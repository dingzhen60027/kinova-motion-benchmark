
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(process.argv[2],'utf8').split('<script>')[1].split('</script>')[0];
const items={},callbacks=[],contexts=[];
const context=new Proxy({}, {get:(target,key)=>target[key]||(()=>{}), set:(target,key,value)=>(target[key]=value,true)});
function element(tag){return {tag,children:[],dataset:{},style:{},value:tag==='progress'?'0':'workspace',clientWidth:1000,clientHeight:640,
 append(...a){this.children.push(...a)},getContext(){return context},setPointerCapture(){},addEventListener(name,fn){this['on'+name]=fn}}}
const sandbox={document:{getElementById(id){return items[id]||(items[id]=element(id))},createElement:element,createTextNode:text=>({text})},
 window:{addEventListener(){}},devicePixelRatio:1,requestAnimationFrame:fn=>callbacks.push(fn),console};
vm.createContext(sandbox);vm.runInContext(source,sandbox);
assert.match(items.state.textContent,/normalized_path_parameter = 0.0000/);
const box=items.legend.children[0].children[0];box.checked=false;box.onchange();assert.equal(items.state.textContent,'');
box.checked=true;box.onchange();items.progress.value='1';items.progress.oninput();assert.match(items.state.textContent,/= 1.0000/);
items.view.value='joints';items.view.onchange();assert.match(items.state.textContent,/= 1.0000/);
items.view.value='workspace';items.view.onchange();
items.canvas.onpointerdown({clientX:0,clientY:0,pointerId:1});items.canvas.onpointermove({clientX:25,clientY:20});
assert.notEqual(vm.runInContext('yaw',sandbox),-.87);items.canvas.onpointerup();items.reset.onclick();assert.equal(vm.runInContext('yaw',sandbox),-.87);
let prevented=false;items.canvas.onwheel({deltaY:-100,preventDefault(){prevented=true}});assert.ok(prevented);assert.ok(vm.runInContext('zoom',sandbox)>1);
items.play.onclick();assert.equal(items.play.textContent,'Pause');assert.equal(items.progress.value,0);
callbacks.shift()(0);callbacks.shift()(5000);assert.equal(+items.progress.value,.5);items.play.onclick();assert.equal(items.play.textContent,'Play');
assert.equal(vm.runInContext('sampleAt({axis:[0,.1,1]},.12)',sandbox),1);
const actual=vm.runInContext('frames(D.traces[0].q[1]).fr3_hand_tcp.map(row=>row[3]).slice(0,3)',sandbox);
const expected=vm.runInContext('D.traces[0].tcp[1]',sandbox);
actual.forEach((v,i)=>assert.ok(Math.abs(v-expected[i])<1e-12));
console.log(JSON.stringify({javascript_controls:'passed',cpu_and_js_fk_max_tolerance:1e-12,browser_rendering:'not_tested'}));
