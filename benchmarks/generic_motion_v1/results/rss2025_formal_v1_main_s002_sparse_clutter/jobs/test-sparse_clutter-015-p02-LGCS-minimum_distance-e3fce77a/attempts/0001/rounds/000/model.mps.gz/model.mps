NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 L  R91     
 E  R92     
 E  R93     
 E  R94     
 E  R95     
 E  R96     
 E  R97     
 E  R98     
 E  R99     
 E  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
 L  qc10    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -3.0999999046325684e+00
    phi[0,1]  R103      -2.2400000095367432e+00
    phi[0,1]  R104      -2.2400000095367432e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      -3.0999999046325684e+00
    phi[0,1]  R107      -2.5699999332427979e+00
    phi[0,1]  R108      -2.5699999332427979e+00
    phi[0,1]  R109      -3.0999999046325684e+00
    phi[0,1]  R110      -3.0999999046325684e+00
    phi[0,1]  R111      -2.0899999141693115e+00
    phi[0,1]  R112      -2.0899999141693115e+00
    phi[0,1]  R113      -3.0999999046325684e+00
    phi[0,1]  R114      -3.0999999046325684e+00
    phi[0,1]  R115      -6.7870473861694336e-01
    phi[0,1]  R116      2.4679460525512695e+00
    phi[0,1]  R117      -6.5995240211486816e-01
    phi[0,1]  R118      1.5863311290740967e-01
    phi[0,1]  R119      2.2749914228916168e-01
    phi[0,1]  R120      5.0446015596389771e-01
    phi[0,1]  R121      -1.0441317558288574e+00
    phi[0,1]  R122      2.4581206962466240e-02
    phi[0,1]  R123      -1.1326408386230469e-01
    phi[0,1]  R124      9.0075075626373291e-01
    phi[0,1]  R125      -1.3231745958328247e+00
    phi[0,1]  R126      5.1040178537368774e-01
    phi[0,1]  R127      -1.1362349987030029e+00
    phi[0,1]  R128      -1.2534059286117554e+00
    phi[0,1]  R129      -2.5273030996322632e-01
    phi[0,1]  R130      -6.9403052330017090e-01
    phi[0,1]  R131      -1.0995017290115356e+00
    phi[0,1]  R132      -2.2981978952884674e-01
    phi[0,1]  R133      -2.5279722213745117e+00
    phi[0,1]  R134      -1.4782435894012451e+00
    phi[0,1]  R135      -3.1369706988334656e-01
    phi[0,1]  R136      1.1746426820755005e+00
    phi[0,1]  R137      -6.7840886116027832e-01
    phi[0,1]  R138      -1.1949342489242554e+00
    phi[0,1]  R139      8.6217188835144043e-01
    phi[0,1]  R140      1.3197193145751953e+00
    phi[0,1]  R141      1.2746766805648804e+00
    phi[0,1]  R142      8.4226405620574951e-01
    phi[0,1]  R143      1.1194735765457153e+00
    phi[0,1]  R144      4.6034428477287292e-01
    phi[0,1]  R145      1.0623747110366821e+00
    phi[0,1]  R146      1.4020334482192993e+00
    phi[0,1]  R147      2.0442163944244385e+00
    phi[0,1]  R148      -1.3945252895355225e+00
    phi[0,1]  R149      1.9599274396896362e+00
    phi[0,1]  R150      -1.9664345979690552e+00
    phi[0,1]  R151      -2.2315731048583984e+00
    phi[0,1]  R152      -2.0604968070983887e+00
    phi[0,1]  R153      -6.8669736385345459e-01
    phi[0,1]  R154      -5.7566374540328979e-01
    phi[0,1]  R155      1.5098834037780762e-01
    phi[0,1]  R156      -9.4772022962570190e-01
    phi[0,1]  R157      -2.6049736142158508e-01
    phi[0,1]  R158      -6.9133520126342773e-01
    phi[0,1]  R159      -1.2187108993530273e+00
    phi[0,1]  R160      -1.0924692153930664e+00
    phi[0,1]  R161      -3.3010971546173096e-01
    phi[0,1]  R162      -8.1356680393218994e-01
    phi[0,1]  R163      -2.2119247913360596e+00
    phi[0,1]  R164      -5.5146235227584839e-01
    phi[0,1]  R165      -3.6900284886360168e-01
    phi[0,1]  R166      -1.2166583538055420e+00
    phi[0,1]  R167      -1.4402250051498413e+00
    phi[0,1]  R168      -1.3968664407730103e+00
    phi[0,1]  R169      1.7343856394290924e-02
    phi[0,1]  R170      -2.1204986572265625e+00
    phi[0,1]  R171      -1.8618186712265015e+00
    phi[0,1]  R172      -1.0128842294216156e-01
    phi[0,1]  R173      -1.1585946083068848e+00
    phi[0,1]  R174      -2.11350417137146
    phi[0,1]  R175      -5.4374343156814575e-01
    phi[0,1]  R176      1.6895470023155212e-01
    phi[0,1]  R177      -2.8368747234344482e-01
    phi[0,1]  R178      -2.0516954362392426e-02
    phi[0,1]  R179      -1.1669390201568604e+00
    phi[0,1]  R180      -6.5428006649017334e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R181      -3.0999999046325684e+00
    phi[1,0]  R182      -3.0999999046325684e+00
    phi[1,0]  R183      -2.2400000095367432e+00
    phi[1,0]  R184      -2.2400000095367432e+00
    phi[1,0]  R185      -3.0999999046325684e+00
    phi[1,0]  R186      -3.0999999046325684e+00
    phi[1,0]  R187      -2.5699999332427979e+00
    phi[1,0]  R188      -2.5699999332427979e+00
    phi[1,0]  R189      -3.0999999046325684e+00
    phi[1,0]  R190      -3.0999999046325684e+00
    phi[1,0]  R191      -2.0899999141693115e+00
    phi[1,0]  R192      -2.0899999141693115e+00
    phi[1,0]  R193      -3.0999999046325684e+00
    phi[1,0]  R194      -3.0999999046325684e+00
    phi[1,0]  R195      1.2746766805648804e+00
    phi[1,0]  R196      8.4226405620574951e-01
    phi[1,0]  R197      1.1194735765457153e+00
    phi[1,0]  R198      4.6034428477287292e-01
    phi[1,0]  R199      1.0623747110366821e+00
    phi[1,0]  R200      1.4020334482192993e+00
    phi[1,0]  R201      2.0442163944244385e+00
    phi[1,0]  R202      -1.3945252895355225e+00
    phi[1,0]  R203      1.9599274396896362e+00
    phi[1,0]  R204      -1.9664345979690552e+00
    phi[1,0]  R205      -2.2315731048583984e+00
    phi[1,0]  R206      -2.0604968070983887e+00
    phi[1,0]  R207      -6.8669736385345459e-01
    phi[1,0]  R208      -5.7566374540328979e-01
    phi[1,0]  R209      1.5098834037780762e-01
    phi[1,0]  R210      -9.4772022962570190e-01
    phi[1,0]  R211      -2.6049736142158508e-01
    phi[1,0]  R212      -6.9133520126342773e-01
    phi[1,0]  R213      -1.2187108993530273e+00
    phi[1,0]  R214      -1.0924692153930664e+00
    phi[1,0]  R215      -3.3010971546173096e-01
    phi[1,0]  R216      -8.1356680393218994e-01
    phi[1,0]  R217      -2.2119247913360596e+00
    phi[1,0]  R218      -5.5146235227584839e-01
    phi[1,0]  R219      -3.6900284886360168e-01
    phi[1,0]  R220      -1.2166583538055420e+00
    phi[1,0]  R221      -1.4402250051498413e+00
    phi[1,0]  R222      -1.3968664407730103e+00
    phi[1,0]  R223      1.7343856394290924e-02
    phi[1,0]  R224      -2.1204986572265625e+00
    phi[1,0]  R225      -1.8618186712265015e+00
    phi[1,0]  R226      -1.0128842294216156e-01
    phi[1,0]  R227      -1.1585946083068848e+00
    phi[1,0]  R228      -2.11350417137146
    phi[1,0]  R229      -5.4374343156814575e-01
    phi[1,0]  R230      1.6895470023155212e-01
    phi[1,0]  R231      -2.8368747234344482e-01
    phi[1,0]  R232      -2.0516954362392426e-02
    phi[1,0]  R233      -1.1669390201568604e+00
    phi[1,0]  R234      -6.5428006649017334e-01
    phi[1,0]  R235      -6.7870473861694336e-01
    phi[1,0]  R236      2.4679460525512695e+00
    phi[1,0]  R237      -6.5995240211486816e-01
    phi[1,0]  R238      1.5863311290740967e-01
    phi[1,0]  R239      2.2749914228916168e-01
    phi[1,0]  R240      5.0446015596389771e-01
    phi[1,0]  R241      -1.0441317558288574e+00
    phi[1,0]  R242      2.4581206962466240e-02
    phi[1,0]  R243      -1.1326408386230469e-01
    phi[1,0]  R244      9.0075075626373291e-01
    phi[1,0]  R245      -1.3231745958328247e+00
    phi[1,0]  R246      5.1040178537368774e-01
    phi[1,0]  R247      -1.1362349987030029e+00
    phi[1,0]  R248      -1.2534059286117554e+00
    phi[1,0]  R249      -2.5273030996322632e-01
    phi[1,0]  R250      -6.9403052330017090e-01
    phi[1,0]  R251      -1.0995017290115356e+00
    phi[1,0]  R252      -2.2981978952884674e-01
    phi[1,0]  R253      -2.5279722213745117e+00
    phi[1,0]  R254      -1.4782435894012451e+00
    phi[1,0]  R255      -3.1369706988334656e-01
    phi[1,0]  R256      1.1746426820755005e+00
    phi[1,0]  R257      -6.7840886116027832e-01
    phi[1,0]  R258      -1.1949342489242554e+00
    phi[1,0]  R259      8.6217188835144043e-01
    phi[1,0]  R260      1.3197193145751953e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R261      -3.0999999046325684e+00
    phi[0,3]  R262      -3.0999999046325684e+00
    phi[0,3]  R263      -2.2400000095367432e+00
    phi[0,3]  R264      -2.2400000095367432e+00
    phi[0,3]  R265      -3.0999999046325684e+00
    phi[0,3]  R266      -3.0999999046325684e+00
    phi[0,3]  R267      -2.5699999332427979e+00
    phi[0,3]  R268      -2.5699999332427979e+00
    phi[0,3]  R269      -3.0999999046325684e+00
    phi[0,3]  R270      -3.0999999046325684e+00
    phi[0,3]  R271      -2.0899999141693115e+00
    phi[0,3]  R272      -2.0899999141693115e+00
    phi[0,3]  R273      -3.0999999046325684e+00
    phi[0,3]  R274      -3.0999999046325684e+00
    phi[0,3]  R275      -6.7870473861694336e-01
    phi[0,3]  R276      2.4679460525512695e+00
    phi[0,3]  R277      -6.5995240211486816e-01
    phi[0,3]  R278      1.5863311290740967e-01
    phi[0,3]  R279      2.2749914228916168e-01
    phi[0,3]  R280      5.0446015596389771e-01
    phi[0,3]  R281      -1.0441317558288574e+00
    phi[0,3]  R282      2.4581206962466240e-02
    phi[0,3]  R283      -1.1326408386230469e-01
    phi[0,3]  R284      9.0075075626373291e-01
    phi[0,3]  R285      -1.3231745958328247e+00
    phi[0,3]  R286      5.1040178537368774e-01
    phi[0,3]  R287      -1.1362349987030029e+00
    phi[0,3]  R288      -1.2534059286117554e+00
    phi[0,3]  R289      -2.5273030996322632e-01
    phi[0,3]  R290      -6.9403052330017090e-01
    phi[0,3]  R291      -1.0995017290115356e+00
    phi[0,3]  R292      -2.2981978952884674e-01
    phi[0,3]  R293      -2.5279722213745117e+00
    phi[0,3]  R294      -1.4782435894012451e+00
    phi[0,3]  R295      -3.1369706988334656e-01
    phi[0,3]  R296      1.1746426820755005e+00
    phi[0,3]  R297      -6.7840886116027832e-01
    phi[0,3]  R298      -1.1949342489242554e+00
    phi[0,3]  R299      8.6217188835144043e-01
    phi[0,3]  R300      1.3197193145751953e+00
    phi[0,3]  R301      1.6396861076354980e+00
    phi[0,3]  R302      3.7706863880157471e+00
    phi[0,3]  R303      2.5411803722381592e+00
    phi[0,3]  R304      7.6300626993179321e-01
    phi[0,3]  R305      7.1959435939788818e-01
    phi[0,3]  R306      1.6043980121612549e+00
    phi[0,3]  R307      1.14211106300354
    phi[0,3]  R308      9.6057862043380737e-02
    phi[0,3]  R309      -1.1476918458938599e+00
    phi[0,3]  R310      -3.5013895034790039e+00
    phi[0,3]  R311      -1.6980837583541870e+00
    phi[0,3]  R312      2.4073269367218018e+00
    phi[0,3]  R313      0.77571702003479
    phi[0,3]  R314      -1.1615384817123413e+00
    phi[0,3]  R315      -1.2084580659866333e+00
    phi[0,3]  R316      5.9216916561126709e-01
    phi[0,3]  R317      4.0691199898719788e-01
    phi[0,3]  R318      1.9634900093078613e+00
    phi[0,3]  R319      -1.0782167911529541e+00
    phi[0,3]  R320      1.4701441526412964e+00
    phi[0,3]  R321      2.0782308578491211e+00
    phi[0,3]  R322      -1.9334624707698822e-01
    phi[0,3]  R323      -1.2710272073745728e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R324      -3.0999999046325684e+00
    phi[3,0]  R325      -3.0999999046325684e+00
    phi[3,0]  R326      -2.2400000095367432e+00
    phi[3,0]  R327      -2.2400000095367432e+00
    phi[3,0]  R328      -3.0999999046325684e+00
    phi[3,0]  R329      -3.0999999046325684e+00
    phi[3,0]  R330      -2.5699999332427979e+00
    phi[3,0]  R331      -2.5699999332427979e+00
    phi[3,0]  R332      -3.0999999046325684e+00
    phi[3,0]  R333      -3.0999999046325684e+00
    phi[3,0]  R334      -2.0899999141693115e+00
    phi[3,0]  R335      -2.0899999141693115e+00
    phi[3,0]  R336      -3.0999999046325684e+00
    phi[3,0]  R337      -3.0999999046325684e+00
    phi[3,0]  R338      1.6396861076354980e+00
    phi[3,0]  R339      3.7706863880157471e+00
    phi[3,0]  R340      2.5411803722381592e+00
    phi[3,0]  R341      7.6300626993179321e-01
    phi[3,0]  R342      7.1959435939788818e-01
    phi[3,0]  R343      1.6043980121612549e+00
    phi[3,0]  R344      1.14211106300354
    phi[3,0]  R345      9.6057862043380737e-02
    phi[3,0]  R346      -1.1476918458938599e+00
    phi[3,0]  R347      -3.5013895034790039e+00
    phi[3,0]  R348      -1.6980837583541870e+00
    phi[3,0]  R349      2.4073269367218018e+00
    phi[3,0]  R350      0.77571702003479
    phi[3,0]  R351      -1.1615384817123413e+00
    phi[3,0]  R352      -1.2084580659866333e+00
    phi[3,0]  R353      5.9216916561126709e-01
    phi[3,0]  R354      4.0691199898719788e-01
    phi[3,0]  R355      1.9634900093078613e+00
    phi[3,0]  R356      -1.0782167911529541e+00
    phi[3,0]  R357      1.4701441526412964e+00
    phi[3,0]  R358      2.0782308578491211e+00
    phi[3,0]  R359      -1.9334624707698822e-01
    phi[3,0]  R360      -1.2710272073745728e+00
    phi[3,0]  R361      -6.7870473861694336e-01
    phi[3,0]  R362      2.4679460525512695e+00
    phi[3,0]  R363      -6.5995240211486816e-01
    phi[3,0]  R364      1.5863311290740967e-01
    phi[3,0]  R365      2.2749914228916168e-01
    phi[3,0]  R366      5.0446015596389771e-01
    phi[3,0]  R367      -1.0441317558288574e+00
    phi[3,0]  R368      2.4581206962466240e-02
    phi[3,0]  R369      -1.1326408386230469e-01
    phi[3,0]  R370      9.0075075626373291e-01
    phi[3,0]  R371      -1.3231745958328247e+00
    phi[3,0]  R372      5.1040178537368774e-01
    phi[3,0]  R373      -1.1362349987030029e+00
    phi[3,0]  R374      -1.2534059286117554e+00
    phi[3,0]  R375      -2.5273030996322632e-01
    phi[3,0]  R376      -6.9403052330017090e-01
    phi[3,0]  R377      -1.0995017290115356e+00
    phi[3,0]  R378      -2.2981978952884674e-01
    phi[3,0]  R379      -2.5279722213745117e+00
    phi[3,0]  R380      -1.4782435894012451e+00
    phi[3,0]  R381      -3.1369706988334656e-01
    phi[3,0]  R382      1.1746426820755005e+00
    phi[3,0]  R383      -6.7840886116027832e-01
    phi[3,0]  R384      -1.1949342489242554e+00
    phi[3,0]  R385      8.6217188835144043e-01
    phi[3,0]  R386      1.3197193145751953e+00
    phi[11,0]  R0        -1
    phi[11,0]  R2        -2.9538400474887365e+00
    phi[11,0]  R3        -1.2706479506090897e+00
    phi[11,0]  R4        9.5884761695168708e-01
    phi[11,0]  R5        -7.2187123698157118e-01
    phi[11,0]  R6        2.6613844559904591e+00
    phi[11,0]  R7        1.5141137283038582e+00
    phi[11,0]  R8        2.2113237458160806e+00
    phi[11,0]  R99       1
    phi[11,0]  R387      -1.4615985714383184e-01
    phi[11,0]  R388      -6.0538399521213044e+00
    phi[11,0]  R389      -9.6935205892765341e-01
    phi[11,0]  R390      -3.5106479601458327e+00
    phi[11,0]  R391      -4.0588475215842550e+00
    phi[11,0]  R392      -2.1411522876808813e+00
    phi[11,0]  R393      -1.8481286962612267e+00
    phi[11,0]  R394      -3.2918711702243693e+00
    phi[11,0]  R395      -5.7613843606230279e+00
    phi[11,0]  R396      -4.3861544864210922e-01
    phi[11,0]  R397      -3.6041136424731697e+00
    phi[11,0]  R398      -5.7588618586545337e-01
    phi[11,0]  R399      -5.3113236504486494e+00
    phi[11,0]  R400      -8.8867615881648776e-01
    phi[11,0]  R401      -1.0215551815420998e-02
    phi[11,0]  R402      -2.5062842962332077e-02
    phi[11,0]  R403      -1.4202351481575337e-01
    phi[11,0]  R404      -1.4309085953373457e-01
    phi[11,0]  R405      -1.6350828316176236e-01
    phi[11,0]  R406      -2.4030480518859820e-01
    phi[11,0]  R407      -2.8727643501408817e-01
    phi[11,0]  R408      -5.4524787861163526e-01
    phi[11,0]  R409      -1.7051083351698710e+00
    phi[11,0]  R410      -1.3997275841563450e+00
    phi[11,0]  R411      -4.9772334572313337e-03
    phi[11,0]  R412      -2.0518425274975716e-02
    phi[11,0]  R413      -4.3335558875118529e-02
    phi[11,0]  R414      -0.0632229498976622
    phi[11,0]  R415      -1.1934124321824183e-01
    phi[11,0]  R416      -1.3482985656666990e-01
    phi[11,0]  R417      -1.4663578686330736e-01
    phi[11,0]  R418      -1.5682479762292129e-01
    phi[11,0]  R419      -1.6398251683743759e-01
    phi[11,0]  R420      -1.8518033086844721e-01
    phi[11,0]  R421      -5.7762233398412077e-02
    phi[11,0]  R422      -1.1731362068038997e-01
    phi[11,0]  R423      -1.1924960581187738e-01
    phi[11,0]  R424      -1.2599485404256772e-01
    phi[11,0]  R425      -1.3568051483530752e-01
    phi[11,0]  R426      -1.3676102965902004e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R427      -3.0999999046325684e+00
    phi[1,2]  R428      -3.0999999046325684e+00
    phi[1,2]  R429      -2.2400000095367432e+00
    phi[1,2]  R430      -2.2400000095367432e+00
    phi[1,2]  R431      -3.0999999046325684e+00
    phi[1,2]  R432      -3.0999999046325684e+00
    phi[1,2]  R433      -2.5699999332427979e+00
    phi[1,2]  R434      -2.5699999332427979e+00
    phi[1,2]  R435      -3.0999999046325684e+00
    phi[1,2]  R436      -3.0999999046325684e+00
    phi[1,2]  R437      -2.0899999141693115e+00
    phi[1,2]  R438      -2.0899999141693115e+00
    phi[1,2]  R439      -3.0999999046325684e+00
    phi[1,2]  R440      -3.0999999046325684e+00
    phi[1,2]  R441      1.2746766805648804e+00
    phi[1,2]  R442      8.4226405620574951e-01
    phi[1,2]  R443      1.1194735765457153e+00
    phi[1,2]  R444      4.6034428477287292e-01
    phi[1,2]  R445      1.0623747110366821e+00
    phi[1,2]  R446      1.4020334482192993e+00
    phi[1,2]  R447      2.0442163944244385e+00
    phi[1,2]  R448      -1.3945252895355225e+00
    phi[1,2]  R449      1.9599274396896362e+00
    phi[1,2]  R450      -1.9664345979690552e+00
    phi[1,2]  R451      -2.2315731048583984e+00
    phi[1,2]  R452      -2.0604968070983887e+00
    phi[1,2]  R453      -6.8669736385345459e-01
    phi[1,2]  R454      -5.7566374540328979e-01
    phi[1,2]  R455      1.5098834037780762e-01
    phi[1,2]  R456      -9.4772022962570190e-01
    phi[1,2]  R457      -2.6049736142158508e-01
    phi[1,2]  R458      -6.9133520126342773e-01
    phi[1,2]  R459      -1.2187108993530273e+00
    phi[1,2]  R460      -1.0924692153930664e+00
    phi[1,2]  R461      -3.3010971546173096e-01
    phi[1,2]  R462      -8.1356680393218994e-01
    phi[1,2]  R463      -2.2119247913360596e+00
    phi[1,2]  R464      -5.5146235227584839e-01
    phi[1,2]  R465      -3.6900284886360168e-01
    phi[1,2]  R466      -1.2166583538055420e+00
    phi[1,2]  R467      -1.4402250051498413e+00
    phi[1,2]  R468      -1.3968664407730103e+00
    phi[1,2]  R469      1.7343856394290924e-02
    phi[1,2]  R470      -2.1204986572265625e+00
    phi[1,2]  R471      -1.8618186712265015e+00
    phi[1,2]  R472      -1.0128842294216156e-01
    phi[1,2]  R473      -1.1585946083068848e+00
    phi[1,2]  R474      -2.11350417137146
    phi[1,2]  R475      -5.4374343156814575e-01
    phi[1,2]  R476      1.6895470023155212e-01
    phi[1,2]  R477      -2.8368747234344482e-01
    phi[1,2]  R478      -2.0516954362392426e-02
    phi[1,2]  R479      -1.1669390201568604e+00
    phi[1,2]  R480      -6.5428006649017334e-01
    phi[1,2]  R481      2.7869639396667480e+00
    phi[1,2]  R482      -8.2424086332321167e-01
    phi[1,2]  R483      2.8569560050964355e+00
    phi[1,2]  R484      1.8975862264633179e+00
    phi[1,2]  R485      9.6506899595260620e-01
    phi[1,2]  R486      2.9695560932159424e+00
    phi[1,2]  R487      2.7049057483673096e+00
    phi[1,2]  R488      -3.3425131440162659e-01
    phi[1,2]  R489      3.5399645566940308e-01
    phi[1,2]  R490      -2.2516159340739250e-02
    phi[1,2]  R491      -1.3879041671752930e+00
    phi[1,2]  R492      -3.2224843502044678e+00
    phi[1,2]  R493      -2.1702163219451904e+00
    phi[1,2]  R494      -2.1587302684783936e+00
    phi[1,2]  R495      -1.6562418937683105e+00
    phi[1,2]  R496      -2.1867699623107910e+00
    phi[1,2]  R497      -1.4608135223388672e+00
    phi[1,2]  R498      -2.9825313091278076e+00
    phi[1,2]  R499      -9.1655021905899048e-01
    phi[1,2]  R500      3.3565130829811096e-01
    phi[1,2]  R501      3.3612579107284546e-01
    phi[1,2]  R502      5.7250708341598511e-01
    phi[1,2]  R503      7.8760528564453125e-01
    phi[1,2]  R504      -4.0896885097026825e-02
    phi[1,2]  R505      3.5293149948120117e-01
    phi[1,2]  R506      8.0277752876281738e-01
    phi[1,2]  R507      -5.2129387855529785e-01
    phi[1,2]  R508      -2.9921722412109375e-01
    phi[1,2]  R509      -8.2313217222690582e-02
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R510      -3.0999999046325684e+00
    phi[2,1]  R511      -3.0999999046325684e+00
    phi[2,1]  R512      -2.2400000095367432e+00
    phi[2,1]  R513      -2.2400000095367432e+00
    phi[2,1]  R514      -3.0999999046325684e+00
    phi[2,1]  R515      -3.0999999046325684e+00
    phi[2,1]  R516      -2.5699999332427979e+00
    phi[2,1]  R517      -2.5699999332427979e+00
    phi[2,1]  R518      -3.0999999046325684e+00
    phi[2,1]  R519      -3.0999999046325684e+00
    phi[2,1]  R520      -2.0899999141693115e+00
    phi[2,1]  R521      -2.0899999141693115e+00
    phi[2,1]  R522      -3.0999999046325684e+00
    phi[2,1]  R523      -3.0999999046325684e+00
    phi[2,1]  R524      2.7869639396667480e+00
    phi[2,1]  R525      -8.2424086332321167e-01
    phi[2,1]  R526      2.8569560050964355e+00
    phi[2,1]  R527      1.8975862264633179e+00
    phi[2,1]  R528      9.6506899595260620e-01
    phi[2,1]  R529      2.9695560932159424e+00
    phi[2,1]  R530      2.7049057483673096e+00
    phi[2,1]  R531      -3.3425131440162659e-01
    phi[2,1]  R532      3.5399645566940308e-01
    phi[2,1]  R533      -2.2516159340739250e-02
    phi[2,1]  R534      -1.3879041671752930e+00
    phi[2,1]  R535      -3.2224843502044678e+00
    phi[2,1]  R536      -2.1702163219451904e+00
    phi[2,1]  R537      -2.1587302684783936e+00
    phi[2,1]  R538      -1.6562418937683105e+00
    phi[2,1]  R539      -2.1867699623107910e+00
    phi[2,1]  R540      -1.4608135223388672e+00
    phi[2,1]  R541      -2.9825313091278076e+00
    phi[2,1]  R542      -9.1655021905899048e-01
    phi[2,1]  R543      3.3565130829811096e-01
    phi[2,1]  R544      3.3612579107284546e-01
    phi[2,1]  R545      5.7250708341598511e-01
    phi[2,1]  R546      7.8760528564453125e-01
    phi[2,1]  R547      -4.0896885097026825e-02
    phi[2,1]  R548      3.5293149948120117e-01
    phi[2,1]  R549      8.0277752876281738e-01
    phi[2,1]  R550      -5.2129387855529785e-01
    phi[2,1]  R551      -2.9921722412109375e-01
    phi[2,1]  R552      -8.2313217222690582e-02
    phi[2,1]  R553      1.2746766805648804e+00
    phi[2,1]  R554      8.4226405620574951e-01
    phi[2,1]  R555      1.1194735765457153e+00
    phi[2,1]  R556      4.6034428477287292e-01
    phi[2,1]  R557      1.0623747110366821e+00
    phi[2,1]  R558      1.4020334482192993e+00
    phi[2,1]  R559      2.0442163944244385e+00
    phi[2,1]  R560      -1.3945252895355225e+00
    phi[2,1]  R561      1.9599274396896362e+00
    phi[2,1]  R562      -1.9664345979690552e+00
    phi[2,1]  R563      -2.2315731048583984e+00
    phi[2,1]  R564      -2.0604968070983887e+00
    phi[2,1]  R565      -6.8669736385345459e-01
    phi[2,1]  R566      -5.7566374540328979e-01
    phi[2,1]  R567      1.5098834037780762e-01
    phi[2,1]  R568      -9.4772022962570190e-01
    phi[2,1]  R569      -2.6049736142158508e-01
    phi[2,1]  R570      -6.9133520126342773e-01
    phi[2,1]  R571      -1.2187108993530273e+00
    phi[2,1]  R572      -1.0924692153930664e+00
    phi[2,1]  R573      -3.3010971546173096e-01
    phi[2,1]  R574      -8.1356680393218994e-01
    phi[2,1]  R575      -2.2119247913360596e+00
    phi[2,1]  R576      -5.5146235227584839e-01
    phi[2,1]  R577      -3.6900284886360168e-01
    phi[2,1]  R578      -1.2166583538055420e+00
    phi[2,1]  R579      -1.4402250051498413e+00
    phi[2,1]  R580      -1.3968664407730103e+00
    phi[2,1]  R581      1.7343856394290924e-02
    phi[2,1]  R582      -2.1204986572265625e+00
    phi[2,1]  R583      -1.8618186712265015e+00
    phi[2,1]  R584      -1.0128842294216156e-01
    phi[2,1]  R585      -1.1585946083068848e+00
    phi[2,1]  R586      -2.11350417137146
    phi[2,1]  R587      -5.4374343156814575e-01
    phi[2,1]  R588      1.6895470023155212e-01
    phi[2,1]  R589      -2.8368747234344482e-01
    phi[2,1]  R590      -2.0516954362392426e-02
    phi[2,1]  R591      -1.1669390201568604e+00
    phi[2,1]  R592      -6.5428006649017334e-01
    phi[2,10]  R18       1
    phi[2,10]  R19       1
    phi[2,10]  R90       -1
    phi[2,10]  R593      -3.0999999046325684e+00
    phi[2,10]  R594      -3.0999999046325684e+00
    phi[2,10]  R595      -2.2400000095367432e+00
    phi[2,10]  R596      -2.2400000095367432e+00
    phi[2,10]  R597      -3.0999999046325684e+00
    phi[2,10]  R598      -3.0999999046325684e+00
    phi[2,10]  R599      -2.5699999332427979e+00
    phi[2,10]  R600      -2.5699999332427979e+00
    phi[2,10]  R601      -3.0999999046325684e+00
    phi[2,10]  R602      -3.0999999046325684e+00
    phi[2,10]  R603      -2.0899999141693115e+00
    phi[2,10]  R604      -2.0899999141693115e+00
    phi[2,10]  R605      -3.0999999046325684e+00
    phi[2,10]  R606      -3.0999999046325684e+00
    phi[2,10]  R607      2.7869639396667480e+00
    phi[2,10]  R608      -8.2424086332321167e-01
    phi[2,10]  R609      2.8569560050964355e+00
    phi[2,10]  R610      1.8975862264633179e+00
    phi[2,10]  R611      9.6506899595260620e-01
    phi[2,10]  R612      2.9695560932159424e+00
    phi[2,10]  R613      2.7049057483673096e+00
    phi[2,10]  R614      -3.3425131440162659e-01
    phi[2,10]  R615      3.5399645566940308e-01
    phi[2,10]  R616      -2.2516159340739250e-02
    phi[2,10]  R617      -1.3879041671752930e+00
    phi[2,10]  R618      -3.2224843502044678e+00
    phi[2,10]  R619      -2.1702163219451904e+00
    phi[2,10]  R620      -2.1587302684783936e+00
    phi[2,10]  R621      -1.6562418937683105e+00
    phi[2,10]  R622      -2.1867699623107910e+00
    phi[2,10]  R623      -1.4608135223388672e+00
    phi[2,10]  R624      -2.9825313091278076e+00
    phi[2,10]  R625      -9.1655021905899048e-01
    phi[2,10]  R626      3.3565130829811096e-01
    phi[2,10]  R627      3.3612579107284546e-01
    phi[2,10]  R628      5.7250708341598511e-01
    phi[2,10]  R629      7.8760528564453125e-01
    phi[2,10]  R630      -4.0896885097026825e-02
    phi[2,10]  R631      3.5293149948120117e-01
    phi[2,10]  R632      8.0277752876281738e-01
    phi[2,10]  R633      -5.2129387855529785e-01
    phi[2,10]  R634      -2.9921722412109375e-01
    phi[2,10]  R635      -8.2313217222690582e-02
    phi[2,10]  R636      3.7476246356964111e+00
    phi[2,10]  R637      2.3326549530029297e+00
    phi[2,10]  R638      3.0208306312561035e+00
    phi[2,10]  R639      3.8094127178192139e+00
    phi[2,10]  R640      3.1111540794372559e+00
    phi[2,10]  R641      2.9160006046295166e+00
    phi[2,10]  R642      1.3418357372283936e+00
    phi[2,10]  R643      6.5273576974868774e-01
    phi[2,10]  R644      1.5833889245986938e+00
    phi[2,10]  R645      1.6466869115829468e+00
    phi[2,10]  R646      -8.0848425626754761e-01
    phi[2,10]  R647      -2.5664358139038086e+00
    phi[2,10]  R648      -4.7129729390144348e-01
    phi[2,10]  R649      2.2003555297851562e+00
    phi[2,10]  R650      -1.9344836473464966e+00
    phi[2,10]  R651      -2.1741805076599121e+00
    phi[2,10]  R652      -7.8689891099929810e-01
    phi[2,10]  R653      -1.6290515661239624e+00
    phi[2,10]  R654      -1.6878708600997925e+00
    phi[2,10]  R655      -2.6771090030670166e+00
    phi[2,10]  R656      2.3412392139434814e+00
    phi[2,10]  R657      -3.5036070346832275e+00
    phi[2,10]  R658      -2.7890751361846924e+00
    phi[2,10]  R659      -4.11458158493042
    phi[2,10]  R660      -5.8083885908126831e-01
    phi[2,10]  R661      -1.1641008853912354e+00
    phi[2,10]  R662      -2.3986289501190186e+00
    phi[2,10]  R663      -2.6365306377410889e+00
    phi[2,10]  R664      1.9542138576507568e+00
    phi[2,10]  R665      9.7905695438385010e-01
    phi[2,10]  R666      3.0298790931701660e+00
    phi[2,10]  R667      -2.0503067970275879e+00
    phi[2,10]  R668      -1.2998553514480591e+00
    phi[2,10]  R669      2.1784925460815430e+00
    phi[2,10]  R670      1.5168902873992920e+00
    phi[2,10]  R671      -1.2194639444351196e+00
    phi[2,10]  R672      -1.4500894546508789e+00
    phi[2,10]  R673      -3.3974559307098389e+00
    phi[2,10]  R674      -2.9136922359466553e+00
    phi[2,10]  R675      -2.7470922470092773e+00
    phi[10,2]  R18       -1
    phi[10,2]  R90       1
    phi[10,2]  R91       1
    phi[10,2]  R676      -3.0999999046325684e+00
    phi[10,2]  R677      -3.0999999046325684e+00
    phi[10,2]  R678      -2.2400000095367432e+00
    phi[10,2]  R679      -2.2400000095367432e+00
    phi[10,2]  R680      -3.0999999046325684e+00
    phi[10,2]  R681      -3.0999999046325684e+00
    phi[10,2]  R682      -2.5699999332427979e+00
    phi[10,2]  R683      -2.5699999332427979e+00
    phi[10,2]  R684      -3.0999999046325684e+00
    phi[10,2]  R685      -3.0999999046325684e+00
    phi[10,2]  R686      -2.0899999141693115e+00
    phi[10,2]  R687      -2.0899999141693115e+00
    phi[10,2]  R688      -3.0999999046325684e+00
    phi[10,2]  R689      -3.0999999046325684e+00
    phi[10,2]  R690      3.7476246356964111e+00
    phi[10,2]  R691      2.3326549530029297e+00
    phi[10,2]  R692      3.0208306312561035e+00
    phi[10,2]  R693      3.8094127178192139e+00
    phi[10,2]  R694      3.1111540794372559e+00
    phi[10,2]  R695      2.9160006046295166e+00
    phi[10,2]  R696      1.3418357372283936e+00
    phi[10,2]  R697      6.5273576974868774e-01
    phi[10,2]  R698      1.5833889245986938e+00
    phi[10,2]  R699      1.6466869115829468e+00
    phi[10,2]  R700      -8.0848425626754761e-01
    phi[10,2]  R701      -2.5664358139038086e+00
    phi[10,2]  R702      -4.7129729390144348e-01
    phi[10,2]  R703      2.2003555297851562e+00
    phi[10,2]  R704      -1.9344836473464966e+00
    phi[10,2]  R705      -2.1741805076599121e+00
    phi[10,2]  R706      -7.8689891099929810e-01
    phi[10,2]  R707      -1.6290515661239624e+00
    phi[10,2]  R708      -1.6878708600997925e+00
    phi[10,2]  R709      -2.6771090030670166e+00
    phi[10,2]  R710      2.3412392139434814e+00
    phi[10,2]  R711      -3.5036070346832275e+00
    phi[10,2]  R712      -2.7890751361846924e+00
    phi[10,2]  R713      -4.11458158493042
    phi[10,2]  R714      -5.8083885908126831e-01
    phi[10,2]  R715      -1.1641008853912354e+00
    phi[10,2]  R716      -2.3986289501190186e+00
    phi[10,2]  R717      -2.6365306377410889e+00
    phi[10,2]  R718      1.9542138576507568e+00
    phi[10,2]  R719      9.7905695438385010e-01
    phi[10,2]  R720      3.0298790931701660e+00
    phi[10,2]  R721      -2.0503067970275879e+00
    phi[10,2]  R722      -1.2998553514480591e+00
    phi[10,2]  R723      2.1784925460815430e+00
    phi[10,2]  R724      1.5168902873992920e+00
    phi[10,2]  R725      -1.2194639444351196e+00
    phi[10,2]  R726      -1.4500894546508789e+00
    phi[10,2]  R727      -3.3974559307098389e+00
    phi[10,2]  R728      -2.9136922359466553e+00
    phi[10,2]  R729      -2.7470922470092773e+00
    phi[10,2]  R730      2.7869639396667480e+00
    phi[10,2]  R731      -8.2424086332321167e-01
    phi[10,2]  R732      2.8569560050964355e+00
    phi[10,2]  R733      1.8975862264633179e+00
    phi[10,2]  R734      9.6506899595260620e-01
    phi[10,2]  R735      2.9695560932159424e+00
    phi[10,2]  R736      2.7049057483673096e+00
    phi[10,2]  R737      -3.3425131440162659e-01
    phi[10,2]  R738      3.5399645566940308e-01
    phi[10,2]  R739      -2.2516159340739250e-02
    phi[10,2]  R740      -1.3879041671752930e+00
    phi[10,2]  R741      -3.2224843502044678e+00
    phi[10,2]  R742      -2.1702163219451904e+00
    phi[10,2]  R743      -2.1587302684783936e+00
    phi[10,2]  R744      -1.6562418937683105e+00
    phi[10,2]  R745      -2.1867699623107910e+00
    phi[10,2]  R746      -1.4608135223388672e+00
    phi[10,2]  R747      -2.9825313091278076e+00
    phi[10,2]  R748      -9.1655021905899048e-01
    phi[10,2]  R749      3.3565130829811096e-01
    phi[10,2]  R750      3.3612579107284546e-01
    phi[10,2]  R751      5.7250708341598511e-01
    phi[10,2]  R752      7.8760528564453125e-01
    phi[10,2]  R753      -4.0896885097026825e-02
    phi[10,2]  R754      3.5293149948120117e-01
    phi[10,2]  R755      8.0277752876281738e-01
    phi[10,2]  R756      -5.2129387855529785e-01
    phi[10,2]  R757      -2.9921722412109375e-01
    phi[10,2]  R758      -8.2313217222690582e-02
    phi[2,12]  R18       1
    phi[2,12]  R19       1
    phi[2,12]  R20       -2.7206018712518723e+00
    phi[2,12]  R21       1.0567445197567189e+00
    phi[2,12]  R22       3.0645618551547318e+00
    phi[2,12]  R23       1.5344943591100941e+00
    phi[2,12]  R24       -1.4155262718534778e+00
    phi[2,12]  R25       -4.7520743336823168e-01
    phi[2,12]  R26       -4.2223510441809609e-01
    phi[2,12]  R100      -1
    phi[2,12]  R759      -5.8206017758844411e+00
    phi[2,12]  R760      -3.7939803338069611e-01
    phi[2,12]  R761      -1.1832554897800243e+00
    phi[2,12]  R762      -3.2967445292934618e+00
    phi[2,12]  R763      -3.5438049477836575e-02
    phi[2,12]  R764      -6.1645617597873006e+00
    phi[2,12]  R765      -1.0355055741327037e+00
    phi[2,12]  R766      -4.1044942923528920e+00
    phi[2,12]  R767      -4.5155261764860466e+00
    phi[2,12]  R768      -1.6844736327790906e+00
    phi[2,12]  R769      -2.5652073475375432e+00
    phi[2,12]  R770      -1.6147924808010798e+00
    phi[2,12]  R771      -3.5222350090506644e+00
    phi[2,12]  R772      -2.6777648002144723e+00
    phi[2,12]  R773      -9.7226166511786616e-02
    phi[2,12]  R774      -1.2842990061746251e-01
    phi[2,12]  R775      -1.2862491639586704e-01
    phi[2,12]  R776      -1.5028489036843506e-01
    phi[2,12]  R777      -1.6737669050826054e-01
    phi[2,12]  R778      -1.7810123379444409e-01
    phi[2,12]  R779      -1.8694156692253561e-01
    phi[2,12]  R780      -2.0043775879564310e-01
    phi[2,12]  R781      -2.0588321214352789e-01
    phi[2,12]  R782      -3.1003777275518385e-01
    phi[2,12]  R783      -1.0274234577734420e-01
    phi[2,12]  R784      -1.0711896143275146e-01
    phi[2,12]  R785      -1.1355123052965155e-01
    phi[2,12]  R786      -1.2508703191093984e-01
    phi[2,12]  R787      -1.2864421886260358e-01
    phi[2,12]  R788      -1.2956061122307538e-01
    phi[2,12]  R789      -1.3069707565000810e-01
    phi[2,12]  R790      -1.3084515835611610e-01
    phi[2,12]  R791      -1.3436429249663628e-01
    phi[2,12]  R792      -1.7234586305036825e-01
    phi[2,12]  R793      -2.1164956142080638e-01
    phi[2,12]  R794      -2.2282485896123438e-01
    phi[2,12]  R795      -2.2357641577242027e-01
    phi[2,12]  R796      -2.2542281887131502e-01
    phi[2,12]  R797      -2.2546469779037526e-01
    phi[2,12]  R798      -2.2736352144449334e-01
    phi[2,12]  R799      -2.4017957977175403e-01
    phi[2,12]  R800      -2.7639623476293953e+00
    phi[2,12]  R801      -2.2985473096229292e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R802      -3.0999999046325684e+00
    phi[3,4]  R803      -3.0999999046325684e+00
    phi[3,4]  R804      -2.2400000095367432e+00
    phi[3,4]  R805      -2.2400000095367432e+00
    phi[3,4]  R806      -3.0999999046325684e+00
    phi[3,4]  R807      -3.0999999046325684e+00
    phi[3,4]  R808      -2.5699999332427979e+00
    phi[3,4]  R809      -2.5699999332427979e+00
    phi[3,4]  R810      -3.0999999046325684e+00
    phi[3,4]  R811      -3.0999999046325684e+00
    phi[3,4]  R812      -2.0899999141693115e+00
    phi[3,4]  R813      -2.0899999141693115e+00
    phi[3,4]  R814      -3.0999999046325684e+00
    phi[3,4]  R815      -3.0999999046325684e+00
    phi[3,4]  R816      1.6396861076354980e+00
    phi[3,4]  R817      3.7706863880157471e+00
    phi[3,4]  R818      2.5411803722381592e+00
    phi[3,4]  R819      7.6300626993179321e-01
    phi[3,4]  R820      7.1959435939788818e-01
    phi[3,4]  R821      1.6043980121612549e+00
    phi[3,4]  R822      1.14211106300354
    phi[3,4]  R823      9.6057862043380737e-02
    phi[3,4]  R824      -1.1476918458938599e+00
    phi[3,4]  R825      -3.5013895034790039e+00
    phi[3,4]  R826      -1.6980837583541870e+00
    phi[3,4]  R827      2.4073269367218018e+00
    phi[3,4]  R828      0.77571702003479
    phi[3,4]  R829      -1.1615384817123413e+00
    phi[3,4]  R830      -1.2084580659866333e+00
    phi[3,4]  R831      5.9216916561126709e-01
    phi[3,4]  R832      4.0691199898719788e-01
    phi[3,4]  R833      1.9634900093078613e+00
    phi[3,4]  R834      -1.0782167911529541e+00
    phi[3,4]  R835      1.4701441526412964e+00
    phi[3,4]  R836      2.0782308578491211e+00
    phi[3,4]  R837      -1.9334624707698822e-01
    phi[3,4]  R838      -1.2710272073745728e+00
    phi[3,4]  R839      9.2054808139801025e-01
    phi[3,4]  R840      1.7996376752853394e+00
    phi[3,4]  R841      2.1969823837280273e+00
    phi[3,4]  R842      3.0140171051025391e+00
    phi[3,4]  R843      2.1068191528320312e+00
    phi[3,4]  R844      3.2593665122985840e+00
    phi[3,4]  R845      3.0053393840789795e+00
    phi[3,4]  R846      3.5564930438995361e+00
    phi[3,4]  R847      2.4449074268341064e+00
    phi[3,4]  R848      2.9883198738098145e+00
    phi[3,4]  R849      -4.0879030227661133e+00
    phi[3,4]  R850      -3.2198550701141357e+00
    phi[3,4]  R851      -3.3690595626831055e+00
    phi[3,4]  R852      -4.1031789779663086e+00
    phi[3,4]  R853      -1.9102838039398193e+00
    phi[3,4]  R854      -1.4092475175857544e+00
    phi[3,4]  R855      -1.1926051229238510e-01
    phi[3,4]  R856      -2.9940478801727295e+00
    phi[3,4]  R857      -1.5206407308578491e+00
    phi[3,4]  R858      -0.145842045545578
    phi[3,4]  R859      -1.7806247472763062e+00
    phi[3,4]  R860      -1.3647599220275879e+00
    phi[3,4]  R861      -2.8645715713500977e+00
    phi[3,4]  R862      -2.8117299079895020e+00
    phi[3,4]  R863      -1.9281855821609497e+00
    phi[3,4]  R864      -3.2804775238037109e+00
    phi[3,4]  R865      -1.5945694446563721e+00
    phi[3,4]  R866      1.2965929508209229e+00
    phi[3,4]  R867      -1.9109510183334351e+00
    phi[3,4]  R868      -1.5469816923141479e+00
    phi[3,4]  R869      -2.6647369861602783e+00
    phi[3,4]  R870      -2.1193079948425293e+00
    phi[3,4]  R871      -2.6023945808410645e+00
    phi[3,4]  R872      -1.1140489578247070e+00
    phi[3,4]  R873      -9.8448818922042847e-01
    phi[3,4]  R874      -0.836376965045929
    phi[3,4]  R875      -2.1451218128204346e+00
    phi[3,4]  R876      -2.5312433242797852e+00
    phi[3,4]  R877      -2.9531803131103516e+00
    phi[3,4]  R878      -2.4701972007751465e+00
    phi[3,4]  R879      -4.0981993675231934e+00
    phi[3,4]  R880      -1.5266170501708984e+00
    phi[3,4]  R881      -1.4208955764770508e+00
    phi[3,4]  R882      -1.4423501491546631e+00
    phi[3,4]  R883      -1.4685974121093750e+00
    phi[3,4]  R884      -2.0717191696166992e+00
    phi[3,4]  R885      -3.0820348262786865e+00
    phi[3,4]  R886      -1.2993072271347046e+00
    phi[3,4]  R887      -1.1897383928298950e+00
    phi[3,4]  R888      -1.9165163040161133e+00
    phi[3,4]  R889      -2.8225593566894531e+00
    phi[3,4]  R890      -3.4229321479797363e+00
    phi[3,4]  R891      -5.4135984182357788e-01
    phi[3,4]  R892      -2.5577859878540039e+00
    phi[3,4]  R893      -2.0503635406494141e+00
    phi[3,4]  R894      -5.8280783891677856e-01
    phi[3,4]  R895      4.3543326854705811e-01
    phi[3,4]  R896      3.7018683552742004e-01
    phi[3,4]  R897      1.3058933019638062e+00
    phi[3,4]  R898      -1.9719191789627075e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R899      -3.0999999046325684e+00
    phi[4,3]  R900      -3.0999999046325684e+00
    phi[4,3]  R901      -2.2400000095367432e+00
    phi[4,3]  R902      -2.2400000095367432e+00
    phi[4,3]  R903      -3.0999999046325684e+00
    phi[4,3]  R904      -3.0999999046325684e+00
    phi[4,3]  R905      -2.5699999332427979e+00
    phi[4,3]  R906      -2.5699999332427979e+00
    phi[4,3]  R907      -3.0999999046325684e+00
    phi[4,3]  R908      -3.0999999046325684e+00
    phi[4,3]  R909      -2.0899999141693115e+00
    phi[4,3]  R910      -2.0899999141693115e+00
    phi[4,3]  R911      -3.0999999046325684e+00
    phi[4,3]  R912      -3.0999999046325684e+00
    phi[4,3]  R913      9.2054808139801025e-01
    phi[4,3]  R914      1.7996376752853394e+00
    phi[4,3]  R915      2.1969823837280273e+00
    phi[4,3]  R916      3.0140171051025391e+00
    phi[4,3]  R917      2.1068191528320312e+00
    phi[4,3]  R918      3.2593665122985840e+00
    phi[4,3]  R919      3.0053393840789795e+00
    phi[4,3]  R920      3.5564930438995361e+00
    phi[4,3]  R921      2.4449074268341064e+00
    phi[4,3]  R922      2.9883198738098145e+00
    phi[4,3]  R923      -4.0879030227661133e+00
    phi[4,3]  R924      -3.2198550701141357e+00
    phi[4,3]  R925      -3.3690595626831055e+00
    phi[4,3]  R926      -4.1031789779663086e+00
    phi[4,3]  R927      -1.9102838039398193e+00
    phi[4,3]  R928      -1.4092475175857544e+00
    phi[4,3]  R929      -1.1926051229238510e-01
    phi[4,3]  R930      -2.9940478801727295e+00
    phi[4,3]  R931      -1.5206407308578491e+00
    phi[4,3]  R932      -0.145842045545578
    phi[4,3]  R933      -1.7806247472763062e+00
    phi[4,3]  R934      -1.3647599220275879e+00
    phi[4,3]  R935      -2.8645715713500977e+00
    phi[4,3]  R936      -2.8117299079895020e+00
    phi[4,3]  R937      -1.9281855821609497e+00
    phi[4,3]  R938      -3.2804775238037109e+00
    phi[4,3]  R939      -1.5945694446563721e+00
    phi[4,3]  R940      1.2965929508209229e+00
    phi[4,3]  R941      -1.9109510183334351e+00
    phi[4,3]  R942      -1.5469816923141479e+00
    phi[4,3]  R943      -2.6647369861602783e+00
    phi[4,3]  R944      -2.1193079948425293e+00
    phi[4,3]  R945      -2.6023945808410645e+00
    phi[4,3]  R946      -1.1140489578247070e+00
    phi[4,3]  R947      -9.8448818922042847e-01
    phi[4,3]  R948      -0.836376965045929
    phi[4,3]  R949      -2.1451218128204346e+00
    phi[4,3]  R950      -2.5312433242797852e+00
    phi[4,3]  R951      -2.9531803131103516e+00
    phi[4,3]  R952      -2.4701972007751465e+00
    phi[4,3]  R953      -4.0981993675231934e+00
    phi[4,3]  R954      -1.5266170501708984e+00
    phi[4,3]  R955      -1.4208955764770508e+00
    phi[4,3]  R956      -1.4423501491546631e+00
    phi[4,3]  R957      -1.4685974121093750e+00
    phi[4,3]  R958      -2.0717191696166992e+00
    phi[4,3]  R959      -3.0820348262786865e+00
    phi[4,3]  R960      -1.2993072271347046e+00
    phi[4,3]  R961      -1.1897383928298950e+00
    phi[4,3]  R962      -1.9165163040161133e+00
    phi[4,3]  R963      -2.8225593566894531e+00
    phi[4,3]  R964      -3.4229321479797363e+00
    phi[4,3]  R965      -5.4135984182357788e-01
    phi[4,3]  R966      -2.5577859878540039e+00
    phi[4,3]  R967      -2.0503635406494141e+00
    phi[4,3]  R968      -5.8280783891677856e-01
    phi[4,3]  R969      4.3543326854705811e-01
    phi[4,3]  R970      3.7018683552742004e-01
    phi[4,3]  R971      1.3058933019638062e+00
    phi[4,3]  R972      -1.9719191789627075e+00
    phi[4,3]  R973      1.6396861076354980e+00
    phi[4,3]  R974      3.7706863880157471e+00
    phi[4,3]  R975      2.5411803722381592e+00
    phi[4,3]  R976      7.6300626993179321e-01
    phi[4,3]  R977      7.1959435939788818e-01
    phi[4,3]  R978      1.6043980121612549e+00
    phi[4,3]  R979      1.14211106300354
    phi[4,3]  R980      9.6057862043380737e-02
    phi[4,3]  R981      -1.1476918458938599e+00
    phi[4,3]  R982      -3.5013895034790039e+00
    phi[4,3]  R983      -1.6980837583541870e+00
    phi[4,3]  R984      2.4073269367218018e+00
    phi[4,3]  R985      0.77571702003479
    phi[4,3]  R986      -1.1615384817123413e+00
    phi[4,3]  R987      -1.2084580659866333e+00
    phi[4,3]  R988      5.9216916561126709e-01
    phi[4,3]  R989      4.0691199898719788e-01
    phi[4,3]  R990      1.9634900093078613e+00
    phi[4,3]  R991      -1.0782167911529541e+00
    phi[4,3]  R992      1.4701441526412964e+00
    phi[4,3]  R993      2.0782308578491211e+00
    phi[4,3]  R994      -1.9334624707698822e-01
    phi[4,3]  R995      -1.2710272073745728e+00
    phi[11,3]  R27       -1
    phi[11,3]  R29       -2.9538400474887365e+00
    phi[11,3]  R30       -1.2706479506090897e+00
    phi[11,3]  R31       9.5884761695168708e-01
    phi[11,3]  R32       -7.2187123698157118e-01
    phi[11,3]  R33       2.6613844559904591e+00
    phi[11,3]  R34       1.5141137283038582e+00
    phi[11,3]  R35       2.2113237458160806e+00
    phi[11,3]  R99       1
    phi[11,3]  R996      -1.4615985714383184e-01
    phi[11,3]  R997      -6.0538399521213044e+00
    phi[11,3]  R998      -9.6935205892765341e-01
    phi[11,3]  R999      -3.5106479601458327e+00
    phi[11,3]  R1000     -4.0588475215842550e+00
    phi[11,3]  R1001     -2.1411522876808813e+00
    phi[11,3]  R1002     -1.8481286962612267e+00
    phi[11,3]  R1003     -3.2918711702243693e+00
    phi[11,3]  R1004     -5.7613843606230279e+00
    phi[11,3]  R1005     -4.3861544864210922e-01
    phi[11,3]  R1006     -3.6041136424731697e+00
    phi[11,3]  R1007     -5.7588618586545337e-01
    phi[11,3]  R1008     -5.3113236504486494e+00
    phi[11,3]  R1009     -8.8867615881648776e-01
    phi[11,3]  R1010     -7.1917164195769434e-03
    phi[11,3]  R1011     -3.1248920964650040e-02
    phi[11,3]  R1012     -4.3033443361146784e-02
    phi[11,3]  R1013     -6.8822113284844666e-02
    phi[11,3]  R1014     -2.1025391165759455e-01
    phi[11,3]  R1015     -0.903625045696089
    phi[11,3]  R1016     -1.5616282880444010e-01
    phi[11,3]  R1017     -1.6261190589892971e-01
    phi[11,3]  R1018     -2.6922276885386953e-01
    phi[11,3]  R1019     -7.1213845215489791e-03
    phi[11,3]  R1020     -7.2996975006299092e-02
    phi[11,3]  R1021     -2.6425564248361422e-01
    phi[11,3]  R1022     -2.7674392965300187e-01
    phi[11,3]  R1023     -4.0633021819886705e-01
    phi[11,3]  R1024     -4.3166689743796838e-01
    phi[11,3]  R1025     -4.3907370753458808e-01
    phi[11,3]  R1026     -4.5202754249202393e-01
    phi[11,3]  R1027     -2.6347603775824124e-02
    phi[11,3]  R1028     -9.5449521379483926e-02
    phi[11,3]  R1029     -2.7525928951335454e-01
    phi[11,3]  R1030     -3.1653896650852609e-01
    phi[11,3]  R1031     -3.4483189313135693e-01
    phi[11,3]  R1032     -3.5205183218452984e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1033     -3.0999999046325684e+00
    phi[4,5]  R1034     -3.0999999046325684e+00
    phi[4,5]  R1035     -2.2400000095367432e+00
    phi[4,5]  R1036     -2.2400000095367432e+00
    phi[4,5]  R1037     -3.0999999046325684e+00
    phi[4,5]  R1038     -3.0999999046325684e+00
    phi[4,5]  R1039     -2.5699999332427979e+00
    phi[4,5]  R1040     -2.5699999332427979e+00
    phi[4,5]  R1041     -3.0999999046325684e+00
    phi[4,5]  R1042     -3.0999999046325684e+00
    phi[4,5]  R1043     -2.0899999141693115e+00
    phi[4,5]  R1044     -2.0899999141693115e+00
    phi[4,5]  R1045     -3.0999999046325684e+00
    phi[4,5]  R1046     -3.0999999046325684e+00
    phi[4,5]  R1047     9.2054808139801025e-01
    phi[4,5]  R1048     1.7996376752853394e+00
    phi[4,5]  R1049     2.1969823837280273e+00
    phi[4,5]  R1050     3.0140171051025391e+00
    phi[4,5]  R1051     2.1068191528320312e+00
    phi[4,5]  R1052     3.2593665122985840e+00
    phi[4,5]  R1053     3.0053393840789795e+00
    phi[4,5]  R1054     3.5564930438995361e+00
    phi[4,5]  R1055     2.4449074268341064e+00
    phi[4,5]  R1056     2.9883198738098145e+00
    phi[4,5]  R1057     -4.0879030227661133e+00
    phi[4,5]  R1058     -3.2198550701141357e+00
    phi[4,5]  R1059     -3.3690595626831055e+00
    phi[4,5]  R1060     -4.1031789779663086e+00
    phi[4,5]  R1061     -1.9102838039398193e+00
    phi[4,5]  R1062     -1.4092475175857544e+00
    phi[4,5]  R1063     -1.1926051229238510e-01
    phi[4,5]  R1064     -2.9940478801727295e+00
    phi[4,5]  R1065     -1.5206407308578491e+00
    phi[4,5]  R1066     -0.145842045545578
    phi[4,5]  R1067     -1.7806247472763062e+00
    phi[4,5]  R1068     -1.3647599220275879e+00
    phi[4,5]  R1069     -2.8645715713500977e+00
    phi[4,5]  R1070     -2.8117299079895020e+00
    phi[4,5]  R1071     -1.9281855821609497e+00
    phi[4,5]  R1072     -3.2804775238037109e+00
    phi[4,5]  R1073     -1.5945694446563721e+00
    phi[4,5]  R1074     1.2965929508209229e+00
    phi[4,5]  R1075     -1.9109510183334351e+00
    phi[4,5]  R1076     -1.5469816923141479e+00
    phi[4,5]  R1077     -2.6647369861602783e+00
    phi[4,5]  R1078     -2.1193079948425293e+00
    phi[4,5]  R1079     -2.6023945808410645e+00
    phi[4,5]  R1080     -1.1140489578247070e+00
    phi[4,5]  R1081     -9.8448818922042847e-01
    phi[4,5]  R1082     -0.836376965045929
    phi[4,5]  R1083     -2.1451218128204346e+00
    phi[4,5]  R1084     -2.5312433242797852e+00
    phi[4,5]  R1085     -2.9531803131103516e+00
    phi[4,5]  R1086     -2.4701972007751465e+00
    phi[4,5]  R1087     -4.0981993675231934e+00
    phi[4,5]  R1088     -1.5266170501708984e+00
    phi[4,5]  R1089     -1.4208955764770508e+00
    phi[4,5]  R1090     -1.4423501491546631e+00
    phi[4,5]  R1091     -1.4685974121093750e+00
    phi[4,5]  R1092     -2.0717191696166992e+00
    phi[4,5]  R1093     -3.0820348262786865e+00
    phi[4,5]  R1094     -1.2993072271347046e+00
    phi[4,5]  R1095     -1.1897383928298950e+00
    phi[4,5]  R1096     -1.9165163040161133e+00
    phi[4,5]  R1097     -2.8225593566894531e+00
    phi[4,5]  R1098     -3.4229321479797363e+00
    phi[4,5]  R1099     -5.4135984182357788e-01
    phi[4,5]  R1100     -2.5577859878540039e+00
    phi[4,5]  R1101     -2.0503635406494141e+00
    phi[4,5]  R1102     -5.8280783891677856e-01
    phi[4,5]  R1103     4.3543326854705811e-01
    phi[4,5]  R1104     3.7018683552742004e-01
    phi[4,5]  R1105     1.3058933019638062e+00
    phi[4,5]  R1106     -1.9719191789627075e+00
    phi[4,5]  R1107     2.5924263000488281e+00
    phi[4,5]  R1108     3.53711199760437
    phi[4,5]  R1109     3.5394117832183838e+00
    phi[4,5]  R1110     2.3229961395263672e+00
    phi[4,5]  R1111     3.7350471019744873e+00
    phi[4,5]  R1112     1.4034076929092407e+00
    phi[4,5]  R1113     2.2403628826141357e+00
    phi[4,5]  R1114     -3.7710287570953369e+00
    phi[4,5]  R1115     -3.0185866355895996e+00
    phi[4,5]  R1116     -2.8269133567810059e+00
    phi[4,5]  R1117     -3.0845029354095459e+00
    phi[4,5]  R1118     -2.2722356319427490e+00
    phi[4,5]  R1119     -3.2840840816497803e+00
    phi[4,5]  R1120     -2.9367680549621582e+00
    phi[4,5]  R1121     -3.7130515575408936e+00
    phi[4,5]  R1122     -2.7352783679962158e+00
    phi[4,5]  R1123     -3.3380048274993896e+00
    phi[4,5]  R1124     -2.7803053855895996e+00
    phi[4,5]  R1125     -2.89789080619812
    phi[4,5]  R1126     -2.4679064750671387e+00
    phi[4,5]  R1127     -2.3828625679016113e+00
    phi[4,5]  R1128     -2.8927006721496582e+00
    phi[4,5]  R1129     -2.8146693706512451e+00
    phi[4,5]  R1130     -1.4980833530426025e+00
    phi[4,5]  R1131     -8.4656757116317749e-01
    phi[4,5]  R1132     -3.2655694484710693e+00
    phi[4,5]  R1133     -9.7715121507644653e-01
    phi[4,5]  R1134     -2.5440905094146729e+00
    phi[4,5]  R1135     -2.3269410133361816e+00
    phi[4,5]  R1136     -1.5756518840789795e+00
    phi[4,5]  R1137     -2.0531871318817139e+00
    phi[4,5]  R1138     -2.0736374855041504e+00
    phi[4,5]  R1139     -2.1756799221038818e+00
    phi[4,5]  R1140     -3.5616226196289062e+00
    phi[4,5]  R1141     -1.4555230140686035e+00
    phi[4,5]  R1142     -3.5308477878570557e+00
    phi[4,5]  R1143     -1.7929992675781250e+00
    phi[4,5]  R1144     -2.4907562732696533e+00
    phi[4,5]  R1145     -2.9425508975982666e+00
    phi[4,5]  R1146     -3.3254361152648926e+00
    phi[4,5]  R1147     -3.1573362350463867e+00
    phi[4,5]  R1148     -2.4346692562103271e+00
    phi[4,5]  R1149     -2.8587656021118164e+00
    phi[4,5]  R1150     -1.7089174985885620e+00
    phi[4,5]  R1151     -2.2405498027801514e+00
    phi[4,5]  R1152     -3.4521558284759521e+00
    phi[4,5]  R1153     -2.5426592826843262e+00
    phi[4,5]  R1154     -9.1153711080551147e-01
    phi[4,5]  R1155     -2.1234467029571533e+00
    phi[4,5]  R1156     -2.3582305908203125e+00
    phi[4,5]  R1157     -3.8900392055511475e+00
    phi[4,5]  R1158     -2.5010931491851807e+00
    phi[4,5]  R1159     -1.9737021625041962e-01
    phi[4,5]  R1160     -5.7246887683868408e-01
    phi[4,5]  R1161     -3.7819674611091614e-01
    phi[4,5]  R1162     -2.1048197150230408e-01
    phi[4,5]  R1163     -7.4335479736328125e-01
    phi[4,5]  R1164     -1.0940319299697876e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1165     -3.0999999046325684e+00
    phi[5,4]  R1166     -3.0999999046325684e+00
    phi[5,4]  R1167     -2.2400000095367432e+00
    phi[5,4]  R1168     -2.2400000095367432e+00
    phi[5,4]  R1169     -3.0999999046325684e+00
    phi[5,4]  R1170     -3.0999999046325684e+00
    phi[5,4]  R1171     -2.5699999332427979e+00
    phi[5,4]  R1172     -2.5699999332427979e+00
    phi[5,4]  R1173     -3.0999999046325684e+00
    phi[5,4]  R1174     -3.0999999046325684e+00
    phi[5,4]  R1175     -2.0899999141693115e+00
    phi[5,4]  R1176     -2.0899999141693115e+00
    phi[5,4]  R1177     -3.0999999046325684e+00
    phi[5,4]  R1178     -3.0999999046325684e+00
    phi[5,4]  R1179     2.5924263000488281e+00
    phi[5,4]  R1180     3.53711199760437
    phi[5,4]  R1181     3.5394117832183838e+00
    phi[5,4]  R1182     2.3229961395263672e+00
    phi[5,4]  R1183     3.7350471019744873e+00
    phi[5,4]  R1184     1.4034076929092407e+00
    phi[5,4]  R1185     2.2403628826141357e+00
    phi[5,4]  R1186     -3.7710287570953369e+00
    phi[5,4]  R1187     -3.0185866355895996e+00
    phi[5,4]  R1188     -2.8269133567810059e+00
    phi[5,4]  R1189     -3.0845029354095459e+00
    phi[5,4]  R1190     -2.2722356319427490e+00
    phi[5,4]  R1191     -3.2840840816497803e+00
    phi[5,4]  R1192     -2.9367680549621582e+00
    phi[5,4]  R1193     -3.7130515575408936e+00
    phi[5,4]  R1194     -2.7352783679962158e+00
    phi[5,4]  R1195     -3.3380048274993896e+00
    phi[5,4]  R1196     -2.7803053855895996e+00
    phi[5,4]  R1197     -2.89789080619812
    phi[5,4]  R1198     -2.4679064750671387e+00
    phi[5,4]  R1199     -2.3828625679016113e+00
    phi[5,4]  R1200     -2.8927006721496582e+00
    phi[5,4]  R1201     -2.8146693706512451e+00
    phi[5,4]  R1202     -1.4980833530426025e+00
    phi[5,4]  R1203     -8.4656757116317749e-01
    phi[5,4]  R1204     -3.2655694484710693e+00
    phi[5,4]  R1205     -9.7715121507644653e-01
    phi[5,4]  R1206     -2.5440905094146729e+00
    phi[5,4]  R1207     -2.3269410133361816e+00
    phi[5,4]  R1208     -1.5756518840789795e+00
    phi[5,4]  R1209     -2.0531871318817139e+00
    phi[5,4]  R1210     -2.0736374855041504e+00
    phi[5,4]  R1211     -2.1756799221038818e+00
    phi[5,4]  R1212     -3.5616226196289062e+00
    phi[5,4]  R1213     -1.4555230140686035e+00
    phi[5,4]  R1214     -3.5308477878570557e+00
    phi[5,4]  R1215     -1.7929992675781250e+00
    phi[5,4]  R1216     -2.4907562732696533e+00
    phi[5,4]  R1217     -2.9425508975982666e+00
    phi[5,4]  R1218     -3.3254361152648926e+00
    phi[5,4]  R1219     -3.1573362350463867e+00
    phi[5,4]  R1220     -2.4346692562103271e+00
    phi[5,4]  R1221     -2.8587656021118164e+00
    phi[5,4]  R1222     -1.7089174985885620e+00
    phi[5,4]  R1223     -2.2405498027801514e+00
    phi[5,4]  R1224     -3.4521558284759521e+00
    phi[5,4]  R1225     -2.5426592826843262e+00
    phi[5,4]  R1226     -9.1153711080551147e-01
    phi[5,4]  R1227     -2.1234467029571533e+00
    phi[5,4]  R1228     -2.3582305908203125e+00
    phi[5,4]  R1229     -3.8900392055511475e+00
    phi[5,4]  R1230     -2.5010931491851807e+00
    phi[5,4]  R1231     -1.9737021625041962e-01
    phi[5,4]  R1232     -5.7246887683868408e-01
    phi[5,4]  R1233     -3.7819674611091614e-01
    phi[5,4]  R1234     -2.1048197150230408e-01
    phi[5,4]  R1235     -7.4335479736328125e-01
    phi[5,4]  R1236     -1.0940319299697876e+00
    phi[5,4]  R1237     9.2054808139801025e-01
    phi[5,4]  R1238     1.7996376752853394e+00
    phi[5,4]  R1239     2.1969823837280273e+00
    phi[5,4]  R1240     3.0140171051025391e+00
    phi[5,4]  R1241     2.1068191528320312e+00
    phi[5,4]  R1242     3.2593665122985840e+00
    phi[5,4]  R1243     3.0053393840789795e+00
    phi[5,4]  R1244     3.5564930438995361e+00
    phi[5,4]  R1245     2.4449074268341064e+00
    phi[5,4]  R1246     2.9883198738098145e+00
    phi[5,4]  R1247     -4.0879030227661133e+00
    phi[5,4]  R1248     -3.2198550701141357e+00
    phi[5,4]  R1249     -3.3690595626831055e+00
    phi[5,4]  R1250     -4.1031789779663086e+00
    phi[5,4]  R1251     -1.9102838039398193e+00
    phi[5,4]  R1252     -1.4092475175857544e+00
    phi[5,4]  R1253     -1.1926051229238510e-01
    phi[5,4]  R1254     -2.9940478801727295e+00
    phi[5,4]  R1255     -1.5206407308578491e+00
    phi[5,4]  R1256     -0.145842045545578
    phi[5,4]  R1257     -1.7806247472763062e+00
    phi[5,4]  R1258     -1.3647599220275879e+00
    phi[5,4]  R1259     -2.8645715713500977e+00
    phi[5,4]  R1260     -2.8117299079895020e+00
    phi[5,4]  R1261     -1.9281855821609497e+00
    phi[5,4]  R1262     -3.2804775238037109e+00
    phi[5,4]  R1263     -1.5945694446563721e+00
    phi[5,4]  R1264     1.2965929508209229e+00
    phi[5,4]  R1265     -1.9109510183334351e+00
    phi[5,4]  R1266     -1.5469816923141479e+00
    phi[5,4]  R1267     -2.6647369861602783e+00
    phi[5,4]  R1268     -2.1193079948425293e+00
    phi[5,4]  R1269     -2.6023945808410645e+00
    phi[5,4]  R1270     -1.1140489578247070e+00
    phi[5,4]  R1271     -9.8448818922042847e-01
    phi[5,4]  R1272     -0.836376965045929
    phi[5,4]  R1273     -2.1451218128204346e+00
    phi[5,4]  R1274     -2.5312433242797852e+00
    phi[5,4]  R1275     -2.9531803131103516e+00
    phi[5,4]  R1276     -2.4701972007751465e+00
    phi[5,4]  R1277     -4.0981993675231934e+00
    phi[5,4]  R1278     -1.5266170501708984e+00
    phi[5,4]  R1279     -1.4208955764770508e+00
    phi[5,4]  R1280     -1.4423501491546631e+00
    phi[5,4]  R1281     -1.4685974121093750e+00
    phi[5,4]  R1282     -2.0717191696166992e+00
    phi[5,4]  R1283     -3.0820348262786865e+00
    phi[5,4]  R1284     -1.2993072271347046e+00
    phi[5,4]  R1285     -1.1897383928298950e+00
    phi[5,4]  R1286     -1.9165163040161133e+00
    phi[5,4]  R1287     -2.8225593566894531e+00
    phi[5,4]  R1288     -3.4229321479797363e+00
    phi[5,4]  R1289     -5.4135984182357788e-01
    phi[5,4]  R1290     -2.5577859878540039e+00
    phi[5,4]  R1291     -2.0503635406494141e+00
    phi[5,4]  R1292     -5.8280783891677856e-01
    phi[5,4]  R1293     4.3543326854705811e-01
    phi[5,4]  R1294     3.7018683552742004e-01
    phi[5,4]  R1295     1.3058933019638062e+00
    phi[5,4]  R1296     -1.9719191789627075e+00
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R54       -1
    phi[4,6]  R1297     -3.0999999046325684e+00
    phi[4,6]  R1298     -3.0999999046325684e+00
    phi[4,6]  R1299     -2.2400000095367432e+00
    phi[4,6]  R1300     -2.2400000095367432e+00
    phi[4,6]  R1301     -3.0999999046325684e+00
    phi[4,6]  R1302     -3.0999999046325684e+00
    phi[4,6]  R1303     -2.5699999332427979e+00
    phi[4,6]  R1304     -2.5699999332427979e+00
    phi[4,6]  R1305     -3.0999999046325684e+00
    phi[4,6]  R1306     -3.0999999046325684e+00
    phi[4,6]  R1307     -2.0899999141693115e+00
    phi[4,6]  R1308     -2.0899999141693115e+00
    phi[4,6]  R1309     -3.0999999046325684e+00
    phi[4,6]  R1310     -3.0999999046325684e+00
    phi[4,6]  R1311     9.2054808139801025e-01
    phi[4,6]  R1312     1.7996376752853394e+00
    phi[4,6]  R1313     2.1969823837280273e+00
    phi[4,6]  R1314     3.0140171051025391e+00
    phi[4,6]  R1315     2.1068191528320312e+00
    phi[4,6]  R1316     3.2593665122985840e+00
    phi[4,6]  R1317     3.0053393840789795e+00
    phi[4,6]  R1318     3.5564930438995361e+00
    phi[4,6]  R1319     2.4449074268341064e+00
    phi[4,6]  R1320     2.9883198738098145e+00
    phi[4,6]  R1321     -4.0879030227661133e+00
    phi[4,6]  R1322     -3.2198550701141357e+00
    phi[4,6]  R1323     -3.3690595626831055e+00
    phi[4,6]  R1324     -4.1031789779663086e+00
    phi[4,6]  R1325     -1.9102838039398193e+00
    phi[4,6]  R1326     -1.4092475175857544e+00
    phi[4,6]  R1327     -1.1926051229238510e-01
    phi[4,6]  R1328     -2.9940478801727295e+00
    phi[4,6]  R1329     -1.5206407308578491e+00
    phi[4,6]  R1330     -0.145842045545578
    phi[4,6]  R1331     -1.7806247472763062e+00
    phi[4,6]  R1332     -1.3647599220275879e+00
    phi[4,6]  R1333     -2.8645715713500977e+00
    phi[4,6]  R1334     -2.8117299079895020e+00
    phi[4,6]  R1335     -1.9281855821609497e+00
    phi[4,6]  R1336     -3.2804775238037109e+00
    phi[4,6]  R1337     -1.5945694446563721e+00
    phi[4,6]  R1338     1.2965929508209229e+00
    phi[4,6]  R1339     -1.9109510183334351e+00
    phi[4,6]  R1340     -1.5469816923141479e+00
    phi[4,6]  R1341     -2.6647369861602783e+00
    phi[4,6]  R1342     -2.1193079948425293e+00
    phi[4,6]  R1343     -2.6023945808410645e+00
    phi[4,6]  R1344     -1.1140489578247070e+00
    phi[4,6]  R1345     -9.8448818922042847e-01
    phi[4,6]  R1346     -0.836376965045929
    phi[4,6]  R1347     -2.1451218128204346e+00
    phi[4,6]  R1348     -2.5312433242797852e+00
    phi[4,6]  R1349     -2.9531803131103516e+00
    phi[4,6]  R1350     -2.4701972007751465e+00
    phi[4,6]  R1351     -4.0981993675231934e+00
    phi[4,6]  R1352     -1.5266170501708984e+00
    phi[4,6]  R1353     -1.4208955764770508e+00
    phi[4,6]  R1354     -1.4423501491546631e+00
    phi[4,6]  R1355     -1.4685974121093750e+00
    phi[4,6]  R1356     -2.0717191696166992e+00
    phi[4,6]  R1357     -3.0820348262786865e+00
    phi[4,6]  R1358     -1.2993072271347046e+00
    phi[4,6]  R1359     -1.1897383928298950e+00
    phi[4,6]  R1360     -1.9165163040161133e+00
    phi[4,6]  R1361     -2.8225593566894531e+00
    phi[4,6]  R1362     -3.4229321479797363e+00
    phi[4,6]  R1363     -5.4135984182357788e-01
    phi[4,6]  R1364     -2.5577859878540039e+00
    phi[4,6]  R1365     -2.0503635406494141e+00
    phi[4,6]  R1366     -5.8280783891677856e-01
    phi[4,6]  R1367     4.3543326854705811e-01
    phi[4,6]  R1368     3.7018683552742004e-01
    phi[4,6]  R1369     1.3058933019638062e+00
    phi[4,6]  R1370     -1.9719191789627075e+00
    phi[4,6]  R1371     2.3482451438903809e+00
    phi[4,6]  R1372     1.4043136835098267e+00
    phi[4,6]  R1373     1.6204274892807007e+00
    phi[4,6]  R1374     2.40729022026062
    phi[4,6]  R1375     2.7308070659637451e-01
    phi[4,6]  R1376     1.5040011405944824e+00
    phi[4,6]  R1377     1.2725017070770264e+00
    phi[4,6]  R1378     2.1638686656951904e+00
    phi[4,6]  R1379     1.0585379600524902e+00
    phi[4,6]  R1380     1.1041893959045410e+00
    phi[4,6]  R1381     -1.0644325017929077e+00
    phi[4,6]  R1382     -4.0935400128364563e-01
    phi[4,6]  R1383     -7.1816021203994751e-01
    phi[4,6]  R1384     -1.4572244882583618e+00
    phi[4,6]  R1385     -1.7214293479919434e+00
    phi[4,6]  R1386     -3.3850994110107422e+00
    phi[4,6]  R1387     -3.3823661804199219e+00
    phi[4,6]  R1388     -4.3609662055969238e+00
    phi[4,6]  R1389     -4.3556127548217773e+00
    phi[4,6]  R1390     -4.3246068954467773e+00
    phi[4,6]  R1391     -1.7675192654132843e-01
    phi[4,6]  R1392     -1.2751983404159546e+00
    phi[4,6]  R1393     1.4920660853385925e-01
    phi[4,6]  R1394     -1.6006368398666382e+00
    phi[4,6]  R1395     -3.6247920989990234e+00
    phi[4,6]  R1396     -2.7305805683135986e+00
    phi[4,6]  R1397     -2.3324098587036133e+00
    phi[4,6]  R1398     -2.7717916965484619e+00
    phi[4,6]  R1399     -3.8806486129760742e+00
    phi[4,6]  R1400     -3.3107373714447021e+00
    phi[4,6]  R1401     -5.1087492704391479e-01
    phi[4,6]  R1402     -3.1512591838836670e+00
    phi[4,6]  R1403     -3.8100645542144775e+00
    phi[4,6]  R1404     -2.7084243297576904e+00
    phi[4,6]  R1405     -2.7310636043548584e+00
    phi[4,6]  R1406     -3.1861634254455566e+00
    phi[4,6]  R1407     -2.3589973449707031e+00
    phi[4,6]  R1408     -1.7078990936279297e+00
    phi[4,6]  R1409     -1.2437846660614014e+00
    phi[4,6]  R1410     -1.3080034255981445e+00
    phi[6,4]  R36       -1
    phi[6,4]  R54       1
    phi[6,4]  R55       1
    phi[6,4]  R1411     -3.0999999046325684e+00
    phi[6,4]  R1412     -3.0999999046325684e+00
    phi[6,4]  R1413     -2.2400000095367432e+00
    phi[6,4]  R1414     -2.2400000095367432e+00
    phi[6,4]  R1415     -3.0999999046325684e+00
    phi[6,4]  R1416     -3.0999999046325684e+00
    phi[6,4]  R1417     -2.5699999332427979e+00
    phi[6,4]  R1418     -2.5699999332427979e+00
    phi[6,4]  R1419     -3.0999999046325684e+00
    phi[6,4]  R1420     -3.0999999046325684e+00
    phi[6,4]  R1421     -2.0899999141693115e+00
    phi[6,4]  R1422     -2.0899999141693115e+00
    phi[6,4]  R1423     -3.0999999046325684e+00
    phi[6,4]  R1424     -3.0999999046325684e+00
    phi[6,4]  R1425     2.3482451438903809e+00
    phi[6,4]  R1426     1.4043136835098267e+00
    phi[6,4]  R1427     1.6204274892807007e+00
    phi[6,4]  R1428     2.40729022026062
    phi[6,4]  R1429     2.7308070659637451e-01
    phi[6,4]  R1430     1.5040011405944824e+00
    phi[6,4]  R1431     1.2725017070770264e+00
    phi[6,4]  R1432     2.1638686656951904e+00
    phi[6,4]  R1433     1.0585379600524902e+00
    phi[6,4]  R1434     1.1041893959045410e+00
    phi[6,4]  R1435     -1.0644325017929077e+00
    phi[6,4]  R1436     -4.0935400128364563e-01
    phi[6,4]  R1437     -7.1816021203994751e-01
    phi[6,4]  R1438     -1.4572244882583618e+00
    phi[6,4]  R1439     -1.7214293479919434e+00
    phi[6,4]  R1440     -3.3850994110107422e+00
    phi[6,4]  R1441     -3.3823661804199219e+00
    phi[6,4]  R1442     -4.3609662055969238e+00
    phi[6,4]  R1443     -4.3556127548217773e+00
    phi[6,4]  R1444     -4.3246068954467773e+00
    phi[6,4]  R1445     -1.7675192654132843e-01
    phi[6,4]  R1446     -1.2751983404159546e+00
    phi[6,4]  R1447     1.4920660853385925e-01
    phi[6,4]  R1448     -1.6006368398666382e+00
    phi[6,4]  R1449     -3.6247920989990234e+00
    phi[6,4]  R1450     -2.7305805683135986e+00
    phi[6,4]  R1451     -2.3324098587036133e+00
    phi[6,4]  R1452     -2.7717916965484619e+00
    phi[6,4]  R1453     -3.8806486129760742e+00
    phi[6,4]  R1454     -3.3107373714447021e+00
    phi[6,4]  R1455     -5.1087492704391479e-01
    phi[6,4]  R1456     -3.1512591838836670e+00
    phi[6,4]  R1457     -3.8100645542144775e+00
    phi[6,4]  R1458     -2.7084243297576904e+00
    phi[6,4]  R1459     -2.7310636043548584e+00
    phi[6,4]  R1460     -3.1861634254455566e+00
    phi[6,4]  R1461     -2.3589973449707031e+00
    phi[6,4]  R1462     -1.7078990936279297e+00
    phi[6,4]  R1463     -1.2437846660614014e+00
    phi[6,4]  R1464     -1.3080034255981445e+00
    phi[6,4]  R1465     9.2054808139801025e-01
    phi[6,4]  R1466     1.7996376752853394e+00
    phi[6,4]  R1467     2.1969823837280273e+00
    phi[6,4]  R1468     3.0140171051025391e+00
    phi[6,4]  R1469     2.1068191528320312e+00
    phi[6,4]  R1470     3.2593665122985840e+00
    phi[6,4]  R1471     3.0053393840789795e+00
    phi[6,4]  R1472     3.5564930438995361e+00
    phi[6,4]  R1473     2.4449074268341064e+00
    phi[6,4]  R1474     2.9883198738098145e+00
    phi[6,4]  R1475     -4.0879030227661133e+00
    phi[6,4]  R1476     -3.2198550701141357e+00
    phi[6,4]  R1477     -3.3690595626831055e+00
    phi[6,4]  R1478     -4.1031789779663086e+00
    phi[6,4]  R1479     -1.9102838039398193e+00
    phi[6,4]  R1480     -1.4092475175857544e+00
    phi[6,4]  R1481     -1.1926051229238510e-01
    phi[6,4]  R1482     -2.9940478801727295e+00
    phi[6,4]  R1483     -1.5206407308578491e+00
    phi[6,4]  R1484     -0.145842045545578
    phi[6,4]  R1485     -1.7806247472763062e+00
    phi[6,4]  R1486     -1.3647599220275879e+00
    phi[6,4]  R1487     -2.8645715713500977e+00
    phi[6,4]  R1488     -2.8117299079895020e+00
    phi[6,4]  R1489     -1.9281855821609497e+00
    phi[6,4]  R1490     -3.2804775238037109e+00
    phi[6,4]  R1491     -1.5945694446563721e+00
    phi[6,4]  R1492     1.2965929508209229e+00
    phi[6,4]  R1493     -1.9109510183334351e+00
    phi[6,4]  R1494     -1.5469816923141479e+00
    phi[6,4]  R1495     -2.6647369861602783e+00
    phi[6,4]  R1496     -2.1193079948425293e+00
    phi[6,4]  R1497     -2.6023945808410645e+00
    phi[6,4]  R1498     -1.1140489578247070e+00
    phi[6,4]  R1499     -9.8448818922042847e-01
    phi[6,4]  R1500     -0.836376965045929
    phi[6,4]  R1501     -2.1451218128204346e+00
    phi[6,4]  R1502     -2.5312433242797852e+00
    phi[6,4]  R1503     -2.9531803131103516e+00
    phi[6,4]  R1504     -2.4701972007751465e+00
    phi[6,4]  R1505     -4.0981993675231934e+00
    phi[6,4]  R1506     -1.5266170501708984e+00
    phi[6,4]  R1507     -1.4208955764770508e+00
    phi[6,4]  R1508     -1.4423501491546631e+00
    phi[6,4]  R1509     -1.4685974121093750e+00
    phi[6,4]  R1510     -2.0717191696166992e+00
    phi[6,4]  R1511     -3.0820348262786865e+00
    phi[6,4]  R1512     -1.2993072271347046e+00
    phi[6,4]  R1513     -1.1897383928298950e+00
    phi[6,4]  R1514     -1.9165163040161133e+00
    phi[6,4]  R1515     -2.8225593566894531e+00
    phi[6,4]  R1516     -3.4229321479797363e+00
    phi[6,4]  R1517     -5.4135984182357788e-01
    phi[6,4]  R1518     -2.5577859878540039e+00
    phi[6,4]  R1519     -2.0503635406494141e+00
    phi[6,4]  R1520     -5.8280783891677856e-01
    phi[6,4]  R1521     4.3543326854705811e-01
    phi[6,4]  R1522     3.7018683552742004e-01
    phi[6,4]  R1523     1.3058933019638062e+00
    phi[6,4]  R1524     -1.9719191789627075e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1525     -3.0999999046325684e+00
    phi[5,6]  R1526     -3.0999999046325684e+00
    phi[5,6]  R1527     -2.2400000095367432e+00
    phi[5,6]  R1528     -2.2400000095367432e+00
    phi[5,6]  R1529     -3.0999999046325684e+00
    phi[5,6]  R1530     -3.0999999046325684e+00
    phi[5,6]  R1531     -2.5699999332427979e+00
    phi[5,6]  R1532     -2.5699999332427979e+00
    phi[5,6]  R1533     -3.0999999046325684e+00
    phi[5,6]  R1534     -3.0999999046325684e+00
    phi[5,6]  R1535     -2.0899999141693115e+00
    phi[5,6]  R1536     -2.0899999141693115e+00
    phi[5,6]  R1537     -3.0999999046325684e+00
    phi[5,6]  R1538     -3.0999999046325684e+00
    phi[5,6]  R1539     2.5924263000488281e+00
    phi[5,6]  R1540     3.53711199760437
    phi[5,6]  R1541     3.5394117832183838e+00
    phi[5,6]  R1542     2.3229961395263672e+00
    phi[5,6]  R1543     3.7350471019744873e+00
    phi[5,6]  R1544     1.4034076929092407e+00
    phi[5,6]  R1545     2.2403628826141357e+00
    phi[5,6]  R1546     -3.7710287570953369e+00
    phi[5,6]  R1547     -3.0185866355895996e+00
    phi[5,6]  R1548     -2.8269133567810059e+00
    phi[5,6]  R1549     -3.0845029354095459e+00
    phi[5,6]  R1550     -2.2722356319427490e+00
    phi[5,6]  R1551     -3.2840840816497803e+00
    phi[5,6]  R1552     -2.9367680549621582e+00
    phi[5,6]  R1553     -3.7130515575408936e+00
    phi[5,6]  R1554     -2.7352783679962158e+00
    phi[5,6]  R1555     -3.3380048274993896e+00
    phi[5,6]  R1556     -2.7803053855895996e+00
    phi[5,6]  R1557     -2.89789080619812
    phi[5,6]  R1558     -2.4679064750671387e+00
    phi[5,6]  R1559     -2.3828625679016113e+00
    phi[5,6]  R1560     -2.8927006721496582e+00
    phi[5,6]  R1561     -2.8146693706512451e+00
    phi[5,6]  R1562     -1.4980833530426025e+00
    phi[5,6]  R1563     -8.4656757116317749e-01
    phi[5,6]  R1564     -3.2655694484710693e+00
    phi[5,6]  R1565     -9.7715121507644653e-01
    phi[5,6]  R1566     -2.5440905094146729e+00
    phi[5,6]  R1567     -2.3269410133361816e+00
    phi[5,6]  R1568     -1.5756518840789795e+00
    phi[5,6]  R1569     -2.0531871318817139e+00
    phi[5,6]  R1570     -2.0736374855041504e+00
    phi[5,6]  R1571     -2.1756799221038818e+00
    phi[5,6]  R1572     -3.5616226196289062e+00
    phi[5,6]  R1573     -1.4555230140686035e+00
    phi[5,6]  R1574     -3.5308477878570557e+00
    phi[5,6]  R1575     -1.7929992675781250e+00
    phi[5,6]  R1576     -2.4907562732696533e+00
    phi[5,6]  R1577     -2.9425508975982666e+00
    phi[5,6]  R1578     -3.3254361152648926e+00
    phi[5,6]  R1579     -3.1573362350463867e+00
    phi[5,6]  R1580     -2.4346692562103271e+00
    phi[5,6]  R1581     -2.8587656021118164e+00
    phi[5,6]  R1582     -1.7089174985885620e+00
    phi[5,6]  R1583     -2.2405498027801514e+00
    phi[5,6]  R1584     -3.4521558284759521e+00
    phi[5,6]  R1585     -2.5426592826843262e+00
    phi[5,6]  R1586     -9.1153711080551147e-01
    phi[5,6]  R1587     -2.1234467029571533e+00
    phi[5,6]  R1588     -2.3582305908203125e+00
    phi[5,6]  R1589     -3.8900392055511475e+00
    phi[5,6]  R1590     -2.5010931491851807e+00
    phi[5,6]  R1591     -1.9737021625041962e-01
    phi[5,6]  R1592     -5.7246887683868408e-01
    phi[5,6]  R1593     -3.7819674611091614e-01
    phi[5,6]  R1594     -2.1048197150230408e-01
    phi[5,6]  R1595     -7.4335479736328125e-01
    phi[5,6]  R1596     -1.0940319299697876e+00
    phi[5,6]  R1597     2.3482451438903809e+00
    phi[5,6]  R1598     1.4043136835098267e+00
    phi[5,6]  R1599     1.6204274892807007e+00
    phi[5,6]  R1600     2.40729022026062
    phi[5,6]  R1601     2.7308070659637451e-01
    phi[5,6]  R1602     1.5040011405944824e+00
    phi[5,6]  R1603     1.2725017070770264e+00
    phi[5,6]  R1604     2.1638686656951904e+00
    phi[5,6]  R1605     1.0585379600524902e+00
    phi[5,6]  R1606     1.1041893959045410e+00
    phi[5,6]  R1607     -1.0644325017929077e+00
    phi[5,6]  R1608     -4.0935400128364563e-01
    phi[5,6]  R1609     -7.1816021203994751e-01
    phi[5,6]  R1610     -1.4572244882583618e+00
    phi[5,6]  R1611     -1.7214293479919434e+00
    phi[5,6]  R1612     -3.3850994110107422e+00
    phi[5,6]  R1613     -3.3823661804199219e+00
    phi[5,6]  R1614     -4.3609662055969238e+00
    phi[5,6]  R1615     -4.3556127548217773e+00
    phi[5,6]  R1616     -4.3246068954467773e+00
    phi[5,6]  R1617     -1.7675192654132843e-01
    phi[5,6]  R1618     -1.2751983404159546e+00
    phi[5,6]  R1619     1.4920660853385925e-01
    phi[5,6]  R1620     -1.6006368398666382e+00
    phi[5,6]  R1621     -3.6247920989990234e+00
    phi[5,6]  R1622     -2.7305805683135986e+00
    phi[5,6]  R1623     -2.3324098587036133e+00
    phi[5,6]  R1624     -2.7717916965484619e+00
    phi[5,6]  R1625     -3.8806486129760742e+00
    phi[5,6]  R1626     -3.3107373714447021e+00
    phi[5,6]  R1627     -5.1087492704391479e-01
    phi[5,6]  R1628     -3.1512591838836670e+00
    phi[5,6]  R1629     -3.8100645542144775e+00
    phi[5,6]  R1630     -2.7084243297576904e+00
    phi[5,6]  R1631     -2.7310636043548584e+00
    phi[5,6]  R1632     -3.1861634254455566e+00
    phi[5,6]  R1633     -2.3589973449707031e+00
    phi[5,6]  R1634     -1.7078990936279297e+00
    phi[5,6]  R1635     -1.2437846660614014e+00
    phi[5,6]  R1636     -1.3080034255981445e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1637     -3.0999999046325684e+00
    phi[6,5]  R1638     -3.0999999046325684e+00
    phi[6,5]  R1639     -2.2400000095367432e+00
    phi[6,5]  R1640     -2.2400000095367432e+00
    phi[6,5]  R1641     -3.0999999046325684e+00
    phi[6,5]  R1642     -3.0999999046325684e+00
    phi[6,5]  R1643     -2.5699999332427979e+00
    phi[6,5]  R1644     -2.5699999332427979e+00
    phi[6,5]  R1645     -3.0999999046325684e+00
    phi[6,5]  R1646     -3.0999999046325684e+00
    phi[6,5]  R1647     -2.0899999141693115e+00
    phi[6,5]  R1648     -2.0899999141693115e+00
    phi[6,5]  R1649     -3.0999999046325684e+00
    phi[6,5]  R1650     -3.0999999046325684e+00
    phi[6,5]  R1651     2.3482451438903809e+00
    phi[6,5]  R1652     1.4043136835098267e+00
    phi[6,5]  R1653     1.6204274892807007e+00
    phi[6,5]  R1654     2.40729022026062
    phi[6,5]  R1655     2.7308070659637451e-01
    phi[6,5]  R1656     1.5040011405944824e+00
    phi[6,5]  R1657     1.2725017070770264e+00
    phi[6,5]  R1658     2.1638686656951904e+00
    phi[6,5]  R1659     1.0585379600524902e+00
    phi[6,5]  R1660     1.1041893959045410e+00
    phi[6,5]  R1661     -1.0644325017929077e+00
    phi[6,5]  R1662     -4.0935400128364563e-01
    phi[6,5]  R1663     -7.1816021203994751e-01
    phi[6,5]  R1664     -1.4572244882583618e+00
    phi[6,5]  R1665     -1.7214293479919434e+00
    phi[6,5]  R1666     -3.3850994110107422e+00
    phi[6,5]  R1667     -3.3823661804199219e+00
    phi[6,5]  R1668     -4.3609662055969238e+00
    phi[6,5]  R1669     -4.3556127548217773e+00
    phi[6,5]  R1670     -4.3246068954467773e+00
    phi[6,5]  R1671     -1.7675192654132843e-01
    phi[6,5]  R1672     -1.2751983404159546e+00
    phi[6,5]  R1673     1.4920660853385925e-01
    phi[6,5]  R1674     -1.6006368398666382e+00
    phi[6,5]  R1675     -3.6247920989990234e+00
    phi[6,5]  R1676     -2.7305805683135986e+00
    phi[6,5]  R1677     -2.3324098587036133e+00
    phi[6,5]  R1678     -2.7717916965484619e+00
    phi[6,5]  R1679     -3.8806486129760742e+00
    phi[6,5]  R1680     -3.3107373714447021e+00
    phi[6,5]  R1681     -5.1087492704391479e-01
    phi[6,5]  R1682     -3.1512591838836670e+00
    phi[6,5]  R1683     -3.8100645542144775e+00
    phi[6,5]  R1684     -2.7084243297576904e+00
    phi[6,5]  R1685     -2.7310636043548584e+00
    phi[6,5]  R1686     -3.1861634254455566e+00
    phi[6,5]  R1687     -2.3589973449707031e+00
    phi[6,5]  R1688     -1.7078990936279297e+00
    phi[6,5]  R1689     -1.2437846660614014e+00
    phi[6,5]  R1690     -1.3080034255981445e+00
    phi[6,5]  R1691     2.5924263000488281e+00
    phi[6,5]  R1692     3.53711199760437
    phi[6,5]  R1693     3.5394117832183838e+00
    phi[6,5]  R1694     2.3229961395263672e+00
    phi[6,5]  R1695     3.7350471019744873e+00
    phi[6,5]  R1696     1.4034076929092407e+00
    phi[6,5]  R1697     2.2403628826141357e+00
    phi[6,5]  R1698     -3.7710287570953369e+00
    phi[6,5]  R1699     -3.0185866355895996e+00
    phi[6,5]  R1700     -2.8269133567810059e+00
    phi[6,5]  R1701     -3.0845029354095459e+00
    phi[6,5]  R1702     -2.2722356319427490e+00
    phi[6,5]  R1703     -3.2840840816497803e+00
    phi[6,5]  R1704     -2.9367680549621582e+00
    phi[6,5]  R1705     -3.7130515575408936e+00
    phi[6,5]  R1706     -2.7352783679962158e+00
    phi[6,5]  R1707     -3.3380048274993896e+00
    phi[6,5]  R1708     -2.7803053855895996e+00
    phi[6,5]  R1709     -2.89789080619812
    phi[6,5]  R1710     -2.4679064750671387e+00
    phi[6,5]  R1711     -2.3828625679016113e+00
    phi[6,5]  R1712     -2.8927006721496582e+00
    phi[6,5]  R1713     -2.8146693706512451e+00
    phi[6,5]  R1714     -1.4980833530426025e+00
    phi[6,5]  R1715     -8.4656757116317749e-01
    phi[6,5]  R1716     -3.2655694484710693e+00
    phi[6,5]  R1717     -9.7715121507644653e-01
    phi[6,5]  R1718     -2.5440905094146729e+00
    phi[6,5]  R1719     -2.3269410133361816e+00
    phi[6,5]  R1720     -1.5756518840789795e+00
    phi[6,5]  R1721     -2.0531871318817139e+00
    phi[6,5]  R1722     -2.0736374855041504e+00
    phi[6,5]  R1723     -2.1756799221038818e+00
    phi[6,5]  R1724     -3.5616226196289062e+00
    phi[6,5]  R1725     -1.4555230140686035e+00
    phi[6,5]  R1726     -3.5308477878570557e+00
    phi[6,5]  R1727     -1.7929992675781250e+00
    phi[6,5]  R1728     -2.4907562732696533e+00
    phi[6,5]  R1729     -2.9425508975982666e+00
    phi[6,5]  R1730     -3.3254361152648926e+00
    phi[6,5]  R1731     -3.1573362350463867e+00
    phi[6,5]  R1732     -2.4346692562103271e+00
    phi[6,5]  R1733     -2.8587656021118164e+00
    phi[6,5]  R1734     -1.7089174985885620e+00
    phi[6,5]  R1735     -2.2405498027801514e+00
    phi[6,5]  R1736     -3.4521558284759521e+00
    phi[6,5]  R1737     -2.5426592826843262e+00
    phi[6,5]  R1738     -9.1153711080551147e-01
    phi[6,5]  R1739     -2.1234467029571533e+00
    phi[6,5]  R1740     -2.3582305908203125e+00
    phi[6,5]  R1741     -3.8900392055511475e+00
    phi[6,5]  R1742     -2.5010931491851807e+00
    phi[6,5]  R1743     -1.9737021625041962e-01
    phi[6,5]  R1744     -5.7246887683868408e-01
    phi[6,5]  R1745     -3.7819674611091614e-01
    phi[6,5]  R1746     -2.1048197150230408e-01
    phi[6,5]  R1747     -7.4335479736328125e-01
    phi[6,5]  R1748     -1.0940319299697876e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R1749     -3.0999999046325684e+00
    phi[6,7]  R1750     -3.0999999046325684e+00
    phi[6,7]  R1751     -2.2400000095367432e+00
    phi[6,7]  R1752     -2.2400000095367432e+00
    phi[6,7]  R1753     -3.0999999046325684e+00
    phi[6,7]  R1754     -3.0999999046325684e+00
    phi[6,7]  R1755     -2.5699999332427979e+00
    phi[6,7]  R1756     -2.5699999332427979e+00
    phi[6,7]  R1757     -3.0999999046325684e+00
    phi[6,7]  R1758     -3.0999999046325684e+00
    phi[6,7]  R1759     -2.0899999141693115e+00
    phi[6,7]  R1760     -2.0899999141693115e+00
    phi[6,7]  R1761     -3.0999999046325684e+00
    phi[6,7]  R1762     -3.0999999046325684e+00
    phi[6,7]  R1763     2.3482451438903809e+00
    phi[6,7]  R1764     1.4043136835098267e+00
    phi[6,7]  R1765     1.6204274892807007e+00
    phi[6,7]  R1766     2.40729022026062
    phi[6,7]  R1767     2.7308070659637451e-01
    phi[6,7]  R1768     1.5040011405944824e+00
    phi[6,7]  R1769     1.2725017070770264e+00
    phi[6,7]  R1770     2.1638686656951904e+00
    phi[6,7]  R1771     1.0585379600524902e+00
    phi[6,7]  R1772     1.1041893959045410e+00
    phi[6,7]  R1773     -1.0644325017929077e+00
    phi[6,7]  R1774     -4.0935400128364563e-01
    phi[6,7]  R1775     -7.1816021203994751e-01
    phi[6,7]  R1776     -1.4572244882583618e+00
    phi[6,7]  R1777     -1.7214293479919434e+00
    phi[6,7]  R1778     -3.3850994110107422e+00
    phi[6,7]  R1779     -3.3823661804199219e+00
    phi[6,7]  R1780     -4.3609662055969238e+00
    phi[6,7]  R1781     -4.3556127548217773e+00
    phi[6,7]  R1782     -4.3246068954467773e+00
    phi[6,7]  R1783     -1.7675192654132843e-01
    phi[6,7]  R1784     -1.2751983404159546e+00
    phi[6,7]  R1785     1.4920660853385925e-01
    phi[6,7]  R1786     -1.6006368398666382e+00
    phi[6,7]  R1787     -3.6247920989990234e+00
    phi[6,7]  R1788     -2.7305805683135986e+00
    phi[6,7]  R1789     -2.3324098587036133e+00
    phi[6,7]  R1790     -2.7717916965484619e+00
    phi[6,7]  R1791     -3.8806486129760742e+00
    phi[6,7]  R1792     -3.3107373714447021e+00
    phi[6,7]  R1793     -5.1087492704391479e-01
    phi[6,7]  R1794     -3.1512591838836670e+00
    phi[6,7]  R1795     -3.8100645542144775e+00
    phi[6,7]  R1796     -2.7084243297576904e+00
    phi[6,7]  R1797     -2.7310636043548584e+00
    phi[6,7]  R1798     -3.1861634254455566e+00
    phi[6,7]  R1799     -2.3589973449707031e+00
    phi[6,7]  R1800     -1.7078990936279297e+00
    phi[6,7]  R1801     -1.2437846660614014e+00
    phi[6,7]  R1802     -1.3080034255981445e+00
    phi[6,7]  R1803     1.30873441696167
    phi[6,7]  R1804     2.1674954891204834e+00
    phi[6,7]  R1805     2.2435932159423828e+00
    phi[6,7]  R1806     6.3852876424789429e-01
    phi[6,7]  R1807     2.4429073333740234e+00
    phi[6,7]  R1808     1.7976462841033936e+00
    phi[6,7]  R1809     2.3629453182220459e+00
    phi[6,7]  R1810     -4.2005845904350281e-01
    phi[6,7]  R1811     -9.9957358837127686e-01
    phi[6,7]  R1812     -1.0416980981826782e+00
    phi[6,7]  R1813     -1.1007224321365356e+00
    phi[6,7]  R1814     -2.7139782905578613e-01
    phi[6,7]  R1815     -0.248402938246727
    phi[6,7]  R1816     -2.77126145362854
    phi[6,7]  R1817     6.5287381410598755e-01
    phi[6,7]  R1818     -5.9839963912963867e-01
    phi[6,7]  R1819     -4.0495882034301758e+00
    phi[6,7]  R1820     -2.1493856906890869e+00
    phi[6,7]  R1821     -9.1510856151580811e-01
    phi[6,7]  R1822     -1.6581090688705444e+00
    phi[6,7]  R1823     -1.8923177719116211e+00
    phi[6,7]  R1824     -1.8867106437683105e+00
    phi[6,7]  R1825     -9.5226854085922241e-01
    phi[6,7]  R1826     -1.3552495241165161e+00
    phi[6,7]  R1827     -3.1631534099578857e+00
    phi[6,7]  R1828     -3.1379821300506592e+00
    phi[6,7]  R1829     -0.0681607723236084
    phi[6,7]  R1830     -2.4373135566711426e+00
    phi[6,7]  R1831     -1.0394971370697021e+00
    phi[6,7]  R1832     -2.4538593292236328e+00
    phi[6,7]  R1833     -2.9986782073974609e+00
    phi[6,7]  R1834     -1.2305874824523926e+00
    phi[6,7]  R1835     -2.9383578300476074e+00
    phi[6,7]  R1836     -1.12994384765625
    phi[6,7]  R1837     3.4514978528022766e-01
    phi[6,7]  R1838     -1.2103297710418701e+00
    phi[6,7]  R1839     -1.8347837924957275e+00
    phi[6,7]  R1840     2.6759034395217896e-01
    phi[6,7]  R1841     -1.0695850849151611e+00
    phi[6,7]  R1842     -1.8820487260818481e+00
    phi[6,7]  R1843     -2.4636950492858887e+00
    phi[6,7]  R1844     -1.9586681127548218e+00
    phi[6,7]  R1845     -5.2575182914733887e-01
    phi[6,7]  R1846     -1.6402151584625244e+00
    phi[6,7]  R1847     -1.3304462432861328e+00
    phi[6,7]  R1848     -1.7752645015716553e+00
    phi[6,7]  R1849     -2.2528967857360840e+00
    phi[6,7]  R1850     -2.3160309791564941e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R1851     -3.0999999046325684e+00
    phi[7,6]  R1852     -3.0999999046325684e+00
    phi[7,6]  R1853     -2.2400000095367432e+00
    phi[7,6]  R1854     -2.2400000095367432e+00
    phi[7,6]  R1855     -3.0999999046325684e+00
    phi[7,6]  R1856     -3.0999999046325684e+00
    phi[7,6]  R1857     -2.5699999332427979e+00
    phi[7,6]  R1858     -2.5699999332427979e+00
    phi[7,6]  R1859     -3.0999999046325684e+00
    phi[7,6]  R1860     -3.0999999046325684e+00
    phi[7,6]  R1861     -2.0899999141693115e+00
    phi[7,6]  R1862     -2.0899999141693115e+00
    phi[7,6]  R1863     -3.0999999046325684e+00
    phi[7,6]  R1864     -3.0999999046325684e+00
    phi[7,6]  R1865     1.30873441696167
    phi[7,6]  R1866     2.1674954891204834e+00
    phi[7,6]  R1867     2.2435932159423828e+00
    phi[7,6]  R1868     6.3852876424789429e-01
    phi[7,6]  R1869     2.4429073333740234e+00
    phi[7,6]  R1870     1.7976462841033936e+00
    phi[7,6]  R1871     2.3629453182220459e+00
    phi[7,6]  R1872     -4.2005845904350281e-01
    phi[7,6]  R1873     -9.9957358837127686e-01
    phi[7,6]  R1874     -1.0416980981826782e+00
    phi[7,6]  R1875     -1.1007224321365356e+00
    phi[7,6]  R1876     -2.7139782905578613e-01
    phi[7,6]  R1877     -0.248402938246727
    phi[7,6]  R1878     -2.77126145362854
    phi[7,6]  R1879     6.5287381410598755e-01
    phi[7,6]  R1880     -5.9839963912963867e-01
    phi[7,6]  R1881     -4.0495882034301758e+00
    phi[7,6]  R1882     -2.1493856906890869e+00
    phi[7,6]  R1883     -9.1510856151580811e-01
    phi[7,6]  R1884     -1.6581090688705444e+00
    phi[7,6]  R1885     -1.8923177719116211e+00
    phi[7,6]  R1886     -1.8867106437683105e+00
    phi[7,6]  R1887     -9.5226854085922241e-01
    phi[7,6]  R1888     -1.3552495241165161e+00
    phi[7,6]  R1889     -3.1631534099578857e+00
    phi[7,6]  R1890     -3.1379821300506592e+00
    phi[7,6]  R1891     -0.0681607723236084
    phi[7,6]  R1892     -2.4373135566711426e+00
    phi[7,6]  R1893     -1.0394971370697021e+00
    phi[7,6]  R1894     -2.4538593292236328e+00
    phi[7,6]  R1895     -2.9986782073974609e+00
    phi[7,6]  R1896     -1.2305874824523926e+00
    phi[7,6]  R1897     -2.9383578300476074e+00
    phi[7,6]  R1898     -1.12994384765625
    phi[7,6]  R1899     3.4514978528022766e-01
    phi[7,6]  R1900     -1.2103297710418701e+00
    phi[7,6]  R1901     -1.8347837924957275e+00
    phi[7,6]  R1902     2.6759034395217896e-01
    phi[7,6]  R1903     -1.0695850849151611e+00
    phi[7,6]  R1904     -1.8820487260818481e+00
    phi[7,6]  R1905     -2.4636950492858887e+00
    phi[7,6]  R1906     -1.9586681127548218e+00
    phi[7,6]  R1907     -5.2575182914733887e-01
    phi[7,6]  R1908     -1.6402151584625244e+00
    phi[7,6]  R1909     -1.3304462432861328e+00
    phi[7,6]  R1910     -1.7752645015716553e+00
    phi[7,6]  R1911     -2.2528967857360840e+00
    phi[7,6]  R1912     -2.3160309791564941e+00
    phi[7,6]  R1913     2.3482451438903809e+00
    phi[7,6]  R1914     1.4043136835098267e+00
    phi[7,6]  R1915     1.6204274892807007e+00
    phi[7,6]  R1916     2.40729022026062
    phi[7,6]  R1917     2.7308070659637451e-01
    phi[7,6]  R1918     1.5040011405944824e+00
    phi[7,6]  R1919     1.2725017070770264e+00
    phi[7,6]  R1920     2.1638686656951904e+00
    phi[7,6]  R1921     1.0585379600524902e+00
    phi[7,6]  R1922     1.1041893959045410e+00
    phi[7,6]  R1923     -1.0644325017929077e+00
    phi[7,6]  R1924     -4.0935400128364563e-01
    phi[7,6]  R1925     -7.1816021203994751e-01
    phi[7,6]  R1926     -1.4572244882583618e+00
    phi[7,6]  R1927     -1.7214293479919434e+00
    phi[7,6]  R1928     -3.3850994110107422e+00
    phi[7,6]  R1929     -3.3823661804199219e+00
    phi[7,6]  R1930     -4.3609662055969238e+00
    phi[7,6]  R1931     -4.3556127548217773e+00
    phi[7,6]  R1932     -4.3246068954467773e+00
    phi[7,6]  R1933     -1.7675192654132843e-01
    phi[7,6]  R1934     -1.2751983404159546e+00
    phi[7,6]  R1935     1.4920660853385925e-01
    phi[7,6]  R1936     -1.6006368398666382e+00
    phi[7,6]  R1937     -3.6247920989990234e+00
    phi[7,6]  R1938     -2.7305805683135986e+00
    phi[7,6]  R1939     -2.3324098587036133e+00
    phi[7,6]  R1940     -2.7717916965484619e+00
    phi[7,6]  R1941     -3.8806486129760742e+00
    phi[7,6]  R1942     -3.3107373714447021e+00
    phi[7,6]  R1943     -5.1087492704391479e-01
    phi[7,6]  R1944     -3.1512591838836670e+00
    phi[7,6]  R1945     -3.8100645542144775e+00
    phi[7,6]  R1946     -2.7084243297576904e+00
    phi[7,6]  R1947     -2.7310636043548584e+00
    phi[7,6]  R1948     -3.1861634254455566e+00
    phi[7,6]  R1949     -2.3589973449707031e+00
    phi[7,6]  R1950     -1.7078990936279297e+00
    phi[7,6]  R1951     -1.2437846660614014e+00
    phi[7,6]  R1952     -1.3080034255981445e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R1953     -3.0999999046325684e+00
    phi[7,8]  R1954     -3.0999999046325684e+00
    phi[7,8]  R1955     -2.2400000095367432e+00
    phi[7,8]  R1956     -2.2400000095367432e+00
    phi[7,8]  R1957     -3.0999999046325684e+00
    phi[7,8]  R1958     -3.0999999046325684e+00
    phi[7,8]  R1959     -2.5699999332427979e+00
    phi[7,8]  R1960     -2.5699999332427979e+00
    phi[7,8]  R1961     -3.0999999046325684e+00
    phi[7,8]  R1962     -3.0999999046325684e+00
    phi[7,8]  R1963     -2.0899999141693115e+00
    phi[7,8]  R1964     -2.0899999141693115e+00
    phi[7,8]  R1965     -3.0999999046325684e+00
    phi[7,8]  R1966     -3.0999999046325684e+00
    phi[7,8]  R1967     1.30873441696167
    phi[7,8]  R1968     2.1674954891204834e+00
    phi[7,8]  R1969     2.2435932159423828e+00
    phi[7,8]  R1970     6.3852876424789429e-01
    phi[7,8]  R1971     2.4429073333740234e+00
    phi[7,8]  R1972     1.7976462841033936e+00
    phi[7,8]  R1973     2.3629453182220459e+00
    phi[7,8]  R1974     -4.2005845904350281e-01
    phi[7,8]  R1975     -9.9957358837127686e-01
    phi[7,8]  R1976     -1.0416980981826782e+00
    phi[7,8]  R1977     -1.1007224321365356e+00
    phi[7,8]  R1978     -2.7139782905578613e-01
    phi[7,8]  R1979     -0.248402938246727
    phi[7,8]  R1980     -2.77126145362854
    phi[7,8]  R1981     6.5287381410598755e-01
    phi[7,8]  R1982     -5.9839963912963867e-01
    phi[7,8]  R1983     -4.0495882034301758e+00
    phi[7,8]  R1984     -2.1493856906890869e+00
    phi[7,8]  R1985     -9.1510856151580811e-01
    phi[7,8]  R1986     -1.6581090688705444e+00
    phi[7,8]  R1987     -1.8923177719116211e+00
    phi[7,8]  R1988     -1.8867106437683105e+00
    phi[7,8]  R1989     -9.5226854085922241e-01
    phi[7,8]  R1990     -1.3552495241165161e+00
    phi[7,8]  R1991     -3.1631534099578857e+00
    phi[7,8]  R1992     -3.1379821300506592e+00
    phi[7,8]  R1993     -0.0681607723236084
    phi[7,8]  R1994     -2.4373135566711426e+00
    phi[7,8]  R1995     -1.0394971370697021e+00
    phi[7,8]  R1996     -2.4538593292236328e+00
    phi[7,8]  R1997     -2.9986782073974609e+00
    phi[7,8]  R1998     -1.2305874824523926e+00
    phi[7,8]  R1999     -2.9383578300476074e+00
    phi[7,8]  R2000     -1.12994384765625
    phi[7,8]  R2001     3.4514978528022766e-01
    phi[7,8]  R2002     -1.2103297710418701e+00
    phi[7,8]  R2003     -1.8347837924957275e+00
    phi[7,8]  R2004     2.6759034395217896e-01
    phi[7,8]  R2005     -1.0695850849151611e+00
    phi[7,8]  R2006     -1.8820487260818481e+00
    phi[7,8]  R2007     -2.4636950492858887e+00
    phi[7,8]  R2008     -1.9586681127548218e+00
    phi[7,8]  R2009     -5.2575182914733887e-01
    phi[7,8]  R2010     -1.6402151584625244e+00
    phi[7,8]  R2011     -1.3304462432861328e+00
    phi[7,8]  R2012     -1.7752645015716553e+00
    phi[7,8]  R2013     -2.2528967857360840e+00
    phi[7,8]  R2014     -2.3160309791564941e+00
    phi[7,8]  R2015     1.8194463253021240e+00
    phi[7,8]  R2016     2.3464875221252441e+00
    phi[7,8]  R2017     2.4024524688720703e+00
    phi[7,8]  R2018     1.9131171703338623e+00
    phi[7,8]  R2019     -2.6979517936706543e-01
    phi[7,8]  R2020     1.3153798580169678e+00
    phi[7,8]  R2021     1.2545664310455322e+00
    phi[7,8]  R2022     1.8561602830886841e+00
    phi[7,8]  R2023     -1.3000187277793884e-01
    phi[7,8]  R2024     1.3591071367263794e+00
    phi[7,8]  R2025     -0.797804057598114
    phi[7,8]  R2026     -1.1115605831146240e+00
    phi[7,8]  R2027     -1.5792071819305420e+00
    phi[7,8]  R2028     -2.3191905021667480e+00
    phi[7,8]  R2029     -4.7756183147430420e-01
    phi[7,8]  R2030     -1.6135271787643433e+00
    phi[7,8]  R2031     -8.4304350614547729e-01
    phi[7,8]  R2032     -1.1712057590484619e+00
    phi[7,8]  R2033     -1.3981798887252808e+00
    phi[7,8]  R2034     1.0792983770370483e+00
    phi[7,8]  R2035     -2.2794516086578369e+00
    phi[7,8]  R2036     -4.8972970247268677e-01
    phi[7,8]  R2037     -3.4085097312927246e+00
    phi[7,8]  R2038     -1.5308282375335693e+00
    phi[7,8]  R2039     1.2647722661495209e-01
    phi[7,8]  R2040     -6.1384302377700806e-01
    phi[7,8]  R2041     -1.0156574249267578e+00
    phi[7,8]  R2042     -2.0959854125976562e+00
    phi[7,8]  R2043     -7.5780749320983887e-01
    phi[7,8]  R2044     -2.5088782310485840e+00
    phi[7,8]  R2045     -5.7222402095794678e-01
    phi[7,8]  R2046     -1.1724900007247925e+00
    phi[7,8]  R2047     -0.642256498336792
    phi[7,8]  R2048     2.4172613620758057e+00
    phi[7,8]  R2049     -1.7524341344833374e+00
    phi[7,8]  R2050     3.6453530192375183e-02
    phi[7,8]  R2051     1.1403180360794067e+00
    phi[7,8]  R2052     -5.6825983524322510e-01
    phi[7,8]  R2053     3.9852076768875122e-01
    phi[7,8]  R2054     4.7192716598510742e-01
    phi[7,8]  R2055     -7.5772687792778015e-02
    phi[7,8]  R2056     -2.9479568004608154e+00
    phi[7,8]  R2057     -1.8583763837814331e+00
    phi[7,8]  R2058     -1.3927371501922607e+00
    phi[7,8]  R2059     2.8539028763771057e-01
    phi[7,8]  R2060     -3.2760732173919678e+00
    phi[7,8]  R2061     -2.88881778717041
    phi[7,8]  R2062     -9.3547904491424561e-01
    phi[7,8]  R2063     -1.5049989223480225e+00
    phi[7,8]  R2064     -2.5927419662475586e+00
    phi[7,8]  R2065     1.36786687374115
    phi[7,8]  R2066     1.0025986433029175e+00
    phi[7,8]  R2067     -2.1903121471405029e-01
    phi[7,8]  R2068     -3.0077648162841797e+00
    phi[7,8]  R2069     -2.2931506633758545e+00
    phi[7,8]  R2070     -1.2664984464645386e+00
    phi[7,8]  R2071     -2.6125891208648682e+00
    phi[7,8]  R2072     1.5658297538757324e+00
    phi[7,8]  R2073     -1.5994573831558228e+00
    phi[7,8]  R2074     -1.1056776046752930e+00
    phi[7,8]  R2075     -8.3404910564422607e-01
    phi[7,8]  R2076     -1.6999678611755371e+00
    phi[7,8]  R2077     1.9655048847198486e-01
    phi[7,8]  R2078     -6.8468920886516571e-02
    phi[7,8]  R2079     8.8446170091629028e-01
    phi[7,8]  R2080     1.2777494192123413e+00
    phi[7,8]  R2081     -5.2626854181289673e-01
    phi[7,8]  R2082     3.5290271043777466e-02
    phi[7,8]  R2083     -8.8477671146392822e-01
    phi[7,8]  R2084     0.415833055973053
    phi[7,8]  R2085     -5.5925470590591431e-01
    phi[7,8]  R2086     -9.9557948112487793e-01
    phi[7,8]  R2087     -6.9177395105361938e-01
    phi[7,8]  R2088     2.9634061455726624e-01
    phi[7,8]  R2089     -3.3496510982513428e-01
    phi[7,8]  R2090     5.7126826047897339e-01
    phi[7,8]  R2091     -3.5101320743560791e+00
    phi[7,8]  R2092     -0.83254474401474
    phi[7,8]  R2093     0.740243136882782
    phi[7,8]  R2094     1.5165263414382935e+00
    phi[7,8]  R2095     -3.3397226333618164e+00
    phi[7,8]  R2096     9.8630148172378540e-01
    phi[7,8]  R2097     1.2914324998855591e+00
    phi[7,8]  R2098     -1.6614911556243896e+00
    phi[7,8]  R2099     6.7956089973449707e-01
    phi[7,8]  R2100     1.3722839355468750e+00
    phi[7,8]  R2101     1.1461105346679688e+00
    phi[7,8]  R2102     5.6339547038078308e-02
    phi[7,8]  R2103     -3.6612565517425537e+00
    phi[7,8]  R2104     -2.9391636848449707e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2105     -3.0999999046325684e+00
    phi[8,7]  R2106     -3.0999999046325684e+00
    phi[8,7]  R2107     -2.2400000095367432e+00
    phi[8,7]  R2108     -2.2400000095367432e+00
    phi[8,7]  R2109     -3.0999999046325684e+00
    phi[8,7]  R2110     -3.0999999046325684e+00
    phi[8,7]  R2111     -2.5699999332427979e+00
    phi[8,7]  R2112     -2.5699999332427979e+00
    phi[8,7]  R2113     -3.0999999046325684e+00
    phi[8,7]  R2114     -3.0999999046325684e+00
    phi[8,7]  R2115     -2.0899999141693115e+00
    phi[8,7]  R2116     -2.0899999141693115e+00
    phi[8,7]  R2117     -3.0999999046325684e+00
    phi[8,7]  R2118     -3.0999999046325684e+00
    phi[8,7]  R2119     1.8194463253021240e+00
    phi[8,7]  R2120     2.3464875221252441e+00
    phi[8,7]  R2121     2.4024524688720703e+00
    phi[8,7]  R2122     1.9131171703338623e+00
    phi[8,7]  R2123     -2.6979517936706543e-01
    phi[8,7]  R2124     1.3153798580169678e+00
    phi[8,7]  R2125     1.2545664310455322e+00
    phi[8,7]  R2126     1.8561602830886841e+00
    phi[8,7]  R2127     -1.3000187277793884e-01
    phi[8,7]  R2128     1.3591071367263794e+00
    phi[8,7]  R2129     -0.797804057598114
    phi[8,7]  R2130     -1.1115605831146240e+00
    phi[8,7]  R2131     -1.5792071819305420e+00
    phi[8,7]  R2132     -2.3191905021667480e+00
    phi[8,7]  R2133     -4.7756183147430420e-01
    phi[8,7]  R2134     -1.6135271787643433e+00
    phi[8,7]  R2135     -8.4304350614547729e-01
    phi[8,7]  R2136     -1.1712057590484619e+00
    phi[8,7]  R2137     -1.3981798887252808e+00
    phi[8,7]  R2138     1.0792983770370483e+00
    phi[8,7]  R2139     -2.2794516086578369e+00
    phi[8,7]  R2140     -4.8972970247268677e-01
    phi[8,7]  R2141     -3.4085097312927246e+00
    phi[8,7]  R2142     -1.5308282375335693e+00
    phi[8,7]  R2143     1.2647722661495209e-01
    phi[8,7]  R2144     -6.1384302377700806e-01
    phi[8,7]  R2145     -1.0156574249267578e+00
    phi[8,7]  R2146     -2.0959854125976562e+00
    phi[8,7]  R2147     -7.5780749320983887e-01
    phi[8,7]  R2148     -2.5088782310485840e+00
    phi[8,7]  R2149     -5.7222402095794678e-01
    phi[8,7]  R2150     -1.1724900007247925e+00
    phi[8,7]  R2151     -0.642256498336792
    phi[8,7]  R2152     2.4172613620758057e+00
    phi[8,7]  R2153     -1.7524341344833374e+00
    phi[8,7]  R2154     3.6453530192375183e-02
    phi[8,7]  R2155     1.1403180360794067e+00
    phi[8,7]  R2156     -5.6825983524322510e-01
    phi[8,7]  R2157     3.9852076768875122e-01
    phi[8,7]  R2158     4.7192716598510742e-01
    phi[8,7]  R2159     -7.5772687792778015e-02
    phi[8,7]  R2160     -2.9479568004608154e+00
    phi[8,7]  R2161     -1.8583763837814331e+00
    phi[8,7]  R2162     -1.3927371501922607e+00
    phi[8,7]  R2163     2.8539028763771057e-01
    phi[8,7]  R2164     -3.2760732173919678e+00
    phi[8,7]  R2165     -2.88881778717041
    phi[8,7]  R2166     -9.3547904491424561e-01
    phi[8,7]  R2167     -1.5049989223480225e+00
    phi[8,7]  R2168     -2.5927419662475586e+00
    phi[8,7]  R2169     1.36786687374115
    phi[8,7]  R2170     1.0025986433029175e+00
    phi[8,7]  R2171     -2.1903121471405029e-01
    phi[8,7]  R2172     -3.0077648162841797e+00
    phi[8,7]  R2173     -2.2931506633758545e+00
    phi[8,7]  R2174     -1.2664984464645386e+00
    phi[8,7]  R2175     -2.6125891208648682e+00
    phi[8,7]  R2176     1.5658297538757324e+00
    phi[8,7]  R2177     -1.5994573831558228e+00
    phi[8,7]  R2178     -1.1056776046752930e+00
    phi[8,7]  R2179     -8.3404910564422607e-01
    phi[8,7]  R2180     -1.6999678611755371e+00
    phi[8,7]  R2181     1.9655048847198486e-01
    phi[8,7]  R2182     -6.8468920886516571e-02
    phi[8,7]  R2183     8.8446170091629028e-01
    phi[8,7]  R2184     1.2777494192123413e+00
    phi[8,7]  R2185     -5.2626854181289673e-01
    phi[8,7]  R2186     3.5290271043777466e-02
    phi[8,7]  R2187     -8.8477671146392822e-01
    phi[8,7]  R2188     0.415833055973053
    phi[8,7]  R2189     -5.5925470590591431e-01
    phi[8,7]  R2190     -9.9557948112487793e-01
    phi[8,7]  R2191     -6.9177395105361938e-01
    phi[8,7]  R2192     2.9634061455726624e-01
    phi[8,7]  R2193     -3.3496510982513428e-01
    phi[8,7]  R2194     5.7126826047897339e-01
    phi[8,7]  R2195     -3.5101320743560791e+00
    phi[8,7]  R2196     -0.83254474401474
    phi[8,7]  R2197     0.740243136882782
    phi[8,7]  R2198     1.5165263414382935e+00
    phi[8,7]  R2199     -3.3397226333618164e+00
    phi[8,7]  R2200     9.8630148172378540e-01
    phi[8,7]  R2201     1.2914324998855591e+00
    phi[8,7]  R2202     -1.6614911556243896e+00
    phi[8,7]  R2203     6.7956089973449707e-01
    phi[8,7]  R2204     1.3722839355468750e+00
    phi[8,7]  R2205     1.1461105346679688e+00
    phi[8,7]  R2206     5.6339547038078308e-02
    phi[8,7]  R2207     -3.6612565517425537e+00
    phi[8,7]  R2208     -2.9391636848449707e+00
    phi[8,7]  R2209     1.30873441696167
    phi[8,7]  R2210     2.1674954891204834e+00
    phi[8,7]  R2211     2.2435932159423828e+00
    phi[8,7]  R2212     6.3852876424789429e-01
    phi[8,7]  R2213     2.4429073333740234e+00
    phi[8,7]  R2214     1.7976462841033936e+00
    phi[8,7]  R2215     2.3629453182220459e+00
    phi[8,7]  R2216     -4.2005845904350281e-01
    phi[8,7]  R2217     -9.9957358837127686e-01
    phi[8,7]  R2218     -1.0416980981826782e+00
    phi[8,7]  R2219     -1.1007224321365356e+00
    phi[8,7]  R2220     -2.7139782905578613e-01
    phi[8,7]  R2221     -0.248402938246727
    phi[8,7]  R2222     -2.77126145362854
    phi[8,7]  R2223     6.5287381410598755e-01
    phi[8,7]  R2224     -5.9839963912963867e-01
    phi[8,7]  R2225     -4.0495882034301758e+00
    phi[8,7]  R2226     -2.1493856906890869e+00
    phi[8,7]  R2227     -9.1510856151580811e-01
    phi[8,7]  R2228     -1.6581090688705444e+00
    phi[8,7]  R2229     -1.8923177719116211e+00
    phi[8,7]  R2230     -1.8867106437683105e+00
    phi[8,7]  R2231     -9.5226854085922241e-01
    phi[8,7]  R2232     -1.3552495241165161e+00
    phi[8,7]  R2233     -3.1631534099578857e+00
    phi[8,7]  R2234     -3.1379821300506592e+00
    phi[8,7]  R2235     -0.0681607723236084
    phi[8,7]  R2236     -2.4373135566711426e+00
    phi[8,7]  R2237     -1.0394971370697021e+00
    phi[8,7]  R2238     -2.4538593292236328e+00
    phi[8,7]  R2239     -2.9986782073974609e+00
    phi[8,7]  R2240     -1.2305874824523926e+00
    phi[8,7]  R2241     -2.9383578300476074e+00
    phi[8,7]  R2242     -1.12994384765625
    phi[8,7]  R2243     3.4514978528022766e-01
    phi[8,7]  R2244     -1.2103297710418701e+00
    phi[8,7]  R2245     -1.8347837924957275e+00
    phi[8,7]  R2246     2.6759034395217896e-01
    phi[8,7]  R2247     -1.0695850849151611e+00
    phi[8,7]  R2248     -1.8820487260818481e+00
    phi[8,7]  R2249     -2.4636950492858887e+00
    phi[8,7]  R2250     -1.9586681127548218e+00
    phi[8,7]  R2251     -5.2575182914733887e-01
    phi[8,7]  R2252     -1.6402151584625244e+00
    phi[8,7]  R2253     -1.3304462432861328e+00
    phi[8,7]  R2254     -1.7752645015716553e+00
    phi[8,7]  R2255     -2.2528967857360840e+00
    phi[8,7]  R2256     -2.3160309791564941e+00
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2257     -3.0999999046325684e+00
    phi[8,9]  R2258     -3.0999999046325684e+00
    phi[8,9]  R2259     -2.2400000095367432e+00
    phi[8,9]  R2260     -2.2400000095367432e+00
    phi[8,9]  R2261     -3.0999999046325684e+00
    phi[8,9]  R2262     -3.0999999046325684e+00
    phi[8,9]  R2263     -2.5699999332427979e+00
    phi[8,9]  R2264     -2.5699999332427979e+00
    phi[8,9]  R2265     -3.0999999046325684e+00
    phi[8,9]  R2266     -3.0999999046325684e+00
    phi[8,9]  R2267     -2.0899999141693115e+00
    phi[8,9]  R2268     -2.0899999141693115e+00
    phi[8,9]  R2269     -3.0999999046325684e+00
    phi[8,9]  R2270     -3.0999999046325684e+00
    phi[8,9]  R2271     1.8194463253021240e+00
    phi[8,9]  R2272     2.3464875221252441e+00
    phi[8,9]  R2273     2.4024524688720703e+00
    phi[8,9]  R2274     1.9131171703338623e+00
    phi[8,9]  R2275     -2.6979517936706543e-01
    phi[8,9]  R2276     1.3153798580169678e+00
    phi[8,9]  R2277     1.2545664310455322e+00
    phi[8,9]  R2278     1.8561602830886841e+00
    phi[8,9]  R2279     -1.3000187277793884e-01
    phi[8,9]  R2280     1.3591071367263794e+00
    phi[8,9]  R2281     -0.797804057598114
    phi[8,9]  R2282     -1.1115605831146240e+00
    phi[8,9]  R2283     -1.5792071819305420e+00
    phi[8,9]  R2284     -2.3191905021667480e+00
    phi[8,9]  R2285     -4.7756183147430420e-01
    phi[8,9]  R2286     -1.6135271787643433e+00
    phi[8,9]  R2287     -8.4304350614547729e-01
    phi[8,9]  R2288     -1.1712057590484619e+00
    phi[8,9]  R2289     -1.3981798887252808e+00
    phi[8,9]  R2290     1.0792983770370483e+00
    phi[8,9]  R2291     -2.2794516086578369e+00
    phi[8,9]  R2292     -4.8972970247268677e-01
    phi[8,9]  R2293     -3.4085097312927246e+00
    phi[8,9]  R2294     -1.5308282375335693e+00
    phi[8,9]  R2295     1.2647722661495209e-01
    phi[8,9]  R2296     -6.1384302377700806e-01
    phi[8,9]  R2297     -1.0156574249267578e+00
    phi[8,9]  R2298     -2.0959854125976562e+00
    phi[8,9]  R2299     -7.5780749320983887e-01
    phi[8,9]  R2300     -2.5088782310485840e+00
    phi[8,9]  R2301     -5.7222402095794678e-01
    phi[8,9]  R2302     -1.1724900007247925e+00
    phi[8,9]  R2303     -0.642256498336792
    phi[8,9]  R2304     2.4172613620758057e+00
    phi[8,9]  R2305     -1.7524341344833374e+00
    phi[8,9]  R2306     3.6453530192375183e-02
    phi[8,9]  R2307     1.1403180360794067e+00
    phi[8,9]  R2308     -5.6825983524322510e-01
    phi[8,9]  R2309     3.9852076768875122e-01
    phi[8,9]  R2310     4.7192716598510742e-01
    phi[8,9]  R2311     -7.5772687792778015e-02
    phi[8,9]  R2312     -2.9479568004608154e+00
    phi[8,9]  R2313     -1.8583763837814331e+00
    phi[8,9]  R2314     -1.3927371501922607e+00
    phi[8,9]  R2315     2.8539028763771057e-01
    phi[8,9]  R2316     -3.2760732173919678e+00
    phi[8,9]  R2317     -2.88881778717041
    phi[8,9]  R2318     -9.3547904491424561e-01
    phi[8,9]  R2319     -1.5049989223480225e+00
    phi[8,9]  R2320     -2.5927419662475586e+00
    phi[8,9]  R2321     1.36786687374115
    phi[8,9]  R2322     1.0025986433029175e+00
    phi[8,9]  R2323     -2.1903121471405029e-01
    phi[8,9]  R2324     -3.0077648162841797e+00
    phi[8,9]  R2325     -2.2931506633758545e+00
    phi[8,9]  R2326     -1.2664984464645386e+00
    phi[8,9]  R2327     -2.6125891208648682e+00
    phi[8,9]  R2328     1.5658297538757324e+00
    phi[8,9]  R2329     -1.5994573831558228e+00
    phi[8,9]  R2330     -1.1056776046752930e+00
    phi[8,9]  R2331     -8.3404910564422607e-01
    phi[8,9]  R2332     -1.6999678611755371e+00
    phi[8,9]  R2333     1.9655048847198486e-01
    phi[8,9]  R2334     -6.8468920886516571e-02
    phi[8,9]  R2335     8.8446170091629028e-01
    phi[8,9]  R2336     1.2777494192123413e+00
    phi[8,9]  R2337     -5.2626854181289673e-01
    phi[8,9]  R2338     3.5290271043777466e-02
    phi[8,9]  R2339     -8.8477671146392822e-01
    phi[8,9]  R2340     0.415833055973053
    phi[8,9]  R2341     -5.5925470590591431e-01
    phi[8,9]  R2342     -9.9557948112487793e-01
    phi[8,9]  R2343     -6.9177395105361938e-01
    phi[8,9]  R2344     2.9634061455726624e-01
    phi[8,9]  R2345     -3.3496510982513428e-01
    phi[8,9]  R2346     5.7126826047897339e-01
    phi[8,9]  R2347     -3.5101320743560791e+00
    phi[8,9]  R2348     -0.83254474401474
    phi[8,9]  R2349     0.740243136882782
    phi[8,9]  R2350     1.5165263414382935e+00
    phi[8,9]  R2351     -3.3397226333618164e+00
    phi[8,9]  R2352     9.8630148172378540e-01
    phi[8,9]  R2353     1.2914324998855591e+00
    phi[8,9]  R2354     -1.6614911556243896e+00
    phi[8,9]  R2355     6.7956089973449707e-01
    phi[8,9]  R2356     1.3722839355468750e+00
    phi[8,9]  R2357     1.1461105346679688e+00
    phi[8,9]  R2358     5.6339547038078308e-02
    phi[8,9]  R2359     -3.6612565517425537e+00
    phi[8,9]  R2360     -2.9391636848449707e+00
    phi[8,9]  R2361     4.4102687835693359e+00
    phi[8,9]  R2362     2.5076591968536377e+00
    phi[8,9]  R2363     1.9908552169799805e+00
    phi[8,9]  R2364     1.1445590257644653e+00
    phi[8,9]  R2365     3.8981527090072632e-01
    phi[8,9]  R2366     -2.0974688231945038e-01
    phi[8,9]  R2367     -1.2636561393737793e+00
    phi[8,9]  R2368     -6.2650972604751587e-01
    phi[8,9]  R2369     -1.1557785272598267e+00
    phi[8,9]  R2370     -1.5122849941253662e+00
    phi[8,9]  R2371     3.7653851509094238e-01
    phi[8,9]  R2372     7.6469682157039642e-02
    phi[8,9]  R2373     -3.5390463471412659e-01
    phi[8,9]  R2374     1.0462409257888794e+00
    phi[8,9]  R2375     1.1184440925717354e-02
    phi[8,9]  R2376     -4.6739262342453003e-01
    phi[8,9]  R2377     -2.9303884506225586e+00
    phi[8,9]  R2378     6.9140052795410156e-01
    phi[8,9]  R2379     -9.4459843635559082e-01
    phi[8,9]  R2380     -1.0690047740936279e+00
    phi[8,9]  R2381     -2.0707087516784668e+00
    phi[8,9]  R2382     -2.2791874408721924e-01
    phi[8,9]  R2383     8.5017883777618408e-01
    phi[8,9]  R2384     8.5363888740539551e-01
    phi[8,9]  R2385     -7.0303261280059814e-01
    phi[8,9]  R2386     1.7387530207633972e-01
    phi[8,9]  R2387     -2.0217206478118896e+00
    phi[8,9]  R2388     -5.8931553363800049e-01
    phi[8,9]  R2389     2.0217137336730957e+00
    phi[8,9]  R2390     4.7554379701614380e-01
    phi[8,9]  R2391     1.1725807934999466e-01
    phi[8,9]  R2392     -2.4055886268615723e+00
    phi[8,9]  R2393     1.1233603954315186e+00
    phi[8,9]  R2394     -5.5898070335388184e-01
    phi[8,9]  R2395     1.6059015989303589e+00
    phi[8,9]  R2396     -1.1120266914367676e+00
    phi[8,9]  R2397     5.1682454347610474e-01
    phi[8,9]  R2398     2.6277685165405273e-01
    phi[8,9]  R2399     -1.5781419277191162e+00
    phi[8,9]  R2400     -7.1714615821838379e-01
    phi[8,9]  R2401     -5.8754548430442810e-02
    phi[8,9]  R2402     -8.0568677186965942e-01
    phi[8,9]  R2403     -1.5289851427078247e+00
    phi[8,9]  R2404     -9.3978680670261383e-02
    phi[8,9]  R2405     1.34114670753479
    phi[8,9]  R2406     0.713556170463562
    phi[8,9]  R2407     1.4747787714004517e+00
    phi[8,9]  R2408     -1.5324072837829590e+00
    phi[8,9]  R2409     1.6225671768188477e+00
    phi[8,9]  R2410     1.5433053970336914e+00
    phi[8,9]  R2411     -2.7873592376708984e+00
    phi[8,9]  R2412     -7.0636707544326782e-01
    phi[8,9]  R2413     -2.8895759582519531e-01
    phi[8,9]  R2414     8.0725330114364624e-01
    phi[8,9]  R2415     -1.4510447978973389e+00
    phi[8,9]  R2416     -1.7711989879608154e+00
    phi[8,9]  R2417     -1.1951242685317993e+00
    phi[8,9]  R2418     -1.2982908487319946e+00
    phi[8,9]  R2419     5.2163147926330566e-01
    phi[8,9]  R2420     -8.3742040395736694e-01
    phi[8,9]  R2421     -7.6910489797592163e-01
    phi[8,9]  R2422     -3.6399543285369873e-02
    phi[8,9]  R2423     1.0609329938888550e+00
    phi[8,9]  R2424     -9.9804377555847168e-01
    phi[8,9]  R2425     1.0156725645065308e+00
    phi[8,9]  R2426     1.1693006753921509e+00
    phi[8,9]  R2427     -2.7812530994415283e+00
    phi[8,9]  R2428     -3.9861454963684082e+00
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2429     -3.0999999046325684e+00
    phi[9,8]  R2430     -3.0999999046325684e+00
    phi[9,8]  R2431     -2.2400000095367432e+00
    phi[9,8]  R2432     -2.2400000095367432e+00
    phi[9,8]  R2433     -3.0999999046325684e+00
    phi[9,8]  R2434     -3.0999999046325684e+00
    phi[9,8]  R2435     -2.5699999332427979e+00
    phi[9,8]  R2436     -2.5699999332427979e+00
    phi[9,8]  R2437     -3.0999999046325684e+00
    phi[9,8]  R2438     -3.0999999046325684e+00
    phi[9,8]  R2439     -2.0899999141693115e+00
    phi[9,8]  R2440     -2.0899999141693115e+00
    phi[9,8]  R2441     -3.0999999046325684e+00
    phi[9,8]  R2442     -3.0999999046325684e+00
    phi[9,8]  R2443     4.4102687835693359e+00
    phi[9,8]  R2444     2.5076591968536377e+00
    phi[9,8]  R2445     1.9908552169799805e+00
    phi[9,8]  R2446     1.1445590257644653e+00
    phi[9,8]  R2447     3.8981527090072632e-01
    phi[9,8]  R2448     -2.0974688231945038e-01
    phi[9,8]  R2449     -1.2636561393737793e+00
    phi[9,8]  R2450     -6.2650972604751587e-01
    phi[9,8]  R2451     -1.1557785272598267e+00
    phi[9,8]  R2452     -1.5122849941253662e+00
    phi[9,8]  R2453     3.7653851509094238e-01
    phi[9,8]  R2454     7.6469682157039642e-02
    phi[9,8]  R2455     -3.5390463471412659e-01
    phi[9,8]  R2456     1.0462409257888794e+00
    phi[9,8]  R2457     1.1184440925717354e-02
    phi[9,8]  R2458     -4.6739262342453003e-01
    phi[9,8]  R2459     -2.9303884506225586e+00
    phi[9,8]  R2460     6.9140052795410156e-01
    phi[9,8]  R2461     -9.4459843635559082e-01
    phi[9,8]  R2462     -1.0690047740936279e+00
    phi[9,8]  R2463     -2.0707087516784668e+00
    phi[9,8]  R2464     -2.2791874408721924e-01
    phi[9,8]  R2465     8.5017883777618408e-01
    phi[9,8]  R2466     8.5363888740539551e-01
    phi[9,8]  R2467     -7.0303261280059814e-01
    phi[9,8]  R2468     1.7387530207633972e-01
    phi[9,8]  R2469     -2.0217206478118896e+00
    phi[9,8]  R2470     -5.8931553363800049e-01
    phi[9,8]  R2471     2.0217137336730957e+00
    phi[9,8]  R2472     4.7554379701614380e-01
    phi[9,8]  R2473     1.1725807934999466e-01
    phi[9,8]  R2474     -2.4055886268615723e+00
    phi[9,8]  R2475     1.1233603954315186e+00
    phi[9,8]  R2476     -5.5898070335388184e-01
    phi[9,8]  R2477     1.6059015989303589e+00
    phi[9,8]  R2478     -1.1120266914367676e+00
    phi[9,8]  R2479     5.1682454347610474e-01
    phi[9,8]  R2480     2.6277685165405273e-01
    phi[9,8]  R2481     -1.5781419277191162e+00
    phi[9,8]  R2482     -7.1714615821838379e-01
    phi[9,8]  R2483     -5.8754548430442810e-02
    phi[9,8]  R2484     -8.0568677186965942e-01
    phi[9,8]  R2485     -1.5289851427078247e+00
    phi[9,8]  R2486     -9.3978680670261383e-02
    phi[9,8]  R2487     1.34114670753479
    phi[9,8]  R2488     0.713556170463562
    phi[9,8]  R2489     1.4747787714004517e+00
    phi[9,8]  R2490     -1.5324072837829590e+00
    phi[9,8]  R2491     1.6225671768188477e+00
    phi[9,8]  R2492     1.5433053970336914e+00
    phi[9,8]  R2493     -2.7873592376708984e+00
    phi[9,8]  R2494     -7.0636707544326782e-01
    phi[9,8]  R2495     -2.8895759582519531e-01
    phi[9,8]  R2496     8.0725330114364624e-01
    phi[9,8]  R2497     -1.4510447978973389e+00
    phi[9,8]  R2498     -1.7711989879608154e+00
    phi[9,8]  R2499     -1.1951242685317993e+00
    phi[9,8]  R2500     -1.2982908487319946e+00
    phi[9,8]  R2501     5.2163147926330566e-01
    phi[9,8]  R2502     -8.3742040395736694e-01
    phi[9,8]  R2503     -7.6910489797592163e-01
    phi[9,8]  R2504     -3.6399543285369873e-02
    phi[9,8]  R2505     1.0609329938888550e+00
    phi[9,8]  R2506     -9.9804377555847168e-01
    phi[9,8]  R2507     1.0156725645065308e+00
    phi[9,8]  R2508     1.1693006753921509e+00
    phi[9,8]  R2509     -2.7812530994415283e+00
    phi[9,8]  R2510     -3.9861454963684082e+00
    phi[9,8]  R2511     1.8194463253021240e+00
    phi[9,8]  R2512     2.3464875221252441e+00
    phi[9,8]  R2513     2.4024524688720703e+00
    phi[9,8]  R2514     1.9131171703338623e+00
    phi[9,8]  R2515     -2.6979517936706543e-01
    phi[9,8]  R2516     1.3153798580169678e+00
    phi[9,8]  R2517     1.2545664310455322e+00
    phi[9,8]  R2518     1.8561602830886841e+00
    phi[9,8]  R2519     -1.3000187277793884e-01
    phi[9,8]  R2520     1.3591071367263794e+00
    phi[9,8]  R2521     -0.797804057598114
    phi[9,8]  R2522     -1.1115605831146240e+00
    phi[9,8]  R2523     -1.5792071819305420e+00
    phi[9,8]  R2524     -2.3191905021667480e+00
    phi[9,8]  R2525     -4.7756183147430420e-01
    phi[9,8]  R2526     -1.6135271787643433e+00
    phi[9,8]  R2527     -8.4304350614547729e-01
    phi[9,8]  R2528     -1.1712057590484619e+00
    phi[9,8]  R2529     -1.3981798887252808e+00
    phi[9,8]  R2530     1.0792983770370483e+00
    phi[9,8]  R2531     -2.2794516086578369e+00
    phi[9,8]  R2532     -4.8972970247268677e-01
    phi[9,8]  R2533     -3.4085097312927246e+00
    phi[9,8]  R2534     -1.5308282375335693e+00
    phi[9,8]  R2535     1.2647722661495209e-01
    phi[9,8]  R2536     -6.1384302377700806e-01
    phi[9,8]  R2537     -1.0156574249267578e+00
    phi[9,8]  R2538     -2.0959854125976562e+00
    phi[9,8]  R2539     -7.5780749320983887e-01
    phi[9,8]  R2540     -2.5088782310485840e+00
    phi[9,8]  R2541     -5.7222402095794678e-01
    phi[9,8]  R2542     -1.1724900007247925e+00
    phi[9,8]  R2543     -0.642256498336792
    phi[9,8]  R2544     2.4172613620758057e+00
    phi[9,8]  R2545     -1.7524341344833374e+00
    phi[9,8]  R2546     3.6453530192375183e-02
    phi[9,8]  R2547     1.1403180360794067e+00
    phi[9,8]  R2548     -5.6825983524322510e-01
    phi[9,8]  R2549     3.9852076768875122e-01
    phi[9,8]  R2550     4.7192716598510742e-01
    phi[9,8]  R2551     -7.5772687792778015e-02
    phi[9,8]  R2552     -2.9479568004608154e+00
    phi[9,8]  R2553     -1.8583763837814331e+00
    phi[9,8]  R2554     -1.3927371501922607e+00
    phi[9,8]  R2555     2.8539028763771057e-01
    phi[9,8]  R2556     -3.2760732173919678e+00
    phi[9,8]  R2557     -2.88881778717041
    phi[9,8]  R2558     -9.3547904491424561e-01
    phi[9,8]  R2559     -1.5049989223480225e+00
    phi[9,8]  R2560     -2.5927419662475586e+00
    phi[9,8]  R2561     1.36786687374115
    phi[9,8]  R2562     1.0025986433029175e+00
    phi[9,8]  R2563     -2.1903121471405029e-01
    phi[9,8]  R2564     -3.0077648162841797e+00
    phi[9,8]  R2565     -2.2931506633758545e+00
    phi[9,8]  R2566     -1.2664984464645386e+00
    phi[9,8]  R2567     -2.6125891208648682e+00
    phi[9,8]  R2568     1.5658297538757324e+00
    phi[9,8]  R2569     -1.5994573831558228e+00
    phi[9,8]  R2570     -1.1056776046752930e+00
    phi[9,8]  R2571     -8.3404910564422607e-01
    phi[9,8]  R2572     -1.6999678611755371e+00
    phi[9,8]  R2573     1.9655048847198486e-01
    phi[9,8]  R2574     -6.8468920886516571e-02
    phi[9,8]  R2575     8.8446170091629028e-01
    phi[9,8]  R2576     1.2777494192123413e+00
    phi[9,8]  R2577     -5.2626854181289673e-01
    phi[9,8]  R2578     3.5290271043777466e-02
    phi[9,8]  R2579     -8.8477671146392822e-01
    phi[9,8]  R2580     0.415833055973053
    phi[9,8]  R2581     -5.5925470590591431e-01
    phi[9,8]  R2582     -9.9557948112487793e-01
    phi[9,8]  R2583     -6.9177395105361938e-01
    phi[9,8]  R2584     2.9634061455726624e-01
    phi[9,8]  R2585     -3.3496510982513428e-01
    phi[9,8]  R2586     5.7126826047897339e-01
    phi[9,8]  R2587     -3.5101320743560791e+00
    phi[9,8]  R2588     -0.83254474401474
    phi[9,8]  R2589     0.740243136882782
    phi[9,8]  R2590     1.5165263414382935e+00
    phi[9,8]  R2591     -3.3397226333618164e+00
    phi[9,8]  R2592     9.8630148172378540e-01
    phi[9,8]  R2593     1.2914324998855591e+00
    phi[9,8]  R2594     -1.6614911556243896e+00
    phi[9,8]  R2595     6.7956089973449707e-01
    phi[9,8]  R2596     1.3722839355468750e+00
    phi[9,8]  R2597     1.1461105346679688e+00
    phi[9,8]  R2598     5.6339547038078308e-02
    phi[9,8]  R2599     -3.6612565517425537e+00
    phi[9,8]  R2600     -2.9391636848449707e+00
    phi[9,10]  R81       1
    phi[9,10]  R82       1
    phi[9,10]  R90       -1
    phi[9,10]  R2601     -3.0999999046325684e+00
    phi[9,10]  R2602     -3.0999999046325684e+00
    phi[9,10]  R2603     -2.2400000095367432e+00
    phi[9,10]  R2604     -2.2400000095367432e+00
    phi[9,10]  R2605     -3.0999999046325684e+00
    phi[9,10]  R2606     -3.0999999046325684e+00
    phi[9,10]  R2607     -2.5699999332427979e+00
    phi[9,10]  R2608     -2.5699999332427979e+00
    phi[9,10]  R2609     -3.0999999046325684e+00
    phi[9,10]  R2610     -3.0999999046325684e+00
    phi[9,10]  R2611     -2.0899999141693115e+00
    phi[9,10]  R2612     -2.0899999141693115e+00
    phi[9,10]  R2613     -3.0999999046325684e+00
    phi[9,10]  R2614     -3.0999999046325684e+00
    phi[9,10]  R2615     4.4102687835693359e+00
    phi[9,10]  R2616     2.5076591968536377e+00
    phi[9,10]  R2617     1.9908552169799805e+00
    phi[9,10]  R2618     1.1445590257644653e+00
    phi[9,10]  R2619     3.8981527090072632e-01
    phi[9,10]  R2620     -2.0974688231945038e-01
    phi[9,10]  R2621     -1.2636561393737793e+00
    phi[9,10]  R2622     -6.2650972604751587e-01
    phi[9,10]  R2623     -1.1557785272598267e+00
    phi[9,10]  R2624     -1.5122849941253662e+00
    phi[9,10]  R2625     3.7653851509094238e-01
    phi[9,10]  R2626     7.6469682157039642e-02
    phi[9,10]  R2627     -3.5390463471412659e-01
    phi[9,10]  R2628     1.0462409257888794e+00
    phi[9,10]  R2629     1.1184440925717354e-02
    phi[9,10]  R2630     -4.6739262342453003e-01
    phi[9,10]  R2631     -2.9303884506225586e+00
    phi[9,10]  R2632     6.9140052795410156e-01
    phi[9,10]  R2633     -9.4459843635559082e-01
    phi[9,10]  R2634     -1.0690047740936279e+00
    phi[9,10]  R2635     -2.0707087516784668e+00
    phi[9,10]  R2636     -2.2791874408721924e-01
    phi[9,10]  R2637     8.5017883777618408e-01
    phi[9,10]  R2638     8.5363888740539551e-01
    phi[9,10]  R2639     -7.0303261280059814e-01
    phi[9,10]  R2640     1.7387530207633972e-01
    phi[9,10]  R2641     -2.0217206478118896e+00
    phi[9,10]  R2642     -5.8931553363800049e-01
    phi[9,10]  R2643     2.0217137336730957e+00
    phi[9,10]  R2644     4.7554379701614380e-01
    phi[9,10]  R2645     1.1725807934999466e-01
    phi[9,10]  R2646     -2.4055886268615723e+00
    phi[9,10]  R2647     1.1233603954315186e+00
    phi[9,10]  R2648     -5.5898070335388184e-01
    phi[9,10]  R2649     1.6059015989303589e+00
    phi[9,10]  R2650     -1.1120266914367676e+00
    phi[9,10]  R2651     5.1682454347610474e-01
    phi[9,10]  R2652     2.6277685165405273e-01
    phi[9,10]  R2653     -1.5781419277191162e+00
    phi[9,10]  R2654     -7.1714615821838379e-01
    phi[9,10]  R2655     -5.8754548430442810e-02
    phi[9,10]  R2656     -8.0568677186965942e-01
    phi[9,10]  R2657     -1.5289851427078247e+00
    phi[9,10]  R2658     -9.3978680670261383e-02
    phi[9,10]  R2659     1.34114670753479
    phi[9,10]  R2660     0.713556170463562
    phi[9,10]  R2661     1.4747787714004517e+00
    phi[9,10]  R2662     -1.5324072837829590e+00
    phi[9,10]  R2663     1.6225671768188477e+00
    phi[9,10]  R2664     1.5433053970336914e+00
    phi[9,10]  R2665     -2.7873592376708984e+00
    phi[9,10]  R2666     -7.0636707544326782e-01
    phi[9,10]  R2667     -2.8895759582519531e-01
    phi[9,10]  R2668     8.0725330114364624e-01
    phi[9,10]  R2669     -1.4510447978973389e+00
    phi[9,10]  R2670     -1.7711989879608154e+00
    phi[9,10]  R2671     -1.1951242685317993e+00
    phi[9,10]  R2672     -1.2982908487319946e+00
    phi[9,10]  R2673     5.2163147926330566e-01
    phi[9,10]  R2674     -8.3742040395736694e-01
    phi[9,10]  R2675     -7.6910489797592163e-01
    phi[9,10]  R2676     -3.6399543285369873e-02
    phi[9,10]  R2677     1.0609329938888550e+00
    phi[9,10]  R2678     -9.9804377555847168e-01
    phi[9,10]  R2679     1.0156725645065308e+00
    phi[9,10]  R2680     1.1693006753921509e+00
    phi[9,10]  R2681     -2.7812530994415283e+00
    phi[9,10]  R2682     -3.9861454963684082e+00
    phi[9,10]  R2683     3.7476246356964111e+00
    phi[9,10]  R2684     2.3326549530029297e+00
    phi[9,10]  R2685     3.0208306312561035e+00
    phi[9,10]  R2686     3.8094127178192139e+00
    phi[9,10]  R2687     3.1111540794372559e+00
    phi[9,10]  R2688     2.9160006046295166e+00
    phi[9,10]  R2689     1.3418357372283936e+00
    phi[9,10]  R2690     6.5273576974868774e-01
    phi[9,10]  R2691     1.5833889245986938e+00
    phi[9,10]  R2692     1.6466869115829468e+00
    phi[9,10]  R2693     -8.0848425626754761e-01
    phi[9,10]  R2694     -2.5664358139038086e+00
    phi[9,10]  R2695     -4.7129729390144348e-01
    phi[9,10]  R2696     2.2003555297851562e+00
    phi[9,10]  R2697     -1.9344836473464966e+00
    phi[9,10]  R2698     -2.1741805076599121e+00
    phi[9,10]  R2699     -7.8689891099929810e-01
    phi[9,10]  R2700     -1.6290515661239624e+00
    phi[9,10]  R2701     -1.6878708600997925e+00
    phi[9,10]  R2702     -2.6771090030670166e+00
    phi[9,10]  R2703     2.3412392139434814e+00
    phi[9,10]  R2704     -3.5036070346832275e+00
    phi[9,10]  R2705     -2.7890751361846924e+00
    phi[9,10]  R2706     -4.11458158493042
    phi[9,10]  R2707     -5.8083885908126831e-01
    phi[9,10]  R2708     -1.1641008853912354e+00
    phi[9,10]  R2709     -2.3986289501190186e+00
    phi[9,10]  R2710     -2.6365306377410889e+00
    phi[9,10]  R2711     1.9542138576507568e+00
    phi[9,10]  R2712     9.7905695438385010e-01
    phi[9,10]  R2713     3.0298790931701660e+00
    phi[9,10]  R2714     -2.0503067970275879e+00
    phi[9,10]  R2715     -1.2998553514480591e+00
    phi[9,10]  R2716     2.1784925460815430e+00
    phi[9,10]  R2717     1.5168902873992920e+00
    phi[9,10]  R2718     -1.2194639444351196e+00
    phi[9,10]  R2719     -1.4500894546508789e+00
    phi[9,10]  R2720     -3.3974559307098389e+00
    phi[9,10]  R2721     -2.9136922359466553e+00
    phi[9,10]  R2722     -2.7470922470092773e+00
    phi[10,9]  R81       -1
    phi[10,9]  R90       1
    phi[10,9]  R91       1
    phi[10,9]  R2723     -3.0999999046325684e+00
    phi[10,9]  R2724     -3.0999999046325684e+00
    phi[10,9]  R2725     -2.2400000095367432e+00
    phi[10,9]  R2726     -2.2400000095367432e+00
    phi[10,9]  R2727     -3.0999999046325684e+00
    phi[10,9]  R2728     -3.0999999046325684e+00
    phi[10,9]  R2729     -2.5699999332427979e+00
    phi[10,9]  R2730     -2.5699999332427979e+00
    phi[10,9]  R2731     -3.0999999046325684e+00
    phi[10,9]  R2732     -3.0999999046325684e+00
    phi[10,9]  R2733     -2.0899999141693115e+00
    phi[10,9]  R2734     -2.0899999141693115e+00
    phi[10,9]  R2735     -3.0999999046325684e+00
    phi[10,9]  R2736     -3.0999999046325684e+00
    phi[10,9]  R2737     3.7476246356964111e+00
    phi[10,9]  R2738     2.3326549530029297e+00
    phi[10,9]  R2739     3.0208306312561035e+00
    phi[10,9]  R2740     3.8094127178192139e+00
    phi[10,9]  R2741     3.1111540794372559e+00
    phi[10,9]  R2742     2.9160006046295166e+00
    phi[10,9]  R2743     1.3418357372283936e+00
    phi[10,9]  R2744     6.5273576974868774e-01
    phi[10,9]  R2745     1.5833889245986938e+00
    phi[10,9]  R2746     1.6466869115829468e+00
    phi[10,9]  R2747     -8.0848425626754761e-01
    phi[10,9]  R2748     -2.5664358139038086e+00
    phi[10,9]  R2749     -4.7129729390144348e-01
    phi[10,9]  R2750     2.2003555297851562e+00
    phi[10,9]  R2751     -1.9344836473464966e+00
    phi[10,9]  R2752     -2.1741805076599121e+00
    phi[10,9]  R2753     -7.8689891099929810e-01
    phi[10,9]  R2754     -1.6290515661239624e+00
    phi[10,9]  R2755     -1.6878708600997925e+00
    phi[10,9]  R2756     -2.6771090030670166e+00
    phi[10,9]  R2757     2.3412392139434814e+00
    phi[10,9]  R2758     -3.5036070346832275e+00
    phi[10,9]  R2759     -2.7890751361846924e+00
    phi[10,9]  R2760     -4.11458158493042
    phi[10,9]  R2761     -5.8083885908126831e-01
    phi[10,9]  R2762     -1.1641008853912354e+00
    phi[10,9]  R2763     -2.3986289501190186e+00
    phi[10,9]  R2764     -2.6365306377410889e+00
    phi[10,9]  R2765     1.9542138576507568e+00
    phi[10,9]  R2766     9.7905695438385010e-01
    phi[10,9]  R2767     3.0298790931701660e+00
    phi[10,9]  R2768     -2.0503067970275879e+00
    phi[10,9]  R2769     -1.2998553514480591e+00
    phi[10,9]  R2770     2.1784925460815430e+00
    phi[10,9]  R2771     1.5168902873992920e+00
    phi[10,9]  R2772     -1.2194639444351196e+00
    phi[10,9]  R2773     -1.4500894546508789e+00
    phi[10,9]  R2774     -3.3974559307098389e+00
    phi[10,9]  R2775     -2.9136922359466553e+00
    phi[10,9]  R2776     -2.7470922470092773e+00
    phi[10,9]  R2777     4.4102687835693359e+00
    phi[10,9]  R2778     2.5076591968536377e+00
    phi[10,9]  R2779     1.9908552169799805e+00
    phi[10,9]  R2780     1.1445590257644653e+00
    phi[10,9]  R2781     3.8981527090072632e-01
    phi[10,9]  R2782     -2.0974688231945038e-01
    phi[10,9]  R2783     -1.2636561393737793e+00
    phi[10,9]  R2784     -6.2650972604751587e-01
    phi[10,9]  R2785     -1.1557785272598267e+00
    phi[10,9]  R2786     -1.5122849941253662e+00
    phi[10,9]  R2787     3.7653851509094238e-01
    phi[10,9]  R2788     7.6469682157039642e-02
    phi[10,9]  R2789     -3.5390463471412659e-01
    phi[10,9]  R2790     1.0462409257888794e+00
    phi[10,9]  R2791     1.1184440925717354e-02
    phi[10,9]  R2792     -4.6739262342453003e-01
    phi[10,9]  R2793     -2.9303884506225586e+00
    phi[10,9]  R2794     6.9140052795410156e-01
    phi[10,9]  R2795     -9.4459843635559082e-01
    phi[10,9]  R2796     -1.0690047740936279e+00
    phi[10,9]  R2797     -2.0707087516784668e+00
    phi[10,9]  R2798     -2.2791874408721924e-01
    phi[10,9]  R2799     8.5017883777618408e-01
    phi[10,9]  R2800     8.5363888740539551e-01
    phi[10,9]  R2801     -7.0303261280059814e-01
    phi[10,9]  R2802     1.7387530207633972e-01
    phi[10,9]  R2803     -2.0217206478118896e+00
    phi[10,9]  R2804     -5.8931553363800049e-01
    phi[10,9]  R2805     2.0217137336730957e+00
    phi[10,9]  R2806     4.7554379701614380e-01
    phi[10,9]  R2807     1.1725807934999466e-01
    phi[10,9]  R2808     -2.4055886268615723e+00
    phi[10,9]  R2809     1.1233603954315186e+00
    phi[10,9]  R2810     -5.5898070335388184e-01
    phi[10,9]  R2811     1.6059015989303589e+00
    phi[10,9]  R2812     -1.1120266914367676e+00
    phi[10,9]  R2813     5.1682454347610474e-01
    phi[10,9]  R2814     2.6277685165405273e-01
    phi[10,9]  R2815     -1.5781419277191162e+00
    phi[10,9]  R2816     -7.1714615821838379e-01
    phi[10,9]  R2817     -5.8754548430442810e-02
    phi[10,9]  R2818     -8.0568677186965942e-01
    phi[10,9]  R2819     -1.5289851427078247e+00
    phi[10,9]  R2820     -9.3978680670261383e-02
    phi[10,9]  R2821     1.34114670753479
    phi[10,9]  R2822     0.713556170463562
    phi[10,9]  R2823     1.4747787714004517e+00
    phi[10,9]  R2824     -1.5324072837829590e+00
    phi[10,9]  R2825     1.6225671768188477e+00
    phi[10,9]  R2826     1.5433053970336914e+00
    phi[10,9]  R2827     -2.7873592376708984e+00
    phi[10,9]  R2828     -7.0636707544326782e-01
    phi[10,9]  R2829     -2.8895759582519531e-01
    phi[10,9]  R2830     8.0725330114364624e-01
    phi[10,9]  R2831     -1.4510447978973389e+00
    phi[10,9]  R2832     -1.7711989879608154e+00
    phi[10,9]  R2833     -1.1951242685317993e+00
    phi[10,9]  R2834     -1.2982908487319946e+00
    phi[10,9]  R2835     5.2163147926330566e-01
    phi[10,9]  R2836     -8.3742040395736694e-01
    phi[10,9]  R2837     -7.6910489797592163e-01
    phi[10,9]  R2838     -3.6399543285369873e-02
    phi[10,9]  R2839     1.0609329938888550e+00
    phi[10,9]  R2840     -9.9804377555847168e-01
    phi[10,9]  R2841     1.0156725645065308e+00
    phi[10,9]  R2842     1.1693006753921509e+00
    phi[10,9]  R2843     -2.7812530994415283e+00
    phi[10,9]  R2844     -3.9861454963684082e+00
    phi[10,12]  R90       1
    phi[10,12]  R91       1
    phi[10,12]  R92       -2.7206018712518723e+00
    phi[10,12]  R93       1.0567445197567189e+00
    phi[10,12]  R94       3.0645618551547318e+00
    phi[10,12]  R95       1.5344943591100941e+00
    phi[10,12]  R96       -1.4155262718534778e+00
    phi[10,12]  R97       -4.7520743336823168e-01
    phi[10,12]  R98       -4.2223510441809609e-01
    phi[10,12]  R100      -1
    phi[10,12]  R2845     -5.8206017758844411e+00
    phi[10,12]  R2846     -3.7939803338069611e-01
    phi[10,12]  R2847     -1.1832554897800243e+00
    phi[10,12]  R2848     -3.2967445292934618e+00
    phi[10,12]  R2849     -3.5438049477836575e-02
    phi[10,12]  R2850     -6.1645617597873006e+00
    phi[10,12]  R2851     -1.0355055741327037e+00
    phi[10,12]  R2852     -4.1044942923528920e+00
    phi[10,12]  R2853     -4.5155261764860466e+00
    phi[10,12]  R2854     -1.6844736327790906e+00
    phi[10,12]  R2855     -2.5652073475375432e+00
    phi[10,12]  R2856     -1.6147924808010798e+00
    phi[10,12]  R2857     -3.5222350090506644e+00
    phi[10,12]  R2858     -2.6777648002144723e+00
    phi[10,12]  R2859     -1.1905693828465580e-01
    phi[10,12]  R2860     -1.2553358282607308e-01
    phi[10,12]  R2861     -1.3604651116769428e-01
    phi[10,12]  R2862     -1.4672142540794164e-01
    phi[10,12]  R2863     -1.4978633005128339e-01
    phi[10,12]  R2864     -1.5902367643011361e-01
    phi[10,12]  R2865     -3.3582344553273691e-01
    phi[10,12]  R2866     -3.4152657780078810e-01
    phi[10,12]  R2867     -3.5097285538294631e-01
    phi[10,12]  R2868     -3.8784080432628887e-01
    phi[10,12]  R2869     -2.2553023777575776e-01
    phi[10,12]  R2870     -2.3589413727914810e-01
    phi[10,12]  R2871     -2.4804894309743128e-01
    phi[10,12]  R2872     -2.4923641316274114e-01
    phi[10,12]  R2873     -2.5073037509193874e-01
    phi[10,12]  R2874     -2.5073398032772465e-01
    phi[10,12]  R2875     -2.5157440496028360e-01
    phi[10,12]  R2876     -2.5353197261457661e-01
    phi[10,12]  R2877     -2.5422759437839937e-01
    phi[10,12]  R2878     -2.6394219241699135e-01
    phi[10,12]  R2879     -0.144985031021859
    phi[10,12]  R2880     -2.3903040888528793e-01
    phi[10,12]  R2881     -2.7526075816400386e-01
    phi[10,12]  R2882     -2.7621085599898665e-01
    phi[10,12]  R2883     -3.0351433007568884e-01
    phi[10,12]  R2884     -3.0492145826478012e-01
    phi[10,12]  R2885     -0.323439994984966
    phi[10,12]  R2886     -3.7215261668648614e-01
    phi[10,12]  R2887     -4.0044554400030963e-01
    phi[10,12]  R2888     -0.47021342925911
    phi[10,12]  R2889     -2.2784614120511204e-01
    phi[10,12]  R2890     -2.7408418355175312e-01
    phi[10,12]  R2891     -2.8485959703024721e-01
    phi[10,12]  R2892     -2.8763713676181490e-01
    phi[10,12]  R2893     -3.2628488880185524e-01
    phi[10,12]  R2894     -3.7536720189333150e-01
    phi[10,12]  R2895     -3.9338486902787162e-01
    phi[10,12]  R2896     -5.9283022283360642e-01
    phi[10,12]  R2897     -1.2240012167598657e+00
    phi[10,12]  R2898     -1.23151145876731
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R101      -1
    z[0,1,0]  R102      1
    z[0,1,0]  R115      -4.3153684586286545e-02
    z[0,1,0]  R116      5.2086554467678070e-02
    z[0,1,0]  R117      -2.2197312116622925e-01
    z[0,1,0]  R118      1.3185174763202667e-01
    z[0,1,0]  R119      6.8412564694881439e-02
    z[0,1,0]  R120      4.4637724757194519e-01
    z[0,1,0]  R121      -3.6403915286064148e-01
    z[0,1,0]  R122      3.9958283305168152e-01
    z[0,1,0]  R123      -0.177352175116539
    z[0,1,0]  R124      8.5280239582061768e-01
    z[0,1,0]  R125      -2.0526976883411407e-01
    z[0,1,0]  R126      7.6757740974426270e-01
    z[0,1,0]  R127      -1.4529375731945038e-01
    z[0,1,0]  R128      -1.0966448113322258e-02
    z[0,1,0]  R129      -4.7159242630004883e-01
    z[0,1,0]  R130      -7.3068559169769287e-01
    z[0,1,0]  R131      -7.9364633560180664e-01
    z[0,1,0]  R132      -5.7123059034347534e-01
    z[0,1,0]  R133      -4.3389741331338882e-02
    z[0,1,0]  R134      -3.3598536252975464e-01
    z[0,1,0]  R135      -1.3736425340175629e-01
    z[0,1,0]  R136      -1.7194937914609909e-02
    z[0,1,0]  R137      -2.6216366887092590e-01
    z[0,1,0]  R138      -1.3007973134517670e-01
    z[0,1,0]  R139      -2.7309054136276245e-01
    z[0,1,0]  R140      2.5507912039756775e-01
    z[0,1,0]  R141      7.2937792539596558e-01
    z[0,1,0]  R142      6.9539844989776611e-01
    z[0,1,0]  R143      6.9143670797348022e-01
    z[0,1,0]  R144      7.0476317405700684e-01
    z[0,1,0]  R145      7.8731817007064819e-01
    z[0,1,0]  R146      6.0982835292816162e-01
    z[0,1,0]  R147      5.1540416479110718e-01
    z[0,1,0]  R148      7.7249638736248016e-02
    z[0,1,0]  R149      2.5266060233116150e-01
    z[0,1,0]  R150      -8.6177125573158264e-02
    z[0,1,0]  R151      -3.7142688035964966e-01
    z[0,1,0]  R152      -4.1751763224601746e-01
    z[0,1,0]  R153      -4.2661333084106445e-01
    z[0,1,0]  R154      -3.9848193526268005e-01
    z[0,1,0]  R155      -5.6802338361740112e-01
    z[0,1,0]  R156      -8.7458425760269165e-01
    z[0,1,0]  R157      -7.4471682310104370e-01
    z[0,1,0]  R158      -5.1511114835739136e-01
    z[0,1,0]  R159      -7.4330282211303711e-01
    z[0,1,0]  R160      -6.4153635501861572e-01
    z[0,1,0]  R161      -5.4495353251695633e-02
    z[0,1,0]  R162      -4.2932775616645813e-01
    z[0,1,0]  R163      1.1912572383880615e-01
    z[0,1,0]  R164      -2.8554797172546387e-01
    z[0,1,0]  R165      -2.1602143347263336e-01
    z[0,1,0]  R166      -3.7890213727951050e-01
    z[0,1,0]  R167      -5.5686873197555542e-01
    z[0,1,0]  R168      -4.8718467354774475e-01
    z[0,1,0]  R169      -4.3907305598258972e-01
    z[0,1,0]  R170      -4.4557729363441467e-01
    z[0,1,0]  R171      -7.9904294013977051e-01
    z[0,1,0]  R172      -3.9945688843727112e-01
    z[0,1,0]  R173      -6.6743910312652588e-01
    z[0,1,0]  R174      -1.1624854523688555e-03
    z[0,1,0]  R175      -6.3050216436386108e-01
    z[0,1,0]  R176      -4.2749956250190735e-01
    z[0,1,0]  R177      -2.7416041493415833e-01
    z[0,1,0]  R178      -5.4435908794403076e-01
    z[0,1,0]  R179      -3.5789293050765991e-01
    z[0,1,0]  R180      -6.7111587524414062e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R103      -1
    z[0,1,1]  R104      1
    z[0,1,1]  R115      -2.6194134354591370e-01
    z[0,1,1]  R116      -9.3748994171619415e-02
    z[0,1,1]  R117      -4.0664568543434143e-01
    z[0,1,1]  R118      8.0268484354019165e-01
    z[0,1,1]  R119      7.7266335487365723e-01
    z[0,1,1]  R120      -2.5754824280738831e-01
    z[0,1,1]  R121      3.7568348646163940e-01
    z[0,1,1]  R122      -3.2684612274169922e-01
    z[0,1,1]  R123      1.9955655932426453e-01
    z[0,1,1]  R124      -8.0468125641345978e-02
    z[0,1,1]  R125      -8.7620508670806885e-01
    z[0,1,1]  R126      -2.1219870448112488e-01
    z[0,1,1]  R127      -2.3760265111923218e-01
    z[0,1,1]  R128      -3.7017947435379028e-01
    z[0,1,1]  R129      7.0989185571670532e-01
    z[0,1,1]  R130      5.0783967971801758e-01
    z[0,1,1]  R131      3.9515414834022522e-01
    z[0,1,1]  R132      4.0462940931320190e-01
    z[0,1,1]  R133      -5.6281000375747681e-01
    z[0,1,1]  R134      4.6903070807456970e-01
    z[0,1,1]  R135      -0.431801438331604
    z[0,1,1]  R136      8.1538873910903931e-01
    z[0,1,1]  R137      7.1509200334548950e-01
    z[0,1,1]  R138      8.2887017726898193e-01
    z[0,1,1]  R139      6.8158239126205444e-01
    z[0,1,1]  R140      8.4231895208358765e-01
    z[0,1,1]  R141      1.3337233662605286e-01
    z[0,1,1]  R142      -2.2710485756397247e-01
    z[0,1,1]  R143      -2.5684958696365356e-01
    z[0,1,1]  R144      -1.4635254442691803e-01
    z[0,1,1]  R145      1.4452819526195526e-01
    z[0,1,1]  R146      3.6530364304780960e-02
    z[0,1,1]  R147      -5.1372405141592026e-02
    z[0,1,1]  R148      -4.1581195592880249e-01
    z[0,1,1]  R149      -1.3684687018394470e-01
    z[0,1,1]  R150      -3.3790990710258484e-01
    z[0,1,1]  R151      -3.9915016293525696e-01
    z[0,1,1]  R152      -3.7968832254409790e-01
    z[0,1,1]  R153      -3.2045853137969971e-01
    z[0,1,1]  R154      8.0964809656143188e-01
    z[0,1,1]  R155      5.8610850572586060e-01
    z[0,1,1]  R156      2.6091438531875610e-01
    z[0,1,1]  R157      3.0141600966453552e-01
    z[0,1,1]  R158      4.9611011147499084e-01
    z[0,1,1]  R159      2.8343120217323303e-01
    z[0,1,1]  R160      3.7927502393722534e-01
    z[0,1,1]  R161      -6.6704308986663818e-01
    z[0,1,1]  R162      7.0783996582031250e-01
    z[0,1,1]  R163      -6.7967861890792847e-01
    z[0,1,1]  R164      -8.0104589462280273e-01
    z[0,1,1]  R165      -4.8625072836875916e-01
    z[0,1,1]  R166      6.3931143283843994e-01
    z[0,1,1]  R167      5.3700327873229980e-01
    z[0,1,1]  R168      6.1399507522583008e-01
    z[0,1,1]  R169      5.9168910980224609e-01
    z[0,1,1]  R170      5.3273463249206543e-01
    z[0,1,1]  R171      0.534850001335144
    z[0,1,1]  R172      8.1202828884124756e-01
    z[0,1,1]  R173      5.8803558349609375e-01
    z[0,1,1]  R174      -3.5635221004486084e-01
    z[0,1,1]  R175      5.1366633176803589e-01
    z[0,1,1]  R176      6.7645597457885742e-01
    z[0,1,1]  R177      8.4169787168502808e-01
    z[0,1,1]  R178      6.4195710420608521e-01
    z[0,1,1]  R179      6.7603194713592529e-01
    z[0,1,1]  R180      0.426799476146698
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R105      -1
    z[0,1,2]  R106      1
    z[0,1,2]  R115      -5.2365267276763916e-01
    z[0,1,2]  R116      -1.3694140315055847e-01
    z[0,1,2]  R117      -1.9229413568973541e-01
    z[0,1,2]  R118      5.0728845596313477e-01
    z[0,1,2]  R119      1.1383360624313354e-01
    z[0,1,2]  R120      -4.5427742600440979e-01
    z[0,1,2]  R121      -4.1681605577468872e-01
    z[0,1,2]  R122      5.0395107269287109e-01
    z[0,1,2]  R123      -6.1691653728485107e-01
    z[0,1,2]  R124      -1.8926786258816719e-02
    z[0,1,2]  R125      2.7228688821196556e-02
    z[0,1,2]  R126      1.8873456120491028e-01
    z[0,1,2]  R127      -3.1726989895105362e-02
    z[0,1,2]  R128      0.720365047454834
    z[0,1,2]  R129      -2.2949756681919098e-01
    z[0,1,2]  R130      1.6310887411236763e-02
    z[0,1,2]  R131      -8.2569479942321777e-02
    z[0,1,2]  R132      -6.8585580587387085e-01
    z[0,1,2]  R133      -2.1133400499820709e-01
    z[0,1,2]  R134      -1.6055570542812347e-01
    z[0,1,2]  R135      -1.5230628848075867e-01
    z[0,1,2]  R136      -3.3396747708320618e-01
    z[0,1,2]  R137      4.7846347093582153e-02
    z[0,1,2]  R138      1.4736245386302471e-02
    z[0,1,2]  R139      3.0269041657447815e-01
    z[0,1,2]  R140      -6.8288013339042664e-02
    z[0,1,2]  R141      3.4506872296333313e-01
    z[0,1,2]  R142      2.2369889914989471e-01
    z[0,1,2]  R143      5.6558990478515625e-01
    z[0,1,2]  R144      1.3435854576528072e-02
    z[0,1,2]  R145      2.3403762280941010e-01
    z[0,1,2]  R146      -6.1334975063800812e-02
    z[0,1,2]  R147      1.0546138882637024e-01
    z[0,1,2]  R148      3.4270009398460388e-01
    z[0,1,2]  R149      1.0621958971023560e-01
    z[0,1,2]  R150      2.0313139259815216e-01
    z[0,1,2]  R151      -4.4750720262527466e-01
    z[0,1,2]  R152      -5.6669324636459351e-01
    z[0,1,2]  R153      -0.647377073764801
    z[0,1,2]  R154      3.4646353125572205e-01
    z[0,1,2]  R155      1.5642565488815308e-01
    z[0,1,2]  R156      1.4474781230092049e-02
    z[0,1,2]  R157      -3.4806481003761292e-01
    z[0,1,2]  R158      1.1457546800374985e-01
    z[0,1,2]  R159      -2.2262121737003326e-01
    z[0,1,2]  R160      -2.0205043256282806e-01
    z[0,1,2]  R161      3.1035864353179932e-01
    z[0,1,2]  R162      -9.3645744025707245e-02
    z[0,1,2]  R163      2.9548269510269165e-01
    z[0,1,2]  R164      2.4751627445220947e-01
    z[0,1,2]  R165      4.7951984405517578e-01
    z[0,1,2]  R166      -3.6204284429550171e-01
    z[0,1,2]  R167      -1.8501663208007812e-01
    z[0,1,2]  R168      8.6969859898090363e-02
    z[0,1,2]  R169      -1.4490877091884613e-01
    z[0,1,2]  R170      -2.9290112853050232e-01
    z[0,1,2]  R171      -1.6944038867950439e-01
    z[0,1,2]  R172      -1.0209630429744720e-01
    z[0,1,2]  R173      -2.0948436111211777e-02
    z[0,1,2]  R174      4.4204688072204590e-01
    z[0,1,2]  R175      -4.6465110778808594e-01
    z[0,1,2]  R176      -5.5999219417572021e-01
    z[0,1,2]  R177      -2.6072350144386292e-01
    z[0,1,2]  R178      1.4294293522834778e-01
    z[0,1,2]  R179      -2.9007813334465027e-01
    z[0,1,2]  R180      1.8540093302726746e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R107      -1
    z[0,1,3]  R108      1
    z[0,1,3]  R115      -7.5549614429473877e-01
    z[0,1,3]  R116      -2.1462583541870117e-01
    z[0,1,3]  R117      -7.1629685163497925e-01
    z[0,1,3]  R118      6.2352091073989868e-02
    z[0,1,3]  R119      -5.7097494602203369e-01
    z[0,1,3]  R120      0.345376580953598
    z[0,1,3]  R121      6.1128032207489014e-01
    z[0,1,3]  R122      1.4581255614757538e-01
    z[0,1,3]  R123      2.9678994417190552e-01
    z[0,1,3]  R124      -2.9740965366363525e-01
    z[0,1,3]  R125      4.0162914991378784e-01
    z[0,1,3]  R126      -4.9689021706581116e-01
    z[0,1,3]  R127      -2.5493571162223816e-01
    z[0,1,3]  R128      4.1132317855954170e-03
    z[0,1,3]  R129      4.5277667045593262e-01
    z[0,1,3]  R130      -1.7219153046607971e-01
    z[0,1,3]  R131      1.4373475313186646e-01
    z[0,1,3]  R132      -1.1241341382265091e-01
    z[0,1,3]  R133      1.3597184419631958e-01
    z[0,1,3]  R134      -2.8878791257739067e-02
    z[0,1,3]  R135      -6.7838227748870850e-01
    z[0,1,3]  R136      -3.2856807112693787e-01
    z[0,1,3]  R137      -8.9747928082942963e-02
    z[0,1,3]  R138      -1.5022800862789154e-01
    z[0,1,3]  R139      -4.1903233528137207e-01
    z[0,1,3]  R140      0.0640232115983963
    z[0,1,3]  R141      5.1889920234680176e-01
    z[0,1,3]  R142      4.8369956016540527e-01
    z[0,1,3]  R143      2.9077830910682678e-01
    z[0,1,3]  R144      0.596926212310791
    z[0,1,3]  R145      3.5593691468238831e-01
    z[0,1,3]  R146      7.3363047838211060e-01
    z[0,1,3]  R147      6.2213766574859619e-01
    z[0,1,3]  R148      -0.202616885304451
    z[0,1,3]  R149      6.8106240034103394e-01
    z[0,1,3]  R150      -4.8952010273933411e-01
    z[0,1,3]  R151      -2.0400212705135345e-01
    z[0,1,3]  R152      1.9041763246059418e-01
    z[0,1,3]  R153      2.0697003602981567e-01
    z[0,1,3]  R154      -1.6126327216625214e-01
    z[0,1,3]  R155      -3.4424927830696106e-01
    z[0,1,3]  R156      -2.3734968900680542e-01
    z[0,1,3]  R157      -1.2973500788211823e-01
    z[0,1,3]  R158      -2.2059005498886108e-01
    z[0,1,3]  R159      1.7889874055981636e-02
    z[0,1,3]  R160      0.285665363073349
    z[0,1,3]  R161      -3.2719928026199341e-01
    z[0,1,3]  R162      -1.7766429483890533e-01
    z[0,1,3]  R163      -2.1534240245819092e-01
    z[0,1,3]  R164      -1.3688556849956512e-01
    z[0,1,3]  R165      -5.4194068908691406e-01
    z[0,1,3]  R166      2.1447072923183441e-01
    z[0,1,3]  R167      3.3593562245368958e-01
    z[0,1,3]  R168      1.8853972852230072e-01
    z[0,1,3]  R169      1.4137262105941772e-01
    z[0,1,3]  R170      -1.3061001896858215e-01
    z[0,1,3]  R171      -2.3714998736977577e-02
    z[0,1,3]  R172      -2.9318743944168091e-01
    z[0,1,3]  R173      -1.2610936164855957e-01
    z[0,1,3]  R174      -7.0942115783691406e-01
    z[0,1,3]  R175      -8.9339666068553925e-02
    z[0,1,3]  R176      1.0879688709974289e-01
    z[0,1,3]  R177      6.1771705746650696e-02
    z[0,1,3]  R178      3.2730036973953247e-01
    z[0,1,3]  R179      0.282962828874588
    z[0,1,3]  R180      4.7854557633399963e-02
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R109      -1
    z[0,1,4]  R110      1
    z[0,1,4]  R115      5.8615417219698429e-03
    z[0,1,4]  R116      -9.5988857746124268e-01
    z[0,1,4]  R117      0.0999041348695755
    z[0,1,4]  R118      4.8622693866491318e-02
    z[0,1,4]  R119      3.8620594888925552e-02
    z[0,1,4]  R120      -1.0241254419088364e-01
    z[0,1,4]  R121      2.5241738557815552e-01
    z[0,1,4]  R122      -7.7295564115047455e-02
    z[0,1,4]  R123      2.0605014637112617e-02
    z[0,1,4]  R124      3.0566453933715820e-03
    z[0,1,4]  R125      6.1652567237615585e-02
    z[0,1,4]  R126      1.4779582619667053e-01
    z[0,1,4]  R127      1.3673785328865051e-01
    z[0,1,4]  R128      1.3951939344406128e-01
    z[0,1,4]  R129      -4.6789102256298065e-02
    z[0,1,4]  R130      -3.4566748887300491e-02
    z[0,1,4]  R131      -3.4867439419031143e-02
    z[0,1,4]  R132      -6.1316180974245071e-02
    z[0,1,4]  R133      0.754446804523468
    z[0,1,4]  R134      5.3235971927642822e-01
    z[0,1,4]  R135      6.6080227494239807e-02
    z[0,1,4]  R136      -1.9636349380016327e-01
    z[0,1,4]  R137      0.305124968290329
    z[0,1,4]  R138      5.0762075185775757e-01
    z[0,1,4]  R139      -4.0650421380996704e-01
    z[0,1,4]  R140      -2.2837018966674805e-01
    z[0,1,4]  R141      -0.0792056992650032
    z[0,1,4]  R142      1.8844315409660339e-01
    z[0,1,4]  R143      -1.9486621022224426e-01
    z[0,1,4]  R144      3.1478238105773926e-01
    z[0,1,4]  R145      2.1180033683776855e-01
    z[0,1,4]  R146      5.1478110253810883e-02
    z[0,1,4]  R147      -3.6653468012809753e-01
    z[0,1,4]  R148      2.7983969449996948e-01
    z[0,1,4]  R149      -6.0779005289077759e-01
    z[0,1,4]  R150      5.0472712516784668e-01
    z[0,1,4]  R151      4.0730607509613037e-01
    z[0,1,4]  R152      1.9348204135894775e-01
    z[0,1,4]  R153      5.5160537362098694e-02
    z[0,1,4]  R154      -8.1306464970111847e-02
    z[0,1,4]  R155      -4.0863001346588135e-01
    z[0,1,4]  R156      -2.7534094452857971e-01
    z[0,1,4]  R157      -2.5417742133140564e-01
    z[0,1,4]  R158      -3.1223183870315552e-01
    z[0,1,4]  R159      -7.5369350612163544e-02
    z[0,1,4]  R160      -1.1840689927339554e-01
    z[0,1,4]  R161      -1.0056166350841522e-01
    z[0,1,4]  R162      3.0120310187339783e-01
    z[0,1,4]  R163      3.0542176961898804e-01
    z[0,1,4]  R164      -4.4282829761505127e-01
    z[0,1,4]  R165      -3.6533474922180176e-01
    z[0,1,4]  R166      3.4225094318389893e-01
    z[0,1,4]  R167      0.354827880859375
    z[0,1,4]  R168      1.8782433867454529e-01
    z[0,1,4]  R169      -2.1791774779558182e-02
    z[0,1,4]  R170      6.3285613059997559e-01
    z[0,1,4]  R171      1.9259554147720337e-01
    z[0,1,4]  R172      -4.1830752044916153e-02
    z[0,1,4]  R173      -1.4422099292278290e-01
    z[0,1,4]  R174      3.5265302658081055e-01
    z[0,1,4]  R175      -1.2806174345314503e-03
    z[0,1,4]  R176      -1.5267243981361389e-01
    z[0,1,4]  R177      4.3057948350906372e-03
    z[0,1,4]  R178      -1.7468999326229095e-01
    z[0,1,4]  R179      2.6484140753746033e-01
    z[0,1,4]  R180      -1.9710429012775421e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R111      -1
    z[0,1,5]  R112      1
    z[0,1,5]  R115      -2.0393329858779907e-01
    z[0,1,5]  R116      -1.7240921035408974e-02
    z[0,1,5]  R117      -3.3184146881103516e-01
    z[0,1,5]  R118      -4.0281414985656738e-02
    z[0,1,5]  R119      2.2710794210433960e-01
    z[0,1,5]  R120      6.1952596902847290e-01
    z[0,1,5]  R121      -1.9208236038684845e-01
    z[0,1,5]  R122      -5.5004042387008667e-01
    z[0,1,5]  R123      2.0833095908164978e-01
    z[0,1,5]  R124      -3.6512249708175659e-01
    z[0,1,5]  R125      -1.5249180793762207e-01
    z[0,1,5]  R126      2.3425480723381042e-01
    z[0,1,5]  R127      7.2086542844772339e-01
    z[0,1,5]  R128      3.7749585509300232e-01
    z[0,1,5]  R129      7.3394723236560822e-02
    z[0,1,5]  R130      -3.7066987156867981e-01
    z[0,1,5]  R131      1.7140556871891022e-01
    z[0,1,5]  R132      -1.7189081758260727e-02
    z[0,1,5]  R133      1.3414807617664337e-01
    z[0,1,5]  R134      -5.6006091833114624e-01
    z[0,1,5]  R135      -5.1815855503082275e-01
    z[0,1,5]  R136      -1.4628899097442627e-01
    z[0,1,5]  R137      -5.0711417198181152e-01
    z[0,1,5]  R138      1.1888663470745087e-01
    z[0,1,5]  R139      -1.0908074676990509e-01
    z[0,1,5]  R140      2.2137090563774109e-01
    z[0,1,5]  R141      2.8551647439599037e-02
    z[0,1,5]  R142      -3.4730178117752075e-01
    z[0,1,5]  R143      1.0039012879133224e-01
    z[0,1,5]  R144      2.3487027734518051e-02
    z[0,1,5]  R145      6.7503049969673157e-02
    z[0,1,5]  R146      -2.0547521114349365e-01
    z[0,1,5]  R147      7.8511908650398254e-02
    z[0,1,5]  R148      -5.4383426904678345e-01
    z[0,1,5]  R149      -2.6201382279396057e-01
    z[0,1,5]  R150      -5.4901939630508423e-01
    z[0,1,5]  R151      4.6231734752655029e-01
    z[0,1,5]  R152      4.5106157660484314e-01
    z[0,1,5]  R153      2.3907804861664772e-02
    z[0,1,5]  R154      1.8173629045486450e-01
    z[0,1,5]  R155      -1.4996635913848877e-01
    z[0,1,5]  R156      -1.1133291572332382e-01
    z[0,1,5]  R157      -1.3700784742832184e-01
    z[0,1,5]  R158      7.9346112906932831e-02
    z[0,1,5]  R159      3.8579019904136658e-01
    z[0,1,5]  R160      5.3271347284317017e-01
    z[0,1,5]  R161      -2.1088415384292603e-01
    z[0,1,5]  R162      -2.7036604285240173e-01
    z[0,1,5]  R163      0.393787682056427
    z[0,1,5]  R164      2.6190746575593948e-02
    z[0,1,5]  R165      -6.9412463344633579e-03
    z[0,1,5]  R166      -1.8771132826805115e-01
    z[0,1,5]  R167      -3.5637933015823364e-01
    z[0,1,5]  R168      -2.7915915846824646e-01
    z[0,1,5]  R169      -6.4423257112503052e-01
    z[0,1,5]  R170      -1.1956059187650681e-01
    z[0,1,5]  R171      1.1860957369208336e-02
    z[0,1,5]  R172      1.0141263902187347e-01
    z[0,1,5]  R173      2.5752207636833191e-01
    z[0,1,5]  R174      2.0284067094326019e-01
    z[0,1,5]  R175      3.1230231747031212e-02
    z[0,1,5]  R176      1.0390304774045944e-01
    z[0,1,5]  R177      0.370836466550827
    z[0,1,5]  R178      -1.9459243118762970e-01
    z[0,1,5]  R179      4.2018571496009827e-01
    z[0,1,5]  R180      1.8176691234111786e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R113      -1
    z[0,1,6]  R114      1
    z[0,1,6]  R115      2.0715892314910889e-01
    z[0,1,6]  R116      4.4695157557725906e-02
    z[0,1,6]  R117      -3.3942502737045288e-01
    z[0,1,6]  R118      2.7036279439926147e-01
    z[0,1,6]  R119      -7.9190358519554138e-02
    z[0,1,6]  R120      1.2026077508926392e-01
    z[0,1,6]  R121      2.7987170219421387e-01
    z[0,1,6]  R122      3.8698580861091614e-01
    z[0,1,6]  R123      -6.4515638351440430e-01
    z[0,1,6]  R124      2.1004404127597809e-01
    z[0,1,6]  R125      -3.2044053077697754e-02
    z[0,1,6]  R126      0.0809752345085144
    z[0,1,6]  R127      -5.6399613618850708e-01
    z[0,1,6]  R128      -4.2653882503509521e-01
    z[0,1,6]  R129      0.0916639119386673
    z[0,1,6]  R130      -1.9922468066215515e-01
    z[0,1,6]  R131      -3.9484897255897522e-01
    z[0,1,6]  R132      -1.5126320719718933e-01
    z[0,1,6]  R133      -1.7614209651947021e-01
    z[0,1,6]  R134      2.0841492712497711e-01
    z[0,1,6]  R135      -1.9602052867412567e-01
    z[0,1,6]  R136      2.3536202311515808e-01
    z[0,1,6]  R137      2.4352371692657471e-01
    z[0,1,6]  R138      3.8144532591104507e-02
    z[0,1,6]  R139      -1.2850385904312134e-01
    z[0,1,6]  R140      3.3987239003181458e-01
    z[0,1,6]  R141      2.3409897089004517e-01
    z[0,1,6]  R142      -1.5718971192836761e-01
    z[0,1,6]  R143      -5.8724023401737213e-02
    z[0,1,6]  R144      -1.6046413779258728e-01
    z[0,1,6]  R145      -3.5827484726905823e-01
    z[0,1,6]  R146      -1.9982320070266724e-01
    z[0,1,6]  R147      -4.3935203552246094e-01
    z[0,1,6]  R148      5.3718715906143188e-01
    z[0,1,6]  R149      6.5169036388397217e-02
    z[0,1,6]  R150      0.203288733959198
    z[0,1,6]  R151      -2.8496682643890381e-01
    z[0,1,6]  R152      2.8848540782928467e-01
    z[0,1,6]  R153      -4.9975943565368652e-01
    z[0,1,6]  R154      6.5745715983211994e-04
    z[0,1,6]  R155      -3.7166573107242584e-02
    z[0,1,6]  R156      -1.4924509823322296e-01
    z[0,1,6]  R157      -3.6494889855384827e-01
    z[0,1,6]  R158      5.6829851865768433e-01
    z[0,1,6]  R159      -4.0345105528831482e-01
    z[0,1,6]  R160      -1.5604069828987122e-01
    z[0,1,6]  R161      -5.4232567548751831e-01
    z[0,1,6]  R162      -3.3239290118217468e-01
    z[0,1,6]  R163      3.7657976150512695e-01
    z[0,1,6]  R164      1.7373524606227875e-03
    z[0,1,6]  R165      -2.4441403150558472e-01
    z[0,1,6]  R166      3.4390413761138916e-01
    z[0,1,6]  R167      3.9139088243246078e-02
    z[0,1,6]  R168      4.7889706492424011e-01
    z[0,1,6]  R169      2.4972047656774521e-02
    z[0,1,6]  R170      -1.7291429685428739e-03
    z[0,1,6]  R171      9.4655208289623260e-02
    z[0,1,6]  R172      -2.6949459314346313e-01
    z[0,1,6]  R173      3.2446798682212830e-01
    z[0,1,6]  R174      9.3911968171596527e-02
    z[0,1,6]  R175      -3.3727535605430603e-01
    z[0,1,6]  R176      1.0890547186136246e-02
    z[0,1,6]  R177      8.3964817225933075e-02
    z[0,1,6]  R178      -3.0923005938529968e-01
    z[0,1,6]  R179      -6.3112258911132812e-02
    z[0,1,6]  R180      -5.0881510972976685e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R181      -1
    z[1,0,0]  R182      1
    z[1,0,0]  R195      7.2937792539596558e-01
    z[1,0,0]  R196      6.9539844989776611e-01
    z[1,0,0]  R197      6.9143670797348022e-01
    z[1,0,0]  R198      7.0476317405700684e-01
    z[1,0,0]  R199      7.8731817007064819e-01
    z[1,0,0]  R200      6.0982835292816162e-01
    z[1,0,0]  R201      5.1540416479110718e-01
    z[1,0,0]  R202      7.7249638736248016e-02
    z[1,0,0]  R203      2.5266060233116150e-01
    z[1,0,0]  R204      -8.6177125573158264e-02
    z[1,0,0]  R205      -3.7142688035964966e-01
    z[1,0,0]  R206      -4.1751763224601746e-01
    z[1,0,0]  R207      -4.2661333084106445e-01
    z[1,0,0]  R208      -3.9848193526268005e-01
    z[1,0,0]  R209      -5.6802338361740112e-01
    z[1,0,0]  R210      -8.7458425760269165e-01
    z[1,0,0]  R211      -7.4471682310104370e-01
    z[1,0,0]  R212      -5.1511114835739136e-01
    z[1,0,0]  R213      -7.4330282211303711e-01
    z[1,0,0]  R214      -6.4153635501861572e-01
    z[1,0,0]  R215      -5.4495353251695633e-02
    z[1,0,0]  R216      -4.2932775616645813e-01
    z[1,0,0]  R217      1.1912572383880615e-01
    z[1,0,0]  R218      -2.8554797172546387e-01
    z[1,0,0]  R219      -2.1602143347263336e-01
    z[1,0,0]  R220      -3.7890213727951050e-01
    z[1,0,0]  R221      -5.5686873197555542e-01
    z[1,0,0]  R222      -4.8718467354774475e-01
    z[1,0,0]  R223      -4.3907305598258972e-01
    z[1,0,0]  R224      -4.4557729363441467e-01
    z[1,0,0]  R225      -7.9904294013977051e-01
    z[1,0,0]  R226      -3.9945688843727112e-01
    z[1,0,0]  R227      -6.6743910312652588e-01
    z[1,0,0]  R228      -1.1624854523688555e-03
    z[1,0,0]  R229      -6.3050216436386108e-01
    z[1,0,0]  R230      -4.2749956250190735e-01
    z[1,0,0]  R231      -2.7416041493415833e-01
    z[1,0,0]  R232      -5.4435908794403076e-01
    z[1,0,0]  R233      -3.5789293050765991e-01
    z[1,0,0]  R234      -6.7111587524414062e-01
    z[1,0,0]  R235      -4.3153684586286545e-02
    z[1,0,0]  R236      5.2086554467678070e-02
    z[1,0,0]  R237      -2.2197312116622925e-01
    z[1,0,0]  R238      1.3185174763202667e-01
    z[1,0,0]  R239      6.8412564694881439e-02
    z[1,0,0]  R240      4.4637724757194519e-01
    z[1,0,0]  R241      -3.6403915286064148e-01
    z[1,0,0]  R242      3.9958283305168152e-01
    z[1,0,0]  R243      -0.177352175116539
    z[1,0,0]  R244      8.5280239582061768e-01
    z[1,0,0]  R245      -2.0526976883411407e-01
    z[1,0,0]  R246      7.6757740974426270e-01
    z[1,0,0]  R247      -1.4529375731945038e-01
    z[1,0,0]  R248      -1.0966448113322258e-02
    z[1,0,0]  R249      -4.7159242630004883e-01
    z[1,0,0]  R250      -7.3068559169769287e-01
    z[1,0,0]  R251      -7.9364633560180664e-01
    z[1,0,0]  R252      -5.7123059034347534e-01
    z[1,0,0]  R253      -4.3389741331338882e-02
    z[1,0,0]  R254      -3.3598536252975464e-01
    z[1,0,0]  R255      -1.3736425340175629e-01
    z[1,0,0]  R256      -1.7194937914609909e-02
    z[1,0,0]  R257      -2.6216366887092590e-01
    z[1,0,0]  R258      -1.3007973134517670e-01
    z[1,0,0]  R259      -2.7309054136276245e-01
    z[1,0,0]  R260      2.5507912039756775e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R183      -1
    z[1,0,1]  R184      1
    z[1,0,1]  R195      1.3337233662605286e-01
    z[1,0,1]  R196      -2.2710485756397247e-01
    z[1,0,1]  R197      -2.5684958696365356e-01
    z[1,0,1]  R198      -1.4635254442691803e-01
    z[1,0,1]  R199      1.4452819526195526e-01
    z[1,0,1]  R200      3.6530364304780960e-02
    z[1,0,1]  R201      -5.1372405141592026e-02
    z[1,0,1]  R202      -4.1581195592880249e-01
    z[1,0,1]  R203      -1.3684687018394470e-01
    z[1,0,1]  R204      -3.3790990710258484e-01
    z[1,0,1]  R205      -3.9915016293525696e-01
    z[1,0,1]  R206      -3.7968832254409790e-01
    z[1,0,1]  R207      -3.2045853137969971e-01
    z[1,0,1]  R208      8.0964809656143188e-01
    z[1,0,1]  R209      5.8610850572586060e-01
    z[1,0,1]  R210      2.6091438531875610e-01
    z[1,0,1]  R211      3.0141600966453552e-01
    z[1,0,1]  R212      4.9611011147499084e-01
    z[1,0,1]  R213      2.8343120217323303e-01
    z[1,0,1]  R214      3.7927502393722534e-01
    z[1,0,1]  R215      -6.6704308986663818e-01
    z[1,0,1]  R216      7.0783996582031250e-01
    z[1,0,1]  R217      -6.7967861890792847e-01
    z[1,0,1]  R218      -8.0104589462280273e-01
    z[1,0,1]  R219      -4.8625072836875916e-01
    z[1,0,1]  R220      6.3931143283843994e-01
    z[1,0,1]  R221      5.3700327873229980e-01
    z[1,0,1]  R222      6.1399507522583008e-01
    z[1,0,1]  R223      5.9168910980224609e-01
    z[1,0,1]  R224      5.3273463249206543e-01
    z[1,0,1]  R225      0.534850001335144
    z[1,0,1]  R226      8.1202828884124756e-01
    z[1,0,1]  R227      5.8803558349609375e-01
    z[1,0,1]  R228      -3.5635221004486084e-01
    z[1,0,1]  R229      5.1366633176803589e-01
    z[1,0,1]  R230      6.7645597457885742e-01
    z[1,0,1]  R231      8.4169787168502808e-01
    z[1,0,1]  R232      6.4195710420608521e-01
    z[1,0,1]  R233      6.7603194713592529e-01
    z[1,0,1]  R234      0.426799476146698
    z[1,0,1]  R235      -2.6194134354591370e-01
    z[1,0,1]  R236      -9.3748994171619415e-02
    z[1,0,1]  R237      -4.0664568543434143e-01
    z[1,0,1]  R238      8.0268484354019165e-01
    z[1,0,1]  R239      7.7266335487365723e-01
    z[1,0,1]  R240      -2.5754824280738831e-01
    z[1,0,1]  R241      3.7568348646163940e-01
    z[1,0,1]  R242      -3.2684612274169922e-01
    z[1,0,1]  R243      1.9955655932426453e-01
    z[1,0,1]  R244      -8.0468125641345978e-02
    z[1,0,1]  R245      -8.7620508670806885e-01
    z[1,0,1]  R246      -2.1219870448112488e-01
    z[1,0,1]  R247      -2.3760265111923218e-01
    z[1,0,1]  R248      -3.7017947435379028e-01
    z[1,0,1]  R249      7.0989185571670532e-01
    z[1,0,1]  R250      5.0783967971801758e-01
    z[1,0,1]  R251      3.9515414834022522e-01
    z[1,0,1]  R252      4.0462940931320190e-01
    z[1,0,1]  R253      -5.6281000375747681e-01
    z[1,0,1]  R254      4.6903070807456970e-01
    z[1,0,1]  R255      -0.431801438331604
    z[1,0,1]  R256      8.1538873910903931e-01
    z[1,0,1]  R257      7.1509200334548950e-01
    z[1,0,1]  R258      8.2887017726898193e-01
    z[1,0,1]  R259      6.8158239126205444e-01
    z[1,0,1]  R260      8.4231895208358765e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R185      -1
    z[1,0,2]  R186      1
    z[1,0,2]  R195      3.4506872296333313e-01
    z[1,0,2]  R196      2.2369889914989471e-01
    z[1,0,2]  R197      5.6558990478515625e-01
    z[1,0,2]  R198      1.3435854576528072e-02
    z[1,0,2]  R199      2.3403762280941010e-01
    z[1,0,2]  R200      -6.1334975063800812e-02
    z[1,0,2]  R201      1.0546138882637024e-01
    z[1,0,2]  R202      3.4270009398460388e-01
    z[1,0,2]  R203      1.0621958971023560e-01
    z[1,0,2]  R204      2.0313139259815216e-01
    z[1,0,2]  R205      -4.4750720262527466e-01
    z[1,0,2]  R206      -5.6669324636459351e-01
    z[1,0,2]  R207      -0.647377073764801
    z[1,0,2]  R208      3.4646353125572205e-01
    z[1,0,2]  R209      1.5642565488815308e-01
    z[1,0,2]  R210      1.4474781230092049e-02
    z[1,0,2]  R211      -3.4806481003761292e-01
    z[1,0,2]  R212      1.1457546800374985e-01
    z[1,0,2]  R213      -2.2262121737003326e-01
    z[1,0,2]  R214      -2.0205043256282806e-01
    z[1,0,2]  R215      3.1035864353179932e-01
    z[1,0,2]  R216      -9.3645744025707245e-02
    z[1,0,2]  R217      2.9548269510269165e-01
    z[1,0,2]  R218      2.4751627445220947e-01
    z[1,0,2]  R219      4.7951984405517578e-01
    z[1,0,2]  R220      -3.6204284429550171e-01
    z[1,0,2]  R221      -1.8501663208007812e-01
    z[1,0,2]  R222      8.6969859898090363e-02
    z[1,0,2]  R223      -1.4490877091884613e-01
    z[1,0,2]  R224      -2.9290112853050232e-01
    z[1,0,2]  R225      -1.6944038867950439e-01
    z[1,0,2]  R226      -1.0209630429744720e-01
    z[1,0,2]  R227      -2.0948436111211777e-02
    z[1,0,2]  R228      4.4204688072204590e-01
    z[1,0,2]  R229      -4.6465110778808594e-01
    z[1,0,2]  R230      -5.5999219417572021e-01
    z[1,0,2]  R231      -2.6072350144386292e-01
    z[1,0,2]  R232      1.4294293522834778e-01
    z[1,0,2]  R233      -2.9007813334465027e-01
    z[1,0,2]  R234      1.8540093302726746e-01
    z[1,0,2]  R235      -5.2365267276763916e-01
    z[1,0,2]  R236      -1.3694140315055847e-01
    z[1,0,2]  R237      -1.9229413568973541e-01
    z[1,0,2]  R238      5.0728845596313477e-01
    z[1,0,2]  R239      1.1383360624313354e-01
    z[1,0,2]  R240      -4.5427742600440979e-01
    z[1,0,2]  R241      -4.1681605577468872e-01
    z[1,0,2]  R242      5.0395107269287109e-01
    z[1,0,2]  R243      -6.1691653728485107e-01
    z[1,0,2]  R244      -1.8926786258816719e-02
    z[1,0,2]  R245      2.7228688821196556e-02
    z[1,0,2]  R246      1.8873456120491028e-01
    z[1,0,2]  R247      -3.1726989895105362e-02
    z[1,0,2]  R248      0.720365047454834
    z[1,0,2]  R249      -2.2949756681919098e-01
    z[1,0,2]  R250      1.6310887411236763e-02
    z[1,0,2]  R251      -8.2569479942321777e-02
    z[1,0,2]  R252      -6.8585580587387085e-01
    z[1,0,2]  R253      -2.1133400499820709e-01
    z[1,0,2]  R254      -1.6055570542812347e-01
    z[1,0,2]  R255      -1.5230628848075867e-01
    z[1,0,2]  R256      -3.3396747708320618e-01
    z[1,0,2]  R257      4.7846347093582153e-02
    z[1,0,2]  R258      1.4736245386302471e-02
    z[1,0,2]  R259      3.0269041657447815e-01
    z[1,0,2]  R260      -6.8288013339042664e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R187      -1
    z[1,0,3]  R188      1
    z[1,0,3]  R195      5.1889920234680176e-01
    z[1,0,3]  R196      4.8369956016540527e-01
    z[1,0,3]  R197      2.9077830910682678e-01
    z[1,0,3]  R198      0.596926212310791
    z[1,0,3]  R199      3.5593691468238831e-01
    z[1,0,3]  R200      7.3363047838211060e-01
    z[1,0,3]  R201      6.2213766574859619e-01
    z[1,0,3]  R202      -0.202616885304451
    z[1,0,3]  R203      6.8106240034103394e-01
    z[1,0,3]  R204      -4.8952010273933411e-01
    z[1,0,3]  R205      -2.0400212705135345e-01
    z[1,0,3]  R206      1.9041763246059418e-01
    z[1,0,3]  R207      2.0697003602981567e-01
    z[1,0,3]  R208      -1.6126327216625214e-01
    z[1,0,3]  R209      -3.4424927830696106e-01
    z[1,0,3]  R210      -2.3734968900680542e-01
    z[1,0,3]  R211      -1.2973500788211823e-01
    z[1,0,3]  R212      -2.2059005498886108e-01
    z[1,0,3]  R213      1.7889874055981636e-02
    z[1,0,3]  R214      0.285665363073349
    z[1,0,3]  R215      -3.2719928026199341e-01
    z[1,0,3]  R216      -1.7766429483890533e-01
    z[1,0,3]  R217      -2.1534240245819092e-01
    z[1,0,3]  R218      -1.3688556849956512e-01
    z[1,0,3]  R219      -5.4194068908691406e-01
    z[1,0,3]  R220      2.1447072923183441e-01
    z[1,0,3]  R221      3.3593562245368958e-01
    z[1,0,3]  R222      1.8853972852230072e-01
    z[1,0,3]  R223      1.4137262105941772e-01
    z[1,0,3]  R224      -1.3061001896858215e-01
    z[1,0,3]  R225      -2.3714998736977577e-02
    z[1,0,3]  R226      -2.9318743944168091e-01
    z[1,0,3]  R227      -1.2610936164855957e-01
    z[1,0,3]  R228      -7.0942115783691406e-01
    z[1,0,3]  R229      -8.9339666068553925e-02
    z[1,0,3]  R230      1.0879688709974289e-01
    z[1,0,3]  R231      6.1771705746650696e-02
    z[1,0,3]  R232      3.2730036973953247e-01
    z[1,0,3]  R233      0.282962828874588
    z[1,0,3]  R234      4.7854557633399963e-02
    z[1,0,3]  R235      -7.5549614429473877e-01
    z[1,0,3]  R236      -2.1462583541870117e-01
    z[1,0,3]  R237      -7.1629685163497925e-01
    z[1,0,3]  R238      6.2352091073989868e-02
    z[1,0,3]  R239      -5.7097494602203369e-01
    z[1,0,3]  R240      0.345376580953598
    z[1,0,3]  R241      6.1128032207489014e-01
    z[1,0,3]  R242      1.4581255614757538e-01
    z[1,0,3]  R243      2.9678994417190552e-01
    z[1,0,3]  R244      -2.9740965366363525e-01
    z[1,0,3]  R245      4.0162914991378784e-01
    z[1,0,3]  R246      -4.9689021706581116e-01
    z[1,0,3]  R247      -2.5493571162223816e-01
    z[1,0,3]  R248      4.1132317855954170e-03
    z[1,0,3]  R249      4.5277667045593262e-01
    z[1,0,3]  R250      -1.7219153046607971e-01
    z[1,0,3]  R251      1.4373475313186646e-01
    z[1,0,3]  R252      -1.1241341382265091e-01
    z[1,0,3]  R253      1.3597184419631958e-01
    z[1,0,3]  R254      -2.8878791257739067e-02
    z[1,0,3]  R255      -6.7838227748870850e-01
    z[1,0,3]  R256      -3.2856807112693787e-01
    z[1,0,3]  R257      -8.9747928082942963e-02
    z[1,0,3]  R258      -1.5022800862789154e-01
    z[1,0,3]  R259      -4.1903233528137207e-01
    z[1,0,3]  R260      0.0640232115983963
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R189      -1
    z[1,0,4]  R190      1
    z[1,0,4]  R195      -0.0792056992650032
    z[1,0,4]  R196      1.8844315409660339e-01
    z[1,0,4]  R197      -1.9486621022224426e-01
    z[1,0,4]  R198      3.1478238105773926e-01
    z[1,0,4]  R199      2.1180033683776855e-01
    z[1,0,4]  R200      5.1478110253810883e-02
    z[1,0,4]  R201      -3.6653468012809753e-01
    z[1,0,4]  R202      2.7983969449996948e-01
    z[1,0,4]  R203      -6.0779005289077759e-01
    z[1,0,4]  R204      5.0472712516784668e-01
    z[1,0,4]  R205      4.0730607509613037e-01
    z[1,0,4]  R206      1.9348204135894775e-01
    z[1,0,4]  R207      5.5160537362098694e-02
    z[1,0,4]  R208      -8.1306464970111847e-02
    z[1,0,4]  R209      -4.0863001346588135e-01
    z[1,0,4]  R210      -2.7534094452857971e-01
    z[1,0,4]  R211      -2.5417742133140564e-01
    z[1,0,4]  R212      -3.1223183870315552e-01
    z[1,0,4]  R213      -7.5369350612163544e-02
    z[1,0,4]  R214      -1.1840689927339554e-01
    z[1,0,4]  R215      -1.0056166350841522e-01
    z[1,0,4]  R216      3.0120310187339783e-01
    z[1,0,4]  R217      3.0542176961898804e-01
    z[1,0,4]  R218      -4.4282829761505127e-01
    z[1,0,4]  R219      -3.6533474922180176e-01
    z[1,0,4]  R220      3.4225094318389893e-01
    z[1,0,4]  R221      0.354827880859375
    z[1,0,4]  R222      1.8782433867454529e-01
    z[1,0,4]  R223      -2.1791774779558182e-02
    z[1,0,4]  R224      6.3285613059997559e-01
    z[1,0,4]  R225      1.9259554147720337e-01
    z[1,0,4]  R226      -4.1830752044916153e-02
    z[1,0,4]  R227      -1.4422099292278290e-01
    z[1,0,4]  R228      3.5265302658081055e-01
    z[1,0,4]  R229      -1.2806174345314503e-03
    z[1,0,4]  R230      -1.5267243981361389e-01
    z[1,0,4]  R231      4.3057948350906372e-03
    z[1,0,4]  R232      -1.7468999326229095e-01
    z[1,0,4]  R233      2.6484140753746033e-01
    z[1,0,4]  R234      -1.9710429012775421e-01
    z[1,0,4]  R235      5.8615417219698429e-03
    z[1,0,4]  R236      -9.5988857746124268e-01
    z[1,0,4]  R237      0.0999041348695755
    z[1,0,4]  R238      4.8622693866491318e-02
    z[1,0,4]  R239      3.8620594888925552e-02
    z[1,0,4]  R240      -1.0241254419088364e-01
    z[1,0,4]  R241      2.5241738557815552e-01
    z[1,0,4]  R242      -7.7295564115047455e-02
    z[1,0,4]  R243      2.0605014637112617e-02
    z[1,0,4]  R244      3.0566453933715820e-03
    z[1,0,4]  R245      6.1652567237615585e-02
    z[1,0,4]  R246      1.4779582619667053e-01
    z[1,0,4]  R247      1.3673785328865051e-01
    z[1,0,4]  R248      1.3951939344406128e-01
    z[1,0,4]  R249      -4.6789102256298065e-02
    z[1,0,4]  R250      -3.4566748887300491e-02
    z[1,0,4]  R251      -3.4867439419031143e-02
    z[1,0,4]  R252      -6.1316180974245071e-02
    z[1,0,4]  R253      0.754446804523468
    z[1,0,4]  R254      5.3235971927642822e-01
    z[1,0,4]  R255      6.6080227494239807e-02
    z[1,0,4]  R256      -1.9636349380016327e-01
    z[1,0,4]  R257      0.305124968290329
    z[1,0,4]  R258      5.0762075185775757e-01
    z[1,0,4]  R259      -4.0650421380996704e-01
    z[1,0,4]  R260      -2.2837018966674805e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R191      -1
    z[1,0,5]  R192      1
    z[1,0,5]  R195      2.8551647439599037e-02
    z[1,0,5]  R196      -3.4730178117752075e-01
    z[1,0,5]  R197      1.0039012879133224e-01
    z[1,0,5]  R198      2.3487027734518051e-02
    z[1,0,5]  R199      6.7503049969673157e-02
    z[1,0,5]  R200      -2.0547521114349365e-01
    z[1,0,5]  R201      7.8511908650398254e-02
    z[1,0,5]  R202      -5.4383426904678345e-01
    z[1,0,5]  R203      -2.6201382279396057e-01
    z[1,0,5]  R204      -5.4901939630508423e-01
    z[1,0,5]  R205      4.6231734752655029e-01
    z[1,0,5]  R206      4.5106157660484314e-01
    z[1,0,5]  R207      2.3907804861664772e-02
    z[1,0,5]  R208      1.8173629045486450e-01
    z[1,0,5]  R209      -1.4996635913848877e-01
    z[1,0,5]  R210      -1.1133291572332382e-01
    z[1,0,5]  R211      -1.3700784742832184e-01
    z[1,0,5]  R212      7.9346112906932831e-02
    z[1,0,5]  R213      3.8579019904136658e-01
    z[1,0,5]  R214      5.3271347284317017e-01
    z[1,0,5]  R215      -2.1088415384292603e-01
    z[1,0,5]  R216      -2.7036604285240173e-01
    z[1,0,5]  R217      0.393787682056427
    z[1,0,5]  R218      2.6190746575593948e-02
    z[1,0,5]  R219      -6.9412463344633579e-03
    z[1,0,5]  R220      -1.8771132826805115e-01
    z[1,0,5]  R221      -3.5637933015823364e-01
    z[1,0,5]  R222      -2.7915915846824646e-01
    z[1,0,5]  R223      -6.4423257112503052e-01
    z[1,0,5]  R224      -1.1956059187650681e-01
    z[1,0,5]  R225      1.1860957369208336e-02
    z[1,0,5]  R226      1.0141263902187347e-01
    z[1,0,5]  R227      2.5752207636833191e-01
    z[1,0,5]  R228      2.0284067094326019e-01
    z[1,0,5]  R229      3.1230231747031212e-02
    z[1,0,5]  R230      1.0390304774045944e-01
    z[1,0,5]  R231      0.370836466550827
    z[1,0,5]  R232      -1.9459243118762970e-01
    z[1,0,5]  R233      4.2018571496009827e-01
    z[1,0,5]  R234      1.8176691234111786e-01
    z[1,0,5]  R235      -2.0393329858779907e-01
    z[1,0,5]  R236      -1.7240921035408974e-02
    z[1,0,5]  R237      -3.3184146881103516e-01
    z[1,0,5]  R238      -4.0281414985656738e-02
    z[1,0,5]  R239      2.2710794210433960e-01
    z[1,0,5]  R240      6.1952596902847290e-01
    z[1,0,5]  R241      -1.9208236038684845e-01
    z[1,0,5]  R242      -5.5004042387008667e-01
    z[1,0,5]  R243      2.0833095908164978e-01
    z[1,0,5]  R244      -3.6512249708175659e-01
    z[1,0,5]  R245      -1.5249180793762207e-01
    z[1,0,5]  R246      2.3425480723381042e-01
    z[1,0,5]  R247      7.2086542844772339e-01
    z[1,0,5]  R248      3.7749585509300232e-01
    z[1,0,5]  R249      7.3394723236560822e-02
    z[1,0,5]  R250      -3.7066987156867981e-01
    z[1,0,5]  R251      1.7140556871891022e-01
    z[1,0,5]  R252      -1.7189081758260727e-02
    z[1,0,5]  R253      1.3414807617664337e-01
    z[1,0,5]  R254      -5.6006091833114624e-01
    z[1,0,5]  R255      -5.1815855503082275e-01
    z[1,0,5]  R256      -1.4628899097442627e-01
    z[1,0,5]  R257      -5.0711417198181152e-01
    z[1,0,5]  R258      1.1888663470745087e-01
    z[1,0,5]  R259      -1.0908074676990509e-01
    z[1,0,5]  R260      2.2137090563774109e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R193      -1
    z[1,0,6]  R194      1
    z[1,0,6]  R195      2.3409897089004517e-01
    z[1,0,6]  R196      -1.5718971192836761e-01
    z[1,0,6]  R197      -5.8724023401737213e-02
    z[1,0,6]  R198      -1.6046413779258728e-01
    z[1,0,6]  R199      -3.5827484726905823e-01
    z[1,0,6]  R200      -1.9982320070266724e-01
    z[1,0,6]  R201      -4.3935203552246094e-01
    z[1,0,6]  R202      5.3718715906143188e-01
    z[1,0,6]  R203      6.5169036388397217e-02
    z[1,0,6]  R204      0.203288733959198
    z[1,0,6]  R205      -2.8496682643890381e-01
    z[1,0,6]  R206      2.8848540782928467e-01
    z[1,0,6]  R207      -4.9975943565368652e-01
    z[1,0,6]  R208      6.5745715983211994e-04
    z[1,0,6]  R209      -3.7166573107242584e-02
    z[1,0,6]  R210      -1.4924509823322296e-01
    z[1,0,6]  R211      -3.6494889855384827e-01
    z[1,0,6]  R212      5.6829851865768433e-01
    z[1,0,6]  R213      -4.0345105528831482e-01
    z[1,0,6]  R214      -1.5604069828987122e-01
    z[1,0,6]  R215      -5.4232567548751831e-01
    z[1,0,6]  R216      -3.3239290118217468e-01
    z[1,0,6]  R217      3.7657976150512695e-01
    z[1,0,6]  R218      1.7373524606227875e-03
    z[1,0,6]  R219      -2.4441403150558472e-01
    z[1,0,6]  R220      3.4390413761138916e-01
    z[1,0,6]  R221      3.9139088243246078e-02
    z[1,0,6]  R222      4.7889706492424011e-01
    z[1,0,6]  R223      2.4972047656774521e-02
    z[1,0,6]  R224      -1.7291429685428739e-03
    z[1,0,6]  R225      9.4655208289623260e-02
    z[1,0,6]  R226      -2.6949459314346313e-01
    z[1,0,6]  R227      3.2446798682212830e-01
    z[1,0,6]  R228      9.3911968171596527e-02
    z[1,0,6]  R229      -3.3727535605430603e-01
    z[1,0,6]  R230      1.0890547186136246e-02
    z[1,0,6]  R231      8.3964817225933075e-02
    z[1,0,6]  R232      -3.0923005938529968e-01
    z[1,0,6]  R233      -6.3112258911132812e-02
    z[1,0,6]  R234      -5.0881510972976685e-01
    z[1,0,6]  R235      2.0715892314910889e-01
    z[1,0,6]  R236      4.4695157557725906e-02
    z[1,0,6]  R237      -3.3942502737045288e-01
    z[1,0,6]  R238      2.7036279439926147e-01
    z[1,0,6]  R239      -7.9190358519554138e-02
    z[1,0,6]  R240      1.2026077508926392e-01
    z[1,0,6]  R241      2.7987170219421387e-01
    z[1,0,6]  R242      3.8698580861091614e-01
    z[1,0,6]  R243      -6.4515638351440430e-01
    z[1,0,6]  R244      2.1004404127597809e-01
    z[1,0,6]  R245      -3.2044053077697754e-02
    z[1,0,6]  R246      0.0809752345085144
    z[1,0,6]  R247      -5.6399613618850708e-01
    z[1,0,6]  R248      -4.2653882503509521e-01
    z[1,0,6]  R249      0.0916639119386673
    z[1,0,6]  R250      -1.9922468066215515e-01
    z[1,0,6]  R251      -3.9484897255897522e-01
    z[1,0,6]  R252      -1.5126320719718933e-01
    z[1,0,6]  R253      -1.7614209651947021e-01
    z[1,0,6]  R254      2.0841492712497711e-01
    z[1,0,6]  R255      -1.9602052867412567e-01
    z[1,0,6]  R256      2.3536202311515808e-01
    z[1,0,6]  R257      2.4352371692657471e-01
    z[1,0,6]  R258      3.8144532591104507e-02
    z[1,0,6]  R259      -1.2850385904312134e-01
    z[1,0,6]  R260      3.3987239003181458e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R261      -1
    z[0,3,0]  R262      1
    z[0,3,0]  R275      -4.3153684586286545e-02
    z[0,3,0]  R276      5.2086554467678070e-02
    z[0,3,0]  R277      -2.2197312116622925e-01
    z[0,3,0]  R278      1.3185174763202667e-01
    z[0,3,0]  R279      6.8412564694881439e-02
    z[0,3,0]  R280      4.4637724757194519e-01
    z[0,3,0]  R281      -3.6403915286064148e-01
    z[0,3,0]  R282      3.9958283305168152e-01
    z[0,3,0]  R283      -0.177352175116539
    z[0,3,0]  R284      8.5280239582061768e-01
    z[0,3,0]  R285      -2.0526976883411407e-01
    z[0,3,0]  R286      7.6757740974426270e-01
    z[0,3,0]  R287      -1.4529375731945038e-01
    z[0,3,0]  R288      -1.0966448113322258e-02
    z[0,3,0]  R289      -4.7159242630004883e-01
    z[0,3,0]  R290      -7.3068559169769287e-01
    z[0,3,0]  R291      -7.9364633560180664e-01
    z[0,3,0]  R292      -5.7123059034347534e-01
    z[0,3,0]  R293      -4.3389741331338882e-02
    z[0,3,0]  R294      -3.3598536252975464e-01
    z[0,3,0]  R295      -1.3736425340175629e-01
    z[0,3,0]  R296      -1.7194937914609909e-02
    z[0,3,0]  R297      -2.6216366887092590e-01
    z[0,3,0]  R298      -1.3007973134517670e-01
    z[0,3,0]  R299      -2.7309054136276245e-01
    z[0,3,0]  R300      2.5507912039756775e-01
    z[0,3,0]  R301      1.9507057964801788e-01
    z[0,3,0]  R302      3.6697140336036682e-01
    z[0,3,0]  R303      2.8205236792564392e-01
    z[0,3,0]  R304      4.2801365256309509e-01
    z[0,3,0]  R305      -6.6984174773097038e-03
    z[0,3,0]  R306      -1.2007335573434830e-01
    z[0,3,0]  R307      1.9108036160469055e-01
    z[0,3,0]  R308      -1.9672195613384247e-01
    z[0,3,0]  R309      -4.0340952575206757e-02
    z[0,3,0]  R310      -2.1231804788112640e-01
    z[0,3,0]  R311      -1.6643962264060974e-01
    z[0,3,0]  R312      3.2462522387504578e-01
    z[0,3,0]  R313      2.2524490952491760e-02
    z[0,3,0]  R314      -7.1754038333892822e-02
    z[0,3,0]  R315      -6.2028553336858749e-02
    z[0,3,0]  R316      6.4146465063095093e-01
    z[0,3,0]  R317      4.4850829243659973e-01
    z[0,3,0]  R318      6.4898796379566193e-02
    z[0,3,0]  R319      -7.6559305191040039e-01
    z[0,3,0]  R320      2.0446164906024933e-01
    z[0,3,0]  R321      7.6459348201751709e-01
    z[0,3,0]  R322      5.7732760906219482e-01
    z[0,3,0]  R323      2.6761946082115173e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R263      -1
    z[0,3,1]  R264      1
    z[0,3,1]  R275      -2.6194134354591370e-01
    z[0,3,1]  R276      -9.3748994171619415e-02
    z[0,3,1]  R277      -4.0664568543434143e-01
    z[0,3,1]  R278      8.0268484354019165e-01
    z[0,3,1]  R279      7.7266335487365723e-01
    z[0,3,1]  R280      -2.5754824280738831e-01
    z[0,3,1]  R281      3.7568348646163940e-01
    z[0,3,1]  R282      -3.2684612274169922e-01
    z[0,3,1]  R283      1.9955655932426453e-01
    z[0,3,1]  R284      -8.0468125641345978e-02
    z[0,3,1]  R285      -8.7620508670806885e-01
    z[0,3,1]  R286      -2.1219870448112488e-01
    z[0,3,1]  R287      -2.3760265111923218e-01
    z[0,3,1]  R288      -3.7017947435379028e-01
    z[0,3,1]  R289      7.0989185571670532e-01
    z[0,3,1]  R290      5.0783967971801758e-01
    z[0,3,1]  R291      3.9515414834022522e-01
    z[0,3,1]  R292      4.0462940931320190e-01
    z[0,3,1]  R293      -5.6281000375747681e-01
    z[0,3,1]  R294      4.6903070807456970e-01
    z[0,3,1]  R295      -0.431801438331604
    z[0,3,1]  R296      8.1538873910903931e-01
    z[0,3,1]  R297      7.1509200334548950e-01
    z[0,3,1]  R298      8.2887017726898193e-01
    z[0,3,1]  R299      6.8158239126205444e-01
    z[0,3,1]  R300      8.4231895208358765e-01
    z[0,3,1]  R301      -3.0789560079574585e-01
    z[0,3,1]  R302      -1.8975988030433655e-01
    z[0,3,1]  R303      -1.4079466462135315e-01
    z[0,3,1]  R304      -3.1250080466270447e-01
    z[0,3,1]  R305      8.7949460744857788e-01
    z[0,3,1]  R306      8.0771207809448242e-01
    z[0,3,1]  R307      -2.9321369528770447e-01
    z[0,3,1]  R308      6.1159390211105347e-01
    z[0,3,1]  R309      7.3790258169174194e-01
    z[0,3,1]  R310      -8.2718676328659058e-01
    z[0,3,1]  R311      -1.9574034959077835e-02
    z[0,3,1]  R312      2.7573844790458679e-01
    z[0,3,1]  R313      9.1792166233062744e-01
    z[0,3,1]  R314      0.639064371585846
    z[0,3,1]  R315      5.9099310636520386e-01
    z[0,3,1]  R316      5.3242707252502441e-01
    z[0,3,1]  R317      5.2474248409271240e-01
    z[0,3,1]  R318      -3.7084934115409851e-01
    z[0,3,1]  R319      -1.4658871293067932e-01
    z[0,3,1]  R320      9.1791230440139771e-01
    z[0,3,1]  R321      4.5774844288825989e-01
    z[0,3,1]  R322      4.1560354828834534e-01
    z[0,3,1]  R323      2.2112429141998291e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R265      -1
    z[0,3,2]  R266      1
    z[0,3,2]  R275      -5.2365267276763916e-01
    z[0,3,2]  R276      -1.3694140315055847e-01
    z[0,3,2]  R277      -1.9229413568973541e-01
    z[0,3,2]  R278      5.0728845596313477e-01
    z[0,3,2]  R279      1.1383360624313354e-01
    z[0,3,2]  R280      -4.5427742600440979e-01
    z[0,3,2]  R281      -4.1681605577468872e-01
    z[0,3,2]  R282      5.0395107269287109e-01
    z[0,3,2]  R283      -6.1691653728485107e-01
    z[0,3,2]  R284      -1.8926786258816719e-02
    z[0,3,2]  R285      2.7228688821196556e-02
    z[0,3,2]  R286      1.8873456120491028e-01
    z[0,3,2]  R287      -3.1726989895105362e-02
    z[0,3,2]  R288      0.720365047454834
    z[0,3,2]  R289      -2.2949756681919098e-01
    z[0,3,2]  R290      1.6310887411236763e-02
    z[0,3,2]  R291      -8.2569479942321777e-02
    z[0,3,2]  R292      -6.8585580587387085e-01
    z[0,3,2]  R293      -2.1133400499820709e-01
    z[0,3,2]  R294      -1.6055570542812347e-01
    z[0,3,2]  R295      -1.5230628848075867e-01
    z[0,3,2]  R296      -3.3396747708320618e-01
    z[0,3,2]  R297      4.7846347093582153e-02
    z[0,3,2]  R298      1.4736245386302471e-02
    z[0,3,2]  R299      3.0269041657447815e-01
    z[0,3,2]  R300      -6.8288013339042664e-02
    z[0,3,2]  R301      -8.3451753854751587e-01
    z[0,3,2]  R302      -5.3803157806396484e-01
    z[0,3,2]  R303      -6.9472914934158325e-01
    z[0,3,2]  R304      4.9458426237106323e-01
    z[0,3,2]  R305      2.0030254125595093e-01
    z[0,3,2]  R306      1.0673587024211884e-01
    z[0,3,2]  R307      -7.4285753071308136e-03
    z[0,3,2]  R308      4.1735753417015076e-01
    z[0,3,2]  R309      6.6532902419567108e-02
    z[0,3,2]  R310      0.0728011205792427
    z[0,3,2]  R311      2.9511865973472595e-01
    z[0,3,2]  R312      3.4283375740051270e-01
    z[0,3,2]  R313      -1.6079235076904297e-01
    z[0,3,2]  R314      -3.3767473697662354e-01
    z[0,3,2]  R315      -3.2790860533714294e-01
    z[0,3,2]  R316      -5.1845133304595947e-02
    z[0,3,2]  R317      -2.5522774457931519e-01
    z[0,3,2]  R318      -6.3111357390880585e-02
    z[0,3,2]  R319      -1.9181032478809357e-01
    z[0,3,2]  R320      -2.4847300350666046e-01
    z[0,3,2]  R321      1.2886928394436836e-02
    z[0,3,2]  R322      9.4998374581336975e-02
    z[0,3,2]  R323      1.7322087287902832e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R267      -1
    z[0,3,3]  R268      1
    z[0,3,3]  R275      -7.5549614429473877e-01
    z[0,3,3]  R276      -2.1462583541870117e-01
    z[0,3,3]  R277      -7.1629685163497925e-01
    z[0,3,3]  R278      6.2352091073989868e-02
    z[0,3,3]  R279      -5.7097494602203369e-01
    z[0,3,3]  R280      0.345376580953598
    z[0,3,3]  R281      6.1128032207489014e-01
    z[0,3,3]  R282      1.4581255614757538e-01
    z[0,3,3]  R283      2.9678994417190552e-01
    z[0,3,3]  R284      -2.9740965366363525e-01
    z[0,3,3]  R285      4.0162914991378784e-01
    z[0,3,3]  R286      -4.9689021706581116e-01
    z[0,3,3]  R287      -2.5493571162223816e-01
    z[0,3,3]  R288      4.1132317855954170e-03
    z[0,3,3]  R289      4.5277667045593262e-01
    z[0,3,3]  R290      -1.7219153046607971e-01
    z[0,3,3]  R291      1.4373475313186646e-01
    z[0,3,3]  R292      -1.1241341382265091e-01
    z[0,3,3]  R293      1.3597184419631958e-01
    z[0,3,3]  R294      -2.8878791257739067e-02
    z[0,3,3]  R295      -6.7838227748870850e-01
    z[0,3,3]  R296      -3.2856807112693787e-01
    z[0,3,3]  R297      -8.9747928082942963e-02
    z[0,3,3]  R298      -1.5022800862789154e-01
    z[0,3,3]  R299      -4.1903233528137207e-01
    z[0,3,3]  R300      0.0640232115983963
    z[0,3,3]  R301      -2.2028996050357819e-01
    z[0,3,3]  R302      4.5112804509699345e-03
    z[0,3,3]  R303      -9.2413641512393951e-02
    z[0,3,3]  R304      1.6334348917007446e-01
    z[0,3,3]  R305      3.7057507038116455e-01
    z[0,3,3]  R306      2.2839917242527008e-01
    z[0,3,3]  R307      9.1190433502197266e-01
    z[0,3,3]  R308      3.6685898900032043e-01
    z[0,3,3]  R309      -5.8687359094619751e-01
    z[0,3,3]  R310      -2.3282991722226143e-02
    z[0,3,3]  R311      -8.3095425367355347e-01
    z[0,3,3]  R312      6.2877142429351807e-01
    z[0,3,3]  R313      -3.4194779396057129e-01
    z[0,3,3]  R314      -9.1844633221626282e-02
    z[0,3,3]  R315      -1.3687096536159515e-01
    z[0,3,3]  R316      -6.5661981701850891e-02
    z[0,3,3]  R317      3.3971334341913462e-03
    z[0,3,3]  R318      2.2036500275135040e-01
    z[0,3,3]  R319      -1.2398524582386017e-01
    z[0,3,3]  R320      -1.1111178249120712e-01
    z[0,3,3]  R321      3.7004286050796509e-01
    z[0,3,3]  R322      6.8615779280662537e-02
    z[0,3,3]  R323      3.1512069702148438e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R269      -1
    z[0,3,4]  R270      1
    z[0,3,4]  R275      5.8615417219698429e-03
    z[0,3,4]  R276      -9.5988857746124268e-01
    z[0,3,4]  R277      0.0999041348695755
    z[0,3,4]  R278      4.8622693866491318e-02
    z[0,3,4]  R279      3.8620594888925552e-02
    z[0,3,4]  R280      -1.0241254419088364e-01
    z[0,3,4]  R281      2.5241738557815552e-01
    z[0,3,4]  R282      -7.7295564115047455e-02
    z[0,3,4]  R283      2.0605014637112617e-02
    z[0,3,4]  R284      3.0566453933715820e-03
    z[0,3,4]  R285      6.1652567237615585e-02
    z[0,3,4]  R286      1.4779582619667053e-01
    z[0,3,4]  R287      1.3673785328865051e-01
    z[0,3,4]  R288      1.3951939344406128e-01
    z[0,3,4]  R289      -4.6789102256298065e-02
    z[0,3,4]  R290      -3.4566748887300491e-02
    z[0,3,4]  R291      -3.4867439419031143e-02
    z[0,3,4]  R292      -6.1316180974245071e-02
    z[0,3,4]  R293      0.754446804523468
    z[0,3,4]  R294      5.3235971927642822e-01
    z[0,3,4]  R295      6.6080227494239807e-02
    z[0,3,4]  R296      -1.9636349380016327e-01
    z[0,3,4]  R297      0.305124968290329
    z[0,3,4]  R298      5.0762075185775757e-01
    z[0,3,4]  R299      -4.0650421380996704e-01
    z[0,3,4]  R300      -2.2837018966674805e-01
    z[0,3,4]  R301      -1.9618004560470581e-01
    z[0,3,4]  R302      -6.9654053449630737e-01
    z[0,3,4]  R303      1.1855020374059677e-01
    z[0,3,4]  R304      -7.7682077884674072e-02
    z[0,3,4]  R305      1.7610885202884674e-01
    z[0,3,4]  R306      -2.0498606562614441e-01
    z[0,3,4]  R307      4.0441237390041351e-02
    z[0,3,4]  R308      -4.0657272934913635e-01
    z[0,3,4]  R309      2.4739861488342285e-01
    z[0,3,4]  R310      3.6312833428382874e-01
    z[0,3,4]  R311      -2.2240689396858215e-01
    z[0,3,4]  R312      -1.9664157927036285e-01
    z[0,3,4]  R313      7.5480744242668152e-02
    z[0,3,4]  R314      2.3989711701869965e-01
    z[0,3,4]  R315      2.7705314755439758e-01
    z[0,3,4]  R316      2.3794779181480408e-01
    z[0,3,4]  R317      1.7909948527812958e-01
    z[0,3,4]  R318      -1.1399597674608231e-01
    z[0,3,4]  R319      -5.6032204627990723e-01
    z[0,3,4]  R320      -1.2320470996201038e-02
    z[0,3,4]  R321      2.4691355228424072e-01
    z[0,3,4]  R322      6.8836772441864014e-01
    z[0,3,4]  R323      8.6080354452133179e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R271      -1
    z[0,3,5]  R272      1
    z[0,3,5]  R275      -2.0393329858779907e-01
    z[0,3,5]  R276      -1.7240921035408974e-02
    z[0,3,5]  R277      -3.3184146881103516e-01
    z[0,3,5]  R278      -4.0281414985656738e-02
    z[0,3,5]  R279      2.2710794210433960e-01
    z[0,3,5]  R280      6.1952596902847290e-01
    z[0,3,5]  R281      -1.9208236038684845e-01
    z[0,3,5]  R282      -5.5004042387008667e-01
    z[0,3,5]  R283      2.0833095908164978e-01
    z[0,3,5]  R284      -3.6512249708175659e-01
    z[0,3,5]  R285      -1.5249180793762207e-01
    z[0,3,5]  R286      2.3425480723381042e-01
    z[0,3,5]  R287      7.2086542844772339e-01
    z[0,3,5]  R288      3.7749585509300232e-01
    z[0,3,5]  R289      7.3394723236560822e-02
    z[0,3,5]  R290      -3.7066987156867981e-01
    z[0,3,5]  R291      1.7140556871891022e-01
    z[0,3,5]  R292      -1.7189081758260727e-02
    z[0,3,5]  R293      1.3414807617664337e-01
    z[0,3,5]  R294      -5.6006091833114624e-01
    z[0,3,5]  R295      -5.1815855503082275e-01
    z[0,3,5]  R296      -1.4628899097442627e-01
    z[0,3,5]  R297      -5.0711417198181152e-01
    z[0,3,5]  R298      1.1888663470745087e-01
    z[0,3,5]  R299      -1.0908074676990509e-01
    z[0,3,5]  R300      2.2137090563774109e-01
    z[0,3,5]  R301      -2.8327253460884094e-01
    z[0,3,5]  R302      -5.5435862392187119e-02
    z[0,3,5]  R303      -4.5814013481140137e-01
    z[0,3,5]  R304      -0.571395218372345
    z[0,3,5]  R305      -1.3369980454444885e-01
    z[0,3,5]  R306      -3.6823821067810059e-01
    z[0,3,5]  R307      -0.0757163017988205
    z[0,3,5]  R308      2.4088194966316223e-01
    z[0,3,5]  R309      8.3779737353324890e-02
    z[0,3,5]  R310      3.4886193275451660e-01
    z[0,3,5]  R311      -1.5392936766147614e-02
    z[0,3,5]  R312      -5.1585435867309570e-01
    z[0,3,5]  R313      -9.1138131916522980e-02
    z[0,3,5]  R314      6.3751161098480225e-01
    z[0,3,5]  R315      6.6132062673568726e-01
    z[0,3,5]  R316      4.8494762182235718e-01
    z[0,3,5]  R317      6.5178465843200684e-01
    z[0,3,5]  R318      -8.6875444650650024e-01
    z[0,3,5]  R319      1.5387354791164398e-01
    z[0,3,5]  R320      1.9965665042400360e-01
    z[0,3,5]  R321      8.0717802047729492e-02
    z[0,3,5]  R322      2.8737673535943031e-02
    z[0,3,5]  R323      -7.9404406249523163e-02
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R273      -1
    z[0,3,6]  R274      1
    z[0,3,6]  R275      2.0715892314910889e-01
    z[0,3,6]  R276      4.4695157557725906e-02
    z[0,3,6]  R277      -3.3942502737045288e-01
    z[0,3,6]  R278      2.7036279439926147e-01
    z[0,3,6]  R279      -7.9190358519554138e-02
    z[0,3,6]  R280      1.2026077508926392e-01
    z[0,3,6]  R281      2.7987170219421387e-01
    z[0,3,6]  R282      3.8698580861091614e-01
    z[0,3,6]  R283      -6.4515638351440430e-01
    z[0,3,6]  R284      2.1004404127597809e-01
    z[0,3,6]  R285      -3.2044053077697754e-02
    z[0,3,6]  R286      0.0809752345085144
    z[0,3,6]  R287      -5.6399613618850708e-01
    z[0,3,6]  R288      -4.2653882503509521e-01
    z[0,3,6]  R289      0.0916639119386673
    z[0,3,6]  R290      -1.9922468066215515e-01
    z[0,3,6]  R291      -3.9484897255897522e-01
    z[0,3,6]  R292      -1.5126320719718933e-01
    z[0,3,6]  R293      -1.7614209651947021e-01
    z[0,3,6]  R294      2.0841492712497711e-01
    z[0,3,6]  R295      -1.9602052867412567e-01
    z[0,3,6]  R296      2.3536202311515808e-01
    z[0,3,6]  R297      2.4352371692657471e-01
    z[0,3,6]  R298      3.8144532591104507e-02
    z[0,3,6]  R299      -1.2850385904312134e-01
    z[0,3,6]  R300      3.3987239003181458e-01
    z[0,3,6]  R301      5.8912258595228195e-02
    z[0,3,6]  R302      -2.2711883485317230e-01
    z[0,3,6]  R303      -4.3068295717239380e-01
    z[0,3,6]  R304      0.339596688747406
    z[0,3,6]  R305      -1.0362610220909119e-02
    z[0,3,6]  R306      -3.0332520604133606e-01
    z[0,3,6]  R307      -1.9626735150814056e-01
    z[0,3,6]  R308      2.3485115170478821e-01
    z[0,3,6]  R309      1.9183342158794403e-01
    z[0,3,6]  R310      1.0617990791797638e-01
    z[0,3,6]  R311      0.380306214094162
    z[0,3,6]  R312      3.0408294871449471e-02
    z[0,3,6]  R313      1.1247279122471809e-02
    z[0,3,6]  R314      4.0876977145671844e-03
    z[0,3,6]  R315      -0.0807369276881218
    z[0,3,6]  R316      0.0790676400065422
    z[0,3,6]  R317      -0.0378536619246006
    z[0,3,6]  R318      -1.9489973783493042e-01
    z[0,3,6]  R319      -5.0770029425621033e-02
    z[0,3,6]  R320      -3.9156213402748108e-02
    z[0,3,6]  R321      -3.5827852785587311e-02
    z[0,3,6]  R322      7.4549503624439240e-02
    z[0,3,6]  R323      -5.3753387182950974e-02
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R324      -1
    z[3,0,0]  R325      1
    z[3,0,0]  R338      1.9507057964801788e-01
    z[3,0,0]  R339      3.6697140336036682e-01
    z[3,0,0]  R340      2.8205236792564392e-01
    z[3,0,0]  R341      4.2801365256309509e-01
    z[3,0,0]  R342      -6.6984174773097038e-03
    z[3,0,0]  R343      -1.2007335573434830e-01
    z[3,0,0]  R344      1.9108036160469055e-01
    z[3,0,0]  R345      -1.9672195613384247e-01
    z[3,0,0]  R346      -4.0340952575206757e-02
    z[3,0,0]  R347      -2.1231804788112640e-01
    z[3,0,0]  R348      -1.6643962264060974e-01
    z[3,0,0]  R349      3.2462522387504578e-01
    z[3,0,0]  R350      2.2524490952491760e-02
    z[3,0,0]  R351      -7.1754038333892822e-02
    z[3,0,0]  R352      -6.2028553336858749e-02
    z[3,0,0]  R353      6.4146465063095093e-01
    z[3,0,0]  R354      4.4850829243659973e-01
    z[3,0,0]  R355      6.4898796379566193e-02
    z[3,0,0]  R356      -7.6559305191040039e-01
    z[3,0,0]  R357      2.0446164906024933e-01
    z[3,0,0]  R358      7.6459348201751709e-01
    z[3,0,0]  R359      5.7732760906219482e-01
    z[3,0,0]  R360      2.6761946082115173e-01
    z[3,0,0]  R361      -4.3153684586286545e-02
    z[3,0,0]  R362      5.2086554467678070e-02
    z[3,0,0]  R363      -2.2197312116622925e-01
    z[3,0,0]  R364      1.3185174763202667e-01
    z[3,0,0]  R365      6.8412564694881439e-02
    z[3,0,0]  R366      4.4637724757194519e-01
    z[3,0,0]  R367      -3.6403915286064148e-01
    z[3,0,0]  R368      3.9958283305168152e-01
    z[3,0,0]  R369      -0.177352175116539
    z[3,0,0]  R370      8.5280239582061768e-01
    z[3,0,0]  R371      -2.0526976883411407e-01
    z[3,0,0]  R372      7.6757740974426270e-01
    z[3,0,0]  R373      -1.4529375731945038e-01
    z[3,0,0]  R374      -1.0966448113322258e-02
    z[3,0,0]  R375      -4.7159242630004883e-01
    z[3,0,0]  R376      -7.3068559169769287e-01
    z[3,0,0]  R377      -7.9364633560180664e-01
    z[3,0,0]  R378      -5.7123059034347534e-01
    z[3,0,0]  R379      -4.3389741331338882e-02
    z[3,0,0]  R380      -3.3598536252975464e-01
    z[3,0,0]  R381      -1.3736425340175629e-01
    z[3,0,0]  R382      -1.7194937914609909e-02
    z[3,0,0]  R383      -2.6216366887092590e-01
    z[3,0,0]  R384      -1.3007973134517670e-01
    z[3,0,0]  R385      -2.7309054136276245e-01
    z[3,0,0]  R386      2.5507912039756775e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R326      -1
    z[3,0,1]  R327      1
    z[3,0,1]  R338      -3.0789560079574585e-01
    z[3,0,1]  R339      -1.8975988030433655e-01
    z[3,0,1]  R340      -1.4079466462135315e-01
    z[3,0,1]  R341      -3.1250080466270447e-01
    z[3,0,1]  R342      8.7949460744857788e-01
    z[3,0,1]  R343      8.0771207809448242e-01
    z[3,0,1]  R344      -2.9321369528770447e-01
    z[3,0,1]  R345      6.1159390211105347e-01
    z[3,0,1]  R346      7.3790258169174194e-01
    z[3,0,1]  R347      -8.2718676328659058e-01
    z[3,0,1]  R348      -1.9574034959077835e-02
    z[3,0,1]  R349      2.7573844790458679e-01
    z[3,0,1]  R350      9.1792166233062744e-01
    z[3,0,1]  R351      0.639064371585846
    z[3,0,1]  R352      5.9099310636520386e-01
    z[3,0,1]  R353      5.3242707252502441e-01
    z[3,0,1]  R354      5.2474248409271240e-01
    z[3,0,1]  R355      -3.7084934115409851e-01
    z[3,0,1]  R356      -1.4658871293067932e-01
    z[3,0,1]  R357      9.1791230440139771e-01
    z[3,0,1]  R358      4.5774844288825989e-01
    z[3,0,1]  R359      4.1560354828834534e-01
    z[3,0,1]  R360      2.2112429141998291e-01
    z[3,0,1]  R361      -2.6194134354591370e-01
    z[3,0,1]  R362      -9.3748994171619415e-02
    z[3,0,1]  R363      -4.0664568543434143e-01
    z[3,0,1]  R364      8.0268484354019165e-01
    z[3,0,1]  R365      7.7266335487365723e-01
    z[3,0,1]  R366      -2.5754824280738831e-01
    z[3,0,1]  R367      3.7568348646163940e-01
    z[3,0,1]  R368      -3.2684612274169922e-01
    z[3,0,1]  R369      1.9955655932426453e-01
    z[3,0,1]  R370      -8.0468125641345978e-02
    z[3,0,1]  R371      -8.7620508670806885e-01
    z[3,0,1]  R372      -2.1219870448112488e-01
    z[3,0,1]  R373      -2.3760265111923218e-01
    z[3,0,1]  R374      -3.7017947435379028e-01
    z[3,0,1]  R375      7.0989185571670532e-01
    z[3,0,1]  R376      5.0783967971801758e-01
    z[3,0,1]  R377      3.9515414834022522e-01
    z[3,0,1]  R378      4.0462940931320190e-01
    z[3,0,1]  R379      -5.6281000375747681e-01
    z[3,0,1]  R380      4.6903070807456970e-01
    z[3,0,1]  R381      -0.431801438331604
    z[3,0,1]  R382      8.1538873910903931e-01
    z[3,0,1]  R383      7.1509200334548950e-01
    z[3,0,1]  R384      8.2887017726898193e-01
    z[3,0,1]  R385      6.8158239126205444e-01
    z[3,0,1]  R386      8.4231895208358765e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R328      -1
    z[3,0,2]  R329      1
    z[3,0,2]  R338      -8.3451753854751587e-01
    z[3,0,2]  R339      -5.3803157806396484e-01
    z[3,0,2]  R340      -6.9472914934158325e-01
    z[3,0,2]  R341      4.9458426237106323e-01
    z[3,0,2]  R342      2.0030254125595093e-01
    z[3,0,2]  R343      1.0673587024211884e-01
    z[3,0,2]  R344      -7.4285753071308136e-03
    z[3,0,2]  R345      4.1735753417015076e-01
    z[3,0,2]  R346      6.6532902419567108e-02
    z[3,0,2]  R347      0.0728011205792427
    z[3,0,2]  R348      2.9511865973472595e-01
    z[3,0,2]  R349      3.4283375740051270e-01
    z[3,0,2]  R350      -1.6079235076904297e-01
    z[3,0,2]  R351      -3.3767473697662354e-01
    z[3,0,2]  R352      -3.2790860533714294e-01
    z[3,0,2]  R353      -5.1845133304595947e-02
    z[3,0,2]  R354      -2.5522774457931519e-01
    z[3,0,2]  R355      -6.3111357390880585e-02
    z[3,0,2]  R356      -1.9181032478809357e-01
    z[3,0,2]  R357      -2.4847300350666046e-01
    z[3,0,2]  R358      1.2886928394436836e-02
    z[3,0,2]  R359      9.4998374581336975e-02
    z[3,0,2]  R360      1.7322087287902832e-01
    z[3,0,2]  R361      -5.2365267276763916e-01
    z[3,0,2]  R362      -1.3694140315055847e-01
    z[3,0,2]  R363      -1.9229413568973541e-01
    z[3,0,2]  R364      5.0728845596313477e-01
    z[3,0,2]  R365      1.1383360624313354e-01
    z[3,0,2]  R366      -4.5427742600440979e-01
    z[3,0,2]  R367      -4.1681605577468872e-01
    z[3,0,2]  R368      5.0395107269287109e-01
    z[3,0,2]  R369      -6.1691653728485107e-01
    z[3,0,2]  R370      -1.8926786258816719e-02
    z[3,0,2]  R371      2.7228688821196556e-02
    z[3,0,2]  R372      1.8873456120491028e-01
    z[3,0,2]  R373      -3.1726989895105362e-02
    z[3,0,2]  R374      0.720365047454834
    z[3,0,2]  R375      -2.2949756681919098e-01
    z[3,0,2]  R376      1.6310887411236763e-02
    z[3,0,2]  R377      -8.2569479942321777e-02
    z[3,0,2]  R378      -6.8585580587387085e-01
    z[3,0,2]  R379      -2.1133400499820709e-01
    z[3,0,2]  R380      -1.6055570542812347e-01
    z[3,0,2]  R381      -1.5230628848075867e-01
    z[3,0,2]  R382      -3.3396747708320618e-01
    z[3,0,2]  R383      4.7846347093582153e-02
    z[3,0,2]  R384      1.4736245386302471e-02
    z[3,0,2]  R385      3.0269041657447815e-01
    z[3,0,2]  R386      -6.8288013339042664e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R330      -1
    z[3,0,3]  R331      1
    z[3,0,3]  R338      -2.2028996050357819e-01
    z[3,0,3]  R339      4.5112804509699345e-03
    z[3,0,3]  R340      -9.2413641512393951e-02
    z[3,0,3]  R341      1.6334348917007446e-01
    z[3,0,3]  R342      3.7057507038116455e-01
    z[3,0,3]  R343      2.2839917242527008e-01
    z[3,0,3]  R344      9.1190433502197266e-01
    z[3,0,3]  R345      3.6685898900032043e-01
    z[3,0,3]  R346      -5.8687359094619751e-01
    z[3,0,3]  R347      -2.3282991722226143e-02
    z[3,0,3]  R348      -8.3095425367355347e-01
    z[3,0,3]  R349      6.2877142429351807e-01
    z[3,0,3]  R350      -3.4194779396057129e-01
    z[3,0,3]  R351      -9.1844633221626282e-02
    z[3,0,3]  R352      -1.3687096536159515e-01
    z[3,0,3]  R353      -6.5661981701850891e-02
    z[3,0,3]  R354      3.3971334341913462e-03
    z[3,0,3]  R355      2.2036500275135040e-01
    z[3,0,3]  R356      -1.2398524582386017e-01
    z[3,0,3]  R357      -1.1111178249120712e-01
    z[3,0,3]  R358      3.7004286050796509e-01
    z[3,0,3]  R359      6.8615779280662537e-02
    z[3,0,3]  R360      3.1512069702148438e-01
    z[3,0,3]  R361      -7.5549614429473877e-01
    z[3,0,3]  R362      -2.1462583541870117e-01
    z[3,0,3]  R363      -7.1629685163497925e-01
    z[3,0,3]  R364      6.2352091073989868e-02
    z[3,0,3]  R365      -5.7097494602203369e-01
    z[3,0,3]  R366      0.345376580953598
    z[3,0,3]  R367      6.1128032207489014e-01
    z[3,0,3]  R368      1.4581255614757538e-01
    z[3,0,3]  R369      2.9678994417190552e-01
    z[3,0,3]  R370      -2.9740965366363525e-01
    z[3,0,3]  R371      4.0162914991378784e-01
    z[3,0,3]  R372      -4.9689021706581116e-01
    z[3,0,3]  R373      -2.5493571162223816e-01
    z[3,0,3]  R374      4.1132317855954170e-03
    z[3,0,3]  R375      4.5277667045593262e-01
    z[3,0,3]  R376      -1.7219153046607971e-01
    z[3,0,3]  R377      1.4373475313186646e-01
    z[3,0,3]  R378      -1.1241341382265091e-01
    z[3,0,3]  R379      1.3597184419631958e-01
    z[3,0,3]  R380      -2.8878791257739067e-02
    z[3,0,3]  R381      -6.7838227748870850e-01
    z[3,0,3]  R382      -3.2856807112693787e-01
    z[3,0,3]  R383      -8.9747928082942963e-02
    z[3,0,3]  R384      -1.5022800862789154e-01
    z[3,0,3]  R385      -4.1903233528137207e-01
    z[3,0,3]  R386      0.0640232115983963
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R332      -1
    z[3,0,4]  R333      1
    z[3,0,4]  R338      -1.9618004560470581e-01
    z[3,0,4]  R339      -6.9654053449630737e-01
    z[3,0,4]  R340      1.1855020374059677e-01
    z[3,0,4]  R341      -7.7682077884674072e-02
    z[3,0,4]  R342      1.7610885202884674e-01
    z[3,0,4]  R343      -2.0498606562614441e-01
    z[3,0,4]  R344      4.0441237390041351e-02
    z[3,0,4]  R345      -4.0657272934913635e-01
    z[3,0,4]  R346      2.4739861488342285e-01
    z[3,0,4]  R347      3.6312833428382874e-01
    z[3,0,4]  R348      -2.2240689396858215e-01
    z[3,0,4]  R349      -1.9664157927036285e-01
    z[3,0,4]  R350      7.5480744242668152e-02
    z[3,0,4]  R351      2.3989711701869965e-01
    z[3,0,4]  R352      2.7705314755439758e-01
    z[3,0,4]  R353      2.3794779181480408e-01
    z[3,0,4]  R354      1.7909948527812958e-01
    z[3,0,4]  R355      -1.1399597674608231e-01
    z[3,0,4]  R356      -5.6032204627990723e-01
    z[3,0,4]  R357      -1.2320470996201038e-02
    z[3,0,4]  R358      2.4691355228424072e-01
    z[3,0,4]  R359      6.8836772441864014e-01
    z[3,0,4]  R360      8.6080354452133179e-01
    z[3,0,4]  R361      5.8615417219698429e-03
    z[3,0,4]  R362      -9.5988857746124268e-01
    z[3,0,4]  R363      0.0999041348695755
    z[3,0,4]  R364      4.8622693866491318e-02
    z[3,0,4]  R365      3.8620594888925552e-02
    z[3,0,4]  R366      -1.0241254419088364e-01
    z[3,0,4]  R367      2.5241738557815552e-01
    z[3,0,4]  R368      -7.7295564115047455e-02
    z[3,0,4]  R369      2.0605014637112617e-02
    z[3,0,4]  R370      3.0566453933715820e-03
    z[3,0,4]  R371      6.1652567237615585e-02
    z[3,0,4]  R372      1.4779582619667053e-01
    z[3,0,4]  R373      1.3673785328865051e-01
    z[3,0,4]  R374      1.3951939344406128e-01
    z[3,0,4]  R375      -4.6789102256298065e-02
    z[3,0,4]  R376      -3.4566748887300491e-02
    z[3,0,4]  R377      -3.4867439419031143e-02
    z[3,0,4]  R378      -6.1316180974245071e-02
    z[3,0,4]  R379      0.754446804523468
    z[3,0,4]  R380      5.3235971927642822e-01
    z[3,0,4]  R381      6.6080227494239807e-02
    z[3,0,4]  R382      -1.9636349380016327e-01
    z[3,0,4]  R383      0.305124968290329
    z[3,0,4]  R384      5.0762075185775757e-01
    z[3,0,4]  R385      -4.0650421380996704e-01
    z[3,0,4]  R386      -2.2837018966674805e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R334      -1
    z[3,0,5]  R335      1
    z[3,0,5]  R338      -2.8327253460884094e-01
    z[3,0,5]  R339      -5.5435862392187119e-02
    z[3,0,5]  R340      -4.5814013481140137e-01
    z[3,0,5]  R341      -0.571395218372345
    z[3,0,5]  R342      -1.3369980454444885e-01
    z[3,0,5]  R343      -3.6823821067810059e-01
    z[3,0,5]  R344      -0.0757163017988205
    z[3,0,5]  R345      2.4088194966316223e-01
    z[3,0,5]  R346      8.3779737353324890e-02
    z[3,0,5]  R347      3.4886193275451660e-01
    z[3,0,5]  R348      -1.5392936766147614e-02
    z[3,0,5]  R349      -5.1585435867309570e-01
    z[3,0,5]  R350      -9.1138131916522980e-02
    z[3,0,5]  R351      6.3751161098480225e-01
    z[3,0,5]  R352      6.6132062673568726e-01
    z[3,0,5]  R353      4.8494762182235718e-01
    z[3,0,5]  R354      6.5178465843200684e-01
    z[3,0,5]  R355      -8.6875444650650024e-01
    z[3,0,5]  R356      1.5387354791164398e-01
    z[3,0,5]  R357      1.9965665042400360e-01
    z[3,0,5]  R358      8.0717802047729492e-02
    z[3,0,5]  R359      2.8737673535943031e-02
    z[3,0,5]  R360      -7.9404406249523163e-02
    z[3,0,5]  R361      -2.0393329858779907e-01
    z[3,0,5]  R362      -1.7240921035408974e-02
    z[3,0,5]  R363      -3.3184146881103516e-01
    z[3,0,5]  R364      -4.0281414985656738e-02
    z[3,0,5]  R365      2.2710794210433960e-01
    z[3,0,5]  R366      6.1952596902847290e-01
    z[3,0,5]  R367      -1.9208236038684845e-01
    z[3,0,5]  R368      -5.5004042387008667e-01
    z[3,0,5]  R369      2.0833095908164978e-01
    z[3,0,5]  R370      -3.6512249708175659e-01
    z[3,0,5]  R371      -1.5249180793762207e-01
    z[3,0,5]  R372      2.3425480723381042e-01
    z[3,0,5]  R373      7.2086542844772339e-01
    z[3,0,5]  R374      3.7749585509300232e-01
    z[3,0,5]  R375      7.3394723236560822e-02
    z[3,0,5]  R376      -3.7066987156867981e-01
    z[3,0,5]  R377      1.7140556871891022e-01
    z[3,0,5]  R378      -1.7189081758260727e-02
    z[3,0,5]  R379      1.3414807617664337e-01
    z[3,0,5]  R380      -5.6006091833114624e-01
    z[3,0,5]  R381      -5.1815855503082275e-01
    z[3,0,5]  R382      -1.4628899097442627e-01
    z[3,0,5]  R383      -5.0711417198181152e-01
    z[3,0,5]  R384      1.1888663470745087e-01
    z[3,0,5]  R385      -1.0908074676990509e-01
    z[3,0,5]  R386      2.2137090563774109e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R336      -1
    z[3,0,6]  R337      1
    z[3,0,6]  R338      5.8912258595228195e-02
    z[3,0,6]  R339      -2.2711883485317230e-01
    z[3,0,6]  R340      -4.3068295717239380e-01
    z[3,0,6]  R341      0.339596688747406
    z[3,0,6]  R342      -1.0362610220909119e-02
    z[3,0,6]  R343      -3.0332520604133606e-01
    z[3,0,6]  R344      -1.9626735150814056e-01
    z[3,0,6]  R345      2.3485115170478821e-01
    z[3,0,6]  R346      1.9183342158794403e-01
    z[3,0,6]  R347      1.0617990791797638e-01
    z[3,0,6]  R348      0.380306214094162
    z[3,0,6]  R349      3.0408294871449471e-02
    z[3,0,6]  R350      1.1247279122471809e-02
    z[3,0,6]  R351      4.0876977145671844e-03
    z[3,0,6]  R352      -0.0807369276881218
    z[3,0,6]  R353      0.0790676400065422
    z[3,0,6]  R354      -0.0378536619246006
    z[3,0,6]  R355      -1.9489973783493042e-01
    z[3,0,6]  R356      -5.0770029425621033e-02
    z[3,0,6]  R357      -3.9156213402748108e-02
    z[3,0,6]  R358      -3.5827852785587311e-02
    z[3,0,6]  R359      7.4549503624439240e-02
    z[3,0,6]  R360      -5.3753387182950974e-02
    z[3,0,6]  R361      2.0715892314910889e-01
    z[3,0,6]  R362      4.4695157557725906e-02
    z[3,0,6]  R363      -3.3942502737045288e-01
    z[3,0,6]  R364      2.7036279439926147e-01
    z[3,0,6]  R365      -7.9190358519554138e-02
    z[3,0,6]  R366      1.2026077508926392e-01
    z[3,0,6]  R367      2.7987170219421387e-01
    z[3,0,6]  R368      3.8698580861091614e-01
    z[3,0,6]  R369      -6.4515638351440430e-01
    z[3,0,6]  R370      2.1004404127597809e-01
    z[3,0,6]  R371      -3.2044053077697754e-02
    z[3,0,6]  R372      0.0809752345085144
    z[3,0,6]  R373      -5.6399613618850708e-01
    z[3,0,6]  R374      -4.2653882503509521e-01
    z[3,0,6]  R375      0.0916639119386673
    z[3,0,6]  R376      -1.9922468066215515e-01
    z[3,0,6]  R377      -3.9484897255897522e-01
    z[3,0,6]  R378      -1.5126320719718933e-01
    z[3,0,6]  R379      -1.7614209651947021e-01
    z[3,0,6]  R380      2.0841492712497711e-01
    z[3,0,6]  R381      -1.9602052867412567e-01
    z[3,0,6]  R382      2.3536202311515808e-01
    z[3,0,6]  R383      2.4352371692657471e-01
    z[3,0,6]  R384      3.8144532591104507e-02
    z[3,0,6]  R385      -1.2850385904312134e-01
    z[3,0,6]  R386      3.3987239003181458e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R427      -1
    z[1,2,0]  R428      1
    z[1,2,0]  R441      7.2937792539596558e-01
    z[1,2,0]  R442      6.9539844989776611e-01
    z[1,2,0]  R443      6.9143670797348022e-01
    z[1,2,0]  R444      7.0476317405700684e-01
    z[1,2,0]  R445      7.8731817007064819e-01
    z[1,2,0]  R446      6.0982835292816162e-01
    z[1,2,0]  R447      5.1540416479110718e-01
    z[1,2,0]  R448      7.7249638736248016e-02
    z[1,2,0]  R449      2.5266060233116150e-01
    z[1,2,0]  R450      -8.6177125573158264e-02
    z[1,2,0]  R451      -3.7142688035964966e-01
    z[1,2,0]  R452      -4.1751763224601746e-01
    z[1,2,0]  R453      -4.2661333084106445e-01
    z[1,2,0]  R454      -3.9848193526268005e-01
    z[1,2,0]  R455      -5.6802338361740112e-01
    z[1,2,0]  R456      -8.7458425760269165e-01
    z[1,2,0]  R457      -7.4471682310104370e-01
    z[1,2,0]  R458      -5.1511114835739136e-01
    z[1,2,0]  R459      -7.4330282211303711e-01
    z[1,2,0]  R460      -6.4153635501861572e-01
    z[1,2,0]  R461      -5.4495353251695633e-02
    z[1,2,0]  R462      -4.2932775616645813e-01
    z[1,2,0]  R463      1.1912572383880615e-01
    z[1,2,0]  R464      -2.8554797172546387e-01
    z[1,2,0]  R465      -2.1602143347263336e-01
    z[1,2,0]  R466      -3.7890213727951050e-01
    z[1,2,0]  R467      -5.5686873197555542e-01
    z[1,2,0]  R468      -4.8718467354774475e-01
    z[1,2,0]  R469      -4.3907305598258972e-01
    z[1,2,0]  R470      -4.4557729363441467e-01
    z[1,2,0]  R471      -7.9904294013977051e-01
    z[1,2,0]  R472      -3.9945688843727112e-01
    z[1,2,0]  R473      -6.6743910312652588e-01
    z[1,2,0]  R474      -1.1624854523688555e-03
    z[1,2,0]  R475      -6.3050216436386108e-01
    z[1,2,0]  R476      -4.2749956250190735e-01
    z[1,2,0]  R477      -2.7416041493415833e-01
    z[1,2,0]  R478      -5.4435908794403076e-01
    z[1,2,0]  R479      -3.5789293050765991e-01
    z[1,2,0]  R480      -6.7111587524414062e-01
    z[1,2,0]  R481      -3.8206443190574646e-02
    z[1,2,0]  R482      9.3746766448020935e-02
    z[1,2,0]  R483      -2.5218451023101807e-01
    z[1,2,0]  R484      3.6683419346809387e-01
    z[1,2,0]  R485      -1.7070950567722321e-01
    z[1,2,0]  R486      -5.6910580024123192e-03
    z[1,2,0]  R487      5.5773887783288956e-02
    z[1,2,0]  R488      -0.363533616065979
    z[1,2,0]  R489      -4.9560809135437012e-01
    z[1,2,0]  R490      1.2669922411441803e-01
    z[1,2,0]  R491      -3.3879640698432922e-01
    z[1,2,0]  R492      -1.6045930981636047e-01
    z[1,2,0]  R493      -1.5793561935424805e-01
    z[1,2,0]  R494      1.4118921756744385e-01
    z[1,2,0]  R495      1.1255958117544651e-02
    z[1,2,0]  R496      -2.9204767942428589e-01
    z[1,2,0]  R497      -2.5073906779289246e-01
    z[1,2,0]  R498      1.8377426266670227e-01
    z[1,2,0]  R499      3.3180419355630875e-02
    z[1,2,0]  R500      1.8592732027173042e-02
    z[1,2,0]  R501      1.6429834067821503e-01
    z[1,2,0]  R502      -7.3716074228286743e-02
    z[1,2,0]  R503      -0.0692955031991005
    z[1,2,0]  R504      6.9407053291797638e-02
    z[1,2,0]  R505      7.7760502696037292e-02
    z[1,2,0]  R506      -9.0459384024143219e-02
    z[1,2,0]  R507      2.0266753435134888e-01
    z[1,2,0]  R508      -9.5341032743453979e-01
    z[1,2,0]  R509      -7.9527717828750610e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R429      -1
    z[1,2,1]  R430      1
    z[1,2,1]  R441      1.3337233662605286e-01
    z[1,2,1]  R442      -2.2710485756397247e-01
    z[1,2,1]  R443      -2.5684958696365356e-01
    z[1,2,1]  R444      -1.4635254442691803e-01
    z[1,2,1]  R445      1.4452819526195526e-01
    z[1,2,1]  R446      3.6530364304780960e-02
    z[1,2,1]  R447      -5.1372405141592026e-02
    z[1,2,1]  R448      -4.1581195592880249e-01
    z[1,2,1]  R449      -1.3684687018394470e-01
    z[1,2,1]  R450      -3.3790990710258484e-01
    z[1,2,1]  R451      -3.9915016293525696e-01
    z[1,2,1]  R452      -3.7968832254409790e-01
    z[1,2,1]  R453      -3.2045853137969971e-01
    z[1,2,1]  R454      8.0964809656143188e-01
    z[1,2,1]  R455      5.8610850572586060e-01
    z[1,2,1]  R456      2.6091438531875610e-01
    z[1,2,1]  R457      3.0141600966453552e-01
    z[1,2,1]  R458      4.9611011147499084e-01
    z[1,2,1]  R459      2.8343120217323303e-01
    z[1,2,1]  R460      3.7927502393722534e-01
    z[1,2,1]  R461      -6.6704308986663818e-01
    z[1,2,1]  R462      7.0783996582031250e-01
    z[1,2,1]  R463      -6.7967861890792847e-01
    z[1,2,1]  R464      -8.0104589462280273e-01
    z[1,2,1]  R465      -4.8625072836875916e-01
    z[1,2,1]  R466      6.3931143283843994e-01
    z[1,2,1]  R467      5.3700327873229980e-01
    z[1,2,1]  R468      6.1399507522583008e-01
    z[1,2,1]  R469      5.9168910980224609e-01
    z[1,2,1]  R470      5.3273463249206543e-01
    z[1,2,1]  R471      0.534850001335144
    z[1,2,1]  R472      8.1202828884124756e-01
    z[1,2,1]  R473      5.8803558349609375e-01
    z[1,2,1]  R474      -3.5635221004486084e-01
    z[1,2,1]  R475      5.1366633176803589e-01
    z[1,2,1]  R476      6.7645597457885742e-01
    z[1,2,1]  R477      8.4169787168502808e-01
    z[1,2,1]  R478      6.4195710420608521e-01
    z[1,2,1]  R479      6.7603194713592529e-01
    z[1,2,1]  R480      0.426799476146698
    z[1,2,1]  R481      7.9431287944316864e-02
    z[1,2,1]  R482      -3.9755183458328247e-01
    z[1,2,1]  R483      3.2342889904975891e-01
    z[1,2,1]  R484      -2.1219430863857269e-01
    z[1,2,1]  R485      -3.0488333106040955e-01
    z[1,2,1]  R486      -0.0971231609582901
    z[1,2,1]  R487      8.3598485216498375e-03
    z[1,2,1]  R488      6.0215830802917480e-01
    z[1,2,1]  R489      2.8943002223968506e-01
    z[1,2,1]  R490      8.2313740253448486e-01
    z[1,2,1]  R491      4.8249977827072144e-01
    z[1,2,1]  R492      0.0206461139023304
    z[1,2,1]  R493      0.269851952791214
    z[1,2,1]  R494      4.1763129830360413e-01
    z[1,2,1]  R495      2.8551751375198364e-01
    z[1,2,1]  R496      -7.7222526073455811e-02
    z[1,2,1]  R497      -2.4024634063243866e-01
    z[1,2,1]  R498      2.5666579604148865e-01
    z[1,2,1]  R499      6.4945000410079956e-01
    z[1,2,1]  R500      0.73226398229599
    z[1,2,1]  R501      -5.3476440906524658e-01
    z[1,2,1]  R502      -7.6775014400482178e-01
    z[1,2,1]  R503      -7.2509992122650146e-01
    z[1,2,1]  R504      -0.877051591873169
    z[1,2,1]  R505      -7.5436115264892578e-01
    z[1,2,1]  R506      -6.5354037284851074e-01
    z[1,2,1]  R507      -0.711564302444458
    z[1,2,1]  R508      -2.0110936462879181e-01
    z[1,2,1]  R509      -3.6352825164794922e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R431      -1
    z[1,2,2]  R432      1
    z[1,2,2]  R441      3.4506872296333313e-01
    z[1,2,2]  R442      2.2369889914989471e-01
    z[1,2,2]  R443      5.6558990478515625e-01
    z[1,2,2]  R444      1.3435854576528072e-02
    z[1,2,2]  R445      2.3403762280941010e-01
    z[1,2,2]  R446      -6.1334975063800812e-02
    z[1,2,2]  R447      1.0546138882637024e-01
    z[1,2,2]  R448      3.4270009398460388e-01
    z[1,2,2]  R449      1.0621958971023560e-01
    z[1,2,2]  R450      2.0313139259815216e-01
    z[1,2,2]  R451      -4.4750720262527466e-01
    z[1,2,2]  R452      -5.6669324636459351e-01
    z[1,2,2]  R453      -0.647377073764801
    z[1,2,2]  R454      3.4646353125572205e-01
    z[1,2,2]  R455      1.5642565488815308e-01
    z[1,2,2]  R456      1.4474781230092049e-02
    z[1,2,2]  R457      -3.4806481003761292e-01
    z[1,2,2]  R458      1.1457546800374985e-01
    z[1,2,2]  R459      -2.2262121737003326e-01
    z[1,2,2]  R460      -2.0205043256282806e-01
    z[1,2,2]  R461      3.1035864353179932e-01
    z[1,2,2]  R462      -9.3645744025707245e-02
    z[1,2,2]  R463      2.9548269510269165e-01
    z[1,2,2]  R464      2.4751627445220947e-01
    z[1,2,2]  R465      4.7951984405517578e-01
    z[1,2,2]  R466      -3.6204284429550171e-01
    z[1,2,2]  R467      -1.8501663208007812e-01
    z[1,2,2]  R468      8.6969859898090363e-02
    z[1,2,2]  R469      -1.4490877091884613e-01
    z[1,2,2]  R470      -2.9290112853050232e-01
    z[1,2,2]  R471      -1.6944038867950439e-01
    z[1,2,2]  R472      -1.0209630429744720e-01
    z[1,2,2]  R473      -2.0948436111211777e-02
    z[1,2,2]  R474      4.4204688072204590e-01
    z[1,2,2]  R475      -4.6465110778808594e-01
    z[1,2,2]  R476      -5.5999219417572021e-01
    z[1,2,2]  R477      -2.6072350144386292e-01
    z[1,2,2]  R478      1.4294293522834778e-01
    z[1,2,2]  R479      -2.9007813334465027e-01
    z[1,2,2]  R480      1.8540093302726746e-01
    z[1,2,2]  R481      6.2867307662963867e-01
    z[1,2,2]  R482      -2.6678498834371567e-03
    z[1,2,2]  R483      2.3240759968757629e-02
    z[1,2,2]  R484      7.3586237430572510e-01
    z[1,2,2]  R485      4.4503051787614822e-02
    z[1,2,2]  R486      5.2740514278411865e-01
    z[1,2,2]  R487      4.8460975289344788e-01
    z[1,2,2]  R488      -3.4216475486755371e-01
    z[1,2,2]  R489      -2.3476199805736542e-01
    z[1,2,2]  R490      1.9673605263233185e-01
    z[1,2,2]  R491      -7.3031479120254517e-01
    z[1,2,2]  R492      -8.0504369735717773e-01
    z[1,2,2]  R493      -5.3276664018630981e-01
    z[1,2,2]  R494      -2.7399149537086487e-01
    z[1,2,2]  R495      -4.8997423052787781e-01
    z[1,2,2]  R496      -4.6244513988494873e-01
    z[1,2,2]  R497      -6.7258810997009277e-01
    z[1,2,2]  R498      -4.4092249870300293e-01
    z[1,2,2]  R499      -1.0443136096000671e-01
    z[1,2,2]  R500      1.6812039911746979e-01
    z[1,2,2]  R501      1.0284559428691864e-01
    z[1,2,2]  R502      1.0101505368947983e-01
    z[1,2,2]  R503      1.1019319295883179e-01
    z[1,2,2]  R504      2.7593395113945007e-01
    z[1,2,2]  R505      1.3302844762802124e-01
    z[1,2,2]  R506      -3.9581082761287689e-02
    z[1,2,2]  R507      2.4669954180717468e-01
    z[1,2,2]  R508      1.2848532199859619e-01
    z[1,2,2]  R509      -4.5250102877616882e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R433      -1
    z[1,2,3]  R434      1
    z[1,2,3]  R441      5.1889920234680176e-01
    z[1,2,3]  R442      4.8369956016540527e-01
    z[1,2,3]  R443      2.9077830910682678e-01
    z[1,2,3]  R444      0.596926212310791
    z[1,2,3]  R445      3.5593691468238831e-01
    z[1,2,3]  R446      7.3363047838211060e-01
    z[1,2,3]  R447      6.2213766574859619e-01
    z[1,2,3]  R448      -0.202616885304451
    z[1,2,3]  R449      6.8106240034103394e-01
    z[1,2,3]  R450      -4.8952010273933411e-01
    z[1,2,3]  R451      -2.0400212705135345e-01
    z[1,2,3]  R452      1.9041763246059418e-01
    z[1,2,3]  R453      2.0697003602981567e-01
    z[1,2,3]  R454      -1.6126327216625214e-01
    z[1,2,3]  R455      -3.4424927830696106e-01
    z[1,2,3]  R456      -2.3734968900680542e-01
    z[1,2,3]  R457      -1.2973500788211823e-01
    z[1,2,3]  R458      -2.2059005498886108e-01
    z[1,2,3]  R459      1.7889874055981636e-02
    z[1,2,3]  R460      0.285665363073349
    z[1,2,3]  R461      -3.2719928026199341e-01
    z[1,2,3]  R462      -1.7766429483890533e-01
    z[1,2,3]  R463      -2.1534240245819092e-01
    z[1,2,3]  R464      -1.3688556849956512e-01
    z[1,2,3]  R465      -5.4194068908691406e-01
    z[1,2,3]  R466      2.1447072923183441e-01
    z[1,2,3]  R467      3.3593562245368958e-01
    z[1,2,3]  R468      1.8853972852230072e-01
    z[1,2,3]  R469      1.4137262105941772e-01
    z[1,2,3]  R470      -1.3061001896858215e-01
    z[1,2,3]  R471      -2.3714998736977577e-02
    z[1,2,3]  R472      -2.9318743944168091e-01
    z[1,2,3]  R473      -1.2610936164855957e-01
    z[1,2,3]  R474      -7.0942115783691406e-01
    z[1,2,3]  R475      -8.9339666068553925e-02
    z[1,2,3]  R476      1.0879688709974289e-01
    z[1,2,3]  R477      6.1771705746650696e-02
    z[1,2,3]  R478      3.2730036973953247e-01
    z[1,2,3]  R479      0.282962828874588
    z[1,2,3]  R480      4.7854557633399963e-02
    z[1,2,3]  R481      6.2566578388214111e-01
    z[1,2,3]  R482      4.9074572324752808e-01
    z[1,2,3]  R483      7.5558441877365112e-01
    z[1,2,3]  R484      3.0732378363609314e-01
    z[1,2,3]  R485      4.1086256504058838e-02
    z[1,2,3]  R486      5.1625502109527588e-01
    z[1,2,3]  R487      2.0595093071460724e-01
    z[1,2,3]  R488      1.3027578592300415e-01
    z[1,2,3]  R489      8.6012363433837891e-02
    z[1,2,3]  R490      -1.4572909474372864e-01
    z[1,2,3]  R491      -3.1805527210235596e-01
    z[1,2,3]  R492      -5.2488803863525391e-01
    z[1,2,3]  R493      -5.9762454032897949e-01
    z[1,2,3]  R494      -5.6750136613845825e-01
    z[1,2,3]  R495      -6.3330346345901489e-01
    z[1,2,3]  R496      -3.8353392481803894e-01
    z[1,2,3]  R497      0.328482985496521
    z[1,2,3]  R498      -5.6475222110748291e-01
    z[1,2,3]  R499      -6.4443355798721313e-01
    z[1,2,3]  R500      -4.9667173624038696e-01
    z[1,2,3]  R501      5.4936748743057251e-01
    z[1,2,3]  R502      5.1287108659744263e-01
    z[1,2,3]  R503      3.5860481858253479e-01
    z[1,2,3]  R504      2.0596887171268463e-01
    z[1,2,3]  R505      4.0284997224807739e-01
    z[1,2,3]  R506      4.1860967874526978e-01
    z[1,2,3]  R507      2.9445654153823853e-01
    z[1,2,3]  R508      -1.5159931778907776e-01
    z[1,2,3]  R509      -7.6267711818218231e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R435      -1
    z[1,2,4]  R436      1
    z[1,2,4]  R441      -0.0792056992650032
    z[1,2,4]  R442      1.8844315409660339e-01
    z[1,2,4]  R443      -1.9486621022224426e-01
    z[1,2,4]  R444      3.1478238105773926e-01
    z[1,2,4]  R445      2.1180033683776855e-01
    z[1,2,4]  R446      5.1478110253810883e-02
    z[1,2,4]  R447      -3.6653468012809753e-01
    z[1,2,4]  R448      2.7983969449996948e-01
    z[1,2,4]  R449      -6.0779005289077759e-01
    z[1,2,4]  R450      5.0472712516784668e-01
    z[1,2,4]  R451      4.0730607509613037e-01
    z[1,2,4]  R452      1.9348204135894775e-01
    z[1,2,4]  R453      5.5160537362098694e-02
    z[1,2,4]  R454      -8.1306464970111847e-02
    z[1,2,4]  R455      -4.0863001346588135e-01
    z[1,2,4]  R456      -2.7534094452857971e-01
    z[1,2,4]  R457      -2.5417742133140564e-01
    z[1,2,4]  R458      -3.1223183870315552e-01
    z[1,2,4]  R459      -7.5369350612163544e-02
    z[1,2,4]  R460      -1.1840689927339554e-01
    z[1,2,4]  R461      -1.0056166350841522e-01
    z[1,2,4]  R462      3.0120310187339783e-01
    z[1,2,4]  R463      3.0542176961898804e-01
    z[1,2,4]  R464      -4.4282829761505127e-01
    z[1,2,4]  R465      -3.6533474922180176e-01
    z[1,2,4]  R466      3.4225094318389893e-01
    z[1,2,4]  R467      0.354827880859375
    z[1,2,4]  R468      1.8782433867454529e-01
    z[1,2,4]  R469      -2.1791774779558182e-02
    z[1,2,4]  R470      6.3285613059997559e-01
    z[1,2,4]  R471      1.9259554147720337e-01
    z[1,2,4]  R472      -4.1830752044916153e-02
    z[1,2,4]  R473      -1.4422099292278290e-01
    z[1,2,4]  R474      3.5265302658081055e-01
    z[1,2,4]  R475      -1.2806174345314503e-03
    z[1,2,4]  R476      -1.5267243981361389e-01
    z[1,2,4]  R477      4.3057948350906372e-03
    z[1,2,4]  R478      -1.7468999326229095e-01
    z[1,2,4]  R479      2.6484140753746033e-01
    z[1,2,4]  R480      -1.9710429012775421e-01
    z[1,2,4]  R481      2.8751331567764282e-01
    z[1,2,4]  R482      4.0704602003097534e-01
    z[1,2,4]  R483      -0.426480770111084
    z[1,2,4]  R484      -3.3437520265579224e-01
    z[1,2,4]  R485      -4.7853785753250122e-01
    z[1,2,4]  R486      -5.2007079124450684e-01
    z[1,2,4]  R487      -0.666246235370636
    z[1,2,4]  R488      5.4549360275268555e-01
    z[1,2,4]  R489      5.2043098211288452e-01
    z[1,2,4]  R490      3.3640742301940918e-01
    z[1,2,4]  R491      4.3694246560335159e-02
    z[1,2,4]  R492      1.3809607923030853e-01
    z[1,2,4]  R493      4.6427417546510696e-02
    z[1,2,4]  R494      -1.1314975097775459e-02
    z[1,2,4]  R495      -5.1508712768554688e-01
    z[1,2,4]  R496      5.3270876407623291e-01
    z[1,2,4]  R497      -1.0619388520717621e-01
    z[1,2,4]  R498      3.6782614886760712e-02
    z[1,2,4]  R499      1.7680945992469788e-01
    z[1,2,4]  R500      -2.3608976975083351e-02
    z[1,2,4]  R501      -4.4129312038421631e-01
    z[1,2,4]  R502      -2.1797710657119751e-01
    z[1,2,4]  R503      -2.6747125387191772e-01
    z[1,2,4]  R504      3.4796193242073059e-02
    z[1,2,4]  R505      -4.4919136166572571e-01
    z[1,2,4]  R506      -5.2068316936492920e-01
    z[1,2,4]  R507      -8.7124384939670563e-02
    z[1,2,4]  R508      2.9048962518572807e-02
    z[1,2,4]  R509      -4.0447497367858887e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R437      -1
    z[1,2,5]  R438      1
    z[1,2,5]  R441      2.8551647439599037e-02
    z[1,2,5]  R442      -3.4730178117752075e-01
    z[1,2,5]  R443      1.0039012879133224e-01
    z[1,2,5]  R444      2.3487027734518051e-02
    z[1,2,5]  R445      6.7503049969673157e-02
    z[1,2,5]  R446      -2.0547521114349365e-01
    z[1,2,5]  R447      7.8511908650398254e-02
    z[1,2,5]  R448      -5.4383426904678345e-01
    z[1,2,5]  R449      -2.6201382279396057e-01
    z[1,2,5]  R450      -5.4901939630508423e-01
    z[1,2,5]  R451      4.6231734752655029e-01
    z[1,2,5]  R452      4.5106157660484314e-01
    z[1,2,5]  R453      2.3907804861664772e-02
    z[1,2,5]  R454      1.8173629045486450e-01
    z[1,2,5]  R455      -1.4996635913848877e-01
    z[1,2,5]  R456      -1.1133291572332382e-01
    z[1,2,5]  R457      -1.3700784742832184e-01
    z[1,2,5]  R458      7.9346112906932831e-02
    z[1,2,5]  R459      3.8579019904136658e-01
    z[1,2,5]  R460      5.3271347284317017e-01
    z[1,2,5]  R461      -2.1088415384292603e-01
    z[1,2,5]  R462      -2.7036604285240173e-01
    z[1,2,5]  R463      0.393787682056427
    z[1,2,5]  R464      2.6190746575593948e-02
    z[1,2,5]  R465      -6.9412463344633579e-03
    z[1,2,5]  R466      -1.8771132826805115e-01
    z[1,2,5]  R467      -3.5637933015823364e-01
    z[1,2,5]  R468      -2.7915915846824646e-01
    z[1,2,5]  R469      -6.4423257112503052e-01
    z[1,2,5]  R470      -1.1956059187650681e-01
    z[1,2,5]  R471      1.1860957369208336e-02
    z[1,2,5]  R472      1.0141263902187347e-01
    z[1,2,5]  R473      2.5752207636833191e-01
    z[1,2,5]  R474      2.0284067094326019e-01
    z[1,2,5]  R475      3.1230231747031212e-02
    z[1,2,5]  R476      1.0390304774045944e-01
    z[1,2,5]  R477      0.370836466550827
    z[1,2,5]  R478      -1.9459243118762970e-01
    z[1,2,5]  R479      4.2018571496009827e-01
    z[1,2,5]  R480      1.8176691234111786e-01
    z[1,2,5]  R481      -3.0940619111061096e-01
    z[1,2,5]  R482      -1.6346307098865509e-01
    z[1,2,5]  R483      -2.7923610806465149e-01
    z[1,2,5]  R484      -2.4581816792488098e-01
    z[1,2,5]  R485      3.8688549399375916e-01
    z[1,2,5]  R486      1.5567594766616821e-01
    z[1,2,5]  R487      -1.6993854939937592e-01
    z[1,2,5]  R488      2.7035483717918396e-01
    z[1,2,5]  R489      3.1617123633623123e-02
    z[1,2,5]  R490      -2.7341408655047417e-02
    z[1,2,5]  R491      -1.2265057861804962e-01
    z[1,2,5]  R492      0.0849970206618309
    z[1,2,5]  R493      0.479673832654953
    z[1,2,5]  R494      5.5909407138824463e-01
    z[1,2,5]  R495      1.0885137319564819e-01
    z[1,2,5]  R496      3.5330349206924438e-01
    z[1,2,5]  R497      4.4289442896842957e-01
    z[1,2,5]  R498      2.3056019842624664e-01
    z[1,2,5]  R499      -3.4332033991813660e-01
    z[1,2,5]  R500      2.8997781872749329e-01
    z[1,2,5]  R501      1.0376957803964615e-01
    z[1,2,5]  R502      1.9177818298339844e-01
    z[1,2,5]  R503      -0.384305864572525
    z[1,2,5]  R504      -1.2934236228466034e-01
    z[1,2,5]  R505      2.0152927935123444e-01
    z[1,2,5]  R506      -2.7260735630989075e-01
    z[1,2,5]  R507      5.2765250205993652e-01
    z[1,2,5]  R508      -1.2215762399137020e-02
    z[1,2,5]  R509      -2.5281757116317749e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R439      -1
    z[1,2,6]  R440      1
    z[1,2,6]  R441      2.3409897089004517e-01
    z[1,2,6]  R442      -1.5718971192836761e-01
    z[1,2,6]  R443      -5.8724023401737213e-02
    z[1,2,6]  R444      -1.6046413779258728e-01
    z[1,2,6]  R445      -3.5827484726905823e-01
    z[1,2,6]  R446      -1.9982320070266724e-01
    z[1,2,6]  R447      -4.3935203552246094e-01
    z[1,2,6]  R448      5.3718715906143188e-01
    z[1,2,6]  R449      6.5169036388397217e-02
    z[1,2,6]  R450      0.203288733959198
    z[1,2,6]  R451      -2.8496682643890381e-01
    z[1,2,6]  R452      2.8848540782928467e-01
    z[1,2,6]  R453      -4.9975943565368652e-01
    z[1,2,6]  R454      6.5745715983211994e-04
    z[1,2,6]  R455      -3.7166573107242584e-02
    z[1,2,6]  R456      -1.4924509823322296e-01
    z[1,2,6]  R457      -3.6494889855384827e-01
    z[1,2,6]  R458      5.6829851865768433e-01
    z[1,2,6]  R459      -4.0345105528831482e-01
    z[1,2,6]  R460      -1.5604069828987122e-01
    z[1,2,6]  R461      -5.4232567548751831e-01
    z[1,2,6]  R462      -3.3239290118217468e-01
    z[1,2,6]  R463      3.7657976150512695e-01
    z[1,2,6]  R464      1.7373524606227875e-03
    z[1,2,6]  R465      -2.4441403150558472e-01
    z[1,2,6]  R466      3.4390413761138916e-01
    z[1,2,6]  R467      3.9139088243246078e-02
    z[1,2,6]  R468      4.7889706492424011e-01
    z[1,2,6]  R469      2.4972047656774521e-02
    z[1,2,6]  R470      -1.7291429685428739e-03
    z[1,2,6]  R471      9.4655208289623260e-02
    z[1,2,6]  R472      -2.6949459314346313e-01
    z[1,2,6]  R473      3.2446798682212830e-01
    z[1,2,6]  R474      9.3911968171596527e-02
    z[1,2,6]  R475      -3.3727535605430603e-01
    z[1,2,6]  R476      1.0890547186136246e-02
    z[1,2,6]  R477      8.3964817225933075e-02
    z[1,2,6]  R478      -3.0923005938529968e-01
    z[1,2,6]  R479      -6.3112258911132812e-02
    z[1,2,6]  R480      -5.0881510972976685e-01
    z[1,2,6]  R481      -1.6476458311080933e-01
    z[1,2,6]  R482      6.3239151239395142e-01
    z[1,2,6]  R483      2.2137025371193886e-02
    z[1,2,6]  R484      1.1059667170047760e-01
    z[1,2,6]  R485      -7.0395815372467041e-01
    z[1,2,6]  R486      -3.8878101110458374e-01
    z[1,2,6]  R487      -4.9678346514701843e-01
    z[1,2,6]  R488      2.3348443210124969e-02
    z[1,2,6]  R489      -0.579865038394928
    z[1,2,6]  R490      3.6405026912689209e-01
    z[1,2,6]  R491      -3.0655439943075180e-02
    z[1,2,6]  R492      1.5468910336494446e-01
    z[1,2,6]  R493      -1.7028902471065521e-01
    z[1,2,6]  R494      0.309525728225708
    z[1,2,6]  R495      6.4637279137969017e-03
    z[1,2,6]  R496      -3.7308064103126526e-01
    z[1,2,6]  R497      3.3422031998634338e-01
    z[1,2,6]  R498      5.7661163806915283e-01
    z[1,2,6]  R499      -0.0422232411801815
    z[1,2,6]  R500      -3.2226061820983887e-01
    z[1,2,6]  R501      4.1127049922943115e-01
    z[1,2,6]  R502      -2.1815580129623413e-01
    z[1,2,6]  R503      -3.3084192872047424e-01
    z[1,2,6]  R504      -2.9909899830818176e-01
    z[1,2,6]  R505      -5.0208289176225662e-02
    z[1,2,6]  R506      -2.0609614253044128e-01
    z[1,2,6]  R507      1.3794523477554321e-01
    z[1,2,6]  R508      1.0039892047643661e-01
    z[1,2,6]  R509      5.2962714107707143e-04
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R510      -1
    z[2,1,0]  R511      1
    z[2,1,0]  R524      -3.8206443190574646e-02
    z[2,1,0]  R525      9.3746766448020935e-02
    z[2,1,0]  R526      -2.5218451023101807e-01
    z[2,1,0]  R527      3.6683419346809387e-01
    z[2,1,0]  R528      -1.7070950567722321e-01
    z[2,1,0]  R529      -5.6910580024123192e-03
    z[2,1,0]  R530      5.5773887783288956e-02
    z[2,1,0]  R531      -0.363533616065979
    z[2,1,0]  R532      -4.9560809135437012e-01
    z[2,1,0]  R533      1.2669922411441803e-01
    z[2,1,0]  R534      -3.3879640698432922e-01
    z[2,1,0]  R535      -1.6045930981636047e-01
    z[2,1,0]  R536      -1.5793561935424805e-01
    z[2,1,0]  R537      1.4118921756744385e-01
    z[2,1,0]  R538      1.1255958117544651e-02
    z[2,1,0]  R539      -2.9204767942428589e-01
    z[2,1,0]  R540      -2.5073906779289246e-01
    z[2,1,0]  R541      1.8377426266670227e-01
    z[2,1,0]  R542      3.3180419355630875e-02
    z[2,1,0]  R543      1.8592732027173042e-02
    z[2,1,0]  R544      1.6429834067821503e-01
    z[2,1,0]  R545      -7.3716074228286743e-02
    z[2,1,0]  R546      -0.0692955031991005
    z[2,1,0]  R547      6.9407053291797638e-02
    z[2,1,0]  R548      7.7760502696037292e-02
    z[2,1,0]  R549      -9.0459384024143219e-02
    z[2,1,0]  R550      2.0266753435134888e-01
    z[2,1,0]  R551      -9.5341032743453979e-01
    z[2,1,0]  R552      -7.9527717828750610e-01
    z[2,1,0]  R553      7.2937792539596558e-01
    z[2,1,0]  R554      6.9539844989776611e-01
    z[2,1,0]  R555      6.9143670797348022e-01
    z[2,1,0]  R556      7.0476317405700684e-01
    z[2,1,0]  R557      7.8731817007064819e-01
    z[2,1,0]  R558      6.0982835292816162e-01
    z[2,1,0]  R559      5.1540416479110718e-01
    z[2,1,0]  R560      7.7249638736248016e-02
    z[2,1,0]  R561      2.5266060233116150e-01
    z[2,1,0]  R562      -8.6177125573158264e-02
    z[2,1,0]  R563      -3.7142688035964966e-01
    z[2,1,0]  R564      -4.1751763224601746e-01
    z[2,1,0]  R565      -4.2661333084106445e-01
    z[2,1,0]  R566      -3.9848193526268005e-01
    z[2,1,0]  R567      -5.6802338361740112e-01
    z[2,1,0]  R568      -8.7458425760269165e-01
    z[2,1,0]  R569      -7.4471682310104370e-01
    z[2,1,0]  R570      -5.1511114835739136e-01
    z[2,1,0]  R571      -7.4330282211303711e-01
    z[2,1,0]  R572      -6.4153635501861572e-01
    z[2,1,0]  R573      -5.4495353251695633e-02
    z[2,1,0]  R574      -4.2932775616645813e-01
    z[2,1,0]  R575      1.1912572383880615e-01
    z[2,1,0]  R576      -2.8554797172546387e-01
    z[2,1,0]  R577      -2.1602143347263336e-01
    z[2,1,0]  R578      -3.7890213727951050e-01
    z[2,1,0]  R579      -5.5686873197555542e-01
    z[2,1,0]  R580      -4.8718467354774475e-01
    z[2,1,0]  R581      -4.3907305598258972e-01
    z[2,1,0]  R582      -4.4557729363441467e-01
    z[2,1,0]  R583      -7.9904294013977051e-01
    z[2,1,0]  R584      -3.9945688843727112e-01
    z[2,1,0]  R585      -6.6743910312652588e-01
    z[2,1,0]  R586      -1.1624854523688555e-03
    z[2,1,0]  R587      -6.3050216436386108e-01
    z[2,1,0]  R588      -4.2749956250190735e-01
    z[2,1,0]  R589      -2.7416041493415833e-01
    z[2,1,0]  R590      -5.4435908794403076e-01
    z[2,1,0]  R591      -3.5789293050765991e-01
    z[2,1,0]  R592      -6.7111587524414062e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R512      -1
    z[2,1,1]  R513      1
    z[2,1,1]  R524      7.9431287944316864e-02
    z[2,1,1]  R525      -3.9755183458328247e-01
    z[2,1,1]  R526      3.2342889904975891e-01
    z[2,1,1]  R527      -2.1219430863857269e-01
    z[2,1,1]  R528      -3.0488333106040955e-01
    z[2,1,1]  R529      -0.0971231609582901
    z[2,1,1]  R530      8.3598485216498375e-03
    z[2,1,1]  R531      6.0215830802917480e-01
    z[2,1,1]  R532      2.8943002223968506e-01
    z[2,1,1]  R533      8.2313740253448486e-01
    z[2,1,1]  R534      4.8249977827072144e-01
    z[2,1,1]  R535      0.0206461139023304
    z[2,1,1]  R536      0.269851952791214
    z[2,1,1]  R537      4.1763129830360413e-01
    z[2,1,1]  R538      2.8551751375198364e-01
    z[2,1,1]  R539      -7.7222526073455811e-02
    z[2,1,1]  R540      -2.4024634063243866e-01
    z[2,1,1]  R541      2.5666579604148865e-01
    z[2,1,1]  R542      6.4945000410079956e-01
    z[2,1,1]  R543      0.73226398229599
    z[2,1,1]  R544      -5.3476440906524658e-01
    z[2,1,1]  R545      -7.6775014400482178e-01
    z[2,1,1]  R546      -7.2509992122650146e-01
    z[2,1,1]  R547      -0.877051591873169
    z[2,1,1]  R548      -7.5436115264892578e-01
    z[2,1,1]  R549      -6.5354037284851074e-01
    z[2,1,1]  R550      -0.711564302444458
    z[2,1,1]  R551      -2.0110936462879181e-01
    z[2,1,1]  R552      -3.6352825164794922e-01
    z[2,1,1]  R553      1.3337233662605286e-01
    z[2,1,1]  R554      -2.2710485756397247e-01
    z[2,1,1]  R555      -2.5684958696365356e-01
    z[2,1,1]  R556      -1.4635254442691803e-01
    z[2,1,1]  R557      1.4452819526195526e-01
    z[2,1,1]  R558      3.6530364304780960e-02
    z[2,1,1]  R559      -5.1372405141592026e-02
    z[2,1,1]  R560      -4.1581195592880249e-01
    z[2,1,1]  R561      -1.3684687018394470e-01
    z[2,1,1]  R562      -3.3790990710258484e-01
    z[2,1,1]  R563      -3.9915016293525696e-01
    z[2,1,1]  R564      -3.7968832254409790e-01
    z[2,1,1]  R565      -3.2045853137969971e-01
    z[2,1,1]  R566      8.0964809656143188e-01
    z[2,1,1]  R567      5.8610850572586060e-01
    z[2,1,1]  R568      2.6091438531875610e-01
    z[2,1,1]  R569      3.0141600966453552e-01
    z[2,1,1]  R570      4.9611011147499084e-01
    z[2,1,1]  R571      2.8343120217323303e-01
    z[2,1,1]  R572      3.7927502393722534e-01
    z[2,1,1]  R573      -6.6704308986663818e-01
    z[2,1,1]  R574      7.0783996582031250e-01
    z[2,1,1]  R575      -6.7967861890792847e-01
    z[2,1,1]  R576      -8.0104589462280273e-01
    z[2,1,1]  R577      -4.8625072836875916e-01
    z[2,1,1]  R578      6.3931143283843994e-01
    z[2,1,1]  R579      5.3700327873229980e-01
    z[2,1,1]  R580      6.1399507522583008e-01
    z[2,1,1]  R581      5.9168910980224609e-01
    z[2,1,1]  R582      5.3273463249206543e-01
    z[2,1,1]  R583      0.534850001335144
    z[2,1,1]  R584      8.1202828884124756e-01
    z[2,1,1]  R585      5.8803558349609375e-01
    z[2,1,1]  R586      -3.5635221004486084e-01
    z[2,1,1]  R587      5.1366633176803589e-01
    z[2,1,1]  R588      6.7645597457885742e-01
    z[2,1,1]  R589      8.4169787168502808e-01
    z[2,1,1]  R590      6.4195710420608521e-01
    z[2,1,1]  R591      6.7603194713592529e-01
    z[2,1,1]  R592      0.426799476146698
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R514      -1
    z[2,1,2]  R515      1
    z[2,1,2]  R524      6.2867307662963867e-01
    z[2,1,2]  R525      -2.6678498834371567e-03
    z[2,1,2]  R526      2.3240759968757629e-02
    z[2,1,2]  R527      7.3586237430572510e-01
    z[2,1,2]  R528      4.4503051787614822e-02
    z[2,1,2]  R529      5.2740514278411865e-01
    z[2,1,2]  R530      4.8460975289344788e-01
    z[2,1,2]  R531      -3.4216475486755371e-01
    z[2,1,2]  R532      -2.3476199805736542e-01
    z[2,1,2]  R533      1.9673605263233185e-01
    z[2,1,2]  R534      -7.3031479120254517e-01
    z[2,1,2]  R535      -8.0504369735717773e-01
    z[2,1,2]  R536      -5.3276664018630981e-01
    z[2,1,2]  R537      -2.7399149537086487e-01
    z[2,1,2]  R538      -4.8997423052787781e-01
    z[2,1,2]  R539      -4.6244513988494873e-01
    z[2,1,2]  R540      -6.7258810997009277e-01
    z[2,1,2]  R541      -4.4092249870300293e-01
    z[2,1,2]  R542      -1.0443136096000671e-01
    z[2,1,2]  R543      1.6812039911746979e-01
    z[2,1,2]  R544      1.0284559428691864e-01
    z[2,1,2]  R545      1.0101505368947983e-01
    z[2,1,2]  R546      1.1019319295883179e-01
    z[2,1,2]  R547      2.7593395113945007e-01
    z[2,1,2]  R548      1.3302844762802124e-01
    z[2,1,2]  R549      -3.9581082761287689e-02
    z[2,1,2]  R550      2.4669954180717468e-01
    z[2,1,2]  R551      1.2848532199859619e-01
    z[2,1,2]  R552      -4.5250102877616882e-02
    z[2,1,2]  R553      3.4506872296333313e-01
    z[2,1,2]  R554      2.2369889914989471e-01
    z[2,1,2]  R555      5.6558990478515625e-01
    z[2,1,2]  R556      1.3435854576528072e-02
    z[2,1,2]  R557      2.3403762280941010e-01
    z[2,1,2]  R558      -6.1334975063800812e-02
    z[2,1,2]  R559      1.0546138882637024e-01
    z[2,1,2]  R560      3.4270009398460388e-01
    z[2,1,2]  R561      1.0621958971023560e-01
    z[2,1,2]  R562      2.0313139259815216e-01
    z[2,1,2]  R563      -4.4750720262527466e-01
    z[2,1,2]  R564      -5.6669324636459351e-01
    z[2,1,2]  R565      -0.647377073764801
    z[2,1,2]  R566      3.4646353125572205e-01
    z[2,1,2]  R567      1.5642565488815308e-01
    z[2,1,2]  R568      1.4474781230092049e-02
    z[2,1,2]  R569      -3.4806481003761292e-01
    z[2,1,2]  R570      1.1457546800374985e-01
    z[2,1,2]  R571      -2.2262121737003326e-01
    z[2,1,2]  R572      -2.0205043256282806e-01
    z[2,1,2]  R573      3.1035864353179932e-01
    z[2,1,2]  R574      -9.3645744025707245e-02
    z[2,1,2]  R575      2.9548269510269165e-01
    z[2,1,2]  R576      2.4751627445220947e-01
    z[2,1,2]  R577      4.7951984405517578e-01
    z[2,1,2]  R578      -3.6204284429550171e-01
    z[2,1,2]  R579      -1.8501663208007812e-01
    z[2,1,2]  R580      8.6969859898090363e-02
    z[2,1,2]  R581      -1.4490877091884613e-01
    z[2,1,2]  R582      -2.9290112853050232e-01
    z[2,1,2]  R583      -1.6944038867950439e-01
    z[2,1,2]  R584      -1.0209630429744720e-01
    z[2,1,2]  R585      -2.0948436111211777e-02
    z[2,1,2]  R586      4.4204688072204590e-01
    z[2,1,2]  R587      -4.6465110778808594e-01
    z[2,1,2]  R588      -5.5999219417572021e-01
    z[2,1,2]  R589      -2.6072350144386292e-01
    z[2,1,2]  R590      1.4294293522834778e-01
    z[2,1,2]  R591      -2.9007813334465027e-01
    z[2,1,2]  R592      1.8540093302726746e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R516      -1
    z[2,1,3]  R517      1
    z[2,1,3]  R524      6.2566578388214111e-01
    z[2,1,3]  R525      4.9074572324752808e-01
    z[2,1,3]  R526      7.5558441877365112e-01
    z[2,1,3]  R527      3.0732378363609314e-01
    z[2,1,3]  R528      4.1086256504058838e-02
    z[2,1,3]  R529      5.1625502109527588e-01
    z[2,1,3]  R530      2.0595093071460724e-01
    z[2,1,3]  R531      1.3027578592300415e-01
    z[2,1,3]  R532      8.6012363433837891e-02
    z[2,1,3]  R533      -1.4572909474372864e-01
    z[2,1,3]  R534      -3.1805527210235596e-01
    z[2,1,3]  R535      -5.2488803863525391e-01
    z[2,1,3]  R536      -5.9762454032897949e-01
    z[2,1,3]  R537      -5.6750136613845825e-01
    z[2,1,3]  R538      -6.3330346345901489e-01
    z[2,1,3]  R539      -3.8353392481803894e-01
    z[2,1,3]  R540      0.328482985496521
    z[2,1,3]  R541      -5.6475222110748291e-01
    z[2,1,3]  R542      -6.4443355798721313e-01
    z[2,1,3]  R543      -4.9667173624038696e-01
    z[2,1,3]  R544      5.4936748743057251e-01
    z[2,1,3]  R545      5.1287108659744263e-01
    z[2,1,3]  R546      3.5860481858253479e-01
    z[2,1,3]  R547      2.0596887171268463e-01
    z[2,1,3]  R548      4.0284997224807739e-01
    z[2,1,3]  R549      4.1860967874526978e-01
    z[2,1,3]  R550      2.9445654153823853e-01
    z[2,1,3]  R551      -1.5159931778907776e-01
    z[2,1,3]  R552      -7.6267711818218231e-02
    z[2,1,3]  R553      5.1889920234680176e-01
    z[2,1,3]  R554      4.8369956016540527e-01
    z[2,1,3]  R555      2.9077830910682678e-01
    z[2,1,3]  R556      0.596926212310791
    z[2,1,3]  R557      3.5593691468238831e-01
    z[2,1,3]  R558      7.3363047838211060e-01
    z[2,1,3]  R559      6.2213766574859619e-01
    z[2,1,3]  R560      -0.202616885304451
    z[2,1,3]  R561      6.8106240034103394e-01
    z[2,1,3]  R562      -4.8952010273933411e-01
    z[2,1,3]  R563      -2.0400212705135345e-01
    z[2,1,3]  R564      1.9041763246059418e-01
    z[2,1,3]  R565      2.0697003602981567e-01
    z[2,1,3]  R566      -1.6126327216625214e-01
    z[2,1,3]  R567      -3.4424927830696106e-01
    z[2,1,3]  R568      -2.3734968900680542e-01
    z[2,1,3]  R569      -1.2973500788211823e-01
    z[2,1,3]  R570      -2.2059005498886108e-01
    z[2,1,3]  R571      1.7889874055981636e-02
    z[2,1,3]  R572      0.285665363073349
    z[2,1,3]  R573      -3.2719928026199341e-01
    z[2,1,3]  R574      -1.7766429483890533e-01
    z[2,1,3]  R575      -2.1534240245819092e-01
    z[2,1,3]  R576      -1.3688556849956512e-01
    z[2,1,3]  R577      -5.4194068908691406e-01
    z[2,1,3]  R578      2.1447072923183441e-01
    z[2,1,3]  R579      3.3593562245368958e-01
    z[2,1,3]  R580      1.8853972852230072e-01
    z[2,1,3]  R581      1.4137262105941772e-01
    z[2,1,3]  R582      -1.3061001896858215e-01
    z[2,1,3]  R583      -2.3714998736977577e-02
    z[2,1,3]  R584      -2.9318743944168091e-01
    z[2,1,3]  R585      -1.2610936164855957e-01
    z[2,1,3]  R586      -7.0942115783691406e-01
    z[2,1,3]  R587      -8.9339666068553925e-02
    z[2,1,3]  R588      1.0879688709974289e-01
    z[2,1,3]  R589      6.1771705746650696e-02
    z[2,1,3]  R590      3.2730036973953247e-01
    z[2,1,3]  R591      0.282962828874588
    z[2,1,3]  R592      4.7854557633399963e-02
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R518      -1
    z[2,1,4]  R519      1
    z[2,1,4]  R524      2.8751331567764282e-01
    z[2,1,4]  R525      4.0704602003097534e-01
    z[2,1,4]  R526      -0.426480770111084
    z[2,1,4]  R527      -3.3437520265579224e-01
    z[2,1,4]  R528      -4.7853785753250122e-01
    z[2,1,4]  R529      -5.2007079124450684e-01
    z[2,1,4]  R530      -0.666246235370636
    z[2,1,4]  R531      5.4549360275268555e-01
    z[2,1,4]  R532      5.2043098211288452e-01
    z[2,1,4]  R533      3.3640742301940918e-01
    z[2,1,4]  R534      4.3694246560335159e-02
    z[2,1,4]  R535      1.3809607923030853e-01
    z[2,1,4]  R536      4.6427417546510696e-02
    z[2,1,4]  R537      -1.1314975097775459e-02
    z[2,1,4]  R538      -5.1508712768554688e-01
    z[2,1,4]  R539      5.3270876407623291e-01
    z[2,1,4]  R540      -1.0619388520717621e-01
    z[2,1,4]  R541      3.6782614886760712e-02
    z[2,1,4]  R542      1.7680945992469788e-01
    z[2,1,4]  R543      -2.3608976975083351e-02
    z[2,1,4]  R544      -4.4129312038421631e-01
    z[2,1,4]  R545      -2.1797710657119751e-01
    z[2,1,4]  R546      -2.6747125387191772e-01
    z[2,1,4]  R547      3.4796193242073059e-02
    z[2,1,4]  R548      -4.4919136166572571e-01
    z[2,1,4]  R549      -5.2068316936492920e-01
    z[2,1,4]  R550      -8.7124384939670563e-02
    z[2,1,4]  R551      2.9048962518572807e-02
    z[2,1,4]  R552      -4.0447497367858887e-01
    z[2,1,4]  R553      -0.0792056992650032
    z[2,1,4]  R554      1.8844315409660339e-01
    z[2,1,4]  R555      -1.9486621022224426e-01
    z[2,1,4]  R556      3.1478238105773926e-01
    z[2,1,4]  R557      2.1180033683776855e-01
    z[2,1,4]  R558      5.1478110253810883e-02
    z[2,1,4]  R559      -3.6653468012809753e-01
    z[2,1,4]  R560      2.7983969449996948e-01
    z[2,1,4]  R561      -6.0779005289077759e-01
    z[2,1,4]  R562      5.0472712516784668e-01
    z[2,1,4]  R563      4.0730607509613037e-01
    z[2,1,4]  R564      1.9348204135894775e-01
    z[2,1,4]  R565      5.5160537362098694e-02
    z[2,1,4]  R566      -8.1306464970111847e-02
    z[2,1,4]  R567      -4.0863001346588135e-01
    z[2,1,4]  R568      -2.7534094452857971e-01
    z[2,1,4]  R569      -2.5417742133140564e-01
    z[2,1,4]  R570      -3.1223183870315552e-01
    z[2,1,4]  R571      -7.5369350612163544e-02
    z[2,1,4]  R572      -1.1840689927339554e-01
    z[2,1,4]  R573      -1.0056166350841522e-01
    z[2,1,4]  R574      3.0120310187339783e-01
    z[2,1,4]  R575      3.0542176961898804e-01
    z[2,1,4]  R576      -4.4282829761505127e-01
    z[2,1,4]  R577      -3.6533474922180176e-01
    z[2,1,4]  R578      3.4225094318389893e-01
    z[2,1,4]  R579      0.354827880859375
    z[2,1,4]  R580      1.8782433867454529e-01
    z[2,1,4]  R581      -2.1791774779558182e-02
    z[2,1,4]  R582      6.3285613059997559e-01
    z[2,1,4]  R583      1.9259554147720337e-01
    z[2,1,4]  R584      -4.1830752044916153e-02
    z[2,1,4]  R585      -1.4422099292278290e-01
    z[2,1,4]  R586      3.5265302658081055e-01
    z[2,1,4]  R587      -1.2806174345314503e-03
    z[2,1,4]  R588      -1.5267243981361389e-01
    z[2,1,4]  R589      4.3057948350906372e-03
    z[2,1,4]  R590      -1.7468999326229095e-01
    z[2,1,4]  R591      2.6484140753746033e-01
    z[2,1,4]  R592      -1.9710429012775421e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R520      -1
    z[2,1,5]  R521      1
    z[2,1,5]  R524      -3.0940619111061096e-01
    z[2,1,5]  R525      -1.6346307098865509e-01
    z[2,1,5]  R526      -2.7923610806465149e-01
    z[2,1,5]  R527      -2.4581816792488098e-01
    z[2,1,5]  R528      3.8688549399375916e-01
    z[2,1,5]  R529      1.5567594766616821e-01
    z[2,1,5]  R530      -1.6993854939937592e-01
    z[2,1,5]  R531      2.7035483717918396e-01
    z[2,1,5]  R532      3.1617123633623123e-02
    z[2,1,5]  R533      -2.7341408655047417e-02
    z[2,1,5]  R534      -1.2265057861804962e-01
    z[2,1,5]  R535      0.0849970206618309
    z[2,1,5]  R536      0.479673832654953
    z[2,1,5]  R537      5.5909407138824463e-01
    z[2,1,5]  R538      1.0885137319564819e-01
    z[2,1,5]  R539      3.5330349206924438e-01
    z[2,1,5]  R540      4.4289442896842957e-01
    z[2,1,5]  R541      2.3056019842624664e-01
    z[2,1,5]  R542      -3.4332033991813660e-01
    z[2,1,5]  R543      2.8997781872749329e-01
    z[2,1,5]  R544      1.0376957803964615e-01
    z[2,1,5]  R545      1.9177818298339844e-01
    z[2,1,5]  R546      -0.384305864572525
    z[2,1,5]  R547      -1.2934236228466034e-01
    z[2,1,5]  R548      2.0152927935123444e-01
    z[2,1,5]  R549      -2.7260735630989075e-01
    z[2,1,5]  R550      5.2765250205993652e-01
    z[2,1,5]  R551      -1.2215762399137020e-02
    z[2,1,5]  R552      -2.5281757116317749e-01
    z[2,1,5]  R553      2.8551647439599037e-02
    z[2,1,5]  R554      -3.4730178117752075e-01
    z[2,1,5]  R555      1.0039012879133224e-01
    z[2,1,5]  R556      2.3487027734518051e-02
    z[2,1,5]  R557      6.7503049969673157e-02
    z[2,1,5]  R558      -2.0547521114349365e-01
    z[2,1,5]  R559      7.8511908650398254e-02
    z[2,1,5]  R560      -5.4383426904678345e-01
    z[2,1,5]  R561      -2.6201382279396057e-01
    z[2,1,5]  R562      -5.4901939630508423e-01
    z[2,1,5]  R563      4.6231734752655029e-01
    z[2,1,5]  R564      4.5106157660484314e-01
    z[2,1,5]  R565      2.3907804861664772e-02
    z[2,1,5]  R566      1.8173629045486450e-01
    z[2,1,5]  R567      -1.4996635913848877e-01
    z[2,1,5]  R568      -1.1133291572332382e-01
    z[2,1,5]  R569      -1.3700784742832184e-01
    z[2,1,5]  R570      7.9346112906932831e-02
    z[2,1,5]  R571      3.8579019904136658e-01
    z[2,1,5]  R572      5.3271347284317017e-01
    z[2,1,5]  R573      -2.1088415384292603e-01
    z[2,1,5]  R574      -2.7036604285240173e-01
    z[2,1,5]  R575      0.393787682056427
    z[2,1,5]  R576      2.6190746575593948e-02
    z[2,1,5]  R577      -6.9412463344633579e-03
    z[2,1,5]  R578      -1.8771132826805115e-01
    z[2,1,5]  R579      -3.5637933015823364e-01
    z[2,1,5]  R580      -2.7915915846824646e-01
    z[2,1,5]  R581      -6.4423257112503052e-01
    z[2,1,5]  R582      -1.1956059187650681e-01
    z[2,1,5]  R583      1.1860957369208336e-02
    z[2,1,5]  R584      1.0141263902187347e-01
    z[2,1,5]  R585      2.5752207636833191e-01
    z[2,1,5]  R586      2.0284067094326019e-01
    z[2,1,5]  R587      3.1230231747031212e-02
    z[2,1,5]  R588      1.0390304774045944e-01
    z[2,1,5]  R589      0.370836466550827
    z[2,1,5]  R590      -1.9459243118762970e-01
    z[2,1,5]  R591      4.2018571496009827e-01
    z[2,1,5]  R592      1.8176691234111786e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R522      -1
    z[2,1,6]  R523      1
    z[2,1,6]  R524      -1.6476458311080933e-01
    z[2,1,6]  R525      6.3239151239395142e-01
    z[2,1,6]  R526      2.2137025371193886e-02
    z[2,1,6]  R527      1.1059667170047760e-01
    z[2,1,6]  R528      -7.0395815372467041e-01
    z[2,1,6]  R529      -3.8878101110458374e-01
    z[2,1,6]  R530      -4.9678346514701843e-01
    z[2,1,6]  R531      2.3348443210124969e-02
    z[2,1,6]  R532      -0.579865038394928
    z[2,1,6]  R533      3.6405026912689209e-01
    z[2,1,6]  R534      -3.0655439943075180e-02
    z[2,1,6]  R535      1.5468910336494446e-01
    z[2,1,6]  R536      -1.7028902471065521e-01
    z[2,1,6]  R537      0.309525728225708
    z[2,1,6]  R538      6.4637279137969017e-03
    z[2,1,6]  R539      -3.7308064103126526e-01
    z[2,1,6]  R540      3.3422031998634338e-01
    z[2,1,6]  R541      5.7661163806915283e-01
    z[2,1,6]  R542      -0.0422232411801815
    z[2,1,6]  R543      -3.2226061820983887e-01
    z[2,1,6]  R544      4.1127049922943115e-01
    z[2,1,6]  R545      -2.1815580129623413e-01
    z[2,1,6]  R546      -3.3084192872047424e-01
    z[2,1,6]  R547      -2.9909899830818176e-01
    z[2,1,6]  R548      -5.0208289176225662e-02
    z[2,1,6]  R549      -2.0609614253044128e-01
    z[2,1,6]  R550      1.3794523477554321e-01
    z[2,1,6]  R551      1.0039892047643661e-01
    z[2,1,6]  R552      5.2962714107707143e-04
    z[2,1,6]  R553      2.3409897089004517e-01
    z[2,1,6]  R554      -1.5718971192836761e-01
    z[2,1,6]  R555      -5.8724023401737213e-02
    z[2,1,6]  R556      -1.6046413779258728e-01
    z[2,1,6]  R557      -3.5827484726905823e-01
    z[2,1,6]  R558      -1.9982320070266724e-01
    z[2,1,6]  R559      -4.3935203552246094e-01
    z[2,1,6]  R560      5.3718715906143188e-01
    z[2,1,6]  R561      6.5169036388397217e-02
    z[2,1,6]  R562      0.203288733959198
    z[2,1,6]  R563      -2.8496682643890381e-01
    z[2,1,6]  R564      2.8848540782928467e-01
    z[2,1,6]  R565      -4.9975943565368652e-01
    z[2,1,6]  R566      6.5745715983211994e-04
    z[2,1,6]  R567      -3.7166573107242584e-02
    z[2,1,6]  R568      -1.4924509823322296e-01
    z[2,1,6]  R569      -3.6494889855384827e-01
    z[2,1,6]  R570      5.6829851865768433e-01
    z[2,1,6]  R571      -4.0345105528831482e-01
    z[2,1,6]  R572      -1.5604069828987122e-01
    z[2,1,6]  R573      -5.4232567548751831e-01
    z[2,1,6]  R574      -3.3239290118217468e-01
    z[2,1,6]  R575      3.7657976150512695e-01
    z[2,1,6]  R576      1.7373524606227875e-03
    z[2,1,6]  R577      -2.4441403150558472e-01
    z[2,1,6]  R578      3.4390413761138916e-01
    z[2,1,6]  R579      3.9139088243246078e-02
    z[2,1,6]  R580      4.7889706492424011e-01
    z[2,1,6]  R581      2.4972047656774521e-02
    z[2,1,6]  R582      -1.7291429685428739e-03
    z[2,1,6]  R583      9.4655208289623260e-02
    z[2,1,6]  R584      -2.6949459314346313e-01
    z[2,1,6]  R585      3.2446798682212830e-01
    z[2,1,6]  R586      9.3911968171596527e-02
    z[2,1,6]  R587      -3.3727535605430603e-01
    z[2,1,6]  R588      1.0890547186136246e-02
    z[2,1,6]  R589      8.3964817225933075e-02
    z[2,1,6]  R590      -3.0923005938529968e-01
    z[2,1,6]  R591      -6.3112258911132812e-02
    z[2,1,6]  R592      -5.0881510972976685e-01
    z[2,10,0]  R20       -1
    z[2,10,0]  R92       1
    z[2,10,0]  R593      -1
    z[2,10,0]  R594      1
    z[2,10,0]  R607      -3.8206443190574646e-02
    z[2,10,0]  R608      9.3746766448020935e-02
    z[2,10,0]  R609      -2.5218451023101807e-01
    z[2,10,0]  R610      3.6683419346809387e-01
    z[2,10,0]  R611      -1.7070950567722321e-01
    z[2,10,0]  R612      -5.6910580024123192e-03
    z[2,10,0]  R613      5.5773887783288956e-02
    z[2,10,0]  R614      -0.363533616065979
    z[2,10,0]  R615      -4.9560809135437012e-01
    z[2,10,0]  R616      1.2669922411441803e-01
    z[2,10,0]  R617      -3.3879640698432922e-01
    z[2,10,0]  R618      -1.6045930981636047e-01
    z[2,10,0]  R619      -1.5793561935424805e-01
    z[2,10,0]  R620      1.4118921756744385e-01
    z[2,10,0]  R621      1.1255958117544651e-02
    z[2,10,0]  R622      -2.9204767942428589e-01
    z[2,10,0]  R623      -2.5073906779289246e-01
    z[2,10,0]  R624      1.8377426266670227e-01
    z[2,10,0]  R625      3.3180419355630875e-02
    z[2,10,0]  R626      1.8592732027173042e-02
    z[2,10,0]  R627      1.6429834067821503e-01
    z[2,10,0]  R628      -7.3716074228286743e-02
    z[2,10,0]  R629      -0.0692955031991005
    z[2,10,0]  R630      6.9407053291797638e-02
    z[2,10,0]  R631      7.7760502696037292e-02
    z[2,10,0]  R632      -9.0459384024143219e-02
    z[2,10,0]  R633      2.0266753435134888e-01
    z[2,10,0]  R634      -9.5341032743453979e-01
    z[2,10,0]  R635      -7.9527717828750610e-01
    z[2,10,0]  R636      -1.6221959888935089e-01
    z[2,10,0]  R637      -3.3538690209388733e-01
    z[2,10,0]  R638      -6.7173206806182861e-01
    z[2,10,0]  R639      -7.2031044960021973e-01
    z[2,10,0]  R640      -5.4360526800155640e-01
    z[2,10,0]  R641      4.0064170956611633e-02
    z[2,10,0]  R642      -3.9596247673034668e-01
    z[2,10,0]  R643      -1.0639448463916779e-01
    z[2,10,0]  R644      -3.3186238259077072e-02
    z[2,10,0]  R645      -1.9214755296707153e-01
    z[2,10,0]  R646      1.7047522589564323e-02
    z[2,10,0]  R647      7.0493870973587036e-01
    z[2,10,0]  R648      2.5561478734016418e-01
    z[2,10,0]  R649      -4.4059613347053528e-01
    z[2,10,0]  R650      3.7649184465408325e-01
    z[2,10,0]  R651      3.3047541975975037e-01
    z[2,10,0]  R652      5.3289394825696945e-02
    z[2,10,0]  R653      3.9863339066505432e-01
    z[2,10,0]  R654      5.3017848730087280e-01
    z[2,10,0]  R655      3.3325755596160889e-01
    z[2,10,0]  R656      -4.5387947559356689e-01
    z[2,10,0]  R657      7.8121083974838257e-01
    z[2,10,0]  R658      7.5855886936187744e-01
    z[2,10,0]  R659      7.5848937034606934e-01
    z[2,10,0]  R660      5.9523308277130127e-01
    z[2,10,0]  R661      5.2806007862091064e-01
    z[2,10,0]  R662      8.8914191722869873e-01
    z[2,10,0]  R663      4.8579803109169006e-01
    z[2,10,0]  R664      -4.7163820266723633e-01
    z[2,10,0]  R665      -3.2286411523818970e-01
    z[2,10,0]  R666      -6.2224978208541870e-01
    z[2,10,0]  R667      0.667977511882782
    z[2,10,0]  R668      0.730576753616333
    z[2,10,0]  R669      -6.6829109191894531e-01
    z[2,10,0]  R670      -2.2789682447910309e-01
    z[2,10,0]  R671      5.1489800214767456e-01
    z[2,10,0]  R672      0.525680661201477
    z[2,10,0]  R673      1.4966865070164204e-02
    z[2,10,0]  R674      -3.3636394888162613e-02
    z[2,10,0]  R675      2.4430401623249054e-02
    z[2,10,1]  R21       -1
    z[2,10,1]  R93       1
    z[2,10,1]  R595      -1
    z[2,10,1]  R596      1
    z[2,10,1]  R607      7.9431287944316864e-02
    z[2,10,1]  R608      -3.9755183458328247e-01
    z[2,10,1]  R609      3.2342889904975891e-01
    z[2,10,1]  R610      -2.1219430863857269e-01
    z[2,10,1]  R611      -3.0488333106040955e-01
    z[2,10,1]  R612      -0.0971231609582901
    z[2,10,1]  R613      8.3598485216498375e-03
    z[2,10,1]  R614      6.0215830802917480e-01
    z[2,10,1]  R615      2.8943002223968506e-01
    z[2,10,1]  R616      8.2313740253448486e-01
    z[2,10,1]  R617      4.8249977827072144e-01
    z[2,10,1]  R618      0.0206461139023304
    z[2,10,1]  R619      0.269851952791214
    z[2,10,1]  R620      4.1763129830360413e-01
    z[2,10,1]  R621      2.8551751375198364e-01
    z[2,10,1]  R622      -7.7222526073455811e-02
    z[2,10,1]  R623      -2.4024634063243866e-01
    z[2,10,1]  R624      2.5666579604148865e-01
    z[2,10,1]  R625      6.4945000410079956e-01
    z[2,10,1]  R626      0.73226398229599
    z[2,10,1]  R627      -5.3476440906524658e-01
    z[2,10,1]  R628      -7.6775014400482178e-01
    z[2,10,1]  R629      -7.2509992122650146e-01
    z[2,10,1]  R630      -0.877051591873169
    z[2,10,1]  R631      -7.5436115264892578e-01
    z[2,10,1]  R632      -6.5354037284851074e-01
    z[2,10,1]  R633      -0.711564302444458
    z[2,10,1]  R634      -2.0110936462879181e-01
    z[2,10,1]  R635      -3.6352825164794922e-01
    z[2,10,1]  R636      9.6819110214710236e-02
    z[2,10,1]  R637      -2.3146387934684753e-01
    z[2,10,1]  R638      -2.2125518321990967e-01
    z[2,10,1]  R639      -0.07354686409235
    z[2,10,1]  R640      -2.5858255103230476e-02
    z[2,10,1]  R641      1.3236142694950104e-01
    z[2,10,1]  R642      7.1941041946411133e-01
    z[2,10,1]  R643      0.777656614780426
    z[2,10,1]  R644      9.2878192663192749e-01
    z[2,10,1]  R645      7.6075583696365356e-01
    z[2,10,1]  R646      4.4521963596343994e-01
    z[2,10,1]  R647      5.6351685523986816e-01
    z[2,10,1]  R648      6.1872792243957520e-01
    z[2,10,1]  R649      -8.7522892281413078e-03
    z[2,10,1]  R650      5.6009984016418457e-01
    z[2,10,1]  R651      3.4401011466979980e-01
    z[2,10,1]  R652      6.8093389272689819e-01
    z[2,10,1]  R653      5.4238563776016235e-01
    z[2,10,1]  R654      0.575753927230835
    z[2,10,1]  R655      0.0868731439113617
    z[2,10,1]  R656      -2.7706253528594971e-01
    z[2,10,1]  R657      1.0392618924379349e-01
    z[2,10,1]  R658      2.5629934668540955e-01
    z[2,10,1]  R659      -1.1515791714191437e-01
    z[2,10,1]  R660      6.5352815389633179e-01
    z[2,10,1]  R661      4.6459311246871948e-01
    z[2,10,1]  R662      2.5869302451610565e-02
    z[2,10,1]  R663      2.3106144741177559e-02
    z[2,10,1]  R664      0.689746618270874
    z[2,10,1]  R665      7.8779542446136475e-01
    z[2,10,1]  R666      5.3671532869338989e-01
    z[2,10,1]  R667      4.2481273412704468e-01
    z[2,10,1]  R668      4.7516006231307983e-01
    z[2,10,1]  R669      5.3228777647018433e-01
    z[2,10,1]  R670      8.7884134054183960e-01
    z[2,10,1]  R671      -6.4468294382095337e-01
    z[2,10,1]  R672      -4.4041857123374939e-01
    z[2,10,1]  R673      -3.7349492311477661e-01
    z[2,10,1]  R674      -9.4402414560317993e-01
    z[2,10,1]  R675      -9.1908359527587891e-01
    z[2,10,2]  R22       -1
    z[2,10,2]  R94       1
    z[2,10,2]  R597      -1
    z[2,10,2]  R598      1
    z[2,10,2]  R607      6.2867307662963867e-01
    z[2,10,2]  R608      -2.6678498834371567e-03
    z[2,10,2]  R609      2.3240759968757629e-02
    z[2,10,2]  R610      7.3586237430572510e-01
    z[2,10,2]  R611      4.4503051787614822e-02
    z[2,10,2]  R612      5.2740514278411865e-01
    z[2,10,2]  R613      4.8460975289344788e-01
    z[2,10,2]  R614      -3.4216475486755371e-01
    z[2,10,2]  R615      -2.3476199805736542e-01
    z[2,10,2]  R616      1.9673605263233185e-01
    z[2,10,2]  R617      -7.3031479120254517e-01
    z[2,10,2]  R618      -8.0504369735717773e-01
    z[2,10,2]  R619      -5.3276664018630981e-01
    z[2,10,2]  R620      -2.7399149537086487e-01
    z[2,10,2]  R621      -4.8997423052787781e-01
    z[2,10,2]  R622      -4.6244513988494873e-01
    z[2,10,2]  R623      -6.7258810997009277e-01
    z[2,10,2]  R624      -4.4092249870300293e-01
    z[2,10,2]  R625      -1.0443136096000671e-01
    z[2,10,2]  R626      1.6812039911746979e-01
    z[2,10,2]  R627      1.0284559428691864e-01
    z[2,10,2]  R628      1.0101505368947983e-01
    z[2,10,2]  R629      1.1019319295883179e-01
    z[2,10,2]  R630      2.7593395113945007e-01
    z[2,10,2]  R631      1.3302844762802124e-01
    z[2,10,2]  R632      -3.9581082761287689e-02
    z[2,10,2]  R633      2.4669954180717468e-01
    z[2,10,2]  R634      1.2848532199859619e-01
    z[2,10,2]  R635      -4.5250102877616882e-02
    z[2,10,2]  R636      6.3735437393188477e-01
    z[2,10,2]  R637      7.2271156311035156e-01
    z[2,10,2]  R638      4.2068734765052795e-01
    z[2,10,2]  R639      3.9869260787963867e-01
    z[2,10,2]  R640      4.7542482614517212e-01
    z[2,10,2]  R641      7.8396451473236084e-01
    z[2,10,2]  R642      1.4413902163505554e-01
    z[2,10,2]  R643      -0.00922539085149765
    z[2,10,2]  R644      2.5615987181663513e-01
    z[2,10,2]  R645      2.3350395262241364e-02
    z[2,10,2]  R646      1.0893570631742477e-01
    z[2,10,2]  R647      -3.6954489350318909e-01
    z[2,10,2]  R648      3.5614830255508423e-01
    z[2,10,2]  R649      5.7090330123901367e-01
    z[2,10,2]  R650      7.9694926738739014e-02
    z[2,10,2]  R651      1.1453211307525635e-01
    z[2,10,2]  R652      4.4933900237083435e-02
    z[2,10,2]  R653      2.8335331007838249e-03
    z[2,10,2]  R654      6.3851945102214813e-02
    z[2,10,2]  R655      1.8226327374577522e-02
    z[2,10,2]  R656      3.9491972327232361e-01
    z[2,10,2]  R657      -3.3328625559806824e-01
    z[2,10,2]  R658      -1.5988531708717346e-01
    z[2,10,2]  R659      -1.8396428227424622e-01
    z[2,10,2]  R660      2.0990529656410217e-01
    z[2,10,2]  R661      -2.2523456811904907e-01
    z[2,10,2]  R662      2.3487906157970428e-01
    z[2,10,2]  R663      -1.5950015187263489e-01
    z[2,10,2]  R664      -5.5727638304233551e-02
    z[2,10,2]  R665      -1.8105761706829071e-01
    z[2,10,2]  R666      0.433397114276886
    z[2,10,2]  R667      1.0749153792858124e-02
    z[2,10,2]  R668      2.0894598215818405e-02
    z[2,10,2]  R669      -1.8183549400418997e-03
    z[2,10,2]  R670      -9.2977546155452728e-02
    z[2,10,2]  R671      3.6989018321037292e-01
    z[2,10,2]  R672      2.5401926040649414e-01
    z[2,10,2]  R673      -2.0009872317314148e-01
    z[2,10,2]  R674      -1.8154628574848175e-01
    z[2,10,2]  R675      -2.4609299004077911e-01
    z[2,10,3]  R23       -1
    z[2,10,3]  R95       1
    z[2,10,3]  R599      -1
    z[2,10,3]  R600      1
    z[2,10,3]  R607      6.2566578388214111e-01
    z[2,10,3]  R608      4.9074572324752808e-01
    z[2,10,3]  R609      7.5558441877365112e-01
    z[2,10,3]  R610      3.0732378363609314e-01
    z[2,10,3]  R611      4.1086256504058838e-02
    z[2,10,3]  R612      5.1625502109527588e-01
    z[2,10,3]  R613      2.0595093071460724e-01
    z[2,10,3]  R614      1.3027578592300415e-01
    z[2,10,3]  R615      8.6012363433837891e-02
    z[2,10,3]  R616      -1.4572909474372864e-01
    z[2,10,3]  R617      -3.1805527210235596e-01
    z[2,10,3]  R618      -5.2488803863525391e-01
    z[2,10,3]  R619      -5.9762454032897949e-01
    z[2,10,3]  R620      -5.6750136613845825e-01
    z[2,10,3]  R621      -6.3330346345901489e-01
    z[2,10,3]  R622      -3.8353392481803894e-01
    z[2,10,3]  R623      0.328482985496521
    z[2,10,3]  R624      -5.6475222110748291e-01
    z[2,10,3]  R625      -6.4443355798721313e-01
    z[2,10,3]  R626      -4.9667173624038696e-01
    z[2,10,3]  R627      5.4936748743057251e-01
    z[2,10,3]  R628      5.1287108659744263e-01
    z[2,10,3]  R629      3.5860481858253479e-01
    z[2,10,3]  R630      2.0596887171268463e-01
    z[2,10,3]  R631      4.0284997224807739e-01
    z[2,10,3]  R632      4.1860967874526978e-01
    z[2,10,3]  R633      2.9445654153823853e-01
    z[2,10,3]  R634      -1.5159931778907776e-01
    z[2,10,3]  R635      -7.6267711818218231e-02
    z[2,10,3]  R636      5.5953943729400635e-01
    z[2,10,3]  R637      0.0492120236158371
    z[2,10,3]  R638      3.4767457842826843e-01
    z[2,10,3]  R639      4.3079793453216553e-01
    z[2,10,3]  R640      4.1219744086265564e-01
    z[2,10,3]  R641      1.0982629656791687e-01
    z[2,10,3]  R642      -1.5279197692871094e-01
    z[2,10,3]  R643      -2.4793931841850281e-01
    z[2,10,3]  R644      9.9482759833335876e-02
    z[2,10,3]  R645      -1.3695076107978821e-01
    z[2,10,3]  R646      -7.8917551040649414e-01
    z[2,10,3]  R647      4.8998516052961349e-02
    z[2,10,3]  R648      -5.8927470445632935e-01
    z[2,10,3]  R649      -0.545684278011322
    z[2,10,3]  R650      -5.2617323398590088e-01
    z[2,10,3]  R651      -7.2550749778747559e-01
    z[2,10,3]  R652      -3.5440614819526672e-01
    z[2,10,3]  R653      -0.551074206829071
    z[2,10,3]  R654      -5.4984372854232788e-01
    z[2,10,3]  R655      -9.2329984903335571e-01
    z[2,10,3]  R656      -2.6921549439430237e-01
    z[2,10,3]  R657      -1.6672497987747192e-01
    z[2,10,3]  R658      2.5321945548057556e-01
    z[2,10,3]  R659      -4.8260873556137085e-01
    z[2,10,3]  R660      -4.4024065136909485e-02
    z[2,10,3]  R661      -5.9136878699064255e-02
    z[2,10,3]  R662      -3.6749252676963806e-01
    z[2,10,3]  R663      -0.658893883228302
    z[2,10,3]  R664      1.9627586007118225e-01
    z[2,10,3]  R665      1.3811291754245758e-01
    z[2,10,3]  R666      -1.0940030962228775e-01
    z[2,10,3]  R667      -5.0067198276519775e-01
    z[2,10,3]  R668      -1.4055319130420685e-01
    z[2,10,3]  R669      3.5209640860557556e-01
    z[2,10,3]  R670      2.6984670758247375e-01
    z[2,10,3]  R671      -2.0533490180969238e-01
    z[2,10,3]  R672      -3.7075065076351166e-02
    z[2,10,3]  R673      -6.0983598232269287e-01
    z[2,10,3]  R674      5.2731644362211227e-02
    z[2,10,3]  R675      2.5956892967224121e-01
    z[2,10,4]  R24       -1
    z[2,10,4]  R96       1
    z[2,10,4]  R601      -1
    z[2,10,4]  R602      1
    z[2,10,4]  R607      2.8751331567764282e-01
    z[2,10,4]  R608      4.0704602003097534e-01
    z[2,10,4]  R609      -0.426480770111084
    z[2,10,4]  R610      -3.3437520265579224e-01
    z[2,10,4]  R611      -4.7853785753250122e-01
    z[2,10,4]  R612      -5.2007079124450684e-01
    z[2,10,4]  R613      -0.666246235370636
    z[2,10,4]  R614      5.4549360275268555e-01
    z[2,10,4]  R615      5.2043098211288452e-01
    z[2,10,4]  R616      3.3640742301940918e-01
    z[2,10,4]  R617      4.3694246560335159e-02
    z[2,10,4]  R618      1.3809607923030853e-01
    z[2,10,4]  R619      4.6427417546510696e-02
    z[2,10,4]  R620      -1.1314975097775459e-02
    z[2,10,4]  R621      -5.1508712768554688e-01
    z[2,10,4]  R622      5.3270876407623291e-01
    z[2,10,4]  R623      -1.0619388520717621e-01
    z[2,10,4]  R624      3.6782614886760712e-02
    z[2,10,4]  R625      1.7680945992469788e-01
    z[2,10,4]  R626      -2.3608976975083351e-02
    z[2,10,4]  R627      -4.4129312038421631e-01
    z[2,10,4]  R628      -2.1797710657119751e-01
    z[2,10,4]  R629      -2.6747125387191772e-01
    z[2,10,4]  R630      3.4796193242073059e-02
    z[2,10,4]  R631      -4.4919136166572571e-01
    z[2,10,4]  R632      -5.2068316936492920e-01
    z[2,10,4]  R633      -8.7124384939670563e-02
    z[2,10,4]  R634      2.9048962518572807e-02
    z[2,10,4]  R635      -4.0447497367858887e-01
    z[2,10,4]  R636      -1.9847100973129272e-01
    z[2,10,4]  R637      4.6726310253143311e-01
    z[2,10,4]  R638      2.4667292833328247e-01
    z[2,10,4]  R639      -2.3602540791034698e-01
    z[2,10,4]  R640      -1.6291595995426178e-02
    z[2,10,4]  R641      -4.7038689255714417e-01
    z[2,10,4]  R642      4.0066707134246826e-01
    z[2,10,4]  R643      -3.8378933072090149e-01
    z[2,10,4]  R644      9.9853627383708954e-02
    z[2,10,4]  R645      -4.2679256200790405e-01
    z[2,10,4]  R646      1.7373624444007874e-01
    z[2,10,4]  R647      -1.1630057543516159e-01
    z[2,10,4]  R648      1.5868136286735535e-01
    z[2,10,4]  R649      -2.0123322308063507e-01
    z[2,10,4]  R650      3.8542258739471436e-01
    z[2,10,4]  R651      2.6206815242767334e-01
    z[2,10,4]  R652      5.3734058141708374e-01
    z[2,10,4]  R653      1.4198876917362213e-02
    z[2,10,4]  R654      5.9667877852916718e-02
    z[2,10,4]  R655      1.5926626324653625e-01
    z[2,10,4]  R656      -2.6454201340675354e-01
    z[2,10,4]  R657      0.183299720287323
    z[2,10,4]  R658      3.7857902050018311e-01
    z[2,10,4]  R659      0.0801553800702095
    z[2,10,4]  R660      1.2145221233367920e-01
    z[2,10,4]  R661      -3.8962772488594055e-01
    z[2,10,4]  R662      -1.1109223961830139e-01
    z[2,10,4]  R663      -4.4010823965072632e-01
    z[2,10,4]  R664      2.2769233211874962e-02
    z[2,10,4]  R665      -2.0858123898506165e-01
    z[2,10,4]  R666      1.3694397173821926e-02
    z[2,10,4]  R667      -1.6645327210426331e-01
    z[2,10,4]  R668      -2.7922114729881287e-01
    z[2,10,4]  R669      3.5035413503646851e-01
    z[2,10,4]  R670      -3.9492573589086533e-02
    z[2,10,4]  R671      -2.4358966946601868e-01
    z[2,10,4]  R672      8.1998612731695175e-03
    z[2,10,4]  R673      6.2724345922470093e-01
    z[2,10,4]  R674      1.2638723850250244e-01
    z[2,10,4]  R675      1.2699866294860840e-01
    z[2,10,5]  R25       -1
    z[2,10,5]  R97       1
    z[2,10,5]  R603      -1
    z[2,10,5]  R604      1
    z[2,10,5]  R607      -3.0940619111061096e-01
    z[2,10,5]  R608      -1.6346307098865509e-01
    z[2,10,5]  R609      -2.7923610806465149e-01
    z[2,10,5]  R610      -2.4581816792488098e-01
    z[2,10,5]  R611      3.8688549399375916e-01
    z[2,10,5]  R612      1.5567594766616821e-01
    z[2,10,5]  R613      -1.6993854939937592e-01
    z[2,10,5]  R614      2.7035483717918396e-01
    z[2,10,5]  R615      3.1617123633623123e-02
    z[2,10,5]  R616      -2.7341408655047417e-02
    z[2,10,5]  R617      -1.2265057861804962e-01
    z[2,10,5]  R618      0.0849970206618309
    z[2,10,5]  R619      0.479673832654953
    z[2,10,5]  R620      5.5909407138824463e-01
    z[2,10,5]  R621      1.0885137319564819e-01
    z[2,10,5]  R622      3.5330349206924438e-01
    z[2,10,5]  R623      4.4289442896842957e-01
    z[2,10,5]  R624      2.3056019842624664e-01
    z[2,10,5]  R625      -3.4332033991813660e-01
    z[2,10,5]  R626      2.8997781872749329e-01
    z[2,10,5]  R627      1.0376957803964615e-01
    z[2,10,5]  R628      1.9177818298339844e-01
    z[2,10,5]  R629      -0.384305864572525
    z[2,10,5]  R630      -1.2934236228466034e-01
    z[2,10,5]  R631      2.0152927935123444e-01
    z[2,10,5]  R632      -2.7260735630989075e-01
    z[2,10,5]  R633      5.2765250205993652e-01
    z[2,10,5]  R634      -1.2215762399137020e-02
    z[2,10,5]  R635      -2.5281757116317749e-01
    z[2,10,5]  R636      -4.5196062326431274e-01
    z[2,10,5]  R637      -2.9771599173545837e-01
    z[2,10,5]  R638      -3.3666574954986572e-01
    z[2,10,5]  R639      6.2836207449436188e-02
    z[2,10,5]  R640      1.6856060922145844e-01
    z[2,10,5]  R641      9.2098012566566467e-02
    z[2,10,5]  R642      -1.3682477176189423e-01
    z[2,10,5]  R643      3.8620522618293762e-01
    z[2,10,5]  R644      5.4775953292846680e-02
    z[2,10,5]  R645      -1.5615113079547882e-01
    z[2,10,5]  R646      -0.349942147731781
    z[2,10,5]  R647      1.3385123014450073e-01
    z[2,10,5]  R648      1.9149929285049438e-01
    z[2,10,5]  R649      1.6691130399703979e-01
    z[2,10,5]  R650      3.3369171619415283e-01
    z[2,10,5]  R651      3.4062218666076660e-01
    z[2,10,5]  R652      1.5259779989719391e-01
    z[2,10,5]  R653      -3.1897285580635071e-01
    z[2,10,5]  R654      -2.7829971909523010e-01
    z[2,10,5]  R655      -2.1505707874894142e-02
    z[2,10,5]  R656      -2.5584620237350464e-01
    z[2,10,5]  R657      -3.1098011136054993e-01
    z[2,10,5]  R658      -1.2054960429668427e-01
    z[2,10,5]  R659      2.5374048948287964e-01
    z[2,10,5]  R660      -2.3950074613094330e-01
    z[2,10,5]  R661      -2.1978724002838135e-01
    z[2,10,5]  R662      -5.6092578917741776e-02
    z[2,10,5]  R663      3.0543115735054016e-01
    z[2,10,5]  R664      -6.5410427749156952e-02
    z[2,10,5]  R665      4.2288175225257874e-01
    z[2,10,5]  R666      3.4910789132118225e-01
    z[2,10,5]  R667      7.2588264942169189e-02
    z[2,10,5]  R668      -1.8564362823963165e-01
    z[2,10,5]  R669      3.4037280827760696e-02
    z[2,10,5]  R670      3.8144804537296295e-02
    z[2,10,5]  R671      -2.5996741652488708e-01
    z[2,10,5]  R672      -5.8338552713394165e-01
    z[2,10,5]  R673      5.9076957404613495e-02
    z[2,10,5]  R674      2.3233537375926971e-01
    z[2,10,5]  R675      -3.5585328936576843e-02
    z[2,10,6]  R26       -1
    z[2,10,6]  R98       1
    z[2,10,6]  R605      -1
    z[2,10,6]  R606      1
    z[2,10,6]  R607      -1.6476458311080933e-01
    z[2,10,6]  R608      6.3239151239395142e-01
    z[2,10,6]  R609      2.2137025371193886e-02
    z[2,10,6]  R610      1.1059667170047760e-01
    z[2,10,6]  R611      -7.0395815372467041e-01
    z[2,10,6]  R612      -3.8878101110458374e-01
    z[2,10,6]  R613      -4.9678346514701843e-01
    z[2,10,6]  R614      2.3348443210124969e-02
    z[2,10,6]  R615      -0.579865038394928
    z[2,10,6]  R616      3.6405026912689209e-01
    z[2,10,6]  R617      -3.0655439943075180e-02
    z[2,10,6]  R618      1.5468910336494446e-01
    z[2,10,6]  R619      -1.7028902471065521e-01
    z[2,10,6]  R620      0.309525728225708
    z[2,10,6]  R621      6.4637279137969017e-03
    z[2,10,6]  R622      -3.7308064103126526e-01
    z[2,10,6]  R623      3.3422031998634338e-01
    z[2,10,6]  R624      5.7661163806915283e-01
    z[2,10,6]  R625      -0.0422232411801815
    z[2,10,6]  R626      -3.2226061820983887e-01
    z[2,10,6]  R627      4.1127049922943115e-01
    z[2,10,6]  R628      -2.1815580129623413e-01
    z[2,10,6]  R629      -3.3084192872047424e-01
    z[2,10,6]  R630      -2.9909899830818176e-01
    z[2,10,6]  R631      -5.0208289176225662e-02
    z[2,10,6]  R632      -2.0609614253044128e-01
    z[2,10,6]  R633      1.3794523477554321e-01
    z[2,10,6]  R634      1.0039892047643661e-01
    z[2,10,6]  R635      5.2962714107707143e-04
    z[2,10,6]  R636      -3.6698929965496063e-02
    z[2,10,6]  R637      -4.7293491661548615e-02
    z[2,10,6]  R638      1.6665907204151154e-01
    z[2,10,6]  R639      2.6747813820838928e-01
    z[2,10,6]  R640      5.2840441465377808e-01
    z[2,10,6]  R641      3.5279917716979980e-01
    z[2,10,6]  R642      -0.319821834564209
    z[2,10,6]  R643      1.6100525856018066e-01
    z[2,10,6]  R644      -2.1857939660549164e-01
    z[2,10,6]  R645      -3.9811313152313232e-01
    z[2,10,6]  R646      1.1907972395420074e-01
    z[2,10,6]  R647      1.2289749085903168e-01
    z[2,10,6]  R648      1.2609063088893890e-01
    z[2,10,6]  R649      -3.3725702762603760e-01
    z[2,10,6]  R650      -3.7839386612176895e-02
    z[2,10,6]  R651      2.1968404948711395e-01
    z[2,10,6]  R652      -3.0634212493896484e-01
    z[2,10,6]  R653      3.7586301565170288e-01
    z[2,10,6]  R654      -1.4251054963096976e-03
    z[2,10,6]  R655      5.2434742450714111e-02
    z[2,10,6]  R656      -5.9443366527557373e-01
    z[2,10,6]  R657      -3.3124676346778870e-01
    z[2,10,6]  R658      3.3370870351791382e-01
    z[2,10,6]  R659      2.7178913354873657e-01
    z[2,10,6]  R660      -0.317000150680542
    z[2,10,6]  R661      -5.0096082687377930e-01
    z[2,10,6]  R662      5.5231865495443344e-02
    z[2,10,6]  R663      -1.3000607490539551e-01
    z[2,10,6]  R664      -5.0535160303115845e-01
    z[2,10,6]  R665      3.0740521848201752e-02
    z[2,10,6]  R666      -5.3632840514183044e-02
    z[2,10,6]  R667      -2.9929324984550476e-01
    z[2,10,6]  R668      -3.2842159271240234e-01
    z[2,10,6]  R669      -1.4891290664672852e-01
    z[2,10,6]  R670      -3.0203312635421753e-01
    z[2,10,6]  R671      1.1560201644897461e-01
    z[2,10,6]  R672      3.5126203298568726e-01
    z[2,10,6]  R673      -2.2674590349197388e-01
    z[2,10,6]  R674      4.4654153287410736e-02
    z[2,10,6]  R675      -9.6725314855575562e-02
    z[10,2,0]  R20       1
    z[10,2,0]  R92       -1
    z[10,2,0]  R676      -1
    z[10,2,0]  R677      1
    z[10,2,0]  R690      -1.6221959888935089e-01
    z[10,2,0]  R691      -3.3538690209388733e-01
    z[10,2,0]  R692      -6.7173206806182861e-01
    z[10,2,0]  R693      -7.2031044960021973e-01
    z[10,2,0]  R694      -5.4360526800155640e-01
    z[10,2,0]  R695      4.0064170956611633e-02
    z[10,2,0]  R696      -3.9596247673034668e-01
    z[10,2,0]  R697      -1.0639448463916779e-01
    z[10,2,0]  R698      -3.3186238259077072e-02
    z[10,2,0]  R699      -1.9214755296707153e-01
    z[10,2,0]  R700      1.7047522589564323e-02
    z[10,2,0]  R701      7.0493870973587036e-01
    z[10,2,0]  R702      2.5561478734016418e-01
    z[10,2,0]  R703      -4.4059613347053528e-01
    z[10,2,0]  R704      3.7649184465408325e-01
    z[10,2,0]  R705      3.3047541975975037e-01
    z[10,2,0]  R706      5.3289394825696945e-02
    z[10,2,0]  R707      3.9863339066505432e-01
    z[10,2,0]  R708      5.3017848730087280e-01
    z[10,2,0]  R709      3.3325755596160889e-01
    z[10,2,0]  R710      -4.5387947559356689e-01
    z[10,2,0]  R711      7.8121083974838257e-01
    z[10,2,0]  R712      7.5855886936187744e-01
    z[10,2,0]  R713      7.5848937034606934e-01
    z[10,2,0]  R714      5.9523308277130127e-01
    z[10,2,0]  R715      5.2806007862091064e-01
    z[10,2,0]  R716      8.8914191722869873e-01
    z[10,2,0]  R717      4.8579803109169006e-01
    z[10,2,0]  R718      -4.7163820266723633e-01
    z[10,2,0]  R719      -3.2286411523818970e-01
    z[10,2,0]  R720      -6.2224978208541870e-01
    z[10,2,0]  R721      0.667977511882782
    z[10,2,0]  R722      0.730576753616333
    z[10,2,0]  R723      -6.6829109191894531e-01
    z[10,2,0]  R724      -2.2789682447910309e-01
    z[10,2,0]  R725      5.1489800214767456e-01
    z[10,2,0]  R726      0.525680661201477
    z[10,2,0]  R727      1.4966865070164204e-02
    z[10,2,0]  R728      -3.3636394888162613e-02
    z[10,2,0]  R729      2.4430401623249054e-02
    z[10,2,0]  R730      -3.8206443190574646e-02
    z[10,2,0]  R731      9.3746766448020935e-02
    z[10,2,0]  R732      -2.5218451023101807e-01
    z[10,2,0]  R733      3.6683419346809387e-01
    z[10,2,0]  R734      -1.7070950567722321e-01
    z[10,2,0]  R735      -5.6910580024123192e-03
    z[10,2,0]  R736      5.5773887783288956e-02
    z[10,2,0]  R737      -0.363533616065979
    z[10,2,0]  R738      -4.9560809135437012e-01
    z[10,2,0]  R739      1.2669922411441803e-01
    z[10,2,0]  R740      -3.3879640698432922e-01
    z[10,2,0]  R741      -1.6045930981636047e-01
    z[10,2,0]  R742      -1.5793561935424805e-01
    z[10,2,0]  R743      1.4118921756744385e-01
    z[10,2,0]  R744      1.1255958117544651e-02
    z[10,2,0]  R745      -2.9204767942428589e-01
    z[10,2,0]  R746      -2.5073906779289246e-01
    z[10,2,0]  R747      1.8377426266670227e-01
    z[10,2,0]  R748      3.3180419355630875e-02
    z[10,2,0]  R749      1.8592732027173042e-02
    z[10,2,0]  R750      1.6429834067821503e-01
    z[10,2,0]  R751      -7.3716074228286743e-02
    z[10,2,0]  R752      -0.0692955031991005
    z[10,2,0]  R753      6.9407053291797638e-02
    z[10,2,0]  R754      7.7760502696037292e-02
    z[10,2,0]  R755      -9.0459384024143219e-02
    z[10,2,0]  R756      2.0266753435134888e-01
    z[10,2,0]  R757      -9.5341032743453979e-01
    z[10,2,0]  R758      -7.9527717828750610e-01
    z[10,2,1]  R21       1
    z[10,2,1]  R93       -1
    z[10,2,1]  R678      -1
    z[10,2,1]  R679      1
    z[10,2,1]  R690      9.6819110214710236e-02
    z[10,2,1]  R691      -2.3146387934684753e-01
    z[10,2,1]  R692      -2.2125518321990967e-01
    z[10,2,1]  R693      -0.07354686409235
    z[10,2,1]  R694      -2.5858255103230476e-02
    z[10,2,1]  R695      1.3236142694950104e-01
    z[10,2,1]  R696      7.1941041946411133e-01
    z[10,2,1]  R697      0.777656614780426
    z[10,2,1]  R698      9.2878192663192749e-01
    z[10,2,1]  R699      7.6075583696365356e-01
    z[10,2,1]  R700      4.4521963596343994e-01
    z[10,2,1]  R701      5.6351685523986816e-01
    z[10,2,1]  R702      6.1872792243957520e-01
    z[10,2,1]  R703      -8.7522892281413078e-03
    z[10,2,1]  R704      5.6009984016418457e-01
    z[10,2,1]  R705      3.4401011466979980e-01
    z[10,2,1]  R706      6.8093389272689819e-01
    z[10,2,1]  R707      5.4238563776016235e-01
    z[10,2,1]  R708      0.575753927230835
    z[10,2,1]  R709      0.0868731439113617
    z[10,2,1]  R710      -2.7706253528594971e-01
    z[10,2,1]  R711      1.0392618924379349e-01
    z[10,2,1]  R712      2.5629934668540955e-01
    z[10,2,1]  R713      -1.1515791714191437e-01
    z[10,2,1]  R714      6.5352815389633179e-01
    z[10,2,1]  R715      4.6459311246871948e-01
    z[10,2,1]  R716      2.5869302451610565e-02
    z[10,2,1]  R717      2.3106144741177559e-02
    z[10,2,1]  R718      0.689746618270874
    z[10,2,1]  R719      7.8779542446136475e-01
    z[10,2,1]  R720      5.3671532869338989e-01
    z[10,2,1]  R721      4.2481273412704468e-01
    z[10,2,1]  R722      4.7516006231307983e-01
    z[10,2,1]  R723      5.3228777647018433e-01
    z[10,2,1]  R724      8.7884134054183960e-01
    z[10,2,1]  R725      -6.4468294382095337e-01
    z[10,2,1]  R726      -4.4041857123374939e-01
    z[10,2,1]  R727      -3.7349492311477661e-01
    z[10,2,1]  R728      -9.4402414560317993e-01
    z[10,2,1]  R729      -9.1908359527587891e-01
    z[10,2,1]  R730      7.9431287944316864e-02
    z[10,2,1]  R731      -3.9755183458328247e-01
    z[10,2,1]  R732      3.2342889904975891e-01
    z[10,2,1]  R733      -2.1219430863857269e-01
    z[10,2,1]  R734      -3.0488333106040955e-01
    z[10,2,1]  R735      -0.0971231609582901
    z[10,2,1]  R736      8.3598485216498375e-03
    z[10,2,1]  R737      6.0215830802917480e-01
    z[10,2,1]  R738      2.8943002223968506e-01
    z[10,2,1]  R739      8.2313740253448486e-01
    z[10,2,1]  R740      4.8249977827072144e-01
    z[10,2,1]  R741      0.0206461139023304
    z[10,2,1]  R742      0.269851952791214
    z[10,2,1]  R743      4.1763129830360413e-01
    z[10,2,1]  R744      2.8551751375198364e-01
    z[10,2,1]  R745      -7.7222526073455811e-02
    z[10,2,1]  R746      -2.4024634063243866e-01
    z[10,2,1]  R747      2.5666579604148865e-01
    z[10,2,1]  R748      6.4945000410079956e-01
    z[10,2,1]  R749      0.73226398229599
    z[10,2,1]  R750      -5.3476440906524658e-01
    z[10,2,1]  R751      -7.6775014400482178e-01
    z[10,2,1]  R752      -7.2509992122650146e-01
    z[10,2,1]  R753      -0.877051591873169
    z[10,2,1]  R754      -7.5436115264892578e-01
    z[10,2,1]  R755      -6.5354037284851074e-01
    z[10,2,1]  R756      -0.711564302444458
    z[10,2,1]  R757      -2.0110936462879181e-01
    z[10,2,1]  R758      -3.6352825164794922e-01
    z[10,2,2]  R22       1
    z[10,2,2]  R94       -1
    z[10,2,2]  R680      -1
    z[10,2,2]  R681      1
    z[10,2,2]  R690      6.3735437393188477e-01
    z[10,2,2]  R691      7.2271156311035156e-01
    z[10,2,2]  R692      4.2068734765052795e-01
    z[10,2,2]  R693      3.9869260787963867e-01
    z[10,2,2]  R694      4.7542482614517212e-01
    z[10,2,2]  R695      7.8396451473236084e-01
    z[10,2,2]  R696      1.4413902163505554e-01
    z[10,2,2]  R697      -0.00922539085149765
    z[10,2,2]  R698      2.5615987181663513e-01
    z[10,2,2]  R699      2.3350395262241364e-02
    z[10,2,2]  R700      1.0893570631742477e-01
    z[10,2,2]  R701      -3.6954489350318909e-01
    z[10,2,2]  R702      3.5614830255508423e-01
    z[10,2,2]  R703      5.7090330123901367e-01
    z[10,2,2]  R704      7.9694926738739014e-02
    z[10,2,2]  R705      1.1453211307525635e-01
    z[10,2,2]  R706      4.4933900237083435e-02
    z[10,2,2]  R707      2.8335331007838249e-03
    z[10,2,2]  R708      6.3851945102214813e-02
    z[10,2,2]  R709      1.8226327374577522e-02
    z[10,2,2]  R710      3.9491972327232361e-01
    z[10,2,2]  R711      -3.3328625559806824e-01
    z[10,2,2]  R712      -1.5988531708717346e-01
    z[10,2,2]  R713      -1.8396428227424622e-01
    z[10,2,2]  R714      2.0990529656410217e-01
    z[10,2,2]  R715      -2.2523456811904907e-01
    z[10,2,2]  R716      2.3487906157970428e-01
    z[10,2,2]  R717      -1.5950015187263489e-01
    z[10,2,2]  R718      -5.5727638304233551e-02
    z[10,2,2]  R719      -1.8105761706829071e-01
    z[10,2,2]  R720      0.433397114276886
    z[10,2,2]  R721      1.0749153792858124e-02
    z[10,2,2]  R722      2.0894598215818405e-02
    z[10,2,2]  R723      -1.8183549400418997e-03
    z[10,2,2]  R724      -9.2977546155452728e-02
    z[10,2,2]  R725      3.6989018321037292e-01
    z[10,2,2]  R726      2.5401926040649414e-01
    z[10,2,2]  R727      -2.0009872317314148e-01
    z[10,2,2]  R728      -1.8154628574848175e-01
    z[10,2,2]  R729      -2.4609299004077911e-01
    z[10,2,2]  R730      6.2867307662963867e-01
    z[10,2,2]  R731      -2.6678498834371567e-03
    z[10,2,2]  R732      2.3240759968757629e-02
    z[10,2,2]  R733      7.3586237430572510e-01
    z[10,2,2]  R734      4.4503051787614822e-02
    z[10,2,2]  R735      5.2740514278411865e-01
    z[10,2,2]  R736      4.8460975289344788e-01
    z[10,2,2]  R737      -3.4216475486755371e-01
    z[10,2,2]  R738      -2.3476199805736542e-01
    z[10,2,2]  R739      1.9673605263233185e-01
    z[10,2,2]  R740      -7.3031479120254517e-01
    z[10,2,2]  R741      -8.0504369735717773e-01
    z[10,2,2]  R742      -5.3276664018630981e-01
    z[10,2,2]  R743      -2.7399149537086487e-01
    z[10,2,2]  R744      -4.8997423052787781e-01
    z[10,2,2]  R745      -4.6244513988494873e-01
    z[10,2,2]  R746      -6.7258810997009277e-01
    z[10,2,2]  R747      -4.4092249870300293e-01
    z[10,2,2]  R748      -1.0443136096000671e-01
    z[10,2,2]  R749      1.6812039911746979e-01
    z[10,2,2]  R750      1.0284559428691864e-01
    z[10,2,2]  R751      1.0101505368947983e-01
    z[10,2,2]  R752      1.1019319295883179e-01
    z[10,2,2]  R753      2.7593395113945007e-01
    z[10,2,2]  R754      1.3302844762802124e-01
    z[10,2,2]  R755      -3.9581082761287689e-02
    z[10,2,2]  R756      2.4669954180717468e-01
    z[10,2,2]  R757      1.2848532199859619e-01
    z[10,2,2]  R758      -4.5250102877616882e-02
    z[10,2,3]  R23       1
    z[10,2,3]  R95       -1
    z[10,2,3]  R682      -1
    z[10,2,3]  R683      1
    z[10,2,3]  R690      5.5953943729400635e-01
    z[10,2,3]  R691      0.0492120236158371
    z[10,2,3]  R692      3.4767457842826843e-01
    z[10,2,3]  R693      4.3079793453216553e-01
    z[10,2,3]  R694      4.1219744086265564e-01
    z[10,2,3]  R695      1.0982629656791687e-01
    z[10,2,3]  R696      -1.5279197692871094e-01
    z[10,2,3]  R697      -2.4793931841850281e-01
    z[10,2,3]  R698      9.9482759833335876e-02
    z[10,2,3]  R699      -1.3695076107978821e-01
    z[10,2,3]  R700      -7.8917551040649414e-01
    z[10,2,3]  R701      4.8998516052961349e-02
    z[10,2,3]  R702      -5.8927470445632935e-01
    z[10,2,3]  R703      -0.545684278011322
    z[10,2,3]  R704      -5.2617323398590088e-01
    z[10,2,3]  R705      -7.2550749778747559e-01
    z[10,2,3]  R706      -3.5440614819526672e-01
    z[10,2,3]  R707      -0.551074206829071
    z[10,2,3]  R708      -5.4984372854232788e-01
    z[10,2,3]  R709      -9.2329984903335571e-01
    z[10,2,3]  R710      -2.6921549439430237e-01
    z[10,2,3]  R711      -1.6672497987747192e-01
    z[10,2,3]  R712      2.5321945548057556e-01
    z[10,2,3]  R713      -4.8260873556137085e-01
    z[10,2,3]  R714      -4.4024065136909485e-02
    z[10,2,3]  R715      -5.9136878699064255e-02
    z[10,2,3]  R716      -3.6749252676963806e-01
    z[10,2,3]  R717      -0.658893883228302
    z[10,2,3]  R718      1.9627586007118225e-01
    z[10,2,3]  R719      1.3811291754245758e-01
    z[10,2,3]  R720      -1.0940030962228775e-01
    z[10,2,3]  R721      -5.0067198276519775e-01
    z[10,2,3]  R722      -1.4055319130420685e-01
    z[10,2,3]  R723      3.5209640860557556e-01
    z[10,2,3]  R724      2.6984670758247375e-01
    z[10,2,3]  R725      -2.0533490180969238e-01
    z[10,2,3]  R726      -3.7075065076351166e-02
    z[10,2,3]  R727      -6.0983598232269287e-01
    z[10,2,3]  R728      5.2731644362211227e-02
    z[10,2,3]  R729      2.5956892967224121e-01
    z[10,2,3]  R730      6.2566578388214111e-01
    z[10,2,3]  R731      4.9074572324752808e-01
    z[10,2,3]  R732      7.5558441877365112e-01
    z[10,2,3]  R733      3.0732378363609314e-01
    z[10,2,3]  R734      4.1086256504058838e-02
    z[10,2,3]  R735      5.1625502109527588e-01
    z[10,2,3]  R736      2.0595093071460724e-01
    z[10,2,3]  R737      1.3027578592300415e-01
    z[10,2,3]  R738      8.6012363433837891e-02
    z[10,2,3]  R739      -1.4572909474372864e-01
    z[10,2,3]  R740      -3.1805527210235596e-01
    z[10,2,3]  R741      -5.2488803863525391e-01
    z[10,2,3]  R742      -5.9762454032897949e-01
    z[10,2,3]  R743      -5.6750136613845825e-01
    z[10,2,3]  R744      -6.3330346345901489e-01
    z[10,2,3]  R745      -3.8353392481803894e-01
    z[10,2,3]  R746      0.328482985496521
    z[10,2,3]  R747      -5.6475222110748291e-01
    z[10,2,3]  R748      -6.4443355798721313e-01
    z[10,2,3]  R749      -4.9667173624038696e-01
    z[10,2,3]  R750      5.4936748743057251e-01
    z[10,2,3]  R751      5.1287108659744263e-01
    z[10,2,3]  R752      3.5860481858253479e-01
    z[10,2,3]  R753      2.0596887171268463e-01
    z[10,2,3]  R754      4.0284997224807739e-01
    z[10,2,3]  R755      4.1860967874526978e-01
    z[10,2,3]  R756      2.9445654153823853e-01
    z[10,2,3]  R757      -1.5159931778907776e-01
    z[10,2,3]  R758      -7.6267711818218231e-02
    z[10,2,4]  R24       1
    z[10,2,4]  R96       -1
    z[10,2,4]  R684      -1
    z[10,2,4]  R685      1
    z[10,2,4]  R690      -1.9847100973129272e-01
    z[10,2,4]  R691      4.6726310253143311e-01
    z[10,2,4]  R692      2.4667292833328247e-01
    z[10,2,4]  R693      -2.3602540791034698e-01
    z[10,2,4]  R694      -1.6291595995426178e-02
    z[10,2,4]  R695      -4.7038689255714417e-01
    z[10,2,4]  R696      4.0066707134246826e-01
    z[10,2,4]  R697      -3.8378933072090149e-01
    z[10,2,4]  R698      9.9853627383708954e-02
    z[10,2,4]  R699      -4.2679256200790405e-01
    z[10,2,4]  R700      1.7373624444007874e-01
    z[10,2,4]  R701      -1.1630057543516159e-01
    z[10,2,4]  R702      1.5868136286735535e-01
    z[10,2,4]  R703      -2.0123322308063507e-01
    z[10,2,4]  R704      3.8542258739471436e-01
    z[10,2,4]  R705      2.6206815242767334e-01
    z[10,2,4]  R706      5.3734058141708374e-01
    z[10,2,4]  R707      1.4198876917362213e-02
    z[10,2,4]  R708      5.9667877852916718e-02
    z[10,2,4]  R709      1.5926626324653625e-01
    z[10,2,4]  R710      -2.6454201340675354e-01
    z[10,2,4]  R711      0.183299720287323
    z[10,2,4]  R712      3.7857902050018311e-01
    z[10,2,4]  R713      0.0801553800702095
    z[10,2,4]  R714      1.2145221233367920e-01
    z[10,2,4]  R715      -3.8962772488594055e-01
    z[10,2,4]  R716      -1.1109223961830139e-01
    z[10,2,4]  R717      -4.4010823965072632e-01
    z[10,2,4]  R718      2.2769233211874962e-02
    z[10,2,4]  R719      -2.0858123898506165e-01
    z[10,2,4]  R720      1.3694397173821926e-02
    z[10,2,4]  R721      -1.6645327210426331e-01
    z[10,2,4]  R722      -2.7922114729881287e-01
    z[10,2,4]  R723      3.5035413503646851e-01
    z[10,2,4]  R724      -3.9492573589086533e-02
    z[10,2,4]  R725      -2.4358966946601868e-01
    z[10,2,4]  R726      8.1998612731695175e-03
    z[10,2,4]  R727      6.2724345922470093e-01
    z[10,2,4]  R728      1.2638723850250244e-01
    z[10,2,4]  R729      1.2699866294860840e-01
    z[10,2,4]  R730      2.8751331567764282e-01
    z[10,2,4]  R731      4.0704602003097534e-01
    z[10,2,4]  R732      -0.426480770111084
    z[10,2,4]  R733      -3.3437520265579224e-01
    z[10,2,4]  R734      -4.7853785753250122e-01
    z[10,2,4]  R735      -5.2007079124450684e-01
    z[10,2,4]  R736      -0.666246235370636
    z[10,2,4]  R737      5.4549360275268555e-01
    z[10,2,4]  R738      5.2043098211288452e-01
    z[10,2,4]  R739      3.3640742301940918e-01
    z[10,2,4]  R740      4.3694246560335159e-02
    z[10,2,4]  R741      1.3809607923030853e-01
    z[10,2,4]  R742      4.6427417546510696e-02
    z[10,2,4]  R743      -1.1314975097775459e-02
    z[10,2,4]  R744      -5.1508712768554688e-01
    z[10,2,4]  R745      5.3270876407623291e-01
    z[10,2,4]  R746      -1.0619388520717621e-01
    z[10,2,4]  R747      3.6782614886760712e-02
    z[10,2,4]  R748      1.7680945992469788e-01
    z[10,2,4]  R749      -2.3608976975083351e-02
    z[10,2,4]  R750      -4.4129312038421631e-01
    z[10,2,4]  R751      -2.1797710657119751e-01
    z[10,2,4]  R752      -2.6747125387191772e-01
    z[10,2,4]  R753      3.4796193242073059e-02
    z[10,2,4]  R754      -4.4919136166572571e-01
    z[10,2,4]  R755      -5.2068316936492920e-01
    z[10,2,4]  R756      -8.7124384939670563e-02
    z[10,2,4]  R757      2.9048962518572807e-02
    z[10,2,4]  R758      -4.0447497367858887e-01
    z[10,2,5]  R25       1
    z[10,2,5]  R97       -1
    z[10,2,5]  R686      -1
    z[10,2,5]  R687      1
    z[10,2,5]  R690      -4.5196062326431274e-01
    z[10,2,5]  R691      -2.9771599173545837e-01
    z[10,2,5]  R692      -3.3666574954986572e-01
    z[10,2,5]  R693      6.2836207449436188e-02
    z[10,2,5]  R694      1.6856060922145844e-01
    z[10,2,5]  R695      9.2098012566566467e-02
    z[10,2,5]  R696      -1.3682477176189423e-01
    z[10,2,5]  R697      3.8620522618293762e-01
    z[10,2,5]  R698      5.4775953292846680e-02
    z[10,2,5]  R699      -1.5615113079547882e-01
    z[10,2,5]  R700      -0.349942147731781
    z[10,2,5]  R701      1.3385123014450073e-01
    z[10,2,5]  R702      1.9149929285049438e-01
    z[10,2,5]  R703      1.6691130399703979e-01
    z[10,2,5]  R704      3.3369171619415283e-01
    z[10,2,5]  R705      3.4062218666076660e-01
    z[10,2,5]  R706      1.5259779989719391e-01
    z[10,2,5]  R707      -3.1897285580635071e-01
    z[10,2,5]  R708      -2.7829971909523010e-01
    z[10,2,5]  R709      -2.1505707874894142e-02
    z[10,2,5]  R710      -2.5584620237350464e-01
    z[10,2,5]  R711      -3.1098011136054993e-01
    z[10,2,5]  R712      -1.2054960429668427e-01
    z[10,2,5]  R713      2.5374048948287964e-01
    z[10,2,5]  R714      -2.3950074613094330e-01
    z[10,2,5]  R715      -2.1978724002838135e-01
    z[10,2,5]  R716      -5.6092578917741776e-02
    z[10,2,5]  R717      3.0543115735054016e-01
    z[10,2,5]  R718      -6.5410427749156952e-02
    z[10,2,5]  R719      4.2288175225257874e-01
    z[10,2,5]  R720      3.4910789132118225e-01
    z[10,2,5]  R721      7.2588264942169189e-02
    z[10,2,5]  R722      -1.8564362823963165e-01
    z[10,2,5]  R723      3.4037280827760696e-02
    z[10,2,5]  R724      3.8144804537296295e-02
    z[10,2,5]  R725      -2.5996741652488708e-01
    z[10,2,5]  R726      -5.8338552713394165e-01
    z[10,2,5]  R727      5.9076957404613495e-02
    z[10,2,5]  R728      2.3233537375926971e-01
    z[10,2,5]  R729      -3.5585328936576843e-02
    z[10,2,5]  R730      -3.0940619111061096e-01
    z[10,2,5]  R731      -1.6346307098865509e-01
    z[10,2,5]  R732      -2.7923610806465149e-01
    z[10,2,5]  R733      -2.4581816792488098e-01
    z[10,2,5]  R734      3.8688549399375916e-01
    z[10,2,5]  R735      1.5567594766616821e-01
    z[10,2,5]  R736      -1.6993854939937592e-01
    z[10,2,5]  R737      2.7035483717918396e-01
    z[10,2,5]  R738      3.1617123633623123e-02
    z[10,2,5]  R739      -2.7341408655047417e-02
    z[10,2,5]  R740      -1.2265057861804962e-01
    z[10,2,5]  R741      0.0849970206618309
    z[10,2,5]  R742      0.479673832654953
    z[10,2,5]  R743      5.5909407138824463e-01
    z[10,2,5]  R744      1.0885137319564819e-01
    z[10,2,5]  R745      3.5330349206924438e-01
    z[10,2,5]  R746      4.4289442896842957e-01
    z[10,2,5]  R747      2.3056019842624664e-01
    z[10,2,5]  R748      -3.4332033991813660e-01
    z[10,2,5]  R749      2.8997781872749329e-01
    z[10,2,5]  R750      1.0376957803964615e-01
    z[10,2,5]  R751      1.9177818298339844e-01
    z[10,2,5]  R752      -0.384305864572525
    z[10,2,5]  R753      -1.2934236228466034e-01
    z[10,2,5]  R754      2.0152927935123444e-01
    z[10,2,5]  R755      -2.7260735630989075e-01
    z[10,2,5]  R756      5.2765250205993652e-01
    z[10,2,5]  R757      -1.2215762399137020e-02
    z[10,2,5]  R758      -2.5281757116317749e-01
    z[10,2,6]  R26       1
    z[10,2,6]  R98       -1
    z[10,2,6]  R688      -1
    z[10,2,6]  R689      1
    z[10,2,6]  R690      -3.6698929965496063e-02
    z[10,2,6]  R691      -4.7293491661548615e-02
    z[10,2,6]  R692      1.6665907204151154e-01
    z[10,2,6]  R693      2.6747813820838928e-01
    z[10,2,6]  R694      5.2840441465377808e-01
    z[10,2,6]  R695      3.5279917716979980e-01
    z[10,2,6]  R696      -0.319821834564209
    z[10,2,6]  R697      1.6100525856018066e-01
    z[10,2,6]  R698      -2.1857939660549164e-01
    z[10,2,6]  R699      -3.9811313152313232e-01
    z[10,2,6]  R700      1.1907972395420074e-01
    z[10,2,6]  R701      1.2289749085903168e-01
    z[10,2,6]  R702      1.2609063088893890e-01
    z[10,2,6]  R703      -3.3725702762603760e-01
    z[10,2,6]  R704      -3.7839386612176895e-02
    z[10,2,6]  R705      2.1968404948711395e-01
    z[10,2,6]  R706      -3.0634212493896484e-01
    z[10,2,6]  R707      3.7586301565170288e-01
    z[10,2,6]  R708      -1.4251054963096976e-03
    z[10,2,6]  R709      5.2434742450714111e-02
    z[10,2,6]  R710      -5.9443366527557373e-01
    z[10,2,6]  R711      -3.3124676346778870e-01
    z[10,2,6]  R712      3.3370870351791382e-01
    z[10,2,6]  R713      2.7178913354873657e-01
    z[10,2,6]  R714      -0.317000150680542
    z[10,2,6]  R715      -5.0096082687377930e-01
    z[10,2,6]  R716      5.5231865495443344e-02
    z[10,2,6]  R717      -1.3000607490539551e-01
    z[10,2,6]  R718      -5.0535160303115845e-01
    z[10,2,6]  R719      3.0740521848201752e-02
    z[10,2,6]  R720      -5.3632840514183044e-02
    z[10,2,6]  R721      -2.9929324984550476e-01
    z[10,2,6]  R722      -3.2842159271240234e-01
    z[10,2,6]  R723      -1.4891290664672852e-01
    z[10,2,6]  R724      -3.0203312635421753e-01
    z[10,2,6]  R725      1.1560201644897461e-01
    z[10,2,6]  R726      3.5126203298568726e-01
    z[10,2,6]  R727      -2.2674590349197388e-01
    z[10,2,6]  R728      4.4654153287410736e-02
    z[10,2,6]  R729      -9.6725314855575562e-02
    z[10,2,6]  R730      -1.6476458311080933e-01
    z[10,2,6]  R731      6.3239151239395142e-01
    z[10,2,6]  R732      2.2137025371193886e-02
    z[10,2,6]  R733      1.1059667170047760e-01
    z[10,2,6]  R734      -7.0395815372467041e-01
    z[10,2,6]  R735      -3.8878101110458374e-01
    z[10,2,6]  R736      -4.9678346514701843e-01
    z[10,2,6]  R737      2.3348443210124969e-02
    z[10,2,6]  R738      -0.579865038394928
    z[10,2,6]  R739      3.6405026912689209e-01
    z[10,2,6]  R740      -3.0655439943075180e-02
    z[10,2,6]  R741      1.5468910336494446e-01
    z[10,2,6]  R742      -1.7028902471065521e-01
    z[10,2,6]  R743      0.309525728225708
    z[10,2,6]  R744      6.4637279137969017e-03
    z[10,2,6]  R745      -3.7308064103126526e-01
    z[10,2,6]  R746      3.3422031998634338e-01
    z[10,2,6]  R747      5.7661163806915283e-01
    z[10,2,6]  R748      -0.0422232411801815
    z[10,2,6]  R749      -3.2226061820983887e-01
    z[10,2,6]  R750      4.1127049922943115e-01
    z[10,2,6]  R751      -2.1815580129623413e-01
    z[10,2,6]  R752      -3.3084192872047424e-01
    z[10,2,6]  R753      -2.9909899830818176e-01
    z[10,2,6]  R754      -5.0208289176225662e-02
    z[10,2,6]  R755      -2.0609614253044128e-01
    z[10,2,6]  R756      1.3794523477554321e-01
    z[10,2,6]  R757      1.0039892047643661e-01
    z[10,2,6]  R758      5.2962714107707143e-04
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R802      -1
    z[3,4,0]  R803      1
    z[3,4,0]  R816      1.9507057964801788e-01
    z[3,4,0]  R817      3.6697140336036682e-01
    z[3,4,0]  R818      2.8205236792564392e-01
    z[3,4,0]  R819      4.2801365256309509e-01
    z[3,4,0]  R820      -6.6984174773097038e-03
    z[3,4,0]  R821      -1.2007335573434830e-01
    z[3,4,0]  R822      1.9108036160469055e-01
    z[3,4,0]  R823      -1.9672195613384247e-01
    z[3,4,0]  R824      -4.0340952575206757e-02
    z[3,4,0]  R825      -2.1231804788112640e-01
    z[3,4,0]  R826      -1.6643962264060974e-01
    z[3,4,0]  R827      3.2462522387504578e-01
    z[3,4,0]  R828      2.2524490952491760e-02
    z[3,4,0]  R829      -7.1754038333892822e-02
    z[3,4,0]  R830      -6.2028553336858749e-02
    z[3,4,0]  R831      6.4146465063095093e-01
    z[3,4,0]  R832      4.4850829243659973e-01
    z[3,4,0]  R833      6.4898796379566193e-02
    z[3,4,0]  R834      -7.6559305191040039e-01
    z[3,4,0]  R835      2.0446164906024933e-01
    z[3,4,0]  R836      7.6459348201751709e-01
    z[3,4,0]  R837      5.7732760906219482e-01
    z[3,4,0]  R838      2.6761946082115173e-01
    z[3,4,0]  R839      1.8276479095220566e-02
    z[3,4,0]  R840      1.1998645216226578e-01
    z[3,4,0]  R841      6.4301635138690472e-03
    z[3,4,0]  R842      3.2188287377357483e-01
    z[3,4,0]  R843      2.7721645310521126e-02
    z[3,4,0]  R844      5.9904661029577255e-02
    z[3,4,0]  R845      0.858936071395874
    z[3,4,0]  R846      8.3661407232284546e-01
    z[3,4,0]  R847      0.852433979511261
    z[3,4,0]  R848      8.1905382871627808e-01
    z[3,4,0]  R849      -1.7209856212139130e-01
    z[3,4,0]  R850      -1.0541781038045883e-01
    z[3,4,0]  R851      -2.4894516170024872e-01
    z[3,4,0]  R852      -3.6012226343154907e-01
    z[3,4,0]  R853      5.3793575614690781e-02
    z[3,4,0]  R854      -7.2886824607849121e-01
    z[3,4,0]  R855      3.1899258494377136e-01
    z[3,4,0]  R856      -2.4710580706596375e-02
    z[3,4,0]  R857      5.6930180639028549e-02
    z[3,4,0]  R858      2.9730057716369629e-01
    z[3,4,0]  R859      -7.6461881399154663e-01
    z[3,4,0]  R860      3.1305238604545593e-02
    z[3,4,0]  R861      -2.4371033906936646e-01
    z[3,4,0]  R862      -6.6487453877925873e-02
    z[3,4,0]  R863      1.7442536354064941e-01
    z[3,4,0]  R864      -2.1793624758720398e-01
    z[3,4,0]  R865      1.1814450845122337e-02
    z[3,4,0]  R866      -1.3853733241558075e-01
    z[3,4,0]  R867      -2.6652544736862183e-01
    z[3,4,0]  R868      -2.8162550926208496e-01
    z[3,4,0]  R869      -5.9845107793807983e-01
    z[3,4,0]  R870      2.3119193315505981e-01
    z[3,4,0]  R871      1.5551097691059113e-01
    z[3,4,0]  R872      2.6353845000267029e-01
    z[3,4,0]  R873      7.6957635581493378e-02
    z[3,4,0]  R874      -5.1124148070812225e-02
    z[3,4,0]  R875      2.0614919066429138e-01
    z[3,4,0]  R876      -4.9619201570749283e-02
    z[3,4,0]  R877      -1.0518789291381836e-01
    z[3,4,0]  R878      -7.7299750410020351e-03
    z[3,4,0]  R879      -7.8285849094390869e-01
    z[3,4,0]  R880      -4.2401376366615295e-01
    z[3,4,0]  R881      -2.3066484928131104e-01
    z[3,4,0]  R882      -3.7945550680160522e-01
    z[3,4,0]  R883      -1.3252480328083038e-01
    z[3,4,0]  R884      -2.2853079438209534e-01
    z[3,4,0]  R885      -3.3826592564582825e-01
    z[3,4,0]  R886      3.2707676291465759e-01
    z[3,4,0]  R887      -8.2660518586635590e-02
    z[3,4,0]  R888      -1.9516560435295105e-01
    z[3,4,0]  R889      -3.0983048677444458e-01
    z[3,4,0]  R890      -5.8509427309036255e-01
    z[3,4,0]  R891      -3.4305313229560852e-01
    z[3,4,0]  R892      3.4879993181675673e-03
    z[3,4,0]  R893      2.7744683623313904e-01
    z[3,4,0]  R894      -7.3124817572534084e-03
    z[3,4,0]  R895      -1.5040916204452515e-01
    z[3,4,0]  R896      -8.9968644082546234e-02
    z[3,4,0]  R897      5.3375765681266785e-02
    z[3,4,0]  R898      -5.7130229473114014e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R804      -1
    z[3,4,1]  R805      1
    z[3,4,1]  R816      -3.0789560079574585e-01
    z[3,4,1]  R817      -1.8975988030433655e-01
    z[3,4,1]  R818      -1.4079466462135315e-01
    z[3,4,1]  R819      -3.1250080466270447e-01
    z[3,4,1]  R820      8.7949460744857788e-01
    z[3,4,1]  R821      8.0771207809448242e-01
    z[3,4,1]  R822      -2.9321369528770447e-01
    z[3,4,1]  R823      6.1159390211105347e-01
    z[3,4,1]  R824      7.3790258169174194e-01
    z[3,4,1]  R825      -8.2718676328659058e-01
    z[3,4,1]  R826      -1.9574034959077835e-02
    z[3,4,1]  R827      2.7573844790458679e-01
    z[3,4,1]  R828      9.1792166233062744e-01
    z[3,4,1]  R829      0.639064371585846
    z[3,4,1]  R830      5.9099310636520386e-01
    z[3,4,1]  R831      5.3242707252502441e-01
    z[3,4,1]  R832      5.2474248409271240e-01
    z[3,4,1]  R833      -3.7084934115409851e-01
    z[3,4,1]  R834      -1.4658871293067932e-01
    z[3,4,1]  R835      9.1791230440139771e-01
    z[3,4,1]  R836      4.5774844288825989e-01
    z[3,4,1]  R837      4.1560354828834534e-01
    z[3,4,1]  R838      2.2112429141998291e-01
    z[3,4,1]  R839      8.8279730081558228e-01
    z[3,4,1]  R840      8.9820599555969238e-01
    z[3,4,1]  R841      5.1838332414627075e-01
    z[3,4,1]  R842      5.8870565891265869e-01
    z[3,4,1]  R843      5.4523938894271851e-01
    z[3,4,1]  R844      5.5945807695388794e-01
    z[3,4,1]  R845      -1.0856576263904572e-01
    z[3,4,1]  R846      1.3602754473686218e-01
    z[3,4,1]  R847      -2.1678301692008972e-01
    z[3,4,1]  R848      5.0889525562524796e-02
    z[3,4,1]  R849      1.0282338410615921e-01
    z[3,4,1]  R850      3.7497210502624512e-01
    z[3,4,1]  R851      0.122503861784935
    z[3,4,1]  R852      4.6388339251279831e-02
    z[3,4,1]  R853      6.4730048179626465e-02
    z[3,4,1]  R854      4.2699292302131653e-01
    z[3,4,1]  R855      -8.9471697807312012e-01
    z[3,4,1]  R856      -8.8038235902786255e-01
    z[3,4,1]  R857      -8.2952016592025757e-01
    z[3,4,1]  R858      3.6464259028434753e-02
    z[3,4,1]  R859      4.4890657067298889e-01
    z[3,4,1]  R860      -9.4527572393417358e-01
    z[3,4,1]  R861      -9.1798186302185059e-01
    z[3,4,1]  R862      -8.9208728075027466e-01
    z[3,4,1]  R863      -8.6514890193939209e-01
    z[3,4,1]  R864      -8.3336752653121948e-01
    z[3,4,1]  R865      -8.1203687191009521e-01
    z[3,4,1]  R866      -5.5051195621490479e-01
    z[3,4,1]  R867      -9.1903531551361084e-01
    z[3,4,1]  R868      -8.1354314088821411e-01
    z[3,4,1]  R869      -3.8258321583271027e-02
    z[3,4,1]  R870      -9.3632888793945312e-01
    z[3,4,1]  R871      -9.2413526773452759e-01
    z[3,4,1]  R872      -8.6651885509490967e-01
    z[3,4,1]  R873      -8.0911898612976074e-01
    z[3,4,1]  R874      -8.6442202329635620e-01
    z[3,4,1]  R875      -8.4205752611160278e-01
    z[3,4,1]  R876      -0.888372004032135
    z[3,4,1]  R877      -8.2396632432937622e-01
    z[3,4,1]  R878      -9.3639492988586426e-01
    z[3,4,1]  R879      -2.1814670413732529e-02
    z[3,4,1]  R880      7.0344597101211548e-02
    z[3,4,1]  R881      4.2119896411895752e-01
    z[3,4,1]  R882      2.9502192139625549e-01
    z[3,4,1]  R883      -0.842427670955658
    z[3,4,1]  R884      -8.9654362201690674e-01
    z[3,4,1]  R885      -8.8176757097244263e-01
    z[3,4,1]  R886      -0.814807116985321
    z[3,4,1]  R887      -7.9867547750473022e-01
    z[3,4,1]  R888      -7.8840601444244385e-01
    z[3,4,1]  R889      2.8742921352386475e-01
    z[3,4,1]  R890      2.4879592657089233e-01
    z[3,4,1]  R891      1.9900441169738770e-01
    z[3,4,1]  R892      -8.9389944076538086e-01
    z[3,4,1]  R893      -8.6115521192550659e-01
    z[3,4,1]  R894      -8.2163053750991821e-01
    z[3,4,1]  R895      -3.8869503140449524e-01
    z[3,4,1]  R896      -5.9901064634323120e-01
    z[3,4,1]  R897      -4.6669882535934448e-01
    z[3,4,1]  R898      -7.2935229539871216e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R806      -1
    z[3,4,2]  R807      1
    z[3,4,2]  R816      -8.3451753854751587e-01
    z[3,4,2]  R817      -5.3803157806396484e-01
    z[3,4,2]  R818      -6.9472914934158325e-01
    z[3,4,2]  R819      4.9458426237106323e-01
    z[3,4,2]  R820      2.0030254125595093e-01
    z[3,4,2]  R821      1.0673587024211884e-01
    z[3,4,2]  R822      -7.4285753071308136e-03
    z[3,4,2]  R823      4.1735753417015076e-01
    z[3,4,2]  R824      6.6532902419567108e-02
    z[3,4,2]  R825      0.0728011205792427
    z[3,4,2]  R826      2.9511865973472595e-01
    z[3,4,2]  R827      3.4283375740051270e-01
    z[3,4,2]  R828      -1.6079235076904297e-01
    z[3,4,2]  R829      -3.3767473697662354e-01
    z[3,4,2]  R830      -3.2790860533714294e-01
    z[3,4,2]  R831      -5.1845133304595947e-02
    z[3,4,2]  R832      -2.5522774457931519e-01
    z[3,4,2]  R833      -6.3111357390880585e-02
    z[3,4,2]  R834      -1.9181032478809357e-01
    z[3,4,2]  R835      -2.4847300350666046e-01
    z[3,4,2]  R836      1.2886928394436836e-02
    z[3,4,2]  R837      9.4998374581336975e-02
    z[3,4,2]  R838      1.7322087287902832e-01
    z[3,4,2]  R839      6.7431636154651642e-02
    z[3,4,2]  R840      1.5567451715469360e-01
    z[3,4,2]  R841      9.1799996793270111e-02
    z[3,4,2]  R842      -7.2012418508529663e-01
    z[3,4,2]  R843      -6.9533628225326538e-01
    z[3,4,2]  R844      -4.1551807522773743e-01
    z[3,4,2]  R845      -2.8524732589721680e-01
    z[3,4,2]  R846      -1.3848823308944702e-01
    z[3,4,2]  R847      -3.6783429980278015e-01
    z[3,4,2]  R848      -1.7657396197319031e-01
    z[3,4,2]  R849      8.4021437168121338e-01
    z[3,4,2]  R850      2.8355118632316589e-01
    z[3,4,2]  R851      4.9967566132545471e-01
    z[3,4,2]  R852      4.6472790837287903e-01
    z[3,4,2]  R853      8.4655404090881348e-01
    z[3,4,2]  R854      6.6695623099803925e-02
    z[3,4,2]  R855      -1.8805885314941406e-01
    z[3,4,2]  R856      -0.0760580450296402
    z[3,4,2]  R857      -1.6840463876724243e-01
    z[3,4,2]  R858      6.3653844594955444e-01
    z[3,4,2]  R859      9.5905712805688381e-04
    z[3,4,2]  R860      -2.5765869021415710e-01
    z[3,4,2]  R861      1.9793811440467834e-01
    z[3,4,2]  R862      8.2529969513416290e-02
    z[3,4,2]  R863      3.0190202593803406e-01
    z[3,4,2]  R864      3.1279298663139343e-01
    z[3,4,2]  R865      -0.0842321366071701
    z[3,4,2]  R866      -4.0897119045257568e-01
    z[3,4,2]  R867      -1.3384819030761719e-01
    z[3,4,2]  R868      -9.7464453428983688e-03
    z[3,4,2]  R869      2.5798752903938293e-02
    z[3,4,2]  R870      1.9758033752441406e-01
    z[3,4,2]  R871      -3.5061892122030258e-02
    z[3,4,2]  R872      5.4388329386711121e-02
    z[3,4,2]  R873      -1.8867659568786621e-01
    z[3,4,2]  R874      7.1011655032634735e-02
    z[3,4,2]  R875      2.8882932662963867e-01
    z[3,4,2]  R876      -2.2510716319084167e-01
    z[3,4,2]  R877      1.8280208110809326e-01
    z[3,4,2]  R878      1.8073084950447083e-01
    z[3,4,2]  R879      3.6547788977622986e-01
    z[3,4,2]  R880      7.0659118890762329e-01
    z[3,4,2]  R881      -8.2825394347310066e-03
    z[3,4,2]  R882      4.5111495256423950e-01
    z[3,4,2]  R883      8.0974452197551727e-02
    z[3,4,2]  R884      -2.9770871996879578e-01
    z[3,4,2]  R885      8.1429913640022278e-02
    z[3,4,2]  R886      9.3797542154788971e-02
    z[3,4,2]  R887      -4.2805038392543793e-02
    z[3,4,2]  R888      3.6200657486915588e-02
    z[3,4,2]  R889      4.8477512598037720e-01
    z[3,4,2]  R890      -7.6532892882823944e-02
    z[3,4,2]  R891      5.3832525014877319e-01
    z[3,4,2]  R892      3.4502517431974411e-02
    z[3,4,2]  R893      1.4597199857234955e-01
    z[3,4,2]  R894      -2.9339563846588135e-01
    z[3,4,2]  R895      -7.7600318193435669e-01
    z[3,4,2]  R896      -6.7623686790466309e-01
    z[3,4,2]  R897      -7.2706836462020874e-01
    z[3,4,2]  R898      -2.1004046499729156e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R808      -1
    z[3,4,3]  R809      1
    z[3,4,3]  R816      -2.2028996050357819e-01
    z[3,4,3]  R817      4.5112804509699345e-03
    z[3,4,3]  R818      -9.2413641512393951e-02
    z[3,4,3]  R819      1.6334348917007446e-01
    z[3,4,3]  R820      3.7057507038116455e-01
    z[3,4,3]  R821      2.2839917242527008e-01
    z[3,4,3]  R822      9.1190433502197266e-01
    z[3,4,3]  R823      3.6685898900032043e-01
    z[3,4,3]  R824      -5.8687359094619751e-01
    z[3,4,3]  R825      -2.3282991722226143e-02
    z[3,4,3]  R826      -8.3095425367355347e-01
    z[3,4,3]  R827      6.2877142429351807e-01
    z[3,4,3]  R828      -3.4194779396057129e-01
    z[3,4,3]  R829      -9.1844633221626282e-02
    z[3,4,3]  R830      -1.3687096536159515e-01
    z[3,4,3]  R831      -6.5661981701850891e-02
    z[3,4,3]  R832      3.3971334341913462e-03
    z[3,4,3]  R833      2.2036500275135040e-01
    z[3,4,3]  R834      -1.2398524582386017e-01
    z[3,4,3]  R835      -1.1111178249120712e-01
    z[3,4,3]  R836      3.7004286050796509e-01
    z[3,4,3]  R837      6.8615779280662537e-02
    z[3,4,3]  R838      3.1512069702148438e-01
    z[3,4,3]  R839      1.1516990512609482e-01
    z[3,4,3]  R840      3.2431280612945557e-01
    z[3,4,3]  R841      -2.0396200940012932e-02
    z[3,4,3]  R842      1.1635913699865341e-01
    z[3,4,3]  R843      8.8614434003829956e-02
    z[3,4,3]  R844      -4.9735743552446365e-02
    z[3,4,3]  R845      1.7283445596694946e-01
    z[3,4,3]  R846      3.2775089144706726e-01
    z[3,4,3]  R847      2.1331556141376495e-01
    z[3,4,3]  R848      4.2960166931152344e-01
    z[3,4,3]  R849      -3.4326744079589844e-01
    z[3,4,3]  R850      -7.0934981107711792e-01
    z[3,4,3]  R851      -3.1899097561836243e-01
    z[3,4,3]  R852      -6.1695091426372528e-02
    z[3,4,3]  R853      1.6761821508407593e-01
    z[3,4,3]  R854      1.9978480041027069e-01
    z[3,4,3]  R855      1.8895334005355835e-01
    z[3,4,3]  R856      -7.9344063997268677e-02
    z[3,4,3]  R857      5.0925098359584808e-02
    z[3,4,3]  R858      -1.7422821372747421e-02
    z[3,4,3]  R859      1.1696402914822102e-02
    z[3,4,3]  R860      -1.2717632949352264e-01
    z[3,4,3]  R861      -4.6137967146933079e-03
    z[3,4,3]  R862      -2.5225919485092163e-01
    z[3,4,3]  R863      5.6858994066715240e-02
    z[3,4,3]  R864      -2.6485204696655273e-01
    z[3,4,3]  R865      -5.9067141264677048e-02
    z[3,4,3]  R866      0.577458918094635
    z[3,4,3]  R867      2.4416531622409821e-01
    z[3,4,3]  R868      4.3209555745124817e-01
    z[3,4,3]  R869      -5.9953224658966064e-01
    z[3,4,3]  R870      -7.7092565596103668e-02
    z[3,4,3]  R871      -1.5031945705413818e-01
    z[3,4,3]  R872      -1.7512956261634827e-01
    z[3,4,3]  R873      3.2055267691612244e-01
    z[3,4,3]  R874      4.5226126909255981e-01
    z[3,4,3]  R875      2.7695652842521667e-01
    z[3,4,3]  R876      -4.8354491591453552e-02
    z[3,4,3]  R877      2.9866832494735718e-01
    z[3,4,3]  R878      1.8614947795867920e-01
    z[3,4,3]  R879      -4.7284394502639771e-01
    z[3,4,3]  R880      1.2677592039108276e-01
    z[3,4,3]  R881      -1.4143761992454529e-01
    z[3,4,3]  R882      -4.3483623862266541e-01
    z[3,4,3]  R883      2.1898582577705383e-01
    z[3,4,3]  R884      1.0630187392234802e-01
    z[3,4,3]  R885      2.1172007918357849e-01
    z[3,4,3]  R886      3.3912602066993713e-01
    z[3,4,3]  R887      5.2484345436096191e-01
    z[3,4,3]  R888      3.1216824054718018e-01
    z[3,4,3]  R889      3.7200883030891418e-01
    z[3,4,3]  R890      9.9150486290454865e-02
    z[3,4,3]  R891      1.4972022175788879e-01
    z[3,4,3]  R892      1.7892074584960938e-01
    z[3,4,3]  R893      1.5810623764991760e-01
    z[3,4,3]  R894      2.3697124421596527e-01
    z[3,4,3]  R895      -1.4373597502708435e-01
    z[3,4,3]  R896      -2.0813571289181709e-02
    z[3,4,3]  R897      1.5533900260925293e-01
    z[3,4,3]  R898      7.3797397315502167e-02
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R810      -1
    z[3,4,4]  R811      1
    z[3,4,4]  R816      -1.9618004560470581e-01
    z[3,4,4]  R817      -6.9654053449630737e-01
    z[3,4,4]  R818      1.1855020374059677e-01
    z[3,4,4]  R819      -7.7682077884674072e-02
    z[3,4,4]  R820      1.7610885202884674e-01
    z[3,4,4]  R821      -2.0498606562614441e-01
    z[3,4,4]  R822      4.0441237390041351e-02
    z[3,4,4]  R823      -4.0657272934913635e-01
    z[3,4,4]  R824      2.4739861488342285e-01
    z[3,4,4]  R825      3.6312833428382874e-01
    z[3,4,4]  R826      -2.2240689396858215e-01
    z[3,4,4]  R827      -1.9664157927036285e-01
    z[3,4,4]  R828      7.5480744242668152e-02
    z[3,4,4]  R829      2.3989711701869965e-01
    z[3,4,4]  R830      2.7705314755439758e-01
    z[3,4,4]  R831      2.3794779181480408e-01
    z[3,4,4]  R832      1.7909948527812958e-01
    z[3,4,4]  R833      -1.1399597674608231e-01
    z[3,4,4]  R834      -5.6032204627990723e-01
    z[3,4,4]  R835      -1.2320470996201038e-02
    z[3,4,4]  R836      2.4691355228424072e-01
    z[3,4,4]  R837      6.8836772441864014e-01
    z[3,4,4]  R838      8.6080354452133179e-01
    z[3,4,4]  R839      1.9727703928947449e-01
    z[3,4,4]  R840      -1.5441924333572388e-01
    z[3,4,4]  R841      -0.753320038318634
    z[3,4,4]  R842      1.1484218388795853e-01
    z[3,4,4]  R843      -5.3371128160506487e-04
    z[3,4,4]  R844      -7.0962566137313843e-01
    z[3,4,4]  R845      -2.0088282227516174e-01
    z[3,4,4]  R846      -3.2505291700363159e-01
    z[3,4,4]  R847      -6.0996998101472855e-02
    z[3,4,4]  R848      2.0736807957291603e-02
    z[3,4,4]  R849      3.2866573333740234e-01
    z[3,4,4]  R850      3.8796129822731018e-01
    z[3,4,4]  R851      1.7747510969638824e-01
    z[3,4,4]  R852      5.6861841678619385e-01
    z[3,4,4]  R853      1.2420850992202759e-01
    z[3,4,4]  R854      4.2864728718996048e-02
    z[3,4,4]  R855      -1.3347423076629639e-01
    z[3,4,4]  R856      4.1570693254470825e-01
    z[3,4,4]  R857      2.5823217630386353e-01
    z[3,4,4]  R858      -3.1981033086776733e-01
    z[3,4,4]  R859      2.4458529055118561e-01
    z[3,4,4]  R860      -0.0643736943602562
    z[3,4,4]  R861      -1.4105857908725739e-01
    z[3,4,4]  R862      2.8672186657786369e-02
    z[3,4,4]  R863      -3.5256387200206518e-03
    z[3,4,4]  R864      -9.0861216187477112e-02
    z[3,4,4]  R865      -1.7767642438411713e-01
    z[3,4,4]  R866      -3.8526263833045959e-01
    z[3,4,4]  R867      -2.2214479744434357e-02
    z[3,4,4]  R868      -1.0918529331684113e-01
    z[3,4,4]  R869      -3.1989240646362305e-01
    z[3,4,4]  R870      7.2579570114612579e-02
    z[3,4,4]  R871      2.8426715731620789e-01
    z[3,4,4]  R872      -3.4772685170173645e-01
    z[3,4,4]  R873      1.4275148510932922e-01
    z[3,4,4]  R874      -1.9971360266208649e-01
    z[3,4,4]  R875      1.9227384030818939e-01
    z[3,4,4]  R876      2.8355914354324341e-01
    z[3,4,4]  R877      3.6364585161209106e-01
    z[3,4,4]  R878      0.0623299777507782
    z[3,4,4]  R879      5.4575152695178986e-02
    z[3,4,4]  R880      -2.1897906064987183e-01
    z[3,4,4]  R881      -0.252566397190094
    z[3,4,4]  R882      -5.8801096677780151e-01
    z[3,4,4]  R883      -1.1910246312618256e-01
    z[3,4,4]  R884      1.2385033816099167e-01
    z[3,4,4]  R885      1.8290621042251587e-01
    z[3,4,4]  R886      3.0379590392112732e-01
    z[3,4,4]  R887      7.5964882969856262e-02
    z[3,4,4]  R888      2.0483568310737610e-01
    z[3,4,4]  R889      4.8887407779693604e-01
    z[3,4,4]  R890      4.4355848431587219e-01
    z[3,4,4]  R891      -5.6815481185913086e-01
    z[3,4,4]  R892      3.8978552818298340e-01
    z[3,4,4]  R893      2.4475511908531189e-01
    z[3,4,4]  R894      1.7736183479428291e-02
    z[3,4,4]  R895      -3.5304382443428040e-01
    z[3,4,4]  R896      -3.3749529719352722e-01
    z[3,4,4]  R897      -3.7403953075408936e-01
    z[3,4,4]  R898      -2.0202626287937164e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R812      -1
    z[3,4,5]  R813      1
    z[3,4,5]  R816      -2.8327253460884094e-01
    z[3,4,5]  R817      -5.5435862392187119e-02
    z[3,4,5]  R818      -4.5814013481140137e-01
    z[3,4,5]  R819      -0.571395218372345
    z[3,4,5]  R820      -1.3369980454444885e-01
    z[3,4,5]  R821      -3.6823821067810059e-01
    z[3,4,5]  R822      -0.0757163017988205
    z[3,4,5]  R823      2.4088194966316223e-01
    z[3,4,5]  R824      8.3779737353324890e-02
    z[3,4,5]  R825      3.4886193275451660e-01
    z[3,4,5]  R826      -1.5392936766147614e-02
    z[3,4,5]  R827      -5.1585435867309570e-01
    z[3,4,5]  R828      -9.1138131916522980e-02
    z[3,4,5]  R829      6.3751161098480225e-01
    z[3,4,5]  R830      6.6132062673568726e-01
    z[3,4,5]  R831      4.8494762182235718e-01
    z[3,4,5]  R832      6.5178465843200684e-01
    z[3,4,5]  R833      -8.6875444650650024e-01
    z[3,4,5]  R834      1.5387354791164398e-01
    z[3,4,5]  R835      1.9965665042400360e-01
    z[3,4,5]  R836      8.0717802047729492e-02
    z[3,4,5]  R837      2.8737673535943031e-02
    z[3,4,5]  R838      -7.9404406249523163e-02
    z[3,4,5]  R839      -1.8966224789619446e-01
    z[3,4,5]  R840      -8.7802886962890625e-02
    z[3,4,5]  R841      -0.067637138068676
    z[3,4,5]  R842      -4.5988604426383972e-02
    z[3,4,5]  R843      -4.5047560706734657e-03
    z[3,4,5]  R844      -3.2689280807971954e-02
    z[3,4,5]  R845      -3.1402119994163513e-01
    z[3,4,5]  R846      -2.1722888946533203e-01
    z[3,4,5]  R847      1.6671134158968925e-02
    z[3,4,5]  R848      -2.8326642513275146e-01
    z[3,4,5]  R849      1.5485012531280518e-01
    z[3,4,5]  R850      3.1400460004806519e-01
    z[3,4,5]  R851      1.8866080045700073e-01
    z[3,4,5]  R852      1.1222336441278458e-01
    z[3,4,5]  R853      -4.7523528337478638e-01
    z[3,4,5]  R854      -4.2120289802551270e-01
    z[3,4,5]  R855      3.0312919989228249e-02
    z[3,4,5]  R856      -1.0461964458227158e-01
    z[3,4,5]  R857      -4.2417088150978088e-01
    z[3,4,5]  R858      -6.0311728715896606e-01
    z[3,4,5]  R859      -3.6094522476196289e-01
    z[3,4,5]  R860      -1.3168926537036896e-01
    z[3,4,5]  R861      6.9820769131183624e-02
    z[3,4,5]  R862      1.6734541952610016e-01
    z[3,4,5]  R863      -0.349232941865921
    z[3,4,5]  R864      -1.2980429828166962e-01
    z[3,4,5]  R865      -1.8330083787441254e-01
    z[3,4,5]  R866      -1.6589336097240448e-01
    z[3,4,5]  R867      6.6312126815319061e-02
    z[3,4,5]  R868      -3.8353651762008667e-02
    z[3,4,5]  R869      3.4753882884979248e-01
    z[3,4,5]  R870      -1.3029731810092926e-01
    z[3,4,5]  R871      5.8049920946359634e-02
    z[3,4,5]  R872      0.0403253547847271
    z[3,4,5]  R873      -2.4391652643680573e-01
    z[3,4,5]  R874      -2.3386912420392036e-02
    z[3,4,5]  R875      1.4532741904258728e-01
    z[3,4,5]  R876      2.7338016033172607e-01
    z[3,4,5]  R877      3.8393858820199966e-02
    z[3,4,5]  R878      1.7576953768730164e-01
    z[3,4,5]  R879      7.1508079767227173e-02
    z[3,4,5]  R880      -3.5299065709114075e-01
    z[3,4,5]  R881      8.2775211334228516e-01
    z[3,4,5]  R882      1.0440965741872787e-01
    z[3,4,5]  R883      -4.4865331053733826e-01
    z[3,4,5]  R884      1.5884213149547577e-01
    z[3,4,5]  R885      4.0458705276250839e-02
    z[3,4,5]  R886      0.0845780149102211
    z[3,4,5]  R887      -4.5434813946485519e-02
    z[3,4,5]  R888      -1.3693729043006897e-01
    z[3,4,5]  R889      0.0855298712849617
    z[3,4,5]  R890      6.1912846565246582e-01
    z[3,4,5]  R891      -1.4781183004379272e-01
    z[3,4,5]  R892      1.0292392224073410e-01
    z[3,4,5]  R893      2.4152073264122009e-01
    z[3,4,5]  R894      2.0462978631258011e-02
    z[3,4,5]  R895      2.7034100890159607e-01
    z[3,4,5]  R896      2.2451931238174438e-01
    z[3,4,5]  R897      2.0600913465023041e-01
    z[3,4,5]  R898      -2.2528212517499924e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R814      -1
    z[3,4,6]  R815      1
    z[3,4,6]  R816      5.8912258595228195e-02
    z[3,4,6]  R817      -2.2711883485317230e-01
    z[3,4,6]  R818      -4.3068295717239380e-01
    z[3,4,6]  R819      0.339596688747406
    z[3,4,6]  R820      -1.0362610220909119e-02
    z[3,4,6]  R821      -3.0332520604133606e-01
    z[3,4,6]  R822      -1.9626735150814056e-01
    z[3,4,6]  R823      2.3485115170478821e-01
    z[3,4,6]  R824      1.9183342158794403e-01
    z[3,4,6]  R825      1.0617990791797638e-01
    z[3,4,6]  R826      0.380306214094162
    z[3,4,6]  R827      3.0408294871449471e-02
    z[3,4,6]  R828      1.1247279122471809e-02
    z[3,4,6]  R829      4.0876977145671844e-03
    z[3,4,6]  R830      -0.0807369276881218
    z[3,4,6]  R831      0.0790676400065422
    z[3,4,6]  R832      -0.0378536619246006
    z[3,4,6]  R833      -1.9489973783493042e-01
    z[3,4,6]  R834      -5.0770029425621033e-02
    z[3,4,6]  R835      -3.9156213402748108e-02
    z[3,4,6]  R836      -3.5827852785587311e-02
    z[3,4,6]  R837      7.4549503624439240e-02
    z[3,4,6]  R838      -5.3753387182950974e-02
    z[3,4,6]  R839      3.5725861787796021e-01
    z[3,4,6]  R840      -1.3364584743976593e-01
    z[3,4,6]  R841      3.8772195577621460e-01
    z[3,4,6]  R842      -4.8938225954771042e-02
    z[3,4,6]  R843      -4.5889008045196533e-01
    z[3,4,6]  R844      6.0432165861129761e-02
    z[3,4,6]  R845      -1.5530244447290897e-02
    z[3,4,6]  R846      4.6107780188322067e-02
    z[3,4,6]  R847      -2.0385617017745972e-01
    z[3,4,6]  R848      1.7365282773971558e-01
    z[3,4,6]  R849      -6.3380233943462372e-02
    z[3,4,6]  R850      -1.2486694753170013e-01
    z[3,4,6]  R851      -7.1028012037277222e-01
    z[3,4,6]  R852      -5.5898189544677734e-01
    z[3,4,6]  R853      -8.3008259534835815e-02
    z[3,4,6]  R854      -2.5063201785087585e-01
    z[3,4,6]  R855      -0.0890025720000267
    z[3,4,6]  R856      -1.6875582933425903e-01
    z[3,4,6]  R857      1.7634356021881104e-01
    z[3,4,6]  R858      1.9689792394638062e-01
    z[3,4,6]  R859      -1.5362252295017242e-01
    z[3,4,6]  R860      3.7762913852930069e-02
    z[3,4,6]  R861      -1.8423174321651459e-01
    z[3,4,6]  R862      3.1699728965759277e-01
    z[3,4,6]  R863      -0.0688420757651329
    z[3,4,6]  R864      2.5477710366249084e-01
    z[3,4,6]  R865      -5.1449424028396606e-01
    z[3,4,6]  R866      3.2861515879631042e-02
    z[3,4,6]  R867      -4.3765522539615631e-02
    z[3,4,6]  R868      -2.4215854704380035e-01
    z[3,4,6]  R869      2.3911017179489136e-01
    z[3,4,6]  R870      5.1108323037624359e-02
    z[3,4,6]  R871      -1.1741942912340164e-01
    z[3,4,6]  R872      -1.5337510406970978e-01
    z[3,4,6]  R873      -3.4810605645179749e-01
    z[3,4,6]  R874      1.2059990316629410e-02
    z[3,4,6]  R875      -1.7385342717170715e-01
    z[3,4,6]  R876      -1.3387300074100494e-02
    z[3,4,6]  R877      -2.3169608414173126e-01
    z[3,4,6]  R878      -1.4494709670543671e-01
    z[3,4,6]  R879      1.4631895720958710e-01
    z[3,4,6]  R880      3.5688430070877075e-01
    z[3,4,6]  R881      1.8671859055757523e-02
    z[3,4,6]  R882      -1.4046387374401093e-01
    z[3,4,6]  R883      -5.2591826766729355e-02
    z[3,4,6]  R884      -5.9016954153776169e-02
    z[3,4,6]  R885      -1.4667728543281555e-01
    z[3,4,6]  R886      7.6553061604499817e-02
    z[3,4,6]  R887      -2.6487118005752563e-01
    z[3,4,6]  R888      4.2527332901954651e-01
    z[3,4,6]  R889      -4.4908666610717773e-01
    z[3,4,6]  R890      3.6136223934590816e-03
    z[3,4,6]  R891      -4.3110698461532593e-01
    z[3,4,6]  R892      7.2128519415855408e-02
    z[3,4,6]  R893      -1.2996993958950043e-01
    z[3,4,6]  R894      4.2649745941162109e-01
    z[3,4,6]  R895      -7.5684264302253723e-02
    z[3,4,6]  R896      1.0512106865644455e-01
    z[3,4,6]  R897      -2.1033169329166412e-01
    z[3,4,6]  R898      0.22533018887043
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R899      -1
    z[4,3,0]  R900      1
    z[4,3,0]  R913      1.8276479095220566e-02
    z[4,3,0]  R914      1.1998645216226578e-01
    z[4,3,0]  R915      6.4301635138690472e-03
    z[4,3,0]  R916      3.2188287377357483e-01
    z[4,3,0]  R917      2.7721645310521126e-02
    z[4,3,0]  R918      5.9904661029577255e-02
    z[4,3,0]  R919      0.858936071395874
    z[4,3,0]  R920      8.3661407232284546e-01
    z[4,3,0]  R921      0.852433979511261
    z[4,3,0]  R922      8.1905382871627808e-01
    z[4,3,0]  R923      -1.7209856212139130e-01
    z[4,3,0]  R924      -1.0541781038045883e-01
    z[4,3,0]  R925      -2.4894516170024872e-01
    z[4,3,0]  R926      -3.6012226343154907e-01
    z[4,3,0]  R927      5.3793575614690781e-02
    z[4,3,0]  R928      -7.2886824607849121e-01
    z[4,3,0]  R929      3.1899258494377136e-01
    z[4,3,0]  R930      -2.4710580706596375e-02
    z[4,3,0]  R931      5.6930180639028549e-02
    z[4,3,0]  R932      2.9730057716369629e-01
    z[4,3,0]  R933      -7.6461881399154663e-01
    z[4,3,0]  R934      3.1305238604545593e-02
    z[4,3,0]  R935      -2.4371033906936646e-01
    z[4,3,0]  R936      -6.6487453877925873e-02
    z[4,3,0]  R937      1.7442536354064941e-01
    z[4,3,0]  R938      -2.1793624758720398e-01
    z[4,3,0]  R939      1.1814450845122337e-02
    z[4,3,0]  R940      -1.3853733241558075e-01
    z[4,3,0]  R941      -2.6652544736862183e-01
    z[4,3,0]  R942      -2.8162550926208496e-01
    z[4,3,0]  R943      -5.9845107793807983e-01
    z[4,3,0]  R944      2.3119193315505981e-01
    z[4,3,0]  R945      1.5551097691059113e-01
    z[4,3,0]  R946      2.6353845000267029e-01
    z[4,3,0]  R947      7.6957635581493378e-02
    z[4,3,0]  R948      -5.1124148070812225e-02
    z[4,3,0]  R949      2.0614919066429138e-01
    z[4,3,0]  R950      -4.9619201570749283e-02
    z[4,3,0]  R951      -1.0518789291381836e-01
    z[4,3,0]  R952      -7.7299750410020351e-03
    z[4,3,0]  R953      -7.8285849094390869e-01
    z[4,3,0]  R954      -4.2401376366615295e-01
    z[4,3,0]  R955      -2.3066484928131104e-01
    z[4,3,0]  R956      -3.7945550680160522e-01
    z[4,3,0]  R957      -1.3252480328083038e-01
    z[4,3,0]  R958      -2.2853079438209534e-01
    z[4,3,0]  R959      -3.3826592564582825e-01
    z[4,3,0]  R960      3.2707676291465759e-01
    z[4,3,0]  R961      -8.2660518586635590e-02
    z[4,3,0]  R962      -1.9516560435295105e-01
    z[4,3,0]  R963      -3.0983048677444458e-01
    z[4,3,0]  R964      -5.8509427309036255e-01
    z[4,3,0]  R965      -3.4305313229560852e-01
    z[4,3,0]  R966      3.4879993181675673e-03
    z[4,3,0]  R967      2.7744683623313904e-01
    z[4,3,0]  R968      -7.3124817572534084e-03
    z[4,3,0]  R969      -1.5040916204452515e-01
    z[4,3,0]  R970      -8.9968644082546234e-02
    z[4,3,0]  R971      5.3375765681266785e-02
    z[4,3,0]  R972      -5.7130229473114014e-01
    z[4,3,0]  R973      1.9507057964801788e-01
    z[4,3,0]  R974      3.6697140336036682e-01
    z[4,3,0]  R975      2.8205236792564392e-01
    z[4,3,0]  R976      4.2801365256309509e-01
    z[4,3,0]  R977      -6.6984174773097038e-03
    z[4,3,0]  R978      -1.2007335573434830e-01
    z[4,3,0]  R979      1.9108036160469055e-01
    z[4,3,0]  R980      -1.9672195613384247e-01
    z[4,3,0]  R981      -4.0340952575206757e-02
    z[4,3,0]  R982      -2.1231804788112640e-01
    z[4,3,0]  R983      -1.6643962264060974e-01
    z[4,3,0]  R984      3.2462522387504578e-01
    z[4,3,0]  R985      2.2524490952491760e-02
    z[4,3,0]  R986      -7.1754038333892822e-02
    z[4,3,0]  R987      -6.2028553336858749e-02
    z[4,3,0]  R988      6.4146465063095093e-01
    z[4,3,0]  R989      4.4850829243659973e-01
    z[4,3,0]  R990      6.4898796379566193e-02
    z[4,3,0]  R991      -7.6559305191040039e-01
    z[4,3,0]  R992      2.0446164906024933e-01
    z[4,3,0]  R993      7.6459348201751709e-01
    z[4,3,0]  R994      5.7732760906219482e-01
    z[4,3,0]  R995      2.6761946082115173e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R901      -1
    z[4,3,1]  R902      1
    z[4,3,1]  R913      8.8279730081558228e-01
    z[4,3,1]  R914      8.9820599555969238e-01
    z[4,3,1]  R915      5.1838332414627075e-01
    z[4,3,1]  R916      5.8870565891265869e-01
    z[4,3,1]  R917      5.4523938894271851e-01
    z[4,3,1]  R918      5.5945807695388794e-01
    z[4,3,1]  R919      -1.0856576263904572e-01
    z[4,3,1]  R920      1.3602754473686218e-01
    z[4,3,1]  R921      -2.1678301692008972e-01
    z[4,3,1]  R922      5.0889525562524796e-02
    z[4,3,1]  R923      1.0282338410615921e-01
    z[4,3,1]  R924      3.7497210502624512e-01
    z[4,3,1]  R925      0.122503861784935
    z[4,3,1]  R926      4.6388339251279831e-02
    z[4,3,1]  R927      6.4730048179626465e-02
    z[4,3,1]  R928      4.2699292302131653e-01
    z[4,3,1]  R929      -8.9471697807312012e-01
    z[4,3,1]  R930      -8.8038235902786255e-01
    z[4,3,1]  R931      -8.2952016592025757e-01
    z[4,3,1]  R932      3.6464259028434753e-02
    z[4,3,1]  R933      4.4890657067298889e-01
    z[4,3,1]  R934      -9.4527572393417358e-01
    z[4,3,1]  R935      -9.1798186302185059e-01
    z[4,3,1]  R936      -8.9208728075027466e-01
    z[4,3,1]  R937      -8.6514890193939209e-01
    z[4,3,1]  R938      -8.3336752653121948e-01
    z[4,3,1]  R939      -8.1203687191009521e-01
    z[4,3,1]  R940      -5.5051195621490479e-01
    z[4,3,1]  R941      -9.1903531551361084e-01
    z[4,3,1]  R942      -8.1354314088821411e-01
    z[4,3,1]  R943      -3.8258321583271027e-02
    z[4,3,1]  R944      -9.3632888793945312e-01
    z[4,3,1]  R945      -9.2413526773452759e-01
    z[4,3,1]  R946      -8.6651885509490967e-01
    z[4,3,1]  R947      -8.0911898612976074e-01
    z[4,3,1]  R948      -8.6442202329635620e-01
    z[4,3,1]  R949      -8.4205752611160278e-01
    z[4,3,1]  R950      -0.888372004032135
    z[4,3,1]  R951      -8.2396632432937622e-01
    z[4,3,1]  R952      -9.3639492988586426e-01
    z[4,3,1]  R953      -2.1814670413732529e-02
    z[4,3,1]  R954      7.0344597101211548e-02
    z[4,3,1]  R955      4.2119896411895752e-01
    z[4,3,1]  R956      2.9502192139625549e-01
    z[4,3,1]  R957      -0.842427670955658
    z[4,3,1]  R958      -8.9654362201690674e-01
    z[4,3,1]  R959      -8.8176757097244263e-01
    z[4,3,1]  R960      -0.814807116985321
    z[4,3,1]  R961      -7.9867547750473022e-01
    z[4,3,1]  R962      -7.8840601444244385e-01
    z[4,3,1]  R963      2.8742921352386475e-01
    z[4,3,1]  R964      2.4879592657089233e-01
    z[4,3,1]  R965      1.9900441169738770e-01
    z[4,3,1]  R966      -8.9389944076538086e-01
    z[4,3,1]  R967      -8.6115521192550659e-01
    z[4,3,1]  R968      -8.2163053750991821e-01
    z[4,3,1]  R969      -3.8869503140449524e-01
    z[4,3,1]  R970      -5.9901064634323120e-01
    z[4,3,1]  R971      -4.6669882535934448e-01
    z[4,3,1]  R972      -7.2935229539871216e-01
    z[4,3,1]  R973      -3.0789560079574585e-01
    z[4,3,1]  R974      -1.8975988030433655e-01
    z[4,3,1]  R975      -1.4079466462135315e-01
    z[4,3,1]  R976      -3.1250080466270447e-01
    z[4,3,1]  R977      8.7949460744857788e-01
    z[4,3,1]  R978      8.0771207809448242e-01
    z[4,3,1]  R979      -2.9321369528770447e-01
    z[4,3,1]  R980      6.1159390211105347e-01
    z[4,3,1]  R981      7.3790258169174194e-01
    z[4,3,1]  R982      -8.2718676328659058e-01
    z[4,3,1]  R983      -1.9574034959077835e-02
    z[4,3,1]  R984      2.7573844790458679e-01
    z[4,3,1]  R985      9.1792166233062744e-01
    z[4,3,1]  R986      0.639064371585846
    z[4,3,1]  R987      5.9099310636520386e-01
    z[4,3,1]  R988      5.3242707252502441e-01
    z[4,3,1]  R989      5.2474248409271240e-01
    z[4,3,1]  R990      -3.7084934115409851e-01
    z[4,3,1]  R991      -1.4658871293067932e-01
    z[4,3,1]  R992      9.1791230440139771e-01
    z[4,3,1]  R993      4.5774844288825989e-01
    z[4,3,1]  R994      4.1560354828834534e-01
    z[4,3,1]  R995      2.2112429141998291e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R903      -1
    z[4,3,2]  R904      1
    z[4,3,2]  R913      6.7431636154651642e-02
    z[4,3,2]  R914      1.5567451715469360e-01
    z[4,3,2]  R915      9.1799996793270111e-02
    z[4,3,2]  R916      -7.2012418508529663e-01
    z[4,3,2]  R917      -6.9533628225326538e-01
    z[4,3,2]  R918      -4.1551807522773743e-01
    z[4,3,2]  R919      -2.8524732589721680e-01
    z[4,3,2]  R920      -1.3848823308944702e-01
    z[4,3,2]  R921      -3.6783429980278015e-01
    z[4,3,2]  R922      -1.7657396197319031e-01
    z[4,3,2]  R923      8.4021437168121338e-01
    z[4,3,2]  R924      2.8355118632316589e-01
    z[4,3,2]  R925      4.9967566132545471e-01
    z[4,3,2]  R926      4.6472790837287903e-01
    z[4,3,2]  R927      8.4655404090881348e-01
    z[4,3,2]  R928      6.6695623099803925e-02
    z[4,3,2]  R929      -1.8805885314941406e-01
    z[4,3,2]  R930      -0.0760580450296402
    z[4,3,2]  R931      -1.6840463876724243e-01
    z[4,3,2]  R932      6.3653844594955444e-01
    z[4,3,2]  R933      9.5905712805688381e-04
    z[4,3,2]  R934      -2.5765869021415710e-01
    z[4,3,2]  R935      1.9793811440467834e-01
    z[4,3,2]  R936      8.2529969513416290e-02
    z[4,3,2]  R937      3.0190202593803406e-01
    z[4,3,2]  R938      3.1279298663139343e-01
    z[4,3,2]  R939      -0.0842321366071701
    z[4,3,2]  R940      -4.0897119045257568e-01
    z[4,3,2]  R941      -1.3384819030761719e-01
    z[4,3,2]  R942      -9.7464453428983688e-03
    z[4,3,2]  R943      2.5798752903938293e-02
    z[4,3,2]  R944      1.9758033752441406e-01
    z[4,3,2]  R945      -3.5061892122030258e-02
    z[4,3,2]  R946      5.4388329386711121e-02
    z[4,3,2]  R947      -1.8867659568786621e-01
    z[4,3,2]  R948      7.1011655032634735e-02
    z[4,3,2]  R949      2.8882932662963867e-01
    z[4,3,2]  R950      -2.2510716319084167e-01
    z[4,3,2]  R951      1.8280208110809326e-01
    z[4,3,2]  R952      1.8073084950447083e-01
    z[4,3,2]  R953      3.6547788977622986e-01
    z[4,3,2]  R954      7.0659118890762329e-01
    z[4,3,2]  R955      -8.2825394347310066e-03
    z[4,3,2]  R956      4.5111495256423950e-01
    z[4,3,2]  R957      8.0974452197551727e-02
    z[4,3,2]  R958      -2.9770871996879578e-01
    z[4,3,2]  R959      8.1429913640022278e-02
    z[4,3,2]  R960      9.3797542154788971e-02
    z[4,3,2]  R961      -4.2805038392543793e-02
    z[4,3,2]  R962      3.6200657486915588e-02
    z[4,3,2]  R963      4.8477512598037720e-01
    z[4,3,2]  R964      -7.6532892882823944e-02
    z[4,3,2]  R965      5.3832525014877319e-01
    z[4,3,2]  R966      3.4502517431974411e-02
    z[4,3,2]  R967      1.4597199857234955e-01
    z[4,3,2]  R968      -2.9339563846588135e-01
    z[4,3,2]  R969      -7.7600318193435669e-01
    z[4,3,2]  R970      -6.7623686790466309e-01
    z[4,3,2]  R971      -7.2706836462020874e-01
    z[4,3,2]  R972      -2.1004046499729156e-01
    z[4,3,2]  R973      -8.3451753854751587e-01
    z[4,3,2]  R974      -5.3803157806396484e-01
    z[4,3,2]  R975      -6.9472914934158325e-01
    z[4,3,2]  R976      4.9458426237106323e-01
    z[4,3,2]  R977      2.0030254125595093e-01
    z[4,3,2]  R978      1.0673587024211884e-01
    z[4,3,2]  R979      -7.4285753071308136e-03
    z[4,3,2]  R980      4.1735753417015076e-01
    z[4,3,2]  R981      6.6532902419567108e-02
    z[4,3,2]  R982      0.0728011205792427
    z[4,3,2]  R983      2.9511865973472595e-01
    z[4,3,2]  R984      3.4283375740051270e-01
    z[4,3,2]  R985      -1.6079235076904297e-01
    z[4,3,2]  R986      -3.3767473697662354e-01
    z[4,3,2]  R987      -3.2790860533714294e-01
    z[4,3,2]  R988      -5.1845133304595947e-02
    z[4,3,2]  R989      -2.5522774457931519e-01
    z[4,3,2]  R990      -6.3111357390880585e-02
    z[4,3,2]  R991      -1.9181032478809357e-01
    z[4,3,2]  R992      -2.4847300350666046e-01
    z[4,3,2]  R993      1.2886928394436836e-02
    z[4,3,2]  R994      9.4998374581336975e-02
    z[4,3,2]  R995      1.7322087287902832e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R905      -1
    z[4,3,3]  R906      1
    z[4,3,3]  R913      1.1516990512609482e-01
    z[4,3,3]  R914      3.2431280612945557e-01
    z[4,3,3]  R915      -2.0396200940012932e-02
    z[4,3,3]  R916      1.1635913699865341e-01
    z[4,3,3]  R917      8.8614434003829956e-02
    z[4,3,3]  R918      -4.9735743552446365e-02
    z[4,3,3]  R919      1.7283445596694946e-01
    z[4,3,3]  R920      3.2775089144706726e-01
    z[4,3,3]  R921      2.1331556141376495e-01
    z[4,3,3]  R922      4.2960166931152344e-01
    z[4,3,3]  R923      -3.4326744079589844e-01
    z[4,3,3]  R924      -7.0934981107711792e-01
    z[4,3,3]  R925      -3.1899097561836243e-01
    z[4,3,3]  R926      -6.1695091426372528e-02
    z[4,3,3]  R927      1.6761821508407593e-01
    z[4,3,3]  R928      1.9978480041027069e-01
    z[4,3,3]  R929      1.8895334005355835e-01
    z[4,3,3]  R930      -7.9344063997268677e-02
    z[4,3,3]  R931      5.0925098359584808e-02
    z[4,3,3]  R932      -1.7422821372747421e-02
    z[4,3,3]  R933      1.1696402914822102e-02
    z[4,3,3]  R934      -1.2717632949352264e-01
    z[4,3,3]  R935      -4.6137967146933079e-03
    z[4,3,3]  R936      -2.5225919485092163e-01
    z[4,3,3]  R937      5.6858994066715240e-02
    z[4,3,3]  R938      -2.6485204696655273e-01
    z[4,3,3]  R939      -5.9067141264677048e-02
    z[4,3,3]  R940      0.577458918094635
    z[4,3,3]  R941      2.4416531622409821e-01
    z[4,3,3]  R942      4.3209555745124817e-01
    z[4,3,3]  R943      -5.9953224658966064e-01
    z[4,3,3]  R944      -7.7092565596103668e-02
    z[4,3,3]  R945      -1.5031945705413818e-01
    z[4,3,3]  R946      -1.7512956261634827e-01
    z[4,3,3]  R947      3.2055267691612244e-01
    z[4,3,3]  R948      4.5226126909255981e-01
    z[4,3,3]  R949      2.7695652842521667e-01
    z[4,3,3]  R950      -4.8354491591453552e-02
    z[4,3,3]  R951      2.9866832494735718e-01
    z[4,3,3]  R952      1.8614947795867920e-01
    z[4,3,3]  R953      -4.7284394502639771e-01
    z[4,3,3]  R954      1.2677592039108276e-01
    z[4,3,3]  R955      -1.4143761992454529e-01
    z[4,3,3]  R956      -4.3483623862266541e-01
    z[4,3,3]  R957      2.1898582577705383e-01
    z[4,3,3]  R958      1.0630187392234802e-01
    z[4,3,3]  R959      2.1172007918357849e-01
    z[4,3,3]  R960      3.3912602066993713e-01
    z[4,3,3]  R961      5.2484345436096191e-01
    z[4,3,3]  R962      3.1216824054718018e-01
    z[4,3,3]  R963      3.7200883030891418e-01
    z[4,3,3]  R964      9.9150486290454865e-02
    z[4,3,3]  R965      1.4972022175788879e-01
    z[4,3,3]  R966      1.7892074584960938e-01
    z[4,3,3]  R967      1.5810623764991760e-01
    z[4,3,3]  R968      2.3697124421596527e-01
    z[4,3,3]  R969      -1.4373597502708435e-01
    z[4,3,3]  R970      -2.0813571289181709e-02
    z[4,3,3]  R971      1.5533900260925293e-01
    z[4,3,3]  R972      7.3797397315502167e-02
    z[4,3,3]  R973      -2.2028996050357819e-01
    z[4,3,3]  R974      4.5112804509699345e-03
    z[4,3,3]  R975      -9.2413641512393951e-02
    z[4,3,3]  R976      1.6334348917007446e-01
    z[4,3,3]  R977      3.7057507038116455e-01
    z[4,3,3]  R978      2.2839917242527008e-01
    z[4,3,3]  R979      9.1190433502197266e-01
    z[4,3,3]  R980      3.6685898900032043e-01
    z[4,3,3]  R981      -5.8687359094619751e-01
    z[4,3,3]  R982      -2.3282991722226143e-02
    z[4,3,3]  R983      -8.3095425367355347e-01
    z[4,3,3]  R984      6.2877142429351807e-01
    z[4,3,3]  R985      -3.4194779396057129e-01
    z[4,3,3]  R986      -9.1844633221626282e-02
    z[4,3,3]  R987      -1.3687096536159515e-01
    z[4,3,3]  R988      -6.5661981701850891e-02
    z[4,3,3]  R989      3.3971334341913462e-03
    z[4,3,3]  R990      2.2036500275135040e-01
    z[4,3,3]  R991      -1.2398524582386017e-01
    z[4,3,3]  R992      -1.1111178249120712e-01
    z[4,3,3]  R993      3.7004286050796509e-01
    z[4,3,3]  R994      6.8615779280662537e-02
    z[4,3,3]  R995      3.1512069702148438e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R907      -1
    z[4,3,4]  R908      1
    z[4,3,4]  R913      1.9727703928947449e-01
    z[4,3,4]  R914      -1.5441924333572388e-01
    z[4,3,4]  R915      -0.753320038318634
    z[4,3,4]  R916      1.1484218388795853e-01
    z[4,3,4]  R917      -5.3371128160506487e-04
    z[4,3,4]  R918      -7.0962566137313843e-01
    z[4,3,4]  R919      -2.0088282227516174e-01
    z[4,3,4]  R920      -3.2505291700363159e-01
    z[4,3,4]  R921      -6.0996998101472855e-02
    z[4,3,4]  R922      2.0736807957291603e-02
    z[4,3,4]  R923      3.2866573333740234e-01
    z[4,3,4]  R924      3.8796129822731018e-01
    z[4,3,4]  R925      1.7747510969638824e-01
    z[4,3,4]  R926      5.6861841678619385e-01
    z[4,3,4]  R927      1.2420850992202759e-01
    z[4,3,4]  R928      4.2864728718996048e-02
    z[4,3,4]  R929      -1.3347423076629639e-01
    z[4,3,4]  R930      4.1570693254470825e-01
    z[4,3,4]  R931      2.5823217630386353e-01
    z[4,3,4]  R932      -3.1981033086776733e-01
    z[4,3,4]  R933      2.4458529055118561e-01
    z[4,3,4]  R934      -0.0643736943602562
    z[4,3,4]  R935      -1.4105857908725739e-01
    z[4,3,4]  R936      2.8672186657786369e-02
    z[4,3,4]  R937      -3.5256387200206518e-03
    z[4,3,4]  R938      -9.0861216187477112e-02
    z[4,3,4]  R939      -1.7767642438411713e-01
    z[4,3,4]  R940      -3.8526263833045959e-01
    z[4,3,4]  R941      -2.2214479744434357e-02
    z[4,3,4]  R942      -1.0918529331684113e-01
    z[4,3,4]  R943      -3.1989240646362305e-01
    z[4,3,4]  R944      7.2579570114612579e-02
    z[4,3,4]  R945      2.8426715731620789e-01
    z[4,3,4]  R946      -3.4772685170173645e-01
    z[4,3,4]  R947      1.4275148510932922e-01
    z[4,3,4]  R948      -1.9971360266208649e-01
    z[4,3,4]  R949      1.9227384030818939e-01
    z[4,3,4]  R950      2.8355914354324341e-01
    z[4,3,4]  R951      3.6364585161209106e-01
    z[4,3,4]  R952      0.0623299777507782
    z[4,3,4]  R953      5.4575152695178986e-02
    z[4,3,4]  R954      -2.1897906064987183e-01
    z[4,3,4]  R955      -0.252566397190094
    z[4,3,4]  R956      -5.8801096677780151e-01
    z[4,3,4]  R957      -1.1910246312618256e-01
    z[4,3,4]  R958      1.2385033816099167e-01
    z[4,3,4]  R959      1.8290621042251587e-01
    z[4,3,4]  R960      3.0379590392112732e-01
    z[4,3,4]  R961      7.5964882969856262e-02
    z[4,3,4]  R962      2.0483568310737610e-01
    z[4,3,4]  R963      4.8887407779693604e-01
    z[4,3,4]  R964      4.4355848431587219e-01
    z[4,3,4]  R965      -5.6815481185913086e-01
    z[4,3,4]  R966      3.8978552818298340e-01
    z[4,3,4]  R967      2.4475511908531189e-01
    z[4,3,4]  R968      1.7736183479428291e-02
    z[4,3,4]  R969      -3.5304382443428040e-01
    z[4,3,4]  R970      -3.3749529719352722e-01
    z[4,3,4]  R971      -3.7403953075408936e-01
    z[4,3,4]  R972      -2.0202626287937164e-01
    z[4,3,4]  R973      -1.9618004560470581e-01
    z[4,3,4]  R974      -6.9654053449630737e-01
    z[4,3,4]  R975      1.1855020374059677e-01
    z[4,3,4]  R976      -7.7682077884674072e-02
    z[4,3,4]  R977      1.7610885202884674e-01
    z[4,3,4]  R978      -2.0498606562614441e-01
    z[4,3,4]  R979      4.0441237390041351e-02
    z[4,3,4]  R980      -4.0657272934913635e-01
    z[4,3,4]  R981      2.4739861488342285e-01
    z[4,3,4]  R982      3.6312833428382874e-01
    z[4,3,4]  R983      -2.2240689396858215e-01
    z[4,3,4]  R984      -1.9664157927036285e-01
    z[4,3,4]  R985      7.5480744242668152e-02
    z[4,3,4]  R986      2.3989711701869965e-01
    z[4,3,4]  R987      2.7705314755439758e-01
    z[4,3,4]  R988      2.3794779181480408e-01
    z[4,3,4]  R989      1.7909948527812958e-01
    z[4,3,4]  R990      -1.1399597674608231e-01
    z[4,3,4]  R991      -5.6032204627990723e-01
    z[4,3,4]  R992      -1.2320470996201038e-02
    z[4,3,4]  R993      2.4691355228424072e-01
    z[4,3,4]  R994      6.8836772441864014e-01
    z[4,3,4]  R995      8.6080354452133179e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R909      -1
    z[4,3,5]  R910      1
    z[4,3,5]  R913      -1.8966224789619446e-01
    z[4,3,5]  R914      -8.7802886962890625e-02
    z[4,3,5]  R915      -0.067637138068676
    z[4,3,5]  R916      -4.5988604426383972e-02
    z[4,3,5]  R917      -4.5047560706734657e-03
    z[4,3,5]  R918      -3.2689280807971954e-02
    z[4,3,5]  R919      -3.1402119994163513e-01
    z[4,3,5]  R920      -2.1722888946533203e-01
    z[4,3,5]  R921      1.6671134158968925e-02
    z[4,3,5]  R922      -2.8326642513275146e-01
    z[4,3,5]  R923      1.5485012531280518e-01
    z[4,3,5]  R924      3.1400460004806519e-01
    z[4,3,5]  R925      1.8866080045700073e-01
    z[4,3,5]  R926      1.1222336441278458e-01
    z[4,3,5]  R927      -4.7523528337478638e-01
    z[4,3,5]  R928      -4.2120289802551270e-01
    z[4,3,5]  R929      3.0312919989228249e-02
    z[4,3,5]  R930      -1.0461964458227158e-01
    z[4,3,5]  R931      -4.2417088150978088e-01
    z[4,3,5]  R932      -6.0311728715896606e-01
    z[4,3,5]  R933      -3.6094522476196289e-01
    z[4,3,5]  R934      -1.3168926537036896e-01
    z[4,3,5]  R935      6.9820769131183624e-02
    z[4,3,5]  R936      1.6734541952610016e-01
    z[4,3,5]  R937      -0.349232941865921
    z[4,3,5]  R938      -1.2980429828166962e-01
    z[4,3,5]  R939      -1.8330083787441254e-01
    z[4,3,5]  R940      -1.6589336097240448e-01
    z[4,3,5]  R941      6.6312126815319061e-02
    z[4,3,5]  R942      -3.8353651762008667e-02
    z[4,3,5]  R943      3.4753882884979248e-01
    z[4,3,5]  R944      -1.3029731810092926e-01
    z[4,3,5]  R945      5.8049920946359634e-02
    z[4,3,5]  R946      0.0403253547847271
    z[4,3,5]  R947      -2.4391652643680573e-01
    z[4,3,5]  R948      -2.3386912420392036e-02
    z[4,3,5]  R949      1.4532741904258728e-01
    z[4,3,5]  R950      2.7338016033172607e-01
    z[4,3,5]  R951      3.8393858820199966e-02
    z[4,3,5]  R952      1.7576953768730164e-01
    z[4,3,5]  R953      7.1508079767227173e-02
    z[4,3,5]  R954      -3.5299065709114075e-01
    z[4,3,5]  R955      8.2775211334228516e-01
    z[4,3,5]  R956      1.0440965741872787e-01
    z[4,3,5]  R957      -4.4865331053733826e-01
    z[4,3,5]  R958      1.5884213149547577e-01
    z[4,3,5]  R959      4.0458705276250839e-02
    z[4,3,5]  R960      0.0845780149102211
    z[4,3,5]  R961      -4.5434813946485519e-02
    z[4,3,5]  R962      -1.3693729043006897e-01
    z[4,3,5]  R963      0.0855298712849617
    z[4,3,5]  R964      6.1912846565246582e-01
    z[4,3,5]  R965      -1.4781183004379272e-01
    z[4,3,5]  R966      1.0292392224073410e-01
    z[4,3,5]  R967      2.4152073264122009e-01
    z[4,3,5]  R968      2.0462978631258011e-02
    z[4,3,5]  R969      2.7034100890159607e-01
    z[4,3,5]  R970      2.2451931238174438e-01
    z[4,3,5]  R971      2.0600913465023041e-01
    z[4,3,5]  R972      -2.2528212517499924e-02
    z[4,3,5]  R973      -2.8327253460884094e-01
    z[4,3,5]  R974      -5.5435862392187119e-02
    z[4,3,5]  R975      -4.5814013481140137e-01
    z[4,3,5]  R976      -0.571395218372345
    z[4,3,5]  R977      -1.3369980454444885e-01
    z[4,3,5]  R978      -3.6823821067810059e-01
    z[4,3,5]  R979      -0.0757163017988205
    z[4,3,5]  R980      2.4088194966316223e-01
    z[4,3,5]  R981      8.3779737353324890e-02
    z[4,3,5]  R982      3.4886193275451660e-01
    z[4,3,5]  R983      -1.5392936766147614e-02
    z[4,3,5]  R984      -5.1585435867309570e-01
    z[4,3,5]  R985      -9.1138131916522980e-02
    z[4,3,5]  R986      6.3751161098480225e-01
    z[4,3,5]  R987      6.6132062673568726e-01
    z[4,3,5]  R988      4.8494762182235718e-01
    z[4,3,5]  R989      6.5178465843200684e-01
    z[4,3,5]  R990      -8.6875444650650024e-01
    z[4,3,5]  R991      1.5387354791164398e-01
    z[4,3,5]  R992      1.9965665042400360e-01
    z[4,3,5]  R993      8.0717802047729492e-02
    z[4,3,5]  R994      2.8737673535943031e-02
    z[4,3,5]  R995      -7.9404406249523163e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R911      -1
    z[4,3,6]  R912      1
    z[4,3,6]  R913      3.5725861787796021e-01
    z[4,3,6]  R914      -1.3364584743976593e-01
    z[4,3,6]  R915      3.8772195577621460e-01
    z[4,3,6]  R916      -4.8938225954771042e-02
    z[4,3,6]  R917      -4.5889008045196533e-01
    z[4,3,6]  R918      6.0432165861129761e-02
    z[4,3,6]  R919      -1.5530244447290897e-02
    z[4,3,6]  R920      4.6107780188322067e-02
    z[4,3,6]  R921      -2.0385617017745972e-01
    z[4,3,6]  R922      1.7365282773971558e-01
    z[4,3,6]  R923      -6.3380233943462372e-02
    z[4,3,6]  R924      -1.2486694753170013e-01
    z[4,3,6]  R925      -7.1028012037277222e-01
    z[4,3,6]  R926      -5.5898189544677734e-01
    z[4,3,6]  R927      -8.3008259534835815e-02
    z[4,3,6]  R928      -2.5063201785087585e-01
    z[4,3,6]  R929      -0.0890025720000267
    z[4,3,6]  R930      -1.6875582933425903e-01
    z[4,3,6]  R931      1.7634356021881104e-01
    z[4,3,6]  R932      1.9689792394638062e-01
    z[4,3,6]  R933      -1.5362252295017242e-01
    z[4,3,6]  R934      3.7762913852930069e-02
    z[4,3,6]  R935      -1.8423174321651459e-01
    z[4,3,6]  R936      3.1699728965759277e-01
    z[4,3,6]  R937      -0.0688420757651329
    z[4,3,6]  R938      2.5477710366249084e-01
    z[4,3,6]  R939      -5.1449424028396606e-01
    z[4,3,6]  R940      3.2861515879631042e-02
    z[4,3,6]  R941      -4.3765522539615631e-02
    z[4,3,6]  R942      -2.4215854704380035e-01
    z[4,3,6]  R943      2.3911017179489136e-01
    z[4,3,6]  R944      5.1108323037624359e-02
    z[4,3,6]  R945      -1.1741942912340164e-01
    z[4,3,6]  R946      -1.5337510406970978e-01
    z[4,3,6]  R947      -3.4810605645179749e-01
    z[4,3,6]  R948      1.2059990316629410e-02
    z[4,3,6]  R949      -1.7385342717170715e-01
    z[4,3,6]  R950      -1.3387300074100494e-02
    z[4,3,6]  R951      -2.3169608414173126e-01
    z[4,3,6]  R952      -1.4494709670543671e-01
    z[4,3,6]  R953      1.4631895720958710e-01
    z[4,3,6]  R954      3.5688430070877075e-01
    z[4,3,6]  R955      1.8671859055757523e-02
    z[4,3,6]  R956      -1.4046387374401093e-01
    z[4,3,6]  R957      -5.2591826766729355e-02
    z[4,3,6]  R958      -5.9016954153776169e-02
    z[4,3,6]  R959      -1.4667728543281555e-01
    z[4,3,6]  R960      7.6553061604499817e-02
    z[4,3,6]  R961      -2.6487118005752563e-01
    z[4,3,6]  R962      4.2527332901954651e-01
    z[4,3,6]  R963      -4.4908666610717773e-01
    z[4,3,6]  R964      3.6136223934590816e-03
    z[4,3,6]  R965      -4.3110698461532593e-01
    z[4,3,6]  R966      7.2128519415855408e-02
    z[4,3,6]  R967      -1.2996993958950043e-01
    z[4,3,6]  R968      4.2649745941162109e-01
    z[4,3,6]  R969      -7.5684264302253723e-02
    z[4,3,6]  R970      1.0512106865644455e-01
    z[4,3,6]  R971      -2.1033169329166412e-01
    z[4,3,6]  R972      0.22533018887043
    z[4,3,6]  R973      5.8912258595228195e-02
    z[4,3,6]  R974      -2.2711883485317230e-01
    z[4,3,6]  R975      -4.3068295717239380e-01
    z[4,3,6]  R976      0.339596688747406
    z[4,3,6]  R977      -1.0362610220909119e-02
    z[4,3,6]  R978      -3.0332520604133606e-01
    z[4,3,6]  R979      -1.9626735150814056e-01
    z[4,3,6]  R980      2.3485115170478821e-01
    z[4,3,6]  R981      1.9183342158794403e-01
    z[4,3,6]  R982      1.0617990791797638e-01
    z[4,3,6]  R983      0.380306214094162
    z[4,3,6]  R984      3.0408294871449471e-02
    z[4,3,6]  R985      1.1247279122471809e-02
    z[4,3,6]  R986      4.0876977145671844e-03
    z[4,3,6]  R987      -0.0807369276881218
    z[4,3,6]  R988      0.0790676400065422
    z[4,3,6]  R989      -0.0378536619246006
    z[4,3,6]  R990      -1.9489973783493042e-01
    z[4,3,6]  R991      -5.0770029425621033e-02
    z[4,3,6]  R992      -3.9156213402748108e-02
    z[4,3,6]  R993      -3.5827852785587311e-02
    z[4,3,6]  R994      7.4549503624439240e-02
    z[4,3,6]  R995      -5.3753387182950974e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1033     -1
    z[4,5,0]  R1034     1
    z[4,5,0]  R1047     1.8276479095220566e-02
    z[4,5,0]  R1048     1.1998645216226578e-01
    z[4,5,0]  R1049     6.4301635138690472e-03
    z[4,5,0]  R1050     3.2188287377357483e-01
    z[4,5,0]  R1051     2.7721645310521126e-02
    z[4,5,0]  R1052     5.9904661029577255e-02
    z[4,5,0]  R1053     0.858936071395874
    z[4,5,0]  R1054     8.3661407232284546e-01
    z[4,5,0]  R1055     0.852433979511261
    z[4,5,0]  R1056     8.1905382871627808e-01
    z[4,5,0]  R1057     -1.7209856212139130e-01
    z[4,5,0]  R1058     -1.0541781038045883e-01
    z[4,5,0]  R1059     -2.4894516170024872e-01
    z[4,5,0]  R1060     -3.6012226343154907e-01
    z[4,5,0]  R1061     5.3793575614690781e-02
    z[4,5,0]  R1062     -7.2886824607849121e-01
    z[4,5,0]  R1063     3.1899258494377136e-01
    z[4,5,0]  R1064     -2.4710580706596375e-02
    z[4,5,0]  R1065     5.6930180639028549e-02
    z[4,5,0]  R1066     2.9730057716369629e-01
    z[4,5,0]  R1067     -7.6461881399154663e-01
    z[4,5,0]  R1068     3.1305238604545593e-02
    z[4,5,0]  R1069     -2.4371033906936646e-01
    z[4,5,0]  R1070     -6.6487453877925873e-02
    z[4,5,0]  R1071     1.7442536354064941e-01
    z[4,5,0]  R1072     -2.1793624758720398e-01
    z[4,5,0]  R1073     1.1814450845122337e-02
    z[4,5,0]  R1074     -1.3853733241558075e-01
    z[4,5,0]  R1075     -2.6652544736862183e-01
    z[4,5,0]  R1076     -2.8162550926208496e-01
    z[4,5,0]  R1077     -5.9845107793807983e-01
    z[4,5,0]  R1078     2.3119193315505981e-01
    z[4,5,0]  R1079     1.5551097691059113e-01
    z[4,5,0]  R1080     2.6353845000267029e-01
    z[4,5,0]  R1081     7.6957635581493378e-02
    z[4,5,0]  R1082     -5.1124148070812225e-02
    z[4,5,0]  R1083     2.0614919066429138e-01
    z[4,5,0]  R1084     -4.9619201570749283e-02
    z[4,5,0]  R1085     -1.0518789291381836e-01
    z[4,5,0]  R1086     -7.7299750410020351e-03
    z[4,5,0]  R1087     -7.8285849094390869e-01
    z[4,5,0]  R1088     -4.2401376366615295e-01
    z[4,5,0]  R1089     -2.3066484928131104e-01
    z[4,5,0]  R1090     -3.7945550680160522e-01
    z[4,5,0]  R1091     -1.3252480328083038e-01
    z[4,5,0]  R1092     -2.2853079438209534e-01
    z[4,5,0]  R1093     -3.3826592564582825e-01
    z[4,5,0]  R1094     3.2707676291465759e-01
    z[4,5,0]  R1095     -8.2660518586635590e-02
    z[4,5,0]  R1096     -1.9516560435295105e-01
    z[4,5,0]  R1097     -3.0983048677444458e-01
    z[4,5,0]  R1098     -5.8509427309036255e-01
    z[4,5,0]  R1099     -3.4305313229560852e-01
    z[4,5,0]  R1100     3.4879993181675673e-03
    z[4,5,0]  R1101     2.7744683623313904e-01
    z[4,5,0]  R1102     -7.3124817572534084e-03
    z[4,5,0]  R1103     -1.5040916204452515e-01
    z[4,5,0]  R1104     -8.9968644082546234e-02
    z[4,5,0]  R1105     5.3375765681266785e-02
    z[4,5,0]  R1106     -5.7130229473114014e-01
    z[4,5,0]  R1107     1.4367249608039856e-01
    z[4,5,0]  R1108     9.6836224198341370e-02
    z[4,5,0]  R1109     -9.1374427080154419e-02
    z[4,5,0]  R1110     -1.2036441266536713e-01
    z[4,5,0]  R1111     7.7137142419815063e-02
    z[4,5,0]  R1112     -1.8016014993190765e-01
    z[4,5,0]  R1113     -1.3040290772914886e-01
    z[4,5,0]  R1114     3.2169858459383249e-03
    z[4,5,0]  R1115     4.2814472317695618e-01
    z[4,5,0]  R1116     -1.3561758399009705e-01
    z[4,5,0]  R1117     -1.9953235983848572e-01
    z[4,5,0]  R1118     -1.5464584529399872e-01
    z[4,5,0]  R1119     -7.9916212707757950e-03
    z[4,5,0]  R1120     4.1941270232200623e-02
    z[4,5,0]  R1121     -5.7299101352691650e-01
    z[4,5,0]  R1122     -6.6932633519172668e-02
    z[4,5,0]  R1123     2.0704032853245735e-02
    z[4,5,0]  R1124     -4.8795364797115326e-02
    z[4,5,0]  R1125     -2.0290263928472996e-03
    z[4,5,0]  R1126     2.0917126536369324e-01
    z[4,5,0]  R1127     -1.2074116617441177e-01
    z[4,5,0]  R1128     -1.7033240199089050e-01
    z[4,5,0]  R1129     -1.2313283979892731e-01
    z[4,5,0]  R1130     -3.0875965952873230e-02
    z[4,5,0]  R1131     8.8018581271171570e-02
    z[4,5,0]  R1132     3.3534996211528778e-02
    z[4,5,0]  R1133     3.1025785207748413e-01
    z[4,5,0]  R1134     -5.4954189807176590e-02
    z[4,5,0]  R1135     -2.0206263661384583e-01
    z[4,5,0]  R1136     3.8460159301757812e-01
    z[4,5,0]  R1137     -8.2343824207782745e-02
    z[4,5,0]  R1138     -1.0563597828149796e-01
    z[4,5,0]  R1139     -1.5603317320346832e-01
    z[4,5,0]  R1140     -7.3864096403121948e-01
    z[4,5,0]  R1141     -6.9027908146381378e-02
    z[4,5,0]  R1142     -4.0976423770189285e-02
    z[4,5,0]  R1143     -3.2495218515396118e-01
    z[4,5,0]  R1144     -3.3865779638290405e-01
    z[4,5,0]  R1145     -1.5645249187946320e-01
    z[4,5,0]  R1146     -8.5378557443618774e-02
    z[4,5,0]  R1147     9.2741541564464569e-02
    z[4,5,0]  R1148     -1.2282628566026688e-01
    z[4,5,0]  R1149     -6.9633579254150391e-01
    z[4,5,0]  R1150     3.3384156227111816e-01
    z[4,5,0]  R1151     -1.2994219362735748e-01
    z[4,5,0]  R1152     9.7509376704692841e-02
    z[4,5,0]  R1153     -3.1440767645835876e-01
    z[4,5,0]  R1154     -7.5987897813320160e-02
    z[4,5,0]  R1155     -2.1686081588268280e-01
    z[4,5,0]  R1156     5.2467696368694305e-02
    z[4,5,0]  R1157     -7.6238703727722168e-01
    z[4,5,0]  R1158     -1.4882014691829681e-01
    z[4,5,0]  R1159     4.7597482800483704e-01
    z[4,5,0]  R1160     8.9614480733871460e-01
    z[4,5,0]  R1161     9.1532504558563232e-01
    z[4,5,0]  R1162     8.8304710388183594e-01
    z[4,5,0]  R1163     8.7570029497146606e-01
    z[4,5,0]  R1164     8.6964684724807739e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1035     -1
    z[4,5,1]  R1036     1
    z[4,5,1]  R1047     8.8279730081558228e-01
    z[4,5,1]  R1048     8.9820599555969238e-01
    z[4,5,1]  R1049     5.1838332414627075e-01
    z[4,5,1]  R1050     5.8870565891265869e-01
    z[4,5,1]  R1051     5.4523938894271851e-01
    z[4,5,1]  R1052     5.5945807695388794e-01
    z[4,5,1]  R1053     -1.0856576263904572e-01
    z[4,5,1]  R1054     1.3602754473686218e-01
    z[4,5,1]  R1055     -2.1678301692008972e-01
    z[4,5,1]  R1056     5.0889525562524796e-02
    z[4,5,1]  R1057     1.0282338410615921e-01
    z[4,5,1]  R1058     3.7497210502624512e-01
    z[4,5,1]  R1059     0.122503861784935
    z[4,5,1]  R1060     4.6388339251279831e-02
    z[4,5,1]  R1061     6.4730048179626465e-02
    z[4,5,1]  R1062     4.2699292302131653e-01
    z[4,5,1]  R1063     -8.9471697807312012e-01
    z[4,5,1]  R1064     -8.8038235902786255e-01
    z[4,5,1]  R1065     -8.2952016592025757e-01
    z[4,5,1]  R1066     3.6464259028434753e-02
    z[4,5,1]  R1067     4.4890657067298889e-01
    z[4,5,1]  R1068     -9.4527572393417358e-01
    z[4,5,1]  R1069     -9.1798186302185059e-01
    z[4,5,1]  R1070     -8.9208728075027466e-01
    z[4,5,1]  R1071     -8.6514890193939209e-01
    z[4,5,1]  R1072     -8.3336752653121948e-01
    z[4,5,1]  R1073     -8.1203687191009521e-01
    z[4,5,1]  R1074     -5.5051195621490479e-01
    z[4,5,1]  R1075     -9.1903531551361084e-01
    z[4,5,1]  R1076     -8.1354314088821411e-01
    z[4,5,1]  R1077     -3.8258321583271027e-02
    z[4,5,1]  R1078     -9.3632888793945312e-01
    z[4,5,1]  R1079     -9.2413526773452759e-01
    z[4,5,1]  R1080     -8.6651885509490967e-01
    z[4,5,1]  R1081     -8.0911898612976074e-01
    z[4,5,1]  R1082     -8.6442202329635620e-01
    z[4,5,1]  R1083     -8.4205752611160278e-01
    z[4,5,1]  R1084     -0.888372004032135
    z[4,5,1]  R1085     -8.2396632432937622e-01
    z[4,5,1]  R1086     -9.3639492988586426e-01
    z[4,5,1]  R1087     -2.1814670413732529e-02
    z[4,5,1]  R1088     7.0344597101211548e-02
    z[4,5,1]  R1089     4.2119896411895752e-01
    z[4,5,1]  R1090     2.9502192139625549e-01
    z[4,5,1]  R1091     -0.842427670955658
    z[4,5,1]  R1092     -8.9654362201690674e-01
    z[4,5,1]  R1093     -8.8176757097244263e-01
    z[4,5,1]  R1094     -0.814807116985321
    z[4,5,1]  R1095     -7.9867547750473022e-01
    z[4,5,1]  R1096     -7.8840601444244385e-01
    z[4,5,1]  R1097     2.8742921352386475e-01
    z[4,5,1]  R1098     2.4879592657089233e-01
    z[4,5,1]  R1099     1.9900441169738770e-01
    z[4,5,1]  R1100     -8.9389944076538086e-01
    z[4,5,1]  R1101     -8.6115521192550659e-01
    z[4,5,1]  R1102     -8.2163053750991821e-01
    z[4,5,1]  R1103     -3.8869503140449524e-01
    z[4,5,1]  R1104     -5.9901064634323120e-01
    z[4,5,1]  R1105     -4.6669882535934448e-01
    z[4,5,1]  R1106     -7.2935229539871216e-01
    z[4,5,1]  R1107     -1.7200057208538055e-01
    z[4,5,1]  R1108     4.0754759684205055e-03
    z[4,5,1]  R1109     1.0573843028396368e-03
    z[4,5,1]  R1110     -1.6342546045780182e-01
    z[4,5,1]  R1111     0.474097341299057
    z[4,5,1]  R1112     -7.5184464454650879e-02
    z[4,5,1]  R1113     6.0491126775741577e-01
    z[4,5,1]  R1114     1.5866902470588684e-01
    z[4,5,1]  R1115     -7.7959084510803223e-01
    z[4,5,1]  R1116     -8.6356341838836670e-01
    z[4,5,1]  R1117     -7.9793006181716919e-01
    z[4,5,1]  R1118     -0.864427924156189
    z[4,5,1]  R1119     -8.0960261821746826e-01
    z[4,5,1]  R1120     -9.0707629919052124e-01
    z[4,5,1]  R1121     2.5930488109588623e-01
    z[4,5,1]  R1122     2.3826844990253448e-01
    z[4,5,1]  R1123     -8.6427938938140869e-01
    z[4,5,1]  R1124     -8.6776155233383179e-01
    z[4,5,1]  R1125     -0.931408703327179
    z[4,5,1]  R1126     -8.4530013799667358e-01
    z[4,5,1]  R1127     -8.3708190917968750e-01
    z[4,5,1]  R1128     -8.6308616399765015e-01
    z[4,5,1]  R1129     -0.0401635617017746
    z[4,5,1]  R1130     -1.2885574996471405e-01
    z[4,5,1]  R1131     2.1168453991413116e-01
    z[4,5,1]  R1132     4.1205409914255142e-02
    z[4,5,1]  R1133     -1.0249330103397369e-01
    z[4,5,1]  R1134     1.6594892740249634e-01
    z[4,5,1]  R1135     -6.9532161951065063e-01
    z[4,5,1]  R1136     2.3633906245231628e-01
    z[4,5,1]  R1137     4.0792447328567505e-01
    z[4,5,1]  R1138     2.8059142827987671e-01
    z[4,5,1]  R1139     4.2804378271102905e-01
    z[4,5,1]  R1140     -6.7567661404609680e-02
    z[4,5,1]  R1141     1.0781825333833694e-01
    z[4,5,1]  R1142     1.6846668720245361e-01
    z[4,5,1]  R1143     0.685014009475708
    z[4,5,1]  R1144     5.6257504224777222e-01
    z[4,5,1]  R1145     -7.9387080669403076e-01
    z[4,5,1]  R1146     -7.6158392429351807e-01
    z[4,5,1]  R1147     -6.4522135257720947e-01
    z[4,5,1]  R1148     2.4340584874153137e-01
    z[4,5,1]  R1149     5.0495165586471558e-01
    z[4,5,1]  R1150     -3.1800780445337296e-02
    z[4,5,1]  R1151     -4.0371179580688477e-02
    z[4,5,1]  R1152     -2.3372535407543182e-01
    z[4,5,1]  R1153     7.0987462997436523e-01
    z[4,5,1]  R1154     2.3280377686023712e-01
    z[4,5,1]  R1155     -8.0311816930770874e-01
    z[4,5,1]  R1156     -3.8023620843887329e-01
    z[4,5,1]  R1157     2.4064344167709351e-01
    z[4,5,1]  R1158     2.9533258080482483e-01
    z[4,5,1]  R1159     2.7576693892478943e-01
    z[4,5,1]  R1160     2.8850775957107544e-01
    z[4,5,1]  R1161     2.5768095254898071e-01
    z[4,5,1]  R1162     2.7619701623916626e-01
    z[4,5,1]  R1163     1.7701391875743866e-01
    z[4,5,1]  R1164     1.6462750732898712e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1037     -1
    z[4,5,2]  R1038     1
    z[4,5,2]  R1047     6.7431636154651642e-02
    z[4,5,2]  R1048     1.5567451715469360e-01
    z[4,5,2]  R1049     9.1799996793270111e-02
    z[4,5,2]  R1050     -7.2012418508529663e-01
    z[4,5,2]  R1051     -6.9533628225326538e-01
    z[4,5,2]  R1052     -4.1551807522773743e-01
    z[4,5,2]  R1053     -2.8524732589721680e-01
    z[4,5,2]  R1054     -1.3848823308944702e-01
    z[4,5,2]  R1055     -3.6783429980278015e-01
    z[4,5,2]  R1056     -1.7657396197319031e-01
    z[4,5,2]  R1057     8.4021437168121338e-01
    z[4,5,2]  R1058     2.8355118632316589e-01
    z[4,5,2]  R1059     4.9967566132545471e-01
    z[4,5,2]  R1060     4.6472790837287903e-01
    z[4,5,2]  R1061     8.4655404090881348e-01
    z[4,5,2]  R1062     6.6695623099803925e-02
    z[4,5,2]  R1063     -1.8805885314941406e-01
    z[4,5,2]  R1064     -0.0760580450296402
    z[4,5,2]  R1065     -1.6840463876724243e-01
    z[4,5,2]  R1066     6.3653844594955444e-01
    z[4,5,2]  R1067     9.5905712805688381e-04
    z[4,5,2]  R1068     -2.5765869021415710e-01
    z[4,5,2]  R1069     1.9793811440467834e-01
    z[4,5,2]  R1070     8.2529969513416290e-02
    z[4,5,2]  R1071     3.0190202593803406e-01
    z[4,5,2]  R1072     3.1279298663139343e-01
    z[4,5,2]  R1073     -0.0842321366071701
    z[4,5,2]  R1074     -4.0897119045257568e-01
    z[4,5,2]  R1075     -1.3384819030761719e-01
    z[4,5,2]  R1076     -9.7464453428983688e-03
    z[4,5,2]  R1077     2.5798752903938293e-02
    z[4,5,2]  R1078     1.9758033752441406e-01
    z[4,5,2]  R1079     -3.5061892122030258e-02
    z[4,5,2]  R1080     5.4388329386711121e-02
    z[4,5,2]  R1081     -1.8867659568786621e-01
    z[4,5,2]  R1082     7.1011655032634735e-02
    z[4,5,2]  R1083     2.8882932662963867e-01
    z[4,5,2]  R1084     -2.2510716319084167e-01
    z[4,5,2]  R1085     1.8280208110809326e-01
    z[4,5,2]  R1086     1.8073084950447083e-01
    z[4,5,2]  R1087     3.6547788977622986e-01
    z[4,5,2]  R1088     7.0659118890762329e-01
    z[4,5,2]  R1089     -8.2825394347310066e-03
    z[4,5,2]  R1090     4.5111495256423950e-01
    z[4,5,2]  R1091     8.0974452197551727e-02
    z[4,5,2]  R1092     -2.9770871996879578e-01
    z[4,5,2]  R1093     8.1429913640022278e-02
    z[4,5,2]  R1094     9.3797542154788971e-02
    z[4,5,2]  R1095     -4.2805038392543793e-02
    z[4,5,2]  R1096     3.6200657486915588e-02
    z[4,5,2]  R1097     4.8477512598037720e-01
    z[4,5,2]  R1098     -7.6532892882823944e-02
    z[4,5,2]  R1099     5.3832525014877319e-01
    z[4,5,2]  R1100     3.4502517431974411e-02
    z[4,5,2]  R1101     1.4597199857234955e-01
    z[4,5,2]  R1102     -2.9339563846588135e-01
    z[4,5,2]  R1103     -7.7600318193435669e-01
    z[4,5,2]  R1104     -6.7623686790466309e-01
    z[4,5,2]  R1105     -7.2706836462020874e-01
    z[4,5,2]  R1106     -2.1004046499729156e-01
    z[4,5,2]  R1107     8.8556744158267975e-03
    z[4,5,2]  R1108     -4.8384219408035278e-01
    z[4,5,2]  R1109     -5.6739443540573120e-01
    z[4,5,2]  R1110     -8.4151841700077057e-02
    z[4,5,2]  R1111     -1.5293259918689728e-01
    z[4,5,2]  R1112     -3.2047325372695923e-01
    z[4,5,2]  R1113     -2.7669697999954224e-01
    z[4,5,2]  R1114     0.551289439201355
    z[4,5,2]  R1115     2.4917015433311462e-01
    z[4,5,2]  R1116     -1.0660753399133682e-01
    z[4,5,2]  R1117     -2.7323761582374573e-01
    z[4,5,2]  R1118     -5.8929339051246643e-02
    z[4,5,2]  R1119     1.5184928476810455e-01
    z[4,5,2]  R1120     2.3951035737991333e-01
    z[4,5,2]  R1121     6.9373279809951782e-01
    z[4,5,2]  R1122     8.3153164386749268e-01
    z[4,5,2]  R1123     0.327529639005661
    z[4,5,2]  R1124     -5.3468596190214157e-02
    z[4,5,2]  R1125     2.0595720410346985e-01
    z[4,5,2]  R1126     -1.2311632931232452e-01
    z[4,5,2]  R1127     -2.1409240365028381e-01
    z[4,5,2]  R1128     -2.5118723511695862e-01
    z[4,5,2]  R1129     9.2495280504226685e-01
    z[4,5,2]  R1130     -4.8624154925346375e-01
    z[4,5,2]  R1131     -5.2616435289382935e-01
    z[4,5,2]  R1132     -1.1939374357461929e-01
    z[4,5,2]  R1133     -2.4027542769908905e-01
    z[4,5,2]  R1134     -6.2671370804309845e-02
    z[4,5,2]  R1135     -2.0683540403842926e-01
    z[4,5,2]  R1136     -3.0107992887496948e-01
    z[4,5,2]  R1137     -3.0763953924179077e-01
    z[4,5,2]  R1138     -1.1845391988754272e-01
    z[4,5,2]  R1139     1.1871451511979103e-02
    z[4,5,2]  R1140     5.6594204902648926e-01
    z[4,5,2]  R1141     -5.9812232851982117e-02
    z[4,5,2]  R1142     1.8718820810317993e-01
    z[4,5,2]  R1143     2.4609220027923584e-01
    z[4,5,2]  R1144     5.6773293018341064e-01
    z[4,5,2]  R1145     3.8105454295873642e-02
    z[4,5,2]  R1146     3.9975973963737488e-01
    z[4,5,2]  R1147     3.0826881527900696e-01
    z[4,5,2]  R1148     -1.4743112027645111e-01
    z[4,5,2]  R1149     4.1032043099403381e-01
    z[4,5,2]  R1150     -2.8690841794013977e-01
    z[4,5,2]  R1151     -4.8879832029342651e-01
    z[4,5,2]  R1152     7.2914361953735352e-01
    z[4,5,2]  R1153     2.8350222110748291e-01
    z[4,5,2]  R1154     -4.6937850117683411e-01
    z[4,5,2]  R1155     -2.3408372700214386e-01
    z[4,5,2]  R1156     -9.8009787499904633e-02
    z[4,5,2]  R1157     5.1663786172866821e-01
    z[4,5,2]  R1158     9.0008443593978882e-01
    z[4,5,2]  R1159     -4.3937939405441284e-01
    z[4,5,2]  R1160     1.7338788509368896e-01
    z[4,5,2]  R1161     1.9356388598680496e-02
    z[4,5,2]  R1162     2.2289606928825378e-01
    z[4,5,2]  R1163     3.6890214681625366e-01
    z[4,5,2]  R1164     3.0789998173713684e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1039     -1
    z[4,5,3]  R1040     1
    z[4,5,3]  R1047     1.1516990512609482e-01
    z[4,5,3]  R1048     3.2431280612945557e-01
    z[4,5,3]  R1049     -2.0396200940012932e-02
    z[4,5,3]  R1050     1.1635913699865341e-01
    z[4,5,3]  R1051     8.8614434003829956e-02
    z[4,5,3]  R1052     -4.9735743552446365e-02
    z[4,5,3]  R1053     1.7283445596694946e-01
    z[4,5,3]  R1054     3.2775089144706726e-01
    z[4,5,3]  R1055     2.1331556141376495e-01
    z[4,5,3]  R1056     4.2960166931152344e-01
    z[4,5,3]  R1057     -3.4326744079589844e-01
    z[4,5,3]  R1058     -7.0934981107711792e-01
    z[4,5,3]  R1059     -3.1899097561836243e-01
    z[4,5,3]  R1060     -6.1695091426372528e-02
    z[4,5,3]  R1061     1.6761821508407593e-01
    z[4,5,3]  R1062     1.9978480041027069e-01
    z[4,5,3]  R1063     1.8895334005355835e-01
    z[4,5,3]  R1064     -7.9344063997268677e-02
    z[4,5,3]  R1065     5.0925098359584808e-02
    z[4,5,3]  R1066     -1.7422821372747421e-02
    z[4,5,3]  R1067     1.1696402914822102e-02
    z[4,5,3]  R1068     -1.2717632949352264e-01
    z[4,5,3]  R1069     -4.6137967146933079e-03
    z[4,5,3]  R1070     -2.5225919485092163e-01
    z[4,5,3]  R1071     5.6858994066715240e-02
    z[4,5,3]  R1072     -2.6485204696655273e-01
    z[4,5,3]  R1073     -5.9067141264677048e-02
    z[4,5,3]  R1074     0.577458918094635
    z[4,5,3]  R1075     2.4416531622409821e-01
    z[4,5,3]  R1076     4.3209555745124817e-01
    z[4,5,3]  R1077     -5.9953224658966064e-01
    z[4,5,3]  R1078     -7.7092565596103668e-02
    z[4,5,3]  R1079     -1.5031945705413818e-01
    z[4,5,3]  R1080     -1.7512956261634827e-01
    z[4,5,3]  R1081     3.2055267691612244e-01
    z[4,5,3]  R1082     4.5226126909255981e-01
    z[4,5,3]  R1083     2.7695652842521667e-01
    z[4,5,3]  R1084     -4.8354491591453552e-02
    z[4,5,3]  R1085     2.9866832494735718e-01
    z[4,5,3]  R1086     1.8614947795867920e-01
    z[4,5,3]  R1087     -4.7284394502639771e-01
    z[4,5,3]  R1088     1.2677592039108276e-01
    z[4,5,3]  R1089     -1.4143761992454529e-01
    z[4,5,3]  R1090     -4.3483623862266541e-01
    z[4,5,3]  R1091     2.1898582577705383e-01
    z[4,5,3]  R1092     1.0630187392234802e-01
    z[4,5,3]  R1093     2.1172007918357849e-01
    z[4,5,3]  R1094     3.3912602066993713e-01
    z[4,5,3]  R1095     5.2484345436096191e-01
    z[4,5,3]  R1096     3.1216824054718018e-01
    z[4,5,3]  R1097     3.7200883030891418e-01
    z[4,5,3]  R1098     9.9150486290454865e-02
    z[4,5,3]  R1099     1.4972022175788879e-01
    z[4,5,3]  R1100     1.7892074584960938e-01
    z[4,5,3]  R1101     1.5810623764991760e-01
    z[4,5,3]  R1102     2.3697124421596527e-01
    z[4,5,3]  R1103     -1.4373597502708435e-01
    z[4,5,3]  R1104     -2.0813571289181709e-02
    z[4,5,3]  R1105     1.5533900260925293e-01
    z[4,5,3]  R1106     7.3797397315502167e-02
    z[4,5,3]  R1107     7.3608434200286865e-01
    z[4,5,3]  R1108     5.4030829668045044e-01
    z[4,5,3]  R1109     6.2292045354843140e-01
    z[4,5,3]  R1110     6.6875702142715454e-01
    z[4,5,3]  R1111     7.5043952465057373e-01
    z[4,5,3]  R1112     7.2219270467758179e-01
    z[4,5,3]  R1113     2.1046654880046844e-01
    z[4,5,3]  R1114     -1.9717127084732056e-01
    z[4,5,3]  R1115     -3.0319371819496155e-01
    z[4,5,3]  R1116     -1.6102933883666992e-01
    z[4,5,3]  R1117     -3.9764145016670227e-01
    z[4,5,3]  R1118     -0.382107138633728
    z[4,5,3]  R1119     -3.4391874074935913e-01
    z[4,5,3]  R1120     2.3867176845669746e-02
    z[4,5,3]  R1121     8.9123375713825226e-02
    z[4,5,3]  R1122     2.2022317349910736e-01
    z[4,5,3]  R1123     -3.3727136254310608e-01
    z[4,5,3]  R1124     -0.384029358625412
    z[4,5,3]  R1125     2.9151519760489464e-02
    z[4,5,3]  R1126     -7.5818479061126709e-02
    z[4,5,3]  R1127     -2.0075872540473938e-01
    z[4,5,3]  R1128     -2.5415161252021790e-01
    z[4,5,3]  R1129     -6.9063976407051086e-03
    z[4,5,3]  R1130     -4.1616834700107574e-02
    z[4,5,3]  R1131     -3.2481840252876282e-01
    z[4,5,3]  R1132     -3.7099415063858032e-01
    z[4,5,3]  R1133     -3.2631272077560425e-01
    z[4,5,3]  R1134     -3.7785044312477112e-01
    z[4,5,3]  R1135     -4.1483816504478455e-01
    z[4,5,3]  R1136     -4.5609995722770691e-01
    z[4,5,3]  R1137     -5.1416993141174316e-01
    z[4,5,3]  R1138     -4.7320303320884705e-01
    z[4,5,3]  R1139     -4.4991636276245117e-01
    z[4,5,3]  R1140     -5.5748138576745987e-02
    z[4,5,3]  R1141     -3.8931149244308472e-01
    z[4,5,3]  R1142     -4.6299010515213013e-01
    z[4,5,3]  R1143     -3.9735451340675354e-01
    z[4,5,3]  R1144     -3.5702151060104370e-01
    z[4,5,3]  R1145     -3.7627723813056946e-01
    z[4,5,3]  R1146     -0.240528866648674
    z[4,5,3]  R1147     -5.2581030130386353e-01
    z[4,5,3]  R1148     -5.1531064510345459e-01
    z[4,5,3]  R1149     -1.9629509747028351e-01
    z[4,5,3]  R1150     -4.6880120038986206e-01
    z[4,5,3]  R1151     -0.436359167098999
    z[4,5,3]  R1152     5.1680259406566620e-02
    z[4,5,3]  R1153     -2.3948743939399719e-01
    z[4,5,3]  R1154     -0.504715621471405
    z[4,5,3]  R1155     -3.7417319416999817e-01
    z[4,5,3]  R1156     1.2880219519138336e-01
    z[4,5,3]  R1157     -2.4957848712801933e-02
    z[4,5,3]  R1158     1.8037818372249603e-01
    z[4,5,3]  R1159     -4.1164883971214294e-01
    z[4,5,3]  R1160     -2.3377789556980133e-01
    z[4,5,3]  R1161     -1.7172104120254517e-01
    z[4,5,3]  R1162     -2.6337611675262451e-01
    z[4,5,3]  R1163     -8.2218900322914124e-02
    z[4,5,3]  R1164     -1.7680704593658447e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1041     -1
    z[4,5,4]  R1042     1
    z[4,5,4]  R1047     1.9727703928947449e-01
    z[4,5,4]  R1048     -1.5441924333572388e-01
    z[4,5,4]  R1049     -0.753320038318634
    z[4,5,4]  R1050     1.1484218388795853e-01
    z[4,5,4]  R1051     -5.3371128160506487e-04
    z[4,5,4]  R1052     -7.0962566137313843e-01
    z[4,5,4]  R1053     -2.0088282227516174e-01
    z[4,5,4]  R1054     -3.2505291700363159e-01
    z[4,5,4]  R1055     -6.0996998101472855e-02
    z[4,5,4]  R1056     2.0736807957291603e-02
    z[4,5,4]  R1057     3.2866573333740234e-01
    z[4,5,4]  R1058     3.8796129822731018e-01
    z[4,5,4]  R1059     1.7747510969638824e-01
    z[4,5,4]  R1060     5.6861841678619385e-01
    z[4,5,4]  R1061     1.2420850992202759e-01
    z[4,5,4]  R1062     4.2864728718996048e-02
    z[4,5,4]  R1063     -1.3347423076629639e-01
    z[4,5,4]  R1064     4.1570693254470825e-01
    z[4,5,4]  R1065     2.5823217630386353e-01
    z[4,5,4]  R1066     -3.1981033086776733e-01
    z[4,5,4]  R1067     2.4458529055118561e-01
    z[4,5,4]  R1068     -0.0643736943602562
    z[4,5,4]  R1069     -1.4105857908725739e-01
    z[4,5,4]  R1070     2.8672186657786369e-02
    z[4,5,4]  R1071     -3.5256387200206518e-03
    z[4,5,4]  R1072     -9.0861216187477112e-02
    z[4,5,4]  R1073     -1.7767642438411713e-01
    z[4,5,4]  R1074     -3.8526263833045959e-01
    z[4,5,4]  R1075     -2.2214479744434357e-02
    z[4,5,4]  R1076     -1.0918529331684113e-01
    z[4,5,4]  R1077     -3.1989240646362305e-01
    z[4,5,4]  R1078     7.2579570114612579e-02
    z[4,5,4]  R1079     2.8426715731620789e-01
    z[4,5,4]  R1080     -3.4772685170173645e-01
    z[4,5,4]  R1081     1.4275148510932922e-01
    z[4,5,4]  R1082     -1.9971360266208649e-01
    z[4,5,4]  R1083     1.9227384030818939e-01
    z[4,5,4]  R1084     2.8355914354324341e-01
    z[4,5,4]  R1085     3.6364585161209106e-01
    z[4,5,4]  R1086     0.0623299777507782
    z[4,5,4]  R1087     5.4575152695178986e-02
    z[4,5,4]  R1088     -2.1897906064987183e-01
    z[4,5,4]  R1089     -0.252566397190094
    z[4,5,4]  R1090     -5.8801096677780151e-01
    z[4,5,4]  R1091     -1.1910246312618256e-01
    z[4,5,4]  R1092     1.2385033816099167e-01
    z[4,5,4]  R1093     1.8290621042251587e-01
    z[4,5,4]  R1094     3.0379590392112732e-01
    z[4,5,4]  R1095     7.5964882969856262e-02
    z[4,5,4]  R1096     2.0483568310737610e-01
    z[4,5,4]  R1097     4.8887407779693604e-01
    z[4,5,4]  R1098     4.4355848431587219e-01
    z[4,5,4]  R1099     -5.6815481185913086e-01
    z[4,5,4]  R1100     3.8978552818298340e-01
    z[4,5,4]  R1101     2.4475511908531189e-01
    z[4,5,4]  R1102     1.7736183479428291e-02
    z[4,5,4]  R1103     -3.5304382443428040e-01
    z[4,5,4]  R1104     -3.3749529719352722e-01
    z[4,5,4]  R1105     -3.7403953075408936e-01
    z[4,5,4]  R1106     -2.0202626287937164e-01
    z[4,5,4]  R1107     -3.6362904310226440e-01
    z[4,5,4]  R1108     -4.9960348010063171e-01
    z[4,5,4]  R1109     -5.0354075431823730e-01
    z[4,5,4]  R1110     -4.5779895782470703e-01
    z[4,5,4]  R1111     -4.1896820068359375e-01
    z[4,5,4]  R1112     1.5908795595169067e-01
    z[4,5,4]  R1113     -3.3138684928417206e-02
    z[4,5,4]  R1114     3.5523235797882080e-01
    z[4,5,4]  R1115     0.217244952917099
    z[4,5,4]  R1116     3.2900825142860413e-01
    z[4,5,4]  R1117     2.9175531864166260e-01
    z[4,5,4]  R1118     -2.2416071593761444e-01
    z[4,5,4]  R1119     2.2207362949848175e-01
    z[4,5,4]  R1120     1.4279159903526306e-01
    z[4,5,4]  R1121     2.6071277260780334e-01
    z[4,5,4]  R1122     4.3812528252601624e-01
    z[4,5,4]  R1123     -2.0273329690098763e-02
    z[4,5,4]  R1124     -8.0797486007213593e-02
    z[4,5,4]  R1125     1.7193509638309479e-01
    z[4,5,4]  R1126     3.0143103003501892e-01
    z[4,5,4]  R1127     2.8488751500844955e-02
    z[4,5,4]  R1128     2.5044327974319458e-01
    z[4,5,4]  R1129     2.7663178741931915e-02
    z[4,5,4]  R1130     7.2973388433456421e-01
    z[4,5,4]  R1131     1.9733099639415741e-01
    z[4,5,4]  R1132     7.4615710973739624e-01
    z[4,5,4]  R1133     -1.6516859829425812e-01
    z[4,5,4]  R1134     3.3730453252792358e-01
    z[4,5,4]  R1135     0.0498795211315155
    z[4,5,4]  R1136     3.7845957279205322e-01
    z[4,5,4]  R1137     4.8017796874046326e-01
    z[4,5,4]  R1138     1.8214242160320282e-01
    z[4,5,4]  R1139     2.7879974246025085e-01
    z[4,5,4]  R1140     -2.2715424001216888e-01
    z[4,5,4]  R1141     -2.0099349319934845e-01
    z[4,5,4]  R1142     5.0853151082992554e-01
    z[4,5,4]  R1143     -1.7937676608562469e-01
    z[4,5,4]  R1144     -1.8026949465274811e-01
    z[4,5,4]  R1145     8.8719859719276428e-02
    z[4,5,4]  R1146     1.4271272718906403e-01
    z[4,5,4]  R1147     -1.2888167798519135e-01
    z[4,5,4]  R1148     3.2883301377296448e-01
    z[4,5,4]  R1149     -0.0935700535774231
    z[4,5,4]  R1150     1.5172238647937775e-01
    z[4,5,4]  R1151     4.0937563776969910e-01
    z[4,5,4]  R1152     5.6467449665069580e-01
    z[4,5,4]  R1153     3.2929587364196777e-01
    z[4,5,4]  R1154     -0.0696905255317688
    z[4,5,4]  R1155     -5.3936969488859177e-02
    z[4,5,4]  R1156     7.8755879402160645e-01
    z[4,5,4]  R1157     2.7873307466506958e-01
    z[4,5,4]  R1158     1.9228503108024597e-01
    z[4,5,4]  R1159     3.1026398763060570e-02
    z[4,5,4]  R1160     1.2565727531909943e-01
    z[4,5,4]  R1161     2.1122060716152191e-01
    z[4,5,4]  R1162     -1.0344945639371872e-01
    z[4,5,4]  R1163     5.7111438363790512e-02
    z[4,5,4]  R1164     2.3274549841880798e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1043     -1
    z[4,5,5]  R1044     1
    z[4,5,5]  R1047     -1.8966224789619446e-01
    z[4,5,5]  R1048     -8.7802886962890625e-02
    z[4,5,5]  R1049     -0.067637138068676
    z[4,5,5]  R1050     -4.5988604426383972e-02
    z[4,5,5]  R1051     -4.5047560706734657e-03
    z[4,5,5]  R1052     -3.2689280807971954e-02
    z[4,5,5]  R1053     -3.1402119994163513e-01
    z[4,5,5]  R1054     -2.1722888946533203e-01
    z[4,5,5]  R1055     1.6671134158968925e-02
    z[4,5,5]  R1056     -2.8326642513275146e-01
    z[4,5,5]  R1057     1.5485012531280518e-01
    z[4,5,5]  R1058     3.1400460004806519e-01
    z[4,5,5]  R1059     1.8866080045700073e-01
    z[4,5,5]  R1060     1.1222336441278458e-01
    z[4,5,5]  R1061     -4.7523528337478638e-01
    z[4,5,5]  R1062     -4.2120289802551270e-01
    z[4,5,5]  R1063     3.0312919989228249e-02
    z[4,5,5]  R1064     -1.0461964458227158e-01
    z[4,5,5]  R1065     -4.2417088150978088e-01
    z[4,5,5]  R1066     -6.0311728715896606e-01
    z[4,5,5]  R1067     -3.6094522476196289e-01
    z[4,5,5]  R1068     -1.3168926537036896e-01
    z[4,5,5]  R1069     6.9820769131183624e-02
    z[4,5,5]  R1070     1.6734541952610016e-01
    z[4,5,5]  R1071     -0.349232941865921
    z[4,5,5]  R1072     -1.2980429828166962e-01
    z[4,5,5]  R1073     -1.8330083787441254e-01
    z[4,5,5]  R1074     -1.6589336097240448e-01
    z[4,5,5]  R1075     6.6312126815319061e-02
    z[4,5,5]  R1076     -3.8353651762008667e-02
    z[4,5,5]  R1077     3.4753882884979248e-01
    z[4,5,5]  R1078     -1.3029731810092926e-01
    z[4,5,5]  R1079     5.8049920946359634e-02
    z[4,5,5]  R1080     0.0403253547847271
    z[4,5,5]  R1081     -2.4391652643680573e-01
    z[4,5,5]  R1082     -2.3386912420392036e-02
    z[4,5,5]  R1083     1.4532741904258728e-01
    z[4,5,5]  R1084     2.7338016033172607e-01
    z[4,5,5]  R1085     3.8393858820199966e-02
    z[4,5,5]  R1086     1.7576953768730164e-01
    z[4,5,5]  R1087     7.1508079767227173e-02
    z[4,5,5]  R1088     -3.5299065709114075e-01
    z[4,5,5]  R1089     8.2775211334228516e-01
    z[4,5,5]  R1090     1.0440965741872787e-01
    z[4,5,5]  R1091     -4.4865331053733826e-01
    z[4,5,5]  R1092     1.5884213149547577e-01
    z[4,5,5]  R1093     4.0458705276250839e-02
    z[4,5,5]  R1094     0.0845780149102211
    z[4,5,5]  R1095     -4.5434813946485519e-02
    z[4,5,5]  R1096     -1.3693729043006897e-01
    z[4,5,5]  R1097     0.0855298712849617
    z[4,5,5]  R1098     6.1912846565246582e-01
    z[4,5,5]  R1099     -1.4781183004379272e-01
    z[4,5,5]  R1100     1.0292392224073410e-01
    z[4,5,5]  R1101     2.4152073264122009e-01
    z[4,5,5]  R1102     2.0462978631258011e-02
    z[4,5,5]  R1103     2.7034100890159607e-01
    z[4,5,5]  R1104     2.2451931238174438e-01
    z[4,5,5]  R1105     2.0600913465023041e-01
    z[4,5,5]  R1106     -2.2528212517499924e-02
    z[4,5,5]  R1107     -5.0993365049362183e-01
    z[4,5,5]  R1108     -3.1566226482391357e-01
    z[4,5,5]  R1109     5.1966842263936996e-02
    z[4,5,5]  R1110     6.5858006477355957e-02
    z[4,5,5]  R1111     0.0646321102976799
    z[4,5,5]  R1112     2.7212062478065491e-01
    z[4,5,5]  R1113     -4.4912809133529663e-01
    z[4,5,5]  R1114     6.9142395257949829e-01
    z[4,5,5]  R1115     -7.7091202139854431e-02
    z[4,5,5]  R1116     -2.8734761476516724e-01
    z[4,5,5]  R1117     6.4398103859275579e-04
    z[4,5,5]  R1118     -8.3091638982295990e-02
    z[4,5,5]  R1119     -3.5906833410263062e-01
    z[4,5,5]  R1120     1.7532955110073090e-01
    z[4,5,5]  R1121     8.3269372582435608e-02
    z[4,5,5]  R1122     -0.0711384192109108
    z[4,5,5]  R1123     -6.2169115990400314e-02
    z[4,5,5]  R1124     1.5969856083393097e-01
    z[4,5,5]  R1125     1.9097542762756348e-01
    z[4,5,5]  R1126     2.0190049707889557e-01
    z[4,5,5]  R1127     4.2580485343933105e-01
    z[4,5,5]  R1128     1.8876263499259949e-01
    z[4,5,5]  R1129     -2.1215988695621490e-01
    z[4,5,5]  R1130     -3.3713313937187195e-01
    z[4,5,5]  R1131     6.9382983446121216e-01
    z[4,5,5]  R1132     5.3669852018356323e-01
    z[4,5,5]  R1133     8.0368494987487793e-01
    z[4,5,5]  R1134     8.3032655715942383e-01
    z[4,5,5]  R1135     -2.8334662318229675e-01
    z[4,5,5]  R1136     5.9061342477798462e-01
    z[4,5,5]  R1137     4.6428731083869934e-01
    z[4,5,5]  R1138     7.9928082227706909e-01
    z[4,5,5]  R1139     6.3880944252014160e-01
    z[4,5,5]  R1140     -1.2024427205324173e-01
    z[4,5,5]  R1141     8.8297879695892334e-01
    z[4,5,5]  R1142     0.678679347038269
    z[4,5,5]  R1143     2.0962141454219818e-01
    z[4,5,5]  R1144     2.9410168528556824e-01
    z[4,5,5]  R1145     -1.6936337947845459e-01
    z[4,5,5]  R1146     -2.9251632094383240e-01
    z[4,5,5]  R1147     2.1376506984233856e-01
    z[4,5,5]  R1148     7.2798830270767212e-01
    z[4,5,5]  R1149     1.8158622086048126e-01
    z[4,5,5]  R1150     6.9855982065200806e-01
    z[4,5,5]  R1151     5.7795554399490356e-01
    z[4,5,5]  R1152     -2.6634159684181213e-01
    z[4,5,5]  R1153     3.6635585129261017e-02
    z[4,5,5]  R1154     6.2024587392807007e-01
    z[4,5,5]  R1155     -2.1901336312294006e-01
    z[4,5,5]  R1156     -2.9368248581886292e-01
    z[4,5,5]  R1157     -9.8348014056682587e-02
    z[4,5,5]  R1158     -0.0858580619096756
    z[4,5,5]  R1159     5.0305879116058350e-01
    z[4,5,5]  R1160     1.7933454364538193e-03
    z[4,5,5]  R1161     1.7778772860765457e-02
    z[4,5,5]  R1162     1.3922728598117828e-02
    z[4,5,5]  R1163     6.9761417806148529e-02
    z[4,5,5]  R1164     -1.3274255394935608e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1045     -1
    z[4,5,6]  R1046     1
    z[4,5,6]  R1047     3.5725861787796021e-01
    z[4,5,6]  R1048     -1.3364584743976593e-01
    z[4,5,6]  R1049     3.8772195577621460e-01
    z[4,5,6]  R1050     -4.8938225954771042e-02
    z[4,5,6]  R1051     -4.5889008045196533e-01
    z[4,5,6]  R1052     6.0432165861129761e-02
    z[4,5,6]  R1053     -1.5530244447290897e-02
    z[4,5,6]  R1054     4.6107780188322067e-02
    z[4,5,6]  R1055     -2.0385617017745972e-01
    z[4,5,6]  R1056     1.7365282773971558e-01
    z[4,5,6]  R1057     -6.3380233943462372e-02
    z[4,5,6]  R1058     -1.2486694753170013e-01
    z[4,5,6]  R1059     -7.1028012037277222e-01
    z[4,5,6]  R1060     -5.5898189544677734e-01
    z[4,5,6]  R1061     -8.3008259534835815e-02
    z[4,5,6]  R1062     -2.5063201785087585e-01
    z[4,5,6]  R1063     -0.0890025720000267
    z[4,5,6]  R1064     -1.6875582933425903e-01
    z[4,5,6]  R1065     1.7634356021881104e-01
    z[4,5,6]  R1066     1.9689792394638062e-01
    z[4,5,6]  R1067     -1.5362252295017242e-01
    z[4,5,6]  R1068     3.7762913852930069e-02
    z[4,5,6]  R1069     -1.8423174321651459e-01
    z[4,5,6]  R1070     3.1699728965759277e-01
    z[4,5,6]  R1071     -0.0688420757651329
    z[4,5,6]  R1072     2.5477710366249084e-01
    z[4,5,6]  R1073     -5.1449424028396606e-01
    z[4,5,6]  R1074     3.2861515879631042e-02
    z[4,5,6]  R1075     -4.3765522539615631e-02
    z[4,5,6]  R1076     -2.4215854704380035e-01
    z[4,5,6]  R1077     2.3911017179489136e-01
    z[4,5,6]  R1078     5.1108323037624359e-02
    z[4,5,6]  R1079     -1.1741942912340164e-01
    z[4,5,6]  R1080     -1.5337510406970978e-01
    z[4,5,6]  R1081     -3.4810605645179749e-01
    z[4,5,6]  R1082     1.2059990316629410e-02
    z[4,5,6]  R1083     -1.7385342717170715e-01
    z[4,5,6]  R1084     -1.3387300074100494e-02
    z[4,5,6]  R1085     -2.3169608414173126e-01
    z[4,5,6]  R1086     -1.4494709670543671e-01
    z[4,5,6]  R1087     1.4631895720958710e-01
    z[4,5,6]  R1088     3.5688430070877075e-01
    z[4,5,6]  R1089     1.8671859055757523e-02
    z[4,5,6]  R1090     -1.4046387374401093e-01
    z[4,5,6]  R1091     -5.2591826766729355e-02
    z[4,5,6]  R1092     -5.9016954153776169e-02
    z[4,5,6]  R1093     -1.4667728543281555e-01
    z[4,5,6]  R1094     7.6553061604499817e-02
    z[4,5,6]  R1095     -2.6487118005752563e-01
    z[4,5,6]  R1096     4.2527332901954651e-01
    z[4,5,6]  R1097     -4.4908666610717773e-01
    z[4,5,6]  R1098     3.6136223934590816e-03
    z[4,5,6]  R1099     -4.3110698461532593e-01
    z[4,5,6]  R1100     7.2128519415855408e-02
    z[4,5,6]  R1101     -1.2996993958950043e-01
    z[4,5,6]  R1102     4.2649745941162109e-01
    z[4,5,6]  R1103     -7.5684264302253723e-02
    z[4,5,6]  R1104     1.0512106865644455e-01
    z[4,5,6]  R1105     -2.1033169329166412e-01
    z[4,5,6]  R1106     0.22533018887043
    z[4,5,6]  R1107     -1.2496767193078995e-01
    z[4,5,6]  R1108     -3.3959320187568665e-01
    z[4,5,6]  R1109     1.5946586430072784e-01
    z[4,5,6]  R1110     5.3904527425765991e-01
    z[4,5,6]  R1111     5.4972756654024124e-02
    z[4,5,6]  R1112     4.8812466859817505e-01
    z[4,5,6]  R1113     0.541669487953186
    z[4,5,6]  R1114     1.6661377251148224e-01
    z[4,5,6]  R1115     4.2185693979263306e-02
    z[4,5,6]  R1116     8.8064707815647125e-02
    z[4,5,6]  R1117     0.0748034194111824
    z[4,5,6]  R1118     1.4905783534049988e-01
    z[4,5,6]  R1119     -1.5778036415576935e-01
    z[4,5,6]  R1120     -2.5766023993492126e-01
    z[4,5,6]  R1121     -2.0082110166549683e-01
    z[4,5,6]  R1122     4.2314846068620682e-02
    z[4,5,6]  R1123     -1.6519361734390259e-01
    z[4,5,6]  R1124     -2.4947854876518250e-01
    z[4,5,6]  R1125     -1.5222434699535370e-01
    z[4,5,6]  R1126     -0.298637717962265
    z[4,5,6]  R1127     -1.2827472388744354e-01
    z[4,5,6]  R1128     -5.2869278006255627e-03
    z[4,5,6]  R1129     2.8611668944358826e-01
    z[4,5,6]  R1130     -3.1322479248046875e-01
    z[4,5,6]  R1131     -2.1153491735458374e-01
    z[4,5,6]  R1132     2.2140184417366982e-02
    z[4,5,6]  R1133     -2.3628962039947510e-01
    z[4,5,6]  R1134     -1.3973458111286163e-01
    z[4,5,6]  R1135     4.2196404933929443e-01
    z[4,5,6]  R1136     -7.4117675423622131e-02
    z[4,5,6]  R1137     -1.4720979332923889e-01
    z[4,5,6]  R1138     1.1466714553534985e-02
    z[4,5,6]  R1139     3.2258301973342896e-01
    z[4,5,6]  R1140     -2.4573981761932373e-01
    z[4,5,6]  R1141     9.1757513582706451e-02
    z[4,5,6]  R1142     -0.036479651927948
    z[4,5,6]  R1143     -3.6137616634368896e-01
    z[4,5,6]  R1144     6.5060378983616829e-03
    z[4,5,6]  R1145     4.0706261992454529e-01
    z[4,5,6]  R1146     2.9850575327873230e-01
    z[4,5,6]  R1147     3.7586751580238342e-01
    z[4,5,6]  R1148     1.6976203769445419e-02
    z[4,5,6]  R1149     -1.0731585323810577e-01
    z[4,5,6]  R1150     -2.7284076809883118e-01
    z[4,5,6]  R1151     -2.2479134798049927e-01
    z[4,5,6]  R1152     1.0838758200407028e-01
    z[4,5,6]  R1153     -3.8693693280220032e-01
    z[4,5,6]  R1154     -2.7461314201354980e-01
    z[4,5,6]  R1155     2.4959123134613037e-01
    z[4,5,6]  R1156     -3.4637156128883362e-01
    z[4,5,6]  R1157     -7.7166631817817688e-02
    z[4,5,6]  R1158     0.0599825382232666
    z[4,5,6]  R1159     2.8436020016670227e-01
    z[4,5,6]  R1160     -1.1480133235454559e-01
    z[4,5,6]  R1161     -1.4487040042877197e-01
    z[4,5,6]  R1162     1.1831221729516983e-01
    z[4,5,6]  R1163     -2.2547294199466705e-01
    z[4,5,6]  R1164     1.3696002960205078e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1165     -1
    z[5,4,0]  R1166     1
    z[5,4,0]  R1179     1.4367249608039856e-01
    z[5,4,0]  R1180     9.6836224198341370e-02
    z[5,4,0]  R1181     -9.1374427080154419e-02
    z[5,4,0]  R1182     -1.2036441266536713e-01
    z[5,4,0]  R1183     7.7137142419815063e-02
    z[5,4,0]  R1184     -1.8016014993190765e-01
    z[5,4,0]  R1185     -1.3040290772914886e-01
    z[5,4,0]  R1186     3.2169858459383249e-03
    z[5,4,0]  R1187     4.2814472317695618e-01
    z[5,4,0]  R1188     -1.3561758399009705e-01
    z[5,4,0]  R1189     -1.9953235983848572e-01
    z[5,4,0]  R1190     -1.5464584529399872e-01
    z[5,4,0]  R1191     -7.9916212707757950e-03
    z[5,4,0]  R1192     4.1941270232200623e-02
    z[5,4,0]  R1193     -5.7299101352691650e-01
    z[5,4,0]  R1194     -6.6932633519172668e-02
    z[5,4,0]  R1195     2.0704032853245735e-02
    z[5,4,0]  R1196     -4.8795364797115326e-02
    z[5,4,0]  R1197     -2.0290263928472996e-03
    z[5,4,0]  R1198     2.0917126536369324e-01
    z[5,4,0]  R1199     -1.2074116617441177e-01
    z[5,4,0]  R1200     -1.7033240199089050e-01
    z[5,4,0]  R1201     -1.2313283979892731e-01
    z[5,4,0]  R1202     -3.0875965952873230e-02
    z[5,4,0]  R1203     8.8018581271171570e-02
    z[5,4,0]  R1204     3.3534996211528778e-02
    z[5,4,0]  R1205     3.1025785207748413e-01
    z[5,4,0]  R1206     -5.4954189807176590e-02
    z[5,4,0]  R1207     -2.0206263661384583e-01
    z[5,4,0]  R1208     3.8460159301757812e-01
    z[5,4,0]  R1209     -8.2343824207782745e-02
    z[5,4,0]  R1210     -1.0563597828149796e-01
    z[5,4,0]  R1211     -1.5603317320346832e-01
    z[5,4,0]  R1212     -7.3864096403121948e-01
    z[5,4,0]  R1213     -6.9027908146381378e-02
    z[5,4,0]  R1214     -4.0976423770189285e-02
    z[5,4,0]  R1215     -3.2495218515396118e-01
    z[5,4,0]  R1216     -3.3865779638290405e-01
    z[5,4,0]  R1217     -1.5645249187946320e-01
    z[5,4,0]  R1218     -8.5378557443618774e-02
    z[5,4,0]  R1219     9.2741541564464569e-02
    z[5,4,0]  R1220     -1.2282628566026688e-01
    z[5,4,0]  R1221     -6.9633579254150391e-01
    z[5,4,0]  R1222     3.3384156227111816e-01
    z[5,4,0]  R1223     -1.2994219362735748e-01
    z[5,4,0]  R1224     9.7509376704692841e-02
    z[5,4,0]  R1225     -3.1440767645835876e-01
    z[5,4,0]  R1226     -7.5987897813320160e-02
    z[5,4,0]  R1227     -2.1686081588268280e-01
    z[5,4,0]  R1228     5.2467696368694305e-02
    z[5,4,0]  R1229     -7.6238703727722168e-01
    z[5,4,0]  R1230     -1.4882014691829681e-01
    z[5,4,0]  R1231     4.7597482800483704e-01
    z[5,4,0]  R1232     8.9614480733871460e-01
    z[5,4,0]  R1233     9.1532504558563232e-01
    z[5,4,0]  R1234     8.8304710388183594e-01
    z[5,4,0]  R1235     8.7570029497146606e-01
    z[5,4,0]  R1236     8.6964684724807739e-01
    z[5,4,0]  R1237     1.8276479095220566e-02
    z[5,4,0]  R1238     1.1998645216226578e-01
    z[5,4,0]  R1239     6.4301635138690472e-03
    z[5,4,0]  R1240     3.2188287377357483e-01
    z[5,4,0]  R1241     2.7721645310521126e-02
    z[5,4,0]  R1242     5.9904661029577255e-02
    z[5,4,0]  R1243     0.858936071395874
    z[5,4,0]  R1244     8.3661407232284546e-01
    z[5,4,0]  R1245     0.852433979511261
    z[5,4,0]  R1246     8.1905382871627808e-01
    z[5,4,0]  R1247     -1.7209856212139130e-01
    z[5,4,0]  R1248     -1.0541781038045883e-01
    z[5,4,0]  R1249     -2.4894516170024872e-01
    z[5,4,0]  R1250     -3.6012226343154907e-01
    z[5,4,0]  R1251     5.3793575614690781e-02
    z[5,4,0]  R1252     -7.2886824607849121e-01
    z[5,4,0]  R1253     3.1899258494377136e-01
    z[5,4,0]  R1254     -2.4710580706596375e-02
    z[5,4,0]  R1255     5.6930180639028549e-02
    z[5,4,0]  R1256     2.9730057716369629e-01
    z[5,4,0]  R1257     -7.6461881399154663e-01
    z[5,4,0]  R1258     3.1305238604545593e-02
    z[5,4,0]  R1259     -2.4371033906936646e-01
    z[5,4,0]  R1260     -6.6487453877925873e-02
    z[5,4,0]  R1261     1.7442536354064941e-01
    z[5,4,0]  R1262     -2.1793624758720398e-01
    z[5,4,0]  R1263     1.1814450845122337e-02
    z[5,4,0]  R1264     -1.3853733241558075e-01
    z[5,4,0]  R1265     -2.6652544736862183e-01
    z[5,4,0]  R1266     -2.8162550926208496e-01
    z[5,4,0]  R1267     -5.9845107793807983e-01
    z[5,4,0]  R1268     2.3119193315505981e-01
    z[5,4,0]  R1269     1.5551097691059113e-01
    z[5,4,0]  R1270     2.6353845000267029e-01
    z[5,4,0]  R1271     7.6957635581493378e-02
    z[5,4,0]  R1272     -5.1124148070812225e-02
    z[5,4,0]  R1273     2.0614919066429138e-01
    z[5,4,0]  R1274     -4.9619201570749283e-02
    z[5,4,0]  R1275     -1.0518789291381836e-01
    z[5,4,0]  R1276     -7.7299750410020351e-03
    z[5,4,0]  R1277     -7.8285849094390869e-01
    z[5,4,0]  R1278     -4.2401376366615295e-01
    z[5,4,0]  R1279     -2.3066484928131104e-01
    z[5,4,0]  R1280     -3.7945550680160522e-01
    z[5,4,0]  R1281     -1.3252480328083038e-01
    z[5,4,0]  R1282     -2.2853079438209534e-01
    z[5,4,0]  R1283     -3.3826592564582825e-01
    z[5,4,0]  R1284     3.2707676291465759e-01
    z[5,4,0]  R1285     -8.2660518586635590e-02
    z[5,4,0]  R1286     -1.9516560435295105e-01
    z[5,4,0]  R1287     -3.0983048677444458e-01
    z[5,4,0]  R1288     -5.8509427309036255e-01
    z[5,4,0]  R1289     -3.4305313229560852e-01
    z[5,4,0]  R1290     3.4879993181675673e-03
    z[5,4,0]  R1291     2.7744683623313904e-01
    z[5,4,0]  R1292     -7.3124817572534084e-03
    z[5,4,0]  R1293     -1.5040916204452515e-01
    z[5,4,0]  R1294     -8.9968644082546234e-02
    z[5,4,0]  R1295     5.3375765681266785e-02
    z[5,4,0]  R1296     -5.7130229473114014e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1167     -1
    z[5,4,1]  R1168     1
    z[5,4,1]  R1179     -1.7200057208538055e-01
    z[5,4,1]  R1180     4.0754759684205055e-03
    z[5,4,1]  R1181     1.0573843028396368e-03
    z[5,4,1]  R1182     -1.6342546045780182e-01
    z[5,4,1]  R1183     0.474097341299057
    z[5,4,1]  R1184     -7.5184464454650879e-02
    z[5,4,1]  R1185     6.0491126775741577e-01
    z[5,4,1]  R1186     1.5866902470588684e-01
    z[5,4,1]  R1187     -7.7959084510803223e-01
    z[5,4,1]  R1188     -8.6356341838836670e-01
    z[5,4,1]  R1189     -7.9793006181716919e-01
    z[5,4,1]  R1190     -0.864427924156189
    z[5,4,1]  R1191     -8.0960261821746826e-01
    z[5,4,1]  R1192     -9.0707629919052124e-01
    z[5,4,1]  R1193     2.5930488109588623e-01
    z[5,4,1]  R1194     2.3826844990253448e-01
    z[5,4,1]  R1195     -8.6427938938140869e-01
    z[5,4,1]  R1196     -8.6776155233383179e-01
    z[5,4,1]  R1197     -0.931408703327179
    z[5,4,1]  R1198     -8.4530013799667358e-01
    z[5,4,1]  R1199     -8.3708190917968750e-01
    z[5,4,1]  R1200     -8.6308616399765015e-01
    z[5,4,1]  R1201     -0.0401635617017746
    z[5,4,1]  R1202     -1.2885574996471405e-01
    z[5,4,1]  R1203     2.1168453991413116e-01
    z[5,4,1]  R1204     4.1205409914255142e-02
    z[5,4,1]  R1205     -1.0249330103397369e-01
    z[5,4,1]  R1206     1.6594892740249634e-01
    z[5,4,1]  R1207     -6.9532161951065063e-01
    z[5,4,1]  R1208     2.3633906245231628e-01
    z[5,4,1]  R1209     4.0792447328567505e-01
    z[5,4,1]  R1210     2.8059142827987671e-01
    z[5,4,1]  R1211     4.2804378271102905e-01
    z[5,4,1]  R1212     -6.7567661404609680e-02
    z[5,4,1]  R1213     1.0781825333833694e-01
    z[5,4,1]  R1214     1.6846668720245361e-01
    z[5,4,1]  R1215     0.685014009475708
    z[5,4,1]  R1216     5.6257504224777222e-01
    z[5,4,1]  R1217     -7.9387080669403076e-01
    z[5,4,1]  R1218     -7.6158392429351807e-01
    z[5,4,1]  R1219     -6.4522135257720947e-01
    z[5,4,1]  R1220     2.4340584874153137e-01
    z[5,4,1]  R1221     5.0495165586471558e-01
    z[5,4,1]  R1222     -3.1800780445337296e-02
    z[5,4,1]  R1223     -4.0371179580688477e-02
    z[5,4,1]  R1224     -2.3372535407543182e-01
    z[5,4,1]  R1225     7.0987462997436523e-01
    z[5,4,1]  R1226     2.3280377686023712e-01
    z[5,4,1]  R1227     -8.0311816930770874e-01
    z[5,4,1]  R1228     -3.8023620843887329e-01
    z[5,4,1]  R1229     2.4064344167709351e-01
    z[5,4,1]  R1230     2.9533258080482483e-01
    z[5,4,1]  R1231     2.7576693892478943e-01
    z[5,4,1]  R1232     2.8850775957107544e-01
    z[5,4,1]  R1233     2.5768095254898071e-01
    z[5,4,1]  R1234     2.7619701623916626e-01
    z[5,4,1]  R1235     1.7701391875743866e-01
    z[5,4,1]  R1236     1.6462750732898712e-01
    z[5,4,1]  R1237     8.8279730081558228e-01
    z[5,4,1]  R1238     8.9820599555969238e-01
    z[5,4,1]  R1239     5.1838332414627075e-01
    z[5,4,1]  R1240     5.8870565891265869e-01
    z[5,4,1]  R1241     5.4523938894271851e-01
    z[5,4,1]  R1242     5.5945807695388794e-01
    z[5,4,1]  R1243     -1.0856576263904572e-01
    z[5,4,1]  R1244     1.3602754473686218e-01
    z[5,4,1]  R1245     -2.1678301692008972e-01
    z[5,4,1]  R1246     5.0889525562524796e-02
    z[5,4,1]  R1247     1.0282338410615921e-01
    z[5,4,1]  R1248     3.7497210502624512e-01
    z[5,4,1]  R1249     0.122503861784935
    z[5,4,1]  R1250     4.6388339251279831e-02
    z[5,4,1]  R1251     6.4730048179626465e-02
    z[5,4,1]  R1252     4.2699292302131653e-01
    z[5,4,1]  R1253     -8.9471697807312012e-01
    z[5,4,1]  R1254     -8.8038235902786255e-01
    z[5,4,1]  R1255     -8.2952016592025757e-01
    z[5,4,1]  R1256     3.6464259028434753e-02
    z[5,4,1]  R1257     4.4890657067298889e-01
    z[5,4,1]  R1258     -9.4527572393417358e-01
    z[5,4,1]  R1259     -9.1798186302185059e-01
    z[5,4,1]  R1260     -8.9208728075027466e-01
    z[5,4,1]  R1261     -8.6514890193939209e-01
    z[5,4,1]  R1262     -8.3336752653121948e-01
    z[5,4,1]  R1263     -8.1203687191009521e-01
    z[5,4,1]  R1264     -5.5051195621490479e-01
    z[5,4,1]  R1265     -9.1903531551361084e-01
    z[5,4,1]  R1266     -8.1354314088821411e-01
    z[5,4,1]  R1267     -3.8258321583271027e-02
    z[5,4,1]  R1268     -9.3632888793945312e-01
    z[5,4,1]  R1269     -9.2413526773452759e-01
    z[5,4,1]  R1270     -8.6651885509490967e-01
    z[5,4,1]  R1271     -8.0911898612976074e-01
    z[5,4,1]  R1272     -8.6442202329635620e-01
    z[5,4,1]  R1273     -8.4205752611160278e-01
    z[5,4,1]  R1274     -0.888372004032135
    z[5,4,1]  R1275     -8.2396632432937622e-01
    z[5,4,1]  R1276     -9.3639492988586426e-01
    z[5,4,1]  R1277     -2.1814670413732529e-02
    z[5,4,1]  R1278     7.0344597101211548e-02
    z[5,4,1]  R1279     4.2119896411895752e-01
    z[5,4,1]  R1280     2.9502192139625549e-01
    z[5,4,1]  R1281     -0.842427670955658
    z[5,4,1]  R1282     -8.9654362201690674e-01
    z[5,4,1]  R1283     -8.8176757097244263e-01
    z[5,4,1]  R1284     -0.814807116985321
    z[5,4,1]  R1285     -7.9867547750473022e-01
    z[5,4,1]  R1286     -7.8840601444244385e-01
    z[5,4,1]  R1287     2.8742921352386475e-01
    z[5,4,1]  R1288     2.4879592657089233e-01
    z[5,4,1]  R1289     1.9900441169738770e-01
    z[5,4,1]  R1290     -8.9389944076538086e-01
    z[5,4,1]  R1291     -8.6115521192550659e-01
    z[5,4,1]  R1292     -8.2163053750991821e-01
    z[5,4,1]  R1293     -3.8869503140449524e-01
    z[5,4,1]  R1294     -5.9901064634323120e-01
    z[5,4,1]  R1295     -4.6669882535934448e-01
    z[5,4,1]  R1296     -7.2935229539871216e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1169     -1
    z[5,4,2]  R1170     1
    z[5,4,2]  R1179     8.8556744158267975e-03
    z[5,4,2]  R1180     -4.8384219408035278e-01
    z[5,4,2]  R1181     -5.6739443540573120e-01
    z[5,4,2]  R1182     -8.4151841700077057e-02
    z[5,4,2]  R1183     -1.5293259918689728e-01
    z[5,4,2]  R1184     -3.2047325372695923e-01
    z[5,4,2]  R1185     -2.7669697999954224e-01
    z[5,4,2]  R1186     0.551289439201355
    z[5,4,2]  R1187     2.4917015433311462e-01
    z[5,4,2]  R1188     -1.0660753399133682e-01
    z[5,4,2]  R1189     -2.7323761582374573e-01
    z[5,4,2]  R1190     -5.8929339051246643e-02
    z[5,4,2]  R1191     1.5184928476810455e-01
    z[5,4,2]  R1192     2.3951035737991333e-01
    z[5,4,2]  R1193     6.9373279809951782e-01
    z[5,4,2]  R1194     8.3153164386749268e-01
    z[5,4,2]  R1195     0.327529639005661
    z[5,4,2]  R1196     -5.3468596190214157e-02
    z[5,4,2]  R1197     2.0595720410346985e-01
    z[5,4,2]  R1198     -1.2311632931232452e-01
    z[5,4,2]  R1199     -2.1409240365028381e-01
    z[5,4,2]  R1200     -2.5118723511695862e-01
    z[5,4,2]  R1201     9.2495280504226685e-01
    z[5,4,2]  R1202     -4.8624154925346375e-01
    z[5,4,2]  R1203     -5.2616435289382935e-01
    z[5,4,2]  R1204     -1.1939374357461929e-01
    z[5,4,2]  R1205     -2.4027542769908905e-01
    z[5,4,2]  R1206     -6.2671370804309845e-02
    z[5,4,2]  R1207     -2.0683540403842926e-01
    z[5,4,2]  R1208     -3.0107992887496948e-01
    z[5,4,2]  R1209     -3.0763953924179077e-01
    z[5,4,2]  R1210     -1.1845391988754272e-01
    z[5,4,2]  R1211     1.1871451511979103e-02
    z[5,4,2]  R1212     5.6594204902648926e-01
    z[5,4,2]  R1213     -5.9812232851982117e-02
    z[5,4,2]  R1214     1.8718820810317993e-01
    z[5,4,2]  R1215     2.4609220027923584e-01
    z[5,4,2]  R1216     5.6773293018341064e-01
    z[5,4,2]  R1217     3.8105454295873642e-02
    z[5,4,2]  R1218     3.9975973963737488e-01
    z[5,4,2]  R1219     3.0826881527900696e-01
    z[5,4,2]  R1220     -1.4743112027645111e-01
    z[5,4,2]  R1221     4.1032043099403381e-01
    z[5,4,2]  R1222     -2.8690841794013977e-01
    z[5,4,2]  R1223     -4.8879832029342651e-01
    z[5,4,2]  R1224     7.2914361953735352e-01
    z[5,4,2]  R1225     2.8350222110748291e-01
    z[5,4,2]  R1226     -4.6937850117683411e-01
    z[5,4,2]  R1227     -2.3408372700214386e-01
    z[5,4,2]  R1228     -9.8009787499904633e-02
    z[5,4,2]  R1229     5.1663786172866821e-01
    z[5,4,2]  R1230     9.0008443593978882e-01
    z[5,4,2]  R1231     -4.3937939405441284e-01
    z[5,4,2]  R1232     1.7338788509368896e-01
    z[5,4,2]  R1233     1.9356388598680496e-02
    z[5,4,2]  R1234     2.2289606928825378e-01
    z[5,4,2]  R1235     3.6890214681625366e-01
    z[5,4,2]  R1236     3.0789998173713684e-01
    z[5,4,2]  R1237     6.7431636154651642e-02
    z[5,4,2]  R1238     1.5567451715469360e-01
    z[5,4,2]  R1239     9.1799996793270111e-02
    z[5,4,2]  R1240     -7.2012418508529663e-01
    z[5,4,2]  R1241     -6.9533628225326538e-01
    z[5,4,2]  R1242     -4.1551807522773743e-01
    z[5,4,2]  R1243     -2.8524732589721680e-01
    z[5,4,2]  R1244     -1.3848823308944702e-01
    z[5,4,2]  R1245     -3.6783429980278015e-01
    z[5,4,2]  R1246     -1.7657396197319031e-01
    z[5,4,2]  R1247     8.4021437168121338e-01
    z[5,4,2]  R1248     2.8355118632316589e-01
    z[5,4,2]  R1249     4.9967566132545471e-01
    z[5,4,2]  R1250     4.6472790837287903e-01
    z[5,4,2]  R1251     8.4655404090881348e-01
    z[5,4,2]  R1252     6.6695623099803925e-02
    z[5,4,2]  R1253     -1.8805885314941406e-01
    z[5,4,2]  R1254     -0.0760580450296402
    z[5,4,2]  R1255     -1.6840463876724243e-01
    z[5,4,2]  R1256     6.3653844594955444e-01
    z[5,4,2]  R1257     9.5905712805688381e-04
    z[5,4,2]  R1258     -2.5765869021415710e-01
    z[5,4,2]  R1259     1.9793811440467834e-01
    z[5,4,2]  R1260     8.2529969513416290e-02
    z[5,4,2]  R1261     3.0190202593803406e-01
    z[5,4,2]  R1262     3.1279298663139343e-01
    z[5,4,2]  R1263     -0.0842321366071701
    z[5,4,2]  R1264     -4.0897119045257568e-01
    z[5,4,2]  R1265     -1.3384819030761719e-01
    z[5,4,2]  R1266     -9.7464453428983688e-03
    z[5,4,2]  R1267     2.5798752903938293e-02
    z[5,4,2]  R1268     1.9758033752441406e-01
    z[5,4,2]  R1269     -3.5061892122030258e-02
    z[5,4,2]  R1270     5.4388329386711121e-02
    z[5,4,2]  R1271     -1.8867659568786621e-01
    z[5,4,2]  R1272     7.1011655032634735e-02
    z[5,4,2]  R1273     2.8882932662963867e-01
    z[5,4,2]  R1274     -2.2510716319084167e-01
    z[5,4,2]  R1275     1.8280208110809326e-01
    z[5,4,2]  R1276     1.8073084950447083e-01
    z[5,4,2]  R1277     3.6547788977622986e-01
    z[5,4,2]  R1278     7.0659118890762329e-01
    z[5,4,2]  R1279     -8.2825394347310066e-03
    z[5,4,2]  R1280     4.5111495256423950e-01
    z[5,4,2]  R1281     8.0974452197551727e-02
    z[5,4,2]  R1282     -2.9770871996879578e-01
    z[5,4,2]  R1283     8.1429913640022278e-02
    z[5,4,2]  R1284     9.3797542154788971e-02
    z[5,4,2]  R1285     -4.2805038392543793e-02
    z[5,4,2]  R1286     3.6200657486915588e-02
    z[5,4,2]  R1287     4.8477512598037720e-01
    z[5,4,2]  R1288     -7.6532892882823944e-02
    z[5,4,2]  R1289     5.3832525014877319e-01
    z[5,4,2]  R1290     3.4502517431974411e-02
    z[5,4,2]  R1291     1.4597199857234955e-01
    z[5,4,2]  R1292     -2.9339563846588135e-01
    z[5,4,2]  R1293     -7.7600318193435669e-01
    z[5,4,2]  R1294     -6.7623686790466309e-01
    z[5,4,2]  R1295     -7.2706836462020874e-01
    z[5,4,2]  R1296     -2.1004046499729156e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1171     -1
    z[5,4,3]  R1172     1
    z[5,4,3]  R1179     7.3608434200286865e-01
    z[5,4,3]  R1180     5.4030829668045044e-01
    z[5,4,3]  R1181     6.2292045354843140e-01
    z[5,4,3]  R1182     6.6875702142715454e-01
    z[5,4,3]  R1183     7.5043952465057373e-01
    z[5,4,3]  R1184     7.2219270467758179e-01
    z[5,4,3]  R1185     2.1046654880046844e-01
    z[5,4,3]  R1186     -1.9717127084732056e-01
    z[5,4,3]  R1187     -3.0319371819496155e-01
    z[5,4,3]  R1188     -1.6102933883666992e-01
    z[5,4,3]  R1189     -3.9764145016670227e-01
    z[5,4,3]  R1190     -0.382107138633728
    z[5,4,3]  R1191     -3.4391874074935913e-01
    z[5,4,3]  R1192     2.3867176845669746e-02
    z[5,4,3]  R1193     8.9123375713825226e-02
    z[5,4,3]  R1194     2.2022317349910736e-01
    z[5,4,3]  R1195     -3.3727136254310608e-01
    z[5,4,3]  R1196     -0.384029358625412
    z[5,4,3]  R1197     2.9151519760489464e-02
    z[5,4,3]  R1198     -7.5818479061126709e-02
    z[5,4,3]  R1199     -2.0075872540473938e-01
    z[5,4,3]  R1200     -2.5415161252021790e-01
    z[5,4,3]  R1201     -6.9063976407051086e-03
    z[5,4,3]  R1202     -4.1616834700107574e-02
    z[5,4,3]  R1203     -3.2481840252876282e-01
    z[5,4,3]  R1204     -3.7099415063858032e-01
    z[5,4,3]  R1205     -3.2631272077560425e-01
    z[5,4,3]  R1206     -3.7785044312477112e-01
    z[5,4,3]  R1207     -4.1483816504478455e-01
    z[5,4,3]  R1208     -4.5609995722770691e-01
    z[5,4,3]  R1209     -5.1416993141174316e-01
    z[5,4,3]  R1210     -4.7320303320884705e-01
    z[5,4,3]  R1211     -4.4991636276245117e-01
    z[5,4,3]  R1212     -5.5748138576745987e-02
    z[5,4,3]  R1213     -3.8931149244308472e-01
    z[5,4,3]  R1214     -4.6299010515213013e-01
    z[5,4,3]  R1215     -3.9735451340675354e-01
    z[5,4,3]  R1216     -3.5702151060104370e-01
    z[5,4,3]  R1217     -3.7627723813056946e-01
    z[5,4,3]  R1218     -0.240528866648674
    z[5,4,3]  R1219     -5.2581030130386353e-01
    z[5,4,3]  R1220     -5.1531064510345459e-01
    z[5,4,3]  R1221     -1.9629509747028351e-01
    z[5,4,3]  R1222     -4.6880120038986206e-01
    z[5,4,3]  R1223     -0.436359167098999
    z[5,4,3]  R1224     5.1680259406566620e-02
    z[5,4,3]  R1225     -2.3948743939399719e-01
    z[5,4,3]  R1226     -0.504715621471405
    z[5,4,3]  R1227     -3.7417319416999817e-01
    z[5,4,3]  R1228     1.2880219519138336e-01
    z[5,4,3]  R1229     -2.4957848712801933e-02
    z[5,4,3]  R1230     1.8037818372249603e-01
    z[5,4,3]  R1231     -4.1164883971214294e-01
    z[5,4,3]  R1232     -2.3377789556980133e-01
    z[5,4,3]  R1233     -1.7172104120254517e-01
    z[5,4,3]  R1234     -2.6337611675262451e-01
    z[5,4,3]  R1235     -8.2218900322914124e-02
    z[5,4,3]  R1236     -1.7680704593658447e-01
    z[5,4,3]  R1237     1.1516990512609482e-01
    z[5,4,3]  R1238     3.2431280612945557e-01
    z[5,4,3]  R1239     -2.0396200940012932e-02
    z[5,4,3]  R1240     1.1635913699865341e-01
    z[5,4,3]  R1241     8.8614434003829956e-02
    z[5,4,3]  R1242     -4.9735743552446365e-02
    z[5,4,3]  R1243     1.7283445596694946e-01
    z[5,4,3]  R1244     3.2775089144706726e-01
    z[5,4,3]  R1245     2.1331556141376495e-01
    z[5,4,3]  R1246     4.2960166931152344e-01
    z[5,4,3]  R1247     -3.4326744079589844e-01
    z[5,4,3]  R1248     -7.0934981107711792e-01
    z[5,4,3]  R1249     -3.1899097561836243e-01
    z[5,4,3]  R1250     -6.1695091426372528e-02
    z[5,4,3]  R1251     1.6761821508407593e-01
    z[5,4,3]  R1252     1.9978480041027069e-01
    z[5,4,3]  R1253     1.8895334005355835e-01
    z[5,4,3]  R1254     -7.9344063997268677e-02
    z[5,4,3]  R1255     5.0925098359584808e-02
    z[5,4,3]  R1256     -1.7422821372747421e-02
    z[5,4,3]  R1257     1.1696402914822102e-02
    z[5,4,3]  R1258     -1.2717632949352264e-01
    z[5,4,3]  R1259     -4.6137967146933079e-03
    z[5,4,3]  R1260     -2.5225919485092163e-01
    z[5,4,3]  R1261     5.6858994066715240e-02
    z[5,4,3]  R1262     -2.6485204696655273e-01
    z[5,4,3]  R1263     -5.9067141264677048e-02
    z[5,4,3]  R1264     0.577458918094635
    z[5,4,3]  R1265     2.4416531622409821e-01
    z[5,4,3]  R1266     4.3209555745124817e-01
    z[5,4,3]  R1267     -5.9953224658966064e-01
    z[5,4,3]  R1268     -7.7092565596103668e-02
    z[5,4,3]  R1269     -1.5031945705413818e-01
    z[5,4,3]  R1270     -1.7512956261634827e-01
    z[5,4,3]  R1271     3.2055267691612244e-01
    z[5,4,3]  R1272     4.5226126909255981e-01
    z[5,4,3]  R1273     2.7695652842521667e-01
    z[5,4,3]  R1274     -4.8354491591453552e-02
    z[5,4,3]  R1275     2.9866832494735718e-01
    z[5,4,3]  R1276     1.8614947795867920e-01
    z[5,4,3]  R1277     -4.7284394502639771e-01
    z[5,4,3]  R1278     1.2677592039108276e-01
    z[5,4,3]  R1279     -1.4143761992454529e-01
    z[5,4,3]  R1280     -4.3483623862266541e-01
    z[5,4,3]  R1281     2.1898582577705383e-01
    z[5,4,3]  R1282     1.0630187392234802e-01
    z[5,4,3]  R1283     2.1172007918357849e-01
    z[5,4,3]  R1284     3.3912602066993713e-01
    z[5,4,3]  R1285     5.2484345436096191e-01
    z[5,4,3]  R1286     3.1216824054718018e-01
    z[5,4,3]  R1287     3.7200883030891418e-01
    z[5,4,3]  R1288     9.9150486290454865e-02
    z[5,4,3]  R1289     1.4972022175788879e-01
    z[5,4,3]  R1290     1.7892074584960938e-01
    z[5,4,3]  R1291     1.5810623764991760e-01
    z[5,4,3]  R1292     2.3697124421596527e-01
    z[5,4,3]  R1293     -1.4373597502708435e-01
    z[5,4,3]  R1294     -2.0813571289181709e-02
    z[5,4,3]  R1295     1.5533900260925293e-01
    z[5,4,3]  R1296     7.3797397315502167e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1173     -1
    z[5,4,4]  R1174     1
    z[5,4,4]  R1179     -3.6362904310226440e-01
    z[5,4,4]  R1180     -4.9960348010063171e-01
    z[5,4,4]  R1181     -5.0354075431823730e-01
    z[5,4,4]  R1182     -4.5779895782470703e-01
    z[5,4,4]  R1183     -4.1896820068359375e-01
    z[5,4,4]  R1184     1.5908795595169067e-01
    z[5,4,4]  R1185     -3.3138684928417206e-02
    z[5,4,4]  R1186     3.5523235797882080e-01
    z[5,4,4]  R1187     0.217244952917099
    z[5,4,4]  R1188     3.2900825142860413e-01
    z[5,4,4]  R1189     2.9175531864166260e-01
    z[5,4,4]  R1190     -2.2416071593761444e-01
    z[5,4,4]  R1191     2.2207362949848175e-01
    z[5,4,4]  R1192     1.4279159903526306e-01
    z[5,4,4]  R1193     2.6071277260780334e-01
    z[5,4,4]  R1194     4.3812528252601624e-01
    z[5,4,4]  R1195     -2.0273329690098763e-02
    z[5,4,4]  R1196     -8.0797486007213593e-02
    z[5,4,4]  R1197     1.7193509638309479e-01
    z[5,4,4]  R1198     3.0143103003501892e-01
    z[5,4,4]  R1199     2.8488751500844955e-02
    z[5,4,4]  R1200     2.5044327974319458e-01
    z[5,4,4]  R1201     2.7663178741931915e-02
    z[5,4,4]  R1202     7.2973388433456421e-01
    z[5,4,4]  R1203     1.9733099639415741e-01
    z[5,4,4]  R1204     7.4615710973739624e-01
    z[5,4,4]  R1205     -1.6516859829425812e-01
    z[5,4,4]  R1206     3.3730453252792358e-01
    z[5,4,4]  R1207     0.0498795211315155
    z[5,4,4]  R1208     3.7845957279205322e-01
    z[5,4,4]  R1209     4.8017796874046326e-01
    z[5,4,4]  R1210     1.8214242160320282e-01
    z[5,4,4]  R1211     2.7879974246025085e-01
    z[5,4,4]  R1212     -2.2715424001216888e-01
    z[5,4,4]  R1213     -2.0099349319934845e-01
    z[5,4,4]  R1214     5.0853151082992554e-01
    z[5,4,4]  R1215     -1.7937676608562469e-01
    z[5,4,4]  R1216     -1.8026949465274811e-01
    z[5,4,4]  R1217     8.8719859719276428e-02
    z[5,4,4]  R1218     1.4271272718906403e-01
    z[5,4,4]  R1219     -1.2888167798519135e-01
    z[5,4,4]  R1220     3.2883301377296448e-01
    z[5,4,4]  R1221     -0.0935700535774231
    z[5,4,4]  R1222     1.5172238647937775e-01
    z[5,4,4]  R1223     4.0937563776969910e-01
    z[5,4,4]  R1224     5.6467449665069580e-01
    z[5,4,4]  R1225     3.2929587364196777e-01
    z[5,4,4]  R1226     -0.0696905255317688
    z[5,4,4]  R1227     -5.3936969488859177e-02
    z[5,4,4]  R1228     7.8755879402160645e-01
    z[5,4,4]  R1229     2.7873307466506958e-01
    z[5,4,4]  R1230     1.9228503108024597e-01
    z[5,4,4]  R1231     3.1026398763060570e-02
    z[5,4,4]  R1232     1.2565727531909943e-01
    z[5,4,4]  R1233     2.1122060716152191e-01
    z[5,4,4]  R1234     -1.0344945639371872e-01
    z[5,4,4]  R1235     5.7111438363790512e-02
    z[5,4,4]  R1236     2.3274549841880798e-01
    z[5,4,4]  R1237     1.9727703928947449e-01
    z[5,4,4]  R1238     -1.5441924333572388e-01
    z[5,4,4]  R1239     -0.753320038318634
    z[5,4,4]  R1240     1.1484218388795853e-01
    z[5,4,4]  R1241     -5.3371128160506487e-04
    z[5,4,4]  R1242     -7.0962566137313843e-01
    z[5,4,4]  R1243     -2.0088282227516174e-01
    z[5,4,4]  R1244     -3.2505291700363159e-01
    z[5,4,4]  R1245     -6.0996998101472855e-02
    z[5,4,4]  R1246     2.0736807957291603e-02
    z[5,4,4]  R1247     3.2866573333740234e-01
    z[5,4,4]  R1248     3.8796129822731018e-01
    z[5,4,4]  R1249     1.7747510969638824e-01
    z[5,4,4]  R1250     5.6861841678619385e-01
    z[5,4,4]  R1251     1.2420850992202759e-01
    z[5,4,4]  R1252     4.2864728718996048e-02
    z[5,4,4]  R1253     -1.3347423076629639e-01
    z[5,4,4]  R1254     4.1570693254470825e-01
    z[5,4,4]  R1255     2.5823217630386353e-01
    z[5,4,4]  R1256     -3.1981033086776733e-01
    z[5,4,4]  R1257     2.4458529055118561e-01
    z[5,4,4]  R1258     -0.0643736943602562
    z[5,4,4]  R1259     -1.4105857908725739e-01
    z[5,4,4]  R1260     2.8672186657786369e-02
    z[5,4,4]  R1261     -3.5256387200206518e-03
    z[5,4,4]  R1262     -9.0861216187477112e-02
    z[5,4,4]  R1263     -1.7767642438411713e-01
    z[5,4,4]  R1264     -3.8526263833045959e-01
    z[5,4,4]  R1265     -2.2214479744434357e-02
    z[5,4,4]  R1266     -1.0918529331684113e-01
    z[5,4,4]  R1267     -3.1989240646362305e-01
    z[5,4,4]  R1268     7.2579570114612579e-02
    z[5,4,4]  R1269     2.8426715731620789e-01
    z[5,4,4]  R1270     -3.4772685170173645e-01
    z[5,4,4]  R1271     1.4275148510932922e-01
    z[5,4,4]  R1272     -1.9971360266208649e-01
    z[5,4,4]  R1273     1.9227384030818939e-01
    z[5,4,4]  R1274     2.8355914354324341e-01
    z[5,4,4]  R1275     3.6364585161209106e-01
    z[5,4,4]  R1276     0.0623299777507782
    z[5,4,4]  R1277     5.4575152695178986e-02
    z[5,4,4]  R1278     -2.1897906064987183e-01
    z[5,4,4]  R1279     -0.252566397190094
    z[5,4,4]  R1280     -5.8801096677780151e-01
    z[5,4,4]  R1281     -1.1910246312618256e-01
    z[5,4,4]  R1282     1.2385033816099167e-01
    z[5,4,4]  R1283     1.8290621042251587e-01
    z[5,4,4]  R1284     3.0379590392112732e-01
    z[5,4,4]  R1285     7.5964882969856262e-02
    z[5,4,4]  R1286     2.0483568310737610e-01
    z[5,4,4]  R1287     4.8887407779693604e-01
    z[5,4,4]  R1288     4.4355848431587219e-01
    z[5,4,4]  R1289     -5.6815481185913086e-01
    z[5,4,4]  R1290     3.8978552818298340e-01
    z[5,4,4]  R1291     2.4475511908531189e-01
    z[5,4,4]  R1292     1.7736183479428291e-02
    z[5,4,4]  R1293     -3.5304382443428040e-01
    z[5,4,4]  R1294     -3.3749529719352722e-01
    z[5,4,4]  R1295     -3.7403953075408936e-01
    z[5,4,4]  R1296     -2.0202626287937164e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1175     -1
    z[5,4,5]  R1176     1
    z[5,4,5]  R1179     -5.0993365049362183e-01
    z[5,4,5]  R1180     -3.1566226482391357e-01
    z[5,4,5]  R1181     5.1966842263936996e-02
    z[5,4,5]  R1182     6.5858006477355957e-02
    z[5,4,5]  R1183     0.0646321102976799
    z[5,4,5]  R1184     2.7212062478065491e-01
    z[5,4,5]  R1185     -4.4912809133529663e-01
    z[5,4,5]  R1186     6.9142395257949829e-01
    z[5,4,5]  R1187     -7.7091202139854431e-02
    z[5,4,5]  R1188     -2.8734761476516724e-01
    z[5,4,5]  R1189     6.4398103859275579e-04
    z[5,4,5]  R1190     -8.3091638982295990e-02
    z[5,4,5]  R1191     -3.5906833410263062e-01
    z[5,4,5]  R1192     1.7532955110073090e-01
    z[5,4,5]  R1193     8.3269372582435608e-02
    z[5,4,5]  R1194     -0.0711384192109108
    z[5,4,5]  R1195     -6.2169115990400314e-02
    z[5,4,5]  R1196     1.5969856083393097e-01
    z[5,4,5]  R1197     1.9097542762756348e-01
    z[5,4,5]  R1198     2.0190049707889557e-01
    z[5,4,5]  R1199     4.2580485343933105e-01
    z[5,4,5]  R1200     1.8876263499259949e-01
    z[5,4,5]  R1201     -2.1215988695621490e-01
    z[5,4,5]  R1202     -3.3713313937187195e-01
    z[5,4,5]  R1203     6.9382983446121216e-01
    z[5,4,5]  R1204     5.3669852018356323e-01
    z[5,4,5]  R1205     8.0368494987487793e-01
    z[5,4,5]  R1206     8.3032655715942383e-01
    z[5,4,5]  R1207     -2.8334662318229675e-01
    z[5,4,5]  R1208     5.9061342477798462e-01
    z[5,4,5]  R1209     4.6428731083869934e-01
    z[5,4,5]  R1210     7.9928082227706909e-01
    z[5,4,5]  R1211     6.3880944252014160e-01
    z[5,4,5]  R1212     -1.2024427205324173e-01
    z[5,4,5]  R1213     8.8297879695892334e-01
    z[5,4,5]  R1214     0.678679347038269
    z[5,4,5]  R1215     2.0962141454219818e-01
    z[5,4,5]  R1216     2.9410168528556824e-01
    z[5,4,5]  R1217     -1.6936337947845459e-01
    z[5,4,5]  R1218     -2.9251632094383240e-01
    z[5,4,5]  R1219     2.1376506984233856e-01
    z[5,4,5]  R1220     7.2798830270767212e-01
    z[5,4,5]  R1221     1.8158622086048126e-01
    z[5,4,5]  R1222     6.9855982065200806e-01
    z[5,4,5]  R1223     5.7795554399490356e-01
    z[5,4,5]  R1224     -2.6634159684181213e-01
    z[5,4,5]  R1225     3.6635585129261017e-02
    z[5,4,5]  R1226     6.2024587392807007e-01
    z[5,4,5]  R1227     -2.1901336312294006e-01
    z[5,4,5]  R1228     -2.9368248581886292e-01
    z[5,4,5]  R1229     -9.8348014056682587e-02
    z[5,4,5]  R1230     -0.0858580619096756
    z[5,4,5]  R1231     5.0305879116058350e-01
    z[5,4,5]  R1232     1.7933454364538193e-03
    z[5,4,5]  R1233     1.7778772860765457e-02
    z[5,4,5]  R1234     1.3922728598117828e-02
    z[5,4,5]  R1235     6.9761417806148529e-02
    z[5,4,5]  R1236     -1.3274255394935608e-01
    z[5,4,5]  R1237     -1.8966224789619446e-01
    z[5,4,5]  R1238     -8.7802886962890625e-02
    z[5,4,5]  R1239     -0.067637138068676
    z[5,4,5]  R1240     -4.5988604426383972e-02
    z[5,4,5]  R1241     -4.5047560706734657e-03
    z[5,4,5]  R1242     -3.2689280807971954e-02
    z[5,4,5]  R1243     -3.1402119994163513e-01
    z[5,4,5]  R1244     -2.1722888946533203e-01
    z[5,4,5]  R1245     1.6671134158968925e-02
    z[5,4,5]  R1246     -2.8326642513275146e-01
    z[5,4,5]  R1247     1.5485012531280518e-01
    z[5,4,5]  R1248     3.1400460004806519e-01
    z[5,4,5]  R1249     1.8866080045700073e-01
    z[5,4,5]  R1250     1.1222336441278458e-01
    z[5,4,5]  R1251     -4.7523528337478638e-01
    z[5,4,5]  R1252     -4.2120289802551270e-01
    z[5,4,5]  R1253     3.0312919989228249e-02
    z[5,4,5]  R1254     -1.0461964458227158e-01
    z[5,4,5]  R1255     -4.2417088150978088e-01
    z[5,4,5]  R1256     -6.0311728715896606e-01
    z[5,4,5]  R1257     -3.6094522476196289e-01
    z[5,4,5]  R1258     -1.3168926537036896e-01
    z[5,4,5]  R1259     6.9820769131183624e-02
    z[5,4,5]  R1260     1.6734541952610016e-01
    z[5,4,5]  R1261     -0.349232941865921
    z[5,4,5]  R1262     -1.2980429828166962e-01
    z[5,4,5]  R1263     -1.8330083787441254e-01
    z[5,4,5]  R1264     -1.6589336097240448e-01
    z[5,4,5]  R1265     6.6312126815319061e-02
    z[5,4,5]  R1266     -3.8353651762008667e-02
    z[5,4,5]  R1267     3.4753882884979248e-01
    z[5,4,5]  R1268     -1.3029731810092926e-01
    z[5,4,5]  R1269     5.8049920946359634e-02
    z[5,4,5]  R1270     0.0403253547847271
    z[5,4,5]  R1271     -2.4391652643680573e-01
    z[5,4,5]  R1272     -2.3386912420392036e-02
    z[5,4,5]  R1273     1.4532741904258728e-01
    z[5,4,5]  R1274     2.7338016033172607e-01
    z[5,4,5]  R1275     3.8393858820199966e-02
    z[5,4,5]  R1276     1.7576953768730164e-01
    z[5,4,5]  R1277     7.1508079767227173e-02
    z[5,4,5]  R1278     -3.5299065709114075e-01
    z[5,4,5]  R1279     8.2775211334228516e-01
    z[5,4,5]  R1280     1.0440965741872787e-01
    z[5,4,5]  R1281     -4.4865331053733826e-01
    z[5,4,5]  R1282     1.5884213149547577e-01
    z[5,4,5]  R1283     4.0458705276250839e-02
    z[5,4,5]  R1284     0.0845780149102211
    z[5,4,5]  R1285     -4.5434813946485519e-02
    z[5,4,5]  R1286     -1.3693729043006897e-01
    z[5,4,5]  R1287     0.0855298712849617
    z[5,4,5]  R1288     6.1912846565246582e-01
    z[5,4,5]  R1289     -1.4781183004379272e-01
    z[5,4,5]  R1290     1.0292392224073410e-01
    z[5,4,5]  R1291     2.4152073264122009e-01
    z[5,4,5]  R1292     2.0462978631258011e-02
    z[5,4,5]  R1293     2.7034100890159607e-01
    z[5,4,5]  R1294     2.2451931238174438e-01
    z[5,4,5]  R1295     2.0600913465023041e-01
    z[5,4,5]  R1296     -2.2528212517499924e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1177     -1
    z[5,4,6]  R1178     1
    z[5,4,6]  R1179     -1.2496767193078995e-01
    z[5,4,6]  R1180     -3.3959320187568665e-01
    z[5,4,6]  R1181     1.5946586430072784e-01
    z[5,4,6]  R1182     5.3904527425765991e-01
    z[5,4,6]  R1183     5.4972756654024124e-02
    z[5,4,6]  R1184     4.8812466859817505e-01
    z[5,4,6]  R1185     0.541669487953186
    z[5,4,6]  R1186     1.6661377251148224e-01
    z[5,4,6]  R1187     4.2185693979263306e-02
    z[5,4,6]  R1188     8.8064707815647125e-02
    z[5,4,6]  R1189     0.0748034194111824
    z[5,4,6]  R1190     1.4905783534049988e-01
    z[5,4,6]  R1191     -1.5778036415576935e-01
    z[5,4,6]  R1192     -2.5766023993492126e-01
    z[5,4,6]  R1193     -2.0082110166549683e-01
    z[5,4,6]  R1194     4.2314846068620682e-02
    z[5,4,6]  R1195     -1.6519361734390259e-01
    z[5,4,6]  R1196     -2.4947854876518250e-01
    z[5,4,6]  R1197     -1.5222434699535370e-01
    z[5,4,6]  R1198     -0.298637717962265
    z[5,4,6]  R1199     -1.2827472388744354e-01
    z[5,4,6]  R1200     -5.2869278006255627e-03
    z[5,4,6]  R1201     2.8611668944358826e-01
    z[5,4,6]  R1202     -3.1322479248046875e-01
    z[5,4,6]  R1203     -2.1153491735458374e-01
    z[5,4,6]  R1204     2.2140184417366982e-02
    z[5,4,6]  R1205     -2.3628962039947510e-01
    z[5,4,6]  R1206     -1.3973458111286163e-01
    z[5,4,6]  R1207     4.2196404933929443e-01
    z[5,4,6]  R1208     -7.4117675423622131e-02
    z[5,4,6]  R1209     -1.4720979332923889e-01
    z[5,4,6]  R1210     1.1466714553534985e-02
    z[5,4,6]  R1211     3.2258301973342896e-01
    z[5,4,6]  R1212     -2.4573981761932373e-01
    z[5,4,6]  R1213     9.1757513582706451e-02
    z[5,4,6]  R1214     -0.036479651927948
    z[5,4,6]  R1215     -3.6137616634368896e-01
    z[5,4,6]  R1216     6.5060378983616829e-03
    z[5,4,6]  R1217     4.0706261992454529e-01
    z[5,4,6]  R1218     2.9850575327873230e-01
    z[5,4,6]  R1219     3.7586751580238342e-01
    z[5,4,6]  R1220     1.6976203769445419e-02
    z[5,4,6]  R1221     -1.0731585323810577e-01
    z[5,4,6]  R1222     -2.7284076809883118e-01
    z[5,4,6]  R1223     -2.2479134798049927e-01
    z[5,4,6]  R1224     1.0838758200407028e-01
    z[5,4,6]  R1225     -3.8693693280220032e-01
    z[5,4,6]  R1226     -2.7461314201354980e-01
    z[5,4,6]  R1227     2.4959123134613037e-01
    z[5,4,6]  R1228     -3.4637156128883362e-01
    z[5,4,6]  R1229     -7.7166631817817688e-02
    z[5,4,6]  R1230     0.0599825382232666
    z[5,4,6]  R1231     2.8436020016670227e-01
    z[5,4,6]  R1232     -1.1480133235454559e-01
    z[5,4,6]  R1233     -1.4487040042877197e-01
    z[5,4,6]  R1234     1.1831221729516983e-01
    z[5,4,6]  R1235     -2.2547294199466705e-01
    z[5,4,6]  R1236     1.3696002960205078e-01
    z[5,4,6]  R1237     3.5725861787796021e-01
    z[5,4,6]  R1238     -1.3364584743976593e-01
    z[5,4,6]  R1239     3.8772195577621460e-01
    z[5,4,6]  R1240     -4.8938225954771042e-02
    z[5,4,6]  R1241     -4.5889008045196533e-01
    z[5,4,6]  R1242     6.0432165861129761e-02
    z[5,4,6]  R1243     -1.5530244447290897e-02
    z[5,4,6]  R1244     4.6107780188322067e-02
    z[5,4,6]  R1245     -2.0385617017745972e-01
    z[5,4,6]  R1246     1.7365282773971558e-01
    z[5,4,6]  R1247     -6.3380233943462372e-02
    z[5,4,6]  R1248     -1.2486694753170013e-01
    z[5,4,6]  R1249     -7.1028012037277222e-01
    z[5,4,6]  R1250     -5.5898189544677734e-01
    z[5,4,6]  R1251     -8.3008259534835815e-02
    z[5,4,6]  R1252     -2.5063201785087585e-01
    z[5,4,6]  R1253     -0.0890025720000267
    z[5,4,6]  R1254     -1.6875582933425903e-01
    z[5,4,6]  R1255     1.7634356021881104e-01
    z[5,4,6]  R1256     1.9689792394638062e-01
    z[5,4,6]  R1257     -1.5362252295017242e-01
    z[5,4,6]  R1258     3.7762913852930069e-02
    z[5,4,6]  R1259     -1.8423174321651459e-01
    z[5,4,6]  R1260     3.1699728965759277e-01
    z[5,4,6]  R1261     -0.0688420757651329
    z[5,4,6]  R1262     2.5477710366249084e-01
    z[5,4,6]  R1263     -5.1449424028396606e-01
    z[5,4,6]  R1264     3.2861515879631042e-02
    z[5,4,6]  R1265     -4.3765522539615631e-02
    z[5,4,6]  R1266     -2.4215854704380035e-01
    z[5,4,6]  R1267     2.3911017179489136e-01
    z[5,4,6]  R1268     5.1108323037624359e-02
    z[5,4,6]  R1269     -1.1741942912340164e-01
    z[5,4,6]  R1270     -1.5337510406970978e-01
    z[5,4,6]  R1271     -3.4810605645179749e-01
    z[5,4,6]  R1272     1.2059990316629410e-02
    z[5,4,6]  R1273     -1.7385342717170715e-01
    z[5,4,6]  R1274     -1.3387300074100494e-02
    z[5,4,6]  R1275     -2.3169608414173126e-01
    z[5,4,6]  R1276     -1.4494709670543671e-01
    z[5,4,6]  R1277     1.4631895720958710e-01
    z[5,4,6]  R1278     3.5688430070877075e-01
    z[5,4,6]  R1279     1.8671859055757523e-02
    z[5,4,6]  R1280     -1.4046387374401093e-01
    z[5,4,6]  R1281     -5.2591826766729355e-02
    z[5,4,6]  R1282     -5.9016954153776169e-02
    z[5,4,6]  R1283     -1.4667728543281555e-01
    z[5,4,6]  R1284     7.6553061604499817e-02
    z[5,4,6]  R1285     -2.6487118005752563e-01
    z[5,4,6]  R1286     4.2527332901954651e-01
    z[5,4,6]  R1287     -4.4908666610717773e-01
    z[5,4,6]  R1288     3.6136223934590816e-03
    z[5,4,6]  R1289     -4.3110698461532593e-01
    z[5,4,6]  R1290     7.2128519415855408e-02
    z[5,4,6]  R1291     -1.2996993958950043e-01
    z[5,4,6]  R1292     4.2649745941162109e-01
    z[5,4,6]  R1293     -7.5684264302253723e-02
    z[5,4,6]  R1294     1.0512106865644455e-01
    z[5,4,6]  R1295     -2.1033169329166412e-01
    z[5,4,6]  R1296     0.22533018887043
    z[4,6,0]  R38       -1
    z[4,6,0]  R56       1
    z[4,6,0]  R1297     -1
    z[4,6,0]  R1298     1
    z[4,6,0]  R1311     1.8276479095220566e-02
    z[4,6,0]  R1312     1.1998645216226578e-01
    z[4,6,0]  R1313     6.4301635138690472e-03
    z[4,6,0]  R1314     3.2188287377357483e-01
    z[4,6,0]  R1315     2.7721645310521126e-02
    z[4,6,0]  R1316     5.9904661029577255e-02
    z[4,6,0]  R1317     0.858936071395874
    z[4,6,0]  R1318     8.3661407232284546e-01
    z[4,6,0]  R1319     0.852433979511261
    z[4,6,0]  R1320     8.1905382871627808e-01
    z[4,6,0]  R1321     -1.7209856212139130e-01
    z[4,6,0]  R1322     -1.0541781038045883e-01
    z[4,6,0]  R1323     -2.4894516170024872e-01
    z[4,6,0]  R1324     -3.6012226343154907e-01
    z[4,6,0]  R1325     5.3793575614690781e-02
    z[4,6,0]  R1326     -7.2886824607849121e-01
    z[4,6,0]  R1327     3.1899258494377136e-01
    z[4,6,0]  R1328     -2.4710580706596375e-02
    z[4,6,0]  R1329     5.6930180639028549e-02
    z[4,6,0]  R1330     2.9730057716369629e-01
    z[4,6,0]  R1331     -7.6461881399154663e-01
    z[4,6,0]  R1332     3.1305238604545593e-02
    z[4,6,0]  R1333     -2.4371033906936646e-01
    z[4,6,0]  R1334     -6.6487453877925873e-02
    z[4,6,0]  R1335     1.7442536354064941e-01
    z[4,6,0]  R1336     -2.1793624758720398e-01
    z[4,6,0]  R1337     1.1814450845122337e-02
    z[4,6,0]  R1338     -1.3853733241558075e-01
    z[4,6,0]  R1339     -2.6652544736862183e-01
    z[4,6,0]  R1340     -2.8162550926208496e-01
    z[4,6,0]  R1341     -5.9845107793807983e-01
    z[4,6,0]  R1342     2.3119193315505981e-01
    z[4,6,0]  R1343     1.5551097691059113e-01
    z[4,6,0]  R1344     2.6353845000267029e-01
    z[4,6,0]  R1345     7.6957635581493378e-02
    z[4,6,0]  R1346     -5.1124148070812225e-02
    z[4,6,0]  R1347     2.0614919066429138e-01
    z[4,6,0]  R1348     -4.9619201570749283e-02
    z[4,6,0]  R1349     -1.0518789291381836e-01
    z[4,6,0]  R1350     -7.7299750410020351e-03
    z[4,6,0]  R1351     -7.8285849094390869e-01
    z[4,6,0]  R1352     -4.2401376366615295e-01
    z[4,6,0]  R1353     -2.3066484928131104e-01
    z[4,6,0]  R1354     -3.7945550680160522e-01
    z[4,6,0]  R1355     -1.3252480328083038e-01
    z[4,6,0]  R1356     -2.2853079438209534e-01
    z[4,6,0]  R1357     -3.3826592564582825e-01
    z[4,6,0]  R1358     3.2707676291465759e-01
    z[4,6,0]  R1359     -8.2660518586635590e-02
    z[4,6,0]  R1360     -1.9516560435295105e-01
    z[4,6,0]  R1361     -3.0983048677444458e-01
    z[4,6,0]  R1362     -5.8509427309036255e-01
    z[4,6,0]  R1363     -3.4305313229560852e-01
    z[4,6,0]  R1364     3.4879993181675673e-03
    z[4,6,0]  R1365     2.7744683623313904e-01
    z[4,6,0]  R1366     -7.3124817572534084e-03
    z[4,6,0]  R1367     -1.5040916204452515e-01
    z[4,6,0]  R1368     -8.9968644082546234e-02
    z[4,6,0]  R1369     5.3375765681266785e-02
    z[4,6,0]  R1370     -5.7130229473114014e-01
    z[4,6,0]  R1371     -3.4049317240715027e-01
    z[4,6,0]  R1372     -6.3429397344589233e-01
    z[4,6,0]  R1373     -3.6248835921287537e-01
    z[4,6,0]  R1374     -3.5702109336853027e-01
    z[4,6,0]  R1375     -6.6193765401840210e-01
    z[4,6,0]  R1376     -5.0425916910171509e-01
    z[4,6,0]  R1377     -7.4791139364242554e-01
    z[4,6,0]  R1378     -4.9772980809211731e-01
    z[4,6,0]  R1379     3.8281381130218506e-02
    z[4,6,0]  R1380     2.4762129783630371e-01
    z[4,6,0]  R1381     3.6441591382026672e-01
    z[4,6,0]  R1382     4.7362810373306274e-01
    z[4,6,0]  R1383     1.6266094148159027e-01
    z[4,6,0]  R1384     5.5636501312255859e-01
    z[4,6,0]  R1385     6.0811895132064819e-01
    z[4,6,0]  R1386     -4.3223667144775391e-01
    z[4,6,0]  R1387     -8.9919343590736389e-02
    z[4,6,0]  R1388     1.3340255618095398e-01
    z[4,6,0]  R1389     -1.4150561392307281e-01
    z[4,6,0]  R1390     -2.0386894047260284e-01
    z[4,6,0]  R1391     -1.4164708554744720e-01
    z[4,6,0]  R1392     2.2895674407482147e-01
    z[4,6,0]  R1393     5.8498895168304443e-01
    z[4,6,0]  R1394     7.5233328342437744e-01
    z[4,6,0]  R1395     -2.8807312250137329e-01
    z[4,6,0]  R1396     -1.7447084188461304e-01
    z[4,6,0]  R1397     6.2511068582534790e-01
    z[4,6,0]  R1398     -3.0400281772017479e-02
    z[4,6,0]  R1399     -2.3215585947036743e-01
    z[4,6,0]  R1400     -2.9119861125946045e-01
    z[4,6,0]  R1401     1.1829664558172226e-01
    z[4,6,0]  R1402     -2.2391916811466217e-01
    z[4,6,0]  R1403     -1.9385483860969543e-01
    z[4,6,0]  R1404     1.2414071708917618e-01
    z[4,6,0]  R1405     -8.9991658926010132e-02
    z[4,6,0]  R1406     -1.2856583297252655e-01
    z[4,6,0]  R1407     1.6626198589801788e-01
    z[4,6,0]  R1408     3.9438480138778687e-01
    z[4,6,0]  R1409     2.3051121830940247e-01
    z[4,6,0]  R1410     4.7068125009536743e-01
    z[4,6,1]  R39       -1
    z[4,6,1]  R57       1
    z[4,6,1]  R1299     -1
    z[4,6,1]  R1300     1
    z[4,6,1]  R1311     8.8279730081558228e-01
    z[4,6,1]  R1312     8.9820599555969238e-01
    z[4,6,1]  R1313     5.1838332414627075e-01
    z[4,6,1]  R1314     5.8870565891265869e-01
    z[4,6,1]  R1315     5.4523938894271851e-01
    z[4,6,1]  R1316     5.5945807695388794e-01
    z[4,6,1]  R1317     -1.0856576263904572e-01
    z[4,6,1]  R1318     1.3602754473686218e-01
    z[4,6,1]  R1319     -2.1678301692008972e-01
    z[4,6,1]  R1320     5.0889525562524796e-02
    z[4,6,1]  R1321     1.0282338410615921e-01
    z[4,6,1]  R1322     3.7497210502624512e-01
    z[4,6,1]  R1323     0.122503861784935
    z[4,6,1]  R1324     4.6388339251279831e-02
    z[4,6,1]  R1325     6.4730048179626465e-02
    z[4,6,1]  R1326     4.2699292302131653e-01
    z[4,6,1]  R1327     -8.9471697807312012e-01
    z[4,6,1]  R1328     -8.8038235902786255e-01
    z[4,6,1]  R1329     -8.2952016592025757e-01
    z[4,6,1]  R1330     3.6464259028434753e-02
    z[4,6,1]  R1331     4.4890657067298889e-01
    z[4,6,1]  R1332     -9.4527572393417358e-01
    z[4,6,1]  R1333     -9.1798186302185059e-01
    z[4,6,1]  R1334     -8.9208728075027466e-01
    z[4,6,1]  R1335     -8.6514890193939209e-01
    z[4,6,1]  R1336     -8.3336752653121948e-01
    z[4,6,1]  R1337     -8.1203687191009521e-01
    z[4,6,1]  R1338     -5.5051195621490479e-01
    z[4,6,1]  R1339     -9.1903531551361084e-01
    z[4,6,1]  R1340     -8.1354314088821411e-01
    z[4,6,1]  R1341     -3.8258321583271027e-02
    z[4,6,1]  R1342     -9.3632888793945312e-01
    z[4,6,1]  R1343     -9.2413526773452759e-01
    z[4,6,1]  R1344     -8.6651885509490967e-01
    z[4,6,1]  R1345     -8.0911898612976074e-01
    z[4,6,1]  R1346     -8.6442202329635620e-01
    z[4,6,1]  R1347     -8.4205752611160278e-01
    z[4,6,1]  R1348     -0.888372004032135
    z[4,6,1]  R1349     -8.2396632432937622e-01
    z[4,6,1]  R1350     -9.3639492988586426e-01
    z[4,6,1]  R1351     -2.1814670413732529e-02
    z[4,6,1]  R1352     7.0344597101211548e-02
    z[4,6,1]  R1353     4.2119896411895752e-01
    z[4,6,1]  R1354     2.9502192139625549e-01
    z[4,6,1]  R1355     -0.842427670955658
    z[4,6,1]  R1356     -8.9654362201690674e-01
    z[4,6,1]  R1357     -8.8176757097244263e-01
    z[4,6,1]  R1358     -0.814807116985321
    z[4,6,1]  R1359     -7.9867547750473022e-01
    z[4,6,1]  R1360     -7.8840601444244385e-01
    z[4,6,1]  R1361     2.8742921352386475e-01
    z[4,6,1]  R1362     2.4879592657089233e-01
    z[4,6,1]  R1363     1.9900441169738770e-01
    z[4,6,1]  R1364     -8.9389944076538086e-01
    z[4,6,1]  R1365     -8.6115521192550659e-01
    z[4,6,1]  R1366     -8.2163053750991821e-01
    z[4,6,1]  R1367     -3.8869503140449524e-01
    z[4,6,1]  R1368     -5.9901064634323120e-01
    z[4,6,1]  R1369     -4.6669882535934448e-01
    z[4,6,1]  R1370     -7.2935229539871216e-01
    z[4,6,1]  R1371     -1.3459932059049606e-02
    z[4,6,1]  R1372     5.1934242248535156e-01
    z[4,6,1]  R1373     -7.9995006322860718e-02
    z[4,6,1]  R1374     0.0594286248087883
    z[4,6,1]  R1375     -5.0231166183948517e-02
    z[4,6,1]  R1376     1.3360656797885895e-01
    z[4,6,1]  R1377     4.5835691690444946e-01
    z[4,6,1]  R1378     -4.5497417449951172e-02
    z[4,6,1]  R1379     -1.8592052161693573e-01
    z[4,6,1]  R1380     -5.0240028649568558e-03
    z[4,6,1]  R1381     -5.2224469184875488e-01
    z[4,6,1]  R1382     -6.3291859626770020e-01
    z[4,6,1]  R1383     -6.0845259577035904e-02
    z[4,6,1]  R1384     -5.1689177751541138e-01
    z[4,6,1]  R1385     -3.9240229129791260e-01
    z[4,6,1]  R1386     -7.2546893358230591e-01
    z[4,6,1]  R1387     -6.4258140325546265e-01
    z[4,6,1]  R1388     -5.2906662225723267e-01
    z[4,6,1]  R1389     6.9133386015892029e-02
    z[4,6,1]  R1390     -3.1099589541554451e-02
    z[4,6,1]  R1391     -2.2310295701026917e-01
    z[4,6,1]  R1392     -6.4148336648941040e-01
    z[4,6,1]  R1393     -2.5085499882698059e-01
    z[4,6,1]  R1394     -1.7219226062297821e-01
    z[4,6,1]  R1395     -7.9821836948394775e-01
    z[4,6,1]  R1396     -7.4681842327117920e-01
    z[4,6,1]  R1397     -2.1572041511535645e-01
    z[4,6,1]  R1398     -7.3871570825576782e-01
    z[4,6,1]  R1399     -7.3048555850982666e-01
    z[4,6,1]  R1400     -6.9063276052474976e-01
    z[4,6,1]  R1401     -4.0086838603019714e-01
    z[4,6,1]  R1402     -8.0846118927001953e-01
    z[4,6,1]  R1403     -0.766937255859375
    z[4,6,1]  R1404     3.8483718037605286e-01
    z[4,6,1]  R1405     3.0647650361061096e-01
    z[4,6,1]  R1406     4.7750377655029297e-01
    z[4,6,1]  R1407     7.7439749240875244e-01
    z[4,6,1]  R1408     7.8351211547851562e-01
    z[4,6,1]  R1409     7.4697548151016235e-01
    z[4,6,1]  R1410     0.796562671661377
    z[4,6,2]  R40       -1
    z[4,6,2]  R58       1
    z[4,6,2]  R1301     -1
    z[4,6,2]  R1302     1
    z[4,6,2]  R1311     6.7431636154651642e-02
    z[4,6,2]  R1312     1.5567451715469360e-01
    z[4,6,2]  R1313     9.1799996793270111e-02
    z[4,6,2]  R1314     -7.2012418508529663e-01
    z[4,6,2]  R1315     -6.9533628225326538e-01
    z[4,6,2]  R1316     -4.1551807522773743e-01
    z[4,6,2]  R1317     -2.8524732589721680e-01
    z[4,6,2]  R1318     -1.3848823308944702e-01
    z[4,6,2]  R1319     -3.6783429980278015e-01
    z[4,6,2]  R1320     -1.7657396197319031e-01
    z[4,6,2]  R1321     8.4021437168121338e-01
    z[4,6,2]  R1322     2.8355118632316589e-01
    z[4,6,2]  R1323     4.9967566132545471e-01
    z[4,6,2]  R1324     4.6472790837287903e-01
    z[4,6,2]  R1325     8.4655404090881348e-01
    z[4,6,2]  R1326     6.6695623099803925e-02
    z[4,6,2]  R1327     -1.8805885314941406e-01
    z[4,6,2]  R1328     -0.0760580450296402
    z[4,6,2]  R1329     -1.6840463876724243e-01
    z[4,6,2]  R1330     6.3653844594955444e-01
    z[4,6,2]  R1331     9.5905712805688381e-04
    z[4,6,2]  R1332     -2.5765869021415710e-01
    z[4,6,2]  R1333     1.9793811440467834e-01
    z[4,6,2]  R1334     8.2529969513416290e-02
    z[4,6,2]  R1335     3.0190202593803406e-01
    z[4,6,2]  R1336     3.1279298663139343e-01
    z[4,6,2]  R1337     -0.0842321366071701
    z[4,6,2]  R1338     -4.0897119045257568e-01
    z[4,6,2]  R1339     -1.3384819030761719e-01
    z[4,6,2]  R1340     -9.7464453428983688e-03
    z[4,6,2]  R1341     2.5798752903938293e-02
    z[4,6,2]  R1342     1.9758033752441406e-01
    z[4,6,2]  R1343     -3.5061892122030258e-02
    z[4,6,2]  R1344     5.4388329386711121e-02
    z[4,6,2]  R1345     -1.8867659568786621e-01
    z[4,6,2]  R1346     7.1011655032634735e-02
    z[4,6,2]  R1347     2.8882932662963867e-01
    z[4,6,2]  R1348     -2.2510716319084167e-01
    z[4,6,2]  R1349     1.8280208110809326e-01
    z[4,6,2]  R1350     1.8073084950447083e-01
    z[4,6,2]  R1351     3.6547788977622986e-01
    z[4,6,2]  R1352     7.0659118890762329e-01
    z[4,6,2]  R1353     -8.2825394347310066e-03
    z[4,6,2]  R1354     4.5111495256423950e-01
    z[4,6,2]  R1355     8.0974452197551727e-02
    z[4,6,2]  R1356     -2.9770871996879578e-01
    z[4,6,2]  R1357     8.1429913640022278e-02
    z[4,6,2]  R1358     9.3797542154788971e-02
    z[4,6,2]  R1359     -4.2805038392543793e-02
    z[4,6,2]  R1360     3.6200657486915588e-02
    z[4,6,2]  R1361     4.8477512598037720e-01
    z[4,6,2]  R1362     -7.6532892882823944e-02
    z[4,6,2]  R1363     5.3832525014877319e-01
    z[4,6,2]  R1364     3.4502517431974411e-02
    z[4,6,2]  R1365     1.4597199857234955e-01
    z[4,6,2]  R1366     -2.9339563846588135e-01
    z[4,6,2]  R1367     -7.7600318193435669e-01
    z[4,6,2]  R1368     -6.7623686790466309e-01
    z[4,6,2]  R1369     -7.2706836462020874e-01
    z[4,6,2]  R1370     -2.1004046499729156e-01
    z[4,6,2]  R1371     -0.560208797454834
    z[4,6,2]  R1372     -4.3954044580459595e-01
    z[4,6,2]  R1373     -3.0679419636726379e-01
    z[4,6,2]  R1374     -4.7865721583366394e-01
    z[4,6,2]  R1375     -3.0638018250465393e-01
    z[4,6,2]  R1376     -1.2894614040851593e-01
    z[4,6,2]  R1377     -2.9435306787490845e-01
    z[4,6,2]  R1378     -6.0012418776750565e-02
    z[4,6,2]  R1379     -1.3119670748710632e-01
    z[4,6,2]  R1380     2.3547196388244629e-01
    z[4,6,2]  R1381     -5.2362614870071411e-01
    z[4,6,2]  R1382     -0.438385546207428
    z[4,6,2]  R1383     -5.9539139270782471e-01
    z[4,6,2]  R1384     3.5121065378189087e-01
    z[4,6,2]  R1385     5.2069473266601562e-01
    z[4,6,2]  R1386     2.0645692944526672e-02
    z[4,6,2]  R1387     6.0132515430450439e-01
    z[4,6,2]  R1388     5.5767655372619629e-01
    z[4,6,2]  R1389     4.3703210353851318e-01
    z[4,6,2]  R1390     4.5359331369400024e-01
    z[4,6,2]  R1391     -4.8705145716667175e-01
    z[4,6,2]  R1392     4.6946480870246887e-01
    z[4,6,2]  R1393     2.7474248409271240e-01
    z[4,6,2]  R1394     5.8647930622100830e-01
    z[4,6,2]  R1395     3.6668869853019714e-01
    z[4,6,2]  R1396     3.1894814968109131e-01
    z[4,6,2]  R1397     2.6994487643241882e-01
    z[4,6,2]  R1398     4.6839416027069092e-01
    z[4,6,2]  R1399     0.56394362449646
    z[4,6,2]  R1400     4.9780625104904175e-01
    z[4,6,2]  R1401     -1.2506563961505890e-01
    z[4,6,2]  R1402     4.0509355068206787e-01
    z[4,6,2]  R1403     4.4223695993423462e-01
    z[4,6,2]  R1404     2.4276073276996613e-01
    z[4,6,2]  R1405     2.3418653011322021e-01
    z[4,6,2]  R1406     1.7361932992935181e-01
    z[4,6,2]  R1407     3.7193521857261658e-01
    z[4,6,2]  R1408     2.2485843300819397e-01
    z[4,6,2]  R1409     5.1996129751205444e-01
    z[4,6,2]  R1410     -3.6978565156459808e-02
    z[4,6,3]  R41       -1
    z[4,6,3]  R59       1
    z[4,6,3]  R1303     -1
    z[4,6,3]  R1304     1
    z[4,6,3]  R1311     1.1516990512609482e-01
    z[4,6,3]  R1312     3.2431280612945557e-01
    z[4,6,3]  R1313     -2.0396200940012932e-02
    z[4,6,3]  R1314     1.1635913699865341e-01
    z[4,6,3]  R1315     8.8614434003829956e-02
    z[4,6,3]  R1316     -4.9735743552446365e-02
    z[4,6,3]  R1317     1.7283445596694946e-01
    z[4,6,3]  R1318     3.2775089144706726e-01
    z[4,6,3]  R1319     2.1331556141376495e-01
    z[4,6,3]  R1320     4.2960166931152344e-01
    z[4,6,3]  R1321     -3.4326744079589844e-01
    z[4,6,3]  R1322     -7.0934981107711792e-01
    z[4,6,3]  R1323     -3.1899097561836243e-01
    z[4,6,3]  R1324     -6.1695091426372528e-02
    z[4,6,3]  R1325     1.6761821508407593e-01
    z[4,6,3]  R1326     1.9978480041027069e-01
    z[4,6,3]  R1327     1.8895334005355835e-01
    z[4,6,3]  R1328     -7.9344063997268677e-02
    z[4,6,3]  R1329     5.0925098359584808e-02
    z[4,6,3]  R1330     -1.7422821372747421e-02
    z[4,6,3]  R1331     1.1696402914822102e-02
    z[4,6,3]  R1332     -1.2717632949352264e-01
    z[4,6,3]  R1333     -4.6137967146933079e-03
    z[4,6,3]  R1334     -2.5225919485092163e-01
    z[4,6,3]  R1335     5.6858994066715240e-02
    z[4,6,3]  R1336     -2.6485204696655273e-01
    z[4,6,3]  R1337     -5.9067141264677048e-02
    z[4,6,3]  R1338     0.577458918094635
    z[4,6,3]  R1339     2.4416531622409821e-01
    z[4,6,3]  R1340     4.3209555745124817e-01
    z[4,6,3]  R1341     -5.9953224658966064e-01
    z[4,6,3]  R1342     -7.7092565596103668e-02
    z[4,6,3]  R1343     -1.5031945705413818e-01
    z[4,6,3]  R1344     -1.7512956261634827e-01
    z[4,6,3]  R1345     3.2055267691612244e-01
    z[4,6,3]  R1346     4.5226126909255981e-01
    z[4,6,3]  R1347     2.7695652842521667e-01
    z[4,6,3]  R1348     -4.8354491591453552e-02
    z[4,6,3]  R1349     2.9866832494735718e-01
    z[4,6,3]  R1350     1.8614947795867920e-01
    z[4,6,3]  R1351     -4.7284394502639771e-01
    z[4,6,3]  R1352     1.2677592039108276e-01
    z[4,6,3]  R1353     -1.4143761992454529e-01
    z[4,6,3]  R1354     -4.3483623862266541e-01
    z[4,6,3]  R1355     2.1898582577705383e-01
    z[4,6,3]  R1356     1.0630187392234802e-01
    z[4,6,3]  R1357     2.1172007918357849e-01
    z[4,6,3]  R1358     3.3912602066993713e-01
    z[4,6,3]  R1359     5.2484345436096191e-01
    z[4,6,3]  R1360     3.1216824054718018e-01
    z[4,6,3]  R1361     3.7200883030891418e-01
    z[4,6,3]  R1362     9.9150486290454865e-02
    z[4,6,3]  R1363     1.4972022175788879e-01
    z[4,6,3]  R1364     1.7892074584960938e-01
    z[4,6,3]  R1365     1.5810623764991760e-01
    z[4,6,3]  R1366     2.3697124421596527e-01
    z[4,6,3]  R1367     -1.4373597502708435e-01
    z[4,6,3]  R1368     -2.0813571289181709e-02
    z[4,6,3]  R1369     1.5533900260925293e-01
    z[4,6,3]  R1370     7.3797397315502167e-02
    z[4,6,3]  R1371     7.3736059665679932e-01
    z[4,6,3]  R1372     2.4496375024318695e-01
    z[4,6,3]  R1373     2.7197441458702087e-01
    z[4,6,3]  R1374     5.6444466114044189e-01
    z[4,6,3]  R1375     2.1162256598472595e-01
    z[4,6,3]  R1376     7.8199088573455811e-01
    z[4,6,3]  R1377     8.8519737124443054e-02
    z[4,6,3]  R1378     3.7660104036331177e-01
    z[4,6,3]  R1379     5.6421411037445068e-01
    z[4,6,3]  R1380     5.9436100721359253e-01
    z[4,6,3]  R1381     -2.2799010574817657e-01
    z[4,6,3]  R1382     -2.5736156105995178e-01
    z[4,6,3]  R1383     -5.4242026805877686e-01
    z[4,6,3]  R1384     -2.6262211799621582e-01
    z[4,6,3]  R1385     -3.8348857313394547e-02
    z[4,6,3]  R1386     -2.9589679837226868e-01
    z[4,6,3]  R1387     -3.0975860357284546e-01
    z[4,6,3]  R1388     -2.8315034508705139e-01
    z[4,6,3]  R1389     -3.3291906118392944e-01
    z[4,6,3]  R1390     -3.2870528101921082e-01
    z[4,6,3]  R1391     -6.7682260274887085e-01
    z[4,6,3]  R1392     4.9128532409667969e-01
    z[4,6,3]  R1393     6.4742344617843628e-01
    z[4,6,3]  R1394     -2.0186990499496460e-01
    z[4,6,3]  R1395     3.9293374866247177e-02
    z[4,6,3]  R1396     2.5785389542579651e-01
    z[4,6,3]  R1397     -2.4777875840663910e-01
    z[4,6,3]  R1398     -1.5962266921997070e-01
    z[4,6,3]  R1399     -2.1654102206230164e-01
    z[4,6,3]  R1400     -2.8818780183792114e-01
    z[4,6,3]  R1401     -3.1955018639564514e-01
    z[4,6,3]  R1402     -0.0674697533249855
    z[4,6,3]  R1403     -3.9962741732597351e-01
    z[4,6,3]  R1404     -3.4626686573028564e-01
    z[4,6,3]  R1405     -3.3625563979148865e-01
    z[4,6,3]  R1406     -3.5481536388397217e-01
    z[4,6,3]  R1407     -2.6597523689270020e-01
    z[4,6,3]  R1408     -1.3726912438869476e-01
    z[4,6,3]  R1409     -4.0699992328882217e-02
    z[4,6,3]  R1410     -2.2174143791198730e-01
    z[4,6,4]  R42       -1
    z[4,6,4]  R60       1
    z[4,6,4]  R1305     -1
    z[4,6,4]  R1306     1
    z[4,6,4]  R1311     1.9727703928947449e-01
    z[4,6,4]  R1312     -1.5441924333572388e-01
    z[4,6,4]  R1313     -0.753320038318634
    z[4,6,4]  R1314     1.1484218388795853e-01
    z[4,6,4]  R1315     -5.3371128160506487e-04
    z[4,6,4]  R1316     -7.0962566137313843e-01
    z[4,6,4]  R1317     -2.0088282227516174e-01
    z[4,6,4]  R1318     -3.2505291700363159e-01
    z[4,6,4]  R1319     -6.0996998101472855e-02
    z[4,6,4]  R1320     2.0736807957291603e-02
    z[4,6,4]  R1321     3.2866573333740234e-01
    z[4,6,4]  R1322     3.8796129822731018e-01
    z[4,6,4]  R1323     1.7747510969638824e-01
    z[4,6,4]  R1324     5.6861841678619385e-01
    z[4,6,4]  R1325     1.2420850992202759e-01
    z[4,6,4]  R1326     4.2864728718996048e-02
    z[4,6,4]  R1327     -1.3347423076629639e-01
    z[4,6,4]  R1328     4.1570693254470825e-01
    z[4,6,4]  R1329     2.5823217630386353e-01
    z[4,6,4]  R1330     -3.1981033086776733e-01
    z[4,6,4]  R1331     2.4458529055118561e-01
    z[4,6,4]  R1332     -0.0643736943602562
    z[4,6,4]  R1333     -1.4105857908725739e-01
    z[4,6,4]  R1334     2.8672186657786369e-02
    z[4,6,4]  R1335     -3.5256387200206518e-03
    z[4,6,4]  R1336     -9.0861216187477112e-02
    z[4,6,4]  R1337     -1.7767642438411713e-01
    z[4,6,4]  R1338     -3.8526263833045959e-01
    z[4,6,4]  R1339     -2.2214479744434357e-02
    z[4,6,4]  R1340     -1.0918529331684113e-01
    z[4,6,4]  R1341     -3.1989240646362305e-01
    z[4,6,4]  R1342     7.2579570114612579e-02
    z[4,6,4]  R1343     2.8426715731620789e-01
    z[4,6,4]  R1344     -3.4772685170173645e-01
    z[4,6,4]  R1345     1.4275148510932922e-01
    z[4,6,4]  R1346     -1.9971360266208649e-01
    z[4,6,4]  R1347     1.9227384030818939e-01
    z[4,6,4]  R1348     2.8355914354324341e-01
    z[4,6,4]  R1349     3.6364585161209106e-01
    z[4,6,4]  R1350     0.0623299777507782
    z[4,6,4]  R1351     5.4575152695178986e-02
    z[4,6,4]  R1352     -2.1897906064987183e-01
    z[4,6,4]  R1353     -0.252566397190094
    z[4,6,4]  R1354     -5.8801096677780151e-01
    z[4,6,4]  R1355     -1.1910246312618256e-01
    z[4,6,4]  R1356     1.2385033816099167e-01
    z[4,6,4]  R1357     1.8290621042251587e-01
    z[4,6,4]  R1358     3.0379590392112732e-01
    z[4,6,4]  R1359     7.5964882969856262e-02
    z[4,6,4]  R1360     2.0483568310737610e-01
    z[4,6,4]  R1361     4.8887407779693604e-01
    z[4,6,4]  R1362     4.4355848431587219e-01
    z[4,6,4]  R1363     -5.6815481185913086e-01
    z[4,6,4]  R1364     3.8978552818298340e-01
    z[4,6,4]  R1365     2.4475511908531189e-01
    z[4,6,4]  R1366     1.7736183479428291e-02
    z[4,6,4]  R1367     -3.5304382443428040e-01
    z[4,6,4]  R1368     -3.3749529719352722e-01
    z[4,6,4]  R1369     -3.7403953075408936e-01
    z[4,6,4]  R1370     -2.0202626287937164e-01
    z[4,6,4]  R1371     -1.4335820078849792e-01
    z[4,6,4]  R1372     -1.8840160965919495e-01
    z[4,6,4]  R1373     -6.8485051393508911e-01
    z[4,6,4]  R1374     -2.5238949060440063e-01
    z[4,6,4]  R1375     -6.9705463945865631e-02
    z[4,6,4]  R1376     -2.0170746371150017e-02
    z[4,6,4]  R1377     -1.4854730665683746e-01
    z[4,6,4]  R1378     -7.6145190000534058e-01
    z[4,6,4]  R1379     1.9435827434062958e-01
    z[4,6,4]  R1380     8.6991004645824432e-02
    z[4,6,4]  R1381     2.6194646954536438e-01
    z[4,6,4]  R1382     -0.0992252379655838
    z[4,6,4]  R1383     2.4288235604763031e-01
    z[4,6,4]  R1384     -1.8302644789218903e-01
    z[4,6,4]  R1385     -6.6127941012382507e-02
    z[4,6,4]  R1386     2.5026535987854004e-01
    z[4,6,4]  R1387     -1.9430282711982727e-01
    z[4,6,4]  R1388     5.0300270318984985e-01
    z[4,6,4]  R1389     6.9137299060821533e-01
    z[4,6,4]  R1390     5.7457500696182251e-01
    z[4,6,4]  R1391     -4.6021699905395508e-01
    z[4,6,4]  R1392     1.0321640968322754e-01
    z[4,6,4]  R1393     1.9517336785793304e-01
    z[4,6,4]  R1394     2.2953076288104057e-02
    z[4,6,4]  R1395     3.7811064720153809e-01
    z[4,6,4]  R1396     3.3351635932922363e-01
    z[4,6,4]  R1397     0.510429859161377
    z[4,6,4]  R1398     -2.8141397982835770e-02
    z[4,6,4]  R1399     1.0243520140647888e-01
    z[4,6,4]  R1400     -6.0386221855878830e-02
    z[4,6,4]  R1401     -0.518736720085144
    z[4,6,4]  R1402     2.2828787565231323e-02
    z[4,6,4]  R1403     8.2920975983142853e-03
    z[4,6,4]  R1404     4.2705839872360229e-01
    z[4,6,4]  R1405     2.9318472743034363e-01
    z[4,6,4]  R1406     7.0638722181320190e-01
    z[4,6,4]  R1407     3.9679402112960815e-01
    z[4,6,4]  R1408     3.3010202646255493e-01
    z[4,6,4]  R1409     1.8786674365401268e-02
    z[4,6,4]  R1410     1.2044016271829605e-01
    z[4,6,5]  R43       -1
    z[4,6,5]  R61       1
    z[4,6,5]  R1307     -1
    z[4,6,5]  R1308     1
    z[4,6,5]  R1311     -1.8966224789619446e-01
    z[4,6,5]  R1312     -8.7802886962890625e-02
    z[4,6,5]  R1313     -0.067637138068676
    z[4,6,5]  R1314     -4.5988604426383972e-02
    z[4,6,5]  R1315     -4.5047560706734657e-03
    z[4,6,5]  R1316     -3.2689280807971954e-02
    z[4,6,5]  R1317     -3.1402119994163513e-01
    z[4,6,5]  R1318     -2.1722888946533203e-01
    z[4,6,5]  R1319     1.6671134158968925e-02
    z[4,6,5]  R1320     -2.8326642513275146e-01
    z[4,6,5]  R1321     1.5485012531280518e-01
    z[4,6,5]  R1322     3.1400460004806519e-01
    z[4,6,5]  R1323     1.8866080045700073e-01
    z[4,6,5]  R1324     1.1222336441278458e-01
    z[4,6,5]  R1325     -4.7523528337478638e-01
    z[4,6,5]  R1326     -4.2120289802551270e-01
    z[4,6,5]  R1327     3.0312919989228249e-02
    z[4,6,5]  R1328     -1.0461964458227158e-01
    z[4,6,5]  R1329     -4.2417088150978088e-01
    z[4,6,5]  R1330     -6.0311728715896606e-01
    z[4,6,5]  R1331     -3.6094522476196289e-01
    z[4,6,5]  R1332     -1.3168926537036896e-01
    z[4,6,5]  R1333     6.9820769131183624e-02
    z[4,6,5]  R1334     1.6734541952610016e-01
    z[4,6,5]  R1335     -0.349232941865921
    z[4,6,5]  R1336     -1.2980429828166962e-01
    z[4,6,5]  R1337     -1.8330083787441254e-01
    z[4,6,5]  R1338     -1.6589336097240448e-01
    z[4,6,5]  R1339     6.6312126815319061e-02
    z[4,6,5]  R1340     -3.8353651762008667e-02
    z[4,6,5]  R1341     3.4753882884979248e-01
    z[4,6,5]  R1342     -1.3029731810092926e-01
    z[4,6,5]  R1343     5.8049920946359634e-02
    z[4,6,5]  R1344     0.0403253547847271
    z[4,6,5]  R1345     -2.4391652643680573e-01
    z[4,6,5]  R1346     -2.3386912420392036e-02
    z[4,6,5]  R1347     1.4532741904258728e-01
    z[4,6,5]  R1348     2.7338016033172607e-01
    z[4,6,5]  R1349     3.8393858820199966e-02
    z[4,6,5]  R1350     1.7576953768730164e-01
    z[4,6,5]  R1351     7.1508079767227173e-02
    z[4,6,5]  R1352     -3.5299065709114075e-01
    z[4,6,5]  R1353     8.2775211334228516e-01
    z[4,6,5]  R1354     1.0440965741872787e-01
    z[4,6,5]  R1355     -4.4865331053733826e-01
    z[4,6,5]  R1356     1.5884213149547577e-01
    z[4,6,5]  R1357     4.0458705276250839e-02
    z[4,6,5]  R1358     0.0845780149102211
    z[4,6,5]  R1359     -4.5434813946485519e-02
    z[4,6,5]  R1360     -1.3693729043006897e-01
    z[4,6,5]  R1361     0.0855298712849617
    z[4,6,5]  R1362     6.1912846565246582e-01
    z[4,6,5]  R1363     -1.4781183004379272e-01
    z[4,6,5]  R1364     1.0292392224073410e-01
    z[4,6,5]  R1365     2.4152073264122009e-01
    z[4,6,5]  R1366     2.0462978631258011e-02
    z[4,6,5]  R1367     2.7034100890159607e-01
    z[4,6,5]  R1368     2.2451931238174438e-01
    z[4,6,5]  R1369     2.0600913465023041e-01
    z[4,6,5]  R1370     -2.2528212517499924e-02
    z[4,6,5]  R1371     6.9417193531990051e-02
    z[4,6,5]  R1372     1.5506243705749512e-01
    z[4,6,5]  R1373     3.7132057547569275e-01
    z[4,6,5]  R1374     2.1465530991554260e-01
    z[4,6,5]  R1375     1.0117302089929581e-01
    z[4,6,5]  R1376     2.5743028521537781e-01
    z[4,6,5]  R1377     -0.305356502532959
    z[4,6,5]  R1378     -1.4670735597610474e-01
    z[4,6,5]  R1379     -7.6789689064025879e-01
    z[4,6,5]  R1380     -6.5999329090118408e-01
    z[4,6,5]  R1381     4.4676882028579712e-01
    z[4,6,5]  R1382     2.8443023562431335e-01
    z[4,6,5]  R1383     3.3078234642744064e-02
    z[4,6,5]  R1384     -3.0063995718955994e-01
    z[4,6,5]  R1385     2.8809410333633423e-01
    z[4,6,5]  R1386     -0.0702296569943428
    z[4,6,5]  R1387     2.3496554791927338e-01
    z[4,6,5]  R1388     -4.1340142488479614e-02
    z[4,6,5]  R1389     4.4156956672668457e-01
    z[4,6,5]  R1390     4.3883880972862244e-01
    z[4,6,5]  R1391     -4.7935396432876587e-02
    z[4,6,5]  R1392     -5.1559843122959137e-02
    z[4,6,5]  R1393     1.7003294825553894e-01
    z[4,6,5]  R1394     -9.0687476098537445e-02
    z[4,6,5]  R1395     -2.9200930148363113e-02
    z[4,6,5]  R1396     2.5748556945472956e-03
    z[4,6,5]  R1397     -3.8776826858520508e-01
    z[4,6,5]  R1398     -3.2422986626625061e-01
    z[4,6,5]  R1399     1.9909940659999847e-02
    z[4,6,5]  R1400     -3.2066482305526733e-01
    z[4,6,5]  R1401     6.5030759572982788e-01
    z[4,6,5]  R1402     0.18819560110569
    z[4,6,5]  R1403     1.9532483071088791e-02
    z[4,6,5]  R1404     6.8907028436660767e-01
    z[4,6,5]  R1405     7.6346707344055176e-01
    z[4,6,5]  R1406     3.1301450729370117e-01
    z[4,6,5]  R1407     7.1340814232826233e-02
    z[4,6,5]  R1408     1.0498243570327759e-01
    z[4,6,5]  R1409     1.6161866486072540e-01
    z[4,6,5]  R1410     -2.5649511814117432e-01
    z[4,6,6]  R44       -1
    z[4,6,6]  R62       1
    z[4,6,6]  R1309     -1
    z[4,6,6]  R1310     1
    z[4,6,6]  R1311     3.5725861787796021e-01
    z[4,6,6]  R1312     -1.3364584743976593e-01
    z[4,6,6]  R1313     3.8772195577621460e-01
    z[4,6,6]  R1314     -4.8938225954771042e-02
    z[4,6,6]  R1315     -4.5889008045196533e-01
    z[4,6,6]  R1316     6.0432165861129761e-02
    z[4,6,6]  R1317     -1.5530244447290897e-02
    z[4,6,6]  R1318     4.6107780188322067e-02
    z[4,6,6]  R1319     -2.0385617017745972e-01
    z[4,6,6]  R1320     1.7365282773971558e-01
    z[4,6,6]  R1321     -6.3380233943462372e-02
    z[4,6,6]  R1322     -1.2486694753170013e-01
    z[4,6,6]  R1323     -7.1028012037277222e-01
    z[4,6,6]  R1324     -5.5898189544677734e-01
    z[4,6,6]  R1325     -8.3008259534835815e-02
    z[4,6,6]  R1326     -2.5063201785087585e-01
    z[4,6,6]  R1327     -0.0890025720000267
    z[4,6,6]  R1328     -1.6875582933425903e-01
    z[4,6,6]  R1329     1.7634356021881104e-01
    z[4,6,6]  R1330     1.9689792394638062e-01
    z[4,6,6]  R1331     -1.5362252295017242e-01
    z[4,6,6]  R1332     3.7762913852930069e-02
    z[4,6,6]  R1333     -1.8423174321651459e-01
    z[4,6,6]  R1334     3.1699728965759277e-01
    z[4,6,6]  R1335     -0.0688420757651329
    z[4,6,6]  R1336     2.5477710366249084e-01
    z[4,6,6]  R1337     -5.1449424028396606e-01
    z[4,6,6]  R1338     3.2861515879631042e-02
    z[4,6,6]  R1339     -4.3765522539615631e-02
    z[4,6,6]  R1340     -2.4215854704380035e-01
    z[4,6,6]  R1341     2.3911017179489136e-01
    z[4,6,6]  R1342     5.1108323037624359e-02
    z[4,6,6]  R1343     -1.1741942912340164e-01
    z[4,6,6]  R1344     -1.5337510406970978e-01
    z[4,6,6]  R1345     -3.4810605645179749e-01
    z[4,6,6]  R1346     1.2059990316629410e-02
    z[4,6,6]  R1347     -1.7385342717170715e-01
    z[4,6,6]  R1348     -1.3387300074100494e-02
    z[4,6,6]  R1349     -2.3169608414173126e-01
    z[4,6,6]  R1350     -1.4494709670543671e-01
    z[4,6,6]  R1351     1.4631895720958710e-01
    z[4,6,6]  R1352     3.5688430070877075e-01
    z[4,6,6]  R1353     1.8671859055757523e-02
    z[4,6,6]  R1354     -1.4046387374401093e-01
    z[4,6,6]  R1355     -5.2591826766729355e-02
    z[4,6,6]  R1356     -5.9016954153776169e-02
    z[4,6,6]  R1357     -1.4667728543281555e-01
    z[4,6,6]  R1358     7.6553061604499817e-02
    z[4,6,6]  R1359     -2.6487118005752563e-01
    z[4,6,6]  R1360     4.2527332901954651e-01
    z[4,6,6]  R1361     -4.4908666610717773e-01
    z[4,6,6]  R1362     3.6136223934590816e-03
    z[4,6,6]  R1363     -4.3110698461532593e-01
    z[4,6,6]  R1364     7.2128519415855408e-02
    z[4,6,6]  R1365     -1.2996993958950043e-01
    z[4,6,6]  R1366     4.2649745941162109e-01
    z[4,6,6]  R1367     -7.5684264302253723e-02
    z[4,6,6]  R1368     1.0512106865644455e-01
    z[4,6,6]  R1369     -2.1033169329166412e-01
    z[4,6,6]  R1370     0.22533018887043
    z[4,6,6]  R1371     3.1279347836971283e-02
    z[4,6,6]  R1372     -1.2333748489618301e-01
    z[4,6,6]  R1373     -2.9531520605087280e-01
    z[4,6,6]  R1374     4.5990908145904541e-01
    z[4,6,6]  R1375     -6.3684183359146118e-01
    z[4,6,6]  R1376     -1.8181812763214111e-01
    z[4,6,6]  R1377     1.4404557645320892e-01
    z[4,6,6]  R1378     -5.8593165129423141e-02
    z[4,6,6]  R1379     3.1259968876838684e-02
    z[4,6,6]  R1380     2.9459765553474426e-01
    z[4,6,6]  R1381     -8.9009217917919159e-03
    z[4,6,6]  R1382     1.6101954877376556e-01
    z[4,6,6]  R1383     5.1092332601547241e-01
    z[4,6,6]  R1384     -3.2722827792167664e-01
    z[4,6,6]  R1385     -0.340950071811676
    z[4,6,6]  R1386     3.6238130927085876e-01
    z[4,6,6]  R1387     -1.6881616413593292e-01
    z[4,6,6]  R1388     2.3747469484806061e-01
    z[4,6,6]  R1389     -1.9602755084633827e-02
    z[4,6,6]  R1390     3.4779345989227295e-01
    z[4,6,6]  R1391     1.4406830072402954e-01
    z[4,6,6]  R1392     -2.4699696898460388e-01
    z[4,6,6]  R1393     1.8225048482418060e-01
    z[4,6,6]  R1394     0.104326531291008
    z[4,6,6]  R1395     -6.0234349220991135e-03
    z[4,6,6]  R1396     3.6382114887237549e-01
    z[4,6,6]  R1397     -1.3241605460643768e-01
    z[4,6,6]  R1398     3.2028988003730774e-01
    z[4,6,6]  R1399     -1.9152744114398956e-01
    z[4,6,6]  R1400     -2.9902998358011246e-02
    z[4,6,6]  R1401     -1.2477464973926544e-01
    z[4,6,6]  R1402     3.0275234580039978e-01
    z[4,6,6]  R1403     -1.3602021336555481e-01
    z[4,6,6]  R1404     2.1427385509014130e-02
    z[4,6,6]  R1405     2.4743328988552094e-01
    z[4,6,6]  R1406     -0.0496220663189888
    z[4,6,6]  R1407     3.2432243227958679e-02
    z[4,6,6]  R1408     2.0292037725448608e-01
    z[4,6,6]  R1409     3.0066993832588196e-01
    z[4,6,6]  R1410     -1.1451942473649979e-01
    z[6,4,0]  R38       1
    z[6,4,0]  R56       -1
    z[6,4,0]  R1411     -1
    z[6,4,0]  R1412     1
    z[6,4,0]  R1425     -3.4049317240715027e-01
    z[6,4,0]  R1426     -6.3429397344589233e-01
    z[6,4,0]  R1427     -3.6248835921287537e-01
    z[6,4,0]  R1428     -3.5702109336853027e-01
    z[6,4,0]  R1429     -6.6193765401840210e-01
    z[6,4,0]  R1430     -5.0425916910171509e-01
    z[6,4,0]  R1431     -7.4791139364242554e-01
    z[6,4,0]  R1432     -4.9772980809211731e-01
    z[6,4,0]  R1433     3.8281381130218506e-02
    z[6,4,0]  R1434     2.4762129783630371e-01
    z[6,4,0]  R1435     3.6441591382026672e-01
    z[6,4,0]  R1436     4.7362810373306274e-01
    z[6,4,0]  R1437     1.6266094148159027e-01
    z[6,4,0]  R1438     5.5636501312255859e-01
    z[6,4,0]  R1439     6.0811895132064819e-01
    z[6,4,0]  R1440     -4.3223667144775391e-01
    z[6,4,0]  R1441     -8.9919343590736389e-02
    z[6,4,0]  R1442     1.3340255618095398e-01
    z[6,4,0]  R1443     -1.4150561392307281e-01
    z[6,4,0]  R1444     -2.0386894047260284e-01
    z[6,4,0]  R1445     -1.4164708554744720e-01
    z[6,4,0]  R1446     2.2895674407482147e-01
    z[6,4,0]  R1447     5.8498895168304443e-01
    z[6,4,0]  R1448     7.5233328342437744e-01
    z[6,4,0]  R1449     -2.8807312250137329e-01
    z[6,4,0]  R1450     -1.7447084188461304e-01
    z[6,4,0]  R1451     6.2511068582534790e-01
    z[6,4,0]  R1452     -3.0400281772017479e-02
    z[6,4,0]  R1453     -2.3215585947036743e-01
    z[6,4,0]  R1454     -2.9119861125946045e-01
    z[6,4,0]  R1455     1.1829664558172226e-01
    z[6,4,0]  R1456     -2.2391916811466217e-01
    z[6,4,0]  R1457     -1.9385483860969543e-01
    z[6,4,0]  R1458     1.2414071708917618e-01
    z[6,4,0]  R1459     -8.9991658926010132e-02
    z[6,4,0]  R1460     -1.2856583297252655e-01
    z[6,4,0]  R1461     1.6626198589801788e-01
    z[6,4,0]  R1462     3.9438480138778687e-01
    z[6,4,0]  R1463     2.3051121830940247e-01
    z[6,4,0]  R1464     4.7068125009536743e-01
    z[6,4,0]  R1465     1.8276479095220566e-02
    z[6,4,0]  R1466     1.1998645216226578e-01
    z[6,4,0]  R1467     6.4301635138690472e-03
    z[6,4,0]  R1468     3.2188287377357483e-01
    z[6,4,0]  R1469     2.7721645310521126e-02
    z[6,4,0]  R1470     5.9904661029577255e-02
    z[6,4,0]  R1471     0.858936071395874
    z[6,4,0]  R1472     8.3661407232284546e-01
    z[6,4,0]  R1473     0.852433979511261
    z[6,4,0]  R1474     8.1905382871627808e-01
    z[6,4,0]  R1475     -1.7209856212139130e-01
    z[6,4,0]  R1476     -1.0541781038045883e-01
    z[6,4,0]  R1477     -2.4894516170024872e-01
    z[6,4,0]  R1478     -3.6012226343154907e-01
    z[6,4,0]  R1479     5.3793575614690781e-02
    z[6,4,0]  R1480     -7.2886824607849121e-01
    z[6,4,0]  R1481     3.1899258494377136e-01
    z[6,4,0]  R1482     -2.4710580706596375e-02
    z[6,4,0]  R1483     5.6930180639028549e-02
    z[6,4,0]  R1484     2.9730057716369629e-01
    z[6,4,0]  R1485     -7.6461881399154663e-01
    z[6,4,0]  R1486     3.1305238604545593e-02
    z[6,4,0]  R1487     -2.4371033906936646e-01
    z[6,4,0]  R1488     -6.6487453877925873e-02
    z[6,4,0]  R1489     1.7442536354064941e-01
    z[6,4,0]  R1490     -2.1793624758720398e-01
    z[6,4,0]  R1491     1.1814450845122337e-02
    z[6,4,0]  R1492     -1.3853733241558075e-01
    z[6,4,0]  R1493     -2.6652544736862183e-01
    z[6,4,0]  R1494     -2.8162550926208496e-01
    z[6,4,0]  R1495     -5.9845107793807983e-01
    z[6,4,0]  R1496     2.3119193315505981e-01
    z[6,4,0]  R1497     1.5551097691059113e-01
    z[6,4,0]  R1498     2.6353845000267029e-01
    z[6,4,0]  R1499     7.6957635581493378e-02
    z[6,4,0]  R1500     -5.1124148070812225e-02
    z[6,4,0]  R1501     2.0614919066429138e-01
    z[6,4,0]  R1502     -4.9619201570749283e-02
    z[6,4,0]  R1503     -1.0518789291381836e-01
    z[6,4,0]  R1504     -7.7299750410020351e-03
    z[6,4,0]  R1505     -7.8285849094390869e-01
    z[6,4,0]  R1506     -4.2401376366615295e-01
    z[6,4,0]  R1507     -2.3066484928131104e-01
    z[6,4,0]  R1508     -3.7945550680160522e-01
    z[6,4,0]  R1509     -1.3252480328083038e-01
    z[6,4,0]  R1510     -2.2853079438209534e-01
    z[6,4,0]  R1511     -3.3826592564582825e-01
    z[6,4,0]  R1512     3.2707676291465759e-01
    z[6,4,0]  R1513     -8.2660518586635590e-02
    z[6,4,0]  R1514     -1.9516560435295105e-01
    z[6,4,0]  R1515     -3.0983048677444458e-01
    z[6,4,0]  R1516     -5.8509427309036255e-01
    z[6,4,0]  R1517     -3.4305313229560852e-01
    z[6,4,0]  R1518     3.4879993181675673e-03
    z[6,4,0]  R1519     2.7744683623313904e-01
    z[6,4,0]  R1520     -7.3124817572534084e-03
    z[6,4,0]  R1521     -1.5040916204452515e-01
    z[6,4,0]  R1522     -8.9968644082546234e-02
    z[6,4,0]  R1523     5.3375765681266785e-02
    z[6,4,0]  R1524     -5.7130229473114014e-01
    z[6,4,1]  R39       1
    z[6,4,1]  R57       -1
    z[6,4,1]  R1413     -1
    z[6,4,1]  R1414     1
    z[6,4,1]  R1425     -1.3459932059049606e-02
    z[6,4,1]  R1426     5.1934242248535156e-01
    z[6,4,1]  R1427     -7.9995006322860718e-02
    z[6,4,1]  R1428     0.0594286248087883
    z[6,4,1]  R1429     -5.0231166183948517e-02
    z[6,4,1]  R1430     1.3360656797885895e-01
    z[6,4,1]  R1431     4.5835691690444946e-01
    z[6,4,1]  R1432     -4.5497417449951172e-02
    z[6,4,1]  R1433     -1.8592052161693573e-01
    z[6,4,1]  R1434     -5.0240028649568558e-03
    z[6,4,1]  R1435     -5.2224469184875488e-01
    z[6,4,1]  R1436     -6.3291859626770020e-01
    z[6,4,1]  R1437     -6.0845259577035904e-02
    z[6,4,1]  R1438     -5.1689177751541138e-01
    z[6,4,1]  R1439     -3.9240229129791260e-01
    z[6,4,1]  R1440     -7.2546893358230591e-01
    z[6,4,1]  R1441     -6.4258140325546265e-01
    z[6,4,1]  R1442     -5.2906662225723267e-01
    z[6,4,1]  R1443     6.9133386015892029e-02
    z[6,4,1]  R1444     -3.1099589541554451e-02
    z[6,4,1]  R1445     -2.2310295701026917e-01
    z[6,4,1]  R1446     -6.4148336648941040e-01
    z[6,4,1]  R1447     -2.5085499882698059e-01
    z[6,4,1]  R1448     -1.7219226062297821e-01
    z[6,4,1]  R1449     -7.9821836948394775e-01
    z[6,4,1]  R1450     -7.4681842327117920e-01
    z[6,4,1]  R1451     -2.1572041511535645e-01
    z[6,4,1]  R1452     -7.3871570825576782e-01
    z[6,4,1]  R1453     -7.3048555850982666e-01
    z[6,4,1]  R1454     -6.9063276052474976e-01
    z[6,4,1]  R1455     -4.0086838603019714e-01
    z[6,4,1]  R1456     -8.0846118927001953e-01
    z[6,4,1]  R1457     -0.766937255859375
    z[6,4,1]  R1458     3.8483718037605286e-01
    z[6,4,1]  R1459     3.0647650361061096e-01
    z[6,4,1]  R1460     4.7750377655029297e-01
    z[6,4,1]  R1461     7.7439749240875244e-01
    z[6,4,1]  R1462     7.8351211547851562e-01
    z[6,4,1]  R1463     7.4697548151016235e-01
    z[6,4,1]  R1464     0.796562671661377
    z[6,4,1]  R1465     8.8279730081558228e-01
    z[6,4,1]  R1466     8.9820599555969238e-01
    z[6,4,1]  R1467     5.1838332414627075e-01
    z[6,4,1]  R1468     5.8870565891265869e-01
    z[6,4,1]  R1469     5.4523938894271851e-01
    z[6,4,1]  R1470     5.5945807695388794e-01
    z[6,4,1]  R1471     -1.0856576263904572e-01
    z[6,4,1]  R1472     1.3602754473686218e-01
    z[6,4,1]  R1473     -2.1678301692008972e-01
    z[6,4,1]  R1474     5.0889525562524796e-02
    z[6,4,1]  R1475     1.0282338410615921e-01
    z[6,4,1]  R1476     3.7497210502624512e-01
    z[6,4,1]  R1477     0.122503861784935
    z[6,4,1]  R1478     4.6388339251279831e-02
    z[6,4,1]  R1479     6.4730048179626465e-02
    z[6,4,1]  R1480     4.2699292302131653e-01
    z[6,4,1]  R1481     -8.9471697807312012e-01
    z[6,4,1]  R1482     -8.8038235902786255e-01
    z[6,4,1]  R1483     -8.2952016592025757e-01
    z[6,4,1]  R1484     3.6464259028434753e-02
    z[6,4,1]  R1485     4.4890657067298889e-01
    z[6,4,1]  R1486     -9.4527572393417358e-01
    z[6,4,1]  R1487     -9.1798186302185059e-01
    z[6,4,1]  R1488     -8.9208728075027466e-01
    z[6,4,1]  R1489     -8.6514890193939209e-01
    z[6,4,1]  R1490     -8.3336752653121948e-01
    z[6,4,1]  R1491     -8.1203687191009521e-01
    z[6,4,1]  R1492     -5.5051195621490479e-01
    z[6,4,1]  R1493     -9.1903531551361084e-01
    z[6,4,1]  R1494     -8.1354314088821411e-01
    z[6,4,1]  R1495     -3.8258321583271027e-02
    z[6,4,1]  R1496     -9.3632888793945312e-01
    z[6,4,1]  R1497     -9.2413526773452759e-01
    z[6,4,1]  R1498     -8.6651885509490967e-01
    z[6,4,1]  R1499     -8.0911898612976074e-01
    z[6,4,1]  R1500     -8.6442202329635620e-01
    z[6,4,1]  R1501     -8.4205752611160278e-01
    z[6,4,1]  R1502     -0.888372004032135
    z[6,4,1]  R1503     -8.2396632432937622e-01
    z[6,4,1]  R1504     -9.3639492988586426e-01
    z[6,4,1]  R1505     -2.1814670413732529e-02
    z[6,4,1]  R1506     7.0344597101211548e-02
    z[6,4,1]  R1507     4.2119896411895752e-01
    z[6,4,1]  R1508     2.9502192139625549e-01
    z[6,4,1]  R1509     -0.842427670955658
    z[6,4,1]  R1510     -8.9654362201690674e-01
    z[6,4,1]  R1511     -8.8176757097244263e-01
    z[6,4,1]  R1512     -0.814807116985321
    z[6,4,1]  R1513     -7.9867547750473022e-01
    z[6,4,1]  R1514     -7.8840601444244385e-01
    z[6,4,1]  R1515     2.8742921352386475e-01
    z[6,4,1]  R1516     2.4879592657089233e-01
    z[6,4,1]  R1517     1.9900441169738770e-01
    z[6,4,1]  R1518     -8.9389944076538086e-01
    z[6,4,1]  R1519     -8.6115521192550659e-01
    z[6,4,1]  R1520     -8.2163053750991821e-01
    z[6,4,1]  R1521     -3.8869503140449524e-01
    z[6,4,1]  R1522     -5.9901064634323120e-01
    z[6,4,1]  R1523     -4.6669882535934448e-01
    z[6,4,1]  R1524     -7.2935229539871216e-01
    z[6,4,2]  R40       1
    z[6,4,2]  R58       -1
    z[6,4,2]  R1415     -1
    z[6,4,2]  R1416     1
    z[6,4,2]  R1425     -0.560208797454834
    z[6,4,2]  R1426     -4.3954044580459595e-01
    z[6,4,2]  R1427     -3.0679419636726379e-01
    z[6,4,2]  R1428     -4.7865721583366394e-01
    z[6,4,2]  R1429     -3.0638018250465393e-01
    z[6,4,2]  R1430     -1.2894614040851593e-01
    z[6,4,2]  R1431     -2.9435306787490845e-01
    z[6,4,2]  R1432     -6.0012418776750565e-02
    z[6,4,2]  R1433     -1.3119670748710632e-01
    z[6,4,2]  R1434     2.3547196388244629e-01
    z[6,4,2]  R1435     -5.2362614870071411e-01
    z[6,4,2]  R1436     -0.438385546207428
    z[6,4,2]  R1437     -5.9539139270782471e-01
    z[6,4,2]  R1438     3.5121065378189087e-01
    z[6,4,2]  R1439     5.2069473266601562e-01
    z[6,4,2]  R1440     2.0645692944526672e-02
    z[6,4,2]  R1441     6.0132515430450439e-01
    z[6,4,2]  R1442     5.5767655372619629e-01
    z[6,4,2]  R1443     4.3703210353851318e-01
    z[6,4,2]  R1444     4.5359331369400024e-01
    z[6,4,2]  R1445     -4.8705145716667175e-01
    z[6,4,2]  R1446     4.6946480870246887e-01
    z[6,4,2]  R1447     2.7474248409271240e-01
    z[6,4,2]  R1448     5.8647930622100830e-01
    z[6,4,2]  R1449     3.6668869853019714e-01
    z[6,4,2]  R1450     3.1894814968109131e-01
    z[6,4,2]  R1451     2.6994487643241882e-01
    z[6,4,2]  R1452     4.6839416027069092e-01
    z[6,4,2]  R1453     0.56394362449646
    z[6,4,2]  R1454     4.9780625104904175e-01
    z[6,4,2]  R1455     -1.2506563961505890e-01
    z[6,4,2]  R1456     4.0509355068206787e-01
    z[6,4,2]  R1457     4.4223695993423462e-01
    z[6,4,2]  R1458     2.4276073276996613e-01
    z[6,4,2]  R1459     2.3418653011322021e-01
    z[6,4,2]  R1460     1.7361932992935181e-01
    z[6,4,2]  R1461     3.7193521857261658e-01
    z[6,4,2]  R1462     2.2485843300819397e-01
    z[6,4,2]  R1463     5.1996129751205444e-01
    z[6,4,2]  R1464     -3.6978565156459808e-02
    z[6,4,2]  R1465     6.7431636154651642e-02
    z[6,4,2]  R1466     1.5567451715469360e-01
    z[6,4,2]  R1467     9.1799996793270111e-02
    z[6,4,2]  R1468     -7.2012418508529663e-01
    z[6,4,2]  R1469     -6.9533628225326538e-01
    z[6,4,2]  R1470     -4.1551807522773743e-01
    z[6,4,2]  R1471     -2.8524732589721680e-01
    z[6,4,2]  R1472     -1.3848823308944702e-01
    z[6,4,2]  R1473     -3.6783429980278015e-01
    z[6,4,2]  R1474     -1.7657396197319031e-01
    z[6,4,2]  R1475     8.4021437168121338e-01
    z[6,4,2]  R1476     2.8355118632316589e-01
    z[6,4,2]  R1477     4.9967566132545471e-01
    z[6,4,2]  R1478     4.6472790837287903e-01
    z[6,4,2]  R1479     8.4655404090881348e-01
    z[6,4,2]  R1480     6.6695623099803925e-02
    z[6,4,2]  R1481     -1.8805885314941406e-01
    z[6,4,2]  R1482     -0.0760580450296402
    z[6,4,2]  R1483     -1.6840463876724243e-01
    z[6,4,2]  R1484     6.3653844594955444e-01
    z[6,4,2]  R1485     9.5905712805688381e-04
    z[6,4,2]  R1486     -2.5765869021415710e-01
    z[6,4,2]  R1487     1.9793811440467834e-01
    z[6,4,2]  R1488     8.2529969513416290e-02
    z[6,4,2]  R1489     3.0190202593803406e-01
    z[6,4,2]  R1490     3.1279298663139343e-01
    z[6,4,2]  R1491     -0.0842321366071701
    z[6,4,2]  R1492     -4.0897119045257568e-01
    z[6,4,2]  R1493     -1.3384819030761719e-01
    z[6,4,2]  R1494     -9.7464453428983688e-03
    z[6,4,2]  R1495     2.5798752903938293e-02
    z[6,4,2]  R1496     1.9758033752441406e-01
    z[6,4,2]  R1497     -3.5061892122030258e-02
    z[6,4,2]  R1498     5.4388329386711121e-02
    z[6,4,2]  R1499     -1.8867659568786621e-01
    z[6,4,2]  R1500     7.1011655032634735e-02
    z[6,4,2]  R1501     2.8882932662963867e-01
    z[6,4,2]  R1502     -2.2510716319084167e-01
    z[6,4,2]  R1503     1.8280208110809326e-01
    z[6,4,2]  R1504     1.8073084950447083e-01
    z[6,4,2]  R1505     3.6547788977622986e-01
    z[6,4,2]  R1506     7.0659118890762329e-01
    z[6,4,2]  R1507     -8.2825394347310066e-03
    z[6,4,2]  R1508     4.5111495256423950e-01
    z[6,4,2]  R1509     8.0974452197551727e-02
    z[6,4,2]  R1510     -2.9770871996879578e-01
    z[6,4,2]  R1511     8.1429913640022278e-02
    z[6,4,2]  R1512     9.3797542154788971e-02
    z[6,4,2]  R1513     -4.2805038392543793e-02
    z[6,4,2]  R1514     3.6200657486915588e-02
    z[6,4,2]  R1515     4.8477512598037720e-01
    z[6,4,2]  R1516     -7.6532892882823944e-02
    z[6,4,2]  R1517     5.3832525014877319e-01
    z[6,4,2]  R1518     3.4502517431974411e-02
    z[6,4,2]  R1519     1.4597199857234955e-01
    z[6,4,2]  R1520     -2.9339563846588135e-01
    z[6,4,2]  R1521     -7.7600318193435669e-01
    z[6,4,2]  R1522     -6.7623686790466309e-01
    z[6,4,2]  R1523     -7.2706836462020874e-01
    z[6,4,2]  R1524     -2.1004046499729156e-01
    z[6,4,3]  R41       1
    z[6,4,3]  R59       -1
    z[6,4,3]  R1417     -1
    z[6,4,3]  R1418     1
    z[6,4,3]  R1425     7.3736059665679932e-01
    z[6,4,3]  R1426     2.4496375024318695e-01
    z[6,4,3]  R1427     2.7197441458702087e-01
    z[6,4,3]  R1428     5.6444466114044189e-01
    z[6,4,3]  R1429     2.1162256598472595e-01
    z[6,4,3]  R1430     7.8199088573455811e-01
    z[6,4,3]  R1431     8.8519737124443054e-02
    z[6,4,3]  R1432     3.7660104036331177e-01
    z[6,4,3]  R1433     5.6421411037445068e-01
    z[6,4,3]  R1434     5.9436100721359253e-01
    z[6,4,3]  R1435     -2.2799010574817657e-01
    z[6,4,3]  R1436     -2.5736156105995178e-01
    z[6,4,3]  R1437     -5.4242026805877686e-01
    z[6,4,3]  R1438     -2.6262211799621582e-01
    z[6,4,3]  R1439     -3.8348857313394547e-02
    z[6,4,3]  R1440     -2.9589679837226868e-01
    z[6,4,3]  R1441     -3.0975860357284546e-01
    z[6,4,3]  R1442     -2.8315034508705139e-01
    z[6,4,3]  R1443     -3.3291906118392944e-01
    z[6,4,3]  R1444     -3.2870528101921082e-01
    z[6,4,3]  R1445     -6.7682260274887085e-01
    z[6,4,3]  R1446     4.9128532409667969e-01
    z[6,4,3]  R1447     6.4742344617843628e-01
    z[6,4,3]  R1448     -2.0186990499496460e-01
    z[6,4,3]  R1449     3.9293374866247177e-02
    z[6,4,3]  R1450     2.5785389542579651e-01
    z[6,4,3]  R1451     -2.4777875840663910e-01
    z[6,4,3]  R1452     -1.5962266921997070e-01
    z[6,4,3]  R1453     -2.1654102206230164e-01
    z[6,4,3]  R1454     -2.8818780183792114e-01
    z[6,4,3]  R1455     -3.1955018639564514e-01
    z[6,4,3]  R1456     -0.0674697533249855
    z[6,4,3]  R1457     -3.9962741732597351e-01
    z[6,4,3]  R1458     -3.4626686573028564e-01
    z[6,4,3]  R1459     -3.3625563979148865e-01
    z[6,4,3]  R1460     -3.5481536388397217e-01
    z[6,4,3]  R1461     -2.6597523689270020e-01
    z[6,4,3]  R1462     -1.3726912438869476e-01
    z[6,4,3]  R1463     -4.0699992328882217e-02
    z[6,4,3]  R1464     -2.2174143791198730e-01
    z[6,4,3]  R1465     1.1516990512609482e-01
    z[6,4,3]  R1466     3.2431280612945557e-01
    z[6,4,3]  R1467     -2.0396200940012932e-02
    z[6,4,3]  R1468     1.1635913699865341e-01
    z[6,4,3]  R1469     8.8614434003829956e-02
    z[6,4,3]  R1470     -4.9735743552446365e-02
    z[6,4,3]  R1471     1.7283445596694946e-01
    z[6,4,3]  R1472     3.2775089144706726e-01
    z[6,4,3]  R1473     2.1331556141376495e-01
    z[6,4,3]  R1474     4.2960166931152344e-01
    z[6,4,3]  R1475     -3.4326744079589844e-01
    z[6,4,3]  R1476     -7.0934981107711792e-01
    z[6,4,3]  R1477     -3.1899097561836243e-01
    z[6,4,3]  R1478     -6.1695091426372528e-02
    z[6,4,3]  R1479     1.6761821508407593e-01
    z[6,4,3]  R1480     1.9978480041027069e-01
    z[6,4,3]  R1481     1.8895334005355835e-01
    z[6,4,3]  R1482     -7.9344063997268677e-02
    z[6,4,3]  R1483     5.0925098359584808e-02
    z[6,4,3]  R1484     -1.7422821372747421e-02
    z[6,4,3]  R1485     1.1696402914822102e-02
    z[6,4,3]  R1486     -1.2717632949352264e-01
    z[6,4,3]  R1487     -4.6137967146933079e-03
    z[6,4,3]  R1488     -2.5225919485092163e-01
    z[6,4,3]  R1489     5.6858994066715240e-02
    z[6,4,3]  R1490     -2.6485204696655273e-01
    z[6,4,3]  R1491     -5.9067141264677048e-02
    z[6,4,3]  R1492     0.577458918094635
    z[6,4,3]  R1493     2.4416531622409821e-01
    z[6,4,3]  R1494     4.3209555745124817e-01
    z[6,4,3]  R1495     -5.9953224658966064e-01
    z[6,4,3]  R1496     -7.7092565596103668e-02
    z[6,4,3]  R1497     -1.5031945705413818e-01
    z[6,4,3]  R1498     -1.7512956261634827e-01
    z[6,4,3]  R1499     3.2055267691612244e-01
    z[6,4,3]  R1500     4.5226126909255981e-01
    z[6,4,3]  R1501     2.7695652842521667e-01
    z[6,4,3]  R1502     -4.8354491591453552e-02
    z[6,4,3]  R1503     2.9866832494735718e-01
    z[6,4,3]  R1504     1.8614947795867920e-01
    z[6,4,3]  R1505     -4.7284394502639771e-01
    z[6,4,3]  R1506     1.2677592039108276e-01
    z[6,4,3]  R1507     -1.4143761992454529e-01
    z[6,4,3]  R1508     -4.3483623862266541e-01
    z[6,4,3]  R1509     2.1898582577705383e-01
    z[6,4,3]  R1510     1.0630187392234802e-01
    z[6,4,3]  R1511     2.1172007918357849e-01
    z[6,4,3]  R1512     3.3912602066993713e-01
    z[6,4,3]  R1513     5.2484345436096191e-01
    z[6,4,3]  R1514     3.1216824054718018e-01
    z[6,4,3]  R1515     3.7200883030891418e-01
    z[6,4,3]  R1516     9.9150486290454865e-02
    z[6,4,3]  R1517     1.4972022175788879e-01
    z[6,4,3]  R1518     1.7892074584960938e-01
    z[6,4,3]  R1519     1.5810623764991760e-01
    z[6,4,3]  R1520     2.3697124421596527e-01
    z[6,4,3]  R1521     -1.4373597502708435e-01
    z[6,4,3]  R1522     -2.0813571289181709e-02
    z[6,4,3]  R1523     1.5533900260925293e-01
    z[6,4,3]  R1524     7.3797397315502167e-02
    z[6,4,4]  R42       1
    z[6,4,4]  R60       -1
    z[6,4,4]  R1419     -1
    z[6,4,4]  R1420     1
    z[6,4,4]  R1425     -1.4335820078849792e-01
    z[6,4,4]  R1426     -1.8840160965919495e-01
    z[6,4,4]  R1427     -6.8485051393508911e-01
    z[6,4,4]  R1428     -2.5238949060440063e-01
    z[6,4,4]  R1429     -6.9705463945865631e-02
    z[6,4,4]  R1430     -2.0170746371150017e-02
    z[6,4,4]  R1431     -1.4854730665683746e-01
    z[6,4,4]  R1432     -7.6145190000534058e-01
    z[6,4,4]  R1433     1.9435827434062958e-01
    z[6,4,4]  R1434     8.6991004645824432e-02
    z[6,4,4]  R1435     2.6194646954536438e-01
    z[6,4,4]  R1436     -0.0992252379655838
    z[6,4,4]  R1437     2.4288235604763031e-01
    z[6,4,4]  R1438     -1.8302644789218903e-01
    z[6,4,4]  R1439     -6.6127941012382507e-02
    z[6,4,4]  R1440     2.5026535987854004e-01
    z[6,4,4]  R1441     -1.9430282711982727e-01
    z[6,4,4]  R1442     5.0300270318984985e-01
    z[6,4,4]  R1443     6.9137299060821533e-01
    z[6,4,4]  R1444     5.7457500696182251e-01
    z[6,4,4]  R1445     -4.6021699905395508e-01
    z[6,4,4]  R1446     1.0321640968322754e-01
    z[6,4,4]  R1447     1.9517336785793304e-01
    z[6,4,4]  R1448     2.2953076288104057e-02
    z[6,4,4]  R1449     3.7811064720153809e-01
    z[6,4,4]  R1450     3.3351635932922363e-01
    z[6,4,4]  R1451     0.510429859161377
    z[6,4,4]  R1452     -2.8141397982835770e-02
    z[6,4,4]  R1453     1.0243520140647888e-01
    z[6,4,4]  R1454     -6.0386221855878830e-02
    z[6,4,4]  R1455     -0.518736720085144
    z[6,4,4]  R1456     2.2828787565231323e-02
    z[6,4,4]  R1457     8.2920975983142853e-03
    z[6,4,4]  R1458     4.2705839872360229e-01
    z[6,4,4]  R1459     2.9318472743034363e-01
    z[6,4,4]  R1460     7.0638722181320190e-01
    z[6,4,4]  R1461     3.9679402112960815e-01
    z[6,4,4]  R1462     3.3010202646255493e-01
    z[6,4,4]  R1463     1.8786674365401268e-02
    z[6,4,4]  R1464     1.2044016271829605e-01
    z[6,4,4]  R1465     1.9727703928947449e-01
    z[6,4,4]  R1466     -1.5441924333572388e-01
    z[6,4,4]  R1467     -0.753320038318634
    z[6,4,4]  R1468     1.1484218388795853e-01
    z[6,4,4]  R1469     -5.3371128160506487e-04
    z[6,4,4]  R1470     -7.0962566137313843e-01
    z[6,4,4]  R1471     -2.0088282227516174e-01
    z[6,4,4]  R1472     -3.2505291700363159e-01
    z[6,4,4]  R1473     -6.0996998101472855e-02
    z[6,4,4]  R1474     2.0736807957291603e-02
    z[6,4,4]  R1475     3.2866573333740234e-01
    z[6,4,4]  R1476     3.8796129822731018e-01
    z[6,4,4]  R1477     1.7747510969638824e-01
    z[6,4,4]  R1478     5.6861841678619385e-01
    z[6,4,4]  R1479     1.2420850992202759e-01
    z[6,4,4]  R1480     4.2864728718996048e-02
    z[6,4,4]  R1481     -1.3347423076629639e-01
    z[6,4,4]  R1482     4.1570693254470825e-01
    z[6,4,4]  R1483     2.5823217630386353e-01
    z[6,4,4]  R1484     -3.1981033086776733e-01
    z[6,4,4]  R1485     2.4458529055118561e-01
    z[6,4,4]  R1486     -0.0643736943602562
    z[6,4,4]  R1487     -1.4105857908725739e-01
    z[6,4,4]  R1488     2.8672186657786369e-02
    z[6,4,4]  R1489     -3.5256387200206518e-03
    z[6,4,4]  R1490     -9.0861216187477112e-02
    z[6,4,4]  R1491     -1.7767642438411713e-01
    z[6,4,4]  R1492     -3.8526263833045959e-01
    z[6,4,4]  R1493     -2.2214479744434357e-02
    z[6,4,4]  R1494     -1.0918529331684113e-01
    z[6,4,4]  R1495     -3.1989240646362305e-01
    z[6,4,4]  R1496     7.2579570114612579e-02
    z[6,4,4]  R1497     2.8426715731620789e-01
    z[6,4,4]  R1498     -3.4772685170173645e-01
    z[6,4,4]  R1499     1.4275148510932922e-01
    z[6,4,4]  R1500     -1.9971360266208649e-01
    z[6,4,4]  R1501     1.9227384030818939e-01
    z[6,4,4]  R1502     2.8355914354324341e-01
    z[6,4,4]  R1503     3.6364585161209106e-01
    z[6,4,4]  R1504     0.0623299777507782
    z[6,4,4]  R1505     5.4575152695178986e-02
    z[6,4,4]  R1506     -2.1897906064987183e-01
    z[6,4,4]  R1507     -0.252566397190094
    z[6,4,4]  R1508     -5.8801096677780151e-01
    z[6,4,4]  R1509     -1.1910246312618256e-01
    z[6,4,4]  R1510     1.2385033816099167e-01
    z[6,4,4]  R1511     1.8290621042251587e-01
    z[6,4,4]  R1512     3.0379590392112732e-01
    z[6,4,4]  R1513     7.5964882969856262e-02
    z[6,4,4]  R1514     2.0483568310737610e-01
    z[6,4,4]  R1515     4.8887407779693604e-01
    z[6,4,4]  R1516     4.4355848431587219e-01
    z[6,4,4]  R1517     -5.6815481185913086e-01
    z[6,4,4]  R1518     3.8978552818298340e-01
    z[6,4,4]  R1519     2.4475511908531189e-01
    z[6,4,4]  R1520     1.7736183479428291e-02
    z[6,4,4]  R1521     -3.5304382443428040e-01
    z[6,4,4]  R1522     -3.3749529719352722e-01
    z[6,4,4]  R1523     -3.7403953075408936e-01
    z[6,4,4]  R1524     -2.0202626287937164e-01
    z[6,4,5]  R43       1
    z[6,4,5]  R61       -1
    z[6,4,5]  R1421     -1
    z[6,4,5]  R1422     1
    z[6,4,5]  R1425     6.9417193531990051e-02
    z[6,4,5]  R1426     1.5506243705749512e-01
    z[6,4,5]  R1427     3.7132057547569275e-01
    z[6,4,5]  R1428     2.1465530991554260e-01
    z[6,4,5]  R1429     1.0117302089929581e-01
    z[6,4,5]  R1430     2.5743028521537781e-01
    z[6,4,5]  R1431     -0.305356502532959
    z[6,4,5]  R1432     -1.4670735597610474e-01
    z[6,4,5]  R1433     -7.6789689064025879e-01
    z[6,4,5]  R1434     -6.5999329090118408e-01
    z[6,4,5]  R1435     4.4676882028579712e-01
    z[6,4,5]  R1436     2.8443023562431335e-01
    z[6,4,5]  R1437     3.3078234642744064e-02
    z[6,4,5]  R1438     -3.0063995718955994e-01
    z[6,4,5]  R1439     2.8809410333633423e-01
    z[6,4,5]  R1440     -0.0702296569943428
    z[6,4,5]  R1441     2.3496554791927338e-01
    z[6,4,5]  R1442     -4.1340142488479614e-02
    z[6,4,5]  R1443     4.4156956672668457e-01
    z[6,4,5]  R1444     4.3883880972862244e-01
    z[6,4,5]  R1445     -4.7935396432876587e-02
    z[6,4,5]  R1446     -5.1559843122959137e-02
    z[6,4,5]  R1447     1.7003294825553894e-01
    z[6,4,5]  R1448     -9.0687476098537445e-02
    z[6,4,5]  R1449     -2.9200930148363113e-02
    z[6,4,5]  R1450     2.5748556945472956e-03
    z[6,4,5]  R1451     -3.8776826858520508e-01
    z[6,4,5]  R1452     -3.2422986626625061e-01
    z[6,4,5]  R1453     1.9909940659999847e-02
    z[6,4,5]  R1454     -3.2066482305526733e-01
    z[6,4,5]  R1455     6.5030759572982788e-01
    z[6,4,5]  R1456     0.18819560110569
    z[6,4,5]  R1457     1.9532483071088791e-02
    z[6,4,5]  R1458     6.8907028436660767e-01
    z[6,4,5]  R1459     7.6346707344055176e-01
    z[6,4,5]  R1460     3.1301450729370117e-01
    z[6,4,5]  R1461     7.1340814232826233e-02
    z[6,4,5]  R1462     1.0498243570327759e-01
    z[6,4,5]  R1463     1.6161866486072540e-01
    z[6,4,5]  R1464     -2.5649511814117432e-01
    z[6,4,5]  R1465     -1.8966224789619446e-01
    z[6,4,5]  R1466     -8.7802886962890625e-02
    z[6,4,5]  R1467     -0.067637138068676
    z[6,4,5]  R1468     -4.5988604426383972e-02
    z[6,4,5]  R1469     -4.5047560706734657e-03
    z[6,4,5]  R1470     -3.2689280807971954e-02
    z[6,4,5]  R1471     -3.1402119994163513e-01
    z[6,4,5]  R1472     -2.1722888946533203e-01
    z[6,4,5]  R1473     1.6671134158968925e-02
    z[6,4,5]  R1474     -2.8326642513275146e-01
    z[6,4,5]  R1475     1.5485012531280518e-01
    z[6,4,5]  R1476     3.1400460004806519e-01
    z[6,4,5]  R1477     1.8866080045700073e-01
    z[6,4,5]  R1478     1.1222336441278458e-01
    z[6,4,5]  R1479     -4.7523528337478638e-01
    z[6,4,5]  R1480     -4.2120289802551270e-01
    z[6,4,5]  R1481     3.0312919989228249e-02
    z[6,4,5]  R1482     -1.0461964458227158e-01
    z[6,4,5]  R1483     -4.2417088150978088e-01
    z[6,4,5]  R1484     -6.0311728715896606e-01
    z[6,4,5]  R1485     -3.6094522476196289e-01
    z[6,4,5]  R1486     -1.3168926537036896e-01
    z[6,4,5]  R1487     6.9820769131183624e-02
    z[6,4,5]  R1488     1.6734541952610016e-01
    z[6,4,5]  R1489     -0.349232941865921
    z[6,4,5]  R1490     -1.2980429828166962e-01
    z[6,4,5]  R1491     -1.8330083787441254e-01
    z[6,4,5]  R1492     -1.6589336097240448e-01
    z[6,4,5]  R1493     6.6312126815319061e-02
    z[6,4,5]  R1494     -3.8353651762008667e-02
    z[6,4,5]  R1495     3.4753882884979248e-01
    z[6,4,5]  R1496     -1.3029731810092926e-01
    z[6,4,5]  R1497     5.8049920946359634e-02
    z[6,4,5]  R1498     0.0403253547847271
    z[6,4,5]  R1499     -2.4391652643680573e-01
    z[6,4,5]  R1500     -2.3386912420392036e-02
    z[6,4,5]  R1501     1.4532741904258728e-01
    z[6,4,5]  R1502     2.7338016033172607e-01
    z[6,4,5]  R1503     3.8393858820199966e-02
    z[6,4,5]  R1504     1.7576953768730164e-01
    z[6,4,5]  R1505     7.1508079767227173e-02
    z[6,4,5]  R1506     -3.5299065709114075e-01
    z[6,4,5]  R1507     8.2775211334228516e-01
    z[6,4,5]  R1508     1.0440965741872787e-01
    z[6,4,5]  R1509     -4.4865331053733826e-01
    z[6,4,5]  R1510     1.5884213149547577e-01
    z[6,4,5]  R1511     4.0458705276250839e-02
    z[6,4,5]  R1512     0.0845780149102211
    z[6,4,5]  R1513     -4.5434813946485519e-02
    z[6,4,5]  R1514     -1.3693729043006897e-01
    z[6,4,5]  R1515     0.0855298712849617
    z[6,4,5]  R1516     6.1912846565246582e-01
    z[6,4,5]  R1517     -1.4781183004379272e-01
    z[6,4,5]  R1518     1.0292392224073410e-01
    z[6,4,5]  R1519     2.4152073264122009e-01
    z[6,4,5]  R1520     2.0462978631258011e-02
    z[6,4,5]  R1521     2.7034100890159607e-01
    z[6,4,5]  R1522     2.2451931238174438e-01
    z[6,4,5]  R1523     2.0600913465023041e-01
    z[6,4,5]  R1524     -2.2528212517499924e-02
    z[6,4,6]  R44       1
    z[6,4,6]  R62       -1
    z[6,4,6]  R1423     -1
    z[6,4,6]  R1424     1
    z[6,4,6]  R1425     3.1279347836971283e-02
    z[6,4,6]  R1426     -1.2333748489618301e-01
    z[6,4,6]  R1427     -2.9531520605087280e-01
    z[6,4,6]  R1428     4.5990908145904541e-01
    z[6,4,6]  R1429     -6.3684183359146118e-01
    z[6,4,6]  R1430     -1.8181812763214111e-01
    z[6,4,6]  R1431     1.4404557645320892e-01
    z[6,4,6]  R1432     -5.8593165129423141e-02
    z[6,4,6]  R1433     3.1259968876838684e-02
    z[6,4,6]  R1434     2.9459765553474426e-01
    z[6,4,6]  R1435     -8.9009217917919159e-03
    z[6,4,6]  R1436     1.6101954877376556e-01
    z[6,4,6]  R1437     5.1092332601547241e-01
    z[6,4,6]  R1438     -3.2722827792167664e-01
    z[6,4,6]  R1439     -0.340950071811676
    z[6,4,6]  R1440     3.6238130927085876e-01
    z[6,4,6]  R1441     -1.6881616413593292e-01
    z[6,4,6]  R1442     2.3747469484806061e-01
    z[6,4,6]  R1443     -1.9602755084633827e-02
    z[6,4,6]  R1444     3.4779345989227295e-01
    z[6,4,6]  R1445     1.4406830072402954e-01
    z[6,4,6]  R1446     -2.4699696898460388e-01
    z[6,4,6]  R1447     1.8225048482418060e-01
    z[6,4,6]  R1448     0.104326531291008
    z[6,4,6]  R1449     -6.0234349220991135e-03
    z[6,4,6]  R1450     3.6382114887237549e-01
    z[6,4,6]  R1451     -1.3241605460643768e-01
    z[6,4,6]  R1452     3.2028988003730774e-01
    z[6,4,6]  R1453     -1.9152744114398956e-01
    z[6,4,6]  R1454     -2.9902998358011246e-02
    z[6,4,6]  R1455     -1.2477464973926544e-01
    z[6,4,6]  R1456     3.0275234580039978e-01
    z[6,4,6]  R1457     -1.3602021336555481e-01
    z[6,4,6]  R1458     2.1427385509014130e-02
    z[6,4,6]  R1459     2.4743328988552094e-01
    z[6,4,6]  R1460     -0.0496220663189888
    z[6,4,6]  R1461     3.2432243227958679e-02
    z[6,4,6]  R1462     2.0292037725448608e-01
    z[6,4,6]  R1463     3.0066993832588196e-01
    z[6,4,6]  R1464     -1.1451942473649979e-01
    z[6,4,6]  R1465     3.5725861787796021e-01
    z[6,4,6]  R1466     -1.3364584743976593e-01
    z[6,4,6]  R1467     3.8772195577621460e-01
    z[6,4,6]  R1468     -4.8938225954771042e-02
    z[6,4,6]  R1469     -4.5889008045196533e-01
    z[6,4,6]  R1470     6.0432165861129761e-02
    z[6,4,6]  R1471     -1.5530244447290897e-02
    z[6,4,6]  R1472     4.6107780188322067e-02
    z[6,4,6]  R1473     -2.0385617017745972e-01
    z[6,4,6]  R1474     1.7365282773971558e-01
    z[6,4,6]  R1475     -6.3380233943462372e-02
    z[6,4,6]  R1476     -1.2486694753170013e-01
    z[6,4,6]  R1477     -7.1028012037277222e-01
    z[6,4,6]  R1478     -5.5898189544677734e-01
    z[6,4,6]  R1479     -8.3008259534835815e-02
    z[6,4,6]  R1480     -2.5063201785087585e-01
    z[6,4,6]  R1481     -0.0890025720000267
    z[6,4,6]  R1482     -1.6875582933425903e-01
    z[6,4,6]  R1483     1.7634356021881104e-01
    z[6,4,6]  R1484     1.9689792394638062e-01
    z[6,4,6]  R1485     -1.5362252295017242e-01
    z[6,4,6]  R1486     3.7762913852930069e-02
    z[6,4,6]  R1487     -1.8423174321651459e-01
    z[6,4,6]  R1488     3.1699728965759277e-01
    z[6,4,6]  R1489     -0.0688420757651329
    z[6,4,6]  R1490     2.5477710366249084e-01
    z[6,4,6]  R1491     -5.1449424028396606e-01
    z[6,4,6]  R1492     3.2861515879631042e-02
    z[6,4,6]  R1493     -4.3765522539615631e-02
    z[6,4,6]  R1494     -2.4215854704380035e-01
    z[6,4,6]  R1495     2.3911017179489136e-01
    z[6,4,6]  R1496     5.1108323037624359e-02
    z[6,4,6]  R1497     -1.1741942912340164e-01
    z[6,4,6]  R1498     -1.5337510406970978e-01
    z[6,4,6]  R1499     -3.4810605645179749e-01
    z[6,4,6]  R1500     1.2059990316629410e-02
    z[6,4,6]  R1501     -1.7385342717170715e-01
    z[6,4,6]  R1502     -1.3387300074100494e-02
    z[6,4,6]  R1503     -2.3169608414173126e-01
    z[6,4,6]  R1504     -1.4494709670543671e-01
    z[6,4,6]  R1505     1.4631895720958710e-01
    z[6,4,6]  R1506     3.5688430070877075e-01
    z[6,4,6]  R1507     1.8671859055757523e-02
    z[6,4,6]  R1508     -1.4046387374401093e-01
    z[6,4,6]  R1509     -5.2591826766729355e-02
    z[6,4,6]  R1510     -5.9016954153776169e-02
    z[6,4,6]  R1511     -1.4667728543281555e-01
    z[6,4,6]  R1512     7.6553061604499817e-02
    z[6,4,6]  R1513     -2.6487118005752563e-01
    z[6,4,6]  R1514     4.2527332901954651e-01
    z[6,4,6]  R1515     -4.4908666610717773e-01
    z[6,4,6]  R1516     3.6136223934590816e-03
    z[6,4,6]  R1517     -4.3110698461532593e-01
    z[6,4,6]  R1518     7.2128519415855408e-02
    z[6,4,6]  R1519     -1.2996993958950043e-01
    z[6,4,6]  R1520     4.2649745941162109e-01
    z[6,4,6]  R1521     -7.5684264302253723e-02
    z[6,4,6]  R1522     1.0512106865644455e-01
    z[6,4,6]  R1523     -2.1033169329166412e-01
    z[6,4,6]  R1524     0.22533018887043
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1525     -1
    z[5,6,0]  R1526     1
    z[5,6,0]  R1539     1.4367249608039856e-01
    z[5,6,0]  R1540     9.6836224198341370e-02
    z[5,6,0]  R1541     -9.1374427080154419e-02
    z[5,6,0]  R1542     -1.2036441266536713e-01
    z[5,6,0]  R1543     7.7137142419815063e-02
    z[5,6,0]  R1544     -1.8016014993190765e-01
    z[5,6,0]  R1545     -1.3040290772914886e-01
    z[5,6,0]  R1546     3.2169858459383249e-03
    z[5,6,0]  R1547     4.2814472317695618e-01
    z[5,6,0]  R1548     -1.3561758399009705e-01
    z[5,6,0]  R1549     -1.9953235983848572e-01
    z[5,6,0]  R1550     -1.5464584529399872e-01
    z[5,6,0]  R1551     -7.9916212707757950e-03
    z[5,6,0]  R1552     4.1941270232200623e-02
    z[5,6,0]  R1553     -5.7299101352691650e-01
    z[5,6,0]  R1554     -6.6932633519172668e-02
    z[5,6,0]  R1555     2.0704032853245735e-02
    z[5,6,0]  R1556     -4.8795364797115326e-02
    z[5,6,0]  R1557     -2.0290263928472996e-03
    z[5,6,0]  R1558     2.0917126536369324e-01
    z[5,6,0]  R1559     -1.2074116617441177e-01
    z[5,6,0]  R1560     -1.7033240199089050e-01
    z[5,6,0]  R1561     -1.2313283979892731e-01
    z[5,6,0]  R1562     -3.0875965952873230e-02
    z[5,6,0]  R1563     8.8018581271171570e-02
    z[5,6,0]  R1564     3.3534996211528778e-02
    z[5,6,0]  R1565     3.1025785207748413e-01
    z[5,6,0]  R1566     -5.4954189807176590e-02
    z[5,6,0]  R1567     -2.0206263661384583e-01
    z[5,6,0]  R1568     3.8460159301757812e-01
    z[5,6,0]  R1569     -8.2343824207782745e-02
    z[5,6,0]  R1570     -1.0563597828149796e-01
    z[5,6,0]  R1571     -1.5603317320346832e-01
    z[5,6,0]  R1572     -7.3864096403121948e-01
    z[5,6,0]  R1573     -6.9027908146381378e-02
    z[5,6,0]  R1574     -4.0976423770189285e-02
    z[5,6,0]  R1575     -3.2495218515396118e-01
    z[5,6,0]  R1576     -3.3865779638290405e-01
    z[5,6,0]  R1577     -1.5645249187946320e-01
    z[5,6,0]  R1578     -8.5378557443618774e-02
    z[5,6,0]  R1579     9.2741541564464569e-02
    z[5,6,0]  R1580     -1.2282628566026688e-01
    z[5,6,0]  R1581     -6.9633579254150391e-01
    z[5,6,0]  R1582     3.3384156227111816e-01
    z[5,6,0]  R1583     -1.2994219362735748e-01
    z[5,6,0]  R1584     9.7509376704692841e-02
    z[5,6,0]  R1585     -3.1440767645835876e-01
    z[5,6,0]  R1586     -7.5987897813320160e-02
    z[5,6,0]  R1587     -2.1686081588268280e-01
    z[5,6,0]  R1588     5.2467696368694305e-02
    z[5,6,0]  R1589     -7.6238703727722168e-01
    z[5,6,0]  R1590     -1.4882014691829681e-01
    z[5,6,0]  R1591     4.7597482800483704e-01
    z[5,6,0]  R1592     8.9614480733871460e-01
    z[5,6,0]  R1593     9.1532504558563232e-01
    z[5,6,0]  R1594     8.8304710388183594e-01
    z[5,6,0]  R1595     8.7570029497146606e-01
    z[5,6,0]  R1596     8.6964684724807739e-01
    z[5,6,0]  R1597     -3.4049317240715027e-01
    z[5,6,0]  R1598     -6.3429397344589233e-01
    z[5,6,0]  R1599     -3.6248835921287537e-01
    z[5,6,0]  R1600     -3.5702109336853027e-01
    z[5,6,0]  R1601     -6.6193765401840210e-01
    z[5,6,0]  R1602     -5.0425916910171509e-01
    z[5,6,0]  R1603     -7.4791139364242554e-01
    z[5,6,0]  R1604     -4.9772980809211731e-01
    z[5,6,0]  R1605     3.8281381130218506e-02
    z[5,6,0]  R1606     2.4762129783630371e-01
    z[5,6,0]  R1607     3.6441591382026672e-01
    z[5,6,0]  R1608     4.7362810373306274e-01
    z[5,6,0]  R1609     1.6266094148159027e-01
    z[5,6,0]  R1610     5.5636501312255859e-01
    z[5,6,0]  R1611     6.0811895132064819e-01
    z[5,6,0]  R1612     -4.3223667144775391e-01
    z[5,6,0]  R1613     -8.9919343590736389e-02
    z[5,6,0]  R1614     1.3340255618095398e-01
    z[5,6,0]  R1615     -1.4150561392307281e-01
    z[5,6,0]  R1616     -2.0386894047260284e-01
    z[5,6,0]  R1617     -1.4164708554744720e-01
    z[5,6,0]  R1618     2.2895674407482147e-01
    z[5,6,0]  R1619     5.8498895168304443e-01
    z[5,6,0]  R1620     7.5233328342437744e-01
    z[5,6,0]  R1621     -2.8807312250137329e-01
    z[5,6,0]  R1622     -1.7447084188461304e-01
    z[5,6,0]  R1623     6.2511068582534790e-01
    z[5,6,0]  R1624     -3.0400281772017479e-02
    z[5,6,0]  R1625     -2.3215585947036743e-01
    z[5,6,0]  R1626     -2.9119861125946045e-01
    z[5,6,0]  R1627     1.1829664558172226e-01
    z[5,6,0]  R1628     -2.2391916811466217e-01
    z[5,6,0]  R1629     -1.9385483860969543e-01
    z[5,6,0]  R1630     1.2414071708917618e-01
    z[5,6,0]  R1631     -8.9991658926010132e-02
    z[5,6,0]  R1632     -1.2856583297252655e-01
    z[5,6,0]  R1633     1.6626198589801788e-01
    z[5,6,0]  R1634     3.9438480138778687e-01
    z[5,6,0]  R1635     2.3051121830940247e-01
    z[5,6,0]  R1636     4.7068125009536743e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1527     -1
    z[5,6,1]  R1528     1
    z[5,6,1]  R1539     -1.7200057208538055e-01
    z[5,6,1]  R1540     4.0754759684205055e-03
    z[5,6,1]  R1541     1.0573843028396368e-03
    z[5,6,1]  R1542     -1.6342546045780182e-01
    z[5,6,1]  R1543     0.474097341299057
    z[5,6,1]  R1544     -7.5184464454650879e-02
    z[5,6,1]  R1545     6.0491126775741577e-01
    z[5,6,1]  R1546     1.5866902470588684e-01
    z[5,6,1]  R1547     -7.7959084510803223e-01
    z[5,6,1]  R1548     -8.6356341838836670e-01
    z[5,6,1]  R1549     -7.9793006181716919e-01
    z[5,6,1]  R1550     -0.864427924156189
    z[5,6,1]  R1551     -8.0960261821746826e-01
    z[5,6,1]  R1552     -9.0707629919052124e-01
    z[5,6,1]  R1553     2.5930488109588623e-01
    z[5,6,1]  R1554     2.3826844990253448e-01
    z[5,6,1]  R1555     -8.6427938938140869e-01
    z[5,6,1]  R1556     -8.6776155233383179e-01
    z[5,6,1]  R1557     -0.931408703327179
    z[5,6,1]  R1558     -8.4530013799667358e-01
    z[5,6,1]  R1559     -8.3708190917968750e-01
    z[5,6,1]  R1560     -8.6308616399765015e-01
    z[5,6,1]  R1561     -0.0401635617017746
    z[5,6,1]  R1562     -1.2885574996471405e-01
    z[5,6,1]  R1563     2.1168453991413116e-01
    z[5,6,1]  R1564     4.1205409914255142e-02
    z[5,6,1]  R1565     -1.0249330103397369e-01
    z[5,6,1]  R1566     1.6594892740249634e-01
    z[5,6,1]  R1567     -6.9532161951065063e-01
    z[5,6,1]  R1568     2.3633906245231628e-01
    z[5,6,1]  R1569     4.0792447328567505e-01
    z[5,6,1]  R1570     2.8059142827987671e-01
    z[5,6,1]  R1571     4.2804378271102905e-01
    z[5,6,1]  R1572     -6.7567661404609680e-02
    z[5,6,1]  R1573     1.0781825333833694e-01
    z[5,6,1]  R1574     1.6846668720245361e-01
    z[5,6,1]  R1575     0.685014009475708
    z[5,6,1]  R1576     5.6257504224777222e-01
    z[5,6,1]  R1577     -7.9387080669403076e-01
    z[5,6,1]  R1578     -7.6158392429351807e-01
    z[5,6,1]  R1579     -6.4522135257720947e-01
    z[5,6,1]  R1580     2.4340584874153137e-01
    z[5,6,1]  R1581     5.0495165586471558e-01
    z[5,6,1]  R1582     -3.1800780445337296e-02
    z[5,6,1]  R1583     -4.0371179580688477e-02
    z[5,6,1]  R1584     -2.3372535407543182e-01
    z[5,6,1]  R1585     7.0987462997436523e-01
    z[5,6,1]  R1586     2.3280377686023712e-01
    z[5,6,1]  R1587     -8.0311816930770874e-01
    z[5,6,1]  R1588     -3.8023620843887329e-01
    z[5,6,1]  R1589     2.4064344167709351e-01
    z[5,6,1]  R1590     2.9533258080482483e-01
    z[5,6,1]  R1591     2.7576693892478943e-01
    z[5,6,1]  R1592     2.8850775957107544e-01
    z[5,6,1]  R1593     2.5768095254898071e-01
    z[5,6,1]  R1594     2.7619701623916626e-01
    z[5,6,1]  R1595     1.7701391875743866e-01
    z[5,6,1]  R1596     1.6462750732898712e-01
    z[5,6,1]  R1597     -1.3459932059049606e-02
    z[5,6,1]  R1598     5.1934242248535156e-01
    z[5,6,1]  R1599     -7.9995006322860718e-02
    z[5,6,1]  R1600     0.0594286248087883
    z[5,6,1]  R1601     -5.0231166183948517e-02
    z[5,6,1]  R1602     1.3360656797885895e-01
    z[5,6,1]  R1603     4.5835691690444946e-01
    z[5,6,1]  R1604     -4.5497417449951172e-02
    z[5,6,1]  R1605     -1.8592052161693573e-01
    z[5,6,1]  R1606     -5.0240028649568558e-03
    z[5,6,1]  R1607     -5.2224469184875488e-01
    z[5,6,1]  R1608     -6.3291859626770020e-01
    z[5,6,1]  R1609     -6.0845259577035904e-02
    z[5,6,1]  R1610     -5.1689177751541138e-01
    z[5,6,1]  R1611     -3.9240229129791260e-01
    z[5,6,1]  R1612     -7.2546893358230591e-01
    z[5,6,1]  R1613     -6.4258140325546265e-01
    z[5,6,1]  R1614     -5.2906662225723267e-01
    z[5,6,1]  R1615     6.9133386015892029e-02
    z[5,6,1]  R1616     -3.1099589541554451e-02
    z[5,6,1]  R1617     -2.2310295701026917e-01
    z[5,6,1]  R1618     -6.4148336648941040e-01
    z[5,6,1]  R1619     -2.5085499882698059e-01
    z[5,6,1]  R1620     -1.7219226062297821e-01
    z[5,6,1]  R1621     -7.9821836948394775e-01
    z[5,6,1]  R1622     -7.4681842327117920e-01
    z[5,6,1]  R1623     -2.1572041511535645e-01
    z[5,6,1]  R1624     -7.3871570825576782e-01
    z[5,6,1]  R1625     -7.3048555850982666e-01
    z[5,6,1]  R1626     -6.9063276052474976e-01
    z[5,6,1]  R1627     -4.0086838603019714e-01
    z[5,6,1]  R1628     -8.0846118927001953e-01
    z[5,6,1]  R1629     -0.766937255859375
    z[5,6,1]  R1630     3.8483718037605286e-01
    z[5,6,1]  R1631     3.0647650361061096e-01
    z[5,6,1]  R1632     4.7750377655029297e-01
    z[5,6,1]  R1633     7.7439749240875244e-01
    z[5,6,1]  R1634     7.8351211547851562e-01
    z[5,6,1]  R1635     7.4697548151016235e-01
    z[5,6,1]  R1636     0.796562671661377
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1529     -1
    z[5,6,2]  R1530     1
    z[5,6,2]  R1539     8.8556744158267975e-03
    z[5,6,2]  R1540     -4.8384219408035278e-01
    z[5,6,2]  R1541     -5.6739443540573120e-01
    z[5,6,2]  R1542     -8.4151841700077057e-02
    z[5,6,2]  R1543     -1.5293259918689728e-01
    z[5,6,2]  R1544     -3.2047325372695923e-01
    z[5,6,2]  R1545     -2.7669697999954224e-01
    z[5,6,2]  R1546     0.551289439201355
    z[5,6,2]  R1547     2.4917015433311462e-01
    z[5,6,2]  R1548     -1.0660753399133682e-01
    z[5,6,2]  R1549     -2.7323761582374573e-01
    z[5,6,2]  R1550     -5.8929339051246643e-02
    z[5,6,2]  R1551     1.5184928476810455e-01
    z[5,6,2]  R1552     2.3951035737991333e-01
    z[5,6,2]  R1553     6.9373279809951782e-01
    z[5,6,2]  R1554     8.3153164386749268e-01
    z[5,6,2]  R1555     0.327529639005661
    z[5,6,2]  R1556     -5.3468596190214157e-02
    z[5,6,2]  R1557     2.0595720410346985e-01
    z[5,6,2]  R1558     -1.2311632931232452e-01
    z[5,6,2]  R1559     -2.1409240365028381e-01
    z[5,6,2]  R1560     -2.5118723511695862e-01
    z[5,6,2]  R1561     9.2495280504226685e-01
    z[5,6,2]  R1562     -4.8624154925346375e-01
    z[5,6,2]  R1563     -5.2616435289382935e-01
    z[5,6,2]  R1564     -1.1939374357461929e-01
    z[5,6,2]  R1565     -2.4027542769908905e-01
    z[5,6,2]  R1566     -6.2671370804309845e-02
    z[5,6,2]  R1567     -2.0683540403842926e-01
    z[5,6,2]  R1568     -3.0107992887496948e-01
    z[5,6,2]  R1569     -3.0763953924179077e-01
    z[5,6,2]  R1570     -1.1845391988754272e-01
    z[5,6,2]  R1571     1.1871451511979103e-02
    z[5,6,2]  R1572     5.6594204902648926e-01
    z[5,6,2]  R1573     -5.9812232851982117e-02
    z[5,6,2]  R1574     1.8718820810317993e-01
    z[5,6,2]  R1575     2.4609220027923584e-01
    z[5,6,2]  R1576     5.6773293018341064e-01
    z[5,6,2]  R1577     3.8105454295873642e-02
    z[5,6,2]  R1578     3.9975973963737488e-01
    z[5,6,2]  R1579     3.0826881527900696e-01
    z[5,6,2]  R1580     -1.4743112027645111e-01
    z[5,6,2]  R1581     4.1032043099403381e-01
    z[5,6,2]  R1582     -2.8690841794013977e-01
    z[5,6,2]  R1583     -4.8879832029342651e-01
    z[5,6,2]  R1584     7.2914361953735352e-01
    z[5,6,2]  R1585     2.8350222110748291e-01
    z[5,6,2]  R1586     -4.6937850117683411e-01
    z[5,6,2]  R1587     -2.3408372700214386e-01
    z[5,6,2]  R1588     -9.8009787499904633e-02
    z[5,6,2]  R1589     5.1663786172866821e-01
    z[5,6,2]  R1590     9.0008443593978882e-01
    z[5,6,2]  R1591     -4.3937939405441284e-01
    z[5,6,2]  R1592     1.7338788509368896e-01
    z[5,6,2]  R1593     1.9356388598680496e-02
    z[5,6,2]  R1594     2.2289606928825378e-01
    z[5,6,2]  R1595     3.6890214681625366e-01
    z[5,6,2]  R1596     3.0789998173713684e-01
    z[5,6,2]  R1597     -0.560208797454834
    z[5,6,2]  R1598     -4.3954044580459595e-01
    z[5,6,2]  R1599     -3.0679419636726379e-01
    z[5,6,2]  R1600     -4.7865721583366394e-01
    z[5,6,2]  R1601     -3.0638018250465393e-01
    z[5,6,2]  R1602     -1.2894614040851593e-01
    z[5,6,2]  R1603     -2.9435306787490845e-01
    z[5,6,2]  R1604     -6.0012418776750565e-02
    z[5,6,2]  R1605     -1.3119670748710632e-01
    z[5,6,2]  R1606     2.3547196388244629e-01
    z[5,6,2]  R1607     -5.2362614870071411e-01
    z[5,6,2]  R1608     -0.438385546207428
    z[5,6,2]  R1609     -5.9539139270782471e-01
    z[5,6,2]  R1610     3.5121065378189087e-01
    z[5,6,2]  R1611     5.2069473266601562e-01
    z[5,6,2]  R1612     2.0645692944526672e-02
    z[5,6,2]  R1613     6.0132515430450439e-01
    z[5,6,2]  R1614     5.5767655372619629e-01
    z[5,6,2]  R1615     4.3703210353851318e-01
    z[5,6,2]  R1616     4.5359331369400024e-01
    z[5,6,2]  R1617     -4.8705145716667175e-01
    z[5,6,2]  R1618     4.6946480870246887e-01
    z[5,6,2]  R1619     2.7474248409271240e-01
    z[5,6,2]  R1620     5.8647930622100830e-01
    z[5,6,2]  R1621     3.6668869853019714e-01
    z[5,6,2]  R1622     3.1894814968109131e-01
    z[5,6,2]  R1623     2.6994487643241882e-01
    z[5,6,2]  R1624     4.6839416027069092e-01
    z[5,6,2]  R1625     0.56394362449646
    z[5,6,2]  R1626     4.9780625104904175e-01
    z[5,6,2]  R1627     -1.2506563961505890e-01
    z[5,6,2]  R1628     4.0509355068206787e-01
    z[5,6,2]  R1629     4.4223695993423462e-01
    z[5,6,2]  R1630     2.4276073276996613e-01
    z[5,6,2]  R1631     2.3418653011322021e-01
    z[5,6,2]  R1632     1.7361932992935181e-01
    z[5,6,2]  R1633     3.7193521857261658e-01
    z[5,6,2]  R1634     2.2485843300819397e-01
    z[5,6,2]  R1635     5.1996129751205444e-01
    z[5,6,2]  R1636     -3.6978565156459808e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1531     -1
    z[5,6,3]  R1532     1
    z[5,6,3]  R1539     7.3608434200286865e-01
    z[5,6,3]  R1540     5.4030829668045044e-01
    z[5,6,3]  R1541     6.2292045354843140e-01
    z[5,6,3]  R1542     6.6875702142715454e-01
    z[5,6,3]  R1543     7.5043952465057373e-01
    z[5,6,3]  R1544     7.2219270467758179e-01
    z[5,6,3]  R1545     2.1046654880046844e-01
    z[5,6,3]  R1546     -1.9717127084732056e-01
    z[5,6,3]  R1547     -3.0319371819496155e-01
    z[5,6,3]  R1548     -1.6102933883666992e-01
    z[5,6,3]  R1549     -3.9764145016670227e-01
    z[5,6,3]  R1550     -0.382107138633728
    z[5,6,3]  R1551     -3.4391874074935913e-01
    z[5,6,3]  R1552     2.3867176845669746e-02
    z[5,6,3]  R1553     8.9123375713825226e-02
    z[5,6,3]  R1554     2.2022317349910736e-01
    z[5,6,3]  R1555     -3.3727136254310608e-01
    z[5,6,3]  R1556     -0.384029358625412
    z[5,6,3]  R1557     2.9151519760489464e-02
    z[5,6,3]  R1558     -7.5818479061126709e-02
    z[5,6,3]  R1559     -2.0075872540473938e-01
    z[5,6,3]  R1560     -2.5415161252021790e-01
    z[5,6,3]  R1561     -6.9063976407051086e-03
    z[5,6,3]  R1562     -4.1616834700107574e-02
    z[5,6,3]  R1563     -3.2481840252876282e-01
    z[5,6,3]  R1564     -3.7099415063858032e-01
    z[5,6,3]  R1565     -3.2631272077560425e-01
    z[5,6,3]  R1566     -3.7785044312477112e-01
    z[5,6,3]  R1567     -4.1483816504478455e-01
    z[5,6,3]  R1568     -4.5609995722770691e-01
    z[5,6,3]  R1569     -5.1416993141174316e-01
    z[5,6,3]  R1570     -4.7320303320884705e-01
    z[5,6,3]  R1571     -4.4991636276245117e-01
    z[5,6,3]  R1572     -5.5748138576745987e-02
    z[5,6,3]  R1573     -3.8931149244308472e-01
    z[5,6,3]  R1574     -4.6299010515213013e-01
    z[5,6,3]  R1575     -3.9735451340675354e-01
    z[5,6,3]  R1576     -3.5702151060104370e-01
    z[5,6,3]  R1577     -3.7627723813056946e-01
    z[5,6,3]  R1578     -0.240528866648674
    z[5,6,3]  R1579     -5.2581030130386353e-01
    z[5,6,3]  R1580     -5.1531064510345459e-01
    z[5,6,3]  R1581     -1.9629509747028351e-01
    z[5,6,3]  R1582     -4.6880120038986206e-01
    z[5,6,3]  R1583     -0.436359167098999
    z[5,6,3]  R1584     5.1680259406566620e-02
    z[5,6,3]  R1585     -2.3948743939399719e-01
    z[5,6,3]  R1586     -0.504715621471405
    z[5,6,3]  R1587     -3.7417319416999817e-01
    z[5,6,3]  R1588     1.2880219519138336e-01
    z[5,6,3]  R1589     -2.4957848712801933e-02
    z[5,6,3]  R1590     1.8037818372249603e-01
    z[5,6,3]  R1591     -4.1164883971214294e-01
    z[5,6,3]  R1592     -2.3377789556980133e-01
    z[5,6,3]  R1593     -1.7172104120254517e-01
    z[5,6,3]  R1594     -2.6337611675262451e-01
    z[5,6,3]  R1595     -8.2218900322914124e-02
    z[5,6,3]  R1596     -1.7680704593658447e-01
    z[5,6,3]  R1597     7.3736059665679932e-01
    z[5,6,3]  R1598     2.4496375024318695e-01
    z[5,6,3]  R1599     2.7197441458702087e-01
    z[5,6,3]  R1600     5.6444466114044189e-01
    z[5,6,3]  R1601     2.1162256598472595e-01
    z[5,6,3]  R1602     7.8199088573455811e-01
    z[5,6,3]  R1603     8.8519737124443054e-02
    z[5,6,3]  R1604     3.7660104036331177e-01
    z[5,6,3]  R1605     5.6421411037445068e-01
    z[5,6,3]  R1606     5.9436100721359253e-01
    z[5,6,3]  R1607     -2.2799010574817657e-01
    z[5,6,3]  R1608     -2.5736156105995178e-01
    z[5,6,3]  R1609     -5.4242026805877686e-01
    z[5,6,3]  R1610     -2.6262211799621582e-01
    z[5,6,3]  R1611     -3.8348857313394547e-02
    z[5,6,3]  R1612     -2.9589679837226868e-01
    z[5,6,3]  R1613     -3.0975860357284546e-01
    z[5,6,3]  R1614     -2.8315034508705139e-01
    z[5,6,3]  R1615     -3.3291906118392944e-01
    z[5,6,3]  R1616     -3.2870528101921082e-01
    z[5,6,3]  R1617     -6.7682260274887085e-01
    z[5,6,3]  R1618     4.9128532409667969e-01
    z[5,6,3]  R1619     6.4742344617843628e-01
    z[5,6,3]  R1620     -2.0186990499496460e-01
    z[5,6,3]  R1621     3.9293374866247177e-02
    z[5,6,3]  R1622     2.5785389542579651e-01
    z[5,6,3]  R1623     -2.4777875840663910e-01
    z[5,6,3]  R1624     -1.5962266921997070e-01
    z[5,6,3]  R1625     -2.1654102206230164e-01
    z[5,6,3]  R1626     -2.8818780183792114e-01
    z[5,6,3]  R1627     -3.1955018639564514e-01
    z[5,6,3]  R1628     -0.0674697533249855
    z[5,6,3]  R1629     -3.9962741732597351e-01
    z[5,6,3]  R1630     -3.4626686573028564e-01
    z[5,6,3]  R1631     -3.3625563979148865e-01
    z[5,6,3]  R1632     -3.5481536388397217e-01
    z[5,6,3]  R1633     -2.6597523689270020e-01
    z[5,6,3]  R1634     -1.3726912438869476e-01
    z[5,6,3]  R1635     -4.0699992328882217e-02
    z[5,6,3]  R1636     -2.2174143791198730e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1533     -1
    z[5,6,4]  R1534     1
    z[5,6,4]  R1539     -3.6362904310226440e-01
    z[5,6,4]  R1540     -4.9960348010063171e-01
    z[5,6,4]  R1541     -5.0354075431823730e-01
    z[5,6,4]  R1542     -4.5779895782470703e-01
    z[5,6,4]  R1543     -4.1896820068359375e-01
    z[5,6,4]  R1544     1.5908795595169067e-01
    z[5,6,4]  R1545     -3.3138684928417206e-02
    z[5,6,4]  R1546     3.5523235797882080e-01
    z[5,6,4]  R1547     0.217244952917099
    z[5,6,4]  R1548     3.2900825142860413e-01
    z[5,6,4]  R1549     2.9175531864166260e-01
    z[5,6,4]  R1550     -2.2416071593761444e-01
    z[5,6,4]  R1551     2.2207362949848175e-01
    z[5,6,4]  R1552     1.4279159903526306e-01
    z[5,6,4]  R1553     2.6071277260780334e-01
    z[5,6,4]  R1554     4.3812528252601624e-01
    z[5,6,4]  R1555     -2.0273329690098763e-02
    z[5,6,4]  R1556     -8.0797486007213593e-02
    z[5,6,4]  R1557     1.7193509638309479e-01
    z[5,6,4]  R1558     3.0143103003501892e-01
    z[5,6,4]  R1559     2.8488751500844955e-02
    z[5,6,4]  R1560     2.5044327974319458e-01
    z[5,6,4]  R1561     2.7663178741931915e-02
    z[5,6,4]  R1562     7.2973388433456421e-01
    z[5,6,4]  R1563     1.9733099639415741e-01
    z[5,6,4]  R1564     7.4615710973739624e-01
    z[5,6,4]  R1565     -1.6516859829425812e-01
    z[5,6,4]  R1566     3.3730453252792358e-01
    z[5,6,4]  R1567     0.0498795211315155
    z[5,6,4]  R1568     3.7845957279205322e-01
    z[5,6,4]  R1569     4.8017796874046326e-01
    z[5,6,4]  R1570     1.8214242160320282e-01
    z[5,6,4]  R1571     2.7879974246025085e-01
    z[5,6,4]  R1572     -2.2715424001216888e-01
    z[5,6,4]  R1573     -2.0099349319934845e-01
    z[5,6,4]  R1574     5.0853151082992554e-01
    z[5,6,4]  R1575     -1.7937676608562469e-01
    z[5,6,4]  R1576     -1.8026949465274811e-01
    z[5,6,4]  R1577     8.8719859719276428e-02
    z[5,6,4]  R1578     1.4271272718906403e-01
    z[5,6,4]  R1579     -1.2888167798519135e-01
    z[5,6,4]  R1580     3.2883301377296448e-01
    z[5,6,4]  R1581     -0.0935700535774231
    z[5,6,4]  R1582     1.5172238647937775e-01
    z[5,6,4]  R1583     4.0937563776969910e-01
    z[5,6,4]  R1584     5.6467449665069580e-01
    z[5,6,4]  R1585     3.2929587364196777e-01
    z[5,6,4]  R1586     -0.0696905255317688
    z[5,6,4]  R1587     -5.3936969488859177e-02
    z[5,6,4]  R1588     7.8755879402160645e-01
    z[5,6,4]  R1589     2.7873307466506958e-01
    z[5,6,4]  R1590     1.9228503108024597e-01
    z[5,6,4]  R1591     3.1026398763060570e-02
    z[5,6,4]  R1592     1.2565727531909943e-01
    z[5,6,4]  R1593     2.1122060716152191e-01
    z[5,6,4]  R1594     -1.0344945639371872e-01
    z[5,6,4]  R1595     5.7111438363790512e-02
    z[5,6,4]  R1596     2.3274549841880798e-01
    z[5,6,4]  R1597     -1.4335820078849792e-01
    z[5,6,4]  R1598     -1.8840160965919495e-01
    z[5,6,4]  R1599     -6.8485051393508911e-01
    z[5,6,4]  R1600     -2.5238949060440063e-01
    z[5,6,4]  R1601     -6.9705463945865631e-02
    z[5,6,4]  R1602     -2.0170746371150017e-02
    z[5,6,4]  R1603     -1.4854730665683746e-01
    z[5,6,4]  R1604     -7.6145190000534058e-01
    z[5,6,4]  R1605     1.9435827434062958e-01
    z[5,6,4]  R1606     8.6991004645824432e-02
    z[5,6,4]  R1607     2.6194646954536438e-01
    z[5,6,4]  R1608     -0.0992252379655838
    z[5,6,4]  R1609     2.4288235604763031e-01
    z[5,6,4]  R1610     -1.8302644789218903e-01
    z[5,6,4]  R1611     -6.6127941012382507e-02
    z[5,6,4]  R1612     2.5026535987854004e-01
    z[5,6,4]  R1613     -1.9430282711982727e-01
    z[5,6,4]  R1614     5.0300270318984985e-01
    z[5,6,4]  R1615     6.9137299060821533e-01
    z[5,6,4]  R1616     5.7457500696182251e-01
    z[5,6,4]  R1617     -4.6021699905395508e-01
    z[5,6,4]  R1618     1.0321640968322754e-01
    z[5,6,4]  R1619     1.9517336785793304e-01
    z[5,6,4]  R1620     2.2953076288104057e-02
    z[5,6,4]  R1621     3.7811064720153809e-01
    z[5,6,4]  R1622     3.3351635932922363e-01
    z[5,6,4]  R1623     0.510429859161377
    z[5,6,4]  R1624     -2.8141397982835770e-02
    z[5,6,4]  R1625     1.0243520140647888e-01
    z[5,6,4]  R1626     -6.0386221855878830e-02
    z[5,6,4]  R1627     -0.518736720085144
    z[5,6,4]  R1628     2.2828787565231323e-02
    z[5,6,4]  R1629     8.2920975983142853e-03
    z[5,6,4]  R1630     4.2705839872360229e-01
    z[5,6,4]  R1631     2.9318472743034363e-01
    z[5,6,4]  R1632     7.0638722181320190e-01
    z[5,6,4]  R1633     3.9679402112960815e-01
    z[5,6,4]  R1634     3.3010202646255493e-01
    z[5,6,4]  R1635     1.8786674365401268e-02
    z[5,6,4]  R1636     1.2044016271829605e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1535     -1
    z[5,6,5]  R1536     1
    z[5,6,5]  R1539     -5.0993365049362183e-01
    z[5,6,5]  R1540     -3.1566226482391357e-01
    z[5,6,5]  R1541     5.1966842263936996e-02
    z[5,6,5]  R1542     6.5858006477355957e-02
    z[5,6,5]  R1543     0.0646321102976799
    z[5,6,5]  R1544     2.7212062478065491e-01
    z[5,6,5]  R1545     -4.4912809133529663e-01
    z[5,6,5]  R1546     6.9142395257949829e-01
    z[5,6,5]  R1547     -7.7091202139854431e-02
    z[5,6,5]  R1548     -2.8734761476516724e-01
    z[5,6,5]  R1549     6.4398103859275579e-04
    z[5,6,5]  R1550     -8.3091638982295990e-02
    z[5,6,5]  R1551     -3.5906833410263062e-01
    z[5,6,5]  R1552     1.7532955110073090e-01
    z[5,6,5]  R1553     8.3269372582435608e-02
    z[5,6,5]  R1554     -0.0711384192109108
    z[5,6,5]  R1555     -6.2169115990400314e-02
    z[5,6,5]  R1556     1.5969856083393097e-01
    z[5,6,5]  R1557     1.9097542762756348e-01
    z[5,6,5]  R1558     2.0190049707889557e-01
    z[5,6,5]  R1559     4.2580485343933105e-01
    z[5,6,5]  R1560     1.8876263499259949e-01
    z[5,6,5]  R1561     -2.1215988695621490e-01
    z[5,6,5]  R1562     -3.3713313937187195e-01
    z[5,6,5]  R1563     6.9382983446121216e-01
    z[5,6,5]  R1564     5.3669852018356323e-01
    z[5,6,5]  R1565     8.0368494987487793e-01
    z[5,6,5]  R1566     8.3032655715942383e-01
    z[5,6,5]  R1567     -2.8334662318229675e-01
    z[5,6,5]  R1568     5.9061342477798462e-01
    z[5,6,5]  R1569     4.6428731083869934e-01
    z[5,6,5]  R1570     7.9928082227706909e-01
    z[5,6,5]  R1571     6.3880944252014160e-01
    z[5,6,5]  R1572     -1.2024427205324173e-01
    z[5,6,5]  R1573     8.8297879695892334e-01
    z[5,6,5]  R1574     0.678679347038269
    z[5,6,5]  R1575     2.0962141454219818e-01
    z[5,6,5]  R1576     2.9410168528556824e-01
    z[5,6,5]  R1577     -1.6936337947845459e-01
    z[5,6,5]  R1578     -2.9251632094383240e-01
    z[5,6,5]  R1579     2.1376506984233856e-01
    z[5,6,5]  R1580     7.2798830270767212e-01
    z[5,6,5]  R1581     1.8158622086048126e-01
    z[5,6,5]  R1582     6.9855982065200806e-01
    z[5,6,5]  R1583     5.7795554399490356e-01
    z[5,6,5]  R1584     -2.6634159684181213e-01
    z[5,6,5]  R1585     3.6635585129261017e-02
    z[5,6,5]  R1586     6.2024587392807007e-01
    z[5,6,5]  R1587     -2.1901336312294006e-01
    z[5,6,5]  R1588     -2.9368248581886292e-01
    z[5,6,5]  R1589     -9.8348014056682587e-02
    z[5,6,5]  R1590     -0.0858580619096756
    z[5,6,5]  R1591     5.0305879116058350e-01
    z[5,6,5]  R1592     1.7933454364538193e-03
    z[5,6,5]  R1593     1.7778772860765457e-02
    z[5,6,5]  R1594     1.3922728598117828e-02
    z[5,6,5]  R1595     6.9761417806148529e-02
    z[5,6,5]  R1596     -1.3274255394935608e-01
    z[5,6,5]  R1597     6.9417193531990051e-02
    z[5,6,5]  R1598     1.5506243705749512e-01
    z[5,6,5]  R1599     3.7132057547569275e-01
    z[5,6,5]  R1600     2.1465530991554260e-01
    z[5,6,5]  R1601     1.0117302089929581e-01
    z[5,6,5]  R1602     2.5743028521537781e-01
    z[5,6,5]  R1603     -0.305356502532959
    z[5,6,5]  R1604     -1.4670735597610474e-01
    z[5,6,5]  R1605     -7.6789689064025879e-01
    z[5,6,5]  R1606     -6.5999329090118408e-01
    z[5,6,5]  R1607     4.4676882028579712e-01
    z[5,6,5]  R1608     2.8443023562431335e-01
    z[5,6,5]  R1609     3.3078234642744064e-02
    z[5,6,5]  R1610     -3.0063995718955994e-01
    z[5,6,5]  R1611     2.8809410333633423e-01
    z[5,6,5]  R1612     -0.0702296569943428
    z[5,6,5]  R1613     2.3496554791927338e-01
    z[5,6,5]  R1614     -4.1340142488479614e-02
    z[5,6,5]  R1615     4.4156956672668457e-01
    z[5,6,5]  R1616     4.3883880972862244e-01
    z[5,6,5]  R1617     -4.7935396432876587e-02
    z[5,6,5]  R1618     -5.1559843122959137e-02
    z[5,6,5]  R1619     1.7003294825553894e-01
    z[5,6,5]  R1620     -9.0687476098537445e-02
    z[5,6,5]  R1621     -2.9200930148363113e-02
    z[5,6,5]  R1622     2.5748556945472956e-03
    z[5,6,5]  R1623     -3.8776826858520508e-01
    z[5,6,5]  R1624     -3.2422986626625061e-01
    z[5,6,5]  R1625     1.9909940659999847e-02
    z[5,6,5]  R1626     -3.2066482305526733e-01
    z[5,6,5]  R1627     6.5030759572982788e-01
    z[5,6,5]  R1628     0.18819560110569
    z[5,6,5]  R1629     1.9532483071088791e-02
    z[5,6,5]  R1630     6.8907028436660767e-01
    z[5,6,5]  R1631     7.6346707344055176e-01
    z[5,6,5]  R1632     3.1301450729370117e-01
    z[5,6,5]  R1633     7.1340814232826233e-02
    z[5,6,5]  R1634     1.0498243570327759e-01
    z[5,6,5]  R1635     1.6161866486072540e-01
    z[5,6,5]  R1636     -2.5649511814117432e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1537     -1
    z[5,6,6]  R1538     1
    z[5,6,6]  R1539     -1.2496767193078995e-01
    z[5,6,6]  R1540     -3.3959320187568665e-01
    z[5,6,6]  R1541     1.5946586430072784e-01
    z[5,6,6]  R1542     5.3904527425765991e-01
    z[5,6,6]  R1543     5.4972756654024124e-02
    z[5,6,6]  R1544     4.8812466859817505e-01
    z[5,6,6]  R1545     0.541669487953186
    z[5,6,6]  R1546     1.6661377251148224e-01
    z[5,6,6]  R1547     4.2185693979263306e-02
    z[5,6,6]  R1548     8.8064707815647125e-02
    z[5,6,6]  R1549     0.0748034194111824
    z[5,6,6]  R1550     1.4905783534049988e-01
    z[5,6,6]  R1551     -1.5778036415576935e-01
    z[5,6,6]  R1552     -2.5766023993492126e-01
    z[5,6,6]  R1553     -2.0082110166549683e-01
    z[5,6,6]  R1554     4.2314846068620682e-02
    z[5,6,6]  R1555     -1.6519361734390259e-01
    z[5,6,6]  R1556     -2.4947854876518250e-01
    z[5,6,6]  R1557     -1.5222434699535370e-01
    z[5,6,6]  R1558     -0.298637717962265
    z[5,6,6]  R1559     -1.2827472388744354e-01
    z[5,6,6]  R1560     -5.2869278006255627e-03
    z[5,6,6]  R1561     2.8611668944358826e-01
    z[5,6,6]  R1562     -3.1322479248046875e-01
    z[5,6,6]  R1563     -2.1153491735458374e-01
    z[5,6,6]  R1564     2.2140184417366982e-02
    z[5,6,6]  R1565     -2.3628962039947510e-01
    z[5,6,6]  R1566     -1.3973458111286163e-01
    z[5,6,6]  R1567     4.2196404933929443e-01
    z[5,6,6]  R1568     -7.4117675423622131e-02
    z[5,6,6]  R1569     -1.4720979332923889e-01
    z[5,6,6]  R1570     1.1466714553534985e-02
    z[5,6,6]  R1571     3.2258301973342896e-01
    z[5,6,6]  R1572     -2.4573981761932373e-01
    z[5,6,6]  R1573     9.1757513582706451e-02
    z[5,6,6]  R1574     -0.036479651927948
    z[5,6,6]  R1575     -3.6137616634368896e-01
    z[5,6,6]  R1576     6.5060378983616829e-03
    z[5,6,6]  R1577     4.0706261992454529e-01
    z[5,6,6]  R1578     2.9850575327873230e-01
    z[5,6,6]  R1579     3.7586751580238342e-01
    z[5,6,6]  R1580     1.6976203769445419e-02
    z[5,6,6]  R1581     -1.0731585323810577e-01
    z[5,6,6]  R1582     -2.7284076809883118e-01
    z[5,6,6]  R1583     -2.2479134798049927e-01
    z[5,6,6]  R1584     1.0838758200407028e-01
    z[5,6,6]  R1585     -3.8693693280220032e-01
    z[5,6,6]  R1586     -2.7461314201354980e-01
    z[5,6,6]  R1587     2.4959123134613037e-01
    z[5,6,6]  R1588     -3.4637156128883362e-01
    z[5,6,6]  R1589     -7.7166631817817688e-02
    z[5,6,6]  R1590     0.0599825382232666
    z[5,6,6]  R1591     2.8436020016670227e-01
    z[5,6,6]  R1592     -1.1480133235454559e-01
    z[5,6,6]  R1593     -1.4487040042877197e-01
    z[5,6,6]  R1594     1.1831221729516983e-01
    z[5,6,6]  R1595     -2.2547294199466705e-01
    z[5,6,6]  R1596     1.3696002960205078e-01
    z[5,6,6]  R1597     3.1279347836971283e-02
    z[5,6,6]  R1598     -1.2333748489618301e-01
    z[5,6,6]  R1599     -2.9531520605087280e-01
    z[5,6,6]  R1600     4.5990908145904541e-01
    z[5,6,6]  R1601     -6.3684183359146118e-01
    z[5,6,6]  R1602     -1.8181812763214111e-01
    z[5,6,6]  R1603     1.4404557645320892e-01
    z[5,6,6]  R1604     -5.8593165129423141e-02
    z[5,6,6]  R1605     3.1259968876838684e-02
    z[5,6,6]  R1606     2.9459765553474426e-01
    z[5,6,6]  R1607     -8.9009217917919159e-03
    z[5,6,6]  R1608     1.6101954877376556e-01
    z[5,6,6]  R1609     5.1092332601547241e-01
    z[5,6,6]  R1610     -3.2722827792167664e-01
    z[5,6,6]  R1611     -0.340950071811676
    z[5,6,6]  R1612     3.6238130927085876e-01
    z[5,6,6]  R1613     -1.6881616413593292e-01
    z[5,6,6]  R1614     2.3747469484806061e-01
    z[5,6,6]  R1615     -1.9602755084633827e-02
    z[5,6,6]  R1616     3.4779345989227295e-01
    z[5,6,6]  R1617     1.4406830072402954e-01
    z[5,6,6]  R1618     -2.4699696898460388e-01
    z[5,6,6]  R1619     1.8225048482418060e-01
    z[5,6,6]  R1620     0.104326531291008
    z[5,6,6]  R1621     -6.0234349220991135e-03
    z[5,6,6]  R1622     3.6382114887237549e-01
    z[5,6,6]  R1623     -1.3241605460643768e-01
    z[5,6,6]  R1624     3.2028988003730774e-01
    z[5,6,6]  R1625     -1.9152744114398956e-01
    z[5,6,6]  R1626     -2.9902998358011246e-02
    z[5,6,6]  R1627     -1.2477464973926544e-01
    z[5,6,6]  R1628     3.0275234580039978e-01
    z[5,6,6]  R1629     -1.3602021336555481e-01
    z[5,6,6]  R1630     2.1427385509014130e-02
    z[5,6,6]  R1631     2.4743328988552094e-01
    z[5,6,6]  R1632     -0.0496220663189888
    z[5,6,6]  R1633     3.2432243227958679e-02
    z[5,6,6]  R1634     2.0292037725448608e-01
    z[5,6,6]  R1635     3.0066993832588196e-01
    z[5,6,6]  R1636     -1.1451942473649979e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1637     -1
    z[6,5,0]  R1638     1
    z[6,5,0]  R1651     -3.4049317240715027e-01
    z[6,5,0]  R1652     -6.3429397344589233e-01
    z[6,5,0]  R1653     -3.6248835921287537e-01
    z[6,5,0]  R1654     -3.5702109336853027e-01
    z[6,5,0]  R1655     -6.6193765401840210e-01
    z[6,5,0]  R1656     -5.0425916910171509e-01
    z[6,5,0]  R1657     -7.4791139364242554e-01
    z[6,5,0]  R1658     -4.9772980809211731e-01
    z[6,5,0]  R1659     3.8281381130218506e-02
    z[6,5,0]  R1660     2.4762129783630371e-01
    z[6,5,0]  R1661     3.6441591382026672e-01
    z[6,5,0]  R1662     4.7362810373306274e-01
    z[6,5,0]  R1663     1.6266094148159027e-01
    z[6,5,0]  R1664     5.5636501312255859e-01
    z[6,5,0]  R1665     6.0811895132064819e-01
    z[6,5,0]  R1666     -4.3223667144775391e-01
    z[6,5,0]  R1667     -8.9919343590736389e-02
    z[6,5,0]  R1668     1.3340255618095398e-01
    z[6,5,0]  R1669     -1.4150561392307281e-01
    z[6,5,0]  R1670     -2.0386894047260284e-01
    z[6,5,0]  R1671     -1.4164708554744720e-01
    z[6,5,0]  R1672     2.2895674407482147e-01
    z[6,5,0]  R1673     5.8498895168304443e-01
    z[6,5,0]  R1674     7.5233328342437744e-01
    z[6,5,0]  R1675     -2.8807312250137329e-01
    z[6,5,0]  R1676     -1.7447084188461304e-01
    z[6,5,0]  R1677     6.2511068582534790e-01
    z[6,5,0]  R1678     -3.0400281772017479e-02
    z[6,5,0]  R1679     -2.3215585947036743e-01
    z[6,5,0]  R1680     -2.9119861125946045e-01
    z[6,5,0]  R1681     1.1829664558172226e-01
    z[6,5,0]  R1682     -2.2391916811466217e-01
    z[6,5,0]  R1683     -1.9385483860969543e-01
    z[6,5,0]  R1684     1.2414071708917618e-01
    z[6,5,0]  R1685     -8.9991658926010132e-02
    z[6,5,0]  R1686     -1.2856583297252655e-01
    z[6,5,0]  R1687     1.6626198589801788e-01
    z[6,5,0]  R1688     3.9438480138778687e-01
    z[6,5,0]  R1689     2.3051121830940247e-01
    z[6,5,0]  R1690     4.7068125009536743e-01
    z[6,5,0]  R1691     1.4367249608039856e-01
    z[6,5,0]  R1692     9.6836224198341370e-02
    z[6,5,0]  R1693     -9.1374427080154419e-02
    z[6,5,0]  R1694     -1.2036441266536713e-01
    z[6,5,0]  R1695     7.7137142419815063e-02
    z[6,5,0]  R1696     -1.8016014993190765e-01
    z[6,5,0]  R1697     -1.3040290772914886e-01
    z[6,5,0]  R1698     3.2169858459383249e-03
    z[6,5,0]  R1699     4.2814472317695618e-01
    z[6,5,0]  R1700     -1.3561758399009705e-01
    z[6,5,0]  R1701     -1.9953235983848572e-01
    z[6,5,0]  R1702     -1.5464584529399872e-01
    z[6,5,0]  R1703     -7.9916212707757950e-03
    z[6,5,0]  R1704     4.1941270232200623e-02
    z[6,5,0]  R1705     -5.7299101352691650e-01
    z[6,5,0]  R1706     -6.6932633519172668e-02
    z[6,5,0]  R1707     2.0704032853245735e-02
    z[6,5,0]  R1708     -4.8795364797115326e-02
    z[6,5,0]  R1709     -2.0290263928472996e-03
    z[6,5,0]  R1710     2.0917126536369324e-01
    z[6,5,0]  R1711     -1.2074116617441177e-01
    z[6,5,0]  R1712     -1.7033240199089050e-01
    z[6,5,0]  R1713     -1.2313283979892731e-01
    z[6,5,0]  R1714     -3.0875965952873230e-02
    z[6,5,0]  R1715     8.8018581271171570e-02
    z[6,5,0]  R1716     3.3534996211528778e-02
    z[6,5,0]  R1717     3.1025785207748413e-01
    z[6,5,0]  R1718     -5.4954189807176590e-02
    z[6,5,0]  R1719     -2.0206263661384583e-01
    z[6,5,0]  R1720     3.8460159301757812e-01
    z[6,5,0]  R1721     -8.2343824207782745e-02
    z[6,5,0]  R1722     -1.0563597828149796e-01
    z[6,5,0]  R1723     -1.5603317320346832e-01
    z[6,5,0]  R1724     -7.3864096403121948e-01
    z[6,5,0]  R1725     -6.9027908146381378e-02
    z[6,5,0]  R1726     -4.0976423770189285e-02
    z[6,5,0]  R1727     -3.2495218515396118e-01
    z[6,5,0]  R1728     -3.3865779638290405e-01
    z[6,5,0]  R1729     -1.5645249187946320e-01
    z[6,5,0]  R1730     -8.5378557443618774e-02
    z[6,5,0]  R1731     9.2741541564464569e-02
    z[6,5,0]  R1732     -1.2282628566026688e-01
    z[6,5,0]  R1733     -6.9633579254150391e-01
    z[6,5,0]  R1734     3.3384156227111816e-01
    z[6,5,0]  R1735     -1.2994219362735748e-01
    z[6,5,0]  R1736     9.7509376704692841e-02
    z[6,5,0]  R1737     -3.1440767645835876e-01
    z[6,5,0]  R1738     -7.5987897813320160e-02
    z[6,5,0]  R1739     -2.1686081588268280e-01
    z[6,5,0]  R1740     5.2467696368694305e-02
    z[6,5,0]  R1741     -7.6238703727722168e-01
    z[6,5,0]  R1742     -1.4882014691829681e-01
    z[6,5,0]  R1743     4.7597482800483704e-01
    z[6,5,0]  R1744     8.9614480733871460e-01
    z[6,5,0]  R1745     9.1532504558563232e-01
    z[6,5,0]  R1746     8.8304710388183594e-01
    z[6,5,0]  R1747     8.7570029497146606e-01
    z[6,5,0]  R1748     8.6964684724807739e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1639     -1
    z[6,5,1]  R1640     1
    z[6,5,1]  R1651     -1.3459932059049606e-02
    z[6,5,1]  R1652     5.1934242248535156e-01
    z[6,5,1]  R1653     -7.9995006322860718e-02
    z[6,5,1]  R1654     0.0594286248087883
    z[6,5,1]  R1655     -5.0231166183948517e-02
    z[6,5,1]  R1656     1.3360656797885895e-01
    z[6,5,1]  R1657     4.5835691690444946e-01
    z[6,5,1]  R1658     -4.5497417449951172e-02
    z[6,5,1]  R1659     -1.8592052161693573e-01
    z[6,5,1]  R1660     -5.0240028649568558e-03
    z[6,5,1]  R1661     -5.2224469184875488e-01
    z[6,5,1]  R1662     -6.3291859626770020e-01
    z[6,5,1]  R1663     -6.0845259577035904e-02
    z[6,5,1]  R1664     -5.1689177751541138e-01
    z[6,5,1]  R1665     -3.9240229129791260e-01
    z[6,5,1]  R1666     -7.2546893358230591e-01
    z[6,5,1]  R1667     -6.4258140325546265e-01
    z[6,5,1]  R1668     -5.2906662225723267e-01
    z[6,5,1]  R1669     6.9133386015892029e-02
    z[6,5,1]  R1670     -3.1099589541554451e-02
    z[6,5,1]  R1671     -2.2310295701026917e-01
    z[6,5,1]  R1672     -6.4148336648941040e-01
    z[6,5,1]  R1673     -2.5085499882698059e-01
    z[6,5,1]  R1674     -1.7219226062297821e-01
    z[6,5,1]  R1675     -7.9821836948394775e-01
    z[6,5,1]  R1676     -7.4681842327117920e-01
    z[6,5,1]  R1677     -2.1572041511535645e-01
    z[6,5,1]  R1678     -7.3871570825576782e-01
    z[6,5,1]  R1679     -7.3048555850982666e-01
    z[6,5,1]  R1680     -6.9063276052474976e-01
    z[6,5,1]  R1681     -4.0086838603019714e-01
    z[6,5,1]  R1682     -8.0846118927001953e-01
    z[6,5,1]  R1683     -0.766937255859375
    z[6,5,1]  R1684     3.8483718037605286e-01
    z[6,5,1]  R1685     3.0647650361061096e-01
    z[6,5,1]  R1686     4.7750377655029297e-01
    z[6,5,1]  R1687     7.7439749240875244e-01
    z[6,5,1]  R1688     7.8351211547851562e-01
    z[6,5,1]  R1689     7.4697548151016235e-01
    z[6,5,1]  R1690     0.796562671661377
    z[6,5,1]  R1691     -1.7200057208538055e-01
    z[6,5,1]  R1692     4.0754759684205055e-03
    z[6,5,1]  R1693     1.0573843028396368e-03
    z[6,5,1]  R1694     -1.6342546045780182e-01
    z[6,5,1]  R1695     0.474097341299057
    z[6,5,1]  R1696     -7.5184464454650879e-02
    z[6,5,1]  R1697     6.0491126775741577e-01
    z[6,5,1]  R1698     1.5866902470588684e-01
    z[6,5,1]  R1699     -7.7959084510803223e-01
    z[6,5,1]  R1700     -8.6356341838836670e-01
    z[6,5,1]  R1701     -7.9793006181716919e-01
    z[6,5,1]  R1702     -0.864427924156189
    z[6,5,1]  R1703     -8.0960261821746826e-01
    z[6,5,1]  R1704     -9.0707629919052124e-01
    z[6,5,1]  R1705     2.5930488109588623e-01
    z[6,5,1]  R1706     2.3826844990253448e-01
    z[6,5,1]  R1707     -8.6427938938140869e-01
    z[6,5,1]  R1708     -8.6776155233383179e-01
    z[6,5,1]  R1709     -0.931408703327179
    z[6,5,1]  R1710     -8.4530013799667358e-01
    z[6,5,1]  R1711     -8.3708190917968750e-01
    z[6,5,1]  R1712     -8.6308616399765015e-01
    z[6,5,1]  R1713     -0.0401635617017746
    z[6,5,1]  R1714     -1.2885574996471405e-01
    z[6,5,1]  R1715     2.1168453991413116e-01
    z[6,5,1]  R1716     4.1205409914255142e-02
    z[6,5,1]  R1717     -1.0249330103397369e-01
    z[6,5,1]  R1718     1.6594892740249634e-01
    z[6,5,1]  R1719     -6.9532161951065063e-01
    z[6,5,1]  R1720     2.3633906245231628e-01
    z[6,5,1]  R1721     4.0792447328567505e-01
    z[6,5,1]  R1722     2.8059142827987671e-01
    z[6,5,1]  R1723     4.2804378271102905e-01
    z[6,5,1]  R1724     -6.7567661404609680e-02
    z[6,5,1]  R1725     1.0781825333833694e-01
    z[6,5,1]  R1726     1.6846668720245361e-01
    z[6,5,1]  R1727     0.685014009475708
    z[6,5,1]  R1728     5.6257504224777222e-01
    z[6,5,1]  R1729     -7.9387080669403076e-01
    z[6,5,1]  R1730     -7.6158392429351807e-01
    z[6,5,1]  R1731     -6.4522135257720947e-01
    z[6,5,1]  R1732     2.4340584874153137e-01
    z[6,5,1]  R1733     5.0495165586471558e-01
    z[6,5,1]  R1734     -3.1800780445337296e-02
    z[6,5,1]  R1735     -4.0371179580688477e-02
    z[6,5,1]  R1736     -2.3372535407543182e-01
    z[6,5,1]  R1737     7.0987462997436523e-01
    z[6,5,1]  R1738     2.3280377686023712e-01
    z[6,5,1]  R1739     -8.0311816930770874e-01
    z[6,5,1]  R1740     -3.8023620843887329e-01
    z[6,5,1]  R1741     2.4064344167709351e-01
    z[6,5,1]  R1742     2.9533258080482483e-01
    z[6,5,1]  R1743     2.7576693892478943e-01
    z[6,5,1]  R1744     2.8850775957107544e-01
    z[6,5,1]  R1745     2.5768095254898071e-01
    z[6,5,1]  R1746     2.7619701623916626e-01
    z[6,5,1]  R1747     1.7701391875743866e-01
    z[6,5,1]  R1748     1.6462750732898712e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1641     -1
    z[6,5,2]  R1642     1
    z[6,5,2]  R1651     -0.560208797454834
    z[6,5,2]  R1652     -4.3954044580459595e-01
    z[6,5,2]  R1653     -3.0679419636726379e-01
    z[6,5,2]  R1654     -4.7865721583366394e-01
    z[6,5,2]  R1655     -3.0638018250465393e-01
    z[6,5,2]  R1656     -1.2894614040851593e-01
    z[6,5,2]  R1657     -2.9435306787490845e-01
    z[6,5,2]  R1658     -6.0012418776750565e-02
    z[6,5,2]  R1659     -1.3119670748710632e-01
    z[6,5,2]  R1660     2.3547196388244629e-01
    z[6,5,2]  R1661     -5.2362614870071411e-01
    z[6,5,2]  R1662     -0.438385546207428
    z[6,5,2]  R1663     -5.9539139270782471e-01
    z[6,5,2]  R1664     3.5121065378189087e-01
    z[6,5,2]  R1665     5.2069473266601562e-01
    z[6,5,2]  R1666     2.0645692944526672e-02
    z[6,5,2]  R1667     6.0132515430450439e-01
    z[6,5,2]  R1668     5.5767655372619629e-01
    z[6,5,2]  R1669     4.3703210353851318e-01
    z[6,5,2]  R1670     4.5359331369400024e-01
    z[6,5,2]  R1671     -4.8705145716667175e-01
    z[6,5,2]  R1672     4.6946480870246887e-01
    z[6,5,2]  R1673     2.7474248409271240e-01
    z[6,5,2]  R1674     5.8647930622100830e-01
    z[6,5,2]  R1675     3.6668869853019714e-01
    z[6,5,2]  R1676     3.1894814968109131e-01
    z[6,5,2]  R1677     2.6994487643241882e-01
    z[6,5,2]  R1678     4.6839416027069092e-01
    z[6,5,2]  R1679     0.56394362449646
    z[6,5,2]  R1680     4.9780625104904175e-01
    z[6,5,2]  R1681     -1.2506563961505890e-01
    z[6,5,2]  R1682     4.0509355068206787e-01
    z[6,5,2]  R1683     4.4223695993423462e-01
    z[6,5,2]  R1684     2.4276073276996613e-01
    z[6,5,2]  R1685     2.3418653011322021e-01
    z[6,5,2]  R1686     1.7361932992935181e-01
    z[6,5,2]  R1687     3.7193521857261658e-01
    z[6,5,2]  R1688     2.2485843300819397e-01
    z[6,5,2]  R1689     5.1996129751205444e-01
    z[6,5,2]  R1690     -3.6978565156459808e-02
    z[6,5,2]  R1691     8.8556744158267975e-03
    z[6,5,2]  R1692     -4.8384219408035278e-01
    z[6,5,2]  R1693     -5.6739443540573120e-01
    z[6,5,2]  R1694     -8.4151841700077057e-02
    z[6,5,2]  R1695     -1.5293259918689728e-01
    z[6,5,2]  R1696     -3.2047325372695923e-01
    z[6,5,2]  R1697     -2.7669697999954224e-01
    z[6,5,2]  R1698     0.551289439201355
    z[6,5,2]  R1699     2.4917015433311462e-01
    z[6,5,2]  R1700     -1.0660753399133682e-01
    z[6,5,2]  R1701     -2.7323761582374573e-01
    z[6,5,2]  R1702     -5.8929339051246643e-02
    z[6,5,2]  R1703     1.5184928476810455e-01
    z[6,5,2]  R1704     2.3951035737991333e-01
    z[6,5,2]  R1705     6.9373279809951782e-01
    z[6,5,2]  R1706     8.3153164386749268e-01
    z[6,5,2]  R1707     0.327529639005661
    z[6,5,2]  R1708     -5.3468596190214157e-02
    z[6,5,2]  R1709     2.0595720410346985e-01
    z[6,5,2]  R1710     -1.2311632931232452e-01
    z[6,5,2]  R1711     -2.1409240365028381e-01
    z[6,5,2]  R1712     -2.5118723511695862e-01
    z[6,5,2]  R1713     9.2495280504226685e-01
    z[6,5,2]  R1714     -4.8624154925346375e-01
    z[6,5,2]  R1715     -5.2616435289382935e-01
    z[6,5,2]  R1716     -1.1939374357461929e-01
    z[6,5,2]  R1717     -2.4027542769908905e-01
    z[6,5,2]  R1718     -6.2671370804309845e-02
    z[6,5,2]  R1719     -2.0683540403842926e-01
    z[6,5,2]  R1720     -3.0107992887496948e-01
    z[6,5,2]  R1721     -3.0763953924179077e-01
    z[6,5,2]  R1722     -1.1845391988754272e-01
    z[6,5,2]  R1723     1.1871451511979103e-02
    z[6,5,2]  R1724     5.6594204902648926e-01
    z[6,5,2]  R1725     -5.9812232851982117e-02
    z[6,5,2]  R1726     1.8718820810317993e-01
    z[6,5,2]  R1727     2.4609220027923584e-01
    z[6,5,2]  R1728     5.6773293018341064e-01
    z[6,5,2]  R1729     3.8105454295873642e-02
    z[6,5,2]  R1730     3.9975973963737488e-01
    z[6,5,2]  R1731     3.0826881527900696e-01
    z[6,5,2]  R1732     -1.4743112027645111e-01
    z[6,5,2]  R1733     4.1032043099403381e-01
    z[6,5,2]  R1734     -2.8690841794013977e-01
    z[6,5,2]  R1735     -4.8879832029342651e-01
    z[6,5,2]  R1736     7.2914361953735352e-01
    z[6,5,2]  R1737     2.8350222110748291e-01
    z[6,5,2]  R1738     -4.6937850117683411e-01
    z[6,5,2]  R1739     -2.3408372700214386e-01
    z[6,5,2]  R1740     -9.8009787499904633e-02
    z[6,5,2]  R1741     5.1663786172866821e-01
    z[6,5,2]  R1742     9.0008443593978882e-01
    z[6,5,2]  R1743     -4.3937939405441284e-01
    z[6,5,2]  R1744     1.7338788509368896e-01
    z[6,5,2]  R1745     1.9356388598680496e-02
    z[6,5,2]  R1746     2.2289606928825378e-01
    z[6,5,2]  R1747     3.6890214681625366e-01
    z[6,5,2]  R1748     3.0789998173713684e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1643     -1
    z[6,5,3]  R1644     1
    z[6,5,3]  R1651     7.3736059665679932e-01
    z[6,5,3]  R1652     2.4496375024318695e-01
    z[6,5,3]  R1653     2.7197441458702087e-01
    z[6,5,3]  R1654     5.6444466114044189e-01
    z[6,5,3]  R1655     2.1162256598472595e-01
    z[6,5,3]  R1656     7.8199088573455811e-01
    z[6,5,3]  R1657     8.8519737124443054e-02
    z[6,5,3]  R1658     3.7660104036331177e-01
    z[6,5,3]  R1659     5.6421411037445068e-01
    z[6,5,3]  R1660     5.9436100721359253e-01
    z[6,5,3]  R1661     -2.2799010574817657e-01
    z[6,5,3]  R1662     -2.5736156105995178e-01
    z[6,5,3]  R1663     -5.4242026805877686e-01
    z[6,5,3]  R1664     -2.6262211799621582e-01
    z[6,5,3]  R1665     -3.8348857313394547e-02
    z[6,5,3]  R1666     -2.9589679837226868e-01
    z[6,5,3]  R1667     -3.0975860357284546e-01
    z[6,5,3]  R1668     -2.8315034508705139e-01
    z[6,5,3]  R1669     -3.3291906118392944e-01
    z[6,5,3]  R1670     -3.2870528101921082e-01
    z[6,5,3]  R1671     -6.7682260274887085e-01
    z[6,5,3]  R1672     4.9128532409667969e-01
    z[6,5,3]  R1673     6.4742344617843628e-01
    z[6,5,3]  R1674     -2.0186990499496460e-01
    z[6,5,3]  R1675     3.9293374866247177e-02
    z[6,5,3]  R1676     2.5785389542579651e-01
    z[6,5,3]  R1677     -2.4777875840663910e-01
    z[6,5,3]  R1678     -1.5962266921997070e-01
    z[6,5,3]  R1679     -2.1654102206230164e-01
    z[6,5,3]  R1680     -2.8818780183792114e-01
    z[6,5,3]  R1681     -3.1955018639564514e-01
    z[6,5,3]  R1682     -0.0674697533249855
    z[6,5,3]  R1683     -3.9962741732597351e-01
    z[6,5,3]  R1684     -3.4626686573028564e-01
    z[6,5,3]  R1685     -3.3625563979148865e-01
    z[6,5,3]  R1686     -3.5481536388397217e-01
    z[6,5,3]  R1687     -2.6597523689270020e-01
    z[6,5,3]  R1688     -1.3726912438869476e-01
    z[6,5,3]  R1689     -4.0699992328882217e-02
    z[6,5,3]  R1690     -2.2174143791198730e-01
    z[6,5,3]  R1691     7.3608434200286865e-01
    z[6,5,3]  R1692     5.4030829668045044e-01
    z[6,5,3]  R1693     6.2292045354843140e-01
    z[6,5,3]  R1694     6.6875702142715454e-01
    z[6,5,3]  R1695     7.5043952465057373e-01
    z[6,5,3]  R1696     7.2219270467758179e-01
    z[6,5,3]  R1697     2.1046654880046844e-01
    z[6,5,3]  R1698     -1.9717127084732056e-01
    z[6,5,3]  R1699     -3.0319371819496155e-01
    z[6,5,3]  R1700     -1.6102933883666992e-01
    z[6,5,3]  R1701     -3.9764145016670227e-01
    z[6,5,3]  R1702     -0.382107138633728
    z[6,5,3]  R1703     -3.4391874074935913e-01
    z[6,5,3]  R1704     2.3867176845669746e-02
    z[6,5,3]  R1705     8.9123375713825226e-02
    z[6,5,3]  R1706     2.2022317349910736e-01
    z[6,5,3]  R1707     -3.3727136254310608e-01
    z[6,5,3]  R1708     -0.384029358625412
    z[6,5,3]  R1709     2.9151519760489464e-02
    z[6,5,3]  R1710     -7.5818479061126709e-02
    z[6,5,3]  R1711     -2.0075872540473938e-01
    z[6,5,3]  R1712     -2.5415161252021790e-01
    z[6,5,3]  R1713     -6.9063976407051086e-03
    z[6,5,3]  R1714     -4.1616834700107574e-02
    z[6,5,3]  R1715     -3.2481840252876282e-01
    z[6,5,3]  R1716     -3.7099415063858032e-01
    z[6,5,3]  R1717     -3.2631272077560425e-01
    z[6,5,3]  R1718     -3.7785044312477112e-01
    z[6,5,3]  R1719     -4.1483816504478455e-01
    z[6,5,3]  R1720     -4.5609995722770691e-01
    z[6,5,3]  R1721     -5.1416993141174316e-01
    z[6,5,3]  R1722     -4.7320303320884705e-01
    z[6,5,3]  R1723     -4.4991636276245117e-01
    z[6,5,3]  R1724     -5.5748138576745987e-02
    z[6,5,3]  R1725     -3.8931149244308472e-01
    z[6,5,3]  R1726     -4.6299010515213013e-01
    z[6,5,3]  R1727     -3.9735451340675354e-01
    z[6,5,3]  R1728     -3.5702151060104370e-01
    z[6,5,3]  R1729     -3.7627723813056946e-01
    z[6,5,3]  R1730     -0.240528866648674
    z[6,5,3]  R1731     -5.2581030130386353e-01
    z[6,5,3]  R1732     -5.1531064510345459e-01
    z[6,5,3]  R1733     -1.9629509747028351e-01
    z[6,5,3]  R1734     -4.6880120038986206e-01
    z[6,5,3]  R1735     -0.436359167098999
    z[6,5,3]  R1736     5.1680259406566620e-02
    z[6,5,3]  R1737     -2.3948743939399719e-01
    z[6,5,3]  R1738     -0.504715621471405
    z[6,5,3]  R1739     -3.7417319416999817e-01
    z[6,5,3]  R1740     1.2880219519138336e-01
    z[6,5,3]  R1741     -2.4957848712801933e-02
    z[6,5,3]  R1742     1.8037818372249603e-01
    z[6,5,3]  R1743     -4.1164883971214294e-01
    z[6,5,3]  R1744     -2.3377789556980133e-01
    z[6,5,3]  R1745     -1.7172104120254517e-01
    z[6,5,3]  R1746     -2.6337611675262451e-01
    z[6,5,3]  R1747     -8.2218900322914124e-02
    z[6,5,3]  R1748     -1.7680704593658447e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1645     -1
    z[6,5,4]  R1646     1
    z[6,5,4]  R1651     -1.4335820078849792e-01
    z[6,5,4]  R1652     -1.8840160965919495e-01
    z[6,5,4]  R1653     -6.8485051393508911e-01
    z[6,5,4]  R1654     -2.5238949060440063e-01
    z[6,5,4]  R1655     -6.9705463945865631e-02
    z[6,5,4]  R1656     -2.0170746371150017e-02
    z[6,5,4]  R1657     -1.4854730665683746e-01
    z[6,5,4]  R1658     -7.6145190000534058e-01
    z[6,5,4]  R1659     1.9435827434062958e-01
    z[6,5,4]  R1660     8.6991004645824432e-02
    z[6,5,4]  R1661     2.6194646954536438e-01
    z[6,5,4]  R1662     -0.0992252379655838
    z[6,5,4]  R1663     2.4288235604763031e-01
    z[6,5,4]  R1664     -1.8302644789218903e-01
    z[6,5,4]  R1665     -6.6127941012382507e-02
    z[6,5,4]  R1666     2.5026535987854004e-01
    z[6,5,4]  R1667     -1.9430282711982727e-01
    z[6,5,4]  R1668     5.0300270318984985e-01
    z[6,5,4]  R1669     6.9137299060821533e-01
    z[6,5,4]  R1670     5.7457500696182251e-01
    z[6,5,4]  R1671     -4.6021699905395508e-01
    z[6,5,4]  R1672     1.0321640968322754e-01
    z[6,5,4]  R1673     1.9517336785793304e-01
    z[6,5,4]  R1674     2.2953076288104057e-02
    z[6,5,4]  R1675     3.7811064720153809e-01
    z[6,5,4]  R1676     3.3351635932922363e-01
    z[6,5,4]  R1677     0.510429859161377
    z[6,5,4]  R1678     -2.8141397982835770e-02
    z[6,5,4]  R1679     1.0243520140647888e-01
    z[6,5,4]  R1680     -6.0386221855878830e-02
    z[6,5,4]  R1681     -0.518736720085144
    z[6,5,4]  R1682     2.2828787565231323e-02
    z[6,5,4]  R1683     8.2920975983142853e-03
    z[6,5,4]  R1684     4.2705839872360229e-01
    z[6,5,4]  R1685     2.9318472743034363e-01
    z[6,5,4]  R1686     7.0638722181320190e-01
    z[6,5,4]  R1687     3.9679402112960815e-01
    z[6,5,4]  R1688     3.3010202646255493e-01
    z[6,5,4]  R1689     1.8786674365401268e-02
    z[6,5,4]  R1690     1.2044016271829605e-01
    z[6,5,4]  R1691     -3.6362904310226440e-01
    z[6,5,4]  R1692     -4.9960348010063171e-01
    z[6,5,4]  R1693     -5.0354075431823730e-01
    z[6,5,4]  R1694     -4.5779895782470703e-01
    z[6,5,4]  R1695     -4.1896820068359375e-01
    z[6,5,4]  R1696     1.5908795595169067e-01
    z[6,5,4]  R1697     -3.3138684928417206e-02
    z[6,5,4]  R1698     3.5523235797882080e-01
    z[6,5,4]  R1699     0.217244952917099
    z[6,5,4]  R1700     3.2900825142860413e-01
    z[6,5,4]  R1701     2.9175531864166260e-01
    z[6,5,4]  R1702     -2.2416071593761444e-01
    z[6,5,4]  R1703     2.2207362949848175e-01
    z[6,5,4]  R1704     1.4279159903526306e-01
    z[6,5,4]  R1705     2.6071277260780334e-01
    z[6,5,4]  R1706     4.3812528252601624e-01
    z[6,5,4]  R1707     -2.0273329690098763e-02
    z[6,5,4]  R1708     -8.0797486007213593e-02
    z[6,5,4]  R1709     1.7193509638309479e-01
    z[6,5,4]  R1710     3.0143103003501892e-01
    z[6,5,4]  R1711     2.8488751500844955e-02
    z[6,5,4]  R1712     2.5044327974319458e-01
    z[6,5,4]  R1713     2.7663178741931915e-02
    z[6,5,4]  R1714     7.2973388433456421e-01
    z[6,5,4]  R1715     1.9733099639415741e-01
    z[6,5,4]  R1716     7.4615710973739624e-01
    z[6,5,4]  R1717     -1.6516859829425812e-01
    z[6,5,4]  R1718     3.3730453252792358e-01
    z[6,5,4]  R1719     0.0498795211315155
    z[6,5,4]  R1720     3.7845957279205322e-01
    z[6,5,4]  R1721     4.8017796874046326e-01
    z[6,5,4]  R1722     1.8214242160320282e-01
    z[6,5,4]  R1723     2.7879974246025085e-01
    z[6,5,4]  R1724     -2.2715424001216888e-01
    z[6,5,4]  R1725     -2.0099349319934845e-01
    z[6,5,4]  R1726     5.0853151082992554e-01
    z[6,5,4]  R1727     -1.7937676608562469e-01
    z[6,5,4]  R1728     -1.8026949465274811e-01
    z[6,5,4]  R1729     8.8719859719276428e-02
    z[6,5,4]  R1730     1.4271272718906403e-01
    z[6,5,4]  R1731     -1.2888167798519135e-01
    z[6,5,4]  R1732     3.2883301377296448e-01
    z[6,5,4]  R1733     -0.0935700535774231
    z[6,5,4]  R1734     1.5172238647937775e-01
    z[6,5,4]  R1735     4.0937563776969910e-01
    z[6,5,4]  R1736     5.6467449665069580e-01
    z[6,5,4]  R1737     3.2929587364196777e-01
    z[6,5,4]  R1738     -0.0696905255317688
    z[6,5,4]  R1739     -5.3936969488859177e-02
    z[6,5,4]  R1740     7.8755879402160645e-01
    z[6,5,4]  R1741     2.7873307466506958e-01
    z[6,5,4]  R1742     1.9228503108024597e-01
    z[6,5,4]  R1743     3.1026398763060570e-02
    z[6,5,4]  R1744     1.2565727531909943e-01
    z[6,5,4]  R1745     2.1122060716152191e-01
    z[6,5,4]  R1746     -1.0344945639371872e-01
    z[6,5,4]  R1747     5.7111438363790512e-02
    z[6,5,4]  R1748     2.3274549841880798e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1647     -1
    z[6,5,5]  R1648     1
    z[6,5,5]  R1651     6.9417193531990051e-02
    z[6,5,5]  R1652     1.5506243705749512e-01
    z[6,5,5]  R1653     3.7132057547569275e-01
    z[6,5,5]  R1654     2.1465530991554260e-01
    z[6,5,5]  R1655     1.0117302089929581e-01
    z[6,5,5]  R1656     2.5743028521537781e-01
    z[6,5,5]  R1657     -0.305356502532959
    z[6,5,5]  R1658     -1.4670735597610474e-01
    z[6,5,5]  R1659     -7.6789689064025879e-01
    z[6,5,5]  R1660     -6.5999329090118408e-01
    z[6,5,5]  R1661     4.4676882028579712e-01
    z[6,5,5]  R1662     2.8443023562431335e-01
    z[6,5,5]  R1663     3.3078234642744064e-02
    z[6,5,5]  R1664     -3.0063995718955994e-01
    z[6,5,5]  R1665     2.8809410333633423e-01
    z[6,5,5]  R1666     -0.0702296569943428
    z[6,5,5]  R1667     2.3496554791927338e-01
    z[6,5,5]  R1668     -4.1340142488479614e-02
    z[6,5,5]  R1669     4.4156956672668457e-01
    z[6,5,5]  R1670     4.3883880972862244e-01
    z[6,5,5]  R1671     -4.7935396432876587e-02
    z[6,5,5]  R1672     -5.1559843122959137e-02
    z[6,5,5]  R1673     1.7003294825553894e-01
    z[6,5,5]  R1674     -9.0687476098537445e-02
    z[6,5,5]  R1675     -2.9200930148363113e-02
    z[6,5,5]  R1676     2.5748556945472956e-03
    z[6,5,5]  R1677     -3.8776826858520508e-01
    z[6,5,5]  R1678     -3.2422986626625061e-01
    z[6,5,5]  R1679     1.9909940659999847e-02
    z[6,5,5]  R1680     -3.2066482305526733e-01
    z[6,5,5]  R1681     6.5030759572982788e-01
    z[6,5,5]  R1682     0.18819560110569
    z[6,5,5]  R1683     1.9532483071088791e-02
    z[6,5,5]  R1684     6.8907028436660767e-01
    z[6,5,5]  R1685     7.6346707344055176e-01
    z[6,5,5]  R1686     3.1301450729370117e-01
    z[6,5,5]  R1687     7.1340814232826233e-02
    z[6,5,5]  R1688     1.0498243570327759e-01
    z[6,5,5]  R1689     1.6161866486072540e-01
    z[6,5,5]  R1690     -2.5649511814117432e-01
    z[6,5,5]  R1691     -5.0993365049362183e-01
    z[6,5,5]  R1692     -3.1566226482391357e-01
    z[6,5,5]  R1693     5.1966842263936996e-02
    z[6,5,5]  R1694     6.5858006477355957e-02
    z[6,5,5]  R1695     0.0646321102976799
    z[6,5,5]  R1696     2.7212062478065491e-01
    z[6,5,5]  R1697     -4.4912809133529663e-01
    z[6,5,5]  R1698     6.9142395257949829e-01
    z[6,5,5]  R1699     -7.7091202139854431e-02
    z[6,5,5]  R1700     -2.8734761476516724e-01
    z[6,5,5]  R1701     6.4398103859275579e-04
    z[6,5,5]  R1702     -8.3091638982295990e-02
    z[6,5,5]  R1703     -3.5906833410263062e-01
    z[6,5,5]  R1704     1.7532955110073090e-01
    z[6,5,5]  R1705     8.3269372582435608e-02
    z[6,5,5]  R1706     -0.0711384192109108
    z[6,5,5]  R1707     -6.2169115990400314e-02
    z[6,5,5]  R1708     1.5969856083393097e-01
    z[6,5,5]  R1709     1.9097542762756348e-01
    z[6,5,5]  R1710     2.0190049707889557e-01
    z[6,5,5]  R1711     4.2580485343933105e-01
    z[6,5,5]  R1712     1.8876263499259949e-01
    z[6,5,5]  R1713     -2.1215988695621490e-01
    z[6,5,5]  R1714     -3.3713313937187195e-01
    z[6,5,5]  R1715     6.9382983446121216e-01
    z[6,5,5]  R1716     5.3669852018356323e-01
    z[6,5,5]  R1717     8.0368494987487793e-01
    z[6,5,5]  R1718     8.3032655715942383e-01
    z[6,5,5]  R1719     -2.8334662318229675e-01
    z[6,5,5]  R1720     5.9061342477798462e-01
    z[6,5,5]  R1721     4.6428731083869934e-01
    z[6,5,5]  R1722     7.9928082227706909e-01
    z[6,5,5]  R1723     6.3880944252014160e-01
    z[6,5,5]  R1724     -1.2024427205324173e-01
    z[6,5,5]  R1725     8.8297879695892334e-01
    z[6,5,5]  R1726     0.678679347038269
    z[6,5,5]  R1727     2.0962141454219818e-01
    z[6,5,5]  R1728     2.9410168528556824e-01
    z[6,5,5]  R1729     -1.6936337947845459e-01
    z[6,5,5]  R1730     -2.9251632094383240e-01
    z[6,5,5]  R1731     2.1376506984233856e-01
    z[6,5,5]  R1732     7.2798830270767212e-01
    z[6,5,5]  R1733     1.8158622086048126e-01
    z[6,5,5]  R1734     6.9855982065200806e-01
    z[6,5,5]  R1735     5.7795554399490356e-01
    z[6,5,5]  R1736     -2.6634159684181213e-01
    z[6,5,5]  R1737     3.6635585129261017e-02
    z[6,5,5]  R1738     6.2024587392807007e-01
    z[6,5,5]  R1739     -2.1901336312294006e-01
    z[6,5,5]  R1740     -2.9368248581886292e-01
    z[6,5,5]  R1741     -9.8348014056682587e-02
    z[6,5,5]  R1742     -0.0858580619096756
    z[6,5,5]  R1743     5.0305879116058350e-01
    z[6,5,5]  R1744     1.7933454364538193e-03
    z[6,5,5]  R1745     1.7778772860765457e-02
    z[6,5,5]  R1746     1.3922728598117828e-02
    z[6,5,5]  R1747     6.9761417806148529e-02
    z[6,5,5]  R1748     -1.3274255394935608e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1649     -1
    z[6,5,6]  R1650     1
    z[6,5,6]  R1651     3.1279347836971283e-02
    z[6,5,6]  R1652     -1.2333748489618301e-01
    z[6,5,6]  R1653     -2.9531520605087280e-01
    z[6,5,6]  R1654     4.5990908145904541e-01
    z[6,5,6]  R1655     -6.3684183359146118e-01
    z[6,5,6]  R1656     -1.8181812763214111e-01
    z[6,5,6]  R1657     1.4404557645320892e-01
    z[6,5,6]  R1658     -5.8593165129423141e-02
    z[6,5,6]  R1659     3.1259968876838684e-02
    z[6,5,6]  R1660     2.9459765553474426e-01
    z[6,5,6]  R1661     -8.9009217917919159e-03
    z[6,5,6]  R1662     1.6101954877376556e-01
    z[6,5,6]  R1663     5.1092332601547241e-01
    z[6,5,6]  R1664     -3.2722827792167664e-01
    z[6,5,6]  R1665     -0.340950071811676
    z[6,5,6]  R1666     3.6238130927085876e-01
    z[6,5,6]  R1667     -1.6881616413593292e-01
    z[6,5,6]  R1668     2.3747469484806061e-01
    z[6,5,6]  R1669     -1.9602755084633827e-02
    z[6,5,6]  R1670     3.4779345989227295e-01
    z[6,5,6]  R1671     1.4406830072402954e-01
    z[6,5,6]  R1672     -2.4699696898460388e-01
    z[6,5,6]  R1673     1.8225048482418060e-01
    z[6,5,6]  R1674     0.104326531291008
    z[6,5,6]  R1675     -6.0234349220991135e-03
    z[6,5,6]  R1676     3.6382114887237549e-01
    z[6,5,6]  R1677     -1.3241605460643768e-01
    z[6,5,6]  R1678     3.2028988003730774e-01
    z[6,5,6]  R1679     -1.9152744114398956e-01
    z[6,5,6]  R1680     -2.9902998358011246e-02
    z[6,5,6]  R1681     -1.2477464973926544e-01
    z[6,5,6]  R1682     3.0275234580039978e-01
    z[6,5,6]  R1683     -1.3602021336555481e-01
    z[6,5,6]  R1684     2.1427385509014130e-02
    z[6,5,6]  R1685     2.4743328988552094e-01
    z[6,5,6]  R1686     -0.0496220663189888
    z[6,5,6]  R1687     3.2432243227958679e-02
    z[6,5,6]  R1688     2.0292037725448608e-01
    z[6,5,6]  R1689     3.0066993832588196e-01
    z[6,5,6]  R1690     -1.1451942473649979e-01
    z[6,5,6]  R1691     -1.2496767193078995e-01
    z[6,5,6]  R1692     -3.3959320187568665e-01
    z[6,5,6]  R1693     1.5946586430072784e-01
    z[6,5,6]  R1694     5.3904527425765991e-01
    z[6,5,6]  R1695     5.4972756654024124e-02
    z[6,5,6]  R1696     4.8812466859817505e-01
    z[6,5,6]  R1697     0.541669487953186
    z[6,5,6]  R1698     1.6661377251148224e-01
    z[6,5,6]  R1699     4.2185693979263306e-02
    z[6,5,6]  R1700     8.8064707815647125e-02
    z[6,5,6]  R1701     0.0748034194111824
    z[6,5,6]  R1702     1.4905783534049988e-01
    z[6,5,6]  R1703     -1.5778036415576935e-01
    z[6,5,6]  R1704     -2.5766023993492126e-01
    z[6,5,6]  R1705     -2.0082110166549683e-01
    z[6,5,6]  R1706     4.2314846068620682e-02
    z[6,5,6]  R1707     -1.6519361734390259e-01
    z[6,5,6]  R1708     -2.4947854876518250e-01
    z[6,5,6]  R1709     -1.5222434699535370e-01
    z[6,5,6]  R1710     -0.298637717962265
    z[6,5,6]  R1711     -1.2827472388744354e-01
    z[6,5,6]  R1712     -5.2869278006255627e-03
    z[6,5,6]  R1713     2.8611668944358826e-01
    z[6,5,6]  R1714     -3.1322479248046875e-01
    z[6,5,6]  R1715     -2.1153491735458374e-01
    z[6,5,6]  R1716     2.2140184417366982e-02
    z[6,5,6]  R1717     -2.3628962039947510e-01
    z[6,5,6]  R1718     -1.3973458111286163e-01
    z[6,5,6]  R1719     4.2196404933929443e-01
    z[6,5,6]  R1720     -7.4117675423622131e-02
    z[6,5,6]  R1721     -1.4720979332923889e-01
    z[6,5,6]  R1722     1.1466714553534985e-02
    z[6,5,6]  R1723     3.2258301973342896e-01
    z[6,5,6]  R1724     -2.4573981761932373e-01
    z[6,5,6]  R1725     9.1757513582706451e-02
    z[6,5,6]  R1726     -0.036479651927948
    z[6,5,6]  R1727     -3.6137616634368896e-01
    z[6,5,6]  R1728     6.5060378983616829e-03
    z[6,5,6]  R1729     4.0706261992454529e-01
    z[6,5,6]  R1730     2.9850575327873230e-01
    z[6,5,6]  R1731     3.7586751580238342e-01
    z[6,5,6]  R1732     1.6976203769445419e-02
    z[6,5,6]  R1733     -1.0731585323810577e-01
    z[6,5,6]  R1734     -2.7284076809883118e-01
    z[6,5,6]  R1735     -2.2479134798049927e-01
    z[6,5,6]  R1736     1.0838758200407028e-01
    z[6,5,6]  R1737     -3.8693693280220032e-01
    z[6,5,6]  R1738     -2.7461314201354980e-01
    z[6,5,6]  R1739     2.4959123134613037e-01
    z[6,5,6]  R1740     -3.4637156128883362e-01
    z[6,5,6]  R1741     -7.7166631817817688e-02
    z[6,5,6]  R1742     0.0599825382232666
    z[6,5,6]  R1743     2.8436020016670227e-01
    z[6,5,6]  R1744     -1.1480133235454559e-01
    z[6,5,6]  R1745     -1.4487040042877197e-01
    z[6,5,6]  R1746     1.1831221729516983e-01
    z[6,5,6]  R1747     -2.2547294199466705e-01
    z[6,5,6]  R1748     1.3696002960205078e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R1749     -1
    z[6,7,0]  R1750     1
    z[6,7,0]  R1763     -3.4049317240715027e-01
    z[6,7,0]  R1764     -6.3429397344589233e-01
    z[6,7,0]  R1765     -3.6248835921287537e-01
    z[6,7,0]  R1766     -3.5702109336853027e-01
    z[6,7,0]  R1767     -6.6193765401840210e-01
    z[6,7,0]  R1768     -5.0425916910171509e-01
    z[6,7,0]  R1769     -7.4791139364242554e-01
    z[6,7,0]  R1770     -4.9772980809211731e-01
    z[6,7,0]  R1771     3.8281381130218506e-02
    z[6,7,0]  R1772     2.4762129783630371e-01
    z[6,7,0]  R1773     3.6441591382026672e-01
    z[6,7,0]  R1774     4.7362810373306274e-01
    z[6,7,0]  R1775     1.6266094148159027e-01
    z[6,7,0]  R1776     5.5636501312255859e-01
    z[6,7,0]  R1777     6.0811895132064819e-01
    z[6,7,0]  R1778     -4.3223667144775391e-01
    z[6,7,0]  R1779     -8.9919343590736389e-02
    z[6,7,0]  R1780     1.3340255618095398e-01
    z[6,7,0]  R1781     -1.4150561392307281e-01
    z[6,7,0]  R1782     -2.0386894047260284e-01
    z[6,7,0]  R1783     -1.4164708554744720e-01
    z[6,7,0]  R1784     2.2895674407482147e-01
    z[6,7,0]  R1785     5.8498895168304443e-01
    z[6,7,0]  R1786     7.5233328342437744e-01
    z[6,7,0]  R1787     -2.8807312250137329e-01
    z[6,7,0]  R1788     -1.7447084188461304e-01
    z[6,7,0]  R1789     6.2511068582534790e-01
    z[6,7,0]  R1790     -3.0400281772017479e-02
    z[6,7,0]  R1791     -2.3215585947036743e-01
    z[6,7,0]  R1792     -2.9119861125946045e-01
    z[6,7,0]  R1793     1.1829664558172226e-01
    z[6,7,0]  R1794     -2.2391916811466217e-01
    z[6,7,0]  R1795     -1.9385483860969543e-01
    z[6,7,0]  R1796     1.2414071708917618e-01
    z[6,7,0]  R1797     -8.9991658926010132e-02
    z[6,7,0]  R1798     -1.2856583297252655e-01
    z[6,7,0]  R1799     1.6626198589801788e-01
    z[6,7,0]  R1800     3.9438480138778687e-01
    z[6,7,0]  R1801     2.3051121830940247e-01
    z[6,7,0]  R1802     4.7068125009536743e-01
    z[6,7,0]  R1803     -6.0311275720596313e-01
    z[6,7,0]  R1804     -4.1975772380828857e-01
    z[6,7,0]  R1805     -3.1643310189247131e-01
    z[6,7,0]  R1806     -7.3209822177886963e-01
    z[6,7,0]  R1807     -3.8009262084960938e-01
    z[6,7,0]  R1808     -5.7497209310531616e-01
    z[6,7,0]  R1809     -5.8650773763656616e-01
    z[6,7,0]  R1810     -2.9185107350349426e-01
    z[6,7,0]  R1811     8.0453574657440186e-02
    z[6,7,0]  R1812     9.2267148196697235e-02
    z[6,7,0]  R1813     5.6734681129455566e-01
    z[6,7,0]  R1814     2.2795991599559784e-01
    z[6,7,0]  R1815     1.9536599516868591e-01
    z[6,7,0]  R1816     3.6459165811538696e-01
    z[6,7,0]  R1817     4.6201157569885254e-01
    z[6,7,0]  R1818     1.5664654970169067e-01
    z[6,7,0]  R1819     2.9601752758026123e-01
    z[6,7,0]  R1820     3.2193651795387268e-01
    z[6,7,0]  R1821     1.2798857688903809e-01
    z[6,7,0]  R1822     -4.2925652116537094e-02
    z[6,7,0]  R1823     -7.6961651444435120e-02
    z[6,7,0]  R1824     -5.2419453859329224e-03
    z[6,7,0]  R1825     7.5517058372497559e-01
    z[6,7,0]  R1826     7.0789128541946411e-01
    z[6,7,0]  R1827     5.7917181402444839e-02
    z[6,7,0]  R1828     2.1695601940155029e-01
    z[6,7,0]  R1829     5.8190357685089111e-01
    z[6,7,0]  R1830     5.3303050994873047e-01
    z[6,7,0]  R1831     3.0288097262382507e-01
    z[6,7,0]  R1832     3.5710540413856506e-01
    z[6,7,0]  R1833     2.0632442831993103e-01
    z[6,7,0]  R1834     2.3541665077209473e-01
    z[6,7,0]  R1835     -1.2956586666405201e-02
    z[6,7,0]  R1836     -8.2483284175395966e-02
    z[6,7,0]  R1837     1.7666345834732056e-01
    z[6,7,0]  R1838     4.5829281210899353e-02
    z[6,7,0]  R1839     -2.0481142401695251e-01
    z[6,7,0]  R1840     4.0946954488754272e-01
    z[6,7,0]  R1841     -9.0658646076917648e-03
    z[6,7,0]  R1842     1.1737505905330181e-02
    z[6,7,0]  R1843     -7.6344244182109833e-02
    z[6,7,0]  R1844     -2.6834377646446228e-01
    z[6,7,0]  R1845     1.8595089018344879e-01
    z[6,7,0]  R1846     2.3791874945163727e-01
    z[6,7,0]  R1847     1.1654905974864960e-01
    z[6,7,0]  R1848     -1.1005988717079163e-01
    z[6,7,0]  R1849     6.6533386707305908e-02
    z[6,7,0]  R1850     1.3699270784854889e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R1751     -1
    z[6,7,1]  R1752     1
    z[6,7,1]  R1763     -1.3459932059049606e-02
    z[6,7,1]  R1764     5.1934242248535156e-01
    z[6,7,1]  R1765     -7.9995006322860718e-02
    z[6,7,1]  R1766     0.0594286248087883
    z[6,7,1]  R1767     -5.0231166183948517e-02
    z[6,7,1]  R1768     1.3360656797885895e-01
    z[6,7,1]  R1769     4.5835691690444946e-01
    z[6,7,1]  R1770     -4.5497417449951172e-02
    z[6,7,1]  R1771     -1.8592052161693573e-01
    z[6,7,1]  R1772     -5.0240028649568558e-03
    z[6,7,1]  R1773     -5.2224469184875488e-01
    z[6,7,1]  R1774     -6.3291859626770020e-01
    z[6,7,1]  R1775     -6.0845259577035904e-02
    z[6,7,1]  R1776     -5.1689177751541138e-01
    z[6,7,1]  R1777     -3.9240229129791260e-01
    z[6,7,1]  R1778     -7.2546893358230591e-01
    z[6,7,1]  R1779     -6.4258140325546265e-01
    z[6,7,1]  R1780     -5.2906662225723267e-01
    z[6,7,1]  R1781     6.9133386015892029e-02
    z[6,7,1]  R1782     -3.1099589541554451e-02
    z[6,7,1]  R1783     -2.2310295701026917e-01
    z[6,7,1]  R1784     -6.4148336648941040e-01
    z[6,7,1]  R1785     -2.5085499882698059e-01
    z[6,7,1]  R1786     -1.7219226062297821e-01
    z[6,7,1]  R1787     -7.9821836948394775e-01
    z[6,7,1]  R1788     -7.4681842327117920e-01
    z[6,7,1]  R1789     -2.1572041511535645e-01
    z[6,7,1]  R1790     -7.3871570825576782e-01
    z[6,7,1]  R1791     -7.3048555850982666e-01
    z[6,7,1]  R1792     -6.9063276052474976e-01
    z[6,7,1]  R1793     -4.0086838603019714e-01
    z[6,7,1]  R1794     -8.0846118927001953e-01
    z[6,7,1]  R1795     -0.766937255859375
    z[6,7,1]  R1796     3.8483718037605286e-01
    z[6,7,1]  R1797     3.0647650361061096e-01
    z[6,7,1]  R1798     4.7750377655029297e-01
    z[6,7,1]  R1799     7.7439749240875244e-01
    z[6,7,1]  R1800     7.8351211547851562e-01
    z[6,7,1]  R1801     7.4697548151016235e-01
    z[6,7,1]  R1802     0.796562671661377
    z[6,7,1]  R1803     1.6140025854110718e-01
    z[6,7,1]  R1804     4.5965674519538879e-01
    z[6,7,1]  R1805     -7.6316393911838531e-02
    z[6,7,1]  R1806     -2.3349776864051819e-01
    z[6,7,1]  R1807     1.9021511077880859e-01
    z[6,7,1]  R1808     -2.9934826493263245e-01
    z[6,7,1]  R1809     -9.7319453954696655e-02
    z[6,7,1]  R1810     -7.7453780174255371e-01
    z[6,7,1]  R1811     -9.0730965137481689e-01
    z[6,7,1]  R1812     -6.3884317874908447e-01
    z[6,7,1]  R1813     4.2621025443077087e-01
    z[6,7,1]  R1814     3.0166879296302795e-01
    z[6,7,1]  R1815     0.0885414183139801
    z[6,7,1]  R1816     1.8170714378356934e-01
    z[6,7,1]  R1817     6.4333818852901459e-02
    z[6,7,1]  R1818     3.0959376692771912e-01
    z[6,7,1]  R1819     1.5628987550735474e-01
    z[6,7,1]  R1820     1.6214667260646820e-01
    z[6,7,1]  R1821     6.6457551717758179e-01
    z[6,7,1]  R1822     0.821221113204956
    z[6,7,1]  R1823     -4.9151638150215149e-01
    z[6,7,1]  R1824     -3.7890347838401794e-01
    z[6,7,1]  R1825     2.1322643756866455e-01
    z[6,7,1]  R1826     2.4058306217193604e-01
    z[6,7,1]  R1827     -2.1792949736118317e-01
    z[6,7,1]  R1828     -2.5230693817138672e-01
    z[6,7,1]  R1829     2.8330886363983154e-01
    z[6,7,1]  R1830     4.7625762224197388e-01
    z[6,7,1]  R1831     9.5401480793952942e-02
    z[6,7,1]  R1832     1.6792092472314835e-02
    z[6,7,1]  R1833     -3.6612647771835327e-01
    z[6,7,1]  R1834     -0.584315836429596
    z[6,7,1]  R1835     -3.1234717369079590e-01
    z[6,7,1]  R1836     -6.9596379995346069e-01
    z[6,7,1]  R1837     0.572786271572113
    z[6,7,1]  R1838     -6.2916569411754608e-02
    z[6,7,1]  R1839     -2.0866429805755615e-01
    z[6,7,1]  R1840     -5.1932379603385925e-02
    z[6,7,1]  R1841     6.7793554067611694e-01
    z[6,7,1]  R1842     8.4547185897827148e-01
    z[6,7,1]  R1843     -0.654776394367218
    z[6,7,1]  R1844     -5.0122487545013428e-01
    z[6,7,1]  R1845     -0.17464579641819
    z[6,7,1]  R1846     8.6933094263076782e-01
    z[6,7,1]  R1847     8.5908889770507812e-01
    z[6,7,1]  R1848     8.3578372001647949e-01
    z[6,7,1]  R1849     8.0418592691421509e-01
    z[6,7,1]  R1850     7.8154599666595459e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R1753     -1
    z[6,7,2]  R1754     1
    z[6,7,2]  R1763     -0.560208797454834
    z[6,7,2]  R1764     -4.3954044580459595e-01
    z[6,7,2]  R1765     -3.0679419636726379e-01
    z[6,7,2]  R1766     -4.7865721583366394e-01
    z[6,7,2]  R1767     -3.0638018250465393e-01
    z[6,7,2]  R1768     -1.2894614040851593e-01
    z[6,7,2]  R1769     -2.9435306787490845e-01
    z[6,7,2]  R1770     -6.0012418776750565e-02
    z[6,7,2]  R1771     -1.3119670748710632e-01
    z[6,7,2]  R1772     2.3547196388244629e-01
    z[6,7,2]  R1773     -5.2362614870071411e-01
    z[6,7,2]  R1774     -0.438385546207428
    z[6,7,2]  R1775     -5.9539139270782471e-01
    z[6,7,2]  R1776     3.5121065378189087e-01
    z[6,7,2]  R1777     5.2069473266601562e-01
    z[6,7,2]  R1778     2.0645692944526672e-02
    z[6,7,2]  R1779     6.0132515430450439e-01
    z[6,7,2]  R1780     5.5767655372619629e-01
    z[6,7,2]  R1781     4.3703210353851318e-01
    z[6,7,2]  R1782     4.5359331369400024e-01
    z[6,7,2]  R1783     -4.8705145716667175e-01
    z[6,7,2]  R1784     4.6946480870246887e-01
    z[6,7,2]  R1785     2.7474248409271240e-01
    z[6,7,2]  R1786     5.8647930622100830e-01
    z[6,7,2]  R1787     3.6668869853019714e-01
    z[6,7,2]  R1788     3.1894814968109131e-01
    z[6,7,2]  R1789     2.6994487643241882e-01
    z[6,7,2]  R1790     4.6839416027069092e-01
    z[6,7,2]  R1791     0.56394362449646
    z[6,7,2]  R1792     4.9780625104904175e-01
    z[6,7,2]  R1793     -1.2506563961505890e-01
    z[6,7,2]  R1794     4.0509355068206787e-01
    z[6,7,2]  R1795     4.4223695993423462e-01
    z[6,7,2]  R1796     2.4276073276996613e-01
    z[6,7,2]  R1797     2.3418653011322021e-01
    z[6,7,2]  R1798     1.7361932992935181e-01
    z[6,7,2]  R1799     3.7193521857261658e-01
    z[6,7,2]  R1800     2.2485843300819397e-01
    z[6,7,2]  R1801     5.1996129751205444e-01
    z[6,7,2]  R1802     -3.6978565156459808e-02
    z[6,7,2]  R1803     -4.5959183573722839e-01
    z[6,7,2]  R1804     -5.5117529630661011e-01
    z[6,7,2]  R1805     -3.2845515012741089e-01
    z[6,7,2]  R1806     -3.6801773309707642e-01
    z[6,7,2]  R1807     -2.8529864549636841e-01
    z[6,7,2]  R1808     -6.0903424024581909e-01
    z[6,7,2]  R1809     -1.9481046497821808e-01
    z[6,7,2]  R1810     -4.1978725790977478e-01
    z[6,7,2]  R1811     1.0509595274925232e-01
    z[6,7,2]  R1812     -6.8624660372734070e-02
    z[6,7,2]  R1813     0.410971999168396
    z[6,7,2]  R1814     5.5042487382888794e-01
    z[6,7,2]  R1815     6.3688921928405762e-01
    z[6,7,2]  R1816     -2.5539478287100792e-02
    z[6,7,2]  R1817     4.0504077076911926e-01
    z[6,7,2]  R1818     5.6090480089187622e-01
    z[6,7,2]  R1819     -3.9990995079278946e-02
    z[6,7,2]  R1820     4.5544752478599548e-01
    z[6,7,2]  R1821     1.4628442004323006e-02
    z[6,7,2]  R1822     3.9811581373214722e-01
    z[6,7,2]  R1823     -3.3156388998031616e-01
    z[6,7,2]  R1824     2.9727813601493835e-01
    z[6,7,2]  R1825     1.2578035891056061e-01
    z[6,7,2]  R1826     3.0262774229049683e-01
    z[6,7,2]  R1827     0.33199542760849
    z[6,7,2]  R1828     5.3181892633438110e-01
    z[6,7,2]  R1829     -3.3132388489320874e-04
    z[6,7,2]  R1830     -6.4216554164886475e-01
    z[6,7,2]  R1831     5.5402827262878418e-01
    z[6,7,2]  R1832     2.6416417956352234e-01
    z[6,7,2]  R1833     1.7065095901489258e-01
    z[6,7,2]  R1834     3.1260296702384949e-01
    z[6,7,2]  R1835     1.3980729877948761e-01
    z[6,7,2]  R1836     3.1571972370147705e-01
    z[6,7,2]  R1837     0.355589896440506
    z[6,7,2]  R1838     -2.6504507660865784e-01
    z[6,7,2]  R1839     -2.8752166777849197e-02
    z[6,7,2]  R1840     6.4543402194976807e-01
    z[6,7,2]  R1841     -3.2898673415184021e-01
    z[6,7,2]  R1842     1.8935500085353851e-01
    z[6,7,2]  R1843     2.4685647338628769e-02
    z[6,7,2]  R1844     -2.0121857523918152e-01
    z[6,7,2]  R1845     -2.0923744142055511e-01
    z[6,7,2]  R1846     2.1507760882377625e-01
    z[6,7,2]  R1847     3.6545589566230774e-01
    z[6,7,2]  R1848     4.1203314065933228e-01
    z[6,7,2]  R1849     3.1193997710943222e-02
    z[6,7,2]  R1850     1.7944779992103577e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R1755     -1
    z[6,7,3]  R1756     1
    z[6,7,3]  R1763     7.3736059665679932e-01
    z[6,7,3]  R1764     2.4496375024318695e-01
    z[6,7,3]  R1765     2.7197441458702087e-01
    z[6,7,3]  R1766     5.6444466114044189e-01
    z[6,7,3]  R1767     2.1162256598472595e-01
    z[6,7,3]  R1768     7.8199088573455811e-01
    z[6,7,3]  R1769     8.8519737124443054e-02
    z[6,7,3]  R1770     3.7660104036331177e-01
    z[6,7,3]  R1771     5.6421411037445068e-01
    z[6,7,3]  R1772     5.9436100721359253e-01
    z[6,7,3]  R1773     -2.2799010574817657e-01
    z[6,7,3]  R1774     -2.5736156105995178e-01
    z[6,7,3]  R1775     -5.4242026805877686e-01
    z[6,7,3]  R1776     -2.6262211799621582e-01
    z[6,7,3]  R1777     -3.8348857313394547e-02
    z[6,7,3]  R1778     -2.9589679837226868e-01
    z[6,7,3]  R1779     -3.0975860357284546e-01
    z[6,7,3]  R1780     -2.8315034508705139e-01
    z[6,7,3]  R1781     -3.3291906118392944e-01
    z[6,7,3]  R1782     -3.2870528101921082e-01
    z[6,7,3]  R1783     -6.7682260274887085e-01
    z[6,7,3]  R1784     4.9128532409667969e-01
    z[6,7,3]  R1785     6.4742344617843628e-01
    z[6,7,3]  R1786     -2.0186990499496460e-01
    z[6,7,3]  R1787     3.9293374866247177e-02
    z[6,7,3]  R1788     2.5785389542579651e-01
    z[6,7,3]  R1789     -2.4777875840663910e-01
    z[6,7,3]  R1790     -1.5962266921997070e-01
    z[6,7,3]  R1791     -2.1654102206230164e-01
    z[6,7,3]  R1792     -2.8818780183792114e-01
    z[6,7,3]  R1793     -3.1955018639564514e-01
    z[6,7,3]  R1794     -0.0674697533249855
    z[6,7,3]  R1795     -3.9962741732597351e-01
    z[6,7,3]  R1796     -3.4626686573028564e-01
    z[6,7,3]  R1797     -3.3625563979148865e-01
    z[6,7,3]  R1798     -3.5481536388397217e-01
    z[6,7,3]  R1799     -2.6597523689270020e-01
    z[6,7,3]  R1800     -1.3726912438869476e-01
    z[6,7,3]  R1801     -4.0699992328882217e-02
    z[6,7,3]  R1802     -2.2174143791198730e-01
    z[6,7,3]  R1803     5.3412193059921265e-01
    z[6,7,3]  R1804     3.5509994626045227e-01
    z[6,7,3]  R1805     5.6234270334243774e-01
    z[6,7,3]  R1806     1.8797422945499420e-01
    z[6,7,3]  R1807     4.3108406662940979e-01
    z[6,7,3]  R1808     2.6964026689529419e-01
    z[6,7,3]  R1809     5.5359804630279541e-01
    z[6,7,3]  R1810     -2.1320657432079315e-01
    z[6,7,3]  R1811     -0.266482949256897
    z[6,7,3]  R1812     -2.5109395384788513e-02
    z[6,7,3]  R1813     6.1683785170316696e-02
    z[6,7,3]  R1814     5.4878854751586914e-01
    z[6,7,3]  R1815     5.7285404205322266e-01
    z[6,7,3]  R1816     -6.4620566368103027e-01
    z[6,7,3]  R1817     2.9126688838005066e-01
    z[6,7,3]  R1818     5.6145054101943970e-01
    z[6,7,3]  R1819     -5.1702308654785156e-01
    z[6,7,3]  R1820     -2.6268932223320007e-01
    z[6,7,3]  R1821     7.1090564131736755e-02
    z[6,7,3]  R1822     -1.5342529118061066e-01
    z[6,7,3]  R1823     -5.6785982847213745e-01
    z[6,7,3]  R1824     -2.7150332927703857e-01
    z[6,7,3]  R1825     5.8796745538711548e-01
    z[6,7,3]  R1826     3.0893996357917786e-01
    z[6,7,3]  R1827     -4.6980452537536621e-01
    z[6,7,3]  R1828     -0.427613228559494
    z[6,7,3]  R1829     -1.9598762691020966e-01
    z[6,7,3]  R1830     -1.6931539773941040e-01
    z[6,7,3]  R1831     3.8242614269256592e-01
    z[6,7,3]  R1832     -8.3257377147674561e-01
    z[6,7,3]  R1833     -0.640066921710968
    z[6,7,3]  R1834     -4.0373942255973816e-01
    z[6,7,3]  R1835     -5.1015150547027588e-01
    z[6,7,3]  R1836     4.0715858340263367e-01
    z[6,7,3]  R1837     0.630540668964386
    z[6,7,3]  R1838     -8.7552732229232788e-01
    z[6,7,3]  R1839     -5.7726246118545532e-01
    z[6,7,3]  R1840     5.5400753021240234e-01
    z[6,7,3]  R1841     -1.1411420255899429e-01
    z[6,7,3]  R1842     -3.7139368057250977e-01
    z[6,7,3]  R1843     -4.6015629172325134e-01
    z[6,7,3]  R1844     -5.1192593574523926e-01
    z[6,7,3]  R1845     -7.3500746488571167e-01
    z[6,7,3]  R1846     -3.4131145477294922e-01
    z[6,7,3]  R1847     -2.5124719738960266e-01
    z[6,7,3]  R1848     -3.1104597449302673e-01
    z[6,7,3]  R1849     -4.5039784908294678e-01
    z[6,7,3]  R1850     -2.8034844994544983e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R1757     -1
    z[6,7,4]  R1758     1
    z[6,7,4]  R1763     -1.4335820078849792e-01
    z[6,7,4]  R1764     -1.8840160965919495e-01
    z[6,7,4]  R1765     -6.8485051393508911e-01
    z[6,7,4]  R1766     -2.5238949060440063e-01
    z[6,7,4]  R1767     -6.9705463945865631e-02
    z[6,7,4]  R1768     -2.0170746371150017e-02
    z[6,7,4]  R1769     -1.4854730665683746e-01
    z[6,7,4]  R1770     -7.6145190000534058e-01
    z[6,7,4]  R1771     1.9435827434062958e-01
    z[6,7,4]  R1772     8.6991004645824432e-02
    z[6,7,4]  R1773     2.6194646954536438e-01
    z[6,7,4]  R1774     -0.0992252379655838
    z[6,7,4]  R1775     2.4288235604763031e-01
    z[6,7,4]  R1776     -1.8302644789218903e-01
    z[6,7,4]  R1777     -6.6127941012382507e-02
    z[6,7,4]  R1778     2.5026535987854004e-01
    z[6,7,4]  R1779     -1.9430282711982727e-01
    z[6,7,4]  R1780     5.0300270318984985e-01
    z[6,7,4]  R1781     6.9137299060821533e-01
    z[6,7,4]  R1782     5.7457500696182251e-01
    z[6,7,4]  R1783     -4.6021699905395508e-01
    z[6,7,4]  R1784     1.0321640968322754e-01
    z[6,7,4]  R1785     1.9517336785793304e-01
    z[6,7,4]  R1786     2.2953076288104057e-02
    z[6,7,4]  R1787     3.7811064720153809e-01
    z[6,7,4]  R1788     3.3351635932922363e-01
    z[6,7,4]  R1789     0.510429859161377
    z[6,7,4]  R1790     -2.8141397982835770e-02
    z[6,7,4]  R1791     1.0243520140647888e-01
    z[6,7,4]  R1792     -6.0386221855878830e-02
    z[6,7,4]  R1793     -0.518736720085144
    z[6,7,4]  R1794     2.2828787565231323e-02
    z[6,7,4]  R1795     8.2920975983142853e-03
    z[6,7,4]  R1796     4.2705839872360229e-01
    z[6,7,4]  R1797     2.9318472743034363e-01
    z[6,7,4]  R1798     7.0638722181320190e-01
    z[6,7,4]  R1799     3.9679402112960815e-01
    z[6,7,4]  R1800     3.3010202646255493e-01
    z[6,7,4]  R1801     1.8786674365401268e-02
    z[6,7,4]  R1802     1.2044016271829605e-01
    z[6,7,4]  R1803     2.2251971065998077e-02
    z[6,7,4]  R1804     -2.3627656698226929e-01
    z[6,7,4]  R1805     -4.4636905193328857e-01
    z[6,7,4]  R1806     8.7686873972415924e-02
    z[6,7,4]  R1807     -7.2892510890960693e-01
    z[6,7,4]  R1808     -2.8721296787261963e-01
    z[6,7,4]  R1809     -3.9025208353996277e-01
    z[6,7,4]  R1810     1.4211065135896206e-02
    z[6,7,4]  R1811     -1.4557726681232452e-01
    z[6,7,4]  R1812     5.5874037742614746e-01
    z[6,7,4]  R1813     1.8388934433460236e-01
    z[6,7,4]  R1814     1.5091983973979950e-01
    z[6,7,4]  R1815     -3.9319179952144623e-02
    z[6,7,4]  R1816     -4.6640940010547638e-02
    z[6,7,4]  R1817     -3.1542456150054932e-01
    z[6,7,4]  R1818     3.7751308083534241e-01
    z[6,7,4]  R1819     6.8618780374526978e-01
    z[6,7,4]  R1820     -4.1213774681091309e-01
    z[6,7,4]  R1821     3.3205825090408325e-01
    z[6,7,4]  R1822     2.5704520940780640e-01
    z[6,7,4]  R1823     0.366986483335495
    z[6,7,4]  R1824     4.7017842531204224e-02
    z[6,7,4]  R1825     -2.4060022085905075e-02
    z[6,7,4]  R1826     -3.1388887763023376e-01
    z[6,7,4]  R1827     4.5337316393852234e-01
    z[6,7,4]  R1828     3.8295388221740723e-01
    z[6,7,4]  R1829     -5.7923948764801025e-01
    z[6,7,4]  R1830     -2.0442249253392220e-02
    z[6,7,4]  R1831     4.6696513891220093e-01
    z[6,7,4]  R1832     4.5723305083811283e-03
    z[6,7,4]  R1833     5.8073186874389648e-01
    z[6,7,4]  R1834     -2.2077956795692444e-01
    z[6,7,4]  R1835     5.2164965867996216e-01
    z[6,7,4]  R1836     3.5395428538322449e-01
    z[6,7,4]  R1837     2.5436949729919434e-01
    z[6,7,4]  R1838     -3.7642422318458557e-01
    z[6,7,4]  R1839     -3.0911937355995178e-01
    z[6,7,4]  R1840     -1.6816121339797974e-01
    z[6,7,4]  R1841     5.3540492057800293e-01
    z[6,7,4]  R1842     1.9686232507228851e-01
    z[6,7,4]  R1843     3.8858780264854431e-01
    z[6,7,4]  R1844     7.1289457380771637e-02
    z[6,7,4]  R1845     -4.0224009752273560e-01
    z[6,7,4]  R1846     1.4052438735961914e-01
    z[6,7,4]  R1847     -1.4828655123710632e-01
    z[6,7,4]  R1848     3.1841620802879333e-02
    z[6,7,4]  R1849     1.7281240224838257e-01
    z[6,7,4]  R1850     2.6056563854217529e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R1759     -1
    z[6,7,5]  R1760     1
    z[6,7,5]  R1763     6.9417193531990051e-02
    z[6,7,5]  R1764     1.5506243705749512e-01
    z[6,7,5]  R1765     3.7132057547569275e-01
    z[6,7,5]  R1766     2.1465530991554260e-01
    z[6,7,5]  R1767     1.0117302089929581e-01
    z[6,7,5]  R1768     2.5743028521537781e-01
    z[6,7,5]  R1769     -0.305356502532959
    z[6,7,5]  R1770     -1.4670735597610474e-01
    z[6,7,5]  R1771     -7.6789689064025879e-01
    z[6,7,5]  R1772     -6.5999329090118408e-01
    z[6,7,5]  R1773     4.4676882028579712e-01
    z[6,7,5]  R1774     2.8443023562431335e-01
    z[6,7,5]  R1775     3.3078234642744064e-02
    z[6,7,5]  R1776     -3.0063995718955994e-01
    z[6,7,5]  R1777     2.8809410333633423e-01
    z[6,7,5]  R1778     -0.0702296569943428
    z[6,7,5]  R1779     2.3496554791927338e-01
    z[6,7,5]  R1780     -4.1340142488479614e-02
    z[6,7,5]  R1781     4.4156956672668457e-01
    z[6,7,5]  R1782     4.3883880972862244e-01
    z[6,7,5]  R1783     -4.7935396432876587e-02
    z[6,7,5]  R1784     -5.1559843122959137e-02
    z[6,7,5]  R1785     1.7003294825553894e-01
    z[6,7,5]  R1786     -9.0687476098537445e-02
    z[6,7,5]  R1787     -2.9200930148363113e-02
    z[6,7,5]  R1788     2.5748556945472956e-03
    z[6,7,5]  R1789     -3.8776826858520508e-01
    z[6,7,5]  R1790     -3.2422986626625061e-01
    z[6,7,5]  R1791     1.9909940659999847e-02
    z[6,7,5]  R1792     -3.2066482305526733e-01
    z[6,7,5]  R1793     6.5030759572982788e-01
    z[6,7,5]  R1794     0.18819560110569
    z[6,7,5]  R1795     1.9532483071088791e-02
    z[6,7,5]  R1796     6.8907028436660767e-01
    z[6,7,5]  R1797     7.6346707344055176e-01
    z[6,7,5]  R1798     3.1301450729370117e-01
    z[6,7,5]  R1799     7.1340814232826233e-02
    z[6,7,5]  R1800     1.0498243570327759e-01
    z[6,7,5]  R1801     1.6161866486072540e-01
    z[6,7,5]  R1802     -2.5649511814117432e-01
    z[6,7,5]  R1803     1.4725837111473083e-01
    z[6,7,5]  R1804     1.5593683719635010e-01
    z[6,7,5]  R1805     4.4074773788452148e-01
    z[6,7,5]  R1806     3.3375957608222961e-01
    z[6,7,5]  R1807     1.0006825625896454e-01
    z[6,7,5]  R1808     -3.3978302963078022e-03
    z[6,7,5]  R1809     -2.8802141547203064e-01
    z[6,7,5]  R1810     -2.9621142148971558e-01
    z[6,7,5]  R1811     1.9540265202522278e-01
    z[6,7,5]  R1812     -4.0066826343536377e-01
    z[6,7,5]  R1813     3.0967578291893005e-01
    z[6,7,5]  R1814     -4.0537956357002258e-01
    z[6,7,5]  R1815     -2.8869214653968811e-01
    z[6,7,5]  R1816     -4.5290020108222961e-01
    z[6,7,5]  R1817     -4.5167851448059082e-01
    z[6,7,5]  R1818     0.0571405366063118
    z[6,7,5]  R1819     3.5836282372474670e-01
    z[6,7,5]  R1820     -9.0226821601390839e-02
    z[6,7,5]  R1821     -6.4252573251724243e-01
    z[6,7,5]  R1822     -2.7371481060981750e-01
    z[6,7,5]  R1823     3.3961218595504761e-01
    z[6,7,5]  R1824     -4.0715846419334412e-01
    z[6,7,5]  R1825     -1.2031991779804230e-01
    z[6,7,5]  R1826     -1.8161757290363312e-01
    z[6,7,5]  R1827     3.1795452814549208e-03
    z[6,7,5]  R1828     5.5409610271453857e-02
    z[6,7,5]  R1829     -2.9763779044151306e-01
    z[6,7,5]  R1830     1.8753847479820251e-01
    z[6,7,5]  R1831     -4.5380941033363342e-01
    z[6,7,5]  R1832     -2.9769745469093323e-01
    z[6,7,5]  R1833     -1.7324566841125488e-01
    z[6,7,5]  R1834     -5.0331324338912964e-01
    z[6,7,5]  R1835     -1.7354843020439148e-01
    z[6,7,5]  R1836     -1.4737382531166077e-02
    z[6,7,5]  R1837     -2.2738638520240784e-01
    z[6,7,5]  R1838     7.1067869663238525e-02
    z[6,7,5]  R1839     2.7304738759994507e-01
    z[6,7,5]  R1840     -0.157281756401062
    z[6,7,5]  R1841     -3.2786116003990173e-01
    z[6,7,5]  R1842     -1.9458128511905670e-01
    z[6,7,5]  R1843     -1.7302711308002472e-01
    z[6,7,5]  R1844     5.1286923885345459e-01
    z[6,7,5]  R1845     -2.5918769836425781e-01
    z[6,7,5]  R1846     -0.0354522168636322
    z[6,7,5]  R1847     2.3612717166543007e-02
    z[6,7,5]  R1848     -3.3197902143001556e-02
    z[6,7,5]  R1849     1.9197198748588562e-01
    z[6,7,5]  R1850     4.0260636806488037e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R1761     -1
    z[6,7,6]  R1762     1
    z[6,7,6]  R1763     3.1279347836971283e-02
    z[6,7,6]  R1764     -1.2333748489618301e-01
    z[6,7,6]  R1765     -2.9531520605087280e-01
    z[6,7,6]  R1766     4.5990908145904541e-01
    z[6,7,6]  R1767     -6.3684183359146118e-01
    z[6,7,6]  R1768     -1.8181812763214111e-01
    z[6,7,6]  R1769     1.4404557645320892e-01
    z[6,7,6]  R1770     -5.8593165129423141e-02
    z[6,7,6]  R1771     3.1259968876838684e-02
    z[6,7,6]  R1772     2.9459765553474426e-01
    z[6,7,6]  R1773     -8.9009217917919159e-03
    z[6,7,6]  R1774     1.6101954877376556e-01
    z[6,7,6]  R1775     5.1092332601547241e-01
    z[6,7,6]  R1776     -3.2722827792167664e-01
    z[6,7,6]  R1777     -0.340950071811676
    z[6,7,6]  R1778     3.6238130927085876e-01
    z[6,7,6]  R1779     -1.6881616413593292e-01
    z[6,7,6]  R1780     2.3747469484806061e-01
    z[6,7,6]  R1781     -1.9602755084633827e-02
    z[6,7,6]  R1782     3.4779345989227295e-01
    z[6,7,6]  R1783     1.4406830072402954e-01
    z[6,7,6]  R1784     -2.4699696898460388e-01
    z[6,7,6]  R1785     1.8225048482418060e-01
    z[6,7,6]  R1786     0.104326531291008
    z[6,7,6]  R1787     -6.0234349220991135e-03
    z[6,7,6]  R1788     3.6382114887237549e-01
    z[6,7,6]  R1789     -1.3241605460643768e-01
    z[6,7,6]  R1790     3.2028988003730774e-01
    z[6,7,6]  R1791     -1.9152744114398956e-01
    z[6,7,6]  R1792     -2.9902998358011246e-02
    z[6,7,6]  R1793     -1.2477464973926544e-01
    z[6,7,6]  R1794     3.0275234580039978e-01
    z[6,7,6]  R1795     -1.3602021336555481e-01
    z[6,7,6]  R1796     2.1427385509014130e-02
    z[6,7,6]  R1797     2.4743328988552094e-01
    z[6,7,6]  R1798     -0.0496220663189888
    z[6,7,6]  R1799     3.2432243227958679e-02
    z[6,7,6]  R1800     2.0292037725448608e-01
    z[6,7,6]  R1801     3.0066993832588196e-01
    z[6,7,6]  R1802     -1.1451942473649979e-01
    z[6,7,6]  R1803     -0.302512526512146
    z[6,7,6]  R1804     3.2013422250747681e-01
    z[6,7,6]  R1805     2.7645963430404663e-01
    z[6,7,6]  R1806     3.4591197967529297e-01
    z[6,7,6]  R1807     -1.0379598289728165e-01
    z[6,7,6]  R1808     2.3165971040725708e-01
    z[6,7,6]  R1809     2.5857791304588318e-01
    z[6,7,6]  R1810     -7.2749868035316467e-02
    z[6,7,6]  R1811     1.6995021700859070e-01
    z[6,7,6]  R1812     3.2450035214424133e-01
    z[6,7,6]  R1813     4.4050562381744385e-01
    z[6,7,6]  R1814     -2.5648474693298340e-01
    z[6,7,6]  R1815     -3.6785000562667847e-01
    z[6,7,6]  R1816     -4.5664796233177185e-01
    z[6,7,6]  R1817     4.7958934307098389e-01
    z[6,7,6]  R1818     3.2247710227966309e-01
    z[6,7,6]  R1819     -1.4056035876274109e-01
    z[6,7,6]  R1820     -6.4469277858734131e-01
    z[6,7,6]  R1821     -1.1656996607780457e-01
    z[6,7,6]  R1822     -2.6940440759062767e-02
    z[6,7,6]  R1823     2.6471406221389771e-01
    z[6,7,6]  R1824     -7.2548437118530273e-01
    z[6,7,6]  R1825     8.7576441466808319e-02
    z[6,7,6]  R1826     -3.4995871782302856e-01
    z[6,7,6]  R1827     -6.4238435029983521e-01
    z[6,7,6]  R1828     -5.2331924438476562e-01
    z[6,7,6]  R1829     3.4439265727996826e-01
    z[6,7,6]  R1830     -1.1146487295627594e-01
    z[6,7,6]  R1831     -1.4820632338523865e-01
    z[6,7,6]  R1832     -1.4348258078098297e-01
    z[6,7,6]  R1833     -1.3156990706920624e-01
    z[6,7,6]  R1834     -2.0089823007583618e-01
    z[6,7,6]  R1835     -5.6589150428771973e-01
    z[6,7,6]  R1836     -3.4332635998725891e-01
    z[6,7,6]  R1837     -1.6490109264850616e-02
    z[6,7,6]  R1838     1.0197193175554276e-01
    z[6,7,6]  R1839     -6.4058023691177368e-01
    z[6,7,6]  R1840     2.3046158254146576e-01
    z[6,7,6]  R1841     1.5784651041030884e-01
    z[6,7,6]  R1842     -1.8610309064388275e-01
    z[6,7,6]  R1843     -4.1490641236305237e-01
    z[6,7,6]  R1844     -3.2571631669998169e-01
    z[6,7,6]  R1845     3.4918409585952759e-01
    z[6,7,6]  R1846     6.2470335513353348e-02
    z[6,7,6]  R1847     -1.7074249684810638e-01
    z[6,7,6]  R1848     -1.4392884075641632e-01
    z[6,7,6]  R1849     -2.7983868122100830e-01
    z[6,7,6]  R1850     -1.7215034365653992e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R1851     -1
    z[7,6,0]  R1852     1
    z[7,6,0]  R1865     -6.0311275720596313e-01
    z[7,6,0]  R1866     -4.1975772380828857e-01
    z[7,6,0]  R1867     -3.1643310189247131e-01
    z[7,6,0]  R1868     -7.3209822177886963e-01
    z[7,6,0]  R1869     -3.8009262084960938e-01
    z[7,6,0]  R1870     -5.7497209310531616e-01
    z[7,6,0]  R1871     -5.8650773763656616e-01
    z[7,6,0]  R1872     -2.9185107350349426e-01
    z[7,6,0]  R1873     8.0453574657440186e-02
    z[7,6,0]  R1874     9.2267148196697235e-02
    z[7,6,0]  R1875     5.6734681129455566e-01
    z[7,6,0]  R1876     2.2795991599559784e-01
    z[7,6,0]  R1877     1.9536599516868591e-01
    z[7,6,0]  R1878     3.6459165811538696e-01
    z[7,6,0]  R1879     4.6201157569885254e-01
    z[7,6,0]  R1880     1.5664654970169067e-01
    z[7,6,0]  R1881     2.9601752758026123e-01
    z[7,6,0]  R1882     3.2193651795387268e-01
    z[7,6,0]  R1883     1.2798857688903809e-01
    z[7,6,0]  R1884     -4.2925652116537094e-02
    z[7,6,0]  R1885     -7.6961651444435120e-02
    z[7,6,0]  R1886     -5.2419453859329224e-03
    z[7,6,0]  R1887     7.5517058372497559e-01
    z[7,6,0]  R1888     7.0789128541946411e-01
    z[7,6,0]  R1889     5.7917181402444839e-02
    z[7,6,0]  R1890     2.1695601940155029e-01
    z[7,6,0]  R1891     5.8190357685089111e-01
    z[7,6,0]  R1892     5.3303050994873047e-01
    z[7,6,0]  R1893     3.0288097262382507e-01
    z[7,6,0]  R1894     3.5710540413856506e-01
    z[7,6,0]  R1895     2.0632442831993103e-01
    z[7,6,0]  R1896     2.3541665077209473e-01
    z[7,6,0]  R1897     -1.2956586666405201e-02
    z[7,6,0]  R1898     -8.2483284175395966e-02
    z[7,6,0]  R1899     1.7666345834732056e-01
    z[7,6,0]  R1900     4.5829281210899353e-02
    z[7,6,0]  R1901     -2.0481142401695251e-01
    z[7,6,0]  R1902     4.0946954488754272e-01
    z[7,6,0]  R1903     -9.0658646076917648e-03
    z[7,6,0]  R1904     1.1737505905330181e-02
    z[7,6,0]  R1905     -7.6344244182109833e-02
    z[7,6,0]  R1906     -2.6834377646446228e-01
    z[7,6,0]  R1907     1.8595089018344879e-01
    z[7,6,0]  R1908     2.3791874945163727e-01
    z[7,6,0]  R1909     1.1654905974864960e-01
    z[7,6,0]  R1910     -1.1005988717079163e-01
    z[7,6,0]  R1911     6.6533386707305908e-02
    z[7,6,0]  R1912     1.3699270784854889e-01
    z[7,6,0]  R1913     -3.4049317240715027e-01
    z[7,6,0]  R1914     -6.3429397344589233e-01
    z[7,6,0]  R1915     -3.6248835921287537e-01
    z[7,6,0]  R1916     -3.5702109336853027e-01
    z[7,6,0]  R1917     -6.6193765401840210e-01
    z[7,6,0]  R1918     -5.0425916910171509e-01
    z[7,6,0]  R1919     -7.4791139364242554e-01
    z[7,6,0]  R1920     -4.9772980809211731e-01
    z[7,6,0]  R1921     3.8281381130218506e-02
    z[7,6,0]  R1922     2.4762129783630371e-01
    z[7,6,0]  R1923     3.6441591382026672e-01
    z[7,6,0]  R1924     4.7362810373306274e-01
    z[7,6,0]  R1925     1.6266094148159027e-01
    z[7,6,0]  R1926     5.5636501312255859e-01
    z[7,6,0]  R1927     6.0811895132064819e-01
    z[7,6,0]  R1928     -4.3223667144775391e-01
    z[7,6,0]  R1929     -8.9919343590736389e-02
    z[7,6,0]  R1930     1.3340255618095398e-01
    z[7,6,0]  R1931     -1.4150561392307281e-01
    z[7,6,0]  R1932     -2.0386894047260284e-01
    z[7,6,0]  R1933     -1.4164708554744720e-01
    z[7,6,0]  R1934     2.2895674407482147e-01
    z[7,6,0]  R1935     5.8498895168304443e-01
    z[7,6,0]  R1936     7.5233328342437744e-01
    z[7,6,0]  R1937     -2.8807312250137329e-01
    z[7,6,0]  R1938     -1.7447084188461304e-01
    z[7,6,0]  R1939     6.2511068582534790e-01
    z[7,6,0]  R1940     -3.0400281772017479e-02
    z[7,6,0]  R1941     -2.3215585947036743e-01
    z[7,6,0]  R1942     -2.9119861125946045e-01
    z[7,6,0]  R1943     1.1829664558172226e-01
    z[7,6,0]  R1944     -2.2391916811466217e-01
    z[7,6,0]  R1945     -1.9385483860969543e-01
    z[7,6,0]  R1946     1.2414071708917618e-01
    z[7,6,0]  R1947     -8.9991658926010132e-02
    z[7,6,0]  R1948     -1.2856583297252655e-01
    z[7,6,0]  R1949     1.6626198589801788e-01
    z[7,6,0]  R1950     3.9438480138778687e-01
    z[7,6,0]  R1951     2.3051121830940247e-01
    z[7,6,0]  R1952     4.7068125009536743e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R1853     -1
    z[7,6,1]  R1854     1
    z[7,6,1]  R1865     1.6140025854110718e-01
    z[7,6,1]  R1866     4.5965674519538879e-01
    z[7,6,1]  R1867     -7.6316393911838531e-02
    z[7,6,1]  R1868     -2.3349776864051819e-01
    z[7,6,1]  R1869     1.9021511077880859e-01
    z[7,6,1]  R1870     -2.9934826493263245e-01
    z[7,6,1]  R1871     -9.7319453954696655e-02
    z[7,6,1]  R1872     -7.7453780174255371e-01
    z[7,6,1]  R1873     -9.0730965137481689e-01
    z[7,6,1]  R1874     -6.3884317874908447e-01
    z[7,6,1]  R1875     4.2621025443077087e-01
    z[7,6,1]  R1876     3.0166879296302795e-01
    z[7,6,1]  R1877     0.0885414183139801
    z[7,6,1]  R1878     1.8170714378356934e-01
    z[7,6,1]  R1879     6.4333818852901459e-02
    z[7,6,1]  R1880     3.0959376692771912e-01
    z[7,6,1]  R1881     1.5628987550735474e-01
    z[7,6,1]  R1882     1.6214667260646820e-01
    z[7,6,1]  R1883     6.6457551717758179e-01
    z[7,6,1]  R1884     0.821221113204956
    z[7,6,1]  R1885     -4.9151638150215149e-01
    z[7,6,1]  R1886     -3.7890347838401794e-01
    z[7,6,1]  R1887     2.1322643756866455e-01
    z[7,6,1]  R1888     2.4058306217193604e-01
    z[7,6,1]  R1889     -2.1792949736118317e-01
    z[7,6,1]  R1890     -2.5230693817138672e-01
    z[7,6,1]  R1891     2.8330886363983154e-01
    z[7,6,1]  R1892     4.7625762224197388e-01
    z[7,6,1]  R1893     9.5401480793952942e-02
    z[7,6,1]  R1894     1.6792092472314835e-02
    z[7,6,1]  R1895     -3.6612647771835327e-01
    z[7,6,1]  R1896     -0.584315836429596
    z[7,6,1]  R1897     -3.1234717369079590e-01
    z[7,6,1]  R1898     -6.9596379995346069e-01
    z[7,6,1]  R1899     0.572786271572113
    z[7,6,1]  R1900     -6.2916569411754608e-02
    z[7,6,1]  R1901     -2.0866429805755615e-01
    z[7,6,1]  R1902     -5.1932379603385925e-02
    z[7,6,1]  R1903     6.7793554067611694e-01
    z[7,6,1]  R1904     8.4547185897827148e-01
    z[7,6,1]  R1905     -0.654776394367218
    z[7,6,1]  R1906     -5.0122487545013428e-01
    z[7,6,1]  R1907     -0.17464579641819
    z[7,6,1]  R1908     8.6933094263076782e-01
    z[7,6,1]  R1909     8.5908889770507812e-01
    z[7,6,1]  R1910     8.3578372001647949e-01
    z[7,6,1]  R1911     8.0418592691421509e-01
    z[7,6,1]  R1912     7.8154599666595459e-01
    z[7,6,1]  R1913     -1.3459932059049606e-02
    z[7,6,1]  R1914     5.1934242248535156e-01
    z[7,6,1]  R1915     -7.9995006322860718e-02
    z[7,6,1]  R1916     0.0594286248087883
    z[7,6,1]  R1917     -5.0231166183948517e-02
    z[7,6,1]  R1918     1.3360656797885895e-01
    z[7,6,1]  R1919     4.5835691690444946e-01
    z[7,6,1]  R1920     -4.5497417449951172e-02
    z[7,6,1]  R1921     -1.8592052161693573e-01
    z[7,6,1]  R1922     -5.0240028649568558e-03
    z[7,6,1]  R1923     -5.2224469184875488e-01
    z[7,6,1]  R1924     -6.3291859626770020e-01
    z[7,6,1]  R1925     -6.0845259577035904e-02
    z[7,6,1]  R1926     -5.1689177751541138e-01
    z[7,6,1]  R1927     -3.9240229129791260e-01
    z[7,6,1]  R1928     -7.2546893358230591e-01
    z[7,6,1]  R1929     -6.4258140325546265e-01
    z[7,6,1]  R1930     -5.2906662225723267e-01
    z[7,6,1]  R1931     6.9133386015892029e-02
    z[7,6,1]  R1932     -3.1099589541554451e-02
    z[7,6,1]  R1933     -2.2310295701026917e-01
    z[7,6,1]  R1934     -6.4148336648941040e-01
    z[7,6,1]  R1935     -2.5085499882698059e-01
    z[7,6,1]  R1936     -1.7219226062297821e-01
    z[7,6,1]  R1937     -7.9821836948394775e-01
    z[7,6,1]  R1938     -7.4681842327117920e-01
    z[7,6,1]  R1939     -2.1572041511535645e-01
    z[7,6,1]  R1940     -7.3871570825576782e-01
    z[7,6,1]  R1941     -7.3048555850982666e-01
    z[7,6,1]  R1942     -6.9063276052474976e-01
    z[7,6,1]  R1943     -4.0086838603019714e-01
    z[7,6,1]  R1944     -8.0846118927001953e-01
    z[7,6,1]  R1945     -0.766937255859375
    z[7,6,1]  R1946     3.8483718037605286e-01
    z[7,6,1]  R1947     3.0647650361061096e-01
    z[7,6,1]  R1948     4.7750377655029297e-01
    z[7,6,1]  R1949     7.7439749240875244e-01
    z[7,6,1]  R1950     7.8351211547851562e-01
    z[7,6,1]  R1951     7.4697548151016235e-01
    z[7,6,1]  R1952     0.796562671661377
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R1855     -1
    z[7,6,2]  R1856     1
    z[7,6,2]  R1865     -4.5959183573722839e-01
    z[7,6,2]  R1866     -5.5117529630661011e-01
    z[7,6,2]  R1867     -3.2845515012741089e-01
    z[7,6,2]  R1868     -3.6801773309707642e-01
    z[7,6,2]  R1869     -2.8529864549636841e-01
    z[7,6,2]  R1870     -6.0903424024581909e-01
    z[7,6,2]  R1871     -1.9481046497821808e-01
    z[7,6,2]  R1872     -4.1978725790977478e-01
    z[7,6,2]  R1873     1.0509595274925232e-01
    z[7,6,2]  R1874     -6.8624660372734070e-02
    z[7,6,2]  R1875     0.410971999168396
    z[7,6,2]  R1876     5.5042487382888794e-01
    z[7,6,2]  R1877     6.3688921928405762e-01
    z[7,6,2]  R1878     -2.5539478287100792e-02
    z[7,6,2]  R1879     4.0504077076911926e-01
    z[7,6,2]  R1880     5.6090480089187622e-01
    z[7,6,2]  R1881     -3.9990995079278946e-02
    z[7,6,2]  R1882     4.5544752478599548e-01
    z[7,6,2]  R1883     1.4628442004323006e-02
    z[7,6,2]  R1884     3.9811581373214722e-01
    z[7,6,2]  R1885     -3.3156388998031616e-01
    z[7,6,2]  R1886     2.9727813601493835e-01
    z[7,6,2]  R1887     1.2578035891056061e-01
    z[7,6,2]  R1888     3.0262774229049683e-01
    z[7,6,2]  R1889     0.33199542760849
    z[7,6,2]  R1890     5.3181892633438110e-01
    z[7,6,2]  R1891     -3.3132388489320874e-04
    z[7,6,2]  R1892     -6.4216554164886475e-01
    z[7,6,2]  R1893     5.5402827262878418e-01
    z[7,6,2]  R1894     2.6416417956352234e-01
    z[7,6,2]  R1895     1.7065095901489258e-01
    z[7,6,2]  R1896     3.1260296702384949e-01
    z[7,6,2]  R1897     1.3980729877948761e-01
    z[7,6,2]  R1898     3.1571972370147705e-01
    z[7,6,2]  R1899     0.355589896440506
    z[7,6,2]  R1900     -2.6504507660865784e-01
    z[7,6,2]  R1901     -2.8752166777849197e-02
    z[7,6,2]  R1902     6.4543402194976807e-01
    z[7,6,2]  R1903     -3.2898673415184021e-01
    z[7,6,2]  R1904     1.8935500085353851e-01
    z[7,6,2]  R1905     2.4685647338628769e-02
    z[7,6,2]  R1906     -2.0121857523918152e-01
    z[7,6,2]  R1907     -2.0923744142055511e-01
    z[7,6,2]  R1908     2.1507760882377625e-01
    z[7,6,2]  R1909     3.6545589566230774e-01
    z[7,6,2]  R1910     4.1203314065933228e-01
    z[7,6,2]  R1911     3.1193997710943222e-02
    z[7,6,2]  R1912     1.7944779992103577e-01
    z[7,6,2]  R1913     -0.560208797454834
    z[7,6,2]  R1914     -4.3954044580459595e-01
    z[7,6,2]  R1915     -3.0679419636726379e-01
    z[7,6,2]  R1916     -4.7865721583366394e-01
    z[7,6,2]  R1917     -3.0638018250465393e-01
    z[7,6,2]  R1918     -1.2894614040851593e-01
    z[7,6,2]  R1919     -2.9435306787490845e-01
    z[7,6,2]  R1920     -6.0012418776750565e-02
    z[7,6,2]  R1921     -1.3119670748710632e-01
    z[7,6,2]  R1922     2.3547196388244629e-01
    z[7,6,2]  R1923     -5.2362614870071411e-01
    z[7,6,2]  R1924     -0.438385546207428
    z[7,6,2]  R1925     -5.9539139270782471e-01
    z[7,6,2]  R1926     3.5121065378189087e-01
    z[7,6,2]  R1927     5.2069473266601562e-01
    z[7,6,2]  R1928     2.0645692944526672e-02
    z[7,6,2]  R1929     6.0132515430450439e-01
    z[7,6,2]  R1930     5.5767655372619629e-01
    z[7,6,2]  R1931     4.3703210353851318e-01
    z[7,6,2]  R1932     4.5359331369400024e-01
    z[7,6,2]  R1933     -4.8705145716667175e-01
    z[7,6,2]  R1934     4.6946480870246887e-01
    z[7,6,2]  R1935     2.7474248409271240e-01
    z[7,6,2]  R1936     5.8647930622100830e-01
    z[7,6,2]  R1937     3.6668869853019714e-01
    z[7,6,2]  R1938     3.1894814968109131e-01
    z[7,6,2]  R1939     2.6994487643241882e-01
    z[7,6,2]  R1940     4.6839416027069092e-01
    z[7,6,2]  R1941     0.56394362449646
    z[7,6,2]  R1942     4.9780625104904175e-01
    z[7,6,2]  R1943     -1.2506563961505890e-01
    z[7,6,2]  R1944     4.0509355068206787e-01
    z[7,6,2]  R1945     4.4223695993423462e-01
    z[7,6,2]  R1946     2.4276073276996613e-01
    z[7,6,2]  R1947     2.3418653011322021e-01
    z[7,6,2]  R1948     1.7361932992935181e-01
    z[7,6,2]  R1949     3.7193521857261658e-01
    z[7,6,2]  R1950     2.2485843300819397e-01
    z[7,6,2]  R1951     5.1996129751205444e-01
    z[7,6,2]  R1952     -3.6978565156459808e-02
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R1857     -1
    z[7,6,3]  R1858     1
    z[7,6,3]  R1865     5.3412193059921265e-01
    z[7,6,3]  R1866     3.5509994626045227e-01
    z[7,6,3]  R1867     5.6234270334243774e-01
    z[7,6,3]  R1868     1.8797422945499420e-01
    z[7,6,3]  R1869     4.3108406662940979e-01
    z[7,6,3]  R1870     2.6964026689529419e-01
    z[7,6,3]  R1871     5.5359804630279541e-01
    z[7,6,3]  R1872     -2.1320657432079315e-01
    z[7,6,3]  R1873     -0.266482949256897
    z[7,6,3]  R1874     -2.5109395384788513e-02
    z[7,6,3]  R1875     6.1683785170316696e-02
    z[7,6,3]  R1876     5.4878854751586914e-01
    z[7,6,3]  R1877     5.7285404205322266e-01
    z[7,6,3]  R1878     -6.4620566368103027e-01
    z[7,6,3]  R1879     2.9126688838005066e-01
    z[7,6,3]  R1880     5.6145054101943970e-01
    z[7,6,3]  R1881     -5.1702308654785156e-01
    z[7,6,3]  R1882     -2.6268932223320007e-01
    z[7,6,3]  R1883     7.1090564131736755e-02
    z[7,6,3]  R1884     -1.5342529118061066e-01
    z[7,6,3]  R1885     -5.6785982847213745e-01
    z[7,6,3]  R1886     -2.7150332927703857e-01
    z[7,6,3]  R1887     5.8796745538711548e-01
    z[7,6,3]  R1888     3.0893996357917786e-01
    z[7,6,3]  R1889     -4.6980452537536621e-01
    z[7,6,3]  R1890     -0.427613228559494
    z[7,6,3]  R1891     -1.9598762691020966e-01
    z[7,6,3]  R1892     -1.6931539773941040e-01
    z[7,6,3]  R1893     3.8242614269256592e-01
    z[7,6,3]  R1894     -8.3257377147674561e-01
    z[7,6,3]  R1895     -0.640066921710968
    z[7,6,3]  R1896     -4.0373942255973816e-01
    z[7,6,3]  R1897     -5.1015150547027588e-01
    z[7,6,3]  R1898     4.0715858340263367e-01
    z[7,6,3]  R1899     0.630540668964386
    z[7,6,3]  R1900     -8.7552732229232788e-01
    z[7,6,3]  R1901     -5.7726246118545532e-01
    z[7,6,3]  R1902     5.5400753021240234e-01
    z[7,6,3]  R1903     -1.1411420255899429e-01
    z[7,6,3]  R1904     -3.7139368057250977e-01
    z[7,6,3]  R1905     -4.6015629172325134e-01
    z[7,6,3]  R1906     -5.1192593574523926e-01
    z[7,6,3]  R1907     -7.3500746488571167e-01
    z[7,6,3]  R1908     -3.4131145477294922e-01
    z[7,6,3]  R1909     -2.5124719738960266e-01
    z[7,6,3]  R1910     -3.1104597449302673e-01
    z[7,6,3]  R1911     -4.5039784908294678e-01
    z[7,6,3]  R1912     -2.8034844994544983e-01
    z[7,6,3]  R1913     7.3736059665679932e-01
    z[7,6,3]  R1914     2.4496375024318695e-01
    z[7,6,3]  R1915     2.7197441458702087e-01
    z[7,6,3]  R1916     5.6444466114044189e-01
    z[7,6,3]  R1917     2.1162256598472595e-01
    z[7,6,3]  R1918     7.8199088573455811e-01
    z[7,6,3]  R1919     8.8519737124443054e-02
    z[7,6,3]  R1920     3.7660104036331177e-01
    z[7,6,3]  R1921     5.6421411037445068e-01
    z[7,6,3]  R1922     5.9436100721359253e-01
    z[7,6,3]  R1923     -2.2799010574817657e-01
    z[7,6,3]  R1924     -2.5736156105995178e-01
    z[7,6,3]  R1925     -5.4242026805877686e-01
    z[7,6,3]  R1926     -2.6262211799621582e-01
    z[7,6,3]  R1927     -3.8348857313394547e-02
    z[7,6,3]  R1928     -2.9589679837226868e-01
    z[7,6,3]  R1929     -3.0975860357284546e-01
    z[7,6,3]  R1930     -2.8315034508705139e-01
    z[7,6,3]  R1931     -3.3291906118392944e-01
    z[7,6,3]  R1932     -3.2870528101921082e-01
    z[7,6,3]  R1933     -6.7682260274887085e-01
    z[7,6,3]  R1934     4.9128532409667969e-01
    z[7,6,3]  R1935     6.4742344617843628e-01
    z[7,6,3]  R1936     -2.0186990499496460e-01
    z[7,6,3]  R1937     3.9293374866247177e-02
    z[7,6,3]  R1938     2.5785389542579651e-01
    z[7,6,3]  R1939     -2.4777875840663910e-01
    z[7,6,3]  R1940     -1.5962266921997070e-01
    z[7,6,3]  R1941     -2.1654102206230164e-01
    z[7,6,3]  R1942     -2.8818780183792114e-01
    z[7,6,3]  R1943     -3.1955018639564514e-01
    z[7,6,3]  R1944     -0.0674697533249855
    z[7,6,3]  R1945     -3.9962741732597351e-01
    z[7,6,3]  R1946     -3.4626686573028564e-01
    z[7,6,3]  R1947     -3.3625563979148865e-01
    z[7,6,3]  R1948     -3.5481536388397217e-01
    z[7,6,3]  R1949     -2.6597523689270020e-01
    z[7,6,3]  R1950     -1.3726912438869476e-01
    z[7,6,3]  R1951     -4.0699992328882217e-02
    z[7,6,3]  R1952     -2.2174143791198730e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R1859     -1
    z[7,6,4]  R1860     1
    z[7,6,4]  R1865     2.2251971065998077e-02
    z[7,6,4]  R1866     -2.3627656698226929e-01
    z[7,6,4]  R1867     -4.4636905193328857e-01
    z[7,6,4]  R1868     8.7686873972415924e-02
    z[7,6,4]  R1869     -7.2892510890960693e-01
    z[7,6,4]  R1870     -2.8721296787261963e-01
    z[7,6,4]  R1871     -3.9025208353996277e-01
    z[7,6,4]  R1872     1.4211065135896206e-02
    z[7,6,4]  R1873     -1.4557726681232452e-01
    z[7,6,4]  R1874     5.5874037742614746e-01
    z[7,6,4]  R1875     1.8388934433460236e-01
    z[7,6,4]  R1876     1.5091983973979950e-01
    z[7,6,4]  R1877     -3.9319179952144623e-02
    z[7,6,4]  R1878     -4.6640940010547638e-02
    z[7,6,4]  R1879     -3.1542456150054932e-01
    z[7,6,4]  R1880     3.7751308083534241e-01
    z[7,6,4]  R1881     6.8618780374526978e-01
    z[7,6,4]  R1882     -4.1213774681091309e-01
    z[7,6,4]  R1883     3.3205825090408325e-01
    z[7,6,4]  R1884     2.5704520940780640e-01
    z[7,6,4]  R1885     0.366986483335495
    z[7,6,4]  R1886     4.7017842531204224e-02
    z[7,6,4]  R1887     -2.4060022085905075e-02
    z[7,6,4]  R1888     -3.1388887763023376e-01
    z[7,6,4]  R1889     4.5337316393852234e-01
    z[7,6,4]  R1890     3.8295388221740723e-01
    z[7,6,4]  R1891     -5.7923948764801025e-01
    z[7,6,4]  R1892     -2.0442249253392220e-02
    z[7,6,4]  R1893     4.6696513891220093e-01
    z[7,6,4]  R1894     4.5723305083811283e-03
    z[7,6,4]  R1895     5.8073186874389648e-01
    z[7,6,4]  R1896     -2.2077956795692444e-01
    z[7,6,4]  R1897     5.2164965867996216e-01
    z[7,6,4]  R1898     3.5395428538322449e-01
    z[7,6,4]  R1899     2.5436949729919434e-01
    z[7,6,4]  R1900     -3.7642422318458557e-01
    z[7,6,4]  R1901     -3.0911937355995178e-01
    z[7,6,4]  R1902     -1.6816121339797974e-01
    z[7,6,4]  R1903     5.3540492057800293e-01
    z[7,6,4]  R1904     1.9686232507228851e-01
    z[7,6,4]  R1905     3.8858780264854431e-01
    z[7,6,4]  R1906     7.1289457380771637e-02
    z[7,6,4]  R1907     -4.0224009752273560e-01
    z[7,6,4]  R1908     1.4052438735961914e-01
    z[7,6,4]  R1909     -1.4828655123710632e-01
    z[7,6,4]  R1910     3.1841620802879333e-02
    z[7,6,4]  R1911     1.7281240224838257e-01
    z[7,6,4]  R1912     2.6056563854217529e-01
    z[7,6,4]  R1913     -1.4335820078849792e-01
    z[7,6,4]  R1914     -1.8840160965919495e-01
    z[7,6,4]  R1915     -6.8485051393508911e-01
    z[7,6,4]  R1916     -2.5238949060440063e-01
    z[7,6,4]  R1917     -6.9705463945865631e-02
    z[7,6,4]  R1918     -2.0170746371150017e-02
    z[7,6,4]  R1919     -1.4854730665683746e-01
    z[7,6,4]  R1920     -7.6145190000534058e-01
    z[7,6,4]  R1921     1.9435827434062958e-01
    z[7,6,4]  R1922     8.6991004645824432e-02
    z[7,6,4]  R1923     2.6194646954536438e-01
    z[7,6,4]  R1924     -0.0992252379655838
    z[7,6,4]  R1925     2.4288235604763031e-01
    z[7,6,4]  R1926     -1.8302644789218903e-01
    z[7,6,4]  R1927     -6.6127941012382507e-02
    z[7,6,4]  R1928     2.5026535987854004e-01
    z[7,6,4]  R1929     -1.9430282711982727e-01
    z[7,6,4]  R1930     5.0300270318984985e-01
    z[7,6,4]  R1931     6.9137299060821533e-01
    z[7,6,4]  R1932     5.7457500696182251e-01
    z[7,6,4]  R1933     -4.6021699905395508e-01
    z[7,6,4]  R1934     1.0321640968322754e-01
    z[7,6,4]  R1935     1.9517336785793304e-01
    z[7,6,4]  R1936     2.2953076288104057e-02
    z[7,6,4]  R1937     3.7811064720153809e-01
    z[7,6,4]  R1938     3.3351635932922363e-01
    z[7,6,4]  R1939     0.510429859161377
    z[7,6,4]  R1940     -2.8141397982835770e-02
    z[7,6,4]  R1941     1.0243520140647888e-01
    z[7,6,4]  R1942     -6.0386221855878830e-02
    z[7,6,4]  R1943     -0.518736720085144
    z[7,6,4]  R1944     2.2828787565231323e-02
    z[7,6,4]  R1945     8.2920975983142853e-03
    z[7,6,4]  R1946     4.2705839872360229e-01
    z[7,6,4]  R1947     2.9318472743034363e-01
    z[7,6,4]  R1948     7.0638722181320190e-01
    z[7,6,4]  R1949     3.9679402112960815e-01
    z[7,6,4]  R1950     3.3010202646255493e-01
    z[7,6,4]  R1951     1.8786674365401268e-02
    z[7,6,4]  R1952     1.2044016271829605e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R1861     -1
    z[7,6,5]  R1862     1
    z[7,6,5]  R1865     1.4725837111473083e-01
    z[7,6,5]  R1866     1.5593683719635010e-01
    z[7,6,5]  R1867     4.4074773788452148e-01
    z[7,6,5]  R1868     3.3375957608222961e-01
    z[7,6,5]  R1869     1.0006825625896454e-01
    z[7,6,5]  R1870     -3.3978302963078022e-03
    z[7,6,5]  R1871     -2.8802141547203064e-01
    z[7,6,5]  R1872     -2.9621142148971558e-01
    z[7,6,5]  R1873     1.9540265202522278e-01
    z[7,6,5]  R1874     -4.0066826343536377e-01
    z[7,6,5]  R1875     3.0967578291893005e-01
    z[7,6,5]  R1876     -4.0537956357002258e-01
    z[7,6,5]  R1877     -2.8869214653968811e-01
    z[7,6,5]  R1878     -4.5290020108222961e-01
    z[7,6,5]  R1879     -4.5167851448059082e-01
    z[7,6,5]  R1880     0.0571405366063118
    z[7,6,5]  R1881     3.5836282372474670e-01
    z[7,6,5]  R1882     -9.0226821601390839e-02
    z[7,6,5]  R1883     -6.4252573251724243e-01
    z[7,6,5]  R1884     -2.7371481060981750e-01
    z[7,6,5]  R1885     3.3961218595504761e-01
    z[7,6,5]  R1886     -4.0715846419334412e-01
    z[7,6,5]  R1887     -1.2031991779804230e-01
    z[7,6,5]  R1888     -1.8161757290363312e-01
    z[7,6,5]  R1889     3.1795452814549208e-03
    z[7,6,5]  R1890     5.5409610271453857e-02
    z[7,6,5]  R1891     -2.9763779044151306e-01
    z[7,6,5]  R1892     1.8753847479820251e-01
    z[7,6,5]  R1893     -4.5380941033363342e-01
    z[7,6,5]  R1894     -2.9769745469093323e-01
    z[7,6,5]  R1895     -1.7324566841125488e-01
    z[7,6,5]  R1896     -5.0331324338912964e-01
    z[7,6,5]  R1897     -1.7354843020439148e-01
    z[7,6,5]  R1898     -1.4737382531166077e-02
    z[7,6,5]  R1899     -2.2738638520240784e-01
    z[7,6,5]  R1900     7.1067869663238525e-02
    z[7,6,5]  R1901     2.7304738759994507e-01
    z[7,6,5]  R1902     -0.157281756401062
    z[7,6,5]  R1903     -3.2786116003990173e-01
    z[7,6,5]  R1904     -1.9458128511905670e-01
    z[7,6,5]  R1905     -1.7302711308002472e-01
    z[7,6,5]  R1906     5.1286923885345459e-01
    z[7,6,5]  R1907     -2.5918769836425781e-01
    z[7,6,5]  R1908     -0.0354522168636322
    z[7,6,5]  R1909     2.3612717166543007e-02
    z[7,6,5]  R1910     -3.3197902143001556e-02
    z[7,6,5]  R1911     1.9197198748588562e-01
    z[7,6,5]  R1912     4.0260636806488037e-01
    z[7,6,5]  R1913     6.9417193531990051e-02
    z[7,6,5]  R1914     1.5506243705749512e-01
    z[7,6,5]  R1915     3.7132057547569275e-01
    z[7,6,5]  R1916     2.1465530991554260e-01
    z[7,6,5]  R1917     1.0117302089929581e-01
    z[7,6,5]  R1918     2.5743028521537781e-01
    z[7,6,5]  R1919     -0.305356502532959
    z[7,6,5]  R1920     -1.4670735597610474e-01
    z[7,6,5]  R1921     -7.6789689064025879e-01
    z[7,6,5]  R1922     -6.5999329090118408e-01
    z[7,6,5]  R1923     4.4676882028579712e-01
    z[7,6,5]  R1924     2.8443023562431335e-01
    z[7,6,5]  R1925     3.3078234642744064e-02
    z[7,6,5]  R1926     -3.0063995718955994e-01
    z[7,6,5]  R1927     2.8809410333633423e-01
    z[7,6,5]  R1928     -0.0702296569943428
    z[7,6,5]  R1929     2.3496554791927338e-01
    z[7,6,5]  R1930     -4.1340142488479614e-02
    z[7,6,5]  R1931     4.4156956672668457e-01
    z[7,6,5]  R1932     4.3883880972862244e-01
    z[7,6,5]  R1933     -4.7935396432876587e-02
    z[7,6,5]  R1934     -5.1559843122959137e-02
    z[7,6,5]  R1935     1.7003294825553894e-01
    z[7,6,5]  R1936     -9.0687476098537445e-02
    z[7,6,5]  R1937     -2.9200930148363113e-02
    z[7,6,5]  R1938     2.5748556945472956e-03
    z[7,6,5]  R1939     -3.8776826858520508e-01
    z[7,6,5]  R1940     -3.2422986626625061e-01
    z[7,6,5]  R1941     1.9909940659999847e-02
    z[7,6,5]  R1942     -3.2066482305526733e-01
    z[7,6,5]  R1943     6.5030759572982788e-01
    z[7,6,5]  R1944     0.18819560110569
    z[7,6,5]  R1945     1.9532483071088791e-02
    z[7,6,5]  R1946     6.8907028436660767e-01
    z[7,6,5]  R1947     7.6346707344055176e-01
    z[7,6,5]  R1948     3.1301450729370117e-01
    z[7,6,5]  R1949     7.1340814232826233e-02
    z[7,6,5]  R1950     1.0498243570327759e-01
    z[7,6,5]  R1951     1.6161866486072540e-01
    z[7,6,5]  R1952     -2.5649511814117432e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R1863     -1
    z[7,6,6]  R1864     1
    z[7,6,6]  R1865     -0.302512526512146
    z[7,6,6]  R1866     3.2013422250747681e-01
    z[7,6,6]  R1867     2.7645963430404663e-01
    z[7,6,6]  R1868     3.4591197967529297e-01
    z[7,6,6]  R1869     -1.0379598289728165e-01
    z[7,6,6]  R1870     2.3165971040725708e-01
    z[7,6,6]  R1871     2.5857791304588318e-01
    z[7,6,6]  R1872     -7.2749868035316467e-02
    z[7,6,6]  R1873     1.6995021700859070e-01
    z[7,6,6]  R1874     3.2450035214424133e-01
    z[7,6,6]  R1875     4.4050562381744385e-01
    z[7,6,6]  R1876     -2.5648474693298340e-01
    z[7,6,6]  R1877     -3.6785000562667847e-01
    z[7,6,6]  R1878     -4.5664796233177185e-01
    z[7,6,6]  R1879     4.7958934307098389e-01
    z[7,6,6]  R1880     3.2247710227966309e-01
    z[7,6,6]  R1881     -1.4056035876274109e-01
    z[7,6,6]  R1882     -6.4469277858734131e-01
    z[7,6,6]  R1883     -1.1656996607780457e-01
    z[7,6,6]  R1884     -2.6940440759062767e-02
    z[7,6,6]  R1885     2.6471406221389771e-01
    z[7,6,6]  R1886     -7.2548437118530273e-01
    z[7,6,6]  R1887     8.7576441466808319e-02
    z[7,6,6]  R1888     -3.4995871782302856e-01
    z[7,6,6]  R1889     -6.4238435029983521e-01
    z[7,6,6]  R1890     -5.2331924438476562e-01
    z[7,6,6]  R1891     3.4439265727996826e-01
    z[7,6,6]  R1892     -1.1146487295627594e-01
    z[7,6,6]  R1893     -1.4820632338523865e-01
    z[7,6,6]  R1894     -1.4348258078098297e-01
    z[7,6,6]  R1895     -1.3156990706920624e-01
    z[7,6,6]  R1896     -2.0089823007583618e-01
    z[7,6,6]  R1897     -5.6589150428771973e-01
    z[7,6,6]  R1898     -3.4332635998725891e-01
    z[7,6,6]  R1899     -1.6490109264850616e-02
    z[7,6,6]  R1900     1.0197193175554276e-01
    z[7,6,6]  R1901     -6.4058023691177368e-01
    z[7,6,6]  R1902     2.3046158254146576e-01
    z[7,6,6]  R1903     1.5784651041030884e-01
    z[7,6,6]  R1904     -1.8610309064388275e-01
    z[7,6,6]  R1905     -4.1490641236305237e-01
    z[7,6,6]  R1906     -3.2571631669998169e-01
    z[7,6,6]  R1907     3.4918409585952759e-01
    z[7,6,6]  R1908     6.2470335513353348e-02
    z[7,6,6]  R1909     -1.7074249684810638e-01
    z[7,6,6]  R1910     -1.4392884075641632e-01
    z[7,6,6]  R1911     -2.7983868122100830e-01
    z[7,6,6]  R1912     -1.7215034365653992e-01
    z[7,6,6]  R1913     3.1279347836971283e-02
    z[7,6,6]  R1914     -1.2333748489618301e-01
    z[7,6,6]  R1915     -2.9531520605087280e-01
    z[7,6,6]  R1916     4.5990908145904541e-01
    z[7,6,6]  R1917     -6.3684183359146118e-01
    z[7,6,6]  R1918     -1.8181812763214111e-01
    z[7,6,6]  R1919     1.4404557645320892e-01
    z[7,6,6]  R1920     -5.8593165129423141e-02
    z[7,6,6]  R1921     3.1259968876838684e-02
    z[7,6,6]  R1922     2.9459765553474426e-01
    z[7,6,6]  R1923     -8.9009217917919159e-03
    z[7,6,6]  R1924     1.6101954877376556e-01
    z[7,6,6]  R1925     5.1092332601547241e-01
    z[7,6,6]  R1926     -3.2722827792167664e-01
    z[7,6,6]  R1927     -0.340950071811676
    z[7,6,6]  R1928     3.6238130927085876e-01
    z[7,6,6]  R1929     -1.6881616413593292e-01
    z[7,6,6]  R1930     2.3747469484806061e-01
    z[7,6,6]  R1931     -1.9602755084633827e-02
    z[7,6,6]  R1932     3.4779345989227295e-01
    z[7,6,6]  R1933     1.4406830072402954e-01
    z[7,6,6]  R1934     -2.4699696898460388e-01
    z[7,6,6]  R1935     1.8225048482418060e-01
    z[7,6,6]  R1936     0.104326531291008
    z[7,6,6]  R1937     -6.0234349220991135e-03
    z[7,6,6]  R1938     3.6382114887237549e-01
    z[7,6,6]  R1939     -1.3241605460643768e-01
    z[7,6,6]  R1940     3.2028988003730774e-01
    z[7,6,6]  R1941     -1.9152744114398956e-01
    z[7,6,6]  R1942     -2.9902998358011246e-02
    z[7,6,6]  R1943     -1.2477464973926544e-01
    z[7,6,6]  R1944     3.0275234580039978e-01
    z[7,6,6]  R1945     -1.3602021336555481e-01
    z[7,6,6]  R1946     2.1427385509014130e-02
    z[7,6,6]  R1947     2.4743328988552094e-01
    z[7,6,6]  R1948     -0.0496220663189888
    z[7,6,6]  R1949     3.2432243227958679e-02
    z[7,6,6]  R1950     2.0292037725448608e-01
    z[7,6,6]  R1951     3.0066993832588196e-01
    z[7,6,6]  R1952     -1.1451942473649979e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R1953     -1
    z[7,8,0]  R1954     1
    z[7,8,0]  R1967     -6.0311275720596313e-01
    z[7,8,0]  R1968     -4.1975772380828857e-01
    z[7,8,0]  R1969     -3.1643310189247131e-01
    z[7,8,0]  R1970     -7.3209822177886963e-01
    z[7,8,0]  R1971     -3.8009262084960938e-01
    z[7,8,0]  R1972     -5.7497209310531616e-01
    z[7,8,0]  R1973     -5.8650773763656616e-01
    z[7,8,0]  R1974     -2.9185107350349426e-01
    z[7,8,0]  R1975     8.0453574657440186e-02
    z[7,8,0]  R1976     9.2267148196697235e-02
    z[7,8,0]  R1977     5.6734681129455566e-01
    z[7,8,0]  R1978     2.2795991599559784e-01
    z[7,8,0]  R1979     1.9536599516868591e-01
    z[7,8,0]  R1980     3.6459165811538696e-01
    z[7,8,0]  R1981     4.6201157569885254e-01
    z[7,8,0]  R1982     1.5664654970169067e-01
    z[7,8,0]  R1983     2.9601752758026123e-01
    z[7,8,0]  R1984     3.2193651795387268e-01
    z[7,8,0]  R1985     1.2798857688903809e-01
    z[7,8,0]  R1986     -4.2925652116537094e-02
    z[7,8,0]  R1987     -7.6961651444435120e-02
    z[7,8,0]  R1988     -5.2419453859329224e-03
    z[7,8,0]  R1989     7.5517058372497559e-01
    z[7,8,0]  R1990     7.0789128541946411e-01
    z[7,8,0]  R1991     5.7917181402444839e-02
    z[7,8,0]  R1992     2.1695601940155029e-01
    z[7,8,0]  R1993     5.8190357685089111e-01
    z[7,8,0]  R1994     5.3303050994873047e-01
    z[7,8,0]  R1995     3.0288097262382507e-01
    z[7,8,0]  R1996     3.5710540413856506e-01
    z[7,8,0]  R1997     2.0632442831993103e-01
    z[7,8,0]  R1998     2.3541665077209473e-01
    z[7,8,0]  R1999     -1.2956586666405201e-02
    z[7,8,0]  R2000     -8.2483284175395966e-02
    z[7,8,0]  R2001     1.7666345834732056e-01
    z[7,8,0]  R2002     4.5829281210899353e-02
    z[7,8,0]  R2003     -2.0481142401695251e-01
    z[7,8,0]  R2004     4.0946954488754272e-01
    z[7,8,0]  R2005     -9.0658646076917648e-03
    z[7,8,0]  R2006     1.1737505905330181e-02
    z[7,8,0]  R2007     -7.6344244182109833e-02
    z[7,8,0]  R2008     -2.6834377646446228e-01
    z[7,8,0]  R2009     1.8595089018344879e-01
    z[7,8,0]  R2010     2.3791874945163727e-01
    z[7,8,0]  R2011     1.1654905974864960e-01
    z[7,8,0]  R2012     -1.1005988717079163e-01
    z[7,8,0]  R2013     6.6533386707305908e-02
    z[7,8,0]  R2014     1.3699270784854889e-01
    z[7,8,0]  R2015     -2.8226274251937866e-01
    z[7,8,0]  R2016     -7.7986550331115723e-01
    z[7,8,0]  R2017     -5.6133443117141724e-01
    z[7,8,0]  R2018     -1.8987755477428436e-01
    z[7,8,0]  R2019     -2.2425100207328796e-01
    z[7,8,0]  R2020     -3.7275391817092896e-01
    z[7,8,0]  R2021     -1.4958010986447334e-02
    z[7,8,0]  R2022     -1.2382146716117859e-01
    z[7,8,0]  R2023     8.7856575846672058e-02
    z[7,8,0]  R2024     1.6627542674541473e-01
    z[7,8,0]  R2025     0.0994608923792839
    z[7,8,0]  R2026     5.5766079574823380e-02
    z[7,8,0]  R2027     -7.3843546211719513e-02
    z[7,8,0]  R2028     0.276685506105423
    z[7,8,0]  R2029     -1.0525304824113846e-02
    z[7,8,0]  R2030     1.7087580263614655e-01
    z[7,8,0]  R2031     -1.3269034028053284e-01
    z[7,8,0]  R2032     -6.3597828149795532e-02
    z[7,8,0]  R2033     1.3340190052986145e-01
    z[7,8,0]  R2034     1.7978912591934204e-01
    z[7,8,0]  R2035     7.2384142875671387e-01
    z[7,8,0]  R2036     6.6835331916809082e-01
    z[7,8,0]  R2037     7.7100640535354614e-01
    z[7,8,0]  R2038     7.0901614427566528e-01
    z[7,8,0]  R2039     2.1059218049049377e-01
    z[7,8,0]  R2040     -2.6733953505754471e-02
    z[7,8,0]  R2041     5.6849938631057739e-01
    z[7,8,0]  R2042     0.751060426235199
    z[7,8,0]  R2043     5.5167865753173828e-01
    z[7,8,0]  R2044     6.1072719097137451e-01
    z[7,8,0]  R2045     1.4569234848022461e-01
    z[7,8,0]  R2046     -0.189011350274086
    z[7,8,0]  R2047     1.0889729112386703e-01
    z[7,8,0]  R2048     -1.1854165792465210e-01
    z[7,8,0]  R2049     1.2387714534997940e-01
    z[7,8,0]  R2050     -9.2916369438171387e-02
    z[7,8,0]  R2051     -4.9124038219451904e-01
    z[7,8,0]  R2052     -5.3309446573257446e-01
    z[7,8,0]  R2053     -3.5195019841194153e-01
    z[7,8,0]  R2054     3.8438871502876282e-01
    z[7,8,0]  R2055     1.7925992608070374e-01
    z[7,8,0]  R2056     7.7746921777725220e-01
    z[7,8,0]  R2057     7.6034718751907349e-01
    z[7,8,0]  R2058     0.081568144261837
    z[7,8,0]  R2059     -2.9130074381828308e-01
    z[7,8,0]  R2060     7.2642546892166138e-01
    z[7,8,0]  R2061     7.1067118644714355e-01
    z[7,8,0]  R2062     -1.2803460471332073e-02
    z[7,8,0]  R2063     7.5687915086746216e-01
    z[7,8,0]  R2064     3.9250746369361877e-01
    z[7,8,0]  R2065     2.2239652276039124e-01
    z[7,8,0]  R2066     9.9800862371921539e-02
    z[7,8,0]  R2067     3.7790974974632263e-01
    z[7,8,0]  R2068     0.721330463886261
    z[7,8,0]  R2069     8.7671202421188354e-01
    z[7,8,0]  R2070     6.8902516365051270e-01
    z[7,8,0]  R2071     7.7704823017120361e-01
    z[7,8,0]  R2072     -1.8984349071979523e-01
    z[7,8,0]  R2073     0.637488603591919
    z[7,8,0]  R2074     5.9059524536132812e-01
    z[7,8,0]  R2075     5.8321809768676758e-01
    z[7,8,0]  R2076     6.9958710670471191e-01
    z[7,8,0]  R2077     1.7745713889598846e-01
    z[7,8,0]  R2078     -2.7724722027778625e-01
    z[7,8,0]  R2079     -5.8270114660263062e-01
    z[7,8,0]  R2080     -3.3282798528671265e-01
    z[7,8,0]  R2081     -1.6312380135059357e-01
    z[7,8,0]  R2082     -2.3580288887023926e-01
    z[7,8,0]  R2083     7.6551836729049683e-01
    z[7,8,0]  R2084     -4.8537963628768921e-01
    z[7,8,0]  R2085     2.0472145080566406e-01
    z[7,8,0]  R2086     6.8301928043365479e-01
    z[7,8,0]  R2087     8.0555105209350586e-01
    z[7,8,0]  R2088     -0.315387487411499
    z[7,8,0]  R2089     -3.9320096373558044e-01
    z[7,8,0]  R2090     -3.5275191068649292e-01
    z[7,8,0]  R2091     6.3006573915481567e-01
    z[7,8,0]  R2092     -2.8680721297860146e-02
    z[7,8,0]  R2093     3.0212867259979248e-01
    z[7,8,0]  R2094     -4.5551683753728867e-02
    z[7,8,0]  R2095     9.1342061758041382e-01
    z[7,8,0]  R2096     -4.6857488155364990e-01
    z[7,8,0]  R2097     -3.4039369225502014e-01
    z[7,8,0]  R2098     6.9425010681152344e-01
    z[7,8,0]  R2099     0.0693756490945816
    z[7,8,0]  R2100     -5.3943157196044922e-01
    z[7,8,0]  R2101     -6.2931698560714722e-01
    z[7,8,0]  R2102     -5.9819233417510986e-01
    z[7,8,0]  R2103     2.9400706291198730e-01
    z[7,8,0]  R2104     2.5269946455955505e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R1955     -1
    z[7,8,1]  R1956     1
    z[7,8,1]  R1967     1.6140025854110718e-01
    z[7,8,1]  R1968     4.5965674519538879e-01
    z[7,8,1]  R1969     -7.6316393911838531e-02
    z[7,8,1]  R1970     -2.3349776864051819e-01
    z[7,8,1]  R1971     1.9021511077880859e-01
    z[7,8,1]  R1972     -2.9934826493263245e-01
    z[7,8,1]  R1973     -9.7319453954696655e-02
    z[7,8,1]  R1974     -7.7453780174255371e-01
    z[7,8,1]  R1975     -9.0730965137481689e-01
    z[7,8,1]  R1976     -6.3884317874908447e-01
    z[7,8,1]  R1977     4.2621025443077087e-01
    z[7,8,1]  R1978     3.0166879296302795e-01
    z[7,8,1]  R1979     0.0885414183139801
    z[7,8,1]  R1980     1.8170714378356934e-01
    z[7,8,1]  R1981     6.4333818852901459e-02
    z[7,8,1]  R1982     3.0959376692771912e-01
    z[7,8,1]  R1983     1.5628987550735474e-01
    z[7,8,1]  R1984     1.6214667260646820e-01
    z[7,8,1]  R1985     6.6457551717758179e-01
    z[7,8,1]  R1986     0.821221113204956
    z[7,8,1]  R1987     -4.9151638150215149e-01
    z[7,8,1]  R1988     -3.7890347838401794e-01
    z[7,8,1]  R1989     2.1322643756866455e-01
    z[7,8,1]  R1990     2.4058306217193604e-01
    z[7,8,1]  R1991     -2.1792949736118317e-01
    z[7,8,1]  R1992     -2.5230693817138672e-01
    z[7,8,1]  R1993     2.8330886363983154e-01
    z[7,8,1]  R1994     4.7625762224197388e-01
    z[7,8,1]  R1995     9.5401480793952942e-02
    z[7,8,1]  R1996     1.6792092472314835e-02
    z[7,8,1]  R1997     -3.6612647771835327e-01
    z[7,8,1]  R1998     -0.584315836429596
    z[7,8,1]  R1999     -3.1234717369079590e-01
    z[7,8,1]  R2000     -6.9596379995346069e-01
    z[7,8,1]  R2001     0.572786271572113
    z[7,8,1]  R2002     -6.2916569411754608e-02
    z[7,8,1]  R2003     -2.0866429805755615e-01
    z[7,8,1]  R2004     -5.1932379603385925e-02
    z[7,8,1]  R2005     6.7793554067611694e-01
    z[7,8,1]  R2006     8.4547185897827148e-01
    z[7,8,1]  R2007     -0.654776394367218
    z[7,8,1]  R2008     -5.0122487545013428e-01
    z[7,8,1]  R2009     -0.17464579641819
    z[7,8,1]  R2010     8.6933094263076782e-01
    z[7,8,1]  R2011     8.5908889770507812e-01
    z[7,8,1]  R2012     8.3578372001647949e-01
    z[7,8,1]  R2013     8.0418592691421509e-01
    z[7,8,1]  R2014     7.8154599666595459e-01
    z[7,8,1]  R2015     -7.9524271190166473e-02
    z[7,8,1]  R2016     4.3006721138954163e-01
    z[7,8,1]  R2017     6.0038244724273682e-01
    z[7,8,1]  R2018     -0.348158061504364
    z[7,8,1]  R2019     6.6742175817489624e-01
    z[7,8,1]  R2020     5.6951224803924561e-01
    z[7,8,1]  R2021     -2.0942346751689911e-01
    z[7,8,1]  R2022     6.8685054779052734e-01
    z[7,8,1]  R2023     7.2288900613784790e-01
    z[7,8,1]  R2024     3.2047115266323090e-02
    z[7,8,1]  R2025     -2.7143087983131409e-01
    z[7,8,1]  R2026     -7.5525051355361938e-01
    z[7,8,1]  R2027     -6.9330054521560669e-01
    z[7,8,1]  R2028     -5.9834969043731689e-01
    z[7,8,1]  R2029     -5.3521466255187988e-01
    z[7,8,1]  R2030     -6.4924311637878418e-01
    z[7,8,1]  R2031     -7.2761493921279907e-01
    z[7,8,1]  R2032     -6.3145416975021362e-01
    z[7,8,1]  R2033     -4.4217732548713684e-01
    z[7,8,1]  R2034     0.265844464302063
    z[7,8,1]  R2035     5.5007302761077881e-01
    z[7,8,1]  R2036     5.3940200805664062e-01
    z[7,8,1]  R2037     1.4655441045761108e-01
    z[7,8,1]  R2038     2.4297359585762024e-01
    z[7,8,1]  R2039     -5.6602823734283447e-01
    z[7,8,1]  R2040     -1.7171211540699005e-01
    z[7,8,1]  R2041     6.2469226121902466e-01
    z[7,8,1]  R2042     1.5787769854068756e-01
    z[7,8,1]  R2043     6.5057468414306641e-01
    z[7,8,1]  R2044     3.6385115981101990e-01
    z[7,8,1]  R2045     1.4839459955692291e-01
    z[7,8,1]  R2046     4.5483246445655823e-01
    z[7,8,1]  R2047     -5.0865131616592407e-01
    z[7,8,1]  R2048     5.2377808094024658e-01
    z[7,8,1]  R2049     -5.3239434957504272e-01
    z[7,8,1]  R2050     5.6583970785140991e-01
    z[7,8,1]  R2051     4.6969932317733765e-01
    z[7,8,1]  R2052     3.6401736736297607e-01
    z[7,8,1]  R2053     7.7508658170700073e-02
    z[7,8,1]  R2054     -3.5676285624504089e-01
    z[7,8,1]  R2055     -4.3701842427253723e-02
    z[7,8,1]  R2056     2.4696822464466095e-01
    z[7,8,1]  R2057     2.7257981896400452e-01
    z[7,8,1]  R2058     -4.9792066216468811e-01
    z[7,8,1]  R2059     -3.2171663641929626e-01
    z[7,8,1]  R2060     2.5877881050109863e-01
    z[7,8,1]  R2061     4.9964633584022522e-01
    z[7,8,1]  R2062     -6.1221045255661011e-01
    z[7,8,1]  R2063     9.7677908837795258e-02
    z[7,8,1]  R2064     -5.5611205101013184e-01
    z[7,8,1]  R2065     0.0494234636425972
    z[7,8,1]  R2066     4.4642563909292221e-02
    z[7,8,1]  R2067     -1.4130115509033203e-01
    z[7,8,1]  R2068     0.358583003282547
    z[7,8,1]  R2069     -6.3015684485435486e-02
    z[7,8,1]  R2070     5.0175529718399048e-01
    z[7,8,1]  R2071     1.2697845697402954e-01
    z[7,8,1]  R2072     -2.1848936378955841e-01
    z[7,8,1]  R2073     3.7984037399291992e-01
    z[7,8,1]  R2074     5.0106209516525269e-01
    z[7,8,1]  R2075     0.666954517364502
    z[7,8,1]  R2076     4.7370767593383789e-01
    z[7,8,1]  R2077     4.9215254187583923e-01
    z[7,8,1]  R2078     3.5664218664169312e-01
    z[7,8,1]  R2079     0.0708300992846489
    z[7,8,1]  R2080     4.5316481590270996e-01
    z[7,8,1]  R2081     7.7104771137237549e-01
    z[7,8,1]  R2082     -7.5780582427978516e-01
    z[7,8,1]  R2083     -8.0938935279846191e-02
    z[7,8,1]  R2084     5.2663671970367432e-01
    z[7,8,1]  R2085     -3.8568067550659180e-01
    z[7,8,1]  R2086     4.6776360273361206e-01
    z[7,8,1]  R2087     2.4367228150367737e-01
    z[7,8,1]  R2088     5.9032875299453735e-01
    z[7,8,1]  R2089     0.531501054763794
    z[7,8,1]  R2090     4.0920135378837585e-01
    z[7,8,1]  R2091     1.8107984960079193e-01
    z[7,8,1]  R2092     -9.1409909725189209e-01
    z[7,8,1]  R2093     -3.5409516096115112e-01
    z[7,8,1]  R2094     -4.3090045452117920e-01
    z[7,8,1]  R2095     1.8716056644916534e-01
    z[7,8,1]  R2096     4.5817929506301880e-01
    z[7,8,1]  R2097     7.3749041557312012e-01
    z[7,8,1]  R2098     2.9498317837715149e-01
    z[7,8,1]  R2099     4.2501375079154968e-01
    z[7,8,1]  R2100     2.7181729674339294e-01
    z[7,8,1]  R2101     4.2410823702812195e-01
    z[7,8,1]  R2102     -1.9883349537849426e-02
    z[7,8,1]  R2103     -3.0261763930320740e-01
    z[7,8,1]  R2104     -7.1180623769760132e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R1957     -1
    z[7,8,2]  R1958     1
    z[7,8,2]  R1967     -4.5959183573722839e-01
    z[7,8,2]  R1968     -5.5117529630661011e-01
    z[7,8,2]  R1969     -3.2845515012741089e-01
    z[7,8,2]  R1970     -3.6801773309707642e-01
    z[7,8,2]  R1971     -2.8529864549636841e-01
    z[7,8,2]  R1972     -6.0903424024581909e-01
    z[7,8,2]  R1973     -1.9481046497821808e-01
    z[7,8,2]  R1974     -4.1978725790977478e-01
    z[7,8,2]  R1975     1.0509595274925232e-01
    z[7,8,2]  R1976     -6.8624660372734070e-02
    z[7,8,2]  R1977     0.410971999168396
    z[7,8,2]  R1978     5.5042487382888794e-01
    z[7,8,2]  R1979     6.3688921928405762e-01
    z[7,8,2]  R1980     -2.5539478287100792e-02
    z[7,8,2]  R1981     4.0504077076911926e-01
    z[7,8,2]  R1982     5.6090480089187622e-01
    z[7,8,2]  R1983     -3.9990995079278946e-02
    z[7,8,2]  R1984     4.5544752478599548e-01
    z[7,8,2]  R1985     1.4628442004323006e-02
    z[7,8,2]  R1986     3.9811581373214722e-01
    z[7,8,2]  R1987     -3.3156388998031616e-01
    z[7,8,2]  R1988     2.9727813601493835e-01
    z[7,8,2]  R1989     1.2578035891056061e-01
    z[7,8,2]  R1990     3.0262774229049683e-01
    z[7,8,2]  R1991     0.33199542760849
    z[7,8,2]  R1992     5.3181892633438110e-01
    z[7,8,2]  R1993     -3.3132388489320874e-04
    z[7,8,2]  R1994     -6.4216554164886475e-01
    z[7,8,2]  R1995     5.5402827262878418e-01
    z[7,8,2]  R1996     2.6416417956352234e-01
    z[7,8,2]  R1997     1.7065095901489258e-01
    z[7,8,2]  R1998     3.1260296702384949e-01
    z[7,8,2]  R1999     1.3980729877948761e-01
    z[7,8,2]  R2000     3.1571972370147705e-01
    z[7,8,2]  R2001     0.355589896440506
    z[7,8,2]  R2002     -2.6504507660865784e-01
    z[7,8,2]  R2003     -2.8752166777849197e-02
    z[7,8,2]  R2004     6.4543402194976807e-01
    z[7,8,2]  R2005     -3.2898673415184021e-01
    z[7,8,2]  R2006     1.8935500085353851e-01
    z[7,8,2]  R2007     2.4685647338628769e-02
    z[7,8,2]  R2008     -2.0121857523918152e-01
    z[7,8,2]  R2009     -2.0923744142055511e-01
    z[7,8,2]  R2010     2.1507760882377625e-01
    z[7,8,2]  R2011     3.6545589566230774e-01
    z[7,8,2]  R2012     4.1203314065933228e-01
    z[7,8,2]  R2013     3.1193997710943222e-02
    z[7,8,2]  R2014     1.7944779992103577e-01
    z[7,8,2]  R2015     -1.4506091177463531e-01
    z[7,8,2]  R2016     -4.0828222036361694e-01
    z[7,8,2]  R2017     -1.3990265130996704e-01
    z[7,8,2]  R2018     1.5811876952648163e-01
    z[7,8,2]  R2019     -6.6476821899414062e-01
    z[7,8,2]  R2020     -5.1513093709945679e-01
    z[7,8,2]  R2021     5.6466543674468994e-01
    z[7,8,2]  R2022     -2.7045628428459167e-01
    z[7,8,2]  R2023     -6.0067063570022583e-01
    z[7,8,2]  R2024     4.9722400307655334e-01
    z[7,8,2]  R2025     -9.8033733665943146e-03
    z[7,8,2]  R2026     4.5843723416328430e-01
    z[7,8,2]  R2027     4.7923445701599121e-01
    z[7,8,2]  R2028     5.4851877689361572e-01
    z[7,8,2]  R2029     3.9394792914390564e-01
    z[7,8,2]  R2030     4.8835653066635132e-01
    z[7,8,2]  R2031     3.5637223720550537e-01
    z[7,8,2]  R2032     5.6142389774322510e-01
    z[7,8,2]  R2033     5.4904019832611084e-01
    z[7,8,2]  R2034     -2.3786285519599915e-01
    z[7,8,2]  R2035     0.0487288273870945
    z[7,8,2]  R2036     -2.6154069229960442e-02
    z[7,8,2]  R2037     4.2261460423469543e-01
    z[7,8,2]  R2038     4.2749884724617004e-01
    z[7,8,2]  R2039     3.4843704104423523e-01
    z[7,8,2]  R2040     1.8114510178565979e-01
    z[7,8,2]  R2041     3.1396117061376572e-02
    z[7,8,2]  R2042     -3.8140231370925903e-01
    z[7,8,2]  R2043     -1.4456406235694885e-01
    z[7,8,2]  R2044     -4.6017771959304810e-01
    z[7,8,2]  R2045     4.1910163126885891e-03
    z[7,8,2]  R2046     -6.4679676294326782e-01
    z[7,8,2]  R2047     -2.4103774130344391e-01
    z[7,8,2]  R2048     -2.5775903463363647e-01
    z[7,8,2]  R2049     -4.9242994189262390e-01
    z[7,8,2]  R2050     -5.4433572292327881e-01
    z[7,8,2]  R2051     -1.7263974249362946e-01
    z[7,8,2]  R2052     -2.8131538629531860e-01
    z[7,8,2]  R2053     -5.9280896186828613e-01
    z[7,8,2]  R2054     3.9855021238327026e-01
    z[7,8,2]  R2055     -2.3835518956184387e-01
    z[7,8,2]  R2056     -3.8933902978897095e-01
    z[7,8,2]  R2057     1.4332948625087738e-01
    z[7,8,2]  R2058     -5.1626789569854736e-01
    z[7,8,2]  R2059     5.0522979348897934e-02
    z[7,8,2]  R2060     -5.4258454591035843e-02
    z[7,8,2]  R2061     -3.3366364240646362e-01
    z[7,8,2]  R2062     2.1466314792633057e-02
    z[7,8,2]  R2063     1.4715506136417389e-01
    z[7,8,2]  R2064     -4.2111596465110779e-01
    z[7,8,2]  R2065     2.6426786184310913e-01
    z[7,8,2]  R2066     4.9070903658866882e-01
    z[7,8,2]  R2067     2.7465194463729858e-01
    z[7,8,2]  R2068     1.6144557297229767e-01
    z[7,8,2]  R2069     1.0726875066757202e-01
    z[7,8,2]  R2070     9.6196554601192474e-02
    z[7,8,2]  R2071     -1.9534166157245636e-01
    z[7,8,2]  R2072     6.4866676926612854e-02
    z[7,8,2]  R2073     1.0155776888132095e-01
    z[7,8,2]  R2074     -3.3164986968040466e-01
    z[7,8,2]  R2075     -2.1577699109911919e-02
    z[7,8,2]  R2076     -4.0542903542518616e-01
    z[7,8,2]  R2077     -5.8782523870468140e-01
    z[7,8,2]  R2078     -6.2577402591705322e-01
    z[7,8,2]  R2079     -3.5352534055709839e-01
    z[7,8,2]  R2080     -4.1959038376808167e-01
    z[7,8,2]  R2081     -3.8010302186012268e-01
    z[7,8,2]  R2082     5.4346317052841187e-01
    z[7,8,2]  R2083     2.2473068535327911e-01
    z[7,8,2]  R2084     -0.0822916328907013
    z[7,8,2]  R2085     -2.4013957008719444e-03
    z[7,8,2]  R2086     0.181917205452919
    z[7,8,2]  R2087     0.0684681311249733
    z[7,8,2]  R2088     -6.6954821348190308e-01
    z[7,8,2]  R2089     -5.5514967441558838e-01
    z[7,8,2]  R2090     -7.1552932262420654e-01
    z[7,8,2]  R2091     9.0828202664852142e-02
    z[7,8,2]  R2092     2.6896980404853821e-01
    z[7,8,2]  R2093     6.1077654361724854e-01
    z[7,8,2]  R2094     6.1808902770280838e-02
    z[7,8,2]  R2095     1.2700352072715759e-01
    z[7,8,2]  R2096     -3.4459051489830017e-01
    z[7,8,2]  R2097     -4.1717949509620667e-01
    z[7,8,2]  R2098     -4.3970888853073120e-01
    z[7,8,2]  R2099     -6.7316633462905884e-01
    z[7,8,2]  R2100     -6.3947242498397827e-01
    z[7,8,2]  R2101     -1.5409936010837555e-01
    z[7,8,2]  R2102     -6.5547204017639160e-01
    z[7,8,2]  R2103     -3.3076709508895874e-01
    z[7,8,2]  R2104     3.5841265320777893e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R1959     -1
    z[7,8,3]  R1960     1
    z[7,8,3]  R1967     5.3412193059921265e-01
    z[7,8,3]  R1968     3.5509994626045227e-01
    z[7,8,3]  R1969     5.6234270334243774e-01
    z[7,8,3]  R1970     1.8797422945499420e-01
    z[7,8,3]  R1971     4.3108406662940979e-01
    z[7,8,3]  R1972     2.6964026689529419e-01
    z[7,8,3]  R1973     5.5359804630279541e-01
    z[7,8,3]  R1974     -2.1320657432079315e-01
    z[7,8,3]  R1975     -0.266482949256897
    z[7,8,3]  R1976     -2.5109395384788513e-02
    z[7,8,3]  R1977     6.1683785170316696e-02
    z[7,8,3]  R1978     5.4878854751586914e-01
    z[7,8,3]  R1979     5.7285404205322266e-01
    z[7,8,3]  R1980     -6.4620566368103027e-01
    z[7,8,3]  R1981     2.9126688838005066e-01
    z[7,8,3]  R1982     5.6145054101943970e-01
    z[7,8,3]  R1983     -5.1702308654785156e-01
    z[7,8,3]  R1984     -2.6268932223320007e-01
    z[7,8,3]  R1985     7.1090564131736755e-02
    z[7,8,3]  R1986     -1.5342529118061066e-01
    z[7,8,3]  R1987     -5.6785982847213745e-01
    z[7,8,3]  R1988     -2.7150332927703857e-01
    z[7,8,3]  R1989     5.8796745538711548e-01
    z[7,8,3]  R1990     3.0893996357917786e-01
    z[7,8,3]  R1991     -4.6980452537536621e-01
    z[7,8,3]  R1992     -0.427613228559494
    z[7,8,3]  R1993     -1.9598762691020966e-01
    z[7,8,3]  R1994     -1.6931539773941040e-01
    z[7,8,3]  R1995     3.8242614269256592e-01
    z[7,8,3]  R1996     -8.3257377147674561e-01
    z[7,8,3]  R1997     -0.640066921710968
    z[7,8,3]  R1998     -4.0373942255973816e-01
    z[7,8,3]  R1999     -5.1015150547027588e-01
    z[7,8,3]  R2000     4.0715858340263367e-01
    z[7,8,3]  R2001     0.630540668964386
    z[7,8,3]  R2002     -8.7552732229232788e-01
    z[7,8,3]  R2003     -5.7726246118545532e-01
    z[7,8,3]  R2004     5.5400753021240234e-01
    z[7,8,3]  R2005     -1.1411420255899429e-01
    z[7,8,3]  R2006     -3.7139368057250977e-01
    z[7,8,3]  R2007     -4.6015629172325134e-01
    z[7,8,3]  R2008     -5.1192593574523926e-01
    z[7,8,3]  R2009     -7.3500746488571167e-01
    z[7,8,3]  R2010     -3.4131145477294922e-01
    z[7,8,3]  R2011     -2.5124719738960266e-01
    z[7,8,3]  R2012     -3.1104597449302673e-01
    z[7,8,3]  R2013     -4.5039784908294678e-01
    z[7,8,3]  R2014     -2.8034844994544983e-01
    z[7,8,3]  R2015     6.3471293449401855e-01
    z[7,8,3]  R2016     3.7169404327869415e-02
    z[7,8,3]  R2017     1.5428406186401844e-02
    z[7,8,3]  R2018     4.8135069012641907e-01
    z[7,8,3]  R2019     8.5634356364607811e-03
    z[7,8,3]  R2020     4.9765971302986145e-01
    z[7,8,3]  R2021     4.4825062155723572e-01
    z[7,8,3]  R2022     4.4120573997497559e-01
    z[7,8,3]  R2023     9.6951022744178772e-02
    z[7,8,3]  R2024     6.3274890184402466e-01
    z[7,8,3]  R2025     7.6028275489807129e-01
    z[7,8,3]  R2026     -3.6877706646919250e-02
    z[7,8,3]  R2027     -2.1236577630043030e-01
    z[7,8,3]  R2028     -2.8400555253028870e-01
    z[7,8,3]  R2029     -3.2647213339805603e-01
    z[7,8,3]  R2030     -3.6428447812795639e-02
    z[7,8,3]  R2031     -3.6264741420745850e-01
    z[7,8,3]  R2032     -4.7265359759330750e-01
    z[7,8,3]  R2033     -4.7184243798255920e-01
    z[7,8,3]  R2034     4.5467212796211243e-01
    z[7,8,3]  R2035     -7.5866356492042542e-02
    z[7,8,3]  R2036     1.8623191118240356e-01
    z[7,8,3]  R2037     -1.4141495525836945e-01
    z[7,8,3]  R2038     3.2630637288093567e-01
    z[7,8,3]  R2039     1.7457969486713409e-01
    z[7,8,3]  R2040     5.9118086099624634e-01
    z[7,8,3]  R2041     3.7921655178070068e-01
    z[7,8,3]  R2042     -7.4865147471427917e-02
    z[7,8,3]  R2043     4.3815410137176514e-01
    z[7,8,3]  R2044     1.6231262683868408e-01
    z[7,8,3]  R2045     7.2276329994201660e-01
    z[7,8,3]  R2046     -3.9736565947532654e-01
    z[7,8,3]  R2047     3.7152585387229919e-01
    z[7,8,3]  R2048     5.5104327201843262e-01
    z[7,8,3]  R2049     3.4945863485336304e-01
    z[7,8,3]  R2050     -1.7210496589541435e-02
    z[7,8,3]  R2051     4.3477201461791992e-01
    z[7,8,3]  R2052     8.3079628646373749e-02
    z[7,8,3]  R2053     7.0735722780227661e-02
    z[7,8,3]  R2054     8.2067184150218964e-02
    z[7,8,3]  R2055     3.2217529416084290e-01
    z[7,8,3]  R2056     -2.6893955469131470e-01
    z[7,8,3]  R2057     -1.4151706127449870e-03
    z[7,8,3]  R2058     3.4386447072029114e-01
    z[7,8,3]  R2059     8.5708731412887573e-01
    z[7,8,3]  R2060     2.5729832053184509e-01
    z[7,8,3]  R2061     2.5699369609355927e-02
    z[7,8,3]  R2062     0.627197265625
    z[7,8,3]  R2063     4.7050496935844421e-01
    z[7,8,3]  R2064     1.7863745987415314e-01
    z[7,8,3]  R2065     4.8613610863685608e-01
    z[7,8,3]  R2066     7.9316431283950806e-01
    z[7,8,3]  R2067     7.6619559526443481e-01
    z[7,8,3]  R2068     -4.2995044589042664e-01
    z[7,8,3]  R2069     3.6229613423347473e-01
    z[7,8,3]  R2070     -1.9225323200225830e-01
    z[7,8,3]  R2071     1.5171775221824646e-01
    z[7,8,3]  R2072     0.892119824886322
    z[7,8,3]  R2073     -4.1772323846817017e-01
    z[7,8,3]  R2074     3.9665955305099487e-01
    z[7,8,3]  R2075     -3.1335288076661527e-04
    z[7,8,3]  R2076     1.2308204174041748e-01
    z[7,8,3]  R2077     3.3044064044952393e-01
    z[7,8,3]  R2078     3.1732434034347534e-01
    z[7,8,3]  R2079     -6.2446214258670807e-02
    z[7,8,3]  R2080     -0.0313868410885334
    z[7,8,3]  R2081     -6.0916036367416382e-02
    z[7,8,3]  R2082     1.9142033159732819e-01
    z[7,8,3]  R2083     4.7483634203672409e-02
    z[7,8,3]  R2084     1.1565615981817245e-01
    z[7,8,3]  R2085     4.1282907128334045e-01
    z[7,8,3]  R2086     5.0725466012954712e-01
    z[7,8,3]  R2087     1.5332493185997009e-01
    z[7,8,3]  R2088     -1.2244151532649994e-01
    z[7,8,3]  R2089     1.3098880648612976e-01
    z[7,8,3]  R2090     2.2630952298641205e-01
    z[7,8,3]  R2091     -4.9962222576141357e-01
    z[7,8,3]  R2092     -1.8756206333637238e-01
    z[7,8,3]  R2093     1.8390727043151855e-01
    z[7,8,3]  R2094     5.0447350740432739e-01
    z[7,8,3]  R2095     -2.1160425245761871e-01
    z[7,8,3]  R2096     -3.9655330777168274e-01
    z[7,8,3]  R2097     6.8886585533618927e-02
    z[7,8,3]  R2098     1.8579009175300598e-01
    z[7,8,3]  R2099     7.5899370014667511e-02
    z[7,8,3]  R2100     2.8333681821823120e-01
    z[7,8,3]  R2101     3.2837271690368652e-01
    z[7,8,3]  R2102     -9.9064677953720093e-02
    z[7,8,3]  R2103     2.5260293483734131e-01
    z[7,8,3]  R2104     2.0337322354316711e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R1961     -1
    z[7,8,4]  R1962     1
    z[7,8,4]  R1967     2.2251971065998077e-02
    z[7,8,4]  R1968     -2.3627656698226929e-01
    z[7,8,4]  R1969     -4.4636905193328857e-01
    z[7,8,4]  R1970     8.7686873972415924e-02
    z[7,8,4]  R1971     -7.2892510890960693e-01
    z[7,8,4]  R1972     -2.8721296787261963e-01
    z[7,8,4]  R1973     -3.9025208353996277e-01
    z[7,8,4]  R1974     1.4211065135896206e-02
    z[7,8,4]  R1975     -1.4557726681232452e-01
    z[7,8,4]  R1976     5.5874037742614746e-01
    z[7,8,4]  R1977     1.8388934433460236e-01
    z[7,8,4]  R1978     1.5091983973979950e-01
    z[7,8,4]  R1979     -3.9319179952144623e-02
    z[7,8,4]  R1980     -4.6640940010547638e-02
    z[7,8,4]  R1981     -3.1542456150054932e-01
    z[7,8,4]  R1982     3.7751308083534241e-01
    z[7,8,4]  R1983     6.8618780374526978e-01
    z[7,8,4]  R1984     -4.1213774681091309e-01
    z[7,8,4]  R1985     3.3205825090408325e-01
    z[7,8,4]  R1986     2.5704520940780640e-01
    z[7,8,4]  R1987     0.366986483335495
    z[7,8,4]  R1988     4.7017842531204224e-02
    z[7,8,4]  R1989     -2.4060022085905075e-02
    z[7,8,4]  R1990     -3.1388887763023376e-01
    z[7,8,4]  R1991     4.5337316393852234e-01
    z[7,8,4]  R1992     3.8295388221740723e-01
    z[7,8,4]  R1993     -5.7923948764801025e-01
    z[7,8,4]  R1994     -2.0442249253392220e-02
    z[7,8,4]  R1995     4.6696513891220093e-01
    z[7,8,4]  R1996     4.5723305083811283e-03
    z[7,8,4]  R1997     5.8073186874389648e-01
    z[7,8,4]  R1998     -2.2077956795692444e-01
    z[7,8,4]  R1999     5.2164965867996216e-01
    z[7,8,4]  R2000     3.5395428538322449e-01
    z[7,8,4]  R2001     2.5436949729919434e-01
    z[7,8,4]  R2002     -3.7642422318458557e-01
    z[7,8,4]  R2003     -3.0911937355995178e-01
    z[7,8,4]  R2004     -1.6816121339797974e-01
    z[7,8,4]  R2005     5.3540492057800293e-01
    z[7,8,4]  R2006     1.9686232507228851e-01
    z[7,8,4]  R2007     3.8858780264854431e-01
    z[7,8,4]  R2008     7.1289457380771637e-02
    z[7,8,4]  R2009     -4.0224009752273560e-01
    z[7,8,4]  R2010     1.4052438735961914e-01
    z[7,8,4]  R2011     -1.4828655123710632e-01
    z[7,8,4]  R2012     3.1841620802879333e-02
    z[7,8,4]  R2013     1.7281240224838257e-01
    z[7,8,4]  R2014     2.6056563854217529e-01
    z[7,8,4]  R2015     -2.1748287975788116e-01
    z[7,8,4]  R2016     -5.6903768330812454e-02
    z[7,8,4]  R2017     -0.0574452243745327
    z[7,8,4]  R2018     -2.6986968517303467e-01
    z[7,8,4]  R2019     4.9347940832376480e-02
    z[7,8,4]  R2020     1.8177621066570282e-02
    z[7,8,4]  R2021     1.0496149957180023e-01
    z[7,8,4]  R2022     -1.0570524632930756e-01
    z[7,8,4]  R2023     -5.3320780396461487e-02
    z[7,8,4]  R2024     -3.2039427757263184e-01
    z[7,8,4]  R2025     -9.1939605772495270e-02
    z[7,8,4]  R2026     7.3073320090770721e-02
    z[7,8,4]  R2027     3.6314350366592407e-01
    z[7,8,4]  R2028     3.4748658537864685e-01
    z[7,8,4]  R2029     1.0689140111207962e-01
    z[7,8,4]  R2030     2.5803259015083313e-01
    z[7,8,4]  R2031     0.014848074875772
    z[7,8,4]  R2032     6.9001503288745880e-02
    z[7,8,4]  R2033     3.1547278165817261e-01
    z[7,8,4]  R2034     -7.0220857858657837e-01
    z[7,8,4]  R2035     -5.0553835928440094e-02
    z[7,8,4]  R2036     -3.8211759924888611e-01
    z[7,8,4]  R2037     2.9748806357383728e-01
    z[7,8,4]  R2038     3.0938872694969177e-01
    z[7,8,4]  R2039     -2.2808396816253662e-01
    z[7,8,4]  R2040     5.9838145971298218e-01
    z[7,8,4]  R2041     5.1360901445150375e-02
    z[7,8,4]  R2042     -2.9469090700149536e-01
    z[7,8,4]  R2043     6.3740663230419159e-02
    z[7,8,4]  R2044     -5.0611924380064011e-02
    z[7,8,4]  R2045     2.7012842893600464e-01
    z[7,8,4]  R2046     2.4763178080320358e-02
    z[7,8,4]  R2047     -4.5352885127067566e-01
    z[7,8,4]  R2048     -4.9569332599639893e-01
    z[7,8,4]  R2049     -1.3083736598491669e-01
    z[7,8,4]  R2050     -2.7934324741363525e-01
    z[7,8,4]  R2051     -2.4890260398387909e-01
    z[7,8,4]  R2052     4.3951147794723511e-01
    z[7,8,4]  R2053     -5.2005261182785034e-01
    z[7,8,4]  R2054     -5.2744048833847046e-01
    z[7,8,4]  R2055     -1.5415717661380768e-01
    z[7,8,4]  R2056     -2.0392365753650665e-01
    z[7,8,4]  R2057     -1.3303364813327789e-01
    z[7,8,4]  R2058     1.4022152125835419e-01
    z[7,8,4]  R2059     2.6859796047210693e-01
    z[7,8,4]  R2060     0.272236168384552
    z[7,8,4]  R2061     9.5518708229064941e-02
    z[7,8,4]  R2062     5.6548561900854111e-02
    z[7,8,4]  R2063     -2.4783669412136078e-01
    z[7,8,4]  R2064     1.7186237871646881e-01
    z[7,8,4]  R2065     -1.0055442899465561e-01
    z[7,8,4]  R2066     1.6592821478843689e-01
    z[7,8,4]  R2067     -2.9397532343864441e-02
    z[7,8,4]  R2068     4.6979844570159912e-02
    z[7,8,4]  R2069     -1.2716351449489594e-01
    z[7,8,4]  R2070     -4.4760741293430328e-02
    z[7,8,4]  R2071     2.2285891696810722e-02
    z[7,8,4]  R2072     -1.9680918753147125e-01
    z[7,8,4]  R2073     9.7770921885967255e-02
    z[7,8,4]  R2074     -2.7405008673667908e-01
    z[7,8,4]  R2075     1.4631024003028870e-01
    z[7,8,4]  R2076     -1.8064735829830170e-01
    z[7,8,4]  R2077     -3.1060841679573059e-01
    z[7,8,4]  R2078     -1.6298873722553253e-01
    z[7,8,4]  R2079     -2.9918268322944641e-01
    z[7,8,4]  R2080     -3.9690437912940979e-01
    z[7,8,4]  R2081     2.8621044754981995e-01
    z[7,8,4]  R2082     -3.2313957810401917e-02
    z[7,8,4]  R2083     -3.3583962917327881e-01
    z[7,8,4]  R2084     3.2931387424468994e-01
    z[7,8,4]  R2085     -1.1051273345947266e-01
    z[7,8,4]  R2086     1.2172869592905045e-01
    z[7,8,4]  R2087     -3.1887373328208923e-01
    z[7,8,4]  R2088     -1.2618668377399445e-01
    z[7,8,4]  R2089     3.1021785736083984e-01
    z[7,8,4]  R2090     -1.8007430434226990e-01
    z[7,8,4]  R2091     5.1927787065505981e-01
    z[7,8,4]  R2092     -0.198231503367424
    z[7,8,4]  R2093     -4.4913059473037720e-01
    z[7,8,4]  R2094     -7.4144983291625977e-01
    z[7,8,4]  R2095     2.5618669390678406e-01
    z[7,8,4]  R2096     -1.0460326820611954e-01
    z[7,8,4]  R2097     -8.8932946324348450e-02
    z[7,8,4]  R2098     -3.7543994188308716e-01
    z[7,8,4]  R2099     -5.5314081907272339e-01
    z[7,8,4]  R2100     -3.0125668644905090e-01
    z[7,8,4]  R2101     1.9281382858753204e-01
    z[7,8,4]  R2102     -1.4993591606616974e-01
    z[7,8,4]  R2103     6.6682964563369751e-01
    z[7,8,4]  R2104     4.2104795575141907e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R1963     -1
    z[7,8,5]  R1964     1
    z[7,8,5]  R1967     1.4725837111473083e-01
    z[7,8,5]  R1968     1.5593683719635010e-01
    z[7,8,5]  R1969     4.4074773788452148e-01
    z[7,8,5]  R1970     3.3375957608222961e-01
    z[7,8,5]  R1971     1.0006825625896454e-01
    z[7,8,5]  R1972     -3.3978302963078022e-03
    z[7,8,5]  R1973     -2.8802141547203064e-01
    z[7,8,5]  R1974     -2.9621142148971558e-01
    z[7,8,5]  R1975     1.9540265202522278e-01
    z[7,8,5]  R1976     -4.0066826343536377e-01
    z[7,8,5]  R1977     3.0967578291893005e-01
    z[7,8,5]  R1978     -4.0537956357002258e-01
    z[7,8,5]  R1979     -2.8869214653968811e-01
    z[7,8,5]  R1980     -4.5290020108222961e-01
    z[7,8,5]  R1981     -4.5167851448059082e-01
    z[7,8,5]  R1982     0.0571405366063118
    z[7,8,5]  R1983     3.5836282372474670e-01
    z[7,8,5]  R1984     -9.0226821601390839e-02
    z[7,8,5]  R1985     -6.4252573251724243e-01
    z[7,8,5]  R1986     -2.7371481060981750e-01
    z[7,8,5]  R1987     3.3961218595504761e-01
    z[7,8,5]  R1988     -4.0715846419334412e-01
    z[7,8,5]  R1989     -1.2031991779804230e-01
    z[7,8,5]  R1990     -1.8161757290363312e-01
    z[7,8,5]  R1991     3.1795452814549208e-03
    z[7,8,5]  R1992     5.5409610271453857e-02
    z[7,8,5]  R1993     -2.9763779044151306e-01
    z[7,8,5]  R1994     1.8753847479820251e-01
    z[7,8,5]  R1995     -4.5380941033363342e-01
    z[7,8,5]  R1996     -2.9769745469093323e-01
    z[7,8,5]  R1997     -1.7324566841125488e-01
    z[7,8,5]  R1998     -5.0331324338912964e-01
    z[7,8,5]  R1999     -1.7354843020439148e-01
    z[7,8,5]  R2000     -1.4737382531166077e-02
    z[7,8,5]  R2001     -2.2738638520240784e-01
    z[7,8,5]  R2002     7.1067869663238525e-02
    z[7,8,5]  R2003     2.7304738759994507e-01
    z[7,8,5]  R2004     -0.157281756401062
    z[7,8,5]  R2005     -3.2786116003990173e-01
    z[7,8,5]  R2006     -1.9458128511905670e-01
    z[7,8,5]  R2007     -1.7302711308002472e-01
    z[7,8,5]  R2008     5.1286923885345459e-01
    z[7,8,5]  R2009     -2.5918769836425781e-01
    z[7,8,5]  R2010     -0.0354522168636322
    z[7,8,5]  R2011     2.3612717166543007e-02
    z[7,8,5]  R2012     -3.3197902143001556e-02
    z[7,8,5]  R2013     1.9197198748588562e-01
    z[7,8,5]  R2014     4.0260636806488037e-01
    z[7,8,5]  R2015     -6.5225899219512939e-01
    z[7,8,5]  R2016     -1.0487017780542374e-01
    z[7,8,5]  R2017     1.6407051682472229e-01
    z[7,8,5]  R2018     -2.5416249036788940e-01
    z[7,8,5]  R2019     8.9542150497436523e-02
    z[7,8,5]  R2020     -1.5008129179477692e-01
    z[7,8,5]  R2021     -4.2632433772087097e-01
    z[7,8,5]  R2022     -4.1950282454490662e-01
    z[7,8,5]  R2023     -3.0137532949447632e-01
    z[7,8,5]  R2024     -4.6895641088485718e-01
    z[7,8,5]  R2025     7.9206518828868866e-02
    z[7,8,5]  R2026     2.2923554480075836e-01
    z[7,8,5]  R2027     -2.7379798889160156e-01
    z[7,8,5]  R2028     -2.3873747885227203e-01
    z[7,8,5]  R2029     -6.5112107992172241e-01
    z[7,8,5]  R2030     -4.5467257499694824e-01
    z[7,8,5]  R2031     -4.2832094430923462e-01
    z[7,8,5]  R2032     -2.2712954878807068e-01
    z[7,8,5]  R2033     -3.4039071202278137e-01
    z[7,8,5]  R2034     3.0946722626686096e-01
    z[7,8,5]  R2035     3.9994516968727112e-01
    z[7,8,5]  R2036     1.6013096272945404e-01
    z[7,8,5]  R2037     1.6711945831775665e-01
    z[7,8,5]  R2038     -2.1236881613731384e-01
    z[7,8,5]  R2039     -0.656708300113678
    z[7,8,5]  R2040     -4.6250590682029724e-01
    z[7,8,5]  R2041     3.4696620702743530e-01
    z[7,8,5]  R2042     -3.6067828536033630e-01
    z[7,8,5]  R2043     -2.3430296778678894e-01
    z[7,8,5]  R2044     -8.6028032004833221e-02
    z[7,8,5]  R2045     -4.0161529183387756e-01
    z[7,8,5]  R2046     3.9787840843200684e-01
    z[7,8,5]  R2047     -2.2953392565250397e-01
    z[7,8,5]  R2048     -4.5798502862453461e-02
    z[7,8,5]  R2049     -3.5307437181472778e-01
    z[7,8,5]  R2050     5.3968578577041626e-01
    z[7,8,5]  R2051     3.3117014169692993e-01
    z[7,8,5]  R2052     4.7005578875541687e-01
    z[7,8,5]  R2053     4.3799132108688354e-01
    z[7,8,5]  R2054     -6.3618764281272888e-02
    z[7,8,5]  R2055     -8.2405406236648560e-01
    z[7,8,5]  R2056     1.9800260663032532e-01
    z[7,8,5]  R2057     5.0412613153457642e-01
    z[7,8,5]  R2058     -5.0805461406707764e-01
    z[7,8,5]  R2059     3.7181344814598560e-03
    z[7,8,5]  R2060     2.9719021916389465e-01
    z[7,8,5]  R2061     2.3098704218864441e-01
    z[7,8,5]  R2062     -2.0979806780815125e-01
    z[7,8,5]  R2063     -1.5571042895317078e-01
    z[7,8,5]  R2064     -2.1392270922660828e-01
    z[7,8,5]  R2065     -6.9061291217803955e-01
    z[7,8,5]  R2066     -2.8672060370445251e-01
    z[7,8,5]  R2067     -3.4048205614089966e-01
    z[7,8,5]  R2068     -1.7928700149059296e-01
    z[7,8,5]  R2069     -7.5652748346328735e-02
    z[7,8,5]  R2070     1.7019577324390411e-01
    z[7,8,5]  R2071     -4.0748879313468933e-01
    z[7,8,5]  R2072     5.4188175126910210e-03
    z[7,8,5]  R2073     -4.3096852302551270e-01
    z[7,8,5]  R2074     2.1025471389293671e-01
    z[7,8,5]  R2075     -3.4225851297378540e-01
    z[7,8,5]  R2076     -2.2261887788772583e-01
    z[7,8,5]  R2077     -3.7638089060783386e-01
    z[7,8,5]  R2078     3.6430227756500244e-01
    z[7,8,5]  R2079     6.5975874662399292e-01
    z[7,8,5]  R2080     5.1600843667984009e-01
    z[7,8,5]  R2081     3.8433954119682312e-01
    z[7,8,5]  R2082     1.9256788492202759e-01
    z[7,8,5]  R2083     -4.2669618129730225e-01
    z[7,8,5]  R2084     5.8736038208007812e-01
    z[7,8,5]  R2085     -6.5819948911666870e-01
    z[7,8,5]  R2086     -7.7228508889675140e-02
    z[7,8,5]  R2087     -3.1256824731826782e-01
    z[7,8,5]  R2088     2.6809409260749817e-01
    z[7,8,5]  R2089     -1.7583874985575676e-02
    z[7,8,5]  R2090     -1.0468696802854538e-01
    z[7,8,5]  R2091     -1.9151781499385834e-01
    z[7,8,5]  R2092     -5.7094257324934006e-02
    z[7,8,5]  R2093     -0.263357013463974
    z[7,8,5]  R2094     7.4967904947698116e-03
    z[7,8,5]  R2095     -0.0255416352301836
    z[7,8,5]  R2096     3.8038536906242371e-01
    z[7,8,5]  R2097     2.9868012666702271e-01
    z[7,8,5]  R2098     -7.8571937978267670e-02
    z[7,8,5]  R2099     -2.2287155687808990e-01
    z[7,8,5]  R2100     -1.0560614988207817e-02
    z[7,8,5]  R2101     0.505304753780365
    z[7,8,5]  R2102     7.6099641621112823e-02
    z[7,8,5]  R2103     -3.4238103032112122e-01
    z[7,8,5]  R2104     2.7827474474906921e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R1965     -1
    z[7,8,6]  R1966     1
    z[7,8,6]  R1967     -0.302512526512146
    z[7,8,6]  R1968     3.2013422250747681e-01
    z[7,8,6]  R1969     2.7645963430404663e-01
    z[7,8,6]  R1970     3.4591197967529297e-01
    z[7,8,6]  R1971     -1.0379598289728165e-01
    z[7,8,6]  R1972     2.3165971040725708e-01
    z[7,8,6]  R1973     2.5857791304588318e-01
    z[7,8,6]  R1974     -7.2749868035316467e-02
    z[7,8,6]  R1975     1.6995021700859070e-01
    z[7,8,6]  R1976     3.2450035214424133e-01
    z[7,8,6]  R1977     4.4050562381744385e-01
    z[7,8,6]  R1978     -2.5648474693298340e-01
    z[7,8,6]  R1979     -3.6785000562667847e-01
    z[7,8,6]  R1980     -4.5664796233177185e-01
    z[7,8,6]  R1981     4.7958934307098389e-01
    z[7,8,6]  R1982     3.2247710227966309e-01
    z[7,8,6]  R1983     -1.4056035876274109e-01
    z[7,8,6]  R1984     -6.4469277858734131e-01
    z[7,8,6]  R1985     -1.1656996607780457e-01
    z[7,8,6]  R1986     -2.6940440759062767e-02
    z[7,8,6]  R1987     2.6471406221389771e-01
    z[7,8,6]  R1988     -7.2548437118530273e-01
    z[7,8,6]  R1989     8.7576441466808319e-02
    z[7,8,6]  R1990     -3.4995871782302856e-01
    z[7,8,6]  R1991     -6.4238435029983521e-01
    z[7,8,6]  R1992     -5.2331924438476562e-01
    z[7,8,6]  R1993     3.4439265727996826e-01
    z[7,8,6]  R1994     -1.1146487295627594e-01
    z[7,8,6]  R1995     -1.4820632338523865e-01
    z[7,8,6]  R1996     -1.4348258078098297e-01
    z[7,8,6]  R1997     -1.3156990706920624e-01
    z[7,8,6]  R1998     -2.0089823007583618e-01
    z[7,8,6]  R1999     -5.6589150428771973e-01
    z[7,8,6]  R2000     -3.4332635998725891e-01
    z[7,8,6]  R2001     -1.6490109264850616e-02
    z[7,8,6]  R2002     1.0197193175554276e-01
    z[7,8,6]  R2003     -6.4058023691177368e-01
    z[7,8,6]  R2004     2.3046158254146576e-01
    z[7,8,6]  R2005     1.5784651041030884e-01
    z[7,8,6]  R2006     -1.8610309064388275e-01
    z[7,8,6]  R2007     -4.1490641236305237e-01
    z[7,8,6]  R2008     -3.2571631669998169e-01
    z[7,8,6]  R2009     3.4918409585952759e-01
    z[7,8,6]  R2010     6.2470335513353348e-02
    z[7,8,6]  R2011     -1.7074249684810638e-01
    z[7,8,6]  R2012     -1.4392884075641632e-01
    z[7,8,6]  R2013     -2.7983868122100830e-01
    z[7,8,6]  R2014     -1.7215034365653992e-01
    z[7,8,6]  R2015     -1.3175633549690247e-01
    z[7,8,6]  R2016     1.5665335953235626e-01
    z[7,8,6]  R2017     5.2384608983993530e-01
    z[7,8,6]  R2018     6.6977924108505249e-01
    z[7,8,6]  R2019     -2.2763228416442871e-01
    z[7,8,6]  R2020     2.8818333521485329e-02
    z[7,8,6]  R2021     4.9332848191261292e-01
    z[7,8,6]  R2022     2.4070571362972260e-01
    z[7,8,6]  R2023     -7.6405160129070282e-02
    z[7,8,6]  R2024     3.3910922706127167e-02
    z[7,8,6]  R2025     -5.6884109973907471e-01
    z[7,8,6]  R2026     3.9632487297058105e-01
    z[7,8,6]  R2027     -1.7966100573539734e-01
    z[7,8,6]  R2028     -0.0784110277891159
    z[7,8,6]  R2029     1.2755751609802246e-01
    z[7,8,6]  R2030     -0.190152108669281
    z[7,8,6]  R2031     -1.0380861163139343e-01
    z[7,8,6]  R2032     -4.7682128846645355e-02
    z[7,8,6]  R2033     2.1728739142417908e-01
    z[7,8,6]  R2034     2.1173125505447388e-01
    z[7,8,6]  R2035     -5.3208328783512115e-02
    z[7,8,6]  R2036     2.3521710932254791e-01
    z[7,8,6]  R2037     -2.6275765895843506e-01
    z[7,8,6]  R2038     9.0591244399547577e-02
    z[7,8,6]  R2039     0.00939799565821886
    z[7,8,6]  R2040     1.2457884848117828e-01
    z[7,8,6]  R2041     1.3694353401660919e-01
    z[7,8,6]  R2042     -2.0731341838836670e-01
    z[7,8,6]  R2043     -2.3764740675687790e-02
    z[7,8,6]  R2044     -4.9654132127761841e-01
    z[7,8,6]  R2045     -4.4730773568153381e-01
    z[7,8,6]  R2046     -1.4911796152591705e-01
    z[7,8,6]  R2047     -5.2431887388229370e-01
    z[7,8,6]  R2048     3.0611521005630493e-01
    z[7,8,6]  R2049     -4.4138675928115845e-01
    z[7,8,6]  R2050     7.2807647287845612e-02
    z[7,8,6]  R2051     -3.8419792056083679e-01
    z[7,8,6]  R2052     -2.8833723068237305e-01
    z[7,8,6]  R2053     -2.2672960162162781e-01
    z[7,8,6]  R2054     5.2644795179367065e-01
    z[7,8,6]  R2055     -3.2018184661865234e-01
    z[7,8,6]  R2056     -1.7275755107402802e-01
    z[7,8,6]  R2057     2.3491667211055756e-01
    z[7,8,6]  R2058     2.8786253929138184e-01
    z[7,8,6]  R2059     0.0482945442199707
    z[7,8,6]  R2060     -4.1684368252754211e-01
    z[7,8,6]  R2061     -2.6613765954971313e-01
    z[7,8,6]  R2062     -4.2893379926681519e-01
    z[7,8,6]  R2063     -2.9815217852592468e-01
    z[7,8,6]  R2064     5.0212317705154419e-01
    z[7,8,6]  R2065     3.9354014396667480e-01
    z[7,8,6]  R2066     9.1656424105167389e-02
    z[7,8,6]  R2067     -2.4070023000240326e-01
    z[7,8,6]  R2068     -0.325311541557312
    z[7,8,6]  R2069     -2.5049161911010742e-01
    z[7,8,6]  R2070     4.4305855035781860e-01
    z[7,8,6]  R2071     -3.9032322168350220e-01
    z[7,8,6]  R2072     2.7816012501716614e-01
    z[7,8,6]  R2073     2.6311546564102173e-01
    z[7,8,6]  R2074     -1.1615970730781555e-01
    z[7,8,6]  R2075     2.7570804953575134e-01
    z[7,8,6]  R2076     -1.5641090273857117e-01
    z[7,8,6]  R2077     -1.8282571434974670e-01
    z[7,8,6]  R2078     -3.7996169924736023e-01
    z[7,8,6]  R2079     4.2082633823156357e-02
    z[7,8,6]  R2080     2.8814616799354553e-01
    z[7,8,6]  R2081     3.2460793852806091e-02
    z[7,8,6]  R2082     2.6251126546412706e-03
    z[7,8,6]  R2083     2.4456915259361267e-01
    z[7,8,6]  R2084     1.1607024818658829e-01
    z[7,8,6]  R2085     -4.3984800577163696e-01
    z[7,8,6]  R2086     5.9148907661437988e-02
    z[7,8,6]  R2087     2.5324997305870056e-01
    z[7,8,6]  R2088     -3.0960096046328545e-02
    z[7,8,6]  R2089     -3.7550774216651917e-01
    z[7,8,6]  R2090     -3.1864714622497559e-01
    z[7,8,6]  R2091     -7.7630870044231415e-02
    z[7,8,6]  R2092     1.1627739667892456e-01
    z[7,8,6]  R2093     3.2463806867599487e-01
    z[7,8,6]  R2094     6.4279779791831970e-02
    z[7,8,6]  R2095     -5.8681093156337738e-02
    z[7,8,6]  R2096     3.7266245484352112e-01
    z[7,8,6]  R2097     2.5364753603935242e-01
    z[7,8,6]  R2098     -2.3666703701019287e-01
    z[7,8,6]  R2099     5.1761954091489315e-04
    z[7,8,6]  R2100     -2.3464260995388031e-01
    z[7,8,6]  R2101     2.6170909404754639e-03
    z[7,8,6]  R2102     -4.1718250513076782e-01
    z[7,8,6]  R2103     -2.9475545883178711e-01
    z[7,8,6]  R2104     -7.0257700979709625e-02
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2105     -1
    z[8,7,0]  R2106     1
    z[8,7,0]  R2119     -2.8226274251937866e-01
    z[8,7,0]  R2120     -7.7986550331115723e-01
    z[8,7,0]  R2121     -5.6133443117141724e-01
    z[8,7,0]  R2122     -1.8987755477428436e-01
    z[8,7,0]  R2123     -2.2425100207328796e-01
    z[8,7,0]  R2124     -3.7275391817092896e-01
    z[8,7,0]  R2125     -1.4958010986447334e-02
    z[8,7,0]  R2126     -1.2382146716117859e-01
    z[8,7,0]  R2127     8.7856575846672058e-02
    z[8,7,0]  R2128     1.6627542674541473e-01
    z[8,7,0]  R2129     0.0994608923792839
    z[8,7,0]  R2130     5.5766079574823380e-02
    z[8,7,0]  R2131     -7.3843546211719513e-02
    z[8,7,0]  R2132     0.276685506105423
    z[8,7,0]  R2133     -1.0525304824113846e-02
    z[8,7,0]  R2134     1.7087580263614655e-01
    z[8,7,0]  R2135     -1.3269034028053284e-01
    z[8,7,0]  R2136     -6.3597828149795532e-02
    z[8,7,0]  R2137     1.3340190052986145e-01
    z[8,7,0]  R2138     1.7978912591934204e-01
    z[8,7,0]  R2139     7.2384142875671387e-01
    z[8,7,0]  R2140     6.6835331916809082e-01
    z[8,7,0]  R2141     7.7100640535354614e-01
    z[8,7,0]  R2142     7.0901614427566528e-01
    z[8,7,0]  R2143     2.1059218049049377e-01
    z[8,7,0]  R2144     -2.6733953505754471e-02
    z[8,7,0]  R2145     5.6849938631057739e-01
    z[8,7,0]  R2146     0.751060426235199
    z[8,7,0]  R2147     5.5167865753173828e-01
    z[8,7,0]  R2148     6.1072719097137451e-01
    z[8,7,0]  R2149     1.4569234848022461e-01
    z[8,7,0]  R2150     -0.189011350274086
    z[8,7,0]  R2151     1.0889729112386703e-01
    z[8,7,0]  R2152     -1.1854165792465210e-01
    z[8,7,0]  R2153     1.2387714534997940e-01
    z[8,7,0]  R2154     -9.2916369438171387e-02
    z[8,7,0]  R2155     -4.9124038219451904e-01
    z[8,7,0]  R2156     -5.3309446573257446e-01
    z[8,7,0]  R2157     -3.5195019841194153e-01
    z[8,7,0]  R2158     3.8438871502876282e-01
    z[8,7,0]  R2159     1.7925992608070374e-01
    z[8,7,0]  R2160     7.7746921777725220e-01
    z[8,7,0]  R2161     7.6034718751907349e-01
    z[8,7,0]  R2162     0.081568144261837
    z[8,7,0]  R2163     -2.9130074381828308e-01
    z[8,7,0]  R2164     7.2642546892166138e-01
    z[8,7,0]  R2165     7.1067118644714355e-01
    z[8,7,0]  R2166     -1.2803460471332073e-02
    z[8,7,0]  R2167     7.5687915086746216e-01
    z[8,7,0]  R2168     3.9250746369361877e-01
    z[8,7,0]  R2169     2.2239652276039124e-01
    z[8,7,0]  R2170     9.9800862371921539e-02
    z[8,7,0]  R2171     3.7790974974632263e-01
    z[8,7,0]  R2172     0.721330463886261
    z[8,7,0]  R2173     8.7671202421188354e-01
    z[8,7,0]  R2174     6.8902516365051270e-01
    z[8,7,0]  R2175     7.7704823017120361e-01
    z[8,7,0]  R2176     -1.8984349071979523e-01
    z[8,7,0]  R2177     0.637488603591919
    z[8,7,0]  R2178     5.9059524536132812e-01
    z[8,7,0]  R2179     5.8321809768676758e-01
    z[8,7,0]  R2180     6.9958710670471191e-01
    z[8,7,0]  R2181     1.7745713889598846e-01
    z[8,7,0]  R2182     -2.7724722027778625e-01
    z[8,7,0]  R2183     -5.8270114660263062e-01
    z[8,7,0]  R2184     -3.3282798528671265e-01
    z[8,7,0]  R2185     -1.6312380135059357e-01
    z[8,7,0]  R2186     -2.3580288887023926e-01
    z[8,7,0]  R2187     7.6551836729049683e-01
    z[8,7,0]  R2188     -4.8537963628768921e-01
    z[8,7,0]  R2189     2.0472145080566406e-01
    z[8,7,0]  R2190     6.8301928043365479e-01
    z[8,7,0]  R2191     8.0555105209350586e-01
    z[8,7,0]  R2192     -0.315387487411499
    z[8,7,0]  R2193     -3.9320096373558044e-01
    z[8,7,0]  R2194     -3.5275191068649292e-01
    z[8,7,0]  R2195     6.3006573915481567e-01
    z[8,7,0]  R2196     -2.8680721297860146e-02
    z[8,7,0]  R2197     3.0212867259979248e-01
    z[8,7,0]  R2198     -4.5551683753728867e-02
    z[8,7,0]  R2199     9.1342061758041382e-01
    z[8,7,0]  R2200     -4.6857488155364990e-01
    z[8,7,0]  R2201     -3.4039369225502014e-01
    z[8,7,0]  R2202     6.9425010681152344e-01
    z[8,7,0]  R2203     0.0693756490945816
    z[8,7,0]  R2204     -5.3943157196044922e-01
    z[8,7,0]  R2205     -6.2931698560714722e-01
    z[8,7,0]  R2206     -5.9819233417510986e-01
    z[8,7,0]  R2207     2.9400706291198730e-01
    z[8,7,0]  R2208     2.5269946455955505e-01
    z[8,7,0]  R2209     -6.0311275720596313e-01
    z[8,7,0]  R2210     -4.1975772380828857e-01
    z[8,7,0]  R2211     -3.1643310189247131e-01
    z[8,7,0]  R2212     -7.3209822177886963e-01
    z[8,7,0]  R2213     -3.8009262084960938e-01
    z[8,7,0]  R2214     -5.7497209310531616e-01
    z[8,7,0]  R2215     -5.8650773763656616e-01
    z[8,7,0]  R2216     -2.9185107350349426e-01
    z[8,7,0]  R2217     8.0453574657440186e-02
    z[8,7,0]  R2218     9.2267148196697235e-02
    z[8,7,0]  R2219     5.6734681129455566e-01
    z[8,7,0]  R2220     2.2795991599559784e-01
    z[8,7,0]  R2221     1.9536599516868591e-01
    z[8,7,0]  R2222     3.6459165811538696e-01
    z[8,7,0]  R2223     4.6201157569885254e-01
    z[8,7,0]  R2224     1.5664654970169067e-01
    z[8,7,0]  R2225     2.9601752758026123e-01
    z[8,7,0]  R2226     3.2193651795387268e-01
    z[8,7,0]  R2227     1.2798857688903809e-01
    z[8,7,0]  R2228     -4.2925652116537094e-02
    z[8,7,0]  R2229     -7.6961651444435120e-02
    z[8,7,0]  R2230     -5.2419453859329224e-03
    z[8,7,0]  R2231     7.5517058372497559e-01
    z[8,7,0]  R2232     7.0789128541946411e-01
    z[8,7,0]  R2233     5.7917181402444839e-02
    z[8,7,0]  R2234     2.1695601940155029e-01
    z[8,7,0]  R2235     5.8190357685089111e-01
    z[8,7,0]  R2236     5.3303050994873047e-01
    z[8,7,0]  R2237     3.0288097262382507e-01
    z[8,7,0]  R2238     3.5710540413856506e-01
    z[8,7,0]  R2239     2.0632442831993103e-01
    z[8,7,0]  R2240     2.3541665077209473e-01
    z[8,7,0]  R2241     -1.2956586666405201e-02
    z[8,7,0]  R2242     -8.2483284175395966e-02
    z[8,7,0]  R2243     1.7666345834732056e-01
    z[8,7,0]  R2244     4.5829281210899353e-02
    z[8,7,0]  R2245     -2.0481142401695251e-01
    z[8,7,0]  R2246     4.0946954488754272e-01
    z[8,7,0]  R2247     -9.0658646076917648e-03
    z[8,7,0]  R2248     1.1737505905330181e-02
    z[8,7,0]  R2249     -7.6344244182109833e-02
    z[8,7,0]  R2250     -2.6834377646446228e-01
    z[8,7,0]  R2251     1.8595089018344879e-01
    z[8,7,0]  R2252     2.3791874945163727e-01
    z[8,7,0]  R2253     1.1654905974864960e-01
    z[8,7,0]  R2254     -1.1005988717079163e-01
    z[8,7,0]  R2255     6.6533386707305908e-02
    z[8,7,0]  R2256     1.3699270784854889e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2107     -1
    z[8,7,1]  R2108     1
    z[8,7,1]  R2119     -7.9524271190166473e-02
    z[8,7,1]  R2120     4.3006721138954163e-01
    z[8,7,1]  R2121     6.0038244724273682e-01
    z[8,7,1]  R2122     -0.348158061504364
    z[8,7,1]  R2123     6.6742175817489624e-01
    z[8,7,1]  R2124     5.6951224803924561e-01
    z[8,7,1]  R2125     -2.0942346751689911e-01
    z[8,7,1]  R2126     6.8685054779052734e-01
    z[8,7,1]  R2127     7.2288900613784790e-01
    z[8,7,1]  R2128     3.2047115266323090e-02
    z[8,7,1]  R2129     -2.7143087983131409e-01
    z[8,7,1]  R2130     -7.5525051355361938e-01
    z[8,7,1]  R2131     -6.9330054521560669e-01
    z[8,7,1]  R2132     -5.9834969043731689e-01
    z[8,7,1]  R2133     -5.3521466255187988e-01
    z[8,7,1]  R2134     -6.4924311637878418e-01
    z[8,7,1]  R2135     -7.2761493921279907e-01
    z[8,7,1]  R2136     -6.3145416975021362e-01
    z[8,7,1]  R2137     -4.4217732548713684e-01
    z[8,7,1]  R2138     0.265844464302063
    z[8,7,1]  R2139     5.5007302761077881e-01
    z[8,7,1]  R2140     5.3940200805664062e-01
    z[8,7,1]  R2141     1.4655441045761108e-01
    z[8,7,1]  R2142     2.4297359585762024e-01
    z[8,7,1]  R2143     -5.6602823734283447e-01
    z[8,7,1]  R2144     -1.7171211540699005e-01
    z[8,7,1]  R2145     6.2469226121902466e-01
    z[8,7,1]  R2146     1.5787769854068756e-01
    z[8,7,1]  R2147     6.5057468414306641e-01
    z[8,7,1]  R2148     3.6385115981101990e-01
    z[8,7,1]  R2149     1.4839459955692291e-01
    z[8,7,1]  R2150     4.5483246445655823e-01
    z[8,7,1]  R2151     -5.0865131616592407e-01
    z[8,7,1]  R2152     5.2377808094024658e-01
    z[8,7,1]  R2153     -5.3239434957504272e-01
    z[8,7,1]  R2154     5.6583970785140991e-01
    z[8,7,1]  R2155     4.6969932317733765e-01
    z[8,7,1]  R2156     3.6401736736297607e-01
    z[8,7,1]  R2157     7.7508658170700073e-02
    z[8,7,1]  R2158     -3.5676285624504089e-01
    z[8,7,1]  R2159     -4.3701842427253723e-02
    z[8,7,1]  R2160     2.4696822464466095e-01
    z[8,7,1]  R2161     2.7257981896400452e-01
    z[8,7,1]  R2162     -4.9792066216468811e-01
    z[8,7,1]  R2163     -3.2171663641929626e-01
    z[8,7,1]  R2164     2.5877881050109863e-01
    z[8,7,1]  R2165     4.9964633584022522e-01
    z[8,7,1]  R2166     -6.1221045255661011e-01
    z[8,7,1]  R2167     9.7677908837795258e-02
    z[8,7,1]  R2168     -5.5611205101013184e-01
    z[8,7,1]  R2169     0.0494234636425972
    z[8,7,1]  R2170     4.4642563909292221e-02
    z[8,7,1]  R2171     -1.4130115509033203e-01
    z[8,7,1]  R2172     0.358583003282547
    z[8,7,1]  R2173     -6.3015684485435486e-02
    z[8,7,1]  R2174     5.0175529718399048e-01
    z[8,7,1]  R2175     1.2697845697402954e-01
    z[8,7,1]  R2176     -2.1848936378955841e-01
    z[8,7,1]  R2177     3.7984037399291992e-01
    z[8,7,1]  R2178     5.0106209516525269e-01
    z[8,7,1]  R2179     0.666954517364502
    z[8,7,1]  R2180     4.7370767593383789e-01
    z[8,7,1]  R2181     4.9215254187583923e-01
    z[8,7,1]  R2182     3.5664218664169312e-01
    z[8,7,1]  R2183     0.0708300992846489
    z[8,7,1]  R2184     4.5316481590270996e-01
    z[8,7,1]  R2185     7.7104771137237549e-01
    z[8,7,1]  R2186     -7.5780582427978516e-01
    z[8,7,1]  R2187     -8.0938935279846191e-02
    z[8,7,1]  R2188     5.2663671970367432e-01
    z[8,7,1]  R2189     -3.8568067550659180e-01
    z[8,7,1]  R2190     4.6776360273361206e-01
    z[8,7,1]  R2191     2.4367228150367737e-01
    z[8,7,1]  R2192     5.9032875299453735e-01
    z[8,7,1]  R2193     0.531501054763794
    z[8,7,1]  R2194     4.0920135378837585e-01
    z[8,7,1]  R2195     1.8107984960079193e-01
    z[8,7,1]  R2196     -9.1409909725189209e-01
    z[8,7,1]  R2197     -3.5409516096115112e-01
    z[8,7,1]  R2198     -4.3090045452117920e-01
    z[8,7,1]  R2199     1.8716056644916534e-01
    z[8,7,1]  R2200     4.5817929506301880e-01
    z[8,7,1]  R2201     7.3749041557312012e-01
    z[8,7,1]  R2202     2.9498317837715149e-01
    z[8,7,1]  R2203     4.2501375079154968e-01
    z[8,7,1]  R2204     2.7181729674339294e-01
    z[8,7,1]  R2205     4.2410823702812195e-01
    z[8,7,1]  R2206     -1.9883349537849426e-02
    z[8,7,1]  R2207     -3.0261763930320740e-01
    z[8,7,1]  R2208     -7.1180623769760132e-01
    z[8,7,1]  R2209     1.6140025854110718e-01
    z[8,7,1]  R2210     4.5965674519538879e-01
    z[8,7,1]  R2211     -7.6316393911838531e-02
    z[8,7,1]  R2212     -2.3349776864051819e-01
    z[8,7,1]  R2213     1.9021511077880859e-01
    z[8,7,1]  R2214     -2.9934826493263245e-01
    z[8,7,1]  R2215     -9.7319453954696655e-02
    z[8,7,1]  R2216     -7.7453780174255371e-01
    z[8,7,1]  R2217     -9.0730965137481689e-01
    z[8,7,1]  R2218     -6.3884317874908447e-01
    z[8,7,1]  R2219     4.2621025443077087e-01
    z[8,7,1]  R2220     3.0166879296302795e-01
    z[8,7,1]  R2221     0.0885414183139801
    z[8,7,1]  R2222     1.8170714378356934e-01
    z[8,7,1]  R2223     6.4333818852901459e-02
    z[8,7,1]  R2224     3.0959376692771912e-01
    z[8,7,1]  R2225     1.5628987550735474e-01
    z[8,7,1]  R2226     1.6214667260646820e-01
    z[8,7,1]  R2227     6.6457551717758179e-01
    z[8,7,1]  R2228     0.821221113204956
    z[8,7,1]  R2229     -4.9151638150215149e-01
    z[8,7,1]  R2230     -3.7890347838401794e-01
    z[8,7,1]  R2231     2.1322643756866455e-01
    z[8,7,1]  R2232     2.4058306217193604e-01
    z[8,7,1]  R2233     -2.1792949736118317e-01
    z[8,7,1]  R2234     -2.5230693817138672e-01
    z[8,7,1]  R2235     2.8330886363983154e-01
    z[8,7,1]  R2236     4.7625762224197388e-01
    z[8,7,1]  R2237     9.5401480793952942e-02
    z[8,7,1]  R2238     1.6792092472314835e-02
    z[8,7,1]  R2239     -3.6612647771835327e-01
    z[8,7,1]  R2240     -0.584315836429596
    z[8,7,1]  R2241     -3.1234717369079590e-01
    z[8,7,1]  R2242     -6.9596379995346069e-01
    z[8,7,1]  R2243     0.572786271572113
    z[8,7,1]  R2244     -6.2916569411754608e-02
    z[8,7,1]  R2245     -2.0866429805755615e-01
    z[8,7,1]  R2246     -5.1932379603385925e-02
    z[8,7,1]  R2247     6.7793554067611694e-01
    z[8,7,1]  R2248     8.4547185897827148e-01
    z[8,7,1]  R2249     -0.654776394367218
    z[8,7,1]  R2250     -5.0122487545013428e-01
    z[8,7,1]  R2251     -0.17464579641819
    z[8,7,1]  R2252     8.6933094263076782e-01
    z[8,7,1]  R2253     8.5908889770507812e-01
    z[8,7,1]  R2254     8.3578372001647949e-01
    z[8,7,1]  R2255     8.0418592691421509e-01
    z[8,7,1]  R2256     7.8154599666595459e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2109     -1
    z[8,7,2]  R2110     1
    z[8,7,2]  R2119     -1.4506091177463531e-01
    z[8,7,2]  R2120     -4.0828222036361694e-01
    z[8,7,2]  R2121     -1.3990265130996704e-01
    z[8,7,2]  R2122     1.5811876952648163e-01
    z[8,7,2]  R2123     -6.6476821899414062e-01
    z[8,7,2]  R2124     -5.1513093709945679e-01
    z[8,7,2]  R2125     5.6466543674468994e-01
    z[8,7,2]  R2126     -2.7045628428459167e-01
    z[8,7,2]  R2127     -6.0067063570022583e-01
    z[8,7,2]  R2128     4.9722400307655334e-01
    z[8,7,2]  R2129     -9.8033733665943146e-03
    z[8,7,2]  R2130     4.5843723416328430e-01
    z[8,7,2]  R2131     4.7923445701599121e-01
    z[8,7,2]  R2132     5.4851877689361572e-01
    z[8,7,2]  R2133     3.9394792914390564e-01
    z[8,7,2]  R2134     4.8835653066635132e-01
    z[8,7,2]  R2135     3.5637223720550537e-01
    z[8,7,2]  R2136     5.6142389774322510e-01
    z[8,7,2]  R2137     5.4904019832611084e-01
    z[8,7,2]  R2138     -2.3786285519599915e-01
    z[8,7,2]  R2139     0.0487288273870945
    z[8,7,2]  R2140     -2.6154069229960442e-02
    z[8,7,2]  R2141     4.2261460423469543e-01
    z[8,7,2]  R2142     4.2749884724617004e-01
    z[8,7,2]  R2143     3.4843704104423523e-01
    z[8,7,2]  R2144     1.8114510178565979e-01
    z[8,7,2]  R2145     3.1396117061376572e-02
    z[8,7,2]  R2146     -3.8140231370925903e-01
    z[8,7,2]  R2147     -1.4456406235694885e-01
    z[8,7,2]  R2148     -4.6017771959304810e-01
    z[8,7,2]  R2149     4.1910163126885891e-03
    z[8,7,2]  R2150     -6.4679676294326782e-01
    z[8,7,2]  R2151     -2.4103774130344391e-01
    z[8,7,2]  R2152     -2.5775903463363647e-01
    z[8,7,2]  R2153     -4.9242994189262390e-01
    z[8,7,2]  R2154     -5.4433572292327881e-01
    z[8,7,2]  R2155     -1.7263974249362946e-01
    z[8,7,2]  R2156     -2.8131538629531860e-01
    z[8,7,2]  R2157     -5.9280896186828613e-01
    z[8,7,2]  R2158     3.9855021238327026e-01
    z[8,7,2]  R2159     -2.3835518956184387e-01
    z[8,7,2]  R2160     -3.8933902978897095e-01
    z[8,7,2]  R2161     1.4332948625087738e-01
    z[8,7,2]  R2162     -5.1626789569854736e-01
    z[8,7,2]  R2163     5.0522979348897934e-02
    z[8,7,2]  R2164     -5.4258454591035843e-02
    z[8,7,2]  R2165     -3.3366364240646362e-01
    z[8,7,2]  R2166     2.1466314792633057e-02
    z[8,7,2]  R2167     1.4715506136417389e-01
    z[8,7,2]  R2168     -4.2111596465110779e-01
    z[8,7,2]  R2169     2.6426786184310913e-01
    z[8,7,2]  R2170     4.9070903658866882e-01
    z[8,7,2]  R2171     2.7465194463729858e-01
    z[8,7,2]  R2172     1.6144557297229767e-01
    z[8,7,2]  R2173     1.0726875066757202e-01
    z[8,7,2]  R2174     9.6196554601192474e-02
    z[8,7,2]  R2175     -1.9534166157245636e-01
    z[8,7,2]  R2176     6.4866676926612854e-02
    z[8,7,2]  R2177     1.0155776888132095e-01
    z[8,7,2]  R2178     -3.3164986968040466e-01
    z[8,7,2]  R2179     -2.1577699109911919e-02
    z[8,7,2]  R2180     -4.0542903542518616e-01
    z[8,7,2]  R2181     -5.8782523870468140e-01
    z[8,7,2]  R2182     -6.2577402591705322e-01
    z[8,7,2]  R2183     -3.5352534055709839e-01
    z[8,7,2]  R2184     -4.1959038376808167e-01
    z[8,7,2]  R2185     -3.8010302186012268e-01
    z[8,7,2]  R2186     5.4346317052841187e-01
    z[8,7,2]  R2187     2.2473068535327911e-01
    z[8,7,2]  R2188     -0.0822916328907013
    z[8,7,2]  R2189     -2.4013957008719444e-03
    z[8,7,2]  R2190     0.181917205452919
    z[8,7,2]  R2191     0.0684681311249733
    z[8,7,2]  R2192     -6.6954821348190308e-01
    z[8,7,2]  R2193     -5.5514967441558838e-01
    z[8,7,2]  R2194     -7.1552932262420654e-01
    z[8,7,2]  R2195     9.0828202664852142e-02
    z[8,7,2]  R2196     2.6896980404853821e-01
    z[8,7,2]  R2197     6.1077654361724854e-01
    z[8,7,2]  R2198     6.1808902770280838e-02
    z[8,7,2]  R2199     1.2700352072715759e-01
    z[8,7,2]  R2200     -3.4459051489830017e-01
    z[8,7,2]  R2201     -4.1717949509620667e-01
    z[8,7,2]  R2202     -4.3970888853073120e-01
    z[8,7,2]  R2203     -6.7316633462905884e-01
    z[8,7,2]  R2204     -6.3947242498397827e-01
    z[8,7,2]  R2205     -1.5409936010837555e-01
    z[8,7,2]  R2206     -6.5547204017639160e-01
    z[8,7,2]  R2207     -3.3076709508895874e-01
    z[8,7,2]  R2208     3.5841265320777893e-01
    z[8,7,2]  R2209     -4.5959183573722839e-01
    z[8,7,2]  R2210     -5.5117529630661011e-01
    z[8,7,2]  R2211     -3.2845515012741089e-01
    z[8,7,2]  R2212     -3.6801773309707642e-01
    z[8,7,2]  R2213     -2.8529864549636841e-01
    z[8,7,2]  R2214     -6.0903424024581909e-01
    z[8,7,2]  R2215     -1.9481046497821808e-01
    z[8,7,2]  R2216     -4.1978725790977478e-01
    z[8,7,2]  R2217     1.0509595274925232e-01
    z[8,7,2]  R2218     -6.8624660372734070e-02
    z[8,7,2]  R2219     0.410971999168396
    z[8,7,2]  R2220     5.5042487382888794e-01
    z[8,7,2]  R2221     6.3688921928405762e-01
    z[8,7,2]  R2222     -2.5539478287100792e-02
    z[8,7,2]  R2223     4.0504077076911926e-01
    z[8,7,2]  R2224     5.6090480089187622e-01
    z[8,7,2]  R2225     -3.9990995079278946e-02
    z[8,7,2]  R2226     4.5544752478599548e-01
    z[8,7,2]  R2227     1.4628442004323006e-02
    z[8,7,2]  R2228     3.9811581373214722e-01
    z[8,7,2]  R2229     -3.3156388998031616e-01
    z[8,7,2]  R2230     2.9727813601493835e-01
    z[8,7,2]  R2231     1.2578035891056061e-01
    z[8,7,2]  R2232     3.0262774229049683e-01
    z[8,7,2]  R2233     0.33199542760849
    z[8,7,2]  R2234     5.3181892633438110e-01
    z[8,7,2]  R2235     -3.3132388489320874e-04
    z[8,7,2]  R2236     -6.4216554164886475e-01
    z[8,7,2]  R2237     5.5402827262878418e-01
    z[8,7,2]  R2238     2.6416417956352234e-01
    z[8,7,2]  R2239     1.7065095901489258e-01
    z[8,7,2]  R2240     3.1260296702384949e-01
    z[8,7,2]  R2241     1.3980729877948761e-01
    z[8,7,2]  R2242     3.1571972370147705e-01
    z[8,7,2]  R2243     0.355589896440506
    z[8,7,2]  R2244     -2.6504507660865784e-01
    z[8,7,2]  R2245     -2.8752166777849197e-02
    z[8,7,2]  R2246     6.4543402194976807e-01
    z[8,7,2]  R2247     -3.2898673415184021e-01
    z[8,7,2]  R2248     1.8935500085353851e-01
    z[8,7,2]  R2249     2.4685647338628769e-02
    z[8,7,2]  R2250     -2.0121857523918152e-01
    z[8,7,2]  R2251     -2.0923744142055511e-01
    z[8,7,2]  R2252     2.1507760882377625e-01
    z[8,7,2]  R2253     3.6545589566230774e-01
    z[8,7,2]  R2254     4.1203314065933228e-01
    z[8,7,2]  R2255     3.1193997710943222e-02
    z[8,7,2]  R2256     1.7944779992103577e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2111     -1
    z[8,7,3]  R2112     1
    z[8,7,3]  R2119     6.3471293449401855e-01
    z[8,7,3]  R2120     3.7169404327869415e-02
    z[8,7,3]  R2121     1.5428406186401844e-02
    z[8,7,3]  R2122     4.8135069012641907e-01
    z[8,7,3]  R2123     8.5634356364607811e-03
    z[8,7,3]  R2124     4.9765971302986145e-01
    z[8,7,3]  R2125     4.4825062155723572e-01
    z[8,7,3]  R2126     4.4120573997497559e-01
    z[8,7,3]  R2127     9.6951022744178772e-02
    z[8,7,3]  R2128     6.3274890184402466e-01
    z[8,7,3]  R2129     7.6028275489807129e-01
    z[8,7,3]  R2130     -3.6877706646919250e-02
    z[8,7,3]  R2131     -2.1236577630043030e-01
    z[8,7,3]  R2132     -2.8400555253028870e-01
    z[8,7,3]  R2133     -3.2647213339805603e-01
    z[8,7,3]  R2134     -3.6428447812795639e-02
    z[8,7,3]  R2135     -3.6264741420745850e-01
    z[8,7,3]  R2136     -4.7265359759330750e-01
    z[8,7,3]  R2137     -4.7184243798255920e-01
    z[8,7,3]  R2138     4.5467212796211243e-01
    z[8,7,3]  R2139     -7.5866356492042542e-02
    z[8,7,3]  R2140     1.8623191118240356e-01
    z[8,7,3]  R2141     -1.4141495525836945e-01
    z[8,7,3]  R2142     3.2630637288093567e-01
    z[8,7,3]  R2143     1.7457969486713409e-01
    z[8,7,3]  R2144     5.9118086099624634e-01
    z[8,7,3]  R2145     3.7921655178070068e-01
    z[8,7,3]  R2146     -7.4865147471427917e-02
    z[8,7,3]  R2147     4.3815410137176514e-01
    z[8,7,3]  R2148     1.6231262683868408e-01
    z[8,7,3]  R2149     7.2276329994201660e-01
    z[8,7,3]  R2150     -3.9736565947532654e-01
    z[8,7,3]  R2151     3.7152585387229919e-01
    z[8,7,3]  R2152     5.5104327201843262e-01
    z[8,7,3]  R2153     3.4945863485336304e-01
    z[8,7,3]  R2154     -1.7210496589541435e-02
    z[8,7,3]  R2155     4.3477201461791992e-01
    z[8,7,3]  R2156     8.3079628646373749e-02
    z[8,7,3]  R2157     7.0735722780227661e-02
    z[8,7,3]  R2158     8.2067184150218964e-02
    z[8,7,3]  R2159     3.2217529416084290e-01
    z[8,7,3]  R2160     -2.6893955469131470e-01
    z[8,7,3]  R2161     -1.4151706127449870e-03
    z[8,7,3]  R2162     3.4386447072029114e-01
    z[8,7,3]  R2163     8.5708731412887573e-01
    z[8,7,3]  R2164     2.5729832053184509e-01
    z[8,7,3]  R2165     2.5699369609355927e-02
    z[8,7,3]  R2166     0.627197265625
    z[8,7,3]  R2167     4.7050496935844421e-01
    z[8,7,3]  R2168     1.7863745987415314e-01
    z[8,7,3]  R2169     4.8613610863685608e-01
    z[8,7,3]  R2170     7.9316431283950806e-01
    z[8,7,3]  R2171     7.6619559526443481e-01
    z[8,7,3]  R2172     -4.2995044589042664e-01
    z[8,7,3]  R2173     3.6229613423347473e-01
    z[8,7,3]  R2174     -1.9225323200225830e-01
    z[8,7,3]  R2175     1.5171775221824646e-01
    z[8,7,3]  R2176     0.892119824886322
    z[8,7,3]  R2177     -4.1772323846817017e-01
    z[8,7,3]  R2178     3.9665955305099487e-01
    z[8,7,3]  R2179     -3.1335288076661527e-04
    z[8,7,3]  R2180     1.2308204174041748e-01
    z[8,7,3]  R2181     3.3044064044952393e-01
    z[8,7,3]  R2182     3.1732434034347534e-01
    z[8,7,3]  R2183     -6.2446214258670807e-02
    z[8,7,3]  R2184     -0.0313868410885334
    z[8,7,3]  R2185     -6.0916036367416382e-02
    z[8,7,3]  R2186     1.9142033159732819e-01
    z[8,7,3]  R2187     4.7483634203672409e-02
    z[8,7,3]  R2188     1.1565615981817245e-01
    z[8,7,3]  R2189     4.1282907128334045e-01
    z[8,7,3]  R2190     5.0725466012954712e-01
    z[8,7,3]  R2191     1.5332493185997009e-01
    z[8,7,3]  R2192     -1.2244151532649994e-01
    z[8,7,3]  R2193     1.3098880648612976e-01
    z[8,7,3]  R2194     2.2630952298641205e-01
    z[8,7,3]  R2195     -4.9962222576141357e-01
    z[8,7,3]  R2196     -1.8756206333637238e-01
    z[8,7,3]  R2197     1.8390727043151855e-01
    z[8,7,3]  R2198     5.0447350740432739e-01
    z[8,7,3]  R2199     -2.1160425245761871e-01
    z[8,7,3]  R2200     -3.9655330777168274e-01
    z[8,7,3]  R2201     6.8886585533618927e-02
    z[8,7,3]  R2202     1.8579009175300598e-01
    z[8,7,3]  R2203     7.5899370014667511e-02
    z[8,7,3]  R2204     2.8333681821823120e-01
    z[8,7,3]  R2205     3.2837271690368652e-01
    z[8,7,3]  R2206     -9.9064677953720093e-02
    z[8,7,3]  R2207     2.5260293483734131e-01
    z[8,7,3]  R2208     2.0337322354316711e-01
    z[8,7,3]  R2209     5.3412193059921265e-01
    z[8,7,3]  R2210     3.5509994626045227e-01
    z[8,7,3]  R2211     5.6234270334243774e-01
    z[8,7,3]  R2212     1.8797422945499420e-01
    z[8,7,3]  R2213     4.3108406662940979e-01
    z[8,7,3]  R2214     2.6964026689529419e-01
    z[8,7,3]  R2215     5.5359804630279541e-01
    z[8,7,3]  R2216     -2.1320657432079315e-01
    z[8,7,3]  R2217     -0.266482949256897
    z[8,7,3]  R2218     -2.5109395384788513e-02
    z[8,7,3]  R2219     6.1683785170316696e-02
    z[8,7,3]  R2220     5.4878854751586914e-01
    z[8,7,3]  R2221     5.7285404205322266e-01
    z[8,7,3]  R2222     -6.4620566368103027e-01
    z[8,7,3]  R2223     2.9126688838005066e-01
    z[8,7,3]  R2224     5.6145054101943970e-01
    z[8,7,3]  R2225     -5.1702308654785156e-01
    z[8,7,3]  R2226     -2.6268932223320007e-01
    z[8,7,3]  R2227     7.1090564131736755e-02
    z[8,7,3]  R2228     -1.5342529118061066e-01
    z[8,7,3]  R2229     -5.6785982847213745e-01
    z[8,7,3]  R2230     -2.7150332927703857e-01
    z[8,7,3]  R2231     5.8796745538711548e-01
    z[8,7,3]  R2232     3.0893996357917786e-01
    z[8,7,3]  R2233     -4.6980452537536621e-01
    z[8,7,3]  R2234     -0.427613228559494
    z[8,7,3]  R2235     -1.9598762691020966e-01
    z[8,7,3]  R2236     -1.6931539773941040e-01
    z[8,7,3]  R2237     3.8242614269256592e-01
    z[8,7,3]  R2238     -8.3257377147674561e-01
    z[8,7,3]  R2239     -0.640066921710968
    z[8,7,3]  R2240     -4.0373942255973816e-01
    z[8,7,3]  R2241     -5.1015150547027588e-01
    z[8,7,3]  R2242     4.0715858340263367e-01
    z[8,7,3]  R2243     0.630540668964386
    z[8,7,3]  R2244     -8.7552732229232788e-01
    z[8,7,3]  R2245     -5.7726246118545532e-01
    z[8,7,3]  R2246     5.5400753021240234e-01
    z[8,7,3]  R2247     -1.1411420255899429e-01
    z[8,7,3]  R2248     -3.7139368057250977e-01
    z[8,7,3]  R2249     -4.6015629172325134e-01
    z[8,7,3]  R2250     -5.1192593574523926e-01
    z[8,7,3]  R2251     -7.3500746488571167e-01
    z[8,7,3]  R2252     -3.4131145477294922e-01
    z[8,7,3]  R2253     -2.5124719738960266e-01
    z[8,7,3]  R2254     -3.1104597449302673e-01
    z[8,7,3]  R2255     -4.5039784908294678e-01
    z[8,7,3]  R2256     -2.8034844994544983e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2113     -1
    z[8,7,4]  R2114     1
    z[8,7,4]  R2119     -2.1748287975788116e-01
    z[8,7,4]  R2120     -5.6903768330812454e-02
    z[8,7,4]  R2121     -0.0574452243745327
    z[8,7,4]  R2122     -2.6986968517303467e-01
    z[8,7,4]  R2123     4.9347940832376480e-02
    z[8,7,4]  R2124     1.8177621066570282e-02
    z[8,7,4]  R2125     1.0496149957180023e-01
    z[8,7,4]  R2126     -1.0570524632930756e-01
    z[8,7,4]  R2127     -5.3320780396461487e-02
    z[8,7,4]  R2128     -3.2039427757263184e-01
    z[8,7,4]  R2129     -9.1939605772495270e-02
    z[8,7,4]  R2130     7.3073320090770721e-02
    z[8,7,4]  R2131     3.6314350366592407e-01
    z[8,7,4]  R2132     3.4748658537864685e-01
    z[8,7,4]  R2133     1.0689140111207962e-01
    z[8,7,4]  R2134     2.5803259015083313e-01
    z[8,7,4]  R2135     0.014848074875772
    z[8,7,4]  R2136     6.9001503288745880e-02
    z[8,7,4]  R2137     3.1547278165817261e-01
    z[8,7,4]  R2138     -7.0220857858657837e-01
    z[8,7,4]  R2139     -5.0553835928440094e-02
    z[8,7,4]  R2140     -3.8211759924888611e-01
    z[8,7,4]  R2141     2.9748806357383728e-01
    z[8,7,4]  R2142     3.0938872694969177e-01
    z[8,7,4]  R2143     -2.2808396816253662e-01
    z[8,7,4]  R2144     5.9838145971298218e-01
    z[8,7,4]  R2145     5.1360901445150375e-02
    z[8,7,4]  R2146     -2.9469090700149536e-01
    z[8,7,4]  R2147     6.3740663230419159e-02
    z[8,7,4]  R2148     -5.0611924380064011e-02
    z[8,7,4]  R2149     2.7012842893600464e-01
    z[8,7,4]  R2150     2.4763178080320358e-02
    z[8,7,4]  R2151     -4.5352885127067566e-01
    z[8,7,4]  R2152     -4.9569332599639893e-01
    z[8,7,4]  R2153     -1.3083736598491669e-01
    z[8,7,4]  R2154     -2.7934324741363525e-01
    z[8,7,4]  R2155     -2.4890260398387909e-01
    z[8,7,4]  R2156     4.3951147794723511e-01
    z[8,7,4]  R2157     -5.2005261182785034e-01
    z[8,7,4]  R2158     -5.2744048833847046e-01
    z[8,7,4]  R2159     -1.5415717661380768e-01
    z[8,7,4]  R2160     -2.0392365753650665e-01
    z[8,7,4]  R2161     -1.3303364813327789e-01
    z[8,7,4]  R2162     1.4022152125835419e-01
    z[8,7,4]  R2163     2.6859796047210693e-01
    z[8,7,4]  R2164     0.272236168384552
    z[8,7,4]  R2165     9.5518708229064941e-02
    z[8,7,4]  R2166     5.6548561900854111e-02
    z[8,7,4]  R2167     -2.4783669412136078e-01
    z[8,7,4]  R2168     1.7186237871646881e-01
    z[8,7,4]  R2169     -1.0055442899465561e-01
    z[8,7,4]  R2170     1.6592821478843689e-01
    z[8,7,4]  R2171     -2.9397532343864441e-02
    z[8,7,4]  R2172     4.6979844570159912e-02
    z[8,7,4]  R2173     -1.2716351449489594e-01
    z[8,7,4]  R2174     -4.4760741293430328e-02
    z[8,7,4]  R2175     2.2285891696810722e-02
    z[8,7,4]  R2176     -1.9680918753147125e-01
    z[8,7,4]  R2177     9.7770921885967255e-02
    z[8,7,4]  R2178     -2.7405008673667908e-01
    z[8,7,4]  R2179     1.4631024003028870e-01
    z[8,7,4]  R2180     -1.8064735829830170e-01
    z[8,7,4]  R2181     -3.1060841679573059e-01
    z[8,7,4]  R2182     -1.6298873722553253e-01
    z[8,7,4]  R2183     -2.9918268322944641e-01
    z[8,7,4]  R2184     -3.9690437912940979e-01
    z[8,7,4]  R2185     2.8621044754981995e-01
    z[8,7,4]  R2186     -3.2313957810401917e-02
    z[8,7,4]  R2187     -3.3583962917327881e-01
    z[8,7,4]  R2188     3.2931387424468994e-01
    z[8,7,4]  R2189     -1.1051273345947266e-01
    z[8,7,4]  R2190     1.2172869592905045e-01
    z[8,7,4]  R2191     -3.1887373328208923e-01
    z[8,7,4]  R2192     -1.2618668377399445e-01
    z[8,7,4]  R2193     3.1021785736083984e-01
    z[8,7,4]  R2194     -1.8007430434226990e-01
    z[8,7,4]  R2195     5.1927787065505981e-01
    z[8,7,4]  R2196     -0.198231503367424
    z[8,7,4]  R2197     -4.4913059473037720e-01
    z[8,7,4]  R2198     -7.4144983291625977e-01
    z[8,7,4]  R2199     2.5618669390678406e-01
    z[8,7,4]  R2200     -1.0460326820611954e-01
    z[8,7,4]  R2201     -8.8932946324348450e-02
    z[8,7,4]  R2202     -3.7543994188308716e-01
    z[8,7,4]  R2203     -5.5314081907272339e-01
    z[8,7,4]  R2204     -3.0125668644905090e-01
    z[8,7,4]  R2205     1.9281382858753204e-01
    z[8,7,4]  R2206     -1.4993591606616974e-01
    z[8,7,4]  R2207     6.6682964563369751e-01
    z[8,7,4]  R2208     4.2104795575141907e-01
    z[8,7,4]  R2209     2.2251971065998077e-02
    z[8,7,4]  R2210     -2.3627656698226929e-01
    z[8,7,4]  R2211     -4.4636905193328857e-01
    z[8,7,4]  R2212     8.7686873972415924e-02
    z[8,7,4]  R2213     -7.2892510890960693e-01
    z[8,7,4]  R2214     -2.8721296787261963e-01
    z[8,7,4]  R2215     -3.9025208353996277e-01
    z[8,7,4]  R2216     1.4211065135896206e-02
    z[8,7,4]  R2217     -1.4557726681232452e-01
    z[8,7,4]  R2218     5.5874037742614746e-01
    z[8,7,4]  R2219     1.8388934433460236e-01
    z[8,7,4]  R2220     1.5091983973979950e-01
    z[8,7,4]  R2221     -3.9319179952144623e-02
    z[8,7,4]  R2222     -4.6640940010547638e-02
    z[8,7,4]  R2223     -3.1542456150054932e-01
    z[8,7,4]  R2224     3.7751308083534241e-01
    z[8,7,4]  R2225     6.8618780374526978e-01
    z[8,7,4]  R2226     -4.1213774681091309e-01
    z[8,7,4]  R2227     3.3205825090408325e-01
    z[8,7,4]  R2228     2.5704520940780640e-01
    z[8,7,4]  R2229     0.366986483335495
    z[8,7,4]  R2230     4.7017842531204224e-02
    z[8,7,4]  R2231     -2.4060022085905075e-02
    z[8,7,4]  R2232     -3.1388887763023376e-01
    z[8,7,4]  R2233     4.5337316393852234e-01
    z[8,7,4]  R2234     3.8295388221740723e-01
    z[8,7,4]  R2235     -5.7923948764801025e-01
    z[8,7,4]  R2236     -2.0442249253392220e-02
    z[8,7,4]  R2237     4.6696513891220093e-01
    z[8,7,4]  R2238     4.5723305083811283e-03
    z[8,7,4]  R2239     5.8073186874389648e-01
    z[8,7,4]  R2240     -2.2077956795692444e-01
    z[8,7,4]  R2241     5.2164965867996216e-01
    z[8,7,4]  R2242     3.5395428538322449e-01
    z[8,7,4]  R2243     2.5436949729919434e-01
    z[8,7,4]  R2244     -3.7642422318458557e-01
    z[8,7,4]  R2245     -3.0911937355995178e-01
    z[8,7,4]  R2246     -1.6816121339797974e-01
    z[8,7,4]  R2247     5.3540492057800293e-01
    z[8,7,4]  R2248     1.9686232507228851e-01
    z[8,7,4]  R2249     3.8858780264854431e-01
    z[8,7,4]  R2250     7.1289457380771637e-02
    z[8,7,4]  R2251     -4.0224009752273560e-01
    z[8,7,4]  R2252     1.4052438735961914e-01
    z[8,7,4]  R2253     -1.4828655123710632e-01
    z[8,7,4]  R2254     3.1841620802879333e-02
    z[8,7,4]  R2255     1.7281240224838257e-01
    z[8,7,4]  R2256     2.6056563854217529e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2115     -1
    z[8,7,5]  R2116     1
    z[8,7,5]  R2119     -6.5225899219512939e-01
    z[8,7,5]  R2120     -1.0487017780542374e-01
    z[8,7,5]  R2121     1.6407051682472229e-01
    z[8,7,5]  R2122     -2.5416249036788940e-01
    z[8,7,5]  R2123     8.9542150497436523e-02
    z[8,7,5]  R2124     -1.5008129179477692e-01
    z[8,7,5]  R2125     -4.2632433772087097e-01
    z[8,7,5]  R2126     -4.1950282454490662e-01
    z[8,7,5]  R2127     -3.0137532949447632e-01
    z[8,7,5]  R2128     -4.6895641088485718e-01
    z[8,7,5]  R2129     7.9206518828868866e-02
    z[8,7,5]  R2130     2.2923554480075836e-01
    z[8,7,5]  R2131     -2.7379798889160156e-01
    z[8,7,5]  R2132     -2.3873747885227203e-01
    z[8,7,5]  R2133     -6.5112107992172241e-01
    z[8,7,5]  R2134     -4.5467257499694824e-01
    z[8,7,5]  R2135     -4.2832094430923462e-01
    z[8,7,5]  R2136     -2.2712954878807068e-01
    z[8,7,5]  R2137     -3.4039071202278137e-01
    z[8,7,5]  R2138     3.0946722626686096e-01
    z[8,7,5]  R2139     3.9994516968727112e-01
    z[8,7,5]  R2140     1.6013096272945404e-01
    z[8,7,5]  R2141     1.6711945831775665e-01
    z[8,7,5]  R2142     -2.1236881613731384e-01
    z[8,7,5]  R2143     -0.656708300113678
    z[8,7,5]  R2144     -4.6250590682029724e-01
    z[8,7,5]  R2145     3.4696620702743530e-01
    z[8,7,5]  R2146     -3.6067828536033630e-01
    z[8,7,5]  R2147     -2.3430296778678894e-01
    z[8,7,5]  R2148     -8.6028032004833221e-02
    z[8,7,5]  R2149     -4.0161529183387756e-01
    z[8,7,5]  R2150     3.9787840843200684e-01
    z[8,7,5]  R2151     -2.2953392565250397e-01
    z[8,7,5]  R2152     -4.5798502862453461e-02
    z[8,7,5]  R2153     -3.5307437181472778e-01
    z[8,7,5]  R2154     5.3968578577041626e-01
    z[8,7,5]  R2155     3.3117014169692993e-01
    z[8,7,5]  R2156     4.7005578875541687e-01
    z[8,7,5]  R2157     4.3799132108688354e-01
    z[8,7,5]  R2158     -6.3618764281272888e-02
    z[8,7,5]  R2159     -8.2405406236648560e-01
    z[8,7,5]  R2160     1.9800260663032532e-01
    z[8,7,5]  R2161     5.0412613153457642e-01
    z[8,7,5]  R2162     -5.0805461406707764e-01
    z[8,7,5]  R2163     3.7181344814598560e-03
    z[8,7,5]  R2164     2.9719021916389465e-01
    z[8,7,5]  R2165     2.3098704218864441e-01
    z[8,7,5]  R2166     -2.0979806780815125e-01
    z[8,7,5]  R2167     -1.5571042895317078e-01
    z[8,7,5]  R2168     -2.1392270922660828e-01
    z[8,7,5]  R2169     -6.9061291217803955e-01
    z[8,7,5]  R2170     -2.8672060370445251e-01
    z[8,7,5]  R2171     -3.4048205614089966e-01
    z[8,7,5]  R2172     -1.7928700149059296e-01
    z[8,7,5]  R2173     -7.5652748346328735e-02
    z[8,7,5]  R2174     1.7019577324390411e-01
    z[8,7,5]  R2175     -4.0748879313468933e-01
    z[8,7,5]  R2176     5.4188175126910210e-03
    z[8,7,5]  R2177     -4.3096852302551270e-01
    z[8,7,5]  R2178     2.1025471389293671e-01
    z[8,7,5]  R2179     -3.4225851297378540e-01
    z[8,7,5]  R2180     -2.2261887788772583e-01
    z[8,7,5]  R2181     -3.7638089060783386e-01
    z[8,7,5]  R2182     3.6430227756500244e-01
    z[8,7,5]  R2183     6.5975874662399292e-01
    z[8,7,5]  R2184     5.1600843667984009e-01
    z[8,7,5]  R2185     3.8433954119682312e-01
    z[8,7,5]  R2186     1.9256788492202759e-01
    z[8,7,5]  R2187     -4.2669618129730225e-01
    z[8,7,5]  R2188     5.8736038208007812e-01
    z[8,7,5]  R2189     -6.5819948911666870e-01
    z[8,7,5]  R2190     -7.7228508889675140e-02
    z[8,7,5]  R2191     -3.1256824731826782e-01
    z[8,7,5]  R2192     2.6809409260749817e-01
    z[8,7,5]  R2193     -1.7583874985575676e-02
    z[8,7,5]  R2194     -1.0468696802854538e-01
    z[8,7,5]  R2195     -1.9151781499385834e-01
    z[8,7,5]  R2196     -5.7094257324934006e-02
    z[8,7,5]  R2197     -0.263357013463974
    z[8,7,5]  R2198     7.4967904947698116e-03
    z[8,7,5]  R2199     -0.0255416352301836
    z[8,7,5]  R2200     3.8038536906242371e-01
    z[8,7,5]  R2201     2.9868012666702271e-01
    z[8,7,5]  R2202     -7.8571937978267670e-02
    z[8,7,5]  R2203     -2.2287155687808990e-01
    z[8,7,5]  R2204     -1.0560614988207817e-02
    z[8,7,5]  R2205     0.505304753780365
    z[8,7,5]  R2206     7.6099641621112823e-02
    z[8,7,5]  R2207     -3.4238103032112122e-01
    z[8,7,5]  R2208     2.7827474474906921e-01
    z[8,7,5]  R2209     1.4725837111473083e-01
    z[8,7,5]  R2210     1.5593683719635010e-01
    z[8,7,5]  R2211     4.4074773788452148e-01
    z[8,7,5]  R2212     3.3375957608222961e-01
    z[8,7,5]  R2213     1.0006825625896454e-01
    z[8,7,5]  R2214     -3.3978302963078022e-03
    z[8,7,5]  R2215     -2.8802141547203064e-01
    z[8,7,5]  R2216     -2.9621142148971558e-01
    z[8,7,5]  R2217     1.9540265202522278e-01
    z[8,7,5]  R2218     -4.0066826343536377e-01
    z[8,7,5]  R2219     3.0967578291893005e-01
    z[8,7,5]  R2220     -4.0537956357002258e-01
    z[8,7,5]  R2221     -2.8869214653968811e-01
    z[8,7,5]  R2222     -4.5290020108222961e-01
    z[8,7,5]  R2223     -4.5167851448059082e-01
    z[8,7,5]  R2224     0.0571405366063118
    z[8,7,5]  R2225     3.5836282372474670e-01
    z[8,7,5]  R2226     -9.0226821601390839e-02
    z[8,7,5]  R2227     -6.4252573251724243e-01
    z[8,7,5]  R2228     -2.7371481060981750e-01
    z[8,7,5]  R2229     3.3961218595504761e-01
    z[8,7,5]  R2230     -4.0715846419334412e-01
    z[8,7,5]  R2231     -1.2031991779804230e-01
    z[8,7,5]  R2232     -1.8161757290363312e-01
    z[8,7,5]  R2233     3.1795452814549208e-03
    z[8,7,5]  R2234     5.5409610271453857e-02
    z[8,7,5]  R2235     -2.9763779044151306e-01
    z[8,7,5]  R2236     1.8753847479820251e-01
    z[8,7,5]  R2237     -4.5380941033363342e-01
    z[8,7,5]  R2238     -2.9769745469093323e-01
    z[8,7,5]  R2239     -1.7324566841125488e-01
    z[8,7,5]  R2240     -5.0331324338912964e-01
    z[8,7,5]  R2241     -1.7354843020439148e-01
    z[8,7,5]  R2242     -1.4737382531166077e-02
    z[8,7,5]  R2243     -2.2738638520240784e-01
    z[8,7,5]  R2244     7.1067869663238525e-02
    z[8,7,5]  R2245     2.7304738759994507e-01
    z[8,7,5]  R2246     -0.157281756401062
    z[8,7,5]  R2247     -3.2786116003990173e-01
    z[8,7,5]  R2248     -1.9458128511905670e-01
    z[8,7,5]  R2249     -1.7302711308002472e-01
    z[8,7,5]  R2250     5.1286923885345459e-01
    z[8,7,5]  R2251     -2.5918769836425781e-01
    z[8,7,5]  R2252     -0.0354522168636322
    z[8,7,5]  R2253     2.3612717166543007e-02
    z[8,7,5]  R2254     -3.3197902143001556e-02
    z[8,7,5]  R2255     1.9197198748588562e-01
    z[8,7,5]  R2256     4.0260636806488037e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2117     -1
    z[8,7,6]  R2118     1
    z[8,7,6]  R2119     -1.3175633549690247e-01
    z[8,7,6]  R2120     1.5665335953235626e-01
    z[8,7,6]  R2121     5.2384608983993530e-01
    z[8,7,6]  R2122     6.6977924108505249e-01
    z[8,7,6]  R2123     -2.2763228416442871e-01
    z[8,7,6]  R2124     2.8818333521485329e-02
    z[8,7,6]  R2125     4.9332848191261292e-01
    z[8,7,6]  R2126     2.4070571362972260e-01
    z[8,7,6]  R2127     -7.6405160129070282e-02
    z[8,7,6]  R2128     3.3910922706127167e-02
    z[8,7,6]  R2129     -5.6884109973907471e-01
    z[8,7,6]  R2130     3.9632487297058105e-01
    z[8,7,6]  R2131     -1.7966100573539734e-01
    z[8,7,6]  R2132     -0.0784110277891159
    z[8,7,6]  R2133     1.2755751609802246e-01
    z[8,7,6]  R2134     -0.190152108669281
    z[8,7,6]  R2135     -1.0380861163139343e-01
    z[8,7,6]  R2136     -4.7682128846645355e-02
    z[8,7,6]  R2137     2.1728739142417908e-01
    z[8,7,6]  R2138     2.1173125505447388e-01
    z[8,7,6]  R2139     -5.3208328783512115e-02
    z[8,7,6]  R2140     2.3521710932254791e-01
    z[8,7,6]  R2141     -2.6275765895843506e-01
    z[8,7,6]  R2142     9.0591244399547577e-02
    z[8,7,6]  R2143     0.00939799565821886
    z[8,7,6]  R2144     1.2457884848117828e-01
    z[8,7,6]  R2145     1.3694353401660919e-01
    z[8,7,6]  R2146     -2.0731341838836670e-01
    z[8,7,6]  R2147     -2.3764740675687790e-02
    z[8,7,6]  R2148     -4.9654132127761841e-01
    z[8,7,6]  R2149     -4.4730773568153381e-01
    z[8,7,6]  R2150     -1.4911796152591705e-01
    z[8,7,6]  R2151     -5.2431887388229370e-01
    z[8,7,6]  R2152     3.0611521005630493e-01
    z[8,7,6]  R2153     -4.4138675928115845e-01
    z[8,7,6]  R2154     7.2807647287845612e-02
    z[8,7,6]  R2155     -3.8419792056083679e-01
    z[8,7,6]  R2156     -2.8833723068237305e-01
    z[8,7,6]  R2157     -2.2672960162162781e-01
    z[8,7,6]  R2158     5.2644795179367065e-01
    z[8,7,6]  R2159     -3.2018184661865234e-01
    z[8,7,6]  R2160     -1.7275755107402802e-01
    z[8,7,6]  R2161     2.3491667211055756e-01
    z[8,7,6]  R2162     2.8786253929138184e-01
    z[8,7,6]  R2163     0.0482945442199707
    z[8,7,6]  R2164     -4.1684368252754211e-01
    z[8,7,6]  R2165     -2.6613765954971313e-01
    z[8,7,6]  R2166     -4.2893379926681519e-01
    z[8,7,6]  R2167     -2.9815217852592468e-01
    z[8,7,6]  R2168     5.0212317705154419e-01
    z[8,7,6]  R2169     3.9354014396667480e-01
    z[8,7,6]  R2170     9.1656424105167389e-02
    z[8,7,6]  R2171     -2.4070023000240326e-01
    z[8,7,6]  R2172     -0.325311541557312
    z[8,7,6]  R2173     -2.5049161911010742e-01
    z[8,7,6]  R2174     4.4305855035781860e-01
    z[8,7,6]  R2175     -3.9032322168350220e-01
    z[8,7,6]  R2176     2.7816012501716614e-01
    z[8,7,6]  R2177     2.6311546564102173e-01
    z[8,7,6]  R2178     -1.1615970730781555e-01
    z[8,7,6]  R2179     2.7570804953575134e-01
    z[8,7,6]  R2180     -1.5641090273857117e-01
    z[8,7,6]  R2181     -1.8282571434974670e-01
    z[8,7,6]  R2182     -3.7996169924736023e-01
    z[8,7,6]  R2183     4.2082633823156357e-02
    z[8,7,6]  R2184     2.8814616799354553e-01
    z[8,7,6]  R2185     3.2460793852806091e-02
    z[8,7,6]  R2186     2.6251126546412706e-03
    z[8,7,6]  R2187     2.4456915259361267e-01
    z[8,7,6]  R2188     1.1607024818658829e-01
    z[8,7,6]  R2189     -4.3984800577163696e-01
    z[8,7,6]  R2190     5.9148907661437988e-02
    z[8,7,6]  R2191     2.5324997305870056e-01
    z[8,7,6]  R2192     -3.0960096046328545e-02
    z[8,7,6]  R2193     -3.7550774216651917e-01
    z[8,7,6]  R2194     -3.1864714622497559e-01
    z[8,7,6]  R2195     -7.7630870044231415e-02
    z[8,7,6]  R2196     1.1627739667892456e-01
    z[8,7,6]  R2197     3.2463806867599487e-01
    z[8,7,6]  R2198     6.4279779791831970e-02
    z[8,7,6]  R2199     -5.8681093156337738e-02
    z[8,7,6]  R2200     3.7266245484352112e-01
    z[8,7,6]  R2201     2.5364753603935242e-01
    z[8,7,6]  R2202     -2.3666703701019287e-01
    z[8,7,6]  R2203     5.1761954091489315e-04
    z[8,7,6]  R2204     -2.3464260995388031e-01
    z[8,7,6]  R2205     2.6170909404754639e-03
    z[8,7,6]  R2206     -4.1718250513076782e-01
    z[8,7,6]  R2207     -2.9475545883178711e-01
    z[8,7,6]  R2208     -7.0257700979709625e-02
    z[8,7,6]  R2209     -0.302512526512146
    z[8,7,6]  R2210     3.2013422250747681e-01
    z[8,7,6]  R2211     2.7645963430404663e-01
    z[8,7,6]  R2212     3.4591197967529297e-01
    z[8,7,6]  R2213     -1.0379598289728165e-01
    z[8,7,6]  R2214     2.3165971040725708e-01
    z[8,7,6]  R2215     2.5857791304588318e-01
    z[8,7,6]  R2216     -7.2749868035316467e-02
    z[8,7,6]  R2217     1.6995021700859070e-01
    z[8,7,6]  R2218     3.2450035214424133e-01
    z[8,7,6]  R2219     4.4050562381744385e-01
    z[8,7,6]  R2220     -2.5648474693298340e-01
    z[8,7,6]  R2221     -3.6785000562667847e-01
    z[8,7,6]  R2222     -4.5664796233177185e-01
    z[8,7,6]  R2223     4.7958934307098389e-01
    z[8,7,6]  R2224     3.2247710227966309e-01
    z[8,7,6]  R2225     -1.4056035876274109e-01
    z[8,7,6]  R2226     -6.4469277858734131e-01
    z[8,7,6]  R2227     -1.1656996607780457e-01
    z[8,7,6]  R2228     -2.6940440759062767e-02
    z[8,7,6]  R2229     2.6471406221389771e-01
    z[8,7,6]  R2230     -7.2548437118530273e-01
    z[8,7,6]  R2231     8.7576441466808319e-02
    z[8,7,6]  R2232     -3.4995871782302856e-01
    z[8,7,6]  R2233     -6.4238435029983521e-01
    z[8,7,6]  R2234     -5.2331924438476562e-01
    z[8,7,6]  R2235     3.4439265727996826e-01
    z[8,7,6]  R2236     -1.1146487295627594e-01
    z[8,7,6]  R2237     -1.4820632338523865e-01
    z[8,7,6]  R2238     -1.4348258078098297e-01
    z[8,7,6]  R2239     -1.3156990706920624e-01
    z[8,7,6]  R2240     -2.0089823007583618e-01
    z[8,7,6]  R2241     -5.6589150428771973e-01
    z[8,7,6]  R2242     -3.4332635998725891e-01
    z[8,7,6]  R2243     -1.6490109264850616e-02
    z[8,7,6]  R2244     1.0197193175554276e-01
    z[8,7,6]  R2245     -6.4058023691177368e-01
    z[8,7,6]  R2246     2.3046158254146576e-01
    z[8,7,6]  R2247     1.5784651041030884e-01
    z[8,7,6]  R2248     -1.8610309064388275e-01
    z[8,7,6]  R2249     -4.1490641236305237e-01
    z[8,7,6]  R2250     -3.2571631669998169e-01
    z[8,7,6]  R2251     3.4918409585952759e-01
    z[8,7,6]  R2252     6.2470335513353348e-02
    z[8,7,6]  R2253     -1.7074249684810638e-01
    z[8,7,6]  R2254     -1.4392884075641632e-01
    z[8,7,6]  R2255     -2.7983868122100830e-01
    z[8,7,6]  R2256     -1.7215034365653992e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2257     -1
    z[8,9,0]  R2258     1
    z[8,9,0]  R2271     -2.8226274251937866e-01
    z[8,9,0]  R2272     -7.7986550331115723e-01
    z[8,9,0]  R2273     -5.6133443117141724e-01
    z[8,9,0]  R2274     -1.8987755477428436e-01
    z[8,9,0]  R2275     -2.2425100207328796e-01
    z[8,9,0]  R2276     -3.7275391817092896e-01
    z[8,9,0]  R2277     -1.4958010986447334e-02
    z[8,9,0]  R2278     -1.2382146716117859e-01
    z[8,9,0]  R2279     8.7856575846672058e-02
    z[8,9,0]  R2280     1.6627542674541473e-01
    z[8,9,0]  R2281     0.0994608923792839
    z[8,9,0]  R2282     5.5766079574823380e-02
    z[8,9,0]  R2283     -7.3843546211719513e-02
    z[8,9,0]  R2284     0.276685506105423
    z[8,9,0]  R2285     -1.0525304824113846e-02
    z[8,9,0]  R2286     1.7087580263614655e-01
    z[8,9,0]  R2287     -1.3269034028053284e-01
    z[8,9,0]  R2288     -6.3597828149795532e-02
    z[8,9,0]  R2289     1.3340190052986145e-01
    z[8,9,0]  R2290     1.7978912591934204e-01
    z[8,9,0]  R2291     7.2384142875671387e-01
    z[8,9,0]  R2292     6.6835331916809082e-01
    z[8,9,0]  R2293     7.7100640535354614e-01
    z[8,9,0]  R2294     7.0901614427566528e-01
    z[8,9,0]  R2295     2.1059218049049377e-01
    z[8,9,0]  R2296     -2.6733953505754471e-02
    z[8,9,0]  R2297     5.6849938631057739e-01
    z[8,9,0]  R2298     0.751060426235199
    z[8,9,0]  R2299     5.5167865753173828e-01
    z[8,9,0]  R2300     6.1072719097137451e-01
    z[8,9,0]  R2301     1.4569234848022461e-01
    z[8,9,0]  R2302     -0.189011350274086
    z[8,9,0]  R2303     1.0889729112386703e-01
    z[8,9,0]  R2304     -1.1854165792465210e-01
    z[8,9,0]  R2305     1.2387714534997940e-01
    z[8,9,0]  R2306     -9.2916369438171387e-02
    z[8,9,0]  R2307     -4.9124038219451904e-01
    z[8,9,0]  R2308     -5.3309446573257446e-01
    z[8,9,0]  R2309     -3.5195019841194153e-01
    z[8,9,0]  R2310     3.8438871502876282e-01
    z[8,9,0]  R2311     1.7925992608070374e-01
    z[8,9,0]  R2312     7.7746921777725220e-01
    z[8,9,0]  R2313     7.6034718751907349e-01
    z[8,9,0]  R2314     0.081568144261837
    z[8,9,0]  R2315     -2.9130074381828308e-01
    z[8,9,0]  R2316     7.2642546892166138e-01
    z[8,9,0]  R2317     7.1067118644714355e-01
    z[8,9,0]  R2318     -1.2803460471332073e-02
    z[8,9,0]  R2319     7.5687915086746216e-01
    z[8,9,0]  R2320     3.9250746369361877e-01
    z[8,9,0]  R2321     2.2239652276039124e-01
    z[8,9,0]  R2322     9.9800862371921539e-02
    z[8,9,0]  R2323     3.7790974974632263e-01
    z[8,9,0]  R2324     0.721330463886261
    z[8,9,0]  R2325     8.7671202421188354e-01
    z[8,9,0]  R2326     6.8902516365051270e-01
    z[8,9,0]  R2327     7.7704823017120361e-01
    z[8,9,0]  R2328     -1.8984349071979523e-01
    z[8,9,0]  R2329     0.637488603591919
    z[8,9,0]  R2330     5.9059524536132812e-01
    z[8,9,0]  R2331     5.8321809768676758e-01
    z[8,9,0]  R2332     6.9958710670471191e-01
    z[8,9,0]  R2333     1.7745713889598846e-01
    z[8,9,0]  R2334     -2.7724722027778625e-01
    z[8,9,0]  R2335     -5.8270114660263062e-01
    z[8,9,0]  R2336     -3.3282798528671265e-01
    z[8,9,0]  R2337     -1.6312380135059357e-01
    z[8,9,0]  R2338     -2.3580288887023926e-01
    z[8,9,0]  R2339     7.6551836729049683e-01
    z[8,9,0]  R2340     -4.8537963628768921e-01
    z[8,9,0]  R2341     2.0472145080566406e-01
    z[8,9,0]  R2342     6.8301928043365479e-01
    z[8,9,0]  R2343     8.0555105209350586e-01
    z[8,9,0]  R2344     -0.315387487411499
    z[8,9,0]  R2345     -3.9320096373558044e-01
    z[8,9,0]  R2346     -3.5275191068649292e-01
    z[8,9,0]  R2347     6.3006573915481567e-01
    z[8,9,0]  R2348     -2.8680721297860146e-02
    z[8,9,0]  R2349     3.0212867259979248e-01
    z[8,9,0]  R2350     -4.5551683753728867e-02
    z[8,9,0]  R2351     9.1342061758041382e-01
    z[8,9,0]  R2352     -4.6857488155364990e-01
    z[8,9,0]  R2353     -3.4039369225502014e-01
    z[8,9,0]  R2354     6.9425010681152344e-01
    z[8,9,0]  R2355     0.0693756490945816
    z[8,9,0]  R2356     -5.3943157196044922e-01
    z[8,9,0]  R2357     -6.2931698560714722e-01
    z[8,9,0]  R2358     -5.9819233417510986e-01
    z[8,9,0]  R2359     2.9400706291198730e-01
    z[8,9,0]  R2360     2.5269946455955505e-01
    z[8,9,0]  R2361     -7.1938061714172363e-01
    z[8,9,0]  R2362     -7.3434668779373169e-01
    z[8,9,0]  R2363     -8.7153381109237671e-01
    z[8,9,0]  R2364     3.9826877415180206e-02
    z[8,9,0]  R2365     4.2995803058147430e-02
    z[8,9,0]  R2366     2.3911140859127045e-02
    z[8,9,0]  R2367     6.6440761089324951e-02
    z[8,9,0]  R2368     -0.0642852932214737
    z[8,9,0]  R2369     1.2891144491732121e-02
    z[8,9,0]  R2370     1.9521045684814453e-01
    z[8,9,0]  R2371     1.8371686339378357e-01
    z[8,9,0]  R2372     3.2115471363067627e-01
    z[8,9,0]  R2373     1.8859191238880157e-01
    z[8,9,0]  R2374     1.8353742361068726e-01
    z[8,9,0]  R2375     2.9240572452545166e-01
    z[8,9,0]  R2376     8.1658527255058289e-02
    z[8,9,0]  R2377     1.1317206174135208e-01
    z[8,9,0]  R2378     -1.2729771435260773e-02
    z[8,9,0]  R2379     1.7303159832954407e-01
    z[8,9,0]  R2380     -1.5301170945167542e-01
    z[8,9,0]  R2381     2.3762527108192444e-01
    z[8,9,0]  R2382     -0.0158318392932415
    z[8,9,0]  R2383     3.9074033498764038e-01
    z[8,9,0]  R2384     2.6645278930664062e-01
    z[8,9,0]  R2385     9.1636814177036285e-02
    z[8,9,0]  R2386     -2.0787367224693298e-01
    z[8,9,0]  R2387     4.5522534847259521e-01
    z[8,9,0]  R2388     0.441200852394104
    z[8,9,0]  R2389     -2.7625164017081261e-02
    z[8,9,0]  R2390     -3.2364460825920105e-01
    z[8,9,0]  R2391     -2.3119792342185974e-01
    z[8,9,0]  R2392     2.4720193445682526e-01
    z[8,9,0]  R2393     2.4882322549819946e-01
    z[8,9,0]  R2394     3.7292793393135071e-01
    z[8,9,0]  R2395     1.8218696117401123e-01
    z[8,9,0]  R2396     1.3982728123664856e-01
    z[8,9,0]  R2397     4.4310668110847473e-01
    z[8,9,0]  R2398     -2.5280886888504028e-01
    z[8,9,0]  R2399     2.0975257456302643e-01
    z[8,9,0]  R2400     4.5805528759956360e-01
    z[8,9,0]  R2401     -1.5050864778459072e-02
    z[8,9,0]  R2402     3.5582253336906433e-01
    z[8,9,0]  R2403     5.5501270294189453e-01
    z[8,9,0]  R2404     4.5985287427902222e-01
    z[8,9,0]  R2405     1.1087729036808014e-01
    z[8,9,0]  R2406     1.2989985942840576e-01
    z[8,9,0]  R2407     1.1822313815355301e-01
    z[8,9,0]  R2408     2.2202843427658081e-01
    z[8,9,0]  R2409     -2.5484177470207214e-01
    z[8,9,0]  R2410     1.3983985781669617e-01
    z[8,9,0]  R2411     6.1186897754669189e-01
    z[8,9,0]  R2412     0.0938342809677124
    z[8,9,0]  R2413     3.5296627879142761e-01
    z[8,9,0]  R2414     -1.8386578187346458e-02
    z[8,9,0]  R2415     -1.2858489155769348e-01
    z[8,9,0]  R2416     -1.9241939485073090e-01
    z[8,9,0]  R2417     -6.3853137195110321e-02
    z[8,9,0]  R2418     -1.3127784430980682e-01
    z[8,9,0]  R2419     -7.1821823716163635e-02
    z[8,9,0]  R2420     1.0111336596310139e-02
    z[8,9,0]  R2421     0.541682779788971
    z[8,9,0]  R2422     5.1831579208374023e-01
    z[8,9,0]  R2423     -1.7896954715251923e-01
    z[8,9,0]  R2424     2.5382828712463379e-01
    z[8,9,0]  R2425     -4.7841900587081909e-01
    z[8,9,0]  R2426     -1.4419214427471161e-01
    z[8,9,0]  R2427     1.1953799426555634e-01
    z[8,9,0]  R2428     1.8817475438117981e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2259     -1
    z[8,9,1]  R2260     1
    z[8,9,1]  R2271     -7.9524271190166473e-02
    z[8,9,1]  R2272     4.3006721138954163e-01
    z[8,9,1]  R2273     6.0038244724273682e-01
    z[8,9,1]  R2274     -0.348158061504364
    z[8,9,1]  R2275     6.6742175817489624e-01
    z[8,9,1]  R2276     5.6951224803924561e-01
    z[8,9,1]  R2277     -2.0942346751689911e-01
    z[8,9,1]  R2278     6.8685054779052734e-01
    z[8,9,1]  R2279     7.2288900613784790e-01
    z[8,9,1]  R2280     3.2047115266323090e-02
    z[8,9,1]  R2281     -2.7143087983131409e-01
    z[8,9,1]  R2282     -7.5525051355361938e-01
    z[8,9,1]  R2283     -6.9330054521560669e-01
    z[8,9,1]  R2284     -5.9834969043731689e-01
    z[8,9,1]  R2285     -5.3521466255187988e-01
    z[8,9,1]  R2286     -6.4924311637878418e-01
    z[8,9,1]  R2287     -7.2761493921279907e-01
    z[8,9,1]  R2288     -6.3145416975021362e-01
    z[8,9,1]  R2289     -4.4217732548713684e-01
    z[8,9,1]  R2290     0.265844464302063
    z[8,9,1]  R2291     5.5007302761077881e-01
    z[8,9,1]  R2292     5.3940200805664062e-01
    z[8,9,1]  R2293     1.4655441045761108e-01
    z[8,9,1]  R2294     2.4297359585762024e-01
    z[8,9,1]  R2295     -5.6602823734283447e-01
    z[8,9,1]  R2296     -1.7171211540699005e-01
    z[8,9,1]  R2297     6.2469226121902466e-01
    z[8,9,1]  R2298     1.5787769854068756e-01
    z[8,9,1]  R2299     6.5057468414306641e-01
    z[8,9,1]  R2300     3.6385115981101990e-01
    z[8,9,1]  R2301     1.4839459955692291e-01
    z[8,9,1]  R2302     4.5483246445655823e-01
    z[8,9,1]  R2303     -5.0865131616592407e-01
    z[8,9,1]  R2304     5.2377808094024658e-01
    z[8,9,1]  R2305     -5.3239434957504272e-01
    z[8,9,1]  R2306     5.6583970785140991e-01
    z[8,9,1]  R2307     4.6969932317733765e-01
    z[8,9,1]  R2308     3.6401736736297607e-01
    z[8,9,1]  R2309     7.7508658170700073e-02
    z[8,9,1]  R2310     -3.5676285624504089e-01
    z[8,9,1]  R2311     -4.3701842427253723e-02
    z[8,9,1]  R2312     2.4696822464466095e-01
    z[8,9,1]  R2313     2.7257981896400452e-01
    z[8,9,1]  R2314     -4.9792066216468811e-01
    z[8,9,1]  R2315     -3.2171663641929626e-01
    z[8,9,1]  R2316     2.5877881050109863e-01
    z[8,9,1]  R2317     4.9964633584022522e-01
    z[8,9,1]  R2318     -6.1221045255661011e-01
    z[8,9,1]  R2319     9.7677908837795258e-02
    z[8,9,1]  R2320     -5.5611205101013184e-01
    z[8,9,1]  R2321     0.0494234636425972
    z[8,9,1]  R2322     4.4642563909292221e-02
    z[8,9,1]  R2323     -1.4130115509033203e-01
    z[8,9,1]  R2324     0.358583003282547
    z[8,9,1]  R2325     -6.3015684485435486e-02
    z[8,9,1]  R2326     5.0175529718399048e-01
    z[8,9,1]  R2327     1.2697845697402954e-01
    z[8,9,1]  R2328     -2.1848936378955841e-01
    z[8,9,1]  R2329     3.7984037399291992e-01
    z[8,9,1]  R2330     5.0106209516525269e-01
    z[8,9,1]  R2331     0.666954517364502
    z[8,9,1]  R2332     4.7370767593383789e-01
    z[8,9,1]  R2333     4.9215254187583923e-01
    z[8,9,1]  R2334     3.5664218664169312e-01
    z[8,9,1]  R2335     0.0708300992846489
    z[8,9,1]  R2336     4.5316481590270996e-01
    z[8,9,1]  R2337     7.7104771137237549e-01
    z[8,9,1]  R2338     -7.5780582427978516e-01
    z[8,9,1]  R2339     -8.0938935279846191e-02
    z[8,9,1]  R2340     5.2663671970367432e-01
    z[8,9,1]  R2341     -3.8568067550659180e-01
    z[8,9,1]  R2342     4.6776360273361206e-01
    z[8,9,1]  R2343     2.4367228150367737e-01
    z[8,9,1]  R2344     5.9032875299453735e-01
    z[8,9,1]  R2345     0.531501054763794
    z[8,9,1]  R2346     4.0920135378837585e-01
    z[8,9,1]  R2347     1.8107984960079193e-01
    z[8,9,1]  R2348     -9.1409909725189209e-01
    z[8,9,1]  R2349     -3.5409516096115112e-01
    z[8,9,1]  R2350     -4.3090045452117920e-01
    z[8,9,1]  R2351     1.8716056644916534e-01
    z[8,9,1]  R2352     4.5817929506301880e-01
    z[8,9,1]  R2353     7.3749041557312012e-01
    z[8,9,1]  R2354     2.9498317837715149e-01
    z[8,9,1]  R2355     4.2501375079154968e-01
    z[8,9,1]  R2356     2.7181729674339294e-01
    z[8,9,1]  R2357     4.2410823702812195e-01
    z[8,9,1]  R2358     -1.9883349537849426e-02
    z[8,9,1]  R2359     -3.0261763930320740e-01
    z[8,9,1]  R2360     -7.1180623769760132e-01
    z[8,9,1]  R2361     3.8767442107200623e-01
    z[8,9,1]  R2362     1.7109133303165436e-01
    z[8,9,1]  R2363     2.1183459088206291e-02
    z[8,9,1]  R2364     7.4613589048385620e-01
    z[8,9,1]  R2365     7.9002523422241211e-01
    z[8,9,1]  R2366     -4.8140946030616760e-01
    z[8,9,1]  R2367     3.8775098323822021e-01
    z[8,9,1]  R2368     -1.8589808046817780e-01
    z[8,9,1]  R2369     6.1399197578430176e-01
    z[8,9,1]  R2370     1.9840073585510254e-01
    z[8,9,1]  R2371     -3.6536478996276855e-01
    z[8,9,1]  R2372     -2.4173070490360260e-01
    z[8,9,1]  R2373     -0.476881742477417
    z[8,9,1]  R2374     -1.9843542575836182e-01
    z[8,9,1]  R2375     -5.4412138462066650e-01
    z[8,9,1]  R2376     -6.9752758741378784e-01
    z[8,9,1]  R2377     2.8069606423377991e-01
    z[8,9,1]  R2378     -7.4881382286548615e-02
    z[8,9,1]  R2379     0.581967830657959
    z[8,9,1]  R2380     3.7978556752204895e-01
    z[8,9,1]  R2381     5.7962757349014282e-01
    z[8,9,1]  R2382     2.7062505483627319e-01
    z[8,9,1]  R2383     1.4633838832378387e-01
    z[8,9,1]  R2384     -2.8048139810562134e-01
    z[8,9,1]  R2385     -9.0064823627471924e-02
    z[8,9,1]  R2386     4.3462336063385010e-01
    z[8,9,1]  R2387     -6.3214832544326782e-01
    z[8,9,1]  R2388     3.3744487911462784e-02
    z[8,9,1]  R2389     6.4503389596939087e-01
    z[8,9,1]  R2390     6.3430631160736084e-01
    z[8,9,1]  R2391     4.7585359215736389e-01
    z[8,9,1]  R2392     3.6725082993507385e-01
    z[8,9,1]  R2393     -1.5736138820648193e-01
    z[8,9,1]  R2394     -3.0708810687065125e-01
    z[8,9,1]  R2395     -2.8330606222152710e-01
    z[8,9,1]  R2396     -3.6009213328361511e-01
    z[8,9,1]  R2397     1.7421099543571472e-01
    z[8,9,1]  R2398     -6.5730142593383789e-01
    z[8,9,1]  R2399     7.4005979299545288e-01
    z[8,9,1]  R2400     -1.4961113035678864e-01
    z[8,9,1]  R2401     -0.664179265499115
    z[8,9,1]  R2402     -4.6668875217437744e-01
    z[8,9,1]  R2403     -5.1353383064270020e-01
    z[8,9,1]  R2404     2.4946649372577667e-01
    z[8,9,1]  R2405     6.0474222898483276e-01
    z[8,9,1]  R2406     6.6959589719772339e-02
    z[8,9,1]  R2407     2.4652989581227303e-02
    z[8,9,1]  R2408     -2.8708785772323608e-01
    z[8,9,1]  R2409     7.7099275588989258e-01
    z[8,9,1]  R2410     -4.4385217130184174e-02
    z[8,9,1]  R2411     -4.5468533039093018e-01
    z[8,9,1]  R2412     4.5502173900604248e-01
    z[8,9,1]  R2413     1.3688434660434723e-01
    z[8,9,1]  R2414     -6.8872314691543579e-01
    z[8,9,1]  R2415     -7.5139582157135010e-01
    z[8,9,1]  R2416     -8.6946922540664673e-01
    z[8,9,1]  R2417     -7.1054071187973022e-01
    z[8,9,1]  R2418     -7.5809156894683838e-01
    z[8,9,1]  R2419     8.4869980812072754e-01
    z[8,9,1]  R2420     0.495947003364563
    z[8,9,1]  R2421     -0.353481262922287
    z[8,9,1]  R2422     -3.2727217767387629e-03
    z[8,9,1]  R2423     -5.8670526742935181e-01
    z[8,9,1]  R2424     -1.5659306943416595e-01
    z[8,9,1]  R2425     -7.8024029731750488e-01
    z[8,9,1]  R2426     -6.8780100345611572e-01
    z[8,9,1]  R2427     -8.3306348323822021e-01
    z[8,9,1]  R2428     -7.9620856046676636e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2261     -1
    z[8,9,2]  R2262     1
    z[8,9,2]  R2271     -1.4506091177463531e-01
    z[8,9,2]  R2272     -4.0828222036361694e-01
    z[8,9,2]  R2273     -1.3990265130996704e-01
    z[8,9,2]  R2274     1.5811876952648163e-01
    z[8,9,2]  R2275     -6.6476821899414062e-01
    z[8,9,2]  R2276     -5.1513093709945679e-01
    z[8,9,2]  R2277     5.6466543674468994e-01
    z[8,9,2]  R2278     -2.7045628428459167e-01
    z[8,9,2]  R2279     -6.0067063570022583e-01
    z[8,9,2]  R2280     4.9722400307655334e-01
    z[8,9,2]  R2281     -9.8033733665943146e-03
    z[8,9,2]  R2282     4.5843723416328430e-01
    z[8,9,2]  R2283     4.7923445701599121e-01
    z[8,9,2]  R2284     5.4851877689361572e-01
    z[8,9,2]  R2285     3.9394792914390564e-01
    z[8,9,2]  R2286     4.8835653066635132e-01
    z[8,9,2]  R2287     3.5637223720550537e-01
    z[8,9,2]  R2288     5.6142389774322510e-01
    z[8,9,2]  R2289     5.4904019832611084e-01
    z[8,9,2]  R2290     -2.3786285519599915e-01
    z[8,9,2]  R2291     0.0487288273870945
    z[8,9,2]  R2292     -2.6154069229960442e-02
    z[8,9,2]  R2293     4.2261460423469543e-01
    z[8,9,2]  R2294     4.2749884724617004e-01
    z[8,9,2]  R2295     3.4843704104423523e-01
    z[8,9,2]  R2296     1.8114510178565979e-01
    z[8,9,2]  R2297     3.1396117061376572e-02
    z[8,9,2]  R2298     -3.8140231370925903e-01
    z[8,9,2]  R2299     -1.4456406235694885e-01
    z[8,9,2]  R2300     -4.6017771959304810e-01
    z[8,9,2]  R2301     4.1910163126885891e-03
    z[8,9,2]  R2302     -6.4679676294326782e-01
    z[8,9,2]  R2303     -2.4103774130344391e-01
    z[8,9,2]  R2304     -2.5775903463363647e-01
    z[8,9,2]  R2305     -4.9242994189262390e-01
    z[8,9,2]  R2306     -5.4433572292327881e-01
    z[8,9,2]  R2307     -1.7263974249362946e-01
    z[8,9,2]  R2308     -2.8131538629531860e-01
    z[8,9,2]  R2309     -5.9280896186828613e-01
    z[8,9,2]  R2310     3.9855021238327026e-01
    z[8,9,2]  R2311     -2.3835518956184387e-01
    z[8,9,2]  R2312     -3.8933902978897095e-01
    z[8,9,2]  R2313     1.4332948625087738e-01
    z[8,9,2]  R2314     -5.1626789569854736e-01
    z[8,9,2]  R2315     5.0522979348897934e-02
    z[8,9,2]  R2316     -5.4258454591035843e-02
    z[8,9,2]  R2317     -3.3366364240646362e-01
    z[8,9,2]  R2318     2.1466314792633057e-02
    z[8,9,2]  R2319     1.4715506136417389e-01
    z[8,9,2]  R2320     -4.2111596465110779e-01
    z[8,9,2]  R2321     2.6426786184310913e-01
    z[8,9,2]  R2322     4.9070903658866882e-01
    z[8,9,2]  R2323     2.7465194463729858e-01
    z[8,9,2]  R2324     1.6144557297229767e-01
    z[8,9,2]  R2325     1.0726875066757202e-01
    z[8,9,2]  R2326     9.6196554601192474e-02
    z[8,9,2]  R2327     -1.9534166157245636e-01
    z[8,9,2]  R2328     6.4866676926612854e-02
    z[8,9,2]  R2329     1.0155776888132095e-01
    z[8,9,2]  R2330     -3.3164986968040466e-01
    z[8,9,2]  R2331     -2.1577699109911919e-02
    z[8,9,2]  R2332     -4.0542903542518616e-01
    z[8,9,2]  R2333     -5.8782523870468140e-01
    z[8,9,2]  R2334     -6.2577402591705322e-01
    z[8,9,2]  R2335     -3.5352534055709839e-01
    z[8,9,2]  R2336     -4.1959038376808167e-01
    z[8,9,2]  R2337     -3.8010302186012268e-01
    z[8,9,2]  R2338     5.4346317052841187e-01
    z[8,9,2]  R2339     2.2473068535327911e-01
    z[8,9,2]  R2340     -0.0822916328907013
    z[8,9,2]  R2341     -2.4013957008719444e-03
    z[8,9,2]  R2342     0.181917205452919
    z[8,9,2]  R2343     0.0684681311249733
    z[8,9,2]  R2344     -6.6954821348190308e-01
    z[8,9,2]  R2345     -5.5514967441558838e-01
    z[8,9,2]  R2346     -7.1552932262420654e-01
    z[8,9,2]  R2347     9.0828202664852142e-02
    z[8,9,2]  R2348     2.6896980404853821e-01
    z[8,9,2]  R2349     6.1077654361724854e-01
    z[8,9,2]  R2350     6.1808902770280838e-02
    z[8,9,2]  R2351     1.2700352072715759e-01
    z[8,9,2]  R2352     -3.4459051489830017e-01
    z[8,9,2]  R2353     -4.1717949509620667e-01
    z[8,9,2]  R2354     -4.3970888853073120e-01
    z[8,9,2]  R2355     -6.7316633462905884e-01
    z[8,9,2]  R2356     -6.3947242498397827e-01
    z[8,9,2]  R2357     -1.5409936010837555e-01
    z[8,9,2]  R2358     -6.5547204017639160e-01
    z[8,9,2]  R2359     -3.3076709508895874e-01
    z[8,9,2]  R2360     3.5841265320777893e-01
    z[8,9,2]  R2361     2.6962780952453613e-01
    z[8,9,2]  R2362     -1.5595278143882751e-01
    z[8,9,2]  R2363     -2.7372547984123230e-01
    z[8,9,2]  R2364     1.2897615134716034e-01
    z[8,9,2]  R2365     -2.4308270215988159e-01
    z[8,9,2]  R2366     3.0984896421432495e-01
    z[8,9,2]  R2367     -1.4209984242916107e-01
    z[8,9,2]  R2368     5.9943532943725586e-01
    z[8,9,2]  R2369     -1.0448925197124481e-01
    z[8,9,2]  R2370     1.3479281216859818e-02
    z[8,9,2]  R2371     1.1287947744131088e-01
    z[8,9,2]  R2372     1.1302204430103302e-01
    z[8,9,2]  R2373     9.8053090274333954e-02
    z[8,9,2]  R2374     7.6808951795101166e-02
    z[8,9,2]  R2375     1.2116042524576187e-01
    z[8,9,2]  R2376     -6.9153765216469765e-03
    z[8,9,2]  R2377     -3.3691966533660889e-01
    z[8,9,2]  R2378     1.6750842332839966e-01
    z[8,9,2]  R2379     -3.8306069374084473e-01
    z[8,9,2]  R2380     -9.7597584128379822e-02
    z[8,9,2]  R2381     -1.6526705026626587e-01
    z[8,9,2]  R2382     -1.6783097386360168e-01
    z[8,9,2]  R2383     4.0195193886756897e-01
    z[8,9,2]  R2384     3.0085697770118713e-01
    z[8,9,2]  R2385     5.0224140286445618e-02
    z[8,9,2]  R2386     -6.7384196445345879e-03
    z[8,9,2]  R2387     2.2282119095325470e-01
    z[8,9,2]  R2388     1.4660651981830597e-01
    z[8,9,2]  R2389     2.7640566229820251e-01
    z[8,9,2]  R2390     -1.7612041532993317e-01
    z[8,9,2]  R2391     -1.9000692665576935e-01
    z[8,9,2]  R2392     -2.3613980412483215e-01
    z[8,9,2]  R2393     1.6630922257900238e-01
    z[8,9,2]  R2394     0.278865247964859
    z[8,9,2]  R2395     3.4774717688560486e-01
    z[8,9,2]  R2396     -2.6795920729637146e-01
    z[8,9,2]  R2397     2.4316211044788361e-01
    z[8,9,2]  R2398     0.072159044444561
    z[8,9,2]  R2399     -1.4607223868370056e-01
    z[8,9,2]  R2400     -3.6402802914381027e-02
    z[8,9,2]  R2401     -0.0696464404463768
    z[8,9,2]  R2402     3.4577544778585434e-02
    z[8,9,2]  R2403     1.7927622795104980e-01
    z[8,9,2]  R2404     -4.9369469285011292e-02
    z[8,9,2]  R2405     -8.6866080760955811e-02
    z[8,9,2]  R2406     -1.8797514960169792e-02
    z[8,9,2]  R2407     1.4925029873847961e-01
    z[8,9,2]  R2408     -3.7630814313888550e-01
    z[8,9,2]  R2409     9.9292054772377014e-02
    z[8,9,2]  R2410     2.7988898754119873e-01
    z[8,9,2]  R2411     -2.0557044446468353e-01
    z[8,9,2]  R2412     4.0105696767568588e-02
    z[8,9,2]  R2413     2.7256676554679871e-01
    z[8,9,2]  R2414     0.440176784992218
    z[8,9,2]  R2415     5.3659409284591675e-01
    z[8,9,2]  R2416     2.4309273064136505e-01
    z[8,9,2]  R2417     5.5031704902648926e-01
    z[8,9,2]  R2418     4.6665042638778687e-01
    z[8,9,2]  R2419     -2.4337400496006012e-01
    z[8,9,2]  R2420     -7.5156822800636292e-02
    z[8,9,2]  R2421     3.5064734518527985e-02
    z[8,9,2]  R2422     4.2925927042961121e-01
    z[8,9,2]  R2423     1.1458951234817505e-01
    z[8,9,2]  R2424     1.7669038474559784e-01
    z[8,9,2]  R2425     1.3559868931770325e-01
    z[8,9,2]  R2426     1.8198868632316589e-01
    z[8,9,2]  R2427     2.8437674045562744e-01
    z[8,9,2]  R2428     -2.2518450021743774e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2263     -1
    z[8,9,3]  R2264     1
    z[8,9,3]  R2271     6.3471293449401855e-01
    z[8,9,3]  R2272     3.7169404327869415e-02
    z[8,9,3]  R2273     1.5428406186401844e-02
    z[8,9,3]  R2274     4.8135069012641907e-01
    z[8,9,3]  R2275     8.5634356364607811e-03
    z[8,9,3]  R2276     4.9765971302986145e-01
    z[8,9,3]  R2277     4.4825062155723572e-01
    z[8,9,3]  R2278     4.4120573997497559e-01
    z[8,9,3]  R2279     9.6951022744178772e-02
    z[8,9,3]  R2280     6.3274890184402466e-01
    z[8,9,3]  R2281     7.6028275489807129e-01
    z[8,9,3]  R2282     -3.6877706646919250e-02
    z[8,9,3]  R2283     -2.1236577630043030e-01
    z[8,9,3]  R2284     -2.8400555253028870e-01
    z[8,9,3]  R2285     -3.2647213339805603e-01
    z[8,9,3]  R2286     -3.6428447812795639e-02
    z[8,9,3]  R2287     -3.6264741420745850e-01
    z[8,9,3]  R2288     -4.7265359759330750e-01
    z[8,9,3]  R2289     -4.7184243798255920e-01
    z[8,9,3]  R2290     4.5467212796211243e-01
    z[8,9,3]  R2291     -7.5866356492042542e-02
    z[8,9,3]  R2292     1.8623191118240356e-01
    z[8,9,3]  R2293     -1.4141495525836945e-01
    z[8,9,3]  R2294     3.2630637288093567e-01
    z[8,9,3]  R2295     1.7457969486713409e-01
    z[8,9,3]  R2296     5.9118086099624634e-01
    z[8,9,3]  R2297     3.7921655178070068e-01
    z[8,9,3]  R2298     -7.4865147471427917e-02
    z[8,9,3]  R2299     4.3815410137176514e-01
    z[8,9,3]  R2300     1.6231262683868408e-01
    z[8,9,3]  R2301     7.2276329994201660e-01
    z[8,9,3]  R2302     -3.9736565947532654e-01
    z[8,9,3]  R2303     3.7152585387229919e-01
    z[8,9,3]  R2304     5.5104327201843262e-01
    z[8,9,3]  R2305     3.4945863485336304e-01
    z[8,9,3]  R2306     -1.7210496589541435e-02
    z[8,9,3]  R2307     4.3477201461791992e-01
    z[8,9,3]  R2308     8.3079628646373749e-02
    z[8,9,3]  R2309     7.0735722780227661e-02
    z[8,9,3]  R2310     8.2067184150218964e-02
    z[8,9,3]  R2311     3.2217529416084290e-01
    z[8,9,3]  R2312     -2.6893955469131470e-01
    z[8,9,3]  R2313     -1.4151706127449870e-03
    z[8,9,3]  R2314     3.4386447072029114e-01
    z[8,9,3]  R2315     8.5708731412887573e-01
    z[8,9,3]  R2316     2.5729832053184509e-01
    z[8,9,3]  R2317     2.5699369609355927e-02
    z[8,9,3]  R2318     0.627197265625
    z[8,9,3]  R2319     4.7050496935844421e-01
    z[8,9,3]  R2320     1.7863745987415314e-01
    z[8,9,3]  R2321     4.8613610863685608e-01
    z[8,9,3]  R2322     7.9316431283950806e-01
    z[8,9,3]  R2323     7.6619559526443481e-01
    z[8,9,3]  R2324     -4.2995044589042664e-01
    z[8,9,3]  R2325     3.6229613423347473e-01
    z[8,9,3]  R2326     -1.9225323200225830e-01
    z[8,9,3]  R2327     1.5171775221824646e-01
    z[8,9,3]  R2328     0.892119824886322
    z[8,9,3]  R2329     -4.1772323846817017e-01
    z[8,9,3]  R2330     3.9665955305099487e-01
    z[8,9,3]  R2331     -3.1335288076661527e-04
    z[8,9,3]  R2332     1.2308204174041748e-01
    z[8,9,3]  R2333     3.3044064044952393e-01
    z[8,9,3]  R2334     3.1732434034347534e-01
    z[8,9,3]  R2335     -6.2446214258670807e-02
    z[8,9,3]  R2336     -0.0313868410885334
    z[8,9,3]  R2337     -6.0916036367416382e-02
    z[8,9,3]  R2338     1.9142033159732819e-01
    z[8,9,3]  R2339     4.7483634203672409e-02
    z[8,9,3]  R2340     1.1565615981817245e-01
    z[8,9,3]  R2341     4.1282907128334045e-01
    z[8,9,3]  R2342     5.0725466012954712e-01
    z[8,9,3]  R2343     1.5332493185997009e-01
    z[8,9,3]  R2344     -1.2244151532649994e-01
    z[8,9,3]  R2345     1.3098880648612976e-01
    z[8,9,3]  R2346     2.2630952298641205e-01
    z[8,9,3]  R2347     -4.9962222576141357e-01
    z[8,9,3]  R2348     -1.8756206333637238e-01
    z[8,9,3]  R2349     1.8390727043151855e-01
    z[8,9,3]  R2350     5.0447350740432739e-01
    z[8,9,3]  R2351     -2.1160425245761871e-01
    z[8,9,3]  R2352     -3.9655330777168274e-01
    z[8,9,3]  R2353     6.8886585533618927e-02
    z[8,9,3]  R2354     1.8579009175300598e-01
    z[8,9,3]  R2355     7.5899370014667511e-02
    z[8,9,3]  R2356     2.8333681821823120e-01
    z[8,9,3]  R2357     3.2837271690368652e-01
    z[8,9,3]  R2358     -9.9064677953720093e-02
    z[8,9,3]  R2359     2.5260293483734131e-01
    z[8,9,3]  R2360     2.0337322354316711e-01
    z[8,9,3]  R2361     5.3373761475086212e-02
    z[8,9,3]  R2362     4.5152485370635986e-01
    z[8,9,3]  R2363     3.2599920034408569e-01
    z[8,9,3]  R2364     -2.1406471729278564e-01
    z[8,9,3]  R2365     1.4406421780586243e-01
    z[8,9,3]  R2366     7.9791283607482910e-01
    z[8,9,3]  R2367     -5.7614302635192871e-01
    z[8,9,3]  R2368     -3.7967890501022339e-01
    z[8,9,3]  R2369     -1.8653295934200287e-01
    z[8,9,3]  R2370     -9.2315798997879028e-01
    z[8,9,3]  R2371     3.3459299802780151e-01
    z[8,9,3]  R2372     8.7592297792434692e-01
    z[8,9,3]  R2373     2.8328070044517517e-01
    z[8,9,3]  R2374     3.9715844392776489e-01
    z[8,9,3]  R2375     2.5570935010910034e-01
    z[8,9,3]  R2376     2.0916453003883362e-01
    z[8,9,3]  R2377     -1.6822256147861481e-01
    z[8,9,3]  R2378     6.4203584194183350e-01
    z[8,9,3]  R2379     1.5802358090877533e-01
    z[8,9,3]  R2380     -7.8423309326171875e-01
    z[8,9,3]  R2381     -2.1199563145637512e-01
    z[8,9,3]  R2382     -6.7315685749053955e-01
    z[8,9,3]  R2383     3.1995415687561035e-01
    z[8,9,3]  R2384     4.2300209403038025e-01
    z[8,9,3]  R2385     7.8073817491531372e-01
    z[8,9,3]  R2386     4.8033601045608521e-01
    z[8,9,3]  R2387     4.6407714486122131e-01
    z[8,9,3]  R2388     4.0075761079788208e-01
    z[8,9,3]  R2389     -0.0906476080417633
    z[8,9,3]  R2390     2.5016140937805176e-01
    z[8,9,3]  R2391     -7.0939630270004272e-01
    z[8,9,3]  R2392     -7.0446836948394775e-01
    z[8,9,3]  R2393     4.7615560889244080e-01
    z[8,9,3]  R2394     3.6661583185195923e-01
    z[8,9,3]  R2395     6.3652658462524414e-01
    z[8,9,3]  R2396     6.4629054069519043e-01
    z[8,9,3]  R2397     6.1970251798629761e-01
    z[8,9,3]  R2398     6.5345507860183716e-01
    z[8,9,3]  R2399     -2.6025879383087158e-01
    z[8,9,3]  R2400     0.534384548664093
    z[8,9,3]  R2401     6.1577588319778442e-01
    z[8,9,3]  R2402     4.0714344382286072e-01
    z[8,9,3]  R2403     5.9882515668869019e-01
    z[8,9,3]  R2404     6.3399654626846313e-01
    z[8,9,3]  R2405     3.2498005032539368e-01
    z[8,9,3]  R2406     8.8929927349090576e-01
    z[8,9,3]  R2407     8.9148283004760742e-01
    z[8,9,3]  R2408     6.5901094675064087e-01
    z[8,9,3]  R2409     3.6119830608367920e-01
    z[8,9,3]  R2410     8.6791312694549561e-01
    z[8,9,3]  R2411     5.4483503103256226e-01
    z[8,9,3]  R2412     -6.0689771175384521e-01
    z[8,9,3]  R2413     0.537681519985199
    z[8,9,3]  R2414     -4.3805586174130440e-03
    z[8,9,3]  R2415     -9.8440952599048615e-02
    z[8,9,3]  R2416     -2.0977884531021118e-01
    z[8,9,3]  R2417     -1.1612334847450256e-01
    z[8,9,3]  R2418     -1.5409705042839050e-01
    z[8,9,3]  R2419     -1.6119350492954254e-01
    z[8,9,3]  R2420     -7.1217817068099976e-01
    z[8,9,3]  R2421     5.0207132101058960e-01
    z[8,9,3]  R2422     5.9529662132263184e-01
    z[8,9,3]  R2423     3.0756023526191711e-01
    z[8,9,3]  R2424     6.9351297616958618e-01
    z[8,9,3]  R2425     2.3969364166259766e-01
    z[8,9,3]  R2426     1.3161744177341461e-01
    z[8,9,3]  R2427     -1.8077501654624939e-01
    z[8,9,3]  R2428     -4.7149181365966797e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2265     -1
    z[8,9,4]  R2266     1
    z[8,9,4]  R2271     -2.1748287975788116e-01
    z[8,9,4]  R2272     -5.6903768330812454e-02
    z[8,9,4]  R2273     -0.0574452243745327
    z[8,9,4]  R2274     -2.6986968517303467e-01
    z[8,9,4]  R2275     4.9347940832376480e-02
    z[8,9,4]  R2276     1.8177621066570282e-02
    z[8,9,4]  R2277     1.0496149957180023e-01
    z[8,9,4]  R2278     -1.0570524632930756e-01
    z[8,9,4]  R2279     -5.3320780396461487e-02
    z[8,9,4]  R2280     -3.2039427757263184e-01
    z[8,9,4]  R2281     -9.1939605772495270e-02
    z[8,9,4]  R2282     7.3073320090770721e-02
    z[8,9,4]  R2283     3.6314350366592407e-01
    z[8,9,4]  R2284     3.4748658537864685e-01
    z[8,9,4]  R2285     1.0689140111207962e-01
    z[8,9,4]  R2286     2.5803259015083313e-01
    z[8,9,4]  R2287     0.014848074875772
    z[8,9,4]  R2288     6.9001503288745880e-02
    z[8,9,4]  R2289     3.1547278165817261e-01
    z[8,9,4]  R2290     -7.0220857858657837e-01
    z[8,9,4]  R2291     -5.0553835928440094e-02
    z[8,9,4]  R2292     -3.8211759924888611e-01
    z[8,9,4]  R2293     2.9748806357383728e-01
    z[8,9,4]  R2294     3.0938872694969177e-01
    z[8,9,4]  R2295     -2.2808396816253662e-01
    z[8,9,4]  R2296     5.9838145971298218e-01
    z[8,9,4]  R2297     5.1360901445150375e-02
    z[8,9,4]  R2298     -2.9469090700149536e-01
    z[8,9,4]  R2299     6.3740663230419159e-02
    z[8,9,4]  R2300     -5.0611924380064011e-02
    z[8,9,4]  R2301     2.7012842893600464e-01
    z[8,9,4]  R2302     2.4763178080320358e-02
    z[8,9,4]  R2303     -4.5352885127067566e-01
    z[8,9,4]  R2304     -4.9569332599639893e-01
    z[8,9,4]  R2305     -1.3083736598491669e-01
    z[8,9,4]  R2306     -2.7934324741363525e-01
    z[8,9,4]  R2307     -2.4890260398387909e-01
    z[8,9,4]  R2308     4.3951147794723511e-01
    z[8,9,4]  R2309     -5.2005261182785034e-01
    z[8,9,4]  R2310     -5.2744048833847046e-01
    z[8,9,4]  R2311     -1.5415717661380768e-01
    z[8,9,4]  R2312     -2.0392365753650665e-01
    z[8,9,4]  R2313     -1.3303364813327789e-01
    z[8,9,4]  R2314     1.4022152125835419e-01
    z[8,9,4]  R2315     2.6859796047210693e-01
    z[8,9,4]  R2316     0.272236168384552
    z[8,9,4]  R2317     9.5518708229064941e-02
    z[8,9,4]  R2318     5.6548561900854111e-02
    z[8,9,4]  R2319     -2.4783669412136078e-01
    z[8,9,4]  R2320     1.7186237871646881e-01
    z[8,9,4]  R2321     -1.0055442899465561e-01
    z[8,9,4]  R2322     1.6592821478843689e-01
    z[8,9,4]  R2323     -2.9397532343864441e-02
    z[8,9,4]  R2324     4.6979844570159912e-02
    z[8,9,4]  R2325     -1.2716351449489594e-01
    z[8,9,4]  R2326     -4.4760741293430328e-02
    z[8,9,4]  R2327     2.2285891696810722e-02
    z[8,9,4]  R2328     -1.9680918753147125e-01
    z[8,9,4]  R2329     9.7770921885967255e-02
    z[8,9,4]  R2330     -2.7405008673667908e-01
    z[8,9,4]  R2331     1.4631024003028870e-01
    z[8,9,4]  R2332     -1.8064735829830170e-01
    z[8,9,4]  R2333     -3.1060841679573059e-01
    z[8,9,4]  R2334     -1.6298873722553253e-01
    z[8,9,4]  R2335     -2.9918268322944641e-01
    z[8,9,4]  R2336     -3.9690437912940979e-01
    z[8,9,4]  R2337     2.8621044754981995e-01
    z[8,9,4]  R2338     -3.2313957810401917e-02
    z[8,9,4]  R2339     -3.3583962917327881e-01
    z[8,9,4]  R2340     3.2931387424468994e-01
    z[8,9,4]  R2341     -1.1051273345947266e-01
    z[8,9,4]  R2342     1.2172869592905045e-01
    z[8,9,4]  R2343     -3.1887373328208923e-01
    z[8,9,4]  R2344     -1.2618668377399445e-01
    z[8,9,4]  R2345     3.1021785736083984e-01
    z[8,9,4]  R2346     -1.8007430434226990e-01
    z[8,9,4]  R2347     5.1927787065505981e-01
    z[8,9,4]  R2348     -0.198231503367424
    z[8,9,4]  R2349     -4.4913059473037720e-01
    z[8,9,4]  R2350     -7.4144983291625977e-01
    z[8,9,4]  R2351     2.5618669390678406e-01
    z[8,9,4]  R2352     -1.0460326820611954e-01
    z[8,9,4]  R2353     -8.8932946324348450e-02
    z[8,9,4]  R2354     -3.7543994188308716e-01
    z[8,9,4]  R2355     -5.5314081907272339e-01
    z[8,9,4]  R2356     -3.0125668644905090e-01
    z[8,9,4]  R2357     1.9281382858753204e-01
    z[8,9,4]  R2358     -1.4993591606616974e-01
    z[8,9,4]  R2359     6.6682964563369751e-01
    z[8,9,4]  R2360     4.2104795575141907e-01
    z[8,9,4]  R2361     -3.9963263273239136e-01
    z[8,9,4]  R2362     -1.9065174460411072e-01
    z[8,9,4]  R2363     1.6308404505252838e-01
    z[8,9,4]  R2364     1.7770475149154663e-01
    z[8,9,4]  R2365     -6.0246824286878109e-03
    z[8,9,4]  R2366     3.9743125438690186e-02
    z[8,9,4]  R2367     -4.7841039299964905e-01
    z[8,9,4]  R2368     -2.6570683717727661e-01
    z[8,9,4]  R2369     2.2985085844993591e-01
    z[8,9,4]  R2370     -9.5314718782901764e-02
    z[8,9,4]  R2371     -3.1862157583236694e-01
    z[8,9,4]  R2372     -2.0755660533905029e-01
    z[8,9,4]  R2373     8.5939332842826843e-02
    z[8,9,4]  R2374     -5.2346813678741455e-01
    z[8,9,4]  R2375     -5.2218484878540039e-01
    z[8,9,4]  R2376     -2.5616351515054703e-02
    z[8,9,4]  R2377     7.9321271181106567e-01
    z[8,9,4]  R2378     2.3815500736236572e-01
    z[8,9,4]  R2379     4.6793961524963379e-01
    z[8,9,4]  R2380     3.7247157096862793e-01
    z[8,9,4]  R2381     6.3064676523208618e-01
    z[8,9,4]  R2382     4.4290821999311447e-02
    z[8,9,4]  R2383     -6.1709702014923096e-02
    z[8,9,4]  R2384     -1.6679541766643524e-01
    z[8,9,4]  R2385     3.7073069810867310e-01
    z[8,9,4]  R2386     4.6271455287933350e-01
    z[8,9,4]  R2387     1.9478730857372284e-01
    z[8,9,4]  R2388     2.6884219050407410e-01
    z[8,9,4]  R2389     8.4355793893337250e-02
    z[8,9,4]  R2390     5.5109471082687378e-01
    z[8,9,4]  R2391     -5.9672966599464417e-02
    z[8,9,4]  R2392     1.2610065937042236e-01
    z[8,9,4]  R2393     -2.6534751057624817e-01
    z[8,9,4]  R2394     4.6184204518795013e-02
    z[8,9,4]  R2395     -4.9820181727409363e-01
    z[8,9,4]  R2396     2.9514145851135254e-01
    z[8,9,4]  R2397     -3.4078621864318848e-01
    z[8,9,4]  R2398     -6.3860282301902771e-02
    z[8,9,4]  R2399     3.5076424479484558e-01
    z[8,9,4]  R2400     1.1089966446161270e-01
    z[8,9,4]  R2401     -6.5157525241374969e-02
    z[8,9,4]  R2402     -1.3002167642116547e-01
    z[8,9,4]  R2403     -2.2800201550126076e-02
    z[8,9,4]  R2404     2.7837478555738926e-03
    z[8,9,4]  R2405     -2.3730394244194031e-01
    z[8,9,4]  R2406     4.9583122134208679e-02
    z[8,9,4]  R2407     -3.3296641707420349e-01
    z[8,9,4]  R2408     0.0236127357929945
    z[8,9,4]  R2409     1.0640777647495270e-01
    z[8,9,4]  R2410     -2.2715452313423157e-01
    z[8,9,4]  R2411     1.9060926139354706e-01
    z[8,9,4]  R2412     -1.9961050152778625e-01
    z[8,9,4]  R2413     2.6911211013793945e-01
    z[8,9,4]  R2414     -5.5291861295700073e-01
    z[8,9,4]  R2415     2.8804585337638855e-01
    z[8,9,4]  R2416     2.6697701215744019e-01
    z[8,9,4]  R2417     2.4555821716785431e-01
    z[8,9,4]  R2418     3.5698929429054260e-01
    z[8,9,4]  R2419     1.2138537317514420e-01
    z[8,9,4]  R2420     -4.9574777483940125e-02
    z[8,9,4]  R2421     -1.7861866950988770e-01
    z[8,9,4]  R2422     -8.1913277506828308e-02
    z[8,9,4]  R2423     -9.4367057085037231e-02
    z[8,9,4]  R2424     4.9848115444183350e-01
    z[8,9,4]  R2425     -1.5069586038589478e-01
    z[8,9,4]  R2426     -5.4800641536712646e-01
    z[8,9,4]  R2427     2.6543119549751282e-01
    z[8,9,4]  R2428     2.0664992928504944e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2267     -1
    z[8,9,5]  R2268     1
    z[8,9,5]  R2271     -6.5225899219512939e-01
    z[8,9,5]  R2272     -1.0487017780542374e-01
    z[8,9,5]  R2273     1.6407051682472229e-01
    z[8,9,5]  R2274     -2.5416249036788940e-01
    z[8,9,5]  R2275     8.9542150497436523e-02
    z[8,9,5]  R2276     -1.5008129179477692e-01
    z[8,9,5]  R2277     -4.2632433772087097e-01
    z[8,9,5]  R2278     -4.1950282454490662e-01
    z[8,9,5]  R2279     -3.0137532949447632e-01
    z[8,9,5]  R2280     -4.6895641088485718e-01
    z[8,9,5]  R2281     7.9206518828868866e-02
    z[8,9,5]  R2282     2.2923554480075836e-01
    z[8,9,5]  R2283     -2.7379798889160156e-01
    z[8,9,5]  R2284     -2.3873747885227203e-01
    z[8,9,5]  R2285     -6.5112107992172241e-01
    z[8,9,5]  R2286     -4.5467257499694824e-01
    z[8,9,5]  R2287     -4.2832094430923462e-01
    z[8,9,5]  R2288     -2.2712954878807068e-01
    z[8,9,5]  R2289     -3.4039071202278137e-01
    z[8,9,5]  R2290     3.0946722626686096e-01
    z[8,9,5]  R2291     3.9994516968727112e-01
    z[8,9,5]  R2292     1.6013096272945404e-01
    z[8,9,5]  R2293     1.6711945831775665e-01
    z[8,9,5]  R2294     -2.1236881613731384e-01
    z[8,9,5]  R2295     -0.656708300113678
    z[8,9,5]  R2296     -4.6250590682029724e-01
    z[8,9,5]  R2297     3.4696620702743530e-01
    z[8,9,5]  R2298     -3.6067828536033630e-01
    z[8,9,5]  R2299     -2.3430296778678894e-01
    z[8,9,5]  R2300     -8.6028032004833221e-02
    z[8,9,5]  R2301     -4.0161529183387756e-01
    z[8,9,5]  R2302     3.9787840843200684e-01
    z[8,9,5]  R2303     -2.2953392565250397e-01
    z[8,9,5]  R2304     -4.5798502862453461e-02
    z[8,9,5]  R2305     -3.5307437181472778e-01
    z[8,9,5]  R2306     5.3968578577041626e-01
    z[8,9,5]  R2307     3.3117014169692993e-01
    z[8,9,5]  R2308     4.7005578875541687e-01
    z[8,9,5]  R2309     4.3799132108688354e-01
    z[8,9,5]  R2310     -6.3618764281272888e-02
    z[8,9,5]  R2311     -8.2405406236648560e-01
    z[8,9,5]  R2312     1.9800260663032532e-01
    z[8,9,5]  R2313     5.0412613153457642e-01
    z[8,9,5]  R2314     -5.0805461406707764e-01
    z[8,9,5]  R2315     3.7181344814598560e-03
    z[8,9,5]  R2316     2.9719021916389465e-01
    z[8,9,5]  R2317     2.3098704218864441e-01
    z[8,9,5]  R2318     -2.0979806780815125e-01
    z[8,9,5]  R2319     -1.5571042895317078e-01
    z[8,9,5]  R2320     -2.1392270922660828e-01
    z[8,9,5]  R2321     -6.9061291217803955e-01
    z[8,9,5]  R2322     -2.8672060370445251e-01
    z[8,9,5]  R2323     -3.4048205614089966e-01
    z[8,9,5]  R2324     -1.7928700149059296e-01
    z[8,9,5]  R2325     -7.5652748346328735e-02
    z[8,9,5]  R2326     1.7019577324390411e-01
    z[8,9,5]  R2327     -4.0748879313468933e-01
    z[8,9,5]  R2328     5.4188175126910210e-03
    z[8,9,5]  R2329     -4.3096852302551270e-01
    z[8,9,5]  R2330     2.1025471389293671e-01
    z[8,9,5]  R2331     -3.4225851297378540e-01
    z[8,9,5]  R2332     -2.2261887788772583e-01
    z[8,9,5]  R2333     -3.7638089060783386e-01
    z[8,9,5]  R2334     3.6430227756500244e-01
    z[8,9,5]  R2335     6.5975874662399292e-01
    z[8,9,5]  R2336     5.1600843667984009e-01
    z[8,9,5]  R2337     3.8433954119682312e-01
    z[8,9,5]  R2338     1.9256788492202759e-01
    z[8,9,5]  R2339     -4.2669618129730225e-01
    z[8,9,5]  R2340     5.8736038208007812e-01
    z[8,9,5]  R2341     -6.5819948911666870e-01
    z[8,9,5]  R2342     -7.7228508889675140e-02
    z[8,9,5]  R2343     -3.1256824731826782e-01
    z[8,9,5]  R2344     2.6809409260749817e-01
    z[8,9,5]  R2345     -1.7583874985575676e-02
    z[8,9,5]  R2346     -1.0468696802854538e-01
    z[8,9,5]  R2347     -1.9151781499385834e-01
    z[8,9,5]  R2348     -5.7094257324934006e-02
    z[8,9,5]  R2349     -0.263357013463974
    z[8,9,5]  R2350     7.4967904947698116e-03
    z[8,9,5]  R2351     -0.0255416352301836
    z[8,9,5]  R2352     3.8038536906242371e-01
    z[8,9,5]  R2353     2.9868012666702271e-01
    z[8,9,5]  R2354     -7.8571937978267670e-02
    z[8,9,5]  R2355     -2.2287155687808990e-01
    z[8,9,5]  R2356     -1.0560614988207817e-02
    z[8,9,5]  R2357     0.505304753780365
    z[8,9,5]  R2358     7.6099641621112823e-02
    z[8,9,5]  R2359     -3.4238103032112122e-01
    z[8,9,5]  R2360     2.7827474474906921e-01
    z[8,9,5]  R2361     -2.9786482453346252e-01
    z[8,9,5]  R2362     1.5181696973741055e-02
    z[8,9,5]  R2363     -1.6975127160549164e-01
    z[8,9,5]  R2364     -4.0652045607566833e-01
    z[8,9,5]  R2365     -3.2270747423171997e-01
    z[8,9,5]  R2366     1.8104752898216248e-01
    z[8,9,5]  R2367     5.0167441368103027e-01
    z[8,9,5]  R2368     2.3916438221931458e-01
    z[8,9,5]  R2369     6.8354773521423340e-01
    z[8,9,5]  R2370     1.2156743556261063e-01
    z[8,9,5]  R2371     -7.2249794006347656e-01
    z[8,9,5]  R2372     -1.2243092805147171e-01
    z[8,9,5]  R2373     -7.5230067968368530e-01
    z[8,9,5]  R2374     -6.4105218648910522e-01
    z[8,9,5]  R2375     -4.6413314342498779e-01
    z[8,9,5]  R2376     -6.1697411537170410e-01
    z[8,9,5]  R2377     2.6064833998680115e-01
    z[8,9,5]  R2378     -2.2591555118560791e-01
    z[8,9,5]  R2379     -4.9055758118629456e-01
    z[8,9,5]  R2380     1.9934152066707611e-01
    z[8,9,5]  R2381     2.4682748317718506e-01
    z[8,9,5]  R2382     -0.664214015007019
    z[8,9,5]  R2383     -7.1010160446166992e-01
    z[8,9,5]  R2384     -5.5496370792388916e-01
    z[8,9,5]  R2385     -3.6890843510627747e-01
    z[8,9,5]  R2386     4.3439719080924988e-01
    z[8,9,5]  R2387     -2.9076570272445679e-01
    z[8,9,5]  R2388     -3.8497292995452881e-01
    z[8,9,5]  R2389     -3.9543408155441284e-01
    z[8,9,5]  R2390     0.0978158637881279
    z[8,9,5]  R2391     -1.6848985850811005e-01
    z[8,9,5]  R2392     0.236422598361969
    z[8,9,5]  R2393     -7.4039202928543091e-01
    z[8,9,5]  R2394     -7.2094070911407471e-01
    z[8,9,5]  R2395     -3.1968402862548828e-01
    z[8,9,5]  R2396     -5.0114977359771729e-01
    z[8,9,5]  R2397     -3.0594348907470703e-01
    z[8,9,5]  R2398     2.2888499498367310e-01
    z[8,9,5]  R2399     4.2588862776756287e-01
    z[8,9,5]  R2400     -6.3209319114685059e-01
    z[8,9,5]  R2401     -4.0558010339736938e-01
    z[8,9,5]  R2402     -6.3632673025131226e-01
    z[8,9,5]  R2403     -1.9038234651088715e-01
    z[8,9,5]  R2404     -5.6710356473922729e-01
    z[8,9,5]  R2405     -5.7302755117416382e-01
    z[8,9,5]  R2406     -4.0226092934608459e-01
    z[8,9,5]  R2407     -2.1952791512012482e-01
    z[8,9,5]  R2408     -2.9151713848114014e-01
    z[8,9,5]  R2409     0.431945264339447
    z[8,9,5]  R2410     -2.8299632668495178e-01
    z[8,9,5]  R2411     -2.0611369609832764e-01
    z[8,9,5]  R2412     4.3252494931221008e-01
    z[8,9,5]  R2413     -6.3303405046463013e-01
    z[8,9,5]  R2414     0.0892023965716362
    z[8,9,5]  R2415     1.5050472319126129e-01
    z[8,9,5]  R2416     -8.9196033775806427e-02
    z[8,9,5]  R2417     2.2232902050018311e-01
    z[8,9,5]  R2418     -1.8899044394493103e-01
    z[8,9,5]  R2419     -3.0630609393119812e-01
    z[8,9,5]  R2420     2.9824903607368469e-01
    z[8,9,5]  R2421     -5.4416441917419434e-01
    z[8,9,5]  R2422     -3.9944788813591003e-01
    z[8,9,5]  R2423     -5.8354437351226807e-01
    z[8,9,5]  R2424     -3.1988191604614258e-01
    z[8,9,5]  R2425     -1.0568533092737198e-02
    z[8,9,5]  R2426     -3.8195142149925232e-01
    z[8,9,5]  R2427     3.2803717255592346e-01
    z[8,9,5]  R2428     1.1291011422872543e-01
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2269     -1
    z[8,9,6]  R2270     1
    z[8,9,6]  R2271     -1.3175633549690247e-01
    z[8,9,6]  R2272     1.5665335953235626e-01
    z[8,9,6]  R2273     5.2384608983993530e-01
    z[8,9,6]  R2274     6.6977924108505249e-01
    z[8,9,6]  R2275     -2.2763228416442871e-01
    z[8,9,6]  R2276     2.8818333521485329e-02
    z[8,9,6]  R2277     4.9332848191261292e-01
    z[8,9,6]  R2278     2.4070571362972260e-01
    z[8,9,6]  R2279     -7.6405160129070282e-02
    z[8,9,6]  R2280     3.3910922706127167e-02
    z[8,9,6]  R2281     -5.6884109973907471e-01
    z[8,9,6]  R2282     3.9632487297058105e-01
    z[8,9,6]  R2283     -1.7966100573539734e-01
    z[8,9,6]  R2284     -0.0784110277891159
    z[8,9,6]  R2285     1.2755751609802246e-01
    z[8,9,6]  R2286     -0.190152108669281
    z[8,9,6]  R2287     -1.0380861163139343e-01
    z[8,9,6]  R2288     -4.7682128846645355e-02
    z[8,9,6]  R2289     2.1728739142417908e-01
    z[8,9,6]  R2290     2.1173125505447388e-01
    z[8,9,6]  R2291     -5.3208328783512115e-02
    z[8,9,6]  R2292     2.3521710932254791e-01
    z[8,9,6]  R2293     -2.6275765895843506e-01
    z[8,9,6]  R2294     9.0591244399547577e-02
    z[8,9,6]  R2295     0.00939799565821886
    z[8,9,6]  R2296     1.2457884848117828e-01
    z[8,9,6]  R2297     1.3694353401660919e-01
    z[8,9,6]  R2298     -2.0731341838836670e-01
    z[8,9,6]  R2299     -2.3764740675687790e-02
    z[8,9,6]  R2300     -4.9654132127761841e-01
    z[8,9,6]  R2301     -4.4730773568153381e-01
    z[8,9,6]  R2302     -1.4911796152591705e-01
    z[8,9,6]  R2303     -5.2431887388229370e-01
    z[8,9,6]  R2304     3.0611521005630493e-01
    z[8,9,6]  R2305     -4.4138675928115845e-01
    z[8,9,6]  R2306     7.2807647287845612e-02
    z[8,9,6]  R2307     -3.8419792056083679e-01
    z[8,9,6]  R2308     -2.8833723068237305e-01
    z[8,9,6]  R2309     -2.2672960162162781e-01
    z[8,9,6]  R2310     5.2644795179367065e-01
    z[8,9,6]  R2311     -3.2018184661865234e-01
    z[8,9,6]  R2312     -1.7275755107402802e-01
    z[8,9,6]  R2313     2.3491667211055756e-01
    z[8,9,6]  R2314     2.8786253929138184e-01
    z[8,9,6]  R2315     0.0482945442199707
    z[8,9,6]  R2316     -4.1684368252754211e-01
    z[8,9,6]  R2317     -2.6613765954971313e-01
    z[8,9,6]  R2318     -4.2893379926681519e-01
    z[8,9,6]  R2319     -2.9815217852592468e-01
    z[8,9,6]  R2320     5.0212317705154419e-01
    z[8,9,6]  R2321     3.9354014396667480e-01
    z[8,9,6]  R2322     9.1656424105167389e-02
    z[8,9,6]  R2323     -2.4070023000240326e-01
    z[8,9,6]  R2324     -0.325311541557312
    z[8,9,6]  R2325     -2.5049161911010742e-01
    z[8,9,6]  R2326     4.4305855035781860e-01
    z[8,9,6]  R2327     -3.9032322168350220e-01
    z[8,9,6]  R2328     2.7816012501716614e-01
    z[8,9,6]  R2329     2.6311546564102173e-01
    z[8,9,6]  R2330     -1.1615970730781555e-01
    z[8,9,6]  R2331     2.7570804953575134e-01
    z[8,9,6]  R2332     -1.5641090273857117e-01
    z[8,9,6]  R2333     -1.8282571434974670e-01
    z[8,9,6]  R2334     -3.7996169924736023e-01
    z[8,9,6]  R2335     4.2082633823156357e-02
    z[8,9,6]  R2336     2.8814616799354553e-01
    z[8,9,6]  R2337     3.2460793852806091e-02
    z[8,9,6]  R2338     2.6251126546412706e-03
    z[8,9,6]  R2339     2.4456915259361267e-01
    z[8,9,6]  R2340     1.1607024818658829e-01
    z[8,9,6]  R2341     -4.3984800577163696e-01
    z[8,9,6]  R2342     5.9148907661437988e-02
    z[8,9,6]  R2343     2.5324997305870056e-01
    z[8,9,6]  R2344     -3.0960096046328545e-02
    z[8,9,6]  R2345     -3.7550774216651917e-01
    z[8,9,6]  R2346     -3.1864714622497559e-01
    z[8,9,6]  R2347     -7.7630870044231415e-02
    z[8,9,6]  R2348     1.1627739667892456e-01
    z[8,9,6]  R2349     3.2463806867599487e-01
    z[8,9,6]  R2350     6.4279779791831970e-02
    z[8,9,6]  R2351     -5.8681093156337738e-02
    z[8,9,6]  R2352     3.7266245484352112e-01
    z[8,9,6]  R2353     2.5364753603935242e-01
    z[8,9,6]  R2354     -2.3666703701019287e-01
    z[8,9,6]  R2355     5.1761954091489315e-04
    z[8,9,6]  R2356     -2.3464260995388031e-01
    z[8,9,6]  R2357     2.6170909404754639e-03
    z[8,9,6]  R2358     -4.1718250513076782e-01
    z[8,9,6]  R2359     -2.9475545883178711e-01
    z[8,9,6]  R2360     -7.0257700979709625e-02
    z[8,9,6]  R2361     9.0677961707115173e-02
    z[8,9,6]  R2362     -4.0827459096908569e-01
    z[8,9,6]  R2363     -5.8025825768709183e-02
    z[8,9,6]  R2364     4.2708155512809753e-01
    z[8,9,6]  R2365     -4.3588000535964966e-01
    z[8,9,6]  R2366     -2.5381874293088913e-02
    z[8,9,6]  R2367     -1.1201821267604828e-01
    z[8,9,6]  R2368     -5.7448309659957886e-01
    z[8,9,6]  R2369     -2.3888534307479858e-01
    z[8,9,6]  R2370     -2.1509103477001190e-01
    z[8,9,6]  R2371     -2.9075646400451660e-01
    z[8,9,6]  R2372     -1.8486784771084785e-02
    z[8,9,6]  R2373     0.271684855222702
    z[8,9,6]  R2374     -2.7988600730895996e-01
    z[8,9,6]  R2375     -2.2420364618301392e-01
    z[8,9,6]  R2376     2.8579053282737732e-01
    z[8,9,6]  R2377     2.6356074213981628e-01
    z[8,9,6]  R2378     6.6798651218414307e-01
    z[8,9,6]  R2379     -7.2378120385110378e-03
    z[8,9,6]  R2380     1.7126396298408508e-01
    z[8,9,6]  R2381     2.7689644694328308e-01
    z[8,9,6]  R2382     -4.5411635190248489e-02
    z[8,9,6]  R2383     2.3220393061637878e-01
    z[8,9,6]  R2384     4.9505755305290222e-01
    z[8,9,6]  R2385     -3.1286051869392395e-01
    z[8,9,6]  R2386     0.366493284702301
    z[8,9,6]  R2387     -7.5198292732238770e-02
    z[8,9,6]  R2388     6.3373708724975586e-01
    z[8,9,6]  R2389     0.578849732875824
    z[8,9,6]  R2390     2.9332116246223450e-01
    z[8,9,6]  R2391     -3.8576591014862061e-01
    z[8,9,6]  R2392     -4.2447996139526367e-01
    z[8,9,6]  R2393     2.0087754726409912e-01
    z[8,9,6]  R2394     -1.8044428527355194e-01
    z[8,9,6]  R2395     1.0024210065603256e-01
    z[8,9,6]  R2396     1.5175281465053558e-01
    z[8,9,6]  R2397     -3.4700337052345276e-01
    z[8,9,6]  R2398     1.2395840138196945e-01
    z[8,9,6]  R2399     -1.2176579236984253e-01
    z[8,9,6]  R2400     2.6281037926673889e-01
    z[8,9,6]  R2401     7.6603099703788757e-02
    z[8,9,6]  R2402     -2.5848224759101868e-01
    z[8,9,6]  R2403     -2.7331728488206863e-02
    z[8,9,6]  R2404     1.7281077802181244e-02
    z[8,9,6]  R2405     -3.5236570239067078e-01
    z[8,9,6]  R2406     1.5219584107398987e-01
    z[8,9,6]  R2407     -9.6638485789299011e-02
    z[8,9,6]  R2408     -4.5479765534400940e-01
    z[8,9,6]  R2409     0.0490252859890461
    z[8,9,6]  R2410     1.2319782376289368e-01
    z[8,9,6]  R2411     -3.0960068106651306e-02
    z[8,9,6]  R2412     -4.3277588486671448e-01
    z[8,9,6]  R2413     -1.4188045263290405e-01
    z[8,9,6]  R2414     1.3368442654609680e-01
    z[8,9,6]  R2415     -1.2499737739562988e-01
    z[8,9,6]  R2416     -1.5704806149005890e-01
    z[8,9,6]  R2417     2.5493544340133667e-01
    z[8,9,6]  R2418     0.0582747608423233
    z[8,9,6]  R2419     -2.8421500325202942e-01
    z[8,9,6]  R2420     -3.8688236474990845e-01
    z[8,9,6]  R2421     1.7495671287178993e-02
    z[8,9,6]  R2422     -1.6256733238697052e-01
    z[8,9,6]  R2423     4.0815880894660950e-01
    z[8,9,6]  R2424     2.1923069655895233e-01
    z[8,9,6]  R2425     2.5234758853912354e-01
    z[8,9,6]  R2426     -9.7453787922859192e-02
    z[8,9,6]  R2427     1.0200767777860165e-02
    z[8,9,6]  R2428     -4.6653822064399719e-02
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2429     -1
    z[9,8,0]  R2430     1
    z[9,8,0]  R2443     -7.1938061714172363e-01
    z[9,8,0]  R2444     -7.3434668779373169e-01
    z[9,8,0]  R2445     -8.7153381109237671e-01
    z[9,8,0]  R2446     3.9826877415180206e-02
    z[9,8,0]  R2447     4.2995803058147430e-02
    z[9,8,0]  R2448     2.3911140859127045e-02
    z[9,8,0]  R2449     6.6440761089324951e-02
    z[9,8,0]  R2450     -0.0642852932214737
    z[9,8,0]  R2451     1.2891144491732121e-02
    z[9,8,0]  R2452     1.9521045684814453e-01
    z[9,8,0]  R2453     1.8371686339378357e-01
    z[9,8,0]  R2454     3.2115471363067627e-01
    z[9,8,0]  R2455     1.8859191238880157e-01
    z[9,8,0]  R2456     1.8353742361068726e-01
    z[9,8,0]  R2457     2.9240572452545166e-01
    z[9,8,0]  R2458     8.1658527255058289e-02
    z[9,8,0]  R2459     1.1317206174135208e-01
    z[9,8,0]  R2460     -1.2729771435260773e-02
    z[9,8,0]  R2461     1.7303159832954407e-01
    z[9,8,0]  R2462     -1.5301170945167542e-01
    z[9,8,0]  R2463     2.3762527108192444e-01
    z[9,8,0]  R2464     -0.0158318392932415
    z[9,8,0]  R2465     3.9074033498764038e-01
    z[9,8,0]  R2466     2.6645278930664062e-01
    z[9,8,0]  R2467     9.1636814177036285e-02
    z[9,8,0]  R2468     -2.0787367224693298e-01
    z[9,8,0]  R2469     4.5522534847259521e-01
    z[9,8,0]  R2470     0.441200852394104
    z[9,8,0]  R2471     -2.7625164017081261e-02
    z[9,8,0]  R2472     -3.2364460825920105e-01
    z[9,8,0]  R2473     -2.3119792342185974e-01
    z[9,8,0]  R2474     2.4720193445682526e-01
    z[9,8,0]  R2475     2.4882322549819946e-01
    z[9,8,0]  R2476     3.7292793393135071e-01
    z[9,8,0]  R2477     1.8218696117401123e-01
    z[9,8,0]  R2478     1.3982728123664856e-01
    z[9,8,0]  R2479     4.4310668110847473e-01
    z[9,8,0]  R2480     -2.5280886888504028e-01
    z[9,8,0]  R2481     2.0975257456302643e-01
    z[9,8,0]  R2482     4.5805528759956360e-01
    z[9,8,0]  R2483     -1.5050864778459072e-02
    z[9,8,0]  R2484     3.5582253336906433e-01
    z[9,8,0]  R2485     5.5501270294189453e-01
    z[9,8,0]  R2486     4.5985287427902222e-01
    z[9,8,0]  R2487     1.1087729036808014e-01
    z[9,8,0]  R2488     1.2989985942840576e-01
    z[9,8,0]  R2489     1.1822313815355301e-01
    z[9,8,0]  R2490     2.2202843427658081e-01
    z[9,8,0]  R2491     -2.5484177470207214e-01
    z[9,8,0]  R2492     1.3983985781669617e-01
    z[9,8,0]  R2493     6.1186897754669189e-01
    z[9,8,0]  R2494     0.0938342809677124
    z[9,8,0]  R2495     3.5296627879142761e-01
    z[9,8,0]  R2496     -1.8386578187346458e-02
    z[9,8,0]  R2497     -1.2858489155769348e-01
    z[9,8,0]  R2498     -1.9241939485073090e-01
    z[9,8,0]  R2499     -6.3853137195110321e-02
    z[9,8,0]  R2500     -1.3127784430980682e-01
    z[9,8,0]  R2501     -7.1821823716163635e-02
    z[9,8,0]  R2502     1.0111336596310139e-02
    z[9,8,0]  R2503     0.541682779788971
    z[9,8,0]  R2504     5.1831579208374023e-01
    z[9,8,0]  R2505     -1.7896954715251923e-01
    z[9,8,0]  R2506     2.5382828712463379e-01
    z[9,8,0]  R2507     -4.7841900587081909e-01
    z[9,8,0]  R2508     -1.4419214427471161e-01
    z[9,8,0]  R2509     1.1953799426555634e-01
    z[9,8,0]  R2510     1.8817475438117981e-01
    z[9,8,0]  R2511     -2.8226274251937866e-01
    z[9,8,0]  R2512     -7.7986550331115723e-01
    z[9,8,0]  R2513     -5.6133443117141724e-01
    z[9,8,0]  R2514     -1.8987755477428436e-01
    z[9,8,0]  R2515     -2.2425100207328796e-01
    z[9,8,0]  R2516     -3.7275391817092896e-01
    z[9,8,0]  R2517     -1.4958010986447334e-02
    z[9,8,0]  R2518     -1.2382146716117859e-01
    z[9,8,0]  R2519     8.7856575846672058e-02
    z[9,8,0]  R2520     1.6627542674541473e-01
    z[9,8,0]  R2521     0.0994608923792839
    z[9,8,0]  R2522     5.5766079574823380e-02
    z[9,8,0]  R2523     -7.3843546211719513e-02
    z[9,8,0]  R2524     0.276685506105423
    z[9,8,0]  R2525     -1.0525304824113846e-02
    z[9,8,0]  R2526     1.7087580263614655e-01
    z[9,8,0]  R2527     -1.3269034028053284e-01
    z[9,8,0]  R2528     -6.3597828149795532e-02
    z[9,8,0]  R2529     1.3340190052986145e-01
    z[9,8,0]  R2530     1.7978912591934204e-01
    z[9,8,0]  R2531     7.2384142875671387e-01
    z[9,8,0]  R2532     6.6835331916809082e-01
    z[9,8,0]  R2533     7.7100640535354614e-01
    z[9,8,0]  R2534     7.0901614427566528e-01
    z[9,8,0]  R2535     2.1059218049049377e-01
    z[9,8,0]  R2536     -2.6733953505754471e-02
    z[9,8,0]  R2537     5.6849938631057739e-01
    z[9,8,0]  R2538     0.751060426235199
    z[9,8,0]  R2539     5.5167865753173828e-01
    z[9,8,0]  R2540     6.1072719097137451e-01
    z[9,8,0]  R2541     1.4569234848022461e-01
    z[9,8,0]  R2542     -0.189011350274086
    z[9,8,0]  R2543     1.0889729112386703e-01
    z[9,8,0]  R2544     -1.1854165792465210e-01
    z[9,8,0]  R2545     1.2387714534997940e-01
    z[9,8,0]  R2546     -9.2916369438171387e-02
    z[9,8,0]  R2547     -4.9124038219451904e-01
    z[9,8,0]  R2548     -5.3309446573257446e-01
    z[9,8,0]  R2549     -3.5195019841194153e-01
    z[9,8,0]  R2550     3.8438871502876282e-01
    z[9,8,0]  R2551     1.7925992608070374e-01
    z[9,8,0]  R2552     7.7746921777725220e-01
    z[9,8,0]  R2553     7.6034718751907349e-01
    z[9,8,0]  R2554     0.081568144261837
    z[9,8,0]  R2555     -2.9130074381828308e-01
    z[9,8,0]  R2556     7.2642546892166138e-01
    z[9,8,0]  R2557     7.1067118644714355e-01
    z[9,8,0]  R2558     -1.2803460471332073e-02
    z[9,8,0]  R2559     7.5687915086746216e-01
    z[9,8,0]  R2560     3.9250746369361877e-01
    z[9,8,0]  R2561     2.2239652276039124e-01
    z[9,8,0]  R2562     9.9800862371921539e-02
    z[9,8,0]  R2563     3.7790974974632263e-01
    z[9,8,0]  R2564     0.721330463886261
    z[9,8,0]  R2565     8.7671202421188354e-01
    z[9,8,0]  R2566     6.8902516365051270e-01
    z[9,8,0]  R2567     7.7704823017120361e-01
    z[9,8,0]  R2568     -1.8984349071979523e-01
    z[9,8,0]  R2569     0.637488603591919
    z[9,8,0]  R2570     5.9059524536132812e-01
    z[9,8,0]  R2571     5.8321809768676758e-01
    z[9,8,0]  R2572     6.9958710670471191e-01
    z[9,8,0]  R2573     1.7745713889598846e-01
    z[9,8,0]  R2574     -2.7724722027778625e-01
    z[9,8,0]  R2575     -5.8270114660263062e-01
    z[9,8,0]  R2576     -3.3282798528671265e-01
    z[9,8,0]  R2577     -1.6312380135059357e-01
    z[9,8,0]  R2578     -2.3580288887023926e-01
    z[9,8,0]  R2579     7.6551836729049683e-01
    z[9,8,0]  R2580     -4.8537963628768921e-01
    z[9,8,0]  R2581     2.0472145080566406e-01
    z[9,8,0]  R2582     6.8301928043365479e-01
    z[9,8,0]  R2583     8.0555105209350586e-01
    z[9,8,0]  R2584     -0.315387487411499
    z[9,8,0]  R2585     -3.9320096373558044e-01
    z[9,8,0]  R2586     -3.5275191068649292e-01
    z[9,8,0]  R2587     6.3006573915481567e-01
    z[9,8,0]  R2588     -2.8680721297860146e-02
    z[9,8,0]  R2589     3.0212867259979248e-01
    z[9,8,0]  R2590     -4.5551683753728867e-02
    z[9,8,0]  R2591     9.1342061758041382e-01
    z[9,8,0]  R2592     -4.6857488155364990e-01
    z[9,8,0]  R2593     -3.4039369225502014e-01
    z[9,8,0]  R2594     6.9425010681152344e-01
    z[9,8,0]  R2595     0.0693756490945816
    z[9,8,0]  R2596     -5.3943157196044922e-01
    z[9,8,0]  R2597     -6.2931698560714722e-01
    z[9,8,0]  R2598     -5.9819233417510986e-01
    z[9,8,0]  R2599     2.9400706291198730e-01
    z[9,8,0]  R2600     2.5269946455955505e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2431     -1
    z[9,8,1]  R2432     1
    z[9,8,1]  R2443     3.8767442107200623e-01
    z[9,8,1]  R2444     1.7109133303165436e-01
    z[9,8,1]  R2445     2.1183459088206291e-02
    z[9,8,1]  R2446     7.4613589048385620e-01
    z[9,8,1]  R2447     7.9002523422241211e-01
    z[9,8,1]  R2448     -4.8140946030616760e-01
    z[9,8,1]  R2449     3.8775098323822021e-01
    z[9,8,1]  R2450     -1.8589808046817780e-01
    z[9,8,1]  R2451     6.1399197578430176e-01
    z[9,8,1]  R2452     1.9840073585510254e-01
    z[9,8,1]  R2453     -3.6536478996276855e-01
    z[9,8,1]  R2454     -2.4173070490360260e-01
    z[9,8,1]  R2455     -0.476881742477417
    z[9,8,1]  R2456     -1.9843542575836182e-01
    z[9,8,1]  R2457     -5.4412138462066650e-01
    z[9,8,1]  R2458     -6.9752758741378784e-01
    z[9,8,1]  R2459     2.8069606423377991e-01
    z[9,8,1]  R2460     -7.4881382286548615e-02
    z[9,8,1]  R2461     0.581967830657959
    z[9,8,1]  R2462     3.7978556752204895e-01
    z[9,8,1]  R2463     5.7962757349014282e-01
    z[9,8,1]  R2464     2.7062505483627319e-01
    z[9,8,1]  R2465     1.4633838832378387e-01
    z[9,8,1]  R2466     -2.8048139810562134e-01
    z[9,8,1]  R2467     -9.0064823627471924e-02
    z[9,8,1]  R2468     4.3462336063385010e-01
    z[9,8,1]  R2469     -6.3214832544326782e-01
    z[9,8,1]  R2470     3.3744487911462784e-02
    z[9,8,1]  R2471     6.4503389596939087e-01
    z[9,8,1]  R2472     6.3430631160736084e-01
    z[9,8,1]  R2473     4.7585359215736389e-01
    z[9,8,1]  R2474     3.6725082993507385e-01
    z[9,8,1]  R2475     -1.5736138820648193e-01
    z[9,8,1]  R2476     -3.0708810687065125e-01
    z[9,8,1]  R2477     -2.8330606222152710e-01
    z[9,8,1]  R2478     -3.6009213328361511e-01
    z[9,8,1]  R2479     1.7421099543571472e-01
    z[9,8,1]  R2480     -6.5730142593383789e-01
    z[9,8,1]  R2481     7.4005979299545288e-01
    z[9,8,1]  R2482     -1.4961113035678864e-01
    z[9,8,1]  R2483     -0.664179265499115
    z[9,8,1]  R2484     -4.6668875217437744e-01
    z[9,8,1]  R2485     -5.1353383064270020e-01
    z[9,8,1]  R2486     2.4946649372577667e-01
    z[9,8,1]  R2487     6.0474222898483276e-01
    z[9,8,1]  R2488     6.6959589719772339e-02
    z[9,8,1]  R2489     2.4652989581227303e-02
    z[9,8,1]  R2490     -2.8708785772323608e-01
    z[9,8,1]  R2491     7.7099275588989258e-01
    z[9,8,1]  R2492     -4.4385217130184174e-02
    z[9,8,1]  R2493     -4.5468533039093018e-01
    z[9,8,1]  R2494     4.5502173900604248e-01
    z[9,8,1]  R2495     1.3688434660434723e-01
    z[9,8,1]  R2496     -6.8872314691543579e-01
    z[9,8,1]  R2497     -7.5139582157135010e-01
    z[9,8,1]  R2498     -8.6946922540664673e-01
    z[9,8,1]  R2499     -7.1054071187973022e-01
    z[9,8,1]  R2500     -7.5809156894683838e-01
    z[9,8,1]  R2501     8.4869980812072754e-01
    z[9,8,1]  R2502     0.495947003364563
    z[9,8,1]  R2503     -0.353481262922287
    z[9,8,1]  R2504     -3.2727217767387629e-03
    z[9,8,1]  R2505     -5.8670526742935181e-01
    z[9,8,1]  R2506     -1.5659306943416595e-01
    z[9,8,1]  R2507     -7.8024029731750488e-01
    z[9,8,1]  R2508     -6.8780100345611572e-01
    z[9,8,1]  R2509     -8.3306348323822021e-01
    z[9,8,1]  R2510     -7.9620856046676636e-01
    z[9,8,1]  R2511     -7.9524271190166473e-02
    z[9,8,1]  R2512     4.3006721138954163e-01
    z[9,8,1]  R2513     6.0038244724273682e-01
    z[9,8,1]  R2514     -0.348158061504364
    z[9,8,1]  R2515     6.6742175817489624e-01
    z[9,8,1]  R2516     5.6951224803924561e-01
    z[9,8,1]  R2517     -2.0942346751689911e-01
    z[9,8,1]  R2518     6.8685054779052734e-01
    z[9,8,1]  R2519     7.2288900613784790e-01
    z[9,8,1]  R2520     3.2047115266323090e-02
    z[9,8,1]  R2521     -2.7143087983131409e-01
    z[9,8,1]  R2522     -7.5525051355361938e-01
    z[9,8,1]  R2523     -6.9330054521560669e-01
    z[9,8,1]  R2524     -5.9834969043731689e-01
    z[9,8,1]  R2525     -5.3521466255187988e-01
    z[9,8,1]  R2526     -6.4924311637878418e-01
    z[9,8,1]  R2527     -7.2761493921279907e-01
    z[9,8,1]  R2528     -6.3145416975021362e-01
    z[9,8,1]  R2529     -4.4217732548713684e-01
    z[9,8,1]  R2530     0.265844464302063
    z[9,8,1]  R2531     5.5007302761077881e-01
    z[9,8,1]  R2532     5.3940200805664062e-01
    z[9,8,1]  R2533     1.4655441045761108e-01
    z[9,8,1]  R2534     2.4297359585762024e-01
    z[9,8,1]  R2535     -5.6602823734283447e-01
    z[9,8,1]  R2536     -1.7171211540699005e-01
    z[9,8,1]  R2537     6.2469226121902466e-01
    z[9,8,1]  R2538     1.5787769854068756e-01
    z[9,8,1]  R2539     6.5057468414306641e-01
    z[9,8,1]  R2540     3.6385115981101990e-01
    z[9,8,1]  R2541     1.4839459955692291e-01
    z[9,8,1]  R2542     4.5483246445655823e-01
    z[9,8,1]  R2543     -5.0865131616592407e-01
    z[9,8,1]  R2544     5.2377808094024658e-01
    z[9,8,1]  R2545     -5.3239434957504272e-01
    z[9,8,1]  R2546     5.6583970785140991e-01
    z[9,8,1]  R2547     4.6969932317733765e-01
    z[9,8,1]  R2548     3.6401736736297607e-01
    z[9,8,1]  R2549     7.7508658170700073e-02
    z[9,8,1]  R2550     -3.5676285624504089e-01
    z[9,8,1]  R2551     -4.3701842427253723e-02
    z[9,8,1]  R2552     2.4696822464466095e-01
    z[9,8,1]  R2553     2.7257981896400452e-01
    z[9,8,1]  R2554     -4.9792066216468811e-01
    z[9,8,1]  R2555     -3.2171663641929626e-01
    z[9,8,1]  R2556     2.5877881050109863e-01
    z[9,8,1]  R2557     4.9964633584022522e-01
    z[9,8,1]  R2558     -6.1221045255661011e-01
    z[9,8,1]  R2559     9.7677908837795258e-02
    z[9,8,1]  R2560     -5.5611205101013184e-01
    z[9,8,1]  R2561     0.0494234636425972
    z[9,8,1]  R2562     4.4642563909292221e-02
    z[9,8,1]  R2563     -1.4130115509033203e-01
    z[9,8,1]  R2564     0.358583003282547
    z[9,8,1]  R2565     -6.3015684485435486e-02
    z[9,8,1]  R2566     5.0175529718399048e-01
    z[9,8,1]  R2567     1.2697845697402954e-01
    z[9,8,1]  R2568     -2.1848936378955841e-01
    z[9,8,1]  R2569     3.7984037399291992e-01
    z[9,8,1]  R2570     5.0106209516525269e-01
    z[9,8,1]  R2571     0.666954517364502
    z[9,8,1]  R2572     4.7370767593383789e-01
    z[9,8,1]  R2573     4.9215254187583923e-01
    z[9,8,1]  R2574     3.5664218664169312e-01
    z[9,8,1]  R2575     0.0708300992846489
    z[9,8,1]  R2576     4.5316481590270996e-01
    z[9,8,1]  R2577     7.7104771137237549e-01
    z[9,8,1]  R2578     -7.5780582427978516e-01
    z[9,8,1]  R2579     -8.0938935279846191e-02
    z[9,8,1]  R2580     5.2663671970367432e-01
    z[9,8,1]  R2581     -3.8568067550659180e-01
    z[9,8,1]  R2582     4.6776360273361206e-01
    z[9,8,1]  R2583     2.4367228150367737e-01
    z[9,8,1]  R2584     5.9032875299453735e-01
    z[9,8,1]  R2585     0.531501054763794
    z[9,8,1]  R2586     4.0920135378837585e-01
    z[9,8,1]  R2587     1.8107984960079193e-01
    z[9,8,1]  R2588     -9.1409909725189209e-01
    z[9,8,1]  R2589     -3.5409516096115112e-01
    z[9,8,1]  R2590     -4.3090045452117920e-01
    z[9,8,1]  R2591     1.8716056644916534e-01
    z[9,8,1]  R2592     4.5817929506301880e-01
    z[9,8,1]  R2593     7.3749041557312012e-01
    z[9,8,1]  R2594     2.9498317837715149e-01
    z[9,8,1]  R2595     4.2501375079154968e-01
    z[9,8,1]  R2596     2.7181729674339294e-01
    z[9,8,1]  R2597     4.2410823702812195e-01
    z[9,8,1]  R2598     -1.9883349537849426e-02
    z[9,8,1]  R2599     -3.0261763930320740e-01
    z[9,8,1]  R2600     -7.1180623769760132e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2433     -1
    z[9,8,2]  R2434     1
    z[9,8,2]  R2443     2.6962780952453613e-01
    z[9,8,2]  R2444     -1.5595278143882751e-01
    z[9,8,2]  R2445     -2.7372547984123230e-01
    z[9,8,2]  R2446     1.2897615134716034e-01
    z[9,8,2]  R2447     -2.4308270215988159e-01
    z[9,8,2]  R2448     3.0984896421432495e-01
    z[9,8,2]  R2449     -1.4209984242916107e-01
    z[9,8,2]  R2450     5.9943532943725586e-01
    z[9,8,2]  R2451     -1.0448925197124481e-01
    z[9,8,2]  R2452     1.3479281216859818e-02
    z[9,8,2]  R2453     1.1287947744131088e-01
    z[9,8,2]  R2454     1.1302204430103302e-01
    z[9,8,2]  R2455     9.8053090274333954e-02
    z[9,8,2]  R2456     7.6808951795101166e-02
    z[9,8,2]  R2457     1.2116042524576187e-01
    z[9,8,2]  R2458     -6.9153765216469765e-03
    z[9,8,2]  R2459     -3.3691966533660889e-01
    z[9,8,2]  R2460     1.6750842332839966e-01
    z[9,8,2]  R2461     -3.8306069374084473e-01
    z[9,8,2]  R2462     -9.7597584128379822e-02
    z[9,8,2]  R2463     -1.6526705026626587e-01
    z[9,8,2]  R2464     -1.6783097386360168e-01
    z[9,8,2]  R2465     4.0195193886756897e-01
    z[9,8,2]  R2466     3.0085697770118713e-01
    z[9,8,2]  R2467     5.0224140286445618e-02
    z[9,8,2]  R2468     -6.7384196445345879e-03
    z[9,8,2]  R2469     2.2282119095325470e-01
    z[9,8,2]  R2470     1.4660651981830597e-01
    z[9,8,2]  R2471     2.7640566229820251e-01
    z[9,8,2]  R2472     -1.7612041532993317e-01
    z[9,8,2]  R2473     -1.9000692665576935e-01
    z[9,8,2]  R2474     -2.3613980412483215e-01
    z[9,8,2]  R2475     1.6630922257900238e-01
    z[9,8,2]  R2476     0.278865247964859
    z[9,8,2]  R2477     3.4774717688560486e-01
    z[9,8,2]  R2478     -2.6795920729637146e-01
    z[9,8,2]  R2479     2.4316211044788361e-01
    z[9,8,2]  R2480     0.072159044444561
    z[9,8,2]  R2481     -1.4607223868370056e-01
    z[9,8,2]  R2482     -3.6402802914381027e-02
    z[9,8,2]  R2483     -0.0696464404463768
    z[9,8,2]  R2484     3.4577544778585434e-02
    z[9,8,2]  R2485     1.7927622795104980e-01
    z[9,8,2]  R2486     -4.9369469285011292e-02
    z[9,8,2]  R2487     -8.6866080760955811e-02
    z[9,8,2]  R2488     -1.8797514960169792e-02
    z[9,8,2]  R2489     1.4925029873847961e-01
    z[9,8,2]  R2490     -3.7630814313888550e-01
    z[9,8,2]  R2491     9.9292054772377014e-02
    z[9,8,2]  R2492     2.7988898754119873e-01
    z[9,8,2]  R2493     -2.0557044446468353e-01
    z[9,8,2]  R2494     4.0105696767568588e-02
    z[9,8,2]  R2495     2.7256676554679871e-01
    z[9,8,2]  R2496     0.440176784992218
    z[9,8,2]  R2497     5.3659409284591675e-01
    z[9,8,2]  R2498     2.4309273064136505e-01
    z[9,8,2]  R2499     5.5031704902648926e-01
    z[9,8,2]  R2500     4.6665042638778687e-01
    z[9,8,2]  R2501     -2.4337400496006012e-01
    z[9,8,2]  R2502     -7.5156822800636292e-02
    z[9,8,2]  R2503     3.5064734518527985e-02
    z[9,8,2]  R2504     4.2925927042961121e-01
    z[9,8,2]  R2505     1.1458951234817505e-01
    z[9,8,2]  R2506     1.7669038474559784e-01
    z[9,8,2]  R2507     1.3559868931770325e-01
    z[9,8,2]  R2508     1.8198868632316589e-01
    z[9,8,2]  R2509     2.8437674045562744e-01
    z[9,8,2]  R2510     -2.2518450021743774e-01
    z[9,8,2]  R2511     -1.4506091177463531e-01
    z[9,8,2]  R2512     -4.0828222036361694e-01
    z[9,8,2]  R2513     -1.3990265130996704e-01
    z[9,8,2]  R2514     1.5811876952648163e-01
    z[9,8,2]  R2515     -6.6476821899414062e-01
    z[9,8,2]  R2516     -5.1513093709945679e-01
    z[9,8,2]  R2517     5.6466543674468994e-01
    z[9,8,2]  R2518     -2.7045628428459167e-01
    z[9,8,2]  R2519     -6.0067063570022583e-01
    z[9,8,2]  R2520     4.9722400307655334e-01
    z[9,8,2]  R2521     -9.8033733665943146e-03
    z[9,8,2]  R2522     4.5843723416328430e-01
    z[9,8,2]  R2523     4.7923445701599121e-01
    z[9,8,2]  R2524     5.4851877689361572e-01
    z[9,8,2]  R2525     3.9394792914390564e-01
    z[9,8,2]  R2526     4.8835653066635132e-01
    z[9,8,2]  R2527     3.5637223720550537e-01
    z[9,8,2]  R2528     5.6142389774322510e-01
    z[9,8,2]  R2529     5.4904019832611084e-01
    z[9,8,2]  R2530     -2.3786285519599915e-01
    z[9,8,2]  R2531     0.0487288273870945
    z[9,8,2]  R2532     -2.6154069229960442e-02
    z[9,8,2]  R2533     4.2261460423469543e-01
    z[9,8,2]  R2534     4.2749884724617004e-01
    z[9,8,2]  R2535     3.4843704104423523e-01
    z[9,8,2]  R2536     1.8114510178565979e-01
    z[9,8,2]  R2537     3.1396117061376572e-02
    z[9,8,2]  R2538     -3.8140231370925903e-01
    z[9,8,2]  R2539     -1.4456406235694885e-01
    z[9,8,2]  R2540     -4.6017771959304810e-01
    z[9,8,2]  R2541     4.1910163126885891e-03
    z[9,8,2]  R2542     -6.4679676294326782e-01
    z[9,8,2]  R2543     -2.4103774130344391e-01
    z[9,8,2]  R2544     -2.5775903463363647e-01
    z[9,8,2]  R2545     -4.9242994189262390e-01
    z[9,8,2]  R2546     -5.4433572292327881e-01
    z[9,8,2]  R2547     -1.7263974249362946e-01
    z[9,8,2]  R2548     -2.8131538629531860e-01
    z[9,8,2]  R2549     -5.9280896186828613e-01
    z[9,8,2]  R2550     3.9855021238327026e-01
    z[9,8,2]  R2551     -2.3835518956184387e-01
    z[9,8,2]  R2552     -3.8933902978897095e-01
    z[9,8,2]  R2553     1.4332948625087738e-01
    z[9,8,2]  R2554     -5.1626789569854736e-01
    z[9,8,2]  R2555     5.0522979348897934e-02
    z[9,8,2]  R2556     -5.4258454591035843e-02
    z[9,8,2]  R2557     -3.3366364240646362e-01
    z[9,8,2]  R2558     2.1466314792633057e-02
    z[9,8,2]  R2559     1.4715506136417389e-01
    z[9,8,2]  R2560     -4.2111596465110779e-01
    z[9,8,2]  R2561     2.6426786184310913e-01
    z[9,8,2]  R2562     4.9070903658866882e-01
    z[9,8,2]  R2563     2.7465194463729858e-01
    z[9,8,2]  R2564     1.6144557297229767e-01
    z[9,8,2]  R2565     1.0726875066757202e-01
    z[9,8,2]  R2566     9.6196554601192474e-02
    z[9,8,2]  R2567     -1.9534166157245636e-01
    z[9,8,2]  R2568     6.4866676926612854e-02
    z[9,8,2]  R2569     1.0155776888132095e-01
    z[9,8,2]  R2570     -3.3164986968040466e-01
    z[9,8,2]  R2571     -2.1577699109911919e-02
    z[9,8,2]  R2572     -4.0542903542518616e-01
    z[9,8,2]  R2573     -5.8782523870468140e-01
    z[9,8,2]  R2574     -6.2577402591705322e-01
    z[9,8,2]  R2575     -3.5352534055709839e-01
    z[9,8,2]  R2576     -4.1959038376808167e-01
    z[9,8,2]  R2577     -3.8010302186012268e-01
    z[9,8,2]  R2578     5.4346317052841187e-01
    z[9,8,2]  R2579     2.2473068535327911e-01
    z[9,8,2]  R2580     -0.0822916328907013
    z[9,8,2]  R2581     -2.4013957008719444e-03
    z[9,8,2]  R2582     0.181917205452919
    z[9,8,2]  R2583     0.0684681311249733
    z[9,8,2]  R2584     -6.6954821348190308e-01
    z[9,8,2]  R2585     -5.5514967441558838e-01
    z[9,8,2]  R2586     -7.1552932262420654e-01
    z[9,8,2]  R2587     9.0828202664852142e-02
    z[9,8,2]  R2588     2.6896980404853821e-01
    z[9,8,2]  R2589     6.1077654361724854e-01
    z[9,8,2]  R2590     6.1808902770280838e-02
    z[9,8,2]  R2591     1.2700352072715759e-01
    z[9,8,2]  R2592     -3.4459051489830017e-01
    z[9,8,2]  R2593     -4.1717949509620667e-01
    z[9,8,2]  R2594     -4.3970888853073120e-01
    z[9,8,2]  R2595     -6.7316633462905884e-01
    z[9,8,2]  R2596     -6.3947242498397827e-01
    z[9,8,2]  R2597     -1.5409936010837555e-01
    z[9,8,2]  R2598     -6.5547204017639160e-01
    z[9,8,2]  R2599     -3.3076709508895874e-01
    z[9,8,2]  R2600     3.5841265320777893e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2435     -1
    z[9,8,3]  R2436     1
    z[9,8,3]  R2443     5.3373761475086212e-02
    z[9,8,3]  R2444     4.5152485370635986e-01
    z[9,8,3]  R2445     3.2599920034408569e-01
    z[9,8,3]  R2446     -2.1406471729278564e-01
    z[9,8,3]  R2447     1.4406421780586243e-01
    z[9,8,3]  R2448     7.9791283607482910e-01
    z[9,8,3]  R2449     -5.7614302635192871e-01
    z[9,8,3]  R2450     -3.7967890501022339e-01
    z[9,8,3]  R2451     -1.8653295934200287e-01
    z[9,8,3]  R2452     -9.2315798997879028e-01
    z[9,8,3]  R2453     3.3459299802780151e-01
    z[9,8,3]  R2454     8.7592297792434692e-01
    z[9,8,3]  R2455     2.8328070044517517e-01
    z[9,8,3]  R2456     3.9715844392776489e-01
    z[9,8,3]  R2457     2.5570935010910034e-01
    z[9,8,3]  R2458     2.0916453003883362e-01
    z[9,8,3]  R2459     -1.6822256147861481e-01
    z[9,8,3]  R2460     6.4203584194183350e-01
    z[9,8,3]  R2461     1.5802358090877533e-01
    z[9,8,3]  R2462     -7.8423309326171875e-01
    z[9,8,3]  R2463     -2.1199563145637512e-01
    z[9,8,3]  R2464     -6.7315685749053955e-01
    z[9,8,3]  R2465     3.1995415687561035e-01
    z[9,8,3]  R2466     4.2300209403038025e-01
    z[9,8,3]  R2467     7.8073817491531372e-01
    z[9,8,3]  R2468     4.8033601045608521e-01
    z[9,8,3]  R2469     4.6407714486122131e-01
    z[9,8,3]  R2470     4.0075761079788208e-01
    z[9,8,3]  R2471     -0.0906476080417633
    z[9,8,3]  R2472     2.5016140937805176e-01
    z[9,8,3]  R2473     -7.0939630270004272e-01
    z[9,8,3]  R2474     -7.0446836948394775e-01
    z[9,8,3]  R2475     4.7615560889244080e-01
    z[9,8,3]  R2476     3.6661583185195923e-01
    z[9,8,3]  R2477     6.3652658462524414e-01
    z[9,8,3]  R2478     6.4629054069519043e-01
    z[9,8,3]  R2479     6.1970251798629761e-01
    z[9,8,3]  R2480     6.5345507860183716e-01
    z[9,8,3]  R2481     -2.6025879383087158e-01
    z[9,8,3]  R2482     0.534384548664093
    z[9,8,3]  R2483     6.1577588319778442e-01
    z[9,8,3]  R2484     4.0714344382286072e-01
    z[9,8,3]  R2485     5.9882515668869019e-01
    z[9,8,3]  R2486     6.3399654626846313e-01
    z[9,8,3]  R2487     3.2498005032539368e-01
    z[9,8,3]  R2488     8.8929927349090576e-01
    z[9,8,3]  R2489     8.9148283004760742e-01
    z[9,8,3]  R2490     6.5901094675064087e-01
    z[9,8,3]  R2491     3.6119830608367920e-01
    z[9,8,3]  R2492     8.6791312694549561e-01
    z[9,8,3]  R2493     5.4483503103256226e-01
    z[9,8,3]  R2494     -6.0689771175384521e-01
    z[9,8,3]  R2495     0.537681519985199
    z[9,8,3]  R2496     -4.3805586174130440e-03
    z[9,8,3]  R2497     -9.8440952599048615e-02
    z[9,8,3]  R2498     -2.0977884531021118e-01
    z[9,8,3]  R2499     -1.1612334847450256e-01
    z[9,8,3]  R2500     -1.5409705042839050e-01
    z[9,8,3]  R2501     -1.6119350492954254e-01
    z[9,8,3]  R2502     -7.1217817068099976e-01
    z[9,8,3]  R2503     5.0207132101058960e-01
    z[9,8,3]  R2504     5.9529662132263184e-01
    z[9,8,3]  R2505     3.0756023526191711e-01
    z[9,8,3]  R2506     6.9351297616958618e-01
    z[9,8,3]  R2507     2.3969364166259766e-01
    z[9,8,3]  R2508     1.3161744177341461e-01
    z[9,8,3]  R2509     -1.8077501654624939e-01
    z[9,8,3]  R2510     -4.7149181365966797e-01
    z[9,8,3]  R2511     6.3471293449401855e-01
    z[9,8,3]  R2512     3.7169404327869415e-02
    z[9,8,3]  R2513     1.5428406186401844e-02
    z[9,8,3]  R2514     4.8135069012641907e-01
    z[9,8,3]  R2515     8.5634356364607811e-03
    z[9,8,3]  R2516     4.9765971302986145e-01
    z[9,8,3]  R2517     4.4825062155723572e-01
    z[9,8,3]  R2518     4.4120573997497559e-01
    z[9,8,3]  R2519     9.6951022744178772e-02
    z[9,8,3]  R2520     6.3274890184402466e-01
    z[9,8,3]  R2521     7.6028275489807129e-01
    z[9,8,3]  R2522     -3.6877706646919250e-02
    z[9,8,3]  R2523     -2.1236577630043030e-01
    z[9,8,3]  R2524     -2.8400555253028870e-01
    z[9,8,3]  R2525     -3.2647213339805603e-01
    z[9,8,3]  R2526     -3.6428447812795639e-02
    z[9,8,3]  R2527     -3.6264741420745850e-01
    z[9,8,3]  R2528     -4.7265359759330750e-01
    z[9,8,3]  R2529     -4.7184243798255920e-01
    z[9,8,3]  R2530     4.5467212796211243e-01
    z[9,8,3]  R2531     -7.5866356492042542e-02
    z[9,8,3]  R2532     1.8623191118240356e-01
    z[9,8,3]  R2533     -1.4141495525836945e-01
    z[9,8,3]  R2534     3.2630637288093567e-01
    z[9,8,3]  R2535     1.7457969486713409e-01
    z[9,8,3]  R2536     5.9118086099624634e-01
    z[9,8,3]  R2537     3.7921655178070068e-01
    z[9,8,3]  R2538     -7.4865147471427917e-02
    z[9,8,3]  R2539     4.3815410137176514e-01
    z[9,8,3]  R2540     1.6231262683868408e-01
    z[9,8,3]  R2541     7.2276329994201660e-01
    z[9,8,3]  R2542     -3.9736565947532654e-01
    z[9,8,3]  R2543     3.7152585387229919e-01
    z[9,8,3]  R2544     5.5104327201843262e-01
    z[9,8,3]  R2545     3.4945863485336304e-01
    z[9,8,3]  R2546     -1.7210496589541435e-02
    z[9,8,3]  R2547     4.3477201461791992e-01
    z[9,8,3]  R2548     8.3079628646373749e-02
    z[9,8,3]  R2549     7.0735722780227661e-02
    z[9,8,3]  R2550     8.2067184150218964e-02
    z[9,8,3]  R2551     3.2217529416084290e-01
    z[9,8,3]  R2552     -2.6893955469131470e-01
    z[9,8,3]  R2553     -1.4151706127449870e-03
    z[9,8,3]  R2554     3.4386447072029114e-01
    z[9,8,3]  R2555     8.5708731412887573e-01
    z[9,8,3]  R2556     2.5729832053184509e-01
    z[9,8,3]  R2557     2.5699369609355927e-02
    z[9,8,3]  R2558     0.627197265625
    z[9,8,3]  R2559     4.7050496935844421e-01
    z[9,8,3]  R2560     1.7863745987415314e-01
    z[9,8,3]  R2561     4.8613610863685608e-01
    z[9,8,3]  R2562     7.9316431283950806e-01
    z[9,8,3]  R2563     7.6619559526443481e-01
    z[9,8,3]  R2564     -4.2995044589042664e-01
    z[9,8,3]  R2565     3.6229613423347473e-01
    z[9,8,3]  R2566     -1.9225323200225830e-01
    z[9,8,3]  R2567     1.5171775221824646e-01
    z[9,8,3]  R2568     0.892119824886322
    z[9,8,3]  R2569     -4.1772323846817017e-01
    z[9,8,3]  R2570     3.9665955305099487e-01
    z[9,8,3]  R2571     -3.1335288076661527e-04
    z[9,8,3]  R2572     1.2308204174041748e-01
    z[9,8,3]  R2573     3.3044064044952393e-01
    z[9,8,3]  R2574     3.1732434034347534e-01
    z[9,8,3]  R2575     -6.2446214258670807e-02
    z[9,8,3]  R2576     -0.0313868410885334
    z[9,8,3]  R2577     -6.0916036367416382e-02
    z[9,8,3]  R2578     1.9142033159732819e-01
    z[9,8,3]  R2579     4.7483634203672409e-02
    z[9,8,3]  R2580     1.1565615981817245e-01
    z[9,8,3]  R2581     4.1282907128334045e-01
    z[9,8,3]  R2582     5.0725466012954712e-01
    z[9,8,3]  R2583     1.5332493185997009e-01
    z[9,8,3]  R2584     -1.2244151532649994e-01
    z[9,8,3]  R2585     1.3098880648612976e-01
    z[9,8,3]  R2586     2.2630952298641205e-01
    z[9,8,3]  R2587     -4.9962222576141357e-01
    z[9,8,3]  R2588     -1.8756206333637238e-01
    z[9,8,3]  R2589     1.8390727043151855e-01
    z[9,8,3]  R2590     5.0447350740432739e-01
    z[9,8,3]  R2591     -2.1160425245761871e-01
    z[9,8,3]  R2592     -3.9655330777168274e-01
    z[9,8,3]  R2593     6.8886585533618927e-02
    z[9,8,3]  R2594     1.8579009175300598e-01
    z[9,8,3]  R2595     7.5899370014667511e-02
    z[9,8,3]  R2596     2.8333681821823120e-01
    z[9,8,3]  R2597     3.2837271690368652e-01
    z[9,8,3]  R2598     -9.9064677953720093e-02
    z[9,8,3]  R2599     2.5260293483734131e-01
    z[9,8,3]  R2600     2.0337322354316711e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2437     -1
    z[9,8,4]  R2438     1
    z[9,8,4]  R2443     -3.9963263273239136e-01
    z[9,8,4]  R2444     -1.9065174460411072e-01
    z[9,8,4]  R2445     1.6308404505252838e-01
    z[9,8,4]  R2446     1.7770475149154663e-01
    z[9,8,4]  R2447     -6.0246824286878109e-03
    z[9,8,4]  R2448     3.9743125438690186e-02
    z[9,8,4]  R2449     -4.7841039299964905e-01
    z[9,8,4]  R2450     -2.6570683717727661e-01
    z[9,8,4]  R2451     2.2985085844993591e-01
    z[9,8,4]  R2452     -9.5314718782901764e-02
    z[9,8,4]  R2453     -3.1862157583236694e-01
    z[9,8,4]  R2454     -2.0755660533905029e-01
    z[9,8,4]  R2455     8.5939332842826843e-02
    z[9,8,4]  R2456     -5.2346813678741455e-01
    z[9,8,4]  R2457     -5.2218484878540039e-01
    z[9,8,4]  R2458     -2.5616351515054703e-02
    z[9,8,4]  R2459     7.9321271181106567e-01
    z[9,8,4]  R2460     2.3815500736236572e-01
    z[9,8,4]  R2461     4.6793961524963379e-01
    z[9,8,4]  R2462     3.7247157096862793e-01
    z[9,8,4]  R2463     6.3064676523208618e-01
    z[9,8,4]  R2464     4.4290821999311447e-02
    z[9,8,4]  R2465     -6.1709702014923096e-02
    z[9,8,4]  R2466     -1.6679541766643524e-01
    z[9,8,4]  R2467     3.7073069810867310e-01
    z[9,8,4]  R2468     4.6271455287933350e-01
    z[9,8,4]  R2469     1.9478730857372284e-01
    z[9,8,4]  R2470     2.6884219050407410e-01
    z[9,8,4]  R2471     8.4355793893337250e-02
    z[9,8,4]  R2472     5.5109471082687378e-01
    z[9,8,4]  R2473     -5.9672966599464417e-02
    z[9,8,4]  R2474     1.2610065937042236e-01
    z[9,8,4]  R2475     -2.6534751057624817e-01
    z[9,8,4]  R2476     4.6184204518795013e-02
    z[9,8,4]  R2477     -4.9820181727409363e-01
    z[9,8,4]  R2478     2.9514145851135254e-01
    z[9,8,4]  R2479     -3.4078621864318848e-01
    z[9,8,4]  R2480     -6.3860282301902771e-02
    z[9,8,4]  R2481     3.5076424479484558e-01
    z[9,8,4]  R2482     1.1089966446161270e-01
    z[9,8,4]  R2483     -6.5157525241374969e-02
    z[9,8,4]  R2484     -1.3002167642116547e-01
    z[9,8,4]  R2485     -2.2800201550126076e-02
    z[9,8,4]  R2486     2.7837478555738926e-03
    z[9,8,4]  R2487     -2.3730394244194031e-01
    z[9,8,4]  R2488     4.9583122134208679e-02
    z[9,8,4]  R2489     -3.3296641707420349e-01
    z[9,8,4]  R2490     0.0236127357929945
    z[9,8,4]  R2491     1.0640777647495270e-01
    z[9,8,4]  R2492     -2.2715452313423157e-01
    z[9,8,4]  R2493     1.9060926139354706e-01
    z[9,8,4]  R2494     -1.9961050152778625e-01
    z[9,8,4]  R2495     2.6911211013793945e-01
    z[9,8,4]  R2496     -5.5291861295700073e-01
    z[9,8,4]  R2497     2.8804585337638855e-01
    z[9,8,4]  R2498     2.6697701215744019e-01
    z[9,8,4]  R2499     2.4555821716785431e-01
    z[9,8,4]  R2500     3.5698929429054260e-01
    z[9,8,4]  R2501     1.2138537317514420e-01
    z[9,8,4]  R2502     -4.9574777483940125e-02
    z[9,8,4]  R2503     -1.7861866950988770e-01
    z[9,8,4]  R2504     -8.1913277506828308e-02
    z[9,8,4]  R2505     -9.4367057085037231e-02
    z[9,8,4]  R2506     4.9848115444183350e-01
    z[9,8,4]  R2507     -1.5069586038589478e-01
    z[9,8,4]  R2508     -5.4800641536712646e-01
    z[9,8,4]  R2509     2.6543119549751282e-01
    z[9,8,4]  R2510     2.0664992928504944e-01
    z[9,8,4]  R2511     -2.1748287975788116e-01
    z[9,8,4]  R2512     -5.6903768330812454e-02
    z[9,8,4]  R2513     -0.0574452243745327
    z[9,8,4]  R2514     -2.6986968517303467e-01
    z[9,8,4]  R2515     4.9347940832376480e-02
    z[9,8,4]  R2516     1.8177621066570282e-02
    z[9,8,4]  R2517     1.0496149957180023e-01
    z[9,8,4]  R2518     -1.0570524632930756e-01
    z[9,8,4]  R2519     -5.3320780396461487e-02
    z[9,8,4]  R2520     -3.2039427757263184e-01
    z[9,8,4]  R2521     -9.1939605772495270e-02
    z[9,8,4]  R2522     7.3073320090770721e-02
    z[9,8,4]  R2523     3.6314350366592407e-01
    z[9,8,4]  R2524     3.4748658537864685e-01
    z[9,8,4]  R2525     1.0689140111207962e-01
    z[9,8,4]  R2526     2.5803259015083313e-01
    z[9,8,4]  R2527     0.014848074875772
    z[9,8,4]  R2528     6.9001503288745880e-02
    z[9,8,4]  R2529     3.1547278165817261e-01
    z[9,8,4]  R2530     -7.0220857858657837e-01
    z[9,8,4]  R2531     -5.0553835928440094e-02
    z[9,8,4]  R2532     -3.8211759924888611e-01
    z[9,8,4]  R2533     2.9748806357383728e-01
    z[9,8,4]  R2534     3.0938872694969177e-01
    z[9,8,4]  R2535     -2.2808396816253662e-01
    z[9,8,4]  R2536     5.9838145971298218e-01
    z[9,8,4]  R2537     5.1360901445150375e-02
    z[9,8,4]  R2538     -2.9469090700149536e-01
    z[9,8,4]  R2539     6.3740663230419159e-02
    z[9,8,4]  R2540     -5.0611924380064011e-02
    z[9,8,4]  R2541     2.7012842893600464e-01
    z[9,8,4]  R2542     2.4763178080320358e-02
    z[9,8,4]  R2543     -4.5352885127067566e-01
    z[9,8,4]  R2544     -4.9569332599639893e-01
    z[9,8,4]  R2545     -1.3083736598491669e-01
    z[9,8,4]  R2546     -2.7934324741363525e-01
    z[9,8,4]  R2547     -2.4890260398387909e-01
    z[9,8,4]  R2548     4.3951147794723511e-01
    z[9,8,4]  R2549     -5.2005261182785034e-01
    z[9,8,4]  R2550     -5.2744048833847046e-01
    z[9,8,4]  R2551     -1.5415717661380768e-01
    z[9,8,4]  R2552     -2.0392365753650665e-01
    z[9,8,4]  R2553     -1.3303364813327789e-01
    z[9,8,4]  R2554     1.4022152125835419e-01
    z[9,8,4]  R2555     2.6859796047210693e-01
    z[9,8,4]  R2556     0.272236168384552
    z[9,8,4]  R2557     9.5518708229064941e-02
    z[9,8,4]  R2558     5.6548561900854111e-02
    z[9,8,4]  R2559     -2.4783669412136078e-01
    z[9,8,4]  R2560     1.7186237871646881e-01
    z[9,8,4]  R2561     -1.0055442899465561e-01
    z[9,8,4]  R2562     1.6592821478843689e-01
    z[9,8,4]  R2563     -2.9397532343864441e-02
    z[9,8,4]  R2564     4.6979844570159912e-02
    z[9,8,4]  R2565     -1.2716351449489594e-01
    z[9,8,4]  R2566     -4.4760741293430328e-02
    z[9,8,4]  R2567     2.2285891696810722e-02
    z[9,8,4]  R2568     -1.9680918753147125e-01
    z[9,8,4]  R2569     9.7770921885967255e-02
    z[9,8,4]  R2570     -2.7405008673667908e-01
    z[9,8,4]  R2571     1.4631024003028870e-01
    z[9,8,4]  R2572     -1.8064735829830170e-01
    z[9,8,4]  R2573     -3.1060841679573059e-01
    z[9,8,4]  R2574     -1.6298873722553253e-01
    z[9,8,4]  R2575     -2.9918268322944641e-01
    z[9,8,4]  R2576     -3.9690437912940979e-01
    z[9,8,4]  R2577     2.8621044754981995e-01
    z[9,8,4]  R2578     -3.2313957810401917e-02
    z[9,8,4]  R2579     -3.3583962917327881e-01
    z[9,8,4]  R2580     3.2931387424468994e-01
    z[9,8,4]  R2581     -1.1051273345947266e-01
    z[9,8,4]  R2582     1.2172869592905045e-01
    z[9,8,4]  R2583     -3.1887373328208923e-01
    z[9,8,4]  R2584     -1.2618668377399445e-01
    z[9,8,4]  R2585     3.1021785736083984e-01
    z[9,8,4]  R2586     -1.8007430434226990e-01
    z[9,8,4]  R2587     5.1927787065505981e-01
    z[9,8,4]  R2588     -0.198231503367424
    z[9,8,4]  R2589     -4.4913059473037720e-01
    z[9,8,4]  R2590     -7.4144983291625977e-01
    z[9,8,4]  R2591     2.5618669390678406e-01
    z[9,8,4]  R2592     -1.0460326820611954e-01
    z[9,8,4]  R2593     -8.8932946324348450e-02
    z[9,8,4]  R2594     -3.7543994188308716e-01
    z[9,8,4]  R2595     -5.5314081907272339e-01
    z[9,8,4]  R2596     -3.0125668644905090e-01
    z[9,8,4]  R2597     1.9281382858753204e-01
    z[9,8,4]  R2598     -1.4993591606616974e-01
    z[9,8,4]  R2599     6.6682964563369751e-01
    z[9,8,4]  R2600     4.2104795575141907e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2439     -1
    z[9,8,5]  R2440     1
    z[9,8,5]  R2443     -2.9786482453346252e-01
    z[9,8,5]  R2444     1.5181696973741055e-02
    z[9,8,5]  R2445     -1.6975127160549164e-01
    z[9,8,5]  R2446     -4.0652045607566833e-01
    z[9,8,5]  R2447     -3.2270747423171997e-01
    z[9,8,5]  R2448     1.8104752898216248e-01
    z[9,8,5]  R2449     5.0167441368103027e-01
    z[9,8,5]  R2450     2.3916438221931458e-01
    z[9,8,5]  R2451     6.8354773521423340e-01
    z[9,8,5]  R2452     1.2156743556261063e-01
    z[9,8,5]  R2453     -7.2249794006347656e-01
    z[9,8,5]  R2454     -1.2243092805147171e-01
    z[9,8,5]  R2455     -7.5230067968368530e-01
    z[9,8,5]  R2456     -6.4105218648910522e-01
    z[9,8,5]  R2457     -4.6413314342498779e-01
    z[9,8,5]  R2458     -6.1697411537170410e-01
    z[9,8,5]  R2459     2.6064833998680115e-01
    z[9,8,5]  R2460     -2.2591555118560791e-01
    z[9,8,5]  R2461     -4.9055758118629456e-01
    z[9,8,5]  R2462     1.9934152066707611e-01
    z[9,8,5]  R2463     2.4682748317718506e-01
    z[9,8,5]  R2464     -0.664214015007019
    z[9,8,5]  R2465     -7.1010160446166992e-01
    z[9,8,5]  R2466     -5.5496370792388916e-01
    z[9,8,5]  R2467     -3.6890843510627747e-01
    z[9,8,5]  R2468     4.3439719080924988e-01
    z[9,8,5]  R2469     -2.9076570272445679e-01
    z[9,8,5]  R2470     -3.8497292995452881e-01
    z[9,8,5]  R2471     -3.9543408155441284e-01
    z[9,8,5]  R2472     0.0978158637881279
    z[9,8,5]  R2473     -1.6848985850811005e-01
    z[9,8,5]  R2474     0.236422598361969
    z[9,8,5]  R2475     -7.4039202928543091e-01
    z[9,8,5]  R2476     -7.2094070911407471e-01
    z[9,8,5]  R2477     -3.1968402862548828e-01
    z[9,8,5]  R2478     -5.0114977359771729e-01
    z[9,8,5]  R2479     -3.0594348907470703e-01
    z[9,8,5]  R2480     2.2888499498367310e-01
    z[9,8,5]  R2481     4.2588862776756287e-01
    z[9,8,5]  R2482     -6.3209319114685059e-01
    z[9,8,5]  R2483     -4.0558010339736938e-01
    z[9,8,5]  R2484     -6.3632673025131226e-01
    z[9,8,5]  R2485     -1.9038234651088715e-01
    z[9,8,5]  R2486     -5.6710356473922729e-01
    z[9,8,5]  R2487     -5.7302755117416382e-01
    z[9,8,5]  R2488     -4.0226092934608459e-01
    z[9,8,5]  R2489     -2.1952791512012482e-01
    z[9,8,5]  R2490     -2.9151713848114014e-01
    z[9,8,5]  R2491     0.431945264339447
    z[9,8,5]  R2492     -2.8299632668495178e-01
    z[9,8,5]  R2493     -2.0611369609832764e-01
    z[9,8,5]  R2494     4.3252494931221008e-01
    z[9,8,5]  R2495     -6.3303405046463013e-01
    z[9,8,5]  R2496     0.0892023965716362
    z[9,8,5]  R2497     1.5050472319126129e-01
    z[9,8,5]  R2498     -8.9196033775806427e-02
    z[9,8,5]  R2499     2.2232902050018311e-01
    z[9,8,5]  R2500     -1.8899044394493103e-01
    z[9,8,5]  R2501     -3.0630609393119812e-01
    z[9,8,5]  R2502     2.9824903607368469e-01
    z[9,8,5]  R2503     -5.4416441917419434e-01
    z[9,8,5]  R2504     -3.9944788813591003e-01
    z[9,8,5]  R2505     -5.8354437351226807e-01
    z[9,8,5]  R2506     -3.1988191604614258e-01
    z[9,8,5]  R2507     -1.0568533092737198e-02
    z[9,8,5]  R2508     -3.8195142149925232e-01
    z[9,8,5]  R2509     3.2803717255592346e-01
    z[9,8,5]  R2510     1.1291011422872543e-01
    z[9,8,5]  R2511     -6.5225899219512939e-01
    z[9,8,5]  R2512     -1.0487017780542374e-01
    z[9,8,5]  R2513     1.6407051682472229e-01
    z[9,8,5]  R2514     -2.5416249036788940e-01
    z[9,8,5]  R2515     8.9542150497436523e-02
    z[9,8,5]  R2516     -1.5008129179477692e-01
    z[9,8,5]  R2517     -4.2632433772087097e-01
    z[9,8,5]  R2518     -4.1950282454490662e-01
    z[9,8,5]  R2519     -3.0137532949447632e-01
    z[9,8,5]  R2520     -4.6895641088485718e-01
    z[9,8,5]  R2521     7.9206518828868866e-02
    z[9,8,5]  R2522     2.2923554480075836e-01
    z[9,8,5]  R2523     -2.7379798889160156e-01
    z[9,8,5]  R2524     -2.3873747885227203e-01
    z[9,8,5]  R2525     -6.5112107992172241e-01
    z[9,8,5]  R2526     -4.5467257499694824e-01
    z[9,8,5]  R2527     -4.2832094430923462e-01
    z[9,8,5]  R2528     -2.2712954878807068e-01
    z[9,8,5]  R2529     -3.4039071202278137e-01
    z[9,8,5]  R2530     3.0946722626686096e-01
    z[9,8,5]  R2531     3.9994516968727112e-01
    z[9,8,5]  R2532     1.6013096272945404e-01
    z[9,8,5]  R2533     1.6711945831775665e-01
    z[9,8,5]  R2534     -2.1236881613731384e-01
    z[9,8,5]  R2535     -0.656708300113678
    z[9,8,5]  R2536     -4.6250590682029724e-01
    z[9,8,5]  R2537     3.4696620702743530e-01
    z[9,8,5]  R2538     -3.6067828536033630e-01
    z[9,8,5]  R2539     -2.3430296778678894e-01
    z[9,8,5]  R2540     -8.6028032004833221e-02
    z[9,8,5]  R2541     -4.0161529183387756e-01
    z[9,8,5]  R2542     3.9787840843200684e-01
    z[9,8,5]  R2543     -2.2953392565250397e-01
    z[9,8,5]  R2544     -4.5798502862453461e-02
    z[9,8,5]  R2545     -3.5307437181472778e-01
    z[9,8,5]  R2546     5.3968578577041626e-01
    z[9,8,5]  R2547     3.3117014169692993e-01
    z[9,8,5]  R2548     4.7005578875541687e-01
    z[9,8,5]  R2549     4.3799132108688354e-01
    z[9,8,5]  R2550     -6.3618764281272888e-02
    z[9,8,5]  R2551     -8.2405406236648560e-01
    z[9,8,5]  R2552     1.9800260663032532e-01
    z[9,8,5]  R2553     5.0412613153457642e-01
    z[9,8,5]  R2554     -5.0805461406707764e-01
    z[9,8,5]  R2555     3.7181344814598560e-03
    z[9,8,5]  R2556     2.9719021916389465e-01
    z[9,8,5]  R2557     2.3098704218864441e-01
    z[9,8,5]  R2558     -2.0979806780815125e-01
    z[9,8,5]  R2559     -1.5571042895317078e-01
    z[9,8,5]  R2560     -2.1392270922660828e-01
    z[9,8,5]  R2561     -6.9061291217803955e-01
    z[9,8,5]  R2562     -2.8672060370445251e-01
    z[9,8,5]  R2563     -3.4048205614089966e-01
    z[9,8,5]  R2564     -1.7928700149059296e-01
    z[9,8,5]  R2565     -7.5652748346328735e-02
    z[9,8,5]  R2566     1.7019577324390411e-01
    z[9,8,5]  R2567     -4.0748879313468933e-01
    z[9,8,5]  R2568     5.4188175126910210e-03
    z[9,8,5]  R2569     -4.3096852302551270e-01
    z[9,8,5]  R2570     2.1025471389293671e-01
    z[9,8,5]  R2571     -3.4225851297378540e-01
    z[9,8,5]  R2572     -2.2261887788772583e-01
    z[9,8,5]  R2573     -3.7638089060783386e-01
    z[9,8,5]  R2574     3.6430227756500244e-01
    z[9,8,5]  R2575     6.5975874662399292e-01
    z[9,8,5]  R2576     5.1600843667984009e-01
    z[9,8,5]  R2577     3.8433954119682312e-01
    z[9,8,5]  R2578     1.9256788492202759e-01
    z[9,8,5]  R2579     -4.2669618129730225e-01
    z[9,8,5]  R2580     5.8736038208007812e-01
    z[9,8,5]  R2581     -6.5819948911666870e-01
    z[9,8,5]  R2582     -7.7228508889675140e-02
    z[9,8,5]  R2583     -3.1256824731826782e-01
    z[9,8,5]  R2584     2.6809409260749817e-01
    z[9,8,5]  R2585     -1.7583874985575676e-02
    z[9,8,5]  R2586     -1.0468696802854538e-01
    z[9,8,5]  R2587     -1.9151781499385834e-01
    z[9,8,5]  R2588     -5.7094257324934006e-02
    z[9,8,5]  R2589     -0.263357013463974
    z[9,8,5]  R2590     7.4967904947698116e-03
    z[9,8,5]  R2591     -0.0255416352301836
    z[9,8,5]  R2592     3.8038536906242371e-01
    z[9,8,5]  R2593     2.9868012666702271e-01
    z[9,8,5]  R2594     -7.8571937978267670e-02
    z[9,8,5]  R2595     -2.2287155687808990e-01
    z[9,8,5]  R2596     -1.0560614988207817e-02
    z[9,8,5]  R2597     0.505304753780365
    z[9,8,5]  R2598     7.6099641621112823e-02
    z[9,8,5]  R2599     -3.4238103032112122e-01
    z[9,8,5]  R2600     2.7827474474906921e-01
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2441     -1
    z[9,8,6]  R2442     1
    z[9,8,6]  R2443     9.0677961707115173e-02
    z[9,8,6]  R2444     -4.0827459096908569e-01
    z[9,8,6]  R2445     -5.8025825768709183e-02
    z[9,8,6]  R2446     4.2708155512809753e-01
    z[9,8,6]  R2447     -4.3588000535964966e-01
    z[9,8,6]  R2448     -2.5381874293088913e-02
    z[9,8,6]  R2449     -1.1201821267604828e-01
    z[9,8,6]  R2450     -5.7448309659957886e-01
    z[9,8,6]  R2451     -2.3888534307479858e-01
    z[9,8,6]  R2452     -2.1509103477001190e-01
    z[9,8,6]  R2453     -2.9075646400451660e-01
    z[9,8,6]  R2454     -1.8486784771084785e-02
    z[9,8,6]  R2455     0.271684855222702
    z[9,8,6]  R2456     -2.7988600730895996e-01
    z[9,8,6]  R2457     -2.2420364618301392e-01
    z[9,8,6]  R2458     2.8579053282737732e-01
    z[9,8,6]  R2459     2.6356074213981628e-01
    z[9,8,6]  R2460     6.6798651218414307e-01
    z[9,8,6]  R2461     -7.2378120385110378e-03
    z[9,8,6]  R2462     1.7126396298408508e-01
    z[9,8,6]  R2463     2.7689644694328308e-01
    z[9,8,6]  R2464     -4.5411635190248489e-02
    z[9,8,6]  R2465     2.3220393061637878e-01
    z[9,8,6]  R2466     4.9505755305290222e-01
    z[9,8,6]  R2467     -3.1286051869392395e-01
    z[9,8,6]  R2468     0.366493284702301
    z[9,8,6]  R2469     -7.5198292732238770e-02
    z[9,8,6]  R2470     6.3373708724975586e-01
    z[9,8,6]  R2471     0.578849732875824
    z[9,8,6]  R2472     2.9332116246223450e-01
    z[9,8,6]  R2473     -3.8576591014862061e-01
    z[9,8,6]  R2474     -4.2447996139526367e-01
    z[9,8,6]  R2475     2.0087754726409912e-01
    z[9,8,6]  R2476     -1.8044428527355194e-01
    z[9,8,6]  R2477     1.0024210065603256e-01
    z[9,8,6]  R2478     1.5175281465053558e-01
    z[9,8,6]  R2479     -3.4700337052345276e-01
    z[9,8,6]  R2480     1.2395840138196945e-01
    z[9,8,6]  R2481     -1.2176579236984253e-01
    z[9,8,6]  R2482     2.6281037926673889e-01
    z[9,8,6]  R2483     7.6603099703788757e-02
    z[9,8,6]  R2484     -2.5848224759101868e-01
    z[9,8,6]  R2485     -2.7331728488206863e-02
    z[9,8,6]  R2486     1.7281077802181244e-02
    z[9,8,6]  R2487     -3.5236570239067078e-01
    z[9,8,6]  R2488     1.5219584107398987e-01
    z[9,8,6]  R2489     -9.6638485789299011e-02
    z[9,8,6]  R2490     -4.5479765534400940e-01
    z[9,8,6]  R2491     0.0490252859890461
    z[9,8,6]  R2492     1.2319782376289368e-01
    z[9,8,6]  R2493     -3.0960068106651306e-02
    z[9,8,6]  R2494     -4.3277588486671448e-01
    z[9,8,6]  R2495     -1.4188045263290405e-01
    z[9,8,6]  R2496     1.3368442654609680e-01
    z[9,8,6]  R2497     -1.2499737739562988e-01
    z[9,8,6]  R2498     -1.5704806149005890e-01
    z[9,8,6]  R2499     2.5493544340133667e-01
    z[9,8,6]  R2500     0.0582747608423233
    z[9,8,6]  R2501     -2.8421500325202942e-01
    z[9,8,6]  R2502     -3.8688236474990845e-01
    z[9,8,6]  R2503     1.7495671287178993e-02
    z[9,8,6]  R2504     -1.6256733238697052e-01
    z[9,8,6]  R2505     4.0815880894660950e-01
    z[9,8,6]  R2506     2.1923069655895233e-01
    z[9,8,6]  R2507     2.5234758853912354e-01
    z[9,8,6]  R2508     -9.7453787922859192e-02
    z[9,8,6]  R2509     1.0200767777860165e-02
    z[9,8,6]  R2510     -4.6653822064399719e-02
    z[9,8,6]  R2511     -1.3175633549690247e-01
    z[9,8,6]  R2512     1.5665335953235626e-01
    z[9,8,6]  R2513     5.2384608983993530e-01
    z[9,8,6]  R2514     6.6977924108505249e-01
    z[9,8,6]  R2515     -2.2763228416442871e-01
    z[9,8,6]  R2516     2.8818333521485329e-02
    z[9,8,6]  R2517     4.9332848191261292e-01
    z[9,8,6]  R2518     2.4070571362972260e-01
    z[9,8,6]  R2519     -7.6405160129070282e-02
    z[9,8,6]  R2520     3.3910922706127167e-02
    z[9,8,6]  R2521     -5.6884109973907471e-01
    z[9,8,6]  R2522     3.9632487297058105e-01
    z[9,8,6]  R2523     -1.7966100573539734e-01
    z[9,8,6]  R2524     -0.0784110277891159
    z[9,8,6]  R2525     1.2755751609802246e-01
    z[9,8,6]  R2526     -0.190152108669281
    z[9,8,6]  R2527     -1.0380861163139343e-01
    z[9,8,6]  R2528     -4.7682128846645355e-02
    z[9,8,6]  R2529     2.1728739142417908e-01
    z[9,8,6]  R2530     2.1173125505447388e-01
    z[9,8,6]  R2531     -5.3208328783512115e-02
    z[9,8,6]  R2532     2.3521710932254791e-01
    z[9,8,6]  R2533     -2.6275765895843506e-01
    z[9,8,6]  R2534     9.0591244399547577e-02
    z[9,8,6]  R2535     0.00939799565821886
    z[9,8,6]  R2536     1.2457884848117828e-01
    z[9,8,6]  R2537     1.3694353401660919e-01
    z[9,8,6]  R2538     -2.0731341838836670e-01
    z[9,8,6]  R2539     -2.3764740675687790e-02
    z[9,8,6]  R2540     -4.9654132127761841e-01
    z[9,8,6]  R2541     -4.4730773568153381e-01
    z[9,8,6]  R2542     -1.4911796152591705e-01
    z[9,8,6]  R2543     -5.2431887388229370e-01
    z[9,8,6]  R2544     3.0611521005630493e-01
    z[9,8,6]  R2545     -4.4138675928115845e-01
    z[9,8,6]  R2546     7.2807647287845612e-02
    z[9,8,6]  R2547     -3.8419792056083679e-01
    z[9,8,6]  R2548     -2.8833723068237305e-01
    z[9,8,6]  R2549     -2.2672960162162781e-01
    z[9,8,6]  R2550     5.2644795179367065e-01
    z[9,8,6]  R2551     -3.2018184661865234e-01
    z[9,8,6]  R2552     -1.7275755107402802e-01
    z[9,8,6]  R2553     2.3491667211055756e-01
    z[9,8,6]  R2554     2.8786253929138184e-01
    z[9,8,6]  R2555     0.0482945442199707
    z[9,8,6]  R2556     -4.1684368252754211e-01
    z[9,8,6]  R2557     -2.6613765954971313e-01
    z[9,8,6]  R2558     -4.2893379926681519e-01
    z[9,8,6]  R2559     -2.9815217852592468e-01
    z[9,8,6]  R2560     5.0212317705154419e-01
    z[9,8,6]  R2561     3.9354014396667480e-01
    z[9,8,6]  R2562     9.1656424105167389e-02
    z[9,8,6]  R2563     -2.4070023000240326e-01
    z[9,8,6]  R2564     -0.325311541557312
    z[9,8,6]  R2565     -2.5049161911010742e-01
    z[9,8,6]  R2566     4.4305855035781860e-01
    z[9,8,6]  R2567     -3.9032322168350220e-01
    z[9,8,6]  R2568     2.7816012501716614e-01
    z[9,8,6]  R2569     2.6311546564102173e-01
    z[9,8,6]  R2570     -1.1615970730781555e-01
    z[9,8,6]  R2571     2.7570804953575134e-01
    z[9,8,6]  R2572     -1.5641090273857117e-01
    z[9,8,6]  R2573     -1.8282571434974670e-01
    z[9,8,6]  R2574     -3.7996169924736023e-01
    z[9,8,6]  R2575     4.2082633823156357e-02
    z[9,8,6]  R2576     2.8814616799354553e-01
    z[9,8,6]  R2577     3.2460793852806091e-02
    z[9,8,6]  R2578     2.6251126546412706e-03
    z[9,8,6]  R2579     2.4456915259361267e-01
    z[9,8,6]  R2580     1.1607024818658829e-01
    z[9,8,6]  R2581     -4.3984800577163696e-01
    z[9,8,6]  R2582     5.9148907661437988e-02
    z[9,8,6]  R2583     2.5324997305870056e-01
    z[9,8,6]  R2584     -3.0960096046328545e-02
    z[9,8,6]  R2585     -3.7550774216651917e-01
    z[9,8,6]  R2586     -3.1864714622497559e-01
    z[9,8,6]  R2587     -7.7630870044231415e-02
    z[9,8,6]  R2588     1.1627739667892456e-01
    z[9,8,6]  R2589     3.2463806867599487e-01
    z[9,8,6]  R2590     6.4279779791831970e-02
    z[9,8,6]  R2591     -5.8681093156337738e-02
    z[9,8,6]  R2592     3.7266245484352112e-01
    z[9,8,6]  R2593     2.5364753603935242e-01
    z[9,8,6]  R2594     -2.3666703701019287e-01
    z[9,8,6]  R2595     5.1761954091489315e-04
    z[9,8,6]  R2596     -2.3464260995388031e-01
    z[9,8,6]  R2597     2.6170909404754639e-03
    z[9,8,6]  R2598     -4.1718250513076782e-01
    z[9,8,6]  R2599     -2.9475545883178711e-01
    z[9,8,6]  R2600     -7.0257700979709625e-02
    z[9,10,0]  R83       -1
    z[9,10,0]  R92       1
    z[9,10,0]  R2601     -1
    z[9,10,0]  R2602     1
    z[9,10,0]  R2615     -7.1938061714172363e-01
    z[9,10,0]  R2616     -7.3434668779373169e-01
    z[9,10,0]  R2617     -8.7153381109237671e-01
    z[9,10,0]  R2618     3.9826877415180206e-02
    z[9,10,0]  R2619     4.2995803058147430e-02
    z[9,10,0]  R2620     2.3911140859127045e-02
    z[9,10,0]  R2621     6.6440761089324951e-02
    z[9,10,0]  R2622     -0.0642852932214737
    z[9,10,0]  R2623     1.2891144491732121e-02
    z[9,10,0]  R2624     1.9521045684814453e-01
    z[9,10,0]  R2625     1.8371686339378357e-01
    z[9,10,0]  R2626     3.2115471363067627e-01
    z[9,10,0]  R2627     1.8859191238880157e-01
    z[9,10,0]  R2628     1.8353742361068726e-01
    z[9,10,0]  R2629     2.9240572452545166e-01
    z[9,10,0]  R2630     8.1658527255058289e-02
    z[9,10,0]  R2631     1.1317206174135208e-01
    z[9,10,0]  R2632     -1.2729771435260773e-02
    z[9,10,0]  R2633     1.7303159832954407e-01
    z[9,10,0]  R2634     -1.5301170945167542e-01
    z[9,10,0]  R2635     2.3762527108192444e-01
    z[9,10,0]  R2636     -0.0158318392932415
    z[9,10,0]  R2637     3.9074033498764038e-01
    z[9,10,0]  R2638     2.6645278930664062e-01
    z[9,10,0]  R2639     9.1636814177036285e-02
    z[9,10,0]  R2640     -2.0787367224693298e-01
    z[9,10,0]  R2641     4.5522534847259521e-01
    z[9,10,0]  R2642     0.441200852394104
    z[9,10,0]  R2643     -2.7625164017081261e-02
    z[9,10,0]  R2644     -3.2364460825920105e-01
    z[9,10,0]  R2645     -2.3119792342185974e-01
    z[9,10,0]  R2646     2.4720193445682526e-01
    z[9,10,0]  R2647     2.4882322549819946e-01
    z[9,10,0]  R2648     3.7292793393135071e-01
    z[9,10,0]  R2649     1.8218696117401123e-01
    z[9,10,0]  R2650     1.3982728123664856e-01
    z[9,10,0]  R2651     4.4310668110847473e-01
    z[9,10,0]  R2652     -2.5280886888504028e-01
    z[9,10,0]  R2653     2.0975257456302643e-01
    z[9,10,0]  R2654     4.5805528759956360e-01
    z[9,10,0]  R2655     -1.5050864778459072e-02
    z[9,10,0]  R2656     3.5582253336906433e-01
    z[9,10,0]  R2657     5.5501270294189453e-01
    z[9,10,0]  R2658     4.5985287427902222e-01
    z[9,10,0]  R2659     1.1087729036808014e-01
    z[9,10,0]  R2660     1.2989985942840576e-01
    z[9,10,0]  R2661     1.1822313815355301e-01
    z[9,10,0]  R2662     2.2202843427658081e-01
    z[9,10,0]  R2663     -2.5484177470207214e-01
    z[9,10,0]  R2664     1.3983985781669617e-01
    z[9,10,0]  R2665     6.1186897754669189e-01
    z[9,10,0]  R2666     0.0938342809677124
    z[9,10,0]  R2667     3.5296627879142761e-01
    z[9,10,0]  R2668     -1.8386578187346458e-02
    z[9,10,0]  R2669     -1.2858489155769348e-01
    z[9,10,0]  R2670     -1.9241939485073090e-01
    z[9,10,0]  R2671     -6.3853137195110321e-02
    z[9,10,0]  R2672     -1.3127784430980682e-01
    z[9,10,0]  R2673     -7.1821823716163635e-02
    z[9,10,0]  R2674     1.0111336596310139e-02
    z[9,10,0]  R2675     0.541682779788971
    z[9,10,0]  R2676     5.1831579208374023e-01
    z[9,10,0]  R2677     -1.7896954715251923e-01
    z[9,10,0]  R2678     2.5382828712463379e-01
    z[9,10,0]  R2679     -4.7841900587081909e-01
    z[9,10,0]  R2680     -1.4419214427471161e-01
    z[9,10,0]  R2681     1.1953799426555634e-01
    z[9,10,0]  R2682     1.8817475438117981e-01
    z[9,10,0]  R2683     -1.6221959888935089e-01
    z[9,10,0]  R2684     -3.3538690209388733e-01
    z[9,10,0]  R2685     -6.7173206806182861e-01
    z[9,10,0]  R2686     -7.2031044960021973e-01
    z[9,10,0]  R2687     -5.4360526800155640e-01
    z[9,10,0]  R2688     4.0064170956611633e-02
    z[9,10,0]  R2689     -3.9596247673034668e-01
    z[9,10,0]  R2690     -1.0639448463916779e-01
    z[9,10,0]  R2691     -3.3186238259077072e-02
    z[9,10,0]  R2692     -1.9214755296707153e-01
    z[9,10,0]  R2693     1.7047522589564323e-02
    z[9,10,0]  R2694     7.0493870973587036e-01
    z[9,10,0]  R2695     2.5561478734016418e-01
    z[9,10,0]  R2696     -4.4059613347053528e-01
    z[9,10,0]  R2697     3.7649184465408325e-01
    z[9,10,0]  R2698     3.3047541975975037e-01
    z[9,10,0]  R2699     5.3289394825696945e-02
    z[9,10,0]  R2700     3.9863339066505432e-01
    z[9,10,0]  R2701     5.3017848730087280e-01
    z[9,10,0]  R2702     3.3325755596160889e-01
    z[9,10,0]  R2703     -4.5387947559356689e-01
    z[9,10,0]  R2704     7.8121083974838257e-01
    z[9,10,0]  R2705     7.5855886936187744e-01
    z[9,10,0]  R2706     7.5848937034606934e-01
    z[9,10,0]  R2707     5.9523308277130127e-01
    z[9,10,0]  R2708     5.2806007862091064e-01
    z[9,10,0]  R2709     8.8914191722869873e-01
    z[9,10,0]  R2710     4.8579803109169006e-01
    z[9,10,0]  R2711     -4.7163820266723633e-01
    z[9,10,0]  R2712     -3.2286411523818970e-01
    z[9,10,0]  R2713     -6.2224978208541870e-01
    z[9,10,0]  R2714     0.667977511882782
    z[9,10,0]  R2715     0.730576753616333
    z[9,10,0]  R2716     -6.6829109191894531e-01
    z[9,10,0]  R2717     -2.2789682447910309e-01
    z[9,10,0]  R2718     5.1489800214767456e-01
    z[9,10,0]  R2719     0.525680661201477
    z[9,10,0]  R2720     1.4966865070164204e-02
    z[9,10,0]  R2721     -3.3636394888162613e-02
    z[9,10,0]  R2722     2.4430401623249054e-02
    z[9,10,1]  R84       -1
    z[9,10,1]  R93       1
    z[9,10,1]  R2603     -1
    z[9,10,1]  R2604     1
    z[9,10,1]  R2615     3.8767442107200623e-01
    z[9,10,1]  R2616     1.7109133303165436e-01
    z[9,10,1]  R2617     2.1183459088206291e-02
    z[9,10,1]  R2618     7.4613589048385620e-01
    z[9,10,1]  R2619     7.9002523422241211e-01
    z[9,10,1]  R2620     -4.8140946030616760e-01
    z[9,10,1]  R2621     3.8775098323822021e-01
    z[9,10,1]  R2622     -1.8589808046817780e-01
    z[9,10,1]  R2623     6.1399197578430176e-01
    z[9,10,1]  R2624     1.9840073585510254e-01
    z[9,10,1]  R2625     -3.6536478996276855e-01
    z[9,10,1]  R2626     -2.4173070490360260e-01
    z[9,10,1]  R2627     -0.476881742477417
    z[9,10,1]  R2628     -1.9843542575836182e-01
    z[9,10,1]  R2629     -5.4412138462066650e-01
    z[9,10,1]  R2630     -6.9752758741378784e-01
    z[9,10,1]  R2631     2.8069606423377991e-01
    z[9,10,1]  R2632     -7.4881382286548615e-02
    z[9,10,1]  R2633     0.581967830657959
    z[9,10,1]  R2634     3.7978556752204895e-01
    z[9,10,1]  R2635     5.7962757349014282e-01
    z[9,10,1]  R2636     2.7062505483627319e-01
    z[9,10,1]  R2637     1.4633838832378387e-01
    z[9,10,1]  R2638     -2.8048139810562134e-01
    z[9,10,1]  R2639     -9.0064823627471924e-02
    z[9,10,1]  R2640     4.3462336063385010e-01
    z[9,10,1]  R2641     -6.3214832544326782e-01
    z[9,10,1]  R2642     3.3744487911462784e-02
    z[9,10,1]  R2643     6.4503389596939087e-01
    z[9,10,1]  R2644     6.3430631160736084e-01
    z[9,10,1]  R2645     4.7585359215736389e-01
    z[9,10,1]  R2646     3.6725082993507385e-01
    z[9,10,1]  R2647     -1.5736138820648193e-01
    z[9,10,1]  R2648     -3.0708810687065125e-01
    z[9,10,1]  R2649     -2.8330606222152710e-01
    z[9,10,1]  R2650     -3.6009213328361511e-01
    z[9,10,1]  R2651     1.7421099543571472e-01
    z[9,10,1]  R2652     -6.5730142593383789e-01
    z[9,10,1]  R2653     7.4005979299545288e-01
    z[9,10,1]  R2654     -1.4961113035678864e-01
    z[9,10,1]  R2655     -0.664179265499115
    z[9,10,1]  R2656     -4.6668875217437744e-01
    z[9,10,1]  R2657     -5.1353383064270020e-01
    z[9,10,1]  R2658     2.4946649372577667e-01
    z[9,10,1]  R2659     6.0474222898483276e-01
    z[9,10,1]  R2660     6.6959589719772339e-02
    z[9,10,1]  R2661     2.4652989581227303e-02
    z[9,10,1]  R2662     -2.8708785772323608e-01
    z[9,10,1]  R2663     7.7099275588989258e-01
    z[9,10,1]  R2664     -4.4385217130184174e-02
    z[9,10,1]  R2665     -4.5468533039093018e-01
    z[9,10,1]  R2666     4.5502173900604248e-01
    z[9,10,1]  R2667     1.3688434660434723e-01
    z[9,10,1]  R2668     -6.8872314691543579e-01
    z[9,10,1]  R2669     -7.5139582157135010e-01
    z[9,10,1]  R2670     -8.6946922540664673e-01
    z[9,10,1]  R2671     -7.1054071187973022e-01
    z[9,10,1]  R2672     -7.5809156894683838e-01
    z[9,10,1]  R2673     8.4869980812072754e-01
    z[9,10,1]  R2674     0.495947003364563
    z[9,10,1]  R2675     -0.353481262922287
    z[9,10,1]  R2676     -3.2727217767387629e-03
    z[9,10,1]  R2677     -5.8670526742935181e-01
    z[9,10,1]  R2678     -1.5659306943416595e-01
    z[9,10,1]  R2679     -7.8024029731750488e-01
    z[9,10,1]  R2680     -6.8780100345611572e-01
    z[9,10,1]  R2681     -8.3306348323822021e-01
    z[9,10,1]  R2682     -7.9620856046676636e-01
    z[9,10,1]  R2683     9.6819110214710236e-02
    z[9,10,1]  R2684     -2.3146387934684753e-01
    z[9,10,1]  R2685     -2.2125518321990967e-01
    z[9,10,1]  R2686     -0.07354686409235
    z[9,10,1]  R2687     -2.5858255103230476e-02
    z[9,10,1]  R2688     1.3236142694950104e-01
    z[9,10,1]  R2689     7.1941041946411133e-01
    z[9,10,1]  R2690     0.777656614780426
    z[9,10,1]  R2691     9.2878192663192749e-01
    z[9,10,1]  R2692     7.6075583696365356e-01
    z[9,10,1]  R2693     4.4521963596343994e-01
    z[9,10,1]  R2694     5.6351685523986816e-01
    z[9,10,1]  R2695     6.1872792243957520e-01
    z[9,10,1]  R2696     -8.7522892281413078e-03
    z[9,10,1]  R2697     5.6009984016418457e-01
    z[9,10,1]  R2698     3.4401011466979980e-01
    z[9,10,1]  R2699     6.8093389272689819e-01
    z[9,10,1]  R2700     5.4238563776016235e-01
    z[9,10,1]  R2701     0.575753927230835
    z[9,10,1]  R2702     0.0868731439113617
    z[9,10,1]  R2703     -2.7706253528594971e-01
    z[9,10,1]  R2704     1.0392618924379349e-01
    z[9,10,1]  R2705     2.5629934668540955e-01
    z[9,10,1]  R2706     -1.1515791714191437e-01
    z[9,10,1]  R2707     6.5352815389633179e-01
    z[9,10,1]  R2708     4.6459311246871948e-01
    z[9,10,1]  R2709     2.5869302451610565e-02
    z[9,10,1]  R2710     2.3106144741177559e-02
    z[9,10,1]  R2711     0.689746618270874
    z[9,10,1]  R2712     7.8779542446136475e-01
    z[9,10,1]  R2713     5.3671532869338989e-01
    z[9,10,1]  R2714     4.2481273412704468e-01
    z[9,10,1]  R2715     4.7516006231307983e-01
    z[9,10,1]  R2716     5.3228777647018433e-01
    z[9,10,1]  R2717     8.7884134054183960e-01
    z[9,10,1]  R2718     -6.4468294382095337e-01
    z[9,10,1]  R2719     -4.4041857123374939e-01
    z[9,10,1]  R2720     -3.7349492311477661e-01
    z[9,10,1]  R2721     -9.4402414560317993e-01
    z[9,10,1]  R2722     -9.1908359527587891e-01
    z[9,10,2]  R85       -1
    z[9,10,2]  R94       1
    z[9,10,2]  R2605     -1
    z[9,10,2]  R2606     1
    z[9,10,2]  R2615     2.6962780952453613e-01
    z[9,10,2]  R2616     -1.5595278143882751e-01
    z[9,10,2]  R2617     -2.7372547984123230e-01
    z[9,10,2]  R2618     1.2897615134716034e-01
    z[9,10,2]  R2619     -2.4308270215988159e-01
    z[9,10,2]  R2620     3.0984896421432495e-01
    z[9,10,2]  R2621     -1.4209984242916107e-01
    z[9,10,2]  R2622     5.9943532943725586e-01
    z[9,10,2]  R2623     -1.0448925197124481e-01
    z[9,10,2]  R2624     1.3479281216859818e-02
    z[9,10,2]  R2625     1.1287947744131088e-01
    z[9,10,2]  R2626     1.1302204430103302e-01
    z[9,10,2]  R2627     9.8053090274333954e-02
    z[9,10,2]  R2628     7.6808951795101166e-02
    z[9,10,2]  R2629     1.2116042524576187e-01
    z[9,10,2]  R2630     -6.9153765216469765e-03
    z[9,10,2]  R2631     -3.3691966533660889e-01
    z[9,10,2]  R2632     1.6750842332839966e-01
    z[9,10,2]  R2633     -3.8306069374084473e-01
    z[9,10,2]  R2634     -9.7597584128379822e-02
    z[9,10,2]  R2635     -1.6526705026626587e-01
    z[9,10,2]  R2636     -1.6783097386360168e-01
    z[9,10,2]  R2637     4.0195193886756897e-01
    z[9,10,2]  R2638     3.0085697770118713e-01
    z[9,10,2]  R2639     5.0224140286445618e-02
    z[9,10,2]  R2640     -6.7384196445345879e-03
    z[9,10,2]  R2641     2.2282119095325470e-01
    z[9,10,2]  R2642     1.4660651981830597e-01
    z[9,10,2]  R2643     2.7640566229820251e-01
    z[9,10,2]  R2644     -1.7612041532993317e-01
    z[9,10,2]  R2645     -1.9000692665576935e-01
    z[9,10,2]  R2646     -2.3613980412483215e-01
    z[9,10,2]  R2647     1.6630922257900238e-01
    z[9,10,2]  R2648     0.278865247964859
    z[9,10,2]  R2649     3.4774717688560486e-01
    z[9,10,2]  R2650     -2.6795920729637146e-01
    z[9,10,2]  R2651     2.4316211044788361e-01
    z[9,10,2]  R2652     0.072159044444561
    z[9,10,2]  R2653     -1.4607223868370056e-01
    z[9,10,2]  R2654     -3.6402802914381027e-02
    z[9,10,2]  R2655     -0.0696464404463768
    z[9,10,2]  R2656     3.4577544778585434e-02
    z[9,10,2]  R2657     1.7927622795104980e-01
    z[9,10,2]  R2658     -4.9369469285011292e-02
    z[9,10,2]  R2659     -8.6866080760955811e-02
    z[9,10,2]  R2660     -1.8797514960169792e-02
    z[9,10,2]  R2661     1.4925029873847961e-01
    z[9,10,2]  R2662     -3.7630814313888550e-01
    z[9,10,2]  R2663     9.9292054772377014e-02
    z[9,10,2]  R2664     2.7988898754119873e-01
    z[9,10,2]  R2665     -2.0557044446468353e-01
    z[9,10,2]  R2666     4.0105696767568588e-02
    z[9,10,2]  R2667     2.7256676554679871e-01
    z[9,10,2]  R2668     0.440176784992218
    z[9,10,2]  R2669     5.3659409284591675e-01
    z[9,10,2]  R2670     2.4309273064136505e-01
    z[9,10,2]  R2671     5.5031704902648926e-01
    z[9,10,2]  R2672     4.6665042638778687e-01
    z[9,10,2]  R2673     -2.4337400496006012e-01
    z[9,10,2]  R2674     -7.5156822800636292e-02
    z[9,10,2]  R2675     3.5064734518527985e-02
    z[9,10,2]  R2676     4.2925927042961121e-01
    z[9,10,2]  R2677     1.1458951234817505e-01
    z[9,10,2]  R2678     1.7669038474559784e-01
    z[9,10,2]  R2679     1.3559868931770325e-01
    z[9,10,2]  R2680     1.8198868632316589e-01
    z[9,10,2]  R2681     2.8437674045562744e-01
    z[9,10,2]  R2682     -2.2518450021743774e-01
    z[9,10,2]  R2683     6.3735437393188477e-01
    z[9,10,2]  R2684     7.2271156311035156e-01
    z[9,10,2]  R2685     4.2068734765052795e-01
    z[9,10,2]  R2686     3.9869260787963867e-01
    z[9,10,2]  R2687     4.7542482614517212e-01
    z[9,10,2]  R2688     7.8396451473236084e-01
    z[9,10,2]  R2689     1.4413902163505554e-01
    z[9,10,2]  R2690     -0.00922539085149765
    z[9,10,2]  R2691     2.5615987181663513e-01
    z[9,10,2]  R2692     2.3350395262241364e-02
    z[9,10,2]  R2693     1.0893570631742477e-01
    z[9,10,2]  R2694     -3.6954489350318909e-01
    z[9,10,2]  R2695     3.5614830255508423e-01
    z[9,10,2]  R2696     5.7090330123901367e-01
    z[9,10,2]  R2697     7.9694926738739014e-02
    z[9,10,2]  R2698     1.1453211307525635e-01
    z[9,10,2]  R2699     4.4933900237083435e-02
    z[9,10,2]  R2700     2.8335331007838249e-03
    z[9,10,2]  R2701     6.3851945102214813e-02
    z[9,10,2]  R2702     1.8226327374577522e-02
    z[9,10,2]  R2703     3.9491972327232361e-01
    z[9,10,2]  R2704     -3.3328625559806824e-01
    z[9,10,2]  R2705     -1.5988531708717346e-01
    z[9,10,2]  R2706     -1.8396428227424622e-01
    z[9,10,2]  R2707     2.0990529656410217e-01
    z[9,10,2]  R2708     -2.2523456811904907e-01
    z[9,10,2]  R2709     2.3487906157970428e-01
    z[9,10,2]  R2710     -1.5950015187263489e-01
    z[9,10,2]  R2711     -5.5727638304233551e-02
    z[9,10,2]  R2712     -1.8105761706829071e-01
    z[9,10,2]  R2713     0.433397114276886
    z[9,10,2]  R2714     1.0749153792858124e-02
    z[9,10,2]  R2715     2.0894598215818405e-02
    z[9,10,2]  R2716     -1.8183549400418997e-03
    z[9,10,2]  R2717     -9.2977546155452728e-02
    z[9,10,2]  R2718     3.6989018321037292e-01
    z[9,10,2]  R2719     2.5401926040649414e-01
    z[9,10,2]  R2720     -2.0009872317314148e-01
    z[9,10,2]  R2721     -1.8154628574848175e-01
    z[9,10,2]  R2722     -2.4609299004077911e-01
    z[9,10,3]  R86       -1
    z[9,10,3]  R95       1
    z[9,10,3]  R2607     -1
    z[9,10,3]  R2608     1
    z[9,10,3]  R2615     5.3373761475086212e-02
    z[9,10,3]  R2616     4.5152485370635986e-01
    z[9,10,3]  R2617     3.2599920034408569e-01
    z[9,10,3]  R2618     -2.1406471729278564e-01
    z[9,10,3]  R2619     1.4406421780586243e-01
    z[9,10,3]  R2620     7.9791283607482910e-01
    z[9,10,3]  R2621     -5.7614302635192871e-01
    z[9,10,3]  R2622     -3.7967890501022339e-01
    z[9,10,3]  R2623     -1.8653295934200287e-01
    z[9,10,3]  R2624     -9.2315798997879028e-01
    z[9,10,3]  R2625     3.3459299802780151e-01
    z[9,10,3]  R2626     8.7592297792434692e-01
    z[9,10,3]  R2627     2.8328070044517517e-01
    z[9,10,3]  R2628     3.9715844392776489e-01
    z[9,10,3]  R2629     2.5570935010910034e-01
    z[9,10,3]  R2630     2.0916453003883362e-01
    z[9,10,3]  R2631     -1.6822256147861481e-01
    z[9,10,3]  R2632     6.4203584194183350e-01
    z[9,10,3]  R2633     1.5802358090877533e-01
    z[9,10,3]  R2634     -7.8423309326171875e-01
    z[9,10,3]  R2635     -2.1199563145637512e-01
    z[9,10,3]  R2636     -6.7315685749053955e-01
    z[9,10,3]  R2637     3.1995415687561035e-01
    z[9,10,3]  R2638     4.2300209403038025e-01
    z[9,10,3]  R2639     7.8073817491531372e-01
    z[9,10,3]  R2640     4.8033601045608521e-01
    z[9,10,3]  R2641     4.6407714486122131e-01
    z[9,10,3]  R2642     4.0075761079788208e-01
    z[9,10,3]  R2643     -0.0906476080417633
    z[9,10,3]  R2644     2.5016140937805176e-01
    z[9,10,3]  R2645     -7.0939630270004272e-01
    z[9,10,3]  R2646     -7.0446836948394775e-01
    z[9,10,3]  R2647     4.7615560889244080e-01
    z[9,10,3]  R2648     3.6661583185195923e-01
    z[9,10,3]  R2649     6.3652658462524414e-01
    z[9,10,3]  R2650     6.4629054069519043e-01
    z[9,10,3]  R2651     6.1970251798629761e-01
    z[9,10,3]  R2652     6.5345507860183716e-01
    z[9,10,3]  R2653     -2.6025879383087158e-01
    z[9,10,3]  R2654     0.534384548664093
    z[9,10,3]  R2655     6.1577588319778442e-01
    z[9,10,3]  R2656     4.0714344382286072e-01
    z[9,10,3]  R2657     5.9882515668869019e-01
    z[9,10,3]  R2658     6.3399654626846313e-01
    z[9,10,3]  R2659     3.2498005032539368e-01
    z[9,10,3]  R2660     8.8929927349090576e-01
    z[9,10,3]  R2661     8.9148283004760742e-01
    z[9,10,3]  R2662     6.5901094675064087e-01
    z[9,10,3]  R2663     3.6119830608367920e-01
    z[9,10,3]  R2664     8.6791312694549561e-01
    z[9,10,3]  R2665     5.4483503103256226e-01
    z[9,10,3]  R2666     -6.0689771175384521e-01
    z[9,10,3]  R2667     0.537681519985199
    z[9,10,3]  R2668     -4.3805586174130440e-03
    z[9,10,3]  R2669     -9.8440952599048615e-02
    z[9,10,3]  R2670     -2.0977884531021118e-01
    z[9,10,3]  R2671     -1.1612334847450256e-01
    z[9,10,3]  R2672     -1.5409705042839050e-01
    z[9,10,3]  R2673     -1.6119350492954254e-01
    z[9,10,3]  R2674     -7.1217817068099976e-01
    z[9,10,3]  R2675     5.0207132101058960e-01
    z[9,10,3]  R2676     5.9529662132263184e-01
    z[9,10,3]  R2677     3.0756023526191711e-01
    z[9,10,3]  R2678     6.9351297616958618e-01
    z[9,10,3]  R2679     2.3969364166259766e-01
    z[9,10,3]  R2680     1.3161744177341461e-01
    z[9,10,3]  R2681     -1.8077501654624939e-01
    z[9,10,3]  R2682     -4.7149181365966797e-01
    z[9,10,3]  R2683     5.5953943729400635e-01
    z[9,10,3]  R2684     0.0492120236158371
    z[9,10,3]  R2685     3.4767457842826843e-01
    z[9,10,3]  R2686     4.3079793453216553e-01
    z[9,10,3]  R2687     4.1219744086265564e-01
    z[9,10,3]  R2688     1.0982629656791687e-01
    z[9,10,3]  R2689     -1.5279197692871094e-01
    z[9,10,3]  R2690     -2.4793931841850281e-01
    z[9,10,3]  R2691     9.9482759833335876e-02
    z[9,10,3]  R2692     -1.3695076107978821e-01
    z[9,10,3]  R2693     -7.8917551040649414e-01
    z[9,10,3]  R2694     4.8998516052961349e-02
    z[9,10,3]  R2695     -5.8927470445632935e-01
    z[9,10,3]  R2696     -0.545684278011322
    z[9,10,3]  R2697     -5.2617323398590088e-01
    z[9,10,3]  R2698     -7.2550749778747559e-01
    z[9,10,3]  R2699     -3.5440614819526672e-01
    z[9,10,3]  R2700     -0.551074206829071
    z[9,10,3]  R2701     -5.4984372854232788e-01
    z[9,10,3]  R2702     -9.2329984903335571e-01
    z[9,10,3]  R2703     -2.6921549439430237e-01
    z[9,10,3]  R2704     -1.6672497987747192e-01
    z[9,10,3]  R2705     2.5321945548057556e-01
    z[9,10,3]  R2706     -4.8260873556137085e-01
    z[9,10,3]  R2707     -4.4024065136909485e-02
    z[9,10,3]  R2708     -5.9136878699064255e-02
    z[9,10,3]  R2709     -3.6749252676963806e-01
    z[9,10,3]  R2710     -0.658893883228302
    z[9,10,3]  R2711     1.9627586007118225e-01
    z[9,10,3]  R2712     1.3811291754245758e-01
    z[9,10,3]  R2713     -1.0940030962228775e-01
    z[9,10,3]  R2714     -5.0067198276519775e-01
    z[9,10,3]  R2715     -1.4055319130420685e-01
    z[9,10,3]  R2716     3.5209640860557556e-01
    z[9,10,3]  R2717     2.6984670758247375e-01
    z[9,10,3]  R2718     -2.0533490180969238e-01
    z[9,10,3]  R2719     -3.7075065076351166e-02
    z[9,10,3]  R2720     -6.0983598232269287e-01
    z[9,10,3]  R2721     5.2731644362211227e-02
    z[9,10,3]  R2722     2.5956892967224121e-01
    z[9,10,4]  R87       -1
    z[9,10,4]  R96       1
    z[9,10,4]  R2609     -1
    z[9,10,4]  R2610     1
    z[9,10,4]  R2615     -3.9963263273239136e-01
    z[9,10,4]  R2616     -1.9065174460411072e-01
    z[9,10,4]  R2617     1.6308404505252838e-01
    z[9,10,4]  R2618     1.7770475149154663e-01
    z[9,10,4]  R2619     -6.0246824286878109e-03
    z[9,10,4]  R2620     3.9743125438690186e-02
    z[9,10,4]  R2621     -4.7841039299964905e-01
    z[9,10,4]  R2622     -2.6570683717727661e-01
    z[9,10,4]  R2623     2.2985085844993591e-01
    z[9,10,4]  R2624     -9.5314718782901764e-02
    z[9,10,4]  R2625     -3.1862157583236694e-01
    z[9,10,4]  R2626     -2.0755660533905029e-01
    z[9,10,4]  R2627     8.5939332842826843e-02
    z[9,10,4]  R2628     -5.2346813678741455e-01
    z[9,10,4]  R2629     -5.2218484878540039e-01
    z[9,10,4]  R2630     -2.5616351515054703e-02
    z[9,10,4]  R2631     7.9321271181106567e-01
    z[9,10,4]  R2632     2.3815500736236572e-01
    z[9,10,4]  R2633     4.6793961524963379e-01
    z[9,10,4]  R2634     3.7247157096862793e-01
    z[9,10,4]  R2635     6.3064676523208618e-01
    z[9,10,4]  R2636     4.4290821999311447e-02
    z[9,10,4]  R2637     -6.1709702014923096e-02
    z[9,10,4]  R2638     -1.6679541766643524e-01
    z[9,10,4]  R2639     3.7073069810867310e-01
    z[9,10,4]  R2640     4.6271455287933350e-01
    z[9,10,4]  R2641     1.9478730857372284e-01
    z[9,10,4]  R2642     2.6884219050407410e-01
    z[9,10,4]  R2643     8.4355793893337250e-02
    z[9,10,4]  R2644     5.5109471082687378e-01
    z[9,10,4]  R2645     -5.9672966599464417e-02
    z[9,10,4]  R2646     1.2610065937042236e-01
    z[9,10,4]  R2647     -2.6534751057624817e-01
    z[9,10,4]  R2648     4.6184204518795013e-02
    z[9,10,4]  R2649     -4.9820181727409363e-01
    z[9,10,4]  R2650     2.9514145851135254e-01
    z[9,10,4]  R2651     -3.4078621864318848e-01
    z[9,10,4]  R2652     -6.3860282301902771e-02
    z[9,10,4]  R2653     3.5076424479484558e-01
    z[9,10,4]  R2654     1.1089966446161270e-01
    z[9,10,4]  R2655     -6.5157525241374969e-02
    z[9,10,4]  R2656     -1.3002167642116547e-01
    z[9,10,4]  R2657     -2.2800201550126076e-02
    z[9,10,4]  R2658     2.7837478555738926e-03
    z[9,10,4]  R2659     -2.3730394244194031e-01
    z[9,10,4]  R2660     4.9583122134208679e-02
    z[9,10,4]  R2661     -3.3296641707420349e-01
    z[9,10,4]  R2662     0.0236127357929945
    z[9,10,4]  R2663     1.0640777647495270e-01
    z[9,10,4]  R2664     -2.2715452313423157e-01
    z[9,10,4]  R2665     1.9060926139354706e-01
    z[9,10,4]  R2666     -1.9961050152778625e-01
    z[9,10,4]  R2667     2.6911211013793945e-01
    z[9,10,4]  R2668     -5.5291861295700073e-01
    z[9,10,4]  R2669     2.8804585337638855e-01
    z[9,10,4]  R2670     2.6697701215744019e-01
    z[9,10,4]  R2671     2.4555821716785431e-01
    z[9,10,4]  R2672     3.5698929429054260e-01
    z[9,10,4]  R2673     1.2138537317514420e-01
    z[9,10,4]  R2674     -4.9574777483940125e-02
    z[9,10,4]  R2675     -1.7861866950988770e-01
    z[9,10,4]  R2676     -8.1913277506828308e-02
    z[9,10,4]  R2677     -9.4367057085037231e-02
    z[9,10,4]  R2678     4.9848115444183350e-01
    z[9,10,4]  R2679     -1.5069586038589478e-01
    z[9,10,4]  R2680     -5.4800641536712646e-01
    z[9,10,4]  R2681     2.6543119549751282e-01
    z[9,10,4]  R2682     2.0664992928504944e-01
    z[9,10,4]  R2683     -1.9847100973129272e-01
    z[9,10,4]  R2684     4.6726310253143311e-01
    z[9,10,4]  R2685     2.4667292833328247e-01
    z[9,10,4]  R2686     -2.3602540791034698e-01
    z[9,10,4]  R2687     -1.6291595995426178e-02
    z[9,10,4]  R2688     -4.7038689255714417e-01
    z[9,10,4]  R2689     4.0066707134246826e-01
    z[9,10,4]  R2690     -3.8378933072090149e-01
    z[9,10,4]  R2691     9.9853627383708954e-02
    z[9,10,4]  R2692     -4.2679256200790405e-01
    z[9,10,4]  R2693     1.7373624444007874e-01
    z[9,10,4]  R2694     -1.1630057543516159e-01
    z[9,10,4]  R2695     1.5868136286735535e-01
    z[9,10,4]  R2696     -2.0123322308063507e-01
    z[9,10,4]  R2697     3.8542258739471436e-01
    z[9,10,4]  R2698     2.6206815242767334e-01
    z[9,10,4]  R2699     5.3734058141708374e-01
    z[9,10,4]  R2700     1.4198876917362213e-02
    z[9,10,4]  R2701     5.9667877852916718e-02
    z[9,10,4]  R2702     1.5926626324653625e-01
    z[9,10,4]  R2703     -2.6454201340675354e-01
    z[9,10,4]  R2704     0.183299720287323
    z[9,10,4]  R2705     3.7857902050018311e-01
    z[9,10,4]  R2706     0.0801553800702095
    z[9,10,4]  R2707     1.2145221233367920e-01
    z[9,10,4]  R2708     -3.8962772488594055e-01
    z[9,10,4]  R2709     -1.1109223961830139e-01
    z[9,10,4]  R2710     -4.4010823965072632e-01
    z[9,10,4]  R2711     2.2769233211874962e-02
    z[9,10,4]  R2712     -2.0858123898506165e-01
    z[9,10,4]  R2713     1.3694397173821926e-02
    z[9,10,4]  R2714     -1.6645327210426331e-01
    z[9,10,4]  R2715     -2.7922114729881287e-01
    z[9,10,4]  R2716     3.5035413503646851e-01
    z[9,10,4]  R2717     -3.9492573589086533e-02
    z[9,10,4]  R2718     -2.4358966946601868e-01
    z[9,10,4]  R2719     8.1998612731695175e-03
    z[9,10,4]  R2720     6.2724345922470093e-01
    z[9,10,4]  R2721     1.2638723850250244e-01
    z[9,10,4]  R2722     1.2699866294860840e-01
    z[9,10,5]  R88       -1
    z[9,10,5]  R97       1
    z[9,10,5]  R2611     -1
    z[9,10,5]  R2612     1
    z[9,10,5]  R2615     -2.9786482453346252e-01
    z[9,10,5]  R2616     1.5181696973741055e-02
    z[9,10,5]  R2617     -1.6975127160549164e-01
    z[9,10,5]  R2618     -4.0652045607566833e-01
    z[9,10,5]  R2619     -3.2270747423171997e-01
    z[9,10,5]  R2620     1.8104752898216248e-01
    z[9,10,5]  R2621     5.0167441368103027e-01
    z[9,10,5]  R2622     2.3916438221931458e-01
    z[9,10,5]  R2623     6.8354773521423340e-01
    z[9,10,5]  R2624     1.2156743556261063e-01
    z[9,10,5]  R2625     -7.2249794006347656e-01
    z[9,10,5]  R2626     -1.2243092805147171e-01
    z[9,10,5]  R2627     -7.5230067968368530e-01
    z[9,10,5]  R2628     -6.4105218648910522e-01
    z[9,10,5]  R2629     -4.6413314342498779e-01
    z[9,10,5]  R2630     -6.1697411537170410e-01
    z[9,10,5]  R2631     2.6064833998680115e-01
    z[9,10,5]  R2632     -2.2591555118560791e-01
    z[9,10,5]  R2633     -4.9055758118629456e-01
    z[9,10,5]  R2634     1.9934152066707611e-01
    z[9,10,5]  R2635     2.4682748317718506e-01
    z[9,10,5]  R2636     -0.664214015007019
    z[9,10,5]  R2637     -7.1010160446166992e-01
    z[9,10,5]  R2638     -5.5496370792388916e-01
    z[9,10,5]  R2639     -3.6890843510627747e-01
    z[9,10,5]  R2640     4.3439719080924988e-01
    z[9,10,5]  R2641     -2.9076570272445679e-01
    z[9,10,5]  R2642     -3.8497292995452881e-01
    z[9,10,5]  R2643     -3.9543408155441284e-01
    z[9,10,5]  R2644     0.0978158637881279
    z[9,10,5]  R2645     -1.6848985850811005e-01
    z[9,10,5]  R2646     0.236422598361969
    z[9,10,5]  R2647     -7.4039202928543091e-01
    z[9,10,5]  R2648     -7.2094070911407471e-01
    z[9,10,5]  R2649     -3.1968402862548828e-01
    z[9,10,5]  R2650     -5.0114977359771729e-01
    z[9,10,5]  R2651     -3.0594348907470703e-01
    z[9,10,5]  R2652     2.2888499498367310e-01
    z[9,10,5]  R2653     4.2588862776756287e-01
    z[9,10,5]  R2654     -6.3209319114685059e-01
    z[9,10,5]  R2655     -4.0558010339736938e-01
    z[9,10,5]  R2656     -6.3632673025131226e-01
    z[9,10,5]  R2657     -1.9038234651088715e-01
    z[9,10,5]  R2658     -5.6710356473922729e-01
    z[9,10,5]  R2659     -5.7302755117416382e-01
    z[9,10,5]  R2660     -4.0226092934608459e-01
    z[9,10,5]  R2661     -2.1952791512012482e-01
    z[9,10,5]  R2662     -2.9151713848114014e-01
    z[9,10,5]  R2663     0.431945264339447
    z[9,10,5]  R2664     -2.8299632668495178e-01
    z[9,10,5]  R2665     -2.0611369609832764e-01
    z[9,10,5]  R2666     4.3252494931221008e-01
    z[9,10,5]  R2667     -6.3303405046463013e-01
    z[9,10,5]  R2668     0.0892023965716362
    z[9,10,5]  R2669     1.5050472319126129e-01
    z[9,10,5]  R2670     -8.9196033775806427e-02
    z[9,10,5]  R2671     2.2232902050018311e-01
    z[9,10,5]  R2672     -1.8899044394493103e-01
    z[9,10,5]  R2673     -3.0630609393119812e-01
    z[9,10,5]  R2674     2.9824903607368469e-01
    z[9,10,5]  R2675     -5.4416441917419434e-01
    z[9,10,5]  R2676     -3.9944788813591003e-01
    z[9,10,5]  R2677     -5.8354437351226807e-01
    z[9,10,5]  R2678     -3.1988191604614258e-01
    z[9,10,5]  R2679     -1.0568533092737198e-02
    z[9,10,5]  R2680     -3.8195142149925232e-01
    z[9,10,5]  R2681     3.2803717255592346e-01
    z[9,10,5]  R2682     1.1291011422872543e-01
    z[9,10,5]  R2683     -4.5196062326431274e-01
    z[9,10,5]  R2684     -2.9771599173545837e-01
    z[9,10,5]  R2685     -3.3666574954986572e-01
    z[9,10,5]  R2686     6.2836207449436188e-02
    z[9,10,5]  R2687     1.6856060922145844e-01
    z[9,10,5]  R2688     9.2098012566566467e-02
    z[9,10,5]  R2689     -1.3682477176189423e-01
    z[9,10,5]  R2690     3.8620522618293762e-01
    z[9,10,5]  R2691     5.4775953292846680e-02
    z[9,10,5]  R2692     -1.5615113079547882e-01
    z[9,10,5]  R2693     -0.349942147731781
    z[9,10,5]  R2694     1.3385123014450073e-01
    z[9,10,5]  R2695     1.9149929285049438e-01
    z[9,10,5]  R2696     1.6691130399703979e-01
    z[9,10,5]  R2697     3.3369171619415283e-01
    z[9,10,5]  R2698     3.4062218666076660e-01
    z[9,10,5]  R2699     1.5259779989719391e-01
    z[9,10,5]  R2700     -3.1897285580635071e-01
    z[9,10,5]  R2701     -2.7829971909523010e-01
    z[9,10,5]  R2702     -2.1505707874894142e-02
    z[9,10,5]  R2703     -2.5584620237350464e-01
    z[9,10,5]  R2704     -3.1098011136054993e-01
    z[9,10,5]  R2705     -1.2054960429668427e-01
    z[9,10,5]  R2706     2.5374048948287964e-01
    z[9,10,5]  R2707     -2.3950074613094330e-01
    z[9,10,5]  R2708     -2.1978724002838135e-01
    z[9,10,5]  R2709     -5.6092578917741776e-02
    z[9,10,5]  R2710     3.0543115735054016e-01
    z[9,10,5]  R2711     -6.5410427749156952e-02
    z[9,10,5]  R2712     4.2288175225257874e-01
    z[9,10,5]  R2713     3.4910789132118225e-01
    z[9,10,5]  R2714     7.2588264942169189e-02
    z[9,10,5]  R2715     -1.8564362823963165e-01
    z[9,10,5]  R2716     3.4037280827760696e-02
    z[9,10,5]  R2717     3.8144804537296295e-02
    z[9,10,5]  R2718     -2.5996741652488708e-01
    z[9,10,5]  R2719     -5.8338552713394165e-01
    z[9,10,5]  R2720     5.9076957404613495e-02
    z[9,10,5]  R2721     2.3233537375926971e-01
    z[9,10,5]  R2722     -3.5585328936576843e-02
    z[9,10,6]  R89       -1
    z[9,10,6]  R98       1
    z[9,10,6]  R2613     -1
    z[9,10,6]  R2614     1
    z[9,10,6]  R2615     9.0677961707115173e-02
    z[9,10,6]  R2616     -4.0827459096908569e-01
    z[9,10,6]  R2617     -5.8025825768709183e-02
    z[9,10,6]  R2618     4.2708155512809753e-01
    z[9,10,6]  R2619     -4.3588000535964966e-01
    z[9,10,6]  R2620     -2.5381874293088913e-02
    z[9,10,6]  R2621     -1.1201821267604828e-01
    z[9,10,6]  R2622     -5.7448309659957886e-01
    z[9,10,6]  R2623     -2.3888534307479858e-01
    z[9,10,6]  R2624     -2.1509103477001190e-01
    z[9,10,6]  R2625     -2.9075646400451660e-01
    z[9,10,6]  R2626     -1.8486784771084785e-02
    z[9,10,6]  R2627     0.271684855222702
    z[9,10,6]  R2628     -2.7988600730895996e-01
    z[9,10,6]  R2629     -2.2420364618301392e-01
    z[9,10,6]  R2630     2.8579053282737732e-01
    z[9,10,6]  R2631     2.6356074213981628e-01
    z[9,10,6]  R2632     6.6798651218414307e-01
    z[9,10,6]  R2633     -7.2378120385110378e-03
    z[9,10,6]  R2634     1.7126396298408508e-01
    z[9,10,6]  R2635     2.7689644694328308e-01
    z[9,10,6]  R2636     -4.5411635190248489e-02
    z[9,10,6]  R2637     2.3220393061637878e-01
    z[9,10,6]  R2638     4.9505755305290222e-01
    z[9,10,6]  R2639     -3.1286051869392395e-01
    z[9,10,6]  R2640     0.366493284702301
    z[9,10,6]  R2641     -7.5198292732238770e-02
    z[9,10,6]  R2642     6.3373708724975586e-01
    z[9,10,6]  R2643     0.578849732875824
    z[9,10,6]  R2644     2.9332116246223450e-01
    z[9,10,6]  R2645     -3.8576591014862061e-01
    z[9,10,6]  R2646     -4.2447996139526367e-01
    z[9,10,6]  R2647     2.0087754726409912e-01
    z[9,10,6]  R2648     -1.8044428527355194e-01
    z[9,10,6]  R2649     1.0024210065603256e-01
    z[9,10,6]  R2650     1.5175281465053558e-01
    z[9,10,6]  R2651     -3.4700337052345276e-01
    z[9,10,6]  R2652     1.2395840138196945e-01
    z[9,10,6]  R2653     -1.2176579236984253e-01
    z[9,10,6]  R2654     2.6281037926673889e-01
    z[9,10,6]  R2655     7.6603099703788757e-02
    z[9,10,6]  R2656     -2.5848224759101868e-01
    z[9,10,6]  R2657     -2.7331728488206863e-02
    z[9,10,6]  R2658     1.7281077802181244e-02
    z[9,10,6]  R2659     -3.5236570239067078e-01
    z[9,10,6]  R2660     1.5219584107398987e-01
    z[9,10,6]  R2661     -9.6638485789299011e-02
    z[9,10,6]  R2662     -4.5479765534400940e-01
    z[9,10,6]  R2663     0.0490252859890461
    z[9,10,6]  R2664     1.2319782376289368e-01
    z[9,10,6]  R2665     -3.0960068106651306e-02
    z[9,10,6]  R2666     -4.3277588486671448e-01
    z[9,10,6]  R2667     -1.4188045263290405e-01
    z[9,10,6]  R2668     1.3368442654609680e-01
    z[9,10,6]  R2669     -1.2499737739562988e-01
    z[9,10,6]  R2670     -1.5704806149005890e-01
    z[9,10,6]  R2671     2.5493544340133667e-01
    z[9,10,6]  R2672     0.0582747608423233
    z[9,10,6]  R2673     -2.8421500325202942e-01
    z[9,10,6]  R2674     -3.8688236474990845e-01
    z[9,10,6]  R2675     1.7495671287178993e-02
    z[9,10,6]  R2676     -1.6256733238697052e-01
    z[9,10,6]  R2677     4.0815880894660950e-01
    z[9,10,6]  R2678     2.1923069655895233e-01
    z[9,10,6]  R2679     2.5234758853912354e-01
    z[9,10,6]  R2680     -9.7453787922859192e-02
    z[9,10,6]  R2681     1.0200767777860165e-02
    z[9,10,6]  R2682     -4.6653822064399719e-02
    z[9,10,6]  R2683     -3.6698929965496063e-02
    z[9,10,6]  R2684     -4.7293491661548615e-02
    z[9,10,6]  R2685     1.6665907204151154e-01
    z[9,10,6]  R2686     2.6747813820838928e-01
    z[9,10,6]  R2687     5.2840441465377808e-01
    z[9,10,6]  R2688     3.5279917716979980e-01
    z[9,10,6]  R2689     -0.319821834564209
    z[9,10,6]  R2690     1.6100525856018066e-01
    z[9,10,6]  R2691     -2.1857939660549164e-01
    z[9,10,6]  R2692     -3.9811313152313232e-01
    z[9,10,6]  R2693     1.1907972395420074e-01
    z[9,10,6]  R2694     1.2289749085903168e-01
    z[9,10,6]  R2695     1.2609063088893890e-01
    z[9,10,6]  R2696     -3.3725702762603760e-01
    z[9,10,6]  R2697     -3.7839386612176895e-02
    z[9,10,6]  R2698     2.1968404948711395e-01
    z[9,10,6]  R2699     -3.0634212493896484e-01
    z[9,10,6]  R2700     3.7586301565170288e-01
    z[9,10,6]  R2701     -1.4251054963096976e-03
    z[9,10,6]  R2702     5.2434742450714111e-02
    z[9,10,6]  R2703     -5.9443366527557373e-01
    z[9,10,6]  R2704     -3.3124676346778870e-01
    z[9,10,6]  R2705     3.3370870351791382e-01
    z[9,10,6]  R2706     2.7178913354873657e-01
    z[9,10,6]  R2707     -0.317000150680542
    z[9,10,6]  R2708     -5.0096082687377930e-01
    z[9,10,6]  R2709     5.5231865495443344e-02
    z[9,10,6]  R2710     -1.3000607490539551e-01
    z[9,10,6]  R2711     -5.0535160303115845e-01
    z[9,10,6]  R2712     3.0740521848201752e-02
    z[9,10,6]  R2713     -5.3632840514183044e-02
    z[9,10,6]  R2714     -2.9929324984550476e-01
    z[9,10,6]  R2715     -3.2842159271240234e-01
    z[9,10,6]  R2716     -1.4891290664672852e-01
    z[9,10,6]  R2717     -3.0203312635421753e-01
    z[9,10,6]  R2718     1.1560201644897461e-01
    z[9,10,6]  R2719     3.5126203298568726e-01
    z[9,10,6]  R2720     -2.2674590349197388e-01
    z[9,10,6]  R2721     4.4654153287410736e-02
    z[9,10,6]  R2722     -9.6725314855575562e-02
    z[10,9,0]  R83       1
    z[10,9,0]  R92       -1
    z[10,9,0]  R2723     -1
    z[10,9,0]  R2724     1
    z[10,9,0]  R2737     -1.6221959888935089e-01
    z[10,9,0]  R2738     -3.3538690209388733e-01
    z[10,9,0]  R2739     -6.7173206806182861e-01
    z[10,9,0]  R2740     -7.2031044960021973e-01
    z[10,9,0]  R2741     -5.4360526800155640e-01
    z[10,9,0]  R2742     4.0064170956611633e-02
    z[10,9,0]  R2743     -3.9596247673034668e-01
    z[10,9,0]  R2744     -1.0639448463916779e-01
    z[10,9,0]  R2745     -3.3186238259077072e-02
    z[10,9,0]  R2746     -1.9214755296707153e-01
    z[10,9,0]  R2747     1.7047522589564323e-02
    z[10,9,0]  R2748     7.0493870973587036e-01
    z[10,9,0]  R2749     2.5561478734016418e-01
    z[10,9,0]  R2750     -4.4059613347053528e-01
    z[10,9,0]  R2751     3.7649184465408325e-01
    z[10,9,0]  R2752     3.3047541975975037e-01
    z[10,9,0]  R2753     5.3289394825696945e-02
    z[10,9,0]  R2754     3.9863339066505432e-01
    z[10,9,0]  R2755     5.3017848730087280e-01
    z[10,9,0]  R2756     3.3325755596160889e-01
    z[10,9,0]  R2757     -4.5387947559356689e-01
    z[10,9,0]  R2758     7.8121083974838257e-01
    z[10,9,0]  R2759     7.5855886936187744e-01
    z[10,9,0]  R2760     7.5848937034606934e-01
    z[10,9,0]  R2761     5.9523308277130127e-01
    z[10,9,0]  R2762     5.2806007862091064e-01
    z[10,9,0]  R2763     8.8914191722869873e-01
    z[10,9,0]  R2764     4.8579803109169006e-01
    z[10,9,0]  R2765     -4.7163820266723633e-01
    z[10,9,0]  R2766     -3.2286411523818970e-01
    z[10,9,0]  R2767     -6.2224978208541870e-01
    z[10,9,0]  R2768     0.667977511882782
    z[10,9,0]  R2769     0.730576753616333
    z[10,9,0]  R2770     -6.6829109191894531e-01
    z[10,9,0]  R2771     -2.2789682447910309e-01
    z[10,9,0]  R2772     5.1489800214767456e-01
    z[10,9,0]  R2773     0.525680661201477
    z[10,9,0]  R2774     1.4966865070164204e-02
    z[10,9,0]  R2775     -3.3636394888162613e-02
    z[10,9,0]  R2776     2.4430401623249054e-02
    z[10,9,0]  R2777     -7.1938061714172363e-01
    z[10,9,0]  R2778     -7.3434668779373169e-01
    z[10,9,0]  R2779     -8.7153381109237671e-01
    z[10,9,0]  R2780     3.9826877415180206e-02
    z[10,9,0]  R2781     4.2995803058147430e-02
    z[10,9,0]  R2782     2.3911140859127045e-02
    z[10,9,0]  R2783     6.6440761089324951e-02
    z[10,9,0]  R2784     -0.0642852932214737
    z[10,9,0]  R2785     1.2891144491732121e-02
    z[10,9,0]  R2786     1.9521045684814453e-01
    z[10,9,0]  R2787     1.8371686339378357e-01
    z[10,9,0]  R2788     3.2115471363067627e-01
    z[10,9,0]  R2789     1.8859191238880157e-01
    z[10,9,0]  R2790     1.8353742361068726e-01
    z[10,9,0]  R2791     2.9240572452545166e-01
    z[10,9,0]  R2792     8.1658527255058289e-02
    z[10,9,0]  R2793     1.1317206174135208e-01
    z[10,9,0]  R2794     -1.2729771435260773e-02
    z[10,9,0]  R2795     1.7303159832954407e-01
    z[10,9,0]  R2796     -1.5301170945167542e-01
    z[10,9,0]  R2797     2.3762527108192444e-01
    z[10,9,0]  R2798     -0.0158318392932415
    z[10,9,0]  R2799     3.9074033498764038e-01
    z[10,9,0]  R2800     2.6645278930664062e-01
    z[10,9,0]  R2801     9.1636814177036285e-02
    z[10,9,0]  R2802     -2.0787367224693298e-01
    z[10,9,0]  R2803     4.5522534847259521e-01
    z[10,9,0]  R2804     0.441200852394104
    z[10,9,0]  R2805     -2.7625164017081261e-02
    z[10,9,0]  R2806     -3.2364460825920105e-01
    z[10,9,0]  R2807     -2.3119792342185974e-01
    z[10,9,0]  R2808     2.4720193445682526e-01
    z[10,9,0]  R2809     2.4882322549819946e-01
    z[10,9,0]  R2810     3.7292793393135071e-01
    z[10,9,0]  R2811     1.8218696117401123e-01
    z[10,9,0]  R2812     1.3982728123664856e-01
    z[10,9,0]  R2813     4.4310668110847473e-01
    z[10,9,0]  R2814     -2.5280886888504028e-01
    z[10,9,0]  R2815     2.0975257456302643e-01
    z[10,9,0]  R2816     4.5805528759956360e-01
    z[10,9,0]  R2817     -1.5050864778459072e-02
    z[10,9,0]  R2818     3.5582253336906433e-01
    z[10,9,0]  R2819     5.5501270294189453e-01
    z[10,9,0]  R2820     4.5985287427902222e-01
    z[10,9,0]  R2821     1.1087729036808014e-01
    z[10,9,0]  R2822     1.2989985942840576e-01
    z[10,9,0]  R2823     1.1822313815355301e-01
    z[10,9,0]  R2824     2.2202843427658081e-01
    z[10,9,0]  R2825     -2.5484177470207214e-01
    z[10,9,0]  R2826     1.3983985781669617e-01
    z[10,9,0]  R2827     6.1186897754669189e-01
    z[10,9,0]  R2828     0.0938342809677124
    z[10,9,0]  R2829     3.5296627879142761e-01
    z[10,9,0]  R2830     -1.8386578187346458e-02
    z[10,9,0]  R2831     -1.2858489155769348e-01
    z[10,9,0]  R2832     -1.9241939485073090e-01
    z[10,9,0]  R2833     -6.3853137195110321e-02
    z[10,9,0]  R2834     -1.3127784430980682e-01
    z[10,9,0]  R2835     -7.1821823716163635e-02
    z[10,9,0]  R2836     1.0111336596310139e-02
    z[10,9,0]  R2837     0.541682779788971
    z[10,9,0]  R2838     5.1831579208374023e-01
    z[10,9,0]  R2839     -1.7896954715251923e-01
    z[10,9,0]  R2840     2.5382828712463379e-01
    z[10,9,0]  R2841     -4.7841900587081909e-01
    z[10,9,0]  R2842     -1.4419214427471161e-01
    z[10,9,0]  R2843     1.1953799426555634e-01
    z[10,9,0]  R2844     1.8817475438117981e-01
    z[10,9,1]  R84       1
    z[10,9,1]  R93       -1
    z[10,9,1]  R2725     -1
    z[10,9,1]  R2726     1
    z[10,9,1]  R2737     9.6819110214710236e-02
    z[10,9,1]  R2738     -2.3146387934684753e-01
    z[10,9,1]  R2739     -2.2125518321990967e-01
    z[10,9,1]  R2740     -0.07354686409235
    z[10,9,1]  R2741     -2.5858255103230476e-02
    z[10,9,1]  R2742     1.3236142694950104e-01
    z[10,9,1]  R2743     7.1941041946411133e-01
    z[10,9,1]  R2744     0.777656614780426
    z[10,9,1]  R2745     9.2878192663192749e-01
    z[10,9,1]  R2746     7.6075583696365356e-01
    z[10,9,1]  R2747     4.4521963596343994e-01
    z[10,9,1]  R2748     5.6351685523986816e-01
    z[10,9,1]  R2749     6.1872792243957520e-01
    z[10,9,1]  R2750     -8.7522892281413078e-03
    z[10,9,1]  R2751     5.6009984016418457e-01
    z[10,9,1]  R2752     3.4401011466979980e-01
    z[10,9,1]  R2753     6.8093389272689819e-01
    z[10,9,1]  R2754     5.4238563776016235e-01
    z[10,9,1]  R2755     0.575753927230835
    z[10,9,1]  R2756     0.0868731439113617
    z[10,9,1]  R2757     -2.7706253528594971e-01
    z[10,9,1]  R2758     1.0392618924379349e-01
    z[10,9,1]  R2759     2.5629934668540955e-01
    z[10,9,1]  R2760     -1.1515791714191437e-01
    z[10,9,1]  R2761     6.5352815389633179e-01
    z[10,9,1]  R2762     4.6459311246871948e-01
    z[10,9,1]  R2763     2.5869302451610565e-02
    z[10,9,1]  R2764     2.3106144741177559e-02
    z[10,9,1]  R2765     0.689746618270874
    z[10,9,1]  R2766     7.8779542446136475e-01
    z[10,9,1]  R2767     5.3671532869338989e-01
    z[10,9,1]  R2768     4.2481273412704468e-01
    z[10,9,1]  R2769     4.7516006231307983e-01
    z[10,9,1]  R2770     5.3228777647018433e-01
    z[10,9,1]  R2771     8.7884134054183960e-01
    z[10,9,1]  R2772     -6.4468294382095337e-01
    z[10,9,1]  R2773     -4.4041857123374939e-01
    z[10,9,1]  R2774     -3.7349492311477661e-01
    z[10,9,1]  R2775     -9.4402414560317993e-01
    z[10,9,1]  R2776     -9.1908359527587891e-01
    z[10,9,1]  R2777     3.8767442107200623e-01
    z[10,9,1]  R2778     1.7109133303165436e-01
    z[10,9,1]  R2779     2.1183459088206291e-02
    z[10,9,1]  R2780     7.4613589048385620e-01
    z[10,9,1]  R2781     7.9002523422241211e-01
    z[10,9,1]  R2782     -4.8140946030616760e-01
    z[10,9,1]  R2783     3.8775098323822021e-01
    z[10,9,1]  R2784     -1.8589808046817780e-01
    z[10,9,1]  R2785     6.1399197578430176e-01
    z[10,9,1]  R2786     1.9840073585510254e-01
    z[10,9,1]  R2787     -3.6536478996276855e-01
    z[10,9,1]  R2788     -2.4173070490360260e-01
    z[10,9,1]  R2789     -0.476881742477417
    z[10,9,1]  R2790     -1.9843542575836182e-01
    z[10,9,1]  R2791     -5.4412138462066650e-01
    z[10,9,1]  R2792     -6.9752758741378784e-01
    z[10,9,1]  R2793     2.8069606423377991e-01
    z[10,9,1]  R2794     -7.4881382286548615e-02
    z[10,9,1]  R2795     0.581967830657959
    z[10,9,1]  R2796     3.7978556752204895e-01
    z[10,9,1]  R2797     5.7962757349014282e-01
    z[10,9,1]  R2798     2.7062505483627319e-01
    z[10,9,1]  R2799     1.4633838832378387e-01
    z[10,9,1]  R2800     -2.8048139810562134e-01
    z[10,9,1]  R2801     -9.0064823627471924e-02
    z[10,9,1]  R2802     4.3462336063385010e-01
    z[10,9,1]  R2803     -6.3214832544326782e-01
    z[10,9,1]  R2804     3.3744487911462784e-02
    z[10,9,1]  R2805     6.4503389596939087e-01
    z[10,9,1]  R2806     6.3430631160736084e-01
    z[10,9,1]  R2807     4.7585359215736389e-01
    z[10,9,1]  R2808     3.6725082993507385e-01
    z[10,9,1]  R2809     -1.5736138820648193e-01
    z[10,9,1]  R2810     -3.0708810687065125e-01
    z[10,9,1]  R2811     -2.8330606222152710e-01
    z[10,9,1]  R2812     -3.6009213328361511e-01
    z[10,9,1]  R2813     1.7421099543571472e-01
    z[10,9,1]  R2814     -6.5730142593383789e-01
    z[10,9,1]  R2815     7.4005979299545288e-01
    z[10,9,1]  R2816     -1.4961113035678864e-01
    z[10,9,1]  R2817     -0.664179265499115
    z[10,9,1]  R2818     -4.6668875217437744e-01
    z[10,9,1]  R2819     -5.1353383064270020e-01
    z[10,9,1]  R2820     2.4946649372577667e-01
    z[10,9,1]  R2821     6.0474222898483276e-01
    z[10,9,1]  R2822     6.6959589719772339e-02
    z[10,9,1]  R2823     2.4652989581227303e-02
    z[10,9,1]  R2824     -2.8708785772323608e-01
    z[10,9,1]  R2825     7.7099275588989258e-01
    z[10,9,1]  R2826     -4.4385217130184174e-02
    z[10,9,1]  R2827     -4.5468533039093018e-01
    z[10,9,1]  R2828     4.5502173900604248e-01
    z[10,9,1]  R2829     1.3688434660434723e-01
    z[10,9,1]  R2830     -6.8872314691543579e-01
    z[10,9,1]  R2831     -7.5139582157135010e-01
    z[10,9,1]  R2832     -8.6946922540664673e-01
    z[10,9,1]  R2833     -7.1054071187973022e-01
    z[10,9,1]  R2834     -7.5809156894683838e-01
    z[10,9,1]  R2835     8.4869980812072754e-01
    z[10,9,1]  R2836     0.495947003364563
    z[10,9,1]  R2837     -0.353481262922287
    z[10,9,1]  R2838     -3.2727217767387629e-03
    z[10,9,1]  R2839     -5.8670526742935181e-01
    z[10,9,1]  R2840     -1.5659306943416595e-01
    z[10,9,1]  R2841     -7.8024029731750488e-01
    z[10,9,1]  R2842     -6.8780100345611572e-01
    z[10,9,1]  R2843     -8.3306348323822021e-01
    z[10,9,1]  R2844     -7.9620856046676636e-01
    z[10,9,2]  R85       1
    z[10,9,2]  R94       -1
    z[10,9,2]  R2727     -1
    z[10,9,2]  R2728     1
    z[10,9,2]  R2737     6.3735437393188477e-01
    z[10,9,2]  R2738     7.2271156311035156e-01
    z[10,9,2]  R2739     4.2068734765052795e-01
    z[10,9,2]  R2740     3.9869260787963867e-01
    z[10,9,2]  R2741     4.7542482614517212e-01
    z[10,9,2]  R2742     7.8396451473236084e-01
    z[10,9,2]  R2743     1.4413902163505554e-01
    z[10,9,2]  R2744     -0.00922539085149765
    z[10,9,2]  R2745     2.5615987181663513e-01
    z[10,9,2]  R2746     2.3350395262241364e-02
    z[10,9,2]  R2747     1.0893570631742477e-01
    z[10,9,2]  R2748     -3.6954489350318909e-01
    z[10,9,2]  R2749     3.5614830255508423e-01
    z[10,9,2]  R2750     5.7090330123901367e-01
    z[10,9,2]  R2751     7.9694926738739014e-02
    z[10,9,2]  R2752     1.1453211307525635e-01
    z[10,9,2]  R2753     4.4933900237083435e-02
    z[10,9,2]  R2754     2.8335331007838249e-03
    z[10,9,2]  R2755     6.3851945102214813e-02
    z[10,9,2]  R2756     1.8226327374577522e-02
    z[10,9,2]  R2757     3.9491972327232361e-01
    z[10,9,2]  R2758     -3.3328625559806824e-01
    z[10,9,2]  R2759     -1.5988531708717346e-01
    z[10,9,2]  R2760     -1.8396428227424622e-01
    z[10,9,2]  R2761     2.0990529656410217e-01
    z[10,9,2]  R2762     -2.2523456811904907e-01
    z[10,9,2]  R2763     2.3487906157970428e-01
    z[10,9,2]  R2764     -1.5950015187263489e-01
    z[10,9,2]  R2765     -5.5727638304233551e-02
    z[10,9,2]  R2766     -1.8105761706829071e-01
    z[10,9,2]  R2767     0.433397114276886
    z[10,9,2]  R2768     1.0749153792858124e-02
    z[10,9,2]  R2769     2.0894598215818405e-02
    z[10,9,2]  R2770     -1.8183549400418997e-03
    z[10,9,2]  R2771     -9.2977546155452728e-02
    z[10,9,2]  R2772     3.6989018321037292e-01
    z[10,9,2]  R2773     2.5401926040649414e-01
    z[10,9,2]  R2774     -2.0009872317314148e-01
    z[10,9,2]  R2775     -1.8154628574848175e-01
    z[10,9,2]  R2776     -2.4609299004077911e-01
    z[10,9,2]  R2777     2.6962780952453613e-01
    z[10,9,2]  R2778     -1.5595278143882751e-01
    z[10,9,2]  R2779     -2.7372547984123230e-01
    z[10,9,2]  R2780     1.2897615134716034e-01
    z[10,9,2]  R2781     -2.4308270215988159e-01
    z[10,9,2]  R2782     3.0984896421432495e-01
    z[10,9,2]  R2783     -1.4209984242916107e-01
    z[10,9,2]  R2784     5.9943532943725586e-01
    z[10,9,2]  R2785     -1.0448925197124481e-01
    z[10,9,2]  R2786     1.3479281216859818e-02
    z[10,9,2]  R2787     1.1287947744131088e-01
    z[10,9,2]  R2788     1.1302204430103302e-01
    z[10,9,2]  R2789     9.8053090274333954e-02
    z[10,9,2]  R2790     7.6808951795101166e-02
    z[10,9,2]  R2791     1.2116042524576187e-01
    z[10,9,2]  R2792     -6.9153765216469765e-03
    z[10,9,2]  R2793     -3.3691966533660889e-01
    z[10,9,2]  R2794     1.6750842332839966e-01
    z[10,9,2]  R2795     -3.8306069374084473e-01
    z[10,9,2]  R2796     -9.7597584128379822e-02
    z[10,9,2]  R2797     -1.6526705026626587e-01
    z[10,9,2]  R2798     -1.6783097386360168e-01
    z[10,9,2]  R2799     4.0195193886756897e-01
    z[10,9,2]  R2800     3.0085697770118713e-01
    z[10,9,2]  R2801     5.0224140286445618e-02
    z[10,9,2]  R2802     -6.7384196445345879e-03
    z[10,9,2]  R2803     2.2282119095325470e-01
    z[10,9,2]  R2804     1.4660651981830597e-01
    z[10,9,2]  R2805     2.7640566229820251e-01
    z[10,9,2]  R2806     -1.7612041532993317e-01
    z[10,9,2]  R2807     -1.9000692665576935e-01
    z[10,9,2]  R2808     -2.3613980412483215e-01
    z[10,9,2]  R2809     1.6630922257900238e-01
    z[10,9,2]  R2810     0.278865247964859
    z[10,9,2]  R2811     3.4774717688560486e-01
    z[10,9,2]  R2812     -2.6795920729637146e-01
    z[10,9,2]  R2813     2.4316211044788361e-01
    z[10,9,2]  R2814     0.072159044444561
    z[10,9,2]  R2815     -1.4607223868370056e-01
    z[10,9,2]  R2816     -3.6402802914381027e-02
    z[10,9,2]  R2817     -0.0696464404463768
    z[10,9,2]  R2818     3.4577544778585434e-02
    z[10,9,2]  R2819     1.7927622795104980e-01
    z[10,9,2]  R2820     -4.9369469285011292e-02
    z[10,9,2]  R2821     -8.6866080760955811e-02
    z[10,9,2]  R2822     -1.8797514960169792e-02
    z[10,9,2]  R2823     1.4925029873847961e-01
    z[10,9,2]  R2824     -3.7630814313888550e-01
    z[10,9,2]  R2825     9.9292054772377014e-02
    z[10,9,2]  R2826     2.7988898754119873e-01
    z[10,9,2]  R2827     -2.0557044446468353e-01
    z[10,9,2]  R2828     4.0105696767568588e-02
    z[10,9,2]  R2829     2.7256676554679871e-01
    z[10,9,2]  R2830     0.440176784992218
    z[10,9,2]  R2831     5.3659409284591675e-01
    z[10,9,2]  R2832     2.4309273064136505e-01
    z[10,9,2]  R2833     5.5031704902648926e-01
    z[10,9,2]  R2834     4.6665042638778687e-01
    z[10,9,2]  R2835     -2.4337400496006012e-01
    z[10,9,2]  R2836     -7.5156822800636292e-02
    z[10,9,2]  R2837     3.5064734518527985e-02
    z[10,9,2]  R2838     4.2925927042961121e-01
    z[10,9,2]  R2839     1.1458951234817505e-01
    z[10,9,2]  R2840     1.7669038474559784e-01
    z[10,9,2]  R2841     1.3559868931770325e-01
    z[10,9,2]  R2842     1.8198868632316589e-01
    z[10,9,2]  R2843     2.8437674045562744e-01
    z[10,9,2]  R2844     -2.2518450021743774e-01
    z[10,9,3]  R86       1
    z[10,9,3]  R95       -1
    z[10,9,3]  R2729     -1
    z[10,9,3]  R2730     1
    z[10,9,3]  R2737     5.5953943729400635e-01
    z[10,9,3]  R2738     0.0492120236158371
    z[10,9,3]  R2739     3.4767457842826843e-01
    z[10,9,3]  R2740     4.3079793453216553e-01
    z[10,9,3]  R2741     4.1219744086265564e-01
    z[10,9,3]  R2742     1.0982629656791687e-01
    z[10,9,3]  R2743     -1.5279197692871094e-01
    z[10,9,3]  R2744     -2.4793931841850281e-01
    z[10,9,3]  R2745     9.9482759833335876e-02
    z[10,9,3]  R2746     -1.3695076107978821e-01
    z[10,9,3]  R2747     -7.8917551040649414e-01
    z[10,9,3]  R2748     4.8998516052961349e-02
    z[10,9,3]  R2749     -5.8927470445632935e-01
    z[10,9,3]  R2750     -0.545684278011322
    z[10,9,3]  R2751     -5.2617323398590088e-01
    z[10,9,3]  R2752     -7.2550749778747559e-01
    z[10,9,3]  R2753     -3.5440614819526672e-01
    z[10,9,3]  R2754     -0.551074206829071
    z[10,9,3]  R2755     -5.4984372854232788e-01
    z[10,9,3]  R2756     -9.2329984903335571e-01
    z[10,9,3]  R2757     -2.6921549439430237e-01
    z[10,9,3]  R2758     -1.6672497987747192e-01
    z[10,9,3]  R2759     2.5321945548057556e-01
    z[10,9,3]  R2760     -4.8260873556137085e-01
    z[10,9,3]  R2761     -4.4024065136909485e-02
    z[10,9,3]  R2762     -5.9136878699064255e-02
    z[10,9,3]  R2763     -3.6749252676963806e-01
    z[10,9,3]  R2764     -0.658893883228302
    z[10,9,3]  R2765     1.9627586007118225e-01
    z[10,9,3]  R2766     1.3811291754245758e-01
    z[10,9,3]  R2767     -1.0940030962228775e-01
    z[10,9,3]  R2768     -5.0067198276519775e-01
    z[10,9,3]  R2769     -1.4055319130420685e-01
    z[10,9,3]  R2770     3.5209640860557556e-01
    z[10,9,3]  R2771     2.6984670758247375e-01
    z[10,9,3]  R2772     -2.0533490180969238e-01
    z[10,9,3]  R2773     -3.7075065076351166e-02
    z[10,9,3]  R2774     -6.0983598232269287e-01
    z[10,9,3]  R2775     5.2731644362211227e-02
    z[10,9,3]  R2776     2.5956892967224121e-01
    z[10,9,3]  R2777     5.3373761475086212e-02
    z[10,9,3]  R2778     4.5152485370635986e-01
    z[10,9,3]  R2779     3.2599920034408569e-01
    z[10,9,3]  R2780     -2.1406471729278564e-01
    z[10,9,3]  R2781     1.4406421780586243e-01
    z[10,9,3]  R2782     7.9791283607482910e-01
    z[10,9,3]  R2783     -5.7614302635192871e-01
    z[10,9,3]  R2784     -3.7967890501022339e-01
    z[10,9,3]  R2785     -1.8653295934200287e-01
    z[10,9,3]  R2786     -9.2315798997879028e-01
    z[10,9,3]  R2787     3.3459299802780151e-01
    z[10,9,3]  R2788     8.7592297792434692e-01
    z[10,9,3]  R2789     2.8328070044517517e-01
    z[10,9,3]  R2790     3.9715844392776489e-01
    z[10,9,3]  R2791     2.5570935010910034e-01
    z[10,9,3]  R2792     2.0916453003883362e-01
    z[10,9,3]  R2793     -1.6822256147861481e-01
    z[10,9,3]  R2794     6.4203584194183350e-01
    z[10,9,3]  R2795     1.5802358090877533e-01
    z[10,9,3]  R2796     -7.8423309326171875e-01
    z[10,9,3]  R2797     -2.1199563145637512e-01
    z[10,9,3]  R2798     -6.7315685749053955e-01
    z[10,9,3]  R2799     3.1995415687561035e-01
    z[10,9,3]  R2800     4.2300209403038025e-01
    z[10,9,3]  R2801     7.8073817491531372e-01
    z[10,9,3]  R2802     4.8033601045608521e-01
    z[10,9,3]  R2803     4.6407714486122131e-01
    z[10,9,3]  R2804     4.0075761079788208e-01
    z[10,9,3]  R2805     -0.0906476080417633
    z[10,9,3]  R2806     2.5016140937805176e-01
    z[10,9,3]  R2807     -7.0939630270004272e-01
    z[10,9,3]  R2808     -7.0446836948394775e-01
    z[10,9,3]  R2809     4.7615560889244080e-01
    z[10,9,3]  R2810     3.6661583185195923e-01
    z[10,9,3]  R2811     6.3652658462524414e-01
    z[10,9,3]  R2812     6.4629054069519043e-01
    z[10,9,3]  R2813     6.1970251798629761e-01
    z[10,9,3]  R2814     6.5345507860183716e-01
    z[10,9,3]  R2815     -2.6025879383087158e-01
    z[10,9,3]  R2816     0.534384548664093
    z[10,9,3]  R2817     6.1577588319778442e-01
    z[10,9,3]  R2818     4.0714344382286072e-01
    z[10,9,3]  R2819     5.9882515668869019e-01
    z[10,9,3]  R2820     6.3399654626846313e-01
    z[10,9,3]  R2821     3.2498005032539368e-01
    z[10,9,3]  R2822     8.8929927349090576e-01
    z[10,9,3]  R2823     8.9148283004760742e-01
    z[10,9,3]  R2824     6.5901094675064087e-01
    z[10,9,3]  R2825     3.6119830608367920e-01
    z[10,9,3]  R2826     8.6791312694549561e-01
    z[10,9,3]  R2827     5.4483503103256226e-01
    z[10,9,3]  R2828     -6.0689771175384521e-01
    z[10,9,3]  R2829     0.537681519985199
    z[10,9,3]  R2830     -4.3805586174130440e-03
    z[10,9,3]  R2831     -9.8440952599048615e-02
    z[10,9,3]  R2832     -2.0977884531021118e-01
    z[10,9,3]  R2833     -1.1612334847450256e-01
    z[10,9,3]  R2834     -1.5409705042839050e-01
    z[10,9,3]  R2835     -1.6119350492954254e-01
    z[10,9,3]  R2836     -7.1217817068099976e-01
    z[10,9,3]  R2837     5.0207132101058960e-01
    z[10,9,3]  R2838     5.9529662132263184e-01
    z[10,9,3]  R2839     3.0756023526191711e-01
    z[10,9,3]  R2840     6.9351297616958618e-01
    z[10,9,3]  R2841     2.3969364166259766e-01
    z[10,9,3]  R2842     1.3161744177341461e-01
    z[10,9,3]  R2843     -1.8077501654624939e-01
    z[10,9,3]  R2844     -4.7149181365966797e-01
    z[10,9,4]  R87       1
    z[10,9,4]  R96       -1
    z[10,9,4]  R2731     -1
    z[10,9,4]  R2732     1
    z[10,9,4]  R2737     -1.9847100973129272e-01
    z[10,9,4]  R2738     4.6726310253143311e-01
    z[10,9,4]  R2739     2.4667292833328247e-01
    z[10,9,4]  R2740     -2.3602540791034698e-01
    z[10,9,4]  R2741     -1.6291595995426178e-02
    z[10,9,4]  R2742     -4.7038689255714417e-01
    z[10,9,4]  R2743     4.0066707134246826e-01
    z[10,9,4]  R2744     -3.8378933072090149e-01
    z[10,9,4]  R2745     9.9853627383708954e-02
    z[10,9,4]  R2746     -4.2679256200790405e-01
    z[10,9,4]  R2747     1.7373624444007874e-01
    z[10,9,4]  R2748     -1.1630057543516159e-01
    z[10,9,4]  R2749     1.5868136286735535e-01
    z[10,9,4]  R2750     -2.0123322308063507e-01
    z[10,9,4]  R2751     3.8542258739471436e-01
    z[10,9,4]  R2752     2.6206815242767334e-01
    z[10,9,4]  R2753     5.3734058141708374e-01
    z[10,9,4]  R2754     1.4198876917362213e-02
    z[10,9,4]  R2755     5.9667877852916718e-02
    z[10,9,4]  R2756     1.5926626324653625e-01
    z[10,9,4]  R2757     -2.6454201340675354e-01
    z[10,9,4]  R2758     0.183299720287323
    z[10,9,4]  R2759     3.7857902050018311e-01
    z[10,9,4]  R2760     0.0801553800702095
    z[10,9,4]  R2761     1.2145221233367920e-01
    z[10,9,4]  R2762     -3.8962772488594055e-01
    z[10,9,4]  R2763     -1.1109223961830139e-01
    z[10,9,4]  R2764     -4.4010823965072632e-01
    z[10,9,4]  R2765     2.2769233211874962e-02
    z[10,9,4]  R2766     -2.0858123898506165e-01
    z[10,9,4]  R2767     1.3694397173821926e-02
    z[10,9,4]  R2768     -1.6645327210426331e-01
    z[10,9,4]  R2769     -2.7922114729881287e-01
    z[10,9,4]  R2770     3.5035413503646851e-01
    z[10,9,4]  R2771     -3.9492573589086533e-02
    z[10,9,4]  R2772     -2.4358966946601868e-01
    z[10,9,4]  R2773     8.1998612731695175e-03
    z[10,9,4]  R2774     6.2724345922470093e-01
    z[10,9,4]  R2775     1.2638723850250244e-01
    z[10,9,4]  R2776     1.2699866294860840e-01
    z[10,9,4]  R2777     -3.9963263273239136e-01
    z[10,9,4]  R2778     -1.9065174460411072e-01
    z[10,9,4]  R2779     1.6308404505252838e-01
    z[10,9,4]  R2780     1.7770475149154663e-01
    z[10,9,4]  R2781     -6.0246824286878109e-03
    z[10,9,4]  R2782     3.9743125438690186e-02
    z[10,9,4]  R2783     -4.7841039299964905e-01
    z[10,9,4]  R2784     -2.6570683717727661e-01
    z[10,9,4]  R2785     2.2985085844993591e-01
    z[10,9,4]  R2786     -9.5314718782901764e-02
    z[10,9,4]  R2787     -3.1862157583236694e-01
    z[10,9,4]  R2788     -2.0755660533905029e-01
    z[10,9,4]  R2789     8.5939332842826843e-02
    z[10,9,4]  R2790     -5.2346813678741455e-01
    z[10,9,4]  R2791     -5.2218484878540039e-01
    z[10,9,4]  R2792     -2.5616351515054703e-02
    z[10,9,4]  R2793     7.9321271181106567e-01
    z[10,9,4]  R2794     2.3815500736236572e-01
    z[10,9,4]  R2795     4.6793961524963379e-01
    z[10,9,4]  R2796     3.7247157096862793e-01
    z[10,9,4]  R2797     6.3064676523208618e-01
    z[10,9,4]  R2798     4.4290821999311447e-02
    z[10,9,4]  R2799     -6.1709702014923096e-02
    z[10,9,4]  R2800     -1.6679541766643524e-01
    z[10,9,4]  R2801     3.7073069810867310e-01
    z[10,9,4]  R2802     4.6271455287933350e-01
    z[10,9,4]  R2803     1.9478730857372284e-01
    z[10,9,4]  R2804     2.6884219050407410e-01
    z[10,9,4]  R2805     8.4355793893337250e-02
    z[10,9,4]  R2806     5.5109471082687378e-01
    z[10,9,4]  R2807     -5.9672966599464417e-02
    z[10,9,4]  R2808     1.2610065937042236e-01
    z[10,9,4]  R2809     -2.6534751057624817e-01
    z[10,9,4]  R2810     4.6184204518795013e-02
    z[10,9,4]  R2811     -4.9820181727409363e-01
    z[10,9,4]  R2812     2.9514145851135254e-01
    z[10,9,4]  R2813     -3.4078621864318848e-01
    z[10,9,4]  R2814     -6.3860282301902771e-02
    z[10,9,4]  R2815     3.5076424479484558e-01
    z[10,9,4]  R2816     1.1089966446161270e-01
    z[10,9,4]  R2817     -6.5157525241374969e-02
    z[10,9,4]  R2818     -1.3002167642116547e-01
    z[10,9,4]  R2819     -2.2800201550126076e-02
    z[10,9,4]  R2820     2.7837478555738926e-03
    z[10,9,4]  R2821     -2.3730394244194031e-01
    z[10,9,4]  R2822     4.9583122134208679e-02
    z[10,9,4]  R2823     -3.3296641707420349e-01
    z[10,9,4]  R2824     0.0236127357929945
    z[10,9,4]  R2825     1.0640777647495270e-01
    z[10,9,4]  R2826     -2.2715452313423157e-01
    z[10,9,4]  R2827     1.9060926139354706e-01
    z[10,9,4]  R2828     -1.9961050152778625e-01
    z[10,9,4]  R2829     2.6911211013793945e-01
    z[10,9,4]  R2830     -5.5291861295700073e-01
    z[10,9,4]  R2831     2.8804585337638855e-01
    z[10,9,4]  R2832     2.6697701215744019e-01
    z[10,9,4]  R2833     2.4555821716785431e-01
    z[10,9,4]  R2834     3.5698929429054260e-01
    z[10,9,4]  R2835     1.2138537317514420e-01
    z[10,9,4]  R2836     -4.9574777483940125e-02
    z[10,9,4]  R2837     -1.7861866950988770e-01
    z[10,9,4]  R2838     -8.1913277506828308e-02
    z[10,9,4]  R2839     -9.4367057085037231e-02
    z[10,9,4]  R2840     4.9848115444183350e-01
    z[10,9,4]  R2841     -1.5069586038589478e-01
    z[10,9,4]  R2842     -5.4800641536712646e-01
    z[10,9,4]  R2843     2.6543119549751282e-01
    z[10,9,4]  R2844     2.0664992928504944e-01
    z[10,9,5]  R88       1
    z[10,9,5]  R97       -1
    z[10,9,5]  R2733     -1
    z[10,9,5]  R2734     1
    z[10,9,5]  R2737     -4.5196062326431274e-01
    z[10,9,5]  R2738     -2.9771599173545837e-01
    z[10,9,5]  R2739     -3.3666574954986572e-01
    z[10,9,5]  R2740     6.2836207449436188e-02
    z[10,9,5]  R2741     1.6856060922145844e-01
    z[10,9,5]  R2742     9.2098012566566467e-02
    z[10,9,5]  R2743     -1.3682477176189423e-01
    z[10,9,5]  R2744     3.8620522618293762e-01
    z[10,9,5]  R2745     5.4775953292846680e-02
    z[10,9,5]  R2746     -1.5615113079547882e-01
    z[10,9,5]  R2747     -0.349942147731781
    z[10,9,5]  R2748     1.3385123014450073e-01
    z[10,9,5]  R2749     1.9149929285049438e-01
    z[10,9,5]  R2750     1.6691130399703979e-01
    z[10,9,5]  R2751     3.3369171619415283e-01
    z[10,9,5]  R2752     3.4062218666076660e-01
    z[10,9,5]  R2753     1.5259779989719391e-01
    z[10,9,5]  R2754     -3.1897285580635071e-01
    z[10,9,5]  R2755     -2.7829971909523010e-01
    z[10,9,5]  R2756     -2.1505707874894142e-02
    z[10,9,5]  R2757     -2.5584620237350464e-01
    z[10,9,5]  R2758     -3.1098011136054993e-01
    z[10,9,5]  R2759     -1.2054960429668427e-01
    z[10,9,5]  R2760     2.5374048948287964e-01
    z[10,9,5]  R2761     -2.3950074613094330e-01
    z[10,9,5]  R2762     -2.1978724002838135e-01
    z[10,9,5]  R2763     -5.6092578917741776e-02
    z[10,9,5]  R2764     3.0543115735054016e-01
    z[10,9,5]  R2765     -6.5410427749156952e-02
    z[10,9,5]  R2766     4.2288175225257874e-01
    z[10,9,5]  R2767     3.4910789132118225e-01
    z[10,9,5]  R2768     7.2588264942169189e-02
    z[10,9,5]  R2769     -1.8564362823963165e-01
    z[10,9,5]  R2770     3.4037280827760696e-02
    z[10,9,5]  R2771     3.8144804537296295e-02
    z[10,9,5]  R2772     -2.5996741652488708e-01
    z[10,9,5]  R2773     -5.8338552713394165e-01
    z[10,9,5]  R2774     5.9076957404613495e-02
    z[10,9,5]  R2775     2.3233537375926971e-01
    z[10,9,5]  R2776     -3.5585328936576843e-02
    z[10,9,5]  R2777     -2.9786482453346252e-01
    z[10,9,5]  R2778     1.5181696973741055e-02
    z[10,9,5]  R2779     -1.6975127160549164e-01
    z[10,9,5]  R2780     -4.0652045607566833e-01
    z[10,9,5]  R2781     -3.2270747423171997e-01
    z[10,9,5]  R2782     1.8104752898216248e-01
    z[10,9,5]  R2783     5.0167441368103027e-01
    z[10,9,5]  R2784     2.3916438221931458e-01
    z[10,9,5]  R2785     6.8354773521423340e-01
    z[10,9,5]  R2786     1.2156743556261063e-01
    z[10,9,5]  R2787     -7.2249794006347656e-01
    z[10,9,5]  R2788     -1.2243092805147171e-01
    z[10,9,5]  R2789     -7.5230067968368530e-01
    z[10,9,5]  R2790     -6.4105218648910522e-01
    z[10,9,5]  R2791     -4.6413314342498779e-01
    z[10,9,5]  R2792     -6.1697411537170410e-01
    z[10,9,5]  R2793     2.6064833998680115e-01
    z[10,9,5]  R2794     -2.2591555118560791e-01
    z[10,9,5]  R2795     -4.9055758118629456e-01
    z[10,9,5]  R2796     1.9934152066707611e-01
    z[10,9,5]  R2797     2.4682748317718506e-01
    z[10,9,5]  R2798     -0.664214015007019
    z[10,9,5]  R2799     -7.1010160446166992e-01
    z[10,9,5]  R2800     -5.5496370792388916e-01
    z[10,9,5]  R2801     -3.6890843510627747e-01
    z[10,9,5]  R2802     4.3439719080924988e-01
    z[10,9,5]  R2803     -2.9076570272445679e-01
    z[10,9,5]  R2804     -3.8497292995452881e-01
    z[10,9,5]  R2805     -3.9543408155441284e-01
    z[10,9,5]  R2806     0.0978158637881279
    z[10,9,5]  R2807     -1.6848985850811005e-01
    z[10,9,5]  R2808     0.236422598361969
    z[10,9,5]  R2809     -7.4039202928543091e-01
    z[10,9,5]  R2810     -7.2094070911407471e-01
    z[10,9,5]  R2811     -3.1968402862548828e-01
    z[10,9,5]  R2812     -5.0114977359771729e-01
    z[10,9,5]  R2813     -3.0594348907470703e-01
    z[10,9,5]  R2814     2.2888499498367310e-01
    z[10,9,5]  R2815     4.2588862776756287e-01
    z[10,9,5]  R2816     -6.3209319114685059e-01
    z[10,9,5]  R2817     -4.0558010339736938e-01
    z[10,9,5]  R2818     -6.3632673025131226e-01
    z[10,9,5]  R2819     -1.9038234651088715e-01
    z[10,9,5]  R2820     -5.6710356473922729e-01
    z[10,9,5]  R2821     -5.7302755117416382e-01
    z[10,9,5]  R2822     -4.0226092934608459e-01
    z[10,9,5]  R2823     -2.1952791512012482e-01
    z[10,9,5]  R2824     -2.9151713848114014e-01
    z[10,9,5]  R2825     0.431945264339447
    z[10,9,5]  R2826     -2.8299632668495178e-01
    z[10,9,5]  R2827     -2.0611369609832764e-01
    z[10,9,5]  R2828     4.3252494931221008e-01
    z[10,9,5]  R2829     -6.3303405046463013e-01
    z[10,9,5]  R2830     0.0892023965716362
    z[10,9,5]  R2831     1.5050472319126129e-01
    z[10,9,5]  R2832     -8.9196033775806427e-02
    z[10,9,5]  R2833     2.2232902050018311e-01
    z[10,9,5]  R2834     -1.8899044394493103e-01
    z[10,9,5]  R2835     -3.0630609393119812e-01
    z[10,9,5]  R2836     2.9824903607368469e-01
    z[10,9,5]  R2837     -5.4416441917419434e-01
    z[10,9,5]  R2838     -3.9944788813591003e-01
    z[10,9,5]  R2839     -5.8354437351226807e-01
    z[10,9,5]  R2840     -3.1988191604614258e-01
    z[10,9,5]  R2841     -1.0568533092737198e-02
    z[10,9,5]  R2842     -3.8195142149925232e-01
    z[10,9,5]  R2843     3.2803717255592346e-01
    z[10,9,5]  R2844     1.1291011422872543e-01
    z[10,9,6]  R89       1
    z[10,9,6]  R98       -1
    z[10,9,6]  R2735     -1
    z[10,9,6]  R2736     1
    z[10,9,6]  R2737     -3.6698929965496063e-02
    z[10,9,6]  R2738     -4.7293491661548615e-02
    z[10,9,6]  R2739     1.6665907204151154e-01
    z[10,9,6]  R2740     2.6747813820838928e-01
    z[10,9,6]  R2741     5.2840441465377808e-01
    z[10,9,6]  R2742     3.5279917716979980e-01
    z[10,9,6]  R2743     -0.319821834564209
    z[10,9,6]  R2744     1.6100525856018066e-01
    z[10,9,6]  R2745     -2.1857939660549164e-01
    z[10,9,6]  R2746     -3.9811313152313232e-01
    z[10,9,6]  R2747     1.1907972395420074e-01
    z[10,9,6]  R2748     1.2289749085903168e-01
    z[10,9,6]  R2749     1.2609063088893890e-01
    z[10,9,6]  R2750     -3.3725702762603760e-01
    z[10,9,6]  R2751     -3.7839386612176895e-02
    z[10,9,6]  R2752     2.1968404948711395e-01
    z[10,9,6]  R2753     -3.0634212493896484e-01
    z[10,9,6]  R2754     3.7586301565170288e-01
    z[10,9,6]  R2755     -1.4251054963096976e-03
    z[10,9,6]  R2756     5.2434742450714111e-02
    z[10,9,6]  R2757     -5.9443366527557373e-01
    z[10,9,6]  R2758     -3.3124676346778870e-01
    z[10,9,6]  R2759     3.3370870351791382e-01
    z[10,9,6]  R2760     2.7178913354873657e-01
    z[10,9,6]  R2761     -0.317000150680542
    z[10,9,6]  R2762     -5.0096082687377930e-01
    z[10,9,6]  R2763     5.5231865495443344e-02
    z[10,9,6]  R2764     -1.3000607490539551e-01
    z[10,9,6]  R2765     -5.0535160303115845e-01
    z[10,9,6]  R2766     3.0740521848201752e-02
    z[10,9,6]  R2767     -5.3632840514183044e-02
    z[10,9,6]  R2768     -2.9929324984550476e-01
    z[10,9,6]  R2769     -3.2842159271240234e-01
    z[10,9,6]  R2770     -1.4891290664672852e-01
    z[10,9,6]  R2771     -3.0203312635421753e-01
    z[10,9,6]  R2772     1.1560201644897461e-01
    z[10,9,6]  R2773     3.5126203298568726e-01
    z[10,9,6]  R2774     -2.2674590349197388e-01
    z[10,9,6]  R2775     4.4654153287410736e-02
    z[10,9,6]  R2776     -9.6725314855575562e-02
    z[10,9,6]  R2777     9.0677961707115173e-02
    z[10,9,6]  R2778     -4.0827459096908569e-01
    z[10,9,6]  R2779     -5.8025825768709183e-02
    z[10,9,6]  R2780     4.2708155512809753e-01
    z[10,9,6]  R2781     -4.3588000535964966e-01
    z[10,9,6]  R2782     -2.5381874293088913e-02
    z[10,9,6]  R2783     -1.1201821267604828e-01
    z[10,9,6]  R2784     -5.7448309659957886e-01
    z[10,9,6]  R2785     -2.3888534307479858e-01
    z[10,9,6]  R2786     -2.1509103477001190e-01
    z[10,9,6]  R2787     -2.9075646400451660e-01
    z[10,9,6]  R2788     -1.8486784771084785e-02
    z[10,9,6]  R2789     0.271684855222702
    z[10,9,6]  R2790     -2.7988600730895996e-01
    z[10,9,6]  R2791     -2.2420364618301392e-01
    z[10,9,6]  R2792     2.8579053282737732e-01
    z[10,9,6]  R2793     2.6356074213981628e-01
    z[10,9,6]  R2794     6.6798651218414307e-01
    z[10,9,6]  R2795     -7.2378120385110378e-03
    z[10,9,6]  R2796     1.7126396298408508e-01
    z[10,9,6]  R2797     2.7689644694328308e-01
    z[10,9,6]  R2798     -4.5411635190248489e-02
    z[10,9,6]  R2799     2.3220393061637878e-01
    z[10,9,6]  R2800     4.9505755305290222e-01
    z[10,9,6]  R2801     -3.1286051869392395e-01
    z[10,9,6]  R2802     0.366493284702301
    z[10,9,6]  R2803     -7.5198292732238770e-02
    z[10,9,6]  R2804     6.3373708724975586e-01
    z[10,9,6]  R2805     0.578849732875824
    z[10,9,6]  R2806     2.9332116246223450e-01
    z[10,9,6]  R2807     -3.8576591014862061e-01
    z[10,9,6]  R2808     -4.2447996139526367e-01
    z[10,9,6]  R2809     2.0087754726409912e-01
    z[10,9,6]  R2810     -1.8044428527355194e-01
    z[10,9,6]  R2811     1.0024210065603256e-01
    z[10,9,6]  R2812     1.5175281465053558e-01
    z[10,9,6]  R2813     -3.4700337052345276e-01
    z[10,9,6]  R2814     1.2395840138196945e-01
    z[10,9,6]  R2815     -1.2176579236984253e-01
    z[10,9,6]  R2816     2.6281037926673889e-01
    z[10,9,6]  R2817     7.6603099703788757e-02
    z[10,9,6]  R2818     -2.5848224759101868e-01
    z[10,9,6]  R2819     -2.7331728488206863e-02
    z[10,9,6]  R2820     1.7281077802181244e-02
    z[10,9,6]  R2821     -3.5236570239067078e-01
    z[10,9,6]  R2822     1.5219584107398987e-01
    z[10,9,6]  R2823     -9.6638485789299011e-02
    z[10,9,6]  R2824     -4.5479765534400940e-01
    z[10,9,6]  R2825     0.0490252859890461
    z[10,9,6]  R2826     1.2319782376289368e-01
    z[10,9,6]  R2827     -3.0960068106651306e-02
    z[10,9,6]  R2828     -4.3277588486671448e-01
    z[10,9,6]  R2829     -1.4188045263290405e-01
    z[10,9,6]  R2830     1.3368442654609680e-01
    z[10,9,6]  R2831     -1.2499737739562988e-01
    z[10,9,6]  R2832     -1.5704806149005890e-01
    z[10,9,6]  R2833     2.5493544340133667e-01
    z[10,9,6]  R2834     0.0582747608423233
    z[10,9,6]  R2835     -2.8421500325202942e-01
    z[10,9,6]  R2836     -3.8688236474990845e-01
    z[10,9,6]  R2837     1.7495671287178993e-02
    z[10,9,6]  R2838     -1.6256733238697052e-01
    z[10,9,6]  R2839     4.0815880894660950e-01
    z[10,9,6]  R2840     2.1923069655895233e-01
    z[10,9,6]  R2841     2.5234758853912354e-01
    z[10,9,6]  R2842     -9.7453787922859192e-02
    z[10,9,6]  R2843     1.0200767777860165e-02
    z[10,9,6]  R2844     -4.6653822064399719e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    length[10]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
    delta[10,0]  R92       1
    delta[10,1]  R93       1
    delta[10,2]  R94       1
    delta[10,3]  R95       1
    delta[10,4]  R96       1
    delta[10,5]  R97       1
    delta[10,6]  R98       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R91       1
    RHS1      R99       1
    RHS1      R100      -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[11,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,10]
 BV BND1      phi[10,2]
 BV BND1      phi[2,12]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[11,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[4,6]
 BV BND1      phi[6,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,10]
 BV BND1      phi[10,9]
 BV BND1      phi[10,12]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,10,0]
 FR BND1      z[2,10,1]
 FR BND1      z[2,10,2]
 FR BND1      z[2,10,3]
 FR BND1      z[2,10,4]
 FR BND1      z[2,10,5]
 FR BND1      z[2,10,6]
 FR BND1      z[10,2,0]
 FR BND1      z[10,2,1]
 FR BND1      z[10,2,2]
 FR BND1      z[10,2,3]
 FR BND1      z[10,2,4]
 FR BND1      z[10,2,5]
 FR BND1      z[10,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[4,6,0]
 FR BND1      z[4,6,1]
 FR BND1      z[4,6,2]
 FR BND1      z[4,6,3]
 FR BND1      z[4,6,4]
 FR BND1      z[4,6,5]
 FR BND1      z[4,6,6]
 FR BND1      z[6,4,0]
 FR BND1      z[6,4,1]
 FR BND1      z[6,4,2]
 FR BND1      z[6,4,3]
 FR BND1      z[6,4,4]
 FR BND1      z[6,4,5]
 FR BND1      z[6,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      z[9,10,0]
 FR BND1      z[9,10,1]
 FR BND1      z[9,10,2]
 FR BND1      z[9,10,3]
 FR BND1      z[9,10,4]
 FR BND1      z[9,10,5]
 FR BND1      z[9,10,6]
 FR BND1      z[10,9,0]
 FR BND1      z[10,9,1]
 FR BND1      z[10,9,2]
 FR BND1      z[10,9,3]
 FR BND1      z[10,9,4]
 FR BND1      z[10,9,5]
 FR BND1      z[10,9,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
 FR BND1      delta[10,0]
 FR BND1      delta[10,1]
 FR BND1      delta[10,2]
 FR BND1      delta[10,3]
 FR BND1      delta[10,4]
 FR BND1      delta[10,5]
 FR BND1      delta[10,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
QCMATRIX   qc10    
    length[10]  length[10]  -1
    delta[10,0]  delta[10,0]  1
    delta[10,1]  delta[10,1]  1
    delta[10,2]  delta[10,2]  1
    delta[10,3]  delta[10,3]  1
    delta[10,4]  delta[10,4]  1
    delta[10,5]  delta[10,5]  1
    delta[10,6]  delta[10,6]  1
ENDATA
