NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 E  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -3.0999999046325684e+00
    phi[0,1]  R85       -2.2400000095367432e+00
    phi[0,1]  R86       -2.2400000095367432e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       -3.0999999046325684e+00
    phi[0,1]  R89       -2.5699999332427979e+00
    phi[0,1]  R90       -2.5699999332427979e+00
    phi[0,1]  R91       -3.0999999046325684e+00
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -2.0899999141693115e+00
    phi[0,1]  R94       -2.0899999141693115e+00
    phi[0,1]  R95       -3.0999999046325684e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       1.1389113664627075e+00
    phi[0,1]  R98       1.9560726881027222e+00
    phi[0,1]  R99       1.5509991645812988e+00
    phi[0,1]  R100      5.9472787380218506e-01
    phi[0,1]  R101      9.7831052541732788e-01
    phi[0,1]  R102      1.7425085306167603e+00
    phi[0,1]  R103      9.9995911121368408e-01
    phi[0,1]  R104      1.0201103687286377e+00
    phi[0,1]  R105      2.2343704700469971e+00
    phi[0,1]  R106      1.7782350778579712e+00
    phi[0,1]  R107      -1.3463376760482788e+00
    phi[0,1]  R108      -6.3847130537033081e-01
    phi[0,1]  R109      -1.0824004411697388e+00
    phi[0,1]  R110      -8.9873019605875015e-03
    phi[0,1]  R111      -2.2626123428344727e+00
    phi[0,1]  R112      -2.3275349140167236e+00
    phi[0,1]  R113      -1.8707048892974854e+00
    phi[0,1]  R114      -1.3622021675109863e-01
    phi[0,1]  R115      -3.6696130037307739e-01
    phi[0,1]  R116      -7.4517852067947388e-01
    phi[0,1]  R117      2.3953604698181152e+00
    phi[0,1]  R118      -1.2427574396133423e+00
    phi[0,1]  R119      -6.5298491716384888e-01
    phi[0,1]  R120      -1.6820474863052368e+00
    phi[0,1]  R121      -1.3640507459640503e+00
    phi[0,1]  R122      -2.2072155475616455e+00
    phi[0,1]  R123      -2.0711317062377930e+00
    phi[0,1]  R124      -1.2532297372817993e+00
    phi[0,1]  R125      -2.7429537773132324e+00
    phi[0,1]  R126      -1.9905788898468018e+00
    phi[0,1]  R127      2.1105699241161346e-01
    phi[0,1]  R128      -4.2005899548530579e-01
    phi[0,1]  R129      -2.1868173778057098e-01
    phi[0,1]  R130      -5.0225931406021118e-01
    phi[0,1]  R131      5.0656753592193127e-03
    phi[0,1]  R132      -1.7911878824234009e+00
    phi[0,1]  R133      -9.5306539535522461e-01
    phi[0,1]  R134      -1.5528067350387573e+00
    phi[0,1]  R135      -2.1885170936584473e+00
    phi[0,1]  R136      -7.6791691780090332e-01
    phi[0,1]  R137      1.0254474878311157e+00
    phi[0,1]  R138      -1.2878739833831787e+00
    phi[0,1]  R139      -1.8315927982330322e+00
    phi[0,1]  R140      -1.0660650730133057e+00
    phi[0,1]  R141      -1.3407517671585083e+00
    phi[0,1]  R142      -2.0146663188934326e+00
    phi[0,1]  R143      -1.1281337738037109e+00
    phi[0,1]  R144      -2.00596022605896
    phi[0,1]  R145      -1.5541017055511475e+00
    phi[0,1]  R146      -8.4688490629196167e-01
    phi[0,1]  R147      9.2024517059326172e-01
    phi[0,1]  R148      -7.8602284193038940e-01
    phi[0,1]  R149      -2.6575699448585510e-01
    phi[0,1]  R150      0.784625768661499
    phi[0,1]  R151      -1.2353962659835815e+00
    phi[0,1]  R152      -1.7611427307128906e+00
    phi[0,1]  R153      -4.9430871009826660e-01
    phi[0,1]  R154      -3.0067489147186279e+00
    phi[0,1]  R155      -6.5736383199691772e-01
    phi[0,1]  R156      -1.4776992797851562e+00
    phi[0,1]  R157      5.5134314298629761e-01
    phi[0,1]  R158      3.3863690495491028e-01
    phi[0,1]  R159      -5.0991302728652954e-01
    phi[0,1]  R160      -1.0220144987106323e+00
    phi[0,1]  R161      -4.3798327445983887e-01
    phi[0,1]  R162      -5.3974652290344238e-01
    phi[0,1]  R163      -3.5310366153717041e+00
    phi[0,1]  R164      -3.3777318000793457e+00
    phi[0,1]  R165      -3.1124389171600342e+00
    phi[0,1]  R166      -3.6476211547851562e+00
    phi[0,1]  R167      1.3451050519943237e+00
    phi[0,1]  R168      2.4983570575714111e+00
    phi[0,1]  R169      8.4667587280273438e-01
    phi[0,1]  R170      1.3708255290985107e+00
    phi[0,1]  R171      1.6622486114501953e+00
    phi[0,1]  R172      1.7738592624664307e+00
    phi[0,1]  R173      2.0162661075592041e+00
    phi[0,1]  R174      1.3337672948837280e+00
    phi[0,1]  R175      -2.1902570724487305e+00
    phi[0,1]  R176      -1.6414864063262939e+00
    phi[0,1]  R177      -2.9676344394683838e+00
    phi[0,1]  R178      -2.3349347114562988e+00
    phi[0,1]  R179      3.7126913666725159e-01
    phi[0,1]  R180      -1.3553777337074280e-01
    phi[0,1]  R181      -1.2483115196228027e+00
    phi[0,1]  R182      -1.5189219713211060e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R183      -3.0999999046325684e+00
    phi[1,0]  R184      -3.0999999046325684e+00
    phi[1,0]  R185      -2.2400000095367432e+00
    phi[1,0]  R186      -2.2400000095367432e+00
    phi[1,0]  R187      -3.0999999046325684e+00
    phi[1,0]  R188      -3.0999999046325684e+00
    phi[1,0]  R189      -2.5699999332427979e+00
    phi[1,0]  R190      -2.5699999332427979e+00
    phi[1,0]  R191      -3.0999999046325684e+00
    phi[1,0]  R192      -3.0999999046325684e+00
    phi[1,0]  R193      -2.0899999141693115e+00
    phi[1,0]  R194      -2.0899999141693115e+00
    phi[1,0]  R195      -3.0999999046325684e+00
    phi[1,0]  R196      -3.0999999046325684e+00
    phi[1,0]  R197      1.3451050519943237e+00
    phi[1,0]  R198      2.4983570575714111e+00
    phi[1,0]  R199      8.4667587280273438e-01
    phi[1,0]  R200      1.3708255290985107e+00
    phi[1,0]  R201      1.6622486114501953e+00
    phi[1,0]  R202      1.7738592624664307e+00
    phi[1,0]  R203      2.0162661075592041e+00
    phi[1,0]  R204      1.3337672948837280e+00
    phi[1,0]  R205      -2.1902570724487305e+00
    phi[1,0]  R206      -1.6414864063262939e+00
    phi[1,0]  R207      -2.9676344394683838e+00
    phi[1,0]  R208      -2.3349347114562988e+00
    phi[1,0]  R209      3.7126913666725159e-01
    phi[1,0]  R210      -1.3553777337074280e-01
    phi[1,0]  R211      -1.2483115196228027e+00
    phi[1,0]  R212      -1.5189219713211060e+00
    phi[1,0]  R213      1.1389113664627075e+00
    phi[1,0]  R214      1.9560726881027222e+00
    phi[1,0]  R215      1.5509991645812988e+00
    phi[1,0]  R216      5.9472787380218506e-01
    phi[1,0]  R217      9.7831052541732788e-01
    phi[1,0]  R218      1.7425085306167603e+00
    phi[1,0]  R219      9.9995911121368408e-01
    phi[1,0]  R220      1.0201103687286377e+00
    phi[1,0]  R221      2.2343704700469971e+00
    phi[1,0]  R222      1.7782350778579712e+00
    phi[1,0]  R223      -1.3463376760482788e+00
    phi[1,0]  R224      -6.3847130537033081e-01
    phi[1,0]  R225      -1.0824004411697388e+00
    phi[1,0]  R226      -8.9873019605875015e-03
    phi[1,0]  R227      -2.2626123428344727e+00
    phi[1,0]  R228      -2.3275349140167236e+00
    phi[1,0]  R229      -1.8707048892974854e+00
    phi[1,0]  R230      -1.3622021675109863e-01
    phi[1,0]  R231      -3.6696130037307739e-01
    phi[1,0]  R232      -7.4517852067947388e-01
    phi[1,0]  R233      2.3953604698181152e+00
    phi[1,0]  R234      -1.2427574396133423e+00
    phi[1,0]  R235      -6.5298491716384888e-01
    phi[1,0]  R236      -1.6820474863052368e+00
    phi[1,0]  R237      -1.3640507459640503e+00
    phi[1,0]  R238      -2.2072155475616455e+00
    phi[1,0]  R239      -2.0711317062377930e+00
    phi[1,0]  R240      -1.2532297372817993e+00
    phi[1,0]  R241      -2.7429537773132324e+00
    phi[1,0]  R242      -1.9905788898468018e+00
    phi[1,0]  R243      2.1105699241161346e-01
    phi[1,0]  R244      -4.2005899548530579e-01
    phi[1,0]  R245      -2.1868173778057098e-01
    phi[1,0]  R246      -5.0225931406021118e-01
    phi[1,0]  R247      5.0656753592193127e-03
    phi[1,0]  R248      -1.7911878824234009e+00
    phi[1,0]  R249      -9.5306539535522461e-01
    phi[1,0]  R250      -1.5528067350387573e+00
    phi[1,0]  R251      -2.1885170936584473e+00
    phi[1,0]  R252      -7.6791691780090332e-01
    phi[1,0]  R253      1.0254474878311157e+00
    phi[1,0]  R254      -1.2878739833831787e+00
    phi[1,0]  R255      -1.8315927982330322e+00
    phi[1,0]  R256      -1.0660650730133057e+00
    phi[1,0]  R257      -1.3407517671585083e+00
    phi[1,0]  R258      -2.0146663188934326e+00
    phi[1,0]  R259      -1.1281337738037109e+00
    phi[1,0]  R260      -2.00596022605896
    phi[1,0]  R261      -1.5541017055511475e+00
    phi[1,0]  R262      -8.4688490629196167e-01
    phi[1,0]  R263      9.2024517059326172e-01
    phi[1,0]  R264      -7.8602284193038940e-01
    phi[1,0]  R265      -2.6575699448585510e-01
    phi[1,0]  R266      0.784625768661499
    phi[1,0]  R267      -1.2353962659835815e+00
    phi[1,0]  R268      -1.7611427307128906e+00
    phi[1,0]  R269      -4.9430871009826660e-01
    phi[1,0]  R270      -3.0067489147186279e+00
    phi[1,0]  R271      -6.5736383199691772e-01
    phi[1,0]  R272      -1.4776992797851562e+00
    phi[1,0]  R273      5.5134314298629761e-01
    phi[1,0]  R274      3.3863690495491028e-01
    phi[1,0]  R275      -5.0991302728652954e-01
    phi[1,0]  R276      -1.0220144987106323e+00
    phi[1,0]  R277      -4.3798327445983887e-01
    phi[1,0]  R278      -5.3974652290344238e-01
    phi[1,0]  R279      -3.5310366153717041e+00
    phi[1,0]  R280      -3.3777318000793457e+00
    phi[1,0]  R281      -3.1124389171600342e+00
    phi[1,0]  R282      -3.6476211547851562e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R283      -3.0999999046325684e+00
    phi[0,4]  R284      -3.0999999046325684e+00
    phi[0,4]  R285      -2.2400000095367432e+00
    phi[0,4]  R286      -2.2400000095367432e+00
    phi[0,4]  R287      -3.0999999046325684e+00
    phi[0,4]  R288      -3.0999999046325684e+00
    phi[0,4]  R289      -2.5699999332427979e+00
    phi[0,4]  R290      -2.5699999332427979e+00
    phi[0,4]  R291      -3.0999999046325684e+00
    phi[0,4]  R292      -3.0999999046325684e+00
    phi[0,4]  R293      -2.0899999141693115e+00
    phi[0,4]  R294      -2.0899999141693115e+00
    phi[0,4]  R295      -3.0999999046325684e+00
    phi[0,4]  R296      -3.0999999046325684e+00
    phi[0,4]  R297      1.1389113664627075e+00
    phi[0,4]  R298      1.9560726881027222e+00
    phi[0,4]  R299      1.5509991645812988e+00
    phi[0,4]  R300      5.9472787380218506e-01
    phi[0,4]  R301      9.7831052541732788e-01
    phi[0,4]  R302      1.7425085306167603e+00
    phi[0,4]  R303      9.9995911121368408e-01
    phi[0,4]  R304      1.0201103687286377e+00
    phi[0,4]  R305      2.2343704700469971e+00
    phi[0,4]  R306      1.7782350778579712e+00
    phi[0,4]  R307      -1.3463376760482788e+00
    phi[0,4]  R308      -6.3847130537033081e-01
    phi[0,4]  R309      -1.0824004411697388e+00
    phi[0,4]  R310      -8.9873019605875015e-03
    phi[0,4]  R311      -2.2626123428344727e+00
    phi[0,4]  R312      -2.3275349140167236e+00
    phi[0,4]  R313      -1.8707048892974854e+00
    phi[0,4]  R314      -1.3622021675109863e-01
    phi[0,4]  R315      -3.6696130037307739e-01
    phi[0,4]  R316      -7.4517852067947388e-01
    phi[0,4]  R317      2.3953604698181152e+00
    phi[0,4]  R318      -1.2427574396133423e+00
    phi[0,4]  R319      -6.5298491716384888e-01
    phi[0,4]  R320      -1.6820474863052368e+00
    phi[0,4]  R321      -1.3640507459640503e+00
    phi[0,4]  R322      -2.2072155475616455e+00
    phi[0,4]  R323      -2.0711317062377930e+00
    phi[0,4]  R324      -1.2532297372817993e+00
    phi[0,4]  R325      -2.7429537773132324e+00
    phi[0,4]  R326      -1.9905788898468018e+00
    phi[0,4]  R327      2.1105699241161346e-01
    phi[0,4]  R328      -4.2005899548530579e-01
    phi[0,4]  R329      -2.1868173778057098e-01
    phi[0,4]  R330      -5.0225931406021118e-01
    phi[0,4]  R331      5.0656753592193127e-03
    phi[0,4]  R332      -1.7911878824234009e+00
    phi[0,4]  R333      -9.5306539535522461e-01
    phi[0,4]  R334      -1.5528067350387573e+00
    phi[0,4]  R335      -2.1885170936584473e+00
    phi[0,4]  R336      -7.6791691780090332e-01
    phi[0,4]  R337      1.0254474878311157e+00
    phi[0,4]  R338      -1.2878739833831787e+00
    phi[0,4]  R339      -1.8315927982330322e+00
    phi[0,4]  R340      -1.0660650730133057e+00
    phi[0,4]  R341      -1.3407517671585083e+00
    phi[0,4]  R342      -2.0146663188934326e+00
    phi[0,4]  R343      -1.1281337738037109e+00
    phi[0,4]  R344      -2.00596022605896
    phi[0,4]  R345      -1.5541017055511475e+00
    phi[0,4]  R346      -8.4688490629196167e-01
    phi[0,4]  R347      9.2024517059326172e-01
    phi[0,4]  R348      -7.8602284193038940e-01
    phi[0,4]  R349      -2.6575699448585510e-01
    phi[0,4]  R350      0.784625768661499
    phi[0,4]  R351      -1.2353962659835815e+00
    phi[0,4]  R352      -1.7611427307128906e+00
    phi[0,4]  R353      -4.9430871009826660e-01
    phi[0,4]  R354      -3.0067489147186279e+00
    phi[0,4]  R355      -6.5736383199691772e-01
    phi[0,4]  R356      -1.4776992797851562e+00
    phi[0,4]  R357      5.5134314298629761e-01
    phi[0,4]  R358      3.3863690495491028e-01
    phi[0,4]  R359      -5.0991302728652954e-01
    phi[0,4]  R360      -1.0220144987106323e+00
    phi[0,4]  R361      -4.3798327445983887e-01
    phi[0,4]  R362      -5.3974652290344238e-01
    phi[0,4]  R363      -3.5310366153717041e+00
    phi[0,4]  R364      -3.3777318000793457e+00
    phi[0,4]  R365      -3.1124389171600342e+00
    phi[0,4]  R366      -3.6476211547851562e+00
    phi[0,4]  R367      1.1243607997894287e+00
    phi[0,4]  R368      2.1491339206695557e+00
    phi[0,4]  R369      -8.8472092151641846e-01
    phi[0,4]  R370      7.6672635972499847e-02
    phi[0,4]  R371      -7.6923805475234985e-01
    phi[0,4]  R372      -1.1769566535949707e+00
    phi[0,4]  R373      1.5079428255558014e-01
    phi[0,4]  R374      -9.3189823627471924e-01
    phi[0,4]  R375      0.969227135181427
    phi[0,4]  R376      2.0665812492370605e+00
    phi[0,4]  R377      -1.5401909351348877e+00
    phi[0,4]  R378      1.0428057909011841e+00
    phi[0,4]  R379      2.1005659103393555e+00
    phi[0,4]  R380      -6.5750908851623535e-01
    phi[0,4]  R381      -2.5939838886260986e+00
    phi[0,4]  R382      -2.5566837787628174e+00
    phi[0,4]  R383      -2.3046352863311768e+00
    phi[0,4]  R384      -1.8035209178924561e+00
    phi[0,4]  R385      -2.3306467533111572e+00
    phi[0,4]  R386      -4.0224194526672363e-01
    phi[0,4]  R387      1.1064871549606323e+00
    phi[0,4]  R388      -2.0770347118377686e+00
    phi[0,4]  R389      6.8675804138183594e-01
    phi[0,4]  R390      -1.8025043010711670e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R391      -3.0999999046325684e+00
    phi[4,0]  R392      -3.0999999046325684e+00
    phi[4,0]  R393      -2.2400000095367432e+00
    phi[4,0]  R394      -2.2400000095367432e+00
    phi[4,0]  R395      -3.0999999046325684e+00
    phi[4,0]  R396      -3.0999999046325684e+00
    phi[4,0]  R397      -2.5699999332427979e+00
    phi[4,0]  R398      -2.5699999332427979e+00
    phi[4,0]  R399      -3.0999999046325684e+00
    phi[4,0]  R400      -3.0999999046325684e+00
    phi[4,0]  R401      -2.0899999141693115e+00
    phi[4,0]  R402      -2.0899999141693115e+00
    phi[4,0]  R403      -3.0999999046325684e+00
    phi[4,0]  R404      -3.0999999046325684e+00
    phi[4,0]  R405      1.1243607997894287e+00
    phi[4,0]  R406      2.1491339206695557e+00
    phi[4,0]  R407      -8.8472092151641846e-01
    phi[4,0]  R408      7.6672635972499847e-02
    phi[4,0]  R409      -7.6923805475234985e-01
    phi[4,0]  R410      -1.1769566535949707e+00
    phi[4,0]  R411      1.5079428255558014e-01
    phi[4,0]  R412      -9.3189823627471924e-01
    phi[4,0]  R413      0.969227135181427
    phi[4,0]  R414      2.0665812492370605e+00
    phi[4,0]  R415      -1.5401909351348877e+00
    phi[4,0]  R416      1.0428057909011841e+00
    phi[4,0]  R417      2.1005659103393555e+00
    phi[4,0]  R418      -6.5750908851623535e-01
    phi[4,0]  R419      -2.5939838886260986e+00
    phi[4,0]  R420      -2.5566837787628174e+00
    phi[4,0]  R421      -2.3046352863311768e+00
    phi[4,0]  R422      -1.8035209178924561e+00
    phi[4,0]  R423      -2.3306467533111572e+00
    phi[4,0]  R424      -4.0224194526672363e-01
    phi[4,0]  R425      1.1064871549606323e+00
    phi[4,0]  R426      -2.0770347118377686e+00
    phi[4,0]  R427      6.8675804138183594e-01
    phi[4,0]  R428      -1.8025043010711670e+00
    phi[4,0]  R429      1.1389113664627075e+00
    phi[4,0]  R430      1.9560726881027222e+00
    phi[4,0]  R431      1.5509991645812988e+00
    phi[4,0]  R432      5.9472787380218506e-01
    phi[4,0]  R433      9.7831052541732788e-01
    phi[4,0]  R434      1.7425085306167603e+00
    phi[4,0]  R435      9.9995911121368408e-01
    phi[4,0]  R436      1.0201103687286377e+00
    phi[4,0]  R437      2.2343704700469971e+00
    phi[4,0]  R438      1.7782350778579712e+00
    phi[4,0]  R439      -1.3463376760482788e+00
    phi[4,0]  R440      -6.3847130537033081e-01
    phi[4,0]  R441      -1.0824004411697388e+00
    phi[4,0]  R442      -8.9873019605875015e-03
    phi[4,0]  R443      -2.2626123428344727e+00
    phi[4,0]  R444      -2.3275349140167236e+00
    phi[4,0]  R445      -1.8707048892974854e+00
    phi[4,0]  R446      -1.3622021675109863e-01
    phi[4,0]  R447      -3.6696130037307739e-01
    phi[4,0]  R448      -7.4517852067947388e-01
    phi[4,0]  R449      2.3953604698181152e+00
    phi[4,0]  R450      -1.2427574396133423e+00
    phi[4,0]  R451      -6.5298491716384888e-01
    phi[4,0]  R452      -1.6820474863052368e+00
    phi[4,0]  R453      -1.3640507459640503e+00
    phi[4,0]  R454      -2.2072155475616455e+00
    phi[4,0]  R455      -2.0711317062377930e+00
    phi[4,0]  R456      -1.2532297372817993e+00
    phi[4,0]  R457      -2.7429537773132324e+00
    phi[4,0]  R458      -1.9905788898468018e+00
    phi[4,0]  R459      2.1105699241161346e-01
    phi[4,0]  R460      -4.2005899548530579e-01
    phi[4,0]  R461      -2.1868173778057098e-01
    phi[4,0]  R462      -5.0225931406021118e-01
    phi[4,0]  R463      5.0656753592193127e-03
    phi[4,0]  R464      -1.7911878824234009e+00
    phi[4,0]  R465      -9.5306539535522461e-01
    phi[4,0]  R466      -1.5528067350387573e+00
    phi[4,0]  R467      -2.1885170936584473e+00
    phi[4,0]  R468      -7.6791691780090332e-01
    phi[4,0]  R469      1.0254474878311157e+00
    phi[4,0]  R470      -1.2878739833831787e+00
    phi[4,0]  R471      -1.8315927982330322e+00
    phi[4,0]  R472      -1.0660650730133057e+00
    phi[4,0]  R473      -1.3407517671585083e+00
    phi[4,0]  R474      -2.0146663188934326e+00
    phi[4,0]  R475      -1.1281337738037109e+00
    phi[4,0]  R476      -2.00596022605896
    phi[4,0]  R477      -1.5541017055511475e+00
    phi[4,0]  R478      -8.4688490629196167e-01
    phi[4,0]  R479      9.2024517059326172e-01
    phi[4,0]  R480      -7.8602284193038940e-01
    phi[4,0]  R481      -2.6575699448585510e-01
    phi[4,0]  R482      0.784625768661499
    phi[4,0]  R483      -1.2353962659835815e+00
    phi[4,0]  R484      -1.7611427307128906e+00
    phi[4,0]  R485      -4.9430871009826660e-01
    phi[4,0]  R486      -3.0067489147186279e+00
    phi[4,0]  R487      -6.5736383199691772e-01
    phi[4,0]  R488      -1.4776992797851562e+00
    phi[4,0]  R489      5.5134314298629761e-01
    phi[4,0]  R490      3.3863690495491028e-01
    phi[4,0]  R491      -5.0991302728652954e-01
    phi[4,0]  R492      -1.0220144987106323e+00
    phi[4,0]  R493      -4.3798327445983887e-01
    phi[4,0]  R494      -5.3974652290344238e-01
    phi[4,0]  R495      -3.5310366153717041e+00
    phi[4,0]  R496      -3.3777318000793457e+00
    phi[4,0]  R497      -3.1124389171600342e+00
    phi[4,0]  R498      -3.6476211547851562e+00
    phi[9,0]  R0        -1
    phi[9,0]  R2        9.8416540455203760e-01
    phi[9,0]  R3        3.5577658564143810e-01
    phi[9,0]  R4        3.1052847899467384e-02
    phi[9,0]  R5        1.4558704339039
    phi[9,0]  R6        -2.7796958883093712e+00
    phi[9,0]  R7        -1.1530399341127979e+00
    phi[9,0]  R8        7.3602550201200545e-01
    phi[9,0]  R81       1
    phi[9,0]  R499      -4.0841653091846055e+00
    phi[9,0]  R500      -2.1158345000805308e+00
    phi[9,0]  R501      -2.5957765951781813e+00
    phi[9,0]  R502      -1.8842234238953051e+00
    phi[9,0]  R503      -3.1310527525320357e+00
    phi[9,0]  R504      -3.0689470567331010e+00
    phi[9,0]  R505      -4.0258703671466982e+00
    phi[9,0]  R506      -1.1141294993388979e+00
    phi[9,0]  R507      -3.2030401632319716e-01
    phi[9,0]  R508      -5.87969579294194
    phi[9,0]  R509      -9.3695998005651360e-01
    phi[9,0]  R510      -3.2430398482821094e+00
    phi[9,0]  R511      -3.8360254066445738e+00
    phi[9,0]  R512      -2.3639744026205629e+00
    phi[9,0]  R513      -2.8483508715136185e-01
    phi[9,0]  R514      -2.9698800384753188e-01
    phi[9,0]  R515      -3.0076625581993022e-01
    phi[9,0]  R516      -3.1005052655873144e-01
    phi[9,0]  R517      -3.2455332743576615e-01
    phi[9,0]  R518      -8.4525300187072849e-01
    phi[9,0]  R519      -3.3710384051220355e-01
    phi[9,0]  R520      -4.4218936560161515e-01
    phi[9,0]  R521      -3.5128452335576066e-01
    phi[9,0]  R522      -3.7538000546927330e-01
    phi[9,0]  R523      -3.9332383479370325e-01
    phi[9,0]  R524      -4.4570614776457995e-01
    phi[9,0]  R525      -4.5285223891822779e-01
    phi[9,0]  R526      -4.6516764983930026e-01
    phi[9,0]  R527      -5.6960433892675422e-01
    phi[9,0]  R528      -7.4541017317008351e-01
    phi[9,0]  R529      -8.8927763553992456e-01
    phi[9,0]  R530      -0.897461666941
    phi[9,0]  R531      -9.0219414920207763e-01
    phi[9,0]  R532      -9.1243415361327684e-01
    phi[9,0]  R533      -2.6122656555500745e-01
    phi[9,0]  R534      -5.3038475481463476e-01
    phi[9,0]  R535      -5.6028904711082816e-01
    phi[9,0]  R536      -6.2363510730926319e-01
    phi[9,0]  R537      -6.3493156684079066e-01
    phi[9,0]  R538      -6.5370591775718268e-01
    phi[9,0]  R539      -6.9913420870244591e-01
    phi[9,0]  R540      -7.0104655867793519e-01
    phi[9,0]  R541      -7.0883447105166386e-01
    phi[9,0]  R542      -7.0906351514626964e-01
    phi[9,0]  R543      -4.2332734828175722e-01
    phi[9,0]  R544      -4.4447487917575734e-01
    phi[9,0]  R545      -4.4701909425222186e-01
    phi[9,0]  R546      -0.448764253101874
    phi[9,0]  R547      -0.464541068841654
    phi[9,0]  R548      -5.0746417506240271e-01
    phi[9,0]  R549      -5.0983878086210288e-01
    phi[9,0]  R550      -5.3074794499954581e-01
    phi[9,0]  R551      -5.6518598348343208e-01
    phi[9,0]  R552      -0.57089982122009
    phi[9,0]  R553      -0.372867985802138
    phi[9,0]  R554      -4.5891085219060612e-01
    phi[9,0]  R555      -4.8345195066182911e-01
    phi[9,0]  R556      -4.9849509838002271e-01
    phi[9,0]  R557      -5.0744498336905108e-01
    phi[9,0]  R558      -5.1930107390134861e-01
    phi[9,0]  R559      -5.6064214700503667e-01
    phi[9,0]  R560      -6.3404498786162145e-01
    phi[9,0]  R561      -7.7032530725206949e-01
    phi[9,0]  R562      -8.2347470497402975e-01
    phi[9,0]  R563      -0.258769271172103
    phi[9,0]  R564      -3.5656120556306231e-01
    phi[9,0]  R565      -5.1457906774359585e-01
    phi[9,0]  R566      -5.9251512750114377e-01
    phi[9,0]  R567      -6.0907320789036146e-01
    phi[9,0]  R568      -6.0980669147269273e-01
    phi[9,0]  R569      -6.1794968612911161e-01
    phi[9,0]  R570      -6.2428930664726723e-01
    phi[9,0]  R571      -6.4972291915091251e-01
    phi[9,0]  R572      -6.7263282465273688e-01
    phi[9,0]  R573      -3.8551753322906734e-01
    phi[9,0]  R574      -4.3224749246846583e-01
    phi[9,0]  R575      -4.5069153065776218e-01
    phi[9,0]  R576      -4.5453731509734063e-01
    phi[9,0]  R577      -5.2778886772165978e-01
    phi[9,0]  R578      -0.623440158877106
    phi[9,0]  R579      -8.6104966700886232e-01
    phi[9,0]  R580      -8.6370304514585872e-01
    phi[9,0]  R581      -8.7105558598696531e-01
    phi[9,0]  R582      -8.7273778646011735e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R583      -3.0999999046325684e+00
    phi[1,2]  R584      -3.0999999046325684e+00
    phi[1,2]  R585      -2.2400000095367432e+00
    phi[1,2]  R586      -2.2400000095367432e+00
    phi[1,2]  R587      -3.0999999046325684e+00
    phi[1,2]  R588      -3.0999999046325684e+00
    phi[1,2]  R589      -2.5699999332427979e+00
    phi[1,2]  R590      -2.5699999332427979e+00
    phi[1,2]  R591      -3.0999999046325684e+00
    phi[1,2]  R592      -3.0999999046325684e+00
    phi[1,2]  R593      -2.0899999141693115e+00
    phi[1,2]  R594      -2.0899999141693115e+00
    phi[1,2]  R595      -3.0999999046325684e+00
    phi[1,2]  R596      -3.0999999046325684e+00
    phi[1,2]  R597      1.3451050519943237e+00
    phi[1,2]  R598      2.4983570575714111e+00
    phi[1,2]  R599      8.4667587280273438e-01
    phi[1,2]  R600      1.3708255290985107e+00
    phi[1,2]  R601      1.6622486114501953e+00
    phi[1,2]  R602      1.7738592624664307e+00
    phi[1,2]  R603      2.0162661075592041e+00
    phi[1,2]  R604      1.3337672948837280e+00
    phi[1,2]  R605      -2.1902570724487305e+00
    phi[1,2]  R606      -1.6414864063262939e+00
    phi[1,2]  R607      -2.9676344394683838e+00
    phi[1,2]  R608      -2.3349347114562988e+00
    phi[1,2]  R609      3.7126913666725159e-01
    phi[1,2]  R610      -1.3553777337074280e-01
    phi[1,2]  R611      -1.2483115196228027e+00
    phi[1,2]  R612      -1.5189219713211060e+00
    phi[1,2]  R613      2.3655726909637451e+00
    phi[1,2]  R614      2.7826492786407471e+00
    phi[1,2]  R615      2.4924004077911377e+00
    phi[1,2]  R616      1.4544085264205933e+00
    phi[1,2]  R617      8.6849480867385864e-01
    phi[1,2]  R618      9.3999284505844116e-01
    phi[1,2]  R619      1.1756030321121216e+00
    phi[1,2]  R620      2.3579282760620117e+00
    phi[1,2]  R621      1.9373757839202881e+00
    phi[1,2]  R622      -2.1968016624450684e+00
    phi[1,2]  R623      -1.4334366321563721e+00
    phi[1,2]  R624      -2.1569547653198242e+00
    phi[1,2]  R625      -3.6311274766921997e-01
    phi[1,2]  R626      -3.3015601634979248e+00
    phi[1,2]  R627      -1.9358081817626953e+00
    phi[1,2]  R628      -1.2378654479980469e+00
    phi[1,2]  R629      -1.5329415798187256e+00
    phi[1,2]  R630      -0.853022575378418
    phi[1,2]  R631      -6.9744193553924561e-01
    phi[1,2]  R632      -1.4605735540390015e+00
    phi[1,2]  R633      -2.1028413772583008e+00
    phi[1,2]  R634      -2.3665318489074707e+00
    phi[1,2]  R635      -3.9356768131256104e+00
    phi[1,2]  R636      -1.8097419738769531e+00
    phi[1,2]  R637      -3.4234671592712402e+00
    phi[1,2]  R638      -7.0859903097152710e-01
    phi[1,2]  R639      -9.3228125572204590e-01
    phi[1,2]  R640      1.5674608945846558e+00
    phi[1,2]  R641      1.2428445816040039e+00
    phi[1,2]  R642      -1.3594897985458374e+00
    phi[1,2]  R643      -1.6922370195388794e+00
    phi[1,2]  R644      -1.4095922708511353e+00
    phi[1,2]  R645      1.8312131166458130e+00
    phi[1,2]  R646      -1.7954415082931519e+00
    phi[1,2]  R647      1.1952558159828186e-01
    phi[1,2]  R648      4.3232358992099762e-02
    phi[1,2]  R649      -6.7001438140869141e-01
    phi[1,2]  R650      -1.1606817245483398e+00
    phi[1,2]  R651      1.2768893241882324e+00
    phi[1,2]  R652      1.6626331806182861e+00
    phi[1,2]  R653      -4.7132381796836853e-01
    phi[1,2]  R654      1.3448071479797363e-01
    phi[1,2]  R655      -5.7465654611587524e-01
    phi[1,2]  R656      1.8104529380798340e+00
    phi[1,2]  R657      3.6223345994949341e-01
    phi[1,2]  R658      -3.5394319891929626e-01
    phi[1,2]  R659      4.2714759707450867e-01
    phi[1,2]  R660      -2.9848396778106689e-01
    phi[1,2]  R661      -8.1925541162490845e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R662      -3.0999999046325684e+00
    phi[2,1]  R663      -3.0999999046325684e+00
    phi[2,1]  R664      -2.2400000095367432e+00
    phi[2,1]  R665      -2.2400000095367432e+00
    phi[2,1]  R666      -3.0999999046325684e+00
    phi[2,1]  R667      -3.0999999046325684e+00
    phi[2,1]  R668      -2.5699999332427979e+00
    phi[2,1]  R669      -2.5699999332427979e+00
    phi[2,1]  R670      -3.0999999046325684e+00
    phi[2,1]  R671      -3.0999999046325684e+00
    phi[2,1]  R672      -2.0899999141693115e+00
    phi[2,1]  R673      -2.0899999141693115e+00
    phi[2,1]  R674      -3.0999999046325684e+00
    phi[2,1]  R675      -3.0999999046325684e+00
    phi[2,1]  R676      2.3655726909637451e+00
    phi[2,1]  R677      2.7826492786407471e+00
    phi[2,1]  R678      2.4924004077911377e+00
    phi[2,1]  R679      1.4544085264205933e+00
    phi[2,1]  R680      8.6849480867385864e-01
    phi[2,1]  R681      9.3999284505844116e-01
    phi[2,1]  R682      1.1756030321121216e+00
    phi[2,1]  R683      2.3579282760620117e+00
    phi[2,1]  R684      1.9373757839202881e+00
    phi[2,1]  R685      -2.1968016624450684e+00
    phi[2,1]  R686      -1.4334366321563721e+00
    phi[2,1]  R687      -2.1569547653198242e+00
    phi[2,1]  R688      -3.6311274766921997e-01
    phi[2,1]  R689      -3.3015601634979248e+00
    phi[2,1]  R690      -1.9358081817626953e+00
    phi[2,1]  R691      -1.2378654479980469e+00
    phi[2,1]  R692      -1.5329415798187256e+00
    phi[2,1]  R693      -0.853022575378418
    phi[2,1]  R694      -6.9744193553924561e-01
    phi[2,1]  R695      -1.4605735540390015e+00
    phi[2,1]  R696      -2.1028413772583008e+00
    phi[2,1]  R697      -2.3665318489074707e+00
    phi[2,1]  R698      -3.9356768131256104e+00
    phi[2,1]  R699      -1.8097419738769531e+00
    phi[2,1]  R700      -3.4234671592712402e+00
    phi[2,1]  R701      -7.0859903097152710e-01
    phi[2,1]  R702      -9.3228125572204590e-01
    phi[2,1]  R703      1.5674608945846558e+00
    phi[2,1]  R704      1.2428445816040039e+00
    phi[2,1]  R705      -1.3594897985458374e+00
    phi[2,1]  R706      -1.6922370195388794e+00
    phi[2,1]  R707      -1.4095922708511353e+00
    phi[2,1]  R708      1.8312131166458130e+00
    phi[2,1]  R709      -1.7954415082931519e+00
    phi[2,1]  R710      1.1952558159828186e-01
    phi[2,1]  R711      4.3232358992099762e-02
    phi[2,1]  R712      -6.7001438140869141e-01
    phi[2,1]  R713      -1.1606817245483398e+00
    phi[2,1]  R714      1.2768893241882324e+00
    phi[2,1]  R715      1.6626331806182861e+00
    phi[2,1]  R716      -4.7132381796836853e-01
    phi[2,1]  R717      1.3448071479797363e-01
    phi[2,1]  R718      -5.7465654611587524e-01
    phi[2,1]  R719      1.8104529380798340e+00
    phi[2,1]  R720      3.6223345994949341e-01
    phi[2,1]  R721      -3.5394319891929626e-01
    phi[2,1]  R722      4.2714759707450867e-01
    phi[2,1]  R723      -2.9848396778106689e-01
    phi[2,1]  R724      -8.1925541162490845e-01
    phi[2,1]  R725      1.3451050519943237e+00
    phi[2,1]  R726      2.4983570575714111e+00
    phi[2,1]  R727      8.4667587280273438e-01
    phi[2,1]  R728      1.3708255290985107e+00
    phi[2,1]  R729      1.6622486114501953e+00
    phi[2,1]  R730      1.7738592624664307e+00
    phi[2,1]  R731      2.0162661075592041e+00
    phi[2,1]  R732      1.3337672948837280e+00
    phi[2,1]  R733      -2.1902570724487305e+00
    phi[2,1]  R734      -1.6414864063262939e+00
    phi[2,1]  R735      -2.9676344394683838e+00
    phi[2,1]  R736      -2.3349347114562988e+00
    phi[2,1]  R737      3.7126913666725159e-01
    phi[2,1]  R738      -1.3553777337074280e-01
    phi[2,1]  R739      -1.2483115196228027e+00
    phi[2,1]  R740      -1.5189219713211060e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R741      -3.0999999046325684e+00
    phi[2,3]  R742      -3.0999999046325684e+00
    phi[2,3]  R743      -2.2400000095367432e+00
    phi[2,3]  R744      -2.2400000095367432e+00
    phi[2,3]  R745      -3.0999999046325684e+00
    phi[2,3]  R746      -3.0999999046325684e+00
    phi[2,3]  R747      -2.5699999332427979e+00
    phi[2,3]  R748      -2.5699999332427979e+00
    phi[2,3]  R749      -3.0999999046325684e+00
    phi[2,3]  R750      -3.0999999046325684e+00
    phi[2,3]  R751      -2.0899999141693115e+00
    phi[2,3]  R752      -2.0899999141693115e+00
    phi[2,3]  R753      -3.0999999046325684e+00
    phi[2,3]  R754      -3.0999999046325684e+00
    phi[2,3]  R755      2.3655726909637451e+00
    phi[2,3]  R756      2.7826492786407471e+00
    phi[2,3]  R757      2.4924004077911377e+00
    phi[2,3]  R758      1.4544085264205933e+00
    phi[2,3]  R759      8.6849480867385864e-01
    phi[2,3]  R760      9.3999284505844116e-01
    phi[2,3]  R761      1.1756030321121216e+00
    phi[2,3]  R762      2.3579282760620117e+00
    phi[2,3]  R763      1.9373757839202881e+00
    phi[2,3]  R764      -2.1968016624450684e+00
    phi[2,3]  R765      -1.4334366321563721e+00
    phi[2,3]  R766      -2.1569547653198242e+00
    phi[2,3]  R767      -3.6311274766921997e-01
    phi[2,3]  R768      -3.3015601634979248e+00
    phi[2,3]  R769      -1.9358081817626953e+00
    phi[2,3]  R770      -1.2378654479980469e+00
    phi[2,3]  R771      -1.5329415798187256e+00
    phi[2,3]  R772      -0.853022575378418
    phi[2,3]  R773      -6.9744193553924561e-01
    phi[2,3]  R774      -1.4605735540390015e+00
    phi[2,3]  R775      -2.1028413772583008e+00
    phi[2,3]  R776      -2.3665318489074707e+00
    phi[2,3]  R777      -3.9356768131256104e+00
    phi[2,3]  R778      -1.8097419738769531e+00
    phi[2,3]  R779      -3.4234671592712402e+00
    phi[2,3]  R780      -7.0859903097152710e-01
    phi[2,3]  R781      -9.3228125572204590e-01
    phi[2,3]  R782      1.5674608945846558e+00
    phi[2,3]  R783      1.2428445816040039e+00
    phi[2,3]  R784      -1.3594897985458374e+00
    phi[2,3]  R785      -1.6922370195388794e+00
    phi[2,3]  R786      -1.4095922708511353e+00
    phi[2,3]  R787      1.8312131166458130e+00
    phi[2,3]  R788      -1.7954415082931519e+00
    phi[2,3]  R789      1.1952558159828186e-01
    phi[2,3]  R790      4.3232358992099762e-02
    phi[2,3]  R791      -6.7001438140869141e-01
    phi[2,3]  R792      -1.1606817245483398e+00
    phi[2,3]  R793      1.2768893241882324e+00
    phi[2,3]  R794      1.6626331806182861e+00
    phi[2,3]  R795      -4.7132381796836853e-01
    phi[2,3]  R796      1.3448071479797363e-01
    phi[2,3]  R797      -5.7465654611587524e-01
    phi[2,3]  R798      1.8104529380798340e+00
    phi[2,3]  R799      3.6223345994949341e-01
    phi[2,3]  R800      -3.5394319891929626e-01
    phi[2,3]  R801      4.2714759707450867e-01
    phi[2,3]  R802      -2.9848396778106689e-01
    phi[2,3]  R803      -8.1925541162490845e-01
    phi[2,3]  R804      4.0503711700439453e+00
    phi[2,3]  R805      3.5879132747650146e+00
    phi[2,3]  R806      4.1635389328002930e+00
    phi[2,3]  R807      3.2585480213165283e+00
    phi[2,3]  R808      2.8723938465118408e+00
    phi[2,3]  R809      3.8616282939910889e+00
    phi[2,3]  R810      2.5086247920989990e+00
    phi[2,3]  R811      2.4652566909790039e+00
    phi[2,3]  R812      1.1091188192367554e+00
    phi[2,3]  R813      1.2103947401046753e+00
    phi[2,3]  R814      -8.4151893854141235e-01
    phi[2,3]  R815      -4.0702733993530273e+00
    phi[2,3]  R816      -1.9245229959487915e+00
    phi[2,3]  R817      -2.4356224536895752e+00
    phi[2,3]  R818      -5.3516358137130737e-01
    phi[2,3]  R819      -3.6943523883819580e+00
    phi[2,3]  R820      -3.5076549053192139e+00
    phi[2,3]  R821      -1.7195533514022827e+00
    phi[2,3]  R822      -2.4534769058227539e+00
    phi[2,3]  R823      -2.4601914882659912e+00
    phi[2,3]  R824      -3.3927912712097168e+00
    phi[2,3]  R825      -2.9344623088836670e+00
    phi[2,3]  R826      -2.3598186969757080e+00
    phi[2,3]  R827      -1.3337448835372925e+00
    phi[2,3]  R828      -3.8295147418975830e+00
    phi[2,3]  R829      -1.6439108848571777e+00
    phi[2,3]  R830      -2.2237887382507324e+00
    phi[2,3]  R831      -2.9040453433990479e+00
    phi[2,3]  R832      -3.3276076316833496e+00
    phi[2,3]  R833      -1.3717718124389648e+00
    phi[2,3]  R834      -1.5473779439926147e+00
    phi[2,3]  R835      -1.8232297897338867e+00
    phi[2,3]  R836      -2.9122645854949951e+00
    phi[2,3]  R837      -7.9303199052810669e-01
    phi[2,3]  R838      -6.1385518312454224e-01
    phi[2,3]  R839      -5.1806038618087769e-01
    phi[2,3]  R840      -2.6435697078704834e+00
    phi[2,3]  R841      -1.8787114620208740e+00
    phi[2,3]  R842      -3.8015344142913818e+00
    phi[2,3]  R843      -4.3842239379882812e+00
    phi[2,3]  R844      -3.0115351676940918e+00
    phi[2,3]  R845      -0.600979208946228
    phi[2,3]  R846      -1.7651461362838745e+00
    phi[2,3]  R847      -5.9371191263198853e-01
    phi[2,3]  R848      -3.2955186367034912e+00
    phi[2,3]  R849      -1.6063951253890991e+00
    phi[2,3]  R850      -1.7241166830062866e+00
    phi[2,3]  R851      -2.2804946899414062e+00
    phi[2,3]  R852      -9.6268552541732788e-01
    phi[2,3]  R853      -2.4205882549285889e+00
    phi[2,3]  R854      -8.2512879371643066e-01
    phi[2,3]  R855      -1.7969044446945190e+00
    phi[2,3]  R856      -2.2814469337463379e+00
    phi[2,3]  R857      -8.1083381175994873e-01
    phi[2,3]  R858      -2.6631608009338379e+00
    phi[2,3]  R859      -4.2897863388061523e+00
    phi[2,3]  R860      -1.3767224550247192e+00
    phi[2,3]  R861      -3.4527678489685059e+00
    phi[2,3]  R862      -2.8348419666290283e+00
    phi[2,3]  R863      -1.8918871879577637e+00
    phi[2,3]  R864      -2.6414623856544495e-01
    phi[2,3]  R865      -4.2053112387657166e-01
    phi[2,3]  R866      -2.1300847530364990e+00
    phi[2,3]  R867      -2.4326183795928955e+00
    phi[2,3]  R868      -1.3410764932632446e-01
    phi[2,3]  R869      -3.9198322296142578e+00
    phi[2,3]  R870      -1.0839822292327881e+00
    phi[2,3]  R871      -1.7975517511367798e+00
    phi[2,3]  R872      1.2998057603836060e+00
    phi[2,3]  R873      -1.9893701076507568e+00
    phi[2,3]  R874      -1.3362200260162354e+00
    phi[2,3]  R875      -3.4279887676239014e+00
    phi[2,3]  R876      -3.3276317119598389e+00
    phi[2,3]  R877      -1.45125412940979
    phi[2,3]  R878      -2.1254436969757080e+00
    phi[2,3]  R879      -2.6439995765686035e+00
    phi[2,3]  R880      -2.4999284744262695e+00
    phi[2,3]  R881      -0.362288236618042
    phi[2,3]  R882      -2.3846101760864258e+00
    phi[2,3]  R883      -3.9022026062011719e+00
    phi[2,3]  R884      2.2812046110630035e-01
    phi[2,3]  R885      -3.1591396331787109e+00
    phi[2,3]  R886      -2.7842397689819336e+00
    phi[2,3]  R887      -2.6204161643981934e+00
    phi[2,3]  R888      -2.75258469581604
    phi[2,3]  R889      -2.0623269081115723e+00
    phi[2,3]  R890      -1.6547034978866577e+00
    phi[2,3]  R891      -4.6394124627113342e-01
    phi[2,3]  R892      -7.9557400941848755e-01
    phi[2,3]  R893      -2.8168640136718750e+00
    phi[2,3]  R894      -1.6619507074356079e+00
    phi[2,3]  R895      -2.7306077480316162e+00
    phi[2,3]  R896      -1.5351079702377319e+00
    phi[2,3]  R897      -1.4108999967575073e+00
    phi[2,3]  R898      -1.7401942014694214e+00
    phi[2,3]  R899      -2.6784791946411133e+00
    phi[2,3]  R900      -8.0966401100158691e-01
    phi[2,3]  R901      -1.4994885921478271e+00
    phi[2,3]  R902      -3.2984893321990967e+00
    phi[2,3]  R903      -2.5836477279663086e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R904      -3.0999999046325684e+00
    phi[3,2]  R905      -3.0999999046325684e+00
    phi[3,2]  R906      -2.2400000095367432e+00
    phi[3,2]  R907      -2.2400000095367432e+00
    phi[3,2]  R908      -3.0999999046325684e+00
    phi[3,2]  R909      -3.0999999046325684e+00
    phi[3,2]  R910      -2.5699999332427979e+00
    phi[3,2]  R911      -2.5699999332427979e+00
    phi[3,2]  R912      -3.0999999046325684e+00
    phi[3,2]  R913      -3.0999999046325684e+00
    phi[3,2]  R914      -2.0899999141693115e+00
    phi[3,2]  R915      -2.0899999141693115e+00
    phi[3,2]  R916      -3.0999999046325684e+00
    phi[3,2]  R917      -3.0999999046325684e+00
    phi[3,2]  R918      4.0503711700439453e+00
    phi[3,2]  R919      3.5879132747650146e+00
    phi[3,2]  R920      4.1635389328002930e+00
    phi[3,2]  R921      3.2585480213165283e+00
    phi[3,2]  R922      2.8723938465118408e+00
    phi[3,2]  R923      3.8616282939910889e+00
    phi[3,2]  R924      2.5086247920989990e+00
    phi[3,2]  R925      2.4652566909790039e+00
    phi[3,2]  R926      1.1091188192367554e+00
    phi[3,2]  R927      1.2103947401046753e+00
    phi[3,2]  R928      -8.4151893854141235e-01
    phi[3,2]  R929      -4.0702733993530273e+00
    phi[3,2]  R930      -1.9245229959487915e+00
    phi[3,2]  R931      -2.4356224536895752e+00
    phi[3,2]  R932      -5.3516358137130737e-01
    phi[3,2]  R933      -3.6943523883819580e+00
    phi[3,2]  R934      -3.5076549053192139e+00
    phi[3,2]  R935      -1.7195533514022827e+00
    phi[3,2]  R936      -2.4534769058227539e+00
    phi[3,2]  R937      -2.4601914882659912e+00
    phi[3,2]  R938      -3.3927912712097168e+00
    phi[3,2]  R939      -2.9344623088836670e+00
    phi[3,2]  R940      -2.3598186969757080e+00
    phi[3,2]  R941      -1.3337448835372925e+00
    phi[3,2]  R942      -3.8295147418975830e+00
    phi[3,2]  R943      -1.6439108848571777e+00
    phi[3,2]  R944      -2.2237887382507324e+00
    phi[3,2]  R945      -2.9040453433990479e+00
    phi[3,2]  R946      -3.3276076316833496e+00
    phi[3,2]  R947      -1.3717718124389648e+00
    phi[3,2]  R948      -1.5473779439926147e+00
    phi[3,2]  R949      -1.8232297897338867e+00
    phi[3,2]  R950      -2.9122645854949951e+00
    phi[3,2]  R951      -7.9303199052810669e-01
    phi[3,2]  R952      -6.1385518312454224e-01
    phi[3,2]  R953      -5.1806038618087769e-01
    phi[3,2]  R954      -2.6435697078704834e+00
    phi[3,2]  R955      -1.8787114620208740e+00
    phi[3,2]  R956      -3.8015344142913818e+00
    phi[3,2]  R957      -4.3842239379882812e+00
    phi[3,2]  R958      -3.0115351676940918e+00
    phi[3,2]  R959      -0.600979208946228
    phi[3,2]  R960      -1.7651461362838745e+00
    phi[3,2]  R961      -5.9371191263198853e-01
    phi[3,2]  R962      -3.2955186367034912e+00
    phi[3,2]  R963      -1.6063951253890991e+00
    phi[3,2]  R964      -1.7241166830062866e+00
    phi[3,2]  R965      -2.2804946899414062e+00
    phi[3,2]  R966      -9.6268552541732788e-01
    phi[3,2]  R967      -2.4205882549285889e+00
    phi[3,2]  R968      -8.2512879371643066e-01
    phi[3,2]  R969      -1.7969044446945190e+00
    phi[3,2]  R970      -2.2814469337463379e+00
    phi[3,2]  R971      -8.1083381175994873e-01
    phi[3,2]  R972      -2.6631608009338379e+00
    phi[3,2]  R973      -4.2897863388061523e+00
    phi[3,2]  R974      -1.3767224550247192e+00
    phi[3,2]  R975      -3.4527678489685059e+00
    phi[3,2]  R976      -2.8348419666290283e+00
    phi[3,2]  R977      -1.8918871879577637e+00
    phi[3,2]  R978      -2.6414623856544495e-01
    phi[3,2]  R979      -4.2053112387657166e-01
    phi[3,2]  R980      -2.1300847530364990e+00
    phi[3,2]  R981      -2.4326183795928955e+00
    phi[3,2]  R982      -1.3410764932632446e-01
    phi[3,2]  R983      -3.9198322296142578e+00
    phi[3,2]  R984      -1.0839822292327881e+00
    phi[3,2]  R985      -1.7975517511367798e+00
    phi[3,2]  R986      1.2998057603836060e+00
    phi[3,2]  R987      -1.9893701076507568e+00
    phi[3,2]  R988      -1.3362200260162354e+00
    phi[3,2]  R989      -3.4279887676239014e+00
    phi[3,2]  R990      -3.3276317119598389e+00
    phi[3,2]  R991      -1.45125412940979
    phi[3,2]  R992      -2.1254436969757080e+00
    phi[3,2]  R993      -2.6439995765686035e+00
    phi[3,2]  R994      -2.4999284744262695e+00
    phi[3,2]  R995      -0.362288236618042
    phi[3,2]  R996      -2.3846101760864258e+00
    phi[3,2]  R997      -3.9022026062011719e+00
    phi[3,2]  R998      2.2812046110630035e-01
    phi[3,2]  R999      -3.1591396331787109e+00
    phi[3,2]  R1000     -2.7842397689819336e+00
    phi[3,2]  R1001     -2.6204161643981934e+00
    phi[3,2]  R1002     -2.75258469581604
    phi[3,2]  R1003     -2.0623269081115723e+00
    phi[3,2]  R1004     -1.6547034978866577e+00
    phi[3,2]  R1005     -4.6394124627113342e-01
    phi[3,2]  R1006     -7.9557400941848755e-01
    phi[3,2]  R1007     -2.8168640136718750e+00
    phi[3,2]  R1008     -1.6619507074356079e+00
    phi[3,2]  R1009     -2.7306077480316162e+00
    phi[3,2]  R1010     -1.5351079702377319e+00
    phi[3,2]  R1011     -1.4108999967575073e+00
    phi[3,2]  R1012     -1.7401942014694214e+00
    phi[3,2]  R1013     -2.6784791946411133e+00
    phi[3,2]  R1014     -8.0966401100158691e-01
    phi[3,2]  R1015     -1.4994885921478271e+00
    phi[3,2]  R1016     -3.2984893321990967e+00
    phi[3,2]  R1017     -2.5836477279663086e+00
    phi[3,2]  R1018     2.3655726909637451e+00
    phi[3,2]  R1019     2.7826492786407471e+00
    phi[3,2]  R1020     2.4924004077911377e+00
    phi[3,2]  R1021     1.4544085264205933e+00
    phi[3,2]  R1022     8.6849480867385864e-01
    phi[3,2]  R1023     9.3999284505844116e-01
    phi[3,2]  R1024     1.1756030321121216e+00
    phi[3,2]  R1025     2.3579282760620117e+00
    phi[3,2]  R1026     1.9373757839202881e+00
    phi[3,2]  R1027     -2.1968016624450684e+00
    phi[3,2]  R1028     -1.4334366321563721e+00
    phi[3,2]  R1029     -2.1569547653198242e+00
    phi[3,2]  R1030     -3.6311274766921997e-01
    phi[3,2]  R1031     -3.3015601634979248e+00
    phi[3,2]  R1032     -1.9358081817626953e+00
    phi[3,2]  R1033     -1.2378654479980469e+00
    phi[3,2]  R1034     -1.5329415798187256e+00
    phi[3,2]  R1035     -0.853022575378418
    phi[3,2]  R1036     -6.9744193553924561e-01
    phi[3,2]  R1037     -1.4605735540390015e+00
    phi[3,2]  R1038     -2.1028413772583008e+00
    phi[3,2]  R1039     -2.3665318489074707e+00
    phi[3,2]  R1040     -3.9356768131256104e+00
    phi[3,2]  R1041     -1.8097419738769531e+00
    phi[3,2]  R1042     -3.4234671592712402e+00
    phi[3,2]  R1043     -7.0859903097152710e-01
    phi[3,2]  R1044     -9.3228125572204590e-01
    phi[3,2]  R1045     1.5674608945846558e+00
    phi[3,2]  R1046     1.2428445816040039e+00
    phi[3,2]  R1047     -1.3594897985458374e+00
    phi[3,2]  R1048     -1.6922370195388794e+00
    phi[3,2]  R1049     -1.4095922708511353e+00
    phi[3,2]  R1050     1.8312131166458130e+00
    phi[3,2]  R1051     -1.7954415082931519e+00
    phi[3,2]  R1052     1.1952558159828186e-01
    phi[3,2]  R1053     4.3232358992099762e-02
    phi[3,2]  R1054     -6.7001438140869141e-01
    phi[3,2]  R1055     -1.1606817245483398e+00
    phi[3,2]  R1056     1.2768893241882324e+00
    phi[3,2]  R1057     1.6626331806182861e+00
    phi[3,2]  R1058     -4.7132381796836853e-01
    phi[3,2]  R1059     1.3448071479797363e-01
    phi[3,2]  R1060     -5.7465654611587524e-01
    phi[3,2]  R1061     1.8104529380798340e+00
    phi[3,2]  R1062     3.6223345994949341e-01
    phi[3,2]  R1063     -3.5394319891929626e-01
    phi[3,2]  R1064     4.2714759707450867e-01
    phi[3,2]  R1065     -2.9848396778106689e-01
    phi[3,2]  R1066     -8.1925541162490845e-01
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1067     -3.0999999046325684e+00
    phi[3,7]  R1068     -3.0999999046325684e+00
    phi[3,7]  R1069     -2.2400000095367432e+00
    phi[3,7]  R1070     -2.2400000095367432e+00
    phi[3,7]  R1071     -3.0999999046325684e+00
    phi[3,7]  R1072     -3.0999999046325684e+00
    phi[3,7]  R1073     -2.5699999332427979e+00
    phi[3,7]  R1074     -2.5699999332427979e+00
    phi[3,7]  R1075     -3.0999999046325684e+00
    phi[3,7]  R1076     -3.0999999046325684e+00
    phi[3,7]  R1077     -2.0899999141693115e+00
    phi[3,7]  R1078     -2.0899999141693115e+00
    phi[3,7]  R1079     -3.0999999046325684e+00
    phi[3,7]  R1080     -3.0999999046325684e+00
    phi[3,7]  R1081     4.0503711700439453e+00
    phi[3,7]  R1082     3.5879132747650146e+00
    phi[3,7]  R1083     4.1635389328002930e+00
    phi[3,7]  R1084     3.2585480213165283e+00
    phi[3,7]  R1085     2.8723938465118408e+00
    phi[3,7]  R1086     3.8616282939910889e+00
    phi[3,7]  R1087     2.5086247920989990e+00
    phi[3,7]  R1088     2.4652566909790039e+00
    phi[3,7]  R1089     1.1091188192367554e+00
    phi[3,7]  R1090     1.2103947401046753e+00
    phi[3,7]  R1091     -8.4151893854141235e-01
    phi[3,7]  R1092     -4.0702733993530273e+00
    phi[3,7]  R1093     -1.9245229959487915e+00
    phi[3,7]  R1094     -2.4356224536895752e+00
    phi[3,7]  R1095     -5.3516358137130737e-01
    phi[3,7]  R1096     -3.6943523883819580e+00
    phi[3,7]  R1097     -3.5076549053192139e+00
    phi[3,7]  R1098     -1.7195533514022827e+00
    phi[3,7]  R1099     -2.4534769058227539e+00
    phi[3,7]  R1100     -2.4601914882659912e+00
    phi[3,7]  R1101     -3.3927912712097168e+00
    phi[3,7]  R1102     -2.9344623088836670e+00
    phi[3,7]  R1103     -2.3598186969757080e+00
    phi[3,7]  R1104     -1.3337448835372925e+00
    phi[3,7]  R1105     -3.8295147418975830e+00
    phi[3,7]  R1106     -1.6439108848571777e+00
    phi[3,7]  R1107     -2.2237887382507324e+00
    phi[3,7]  R1108     -2.9040453433990479e+00
    phi[3,7]  R1109     -3.3276076316833496e+00
    phi[3,7]  R1110     -1.3717718124389648e+00
    phi[3,7]  R1111     -1.5473779439926147e+00
    phi[3,7]  R1112     -1.8232297897338867e+00
    phi[3,7]  R1113     -2.9122645854949951e+00
    phi[3,7]  R1114     -7.9303199052810669e-01
    phi[3,7]  R1115     -6.1385518312454224e-01
    phi[3,7]  R1116     -5.1806038618087769e-01
    phi[3,7]  R1117     -2.6435697078704834e+00
    phi[3,7]  R1118     -1.8787114620208740e+00
    phi[3,7]  R1119     -3.8015344142913818e+00
    phi[3,7]  R1120     -4.3842239379882812e+00
    phi[3,7]  R1121     -3.0115351676940918e+00
    phi[3,7]  R1122     -0.600979208946228
    phi[3,7]  R1123     -1.7651461362838745e+00
    phi[3,7]  R1124     -5.9371191263198853e-01
    phi[3,7]  R1125     -3.2955186367034912e+00
    phi[3,7]  R1126     -1.6063951253890991e+00
    phi[3,7]  R1127     -1.7241166830062866e+00
    phi[3,7]  R1128     -2.2804946899414062e+00
    phi[3,7]  R1129     -9.6268552541732788e-01
    phi[3,7]  R1130     -2.4205882549285889e+00
    phi[3,7]  R1131     -8.2512879371643066e-01
    phi[3,7]  R1132     -1.7969044446945190e+00
    phi[3,7]  R1133     -2.2814469337463379e+00
    phi[3,7]  R1134     -8.1083381175994873e-01
    phi[3,7]  R1135     -2.6631608009338379e+00
    phi[3,7]  R1136     -4.2897863388061523e+00
    phi[3,7]  R1137     -1.3767224550247192e+00
    phi[3,7]  R1138     -3.4527678489685059e+00
    phi[3,7]  R1139     -2.8348419666290283e+00
    phi[3,7]  R1140     -1.8918871879577637e+00
    phi[3,7]  R1141     -2.6414623856544495e-01
    phi[3,7]  R1142     -4.2053112387657166e-01
    phi[3,7]  R1143     -2.1300847530364990e+00
    phi[3,7]  R1144     -2.4326183795928955e+00
    phi[3,7]  R1145     -1.3410764932632446e-01
    phi[3,7]  R1146     -3.9198322296142578e+00
    phi[3,7]  R1147     -1.0839822292327881e+00
    phi[3,7]  R1148     -1.7975517511367798e+00
    phi[3,7]  R1149     1.2998057603836060e+00
    phi[3,7]  R1150     -1.9893701076507568e+00
    phi[3,7]  R1151     -1.3362200260162354e+00
    phi[3,7]  R1152     -3.4279887676239014e+00
    phi[3,7]  R1153     -3.3276317119598389e+00
    phi[3,7]  R1154     -1.45125412940979
    phi[3,7]  R1155     -2.1254436969757080e+00
    phi[3,7]  R1156     -2.6439995765686035e+00
    phi[3,7]  R1157     -2.4999284744262695e+00
    phi[3,7]  R1158     -0.362288236618042
    phi[3,7]  R1159     -2.3846101760864258e+00
    phi[3,7]  R1160     -3.9022026062011719e+00
    phi[3,7]  R1161     2.2812046110630035e-01
    phi[3,7]  R1162     -3.1591396331787109e+00
    phi[3,7]  R1163     -2.7842397689819336e+00
    phi[3,7]  R1164     -2.6204161643981934e+00
    phi[3,7]  R1165     -2.75258469581604
    phi[3,7]  R1166     -2.0623269081115723e+00
    phi[3,7]  R1167     -1.6547034978866577e+00
    phi[3,7]  R1168     -4.6394124627113342e-01
    phi[3,7]  R1169     -7.9557400941848755e-01
    phi[3,7]  R1170     -2.8168640136718750e+00
    phi[3,7]  R1171     -1.6619507074356079e+00
    phi[3,7]  R1172     -2.7306077480316162e+00
    phi[3,7]  R1173     -1.5351079702377319e+00
    phi[3,7]  R1174     -1.4108999967575073e+00
    phi[3,7]  R1175     -1.7401942014694214e+00
    phi[3,7]  R1176     -2.6784791946411133e+00
    phi[3,7]  R1177     -8.0966401100158691e-01
    phi[3,7]  R1178     -1.4994885921478271e+00
    phi[3,7]  R1179     -3.2984893321990967e+00
    phi[3,7]  R1180     -2.5836477279663086e+00
    phi[3,7]  R1181     1.8877326250076294e+00
    phi[3,7]  R1182     2.4902992248535156e+00
    phi[3,7]  R1183     1.3979263305664062e+00
    phi[3,7]  R1184     1.7726165056228638e+00
    phi[3,7]  R1185     0.897317111492157
    phi[3,7]  R1186     1.2070739269256592e+00
    phi[3,7]  R1187     1.6141772270202637e+00
    phi[3,7]  R1188     2.7527064085006714e-01
    phi[3,7]  R1189     9.1237914562225342e-01
    phi[3,7]  R1190     4.2508375644683838e-01
    phi[3,7]  R1191     -1.4387768507003784e+00
    phi[3,7]  R1192     -9.6690398454666138e-01
    phi[3,7]  R1193     6.2956625223159790e-01
    phi[3,7]  R1194     -1.9422986507415771e+00
    phi[3,7]  R1195     -1.6858065128326416e+00
    phi[3,7]  R1196     -5.7946896553039551e-01
    phi[3,7]  R1197     -8.2615214586257935e-01
    phi[3,7]  R1198     -6.0905653238296509e-01
    phi[3,7]  R1199     -2.1531448364257812e+00
    phi[3,7]  R1200     -3.1135287284851074e+00
    phi[3,7]  R1201     -1.8449470996856689e+00
    phi[3,7]  R1202     -9.9106812477111816e-01
    phi[3,7]  R1203     -9.7013485431671143e-01
    phi[3,7]  R1204     5.1104009151458740e-01
    phi[3,7]  R1205     3.0847355723381042e-01
    phi[3,7]  R1206     -1.5185298919677734e+00
    phi[3,7]  R1207     9.1935470700263977e-02
    phi[3,7]  R1208     -8.9312058687210083e-01
    phi[3,7]  R1209     -1.3974380493164062e+00
    phi[3,7]  R1210     -7.2802287340164185e-01
    phi[3,7]  R1211     -5.3387045860290527e-01
    phi[3,7]  R1212     -1.8758782148361206e+00
    phi[3,7]  R1213     7.4206769466400146e-01
    phi[3,7]  R1214     -1.8638120591640472e-01
    phi[3,7]  R1215     1.0242608189582825e-01
    phi[3,7]  R1216     1.4591467380523682e+00
    phi[3,7]  R1217     2.5358468294143677e-01
    phi[3,7]  R1218     0.093849778175354
    phi[3,7]  R1219     1.6369804739952087e-01
    phi[3,7]  R1220     5.5032569169998169e-01
    phi[3,7]  R1221     -6.9657552242279053e-01
    phi[3,7]  R1222     -1.8980673551559448e+00
    phi[3,7]  R1223     -9.8858565092086792e-01
    phi[3,7]  R1224     1.4691779613494873e+00
    phi[3,7]  R1225     -9.7031068801879883e-01
    phi[3,7]  R1226     3.0049237608909607e-01
    phi[3,7]  R1227     -1.5849580764770508e+00
    phi[3,7]  R1228     -1.1887344121932983e+00
    phi[3,7]  R1229     -0.544943630695343
    phi[3,7]  R1230     -1.2424132823944092e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1231     -3.0999999046325684e+00
    phi[7,3]  R1232     -3.0999999046325684e+00
    phi[7,3]  R1233     -2.2400000095367432e+00
    phi[7,3]  R1234     -2.2400000095367432e+00
    phi[7,3]  R1235     -3.0999999046325684e+00
    phi[7,3]  R1236     -3.0999999046325684e+00
    phi[7,3]  R1237     -2.5699999332427979e+00
    phi[7,3]  R1238     -2.5699999332427979e+00
    phi[7,3]  R1239     -3.0999999046325684e+00
    phi[7,3]  R1240     -3.0999999046325684e+00
    phi[7,3]  R1241     -2.0899999141693115e+00
    phi[7,3]  R1242     -2.0899999141693115e+00
    phi[7,3]  R1243     -3.0999999046325684e+00
    phi[7,3]  R1244     -3.0999999046325684e+00
    phi[7,3]  R1245     1.8877326250076294e+00
    phi[7,3]  R1246     2.4902992248535156e+00
    phi[7,3]  R1247     1.3979263305664062e+00
    phi[7,3]  R1248     1.7726165056228638e+00
    phi[7,3]  R1249     0.897317111492157
    phi[7,3]  R1250     1.2070739269256592e+00
    phi[7,3]  R1251     1.6141772270202637e+00
    phi[7,3]  R1252     2.7527064085006714e-01
    phi[7,3]  R1253     9.1237914562225342e-01
    phi[7,3]  R1254     4.2508375644683838e-01
    phi[7,3]  R1255     -1.4387768507003784e+00
    phi[7,3]  R1256     -9.6690398454666138e-01
    phi[7,3]  R1257     6.2956625223159790e-01
    phi[7,3]  R1258     -1.9422986507415771e+00
    phi[7,3]  R1259     -1.6858065128326416e+00
    phi[7,3]  R1260     -5.7946896553039551e-01
    phi[7,3]  R1261     -8.2615214586257935e-01
    phi[7,3]  R1262     -6.0905653238296509e-01
    phi[7,3]  R1263     -2.1531448364257812e+00
    phi[7,3]  R1264     -3.1135287284851074e+00
    phi[7,3]  R1265     -1.8449470996856689e+00
    phi[7,3]  R1266     -9.9106812477111816e-01
    phi[7,3]  R1267     -9.7013485431671143e-01
    phi[7,3]  R1268     5.1104009151458740e-01
    phi[7,3]  R1269     3.0847355723381042e-01
    phi[7,3]  R1270     -1.5185298919677734e+00
    phi[7,3]  R1271     9.1935470700263977e-02
    phi[7,3]  R1272     -8.9312058687210083e-01
    phi[7,3]  R1273     -1.3974380493164062e+00
    phi[7,3]  R1274     -7.2802287340164185e-01
    phi[7,3]  R1275     -5.3387045860290527e-01
    phi[7,3]  R1276     -1.8758782148361206e+00
    phi[7,3]  R1277     7.4206769466400146e-01
    phi[7,3]  R1278     -1.8638120591640472e-01
    phi[7,3]  R1279     1.0242608189582825e-01
    phi[7,3]  R1280     1.4591467380523682e+00
    phi[7,3]  R1281     2.5358468294143677e-01
    phi[7,3]  R1282     0.093849778175354
    phi[7,3]  R1283     1.6369804739952087e-01
    phi[7,3]  R1284     5.5032569169998169e-01
    phi[7,3]  R1285     -6.9657552242279053e-01
    phi[7,3]  R1286     -1.8980673551559448e+00
    phi[7,3]  R1287     -9.8858565092086792e-01
    phi[7,3]  R1288     1.4691779613494873e+00
    phi[7,3]  R1289     -9.7031068801879883e-01
    phi[7,3]  R1290     3.0049237608909607e-01
    phi[7,3]  R1291     -1.5849580764770508e+00
    phi[7,3]  R1292     -1.1887344121932983e+00
    phi[7,3]  R1293     -0.544943630695343
    phi[7,3]  R1294     -1.2424132823944092e+00
    phi[7,3]  R1295     4.0503711700439453e+00
    phi[7,3]  R1296     3.5879132747650146e+00
    phi[7,3]  R1297     4.1635389328002930e+00
    phi[7,3]  R1298     3.2585480213165283e+00
    phi[7,3]  R1299     2.8723938465118408e+00
    phi[7,3]  R1300     3.8616282939910889e+00
    phi[7,3]  R1301     2.5086247920989990e+00
    phi[7,3]  R1302     2.4652566909790039e+00
    phi[7,3]  R1303     1.1091188192367554e+00
    phi[7,3]  R1304     1.2103947401046753e+00
    phi[7,3]  R1305     -8.4151893854141235e-01
    phi[7,3]  R1306     -4.0702733993530273e+00
    phi[7,3]  R1307     -1.9245229959487915e+00
    phi[7,3]  R1308     -2.4356224536895752e+00
    phi[7,3]  R1309     -5.3516358137130737e-01
    phi[7,3]  R1310     -3.6943523883819580e+00
    phi[7,3]  R1311     -3.5076549053192139e+00
    phi[7,3]  R1312     -1.7195533514022827e+00
    phi[7,3]  R1313     -2.4534769058227539e+00
    phi[7,3]  R1314     -2.4601914882659912e+00
    phi[7,3]  R1315     -3.3927912712097168e+00
    phi[7,3]  R1316     -2.9344623088836670e+00
    phi[7,3]  R1317     -2.3598186969757080e+00
    phi[7,3]  R1318     -1.3337448835372925e+00
    phi[7,3]  R1319     -3.8295147418975830e+00
    phi[7,3]  R1320     -1.6439108848571777e+00
    phi[7,3]  R1321     -2.2237887382507324e+00
    phi[7,3]  R1322     -2.9040453433990479e+00
    phi[7,3]  R1323     -3.3276076316833496e+00
    phi[7,3]  R1324     -1.3717718124389648e+00
    phi[7,3]  R1325     -1.5473779439926147e+00
    phi[7,3]  R1326     -1.8232297897338867e+00
    phi[7,3]  R1327     -2.9122645854949951e+00
    phi[7,3]  R1328     -7.9303199052810669e-01
    phi[7,3]  R1329     -6.1385518312454224e-01
    phi[7,3]  R1330     -5.1806038618087769e-01
    phi[7,3]  R1331     -2.6435697078704834e+00
    phi[7,3]  R1332     -1.8787114620208740e+00
    phi[7,3]  R1333     -3.8015344142913818e+00
    phi[7,3]  R1334     -4.3842239379882812e+00
    phi[7,3]  R1335     -3.0115351676940918e+00
    phi[7,3]  R1336     -0.600979208946228
    phi[7,3]  R1337     -1.7651461362838745e+00
    phi[7,3]  R1338     -5.9371191263198853e-01
    phi[7,3]  R1339     -3.2955186367034912e+00
    phi[7,3]  R1340     -1.6063951253890991e+00
    phi[7,3]  R1341     -1.7241166830062866e+00
    phi[7,3]  R1342     -2.2804946899414062e+00
    phi[7,3]  R1343     -9.6268552541732788e-01
    phi[7,3]  R1344     -2.4205882549285889e+00
    phi[7,3]  R1345     -8.2512879371643066e-01
    phi[7,3]  R1346     -1.7969044446945190e+00
    phi[7,3]  R1347     -2.2814469337463379e+00
    phi[7,3]  R1348     -8.1083381175994873e-01
    phi[7,3]  R1349     -2.6631608009338379e+00
    phi[7,3]  R1350     -4.2897863388061523e+00
    phi[7,3]  R1351     -1.3767224550247192e+00
    phi[7,3]  R1352     -3.4527678489685059e+00
    phi[7,3]  R1353     -2.8348419666290283e+00
    phi[7,3]  R1354     -1.8918871879577637e+00
    phi[7,3]  R1355     -2.6414623856544495e-01
    phi[7,3]  R1356     -4.2053112387657166e-01
    phi[7,3]  R1357     -2.1300847530364990e+00
    phi[7,3]  R1358     -2.4326183795928955e+00
    phi[7,3]  R1359     -1.3410764932632446e-01
    phi[7,3]  R1360     -3.9198322296142578e+00
    phi[7,3]  R1361     -1.0839822292327881e+00
    phi[7,3]  R1362     -1.7975517511367798e+00
    phi[7,3]  R1363     1.2998057603836060e+00
    phi[7,3]  R1364     -1.9893701076507568e+00
    phi[7,3]  R1365     -1.3362200260162354e+00
    phi[7,3]  R1366     -3.4279887676239014e+00
    phi[7,3]  R1367     -3.3276317119598389e+00
    phi[7,3]  R1368     -1.45125412940979
    phi[7,3]  R1369     -2.1254436969757080e+00
    phi[7,3]  R1370     -2.6439995765686035e+00
    phi[7,3]  R1371     -2.4999284744262695e+00
    phi[7,3]  R1372     -0.362288236618042
    phi[7,3]  R1373     -2.3846101760864258e+00
    phi[7,3]  R1374     -3.9022026062011719e+00
    phi[7,3]  R1375     2.2812046110630035e-01
    phi[7,3]  R1376     -3.1591396331787109e+00
    phi[7,3]  R1377     -2.7842397689819336e+00
    phi[7,3]  R1378     -2.6204161643981934e+00
    phi[7,3]  R1379     -2.75258469581604
    phi[7,3]  R1380     -2.0623269081115723e+00
    phi[7,3]  R1381     -1.6547034978866577e+00
    phi[7,3]  R1382     -4.6394124627113342e-01
    phi[7,3]  R1383     -7.9557400941848755e-01
    phi[7,3]  R1384     -2.8168640136718750e+00
    phi[7,3]  R1385     -1.6619507074356079e+00
    phi[7,3]  R1386     -2.7306077480316162e+00
    phi[7,3]  R1387     -1.5351079702377319e+00
    phi[7,3]  R1388     -1.4108999967575073e+00
    phi[7,3]  R1389     -1.7401942014694214e+00
    phi[7,3]  R1390     -2.6784791946411133e+00
    phi[7,3]  R1391     -8.0966401100158691e-01
    phi[7,3]  R1392     -1.4994885921478271e+00
    phi[7,3]  R1393     -3.2984893321990967e+00
    phi[7,3]  R1394     -2.5836477279663086e+00
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R72       -1
    phi[3,8]  R1395     -3.0999999046325684e+00
    phi[3,8]  R1396     -3.0999999046325684e+00
    phi[3,8]  R1397     -2.2400000095367432e+00
    phi[3,8]  R1398     -2.2400000095367432e+00
    phi[3,8]  R1399     -3.0999999046325684e+00
    phi[3,8]  R1400     -3.0999999046325684e+00
    phi[3,8]  R1401     -2.5699999332427979e+00
    phi[3,8]  R1402     -2.5699999332427979e+00
    phi[3,8]  R1403     -3.0999999046325684e+00
    phi[3,8]  R1404     -3.0999999046325684e+00
    phi[3,8]  R1405     -2.0899999141693115e+00
    phi[3,8]  R1406     -2.0899999141693115e+00
    phi[3,8]  R1407     -3.0999999046325684e+00
    phi[3,8]  R1408     -3.0999999046325684e+00
    phi[3,8]  R1409     4.0503711700439453e+00
    phi[3,8]  R1410     3.5879132747650146e+00
    phi[3,8]  R1411     4.1635389328002930e+00
    phi[3,8]  R1412     3.2585480213165283e+00
    phi[3,8]  R1413     2.8723938465118408e+00
    phi[3,8]  R1414     3.8616282939910889e+00
    phi[3,8]  R1415     2.5086247920989990e+00
    phi[3,8]  R1416     2.4652566909790039e+00
    phi[3,8]  R1417     1.1091188192367554e+00
    phi[3,8]  R1418     1.2103947401046753e+00
    phi[3,8]  R1419     -8.4151893854141235e-01
    phi[3,8]  R1420     -4.0702733993530273e+00
    phi[3,8]  R1421     -1.9245229959487915e+00
    phi[3,8]  R1422     -2.4356224536895752e+00
    phi[3,8]  R1423     -5.3516358137130737e-01
    phi[3,8]  R1424     -3.6943523883819580e+00
    phi[3,8]  R1425     -3.5076549053192139e+00
    phi[3,8]  R1426     -1.7195533514022827e+00
    phi[3,8]  R1427     -2.4534769058227539e+00
    phi[3,8]  R1428     -2.4601914882659912e+00
    phi[3,8]  R1429     -3.3927912712097168e+00
    phi[3,8]  R1430     -2.9344623088836670e+00
    phi[3,8]  R1431     -2.3598186969757080e+00
    phi[3,8]  R1432     -1.3337448835372925e+00
    phi[3,8]  R1433     -3.8295147418975830e+00
    phi[3,8]  R1434     -1.6439108848571777e+00
    phi[3,8]  R1435     -2.2237887382507324e+00
    phi[3,8]  R1436     -2.9040453433990479e+00
    phi[3,8]  R1437     -3.3276076316833496e+00
    phi[3,8]  R1438     -1.3717718124389648e+00
    phi[3,8]  R1439     -1.5473779439926147e+00
    phi[3,8]  R1440     -1.8232297897338867e+00
    phi[3,8]  R1441     -2.9122645854949951e+00
    phi[3,8]  R1442     -7.9303199052810669e-01
    phi[3,8]  R1443     -6.1385518312454224e-01
    phi[3,8]  R1444     -5.1806038618087769e-01
    phi[3,8]  R1445     -2.6435697078704834e+00
    phi[3,8]  R1446     -1.8787114620208740e+00
    phi[3,8]  R1447     -3.8015344142913818e+00
    phi[3,8]  R1448     -4.3842239379882812e+00
    phi[3,8]  R1449     -3.0115351676940918e+00
    phi[3,8]  R1450     -0.600979208946228
    phi[3,8]  R1451     -1.7651461362838745e+00
    phi[3,8]  R1452     -5.9371191263198853e-01
    phi[3,8]  R1453     -3.2955186367034912e+00
    phi[3,8]  R1454     -1.6063951253890991e+00
    phi[3,8]  R1455     -1.7241166830062866e+00
    phi[3,8]  R1456     -2.2804946899414062e+00
    phi[3,8]  R1457     -9.6268552541732788e-01
    phi[3,8]  R1458     -2.4205882549285889e+00
    phi[3,8]  R1459     -8.2512879371643066e-01
    phi[3,8]  R1460     -1.7969044446945190e+00
    phi[3,8]  R1461     -2.2814469337463379e+00
    phi[3,8]  R1462     -8.1083381175994873e-01
    phi[3,8]  R1463     -2.6631608009338379e+00
    phi[3,8]  R1464     -4.2897863388061523e+00
    phi[3,8]  R1465     -1.3767224550247192e+00
    phi[3,8]  R1466     -3.4527678489685059e+00
    phi[3,8]  R1467     -2.8348419666290283e+00
    phi[3,8]  R1468     -1.8918871879577637e+00
    phi[3,8]  R1469     -2.6414623856544495e-01
    phi[3,8]  R1470     -4.2053112387657166e-01
    phi[3,8]  R1471     -2.1300847530364990e+00
    phi[3,8]  R1472     -2.4326183795928955e+00
    phi[3,8]  R1473     -1.3410764932632446e-01
    phi[3,8]  R1474     -3.9198322296142578e+00
    phi[3,8]  R1475     -1.0839822292327881e+00
    phi[3,8]  R1476     -1.7975517511367798e+00
    phi[3,8]  R1477     1.2998057603836060e+00
    phi[3,8]  R1478     -1.9893701076507568e+00
    phi[3,8]  R1479     -1.3362200260162354e+00
    phi[3,8]  R1480     -3.4279887676239014e+00
    phi[3,8]  R1481     -3.3276317119598389e+00
    phi[3,8]  R1482     -1.45125412940979
    phi[3,8]  R1483     -2.1254436969757080e+00
    phi[3,8]  R1484     -2.6439995765686035e+00
    phi[3,8]  R1485     -2.4999284744262695e+00
    phi[3,8]  R1486     -0.362288236618042
    phi[3,8]  R1487     -2.3846101760864258e+00
    phi[3,8]  R1488     -3.9022026062011719e+00
    phi[3,8]  R1489     2.2812046110630035e-01
    phi[3,8]  R1490     -3.1591396331787109e+00
    phi[3,8]  R1491     -2.7842397689819336e+00
    phi[3,8]  R1492     -2.6204161643981934e+00
    phi[3,8]  R1493     -2.75258469581604
    phi[3,8]  R1494     -2.0623269081115723e+00
    phi[3,8]  R1495     -1.6547034978866577e+00
    phi[3,8]  R1496     -4.6394124627113342e-01
    phi[3,8]  R1497     -7.9557400941848755e-01
    phi[3,8]  R1498     -2.8168640136718750e+00
    phi[3,8]  R1499     -1.6619507074356079e+00
    phi[3,8]  R1500     -2.7306077480316162e+00
    phi[3,8]  R1501     -1.5351079702377319e+00
    phi[3,8]  R1502     -1.4108999967575073e+00
    phi[3,8]  R1503     -1.7401942014694214e+00
    phi[3,8]  R1504     -2.6784791946411133e+00
    phi[3,8]  R1505     -8.0966401100158691e-01
    phi[3,8]  R1506     -1.4994885921478271e+00
    phi[3,8]  R1507     -3.2984893321990967e+00
    phi[3,8]  R1508     -2.5836477279663086e+00
    phi[3,8]  R1509     2.9574358463287354e+00
    phi[3,8]  R1510     1.7678208351135254e+00
    phi[3,8]  R1511     2.7716984748840332e+00
    phi[3,8]  R1512     3.1057813167572021e+00
    phi[3,8]  R1513     2.5503857135772705e+00
    phi[3,8]  R1514     2.61163330078125
    phi[3,8]  R1515     2.2297563552856445e+00
    phi[3,8]  R1516     2.9782485961914062e+00
    phi[3,8]  R1517     3.6897568702697754e+00
    phi[3,8]  R1518     1.3750586509704590e+00
    phi[3,8]  R1519     -1.8856845796108246e-01
    phi[3,8]  R1520     1.5766894817352295e-01
    phi[3,8]  R1521     2.1403953433036804e-01
    phi[3,8]  R1522     -2.4956189095973969e-01
    phi[3,8]  R1523     6.7220932245254517e-01
    phi[3,8]  R1524     8.7469440698623657e-01
    phi[3,8]  R1525     1.3135534524917603e+00
    phi[3,8]  R1526     -1.9691134691238403e+00
    phi[3,8]  R1527     -1.7854479551315308e+00
    phi[3,8]  R1528     -9.6085512638092041e-01
    phi[3,8]  R1529     -3.1859538555145264e+00
    phi[3,8]  R1530     -1.9135022163391113e+00
    phi[3,8]  R1531     -7.1398347616195679e-01
    phi[3,8]  R1532     8.1113380193710327e-01
    phi[3,8]  R1533     -1.7607040405273438e+00
    phi[3,8]  R1534     -2.2081685066223145e+00
    phi[3,8]  R1535     -1.2687575817108154e+00
    phi[3,8]  R1536     -2.1916414797306061e-01
    phi[3,8]  R1537     -0.849112868309021
    phi[3,8]  R1538     -2.0379360020160675e-01
    phi[3,8]  R1539     -8.7801367044448853e-01
    phi[3,8]  R1540     7.2806692123413086e-01
    phi[3,8]  R1541     -2.9329149723052979e+00
    phi[3,8]  R1542     -1.4825030565261841e+00
    phi[3,8]  R1543     5.8833771944046021e-01
    phi[3,8]  R1544     -2.6530566215515137e+00
    phi[3,8]  R1545     -2.5690624713897705e+00
    phi[3,8]  R1546     -4.2340865135192871e+00
    phi[3,8]  R1547     -2.0677442550659180e+00
    phi[3,8]  R1548     -2.2118999958038330e+00
    phi[3,8]  R1549     -1.9137452840805054e+00
    phi[3,8]  R1550     -1.5108398199081421e+00
    phi[3,8]  R1551     1.3819980621337891e-01
    phi[3,8]  R1552     -1.3166280984878540e+00
    phi[3,8]  R1553     1.0300825834274292e+00
    phi[3,8]  R1554     0.884740948677063
    phi[3,8]  R1555     -2.3961904048919678e+00
    phi[3,8]  R1556     -1.5462066233158112e-01
    phi[3,8]  R1557     4.1079449653625488e-01
    phi[3,8]  R1558     -1.5275092124938965e+00
    phi[3,8]  R1559     -1.4849309921264648e+00
    phi[3,8]  R1560     -1.2991361618041992e+00
    phi[3,8]  R1561     -8.7873870134353638e-01
    phi[3,8]  R1562     -1.2331010103225708e+00
    phi[3,8]  R1563     -1.2191474437713623e+00
    phi[3,8]  R1564     -6.2540876865386963e-01
    phi[3,8]  R1565     -2.2967813014984131e+00
    phi[3,8]  R1566     1.7855854332447052e-01
    phi[3,8]  R1567     -1.0451027154922485e+00
    phi[3,8]  R1568     -1.4284933805465698e+00
    phi[3,8]  R1569     9.2354410886764526e-01
    phi[3,8]  R1570     -2.9172709584236145e-01
    phi[3,8]  R1571     -1.0273895263671875e+00
    phi[3,8]  R1572     -1.9816323518753052e+00
    phi[3,8]  R1573     -1.96592116355896
    phi[3,8]  R1574     -1.6121990680694580e+00
    phi[3,8]  R1575     -2.6360912322998047e+00
    phi[3,8]  R1576     -4.0716147422790527e+00
    phi[3,8]  R1577     -2.9305608272552490e+00
    phi[3,8]  R1578     -2.7916069030761719e+00
    phi[3,8]  R1579     -0.976621150970459
    phi[3,8]  R1580     -2.4576604366302490e+00
    phi[3,8]  R1581     -1.5908827781677246e+00
    phi[3,8]  R1582     -3.1188192367553711e+00
    phi[3,8]  R1583     -2.5783686637878418e+00
    phi[3,8]  R1584     -3.8530991077423096e+00
    phi[3,8]  R1585     -3.0460712909698486e+00
    phi[3,8]  R1586     -3.0901267528533936e+00
    phi[3,8]  R1587     1.2197611331939697e+00
    phi[3,8]  R1588     -3.8949646949768066e+00
    phi[8,3]  R27       -1
    phi[8,3]  R72       1
    phi[8,3]  R73       1
    phi[8,3]  R1589     -3.0999999046325684e+00
    phi[8,3]  R1590     -3.0999999046325684e+00
    phi[8,3]  R1591     -2.2400000095367432e+00
    phi[8,3]  R1592     -2.2400000095367432e+00
    phi[8,3]  R1593     -3.0999999046325684e+00
    phi[8,3]  R1594     -3.0999999046325684e+00
    phi[8,3]  R1595     -2.5699999332427979e+00
    phi[8,3]  R1596     -2.5699999332427979e+00
    phi[8,3]  R1597     -3.0999999046325684e+00
    phi[8,3]  R1598     -3.0999999046325684e+00
    phi[8,3]  R1599     -2.0899999141693115e+00
    phi[8,3]  R1600     -2.0899999141693115e+00
    phi[8,3]  R1601     -3.0999999046325684e+00
    phi[8,3]  R1602     -3.0999999046325684e+00
    phi[8,3]  R1603     2.9574358463287354e+00
    phi[8,3]  R1604     1.7678208351135254e+00
    phi[8,3]  R1605     2.7716984748840332e+00
    phi[8,3]  R1606     3.1057813167572021e+00
    phi[8,3]  R1607     2.5503857135772705e+00
    phi[8,3]  R1608     2.61163330078125
    phi[8,3]  R1609     2.2297563552856445e+00
    phi[8,3]  R1610     2.9782485961914062e+00
    phi[8,3]  R1611     3.6897568702697754e+00
    phi[8,3]  R1612     1.3750586509704590e+00
    phi[8,3]  R1613     -1.8856845796108246e-01
    phi[8,3]  R1614     1.5766894817352295e-01
    phi[8,3]  R1615     2.1403953433036804e-01
    phi[8,3]  R1616     -2.4956189095973969e-01
    phi[8,3]  R1617     6.7220932245254517e-01
    phi[8,3]  R1618     8.7469440698623657e-01
    phi[8,3]  R1619     1.3135534524917603e+00
    phi[8,3]  R1620     -1.9691134691238403e+00
    phi[8,3]  R1621     -1.7854479551315308e+00
    phi[8,3]  R1622     -9.6085512638092041e-01
    phi[8,3]  R1623     -3.1859538555145264e+00
    phi[8,3]  R1624     -1.9135022163391113e+00
    phi[8,3]  R1625     -7.1398347616195679e-01
    phi[8,3]  R1626     8.1113380193710327e-01
    phi[8,3]  R1627     -1.7607040405273438e+00
    phi[8,3]  R1628     -2.2081685066223145e+00
    phi[8,3]  R1629     -1.2687575817108154e+00
    phi[8,3]  R1630     -2.1916414797306061e-01
    phi[8,3]  R1631     -0.849112868309021
    phi[8,3]  R1632     -2.0379360020160675e-01
    phi[8,3]  R1633     -8.7801367044448853e-01
    phi[8,3]  R1634     7.2806692123413086e-01
    phi[8,3]  R1635     -2.9329149723052979e+00
    phi[8,3]  R1636     -1.4825030565261841e+00
    phi[8,3]  R1637     5.8833771944046021e-01
    phi[8,3]  R1638     -2.6530566215515137e+00
    phi[8,3]  R1639     -2.5690624713897705e+00
    phi[8,3]  R1640     -4.2340865135192871e+00
    phi[8,3]  R1641     -2.0677442550659180e+00
    phi[8,3]  R1642     -2.2118999958038330e+00
    phi[8,3]  R1643     -1.9137452840805054e+00
    phi[8,3]  R1644     -1.5108398199081421e+00
    phi[8,3]  R1645     1.3819980621337891e-01
    phi[8,3]  R1646     -1.3166280984878540e+00
    phi[8,3]  R1647     1.0300825834274292e+00
    phi[8,3]  R1648     0.884740948677063
    phi[8,3]  R1649     -2.3961904048919678e+00
    phi[8,3]  R1650     -1.5462066233158112e-01
    phi[8,3]  R1651     4.1079449653625488e-01
    phi[8,3]  R1652     -1.5275092124938965e+00
    phi[8,3]  R1653     -1.4849309921264648e+00
    phi[8,3]  R1654     -1.2991361618041992e+00
    phi[8,3]  R1655     -8.7873870134353638e-01
    phi[8,3]  R1656     -1.2331010103225708e+00
    phi[8,3]  R1657     -1.2191474437713623e+00
    phi[8,3]  R1658     -6.2540876865386963e-01
    phi[8,3]  R1659     -2.2967813014984131e+00
    phi[8,3]  R1660     1.7855854332447052e-01
    phi[8,3]  R1661     -1.0451027154922485e+00
    phi[8,3]  R1662     -1.4284933805465698e+00
    phi[8,3]  R1663     9.2354410886764526e-01
    phi[8,3]  R1664     -2.9172709584236145e-01
    phi[8,3]  R1665     -1.0273895263671875e+00
    phi[8,3]  R1666     -1.9816323518753052e+00
    phi[8,3]  R1667     -1.96592116355896
    phi[8,3]  R1668     -1.6121990680694580e+00
    phi[8,3]  R1669     -2.6360912322998047e+00
    phi[8,3]  R1670     -4.0716147422790527e+00
    phi[8,3]  R1671     -2.9305608272552490e+00
    phi[8,3]  R1672     -2.7916069030761719e+00
    phi[8,3]  R1673     -0.976621150970459
    phi[8,3]  R1674     -2.4576604366302490e+00
    phi[8,3]  R1675     -1.5908827781677246e+00
    phi[8,3]  R1676     -3.1188192367553711e+00
    phi[8,3]  R1677     -2.5783686637878418e+00
    phi[8,3]  R1678     -3.8530991077423096e+00
    phi[8,3]  R1679     -3.0460712909698486e+00
    phi[8,3]  R1680     -3.0901267528533936e+00
    phi[8,3]  R1681     1.2197611331939697e+00
    phi[8,3]  R1682     -3.8949646949768066e+00
    phi[8,3]  R1683     4.0503711700439453e+00
    phi[8,3]  R1684     3.5879132747650146e+00
    phi[8,3]  R1685     4.1635389328002930e+00
    phi[8,3]  R1686     3.2585480213165283e+00
    phi[8,3]  R1687     2.8723938465118408e+00
    phi[8,3]  R1688     3.8616282939910889e+00
    phi[8,3]  R1689     2.5086247920989990e+00
    phi[8,3]  R1690     2.4652566909790039e+00
    phi[8,3]  R1691     1.1091188192367554e+00
    phi[8,3]  R1692     1.2103947401046753e+00
    phi[8,3]  R1693     -8.4151893854141235e-01
    phi[8,3]  R1694     -4.0702733993530273e+00
    phi[8,3]  R1695     -1.9245229959487915e+00
    phi[8,3]  R1696     -2.4356224536895752e+00
    phi[8,3]  R1697     -5.3516358137130737e-01
    phi[8,3]  R1698     -3.6943523883819580e+00
    phi[8,3]  R1699     -3.5076549053192139e+00
    phi[8,3]  R1700     -1.7195533514022827e+00
    phi[8,3]  R1701     -2.4534769058227539e+00
    phi[8,3]  R1702     -2.4601914882659912e+00
    phi[8,3]  R1703     -3.3927912712097168e+00
    phi[8,3]  R1704     -2.9344623088836670e+00
    phi[8,3]  R1705     -2.3598186969757080e+00
    phi[8,3]  R1706     -1.3337448835372925e+00
    phi[8,3]  R1707     -3.8295147418975830e+00
    phi[8,3]  R1708     -1.6439108848571777e+00
    phi[8,3]  R1709     -2.2237887382507324e+00
    phi[8,3]  R1710     -2.9040453433990479e+00
    phi[8,3]  R1711     -3.3276076316833496e+00
    phi[8,3]  R1712     -1.3717718124389648e+00
    phi[8,3]  R1713     -1.5473779439926147e+00
    phi[8,3]  R1714     -1.8232297897338867e+00
    phi[8,3]  R1715     -2.9122645854949951e+00
    phi[8,3]  R1716     -7.9303199052810669e-01
    phi[8,3]  R1717     -6.1385518312454224e-01
    phi[8,3]  R1718     -5.1806038618087769e-01
    phi[8,3]  R1719     -2.6435697078704834e+00
    phi[8,3]  R1720     -1.8787114620208740e+00
    phi[8,3]  R1721     -3.8015344142913818e+00
    phi[8,3]  R1722     -4.3842239379882812e+00
    phi[8,3]  R1723     -3.0115351676940918e+00
    phi[8,3]  R1724     -0.600979208946228
    phi[8,3]  R1725     -1.7651461362838745e+00
    phi[8,3]  R1726     -5.9371191263198853e-01
    phi[8,3]  R1727     -3.2955186367034912e+00
    phi[8,3]  R1728     -1.6063951253890991e+00
    phi[8,3]  R1729     -1.7241166830062866e+00
    phi[8,3]  R1730     -2.2804946899414062e+00
    phi[8,3]  R1731     -9.6268552541732788e-01
    phi[8,3]  R1732     -2.4205882549285889e+00
    phi[8,3]  R1733     -8.2512879371643066e-01
    phi[8,3]  R1734     -1.7969044446945190e+00
    phi[8,3]  R1735     -2.2814469337463379e+00
    phi[8,3]  R1736     -8.1083381175994873e-01
    phi[8,3]  R1737     -2.6631608009338379e+00
    phi[8,3]  R1738     -4.2897863388061523e+00
    phi[8,3]  R1739     -1.3767224550247192e+00
    phi[8,3]  R1740     -3.4527678489685059e+00
    phi[8,3]  R1741     -2.8348419666290283e+00
    phi[8,3]  R1742     -1.8918871879577637e+00
    phi[8,3]  R1743     -2.6414623856544495e-01
    phi[8,3]  R1744     -4.2053112387657166e-01
    phi[8,3]  R1745     -2.1300847530364990e+00
    phi[8,3]  R1746     -2.4326183795928955e+00
    phi[8,3]  R1747     -1.3410764932632446e-01
    phi[8,3]  R1748     -3.9198322296142578e+00
    phi[8,3]  R1749     -1.0839822292327881e+00
    phi[8,3]  R1750     -1.7975517511367798e+00
    phi[8,3]  R1751     1.2998057603836060e+00
    phi[8,3]  R1752     -1.9893701076507568e+00
    phi[8,3]  R1753     -1.3362200260162354e+00
    phi[8,3]  R1754     -3.4279887676239014e+00
    phi[8,3]  R1755     -3.3276317119598389e+00
    phi[8,3]  R1756     -1.45125412940979
    phi[8,3]  R1757     -2.1254436969757080e+00
    phi[8,3]  R1758     -2.6439995765686035e+00
    phi[8,3]  R1759     -2.4999284744262695e+00
    phi[8,3]  R1760     -0.362288236618042
    phi[8,3]  R1761     -2.3846101760864258e+00
    phi[8,3]  R1762     -3.9022026062011719e+00
    phi[8,3]  R1763     2.2812046110630035e-01
    phi[8,3]  R1764     -3.1591396331787109e+00
    phi[8,3]  R1765     -2.7842397689819336e+00
    phi[8,3]  R1766     -2.6204161643981934e+00
    phi[8,3]  R1767     -2.75258469581604
    phi[8,3]  R1768     -2.0623269081115723e+00
    phi[8,3]  R1769     -1.6547034978866577e+00
    phi[8,3]  R1770     -4.6394124627113342e-01
    phi[8,3]  R1771     -7.9557400941848755e-01
    phi[8,3]  R1772     -2.8168640136718750e+00
    phi[8,3]  R1773     -1.6619507074356079e+00
    phi[8,3]  R1774     -2.7306077480316162e+00
    phi[8,3]  R1775     -1.5351079702377319e+00
    phi[8,3]  R1776     -1.4108999967575073e+00
    phi[8,3]  R1777     -1.7401942014694214e+00
    phi[8,3]  R1778     -2.6784791946411133e+00
    phi[8,3]  R1779     -8.0966401100158691e-01
    phi[8,3]  R1780     -1.4994885921478271e+00
    phi[8,3]  R1781     -3.2984893321990967e+00
    phi[8,3]  R1782     -2.5836477279663086e+00
    phi[3,10]  R27       1
    phi[3,10]  R28       1
    phi[3,10]  R29       2.1169342290670903e+00
    phi[3,10]  R30       1.4578004069282136e-01
    phi[3,10]  R31       2.7019429283681484e+00
    phi[3,10]  R32       -1.47339882112013
    phi[3,10]  R33       1.6277192221282757e+00
    phi[3,10]  R34       1.2967216847552172e+00
    phi[3,10]  R35       -2.4576673418323316e+00
    phi[3,10]  R82       -1
    phi[3,10]  R1783     -9.8306567556547808e-01
    phi[3,10]  R1784     -5.2169341336996586e+00
    phi[3,10]  R1785     -2.0942199688439218e+00
    phi[3,10]  R1786     -2.3857800502295645e+00
    phi[3,10]  R1787     -3.9805697626441994e-01
    phi[3,10]  R1788     -5.8019428330007168e+00
    phi[3,10]  R1789     -4.0433987543629275e+00
    phi[3,10]  R1790     -1.0966011121226678e+00
    phi[3,10]  R1791     -1.4722806825042927e+00
    phi[3,10]  R1792     -4.7277191267608440e+00
    phi[3,10]  R1793     -7.9327822941409432e-01
    phi[3,10]  R1794     -3.3867215989245287e+00
    phi[3,10]  R1795     -5.5576672464649
    phi[3,10]  R1796     -6.4233256280023676e-01
    phi[3,10]  R1797     -2.0800680094457835e-01
    phi[3,10]  R1798     -2.1154214361057910e-01
    phi[3,10]  R1799     -2.1323199674708970e-01
    phi[3,10]  R1800     -2.1917279113292931e-01
    phi[3,10]  R1801     -2.2139104565637435e-01
    phi[3,10]  R1802     -2.2168309383004825e-01
    phi[3,10]  R1803     -2.3024205283010435e-01
    phi[3,10]  R1804     -3.0807224672629818e-01
    phi[3,10]  R1805     -3.3868522230155929e-01
    phi[3,10]  R1806     -3.7902469629702296e-01
    phi[3,10]  R1807     -3.5018769200914723e-01
    phi[3,10]  R1808     -3.5098674848079447e-01
    phi[3,10]  R1809     -3.8539606414574057e-01
    phi[3,10]  R1810     -4.4719345596318849e-01
    phi[3,10]  R1811     -4.5482720983720659e-01
    phi[3,10]  R1812     -4.6546648590111772e-01
    phi[3,10]  R1813     -4.9049560681478832e-01
    phi[3,10]  R1814     -0.531275743890002
    phi[3,10]  R1815     -5.3746220689766244e-01
    phi[3,10]  R1816     -7.9931258194289945e-01
    phi[3,10]  R1817     -4.2636787707551349e-01
    phi[3,10]  R1818     -2.1419663188227718e+00
    phi[3,10]  R1819     -1.3479556035902143e+00
    phi[3,10]  R1820     -5.2275665930463311e-01
    phi[3,10]  R1821     -5.3653078840565094e-01
    phi[3,10]  R1822     -5.3845290274030644e-01
    phi[3,10]  R1823     -5.4432170027854521e-01
    phi[3,10]  R1824     -5.4793634034639416e-01
    phi[3,10]  R1825     -1.6789525663762457e+00
    phi[3,10]  R1826     -0.564852457769381
    phi[3,10]  R1827     -3.0023787168384319e-01
    phi[3,10]  R1828     -9.6461646266977907e-01
    phi[3,10]  R1829     -6.0753068237011787e-01
    phi[3,10]  R1830     -7.7536389851132959e-01
    phi[3,10]  R1831     -4.1055257554284841e-01
    phi[3,10]  R1832     -4.4990615718087579e-01
    phi[3,10]  R1833     -2.1829415482262506e+00
    phi[3,10]  R1834     -2.2994754336264571e+00
    phi[3,10]  R1835     -5.2387824582130182e-01
    phi[3,10]  R1836     -2.0096539860534937e+00
    phi[3,10]  R1837     -3.5878276042706414e-01
    phi[3,10]  R1838     -3.7167714723669576e-01
    phi[3,10]  R1839     -2.3046396827448890e+00
    phi[3,10]  R1840     -5.5234540407806176e-01
    phi[3,10]  R1841     -5.7188552209172849e-01
    phi[3,10]  R1842     -1.6935785943895270e+00
    phi[3,10]  R1843     -6.3131076352477611e-01
    phi[3,10]  R1844     -2.0827408610597744e+00
    phi[3,10]  R1845     -6.4486884471058770e-01
    phi[3,10]  R1846     -2.5244682891928214e+00
    phi[3,10]  R1847     -3.5964855843324783e-01
    phi[3,10]  R1848     -1.7438259855316465e+00
    phi[3,10]  R1849     -1.8153731145259204e+00
    phi[3,10]  R1850     -4.1794113577647840e-01
    phi[3,10]  R1851     -5.0140337338259844e-01
    phi[3,10]  R1852     -1.5734663261433894e+00
    phi[3,10]  R1853     -5.3347958141660368e-01
    phi[3,10]  R1854     -8.1582342850742551e-01
    phi[3,10]  R1855     -5.6548624422366256e-01
    phi[3,10]  R1856     -8.1794842115182176e-01
    phi[3,10]  R1857     -3.2997008201313915e-01
    phi[3,10]  R1858     -3.9877984940111938e-01
    phi[3,10]  R1859     -4.4463974232440928e-01
    phi[3,10]  R1860     -5.0878013858831084e-01
    phi[3,10]  R1861     -5.2516983076347534e-01
    phi[3,10]  R1862     -0.956792299579118
    phi[3,10]  R1863     -5.4499086457293044e-01
    phi[3,10]  R1864     -8.4968459021661569e-01
    phi[3,10]  R1865     -6.1860816583446421e-01
    phi[3,10]  R1866     -1.5143255825339093e+00
    phi[3,10]  R1867     -3.9561796491884293e-01
    phi[3,10]  R1868     -2.1101372760027091e+00
    phi[3,10]  R1869     -4.5802519510066819e-01
    phi[3,10]  R1870     -0.465994020700512
    phi[3,10]  R1871     -4.7010088726262511e-01
    phi[3,10]  R1872     -5.2786926233799036e-01
    phi[3,10]  R1873     -6.1141561531988287e-01
    phi[3,10]  R1874     -0.631325704155495
    phi[3,10]  R1875     -1.1039618558304123e+00
    phi[3,10]  R1876     -0.700933011092526
    phi[3,10]  R1877     -3.7317001426767282e-01
    phi[3,10]  R1878     -4.6120234407527150e-01
    phi[3,10]  R1879     -8.6232879601864720e-01
    phi[3,10]  R1880     -6.7433552430157917e-01
    phi[3,10]  R1881     -5.9636593134858185e-01
    phi[3,10]  R1882     -7.2594730133573737e-01
    phi[3,10]  R1883     -7.5411843083789720e-01
    phi[3,10]  R1884     -1.7379433865551781e+00
    phi[3,10]  R1885     -7.9469667438201985e-01
    phi[3,10]  R1886     -0.798759158052357
    phi[3,10]  R1887     -3.6995862914634170e-01
    phi[3,10]  R1888     -3.7299150576983919e-01
    phi[3,10]  R1889     -4.4884446875663064e-01
    phi[3,10]  R1890     -5.2183192195106809e-01
    phi[3,10]  R1891     -5.7042344585957161e-01
    phi[3,10]  R1892     -0.584465104197406
    phi[3,10]  R1893     -7.4835401086192110e-01
    phi[3,10]  R1894     -7.7438819001203063e-01
    phi[3,10]  R1895     -7.7702082637463032e-01
    phi[3,10]  R1896     -7.9347868715131731e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1897     -3.0999999046325684e+00
    phi[4,5]  R1898     -3.0999999046325684e+00
    phi[4,5]  R1899     -2.2400000095367432e+00
    phi[4,5]  R1900     -2.2400000095367432e+00
    phi[4,5]  R1901     -3.0999999046325684e+00
    phi[4,5]  R1902     -3.0999999046325684e+00
    phi[4,5]  R1903     -2.5699999332427979e+00
    phi[4,5]  R1904     -2.5699999332427979e+00
    phi[4,5]  R1905     -3.0999999046325684e+00
    phi[4,5]  R1906     -3.0999999046325684e+00
    phi[4,5]  R1907     -2.0899999141693115e+00
    phi[4,5]  R1908     -2.0899999141693115e+00
    phi[4,5]  R1909     -3.0999999046325684e+00
    phi[4,5]  R1910     -3.0999999046325684e+00
    phi[4,5]  R1911     1.1243607997894287e+00
    phi[4,5]  R1912     2.1491339206695557e+00
    phi[4,5]  R1913     -8.8472092151641846e-01
    phi[4,5]  R1914     7.6672635972499847e-02
    phi[4,5]  R1915     -7.6923805475234985e-01
    phi[4,5]  R1916     -1.1769566535949707e+00
    phi[4,5]  R1917     1.5079428255558014e-01
    phi[4,5]  R1918     -9.3189823627471924e-01
    phi[4,5]  R1919     0.969227135181427
    phi[4,5]  R1920     2.0665812492370605e+00
    phi[4,5]  R1921     -1.5401909351348877e+00
    phi[4,5]  R1922     1.0428057909011841e+00
    phi[4,5]  R1923     2.1005659103393555e+00
    phi[4,5]  R1924     -6.5750908851623535e-01
    phi[4,5]  R1925     -2.5939838886260986e+00
    phi[4,5]  R1926     -2.5566837787628174e+00
    phi[4,5]  R1927     -2.3046352863311768e+00
    phi[4,5]  R1928     -1.8035209178924561e+00
    phi[4,5]  R1929     -2.3306467533111572e+00
    phi[4,5]  R1930     -4.0224194526672363e-01
    phi[4,5]  R1931     1.1064871549606323e+00
    phi[4,5]  R1932     -2.0770347118377686e+00
    phi[4,5]  R1933     6.8675804138183594e-01
    phi[4,5]  R1934     -1.8025043010711670e+00
    phi[4,5]  R1935     -0.618039608001709
    phi[4,5]  R1936     1.2384635210037231e+00
    phi[4,5]  R1937     1.2009190320968628e+00
    phi[4,5]  R1938     2.2980306148529053e+00
    phi[4,5]  R1939     6.8003827333450317e-01
    phi[4,5]  R1940     -1.9158256053924561e+00
    phi[4,5]  R1941     6.1235660314559937e-01
    phi[4,5]  R1942     -1.5051623582839966e+00
    phi[4,5]  R1943     -1.8261150121688843e+00
    phi[4,5]  R1944     4.5234224200248718e-01
    phi[4,5]  R1945     -1.4219955205917358e+00
    phi[4,5]  R1946     -1.8751188516616821e+00
    phi[4,5]  R1947     1.4069317579269409e+00
    phi[4,5]  R1948     9.3102663755416870e-02
    phi[4,5]  R1949     7.2135728597640991e-01
    phi[4,5]  R1950     -5.4492145776748657e-01
    phi[4,5]  R1951     -2.2762084007263184e+00
    phi[4,5]  R1952     -1.3509545326232910e+00
    phi[4,5]  R1953     -4.9528825283050537e-01
    phi[4,5]  R1954     1.3559268712997437e+00
    phi[4,5]  R1955     1.2898880243301392e+00
    phi[4,5]  R1956     -3.6097741127014160e-01
    phi[4,5]  R1957     -1.5508773326873779e+00
    phi[4,5]  R1958     -5.9530276060104370e-01
    phi[4,5]  R1959     5.7704550027847290e-01
    phi[4,5]  R1960     -1.0415625572204590e+00
    phi[4,5]  R1961     -1.2070719003677368e+00
    phi[4,5]  R1962     -5.1577007770538330e-01
    phi[4,5]  R1963     -1.4303536415100098e+00
    phi[4,5]  R1964     -2.0272398367524147e-02
    phi[4,5]  R1965     -6.1094999313354492e-01
    phi[4,5]  R1966     3.7742918729782104e-01
    phi[4,5]  R1967     -1.1045762300491333e+00
    phi[4,5]  R1968     -1.6322221755981445e+00
    phi[4,5]  R1969     -3.7021777033805847e-01
    phi[4,5]  R1970     -1.85337495803833
    phi[4,5]  R1971     -2.3583102226257324e+00
    phi[4,5]  R1972     -8.7704420089721680e-01
    phi[4,5]  R1973     -8.7660294771194458e-01
    phi[4,5]  R1974     -1.5302660465240479e+00
    phi[4,5]  R1975     -4.9395978450775146e-01
    phi[4,5]  R1976     -1.8319665193557739e+00
    phi[4,5]  R1977     -9.4045169651508331e-02
    phi[4,5]  R1978     -1.6604487895965576e+00
    phi[4,5]  R1979     -1.6271107196807861e+00
    phi[4,5]  R1980     -1.9775663614273071e+00
    phi[4,5]  R1981     -2.1356398239731789e-02
    phi[4,5]  R1982     -4.1763834655284882e-02
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1983     -3.0999999046325684e+00
    phi[5,4]  R1984     -3.0999999046325684e+00
    phi[5,4]  R1985     -2.2400000095367432e+00
    phi[5,4]  R1986     -2.2400000095367432e+00
    phi[5,4]  R1987     -3.0999999046325684e+00
    phi[5,4]  R1988     -3.0999999046325684e+00
    phi[5,4]  R1989     -2.5699999332427979e+00
    phi[5,4]  R1990     -2.5699999332427979e+00
    phi[5,4]  R1991     -3.0999999046325684e+00
    phi[5,4]  R1992     -3.0999999046325684e+00
    phi[5,4]  R1993     -2.0899999141693115e+00
    phi[5,4]  R1994     -2.0899999141693115e+00
    phi[5,4]  R1995     -3.0999999046325684e+00
    phi[5,4]  R1996     -3.0999999046325684e+00
    phi[5,4]  R1997     -0.618039608001709
    phi[5,4]  R1998     1.2384635210037231e+00
    phi[5,4]  R1999     1.2009190320968628e+00
    phi[5,4]  R2000     2.2980306148529053e+00
    phi[5,4]  R2001     6.8003827333450317e-01
    phi[5,4]  R2002     -1.9158256053924561e+00
    phi[5,4]  R2003     6.1235660314559937e-01
    phi[5,4]  R2004     -1.5051623582839966e+00
    phi[5,4]  R2005     -1.8261150121688843e+00
    phi[5,4]  R2006     4.5234224200248718e-01
    phi[5,4]  R2007     -1.4219955205917358e+00
    phi[5,4]  R2008     -1.8751188516616821e+00
    phi[5,4]  R2009     1.4069317579269409e+00
    phi[5,4]  R2010     9.3102663755416870e-02
    phi[5,4]  R2011     7.2135728597640991e-01
    phi[5,4]  R2012     -5.4492145776748657e-01
    phi[5,4]  R2013     -2.2762084007263184e+00
    phi[5,4]  R2014     -1.3509545326232910e+00
    phi[5,4]  R2015     -4.9528825283050537e-01
    phi[5,4]  R2016     1.3559268712997437e+00
    phi[5,4]  R2017     1.2898880243301392e+00
    phi[5,4]  R2018     -3.6097741127014160e-01
    phi[5,4]  R2019     -1.5508773326873779e+00
    phi[5,4]  R2020     -5.9530276060104370e-01
    phi[5,4]  R2021     5.7704550027847290e-01
    phi[5,4]  R2022     -1.0415625572204590e+00
    phi[5,4]  R2023     -1.2070719003677368e+00
    phi[5,4]  R2024     -5.1577007770538330e-01
    phi[5,4]  R2025     -1.4303536415100098e+00
    phi[5,4]  R2026     -2.0272398367524147e-02
    phi[5,4]  R2027     -6.1094999313354492e-01
    phi[5,4]  R2028     3.7742918729782104e-01
    phi[5,4]  R2029     -1.1045762300491333e+00
    phi[5,4]  R2030     -1.6322221755981445e+00
    phi[5,4]  R2031     -3.7021777033805847e-01
    phi[5,4]  R2032     -1.85337495803833
    phi[5,4]  R2033     -2.3583102226257324e+00
    phi[5,4]  R2034     -8.7704420089721680e-01
    phi[5,4]  R2035     -8.7660294771194458e-01
    phi[5,4]  R2036     -1.5302660465240479e+00
    phi[5,4]  R2037     -4.9395978450775146e-01
    phi[5,4]  R2038     -1.8319665193557739e+00
    phi[5,4]  R2039     -9.4045169651508331e-02
    phi[5,4]  R2040     -1.6604487895965576e+00
    phi[5,4]  R2041     -1.6271107196807861e+00
    phi[5,4]  R2042     -1.9775663614273071e+00
    phi[5,4]  R2043     -2.1356398239731789e-02
    phi[5,4]  R2044     -4.1763834655284882e-02
    phi[5,4]  R2045     1.1243607997894287e+00
    phi[5,4]  R2046     2.1491339206695557e+00
    phi[5,4]  R2047     -8.8472092151641846e-01
    phi[5,4]  R2048     7.6672635972499847e-02
    phi[5,4]  R2049     -7.6923805475234985e-01
    phi[5,4]  R2050     -1.1769566535949707e+00
    phi[5,4]  R2051     1.5079428255558014e-01
    phi[5,4]  R2052     -9.3189823627471924e-01
    phi[5,4]  R2053     0.969227135181427
    phi[5,4]  R2054     2.0665812492370605e+00
    phi[5,4]  R2055     -1.5401909351348877e+00
    phi[5,4]  R2056     1.0428057909011841e+00
    phi[5,4]  R2057     2.1005659103393555e+00
    phi[5,4]  R2058     -6.5750908851623535e-01
    phi[5,4]  R2059     -2.5939838886260986e+00
    phi[5,4]  R2060     -2.5566837787628174e+00
    phi[5,4]  R2061     -2.3046352863311768e+00
    phi[5,4]  R2062     -1.8035209178924561e+00
    phi[5,4]  R2063     -2.3306467533111572e+00
    phi[5,4]  R2064     -4.0224194526672363e-01
    phi[5,4]  R2065     1.1064871549606323e+00
    phi[5,4]  R2066     -2.0770347118377686e+00
    phi[5,4]  R2067     6.8675804138183594e-01
    phi[5,4]  R2068     -1.8025043010711670e+00
    phi[9,4]  R36       -1
    phi[9,4]  R38       9.8416540455203760e-01
    phi[9,4]  R39       3.5577658564143810e-01
    phi[9,4]  R40       3.1052847899467384e-02
    phi[9,4]  R41       1.4558704339039
    phi[9,4]  R42       -2.7796958883093712e+00
    phi[9,4]  R43       -1.1530399341127979e+00
    phi[9,4]  R44       7.3602550201200545e-01
    phi[9,4]  R81       1
    phi[9,4]  R2069     -4.0841653091846055e+00
    phi[9,4]  R2070     -2.1158345000805308e+00
    phi[9,4]  R2071     -2.5957765951781813e+00
    phi[9,4]  R2072     -1.8842234238953051e+00
    phi[9,4]  R2073     -3.1310527525320357e+00
    phi[9,4]  R2074     -3.0689470567331010e+00
    phi[9,4]  R2075     -4.0258703671466982e+00
    phi[9,4]  R2076     -1.1141294993388979e+00
    phi[9,4]  R2077     -3.2030401632319716e-01
    phi[9,4]  R2078     -5.87969579294194
    phi[9,4]  R2079     -9.3695998005651360e-01
    phi[9,4]  R2080     -3.2430398482821094e+00
    phi[9,4]  R2081     -3.8360254066445738e+00
    phi[9,4]  R2082     -2.3639744026205629e+00
    phi[9,4]  R2083     -2.6756556135898890e-02
    phi[9,4]  R2084     -2.9908266774610226e-02
    phi[9,4]  R2085     -0.767077310258295
    phi[9,4]  R2086     -1.0406540205116017e+00
    phi[9,4]  R2087     -5.3760724136685223e-01
    phi[9,4]  R2088     -2.5743508951487082e-01
    phi[9,4]  R2089     -1.4227082398769548e+00
    phi[9,4]  R2090     -3.0899357898818669e-01
    phi[9,4]  R2091     -3.5122612844815770e-01
    phi[9,4]  R2092     -3.5472161121134116e-01
    phi[9,4]  R2093     -1.6969744509539653e-01
    phi[9,4]  R2094     -1.8869430878811655e-01
    phi[9,4]  R2095     -0.229447313977877
    phi[9,4]  R2096     -2.8685827902367211e-01
    phi[9,4]  R2097     -3.5859528623772485e-01
    phi[9,4]  R2098     -5.5431711639833159e-01
    phi[9,4]  R2099     -1.1672939844116277e+00
    phi[9,4]  R2100     -1.2248507209634596e-01
    phi[9,4]  R2101     -1.2501339868740136e-01
    phi[9,4]  R2102     -1.3346657761875153e-01
    phi[9,4]  R2103     -2.0703133529938134e-01
    phi[9,4]  R2104     -2.3741406125050202e-01
    phi[9,4]  R2105     -2.9519906033505461e-01
    phi[9,4]  R2106     -3.8919637314175892e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2107     -3.0999999046325684e+00
    phi[5,6]  R2108     -3.0999999046325684e+00
    phi[5,6]  R2109     -2.2400000095367432e+00
    phi[5,6]  R2110     -2.2400000095367432e+00
    phi[5,6]  R2111     -3.0999999046325684e+00
    phi[5,6]  R2112     -3.0999999046325684e+00
    phi[5,6]  R2113     -2.5699999332427979e+00
    phi[5,6]  R2114     -2.5699999332427979e+00
    phi[5,6]  R2115     -3.0999999046325684e+00
    phi[5,6]  R2116     -3.0999999046325684e+00
    phi[5,6]  R2117     -2.0899999141693115e+00
    phi[5,6]  R2118     -2.0899999141693115e+00
    phi[5,6]  R2119     -3.0999999046325684e+00
    phi[5,6]  R2120     -3.0999999046325684e+00
    phi[5,6]  R2121     -0.618039608001709
    phi[5,6]  R2122     1.2384635210037231e+00
    phi[5,6]  R2123     1.2009190320968628e+00
    phi[5,6]  R2124     2.2980306148529053e+00
    phi[5,6]  R2125     6.8003827333450317e-01
    phi[5,6]  R2126     -1.9158256053924561e+00
    phi[5,6]  R2127     6.1235660314559937e-01
    phi[5,6]  R2128     -1.5051623582839966e+00
    phi[5,6]  R2129     -1.8261150121688843e+00
    phi[5,6]  R2130     4.5234224200248718e-01
    phi[5,6]  R2131     -1.4219955205917358e+00
    phi[5,6]  R2132     -1.8751188516616821e+00
    phi[5,6]  R2133     1.4069317579269409e+00
    phi[5,6]  R2134     9.3102663755416870e-02
    phi[5,6]  R2135     7.2135728597640991e-01
    phi[5,6]  R2136     -5.4492145776748657e-01
    phi[5,6]  R2137     -2.2762084007263184e+00
    phi[5,6]  R2138     -1.3509545326232910e+00
    phi[5,6]  R2139     -4.9528825283050537e-01
    phi[5,6]  R2140     1.3559268712997437e+00
    phi[5,6]  R2141     1.2898880243301392e+00
    phi[5,6]  R2142     -3.6097741127014160e-01
    phi[5,6]  R2143     -1.5508773326873779e+00
    phi[5,6]  R2144     -5.9530276060104370e-01
    phi[5,6]  R2145     5.7704550027847290e-01
    phi[5,6]  R2146     -1.0415625572204590e+00
    phi[5,6]  R2147     -1.2070719003677368e+00
    phi[5,6]  R2148     -5.1577007770538330e-01
    phi[5,6]  R2149     -1.4303536415100098e+00
    phi[5,6]  R2150     -2.0272398367524147e-02
    phi[5,6]  R2151     -6.1094999313354492e-01
    phi[5,6]  R2152     3.7742918729782104e-01
    phi[5,6]  R2153     -1.1045762300491333e+00
    phi[5,6]  R2154     -1.6322221755981445e+00
    phi[5,6]  R2155     -3.7021777033805847e-01
    phi[5,6]  R2156     -1.85337495803833
    phi[5,6]  R2157     -2.3583102226257324e+00
    phi[5,6]  R2158     -8.7704420089721680e-01
    phi[5,6]  R2159     -8.7660294771194458e-01
    phi[5,6]  R2160     -1.5302660465240479e+00
    phi[5,6]  R2161     -4.9395978450775146e-01
    phi[5,6]  R2162     -1.8319665193557739e+00
    phi[5,6]  R2163     -9.4045169651508331e-02
    phi[5,6]  R2164     -1.6604487895965576e+00
    phi[5,6]  R2165     -1.6271107196807861e+00
    phi[5,6]  R2166     -1.9775663614273071e+00
    phi[5,6]  R2167     -2.1356398239731789e-02
    phi[5,6]  R2168     -4.1763834655284882e-02
    phi[5,6]  R2169     7.1006518602371216e-01
    phi[5,6]  R2170     8.9362072944641113e-01
    phi[5,6]  R2171     -2.6304274797439575e-04
    phi[5,6]  R2172     -7.2472828626632690e-01
    phi[5,6]  R2173     1.4569396972656250e+00
    phi[5,6]  R2174     1.4274829626083374e+00
    phi[5,6]  R2175     1.9080957174301147e+00
    phi[5,6]  R2176     -3.1568434834480286e-01
    phi[5,6]  R2177     -5.7496017217636108e-01
    phi[5,6]  R2178     1.1733049154281616e+00
    phi[5,6]  R2179     -1.2986304759979248e+00
    phi[5,6]  R2180     -2.5701576471328735e-01
    phi[5,6]  R2181     2.6179161667823792e-01
    phi[5,6]  R2182     -2.2015528678894043e+00
    phi[5,6]  R2183     -2.1397325992584229e+00
    phi[5,6]  R2184     -1.9427852630615234e+00
    phi[5,6]  R2185     2.6902338862419128e-01
    phi[5,6]  R2186     -2.8015897274017334e+00
    phi[5,6]  R2187     2.1780595779418945e+00
    phi[5,6]  R2188     -1.2803990840911865e+00
    phi[5,6]  R2189     -2.3639614880084991e-01
    phi[5,6]  R2190     -1.2944108247756958e+00
    phi[5,6]  R2191     -1.4041055440902710e+00
    phi[5,6]  R2192     -2.6837801933288574e+00
    phi[5,6]  R2193     -3.3820278644561768e+00
    phi[5,6]  R2194     -1.1221339702606201e+00
    phi[5,6]  R2195     -2.0613236427307129e+00
    phi[5,6]  R2196     -1.7517188787460327e+00
    phi[5,6]  R2197     -2.1298215389251709e+00
    phi[5,6]  R2198     -3.2870280742645264e+00
    phi[5,6]  R2199     -9.7438961267471313e-01
    phi[5,6]  R2200     -2.7779674530029297e-01
    phi[5,6]  R2201     -2.0701606273651123e+00
    phi[5,6]  R2202     -2.3292255401611328e+00
    phi[5,6]  R2203     9.4946539402008057e-01
    phi[5,6]  R2204     1.8398620188236237e-01
    phi[5,6]  R2205     0.932320237159729
    phi[5,6]  R2206     6.0062843561172485e-01
    phi[5,6]  R2207     -8.7959128618240356e-01
    phi[5,6]  R2208     4.4389379024505615e-01
    phi[5,6]  R2209     3.7365925312042236e-01
    phi[5,6]  R2210     -6.9503772258758545e-01
    phi[5,6]  R2211     -2.1756041049957275e+00
    phi[5,6]  R2212     -1.3422195911407471e+00
    phi[5,6]  R2213     6.5806359052658081e-01
    phi[5,6]  R2214     -1.8851649761199951e+00
    phi[5,6]  R2215     -1.2332965135574341e+00
    phi[5,6]  R2216     -3.0893158912658691e-01
    phi[5,6]  R2217     -3.0962789058685303e+00
    phi[5,6]  R2218     -1.3021374940872192e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2219     -3.0999999046325684e+00
    phi[6,5]  R2220     -3.0999999046325684e+00
    phi[6,5]  R2221     -2.2400000095367432e+00
    phi[6,5]  R2222     -2.2400000095367432e+00
    phi[6,5]  R2223     -3.0999999046325684e+00
    phi[6,5]  R2224     -3.0999999046325684e+00
    phi[6,5]  R2225     -2.5699999332427979e+00
    phi[6,5]  R2226     -2.5699999332427979e+00
    phi[6,5]  R2227     -3.0999999046325684e+00
    phi[6,5]  R2228     -3.0999999046325684e+00
    phi[6,5]  R2229     -2.0899999141693115e+00
    phi[6,5]  R2230     -2.0899999141693115e+00
    phi[6,5]  R2231     -3.0999999046325684e+00
    phi[6,5]  R2232     -3.0999999046325684e+00
    phi[6,5]  R2233     7.1006518602371216e-01
    phi[6,5]  R2234     8.9362072944641113e-01
    phi[6,5]  R2235     -2.6304274797439575e-04
    phi[6,5]  R2236     -7.2472828626632690e-01
    phi[6,5]  R2237     1.4569396972656250e+00
    phi[6,5]  R2238     1.4274829626083374e+00
    phi[6,5]  R2239     1.9080957174301147e+00
    phi[6,5]  R2240     -3.1568434834480286e-01
    phi[6,5]  R2241     -5.7496017217636108e-01
    phi[6,5]  R2242     1.1733049154281616e+00
    phi[6,5]  R2243     -1.2986304759979248e+00
    phi[6,5]  R2244     -2.5701576471328735e-01
    phi[6,5]  R2245     2.6179161667823792e-01
    phi[6,5]  R2246     -2.2015528678894043e+00
    phi[6,5]  R2247     -2.1397325992584229e+00
    phi[6,5]  R2248     -1.9427852630615234e+00
    phi[6,5]  R2249     2.6902338862419128e-01
    phi[6,5]  R2250     -2.8015897274017334e+00
    phi[6,5]  R2251     2.1780595779418945e+00
    phi[6,5]  R2252     -1.2803990840911865e+00
    phi[6,5]  R2253     -2.3639614880084991e-01
    phi[6,5]  R2254     -1.2944108247756958e+00
    phi[6,5]  R2255     -1.4041055440902710e+00
    phi[6,5]  R2256     -2.6837801933288574e+00
    phi[6,5]  R2257     -3.3820278644561768e+00
    phi[6,5]  R2258     -1.1221339702606201e+00
    phi[6,5]  R2259     -2.0613236427307129e+00
    phi[6,5]  R2260     -1.7517188787460327e+00
    phi[6,5]  R2261     -2.1298215389251709e+00
    phi[6,5]  R2262     -3.2870280742645264e+00
    phi[6,5]  R2263     -9.7438961267471313e-01
    phi[6,5]  R2264     -2.7779674530029297e-01
    phi[6,5]  R2265     -2.0701606273651123e+00
    phi[6,5]  R2266     -2.3292255401611328e+00
    phi[6,5]  R2267     9.4946539402008057e-01
    phi[6,5]  R2268     1.8398620188236237e-01
    phi[6,5]  R2269     0.932320237159729
    phi[6,5]  R2270     6.0062843561172485e-01
    phi[6,5]  R2271     -8.7959128618240356e-01
    phi[6,5]  R2272     4.4389379024505615e-01
    phi[6,5]  R2273     3.7365925312042236e-01
    phi[6,5]  R2274     -6.9503772258758545e-01
    phi[6,5]  R2275     -2.1756041049957275e+00
    phi[6,5]  R2276     -1.3422195911407471e+00
    phi[6,5]  R2277     6.5806359052658081e-01
    phi[6,5]  R2278     -1.8851649761199951e+00
    phi[6,5]  R2279     -1.2332965135574341e+00
    phi[6,5]  R2280     -3.0893158912658691e-01
    phi[6,5]  R2281     -3.0962789058685303e+00
    phi[6,5]  R2282     -1.3021374940872192e+00
    phi[6,5]  R2283     -0.618039608001709
    phi[6,5]  R2284     1.2384635210037231e+00
    phi[6,5]  R2285     1.2009190320968628e+00
    phi[6,5]  R2286     2.2980306148529053e+00
    phi[6,5]  R2287     6.8003827333450317e-01
    phi[6,5]  R2288     -1.9158256053924561e+00
    phi[6,5]  R2289     6.1235660314559937e-01
    phi[6,5]  R2290     -1.5051623582839966e+00
    phi[6,5]  R2291     -1.8261150121688843e+00
    phi[6,5]  R2292     4.5234224200248718e-01
    phi[6,5]  R2293     -1.4219955205917358e+00
    phi[6,5]  R2294     -1.8751188516616821e+00
    phi[6,5]  R2295     1.4069317579269409e+00
    phi[6,5]  R2296     9.3102663755416870e-02
    phi[6,5]  R2297     7.2135728597640991e-01
    phi[6,5]  R2298     -5.4492145776748657e-01
    phi[6,5]  R2299     -2.2762084007263184e+00
    phi[6,5]  R2300     -1.3509545326232910e+00
    phi[6,5]  R2301     -4.9528825283050537e-01
    phi[6,5]  R2302     1.3559268712997437e+00
    phi[6,5]  R2303     1.2898880243301392e+00
    phi[6,5]  R2304     -3.6097741127014160e-01
    phi[6,5]  R2305     -1.5508773326873779e+00
    phi[6,5]  R2306     -5.9530276060104370e-01
    phi[6,5]  R2307     5.7704550027847290e-01
    phi[6,5]  R2308     -1.0415625572204590e+00
    phi[6,5]  R2309     -1.2070719003677368e+00
    phi[6,5]  R2310     -5.1577007770538330e-01
    phi[6,5]  R2311     -1.4303536415100098e+00
    phi[6,5]  R2312     -2.0272398367524147e-02
    phi[6,5]  R2313     -6.1094999313354492e-01
    phi[6,5]  R2314     3.7742918729782104e-01
    phi[6,5]  R2315     -1.1045762300491333e+00
    phi[6,5]  R2316     -1.6322221755981445e+00
    phi[6,5]  R2317     -3.7021777033805847e-01
    phi[6,5]  R2318     -1.85337495803833
    phi[6,5]  R2319     -2.3583102226257324e+00
    phi[6,5]  R2320     -8.7704420089721680e-01
    phi[6,5]  R2321     -8.7660294771194458e-01
    phi[6,5]  R2322     -1.5302660465240479e+00
    phi[6,5]  R2323     -4.9395978450775146e-01
    phi[6,5]  R2324     -1.8319665193557739e+00
    phi[6,5]  R2325     -9.4045169651508331e-02
    phi[6,5]  R2326     -1.6604487895965576e+00
    phi[6,5]  R2327     -1.6271107196807861e+00
    phi[6,5]  R2328     -1.9775663614273071e+00
    phi[6,5]  R2329     -2.1356398239731789e-02
    phi[6,5]  R2330     -4.1763834655284882e-02
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2331     -3.0999999046325684e+00
    phi[6,7]  R2332     -3.0999999046325684e+00
    phi[6,7]  R2333     -2.2400000095367432e+00
    phi[6,7]  R2334     -2.2400000095367432e+00
    phi[6,7]  R2335     -3.0999999046325684e+00
    phi[6,7]  R2336     -3.0999999046325684e+00
    phi[6,7]  R2337     -2.5699999332427979e+00
    phi[6,7]  R2338     -2.5699999332427979e+00
    phi[6,7]  R2339     -3.0999999046325684e+00
    phi[6,7]  R2340     -3.0999999046325684e+00
    phi[6,7]  R2341     -2.0899999141693115e+00
    phi[6,7]  R2342     -2.0899999141693115e+00
    phi[6,7]  R2343     -3.0999999046325684e+00
    phi[6,7]  R2344     -3.0999999046325684e+00
    phi[6,7]  R2345     7.1006518602371216e-01
    phi[6,7]  R2346     8.9362072944641113e-01
    phi[6,7]  R2347     -2.6304274797439575e-04
    phi[6,7]  R2348     -7.2472828626632690e-01
    phi[6,7]  R2349     1.4569396972656250e+00
    phi[6,7]  R2350     1.4274829626083374e+00
    phi[6,7]  R2351     1.9080957174301147e+00
    phi[6,7]  R2352     -3.1568434834480286e-01
    phi[6,7]  R2353     -5.7496017217636108e-01
    phi[6,7]  R2354     1.1733049154281616e+00
    phi[6,7]  R2355     -1.2986304759979248e+00
    phi[6,7]  R2356     -2.5701576471328735e-01
    phi[6,7]  R2357     2.6179161667823792e-01
    phi[6,7]  R2358     -2.2015528678894043e+00
    phi[6,7]  R2359     -2.1397325992584229e+00
    phi[6,7]  R2360     -1.9427852630615234e+00
    phi[6,7]  R2361     2.6902338862419128e-01
    phi[6,7]  R2362     -2.8015897274017334e+00
    phi[6,7]  R2363     2.1780595779418945e+00
    phi[6,7]  R2364     -1.2803990840911865e+00
    phi[6,7]  R2365     -2.3639614880084991e-01
    phi[6,7]  R2366     -1.2944108247756958e+00
    phi[6,7]  R2367     -1.4041055440902710e+00
    phi[6,7]  R2368     -2.6837801933288574e+00
    phi[6,7]  R2369     -3.3820278644561768e+00
    phi[6,7]  R2370     -1.1221339702606201e+00
    phi[6,7]  R2371     -2.0613236427307129e+00
    phi[6,7]  R2372     -1.7517188787460327e+00
    phi[6,7]  R2373     -2.1298215389251709e+00
    phi[6,7]  R2374     -3.2870280742645264e+00
    phi[6,7]  R2375     -9.7438961267471313e-01
    phi[6,7]  R2376     -2.7779674530029297e-01
    phi[6,7]  R2377     -2.0701606273651123e+00
    phi[6,7]  R2378     -2.3292255401611328e+00
    phi[6,7]  R2379     9.4946539402008057e-01
    phi[6,7]  R2380     1.8398620188236237e-01
    phi[6,7]  R2381     0.932320237159729
    phi[6,7]  R2382     6.0062843561172485e-01
    phi[6,7]  R2383     -8.7959128618240356e-01
    phi[6,7]  R2384     4.4389379024505615e-01
    phi[6,7]  R2385     3.7365925312042236e-01
    phi[6,7]  R2386     -6.9503772258758545e-01
    phi[6,7]  R2387     -2.1756041049957275e+00
    phi[6,7]  R2388     -1.3422195911407471e+00
    phi[6,7]  R2389     6.5806359052658081e-01
    phi[6,7]  R2390     -1.8851649761199951e+00
    phi[6,7]  R2391     -1.2332965135574341e+00
    phi[6,7]  R2392     -3.0893158912658691e-01
    phi[6,7]  R2393     -3.0962789058685303e+00
    phi[6,7]  R2394     -1.3021374940872192e+00
    phi[6,7]  R2395     1.8877326250076294e+00
    phi[6,7]  R2396     2.4902992248535156e+00
    phi[6,7]  R2397     1.3979263305664062e+00
    phi[6,7]  R2398     1.7726165056228638e+00
    phi[6,7]  R2399     0.897317111492157
    phi[6,7]  R2400     1.2070739269256592e+00
    phi[6,7]  R2401     1.6141772270202637e+00
    phi[6,7]  R2402     2.7527064085006714e-01
    phi[6,7]  R2403     9.1237914562225342e-01
    phi[6,7]  R2404     4.2508375644683838e-01
    phi[6,7]  R2405     -1.4387768507003784e+00
    phi[6,7]  R2406     -9.6690398454666138e-01
    phi[6,7]  R2407     6.2956625223159790e-01
    phi[6,7]  R2408     -1.9422986507415771e+00
    phi[6,7]  R2409     -1.6858065128326416e+00
    phi[6,7]  R2410     -5.7946896553039551e-01
    phi[6,7]  R2411     -8.2615214586257935e-01
    phi[6,7]  R2412     -6.0905653238296509e-01
    phi[6,7]  R2413     -2.1531448364257812e+00
    phi[6,7]  R2414     -3.1135287284851074e+00
    phi[6,7]  R2415     -1.8449470996856689e+00
    phi[6,7]  R2416     -9.9106812477111816e-01
    phi[6,7]  R2417     -9.7013485431671143e-01
    phi[6,7]  R2418     5.1104009151458740e-01
    phi[6,7]  R2419     3.0847355723381042e-01
    phi[6,7]  R2420     -1.5185298919677734e+00
    phi[6,7]  R2421     9.1935470700263977e-02
    phi[6,7]  R2422     -8.9312058687210083e-01
    phi[6,7]  R2423     -1.3974380493164062e+00
    phi[6,7]  R2424     -7.2802287340164185e-01
    phi[6,7]  R2425     -5.3387045860290527e-01
    phi[6,7]  R2426     -1.8758782148361206e+00
    phi[6,7]  R2427     7.4206769466400146e-01
    phi[6,7]  R2428     -1.8638120591640472e-01
    phi[6,7]  R2429     1.0242608189582825e-01
    phi[6,7]  R2430     1.4591467380523682e+00
    phi[6,7]  R2431     2.5358468294143677e-01
    phi[6,7]  R2432     0.093849778175354
    phi[6,7]  R2433     1.6369804739952087e-01
    phi[6,7]  R2434     5.5032569169998169e-01
    phi[6,7]  R2435     -6.9657552242279053e-01
    phi[6,7]  R2436     -1.8980673551559448e+00
    phi[6,7]  R2437     -9.8858565092086792e-01
    phi[6,7]  R2438     1.4691779613494873e+00
    phi[6,7]  R2439     -9.7031068801879883e-01
    phi[6,7]  R2440     3.0049237608909607e-01
    phi[6,7]  R2441     -1.5849580764770508e+00
    phi[6,7]  R2442     -1.1887344121932983e+00
    phi[6,7]  R2443     -0.544943630695343
    phi[6,7]  R2444     -1.2424132823944092e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2445     -3.0999999046325684e+00
    phi[7,6]  R2446     -3.0999999046325684e+00
    phi[7,6]  R2447     -2.2400000095367432e+00
    phi[7,6]  R2448     -2.2400000095367432e+00
    phi[7,6]  R2449     -3.0999999046325684e+00
    phi[7,6]  R2450     -3.0999999046325684e+00
    phi[7,6]  R2451     -2.5699999332427979e+00
    phi[7,6]  R2452     -2.5699999332427979e+00
    phi[7,6]  R2453     -3.0999999046325684e+00
    phi[7,6]  R2454     -3.0999999046325684e+00
    phi[7,6]  R2455     -2.0899999141693115e+00
    phi[7,6]  R2456     -2.0899999141693115e+00
    phi[7,6]  R2457     -3.0999999046325684e+00
    phi[7,6]  R2458     -3.0999999046325684e+00
    phi[7,6]  R2459     1.8877326250076294e+00
    phi[7,6]  R2460     2.4902992248535156e+00
    phi[7,6]  R2461     1.3979263305664062e+00
    phi[7,6]  R2462     1.7726165056228638e+00
    phi[7,6]  R2463     0.897317111492157
    phi[7,6]  R2464     1.2070739269256592e+00
    phi[7,6]  R2465     1.6141772270202637e+00
    phi[7,6]  R2466     2.7527064085006714e-01
    phi[7,6]  R2467     9.1237914562225342e-01
    phi[7,6]  R2468     4.2508375644683838e-01
    phi[7,6]  R2469     -1.4387768507003784e+00
    phi[7,6]  R2470     -9.6690398454666138e-01
    phi[7,6]  R2471     6.2956625223159790e-01
    phi[7,6]  R2472     -1.9422986507415771e+00
    phi[7,6]  R2473     -1.6858065128326416e+00
    phi[7,6]  R2474     -5.7946896553039551e-01
    phi[7,6]  R2475     -8.2615214586257935e-01
    phi[7,6]  R2476     -6.0905653238296509e-01
    phi[7,6]  R2477     -2.1531448364257812e+00
    phi[7,6]  R2478     -3.1135287284851074e+00
    phi[7,6]  R2479     -1.8449470996856689e+00
    phi[7,6]  R2480     -9.9106812477111816e-01
    phi[7,6]  R2481     -9.7013485431671143e-01
    phi[7,6]  R2482     5.1104009151458740e-01
    phi[7,6]  R2483     3.0847355723381042e-01
    phi[7,6]  R2484     -1.5185298919677734e+00
    phi[7,6]  R2485     9.1935470700263977e-02
    phi[7,6]  R2486     -8.9312058687210083e-01
    phi[7,6]  R2487     -1.3974380493164062e+00
    phi[7,6]  R2488     -7.2802287340164185e-01
    phi[7,6]  R2489     -5.3387045860290527e-01
    phi[7,6]  R2490     -1.8758782148361206e+00
    phi[7,6]  R2491     7.4206769466400146e-01
    phi[7,6]  R2492     -1.8638120591640472e-01
    phi[7,6]  R2493     1.0242608189582825e-01
    phi[7,6]  R2494     1.4591467380523682e+00
    phi[7,6]  R2495     2.5358468294143677e-01
    phi[7,6]  R2496     0.093849778175354
    phi[7,6]  R2497     1.6369804739952087e-01
    phi[7,6]  R2498     5.5032569169998169e-01
    phi[7,6]  R2499     -6.9657552242279053e-01
    phi[7,6]  R2500     -1.8980673551559448e+00
    phi[7,6]  R2501     -9.8858565092086792e-01
    phi[7,6]  R2502     1.4691779613494873e+00
    phi[7,6]  R2503     -9.7031068801879883e-01
    phi[7,6]  R2504     3.0049237608909607e-01
    phi[7,6]  R2505     -1.5849580764770508e+00
    phi[7,6]  R2506     -1.1887344121932983e+00
    phi[7,6]  R2507     -0.544943630695343
    phi[7,6]  R2508     -1.2424132823944092e+00
    phi[7,6]  R2509     7.1006518602371216e-01
    phi[7,6]  R2510     8.9362072944641113e-01
    phi[7,6]  R2511     -2.6304274797439575e-04
    phi[7,6]  R2512     -7.2472828626632690e-01
    phi[7,6]  R2513     1.4569396972656250e+00
    phi[7,6]  R2514     1.4274829626083374e+00
    phi[7,6]  R2515     1.9080957174301147e+00
    phi[7,6]  R2516     -3.1568434834480286e-01
    phi[7,6]  R2517     -5.7496017217636108e-01
    phi[7,6]  R2518     1.1733049154281616e+00
    phi[7,6]  R2519     -1.2986304759979248e+00
    phi[7,6]  R2520     -2.5701576471328735e-01
    phi[7,6]  R2521     2.6179161667823792e-01
    phi[7,6]  R2522     -2.2015528678894043e+00
    phi[7,6]  R2523     -2.1397325992584229e+00
    phi[7,6]  R2524     -1.9427852630615234e+00
    phi[7,6]  R2525     2.6902338862419128e-01
    phi[7,6]  R2526     -2.8015897274017334e+00
    phi[7,6]  R2527     2.1780595779418945e+00
    phi[7,6]  R2528     -1.2803990840911865e+00
    phi[7,6]  R2529     -2.3639614880084991e-01
    phi[7,6]  R2530     -1.2944108247756958e+00
    phi[7,6]  R2531     -1.4041055440902710e+00
    phi[7,6]  R2532     -2.6837801933288574e+00
    phi[7,6]  R2533     -3.3820278644561768e+00
    phi[7,6]  R2534     -1.1221339702606201e+00
    phi[7,6]  R2535     -2.0613236427307129e+00
    phi[7,6]  R2536     -1.7517188787460327e+00
    phi[7,6]  R2537     -2.1298215389251709e+00
    phi[7,6]  R2538     -3.2870280742645264e+00
    phi[7,6]  R2539     -9.7438961267471313e-01
    phi[7,6]  R2540     -2.7779674530029297e-01
    phi[7,6]  R2541     -2.0701606273651123e+00
    phi[7,6]  R2542     -2.3292255401611328e+00
    phi[7,6]  R2543     9.4946539402008057e-01
    phi[7,6]  R2544     1.8398620188236237e-01
    phi[7,6]  R2545     0.932320237159729
    phi[7,6]  R2546     6.0062843561172485e-01
    phi[7,6]  R2547     -8.7959128618240356e-01
    phi[7,6]  R2548     4.4389379024505615e-01
    phi[7,6]  R2549     3.7365925312042236e-01
    phi[7,6]  R2550     -6.9503772258758545e-01
    phi[7,6]  R2551     -2.1756041049957275e+00
    phi[7,6]  R2552     -1.3422195911407471e+00
    phi[7,6]  R2553     6.5806359052658081e-01
    phi[7,6]  R2554     -1.8851649761199951e+00
    phi[7,6]  R2555     -1.2332965135574341e+00
    phi[7,6]  R2556     -3.0893158912658691e-01
    phi[7,6]  R2557     -3.0962789058685303e+00
    phi[7,6]  R2558     -1.3021374940872192e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2559     -3.0999999046325684e+00
    phi[7,8]  R2560     -3.0999999046325684e+00
    phi[7,8]  R2561     -2.2400000095367432e+00
    phi[7,8]  R2562     -2.2400000095367432e+00
    phi[7,8]  R2563     -3.0999999046325684e+00
    phi[7,8]  R2564     -3.0999999046325684e+00
    phi[7,8]  R2565     -2.5699999332427979e+00
    phi[7,8]  R2566     -2.5699999332427979e+00
    phi[7,8]  R2567     -3.0999999046325684e+00
    phi[7,8]  R2568     -3.0999999046325684e+00
    phi[7,8]  R2569     -2.0899999141693115e+00
    phi[7,8]  R2570     -2.0899999141693115e+00
    phi[7,8]  R2571     -3.0999999046325684e+00
    phi[7,8]  R2572     -3.0999999046325684e+00
    phi[7,8]  R2573     1.8877326250076294e+00
    phi[7,8]  R2574     2.4902992248535156e+00
    phi[7,8]  R2575     1.3979263305664062e+00
    phi[7,8]  R2576     1.7726165056228638e+00
    phi[7,8]  R2577     0.897317111492157
    phi[7,8]  R2578     1.2070739269256592e+00
    phi[7,8]  R2579     1.6141772270202637e+00
    phi[7,8]  R2580     2.7527064085006714e-01
    phi[7,8]  R2581     9.1237914562225342e-01
    phi[7,8]  R2582     4.2508375644683838e-01
    phi[7,8]  R2583     -1.4387768507003784e+00
    phi[7,8]  R2584     -9.6690398454666138e-01
    phi[7,8]  R2585     6.2956625223159790e-01
    phi[7,8]  R2586     -1.9422986507415771e+00
    phi[7,8]  R2587     -1.6858065128326416e+00
    phi[7,8]  R2588     -5.7946896553039551e-01
    phi[7,8]  R2589     -8.2615214586257935e-01
    phi[7,8]  R2590     -6.0905653238296509e-01
    phi[7,8]  R2591     -2.1531448364257812e+00
    phi[7,8]  R2592     -3.1135287284851074e+00
    phi[7,8]  R2593     -1.8449470996856689e+00
    phi[7,8]  R2594     -9.9106812477111816e-01
    phi[7,8]  R2595     -9.7013485431671143e-01
    phi[7,8]  R2596     5.1104009151458740e-01
    phi[7,8]  R2597     3.0847355723381042e-01
    phi[7,8]  R2598     -1.5185298919677734e+00
    phi[7,8]  R2599     9.1935470700263977e-02
    phi[7,8]  R2600     -8.9312058687210083e-01
    phi[7,8]  R2601     -1.3974380493164062e+00
    phi[7,8]  R2602     -7.2802287340164185e-01
    phi[7,8]  R2603     -5.3387045860290527e-01
    phi[7,8]  R2604     -1.8758782148361206e+00
    phi[7,8]  R2605     7.4206769466400146e-01
    phi[7,8]  R2606     -1.8638120591640472e-01
    phi[7,8]  R2607     1.0242608189582825e-01
    phi[7,8]  R2608     1.4591467380523682e+00
    phi[7,8]  R2609     2.5358468294143677e-01
    phi[7,8]  R2610     0.093849778175354
    phi[7,8]  R2611     1.6369804739952087e-01
    phi[7,8]  R2612     5.5032569169998169e-01
    phi[7,8]  R2613     -6.9657552242279053e-01
    phi[7,8]  R2614     -1.8980673551559448e+00
    phi[7,8]  R2615     -9.8858565092086792e-01
    phi[7,8]  R2616     1.4691779613494873e+00
    phi[7,8]  R2617     -9.7031068801879883e-01
    phi[7,8]  R2618     3.0049237608909607e-01
    phi[7,8]  R2619     -1.5849580764770508e+00
    phi[7,8]  R2620     -1.1887344121932983e+00
    phi[7,8]  R2621     -0.544943630695343
    phi[7,8]  R2622     -1.2424132823944092e+00
    phi[7,8]  R2623     2.9574358463287354e+00
    phi[7,8]  R2624     1.7678208351135254e+00
    phi[7,8]  R2625     2.7716984748840332e+00
    phi[7,8]  R2626     3.1057813167572021e+00
    phi[7,8]  R2627     2.5503857135772705e+00
    phi[7,8]  R2628     2.61163330078125
    phi[7,8]  R2629     2.2297563552856445e+00
    phi[7,8]  R2630     2.9782485961914062e+00
    phi[7,8]  R2631     3.6897568702697754e+00
    phi[7,8]  R2632     1.3750586509704590e+00
    phi[7,8]  R2633     -1.8856845796108246e-01
    phi[7,8]  R2634     1.5766894817352295e-01
    phi[7,8]  R2635     2.1403953433036804e-01
    phi[7,8]  R2636     -2.4956189095973969e-01
    phi[7,8]  R2637     6.7220932245254517e-01
    phi[7,8]  R2638     8.7469440698623657e-01
    phi[7,8]  R2639     1.3135534524917603e+00
    phi[7,8]  R2640     -1.9691134691238403e+00
    phi[7,8]  R2641     -1.7854479551315308e+00
    phi[7,8]  R2642     -9.6085512638092041e-01
    phi[7,8]  R2643     -3.1859538555145264e+00
    phi[7,8]  R2644     -1.9135022163391113e+00
    phi[7,8]  R2645     -7.1398347616195679e-01
    phi[7,8]  R2646     8.1113380193710327e-01
    phi[7,8]  R2647     -1.7607040405273438e+00
    phi[7,8]  R2648     -2.2081685066223145e+00
    phi[7,8]  R2649     -1.2687575817108154e+00
    phi[7,8]  R2650     -2.1916414797306061e-01
    phi[7,8]  R2651     -0.849112868309021
    phi[7,8]  R2652     -2.0379360020160675e-01
    phi[7,8]  R2653     -8.7801367044448853e-01
    phi[7,8]  R2654     7.2806692123413086e-01
    phi[7,8]  R2655     -2.9329149723052979e+00
    phi[7,8]  R2656     -1.4825030565261841e+00
    phi[7,8]  R2657     5.8833771944046021e-01
    phi[7,8]  R2658     -2.6530566215515137e+00
    phi[7,8]  R2659     -2.5690624713897705e+00
    phi[7,8]  R2660     -4.2340865135192871e+00
    phi[7,8]  R2661     -2.0677442550659180e+00
    phi[7,8]  R2662     -2.2118999958038330e+00
    phi[7,8]  R2663     -1.9137452840805054e+00
    phi[7,8]  R2664     -1.5108398199081421e+00
    phi[7,8]  R2665     1.3819980621337891e-01
    phi[7,8]  R2666     -1.3166280984878540e+00
    phi[7,8]  R2667     1.0300825834274292e+00
    phi[7,8]  R2668     0.884740948677063
    phi[7,8]  R2669     -2.3961904048919678e+00
    phi[7,8]  R2670     -1.5462066233158112e-01
    phi[7,8]  R2671     4.1079449653625488e-01
    phi[7,8]  R2672     -1.5275092124938965e+00
    phi[7,8]  R2673     -1.4849309921264648e+00
    phi[7,8]  R2674     -1.2991361618041992e+00
    phi[7,8]  R2675     -8.7873870134353638e-01
    phi[7,8]  R2676     -1.2331010103225708e+00
    phi[7,8]  R2677     -1.2191474437713623e+00
    phi[7,8]  R2678     -6.2540876865386963e-01
    phi[7,8]  R2679     -2.2967813014984131e+00
    phi[7,8]  R2680     1.7855854332447052e-01
    phi[7,8]  R2681     -1.0451027154922485e+00
    phi[7,8]  R2682     -1.4284933805465698e+00
    phi[7,8]  R2683     9.2354410886764526e-01
    phi[7,8]  R2684     -2.9172709584236145e-01
    phi[7,8]  R2685     -1.0273895263671875e+00
    phi[7,8]  R2686     -1.9816323518753052e+00
    phi[7,8]  R2687     -1.96592116355896
    phi[7,8]  R2688     -1.6121990680694580e+00
    phi[7,8]  R2689     -2.6360912322998047e+00
    phi[7,8]  R2690     -4.0716147422790527e+00
    phi[7,8]  R2691     -2.9305608272552490e+00
    phi[7,8]  R2692     -2.7916069030761719e+00
    phi[7,8]  R2693     -0.976621150970459
    phi[7,8]  R2694     -2.4576604366302490e+00
    phi[7,8]  R2695     -1.5908827781677246e+00
    phi[7,8]  R2696     -3.1188192367553711e+00
    phi[7,8]  R2697     -2.5783686637878418e+00
    phi[7,8]  R2698     -3.8530991077423096e+00
    phi[7,8]  R2699     -3.0460712909698486e+00
    phi[7,8]  R2700     -3.0901267528533936e+00
    phi[7,8]  R2701     1.2197611331939697e+00
    phi[7,8]  R2702     -3.8949646949768066e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2703     -3.0999999046325684e+00
    phi[8,7]  R2704     -3.0999999046325684e+00
    phi[8,7]  R2705     -2.2400000095367432e+00
    phi[8,7]  R2706     -2.2400000095367432e+00
    phi[8,7]  R2707     -3.0999999046325684e+00
    phi[8,7]  R2708     -3.0999999046325684e+00
    phi[8,7]  R2709     -2.5699999332427979e+00
    phi[8,7]  R2710     -2.5699999332427979e+00
    phi[8,7]  R2711     -3.0999999046325684e+00
    phi[8,7]  R2712     -3.0999999046325684e+00
    phi[8,7]  R2713     -2.0899999141693115e+00
    phi[8,7]  R2714     -2.0899999141693115e+00
    phi[8,7]  R2715     -3.0999999046325684e+00
    phi[8,7]  R2716     -3.0999999046325684e+00
    phi[8,7]  R2717     2.9574358463287354e+00
    phi[8,7]  R2718     1.7678208351135254e+00
    phi[8,7]  R2719     2.7716984748840332e+00
    phi[8,7]  R2720     3.1057813167572021e+00
    phi[8,7]  R2721     2.5503857135772705e+00
    phi[8,7]  R2722     2.61163330078125
    phi[8,7]  R2723     2.2297563552856445e+00
    phi[8,7]  R2724     2.9782485961914062e+00
    phi[8,7]  R2725     3.6897568702697754e+00
    phi[8,7]  R2726     1.3750586509704590e+00
    phi[8,7]  R2727     -1.8856845796108246e-01
    phi[8,7]  R2728     1.5766894817352295e-01
    phi[8,7]  R2729     2.1403953433036804e-01
    phi[8,7]  R2730     -2.4956189095973969e-01
    phi[8,7]  R2731     6.7220932245254517e-01
    phi[8,7]  R2732     8.7469440698623657e-01
    phi[8,7]  R2733     1.3135534524917603e+00
    phi[8,7]  R2734     -1.9691134691238403e+00
    phi[8,7]  R2735     -1.7854479551315308e+00
    phi[8,7]  R2736     -9.6085512638092041e-01
    phi[8,7]  R2737     -3.1859538555145264e+00
    phi[8,7]  R2738     -1.9135022163391113e+00
    phi[8,7]  R2739     -7.1398347616195679e-01
    phi[8,7]  R2740     8.1113380193710327e-01
    phi[8,7]  R2741     -1.7607040405273438e+00
    phi[8,7]  R2742     -2.2081685066223145e+00
    phi[8,7]  R2743     -1.2687575817108154e+00
    phi[8,7]  R2744     -2.1916414797306061e-01
    phi[8,7]  R2745     -0.849112868309021
    phi[8,7]  R2746     -2.0379360020160675e-01
    phi[8,7]  R2747     -8.7801367044448853e-01
    phi[8,7]  R2748     7.2806692123413086e-01
    phi[8,7]  R2749     -2.9329149723052979e+00
    phi[8,7]  R2750     -1.4825030565261841e+00
    phi[8,7]  R2751     5.8833771944046021e-01
    phi[8,7]  R2752     -2.6530566215515137e+00
    phi[8,7]  R2753     -2.5690624713897705e+00
    phi[8,7]  R2754     -4.2340865135192871e+00
    phi[8,7]  R2755     -2.0677442550659180e+00
    phi[8,7]  R2756     -2.2118999958038330e+00
    phi[8,7]  R2757     -1.9137452840805054e+00
    phi[8,7]  R2758     -1.5108398199081421e+00
    phi[8,7]  R2759     1.3819980621337891e-01
    phi[8,7]  R2760     -1.3166280984878540e+00
    phi[8,7]  R2761     1.0300825834274292e+00
    phi[8,7]  R2762     0.884740948677063
    phi[8,7]  R2763     -2.3961904048919678e+00
    phi[8,7]  R2764     -1.5462066233158112e-01
    phi[8,7]  R2765     4.1079449653625488e-01
    phi[8,7]  R2766     -1.5275092124938965e+00
    phi[8,7]  R2767     -1.4849309921264648e+00
    phi[8,7]  R2768     -1.2991361618041992e+00
    phi[8,7]  R2769     -8.7873870134353638e-01
    phi[8,7]  R2770     -1.2331010103225708e+00
    phi[8,7]  R2771     -1.2191474437713623e+00
    phi[8,7]  R2772     -6.2540876865386963e-01
    phi[8,7]  R2773     -2.2967813014984131e+00
    phi[8,7]  R2774     1.7855854332447052e-01
    phi[8,7]  R2775     -1.0451027154922485e+00
    phi[8,7]  R2776     -1.4284933805465698e+00
    phi[8,7]  R2777     9.2354410886764526e-01
    phi[8,7]  R2778     -2.9172709584236145e-01
    phi[8,7]  R2779     -1.0273895263671875e+00
    phi[8,7]  R2780     -1.9816323518753052e+00
    phi[8,7]  R2781     -1.96592116355896
    phi[8,7]  R2782     -1.6121990680694580e+00
    phi[8,7]  R2783     -2.6360912322998047e+00
    phi[8,7]  R2784     -4.0716147422790527e+00
    phi[8,7]  R2785     -2.9305608272552490e+00
    phi[8,7]  R2786     -2.7916069030761719e+00
    phi[8,7]  R2787     -0.976621150970459
    phi[8,7]  R2788     -2.4576604366302490e+00
    phi[8,7]  R2789     -1.5908827781677246e+00
    phi[8,7]  R2790     -3.1188192367553711e+00
    phi[8,7]  R2791     -2.5783686637878418e+00
    phi[8,7]  R2792     -3.8530991077423096e+00
    phi[8,7]  R2793     -3.0460712909698486e+00
    phi[8,7]  R2794     -3.0901267528533936e+00
    phi[8,7]  R2795     1.2197611331939697e+00
    phi[8,7]  R2796     -3.8949646949768066e+00
    phi[8,7]  R2797     1.8877326250076294e+00
    phi[8,7]  R2798     2.4902992248535156e+00
    phi[8,7]  R2799     1.3979263305664062e+00
    phi[8,7]  R2800     1.7726165056228638e+00
    phi[8,7]  R2801     0.897317111492157
    phi[8,7]  R2802     1.2070739269256592e+00
    phi[8,7]  R2803     1.6141772270202637e+00
    phi[8,7]  R2804     2.7527064085006714e-01
    phi[8,7]  R2805     9.1237914562225342e-01
    phi[8,7]  R2806     4.2508375644683838e-01
    phi[8,7]  R2807     -1.4387768507003784e+00
    phi[8,7]  R2808     -9.6690398454666138e-01
    phi[8,7]  R2809     6.2956625223159790e-01
    phi[8,7]  R2810     -1.9422986507415771e+00
    phi[8,7]  R2811     -1.6858065128326416e+00
    phi[8,7]  R2812     -5.7946896553039551e-01
    phi[8,7]  R2813     -8.2615214586257935e-01
    phi[8,7]  R2814     -6.0905653238296509e-01
    phi[8,7]  R2815     -2.1531448364257812e+00
    phi[8,7]  R2816     -3.1135287284851074e+00
    phi[8,7]  R2817     -1.8449470996856689e+00
    phi[8,7]  R2818     -9.9106812477111816e-01
    phi[8,7]  R2819     -9.7013485431671143e-01
    phi[8,7]  R2820     5.1104009151458740e-01
    phi[8,7]  R2821     3.0847355723381042e-01
    phi[8,7]  R2822     -1.5185298919677734e+00
    phi[8,7]  R2823     9.1935470700263977e-02
    phi[8,7]  R2824     -8.9312058687210083e-01
    phi[8,7]  R2825     -1.3974380493164062e+00
    phi[8,7]  R2826     -7.2802287340164185e-01
    phi[8,7]  R2827     -5.3387045860290527e-01
    phi[8,7]  R2828     -1.8758782148361206e+00
    phi[8,7]  R2829     7.4206769466400146e-01
    phi[8,7]  R2830     -1.8638120591640472e-01
    phi[8,7]  R2831     1.0242608189582825e-01
    phi[8,7]  R2832     1.4591467380523682e+00
    phi[8,7]  R2833     2.5358468294143677e-01
    phi[8,7]  R2834     0.093849778175354
    phi[8,7]  R2835     1.6369804739952087e-01
    phi[8,7]  R2836     5.5032569169998169e-01
    phi[8,7]  R2837     -6.9657552242279053e-01
    phi[8,7]  R2838     -1.8980673551559448e+00
    phi[8,7]  R2839     -9.8858565092086792e-01
    phi[8,7]  R2840     1.4691779613494873e+00
    phi[8,7]  R2841     -9.7031068801879883e-01
    phi[8,7]  R2842     3.0049237608909607e-01
    phi[8,7]  R2843     -1.5849580764770508e+00
    phi[8,7]  R2844     -1.1887344121932983e+00
    phi[8,7]  R2845     -0.544943630695343
    phi[8,7]  R2846     -1.2424132823944092e+00
    phi[8,10]  R72       1
    phi[8,10]  R73       1
    phi[8,10]  R74       2.1169342290670903e+00
    phi[8,10]  R75       1.4578004069282136e-01
    phi[8,10]  R76       2.7019429283681484e+00
    phi[8,10]  R77       -1.47339882112013
    phi[8,10]  R78       1.6277192221282757e+00
    phi[8,10]  R79       1.2967216847552172e+00
    phi[8,10]  R80       -2.4576673418323316e+00
    phi[8,10]  R82       -1
    phi[8,10]  R2847     -9.8306567556547808e-01
    phi[8,10]  R2848     -5.2169341336996586e+00
    phi[8,10]  R2849     -2.0942199688439218e+00
    phi[8,10]  R2850     -2.3857800502295645e+00
    phi[8,10]  R2851     -3.9805697626441994e-01
    phi[8,10]  R2852     -5.8019428330007168e+00
    phi[8,10]  R2853     -4.0433987543629275e+00
    phi[8,10]  R2854     -1.0966011121226678e+00
    phi[8,10]  R2855     -1.4722806825042927e+00
    phi[8,10]  R2856     -4.7277191267608440e+00
    phi[8,10]  R2857     -7.9327822941409432e-01
    phi[8,10]  R2858     -3.3867215989245287e+00
    phi[8,10]  R2859     -5.5576672464649
    phi[8,10]  R2860     -6.4233256280023676e-01
    phi[8,10]  R2861     -3.5546117168979352e-01
    phi[8,10]  R2862     -3.6121775622516550e-01
    phi[8,10]  R2863     -3.7096690897982487e-01
    phi[8,10]  R2864     -3.7399155925440919e-01
    phi[8,10]  R2865     -3.7629307193188755e-01
    phi[8,10]  R2866     -3.7734252279498737e-01
    phi[8,10]  R2867     -0.384738479009465
    phi[8,10]  R2868     -3.8574055047806644e-01
    phi[8,10]  R2869     -3.8616348813226775e-01
    phi[8,10]  R2870     -3.8827554882555759e-01
    phi[8,10]  R2871     -8.5544540674428227e-01
    phi[8,10]  R2872     -7.6483510598762949e-01
    phi[8,10]  R2873     -4.0843352389923249e-01
    phi[8,10]  R2874     -7.0426003576687968e-01
    phi[8,10]  R2875     -9.0918991552420181e-01
    phi[8,10]  R2876     -5.8033220780392947e-01
    phi[8,10]  R2877     -6.6152633231069369e-01
    phi[8,10]  R2878     -4.8320075848809085e-01
    phi[8,10]  R2879     -4.8419885611613056e-01
    phi[8,10]  R2880     -4.8870687336729057e-01
    phi[8,10]  R2881     -3.7004546441525843e-01
    phi[8,10]  R2882     -3.8396219851020974e-01
    phi[8,10]  R2883     -4.3067469673807168e-01
    phi[8,10]  R2884     -4.4062087044016751e-01
    phi[8,10]  R2885     -4.4141977087598439e-01
    phi[8,10]  R2886     -4.6802789042110859e-01
    phi[8,10]  R2887     -4.8090679982524087e-01
    phi[8,10]  R2888     -0.495338587921177
    phi[8,10]  R2889     -4.9862084965151143e-01
    phi[8,10]  R2890     -4.9878246810100979e-01
    phi[8,10]  R2891     -3.3726275901309077e-01
    phi[8,10]  R2892     -3.4723339171854173e-01
    phi[8,10]  R2893     -3.6609671574025215e-01
    phi[8,10]  R2894     -3.7468737909525607e-01
    phi[8,10]  R2895     -3.9794792663649114e-01
    phi[8,10]  R2896     -4.3389726490258562e-01
    phi[8,10]  R2897     -4.6737413336764888e-01
    phi[8,10]  R2898     -1.1882239405583004e+00
    phi[8,10]  R2899     -6.6596719853536857e-01
    phi[8,10]  R2900     -8.9166429819271942e-01
    phi[8,10]  R2901     -5.2358317029130030e-01
    phi[8,10]  R2902     -5.4573595299449007e-01
    phi[8,10]  R2903     -5.5077471621231811e-01
    phi[8,10]  R2904     -5.6835621102734868e-01
    phi[8,10]  R2905     -5.9580134871911761e-01
    phi[8,10]  R2906     -6.0965305037780793e-01
    phi[8,10]  R2907     -6.1175444716759020e-01
    phi[8,10]  R2908     -6.1459907719905382e-01
    phi[8,10]  R2909     -6.1629456617593292e-01
    phi[8,10]  R2910     -0.796311353252351
    phi[8,10]  R2911     -3.0657236449977354e-01
    phi[8,10]  R2912     -3.4143047038466923e-01
    phi[8,10]  R2913     -3.4847300903136713e-01
    phi[8,10]  R2914     -3.8717707759259778e-01
    phi[8,10]  R2915     -4.4917663747283054e-01
    phi[8,10]  R2916     -4.9915915761514684e-01
    phi[8,10]  R2917     -5.0161451037307137e-01
    phi[8,10]  R2918     -0.518898775747672
    phi[8,10]  R2919     -7.7732352665956361e-01
    phi[8,10]  R2920     -5.4377610660678122e-01
    phi[8,10]  R2921     -3.2550270670659076e-01
    phi[8,10]  R2922     -4.9430466582640831e-01
    phi[8,10]  R2923     -4.3008874910734884e-01
    phi[8,10]  R2924     -1.3655698230851927e+00
    phi[8,10]  R2925     -9.5738252166511129e-01
    phi[8,10]  R2926     -1.21706890760017
    phi[8,10]  R2927     -1.5701152884644261e+00
    phi[8,10]  R2928     -1.0300623798926121e+00
    phi[8,10]  R2929     -1.5155114799324603e+00
    phi[8,10]  R2930     -1.1480867528779131e+00
    phi[8,10]  R2931     -4.7158661801887114e-01
    phi[8,10]  R2932     -4.7737604935135924e-01
    phi[8,10]  R2933     -1.1661038875143794e+00
    phi[8,10]  R2934     -1.5043900769704954e+00
    phi[8,10]  R2935     -1.0347671897776156e+00
    phi[8,10]  R2936     -1.2542675275975324e+00
    phi[8,10]  R2937     -1.2119314836078290e+00
    phi[8,10]  R2938     -1.2427811895362335e+00
    phi[8,10]  R2939     -8.6694654569913876e-01
    phi[8,10]  R2940     -1.4425845345109791e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R83       -1
    z[0,1,0]  R84       1
    z[0,1,0]  R97       -3.9479446411132812e-01
    z[0,1,0]  R98       -7.1644838899374008e-03
    z[0,1,0]  R99       1.7566068470478058e-01
    z[0,1,0]  R100      7.8504756093025208e-02
    z[0,1,0]  R101      -2.2681222856044769e-01
    z[0,1,0]  R102      -4.6323519945144653e-01
    z[0,1,0]  R103      0.0936773419380188
    z[0,1,0]  R104      -4.5889618992805481e-01
    z[0,1,0]  R105      -2.4875631928443909e-01
    z[0,1,0]  R106      -5.2680855989456177e-01
    z[0,1,0]  R107      7.0719575881958008e-01
    z[0,1,0]  R108      0.6134073138237
    z[0,1,0]  R109      6.9082254171371460e-01
    z[0,1,0]  R110      4.2688539624214172e-01
    z[0,1,0]  R111      3.9112001657485962e-01
    z[0,1,0]  R112      1.5688183903694153e-01
    z[0,1,0]  R113      2.4505098164081573e-01
    z[0,1,0]  R114      6.1353474855422974e-01
    z[0,1,0]  R115      6.3017058372497559e-01
    z[0,1,0]  R116      0.533696711063385
    z[0,1,0]  R117      -4.1174806654453278e-02
    z[0,1,0]  R118      -2.2101683914661407e-01
    z[0,1,0]  R119      2.3543527722358704e-01
    z[0,1,0]  R120      -4.1090536117553711e-01
    z[0,1,0]  R121      -2.8238549828529358e-01
    z[0,1,0]  R122      -6.5844398736953735e-01
    z[0,1,0]  R123      2.7941653132438660e-01
    z[0,1,0]  R124      1.9471745193004608e-01
    z[0,1,0]  R125      2.4684593081474304e-01
    z[0,1,0]  R126      -6.4855295419692993e-01
    z[0,1,0]  R127      -6.4152352511882782e-02
    z[0,1,0]  R128      -2.1554049849510193e-01
    z[0,1,0]  R129      -3.8296741247177124e-01
    z[0,1,0]  R130      -2.9756072163581848e-01
    z[0,1,0]  R131      -8.0398225784301758e-01
    z[0,1,0]  R132      -1.5241575241088867e-01
    z[0,1,0]  R133      -2.3599635809659958e-02
    z[0,1,0]  R134      2.5626775622367859e-01
    z[0,1,0]  R135      2.9781398177146912e-01
    z[0,1,0]  R136      1.8805319070816040e-01
    z[0,1,0]  R137      -4.7391787171363831e-01
    z[0,1,0]  R138      9.8290868103504181e-02
    z[0,1,0]  R139      -7.2330236434936523e-02
    z[0,1,0]  R140      -2.0658065378665924e-01
    z[0,1,0]  R141      0.511587917804718
    z[0,1,0]  R142      -3.8683310151100159e-02
    z[0,1,0]  R143      2.7261814475059509e-01
    z[0,1,0]  R144      -4.4772675633430481e-01
    z[0,1,0]  R145      2.7434009313583374e-01
    z[0,1,0]  R146      -6.1960822343826294e-01
    z[0,1,0]  R147      -2.3314456641674042e-01
    z[0,1,0]  R148      2.1505402028560638e-01
    z[0,1,0]  R149      -3.5934236645698547e-01
    z[0,1,0]  R150      -4.7247186303138733e-01
    z[0,1,0]  R151      -5.6366211175918579e-01
    z[0,1,0]  R152      1.6025616228580475e-01
    z[0,1,0]  R153      -4.7844117879867554e-01
    z[0,1,0]  R154      4.9190583825111389e-01
    z[0,1,0]  R155      3.6162805557250977e-01
    z[0,1,0]  R156      -3.7239813804626465e-01
    z[0,1,0]  R157      -3.0806419253349304e-01
    z[0,1,0]  R158      1.1876897513866425e-01
    z[0,1,0]  R159      1.5820379555225372e-01
    z[0,1,0]  R160      3.1624826788902283e-01
    z[0,1,0]  R161      2.8448304533958435e-01
    z[0,1,0]  R162      2.8737327456474304e-01
    z[0,1,0]  R163      1.4233843982219696e-01
    z[0,1,0]  R164      3.8168802857398987e-02
    z[0,1,0]  R165      -3.0492378398776054e-02
    z[0,1,0]  R166      1.7495785653591156e-01
    z[0,1,0]  R167      7.8782200813293457e-01
    z[0,1,0]  R168      -9.1499380767345428e-02
    z[0,1,0]  R169      -1.8841521441936493e-01
    z[0,1,0]  R170      -4.2797368764877319e-01
    z[0,1,0]  R171      -3.4564241766929626e-01
    z[0,1,0]  R172      -5.2983468770980835e-01
    z[0,1,0]  R173      -4.0331348776817322e-01
    z[0,1,0]  R174      -7.4129021167755127e-01
    z[0,1,0]  R175      4.6944785118103027e-01
    z[0,1,0]  R176      -1.6648881137371063e-01
    z[0,1,0]  R177      -2.2663618624210358e-01
    z[0,1,0]  R178      -1.2377069145441055e-01
    z[0,1,0]  R179      -5.1148599386215210e-01
    z[0,1,0]  R180      -1.9897338747978210e-01
    z[0,1,0]  R181      5.4989758878946304e-02
    z[0,1,0]  R182      -3.4354427456855774e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R85       -1
    z[0,1,1]  R86       1
    z[0,1,1]  R97       -3.7504711747169495e-01
    z[0,1,1]  R98       -2.5783985853195190e-02
    z[0,1,1]  R99       -3.3422711491584778e-01
    z[0,1,1]  R100      -3.5029903054237366e-01
    z[0,1,1]  R101      4.9680642783641815e-02
    z[0,1,1]  R102      1.2528367340564728e-01
    z[0,1,1]  R103      3.9745840430259705e-01
    z[0,1,1]  R104      6.4624166488647461e-01
    z[0,1,1]  R105      3.3386969566345215e-01
    z[0,1,1]  R106      4.9182033538818359e-01
    z[0,1,1]  R107      -5.9345859289169312e-01
    z[0,1,1]  R108      -0.574647843837738
    z[0,1,1]  R109      -4.8191988468170166e-01
    z[0,1,1]  R110      -6.6034138202667236e-01
    z[0,1,1]  R111      8.1128066778182983e-01
    z[0,1,1]  R112      7.6293140649795532e-01
    z[0,1,1]  R113      0.261626660823822
    z[0,1,1]  R114      2.8607034683227539e-01
    z[0,1,1]  R115      3.0158591270446777e-01
    z[0,1,1]  R116      3.2507914304733276e-01
    z[0,1,1]  R117      -3.8137458264827728e-02
    z[0,1,1]  R118      9.3860030174255371e-01
    z[0,1,1]  R119      5.7797157764434814e-01
    z[0,1,1]  R120      7.6948130130767822e-01
    z[0,1,1]  R121      7.0045018196105957e-01
    z[0,1,1]  R122      2.2301225364208221e-01
    z[0,1,1]  R123      5.5432754755020142e-01
    z[0,1,1]  R124      -0.735713005065918
    z[0,1,1]  R125      4.2580845952033997e-01
    z[0,1,1]  R126      2.6165801286697388e-01
    z[0,1,1]  R127      1.5105303376913071e-02
    z[0,1,1]  R128      3.5461014509201050e-01
    z[0,1,1]  R129      2.8842544555664062e-01
    z[0,1,1]  R130      4.8079398274421692e-01
    z[0,1,1]  R131      4.1632503271102905e-01
    z[0,1,1]  R132      7.3749560117721558e-01
    z[0,1,1]  R133      8.9738404750823975e-01
    z[0,1,1]  R134      6.3835614919662476e-01
    z[0,1,1]  R135      5.9868997335433960e-01
    z[0,1,1]  R136      7.7419120073318481e-01
    z[0,1,1]  R137      3.2915085554122925e-01
    z[0,1,1]  R138      3.9533627033233643e-01
    z[0,1,1]  R139      8.8824760913848877e-01
    z[0,1,1]  R140      0.877727210521698
    z[0,1,1]  R141      4.2683750391006470e-01
    z[0,1,1]  R142      3.0805489420890808e-01
    z[0,1,1]  R143      8.3055114746093750e-01
    z[0,1,1]  R144      1.3095045089721680e-01
    z[0,1,1]  R145      -5.9901338815689087e-01
    z[0,1,1]  R146      -1.9765254110097885e-02
    z[0,1,1]  R147      -2.4018374085426331e-01
    z[0,1,1]  R148      2.2535805404186249e-01
    z[0,1,1]  R149      8.8200157880783081e-01
    z[0,1,1]  R150      1.5178048610687256e-01
    z[0,1,1]  R151      1.4478464424610138e-01
    z[0,1,1]  R152      -8.1214743852615356e-01
    z[0,1,1]  R153      -5.2411098033189774e-02
    z[0,1,1]  R154      0.616611659526825
    z[0,1,1]  R155      0.82222580909729
    z[0,1,1]  R156      9.0921252965927124e-02
    z[0,1,1]  R157      5.0547677278518677e-01
    z[0,1,1]  R158      0.720435380935669
    z[0,1,1]  R159      4.8574465513229370e-01
    z[0,1,1]  R160      0.200750932097435
    z[0,1,1]  R161      -7.4452996253967285e-01
    z[0,1,1]  R162      8.5937988758087158e-01
    z[0,1,1]  R163      -3.5893049091100693e-02
    z[0,1,1]  R164      1.5119243413209915e-02
    z[0,1,1]  R165      0.0903463065624237
    z[0,1,1]  R166      1.1638209223747253e-01
    z[0,1,1]  R167      1.8559511005878448e-01
    z[0,1,1]  R168      8.6331389844417572e-02
    z[0,1,1]  R169      -6.4906142652034760e-02
    z[0,1,1]  R170      4.4738192111253738e-02
    z[0,1,1]  R171      -6.0009807348251343e-02
    z[0,1,1]  R172      -4.8701085150241852e-02
    z[0,1,1]  R173      4.6199014782905579e-01
    z[0,1,1]  R174      -2.2323431447148323e-02
    z[0,1,1]  R175      -2.3589028418064117e-01
    z[0,1,1]  R176      4.7085127234458923e-01
    z[0,1,1]  R177      -4.2715936899185181e-01
    z[0,1,1]  R178      4.4058451056480408e-01
    z[0,1,1]  R179      5.4624825716018677e-01
    z[0,1,1]  R180      6.0098719596862793e-01
    z[0,1,1]  R181      5.0409317016601562e-01
    z[0,1,1]  R182      -3.8267418742179871e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R87       -1
    z[0,1,2]  R88       1
    z[0,1,2]  R97       -2.8222200274467468e-01
    z[0,1,2]  R98       -7.0818763971328735e-01
    z[0,1,2]  R99       -0.651944637298584
    z[0,1,2]  R100      -5.8991187810897827e-01
    z[0,1,2]  R101      -3.4730535745620728e-01
    z[0,1,2]  R102      -6.0387951135635376e-01
    z[0,1,2]  R103      -0.27772057056427
    z[0,1,2]  R104      -2.9529851675033569e-01
    z[0,1,2]  R105      -4.0939885377883911e-01
    z[0,1,2]  R106      -3.5868924856185913e-01
    z[0,1,2]  R107      3.0828040838241577e-01
    z[0,1,2]  R108      4.5731565356254578e-01
    z[0,1,2]  R109      3.3518549799919128e-01
    z[0,1,2]  R110      4.4903567433357239e-01
    z[0,1,2]  R111      -1.2298995256423950e-01
    z[0,1,2]  R112      3.8961014151573181e-01
    z[0,1,2]  R113      7.5684711337089539e-02
    z[0,1,2]  R114      5.4651558399200439e-01
    z[0,1,2]  R115      4.6327370405197144e-01
    z[0,1,2]  R116      7.1334266662597656e-01
    z[0,1,2]  R117      -2.5875192880630493e-01
    z[0,1,2]  R118      3.3265821635723114e-02
    z[0,1,2]  R119      -2.8829440474510193e-01
    z[0,1,2]  R120      -1.6742104291915894e-01
    z[0,1,2]  R121      -1.5327529981732368e-02
    z[0,1,2]  R122      -2.2643579542636871e-01
    z[0,1,2]  R123      -4.5030519366264343e-01
    z[0,1,2]  R124      -4.2532366514205933e-01
    z[0,1,2]  R125      8.2564197480678558e-02
    z[0,1,2]  R126      -4.2296311259269714e-01
    z[0,1,2]  R127      0.0939294695854187
    z[0,1,2]  R128      5.1697814464569092e-01
    z[0,1,2]  R129      4.8295497894287109e-01
    z[0,1,2]  R130      0.530137300491333
    z[0,1,2]  R131      -1.3428612053394318e-01
    z[0,1,2]  R132      2.9846025630831718e-02
    z[0,1,2]  R133      2.1396109461784363e-01
    z[0,1,2]  R134      -1.9447919726371765e-01
    z[0,1,2]  R135      1.6164864599704742e-01
    z[0,1,2]  R136      -4.8067551851272583e-01
    z[0,1,2]  R137      3.7510451674461365e-01
    z[0,1,2]  R138      2.3092246055603027e-01
    z[0,1,2]  R139      -2.2959072887897491e-01
    z[0,1,2]  R140      -1.6290232539176941e-01
    z[0,1,2]  R141      -4.5549508929252625e-01
    z[0,1,2]  R142      -5.5159491300582886e-01
    z[0,1,2]  R143      -2.0587055385112762e-01
    z[0,1,2]  R144      -6.7763239145278931e-01
    z[0,1,2]  R145      -3.8402143120765686e-01
    z[0,1,2]  R146      -3.8673040270805359e-01
    z[0,1,2]  R147      -2.3727035522460938e-01
    z[0,1,2]  R148      8.1480335211381316e-04
    z[0,1,2]  R149      -7.0957783609628677e-03
    z[0,1,2]  R150      4.7249630093574524e-01
    z[0,1,2]  R151      -4.6459707617759705e-01
    z[0,1,2]  R152      -1.9321471452713013e-01
    z[0,1,2]  R153      4.0367519855499268e-01
    z[0,1,2]  R154      3.6768182180821896e-03
    z[0,1,2]  R155      2.1117500960826874e-01
    z[0,1,2]  R156      -7.9911732673645020e-01
    z[0,1,2]  R157      2.7404162287712097e-01
    z[0,1,2]  R158      -2.1417331695556641e-01
    z[0,1,2]  R159      -2.6037716865539551e-01
    z[0,1,2]  R160      -8.3167001605033875e-02
    z[0,1,2]  R161      -0.0464789904654026
    z[0,1,2]  R162      2.4752826988697052e-01
    z[0,1,2]  R163      0.0690079852938652
    z[0,1,2]  R164      -1.9208157435059547e-02
    z[0,1,2]  R165      -2.4218328297138214e-01
    z[0,1,2]  R166      1.1183889955282211e-01
    z[0,1,2]  R167      -3.7961982190608978e-02
    z[0,1,2]  R168      -2.0295926928520203e-01
    z[0,1,2]  R169      -4.9763530492782593e-01
    z[0,1,2]  R170      -3.9014372229576111e-01
    z[0,1,2]  R171      -4.2751175165176392e-01
    z[0,1,2]  R172      -3.1068110838532448e-03
    z[0,1,2]  R173      -4.9676337838172913e-01
    z[0,1,2]  R174      -5.3054824471473694e-02
    z[0,1,2]  R175      3.4527891874313354e-01
    z[0,1,2]  R176      -2.4652208387851715e-01
    z[0,1,2]  R177      2.2169497609138489e-01
    z[0,1,2]  R178      3.6531981825828552e-01
    z[0,1,2]  R179      -5.1182711124420166e-01
    z[0,1,2]  R180      -8.2438193261623383e-02
    z[0,1,2]  R181      -5.5990350246429443e-01
    z[0,1,2]  R182      3.3791989088058472e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R89       -1
    z[0,1,3]  R90       1
    z[0,1,3]  R97       -6.8621051311492920e-01
    z[0,1,3]  R98       -2.5275599956512451e-01
    z[0,1,3]  R99       -4.9141255021095276e-01
    z[0,1,3]  R100      -4.5514798164367676e-01
    z[0,1,3]  R101      -8.4004592895507812e-01
    z[0,1,3]  R102      -2.7963468432426453e-01
    z[0,1,3]  R103      -1.3276250660419464e-01
    z[0,1,3]  R104      5.9658315032720566e-02
    z[0,1,3]  R105      -5.3083121776580811e-01
    z[0,1,3]  R106      -4.5202895998954773e-01
    z[0,1,3]  R107      1.0881885886192322e-02
    z[0,1,3]  R108      1.5948741137981415e-01
    z[0,1,3]  R109      2.7570670843124390e-01
    z[0,1,3]  R110      -1.8218036741018295e-02
    z[0,1,3]  R111      2.2762574255466461e-01
    z[0,1,3]  R112      2.1701575815677643e-01
    z[0,1,3]  R113      0.722253143787384
    z[0,1,3]  R114      -1.1596355587244034e-01
    z[0,1,3]  R115      3.2577980309724808e-02
    z[0,1,3]  R116      -2.0400810241699219e-01
    z[0,1,3]  R117      -8.4571164846420288e-01
    z[0,1,3]  R118      1.3899172656238079e-02
    z[0,1,3]  R119      -0.503036379814148
    z[0,1,3]  R120      1.9249898195266724e-01
    z[0,1,3]  R121      1.7376442253589630e-01
    z[0,1,3]  R122      2.0377150177955627e-01
    z[0,1,3]  R123      5.3218871355056763e-01
    z[0,1,3]  R124      3.7639716267585754e-01
    z[0,1,3]  R125      8.0569308996200562e-01
    z[0,1,3]  R126      1.9111488759517670e-01
    z[0,1,3]  R127      -6.7610043287277222e-01
    z[0,1,3]  R128      -2.5543466210365295e-01
    z[0,1,3]  R129      -2.9475077986717224e-01
    z[0,1,3]  R130      -3.6603674292564392e-01
    z[0,1,3]  R131      -3.1473973393440247e-01
    z[0,1,3]  R132      4.0507054328918457e-01
    z[0,1,3]  R133      3.4312078356742859e-01
    z[0,1,3]  R134      6.6566234827041626e-01
    z[0,1,3]  R135      6.0403460264205933e-01
    z[0,1,3]  R136      1.8613217771053314e-01
    z[0,1,3]  R137      -4.0200895071029663e-01
    z[0,1,3]  R138      -4.2520660161972046e-01
    z[0,1,3]  R139      3.1519877910614014e-01
    z[0,1,3]  R140      1.3571046292781830e-01
    z[0,1,3]  R141      -4.4724997878074646e-01
    z[0,1,3]  R142      -4.7054540365934372e-02
    z[0,1,3]  R143      3.4226789139211178e-03
    z[0,1,3]  R144      4.4271681457757950e-02
    z[0,1,3]  R145      2.0921096205711365e-01
    z[0,1,3]  R146      4.4117620587348938e-01
    z[0,1,3]  R147      -8.0092787742614746e-01
    z[0,1,3]  R148      -3.2704836130142212e-01
    z[0,1,3]  R149      1.8207387626171112e-01
    z[0,1,3]  R150      -4.8394846916198730e-01
    z[0,1,3]  R151      0.361424058675766
    z[0,1,3]  R152      1.2346322089433670e-01
    z[0,1,3]  R153      -4.5794636011123657e-01
    z[0,1,3]  R154      4.5768809318542480e-01
    z[0,1,3]  R155      -4.9208205193281174e-02
    z[0,1,3]  R156      4.1079086065292358e-01
    z[0,1,3]  R157      -6.7735582590103149e-01
    z[0,1,3]  R158      -4.6819177269935608e-01
    z[0,1,3]  R159      -5.0702202320098877e-01
    z[0,1,3]  R160      -1.0684862732887268e-01
    z[0,1,3]  R161      2.7452594041824341e-01
    z[0,1,3]  R162      -5.2677791565656662e-02
    z[0,1,3]  R163      8.0816954374313354e-01
    z[0,1,3]  R164      7.4673879146575928e-01
    z[0,1,3]  R165      8.8588553667068481e-01
    z[0,1,3]  R166      0.750617504119873
    z[0,1,3]  R167      -1.9140833616256714e-01
    z[0,1,3]  R168      -8.7153857946395874e-01
    z[0,1,3]  R169      -7.4942690134048462e-01
    z[0,1,3]  R170      -7.6530581712722778e-01
    z[0,1,3]  R171      -7.4175614118576050e-01
    z[0,1,3]  R172      -7.6331532001495361e-01
    z[0,1,3]  R173      -2.5657391548156738e-01
    z[0,1,3]  R174      0.00394494878128171
    z[0,1,3]  R175      0.538794219493866
    z[0,1,3]  R176      6.4446341991424561e-01
    z[0,1,3]  R177      3.4445956349372864e-01
    z[0,1,3]  R178      1.4134380221366882e-01
    z[0,1,3]  R179      2.7410295605659485e-01
    z[0,1,3]  R180      1.5015423297882080e-01
    z[0,1,3]  R181      -4.2969822883605957e-02
    z[0,1,3]  R182      3.9759820699691772e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R91       -1
    z[0,1,4]  R92       1
    z[0,1,4]  R97       -1.9780221581459045e-01
    z[0,1,4]  R98       4.3426206707954407e-01
    z[0,1,4]  R99       2.7881652116775513e-01
    z[0,1,4]  R100      -1.3999934494495392e-01
    z[0,1,4]  R101      1.1205311119556427e-01
    z[0,1,4]  R102      5.0323325395584106e-01
    z[0,1,4]  R103      1.1693440377712250e-01
    z[0,1,4]  R104      2.7517375349998474e-01
    z[0,1,4]  R105      6.1010152101516724e-01
    z[0,1,4]  R106      2.9160878062248230e-01
    z[0,1,4]  R107      -4.9447748810052872e-02
    z[0,1,4]  R108      0.0463813841342926
    z[0,1,4]  R109      -2.7928104624152184e-02
    z[0,1,4]  R110      2.0555068552494049e-01
    z[0,1,4]  R111      -1.7847079038619995e-01
    z[0,1,4]  R112      -1.1961609870195389e-01
    z[0,1,4]  R113      -1.1268706619739532e-01
    z[0,1,4]  R114      4.5529574155807495e-01
    z[0,1,4]  R115      5.2836841344833374e-01
    z[0,1,4]  R116      1.9430550932884216e-01
    z[0,1,4]  R117      3.6644729971885681e-01
    z[0,1,4]  R118      -1.2006153166294098e-01
    z[0,1,4]  R119      -2.7529746294021606e-01
    z[0,1,4]  R120      -1.7058400809764862e-01
    z[0,1,4]  R121      -2.7533468604087830e-01
    z[0,1,4]  R122      -6.5085852146148682e-01
    z[0,1,4]  R123      4.7541882842779160e-02
    z[0,1,4]  R124      -8.1411756575107574e-02
    z[0,1,4]  R125      -2.5701868534088135e-01
    z[0,1,4]  R126      -4.0119481086730957e-01
    z[0,1,4]  R127      -3.4540107846260071e-01
    z[0,1,4]  R128      -3.8256838917732239e-01
    z[0,1,4]  R129      -0.398904025554657
    z[0,1,4]  R130      -3.4026777744293213e-01
    z[0,1,4]  R131      -2.2784620523452759e-01
    z[0,1,4]  R132      -3.7005582451820374e-01
    z[0,1,4]  R133      1.4103437960147858e-01
    z[0,1,4]  R134      5.0847832113504410e-02
    z[0,1,4]  R135      -2.4096952378749847e-01
    z[0,1,4]  R136      1.5062609314918518e-01
    z[0,1,4]  R137      -9.1757416725158691e-02
    z[0,1,4]  R138      -6.4169371128082275e-01
    z[0,1,4]  R139      -1.4829677343368530e-01
    z[0,1,4]  R140      -2.0367094874382019e-01
    z[0,1,4]  R141      -3.2702258229255676e-01
    z[0,1,4]  R142      -4.5942065119743347e-01
    z[0,1,4]  R143      5.1726657897233963e-02
    z[0,1,4]  R144      -4.9323320388793945e-01
    z[0,1,4]  R145      -3.2182257622480392e-02
    z[0,1,4]  R146      -1.8704400956630707e-01
    z[0,1,4]  R147      -2.5612348318099976e-01
    z[0,1,4]  R148      -3.5367685556411743e-01
    z[0,1,4]  R149      1.0367939621210098e-01
    z[0,1,4]  R150      1.9010002911090851e-01
    z[0,1,4]  R151      -4.0953093767166138e-01
    z[0,1,4]  R152      -2.8843152523040771e-01
    z[0,1,4]  R153      -1.7898014187812805e-01
    z[0,1,4]  R154      -2.9846525192260742e-01
    z[0,1,4]  R155      1.0212247818708420e-01
    z[0,1,4]  R156      -2.1296466886997223e-01
    z[0,1,4]  R157      -9.3044847249984741e-02
    z[0,1,4]  R158      1.7969395220279694e-01
    z[0,1,4]  R159      -3.8016852736473083e-01
    z[0,1,4]  R160      -5.0106018781661987e-01
    z[0,1,4]  R161      1.8553231656551361e-01
    z[0,1,4]  R162      1.1167474091053009e-01
    z[0,1,4]  R163      -2.5926116108894348e-01
    z[0,1,4]  R164      -2.1536377072334290e-01
    z[0,1,4]  R165      -1.9740676879882812e-01
    z[0,1,4]  R166      -2.5239869952201843e-01
    z[0,1,4]  R167      -2.2562074661254883e-01
    z[0,1,4]  R168      4.1770094633102417e-01
    z[0,1,4]  R169      9.3129336833953857e-02
    z[0,1,4]  R170      -2.1449530124664307e-01
    z[0,1,4]  R171      2.4335640668869019e-01
    z[0,1,4]  R172      -5.7202443480491638e-02
    z[0,1,4]  R173      5.2923923730850220e-01
    z[0,1,4]  R174      5.5525940656661987e-01
    z[0,1,4]  R175      1.3088180124759674e-01
    z[0,1,4]  R176      -2.1067827939987183e-01
    z[0,1,4]  R177      -6.9597214460372925e-01
    z[0,1,4]  R178      -4.6219328045845032e-01
    z[0,1,4]  R179      -5.0360444001853466e-03
    z[0,1,4]  R180      2.0514579117298126e-01
    z[0,1,4]  R181      -2.5430586934089661e-01
    z[0,1,4]  R182      -4.5101216435432434e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R93       -1
    z[0,1,5]  R94       1
    z[0,1,5]  R97       2.2368688881397247e-01
    z[0,1,5]  R98       4.8190298676490784e-01
    z[0,1,5]  R99       3.3627447485923767e-01
    z[0,1,5]  R100      5.3906667232513428e-01
    z[0,1,5]  R101      -0.274694561958313
    z[0,1,5]  R102      2.6330825686454773e-01
    z[0,1,5]  R103      0.846364438533783
    z[0,1,5]  R104      4.5080372691154480e-01
    z[0,1,5]  R105      -5.0654627382755280e-02
    z[0,1,5]  R106      2.3863463103771210e-01
    z[0,1,5]  R107      -1.7922644317150116e-01
    z[0,1,5]  R108      1.8534478545188904e-01
    z[0,1,5]  R109      3.1838840246200562e-01
    z[0,1,5]  R110      -1.6285143792629242e-01
    z[0,1,5]  R111      -2.6255920529365540e-01
    z[0,1,5]  R112      -1.8663893640041351e-01
    z[0,1,5]  R113      3.1805068254470825e-01
    z[0,1,5]  R114      -4.7559358179569244e-02
    z[0,1,5]  R115      -4.7271057963371277e-02
    z[0,1,5]  R116      7.4209690093994141e-02
    z[0,1,5]  R117      2.8233960270881653e-01
    z[0,1,5]  R118      -2.3085056245326996e-01
    z[0,1,5]  R119      3.6141827702522278e-02
    z[0,1,5]  R120      -1.6141220927238464e-01
    z[0,1,5]  R121      -1.2815786898136139e-01
    z[0,1,5]  R122      -1.2487945146858692e-02
    z[0,1,5]  R123      -8.2670869305729866e-03
    z[0,1,5]  R124      -6.7917510867118835e-02
    z[0,1,5]  R125      1.7979972064495087e-01
    z[0,1,5]  R126      -3.6516842246055603e-01
    z[0,1,5]  R127      6.0884922742843628e-01
    z[0,1,5]  R128      0.588984489440918
    z[0,1,5]  R129      5.3796172142028809e-01
    z[0,1,5]  R130      3.3902713656425476e-01
    z[0,1,5]  R131      -5.8717697858810425e-02
    z[0,1,5]  R132      3.5889267921447754e-01
    z[0,1,5]  R133      3.3878777176141739e-02
    z[0,1,5]  R134      1.9420199096202850e-01
    z[0,1,5]  R135      2.9188758134841919e-01
    z[0,1,5]  R136      -0.0816691666841507
    z[0,1,5]  R137      3.0651926994323730e-01
    z[0,1,5]  R138      3.0878382921218872e-01
    z[0,1,5]  R139      -1.2946107983589172e-01
    z[0,1,5]  R140      6.1762958765029907e-02
    z[0,1,5]  R141      1.4723029732704163e-01
    z[0,1,5]  R142      1.7835982143878937e-01
    z[0,1,5]  R143      1.3586243987083435e-01
    z[0,1,5]  R144      -1.5781633555889130e-01
    z[0,1,5]  R145      -0.512084424495697
    z[0,1,5]  R146      1.4620803296566010e-01
    z[0,1,5]  R147      3.5290205478668213e-01
    z[0,1,5]  R148      6.4368414878845215e-01
    z[0,1,5]  R149      2.0285930484533310e-02
    z[0,1,5]  R150      -4.1125866770744324e-01
    z[0,1,5]  R151      3.4659293293952942e-01
    z[0,1,5]  R152      -3.8214546442031860e-01
    z[0,1,5]  R153      -0.573047399520874
    z[0,1,5]  R154      2.0609468221664429e-02
    z[0,1,5]  R155      1.8222462385892868e-02
    z[0,1,5]  R156      1.5775173902511597e-02
    z[0,1,5]  R157      2.3029072582721710e-01
    z[0,1,5]  R158      1.9393661618232727e-01
    z[0,1,5]  R159      1.9587431848049164e-01
    z[0,1,5]  R160      6.6620707511901855e-01
    z[0,1,5]  R161      -2.7824527025222778e-01
    z[0,1,5]  R162      5.2504088729619980e-02
    z[0,1,5]  R163      -4.9292716383934021e-01
    z[0,1,5]  R164      -6.2025654315948486e-01
    z[0,1,5]  R165      -3.2653677463531494e-01
    z[0,1,5]  R166      -5.0747859477996826e-01
    z[0,1,5]  R167      4.1746962070465088e-01
    z[0,1,5]  R168      -4.2152579873800278e-02
    z[0,1,5]  R169      -3.6931574344635010e-01
    z[0,1,5]  R170      -0.0731348991394043
    z[0,1,5]  R171      2.7010822296142578e-01
    z[0,1,5]  R172      3.0007827281951904e-01
    z[0,1,5]  R173      -1.0756545513868332e-01
    z[0,1,5]  R174      -1.1789335310459137e-01
    z[0,1,5]  R175      -3.8339126110076904e-01
    z[0,1,5]  R176      4.2558598518371582e-01
    z[0,1,5]  R177      2.2750738263130188e-01
    z[0,1,5]  R178      -4.8899385333061218e-01
    z[0,1,5]  R179      3.1099513173103333e-01
    z[0,1,5]  R180      5.5458873510360718e-01
    z[0,1,5]  R181      -1.4815038442611694e-01
    z[0,1,5]  R182      3.8735222816467285e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R95       -1
    z[0,1,6]  R96       1
    z[0,1,6]  R97       -2.5254982709884644e-01
    z[0,1,6]  R98       -1.1425584554672241e-01
    z[0,1,6]  R99       -0.00990948174148798
    z[0,1,6]  R100      0.0760202705860138
    z[0,1,6]  R101      1.7826054990291595e-01
    z[0,1,6]  R102      -6.5391868352890015e-02
    z[0,1,6]  R103      -9.2143878340721130e-02
    z[0,1,6]  R104      -4.5621380209922791e-02
    z[0,1,6]  R105      -4.9721501767635345e-02
    z[0,1,6]  R106      -7.4934326112270355e-02
    z[0,1,6]  R107      1.3400943577289581e-01
    z[0,1,6]  R108      -1.4977841079235077e-01
    z[0,1,6]  R109      -1.6282552387565374e-03
    z[0,1,6]  R110      -3.3313891291618347e-01
    z[0,1,6]  R111      -1.4532597362995148e-01
    z[0,1,6]  R112      3.8116896152496338e-01
    z[0,1,6]  R113      -4.7986373305320740e-01
    z[0,1,6]  R114      -1.4161920547485352e-01
    z[0,1,6]  R115      1.2181732803583145e-01
    z[0,1,6]  R116      1.2550921738147736e-01
    z[0,1,6]  R117      -2.5886796414852142e-02
    z[0,1,6]  R118      -3.4271985292434692e-02
    z[0,1,6]  R119      -4.4414526224136353e-01
    z[0,1,6]  R120      3.4469828009605408e-01
    z[0,1,6]  R121      -5.5404454469680786e-01
    z[0,1,6]  R122      1.2178383767604828e-02
    z[0,1,6]  R123      3.5541403293609619e-01
    z[0,1,6]  R124      -2.9495045542716980e-01
    z[0,1,6]  R125      -5.8390267193317413e-02
    z[0,1,6]  R126      3.4440811723470688e-02
    z[0,1,6]  R127      1.9930483400821686e-01
    z[0,1,6]  R128      4.4936783611774445e-02
    z[0,1,6]  R129      -3.8677752017974854e-02
    z[0,1,6]  R130      1.8586240708827972e-01
    z[0,1,6]  R131      -8.8489718735218048e-02
    z[0,1,6]  R132      -4.6383913606405258e-02
    z[0,1,6]  R133      9.7954608500003815e-02
    z[0,1,6]  R134      -0.0748317539691925
    z[0,1,6]  R135      -1.3647177815437317e-01
    z[0,1,6]  R136      -2.6497521996498108e-01
    z[0,1,6]  R137      -0.512224018573761
    z[0,1,6]  R138      -3.0463767051696777e-01
    z[0,1,6]  R139      1.2235336750745773e-01
    z[0,1,6]  R140      -3.1091544032096863e-01
    z[0,1,6]  R141      1.4127552509307861e-01
    z[0,1,6]  R142      5.9519338607788086e-01
    z[0,1,6]  R143      4.1513332724571228e-01
    z[0,1,6]  R144      2.3035214841365814e-01
    z[0,1,6]  R145      -3.3378526568412781e-01
    z[0,1,6]  R146      -0.463827520608902
    z[0,1,6]  R147      5.8014723472297192e-03
    z[0,1,6]  R148      5.0654488801956177e-01
    z[0,1,6]  R149      -2.2041791677474976e-01
    z[0,1,6]  R150      -3.0166599154472351e-01
    z[0,1,6]  R151      -1.6432404518127441e-01
    z[0,1,6]  R152      -0.181470587849617
    z[0,1,6]  R153      -1.8777973949909210e-01
    z[0,1,6]  R154      2.8074988722801208e-01
    z[0,1,6]  R155      -3.6795702576637268e-01
    z[0,1,6]  R156      -1.0612189769744873e-02
    z[0,1,6]  R157      2.3235501348972321e-01
    z[0,1,6]  R158      3.6316907405853271e-01
    z[0,1,6]  R159      -4.8089629411697388e-01
    z[0,1,6]  R160      -3.8270026445388794e-01
    z[0,1,6]  R161      -4.1878035664558411e-01
    z[0,1,6]  R162      -3.1560999155044556e-01
    z[0,1,6]  R163      1.0177277773618698e-01
    z[0,1,6]  R164      9.6057072281837463e-02
    z[0,1,6]  R165      4.3198190629482269e-02
    z[0,1,6]  R166      2.4222043156623840e-01
    z[0,1,6]  R167      -2.8570449352264404e-01
    z[0,1,6]  R168      -8.4568858146667480e-02
    z[0,1,6]  R169      7.7060006558895111e-02
    z[0,1,6]  R170      -1.5992110967636108e-01
    z[0,1,6]  R171      -1.0853934288024902e-01
    z[0,1,6]  R172      -2.0229780673980713e-01
    z[0,1,6]  R173      -1.4012403786182404e-01
    z[0,1,6]  R174      -3.5348019003868103e-01
    z[0,1,6]  R175      3.8773542642593384e-01
    z[0,1,6]  R176      2.2128143906593323e-01
    z[0,1,6]  R177      -2.4946540594100952e-01
    z[0,1,6]  R178      -4.2940875887870789e-01
    z[0,1,6]  R179      -7.8437119722366333e-02
    z[0,1,6]  R180      4.6928480267524719e-01
    z[0,1,6]  R181      5.8387309312820435e-01
    z[0,1,6]  R182      -3.3137583732604980e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R183      -1
    z[1,0,0]  R184      1
    z[1,0,0]  R197      7.8782200813293457e-01
    z[1,0,0]  R198      -9.1499380767345428e-02
    z[1,0,0]  R199      -1.8841521441936493e-01
    z[1,0,0]  R200      -4.2797368764877319e-01
    z[1,0,0]  R201      -3.4564241766929626e-01
    z[1,0,0]  R202      -5.2983468770980835e-01
    z[1,0,0]  R203      -4.0331348776817322e-01
    z[1,0,0]  R204      -7.4129021167755127e-01
    z[1,0,0]  R205      4.6944785118103027e-01
    z[1,0,0]  R206      -1.6648881137371063e-01
    z[1,0,0]  R207      -2.2663618624210358e-01
    z[1,0,0]  R208      -1.2377069145441055e-01
    z[1,0,0]  R209      -5.1148599386215210e-01
    z[1,0,0]  R210      -1.9897338747978210e-01
    z[1,0,0]  R211      5.4989758878946304e-02
    z[1,0,0]  R212      -3.4354427456855774e-01
    z[1,0,0]  R213      -3.9479446411132812e-01
    z[1,0,0]  R214      -7.1644838899374008e-03
    z[1,0,0]  R215      1.7566068470478058e-01
    z[1,0,0]  R216      7.8504756093025208e-02
    z[1,0,0]  R217      -2.2681222856044769e-01
    z[1,0,0]  R218      -4.6323519945144653e-01
    z[1,0,0]  R219      0.0936773419380188
    z[1,0,0]  R220      -4.5889618992805481e-01
    z[1,0,0]  R221      -2.4875631928443909e-01
    z[1,0,0]  R222      -5.2680855989456177e-01
    z[1,0,0]  R223      7.0719575881958008e-01
    z[1,0,0]  R224      0.6134073138237
    z[1,0,0]  R225      6.9082254171371460e-01
    z[1,0,0]  R226      4.2688539624214172e-01
    z[1,0,0]  R227      3.9112001657485962e-01
    z[1,0,0]  R228      1.5688183903694153e-01
    z[1,0,0]  R229      2.4505098164081573e-01
    z[1,0,0]  R230      6.1353474855422974e-01
    z[1,0,0]  R231      6.3017058372497559e-01
    z[1,0,0]  R232      0.533696711063385
    z[1,0,0]  R233      -4.1174806654453278e-02
    z[1,0,0]  R234      -2.2101683914661407e-01
    z[1,0,0]  R235      2.3543527722358704e-01
    z[1,0,0]  R236      -4.1090536117553711e-01
    z[1,0,0]  R237      -2.8238549828529358e-01
    z[1,0,0]  R238      -6.5844398736953735e-01
    z[1,0,0]  R239      2.7941653132438660e-01
    z[1,0,0]  R240      1.9471745193004608e-01
    z[1,0,0]  R241      2.4684593081474304e-01
    z[1,0,0]  R242      -6.4855295419692993e-01
    z[1,0,0]  R243      -6.4152352511882782e-02
    z[1,0,0]  R244      -2.1554049849510193e-01
    z[1,0,0]  R245      -3.8296741247177124e-01
    z[1,0,0]  R246      -2.9756072163581848e-01
    z[1,0,0]  R247      -8.0398225784301758e-01
    z[1,0,0]  R248      -1.5241575241088867e-01
    z[1,0,0]  R249      -2.3599635809659958e-02
    z[1,0,0]  R250      2.5626775622367859e-01
    z[1,0,0]  R251      2.9781398177146912e-01
    z[1,0,0]  R252      1.8805319070816040e-01
    z[1,0,0]  R253      -4.7391787171363831e-01
    z[1,0,0]  R254      9.8290868103504181e-02
    z[1,0,0]  R255      -7.2330236434936523e-02
    z[1,0,0]  R256      -2.0658065378665924e-01
    z[1,0,0]  R257      0.511587917804718
    z[1,0,0]  R258      -3.8683310151100159e-02
    z[1,0,0]  R259      2.7261814475059509e-01
    z[1,0,0]  R260      -4.4772675633430481e-01
    z[1,0,0]  R261      2.7434009313583374e-01
    z[1,0,0]  R262      -6.1960822343826294e-01
    z[1,0,0]  R263      -2.3314456641674042e-01
    z[1,0,0]  R264      2.1505402028560638e-01
    z[1,0,0]  R265      -3.5934236645698547e-01
    z[1,0,0]  R266      -4.7247186303138733e-01
    z[1,0,0]  R267      -5.6366211175918579e-01
    z[1,0,0]  R268      1.6025616228580475e-01
    z[1,0,0]  R269      -4.7844117879867554e-01
    z[1,0,0]  R270      4.9190583825111389e-01
    z[1,0,0]  R271      3.6162805557250977e-01
    z[1,0,0]  R272      -3.7239813804626465e-01
    z[1,0,0]  R273      -3.0806419253349304e-01
    z[1,0,0]  R274      1.1876897513866425e-01
    z[1,0,0]  R275      1.5820379555225372e-01
    z[1,0,0]  R276      3.1624826788902283e-01
    z[1,0,0]  R277      2.8448304533958435e-01
    z[1,0,0]  R278      2.8737327456474304e-01
    z[1,0,0]  R279      1.4233843982219696e-01
    z[1,0,0]  R280      3.8168802857398987e-02
    z[1,0,0]  R281      -3.0492378398776054e-02
    z[1,0,0]  R282      1.7495785653591156e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R185      -1
    z[1,0,1]  R186      1
    z[1,0,1]  R197      1.8559511005878448e-01
    z[1,0,1]  R198      8.6331389844417572e-02
    z[1,0,1]  R199      -6.4906142652034760e-02
    z[1,0,1]  R200      4.4738192111253738e-02
    z[1,0,1]  R201      -6.0009807348251343e-02
    z[1,0,1]  R202      -4.8701085150241852e-02
    z[1,0,1]  R203      4.6199014782905579e-01
    z[1,0,1]  R204      -2.2323431447148323e-02
    z[1,0,1]  R205      -2.3589028418064117e-01
    z[1,0,1]  R206      4.7085127234458923e-01
    z[1,0,1]  R207      -4.2715936899185181e-01
    z[1,0,1]  R208      4.4058451056480408e-01
    z[1,0,1]  R209      5.4624825716018677e-01
    z[1,0,1]  R210      6.0098719596862793e-01
    z[1,0,1]  R211      5.0409317016601562e-01
    z[1,0,1]  R212      -3.8267418742179871e-01
    z[1,0,1]  R213      -3.7504711747169495e-01
    z[1,0,1]  R214      -2.5783985853195190e-02
    z[1,0,1]  R215      -3.3422711491584778e-01
    z[1,0,1]  R216      -3.5029903054237366e-01
    z[1,0,1]  R217      4.9680642783641815e-02
    z[1,0,1]  R218      1.2528367340564728e-01
    z[1,0,1]  R219      3.9745840430259705e-01
    z[1,0,1]  R220      6.4624166488647461e-01
    z[1,0,1]  R221      3.3386969566345215e-01
    z[1,0,1]  R222      4.9182033538818359e-01
    z[1,0,1]  R223      -5.9345859289169312e-01
    z[1,0,1]  R224      -0.574647843837738
    z[1,0,1]  R225      -4.8191988468170166e-01
    z[1,0,1]  R226      -6.6034138202667236e-01
    z[1,0,1]  R227      8.1128066778182983e-01
    z[1,0,1]  R228      7.6293140649795532e-01
    z[1,0,1]  R229      0.261626660823822
    z[1,0,1]  R230      2.8607034683227539e-01
    z[1,0,1]  R231      3.0158591270446777e-01
    z[1,0,1]  R232      3.2507914304733276e-01
    z[1,0,1]  R233      -3.8137458264827728e-02
    z[1,0,1]  R234      9.3860030174255371e-01
    z[1,0,1]  R235      5.7797157764434814e-01
    z[1,0,1]  R236      7.6948130130767822e-01
    z[1,0,1]  R237      7.0045018196105957e-01
    z[1,0,1]  R238      2.2301225364208221e-01
    z[1,0,1]  R239      5.5432754755020142e-01
    z[1,0,1]  R240      -0.735713005065918
    z[1,0,1]  R241      4.2580845952033997e-01
    z[1,0,1]  R242      2.6165801286697388e-01
    z[1,0,1]  R243      1.5105303376913071e-02
    z[1,0,1]  R244      3.5461014509201050e-01
    z[1,0,1]  R245      2.8842544555664062e-01
    z[1,0,1]  R246      4.8079398274421692e-01
    z[1,0,1]  R247      4.1632503271102905e-01
    z[1,0,1]  R248      7.3749560117721558e-01
    z[1,0,1]  R249      8.9738404750823975e-01
    z[1,0,1]  R250      6.3835614919662476e-01
    z[1,0,1]  R251      5.9868997335433960e-01
    z[1,0,1]  R252      7.7419120073318481e-01
    z[1,0,1]  R253      3.2915085554122925e-01
    z[1,0,1]  R254      3.9533627033233643e-01
    z[1,0,1]  R255      8.8824760913848877e-01
    z[1,0,1]  R256      0.877727210521698
    z[1,0,1]  R257      4.2683750391006470e-01
    z[1,0,1]  R258      3.0805489420890808e-01
    z[1,0,1]  R259      8.3055114746093750e-01
    z[1,0,1]  R260      1.3095045089721680e-01
    z[1,0,1]  R261      -5.9901338815689087e-01
    z[1,0,1]  R262      -1.9765254110097885e-02
    z[1,0,1]  R263      -2.4018374085426331e-01
    z[1,0,1]  R264      2.2535805404186249e-01
    z[1,0,1]  R265      8.8200157880783081e-01
    z[1,0,1]  R266      1.5178048610687256e-01
    z[1,0,1]  R267      1.4478464424610138e-01
    z[1,0,1]  R268      -8.1214743852615356e-01
    z[1,0,1]  R269      -5.2411098033189774e-02
    z[1,0,1]  R270      0.616611659526825
    z[1,0,1]  R271      0.82222580909729
    z[1,0,1]  R272      9.0921252965927124e-02
    z[1,0,1]  R273      5.0547677278518677e-01
    z[1,0,1]  R274      0.720435380935669
    z[1,0,1]  R275      4.8574465513229370e-01
    z[1,0,1]  R276      0.200750932097435
    z[1,0,1]  R277      -7.4452996253967285e-01
    z[1,0,1]  R278      8.5937988758087158e-01
    z[1,0,1]  R279      -3.5893049091100693e-02
    z[1,0,1]  R280      1.5119243413209915e-02
    z[1,0,1]  R281      0.0903463065624237
    z[1,0,1]  R282      1.1638209223747253e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R187      -1
    z[1,0,2]  R188      1
    z[1,0,2]  R197      -3.7961982190608978e-02
    z[1,0,2]  R198      -2.0295926928520203e-01
    z[1,0,2]  R199      -4.9763530492782593e-01
    z[1,0,2]  R200      -3.9014372229576111e-01
    z[1,0,2]  R201      -4.2751175165176392e-01
    z[1,0,2]  R202      -3.1068110838532448e-03
    z[1,0,2]  R203      -4.9676337838172913e-01
    z[1,0,2]  R204      -5.3054824471473694e-02
    z[1,0,2]  R205      3.4527891874313354e-01
    z[1,0,2]  R206      -2.4652208387851715e-01
    z[1,0,2]  R207      2.2169497609138489e-01
    z[1,0,2]  R208      3.6531981825828552e-01
    z[1,0,2]  R209      -5.1182711124420166e-01
    z[1,0,2]  R210      -8.2438193261623383e-02
    z[1,0,2]  R211      -5.5990350246429443e-01
    z[1,0,2]  R212      3.3791989088058472e-01
    z[1,0,2]  R213      -2.8222200274467468e-01
    z[1,0,2]  R214      -7.0818763971328735e-01
    z[1,0,2]  R215      -0.651944637298584
    z[1,0,2]  R216      -5.8991187810897827e-01
    z[1,0,2]  R217      -3.4730535745620728e-01
    z[1,0,2]  R218      -6.0387951135635376e-01
    z[1,0,2]  R219      -0.27772057056427
    z[1,0,2]  R220      -2.9529851675033569e-01
    z[1,0,2]  R221      -4.0939885377883911e-01
    z[1,0,2]  R222      -3.5868924856185913e-01
    z[1,0,2]  R223      3.0828040838241577e-01
    z[1,0,2]  R224      4.5731565356254578e-01
    z[1,0,2]  R225      3.3518549799919128e-01
    z[1,0,2]  R226      4.4903567433357239e-01
    z[1,0,2]  R227      -1.2298995256423950e-01
    z[1,0,2]  R228      3.8961014151573181e-01
    z[1,0,2]  R229      7.5684711337089539e-02
    z[1,0,2]  R230      5.4651558399200439e-01
    z[1,0,2]  R231      4.6327370405197144e-01
    z[1,0,2]  R232      7.1334266662597656e-01
    z[1,0,2]  R233      -2.5875192880630493e-01
    z[1,0,2]  R234      3.3265821635723114e-02
    z[1,0,2]  R235      -2.8829440474510193e-01
    z[1,0,2]  R236      -1.6742104291915894e-01
    z[1,0,2]  R237      -1.5327529981732368e-02
    z[1,0,2]  R238      -2.2643579542636871e-01
    z[1,0,2]  R239      -4.5030519366264343e-01
    z[1,0,2]  R240      -4.2532366514205933e-01
    z[1,0,2]  R241      8.2564197480678558e-02
    z[1,0,2]  R242      -4.2296311259269714e-01
    z[1,0,2]  R243      0.0939294695854187
    z[1,0,2]  R244      5.1697814464569092e-01
    z[1,0,2]  R245      4.8295497894287109e-01
    z[1,0,2]  R246      0.530137300491333
    z[1,0,2]  R247      -1.3428612053394318e-01
    z[1,0,2]  R248      2.9846025630831718e-02
    z[1,0,2]  R249      2.1396109461784363e-01
    z[1,0,2]  R250      -1.9447919726371765e-01
    z[1,0,2]  R251      1.6164864599704742e-01
    z[1,0,2]  R252      -4.8067551851272583e-01
    z[1,0,2]  R253      3.7510451674461365e-01
    z[1,0,2]  R254      2.3092246055603027e-01
    z[1,0,2]  R255      -2.2959072887897491e-01
    z[1,0,2]  R256      -1.6290232539176941e-01
    z[1,0,2]  R257      -4.5549508929252625e-01
    z[1,0,2]  R258      -5.5159491300582886e-01
    z[1,0,2]  R259      -2.0587055385112762e-01
    z[1,0,2]  R260      -6.7763239145278931e-01
    z[1,0,2]  R261      -3.8402143120765686e-01
    z[1,0,2]  R262      -3.8673040270805359e-01
    z[1,0,2]  R263      -2.3727035522460938e-01
    z[1,0,2]  R264      8.1480335211381316e-04
    z[1,0,2]  R265      -7.0957783609628677e-03
    z[1,0,2]  R266      4.7249630093574524e-01
    z[1,0,2]  R267      -4.6459707617759705e-01
    z[1,0,2]  R268      -1.9321471452713013e-01
    z[1,0,2]  R269      4.0367519855499268e-01
    z[1,0,2]  R270      3.6768182180821896e-03
    z[1,0,2]  R271      2.1117500960826874e-01
    z[1,0,2]  R272      -7.9911732673645020e-01
    z[1,0,2]  R273      2.7404162287712097e-01
    z[1,0,2]  R274      -2.1417331695556641e-01
    z[1,0,2]  R275      -2.6037716865539551e-01
    z[1,0,2]  R276      -8.3167001605033875e-02
    z[1,0,2]  R277      -0.0464789904654026
    z[1,0,2]  R278      2.4752826988697052e-01
    z[1,0,2]  R279      0.0690079852938652
    z[1,0,2]  R280      -1.9208157435059547e-02
    z[1,0,2]  R281      -2.4218328297138214e-01
    z[1,0,2]  R282      1.1183889955282211e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R189      -1
    z[1,0,3]  R190      1
    z[1,0,3]  R197      -1.9140833616256714e-01
    z[1,0,3]  R198      -8.7153857946395874e-01
    z[1,0,3]  R199      -7.4942690134048462e-01
    z[1,0,3]  R200      -7.6530581712722778e-01
    z[1,0,3]  R201      -7.4175614118576050e-01
    z[1,0,3]  R202      -7.6331532001495361e-01
    z[1,0,3]  R203      -2.5657391548156738e-01
    z[1,0,3]  R204      0.00394494878128171
    z[1,0,3]  R205      0.538794219493866
    z[1,0,3]  R206      6.4446341991424561e-01
    z[1,0,3]  R207      3.4445956349372864e-01
    z[1,0,3]  R208      1.4134380221366882e-01
    z[1,0,3]  R209      2.7410295605659485e-01
    z[1,0,3]  R210      1.5015423297882080e-01
    z[1,0,3]  R211      -4.2969822883605957e-02
    z[1,0,3]  R212      3.9759820699691772e-01
    z[1,0,3]  R213      -6.8621051311492920e-01
    z[1,0,3]  R214      -2.5275599956512451e-01
    z[1,0,3]  R215      -4.9141255021095276e-01
    z[1,0,3]  R216      -4.5514798164367676e-01
    z[1,0,3]  R217      -8.4004592895507812e-01
    z[1,0,3]  R218      -2.7963468432426453e-01
    z[1,0,3]  R219      -1.3276250660419464e-01
    z[1,0,3]  R220      5.9658315032720566e-02
    z[1,0,3]  R221      -5.3083121776580811e-01
    z[1,0,3]  R222      -4.5202895998954773e-01
    z[1,0,3]  R223      1.0881885886192322e-02
    z[1,0,3]  R224      1.5948741137981415e-01
    z[1,0,3]  R225      2.7570670843124390e-01
    z[1,0,3]  R226      -1.8218036741018295e-02
    z[1,0,3]  R227      2.2762574255466461e-01
    z[1,0,3]  R228      2.1701575815677643e-01
    z[1,0,3]  R229      0.722253143787384
    z[1,0,3]  R230      -1.1596355587244034e-01
    z[1,0,3]  R231      3.2577980309724808e-02
    z[1,0,3]  R232      -2.0400810241699219e-01
    z[1,0,3]  R233      -8.4571164846420288e-01
    z[1,0,3]  R234      1.3899172656238079e-02
    z[1,0,3]  R235      -0.503036379814148
    z[1,0,3]  R236      1.9249898195266724e-01
    z[1,0,3]  R237      1.7376442253589630e-01
    z[1,0,3]  R238      2.0377150177955627e-01
    z[1,0,3]  R239      5.3218871355056763e-01
    z[1,0,3]  R240      3.7639716267585754e-01
    z[1,0,3]  R241      8.0569308996200562e-01
    z[1,0,3]  R242      1.9111488759517670e-01
    z[1,0,3]  R243      -6.7610043287277222e-01
    z[1,0,3]  R244      -2.5543466210365295e-01
    z[1,0,3]  R245      -2.9475077986717224e-01
    z[1,0,3]  R246      -3.6603674292564392e-01
    z[1,0,3]  R247      -3.1473973393440247e-01
    z[1,0,3]  R248      4.0507054328918457e-01
    z[1,0,3]  R249      3.4312078356742859e-01
    z[1,0,3]  R250      6.6566234827041626e-01
    z[1,0,3]  R251      6.0403460264205933e-01
    z[1,0,3]  R252      1.8613217771053314e-01
    z[1,0,3]  R253      -4.0200895071029663e-01
    z[1,0,3]  R254      -4.2520660161972046e-01
    z[1,0,3]  R255      3.1519877910614014e-01
    z[1,0,3]  R256      1.3571046292781830e-01
    z[1,0,3]  R257      -4.4724997878074646e-01
    z[1,0,3]  R258      -4.7054540365934372e-02
    z[1,0,3]  R259      3.4226789139211178e-03
    z[1,0,3]  R260      4.4271681457757950e-02
    z[1,0,3]  R261      2.0921096205711365e-01
    z[1,0,3]  R262      4.4117620587348938e-01
    z[1,0,3]  R263      -8.0092787742614746e-01
    z[1,0,3]  R264      -3.2704836130142212e-01
    z[1,0,3]  R265      1.8207387626171112e-01
    z[1,0,3]  R266      -4.8394846916198730e-01
    z[1,0,3]  R267      0.361424058675766
    z[1,0,3]  R268      1.2346322089433670e-01
    z[1,0,3]  R269      -4.5794636011123657e-01
    z[1,0,3]  R270      4.5768809318542480e-01
    z[1,0,3]  R271      -4.9208205193281174e-02
    z[1,0,3]  R272      4.1079086065292358e-01
    z[1,0,3]  R273      -6.7735582590103149e-01
    z[1,0,3]  R274      -4.6819177269935608e-01
    z[1,0,3]  R275      -5.0702202320098877e-01
    z[1,0,3]  R276      -1.0684862732887268e-01
    z[1,0,3]  R277      2.7452594041824341e-01
    z[1,0,3]  R278      -5.2677791565656662e-02
    z[1,0,3]  R279      8.0816954374313354e-01
    z[1,0,3]  R280      7.4673879146575928e-01
    z[1,0,3]  R281      8.8588553667068481e-01
    z[1,0,3]  R282      0.750617504119873
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R191      -1
    z[1,0,4]  R192      1
    z[1,0,4]  R197      -2.2562074661254883e-01
    z[1,0,4]  R198      4.1770094633102417e-01
    z[1,0,4]  R199      9.3129336833953857e-02
    z[1,0,4]  R200      -2.1449530124664307e-01
    z[1,0,4]  R201      2.4335640668869019e-01
    z[1,0,4]  R202      -5.7202443480491638e-02
    z[1,0,4]  R203      5.2923923730850220e-01
    z[1,0,4]  R204      5.5525940656661987e-01
    z[1,0,4]  R205      1.3088180124759674e-01
    z[1,0,4]  R206      -2.1067827939987183e-01
    z[1,0,4]  R207      -6.9597214460372925e-01
    z[1,0,4]  R208      -4.6219328045845032e-01
    z[1,0,4]  R209      -5.0360444001853466e-03
    z[1,0,4]  R210      2.0514579117298126e-01
    z[1,0,4]  R211      -2.5430586934089661e-01
    z[1,0,4]  R212      -4.5101216435432434e-01
    z[1,0,4]  R213      -1.9780221581459045e-01
    z[1,0,4]  R214      4.3426206707954407e-01
    z[1,0,4]  R215      2.7881652116775513e-01
    z[1,0,4]  R216      -1.3999934494495392e-01
    z[1,0,4]  R217      1.1205311119556427e-01
    z[1,0,4]  R218      5.0323325395584106e-01
    z[1,0,4]  R219      1.1693440377712250e-01
    z[1,0,4]  R220      2.7517375349998474e-01
    z[1,0,4]  R221      6.1010152101516724e-01
    z[1,0,4]  R222      2.9160878062248230e-01
    z[1,0,4]  R223      -4.9447748810052872e-02
    z[1,0,4]  R224      0.0463813841342926
    z[1,0,4]  R225      -2.7928104624152184e-02
    z[1,0,4]  R226      2.0555068552494049e-01
    z[1,0,4]  R227      -1.7847079038619995e-01
    z[1,0,4]  R228      -1.1961609870195389e-01
    z[1,0,4]  R229      -1.1268706619739532e-01
    z[1,0,4]  R230      4.5529574155807495e-01
    z[1,0,4]  R231      5.2836841344833374e-01
    z[1,0,4]  R232      1.9430550932884216e-01
    z[1,0,4]  R233      3.6644729971885681e-01
    z[1,0,4]  R234      -1.2006153166294098e-01
    z[1,0,4]  R235      -2.7529746294021606e-01
    z[1,0,4]  R236      -1.7058400809764862e-01
    z[1,0,4]  R237      -2.7533468604087830e-01
    z[1,0,4]  R238      -6.5085852146148682e-01
    z[1,0,4]  R239      4.7541882842779160e-02
    z[1,0,4]  R240      -8.1411756575107574e-02
    z[1,0,4]  R241      -2.5701868534088135e-01
    z[1,0,4]  R242      -4.0119481086730957e-01
    z[1,0,4]  R243      -3.4540107846260071e-01
    z[1,0,4]  R244      -3.8256838917732239e-01
    z[1,0,4]  R245      -0.398904025554657
    z[1,0,4]  R246      -3.4026777744293213e-01
    z[1,0,4]  R247      -2.2784620523452759e-01
    z[1,0,4]  R248      -3.7005582451820374e-01
    z[1,0,4]  R249      1.4103437960147858e-01
    z[1,0,4]  R250      5.0847832113504410e-02
    z[1,0,4]  R251      -2.4096952378749847e-01
    z[1,0,4]  R252      1.5062609314918518e-01
    z[1,0,4]  R253      -9.1757416725158691e-02
    z[1,0,4]  R254      -6.4169371128082275e-01
    z[1,0,4]  R255      -1.4829677343368530e-01
    z[1,0,4]  R256      -2.0367094874382019e-01
    z[1,0,4]  R257      -3.2702258229255676e-01
    z[1,0,4]  R258      -4.5942065119743347e-01
    z[1,0,4]  R259      5.1726657897233963e-02
    z[1,0,4]  R260      -4.9323320388793945e-01
    z[1,0,4]  R261      -3.2182257622480392e-02
    z[1,0,4]  R262      -1.8704400956630707e-01
    z[1,0,4]  R263      -2.5612348318099976e-01
    z[1,0,4]  R264      -3.5367685556411743e-01
    z[1,0,4]  R265      1.0367939621210098e-01
    z[1,0,4]  R266      1.9010002911090851e-01
    z[1,0,4]  R267      -4.0953093767166138e-01
    z[1,0,4]  R268      -2.8843152523040771e-01
    z[1,0,4]  R269      -1.7898014187812805e-01
    z[1,0,4]  R270      -2.9846525192260742e-01
    z[1,0,4]  R271      1.0212247818708420e-01
    z[1,0,4]  R272      -2.1296466886997223e-01
    z[1,0,4]  R273      -9.3044847249984741e-02
    z[1,0,4]  R274      1.7969395220279694e-01
    z[1,0,4]  R275      -3.8016852736473083e-01
    z[1,0,4]  R276      -5.0106018781661987e-01
    z[1,0,4]  R277      1.8553231656551361e-01
    z[1,0,4]  R278      1.1167474091053009e-01
    z[1,0,4]  R279      -2.5926116108894348e-01
    z[1,0,4]  R280      -2.1536377072334290e-01
    z[1,0,4]  R281      -1.9740676879882812e-01
    z[1,0,4]  R282      -2.5239869952201843e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R193      -1
    z[1,0,5]  R194      1
    z[1,0,5]  R197      4.1746962070465088e-01
    z[1,0,5]  R198      -4.2152579873800278e-02
    z[1,0,5]  R199      -3.6931574344635010e-01
    z[1,0,5]  R200      -0.0731348991394043
    z[1,0,5]  R201      2.7010822296142578e-01
    z[1,0,5]  R202      3.0007827281951904e-01
    z[1,0,5]  R203      -1.0756545513868332e-01
    z[1,0,5]  R204      -1.1789335310459137e-01
    z[1,0,5]  R205      -3.8339126110076904e-01
    z[1,0,5]  R206      4.2558598518371582e-01
    z[1,0,5]  R207      2.2750738263130188e-01
    z[1,0,5]  R208      -4.8899385333061218e-01
    z[1,0,5]  R209      3.1099513173103333e-01
    z[1,0,5]  R210      5.5458873510360718e-01
    z[1,0,5]  R211      -1.4815038442611694e-01
    z[1,0,5]  R212      3.8735222816467285e-01
    z[1,0,5]  R213      2.2368688881397247e-01
    z[1,0,5]  R214      4.8190298676490784e-01
    z[1,0,5]  R215      3.3627447485923767e-01
    z[1,0,5]  R216      5.3906667232513428e-01
    z[1,0,5]  R217      -0.274694561958313
    z[1,0,5]  R218      2.6330825686454773e-01
    z[1,0,5]  R219      0.846364438533783
    z[1,0,5]  R220      4.5080372691154480e-01
    z[1,0,5]  R221      -5.0654627382755280e-02
    z[1,0,5]  R222      2.3863463103771210e-01
    z[1,0,5]  R223      -1.7922644317150116e-01
    z[1,0,5]  R224      1.8534478545188904e-01
    z[1,0,5]  R225      3.1838840246200562e-01
    z[1,0,5]  R226      -1.6285143792629242e-01
    z[1,0,5]  R227      -2.6255920529365540e-01
    z[1,0,5]  R228      -1.8663893640041351e-01
    z[1,0,5]  R229      3.1805068254470825e-01
    z[1,0,5]  R230      -4.7559358179569244e-02
    z[1,0,5]  R231      -4.7271057963371277e-02
    z[1,0,5]  R232      7.4209690093994141e-02
    z[1,0,5]  R233      2.8233960270881653e-01
    z[1,0,5]  R234      -2.3085056245326996e-01
    z[1,0,5]  R235      3.6141827702522278e-02
    z[1,0,5]  R236      -1.6141220927238464e-01
    z[1,0,5]  R237      -1.2815786898136139e-01
    z[1,0,5]  R238      -1.2487945146858692e-02
    z[1,0,5]  R239      -8.2670869305729866e-03
    z[1,0,5]  R240      -6.7917510867118835e-02
    z[1,0,5]  R241      1.7979972064495087e-01
    z[1,0,5]  R242      -3.6516842246055603e-01
    z[1,0,5]  R243      6.0884922742843628e-01
    z[1,0,5]  R244      0.588984489440918
    z[1,0,5]  R245      5.3796172142028809e-01
    z[1,0,5]  R246      3.3902713656425476e-01
    z[1,0,5]  R247      -5.8717697858810425e-02
    z[1,0,5]  R248      3.5889267921447754e-01
    z[1,0,5]  R249      3.3878777176141739e-02
    z[1,0,5]  R250      1.9420199096202850e-01
    z[1,0,5]  R251      2.9188758134841919e-01
    z[1,0,5]  R252      -0.0816691666841507
    z[1,0,5]  R253      3.0651926994323730e-01
    z[1,0,5]  R254      3.0878382921218872e-01
    z[1,0,5]  R255      -1.2946107983589172e-01
    z[1,0,5]  R256      6.1762958765029907e-02
    z[1,0,5]  R257      1.4723029732704163e-01
    z[1,0,5]  R258      1.7835982143878937e-01
    z[1,0,5]  R259      1.3586243987083435e-01
    z[1,0,5]  R260      -1.5781633555889130e-01
    z[1,0,5]  R261      -0.512084424495697
    z[1,0,5]  R262      1.4620803296566010e-01
    z[1,0,5]  R263      3.5290205478668213e-01
    z[1,0,5]  R264      6.4368414878845215e-01
    z[1,0,5]  R265      2.0285930484533310e-02
    z[1,0,5]  R266      -4.1125866770744324e-01
    z[1,0,5]  R267      3.4659293293952942e-01
    z[1,0,5]  R268      -3.8214546442031860e-01
    z[1,0,5]  R269      -0.573047399520874
    z[1,0,5]  R270      2.0609468221664429e-02
    z[1,0,5]  R271      1.8222462385892868e-02
    z[1,0,5]  R272      1.5775173902511597e-02
    z[1,0,5]  R273      2.3029072582721710e-01
    z[1,0,5]  R274      1.9393661618232727e-01
    z[1,0,5]  R275      1.9587431848049164e-01
    z[1,0,5]  R276      6.6620707511901855e-01
    z[1,0,5]  R277      -2.7824527025222778e-01
    z[1,0,5]  R278      5.2504088729619980e-02
    z[1,0,5]  R279      -4.9292716383934021e-01
    z[1,0,5]  R280      -6.2025654315948486e-01
    z[1,0,5]  R281      -3.2653677463531494e-01
    z[1,0,5]  R282      -5.0747859477996826e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R195      -1
    z[1,0,6]  R196      1
    z[1,0,6]  R197      -2.8570449352264404e-01
    z[1,0,6]  R198      -8.4568858146667480e-02
    z[1,0,6]  R199      7.7060006558895111e-02
    z[1,0,6]  R200      -1.5992110967636108e-01
    z[1,0,6]  R201      -1.0853934288024902e-01
    z[1,0,6]  R202      -2.0229780673980713e-01
    z[1,0,6]  R203      -1.4012403786182404e-01
    z[1,0,6]  R204      -3.5348019003868103e-01
    z[1,0,6]  R205      3.8773542642593384e-01
    z[1,0,6]  R206      2.2128143906593323e-01
    z[1,0,6]  R207      -2.4946540594100952e-01
    z[1,0,6]  R208      -4.2940875887870789e-01
    z[1,0,6]  R209      -7.8437119722366333e-02
    z[1,0,6]  R210      4.6928480267524719e-01
    z[1,0,6]  R211      5.8387309312820435e-01
    z[1,0,6]  R212      -3.3137583732604980e-01
    z[1,0,6]  R213      -2.5254982709884644e-01
    z[1,0,6]  R214      -1.1425584554672241e-01
    z[1,0,6]  R215      -0.00990948174148798
    z[1,0,6]  R216      0.0760202705860138
    z[1,0,6]  R217      1.7826054990291595e-01
    z[1,0,6]  R218      -6.5391868352890015e-02
    z[1,0,6]  R219      -9.2143878340721130e-02
    z[1,0,6]  R220      -4.5621380209922791e-02
    z[1,0,6]  R221      -4.9721501767635345e-02
    z[1,0,6]  R222      -7.4934326112270355e-02
    z[1,0,6]  R223      1.3400943577289581e-01
    z[1,0,6]  R224      -1.4977841079235077e-01
    z[1,0,6]  R225      -1.6282552387565374e-03
    z[1,0,6]  R226      -3.3313891291618347e-01
    z[1,0,6]  R227      -1.4532597362995148e-01
    z[1,0,6]  R228      3.8116896152496338e-01
    z[1,0,6]  R229      -4.7986373305320740e-01
    z[1,0,6]  R230      -1.4161920547485352e-01
    z[1,0,6]  R231      1.2181732803583145e-01
    z[1,0,6]  R232      1.2550921738147736e-01
    z[1,0,6]  R233      -2.5886796414852142e-02
    z[1,0,6]  R234      -3.4271985292434692e-02
    z[1,0,6]  R235      -4.4414526224136353e-01
    z[1,0,6]  R236      3.4469828009605408e-01
    z[1,0,6]  R237      -5.5404454469680786e-01
    z[1,0,6]  R238      1.2178383767604828e-02
    z[1,0,6]  R239      3.5541403293609619e-01
    z[1,0,6]  R240      -2.9495045542716980e-01
    z[1,0,6]  R241      -5.8390267193317413e-02
    z[1,0,6]  R242      3.4440811723470688e-02
    z[1,0,6]  R243      1.9930483400821686e-01
    z[1,0,6]  R244      4.4936783611774445e-02
    z[1,0,6]  R245      -3.8677752017974854e-02
    z[1,0,6]  R246      1.8586240708827972e-01
    z[1,0,6]  R247      -8.8489718735218048e-02
    z[1,0,6]  R248      -4.6383913606405258e-02
    z[1,0,6]  R249      9.7954608500003815e-02
    z[1,0,6]  R250      -0.0748317539691925
    z[1,0,6]  R251      -1.3647177815437317e-01
    z[1,0,6]  R252      -2.6497521996498108e-01
    z[1,0,6]  R253      -0.512224018573761
    z[1,0,6]  R254      -3.0463767051696777e-01
    z[1,0,6]  R255      1.2235336750745773e-01
    z[1,0,6]  R256      -3.1091544032096863e-01
    z[1,0,6]  R257      1.4127552509307861e-01
    z[1,0,6]  R258      5.9519338607788086e-01
    z[1,0,6]  R259      4.1513332724571228e-01
    z[1,0,6]  R260      2.3035214841365814e-01
    z[1,0,6]  R261      -3.3378526568412781e-01
    z[1,0,6]  R262      -0.463827520608902
    z[1,0,6]  R263      5.8014723472297192e-03
    z[1,0,6]  R264      5.0654488801956177e-01
    z[1,0,6]  R265      -2.2041791677474976e-01
    z[1,0,6]  R266      -3.0166599154472351e-01
    z[1,0,6]  R267      -1.6432404518127441e-01
    z[1,0,6]  R268      -0.181470587849617
    z[1,0,6]  R269      -1.8777973949909210e-01
    z[1,0,6]  R270      2.8074988722801208e-01
    z[1,0,6]  R271      -3.6795702576637268e-01
    z[1,0,6]  R272      -1.0612189769744873e-02
    z[1,0,6]  R273      2.3235501348972321e-01
    z[1,0,6]  R274      3.6316907405853271e-01
    z[1,0,6]  R275      -4.8089629411697388e-01
    z[1,0,6]  R276      -3.8270026445388794e-01
    z[1,0,6]  R277      -4.1878035664558411e-01
    z[1,0,6]  R278      -3.1560999155044556e-01
    z[1,0,6]  R279      1.0177277773618698e-01
    z[1,0,6]  R280      9.6057072281837463e-02
    z[1,0,6]  R281      4.3198190629482269e-02
    z[1,0,6]  R282      2.4222043156623840e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R283      -1
    z[0,4,0]  R284      1
    z[0,4,0]  R297      -3.9479446411132812e-01
    z[0,4,0]  R298      -7.1644838899374008e-03
    z[0,4,0]  R299      1.7566068470478058e-01
    z[0,4,0]  R300      7.8504756093025208e-02
    z[0,4,0]  R301      -2.2681222856044769e-01
    z[0,4,0]  R302      -4.6323519945144653e-01
    z[0,4,0]  R303      0.0936773419380188
    z[0,4,0]  R304      -4.5889618992805481e-01
    z[0,4,0]  R305      -2.4875631928443909e-01
    z[0,4,0]  R306      -5.2680855989456177e-01
    z[0,4,0]  R307      7.0719575881958008e-01
    z[0,4,0]  R308      0.6134073138237
    z[0,4,0]  R309      6.9082254171371460e-01
    z[0,4,0]  R310      4.2688539624214172e-01
    z[0,4,0]  R311      3.9112001657485962e-01
    z[0,4,0]  R312      1.5688183903694153e-01
    z[0,4,0]  R313      2.4505098164081573e-01
    z[0,4,0]  R314      6.1353474855422974e-01
    z[0,4,0]  R315      6.3017058372497559e-01
    z[0,4,0]  R316      0.533696711063385
    z[0,4,0]  R317      -4.1174806654453278e-02
    z[0,4,0]  R318      -2.2101683914661407e-01
    z[0,4,0]  R319      2.3543527722358704e-01
    z[0,4,0]  R320      -4.1090536117553711e-01
    z[0,4,0]  R321      -2.8238549828529358e-01
    z[0,4,0]  R322      -6.5844398736953735e-01
    z[0,4,0]  R323      2.7941653132438660e-01
    z[0,4,0]  R324      1.9471745193004608e-01
    z[0,4,0]  R325      2.4684593081474304e-01
    z[0,4,0]  R326      -6.4855295419692993e-01
    z[0,4,0]  R327      -6.4152352511882782e-02
    z[0,4,0]  R328      -2.1554049849510193e-01
    z[0,4,0]  R329      -3.8296741247177124e-01
    z[0,4,0]  R330      -2.9756072163581848e-01
    z[0,4,0]  R331      -8.0398225784301758e-01
    z[0,4,0]  R332      -1.5241575241088867e-01
    z[0,4,0]  R333      -2.3599635809659958e-02
    z[0,4,0]  R334      2.5626775622367859e-01
    z[0,4,0]  R335      2.9781398177146912e-01
    z[0,4,0]  R336      1.8805319070816040e-01
    z[0,4,0]  R337      -4.7391787171363831e-01
    z[0,4,0]  R338      9.8290868103504181e-02
    z[0,4,0]  R339      -7.2330236434936523e-02
    z[0,4,0]  R340      -2.0658065378665924e-01
    z[0,4,0]  R341      0.511587917804718
    z[0,4,0]  R342      -3.8683310151100159e-02
    z[0,4,0]  R343      2.7261814475059509e-01
    z[0,4,0]  R344      -4.4772675633430481e-01
    z[0,4,0]  R345      2.7434009313583374e-01
    z[0,4,0]  R346      -6.1960822343826294e-01
    z[0,4,0]  R347      -2.3314456641674042e-01
    z[0,4,0]  R348      2.1505402028560638e-01
    z[0,4,0]  R349      -3.5934236645698547e-01
    z[0,4,0]  R350      -4.7247186303138733e-01
    z[0,4,0]  R351      -5.6366211175918579e-01
    z[0,4,0]  R352      1.6025616228580475e-01
    z[0,4,0]  R353      -4.7844117879867554e-01
    z[0,4,0]  R354      4.9190583825111389e-01
    z[0,4,0]  R355      3.6162805557250977e-01
    z[0,4,0]  R356      -3.7239813804626465e-01
    z[0,4,0]  R357      -3.0806419253349304e-01
    z[0,4,0]  R358      1.1876897513866425e-01
    z[0,4,0]  R359      1.5820379555225372e-01
    z[0,4,0]  R360      3.1624826788902283e-01
    z[0,4,0]  R361      2.8448304533958435e-01
    z[0,4,0]  R362      2.8737327456474304e-01
    z[0,4,0]  R363      1.4233843982219696e-01
    z[0,4,0]  R364      3.8168802857398987e-02
    z[0,4,0]  R365      -3.0492378398776054e-02
    z[0,4,0]  R366      1.7495785653591156e-01
    z[0,4,0]  R367      3.1280374526977539e-01
    z[0,4,0]  R368      -3.6479675769805908e-01
    z[0,4,0]  R369      -7.0757251977920532e-01
    z[0,4,0]  R370      -7.7134460210800171e-01
    z[0,4,0]  R371      -7.6169526576995850e-01
    z[0,4,0]  R372      0.670039713382721
    z[0,4,0]  R373      -6.3153463602066040e-01
    z[0,4,0]  R374      -2.7676162123680115e-01
    z[0,4,0]  R375      1.0108610242605209e-01
    z[0,4,0]  R376      0.219046488404274
    z[0,4,0]  R377      2.5553833693265915e-03
    z[0,4,0]  R378      1.3077133893966675e-01
    z[0,4,0]  R379      -3.1307630240917206e-02
    z[0,4,0]  R380      3.9913639426231384e-01
    z[0,4,0]  R381      2.7574592828750610e-01
    z[0,4,0]  R382      0.0935889184474945
    z[0,4,0]  R383      -4.4590409845113754e-02
    z[0,4,0]  R384      2.5477501749992371e-01
    z[0,4,0]  R385      1.4936186373233795e-01
    z[0,4,0]  R386      2.3234197497367859e-01
    z[0,4,0]  R387      4.9659404903650284e-02
    z[0,4,0]  R388      -0.358368843793869
    z[0,4,0]  R389      2.0152449607849121e-01
    z[0,4,0]  R390      -2.3189561069011688e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R285      -1
    z[0,4,1]  R286      1
    z[0,4,1]  R297      -3.7504711747169495e-01
    z[0,4,1]  R298      -2.5783985853195190e-02
    z[0,4,1]  R299      -3.3422711491584778e-01
    z[0,4,1]  R300      -3.5029903054237366e-01
    z[0,4,1]  R301      4.9680642783641815e-02
    z[0,4,1]  R302      1.2528367340564728e-01
    z[0,4,1]  R303      3.9745840430259705e-01
    z[0,4,1]  R304      6.4624166488647461e-01
    z[0,4,1]  R305      3.3386969566345215e-01
    z[0,4,1]  R306      4.9182033538818359e-01
    z[0,4,1]  R307      -5.9345859289169312e-01
    z[0,4,1]  R308      -0.574647843837738
    z[0,4,1]  R309      -4.8191988468170166e-01
    z[0,4,1]  R310      -6.6034138202667236e-01
    z[0,4,1]  R311      8.1128066778182983e-01
    z[0,4,1]  R312      7.6293140649795532e-01
    z[0,4,1]  R313      0.261626660823822
    z[0,4,1]  R314      2.8607034683227539e-01
    z[0,4,1]  R315      3.0158591270446777e-01
    z[0,4,1]  R316      3.2507914304733276e-01
    z[0,4,1]  R317      -3.8137458264827728e-02
    z[0,4,1]  R318      9.3860030174255371e-01
    z[0,4,1]  R319      5.7797157764434814e-01
    z[0,4,1]  R320      7.6948130130767822e-01
    z[0,4,1]  R321      7.0045018196105957e-01
    z[0,4,1]  R322      2.2301225364208221e-01
    z[0,4,1]  R323      5.5432754755020142e-01
    z[0,4,1]  R324      -0.735713005065918
    z[0,4,1]  R325      4.2580845952033997e-01
    z[0,4,1]  R326      2.6165801286697388e-01
    z[0,4,1]  R327      1.5105303376913071e-02
    z[0,4,1]  R328      3.5461014509201050e-01
    z[0,4,1]  R329      2.8842544555664062e-01
    z[0,4,1]  R330      4.8079398274421692e-01
    z[0,4,1]  R331      4.1632503271102905e-01
    z[0,4,1]  R332      7.3749560117721558e-01
    z[0,4,1]  R333      8.9738404750823975e-01
    z[0,4,1]  R334      6.3835614919662476e-01
    z[0,4,1]  R335      5.9868997335433960e-01
    z[0,4,1]  R336      7.7419120073318481e-01
    z[0,4,1]  R337      3.2915085554122925e-01
    z[0,4,1]  R338      3.9533627033233643e-01
    z[0,4,1]  R339      8.8824760913848877e-01
    z[0,4,1]  R340      0.877727210521698
    z[0,4,1]  R341      4.2683750391006470e-01
    z[0,4,1]  R342      3.0805489420890808e-01
    z[0,4,1]  R343      8.3055114746093750e-01
    z[0,4,1]  R344      1.3095045089721680e-01
    z[0,4,1]  R345      -5.9901338815689087e-01
    z[0,4,1]  R346      -1.9765254110097885e-02
    z[0,4,1]  R347      -2.4018374085426331e-01
    z[0,4,1]  R348      2.2535805404186249e-01
    z[0,4,1]  R349      8.8200157880783081e-01
    z[0,4,1]  R350      1.5178048610687256e-01
    z[0,4,1]  R351      1.4478464424610138e-01
    z[0,4,1]  R352      -8.1214743852615356e-01
    z[0,4,1]  R353      -5.2411098033189774e-02
    z[0,4,1]  R354      0.616611659526825
    z[0,4,1]  R355      0.82222580909729
    z[0,4,1]  R356      9.0921252965927124e-02
    z[0,4,1]  R357      5.0547677278518677e-01
    z[0,4,1]  R358      0.720435380935669
    z[0,4,1]  R359      4.8574465513229370e-01
    z[0,4,1]  R360      0.200750932097435
    z[0,4,1]  R361      -7.4452996253967285e-01
    z[0,4,1]  R362      8.5937988758087158e-01
    z[0,4,1]  R363      -3.5893049091100693e-02
    z[0,4,1]  R364      1.5119243413209915e-02
    z[0,4,1]  R365      0.0903463065624237
    z[0,4,1]  R366      1.1638209223747253e-01
    z[0,4,1]  R367      -4.2932558059692383e-01
    z[0,4,1]  R368      -6.7576491832733154e-01
    z[0,4,1]  R369      2.0904146134853363e-01
    z[0,4,1]  R370      4.9067354202270508e-01
    z[0,4,1]  R371      4.0315636992454529e-01
    z[0,4,1]  R372      4.1437533497810364e-01
    z[0,4,1]  R373      1.3012956082820892e-01
    z[0,4,1]  R374      0.589113175868988
    z[0,4,1]  R375      3.9583536982536316e-01
    z[0,4,1]  R376      3.5854130983352661e-01
    z[0,4,1]  R377      3.7020951509475708e-01
    z[0,4,1]  R378      7.5881212949752808e-01
    z[0,4,1]  R379      3.9203503727912903e-01
    z[0,4,1]  R380      -5.6707769632339478e-01
    z[0,4,1]  R381      -2.9880559444427490e-01
    z[0,4,1]  R382      2.4329890310764313e-01
    z[0,4,1]  R383      -2.1724271774291992e-01
    z[0,4,1]  R384      -6.3097810745239258e-01
    z[0,4,1]  R385      -4.3904387950897217e-01
    z[0,4,1]  R386      7.1723777055740356e-01
    z[0,4,1]  R387      4.3934261798858643e-01
    z[0,4,1]  R388      -1.7849127948284149e-01
    z[0,4,1]  R389      7.4805237352848053e-02
    z[0,4,1]  R390      0.0457318089902401
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R287      -1
    z[0,4,2]  R288      1
    z[0,4,2]  R297      -2.8222200274467468e-01
    z[0,4,2]  R298      -7.0818763971328735e-01
    z[0,4,2]  R299      -0.651944637298584
    z[0,4,2]  R300      -5.8991187810897827e-01
    z[0,4,2]  R301      -3.4730535745620728e-01
    z[0,4,2]  R302      -6.0387951135635376e-01
    z[0,4,2]  R303      -0.27772057056427
    z[0,4,2]  R304      -2.9529851675033569e-01
    z[0,4,2]  R305      -4.0939885377883911e-01
    z[0,4,2]  R306      -3.5868924856185913e-01
    z[0,4,2]  R307      3.0828040838241577e-01
    z[0,4,2]  R308      4.5731565356254578e-01
    z[0,4,2]  R309      3.3518549799919128e-01
    z[0,4,2]  R310      4.4903567433357239e-01
    z[0,4,2]  R311      -1.2298995256423950e-01
    z[0,4,2]  R312      3.8961014151573181e-01
    z[0,4,2]  R313      7.5684711337089539e-02
    z[0,4,2]  R314      5.4651558399200439e-01
    z[0,4,2]  R315      4.6327370405197144e-01
    z[0,4,2]  R316      7.1334266662597656e-01
    z[0,4,2]  R317      -2.5875192880630493e-01
    z[0,4,2]  R318      3.3265821635723114e-02
    z[0,4,2]  R319      -2.8829440474510193e-01
    z[0,4,2]  R320      -1.6742104291915894e-01
    z[0,4,2]  R321      -1.5327529981732368e-02
    z[0,4,2]  R322      -2.2643579542636871e-01
    z[0,4,2]  R323      -4.5030519366264343e-01
    z[0,4,2]  R324      -4.2532366514205933e-01
    z[0,4,2]  R325      8.2564197480678558e-02
    z[0,4,2]  R326      -4.2296311259269714e-01
    z[0,4,2]  R327      0.0939294695854187
    z[0,4,2]  R328      5.1697814464569092e-01
    z[0,4,2]  R329      4.8295497894287109e-01
    z[0,4,2]  R330      0.530137300491333
    z[0,4,2]  R331      -1.3428612053394318e-01
    z[0,4,2]  R332      2.9846025630831718e-02
    z[0,4,2]  R333      2.1396109461784363e-01
    z[0,4,2]  R334      -1.9447919726371765e-01
    z[0,4,2]  R335      1.6164864599704742e-01
    z[0,4,2]  R336      -4.8067551851272583e-01
    z[0,4,2]  R337      3.7510451674461365e-01
    z[0,4,2]  R338      2.3092246055603027e-01
    z[0,4,2]  R339      -2.2959072887897491e-01
    z[0,4,2]  R340      -1.6290232539176941e-01
    z[0,4,2]  R341      -4.5549508929252625e-01
    z[0,4,2]  R342      -5.5159491300582886e-01
    z[0,4,2]  R343      -2.0587055385112762e-01
    z[0,4,2]  R344      -6.7763239145278931e-01
    z[0,4,2]  R345      -3.8402143120765686e-01
    z[0,4,2]  R346      -3.8673040270805359e-01
    z[0,4,2]  R347      -2.3727035522460938e-01
    z[0,4,2]  R348      8.1480335211381316e-04
    z[0,4,2]  R349      -7.0957783609628677e-03
    z[0,4,2]  R350      4.7249630093574524e-01
    z[0,4,2]  R351      -4.6459707617759705e-01
    z[0,4,2]  R352      -1.9321471452713013e-01
    z[0,4,2]  R353      4.0367519855499268e-01
    z[0,4,2]  R354      3.6768182180821896e-03
    z[0,4,2]  R355      2.1117500960826874e-01
    z[0,4,2]  R356      -7.9911732673645020e-01
    z[0,4,2]  R357      2.7404162287712097e-01
    z[0,4,2]  R358      -2.1417331695556641e-01
    z[0,4,2]  R359      -2.6037716865539551e-01
    z[0,4,2]  R360      -8.3167001605033875e-02
    z[0,4,2]  R361      -0.0464789904654026
    z[0,4,2]  R362      2.4752826988697052e-01
    z[0,4,2]  R363      0.0690079852938652
    z[0,4,2]  R364      -1.9208157435059547e-02
    z[0,4,2]  R365      -2.4218328297138214e-01
    z[0,4,2]  R366      1.1183889955282211e-01
    z[0,4,2]  R367      2.2591508924961090e-01
    z[0,4,2]  R368      -2.1254327893257141e-01
    z[0,4,2]  R369      -5.9841352701187134e-01
    z[0,4,2]  R370      8.1337429583072662e-02
    z[0,4,2]  R371      7.7377937734127045e-02
    z[0,4,2]  R372      -2.5290283560752869e-01
    z[0,4,2]  R373      2.1290490031242371e-01
    z[0,4,2]  R374      -5.2991569042205811e-01
    z[0,4,2]  R375      -2.7966782450675964e-01
    z[0,4,2]  R376      -3.1875881552696228e-01
    z[0,4,2]  R377      5.4847621917724609e-01
    z[0,4,2]  R378      6.5688274800777435e-02
    z[0,4,2]  R379      4.2364135384559631e-01
    z[0,4,2]  R380      1.5305852284654975e-03
    z[0,4,2]  R381      -4.8518818616867065e-01
    z[0,4,2]  R382      8.3909317851066589e-02
    z[0,4,2]  R383      1.3591116666793823e-01
    z[0,4,2]  R384      -3.6270821094512939e-01
    z[0,4,2]  R385      -2.5830566883087158e-01
    z[0,4,2]  R386      3.8193327188491821e-01
    z[0,4,2]  R387      -1.3486935198307037e-01
    z[0,4,2]  R388      3.7739354372024536e-01
    z[0,4,2]  R389      -7.0517137646675110e-02
    z[0,4,2]  R390      -1.8015700578689575e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R289      -1
    z[0,4,3]  R290      1
    z[0,4,3]  R297      -6.8621051311492920e-01
    z[0,4,3]  R298      -2.5275599956512451e-01
    z[0,4,3]  R299      -4.9141255021095276e-01
    z[0,4,3]  R300      -4.5514798164367676e-01
    z[0,4,3]  R301      -8.4004592895507812e-01
    z[0,4,3]  R302      -2.7963468432426453e-01
    z[0,4,3]  R303      -1.3276250660419464e-01
    z[0,4,3]  R304      5.9658315032720566e-02
    z[0,4,3]  R305      -5.3083121776580811e-01
    z[0,4,3]  R306      -4.5202895998954773e-01
    z[0,4,3]  R307      1.0881885886192322e-02
    z[0,4,3]  R308      1.5948741137981415e-01
    z[0,4,3]  R309      2.7570670843124390e-01
    z[0,4,3]  R310      -1.8218036741018295e-02
    z[0,4,3]  R311      2.2762574255466461e-01
    z[0,4,3]  R312      2.1701575815677643e-01
    z[0,4,3]  R313      0.722253143787384
    z[0,4,3]  R314      -1.1596355587244034e-01
    z[0,4,3]  R315      3.2577980309724808e-02
    z[0,4,3]  R316      -2.0400810241699219e-01
    z[0,4,3]  R317      -8.4571164846420288e-01
    z[0,4,3]  R318      1.3899172656238079e-02
    z[0,4,3]  R319      -0.503036379814148
    z[0,4,3]  R320      1.9249898195266724e-01
    z[0,4,3]  R321      1.7376442253589630e-01
    z[0,4,3]  R322      2.0377150177955627e-01
    z[0,4,3]  R323      5.3218871355056763e-01
    z[0,4,3]  R324      3.7639716267585754e-01
    z[0,4,3]  R325      8.0569308996200562e-01
    z[0,4,3]  R326      1.9111488759517670e-01
    z[0,4,3]  R327      -6.7610043287277222e-01
    z[0,4,3]  R328      -2.5543466210365295e-01
    z[0,4,3]  R329      -2.9475077986717224e-01
    z[0,4,3]  R330      -3.6603674292564392e-01
    z[0,4,3]  R331      -3.1473973393440247e-01
    z[0,4,3]  R332      4.0507054328918457e-01
    z[0,4,3]  R333      3.4312078356742859e-01
    z[0,4,3]  R334      6.6566234827041626e-01
    z[0,4,3]  R335      6.0403460264205933e-01
    z[0,4,3]  R336      1.8613217771053314e-01
    z[0,4,3]  R337      -4.0200895071029663e-01
    z[0,4,3]  R338      -4.2520660161972046e-01
    z[0,4,3]  R339      3.1519877910614014e-01
    z[0,4,3]  R340      1.3571046292781830e-01
    z[0,4,3]  R341      -4.4724997878074646e-01
    z[0,4,3]  R342      -4.7054540365934372e-02
    z[0,4,3]  R343      3.4226789139211178e-03
    z[0,4,3]  R344      4.4271681457757950e-02
    z[0,4,3]  R345      2.0921096205711365e-01
    z[0,4,3]  R346      4.4117620587348938e-01
    z[0,4,3]  R347      -8.0092787742614746e-01
    z[0,4,3]  R348      -3.2704836130142212e-01
    z[0,4,3]  R349      1.8207387626171112e-01
    z[0,4,3]  R350      -4.8394846916198730e-01
    z[0,4,3]  R351      0.361424058675766
    z[0,4,3]  R352      1.2346322089433670e-01
    z[0,4,3]  R353      -4.5794636011123657e-01
    z[0,4,3]  R354      4.5768809318542480e-01
    z[0,4,3]  R355      -4.9208205193281174e-02
    z[0,4,3]  R356      4.1079086065292358e-01
    z[0,4,3]  R357      -6.7735582590103149e-01
    z[0,4,3]  R358      -4.6819177269935608e-01
    z[0,4,3]  R359      -5.0702202320098877e-01
    z[0,4,3]  R360      -1.0684862732887268e-01
    z[0,4,3]  R361      2.7452594041824341e-01
    z[0,4,3]  R362      -5.2677791565656662e-02
    z[0,4,3]  R363      8.0816954374313354e-01
    z[0,4,3]  R364      7.4673879146575928e-01
    z[0,4,3]  R365      8.8588553667068481e-01
    z[0,4,3]  R366      0.750617504119873
    z[0,4,3]  R367      -8.1339550018310547e-01
    z[0,4,3]  R368      -4.8179841041564941e-01
    z[0,4,3]  R369      1.5598054230213165e-01
    z[0,4,3]  R370      -1.5040325000882149e-02
    z[0,4,3]  R371      1.8572627007961273e-01
    z[0,4,3]  R372      7.1286216378211975e-02
    z[0,4,3]  R373      3.1809020042419434e-01
    z[0,4,3]  R374      5.2645099163055420e-01
    z[0,4,3]  R375      -1.3016305863857269e-01
    z[0,4,3]  R376      -1.0045634955167770e-01
    z[0,4,3]  R377      3.8470726460218430e-02
    z[0,4,3]  R378      -3.2603898644447327e-01
    z[0,4,3]  R379      -3.5169713199138641e-02
    z[0,4,3]  R380      0.541219174861908
    z[0,4,3]  R381      1.1270406842231750e-01
    z[0,4,3]  R382      5.0854027271270752e-01
    z[0,4,3]  R383      5.4692953824996948e-01
    z[0,4,3]  R384      2.6314312219619751e-01
    z[0,4,3]  R385      2.2490815818309784e-01
    z[0,4,3]  R386      4.4447129964828491e-01
    z[0,4,3]  R387      -3.0794769525527954e-01
    z[0,4,3]  R388      1.0301160067319870e-01
    z[0,4,3]  R389      4.4565784931182861e-01
    z[0,4,3]  R390      8.9852446317672729e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R291      -1
    z[0,4,4]  R292      1
    z[0,4,4]  R297      -1.9780221581459045e-01
    z[0,4,4]  R298      4.3426206707954407e-01
    z[0,4,4]  R299      2.7881652116775513e-01
    z[0,4,4]  R300      -1.3999934494495392e-01
    z[0,4,4]  R301      1.1205311119556427e-01
    z[0,4,4]  R302      5.0323325395584106e-01
    z[0,4,4]  R303      1.1693440377712250e-01
    z[0,4,4]  R304      2.7517375349998474e-01
    z[0,4,4]  R305      6.1010152101516724e-01
    z[0,4,4]  R306      2.9160878062248230e-01
    z[0,4,4]  R307      -4.9447748810052872e-02
    z[0,4,4]  R308      0.0463813841342926
    z[0,4,4]  R309      -2.7928104624152184e-02
    z[0,4,4]  R310      2.0555068552494049e-01
    z[0,4,4]  R311      -1.7847079038619995e-01
    z[0,4,4]  R312      -1.1961609870195389e-01
    z[0,4,4]  R313      -1.1268706619739532e-01
    z[0,4,4]  R314      4.5529574155807495e-01
    z[0,4,4]  R315      5.2836841344833374e-01
    z[0,4,4]  R316      1.9430550932884216e-01
    z[0,4,4]  R317      3.6644729971885681e-01
    z[0,4,4]  R318      -1.2006153166294098e-01
    z[0,4,4]  R319      -2.7529746294021606e-01
    z[0,4,4]  R320      -1.7058400809764862e-01
    z[0,4,4]  R321      -2.7533468604087830e-01
    z[0,4,4]  R322      -6.5085852146148682e-01
    z[0,4,4]  R323      4.7541882842779160e-02
    z[0,4,4]  R324      -8.1411756575107574e-02
    z[0,4,4]  R325      -2.5701868534088135e-01
    z[0,4,4]  R326      -4.0119481086730957e-01
    z[0,4,4]  R327      -3.4540107846260071e-01
    z[0,4,4]  R328      -3.8256838917732239e-01
    z[0,4,4]  R329      -0.398904025554657
    z[0,4,4]  R330      -3.4026777744293213e-01
    z[0,4,4]  R331      -2.2784620523452759e-01
    z[0,4,4]  R332      -3.7005582451820374e-01
    z[0,4,4]  R333      1.4103437960147858e-01
    z[0,4,4]  R334      5.0847832113504410e-02
    z[0,4,4]  R335      -2.4096952378749847e-01
    z[0,4,4]  R336      1.5062609314918518e-01
    z[0,4,4]  R337      -9.1757416725158691e-02
    z[0,4,4]  R338      -6.4169371128082275e-01
    z[0,4,4]  R339      -1.4829677343368530e-01
    z[0,4,4]  R340      -2.0367094874382019e-01
    z[0,4,4]  R341      -3.2702258229255676e-01
    z[0,4,4]  R342      -4.5942065119743347e-01
    z[0,4,4]  R343      5.1726657897233963e-02
    z[0,4,4]  R344      -4.9323320388793945e-01
    z[0,4,4]  R345      -3.2182257622480392e-02
    z[0,4,4]  R346      -1.8704400956630707e-01
    z[0,4,4]  R347      -2.5612348318099976e-01
    z[0,4,4]  R348      -3.5367685556411743e-01
    z[0,4,4]  R349      1.0367939621210098e-01
    z[0,4,4]  R350      1.9010002911090851e-01
    z[0,4,4]  R351      -4.0953093767166138e-01
    z[0,4,4]  R352      -2.8843152523040771e-01
    z[0,4,4]  R353      -1.7898014187812805e-01
    z[0,4,4]  R354      -2.9846525192260742e-01
    z[0,4,4]  R355      1.0212247818708420e-01
    z[0,4,4]  R356      -2.1296466886997223e-01
    z[0,4,4]  R357      -9.3044847249984741e-02
    z[0,4,4]  R358      1.7969395220279694e-01
    z[0,4,4]  R359      -3.8016852736473083e-01
    z[0,4,4]  R360      -5.0106018781661987e-01
    z[0,4,4]  R361      1.8553231656551361e-01
    z[0,4,4]  R362      1.1167474091053009e-01
    z[0,4,4]  R363      -2.5926116108894348e-01
    z[0,4,4]  R364      -2.1536377072334290e-01
    z[0,4,4]  R365      -1.9740676879882812e-01
    z[0,4,4]  R366      -2.5239869952201843e-01
    z[0,4,4]  R367      6.3242472708225250e-02
    z[0,4,4]  R368      2.1984401345252991e-01
    z[0,4,4]  R369      -2.3649795353412628e-01
    z[0,4,4]  R370      2.2370700538158417e-01
    z[0,4,4]  R371      -3.5109555721282959e-01
    z[0,4,4]  R372      -0.0685136467218399
    z[0,4,4]  R373      2.7055370807647705e-01
    z[0,4,4]  R374      -3.9472747594118118e-02
    z[0,4,4]  R375      1.1186251044273376e-01
    z[0,4,4]  R376      7.6634413003921509e-01
    z[0,4,4]  R377      -5.8889114856719971e-01
    z[0,4,4]  R378      4.3271717429161072e-01
    z[0,4,4]  R379      6.4112299680709839e-01
    z[0,4,4]  R380      3.5008779168128967e-01
    z[0,4,4]  R381      -3.7443917989730835e-01
    z[0,4,4]  R382      -8.1466743722558022e-03
    z[0,4,4]  R383      -1.6769704222679138e-01
    z[0,4,4]  R384      -0.322881281375885
    z[0,4,4]  R385      -6.3616609573364258e-01
    z[0,4,4]  R386      2.9244709014892578e-01
    z[0,4,4]  R387      3.8723675534129143e-03
    z[0,4,4]  R388      -4.5999753475189209e-01
    z[0,4,4]  R389      3.3557209372520447e-01
    z[0,4,4]  R390      3.5253819078207016e-02
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R293      -1
    z[0,4,5]  R294      1
    z[0,4,5]  R297      2.2368688881397247e-01
    z[0,4,5]  R298      4.8190298676490784e-01
    z[0,4,5]  R299      3.3627447485923767e-01
    z[0,4,5]  R300      5.3906667232513428e-01
    z[0,4,5]  R301      -0.274694561958313
    z[0,4,5]  R302      2.6330825686454773e-01
    z[0,4,5]  R303      0.846364438533783
    z[0,4,5]  R304      4.5080372691154480e-01
    z[0,4,5]  R305      -5.0654627382755280e-02
    z[0,4,5]  R306      2.3863463103771210e-01
    z[0,4,5]  R307      -1.7922644317150116e-01
    z[0,4,5]  R308      1.8534478545188904e-01
    z[0,4,5]  R309      3.1838840246200562e-01
    z[0,4,5]  R310      -1.6285143792629242e-01
    z[0,4,5]  R311      -2.6255920529365540e-01
    z[0,4,5]  R312      -1.8663893640041351e-01
    z[0,4,5]  R313      3.1805068254470825e-01
    z[0,4,5]  R314      -4.7559358179569244e-02
    z[0,4,5]  R315      -4.7271057963371277e-02
    z[0,4,5]  R316      7.4209690093994141e-02
    z[0,4,5]  R317      2.8233960270881653e-01
    z[0,4,5]  R318      -2.3085056245326996e-01
    z[0,4,5]  R319      3.6141827702522278e-02
    z[0,4,5]  R320      -1.6141220927238464e-01
    z[0,4,5]  R321      -1.2815786898136139e-01
    z[0,4,5]  R322      -1.2487945146858692e-02
    z[0,4,5]  R323      -8.2670869305729866e-03
    z[0,4,5]  R324      -6.7917510867118835e-02
    z[0,4,5]  R325      1.7979972064495087e-01
    z[0,4,5]  R326      -3.6516842246055603e-01
    z[0,4,5]  R327      6.0884922742843628e-01
    z[0,4,5]  R328      0.588984489440918
    z[0,4,5]  R329      5.3796172142028809e-01
    z[0,4,5]  R330      3.3902713656425476e-01
    z[0,4,5]  R331      -5.8717697858810425e-02
    z[0,4,5]  R332      3.5889267921447754e-01
    z[0,4,5]  R333      3.3878777176141739e-02
    z[0,4,5]  R334      1.9420199096202850e-01
    z[0,4,5]  R335      2.9188758134841919e-01
    z[0,4,5]  R336      -0.0816691666841507
    z[0,4,5]  R337      3.0651926994323730e-01
    z[0,4,5]  R338      3.0878382921218872e-01
    z[0,4,5]  R339      -1.2946107983589172e-01
    z[0,4,5]  R340      6.1762958765029907e-02
    z[0,4,5]  R341      1.4723029732704163e-01
    z[0,4,5]  R342      1.7835982143878937e-01
    z[0,4,5]  R343      1.3586243987083435e-01
    z[0,4,5]  R344      -1.5781633555889130e-01
    z[0,4,5]  R345      -0.512084424495697
    z[0,4,5]  R346      1.4620803296566010e-01
    z[0,4,5]  R347      3.5290205478668213e-01
    z[0,4,5]  R348      6.4368414878845215e-01
    z[0,4,5]  R349      2.0285930484533310e-02
    z[0,4,5]  R350      -4.1125866770744324e-01
    z[0,4,5]  R351      3.4659293293952942e-01
    z[0,4,5]  R352      -3.8214546442031860e-01
    z[0,4,5]  R353      -0.573047399520874
    z[0,4,5]  R354      2.0609468221664429e-02
    z[0,4,5]  R355      1.8222462385892868e-02
    z[0,4,5]  R356      1.5775173902511597e-02
    z[0,4,5]  R357      2.3029072582721710e-01
    z[0,4,5]  R358      1.9393661618232727e-01
    z[0,4,5]  R359      1.9587431848049164e-01
    z[0,4,5]  R360      6.6620707511901855e-01
    z[0,4,5]  R361      -2.7824527025222778e-01
    z[0,4,5]  R362      5.2504088729619980e-02
    z[0,4,5]  R363      -4.9292716383934021e-01
    z[0,4,5]  R364      -6.2025654315948486e-01
    z[0,4,5]  R365      -3.2653677463531494e-01
    z[0,4,5]  R366      -5.0747859477996826e-01
    z[0,4,5]  R367      -3.0946649610996246e-02
    z[0,4,5]  R368      0.0421551950275898
    z[0,4,5]  R369      1.2816968560218811e-01
    z[0,4,5]  R370      -2.3789976537227631e-01
    z[0,4,5]  R371      2.2226135432720184e-01
    z[0,4,5]  R372      3.9653125405311584e-01
    z[0,4,5]  R373      6.0311287641525269e-01
    z[0,4,5]  R374      1.2090355157852173e-01
    z[0,4,5]  R375      8.4526848793029785e-01
    z[0,4,5]  R376      2.6858550310134888e-01
    z[0,4,5]  R377      4.5679005980491638e-01
    z[0,4,5]  R378      -2.0484769344329834e-01
    z[0,4,5]  R379      2.6183694601058960e-01
    z[0,4,5]  R380      -1.2768730521202087e-01
    z[0,4,5]  R381      -4.4617816805839539e-01
    z[0,4,5]  R382      -7.9233056306838989e-01
    z[0,4,5]  R383      -4.1353252530097961e-01
    z[0,4,5]  R384      -2.7373023331165314e-02
    z[0,4,5]  R385      1.9302488863468170e-01
    z[0,4,5]  R386      2.4049438536167145e-02
    z[0,4,5]  R387      0.817222535610199
    z[0,4,5]  R388      -6.8864285945892334e-01
    z[0,4,5]  R389      7.9849857091903687e-01
    z[0,4,5]  R390      -3.0883839726448059e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R295      -1
    z[0,4,6]  R296      1
    z[0,4,6]  R297      -2.5254982709884644e-01
    z[0,4,6]  R298      -1.1425584554672241e-01
    z[0,4,6]  R299      -0.00990948174148798
    z[0,4,6]  R300      0.0760202705860138
    z[0,4,6]  R301      1.7826054990291595e-01
    z[0,4,6]  R302      -6.5391868352890015e-02
    z[0,4,6]  R303      -9.2143878340721130e-02
    z[0,4,6]  R304      -4.5621380209922791e-02
    z[0,4,6]  R305      -4.9721501767635345e-02
    z[0,4,6]  R306      -7.4934326112270355e-02
    z[0,4,6]  R307      1.3400943577289581e-01
    z[0,4,6]  R308      -1.4977841079235077e-01
    z[0,4,6]  R309      -1.6282552387565374e-03
    z[0,4,6]  R310      -3.3313891291618347e-01
    z[0,4,6]  R311      -1.4532597362995148e-01
    z[0,4,6]  R312      3.8116896152496338e-01
    z[0,4,6]  R313      -4.7986373305320740e-01
    z[0,4,6]  R314      -1.4161920547485352e-01
    z[0,4,6]  R315      1.2181732803583145e-01
    z[0,4,6]  R316      1.2550921738147736e-01
    z[0,4,6]  R317      -2.5886796414852142e-02
    z[0,4,6]  R318      -3.4271985292434692e-02
    z[0,4,6]  R319      -4.4414526224136353e-01
    z[0,4,6]  R320      3.4469828009605408e-01
    z[0,4,6]  R321      -5.5404454469680786e-01
    z[0,4,6]  R322      1.2178383767604828e-02
    z[0,4,6]  R323      3.5541403293609619e-01
    z[0,4,6]  R324      -2.9495045542716980e-01
    z[0,4,6]  R325      -5.8390267193317413e-02
    z[0,4,6]  R326      3.4440811723470688e-02
    z[0,4,6]  R327      1.9930483400821686e-01
    z[0,4,6]  R328      4.4936783611774445e-02
    z[0,4,6]  R329      -3.8677752017974854e-02
    z[0,4,6]  R330      1.8586240708827972e-01
    z[0,4,6]  R331      -8.8489718735218048e-02
    z[0,4,6]  R332      -4.6383913606405258e-02
    z[0,4,6]  R333      9.7954608500003815e-02
    z[0,4,6]  R334      -0.0748317539691925
    z[0,4,6]  R335      -1.3647177815437317e-01
    z[0,4,6]  R336      -2.6497521996498108e-01
    z[0,4,6]  R337      -0.512224018573761
    z[0,4,6]  R338      -3.0463767051696777e-01
    z[0,4,6]  R339      1.2235336750745773e-01
    z[0,4,6]  R340      -3.1091544032096863e-01
    z[0,4,6]  R341      1.4127552509307861e-01
    z[0,4,6]  R342      5.9519338607788086e-01
    z[0,4,6]  R343      4.1513332724571228e-01
    z[0,4,6]  R344      2.3035214841365814e-01
    z[0,4,6]  R345      -3.3378526568412781e-01
    z[0,4,6]  R346      -0.463827520608902
    z[0,4,6]  R347      5.8014723472297192e-03
    z[0,4,6]  R348      5.0654488801956177e-01
    z[0,4,6]  R349      -2.2041791677474976e-01
    z[0,4,6]  R350      -3.0166599154472351e-01
    z[0,4,6]  R351      -1.6432404518127441e-01
    z[0,4,6]  R352      -0.181470587849617
    z[0,4,6]  R353      -1.8777973949909210e-01
    z[0,4,6]  R354      2.8074988722801208e-01
    z[0,4,6]  R355      -3.6795702576637268e-01
    z[0,4,6]  R356      -1.0612189769744873e-02
    z[0,4,6]  R357      2.3235501348972321e-01
    z[0,4,6]  R358      3.6316907405853271e-01
    z[0,4,6]  R359      -4.8089629411697388e-01
    z[0,4,6]  R360      -3.8270026445388794e-01
    z[0,4,6]  R361      -4.1878035664558411e-01
    z[0,4,6]  R362      -3.1560999155044556e-01
    z[0,4,6]  R363      1.0177277773618698e-01
    z[0,4,6]  R364      9.6057072281837463e-02
    z[0,4,6]  R365      4.3198190629482269e-02
    z[0,4,6]  R366      2.4222043156623840e-01
    z[0,4,6]  R367      1.5041979029774666e-02
    z[0,4,6]  R368      -2.8784090280532837e-01
    z[0,4,6]  R369      2.9248049482703209e-02
    z[0,4,6]  R370      -2.2535309195518494e-01
    z[0,4,6]  R371      -2.1008443832397461e-01
    z[0,4,6]  R372      3.8518467545509338e-01
    z[0,4,6]  R373      -2.7857992798089981e-02
    z[0,4,6]  R374      -4.7027524560689926e-02
    z[0,4,6]  R375      -1.0463027656078339e-01
    z[0,4,6]  R376      -2.2879397869110107e-01
    z[0,4,6]  R377      7.1988575160503387e-02
    z[0,4,6]  R378      -2.5938370823860168e-01
    z[0,4,6]  R379      -4.3014207482337952e-01
    z[0,4,6]  R380      2.9551157355308533e-01
    z[0,4,6]  R381      4.9728262424468994e-01
    z[0,4,6]  R382      1.9631277024745941e-01
    z[0,4,6]  R383      -6.5884912014007568e-01
    z[0,4,6]  R384      4.8078387975692749e-01
    z[0,4,6]  R385      4.7503682971000671e-01
    z[0,4,6]  R386      -4.5341871678829193e-02
    z[0,4,6]  R387      -1.5369729697704315e-01
    z[0,4,6]  R388      0.0291310902684927
    z[0,4,6]  R389      -6.2104641983751208e-05
    z[0,4,6]  R390      8.7785460054874420e-02
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R391      -1
    z[4,0,0]  R392      1
    z[4,0,0]  R405      3.1280374526977539e-01
    z[4,0,0]  R406      -3.6479675769805908e-01
    z[4,0,0]  R407      -7.0757251977920532e-01
    z[4,0,0]  R408      -7.7134460210800171e-01
    z[4,0,0]  R409      -7.6169526576995850e-01
    z[4,0,0]  R410      0.670039713382721
    z[4,0,0]  R411      -6.3153463602066040e-01
    z[4,0,0]  R412      -2.7676162123680115e-01
    z[4,0,0]  R413      1.0108610242605209e-01
    z[4,0,0]  R414      0.219046488404274
    z[4,0,0]  R415      2.5553833693265915e-03
    z[4,0,0]  R416      1.3077133893966675e-01
    z[4,0,0]  R417      -3.1307630240917206e-02
    z[4,0,0]  R418      3.9913639426231384e-01
    z[4,0,0]  R419      2.7574592828750610e-01
    z[4,0,0]  R420      0.0935889184474945
    z[4,0,0]  R421      -4.4590409845113754e-02
    z[4,0,0]  R422      2.5477501749992371e-01
    z[4,0,0]  R423      1.4936186373233795e-01
    z[4,0,0]  R424      2.3234197497367859e-01
    z[4,0,0]  R425      4.9659404903650284e-02
    z[4,0,0]  R426      -0.358368843793869
    z[4,0,0]  R427      2.0152449607849121e-01
    z[4,0,0]  R428      -2.3189561069011688e-01
    z[4,0,0]  R429      -3.9479446411132812e-01
    z[4,0,0]  R430      -7.1644838899374008e-03
    z[4,0,0]  R431      1.7566068470478058e-01
    z[4,0,0]  R432      7.8504756093025208e-02
    z[4,0,0]  R433      -2.2681222856044769e-01
    z[4,0,0]  R434      -4.6323519945144653e-01
    z[4,0,0]  R435      0.0936773419380188
    z[4,0,0]  R436      -4.5889618992805481e-01
    z[4,0,0]  R437      -2.4875631928443909e-01
    z[4,0,0]  R438      -5.2680855989456177e-01
    z[4,0,0]  R439      7.0719575881958008e-01
    z[4,0,0]  R440      0.6134073138237
    z[4,0,0]  R441      6.9082254171371460e-01
    z[4,0,0]  R442      4.2688539624214172e-01
    z[4,0,0]  R443      3.9112001657485962e-01
    z[4,0,0]  R444      1.5688183903694153e-01
    z[4,0,0]  R445      2.4505098164081573e-01
    z[4,0,0]  R446      6.1353474855422974e-01
    z[4,0,0]  R447      6.3017058372497559e-01
    z[4,0,0]  R448      0.533696711063385
    z[4,0,0]  R449      -4.1174806654453278e-02
    z[4,0,0]  R450      -2.2101683914661407e-01
    z[4,0,0]  R451      2.3543527722358704e-01
    z[4,0,0]  R452      -4.1090536117553711e-01
    z[4,0,0]  R453      -2.8238549828529358e-01
    z[4,0,0]  R454      -6.5844398736953735e-01
    z[4,0,0]  R455      2.7941653132438660e-01
    z[4,0,0]  R456      1.9471745193004608e-01
    z[4,0,0]  R457      2.4684593081474304e-01
    z[4,0,0]  R458      -6.4855295419692993e-01
    z[4,0,0]  R459      -6.4152352511882782e-02
    z[4,0,0]  R460      -2.1554049849510193e-01
    z[4,0,0]  R461      -3.8296741247177124e-01
    z[4,0,0]  R462      -2.9756072163581848e-01
    z[4,0,0]  R463      -8.0398225784301758e-01
    z[4,0,0]  R464      -1.5241575241088867e-01
    z[4,0,0]  R465      -2.3599635809659958e-02
    z[4,0,0]  R466      2.5626775622367859e-01
    z[4,0,0]  R467      2.9781398177146912e-01
    z[4,0,0]  R468      1.8805319070816040e-01
    z[4,0,0]  R469      -4.7391787171363831e-01
    z[4,0,0]  R470      9.8290868103504181e-02
    z[4,0,0]  R471      -7.2330236434936523e-02
    z[4,0,0]  R472      -2.0658065378665924e-01
    z[4,0,0]  R473      0.511587917804718
    z[4,0,0]  R474      -3.8683310151100159e-02
    z[4,0,0]  R475      2.7261814475059509e-01
    z[4,0,0]  R476      -4.4772675633430481e-01
    z[4,0,0]  R477      2.7434009313583374e-01
    z[4,0,0]  R478      -6.1960822343826294e-01
    z[4,0,0]  R479      -2.3314456641674042e-01
    z[4,0,0]  R480      2.1505402028560638e-01
    z[4,0,0]  R481      -3.5934236645698547e-01
    z[4,0,0]  R482      -4.7247186303138733e-01
    z[4,0,0]  R483      -5.6366211175918579e-01
    z[4,0,0]  R484      1.6025616228580475e-01
    z[4,0,0]  R485      -4.7844117879867554e-01
    z[4,0,0]  R486      4.9190583825111389e-01
    z[4,0,0]  R487      3.6162805557250977e-01
    z[4,0,0]  R488      -3.7239813804626465e-01
    z[4,0,0]  R489      -3.0806419253349304e-01
    z[4,0,0]  R490      1.1876897513866425e-01
    z[4,0,0]  R491      1.5820379555225372e-01
    z[4,0,0]  R492      3.1624826788902283e-01
    z[4,0,0]  R493      2.8448304533958435e-01
    z[4,0,0]  R494      2.8737327456474304e-01
    z[4,0,0]  R495      1.4233843982219696e-01
    z[4,0,0]  R496      3.8168802857398987e-02
    z[4,0,0]  R497      -3.0492378398776054e-02
    z[4,0,0]  R498      1.7495785653591156e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R393      -1
    z[4,0,1]  R394      1
    z[4,0,1]  R405      -4.2932558059692383e-01
    z[4,0,1]  R406      -6.7576491832733154e-01
    z[4,0,1]  R407      2.0904146134853363e-01
    z[4,0,1]  R408      4.9067354202270508e-01
    z[4,0,1]  R409      4.0315636992454529e-01
    z[4,0,1]  R410      4.1437533497810364e-01
    z[4,0,1]  R411      1.3012956082820892e-01
    z[4,0,1]  R412      0.589113175868988
    z[4,0,1]  R413      3.9583536982536316e-01
    z[4,0,1]  R414      3.5854130983352661e-01
    z[4,0,1]  R415      3.7020951509475708e-01
    z[4,0,1]  R416      7.5881212949752808e-01
    z[4,0,1]  R417      3.9203503727912903e-01
    z[4,0,1]  R418      -5.6707769632339478e-01
    z[4,0,1]  R419      -2.9880559444427490e-01
    z[4,0,1]  R420      2.4329890310764313e-01
    z[4,0,1]  R421      -2.1724271774291992e-01
    z[4,0,1]  R422      -6.3097810745239258e-01
    z[4,0,1]  R423      -4.3904387950897217e-01
    z[4,0,1]  R424      7.1723777055740356e-01
    z[4,0,1]  R425      4.3934261798858643e-01
    z[4,0,1]  R426      -1.7849127948284149e-01
    z[4,0,1]  R427      7.4805237352848053e-02
    z[4,0,1]  R428      0.0457318089902401
    z[4,0,1]  R429      -3.7504711747169495e-01
    z[4,0,1]  R430      -2.5783985853195190e-02
    z[4,0,1]  R431      -3.3422711491584778e-01
    z[4,0,1]  R432      -3.5029903054237366e-01
    z[4,0,1]  R433      4.9680642783641815e-02
    z[4,0,1]  R434      1.2528367340564728e-01
    z[4,0,1]  R435      3.9745840430259705e-01
    z[4,0,1]  R436      6.4624166488647461e-01
    z[4,0,1]  R437      3.3386969566345215e-01
    z[4,0,1]  R438      4.9182033538818359e-01
    z[4,0,1]  R439      -5.9345859289169312e-01
    z[4,0,1]  R440      -0.574647843837738
    z[4,0,1]  R441      -4.8191988468170166e-01
    z[4,0,1]  R442      -6.6034138202667236e-01
    z[4,0,1]  R443      8.1128066778182983e-01
    z[4,0,1]  R444      7.6293140649795532e-01
    z[4,0,1]  R445      0.261626660823822
    z[4,0,1]  R446      2.8607034683227539e-01
    z[4,0,1]  R447      3.0158591270446777e-01
    z[4,0,1]  R448      3.2507914304733276e-01
    z[4,0,1]  R449      -3.8137458264827728e-02
    z[4,0,1]  R450      9.3860030174255371e-01
    z[4,0,1]  R451      5.7797157764434814e-01
    z[4,0,1]  R452      7.6948130130767822e-01
    z[4,0,1]  R453      7.0045018196105957e-01
    z[4,0,1]  R454      2.2301225364208221e-01
    z[4,0,1]  R455      5.5432754755020142e-01
    z[4,0,1]  R456      -0.735713005065918
    z[4,0,1]  R457      4.2580845952033997e-01
    z[4,0,1]  R458      2.6165801286697388e-01
    z[4,0,1]  R459      1.5105303376913071e-02
    z[4,0,1]  R460      3.5461014509201050e-01
    z[4,0,1]  R461      2.8842544555664062e-01
    z[4,0,1]  R462      4.8079398274421692e-01
    z[4,0,1]  R463      4.1632503271102905e-01
    z[4,0,1]  R464      7.3749560117721558e-01
    z[4,0,1]  R465      8.9738404750823975e-01
    z[4,0,1]  R466      6.3835614919662476e-01
    z[4,0,1]  R467      5.9868997335433960e-01
    z[4,0,1]  R468      7.7419120073318481e-01
    z[4,0,1]  R469      3.2915085554122925e-01
    z[4,0,1]  R470      3.9533627033233643e-01
    z[4,0,1]  R471      8.8824760913848877e-01
    z[4,0,1]  R472      0.877727210521698
    z[4,0,1]  R473      4.2683750391006470e-01
    z[4,0,1]  R474      3.0805489420890808e-01
    z[4,0,1]  R475      8.3055114746093750e-01
    z[4,0,1]  R476      1.3095045089721680e-01
    z[4,0,1]  R477      -5.9901338815689087e-01
    z[4,0,1]  R478      -1.9765254110097885e-02
    z[4,0,1]  R479      -2.4018374085426331e-01
    z[4,0,1]  R480      2.2535805404186249e-01
    z[4,0,1]  R481      8.8200157880783081e-01
    z[4,0,1]  R482      1.5178048610687256e-01
    z[4,0,1]  R483      1.4478464424610138e-01
    z[4,0,1]  R484      -8.1214743852615356e-01
    z[4,0,1]  R485      -5.2411098033189774e-02
    z[4,0,1]  R486      0.616611659526825
    z[4,0,1]  R487      0.82222580909729
    z[4,0,1]  R488      9.0921252965927124e-02
    z[4,0,1]  R489      5.0547677278518677e-01
    z[4,0,1]  R490      0.720435380935669
    z[4,0,1]  R491      4.8574465513229370e-01
    z[4,0,1]  R492      0.200750932097435
    z[4,0,1]  R493      -7.4452996253967285e-01
    z[4,0,1]  R494      8.5937988758087158e-01
    z[4,0,1]  R495      -3.5893049091100693e-02
    z[4,0,1]  R496      1.5119243413209915e-02
    z[4,0,1]  R497      0.0903463065624237
    z[4,0,1]  R498      1.1638209223747253e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R395      -1
    z[4,0,2]  R396      1
    z[4,0,2]  R405      2.2591508924961090e-01
    z[4,0,2]  R406      -2.1254327893257141e-01
    z[4,0,2]  R407      -5.9841352701187134e-01
    z[4,0,2]  R408      8.1337429583072662e-02
    z[4,0,2]  R409      7.7377937734127045e-02
    z[4,0,2]  R410      -2.5290283560752869e-01
    z[4,0,2]  R411      2.1290490031242371e-01
    z[4,0,2]  R412      -5.2991569042205811e-01
    z[4,0,2]  R413      -2.7966782450675964e-01
    z[4,0,2]  R414      -3.1875881552696228e-01
    z[4,0,2]  R415      5.4847621917724609e-01
    z[4,0,2]  R416      6.5688274800777435e-02
    z[4,0,2]  R417      4.2364135384559631e-01
    z[4,0,2]  R418      1.5305852284654975e-03
    z[4,0,2]  R419      -4.8518818616867065e-01
    z[4,0,2]  R420      8.3909317851066589e-02
    z[4,0,2]  R421      1.3591116666793823e-01
    z[4,0,2]  R422      -3.6270821094512939e-01
    z[4,0,2]  R423      -2.5830566883087158e-01
    z[4,0,2]  R424      3.8193327188491821e-01
    z[4,0,2]  R425      -1.3486935198307037e-01
    z[4,0,2]  R426      3.7739354372024536e-01
    z[4,0,2]  R427      -7.0517137646675110e-02
    z[4,0,2]  R428      -1.8015700578689575e-01
    z[4,0,2]  R429      -2.8222200274467468e-01
    z[4,0,2]  R430      -7.0818763971328735e-01
    z[4,0,2]  R431      -0.651944637298584
    z[4,0,2]  R432      -5.8991187810897827e-01
    z[4,0,2]  R433      -3.4730535745620728e-01
    z[4,0,2]  R434      -6.0387951135635376e-01
    z[4,0,2]  R435      -0.27772057056427
    z[4,0,2]  R436      -2.9529851675033569e-01
    z[4,0,2]  R437      -4.0939885377883911e-01
    z[4,0,2]  R438      -3.5868924856185913e-01
    z[4,0,2]  R439      3.0828040838241577e-01
    z[4,0,2]  R440      4.5731565356254578e-01
    z[4,0,2]  R441      3.3518549799919128e-01
    z[4,0,2]  R442      4.4903567433357239e-01
    z[4,0,2]  R443      -1.2298995256423950e-01
    z[4,0,2]  R444      3.8961014151573181e-01
    z[4,0,2]  R445      7.5684711337089539e-02
    z[4,0,2]  R446      5.4651558399200439e-01
    z[4,0,2]  R447      4.6327370405197144e-01
    z[4,0,2]  R448      7.1334266662597656e-01
    z[4,0,2]  R449      -2.5875192880630493e-01
    z[4,0,2]  R450      3.3265821635723114e-02
    z[4,0,2]  R451      -2.8829440474510193e-01
    z[4,0,2]  R452      -1.6742104291915894e-01
    z[4,0,2]  R453      -1.5327529981732368e-02
    z[4,0,2]  R454      -2.2643579542636871e-01
    z[4,0,2]  R455      -4.5030519366264343e-01
    z[4,0,2]  R456      -4.2532366514205933e-01
    z[4,0,2]  R457      8.2564197480678558e-02
    z[4,0,2]  R458      -4.2296311259269714e-01
    z[4,0,2]  R459      0.0939294695854187
    z[4,0,2]  R460      5.1697814464569092e-01
    z[4,0,2]  R461      4.8295497894287109e-01
    z[4,0,2]  R462      0.530137300491333
    z[4,0,2]  R463      -1.3428612053394318e-01
    z[4,0,2]  R464      2.9846025630831718e-02
    z[4,0,2]  R465      2.1396109461784363e-01
    z[4,0,2]  R466      -1.9447919726371765e-01
    z[4,0,2]  R467      1.6164864599704742e-01
    z[4,0,2]  R468      -4.8067551851272583e-01
    z[4,0,2]  R469      3.7510451674461365e-01
    z[4,0,2]  R470      2.3092246055603027e-01
    z[4,0,2]  R471      -2.2959072887897491e-01
    z[4,0,2]  R472      -1.6290232539176941e-01
    z[4,0,2]  R473      -4.5549508929252625e-01
    z[4,0,2]  R474      -5.5159491300582886e-01
    z[4,0,2]  R475      -2.0587055385112762e-01
    z[4,0,2]  R476      -6.7763239145278931e-01
    z[4,0,2]  R477      -3.8402143120765686e-01
    z[4,0,2]  R478      -3.8673040270805359e-01
    z[4,0,2]  R479      -2.3727035522460938e-01
    z[4,0,2]  R480      8.1480335211381316e-04
    z[4,0,2]  R481      -7.0957783609628677e-03
    z[4,0,2]  R482      4.7249630093574524e-01
    z[4,0,2]  R483      -4.6459707617759705e-01
    z[4,0,2]  R484      -1.9321471452713013e-01
    z[4,0,2]  R485      4.0367519855499268e-01
    z[4,0,2]  R486      3.6768182180821896e-03
    z[4,0,2]  R487      2.1117500960826874e-01
    z[4,0,2]  R488      -7.9911732673645020e-01
    z[4,0,2]  R489      2.7404162287712097e-01
    z[4,0,2]  R490      -2.1417331695556641e-01
    z[4,0,2]  R491      -2.6037716865539551e-01
    z[4,0,2]  R492      -8.3167001605033875e-02
    z[4,0,2]  R493      -0.0464789904654026
    z[4,0,2]  R494      2.4752826988697052e-01
    z[4,0,2]  R495      0.0690079852938652
    z[4,0,2]  R496      -1.9208157435059547e-02
    z[4,0,2]  R497      -2.4218328297138214e-01
    z[4,0,2]  R498      1.1183889955282211e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R397      -1
    z[4,0,3]  R398      1
    z[4,0,3]  R405      -8.1339550018310547e-01
    z[4,0,3]  R406      -4.8179841041564941e-01
    z[4,0,3]  R407      1.5598054230213165e-01
    z[4,0,3]  R408      -1.5040325000882149e-02
    z[4,0,3]  R409      1.8572627007961273e-01
    z[4,0,3]  R410      7.1286216378211975e-02
    z[4,0,3]  R411      3.1809020042419434e-01
    z[4,0,3]  R412      5.2645099163055420e-01
    z[4,0,3]  R413      -1.3016305863857269e-01
    z[4,0,3]  R414      -1.0045634955167770e-01
    z[4,0,3]  R415      3.8470726460218430e-02
    z[4,0,3]  R416      -3.2603898644447327e-01
    z[4,0,3]  R417      -3.5169713199138641e-02
    z[4,0,3]  R418      0.541219174861908
    z[4,0,3]  R419      1.1270406842231750e-01
    z[4,0,3]  R420      5.0854027271270752e-01
    z[4,0,3]  R421      5.4692953824996948e-01
    z[4,0,3]  R422      2.6314312219619751e-01
    z[4,0,3]  R423      2.2490815818309784e-01
    z[4,0,3]  R424      4.4447129964828491e-01
    z[4,0,3]  R425      -3.0794769525527954e-01
    z[4,0,3]  R426      1.0301160067319870e-01
    z[4,0,3]  R427      4.4565784931182861e-01
    z[4,0,3]  R428      8.9852446317672729e-01
    z[4,0,3]  R429      -6.8621051311492920e-01
    z[4,0,3]  R430      -2.5275599956512451e-01
    z[4,0,3]  R431      -4.9141255021095276e-01
    z[4,0,3]  R432      -4.5514798164367676e-01
    z[4,0,3]  R433      -8.4004592895507812e-01
    z[4,0,3]  R434      -2.7963468432426453e-01
    z[4,0,3]  R435      -1.3276250660419464e-01
    z[4,0,3]  R436      5.9658315032720566e-02
    z[4,0,3]  R437      -5.3083121776580811e-01
    z[4,0,3]  R438      -4.5202895998954773e-01
    z[4,0,3]  R439      1.0881885886192322e-02
    z[4,0,3]  R440      1.5948741137981415e-01
    z[4,0,3]  R441      2.7570670843124390e-01
    z[4,0,3]  R442      -1.8218036741018295e-02
    z[4,0,3]  R443      2.2762574255466461e-01
    z[4,0,3]  R444      2.1701575815677643e-01
    z[4,0,3]  R445      0.722253143787384
    z[4,0,3]  R446      -1.1596355587244034e-01
    z[4,0,3]  R447      3.2577980309724808e-02
    z[4,0,3]  R448      -2.0400810241699219e-01
    z[4,0,3]  R449      -8.4571164846420288e-01
    z[4,0,3]  R450      1.3899172656238079e-02
    z[4,0,3]  R451      -0.503036379814148
    z[4,0,3]  R452      1.9249898195266724e-01
    z[4,0,3]  R453      1.7376442253589630e-01
    z[4,0,3]  R454      2.0377150177955627e-01
    z[4,0,3]  R455      5.3218871355056763e-01
    z[4,0,3]  R456      3.7639716267585754e-01
    z[4,0,3]  R457      8.0569308996200562e-01
    z[4,0,3]  R458      1.9111488759517670e-01
    z[4,0,3]  R459      -6.7610043287277222e-01
    z[4,0,3]  R460      -2.5543466210365295e-01
    z[4,0,3]  R461      -2.9475077986717224e-01
    z[4,0,3]  R462      -3.6603674292564392e-01
    z[4,0,3]  R463      -3.1473973393440247e-01
    z[4,0,3]  R464      4.0507054328918457e-01
    z[4,0,3]  R465      3.4312078356742859e-01
    z[4,0,3]  R466      6.6566234827041626e-01
    z[4,0,3]  R467      6.0403460264205933e-01
    z[4,0,3]  R468      1.8613217771053314e-01
    z[4,0,3]  R469      -4.0200895071029663e-01
    z[4,0,3]  R470      -4.2520660161972046e-01
    z[4,0,3]  R471      3.1519877910614014e-01
    z[4,0,3]  R472      1.3571046292781830e-01
    z[4,0,3]  R473      -4.4724997878074646e-01
    z[4,0,3]  R474      -4.7054540365934372e-02
    z[4,0,3]  R475      3.4226789139211178e-03
    z[4,0,3]  R476      4.4271681457757950e-02
    z[4,0,3]  R477      2.0921096205711365e-01
    z[4,0,3]  R478      4.4117620587348938e-01
    z[4,0,3]  R479      -8.0092787742614746e-01
    z[4,0,3]  R480      -3.2704836130142212e-01
    z[4,0,3]  R481      1.8207387626171112e-01
    z[4,0,3]  R482      -4.8394846916198730e-01
    z[4,0,3]  R483      0.361424058675766
    z[4,0,3]  R484      1.2346322089433670e-01
    z[4,0,3]  R485      -4.5794636011123657e-01
    z[4,0,3]  R486      4.5768809318542480e-01
    z[4,0,3]  R487      -4.9208205193281174e-02
    z[4,0,3]  R488      4.1079086065292358e-01
    z[4,0,3]  R489      -6.7735582590103149e-01
    z[4,0,3]  R490      -4.6819177269935608e-01
    z[4,0,3]  R491      -5.0702202320098877e-01
    z[4,0,3]  R492      -1.0684862732887268e-01
    z[4,0,3]  R493      2.7452594041824341e-01
    z[4,0,3]  R494      -5.2677791565656662e-02
    z[4,0,3]  R495      8.0816954374313354e-01
    z[4,0,3]  R496      7.4673879146575928e-01
    z[4,0,3]  R497      8.8588553667068481e-01
    z[4,0,3]  R498      0.750617504119873
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R399      -1
    z[4,0,4]  R400      1
    z[4,0,4]  R405      6.3242472708225250e-02
    z[4,0,4]  R406      2.1984401345252991e-01
    z[4,0,4]  R407      -2.3649795353412628e-01
    z[4,0,4]  R408      2.2370700538158417e-01
    z[4,0,4]  R409      -3.5109555721282959e-01
    z[4,0,4]  R410      -0.0685136467218399
    z[4,0,4]  R411      2.7055370807647705e-01
    z[4,0,4]  R412      -3.9472747594118118e-02
    z[4,0,4]  R413      1.1186251044273376e-01
    z[4,0,4]  R414      7.6634413003921509e-01
    z[4,0,4]  R415      -5.8889114856719971e-01
    z[4,0,4]  R416      4.3271717429161072e-01
    z[4,0,4]  R417      6.4112299680709839e-01
    z[4,0,4]  R418      3.5008779168128967e-01
    z[4,0,4]  R419      -3.7443917989730835e-01
    z[4,0,4]  R420      -8.1466743722558022e-03
    z[4,0,4]  R421      -1.6769704222679138e-01
    z[4,0,4]  R422      -0.322881281375885
    z[4,0,4]  R423      -6.3616609573364258e-01
    z[4,0,4]  R424      2.9244709014892578e-01
    z[4,0,4]  R425      3.8723675534129143e-03
    z[4,0,4]  R426      -4.5999753475189209e-01
    z[4,0,4]  R427      3.3557209372520447e-01
    z[4,0,4]  R428      3.5253819078207016e-02
    z[4,0,4]  R429      -1.9780221581459045e-01
    z[4,0,4]  R430      4.3426206707954407e-01
    z[4,0,4]  R431      2.7881652116775513e-01
    z[4,0,4]  R432      -1.3999934494495392e-01
    z[4,0,4]  R433      1.1205311119556427e-01
    z[4,0,4]  R434      5.0323325395584106e-01
    z[4,0,4]  R435      1.1693440377712250e-01
    z[4,0,4]  R436      2.7517375349998474e-01
    z[4,0,4]  R437      6.1010152101516724e-01
    z[4,0,4]  R438      2.9160878062248230e-01
    z[4,0,4]  R439      -4.9447748810052872e-02
    z[4,0,4]  R440      0.0463813841342926
    z[4,0,4]  R441      -2.7928104624152184e-02
    z[4,0,4]  R442      2.0555068552494049e-01
    z[4,0,4]  R443      -1.7847079038619995e-01
    z[4,0,4]  R444      -1.1961609870195389e-01
    z[4,0,4]  R445      -1.1268706619739532e-01
    z[4,0,4]  R446      4.5529574155807495e-01
    z[4,0,4]  R447      5.2836841344833374e-01
    z[4,0,4]  R448      1.9430550932884216e-01
    z[4,0,4]  R449      3.6644729971885681e-01
    z[4,0,4]  R450      -1.2006153166294098e-01
    z[4,0,4]  R451      -2.7529746294021606e-01
    z[4,0,4]  R452      -1.7058400809764862e-01
    z[4,0,4]  R453      -2.7533468604087830e-01
    z[4,0,4]  R454      -6.5085852146148682e-01
    z[4,0,4]  R455      4.7541882842779160e-02
    z[4,0,4]  R456      -8.1411756575107574e-02
    z[4,0,4]  R457      -2.5701868534088135e-01
    z[4,0,4]  R458      -4.0119481086730957e-01
    z[4,0,4]  R459      -3.4540107846260071e-01
    z[4,0,4]  R460      -3.8256838917732239e-01
    z[4,0,4]  R461      -0.398904025554657
    z[4,0,4]  R462      -3.4026777744293213e-01
    z[4,0,4]  R463      -2.2784620523452759e-01
    z[4,0,4]  R464      -3.7005582451820374e-01
    z[4,0,4]  R465      1.4103437960147858e-01
    z[4,0,4]  R466      5.0847832113504410e-02
    z[4,0,4]  R467      -2.4096952378749847e-01
    z[4,0,4]  R468      1.5062609314918518e-01
    z[4,0,4]  R469      -9.1757416725158691e-02
    z[4,0,4]  R470      -6.4169371128082275e-01
    z[4,0,4]  R471      -1.4829677343368530e-01
    z[4,0,4]  R472      -2.0367094874382019e-01
    z[4,0,4]  R473      -3.2702258229255676e-01
    z[4,0,4]  R474      -4.5942065119743347e-01
    z[4,0,4]  R475      5.1726657897233963e-02
    z[4,0,4]  R476      -4.9323320388793945e-01
    z[4,0,4]  R477      -3.2182257622480392e-02
    z[4,0,4]  R478      -1.8704400956630707e-01
    z[4,0,4]  R479      -2.5612348318099976e-01
    z[4,0,4]  R480      -3.5367685556411743e-01
    z[4,0,4]  R481      1.0367939621210098e-01
    z[4,0,4]  R482      1.9010002911090851e-01
    z[4,0,4]  R483      -4.0953093767166138e-01
    z[4,0,4]  R484      -2.8843152523040771e-01
    z[4,0,4]  R485      -1.7898014187812805e-01
    z[4,0,4]  R486      -2.9846525192260742e-01
    z[4,0,4]  R487      1.0212247818708420e-01
    z[4,0,4]  R488      -2.1296466886997223e-01
    z[4,0,4]  R489      -9.3044847249984741e-02
    z[4,0,4]  R490      1.7969395220279694e-01
    z[4,0,4]  R491      -3.8016852736473083e-01
    z[4,0,4]  R492      -5.0106018781661987e-01
    z[4,0,4]  R493      1.8553231656551361e-01
    z[4,0,4]  R494      1.1167474091053009e-01
    z[4,0,4]  R495      -2.5926116108894348e-01
    z[4,0,4]  R496      -2.1536377072334290e-01
    z[4,0,4]  R497      -1.9740676879882812e-01
    z[4,0,4]  R498      -2.5239869952201843e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R401      -1
    z[4,0,5]  R402      1
    z[4,0,5]  R405      -3.0946649610996246e-02
    z[4,0,5]  R406      0.0421551950275898
    z[4,0,5]  R407      1.2816968560218811e-01
    z[4,0,5]  R408      -2.3789976537227631e-01
    z[4,0,5]  R409      2.2226135432720184e-01
    z[4,0,5]  R410      3.9653125405311584e-01
    z[4,0,5]  R411      6.0311287641525269e-01
    z[4,0,5]  R412      1.2090355157852173e-01
    z[4,0,5]  R413      8.4526848793029785e-01
    z[4,0,5]  R414      2.6858550310134888e-01
    z[4,0,5]  R415      4.5679005980491638e-01
    z[4,0,5]  R416      -2.0484769344329834e-01
    z[4,0,5]  R417      2.6183694601058960e-01
    z[4,0,5]  R418      -1.2768730521202087e-01
    z[4,0,5]  R419      -4.4617816805839539e-01
    z[4,0,5]  R420      -7.9233056306838989e-01
    z[4,0,5]  R421      -4.1353252530097961e-01
    z[4,0,5]  R422      -2.7373023331165314e-02
    z[4,0,5]  R423      1.9302488863468170e-01
    z[4,0,5]  R424      2.4049438536167145e-02
    z[4,0,5]  R425      0.817222535610199
    z[4,0,5]  R426      -6.8864285945892334e-01
    z[4,0,5]  R427      7.9849857091903687e-01
    z[4,0,5]  R428      -3.0883839726448059e-01
    z[4,0,5]  R429      2.2368688881397247e-01
    z[4,0,5]  R430      4.8190298676490784e-01
    z[4,0,5]  R431      3.3627447485923767e-01
    z[4,0,5]  R432      5.3906667232513428e-01
    z[4,0,5]  R433      -0.274694561958313
    z[4,0,5]  R434      2.6330825686454773e-01
    z[4,0,5]  R435      0.846364438533783
    z[4,0,5]  R436      4.5080372691154480e-01
    z[4,0,5]  R437      -5.0654627382755280e-02
    z[4,0,5]  R438      2.3863463103771210e-01
    z[4,0,5]  R439      -1.7922644317150116e-01
    z[4,0,5]  R440      1.8534478545188904e-01
    z[4,0,5]  R441      3.1838840246200562e-01
    z[4,0,5]  R442      -1.6285143792629242e-01
    z[4,0,5]  R443      -2.6255920529365540e-01
    z[4,0,5]  R444      -1.8663893640041351e-01
    z[4,0,5]  R445      3.1805068254470825e-01
    z[4,0,5]  R446      -4.7559358179569244e-02
    z[4,0,5]  R447      -4.7271057963371277e-02
    z[4,0,5]  R448      7.4209690093994141e-02
    z[4,0,5]  R449      2.8233960270881653e-01
    z[4,0,5]  R450      -2.3085056245326996e-01
    z[4,0,5]  R451      3.6141827702522278e-02
    z[4,0,5]  R452      -1.6141220927238464e-01
    z[4,0,5]  R453      -1.2815786898136139e-01
    z[4,0,5]  R454      -1.2487945146858692e-02
    z[4,0,5]  R455      -8.2670869305729866e-03
    z[4,0,5]  R456      -6.7917510867118835e-02
    z[4,0,5]  R457      1.7979972064495087e-01
    z[4,0,5]  R458      -3.6516842246055603e-01
    z[4,0,5]  R459      6.0884922742843628e-01
    z[4,0,5]  R460      0.588984489440918
    z[4,0,5]  R461      5.3796172142028809e-01
    z[4,0,5]  R462      3.3902713656425476e-01
    z[4,0,5]  R463      -5.8717697858810425e-02
    z[4,0,5]  R464      3.5889267921447754e-01
    z[4,0,5]  R465      3.3878777176141739e-02
    z[4,0,5]  R466      1.9420199096202850e-01
    z[4,0,5]  R467      2.9188758134841919e-01
    z[4,0,5]  R468      -0.0816691666841507
    z[4,0,5]  R469      3.0651926994323730e-01
    z[4,0,5]  R470      3.0878382921218872e-01
    z[4,0,5]  R471      -1.2946107983589172e-01
    z[4,0,5]  R472      6.1762958765029907e-02
    z[4,0,5]  R473      1.4723029732704163e-01
    z[4,0,5]  R474      1.7835982143878937e-01
    z[4,0,5]  R475      1.3586243987083435e-01
    z[4,0,5]  R476      -1.5781633555889130e-01
    z[4,0,5]  R477      -0.512084424495697
    z[4,0,5]  R478      1.4620803296566010e-01
    z[4,0,5]  R479      3.5290205478668213e-01
    z[4,0,5]  R480      6.4368414878845215e-01
    z[4,0,5]  R481      2.0285930484533310e-02
    z[4,0,5]  R482      -4.1125866770744324e-01
    z[4,0,5]  R483      3.4659293293952942e-01
    z[4,0,5]  R484      -3.8214546442031860e-01
    z[4,0,5]  R485      -0.573047399520874
    z[4,0,5]  R486      2.0609468221664429e-02
    z[4,0,5]  R487      1.8222462385892868e-02
    z[4,0,5]  R488      1.5775173902511597e-02
    z[4,0,5]  R489      2.3029072582721710e-01
    z[4,0,5]  R490      1.9393661618232727e-01
    z[4,0,5]  R491      1.9587431848049164e-01
    z[4,0,5]  R492      6.6620707511901855e-01
    z[4,0,5]  R493      -2.7824527025222778e-01
    z[4,0,5]  R494      5.2504088729619980e-02
    z[4,0,5]  R495      -4.9292716383934021e-01
    z[4,0,5]  R496      -6.2025654315948486e-01
    z[4,0,5]  R497      -3.2653677463531494e-01
    z[4,0,5]  R498      -5.0747859477996826e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R403      -1
    z[4,0,6]  R404      1
    z[4,0,6]  R405      1.5041979029774666e-02
    z[4,0,6]  R406      -2.8784090280532837e-01
    z[4,0,6]  R407      2.9248049482703209e-02
    z[4,0,6]  R408      -2.2535309195518494e-01
    z[4,0,6]  R409      -2.1008443832397461e-01
    z[4,0,6]  R410      3.8518467545509338e-01
    z[4,0,6]  R411      -2.7857992798089981e-02
    z[4,0,6]  R412      -4.7027524560689926e-02
    z[4,0,6]  R413      -1.0463027656078339e-01
    z[4,0,6]  R414      -2.2879397869110107e-01
    z[4,0,6]  R415      7.1988575160503387e-02
    z[4,0,6]  R416      -2.5938370823860168e-01
    z[4,0,6]  R417      -4.3014207482337952e-01
    z[4,0,6]  R418      2.9551157355308533e-01
    z[4,0,6]  R419      4.9728262424468994e-01
    z[4,0,6]  R420      1.9631277024745941e-01
    z[4,0,6]  R421      -6.5884912014007568e-01
    z[4,0,6]  R422      4.8078387975692749e-01
    z[4,0,6]  R423      4.7503682971000671e-01
    z[4,0,6]  R424      -4.5341871678829193e-02
    z[4,0,6]  R425      -1.5369729697704315e-01
    z[4,0,6]  R426      0.0291310902684927
    z[4,0,6]  R427      -6.2104641983751208e-05
    z[4,0,6]  R428      8.7785460054874420e-02
    z[4,0,6]  R429      -2.5254982709884644e-01
    z[4,0,6]  R430      -1.1425584554672241e-01
    z[4,0,6]  R431      -0.00990948174148798
    z[4,0,6]  R432      0.0760202705860138
    z[4,0,6]  R433      1.7826054990291595e-01
    z[4,0,6]  R434      -6.5391868352890015e-02
    z[4,0,6]  R435      -9.2143878340721130e-02
    z[4,0,6]  R436      -4.5621380209922791e-02
    z[4,0,6]  R437      -4.9721501767635345e-02
    z[4,0,6]  R438      -7.4934326112270355e-02
    z[4,0,6]  R439      1.3400943577289581e-01
    z[4,0,6]  R440      -1.4977841079235077e-01
    z[4,0,6]  R441      -1.6282552387565374e-03
    z[4,0,6]  R442      -3.3313891291618347e-01
    z[4,0,6]  R443      -1.4532597362995148e-01
    z[4,0,6]  R444      3.8116896152496338e-01
    z[4,0,6]  R445      -4.7986373305320740e-01
    z[4,0,6]  R446      -1.4161920547485352e-01
    z[4,0,6]  R447      1.2181732803583145e-01
    z[4,0,6]  R448      1.2550921738147736e-01
    z[4,0,6]  R449      -2.5886796414852142e-02
    z[4,0,6]  R450      -3.4271985292434692e-02
    z[4,0,6]  R451      -4.4414526224136353e-01
    z[4,0,6]  R452      3.4469828009605408e-01
    z[4,0,6]  R453      -5.5404454469680786e-01
    z[4,0,6]  R454      1.2178383767604828e-02
    z[4,0,6]  R455      3.5541403293609619e-01
    z[4,0,6]  R456      -2.9495045542716980e-01
    z[4,0,6]  R457      -5.8390267193317413e-02
    z[4,0,6]  R458      3.4440811723470688e-02
    z[4,0,6]  R459      1.9930483400821686e-01
    z[4,0,6]  R460      4.4936783611774445e-02
    z[4,0,6]  R461      -3.8677752017974854e-02
    z[4,0,6]  R462      1.8586240708827972e-01
    z[4,0,6]  R463      -8.8489718735218048e-02
    z[4,0,6]  R464      -4.6383913606405258e-02
    z[4,0,6]  R465      9.7954608500003815e-02
    z[4,0,6]  R466      -0.0748317539691925
    z[4,0,6]  R467      -1.3647177815437317e-01
    z[4,0,6]  R468      -2.6497521996498108e-01
    z[4,0,6]  R469      -0.512224018573761
    z[4,0,6]  R470      -3.0463767051696777e-01
    z[4,0,6]  R471      1.2235336750745773e-01
    z[4,0,6]  R472      -3.1091544032096863e-01
    z[4,0,6]  R473      1.4127552509307861e-01
    z[4,0,6]  R474      5.9519338607788086e-01
    z[4,0,6]  R475      4.1513332724571228e-01
    z[4,0,6]  R476      2.3035214841365814e-01
    z[4,0,6]  R477      -3.3378526568412781e-01
    z[4,0,6]  R478      -0.463827520608902
    z[4,0,6]  R479      5.8014723472297192e-03
    z[4,0,6]  R480      5.0654488801956177e-01
    z[4,0,6]  R481      -2.2041791677474976e-01
    z[4,0,6]  R482      -3.0166599154472351e-01
    z[4,0,6]  R483      -1.6432404518127441e-01
    z[4,0,6]  R484      -0.181470587849617
    z[4,0,6]  R485      -1.8777973949909210e-01
    z[4,0,6]  R486      2.8074988722801208e-01
    z[4,0,6]  R487      -3.6795702576637268e-01
    z[4,0,6]  R488      -1.0612189769744873e-02
    z[4,0,6]  R489      2.3235501348972321e-01
    z[4,0,6]  R490      3.6316907405853271e-01
    z[4,0,6]  R491      -4.8089629411697388e-01
    z[4,0,6]  R492      -3.8270026445388794e-01
    z[4,0,6]  R493      -4.1878035664558411e-01
    z[4,0,6]  R494      -3.1560999155044556e-01
    z[4,0,6]  R495      1.0177277773618698e-01
    z[4,0,6]  R496      9.6057072281837463e-02
    z[4,0,6]  R497      4.3198190629482269e-02
    z[4,0,6]  R498      2.4222043156623840e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R583      -1
    z[1,2,0]  R584      1
    z[1,2,0]  R597      7.8782200813293457e-01
    z[1,2,0]  R598      -9.1499380767345428e-02
    z[1,2,0]  R599      -1.8841521441936493e-01
    z[1,2,0]  R600      -4.2797368764877319e-01
    z[1,2,0]  R601      -3.4564241766929626e-01
    z[1,2,0]  R602      -5.2983468770980835e-01
    z[1,2,0]  R603      -4.0331348776817322e-01
    z[1,2,0]  R604      -7.4129021167755127e-01
    z[1,2,0]  R605      4.6944785118103027e-01
    z[1,2,0]  R606      -1.6648881137371063e-01
    z[1,2,0]  R607      -2.2663618624210358e-01
    z[1,2,0]  R608      -1.2377069145441055e-01
    z[1,2,0]  R609      -5.1148599386215210e-01
    z[1,2,0]  R610      -1.9897338747978210e-01
    z[1,2,0]  R611      5.4989758878946304e-02
    z[1,2,0]  R612      -3.4354427456855774e-01
    z[1,2,0]  R613      -1.0609781742095947e-01
    z[1,2,0]  R614      -3.4289813041687012e-01
    z[1,2,0]  R615      -4.1695043444633484e-01
    z[1,2,0]  R616      -4.0962496399879456e-01
    z[1,2,0]  R617      1.7386958003044128e-01
    z[1,2,0]  R618      5.3327787667512894e-02
    z[1,2,0]  R619      5.7834988832473755e-01
    z[1,2,0]  R620      4.5682811737060547e-01
    z[1,2,0]  R621      6.1966693401336670e-01
    z[1,2,0]  R622      3.5519456863403320e-01
    z[1,2,0]  R623      -3.2717451453208923e-01
    z[1,2,0]  R624      1.8589578103274107e-03
    z[1,2,0]  R625      3.5171806812286377e-01
    z[1,2,0]  R626      -1.0059101879596710e-01
    z[1,2,0]  R627      -2.1450848877429962e-01
    z[1,2,0]  R628      4.8710286617279053e-01
    z[1,2,0]  R629      2.6665395498275757e-01
    z[1,2,0]  R630      2.2105872631072998e-01
    z[1,2,0]  R631      0.0990963950753212
    z[1,2,0]  R632      1.7798755317926407e-02
    z[1,2,0]  R633      1.1406289041042328e-01
    z[1,2,0]  R634      5.3117722272872925e-01
    z[1,2,0]  R635      1.7338527739048004e-01
    z[1,2,0]  R636      2.8216194361448288e-02
    z[1,2,0]  R637      1.5669876337051392e-01
    z[1,2,0]  R638      4.4781687855720520e-01
    z[1,2,0]  R639      3.3464625477790833e-01
    z[1,2,0]  R640      3.2121995091438293e-01
    z[1,2,0]  R641      5.7929539680480957e-01
    z[1,2,0]  R642      -2.3732288181781769e-01
    z[1,2,0]  R643      -1.1253122985363007e-01
    z[1,2,0]  R644      1.6066257655620575e-01
    z[1,2,0]  R645      2.9148164391517639e-01
    z[1,2,0]  R646      -6.2944769859313965e-02
    z[1,2,0]  R647      5.6542152166366577e-01
    z[1,2,0]  R648      3.5250759124755859e-01
    z[1,2,0]  R649      4.3026891350746155e-01
    z[1,2,0]  R650      2.9435160756111145e-01
    z[1,2,0]  R651      3.9072433114051819e-01
    z[1,2,0]  R652      -0.301540344953537
    z[1,2,0]  R653      -3.0550071597099304e-01
    z[1,2,0]  R654      -2.3596100509166718e-01
    z[1,2,0]  R655      2.5410386919975281e-01
    z[1,2,0]  R656      4.7374597191810608e-01
    z[1,2,0]  R657      4.8651728034019470e-01
    z[1,2,0]  R658      6.4232480525970459e-01
    z[1,2,0]  R659      4.4753953814506531e-01
    z[1,2,0]  R660      3.5032770037651062e-01
    z[1,2,0]  R661      5.7069998979568481e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R585      -1
    z[1,2,1]  R586      1
    z[1,2,1]  R597      1.8559511005878448e-01
    z[1,2,1]  R598      8.6331389844417572e-02
    z[1,2,1]  R599      -6.4906142652034760e-02
    z[1,2,1]  R600      4.4738192111253738e-02
    z[1,2,1]  R601      -6.0009807348251343e-02
    z[1,2,1]  R602      -4.8701085150241852e-02
    z[1,2,1]  R603      4.6199014782905579e-01
    z[1,2,1]  R604      -2.2323431447148323e-02
    z[1,2,1]  R605      -2.3589028418064117e-01
    z[1,2,1]  R606      4.7085127234458923e-01
    z[1,2,1]  R607      -4.2715936899185181e-01
    z[1,2,1]  R608      4.4058451056480408e-01
    z[1,2,1]  R609      5.4624825716018677e-01
    z[1,2,1]  R610      6.0098719596862793e-01
    z[1,2,1]  R611      5.0409317016601562e-01
    z[1,2,1]  R612      -3.8267418742179871e-01
    z[1,2,1]  R613      -5.0503000617027283e-02
    z[1,2,1]  R614      -6.7437969148159027e-02
    z[1,2,1]  R615      3.2634413801133633e-03
    z[1,2,1]  R616      -3.5629320889711380e-02
    z[1,2,1]  R617      -4.0873914957046509e-02
    z[1,2,1]  R618      2.9203820973634720e-02
    z[1,2,1]  R619      7.3784464597702026e-01
    z[1,2,1]  R620      7.5842893123626709e-01
    z[1,2,1]  R621      5.9752637147903442e-01
    z[1,2,1]  R622      -7.4232590198516846e-01
    z[1,2,1]  R623      -7.6864480972290039e-01
    z[1,2,1]  R624      -4.6451109647750854e-01
    z[1,2,1]  R625      -2.3297613859176636e-01
    z[1,2,1]  R626      -0.83770751953125
    z[1,2,1]  R627      -6.4848428964614868e-01
    z[1,2,1]  R628      -6.2998992204666138e-01
    z[1,2,1]  R629      -6.0057139396667480e-01
    z[1,2,1]  R630      -5.4732006788253784e-01
    z[1,2,1]  R631      -5.8858454227447510e-01
    z[1,2,1]  R632      -8.7194216251373291e-01
    z[1,2,1]  R633      -7.5847518444061279e-01
    z[1,2,1]  R634      -0.737540066242218
    z[1,2,1]  R635      -6.5106922388076782e-01
    z[1,2,1]  R636      -4.9031745642423630e-02
    z[1,2,1]  R637      -5.3413182497024536e-01
    z[1,2,1]  R638      4.4354477524757385e-01
    z[1,2,1]  R639      6.3502651453018188e-01
    z[1,2,1]  R640      7.8038352727890015e-01
    z[1,2,1]  R641      4.1401675343513489e-01
    z[1,2,1]  R642      -0.774492084980011
    z[1,2,1]  R643      -6.4482349157333374e-01
    z[1,2,1]  R644      -6.9996660947799683e-01
    z[1,2,1]  R645      -3.6509573459625244e-01
    z[1,2,1]  R646      -2.3846681416034698e-01
    z[1,2,1]  R647      -1.9123752415180206e-01
    z[1,2,1]  R648      6.3160890340805054e-01
    z[1,2,1]  R649      5.4495137929916382e-01
    z[1,2,1]  R650      6.7421919107437134e-01
    z[1,2,1]  R651      8.4285050630569458e-01
    z[1,2,1]  R652      -2.3346172273159027e-01
    z[1,2,1]  R653      -7.4203974008560181e-01
    z[1,2,1]  R654      -6.6759639978408813e-01
    z[1,2,1]  R655      -4.9453061074018478e-02
    z[1,2,1]  R656      8.1790482997894287e-01
    z[1,2,1]  R657      5.3430742025375366e-01
    z[1,2,1]  R658      4.5711231231689453e-01
    z[1,2,1]  R659      6.5081173181533813e-01
    z[1,2,1]  R660      7.2330325841903687e-01
    z[1,2,1]  R661      4.1058927774429321e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R587      -1
    z[1,2,2]  R588      1
    z[1,2,2]  R597      -3.7961982190608978e-02
    z[1,2,2]  R598      -2.0295926928520203e-01
    z[1,2,2]  R599      -4.9763530492782593e-01
    z[1,2,2]  R600      -3.9014372229576111e-01
    z[1,2,2]  R601      -4.2751175165176392e-01
    z[1,2,2]  R602      -3.1068110838532448e-03
    z[1,2,2]  R603      -4.9676337838172913e-01
    z[1,2,2]  R604      -5.3054824471473694e-02
    z[1,2,2]  R605      3.4527891874313354e-01
    z[1,2,2]  R606      -2.4652208387851715e-01
    z[1,2,2]  R607      2.2169497609138489e-01
    z[1,2,2]  R608      3.6531981825828552e-01
    z[1,2,2]  R609      -5.1182711124420166e-01
    z[1,2,2]  R610      -8.2438193261623383e-02
    z[1,2,2]  R611      -5.5990350246429443e-01
    z[1,2,2]  R612      3.3791989088058472e-01
    z[1,2,2]  R613      6.5919585525989532e-02
    z[1,2,2]  R614      1.5690113604068756e-01
    z[1,2,2]  R615      -1.3273629546165466e-01
    z[1,2,2]  R616      2.4814562499523163e-01
    z[1,2,2]  R617      -1.4085343107581139e-02
    z[1,2,2]  R618      -3.6242190003395081e-01
    z[1,2,2]  R619      -3.3191487193107605e-01
    z[1,2,2]  R620      0.0945688933134079
    z[1,2,2]  R621      2.0823976397514343e-01
    z[1,2,2]  R622      -4.9097096920013428e-01
    z[1,2,2]  R623      -1.9649036228656769e-01
    z[1,2,2]  R624      2.1629586815834045e-01
    z[1,2,2]  R625      0.693274199962616
    z[1,2,2]  R626      -2.5046586990356445e-01
    z[1,2,2]  R627      3.4714984893798828e-01
    z[1,2,2]  R628      1.4693361520767212e-01
    z[1,2,2]  R629      -2.0404672622680664e-01
    z[1,2,2]  R630      -4.6474647521972656e-01
    z[1,2,2]  R631      -4.5270577073097229e-01
    z[1,2,2]  R632      -1.9578759372234344e-01
    z[1,2,2]  R633      2.8505036234855652e-01
    z[1,2,2]  R634      -3.2137352973222733e-02
    z[1,2,2]  R635      1.6045522689819336e-01
    z[1,2,2]  R636      -2.9685732722282410e-01
    z[1,2,2]  R637      -3.7420034408569336e-01
    z[1,2,2]  R638      -2.1563017368316650e-01
    z[1,2,2]  R639      3.0412617325782776e-01
    z[1,2,2]  R640      4.7782737016677856e-01
    z[1,2,2]  R641      -1.0993339121341705e-01
    z[1,2,2]  R642      4.3414631485939026e-01
    z[1,2,2]  R643      -6.0789614915847778e-01
    z[1,2,2]  R644      -4.0976539254188538e-01
    z[1,2,2]  R645      -2.6562992483377457e-02
    z[1,2,2]  R646      -2.7773827314376831e-01
    z[1,2,2]  R647      1.0486693121492863e-02
    z[1,2,2]  R648      -9.5970399677753448e-02
    z[1,2,2]  R649      1.6788119077682495e-01
    z[1,2,2]  R650      -7.4469313025474548e-02
    z[1,2,2]  R651      3.2411456108093262e-01
    z[1,2,2]  R652      1.6742104291915894e-01
    z[1,2,2]  R653      -3.0482724308967590e-01
    z[1,2,2]  R654      1.1141819506883621e-01
    z[1,2,2]  R655      -5.6936436891555786e-01
    z[1,2,2]  R656      1.6606016457080841e-01
    z[1,2,2]  R657      -1.3456906378269196e-01
    z[1,2,2]  R658      -1.5954619273543358e-02
    z[1,2,2]  R659      9.6836470067501068e-02
    z[1,2,2]  R660      5.0356034189462662e-02
    z[1,2,2]  R661      2.9992294311523438e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R589      -1
    z[1,2,3]  R590      1
    z[1,2,3]  R597      -1.9140833616256714e-01
    z[1,2,3]  R598      -8.7153857946395874e-01
    z[1,2,3]  R599      -7.4942690134048462e-01
    z[1,2,3]  R600      -7.6530581712722778e-01
    z[1,2,3]  R601      -7.4175614118576050e-01
    z[1,2,3]  R602      -7.6331532001495361e-01
    z[1,2,3]  R603      -2.5657391548156738e-01
    z[1,2,3]  R604      0.00394494878128171
    z[1,2,3]  R605      0.538794219493866
    z[1,2,3]  R606      6.4446341991424561e-01
    z[1,2,3]  R607      3.4445956349372864e-01
    z[1,2,3]  R608      1.4134380221366882e-01
    z[1,2,3]  R609      2.7410295605659485e-01
    z[1,2,3]  R610      1.5015423297882080e-01
    z[1,2,3]  R611      -4.2969822883605957e-02
    z[1,2,3]  R612      3.9759820699691772e-01
    z[1,2,3]  R613      -9.0902382135391235e-01
    z[1,2,3]  R614      -7.4488759040832520e-01
    z[1,2,3]  R615      -7.3872792720794678e-01
    z[1,2,3]  R616      -7.1963566541671753e-01
    z[1,2,3]  R617      -8.4947013854980469e-01
    z[1,2,3]  R618      -6.7806845903396606e-01
    z[1,2,3]  R619      6.8751536309719086e-02
    z[1,2,3]  R620      -4.6488042920827866e-02
    z[1,2,3]  R621      -2.6350151747465134e-02
    z[1,2,3]  R622      -1.4525451697409153e-02
    z[1,2,3]  R623      2.5759249925613403e-01
    z[1,2,3]  R624      -5.7335708290338516e-02
    z[1,2,3]  R625      -2.7631255984306335e-01
    z[1,2,3]  R626      2.0623576641082764e-01
    z[1,2,3]  R627      4.7101509571075439e-01
    z[1,2,3]  R628      4.3801674246788025e-01
    z[1,2,3]  R629      1.6934689879417419e-01
    z[1,2,3]  R630      3.1265792250633240e-01
    z[1,2,3]  R631      1.8767033517360687e-01
    z[1,2,3]  R632      -1.3730492442846298e-02
    z[1,2,3]  R633      4.7327306866645813e-01
    z[1,2,3]  R634      3.6038488149642944e-01
    z[1,2,3]  R635      3.5026934742927551e-01
    z[1,2,3]  R636      -3.5700049996376038e-01
    z[1,2,3]  R637      4.5172271132469177e-01
    z[1,2,3]  R638      6.7419892549514771e-01
    z[1,2,3]  R639      5.0025576353073120e-01
    z[1,2,3]  R640      8.1911824643611908e-02
    z[1,2,3]  R641      4.2093262076377869e-02
    z[1,2,3]  R642      -2.3202177882194519e-01
    z[1,2,3]  R643      -2.6309096813201904e-01
    z[1,2,3]  R644      -3.6003756523132324e-01
    z[1,2,3]  R645      -5.2444475889205933e-01
    z[1,2,3]  R646      -4.5565196871757507e-01
    z[1,2,3]  R647      -5.5628603696823120e-01
    z[1,2,3]  R648      6.5259546041488647e-01
    z[1,2,3]  R649      5.7947164773941040e-01
    z[1,2,3]  R650      4.9359327554702759e-01
    z[1,2,3]  R651      -6.3951924443244934e-02
    z[1,2,3]  R652      -0.901881217956543
    z[1,2,3]  R653      -2.7289089560508728e-01
    z[1,2,3]  R654      -1.7915260791778564e-01
    z[1,2,3]  R655      -6.3319075107574463e-01
    z[1,2,3]  R656      9.9597439169883728e-02
    z[1,2,3]  R657      0.581642210483551
    z[1,2,3]  R658      3.8312000036239624e-01
    z[1,2,3]  R659      3.3111450076103210e-01
    z[1,2,3]  R660      -4.5543190091848373e-02
    z[1,2,3]  R661      2.4427708983421326e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R591      -1
    z[1,2,4]  R592      1
    z[1,2,4]  R597      -2.2562074661254883e-01
    z[1,2,4]  R598      4.1770094633102417e-01
    z[1,2,4]  R599      9.3129336833953857e-02
    z[1,2,4]  R600      -2.1449530124664307e-01
    z[1,2,4]  R601      2.4335640668869019e-01
    z[1,2,4]  R602      -5.7202443480491638e-02
    z[1,2,4]  R603      5.2923923730850220e-01
    z[1,2,4]  R604      5.5525940656661987e-01
    z[1,2,4]  R605      1.3088180124759674e-01
    z[1,2,4]  R606      -2.1067827939987183e-01
    z[1,2,4]  R607      -6.9597214460372925e-01
    z[1,2,4]  R608      -4.6219328045845032e-01
    z[1,2,4]  R609      -5.0360444001853466e-03
    z[1,2,4]  R610      2.0514579117298126e-01
    z[1,2,4]  R611      -2.5430586934089661e-01
    z[1,2,4]  R612      -4.5101216435432434e-01
    z[1,2,4]  R613      -6.6306792199611664e-02
    z[1,2,4]  R614      4.3965074419975281e-01
    z[1,2,4]  R615      4.4334211945533752e-01
    z[1,2,4]  R616      1.6884812712669373e-01
    z[1,2,4]  R617      -3.4588897228240967e-01
    z[1,2,4]  R618      -3.7867131829261780e-01
    z[1,2,4]  R619      7.8314365819096565e-03
    z[1,2,4]  R620      4.1429454088211060e-01
    z[1,2,4]  R621      -1.2736883759498596e-01
    z[1,2,4]  R622      1.5730260312557220e-01
    z[1,2,4]  R623      2.1937662363052368e-01
    z[1,2,4]  R624      1.5066680312156677e-01
    z[1,2,4]  R625      1.6973850131034851e-01
    z[1,2,4]  R626      1.2679381668567657e-01
    z[1,2,4]  R627      -1.1155434697866440e-01
    z[1,2,4]  R628      1.6030846536159515e-01
    z[1,2,4]  R629      -5.6932407617568970e-01
    z[1,2,4]  R630      2.9742112755775452e-01
    z[1,2,4]  R631      -1.7082078754901886e-01
    z[1,2,4]  R632      -1.8431127071380615e-01
    z[1,2,4]  R633      2.8770866990089417e-01
    z[1,2,4]  R634      -1.8145841360092163e-01
    z[1,2,4]  R635      -2.6810136437416077e-01
    z[1,2,4]  R636      1.8248723447322845e-01
    z[1,2,4]  R637      -3.3276686072349548e-01
    z[1,2,4]  R638      0.265112966299057
    z[1,2,4]  R639      -2.2561891376972198e-01
    z[1,2,4]  R640      -5.3866151720285416e-02
    z[1,2,4]  R641      5.6937980651855469e-01
    z[1,2,4]  R642      -2.1870298683643341e-01
    z[1,2,4]  R643      2.0903086662292480e-01
    z[1,2,4]  R644      -4.2719554901123047e-01
    z[1,2,4]  R645      2.5150260329246521e-01
    z[1,2,4]  R646      5.7169649749994278e-02
    z[1,2,4]  R647      3.5505077242851257e-01
    z[1,2,4]  R648      1.1017717421054840e-01
    z[1,2,4]  R649      -3.7148892879486084e-01
    z[1,2,4]  R650      -4.1202649474143982e-02
    z[1,2,4]  R651      -1.1888147145509720e-01
    z[1,2,4]  R652      7.6279595494270325e-02
    z[1,2,4]  R653      6.9572590291500092e-02
    z[1,2,4]  R654      2.4538795650005341e-01
    z[1,2,4]  R655      -3.0108207464218140e-01
    z[1,2,4]  R656      1.8064978718757629e-01
    z[1,2,4]  R657      1.0405606776475906e-01
    z[1,2,4]  R658      1.2176611274480820e-01
    z[1,2,4]  R659      -3.5840880870819092e-01
    z[1,2,4]  R660      -4.9609247595071793e-02
    z[1,2,4]  R661      -3.0643252655863762e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R593      -1
    z[1,2,5]  R594      1
    z[1,2,5]  R597      4.1746962070465088e-01
    z[1,2,5]  R598      -4.2152579873800278e-02
    z[1,2,5]  R599      -3.6931574344635010e-01
    z[1,2,5]  R600      -0.0731348991394043
    z[1,2,5]  R601      2.7010822296142578e-01
    z[1,2,5]  R602      3.0007827281951904e-01
    z[1,2,5]  R603      -1.0756545513868332e-01
    z[1,2,5]  R604      -1.1789335310459137e-01
    z[1,2,5]  R605      -3.8339126110076904e-01
    z[1,2,5]  R606      4.2558598518371582e-01
    z[1,2,5]  R607      2.2750738263130188e-01
    z[1,2,5]  R608      -4.8899385333061218e-01
    z[1,2,5]  R609      3.1099513173103333e-01
    z[1,2,5]  R610      5.5458873510360718e-01
    z[1,2,5]  R611      -1.4815038442611694e-01
    z[1,2,5]  R612      3.8735222816467285e-01
    z[1,2,5]  R613      -2.3398378491401672e-01
    z[1,2,5]  R614      -4.6752616763114929e-02
    z[1,2,5]  R615      1.3514953851699829e-01
    z[1,2,5]  R616      0.46548992395401
    z[1,2,5]  R617      0.344230055809021
    z[1,2,5]  R618      5.0049668550491333e-01
    z[1,2,5]  R619      -3.2925210893154144e-02
    z[1,2,5]  R620      -1.1988820135593414e-01
    z[1,2,5]  R621      2.9034256935119629e-01
    z[1,2,5]  R622      5.4852332919836044e-02
    z[1,2,5]  R623      3.2863688468933105e-01
    z[1,2,5]  R624      -6.5464353561401367e-01
    z[1,2,5]  R625      -3.5209223628044128e-01
    z[1,2,5]  R626      -3.9660032838582993e-02
    z[1,2,5]  R627      3.9664039015769958e-01
    z[1,2,5]  R628      -2.3206442594528198e-01
    z[1,2,5]  R629      -1.0509885102510452e-01
    z[1,2,5]  R630      -3.5911419987678528e-01
    z[1,2,5]  R631      -1.9423596560955048e-01
    z[1,2,5]  R632      -2.9846975207328796e-01
    z[1,2,5]  R633      -1.5160897374153137e-01
    z[1,2,5]  R634      8.6666487157344818e-02
    z[1,2,5]  R635      -1.0509578138589859e-01
    z[1,2,5]  R636      -9.1551892459392548e-02
    z[1,2,5]  R637      4.1956865787506104e-01
    z[1,2,5]  R638      1.3488624989986420e-01
    z[1,2,5]  R639      -4.5855108648538589e-02
    z[1,2,5]  R640      -1.9494697451591492e-01
    z[1,2,5]  R641      3.9313459396362305e-01
    z[1,2,5]  R642      2.2306744754314423e-01
    z[1,2,5]  R643      -3.1990390270948410e-02
    z[1,2,5]  R644      4.2567834258079529e-02
    z[1,2,5]  R645      5.0508803129196167e-01
    z[1,2,5]  R646      2.3285277187824249e-01
    z[1,2,5]  R647      -2.5751617550849915e-01
    z[1,2,5]  R648      -1.4964435994625092e-01
    z[1,2,5]  R649      1.2595626711845398e-01
    z[1,2,5]  R650      1.0267663002014160e-01
    z[1,2,5]  R651      -4.0106363594532013e-02
    z[1,2,5]  R652      2.9455076903104782e-02
    z[1,2,5]  R653      3.7211453914642334e-01
    z[1,2,5]  R654      -5.3069853782653809e-01
    z[1,2,5]  R655      -2.3428719490766525e-02
    z[1,2,5]  R656      -1.6490390896797180e-01
    z[1,2,5]  R657      2.6599767804145813e-01
    z[1,2,5]  R658      4.1694071888923645e-01
    z[1,2,5]  R659      -3.0218055844306946e-01
    z[1,2,5]  R660      -1.9956310093402863e-01
    z[1,2,5]  R661      -4.7557353973388672e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R595      -1
    z[1,2,6]  R596      1
    z[1,2,6]  R597      -2.8570449352264404e-01
    z[1,2,6]  R598      -8.4568858146667480e-02
    z[1,2,6]  R599      7.7060006558895111e-02
    z[1,2,6]  R600      -1.5992110967636108e-01
    z[1,2,6]  R601      -1.0853934288024902e-01
    z[1,2,6]  R602      -2.0229780673980713e-01
    z[1,2,6]  R603      -1.4012403786182404e-01
    z[1,2,6]  R604      -3.5348019003868103e-01
    z[1,2,6]  R605      3.8773542642593384e-01
    z[1,2,6]  R606      2.2128143906593323e-01
    z[1,2,6]  R607      -2.4946540594100952e-01
    z[1,2,6]  R608      -4.2940875887870789e-01
    z[1,2,6]  R609      -7.8437119722366333e-02
    z[1,2,6]  R610      4.6928480267524719e-01
    z[1,2,6]  R611      5.8387309312820435e-01
    z[1,2,6]  R612      -3.3137583732604980e-01
    z[1,2,6]  R613      -3.1044816970825195e-01
    z[1,2,6]  R614      -3.2080981135368347e-01
    z[1,2,6]  R615      -2.1905763447284698e-01
    z[1,2,6]  R616      7.9345032572746277e-02
    z[1,2,6]  R617      9.0372875332832336e-02
    z[1,2,6]  R618      -1.0624471306800842e-01
    z[1,2,6]  R619      -7.1111850440502167e-02
    z[1,2,6]  R620      -1.3775345683097839e-01
    z[1,2,6]  R621      -3.3822375535964966e-01
    z[1,2,6]  R622      2.3188921809196472e-01
    z[1,2,6]  R623      -2.0261134207248688e-01
    z[1,2,6]  R624      0.531879723072052
    z[1,2,6]  R625      3.3505034446716309e-01
    z[1,2,6]  R626      4.0646219253540039e-01
    z[1,2,6]  R627      -1.4600698649883270e-01
    z[1,2,6]  R628      -2.6989373564720154e-01
    z[1,2,6]  R629      -4.0338656306266785e-01
    z[1,2,6]  R630      -3.4699743986129761e-01
    z[1,2,6]  R631      -5.8023977279663086e-01
    z[1,2,6]  R632      -2.7896949648857117e-01
    z[1,2,6]  R633      2.6502072811126709e-02
    z[1,2,6]  R634      -5.0369039177894592e-02
    z[1,2,6]  R635      5.6097096204757690e-01
    z[1,2,6]  R636      8.5996669530868530e-01
    z[1,2,6]  R637      2.4351125955581665e-01
    z[1,2,6]  R638      1.1492806673049927e-01
    z[1,2,6]  R639      2.9832544922828674e-01
    z[1,2,6]  R640      -1.0901782661676407e-01
    z[1,2,6]  R641      2.0039934664964676e-02
    z[1,2,6]  R642      6.2712259590625763e-02
    z[1,2,6]  R643      2.9676163196563721e-01
    z[1,2,6]  R644      -4.8904288560152054e-02
    z[1,2,6]  R645      -4.3316057324409485e-01
    z[1,2,6]  R646      7.7260947227478027e-01
    z[1,2,6]  R647      3.7654605507850647e-01
    z[1,2,6]  R648      -8.4765374660491943e-02
    z[1,2,6]  R649      -7.4907653033733368e-03
    z[1,2,6]  R650      4.4425830245018005e-01
    z[1,2,6]  R651      1.0980103164911270e-01
    z[1,2,6]  R652      -0.080394446849823
    z[1,2,6]  R653      -2.1295015513896942e-01
    z[1,2,6]  R654      -3.3506935834884644e-01
    z[1,2,6]  R655      3.4158456325531006e-01
    z[1,2,6]  R656      -9.6297636628150940e-02
    z[1,2,6]  R657      -1.9954350590705872e-01
    z[1,2,6]  R658      2.0679706335067749e-01
    z[1,2,6]  R659      -1.9330868124961853e-01
    z[1,2,6]  R660      5.5426204204559326e-01
    z[1,2,6]  R661      3.5914307832717896e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R662      -1
    z[2,1,0]  R663      1
    z[2,1,0]  R676      -1.0609781742095947e-01
    z[2,1,0]  R677      -3.4289813041687012e-01
    z[2,1,0]  R678      -4.1695043444633484e-01
    z[2,1,0]  R679      -4.0962496399879456e-01
    z[2,1,0]  R680      1.7386958003044128e-01
    z[2,1,0]  R681      5.3327787667512894e-02
    z[2,1,0]  R682      5.7834988832473755e-01
    z[2,1,0]  R683      4.5682811737060547e-01
    z[2,1,0]  R684      6.1966693401336670e-01
    z[2,1,0]  R685      3.5519456863403320e-01
    z[2,1,0]  R686      -3.2717451453208923e-01
    z[2,1,0]  R687      1.8589578103274107e-03
    z[2,1,0]  R688      3.5171806812286377e-01
    z[2,1,0]  R689      -1.0059101879596710e-01
    z[2,1,0]  R690      -2.1450848877429962e-01
    z[2,1,0]  R691      4.8710286617279053e-01
    z[2,1,0]  R692      2.6665395498275757e-01
    z[2,1,0]  R693      2.2105872631072998e-01
    z[2,1,0]  R694      0.0990963950753212
    z[2,1,0]  R695      1.7798755317926407e-02
    z[2,1,0]  R696      1.1406289041042328e-01
    z[2,1,0]  R697      5.3117722272872925e-01
    z[2,1,0]  R698      1.7338527739048004e-01
    z[2,1,0]  R699      2.8216194361448288e-02
    z[2,1,0]  R700      1.5669876337051392e-01
    z[2,1,0]  R701      4.4781687855720520e-01
    z[2,1,0]  R702      3.3464625477790833e-01
    z[2,1,0]  R703      3.2121995091438293e-01
    z[2,1,0]  R704      5.7929539680480957e-01
    z[2,1,0]  R705      -2.3732288181781769e-01
    z[2,1,0]  R706      -1.1253122985363007e-01
    z[2,1,0]  R707      1.6066257655620575e-01
    z[2,1,0]  R708      2.9148164391517639e-01
    z[2,1,0]  R709      -6.2944769859313965e-02
    z[2,1,0]  R710      5.6542152166366577e-01
    z[2,1,0]  R711      3.5250759124755859e-01
    z[2,1,0]  R712      4.3026891350746155e-01
    z[2,1,0]  R713      2.9435160756111145e-01
    z[2,1,0]  R714      3.9072433114051819e-01
    z[2,1,0]  R715      -0.301540344953537
    z[2,1,0]  R716      -3.0550071597099304e-01
    z[2,1,0]  R717      -2.3596100509166718e-01
    z[2,1,0]  R718      2.5410386919975281e-01
    z[2,1,0]  R719      4.7374597191810608e-01
    z[2,1,0]  R720      4.8651728034019470e-01
    z[2,1,0]  R721      6.4232480525970459e-01
    z[2,1,0]  R722      4.4753953814506531e-01
    z[2,1,0]  R723      3.5032770037651062e-01
    z[2,1,0]  R724      5.7069998979568481e-01
    z[2,1,0]  R725      7.8782200813293457e-01
    z[2,1,0]  R726      -9.1499380767345428e-02
    z[2,1,0]  R727      -1.8841521441936493e-01
    z[2,1,0]  R728      -4.2797368764877319e-01
    z[2,1,0]  R729      -3.4564241766929626e-01
    z[2,1,0]  R730      -5.2983468770980835e-01
    z[2,1,0]  R731      -4.0331348776817322e-01
    z[2,1,0]  R732      -7.4129021167755127e-01
    z[2,1,0]  R733      4.6944785118103027e-01
    z[2,1,0]  R734      -1.6648881137371063e-01
    z[2,1,0]  R735      -2.2663618624210358e-01
    z[2,1,0]  R736      -1.2377069145441055e-01
    z[2,1,0]  R737      -5.1148599386215210e-01
    z[2,1,0]  R738      -1.9897338747978210e-01
    z[2,1,0]  R739      5.4989758878946304e-02
    z[2,1,0]  R740      -3.4354427456855774e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R664      -1
    z[2,1,1]  R665      1
    z[2,1,1]  R676      -5.0503000617027283e-02
    z[2,1,1]  R677      -6.7437969148159027e-02
    z[2,1,1]  R678      3.2634413801133633e-03
    z[2,1,1]  R679      -3.5629320889711380e-02
    z[2,1,1]  R680      -4.0873914957046509e-02
    z[2,1,1]  R681      2.9203820973634720e-02
    z[2,1,1]  R682      7.3784464597702026e-01
    z[2,1,1]  R683      7.5842893123626709e-01
    z[2,1,1]  R684      5.9752637147903442e-01
    z[2,1,1]  R685      -7.4232590198516846e-01
    z[2,1,1]  R686      -7.6864480972290039e-01
    z[2,1,1]  R687      -4.6451109647750854e-01
    z[2,1,1]  R688      -2.3297613859176636e-01
    z[2,1,1]  R689      -0.83770751953125
    z[2,1,1]  R690      -6.4848428964614868e-01
    z[2,1,1]  R691      -6.2998992204666138e-01
    z[2,1,1]  R692      -6.0057139396667480e-01
    z[2,1,1]  R693      -5.4732006788253784e-01
    z[2,1,1]  R694      -5.8858454227447510e-01
    z[2,1,1]  R695      -8.7194216251373291e-01
    z[2,1,1]  R696      -7.5847518444061279e-01
    z[2,1,1]  R697      -0.737540066242218
    z[2,1,1]  R698      -6.5106922388076782e-01
    z[2,1,1]  R699      -4.9031745642423630e-02
    z[2,1,1]  R700      -5.3413182497024536e-01
    z[2,1,1]  R701      4.4354477524757385e-01
    z[2,1,1]  R702      6.3502651453018188e-01
    z[2,1,1]  R703      7.8038352727890015e-01
    z[2,1,1]  R704      4.1401675343513489e-01
    z[2,1,1]  R705      -0.774492084980011
    z[2,1,1]  R706      -6.4482349157333374e-01
    z[2,1,1]  R707      -6.9996660947799683e-01
    z[2,1,1]  R708      -3.6509573459625244e-01
    z[2,1,1]  R709      -2.3846681416034698e-01
    z[2,1,1]  R710      -1.9123752415180206e-01
    z[2,1,1]  R711      6.3160890340805054e-01
    z[2,1,1]  R712      5.4495137929916382e-01
    z[2,1,1]  R713      6.7421919107437134e-01
    z[2,1,1]  R714      8.4285050630569458e-01
    z[2,1,1]  R715      -2.3346172273159027e-01
    z[2,1,1]  R716      -7.4203974008560181e-01
    z[2,1,1]  R717      -6.6759639978408813e-01
    z[2,1,1]  R718      -4.9453061074018478e-02
    z[2,1,1]  R719      8.1790482997894287e-01
    z[2,1,1]  R720      5.3430742025375366e-01
    z[2,1,1]  R721      4.5711231231689453e-01
    z[2,1,1]  R722      6.5081173181533813e-01
    z[2,1,1]  R723      7.2330325841903687e-01
    z[2,1,1]  R724      4.1058927774429321e-01
    z[2,1,1]  R725      1.8559511005878448e-01
    z[2,1,1]  R726      8.6331389844417572e-02
    z[2,1,1]  R727      -6.4906142652034760e-02
    z[2,1,1]  R728      4.4738192111253738e-02
    z[2,1,1]  R729      -6.0009807348251343e-02
    z[2,1,1]  R730      -4.8701085150241852e-02
    z[2,1,1]  R731      4.6199014782905579e-01
    z[2,1,1]  R732      -2.2323431447148323e-02
    z[2,1,1]  R733      -2.3589028418064117e-01
    z[2,1,1]  R734      4.7085127234458923e-01
    z[2,1,1]  R735      -4.2715936899185181e-01
    z[2,1,1]  R736      4.4058451056480408e-01
    z[2,1,1]  R737      5.4624825716018677e-01
    z[2,1,1]  R738      6.0098719596862793e-01
    z[2,1,1]  R739      5.0409317016601562e-01
    z[2,1,1]  R740      -3.8267418742179871e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R666      -1
    z[2,1,2]  R667      1
    z[2,1,2]  R676      6.5919585525989532e-02
    z[2,1,2]  R677      1.5690113604068756e-01
    z[2,1,2]  R678      -1.3273629546165466e-01
    z[2,1,2]  R679      2.4814562499523163e-01
    z[2,1,2]  R680      -1.4085343107581139e-02
    z[2,1,2]  R681      -3.6242190003395081e-01
    z[2,1,2]  R682      -3.3191487193107605e-01
    z[2,1,2]  R683      0.0945688933134079
    z[2,1,2]  R684      2.0823976397514343e-01
    z[2,1,2]  R685      -4.9097096920013428e-01
    z[2,1,2]  R686      -1.9649036228656769e-01
    z[2,1,2]  R687      2.1629586815834045e-01
    z[2,1,2]  R688      0.693274199962616
    z[2,1,2]  R689      -2.5046586990356445e-01
    z[2,1,2]  R690      3.4714984893798828e-01
    z[2,1,2]  R691      1.4693361520767212e-01
    z[2,1,2]  R692      -2.0404672622680664e-01
    z[2,1,2]  R693      -4.6474647521972656e-01
    z[2,1,2]  R694      -4.5270577073097229e-01
    z[2,1,2]  R695      -1.9578759372234344e-01
    z[2,1,2]  R696      2.8505036234855652e-01
    z[2,1,2]  R697      -3.2137352973222733e-02
    z[2,1,2]  R698      1.6045522689819336e-01
    z[2,1,2]  R699      -2.9685732722282410e-01
    z[2,1,2]  R700      -3.7420034408569336e-01
    z[2,1,2]  R701      -2.1563017368316650e-01
    z[2,1,2]  R702      3.0412617325782776e-01
    z[2,1,2]  R703      4.7782737016677856e-01
    z[2,1,2]  R704      -1.0993339121341705e-01
    z[2,1,2]  R705      4.3414631485939026e-01
    z[2,1,2]  R706      -6.0789614915847778e-01
    z[2,1,2]  R707      -4.0976539254188538e-01
    z[2,1,2]  R708      -2.6562992483377457e-02
    z[2,1,2]  R709      -2.7773827314376831e-01
    z[2,1,2]  R710      1.0486693121492863e-02
    z[2,1,2]  R711      -9.5970399677753448e-02
    z[2,1,2]  R712      1.6788119077682495e-01
    z[2,1,2]  R713      -7.4469313025474548e-02
    z[2,1,2]  R714      3.2411456108093262e-01
    z[2,1,2]  R715      1.6742104291915894e-01
    z[2,1,2]  R716      -3.0482724308967590e-01
    z[2,1,2]  R717      1.1141819506883621e-01
    z[2,1,2]  R718      -5.6936436891555786e-01
    z[2,1,2]  R719      1.6606016457080841e-01
    z[2,1,2]  R720      -1.3456906378269196e-01
    z[2,1,2]  R721      -1.5954619273543358e-02
    z[2,1,2]  R722      9.6836470067501068e-02
    z[2,1,2]  R723      5.0356034189462662e-02
    z[2,1,2]  R724      2.9992294311523438e-01
    z[2,1,2]  R725      -3.7961982190608978e-02
    z[2,1,2]  R726      -2.0295926928520203e-01
    z[2,1,2]  R727      -4.9763530492782593e-01
    z[2,1,2]  R728      -3.9014372229576111e-01
    z[2,1,2]  R729      -4.2751175165176392e-01
    z[2,1,2]  R730      -3.1068110838532448e-03
    z[2,1,2]  R731      -4.9676337838172913e-01
    z[2,1,2]  R732      -5.3054824471473694e-02
    z[2,1,2]  R733      3.4527891874313354e-01
    z[2,1,2]  R734      -2.4652208387851715e-01
    z[2,1,2]  R735      2.2169497609138489e-01
    z[2,1,2]  R736      3.6531981825828552e-01
    z[2,1,2]  R737      -5.1182711124420166e-01
    z[2,1,2]  R738      -8.2438193261623383e-02
    z[2,1,2]  R739      -5.5990350246429443e-01
    z[2,1,2]  R740      3.3791989088058472e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R668      -1
    z[2,1,3]  R669      1
    z[2,1,3]  R676      -9.0902382135391235e-01
    z[2,1,3]  R677      -7.4488759040832520e-01
    z[2,1,3]  R678      -7.3872792720794678e-01
    z[2,1,3]  R679      -7.1963566541671753e-01
    z[2,1,3]  R680      -8.4947013854980469e-01
    z[2,1,3]  R681      -6.7806845903396606e-01
    z[2,1,3]  R682      6.8751536309719086e-02
    z[2,1,3]  R683      -4.6488042920827866e-02
    z[2,1,3]  R684      -2.6350151747465134e-02
    z[2,1,3]  R685      -1.4525451697409153e-02
    z[2,1,3]  R686      2.5759249925613403e-01
    z[2,1,3]  R687      -5.7335708290338516e-02
    z[2,1,3]  R688      -2.7631255984306335e-01
    z[2,1,3]  R689      2.0623576641082764e-01
    z[2,1,3]  R690      4.7101509571075439e-01
    z[2,1,3]  R691      4.3801674246788025e-01
    z[2,1,3]  R692      1.6934689879417419e-01
    z[2,1,3]  R693      3.1265792250633240e-01
    z[2,1,3]  R694      1.8767033517360687e-01
    z[2,1,3]  R695      -1.3730492442846298e-02
    z[2,1,3]  R696      4.7327306866645813e-01
    z[2,1,3]  R697      3.6038488149642944e-01
    z[2,1,3]  R698      3.5026934742927551e-01
    z[2,1,3]  R699      -3.5700049996376038e-01
    z[2,1,3]  R700      4.5172271132469177e-01
    z[2,1,3]  R701      6.7419892549514771e-01
    z[2,1,3]  R702      5.0025576353073120e-01
    z[2,1,3]  R703      8.1911824643611908e-02
    z[2,1,3]  R704      4.2093262076377869e-02
    z[2,1,3]  R705      -2.3202177882194519e-01
    z[2,1,3]  R706      -2.6309096813201904e-01
    z[2,1,3]  R707      -3.6003756523132324e-01
    z[2,1,3]  R708      -5.2444475889205933e-01
    z[2,1,3]  R709      -4.5565196871757507e-01
    z[2,1,3]  R710      -5.5628603696823120e-01
    z[2,1,3]  R711      6.5259546041488647e-01
    z[2,1,3]  R712      5.7947164773941040e-01
    z[2,1,3]  R713      4.9359327554702759e-01
    z[2,1,3]  R714      -6.3951924443244934e-02
    z[2,1,3]  R715      -0.901881217956543
    z[2,1,3]  R716      -2.7289089560508728e-01
    z[2,1,3]  R717      -1.7915260791778564e-01
    z[2,1,3]  R718      -6.3319075107574463e-01
    z[2,1,3]  R719      9.9597439169883728e-02
    z[2,1,3]  R720      0.581642210483551
    z[2,1,3]  R721      3.8312000036239624e-01
    z[2,1,3]  R722      3.3111450076103210e-01
    z[2,1,3]  R723      -4.5543190091848373e-02
    z[2,1,3]  R724      2.4427708983421326e-01
    z[2,1,3]  R725      -1.9140833616256714e-01
    z[2,1,3]  R726      -8.7153857946395874e-01
    z[2,1,3]  R727      -7.4942690134048462e-01
    z[2,1,3]  R728      -7.6530581712722778e-01
    z[2,1,3]  R729      -7.4175614118576050e-01
    z[2,1,3]  R730      -7.6331532001495361e-01
    z[2,1,3]  R731      -2.5657391548156738e-01
    z[2,1,3]  R732      0.00394494878128171
    z[2,1,3]  R733      0.538794219493866
    z[2,1,3]  R734      6.4446341991424561e-01
    z[2,1,3]  R735      3.4445956349372864e-01
    z[2,1,3]  R736      1.4134380221366882e-01
    z[2,1,3]  R737      2.7410295605659485e-01
    z[2,1,3]  R738      1.5015423297882080e-01
    z[2,1,3]  R739      -4.2969822883605957e-02
    z[2,1,3]  R740      3.9759820699691772e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R670      -1
    z[2,1,4]  R671      1
    z[2,1,4]  R676      -6.6306792199611664e-02
    z[2,1,4]  R677      4.3965074419975281e-01
    z[2,1,4]  R678      4.4334211945533752e-01
    z[2,1,4]  R679      1.6884812712669373e-01
    z[2,1,4]  R680      -3.4588897228240967e-01
    z[2,1,4]  R681      -3.7867131829261780e-01
    z[2,1,4]  R682      7.8314365819096565e-03
    z[2,1,4]  R683      4.1429454088211060e-01
    z[2,1,4]  R684      -1.2736883759498596e-01
    z[2,1,4]  R685      1.5730260312557220e-01
    z[2,1,4]  R686      2.1937662363052368e-01
    z[2,1,4]  R687      1.5066680312156677e-01
    z[2,1,4]  R688      1.6973850131034851e-01
    z[2,1,4]  R689      1.2679381668567657e-01
    z[2,1,4]  R690      -1.1155434697866440e-01
    z[2,1,4]  R691      1.6030846536159515e-01
    z[2,1,4]  R692      -5.6932407617568970e-01
    z[2,1,4]  R693      2.9742112755775452e-01
    z[2,1,4]  R694      -1.7082078754901886e-01
    z[2,1,4]  R695      -1.8431127071380615e-01
    z[2,1,4]  R696      2.8770866990089417e-01
    z[2,1,4]  R697      -1.8145841360092163e-01
    z[2,1,4]  R698      -2.6810136437416077e-01
    z[2,1,4]  R699      1.8248723447322845e-01
    z[2,1,4]  R700      -3.3276686072349548e-01
    z[2,1,4]  R701      0.265112966299057
    z[2,1,4]  R702      -2.2561891376972198e-01
    z[2,1,4]  R703      -5.3866151720285416e-02
    z[2,1,4]  R704      5.6937980651855469e-01
    z[2,1,4]  R705      -2.1870298683643341e-01
    z[2,1,4]  R706      2.0903086662292480e-01
    z[2,1,4]  R707      -4.2719554901123047e-01
    z[2,1,4]  R708      2.5150260329246521e-01
    z[2,1,4]  R709      5.7169649749994278e-02
    z[2,1,4]  R710      3.5505077242851257e-01
    z[2,1,4]  R711      1.1017717421054840e-01
    z[2,1,4]  R712      -3.7148892879486084e-01
    z[2,1,4]  R713      -4.1202649474143982e-02
    z[2,1,4]  R714      -1.1888147145509720e-01
    z[2,1,4]  R715      7.6279595494270325e-02
    z[2,1,4]  R716      6.9572590291500092e-02
    z[2,1,4]  R717      2.4538795650005341e-01
    z[2,1,4]  R718      -3.0108207464218140e-01
    z[2,1,4]  R719      1.8064978718757629e-01
    z[2,1,4]  R720      1.0405606776475906e-01
    z[2,1,4]  R721      1.2176611274480820e-01
    z[2,1,4]  R722      -3.5840880870819092e-01
    z[2,1,4]  R723      -4.9609247595071793e-02
    z[2,1,4]  R724      -3.0643252655863762e-02
    z[2,1,4]  R725      -2.2562074661254883e-01
    z[2,1,4]  R726      4.1770094633102417e-01
    z[2,1,4]  R727      9.3129336833953857e-02
    z[2,1,4]  R728      -2.1449530124664307e-01
    z[2,1,4]  R729      2.4335640668869019e-01
    z[2,1,4]  R730      -5.7202443480491638e-02
    z[2,1,4]  R731      5.2923923730850220e-01
    z[2,1,4]  R732      5.5525940656661987e-01
    z[2,1,4]  R733      1.3088180124759674e-01
    z[2,1,4]  R734      -2.1067827939987183e-01
    z[2,1,4]  R735      -6.9597214460372925e-01
    z[2,1,4]  R736      -4.6219328045845032e-01
    z[2,1,4]  R737      -5.0360444001853466e-03
    z[2,1,4]  R738      2.0514579117298126e-01
    z[2,1,4]  R739      -2.5430586934089661e-01
    z[2,1,4]  R740      -4.5101216435432434e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R672      -1
    z[2,1,5]  R673      1
    z[2,1,5]  R676      -2.3398378491401672e-01
    z[2,1,5]  R677      -4.6752616763114929e-02
    z[2,1,5]  R678      1.3514953851699829e-01
    z[2,1,5]  R679      0.46548992395401
    z[2,1,5]  R680      0.344230055809021
    z[2,1,5]  R681      5.0049668550491333e-01
    z[2,1,5]  R682      -3.2925210893154144e-02
    z[2,1,5]  R683      -1.1988820135593414e-01
    z[2,1,5]  R684      2.9034256935119629e-01
    z[2,1,5]  R685      5.4852332919836044e-02
    z[2,1,5]  R686      3.2863688468933105e-01
    z[2,1,5]  R687      -6.5464353561401367e-01
    z[2,1,5]  R688      -3.5209223628044128e-01
    z[2,1,5]  R689      -3.9660032838582993e-02
    z[2,1,5]  R690      3.9664039015769958e-01
    z[2,1,5]  R691      -2.3206442594528198e-01
    z[2,1,5]  R692      -1.0509885102510452e-01
    z[2,1,5]  R693      -3.5911419987678528e-01
    z[2,1,5]  R694      -1.9423596560955048e-01
    z[2,1,5]  R695      -2.9846975207328796e-01
    z[2,1,5]  R696      -1.5160897374153137e-01
    z[2,1,5]  R697      8.6666487157344818e-02
    z[2,1,5]  R698      -1.0509578138589859e-01
    z[2,1,5]  R699      -9.1551892459392548e-02
    z[2,1,5]  R700      4.1956865787506104e-01
    z[2,1,5]  R701      1.3488624989986420e-01
    z[2,1,5]  R702      -4.5855108648538589e-02
    z[2,1,5]  R703      -1.9494697451591492e-01
    z[2,1,5]  R704      3.9313459396362305e-01
    z[2,1,5]  R705      2.2306744754314423e-01
    z[2,1,5]  R706      -3.1990390270948410e-02
    z[2,1,5]  R707      4.2567834258079529e-02
    z[2,1,5]  R708      5.0508803129196167e-01
    z[2,1,5]  R709      2.3285277187824249e-01
    z[2,1,5]  R710      -2.5751617550849915e-01
    z[2,1,5]  R711      -1.4964435994625092e-01
    z[2,1,5]  R712      1.2595626711845398e-01
    z[2,1,5]  R713      1.0267663002014160e-01
    z[2,1,5]  R714      -4.0106363594532013e-02
    z[2,1,5]  R715      2.9455076903104782e-02
    z[2,1,5]  R716      3.7211453914642334e-01
    z[2,1,5]  R717      -5.3069853782653809e-01
    z[2,1,5]  R718      -2.3428719490766525e-02
    z[2,1,5]  R719      -1.6490390896797180e-01
    z[2,1,5]  R720      2.6599767804145813e-01
    z[2,1,5]  R721      4.1694071888923645e-01
    z[2,1,5]  R722      -3.0218055844306946e-01
    z[2,1,5]  R723      -1.9956310093402863e-01
    z[2,1,5]  R724      -4.7557353973388672e-01
    z[2,1,5]  R725      4.1746962070465088e-01
    z[2,1,5]  R726      -4.2152579873800278e-02
    z[2,1,5]  R727      -3.6931574344635010e-01
    z[2,1,5]  R728      -0.0731348991394043
    z[2,1,5]  R729      2.7010822296142578e-01
    z[2,1,5]  R730      3.0007827281951904e-01
    z[2,1,5]  R731      -1.0756545513868332e-01
    z[2,1,5]  R732      -1.1789335310459137e-01
    z[2,1,5]  R733      -3.8339126110076904e-01
    z[2,1,5]  R734      4.2558598518371582e-01
    z[2,1,5]  R735      2.2750738263130188e-01
    z[2,1,5]  R736      -4.8899385333061218e-01
    z[2,1,5]  R737      3.1099513173103333e-01
    z[2,1,5]  R738      5.5458873510360718e-01
    z[2,1,5]  R739      -1.4815038442611694e-01
    z[2,1,5]  R740      3.8735222816467285e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R674      -1
    z[2,1,6]  R675      1
    z[2,1,6]  R676      -3.1044816970825195e-01
    z[2,1,6]  R677      -3.2080981135368347e-01
    z[2,1,6]  R678      -2.1905763447284698e-01
    z[2,1,6]  R679      7.9345032572746277e-02
    z[2,1,6]  R680      9.0372875332832336e-02
    z[2,1,6]  R681      -1.0624471306800842e-01
    z[2,1,6]  R682      -7.1111850440502167e-02
    z[2,1,6]  R683      -1.3775345683097839e-01
    z[2,1,6]  R684      -3.3822375535964966e-01
    z[2,1,6]  R685      2.3188921809196472e-01
    z[2,1,6]  R686      -2.0261134207248688e-01
    z[2,1,6]  R687      0.531879723072052
    z[2,1,6]  R688      3.3505034446716309e-01
    z[2,1,6]  R689      4.0646219253540039e-01
    z[2,1,6]  R690      -1.4600698649883270e-01
    z[2,1,6]  R691      -2.6989373564720154e-01
    z[2,1,6]  R692      -4.0338656306266785e-01
    z[2,1,6]  R693      -3.4699743986129761e-01
    z[2,1,6]  R694      -5.8023977279663086e-01
    z[2,1,6]  R695      -2.7896949648857117e-01
    z[2,1,6]  R696      2.6502072811126709e-02
    z[2,1,6]  R697      -5.0369039177894592e-02
    z[2,1,6]  R698      5.6097096204757690e-01
    z[2,1,6]  R699      8.5996669530868530e-01
    z[2,1,6]  R700      2.4351125955581665e-01
    z[2,1,6]  R701      1.1492806673049927e-01
    z[2,1,6]  R702      2.9832544922828674e-01
    z[2,1,6]  R703      -1.0901782661676407e-01
    z[2,1,6]  R704      2.0039934664964676e-02
    z[2,1,6]  R705      6.2712259590625763e-02
    z[2,1,6]  R706      2.9676163196563721e-01
    z[2,1,6]  R707      -4.8904288560152054e-02
    z[2,1,6]  R708      -4.3316057324409485e-01
    z[2,1,6]  R709      7.7260947227478027e-01
    z[2,1,6]  R710      3.7654605507850647e-01
    z[2,1,6]  R711      -8.4765374660491943e-02
    z[2,1,6]  R712      -7.4907653033733368e-03
    z[2,1,6]  R713      4.4425830245018005e-01
    z[2,1,6]  R714      1.0980103164911270e-01
    z[2,1,6]  R715      -0.080394446849823
    z[2,1,6]  R716      -2.1295015513896942e-01
    z[2,1,6]  R717      -3.3506935834884644e-01
    z[2,1,6]  R718      3.4158456325531006e-01
    z[2,1,6]  R719      -9.6297636628150940e-02
    z[2,1,6]  R720      -1.9954350590705872e-01
    z[2,1,6]  R721      2.0679706335067749e-01
    z[2,1,6]  R722      -1.9330868124961853e-01
    z[2,1,6]  R723      5.5426204204559326e-01
    z[2,1,6]  R724      3.5914307832717896e-01
    z[2,1,6]  R725      -2.8570449352264404e-01
    z[2,1,6]  R726      -8.4568858146667480e-02
    z[2,1,6]  R727      7.7060006558895111e-02
    z[2,1,6]  R728      -1.5992110967636108e-01
    z[2,1,6]  R729      -1.0853934288024902e-01
    z[2,1,6]  R730      -2.0229780673980713e-01
    z[2,1,6]  R731      -1.4012403786182404e-01
    z[2,1,6]  R732      -3.5348019003868103e-01
    z[2,1,6]  R733      3.8773542642593384e-01
    z[2,1,6]  R734      2.2128143906593323e-01
    z[2,1,6]  R735      -2.4946540594100952e-01
    z[2,1,6]  R736      -4.2940875887870789e-01
    z[2,1,6]  R737      -7.8437119722366333e-02
    z[2,1,6]  R738      4.6928480267524719e-01
    z[2,1,6]  R739      5.8387309312820435e-01
    z[2,1,6]  R740      -3.3137583732604980e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R741      -1
    z[2,3,0]  R742      1
    z[2,3,0]  R755      -1.0609781742095947e-01
    z[2,3,0]  R756      -3.4289813041687012e-01
    z[2,3,0]  R757      -4.1695043444633484e-01
    z[2,3,0]  R758      -4.0962496399879456e-01
    z[2,3,0]  R759      1.7386958003044128e-01
    z[2,3,0]  R760      5.3327787667512894e-02
    z[2,3,0]  R761      5.7834988832473755e-01
    z[2,3,0]  R762      4.5682811737060547e-01
    z[2,3,0]  R763      6.1966693401336670e-01
    z[2,3,0]  R764      3.5519456863403320e-01
    z[2,3,0]  R765      -3.2717451453208923e-01
    z[2,3,0]  R766      1.8589578103274107e-03
    z[2,3,0]  R767      3.5171806812286377e-01
    z[2,3,0]  R768      -1.0059101879596710e-01
    z[2,3,0]  R769      -2.1450848877429962e-01
    z[2,3,0]  R770      4.8710286617279053e-01
    z[2,3,0]  R771      2.6665395498275757e-01
    z[2,3,0]  R772      2.2105872631072998e-01
    z[2,3,0]  R773      0.0990963950753212
    z[2,3,0]  R774      1.7798755317926407e-02
    z[2,3,0]  R775      1.1406289041042328e-01
    z[2,3,0]  R776      5.3117722272872925e-01
    z[2,3,0]  R777      1.7338527739048004e-01
    z[2,3,0]  R778      2.8216194361448288e-02
    z[2,3,0]  R779      1.5669876337051392e-01
    z[2,3,0]  R780      4.4781687855720520e-01
    z[2,3,0]  R781      3.3464625477790833e-01
    z[2,3,0]  R782      3.2121995091438293e-01
    z[2,3,0]  R783      5.7929539680480957e-01
    z[2,3,0]  R784      -2.3732288181781769e-01
    z[2,3,0]  R785      -1.1253122985363007e-01
    z[2,3,0]  R786      1.6066257655620575e-01
    z[2,3,0]  R787      2.9148164391517639e-01
    z[2,3,0]  R788      -6.2944769859313965e-02
    z[2,3,0]  R789      5.6542152166366577e-01
    z[2,3,0]  R790      3.5250759124755859e-01
    z[2,3,0]  R791      4.3026891350746155e-01
    z[2,3,0]  R792      2.9435160756111145e-01
    z[2,3,0]  R793      3.9072433114051819e-01
    z[2,3,0]  R794      -0.301540344953537
    z[2,3,0]  R795      -3.0550071597099304e-01
    z[2,3,0]  R796      -2.3596100509166718e-01
    z[2,3,0]  R797      2.5410386919975281e-01
    z[2,3,0]  R798      4.7374597191810608e-01
    z[2,3,0]  R799      4.8651728034019470e-01
    z[2,3,0]  R800      6.4232480525970459e-01
    z[2,3,0]  R801      4.4753953814506531e-01
    z[2,3,0]  R802      3.5032770037651062e-01
    z[2,3,0]  R803      5.7069998979568481e-01
    z[2,3,0]  R804      7.3081964254379272e-01
    z[2,3,0]  R805      7.5236237049102783e-01
    z[2,3,0]  R806      6.4019095897674561e-01
    z[2,3,0]  R807      7.5551462173461914e-01
    z[2,3,0]  R808      7.9268425703048706e-01
    z[2,3,0]  R809      5.8187460899353027e-01
    z[2,3,0]  R810      7.8306490182876587e-01
    z[2,3,0]  R811      7.6801878213882446e-01
    z[2,3,0]  R812      -1.7464710399508476e-02
    z[2,3,0]  R813      -5.1970733329653740e-04
    z[2,3,0]  R814      -3.7451930344104767e-02
    z[2,3,0]  R815      -1.7085577547550201e-01
    z[2,3,0]  R816      -1.3820216059684753e-01
    z[2,3,0]  R817      -2.9620608687400818e-01
    z[2,3,0]  R818      -3.9036303758621216e-01
    z[2,3,0]  R819      -1.3025595247745514e-01
    z[2,3,0]  R820      -8.9698553085327148e-02
    z[2,3,0]  R821      -0.651669979095459
    z[2,3,0]  R822      -5.4056859016418457e-01
    z[2,3,0]  R823      -3.8065171241760254e-01
    z[2,3,0]  R824      6.7949414253234863e-02
    z[2,3,0]  R825      -5.3215283155441284e-01
    z[2,3,0]  R826      -3.6922167986631393e-02
    z[2,3,0]  R827      -3.3193930983543396e-01
    z[2,3,0]  R828      -9.1507446765899658e-01
    z[2,3,0]  R829      -9.1097509860992432e-01
    z[2,3,0]  R830      -3.6560615897178650e-01
    z[2,3,0]  R831      2.1802823990583420e-02
    z[2,3,0]  R832      -8.8899797201156616e-01
    z[2,3,0]  R833      -8.7273043394088745e-01
    z[2,3,0]  R834      -4.3535541743040085e-02
    z[2,3,0]  R835      6.1079227924346924e-01
    z[2,3,0]  R836      -2.8745830059051514e-01
    z[2,3,0]  R837      -6.3473924994468689e-02
    z[2,3,0]  R838      2.5515419244766235e-01
    z[2,3,0]  R839      -3.7279021739959717e-01
    z[2,3,0]  R840      -6.3946500420570374e-02
    z[2,3,0]  R841      1.7163048684597015e-01
    z[2,3,0]  R842      -3.3679354190826416e-01
    z[2,3,0]  R843      -6.0315674543380737e-01
    z[2,3,0]  R844      -4.9866211414337158e-01
    z[2,3,0]  R845      5.8716970682144165e-01
    z[2,3,0]  R846      2.4355675280094147e-01
    z[2,3,0]  R847      -9.8377957940101624e-02
    z[2,3,0]  R848      -9.1336077451705933e-01
    z[2,3,0]  R849      -2.0049074292182922e-01
    z[2,3,0]  R850      -0.793777346611023
    z[2,3,0]  R851      -1.3446946442127228e-01
    z[2,3,0]  R852      -7.6299661397933960e-01
    z[2,3,0]  R853      -2.5040575861930847e-01
    z[2,3,0]  R854      -4.8506896942853928e-02
    z[2,3,0]  R855      3.9443102478981018e-01
    z[2,3,0]  R856      -3.4812141209840775e-02
    z[2,3,0]  R857      -6.8137490749359131e-01
    z[2,3,0]  R858      -4.9739876389503479e-01
    z[2,3,0]  R859      -7.7618694305419922e-01
    z[2,3,0]  R860      -8.8468819856643677e-01
    z[2,3,0]  R861      -8.9799350500106812e-01
    z[2,3,0]  R862      -3.6623382568359375e-01
    z[2,3,0]  R863      -8.2222521305084229e-01
    z[2,3,0]  R864      -9.5417900010943413e-03
    z[2,3,0]  R865      -5.6352788209915161e-01
    z[2,3,0]  R866      -0.457535058259964
    z[2,3,0]  R867      -4.6804243326187134e-01
    z[2,3,0]  R868      -5.3360491991043091e-01
    z[2,3,0]  R869      -9.5024204254150391e-01
    z[2,3,0]  R870      -9.2259037494659424e-01
    z[2,3,0]  R871      -8.5279864072799683e-01
    z[2,3,0]  R872      -4.1459599137306213e-01
    z[2,3,0]  R873      -1.6792495548725128e-01
    z[2,3,0]  R874      -4.4118997454643250e-01
    z[2,3,0]  R875      -5.4312908649444580e-01
    z[2,3,0]  R876      -2.4107502773404121e-02
    z[2,3,0]  R877      -4.8570921644568443e-03
    z[2,3,0]  R878      -5.8970987796783447e-01
    z[2,3,0]  R879      4.0796521306037903e-01
    z[2,3,0]  R880      -8.3640134334564209e-01
    z[2,3,0]  R881      -7.5629872083663940e-01
    z[2,3,0]  R882      -2.3148091509938240e-02
    z[2,3,0]  R883      -5.3866463899612427e-01
    z[2,3,0]  R884      1.6193255782127380e-01
    z[2,3,0]  R885      4.9023322761058807e-02
    z[2,3,0]  R886      9.2316336929798126e-02
    z[2,3,0]  R887      -9.0431171655654907e-01
    z[2,3,0]  R888      -8.4467101097106934e-01
    z[2,3,0]  R889      -3.7108820676803589e-01
    z[2,3,0]  R890      -3.4779664874076843e-01
    z[2,3,0]  R891      -1.0684672743082047e-01
    z[2,3,0]  R892      -1.9758220016956329e-01
    z[2,3,0]  R893      -5.0120222568511963e-01
    z[2,3,0]  R894      3.2902139425277710e-01
    z[2,3,0]  R895      3.8526329398155212e-01
    z[2,3,0]  R896      -6.9628250598907471e-01
    z[2,3,0]  R897      -9.1065317392349243e-01
    z[2,3,0]  R898      -8.7985646724700928e-01
    z[2,3,0]  R899      -8.5753923654556274e-01
    z[2,3,0]  R900      -5.2138119935989380e-01
    z[2,3,0]  R901      -0.281818151473999
    z[2,3,0]  R902      -4.4188895821571350e-01
    z[2,3,0]  R903      -4.0765147656202316e-02
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R743      -1
    z[2,3,1]  R744      1
    z[2,3,1]  R755      -5.0503000617027283e-02
    z[2,3,1]  R756      -6.7437969148159027e-02
    z[2,3,1]  R757      3.2634413801133633e-03
    z[2,3,1]  R758      -3.5629320889711380e-02
    z[2,3,1]  R759      -4.0873914957046509e-02
    z[2,3,1]  R760      2.9203820973634720e-02
    z[2,3,1]  R761      7.3784464597702026e-01
    z[2,3,1]  R762      7.5842893123626709e-01
    z[2,3,1]  R763      5.9752637147903442e-01
    z[2,3,1]  R764      -7.4232590198516846e-01
    z[2,3,1]  R765      -7.6864480972290039e-01
    z[2,3,1]  R766      -4.6451109647750854e-01
    z[2,3,1]  R767      -2.3297613859176636e-01
    z[2,3,1]  R768      -0.83770751953125
    z[2,3,1]  R769      -6.4848428964614868e-01
    z[2,3,1]  R770      -6.2998992204666138e-01
    z[2,3,1]  R771      -6.0057139396667480e-01
    z[2,3,1]  R772      -5.4732006788253784e-01
    z[2,3,1]  R773      -5.8858454227447510e-01
    z[2,3,1]  R774      -8.7194216251373291e-01
    z[2,3,1]  R775      -7.5847518444061279e-01
    z[2,3,1]  R776      -0.737540066242218
    z[2,3,1]  R777      -6.5106922388076782e-01
    z[2,3,1]  R778      -4.9031745642423630e-02
    z[2,3,1]  R779      -5.3413182497024536e-01
    z[2,3,1]  R780      4.4354477524757385e-01
    z[2,3,1]  R781      6.3502651453018188e-01
    z[2,3,1]  R782      7.8038352727890015e-01
    z[2,3,1]  R783      4.1401675343513489e-01
    z[2,3,1]  R784      -0.774492084980011
    z[2,3,1]  R785      -6.4482349157333374e-01
    z[2,3,1]  R786      -6.9996660947799683e-01
    z[2,3,1]  R787      -3.6509573459625244e-01
    z[2,3,1]  R788      -2.3846681416034698e-01
    z[2,3,1]  R789      -1.9123752415180206e-01
    z[2,3,1]  R790      6.3160890340805054e-01
    z[2,3,1]  R791      5.4495137929916382e-01
    z[2,3,1]  R792      6.7421919107437134e-01
    z[2,3,1]  R793      8.4285050630569458e-01
    z[2,3,1]  R794      -2.3346172273159027e-01
    z[2,3,1]  R795      -7.4203974008560181e-01
    z[2,3,1]  R796      -6.6759639978408813e-01
    z[2,3,1]  R797      -4.9453061074018478e-02
    z[2,3,1]  R798      8.1790482997894287e-01
    z[2,3,1]  R799      5.3430742025375366e-01
    z[2,3,1]  R800      4.5711231231689453e-01
    z[2,3,1]  R801      6.5081173181533813e-01
    z[2,3,1]  R802      7.2330325841903687e-01
    z[2,3,1]  R803      4.1058927774429321e-01
    z[2,3,1]  R804      1.3711350969970226e-02
    z[2,3,1]  R805      5.4299894720315933e-02
    z[2,3,1]  R806      2.4019737541675568e-01
    z[2,3,1]  R807      3.7223255634307861e-01
    z[2,3,1]  R808      2.8006935119628906e-01
    z[2,3,1]  R809      3.9857888221740723e-01
    z[2,3,1]  R810      4.2062580585479736e-01
    z[2,3,1]  R811      -2.2349764406681061e-01
    z[2,3,1]  R812      7.9020828008651733e-01
    z[2,3,1]  R813      7.2798633575439453e-01
    z[2,3,1]  R814      7.1584838628768921e-01
    z[2,3,1]  R815      -2.1504734456539154e-01
    z[2,3,1]  R816      6.5834307670593262e-01
    z[2,3,1]  R817      6.4349353313446045e-01
    z[2,3,1]  R818      8.0013543367385864e-02
    z[2,3,1]  R819      5.5630236864089966e-01
    z[2,3,1]  R820      5.1694333553314209e-01
    z[2,3,1]  R821      1.1657485365867615e-01
    z[2,3,1]  R822      1.8256975710391998e-01
    z[2,3,1]  R823      0.0415816530585289
    z[2,3,1]  R824      2.3756314814090729e-01
    z[2,3,1]  R825      -2.9377132654190063e-02
    z[2,3,1]  R826      -5.2666097879409790e-01
    z[2,3,1]  R827      5.0524920225143433e-01
    z[2,3,1]  R828      1.1464839428663254e-01
    z[2,3,1]  R829      -1.9159886986017227e-02
    z[2,3,1]  R830      4.8104834556579590e-01
    z[2,3,1]  R831      4.5014080405235291e-01
    z[2,3,1]  R832      -6.3170604407787323e-02
    z[2,3,1]  R833      2.7494031190872192e-01
    z[2,3,1]  R834      4.4470425695180893e-02
    z[2,3,1]  R835      -9.6938237547874451e-03
    z[2,3,1]  R836      4.1444137692451477e-01
    z[2,3,1]  R837      5.4111951589584351e-01
    z[2,3,1]  R838      0.627250611782074
    z[2,3,1]  R839      5.6994384527206421e-01
    z[2,3,1]  R840      -4.6652853488922119e-01
    z[2,3,1]  R841      -5.2630335092544556e-01
    z[2,3,1]  R842      4.4160258769989014e-01
    z[2,3,1]  R843      -5.4234772920608521e-01
    z[2,3,1]  R844      6.7723000049591064e-01
    z[2,3,1]  R845      -4.7758162021636963e-02
    z[2,3,1]  R846      -5.6062698364257812e-01
    z[2,3,1]  R847      4.3963938951492310e-01
    z[2,3,1]  R848      -1.6114315390586853e-01
    z[2,3,1]  R849      -9.4882321357727051e-01
    z[2,3,1]  R850      4.0067046880722046e-02
    z[2,3,1]  R851      -9.2889207601547241e-01
    z[2,3,1]  R852      -2.3473416268825531e-01
    z[2,3,1]  R853      -9.0752846002578735e-01
    z[2,3,1]  R854      7.4260032176971436e-01
    z[2,3,1]  R855      -6.6749060153961182e-01
    z[2,3,1]  R856      -4.7623196244239807e-01
    z[2,3,1]  R857      6.0549920797348022e-01
    z[2,3,1]  R858      4.7995755076408386e-01
    z[2,3,1]  R859      -4.0013200044631958e-01
    z[2,3,1]  R860      7.1967437863349915e-02
    z[2,3,1]  R861      -8.7360413745045662e-03
    z[2,3,1]  R862      6.3114196062088013e-02
    z[2,3,1]  R863      6.9946028292179108e-02
    z[2,3,1]  R864      7.9096013307571411e-01
    z[2,3,1]  R865      6.5089470148086548e-01
    z[2,3,1]  R866      5.2843958139419556e-01
    z[2,3,1]  R867      1.1336542665958405e-01
    z[2,3,1]  R868      5.1968789100646973e-01
    z[2,3,1]  R869      -4.5264068990945816e-02
    z[2,3,1]  R870      -5.3006079047918320e-02
    z[2,3,1]  R871      2.8267037868499756e-01
    z[2,3,1]  R872      1.7081966996192932e-01
    z[2,3,1]  R873      -8.8181960582733154e-01
    z[2,3,1]  R874      6.4701217412948608e-01
    z[2,3,1]  R875      -1.5277132391929626e-01
    z[2,3,1]  R876      5.6754022836685181e-01
    z[2,3,1]  R877      1.6682486236095428e-01
    z[2,3,1]  R878      1.8880617618560791e-01
    z[2,3,1]  R879      0.492443710565567
    z[2,3,1]  R880      -2.4261765182018280e-01
    z[2,3,1]  R881      1.0084971785545349e-01
    z[2,3,1]  R882      -8.7758040428161621e-01
    z[2,3,1]  R883      -3.5370045900344849e-01
    z[2,3,1]  R884      7.1731823682785034e-01
    z[2,3,1]  R885      5.5955308675765991e-01
    z[2,3,1]  R886      -1.5039165318012238e-01
    z[2,3,1]  R887      -2.1676853299140930e-01
    z[2,3,1]  R888      1.5709306299686432e-01
    z[2,3,1]  R889      -6.6963976621627808e-01
    z[2,3,1]  R890      -5.3933167457580566e-01
    z[2,3,1]  R891      -7.8680831193923950e-01
    z[2,3,1]  R892      -4.8667269945144653e-01
    z[2,3,1]  R893      -5.3156054019927979e-01
    z[2,3,1]  R894      6.9027435779571533e-01
    z[2,3,1]  R895      -1.5281352400779724e-01
    z[2,3,1]  R896      0.324432373046875
    z[2,3,1]  R897      4.5422129333019257e-02
    z[2,3,1]  R898      -2.6522394269704819e-02
    z[2,3,1]  R899      1.5438407659530640e-01
    z[2,3,1]  R900      -0.581614077091217
    z[2,3,1]  R901      -5.1495635509490967e-01
    z[2,3,1]  R902      -1.3446459174156189e-01
    z[2,3,1]  R903      -5.9460699558258057e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R745      -1
    z[2,3,2]  R746      1
    z[2,3,2]  R755      6.5919585525989532e-02
    z[2,3,2]  R756      1.5690113604068756e-01
    z[2,3,2]  R757      -1.3273629546165466e-01
    z[2,3,2]  R758      2.4814562499523163e-01
    z[2,3,2]  R759      -1.4085343107581139e-02
    z[2,3,2]  R760      -3.6242190003395081e-01
    z[2,3,2]  R761      -3.3191487193107605e-01
    z[2,3,2]  R762      0.0945688933134079
    z[2,3,2]  R763      2.0823976397514343e-01
    z[2,3,2]  R764      -4.9097096920013428e-01
    z[2,3,2]  R765      -1.9649036228656769e-01
    z[2,3,2]  R766      2.1629586815834045e-01
    z[2,3,2]  R767      0.693274199962616
    z[2,3,2]  R768      -2.5046586990356445e-01
    z[2,3,2]  R769      3.4714984893798828e-01
    z[2,3,2]  R770      1.4693361520767212e-01
    z[2,3,2]  R771      -2.0404672622680664e-01
    z[2,3,2]  R772      -4.6474647521972656e-01
    z[2,3,2]  R773      -4.5270577073097229e-01
    z[2,3,2]  R774      -1.9578759372234344e-01
    z[2,3,2]  R775      2.8505036234855652e-01
    z[2,3,2]  R776      -3.2137352973222733e-02
    z[2,3,2]  R777      1.6045522689819336e-01
    z[2,3,2]  R778      -2.9685732722282410e-01
    z[2,3,2]  R779      -3.7420034408569336e-01
    z[2,3,2]  R780      -2.1563017368316650e-01
    z[2,3,2]  R781      3.0412617325782776e-01
    z[2,3,2]  R782      4.7782737016677856e-01
    z[2,3,2]  R783      -1.0993339121341705e-01
    z[2,3,2]  R784      4.3414631485939026e-01
    z[2,3,2]  R785      -6.0789614915847778e-01
    z[2,3,2]  R786      -4.0976539254188538e-01
    z[2,3,2]  R787      -2.6562992483377457e-02
    z[2,3,2]  R788      -2.7773827314376831e-01
    z[2,3,2]  R789      1.0486693121492863e-02
    z[2,3,2]  R790      -9.5970399677753448e-02
    z[2,3,2]  R791      1.6788119077682495e-01
    z[2,3,2]  R792      -7.4469313025474548e-02
    z[2,3,2]  R793      3.2411456108093262e-01
    z[2,3,2]  R794      1.6742104291915894e-01
    z[2,3,2]  R795      -3.0482724308967590e-01
    z[2,3,2]  R796      1.1141819506883621e-01
    z[2,3,2]  R797      -5.6936436891555786e-01
    z[2,3,2]  R798      1.6606016457080841e-01
    z[2,3,2]  R799      -1.3456906378269196e-01
    z[2,3,2]  R800      -1.5954619273543358e-02
    z[2,3,2]  R801      9.6836470067501068e-02
    z[2,3,2]  R802      5.0356034189462662e-02
    z[2,3,2]  R803      2.9992294311523438e-01
    z[2,3,2]  R804      0.388574481010437
    z[2,3,2]  R805      2.4980668723583221e-01
    z[2,3,2]  R806      6.0219585895538330e-01
    z[2,3,2]  R807      3.8829341530799866e-01
    z[2,3,2]  R808      1.6707780957221985e-01
    z[2,3,2]  R809      4.4926857948303223e-01
    z[2,3,2]  R810      3.8597890734672546e-01
    z[2,3,2]  R811      1.4168396592140198e-01
    z[2,3,2]  R812      0.345490425825119
    z[2,3,2]  R813      5.9946954250335693e-01
    z[2,3,2]  R814      -4.6438673138618469e-01
    z[2,3,2]  R815      -0.453572154045105
    z[2,3,2]  R816      -2.5681027770042419e-01
    z[2,3,2]  R817      -6.0514993965625763e-02
    z[2,3,2]  R818      -3.0757537484169006e-01
    z[2,3,2]  R819      -1.1456935852766037e-01
    z[2,3,2]  R820      -2.6502177119255066e-01
    z[2,3,2]  R821      -3.3766967058181763e-01
    z[2,3,2]  R822      -2.5241887569427490e-01
    z[2,3,2]  R823      2.2210665047168732e-01
    z[2,3,2]  R824      -4.0944731235504150e-01
    z[2,3,2]  R825      6.3712793588638306e-01
    z[2,3,2]  R826      -6.7614391446113586e-02
    z[2,3,2]  R827      2.8389924764633179e-01
    z[2,3,2]  R828      -2.0516772568225861e-01
    z[2,3,2]  R829      -7.7193580567836761e-02
    z[2,3,2]  R830      1.2833668291568756e-01
    z[2,3,2]  R831      -4.6638140082359314e-01
    z[2,3,2]  R832      3.0287280678749084e-01
    z[2,3,2]  R833      2.8450208902359009e-01
    z[2,3,2]  R834      3.0728485435247421e-02
    z[2,3,2]  R835      1.0896039195358753e-02
    z[2,3,2]  R836      1.4771074056625366e-01
    z[2,3,2]  R837      4.6055087447166443e-01
    z[2,3,2]  R838      -4.0463727712631226e-01
    z[2,3,2]  R839      2.0238615572452545e-02
    z[2,3,2]  R840      5.5145698785781860e-01
    z[2,3,2]  R841      5.6918853521347046e-01
    z[2,3,2]  R842      -5.7994669675827026e-01
    z[2,3,2]  R843      2.2485144436359406e-01
    z[2,3,2]  R844      -2.5433886051177979e-01
    z[2,3,2]  R845      4.7333080321550369e-02
    z[2,3,2]  R846      5.2712643146514893e-01
    z[2,3,2]  R847      -3.9871567487716675e-01
    z[2,3,2]  R848      -1.4094695448875427e-01
    z[2,3,2]  R849      6.4704142510890961e-02
    z[2,3,2]  R850      -3.2439496368169785e-02
    z[2,3,2]  R851      3.1068574637174606e-02
    z[2,3,2]  R852      1.6097691655158997e-01
    z[2,3,2]  R853      2.4971139430999756e-01
    z[2,3,2]  R854      6.2799811363220215e-02
    z[2,3,2]  R855      1.2318023294210434e-01
    z[2,3,2]  R856      0.424014687538147
    z[2,3,2]  R857      0.0715944841504097
    z[2,3,2]  R858      -2.9453590512275696e-01
    z[2,3,2]  R859      7.6235704123973846e-02
    z[2,3,2]  R860      1.3002495467662811e-01
    z[2,3,2]  R861      -1.7952781915664673e-01
    z[2,3,2]  R862      -0.280814528465271
    z[2,3,2]  R863      2.7645226567983627e-02
    z[2,3,2]  R864      -1.2493391335010529e-01
    z[2,3,2]  R865      1.9838419556617737e-01
    z[2,3,2]  R866      -0.488179087638855
    z[2,3,2]  R867      -2.6554372906684875e-01
    z[2,3,2]  R868      3.6922845244407654e-01
    z[2,3,2]  R869      -0.0339483805000782
    z[2,3,2]  R870      1.3924182951450348e-01
    z[2,3,2]  R871      1.7402195930480957e-01
    z[2,3,2]  R872      -1.2328878045082092e-01
    z[2,3,2]  R873      -5.0941850990056992e-02
    z[2,3,2]  R874      4.4459328055381775e-02
    z[2,3,2]  R875      5.5610740184783936e-01
    z[2,3,2]  R876      -1.8911378085613251e-01
    z[2,3,2]  R877      -1.1785674095153809e-01
    z[2,3,2]  R878      -2.0113836228847504e-01
    z[2,3,2]  R879      -5.2802842855453491e-01
    z[2,3,2]  R880      -5.6183699518442154e-02
    z[2,3,2]  R881      3.6028262972831726e-01
    z[2,3,2]  R882      -4.0361863374710083e-01
    z[2,3,2]  R883      -6.0564011335372925e-01
    z[2,3,2]  R884      1.1743155121803284e-01
    z[2,3,2]  R885      -2.8917932510375977e-01
    z[2,3,2]  R886      -1.1606529355049133e-01
    z[2,3,2]  R887      -9.5972500275820494e-04
    z[2,3,2]  R888      -1.6278178989887238e-01
    z[2,3,2]  R889      -4.5483973622322083e-01
    z[2,3,2]  R890      -4.7846508026123047e-01
    z[2,3,2]  R891      2.9979849234223366e-02
    z[2,3,2]  R892      -4.4776901602745056e-01
    z[2,3,2]  R893      -3.7698981165885925e-01
    z[2,3,2]  R894      -4.9701115489006042e-01
    z[2,3,2]  R895      -2.9945635795593262e-01
    z[2,3,2]  R896      -2.0904821157455444e-01
    z[2,3,2]  R897      1.8929970264434814e-01
    z[2,3,2]  R898      1.1313340812921524e-01
    z[2,3,2]  R899      -1.4072303473949432e-01
    z[2,3,2]  R900      -2.4279899895191193e-01
    z[2,3,2]  R901      -5.3732901811599731e-01
    z[2,3,2]  R902      -0.518753707408905
    z[2,3,2]  R903      -6.6158592700958252e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R747      -1
    z[2,3,3]  R748      1
    z[2,3,3]  R755      -9.0902382135391235e-01
    z[2,3,3]  R756      -7.4488759040832520e-01
    z[2,3,3]  R757      -7.3872792720794678e-01
    z[2,3,3]  R758      -7.1963566541671753e-01
    z[2,3,3]  R759      -8.4947013854980469e-01
    z[2,3,3]  R760      -6.7806845903396606e-01
    z[2,3,3]  R761      6.8751536309719086e-02
    z[2,3,3]  R762      -4.6488042920827866e-02
    z[2,3,3]  R763      -2.6350151747465134e-02
    z[2,3,3]  R764      -1.4525451697409153e-02
    z[2,3,3]  R765      2.5759249925613403e-01
    z[2,3,3]  R766      -5.7335708290338516e-02
    z[2,3,3]  R767      -2.7631255984306335e-01
    z[2,3,3]  R768      2.0623576641082764e-01
    z[2,3,3]  R769      4.7101509571075439e-01
    z[2,3,3]  R770      4.3801674246788025e-01
    z[2,3,3]  R771      1.6934689879417419e-01
    z[2,3,3]  R772      3.1265792250633240e-01
    z[2,3,3]  R773      1.8767033517360687e-01
    z[2,3,3]  R774      -1.3730492442846298e-02
    z[2,3,3]  R775      4.7327306866645813e-01
    z[2,3,3]  R776      3.6038488149642944e-01
    z[2,3,3]  R777      3.5026934742927551e-01
    z[2,3,3]  R778      -3.5700049996376038e-01
    z[2,3,3]  R779      4.5172271132469177e-01
    z[2,3,3]  R780      6.7419892549514771e-01
    z[2,3,3]  R781      5.0025576353073120e-01
    z[2,3,3]  R782      8.1911824643611908e-02
    z[2,3,3]  R783      4.2093262076377869e-02
    z[2,3,3]  R784      -2.3202177882194519e-01
    z[2,3,3]  R785      -2.6309096813201904e-01
    z[2,3,3]  R786      -3.6003756523132324e-01
    z[2,3,3]  R787      -5.2444475889205933e-01
    z[2,3,3]  R788      -4.5565196871757507e-01
    z[2,3,3]  R789      -5.5628603696823120e-01
    z[2,3,3]  R790      6.5259546041488647e-01
    z[2,3,3]  R791      5.7947164773941040e-01
    z[2,3,3]  R792      4.9359327554702759e-01
    z[2,3,3]  R793      -6.3951924443244934e-02
    z[2,3,3]  R794      -0.901881217956543
    z[2,3,3]  R795      -2.7289089560508728e-01
    z[2,3,3]  R796      -1.7915260791778564e-01
    z[2,3,3]  R797      -6.3319075107574463e-01
    z[2,3,3]  R798      9.9597439169883728e-02
    z[2,3,3]  R799      0.581642210483551
    z[2,3,3]  R800      3.8312000036239624e-01
    z[2,3,3]  R801      3.3111450076103210e-01
    z[2,3,3]  R802      -4.5543190091848373e-02
    z[2,3,3]  R803      2.4427708983421326e-01
    z[2,3,3]  R804      -2.1983437240123749e-01
    z[2,3,3]  R805      -3.3784502744674683e-01
    z[2,3,3]  R806      -2.1890088915824890e-01
    z[2,3,3]  R807      1.0547752678394318e-01
    z[2,3,3]  R808      3.8617804646492004e-02
    z[2,3,3]  R809      -2.0519154146313667e-02
    z[2,3,3]  R810      3.8928262889385223e-02
    z[2,3,3]  R811      -3.7719801068305969e-01
    z[2,3,3]  R812      -2.8920945525169373e-01
    z[2,3,3]  R813      -2.4688212573528290e-01
    z[2,3,3]  R814      2.2081515192985535e-01
    z[2,3,3]  R815      5.5929505825042725e-01
    z[2,3,3]  R816      2.4585790932178497e-01
    z[2,3,3]  R817      6.1227369308471680e-01
    z[2,3,3]  R818      -8.4651607275009155e-01
    z[2,3,3]  R819      3.4073927998542786e-01
    z[2,3,3]  R820      6.9690680503845215e-01
    z[2,3,3]  R821      -5.2825736999511719e-01
    z[2,3,3]  R822      -4.5570856332778931e-01
    z[2,3,3]  R823      1.1839376389980316e-01
    z[2,3,3]  R824      8.2410866022109985e-01
    z[2,3,3]  R825      3.8797068595886230e-01
    z[2,3,3]  R826      2.3541538417339325e-01
    z[2,3,3]  R827      3.8441452383995056e-01
    z[2,3,3]  R828      1.0509452782571316e-02
    z[2,3,3]  R829      -1.1293182522058487e-01
    z[2,3,3]  R830      2.7240052819252014e-01
    z[2,3,3]  R831      -2.9375419020652771e-01
    z[2,3,3]  R832      -4.5824725180864334e-02
    z[2,3,3]  R833      1.9795901607722044e-03
    z[2,3,3]  R834      6.7289197444915771e-01
    z[2,3,3]  R835      6.0950154066085815e-01
    z[2,3,3]  R836      4.7397544980049133e-01
    z[2,3,3]  R837      4.8006868362426758e-01
    z[2,3,3]  R838      2.0311798900365829e-02
    z[2,3,3]  R839      -4.1097089648246765e-01
    z[2,3,3]  R840      4.3353244662284851e-01
    z[2,3,3]  R841      3.1306838989257812e-01
    z[2,3,3]  R842      -3.0565026402473450e-01
    z[2,3,3]  R843      2.4861592054367065e-01
    z[2,3,3]  R844      8.8877469301223755e-02
    z[2,3,3]  R845      -1.5399585664272308e-01
    z[2,3,3]  R846      4.1052162647247314e-01
    z[2,3,3]  R847      -2.8152248263359070e-01
    z[2,3,3]  R848      7.5641043484210968e-02
    z[2,3,3]  R849      -9.4083890318870544e-02
    z[2,3,3]  R850      3.7302400916814804e-02
    z[2,3,3]  R851      -6.9526262581348419e-02
    z[2,3,3]  R852      -3.0936279892921448e-01
    z[2,3,3]  R853      5.2418440580368042e-02
    z[2,3,3]  R854      3.3702442049980164e-01
    z[2,3,3]  R855      5.6980293989181519e-01
    z[2,3,3]  R856      4.3843919038772583e-01
    z[2,3,3]  R857      -3.5689270496368408e-01
    z[2,3,3]  R858      -2.8074812889099121e-01
    z[2,3,3]  R859      3.2118624448776245e-01
    z[2,3,3]  R860      -3.9957201480865479e-01
    z[2,3,3]  R861      2.8057834506034851e-01
    z[2,3,3]  R862      -0.649041473865509
    z[2,3,3]  R863      -9.9989846348762512e-02
    z[2,3,3]  R864      1.8089847872033715e-03
    z[2,3,3]  R865      8.7370024994015694e-04
    z[2,3,3]  R866      -3.8883021473884583e-01
    z[2,3,3]  R867      -6.4202928543090820e-01
    z[2,3,3]  R868      2.5093883275985718e-01
    z[2,3,3]  R869      1.7347642779350281e-01
    z[2,3,3]  R870      -1.0311586409807205e-01
    z[2,3,3]  R871      -1.5421982109546661e-01
    z[2,3,3]  R872      -4.7485277056694031e-01
    z[2,3,3]  R873      -3.8497611880302429e-01
    z[2,3,3]  R874      -3.3683210611343384e-01
    z[2,3,3]  R875      3.6364433169364929e-01
    z[2,3,3]  R876      2.2673273086547852e-01
    z[2,3,3]  R877      0.277258962392807
    z[2,3,3]  R878      -5.7367360591888428e-01
    z[2,3,3]  R879      8.6202420294284821e-02
    z[2,3,3]  R880      -3.1494984030723572e-01
    z[2,3,3]  R881      -1.5366628766059875e-01
    z[2,3,3]  R882      -1.6533143818378448e-01
    z[2,3,3]  R883      2.4333539605140686e-01
    z[2,3,3]  R884      -4.1196337342262268e-01
    z[2,3,3]  R885      5.6809765100479126e-01
    z[2,3,3]  R886      -3.2596006989479065e-02
    z[2,3,3]  R887      -2.0463606715202332e-01
    z[2,3,3]  R888      -2.2062188386917114e-01
    z[2,3,3]  R889      -4.1860058903694153e-01
    z[2,3,3]  R890      -4.4509038329124451e-02
    z[2,3,3]  R891      -3.3235767483711243e-01
    z[2,3,3]  R892      -2.3991049826145172e-01
    z[2,3,3]  R893      -3.9578244090080261e-01
    z[2,3,3]  R894      -1.1740065366029739e-01
    z[2,3,3]  R895      4.9503996968269348e-01
    z[2,3,3]  R896      -5.5340075492858887e-01
    z[2,3,3]  R897      -3.4102407097816467e-01
    z[2,3,3]  R898      1.7385666072368622e-01
    z[2,3,3]  R899      -2.4025362730026245e-01
    z[2,3,3]  R900      -3.6551502346992493e-01
    z[2,3,3]  R901      1.0349040478467941e-01
    z[2,3,3]  R902      -1.5072527341544628e-02
    z[2,3,3]  R903      1.3338880613446236e-02
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R749      -1
    z[2,3,4]  R750      1
    z[2,3,4]  R755      -6.6306792199611664e-02
    z[2,3,4]  R756      4.3965074419975281e-01
    z[2,3,4]  R757      4.4334211945533752e-01
    z[2,3,4]  R758      1.6884812712669373e-01
    z[2,3,4]  R759      -3.4588897228240967e-01
    z[2,3,4]  R760      -3.7867131829261780e-01
    z[2,3,4]  R761      7.8314365819096565e-03
    z[2,3,4]  R762      4.1429454088211060e-01
    z[2,3,4]  R763      -1.2736883759498596e-01
    z[2,3,4]  R764      1.5730260312557220e-01
    z[2,3,4]  R765      2.1937662363052368e-01
    z[2,3,4]  R766      1.5066680312156677e-01
    z[2,3,4]  R767      1.6973850131034851e-01
    z[2,3,4]  R768      1.2679381668567657e-01
    z[2,3,4]  R769      -1.1155434697866440e-01
    z[2,3,4]  R770      1.6030846536159515e-01
    z[2,3,4]  R771      -5.6932407617568970e-01
    z[2,3,4]  R772      2.9742112755775452e-01
    z[2,3,4]  R773      -1.7082078754901886e-01
    z[2,3,4]  R774      -1.8431127071380615e-01
    z[2,3,4]  R775      2.8770866990089417e-01
    z[2,3,4]  R776      -1.8145841360092163e-01
    z[2,3,4]  R777      -2.6810136437416077e-01
    z[2,3,4]  R778      1.8248723447322845e-01
    z[2,3,4]  R779      -3.3276686072349548e-01
    z[2,3,4]  R780      0.265112966299057
    z[2,3,4]  R781      -2.2561891376972198e-01
    z[2,3,4]  R782      -5.3866151720285416e-02
    z[2,3,4]  R783      5.6937980651855469e-01
    z[2,3,4]  R784      -2.1870298683643341e-01
    z[2,3,4]  R785      2.0903086662292480e-01
    z[2,3,4]  R786      -4.2719554901123047e-01
    z[2,3,4]  R787      2.5150260329246521e-01
    z[2,3,4]  R788      5.7169649749994278e-02
    z[2,3,4]  R789      3.5505077242851257e-01
    z[2,3,4]  R790      1.1017717421054840e-01
    z[2,3,4]  R791      -3.7148892879486084e-01
    z[2,3,4]  R792      -4.1202649474143982e-02
    z[2,3,4]  R793      -1.1888147145509720e-01
    z[2,3,4]  R794      7.6279595494270325e-02
    z[2,3,4]  R795      6.9572590291500092e-02
    z[2,3,4]  R796      2.4538795650005341e-01
    z[2,3,4]  R797      -3.0108207464218140e-01
    z[2,3,4]  R798      1.8064978718757629e-01
    z[2,3,4]  R799      1.0405606776475906e-01
    z[2,3,4]  R800      1.2176611274480820e-01
    z[2,3,4]  R801      -3.5840880870819092e-01
    z[2,3,4]  R802      -4.9609247595071793e-02
    z[2,3,4]  R803      -3.0643252655863762e-02
    z[2,3,4]  R804      3.6975425481796265e-01
    z[2,3,4]  R805      0.0836007222533226
    z[2,3,4]  R806      2.7925944328308105e-01
    z[2,3,4]  R807      1.6411504149436951e-01
    z[2,3,4]  R808      -1.3834075629711151e-01
    z[2,3,4]  R809      9.8664209246635437e-02
    z[2,3,4]  R810      -1.6533695161342621e-01
    z[2,3,4]  R811      -2.0861823856830597e-01
    z[2,3,4]  R812      -2.3871515691280365e-01
    z[2,3,4]  R813      -6.3319101929664612e-02
    z[2,3,4]  R814      4.0838193893432617e-01
    z[2,3,4]  R815      -1.8973509967327118e-01
    z[2,3,4]  R816      3.4369704127311707e-01
    z[2,3,4]  R817      -1.2840871512889862e-01
    z[2,3,4]  R818      2.6399930939078331e-02
    z[2,3,4]  R819      -2.5398489832878113e-01
    z[2,3,4]  R820      -1.4980722218751907e-02
    z[2,3,4]  R821      2.6581141352653503e-01
    z[2,3,4]  R822      -5.2717506885528564e-01
    z[2,3,4]  R823      -2.4696613848209381e-01
    z[2,3,4]  R824      -2.6409873366355896e-01
    z[2,3,4]  R825      -2.9159709811210632e-01
    z[2,3,4]  R826      -4.9763542413711548e-01
    z[2,3,4]  R827      -2.1162109076976776e-01
    z[2,3,4]  R828      -3.0046626925468445e-01
    z[2,3,4]  R829      -1.0412283986806870e-01
    z[2,3,4]  R830      1.2374614179134369e-01
    z[2,3,4]  R831      -5.5735909938812256e-01
    z[2,3,4]  R832      -2.5431391596794128e-01
    z[2,3,4]  R833      2.7516716718673706e-01
    z[2,3,4]  R834      1.2355333566665649e-01
    z[2,3,4]  R835      -3.3346304297447205e-01
    z[2,3,4]  R836      -0.394437313079834
    z[2,3,4]  R837      -2.4966441094875336e-01
    z[2,3,4]  R838      3.9922407269477844e-01
    z[2,3,4]  R839      4.2915868759155273e-01
    z[2,3,4]  R840      1.0579667240381241e-01
    z[2,3,4]  R841      -0.181906595826149
    z[2,3,4]  R842      -7.3114745318889618e-02
    z[2,3,4]  R843      -1.4692904055118561e-01
    z[2,3,4]  R844      -4.5659685134887695e-01
    z[2,3,4]  R845      1.6165295243263245e-01
    z[2,3,4]  R846      -1.6063414514064789e-01
    z[2,3,4]  R847      -4.8005864024162292e-01
    z[2,3,4]  R848      3.8883373141288757e-02
    z[2,3,4]  R849      1.1996621638536453e-01
    z[2,3,4]  R850      3.7625020742416382e-01
    z[2,3,4]  R851      3.4751359373331070e-02
    z[2,3,4]  R852      4.7478446364402771e-01
    z[2,3,4]  R853      -1.5053851902484894e-01
    z[2,3,4]  R854      -2.2645914554595947e-01
    z[2,3,4]  R855      -5.7060797698795795e-03
    z[2,3,4]  R856      -7.6822616159915924e-02
    z[2,3,4]  R857      2.1029409021139145e-02
    z[2,3,4]  R858      1.8492749333381653e-01
    z[2,3,4]  R859      -1.1500279605388641e-01
    z[2,3,4]  R860      6.0783304274082184e-02
    z[2,3,4]  R861      7.0928357541561127e-02
    z[2,3,4]  R862      -0.42122882604599
    z[2,3,4]  R863      1.3787874579429626e-01
    z[2,3,4]  R864      2.6096263527870178e-01
    z[2,3,4]  R865      -0.16848124563694
    z[2,3,4]  R866      3.8658101111650467e-02
    z[2,3,4]  R867      -4.1916516423225403e-01
    z[2,3,4]  R868      4.3393567204475403e-01
    z[2,3,4]  R869      2.7704099193215370e-02
    z[2,3,4]  R870      3.0394849181175232e-01
    z[2,3,4]  R871      -2.5828543305397034e-01
    z[2,3,4]  R872      3.7149384617805481e-01
    z[2,3,4]  R873      4.7176092863082886e-02
    z[2,3,4]  R874      -2.7131193876266479e-01
    z[2,3,4]  R875      -2.9805478453636169e-01
    z[2,3,4]  R876      -6.0237679630517960e-02
    z[2,3,4]  R877      -6.2752211093902588e-01
    z[2,3,4]  R878      1.4327786862850189e-01
    z[2,3,4]  R879      -4.9175915122032166e-01
    z[2,3,4]  R880      -9.4972558319568634e-02
    z[2,3,4]  R881      9.8763778805732727e-02
    z[2,3,4]  R882      -1.2358006834983826e-01
    z[2,3,4]  R883      8.0499485135078430e-02
    z[2,3,4]  R884      2.8234642744064331e-01
    z[2,3,4]  R885      9.6305571496486664e-02
    z[2,3,4]  R886      -7.1907705068588257e-01
    z[2,3,4]  R887      -1.6345153562724590e-03
    z[2,3,4]  R888      -2.5797012448310852e-01
    z[2,3,4]  R889      -1.1582937091588974e-01
    z[2,3,4]  R890      2.3507069051265717e-01
    z[2,3,4]  R891      -1.5902440249919891e-01
    z[2,3,4]  R892      -1.6797071322798729e-02
    z[2,3,4]  R893      1.1166515201330185e-01
    z[2,3,4]  R894      -2.2787198424339294e-01
    z[2,3,4]  R895      -1.4868468046188354e-01
    z[2,3,4]  R896      -3.1543251127004623e-02
    z[2,3,4]  R897      4.9308642745018005e-02
    z[2,3,4]  R898      3.4621319174766541e-01
    z[2,3,4]  R899      -2.5849640369415283e-01
    z[2,3,4]  R900      2.3924781382083893e-01
    z[2,3,4]  R901      1.4420378953218460e-02
    z[2,3,4]  R902      -0.0878065750002861
    z[2,3,4]  R903      4.0671084076166153e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R751      -1
    z[2,3,5]  R752      1
    z[2,3,5]  R755      -2.3398378491401672e-01
    z[2,3,5]  R756      -4.6752616763114929e-02
    z[2,3,5]  R757      1.3514953851699829e-01
    z[2,3,5]  R758      0.46548992395401
    z[2,3,5]  R759      0.344230055809021
    z[2,3,5]  R760      5.0049668550491333e-01
    z[2,3,5]  R761      -3.2925210893154144e-02
    z[2,3,5]  R762      -1.1988820135593414e-01
    z[2,3,5]  R763      2.9034256935119629e-01
    z[2,3,5]  R764      5.4852332919836044e-02
    z[2,3,5]  R765      3.2863688468933105e-01
    z[2,3,5]  R766      -6.5464353561401367e-01
    z[2,3,5]  R767      -3.5209223628044128e-01
    z[2,3,5]  R768      -3.9660032838582993e-02
    z[2,3,5]  R769      3.9664039015769958e-01
    z[2,3,5]  R770      -2.3206442594528198e-01
    z[2,3,5]  R771      -1.0509885102510452e-01
    z[2,3,5]  R772      -3.5911419987678528e-01
    z[2,3,5]  R773      -1.9423596560955048e-01
    z[2,3,5]  R774      -2.9846975207328796e-01
    z[2,3,5]  R775      -1.5160897374153137e-01
    z[2,3,5]  R776      8.6666487157344818e-02
    z[2,3,5]  R777      -1.0509578138589859e-01
    z[2,3,5]  R778      -9.1551892459392548e-02
    z[2,3,5]  R779      4.1956865787506104e-01
    z[2,3,5]  R780      1.3488624989986420e-01
    z[2,3,5]  R781      -4.5855108648538589e-02
    z[2,3,5]  R782      -1.9494697451591492e-01
    z[2,3,5]  R783      3.9313459396362305e-01
    z[2,3,5]  R784      2.2306744754314423e-01
    z[2,3,5]  R785      -3.1990390270948410e-02
    z[2,3,5]  R786      4.2567834258079529e-02
    z[2,3,5]  R787      5.0508803129196167e-01
    z[2,3,5]  R788      2.3285277187824249e-01
    z[2,3,5]  R789      -2.5751617550849915e-01
    z[2,3,5]  R790      -1.4964435994625092e-01
    z[2,3,5]  R791      1.2595626711845398e-01
    z[2,3,5]  R792      1.0267663002014160e-01
    z[2,3,5]  R793      -4.0106363594532013e-02
    z[2,3,5]  R794      2.9455076903104782e-02
    z[2,3,5]  R795      3.7211453914642334e-01
    z[2,3,5]  R796      -5.3069853782653809e-01
    z[2,3,5]  R797      -2.3428719490766525e-02
    z[2,3,5]  R798      -1.6490390896797180e-01
    z[2,3,5]  R799      2.6599767804145813e-01
    z[2,3,5]  R800      4.1694071888923645e-01
    z[2,3,5]  R801      -3.0218055844306946e-01
    z[2,3,5]  R802      -1.9956310093402863e-01
    z[2,3,5]  R803      -4.7557353973388672e-01
    z[2,3,5]  R804      3.3980527520179749e-01
    z[2,3,5]  R805      0.486115425825119
    z[2,3,5]  R806      9.7025007009506226e-02
    z[2,3,5]  R807      2.9867282509803772e-01
    z[2,3,5]  R808      4.1259261965751648e-01
    z[2,3,5]  R809      4.1188114881515503e-01
    z[2,3,5]  R810      -0.074520044028759
    z[2,3,5]  R811      -1.9655311107635498e-01
    z[2,3,5]  R812      -2.0525650680065155e-01
    z[2,3,5]  R813      0.0744505226612091
    z[2,3,5]  R814      -9.6932850778102875e-02
    z[2,3,5]  R815      -6.0361623764038086e-01
    z[2,3,5]  R816      2.6354864239692688e-01
    z[2,3,5]  R817      2.4786043167114258e-01
    z[2,3,5]  R818      1.6977612674236298e-01
    z[2,3,5]  R819      -9.4695478677749634e-02
    z[2,3,5]  R820      -2.2654792666435242e-01
    z[2,3,5]  R821      -2.9492089152336121e-01
    z[2,3,5]  R822      3.2390865683555603e-01
    z[2,3,5]  R823      -8.4928011894226074e-01
    z[2,3,5]  R824      -1.0813717544078827e-01
    z[2,3,5]  R825      -2.7280244231224060e-01
    z[2,3,5]  R826      -4.6663495898246765e-01
    z[2,3,5]  R827      -5.3795474767684937e-01
    z[2,3,5]  R828      -1.1047238111495972e-01
    z[2,3,5]  R829      1.4906586706638336e-01
    z[2,3,5]  R830      -7.2340106964111328e-01
    z[2,3,5]  R831      0.17389015853405
    z[2,3,5]  R832      1.3917692005634308e-01
    z[2,3,5]  R833      -2.3230737075209618e-02
    z[2,3,5]  R834      -7.0192688703536987e-01
    z[2,3,5]  R835      -3.6358866095542908e-01
    z[2,3,5]  R836      -5.8569401502609253e-01
    z[2,3,5]  R837      -4.0828722715377808e-01
    z[2,3,5]  R838      3.3582428097724915e-01
    z[2,3,5]  R839      1.7942123115062714e-01
    z[2,3,5]  R840      -4.3635964393615723e-01
    z[2,3,5]  R841      -4.8830467462539673e-01
    z[2,3,5]  R842      -1.7145806550979614e-01
    z[2,3,5]  R843      -4.1066142916679382e-01
    z[2,3,5]  R844      6.2644377350807190e-02
    z[2,3,5]  R845      -1.7560601234436035e-01
    z[2,3,5]  R846      -0.392000675201416
    z[2,3,5]  R847      1.3934718072414398e-01
    z[2,3,5]  R848      -3.3349204063415527e-01
    z[2,3,5]  R849      -1.2825973331928253e-01
    z[2,3,5]  R850      4.3615409731864929e-01
    z[2,3,5]  R851      2.9254710674285889e-01
    z[2,3,5]  R852      -0.0223592147231102
    z[2,3,5]  R853      1.2361817806959152e-01
    z[2,3,5]  R854      4.9798870086669922e-01
    z[2,3,5]  R855      -0.242364302277565
    z[2,3,5]  R856      -6.2602925300598145e-01
    z[2,3,5]  R857      1.8952375650405884e-01
    z[2,3,5]  R858      -5.4515582323074341e-01
    z[2,3,5]  R859      -3.3561038970947266e-01
    z[2,3,5]  R860      1.5446986258029938e-01
    z[2,3,5]  R861      2.5392949581146240e-01
    z[2,3,5]  R862      -3.6997672915458679e-01
    z[2,3,5]  R863      5.0624340772628784e-01
    z[2,3,5]  R864      4.5626637339591980e-01
    z[2,3,5]  R865      4.2337018251419067e-01
    z[2,3,5]  R866      -3.2346537709236145e-01
    z[2,3,5]  R867      -3.3001348376274109e-01
    z[2,3,5]  R868      -1.9071669876575470e-01
    z[2,3,5]  R869      -2.1720662713050842e-02
    z[2,3,5]  R870      1.8512552604079247e-02
    z[2,3,5]  R871      2.5458592176437378e-01
    z[2,3,5]  R872      3.2484656572341919e-01
    z[2,3,5]  R873      9.8366884049028158e-04
    z[2,3,5]  R874      3.3701050281524658e-01
    z[2,3,5]  R875      -3.8555371761322021e-01
    z[2,3,5]  R876      -5.9404969215393066e-01
    z[2,3,5]  R877      -4.4391539692878723e-01
    z[2,3,5]  R878      -4.4910570979118347e-01
    z[2,3,5]  R879      -1.1908382177352905e-01
    z[2,3,5]  R880      -3.5017880797386169e-01
    z[2,3,5]  R881      -3.3454936742782593e-01
    z[2,3,5]  R882      -1.4463682472705841e-01
    z[2,3,5]  R883      3.1754285097122192e-01
    z[2,3,5]  R884      -1.9783751666545868e-01
    z[2,3,5]  R885      -3.1333526968955994e-01
    z[2,3,5]  R886      -6.5661799907684326e-01
    z[2,3,5]  R887      -0.303000271320343
    z[2,3,5]  R888      3.2724419236183167e-01
    z[2,3,5]  R889      1.0442462563514709e-01
    z[2,3,5]  R890      5.4920810461044312e-01
    z[2,3,5]  R891      3.1957671046257019e-01
    z[2,3,5]  R892      6.4711350202560425e-01
    z[2,3,5]  R893      1.8048487603664398e-01
    z[2,3,5]  R894      -3.1513166427612305e-01
    z[2,3,5]  R895      -6.5260219573974609e-01
    z[2,3,5]  R896      -1.8633204698562622e-01
    z[2,3,5]  R897      -1.1351475864648819e-01
    z[2,3,5]  R898      -2.0502893626689911e-01
    z[2,3,5]  R899      2.9521077871322632e-01
    z[2,3,5]  R900      3.3200421929359436e-01
    z[2,3,5]  R901      0.461311936378479
    z[2,3,5]  R902      6.2382197380065918e-01
    z[2,3,5]  R903      4.1954675316810608e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R753      -1
    z[2,3,6]  R754      1
    z[2,3,6]  R755      -3.1044816970825195e-01
    z[2,3,6]  R756      -3.2080981135368347e-01
    z[2,3,6]  R757      -2.1905763447284698e-01
    z[2,3,6]  R758      7.9345032572746277e-02
    z[2,3,6]  R759      9.0372875332832336e-02
    z[2,3,6]  R760      -1.0624471306800842e-01
    z[2,3,6]  R761      -7.1111850440502167e-02
    z[2,3,6]  R762      -1.3775345683097839e-01
    z[2,3,6]  R763      -3.3822375535964966e-01
    z[2,3,6]  R764      2.3188921809196472e-01
    z[2,3,6]  R765      -2.0261134207248688e-01
    z[2,3,6]  R766      0.531879723072052
    z[2,3,6]  R767      3.3505034446716309e-01
    z[2,3,6]  R768      4.0646219253540039e-01
    z[2,3,6]  R769      -1.4600698649883270e-01
    z[2,3,6]  R770      -2.6989373564720154e-01
    z[2,3,6]  R771      -4.0338656306266785e-01
    z[2,3,6]  R772      -3.4699743986129761e-01
    z[2,3,6]  R773      -5.8023977279663086e-01
    z[2,3,6]  R774      -2.7896949648857117e-01
    z[2,3,6]  R775      2.6502072811126709e-02
    z[2,3,6]  R776      -5.0369039177894592e-02
    z[2,3,6]  R777      5.6097096204757690e-01
    z[2,3,6]  R778      8.5996669530868530e-01
    z[2,3,6]  R779      2.4351125955581665e-01
    z[2,3,6]  R780      1.1492806673049927e-01
    z[2,3,6]  R781      2.9832544922828674e-01
    z[2,3,6]  R782      -1.0901782661676407e-01
    z[2,3,6]  R783      2.0039934664964676e-02
    z[2,3,6]  R784      6.2712259590625763e-02
    z[2,3,6]  R785      2.9676163196563721e-01
    z[2,3,6]  R786      -4.8904288560152054e-02
    z[2,3,6]  R787      -4.3316057324409485e-01
    z[2,3,6]  R788      7.7260947227478027e-01
    z[2,3,6]  R789      3.7654605507850647e-01
    z[2,3,6]  R790      -8.4765374660491943e-02
    z[2,3,6]  R791      -7.4907653033733368e-03
    z[2,3,6]  R792      4.4425830245018005e-01
    z[2,3,6]  R793      1.0980103164911270e-01
    z[2,3,6]  R794      -0.080394446849823
    z[2,3,6]  R795      -2.1295015513896942e-01
    z[2,3,6]  R796      -3.3506935834884644e-01
    z[2,3,6]  R797      3.4158456325531006e-01
    z[2,3,6]  R798      -9.6297636628150940e-02
    z[2,3,6]  R799      -1.9954350590705872e-01
    z[2,3,6]  R800      2.0679706335067749e-01
    z[2,3,6]  R801      -1.9330868124961853e-01
    z[2,3,6]  R802      5.5426204204559326e-01
    z[2,3,6]  R803      3.5914307832717896e-01
    z[2,3,6]  R804      -1.1921192705631256e-01
    z[2,3,6]  R805      -1.0565267503261566e-01
    z[2,3,6]  R806      -1.8575143814086914e-01
    z[2,3,6]  R807      -1.1226785928010941e-01
    z[2,3,6]  R808      -2.7282893657684326e-01
    z[2,3,6]  R809      -3.4772503376007080e-01
    z[2,3,6]  R810      -1.6278398036956787e-01
    z[2,3,6]  R811      -3.4013012051582336e-01
    z[2,3,6]  R812      -2.7045345306396484e-01
    z[2,3,6]  R813      2.0042194426059723e-01
    z[2,3,6]  R814      -2.1347667276859283e-01
    z[2,3,6]  R815      7.5314551591873169e-02
    z[2,3,6]  R816      4.8321974277496338e-01
    z[2,3,6]  R817      2.0423837006092072e-01
    z[2,3,6]  R818      -2.2396599873900414e-02
    z[2,3,6]  R819      6.8618965148925781e-01
    z[2,3,6]  R820      3.4243202209472656e-01
    z[2,3,6]  R821      -1.0500402003526688e-01
    z[2,3,6]  R822      1.4225970208644867e-01
    z[2,3,6]  R823      -8.8078305125236511e-02
    z[2,3,6]  R824      1.0345313698053360e-01
    z[2,3,6]  R825      -6.8595241755247116e-03
    z[2,3,6]  R826      -4.4258746504783630e-01
    z[2,3,6]  R827      -2.6830476522445679e-01
    z[2,3,6]  R828      6.9326788187026978e-02
    z[2,3,6]  R829      -3.4348601102828979e-01
    z[2,3,6]  R830      0.0750337466597557
    z[2,3,6]  R831      0.390138179063797
    z[2,3,6]  R832      1.6677644848823547e-01
    z[2,3,6]  R833      7.4481196701526642e-02
    z[2,3,6]  R834      -1.8555977940559387e-01
    z[2,3,6]  R835      1.0878256708383560e-01
    z[2,3,6]  R836      2.2727511823177338e-02
    z[2,3,6]  R837      -1.7764264345169067e-01
    z[2,3,6]  R838      3.2427048683166504e-01
    z[2,3,6]  R839      3.8796347379684448e-01
    z[2,3,6]  R840      2.9086786508560181e-01
    z[2,3,6]  R841      5.3685763850808144e-03
    z[2,3,6]  R842      4.7650119662284851e-01
    z[2,3,6]  R843      1.9865010678768158e-01
    z[2,3,6]  R844      8.7767750024795532e-02
    z[2,3,6]  R845      7.5500112771987915e-01
    z[2,3,6]  R846      -2.2788988426327705e-02
    z[2,3,6]  R847      -5.5582004785537720e-01
    z[2,3,6]  R848      -3.8580577820539474e-02
    z[2,3,6]  R849      -1.2512862682342529e-01
    z[2,3,6]  R850      1.8459033966064453e-01
    z[2,3,6]  R851      1.6274780035018921e-01
    z[2,3,6]  R852      1.2327576428651810e-01
    z[2,3,6]  R853      -1.0316102951765060e-01
    z[2,3,6]  R854      1.7142336070537567e-01
    z[2,3,6]  R855      -1.6085078939795494e-02
    z[2,3,6]  R856      -4.6470880508422852e-02
    z[2,3,6]  R857      1.5468142926692963e-02
    z[2,3,6]  R858      1.5896968543529510e-01
    z[2,3,6]  R859      5.0948962569236755e-02
    z[2,3,6]  R860      8.9596778154373169e-02
    z[2,3,6]  R861      1.1430647969245911e-01
    z[2,3,6]  R862      2.1785560250282288e-01
    z[2,3,6]  R863      1.8165364861488342e-01
    z[2,3,6]  R864      2.8705176711082458e-01
    z[2,3,6]  R865      -1.0856804251670837e-01
    z[2,3,6]  R866      -1.2562349438667297e-01
    z[2,3,6]  R867      2.7592003345489502e-02
    z[2,3,6]  R868      -0.145661860704422
    z[2,3,6]  R869      2.5001093745231628e-01
    z[2,3,6]  R870      -1.5254151821136475e-01
    z[2,3,6]  R871      -0.0850839912891388
    z[2,3,6]  R872      -0.560992419719696
    z[2,3,6]  R873      2.0289690792560577e-01
    z[2,3,6]  R874      2.9001367092132568e-01
    z[2,3,6]  R875      5.1871906965970993e-02
    z[2,3,6]  R876      4.8334410786628723e-01
    z[2,3,6]  R877      -5.3901600837707520e-01
    z[2,3,6]  R878      1.5751791000366211e-01
    z[2,3,6]  R879      2.2093172371387482e-01
    z[2,3,6]  R880      -8.7031356990337372e-02
    z[2,3,6]  R881      -3.7781888246536255e-01
    z[2,3,6]  R882      -5.3689569234848022e-02
    z[2,3,6]  R883      2.2673925757408142e-01
    z[2,3,6]  R884      3.9606702327728271e-01
    z[2,3,6]  R885      4.1313868761062622e-01
    z[2,3,6]  R886      -7.8150011599063873e-02
    z[2,3,6]  R887      -3.9280518889427185e-02
    z[2,3,6]  R888      1.1420807242393494e-01
    z[2,3,6]  R889      -8.6310803890228271e-02
    z[2,3,6]  R890      -1.9005009904503822e-02
    z[2,3,6]  R891      -3.6157715320587158e-01
    z[2,3,6]  R892      -2.1683798730373383e-01
    z[2,3,6]  R893      3.4990105032920837e-01
    z[2,3,6]  R894      5.6830104440450668e-02
    z[2,3,6]  R895      2.1327154338359833e-01
    z[2,3,6]  R896      -1.5577603876590729e-01
    z[2,3,6]  R897      -3.4625567495822906e-02
    z[2,3,6]  R898      -1.4220872521400452e-01
    z[2,3,6]  R899      9.6423342823982239e-02
    z[2,3,6]  R900      -1.7282311618328094e-01
    z[2,3,6]  R901      -0.378086119890213
    z[2,3,6]  R902      3.4706908464431763e-01
    z[2,3,6]  R903      1.7097742855548859e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R904      -1
    z[3,2,0]  R905      1
    z[3,2,0]  R918      7.3081964254379272e-01
    z[3,2,0]  R919      7.5236237049102783e-01
    z[3,2,0]  R920      6.4019095897674561e-01
    z[3,2,0]  R921      7.5551462173461914e-01
    z[3,2,0]  R922      7.9268425703048706e-01
    z[3,2,0]  R923      5.8187460899353027e-01
    z[3,2,0]  R924      7.8306490182876587e-01
    z[3,2,0]  R925      7.6801878213882446e-01
    z[3,2,0]  R926      -1.7464710399508476e-02
    z[3,2,0]  R927      -5.1970733329653740e-04
    z[3,2,0]  R928      -3.7451930344104767e-02
    z[3,2,0]  R929      -1.7085577547550201e-01
    z[3,2,0]  R930      -1.3820216059684753e-01
    z[3,2,0]  R931      -2.9620608687400818e-01
    z[3,2,0]  R932      -3.9036303758621216e-01
    z[3,2,0]  R933      -1.3025595247745514e-01
    z[3,2,0]  R934      -8.9698553085327148e-02
    z[3,2,0]  R935      -0.651669979095459
    z[3,2,0]  R936      -5.4056859016418457e-01
    z[3,2,0]  R937      -3.8065171241760254e-01
    z[3,2,0]  R938      6.7949414253234863e-02
    z[3,2,0]  R939      -5.3215283155441284e-01
    z[3,2,0]  R940      -3.6922167986631393e-02
    z[3,2,0]  R941      -3.3193930983543396e-01
    z[3,2,0]  R942      -9.1507446765899658e-01
    z[3,2,0]  R943      -9.1097509860992432e-01
    z[3,2,0]  R944      -3.6560615897178650e-01
    z[3,2,0]  R945      2.1802823990583420e-02
    z[3,2,0]  R946      -8.8899797201156616e-01
    z[3,2,0]  R947      -8.7273043394088745e-01
    z[3,2,0]  R948      -4.3535541743040085e-02
    z[3,2,0]  R949      6.1079227924346924e-01
    z[3,2,0]  R950      -2.8745830059051514e-01
    z[3,2,0]  R951      -6.3473924994468689e-02
    z[3,2,0]  R952      2.5515419244766235e-01
    z[3,2,0]  R953      -3.7279021739959717e-01
    z[3,2,0]  R954      -6.3946500420570374e-02
    z[3,2,0]  R955      1.7163048684597015e-01
    z[3,2,0]  R956      -3.3679354190826416e-01
    z[3,2,0]  R957      -6.0315674543380737e-01
    z[3,2,0]  R958      -4.9866211414337158e-01
    z[3,2,0]  R959      5.8716970682144165e-01
    z[3,2,0]  R960      2.4355675280094147e-01
    z[3,2,0]  R961      -9.8377957940101624e-02
    z[3,2,0]  R962      -9.1336077451705933e-01
    z[3,2,0]  R963      -2.0049074292182922e-01
    z[3,2,0]  R964      -0.793777346611023
    z[3,2,0]  R965      -1.3446946442127228e-01
    z[3,2,0]  R966      -7.6299661397933960e-01
    z[3,2,0]  R967      -2.5040575861930847e-01
    z[3,2,0]  R968      -4.8506896942853928e-02
    z[3,2,0]  R969      3.9443102478981018e-01
    z[3,2,0]  R970      -3.4812141209840775e-02
    z[3,2,0]  R971      -6.8137490749359131e-01
    z[3,2,0]  R972      -4.9739876389503479e-01
    z[3,2,0]  R973      -7.7618694305419922e-01
    z[3,2,0]  R974      -8.8468819856643677e-01
    z[3,2,0]  R975      -8.9799350500106812e-01
    z[3,2,0]  R976      -3.6623382568359375e-01
    z[3,2,0]  R977      -8.2222521305084229e-01
    z[3,2,0]  R978      -9.5417900010943413e-03
    z[3,2,0]  R979      -5.6352788209915161e-01
    z[3,2,0]  R980      -0.457535058259964
    z[3,2,0]  R981      -4.6804243326187134e-01
    z[3,2,0]  R982      -5.3360491991043091e-01
    z[3,2,0]  R983      -9.5024204254150391e-01
    z[3,2,0]  R984      -9.2259037494659424e-01
    z[3,2,0]  R985      -8.5279864072799683e-01
    z[3,2,0]  R986      -4.1459599137306213e-01
    z[3,2,0]  R987      -1.6792495548725128e-01
    z[3,2,0]  R988      -4.4118997454643250e-01
    z[3,2,0]  R989      -5.4312908649444580e-01
    z[3,2,0]  R990      -2.4107502773404121e-02
    z[3,2,0]  R991      -4.8570921644568443e-03
    z[3,2,0]  R992      -5.8970987796783447e-01
    z[3,2,0]  R993      4.0796521306037903e-01
    z[3,2,0]  R994      -8.3640134334564209e-01
    z[3,2,0]  R995      -7.5629872083663940e-01
    z[3,2,0]  R996      -2.3148091509938240e-02
    z[3,2,0]  R997      -5.3866463899612427e-01
    z[3,2,0]  R998      1.6193255782127380e-01
    z[3,2,0]  R999      4.9023322761058807e-02
    z[3,2,0]  R1000     9.2316336929798126e-02
    z[3,2,0]  R1001     -9.0431171655654907e-01
    z[3,2,0]  R1002     -8.4467101097106934e-01
    z[3,2,0]  R1003     -3.7108820676803589e-01
    z[3,2,0]  R1004     -3.4779664874076843e-01
    z[3,2,0]  R1005     -1.0684672743082047e-01
    z[3,2,0]  R1006     -1.9758220016956329e-01
    z[3,2,0]  R1007     -5.0120222568511963e-01
    z[3,2,0]  R1008     3.2902139425277710e-01
    z[3,2,0]  R1009     3.8526329398155212e-01
    z[3,2,0]  R1010     -6.9628250598907471e-01
    z[3,2,0]  R1011     -9.1065317392349243e-01
    z[3,2,0]  R1012     -8.7985646724700928e-01
    z[3,2,0]  R1013     -8.5753923654556274e-01
    z[3,2,0]  R1014     -5.2138119935989380e-01
    z[3,2,0]  R1015     -0.281818151473999
    z[3,2,0]  R1016     -4.4188895821571350e-01
    z[3,2,0]  R1017     -4.0765147656202316e-02
    z[3,2,0]  R1018     -1.0609781742095947e-01
    z[3,2,0]  R1019     -3.4289813041687012e-01
    z[3,2,0]  R1020     -4.1695043444633484e-01
    z[3,2,0]  R1021     -4.0962496399879456e-01
    z[3,2,0]  R1022     1.7386958003044128e-01
    z[3,2,0]  R1023     5.3327787667512894e-02
    z[3,2,0]  R1024     5.7834988832473755e-01
    z[3,2,0]  R1025     4.5682811737060547e-01
    z[3,2,0]  R1026     6.1966693401336670e-01
    z[3,2,0]  R1027     3.5519456863403320e-01
    z[3,2,0]  R1028     -3.2717451453208923e-01
    z[3,2,0]  R1029     1.8589578103274107e-03
    z[3,2,0]  R1030     3.5171806812286377e-01
    z[3,2,0]  R1031     -1.0059101879596710e-01
    z[3,2,0]  R1032     -2.1450848877429962e-01
    z[3,2,0]  R1033     4.8710286617279053e-01
    z[3,2,0]  R1034     2.6665395498275757e-01
    z[3,2,0]  R1035     2.2105872631072998e-01
    z[3,2,0]  R1036     0.0990963950753212
    z[3,2,0]  R1037     1.7798755317926407e-02
    z[3,2,0]  R1038     1.1406289041042328e-01
    z[3,2,0]  R1039     5.3117722272872925e-01
    z[3,2,0]  R1040     1.7338527739048004e-01
    z[3,2,0]  R1041     2.8216194361448288e-02
    z[3,2,0]  R1042     1.5669876337051392e-01
    z[3,2,0]  R1043     4.4781687855720520e-01
    z[3,2,0]  R1044     3.3464625477790833e-01
    z[3,2,0]  R1045     3.2121995091438293e-01
    z[3,2,0]  R1046     5.7929539680480957e-01
    z[3,2,0]  R1047     -2.3732288181781769e-01
    z[3,2,0]  R1048     -1.1253122985363007e-01
    z[3,2,0]  R1049     1.6066257655620575e-01
    z[3,2,0]  R1050     2.9148164391517639e-01
    z[3,2,0]  R1051     -6.2944769859313965e-02
    z[3,2,0]  R1052     5.6542152166366577e-01
    z[3,2,0]  R1053     3.5250759124755859e-01
    z[3,2,0]  R1054     4.3026891350746155e-01
    z[3,2,0]  R1055     2.9435160756111145e-01
    z[3,2,0]  R1056     3.9072433114051819e-01
    z[3,2,0]  R1057     -0.301540344953537
    z[3,2,0]  R1058     -3.0550071597099304e-01
    z[3,2,0]  R1059     -2.3596100509166718e-01
    z[3,2,0]  R1060     2.5410386919975281e-01
    z[3,2,0]  R1061     4.7374597191810608e-01
    z[3,2,0]  R1062     4.8651728034019470e-01
    z[3,2,0]  R1063     6.4232480525970459e-01
    z[3,2,0]  R1064     4.4753953814506531e-01
    z[3,2,0]  R1065     3.5032770037651062e-01
    z[3,2,0]  R1066     5.7069998979568481e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R906      -1
    z[3,2,1]  R907      1
    z[3,2,1]  R918      1.3711350969970226e-02
    z[3,2,1]  R919      5.4299894720315933e-02
    z[3,2,1]  R920      2.4019737541675568e-01
    z[3,2,1]  R921      3.7223255634307861e-01
    z[3,2,1]  R922      2.8006935119628906e-01
    z[3,2,1]  R923      3.9857888221740723e-01
    z[3,2,1]  R924      4.2062580585479736e-01
    z[3,2,1]  R925      -2.2349764406681061e-01
    z[3,2,1]  R926      7.9020828008651733e-01
    z[3,2,1]  R927      7.2798633575439453e-01
    z[3,2,1]  R928      7.1584838628768921e-01
    z[3,2,1]  R929      -2.1504734456539154e-01
    z[3,2,1]  R930      6.5834307670593262e-01
    z[3,2,1]  R931      6.4349353313446045e-01
    z[3,2,1]  R932      8.0013543367385864e-02
    z[3,2,1]  R933      5.5630236864089966e-01
    z[3,2,1]  R934      5.1694333553314209e-01
    z[3,2,1]  R935      1.1657485365867615e-01
    z[3,2,1]  R936      1.8256975710391998e-01
    z[3,2,1]  R937      0.0415816530585289
    z[3,2,1]  R938      2.3756314814090729e-01
    z[3,2,1]  R939      -2.9377132654190063e-02
    z[3,2,1]  R940      -5.2666097879409790e-01
    z[3,2,1]  R941      5.0524920225143433e-01
    z[3,2,1]  R942      1.1464839428663254e-01
    z[3,2,1]  R943      -1.9159886986017227e-02
    z[3,2,1]  R944      4.8104834556579590e-01
    z[3,2,1]  R945      4.5014080405235291e-01
    z[3,2,1]  R946      -6.3170604407787323e-02
    z[3,2,1]  R947      2.7494031190872192e-01
    z[3,2,1]  R948      4.4470425695180893e-02
    z[3,2,1]  R949      -9.6938237547874451e-03
    z[3,2,1]  R950      4.1444137692451477e-01
    z[3,2,1]  R951      5.4111951589584351e-01
    z[3,2,1]  R952      0.627250611782074
    z[3,2,1]  R953      5.6994384527206421e-01
    z[3,2,1]  R954      -4.6652853488922119e-01
    z[3,2,1]  R955      -5.2630335092544556e-01
    z[3,2,1]  R956      4.4160258769989014e-01
    z[3,2,1]  R957      -5.4234772920608521e-01
    z[3,2,1]  R958      6.7723000049591064e-01
    z[3,2,1]  R959      -4.7758162021636963e-02
    z[3,2,1]  R960      -5.6062698364257812e-01
    z[3,2,1]  R961      4.3963938951492310e-01
    z[3,2,1]  R962      -1.6114315390586853e-01
    z[3,2,1]  R963      -9.4882321357727051e-01
    z[3,2,1]  R964      4.0067046880722046e-02
    z[3,2,1]  R965      -9.2889207601547241e-01
    z[3,2,1]  R966      -2.3473416268825531e-01
    z[3,2,1]  R967      -9.0752846002578735e-01
    z[3,2,1]  R968      7.4260032176971436e-01
    z[3,2,1]  R969      -6.6749060153961182e-01
    z[3,2,1]  R970      -4.7623196244239807e-01
    z[3,2,1]  R971      6.0549920797348022e-01
    z[3,2,1]  R972      4.7995755076408386e-01
    z[3,2,1]  R973      -4.0013200044631958e-01
    z[3,2,1]  R974      7.1967437863349915e-02
    z[3,2,1]  R975      -8.7360413745045662e-03
    z[3,2,1]  R976      6.3114196062088013e-02
    z[3,2,1]  R977      6.9946028292179108e-02
    z[3,2,1]  R978      7.9096013307571411e-01
    z[3,2,1]  R979      6.5089470148086548e-01
    z[3,2,1]  R980      5.2843958139419556e-01
    z[3,2,1]  R981      1.1336542665958405e-01
    z[3,2,1]  R982      5.1968789100646973e-01
    z[3,2,1]  R983      -4.5264068990945816e-02
    z[3,2,1]  R984      -5.3006079047918320e-02
    z[3,2,1]  R985      2.8267037868499756e-01
    z[3,2,1]  R986      1.7081966996192932e-01
    z[3,2,1]  R987      -8.8181960582733154e-01
    z[3,2,1]  R988      6.4701217412948608e-01
    z[3,2,1]  R989      -1.5277132391929626e-01
    z[3,2,1]  R990      5.6754022836685181e-01
    z[3,2,1]  R991      1.6682486236095428e-01
    z[3,2,1]  R992      1.8880617618560791e-01
    z[3,2,1]  R993      0.492443710565567
    z[3,2,1]  R994      -2.4261765182018280e-01
    z[3,2,1]  R995      1.0084971785545349e-01
    z[3,2,1]  R996      -8.7758040428161621e-01
    z[3,2,1]  R997      -3.5370045900344849e-01
    z[3,2,1]  R998      7.1731823682785034e-01
    z[3,2,1]  R999      5.5955308675765991e-01
    z[3,2,1]  R1000     -1.5039165318012238e-01
    z[3,2,1]  R1001     -2.1676853299140930e-01
    z[3,2,1]  R1002     1.5709306299686432e-01
    z[3,2,1]  R1003     -6.6963976621627808e-01
    z[3,2,1]  R1004     -5.3933167457580566e-01
    z[3,2,1]  R1005     -7.8680831193923950e-01
    z[3,2,1]  R1006     -4.8667269945144653e-01
    z[3,2,1]  R1007     -5.3156054019927979e-01
    z[3,2,1]  R1008     6.9027435779571533e-01
    z[3,2,1]  R1009     -1.5281352400779724e-01
    z[3,2,1]  R1010     0.324432373046875
    z[3,2,1]  R1011     4.5422129333019257e-02
    z[3,2,1]  R1012     -2.6522394269704819e-02
    z[3,2,1]  R1013     1.5438407659530640e-01
    z[3,2,1]  R1014     -0.581614077091217
    z[3,2,1]  R1015     -5.1495635509490967e-01
    z[3,2,1]  R1016     -1.3446459174156189e-01
    z[3,2,1]  R1017     -5.9460699558258057e-01
    z[3,2,1]  R1018     -5.0503000617027283e-02
    z[3,2,1]  R1019     -6.7437969148159027e-02
    z[3,2,1]  R1020     3.2634413801133633e-03
    z[3,2,1]  R1021     -3.5629320889711380e-02
    z[3,2,1]  R1022     -4.0873914957046509e-02
    z[3,2,1]  R1023     2.9203820973634720e-02
    z[3,2,1]  R1024     7.3784464597702026e-01
    z[3,2,1]  R1025     7.5842893123626709e-01
    z[3,2,1]  R1026     5.9752637147903442e-01
    z[3,2,1]  R1027     -7.4232590198516846e-01
    z[3,2,1]  R1028     -7.6864480972290039e-01
    z[3,2,1]  R1029     -4.6451109647750854e-01
    z[3,2,1]  R1030     -2.3297613859176636e-01
    z[3,2,1]  R1031     -0.83770751953125
    z[3,2,1]  R1032     -6.4848428964614868e-01
    z[3,2,1]  R1033     -6.2998992204666138e-01
    z[3,2,1]  R1034     -6.0057139396667480e-01
    z[3,2,1]  R1035     -5.4732006788253784e-01
    z[3,2,1]  R1036     -5.8858454227447510e-01
    z[3,2,1]  R1037     -8.7194216251373291e-01
    z[3,2,1]  R1038     -7.5847518444061279e-01
    z[3,2,1]  R1039     -0.737540066242218
    z[3,2,1]  R1040     -6.5106922388076782e-01
    z[3,2,1]  R1041     -4.9031745642423630e-02
    z[3,2,1]  R1042     -5.3413182497024536e-01
    z[3,2,1]  R1043     4.4354477524757385e-01
    z[3,2,1]  R1044     6.3502651453018188e-01
    z[3,2,1]  R1045     7.8038352727890015e-01
    z[3,2,1]  R1046     4.1401675343513489e-01
    z[3,2,1]  R1047     -0.774492084980011
    z[3,2,1]  R1048     -6.4482349157333374e-01
    z[3,2,1]  R1049     -6.9996660947799683e-01
    z[3,2,1]  R1050     -3.6509573459625244e-01
    z[3,2,1]  R1051     -2.3846681416034698e-01
    z[3,2,1]  R1052     -1.9123752415180206e-01
    z[3,2,1]  R1053     6.3160890340805054e-01
    z[3,2,1]  R1054     5.4495137929916382e-01
    z[3,2,1]  R1055     6.7421919107437134e-01
    z[3,2,1]  R1056     8.4285050630569458e-01
    z[3,2,1]  R1057     -2.3346172273159027e-01
    z[3,2,1]  R1058     -7.4203974008560181e-01
    z[3,2,1]  R1059     -6.6759639978408813e-01
    z[3,2,1]  R1060     -4.9453061074018478e-02
    z[3,2,1]  R1061     8.1790482997894287e-01
    z[3,2,1]  R1062     5.3430742025375366e-01
    z[3,2,1]  R1063     4.5711231231689453e-01
    z[3,2,1]  R1064     6.5081173181533813e-01
    z[3,2,1]  R1065     7.2330325841903687e-01
    z[3,2,1]  R1066     4.1058927774429321e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R908      -1
    z[3,2,2]  R909      1
    z[3,2,2]  R918      0.388574481010437
    z[3,2,2]  R919      2.4980668723583221e-01
    z[3,2,2]  R920      6.0219585895538330e-01
    z[3,2,2]  R921      3.8829341530799866e-01
    z[3,2,2]  R922      1.6707780957221985e-01
    z[3,2,2]  R923      4.4926857948303223e-01
    z[3,2,2]  R924      3.8597890734672546e-01
    z[3,2,2]  R925      1.4168396592140198e-01
    z[3,2,2]  R926      0.345490425825119
    z[3,2,2]  R927      5.9946954250335693e-01
    z[3,2,2]  R928      -4.6438673138618469e-01
    z[3,2,2]  R929      -0.453572154045105
    z[3,2,2]  R930      -2.5681027770042419e-01
    z[3,2,2]  R931      -6.0514993965625763e-02
    z[3,2,2]  R932      -3.0757537484169006e-01
    z[3,2,2]  R933      -1.1456935852766037e-01
    z[3,2,2]  R934      -2.6502177119255066e-01
    z[3,2,2]  R935      -3.3766967058181763e-01
    z[3,2,2]  R936      -2.5241887569427490e-01
    z[3,2,2]  R937      2.2210665047168732e-01
    z[3,2,2]  R938      -4.0944731235504150e-01
    z[3,2,2]  R939      6.3712793588638306e-01
    z[3,2,2]  R940      -6.7614391446113586e-02
    z[3,2,2]  R941      2.8389924764633179e-01
    z[3,2,2]  R942      -2.0516772568225861e-01
    z[3,2,2]  R943      -7.7193580567836761e-02
    z[3,2,2]  R944      1.2833668291568756e-01
    z[3,2,2]  R945      -4.6638140082359314e-01
    z[3,2,2]  R946      3.0287280678749084e-01
    z[3,2,2]  R947      2.8450208902359009e-01
    z[3,2,2]  R948      3.0728485435247421e-02
    z[3,2,2]  R949      1.0896039195358753e-02
    z[3,2,2]  R950      1.4771074056625366e-01
    z[3,2,2]  R951      4.6055087447166443e-01
    z[3,2,2]  R952      -4.0463727712631226e-01
    z[3,2,2]  R953      2.0238615572452545e-02
    z[3,2,2]  R954      5.5145698785781860e-01
    z[3,2,2]  R955      5.6918853521347046e-01
    z[3,2,2]  R956      -5.7994669675827026e-01
    z[3,2,2]  R957      2.2485144436359406e-01
    z[3,2,2]  R958      -2.5433886051177979e-01
    z[3,2,2]  R959      4.7333080321550369e-02
    z[3,2,2]  R960      5.2712643146514893e-01
    z[3,2,2]  R961      -3.9871567487716675e-01
    z[3,2,2]  R962      -1.4094695448875427e-01
    z[3,2,2]  R963      6.4704142510890961e-02
    z[3,2,2]  R964      -3.2439496368169785e-02
    z[3,2,2]  R965      3.1068574637174606e-02
    z[3,2,2]  R966      1.6097691655158997e-01
    z[3,2,2]  R967      2.4971139430999756e-01
    z[3,2,2]  R968      6.2799811363220215e-02
    z[3,2,2]  R969      1.2318023294210434e-01
    z[3,2,2]  R970      0.424014687538147
    z[3,2,2]  R971      0.0715944841504097
    z[3,2,2]  R972      -2.9453590512275696e-01
    z[3,2,2]  R973      7.6235704123973846e-02
    z[3,2,2]  R974      1.3002495467662811e-01
    z[3,2,2]  R975      -1.7952781915664673e-01
    z[3,2,2]  R976      -0.280814528465271
    z[3,2,2]  R977      2.7645226567983627e-02
    z[3,2,2]  R978      -1.2493391335010529e-01
    z[3,2,2]  R979      1.9838419556617737e-01
    z[3,2,2]  R980      -0.488179087638855
    z[3,2,2]  R981      -2.6554372906684875e-01
    z[3,2,2]  R982      3.6922845244407654e-01
    z[3,2,2]  R983      -0.0339483805000782
    z[3,2,2]  R984      1.3924182951450348e-01
    z[3,2,2]  R985      1.7402195930480957e-01
    z[3,2,2]  R986      -1.2328878045082092e-01
    z[3,2,2]  R987      -5.0941850990056992e-02
    z[3,2,2]  R988      4.4459328055381775e-02
    z[3,2,2]  R989      5.5610740184783936e-01
    z[3,2,2]  R990      -1.8911378085613251e-01
    z[3,2,2]  R991      -1.1785674095153809e-01
    z[3,2,2]  R992      -2.0113836228847504e-01
    z[3,2,2]  R993      -5.2802842855453491e-01
    z[3,2,2]  R994      -5.6183699518442154e-02
    z[3,2,2]  R995      3.6028262972831726e-01
    z[3,2,2]  R996      -4.0361863374710083e-01
    z[3,2,2]  R997      -6.0564011335372925e-01
    z[3,2,2]  R998      1.1743155121803284e-01
    z[3,2,2]  R999      -2.8917932510375977e-01
    z[3,2,2]  R1000     -1.1606529355049133e-01
    z[3,2,2]  R1001     -9.5972500275820494e-04
    z[3,2,2]  R1002     -1.6278178989887238e-01
    z[3,2,2]  R1003     -4.5483973622322083e-01
    z[3,2,2]  R1004     -4.7846508026123047e-01
    z[3,2,2]  R1005     2.9979849234223366e-02
    z[3,2,2]  R1006     -4.4776901602745056e-01
    z[3,2,2]  R1007     -3.7698981165885925e-01
    z[3,2,2]  R1008     -4.9701115489006042e-01
    z[3,2,2]  R1009     -2.9945635795593262e-01
    z[3,2,2]  R1010     -2.0904821157455444e-01
    z[3,2,2]  R1011     1.8929970264434814e-01
    z[3,2,2]  R1012     1.1313340812921524e-01
    z[3,2,2]  R1013     -1.4072303473949432e-01
    z[3,2,2]  R1014     -2.4279899895191193e-01
    z[3,2,2]  R1015     -5.3732901811599731e-01
    z[3,2,2]  R1016     -0.518753707408905
    z[3,2,2]  R1017     -6.6158592700958252e-01
    z[3,2,2]  R1018     6.5919585525989532e-02
    z[3,2,2]  R1019     1.5690113604068756e-01
    z[3,2,2]  R1020     -1.3273629546165466e-01
    z[3,2,2]  R1021     2.4814562499523163e-01
    z[3,2,2]  R1022     -1.4085343107581139e-02
    z[3,2,2]  R1023     -3.6242190003395081e-01
    z[3,2,2]  R1024     -3.3191487193107605e-01
    z[3,2,2]  R1025     0.0945688933134079
    z[3,2,2]  R1026     2.0823976397514343e-01
    z[3,2,2]  R1027     -4.9097096920013428e-01
    z[3,2,2]  R1028     -1.9649036228656769e-01
    z[3,2,2]  R1029     2.1629586815834045e-01
    z[3,2,2]  R1030     0.693274199962616
    z[3,2,2]  R1031     -2.5046586990356445e-01
    z[3,2,2]  R1032     3.4714984893798828e-01
    z[3,2,2]  R1033     1.4693361520767212e-01
    z[3,2,2]  R1034     -2.0404672622680664e-01
    z[3,2,2]  R1035     -4.6474647521972656e-01
    z[3,2,2]  R1036     -4.5270577073097229e-01
    z[3,2,2]  R1037     -1.9578759372234344e-01
    z[3,2,2]  R1038     2.8505036234855652e-01
    z[3,2,2]  R1039     -3.2137352973222733e-02
    z[3,2,2]  R1040     1.6045522689819336e-01
    z[3,2,2]  R1041     -2.9685732722282410e-01
    z[3,2,2]  R1042     -3.7420034408569336e-01
    z[3,2,2]  R1043     -2.1563017368316650e-01
    z[3,2,2]  R1044     3.0412617325782776e-01
    z[3,2,2]  R1045     4.7782737016677856e-01
    z[3,2,2]  R1046     -1.0993339121341705e-01
    z[3,2,2]  R1047     4.3414631485939026e-01
    z[3,2,2]  R1048     -6.0789614915847778e-01
    z[3,2,2]  R1049     -4.0976539254188538e-01
    z[3,2,2]  R1050     -2.6562992483377457e-02
    z[3,2,2]  R1051     -2.7773827314376831e-01
    z[3,2,2]  R1052     1.0486693121492863e-02
    z[3,2,2]  R1053     -9.5970399677753448e-02
    z[3,2,2]  R1054     1.6788119077682495e-01
    z[3,2,2]  R1055     -7.4469313025474548e-02
    z[3,2,2]  R1056     3.2411456108093262e-01
    z[3,2,2]  R1057     1.6742104291915894e-01
    z[3,2,2]  R1058     -3.0482724308967590e-01
    z[3,2,2]  R1059     1.1141819506883621e-01
    z[3,2,2]  R1060     -5.6936436891555786e-01
    z[3,2,2]  R1061     1.6606016457080841e-01
    z[3,2,2]  R1062     -1.3456906378269196e-01
    z[3,2,2]  R1063     -1.5954619273543358e-02
    z[3,2,2]  R1064     9.6836470067501068e-02
    z[3,2,2]  R1065     5.0356034189462662e-02
    z[3,2,2]  R1066     2.9992294311523438e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R910      -1
    z[3,2,3]  R911      1
    z[3,2,3]  R918      -2.1983437240123749e-01
    z[3,2,3]  R919      -3.3784502744674683e-01
    z[3,2,3]  R920      -2.1890088915824890e-01
    z[3,2,3]  R921      1.0547752678394318e-01
    z[3,2,3]  R922      3.8617804646492004e-02
    z[3,2,3]  R923      -2.0519154146313667e-02
    z[3,2,3]  R924      3.8928262889385223e-02
    z[3,2,3]  R925      -3.7719801068305969e-01
    z[3,2,3]  R926      -2.8920945525169373e-01
    z[3,2,3]  R927      -2.4688212573528290e-01
    z[3,2,3]  R928      2.2081515192985535e-01
    z[3,2,3]  R929      5.5929505825042725e-01
    z[3,2,3]  R930      2.4585790932178497e-01
    z[3,2,3]  R931      6.1227369308471680e-01
    z[3,2,3]  R932      -8.4651607275009155e-01
    z[3,2,3]  R933      3.4073927998542786e-01
    z[3,2,3]  R934      6.9690680503845215e-01
    z[3,2,3]  R935      -5.2825736999511719e-01
    z[3,2,3]  R936      -4.5570856332778931e-01
    z[3,2,3]  R937      1.1839376389980316e-01
    z[3,2,3]  R938      8.2410866022109985e-01
    z[3,2,3]  R939      3.8797068595886230e-01
    z[3,2,3]  R940      2.3541538417339325e-01
    z[3,2,3]  R941      3.8441452383995056e-01
    z[3,2,3]  R942      1.0509452782571316e-02
    z[3,2,3]  R943      -1.1293182522058487e-01
    z[3,2,3]  R944      2.7240052819252014e-01
    z[3,2,3]  R945      -2.9375419020652771e-01
    z[3,2,3]  R946      -4.5824725180864334e-02
    z[3,2,3]  R947      1.9795901607722044e-03
    z[3,2,3]  R948      6.7289197444915771e-01
    z[3,2,3]  R949      6.0950154066085815e-01
    z[3,2,3]  R950      4.7397544980049133e-01
    z[3,2,3]  R951      4.8006868362426758e-01
    z[3,2,3]  R952      2.0311798900365829e-02
    z[3,2,3]  R953      -4.1097089648246765e-01
    z[3,2,3]  R954      4.3353244662284851e-01
    z[3,2,3]  R955      3.1306838989257812e-01
    z[3,2,3]  R956      -3.0565026402473450e-01
    z[3,2,3]  R957      2.4861592054367065e-01
    z[3,2,3]  R958      8.8877469301223755e-02
    z[3,2,3]  R959      -1.5399585664272308e-01
    z[3,2,3]  R960      4.1052162647247314e-01
    z[3,2,3]  R961      -2.8152248263359070e-01
    z[3,2,3]  R962      7.5641043484210968e-02
    z[3,2,3]  R963      -9.4083890318870544e-02
    z[3,2,3]  R964      3.7302400916814804e-02
    z[3,2,3]  R965      -6.9526262581348419e-02
    z[3,2,3]  R966      -3.0936279892921448e-01
    z[3,2,3]  R967      5.2418440580368042e-02
    z[3,2,3]  R968      3.3702442049980164e-01
    z[3,2,3]  R969      5.6980293989181519e-01
    z[3,2,3]  R970      4.3843919038772583e-01
    z[3,2,3]  R971      -3.5689270496368408e-01
    z[3,2,3]  R972      -2.8074812889099121e-01
    z[3,2,3]  R973      3.2118624448776245e-01
    z[3,2,3]  R974      -3.9957201480865479e-01
    z[3,2,3]  R975      2.8057834506034851e-01
    z[3,2,3]  R976      -0.649041473865509
    z[3,2,3]  R977      -9.9989846348762512e-02
    z[3,2,3]  R978      1.8089847872033715e-03
    z[3,2,3]  R979      8.7370024994015694e-04
    z[3,2,3]  R980      -3.8883021473884583e-01
    z[3,2,3]  R981      -6.4202928543090820e-01
    z[3,2,3]  R982      2.5093883275985718e-01
    z[3,2,3]  R983      1.7347642779350281e-01
    z[3,2,3]  R984      -1.0311586409807205e-01
    z[3,2,3]  R985      -1.5421982109546661e-01
    z[3,2,3]  R986      -4.7485277056694031e-01
    z[3,2,3]  R987      -3.8497611880302429e-01
    z[3,2,3]  R988      -3.3683210611343384e-01
    z[3,2,3]  R989      3.6364433169364929e-01
    z[3,2,3]  R990      2.2673273086547852e-01
    z[3,2,3]  R991      0.277258962392807
    z[3,2,3]  R992      -5.7367360591888428e-01
    z[3,2,3]  R993      8.6202420294284821e-02
    z[3,2,3]  R994      -3.1494984030723572e-01
    z[3,2,3]  R995      -1.5366628766059875e-01
    z[3,2,3]  R996      -1.6533143818378448e-01
    z[3,2,3]  R997      2.4333539605140686e-01
    z[3,2,3]  R998      -4.1196337342262268e-01
    z[3,2,3]  R999      5.6809765100479126e-01
    z[3,2,3]  R1000     -3.2596006989479065e-02
    z[3,2,3]  R1001     -2.0463606715202332e-01
    z[3,2,3]  R1002     -2.2062188386917114e-01
    z[3,2,3]  R1003     -4.1860058903694153e-01
    z[3,2,3]  R1004     -4.4509038329124451e-02
    z[3,2,3]  R1005     -3.3235767483711243e-01
    z[3,2,3]  R1006     -2.3991049826145172e-01
    z[3,2,3]  R1007     -3.9578244090080261e-01
    z[3,2,3]  R1008     -1.1740065366029739e-01
    z[3,2,3]  R1009     4.9503996968269348e-01
    z[3,2,3]  R1010     -5.5340075492858887e-01
    z[3,2,3]  R1011     -3.4102407097816467e-01
    z[3,2,3]  R1012     1.7385666072368622e-01
    z[3,2,3]  R1013     -2.4025362730026245e-01
    z[3,2,3]  R1014     -3.6551502346992493e-01
    z[3,2,3]  R1015     1.0349040478467941e-01
    z[3,2,3]  R1016     -1.5072527341544628e-02
    z[3,2,3]  R1017     1.3338880613446236e-02
    z[3,2,3]  R1018     -9.0902382135391235e-01
    z[3,2,3]  R1019     -7.4488759040832520e-01
    z[3,2,3]  R1020     -7.3872792720794678e-01
    z[3,2,3]  R1021     -7.1963566541671753e-01
    z[3,2,3]  R1022     -8.4947013854980469e-01
    z[3,2,3]  R1023     -6.7806845903396606e-01
    z[3,2,3]  R1024     6.8751536309719086e-02
    z[3,2,3]  R1025     -4.6488042920827866e-02
    z[3,2,3]  R1026     -2.6350151747465134e-02
    z[3,2,3]  R1027     -1.4525451697409153e-02
    z[3,2,3]  R1028     2.5759249925613403e-01
    z[3,2,3]  R1029     -5.7335708290338516e-02
    z[3,2,3]  R1030     -2.7631255984306335e-01
    z[3,2,3]  R1031     2.0623576641082764e-01
    z[3,2,3]  R1032     4.7101509571075439e-01
    z[3,2,3]  R1033     4.3801674246788025e-01
    z[3,2,3]  R1034     1.6934689879417419e-01
    z[3,2,3]  R1035     3.1265792250633240e-01
    z[3,2,3]  R1036     1.8767033517360687e-01
    z[3,2,3]  R1037     -1.3730492442846298e-02
    z[3,2,3]  R1038     4.7327306866645813e-01
    z[3,2,3]  R1039     3.6038488149642944e-01
    z[3,2,3]  R1040     3.5026934742927551e-01
    z[3,2,3]  R1041     -3.5700049996376038e-01
    z[3,2,3]  R1042     4.5172271132469177e-01
    z[3,2,3]  R1043     6.7419892549514771e-01
    z[3,2,3]  R1044     5.0025576353073120e-01
    z[3,2,3]  R1045     8.1911824643611908e-02
    z[3,2,3]  R1046     4.2093262076377869e-02
    z[3,2,3]  R1047     -2.3202177882194519e-01
    z[3,2,3]  R1048     -2.6309096813201904e-01
    z[3,2,3]  R1049     -3.6003756523132324e-01
    z[3,2,3]  R1050     -5.2444475889205933e-01
    z[3,2,3]  R1051     -4.5565196871757507e-01
    z[3,2,3]  R1052     -5.5628603696823120e-01
    z[3,2,3]  R1053     6.5259546041488647e-01
    z[3,2,3]  R1054     5.7947164773941040e-01
    z[3,2,3]  R1055     4.9359327554702759e-01
    z[3,2,3]  R1056     -6.3951924443244934e-02
    z[3,2,3]  R1057     -0.901881217956543
    z[3,2,3]  R1058     -2.7289089560508728e-01
    z[3,2,3]  R1059     -1.7915260791778564e-01
    z[3,2,3]  R1060     -6.3319075107574463e-01
    z[3,2,3]  R1061     9.9597439169883728e-02
    z[3,2,3]  R1062     0.581642210483551
    z[3,2,3]  R1063     3.8312000036239624e-01
    z[3,2,3]  R1064     3.3111450076103210e-01
    z[3,2,3]  R1065     -4.5543190091848373e-02
    z[3,2,3]  R1066     2.4427708983421326e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R912      -1
    z[3,2,4]  R913      1
    z[3,2,4]  R918      3.6975425481796265e-01
    z[3,2,4]  R919      0.0836007222533226
    z[3,2,4]  R920      2.7925944328308105e-01
    z[3,2,4]  R921      1.6411504149436951e-01
    z[3,2,4]  R922      -1.3834075629711151e-01
    z[3,2,4]  R923      9.8664209246635437e-02
    z[3,2,4]  R924      -1.6533695161342621e-01
    z[3,2,4]  R925      -2.0861823856830597e-01
    z[3,2,4]  R926      -2.3871515691280365e-01
    z[3,2,4]  R927      -6.3319101929664612e-02
    z[3,2,4]  R928      4.0838193893432617e-01
    z[3,2,4]  R929      -1.8973509967327118e-01
    z[3,2,4]  R930      3.4369704127311707e-01
    z[3,2,4]  R931      -1.2840871512889862e-01
    z[3,2,4]  R932      2.6399930939078331e-02
    z[3,2,4]  R933      -2.5398489832878113e-01
    z[3,2,4]  R934      -1.4980722218751907e-02
    z[3,2,4]  R935      2.6581141352653503e-01
    z[3,2,4]  R936      -5.2717506885528564e-01
    z[3,2,4]  R937      -2.4696613848209381e-01
    z[3,2,4]  R938      -2.6409873366355896e-01
    z[3,2,4]  R939      -2.9159709811210632e-01
    z[3,2,4]  R940      -4.9763542413711548e-01
    z[3,2,4]  R941      -2.1162109076976776e-01
    z[3,2,4]  R942      -3.0046626925468445e-01
    z[3,2,4]  R943      -1.0412283986806870e-01
    z[3,2,4]  R944      1.2374614179134369e-01
    z[3,2,4]  R945      -5.5735909938812256e-01
    z[3,2,4]  R946      -2.5431391596794128e-01
    z[3,2,4]  R947      2.7516716718673706e-01
    z[3,2,4]  R948      1.2355333566665649e-01
    z[3,2,4]  R949      -3.3346304297447205e-01
    z[3,2,4]  R950      -0.394437313079834
    z[3,2,4]  R951      -2.4966441094875336e-01
    z[3,2,4]  R952      3.9922407269477844e-01
    z[3,2,4]  R953      4.2915868759155273e-01
    z[3,2,4]  R954      1.0579667240381241e-01
    z[3,2,4]  R955      -0.181906595826149
    z[3,2,4]  R956      -7.3114745318889618e-02
    z[3,2,4]  R957      -1.4692904055118561e-01
    z[3,2,4]  R958      -4.5659685134887695e-01
    z[3,2,4]  R959      1.6165295243263245e-01
    z[3,2,4]  R960      -1.6063414514064789e-01
    z[3,2,4]  R961      -4.8005864024162292e-01
    z[3,2,4]  R962      3.8883373141288757e-02
    z[3,2,4]  R963      1.1996621638536453e-01
    z[3,2,4]  R964      3.7625020742416382e-01
    z[3,2,4]  R965      3.4751359373331070e-02
    z[3,2,4]  R966      4.7478446364402771e-01
    z[3,2,4]  R967      -1.5053851902484894e-01
    z[3,2,4]  R968      -2.2645914554595947e-01
    z[3,2,4]  R969      -5.7060797698795795e-03
    z[3,2,4]  R970      -7.6822616159915924e-02
    z[3,2,4]  R971      2.1029409021139145e-02
    z[3,2,4]  R972      1.8492749333381653e-01
    z[3,2,4]  R973      -1.1500279605388641e-01
    z[3,2,4]  R974      6.0783304274082184e-02
    z[3,2,4]  R975      7.0928357541561127e-02
    z[3,2,4]  R976      -0.42122882604599
    z[3,2,4]  R977      1.3787874579429626e-01
    z[3,2,4]  R978      2.6096263527870178e-01
    z[3,2,4]  R979      -0.16848124563694
    z[3,2,4]  R980      3.8658101111650467e-02
    z[3,2,4]  R981      -4.1916516423225403e-01
    z[3,2,4]  R982      4.3393567204475403e-01
    z[3,2,4]  R983      2.7704099193215370e-02
    z[3,2,4]  R984      3.0394849181175232e-01
    z[3,2,4]  R985      -2.5828543305397034e-01
    z[3,2,4]  R986      3.7149384617805481e-01
    z[3,2,4]  R987      4.7176092863082886e-02
    z[3,2,4]  R988      -2.7131193876266479e-01
    z[3,2,4]  R989      -2.9805478453636169e-01
    z[3,2,4]  R990      -6.0237679630517960e-02
    z[3,2,4]  R991      -6.2752211093902588e-01
    z[3,2,4]  R992      1.4327786862850189e-01
    z[3,2,4]  R993      -4.9175915122032166e-01
    z[3,2,4]  R994      -9.4972558319568634e-02
    z[3,2,4]  R995      9.8763778805732727e-02
    z[3,2,4]  R996      -1.2358006834983826e-01
    z[3,2,4]  R997      8.0499485135078430e-02
    z[3,2,4]  R998      2.8234642744064331e-01
    z[3,2,4]  R999      9.6305571496486664e-02
    z[3,2,4]  R1000     -7.1907705068588257e-01
    z[3,2,4]  R1001     -1.6345153562724590e-03
    z[3,2,4]  R1002     -2.5797012448310852e-01
    z[3,2,4]  R1003     -1.1582937091588974e-01
    z[3,2,4]  R1004     2.3507069051265717e-01
    z[3,2,4]  R1005     -1.5902440249919891e-01
    z[3,2,4]  R1006     -1.6797071322798729e-02
    z[3,2,4]  R1007     1.1166515201330185e-01
    z[3,2,4]  R1008     -2.2787198424339294e-01
    z[3,2,4]  R1009     -1.4868468046188354e-01
    z[3,2,4]  R1010     -3.1543251127004623e-02
    z[3,2,4]  R1011     4.9308642745018005e-02
    z[3,2,4]  R1012     3.4621319174766541e-01
    z[3,2,4]  R1013     -2.5849640369415283e-01
    z[3,2,4]  R1014     2.3924781382083893e-01
    z[3,2,4]  R1015     1.4420378953218460e-02
    z[3,2,4]  R1016     -0.0878065750002861
    z[3,2,4]  R1017     4.0671084076166153e-02
    z[3,2,4]  R1018     -6.6306792199611664e-02
    z[3,2,4]  R1019     4.3965074419975281e-01
    z[3,2,4]  R1020     4.4334211945533752e-01
    z[3,2,4]  R1021     1.6884812712669373e-01
    z[3,2,4]  R1022     -3.4588897228240967e-01
    z[3,2,4]  R1023     -3.7867131829261780e-01
    z[3,2,4]  R1024     7.8314365819096565e-03
    z[3,2,4]  R1025     4.1429454088211060e-01
    z[3,2,4]  R1026     -1.2736883759498596e-01
    z[3,2,4]  R1027     1.5730260312557220e-01
    z[3,2,4]  R1028     2.1937662363052368e-01
    z[3,2,4]  R1029     1.5066680312156677e-01
    z[3,2,4]  R1030     1.6973850131034851e-01
    z[3,2,4]  R1031     1.2679381668567657e-01
    z[3,2,4]  R1032     -1.1155434697866440e-01
    z[3,2,4]  R1033     1.6030846536159515e-01
    z[3,2,4]  R1034     -5.6932407617568970e-01
    z[3,2,4]  R1035     2.9742112755775452e-01
    z[3,2,4]  R1036     -1.7082078754901886e-01
    z[3,2,4]  R1037     -1.8431127071380615e-01
    z[3,2,4]  R1038     2.8770866990089417e-01
    z[3,2,4]  R1039     -1.8145841360092163e-01
    z[3,2,4]  R1040     -2.6810136437416077e-01
    z[3,2,4]  R1041     1.8248723447322845e-01
    z[3,2,4]  R1042     -3.3276686072349548e-01
    z[3,2,4]  R1043     0.265112966299057
    z[3,2,4]  R1044     -2.2561891376972198e-01
    z[3,2,4]  R1045     -5.3866151720285416e-02
    z[3,2,4]  R1046     5.6937980651855469e-01
    z[3,2,4]  R1047     -2.1870298683643341e-01
    z[3,2,4]  R1048     2.0903086662292480e-01
    z[3,2,4]  R1049     -4.2719554901123047e-01
    z[3,2,4]  R1050     2.5150260329246521e-01
    z[3,2,4]  R1051     5.7169649749994278e-02
    z[3,2,4]  R1052     3.5505077242851257e-01
    z[3,2,4]  R1053     1.1017717421054840e-01
    z[3,2,4]  R1054     -3.7148892879486084e-01
    z[3,2,4]  R1055     -4.1202649474143982e-02
    z[3,2,4]  R1056     -1.1888147145509720e-01
    z[3,2,4]  R1057     7.6279595494270325e-02
    z[3,2,4]  R1058     6.9572590291500092e-02
    z[3,2,4]  R1059     2.4538795650005341e-01
    z[3,2,4]  R1060     -3.0108207464218140e-01
    z[3,2,4]  R1061     1.8064978718757629e-01
    z[3,2,4]  R1062     1.0405606776475906e-01
    z[3,2,4]  R1063     1.2176611274480820e-01
    z[3,2,4]  R1064     -3.5840880870819092e-01
    z[3,2,4]  R1065     -4.9609247595071793e-02
    z[3,2,4]  R1066     -3.0643252655863762e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R914      -1
    z[3,2,5]  R915      1
    z[3,2,5]  R918      3.3980527520179749e-01
    z[3,2,5]  R919      0.486115425825119
    z[3,2,5]  R920      9.7025007009506226e-02
    z[3,2,5]  R921      2.9867282509803772e-01
    z[3,2,5]  R922      4.1259261965751648e-01
    z[3,2,5]  R923      4.1188114881515503e-01
    z[3,2,5]  R924      -0.074520044028759
    z[3,2,5]  R925      -1.9655311107635498e-01
    z[3,2,5]  R926      -2.0525650680065155e-01
    z[3,2,5]  R927      0.0744505226612091
    z[3,2,5]  R928      -9.6932850778102875e-02
    z[3,2,5]  R929      -6.0361623764038086e-01
    z[3,2,5]  R930      2.6354864239692688e-01
    z[3,2,5]  R931      2.4786043167114258e-01
    z[3,2,5]  R932      1.6977612674236298e-01
    z[3,2,5]  R933      -9.4695478677749634e-02
    z[3,2,5]  R934      -2.2654792666435242e-01
    z[3,2,5]  R935      -2.9492089152336121e-01
    z[3,2,5]  R936      3.2390865683555603e-01
    z[3,2,5]  R937      -8.4928011894226074e-01
    z[3,2,5]  R938      -1.0813717544078827e-01
    z[3,2,5]  R939      -2.7280244231224060e-01
    z[3,2,5]  R940      -4.6663495898246765e-01
    z[3,2,5]  R941      -5.3795474767684937e-01
    z[3,2,5]  R942      -1.1047238111495972e-01
    z[3,2,5]  R943      1.4906586706638336e-01
    z[3,2,5]  R944      -7.2340106964111328e-01
    z[3,2,5]  R945      0.17389015853405
    z[3,2,5]  R946      1.3917692005634308e-01
    z[3,2,5]  R947      -2.3230737075209618e-02
    z[3,2,5]  R948      -7.0192688703536987e-01
    z[3,2,5]  R949      -3.6358866095542908e-01
    z[3,2,5]  R950      -5.8569401502609253e-01
    z[3,2,5]  R951      -4.0828722715377808e-01
    z[3,2,5]  R952      3.3582428097724915e-01
    z[3,2,5]  R953      1.7942123115062714e-01
    z[3,2,5]  R954      -4.3635964393615723e-01
    z[3,2,5]  R955      -4.8830467462539673e-01
    z[3,2,5]  R956      -1.7145806550979614e-01
    z[3,2,5]  R957      -4.1066142916679382e-01
    z[3,2,5]  R958      6.2644377350807190e-02
    z[3,2,5]  R959      -1.7560601234436035e-01
    z[3,2,5]  R960      -0.392000675201416
    z[3,2,5]  R961      1.3934718072414398e-01
    z[3,2,5]  R962      -3.3349204063415527e-01
    z[3,2,5]  R963      -1.2825973331928253e-01
    z[3,2,5]  R964      4.3615409731864929e-01
    z[3,2,5]  R965      2.9254710674285889e-01
    z[3,2,5]  R966      -0.0223592147231102
    z[3,2,5]  R967      1.2361817806959152e-01
    z[3,2,5]  R968      4.9798870086669922e-01
    z[3,2,5]  R969      -0.242364302277565
    z[3,2,5]  R970      -6.2602925300598145e-01
    z[3,2,5]  R971      1.8952375650405884e-01
    z[3,2,5]  R972      -5.4515582323074341e-01
    z[3,2,5]  R973      -3.3561038970947266e-01
    z[3,2,5]  R974      1.5446986258029938e-01
    z[3,2,5]  R975      2.5392949581146240e-01
    z[3,2,5]  R976      -3.6997672915458679e-01
    z[3,2,5]  R977      5.0624340772628784e-01
    z[3,2,5]  R978      4.5626637339591980e-01
    z[3,2,5]  R979      4.2337018251419067e-01
    z[3,2,5]  R980      -3.2346537709236145e-01
    z[3,2,5]  R981      -3.3001348376274109e-01
    z[3,2,5]  R982      -1.9071669876575470e-01
    z[3,2,5]  R983      -2.1720662713050842e-02
    z[3,2,5]  R984      1.8512552604079247e-02
    z[3,2,5]  R985      2.5458592176437378e-01
    z[3,2,5]  R986      3.2484656572341919e-01
    z[3,2,5]  R987      9.8366884049028158e-04
    z[3,2,5]  R988      3.3701050281524658e-01
    z[3,2,5]  R989      -3.8555371761322021e-01
    z[3,2,5]  R990      -5.9404969215393066e-01
    z[3,2,5]  R991      -4.4391539692878723e-01
    z[3,2,5]  R992      -4.4910570979118347e-01
    z[3,2,5]  R993      -1.1908382177352905e-01
    z[3,2,5]  R994      -3.5017880797386169e-01
    z[3,2,5]  R995      -3.3454936742782593e-01
    z[3,2,5]  R996      -1.4463682472705841e-01
    z[3,2,5]  R997      3.1754285097122192e-01
    z[3,2,5]  R998      -1.9783751666545868e-01
    z[3,2,5]  R999      -3.1333526968955994e-01
    z[3,2,5]  R1000     -6.5661799907684326e-01
    z[3,2,5]  R1001     -0.303000271320343
    z[3,2,5]  R1002     3.2724419236183167e-01
    z[3,2,5]  R1003     1.0442462563514709e-01
    z[3,2,5]  R1004     5.4920810461044312e-01
    z[3,2,5]  R1005     3.1957671046257019e-01
    z[3,2,5]  R1006     6.4711350202560425e-01
    z[3,2,5]  R1007     1.8048487603664398e-01
    z[3,2,5]  R1008     -3.1513166427612305e-01
    z[3,2,5]  R1009     -6.5260219573974609e-01
    z[3,2,5]  R1010     -1.8633204698562622e-01
    z[3,2,5]  R1011     -1.1351475864648819e-01
    z[3,2,5]  R1012     -2.0502893626689911e-01
    z[3,2,5]  R1013     2.9521077871322632e-01
    z[3,2,5]  R1014     3.3200421929359436e-01
    z[3,2,5]  R1015     0.461311936378479
    z[3,2,5]  R1016     6.2382197380065918e-01
    z[3,2,5]  R1017     4.1954675316810608e-01
    z[3,2,5]  R1018     -2.3398378491401672e-01
    z[3,2,5]  R1019     -4.6752616763114929e-02
    z[3,2,5]  R1020     1.3514953851699829e-01
    z[3,2,5]  R1021     0.46548992395401
    z[3,2,5]  R1022     0.344230055809021
    z[3,2,5]  R1023     5.0049668550491333e-01
    z[3,2,5]  R1024     -3.2925210893154144e-02
    z[3,2,5]  R1025     -1.1988820135593414e-01
    z[3,2,5]  R1026     2.9034256935119629e-01
    z[3,2,5]  R1027     5.4852332919836044e-02
    z[3,2,5]  R1028     3.2863688468933105e-01
    z[3,2,5]  R1029     -6.5464353561401367e-01
    z[3,2,5]  R1030     -3.5209223628044128e-01
    z[3,2,5]  R1031     -3.9660032838582993e-02
    z[3,2,5]  R1032     3.9664039015769958e-01
    z[3,2,5]  R1033     -2.3206442594528198e-01
    z[3,2,5]  R1034     -1.0509885102510452e-01
    z[3,2,5]  R1035     -3.5911419987678528e-01
    z[3,2,5]  R1036     -1.9423596560955048e-01
    z[3,2,5]  R1037     -2.9846975207328796e-01
    z[3,2,5]  R1038     -1.5160897374153137e-01
    z[3,2,5]  R1039     8.6666487157344818e-02
    z[3,2,5]  R1040     -1.0509578138589859e-01
    z[3,2,5]  R1041     -9.1551892459392548e-02
    z[3,2,5]  R1042     4.1956865787506104e-01
    z[3,2,5]  R1043     1.3488624989986420e-01
    z[3,2,5]  R1044     -4.5855108648538589e-02
    z[3,2,5]  R1045     -1.9494697451591492e-01
    z[3,2,5]  R1046     3.9313459396362305e-01
    z[3,2,5]  R1047     2.2306744754314423e-01
    z[3,2,5]  R1048     -3.1990390270948410e-02
    z[3,2,5]  R1049     4.2567834258079529e-02
    z[3,2,5]  R1050     5.0508803129196167e-01
    z[3,2,5]  R1051     2.3285277187824249e-01
    z[3,2,5]  R1052     -2.5751617550849915e-01
    z[3,2,5]  R1053     -1.4964435994625092e-01
    z[3,2,5]  R1054     1.2595626711845398e-01
    z[3,2,5]  R1055     1.0267663002014160e-01
    z[3,2,5]  R1056     -4.0106363594532013e-02
    z[3,2,5]  R1057     2.9455076903104782e-02
    z[3,2,5]  R1058     3.7211453914642334e-01
    z[3,2,5]  R1059     -5.3069853782653809e-01
    z[3,2,5]  R1060     -2.3428719490766525e-02
    z[3,2,5]  R1061     -1.6490390896797180e-01
    z[3,2,5]  R1062     2.6599767804145813e-01
    z[3,2,5]  R1063     4.1694071888923645e-01
    z[3,2,5]  R1064     -3.0218055844306946e-01
    z[3,2,5]  R1065     -1.9956310093402863e-01
    z[3,2,5]  R1066     -4.7557353973388672e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R916      -1
    z[3,2,6]  R917      1
    z[3,2,6]  R918      -1.1921192705631256e-01
    z[3,2,6]  R919      -1.0565267503261566e-01
    z[3,2,6]  R920      -1.8575143814086914e-01
    z[3,2,6]  R921      -1.1226785928010941e-01
    z[3,2,6]  R922      -2.7282893657684326e-01
    z[3,2,6]  R923      -3.4772503376007080e-01
    z[3,2,6]  R924      -1.6278398036956787e-01
    z[3,2,6]  R925      -3.4013012051582336e-01
    z[3,2,6]  R926      -2.7045345306396484e-01
    z[3,2,6]  R927      2.0042194426059723e-01
    z[3,2,6]  R928      -2.1347667276859283e-01
    z[3,2,6]  R929      7.5314551591873169e-02
    z[3,2,6]  R930      4.8321974277496338e-01
    z[3,2,6]  R931      2.0423837006092072e-01
    z[3,2,6]  R932      -2.2396599873900414e-02
    z[3,2,6]  R933      6.8618965148925781e-01
    z[3,2,6]  R934      3.4243202209472656e-01
    z[3,2,6]  R935      -1.0500402003526688e-01
    z[3,2,6]  R936      1.4225970208644867e-01
    z[3,2,6]  R937      -8.8078305125236511e-02
    z[3,2,6]  R938      1.0345313698053360e-01
    z[3,2,6]  R939      -6.8595241755247116e-03
    z[3,2,6]  R940      -4.4258746504783630e-01
    z[3,2,6]  R941      -2.6830476522445679e-01
    z[3,2,6]  R942      6.9326788187026978e-02
    z[3,2,6]  R943      -3.4348601102828979e-01
    z[3,2,6]  R944      0.0750337466597557
    z[3,2,6]  R945      0.390138179063797
    z[3,2,6]  R946      1.6677644848823547e-01
    z[3,2,6]  R947      7.4481196701526642e-02
    z[3,2,6]  R948      -1.8555977940559387e-01
    z[3,2,6]  R949      1.0878256708383560e-01
    z[3,2,6]  R950      2.2727511823177338e-02
    z[3,2,6]  R951      -1.7764264345169067e-01
    z[3,2,6]  R952      3.2427048683166504e-01
    z[3,2,6]  R953      3.8796347379684448e-01
    z[3,2,6]  R954      2.9086786508560181e-01
    z[3,2,6]  R955      5.3685763850808144e-03
    z[3,2,6]  R956      4.7650119662284851e-01
    z[3,2,6]  R957      1.9865010678768158e-01
    z[3,2,6]  R958      8.7767750024795532e-02
    z[3,2,6]  R959      7.5500112771987915e-01
    z[3,2,6]  R960      -2.2788988426327705e-02
    z[3,2,6]  R961      -5.5582004785537720e-01
    z[3,2,6]  R962      -3.8580577820539474e-02
    z[3,2,6]  R963      -1.2512862682342529e-01
    z[3,2,6]  R964      1.8459033966064453e-01
    z[3,2,6]  R965      1.6274780035018921e-01
    z[3,2,6]  R966      1.2327576428651810e-01
    z[3,2,6]  R967      -1.0316102951765060e-01
    z[3,2,6]  R968      1.7142336070537567e-01
    z[3,2,6]  R969      -1.6085078939795494e-02
    z[3,2,6]  R970      -4.6470880508422852e-02
    z[3,2,6]  R971      1.5468142926692963e-02
    z[3,2,6]  R972      1.5896968543529510e-01
    z[3,2,6]  R973      5.0948962569236755e-02
    z[3,2,6]  R974      8.9596778154373169e-02
    z[3,2,6]  R975      1.1430647969245911e-01
    z[3,2,6]  R976      2.1785560250282288e-01
    z[3,2,6]  R977      1.8165364861488342e-01
    z[3,2,6]  R978      2.8705176711082458e-01
    z[3,2,6]  R979      -1.0856804251670837e-01
    z[3,2,6]  R980      -1.2562349438667297e-01
    z[3,2,6]  R981      2.7592003345489502e-02
    z[3,2,6]  R982      -0.145661860704422
    z[3,2,6]  R983      2.5001093745231628e-01
    z[3,2,6]  R984      -1.5254151821136475e-01
    z[3,2,6]  R985      -0.0850839912891388
    z[3,2,6]  R986      -0.560992419719696
    z[3,2,6]  R987      2.0289690792560577e-01
    z[3,2,6]  R988      2.9001367092132568e-01
    z[3,2,6]  R989      5.1871906965970993e-02
    z[3,2,6]  R990      4.8334410786628723e-01
    z[3,2,6]  R991      -5.3901600837707520e-01
    z[3,2,6]  R992      1.5751791000366211e-01
    z[3,2,6]  R993      2.2093172371387482e-01
    z[3,2,6]  R994      -8.7031356990337372e-02
    z[3,2,6]  R995      -3.7781888246536255e-01
    z[3,2,6]  R996      -5.3689569234848022e-02
    z[3,2,6]  R997      2.2673925757408142e-01
    z[3,2,6]  R998      3.9606702327728271e-01
    z[3,2,6]  R999      4.1313868761062622e-01
    z[3,2,6]  R1000     -7.8150011599063873e-02
    z[3,2,6]  R1001     -3.9280518889427185e-02
    z[3,2,6]  R1002     1.1420807242393494e-01
    z[3,2,6]  R1003     -8.6310803890228271e-02
    z[3,2,6]  R1004     -1.9005009904503822e-02
    z[3,2,6]  R1005     -3.6157715320587158e-01
    z[3,2,6]  R1006     -2.1683798730373383e-01
    z[3,2,6]  R1007     3.4990105032920837e-01
    z[3,2,6]  R1008     5.6830104440450668e-02
    z[3,2,6]  R1009     2.1327154338359833e-01
    z[3,2,6]  R1010     -1.5577603876590729e-01
    z[3,2,6]  R1011     -3.4625567495822906e-02
    z[3,2,6]  R1012     -1.4220872521400452e-01
    z[3,2,6]  R1013     9.6423342823982239e-02
    z[3,2,6]  R1014     -1.7282311618328094e-01
    z[3,2,6]  R1015     -0.378086119890213
    z[3,2,6]  R1016     3.4706908464431763e-01
    z[3,2,6]  R1017     1.7097742855548859e-01
    z[3,2,6]  R1018     -3.1044816970825195e-01
    z[3,2,6]  R1019     -3.2080981135368347e-01
    z[3,2,6]  R1020     -2.1905763447284698e-01
    z[3,2,6]  R1021     7.9345032572746277e-02
    z[3,2,6]  R1022     9.0372875332832336e-02
    z[3,2,6]  R1023     -1.0624471306800842e-01
    z[3,2,6]  R1024     -7.1111850440502167e-02
    z[3,2,6]  R1025     -1.3775345683097839e-01
    z[3,2,6]  R1026     -3.3822375535964966e-01
    z[3,2,6]  R1027     2.3188921809196472e-01
    z[3,2,6]  R1028     -2.0261134207248688e-01
    z[3,2,6]  R1029     0.531879723072052
    z[3,2,6]  R1030     3.3505034446716309e-01
    z[3,2,6]  R1031     4.0646219253540039e-01
    z[3,2,6]  R1032     -1.4600698649883270e-01
    z[3,2,6]  R1033     -2.6989373564720154e-01
    z[3,2,6]  R1034     -4.0338656306266785e-01
    z[3,2,6]  R1035     -3.4699743986129761e-01
    z[3,2,6]  R1036     -5.8023977279663086e-01
    z[3,2,6]  R1037     -2.7896949648857117e-01
    z[3,2,6]  R1038     2.6502072811126709e-02
    z[3,2,6]  R1039     -5.0369039177894592e-02
    z[3,2,6]  R1040     5.6097096204757690e-01
    z[3,2,6]  R1041     8.5996669530868530e-01
    z[3,2,6]  R1042     2.4351125955581665e-01
    z[3,2,6]  R1043     1.1492806673049927e-01
    z[3,2,6]  R1044     2.9832544922828674e-01
    z[3,2,6]  R1045     -1.0901782661676407e-01
    z[3,2,6]  R1046     2.0039934664964676e-02
    z[3,2,6]  R1047     6.2712259590625763e-02
    z[3,2,6]  R1048     2.9676163196563721e-01
    z[3,2,6]  R1049     -4.8904288560152054e-02
    z[3,2,6]  R1050     -4.3316057324409485e-01
    z[3,2,6]  R1051     7.7260947227478027e-01
    z[3,2,6]  R1052     3.7654605507850647e-01
    z[3,2,6]  R1053     -8.4765374660491943e-02
    z[3,2,6]  R1054     -7.4907653033733368e-03
    z[3,2,6]  R1055     4.4425830245018005e-01
    z[3,2,6]  R1056     1.0980103164911270e-01
    z[3,2,6]  R1057     -0.080394446849823
    z[3,2,6]  R1058     -2.1295015513896942e-01
    z[3,2,6]  R1059     -3.3506935834884644e-01
    z[3,2,6]  R1060     3.4158456325531006e-01
    z[3,2,6]  R1061     -9.6297636628150940e-02
    z[3,2,6]  R1062     -1.9954350590705872e-01
    z[3,2,6]  R1063     2.0679706335067749e-01
    z[3,2,6]  R1064     -1.9330868124961853e-01
    z[3,2,6]  R1065     5.5426204204559326e-01
    z[3,2,6]  R1066     3.5914307832717896e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1067     -1
    z[3,7,0]  R1068     1
    z[3,7,0]  R1081     7.3081964254379272e-01
    z[3,7,0]  R1082     7.5236237049102783e-01
    z[3,7,0]  R1083     6.4019095897674561e-01
    z[3,7,0]  R1084     7.5551462173461914e-01
    z[3,7,0]  R1085     7.9268425703048706e-01
    z[3,7,0]  R1086     5.8187460899353027e-01
    z[3,7,0]  R1087     7.8306490182876587e-01
    z[3,7,0]  R1088     7.6801878213882446e-01
    z[3,7,0]  R1089     -1.7464710399508476e-02
    z[3,7,0]  R1090     -5.1970733329653740e-04
    z[3,7,0]  R1091     -3.7451930344104767e-02
    z[3,7,0]  R1092     -1.7085577547550201e-01
    z[3,7,0]  R1093     -1.3820216059684753e-01
    z[3,7,0]  R1094     -2.9620608687400818e-01
    z[3,7,0]  R1095     -3.9036303758621216e-01
    z[3,7,0]  R1096     -1.3025595247745514e-01
    z[3,7,0]  R1097     -8.9698553085327148e-02
    z[3,7,0]  R1098     -0.651669979095459
    z[3,7,0]  R1099     -5.4056859016418457e-01
    z[3,7,0]  R1100     -3.8065171241760254e-01
    z[3,7,0]  R1101     6.7949414253234863e-02
    z[3,7,0]  R1102     -5.3215283155441284e-01
    z[3,7,0]  R1103     -3.6922167986631393e-02
    z[3,7,0]  R1104     -3.3193930983543396e-01
    z[3,7,0]  R1105     -9.1507446765899658e-01
    z[3,7,0]  R1106     -9.1097509860992432e-01
    z[3,7,0]  R1107     -3.6560615897178650e-01
    z[3,7,0]  R1108     2.1802823990583420e-02
    z[3,7,0]  R1109     -8.8899797201156616e-01
    z[3,7,0]  R1110     -8.7273043394088745e-01
    z[3,7,0]  R1111     -4.3535541743040085e-02
    z[3,7,0]  R1112     6.1079227924346924e-01
    z[3,7,0]  R1113     -2.8745830059051514e-01
    z[3,7,0]  R1114     -6.3473924994468689e-02
    z[3,7,0]  R1115     2.5515419244766235e-01
    z[3,7,0]  R1116     -3.7279021739959717e-01
    z[3,7,0]  R1117     -6.3946500420570374e-02
    z[3,7,0]  R1118     1.7163048684597015e-01
    z[3,7,0]  R1119     -3.3679354190826416e-01
    z[3,7,0]  R1120     -6.0315674543380737e-01
    z[3,7,0]  R1121     -4.9866211414337158e-01
    z[3,7,0]  R1122     5.8716970682144165e-01
    z[3,7,0]  R1123     2.4355675280094147e-01
    z[3,7,0]  R1124     -9.8377957940101624e-02
    z[3,7,0]  R1125     -9.1336077451705933e-01
    z[3,7,0]  R1126     -2.0049074292182922e-01
    z[3,7,0]  R1127     -0.793777346611023
    z[3,7,0]  R1128     -1.3446946442127228e-01
    z[3,7,0]  R1129     -7.6299661397933960e-01
    z[3,7,0]  R1130     -2.5040575861930847e-01
    z[3,7,0]  R1131     -4.8506896942853928e-02
    z[3,7,0]  R1132     3.9443102478981018e-01
    z[3,7,0]  R1133     -3.4812141209840775e-02
    z[3,7,0]  R1134     -6.8137490749359131e-01
    z[3,7,0]  R1135     -4.9739876389503479e-01
    z[3,7,0]  R1136     -7.7618694305419922e-01
    z[3,7,0]  R1137     -8.8468819856643677e-01
    z[3,7,0]  R1138     -8.9799350500106812e-01
    z[3,7,0]  R1139     -3.6623382568359375e-01
    z[3,7,0]  R1140     -8.2222521305084229e-01
    z[3,7,0]  R1141     -9.5417900010943413e-03
    z[3,7,0]  R1142     -5.6352788209915161e-01
    z[3,7,0]  R1143     -0.457535058259964
    z[3,7,0]  R1144     -4.6804243326187134e-01
    z[3,7,0]  R1145     -5.3360491991043091e-01
    z[3,7,0]  R1146     -9.5024204254150391e-01
    z[3,7,0]  R1147     -9.2259037494659424e-01
    z[3,7,0]  R1148     -8.5279864072799683e-01
    z[3,7,0]  R1149     -4.1459599137306213e-01
    z[3,7,0]  R1150     -1.6792495548725128e-01
    z[3,7,0]  R1151     -4.4118997454643250e-01
    z[3,7,0]  R1152     -5.4312908649444580e-01
    z[3,7,0]  R1153     -2.4107502773404121e-02
    z[3,7,0]  R1154     -4.8570921644568443e-03
    z[3,7,0]  R1155     -5.8970987796783447e-01
    z[3,7,0]  R1156     4.0796521306037903e-01
    z[3,7,0]  R1157     -8.3640134334564209e-01
    z[3,7,0]  R1158     -7.5629872083663940e-01
    z[3,7,0]  R1159     -2.3148091509938240e-02
    z[3,7,0]  R1160     -5.3866463899612427e-01
    z[3,7,0]  R1161     1.6193255782127380e-01
    z[3,7,0]  R1162     4.9023322761058807e-02
    z[3,7,0]  R1163     9.2316336929798126e-02
    z[3,7,0]  R1164     -9.0431171655654907e-01
    z[3,7,0]  R1165     -8.4467101097106934e-01
    z[3,7,0]  R1166     -3.7108820676803589e-01
    z[3,7,0]  R1167     -3.4779664874076843e-01
    z[3,7,0]  R1168     -1.0684672743082047e-01
    z[3,7,0]  R1169     -1.9758220016956329e-01
    z[3,7,0]  R1170     -5.0120222568511963e-01
    z[3,7,0]  R1171     3.2902139425277710e-01
    z[3,7,0]  R1172     3.8526329398155212e-01
    z[3,7,0]  R1173     -6.9628250598907471e-01
    z[3,7,0]  R1174     -9.1065317392349243e-01
    z[3,7,0]  R1175     -8.7985646724700928e-01
    z[3,7,0]  R1176     -8.5753923654556274e-01
    z[3,7,0]  R1177     -5.2138119935989380e-01
    z[3,7,0]  R1178     -0.281818151473999
    z[3,7,0]  R1179     -4.4188895821571350e-01
    z[3,7,0]  R1180     -4.0765147656202316e-02
    z[3,7,0]  R1181     6.5578132867813110e-01
    z[3,7,0]  R1182     5.6253653764724731e-01
    z[3,7,0]  R1183     3.7063813209533691e-01
    z[3,7,0]  R1184     2.3754149675369263e-01
    z[3,7,0]  R1185     -0.138264000415802
    z[3,7,0]  R1186     -1.8511675298213959e-01
    z[3,7,0]  R1187     -4.6320948004722595e-01
    z[3,7,0]  R1188     -3.7512639164924622e-01
    z[3,7,0]  R1189     -4.1988947987556458e-01
    z[3,7,0]  R1190     -0.35318723320961
    z[3,7,0]  R1191     -0.421892911195755
    z[3,7,0]  R1192     -1.8761147558689117e-01
    z[3,7,0]  R1193     -5.7019978761672974e-01
    z[3,7,0]  R1194     5.4557597637176514e-01
    z[3,7,0]  R1195     4.3389233946800232e-01
    z[3,7,0]  R1196     -4.4840371608734131e-01
    z[3,7,0]  R1197     -3.5936030745506287e-01
    z[3,7,0]  R1198     -5.6440997123718262e-01
    z[3,7,0]  R1199     -6.0405993461608887e-01
    z[3,7,0]  R1200     -2.4745118618011475e-01
    z[3,7,0]  R1201     4.6661216020584106e-01
    z[3,7,0]  R1202     6.2787905335426331e-02
    z[3,7,0]  R1203     -3.2162716984748840e-01
    z[3,7,0]  R1204     4.1591387242078781e-02
    z[3,7,0]  R1205     -2.3878654837608337e-01
    z[3,7,0]  R1206     5.1987826824188232e-01
    z[3,7,0]  R1207     -2.7496299147605896e-01
    z[3,7,0]  R1208     5.0926379859447479e-02
    z[3,7,0]  R1209     -1.8982946872711182e-01
    z[3,7,0]  R1210     -2.6450318098068237e-01
    z[3,7,0]  R1211     0.367813378572464
    z[3,7,0]  R1212     5.8785051107406616e-01
    z[3,7,0]  R1213     -2.0450721681118011e-01
    z[3,7,0]  R1214     -5.3593933582305908e-01
    z[3,7,0]  R1215     -0.239603653550148
    z[3,7,0]  R1216     -1.3740982115268707e-01
    z[3,7,0]  R1217     2.0276165008544922e-01
    z[3,7,0]  R1218     -1.6038633882999420e-01
    z[3,7,0]  R1219     -1.2973412871360779e-01
    z[3,7,0]  R1220     -3.3333939313888550e-01
    z[3,7,0]  R1221     5.7482933998107910e-01
    z[3,7,0]  R1222     -3.9732262492179871e-01
    z[3,7,0]  R1223     -3.3347824215888977e-01
    z[3,7,0]  R1224     -1.0597234219312668e-01
    z[3,7,0]  R1225     -4.5789030194282532e-01
    z[3,7,0]  R1226     -1.2106350809335709e-01
    z[3,7,0]  R1227     -7.2929584980010986e-01
    z[3,7,0]  R1228     -5.4588454961776733e-01
    z[3,7,0]  R1229     -6.7704671621322632e-01
    z[3,7,0]  R1230     -4.2286023497581482e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1069     -1
    z[3,7,1]  R1070     1
    z[3,7,1]  R1081     1.3711350969970226e-02
    z[3,7,1]  R1082     5.4299894720315933e-02
    z[3,7,1]  R1083     2.4019737541675568e-01
    z[3,7,1]  R1084     3.7223255634307861e-01
    z[3,7,1]  R1085     2.8006935119628906e-01
    z[3,7,1]  R1086     3.9857888221740723e-01
    z[3,7,1]  R1087     4.2062580585479736e-01
    z[3,7,1]  R1088     -2.2349764406681061e-01
    z[3,7,1]  R1089     7.9020828008651733e-01
    z[3,7,1]  R1090     7.2798633575439453e-01
    z[3,7,1]  R1091     7.1584838628768921e-01
    z[3,7,1]  R1092     -2.1504734456539154e-01
    z[3,7,1]  R1093     6.5834307670593262e-01
    z[3,7,1]  R1094     6.4349353313446045e-01
    z[3,7,1]  R1095     8.0013543367385864e-02
    z[3,7,1]  R1096     5.5630236864089966e-01
    z[3,7,1]  R1097     5.1694333553314209e-01
    z[3,7,1]  R1098     1.1657485365867615e-01
    z[3,7,1]  R1099     1.8256975710391998e-01
    z[3,7,1]  R1100     0.0415816530585289
    z[3,7,1]  R1101     2.3756314814090729e-01
    z[3,7,1]  R1102     -2.9377132654190063e-02
    z[3,7,1]  R1103     -5.2666097879409790e-01
    z[3,7,1]  R1104     5.0524920225143433e-01
    z[3,7,1]  R1105     1.1464839428663254e-01
    z[3,7,1]  R1106     -1.9159886986017227e-02
    z[3,7,1]  R1107     4.8104834556579590e-01
    z[3,7,1]  R1108     4.5014080405235291e-01
    z[3,7,1]  R1109     -6.3170604407787323e-02
    z[3,7,1]  R1110     2.7494031190872192e-01
    z[3,7,1]  R1111     4.4470425695180893e-02
    z[3,7,1]  R1112     -9.6938237547874451e-03
    z[3,7,1]  R1113     4.1444137692451477e-01
    z[3,7,1]  R1114     5.4111951589584351e-01
    z[3,7,1]  R1115     0.627250611782074
    z[3,7,1]  R1116     5.6994384527206421e-01
    z[3,7,1]  R1117     -4.6652853488922119e-01
    z[3,7,1]  R1118     -5.2630335092544556e-01
    z[3,7,1]  R1119     4.4160258769989014e-01
    z[3,7,1]  R1120     -5.4234772920608521e-01
    z[3,7,1]  R1121     6.7723000049591064e-01
    z[3,7,1]  R1122     -4.7758162021636963e-02
    z[3,7,1]  R1123     -5.6062698364257812e-01
    z[3,7,1]  R1124     4.3963938951492310e-01
    z[3,7,1]  R1125     -1.6114315390586853e-01
    z[3,7,1]  R1126     -9.4882321357727051e-01
    z[3,7,1]  R1127     4.0067046880722046e-02
    z[3,7,1]  R1128     -9.2889207601547241e-01
    z[3,7,1]  R1129     -2.3473416268825531e-01
    z[3,7,1]  R1130     -9.0752846002578735e-01
    z[3,7,1]  R1131     7.4260032176971436e-01
    z[3,7,1]  R1132     -6.6749060153961182e-01
    z[3,7,1]  R1133     -4.7623196244239807e-01
    z[3,7,1]  R1134     6.0549920797348022e-01
    z[3,7,1]  R1135     4.7995755076408386e-01
    z[3,7,1]  R1136     -4.0013200044631958e-01
    z[3,7,1]  R1137     7.1967437863349915e-02
    z[3,7,1]  R1138     -8.7360413745045662e-03
    z[3,7,1]  R1139     6.3114196062088013e-02
    z[3,7,1]  R1140     6.9946028292179108e-02
    z[3,7,1]  R1141     7.9096013307571411e-01
    z[3,7,1]  R1142     6.5089470148086548e-01
    z[3,7,1]  R1143     5.2843958139419556e-01
    z[3,7,1]  R1144     1.1336542665958405e-01
    z[3,7,1]  R1145     5.1968789100646973e-01
    z[3,7,1]  R1146     -4.5264068990945816e-02
    z[3,7,1]  R1147     -5.3006079047918320e-02
    z[3,7,1]  R1148     2.8267037868499756e-01
    z[3,7,1]  R1149     1.7081966996192932e-01
    z[3,7,1]  R1150     -8.8181960582733154e-01
    z[3,7,1]  R1151     6.4701217412948608e-01
    z[3,7,1]  R1152     -1.5277132391929626e-01
    z[3,7,1]  R1153     5.6754022836685181e-01
    z[3,7,1]  R1154     1.6682486236095428e-01
    z[3,7,1]  R1155     1.8880617618560791e-01
    z[3,7,1]  R1156     0.492443710565567
    z[3,7,1]  R1157     -2.4261765182018280e-01
    z[3,7,1]  R1158     1.0084971785545349e-01
    z[3,7,1]  R1159     -8.7758040428161621e-01
    z[3,7,1]  R1160     -3.5370045900344849e-01
    z[3,7,1]  R1161     7.1731823682785034e-01
    z[3,7,1]  R1162     5.5955308675765991e-01
    z[3,7,1]  R1163     -1.5039165318012238e-01
    z[3,7,1]  R1164     -2.1676853299140930e-01
    z[3,7,1]  R1165     1.5709306299686432e-01
    z[3,7,1]  R1166     -6.6963976621627808e-01
    z[3,7,1]  R1167     -5.3933167457580566e-01
    z[3,7,1]  R1168     -7.8680831193923950e-01
    z[3,7,1]  R1169     -4.8667269945144653e-01
    z[3,7,1]  R1170     -5.3156054019927979e-01
    z[3,7,1]  R1171     6.9027435779571533e-01
    z[3,7,1]  R1172     -1.5281352400779724e-01
    z[3,7,1]  R1173     0.324432373046875
    z[3,7,1]  R1174     4.5422129333019257e-02
    z[3,7,1]  R1175     -2.6522394269704819e-02
    z[3,7,1]  R1176     1.5438407659530640e-01
    z[3,7,1]  R1177     -0.581614077091217
    z[3,7,1]  R1178     -5.1495635509490967e-01
    z[3,7,1]  R1179     -1.3446459174156189e-01
    z[3,7,1]  R1180     -5.9460699558258057e-01
    z[3,7,1]  R1181     1.1435882002115250e-01
    z[3,7,1]  R1182     4.0142297744750977e-01
    z[3,7,1]  R1183     7.6485341787338257e-01
    z[3,7,1]  R1184     5.3542929887771606e-01
    z[3,7,1]  R1185     7.8002071380615234e-01
    z[3,7,1]  R1186     1.3832345604896545e-01
    z[3,7,1]  R1187     -4.7877561300992966e-02
    z[3,7,1]  R1188     -6.3829831779003143e-02
    z[3,7,1]  R1189     3.1923419237136841e-01
    z[3,7,1]  R1190     2.3087453842163086e-01
    z[3,7,1]  R1191     -2.1191075444221497e-01
    z[3,7,1]  R1192     -5.8906716108322144e-01
    z[3,7,1]  R1193     -5.2865590900182724e-02
    z[3,7,1]  R1194     -4.4142669439315796e-01
    z[3,7,1]  R1195     -7.1289384365081787e-01
    z[3,7,1]  R1196     -5.0402671098709106e-01
    z[3,7,1]  R1197     -7.4249184131622314e-01
    z[3,7,1]  R1198     -5.9427630901336670e-01
    z[3,7,1]  R1199     -4.1634941101074219e-01
    z[3,7,1]  R1200     -0.832743227481842
    z[3,7,1]  R1201     -2.4929188191890717e-01
    z[3,7,1]  R1202     1.9046372175216675e-01
    z[3,7,1]  R1203     -1.8191392719745636e-01
    z[3,7,1]  R1204     -1.6768236458301544e-01
    z[3,7,1]  R1205     -0.133817657828331
    z[3,7,1]  R1206     -1.0523710399866104e-01
    z[3,7,1]  R1207     -9.5723263919353485e-02
    z[3,7,1]  R1208     -0.186284601688385
    z[3,7,1]  R1209     -4.1939345002174377e-01
    z[3,7,1]  R1210     -3.8949453830718994e-01
    z[3,7,1]  R1211     2.4423290044069290e-02
    z[3,7,1]  R1212     -4.4574740529060364e-01
    z[3,7,1]  R1213     -4.0387764573097229e-01
    z[3,7,1]  R1214     -2.6248106360435486e-01
    z[3,7,1]  R1215     -4.1414785385131836e-01
    z[3,7,1]  R1216     -1.8218639492988586e-01
    z[3,7,1]  R1217     -1.4169288624543697e-04
    z[3,7,1]  R1218     6.4466185867786407e-02
    z[3,7,1]  R1219     -1.2670651078224182e-01
    z[3,7,1]  R1220     -1.5292043983936310e-01
    z[3,7,1]  R1221     0.437441885471344
    z[3,7,1]  R1222     -2.9498405754566193e-02
    z[3,7,1]  R1223     -2.9368460178375244e-01
    z[3,7,1]  R1224     1.3990128040313721e-01
    z[3,7,1]  R1225     -2.5596305727958679e-01
    z[3,7,1]  R1226     1.6905392706394196e-01
    z[3,7,1]  R1227     -2.0205664634704590e-01
    z[3,7,1]  R1228     4.3392226099967957e-01
    z[3,7,1]  R1229     1.8731987476348877e-01
    z[3,7,1]  R1230     4.3244999647140503e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1071     -1
    z[3,7,2]  R1072     1
    z[3,7,2]  R1081     0.388574481010437
    z[3,7,2]  R1082     2.4980668723583221e-01
    z[3,7,2]  R1083     6.0219585895538330e-01
    z[3,7,2]  R1084     3.8829341530799866e-01
    z[3,7,2]  R1085     1.6707780957221985e-01
    z[3,7,2]  R1086     4.4926857948303223e-01
    z[3,7,2]  R1087     3.8597890734672546e-01
    z[3,7,2]  R1088     1.4168396592140198e-01
    z[3,7,2]  R1089     0.345490425825119
    z[3,7,2]  R1090     5.9946954250335693e-01
    z[3,7,2]  R1091     -4.6438673138618469e-01
    z[3,7,2]  R1092     -0.453572154045105
    z[3,7,2]  R1093     -2.5681027770042419e-01
    z[3,7,2]  R1094     -6.0514993965625763e-02
    z[3,7,2]  R1095     -3.0757537484169006e-01
    z[3,7,2]  R1096     -1.1456935852766037e-01
    z[3,7,2]  R1097     -2.6502177119255066e-01
    z[3,7,2]  R1098     -3.3766967058181763e-01
    z[3,7,2]  R1099     -2.5241887569427490e-01
    z[3,7,2]  R1100     2.2210665047168732e-01
    z[3,7,2]  R1101     -4.0944731235504150e-01
    z[3,7,2]  R1102     6.3712793588638306e-01
    z[3,7,2]  R1103     -6.7614391446113586e-02
    z[3,7,2]  R1104     2.8389924764633179e-01
    z[3,7,2]  R1105     -2.0516772568225861e-01
    z[3,7,2]  R1106     -7.7193580567836761e-02
    z[3,7,2]  R1107     1.2833668291568756e-01
    z[3,7,2]  R1108     -4.6638140082359314e-01
    z[3,7,2]  R1109     3.0287280678749084e-01
    z[3,7,2]  R1110     2.8450208902359009e-01
    z[3,7,2]  R1111     3.0728485435247421e-02
    z[3,7,2]  R1112     1.0896039195358753e-02
    z[3,7,2]  R1113     1.4771074056625366e-01
    z[3,7,2]  R1114     4.6055087447166443e-01
    z[3,7,2]  R1115     -4.0463727712631226e-01
    z[3,7,2]  R1116     2.0238615572452545e-02
    z[3,7,2]  R1117     5.5145698785781860e-01
    z[3,7,2]  R1118     5.6918853521347046e-01
    z[3,7,2]  R1119     -5.7994669675827026e-01
    z[3,7,2]  R1120     2.2485144436359406e-01
    z[3,7,2]  R1121     -2.5433886051177979e-01
    z[3,7,2]  R1122     4.7333080321550369e-02
    z[3,7,2]  R1123     5.2712643146514893e-01
    z[3,7,2]  R1124     -3.9871567487716675e-01
    z[3,7,2]  R1125     -1.4094695448875427e-01
    z[3,7,2]  R1126     6.4704142510890961e-02
    z[3,7,2]  R1127     -3.2439496368169785e-02
    z[3,7,2]  R1128     3.1068574637174606e-02
    z[3,7,2]  R1129     1.6097691655158997e-01
    z[3,7,2]  R1130     2.4971139430999756e-01
    z[3,7,2]  R1131     6.2799811363220215e-02
    z[3,7,2]  R1132     1.2318023294210434e-01
    z[3,7,2]  R1133     0.424014687538147
    z[3,7,2]  R1134     0.0715944841504097
    z[3,7,2]  R1135     -2.9453590512275696e-01
    z[3,7,2]  R1136     7.6235704123973846e-02
    z[3,7,2]  R1137     1.3002495467662811e-01
    z[3,7,2]  R1138     -1.7952781915664673e-01
    z[3,7,2]  R1139     -0.280814528465271
    z[3,7,2]  R1140     2.7645226567983627e-02
    z[3,7,2]  R1141     -1.2493391335010529e-01
    z[3,7,2]  R1142     1.9838419556617737e-01
    z[3,7,2]  R1143     -0.488179087638855
    z[3,7,2]  R1144     -2.6554372906684875e-01
    z[3,7,2]  R1145     3.6922845244407654e-01
    z[3,7,2]  R1146     -0.0339483805000782
    z[3,7,2]  R1147     1.3924182951450348e-01
    z[3,7,2]  R1148     1.7402195930480957e-01
    z[3,7,2]  R1149     -1.2328878045082092e-01
    z[3,7,2]  R1150     -5.0941850990056992e-02
    z[3,7,2]  R1151     4.4459328055381775e-02
    z[3,7,2]  R1152     5.5610740184783936e-01
    z[3,7,2]  R1153     -1.8911378085613251e-01
    z[3,7,2]  R1154     -1.1785674095153809e-01
    z[3,7,2]  R1155     -2.0113836228847504e-01
    z[3,7,2]  R1156     -5.2802842855453491e-01
    z[3,7,2]  R1157     -5.6183699518442154e-02
    z[3,7,2]  R1158     3.6028262972831726e-01
    z[3,7,2]  R1159     -4.0361863374710083e-01
    z[3,7,2]  R1160     -6.0564011335372925e-01
    z[3,7,2]  R1161     1.1743155121803284e-01
    z[3,7,2]  R1162     -2.8917932510375977e-01
    z[3,7,2]  R1163     -1.1606529355049133e-01
    z[3,7,2]  R1164     -9.5972500275820494e-04
    z[3,7,2]  R1165     -1.6278178989887238e-01
    z[3,7,2]  R1166     -4.5483973622322083e-01
    z[3,7,2]  R1167     -4.7846508026123047e-01
    z[3,7,2]  R1168     2.9979849234223366e-02
    z[3,7,2]  R1169     -4.4776901602745056e-01
    z[3,7,2]  R1170     -3.7698981165885925e-01
    z[3,7,2]  R1171     -4.9701115489006042e-01
    z[3,7,2]  R1172     -2.9945635795593262e-01
    z[3,7,2]  R1173     -2.0904821157455444e-01
    z[3,7,2]  R1174     1.8929970264434814e-01
    z[3,7,2]  R1175     1.1313340812921524e-01
    z[3,7,2]  R1176     -1.4072303473949432e-01
    z[3,7,2]  R1177     -2.4279899895191193e-01
    z[3,7,2]  R1178     -5.3732901811599731e-01
    z[3,7,2]  R1179     -0.518753707408905
    z[3,7,2]  R1180     -6.6158592700958252e-01
    z[3,7,2]  R1181     -3.3604586124420166e-01
    z[3,7,2]  R1182     -8.9773915708065033e-02
    z[3,7,2]  R1183     -2.6283088326454163e-01
    z[3,7,2]  R1184     -2.2129869461059570e-01
    z[3,7,2]  R1185     3.8711285591125488e-01
    z[3,7,2]  R1186     7.2691243886947632e-01
    z[3,7,2]  R1187     4.8589169979095459e-01
    z[3,7,2]  R1188     7.5987368822097778e-01
    z[3,7,2]  R1189     3.2897848635911942e-02
    z[3,7,2]  R1190     -8.8280633091926575e-02
    z[3,7,2]  R1191     4.2452374100685120e-01
    z[3,7,2]  R1192     -4.1473528742790222e-01
    z[3,7,2]  R1193     4.7904092073440552e-01
    z[3,7,2]  R1194     -3.3625373244285583e-01
    z[3,7,2]  R1195     -1.5323549509048462e-01
    z[3,7,2]  R1196     -2.1477967500686646e-01
    z[3,7,2]  R1197     -4.4494945555925369e-02
    z[3,7,2]  R1198     -4.4417638331651688e-02
    z[3,7,2]  R1199     5.2536106109619141e-01
    z[3,7,2]  R1200     -3.5484644770622253e-01
    z[3,7,2]  R1201     9.7630776464939117e-02
    z[3,7,2]  R1202     4.0585052967071533e-01
    z[3,7,2]  R1203     -2.9736492037773132e-01
    z[3,7,2]  R1204     6.2986373901367188e-01
    z[3,7,2]  R1205     2.7783477306365967e-01
    z[3,7,2]  R1206     -2.5348627567291260e-01
    z[3,7,2]  R1207     7.6207816600799561e-01
    z[3,7,2]  R1208     0.831156849861145
    z[3,7,2]  R1209     6.1910808086395264e-01
    z[3,7,2]  R1210     7.5966519117355347e-01
    z[3,7,2]  R1211     3.1685021519660950e-01
    z[3,7,2]  R1212     -3.6706620454788208e-01
    z[3,7,2]  R1213     -4.2125180363655090e-01
    z[3,7,2]  R1214     5.5523318052291870e-01
    z[3,7,2]  R1215     0.807011067867279
    z[3,7,2]  R1216     8.4683841466903687e-01
    z[3,7,2]  R1217     8.7419945001602173e-01
    z[3,7,2]  R1218     9.5148253440856934e-01
    z[3,7,2]  R1219     9.5361477136611938e-01
    z[3,7,2]  R1220     8.5782015323638916e-01
    z[3,7,2]  R1221     -3.0486200004816055e-02
    z[3,7,2]  R1222     -1.1528084427118301e-01
    z[3,7,2]  R1223     7.4738597869873047e-01
    z[3,7,2]  R1224     7.1247100830078125e-01
    z[3,7,2]  R1225     3.2485216856002808e-01
    z[3,7,2]  R1226     6.8495023250579834e-01
    z[3,7,2]  R1227     1.1261721700429916e-01
    z[3,7,2]  R1228     6.6891357302665710e-02
    z[3,7,2]  R1229     9.6072681248188019e-02
    z[3,7,2]  R1230     2.4772010743618011e-02
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1073     -1
    z[3,7,3]  R1074     1
    z[3,7,3]  R1081     -2.1983437240123749e-01
    z[3,7,3]  R1082     -3.3784502744674683e-01
    z[3,7,3]  R1083     -2.1890088915824890e-01
    z[3,7,3]  R1084     1.0547752678394318e-01
    z[3,7,3]  R1085     3.8617804646492004e-02
    z[3,7,3]  R1086     -2.0519154146313667e-02
    z[3,7,3]  R1087     3.8928262889385223e-02
    z[3,7,3]  R1088     -3.7719801068305969e-01
    z[3,7,3]  R1089     -2.8920945525169373e-01
    z[3,7,3]  R1090     -2.4688212573528290e-01
    z[3,7,3]  R1091     2.2081515192985535e-01
    z[3,7,3]  R1092     5.5929505825042725e-01
    z[3,7,3]  R1093     2.4585790932178497e-01
    z[3,7,3]  R1094     6.1227369308471680e-01
    z[3,7,3]  R1095     -8.4651607275009155e-01
    z[3,7,3]  R1096     3.4073927998542786e-01
    z[3,7,3]  R1097     6.9690680503845215e-01
    z[3,7,3]  R1098     -5.2825736999511719e-01
    z[3,7,3]  R1099     -4.5570856332778931e-01
    z[3,7,3]  R1100     1.1839376389980316e-01
    z[3,7,3]  R1101     8.2410866022109985e-01
    z[3,7,3]  R1102     3.8797068595886230e-01
    z[3,7,3]  R1103     2.3541538417339325e-01
    z[3,7,3]  R1104     3.8441452383995056e-01
    z[3,7,3]  R1105     1.0509452782571316e-02
    z[3,7,3]  R1106     -1.1293182522058487e-01
    z[3,7,3]  R1107     2.7240052819252014e-01
    z[3,7,3]  R1108     -2.9375419020652771e-01
    z[3,7,3]  R1109     -4.5824725180864334e-02
    z[3,7,3]  R1110     1.9795901607722044e-03
    z[3,7,3]  R1111     6.7289197444915771e-01
    z[3,7,3]  R1112     6.0950154066085815e-01
    z[3,7,3]  R1113     4.7397544980049133e-01
    z[3,7,3]  R1114     4.8006868362426758e-01
    z[3,7,3]  R1115     2.0311798900365829e-02
    z[3,7,3]  R1116     -4.1097089648246765e-01
    z[3,7,3]  R1117     4.3353244662284851e-01
    z[3,7,3]  R1118     3.1306838989257812e-01
    z[3,7,3]  R1119     -3.0565026402473450e-01
    z[3,7,3]  R1120     2.4861592054367065e-01
    z[3,7,3]  R1121     8.8877469301223755e-02
    z[3,7,3]  R1122     -1.5399585664272308e-01
    z[3,7,3]  R1123     4.1052162647247314e-01
    z[3,7,3]  R1124     -2.8152248263359070e-01
    z[3,7,3]  R1125     7.5641043484210968e-02
    z[3,7,3]  R1126     -9.4083890318870544e-02
    z[3,7,3]  R1127     3.7302400916814804e-02
    z[3,7,3]  R1128     -6.9526262581348419e-02
    z[3,7,3]  R1129     -3.0936279892921448e-01
    z[3,7,3]  R1130     5.2418440580368042e-02
    z[3,7,3]  R1131     3.3702442049980164e-01
    z[3,7,3]  R1132     5.6980293989181519e-01
    z[3,7,3]  R1133     4.3843919038772583e-01
    z[3,7,3]  R1134     -3.5689270496368408e-01
    z[3,7,3]  R1135     -2.8074812889099121e-01
    z[3,7,3]  R1136     3.2118624448776245e-01
    z[3,7,3]  R1137     -3.9957201480865479e-01
    z[3,7,3]  R1138     2.8057834506034851e-01
    z[3,7,3]  R1139     -0.649041473865509
    z[3,7,3]  R1140     -9.9989846348762512e-02
    z[3,7,3]  R1141     1.8089847872033715e-03
    z[3,7,3]  R1142     8.7370024994015694e-04
    z[3,7,3]  R1143     -3.8883021473884583e-01
    z[3,7,3]  R1144     -6.4202928543090820e-01
    z[3,7,3]  R1145     2.5093883275985718e-01
    z[3,7,3]  R1146     1.7347642779350281e-01
    z[3,7,3]  R1147     -1.0311586409807205e-01
    z[3,7,3]  R1148     -1.5421982109546661e-01
    z[3,7,3]  R1149     -4.7485277056694031e-01
    z[3,7,3]  R1150     -3.8497611880302429e-01
    z[3,7,3]  R1151     -3.3683210611343384e-01
    z[3,7,3]  R1152     3.6364433169364929e-01
    z[3,7,3]  R1153     2.2673273086547852e-01
    z[3,7,3]  R1154     0.277258962392807
    z[3,7,3]  R1155     -5.7367360591888428e-01
    z[3,7,3]  R1156     8.6202420294284821e-02
    z[3,7,3]  R1157     -3.1494984030723572e-01
    z[3,7,3]  R1158     -1.5366628766059875e-01
    z[3,7,3]  R1159     -1.6533143818378448e-01
    z[3,7,3]  R1160     2.4333539605140686e-01
    z[3,7,3]  R1161     -4.1196337342262268e-01
    z[3,7,3]  R1162     5.6809765100479126e-01
    z[3,7,3]  R1163     -3.2596006989479065e-02
    z[3,7,3]  R1164     -2.0463606715202332e-01
    z[3,7,3]  R1165     -2.2062188386917114e-01
    z[3,7,3]  R1166     -4.1860058903694153e-01
    z[3,7,3]  R1167     -4.4509038329124451e-02
    z[3,7,3]  R1168     -3.3235767483711243e-01
    z[3,7,3]  R1169     -2.3991049826145172e-01
    z[3,7,3]  R1170     -3.9578244090080261e-01
    z[3,7,3]  R1171     -1.1740065366029739e-01
    z[3,7,3]  R1172     4.9503996968269348e-01
    z[3,7,3]  R1173     -5.5340075492858887e-01
    z[3,7,3]  R1174     -3.4102407097816467e-01
    z[3,7,3]  R1175     1.7385666072368622e-01
    z[3,7,3]  R1176     -2.4025362730026245e-01
    z[3,7,3]  R1177     -3.6551502346992493e-01
    z[3,7,3]  R1178     1.0349040478467941e-01
    z[3,7,3]  R1179     -1.5072527341544628e-02
    z[3,7,3]  R1180     1.3338880613446236e-02
    z[3,7,3]  R1181     1.7860975861549377e-01
    z[3,7,3]  R1182     3.2187944650650024e-01
    z[3,7,3]  R1183     1.0834605433046818e-02
    z[3,7,3]  R1184     3.2391202449798584e-01
    z[3,7,3]  R1185     2.0039199292659760e-01
    z[3,7,3]  R1186     1.2313036620616913e-01
    z[3,7,3]  R1187     -1.6694139689207077e-02
    z[3,7,3]  R1188     1.9584544003009796e-01
    z[3,7,3]  R1189     -7.0980352163314819e-01
    z[3,7,3]  R1190     -7.1118837594985962e-01
    z[3,7,3]  R1191     -2.2603254020214081e-01
    z[3,7,3]  R1192     -5.7955193519592285e-01
    z[3,7,3]  R1193     -1.2480422854423523e-01
    z[3,7,3]  R1194     -2.7611499652266502e-02
    z[3,7,3]  R1195     1.1606021970510483e-01
    z[3,7,3]  R1196     -0.664367139339447
    z[3,7,3]  R1197     -4.7494283318519592e-01
    z[3,7,3]  R1198     -4.8844027519226074e-01
    z[3,7,3]  R1199     -1.0250040888786316e-01
    z[3,7,3]  R1200     4.6880498528480530e-02
    z[3,7,3]  R1201     1.5337735414505005e-01
    z[3,7,3]  R1202     6.7403799295425415e-01
    z[3,7,3]  R1203     -3.1837800145149231e-01
    z[3,7,3]  R1204     -4.4210964441299438e-01
    z[3,7,3]  R1205     -3.6278063058853149e-01
    z[3,7,3]  R1206     4.9592819809913635e-01
    z[3,7,3]  R1207     1.2239511311054230e-01
    z[3,7,3]  R1208     2.6496684551239014e-01
    z[3,7,3]  R1209     0.199748694896698
    z[3,7,3]  R1210     3.2743549346923828e-01
    z[3,7,3]  R1211     7.1964037418365479e-01
    z[3,7,3]  R1212     2.1272291243076324e-01
    z[3,7,3]  R1213     -5.7984054088592529e-01
    z[3,7,3]  R1214     -4.1433432698249817e-01
    z[3,7,3]  R1215     1.1915339529514313e-01
    z[3,7,3]  R1216     -1.1254362016916275e-01
    z[3,7,3]  R1217     2.7752781286835670e-02
    z[3,7,3]  R1218     9.9605210125446320e-03
    z[3,7,3]  R1219     -1.5184667706489563e-01
    z[3,7,3]  R1220     -1.8563267588615417e-01
    z[3,7,3]  R1221     3.1545478105545044e-01
    z[3,7,3]  R1222     -2.9333594441413879e-01
    z[3,7,3]  R1223     1.9253598153591156e-01
    z[3,7,3]  R1224     -1.1768083274364471e-01
    z[3,7,3]  R1225     0.0886588916182518
    z[3,7,3]  R1226     -3.5248023271560669e-01
    z[3,7,3]  R1227     -2.3124119639396667e-01
    z[3,7,3]  R1228     -6.5944540500640869e-01
    z[3,7,3]  R1229     -6.8610537052154541e-01
    z[3,7,3]  R1230     -7.5621813535690308e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1075     -1
    z[3,7,4]  R1076     1
    z[3,7,4]  R1081     3.6975425481796265e-01
    z[3,7,4]  R1082     0.0836007222533226
    z[3,7,4]  R1083     2.7925944328308105e-01
    z[3,7,4]  R1084     1.6411504149436951e-01
    z[3,7,4]  R1085     -1.3834075629711151e-01
    z[3,7,4]  R1086     9.8664209246635437e-02
    z[3,7,4]  R1087     -1.6533695161342621e-01
    z[3,7,4]  R1088     -2.0861823856830597e-01
    z[3,7,4]  R1089     -2.3871515691280365e-01
    z[3,7,4]  R1090     -6.3319101929664612e-02
    z[3,7,4]  R1091     4.0838193893432617e-01
    z[3,7,4]  R1092     -1.8973509967327118e-01
    z[3,7,4]  R1093     3.4369704127311707e-01
    z[3,7,4]  R1094     -1.2840871512889862e-01
    z[3,7,4]  R1095     2.6399930939078331e-02
    z[3,7,4]  R1096     -2.5398489832878113e-01
    z[3,7,4]  R1097     -1.4980722218751907e-02
    z[3,7,4]  R1098     2.6581141352653503e-01
    z[3,7,4]  R1099     -5.2717506885528564e-01
    z[3,7,4]  R1100     -2.4696613848209381e-01
    z[3,7,4]  R1101     -2.6409873366355896e-01
    z[3,7,4]  R1102     -2.9159709811210632e-01
    z[3,7,4]  R1103     -4.9763542413711548e-01
    z[3,7,4]  R1104     -2.1162109076976776e-01
    z[3,7,4]  R1105     -3.0046626925468445e-01
    z[3,7,4]  R1106     -1.0412283986806870e-01
    z[3,7,4]  R1107     1.2374614179134369e-01
    z[3,7,4]  R1108     -5.5735909938812256e-01
    z[3,7,4]  R1109     -2.5431391596794128e-01
    z[3,7,4]  R1110     2.7516716718673706e-01
    z[3,7,4]  R1111     1.2355333566665649e-01
    z[3,7,4]  R1112     -3.3346304297447205e-01
    z[3,7,4]  R1113     -0.394437313079834
    z[3,7,4]  R1114     -2.4966441094875336e-01
    z[3,7,4]  R1115     3.9922407269477844e-01
    z[3,7,4]  R1116     4.2915868759155273e-01
    z[3,7,4]  R1117     1.0579667240381241e-01
    z[3,7,4]  R1118     -0.181906595826149
    z[3,7,4]  R1119     -7.3114745318889618e-02
    z[3,7,4]  R1120     -1.4692904055118561e-01
    z[3,7,4]  R1121     -4.5659685134887695e-01
    z[3,7,4]  R1122     1.6165295243263245e-01
    z[3,7,4]  R1123     -1.6063414514064789e-01
    z[3,7,4]  R1124     -4.8005864024162292e-01
    z[3,7,4]  R1125     3.8883373141288757e-02
    z[3,7,4]  R1126     1.1996621638536453e-01
    z[3,7,4]  R1127     3.7625020742416382e-01
    z[3,7,4]  R1128     3.4751359373331070e-02
    z[3,7,4]  R1129     4.7478446364402771e-01
    z[3,7,4]  R1130     -1.5053851902484894e-01
    z[3,7,4]  R1131     -2.2645914554595947e-01
    z[3,7,4]  R1132     -5.7060797698795795e-03
    z[3,7,4]  R1133     -7.6822616159915924e-02
    z[3,7,4]  R1134     2.1029409021139145e-02
    z[3,7,4]  R1135     1.8492749333381653e-01
    z[3,7,4]  R1136     -1.1500279605388641e-01
    z[3,7,4]  R1137     6.0783304274082184e-02
    z[3,7,4]  R1138     7.0928357541561127e-02
    z[3,7,4]  R1139     -0.42122882604599
    z[3,7,4]  R1140     1.3787874579429626e-01
    z[3,7,4]  R1141     2.6096263527870178e-01
    z[3,7,4]  R1142     -0.16848124563694
    z[3,7,4]  R1143     3.8658101111650467e-02
    z[3,7,4]  R1144     -4.1916516423225403e-01
    z[3,7,4]  R1145     4.3393567204475403e-01
    z[3,7,4]  R1146     2.7704099193215370e-02
    z[3,7,4]  R1147     3.0394849181175232e-01
    z[3,7,4]  R1148     -2.5828543305397034e-01
    z[3,7,4]  R1149     3.7149384617805481e-01
    z[3,7,4]  R1150     4.7176092863082886e-02
    z[3,7,4]  R1151     -2.7131193876266479e-01
    z[3,7,4]  R1152     -2.9805478453636169e-01
    z[3,7,4]  R1153     -6.0237679630517960e-02
    z[3,7,4]  R1154     -6.2752211093902588e-01
    z[3,7,4]  R1155     1.4327786862850189e-01
    z[3,7,4]  R1156     -4.9175915122032166e-01
    z[3,7,4]  R1157     -9.4972558319568634e-02
    z[3,7,4]  R1158     9.8763778805732727e-02
    z[3,7,4]  R1159     -1.2358006834983826e-01
    z[3,7,4]  R1160     8.0499485135078430e-02
    z[3,7,4]  R1161     2.8234642744064331e-01
    z[3,7,4]  R1162     9.6305571496486664e-02
    z[3,7,4]  R1163     -7.1907705068588257e-01
    z[3,7,4]  R1164     -1.6345153562724590e-03
    z[3,7,4]  R1165     -2.5797012448310852e-01
    z[3,7,4]  R1166     -1.1582937091588974e-01
    z[3,7,4]  R1167     2.3507069051265717e-01
    z[3,7,4]  R1168     -1.5902440249919891e-01
    z[3,7,4]  R1169     -1.6797071322798729e-02
    z[3,7,4]  R1170     1.1166515201330185e-01
    z[3,7,4]  R1171     -2.2787198424339294e-01
    z[3,7,4]  R1172     -1.4868468046188354e-01
    z[3,7,4]  R1173     -3.1543251127004623e-02
    z[3,7,4]  R1174     4.9308642745018005e-02
    z[3,7,4]  R1175     3.4621319174766541e-01
    z[3,7,4]  R1176     -2.5849640369415283e-01
    z[3,7,4]  R1177     2.3924781382083893e-01
    z[3,7,4]  R1178     1.4420378953218460e-02
    z[3,7,4]  R1179     -0.0878065750002861
    z[3,7,4]  R1180     4.0671084076166153e-02
    z[3,7,4]  R1181     1.6010291874408722e-02
    z[3,7,4]  R1182     -1.0964769870042801e-01
    z[3,7,4]  R1183     2.1156449615955353e-01
    z[3,7,4]  R1184     0.655748188495636
    z[3,7,4]  R1185     -1.4161817729473114e-01
    z[3,7,4]  R1186     6.3251096010208130e-01
    z[3,7,4]  R1187     3.9920559525489807e-01
    z[3,7,4]  R1188     -6.1699371784925461e-02
    z[3,7,4]  R1189     3.5262140631675720e-01
    z[3,7,4]  R1190     -2.7352491393685341e-02
    z[3,7,4]  R1191     3.0771702527999878e-01
    z[3,7,4]  R1192     0.307492196559906
    z[3,7,4]  R1193     4.6538379788398743e-01
    z[3,7,4]  R1194     -2.9700118303298950e-01
    z[3,7,4]  R1195     -3.9172884821891785e-01
    z[3,7,4]  R1196     2.1518760919570923e-01
    z[3,7,4]  R1197     -1.0180468112230301e-01
    z[3,7,4]  R1198     2.2309435904026031e-01
    z[3,7,4]  R1199     -0.0850767120718956
    z[3,7,4]  R1200     -1.1955167353153229e-01
    z[3,7,4]  R1201     -8.1110924482345581e-01
    z[3,7,4]  R1202     -1.0898580402135849e-01
    z[3,7,4]  R1203     5.5226337909698486e-01
    z[3,7,4]  R1204     4.8057359457015991e-01
    z[3,7,4]  R1205     7.1364927291870117e-01
    z[3,7,4]  R1206     2.6871958374977112e-01
    z[3,7,4]  R1207     5.2876341342926025e-01
    z[3,7,4]  R1208     1.1409211903810501e-01
    z[3,7,4]  R1209     2.6202520728111267e-01
    z[3,7,4]  R1210     2.4984866380691528e-01
    z[3,7,4]  R1211     -3.6618936061859131e-01
    z[3,7,4]  R1212     -1.6661860048770905e-02
    z[3,7,4]  R1213     4.3248176574707031e-01
    z[3,7,4]  R1214     2.5308316946029663e-01
    z[3,7,4]  R1215     2.0223341882228851e-01
    z[3,7,4]  R1216     3.3913221955299377e-01
    z[3,7,4]  R1217     3.0128675699234009e-01
    z[3,7,4]  R1218     1.3564477860927582e-01
    z[3,7,4]  R1219     -2.7488607913255692e-02
    z[3,7,4]  R1220     4.8106640577316284e-02
    z[3,7,4]  R1221     -3.4481963515281677e-01
    z[3,7,4]  R1222     -2.0610374212265015e-01
    z[3,7,4]  R1223     2.7970704436302185e-01
    z[3,7,4]  R1224     5.1321285963058472e-01
    z[3,7,4]  R1225     6.8382078409194946e-01
    z[3,7,4]  R1226     7.9613149166107178e-02
    z[3,7,4]  R1227     5.0367474555969238e-01
    z[3,7,4]  R1228     -1.6412030905485153e-02
    z[3,7,4]  R1229     5.0547290593385696e-02
    z[3,7,4]  R1230     -2.2112096846103668e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1077     -1
    z[3,7,5]  R1078     1
    z[3,7,5]  R1081     3.3980527520179749e-01
    z[3,7,5]  R1082     0.486115425825119
    z[3,7,5]  R1083     9.7025007009506226e-02
    z[3,7,5]  R1084     2.9867282509803772e-01
    z[3,7,5]  R1085     4.1259261965751648e-01
    z[3,7,5]  R1086     4.1188114881515503e-01
    z[3,7,5]  R1087     -0.074520044028759
    z[3,7,5]  R1088     -1.9655311107635498e-01
    z[3,7,5]  R1089     -2.0525650680065155e-01
    z[3,7,5]  R1090     0.0744505226612091
    z[3,7,5]  R1091     -9.6932850778102875e-02
    z[3,7,5]  R1092     -6.0361623764038086e-01
    z[3,7,5]  R1093     2.6354864239692688e-01
    z[3,7,5]  R1094     2.4786043167114258e-01
    z[3,7,5]  R1095     1.6977612674236298e-01
    z[3,7,5]  R1096     -9.4695478677749634e-02
    z[3,7,5]  R1097     -2.2654792666435242e-01
    z[3,7,5]  R1098     -2.9492089152336121e-01
    z[3,7,5]  R1099     3.2390865683555603e-01
    z[3,7,5]  R1100     -8.4928011894226074e-01
    z[3,7,5]  R1101     -1.0813717544078827e-01
    z[3,7,5]  R1102     -2.7280244231224060e-01
    z[3,7,5]  R1103     -4.6663495898246765e-01
    z[3,7,5]  R1104     -5.3795474767684937e-01
    z[3,7,5]  R1105     -1.1047238111495972e-01
    z[3,7,5]  R1106     1.4906586706638336e-01
    z[3,7,5]  R1107     -7.2340106964111328e-01
    z[3,7,5]  R1108     0.17389015853405
    z[3,7,5]  R1109     1.3917692005634308e-01
    z[3,7,5]  R1110     -2.3230737075209618e-02
    z[3,7,5]  R1111     -7.0192688703536987e-01
    z[3,7,5]  R1112     -3.6358866095542908e-01
    z[3,7,5]  R1113     -5.8569401502609253e-01
    z[3,7,5]  R1114     -4.0828722715377808e-01
    z[3,7,5]  R1115     3.3582428097724915e-01
    z[3,7,5]  R1116     1.7942123115062714e-01
    z[3,7,5]  R1117     -4.3635964393615723e-01
    z[3,7,5]  R1118     -4.8830467462539673e-01
    z[3,7,5]  R1119     -1.7145806550979614e-01
    z[3,7,5]  R1120     -4.1066142916679382e-01
    z[3,7,5]  R1121     6.2644377350807190e-02
    z[3,7,5]  R1122     -1.7560601234436035e-01
    z[3,7,5]  R1123     -0.392000675201416
    z[3,7,5]  R1124     1.3934718072414398e-01
    z[3,7,5]  R1125     -3.3349204063415527e-01
    z[3,7,5]  R1126     -1.2825973331928253e-01
    z[3,7,5]  R1127     4.3615409731864929e-01
    z[3,7,5]  R1128     2.9254710674285889e-01
    z[3,7,5]  R1129     -0.0223592147231102
    z[3,7,5]  R1130     1.2361817806959152e-01
    z[3,7,5]  R1131     4.9798870086669922e-01
    z[3,7,5]  R1132     -0.242364302277565
    z[3,7,5]  R1133     -6.2602925300598145e-01
    z[3,7,5]  R1134     1.8952375650405884e-01
    z[3,7,5]  R1135     -5.4515582323074341e-01
    z[3,7,5]  R1136     -3.3561038970947266e-01
    z[3,7,5]  R1137     1.5446986258029938e-01
    z[3,7,5]  R1138     2.5392949581146240e-01
    z[3,7,5]  R1139     -3.6997672915458679e-01
    z[3,7,5]  R1140     5.0624340772628784e-01
    z[3,7,5]  R1141     4.5626637339591980e-01
    z[3,7,5]  R1142     4.2337018251419067e-01
    z[3,7,5]  R1143     -3.2346537709236145e-01
    z[3,7,5]  R1144     -3.3001348376274109e-01
    z[3,7,5]  R1145     -1.9071669876575470e-01
    z[3,7,5]  R1146     -2.1720662713050842e-02
    z[3,7,5]  R1147     1.8512552604079247e-02
    z[3,7,5]  R1148     2.5458592176437378e-01
    z[3,7,5]  R1149     3.2484656572341919e-01
    z[3,7,5]  R1150     9.8366884049028158e-04
    z[3,7,5]  R1151     3.3701050281524658e-01
    z[3,7,5]  R1152     -3.8555371761322021e-01
    z[3,7,5]  R1153     -5.9404969215393066e-01
    z[3,7,5]  R1154     -4.4391539692878723e-01
    z[3,7,5]  R1155     -4.4910570979118347e-01
    z[3,7,5]  R1156     -1.1908382177352905e-01
    z[3,7,5]  R1157     -3.5017880797386169e-01
    z[3,7,5]  R1158     -3.3454936742782593e-01
    z[3,7,5]  R1159     -1.4463682472705841e-01
    z[3,7,5]  R1160     3.1754285097122192e-01
    z[3,7,5]  R1161     -1.9783751666545868e-01
    z[3,7,5]  R1162     -3.1333526968955994e-01
    z[3,7,5]  R1163     -6.5661799907684326e-01
    z[3,7,5]  R1164     -0.303000271320343
    z[3,7,5]  R1165     3.2724419236183167e-01
    z[3,7,5]  R1166     1.0442462563514709e-01
    z[3,7,5]  R1167     5.4920810461044312e-01
    z[3,7,5]  R1168     3.1957671046257019e-01
    z[3,7,5]  R1169     6.4711350202560425e-01
    z[3,7,5]  R1170     1.8048487603664398e-01
    z[3,7,5]  R1171     -3.1513166427612305e-01
    z[3,7,5]  R1172     -6.5260219573974609e-01
    z[3,7,5]  R1173     -1.8633204698562622e-01
    z[3,7,5]  R1174     -1.1351475864648819e-01
    z[3,7,5]  R1175     -2.0502893626689911e-01
    z[3,7,5]  R1176     2.9521077871322632e-01
    z[3,7,5]  R1177     3.3200421929359436e-01
    z[3,7,5]  R1178     0.461311936378479
    z[3,7,5]  R1179     6.2382197380065918e-01
    z[3,7,5]  R1180     4.1954675316810608e-01
    z[3,7,5]  R1181     6.1092805862426758e-01
    z[3,7,5]  R1182     0.305328369140625
    z[3,7,5]  R1183     -3.2644817233085632e-01
    z[3,7,5]  R1184     2.7013307809829712e-01
    z[3,7,5]  R1185     3.8586756587028503e-01
    z[3,7,5]  R1186     -1.1724155396223068e-02
    z[3,7,5]  R1187     -5.4554667323827744e-02
    z[3,7,5]  R1188     -1.7589065432548523e-01
    z[3,7,5]  R1189     7.0996925234794617e-02
    z[3,7,5]  R1190     4.9334344267845154e-01
    z[3,7,5]  R1191     -0.647737979888916
    z[3,7,5]  R1192     2.6006600819528103e-03
    z[3,7,5]  R1193     -3.1988570094108582e-01
    z[3,7,5]  R1194     -5.3647315502166748e-01
    z[3,7,5]  R1195     -3.3451077342033386e-01
    z[3,7,5]  R1196     3.8160249590873718e-02
    z[3,7,5]  R1197     0.247584730386734
    z[3,7,5]  R1198     1.7031347751617432e-01
    z[3,7,5]  R1199     -3.9729550480842590e-01
    z[3,7,5]  R1200     2.6620325446128845e-01
    z[3,7,5]  R1201     -9.6859313547611237e-02
    z[3,7,5]  R1202     3.9680776000022888e-01
    z[3,7,5]  R1203     3.8803797960281372e-01
    z[3,7,5]  R1204     -3.6811605095863342e-01
    z[3,7,5]  R1205     -4.5355820655822754e-01
    z[3,7,5]  R1206     -3.7679061293601990e-01
    z[3,7,5]  R1207     -9.9245734512805939e-02
    z[3,7,5]  R1208     -3.6069911718368530e-01
    z[3,7,5]  R1209     -4.9722501635551453e-01
    z[3,7,5]  R1210     -6.0913139022886753e-03
    z[3,7,5]  R1211     -3.0868908762931824e-01
    z[3,7,5]  R1212     -2.5204730033874512e-01
    z[3,7,5]  R1213     2.2183644771575928e-01
    z[3,7,5]  R1214     -2.9326236248016357e-01
    z[3,7,5]  R1215     -2.0866183936595917e-01
    z[3,7,5]  R1216     -9.8147220909595490e-02
    z[3,7,5]  R1217     -2.2753703594207764e-01
    z[3,7,5]  R1218     -2.1214932203292847e-01
    z[3,7,5]  R1219     -1.6605599224567413e-01
    z[3,7,5]  R1220     -1.2479253858327866e-01
    z[3,7,5]  R1221     -5.0345528125762939e-01
    z[3,7,5]  R1222     0.754705548286438
    z[3,7,5]  R1223     -2.9630449414253235e-01
    z[3,7,5]  R1224     -3.5210517048835754e-01
    z[3,7,5]  R1225     -2.0151783525943756e-01
    z[3,7,5]  R1226     -5.6089985370635986e-01
    z[3,7,5]  R1227     -1.1960883438587189e-01
    z[3,7,5]  R1228     -2.6464805006980896e-01
    z[3,7,5]  R1229     -6.1810355633497238e-02
    z[3,7,5]  R1230     -4.4104088097810745e-02
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1079     -1
    z[3,7,6]  R1080     1
    z[3,7,6]  R1081     -1.1921192705631256e-01
    z[3,7,6]  R1082     -1.0565267503261566e-01
    z[3,7,6]  R1083     -1.8575143814086914e-01
    z[3,7,6]  R1084     -1.1226785928010941e-01
    z[3,7,6]  R1085     -2.7282893657684326e-01
    z[3,7,6]  R1086     -3.4772503376007080e-01
    z[3,7,6]  R1087     -1.6278398036956787e-01
    z[3,7,6]  R1088     -3.4013012051582336e-01
    z[3,7,6]  R1089     -2.7045345306396484e-01
    z[3,7,6]  R1090     2.0042194426059723e-01
    z[3,7,6]  R1091     -2.1347667276859283e-01
    z[3,7,6]  R1092     7.5314551591873169e-02
    z[3,7,6]  R1093     4.8321974277496338e-01
    z[3,7,6]  R1094     2.0423837006092072e-01
    z[3,7,6]  R1095     -2.2396599873900414e-02
    z[3,7,6]  R1096     6.8618965148925781e-01
    z[3,7,6]  R1097     3.4243202209472656e-01
    z[3,7,6]  R1098     -1.0500402003526688e-01
    z[3,7,6]  R1099     1.4225970208644867e-01
    z[3,7,6]  R1100     -8.8078305125236511e-02
    z[3,7,6]  R1101     1.0345313698053360e-01
    z[3,7,6]  R1102     -6.8595241755247116e-03
    z[3,7,6]  R1103     -4.4258746504783630e-01
    z[3,7,6]  R1104     -2.6830476522445679e-01
    z[3,7,6]  R1105     6.9326788187026978e-02
    z[3,7,6]  R1106     -3.4348601102828979e-01
    z[3,7,6]  R1107     0.0750337466597557
    z[3,7,6]  R1108     0.390138179063797
    z[3,7,6]  R1109     1.6677644848823547e-01
    z[3,7,6]  R1110     7.4481196701526642e-02
    z[3,7,6]  R1111     -1.8555977940559387e-01
    z[3,7,6]  R1112     1.0878256708383560e-01
    z[3,7,6]  R1113     2.2727511823177338e-02
    z[3,7,6]  R1114     -1.7764264345169067e-01
    z[3,7,6]  R1115     3.2427048683166504e-01
    z[3,7,6]  R1116     3.8796347379684448e-01
    z[3,7,6]  R1117     2.9086786508560181e-01
    z[3,7,6]  R1118     5.3685763850808144e-03
    z[3,7,6]  R1119     4.7650119662284851e-01
    z[3,7,6]  R1120     1.9865010678768158e-01
    z[3,7,6]  R1121     8.7767750024795532e-02
    z[3,7,6]  R1122     7.5500112771987915e-01
    z[3,7,6]  R1123     -2.2788988426327705e-02
    z[3,7,6]  R1124     -5.5582004785537720e-01
    z[3,7,6]  R1125     -3.8580577820539474e-02
    z[3,7,6]  R1126     -1.2512862682342529e-01
    z[3,7,6]  R1127     1.8459033966064453e-01
    z[3,7,6]  R1128     1.6274780035018921e-01
    z[3,7,6]  R1129     1.2327576428651810e-01
    z[3,7,6]  R1130     -1.0316102951765060e-01
    z[3,7,6]  R1131     1.7142336070537567e-01
    z[3,7,6]  R1132     -1.6085078939795494e-02
    z[3,7,6]  R1133     -4.6470880508422852e-02
    z[3,7,6]  R1134     1.5468142926692963e-02
    z[3,7,6]  R1135     1.5896968543529510e-01
    z[3,7,6]  R1136     5.0948962569236755e-02
    z[3,7,6]  R1137     8.9596778154373169e-02
    z[3,7,6]  R1138     1.1430647969245911e-01
    z[3,7,6]  R1139     2.1785560250282288e-01
    z[3,7,6]  R1140     1.8165364861488342e-01
    z[3,7,6]  R1141     2.8705176711082458e-01
    z[3,7,6]  R1142     -1.0856804251670837e-01
    z[3,7,6]  R1143     -1.2562349438667297e-01
    z[3,7,6]  R1144     2.7592003345489502e-02
    z[3,7,6]  R1145     -0.145661860704422
    z[3,7,6]  R1146     2.5001093745231628e-01
    z[3,7,6]  R1147     -1.5254151821136475e-01
    z[3,7,6]  R1148     -0.0850839912891388
    z[3,7,6]  R1149     -0.560992419719696
    z[3,7,6]  R1150     2.0289690792560577e-01
    z[3,7,6]  R1151     2.9001367092132568e-01
    z[3,7,6]  R1152     5.1871906965970993e-02
    z[3,7,6]  R1153     4.8334410786628723e-01
    z[3,7,6]  R1154     -5.3901600837707520e-01
    z[3,7,6]  R1155     1.5751791000366211e-01
    z[3,7,6]  R1156     2.2093172371387482e-01
    z[3,7,6]  R1157     -8.7031356990337372e-02
    z[3,7,6]  R1158     -3.7781888246536255e-01
    z[3,7,6]  R1159     -5.3689569234848022e-02
    z[3,7,6]  R1160     2.2673925757408142e-01
    z[3,7,6]  R1161     3.9606702327728271e-01
    z[3,7,6]  R1162     4.1313868761062622e-01
    z[3,7,6]  R1163     -7.8150011599063873e-02
    z[3,7,6]  R1164     -3.9280518889427185e-02
    z[3,7,6]  R1165     1.1420807242393494e-01
    z[3,7,6]  R1166     -8.6310803890228271e-02
    z[3,7,6]  R1167     -1.9005009904503822e-02
    z[3,7,6]  R1168     -3.6157715320587158e-01
    z[3,7,6]  R1169     -2.1683798730373383e-01
    z[3,7,6]  R1170     3.4990105032920837e-01
    z[3,7,6]  R1171     5.6830104440450668e-02
    z[3,7,6]  R1172     2.1327154338359833e-01
    z[3,7,6]  R1173     -1.5577603876590729e-01
    z[3,7,6]  R1174     -3.4625567495822906e-02
    z[3,7,6]  R1175     -1.4220872521400452e-01
    z[3,7,6]  R1176     9.6423342823982239e-02
    z[3,7,6]  R1177     -1.7282311618328094e-01
    z[3,7,6]  R1178     -0.378086119890213
    z[3,7,6]  R1179     3.4706908464431763e-01
    z[3,7,6]  R1180     1.7097742855548859e-01
    z[3,7,6]  R1181     -1.9635464251041412e-01
    z[3,7,6]  R1182     -5.5271911621093750e-01
    z[3,7,6]  R1183     -2.3895850777626038e-01
    z[3,7,6]  R1184     4.4609103351831436e-03
    z[3,7,6]  R1185     -1.1613752692937851e-01
    z[3,7,6]  R1186     -5.3179364651441574e-02
    z[3,7,6]  R1187     -6.2002742290496826e-01
    z[3,7,6]  R1188     -4.5243588089942932e-01
    z[3,7,6]  R1189     -0.295798122882843
    z[3,7,6]  R1190     -2.5345128774642944e-01
    z[3,7,6]  R1191     1.7758010327816010e-01
    z[3,7,6]  R1192     1.2392652779817581e-01
    z[3,7,6]  R1193     -3.2880410552024841e-01
    z[3,7,6]  R1194     1.3284260034561157e-01
    z[3,7,6]  R1195     -0.0349249504506588
    z[3,7,6]  R1196     -9.8057381808757782e-02
    z[3,7,6]  R1197     -1.4266440272331238e-01
    z[3,7,6]  R1198     -9.4616673886775970e-02
    z[3,7,6]  R1199     1.0085908323526382e-01
    z[3,7,6]  R1200     1.7898587882518768e-01
    z[3,7,6]  R1201     1.4067785441875458e-01
    z[3,7,6]  R1202     4.1401076316833496e-01
    z[3,7,6]  R1203     4.6701654791831970e-01
    z[3,7,6]  R1204     1.0725246369838715e-01
    z[3,7,6]  R1205     3.5518039017915726e-02
    z[3,7,6]  R1206     4.4076108932495117e-01
    z[3,7,6]  R1207     1.7334438860416412e-01
    z[3,7,6]  R1208     2.4198049306869507e-01
    z[3,7,6]  R1209     2.2133606672286987e-01
    z[3,7,6]  R1210     1.7766645550727844e-01
    z[3,7,6]  R1211     -1.2828439474105835e-01
    z[3,7,6]  R1212     4.6037697792053223e-01
    z[3,7,6]  R1213     -2.1246072649955750e-01
    z[3,7,6]  R1214     -1.1773724108934402e-01
    z[3,7,6]  R1215     -1.4549601078033447e-01
    z[3,7,6]  R1216     -3.0574795603752136e-01
    z[3,7,6]  R1217     2.2659644484519958e-01
    z[3,7,6]  R1218     3.5989217460155487e-02
    z[3,7,6]  R1219     -7.9660356044769287e-02
    z[3,7,6]  R1220     -2.7802494168281555e-01
    z[3,7,6]  R1221     7.3532208800315857e-02
    z[3,7,6]  R1222     3.6037430167198181e-01
    z[3,7,6]  R1223     2.0212219655513763e-01
    z[3,7,6]  R1224     -2.4569953978061676e-01
    z[3,7,6]  R1225     3.2126274704933167e-01
    z[3,7,6]  R1226     -2.0595690608024597e-01
    z[3,7,6]  R1227     3.0520647764205933e-01
    z[3,7,6]  R1228     6.3805043697357178e-02
    z[3,7,6]  R1229     -1.4203125238418579e-01
    z[3,7,6]  R1230     1.0419698059558868e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1231     -1
    z[7,3,0]  R1232     1
    z[7,3,0]  R1245     6.5578132867813110e-01
    z[7,3,0]  R1246     5.6253653764724731e-01
    z[7,3,0]  R1247     3.7063813209533691e-01
    z[7,3,0]  R1248     2.3754149675369263e-01
    z[7,3,0]  R1249     -0.138264000415802
    z[7,3,0]  R1250     -1.8511675298213959e-01
    z[7,3,0]  R1251     -4.6320948004722595e-01
    z[7,3,0]  R1252     -3.7512639164924622e-01
    z[7,3,0]  R1253     -4.1988947987556458e-01
    z[7,3,0]  R1254     -0.35318723320961
    z[7,3,0]  R1255     -0.421892911195755
    z[7,3,0]  R1256     -1.8761147558689117e-01
    z[7,3,0]  R1257     -5.7019978761672974e-01
    z[7,3,0]  R1258     5.4557597637176514e-01
    z[7,3,0]  R1259     4.3389233946800232e-01
    z[7,3,0]  R1260     -4.4840371608734131e-01
    z[7,3,0]  R1261     -3.5936030745506287e-01
    z[7,3,0]  R1262     -5.6440997123718262e-01
    z[7,3,0]  R1263     -6.0405993461608887e-01
    z[7,3,0]  R1264     -2.4745118618011475e-01
    z[7,3,0]  R1265     4.6661216020584106e-01
    z[7,3,0]  R1266     6.2787905335426331e-02
    z[7,3,0]  R1267     -3.2162716984748840e-01
    z[7,3,0]  R1268     4.1591387242078781e-02
    z[7,3,0]  R1269     -2.3878654837608337e-01
    z[7,3,0]  R1270     5.1987826824188232e-01
    z[7,3,0]  R1271     -2.7496299147605896e-01
    z[7,3,0]  R1272     5.0926379859447479e-02
    z[7,3,0]  R1273     -1.8982946872711182e-01
    z[7,3,0]  R1274     -2.6450318098068237e-01
    z[7,3,0]  R1275     0.367813378572464
    z[7,3,0]  R1276     5.8785051107406616e-01
    z[7,3,0]  R1277     -2.0450721681118011e-01
    z[7,3,0]  R1278     -5.3593933582305908e-01
    z[7,3,0]  R1279     -0.239603653550148
    z[7,3,0]  R1280     -1.3740982115268707e-01
    z[7,3,0]  R1281     2.0276165008544922e-01
    z[7,3,0]  R1282     -1.6038633882999420e-01
    z[7,3,0]  R1283     -1.2973412871360779e-01
    z[7,3,0]  R1284     -3.3333939313888550e-01
    z[7,3,0]  R1285     5.7482933998107910e-01
    z[7,3,0]  R1286     -3.9732262492179871e-01
    z[7,3,0]  R1287     -3.3347824215888977e-01
    z[7,3,0]  R1288     -1.0597234219312668e-01
    z[7,3,0]  R1289     -4.5789030194282532e-01
    z[7,3,0]  R1290     -1.2106350809335709e-01
    z[7,3,0]  R1291     -7.2929584980010986e-01
    z[7,3,0]  R1292     -5.4588454961776733e-01
    z[7,3,0]  R1293     -6.7704671621322632e-01
    z[7,3,0]  R1294     -4.2286023497581482e-01
    z[7,3,0]  R1295     7.3081964254379272e-01
    z[7,3,0]  R1296     7.5236237049102783e-01
    z[7,3,0]  R1297     6.4019095897674561e-01
    z[7,3,0]  R1298     7.5551462173461914e-01
    z[7,3,0]  R1299     7.9268425703048706e-01
    z[7,3,0]  R1300     5.8187460899353027e-01
    z[7,3,0]  R1301     7.8306490182876587e-01
    z[7,3,0]  R1302     7.6801878213882446e-01
    z[7,3,0]  R1303     -1.7464710399508476e-02
    z[7,3,0]  R1304     -5.1970733329653740e-04
    z[7,3,0]  R1305     -3.7451930344104767e-02
    z[7,3,0]  R1306     -1.7085577547550201e-01
    z[7,3,0]  R1307     -1.3820216059684753e-01
    z[7,3,0]  R1308     -2.9620608687400818e-01
    z[7,3,0]  R1309     -3.9036303758621216e-01
    z[7,3,0]  R1310     -1.3025595247745514e-01
    z[7,3,0]  R1311     -8.9698553085327148e-02
    z[7,3,0]  R1312     -0.651669979095459
    z[7,3,0]  R1313     -5.4056859016418457e-01
    z[7,3,0]  R1314     -3.8065171241760254e-01
    z[7,3,0]  R1315     6.7949414253234863e-02
    z[7,3,0]  R1316     -5.3215283155441284e-01
    z[7,3,0]  R1317     -3.6922167986631393e-02
    z[7,3,0]  R1318     -3.3193930983543396e-01
    z[7,3,0]  R1319     -9.1507446765899658e-01
    z[7,3,0]  R1320     -9.1097509860992432e-01
    z[7,3,0]  R1321     -3.6560615897178650e-01
    z[7,3,0]  R1322     2.1802823990583420e-02
    z[7,3,0]  R1323     -8.8899797201156616e-01
    z[7,3,0]  R1324     -8.7273043394088745e-01
    z[7,3,0]  R1325     -4.3535541743040085e-02
    z[7,3,0]  R1326     6.1079227924346924e-01
    z[7,3,0]  R1327     -2.8745830059051514e-01
    z[7,3,0]  R1328     -6.3473924994468689e-02
    z[7,3,0]  R1329     2.5515419244766235e-01
    z[7,3,0]  R1330     -3.7279021739959717e-01
    z[7,3,0]  R1331     -6.3946500420570374e-02
    z[7,3,0]  R1332     1.7163048684597015e-01
    z[7,3,0]  R1333     -3.3679354190826416e-01
    z[7,3,0]  R1334     -6.0315674543380737e-01
    z[7,3,0]  R1335     -4.9866211414337158e-01
    z[7,3,0]  R1336     5.8716970682144165e-01
    z[7,3,0]  R1337     2.4355675280094147e-01
    z[7,3,0]  R1338     -9.8377957940101624e-02
    z[7,3,0]  R1339     -9.1336077451705933e-01
    z[7,3,0]  R1340     -2.0049074292182922e-01
    z[7,3,0]  R1341     -0.793777346611023
    z[7,3,0]  R1342     -1.3446946442127228e-01
    z[7,3,0]  R1343     -7.6299661397933960e-01
    z[7,3,0]  R1344     -2.5040575861930847e-01
    z[7,3,0]  R1345     -4.8506896942853928e-02
    z[7,3,0]  R1346     3.9443102478981018e-01
    z[7,3,0]  R1347     -3.4812141209840775e-02
    z[7,3,0]  R1348     -6.8137490749359131e-01
    z[7,3,0]  R1349     -4.9739876389503479e-01
    z[7,3,0]  R1350     -7.7618694305419922e-01
    z[7,3,0]  R1351     -8.8468819856643677e-01
    z[7,3,0]  R1352     -8.9799350500106812e-01
    z[7,3,0]  R1353     -3.6623382568359375e-01
    z[7,3,0]  R1354     -8.2222521305084229e-01
    z[7,3,0]  R1355     -9.5417900010943413e-03
    z[7,3,0]  R1356     -5.6352788209915161e-01
    z[7,3,0]  R1357     -0.457535058259964
    z[7,3,0]  R1358     -4.6804243326187134e-01
    z[7,3,0]  R1359     -5.3360491991043091e-01
    z[7,3,0]  R1360     -9.5024204254150391e-01
    z[7,3,0]  R1361     -9.2259037494659424e-01
    z[7,3,0]  R1362     -8.5279864072799683e-01
    z[7,3,0]  R1363     -4.1459599137306213e-01
    z[7,3,0]  R1364     -1.6792495548725128e-01
    z[7,3,0]  R1365     -4.4118997454643250e-01
    z[7,3,0]  R1366     -5.4312908649444580e-01
    z[7,3,0]  R1367     -2.4107502773404121e-02
    z[7,3,0]  R1368     -4.8570921644568443e-03
    z[7,3,0]  R1369     -5.8970987796783447e-01
    z[7,3,0]  R1370     4.0796521306037903e-01
    z[7,3,0]  R1371     -8.3640134334564209e-01
    z[7,3,0]  R1372     -7.5629872083663940e-01
    z[7,3,0]  R1373     -2.3148091509938240e-02
    z[7,3,0]  R1374     -5.3866463899612427e-01
    z[7,3,0]  R1375     1.6193255782127380e-01
    z[7,3,0]  R1376     4.9023322761058807e-02
    z[7,3,0]  R1377     9.2316336929798126e-02
    z[7,3,0]  R1378     -9.0431171655654907e-01
    z[7,3,0]  R1379     -8.4467101097106934e-01
    z[7,3,0]  R1380     -3.7108820676803589e-01
    z[7,3,0]  R1381     -3.4779664874076843e-01
    z[7,3,0]  R1382     -1.0684672743082047e-01
    z[7,3,0]  R1383     -1.9758220016956329e-01
    z[7,3,0]  R1384     -5.0120222568511963e-01
    z[7,3,0]  R1385     3.2902139425277710e-01
    z[7,3,0]  R1386     3.8526329398155212e-01
    z[7,3,0]  R1387     -6.9628250598907471e-01
    z[7,3,0]  R1388     -9.1065317392349243e-01
    z[7,3,0]  R1389     -8.7985646724700928e-01
    z[7,3,0]  R1390     -8.5753923654556274e-01
    z[7,3,0]  R1391     -5.2138119935989380e-01
    z[7,3,0]  R1392     -0.281818151473999
    z[7,3,0]  R1393     -4.4188895821571350e-01
    z[7,3,0]  R1394     -4.0765147656202316e-02
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1233     -1
    z[7,3,1]  R1234     1
    z[7,3,1]  R1245     1.1435882002115250e-01
    z[7,3,1]  R1246     4.0142297744750977e-01
    z[7,3,1]  R1247     7.6485341787338257e-01
    z[7,3,1]  R1248     5.3542929887771606e-01
    z[7,3,1]  R1249     7.8002071380615234e-01
    z[7,3,1]  R1250     1.3832345604896545e-01
    z[7,3,1]  R1251     -4.7877561300992966e-02
    z[7,3,1]  R1252     -6.3829831779003143e-02
    z[7,3,1]  R1253     3.1923419237136841e-01
    z[7,3,1]  R1254     2.3087453842163086e-01
    z[7,3,1]  R1255     -2.1191075444221497e-01
    z[7,3,1]  R1256     -5.8906716108322144e-01
    z[7,3,1]  R1257     -5.2865590900182724e-02
    z[7,3,1]  R1258     -4.4142669439315796e-01
    z[7,3,1]  R1259     -7.1289384365081787e-01
    z[7,3,1]  R1260     -5.0402671098709106e-01
    z[7,3,1]  R1261     -7.4249184131622314e-01
    z[7,3,1]  R1262     -5.9427630901336670e-01
    z[7,3,1]  R1263     -4.1634941101074219e-01
    z[7,3,1]  R1264     -0.832743227481842
    z[7,3,1]  R1265     -2.4929188191890717e-01
    z[7,3,1]  R1266     1.9046372175216675e-01
    z[7,3,1]  R1267     -1.8191392719745636e-01
    z[7,3,1]  R1268     -1.6768236458301544e-01
    z[7,3,1]  R1269     -0.133817657828331
    z[7,3,1]  R1270     -1.0523710399866104e-01
    z[7,3,1]  R1271     -9.5723263919353485e-02
    z[7,3,1]  R1272     -0.186284601688385
    z[7,3,1]  R1273     -4.1939345002174377e-01
    z[7,3,1]  R1274     -3.8949453830718994e-01
    z[7,3,1]  R1275     2.4423290044069290e-02
    z[7,3,1]  R1276     -4.4574740529060364e-01
    z[7,3,1]  R1277     -4.0387764573097229e-01
    z[7,3,1]  R1278     -2.6248106360435486e-01
    z[7,3,1]  R1279     -4.1414785385131836e-01
    z[7,3,1]  R1280     -1.8218639492988586e-01
    z[7,3,1]  R1281     -1.4169288624543697e-04
    z[7,3,1]  R1282     6.4466185867786407e-02
    z[7,3,1]  R1283     -1.2670651078224182e-01
    z[7,3,1]  R1284     -1.5292043983936310e-01
    z[7,3,1]  R1285     0.437441885471344
    z[7,3,1]  R1286     -2.9498405754566193e-02
    z[7,3,1]  R1287     -2.9368460178375244e-01
    z[7,3,1]  R1288     1.3990128040313721e-01
    z[7,3,1]  R1289     -2.5596305727958679e-01
    z[7,3,1]  R1290     1.6905392706394196e-01
    z[7,3,1]  R1291     -2.0205664634704590e-01
    z[7,3,1]  R1292     4.3392226099967957e-01
    z[7,3,1]  R1293     1.8731987476348877e-01
    z[7,3,1]  R1294     4.3244999647140503e-01
    z[7,3,1]  R1295     1.3711350969970226e-02
    z[7,3,1]  R1296     5.4299894720315933e-02
    z[7,3,1]  R1297     2.4019737541675568e-01
    z[7,3,1]  R1298     3.7223255634307861e-01
    z[7,3,1]  R1299     2.8006935119628906e-01
    z[7,3,1]  R1300     3.9857888221740723e-01
    z[7,3,1]  R1301     4.2062580585479736e-01
    z[7,3,1]  R1302     -2.2349764406681061e-01
    z[7,3,1]  R1303     7.9020828008651733e-01
    z[7,3,1]  R1304     7.2798633575439453e-01
    z[7,3,1]  R1305     7.1584838628768921e-01
    z[7,3,1]  R1306     -2.1504734456539154e-01
    z[7,3,1]  R1307     6.5834307670593262e-01
    z[7,3,1]  R1308     6.4349353313446045e-01
    z[7,3,1]  R1309     8.0013543367385864e-02
    z[7,3,1]  R1310     5.5630236864089966e-01
    z[7,3,1]  R1311     5.1694333553314209e-01
    z[7,3,1]  R1312     1.1657485365867615e-01
    z[7,3,1]  R1313     1.8256975710391998e-01
    z[7,3,1]  R1314     0.0415816530585289
    z[7,3,1]  R1315     2.3756314814090729e-01
    z[7,3,1]  R1316     -2.9377132654190063e-02
    z[7,3,1]  R1317     -5.2666097879409790e-01
    z[7,3,1]  R1318     5.0524920225143433e-01
    z[7,3,1]  R1319     1.1464839428663254e-01
    z[7,3,1]  R1320     -1.9159886986017227e-02
    z[7,3,1]  R1321     4.8104834556579590e-01
    z[7,3,1]  R1322     4.5014080405235291e-01
    z[7,3,1]  R1323     -6.3170604407787323e-02
    z[7,3,1]  R1324     2.7494031190872192e-01
    z[7,3,1]  R1325     4.4470425695180893e-02
    z[7,3,1]  R1326     -9.6938237547874451e-03
    z[7,3,1]  R1327     4.1444137692451477e-01
    z[7,3,1]  R1328     5.4111951589584351e-01
    z[7,3,1]  R1329     0.627250611782074
    z[7,3,1]  R1330     5.6994384527206421e-01
    z[7,3,1]  R1331     -4.6652853488922119e-01
    z[7,3,1]  R1332     -5.2630335092544556e-01
    z[7,3,1]  R1333     4.4160258769989014e-01
    z[7,3,1]  R1334     -5.4234772920608521e-01
    z[7,3,1]  R1335     6.7723000049591064e-01
    z[7,3,1]  R1336     -4.7758162021636963e-02
    z[7,3,1]  R1337     -5.6062698364257812e-01
    z[7,3,1]  R1338     4.3963938951492310e-01
    z[7,3,1]  R1339     -1.6114315390586853e-01
    z[7,3,1]  R1340     -9.4882321357727051e-01
    z[7,3,1]  R1341     4.0067046880722046e-02
    z[7,3,1]  R1342     -9.2889207601547241e-01
    z[7,3,1]  R1343     -2.3473416268825531e-01
    z[7,3,1]  R1344     -9.0752846002578735e-01
    z[7,3,1]  R1345     7.4260032176971436e-01
    z[7,3,1]  R1346     -6.6749060153961182e-01
    z[7,3,1]  R1347     -4.7623196244239807e-01
    z[7,3,1]  R1348     6.0549920797348022e-01
    z[7,3,1]  R1349     4.7995755076408386e-01
    z[7,3,1]  R1350     -4.0013200044631958e-01
    z[7,3,1]  R1351     7.1967437863349915e-02
    z[7,3,1]  R1352     -8.7360413745045662e-03
    z[7,3,1]  R1353     6.3114196062088013e-02
    z[7,3,1]  R1354     6.9946028292179108e-02
    z[7,3,1]  R1355     7.9096013307571411e-01
    z[7,3,1]  R1356     6.5089470148086548e-01
    z[7,3,1]  R1357     5.2843958139419556e-01
    z[7,3,1]  R1358     1.1336542665958405e-01
    z[7,3,1]  R1359     5.1968789100646973e-01
    z[7,3,1]  R1360     -4.5264068990945816e-02
    z[7,3,1]  R1361     -5.3006079047918320e-02
    z[7,3,1]  R1362     2.8267037868499756e-01
    z[7,3,1]  R1363     1.7081966996192932e-01
    z[7,3,1]  R1364     -8.8181960582733154e-01
    z[7,3,1]  R1365     6.4701217412948608e-01
    z[7,3,1]  R1366     -1.5277132391929626e-01
    z[7,3,1]  R1367     5.6754022836685181e-01
    z[7,3,1]  R1368     1.6682486236095428e-01
    z[7,3,1]  R1369     1.8880617618560791e-01
    z[7,3,1]  R1370     0.492443710565567
    z[7,3,1]  R1371     -2.4261765182018280e-01
    z[7,3,1]  R1372     1.0084971785545349e-01
    z[7,3,1]  R1373     -8.7758040428161621e-01
    z[7,3,1]  R1374     -3.5370045900344849e-01
    z[7,3,1]  R1375     7.1731823682785034e-01
    z[7,3,1]  R1376     5.5955308675765991e-01
    z[7,3,1]  R1377     -1.5039165318012238e-01
    z[7,3,1]  R1378     -2.1676853299140930e-01
    z[7,3,1]  R1379     1.5709306299686432e-01
    z[7,3,1]  R1380     -6.6963976621627808e-01
    z[7,3,1]  R1381     -5.3933167457580566e-01
    z[7,3,1]  R1382     -7.8680831193923950e-01
    z[7,3,1]  R1383     -4.8667269945144653e-01
    z[7,3,1]  R1384     -5.3156054019927979e-01
    z[7,3,1]  R1385     6.9027435779571533e-01
    z[7,3,1]  R1386     -1.5281352400779724e-01
    z[7,3,1]  R1387     0.324432373046875
    z[7,3,1]  R1388     4.5422129333019257e-02
    z[7,3,1]  R1389     -2.6522394269704819e-02
    z[7,3,1]  R1390     1.5438407659530640e-01
    z[7,3,1]  R1391     -0.581614077091217
    z[7,3,1]  R1392     -5.1495635509490967e-01
    z[7,3,1]  R1393     -1.3446459174156189e-01
    z[7,3,1]  R1394     -5.9460699558258057e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1235     -1
    z[7,3,2]  R1236     1
    z[7,3,2]  R1245     -3.3604586124420166e-01
    z[7,3,2]  R1246     -8.9773915708065033e-02
    z[7,3,2]  R1247     -2.6283088326454163e-01
    z[7,3,2]  R1248     -2.2129869461059570e-01
    z[7,3,2]  R1249     3.8711285591125488e-01
    z[7,3,2]  R1250     7.2691243886947632e-01
    z[7,3,2]  R1251     4.8589169979095459e-01
    z[7,3,2]  R1252     7.5987368822097778e-01
    z[7,3,2]  R1253     3.2897848635911942e-02
    z[7,3,2]  R1254     -8.8280633091926575e-02
    z[7,3,2]  R1255     4.2452374100685120e-01
    z[7,3,2]  R1256     -4.1473528742790222e-01
    z[7,3,2]  R1257     4.7904092073440552e-01
    z[7,3,2]  R1258     -3.3625373244285583e-01
    z[7,3,2]  R1259     -1.5323549509048462e-01
    z[7,3,2]  R1260     -2.1477967500686646e-01
    z[7,3,2]  R1261     -4.4494945555925369e-02
    z[7,3,2]  R1262     -4.4417638331651688e-02
    z[7,3,2]  R1263     5.2536106109619141e-01
    z[7,3,2]  R1264     -3.5484644770622253e-01
    z[7,3,2]  R1265     9.7630776464939117e-02
    z[7,3,2]  R1266     4.0585052967071533e-01
    z[7,3,2]  R1267     -2.9736492037773132e-01
    z[7,3,2]  R1268     6.2986373901367188e-01
    z[7,3,2]  R1269     2.7783477306365967e-01
    z[7,3,2]  R1270     -2.5348627567291260e-01
    z[7,3,2]  R1271     7.6207816600799561e-01
    z[7,3,2]  R1272     0.831156849861145
    z[7,3,2]  R1273     6.1910808086395264e-01
    z[7,3,2]  R1274     7.5966519117355347e-01
    z[7,3,2]  R1275     3.1685021519660950e-01
    z[7,3,2]  R1276     -3.6706620454788208e-01
    z[7,3,2]  R1277     -4.2125180363655090e-01
    z[7,3,2]  R1278     5.5523318052291870e-01
    z[7,3,2]  R1279     0.807011067867279
    z[7,3,2]  R1280     8.4683841466903687e-01
    z[7,3,2]  R1281     8.7419945001602173e-01
    z[7,3,2]  R1282     9.5148253440856934e-01
    z[7,3,2]  R1283     9.5361477136611938e-01
    z[7,3,2]  R1284     8.5782015323638916e-01
    z[7,3,2]  R1285     -3.0486200004816055e-02
    z[7,3,2]  R1286     -1.1528084427118301e-01
    z[7,3,2]  R1287     7.4738597869873047e-01
    z[7,3,2]  R1288     7.1247100830078125e-01
    z[7,3,2]  R1289     3.2485216856002808e-01
    z[7,3,2]  R1290     6.8495023250579834e-01
    z[7,3,2]  R1291     1.1261721700429916e-01
    z[7,3,2]  R1292     6.6891357302665710e-02
    z[7,3,2]  R1293     9.6072681248188019e-02
    z[7,3,2]  R1294     2.4772010743618011e-02
    z[7,3,2]  R1295     0.388574481010437
    z[7,3,2]  R1296     2.4980668723583221e-01
    z[7,3,2]  R1297     6.0219585895538330e-01
    z[7,3,2]  R1298     3.8829341530799866e-01
    z[7,3,2]  R1299     1.6707780957221985e-01
    z[7,3,2]  R1300     4.4926857948303223e-01
    z[7,3,2]  R1301     3.8597890734672546e-01
    z[7,3,2]  R1302     1.4168396592140198e-01
    z[7,3,2]  R1303     0.345490425825119
    z[7,3,2]  R1304     5.9946954250335693e-01
    z[7,3,2]  R1305     -4.6438673138618469e-01
    z[7,3,2]  R1306     -0.453572154045105
    z[7,3,2]  R1307     -2.5681027770042419e-01
    z[7,3,2]  R1308     -6.0514993965625763e-02
    z[7,3,2]  R1309     -3.0757537484169006e-01
    z[7,3,2]  R1310     -1.1456935852766037e-01
    z[7,3,2]  R1311     -2.6502177119255066e-01
    z[7,3,2]  R1312     -3.3766967058181763e-01
    z[7,3,2]  R1313     -2.5241887569427490e-01
    z[7,3,2]  R1314     2.2210665047168732e-01
    z[7,3,2]  R1315     -4.0944731235504150e-01
    z[7,3,2]  R1316     6.3712793588638306e-01
    z[7,3,2]  R1317     -6.7614391446113586e-02
    z[7,3,2]  R1318     2.8389924764633179e-01
    z[7,3,2]  R1319     -2.0516772568225861e-01
    z[7,3,2]  R1320     -7.7193580567836761e-02
    z[7,3,2]  R1321     1.2833668291568756e-01
    z[7,3,2]  R1322     -4.6638140082359314e-01
    z[7,3,2]  R1323     3.0287280678749084e-01
    z[7,3,2]  R1324     2.8450208902359009e-01
    z[7,3,2]  R1325     3.0728485435247421e-02
    z[7,3,2]  R1326     1.0896039195358753e-02
    z[7,3,2]  R1327     1.4771074056625366e-01
    z[7,3,2]  R1328     4.6055087447166443e-01
    z[7,3,2]  R1329     -4.0463727712631226e-01
    z[7,3,2]  R1330     2.0238615572452545e-02
    z[7,3,2]  R1331     5.5145698785781860e-01
    z[7,3,2]  R1332     5.6918853521347046e-01
    z[7,3,2]  R1333     -5.7994669675827026e-01
    z[7,3,2]  R1334     2.2485144436359406e-01
    z[7,3,2]  R1335     -2.5433886051177979e-01
    z[7,3,2]  R1336     4.7333080321550369e-02
    z[7,3,2]  R1337     5.2712643146514893e-01
    z[7,3,2]  R1338     -3.9871567487716675e-01
    z[7,3,2]  R1339     -1.4094695448875427e-01
    z[7,3,2]  R1340     6.4704142510890961e-02
    z[7,3,2]  R1341     -3.2439496368169785e-02
    z[7,3,2]  R1342     3.1068574637174606e-02
    z[7,3,2]  R1343     1.6097691655158997e-01
    z[7,3,2]  R1344     2.4971139430999756e-01
    z[7,3,2]  R1345     6.2799811363220215e-02
    z[7,3,2]  R1346     1.2318023294210434e-01
    z[7,3,2]  R1347     0.424014687538147
    z[7,3,2]  R1348     0.0715944841504097
    z[7,3,2]  R1349     -2.9453590512275696e-01
    z[7,3,2]  R1350     7.6235704123973846e-02
    z[7,3,2]  R1351     1.3002495467662811e-01
    z[7,3,2]  R1352     -1.7952781915664673e-01
    z[7,3,2]  R1353     -0.280814528465271
    z[7,3,2]  R1354     2.7645226567983627e-02
    z[7,3,2]  R1355     -1.2493391335010529e-01
    z[7,3,2]  R1356     1.9838419556617737e-01
    z[7,3,2]  R1357     -0.488179087638855
    z[7,3,2]  R1358     -2.6554372906684875e-01
    z[7,3,2]  R1359     3.6922845244407654e-01
    z[7,3,2]  R1360     -0.0339483805000782
    z[7,3,2]  R1361     1.3924182951450348e-01
    z[7,3,2]  R1362     1.7402195930480957e-01
    z[7,3,2]  R1363     -1.2328878045082092e-01
    z[7,3,2]  R1364     -5.0941850990056992e-02
    z[7,3,2]  R1365     4.4459328055381775e-02
    z[7,3,2]  R1366     5.5610740184783936e-01
    z[7,3,2]  R1367     -1.8911378085613251e-01
    z[7,3,2]  R1368     -1.1785674095153809e-01
    z[7,3,2]  R1369     -2.0113836228847504e-01
    z[7,3,2]  R1370     -5.2802842855453491e-01
    z[7,3,2]  R1371     -5.6183699518442154e-02
    z[7,3,2]  R1372     3.6028262972831726e-01
    z[7,3,2]  R1373     -4.0361863374710083e-01
    z[7,3,2]  R1374     -6.0564011335372925e-01
    z[7,3,2]  R1375     1.1743155121803284e-01
    z[7,3,2]  R1376     -2.8917932510375977e-01
    z[7,3,2]  R1377     -1.1606529355049133e-01
    z[7,3,2]  R1378     -9.5972500275820494e-04
    z[7,3,2]  R1379     -1.6278178989887238e-01
    z[7,3,2]  R1380     -4.5483973622322083e-01
    z[7,3,2]  R1381     -4.7846508026123047e-01
    z[7,3,2]  R1382     2.9979849234223366e-02
    z[7,3,2]  R1383     -4.4776901602745056e-01
    z[7,3,2]  R1384     -3.7698981165885925e-01
    z[7,3,2]  R1385     -4.9701115489006042e-01
    z[7,3,2]  R1386     -2.9945635795593262e-01
    z[7,3,2]  R1387     -2.0904821157455444e-01
    z[7,3,2]  R1388     1.8929970264434814e-01
    z[7,3,2]  R1389     1.1313340812921524e-01
    z[7,3,2]  R1390     -1.4072303473949432e-01
    z[7,3,2]  R1391     -2.4279899895191193e-01
    z[7,3,2]  R1392     -5.3732901811599731e-01
    z[7,3,2]  R1393     -0.518753707408905
    z[7,3,2]  R1394     -6.6158592700958252e-01
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1237     -1
    z[7,3,3]  R1238     1
    z[7,3,3]  R1245     1.7860975861549377e-01
    z[7,3,3]  R1246     3.2187944650650024e-01
    z[7,3,3]  R1247     1.0834605433046818e-02
    z[7,3,3]  R1248     3.2391202449798584e-01
    z[7,3,3]  R1249     2.0039199292659760e-01
    z[7,3,3]  R1250     1.2313036620616913e-01
    z[7,3,3]  R1251     -1.6694139689207077e-02
    z[7,3,3]  R1252     1.9584544003009796e-01
    z[7,3,3]  R1253     -7.0980352163314819e-01
    z[7,3,3]  R1254     -7.1118837594985962e-01
    z[7,3,3]  R1255     -2.2603254020214081e-01
    z[7,3,3]  R1256     -5.7955193519592285e-01
    z[7,3,3]  R1257     -1.2480422854423523e-01
    z[7,3,3]  R1258     -2.7611499652266502e-02
    z[7,3,3]  R1259     1.1606021970510483e-01
    z[7,3,3]  R1260     -0.664367139339447
    z[7,3,3]  R1261     -4.7494283318519592e-01
    z[7,3,3]  R1262     -4.8844027519226074e-01
    z[7,3,3]  R1263     -1.0250040888786316e-01
    z[7,3,3]  R1264     4.6880498528480530e-02
    z[7,3,3]  R1265     1.5337735414505005e-01
    z[7,3,3]  R1266     6.7403799295425415e-01
    z[7,3,3]  R1267     -3.1837800145149231e-01
    z[7,3,3]  R1268     -4.4210964441299438e-01
    z[7,3,3]  R1269     -3.6278063058853149e-01
    z[7,3,3]  R1270     4.9592819809913635e-01
    z[7,3,3]  R1271     1.2239511311054230e-01
    z[7,3,3]  R1272     2.6496684551239014e-01
    z[7,3,3]  R1273     0.199748694896698
    z[7,3,3]  R1274     3.2743549346923828e-01
    z[7,3,3]  R1275     7.1964037418365479e-01
    z[7,3,3]  R1276     2.1272291243076324e-01
    z[7,3,3]  R1277     -5.7984054088592529e-01
    z[7,3,3]  R1278     -4.1433432698249817e-01
    z[7,3,3]  R1279     1.1915339529514313e-01
    z[7,3,3]  R1280     -1.1254362016916275e-01
    z[7,3,3]  R1281     2.7752781286835670e-02
    z[7,3,3]  R1282     9.9605210125446320e-03
    z[7,3,3]  R1283     -1.5184667706489563e-01
    z[7,3,3]  R1284     -1.8563267588615417e-01
    z[7,3,3]  R1285     3.1545478105545044e-01
    z[7,3,3]  R1286     -2.9333594441413879e-01
    z[7,3,3]  R1287     1.9253598153591156e-01
    z[7,3,3]  R1288     -1.1768083274364471e-01
    z[7,3,3]  R1289     0.0886588916182518
    z[7,3,3]  R1290     -3.5248023271560669e-01
    z[7,3,3]  R1291     -2.3124119639396667e-01
    z[7,3,3]  R1292     -6.5944540500640869e-01
    z[7,3,3]  R1293     -6.8610537052154541e-01
    z[7,3,3]  R1294     -7.5621813535690308e-01
    z[7,3,3]  R1295     -2.1983437240123749e-01
    z[7,3,3]  R1296     -3.3784502744674683e-01
    z[7,3,3]  R1297     -2.1890088915824890e-01
    z[7,3,3]  R1298     1.0547752678394318e-01
    z[7,3,3]  R1299     3.8617804646492004e-02
    z[7,3,3]  R1300     -2.0519154146313667e-02
    z[7,3,3]  R1301     3.8928262889385223e-02
    z[7,3,3]  R1302     -3.7719801068305969e-01
    z[7,3,3]  R1303     -2.8920945525169373e-01
    z[7,3,3]  R1304     -2.4688212573528290e-01
    z[7,3,3]  R1305     2.2081515192985535e-01
    z[7,3,3]  R1306     5.5929505825042725e-01
    z[7,3,3]  R1307     2.4585790932178497e-01
    z[7,3,3]  R1308     6.1227369308471680e-01
    z[7,3,3]  R1309     -8.4651607275009155e-01
    z[7,3,3]  R1310     3.4073927998542786e-01
    z[7,3,3]  R1311     6.9690680503845215e-01
    z[7,3,3]  R1312     -5.2825736999511719e-01
    z[7,3,3]  R1313     -4.5570856332778931e-01
    z[7,3,3]  R1314     1.1839376389980316e-01
    z[7,3,3]  R1315     8.2410866022109985e-01
    z[7,3,3]  R1316     3.8797068595886230e-01
    z[7,3,3]  R1317     2.3541538417339325e-01
    z[7,3,3]  R1318     3.8441452383995056e-01
    z[7,3,3]  R1319     1.0509452782571316e-02
    z[7,3,3]  R1320     -1.1293182522058487e-01
    z[7,3,3]  R1321     2.7240052819252014e-01
    z[7,3,3]  R1322     -2.9375419020652771e-01
    z[7,3,3]  R1323     -4.5824725180864334e-02
    z[7,3,3]  R1324     1.9795901607722044e-03
    z[7,3,3]  R1325     6.7289197444915771e-01
    z[7,3,3]  R1326     6.0950154066085815e-01
    z[7,3,3]  R1327     4.7397544980049133e-01
    z[7,3,3]  R1328     4.8006868362426758e-01
    z[7,3,3]  R1329     2.0311798900365829e-02
    z[7,3,3]  R1330     -4.1097089648246765e-01
    z[7,3,3]  R1331     4.3353244662284851e-01
    z[7,3,3]  R1332     3.1306838989257812e-01
    z[7,3,3]  R1333     -3.0565026402473450e-01
    z[7,3,3]  R1334     2.4861592054367065e-01
    z[7,3,3]  R1335     8.8877469301223755e-02
    z[7,3,3]  R1336     -1.5399585664272308e-01
    z[7,3,3]  R1337     4.1052162647247314e-01
    z[7,3,3]  R1338     -2.8152248263359070e-01
    z[7,3,3]  R1339     7.5641043484210968e-02
    z[7,3,3]  R1340     -9.4083890318870544e-02
    z[7,3,3]  R1341     3.7302400916814804e-02
    z[7,3,3]  R1342     -6.9526262581348419e-02
    z[7,3,3]  R1343     -3.0936279892921448e-01
    z[7,3,3]  R1344     5.2418440580368042e-02
    z[7,3,3]  R1345     3.3702442049980164e-01
    z[7,3,3]  R1346     5.6980293989181519e-01
    z[7,3,3]  R1347     4.3843919038772583e-01
    z[7,3,3]  R1348     -3.5689270496368408e-01
    z[7,3,3]  R1349     -2.8074812889099121e-01
    z[7,3,3]  R1350     3.2118624448776245e-01
    z[7,3,3]  R1351     -3.9957201480865479e-01
    z[7,3,3]  R1352     2.8057834506034851e-01
    z[7,3,3]  R1353     -0.649041473865509
    z[7,3,3]  R1354     -9.9989846348762512e-02
    z[7,3,3]  R1355     1.8089847872033715e-03
    z[7,3,3]  R1356     8.7370024994015694e-04
    z[7,3,3]  R1357     -3.8883021473884583e-01
    z[7,3,3]  R1358     -6.4202928543090820e-01
    z[7,3,3]  R1359     2.5093883275985718e-01
    z[7,3,3]  R1360     1.7347642779350281e-01
    z[7,3,3]  R1361     -1.0311586409807205e-01
    z[7,3,3]  R1362     -1.5421982109546661e-01
    z[7,3,3]  R1363     -4.7485277056694031e-01
    z[7,3,3]  R1364     -3.8497611880302429e-01
    z[7,3,3]  R1365     -3.3683210611343384e-01
    z[7,3,3]  R1366     3.6364433169364929e-01
    z[7,3,3]  R1367     2.2673273086547852e-01
    z[7,3,3]  R1368     0.277258962392807
    z[7,3,3]  R1369     -5.7367360591888428e-01
    z[7,3,3]  R1370     8.6202420294284821e-02
    z[7,3,3]  R1371     -3.1494984030723572e-01
    z[7,3,3]  R1372     -1.5366628766059875e-01
    z[7,3,3]  R1373     -1.6533143818378448e-01
    z[7,3,3]  R1374     2.4333539605140686e-01
    z[7,3,3]  R1375     -4.1196337342262268e-01
    z[7,3,3]  R1376     5.6809765100479126e-01
    z[7,3,3]  R1377     -3.2596006989479065e-02
    z[7,3,3]  R1378     -2.0463606715202332e-01
    z[7,3,3]  R1379     -2.2062188386917114e-01
    z[7,3,3]  R1380     -4.1860058903694153e-01
    z[7,3,3]  R1381     -4.4509038329124451e-02
    z[7,3,3]  R1382     -3.3235767483711243e-01
    z[7,3,3]  R1383     -2.3991049826145172e-01
    z[7,3,3]  R1384     -3.9578244090080261e-01
    z[7,3,3]  R1385     -1.1740065366029739e-01
    z[7,3,3]  R1386     4.9503996968269348e-01
    z[7,3,3]  R1387     -5.5340075492858887e-01
    z[7,3,3]  R1388     -3.4102407097816467e-01
    z[7,3,3]  R1389     1.7385666072368622e-01
    z[7,3,3]  R1390     -2.4025362730026245e-01
    z[7,3,3]  R1391     -3.6551502346992493e-01
    z[7,3,3]  R1392     1.0349040478467941e-01
    z[7,3,3]  R1393     -1.5072527341544628e-02
    z[7,3,3]  R1394     1.3338880613446236e-02
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1239     -1
    z[7,3,4]  R1240     1
    z[7,3,4]  R1245     1.6010291874408722e-02
    z[7,3,4]  R1246     -1.0964769870042801e-01
    z[7,3,4]  R1247     2.1156449615955353e-01
    z[7,3,4]  R1248     0.655748188495636
    z[7,3,4]  R1249     -1.4161817729473114e-01
    z[7,3,4]  R1250     6.3251096010208130e-01
    z[7,3,4]  R1251     3.9920559525489807e-01
    z[7,3,4]  R1252     -6.1699371784925461e-02
    z[7,3,4]  R1253     3.5262140631675720e-01
    z[7,3,4]  R1254     -2.7352491393685341e-02
    z[7,3,4]  R1255     3.0771702527999878e-01
    z[7,3,4]  R1256     0.307492196559906
    z[7,3,4]  R1257     4.6538379788398743e-01
    z[7,3,4]  R1258     -2.9700118303298950e-01
    z[7,3,4]  R1259     -3.9172884821891785e-01
    z[7,3,4]  R1260     2.1518760919570923e-01
    z[7,3,4]  R1261     -1.0180468112230301e-01
    z[7,3,4]  R1262     2.2309435904026031e-01
    z[7,3,4]  R1263     -0.0850767120718956
    z[7,3,4]  R1264     -1.1955167353153229e-01
    z[7,3,4]  R1265     -8.1110924482345581e-01
    z[7,3,4]  R1266     -1.0898580402135849e-01
    z[7,3,4]  R1267     5.5226337909698486e-01
    z[7,3,4]  R1268     4.8057359457015991e-01
    z[7,3,4]  R1269     7.1364927291870117e-01
    z[7,3,4]  R1270     2.6871958374977112e-01
    z[7,3,4]  R1271     5.2876341342926025e-01
    z[7,3,4]  R1272     1.1409211903810501e-01
    z[7,3,4]  R1273     2.6202520728111267e-01
    z[7,3,4]  R1274     2.4984866380691528e-01
    z[7,3,4]  R1275     -3.6618936061859131e-01
    z[7,3,4]  R1276     -1.6661860048770905e-02
    z[7,3,4]  R1277     4.3248176574707031e-01
    z[7,3,4]  R1278     2.5308316946029663e-01
    z[7,3,4]  R1279     2.0223341882228851e-01
    z[7,3,4]  R1280     3.3913221955299377e-01
    z[7,3,4]  R1281     3.0128675699234009e-01
    z[7,3,4]  R1282     1.3564477860927582e-01
    z[7,3,4]  R1283     -2.7488607913255692e-02
    z[7,3,4]  R1284     4.8106640577316284e-02
    z[7,3,4]  R1285     -3.4481963515281677e-01
    z[7,3,4]  R1286     -2.0610374212265015e-01
    z[7,3,4]  R1287     2.7970704436302185e-01
    z[7,3,4]  R1288     5.1321285963058472e-01
    z[7,3,4]  R1289     6.8382078409194946e-01
    z[7,3,4]  R1290     7.9613149166107178e-02
    z[7,3,4]  R1291     5.0367474555969238e-01
    z[7,3,4]  R1292     -1.6412030905485153e-02
    z[7,3,4]  R1293     5.0547290593385696e-02
    z[7,3,4]  R1294     -2.2112096846103668e-01
    z[7,3,4]  R1295     3.6975425481796265e-01
    z[7,3,4]  R1296     0.0836007222533226
    z[7,3,4]  R1297     2.7925944328308105e-01
    z[7,3,4]  R1298     1.6411504149436951e-01
    z[7,3,4]  R1299     -1.3834075629711151e-01
    z[7,3,4]  R1300     9.8664209246635437e-02
    z[7,3,4]  R1301     -1.6533695161342621e-01
    z[7,3,4]  R1302     -2.0861823856830597e-01
    z[7,3,4]  R1303     -2.3871515691280365e-01
    z[7,3,4]  R1304     -6.3319101929664612e-02
    z[7,3,4]  R1305     4.0838193893432617e-01
    z[7,3,4]  R1306     -1.8973509967327118e-01
    z[7,3,4]  R1307     3.4369704127311707e-01
    z[7,3,4]  R1308     -1.2840871512889862e-01
    z[7,3,4]  R1309     2.6399930939078331e-02
    z[7,3,4]  R1310     -2.5398489832878113e-01
    z[7,3,4]  R1311     -1.4980722218751907e-02
    z[7,3,4]  R1312     2.6581141352653503e-01
    z[7,3,4]  R1313     -5.2717506885528564e-01
    z[7,3,4]  R1314     -2.4696613848209381e-01
    z[7,3,4]  R1315     -2.6409873366355896e-01
    z[7,3,4]  R1316     -2.9159709811210632e-01
    z[7,3,4]  R1317     -4.9763542413711548e-01
    z[7,3,4]  R1318     -2.1162109076976776e-01
    z[7,3,4]  R1319     -3.0046626925468445e-01
    z[7,3,4]  R1320     -1.0412283986806870e-01
    z[7,3,4]  R1321     1.2374614179134369e-01
    z[7,3,4]  R1322     -5.5735909938812256e-01
    z[7,3,4]  R1323     -2.5431391596794128e-01
    z[7,3,4]  R1324     2.7516716718673706e-01
    z[7,3,4]  R1325     1.2355333566665649e-01
    z[7,3,4]  R1326     -3.3346304297447205e-01
    z[7,3,4]  R1327     -0.394437313079834
    z[7,3,4]  R1328     -2.4966441094875336e-01
    z[7,3,4]  R1329     3.9922407269477844e-01
    z[7,3,4]  R1330     4.2915868759155273e-01
    z[7,3,4]  R1331     1.0579667240381241e-01
    z[7,3,4]  R1332     -0.181906595826149
    z[7,3,4]  R1333     -7.3114745318889618e-02
    z[7,3,4]  R1334     -1.4692904055118561e-01
    z[7,3,4]  R1335     -4.5659685134887695e-01
    z[7,3,4]  R1336     1.6165295243263245e-01
    z[7,3,4]  R1337     -1.6063414514064789e-01
    z[7,3,4]  R1338     -4.8005864024162292e-01
    z[7,3,4]  R1339     3.8883373141288757e-02
    z[7,3,4]  R1340     1.1996621638536453e-01
    z[7,3,4]  R1341     3.7625020742416382e-01
    z[7,3,4]  R1342     3.4751359373331070e-02
    z[7,3,4]  R1343     4.7478446364402771e-01
    z[7,3,4]  R1344     -1.5053851902484894e-01
    z[7,3,4]  R1345     -2.2645914554595947e-01
    z[7,3,4]  R1346     -5.7060797698795795e-03
    z[7,3,4]  R1347     -7.6822616159915924e-02
    z[7,3,4]  R1348     2.1029409021139145e-02
    z[7,3,4]  R1349     1.8492749333381653e-01
    z[7,3,4]  R1350     -1.1500279605388641e-01
    z[7,3,4]  R1351     6.0783304274082184e-02
    z[7,3,4]  R1352     7.0928357541561127e-02
    z[7,3,4]  R1353     -0.42122882604599
    z[7,3,4]  R1354     1.3787874579429626e-01
    z[7,3,4]  R1355     2.6096263527870178e-01
    z[7,3,4]  R1356     -0.16848124563694
    z[7,3,4]  R1357     3.8658101111650467e-02
    z[7,3,4]  R1358     -4.1916516423225403e-01
    z[7,3,4]  R1359     4.3393567204475403e-01
    z[7,3,4]  R1360     2.7704099193215370e-02
    z[7,3,4]  R1361     3.0394849181175232e-01
    z[7,3,4]  R1362     -2.5828543305397034e-01
    z[7,3,4]  R1363     3.7149384617805481e-01
    z[7,3,4]  R1364     4.7176092863082886e-02
    z[7,3,4]  R1365     -2.7131193876266479e-01
    z[7,3,4]  R1366     -2.9805478453636169e-01
    z[7,3,4]  R1367     -6.0237679630517960e-02
    z[7,3,4]  R1368     -6.2752211093902588e-01
    z[7,3,4]  R1369     1.4327786862850189e-01
    z[7,3,4]  R1370     -4.9175915122032166e-01
    z[7,3,4]  R1371     -9.4972558319568634e-02
    z[7,3,4]  R1372     9.8763778805732727e-02
    z[7,3,4]  R1373     -1.2358006834983826e-01
    z[7,3,4]  R1374     8.0499485135078430e-02
    z[7,3,4]  R1375     2.8234642744064331e-01
    z[7,3,4]  R1376     9.6305571496486664e-02
    z[7,3,4]  R1377     -7.1907705068588257e-01
    z[7,3,4]  R1378     -1.6345153562724590e-03
    z[7,3,4]  R1379     -2.5797012448310852e-01
    z[7,3,4]  R1380     -1.1582937091588974e-01
    z[7,3,4]  R1381     2.3507069051265717e-01
    z[7,3,4]  R1382     -1.5902440249919891e-01
    z[7,3,4]  R1383     -1.6797071322798729e-02
    z[7,3,4]  R1384     1.1166515201330185e-01
    z[7,3,4]  R1385     -2.2787198424339294e-01
    z[7,3,4]  R1386     -1.4868468046188354e-01
    z[7,3,4]  R1387     -3.1543251127004623e-02
    z[7,3,4]  R1388     4.9308642745018005e-02
    z[7,3,4]  R1389     3.4621319174766541e-01
    z[7,3,4]  R1390     -2.5849640369415283e-01
    z[7,3,4]  R1391     2.3924781382083893e-01
    z[7,3,4]  R1392     1.4420378953218460e-02
    z[7,3,4]  R1393     -0.0878065750002861
    z[7,3,4]  R1394     4.0671084076166153e-02
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1241     -1
    z[7,3,5]  R1242     1
    z[7,3,5]  R1245     6.1092805862426758e-01
    z[7,3,5]  R1246     0.305328369140625
    z[7,3,5]  R1247     -3.2644817233085632e-01
    z[7,3,5]  R1248     2.7013307809829712e-01
    z[7,3,5]  R1249     3.8586756587028503e-01
    z[7,3,5]  R1250     -1.1724155396223068e-02
    z[7,3,5]  R1251     -5.4554667323827744e-02
    z[7,3,5]  R1252     -1.7589065432548523e-01
    z[7,3,5]  R1253     7.0996925234794617e-02
    z[7,3,5]  R1254     4.9334344267845154e-01
    z[7,3,5]  R1255     -0.647737979888916
    z[7,3,5]  R1256     2.6006600819528103e-03
    z[7,3,5]  R1257     -3.1988570094108582e-01
    z[7,3,5]  R1258     -5.3647315502166748e-01
    z[7,3,5]  R1259     -3.3451077342033386e-01
    z[7,3,5]  R1260     3.8160249590873718e-02
    z[7,3,5]  R1261     0.247584730386734
    z[7,3,5]  R1262     1.7031347751617432e-01
    z[7,3,5]  R1263     -3.9729550480842590e-01
    z[7,3,5]  R1264     2.6620325446128845e-01
    z[7,3,5]  R1265     -9.6859313547611237e-02
    z[7,3,5]  R1266     3.9680776000022888e-01
    z[7,3,5]  R1267     3.8803797960281372e-01
    z[7,3,5]  R1268     -3.6811605095863342e-01
    z[7,3,5]  R1269     -4.5355820655822754e-01
    z[7,3,5]  R1270     -3.7679061293601990e-01
    z[7,3,5]  R1271     -9.9245734512805939e-02
    z[7,3,5]  R1272     -3.6069911718368530e-01
    z[7,3,5]  R1273     -4.9722501635551453e-01
    z[7,3,5]  R1274     -6.0913139022886753e-03
    z[7,3,5]  R1275     -3.0868908762931824e-01
    z[7,3,5]  R1276     -2.5204730033874512e-01
    z[7,3,5]  R1277     2.2183644771575928e-01
    z[7,3,5]  R1278     -2.9326236248016357e-01
    z[7,3,5]  R1279     -2.0866183936595917e-01
    z[7,3,5]  R1280     -9.8147220909595490e-02
    z[7,3,5]  R1281     -2.2753703594207764e-01
    z[7,3,5]  R1282     -2.1214932203292847e-01
    z[7,3,5]  R1283     -1.6605599224567413e-01
    z[7,3,5]  R1284     -1.2479253858327866e-01
    z[7,3,5]  R1285     -5.0345528125762939e-01
    z[7,3,5]  R1286     0.754705548286438
    z[7,3,5]  R1287     -2.9630449414253235e-01
    z[7,3,5]  R1288     -3.5210517048835754e-01
    z[7,3,5]  R1289     -2.0151783525943756e-01
    z[7,3,5]  R1290     -5.6089985370635986e-01
    z[7,3,5]  R1291     -1.1960883438587189e-01
    z[7,3,5]  R1292     -2.6464805006980896e-01
    z[7,3,5]  R1293     -6.1810355633497238e-02
    z[7,3,5]  R1294     -4.4104088097810745e-02
    z[7,3,5]  R1295     3.3980527520179749e-01
    z[7,3,5]  R1296     0.486115425825119
    z[7,3,5]  R1297     9.7025007009506226e-02
    z[7,3,5]  R1298     2.9867282509803772e-01
    z[7,3,5]  R1299     4.1259261965751648e-01
    z[7,3,5]  R1300     4.1188114881515503e-01
    z[7,3,5]  R1301     -0.074520044028759
    z[7,3,5]  R1302     -1.9655311107635498e-01
    z[7,3,5]  R1303     -2.0525650680065155e-01
    z[7,3,5]  R1304     0.0744505226612091
    z[7,3,5]  R1305     -9.6932850778102875e-02
    z[7,3,5]  R1306     -6.0361623764038086e-01
    z[7,3,5]  R1307     2.6354864239692688e-01
    z[7,3,5]  R1308     2.4786043167114258e-01
    z[7,3,5]  R1309     1.6977612674236298e-01
    z[7,3,5]  R1310     -9.4695478677749634e-02
    z[7,3,5]  R1311     -2.2654792666435242e-01
    z[7,3,5]  R1312     -2.9492089152336121e-01
    z[7,3,5]  R1313     3.2390865683555603e-01
    z[7,3,5]  R1314     -8.4928011894226074e-01
    z[7,3,5]  R1315     -1.0813717544078827e-01
    z[7,3,5]  R1316     -2.7280244231224060e-01
    z[7,3,5]  R1317     -4.6663495898246765e-01
    z[7,3,5]  R1318     -5.3795474767684937e-01
    z[7,3,5]  R1319     -1.1047238111495972e-01
    z[7,3,5]  R1320     1.4906586706638336e-01
    z[7,3,5]  R1321     -7.2340106964111328e-01
    z[7,3,5]  R1322     0.17389015853405
    z[7,3,5]  R1323     1.3917692005634308e-01
    z[7,3,5]  R1324     -2.3230737075209618e-02
    z[7,3,5]  R1325     -7.0192688703536987e-01
    z[7,3,5]  R1326     -3.6358866095542908e-01
    z[7,3,5]  R1327     -5.8569401502609253e-01
    z[7,3,5]  R1328     -4.0828722715377808e-01
    z[7,3,5]  R1329     3.3582428097724915e-01
    z[7,3,5]  R1330     1.7942123115062714e-01
    z[7,3,5]  R1331     -4.3635964393615723e-01
    z[7,3,5]  R1332     -4.8830467462539673e-01
    z[7,3,5]  R1333     -1.7145806550979614e-01
    z[7,3,5]  R1334     -4.1066142916679382e-01
    z[7,3,5]  R1335     6.2644377350807190e-02
    z[7,3,5]  R1336     -1.7560601234436035e-01
    z[7,3,5]  R1337     -0.392000675201416
    z[7,3,5]  R1338     1.3934718072414398e-01
    z[7,3,5]  R1339     -3.3349204063415527e-01
    z[7,3,5]  R1340     -1.2825973331928253e-01
    z[7,3,5]  R1341     4.3615409731864929e-01
    z[7,3,5]  R1342     2.9254710674285889e-01
    z[7,3,5]  R1343     -0.0223592147231102
    z[7,3,5]  R1344     1.2361817806959152e-01
    z[7,3,5]  R1345     4.9798870086669922e-01
    z[7,3,5]  R1346     -0.242364302277565
    z[7,3,5]  R1347     -6.2602925300598145e-01
    z[7,3,5]  R1348     1.8952375650405884e-01
    z[7,3,5]  R1349     -5.4515582323074341e-01
    z[7,3,5]  R1350     -3.3561038970947266e-01
    z[7,3,5]  R1351     1.5446986258029938e-01
    z[7,3,5]  R1352     2.5392949581146240e-01
    z[7,3,5]  R1353     -3.6997672915458679e-01
    z[7,3,5]  R1354     5.0624340772628784e-01
    z[7,3,5]  R1355     4.5626637339591980e-01
    z[7,3,5]  R1356     4.2337018251419067e-01
    z[7,3,5]  R1357     -3.2346537709236145e-01
    z[7,3,5]  R1358     -3.3001348376274109e-01
    z[7,3,5]  R1359     -1.9071669876575470e-01
    z[7,3,5]  R1360     -2.1720662713050842e-02
    z[7,3,5]  R1361     1.8512552604079247e-02
    z[7,3,5]  R1362     2.5458592176437378e-01
    z[7,3,5]  R1363     3.2484656572341919e-01
    z[7,3,5]  R1364     9.8366884049028158e-04
    z[7,3,5]  R1365     3.3701050281524658e-01
    z[7,3,5]  R1366     -3.8555371761322021e-01
    z[7,3,5]  R1367     -5.9404969215393066e-01
    z[7,3,5]  R1368     -4.4391539692878723e-01
    z[7,3,5]  R1369     -4.4910570979118347e-01
    z[7,3,5]  R1370     -1.1908382177352905e-01
    z[7,3,5]  R1371     -3.5017880797386169e-01
    z[7,3,5]  R1372     -3.3454936742782593e-01
    z[7,3,5]  R1373     -1.4463682472705841e-01
    z[7,3,5]  R1374     3.1754285097122192e-01
    z[7,3,5]  R1375     -1.9783751666545868e-01
    z[7,3,5]  R1376     -3.1333526968955994e-01
    z[7,3,5]  R1377     -6.5661799907684326e-01
    z[7,3,5]  R1378     -0.303000271320343
    z[7,3,5]  R1379     3.2724419236183167e-01
    z[7,3,5]  R1380     1.0442462563514709e-01
    z[7,3,5]  R1381     5.4920810461044312e-01
    z[7,3,5]  R1382     3.1957671046257019e-01
    z[7,3,5]  R1383     6.4711350202560425e-01
    z[7,3,5]  R1384     1.8048487603664398e-01
    z[7,3,5]  R1385     -3.1513166427612305e-01
    z[7,3,5]  R1386     -6.5260219573974609e-01
    z[7,3,5]  R1387     -1.8633204698562622e-01
    z[7,3,5]  R1388     -1.1351475864648819e-01
    z[7,3,5]  R1389     -2.0502893626689911e-01
    z[7,3,5]  R1390     2.9521077871322632e-01
    z[7,3,5]  R1391     3.3200421929359436e-01
    z[7,3,5]  R1392     0.461311936378479
    z[7,3,5]  R1393     6.2382197380065918e-01
    z[7,3,5]  R1394     4.1954675316810608e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1243     -1
    z[7,3,6]  R1244     1
    z[7,3,6]  R1245     -1.9635464251041412e-01
    z[7,3,6]  R1246     -5.5271911621093750e-01
    z[7,3,6]  R1247     -2.3895850777626038e-01
    z[7,3,6]  R1248     4.4609103351831436e-03
    z[7,3,6]  R1249     -1.1613752692937851e-01
    z[7,3,6]  R1250     -5.3179364651441574e-02
    z[7,3,6]  R1251     -6.2002742290496826e-01
    z[7,3,6]  R1252     -4.5243588089942932e-01
    z[7,3,6]  R1253     -0.295798122882843
    z[7,3,6]  R1254     -2.5345128774642944e-01
    z[7,3,6]  R1255     1.7758010327816010e-01
    z[7,3,6]  R1256     1.2392652779817581e-01
    z[7,3,6]  R1257     -3.2880410552024841e-01
    z[7,3,6]  R1258     1.3284260034561157e-01
    z[7,3,6]  R1259     -0.0349249504506588
    z[7,3,6]  R1260     -9.8057381808757782e-02
    z[7,3,6]  R1261     -1.4266440272331238e-01
    z[7,3,6]  R1262     -9.4616673886775970e-02
    z[7,3,6]  R1263     1.0085908323526382e-01
    z[7,3,6]  R1264     1.7898587882518768e-01
    z[7,3,6]  R1265     1.4067785441875458e-01
    z[7,3,6]  R1266     4.1401076316833496e-01
    z[7,3,6]  R1267     4.6701654791831970e-01
    z[7,3,6]  R1268     1.0725246369838715e-01
    z[7,3,6]  R1269     3.5518039017915726e-02
    z[7,3,6]  R1270     4.4076108932495117e-01
    z[7,3,6]  R1271     1.7334438860416412e-01
    z[7,3,6]  R1272     2.4198049306869507e-01
    z[7,3,6]  R1273     2.2133606672286987e-01
    z[7,3,6]  R1274     1.7766645550727844e-01
    z[7,3,6]  R1275     -1.2828439474105835e-01
    z[7,3,6]  R1276     4.6037697792053223e-01
    z[7,3,6]  R1277     -2.1246072649955750e-01
    z[7,3,6]  R1278     -1.1773724108934402e-01
    z[7,3,6]  R1279     -1.4549601078033447e-01
    z[7,3,6]  R1280     -3.0574795603752136e-01
    z[7,3,6]  R1281     2.2659644484519958e-01
    z[7,3,6]  R1282     3.5989217460155487e-02
    z[7,3,6]  R1283     -7.9660356044769287e-02
    z[7,3,6]  R1284     -2.7802494168281555e-01
    z[7,3,6]  R1285     7.3532208800315857e-02
    z[7,3,6]  R1286     3.6037430167198181e-01
    z[7,3,6]  R1287     2.0212219655513763e-01
    z[7,3,6]  R1288     -2.4569953978061676e-01
    z[7,3,6]  R1289     3.2126274704933167e-01
    z[7,3,6]  R1290     -2.0595690608024597e-01
    z[7,3,6]  R1291     3.0520647764205933e-01
    z[7,3,6]  R1292     6.3805043697357178e-02
    z[7,3,6]  R1293     -1.4203125238418579e-01
    z[7,3,6]  R1294     1.0419698059558868e-01
    z[7,3,6]  R1295     -1.1921192705631256e-01
    z[7,3,6]  R1296     -1.0565267503261566e-01
    z[7,3,6]  R1297     -1.8575143814086914e-01
    z[7,3,6]  R1298     -1.1226785928010941e-01
    z[7,3,6]  R1299     -2.7282893657684326e-01
    z[7,3,6]  R1300     -3.4772503376007080e-01
    z[7,3,6]  R1301     -1.6278398036956787e-01
    z[7,3,6]  R1302     -3.4013012051582336e-01
    z[7,3,6]  R1303     -2.7045345306396484e-01
    z[7,3,6]  R1304     2.0042194426059723e-01
    z[7,3,6]  R1305     -2.1347667276859283e-01
    z[7,3,6]  R1306     7.5314551591873169e-02
    z[7,3,6]  R1307     4.8321974277496338e-01
    z[7,3,6]  R1308     2.0423837006092072e-01
    z[7,3,6]  R1309     -2.2396599873900414e-02
    z[7,3,6]  R1310     6.8618965148925781e-01
    z[7,3,6]  R1311     3.4243202209472656e-01
    z[7,3,6]  R1312     -1.0500402003526688e-01
    z[7,3,6]  R1313     1.4225970208644867e-01
    z[7,3,6]  R1314     -8.8078305125236511e-02
    z[7,3,6]  R1315     1.0345313698053360e-01
    z[7,3,6]  R1316     -6.8595241755247116e-03
    z[7,3,6]  R1317     -4.4258746504783630e-01
    z[7,3,6]  R1318     -2.6830476522445679e-01
    z[7,3,6]  R1319     6.9326788187026978e-02
    z[7,3,6]  R1320     -3.4348601102828979e-01
    z[7,3,6]  R1321     0.0750337466597557
    z[7,3,6]  R1322     0.390138179063797
    z[7,3,6]  R1323     1.6677644848823547e-01
    z[7,3,6]  R1324     7.4481196701526642e-02
    z[7,3,6]  R1325     -1.8555977940559387e-01
    z[7,3,6]  R1326     1.0878256708383560e-01
    z[7,3,6]  R1327     2.2727511823177338e-02
    z[7,3,6]  R1328     -1.7764264345169067e-01
    z[7,3,6]  R1329     3.2427048683166504e-01
    z[7,3,6]  R1330     3.8796347379684448e-01
    z[7,3,6]  R1331     2.9086786508560181e-01
    z[7,3,6]  R1332     5.3685763850808144e-03
    z[7,3,6]  R1333     4.7650119662284851e-01
    z[7,3,6]  R1334     1.9865010678768158e-01
    z[7,3,6]  R1335     8.7767750024795532e-02
    z[7,3,6]  R1336     7.5500112771987915e-01
    z[7,3,6]  R1337     -2.2788988426327705e-02
    z[7,3,6]  R1338     -5.5582004785537720e-01
    z[7,3,6]  R1339     -3.8580577820539474e-02
    z[7,3,6]  R1340     -1.2512862682342529e-01
    z[7,3,6]  R1341     1.8459033966064453e-01
    z[7,3,6]  R1342     1.6274780035018921e-01
    z[7,3,6]  R1343     1.2327576428651810e-01
    z[7,3,6]  R1344     -1.0316102951765060e-01
    z[7,3,6]  R1345     1.7142336070537567e-01
    z[7,3,6]  R1346     -1.6085078939795494e-02
    z[7,3,6]  R1347     -4.6470880508422852e-02
    z[7,3,6]  R1348     1.5468142926692963e-02
    z[7,3,6]  R1349     1.5896968543529510e-01
    z[7,3,6]  R1350     5.0948962569236755e-02
    z[7,3,6]  R1351     8.9596778154373169e-02
    z[7,3,6]  R1352     1.1430647969245911e-01
    z[7,3,6]  R1353     2.1785560250282288e-01
    z[7,3,6]  R1354     1.8165364861488342e-01
    z[7,3,6]  R1355     2.8705176711082458e-01
    z[7,3,6]  R1356     -1.0856804251670837e-01
    z[7,3,6]  R1357     -1.2562349438667297e-01
    z[7,3,6]  R1358     2.7592003345489502e-02
    z[7,3,6]  R1359     -0.145661860704422
    z[7,3,6]  R1360     2.5001093745231628e-01
    z[7,3,6]  R1361     -1.5254151821136475e-01
    z[7,3,6]  R1362     -0.0850839912891388
    z[7,3,6]  R1363     -0.560992419719696
    z[7,3,6]  R1364     2.0289690792560577e-01
    z[7,3,6]  R1365     2.9001367092132568e-01
    z[7,3,6]  R1366     5.1871906965970993e-02
    z[7,3,6]  R1367     4.8334410786628723e-01
    z[7,3,6]  R1368     -5.3901600837707520e-01
    z[7,3,6]  R1369     1.5751791000366211e-01
    z[7,3,6]  R1370     2.2093172371387482e-01
    z[7,3,6]  R1371     -8.7031356990337372e-02
    z[7,3,6]  R1372     -3.7781888246536255e-01
    z[7,3,6]  R1373     -5.3689569234848022e-02
    z[7,3,6]  R1374     2.2673925757408142e-01
    z[7,3,6]  R1375     3.9606702327728271e-01
    z[7,3,6]  R1376     4.1313868761062622e-01
    z[7,3,6]  R1377     -7.8150011599063873e-02
    z[7,3,6]  R1378     -3.9280518889427185e-02
    z[7,3,6]  R1379     1.1420807242393494e-01
    z[7,3,6]  R1380     -8.6310803890228271e-02
    z[7,3,6]  R1381     -1.9005009904503822e-02
    z[7,3,6]  R1382     -3.6157715320587158e-01
    z[7,3,6]  R1383     -2.1683798730373383e-01
    z[7,3,6]  R1384     3.4990105032920837e-01
    z[7,3,6]  R1385     5.6830104440450668e-02
    z[7,3,6]  R1386     2.1327154338359833e-01
    z[7,3,6]  R1387     -1.5577603876590729e-01
    z[7,3,6]  R1388     -3.4625567495822906e-02
    z[7,3,6]  R1389     -1.4220872521400452e-01
    z[7,3,6]  R1390     9.6423342823982239e-02
    z[7,3,6]  R1391     -1.7282311618328094e-01
    z[7,3,6]  R1392     -0.378086119890213
    z[7,3,6]  R1393     3.4706908464431763e-01
    z[7,3,6]  R1394     1.7097742855548859e-01
    z[3,8,0]  R29       -1
    z[3,8,0]  R74       1
    z[3,8,0]  R1395     -1
    z[3,8,0]  R1396     1
    z[3,8,0]  R1409     7.3081964254379272e-01
    z[3,8,0]  R1410     7.5236237049102783e-01
    z[3,8,0]  R1411     6.4019095897674561e-01
    z[3,8,0]  R1412     7.5551462173461914e-01
    z[3,8,0]  R1413     7.9268425703048706e-01
    z[3,8,0]  R1414     5.8187460899353027e-01
    z[3,8,0]  R1415     7.8306490182876587e-01
    z[3,8,0]  R1416     7.6801878213882446e-01
    z[3,8,0]  R1417     -1.7464710399508476e-02
    z[3,8,0]  R1418     -5.1970733329653740e-04
    z[3,8,0]  R1419     -3.7451930344104767e-02
    z[3,8,0]  R1420     -1.7085577547550201e-01
    z[3,8,0]  R1421     -1.3820216059684753e-01
    z[3,8,0]  R1422     -2.9620608687400818e-01
    z[3,8,0]  R1423     -3.9036303758621216e-01
    z[3,8,0]  R1424     -1.3025595247745514e-01
    z[3,8,0]  R1425     -8.9698553085327148e-02
    z[3,8,0]  R1426     -0.651669979095459
    z[3,8,0]  R1427     -5.4056859016418457e-01
    z[3,8,0]  R1428     -3.8065171241760254e-01
    z[3,8,0]  R1429     6.7949414253234863e-02
    z[3,8,0]  R1430     -5.3215283155441284e-01
    z[3,8,0]  R1431     -3.6922167986631393e-02
    z[3,8,0]  R1432     -3.3193930983543396e-01
    z[3,8,0]  R1433     -9.1507446765899658e-01
    z[3,8,0]  R1434     -9.1097509860992432e-01
    z[3,8,0]  R1435     -3.6560615897178650e-01
    z[3,8,0]  R1436     2.1802823990583420e-02
    z[3,8,0]  R1437     -8.8899797201156616e-01
    z[3,8,0]  R1438     -8.7273043394088745e-01
    z[3,8,0]  R1439     -4.3535541743040085e-02
    z[3,8,0]  R1440     6.1079227924346924e-01
    z[3,8,0]  R1441     -2.8745830059051514e-01
    z[3,8,0]  R1442     -6.3473924994468689e-02
    z[3,8,0]  R1443     2.5515419244766235e-01
    z[3,8,0]  R1444     -3.7279021739959717e-01
    z[3,8,0]  R1445     -6.3946500420570374e-02
    z[3,8,0]  R1446     1.7163048684597015e-01
    z[3,8,0]  R1447     -3.3679354190826416e-01
    z[3,8,0]  R1448     -6.0315674543380737e-01
    z[3,8,0]  R1449     -4.9866211414337158e-01
    z[3,8,0]  R1450     5.8716970682144165e-01
    z[3,8,0]  R1451     2.4355675280094147e-01
    z[3,8,0]  R1452     -9.8377957940101624e-02
    z[3,8,0]  R1453     -9.1336077451705933e-01
    z[3,8,0]  R1454     -2.0049074292182922e-01
    z[3,8,0]  R1455     -0.793777346611023
    z[3,8,0]  R1456     -1.3446946442127228e-01
    z[3,8,0]  R1457     -7.6299661397933960e-01
    z[3,8,0]  R1458     -2.5040575861930847e-01
    z[3,8,0]  R1459     -4.8506896942853928e-02
    z[3,8,0]  R1460     3.9443102478981018e-01
    z[3,8,0]  R1461     -3.4812141209840775e-02
    z[3,8,0]  R1462     -6.8137490749359131e-01
    z[3,8,0]  R1463     -4.9739876389503479e-01
    z[3,8,0]  R1464     -7.7618694305419922e-01
    z[3,8,0]  R1465     -8.8468819856643677e-01
    z[3,8,0]  R1466     -8.9799350500106812e-01
    z[3,8,0]  R1467     -3.6623382568359375e-01
    z[3,8,0]  R1468     -8.2222521305084229e-01
    z[3,8,0]  R1469     -9.5417900010943413e-03
    z[3,8,0]  R1470     -5.6352788209915161e-01
    z[3,8,0]  R1471     -0.457535058259964
    z[3,8,0]  R1472     -4.6804243326187134e-01
    z[3,8,0]  R1473     -5.3360491991043091e-01
    z[3,8,0]  R1474     -9.5024204254150391e-01
    z[3,8,0]  R1475     -9.2259037494659424e-01
    z[3,8,0]  R1476     -8.5279864072799683e-01
    z[3,8,0]  R1477     -4.1459599137306213e-01
    z[3,8,0]  R1478     -1.6792495548725128e-01
    z[3,8,0]  R1479     -4.4118997454643250e-01
    z[3,8,0]  R1480     -5.4312908649444580e-01
    z[3,8,0]  R1481     -2.4107502773404121e-02
    z[3,8,0]  R1482     -4.8570921644568443e-03
    z[3,8,0]  R1483     -5.8970987796783447e-01
    z[3,8,0]  R1484     4.0796521306037903e-01
    z[3,8,0]  R1485     -8.3640134334564209e-01
    z[3,8,0]  R1486     -7.5629872083663940e-01
    z[3,8,0]  R1487     -2.3148091509938240e-02
    z[3,8,0]  R1488     -5.3866463899612427e-01
    z[3,8,0]  R1489     1.6193255782127380e-01
    z[3,8,0]  R1490     4.9023322761058807e-02
    z[3,8,0]  R1491     9.2316336929798126e-02
    z[3,8,0]  R1492     -9.0431171655654907e-01
    z[3,8,0]  R1493     -8.4467101097106934e-01
    z[3,8,0]  R1494     -3.7108820676803589e-01
    z[3,8,0]  R1495     -3.4779664874076843e-01
    z[3,8,0]  R1496     -1.0684672743082047e-01
    z[3,8,0]  R1497     -1.9758220016956329e-01
    z[3,8,0]  R1498     -5.0120222568511963e-01
    z[3,8,0]  R1499     3.2902139425277710e-01
    z[3,8,0]  R1500     3.8526329398155212e-01
    z[3,8,0]  R1501     -6.9628250598907471e-01
    z[3,8,0]  R1502     -9.1065317392349243e-01
    z[3,8,0]  R1503     -8.7985646724700928e-01
    z[3,8,0]  R1504     -8.5753923654556274e-01
    z[3,8,0]  R1505     -5.2138119935989380e-01
    z[3,8,0]  R1506     -0.281818151473999
    z[3,8,0]  R1507     -4.4188895821571350e-01
    z[3,8,0]  R1508     -4.0765147656202316e-02
    z[3,8,0]  R1509     7.3675704002380371e-01
    z[3,8,0]  R1510     1.0319972038269043e-01
    z[3,8,0]  R1511     6.3704389333724976e-01
    z[3,8,0]  R1512     3.2089483737945557e-01
    z[3,8,0]  R1513     4.4578793644905090e-01
    z[3,8,0]  R1514     8.4498089551925659e-01
    z[3,8,0]  R1515     5.0070625543594360e-01
    z[3,8,0]  R1516     5.7631397247314453e-01
    z[3,8,0]  R1517     6.8455582857131958e-01
    z[3,8,0]  R1518     -3.2613688707351685e-01
    z[3,8,0]  R1519     -1.6814163327217102e-01
    z[3,8,0]  R1520     -1.7515951395034790e-01
    z[3,8,0]  R1521     -2.4347655475139618e-02
    z[3,8,0]  R1522     -0.0678994357585907
    z[3,8,0]  R1523     -2.3351998627185822e-01
    z[3,8,0]  R1524     1.1257733404636383e-01
    z[3,8,0]  R1525     -2.7053564786911011e-01
    z[3,8,0]  R1526     -7.0400846004486084e-01
    z[3,8,0]  R1527     -5.1912359893321991e-02
    z[3,8,0]  R1528     3.8379433751106262e-01
    z[3,8,0]  R1529     -1.3053552806377411e-01
    z[3,8,0]  R1530     -1.2395630031824112e-01
    z[3,8,0]  R1531     -2.5183475017547607e-01
    z[3,8,0]  R1532     0.114784836769104
    z[3,8,0]  R1533     -4.0332657098770142e-01
    z[3,8,0]  R1534     3.3311915397644043e-01
    z[3,8,0]  R1535     0.347579687833786
    z[3,8,0]  R1536     5.9238141775131226e-01
    z[3,8,0]  R1537     -2.0692250132560730e-01
    z[3,8,0]  R1538     2.5033403187990189e-02
    z[3,8,0]  R1539     -2.5332754850387573e-01
    z[3,8,0]  R1540     -1.5056604752317071e-03
    z[3,8,0]  R1541     -2.8315967321395874e-01
    z[3,8,0]  R1542     4.8121601343154907e-02
    z[3,8,0]  R1543     4.5071363449096680e-01
    z[3,8,0]  R1544     -1.4257016777992249e-01
    z[3,8,0]  R1545     -4.2801958322525024e-01
    z[3,8,0]  R1546     -1.1250866204500198e-01
    z[3,8,0]  R1547     1.8788002431392670e-01
    z[3,8,0]  R1548     -2.6258345693349838e-02
    z[3,8,0]  R1549     -3.2672667503356934e-01
    z[3,8,0]  R1550     -4.8704558610916138e-01
    z[3,8,0]  R1551     -3.9662095904350281e-01
    z[3,8,0]  R1552     -3.9709344506263733e-01
    z[3,8,0]  R1553     2.8152653574943542e-01
    z[3,8,0]  R1554     -0.386346697807312
    z[3,8,0]  R1555     -5.3818565607070923e-01
    z[3,8,0]  R1556     -4.8915845155715942e-01
    z[3,8,0]  R1557     -3.6705833673477173e-01
    z[3,8,0]  R1558     5.6868660449981689e-01
    z[3,8,0]  R1559     -4.3744522333145142e-01
    z[3,8,0]  R1560     -6.1622118949890137e-01
    z[3,8,0]  R1561     1.5182720124721527e-01
    z[3,8,0]  R1562     2.2419843077659607e-01
    z[3,8,0]  R1563     4.1455361060798168e-03
    z[3,8,0]  R1564     -2.3684193193912506e-01
    z[3,8,0]  R1565     -3.7485834956169128e-01
    z[3,8,0]  R1566     -3.6465996503829956e-01
    z[3,8,0]  R1567     2.9203328490257263e-01
    z[3,8,0]  R1568     -6.6135597229003906e-01
    z[3,8,0]  R1569     3.9041861891746521e-01
    z[3,8,0]  R1570     0.06740702688694
    z[3,8,0]  R1571     -2.7967801690101624e-01
    z[3,8,0]  R1572     -7.1032392978668213e-01
    z[3,8,0]  R1573     5.2875989675521851e-01
    z[3,8,0]  R1574     3.4844768047332764e-01
    z[3,8,0]  R1575     2.0690768957138062e-01
    z[3,8,0]  R1576     -6.6474074125289917e-01
    z[3,8,0]  R1577     -5.2484017610549927e-01
    z[3,8,0]  R1578     2.9758960008621216e-01
    z[3,8,0]  R1579     -4.0893962979316711e-01
    z[3,8,0]  R1580     -3.6436259746551514e-01
    z[3,8,0]  R1581     4.1812849044799805e-01
    z[3,8,0]  R1582     7.8895963728427887e-02
    z[3,8,0]  R1583     3.8255488872528076e-01
    z[3,8,0]  R1584     -2.0790712535381317e-01
    z[3,8,0]  R1585     1.8902172148227692e-01
    z[3,8,0]  R1586     4.2085587978363037e-02
    z[3,8,0]  R1587     6.1813032627105713e-01
    z[3,8,0]  R1588     -4.4558876752853394e-01
    z[3,8,1]  R30       -1
    z[3,8,1]  R75       1
    z[3,8,1]  R1397     -1
    z[3,8,1]  R1398     1
    z[3,8,1]  R1409     1.3711350969970226e-02
    z[3,8,1]  R1410     5.4299894720315933e-02
    z[3,8,1]  R1411     2.4019737541675568e-01
    z[3,8,1]  R1412     3.7223255634307861e-01
    z[3,8,1]  R1413     2.8006935119628906e-01
    z[3,8,1]  R1414     3.9857888221740723e-01
    z[3,8,1]  R1415     4.2062580585479736e-01
    z[3,8,1]  R1416     -2.2349764406681061e-01
    z[3,8,1]  R1417     7.9020828008651733e-01
    z[3,8,1]  R1418     7.2798633575439453e-01
    z[3,8,1]  R1419     7.1584838628768921e-01
    z[3,8,1]  R1420     -2.1504734456539154e-01
    z[3,8,1]  R1421     6.5834307670593262e-01
    z[3,8,1]  R1422     6.4349353313446045e-01
    z[3,8,1]  R1423     8.0013543367385864e-02
    z[3,8,1]  R1424     5.5630236864089966e-01
    z[3,8,1]  R1425     5.1694333553314209e-01
    z[3,8,1]  R1426     1.1657485365867615e-01
    z[3,8,1]  R1427     1.8256975710391998e-01
    z[3,8,1]  R1428     0.0415816530585289
    z[3,8,1]  R1429     2.3756314814090729e-01
    z[3,8,1]  R1430     -2.9377132654190063e-02
    z[3,8,1]  R1431     -5.2666097879409790e-01
    z[3,8,1]  R1432     5.0524920225143433e-01
    z[3,8,1]  R1433     1.1464839428663254e-01
    z[3,8,1]  R1434     -1.9159886986017227e-02
    z[3,8,1]  R1435     4.8104834556579590e-01
    z[3,8,1]  R1436     4.5014080405235291e-01
    z[3,8,1]  R1437     -6.3170604407787323e-02
    z[3,8,1]  R1438     2.7494031190872192e-01
    z[3,8,1]  R1439     4.4470425695180893e-02
    z[3,8,1]  R1440     -9.6938237547874451e-03
    z[3,8,1]  R1441     4.1444137692451477e-01
    z[3,8,1]  R1442     5.4111951589584351e-01
    z[3,8,1]  R1443     0.627250611782074
    z[3,8,1]  R1444     5.6994384527206421e-01
    z[3,8,1]  R1445     -4.6652853488922119e-01
    z[3,8,1]  R1446     -5.2630335092544556e-01
    z[3,8,1]  R1447     4.4160258769989014e-01
    z[3,8,1]  R1448     -5.4234772920608521e-01
    z[3,8,1]  R1449     6.7723000049591064e-01
    z[3,8,1]  R1450     -4.7758162021636963e-02
    z[3,8,1]  R1451     -5.6062698364257812e-01
    z[3,8,1]  R1452     4.3963938951492310e-01
    z[3,8,1]  R1453     -1.6114315390586853e-01
    z[3,8,1]  R1454     -9.4882321357727051e-01
    z[3,8,1]  R1455     4.0067046880722046e-02
    z[3,8,1]  R1456     -9.2889207601547241e-01
    z[3,8,1]  R1457     -2.3473416268825531e-01
    z[3,8,1]  R1458     -9.0752846002578735e-01
    z[3,8,1]  R1459     7.4260032176971436e-01
    z[3,8,1]  R1460     -6.6749060153961182e-01
    z[3,8,1]  R1461     -4.7623196244239807e-01
    z[3,8,1]  R1462     6.0549920797348022e-01
    z[3,8,1]  R1463     4.7995755076408386e-01
    z[3,8,1]  R1464     -4.0013200044631958e-01
    z[3,8,1]  R1465     7.1967437863349915e-02
    z[3,8,1]  R1466     -8.7360413745045662e-03
    z[3,8,1]  R1467     6.3114196062088013e-02
    z[3,8,1]  R1468     6.9946028292179108e-02
    z[3,8,1]  R1469     7.9096013307571411e-01
    z[3,8,1]  R1470     6.5089470148086548e-01
    z[3,8,1]  R1471     5.2843958139419556e-01
    z[3,8,1]  R1472     1.1336542665958405e-01
    z[3,8,1]  R1473     5.1968789100646973e-01
    z[3,8,1]  R1474     -4.5264068990945816e-02
    z[3,8,1]  R1475     -5.3006079047918320e-02
    z[3,8,1]  R1476     2.8267037868499756e-01
    z[3,8,1]  R1477     1.7081966996192932e-01
    z[3,8,1]  R1478     -8.8181960582733154e-01
    z[3,8,1]  R1479     6.4701217412948608e-01
    z[3,8,1]  R1480     -1.5277132391929626e-01
    z[3,8,1]  R1481     5.6754022836685181e-01
    z[3,8,1]  R1482     1.6682486236095428e-01
    z[3,8,1]  R1483     1.8880617618560791e-01
    z[3,8,1]  R1484     0.492443710565567
    z[3,8,1]  R1485     -2.4261765182018280e-01
    z[3,8,1]  R1486     1.0084971785545349e-01
    z[3,8,1]  R1487     -8.7758040428161621e-01
    z[3,8,1]  R1488     -3.5370045900344849e-01
    z[3,8,1]  R1489     7.1731823682785034e-01
    z[3,8,1]  R1490     5.5955308675765991e-01
    z[3,8,1]  R1491     -1.5039165318012238e-01
    z[3,8,1]  R1492     -2.1676853299140930e-01
    z[3,8,1]  R1493     1.5709306299686432e-01
    z[3,8,1]  R1494     -6.6963976621627808e-01
    z[3,8,1]  R1495     -5.3933167457580566e-01
    z[3,8,1]  R1496     -7.8680831193923950e-01
    z[3,8,1]  R1497     -4.8667269945144653e-01
    z[3,8,1]  R1498     -5.3156054019927979e-01
    z[3,8,1]  R1499     6.9027435779571533e-01
    z[3,8,1]  R1500     -1.5281352400779724e-01
    z[3,8,1]  R1501     0.324432373046875
    z[3,8,1]  R1502     4.5422129333019257e-02
    z[3,8,1]  R1503     -2.6522394269704819e-02
    z[3,8,1]  R1504     1.5438407659530640e-01
    z[3,8,1]  R1505     -0.581614077091217
    z[3,8,1]  R1506     -5.1495635509490967e-01
    z[3,8,1]  R1507     -1.3446459174156189e-01
    z[3,8,1]  R1508     -5.9460699558258057e-01
    z[3,8,1]  R1509     0.30374675989151
    z[3,8,1]  R1510     7.4504172801971436e-01
    z[3,8,1]  R1511     1.7645424604415894e-01
    z[3,8,1]  R1512     0.712421178817749
    z[3,8,1]  R1513     3.6899831891059875e-01
    z[3,8,1]  R1514     5.9653103351593018e-02
    z[3,8,1]  R1515     5.5840945243835449e-01
    z[3,8,1]  R1516     4.7310832142829895e-01
    z[3,8,1]  R1517     1.8774619698524475e-01
    z[3,8,1]  R1518     0.708575427532196
    z[3,8,1]  R1519     -5.0860875844955444e-01
    z[3,8,1]  R1520     -5.9739941358566284e-01
    z[3,8,1]  R1521     -5.6169933080673218e-01
    z[3,8,1]  R1522     -4.4880822300910950e-01
    z[3,8,1]  R1523     -5.3318786621093750e-01
    z[3,8,1]  R1524     -5.1414120197296143e-01
    z[3,8,1]  R1525     -3.5053873062133789e-01
    z[3,8,1]  R1526     3.0828055739402771e-01
    z[3,8,1]  R1527     5.2129125595092773e-01
    z[3,8,1]  R1528     5.5241715908050537e-01
    z[3,8,1]  R1529     6.9651472568511963e-01
    z[3,8,1]  R1530     6.7883557081222534e-01
    z[3,8,1]  R1531     6.0026526451110840e-01
    z[3,8,1]  R1532     5.7415229082107544e-01
    z[3,8,1]  R1533     5.8584743738174438e-01
    z[3,8,1]  R1534     5.5500334501266479e-01
    z[3,8,1]  R1535     5.3615683317184448e-01
    z[3,8,1]  R1536     0.540215015411377
    z[3,8,1]  R1537     6.7617017030715942e-01
    z[3,8,1]  R1538     7.3270970582962036e-01
    z[3,8,1]  R1539     7.4011689424514771e-01
    z[3,8,1]  R1540     7.8080952167510986e-01
    z[3,8,1]  R1541     6.4962941408157349e-01
    z[3,8,1]  R1542     7.3950606584548950e-01
    z[3,8,1]  R1543     7.0295256376266479e-01
    z[3,8,1]  R1544     -0.282776415348053
    z[3,8,1]  R1545     6.5165388584136963e-01
    z[3,8,1]  R1546     -6.9621199369430542e-01
    z[3,8,1]  R1547     -6.2677758932113647e-01
    z[3,8,1]  R1548     -6.9244033098220825e-01
    z[3,8,1]  R1549     4.4207695126533508e-01
    z[3,8,1]  R1550     9.8487166687846184e-03
    z[3,8,1]  R1551     1.4604867994785309e-01
    z[3,8,1]  R1552     -1.7323195934295654e-01
    z[3,8,1]  R1553     4.5368626713752747e-01
    z[3,8,1]  R1554     9.7142502665519714e-02
    z[3,8,1]  R1555     -6.1505597829818726e-01
    z[3,8,1]  R1556     -5.5039227008819580e-01
    z[3,8,1]  R1557     3.2359874248504639e-01
    z[3,8,1]  R1558     -6.2403416633605957e-01
    z[3,8,1]  R1559     8.3767253160476685e-01
    z[3,8,1]  R1560     7.2170168161392212e-01
    z[3,8,1]  R1561     7.8799778223037720e-01
    z[3,8,1]  R1562     0.663337767124176
    z[3,8,1]  R1563     -5.2512373775243759e-02
    z[3,8,1]  R1564     4.7200858592987061e-01
    z[3,8,1]  R1565     3.7658709287643433e-01
    z[3,8,1]  R1566     1.6975344717502594e-01
    z[3,8,1]  R1567     2.2284699603915215e-02
    z[3,8,1]  R1568     -4.1852882504463196e-01
    z[3,8,1]  R1569     0.803875207901001
    z[3,8,1]  R1570     -1.5951721370220184e-01
    z[3,8,1]  R1571     0.295402467250824
    z[3,8,1]  R1572     1.3658988475799561e-01
    z[3,8,1]  R1573     -4.7057133913040161e-01
    z[3,8,1]  R1574     -7.8113985061645508e-01
    z[3,8,1]  R1575     -6.2176591157913208e-01
    z[3,8,1]  R1576     -3.1555432081222534e-01
    z[3,8,1]  R1577     -7.0497810840606689e-01
    z[3,8,1]  R1578     -1.9482684135437012e-01
    z[3,8,1]  R1579     -6.5725374221801758e-01
    z[3,8,1]  R1580     -5.3161764144897461e-01
    z[3,8,1]  R1581     -7.3614805936813354e-01
    z[3,8,1]  R1582     -5.2352142333984375e-01
    z[3,8,1]  R1583     -1.1451903730630875e-01
    z[3,8,1]  R1584     -1.9247953593730927e-01
    z[3,8,1]  R1585     -3.2207658886909485e-01
    z[3,8,1]  R1586     -3.2849270105361938e-01
    z[3,8,1]  R1587     -5.9491980075836182e-01
    z[3,8,1]  R1588     -3.0491960048675537e-01
    z[3,8,2]  R31       -1
    z[3,8,2]  R76       1
    z[3,8,2]  R1399     -1
    z[3,8,2]  R1400     1
    z[3,8,2]  R1409     0.388574481010437
    z[3,8,2]  R1410     2.4980668723583221e-01
    z[3,8,2]  R1411     6.0219585895538330e-01
    z[3,8,2]  R1412     3.8829341530799866e-01
    z[3,8,2]  R1413     1.6707780957221985e-01
    z[3,8,2]  R1414     4.4926857948303223e-01
    z[3,8,2]  R1415     3.8597890734672546e-01
    z[3,8,2]  R1416     1.4168396592140198e-01
    z[3,8,2]  R1417     0.345490425825119
    z[3,8,2]  R1418     5.9946954250335693e-01
    z[3,8,2]  R1419     -4.6438673138618469e-01
    z[3,8,2]  R1420     -0.453572154045105
    z[3,8,2]  R1421     -2.5681027770042419e-01
    z[3,8,2]  R1422     -6.0514993965625763e-02
    z[3,8,2]  R1423     -3.0757537484169006e-01
    z[3,8,2]  R1424     -1.1456935852766037e-01
    z[3,8,2]  R1425     -2.6502177119255066e-01
    z[3,8,2]  R1426     -3.3766967058181763e-01
    z[3,8,2]  R1427     -2.5241887569427490e-01
    z[3,8,2]  R1428     2.2210665047168732e-01
    z[3,8,2]  R1429     -4.0944731235504150e-01
    z[3,8,2]  R1430     6.3712793588638306e-01
    z[3,8,2]  R1431     -6.7614391446113586e-02
    z[3,8,2]  R1432     2.8389924764633179e-01
    z[3,8,2]  R1433     -2.0516772568225861e-01
    z[3,8,2]  R1434     -7.7193580567836761e-02
    z[3,8,2]  R1435     1.2833668291568756e-01
    z[3,8,2]  R1436     -4.6638140082359314e-01
    z[3,8,2]  R1437     3.0287280678749084e-01
    z[3,8,2]  R1438     2.8450208902359009e-01
    z[3,8,2]  R1439     3.0728485435247421e-02
    z[3,8,2]  R1440     1.0896039195358753e-02
    z[3,8,2]  R1441     1.4771074056625366e-01
    z[3,8,2]  R1442     4.6055087447166443e-01
    z[3,8,2]  R1443     -4.0463727712631226e-01
    z[3,8,2]  R1444     2.0238615572452545e-02
    z[3,8,2]  R1445     5.5145698785781860e-01
    z[3,8,2]  R1446     5.6918853521347046e-01
    z[3,8,2]  R1447     -5.7994669675827026e-01
    z[3,8,2]  R1448     2.2485144436359406e-01
    z[3,8,2]  R1449     -2.5433886051177979e-01
    z[3,8,2]  R1450     4.7333080321550369e-02
    z[3,8,2]  R1451     5.2712643146514893e-01
    z[3,8,2]  R1452     -3.9871567487716675e-01
    z[3,8,2]  R1453     -1.4094695448875427e-01
    z[3,8,2]  R1454     6.4704142510890961e-02
    z[3,8,2]  R1455     -3.2439496368169785e-02
    z[3,8,2]  R1456     3.1068574637174606e-02
    z[3,8,2]  R1457     1.6097691655158997e-01
    z[3,8,2]  R1458     2.4971139430999756e-01
    z[3,8,2]  R1459     6.2799811363220215e-02
    z[3,8,2]  R1460     1.2318023294210434e-01
    z[3,8,2]  R1461     0.424014687538147
    z[3,8,2]  R1462     0.0715944841504097
    z[3,8,2]  R1463     -2.9453590512275696e-01
    z[3,8,2]  R1464     7.6235704123973846e-02
    z[3,8,2]  R1465     1.3002495467662811e-01
    z[3,8,2]  R1466     -1.7952781915664673e-01
    z[3,8,2]  R1467     -0.280814528465271
    z[3,8,2]  R1468     2.7645226567983627e-02
    z[3,8,2]  R1469     -1.2493391335010529e-01
    z[3,8,2]  R1470     1.9838419556617737e-01
    z[3,8,2]  R1471     -0.488179087638855
    z[3,8,2]  R1472     -2.6554372906684875e-01
    z[3,8,2]  R1473     3.6922845244407654e-01
    z[3,8,2]  R1474     -0.0339483805000782
    z[3,8,2]  R1475     1.3924182951450348e-01
    z[3,8,2]  R1476     1.7402195930480957e-01
    z[3,8,2]  R1477     -1.2328878045082092e-01
    z[3,8,2]  R1478     -5.0941850990056992e-02
    z[3,8,2]  R1479     4.4459328055381775e-02
    z[3,8,2]  R1480     5.5610740184783936e-01
    z[3,8,2]  R1481     -1.8911378085613251e-01
    z[3,8,2]  R1482     -1.1785674095153809e-01
    z[3,8,2]  R1483     -2.0113836228847504e-01
    z[3,8,2]  R1484     -5.2802842855453491e-01
    z[3,8,2]  R1485     -5.6183699518442154e-02
    z[3,8,2]  R1486     3.6028262972831726e-01
    z[3,8,2]  R1487     -4.0361863374710083e-01
    z[3,8,2]  R1488     -6.0564011335372925e-01
    z[3,8,2]  R1489     1.1743155121803284e-01
    z[3,8,2]  R1490     -2.8917932510375977e-01
    z[3,8,2]  R1491     -1.1606529355049133e-01
    z[3,8,2]  R1492     -9.5972500275820494e-04
    z[3,8,2]  R1493     -1.6278178989887238e-01
    z[3,8,2]  R1494     -4.5483973622322083e-01
    z[3,8,2]  R1495     -4.7846508026123047e-01
    z[3,8,2]  R1496     2.9979849234223366e-02
    z[3,8,2]  R1497     -4.4776901602745056e-01
    z[3,8,2]  R1498     -3.7698981165885925e-01
    z[3,8,2]  R1499     -4.9701115489006042e-01
    z[3,8,2]  R1500     -2.9945635795593262e-01
    z[3,8,2]  R1501     -2.0904821157455444e-01
    z[3,8,2]  R1502     1.8929970264434814e-01
    z[3,8,2]  R1503     1.1313340812921524e-01
    z[3,8,2]  R1504     -1.4072303473949432e-01
    z[3,8,2]  R1505     -2.4279899895191193e-01
    z[3,8,2]  R1506     -5.3732901811599731e-01
    z[3,8,2]  R1507     -0.518753707408905
    z[3,8,2]  R1508     -6.6158592700958252e-01
    z[3,8,2]  R1509     5.7814067602157593e-01
    z[3,8,2]  R1510     1.7388562858104706e-01
    z[3,8,2]  R1511     7.1906256675720215e-01
    z[3,8,2]  R1512     3.2191246747970581e-01
    z[3,8,2]  R1513     7.6544874906539917e-01
    z[3,8,2]  R1514     0.505023717880249
    z[3,8,2]  R1515     6.0721164941787720e-01
    z[3,8,2]  R1516     6.0207647085189819e-01
    z[3,8,2]  R1517     6.1139428615570068e-01
    z[3,8,2]  R1518     3.8345783948898315e-01
    z[3,8,2]  R1519     -2.9519745148718357e-03
    z[3,8,2]  R1520     -8.7089262902736664e-02
    z[3,8,2]  R1521     -3.4792459011077881e-01
    z[3,8,2]  R1522     -2.7005153894424438e-01
    z[3,8,2]  R1523     1.1014468967914581e-01
    z[3,8,2]  R1524     -2.5249516963958740e-01
    z[3,8,2]  R1525     0.0291758980602026
    z[3,8,2]  R1526     -3.0748954415321350e-01
    z[3,8,2]  R1527     -3.1573307514190674e-01
    z[3,8,2]  R1528     -4.2549693584442139e-01
    z[3,8,2]  R1529     -3.6064156889915466e-01
    z[3,8,2]  R1530     -1.0769446939229965e-01
    z[3,8,2]  R1531     -1.9698448479175568e-01
    z[3,8,2]  R1532     -4.9072912335395813e-01
    z[3,8,2]  R1533     9.0174175798892975e-02
    z[3,8,2]  R1534     -5.2778005599975586e-01
    z[3,8,2]  R1535     -5.9519398212432861e-01
    z[3,8,2]  R1536     -3.6995080113410950e-01
    z[3,8,2]  R1537     -2.0785297453403473e-01
    z[3,8,2]  R1538     1.1789846420288086e-01
    z[3,8,2]  R1539     -3.0639493465423584e-01
    z[3,8,2]  R1540     4.8860549926757812e-02
    z[3,8,2]  R1541     -5.4658007621765137e-01
    z[3,8,2]  R1542     1.6758209466934204e-01
    z[3,8,2]  R1543     1.1022539436817169e-01
    z[3,8,2]  R1544     -8.1075555086135864e-01
    z[3,8,2]  R1545     1.1862143874168396e-01
    z[3,8,2]  R1546     -5.5827546119689941e-01
    z[3,8,2]  R1547     -6.7261105775833130e-01
    z[3,8,2]  R1548     -3.8340216875076294e-01
    z[3,8,2]  R1549     -5.7558870315551758e-01
    z[3,8,2]  R1550     -2.4053406715393066e-01
    z[3,8,2]  R1551     -3.0332398414611816e-01
    z[3,8,2]  R1552     -2.5991985201835632e-01
    z[3,8,2]  R1553     -9.3733951449394226e-02
    z[3,8,2]  R1554     -3.3817071467638016e-02
    z[3,8,2]  R1555     -4.5310333371162415e-01
    z[3,8,2]  R1556     -2.0347027480602264e-01
    z[3,8,2]  R1557     0.270241916179657
    z[3,8,2]  R1558     -3.4853389859199524e-01
    z[3,8,2]  R1559     3.8999080657958984e-02
    z[3,8,2]  R1560     -1.0526547580957413e-01
    z[3,8,2]  R1561     1.4102604985237122e-01
    z[3,8,2]  R1562     -3.3617219328880310e-01
    z[3,8,2]  R1563     -5.4828923940658569e-01
    z[3,8,2]  R1564     -4.7268554568290710e-01
    z[3,8,2]  R1565     -6.1010879278182983e-01
    z[3,8,2]  R1566     -2.1281237900257111e-01
    z[3,8,2]  R1567     -4.4417455792427063e-01
    z[3,8,2]  R1568     -1.3416640460491180e-01
    z[3,8,2]  R1569     -1.1298751085996628e-01
    z[3,8,2]  R1570     -4.2926058173179626e-01
    z[3,8,2]  R1571     -5.7679069042205811e-01
    z[3,8,2]  R1572     1.8374128639698029e-01
    z[3,8,2]  R1573     -3.8103365898132324e-01
    z[3,8,2]  R1574     -1.4756055176258087e-01
    z[3,8,2]  R1575     4.2118526995182037e-02
    z[3,8,2]  R1576     -0.535280704498291
    z[3,8,2]  R1577     2.7376702427864075e-01
    z[3,8,2]  R1578     -0.0871121808886528
    z[3,8,2]  R1579     -3.8658180832862854e-01
    z[3,8,2]  R1580     -5.9542137384414673e-01
    z[3,8,2]  R1581     -2.0386219024658203e-01
    z[3,8,2]  R1582     -9.4626814126968384e-02
    z[3,8,2]  R1583     -1.6701258718967438e-01
    z[3,8,2]  R1584     -1.1634702235460281e-01
    z[3,8,2]  R1585     3.6156069836579263e-04
    z[3,8,2]  R1586     1.2524689733982086e-01
    z[3,8,2]  R1587     -7.1765370666980743e-02
    z[3,8,2]  R1588     8.1551790237426758e-02
    z[3,8,3]  R32       -1
    z[3,8,3]  R77       1
    z[3,8,3]  R1401     -1
    z[3,8,3]  R1402     1
    z[3,8,3]  R1409     -2.1983437240123749e-01
    z[3,8,3]  R1410     -3.3784502744674683e-01
    z[3,8,3]  R1411     -2.1890088915824890e-01
    z[3,8,3]  R1412     1.0547752678394318e-01
    z[3,8,3]  R1413     3.8617804646492004e-02
    z[3,8,3]  R1414     -2.0519154146313667e-02
    z[3,8,3]  R1415     3.8928262889385223e-02
    z[3,8,3]  R1416     -3.7719801068305969e-01
    z[3,8,3]  R1417     -2.8920945525169373e-01
    z[3,8,3]  R1418     -2.4688212573528290e-01
    z[3,8,3]  R1419     2.2081515192985535e-01
    z[3,8,3]  R1420     5.5929505825042725e-01
    z[3,8,3]  R1421     2.4585790932178497e-01
    z[3,8,3]  R1422     6.1227369308471680e-01
    z[3,8,3]  R1423     -8.4651607275009155e-01
    z[3,8,3]  R1424     3.4073927998542786e-01
    z[3,8,3]  R1425     6.9690680503845215e-01
    z[3,8,3]  R1426     -5.2825736999511719e-01
    z[3,8,3]  R1427     -4.5570856332778931e-01
    z[3,8,3]  R1428     1.1839376389980316e-01
    z[3,8,3]  R1429     8.2410866022109985e-01
    z[3,8,3]  R1430     3.8797068595886230e-01
    z[3,8,3]  R1431     2.3541538417339325e-01
    z[3,8,3]  R1432     3.8441452383995056e-01
    z[3,8,3]  R1433     1.0509452782571316e-02
    z[3,8,3]  R1434     -1.1293182522058487e-01
    z[3,8,3]  R1435     2.7240052819252014e-01
    z[3,8,3]  R1436     -2.9375419020652771e-01
    z[3,8,3]  R1437     -4.5824725180864334e-02
    z[3,8,3]  R1438     1.9795901607722044e-03
    z[3,8,3]  R1439     6.7289197444915771e-01
    z[3,8,3]  R1440     6.0950154066085815e-01
    z[3,8,3]  R1441     4.7397544980049133e-01
    z[3,8,3]  R1442     4.8006868362426758e-01
    z[3,8,3]  R1443     2.0311798900365829e-02
    z[3,8,3]  R1444     -4.1097089648246765e-01
    z[3,8,3]  R1445     4.3353244662284851e-01
    z[3,8,3]  R1446     3.1306838989257812e-01
    z[3,8,3]  R1447     -3.0565026402473450e-01
    z[3,8,3]  R1448     2.4861592054367065e-01
    z[3,8,3]  R1449     8.8877469301223755e-02
    z[3,8,3]  R1450     -1.5399585664272308e-01
    z[3,8,3]  R1451     4.1052162647247314e-01
    z[3,8,3]  R1452     -2.8152248263359070e-01
    z[3,8,3]  R1453     7.5641043484210968e-02
    z[3,8,3]  R1454     -9.4083890318870544e-02
    z[3,8,3]  R1455     3.7302400916814804e-02
    z[3,8,3]  R1456     -6.9526262581348419e-02
    z[3,8,3]  R1457     -3.0936279892921448e-01
    z[3,8,3]  R1458     5.2418440580368042e-02
    z[3,8,3]  R1459     3.3702442049980164e-01
    z[3,8,3]  R1460     5.6980293989181519e-01
    z[3,8,3]  R1461     4.3843919038772583e-01
    z[3,8,3]  R1462     -3.5689270496368408e-01
    z[3,8,3]  R1463     -2.8074812889099121e-01
    z[3,8,3]  R1464     3.2118624448776245e-01
    z[3,8,3]  R1465     -3.9957201480865479e-01
    z[3,8,3]  R1466     2.8057834506034851e-01
    z[3,8,3]  R1467     -0.649041473865509
    z[3,8,3]  R1468     -9.9989846348762512e-02
    z[3,8,3]  R1469     1.8089847872033715e-03
    z[3,8,3]  R1470     8.7370024994015694e-04
    z[3,8,3]  R1471     -3.8883021473884583e-01
    z[3,8,3]  R1472     -6.4202928543090820e-01
    z[3,8,3]  R1473     2.5093883275985718e-01
    z[3,8,3]  R1474     1.7347642779350281e-01
    z[3,8,3]  R1475     -1.0311586409807205e-01
    z[3,8,3]  R1476     -1.5421982109546661e-01
    z[3,8,3]  R1477     -4.7485277056694031e-01
    z[3,8,3]  R1478     -3.8497611880302429e-01
    z[3,8,3]  R1479     -3.3683210611343384e-01
    z[3,8,3]  R1480     3.6364433169364929e-01
    z[3,8,3]  R1481     2.2673273086547852e-01
    z[3,8,3]  R1482     0.277258962392807
    z[3,8,3]  R1483     -5.7367360591888428e-01
    z[3,8,3]  R1484     8.6202420294284821e-02
    z[3,8,3]  R1485     -3.1494984030723572e-01
    z[3,8,3]  R1486     -1.5366628766059875e-01
    z[3,8,3]  R1487     -1.6533143818378448e-01
    z[3,8,3]  R1488     2.4333539605140686e-01
    z[3,8,3]  R1489     -4.1196337342262268e-01
    z[3,8,3]  R1490     5.6809765100479126e-01
    z[3,8,3]  R1491     -3.2596006989479065e-02
    z[3,8,3]  R1492     -2.0463606715202332e-01
    z[3,8,3]  R1493     -2.2062188386917114e-01
    z[3,8,3]  R1494     -4.1860058903694153e-01
    z[3,8,3]  R1495     -4.4509038329124451e-02
    z[3,8,3]  R1496     -3.3235767483711243e-01
    z[3,8,3]  R1497     -2.3991049826145172e-01
    z[3,8,3]  R1498     -3.9578244090080261e-01
    z[3,8,3]  R1499     -1.1740065366029739e-01
    z[3,8,3]  R1500     4.9503996968269348e-01
    z[3,8,3]  R1501     -5.5340075492858887e-01
    z[3,8,3]  R1502     -3.4102407097816467e-01
    z[3,8,3]  R1503     1.7385666072368622e-01
    z[3,8,3]  R1504     -2.4025362730026245e-01
    z[3,8,3]  R1505     -3.6551502346992493e-01
    z[3,8,3]  R1506     1.0349040478467941e-01
    z[3,8,3]  R1507     -1.5072527341544628e-02
    z[3,8,3]  R1508     1.3338880613446236e-02
    z[3,8,3]  R1509     5.1857795566320419e-02
    z[3,8,3]  R1510     1.8211877346038818e-01
    z[3,8,3]  R1511     1.1691156774759293e-01
    z[3,8,3]  R1512     -1.8961118161678314e-01
    z[3,8,3]  R1513     1.5626855194568634e-01
    z[3,8,3]  R1514     -8.3744160830974579e-02
    z[3,8,3]  R1515     1.5992085635662079e-01
    z[3,8,3]  R1516     -2.7161669731140137e-01
    z[3,8,3]  R1517     -1.2416200339794159e-01
    z[3,8,3]  R1518     3.6150798201560974e-02
    z[3,8,3]  R1519     -7.4238038063049316e-01
    z[3,8,3]  R1520     -3.5980746150016785e-01
    z[3,8,3]  R1521     -5.8321952819824219e-01
    z[3,8,3]  R1522     -2.1688893437385559e-01
    z[3,8,3]  R1523     -4.7954815626144409e-01
    z[3,8,3]  R1524     -5.9930962324142456e-01
    z[3,8,3]  R1525     -3.8831308484077454e-01
    z[3,8,3]  R1526     -5.0890469551086426e-01
    z[3,8,3]  R1527     -2.4170038104057312e-01
    z[3,8,3]  R1528     -3.9172795414924622e-01
    z[3,8,3]  R1529     1.9254611432552338e-01
    z[3,8,3]  R1530     2.5090974569320679e-01
    z[3,8,3]  R1531     2.9566147923469543e-01
    z[3,8,3]  R1532     -2.8940621018409729e-01
    z[3,8,3]  R1533     0.402680367231369
    z[3,8,3]  R1534     4.0484678745269775e-01
    z[3,8,3]  R1535     1.3354191184043884e-01
    z[3,8,3]  R1536     3.8730335235595703e-01
    z[3,8,3]  R1537     -0.429853230714798
    z[3,8,3]  R1538     -4.6079343557357788e-01
    z[3,8,3]  R1539     -3.1336975097656250e-01
    z[3,8,3]  R1540     -1.7450611293315887e-01
    z[3,8,3]  R1541     -2.0374611020088196e-01
    z[3,8,3]  R1542     4.9226158857345581e-01
    z[3,8,3]  R1543     -1.2572954595088959e-01
    z[3,8,3]  R1544     -3.4273895621299744e-01
    z[3,8,3]  R1545     1.3936059176921844e-01
    z[3,8,3]  R1546     1.9586777687072754e-01
    z[3,8,3]  R1547     1.9571746885776520e-01
    z[3,8,3]  R1548     4.9618965387344360e-01
    z[3,8,3]  R1549     -2.1210125088691711e-01
    z[3,8,3]  R1550     -0.767402708530426
    z[3,8,3]  R1551     -5.0298583507537842e-01
    z[3,8,3]  R1552     2.3538877069950104e-01
    z[3,8,3]  R1553     2.0210632681846619e-01
    z[3,8,3]  R1554     -7.3404544591903687e-01
    z[3,8,3]  R1555     -0.00976675283163786
    z[3,8,3]  R1556     -7.7435187995433807e-02
    z[3,8,3]  R1557     -7.9551786184310913e-01
    z[3,8,3]  R1558     1.9590778648853302e-01
    z[3,8,3]  R1559     -1.2370344996452332e-01
    z[3,8,3]  R1560     -1.1679595708847046e-01
    z[3,8,3]  R1561     -2.1719770133495331e-01
    z[3,8,3]  R1562     -1.4076061546802521e-01
    z[3,8,3]  R1563     -6.8923436105251312e-02
    z[3,8,3]  R1564     -4.8576775938272476e-02
    z[3,8,3]  R1565     -5.0221878290176392e-01
    z[3,8,3]  R1566     -7.7450329065322876e-01
    z[3,8,3]  R1567     -4.3196612596511841e-01
    z[3,8,3]  R1568     -3.6524653434753418e-02
    z[3,8,3]  R1569     -9.0609379112720490e-02
    z[3,8,3]  R1570     -7.5901877880096436e-01
    z[3,8,3]  R1571     -5.9787321090698242e-01
    z[3,8,3]  R1572     -5.1823216676712036e-01
    z[3,8,3]  R1573     2.4977408349514008e-01
    z[3,8,3]  R1574     1.6055627167224884e-01
    z[3,8,3]  R1575     0.374318391084671
    z[3,8,3]  R1576     2.2835499048233032e-01
    z[3,8,3]  R1577     2.3273542523384094e-01
    z[3,8,3]  R1578     8.0029904842376709e-01
    z[3,8,3]  R1579     -1.9853542745113373e-01
    z[3,8,3]  R1580     -2.3308378458023071e-01
    z[3,8,3]  R1581     1.1561270803213120e-01
    z[3,8,3]  R1582     4.7575098276138306e-01
    z[3,8,3]  R1583     6.0858130455017090e-01
    z[3,8,3]  R1584     8.5577911138534546e-01
    z[3,8,3]  R1585     0.516191840171814
    z[3,8,3]  R1586     0.539966881275177
    z[3,8,3]  R1587     1.7886368930339813e-01
    z[3,8,3]  R1588     5.5466693639755249e-01
    z[3,8,4]  R33       -1
    z[3,8,4]  R78       1
    z[3,8,4]  R1403     -1
    z[3,8,4]  R1404     1
    z[3,8,4]  R1409     3.6975425481796265e-01
    z[3,8,4]  R1410     0.0836007222533226
    z[3,8,4]  R1411     2.7925944328308105e-01
    z[3,8,4]  R1412     1.6411504149436951e-01
    z[3,8,4]  R1413     -1.3834075629711151e-01
    z[3,8,4]  R1414     9.8664209246635437e-02
    z[3,8,4]  R1415     -1.6533695161342621e-01
    z[3,8,4]  R1416     -2.0861823856830597e-01
    z[3,8,4]  R1417     -2.3871515691280365e-01
    z[3,8,4]  R1418     -6.3319101929664612e-02
    z[3,8,4]  R1419     4.0838193893432617e-01
    z[3,8,4]  R1420     -1.8973509967327118e-01
    z[3,8,4]  R1421     3.4369704127311707e-01
    z[3,8,4]  R1422     -1.2840871512889862e-01
    z[3,8,4]  R1423     2.6399930939078331e-02
    z[3,8,4]  R1424     -2.5398489832878113e-01
    z[3,8,4]  R1425     -1.4980722218751907e-02
    z[3,8,4]  R1426     2.6581141352653503e-01
    z[3,8,4]  R1427     -5.2717506885528564e-01
    z[3,8,4]  R1428     -2.4696613848209381e-01
    z[3,8,4]  R1429     -2.6409873366355896e-01
    z[3,8,4]  R1430     -2.9159709811210632e-01
    z[3,8,4]  R1431     -4.9763542413711548e-01
    z[3,8,4]  R1432     -2.1162109076976776e-01
    z[3,8,4]  R1433     -3.0046626925468445e-01
    z[3,8,4]  R1434     -1.0412283986806870e-01
    z[3,8,4]  R1435     1.2374614179134369e-01
    z[3,8,4]  R1436     -5.5735909938812256e-01
    z[3,8,4]  R1437     -2.5431391596794128e-01
    z[3,8,4]  R1438     2.7516716718673706e-01
    z[3,8,4]  R1439     1.2355333566665649e-01
    z[3,8,4]  R1440     -3.3346304297447205e-01
    z[3,8,4]  R1441     -0.394437313079834
    z[3,8,4]  R1442     -2.4966441094875336e-01
    z[3,8,4]  R1443     3.9922407269477844e-01
    z[3,8,4]  R1444     4.2915868759155273e-01
    z[3,8,4]  R1445     1.0579667240381241e-01
    z[3,8,4]  R1446     -0.181906595826149
    z[3,8,4]  R1447     -7.3114745318889618e-02
    z[3,8,4]  R1448     -1.4692904055118561e-01
    z[3,8,4]  R1449     -4.5659685134887695e-01
    z[3,8,4]  R1450     1.6165295243263245e-01
    z[3,8,4]  R1451     -1.6063414514064789e-01
    z[3,8,4]  R1452     -4.8005864024162292e-01
    z[3,8,4]  R1453     3.8883373141288757e-02
    z[3,8,4]  R1454     1.1996621638536453e-01
    z[3,8,4]  R1455     3.7625020742416382e-01
    z[3,8,4]  R1456     3.4751359373331070e-02
    z[3,8,4]  R1457     4.7478446364402771e-01
    z[3,8,4]  R1458     -1.5053851902484894e-01
    z[3,8,4]  R1459     -2.2645914554595947e-01
    z[3,8,4]  R1460     -5.7060797698795795e-03
    z[3,8,4]  R1461     -7.6822616159915924e-02
    z[3,8,4]  R1462     2.1029409021139145e-02
    z[3,8,4]  R1463     1.8492749333381653e-01
    z[3,8,4]  R1464     -1.1500279605388641e-01
    z[3,8,4]  R1465     6.0783304274082184e-02
    z[3,8,4]  R1466     7.0928357541561127e-02
    z[3,8,4]  R1467     -0.42122882604599
    z[3,8,4]  R1468     1.3787874579429626e-01
    z[3,8,4]  R1469     2.6096263527870178e-01
    z[3,8,4]  R1470     -0.16848124563694
    z[3,8,4]  R1471     3.8658101111650467e-02
    z[3,8,4]  R1472     -4.1916516423225403e-01
    z[3,8,4]  R1473     4.3393567204475403e-01
    z[3,8,4]  R1474     2.7704099193215370e-02
    z[3,8,4]  R1475     3.0394849181175232e-01
    z[3,8,4]  R1476     -2.5828543305397034e-01
    z[3,8,4]  R1477     3.7149384617805481e-01
    z[3,8,4]  R1478     4.7176092863082886e-02
    z[3,8,4]  R1479     -2.7131193876266479e-01
    z[3,8,4]  R1480     -2.9805478453636169e-01
    z[3,8,4]  R1481     -6.0237679630517960e-02
    z[3,8,4]  R1482     -6.2752211093902588e-01
    z[3,8,4]  R1483     1.4327786862850189e-01
    z[3,8,4]  R1484     -4.9175915122032166e-01
    z[3,8,4]  R1485     -9.4972558319568634e-02
    z[3,8,4]  R1486     9.8763778805732727e-02
    z[3,8,4]  R1487     -1.2358006834983826e-01
    z[3,8,4]  R1488     8.0499485135078430e-02
    z[3,8,4]  R1489     2.8234642744064331e-01
    z[3,8,4]  R1490     9.6305571496486664e-02
    z[3,8,4]  R1491     -7.1907705068588257e-01
    z[3,8,4]  R1492     -1.6345153562724590e-03
    z[3,8,4]  R1493     -2.5797012448310852e-01
    z[3,8,4]  R1494     -1.1582937091588974e-01
    z[3,8,4]  R1495     2.3507069051265717e-01
    z[3,8,4]  R1496     -1.5902440249919891e-01
    z[3,8,4]  R1497     -1.6797071322798729e-02
    z[3,8,4]  R1498     1.1166515201330185e-01
    z[3,8,4]  R1499     -2.2787198424339294e-01
    z[3,8,4]  R1500     -1.4868468046188354e-01
    z[3,8,4]  R1501     -3.1543251127004623e-02
    z[3,8,4]  R1502     4.9308642745018005e-02
    z[3,8,4]  R1503     3.4621319174766541e-01
    z[3,8,4]  R1504     -2.5849640369415283e-01
    z[3,8,4]  R1505     2.3924781382083893e-01
    z[3,8,4]  R1506     1.4420378953218460e-02
    z[3,8,4]  R1507     -0.0878065750002861
    z[3,8,4]  R1508     4.0671084076166153e-02
    z[3,8,4]  R1509     -3.0929857864975929e-02
    z[3,8,4]  R1510     4.3862223625183105e-02
    z[3,8,4]  R1511     -7.1362167596817017e-02
    z[3,8,4]  R1512     3.4079080820083618e-01
    z[3,8,4]  R1513     -0.17815001308918
    z[3,8,4]  R1514     -5.3338829427957535e-02
    z[3,8,4]  R1515     1.8202421069145203e-01
    z[3,8,4]  R1516     -1.1549197370186448e-03
    z[3,8,4]  R1517     1.7097112536430359e-01
    z[3,8,4]  R1518     1.6588468849658966e-01
    z[3,8,4]  R1519     -1.0755776613950729e-01
    z[3,8,4]  R1520     -3.3011589199304581e-02
    z[3,8,4]  R1521     1.8318261206150055e-01
    z[3,8,4]  R1522     -0.0909905806183815
    z[3,8,4]  R1523     -1.9154475629329681e-01
    z[3,8,4]  R1524     -1.0848290473222733e-01
    z[3,8,4]  R1525     -1.0991883277893066e-01
    z[3,8,4]  R1526     5.4228086024522781e-02
    z[3,8,4]  R1527     3.8252902030944824e-01
    z[3,8,4]  R1528     -4.4202274084091187e-01
    z[3,8,4]  R1529     -2.9359623789787292e-01
    z[3,8,4]  R1530     2.5340250134468079e-01
    z[3,8,4]  R1531     -2.7820026874542236e-01
    z[3,8,4]  R1532     2.5382417440414429e-01
    z[3,8,4]  R1533     -7.9937517642974854e-02
    z[3,8,4]  R1534     -3.2220691442489624e-01
    z[3,8,4]  R1535     3.4887593239545822e-02
    z[3,8,4]  R1536     5.7678680866956711e-02
    z[3,8,4]  R1537     -3.5977670550346375e-01
    z[3,8,4]  R1538     -1.0594666749238968e-01
    z[3,8,4]  R1539     1.8152515590190887e-01
    z[3,8,4]  R1540     -3.5370573401451111e-01
    z[3,8,4]  R1541     -7.6284185051918030e-02
    z[3,8,4]  R1542     -2.6278996467590332e-01
    z[3,8,4]  R1543     -5.0045949220657349e-01
    z[3,8,4]  R1544     9.5087058842182159e-02
    z[3,8,4]  R1545     1.3192920386791229e-01
    z[3,8,4]  R1546     -3.7163820862770081e-01
    z[3,8,4]  R1547     -1.5029367804527283e-01
    z[3,8,4]  R1548     -1.3495387136936188e-01
    z[3,8,4]  R1549     -2.0871834456920624e-01
    z[3,8,4]  R1550     1.8678975105285645e-01
    z[3,8,4]  R1551     2.5995094329118729e-02
    z[3,8,4]  R1552     2.8754368424415588e-01
    z[3,8,4]  R1553     2.7865159511566162e-01
    z[3,8,4]  R1554     -7.7265299856662750e-02
    z[3,8,4]  R1555     3.5431340336799622e-01
    z[3,8,4]  R1556     1.9545695185661316e-01
    z[3,8,4]  R1557     5.7299785315990448e-02
    z[3,8,4]  R1558     -8.0676466226577759e-02
    z[3,8,4]  R1559     7.4233666062355042e-02
    z[3,8,4]  R1560     -2.9526667669415474e-02
    z[3,8,4]  R1561     -1.7548096179962158e-01
    z[3,8,4]  R1562     -2.5313866138458252e-01
    z[3,8,4]  R1563     3.1068675220012665e-02
    z[3,8,4]  R1564     6.0402441024780273e-01
    z[3,8,4]  R1565     -2.0315755903720856e-01
    z[3,8,4]  R1566     -1.1944981664419174e-01
    z[3,8,4]  R1567     -3.3345988392829895e-01
    z[3,8,4]  R1568     4.9226564168930054e-01
    z[3,8,4]  R1569     0.192902609705925
    z[3,8,4]  R1570     -1.0200403630733490e-01
    z[3,8,4]  R1571     2.3301427066326141e-01
    z[3,8,4]  R1572     -3.9524596929550171e-01
    z[3,8,4]  R1573     -2.6711821556091309e-01
    z[3,8,4]  R1574     -4.3883770704269409e-01
    z[3,8,4]  R1575     -5.2055913209915161e-01
    z[3,8,4]  R1576     -7.5289912521839142e-02
    z[3,8,4]  R1577     -1.4688414335250854e-01
    z[3,8,4]  R1578     -4.3398797512054443e-01
    z[3,8,4]  R1579     3.2364809513092041e-01
    z[3,8,4]  R1580     3.2094126939773560e-01
    z[3,8,4]  R1581     -4.4822499155998230e-01
    z[3,8,4]  R1582     -5.5237084627151489e-01
    z[3,8,4]  R1583     -4.7012698650360107e-01
    z[3,8,4]  R1584     -3.3907783031463623e-01
    z[3,8,4]  R1585     -3.8905680179595947e-01
    z[3,8,4]  R1586     -3.0298039317131042e-01
    z[3,8,4]  R1587     5.9135757386684418e-02
    z[3,8,4]  R1588     -2.5848689675331116e-01
    z[3,8,5]  R34       -1
    z[3,8,5]  R79       1
    z[3,8,5]  R1405     -1
    z[3,8,5]  R1406     1
    z[3,8,5]  R1409     3.3980527520179749e-01
    z[3,8,5]  R1410     0.486115425825119
    z[3,8,5]  R1411     9.7025007009506226e-02
    z[3,8,5]  R1412     2.9867282509803772e-01
    z[3,8,5]  R1413     4.1259261965751648e-01
    z[3,8,5]  R1414     4.1188114881515503e-01
    z[3,8,5]  R1415     -0.074520044028759
    z[3,8,5]  R1416     -1.9655311107635498e-01
    z[3,8,5]  R1417     -2.0525650680065155e-01
    z[3,8,5]  R1418     0.0744505226612091
    z[3,8,5]  R1419     -9.6932850778102875e-02
    z[3,8,5]  R1420     -6.0361623764038086e-01
    z[3,8,5]  R1421     2.6354864239692688e-01
    z[3,8,5]  R1422     2.4786043167114258e-01
    z[3,8,5]  R1423     1.6977612674236298e-01
    z[3,8,5]  R1424     -9.4695478677749634e-02
    z[3,8,5]  R1425     -2.2654792666435242e-01
    z[3,8,5]  R1426     -2.9492089152336121e-01
    z[3,8,5]  R1427     3.2390865683555603e-01
    z[3,8,5]  R1428     -8.4928011894226074e-01
    z[3,8,5]  R1429     -1.0813717544078827e-01
    z[3,8,5]  R1430     -2.7280244231224060e-01
    z[3,8,5]  R1431     -4.6663495898246765e-01
    z[3,8,5]  R1432     -5.3795474767684937e-01
    z[3,8,5]  R1433     -1.1047238111495972e-01
    z[3,8,5]  R1434     1.4906586706638336e-01
    z[3,8,5]  R1435     -7.2340106964111328e-01
    z[3,8,5]  R1436     0.17389015853405
    z[3,8,5]  R1437     1.3917692005634308e-01
    z[3,8,5]  R1438     -2.3230737075209618e-02
    z[3,8,5]  R1439     -7.0192688703536987e-01
    z[3,8,5]  R1440     -3.6358866095542908e-01
    z[3,8,5]  R1441     -5.8569401502609253e-01
    z[3,8,5]  R1442     -4.0828722715377808e-01
    z[3,8,5]  R1443     3.3582428097724915e-01
    z[3,8,5]  R1444     1.7942123115062714e-01
    z[3,8,5]  R1445     -4.3635964393615723e-01
    z[3,8,5]  R1446     -4.8830467462539673e-01
    z[3,8,5]  R1447     -1.7145806550979614e-01
    z[3,8,5]  R1448     -4.1066142916679382e-01
    z[3,8,5]  R1449     6.2644377350807190e-02
    z[3,8,5]  R1450     -1.7560601234436035e-01
    z[3,8,5]  R1451     -0.392000675201416
    z[3,8,5]  R1452     1.3934718072414398e-01
    z[3,8,5]  R1453     -3.3349204063415527e-01
    z[3,8,5]  R1454     -1.2825973331928253e-01
    z[3,8,5]  R1455     4.3615409731864929e-01
    z[3,8,5]  R1456     2.9254710674285889e-01
    z[3,8,5]  R1457     -0.0223592147231102
    z[3,8,5]  R1458     1.2361817806959152e-01
    z[3,8,5]  R1459     4.9798870086669922e-01
    z[3,8,5]  R1460     -0.242364302277565
    z[3,8,5]  R1461     -6.2602925300598145e-01
    z[3,8,5]  R1462     1.8952375650405884e-01
    z[3,8,5]  R1463     -5.4515582323074341e-01
    z[3,8,5]  R1464     -3.3561038970947266e-01
    z[3,8,5]  R1465     1.5446986258029938e-01
    z[3,8,5]  R1466     2.5392949581146240e-01
    z[3,8,5]  R1467     -3.6997672915458679e-01
    z[3,8,5]  R1468     5.0624340772628784e-01
    z[3,8,5]  R1469     4.5626637339591980e-01
    z[3,8,5]  R1470     4.2337018251419067e-01
    z[3,8,5]  R1471     -3.2346537709236145e-01
    z[3,8,5]  R1472     -3.3001348376274109e-01
    z[3,8,5]  R1473     -1.9071669876575470e-01
    z[3,8,5]  R1474     -2.1720662713050842e-02
    z[3,8,5]  R1475     1.8512552604079247e-02
    z[3,8,5]  R1476     2.5458592176437378e-01
    z[3,8,5]  R1477     3.2484656572341919e-01
    z[3,8,5]  R1478     9.8366884049028158e-04
    z[3,8,5]  R1479     3.3701050281524658e-01
    z[3,8,5]  R1480     -3.8555371761322021e-01
    z[3,8,5]  R1481     -5.9404969215393066e-01
    z[3,8,5]  R1482     -4.4391539692878723e-01
    z[3,8,5]  R1483     -4.4910570979118347e-01
    z[3,8,5]  R1484     -1.1908382177352905e-01
    z[3,8,5]  R1485     -3.5017880797386169e-01
    z[3,8,5]  R1486     -3.3454936742782593e-01
    z[3,8,5]  R1487     -1.4463682472705841e-01
    z[3,8,5]  R1488     3.1754285097122192e-01
    z[3,8,5]  R1489     -1.9783751666545868e-01
    z[3,8,5]  R1490     -3.1333526968955994e-01
    z[3,8,5]  R1491     -6.5661799907684326e-01
    z[3,8,5]  R1492     -0.303000271320343
    z[3,8,5]  R1493     3.2724419236183167e-01
    z[3,8,5]  R1494     1.0442462563514709e-01
    z[3,8,5]  R1495     5.4920810461044312e-01
    z[3,8,5]  R1496     3.1957671046257019e-01
    z[3,8,5]  R1497     6.4711350202560425e-01
    z[3,8,5]  R1498     1.8048487603664398e-01
    z[3,8,5]  R1499     -3.1513166427612305e-01
    z[3,8,5]  R1500     -6.5260219573974609e-01
    z[3,8,5]  R1501     -1.8633204698562622e-01
    z[3,8,5]  R1502     -1.1351475864648819e-01
    z[3,8,5]  R1503     -2.0502893626689911e-01
    z[3,8,5]  R1504     2.9521077871322632e-01
    z[3,8,5]  R1505     3.3200421929359436e-01
    z[3,8,5]  R1506     0.461311936378479
    z[3,8,5]  R1507     6.2382197380065918e-01
    z[3,8,5]  R1508     4.1954675316810608e-01
    z[3,8,5]  R1509     -7.0518068969249725e-02
    z[3,8,5]  R1510     2.9320802539587021e-02
    z[3,8,5]  R1511     1.6049274802207947e-01
    z[3,8,5]  R1512     9.7442999482154846e-02
    z[3,8,5]  R1513     1.2150280922651291e-01
    z[3,8,5]  R1514     6.1087656766176224e-02
    z[3,8,5]  R1515     -8.9247547090053558e-02
    z[3,8,5]  R1516     8.4644109010696411e-02
    z[3,8,5]  R1517     2.7353477478027344e-01
    z[3,8,5]  R1518     4.0036666393280029e-01
    z[3,8,5]  R1519     3.6903893947601318e-01
    z[3,8,5]  R1520     6.8073374032974243e-01
    z[3,8,5]  R1521     4.3479007482528687e-01
    z[3,8,5]  R1522     8.1305164098739624e-01
    z[3,8,5]  R1523     5.3321695327758789e-01
    z[3,8,5]  R1524     4.6339431405067444e-01
    z[3,8,5]  R1525     5.6345325708389282e-01
    z[3,8,5]  R1526     -2.1080057322978973e-01
    z[3,8,5]  R1527     -0.598402738571167
    z[3,8,5]  R1528     1.0290031135082245e-01
    z[3,8,5]  R1529     -4.8102951049804688e-01
    z[3,8,5]  R1530     2.3012389242649078e-01
    z[3,8,5]  R1531     4.5984706282615662e-01
    z[3,8,5]  R1532     1.4776639640331268e-01
    z[3,8,5]  R1533     -5.0973349809646606e-01
    z[3,8,5]  R1534     1.6818402707576752e-01
    z[3,8,5]  R1535     -3.8613748550415039e-01
    z[3,8,5]  R1536     2.5651791691780090e-01
    z[3,8,5]  R1537     -2.0864118635654449e-01
    z[3,8,5]  R1538     2.4168965220451355e-01
    z[3,8,5]  R1539     3.4985315799713135e-01
    z[3,8,5]  R1540     0.411308616399765
    z[3,8,5]  R1541     1.1703790724277496e-01
    z[3,8,5]  R1542     -3.2389920949935913e-01
    z[3,8,5]  R1543     -0.0661073550581932
    z[3,8,5]  R1544     2.2231031954288483e-01
    z[3,8,5]  R1545     -2.4207718670368195e-01
    z[3,8,5]  R1546     -6.9456794299185276e-03
    z[3,8,5]  R1547     4.4466793537139893e-02
    z[3,8,5]  R1548     2.6548272371292114e-01
    z[3,8,5]  R1549     -2.4890737235546112e-01
    z[3,8,5]  R1550     -2.2501491010189056e-01
    z[3,8,5]  R1551     -1.0241493582725525e-01
    z[3,8,5]  R1552     7.6932793855667114e-01
    z[3,8,5]  R1553     7.6607394218444824e-01
    z[3,8,5]  R1554     8.9728303253650665e-02
    z[3,8,5]  R1555     -3.3832769840955734e-03
    z[3,8,5]  R1556     2.5807055830955505e-01
    z[3,8,5]  R1557     -2.2562643885612488e-01
    z[3,8,5]  R1558     1.8531037867069244e-01
    z[3,8,5]  R1559     -1.9545707106590271e-01
    z[3,8,5]  R1560     -1.3591052591800690e-01
    z[3,8,5]  R1561     -1.4011819660663605e-01
    z[3,8,5]  R1562     -5.3619122505187988e-01
    z[3,8,5]  R1563     8.0709677934646606e-01
    z[3,8,5]  R1564     -1.8276451528072357e-01
    z[3,8,5]  R1565     -1.6230879724025726e-01
    z[3,8,5]  R1566     2.7760567143559456e-02
    z[3,8,5]  R1567     6.0488367080688477e-01
    z[3,8,5]  R1568     3.2660558819770813e-01
    z[3,8,5]  R1569     3.5799962282180786e-01
    z[3,8,5]  R1570     4.3259340524673462e-01
    z[3,8,5]  R1571     -2.1127325296401978e-01
    z[3,8,5]  R1572     1.3093756139278412e-01
    z[3,8,5]  R1573     3.7043792009353638e-01
    z[3,8,5]  R1574     -0.0495392307639122
    z[3,8,5]  R1575     3.2732561230659485e-01
    z[3,8,5]  R1576     -2.2811965644359589e-01
    z[3,8,5]  R1577     -2.7723529934883118e-01
    z[3,8,5]  R1578     -1.8648815155029297e-01
    z[3,8,5]  R1579     3.0621299147605896e-01
    z[3,8,5]  R1580     1.3879445195198059e-01
    z[3,8,5]  R1581     1.6501431167125702e-01
    z[3,8,5]  R1582     3.9671370387077332e-01
    z[3,8,5]  R1583     -4.4743424654006958e-01
    z[3,8,5]  R1584     -2.1514873206615448e-01
    z[3,8,5]  R1585     -6.6480213403701782e-01
    z[3,8,5]  R1586     -7.0080637931823730e-01
    z[3,8,5]  R1587     5.6166354566812515e-02
    z[3,8,5]  R1588     -0.560685932636261
    z[3,8,6]  R35       -1
    z[3,8,6]  R80       1
    z[3,8,6]  R1407     -1
    z[3,8,6]  R1408     1
    z[3,8,6]  R1409     -1.1921192705631256e-01
    z[3,8,6]  R1410     -1.0565267503261566e-01
    z[3,8,6]  R1411     -1.8575143814086914e-01
    z[3,8,6]  R1412     -1.1226785928010941e-01
    z[3,8,6]  R1413     -2.7282893657684326e-01
    z[3,8,6]  R1414     -3.4772503376007080e-01
    z[3,8,6]  R1415     -1.6278398036956787e-01
    z[3,8,6]  R1416     -3.4013012051582336e-01
    z[3,8,6]  R1417     -2.7045345306396484e-01
    z[3,8,6]  R1418     2.0042194426059723e-01
    z[3,8,6]  R1419     -2.1347667276859283e-01
    z[3,8,6]  R1420     7.5314551591873169e-02
    z[3,8,6]  R1421     4.8321974277496338e-01
    z[3,8,6]  R1422     2.0423837006092072e-01
    z[3,8,6]  R1423     -2.2396599873900414e-02
    z[3,8,6]  R1424     6.8618965148925781e-01
    z[3,8,6]  R1425     3.4243202209472656e-01
    z[3,8,6]  R1426     -1.0500402003526688e-01
    z[3,8,6]  R1427     1.4225970208644867e-01
    z[3,8,6]  R1428     -8.8078305125236511e-02
    z[3,8,6]  R1429     1.0345313698053360e-01
    z[3,8,6]  R1430     -6.8595241755247116e-03
    z[3,8,6]  R1431     -4.4258746504783630e-01
    z[3,8,6]  R1432     -2.6830476522445679e-01
    z[3,8,6]  R1433     6.9326788187026978e-02
    z[3,8,6]  R1434     -3.4348601102828979e-01
    z[3,8,6]  R1435     0.0750337466597557
    z[3,8,6]  R1436     0.390138179063797
    z[3,8,6]  R1437     1.6677644848823547e-01
    z[3,8,6]  R1438     7.4481196701526642e-02
    z[3,8,6]  R1439     -1.8555977940559387e-01
    z[3,8,6]  R1440     1.0878256708383560e-01
    z[3,8,6]  R1441     2.2727511823177338e-02
    z[3,8,6]  R1442     -1.7764264345169067e-01
    z[3,8,6]  R1443     3.2427048683166504e-01
    z[3,8,6]  R1444     3.8796347379684448e-01
    z[3,8,6]  R1445     2.9086786508560181e-01
    z[3,8,6]  R1446     5.3685763850808144e-03
    z[3,8,6]  R1447     4.7650119662284851e-01
    z[3,8,6]  R1448     1.9865010678768158e-01
    z[3,8,6]  R1449     8.7767750024795532e-02
    z[3,8,6]  R1450     7.5500112771987915e-01
    z[3,8,6]  R1451     -2.2788988426327705e-02
    z[3,8,6]  R1452     -5.5582004785537720e-01
    z[3,8,6]  R1453     -3.8580577820539474e-02
    z[3,8,6]  R1454     -1.2512862682342529e-01
    z[3,8,6]  R1455     1.8459033966064453e-01
    z[3,8,6]  R1456     1.6274780035018921e-01
    z[3,8,6]  R1457     1.2327576428651810e-01
    z[3,8,6]  R1458     -1.0316102951765060e-01
    z[3,8,6]  R1459     1.7142336070537567e-01
    z[3,8,6]  R1460     -1.6085078939795494e-02
    z[3,8,6]  R1461     -4.6470880508422852e-02
    z[3,8,6]  R1462     1.5468142926692963e-02
    z[3,8,6]  R1463     1.5896968543529510e-01
    z[3,8,6]  R1464     5.0948962569236755e-02
    z[3,8,6]  R1465     8.9596778154373169e-02
    z[3,8,6]  R1466     1.1430647969245911e-01
    z[3,8,6]  R1467     2.1785560250282288e-01
    z[3,8,6]  R1468     1.8165364861488342e-01
    z[3,8,6]  R1469     2.8705176711082458e-01
    z[3,8,6]  R1470     -1.0856804251670837e-01
    z[3,8,6]  R1471     -1.2562349438667297e-01
    z[3,8,6]  R1472     2.7592003345489502e-02
    z[3,8,6]  R1473     -0.145661860704422
    z[3,8,6]  R1474     2.5001093745231628e-01
    z[3,8,6]  R1475     -1.5254151821136475e-01
    z[3,8,6]  R1476     -0.0850839912891388
    z[3,8,6]  R1477     -0.560992419719696
    z[3,8,6]  R1478     2.0289690792560577e-01
    z[3,8,6]  R1479     2.9001367092132568e-01
    z[3,8,6]  R1480     5.1871906965970993e-02
    z[3,8,6]  R1481     4.8334410786628723e-01
    z[3,8,6]  R1482     -5.3901600837707520e-01
    z[3,8,6]  R1483     1.5751791000366211e-01
    z[3,8,6]  R1484     2.2093172371387482e-01
    z[3,8,6]  R1485     -8.7031356990337372e-02
    z[3,8,6]  R1486     -3.7781888246536255e-01
    z[3,8,6]  R1487     -5.3689569234848022e-02
    z[3,8,6]  R1488     2.2673925757408142e-01
    z[3,8,6]  R1489     3.9606702327728271e-01
    z[3,8,6]  R1490     4.1313868761062622e-01
    z[3,8,6]  R1491     -7.8150011599063873e-02
    z[3,8,6]  R1492     -3.9280518889427185e-02
    z[3,8,6]  R1493     1.1420807242393494e-01
    z[3,8,6]  R1494     -8.6310803890228271e-02
    z[3,8,6]  R1495     -1.9005009904503822e-02
    z[3,8,6]  R1496     -3.6157715320587158e-01
    z[3,8,6]  R1497     -2.1683798730373383e-01
    z[3,8,6]  R1498     3.4990105032920837e-01
    z[3,8,6]  R1499     5.6830104440450668e-02
    z[3,8,6]  R1500     2.1327154338359833e-01
    z[3,8,6]  R1501     -1.5577603876590729e-01
    z[3,8,6]  R1502     -3.4625567495822906e-02
    z[3,8,6]  R1503     -1.4220872521400452e-01
    z[3,8,6]  R1504     9.6423342823982239e-02
    z[3,8,6]  R1505     -1.7282311618328094e-01
    z[3,8,6]  R1506     -0.378086119890213
    z[3,8,6]  R1507     3.4706908464431763e-01
    z[3,8,6]  R1508     1.7097742855548859e-01
    z[3,8,6]  R1509     -1.4853195846080780e-01
    z[3,8,6]  R1510     -6.0669219493865967e-01
    z[3,8,6]  R1511     3.8330513983964920e-02
    z[3,8,6]  R1512     -3.5251826047897339e-01
    z[3,8,6]  R1513     -9.1001898050308228e-02
    z[3,8,6]  R1514     1.1751641333103180e-01
    z[3,8,6]  R1515     4.5755349099636078e-02
    z[3,8,6]  R1516     2.4354528635740280e-02
    z[3,8,6]  R1517     -5.3508855402469635e-02
    z[3,8,6]  R1518     -2.3536704480648041e-01
    z[3,8,6]  R1519     1.1895284801721573e-01
    z[3,8,6]  R1520     -1.0439812391996384e-01
    z[3,8,6]  R1521     1.0300076566636562e-02
    z[3,8,6]  R1522     -6.8263687193393707e-02
    z[3,8,6]  R1523     -3.1316304206848145e-01
    z[3,8,6]  R1524     -2.7121287584304810e-01
    z[3,8,6]  R1525     -5.6809592247009277e-01
    z[3,8,6]  R1526     -9.1780908405780792e-02
    z[3,8,6]  R1527     2.5107720494270325e-01
    z[3,8,6]  R1528     8.4061108529567719e-02
    z[3,8,6]  R1529     1.1446928232908249e-01
    z[3,8,6]  R1530     5.7627558708190918e-01
    z[3,8,6]  R1531     -4.0148171782493591e-01
    z[3,8,6]  R1532     -4.9632743000984192e-01
    z[3,8,6]  R1533     -2.4001958966255188e-01
    z[3,8,6]  R1534     8.0292999744415283e-02
    z[3,8,6]  R1535     -0.263278603553772
    z[3,8,6]  R1536     -3.5444416105747223e-02
    z[3,8,6]  R1537     -3.1469020247459412e-01
    z[3,8,6]  R1538     4.0821629762649536e-01
    z[3,8,6]  R1539     2.0155639946460724e-01
    z[3,8,6]  R1540     -2.5141993165016174e-01
    z[3,8,6]  R1541     3.7151420116424561e-01
    z[3,8,6]  R1542     8.0253079533576965e-02
    z[3,8,6]  R1543     -1.4116473495960236e-01
    z[3,8,6]  R1544     2.5778514146804810e-01
    z[3,8,6]  R1545     5.3164589405059814e-01
    z[3,8,6]  R1546     1.2013272196054459e-01
    z[3,8,6]  R1547     -2.3785415291786194e-01
    z[3,8,6]  R1548     -1.9478686153888702e-01
    z[3,8,6]  R1549     -4.6476888656616211e-01
    z[3,8,6]  R1550     1.7436721920967102e-01
    z[3,8,6]  R1551     -6.8205338716506958e-01
    z[3,8,6]  R1552     1.2163235992193222e-01
    z[3,8,6]  R1553     -2.7614856138825417e-02
    z[3,8,6]  R1554     -5.3601509332656860e-01
    z[3,8,6]  R1555     -3.3391021192073822e-02
    z[3,8,6]  R1556     -5.5280399322509766e-01
    z[3,8,6]  R1557     -2.1958464756608009e-02
    z[3,8,6]  R1558     2.9406201839447021e-01
    z[3,8,6]  R1559     2.1542693674564362e-01
    z[3,8,6]  R1560     -2.3527100682258606e-01
    z[3,8,6]  R1561     4.8838317394256592e-01
    z[3,8,6]  R1562     -1.5909896790981293e-01
    z[3,8,6]  R1563     0.198703795671463
    z[3,8,6]  R1564     -3.1156727671623230e-01
    z[3,8,6]  R1565     -1.5996801853179932e-01
    z[3,8,6]  R1566     -0.421928346157074
    z[3,8,6]  R1567     2.3076918721199036e-01
    z[3,8,6]  R1568     1.3824053108692169e-01
    z[3,8,6]  R1569     0.122501440346241
    z[3,8,6]  R1570     1.0997556149959564e-01
    z[3,8,6]  R1571     -2.1318021416664124e-01
    z[3,8,6]  R1572     -3.3069238066673279e-02
    z[3,8,6]  R1573     2.8779405355453491e-01
    z[3,8,6]  R1574     -1.6068504750728607e-01
    z[3,8,6]  R1575     2.2490942478179932e-01
    z[3,8,6]  R1576     -2.4933236837387085e-01
    z[3,8,6]  R1577     -2.3067300207912922e-04
    z[3,8,6]  R1578     -4.7878619283437729e-02
    z[3,8,6]  R1579     -1.1579968780279160e-01
    z[3,8,6]  R1580     2.3130239546298981e-01
    z[3,8,6]  R1581     -1.3899651356041431e-02
    z[3,8,6]  R1582     1.4802783727645874e-01
    z[3,8,6]  R1583     -1.4510647952556610e-01
    z[3,8,6]  R1584     -1.1211130023002625e-01
    z[3,8,6]  R1585     -2.7499282732605934e-02
    z[3,8,6]  R1586     1.1985295452177525e-02
    z[3,8,6]  R1587     -4.6924528479576111e-01
    z[3,8,6]  R1588     -1.1394876986742020e-01
    z[8,3,0]  R29       1
    z[8,3,0]  R74       -1
    z[8,3,0]  R1589     -1
    z[8,3,0]  R1590     1
    z[8,3,0]  R1603     7.3675704002380371e-01
    z[8,3,0]  R1604     1.0319972038269043e-01
    z[8,3,0]  R1605     6.3704389333724976e-01
    z[8,3,0]  R1606     3.2089483737945557e-01
    z[8,3,0]  R1607     4.4578793644905090e-01
    z[8,3,0]  R1608     8.4498089551925659e-01
    z[8,3,0]  R1609     5.0070625543594360e-01
    z[8,3,0]  R1610     5.7631397247314453e-01
    z[8,3,0]  R1611     6.8455582857131958e-01
    z[8,3,0]  R1612     -3.2613688707351685e-01
    z[8,3,0]  R1613     -1.6814163327217102e-01
    z[8,3,0]  R1614     -1.7515951395034790e-01
    z[8,3,0]  R1615     -2.4347655475139618e-02
    z[8,3,0]  R1616     -0.0678994357585907
    z[8,3,0]  R1617     -2.3351998627185822e-01
    z[8,3,0]  R1618     1.1257733404636383e-01
    z[8,3,0]  R1619     -2.7053564786911011e-01
    z[8,3,0]  R1620     -7.0400846004486084e-01
    z[8,3,0]  R1621     -5.1912359893321991e-02
    z[8,3,0]  R1622     3.8379433751106262e-01
    z[8,3,0]  R1623     -1.3053552806377411e-01
    z[8,3,0]  R1624     -1.2395630031824112e-01
    z[8,3,0]  R1625     -2.5183475017547607e-01
    z[8,3,0]  R1626     0.114784836769104
    z[8,3,0]  R1627     -4.0332657098770142e-01
    z[8,3,0]  R1628     3.3311915397644043e-01
    z[8,3,0]  R1629     0.347579687833786
    z[8,3,0]  R1630     5.9238141775131226e-01
    z[8,3,0]  R1631     -2.0692250132560730e-01
    z[8,3,0]  R1632     2.5033403187990189e-02
    z[8,3,0]  R1633     -2.5332754850387573e-01
    z[8,3,0]  R1634     -1.5056604752317071e-03
    z[8,3,0]  R1635     -2.8315967321395874e-01
    z[8,3,0]  R1636     4.8121601343154907e-02
    z[8,3,0]  R1637     4.5071363449096680e-01
    z[8,3,0]  R1638     -1.4257016777992249e-01
    z[8,3,0]  R1639     -4.2801958322525024e-01
    z[8,3,0]  R1640     -1.1250866204500198e-01
    z[8,3,0]  R1641     1.8788002431392670e-01
    z[8,3,0]  R1642     -2.6258345693349838e-02
    z[8,3,0]  R1643     -3.2672667503356934e-01
    z[8,3,0]  R1644     -4.8704558610916138e-01
    z[8,3,0]  R1645     -3.9662095904350281e-01
    z[8,3,0]  R1646     -3.9709344506263733e-01
    z[8,3,0]  R1647     2.8152653574943542e-01
    z[8,3,0]  R1648     -0.386346697807312
    z[8,3,0]  R1649     -5.3818565607070923e-01
    z[8,3,0]  R1650     -4.8915845155715942e-01
    z[8,3,0]  R1651     -3.6705833673477173e-01
    z[8,3,0]  R1652     5.6868660449981689e-01
    z[8,3,0]  R1653     -4.3744522333145142e-01
    z[8,3,0]  R1654     -6.1622118949890137e-01
    z[8,3,0]  R1655     1.5182720124721527e-01
    z[8,3,0]  R1656     2.2419843077659607e-01
    z[8,3,0]  R1657     4.1455361060798168e-03
    z[8,3,0]  R1658     -2.3684193193912506e-01
    z[8,3,0]  R1659     -3.7485834956169128e-01
    z[8,3,0]  R1660     -3.6465996503829956e-01
    z[8,3,0]  R1661     2.9203328490257263e-01
    z[8,3,0]  R1662     -6.6135597229003906e-01
    z[8,3,0]  R1663     3.9041861891746521e-01
    z[8,3,0]  R1664     0.06740702688694
    z[8,3,0]  R1665     -2.7967801690101624e-01
    z[8,3,0]  R1666     -7.1032392978668213e-01
    z[8,3,0]  R1667     5.2875989675521851e-01
    z[8,3,0]  R1668     3.4844768047332764e-01
    z[8,3,0]  R1669     2.0690768957138062e-01
    z[8,3,0]  R1670     -6.6474074125289917e-01
    z[8,3,0]  R1671     -5.2484017610549927e-01
    z[8,3,0]  R1672     2.9758960008621216e-01
    z[8,3,0]  R1673     -4.0893962979316711e-01
    z[8,3,0]  R1674     -3.6436259746551514e-01
    z[8,3,0]  R1675     4.1812849044799805e-01
    z[8,3,0]  R1676     7.8895963728427887e-02
    z[8,3,0]  R1677     3.8255488872528076e-01
    z[8,3,0]  R1678     -2.0790712535381317e-01
    z[8,3,0]  R1679     1.8902172148227692e-01
    z[8,3,0]  R1680     4.2085587978363037e-02
    z[8,3,0]  R1681     6.1813032627105713e-01
    z[8,3,0]  R1682     -4.4558876752853394e-01
    z[8,3,0]  R1683     7.3081964254379272e-01
    z[8,3,0]  R1684     7.5236237049102783e-01
    z[8,3,0]  R1685     6.4019095897674561e-01
    z[8,3,0]  R1686     7.5551462173461914e-01
    z[8,3,0]  R1687     7.9268425703048706e-01
    z[8,3,0]  R1688     5.8187460899353027e-01
    z[8,3,0]  R1689     7.8306490182876587e-01
    z[8,3,0]  R1690     7.6801878213882446e-01
    z[8,3,0]  R1691     -1.7464710399508476e-02
    z[8,3,0]  R1692     -5.1970733329653740e-04
    z[8,3,0]  R1693     -3.7451930344104767e-02
    z[8,3,0]  R1694     -1.7085577547550201e-01
    z[8,3,0]  R1695     -1.3820216059684753e-01
    z[8,3,0]  R1696     -2.9620608687400818e-01
    z[8,3,0]  R1697     -3.9036303758621216e-01
    z[8,3,0]  R1698     -1.3025595247745514e-01
    z[8,3,0]  R1699     -8.9698553085327148e-02
    z[8,3,0]  R1700     -0.651669979095459
    z[8,3,0]  R1701     -5.4056859016418457e-01
    z[8,3,0]  R1702     -3.8065171241760254e-01
    z[8,3,0]  R1703     6.7949414253234863e-02
    z[8,3,0]  R1704     -5.3215283155441284e-01
    z[8,3,0]  R1705     -3.6922167986631393e-02
    z[8,3,0]  R1706     -3.3193930983543396e-01
    z[8,3,0]  R1707     -9.1507446765899658e-01
    z[8,3,0]  R1708     -9.1097509860992432e-01
    z[8,3,0]  R1709     -3.6560615897178650e-01
    z[8,3,0]  R1710     2.1802823990583420e-02
    z[8,3,0]  R1711     -8.8899797201156616e-01
    z[8,3,0]  R1712     -8.7273043394088745e-01
    z[8,3,0]  R1713     -4.3535541743040085e-02
    z[8,3,0]  R1714     6.1079227924346924e-01
    z[8,3,0]  R1715     -2.8745830059051514e-01
    z[8,3,0]  R1716     -6.3473924994468689e-02
    z[8,3,0]  R1717     2.5515419244766235e-01
    z[8,3,0]  R1718     -3.7279021739959717e-01
    z[8,3,0]  R1719     -6.3946500420570374e-02
    z[8,3,0]  R1720     1.7163048684597015e-01
    z[8,3,0]  R1721     -3.3679354190826416e-01
    z[8,3,0]  R1722     -6.0315674543380737e-01
    z[8,3,0]  R1723     -4.9866211414337158e-01
    z[8,3,0]  R1724     5.8716970682144165e-01
    z[8,3,0]  R1725     2.4355675280094147e-01
    z[8,3,0]  R1726     -9.8377957940101624e-02
    z[8,3,0]  R1727     -9.1336077451705933e-01
    z[8,3,0]  R1728     -2.0049074292182922e-01
    z[8,3,0]  R1729     -0.793777346611023
    z[8,3,0]  R1730     -1.3446946442127228e-01
    z[8,3,0]  R1731     -7.6299661397933960e-01
    z[8,3,0]  R1732     -2.5040575861930847e-01
    z[8,3,0]  R1733     -4.8506896942853928e-02
    z[8,3,0]  R1734     3.9443102478981018e-01
    z[8,3,0]  R1735     -3.4812141209840775e-02
    z[8,3,0]  R1736     -6.8137490749359131e-01
    z[8,3,0]  R1737     -4.9739876389503479e-01
    z[8,3,0]  R1738     -7.7618694305419922e-01
    z[8,3,0]  R1739     -8.8468819856643677e-01
    z[8,3,0]  R1740     -8.9799350500106812e-01
    z[8,3,0]  R1741     -3.6623382568359375e-01
    z[8,3,0]  R1742     -8.2222521305084229e-01
    z[8,3,0]  R1743     -9.5417900010943413e-03
    z[8,3,0]  R1744     -5.6352788209915161e-01
    z[8,3,0]  R1745     -0.457535058259964
    z[8,3,0]  R1746     -4.6804243326187134e-01
    z[8,3,0]  R1747     -5.3360491991043091e-01
    z[8,3,0]  R1748     -9.5024204254150391e-01
    z[8,3,0]  R1749     -9.2259037494659424e-01
    z[8,3,0]  R1750     -8.5279864072799683e-01
    z[8,3,0]  R1751     -4.1459599137306213e-01
    z[8,3,0]  R1752     -1.6792495548725128e-01
    z[8,3,0]  R1753     -4.4118997454643250e-01
    z[8,3,0]  R1754     -5.4312908649444580e-01
    z[8,3,0]  R1755     -2.4107502773404121e-02
    z[8,3,0]  R1756     -4.8570921644568443e-03
    z[8,3,0]  R1757     -5.8970987796783447e-01
    z[8,3,0]  R1758     4.0796521306037903e-01
    z[8,3,0]  R1759     -8.3640134334564209e-01
    z[8,3,0]  R1760     -7.5629872083663940e-01
    z[8,3,0]  R1761     -2.3148091509938240e-02
    z[8,3,0]  R1762     -5.3866463899612427e-01
    z[8,3,0]  R1763     1.6193255782127380e-01
    z[8,3,0]  R1764     4.9023322761058807e-02
    z[8,3,0]  R1765     9.2316336929798126e-02
    z[8,3,0]  R1766     -9.0431171655654907e-01
    z[8,3,0]  R1767     -8.4467101097106934e-01
    z[8,3,0]  R1768     -3.7108820676803589e-01
    z[8,3,0]  R1769     -3.4779664874076843e-01
    z[8,3,0]  R1770     -1.0684672743082047e-01
    z[8,3,0]  R1771     -1.9758220016956329e-01
    z[8,3,0]  R1772     -5.0120222568511963e-01
    z[8,3,0]  R1773     3.2902139425277710e-01
    z[8,3,0]  R1774     3.8526329398155212e-01
    z[8,3,0]  R1775     -6.9628250598907471e-01
    z[8,3,0]  R1776     -9.1065317392349243e-01
    z[8,3,0]  R1777     -8.7985646724700928e-01
    z[8,3,0]  R1778     -8.5753923654556274e-01
    z[8,3,0]  R1779     -5.2138119935989380e-01
    z[8,3,0]  R1780     -0.281818151473999
    z[8,3,0]  R1781     -4.4188895821571350e-01
    z[8,3,0]  R1782     -4.0765147656202316e-02
    z[8,3,1]  R30       1
    z[8,3,1]  R75       -1
    z[8,3,1]  R1591     -1
    z[8,3,1]  R1592     1
    z[8,3,1]  R1603     0.30374675989151
    z[8,3,1]  R1604     7.4504172801971436e-01
    z[8,3,1]  R1605     1.7645424604415894e-01
    z[8,3,1]  R1606     0.712421178817749
    z[8,3,1]  R1607     3.6899831891059875e-01
    z[8,3,1]  R1608     5.9653103351593018e-02
    z[8,3,1]  R1609     5.5840945243835449e-01
    z[8,3,1]  R1610     4.7310832142829895e-01
    z[8,3,1]  R1611     1.8774619698524475e-01
    z[8,3,1]  R1612     0.708575427532196
    z[8,3,1]  R1613     -5.0860875844955444e-01
    z[8,3,1]  R1614     -5.9739941358566284e-01
    z[8,3,1]  R1615     -5.6169933080673218e-01
    z[8,3,1]  R1616     -4.4880822300910950e-01
    z[8,3,1]  R1617     -5.3318786621093750e-01
    z[8,3,1]  R1618     -5.1414120197296143e-01
    z[8,3,1]  R1619     -3.5053873062133789e-01
    z[8,3,1]  R1620     3.0828055739402771e-01
    z[8,3,1]  R1621     5.2129125595092773e-01
    z[8,3,1]  R1622     5.5241715908050537e-01
    z[8,3,1]  R1623     6.9651472568511963e-01
    z[8,3,1]  R1624     6.7883557081222534e-01
    z[8,3,1]  R1625     6.0026526451110840e-01
    z[8,3,1]  R1626     5.7415229082107544e-01
    z[8,3,1]  R1627     5.8584743738174438e-01
    z[8,3,1]  R1628     5.5500334501266479e-01
    z[8,3,1]  R1629     5.3615683317184448e-01
    z[8,3,1]  R1630     0.540215015411377
    z[8,3,1]  R1631     6.7617017030715942e-01
    z[8,3,1]  R1632     7.3270970582962036e-01
    z[8,3,1]  R1633     7.4011689424514771e-01
    z[8,3,1]  R1634     7.8080952167510986e-01
    z[8,3,1]  R1635     6.4962941408157349e-01
    z[8,3,1]  R1636     7.3950606584548950e-01
    z[8,3,1]  R1637     7.0295256376266479e-01
    z[8,3,1]  R1638     -0.282776415348053
    z[8,3,1]  R1639     6.5165388584136963e-01
    z[8,3,1]  R1640     -6.9621199369430542e-01
    z[8,3,1]  R1641     -6.2677758932113647e-01
    z[8,3,1]  R1642     -6.9244033098220825e-01
    z[8,3,1]  R1643     4.4207695126533508e-01
    z[8,3,1]  R1644     9.8487166687846184e-03
    z[8,3,1]  R1645     1.4604867994785309e-01
    z[8,3,1]  R1646     -1.7323195934295654e-01
    z[8,3,1]  R1647     4.5368626713752747e-01
    z[8,3,1]  R1648     9.7142502665519714e-02
    z[8,3,1]  R1649     -6.1505597829818726e-01
    z[8,3,1]  R1650     -5.5039227008819580e-01
    z[8,3,1]  R1651     3.2359874248504639e-01
    z[8,3,1]  R1652     -6.2403416633605957e-01
    z[8,3,1]  R1653     8.3767253160476685e-01
    z[8,3,1]  R1654     7.2170168161392212e-01
    z[8,3,1]  R1655     7.8799778223037720e-01
    z[8,3,1]  R1656     0.663337767124176
    z[8,3,1]  R1657     -5.2512373775243759e-02
    z[8,3,1]  R1658     4.7200858592987061e-01
    z[8,3,1]  R1659     3.7658709287643433e-01
    z[8,3,1]  R1660     1.6975344717502594e-01
    z[8,3,1]  R1661     2.2284699603915215e-02
    z[8,3,1]  R1662     -4.1852882504463196e-01
    z[8,3,1]  R1663     0.803875207901001
    z[8,3,1]  R1664     -1.5951721370220184e-01
    z[8,3,1]  R1665     0.295402467250824
    z[8,3,1]  R1666     1.3658988475799561e-01
    z[8,3,1]  R1667     -4.7057133913040161e-01
    z[8,3,1]  R1668     -7.8113985061645508e-01
    z[8,3,1]  R1669     -6.2176591157913208e-01
    z[8,3,1]  R1670     -3.1555432081222534e-01
    z[8,3,1]  R1671     -7.0497810840606689e-01
    z[8,3,1]  R1672     -1.9482684135437012e-01
    z[8,3,1]  R1673     -6.5725374221801758e-01
    z[8,3,1]  R1674     -5.3161764144897461e-01
    z[8,3,1]  R1675     -7.3614805936813354e-01
    z[8,3,1]  R1676     -5.2352142333984375e-01
    z[8,3,1]  R1677     -1.1451903730630875e-01
    z[8,3,1]  R1678     -1.9247953593730927e-01
    z[8,3,1]  R1679     -3.2207658886909485e-01
    z[8,3,1]  R1680     -3.2849270105361938e-01
    z[8,3,1]  R1681     -5.9491980075836182e-01
    z[8,3,1]  R1682     -3.0491960048675537e-01
    z[8,3,1]  R1683     1.3711350969970226e-02
    z[8,3,1]  R1684     5.4299894720315933e-02
    z[8,3,1]  R1685     2.4019737541675568e-01
    z[8,3,1]  R1686     3.7223255634307861e-01
    z[8,3,1]  R1687     2.8006935119628906e-01
    z[8,3,1]  R1688     3.9857888221740723e-01
    z[8,3,1]  R1689     4.2062580585479736e-01
    z[8,3,1]  R1690     -2.2349764406681061e-01
    z[8,3,1]  R1691     7.9020828008651733e-01
    z[8,3,1]  R1692     7.2798633575439453e-01
    z[8,3,1]  R1693     7.1584838628768921e-01
    z[8,3,1]  R1694     -2.1504734456539154e-01
    z[8,3,1]  R1695     6.5834307670593262e-01
    z[8,3,1]  R1696     6.4349353313446045e-01
    z[8,3,1]  R1697     8.0013543367385864e-02
    z[8,3,1]  R1698     5.5630236864089966e-01
    z[8,3,1]  R1699     5.1694333553314209e-01
    z[8,3,1]  R1700     1.1657485365867615e-01
    z[8,3,1]  R1701     1.8256975710391998e-01
    z[8,3,1]  R1702     0.0415816530585289
    z[8,3,1]  R1703     2.3756314814090729e-01
    z[8,3,1]  R1704     -2.9377132654190063e-02
    z[8,3,1]  R1705     -5.2666097879409790e-01
    z[8,3,1]  R1706     5.0524920225143433e-01
    z[8,3,1]  R1707     1.1464839428663254e-01
    z[8,3,1]  R1708     -1.9159886986017227e-02
    z[8,3,1]  R1709     4.8104834556579590e-01
    z[8,3,1]  R1710     4.5014080405235291e-01
    z[8,3,1]  R1711     -6.3170604407787323e-02
    z[8,3,1]  R1712     2.7494031190872192e-01
    z[8,3,1]  R1713     4.4470425695180893e-02
    z[8,3,1]  R1714     -9.6938237547874451e-03
    z[8,3,1]  R1715     4.1444137692451477e-01
    z[8,3,1]  R1716     5.4111951589584351e-01
    z[8,3,1]  R1717     0.627250611782074
    z[8,3,1]  R1718     5.6994384527206421e-01
    z[8,3,1]  R1719     -4.6652853488922119e-01
    z[8,3,1]  R1720     -5.2630335092544556e-01
    z[8,3,1]  R1721     4.4160258769989014e-01
    z[8,3,1]  R1722     -5.4234772920608521e-01
    z[8,3,1]  R1723     6.7723000049591064e-01
    z[8,3,1]  R1724     -4.7758162021636963e-02
    z[8,3,1]  R1725     -5.6062698364257812e-01
    z[8,3,1]  R1726     4.3963938951492310e-01
    z[8,3,1]  R1727     -1.6114315390586853e-01
    z[8,3,1]  R1728     -9.4882321357727051e-01
    z[8,3,1]  R1729     4.0067046880722046e-02
    z[8,3,1]  R1730     -9.2889207601547241e-01
    z[8,3,1]  R1731     -2.3473416268825531e-01
    z[8,3,1]  R1732     -9.0752846002578735e-01
    z[8,3,1]  R1733     7.4260032176971436e-01
    z[8,3,1]  R1734     -6.6749060153961182e-01
    z[8,3,1]  R1735     -4.7623196244239807e-01
    z[8,3,1]  R1736     6.0549920797348022e-01
    z[8,3,1]  R1737     4.7995755076408386e-01
    z[8,3,1]  R1738     -4.0013200044631958e-01
    z[8,3,1]  R1739     7.1967437863349915e-02
    z[8,3,1]  R1740     -8.7360413745045662e-03
    z[8,3,1]  R1741     6.3114196062088013e-02
    z[8,3,1]  R1742     6.9946028292179108e-02
    z[8,3,1]  R1743     7.9096013307571411e-01
    z[8,3,1]  R1744     6.5089470148086548e-01
    z[8,3,1]  R1745     5.2843958139419556e-01
    z[8,3,1]  R1746     1.1336542665958405e-01
    z[8,3,1]  R1747     5.1968789100646973e-01
    z[8,3,1]  R1748     -4.5264068990945816e-02
    z[8,3,1]  R1749     -5.3006079047918320e-02
    z[8,3,1]  R1750     2.8267037868499756e-01
    z[8,3,1]  R1751     1.7081966996192932e-01
    z[8,3,1]  R1752     -8.8181960582733154e-01
    z[8,3,1]  R1753     6.4701217412948608e-01
    z[8,3,1]  R1754     -1.5277132391929626e-01
    z[8,3,1]  R1755     5.6754022836685181e-01
    z[8,3,1]  R1756     1.6682486236095428e-01
    z[8,3,1]  R1757     1.8880617618560791e-01
    z[8,3,1]  R1758     0.492443710565567
    z[8,3,1]  R1759     -2.4261765182018280e-01
    z[8,3,1]  R1760     1.0084971785545349e-01
    z[8,3,1]  R1761     -8.7758040428161621e-01
    z[8,3,1]  R1762     -3.5370045900344849e-01
    z[8,3,1]  R1763     7.1731823682785034e-01
    z[8,3,1]  R1764     5.5955308675765991e-01
    z[8,3,1]  R1765     -1.5039165318012238e-01
    z[8,3,1]  R1766     -2.1676853299140930e-01
    z[8,3,1]  R1767     1.5709306299686432e-01
    z[8,3,1]  R1768     -6.6963976621627808e-01
    z[8,3,1]  R1769     -5.3933167457580566e-01
    z[8,3,1]  R1770     -7.8680831193923950e-01
    z[8,3,1]  R1771     -4.8667269945144653e-01
    z[8,3,1]  R1772     -5.3156054019927979e-01
    z[8,3,1]  R1773     6.9027435779571533e-01
    z[8,3,1]  R1774     -1.5281352400779724e-01
    z[8,3,1]  R1775     0.324432373046875
    z[8,3,1]  R1776     4.5422129333019257e-02
    z[8,3,1]  R1777     -2.6522394269704819e-02
    z[8,3,1]  R1778     1.5438407659530640e-01
    z[8,3,1]  R1779     -0.581614077091217
    z[8,3,1]  R1780     -5.1495635509490967e-01
    z[8,3,1]  R1781     -1.3446459174156189e-01
    z[8,3,1]  R1782     -5.9460699558258057e-01
    z[8,3,2]  R31       1
    z[8,3,2]  R76       -1
    z[8,3,2]  R1593     -1
    z[8,3,2]  R1594     1
    z[8,3,2]  R1603     5.7814067602157593e-01
    z[8,3,2]  R1604     1.7388562858104706e-01
    z[8,3,2]  R1605     7.1906256675720215e-01
    z[8,3,2]  R1606     3.2191246747970581e-01
    z[8,3,2]  R1607     7.6544874906539917e-01
    z[8,3,2]  R1608     0.505023717880249
    z[8,3,2]  R1609     6.0721164941787720e-01
    z[8,3,2]  R1610     6.0207647085189819e-01
    z[8,3,2]  R1611     6.1139428615570068e-01
    z[8,3,2]  R1612     3.8345783948898315e-01
    z[8,3,2]  R1613     -2.9519745148718357e-03
    z[8,3,2]  R1614     -8.7089262902736664e-02
    z[8,3,2]  R1615     -3.4792459011077881e-01
    z[8,3,2]  R1616     -2.7005153894424438e-01
    z[8,3,2]  R1617     1.1014468967914581e-01
    z[8,3,2]  R1618     -2.5249516963958740e-01
    z[8,3,2]  R1619     0.0291758980602026
    z[8,3,2]  R1620     -3.0748954415321350e-01
    z[8,3,2]  R1621     -3.1573307514190674e-01
    z[8,3,2]  R1622     -4.2549693584442139e-01
    z[8,3,2]  R1623     -3.6064156889915466e-01
    z[8,3,2]  R1624     -1.0769446939229965e-01
    z[8,3,2]  R1625     -1.9698448479175568e-01
    z[8,3,2]  R1626     -4.9072912335395813e-01
    z[8,3,2]  R1627     9.0174175798892975e-02
    z[8,3,2]  R1628     -5.2778005599975586e-01
    z[8,3,2]  R1629     -5.9519398212432861e-01
    z[8,3,2]  R1630     -3.6995080113410950e-01
    z[8,3,2]  R1631     -2.0785297453403473e-01
    z[8,3,2]  R1632     1.1789846420288086e-01
    z[8,3,2]  R1633     -3.0639493465423584e-01
    z[8,3,2]  R1634     4.8860549926757812e-02
    z[8,3,2]  R1635     -5.4658007621765137e-01
    z[8,3,2]  R1636     1.6758209466934204e-01
    z[8,3,2]  R1637     1.1022539436817169e-01
    z[8,3,2]  R1638     -8.1075555086135864e-01
    z[8,3,2]  R1639     1.1862143874168396e-01
    z[8,3,2]  R1640     -5.5827546119689941e-01
    z[8,3,2]  R1641     -6.7261105775833130e-01
    z[8,3,2]  R1642     -3.8340216875076294e-01
    z[8,3,2]  R1643     -5.7558870315551758e-01
    z[8,3,2]  R1644     -2.4053406715393066e-01
    z[8,3,2]  R1645     -3.0332398414611816e-01
    z[8,3,2]  R1646     -2.5991985201835632e-01
    z[8,3,2]  R1647     -9.3733951449394226e-02
    z[8,3,2]  R1648     -3.3817071467638016e-02
    z[8,3,2]  R1649     -4.5310333371162415e-01
    z[8,3,2]  R1650     -2.0347027480602264e-01
    z[8,3,2]  R1651     0.270241916179657
    z[8,3,2]  R1652     -3.4853389859199524e-01
    z[8,3,2]  R1653     3.8999080657958984e-02
    z[8,3,2]  R1654     -1.0526547580957413e-01
    z[8,3,2]  R1655     1.4102604985237122e-01
    z[8,3,2]  R1656     -3.3617219328880310e-01
    z[8,3,2]  R1657     -5.4828923940658569e-01
    z[8,3,2]  R1658     -4.7268554568290710e-01
    z[8,3,2]  R1659     -6.1010879278182983e-01
    z[8,3,2]  R1660     -2.1281237900257111e-01
    z[8,3,2]  R1661     -4.4417455792427063e-01
    z[8,3,2]  R1662     -1.3416640460491180e-01
    z[8,3,2]  R1663     -1.1298751085996628e-01
    z[8,3,2]  R1664     -4.2926058173179626e-01
    z[8,3,2]  R1665     -5.7679069042205811e-01
    z[8,3,2]  R1666     1.8374128639698029e-01
    z[8,3,2]  R1667     -3.8103365898132324e-01
    z[8,3,2]  R1668     -1.4756055176258087e-01
    z[8,3,2]  R1669     4.2118526995182037e-02
    z[8,3,2]  R1670     -0.535280704498291
    z[8,3,2]  R1671     2.7376702427864075e-01
    z[8,3,2]  R1672     -0.0871121808886528
    z[8,3,2]  R1673     -3.8658180832862854e-01
    z[8,3,2]  R1674     -5.9542137384414673e-01
    z[8,3,2]  R1675     -2.0386219024658203e-01
    z[8,3,2]  R1676     -9.4626814126968384e-02
    z[8,3,2]  R1677     -1.6701258718967438e-01
    z[8,3,2]  R1678     -1.1634702235460281e-01
    z[8,3,2]  R1679     3.6156069836579263e-04
    z[8,3,2]  R1680     1.2524689733982086e-01
    z[8,3,2]  R1681     -7.1765370666980743e-02
    z[8,3,2]  R1682     8.1551790237426758e-02
    z[8,3,2]  R1683     0.388574481010437
    z[8,3,2]  R1684     2.4980668723583221e-01
    z[8,3,2]  R1685     6.0219585895538330e-01
    z[8,3,2]  R1686     3.8829341530799866e-01
    z[8,3,2]  R1687     1.6707780957221985e-01
    z[8,3,2]  R1688     4.4926857948303223e-01
    z[8,3,2]  R1689     3.8597890734672546e-01
    z[8,3,2]  R1690     1.4168396592140198e-01
    z[8,3,2]  R1691     0.345490425825119
    z[8,3,2]  R1692     5.9946954250335693e-01
    z[8,3,2]  R1693     -4.6438673138618469e-01
    z[8,3,2]  R1694     -0.453572154045105
    z[8,3,2]  R1695     -2.5681027770042419e-01
    z[8,3,2]  R1696     -6.0514993965625763e-02
    z[8,3,2]  R1697     -3.0757537484169006e-01
    z[8,3,2]  R1698     -1.1456935852766037e-01
    z[8,3,2]  R1699     -2.6502177119255066e-01
    z[8,3,2]  R1700     -3.3766967058181763e-01
    z[8,3,2]  R1701     -2.5241887569427490e-01
    z[8,3,2]  R1702     2.2210665047168732e-01
    z[8,3,2]  R1703     -4.0944731235504150e-01
    z[8,3,2]  R1704     6.3712793588638306e-01
    z[8,3,2]  R1705     -6.7614391446113586e-02
    z[8,3,2]  R1706     2.8389924764633179e-01
    z[8,3,2]  R1707     -2.0516772568225861e-01
    z[8,3,2]  R1708     -7.7193580567836761e-02
    z[8,3,2]  R1709     1.2833668291568756e-01
    z[8,3,2]  R1710     -4.6638140082359314e-01
    z[8,3,2]  R1711     3.0287280678749084e-01
    z[8,3,2]  R1712     2.8450208902359009e-01
    z[8,3,2]  R1713     3.0728485435247421e-02
    z[8,3,2]  R1714     1.0896039195358753e-02
    z[8,3,2]  R1715     1.4771074056625366e-01
    z[8,3,2]  R1716     4.6055087447166443e-01
    z[8,3,2]  R1717     -4.0463727712631226e-01
    z[8,3,2]  R1718     2.0238615572452545e-02
    z[8,3,2]  R1719     5.5145698785781860e-01
    z[8,3,2]  R1720     5.6918853521347046e-01
    z[8,3,2]  R1721     -5.7994669675827026e-01
    z[8,3,2]  R1722     2.2485144436359406e-01
    z[8,3,2]  R1723     -2.5433886051177979e-01
    z[8,3,2]  R1724     4.7333080321550369e-02
    z[8,3,2]  R1725     5.2712643146514893e-01
    z[8,3,2]  R1726     -3.9871567487716675e-01
    z[8,3,2]  R1727     -1.4094695448875427e-01
    z[8,3,2]  R1728     6.4704142510890961e-02
    z[8,3,2]  R1729     -3.2439496368169785e-02
    z[8,3,2]  R1730     3.1068574637174606e-02
    z[8,3,2]  R1731     1.6097691655158997e-01
    z[8,3,2]  R1732     2.4971139430999756e-01
    z[8,3,2]  R1733     6.2799811363220215e-02
    z[8,3,2]  R1734     1.2318023294210434e-01
    z[8,3,2]  R1735     0.424014687538147
    z[8,3,2]  R1736     0.0715944841504097
    z[8,3,2]  R1737     -2.9453590512275696e-01
    z[8,3,2]  R1738     7.6235704123973846e-02
    z[8,3,2]  R1739     1.3002495467662811e-01
    z[8,3,2]  R1740     -1.7952781915664673e-01
    z[8,3,2]  R1741     -0.280814528465271
    z[8,3,2]  R1742     2.7645226567983627e-02
    z[8,3,2]  R1743     -1.2493391335010529e-01
    z[8,3,2]  R1744     1.9838419556617737e-01
    z[8,3,2]  R1745     -0.488179087638855
    z[8,3,2]  R1746     -2.6554372906684875e-01
    z[8,3,2]  R1747     3.6922845244407654e-01
    z[8,3,2]  R1748     -0.0339483805000782
    z[8,3,2]  R1749     1.3924182951450348e-01
    z[8,3,2]  R1750     1.7402195930480957e-01
    z[8,3,2]  R1751     -1.2328878045082092e-01
    z[8,3,2]  R1752     -5.0941850990056992e-02
    z[8,3,2]  R1753     4.4459328055381775e-02
    z[8,3,2]  R1754     5.5610740184783936e-01
    z[8,3,2]  R1755     -1.8911378085613251e-01
    z[8,3,2]  R1756     -1.1785674095153809e-01
    z[8,3,2]  R1757     -2.0113836228847504e-01
    z[8,3,2]  R1758     -5.2802842855453491e-01
    z[8,3,2]  R1759     -5.6183699518442154e-02
    z[8,3,2]  R1760     3.6028262972831726e-01
    z[8,3,2]  R1761     -4.0361863374710083e-01
    z[8,3,2]  R1762     -6.0564011335372925e-01
    z[8,3,2]  R1763     1.1743155121803284e-01
    z[8,3,2]  R1764     -2.8917932510375977e-01
    z[8,3,2]  R1765     -1.1606529355049133e-01
    z[8,3,2]  R1766     -9.5972500275820494e-04
    z[8,3,2]  R1767     -1.6278178989887238e-01
    z[8,3,2]  R1768     -4.5483973622322083e-01
    z[8,3,2]  R1769     -4.7846508026123047e-01
    z[8,3,2]  R1770     2.9979849234223366e-02
    z[8,3,2]  R1771     -4.4776901602745056e-01
    z[8,3,2]  R1772     -3.7698981165885925e-01
    z[8,3,2]  R1773     -4.9701115489006042e-01
    z[8,3,2]  R1774     -2.9945635795593262e-01
    z[8,3,2]  R1775     -2.0904821157455444e-01
    z[8,3,2]  R1776     1.8929970264434814e-01
    z[8,3,2]  R1777     1.1313340812921524e-01
    z[8,3,2]  R1778     -1.4072303473949432e-01
    z[8,3,2]  R1779     -2.4279899895191193e-01
    z[8,3,2]  R1780     -5.3732901811599731e-01
    z[8,3,2]  R1781     -0.518753707408905
    z[8,3,2]  R1782     -6.6158592700958252e-01
    z[8,3,3]  R32       1
    z[8,3,3]  R77       -1
    z[8,3,3]  R1595     -1
    z[8,3,3]  R1596     1
    z[8,3,3]  R1603     5.1857795566320419e-02
    z[8,3,3]  R1604     1.8211877346038818e-01
    z[8,3,3]  R1605     1.1691156774759293e-01
    z[8,3,3]  R1606     -1.8961118161678314e-01
    z[8,3,3]  R1607     1.5626855194568634e-01
    z[8,3,3]  R1608     -8.3744160830974579e-02
    z[8,3,3]  R1609     1.5992085635662079e-01
    z[8,3,3]  R1610     -2.7161669731140137e-01
    z[8,3,3]  R1611     -1.2416200339794159e-01
    z[8,3,3]  R1612     3.6150798201560974e-02
    z[8,3,3]  R1613     -7.4238038063049316e-01
    z[8,3,3]  R1614     -3.5980746150016785e-01
    z[8,3,3]  R1615     -5.8321952819824219e-01
    z[8,3,3]  R1616     -2.1688893437385559e-01
    z[8,3,3]  R1617     -4.7954815626144409e-01
    z[8,3,3]  R1618     -5.9930962324142456e-01
    z[8,3,3]  R1619     -3.8831308484077454e-01
    z[8,3,3]  R1620     -5.0890469551086426e-01
    z[8,3,3]  R1621     -2.4170038104057312e-01
    z[8,3,3]  R1622     -3.9172795414924622e-01
    z[8,3,3]  R1623     1.9254611432552338e-01
    z[8,3,3]  R1624     2.5090974569320679e-01
    z[8,3,3]  R1625     2.9566147923469543e-01
    z[8,3,3]  R1626     -2.8940621018409729e-01
    z[8,3,3]  R1627     0.402680367231369
    z[8,3,3]  R1628     4.0484678745269775e-01
    z[8,3,3]  R1629     1.3354191184043884e-01
    z[8,3,3]  R1630     3.8730335235595703e-01
    z[8,3,3]  R1631     -0.429853230714798
    z[8,3,3]  R1632     -4.6079343557357788e-01
    z[8,3,3]  R1633     -3.1336975097656250e-01
    z[8,3,3]  R1634     -1.7450611293315887e-01
    z[8,3,3]  R1635     -2.0374611020088196e-01
    z[8,3,3]  R1636     4.9226158857345581e-01
    z[8,3,3]  R1637     -1.2572954595088959e-01
    z[8,3,3]  R1638     -3.4273895621299744e-01
    z[8,3,3]  R1639     1.3936059176921844e-01
    z[8,3,3]  R1640     1.9586777687072754e-01
    z[8,3,3]  R1641     1.9571746885776520e-01
    z[8,3,3]  R1642     4.9618965387344360e-01
    z[8,3,3]  R1643     -2.1210125088691711e-01
    z[8,3,3]  R1644     -0.767402708530426
    z[8,3,3]  R1645     -5.0298583507537842e-01
    z[8,3,3]  R1646     2.3538877069950104e-01
    z[8,3,3]  R1647     2.0210632681846619e-01
    z[8,3,3]  R1648     -7.3404544591903687e-01
    z[8,3,3]  R1649     -0.00976675283163786
    z[8,3,3]  R1650     -7.7435187995433807e-02
    z[8,3,3]  R1651     -7.9551786184310913e-01
    z[8,3,3]  R1652     1.9590778648853302e-01
    z[8,3,3]  R1653     -1.2370344996452332e-01
    z[8,3,3]  R1654     -1.1679595708847046e-01
    z[8,3,3]  R1655     -2.1719770133495331e-01
    z[8,3,3]  R1656     -1.4076061546802521e-01
    z[8,3,3]  R1657     -6.8923436105251312e-02
    z[8,3,3]  R1658     -4.8576775938272476e-02
    z[8,3,3]  R1659     -5.0221878290176392e-01
    z[8,3,3]  R1660     -7.7450329065322876e-01
    z[8,3,3]  R1661     -4.3196612596511841e-01
    z[8,3,3]  R1662     -3.6524653434753418e-02
    z[8,3,3]  R1663     -9.0609379112720490e-02
    z[8,3,3]  R1664     -7.5901877880096436e-01
    z[8,3,3]  R1665     -5.9787321090698242e-01
    z[8,3,3]  R1666     -5.1823216676712036e-01
    z[8,3,3]  R1667     2.4977408349514008e-01
    z[8,3,3]  R1668     1.6055627167224884e-01
    z[8,3,3]  R1669     0.374318391084671
    z[8,3,3]  R1670     2.2835499048233032e-01
    z[8,3,3]  R1671     2.3273542523384094e-01
    z[8,3,3]  R1672     8.0029904842376709e-01
    z[8,3,3]  R1673     -1.9853542745113373e-01
    z[8,3,3]  R1674     -2.3308378458023071e-01
    z[8,3,3]  R1675     1.1561270803213120e-01
    z[8,3,3]  R1676     4.7575098276138306e-01
    z[8,3,3]  R1677     6.0858130455017090e-01
    z[8,3,3]  R1678     8.5577911138534546e-01
    z[8,3,3]  R1679     0.516191840171814
    z[8,3,3]  R1680     0.539966881275177
    z[8,3,3]  R1681     1.7886368930339813e-01
    z[8,3,3]  R1682     5.5466693639755249e-01
    z[8,3,3]  R1683     -2.1983437240123749e-01
    z[8,3,3]  R1684     -3.3784502744674683e-01
    z[8,3,3]  R1685     -2.1890088915824890e-01
    z[8,3,3]  R1686     1.0547752678394318e-01
    z[8,3,3]  R1687     3.8617804646492004e-02
    z[8,3,3]  R1688     -2.0519154146313667e-02
    z[8,3,3]  R1689     3.8928262889385223e-02
    z[8,3,3]  R1690     -3.7719801068305969e-01
    z[8,3,3]  R1691     -2.8920945525169373e-01
    z[8,3,3]  R1692     -2.4688212573528290e-01
    z[8,3,3]  R1693     2.2081515192985535e-01
    z[8,3,3]  R1694     5.5929505825042725e-01
    z[8,3,3]  R1695     2.4585790932178497e-01
    z[8,3,3]  R1696     6.1227369308471680e-01
    z[8,3,3]  R1697     -8.4651607275009155e-01
    z[8,3,3]  R1698     3.4073927998542786e-01
    z[8,3,3]  R1699     6.9690680503845215e-01
    z[8,3,3]  R1700     -5.2825736999511719e-01
    z[8,3,3]  R1701     -4.5570856332778931e-01
    z[8,3,3]  R1702     1.1839376389980316e-01
    z[8,3,3]  R1703     8.2410866022109985e-01
    z[8,3,3]  R1704     3.8797068595886230e-01
    z[8,3,3]  R1705     2.3541538417339325e-01
    z[8,3,3]  R1706     3.8441452383995056e-01
    z[8,3,3]  R1707     1.0509452782571316e-02
    z[8,3,3]  R1708     -1.1293182522058487e-01
    z[8,3,3]  R1709     2.7240052819252014e-01
    z[8,3,3]  R1710     -2.9375419020652771e-01
    z[8,3,3]  R1711     -4.5824725180864334e-02
    z[8,3,3]  R1712     1.9795901607722044e-03
    z[8,3,3]  R1713     6.7289197444915771e-01
    z[8,3,3]  R1714     6.0950154066085815e-01
    z[8,3,3]  R1715     4.7397544980049133e-01
    z[8,3,3]  R1716     4.8006868362426758e-01
    z[8,3,3]  R1717     2.0311798900365829e-02
    z[8,3,3]  R1718     -4.1097089648246765e-01
    z[8,3,3]  R1719     4.3353244662284851e-01
    z[8,3,3]  R1720     3.1306838989257812e-01
    z[8,3,3]  R1721     -3.0565026402473450e-01
    z[8,3,3]  R1722     2.4861592054367065e-01
    z[8,3,3]  R1723     8.8877469301223755e-02
    z[8,3,3]  R1724     -1.5399585664272308e-01
    z[8,3,3]  R1725     4.1052162647247314e-01
    z[8,3,3]  R1726     -2.8152248263359070e-01
    z[8,3,3]  R1727     7.5641043484210968e-02
    z[8,3,3]  R1728     -9.4083890318870544e-02
    z[8,3,3]  R1729     3.7302400916814804e-02
    z[8,3,3]  R1730     -6.9526262581348419e-02
    z[8,3,3]  R1731     -3.0936279892921448e-01
    z[8,3,3]  R1732     5.2418440580368042e-02
    z[8,3,3]  R1733     3.3702442049980164e-01
    z[8,3,3]  R1734     5.6980293989181519e-01
    z[8,3,3]  R1735     4.3843919038772583e-01
    z[8,3,3]  R1736     -3.5689270496368408e-01
    z[8,3,3]  R1737     -2.8074812889099121e-01
    z[8,3,3]  R1738     3.2118624448776245e-01
    z[8,3,3]  R1739     -3.9957201480865479e-01
    z[8,3,3]  R1740     2.8057834506034851e-01
    z[8,3,3]  R1741     -0.649041473865509
    z[8,3,3]  R1742     -9.9989846348762512e-02
    z[8,3,3]  R1743     1.8089847872033715e-03
    z[8,3,3]  R1744     8.7370024994015694e-04
    z[8,3,3]  R1745     -3.8883021473884583e-01
    z[8,3,3]  R1746     -6.4202928543090820e-01
    z[8,3,3]  R1747     2.5093883275985718e-01
    z[8,3,3]  R1748     1.7347642779350281e-01
    z[8,3,3]  R1749     -1.0311586409807205e-01
    z[8,3,3]  R1750     -1.5421982109546661e-01
    z[8,3,3]  R1751     -4.7485277056694031e-01
    z[8,3,3]  R1752     -3.8497611880302429e-01
    z[8,3,3]  R1753     -3.3683210611343384e-01
    z[8,3,3]  R1754     3.6364433169364929e-01
    z[8,3,3]  R1755     2.2673273086547852e-01
    z[8,3,3]  R1756     0.277258962392807
    z[8,3,3]  R1757     -5.7367360591888428e-01
    z[8,3,3]  R1758     8.6202420294284821e-02
    z[8,3,3]  R1759     -3.1494984030723572e-01
    z[8,3,3]  R1760     -1.5366628766059875e-01
    z[8,3,3]  R1761     -1.6533143818378448e-01
    z[8,3,3]  R1762     2.4333539605140686e-01
    z[8,3,3]  R1763     -4.1196337342262268e-01
    z[8,3,3]  R1764     5.6809765100479126e-01
    z[8,3,3]  R1765     -3.2596006989479065e-02
    z[8,3,3]  R1766     -2.0463606715202332e-01
    z[8,3,3]  R1767     -2.2062188386917114e-01
    z[8,3,3]  R1768     -4.1860058903694153e-01
    z[8,3,3]  R1769     -4.4509038329124451e-02
    z[8,3,3]  R1770     -3.3235767483711243e-01
    z[8,3,3]  R1771     -2.3991049826145172e-01
    z[8,3,3]  R1772     -3.9578244090080261e-01
    z[8,3,3]  R1773     -1.1740065366029739e-01
    z[8,3,3]  R1774     4.9503996968269348e-01
    z[8,3,3]  R1775     -5.5340075492858887e-01
    z[8,3,3]  R1776     -3.4102407097816467e-01
    z[8,3,3]  R1777     1.7385666072368622e-01
    z[8,3,3]  R1778     -2.4025362730026245e-01
    z[8,3,3]  R1779     -3.6551502346992493e-01
    z[8,3,3]  R1780     1.0349040478467941e-01
    z[8,3,3]  R1781     -1.5072527341544628e-02
    z[8,3,3]  R1782     1.3338880613446236e-02
    z[8,3,4]  R33       1
    z[8,3,4]  R78       -1
    z[8,3,4]  R1597     -1
    z[8,3,4]  R1598     1
    z[8,3,4]  R1603     -3.0929857864975929e-02
    z[8,3,4]  R1604     4.3862223625183105e-02
    z[8,3,4]  R1605     -7.1362167596817017e-02
    z[8,3,4]  R1606     3.4079080820083618e-01
    z[8,3,4]  R1607     -0.17815001308918
    z[8,3,4]  R1608     -5.3338829427957535e-02
    z[8,3,4]  R1609     1.8202421069145203e-01
    z[8,3,4]  R1610     -1.1549197370186448e-03
    z[8,3,4]  R1611     1.7097112536430359e-01
    z[8,3,4]  R1612     1.6588468849658966e-01
    z[8,3,4]  R1613     -1.0755776613950729e-01
    z[8,3,4]  R1614     -3.3011589199304581e-02
    z[8,3,4]  R1615     1.8318261206150055e-01
    z[8,3,4]  R1616     -0.0909905806183815
    z[8,3,4]  R1617     -1.9154475629329681e-01
    z[8,3,4]  R1618     -1.0848290473222733e-01
    z[8,3,4]  R1619     -1.0991883277893066e-01
    z[8,3,4]  R1620     5.4228086024522781e-02
    z[8,3,4]  R1621     3.8252902030944824e-01
    z[8,3,4]  R1622     -4.4202274084091187e-01
    z[8,3,4]  R1623     -2.9359623789787292e-01
    z[8,3,4]  R1624     2.5340250134468079e-01
    z[8,3,4]  R1625     -2.7820026874542236e-01
    z[8,3,4]  R1626     2.5382417440414429e-01
    z[8,3,4]  R1627     -7.9937517642974854e-02
    z[8,3,4]  R1628     -3.2220691442489624e-01
    z[8,3,4]  R1629     3.4887593239545822e-02
    z[8,3,4]  R1630     5.7678680866956711e-02
    z[8,3,4]  R1631     -3.5977670550346375e-01
    z[8,3,4]  R1632     -1.0594666749238968e-01
    z[8,3,4]  R1633     1.8152515590190887e-01
    z[8,3,4]  R1634     -3.5370573401451111e-01
    z[8,3,4]  R1635     -7.6284185051918030e-02
    z[8,3,4]  R1636     -2.6278996467590332e-01
    z[8,3,4]  R1637     -5.0045949220657349e-01
    z[8,3,4]  R1638     9.5087058842182159e-02
    z[8,3,4]  R1639     1.3192920386791229e-01
    z[8,3,4]  R1640     -3.7163820862770081e-01
    z[8,3,4]  R1641     -1.5029367804527283e-01
    z[8,3,4]  R1642     -1.3495387136936188e-01
    z[8,3,4]  R1643     -2.0871834456920624e-01
    z[8,3,4]  R1644     1.8678975105285645e-01
    z[8,3,4]  R1645     2.5995094329118729e-02
    z[8,3,4]  R1646     2.8754368424415588e-01
    z[8,3,4]  R1647     2.7865159511566162e-01
    z[8,3,4]  R1648     -7.7265299856662750e-02
    z[8,3,4]  R1649     3.5431340336799622e-01
    z[8,3,4]  R1650     1.9545695185661316e-01
    z[8,3,4]  R1651     5.7299785315990448e-02
    z[8,3,4]  R1652     -8.0676466226577759e-02
    z[8,3,4]  R1653     7.4233666062355042e-02
    z[8,3,4]  R1654     -2.9526667669415474e-02
    z[8,3,4]  R1655     -1.7548096179962158e-01
    z[8,3,4]  R1656     -2.5313866138458252e-01
    z[8,3,4]  R1657     3.1068675220012665e-02
    z[8,3,4]  R1658     6.0402441024780273e-01
    z[8,3,4]  R1659     -2.0315755903720856e-01
    z[8,3,4]  R1660     -1.1944981664419174e-01
    z[8,3,4]  R1661     -3.3345988392829895e-01
    z[8,3,4]  R1662     4.9226564168930054e-01
    z[8,3,4]  R1663     0.192902609705925
    z[8,3,4]  R1664     -1.0200403630733490e-01
    z[8,3,4]  R1665     2.3301427066326141e-01
    z[8,3,4]  R1666     -3.9524596929550171e-01
    z[8,3,4]  R1667     -2.6711821556091309e-01
    z[8,3,4]  R1668     -4.3883770704269409e-01
    z[8,3,4]  R1669     -5.2055913209915161e-01
    z[8,3,4]  R1670     -7.5289912521839142e-02
    z[8,3,4]  R1671     -1.4688414335250854e-01
    z[8,3,4]  R1672     -4.3398797512054443e-01
    z[8,3,4]  R1673     3.2364809513092041e-01
    z[8,3,4]  R1674     3.2094126939773560e-01
    z[8,3,4]  R1675     -4.4822499155998230e-01
    z[8,3,4]  R1676     -5.5237084627151489e-01
    z[8,3,4]  R1677     -4.7012698650360107e-01
    z[8,3,4]  R1678     -3.3907783031463623e-01
    z[8,3,4]  R1679     -3.8905680179595947e-01
    z[8,3,4]  R1680     -3.0298039317131042e-01
    z[8,3,4]  R1681     5.9135757386684418e-02
    z[8,3,4]  R1682     -2.5848689675331116e-01
    z[8,3,4]  R1683     3.6975425481796265e-01
    z[8,3,4]  R1684     0.0836007222533226
    z[8,3,4]  R1685     2.7925944328308105e-01
    z[8,3,4]  R1686     1.6411504149436951e-01
    z[8,3,4]  R1687     -1.3834075629711151e-01
    z[8,3,4]  R1688     9.8664209246635437e-02
    z[8,3,4]  R1689     -1.6533695161342621e-01
    z[8,3,4]  R1690     -2.0861823856830597e-01
    z[8,3,4]  R1691     -2.3871515691280365e-01
    z[8,3,4]  R1692     -6.3319101929664612e-02
    z[8,3,4]  R1693     4.0838193893432617e-01
    z[8,3,4]  R1694     -1.8973509967327118e-01
    z[8,3,4]  R1695     3.4369704127311707e-01
    z[8,3,4]  R1696     -1.2840871512889862e-01
    z[8,3,4]  R1697     2.6399930939078331e-02
    z[8,3,4]  R1698     -2.5398489832878113e-01
    z[8,3,4]  R1699     -1.4980722218751907e-02
    z[8,3,4]  R1700     2.6581141352653503e-01
    z[8,3,4]  R1701     -5.2717506885528564e-01
    z[8,3,4]  R1702     -2.4696613848209381e-01
    z[8,3,4]  R1703     -2.6409873366355896e-01
    z[8,3,4]  R1704     -2.9159709811210632e-01
    z[8,3,4]  R1705     -4.9763542413711548e-01
    z[8,3,4]  R1706     -2.1162109076976776e-01
    z[8,3,4]  R1707     -3.0046626925468445e-01
    z[8,3,4]  R1708     -1.0412283986806870e-01
    z[8,3,4]  R1709     1.2374614179134369e-01
    z[8,3,4]  R1710     -5.5735909938812256e-01
    z[8,3,4]  R1711     -2.5431391596794128e-01
    z[8,3,4]  R1712     2.7516716718673706e-01
    z[8,3,4]  R1713     1.2355333566665649e-01
    z[8,3,4]  R1714     -3.3346304297447205e-01
    z[8,3,4]  R1715     -0.394437313079834
    z[8,3,4]  R1716     -2.4966441094875336e-01
    z[8,3,4]  R1717     3.9922407269477844e-01
    z[8,3,4]  R1718     4.2915868759155273e-01
    z[8,3,4]  R1719     1.0579667240381241e-01
    z[8,3,4]  R1720     -0.181906595826149
    z[8,3,4]  R1721     -7.3114745318889618e-02
    z[8,3,4]  R1722     -1.4692904055118561e-01
    z[8,3,4]  R1723     -4.5659685134887695e-01
    z[8,3,4]  R1724     1.6165295243263245e-01
    z[8,3,4]  R1725     -1.6063414514064789e-01
    z[8,3,4]  R1726     -4.8005864024162292e-01
    z[8,3,4]  R1727     3.8883373141288757e-02
    z[8,3,4]  R1728     1.1996621638536453e-01
    z[8,3,4]  R1729     3.7625020742416382e-01
    z[8,3,4]  R1730     3.4751359373331070e-02
    z[8,3,4]  R1731     4.7478446364402771e-01
    z[8,3,4]  R1732     -1.5053851902484894e-01
    z[8,3,4]  R1733     -2.2645914554595947e-01
    z[8,3,4]  R1734     -5.7060797698795795e-03
    z[8,3,4]  R1735     -7.6822616159915924e-02
    z[8,3,4]  R1736     2.1029409021139145e-02
    z[8,3,4]  R1737     1.8492749333381653e-01
    z[8,3,4]  R1738     -1.1500279605388641e-01
    z[8,3,4]  R1739     6.0783304274082184e-02
    z[8,3,4]  R1740     7.0928357541561127e-02
    z[8,3,4]  R1741     -0.42122882604599
    z[8,3,4]  R1742     1.3787874579429626e-01
    z[8,3,4]  R1743     2.6096263527870178e-01
    z[8,3,4]  R1744     -0.16848124563694
    z[8,3,4]  R1745     3.8658101111650467e-02
    z[8,3,4]  R1746     -4.1916516423225403e-01
    z[8,3,4]  R1747     4.3393567204475403e-01
    z[8,3,4]  R1748     2.7704099193215370e-02
    z[8,3,4]  R1749     3.0394849181175232e-01
    z[8,3,4]  R1750     -2.5828543305397034e-01
    z[8,3,4]  R1751     3.7149384617805481e-01
    z[8,3,4]  R1752     4.7176092863082886e-02
    z[8,3,4]  R1753     -2.7131193876266479e-01
    z[8,3,4]  R1754     -2.9805478453636169e-01
    z[8,3,4]  R1755     -6.0237679630517960e-02
    z[8,3,4]  R1756     -6.2752211093902588e-01
    z[8,3,4]  R1757     1.4327786862850189e-01
    z[8,3,4]  R1758     -4.9175915122032166e-01
    z[8,3,4]  R1759     -9.4972558319568634e-02
    z[8,3,4]  R1760     9.8763778805732727e-02
    z[8,3,4]  R1761     -1.2358006834983826e-01
    z[8,3,4]  R1762     8.0499485135078430e-02
    z[8,3,4]  R1763     2.8234642744064331e-01
    z[8,3,4]  R1764     9.6305571496486664e-02
    z[8,3,4]  R1765     -7.1907705068588257e-01
    z[8,3,4]  R1766     -1.6345153562724590e-03
    z[8,3,4]  R1767     -2.5797012448310852e-01
    z[8,3,4]  R1768     -1.1582937091588974e-01
    z[8,3,4]  R1769     2.3507069051265717e-01
    z[8,3,4]  R1770     -1.5902440249919891e-01
    z[8,3,4]  R1771     -1.6797071322798729e-02
    z[8,3,4]  R1772     1.1166515201330185e-01
    z[8,3,4]  R1773     -2.2787198424339294e-01
    z[8,3,4]  R1774     -1.4868468046188354e-01
    z[8,3,4]  R1775     -3.1543251127004623e-02
    z[8,3,4]  R1776     4.9308642745018005e-02
    z[8,3,4]  R1777     3.4621319174766541e-01
    z[8,3,4]  R1778     -2.5849640369415283e-01
    z[8,3,4]  R1779     2.3924781382083893e-01
    z[8,3,4]  R1780     1.4420378953218460e-02
    z[8,3,4]  R1781     -0.0878065750002861
    z[8,3,4]  R1782     4.0671084076166153e-02
    z[8,3,5]  R34       1
    z[8,3,5]  R79       -1
    z[8,3,5]  R1599     -1
    z[8,3,5]  R1600     1
    z[8,3,5]  R1603     -7.0518068969249725e-02
    z[8,3,5]  R1604     2.9320802539587021e-02
    z[8,3,5]  R1605     1.6049274802207947e-01
    z[8,3,5]  R1606     9.7442999482154846e-02
    z[8,3,5]  R1607     1.2150280922651291e-01
    z[8,3,5]  R1608     6.1087656766176224e-02
    z[8,3,5]  R1609     -8.9247547090053558e-02
    z[8,3,5]  R1610     8.4644109010696411e-02
    z[8,3,5]  R1611     2.7353477478027344e-01
    z[8,3,5]  R1612     4.0036666393280029e-01
    z[8,3,5]  R1613     3.6903893947601318e-01
    z[8,3,5]  R1614     6.8073374032974243e-01
    z[8,3,5]  R1615     4.3479007482528687e-01
    z[8,3,5]  R1616     8.1305164098739624e-01
    z[8,3,5]  R1617     5.3321695327758789e-01
    z[8,3,5]  R1618     4.6339431405067444e-01
    z[8,3,5]  R1619     5.6345325708389282e-01
    z[8,3,5]  R1620     -2.1080057322978973e-01
    z[8,3,5]  R1621     -0.598402738571167
    z[8,3,5]  R1622     1.0290031135082245e-01
    z[8,3,5]  R1623     -4.8102951049804688e-01
    z[8,3,5]  R1624     2.3012389242649078e-01
    z[8,3,5]  R1625     4.5984706282615662e-01
    z[8,3,5]  R1626     1.4776639640331268e-01
    z[8,3,5]  R1627     -5.0973349809646606e-01
    z[8,3,5]  R1628     1.6818402707576752e-01
    z[8,3,5]  R1629     -3.8613748550415039e-01
    z[8,3,5]  R1630     2.5651791691780090e-01
    z[8,3,5]  R1631     -2.0864118635654449e-01
    z[8,3,5]  R1632     2.4168965220451355e-01
    z[8,3,5]  R1633     3.4985315799713135e-01
    z[8,3,5]  R1634     0.411308616399765
    z[8,3,5]  R1635     1.1703790724277496e-01
    z[8,3,5]  R1636     -3.2389920949935913e-01
    z[8,3,5]  R1637     -0.0661073550581932
    z[8,3,5]  R1638     2.2231031954288483e-01
    z[8,3,5]  R1639     -2.4207718670368195e-01
    z[8,3,5]  R1640     -6.9456794299185276e-03
    z[8,3,5]  R1641     4.4466793537139893e-02
    z[8,3,5]  R1642     2.6548272371292114e-01
    z[8,3,5]  R1643     -2.4890737235546112e-01
    z[8,3,5]  R1644     -2.2501491010189056e-01
    z[8,3,5]  R1645     -1.0241493582725525e-01
    z[8,3,5]  R1646     7.6932793855667114e-01
    z[8,3,5]  R1647     7.6607394218444824e-01
    z[8,3,5]  R1648     8.9728303253650665e-02
    z[8,3,5]  R1649     -3.3832769840955734e-03
    z[8,3,5]  R1650     2.5807055830955505e-01
    z[8,3,5]  R1651     -2.2562643885612488e-01
    z[8,3,5]  R1652     1.8531037867069244e-01
    z[8,3,5]  R1653     -1.9545707106590271e-01
    z[8,3,5]  R1654     -1.3591052591800690e-01
    z[8,3,5]  R1655     -1.4011819660663605e-01
    z[8,3,5]  R1656     -5.3619122505187988e-01
    z[8,3,5]  R1657     8.0709677934646606e-01
    z[8,3,5]  R1658     -1.8276451528072357e-01
    z[8,3,5]  R1659     -1.6230879724025726e-01
    z[8,3,5]  R1660     2.7760567143559456e-02
    z[8,3,5]  R1661     6.0488367080688477e-01
    z[8,3,5]  R1662     3.2660558819770813e-01
    z[8,3,5]  R1663     3.5799962282180786e-01
    z[8,3,5]  R1664     4.3259340524673462e-01
    z[8,3,5]  R1665     -2.1127325296401978e-01
    z[8,3,5]  R1666     1.3093756139278412e-01
    z[8,3,5]  R1667     3.7043792009353638e-01
    z[8,3,5]  R1668     -0.0495392307639122
    z[8,3,5]  R1669     3.2732561230659485e-01
    z[8,3,5]  R1670     -2.2811965644359589e-01
    z[8,3,5]  R1671     -2.7723529934883118e-01
    z[8,3,5]  R1672     -1.8648815155029297e-01
    z[8,3,5]  R1673     3.0621299147605896e-01
    z[8,3,5]  R1674     1.3879445195198059e-01
    z[8,3,5]  R1675     1.6501431167125702e-01
    z[8,3,5]  R1676     3.9671370387077332e-01
    z[8,3,5]  R1677     -4.4743424654006958e-01
    z[8,3,5]  R1678     -2.1514873206615448e-01
    z[8,3,5]  R1679     -6.6480213403701782e-01
    z[8,3,5]  R1680     -7.0080637931823730e-01
    z[8,3,5]  R1681     5.6166354566812515e-02
    z[8,3,5]  R1682     -0.560685932636261
    z[8,3,5]  R1683     3.3980527520179749e-01
    z[8,3,5]  R1684     0.486115425825119
    z[8,3,5]  R1685     9.7025007009506226e-02
    z[8,3,5]  R1686     2.9867282509803772e-01
    z[8,3,5]  R1687     4.1259261965751648e-01
    z[8,3,5]  R1688     4.1188114881515503e-01
    z[8,3,5]  R1689     -0.074520044028759
    z[8,3,5]  R1690     -1.9655311107635498e-01
    z[8,3,5]  R1691     -2.0525650680065155e-01
    z[8,3,5]  R1692     0.0744505226612091
    z[8,3,5]  R1693     -9.6932850778102875e-02
    z[8,3,5]  R1694     -6.0361623764038086e-01
    z[8,3,5]  R1695     2.6354864239692688e-01
    z[8,3,5]  R1696     2.4786043167114258e-01
    z[8,3,5]  R1697     1.6977612674236298e-01
    z[8,3,5]  R1698     -9.4695478677749634e-02
    z[8,3,5]  R1699     -2.2654792666435242e-01
    z[8,3,5]  R1700     -2.9492089152336121e-01
    z[8,3,5]  R1701     3.2390865683555603e-01
    z[8,3,5]  R1702     -8.4928011894226074e-01
    z[8,3,5]  R1703     -1.0813717544078827e-01
    z[8,3,5]  R1704     -2.7280244231224060e-01
    z[8,3,5]  R1705     -4.6663495898246765e-01
    z[8,3,5]  R1706     -5.3795474767684937e-01
    z[8,3,5]  R1707     -1.1047238111495972e-01
    z[8,3,5]  R1708     1.4906586706638336e-01
    z[8,3,5]  R1709     -7.2340106964111328e-01
    z[8,3,5]  R1710     0.17389015853405
    z[8,3,5]  R1711     1.3917692005634308e-01
    z[8,3,5]  R1712     -2.3230737075209618e-02
    z[8,3,5]  R1713     -7.0192688703536987e-01
    z[8,3,5]  R1714     -3.6358866095542908e-01
    z[8,3,5]  R1715     -5.8569401502609253e-01
    z[8,3,5]  R1716     -4.0828722715377808e-01
    z[8,3,5]  R1717     3.3582428097724915e-01
    z[8,3,5]  R1718     1.7942123115062714e-01
    z[8,3,5]  R1719     -4.3635964393615723e-01
    z[8,3,5]  R1720     -4.8830467462539673e-01
    z[8,3,5]  R1721     -1.7145806550979614e-01
    z[8,3,5]  R1722     -4.1066142916679382e-01
    z[8,3,5]  R1723     6.2644377350807190e-02
    z[8,3,5]  R1724     -1.7560601234436035e-01
    z[8,3,5]  R1725     -0.392000675201416
    z[8,3,5]  R1726     1.3934718072414398e-01
    z[8,3,5]  R1727     -3.3349204063415527e-01
    z[8,3,5]  R1728     -1.2825973331928253e-01
    z[8,3,5]  R1729     4.3615409731864929e-01
    z[8,3,5]  R1730     2.9254710674285889e-01
    z[8,3,5]  R1731     -0.0223592147231102
    z[8,3,5]  R1732     1.2361817806959152e-01
    z[8,3,5]  R1733     4.9798870086669922e-01
    z[8,3,5]  R1734     -0.242364302277565
    z[8,3,5]  R1735     -6.2602925300598145e-01
    z[8,3,5]  R1736     1.8952375650405884e-01
    z[8,3,5]  R1737     -5.4515582323074341e-01
    z[8,3,5]  R1738     -3.3561038970947266e-01
    z[8,3,5]  R1739     1.5446986258029938e-01
    z[8,3,5]  R1740     2.5392949581146240e-01
    z[8,3,5]  R1741     -3.6997672915458679e-01
    z[8,3,5]  R1742     5.0624340772628784e-01
    z[8,3,5]  R1743     4.5626637339591980e-01
    z[8,3,5]  R1744     4.2337018251419067e-01
    z[8,3,5]  R1745     -3.2346537709236145e-01
    z[8,3,5]  R1746     -3.3001348376274109e-01
    z[8,3,5]  R1747     -1.9071669876575470e-01
    z[8,3,5]  R1748     -2.1720662713050842e-02
    z[8,3,5]  R1749     1.8512552604079247e-02
    z[8,3,5]  R1750     2.5458592176437378e-01
    z[8,3,5]  R1751     3.2484656572341919e-01
    z[8,3,5]  R1752     9.8366884049028158e-04
    z[8,3,5]  R1753     3.3701050281524658e-01
    z[8,3,5]  R1754     -3.8555371761322021e-01
    z[8,3,5]  R1755     -5.9404969215393066e-01
    z[8,3,5]  R1756     -4.4391539692878723e-01
    z[8,3,5]  R1757     -4.4910570979118347e-01
    z[8,3,5]  R1758     -1.1908382177352905e-01
    z[8,3,5]  R1759     -3.5017880797386169e-01
    z[8,3,5]  R1760     -3.3454936742782593e-01
    z[8,3,5]  R1761     -1.4463682472705841e-01
    z[8,3,5]  R1762     3.1754285097122192e-01
    z[8,3,5]  R1763     -1.9783751666545868e-01
    z[8,3,5]  R1764     -3.1333526968955994e-01
    z[8,3,5]  R1765     -6.5661799907684326e-01
    z[8,3,5]  R1766     -0.303000271320343
    z[8,3,5]  R1767     3.2724419236183167e-01
    z[8,3,5]  R1768     1.0442462563514709e-01
    z[8,3,5]  R1769     5.4920810461044312e-01
    z[8,3,5]  R1770     3.1957671046257019e-01
    z[8,3,5]  R1771     6.4711350202560425e-01
    z[8,3,5]  R1772     1.8048487603664398e-01
    z[8,3,5]  R1773     -3.1513166427612305e-01
    z[8,3,5]  R1774     -6.5260219573974609e-01
    z[8,3,5]  R1775     -1.8633204698562622e-01
    z[8,3,5]  R1776     -1.1351475864648819e-01
    z[8,3,5]  R1777     -2.0502893626689911e-01
    z[8,3,5]  R1778     2.9521077871322632e-01
    z[8,3,5]  R1779     3.3200421929359436e-01
    z[8,3,5]  R1780     0.461311936378479
    z[8,3,5]  R1781     6.2382197380065918e-01
    z[8,3,5]  R1782     4.1954675316810608e-01
    z[8,3,6]  R35       1
    z[8,3,6]  R80       -1
    z[8,3,6]  R1601     -1
    z[8,3,6]  R1602     1
    z[8,3,6]  R1603     -1.4853195846080780e-01
    z[8,3,6]  R1604     -6.0669219493865967e-01
    z[8,3,6]  R1605     3.8330513983964920e-02
    z[8,3,6]  R1606     -3.5251826047897339e-01
    z[8,3,6]  R1607     -9.1001898050308228e-02
    z[8,3,6]  R1608     1.1751641333103180e-01
    z[8,3,6]  R1609     4.5755349099636078e-02
    z[8,3,6]  R1610     2.4354528635740280e-02
    z[8,3,6]  R1611     -5.3508855402469635e-02
    z[8,3,6]  R1612     -2.3536704480648041e-01
    z[8,3,6]  R1613     1.1895284801721573e-01
    z[8,3,6]  R1614     -1.0439812391996384e-01
    z[8,3,6]  R1615     1.0300076566636562e-02
    z[8,3,6]  R1616     -6.8263687193393707e-02
    z[8,3,6]  R1617     -3.1316304206848145e-01
    z[8,3,6]  R1618     -2.7121287584304810e-01
    z[8,3,6]  R1619     -5.6809592247009277e-01
    z[8,3,6]  R1620     -9.1780908405780792e-02
    z[8,3,6]  R1621     2.5107720494270325e-01
    z[8,3,6]  R1622     8.4061108529567719e-02
    z[8,3,6]  R1623     1.1446928232908249e-01
    z[8,3,6]  R1624     5.7627558708190918e-01
    z[8,3,6]  R1625     -4.0148171782493591e-01
    z[8,3,6]  R1626     -4.9632743000984192e-01
    z[8,3,6]  R1627     -2.4001958966255188e-01
    z[8,3,6]  R1628     8.0292999744415283e-02
    z[8,3,6]  R1629     -0.263278603553772
    z[8,3,6]  R1630     -3.5444416105747223e-02
    z[8,3,6]  R1631     -3.1469020247459412e-01
    z[8,3,6]  R1632     4.0821629762649536e-01
    z[8,3,6]  R1633     2.0155639946460724e-01
    z[8,3,6]  R1634     -2.5141993165016174e-01
    z[8,3,6]  R1635     3.7151420116424561e-01
    z[8,3,6]  R1636     8.0253079533576965e-02
    z[8,3,6]  R1637     -1.4116473495960236e-01
    z[8,3,6]  R1638     2.5778514146804810e-01
    z[8,3,6]  R1639     5.3164589405059814e-01
    z[8,3,6]  R1640     1.2013272196054459e-01
    z[8,3,6]  R1641     -2.3785415291786194e-01
    z[8,3,6]  R1642     -1.9478686153888702e-01
    z[8,3,6]  R1643     -4.6476888656616211e-01
    z[8,3,6]  R1644     1.7436721920967102e-01
    z[8,3,6]  R1645     -6.8205338716506958e-01
    z[8,3,6]  R1646     1.2163235992193222e-01
    z[8,3,6]  R1647     -2.7614856138825417e-02
    z[8,3,6]  R1648     -5.3601509332656860e-01
    z[8,3,6]  R1649     -3.3391021192073822e-02
    z[8,3,6]  R1650     -5.5280399322509766e-01
    z[8,3,6]  R1651     -2.1958464756608009e-02
    z[8,3,6]  R1652     2.9406201839447021e-01
    z[8,3,6]  R1653     2.1542693674564362e-01
    z[8,3,6]  R1654     -2.3527100682258606e-01
    z[8,3,6]  R1655     4.8838317394256592e-01
    z[8,3,6]  R1656     -1.5909896790981293e-01
    z[8,3,6]  R1657     0.198703795671463
    z[8,3,6]  R1658     -3.1156727671623230e-01
    z[8,3,6]  R1659     -1.5996801853179932e-01
    z[8,3,6]  R1660     -0.421928346157074
    z[8,3,6]  R1661     2.3076918721199036e-01
    z[8,3,6]  R1662     1.3824053108692169e-01
    z[8,3,6]  R1663     0.122501440346241
    z[8,3,6]  R1664     1.0997556149959564e-01
    z[8,3,6]  R1665     -2.1318021416664124e-01
    z[8,3,6]  R1666     -3.3069238066673279e-02
    z[8,3,6]  R1667     2.8779405355453491e-01
    z[8,3,6]  R1668     -1.6068504750728607e-01
    z[8,3,6]  R1669     2.2490942478179932e-01
    z[8,3,6]  R1670     -2.4933236837387085e-01
    z[8,3,6]  R1671     -2.3067300207912922e-04
    z[8,3,6]  R1672     -4.7878619283437729e-02
    z[8,3,6]  R1673     -1.1579968780279160e-01
    z[8,3,6]  R1674     2.3130239546298981e-01
    z[8,3,6]  R1675     -1.3899651356041431e-02
    z[8,3,6]  R1676     1.4802783727645874e-01
    z[8,3,6]  R1677     -1.4510647952556610e-01
    z[8,3,6]  R1678     -1.1211130023002625e-01
    z[8,3,6]  R1679     -2.7499282732605934e-02
    z[8,3,6]  R1680     1.1985295452177525e-02
    z[8,3,6]  R1681     -4.6924528479576111e-01
    z[8,3,6]  R1682     -1.1394876986742020e-01
    z[8,3,6]  R1683     -1.1921192705631256e-01
    z[8,3,6]  R1684     -1.0565267503261566e-01
    z[8,3,6]  R1685     -1.8575143814086914e-01
    z[8,3,6]  R1686     -1.1226785928010941e-01
    z[8,3,6]  R1687     -2.7282893657684326e-01
    z[8,3,6]  R1688     -3.4772503376007080e-01
    z[8,3,6]  R1689     -1.6278398036956787e-01
    z[8,3,6]  R1690     -3.4013012051582336e-01
    z[8,3,6]  R1691     -2.7045345306396484e-01
    z[8,3,6]  R1692     2.0042194426059723e-01
    z[8,3,6]  R1693     -2.1347667276859283e-01
    z[8,3,6]  R1694     7.5314551591873169e-02
    z[8,3,6]  R1695     4.8321974277496338e-01
    z[8,3,6]  R1696     2.0423837006092072e-01
    z[8,3,6]  R1697     -2.2396599873900414e-02
    z[8,3,6]  R1698     6.8618965148925781e-01
    z[8,3,6]  R1699     3.4243202209472656e-01
    z[8,3,6]  R1700     -1.0500402003526688e-01
    z[8,3,6]  R1701     1.4225970208644867e-01
    z[8,3,6]  R1702     -8.8078305125236511e-02
    z[8,3,6]  R1703     1.0345313698053360e-01
    z[8,3,6]  R1704     -6.8595241755247116e-03
    z[8,3,6]  R1705     -4.4258746504783630e-01
    z[8,3,6]  R1706     -2.6830476522445679e-01
    z[8,3,6]  R1707     6.9326788187026978e-02
    z[8,3,6]  R1708     -3.4348601102828979e-01
    z[8,3,6]  R1709     0.0750337466597557
    z[8,3,6]  R1710     0.390138179063797
    z[8,3,6]  R1711     1.6677644848823547e-01
    z[8,3,6]  R1712     7.4481196701526642e-02
    z[8,3,6]  R1713     -1.8555977940559387e-01
    z[8,3,6]  R1714     1.0878256708383560e-01
    z[8,3,6]  R1715     2.2727511823177338e-02
    z[8,3,6]  R1716     -1.7764264345169067e-01
    z[8,3,6]  R1717     3.2427048683166504e-01
    z[8,3,6]  R1718     3.8796347379684448e-01
    z[8,3,6]  R1719     2.9086786508560181e-01
    z[8,3,6]  R1720     5.3685763850808144e-03
    z[8,3,6]  R1721     4.7650119662284851e-01
    z[8,3,6]  R1722     1.9865010678768158e-01
    z[8,3,6]  R1723     8.7767750024795532e-02
    z[8,3,6]  R1724     7.5500112771987915e-01
    z[8,3,6]  R1725     -2.2788988426327705e-02
    z[8,3,6]  R1726     -5.5582004785537720e-01
    z[8,3,6]  R1727     -3.8580577820539474e-02
    z[8,3,6]  R1728     -1.2512862682342529e-01
    z[8,3,6]  R1729     1.8459033966064453e-01
    z[8,3,6]  R1730     1.6274780035018921e-01
    z[8,3,6]  R1731     1.2327576428651810e-01
    z[8,3,6]  R1732     -1.0316102951765060e-01
    z[8,3,6]  R1733     1.7142336070537567e-01
    z[8,3,6]  R1734     -1.6085078939795494e-02
    z[8,3,6]  R1735     -4.6470880508422852e-02
    z[8,3,6]  R1736     1.5468142926692963e-02
    z[8,3,6]  R1737     1.5896968543529510e-01
    z[8,3,6]  R1738     5.0948962569236755e-02
    z[8,3,6]  R1739     8.9596778154373169e-02
    z[8,3,6]  R1740     1.1430647969245911e-01
    z[8,3,6]  R1741     2.1785560250282288e-01
    z[8,3,6]  R1742     1.8165364861488342e-01
    z[8,3,6]  R1743     2.8705176711082458e-01
    z[8,3,6]  R1744     -1.0856804251670837e-01
    z[8,3,6]  R1745     -1.2562349438667297e-01
    z[8,3,6]  R1746     2.7592003345489502e-02
    z[8,3,6]  R1747     -0.145661860704422
    z[8,3,6]  R1748     2.5001093745231628e-01
    z[8,3,6]  R1749     -1.5254151821136475e-01
    z[8,3,6]  R1750     -0.0850839912891388
    z[8,3,6]  R1751     -0.560992419719696
    z[8,3,6]  R1752     2.0289690792560577e-01
    z[8,3,6]  R1753     2.9001367092132568e-01
    z[8,3,6]  R1754     5.1871906965970993e-02
    z[8,3,6]  R1755     4.8334410786628723e-01
    z[8,3,6]  R1756     -5.3901600837707520e-01
    z[8,3,6]  R1757     1.5751791000366211e-01
    z[8,3,6]  R1758     2.2093172371387482e-01
    z[8,3,6]  R1759     -8.7031356990337372e-02
    z[8,3,6]  R1760     -3.7781888246536255e-01
    z[8,3,6]  R1761     -5.3689569234848022e-02
    z[8,3,6]  R1762     2.2673925757408142e-01
    z[8,3,6]  R1763     3.9606702327728271e-01
    z[8,3,6]  R1764     4.1313868761062622e-01
    z[8,3,6]  R1765     -7.8150011599063873e-02
    z[8,3,6]  R1766     -3.9280518889427185e-02
    z[8,3,6]  R1767     1.1420807242393494e-01
    z[8,3,6]  R1768     -8.6310803890228271e-02
    z[8,3,6]  R1769     -1.9005009904503822e-02
    z[8,3,6]  R1770     -3.6157715320587158e-01
    z[8,3,6]  R1771     -2.1683798730373383e-01
    z[8,3,6]  R1772     3.4990105032920837e-01
    z[8,3,6]  R1773     5.6830104440450668e-02
    z[8,3,6]  R1774     2.1327154338359833e-01
    z[8,3,6]  R1775     -1.5577603876590729e-01
    z[8,3,6]  R1776     -3.4625567495822906e-02
    z[8,3,6]  R1777     -1.4220872521400452e-01
    z[8,3,6]  R1778     9.6423342823982239e-02
    z[8,3,6]  R1779     -1.7282311618328094e-01
    z[8,3,6]  R1780     -0.378086119890213
    z[8,3,6]  R1781     3.4706908464431763e-01
    z[8,3,6]  R1782     1.7097742855548859e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1897     -1
    z[4,5,0]  R1898     1
    z[4,5,0]  R1911     3.1280374526977539e-01
    z[4,5,0]  R1912     -3.6479675769805908e-01
    z[4,5,0]  R1913     -7.0757251977920532e-01
    z[4,5,0]  R1914     -7.7134460210800171e-01
    z[4,5,0]  R1915     -7.6169526576995850e-01
    z[4,5,0]  R1916     0.670039713382721
    z[4,5,0]  R1917     -6.3153463602066040e-01
    z[4,5,0]  R1918     -2.7676162123680115e-01
    z[4,5,0]  R1919     1.0108610242605209e-01
    z[4,5,0]  R1920     0.219046488404274
    z[4,5,0]  R1921     2.5553833693265915e-03
    z[4,5,0]  R1922     1.3077133893966675e-01
    z[4,5,0]  R1923     -3.1307630240917206e-02
    z[4,5,0]  R1924     3.9913639426231384e-01
    z[4,5,0]  R1925     2.7574592828750610e-01
    z[4,5,0]  R1926     0.0935889184474945
    z[4,5,0]  R1927     -4.4590409845113754e-02
    z[4,5,0]  R1928     2.5477501749992371e-01
    z[4,5,0]  R1929     1.4936186373233795e-01
    z[4,5,0]  R1930     2.3234197497367859e-01
    z[4,5,0]  R1931     4.9659404903650284e-02
    z[4,5,0]  R1932     -0.358368843793869
    z[4,5,0]  R1933     2.0152449607849121e-01
    z[4,5,0]  R1934     -2.3189561069011688e-01
    z[4,5,0]  R1935     -7.2277379035949707e-01
    z[4,5,0]  R1936     0.805334210395813
    z[4,5,0]  R1937     7.3077583312988281e-01
    z[4,5,0]  R1938     1.1370386183261871e-01
    z[4,5,0]  R1939     -7.7118612825870514e-02
    z[4,5,0]  R1940     1.3980850577354431e-01
    z[4,5,0]  R1941     -3.9450824260711670e-01
    z[4,5,0]  R1942     -5.3267621994018555e-01
    z[4,5,0]  R1943     1.5024597942829132e-01
    z[4,5,0]  R1944     1.7440715432167053e-01
    z[4,5,0]  R1945     6.5103721618652344e-01
    z[4,5,0]  R1946     1.6288323327898979e-02
    z[4,5,0]  R1947     -3.3365017175674438e-01
    z[4,5,0]  R1948     -5.9681493043899536e-01
    z[4,5,0]  R1949     -4.3888008594512939e-01
    z[4,5,0]  R1950     3.3577498793601990e-01
    z[4,5,0]  R1951     4.0972787141799927e-01
    z[4,5,0]  R1952     1.8252097070217133e-01
    z[4,5,0]  R1953     9.0965494513511658e-02
    z[4,5,0]  R1954     -5.5656415224075317e-01
    z[4,5,0]  R1955     -3.1916010379791260e-01
    z[4,5,0]  R1956     -8.7184444069862366e-02
    z[4,5,0]  R1957     -4.1862553358078003e-01
    z[4,5,0]  R1958     -6.4222311973571777e-01
    z[4,5,0]  R1959     6.0630504041910172e-02
    z[4,5,0]  R1960     -4.8078897595405579e-01
    z[4,5,0]  R1961     -4.2030301690101624e-01
    z[4,5,0]  R1962     0.355146199464798
    z[4,5,0]  R1963     2.7121397852897644e-01
    z[4,5,0]  R1964     4.7907616943120956e-02
    z[4,5,0]  R1965     1.3716715574264526e-01
    z[4,5,0]  R1966     -4.7560158371925354e-01
    z[4,5,0]  R1967     -6.0663259029388428e-01
    z[4,5,0]  R1968     2.3190313577651978e-01
    z[4,5,0]  R1969     2.1783809363842010e-01
    z[4,5,0]  R1970     3.5618704557418823e-01
    z[4,5,0]  R1971     3.3672192692756653e-01
    z[4,5,0]  R1972     2.8452232480049133e-01
    z[4,5,0]  R1973     3.6942040920257568e-01
    z[4,5,0]  R1974     3.5282671451568604e-01
    z[4,5,0]  R1975     -4.4571959972381592e-01
    z[4,5,0]  R1976     1.0341478139162064e-01
    z[4,5,0]  R1977     3.4538006782531738e-01
    z[4,5,0]  R1978     2.1061430871486664e-01
    z[4,5,0]  R1979     1.9354499876499176e-01
    z[4,5,0]  R1980     1.7186896502971649e-01
    z[4,5,0]  R1981     -3.8703698664903641e-02
    z[4,5,0]  R1982     2.5730609893798828e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1899     -1
    z[4,5,1]  R1900     1
    z[4,5,1]  R1911     -4.2932558059692383e-01
    z[4,5,1]  R1912     -6.7576491832733154e-01
    z[4,5,1]  R1913     2.0904146134853363e-01
    z[4,5,1]  R1914     4.9067354202270508e-01
    z[4,5,1]  R1915     4.0315636992454529e-01
    z[4,5,1]  R1916     4.1437533497810364e-01
    z[4,5,1]  R1917     1.3012956082820892e-01
    z[4,5,1]  R1918     0.589113175868988
    z[4,5,1]  R1919     3.9583536982536316e-01
    z[4,5,1]  R1920     3.5854130983352661e-01
    z[4,5,1]  R1921     3.7020951509475708e-01
    z[4,5,1]  R1922     7.5881212949752808e-01
    z[4,5,1]  R1923     3.9203503727912903e-01
    z[4,5,1]  R1924     -5.6707769632339478e-01
    z[4,5,1]  R1925     -2.9880559444427490e-01
    z[4,5,1]  R1926     2.4329890310764313e-01
    z[4,5,1]  R1927     -2.1724271774291992e-01
    z[4,5,1]  R1928     -6.3097810745239258e-01
    z[4,5,1]  R1929     -4.3904387950897217e-01
    z[4,5,1]  R1930     7.1723777055740356e-01
    z[4,5,1]  R1931     4.3934261798858643e-01
    z[4,5,1]  R1932     -1.7849127948284149e-01
    z[4,5,1]  R1933     7.4805237352848053e-02
    z[4,5,1]  R1934     0.0457318089902401
    z[4,5,1]  R1935     4.9335613846778870e-01
    z[4,5,1]  R1936     -5.2092432975769043e-01
    z[4,5,1]  R1937     -3.1740444898605347e-01
    z[4,5,1]  R1938     -4.7887480258941650e-01
    z[4,5,1]  R1939     3.2369661331176758e-01
    z[4,5,1]  R1940     7.4469465017318726e-01
    z[4,5,1]  R1941     3.1814590096473694e-01
    z[4,5,1]  R1942     -3.7238383293151855e-01
    z[4,5,1]  R1943     -4.2741736769676208e-01
    z[4,5,1]  R1944     -3.2416197657585144e-01
    z[4,5,1]  R1945     -2.1738414466381073e-01
    z[4,5,1]  R1946     -1.8900883197784424e-01
    z[4,5,1]  R1947     3.3727544546127319e-01
    z[4,5,1]  R1948     9.7226023674011230e-02
    z[4,5,1]  R1949     -7.2843387722969055e-02
    z[4,5,1]  R1950     6.4356744289398193e-01
    z[4,5,1]  R1951     7.6706510782241821e-01
    z[4,5,1]  R1952     6.5957701206207275e-01
    z[4,5,1]  R1953     -5.0450706481933594e-01
    z[4,5,1]  R1954     5.6698240339756012e-02
    z[4,5,1]  R1955     4.8791885375976562e-02
    z[4,5,1]  R1956     -1.3757948577404022e-01
    z[4,5,1]  R1957     3.7401422858238220e-01
    z[4,5,1]  R1958     1.1739350110292435e-01
    z[4,5,1]  R1959     2.3625028133392334e-01
    z[4,5,1]  R1960     1.8291552364826202e-01
    z[4,5,1]  R1961     4.8557594418525696e-02
    z[4,5,1]  R1962     7.9516094923019409e-01
    z[4,5,1]  R1963     -1.7780935764312744e-01
    z[4,5,1]  R1964     -2.0906296372413635e-01
    z[4,5,1]  R1965     -3.6919206380844116e-01
    z[4,5,1]  R1966     3.8943886756896973e-01
    z[4,5,1]  R1967     2.8447780013084412e-01
    z[4,5,1]  R1968     8.3946412801742554e-01
    z[4,5,1]  R1969     0.894114077091217
    z[4,5,1]  R1970     7.2143363952636719e-01
    z[4,5,1]  R1971     6.5222895145416260e-01
    z[4,5,1]  R1972     6.5590417385101318e-01
    z[4,5,1]  R1973     -5.3437268733978271e-01
    z[4,5,1]  R1974     -1.7508365213871002e-01
    z[4,5,1]  R1975     1.9357708096504211e-01
    z[4,5,1]  R1976     7.8060162067413330e-01
    z[4,5,1]  R1977     0.706145167350769
    z[4,5,1]  R1978     3.6584153771400452e-01
    z[4,5,1]  R1979     3.0645939707756042e-01
    z[4,5,1]  R1980     3.1118473410606384e-01
    z[4,5,1]  R1981     1.4049403369426727e-01
    z[4,5,1]  R1982     4.9242043495178223e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1901     -1
    z[4,5,2]  R1902     1
    z[4,5,2]  R1911     2.2591508924961090e-01
    z[4,5,2]  R1912     -2.1254327893257141e-01
    z[4,5,2]  R1913     -5.9841352701187134e-01
    z[4,5,2]  R1914     8.1337429583072662e-02
    z[4,5,2]  R1915     7.7377937734127045e-02
    z[4,5,2]  R1916     -2.5290283560752869e-01
    z[4,5,2]  R1917     2.1290490031242371e-01
    z[4,5,2]  R1918     -5.2991569042205811e-01
    z[4,5,2]  R1919     -2.7966782450675964e-01
    z[4,5,2]  R1920     -3.1875881552696228e-01
    z[4,5,2]  R1921     5.4847621917724609e-01
    z[4,5,2]  R1922     6.5688274800777435e-02
    z[4,5,2]  R1923     4.2364135384559631e-01
    z[4,5,2]  R1924     1.5305852284654975e-03
    z[4,5,2]  R1925     -4.8518818616867065e-01
    z[4,5,2]  R1926     8.3909317851066589e-02
    z[4,5,2]  R1927     1.3591116666793823e-01
    z[4,5,2]  R1928     -3.6270821094512939e-01
    z[4,5,2]  R1929     -2.5830566883087158e-01
    z[4,5,2]  R1930     3.8193327188491821e-01
    z[4,5,2]  R1931     -1.3486935198307037e-01
    z[4,5,2]  R1932     3.7739354372024536e-01
    z[4,5,2]  R1933     -7.0517137646675110e-02
    z[4,5,2]  R1934     -1.8015700578689575e-01
    z[4,5,2]  R1935     -4.6858462691307068e-01
    z[4,5,2]  R1936     1.6033723950386047e-01
    z[4,5,2]  R1937     3.6763134598731995e-01
    z[4,5,2]  R1938     2.9411950707435608e-01
    z[4,5,2]  R1939     -2.0330508053302765e-01
    z[4,5,2]  R1940     0.450483113527298
    z[4,5,2]  R1941     6.3353300094604492e-01
    z[4,5,2]  R1942     4.7934162616729736e-01
    z[4,5,2]  R1943     4.2288044095039368e-01
    z[4,5,2]  R1944     7.7174264192581177e-01
    z[4,5,2]  R1945     0.0368468351662159
    z[4,5,2]  R1946     7.5390481948852539e-01
    z[4,5,2]  R1947     3.0433061718940735e-01
    z[4,5,2]  R1948     5.9244847297668457e-01
    z[4,5,2]  R1949     4.0476010181009769e-03
    z[4,5,2]  R1950     -9.3448825180530548e-02
    z[4,5,2]  R1951     2.7863787487149239e-02
    z[4,5,2]  R1952     1.8628510832786560e-01
    z[4,5,2]  R1953     3.7412515282630920e-01
    z[4,5,2]  R1954     7.2498425841331482e-02
    z[4,5,2]  R1955     -2.7489945292472839e-01
    z[4,5,2]  R1956     7.8560537099838257e-01
    z[4,5,2]  R1957     4.5996546745300293e-01
    z[4,5,2]  R1958     5.5690473318099976e-01
    z[4,5,2]  R1959     -6.1309903860092163e-01
    z[4,5,2]  R1960     2.0956581830978394e-01
    z[4,5,2]  R1961     1.0263431817293167e-01
    z[4,5,2]  R1962     1.1223587393760681e-01
    z[4,5,2]  R1963     3.2272240519523621e-01
    z[4,5,2]  R1964     7.7449077367782593e-01
    z[4,5,2]  R1965     -3.1922541558742523e-02
    z[4,5,2]  R1966     3.7960460782051086e-01
    z[4,5,2]  R1967     0.566888689994812
    z[4,5,2]  R1968     1.9992722570896149e-01
    z[4,5,2]  R1969     2.5040122866630554e-01
    z[4,5,2]  R1970     -1.5434475243091583e-01
    z[4,5,2]  R1971     5.5092971771955490e-02
    z[4,5,2]  R1972     6.4093485474586487e-02
    z[4,5,2]  R1973     3.9169132709503174e-01
    z[4,5,2]  R1974     4.8306062817573547e-01
    z[4,5,2]  R1975     1.1360051482915878e-01
    z[4,5,2]  R1976     3.5109764337539673e-01
    z[4,5,2]  R1977     -1.8109707534313202e-01
    z[4,5,2]  R1978     7.0444536395370960e-03
    z[4,5,2]  R1979     -1.0378784686326981e-01
    z[4,5,2]  R1980     -3.2495737075805664e-01
    z[4,5,2]  R1981     -1.4832274615764618e-01
    z[4,5,2]  R1982     -1.1233911663293839e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1903     -1
    z[4,5,3]  R1904     1
    z[4,5,3]  R1911     -8.1339550018310547e-01
    z[4,5,3]  R1912     -4.8179841041564941e-01
    z[4,5,3]  R1913     1.5598054230213165e-01
    z[4,5,3]  R1914     -1.5040325000882149e-02
    z[4,5,3]  R1915     1.8572627007961273e-01
    z[4,5,3]  R1916     7.1286216378211975e-02
    z[4,5,3]  R1917     3.1809020042419434e-01
    z[4,5,3]  R1918     5.2645099163055420e-01
    z[4,5,3]  R1919     -1.3016305863857269e-01
    z[4,5,3]  R1920     -1.0045634955167770e-01
    z[4,5,3]  R1921     3.8470726460218430e-02
    z[4,5,3]  R1922     -3.2603898644447327e-01
    z[4,5,3]  R1923     -3.5169713199138641e-02
    z[4,5,3]  R1924     0.541219174861908
    z[4,5,3]  R1925     1.1270406842231750e-01
    z[4,5,3]  R1926     5.0854027271270752e-01
    z[4,5,3]  R1927     5.4692953824996948e-01
    z[4,5,3]  R1928     2.6314312219619751e-01
    z[4,5,3]  R1929     2.2490815818309784e-01
    z[4,5,3]  R1930     4.4447129964828491e-01
    z[4,5,3]  R1931     -3.0794769525527954e-01
    z[4,5,3]  R1932     1.0301160067319870e-01
    z[4,5,3]  R1933     4.4565784931182861e-01
    z[4,5,3]  R1934     8.9852446317672729e-01
    z[4,5,3]  R1935     0.0741507038474083
    z[4,5,3]  R1936     -3.5644143819808960e-02
    z[4,5,3]  R1937     -1.9135881960391998e-01
    z[4,5,3]  R1938     5.6048100814223289e-03
    z[4,5,3]  R1939     -6.7439842224121094e-01
    z[4,5,3]  R1940     3.2411301136016846e-01
    z[4,5,3]  R1941     -4.6218031644821167e-01
    z[4,5,3]  R1942     1.8789154291152954e-01
    z[4,5,3]  R1943     2.1419529616832733e-01
    z[4,5,3]  R1944     4.3450275063514709e-01
    z[4,5,3]  R1945     -3.3244210481643677e-01
    z[4,5,3]  R1946     1.4798830263316631e-02
    z[4,5,3]  R1947     -5.7175344228744507e-01
    z[4,5,3]  R1948     -5.0337541103363037e-01
    z[4,5,3]  R1949     -4.3989843130111694e-01
    z[4,5,3]  R1950     5.6945568323135376e-01
    z[4,5,3]  R1951     3.1394094228744507e-01
    z[4,5,3]  R1952     5.4297178983688354e-01
    z[4,5,3]  R1953     7.8871408477425575e-03
    z[4,5,3]  R1954     -5.3595298528671265e-01
    z[4,5,3]  R1955     -7.5749266147613525e-01
    z[4,5,3]  R1956     -5.6745105981826782e-01
    z[4,5,3]  R1957     -3.8951399922370911e-01
    z[4,5,3]  R1958     -4.8240518569946289e-01
    z[4,5,3]  R1959     -5.1529681682586670e-01
    z[4,5,3]  R1960     -5.2376532554626465e-01
    z[4,5,3]  R1961     -6.9816923141479492e-01
    z[4,5,3]  R1962     4.0796205401420593e-01
    z[4,5,3]  R1963     -2.9315567016601562e-01
    z[4,5,3]  R1964     -5.8616679906845093e-01
    z[4,5,3]  R1965     -5.9187036752700806e-01
    z[4,5,3]  R1966     -2.2168566286563873e-01
    z[4,5,3]  R1967     -1.7261917889118195e-01
    z[4,5,3]  R1968     3.3974161744117737e-01
    z[4,5,3]  R1969     1.9725590944290161e-01
    z[4,5,3]  R1970     4.6568682789802551e-01
    z[4,5,3]  R1971     5.7034349441528320e-01
    z[4,5,3]  R1972     4.6530708670616150e-01
    z[4,5,3]  R1973     5.3525015711784363e-02
    z[4,5,3]  R1974     -5.4226624965667725e-01
    z[4,5,3]  R1975     -8.3188682794570923e-01
    z[4,5,3]  R1976     4.4643855094909668e-01
    z[4,5,3]  R1977     3.2516720890998840e-01
    z[4,5,3]  R1978     8.6171567440032959e-01
    z[4,5,3]  R1979     9.1848051548004150e-01
    z[4,5,3]  R1980     2.0819117128849030e-01
    z[4,5,3]  R1981     5.4480707645416260e-01
    z[4,5,3]  R1982     0.648116409778595
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1905     -1
    z[4,5,4]  R1906     1
    z[4,5,4]  R1911     6.3242472708225250e-02
    z[4,5,4]  R1912     2.1984401345252991e-01
    z[4,5,4]  R1913     -2.3649795353412628e-01
    z[4,5,4]  R1914     2.2370700538158417e-01
    z[4,5,4]  R1915     -3.5109555721282959e-01
    z[4,5,4]  R1916     -0.0685136467218399
    z[4,5,4]  R1917     2.7055370807647705e-01
    z[4,5,4]  R1918     -3.9472747594118118e-02
    z[4,5,4]  R1919     1.1186251044273376e-01
    z[4,5,4]  R1920     7.6634413003921509e-01
    z[4,5,4]  R1921     -5.8889114856719971e-01
    z[4,5,4]  R1922     4.3271717429161072e-01
    z[4,5,4]  R1923     6.4112299680709839e-01
    z[4,5,4]  R1924     3.5008779168128967e-01
    z[4,5,4]  R1925     -3.7443917989730835e-01
    z[4,5,4]  R1926     -8.1466743722558022e-03
    z[4,5,4]  R1927     -1.6769704222679138e-01
    z[4,5,4]  R1928     -0.322881281375885
    z[4,5,4]  R1929     -6.3616609573364258e-01
    z[4,5,4]  R1930     2.9244709014892578e-01
    z[4,5,4]  R1931     3.8723675534129143e-03
    z[4,5,4]  R1932     -4.5999753475189209e-01
    z[4,5,4]  R1933     3.3557209372520447e-01
    z[4,5,4]  R1934     3.5253819078207016e-02
    z[4,5,4]  R1935     -5.0201267004013062e-02
    z[4,5,4]  R1936     2.0140080153942108e-01
    z[4,5,4]  R1937     -1.2708598375320435e-01
    z[4,5,4]  R1938     7.1005290746688843e-01
    z[4,5,4]  R1939     -1.5742965042591095e-01
    z[4,5,4]  R1940     -1.4207400381565094e-01
    z[4,5,4]  R1941     9.2905789613723755e-02
    z[4,5,4]  R1942     -1.1216209828853607e-01
    z[4,5,4]  R1943     6.4459383487701416e-02
    z[4,5,4]  R1944     0.129435732960701
    z[4,5,4]  R1945     -4.1458931565284729e-01
    z[4,5,4]  R1946     -1.4615179598331451e-01
    z[4,5,4]  R1947     -1.0555419325828552e-01
    z[4,5,4]  R1948     1.5200559794902802e-01
    z[4,5,4]  R1949     5.8861184120178223e-01
    z[4,5,4]  R1950     3.7204778194427490e-01
    z[4,5,4]  R1951     -2.9196339845657349e-01
    z[4,5,4]  R1952     2.4302378296852112e-02
    z[4,5,4]  R1953     4.9243906140327454e-01
    z[4,5,4]  R1954     5.1775109767913818e-01
    z[4,5,4]  R1955     3.5475182533264160e-01
    z[4,5,4]  R1956     -6.6218726336956024e-02
    z[4,5,4]  R1957     -4.8138126730918884e-01
    z[4,5,4]  R1958     6.9008268415927887e-02
    z[4,5,4]  R1959     -2.0882911980152130e-02
    z[4,5,4]  R1960     -3.0655593145638704e-03
    z[4,5,4]  R1961     9.0737171471118927e-02
    z[4,5,4]  R1962     2.3281882703304291e-01
    z[4,5,4]  R1963     -3.2913425564765930e-01
    z[4,5,4]  R1964     -1.9677041098475456e-02
    z[4,5,4]  R1965     3.1881293654441833e-01
    z[4,5,4]  R1966     -1.6965357959270477e-01
    z[4,5,4]  R1967     -1.7790514230728149e-01
    z[4,5,4]  R1968     -1.6859249770641327e-01
    z[4,5,4]  R1969     4.3431546539068222e-02
    z[4,5,4]  R1970     -1.0452105849981308e-01
    z[4,5,4]  R1971     -2.2325780242681503e-02
    z[4,5,4]  R1972     -3.5965809226036072e-01
    z[4,5,4]  R1973     0.268614798784256
    z[4,5,4]  R1974     -3.6467319726943970e-01
    z[4,5,4]  R1975     -3.9487909525632858e-02
    z[4,5,4]  R1976     8.6490392684936523e-02
    z[4,5,4]  R1977     3.3647322654724121e-01
    z[4,5,4]  R1978     1.6580912470817566e-01
    z[4,5,4]  R1979     -1.1505384743213654e-01
    z[4,5,4]  R1980     -5.4393541812896729e-01
    z[4,5,4]  R1981     0.0495305210351944
    z[4,5,4]  R1982     -1.7865665256977081e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1907     -1
    z[4,5,5]  R1908     1
    z[4,5,5]  R1911     -3.0946649610996246e-02
    z[4,5,5]  R1912     0.0421551950275898
    z[4,5,5]  R1913     1.2816968560218811e-01
    z[4,5,5]  R1914     -2.3789976537227631e-01
    z[4,5,5]  R1915     2.2226135432720184e-01
    z[4,5,5]  R1916     3.9653125405311584e-01
    z[4,5,5]  R1917     6.0311287641525269e-01
    z[4,5,5]  R1918     1.2090355157852173e-01
    z[4,5,5]  R1919     8.4526848793029785e-01
    z[4,5,5]  R1920     2.6858550310134888e-01
    z[4,5,5]  R1921     4.5679005980491638e-01
    z[4,5,5]  R1922     -2.0484769344329834e-01
    z[4,5,5]  R1923     2.6183694601058960e-01
    z[4,5,5]  R1924     -1.2768730521202087e-01
    z[4,5,5]  R1925     -4.4617816805839539e-01
    z[4,5,5]  R1926     -7.9233056306838989e-01
    z[4,5,5]  R1927     -4.1353252530097961e-01
    z[4,5,5]  R1928     -2.7373023331165314e-02
    z[4,5,5]  R1929     1.9302488863468170e-01
    z[4,5,5]  R1930     2.4049438536167145e-02
    z[4,5,5]  R1931     0.817222535610199
    z[4,5,5]  R1932     -6.8864285945892334e-01
    z[4,5,5]  R1933     7.9849857091903687e-01
    z[4,5,5]  R1934     -3.0883839726448059e-01
    z[4,5,5]  R1935     -7.6874576508998871e-02
    z[4,5,5]  R1936     3.5730041563510895e-03
    z[4,5,5]  R1937     -1.6611084342002869e-01
    z[4,5,5]  R1938     -2.1292728185653687e-01
    z[4,5,5]  R1939     6.0546815395355225e-01
    z[4,5,5]  R1940     -3.1042459607124329e-01
    z[4,5,5]  R1941     1.9761377573013306e-01
    z[4,5,5]  R1942     5.4740697145462036e-01
    z[4,5,5]  R1943     -6.2707710266113281e-01
    z[4,5,5]  R1944     -5.8926129713654518e-03
    z[4,5,5]  R1945     -4.0352556109428406e-01
    z[4,5,5]  R1946     3.0668142437934875e-01
    z[4,5,5]  R1947     3.7205097079277039e-01
    z[4,5,5]  R1948     8.2550808787345886e-02
    z[4,5,5]  R1949     0.428880512714386
    z[4,5,5]  R1950     -2.5570359081029892e-02
    z[4,5,5]  R1951     -7.0960409939289093e-02
    z[4,5,5]  R1952     4.1393381357192993e-01
    z[4,5,5]  R1953     1.8796385824680328e-01
    z[4,5,5]  R1954     3.5510486364364624e-01
    z[4,5,5]  R1955     -3.2259428501129150e-01
    z[4,5,5]  R1956     -1.4974993467330933e-01
    z[4,5,5]  R1957     2.4394790828227997e-01
    z[4,5,5]  R1958     -6.0236491262912750e-02
    z[4,5,5]  R1959     0.537821888923645
    z[4,5,5]  R1960     4.4306963682174683e-01
    z[4,5,5]  R1961     2.6599545031785965e-02
    z[4,5,5]  R1962     -5.4927755147218704e-02
    z[4,5,5]  R1963     -7.6165050268173218e-01
    z[4,5,5]  R1964     -4.7618150711059570e-02
    z[4,5,5]  R1965     -2.2291608154773712e-01
    z[4,5,5]  R1966     5.9336161613464355e-01
    z[4,5,5]  R1967     3.7358757853507996e-01
    z[4,5,5]  R1968     2.0678481459617615e-01
    z[4,5,5]  R1969     1.5632654726505280e-01
    z[4,5,5]  R1970     1.7294344305992126e-01
    z[4,5,5]  R1971     -1.2472229450941086e-01
    z[4,5,5]  R1972     -1.3050112128257751e-01
    z[4,5,5]  R1973     1.4924408495426178e-01
    z[4,5,5]  R1974     -6.4426816999912262e-02
    z[4,5,5]  R1975     -7.1667745709419250e-02
    z[4,5,5]  R1976     -9.7219776362180710e-03
    z[4,5,5]  R1977     3.5702455043792725e-01
    z[4,5,5]  R1978     3.7620570510625839e-02
    z[4,5,5]  R1979     -1.9718091934919357e-02
    z[4,5,5]  R1980     5.7228130102157593e-01
    z[4,5,5]  R1981     8.1076073646545410e-01
    z[4,5,5]  R1982     2.4047380685806274e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1909     -1
    z[4,5,6]  R1910     1
    z[4,5,6]  R1911     1.5041979029774666e-02
    z[4,5,6]  R1912     -2.8784090280532837e-01
    z[4,5,6]  R1913     2.9248049482703209e-02
    z[4,5,6]  R1914     -2.2535309195518494e-01
    z[4,5,6]  R1915     -2.1008443832397461e-01
    z[4,5,6]  R1916     3.8518467545509338e-01
    z[4,5,6]  R1917     -2.7857992798089981e-02
    z[4,5,6]  R1918     -4.7027524560689926e-02
    z[4,5,6]  R1919     -1.0463027656078339e-01
    z[4,5,6]  R1920     -2.2879397869110107e-01
    z[4,5,6]  R1921     7.1988575160503387e-02
    z[4,5,6]  R1922     -2.5938370823860168e-01
    z[4,5,6]  R1923     -4.3014207482337952e-01
    z[4,5,6]  R1924     2.9551157355308533e-01
    z[4,5,6]  R1925     4.9728262424468994e-01
    z[4,5,6]  R1926     1.9631277024745941e-01
    z[4,5,6]  R1927     -6.5884912014007568e-01
    z[4,5,6]  R1928     4.8078387975692749e-01
    z[4,5,6]  R1929     4.7503682971000671e-01
    z[4,5,6]  R1930     -4.5341871678829193e-02
    z[4,5,6]  R1931     -1.5369729697704315e-01
    z[4,5,6]  R1932     0.0291310902684927
    z[4,5,6]  R1933     -6.2104641983751208e-05
    z[4,5,6]  R1934     8.7785460054874420e-02
    z[4,5,6]  R1935     -2.6419568806886673e-02
    z[4,5,6]  R1936     -1.1189787089824677e-01
    z[4,5,6]  R1937     -3.8691911101341248e-01
    z[4,5,6]  R1938     -3.4885451197624207e-01
    z[4,5,6]  R1939     -4.1847601532936096e-02
    z[4,5,6]  R1940     3.6751903593540192e-02
    z[4,5,6]  R1941     -2.8370583057403564e-01
    z[4,5,6]  R1942     1.6733314841985703e-02
    z[4,5,6]  R1943     4.1551443934440613e-01
    z[4,5,6]  R1944     -2.5166139006614685e-01
    z[4,5,6]  R1945     0.286883145570755
    z[4,5,6]  R1946     5.2915501594543457e-01
    z[4,5,6]  R1947     -4.5369610190391541e-01
    z[4,5,6]  R1948     7.5325523503124714e-03
    z[4,5,6]  R1949     2.7955085039138794e-01
    z[4,5,6]  R1950     3.1469553709030151e-02
    z[4,5,6]  R1951     2.3263911902904510e-01
    z[4,5,6]  R1952     1.7375846207141876e-01
    z[4,5,6]  R1953     0.565101146697998
    z[4,5,6]  R1954     1.8824603408575058e-02
    z[4,5,6]  R1955     -1.2835679948329926e-01
    z[4,5,6]  R1956     8.6512207984924316e-02
    z[4,5,6]  R1957     1.7417861521244049e-01
    z[4,5,6]  R1958     1.5006642043590546e-01
    z[4,5,6]  R1959     9.6953660249710083e-02
    z[4,5,6]  R1960     4.6991053223609924e-01
    z[4,5,6]  R1961     5.6042182445526123e-01
    z[4,5,6]  R1962     -7.3065526783466339e-02
    z[4,5,6]  R1963     1.2765587866306305e-01
    z[4,5,6]  R1964     8.8968977332115173e-02
    z[4,5,6]  R1965     5.8499538898468018e-01
    z[4,5,6]  R1966     -2.1917113661766052e-01
    z[4,5,6]  R1967     1.6938470304012299e-01
    z[4,5,6]  R1968     1.2223885208368301e-01
    z[4,5,6]  R1969     -1.5865561366081238e-01
    z[4,5,6]  R1970     2.6672789454460144e-01
    z[4,5,6]  R1971     3.4181100130081177e-01
    z[4,5,6]  R1972     -3.4904679656028748e-01
    z[4,5,6]  R1973     5.7206612825393677e-01
    z[4,5,6]  R1974     4.2464268207550049e-01
    z[4,5,6]  R1975     2.2852925956249237e-01
    z[4,5,6]  R1976     0.223191499710083
    z[4,5,6]  R1977     5.3487755358219147e-02
    z[4,5,6]  R1978     2.2425462305545807e-01
    z[4,5,6]  R1979     2.4868229404091835e-02
    z[4,5,6]  R1980     3.1829643249511719e-01
    z[4,5,6]  R1981     -1.2762982398271561e-02
    z[4,5,6]  R1982     -4.1096824407577515e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1983     -1
    z[5,4,0]  R1984     1
    z[5,4,0]  R1997     -7.2277379035949707e-01
    z[5,4,0]  R1998     0.805334210395813
    z[5,4,0]  R1999     7.3077583312988281e-01
    z[5,4,0]  R2000     1.1370386183261871e-01
    z[5,4,0]  R2001     -7.7118612825870514e-02
    z[5,4,0]  R2002     1.3980850577354431e-01
    z[5,4,0]  R2003     -3.9450824260711670e-01
    z[5,4,0]  R2004     -5.3267621994018555e-01
    z[5,4,0]  R2005     1.5024597942829132e-01
    z[5,4,0]  R2006     1.7440715432167053e-01
    z[5,4,0]  R2007     6.5103721618652344e-01
    z[5,4,0]  R2008     1.6288323327898979e-02
    z[5,4,0]  R2009     -3.3365017175674438e-01
    z[5,4,0]  R2010     -5.9681493043899536e-01
    z[5,4,0]  R2011     -4.3888008594512939e-01
    z[5,4,0]  R2012     3.3577498793601990e-01
    z[5,4,0]  R2013     4.0972787141799927e-01
    z[5,4,0]  R2014     1.8252097070217133e-01
    z[5,4,0]  R2015     9.0965494513511658e-02
    z[5,4,0]  R2016     -5.5656415224075317e-01
    z[5,4,0]  R2017     -3.1916010379791260e-01
    z[5,4,0]  R2018     -8.7184444069862366e-02
    z[5,4,0]  R2019     -4.1862553358078003e-01
    z[5,4,0]  R2020     -6.4222311973571777e-01
    z[5,4,0]  R2021     6.0630504041910172e-02
    z[5,4,0]  R2022     -4.8078897595405579e-01
    z[5,4,0]  R2023     -4.2030301690101624e-01
    z[5,4,0]  R2024     0.355146199464798
    z[5,4,0]  R2025     2.7121397852897644e-01
    z[5,4,0]  R2026     4.7907616943120956e-02
    z[5,4,0]  R2027     1.3716715574264526e-01
    z[5,4,0]  R2028     -4.7560158371925354e-01
    z[5,4,0]  R2029     -6.0663259029388428e-01
    z[5,4,0]  R2030     2.3190313577651978e-01
    z[5,4,0]  R2031     2.1783809363842010e-01
    z[5,4,0]  R2032     3.5618704557418823e-01
    z[5,4,0]  R2033     3.3672192692756653e-01
    z[5,4,0]  R2034     2.8452232480049133e-01
    z[5,4,0]  R2035     3.6942040920257568e-01
    z[5,4,0]  R2036     3.5282671451568604e-01
    z[5,4,0]  R2037     -4.4571959972381592e-01
    z[5,4,0]  R2038     1.0341478139162064e-01
    z[5,4,0]  R2039     3.4538006782531738e-01
    z[5,4,0]  R2040     2.1061430871486664e-01
    z[5,4,0]  R2041     1.9354499876499176e-01
    z[5,4,0]  R2042     1.7186896502971649e-01
    z[5,4,0]  R2043     -3.8703698664903641e-02
    z[5,4,0]  R2044     2.5730609893798828e-01
    z[5,4,0]  R2045     3.1280374526977539e-01
    z[5,4,0]  R2046     -3.6479675769805908e-01
    z[5,4,0]  R2047     -7.0757251977920532e-01
    z[5,4,0]  R2048     -7.7134460210800171e-01
    z[5,4,0]  R2049     -7.6169526576995850e-01
    z[5,4,0]  R2050     0.670039713382721
    z[5,4,0]  R2051     -6.3153463602066040e-01
    z[5,4,0]  R2052     -2.7676162123680115e-01
    z[5,4,0]  R2053     1.0108610242605209e-01
    z[5,4,0]  R2054     0.219046488404274
    z[5,4,0]  R2055     2.5553833693265915e-03
    z[5,4,0]  R2056     1.3077133893966675e-01
    z[5,4,0]  R2057     -3.1307630240917206e-02
    z[5,4,0]  R2058     3.9913639426231384e-01
    z[5,4,0]  R2059     2.7574592828750610e-01
    z[5,4,0]  R2060     0.0935889184474945
    z[5,4,0]  R2061     -4.4590409845113754e-02
    z[5,4,0]  R2062     2.5477501749992371e-01
    z[5,4,0]  R2063     1.4936186373233795e-01
    z[5,4,0]  R2064     2.3234197497367859e-01
    z[5,4,0]  R2065     4.9659404903650284e-02
    z[5,4,0]  R2066     -0.358368843793869
    z[5,4,0]  R2067     2.0152449607849121e-01
    z[5,4,0]  R2068     -2.3189561069011688e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1985     -1
    z[5,4,1]  R1986     1
    z[5,4,1]  R1997     4.9335613846778870e-01
    z[5,4,1]  R1998     -5.2092432975769043e-01
    z[5,4,1]  R1999     -3.1740444898605347e-01
    z[5,4,1]  R2000     -4.7887480258941650e-01
    z[5,4,1]  R2001     3.2369661331176758e-01
    z[5,4,1]  R2002     7.4469465017318726e-01
    z[5,4,1]  R2003     3.1814590096473694e-01
    z[5,4,1]  R2004     -3.7238383293151855e-01
    z[5,4,1]  R2005     -4.2741736769676208e-01
    z[5,4,1]  R2006     -3.2416197657585144e-01
    z[5,4,1]  R2007     -2.1738414466381073e-01
    z[5,4,1]  R2008     -1.8900883197784424e-01
    z[5,4,1]  R2009     3.3727544546127319e-01
    z[5,4,1]  R2010     9.7226023674011230e-02
    z[5,4,1]  R2011     -7.2843387722969055e-02
    z[5,4,1]  R2012     6.4356744289398193e-01
    z[5,4,1]  R2013     7.6706510782241821e-01
    z[5,4,1]  R2014     6.5957701206207275e-01
    z[5,4,1]  R2015     -5.0450706481933594e-01
    z[5,4,1]  R2016     5.6698240339756012e-02
    z[5,4,1]  R2017     4.8791885375976562e-02
    z[5,4,1]  R2018     -1.3757948577404022e-01
    z[5,4,1]  R2019     3.7401422858238220e-01
    z[5,4,1]  R2020     1.1739350110292435e-01
    z[5,4,1]  R2021     2.3625028133392334e-01
    z[5,4,1]  R2022     1.8291552364826202e-01
    z[5,4,1]  R2023     4.8557594418525696e-02
    z[5,4,1]  R2024     7.9516094923019409e-01
    z[5,4,1]  R2025     -1.7780935764312744e-01
    z[5,4,1]  R2026     -2.0906296372413635e-01
    z[5,4,1]  R2027     -3.6919206380844116e-01
    z[5,4,1]  R2028     3.8943886756896973e-01
    z[5,4,1]  R2029     2.8447780013084412e-01
    z[5,4,1]  R2030     8.3946412801742554e-01
    z[5,4,1]  R2031     0.894114077091217
    z[5,4,1]  R2032     7.2143363952636719e-01
    z[5,4,1]  R2033     6.5222895145416260e-01
    z[5,4,1]  R2034     6.5590417385101318e-01
    z[5,4,1]  R2035     -5.3437268733978271e-01
    z[5,4,1]  R2036     -1.7508365213871002e-01
    z[5,4,1]  R2037     1.9357708096504211e-01
    z[5,4,1]  R2038     7.8060162067413330e-01
    z[5,4,1]  R2039     0.706145167350769
    z[5,4,1]  R2040     3.6584153771400452e-01
    z[5,4,1]  R2041     3.0645939707756042e-01
    z[5,4,1]  R2042     3.1118473410606384e-01
    z[5,4,1]  R2043     1.4049403369426727e-01
    z[5,4,1]  R2044     4.9242043495178223e-01
    z[5,4,1]  R2045     -4.2932558059692383e-01
    z[5,4,1]  R2046     -6.7576491832733154e-01
    z[5,4,1]  R2047     2.0904146134853363e-01
    z[5,4,1]  R2048     4.9067354202270508e-01
    z[5,4,1]  R2049     4.0315636992454529e-01
    z[5,4,1]  R2050     4.1437533497810364e-01
    z[5,4,1]  R2051     1.3012956082820892e-01
    z[5,4,1]  R2052     0.589113175868988
    z[5,4,1]  R2053     3.9583536982536316e-01
    z[5,4,1]  R2054     3.5854130983352661e-01
    z[5,4,1]  R2055     3.7020951509475708e-01
    z[5,4,1]  R2056     7.5881212949752808e-01
    z[5,4,1]  R2057     3.9203503727912903e-01
    z[5,4,1]  R2058     -5.6707769632339478e-01
    z[5,4,1]  R2059     -2.9880559444427490e-01
    z[5,4,1]  R2060     2.4329890310764313e-01
    z[5,4,1]  R2061     -2.1724271774291992e-01
    z[5,4,1]  R2062     -6.3097810745239258e-01
    z[5,4,1]  R2063     -4.3904387950897217e-01
    z[5,4,1]  R2064     7.1723777055740356e-01
    z[5,4,1]  R2065     4.3934261798858643e-01
    z[5,4,1]  R2066     -1.7849127948284149e-01
    z[5,4,1]  R2067     7.4805237352848053e-02
    z[5,4,1]  R2068     0.0457318089902401
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1987     -1
    z[5,4,2]  R1988     1
    z[5,4,2]  R1997     -4.6858462691307068e-01
    z[5,4,2]  R1998     1.6033723950386047e-01
    z[5,4,2]  R1999     3.6763134598731995e-01
    z[5,4,2]  R2000     2.9411950707435608e-01
    z[5,4,2]  R2001     -2.0330508053302765e-01
    z[5,4,2]  R2002     0.450483113527298
    z[5,4,2]  R2003     6.3353300094604492e-01
    z[5,4,2]  R2004     4.7934162616729736e-01
    z[5,4,2]  R2005     4.2288044095039368e-01
    z[5,4,2]  R2006     7.7174264192581177e-01
    z[5,4,2]  R2007     0.0368468351662159
    z[5,4,2]  R2008     7.5390481948852539e-01
    z[5,4,2]  R2009     3.0433061718940735e-01
    z[5,4,2]  R2010     5.9244847297668457e-01
    z[5,4,2]  R2011     4.0476010181009769e-03
    z[5,4,2]  R2012     -9.3448825180530548e-02
    z[5,4,2]  R2013     2.7863787487149239e-02
    z[5,4,2]  R2014     1.8628510832786560e-01
    z[5,4,2]  R2015     3.7412515282630920e-01
    z[5,4,2]  R2016     7.2498425841331482e-02
    z[5,4,2]  R2017     -2.7489945292472839e-01
    z[5,4,2]  R2018     7.8560537099838257e-01
    z[5,4,2]  R2019     4.5996546745300293e-01
    z[5,4,2]  R2020     5.5690473318099976e-01
    z[5,4,2]  R2021     -6.1309903860092163e-01
    z[5,4,2]  R2022     2.0956581830978394e-01
    z[5,4,2]  R2023     1.0263431817293167e-01
    z[5,4,2]  R2024     1.1223587393760681e-01
    z[5,4,2]  R2025     3.2272240519523621e-01
    z[5,4,2]  R2026     7.7449077367782593e-01
    z[5,4,2]  R2027     -3.1922541558742523e-02
    z[5,4,2]  R2028     3.7960460782051086e-01
    z[5,4,2]  R2029     0.566888689994812
    z[5,4,2]  R2030     1.9992722570896149e-01
    z[5,4,2]  R2031     2.5040122866630554e-01
    z[5,4,2]  R2032     -1.5434475243091583e-01
    z[5,4,2]  R2033     5.5092971771955490e-02
    z[5,4,2]  R2034     6.4093485474586487e-02
    z[5,4,2]  R2035     3.9169132709503174e-01
    z[5,4,2]  R2036     4.8306062817573547e-01
    z[5,4,2]  R2037     1.1360051482915878e-01
    z[5,4,2]  R2038     3.5109764337539673e-01
    z[5,4,2]  R2039     -1.8109707534313202e-01
    z[5,4,2]  R2040     7.0444536395370960e-03
    z[5,4,2]  R2041     -1.0378784686326981e-01
    z[5,4,2]  R2042     -3.2495737075805664e-01
    z[5,4,2]  R2043     -1.4832274615764618e-01
    z[5,4,2]  R2044     -1.1233911663293839e-01
    z[5,4,2]  R2045     2.2591508924961090e-01
    z[5,4,2]  R2046     -2.1254327893257141e-01
    z[5,4,2]  R2047     -5.9841352701187134e-01
    z[5,4,2]  R2048     8.1337429583072662e-02
    z[5,4,2]  R2049     7.7377937734127045e-02
    z[5,4,2]  R2050     -2.5290283560752869e-01
    z[5,4,2]  R2051     2.1290490031242371e-01
    z[5,4,2]  R2052     -5.2991569042205811e-01
    z[5,4,2]  R2053     -2.7966782450675964e-01
    z[5,4,2]  R2054     -3.1875881552696228e-01
    z[5,4,2]  R2055     5.4847621917724609e-01
    z[5,4,2]  R2056     6.5688274800777435e-02
    z[5,4,2]  R2057     4.2364135384559631e-01
    z[5,4,2]  R2058     1.5305852284654975e-03
    z[5,4,2]  R2059     -4.8518818616867065e-01
    z[5,4,2]  R2060     8.3909317851066589e-02
    z[5,4,2]  R2061     1.3591116666793823e-01
    z[5,4,2]  R2062     -3.6270821094512939e-01
    z[5,4,2]  R2063     -2.5830566883087158e-01
    z[5,4,2]  R2064     3.8193327188491821e-01
    z[5,4,2]  R2065     -1.3486935198307037e-01
    z[5,4,2]  R2066     3.7739354372024536e-01
    z[5,4,2]  R2067     -7.0517137646675110e-02
    z[5,4,2]  R2068     -1.8015700578689575e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1989     -1
    z[5,4,3]  R1990     1
    z[5,4,3]  R1997     0.0741507038474083
    z[5,4,3]  R1998     -3.5644143819808960e-02
    z[5,4,3]  R1999     -1.9135881960391998e-01
    z[5,4,3]  R2000     5.6048100814223289e-03
    z[5,4,3]  R2001     -6.7439842224121094e-01
    z[5,4,3]  R2002     3.2411301136016846e-01
    z[5,4,3]  R2003     -4.6218031644821167e-01
    z[5,4,3]  R2004     1.8789154291152954e-01
    z[5,4,3]  R2005     2.1419529616832733e-01
    z[5,4,3]  R2006     4.3450275063514709e-01
    z[5,4,3]  R2007     -3.3244210481643677e-01
    z[5,4,3]  R2008     1.4798830263316631e-02
    z[5,4,3]  R2009     -5.7175344228744507e-01
    z[5,4,3]  R2010     -5.0337541103363037e-01
    z[5,4,3]  R2011     -4.3989843130111694e-01
    z[5,4,3]  R2012     5.6945568323135376e-01
    z[5,4,3]  R2013     3.1394094228744507e-01
    z[5,4,3]  R2014     5.4297178983688354e-01
    z[5,4,3]  R2015     7.8871408477425575e-03
    z[5,4,3]  R2016     -5.3595298528671265e-01
    z[5,4,3]  R2017     -7.5749266147613525e-01
    z[5,4,3]  R2018     -5.6745105981826782e-01
    z[5,4,3]  R2019     -3.8951399922370911e-01
    z[5,4,3]  R2020     -4.8240518569946289e-01
    z[5,4,3]  R2021     -5.1529681682586670e-01
    z[5,4,3]  R2022     -5.2376532554626465e-01
    z[5,4,3]  R2023     -6.9816923141479492e-01
    z[5,4,3]  R2024     4.0796205401420593e-01
    z[5,4,3]  R2025     -2.9315567016601562e-01
    z[5,4,3]  R2026     -5.8616679906845093e-01
    z[5,4,3]  R2027     -5.9187036752700806e-01
    z[5,4,3]  R2028     -2.2168566286563873e-01
    z[5,4,3]  R2029     -1.7261917889118195e-01
    z[5,4,3]  R2030     3.3974161744117737e-01
    z[5,4,3]  R2031     1.9725590944290161e-01
    z[5,4,3]  R2032     4.6568682789802551e-01
    z[5,4,3]  R2033     5.7034349441528320e-01
    z[5,4,3]  R2034     4.6530708670616150e-01
    z[5,4,3]  R2035     5.3525015711784363e-02
    z[5,4,3]  R2036     -5.4226624965667725e-01
    z[5,4,3]  R2037     -8.3188682794570923e-01
    z[5,4,3]  R2038     4.4643855094909668e-01
    z[5,4,3]  R2039     3.2516720890998840e-01
    z[5,4,3]  R2040     8.6171567440032959e-01
    z[5,4,3]  R2041     9.1848051548004150e-01
    z[5,4,3]  R2042     2.0819117128849030e-01
    z[5,4,3]  R2043     5.4480707645416260e-01
    z[5,4,3]  R2044     0.648116409778595
    z[5,4,3]  R2045     -8.1339550018310547e-01
    z[5,4,3]  R2046     -4.8179841041564941e-01
    z[5,4,3]  R2047     1.5598054230213165e-01
    z[5,4,3]  R2048     -1.5040325000882149e-02
    z[5,4,3]  R2049     1.8572627007961273e-01
    z[5,4,3]  R2050     7.1286216378211975e-02
    z[5,4,3]  R2051     3.1809020042419434e-01
    z[5,4,3]  R2052     5.2645099163055420e-01
    z[5,4,3]  R2053     -1.3016305863857269e-01
    z[5,4,3]  R2054     -1.0045634955167770e-01
    z[5,4,3]  R2055     3.8470726460218430e-02
    z[5,4,3]  R2056     -3.2603898644447327e-01
    z[5,4,3]  R2057     -3.5169713199138641e-02
    z[5,4,3]  R2058     0.541219174861908
    z[5,4,3]  R2059     1.1270406842231750e-01
    z[5,4,3]  R2060     5.0854027271270752e-01
    z[5,4,3]  R2061     5.4692953824996948e-01
    z[5,4,3]  R2062     2.6314312219619751e-01
    z[5,4,3]  R2063     2.2490815818309784e-01
    z[5,4,3]  R2064     4.4447129964828491e-01
    z[5,4,3]  R2065     -3.0794769525527954e-01
    z[5,4,3]  R2066     1.0301160067319870e-01
    z[5,4,3]  R2067     4.4565784931182861e-01
    z[5,4,3]  R2068     8.9852446317672729e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1991     -1
    z[5,4,4]  R1992     1
    z[5,4,4]  R1997     -5.0201267004013062e-02
    z[5,4,4]  R1998     2.0140080153942108e-01
    z[5,4,4]  R1999     -1.2708598375320435e-01
    z[5,4,4]  R2000     7.1005290746688843e-01
    z[5,4,4]  R2001     -1.5742965042591095e-01
    z[5,4,4]  R2002     -1.4207400381565094e-01
    z[5,4,4]  R2003     9.2905789613723755e-02
    z[5,4,4]  R2004     -1.1216209828853607e-01
    z[5,4,4]  R2005     6.4459383487701416e-02
    z[5,4,4]  R2006     0.129435732960701
    z[5,4,4]  R2007     -4.1458931565284729e-01
    z[5,4,4]  R2008     -1.4615179598331451e-01
    z[5,4,4]  R2009     -1.0555419325828552e-01
    z[5,4,4]  R2010     1.5200559794902802e-01
    z[5,4,4]  R2011     5.8861184120178223e-01
    z[5,4,4]  R2012     3.7204778194427490e-01
    z[5,4,4]  R2013     -2.9196339845657349e-01
    z[5,4,4]  R2014     2.4302378296852112e-02
    z[5,4,4]  R2015     4.9243906140327454e-01
    z[5,4,4]  R2016     5.1775109767913818e-01
    z[5,4,4]  R2017     3.5475182533264160e-01
    z[5,4,4]  R2018     -6.6218726336956024e-02
    z[5,4,4]  R2019     -4.8138126730918884e-01
    z[5,4,4]  R2020     6.9008268415927887e-02
    z[5,4,4]  R2021     -2.0882911980152130e-02
    z[5,4,4]  R2022     -3.0655593145638704e-03
    z[5,4,4]  R2023     9.0737171471118927e-02
    z[5,4,4]  R2024     2.3281882703304291e-01
    z[5,4,4]  R2025     -3.2913425564765930e-01
    z[5,4,4]  R2026     -1.9677041098475456e-02
    z[5,4,4]  R2027     3.1881293654441833e-01
    z[5,4,4]  R2028     -1.6965357959270477e-01
    z[5,4,4]  R2029     -1.7790514230728149e-01
    z[5,4,4]  R2030     -1.6859249770641327e-01
    z[5,4,4]  R2031     4.3431546539068222e-02
    z[5,4,4]  R2032     -1.0452105849981308e-01
    z[5,4,4]  R2033     -2.2325780242681503e-02
    z[5,4,4]  R2034     -3.5965809226036072e-01
    z[5,4,4]  R2035     0.268614798784256
    z[5,4,4]  R2036     -3.6467319726943970e-01
    z[5,4,4]  R2037     -3.9487909525632858e-02
    z[5,4,4]  R2038     8.6490392684936523e-02
    z[5,4,4]  R2039     3.3647322654724121e-01
    z[5,4,4]  R2040     1.6580912470817566e-01
    z[5,4,4]  R2041     -1.1505384743213654e-01
    z[5,4,4]  R2042     -5.4393541812896729e-01
    z[5,4,4]  R2043     0.0495305210351944
    z[5,4,4]  R2044     -1.7865665256977081e-01
    z[5,4,4]  R2045     6.3242472708225250e-02
    z[5,4,4]  R2046     2.1984401345252991e-01
    z[5,4,4]  R2047     -2.3649795353412628e-01
    z[5,4,4]  R2048     2.2370700538158417e-01
    z[5,4,4]  R2049     -3.5109555721282959e-01
    z[5,4,4]  R2050     -0.0685136467218399
    z[5,4,4]  R2051     2.7055370807647705e-01
    z[5,4,4]  R2052     -3.9472747594118118e-02
    z[5,4,4]  R2053     1.1186251044273376e-01
    z[5,4,4]  R2054     7.6634413003921509e-01
    z[5,4,4]  R2055     -5.8889114856719971e-01
    z[5,4,4]  R2056     4.3271717429161072e-01
    z[5,4,4]  R2057     6.4112299680709839e-01
    z[5,4,4]  R2058     3.5008779168128967e-01
    z[5,4,4]  R2059     -3.7443917989730835e-01
    z[5,4,4]  R2060     -8.1466743722558022e-03
    z[5,4,4]  R2061     -1.6769704222679138e-01
    z[5,4,4]  R2062     -0.322881281375885
    z[5,4,4]  R2063     -6.3616609573364258e-01
    z[5,4,4]  R2064     2.9244709014892578e-01
    z[5,4,4]  R2065     3.8723675534129143e-03
    z[5,4,4]  R2066     -4.5999753475189209e-01
    z[5,4,4]  R2067     3.3557209372520447e-01
    z[5,4,4]  R2068     3.5253819078207016e-02
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1993     -1
    z[5,4,5]  R1994     1
    z[5,4,5]  R1997     -7.6874576508998871e-02
    z[5,4,5]  R1998     3.5730041563510895e-03
    z[5,4,5]  R1999     -1.6611084342002869e-01
    z[5,4,5]  R2000     -2.1292728185653687e-01
    z[5,4,5]  R2001     6.0546815395355225e-01
    z[5,4,5]  R2002     -3.1042459607124329e-01
    z[5,4,5]  R2003     1.9761377573013306e-01
    z[5,4,5]  R2004     5.4740697145462036e-01
    z[5,4,5]  R2005     -6.2707710266113281e-01
    z[5,4,5]  R2006     -5.8926129713654518e-03
    z[5,4,5]  R2007     -4.0352556109428406e-01
    z[5,4,5]  R2008     3.0668142437934875e-01
    z[5,4,5]  R2009     3.7205097079277039e-01
    z[5,4,5]  R2010     8.2550808787345886e-02
    z[5,4,5]  R2011     0.428880512714386
    z[5,4,5]  R2012     -2.5570359081029892e-02
    z[5,4,5]  R2013     -7.0960409939289093e-02
    z[5,4,5]  R2014     4.1393381357192993e-01
    z[5,4,5]  R2015     1.8796385824680328e-01
    z[5,4,5]  R2016     3.5510486364364624e-01
    z[5,4,5]  R2017     -3.2259428501129150e-01
    z[5,4,5]  R2018     -1.4974993467330933e-01
    z[5,4,5]  R2019     2.4394790828227997e-01
    z[5,4,5]  R2020     -6.0236491262912750e-02
    z[5,4,5]  R2021     0.537821888923645
    z[5,4,5]  R2022     4.4306963682174683e-01
    z[5,4,5]  R2023     2.6599545031785965e-02
    z[5,4,5]  R2024     -5.4927755147218704e-02
    z[5,4,5]  R2025     -7.6165050268173218e-01
    z[5,4,5]  R2026     -4.7618150711059570e-02
    z[5,4,5]  R2027     -2.2291608154773712e-01
    z[5,4,5]  R2028     5.9336161613464355e-01
    z[5,4,5]  R2029     3.7358757853507996e-01
    z[5,4,5]  R2030     2.0678481459617615e-01
    z[5,4,5]  R2031     1.5632654726505280e-01
    z[5,4,5]  R2032     1.7294344305992126e-01
    z[5,4,5]  R2033     -1.2472229450941086e-01
    z[5,4,5]  R2034     -1.3050112128257751e-01
    z[5,4,5]  R2035     1.4924408495426178e-01
    z[5,4,5]  R2036     -6.4426816999912262e-02
    z[5,4,5]  R2037     -7.1667745709419250e-02
    z[5,4,5]  R2038     -9.7219776362180710e-03
    z[5,4,5]  R2039     3.5702455043792725e-01
    z[5,4,5]  R2040     3.7620570510625839e-02
    z[5,4,5]  R2041     -1.9718091934919357e-02
    z[5,4,5]  R2042     5.7228130102157593e-01
    z[5,4,5]  R2043     8.1076073646545410e-01
    z[5,4,5]  R2044     2.4047380685806274e-01
    z[5,4,5]  R2045     -3.0946649610996246e-02
    z[5,4,5]  R2046     0.0421551950275898
    z[5,4,5]  R2047     1.2816968560218811e-01
    z[5,4,5]  R2048     -2.3789976537227631e-01
    z[5,4,5]  R2049     2.2226135432720184e-01
    z[5,4,5]  R2050     3.9653125405311584e-01
    z[5,4,5]  R2051     6.0311287641525269e-01
    z[5,4,5]  R2052     1.2090355157852173e-01
    z[5,4,5]  R2053     8.4526848793029785e-01
    z[5,4,5]  R2054     2.6858550310134888e-01
    z[5,4,5]  R2055     4.5679005980491638e-01
    z[5,4,5]  R2056     -2.0484769344329834e-01
    z[5,4,5]  R2057     2.6183694601058960e-01
    z[5,4,5]  R2058     -1.2768730521202087e-01
    z[5,4,5]  R2059     -4.4617816805839539e-01
    z[5,4,5]  R2060     -7.9233056306838989e-01
    z[5,4,5]  R2061     -4.1353252530097961e-01
    z[5,4,5]  R2062     -2.7373023331165314e-02
    z[5,4,5]  R2063     1.9302488863468170e-01
    z[5,4,5]  R2064     2.4049438536167145e-02
    z[5,4,5]  R2065     0.817222535610199
    z[5,4,5]  R2066     -6.8864285945892334e-01
    z[5,4,5]  R2067     7.9849857091903687e-01
    z[5,4,5]  R2068     -3.0883839726448059e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1995     -1
    z[5,4,6]  R1996     1
    z[5,4,6]  R1997     -2.6419568806886673e-02
    z[5,4,6]  R1998     -1.1189787089824677e-01
    z[5,4,6]  R1999     -3.8691911101341248e-01
    z[5,4,6]  R2000     -3.4885451197624207e-01
    z[5,4,6]  R2001     -4.1847601532936096e-02
    z[5,4,6]  R2002     3.6751903593540192e-02
    z[5,4,6]  R2003     -2.8370583057403564e-01
    z[5,4,6]  R2004     1.6733314841985703e-02
    z[5,4,6]  R2005     4.1551443934440613e-01
    z[5,4,6]  R2006     -2.5166139006614685e-01
    z[5,4,6]  R2007     0.286883145570755
    z[5,4,6]  R2008     5.2915501594543457e-01
    z[5,4,6]  R2009     -4.5369610190391541e-01
    z[5,4,6]  R2010     7.5325523503124714e-03
    z[5,4,6]  R2011     2.7955085039138794e-01
    z[5,4,6]  R2012     3.1469553709030151e-02
    z[5,4,6]  R2013     2.3263911902904510e-01
    z[5,4,6]  R2014     1.7375846207141876e-01
    z[5,4,6]  R2015     0.565101146697998
    z[5,4,6]  R2016     1.8824603408575058e-02
    z[5,4,6]  R2017     -1.2835679948329926e-01
    z[5,4,6]  R2018     8.6512207984924316e-02
    z[5,4,6]  R2019     1.7417861521244049e-01
    z[5,4,6]  R2020     1.5006642043590546e-01
    z[5,4,6]  R2021     9.6953660249710083e-02
    z[5,4,6]  R2022     4.6991053223609924e-01
    z[5,4,6]  R2023     5.6042182445526123e-01
    z[5,4,6]  R2024     -7.3065526783466339e-02
    z[5,4,6]  R2025     1.2765587866306305e-01
    z[5,4,6]  R2026     8.8968977332115173e-02
    z[5,4,6]  R2027     5.8499538898468018e-01
    z[5,4,6]  R2028     -2.1917113661766052e-01
    z[5,4,6]  R2029     1.6938470304012299e-01
    z[5,4,6]  R2030     1.2223885208368301e-01
    z[5,4,6]  R2031     -1.5865561366081238e-01
    z[5,4,6]  R2032     2.6672789454460144e-01
    z[5,4,6]  R2033     3.4181100130081177e-01
    z[5,4,6]  R2034     -3.4904679656028748e-01
    z[5,4,6]  R2035     5.7206612825393677e-01
    z[5,4,6]  R2036     4.2464268207550049e-01
    z[5,4,6]  R2037     2.2852925956249237e-01
    z[5,4,6]  R2038     0.223191499710083
    z[5,4,6]  R2039     5.3487755358219147e-02
    z[5,4,6]  R2040     2.2425462305545807e-01
    z[5,4,6]  R2041     2.4868229404091835e-02
    z[5,4,6]  R2042     3.1829643249511719e-01
    z[5,4,6]  R2043     -1.2762982398271561e-02
    z[5,4,6]  R2044     -4.1096824407577515e-01
    z[5,4,6]  R2045     1.5041979029774666e-02
    z[5,4,6]  R2046     -2.8784090280532837e-01
    z[5,4,6]  R2047     2.9248049482703209e-02
    z[5,4,6]  R2048     -2.2535309195518494e-01
    z[5,4,6]  R2049     -2.1008443832397461e-01
    z[5,4,6]  R2050     3.8518467545509338e-01
    z[5,4,6]  R2051     -2.7857992798089981e-02
    z[5,4,6]  R2052     -4.7027524560689926e-02
    z[5,4,6]  R2053     -1.0463027656078339e-01
    z[5,4,6]  R2054     -2.2879397869110107e-01
    z[5,4,6]  R2055     7.1988575160503387e-02
    z[5,4,6]  R2056     -2.5938370823860168e-01
    z[5,4,6]  R2057     -4.3014207482337952e-01
    z[5,4,6]  R2058     2.9551157355308533e-01
    z[5,4,6]  R2059     4.9728262424468994e-01
    z[5,4,6]  R2060     1.9631277024745941e-01
    z[5,4,6]  R2061     -6.5884912014007568e-01
    z[5,4,6]  R2062     4.8078387975692749e-01
    z[5,4,6]  R2063     4.7503682971000671e-01
    z[5,4,6]  R2064     -4.5341871678829193e-02
    z[5,4,6]  R2065     -1.5369729697704315e-01
    z[5,4,6]  R2066     0.0291310902684927
    z[5,4,6]  R2067     -6.2104641983751208e-05
    z[5,4,6]  R2068     8.7785460054874420e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2107     -1
    z[5,6,0]  R2108     1
    z[5,6,0]  R2121     -7.2277379035949707e-01
    z[5,6,0]  R2122     0.805334210395813
    z[5,6,0]  R2123     7.3077583312988281e-01
    z[5,6,0]  R2124     1.1370386183261871e-01
    z[5,6,0]  R2125     -7.7118612825870514e-02
    z[5,6,0]  R2126     1.3980850577354431e-01
    z[5,6,0]  R2127     -3.9450824260711670e-01
    z[5,6,0]  R2128     -5.3267621994018555e-01
    z[5,6,0]  R2129     1.5024597942829132e-01
    z[5,6,0]  R2130     1.7440715432167053e-01
    z[5,6,0]  R2131     6.5103721618652344e-01
    z[5,6,0]  R2132     1.6288323327898979e-02
    z[5,6,0]  R2133     -3.3365017175674438e-01
    z[5,6,0]  R2134     -5.9681493043899536e-01
    z[5,6,0]  R2135     -4.3888008594512939e-01
    z[5,6,0]  R2136     3.3577498793601990e-01
    z[5,6,0]  R2137     4.0972787141799927e-01
    z[5,6,0]  R2138     1.8252097070217133e-01
    z[5,6,0]  R2139     9.0965494513511658e-02
    z[5,6,0]  R2140     -5.5656415224075317e-01
    z[5,6,0]  R2141     -3.1916010379791260e-01
    z[5,6,0]  R2142     -8.7184444069862366e-02
    z[5,6,0]  R2143     -4.1862553358078003e-01
    z[5,6,0]  R2144     -6.4222311973571777e-01
    z[5,6,0]  R2145     6.0630504041910172e-02
    z[5,6,0]  R2146     -4.8078897595405579e-01
    z[5,6,0]  R2147     -4.2030301690101624e-01
    z[5,6,0]  R2148     0.355146199464798
    z[5,6,0]  R2149     2.7121397852897644e-01
    z[5,6,0]  R2150     4.7907616943120956e-02
    z[5,6,0]  R2151     1.3716715574264526e-01
    z[5,6,0]  R2152     -4.7560158371925354e-01
    z[5,6,0]  R2153     -6.0663259029388428e-01
    z[5,6,0]  R2154     2.3190313577651978e-01
    z[5,6,0]  R2155     2.1783809363842010e-01
    z[5,6,0]  R2156     3.5618704557418823e-01
    z[5,6,0]  R2157     3.3672192692756653e-01
    z[5,6,0]  R2158     2.8452232480049133e-01
    z[5,6,0]  R2159     3.6942040920257568e-01
    z[5,6,0]  R2160     3.5282671451568604e-01
    z[5,6,0]  R2161     -4.4571959972381592e-01
    z[5,6,0]  R2162     1.0341478139162064e-01
    z[5,6,0]  R2163     3.4538006782531738e-01
    z[5,6,0]  R2164     2.1061430871486664e-01
    z[5,6,0]  R2165     1.9354499876499176e-01
    z[5,6,0]  R2166     1.7186896502971649e-01
    z[5,6,0]  R2167     -3.8703698664903641e-02
    z[5,6,0]  R2168     2.5730609893798828e-01
    z[5,6,0]  R2169     7.7563089132308960e-01
    z[5,6,0]  R2170     -3.6315703392028809e-01
    z[5,6,0]  R2171     2.2257076203823090e-01
    z[5,6,0]  R2172     -4.7346496582031250e-01
    z[5,6,0]  R2173     3.5658380389213562e-01
    z[5,6,0]  R2174     -2.3258747160434723e-01
    z[5,6,0]  R2175     2.1382865309715271e-01
    z[5,6,0]  R2176     7.1372449398040771e-01
    z[5,6,0]  R2177     5.7560062408447266e-01
    z[5,6,0]  R2178     -4.9470528960227966e-01
    z[5,6,0]  R2179     3.5655274987220764e-01
    z[5,6,0]  R2180     -2.4651080369949341e-01
    z[5,6,0]  R2181     3.2239560037851334e-02
    z[5,6,0]  R2182     2.6050829887390137e-01
    z[5,6,0]  R2183     3.3348988741636276e-02
    z[5,6,0]  R2184     3.9413425326347351e-01
    z[5,6,0]  R2185     1.2040492892265320e-01
    z[5,6,0]  R2186     -4.4223297387361526e-02
    z[5,6,0]  R2187     1.2639553844928741e-01
    z[5,6,0]  R2188     2.3407611250877380e-01
    z[5,6,0]  R2189     2.2489212453365326e-02
    z[5,6,0]  R2190     0.049301877617836
    z[5,6,0]  R2191     -6.8539790809154510e-02
    z[5,6,0]  R2192     -1.3925112783908844e-01
    z[5,6,0]  R2193     -0.00698230741545558
    z[5,6,0]  R2194     4.2981904745101929e-01
    z[5,6,0]  R2195     -3.6302912235260010e-01
    z[5,6,0]  R2196     -3.9324671030044556e-02
    z[5,6,0]  R2197     -4.6612534672021866e-02
    z[5,6,0]  R2198     -4.6752050518989563e-02
    z[5,6,0]  R2199     8.7930776178836823e-02
    z[5,6,0]  R2200     -1.3830077648162842e-01
    z[5,6,0]  R2201     -7.0758499205112457e-02
    z[5,6,0]  R2202     -6.4150315523147583e-01
    z[5,6,0]  R2203     2.5420022010803223e-01
    z[5,6,0]  R2204     1.9832299649715424e-01
    z[5,6,0]  R2205     1.6615045070648193e-01
    z[5,6,0]  R2206     4.4550865888595581e-01
    z[5,6,0]  R2207     3.8090556859970093e-01
    z[5,6,0]  R2208     6.2357878684997559e-01
    z[5,6,0]  R2209     -2.5736644864082336e-01
    z[5,6,0]  R2210     -2.2577261924743652e-01
    z[5,6,0]  R2211     -4.2888778448104858e-01
    z[5,6,0]  R2212     -3.5213425755500793e-01
    z[5,6,0]  R2213     2.4962651729583740e-01
    z[5,6,0]  R2214     -4.7133937478065491e-01
    z[5,6,0]  R2215     2.6826107501983643e-01
    z[5,6,0]  R2216     4.7166994214057922e-01
    z[5,6,0]  R2217     -0.494873583316803
    z[5,6,0]  R2218     -2.0486731827259064e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2109     -1
    z[5,6,1]  R2110     1
    z[5,6,1]  R2121     4.9335613846778870e-01
    z[5,6,1]  R2122     -5.2092432975769043e-01
    z[5,6,1]  R2123     -3.1740444898605347e-01
    z[5,6,1]  R2124     -4.7887480258941650e-01
    z[5,6,1]  R2125     3.2369661331176758e-01
    z[5,6,1]  R2126     7.4469465017318726e-01
    z[5,6,1]  R2127     3.1814590096473694e-01
    z[5,6,1]  R2128     -3.7238383293151855e-01
    z[5,6,1]  R2129     -4.2741736769676208e-01
    z[5,6,1]  R2130     -3.2416197657585144e-01
    z[5,6,1]  R2131     -2.1738414466381073e-01
    z[5,6,1]  R2132     -1.8900883197784424e-01
    z[5,6,1]  R2133     3.3727544546127319e-01
    z[5,6,1]  R2134     9.7226023674011230e-02
    z[5,6,1]  R2135     -7.2843387722969055e-02
    z[5,6,1]  R2136     6.4356744289398193e-01
    z[5,6,1]  R2137     7.6706510782241821e-01
    z[5,6,1]  R2138     6.5957701206207275e-01
    z[5,6,1]  R2139     -5.0450706481933594e-01
    z[5,6,1]  R2140     5.6698240339756012e-02
    z[5,6,1]  R2141     4.8791885375976562e-02
    z[5,6,1]  R2142     -1.3757948577404022e-01
    z[5,6,1]  R2143     3.7401422858238220e-01
    z[5,6,1]  R2144     1.1739350110292435e-01
    z[5,6,1]  R2145     2.3625028133392334e-01
    z[5,6,1]  R2146     1.8291552364826202e-01
    z[5,6,1]  R2147     4.8557594418525696e-02
    z[5,6,1]  R2148     7.9516094923019409e-01
    z[5,6,1]  R2149     -1.7780935764312744e-01
    z[5,6,1]  R2150     -2.0906296372413635e-01
    z[5,6,1]  R2151     -3.6919206380844116e-01
    z[5,6,1]  R2152     3.8943886756896973e-01
    z[5,6,1]  R2153     2.8447780013084412e-01
    z[5,6,1]  R2154     8.3946412801742554e-01
    z[5,6,1]  R2155     0.894114077091217
    z[5,6,1]  R2156     7.2143363952636719e-01
    z[5,6,1]  R2157     6.5222895145416260e-01
    z[5,6,1]  R2158     6.5590417385101318e-01
    z[5,6,1]  R2159     -5.3437268733978271e-01
    z[5,6,1]  R2160     -1.7508365213871002e-01
    z[5,6,1]  R2161     1.9357708096504211e-01
    z[5,6,1]  R2162     7.8060162067413330e-01
    z[5,6,1]  R2163     0.706145167350769
    z[5,6,1]  R2164     3.6584153771400452e-01
    z[5,6,1]  R2165     3.0645939707756042e-01
    z[5,6,1]  R2166     3.1118473410606384e-01
    z[5,6,1]  R2167     1.4049403369426727e-01
    z[5,6,1]  R2168     4.9242043495178223e-01
    z[5,6,1]  R2169     -6.8863760679960251e-03
    z[5,6,1]  R2170     5.6003773212432861e-01
    z[5,6,1]  R2171     -1.4625418186187744e-01
    z[5,6,1]  R2172     6.9248473644256592e-01
    z[5,6,1]  R2173     3.9886170625686646e-01
    z[5,6,1]  R2174     5.5988734960556030e-01
    z[5,6,1]  R2175     1.0517976433038712e-01
    z[5,6,1]  R2176     -2.9216584563255310e-01
    z[5,6,1]  R2177     -2.8257003426551819e-01
    z[5,6,1]  R2178     -1.3245357573032379e-01
    z[5,6,1]  R2179     3.8201412558555603e-01
    z[5,6,1]  R2180     3.3908998966217041e-01
    z[5,6,1]  R2181     -7.6833689212799072e-01
    z[5,6,1]  R2182     3.7499892711639404e-01
    z[5,6,1]  R2183     2.9757189750671387e-01
    z[5,6,1]  R2184     -2.0670397579669952e-01
    z[5,6,1]  R2185     -2.9394933581352234e-01
    z[5,6,1]  R2186     -1.2583871185779572e-01
    z[5,6,1]  R2187     -2.2176085412502289e-01
    z[5,6,1]  R2188     -1.3010367751121521e-01
    z[5,6,1]  R2189     7.5065529346466064e-01
    z[5,6,1]  R2190     -4.5002600550651550e-01
    z[5,6,1]  R2191     5.0673919916152954e-01
    z[5,6,1]  R2192     3.5009592771530151e-01
    z[5,6,1]  R2193     -2.4651616811752319e-01
    z[5,6,1]  R2194     3.0220919847488403e-01
    z[5,6,1]  R2195     3.0643942952156067e-01
    z[5,6,1]  R2196     -1.0024845600128174e-01
    z[5,6,1]  R2197     -2.0697984099388123e-01
    z[5,6,1]  R2198     0.4423828125
    z[5,6,1]  R2199     2.1564997732639313e-01
    z[5,6,1]  R2200     3.8733181357383728e-01
    z[5,6,1]  R2201     4.2823117971420288e-01
    z[5,6,1]  R2202     3.6220580339431763e-01
    z[5,6,1]  R2203     -6.1041563749313354e-01
    z[5,6,1]  R2204     -5.3197807073593140e-01
    z[5,6,1]  R2205     -7.1954762935638428e-01
    z[5,6,1]  R2206     -6.6901612281799316e-01
    z[5,6,1]  R2207     -5.9677267074584961e-01
    z[5,6,1]  R2208     -5.1348793506622314e-01
    z[5,6,1]  R2209     5.8343487977981567e-01
    z[5,6,1]  R2210     4.3708932399749756e-01
    z[5,6,1]  R2211     5.0127738714218140e-01
    z[5,6,1]  R2212     3.1788554787635803e-01
    z[5,6,1]  R2213     -2.6431185007095337e-01
    z[5,6,1]  R2214     6.6319274902343750e-01
    z[5,6,1]  R2215     -2.4326251447200775e-01
    z[5,6,1]  R2216     1.5771420672535896e-02
    z[5,6,1]  R2217     4.6840080618858337e-01
    z[5,6,1]  R2218     -5.3650361299514771e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2111     -1
    z[5,6,2]  R2112     1
    z[5,6,2]  R2121     -4.6858462691307068e-01
    z[5,6,2]  R2122     1.6033723950386047e-01
    z[5,6,2]  R2123     3.6763134598731995e-01
    z[5,6,2]  R2124     2.9411950707435608e-01
    z[5,6,2]  R2125     -2.0330508053302765e-01
    z[5,6,2]  R2126     0.450483113527298
    z[5,6,2]  R2127     6.3353300094604492e-01
    z[5,6,2]  R2128     4.7934162616729736e-01
    z[5,6,2]  R2129     4.2288044095039368e-01
    z[5,6,2]  R2130     7.7174264192581177e-01
    z[5,6,2]  R2131     0.0368468351662159
    z[5,6,2]  R2132     7.5390481948852539e-01
    z[5,6,2]  R2133     3.0433061718940735e-01
    z[5,6,2]  R2134     5.9244847297668457e-01
    z[5,6,2]  R2135     4.0476010181009769e-03
    z[5,6,2]  R2136     -9.3448825180530548e-02
    z[5,6,2]  R2137     2.7863787487149239e-02
    z[5,6,2]  R2138     1.8628510832786560e-01
    z[5,6,2]  R2139     3.7412515282630920e-01
    z[5,6,2]  R2140     7.2498425841331482e-02
    z[5,6,2]  R2141     -2.7489945292472839e-01
    z[5,6,2]  R2142     7.8560537099838257e-01
    z[5,6,2]  R2143     4.5996546745300293e-01
    z[5,6,2]  R2144     5.5690473318099976e-01
    z[5,6,2]  R2145     -6.1309903860092163e-01
    z[5,6,2]  R2146     2.0956581830978394e-01
    z[5,6,2]  R2147     1.0263431817293167e-01
    z[5,6,2]  R2148     1.1223587393760681e-01
    z[5,6,2]  R2149     3.2272240519523621e-01
    z[5,6,2]  R2150     7.7449077367782593e-01
    z[5,6,2]  R2151     -3.1922541558742523e-02
    z[5,6,2]  R2152     3.7960460782051086e-01
    z[5,6,2]  R2153     0.566888689994812
    z[5,6,2]  R2154     1.9992722570896149e-01
    z[5,6,2]  R2155     2.5040122866630554e-01
    z[5,6,2]  R2156     -1.5434475243091583e-01
    z[5,6,2]  R2157     5.5092971771955490e-02
    z[5,6,2]  R2158     6.4093485474586487e-02
    z[5,6,2]  R2159     3.9169132709503174e-01
    z[5,6,2]  R2160     4.8306062817573547e-01
    z[5,6,2]  R2161     1.1360051482915878e-01
    z[5,6,2]  R2162     3.5109764337539673e-01
    z[5,6,2]  R2163     -1.8109707534313202e-01
    z[5,6,2]  R2164     7.0444536395370960e-03
    z[5,6,2]  R2165     -1.0378784686326981e-01
    z[5,6,2]  R2166     -3.2495737075805664e-01
    z[5,6,2]  R2167     -1.4832274615764618e-01
    z[5,6,2]  R2168     -1.1233911663293839e-01
    z[5,6,2]  R2169     4.7511968016624451e-01
    z[5,6,2]  R2170     -2.9498362541198730e-01
    z[5,6,2]  R2171     9.4056320190429688e-01
    z[5,6,2]  R2172     -2.1618528664112091e-01
    z[5,6,2]  R2173     -4.4302487373352051e-01
    z[5,6,2]  R2174     -2.6129558682441711e-01
    z[5,6,2]  R2175     -4.5782196521759033e-01
    z[5,6,2]  R2176     -0.60861736536026
    z[5,6,2]  R2177     -0.651661217212677
    z[5,6,2]  R2178     5.7883709669113159e-01
    z[5,6,2]  R2179     -6.7905426025390625e-01
    z[5,6,2]  R2180     -2.1646840870380402e-01
    z[5,6,2]  R2181     0.572898805141449
    z[5,6,2]  R2182     -3.7956693768501282e-01
    z[5,6,2]  R2183     -3.0350151658058167e-01
    z[5,6,2]  R2184     1.7284838855266571e-01
    z[5,6,2]  R2185     0.508536696434021
    z[5,6,2]  R2186     -2.6058253645896912e-01
    z[5,6,2]  R2187     3.9446863532066345e-01
    z[5,6,2]  R2188     -3.0458378791809082e-01
    z[5,6,2]  R2189     -4.2649102210998535e-01
    z[5,6,2]  R2190     2.5434204936027527e-01
    z[5,6,2]  R2191     -1.4129005372524261e-01
    z[5,6,2]  R2192     -3.8931033015251160e-01
    z[5,6,2]  R2193     4.5407322049140930e-01
    z[5,6,2]  R2194     -6.0657691955566406e-01
    z[5,6,2]  R2195     -2.8872179985046387e-01
    z[5,6,2]  R2196     -3.6127230525016785e-01
    z[5,6,2]  R2197     4.4500410556793213e-01
    z[5,6,2]  R2198     -2.3062816262245178e-01
    z[5,6,2]  R2199     -3.6736661195755005e-01
    z[5,6,2]  R2200     -5.2608931064605713e-01
    z[5,6,2]  R2201     -3.2370918989181519e-01
    z[5,6,2]  R2202     9.6486732363700867e-02
    z[5,6,2]  R2203     4.9646192789077759e-01
    z[5,6,2]  R2204     4.8926532268524170e-01
    z[5,6,2]  R2205     4.4028982520103455e-01
    z[5,6,2]  R2206     1.7534171044826508e-01
    z[5,6,2]  R2207     2.3417973518371582e-01
    z[5,6,2]  R2208     1.1144289374351501e-01
    z[5,6,2]  R2209     -3.2406392693519592e-01
    z[5,6,2]  R2210     -5.0877904891967773e-01
    z[5,6,2]  R2211     -1.6972798109054565e-01
    z[5,6,2]  R2212     -3.3042725920677185e-01
    z[5,6,2]  R2213     2.9166355729103088e-01
    z[5,6,2]  R2214     -1.6853570938110352e-01
    z[5,6,2]  R2215     3.0091315507888794e-01
    z[5,6,2]  R2216     4.2526204138994217e-02
    z[5,6,2]  R2217     1.0257680714130402e-01
    z[5,6,2]  R2218     4.3797358870506287e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2113     -1
    z[5,6,3]  R2114     1
    z[5,6,3]  R2121     0.0741507038474083
    z[5,6,3]  R2122     -3.5644143819808960e-02
    z[5,6,3]  R2123     -1.9135881960391998e-01
    z[5,6,3]  R2124     5.6048100814223289e-03
    z[5,6,3]  R2125     -6.7439842224121094e-01
    z[5,6,3]  R2126     3.2411301136016846e-01
    z[5,6,3]  R2127     -4.6218031644821167e-01
    z[5,6,3]  R2128     1.8789154291152954e-01
    z[5,6,3]  R2129     2.1419529616832733e-01
    z[5,6,3]  R2130     4.3450275063514709e-01
    z[5,6,3]  R2131     -3.3244210481643677e-01
    z[5,6,3]  R2132     1.4798830263316631e-02
    z[5,6,3]  R2133     -5.7175344228744507e-01
    z[5,6,3]  R2134     -5.0337541103363037e-01
    z[5,6,3]  R2135     -4.3989843130111694e-01
    z[5,6,3]  R2136     5.6945568323135376e-01
    z[5,6,3]  R2137     3.1394094228744507e-01
    z[5,6,3]  R2138     5.4297178983688354e-01
    z[5,6,3]  R2139     7.8871408477425575e-03
    z[5,6,3]  R2140     -5.3595298528671265e-01
    z[5,6,3]  R2141     -7.5749266147613525e-01
    z[5,6,3]  R2142     -5.6745105981826782e-01
    z[5,6,3]  R2143     -3.8951399922370911e-01
    z[5,6,3]  R2144     -4.8240518569946289e-01
    z[5,6,3]  R2145     -5.1529681682586670e-01
    z[5,6,3]  R2146     -5.2376532554626465e-01
    z[5,6,3]  R2147     -6.9816923141479492e-01
    z[5,6,3]  R2148     4.0796205401420593e-01
    z[5,6,3]  R2149     -2.9315567016601562e-01
    z[5,6,3]  R2150     -5.8616679906845093e-01
    z[5,6,3]  R2151     -5.9187036752700806e-01
    z[5,6,3]  R2152     -2.2168566286563873e-01
    z[5,6,3]  R2153     -1.7261917889118195e-01
    z[5,6,3]  R2154     3.3974161744117737e-01
    z[5,6,3]  R2155     1.9725590944290161e-01
    z[5,6,3]  R2156     4.6568682789802551e-01
    z[5,6,3]  R2157     5.7034349441528320e-01
    z[5,6,3]  R2158     4.6530708670616150e-01
    z[5,6,3]  R2159     5.3525015711784363e-02
    z[5,6,3]  R2160     -5.4226624965667725e-01
    z[5,6,3]  R2161     -8.3188682794570923e-01
    z[5,6,3]  R2162     4.4643855094909668e-01
    z[5,6,3]  R2163     3.2516720890998840e-01
    z[5,6,3]  R2164     8.6171567440032959e-01
    z[5,6,3]  R2165     9.1848051548004150e-01
    z[5,6,3]  R2166     2.0819117128849030e-01
    z[5,6,3]  R2167     5.4480707645416260e-01
    z[5,6,3]  R2168     0.648116409778595
    z[5,6,3]  R2169     2.1513253450393677e-01
    z[5,6,3]  R2170     4.1307443380355835e-01
    z[5,6,3]  R2171     9.2487454414367676e-02
    z[5,6,3]  R2172     2.8184279799461365e-01
    z[5,6,3]  R2173     2.4462194740772247e-01
    z[5,6,3]  R2174     -4.2428457736968994e-01
    z[5,6,3]  R2175     2.8683164715766907e-01
    z[5,6,3]  R2176     5.8566696941852570e-02
    z[5,6,3]  R2177     -7.3858529329299927e-02
    z[5,6,3]  R2178     -9.7937986254692078e-02
    z[5,6,3]  R2179     7.9831499606370926e-03
    z[5,6,3]  R2180     1.7509230971336365e-01
    z[5,6,3]  R2181     4.2215961962938309e-02
    z[5,6,3]  R2182     -6.5733693540096283e-02
    z[5,6,3]  R2183     -6.8958718329668045e-03
    z[5,6,3]  R2184     -9.3161761760711670e-03
    z[5,6,3]  R2185     -5.9417265653610229e-01
    z[5,6,3]  R2186     3.0213648080825806e-01
    z[5,6,3]  R2187     -5.0230938196182251e-01
    z[5,6,3]  R2188     9.0317547321319580e-01
    z[5,6,3]  R2189     1.5011011064052582e-01
    z[5,6,3]  R2190     6.5144568681716919e-01
    z[5,6,3]  R2191     4.3764621019363403e-01
    z[5,6,3]  R2192     5.6495642662048340e-01
    z[5,6,3]  R2193     3.0804595351219177e-01
    z[5,6,3]  R2194     5.1600122451782227e-01
    z[5,6,3]  R2195     1.2161944806575775e-01
    z[5,6,3]  R2196     6.4246350526809692e-01
    z[5,6,3]  R2197     -3.2450112700462341e-01
    z[5,6,3]  R2198     2.9475349187850952e-01
    z[5,6,3]  R2199     8.0075448751449585e-01
    z[5,6,3]  R2200     1.4355318248271942e-01
    z[5,6,3]  R2201     -1.0965181142091751e-01
    z[5,6,3]  R2202     4.7584244608879089e-01
    z[5,6,3]  R2203     -4.6038556098937988e-01
    z[5,6,3]  R2204     -0.3236083984375
    z[5,6,3]  R2205     -2.0194093883037567e-01
    z[5,6,3]  R2206     -2.8639006614685059e-01
    z[5,6,3]  R2207     -5.2986311912536621e-01
    z[5,6,3]  R2208     -5.5533796548843384e-01
    z[5,6,3]  R2209     5.0833827257156372e-01
    z[5,6,3]  R2210     3.2436171174049377e-01
    z[5,6,3]  R2211     2.4476137757301331e-01
    z[5,6,3]  R2212     7.0018047094345093e-01
    z[5,6,3]  R2213     -2.7334091067314148e-01
    z[5,6,3]  R2214     -2.3013319075107574e-01
    z[5,6,3]  R2215     0.042548768222332
    z[5,6,3]  R2216     -8.6475081741809845e-02
    z[5,6,3]  R2217     1.9139336422085762e-02
    z[5,6,3]  R2218     4.4826313853263855e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2115     -1
    z[5,6,4]  R2116     1
    z[5,6,4]  R2121     -5.0201267004013062e-02
    z[5,6,4]  R2122     2.0140080153942108e-01
    z[5,6,4]  R2123     -1.2708598375320435e-01
    z[5,6,4]  R2124     7.1005290746688843e-01
    z[5,6,4]  R2125     -1.5742965042591095e-01
    z[5,6,4]  R2126     -1.4207400381565094e-01
    z[5,6,4]  R2127     9.2905789613723755e-02
    z[5,6,4]  R2128     -1.1216209828853607e-01
    z[5,6,4]  R2129     6.4459383487701416e-02
    z[5,6,4]  R2130     0.129435732960701
    z[5,6,4]  R2131     -4.1458931565284729e-01
    z[5,6,4]  R2132     -1.4615179598331451e-01
    z[5,6,4]  R2133     -1.0555419325828552e-01
    z[5,6,4]  R2134     1.5200559794902802e-01
    z[5,6,4]  R2135     5.8861184120178223e-01
    z[5,6,4]  R2136     3.7204778194427490e-01
    z[5,6,4]  R2137     -2.9196339845657349e-01
    z[5,6,4]  R2138     2.4302378296852112e-02
    z[5,6,4]  R2139     4.9243906140327454e-01
    z[5,6,4]  R2140     5.1775109767913818e-01
    z[5,6,4]  R2141     3.5475182533264160e-01
    z[5,6,4]  R2142     -6.6218726336956024e-02
    z[5,6,4]  R2143     -4.8138126730918884e-01
    z[5,6,4]  R2144     6.9008268415927887e-02
    z[5,6,4]  R2145     -2.0882911980152130e-02
    z[5,6,4]  R2146     -3.0655593145638704e-03
    z[5,6,4]  R2147     9.0737171471118927e-02
    z[5,6,4]  R2148     2.3281882703304291e-01
    z[5,6,4]  R2149     -3.2913425564765930e-01
    z[5,6,4]  R2150     -1.9677041098475456e-02
    z[5,6,4]  R2151     3.1881293654441833e-01
    z[5,6,4]  R2152     -1.6965357959270477e-01
    z[5,6,4]  R2153     -1.7790514230728149e-01
    z[5,6,4]  R2154     -1.6859249770641327e-01
    z[5,6,4]  R2155     4.3431546539068222e-02
    z[5,6,4]  R2156     -1.0452105849981308e-01
    z[5,6,4]  R2157     -2.2325780242681503e-02
    z[5,6,4]  R2158     -3.5965809226036072e-01
    z[5,6,4]  R2159     0.268614798784256
    z[5,6,4]  R2160     -3.6467319726943970e-01
    z[5,6,4]  R2161     -3.9487909525632858e-02
    z[5,6,4]  R2162     8.6490392684936523e-02
    z[5,6,4]  R2163     3.3647322654724121e-01
    z[5,6,4]  R2164     1.6580912470817566e-01
    z[5,6,4]  R2165     -1.1505384743213654e-01
    z[5,6,4]  R2166     -5.4393541812896729e-01
    z[5,6,4]  R2167     0.0495305210351944
    z[5,6,4]  R2168     -1.7865665256977081e-01
    z[5,6,4]  R2169     2.3307062685489655e-01
    z[5,6,4]  R2170     2.5533128529787064e-02
    z[5,6,4]  R2171     2.7801211923360825e-02
    z[5,6,4]  R2172     -2.5979182124137878e-01
    z[5,6,4]  R2173     6.5709066390991211e-01
    z[5,6,4]  R2174     2.2197322547435760e-01
    z[5,6,4]  R2175     4.7340080142021179e-01
    z[5,6,4]  R2176     -2.6889607310295105e-02
    z[5,6,4]  R2177     -3.4498524665832520e-01
    z[5,6,4]  R2178     3.8552662730216980e-01
    z[5,6,4]  R2179     -4.2029681801795959e-01
    z[5,6,4]  R2180     4.5138096809387207e-01
    z[5,6,4]  R2181     1.0632122308015823e-01
    z[5,6,4]  R2182     -6.3010370731353760e-01
    z[5,6,4]  R2183     -0.851609468460083
    z[5,6,4]  R2184     1.2785906903445721e-02
    z[5,6,4]  R2185     1.0424222797155380e-01
    z[5,6,4]  R2186     -7.7600908279418945e-01
    z[5,6,4]  R2187     4.1884702444076538e-01
    z[5,6,4]  R2188     1.0178020223975182e-02
    z[5,6,4]  R2189     3.7334653735160828e-01
    z[5,6,4]  R2190     3.4768790006637573e-01
    z[5,6,4]  R2191     2.7879342436790466e-01
    z[5,6,4]  R2192     -5.8211672306060791e-01
    z[5,6,4]  R2193     -2.4894128739833832e-01
    z[5,6,4]  R2194     -1.0453967005014420e-01
    z[5,6,4]  R2195     -6.4241182804107666e-01
    z[5,6,4]  R2196     -4.8757123947143555e-01
    z[5,6,4]  R2197     -4.2702168226242065e-01
    z[5,6,4]  R2198     -3.4983408451080322e-01
    z[5,6,4]  R2199     -1.3893342018127441e-01
    z[5,6,4]  R2200     -2.7974995970726013e-01
    z[5,6,4]  R2201     -8.1697374582290649e-01
    z[5,6,4]  R2202     5.1591273397207260e-02
    z[5,6,4]  R2203     2.1880412101745605e-01
    z[5,6,4]  R2204     4.7620871663093567e-01
    z[5,6,4]  R2205     3.9910537004470825e-01
    z[5,6,4]  R2206     2.8587529063224792e-01
    z[5,6,4]  R2207     -2.2865609824657440e-01
    z[5,6,4]  R2208     9.1808803379535675e-02
    z[5,6,4]  R2209     4.6441745758056641e-01
    z[5,6,4]  R2210     -2.8656238317489624e-01
    z[5,6,4]  R2211     3.5038910806179047e-02
    z[5,6,4]  R2212     -8.6673960089683533e-02
    z[5,6,4]  R2213     -1.1518691480159760e-01
    z[5,6,4]  R2214     -3.9452469348907471e-01
    z[5,6,4]  R2215     3.6958824843168259e-02
    z[5,6,4]  R2216     4.2782264947891235e-01
    z[5,6,4]  R2217     -4.7407191991806030e-01
    z[5,6,4]  R2218     -3.2385182380676270e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2117     -1
    z[5,6,5]  R2118     1
    z[5,6,5]  R2121     -7.6874576508998871e-02
    z[5,6,5]  R2122     3.5730041563510895e-03
    z[5,6,5]  R2123     -1.6611084342002869e-01
    z[5,6,5]  R2124     -2.1292728185653687e-01
    z[5,6,5]  R2125     6.0546815395355225e-01
    z[5,6,5]  R2126     -3.1042459607124329e-01
    z[5,6,5]  R2127     1.9761377573013306e-01
    z[5,6,5]  R2128     5.4740697145462036e-01
    z[5,6,5]  R2129     -6.2707710266113281e-01
    z[5,6,5]  R2130     -5.8926129713654518e-03
    z[5,6,5]  R2131     -4.0352556109428406e-01
    z[5,6,5]  R2132     3.0668142437934875e-01
    z[5,6,5]  R2133     3.7205097079277039e-01
    z[5,6,5]  R2134     8.2550808787345886e-02
    z[5,6,5]  R2135     0.428880512714386
    z[5,6,5]  R2136     -2.5570359081029892e-02
    z[5,6,5]  R2137     -7.0960409939289093e-02
    z[5,6,5]  R2138     4.1393381357192993e-01
    z[5,6,5]  R2139     1.8796385824680328e-01
    z[5,6,5]  R2140     3.5510486364364624e-01
    z[5,6,5]  R2141     -3.2259428501129150e-01
    z[5,6,5]  R2142     -1.4974993467330933e-01
    z[5,6,5]  R2143     2.4394790828227997e-01
    z[5,6,5]  R2144     -6.0236491262912750e-02
    z[5,6,5]  R2145     0.537821888923645
    z[5,6,5]  R2146     4.4306963682174683e-01
    z[5,6,5]  R2147     2.6599545031785965e-02
    z[5,6,5]  R2148     -5.4927755147218704e-02
    z[5,6,5]  R2149     -7.6165050268173218e-01
    z[5,6,5]  R2150     -4.7618150711059570e-02
    z[5,6,5]  R2151     -2.2291608154773712e-01
    z[5,6,5]  R2152     5.9336161613464355e-01
    z[5,6,5]  R2153     3.7358757853507996e-01
    z[5,6,5]  R2154     2.0678481459617615e-01
    z[5,6,5]  R2155     1.5632654726505280e-01
    z[5,6,5]  R2156     1.7294344305992126e-01
    z[5,6,5]  R2157     -1.2472229450941086e-01
    z[5,6,5]  R2158     -1.3050112128257751e-01
    z[5,6,5]  R2159     1.4924408495426178e-01
    z[5,6,5]  R2160     -6.4426816999912262e-02
    z[5,6,5]  R2161     -7.1667745709419250e-02
    z[5,6,5]  R2162     -9.7219776362180710e-03
    z[5,6,5]  R2163     3.5702455043792725e-01
    z[5,6,5]  R2164     3.7620570510625839e-02
    z[5,6,5]  R2165     -1.9718091934919357e-02
    z[5,6,5]  R2166     5.7228130102157593e-01
    z[5,6,5]  R2167     8.1076073646545410e-01
    z[5,6,5]  R2168     2.4047380685806274e-01
    z[5,6,5]  R2169     -2.4626553058624268e-01
    z[5,6,5]  R2170     3.9973545819520950e-02
    z[5,6,5]  R2171     1.8533450365066528e-01
    z[5,6,5]  R2172     2.9870948195457458e-01
    z[5,6,5]  R2173     -1.1307615786790848e-01
    z[5,6,5]  R2174     5.5027270317077637e-01
    z[5,6,5]  R2175     0.598588764667511
    z[5,6,5]  R2176     1.6931708157062531e-01
    z[5,6,5]  R2177     1.1876410990953445e-01
    z[5,6,5]  R2178     -1.1166165024042130e-01
    z[5,6,5]  R2179     1.9647181034088135e-01
    z[5,6,5]  R2180     6.0314178466796875e-01
    z[5,6,5]  R2181     -1.6237659752368927e-01
    z[5,6,5]  R2182     -4.7565874457359314e-01
    z[5,6,5]  R2183     -2.9490628838539124e-01
    z[5,6,5]  R2184     -7.6681065559387207e-01
    z[5,6,5]  R2185     -5.1645308732986450e-01
    z[5,6,5]  R2186     3.8237437605857849e-01
    z[5,6,5]  R2187     -3.2025906443595886e-01
    z[5,6,5]  R2188     -1.2556119263172150e-01
    z[5,6,5]  R2189     -1.8859510123729706e-01
    z[5,6,5]  R2190     -2.1523422002792358e-01
    z[5,6,5]  R2191     -5.9475260972976685e-01
    z[5,6,5]  R2192     -1.0085628181695938e-01
    z[5,6,5]  R2193     -3.0298787355422974e-01
    z[5,6,5]  R2194     -2.4765150249004364e-01
    z[5,6,5]  R2195     4.7999256849288940e-01
    z[5,6,5]  R2196     4.4700637459754944e-01
    z[5,6,5]  R2197     -6.5264725685119629e-01
    z[5,6,5]  R2198     -4.7134715318679810e-01
    z[5,6,5]  R2199     -3.5447177290916443e-01
    z[5,6,5]  R2200     6.7346090078353882e-01
    z[5,6,5]  R2201     -1.6537380218505859e-01
    z[5,6,5]  R2202     3.0855366960167885e-02
    z[5,6,5]  R2203     -2.0155285298824310e-01
    z[5,6,5]  R2204     -1.2042575329542160e-01
    z[5,6,5]  R2205     2.4261063337326050e-01
    z[5,6,5]  R2206     3.4163564443588257e-01
    z[5,6,5]  R2207     1.0395988821983337e-01
    z[5,6,5]  R2208     -2.8603386133909225e-02
    z[5,6,5]  R2209     1.1940021067857742e-01
    z[5,6,5]  R2210     5.5837196111679077e-01
    z[5,6,5]  R2211     2.7310207486152649e-01
    z[5,6,5]  R2212     3.7988269329071045e-01
    z[5,6,5]  R2213     -6.8950974941253662e-01
    z[5,6,5]  R2214     1.4357882738113403e-01
    z[5,6,5]  R2215     -8.6851459741592407e-01
    z[5,6,5]  R2216     -7.1773386001586914e-01
    z[5,6,5]  R2217     -4.0822815895080566e-01
    z[5,6,5]  R2218     -3.4957060217857361e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2119     -1
    z[5,6,6]  R2120     1
    z[5,6,6]  R2121     -2.6419568806886673e-02
    z[5,6,6]  R2122     -1.1189787089824677e-01
    z[5,6,6]  R2123     -3.8691911101341248e-01
    z[5,6,6]  R2124     -3.4885451197624207e-01
    z[5,6,6]  R2125     -4.1847601532936096e-02
    z[5,6,6]  R2126     3.6751903593540192e-02
    z[5,6,6]  R2127     -2.8370583057403564e-01
    z[5,6,6]  R2128     1.6733314841985703e-02
    z[5,6,6]  R2129     4.1551443934440613e-01
    z[5,6,6]  R2130     -2.5166139006614685e-01
    z[5,6,6]  R2131     0.286883145570755
    z[5,6,6]  R2132     5.2915501594543457e-01
    z[5,6,6]  R2133     -4.5369610190391541e-01
    z[5,6,6]  R2134     7.5325523503124714e-03
    z[5,6,6]  R2135     2.7955085039138794e-01
    z[5,6,6]  R2136     3.1469553709030151e-02
    z[5,6,6]  R2137     2.3263911902904510e-01
    z[5,6,6]  R2138     1.7375846207141876e-01
    z[5,6,6]  R2139     0.565101146697998
    z[5,6,6]  R2140     1.8824603408575058e-02
    z[5,6,6]  R2141     -1.2835679948329926e-01
    z[5,6,6]  R2142     8.6512207984924316e-02
    z[5,6,6]  R2143     1.7417861521244049e-01
    z[5,6,6]  R2144     1.5006642043590546e-01
    z[5,6,6]  R2145     9.6953660249710083e-02
    z[5,6,6]  R2146     4.6991053223609924e-01
    z[5,6,6]  R2147     5.6042182445526123e-01
    z[5,6,6]  R2148     -7.3065526783466339e-02
    z[5,6,6]  R2149     1.2765587866306305e-01
    z[5,6,6]  R2150     8.8968977332115173e-02
    z[5,6,6]  R2151     5.8499538898468018e-01
    z[5,6,6]  R2152     -2.1917113661766052e-01
    z[5,6,6]  R2153     1.6938470304012299e-01
    z[5,6,6]  R2154     1.2223885208368301e-01
    z[5,6,6]  R2155     -1.5865561366081238e-01
    z[5,6,6]  R2156     2.6672789454460144e-01
    z[5,6,6]  R2157     3.4181100130081177e-01
    z[5,6,6]  R2158     -3.4904679656028748e-01
    z[5,6,6]  R2159     5.7206612825393677e-01
    z[5,6,6]  R2160     4.2464268207550049e-01
    z[5,6,6]  R2161     2.2852925956249237e-01
    z[5,6,6]  R2162     0.223191499710083
    z[5,6,6]  R2163     5.3487755358219147e-02
    z[5,6,6]  R2164     2.2425462305545807e-01
    z[5,6,6]  R2165     2.4868229404091835e-02
    z[5,6,6]  R2166     3.1829643249511719e-01
    z[5,6,6]  R2167     -1.2762982398271561e-02
    z[5,6,6]  R2168     -4.1096824407577515e-01
    z[5,6,6]  R2169     -1.0658331215381622e-01
    z[5,6,6]  R2170     -5.4275143146514893e-01
    z[5,6,6]  R2171     -2.7151120826601982e-02
    z[5,6,6]  R2172     -1.1578156799077988e-01
    z[5,6,6]  R2173     -1.1442054808139801e-01
    z[5,6,6]  R2174     -1.7906531691551208e-01
    z[5,6,6]  R2175     -2.6253458857536316e-01
    z[5,6,6]  R2176     4.4720619916915894e-02
    z[5,6,6]  R2177     -1.6000309586524963e-01
    z[5,6,6]  R2178     -4.8164242506027222e-01
    z[5,6,6]  R2179     2.2473609447479248e-01
    z[5,6,6]  R2180     4.2333155870437622e-01
    z[5,6,6]  R2181     -2.0236971974372864e-01
    z[5,6,6]  R2182     1.4084529876708984e-01
    z[5,6,6]  R2183     -7.7263832092285156e-02
    z[5,6,6]  R2184     4.2872640490531921e-01
    z[5,6,6]  R2185     -9.9274218082427979e-02
    z[5,6,6]  R2186     2.7316457033157349e-01
    z[5,6,6]  R2187     -4.9892616271972656e-01
    z[5,6,6]  R2188     6.2569208443164825e-02
    z[5,6,6]  R2189     2.3796525597572327e-01
    z[5,6,6]  R2190     3.7250757217407227e-01
    z[5,6,6]  R2191     3.0913466215133667e-01
    z[5,6,6]  R2192     1.9563171267509460e-01
    z[5,6,6]  R2193     6.9594025611877441e-01
    z[5,6,6]  R2194     1.3218365609645844e-01
    z[5,6,6]  R2195     1.8184454739093781e-01
    z[5,6,6]  R2196     8.7099619209766388e-02
    z[5,6,6]  R2197     2.0823296904563904e-01
    z[5,6,6]  R2198     5.6346309185028076e-01
    z[5,6,6]  R2199     -1.5698574483394623e-01
    z[5,6,6]  R2200     -4.0741167962551117e-02
    z[5,6,6]  R2201     2.3560726549476385e-03
    z[5,6,6]  R2202     4.6683105826377869e-01
    z[5,6,6]  R2203     -1.2588398158550262e-01
    z[5,6,6]  R2204     3.0378827452659607e-01
    z[5,6,6]  R2205     4.3183397501707077e-02
    z[5,6,6]  R2206     2.0672650635242462e-01
    z[5,6,6]  R2207     3.1636545062065125e-01
    z[5,6,6]  R2208     1.3195750117301941e-01
    z[5,6,6]  R2209     -1.0134275071322918e-03
    z[5,6,6]  R2210     -3.9759213104844093e-03
    z[5,6,6]  R2211     6.3265162706375122e-01
    z[5,6,6]  R2212     1.5392234921455383e-01
    z[5,6,6]  R2213     -0.468349426984787
    z[5,6,6]  R2214     2.8352162241935730e-01
    z[5,6,6]  R2215     1.4427970349788666e-01
    z[5,6,6]  R2216     2.6423105597496033e-01
    z[5,6,6]  R2217     0.365264356136322
    z[5,6,6]  R2218     -2.2439448535442352e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2219     -1
    z[6,5,0]  R2220     1
    z[6,5,0]  R2233     7.7563089132308960e-01
    z[6,5,0]  R2234     -3.6315703392028809e-01
    z[6,5,0]  R2235     2.2257076203823090e-01
    z[6,5,0]  R2236     -4.7346496582031250e-01
    z[6,5,0]  R2237     3.5658380389213562e-01
    z[6,5,0]  R2238     -2.3258747160434723e-01
    z[6,5,0]  R2239     2.1382865309715271e-01
    z[6,5,0]  R2240     7.1372449398040771e-01
    z[6,5,0]  R2241     5.7560062408447266e-01
    z[6,5,0]  R2242     -4.9470528960227966e-01
    z[6,5,0]  R2243     3.5655274987220764e-01
    z[6,5,0]  R2244     -2.4651080369949341e-01
    z[6,5,0]  R2245     3.2239560037851334e-02
    z[6,5,0]  R2246     2.6050829887390137e-01
    z[6,5,0]  R2247     3.3348988741636276e-02
    z[6,5,0]  R2248     3.9413425326347351e-01
    z[6,5,0]  R2249     1.2040492892265320e-01
    z[6,5,0]  R2250     -4.4223297387361526e-02
    z[6,5,0]  R2251     1.2639553844928741e-01
    z[6,5,0]  R2252     2.3407611250877380e-01
    z[6,5,0]  R2253     2.2489212453365326e-02
    z[6,5,0]  R2254     0.049301877617836
    z[6,5,0]  R2255     -6.8539790809154510e-02
    z[6,5,0]  R2256     -1.3925112783908844e-01
    z[6,5,0]  R2257     -0.00698230741545558
    z[6,5,0]  R2258     4.2981904745101929e-01
    z[6,5,0]  R2259     -3.6302912235260010e-01
    z[6,5,0]  R2260     -3.9324671030044556e-02
    z[6,5,0]  R2261     -4.6612534672021866e-02
    z[6,5,0]  R2262     -4.6752050518989563e-02
    z[6,5,0]  R2263     8.7930776178836823e-02
    z[6,5,0]  R2264     -1.3830077648162842e-01
    z[6,5,0]  R2265     -7.0758499205112457e-02
    z[6,5,0]  R2266     -6.4150315523147583e-01
    z[6,5,0]  R2267     2.5420022010803223e-01
    z[6,5,0]  R2268     1.9832299649715424e-01
    z[6,5,0]  R2269     1.6615045070648193e-01
    z[6,5,0]  R2270     4.4550865888595581e-01
    z[6,5,0]  R2271     3.8090556859970093e-01
    z[6,5,0]  R2272     6.2357878684997559e-01
    z[6,5,0]  R2273     -2.5736644864082336e-01
    z[6,5,0]  R2274     -2.2577261924743652e-01
    z[6,5,0]  R2275     -4.2888778448104858e-01
    z[6,5,0]  R2276     -3.5213425755500793e-01
    z[6,5,0]  R2277     2.4962651729583740e-01
    z[6,5,0]  R2278     -4.7133937478065491e-01
    z[6,5,0]  R2279     2.6826107501983643e-01
    z[6,5,0]  R2280     4.7166994214057922e-01
    z[6,5,0]  R2281     -0.494873583316803
    z[6,5,0]  R2282     -2.0486731827259064e-01
    z[6,5,0]  R2283     -7.2277379035949707e-01
    z[6,5,0]  R2284     0.805334210395813
    z[6,5,0]  R2285     7.3077583312988281e-01
    z[6,5,0]  R2286     1.1370386183261871e-01
    z[6,5,0]  R2287     -7.7118612825870514e-02
    z[6,5,0]  R2288     1.3980850577354431e-01
    z[6,5,0]  R2289     -3.9450824260711670e-01
    z[6,5,0]  R2290     -5.3267621994018555e-01
    z[6,5,0]  R2291     1.5024597942829132e-01
    z[6,5,0]  R2292     1.7440715432167053e-01
    z[6,5,0]  R2293     6.5103721618652344e-01
    z[6,5,0]  R2294     1.6288323327898979e-02
    z[6,5,0]  R2295     -3.3365017175674438e-01
    z[6,5,0]  R2296     -5.9681493043899536e-01
    z[6,5,0]  R2297     -4.3888008594512939e-01
    z[6,5,0]  R2298     3.3577498793601990e-01
    z[6,5,0]  R2299     4.0972787141799927e-01
    z[6,5,0]  R2300     1.8252097070217133e-01
    z[6,5,0]  R2301     9.0965494513511658e-02
    z[6,5,0]  R2302     -5.5656415224075317e-01
    z[6,5,0]  R2303     -3.1916010379791260e-01
    z[6,5,0]  R2304     -8.7184444069862366e-02
    z[6,5,0]  R2305     -4.1862553358078003e-01
    z[6,5,0]  R2306     -6.4222311973571777e-01
    z[6,5,0]  R2307     6.0630504041910172e-02
    z[6,5,0]  R2308     -4.8078897595405579e-01
    z[6,5,0]  R2309     -4.2030301690101624e-01
    z[6,5,0]  R2310     0.355146199464798
    z[6,5,0]  R2311     2.7121397852897644e-01
    z[6,5,0]  R2312     4.7907616943120956e-02
    z[6,5,0]  R2313     1.3716715574264526e-01
    z[6,5,0]  R2314     -4.7560158371925354e-01
    z[6,5,0]  R2315     -6.0663259029388428e-01
    z[6,5,0]  R2316     2.3190313577651978e-01
    z[6,5,0]  R2317     2.1783809363842010e-01
    z[6,5,0]  R2318     3.5618704557418823e-01
    z[6,5,0]  R2319     3.3672192692756653e-01
    z[6,5,0]  R2320     2.8452232480049133e-01
    z[6,5,0]  R2321     3.6942040920257568e-01
    z[6,5,0]  R2322     3.5282671451568604e-01
    z[6,5,0]  R2323     -4.4571959972381592e-01
    z[6,5,0]  R2324     1.0341478139162064e-01
    z[6,5,0]  R2325     3.4538006782531738e-01
    z[6,5,0]  R2326     2.1061430871486664e-01
    z[6,5,0]  R2327     1.9354499876499176e-01
    z[6,5,0]  R2328     1.7186896502971649e-01
    z[6,5,0]  R2329     -3.8703698664903641e-02
    z[6,5,0]  R2330     2.5730609893798828e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2221     -1
    z[6,5,1]  R2222     1
    z[6,5,1]  R2233     -6.8863760679960251e-03
    z[6,5,1]  R2234     5.6003773212432861e-01
    z[6,5,1]  R2235     -1.4625418186187744e-01
    z[6,5,1]  R2236     6.9248473644256592e-01
    z[6,5,1]  R2237     3.9886170625686646e-01
    z[6,5,1]  R2238     5.5988734960556030e-01
    z[6,5,1]  R2239     1.0517976433038712e-01
    z[6,5,1]  R2240     -2.9216584563255310e-01
    z[6,5,1]  R2241     -2.8257003426551819e-01
    z[6,5,1]  R2242     -1.3245357573032379e-01
    z[6,5,1]  R2243     3.8201412558555603e-01
    z[6,5,1]  R2244     3.3908998966217041e-01
    z[6,5,1]  R2245     -7.6833689212799072e-01
    z[6,5,1]  R2246     3.7499892711639404e-01
    z[6,5,1]  R2247     2.9757189750671387e-01
    z[6,5,1]  R2248     -2.0670397579669952e-01
    z[6,5,1]  R2249     -2.9394933581352234e-01
    z[6,5,1]  R2250     -1.2583871185779572e-01
    z[6,5,1]  R2251     -2.2176085412502289e-01
    z[6,5,1]  R2252     -1.3010367751121521e-01
    z[6,5,1]  R2253     7.5065529346466064e-01
    z[6,5,1]  R2254     -4.5002600550651550e-01
    z[6,5,1]  R2255     5.0673919916152954e-01
    z[6,5,1]  R2256     3.5009592771530151e-01
    z[6,5,1]  R2257     -2.4651616811752319e-01
    z[6,5,1]  R2258     3.0220919847488403e-01
    z[6,5,1]  R2259     3.0643942952156067e-01
    z[6,5,1]  R2260     -1.0024845600128174e-01
    z[6,5,1]  R2261     -2.0697984099388123e-01
    z[6,5,1]  R2262     0.4423828125
    z[6,5,1]  R2263     2.1564997732639313e-01
    z[6,5,1]  R2264     3.8733181357383728e-01
    z[6,5,1]  R2265     4.2823117971420288e-01
    z[6,5,1]  R2266     3.6220580339431763e-01
    z[6,5,1]  R2267     -6.1041563749313354e-01
    z[6,5,1]  R2268     -5.3197807073593140e-01
    z[6,5,1]  R2269     -7.1954762935638428e-01
    z[6,5,1]  R2270     -6.6901612281799316e-01
    z[6,5,1]  R2271     -5.9677267074584961e-01
    z[6,5,1]  R2272     -5.1348793506622314e-01
    z[6,5,1]  R2273     5.8343487977981567e-01
    z[6,5,1]  R2274     4.3708932399749756e-01
    z[6,5,1]  R2275     5.0127738714218140e-01
    z[6,5,1]  R2276     3.1788554787635803e-01
    z[6,5,1]  R2277     -2.6431185007095337e-01
    z[6,5,1]  R2278     6.6319274902343750e-01
    z[6,5,1]  R2279     -2.4326251447200775e-01
    z[6,5,1]  R2280     1.5771420672535896e-02
    z[6,5,1]  R2281     4.6840080618858337e-01
    z[6,5,1]  R2282     -5.3650361299514771e-01
    z[6,5,1]  R2283     4.9335613846778870e-01
    z[6,5,1]  R2284     -5.2092432975769043e-01
    z[6,5,1]  R2285     -3.1740444898605347e-01
    z[6,5,1]  R2286     -4.7887480258941650e-01
    z[6,5,1]  R2287     3.2369661331176758e-01
    z[6,5,1]  R2288     7.4469465017318726e-01
    z[6,5,1]  R2289     3.1814590096473694e-01
    z[6,5,1]  R2290     -3.7238383293151855e-01
    z[6,5,1]  R2291     -4.2741736769676208e-01
    z[6,5,1]  R2292     -3.2416197657585144e-01
    z[6,5,1]  R2293     -2.1738414466381073e-01
    z[6,5,1]  R2294     -1.8900883197784424e-01
    z[6,5,1]  R2295     3.3727544546127319e-01
    z[6,5,1]  R2296     9.7226023674011230e-02
    z[6,5,1]  R2297     -7.2843387722969055e-02
    z[6,5,1]  R2298     6.4356744289398193e-01
    z[6,5,1]  R2299     7.6706510782241821e-01
    z[6,5,1]  R2300     6.5957701206207275e-01
    z[6,5,1]  R2301     -5.0450706481933594e-01
    z[6,5,1]  R2302     5.6698240339756012e-02
    z[6,5,1]  R2303     4.8791885375976562e-02
    z[6,5,1]  R2304     -1.3757948577404022e-01
    z[6,5,1]  R2305     3.7401422858238220e-01
    z[6,5,1]  R2306     1.1739350110292435e-01
    z[6,5,1]  R2307     2.3625028133392334e-01
    z[6,5,1]  R2308     1.8291552364826202e-01
    z[6,5,1]  R2309     4.8557594418525696e-02
    z[6,5,1]  R2310     7.9516094923019409e-01
    z[6,5,1]  R2311     -1.7780935764312744e-01
    z[6,5,1]  R2312     -2.0906296372413635e-01
    z[6,5,1]  R2313     -3.6919206380844116e-01
    z[6,5,1]  R2314     3.8943886756896973e-01
    z[6,5,1]  R2315     2.8447780013084412e-01
    z[6,5,1]  R2316     8.3946412801742554e-01
    z[6,5,1]  R2317     0.894114077091217
    z[6,5,1]  R2318     7.2143363952636719e-01
    z[6,5,1]  R2319     6.5222895145416260e-01
    z[6,5,1]  R2320     6.5590417385101318e-01
    z[6,5,1]  R2321     -5.3437268733978271e-01
    z[6,5,1]  R2322     -1.7508365213871002e-01
    z[6,5,1]  R2323     1.9357708096504211e-01
    z[6,5,1]  R2324     7.8060162067413330e-01
    z[6,5,1]  R2325     0.706145167350769
    z[6,5,1]  R2326     3.6584153771400452e-01
    z[6,5,1]  R2327     3.0645939707756042e-01
    z[6,5,1]  R2328     3.1118473410606384e-01
    z[6,5,1]  R2329     1.4049403369426727e-01
    z[6,5,1]  R2330     4.9242043495178223e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2223     -1
    z[6,5,2]  R2224     1
    z[6,5,2]  R2233     4.7511968016624451e-01
    z[6,5,2]  R2234     -2.9498362541198730e-01
    z[6,5,2]  R2235     9.4056320190429688e-01
    z[6,5,2]  R2236     -2.1618528664112091e-01
    z[6,5,2]  R2237     -4.4302487373352051e-01
    z[6,5,2]  R2238     -2.6129558682441711e-01
    z[6,5,2]  R2239     -4.5782196521759033e-01
    z[6,5,2]  R2240     -0.60861736536026
    z[6,5,2]  R2241     -0.651661217212677
    z[6,5,2]  R2242     5.7883709669113159e-01
    z[6,5,2]  R2243     -6.7905426025390625e-01
    z[6,5,2]  R2244     -2.1646840870380402e-01
    z[6,5,2]  R2245     0.572898805141449
    z[6,5,2]  R2246     -3.7956693768501282e-01
    z[6,5,2]  R2247     -3.0350151658058167e-01
    z[6,5,2]  R2248     1.7284838855266571e-01
    z[6,5,2]  R2249     0.508536696434021
    z[6,5,2]  R2250     -2.6058253645896912e-01
    z[6,5,2]  R2251     3.9446863532066345e-01
    z[6,5,2]  R2252     -3.0458378791809082e-01
    z[6,5,2]  R2253     -4.2649102210998535e-01
    z[6,5,2]  R2254     2.5434204936027527e-01
    z[6,5,2]  R2255     -1.4129005372524261e-01
    z[6,5,2]  R2256     -3.8931033015251160e-01
    z[6,5,2]  R2257     4.5407322049140930e-01
    z[6,5,2]  R2258     -6.0657691955566406e-01
    z[6,5,2]  R2259     -2.8872179985046387e-01
    z[6,5,2]  R2260     -3.6127230525016785e-01
    z[6,5,2]  R2261     4.4500410556793213e-01
    z[6,5,2]  R2262     -2.3062816262245178e-01
    z[6,5,2]  R2263     -3.6736661195755005e-01
    z[6,5,2]  R2264     -5.2608931064605713e-01
    z[6,5,2]  R2265     -3.2370918989181519e-01
    z[6,5,2]  R2266     9.6486732363700867e-02
    z[6,5,2]  R2267     4.9646192789077759e-01
    z[6,5,2]  R2268     4.8926532268524170e-01
    z[6,5,2]  R2269     4.4028982520103455e-01
    z[6,5,2]  R2270     1.7534171044826508e-01
    z[6,5,2]  R2271     2.3417973518371582e-01
    z[6,5,2]  R2272     1.1144289374351501e-01
    z[6,5,2]  R2273     -3.2406392693519592e-01
    z[6,5,2]  R2274     -5.0877904891967773e-01
    z[6,5,2]  R2275     -1.6972798109054565e-01
    z[6,5,2]  R2276     -3.3042725920677185e-01
    z[6,5,2]  R2277     2.9166355729103088e-01
    z[6,5,2]  R2278     -1.6853570938110352e-01
    z[6,5,2]  R2279     3.0091315507888794e-01
    z[6,5,2]  R2280     4.2526204138994217e-02
    z[6,5,2]  R2281     1.0257680714130402e-01
    z[6,5,2]  R2282     4.3797358870506287e-01
    z[6,5,2]  R2283     -4.6858462691307068e-01
    z[6,5,2]  R2284     1.6033723950386047e-01
    z[6,5,2]  R2285     3.6763134598731995e-01
    z[6,5,2]  R2286     2.9411950707435608e-01
    z[6,5,2]  R2287     -2.0330508053302765e-01
    z[6,5,2]  R2288     0.450483113527298
    z[6,5,2]  R2289     6.3353300094604492e-01
    z[6,5,2]  R2290     4.7934162616729736e-01
    z[6,5,2]  R2291     4.2288044095039368e-01
    z[6,5,2]  R2292     7.7174264192581177e-01
    z[6,5,2]  R2293     0.0368468351662159
    z[6,5,2]  R2294     7.5390481948852539e-01
    z[6,5,2]  R2295     3.0433061718940735e-01
    z[6,5,2]  R2296     5.9244847297668457e-01
    z[6,5,2]  R2297     4.0476010181009769e-03
    z[6,5,2]  R2298     -9.3448825180530548e-02
    z[6,5,2]  R2299     2.7863787487149239e-02
    z[6,5,2]  R2300     1.8628510832786560e-01
    z[6,5,2]  R2301     3.7412515282630920e-01
    z[6,5,2]  R2302     7.2498425841331482e-02
    z[6,5,2]  R2303     -2.7489945292472839e-01
    z[6,5,2]  R2304     7.8560537099838257e-01
    z[6,5,2]  R2305     4.5996546745300293e-01
    z[6,5,2]  R2306     5.5690473318099976e-01
    z[6,5,2]  R2307     -6.1309903860092163e-01
    z[6,5,2]  R2308     2.0956581830978394e-01
    z[6,5,2]  R2309     1.0263431817293167e-01
    z[6,5,2]  R2310     1.1223587393760681e-01
    z[6,5,2]  R2311     3.2272240519523621e-01
    z[6,5,2]  R2312     7.7449077367782593e-01
    z[6,5,2]  R2313     -3.1922541558742523e-02
    z[6,5,2]  R2314     3.7960460782051086e-01
    z[6,5,2]  R2315     0.566888689994812
    z[6,5,2]  R2316     1.9992722570896149e-01
    z[6,5,2]  R2317     2.5040122866630554e-01
    z[6,5,2]  R2318     -1.5434475243091583e-01
    z[6,5,2]  R2319     5.5092971771955490e-02
    z[6,5,2]  R2320     6.4093485474586487e-02
    z[6,5,2]  R2321     3.9169132709503174e-01
    z[6,5,2]  R2322     4.8306062817573547e-01
    z[6,5,2]  R2323     1.1360051482915878e-01
    z[6,5,2]  R2324     3.5109764337539673e-01
    z[6,5,2]  R2325     -1.8109707534313202e-01
    z[6,5,2]  R2326     7.0444536395370960e-03
    z[6,5,2]  R2327     -1.0378784686326981e-01
    z[6,5,2]  R2328     -3.2495737075805664e-01
    z[6,5,2]  R2329     -1.4832274615764618e-01
    z[6,5,2]  R2330     -1.1233911663293839e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2225     -1
    z[6,5,3]  R2226     1
    z[6,5,3]  R2233     2.1513253450393677e-01
    z[6,5,3]  R2234     4.1307443380355835e-01
    z[6,5,3]  R2235     9.2487454414367676e-02
    z[6,5,3]  R2236     2.8184279799461365e-01
    z[6,5,3]  R2237     2.4462194740772247e-01
    z[6,5,3]  R2238     -4.2428457736968994e-01
    z[6,5,3]  R2239     2.8683164715766907e-01
    z[6,5,3]  R2240     5.8566696941852570e-02
    z[6,5,3]  R2241     -7.3858529329299927e-02
    z[6,5,3]  R2242     -9.7937986254692078e-02
    z[6,5,3]  R2243     7.9831499606370926e-03
    z[6,5,3]  R2244     1.7509230971336365e-01
    z[6,5,3]  R2245     4.2215961962938309e-02
    z[6,5,3]  R2246     -6.5733693540096283e-02
    z[6,5,3]  R2247     -6.8958718329668045e-03
    z[6,5,3]  R2248     -9.3161761760711670e-03
    z[6,5,3]  R2249     -5.9417265653610229e-01
    z[6,5,3]  R2250     3.0213648080825806e-01
    z[6,5,3]  R2251     -5.0230938196182251e-01
    z[6,5,3]  R2252     9.0317547321319580e-01
    z[6,5,3]  R2253     1.5011011064052582e-01
    z[6,5,3]  R2254     6.5144568681716919e-01
    z[6,5,3]  R2255     4.3764621019363403e-01
    z[6,5,3]  R2256     5.6495642662048340e-01
    z[6,5,3]  R2257     3.0804595351219177e-01
    z[6,5,3]  R2258     5.1600122451782227e-01
    z[6,5,3]  R2259     1.2161944806575775e-01
    z[6,5,3]  R2260     6.4246350526809692e-01
    z[6,5,3]  R2261     -3.2450112700462341e-01
    z[6,5,3]  R2262     2.9475349187850952e-01
    z[6,5,3]  R2263     8.0075448751449585e-01
    z[6,5,3]  R2264     1.4355318248271942e-01
    z[6,5,3]  R2265     -1.0965181142091751e-01
    z[6,5,3]  R2266     4.7584244608879089e-01
    z[6,5,3]  R2267     -4.6038556098937988e-01
    z[6,5,3]  R2268     -0.3236083984375
    z[6,5,3]  R2269     -2.0194093883037567e-01
    z[6,5,3]  R2270     -2.8639006614685059e-01
    z[6,5,3]  R2271     -5.2986311912536621e-01
    z[6,5,3]  R2272     -5.5533796548843384e-01
    z[6,5,3]  R2273     5.0833827257156372e-01
    z[6,5,3]  R2274     3.2436171174049377e-01
    z[6,5,3]  R2275     2.4476137757301331e-01
    z[6,5,3]  R2276     7.0018047094345093e-01
    z[6,5,3]  R2277     -2.7334091067314148e-01
    z[6,5,3]  R2278     -2.3013319075107574e-01
    z[6,5,3]  R2279     0.042548768222332
    z[6,5,3]  R2280     -8.6475081741809845e-02
    z[6,5,3]  R2281     1.9139336422085762e-02
    z[6,5,3]  R2282     4.4826313853263855e-01
    z[6,5,3]  R2283     0.0741507038474083
    z[6,5,3]  R2284     -3.5644143819808960e-02
    z[6,5,3]  R2285     -1.9135881960391998e-01
    z[6,5,3]  R2286     5.6048100814223289e-03
    z[6,5,3]  R2287     -6.7439842224121094e-01
    z[6,5,3]  R2288     3.2411301136016846e-01
    z[6,5,3]  R2289     -4.6218031644821167e-01
    z[6,5,3]  R2290     1.8789154291152954e-01
    z[6,5,3]  R2291     2.1419529616832733e-01
    z[6,5,3]  R2292     4.3450275063514709e-01
    z[6,5,3]  R2293     -3.3244210481643677e-01
    z[6,5,3]  R2294     1.4798830263316631e-02
    z[6,5,3]  R2295     -5.7175344228744507e-01
    z[6,5,3]  R2296     -5.0337541103363037e-01
    z[6,5,3]  R2297     -4.3989843130111694e-01
    z[6,5,3]  R2298     5.6945568323135376e-01
    z[6,5,3]  R2299     3.1394094228744507e-01
    z[6,5,3]  R2300     5.4297178983688354e-01
    z[6,5,3]  R2301     7.8871408477425575e-03
    z[6,5,3]  R2302     -5.3595298528671265e-01
    z[6,5,3]  R2303     -7.5749266147613525e-01
    z[6,5,3]  R2304     -5.6745105981826782e-01
    z[6,5,3]  R2305     -3.8951399922370911e-01
    z[6,5,3]  R2306     -4.8240518569946289e-01
    z[6,5,3]  R2307     -5.1529681682586670e-01
    z[6,5,3]  R2308     -5.2376532554626465e-01
    z[6,5,3]  R2309     -6.9816923141479492e-01
    z[6,5,3]  R2310     4.0796205401420593e-01
    z[6,5,3]  R2311     -2.9315567016601562e-01
    z[6,5,3]  R2312     -5.8616679906845093e-01
    z[6,5,3]  R2313     -5.9187036752700806e-01
    z[6,5,3]  R2314     -2.2168566286563873e-01
    z[6,5,3]  R2315     -1.7261917889118195e-01
    z[6,5,3]  R2316     3.3974161744117737e-01
    z[6,5,3]  R2317     1.9725590944290161e-01
    z[6,5,3]  R2318     4.6568682789802551e-01
    z[6,5,3]  R2319     5.7034349441528320e-01
    z[6,5,3]  R2320     4.6530708670616150e-01
    z[6,5,3]  R2321     5.3525015711784363e-02
    z[6,5,3]  R2322     -5.4226624965667725e-01
    z[6,5,3]  R2323     -8.3188682794570923e-01
    z[6,5,3]  R2324     4.4643855094909668e-01
    z[6,5,3]  R2325     3.2516720890998840e-01
    z[6,5,3]  R2326     8.6171567440032959e-01
    z[6,5,3]  R2327     9.1848051548004150e-01
    z[6,5,3]  R2328     2.0819117128849030e-01
    z[6,5,3]  R2329     5.4480707645416260e-01
    z[6,5,3]  R2330     0.648116409778595
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2227     -1
    z[6,5,4]  R2228     1
    z[6,5,4]  R2233     2.3307062685489655e-01
    z[6,5,4]  R2234     2.5533128529787064e-02
    z[6,5,4]  R2235     2.7801211923360825e-02
    z[6,5,4]  R2236     -2.5979182124137878e-01
    z[6,5,4]  R2237     6.5709066390991211e-01
    z[6,5,4]  R2238     2.2197322547435760e-01
    z[6,5,4]  R2239     4.7340080142021179e-01
    z[6,5,4]  R2240     -2.6889607310295105e-02
    z[6,5,4]  R2241     -3.4498524665832520e-01
    z[6,5,4]  R2242     3.8552662730216980e-01
    z[6,5,4]  R2243     -4.2029681801795959e-01
    z[6,5,4]  R2244     4.5138096809387207e-01
    z[6,5,4]  R2245     1.0632122308015823e-01
    z[6,5,4]  R2246     -6.3010370731353760e-01
    z[6,5,4]  R2247     -0.851609468460083
    z[6,5,4]  R2248     1.2785906903445721e-02
    z[6,5,4]  R2249     1.0424222797155380e-01
    z[6,5,4]  R2250     -7.7600908279418945e-01
    z[6,5,4]  R2251     4.1884702444076538e-01
    z[6,5,4]  R2252     1.0178020223975182e-02
    z[6,5,4]  R2253     3.7334653735160828e-01
    z[6,5,4]  R2254     3.4768790006637573e-01
    z[6,5,4]  R2255     2.7879342436790466e-01
    z[6,5,4]  R2256     -5.8211672306060791e-01
    z[6,5,4]  R2257     -2.4894128739833832e-01
    z[6,5,4]  R2258     -1.0453967005014420e-01
    z[6,5,4]  R2259     -6.4241182804107666e-01
    z[6,5,4]  R2260     -4.8757123947143555e-01
    z[6,5,4]  R2261     -4.2702168226242065e-01
    z[6,5,4]  R2262     -3.4983408451080322e-01
    z[6,5,4]  R2263     -1.3893342018127441e-01
    z[6,5,4]  R2264     -2.7974995970726013e-01
    z[6,5,4]  R2265     -8.1697374582290649e-01
    z[6,5,4]  R2266     5.1591273397207260e-02
    z[6,5,4]  R2267     2.1880412101745605e-01
    z[6,5,4]  R2268     4.7620871663093567e-01
    z[6,5,4]  R2269     3.9910537004470825e-01
    z[6,5,4]  R2270     2.8587529063224792e-01
    z[6,5,4]  R2271     -2.2865609824657440e-01
    z[6,5,4]  R2272     9.1808803379535675e-02
    z[6,5,4]  R2273     4.6441745758056641e-01
    z[6,5,4]  R2274     -2.8656238317489624e-01
    z[6,5,4]  R2275     3.5038910806179047e-02
    z[6,5,4]  R2276     -8.6673960089683533e-02
    z[6,5,4]  R2277     -1.1518691480159760e-01
    z[6,5,4]  R2278     -3.9452469348907471e-01
    z[6,5,4]  R2279     3.6958824843168259e-02
    z[6,5,4]  R2280     4.2782264947891235e-01
    z[6,5,4]  R2281     -4.7407191991806030e-01
    z[6,5,4]  R2282     -3.2385182380676270e-01
    z[6,5,4]  R2283     -5.0201267004013062e-02
    z[6,5,4]  R2284     2.0140080153942108e-01
    z[6,5,4]  R2285     -1.2708598375320435e-01
    z[6,5,4]  R2286     7.1005290746688843e-01
    z[6,5,4]  R2287     -1.5742965042591095e-01
    z[6,5,4]  R2288     -1.4207400381565094e-01
    z[6,5,4]  R2289     9.2905789613723755e-02
    z[6,5,4]  R2290     -1.1216209828853607e-01
    z[6,5,4]  R2291     6.4459383487701416e-02
    z[6,5,4]  R2292     0.129435732960701
    z[6,5,4]  R2293     -4.1458931565284729e-01
    z[6,5,4]  R2294     -1.4615179598331451e-01
    z[6,5,4]  R2295     -1.0555419325828552e-01
    z[6,5,4]  R2296     1.5200559794902802e-01
    z[6,5,4]  R2297     5.8861184120178223e-01
    z[6,5,4]  R2298     3.7204778194427490e-01
    z[6,5,4]  R2299     -2.9196339845657349e-01
    z[6,5,4]  R2300     2.4302378296852112e-02
    z[6,5,4]  R2301     4.9243906140327454e-01
    z[6,5,4]  R2302     5.1775109767913818e-01
    z[6,5,4]  R2303     3.5475182533264160e-01
    z[6,5,4]  R2304     -6.6218726336956024e-02
    z[6,5,4]  R2305     -4.8138126730918884e-01
    z[6,5,4]  R2306     6.9008268415927887e-02
    z[6,5,4]  R2307     -2.0882911980152130e-02
    z[6,5,4]  R2308     -3.0655593145638704e-03
    z[6,5,4]  R2309     9.0737171471118927e-02
    z[6,5,4]  R2310     2.3281882703304291e-01
    z[6,5,4]  R2311     -3.2913425564765930e-01
    z[6,5,4]  R2312     -1.9677041098475456e-02
    z[6,5,4]  R2313     3.1881293654441833e-01
    z[6,5,4]  R2314     -1.6965357959270477e-01
    z[6,5,4]  R2315     -1.7790514230728149e-01
    z[6,5,4]  R2316     -1.6859249770641327e-01
    z[6,5,4]  R2317     4.3431546539068222e-02
    z[6,5,4]  R2318     -1.0452105849981308e-01
    z[6,5,4]  R2319     -2.2325780242681503e-02
    z[6,5,4]  R2320     -3.5965809226036072e-01
    z[6,5,4]  R2321     0.268614798784256
    z[6,5,4]  R2322     -3.6467319726943970e-01
    z[6,5,4]  R2323     -3.9487909525632858e-02
    z[6,5,4]  R2324     8.6490392684936523e-02
    z[6,5,4]  R2325     3.3647322654724121e-01
    z[6,5,4]  R2326     1.6580912470817566e-01
    z[6,5,4]  R2327     -1.1505384743213654e-01
    z[6,5,4]  R2328     -5.4393541812896729e-01
    z[6,5,4]  R2329     0.0495305210351944
    z[6,5,4]  R2330     -1.7865665256977081e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2229     -1
    z[6,5,5]  R2230     1
    z[6,5,5]  R2233     -2.4626553058624268e-01
    z[6,5,5]  R2234     3.9973545819520950e-02
    z[6,5,5]  R2235     1.8533450365066528e-01
    z[6,5,5]  R2236     2.9870948195457458e-01
    z[6,5,5]  R2237     -1.1307615786790848e-01
    z[6,5,5]  R2238     5.5027270317077637e-01
    z[6,5,5]  R2239     0.598588764667511
    z[6,5,5]  R2240     1.6931708157062531e-01
    z[6,5,5]  R2241     1.1876410990953445e-01
    z[6,5,5]  R2242     -1.1166165024042130e-01
    z[6,5,5]  R2243     1.9647181034088135e-01
    z[6,5,5]  R2244     6.0314178466796875e-01
    z[6,5,5]  R2245     -1.6237659752368927e-01
    z[6,5,5]  R2246     -4.7565874457359314e-01
    z[6,5,5]  R2247     -2.9490628838539124e-01
    z[6,5,5]  R2248     -7.6681065559387207e-01
    z[6,5,5]  R2249     -5.1645308732986450e-01
    z[6,5,5]  R2250     3.8237437605857849e-01
    z[6,5,5]  R2251     -3.2025906443595886e-01
    z[6,5,5]  R2252     -1.2556119263172150e-01
    z[6,5,5]  R2253     -1.8859510123729706e-01
    z[6,5,5]  R2254     -2.1523422002792358e-01
    z[6,5,5]  R2255     -5.9475260972976685e-01
    z[6,5,5]  R2256     -1.0085628181695938e-01
    z[6,5,5]  R2257     -3.0298787355422974e-01
    z[6,5,5]  R2258     -2.4765150249004364e-01
    z[6,5,5]  R2259     4.7999256849288940e-01
    z[6,5,5]  R2260     4.4700637459754944e-01
    z[6,5,5]  R2261     -6.5264725685119629e-01
    z[6,5,5]  R2262     -4.7134715318679810e-01
    z[6,5,5]  R2263     -3.5447177290916443e-01
    z[6,5,5]  R2264     6.7346090078353882e-01
    z[6,5,5]  R2265     -1.6537380218505859e-01
    z[6,5,5]  R2266     3.0855366960167885e-02
    z[6,5,5]  R2267     -2.0155285298824310e-01
    z[6,5,5]  R2268     -1.2042575329542160e-01
    z[6,5,5]  R2269     2.4261063337326050e-01
    z[6,5,5]  R2270     3.4163564443588257e-01
    z[6,5,5]  R2271     1.0395988821983337e-01
    z[6,5,5]  R2272     -2.8603386133909225e-02
    z[6,5,5]  R2273     1.1940021067857742e-01
    z[6,5,5]  R2274     5.5837196111679077e-01
    z[6,5,5]  R2275     2.7310207486152649e-01
    z[6,5,5]  R2276     3.7988269329071045e-01
    z[6,5,5]  R2277     -6.8950974941253662e-01
    z[6,5,5]  R2278     1.4357882738113403e-01
    z[6,5,5]  R2279     -8.6851459741592407e-01
    z[6,5,5]  R2280     -7.1773386001586914e-01
    z[6,5,5]  R2281     -4.0822815895080566e-01
    z[6,5,5]  R2282     -3.4957060217857361e-01
    z[6,5,5]  R2283     -7.6874576508998871e-02
    z[6,5,5]  R2284     3.5730041563510895e-03
    z[6,5,5]  R2285     -1.6611084342002869e-01
    z[6,5,5]  R2286     -2.1292728185653687e-01
    z[6,5,5]  R2287     6.0546815395355225e-01
    z[6,5,5]  R2288     -3.1042459607124329e-01
    z[6,5,5]  R2289     1.9761377573013306e-01
    z[6,5,5]  R2290     5.4740697145462036e-01
    z[6,5,5]  R2291     -6.2707710266113281e-01
    z[6,5,5]  R2292     -5.8926129713654518e-03
    z[6,5,5]  R2293     -4.0352556109428406e-01
    z[6,5,5]  R2294     3.0668142437934875e-01
    z[6,5,5]  R2295     3.7205097079277039e-01
    z[6,5,5]  R2296     8.2550808787345886e-02
    z[6,5,5]  R2297     0.428880512714386
    z[6,5,5]  R2298     -2.5570359081029892e-02
    z[6,5,5]  R2299     -7.0960409939289093e-02
    z[6,5,5]  R2300     4.1393381357192993e-01
    z[6,5,5]  R2301     1.8796385824680328e-01
    z[6,5,5]  R2302     3.5510486364364624e-01
    z[6,5,5]  R2303     -3.2259428501129150e-01
    z[6,5,5]  R2304     -1.4974993467330933e-01
    z[6,5,5]  R2305     2.4394790828227997e-01
    z[6,5,5]  R2306     -6.0236491262912750e-02
    z[6,5,5]  R2307     0.537821888923645
    z[6,5,5]  R2308     4.4306963682174683e-01
    z[6,5,5]  R2309     2.6599545031785965e-02
    z[6,5,5]  R2310     -5.4927755147218704e-02
    z[6,5,5]  R2311     -7.6165050268173218e-01
    z[6,5,5]  R2312     -4.7618150711059570e-02
    z[6,5,5]  R2313     -2.2291608154773712e-01
    z[6,5,5]  R2314     5.9336161613464355e-01
    z[6,5,5]  R2315     3.7358757853507996e-01
    z[6,5,5]  R2316     2.0678481459617615e-01
    z[6,5,5]  R2317     1.5632654726505280e-01
    z[6,5,5]  R2318     1.7294344305992126e-01
    z[6,5,5]  R2319     -1.2472229450941086e-01
    z[6,5,5]  R2320     -1.3050112128257751e-01
    z[6,5,5]  R2321     1.4924408495426178e-01
    z[6,5,5]  R2322     -6.4426816999912262e-02
    z[6,5,5]  R2323     -7.1667745709419250e-02
    z[6,5,5]  R2324     -9.7219776362180710e-03
    z[6,5,5]  R2325     3.5702455043792725e-01
    z[6,5,5]  R2326     3.7620570510625839e-02
    z[6,5,5]  R2327     -1.9718091934919357e-02
    z[6,5,5]  R2328     5.7228130102157593e-01
    z[6,5,5]  R2329     8.1076073646545410e-01
    z[6,5,5]  R2330     2.4047380685806274e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2231     -1
    z[6,5,6]  R2232     1
    z[6,5,6]  R2233     -1.0658331215381622e-01
    z[6,5,6]  R2234     -5.4275143146514893e-01
    z[6,5,6]  R2235     -2.7151120826601982e-02
    z[6,5,6]  R2236     -1.1578156799077988e-01
    z[6,5,6]  R2237     -1.1442054808139801e-01
    z[6,5,6]  R2238     -1.7906531691551208e-01
    z[6,5,6]  R2239     -2.6253458857536316e-01
    z[6,5,6]  R2240     4.4720619916915894e-02
    z[6,5,6]  R2241     -1.6000309586524963e-01
    z[6,5,6]  R2242     -4.8164242506027222e-01
    z[6,5,6]  R2243     2.2473609447479248e-01
    z[6,5,6]  R2244     4.2333155870437622e-01
    z[6,5,6]  R2245     -2.0236971974372864e-01
    z[6,5,6]  R2246     1.4084529876708984e-01
    z[6,5,6]  R2247     -7.7263832092285156e-02
    z[6,5,6]  R2248     4.2872640490531921e-01
    z[6,5,6]  R2249     -9.9274218082427979e-02
    z[6,5,6]  R2250     2.7316457033157349e-01
    z[6,5,6]  R2251     -4.9892616271972656e-01
    z[6,5,6]  R2252     6.2569208443164825e-02
    z[6,5,6]  R2253     2.3796525597572327e-01
    z[6,5,6]  R2254     3.7250757217407227e-01
    z[6,5,6]  R2255     3.0913466215133667e-01
    z[6,5,6]  R2256     1.9563171267509460e-01
    z[6,5,6]  R2257     6.9594025611877441e-01
    z[6,5,6]  R2258     1.3218365609645844e-01
    z[6,5,6]  R2259     1.8184454739093781e-01
    z[6,5,6]  R2260     8.7099619209766388e-02
    z[6,5,6]  R2261     2.0823296904563904e-01
    z[6,5,6]  R2262     5.6346309185028076e-01
    z[6,5,6]  R2263     -1.5698574483394623e-01
    z[6,5,6]  R2264     -4.0741167962551117e-02
    z[6,5,6]  R2265     2.3560726549476385e-03
    z[6,5,6]  R2266     4.6683105826377869e-01
    z[6,5,6]  R2267     -1.2588398158550262e-01
    z[6,5,6]  R2268     3.0378827452659607e-01
    z[6,5,6]  R2269     4.3183397501707077e-02
    z[6,5,6]  R2270     2.0672650635242462e-01
    z[6,5,6]  R2271     3.1636545062065125e-01
    z[6,5,6]  R2272     1.3195750117301941e-01
    z[6,5,6]  R2273     -1.0134275071322918e-03
    z[6,5,6]  R2274     -3.9759213104844093e-03
    z[6,5,6]  R2275     6.3265162706375122e-01
    z[6,5,6]  R2276     1.5392234921455383e-01
    z[6,5,6]  R2277     -0.468349426984787
    z[6,5,6]  R2278     2.8352162241935730e-01
    z[6,5,6]  R2279     1.4427970349788666e-01
    z[6,5,6]  R2280     2.6423105597496033e-01
    z[6,5,6]  R2281     0.365264356136322
    z[6,5,6]  R2282     -2.2439448535442352e-01
    z[6,5,6]  R2283     -2.6419568806886673e-02
    z[6,5,6]  R2284     -1.1189787089824677e-01
    z[6,5,6]  R2285     -3.8691911101341248e-01
    z[6,5,6]  R2286     -3.4885451197624207e-01
    z[6,5,6]  R2287     -4.1847601532936096e-02
    z[6,5,6]  R2288     3.6751903593540192e-02
    z[6,5,6]  R2289     -2.8370583057403564e-01
    z[6,5,6]  R2290     1.6733314841985703e-02
    z[6,5,6]  R2291     4.1551443934440613e-01
    z[6,5,6]  R2292     -2.5166139006614685e-01
    z[6,5,6]  R2293     0.286883145570755
    z[6,5,6]  R2294     5.2915501594543457e-01
    z[6,5,6]  R2295     -4.5369610190391541e-01
    z[6,5,6]  R2296     7.5325523503124714e-03
    z[6,5,6]  R2297     2.7955085039138794e-01
    z[6,5,6]  R2298     3.1469553709030151e-02
    z[6,5,6]  R2299     2.3263911902904510e-01
    z[6,5,6]  R2300     1.7375846207141876e-01
    z[6,5,6]  R2301     0.565101146697998
    z[6,5,6]  R2302     1.8824603408575058e-02
    z[6,5,6]  R2303     -1.2835679948329926e-01
    z[6,5,6]  R2304     8.6512207984924316e-02
    z[6,5,6]  R2305     1.7417861521244049e-01
    z[6,5,6]  R2306     1.5006642043590546e-01
    z[6,5,6]  R2307     9.6953660249710083e-02
    z[6,5,6]  R2308     4.6991053223609924e-01
    z[6,5,6]  R2309     5.6042182445526123e-01
    z[6,5,6]  R2310     -7.3065526783466339e-02
    z[6,5,6]  R2311     1.2765587866306305e-01
    z[6,5,6]  R2312     8.8968977332115173e-02
    z[6,5,6]  R2313     5.8499538898468018e-01
    z[6,5,6]  R2314     -2.1917113661766052e-01
    z[6,5,6]  R2315     1.6938470304012299e-01
    z[6,5,6]  R2316     1.2223885208368301e-01
    z[6,5,6]  R2317     -1.5865561366081238e-01
    z[6,5,6]  R2318     2.6672789454460144e-01
    z[6,5,6]  R2319     3.4181100130081177e-01
    z[6,5,6]  R2320     -3.4904679656028748e-01
    z[6,5,6]  R2321     5.7206612825393677e-01
    z[6,5,6]  R2322     4.2464268207550049e-01
    z[6,5,6]  R2323     2.2852925956249237e-01
    z[6,5,6]  R2324     0.223191499710083
    z[6,5,6]  R2325     5.3487755358219147e-02
    z[6,5,6]  R2326     2.2425462305545807e-01
    z[6,5,6]  R2327     2.4868229404091835e-02
    z[6,5,6]  R2328     3.1829643249511719e-01
    z[6,5,6]  R2329     -1.2762982398271561e-02
    z[6,5,6]  R2330     -4.1096824407577515e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2331     -1
    z[6,7,0]  R2332     1
    z[6,7,0]  R2345     7.7563089132308960e-01
    z[6,7,0]  R2346     -3.6315703392028809e-01
    z[6,7,0]  R2347     2.2257076203823090e-01
    z[6,7,0]  R2348     -4.7346496582031250e-01
    z[6,7,0]  R2349     3.5658380389213562e-01
    z[6,7,0]  R2350     -2.3258747160434723e-01
    z[6,7,0]  R2351     2.1382865309715271e-01
    z[6,7,0]  R2352     7.1372449398040771e-01
    z[6,7,0]  R2353     5.7560062408447266e-01
    z[6,7,0]  R2354     -4.9470528960227966e-01
    z[6,7,0]  R2355     3.5655274987220764e-01
    z[6,7,0]  R2356     -2.4651080369949341e-01
    z[6,7,0]  R2357     3.2239560037851334e-02
    z[6,7,0]  R2358     2.6050829887390137e-01
    z[6,7,0]  R2359     3.3348988741636276e-02
    z[6,7,0]  R2360     3.9413425326347351e-01
    z[6,7,0]  R2361     1.2040492892265320e-01
    z[6,7,0]  R2362     -4.4223297387361526e-02
    z[6,7,0]  R2363     1.2639553844928741e-01
    z[6,7,0]  R2364     2.3407611250877380e-01
    z[6,7,0]  R2365     2.2489212453365326e-02
    z[6,7,0]  R2366     0.049301877617836
    z[6,7,0]  R2367     -6.8539790809154510e-02
    z[6,7,0]  R2368     -1.3925112783908844e-01
    z[6,7,0]  R2369     -0.00698230741545558
    z[6,7,0]  R2370     4.2981904745101929e-01
    z[6,7,0]  R2371     -3.6302912235260010e-01
    z[6,7,0]  R2372     -3.9324671030044556e-02
    z[6,7,0]  R2373     -4.6612534672021866e-02
    z[6,7,0]  R2374     -4.6752050518989563e-02
    z[6,7,0]  R2375     8.7930776178836823e-02
    z[6,7,0]  R2376     -1.3830077648162842e-01
    z[6,7,0]  R2377     -7.0758499205112457e-02
    z[6,7,0]  R2378     -6.4150315523147583e-01
    z[6,7,0]  R2379     2.5420022010803223e-01
    z[6,7,0]  R2380     1.9832299649715424e-01
    z[6,7,0]  R2381     1.6615045070648193e-01
    z[6,7,0]  R2382     4.4550865888595581e-01
    z[6,7,0]  R2383     3.8090556859970093e-01
    z[6,7,0]  R2384     6.2357878684997559e-01
    z[6,7,0]  R2385     -2.5736644864082336e-01
    z[6,7,0]  R2386     -2.2577261924743652e-01
    z[6,7,0]  R2387     -4.2888778448104858e-01
    z[6,7,0]  R2388     -3.5213425755500793e-01
    z[6,7,0]  R2389     2.4962651729583740e-01
    z[6,7,0]  R2390     -4.7133937478065491e-01
    z[6,7,0]  R2391     2.6826107501983643e-01
    z[6,7,0]  R2392     4.7166994214057922e-01
    z[6,7,0]  R2393     -0.494873583316803
    z[6,7,0]  R2394     -2.0486731827259064e-01
    z[6,7,0]  R2395     6.5578132867813110e-01
    z[6,7,0]  R2396     5.6253653764724731e-01
    z[6,7,0]  R2397     3.7063813209533691e-01
    z[6,7,0]  R2398     2.3754149675369263e-01
    z[6,7,0]  R2399     -0.138264000415802
    z[6,7,0]  R2400     -1.8511675298213959e-01
    z[6,7,0]  R2401     -4.6320948004722595e-01
    z[6,7,0]  R2402     -3.7512639164924622e-01
    z[6,7,0]  R2403     -4.1988947987556458e-01
    z[6,7,0]  R2404     -0.35318723320961
    z[6,7,0]  R2405     -0.421892911195755
    z[6,7,0]  R2406     -1.8761147558689117e-01
    z[6,7,0]  R2407     -5.7019978761672974e-01
    z[6,7,0]  R2408     5.4557597637176514e-01
    z[6,7,0]  R2409     4.3389233946800232e-01
    z[6,7,0]  R2410     -4.4840371608734131e-01
    z[6,7,0]  R2411     -3.5936030745506287e-01
    z[6,7,0]  R2412     -5.6440997123718262e-01
    z[6,7,0]  R2413     -6.0405993461608887e-01
    z[6,7,0]  R2414     -2.4745118618011475e-01
    z[6,7,0]  R2415     4.6661216020584106e-01
    z[6,7,0]  R2416     6.2787905335426331e-02
    z[6,7,0]  R2417     -3.2162716984748840e-01
    z[6,7,0]  R2418     4.1591387242078781e-02
    z[6,7,0]  R2419     -2.3878654837608337e-01
    z[6,7,0]  R2420     5.1987826824188232e-01
    z[6,7,0]  R2421     -2.7496299147605896e-01
    z[6,7,0]  R2422     5.0926379859447479e-02
    z[6,7,0]  R2423     -1.8982946872711182e-01
    z[6,7,0]  R2424     -2.6450318098068237e-01
    z[6,7,0]  R2425     0.367813378572464
    z[6,7,0]  R2426     5.8785051107406616e-01
    z[6,7,0]  R2427     -2.0450721681118011e-01
    z[6,7,0]  R2428     -5.3593933582305908e-01
    z[6,7,0]  R2429     -0.239603653550148
    z[6,7,0]  R2430     -1.3740982115268707e-01
    z[6,7,0]  R2431     2.0276165008544922e-01
    z[6,7,0]  R2432     -1.6038633882999420e-01
    z[6,7,0]  R2433     -1.2973412871360779e-01
    z[6,7,0]  R2434     -3.3333939313888550e-01
    z[6,7,0]  R2435     5.7482933998107910e-01
    z[6,7,0]  R2436     -3.9732262492179871e-01
    z[6,7,0]  R2437     -3.3347824215888977e-01
    z[6,7,0]  R2438     -1.0597234219312668e-01
    z[6,7,0]  R2439     -4.5789030194282532e-01
    z[6,7,0]  R2440     -1.2106350809335709e-01
    z[6,7,0]  R2441     -7.2929584980010986e-01
    z[6,7,0]  R2442     -5.4588454961776733e-01
    z[6,7,0]  R2443     -6.7704671621322632e-01
    z[6,7,0]  R2444     -4.2286023497581482e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2333     -1
    z[6,7,1]  R2334     1
    z[6,7,1]  R2345     -6.8863760679960251e-03
    z[6,7,1]  R2346     5.6003773212432861e-01
    z[6,7,1]  R2347     -1.4625418186187744e-01
    z[6,7,1]  R2348     6.9248473644256592e-01
    z[6,7,1]  R2349     3.9886170625686646e-01
    z[6,7,1]  R2350     5.5988734960556030e-01
    z[6,7,1]  R2351     1.0517976433038712e-01
    z[6,7,1]  R2352     -2.9216584563255310e-01
    z[6,7,1]  R2353     -2.8257003426551819e-01
    z[6,7,1]  R2354     -1.3245357573032379e-01
    z[6,7,1]  R2355     3.8201412558555603e-01
    z[6,7,1]  R2356     3.3908998966217041e-01
    z[6,7,1]  R2357     -7.6833689212799072e-01
    z[6,7,1]  R2358     3.7499892711639404e-01
    z[6,7,1]  R2359     2.9757189750671387e-01
    z[6,7,1]  R2360     -2.0670397579669952e-01
    z[6,7,1]  R2361     -2.9394933581352234e-01
    z[6,7,1]  R2362     -1.2583871185779572e-01
    z[6,7,1]  R2363     -2.2176085412502289e-01
    z[6,7,1]  R2364     -1.3010367751121521e-01
    z[6,7,1]  R2365     7.5065529346466064e-01
    z[6,7,1]  R2366     -4.5002600550651550e-01
    z[6,7,1]  R2367     5.0673919916152954e-01
    z[6,7,1]  R2368     3.5009592771530151e-01
    z[6,7,1]  R2369     -2.4651616811752319e-01
    z[6,7,1]  R2370     3.0220919847488403e-01
    z[6,7,1]  R2371     3.0643942952156067e-01
    z[6,7,1]  R2372     -1.0024845600128174e-01
    z[6,7,1]  R2373     -2.0697984099388123e-01
    z[6,7,1]  R2374     0.4423828125
    z[6,7,1]  R2375     2.1564997732639313e-01
    z[6,7,1]  R2376     3.8733181357383728e-01
    z[6,7,1]  R2377     4.2823117971420288e-01
    z[6,7,1]  R2378     3.6220580339431763e-01
    z[6,7,1]  R2379     -6.1041563749313354e-01
    z[6,7,1]  R2380     -5.3197807073593140e-01
    z[6,7,1]  R2381     -7.1954762935638428e-01
    z[6,7,1]  R2382     -6.6901612281799316e-01
    z[6,7,1]  R2383     -5.9677267074584961e-01
    z[6,7,1]  R2384     -5.1348793506622314e-01
    z[6,7,1]  R2385     5.8343487977981567e-01
    z[6,7,1]  R2386     4.3708932399749756e-01
    z[6,7,1]  R2387     5.0127738714218140e-01
    z[6,7,1]  R2388     3.1788554787635803e-01
    z[6,7,1]  R2389     -2.6431185007095337e-01
    z[6,7,1]  R2390     6.6319274902343750e-01
    z[6,7,1]  R2391     -2.4326251447200775e-01
    z[6,7,1]  R2392     1.5771420672535896e-02
    z[6,7,1]  R2393     4.6840080618858337e-01
    z[6,7,1]  R2394     -5.3650361299514771e-01
    z[6,7,1]  R2395     1.1435882002115250e-01
    z[6,7,1]  R2396     4.0142297744750977e-01
    z[6,7,1]  R2397     7.6485341787338257e-01
    z[6,7,1]  R2398     5.3542929887771606e-01
    z[6,7,1]  R2399     7.8002071380615234e-01
    z[6,7,1]  R2400     1.3832345604896545e-01
    z[6,7,1]  R2401     -4.7877561300992966e-02
    z[6,7,1]  R2402     -6.3829831779003143e-02
    z[6,7,1]  R2403     3.1923419237136841e-01
    z[6,7,1]  R2404     2.3087453842163086e-01
    z[6,7,1]  R2405     -2.1191075444221497e-01
    z[6,7,1]  R2406     -5.8906716108322144e-01
    z[6,7,1]  R2407     -5.2865590900182724e-02
    z[6,7,1]  R2408     -4.4142669439315796e-01
    z[6,7,1]  R2409     -7.1289384365081787e-01
    z[6,7,1]  R2410     -5.0402671098709106e-01
    z[6,7,1]  R2411     -7.4249184131622314e-01
    z[6,7,1]  R2412     -5.9427630901336670e-01
    z[6,7,1]  R2413     -4.1634941101074219e-01
    z[6,7,1]  R2414     -0.832743227481842
    z[6,7,1]  R2415     -2.4929188191890717e-01
    z[6,7,1]  R2416     1.9046372175216675e-01
    z[6,7,1]  R2417     -1.8191392719745636e-01
    z[6,7,1]  R2418     -1.6768236458301544e-01
    z[6,7,1]  R2419     -0.133817657828331
    z[6,7,1]  R2420     -1.0523710399866104e-01
    z[6,7,1]  R2421     -9.5723263919353485e-02
    z[6,7,1]  R2422     -0.186284601688385
    z[6,7,1]  R2423     -4.1939345002174377e-01
    z[6,7,1]  R2424     -3.8949453830718994e-01
    z[6,7,1]  R2425     2.4423290044069290e-02
    z[6,7,1]  R2426     -4.4574740529060364e-01
    z[6,7,1]  R2427     -4.0387764573097229e-01
    z[6,7,1]  R2428     -2.6248106360435486e-01
    z[6,7,1]  R2429     -4.1414785385131836e-01
    z[6,7,1]  R2430     -1.8218639492988586e-01
    z[6,7,1]  R2431     -1.4169288624543697e-04
    z[6,7,1]  R2432     6.4466185867786407e-02
    z[6,7,1]  R2433     -1.2670651078224182e-01
    z[6,7,1]  R2434     -1.5292043983936310e-01
    z[6,7,1]  R2435     0.437441885471344
    z[6,7,1]  R2436     -2.9498405754566193e-02
    z[6,7,1]  R2437     -2.9368460178375244e-01
    z[6,7,1]  R2438     1.3990128040313721e-01
    z[6,7,1]  R2439     -2.5596305727958679e-01
    z[6,7,1]  R2440     1.6905392706394196e-01
    z[6,7,1]  R2441     -2.0205664634704590e-01
    z[6,7,1]  R2442     4.3392226099967957e-01
    z[6,7,1]  R2443     1.8731987476348877e-01
    z[6,7,1]  R2444     4.3244999647140503e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2335     -1
    z[6,7,2]  R2336     1
    z[6,7,2]  R2345     4.7511968016624451e-01
    z[6,7,2]  R2346     -2.9498362541198730e-01
    z[6,7,2]  R2347     9.4056320190429688e-01
    z[6,7,2]  R2348     -2.1618528664112091e-01
    z[6,7,2]  R2349     -4.4302487373352051e-01
    z[6,7,2]  R2350     -2.6129558682441711e-01
    z[6,7,2]  R2351     -4.5782196521759033e-01
    z[6,7,2]  R2352     -0.60861736536026
    z[6,7,2]  R2353     -0.651661217212677
    z[6,7,2]  R2354     5.7883709669113159e-01
    z[6,7,2]  R2355     -6.7905426025390625e-01
    z[6,7,2]  R2356     -2.1646840870380402e-01
    z[6,7,2]  R2357     0.572898805141449
    z[6,7,2]  R2358     -3.7956693768501282e-01
    z[6,7,2]  R2359     -3.0350151658058167e-01
    z[6,7,2]  R2360     1.7284838855266571e-01
    z[6,7,2]  R2361     0.508536696434021
    z[6,7,2]  R2362     -2.6058253645896912e-01
    z[6,7,2]  R2363     3.9446863532066345e-01
    z[6,7,2]  R2364     -3.0458378791809082e-01
    z[6,7,2]  R2365     -4.2649102210998535e-01
    z[6,7,2]  R2366     2.5434204936027527e-01
    z[6,7,2]  R2367     -1.4129005372524261e-01
    z[6,7,2]  R2368     -3.8931033015251160e-01
    z[6,7,2]  R2369     4.5407322049140930e-01
    z[6,7,2]  R2370     -6.0657691955566406e-01
    z[6,7,2]  R2371     -2.8872179985046387e-01
    z[6,7,2]  R2372     -3.6127230525016785e-01
    z[6,7,2]  R2373     4.4500410556793213e-01
    z[6,7,2]  R2374     -2.3062816262245178e-01
    z[6,7,2]  R2375     -3.6736661195755005e-01
    z[6,7,2]  R2376     -5.2608931064605713e-01
    z[6,7,2]  R2377     -3.2370918989181519e-01
    z[6,7,2]  R2378     9.6486732363700867e-02
    z[6,7,2]  R2379     4.9646192789077759e-01
    z[6,7,2]  R2380     4.8926532268524170e-01
    z[6,7,2]  R2381     4.4028982520103455e-01
    z[6,7,2]  R2382     1.7534171044826508e-01
    z[6,7,2]  R2383     2.3417973518371582e-01
    z[6,7,2]  R2384     1.1144289374351501e-01
    z[6,7,2]  R2385     -3.2406392693519592e-01
    z[6,7,2]  R2386     -5.0877904891967773e-01
    z[6,7,2]  R2387     -1.6972798109054565e-01
    z[6,7,2]  R2388     -3.3042725920677185e-01
    z[6,7,2]  R2389     2.9166355729103088e-01
    z[6,7,2]  R2390     -1.6853570938110352e-01
    z[6,7,2]  R2391     3.0091315507888794e-01
    z[6,7,2]  R2392     4.2526204138994217e-02
    z[6,7,2]  R2393     1.0257680714130402e-01
    z[6,7,2]  R2394     4.3797358870506287e-01
    z[6,7,2]  R2395     -3.3604586124420166e-01
    z[6,7,2]  R2396     -8.9773915708065033e-02
    z[6,7,2]  R2397     -2.6283088326454163e-01
    z[6,7,2]  R2398     -2.2129869461059570e-01
    z[6,7,2]  R2399     3.8711285591125488e-01
    z[6,7,2]  R2400     7.2691243886947632e-01
    z[6,7,2]  R2401     4.8589169979095459e-01
    z[6,7,2]  R2402     7.5987368822097778e-01
    z[6,7,2]  R2403     3.2897848635911942e-02
    z[6,7,2]  R2404     -8.8280633091926575e-02
    z[6,7,2]  R2405     4.2452374100685120e-01
    z[6,7,2]  R2406     -4.1473528742790222e-01
    z[6,7,2]  R2407     4.7904092073440552e-01
    z[6,7,2]  R2408     -3.3625373244285583e-01
    z[6,7,2]  R2409     -1.5323549509048462e-01
    z[6,7,2]  R2410     -2.1477967500686646e-01
    z[6,7,2]  R2411     -4.4494945555925369e-02
    z[6,7,2]  R2412     -4.4417638331651688e-02
    z[6,7,2]  R2413     5.2536106109619141e-01
    z[6,7,2]  R2414     -3.5484644770622253e-01
    z[6,7,2]  R2415     9.7630776464939117e-02
    z[6,7,2]  R2416     4.0585052967071533e-01
    z[6,7,2]  R2417     -2.9736492037773132e-01
    z[6,7,2]  R2418     6.2986373901367188e-01
    z[6,7,2]  R2419     2.7783477306365967e-01
    z[6,7,2]  R2420     -2.5348627567291260e-01
    z[6,7,2]  R2421     7.6207816600799561e-01
    z[6,7,2]  R2422     0.831156849861145
    z[6,7,2]  R2423     6.1910808086395264e-01
    z[6,7,2]  R2424     7.5966519117355347e-01
    z[6,7,2]  R2425     3.1685021519660950e-01
    z[6,7,2]  R2426     -3.6706620454788208e-01
    z[6,7,2]  R2427     -4.2125180363655090e-01
    z[6,7,2]  R2428     5.5523318052291870e-01
    z[6,7,2]  R2429     0.807011067867279
    z[6,7,2]  R2430     8.4683841466903687e-01
    z[6,7,2]  R2431     8.7419945001602173e-01
    z[6,7,2]  R2432     9.5148253440856934e-01
    z[6,7,2]  R2433     9.5361477136611938e-01
    z[6,7,2]  R2434     8.5782015323638916e-01
    z[6,7,2]  R2435     -3.0486200004816055e-02
    z[6,7,2]  R2436     -1.1528084427118301e-01
    z[6,7,2]  R2437     7.4738597869873047e-01
    z[6,7,2]  R2438     7.1247100830078125e-01
    z[6,7,2]  R2439     3.2485216856002808e-01
    z[6,7,2]  R2440     6.8495023250579834e-01
    z[6,7,2]  R2441     1.1261721700429916e-01
    z[6,7,2]  R2442     6.6891357302665710e-02
    z[6,7,2]  R2443     9.6072681248188019e-02
    z[6,7,2]  R2444     2.4772010743618011e-02
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2337     -1
    z[6,7,3]  R2338     1
    z[6,7,3]  R2345     2.1513253450393677e-01
    z[6,7,3]  R2346     4.1307443380355835e-01
    z[6,7,3]  R2347     9.2487454414367676e-02
    z[6,7,3]  R2348     2.8184279799461365e-01
    z[6,7,3]  R2349     2.4462194740772247e-01
    z[6,7,3]  R2350     -4.2428457736968994e-01
    z[6,7,3]  R2351     2.8683164715766907e-01
    z[6,7,3]  R2352     5.8566696941852570e-02
    z[6,7,3]  R2353     -7.3858529329299927e-02
    z[6,7,3]  R2354     -9.7937986254692078e-02
    z[6,7,3]  R2355     7.9831499606370926e-03
    z[6,7,3]  R2356     1.7509230971336365e-01
    z[6,7,3]  R2357     4.2215961962938309e-02
    z[6,7,3]  R2358     -6.5733693540096283e-02
    z[6,7,3]  R2359     -6.8958718329668045e-03
    z[6,7,3]  R2360     -9.3161761760711670e-03
    z[6,7,3]  R2361     -5.9417265653610229e-01
    z[6,7,3]  R2362     3.0213648080825806e-01
    z[6,7,3]  R2363     -5.0230938196182251e-01
    z[6,7,3]  R2364     9.0317547321319580e-01
    z[6,7,3]  R2365     1.5011011064052582e-01
    z[6,7,3]  R2366     6.5144568681716919e-01
    z[6,7,3]  R2367     4.3764621019363403e-01
    z[6,7,3]  R2368     5.6495642662048340e-01
    z[6,7,3]  R2369     3.0804595351219177e-01
    z[6,7,3]  R2370     5.1600122451782227e-01
    z[6,7,3]  R2371     1.2161944806575775e-01
    z[6,7,3]  R2372     6.4246350526809692e-01
    z[6,7,3]  R2373     -3.2450112700462341e-01
    z[6,7,3]  R2374     2.9475349187850952e-01
    z[6,7,3]  R2375     8.0075448751449585e-01
    z[6,7,3]  R2376     1.4355318248271942e-01
    z[6,7,3]  R2377     -1.0965181142091751e-01
    z[6,7,3]  R2378     4.7584244608879089e-01
    z[6,7,3]  R2379     -4.6038556098937988e-01
    z[6,7,3]  R2380     -0.3236083984375
    z[6,7,3]  R2381     -2.0194093883037567e-01
    z[6,7,3]  R2382     -2.8639006614685059e-01
    z[6,7,3]  R2383     -5.2986311912536621e-01
    z[6,7,3]  R2384     -5.5533796548843384e-01
    z[6,7,3]  R2385     5.0833827257156372e-01
    z[6,7,3]  R2386     3.2436171174049377e-01
    z[6,7,3]  R2387     2.4476137757301331e-01
    z[6,7,3]  R2388     7.0018047094345093e-01
    z[6,7,3]  R2389     -2.7334091067314148e-01
    z[6,7,3]  R2390     -2.3013319075107574e-01
    z[6,7,3]  R2391     0.042548768222332
    z[6,7,3]  R2392     -8.6475081741809845e-02
    z[6,7,3]  R2393     1.9139336422085762e-02
    z[6,7,3]  R2394     4.4826313853263855e-01
    z[6,7,3]  R2395     1.7860975861549377e-01
    z[6,7,3]  R2396     3.2187944650650024e-01
    z[6,7,3]  R2397     1.0834605433046818e-02
    z[6,7,3]  R2398     3.2391202449798584e-01
    z[6,7,3]  R2399     2.0039199292659760e-01
    z[6,7,3]  R2400     1.2313036620616913e-01
    z[6,7,3]  R2401     -1.6694139689207077e-02
    z[6,7,3]  R2402     1.9584544003009796e-01
    z[6,7,3]  R2403     -7.0980352163314819e-01
    z[6,7,3]  R2404     -7.1118837594985962e-01
    z[6,7,3]  R2405     -2.2603254020214081e-01
    z[6,7,3]  R2406     -5.7955193519592285e-01
    z[6,7,3]  R2407     -1.2480422854423523e-01
    z[6,7,3]  R2408     -2.7611499652266502e-02
    z[6,7,3]  R2409     1.1606021970510483e-01
    z[6,7,3]  R2410     -0.664367139339447
    z[6,7,3]  R2411     -4.7494283318519592e-01
    z[6,7,3]  R2412     -4.8844027519226074e-01
    z[6,7,3]  R2413     -1.0250040888786316e-01
    z[6,7,3]  R2414     4.6880498528480530e-02
    z[6,7,3]  R2415     1.5337735414505005e-01
    z[6,7,3]  R2416     6.7403799295425415e-01
    z[6,7,3]  R2417     -3.1837800145149231e-01
    z[6,7,3]  R2418     -4.4210964441299438e-01
    z[6,7,3]  R2419     -3.6278063058853149e-01
    z[6,7,3]  R2420     4.9592819809913635e-01
    z[6,7,3]  R2421     1.2239511311054230e-01
    z[6,7,3]  R2422     2.6496684551239014e-01
    z[6,7,3]  R2423     0.199748694896698
    z[6,7,3]  R2424     3.2743549346923828e-01
    z[6,7,3]  R2425     7.1964037418365479e-01
    z[6,7,3]  R2426     2.1272291243076324e-01
    z[6,7,3]  R2427     -5.7984054088592529e-01
    z[6,7,3]  R2428     -4.1433432698249817e-01
    z[6,7,3]  R2429     1.1915339529514313e-01
    z[6,7,3]  R2430     -1.1254362016916275e-01
    z[6,7,3]  R2431     2.7752781286835670e-02
    z[6,7,3]  R2432     9.9605210125446320e-03
    z[6,7,3]  R2433     -1.5184667706489563e-01
    z[6,7,3]  R2434     -1.8563267588615417e-01
    z[6,7,3]  R2435     3.1545478105545044e-01
    z[6,7,3]  R2436     -2.9333594441413879e-01
    z[6,7,3]  R2437     1.9253598153591156e-01
    z[6,7,3]  R2438     -1.1768083274364471e-01
    z[6,7,3]  R2439     0.0886588916182518
    z[6,7,3]  R2440     -3.5248023271560669e-01
    z[6,7,3]  R2441     -2.3124119639396667e-01
    z[6,7,3]  R2442     -6.5944540500640869e-01
    z[6,7,3]  R2443     -6.8610537052154541e-01
    z[6,7,3]  R2444     -7.5621813535690308e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2339     -1
    z[6,7,4]  R2340     1
    z[6,7,4]  R2345     2.3307062685489655e-01
    z[6,7,4]  R2346     2.5533128529787064e-02
    z[6,7,4]  R2347     2.7801211923360825e-02
    z[6,7,4]  R2348     -2.5979182124137878e-01
    z[6,7,4]  R2349     6.5709066390991211e-01
    z[6,7,4]  R2350     2.2197322547435760e-01
    z[6,7,4]  R2351     4.7340080142021179e-01
    z[6,7,4]  R2352     -2.6889607310295105e-02
    z[6,7,4]  R2353     -3.4498524665832520e-01
    z[6,7,4]  R2354     3.8552662730216980e-01
    z[6,7,4]  R2355     -4.2029681801795959e-01
    z[6,7,4]  R2356     4.5138096809387207e-01
    z[6,7,4]  R2357     1.0632122308015823e-01
    z[6,7,4]  R2358     -6.3010370731353760e-01
    z[6,7,4]  R2359     -0.851609468460083
    z[6,7,4]  R2360     1.2785906903445721e-02
    z[6,7,4]  R2361     1.0424222797155380e-01
    z[6,7,4]  R2362     -7.7600908279418945e-01
    z[6,7,4]  R2363     4.1884702444076538e-01
    z[6,7,4]  R2364     1.0178020223975182e-02
    z[6,7,4]  R2365     3.7334653735160828e-01
    z[6,7,4]  R2366     3.4768790006637573e-01
    z[6,7,4]  R2367     2.7879342436790466e-01
    z[6,7,4]  R2368     -5.8211672306060791e-01
    z[6,7,4]  R2369     -2.4894128739833832e-01
    z[6,7,4]  R2370     -1.0453967005014420e-01
    z[6,7,4]  R2371     -6.4241182804107666e-01
    z[6,7,4]  R2372     -4.8757123947143555e-01
    z[6,7,4]  R2373     -4.2702168226242065e-01
    z[6,7,4]  R2374     -3.4983408451080322e-01
    z[6,7,4]  R2375     -1.3893342018127441e-01
    z[6,7,4]  R2376     -2.7974995970726013e-01
    z[6,7,4]  R2377     -8.1697374582290649e-01
    z[6,7,4]  R2378     5.1591273397207260e-02
    z[6,7,4]  R2379     2.1880412101745605e-01
    z[6,7,4]  R2380     4.7620871663093567e-01
    z[6,7,4]  R2381     3.9910537004470825e-01
    z[6,7,4]  R2382     2.8587529063224792e-01
    z[6,7,4]  R2383     -2.2865609824657440e-01
    z[6,7,4]  R2384     9.1808803379535675e-02
    z[6,7,4]  R2385     4.6441745758056641e-01
    z[6,7,4]  R2386     -2.8656238317489624e-01
    z[6,7,4]  R2387     3.5038910806179047e-02
    z[6,7,4]  R2388     -8.6673960089683533e-02
    z[6,7,4]  R2389     -1.1518691480159760e-01
    z[6,7,4]  R2390     -3.9452469348907471e-01
    z[6,7,4]  R2391     3.6958824843168259e-02
    z[6,7,4]  R2392     4.2782264947891235e-01
    z[6,7,4]  R2393     -4.7407191991806030e-01
    z[6,7,4]  R2394     -3.2385182380676270e-01
    z[6,7,4]  R2395     1.6010291874408722e-02
    z[6,7,4]  R2396     -1.0964769870042801e-01
    z[6,7,4]  R2397     2.1156449615955353e-01
    z[6,7,4]  R2398     0.655748188495636
    z[6,7,4]  R2399     -1.4161817729473114e-01
    z[6,7,4]  R2400     6.3251096010208130e-01
    z[6,7,4]  R2401     3.9920559525489807e-01
    z[6,7,4]  R2402     -6.1699371784925461e-02
    z[6,7,4]  R2403     3.5262140631675720e-01
    z[6,7,4]  R2404     -2.7352491393685341e-02
    z[6,7,4]  R2405     3.0771702527999878e-01
    z[6,7,4]  R2406     0.307492196559906
    z[6,7,4]  R2407     4.6538379788398743e-01
    z[6,7,4]  R2408     -2.9700118303298950e-01
    z[6,7,4]  R2409     -3.9172884821891785e-01
    z[6,7,4]  R2410     2.1518760919570923e-01
    z[6,7,4]  R2411     -1.0180468112230301e-01
    z[6,7,4]  R2412     2.2309435904026031e-01
    z[6,7,4]  R2413     -0.0850767120718956
    z[6,7,4]  R2414     -1.1955167353153229e-01
    z[6,7,4]  R2415     -8.1110924482345581e-01
    z[6,7,4]  R2416     -1.0898580402135849e-01
    z[6,7,4]  R2417     5.5226337909698486e-01
    z[6,7,4]  R2418     4.8057359457015991e-01
    z[6,7,4]  R2419     7.1364927291870117e-01
    z[6,7,4]  R2420     2.6871958374977112e-01
    z[6,7,4]  R2421     5.2876341342926025e-01
    z[6,7,4]  R2422     1.1409211903810501e-01
    z[6,7,4]  R2423     2.6202520728111267e-01
    z[6,7,4]  R2424     2.4984866380691528e-01
    z[6,7,4]  R2425     -3.6618936061859131e-01
    z[6,7,4]  R2426     -1.6661860048770905e-02
    z[6,7,4]  R2427     4.3248176574707031e-01
    z[6,7,4]  R2428     2.5308316946029663e-01
    z[6,7,4]  R2429     2.0223341882228851e-01
    z[6,7,4]  R2430     3.3913221955299377e-01
    z[6,7,4]  R2431     3.0128675699234009e-01
    z[6,7,4]  R2432     1.3564477860927582e-01
    z[6,7,4]  R2433     -2.7488607913255692e-02
    z[6,7,4]  R2434     4.8106640577316284e-02
    z[6,7,4]  R2435     -3.4481963515281677e-01
    z[6,7,4]  R2436     -2.0610374212265015e-01
    z[6,7,4]  R2437     2.7970704436302185e-01
    z[6,7,4]  R2438     5.1321285963058472e-01
    z[6,7,4]  R2439     6.8382078409194946e-01
    z[6,7,4]  R2440     7.9613149166107178e-02
    z[6,7,4]  R2441     5.0367474555969238e-01
    z[6,7,4]  R2442     -1.6412030905485153e-02
    z[6,7,4]  R2443     5.0547290593385696e-02
    z[6,7,4]  R2444     -2.2112096846103668e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2341     -1
    z[6,7,5]  R2342     1
    z[6,7,5]  R2345     -2.4626553058624268e-01
    z[6,7,5]  R2346     3.9973545819520950e-02
    z[6,7,5]  R2347     1.8533450365066528e-01
    z[6,7,5]  R2348     2.9870948195457458e-01
    z[6,7,5]  R2349     -1.1307615786790848e-01
    z[6,7,5]  R2350     5.5027270317077637e-01
    z[6,7,5]  R2351     0.598588764667511
    z[6,7,5]  R2352     1.6931708157062531e-01
    z[6,7,5]  R2353     1.1876410990953445e-01
    z[6,7,5]  R2354     -1.1166165024042130e-01
    z[6,7,5]  R2355     1.9647181034088135e-01
    z[6,7,5]  R2356     6.0314178466796875e-01
    z[6,7,5]  R2357     -1.6237659752368927e-01
    z[6,7,5]  R2358     -4.7565874457359314e-01
    z[6,7,5]  R2359     -2.9490628838539124e-01
    z[6,7,5]  R2360     -7.6681065559387207e-01
    z[6,7,5]  R2361     -5.1645308732986450e-01
    z[6,7,5]  R2362     3.8237437605857849e-01
    z[6,7,5]  R2363     -3.2025906443595886e-01
    z[6,7,5]  R2364     -1.2556119263172150e-01
    z[6,7,5]  R2365     -1.8859510123729706e-01
    z[6,7,5]  R2366     -2.1523422002792358e-01
    z[6,7,5]  R2367     -5.9475260972976685e-01
    z[6,7,5]  R2368     -1.0085628181695938e-01
    z[6,7,5]  R2369     -3.0298787355422974e-01
    z[6,7,5]  R2370     -2.4765150249004364e-01
    z[6,7,5]  R2371     4.7999256849288940e-01
    z[6,7,5]  R2372     4.4700637459754944e-01
    z[6,7,5]  R2373     -6.5264725685119629e-01
    z[6,7,5]  R2374     -4.7134715318679810e-01
    z[6,7,5]  R2375     -3.5447177290916443e-01
    z[6,7,5]  R2376     6.7346090078353882e-01
    z[6,7,5]  R2377     -1.6537380218505859e-01
    z[6,7,5]  R2378     3.0855366960167885e-02
    z[6,7,5]  R2379     -2.0155285298824310e-01
    z[6,7,5]  R2380     -1.2042575329542160e-01
    z[6,7,5]  R2381     2.4261063337326050e-01
    z[6,7,5]  R2382     3.4163564443588257e-01
    z[6,7,5]  R2383     1.0395988821983337e-01
    z[6,7,5]  R2384     -2.8603386133909225e-02
    z[6,7,5]  R2385     1.1940021067857742e-01
    z[6,7,5]  R2386     5.5837196111679077e-01
    z[6,7,5]  R2387     2.7310207486152649e-01
    z[6,7,5]  R2388     3.7988269329071045e-01
    z[6,7,5]  R2389     -6.8950974941253662e-01
    z[6,7,5]  R2390     1.4357882738113403e-01
    z[6,7,5]  R2391     -8.6851459741592407e-01
    z[6,7,5]  R2392     -7.1773386001586914e-01
    z[6,7,5]  R2393     -4.0822815895080566e-01
    z[6,7,5]  R2394     -3.4957060217857361e-01
    z[6,7,5]  R2395     6.1092805862426758e-01
    z[6,7,5]  R2396     0.305328369140625
    z[6,7,5]  R2397     -3.2644817233085632e-01
    z[6,7,5]  R2398     2.7013307809829712e-01
    z[6,7,5]  R2399     3.8586756587028503e-01
    z[6,7,5]  R2400     -1.1724155396223068e-02
    z[6,7,5]  R2401     -5.4554667323827744e-02
    z[6,7,5]  R2402     -1.7589065432548523e-01
    z[6,7,5]  R2403     7.0996925234794617e-02
    z[6,7,5]  R2404     4.9334344267845154e-01
    z[6,7,5]  R2405     -0.647737979888916
    z[6,7,5]  R2406     2.6006600819528103e-03
    z[6,7,5]  R2407     -3.1988570094108582e-01
    z[6,7,5]  R2408     -5.3647315502166748e-01
    z[6,7,5]  R2409     -3.3451077342033386e-01
    z[6,7,5]  R2410     3.8160249590873718e-02
    z[6,7,5]  R2411     0.247584730386734
    z[6,7,5]  R2412     1.7031347751617432e-01
    z[6,7,5]  R2413     -3.9729550480842590e-01
    z[6,7,5]  R2414     2.6620325446128845e-01
    z[6,7,5]  R2415     -9.6859313547611237e-02
    z[6,7,5]  R2416     3.9680776000022888e-01
    z[6,7,5]  R2417     3.8803797960281372e-01
    z[6,7,5]  R2418     -3.6811605095863342e-01
    z[6,7,5]  R2419     -4.5355820655822754e-01
    z[6,7,5]  R2420     -3.7679061293601990e-01
    z[6,7,5]  R2421     -9.9245734512805939e-02
    z[6,7,5]  R2422     -3.6069911718368530e-01
    z[6,7,5]  R2423     -4.9722501635551453e-01
    z[6,7,5]  R2424     -6.0913139022886753e-03
    z[6,7,5]  R2425     -3.0868908762931824e-01
    z[6,7,5]  R2426     -2.5204730033874512e-01
    z[6,7,5]  R2427     2.2183644771575928e-01
    z[6,7,5]  R2428     -2.9326236248016357e-01
    z[6,7,5]  R2429     -2.0866183936595917e-01
    z[6,7,5]  R2430     -9.8147220909595490e-02
    z[6,7,5]  R2431     -2.2753703594207764e-01
    z[6,7,5]  R2432     -2.1214932203292847e-01
    z[6,7,5]  R2433     -1.6605599224567413e-01
    z[6,7,5]  R2434     -1.2479253858327866e-01
    z[6,7,5]  R2435     -5.0345528125762939e-01
    z[6,7,5]  R2436     0.754705548286438
    z[6,7,5]  R2437     -2.9630449414253235e-01
    z[6,7,5]  R2438     -3.5210517048835754e-01
    z[6,7,5]  R2439     -2.0151783525943756e-01
    z[6,7,5]  R2440     -5.6089985370635986e-01
    z[6,7,5]  R2441     -1.1960883438587189e-01
    z[6,7,5]  R2442     -2.6464805006980896e-01
    z[6,7,5]  R2443     -6.1810355633497238e-02
    z[6,7,5]  R2444     -4.4104088097810745e-02
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2343     -1
    z[6,7,6]  R2344     1
    z[6,7,6]  R2345     -1.0658331215381622e-01
    z[6,7,6]  R2346     -5.4275143146514893e-01
    z[6,7,6]  R2347     -2.7151120826601982e-02
    z[6,7,6]  R2348     -1.1578156799077988e-01
    z[6,7,6]  R2349     -1.1442054808139801e-01
    z[6,7,6]  R2350     -1.7906531691551208e-01
    z[6,7,6]  R2351     -2.6253458857536316e-01
    z[6,7,6]  R2352     4.4720619916915894e-02
    z[6,7,6]  R2353     -1.6000309586524963e-01
    z[6,7,6]  R2354     -4.8164242506027222e-01
    z[6,7,6]  R2355     2.2473609447479248e-01
    z[6,7,6]  R2356     4.2333155870437622e-01
    z[6,7,6]  R2357     -2.0236971974372864e-01
    z[6,7,6]  R2358     1.4084529876708984e-01
    z[6,7,6]  R2359     -7.7263832092285156e-02
    z[6,7,6]  R2360     4.2872640490531921e-01
    z[6,7,6]  R2361     -9.9274218082427979e-02
    z[6,7,6]  R2362     2.7316457033157349e-01
    z[6,7,6]  R2363     -4.9892616271972656e-01
    z[6,7,6]  R2364     6.2569208443164825e-02
    z[6,7,6]  R2365     2.3796525597572327e-01
    z[6,7,6]  R2366     3.7250757217407227e-01
    z[6,7,6]  R2367     3.0913466215133667e-01
    z[6,7,6]  R2368     1.9563171267509460e-01
    z[6,7,6]  R2369     6.9594025611877441e-01
    z[6,7,6]  R2370     1.3218365609645844e-01
    z[6,7,6]  R2371     1.8184454739093781e-01
    z[6,7,6]  R2372     8.7099619209766388e-02
    z[6,7,6]  R2373     2.0823296904563904e-01
    z[6,7,6]  R2374     5.6346309185028076e-01
    z[6,7,6]  R2375     -1.5698574483394623e-01
    z[6,7,6]  R2376     -4.0741167962551117e-02
    z[6,7,6]  R2377     2.3560726549476385e-03
    z[6,7,6]  R2378     4.6683105826377869e-01
    z[6,7,6]  R2379     -1.2588398158550262e-01
    z[6,7,6]  R2380     3.0378827452659607e-01
    z[6,7,6]  R2381     4.3183397501707077e-02
    z[6,7,6]  R2382     2.0672650635242462e-01
    z[6,7,6]  R2383     3.1636545062065125e-01
    z[6,7,6]  R2384     1.3195750117301941e-01
    z[6,7,6]  R2385     -1.0134275071322918e-03
    z[6,7,6]  R2386     -3.9759213104844093e-03
    z[6,7,6]  R2387     6.3265162706375122e-01
    z[6,7,6]  R2388     1.5392234921455383e-01
    z[6,7,6]  R2389     -0.468349426984787
    z[6,7,6]  R2390     2.8352162241935730e-01
    z[6,7,6]  R2391     1.4427970349788666e-01
    z[6,7,6]  R2392     2.6423105597496033e-01
    z[6,7,6]  R2393     0.365264356136322
    z[6,7,6]  R2394     -2.2439448535442352e-01
    z[6,7,6]  R2395     -1.9635464251041412e-01
    z[6,7,6]  R2396     -5.5271911621093750e-01
    z[6,7,6]  R2397     -2.3895850777626038e-01
    z[6,7,6]  R2398     4.4609103351831436e-03
    z[6,7,6]  R2399     -1.1613752692937851e-01
    z[6,7,6]  R2400     -5.3179364651441574e-02
    z[6,7,6]  R2401     -6.2002742290496826e-01
    z[6,7,6]  R2402     -4.5243588089942932e-01
    z[6,7,6]  R2403     -0.295798122882843
    z[6,7,6]  R2404     -2.5345128774642944e-01
    z[6,7,6]  R2405     1.7758010327816010e-01
    z[6,7,6]  R2406     1.2392652779817581e-01
    z[6,7,6]  R2407     -3.2880410552024841e-01
    z[6,7,6]  R2408     1.3284260034561157e-01
    z[6,7,6]  R2409     -0.0349249504506588
    z[6,7,6]  R2410     -9.8057381808757782e-02
    z[6,7,6]  R2411     -1.4266440272331238e-01
    z[6,7,6]  R2412     -9.4616673886775970e-02
    z[6,7,6]  R2413     1.0085908323526382e-01
    z[6,7,6]  R2414     1.7898587882518768e-01
    z[6,7,6]  R2415     1.4067785441875458e-01
    z[6,7,6]  R2416     4.1401076316833496e-01
    z[6,7,6]  R2417     4.6701654791831970e-01
    z[6,7,6]  R2418     1.0725246369838715e-01
    z[6,7,6]  R2419     3.5518039017915726e-02
    z[6,7,6]  R2420     4.4076108932495117e-01
    z[6,7,6]  R2421     1.7334438860416412e-01
    z[6,7,6]  R2422     2.4198049306869507e-01
    z[6,7,6]  R2423     2.2133606672286987e-01
    z[6,7,6]  R2424     1.7766645550727844e-01
    z[6,7,6]  R2425     -1.2828439474105835e-01
    z[6,7,6]  R2426     4.6037697792053223e-01
    z[6,7,6]  R2427     -2.1246072649955750e-01
    z[6,7,6]  R2428     -1.1773724108934402e-01
    z[6,7,6]  R2429     -1.4549601078033447e-01
    z[6,7,6]  R2430     -3.0574795603752136e-01
    z[6,7,6]  R2431     2.2659644484519958e-01
    z[6,7,6]  R2432     3.5989217460155487e-02
    z[6,7,6]  R2433     -7.9660356044769287e-02
    z[6,7,6]  R2434     -2.7802494168281555e-01
    z[6,7,6]  R2435     7.3532208800315857e-02
    z[6,7,6]  R2436     3.6037430167198181e-01
    z[6,7,6]  R2437     2.0212219655513763e-01
    z[6,7,6]  R2438     -2.4569953978061676e-01
    z[6,7,6]  R2439     3.2126274704933167e-01
    z[6,7,6]  R2440     -2.0595690608024597e-01
    z[6,7,6]  R2441     3.0520647764205933e-01
    z[6,7,6]  R2442     6.3805043697357178e-02
    z[6,7,6]  R2443     -1.4203125238418579e-01
    z[6,7,6]  R2444     1.0419698059558868e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2445     -1
    z[7,6,0]  R2446     1
    z[7,6,0]  R2459     6.5578132867813110e-01
    z[7,6,0]  R2460     5.6253653764724731e-01
    z[7,6,0]  R2461     3.7063813209533691e-01
    z[7,6,0]  R2462     2.3754149675369263e-01
    z[7,6,0]  R2463     -0.138264000415802
    z[7,6,0]  R2464     -1.8511675298213959e-01
    z[7,6,0]  R2465     -4.6320948004722595e-01
    z[7,6,0]  R2466     -3.7512639164924622e-01
    z[7,6,0]  R2467     -4.1988947987556458e-01
    z[7,6,0]  R2468     -0.35318723320961
    z[7,6,0]  R2469     -0.421892911195755
    z[7,6,0]  R2470     -1.8761147558689117e-01
    z[7,6,0]  R2471     -5.7019978761672974e-01
    z[7,6,0]  R2472     5.4557597637176514e-01
    z[7,6,0]  R2473     4.3389233946800232e-01
    z[7,6,0]  R2474     -4.4840371608734131e-01
    z[7,6,0]  R2475     -3.5936030745506287e-01
    z[7,6,0]  R2476     -5.6440997123718262e-01
    z[7,6,0]  R2477     -6.0405993461608887e-01
    z[7,6,0]  R2478     -2.4745118618011475e-01
    z[7,6,0]  R2479     4.6661216020584106e-01
    z[7,6,0]  R2480     6.2787905335426331e-02
    z[7,6,0]  R2481     -3.2162716984748840e-01
    z[7,6,0]  R2482     4.1591387242078781e-02
    z[7,6,0]  R2483     -2.3878654837608337e-01
    z[7,6,0]  R2484     5.1987826824188232e-01
    z[7,6,0]  R2485     -2.7496299147605896e-01
    z[7,6,0]  R2486     5.0926379859447479e-02
    z[7,6,0]  R2487     -1.8982946872711182e-01
    z[7,6,0]  R2488     -2.6450318098068237e-01
    z[7,6,0]  R2489     0.367813378572464
    z[7,6,0]  R2490     5.8785051107406616e-01
    z[7,6,0]  R2491     -2.0450721681118011e-01
    z[7,6,0]  R2492     -5.3593933582305908e-01
    z[7,6,0]  R2493     -0.239603653550148
    z[7,6,0]  R2494     -1.3740982115268707e-01
    z[7,6,0]  R2495     2.0276165008544922e-01
    z[7,6,0]  R2496     -1.6038633882999420e-01
    z[7,6,0]  R2497     -1.2973412871360779e-01
    z[7,6,0]  R2498     -3.3333939313888550e-01
    z[7,6,0]  R2499     5.7482933998107910e-01
    z[7,6,0]  R2500     -3.9732262492179871e-01
    z[7,6,0]  R2501     -3.3347824215888977e-01
    z[7,6,0]  R2502     -1.0597234219312668e-01
    z[7,6,0]  R2503     -4.5789030194282532e-01
    z[7,6,0]  R2504     -1.2106350809335709e-01
    z[7,6,0]  R2505     -7.2929584980010986e-01
    z[7,6,0]  R2506     -5.4588454961776733e-01
    z[7,6,0]  R2507     -6.7704671621322632e-01
    z[7,6,0]  R2508     -4.2286023497581482e-01
    z[7,6,0]  R2509     7.7563089132308960e-01
    z[7,6,0]  R2510     -3.6315703392028809e-01
    z[7,6,0]  R2511     2.2257076203823090e-01
    z[7,6,0]  R2512     -4.7346496582031250e-01
    z[7,6,0]  R2513     3.5658380389213562e-01
    z[7,6,0]  R2514     -2.3258747160434723e-01
    z[7,6,0]  R2515     2.1382865309715271e-01
    z[7,6,0]  R2516     7.1372449398040771e-01
    z[7,6,0]  R2517     5.7560062408447266e-01
    z[7,6,0]  R2518     -4.9470528960227966e-01
    z[7,6,0]  R2519     3.5655274987220764e-01
    z[7,6,0]  R2520     -2.4651080369949341e-01
    z[7,6,0]  R2521     3.2239560037851334e-02
    z[7,6,0]  R2522     2.6050829887390137e-01
    z[7,6,0]  R2523     3.3348988741636276e-02
    z[7,6,0]  R2524     3.9413425326347351e-01
    z[7,6,0]  R2525     1.2040492892265320e-01
    z[7,6,0]  R2526     -4.4223297387361526e-02
    z[7,6,0]  R2527     1.2639553844928741e-01
    z[7,6,0]  R2528     2.3407611250877380e-01
    z[7,6,0]  R2529     2.2489212453365326e-02
    z[7,6,0]  R2530     0.049301877617836
    z[7,6,0]  R2531     -6.8539790809154510e-02
    z[7,6,0]  R2532     -1.3925112783908844e-01
    z[7,6,0]  R2533     -0.00698230741545558
    z[7,6,0]  R2534     4.2981904745101929e-01
    z[7,6,0]  R2535     -3.6302912235260010e-01
    z[7,6,0]  R2536     -3.9324671030044556e-02
    z[7,6,0]  R2537     -4.6612534672021866e-02
    z[7,6,0]  R2538     -4.6752050518989563e-02
    z[7,6,0]  R2539     8.7930776178836823e-02
    z[7,6,0]  R2540     -1.3830077648162842e-01
    z[7,6,0]  R2541     -7.0758499205112457e-02
    z[7,6,0]  R2542     -6.4150315523147583e-01
    z[7,6,0]  R2543     2.5420022010803223e-01
    z[7,6,0]  R2544     1.9832299649715424e-01
    z[7,6,0]  R2545     1.6615045070648193e-01
    z[7,6,0]  R2546     4.4550865888595581e-01
    z[7,6,0]  R2547     3.8090556859970093e-01
    z[7,6,0]  R2548     6.2357878684997559e-01
    z[7,6,0]  R2549     -2.5736644864082336e-01
    z[7,6,0]  R2550     -2.2577261924743652e-01
    z[7,6,0]  R2551     -4.2888778448104858e-01
    z[7,6,0]  R2552     -3.5213425755500793e-01
    z[7,6,0]  R2553     2.4962651729583740e-01
    z[7,6,0]  R2554     -4.7133937478065491e-01
    z[7,6,0]  R2555     2.6826107501983643e-01
    z[7,6,0]  R2556     4.7166994214057922e-01
    z[7,6,0]  R2557     -0.494873583316803
    z[7,6,0]  R2558     -2.0486731827259064e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2447     -1
    z[7,6,1]  R2448     1
    z[7,6,1]  R2459     1.1435882002115250e-01
    z[7,6,1]  R2460     4.0142297744750977e-01
    z[7,6,1]  R2461     7.6485341787338257e-01
    z[7,6,1]  R2462     5.3542929887771606e-01
    z[7,6,1]  R2463     7.8002071380615234e-01
    z[7,6,1]  R2464     1.3832345604896545e-01
    z[7,6,1]  R2465     -4.7877561300992966e-02
    z[7,6,1]  R2466     -6.3829831779003143e-02
    z[7,6,1]  R2467     3.1923419237136841e-01
    z[7,6,1]  R2468     2.3087453842163086e-01
    z[7,6,1]  R2469     -2.1191075444221497e-01
    z[7,6,1]  R2470     -5.8906716108322144e-01
    z[7,6,1]  R2471     -5.2865590900182724e-02
    z[7,6,1]  R2472     -4.4142669439315796e-01
    z[7,6,1]  R2473     -7.1289384365081787e-01
    z[7,6,1]  R2474     -5.0402671098709106e-01
    z[7,6,1]  R2475     -7.4249184131622314e-01
    z[7,6,1]  R2476     -5.9427630901336670e-01
    z[7,6,1]  R2477     -4.1634941101074219e-01
    z[7,6,1]  R2478     -0.832743227481842
    z[7,6,1]  R2479     -2.4929188191890717e-01
    z[7,6,1]  R2480     1.9046372175216675e-01
    z[7,6,1]  R2481     -1.8191392719745636e-01
    z[7,6,1]  R2482     -1.6768236458301544e-01
    z[7,6,1]  R2483     -0.133817657828331
    z[7,6,1]  R2484     -1.0523710399866104e-01
    z[7,6,1]  R2485     -9.5723263919353485e-02
    z[7,6,1]  R2486     -0.186284601688385
    z[7,6,1]  R2487     -4.1939345002174377e-01
    z[7,6,1]  R2488     -3.8949453830718994e-01
    z[7,6,1]  R2489     2.4423290044069290e-02
    z[7,6,1]  R2490     -4.4574740529060364e-01
    z[7,6,1]  R2491     -4.0387764573097229e-01
    z[7,6,1]  R2492     -2.6248106360435486e-01
    z[7,6,1]  R2493     -4.1414785385131836e-01
    z[7,6,1]  R2494     -1.8218639492988586e-01
    z[7,6,1]  R2495     -1.4169288624543697e-04
    z[7,6,1]  R2496     6.4466185867786407e-02
    z[7,6,1]  R2497     -1.2670651078224182e-01
    z[7,6,1]  R2498     -1.5292043983936310e-01
    z[7,6,1]  R2499     0.437441885471344
    z[7,6,1]  R2500     -2.9498405754566193e-02
    z[7,6,1]  R2501     -2.9368460178375244e-01
    z[7,6,1]  R2502     1.3990128040313721e-01
    z[7,6,1]  R2503     -2.5596305727958679e-01
    z[7,6,1]  R2504     1.6905392706394196e-01
    z[7,6,1]  R2505     -2.0205664634704590e-01
    z[7,6,1]  R2506     4.3392226099967957e-01
    z[7,6,1]  R2507     1.8731987476348877e-01
    z[7,6,1]  R2508     4.3244999647140503e-01
    z[7,6,1]  R2509     -6.8863760679960251e-03
    z[7,6,1]  R2510     5.6003773212432861e-01
    z[7,6,1]  R2511     -1.4625418186187744e-01
    z[7,6,1]  R2512     6.9248473644256592e-01
    z[7,6,1]  R2513     3.9886170625686646e-01
    z[7,6,1]  R2514     5.5988734960556030e-01
    z[7,6,1]  R2515     1.0517976433038712e-01
    z[7,6,1]  R2516     -2.9216584563255310e-01
    z[7,6,1]  R2517     -2.8257003426551819e-01
    z[7,6,1]  R2518     -1.3245357573032379e-01
    z[7,6,1]  R2519     3.8201412558555603e-01
    z[7,6,1]  R2520     3.3908998966217041e-01
    z[7,6,1]  R2521     -7.6833689212799072e-01
    z[7,6,1]  R2522     3.7499892711639404e-01
    z[7,6,1]  R2523     2.9757189750671387e-01
    z[7,6,1]  R2524     -2.0670397579669952e-01
    z[7,6,1]  R2525     -2.9394933581352234e-01
    z[7,6,1]  R2526     -1.2583871185779572e-01
    z[7,6,1]  R2527     -2.2176085412502289e-01
    z[7,6,1]  R2528     -1.3010367751121521e-01
    z[7,6,1]  R2529     7.5065529346466064e-01
    z[7,6,1]  R2530     -4.5002600550651550e-01
    z[7,6,1]  R2531     5.0673919916152954e-01
    z[7,6,1]  R2532     3.5009592771530151e-01
    z[7,6,1]  R2533     -2.4651616811752319e-01
    z[7,6,1]  R2534     3.0220919847488403e-01
    z[7,6,1]  R2535     3.0643942952156067e-01
    z[7,6,1]  R2536     -1.0024845600128174e-01
    z[7,6,1]  R2537     -2.0697984099388123e-01
    z[7,6,1]  R2538     0.4423828125
    z[7,6,1]  R2539     2.1564997732639313e-01
    z[7,6,1]  R2540     3.8733181357383728e-01
    z[7,6,1]  R2541     4.2823117971420288e-01
    z[7,6,1]  R2542     3.6220580339431763e-01
    z[7,6,1]  R2543     -6.1041563749313354e-01
    z[7,6,1]  R2544     -5.3197807073593140e-01
    z[7,6,1]  R2545     -7.1954762935638428e-01
    z[7,6,1]  R2546     -6.6901612281799316e-01
    z[7,6,1]  R2547     -5.9677267074584961e-01
    z[7,6,1]  R2548     -5.1348793506622314e-01
    z[7,6,1]  R2549     5.8343487977981567e-01
    z[7,6,1]  R2550     4.3708932399749756e-01
    z[7,6,1]  R2551     5.0127738714218140e-01
    z[7,6,1]  R2552     3.1788554787635803e-01
    z[7,6,1]  R2553     -2.6431185007095337e-01
    z[7,6,1]  R2554     6.6319274902343750e-01
    z[7,6,1]  R2555     -2.4326251447200775e-01
    z[7,6,1]  R2556     1.5771420672535896e-02
    z[7,6,1]  R2557     4.6840080618858337e-01
    z[7,6,1]  R2558     -5.3650361299514771e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2449     -1
    z[7,6,2]  R2450     1
    z[7,6,2]  R2459     -3.3604586124420166e-01
    z[7,6,2]  R2460     -8.9773915708065033e-02
    z[7,6,2]  R2461     -2.6283088326454163e-01
    z[7,6,2]  R2462     -2.2129869461059570e-01
    z[7,6,2]  R2463     3.8711285591125488e-01
    z[7,6,2]  R2464     7.2691243886947632e-01
    z[7,6,2]  R2465     4.8589169979095459e-01
    z[7,6,2]  R2466     7.5987368822097778e-01
    z[7,6,2]  R2467     3.2897848635911942e-02
    z[7,6,2]  R2468     -8.8280633091926575e-02
    z[7,6,2]  R2469     4.2452374100685120e-01
    z[7,6,2]  R2470     -4.1473528742790222e-01
    z[7,6,2]  R2471     4.7904092073440552e-01
    z[7,6,2]  R2472     -3.3625373244285583e-01
    z[7,6,2]  R2473     -1.5323549509048462e-01
    z[7,6,2]  R2474     -2.1477967500686646e-01
    z[7,6,2]  R2475     -4.4494945555925369e-02
    z[7,6,2]  R2476     -4.4417638331651688e-02
    z[7,6,2]  R2477     5.2536106109619141e-01
    z[7,6,2]  R2478     -3.5484644770622253e-01
    z[7,6,2]  R2479     9.7630776464939117e-02
    z[7,6,2]  R2480     4.0585052967071533e-01
    z[7,6,2]  R2481     -2.9736492037773132e-01
    z[7,6,2]  R2482     6.2986373901367188e-01
    z[7,6,2]  R2483     2.7783477306365967e-01
    z[7,6,2]  R2484     -2.5348627567291260e-01
    z[7,6,2]  R2485     7.6207816600799561e-01
    z[7,6,2]  R2486     0.831156849861145
    z[7,6,2]  R2487     6.1910808086395264e-01
    z[7,6,2]  R2488     7.5966519117355347e-01
    z[7,6,2]  R2489     3.1685021519660950e-01
    z[7,6,2]  R2490     -3.6706620454788208e-01
    z[7,6,2]  R2491     -4.2125180363655090e-01
    z[7,6,2]  R2492     5.5523318052291870e-01
    z[7,6,2]  R2493     0.807011067867279
    z[7,6,2]  R2494     8.4683841466903687e-01
    z[7,6,2]  R2495     8.7419945001602173e-01
    z[7,6,2]  R2496     9.5148253440856934e-01
    z[7,6,2]  R2497     9.5361477136611938e-01
    z[7,6,2]  R2498     8.5782015323638916e-01
    z[7,6,2]  R2499     -3.0486200004816055e-02
    z[7,6,2]  R2500     -1.1528084427118301e-01
    z[7,6,2]  R2501     7.4738597869873047e-01
    z[7,6,2]  R2502     7.1247100830078125e-01
    z[7,6,2]  R2503     3.2485216856002808e-01
    z[7,6,2]  R2504     6.8495023250579834e-01
    z[7,6,2]  R2505     1.1261721700429916e-01
    z[7,6,2]  R2506     6.6891357302665710e-02
    z[7,6,2]  R2507     9.6072681248188019e-02
    z[7,6,2]  R2508     2.4772010743618011e-02
    z[7,6,2]  R2509     4.7511968016624451e-01
    z[7,6,2]  R2510     -2.9498362541198730e-01
    z[7,6,2]  R2511     9.4056320190429688e-01
    z[7,6,2]  R2512     -2.1618528664112091e-01
    z[7,6,2]  R2513     -4.4302487373352051e-01
    z[7,6,2]  R2514     -2.6129558682441711e-01
    z[7,6,2]  R2515     -4.5782196521759033e-01
    z[7,6,2]  R2516     -0.60861736536026
    z[7,6,2]  R2517     -0.651661217212677
    z[7,6,2]  R2518     5.7883709669113159e-01
    z[7,6,2]  R2519     -6.7905426025390625e-01
    z[7,6,2]  R2520     -2.1646840870380402e-01
    z[7,6,2]  R2521     0.572898805141449
    z[7,6,2]  R2522     -3.7956693768501282e-01
    z[7,6,2]  R2523     -3.0350151658058167e-01
    z[7,6,2]  R2524     1.7284838855266571e-01
    z[7,6,2]  R2525     0.508536696434021
    z[7,6,2]  R2526     -2.6058253645896912e-01
    z[7,6,2]  R2527     3.9446863532066345e-01
    z[7,6,2]  R2528     -3.0458378791809082e-01
    z[7,6,2]  R2529     -4.2649102210998535e-01
    z[7,6,2]  R2530     2.5434204936027527e-01
    z[7,6,2]  R2531     -1.4129005372524261e-01
    z[7,6,2]  R2532     -3.8931033015251160e-01
    z[7,6,2]  R2533     4.5407322049140930e-01
    z[7,6,2]  R2534     -6.0657691955566406e-01
    z[7,6,2]  R2535     -2.8872179985046387e-01
    z[7,6,2]  R2536     -3.6127230525016785e-01
    z[7,6,2]  R2537     4.4500410556793213e-01
    z[7,6,2]  R2538     -2.3062816262245178e-01
    z[7,6,2]  R2539     -3.6736661195755005e-01
    z[7,6,2]  R2540     -5.2608931064605713e-01
    z[7,6,2]  R2541     -3.2370918989181519e-01
    z[7,6,2]  R2542     9.6486732363700867e-02
    z[7,6,2]  R2543     4.9646192789077759e-01
    z[7,6,2]  R2544     4.8926532268524170e-01
    z[7,6,2]  R2545     4.4028982520103455e-01
    z[7,6,2]  R2546     1.7534171044826508e-01
    z[7,6,2]  R2547     2.3417973518371582e-01
    z[7,6,2]  R2548     1.1144289374351501e-01
    z[7,6,2]  R2549     -3.2406392693519592e-01
    z[7,6,2]  R2550     -5.0877904891967773e-01
    z[7,6,2]  R2551     -1.6972798109054565e-01
    z[7,6,2]  R2552     -3.3042725920677185e-01
    z[7,6,2]  R2553     2.9166355729103088e-01
    z[7,6,2]  R2554     -1.6853570938110352e-01
    z[7,6,2]  R2555     3.0091315507888794e-01
    z[7,6,2]  R2556     4.2526204138994217e-02
    z[7,6,2]  R2557     1.0257680714130402e-01
    z[7,6,2]  R2558     4.3797358870506287e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2451     -1
    z[7,6,3]  R2452     1
    z[7,6,3]  R2459     1.7860975861549377e-01
    z[7,6,3]  R2460     3.2187944650650024e-01
    z[7,6,3]  R2461     1.0834605433046818e-02
    z[7,6,3]  R2462     3.2391202449798584e-01
    z[7,6,3]  R2463     2.0039199292659760e-01
    z[7,6,3]  R2464     1.2313036620616913e-01
    z[7,6,3]  R2465     -1.6694139689207077e-02
    z[7,6,3]  R2466     1.9584544003009796e-01
    z[7,6,3]  R2467     -7.0980352163314819e-01
    z[7,6,3]  R2468     -7.1118837594985962e-01
    z[7,6,3]  R2469     -2.2603254020214081e-01
    z[7,6,3]  R2470     -5.7955193519592285e-01
    z[7,6,3]  R2471     -1.2480422854423523e-01
    z[7,6,3]  R2472     -2.7611499652266502e-02
    z[7,6,3]  R2473     1.1606021970510483e-01
    z[7,6,3]  R2474     -0.664367139339447
    z[7,6,3]  R2475     -4.7494283318519592e-01
    z[7,6,3]  R2476     -4.8844027519226074e-01
    z[7,6,3]  R2477     -1.0250040888786316e-01
    z[7,6,3]  R2478     4.6880498528480530e-02
    z[7,6,3]  R2479     1.5337735414505005e-01
    z[7,6,3]  R2480     6.7403799295425415e-01
    z[7,6,3]  R2481     -3.1837800145149231e-01
    z[7,6,3]  R2482     -4.4210964441299438e-01
    z[7,6,3]  R2483     -3.6278063058853149e-01
    z[7,6,3]  R2484     4.9592819809913635e-01
    z[7,6,3]  R2485     1.2239511311054230e-01
    z[7,6,3]  R2486     2.6496684551239014e-01
    z[7,6,3]  R2487     0.199748694896698
    z[7,6,3]  R2488     3.2743549346923828e-01
    z[7,6,3]  R2489     7.1964037418365479e-01
    z[7,6,3]  R2490     2.1272291243076324e-01
    z[7,6,3]  R2491     -5.7984054088592529e-01
    z[7,6,3]  R2492     -4.1433432698249817e-01
    z[7,6,3]  R2493     1.1915339529514313e-01
    z[7,6,3]  R2494     -1.1254362016916275e-01
    z[7,6,3]  R2495     2.7752781286835670e-02
    z[7,6,3]  R2496     9.9605210125446320e-03
    z[7,6,3]  R2497     -1.5184667706489563e-01
    z[7,6,3]  R2498     -1.8563267588615417e-01
    z[7,6,3]  R2499     3.1545478105545044e-01
    z[7,6,3]  R2500     -2.9333594441413879e-01
    z[7,6,3]  R2501     1.9253598153591156e-01
    z[7,6,3]  R2502     -1.1768083274364471e-01
    z[7,6,3]  R2503     0.0886588916182518
    z[7,6,3]  R2504     -3.5248023271560669e-01
    z[7,6,3]  R2505     -2.3124119639396667e-01
    z[7,6,3]  R2506     -6.5944540500640869e-01
    z[7,6,3]  R2507     -6.8610537052154541e-01
    z[7,6,3]  R2508     -7.5621813535690308e-01
    z[7,6,3]  R2509     2.1513253450393677e-01
    z[7,6,3]  R2510     4.1307443380355835e-01
    z[7,6,3]  R2511     9.2487454414367676e-02
    z[7,6,3]  R2512     2.8184279799461365e-01
    z[7,6,3]  R2513     2.4462194740772247e-01
    z[7,6,3]  R2514     -4.2428457736968994e-01
    z[7,6,3]  R2515     2.8683164715766907e-01
    z[7,6,3]  R2516     5.8566696941852570e-02
    z[7,6,3]  R2517     -7.3858529329299927e-02
    z[7,6,3]  R2518     -9.7937986254692078e-02
    z[7,6,3]  R2519     7.9831499606370926e-03
    z[7,6,3]  R2520     1.7509230971336365e-01
    z[7,6,3]  R2521     4.2215961962938309e-02
    z[7,6,3]  R2522     -6.5733693540096283e-02
    z[7,6,3]  R2523     -6.8958718329668045e-03
    z[7,6,3]  R2524     -9.3161761760711670e-03
    z[7,6,3]  R2525     -5.9417265653610229e-01
    z[7,6,3]  R2526     3.0213648080825806e-01
    z[7,6,3]  R2527     -5.0230938196182251e-01
    z[7,6,3]  R2528     9.0317547321319580e-01
    z[7,6,3]  R2529     1.5011011064052582e-01
    z[7,6,3]  R2530     6.5144568681716919e-01
    z[7,6,3]  R2531     4.3764621019363403e-01
    z[7,6,3]  R2532     5.6495642662048340e-01
    z[7,6,3]  R2533     3.0804595351219177e-01
    z[7,6,3]  R2534     5.1600122451782227e-01
    z[7,6,3]  R2535     1.2161944806575775e-01
    z[7,6,3]  R2536     6.4246350526809692e-01
    z[7,6,3]  R2537     -3.2450112700462341e-01
    z[7,6,3]  R2538     2.9475349187850952e-01
    z[7,6,3]  R2539     8.0075448751449585e-01
    z[7,6,3]  R2540     1.4355318248271942e-01
    z[7,6,3]  R2541     -1.0965181142091751e-01
    z[7,6,3]  R2542     4.7584244608879089e-01
    z[7,6,3]  R2543     -4.6038556098937988e-01
    z[7,6,3]  R2544     -0.3236083984375
    z[7,6,3]  R2545     -2.0194093883037567e-01
    z[7,6,3]  R2546     -2.8639006614685059e-01
    z[7,6,3]  R2547     -5.2986311912536621e-01
    z[7,6,3]  R2548     -5.5533796548843384e-01
    z[7,6,3]  R2549     5.0833827257156372e-01
    z[7,6,3]  R2550     3.2436171174049377e-01
    z[7,6,3]  R2551     2.4476137757301331e-01
    z[7,6,3]  R2552     7.0018047094345093e-01
    z[7,6,3]  R2553     -2.7334091067314148e-01
    z[7,6,3]  R2554     -2.3013319075107574e-01
    z[7,6,3]  R2555     0.042548768222332
    z[7,6,3]  R2556     -8.6475081741809845e-02
    z[7,6,3]  R2557     1.9139336422085762e-02
    z[7,6,3]  R2558     4.4826313853263855e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2453     -1
    z[7,6,4]  R2454     1
    z[7,6,4]  R2459     1.6010291874408722e-02
    z[7,6,4]  R2460     -1.0964769870042801e-01
    z[7,6,4]  R2461     2.1156449615955353e-01
    z[7,6,4]  R2462     0.655748188495636
    z[7,6,4]  R2463     -1.4161817729473114e-01
    z[7,6,4]  R2464     6.3251096010208130e-01
    z[7,6,4]  R2465     3.9920559525489807e-01
    z[7,6,4]  R2466     -6.1699371784925461e-02
    z[7,6,4]  R2467     3.5262140631675720e-01
    z[7,6,4]  R2468     -2.7352491393685341e-02
    z[7,6,4]  R2469     3.0771702527999878e-01
    z[7,6,4]  R2470     0.307492196559906
    z[7,6,4]  R2471     4.6538379788398743e-01
    z[7,6,4]  R2472     -2.9700118303298950e-01
    z[7,6,4]  R2473     -3.9172884821891785e-01
    z[7,6,4]  R2474     2.1518760919570923e-01
    z[7,6,4]  R2475     -1.0180468112230301e-01
    z[7,6,4]  R2476     2.2309435904026031e-01
    z[7,6,4]  R2477     -0.0850767120718956
    z[7,6,4]  R2478     -1.1955167353153229e-01
    z[7,6,4]  R2479     -8.1110924482345581e-01
    z[7,6,4]  R2480     -1.0898580402135849e-01
    z[7,6,4]  R2481     5.5226337909698486e-01
    z[7,6,4]  R2482     4.8057359457015991e-01
    z[7,6,4]  R2483     7.1364927291870117e-01
    z[7,6,4]  R2484     2.6871958374977112e-01
    z[7,6,4]  R2485     5.2876341342926025e-01
    z[7,6,4]  R2486     1.1409211903810501e-01
    z[7,6,4]  R2487     2.6202520728111267e-01
    z[7,6,4]  R2488     2.4984866380691528e-01
    z[7,6,4]  R2489     -3.6618936061859131e-01
    z[7,6,4]  R2490     -1.6661860048770905e-02
    z[7,6,4]  R2491     4.3248176574707031e-01
    z[7,6,4]  R2492     2.5308316946029663e-01
    z[7,6,4]  R2493     2.0223341882228851e-01
    z[7,6,4]  R2494     3.3913221955299377e-01
    z[7,6,4]  R2495     3.0128675699234009e-01
    z[7,6,4]  R2496     1.3564477860927582e-01
    z[7,6,4]  R2497     -2.7488607913255692e-02
    z[7,6,4]  R2498     4.8106640577316284e-02
    z[7,6,4]  R2499     -3.4481963515281677e-01
    z[7,6,4]  R2500     -2.0610374212265015e-01
    z[7,6,4]  R2501     2.7970704436302185e-01
    z[7,6,4]  R2502     5.1321285963058472e-01
    z[7,6,4]  R2503     6.8382078409194946e-01
    z[7,6,4]  R2504     7.9613149166107178e-02
    z[7,6,4]  R2505     5.0367474555969238e-01
    z[7,6,4]  R2506     -1.6412030905485153e-02
    z[7,6,4]  R2507     5.0547290593385696e-02
    z[7,6,4]  R2508     -2.2112096846103668e-01
    z[7,6,4]  R2509     2.3307062685489655e-01
    z[7,6,4]  R2510     2.5533128529787064e-02
    z[7,6,4]  R2511     2.7801211923360825e-02
    z[7,6,4]  R2512     -2.5979182124137878e-01
    z[7,6,4]  R2513     6.5709066390991211e-01
    z[7,6,4]  R2514     2.2197322547435760e-01
    z[7,6,4]  R2515     4.7340080142021179e-01
    z[7,6,4]  R2516     -2.6889607310295105e-02
    z[7,6,4]  R2517     -3.4498524665832520e-01
    z[7,6,4]  R2518     3.8552662730216980e-01
    z[7,6,4]  R2519     -4.2029681801795959e-01
    z[7,6,4]  R2520     4.5138096809387207e-01
    z[7,6,4]  R2521     1.0632122308015823e-01
    z[7,6,4]  R2522     -6.3010370731353760e-01
    z[7,6,4]  R2523     -0.851609468460083
    z[7,6,4]  R2524     1.2785906903445721e-02
    z[7,6,4]  R2525     1.0424222797155380e-01
    z[7,6,4]  R2526     -7.7600908279418945e-01
    z[7,6,4]  R2527     4.1884702444076538e-01
    z[7,6,4]  R2528     1.0178020223975182e-02
    z[7,6,4]  R2529     3.7334653735160828e-01
    z[7,6,4]  R2530     3.4768790006637573e-01
    z[7,6,4]  R2531     2.7879342436790466e-01
    z[7,6,4]  R2532     -5.8211672306060791e-01
    z[7,6,4]  R2533     -2.4894128739833832e-01
    z[7,6,4]  R2534     -1.0453967005014420e-01
    z[7,6,4]  R2535     -6.4241182804107666e-01
    z[7,6,4]  R2536     -4.8757123947143555e-01
    z[7,6,4]  R2537     -4.2702168226242065e-01
    z[7,6,4]  R2538     -3.4983408451080322e-01
    z[7,6,4]  R2539     -1.3893342018127441e-01
    z[7,6,4]  R2540     -2.7974995970726013e-01
    z[7,6,4]  R2541     -8.1697374582290649e-01
    z[7,6,4]  R2542     5.1591273397207260e-02
    z[7,6,4]  R2543     2.1880412101745605e-01
    z[7,6,4]  R2544     4.7620871663093567e-01
    z[7,6,4]  R2545     3.9910537004470825e-01
    z[7,6,4]  R2546     2.8587529063224792e-01
    z[7,6,4]  R2547     -2.2865609824657440e-01
    z[7,6,4]  R2548     9.1808803379535675e-02
    z[7,6,4]  R2549     4.6441745758056641e-01
    z[7,6,4]  R2550     -2.8656238317489624e-01
    z[7,6,4]  R2551     3.5038910806179047e-02
    z[7,6,4]  R2552     -8.6673960089683533e-02
    z[7,6,4]  R2553     -1.1518691480159760e-01
    z[7,6,4]  R2554     -3.9452469348907471e-01
    z[7,6,4]  R2555     3.6958824843168259e-02
    z[7,6,4]  R2556     4.2782264947891235e-01
    z[7,6,4]  R2557     -4.7407191991806030e-01
    z[7,6,4]  R2558     -3.2385182380676270e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2455     -1
    z[7,6,5]  R2456     1
    z[7,6,5]  R2459     6.1092805862426758e-01
    z[7,6,5]  R2460     0.305328369140625
    z[7,6,5]  R2461     -3.2644817233085632e-01
    z[7,6,5]  R2462     2.7013307809829712e-01
    z[7,6,5]  R2463     3.8586756587028503e-01
    z[7,6,5]  R2464     -1.1724155396223068e-02
    z[7,6,5]  R2465     -5.4554667323827744e-02
    z[7,6,5]  R2466     -1.7589065432548523e-01
    z[7,6,5]  R2467     7.0996925234794617e-02
    z[7,6,5]  R2468     4.9334344267845154e-01
    z[7,6,5]  R2469     -0.647737979888916
    z[7,6,5]  R2470     2.6006600819528103e-03
    z[7,6,5]  R2471     -3.1988570094108582e-01
    z[7,6,5]  R2472     -5.3647315502166748e-01
    z[7,6,5]  R2473     -3.3451077342033386e-01
    z[7,6,5]  R2474     3.8160249590873718e-02
    z[7,6,5]  R2475     0.247584730386734
    z[7,6,5]  R2476     1.7031347751617432e-01
    z[7,6,5]  R2477     -3.9729550480842590e-01
    z[7,6,5]  R2478     2.6620325446128845e-01
    z[7,6,5]  R2479     -9.6859313547611237e-02
    z[7,6,5]  R2480     3.9680776000022888e-01
    z[7,6,5]  R2481     3.8803797960281372e-01
    z[7,6,5]  R2482     -3.6811605095863342e-01
    z[7,6,5]  R2483     -4.5355820655822754e-01
    z[7,6,5]  R2484     -3.7679061293601990e-01
    z[7,6,5]  R2485     -9.9245734512805939e-02
    z[7,6,5]  R2486     -3.6069911718368530e-01
    z[7,6,5]  R2487     -4.9722501635551453e-01
    z[7,6,5]  R2488     -6.0913139022886753e-03
    z[7,6,5]  R2489     -3.0868908762931824e-01
    z[7,6,5]  R2490     -2.5204730033874512e-01
    z[7,6,5]  R2491     2.2183644771575928e-01
    z[7,6,5]  R2492     -2.9326236248016357e-01
    z[7,6,5]  R2493     -2.0866183936595917e-01
    z[7,6,5]  R2494     -9.8147220909595490e-02
    z[7,6,5]  R2495     -2.2753703594207764e-01
    z[7,6,5]  R2496     -2.1214932203292847e-01
    z[7,6,5]  R2497     -1.6605599224567413e-01
    z[7,6,5]  R2498     -1.2479253858327866e-01
    z[7,6,5]  R2499     -5.0345528125762939e-01
    z[7,6,5]  R2500     0.754705548286438
    z[7,6,5]  R2501     -2.9630449414253235e-01
    z[7,6,5]  R2502     -3.5210517048835754e-01
    z[7,6,5]  R2503     -2.0151783525943756e-01
    z[7,6,5]  R2504     -5.6089985370635986e-01
    z[7,6,5]  R2505     -1.1960883438587189e-01
    z[7,6,5]  R2506     -2.6464805006980896e-01
    z[7,6,5]  R2507     -6.1810355633497238e-02
    z[7,6,5]  R2508     -4.4104088097810745e-02
    z[7,6,5]  R2509     -2.4626553058624268e-01
    z[7,6,5]  R2510     3.9973545819520950e-02
    z[7,6,5]  R2511     1.8533450365066528e-01
    z[7,6,5]  R2512     2.9870948195457458e-01
    z[7,6,5]  R2513     -1.1307615786790848e-01
    z[7,6,5]  R2514     5.5027270317077637e-01
    z[7,6,5]  R2515     0.598588764667511
    z[7,6,5]  R2516     1.6931708157062531e-01
    z[7,6,5]  R2517     1.1876410990953445e-01
    z[7,6,5]  R2518     -1.1166165024042130e-01
    z[7,6,5]  R2519     1.9647181034088135e-01
    z[7,6,5]  R2520     6.0314178466796875e-01
    z[7,6,5]  R2521     -1.6237659752368927e-01
    z[7,6,5]  R2522     -4.7565874457359314e-01
    z[7,6,5]  R2523     -2.9490628838539124e-01
    z[7,6,5]  R2524     -7.6681065559387207e-01
    z[7,6,5]  R2525     -5.1645308732986450e-01
    z[7,6,5]  R2526     3.8237437605857849e-01
    z[7,6,5]  R2527     -3.2025906443595886e-01
    z[7,6,5]  R2528     -1.2556119263172150e-01
    z[7,6,5]  R2529     -1.8859510123729706e-01
    z[7,6,5]  R2530     -2.1523422002792358e-01
    z[7,6,5]  R2531     -5.9475260972976685e-01
    z[7,6,5]  R2532     -1.0085628181695938e-01
    z[7,6,5]  R2533     -3.0298787355422974e-01
    z[7,6,5]  R2534     -2.4765150249004364e-01
    z[7,6,5]  R2535     4.7999256849288940e-01
    z[7,6,5]  R2536     4.4700637459754944e-01
    z[7,6,5]  R2537     -6.5264725685119629e-01
    z[7,6,5]  R2538     -4.7134715318679810e-01
    z[7,6,5]  R2539     -3.5447177290916443e-01
    z[7,6,5]  R2540     6.7346090078353882e-01
    z[7,6,5]  R2541     -1.6537380218505859e-01
    z[7,6,5]  R2542     3.0855366960167885e-02
    z[7,6,5]  R2543     -2.0155285298824310e-01
    z[7,6,5]  R2544     -1.2042575329542160e-01
    z[7,6,5]  R2545     2.4261063337326050e-01
    z[7,6,5]  R2546     3.4163564443588257e-01
    z[7,6,5]  R2547     1.0395988821983337e-01
    z[7,6,5]  R2548     -2.8603386133909225e-02
    z[7,6,5]  R2549     1.1940021067857742e-01
    z[7,6,5]  R2550     5.5837196111679077e-01
    z[7,6,5]  R2551     2.7310207486152649e-01
    z[7,6,5]  R2552     3.7988269329071045e-01
    z[7,6,5]  R2553     -6.8950974941253662e-01
    z[7,6,5]  R2554     1.4357882738113403e-01
    z[7,6,5]  R2555     -8.6851459741592407e-01
    z[7,6,5]  R2556     -7.1773386001586914e-01
    z[7,6,5]  R2557     -4.0822815895080566e-01
    z[7,6,5]  R2558     -3.4957060217857361e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2457     -1
    z[7,6,6]  R2458     1
    z[7,6,6]  R2459     -1.9635464251041412e-01
    z[7,6,6]  R2460     -5.5271911621093750e-01
    z[7,6,6]  R2461     -2.3895850777626038e-01
    z[7,6,6]  R2462     4.4609103351831436e-03
    z[7,6,6]  R2463     -1.1613752692937851e-01
    z[7,6,6]  R2464     -5.3179364651441574e-02
    z[7,6,6]  R2465     -6.2002742290496826e-01
    z[7,6,6]  R2466     -4.5243588089942932e-01
    z[7,6,6]  R2467     -0.295798122882843
    z[7,6,6]  R2468     -2.5345128774642944e-01
    z[7,6,6]  R2469     1.7758010327816010e-01
    z[7,6,6]  R2470     1.2392652779817581e-01
    z[7,6,6]  R2471     -3.2880410552024841e-01
    z[7,6,6]  R2472     1.3284260034561157e-01
    z[7,6,6]  R2473     -0.0349249504506588
    z[7,6,6]  R2474     -9.8057381808757782e-02
    z[7,6,6]  R2475     -1.4266440272331238e-01
    z[7,6,6]  R2476     -9.4616673886775970e-02
    z[7,6,6]  R2477     1.0085908323526382e-01
    z[7,6,6]  R2478     1.7898587882518768e-01
    z[7,6,6]  R2479     1.4067785441875458e-01
    z[7,6,6]  R2480     4.1401076316833496e-01
    z[7,6,6]  R2481     4.6701654791831970e-01
    z[7,6,6]  R2482     1.0725246369838715e-01
    z[7,6,6]  R2483     3.5518039017915726e-02
    z[7,6,6]  R2484     4.4076108932495117e-01
    z[7,6,6]  R2485     1.7334438860416412e-01
    z[7,6,6]  R2486     2.4198049306869507e-01
    z[7,6,6]  R2487     2.2133606672286987e-01
    z[7,6,6]  R2488     1.7766645550727844e-01
    z[7,6,6]  R2489     -1.2828439474105835e-01
    z[7,6,6]  R2490     4.6037697792053223e-01
    z[7,6,6]  R2491     -2.1246072649955750e-01
    z[7,6,6]  R2492     -1.1773724108934402e-01
    z[7,6,6]  R2493     -1.4549601078033447e-01
    z[7,6,6]  R2494     -3.0574795603752136e-01
    z[7,6,6]  R2495     2.2659644484519958e-01
    z[7,6,6]  R2496     3.5989217460155487e-02
    z[7,6,6]  R2497     -7.9660356044769287e-02
    z[7,6,6]  R2498     -2.7802494168281555e-01
    z[7,6,6]  R2499     7.3532208800315857e-02
    z[7,6,6]  R2500     3.6037430167198181e-01
    z[7,6,6]  R2501     2.0212219655513763e-01
    z[7,6,6]  R2502     -2.4569953978061676e-01
    z[7,6,6]  R2503     3.2126274704933167e-01
    z[7,6,6]  R2504     -2.0595690608024597e-01
    z[7,6,6]  R2505     3.0520647764205933e-01
    z[7,6,6]  R2506     6.3805043697357178e-02
    z[7,6,6]  R2507     -1.4203125238418579e-01
    z[7,6,6]  R2508     1.0419698059558868e-01
    z[7,6,6]  R2509     -1.0658331215381622e-01
    z[7,6,6]  R2510     -5.4275143146514893e-01
    z[7,6,6]  R2511     -2.7151120826601982e-02
    z[7,6,6]  R2512     -1.1578156799077988e-01
    z[7,6,6]  R2513     -1.1442054808139801e-01
    z[7,6,6]  R2514     -1.7906531691551208e-01
    z[7,6,6]  R2515     -2.6253458857536316e-01
    z[7,6,6]  R2516     4.4720619916915894e-02
    z[7,6,6]  R2517     -1.6000309586524963e-01
    z[7,6,6]  R2518     -4.8164242506027222e-01
    z[7,6,6]  R2519     2.2473609447479248e-01
    z[7,6,6]  R2520     4.2333155870437622e-01
    z[7,6,6]  R2521     -2.0236971974372864e-01
    z[7,6,6]  R2522     1.4084529876708984e-01
    z[7,6,6]  R2523     -7.7263832092285156e-02
    z[7,6,6]  R2524     4.2872640490531921e-01
    z[7,6,6]  R2525     -9.9274218082427979e-02
    z[7,6,6]  R2526     2.7316457033157349e-01
    z[7,6,6]  R2527     -4.9892616271972656e-01
    z[7,6,6]  R2528     6.2569208443164825e-02
    z[7,6,6]  R2529     2.3796525597572327e-01
    z[7,6,6]  R2530     3.7250757217407227e-01
    z[7,6,6]  R2531     3.0913466215133667e-01
    z[7,6,6]  R2532     1.9563171267509460e-01
    z[7,6,6]  R2533     6.9594025611877441e-01
    z[7,6,6]  R2534     1.3218365609645844e-01
    z[7,6,6]  R2535     1.8184454739093781e-01
    z[7,6,6]  R2536     8.7099619209766388e-02
    z[7,6,6]  R2537     2.0823296904563904e-01
    z[7,6,6]  R2538     5.6346309185028076e-01
    z[7,6,6]  R2539     -1.5698574483394623e-01
    z[7,6,6]  R2540     -4.0741167962551117e-02
    z[7,6,6]  R2541     2.3560726549476385e-03
    z[7,6,6]  R2542     4.6683105826377869e-01
    z[7,6,6]  R2543     -1.2588398158550262e-01
    z[7,6,6]  R2544     3.0378827452659607e-01
    z[7,6,6]  R2545     4.3183397501707077e-02
    z[7,6,6]  R2546     2.0672650635242462e-01
    z[7,6,6]  R2547     3.1636545062065125e-01
    z[7,6,6]  R2548     1.3195750117301941e-01
    z[7,6,6]  R2549     -1.0134275071322918e-03
    z[7,6,6]  R2550     -3.9759213104844093e-03
    z[7,6,6]  R2551     6.3265162706375122e-01
    z[7,6,6]  R2552     1.5392234921455383e-01
    z[7,6,6]  R2553     -0.468349426984787
    z[7,6,6]  R2554     2.8352162241935730e-01
    z[7,6,6]  R2555     1.4427970349788666e-01
    z[7,6,6]  R2556     2.6423105597496033e-01
    z[7,6,6]  R2557     0.365264356136322
    z[7,6,6]  R2558     -2.2439448535442352e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2559     -1
    z[7,8,0]  R2560     1
    z[7,8,0]  R2573     6.5578132867813110e-01
    z[7,8,0]  R2574     5.6253653764724731e-01
    z[7,8,0]  R2575     3.7063813209533691e-01
    z[7,8,0]  R2576     2.3754149675369263e-01
    z[7,8,0]  R2577     -0.138264000415802
    z[7,8,0]  R2578     -1.8511675298213959e-01
    z[7,8,0]  R2579     -4.6320948004722595e-01
    z[7,8,0]  R2580     -3.7512639164924622e-01
    z[7,8,0]  R2581     -4.1988947987556458e-01
    z[7,8,0]  R2582     -0.35318723320961
    z[7,8,0]  R2583     -0.421892911195755
    z[7,8,0]  R2584     -1.8761147558689117e-01
    z[7,8,0]  R2585     -5.7019978761672974e-01
    z[7,8,0]  R2586     5.4557597637176514e-01
    z[7,8,0]  R2587     4.3389233946800232e-01
    z[7,8,0]  R2588     -4.4840371608734131e-01
    z[7,8,0]  R2589     -3.5936030745506287e-01
    z[7,8,0]  R2590     -5.6440997123718262e-01
    z[7,8,0]  R2591     -6.0405993461608887e-01
    z[7,8,0]  R2592     -2.4745118618011475e-01
    z[7,8,0]  R2593     4.6661216020584106e-01
    z[7,8,0]  R2594     6.2787905335426331e-02
    z[7,8,0]  R2595     -3.2162716984748840e-01
    z[7,8,0]  R2596     4.1591387242078781e-02
    z[7,8,0]  R2597     -2.3878654837608337e-01
    z[7,8,0]  R2598     5.1987826824188232e-01
    z[7,8,0]  R2599     -2.7496299147605896e-01
    z[7,8,0]  R2600     5.0926379859447479e-02
    z[7,8,0]  R2601     -1.8982946872711182e-01
    z[7,8,0]  R2602     -2.6450318098068237e-01
    z[7,8,0]  R2603     0.367813378572464
    z[7,8,0]  R2604     5.8785051107406616e-01
    z[7,8,0]  R2605     -2.0450721681118011e-01
    z[7,8,0]  R2606     -5.3593933582305908e-01
    z[7,8,0]  R2607     -0.239603653550148
    z[7,8,0]  R2608     -1.3740982115268707e-01
    z[7,8,0]  R2609     2.0276165008544922e-01
    z[7,8,0]  R2610     -1.6038633882999420e-01
    z[7,8,0]  R2611     -1.2973412871360779e-01
    z[7,8,0]  R2612     -3.3333939313888550e-01
    z[7,8,0]  R2613     5.7482933998107910e-01
    z[7,8,0]  R2614     -3.9732262492179871e-01
    z[7,8,0]  R2615     -3.3347824215888977e-01
    z[7,8,0]  R2616     -1.0597234219312668e-01
    z[7,8,0]  R2617     -4.5789030194282532e-01
    z[7,8,0]  R2618     -1.2106350809335709e-01
    z[7,8,0]  R2619     -7.2929584980010986e-01
    z[7,8,0]  R2620     -5.4588454961776733e-01
    z[7,8,0]  R2621     -6.7704671621322632e-01
    z[7,8,0]  R2622     -4.2286023497581482e-01
    z[7,8,0]  R2623     7.3675704002380371e-01
    z[7,8,0]  R2624     1.0319972038269043e-01
    z[7,8,0]  R2625     6.3704389333724976e-01
    z[7,8,0]  R2626     3.2089483737945557e-01
    z[7,8,0]  R2627     4.4578793644905090e-01
    z[7,8,0]  R2628     8.4498089551925659e-01
    z[7,8,0]  R2629     5.0070625543594360e-01
    z[7,8,0]  R2630     5.7631397247314453e-01
    z[7,8,0]  R2631     6.8455582857131958e-01
    z[7,8,0]  R2632     -3.2613688707351685e-01
    z[7,8,0]  R2633     -1.6814163327217102e-01
    z[7,8,0]  R2634     -1.7515951395034790e-01
    z[7,8,0]  R2635     -2.4347655475139618e-02
    z[7,8,0]  R2636     -0.0678994357585907
    z[7,8,0]  R2637     -2.3351998627185822e-01
    z[7,8,0]  R2638     1.1257733404636383e-01
    z[7,8,0]  R2639     -2.7053564786911011e-01
    z[7,8,0]  R2640     -7.0400846004486084e-01
    z[7,8,0]  R2641     -5.1912359893321991e-02
    z[7,8,0]  R2642     3.8379433751106262e-01
    z[7,8,0]  R2643     -1.3053552806377411e-01
    z[7,8,0]  R2644     -1.2395630031824112e-01
    z[7,8,0]  R2645     -2.5183475017547607e-01
    z[7,8,0]  R2646     0.114784836769104
    z[7,8,0]  R2647     -4.0332657098770142e-01
    z[7,8,0]  R2648     3.3311915397644043e-01
    z[7,8,0]  R2649     0.347579687833786
    z[7,8,0]  R2650     5.9238141775131226e-01
    z[7,8,0]  R2651     -2.0692250132560730e-01
    z[7,8,0]  R2652     2.5033403187990189e-02
    z[7,8,0]  R2653     -2.5332754850387573e-01
    z[7,8,0]  R2654     -1.5056604752317071e-03
    z[7,8,0]  R2655     -2.8315967321395874e-01
    z[7,8,0]  R2656     4.8121601343154907e-02
    z[7,8,0]  R2657     4.5071363449096680e-01
    z[7,8,0]  R2658     -1.4257016777992249e-01
    z[7,8,0]  R2659     -4.2801958322525024e-01
    z[7,8,0]  R2660     -1.1250866204500198e-01
    z[7,8,0]  R2661     1.8788002431392670e-01
    z[7,8,0]  R2662     -2.6258345693349838e-02
    z[7,8,0]  R2663     -3.2672667503356934e-01
    z[7,8,0]  R2664     -4.8704558610916138e-01
    z[7,8,0]  R2665     -3.9662095904350281e-01
    z[7,8,0]  R2666     -3.9709344506263733e-01
    z[7,8,0]  R2667     2.8152653574943542e-01
    z[7,8,0]  R2668     -0.386346697807312
    z[7,8,0]  R2669     -5.3818565607070923e-01
    z[7,8,0]  R2670     -4.8915845155715942e-01
    z[7,8,0]  R2671     -3.6705833673477173e-01
    z[7,8,0]  R2672     5.6868660449981689e-01
    z[7,8,0]  R2673     -4.3744522333145142e-01
    z[7,8,0]  R2674     -6.1622118949890137e-01
    z[7,8,0]  R2675     1.5182720124721527e-01
    z[7,8,0]  R2676     2.2419843077659607e-01
    z[7,8,0]  R2677     4.1455361060798168e-03
    z[7,8,0]  R2678     -2.3684193193912506e-01
    z[7,8,0]  R2679     -3.7485834956169128e-01
    z[7,8,0]  R2680     -3.6465996503829956e-01
    z[7,8,0]  R2681     2.9203328490257263e-01
    z[7,8,0]  R2682     -6.6135597229003906e-01
    z[7,8,0]  R2683     3.9041861891746521e-01
    z[7,8,0]  R2684     0.06740702688694
    z[7,8,0]  R2685     -2.7967801690101624e-01
    z[7,8,0]  R2686     -7.1032392978668213e-01
    z[7,8,0]  R2687     5.2875989675521851e-01
    z[7,8,0]  R2688     3.4844768047332764e-01
    z[7,8,0]  R2689     2.0690768957138062e-01
    z[7,8,0]  R2690     -6.6474074125289917e-01
    z[7,8,0]  R2691     -5.2484017610549927e-01
    z[7,8,0]  R2692     2.9758960008621216e-01
    z[7,8,0]  R2693     -4.0893962979316711e-01
    z[7,8,0]  R2694     -3.6436259746551514e-01
    z[7,8,0]  R2695     4.1812849044799805e-01
    z[7,8,0]  R2696     7.8895963728427887e-02
    z[7,8,0]  R2697     3.8255488872528076e-01
    z[7,8,0]  R2698     -2.0790712535381317e-01
    z[7,8,0]  R2699     1.8902172148227692e-01
    z[7,8,0]  R2700     4.2085587978363037e-02
    z[7,8,0]  R2701     6.1813032627105713e-01
    z[7,8,0]  R2702     -4.4558876752853394e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2561     -1
    z[7,8,1]  R2562     1
    z[7,8,1]  R2573     1.1435882002115250e-01
    z[7,8,1]  R2574     4.0142297744750977e-01
    z[7,8,1]  R2575     7.6485341787338257e-01
    z[7,8,1]  R2576     5.3542929887771606e-01
    z[7,8,1]  R2577     7.8002071380615234e-01
    z[7,8,1]  R2578     1.3832345604896545e-01
    z[7,8,1]  R2579     -4.7877561300992966e-02
    z[7,8,1]  R2580     -6.3829831779003143e-02
    z[7,8,1]  R2581     3.1923419237136841e-01
    z[7,8,1]  R2582     2.3087453842163086e-01
    z[7,8,1]  R2583     -2.1191075444221497e-01
    z[7,8,1]  R2584     -5.8906716108322144e-01
    z[7,8,1]  R2585     -5.2865590900182724e-02
    z[7,8,1]  R2586     -4.4142669439315796e-01
    z[7,8,1]  R2587     -7.1289384365081787e-01
    z[7,8,1]  R2588     -5.0402671098709106e-01
    z[7,8,1]  R2589     -7.4249184131622314e-01
    z[7,8,1]  R2590     -5.9427630901336670e-01
    z[7,8,1]  R2591     -4.1634941101074219e-01
    z[7,8,1]  R2592     -0.832743227481842
    z[7,8,1]  R2593     -2.4929188191890717e-01
    z[7,8,1]  R2594     1.9046372175216675e-01
    z[7,8,1]  R2595     -1.8191392719745636e-01
    z[7,8,1]  R2596     -1.6768236458301544e-01
    z[7,8,1]  R2597     -0.133817657828331
    z[7,8,1]  R2598     -1.0523710399866104e-01
    z[7,8,1]  R2599     -9.5723263919353485e-02
    z[7,8,1]  R2600     -0.186284601688385
    z[7,8,1]  R2601     -4.1939345002174377e-01
    z[7,8,1]  R2602     -3.8949453830718994e-01
    z[7,8,1]  R2603     2.4423290044069290e-02
    z[7,8,1]  R2604     -4.4574740529060364e-01
    z[7,8,1]  R2605     -4.0387764573097229e-01
    z[7,8,1]  R2606     -2.6248106360435486e-01
    z[7,8,1]  R2607     -4.1414785385131836e-01
    z[7,8,1]  R2608     -1.8218639492988586e-01
    z[7,8,1]  R2609     -1.4169288624543697e-04
    z[7,8,1]  R2610     6.4466185867786407e-02
    z[7,8,1]  R2611     -1.2670651078224182e-01
    z[7,8,1]  R2612     -1.5292043983936310e-01
    z[7,8,1]  R2613     0.437441885471344
    z[7,8,1]  R2614     -2.9498405754566193e-02
    z[7,8,1]  R2615     -2.9368460178375244e-01
    z[7,8,1]  R2616     1.3990128040313721e-01
    z[7,8,1]  R2617     -2.5596305727958679e-01
    z[7,8,1]  R2618     1.6905392706394196e-01
    z[7,8,1]  R2619     -2.0205664634704590e-01
    z[7,8,1]  R2620     4.3392226099967957e-01
    z[7,8,1]  R2621     1.8731987476348877e-01
    z[7,8,1]  R2622     4.3244999647140503e-01
    z[7,8,1]  R2623     0.30374675989151
    z[7,8,1]  R2624     7.4504172801971436e-01
    z[7,8,1]  R2625     1.7645424604415894e-01
    z[7,8,1]  R2626     0.712421178817749
    z[7,8,1]  R2627     3.6899831891059875e-01
    z[7,8,1]  R2628     5.9653103351593018e-02
    z[7,8,1]  R2629     5.5840945243835449e-01
    z[7,8,1]  R2630     4.7310832142829895e-01
    z[7,8,1]  R2631     1.8774619698524475e-01
    z[7,8,1]  R2632     0.708575427532196
    z[7,8,1]  R2633     -5.0860875844955444e-01
    z[7,8,1]  R2634     -5.9739941358566284e-01
    z[7,8,1]  R2635     -5.6169933080673218e-01
    z[7,8,1]  R2636     -4.4880822300910950e-01
    z[7,8,1]  R2637     -5.3318786621093750e-01
    z[7,8,1]  R2638     -5.1414120197296143e-01
    z[7,8,1]  R2639     -3.5053873062133789e-01
    z[7,8,1]  R2640     3.0828055739402771e-01
    z[7,8,1]  R2641     5.2129125595092773e-01
    z[7,8,1]  R2642     5.5241715908050537e-01
    z[7,8,1]  R2643     6.9651472568511963e-01
    z[7,8,1]  R2644     6.7883557081222534e-01
    z[7,8,1]  R2645     6.0026526451110840e-01
    z[7,8,1]  R2646     5.7415229082107544e-01
    z[7,8,1]  R2647     5.8584743738174438e-01
    z[7,8,1]  R2648     5.5500334501266479e-01
    z[7,8,1]  R2649     5.3615683317184448e-01
    z[7,8,1]  R2650     0.540215015411377
    z[7,8,1]  R2651     6.7617017030715942e-01
    z[7,8,1]  R2652     7.3270970582962036e-01
    z[7,8,1]  R2653     7.4011689424514771e-01
    z[7,8,1]  R2654     7.8080952167510986e-01
    z[7,8,1]  R2655     6.4962941408157349e-01
    z[7,8,1]  R2656     7.3950606584548950e-01
    z[7,8,1]  R2657     7.0295256376266479e-01
    z[7,8,1]  R2658     -0.282776415348053
    z[7,8,1]  R2659     6.5165388584136963e-01
    z[7,8,1]  R2660     -6.9621199369430542e-01
    z[7,8,1]  R2661     -6.2677758932113647e-01
    z[7,8,1]  R2662     -6.9244033098220825e-01
    z[7,8,1]  R2663     4.4207695126533508e-01
    z[7,8,1]  R2664     9.8487166687846184e-03
    z[7,8,1]  R2665     1.4604867994785309e-01
    z[7,8,1]  R2666     -1.7323195934295654e-01
    z[7,8,1]  R2667     4.5368626713752747e-01
    z[7,8,1]  R2668     9.7142502665519714e-02
    z[7,8,1]  R2669     -6.1505597829818726e-01
    z[7,8,1]  R2670     -5.5039227008819580e-01
    z[7,8,1]  R2671     3.2359874248504639e-01
    z[7,8,1]  R2672     -6.2403416633605957e-01
    z[7,8,1]  R2673     8.3767253160476685e-01
    z[7,8,1]  R2674     7.2170168161392212e-01
    z[7,8,1]  R2675     7.8799778223037720e-01
    z[7,8,1]  R2676     0.663337767124176
    z[7,8,1]  R2677     -5.2512373775243759e-02
    z[7,8,1]  R2678     4.7200858592987061e-01
    z[7,8,1]  R2679     3.7658709287643433e-01
    z[7,8,1]  R2680     1.6975344717502594e-01
    z[7,8,1]  R2681     2.2284699603915215e-02
    z[7,8,1]  R2682     -4.1852882504463196e-01
    z[7,8,1]  R2683     0.803875207901001
    z[7,8,1]  R2684     -1.5951721370220184e-01
    z[7,8,1]  R2685     0.295402467250824
    z[7,8,1]  R2686     1.3658988475799561e-01
    z[7,8,1]  R2687     -4.7057133913040161e-01
    z[7,8,1]  R2688     -7.8113985061645508e-01
    z[7,8,1]  R2689     -6.2176591157913208e-01
    z[7,8,1]  R2690     -3.1555432081222534e-01
    z[7,8,1]  R2691     -7.0497810840606689e-01
    z[7,8,1]  R2692     -1.9482684135437012e-01
    z[7,8,1]  R2693     -6.5725374221801758e-01
    z[7,8,1]  R2694     -5.3161764144897461e-01
    z[7,8,1]  R2695     -7.3614805936813354e-01
    z[7,8,1]  R2696     -5.2352142333984375e-01
    z[7,8,1]  R2697     -1.1451903730630875e-01
    z[7,8,1]  R2698     -1.9247953593730927e-01
    z[7,8,1]  R2699     -3.2207658886909485e-01
    z[7,8,1]  R2700     -3.2849270105361938e-01
    z[7,8,1]  R2701     -5.9491980075836182e-01
    z[7,8,1]  R2702     -3.0491960048675537e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2563     -1
    z[7,8,2]  R2564     1
    z[7,8,2]  R2573     -3.3604586124420166e-01
    z[7,8,2]  R2574     -8.9773915708065033e-02
    z[7,8,2]  R2575     -2.6283088326454163e-01
    z[7,8,2]  R2576     -2.2129869461059570e-01
    z[7,8,2]  R2577     3.8711285591125488e-01
    z[7,8,2]  R2578     7.2691243886947632e-01
    z[7,8,2]  R2579     4.8589169979095459e-01
    z[7,8,2]  R2580     7.5987368822097778e-01
    z[7,8,2]  R2581     3.2897848635911942e-02
    z[7,8,2]  R2582     -8.8280633091926575e-02
    z[7,8,2]  R2583     4.2452374100685120e-01
    z[7,8,2]  R2584     -4.1473528742790222e-01
    z[7,8,2]  R2585     4.7904092073440552e-01
    z[7,8,2]  R2586     -3.3625373244285583e-01
    z[7,8,2]  R2587     -1.5323549509048462e-01
    z[7,8,2]  R2588     -2.1477967500686646e-01
    z[7,8,2]  R2589     -4.4494945555925369e-02
    z[7,8,2]  R2590     -4.4417638331651688e-02
    z[7,8,2]  R2591     5.2536106109619141e-01
    z[7,8,2]  R2592     -3.5484644770622253e-01
    z[7,8,2]  R2593     9.7630776464939117e-02
    z[7,8,2]  R2594     4.0585052967071533e-01
    z[7,8,2]  R2595     -2.9736492037773132e-01
    z[7,8,2]  R2596     6.2986373901367188e-01
    z[7,8,2]  R2597     2.7783477306365967e-01
    z[7,8,2]  R2598     -2.5348627567291260e-01
    z[7,8,2]  R2599     7.6207816600799561e-01
    z[7,8,2]  R2600     0.831156849861145
    z[7,8,2]  R2601     6.1910808086395264e-01
    z[7,8,2]  R2602     7.5966519117355347e-01
    z[7,8,2]  R2603     3.1685021519660950e-01
    z[7,8,2]  R2604     -3.6706620454788208e-01
    z[7,8,2]  R2605     -4.2125180363655090e-01
    z[7,8,2]  R2606     5.5523318052291870e-01
    z[7,8,2]  R2607     0.807011067867279
    z[7,8,2]  R2608     8.4683841466903687e-01
    z[7,8,2]  R2609     8.7419945001602173e-01
    z[7,8,2]  R2610     9.5148253440856934e-01
    z[7,8,2]  R2611     9.5361477136611938e-01
    z[7,8,2]  R2612     8.5782015323638916e-01
    z[7,8,2]  R2613     -3.0486200004816055e-02
    z[7,8,2]  R2614     -1.1528084427118301e-01
    z[7,8,2]  R2615     7.4738597869873047e-01
    z[7,8,2]  R2616     7.1247100830078125e-01
    z[7,8,2]  R2617     3.2485216856002808e-01
    z[7,8,2]  R2618     6.8495023250579834e-01
    z[7,8,2]  R2619     1.1261721700429916e-01
    z[7,8,2]  R2620     6.6891357302665710e-02
    z[7,8,2]  R2621     9.6072681248188019e-02
    z[7,8,2]  R2622     2.4772010743618011e-02
    z[7,8,2]  R2623     5.7814067602157593e-01
    z[7,8,2]  R2624     1.7388562858104706e-01
    z[7,8,2]  R2625     7.1906256675720215e-01
    z[7,8,2]  R2626     3.2191246747970581e-01
    z[7,8,2]  R2627     7.6544874906539917e-01
    z[7,8,2]  R2628     0.505023717880249
    z[7,8,2]  R2629     6.0721164941787720e-01
    z[7,8,2]  R2630     6.0207647085189819e-01
    z[7,8,2]  R2631     6.1139428615570068e-01
    z[7,8,2]  R2632     3.8345783948898315e-01
    z[7,8,2]  R2633     -2.9519745148718357e-03
    z[7,8,2]  R2634     -8.7089262902736664e-02
    z[7,8,2]  R2635     -3.4792459011077881e-01
    z[7,8,2]  R2636     -2.7005153894424438e-01
    z[7,8,2]  R2637     1.1014468967914581e-01
    z[7,8,2]  R2638     -2.5249516963958740e-01
    z[7,8,2]  R2639     0.0291758980602026
    z[7,8,2]  R2640     -3.0748954415321350e-01
    z[7,8,2]  R2641     -3.1573307514190674e-01
    z[7,8,2]  R2642     -4.2549693584442139e-01
    z[7,8,2]  R2643     -3.6064156889915466e-01
    z[7,8,2]  R2644     -1.0769446939229965e-01
    z[7,8,2]  R2645     -1.9698448479175568e-01
    z[7,8,2]  R2646     -4.9072912335395813e-01
    z[7,8,2]  R2647     9.0174175798892975e-02
    z[7,8,2]  R2648     -5.2778005599975586e-01
    z[7,8,2]  R2649     -5.9519398212432861e-01
    z[7,8,2]  R2650     -3.6995080113410950e-01
    z[7,8,2]  R2651     -2.0785297453403473e-01
    z[7,8,2]  R2652     1.1789846420288086e-01
    z[7,8,2]  R2653     -3.0639493465423584e-01
    z[7,8,2]  R2654     4.8860549926757812e-02
    z[7,8,2]  R2655     -5.4658007621765137e-01
    z[7,8,2]  R2656     1.6758209466934204e-01
    z[7,8,2]  R2657     1.1022539436817169e-01
    z[7,8,2]  R2658     -8.1075555086135864e-01
    z[7,8,2]  R2659     1.1862143874168396e-01
    z[7,8,2]  R2660     -5.5827546119689941e-01
    z[7,8,2]  R2661     -6.7261105775833130e-01
    z[7,8,2]  R2662     -3.8340216875076294e-01
    z[7,8,2]  R2663     -5.7558870315551758e-01
    z[7,8,2]  R2664     -2.4053406715393066e-01
    z[7,8,2]  R2665     -3.0332398414611816e-01
    z[7,8,2]  R2666     -2.5991985201835632e-01
    z[7,8,2]  R2667     -9.3733951449394226e-02
    z[7,8,2]  R2668     -3.3817071467638016e-02
    z[7,8,2]  R2669     -4.5310333371162415e-01
    z[7,8,2]  R2670     -2.0347027480602264e-01
    z[7,8,2]  R2671     0.270241916179657
    z[7,8,2]  R2672     -3.4853389859199524e-01
    z[7,8,2]  R2673     3.8999080657958984e-02
    z[7,8,2]  R2674     -1.0526547580957413e-01
    z[7,8,2]  R2675     1.4102604985237122e-01
    z[7,8,2]  R2676     -3.3617219328880310e-01
    z[7,8,2]  R2677     -5.4828923940658569e-01
    z[7,8,2]  R2678     -4.7268554568290710e-01
    z[7,8,2]  R2679     -6.1010879278182983e-01
    z[7,8,2]  R2680     -2.1281237900257111e-01
    z[7,8,2]  R2681     -4.4417455792427063e-01
    z[7,8,2]  R2682     -1.3416640460491180e-01
    z[7,8,2]  R2683     -1.1298751085996628e-01
    z[7,8,2]  R2684     -4.2926058173179626e-01
    z[7,8,2]  R2685     -5.7679069042205811e-01
    z[7,8,2]  R2686     1.8374128639698029e-01
    z[7,8,2]  R2687     -3.8103365898132324e-01
    z[7,8,2]  R2688     -1.4756055176258087e-01
    z[7,8,2]  R2689     4.2118526995182037e-02
    z[7,8,2]  R2690     -0.535280704498291
    z[7,8,2]  R2691     2.7376702427864075e-01
    z[7,8,2]  R2692     -0.0871121808886528
    z[7,8,2]  R2693     -3.8658180832862854e-01
    z[7,8,2]  R2694     -5.9542137384414673e-01
    z[7,8,2]  R2695     -2.0386219024658203e-01
    z[7,8,2]  R2696     -9.4626814126968384e-02
    z[7,8,2]  R2697     -1.6701258718967438e-01
    z[7,8,2]  R2698     -1.1634702235460281e-01
    z[7,8,2]  R2699     3.6156069836579263e-04
    z[7,8,2]  R2700     1.2524689733982086e-01
    z[7,8,2]  R2701     -7.1765370666980743e-02
    z[7,8,2]  R2702     8.1551790237426758e-02
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2565     -1
    z[7,8,3]  R2566     1
    z[7,8,3]  R2573     1.7860975861549377e-01
    z[7,8,3]  R2574     3.2187944650650024e-01
    z[7,8,3]  R2575     1.0834605433046818e-02
    z[7,8,3]  R2576     3.2391202449798584e-01
    z[7,8,3]  R2577     2.0039199292659760e-01
    z[7,8,3]  R2578     1.2313036620616913e-01
    z[7,8,3]  R2579     -1.6694139689207077e-02
    z[7,8,3]  R2580     1.9584544003009796e-01
    z[7,8,3]  R2581     -7.0980352163314819e-01
    z[7,8,3]  R2582     -7.1118837594985962e-01
    z[7,8,3]  R2583     -2.2603254020214081e-01
    z[7,8,3]  R2584     -5.7955193519592285e-01
    z[7,8,3]  R2585     -1.2480422854423523e-01
    z[7,8,3]  R2586     -2.7611499652266502e-02
    z[7,8,3]  R2587     1.1606021970510483e-01
    z[7,8,3]  R2588     -0.664367139339447
    z[7,8,3]  R2589     -4.7494283318519592e-01
    z[7,8,3]  R2590     -4.8844027519226074e-01
    z[7,8,3]  R2591     -1.0250040888786316e-01
    z[7,8,3]  R2592     4.6880498528480530e-02
    z[7,8,3]  R2593     1.5337735414505005e-01
    z[7,8,3]  R2594     6.7403799295425415e-01
    z[7,8,3]  R2595     -3.1837800145149231e-01
    z[7,8,3]  R2596     -4.4210964441299438e-01
    z[7,8,3]  R2597     -3.6278063058853149e-01
    z[7,8,3]  R2598     4.9592819809913635e-01
    z[7,8,3]  R2599     1.2239511311054230e-01
    z[7,8,3]  R2600     2.6496684551239014e-01
    z[7,8,3]  R2601     0.199748694896698
    z[7,8,3]  R2602     3.2743549346923828e-01
    z[7,8,3]  R2603     7.1964037418365479e-01
    z[7,8,3]  R2604     2.1272291243076324e-01
    z[7,8,3]  R2605     -5.7984054088592529e-01
    z[7,8,3]  R2606     -4.1433432698249817e-01
    z[7,8,3]  R2607     1.1915339529514313e-01
    z[7,8,3]  R2608     -1.1254362016916275e-01
    z[7,8,3]  R2609     2.7752781286835670e-02
    z[7,8,3]  R2610     9.9605210125446320e-03
    z[7,8,3]  R2611     -1.5184667706489563e-01
    z[7,8,3]  R2612     -1.8563267588615417e-01
    z[7,8,3]  R2613     3.1545478105545044e-01
    z[7,8,3]  R2614     -2.9333594441413879e-01
    z[7,8,3]  R2615     1.9253598153591156e-01
    z[7,8,3]  R2616     -1.1768083274364471e-01
    z[7,8,3]  R2617     0.0886588916182518
    z[7,8,3]  R2618     -3.5248023271560669e-01
    z[7,8,3]  R2619     -2.3124119639396667e-01
    z[7,8,3]  R2620     -6.5944540500640869e-01
    z[7,8,3]  R2621     -6.8610537052154541e-01
    z[7,8,3]  R2622     -7.5621813535690308e-01
    z[7,8,3]  R2623     5.1857795566320419e-02
    z[7,8,3]  R2624     1.8211877346038818e-01
    z[7,8,3]  R2625     1.1691156774759293e-01
    z[7,8,3]  R2626     -1.8961118161678314e-01
    z[7,8,3]  R2627     1.5626855194568634e-01
    z[7,8,3]  R2628     -8.3744160830974579e-02
    z[7,8,3]  R2629     1.5992085635662079e-01
    z[7,8,3]  R2630     -2.7161669731140137e-01
    z[7,8,3]  R2631     -1.2416200339794159e-01
    z[7,8,3]  R2632     3.6150798201560974e-02
    z[7,8,3]  R2633     -7.4238038063049316e-01
    z[7,8,3]  R2634     -3.5980746150016785e-01
    z[7,8,3]  R2635     -5.8321952819824219e-01
    z[7,8,3]  R2636     -2.1688893437385559e-01
    z[7,8,3]  R2637     -4.7954815626144409e-01
    z[7,8,3]  R2638     -5.9930962324142456e-01
    z[7,8,3]  R2639     -3.8831308484077454e-01
    z[7,8,3]  R2640     -5.0890469551086426e-01
    z[7,8,3]  R2641     -2.4170038104057312e-01
    z[7,8,3]  R2642     -3.9172795414924622e-01
    z[7,8,3]  R2643     1.9254611432552338e-01
    z[7,8,3]  R2644     2.5090974569320679e-01
    z[7,8,3]  R2645     2.9566147923469543e-01
    z[7,8,3]  R2646     -2.8940621018409729e-01
    z[7,8,3]  R2647     0.402680367231369
    z[7,8,3]  R2648     4.0484678745269775e-01
    z[7,8,3]  R2649     1.3354191184043884e-01
    z[7,8,3]  R2650     3.8730335235595703e-01
    z[7,8,3]  R2651     -0.429853230714798
    z[7,8,3]  R2652     -4.6079343557357788e-01
    z[7,8,3]  R2653     -3.1336975097656250e-01
    z[7,8,3]  R2654     -1.7450611293315887e-01
    z[7,8,3]  R2655     -2.0374611020088196e-01
    z[7,8,3]  R2656     4.9226158857345581e-01
    z[7,8,3]  R2657     -1.2572954595088959e-01
    z[7,8,3]  R2658     -3.4273895621299744e-01
    z[7,8,3]  R2659     1.3936059176921844e-01
    z[7,8,3]  R2660     1.9586777687072754e-01
    z[7,8,3]  R2661     1.9571746885776520e-01
    z[7,8,3]  R2662     4.9618965387344360e-01
    z[7,8,3]  R2663     -2.1210125088691711e-01
    z[7,8,3]  R2664     -0.767402708530426
    z[7,8,3]  R2665     -5.0298583507537842e-01
    z[7,8,3]  R2666     2.3538877069950104e-01
    z[7,8,3]  R2667     2.0210632681846619e-01
    z[7,8,3]  R2668     -7.3404544591903687e-01
    z[7,8,3]  R2669     -0.00976675283163786
    z[7,8,3]  R2670     -7.7435187995433807e-02
    z[7,8,3]  R2671     -7.9551786184310913e-01
    z[7,8,3]  R2672     1.9590778648853302e-01
    z[7,8,3]  R2673     -1.2370344996452332e-01
    z[7,8,3]  R2674     -1.1679595708847046e-01
    z[7,8,3]  R2675     -2.1719770133495331e-01
    z[7,8,3]  R2676     -1.4076061546802521e-01
    z[7,8,3]  R2677     -6.8923436105251312e-02
    z[7,8,3]  R2678     -4.8576775938272476e-02
    z[7,8,3]  R2679     -5.0221878290176392e-01
    z[7,8,3]  R2680     -7.7450329065322876e-01
    z[7,8,3]  R2681     -4.3196612596511841e-01
    z[7,8,3]  R2682     -3.6524653434753418e-02
    z[7,8,3]  R2683     -9.0609379112720490e-02
    z[7,8,3]  R2684     -7.5901877880096436e-01
    z[7,8,3]  R2685     -5.9787321090698242e-01
    z[7,8,3]  R2686     -5.1823216676712036e-01
    z[7,8,3]  R2687     2.4977408349514008e-01
    z[7,8,3]  R2688     1.6055627167224884e-01
    z[7,8,3]  R2689     0.374318391084671
    z[7,8,3]  R2690     2.2835499048233032e-01
    z[7,8,3]  R2691     2.3273542523384094e-01
    z[7,8,3]  R2692     8.0029904842376709e-01
    z[7,8,3]  R2693     -1.9853542745113373e-01
    z[7,8,3]  R2694     -2.3308378458023071e-01
    z[7,8,3]  R2695     1.1561270803213120e-01
    z[7,8,3]  R2696     4.7575098276138306e-01
    z[7,8,3]  R2697     6.0858130455017090e-01
    z[7,8,3]  R2698     8.5577911138534546e-01
    z[7,8,3]  R2699     0.516191840171814
    z[7,8,3]  R2700     0.539966881275177
    z[7,8,3]  R2701     1.7886368930339813e-01
    z[7,8,3]  R2702     5.5466693639755249e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2567     -1
    z[7,8,4]  R2568     1
    z[7,8,4]  R2573     1.6010291874408722e-02
    z[7,8,4]  R2574     -1.0964769870042801e-01
    z[7,8,4]  R2575     2.1156449615955353e-01
    z[7,8,4]  R2576     0.655748188495636
    z[7,8,4]  R2577     -1.4161817729473114e-01
    z[7,8,4]  R2578     6.3251096010208130e-01
    z[7,8,4]  R2579     3.9920559525489807e-01
    z[7,8,4]  R2580     -6.1699371784925461e-02
    z[7,8,4]  R2581     3.5262140631675720e-01
    z[7,8,4]  R2582     -2.7352491393685341e-02
    z[7,8,4]  R2583     3.0771702527999878e-01
    z[7,8,4]  R2584     0.307492196559906
    z[7,8,4]  R2585     4.6538379788398743e-01
    z[7,8,4]  R2586     -2.9700118303298950e-01
    z[7,8,4]  R2587     -3.9172884821891785e-01
    z[7,8,4]  R2588     2.1518760919570923e-01
    z[7,8,4]  R2589     -1.0180468112230301e-01
    z[7,8,4]  R2590     2.2309435904026031e-01
    z[7,8,4]  R2591     -0.0850767120718956
    z[7,8,4]  R2592     -1.1955167353153229e-01
    z[7,8,4]  R2593     -8.1110924482345581e-01
    z[7,8,4]  R2594     -1.0898580402135849e-01
    z[7,8,4]  R2595     5.5226337909698486e-01
    z[7,8,4]  R2596     4.8057359457015991e-01
    z[7,8,4]  R2597     7.1364927291870117e-01
    z[7,8,4]  R2598     2.6871958374977112e-01
    z[7,8,4]  R2599     5.2876341342926025e-01
    z[7,8,4]  R2600     1.1409211903810501e-01
    z[7,8,4]  R2601     2.6202520728111267e-01
    z[7,8,4]  R2602     2.4984866380691528e-01
    z[7,8,4]  R2603     -3.6618936061859131e-01
    z[7,8,4]  R2604     -1.6661860048770905e-02
    z[7,8,4]  R2605     4.3248176574707031e-01
    z[7,8,4]  R2606     2.5308316946029663e-01
    z[7,8,4]  R2607     2.0223341882228851e-01
    z[7,8,4]  R2608     3.3913221955299377e-01
    z[7,8,4]  R2609     3.0128675699234009e-01
    z[7,8,4]  R2610     1.3564477860927582e-01
    z[7,8,4]  R2611     -2.7488607913255692e-02
    z[7,8,4]  R2612     4.8106640577316284e-02
    z[7,8,4]  R2613     -3.4481963515281677e-01
    z[7,8,4]  R2614     -2.0610374212265015e-01
    z[7,8,4]  R2615     2.7970704436302185e-01
    z[7,8,4]  R2616     5.1321285963058472e-01
    z[7,8,4]  R2617     6.8382078409194946e-01
    z[7,8,4]  R2618     7.9613149166107178e-02
    z[7,8,4]  R2619     5.0367474555969238e-01
    z[7,8,4]  R2620     -1.6412030905485153e-02
    z[7,8,4]  R2621     5.0547290593385696e-02
    z[7,8,4]  R2622     -2.2112096846103668e-01
    z[7,8,4]  R2623     -3.0929857864975929e-02
    z[7,8,4]  R2624     4.3862223625183105e-02
    z[7,8,4]  R2625     -7.1362167596817017e-02
    z[7,8,4]  R2626     3.4079080820083618e-01
    z[7,8,4]  R2627     -0.17815001308918
    z[7,8,4]  R2628     -5.3338829427957535e-02
    z[7,8,4]  R2629     1.8202421069145203e-01
    z[7,8,4]  R2630     -1.1549197370186448e-03
    z[7,8,4]  R2631     1.7097112536430359e-01
    z[7,8,4]  R2632     1.6588468849658966e-01
    z[7,8,4]  R2633     -1.0755776613950729e-01
    z[7,8,4]  R2634     -3.3011589199304581e-02
    z[7,8,4]  R2635     1.8318261206150055e-01
    z[7,8,4]  R2636     -0.0909905806183815
    z[7,8,4]  R2637     -1.9154475629329681e-01
    z[7,8,4]  R2638     -1.0848290473222733e-01
    z[7,8,4]  R2639     -1.0991883277893066e-01
    z[7,8,4]  R2640     5.4228086024522781e-02
    z[7,8,4]  R2641     3.8252902030944824e-01
    z[7,8,4]  R2642     -4.4202274084091187e-01
    z[7,8,4]  R2643     -2.9359623789787292e-01
    z[7,8,4]  R2644     2.5340250134468079e-01
    z[7,8,4]  R2645     -2.7820026874542236e-01
    z[7,8,4]  R2646     2.5382417440414429e-01
    z[7,8,4]  R2647     -7.9937517642974854e-02
    z[7,8,4]  R2648     -3.2220691442489624e-01
    z[7,8,4]  R2649     3.4887593239545822e-02
    z[7,8,4]  R2650     5.7678680866956711e-02
    z[7,8,4]  R2651     -3.5977670550346375e-01
    z[7,8,4]  R2652     -1.0594666749238968e-01
    z[7,8,4]  R2653     1.8152515590190887e-01
    z[7,8,4]  R2654     -3.5370573401451111e-01
    z[7,8,4]  R2655     -7.6284185051918030e-02
    z[7,8,4]  R2656     -2.6278996467590332e-01
    z[7,8,4]  R2657     -5.0045949220657349e-01
    z[7,8,4]  R2658     9.5087058842182159e-02
    z[7,8,4]  R2659     1.3192920386791229e-01
    z[7,8,4]  R2660     -3.7163820862770081e-01
    z[7,8,4]  R2661     -1.5029367804527283e-01
    z[7,8,4]  R2662     -1.3495387136936188e-01
    z[7,8,4]  R2663     -2.0871834456920624e-01
    z[7,8,4]  R2664     1.8678975105285645e-01
    z[7,8,4]  R2665     2.5995094329118729e-02
    z[7,8,4]  R2666     2.8754368424415588e-01
    z[7,8,4]  R2667     2.7865159511566162e-01
    z[7,8,4]  R2668     -7.7265299856662750e-02
    z[7,8,4]  R2669     3.5431340336799622e-01
    z[7,8,4]  R2670     1.9545695185661316e-01
    z[7,8,4]  R2671     5.7299785315990448e-02
    z[7,8,4]  R2672     -8.0676466226577759e-02
    z[7,8,4]  R2673     7.4233666062355042e-02
    z[7,8,4]  R2674     -2.9526667669415474e-02
    z[7,8,4]  R2675     -1.7548096179962158e-01
    z[7,8,4]  R2676     -2.5313866138458252e-01
    z[7,8,4]  R2677     3.1068675220012665e-02
    z[7,8,4]  R2678     6.0402441024780273e-01
    z[7,8,4]  R2679     -2.0315755903720856e-01
    z[7,8,4]  R2680     -1.1944981664419174e-01
    z[7,8,4]  R2681     -3.3345988392829895e-01
    z[7,8,4]  R2682     4.9226564168930054e-01
    z[7,8,4]  R2683     0.192902609705925
    z[7,8,4]  R2684     -1.0200403630733490e-01
    z[7,8,4]  R2685     2.3301427066326141e-01
    z[7,8,4]  R2686     -3.9524596929550171e-01
    z[7,8,4]  R2687     -2.6711821556091309e-01
    z[7,8,4]  R2688     -4.3883770704269409e-01
    z[7,8,4]  R2689     -5.2055913209915161e-01
    z[7,8,4]  R2690     -7.5289912521839142e-02
    z[7,8,4]  R2691     -1.4688414335250854e-01
    z[7,8,4]  R2692     -4.3398797512054443e-01
    z[7,8,4]  R2693     3.2364809513092041e-01
    z[7,8,4]  R2694     3.2094126939773560e-01
    z[7,8,4]  R2695     -4.4822499155998230e-01
    z[7,8,4]  R2696     -5.5237084627151489e-01
    z[7,8,4]  R2697     -4.7012698650360107e-01
    z[7,8,4]  R2698     -3.3907783031463623e-01
    z[7,8,4]  R2699     -3.8905680179595947e-01
    z[7,8,4]  R2700     -3.0298039317131042e-01
    z[7,8,4]  R2701     5.9135757386684418e-02
    z[7,8,4]  R2702     -2.5848689675331116e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2569     -1
    z[7,8,5]  R2570     1
    z[7,8,5]  R2573     6.1092805862426758e-01
    z[7,8,5]  R2574     0.305328369140625
    z[7,8,5]  R2575     -3.2644817233085632e-01
    z[7,8,5]  R2576     2.7013307809829712e-01
    z[7,8,5]  R2577     3.8586756587028503e-01
    z[7,8,5]  R2578     -1.1724155396223068e-02
    z[7,8,5]  R2579     -5.4554667323827744e-02
    z[7,8,5]  R2580     -1.7589065432548523e-01
    z[7,8,5]  R2581     7.0996925234794617e-02
    z[7,8,5]  R2582     4.9334344267845154e-01
    z[7,8,5]  R2583     -0.647737979888916
    z[7,8,5]  R2584     2.6006600819528103e-03
    z[7,8,5]  R2585     -3.1988570094108582e-01
    z[7,8,5]  R2586     -5.3647315502166748e-01
    z[7,8,5]  R2587     -3.3451077342033386e-01
    z[7,8,5]  R2588     3.8160249590873718e-02
    z[7,8,5]  R2589     0.247584730386734
    z[7,8,5]  R2590     1.7031347751617432e-01
    z[7,8,5]  R2591     -3.9729550480842590e-01
    z[7,8,5]  R2592     2.6620325446128845e-01
    z[7,8,5]  R2593     -9.6859313547611237e-02
    z[7,8,5]  R2594     3.9680776000022888e-01
    z[7,8,5]  R2595     3.8803797960281372e-01
    z[7,8,5]  R2596     -3.6811605095863342e-01
    z[7,8,5]  R2597     -4.5355820655822754e-01
    z[7,8,5]  R2598     -3.7679061293601990e-01
    z[7,8,5]  R2599     -9.9245734512805939e-02
    z[7,8,5]  R2600     -3.6069911718368530e-01
    z[7,8,5]  R2601     -4.9722501635551453e-01
    z[7,8,5]  R2602     -6.0913139022886753e-03
    z[7,8,5]  R2603     -3.0868908762931824e-01
    z[7,8,5]  R2604     -2.5204730033874512e-01
    z[7,8,5]  R2605     2.2183644771575928e-01
    z[7,8,5]  R2606     -2.9326236248016357e-01
    z[7,8,5]  R2607     -2.0866183936595917e-01
    z[7,8,5]  R2608     -9.8147220909595490e-02
    z[7,8,5]  R2609     -2.2753703594207764e-01
    z[7,8,5]  R2610     -2.1214932203292847e-01
    z[7,8,5]  R2611     -1.6605599224567413e-01
    z[7,8,5]  R2612     -1.2479253858327866e-01
    z[7,8,5]  R2613     -5.0345528125762939e-01
    z[7,8,5]  R2614     0.754705548286438
    z[7,8,5]  R2615     -2.9630449414253235e-01
    z[7,8,5]  R2616     -3.5210517048835754e-01
    z[7,8,5]  R2617     -2.0151783525943756e-01
    z[7,8,5]  R2618     -5.6089985370635986e-01
    z[7,8,5]  R2619     -1.1960883438587189e-01
    z[7,8,5]  R2620     -2.6464805006980896e-01
    z[7,8,5]  R2621     -6.1810355633497238e-02
    z[7,8,5]  R2622     -4.4104088097810745e-02
    z[7,8,5]  R2623     -7.0518068969249725e-02
    z[7,8,5]  R2624     2.9320802539587021e-02
    z[7,8,5]  R2625     1.6049274802207947e-01
    z[7,8,5]  R2626     9.7442999482154846e-02
    z[7,8,5]  R2627     1.2150280922651291e-01
    z[7,8,5]  R2628     6.1087656766176224e-02
    z[7,8,5]  R2629     -8.9247547090053558e-02
    z[7,8,5]  R2630     8.4644109010696411e-02
    z[7,8,5]  R2631     2.7353477478027344e-01
    z[7,8,5]  R2632     4.0036666393280029e-01
    z[7,8,5]  R2633     3.6903893947601318e-01
    z[7,8,5]  R2634     6.8073374032974243e-01
    z[7,8,5]  R2635     4.3479007482528687e-01
    z[7,8,5]  R2636     8.1305164098739624e-01
    z[7,8,5]  R2637     5.3321695327758789e-01
    z[7,8,5]  R2638     4.6339431405067444e-01
    z[7,8,5]  R2639     5.6345325708389282e-01
    z[7,8,5]  R2640     -2.1080057322978973e-01
    z[7,8,5]  R2641     -0.598402738571167
    z[7,8,5]  R2642     1.0290031135082245e-01
    z[7,8,5]  R2643     -4.8102951049804688e-01
    z[7,8,5]  R2644     2.3012389242649078e-01
    z[7,8,5]  R2645     4.5984706282615662e-01
    z[7,8,5]  R2646     1.4776639640331268e-01
    z[7,8,5]  R2647     -5.0973349809646606e-01
    z[7,8,5]  R2648     1.6818402707576752e-01
    z[7,8,5]  R2649     -3.8613748550415039e-01
    z[7,8,5]  R2650     2.5651791691780090e-01
    z[7,8,5]  R2651     -2.0864118635654449e-01
    z[7,8,5]  R2652     2.4168965220451355e-01
    z[7,8,5]  R2653     3.4985315799713135e-01
    z[7,8,5]  R2654     0.411308616399765
    z[7,8,5]  R2655     1.1703790724277496e-01
    z[7,8,5]  R2656     -3.2389920949935913e-01
    z[7,8,5]  R2657     -0.0661073550581932
    z[7,8,5]  R2658     2.2231031954288483e-01
    z[7,8,5]  R2659     -2.4207718670368195e-01
    z[7,8,5]  R2660     -6.9456794299185276e-03
    z[7,8,5]  R2661     4.4466793537139893e-02
    z[7,8,5]  R2662     2.6548272371292114e-01
    z[7,8,5]  R2663     -2.4890737235546112e-01
    z[7,8,5]  R2664     -2.2501491010189056e-01
    z[7,8,5]  R2665     -1.0241493582725525e-01
    z[7,8,5]  R2666     7.6932793855667114e-01
    z[7,8,5]  R2667     7.6607394218444824e-01
    z[7,8,5]  R2668     8.9728303253650665e-02
    z[7,8,5]  R2669     -3.3832769840955734e-03
    z[7,8,5]  R2670     2.5807055830955505e-01
    z[7,8,5]  R2671     -2.2562643885612488e-01
    z[7,8,5]  R2672     1.8531037867069244e-01
    z[7,8,5]  R2673     -1.9545707106590271e-01
    z[7,8,5]  R2674     -1.3591052591800690e-01
    z[7,8,5]  R2675     -1.4011819660663605e-01
    z[7,8,5]  R2676     -5.3619122505187988e-01
    z[7,8,5]  R2677     8.0709677934646606e-01
    z[7,8,5]  R2678     -1.8276451528072357e-01
    z[7,8,5]  R2679     -1.6230879724025726e-01
    z[7,8,5]  R2680     2.7760567143559456e-02
    z[7,8,5]  R2681     6.0488367080688477e-01
    z[7,8,5]  R2682     3.2660558819770813e-01
    z[7,8,5]  R2683     3.5799962282180786e-01
    z[7,8,5]  R2684     4.3259340524673462e-01
    z[7,8,5]  R2685     -2.1127325296401978e-01
    z[7,8,5]  R2686     1.3093756139278412e-01
    z[7,8,5]  R2687     3.7043792009353638e-01
    z[7,8,5]  R2688     -0.0495392307639122
    z[7,8,5]  R2689     3.2732561230659485e-01
    z[7,8,5]  R2690     -2.2811965644359589e-01
    z[7,8,5]  R2691     -2.7723529934883118e-01
    z[7,8,5]  R2692     -1.8648815155029297e-01
    z[7,8,5]  R2693     3.0621299147605896e-01
    z[7,8,5]  R2694     1.3879445195198059e-01
    z[7,8,5]  R2695     1.6501431167125702e-01
    z[7,8,5]  R2696     3.9671370387077332e-01
    z[7,8,5]  R2697     -4.4743424654006958e-01
    z[7,8,5]  R2698     -2.1514873206615448e-01
    z[7,8,5]  R2699     -6.6480213403701782e-01
    z[7,8,5]  R2700     -7.0080637931823730e-01
    z[7,8,5]  R2701     5.6166354566812515e-02
    z[7,8,5]  R2702     -0.560685932636261
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2571     -1
    z[7,8,6]  R2572     1
    z[7,8,6]  R2573     -1.9635464251041412e-01
    z[7,8,6]  R2574     -5.5271911621093750e-01
    z[7,8,6]  R2575     -2.3895850777626038e-01
    z[7,8,6]  R2576     4.4609103351831436e-03
    z[7,8,6]  R2577     -1.1613752692937851e-01
    z[7,8,6]  R2578     -5.3179364651441574e-02
    z[7,8,6]  R2579     -6.2002742290496826e-01
    z[7,8,6]  R2580     -4.5243588089942932e-01
    z[7,8,6]  R2581     -0.295798122882843
    z[7,8,6]  R2582     -2.5345128774642944e-01
    z[7,8,6]  R2583     1.7758010327816010e-01
    z[7,8,6]  R2584     1.2392652779817581e-01
    z[7,8,6]  R2585     -3.2880410552024841e-01
    z[7,8,6]  R2586     1.3284260034561157e-01
    z[7,8,6]  R2587     -0.0349249504506588
    z[7,8,6]  R2588     -9.8057381808757782e-02
    z[7,8,6]  R2589     -1.4266440272331238e-01
    z[7,8,6]  R2590     -9.4616673886775970e-02
    z[7,8,6]  R2591     1.0085908323526382e-01
    z[7,8,6]  R2592     1.7898587882518768e-01
    z[7,8,6]  R2593     1.4067785441875458e-01
    z[7,8,6]  R2594     4.1401076316833496e-01
    z[7,8,6]  R2595     4.6701654791831970e-01
    z[7,8,6]  R2596     1.0725246369838715e-01
    z[7,8,6]  R2597     3.5518039017915726e-02
    z[7,8,6]  R2598     4.4076108932495117e-01
    z[7,8,6]  R2599     1.7334438860416412e-01
    z[7,8,6]  R2600     2.4198049306869507e-01
    z[7,8,6]  R2601     2.2133606672286987e-01
    z[7,8,6]  R2602     1.7766645550727844e-01
    z[7,8,6]  R2603     -1.2828439474105835e-01
    z[7,8,6]  R2604     4.6037697792053223e-01
    z[7,8,6]  R2605     -2.1246072649955750e-01
    z[7,8,6]  R2606     -1.1773724108934402e-01
    z[7,8,6]  R2607     -1.4549601078033447e-01
    z[7,8,6]  R2608     -3.0574795603752136e-01
    z[7,8,6]  R2609     2.2659644484519958e-01
    z[7,8,6]  R2610     3.5989217460155487e-02
    z[7,8,6]  R2611     -7.9660356044769287e-02
    z[7,8,6]  R2612     -2.7802494168281555e-01
    z[7,8,6]  R2613     7.3532208800315857e-02
    z[7,8,6]  R2614     3.6037430167198181e-01
    z[7,8,6]  R2615     2.0212219655513763e-01
    z[7,8,6]  R2616     -2.4569953978061676e-01
    z[7,8,6]  R2617     3.2126274704933167e-01
    z[7,8,6]  R2618     -2.0595690608024597e-01
    z[7,8,6]  R2619     3.0520647764205933e-01
    z[7,8,6]  R2620     6.3805043697357178e-02
    z[7,8,6]  R2621     -1.4203125238418579e-01
    z[7,8,6]  R2622     1.0419698059558868e-01
    z[7,8,6]  R2623     -1.4853195846080780e-01
    z[7,8,6]  R2624     -6.0669219493865967e-01
    z[7,8,6]  R2625     3.8330513983964920e-02
    z[7,8,6]  R2626     -3.5251826047897339e-01
    z[7,8,6]  R2627     -9.1001898050308228e-02
    z[7,8,6]  R2628     1.1751641333103180e-01
    z[7,8,6]  R2629     4.5755349099636078e-02
    z[7,8,6]  R2630     2.4354528635740280e-02
    z[7,8,6]  R2631     -5.3508855402469635e-02
    z[7,8,6]  R2632     -2.3536704480648041e-01
    z[7,8,6]  R2633     1.1895284801721573e-01
    z[7,8,6]  R2634     -1.0439812391996384e-01
    z[7,8,6]  R2635     1.0300076566636562e-02
    z[7,8,6]  R2636     -6.8263687193393707e-02
    z[7,8,6]  R2637     -3.1316304206848145e-01
    z[7,8,6]  R2638     -2.7121287584304810e-01
    z[7,8,6]  R2639     -5.6809592247009277e-01
    z[7,8,6]  R2640     -9.1780908405780792e-02
    z[7,8,6]  R2641     2.5107720494270325e-01
    z[7,8,6]  R2642     8.4061108529567719e-02
    z[7,8,6]  R2643     1.1446928232908249e-01
    z[7,8,6]  R2644     5.7627558708190918e-01
    z[7,8,6]  R2645     -4.0148171782493591e-01
    z[7,8,6]  R2646     -4.9632743000984192e-01
    z[7,8,6]  R2647     -2.4001958966255188e-01
    z[7,8,6]  R2648     8.0292999744415283e-02
    z[7,8,6]  R2649     -0.263278603553772
    z[7,8,6]  R2650     -3.5444416105747223e-02
    z[7,8,6]  R2651     -3.1469020247459412e-01
    z[7,8,6]  R2652     4.0821629762649536e-01
    z[7,8,6]  R2653     2.0155639946460724e-01
    z[7,8,6]  R2654     -2.5141993165016174e-01
    z[7,8,6]  R2655     3.7151420116424561e-01
    z[7,8,6]  R2656     8.0253079533576965e-02
    z[7,8,6]  R2657     -1.4116473495960236e-01
    z[7,8,6]  R2658     2.5778514146804810e-01
    z[7,8,6]  R2659     5.3164589405059814e-01
    z[7,8,6]  R2660     1.2013272196054459e-01
    z[7,8,6]  R2661     -2.3785415291786194e-01
    z[7,8,6]  R2662     -1.9478686153888702e-01
    z[7,8,6]  R2663     -4.6476888656616211e-01
    z[7,8,6]  R2664     1.7436721920967102e-01
    z[7,8,6]  R2665     -6.8205338716506958e-01
    z[7,8,6]  R2666     1.2163235992193222e-01
    z[7,8,6]  R2667     -2.7614856138825417e-02
    z[7,8,6]  R2668     -5.3601509332656860e-01
    z[7,8,6]  R2669     -3.3391021192073822e-02
    z[7,8,6]  R2670     -5.5280399322509766e-01
    z[7,8,6]  R2671     -2.1958464756608009e-02
    z[7,8,6]  R2672     2.9406201839447021e-01
    z[7,8,6]  R2673     2.1542693674564362e-01
    z[7,8,6]  R2674     -2.3527100682258606e-01
    z[7,8,6]  R2675     4.8838317394256592e-01
    z[7,8,6]  R2676     -1.5909896790981293e-01
    z[7,8,6]  R2677     0.198703795671463
    z[7,8,6]  R2678     -3.1156727671623230e-01
    z[7,8,6]  R2679     -1.5996801853179932e-01
    z[7,8,6]  R2680     -0.421928346157074
    z[7,8,6]  R2681     2.3076918721199036e-01
    z[7,8,6]  R2682     1.3824053108692169e-01
    z[7,8,6]  R2683     0.122501440346241
    z[7,8,6]  R2684     1.0997556149959564e-01
    z[7,8,6]  R2685     -2.1318021416664124e-01
    z[7,8,6]  R2686     -3.3069238066673279e-02
    z[7,8,6]  R2687     2.8779405355453491e-01
    z[7,8,6]  R2688     -1.6068504750728607e-01
    z[7,8,6]  R2689     2.2490942478179932e-01
    z[7,8,6]  R2690     -2.4933236837387085e-01
    z[7,8,6]  R2691     -2.3067300207912922e-04
    z[7,8,6]  R2692     -4.7878619283437729e-02
    z[7,8,6]  R2693     -1.1579968780279160e-01
    z[7,8,6]  R2694     2.3130239546298981e-01
    z[7,8,6]  R2695     -1.3899651356041431e-02
    z[7,8,6]  R2696     1.4802783727645874e-01
    z[7,8,6]  R2697     -1.4510647952556610e-01
    z[7,8,6]  R2698     -1.1211130023002625e-01
    z[7,8,6]  R2699     -2.7499282732605934e-02
    z[7,8,6]  R2700     1.1985295452177525e-02
    z[7,8,6]  R2701     -4.6924528479576111e-01
    z[7,8,6]  R2702     -1.1394876986742020e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2703     -1
    z[8,7,0]  R2704     1
    z[8,7,0]  R2717     7.3675704002380371e-01
    z[8,7,0]  R2718     1.0319972038269043e-01
    z[8,7,0]  R2719     6.3704389333724976e-01
    z[8,7,0]  R2720     3.2089483737945557e-01
    z[8,7,0]  R2721     4.4578793644905090e-01
    z[8,7,0]  R2722     8.4498089551925659e-01
    z[8,7,0]  R2723     5.0070625543594360e-01
    z[8,7,0]  R2724     5.7631397247314453e-01
    z[8,7,0]  R2725     6.8455582857131958e-01
    z[8,7,0]  R2726     -3.2613688707351685e-01
    z[8,7,0]  R2727     -1.6814163327217102e-01
    z[8,7,0]  R2728     -1.7515951395034790e-01
    z[8,7,0]  R2729     -2.4347655475139618e-02
    z[8,7,0]  R2730     -0.0678994357585907
    z[8,7,0]  R2731     -2.3351998627185822e-01
    z[8,7,0]  R2732     1.1257733404636383e-01
    z[8,7,0]  R2733     -2.7053564786911011e-01
    z[8,7,0]  R2734     -7.0400846004486084e-01
    z[8,7,0]  R2735     -5.1912359893321991e-02
    z[8,7,0]  R2736     3.8379433751106262e-01
    z[8,7,0]  R2737     -1.3053552806377411e-01
    z[8,7,0]  R2738     -1.2395630031824112e-01
    z[8,7,0]  R2739     -2.5183475017547607e-01
    z[8,7,0]  R2740     0.114784836769104
    z[8,7,0]  R2741     -4.0332657098770142e-01
    z[8,7,0]  R2742     3.3311915397644043e-01
    z[8,7,0]  R2743     0.347579687833786
    z[8,7,0]  R2744     5.9238141775131226e-01
    z[8,7,0]  R2745     -2.0692250132560730e-01
    z[8,7,0]  R2746     2.5033403187990189e-02
    z[8,7,0]  R2747     -2.5332754850387573e-01
    z[8,7,0]  R2748     -1.5056604752317071e-03
    z[8,7,0]  R2749     -2.8315967321395874e-01
    z[8,7,0]  R2750     4.8121601343154907e-02
    z[8,7,0]  R2751     4.5071363449096680e-01
    z[8,7,0]  R2752     -1.4257016777992249e-01
    z[8,7,0]  R2753     -4.2801958322525024e-01
    z[8,7,0]  R2754     -1.1250866204500198e-01
    z[8,7,0]  R2755     1.8788002431392670e-01
    z[8,7,0]  R2756     -2.6258345693349838e-02
    z[8,7,0]  R2757     -3.2672667503356934e-01
    z[8,7,0]  R2758     -4.8704558610916138e-01
    z[8,7,0]  R2759     -3.9662095904350281e-01
    z[8,7,0]  R2760     -3.9709344506263733e-01
    z[8,7,0]  R2761     2.8152653574943542e-01
    z[8,7,0]  R2762     -0.386346697807312
    z[8,7,0]  R2763     -5.3818565607070923e-01
    z[8,7,0]  R2764     -4.8915845155715942e-01
    z[8,7,0]  R2765     -3.6705833673477173e-01
    z[8,7,0]  R2766     5.6868660449981689e-01
    z[8,7,0]  R2767     -4.3744522333145142e-01
    z[8,7,0]  R2768     -6.1622118949890137e-01
    z[8,7,0]  R2769     1.5182720124721527e-01
    z[8,7,0]  R2770     2.2419843077659607e-01
    z[8,7,0]  R2771     4.1455361060798168e-03
    z[8,7,0]  R2772     -2.3684193193912506e-01
    z[8,7,0]  R2773     -3.7485834956169128e-01
    z[8,7,0]  R2774     -3.6465996503829956e-01
    z[8,7,0]  R2775     2.9203328490257263e-01
    z[8,7,0]  R2776     -6.6135597229003906e-01
    z[8,7,0]  R2777     3.9041861891746521e-01
    z[8,7,0]  R2778     0.06740702688694
    z[8,7,0]  R2779     -2.7967801690101624e-01
    z[8,7,0]  R2780     -7.1032392978668213e-01
    z[8,7,0]  R2781     5.2875989675521851e-01
    z[8,7,0]  R2782     3.4844768047332764e-01
    z[8,7,0]  R2783     2.0690768957138062e-01
    z[8,7,0]  R2784     -6.6474074125289917e-01
    z[8,7,0]  R2785     -5.2484017610549927e-01
    z[8,7,0]  R2786     2.9758960008621216e-01
    z[8,7,0]  R2787     -4.0893962979316711e-01
    z[8,7,0]  R2788     -3.6436259746551514e-01
    z[8,7,0]  R2789     4.1812849044799805e-01
    z[8,7,0]  R2790     7.8895963728427887e-02
    z[8,7,0]  R2791     3.8255488872528076e-01
    z[8,7,0]  R2792     -2.0790712535381317e-01
    z[8,7,0]  R2793     1.8902172148227692e-01
    z[8,7,0]  R2794     4.2085587978363037e-02
    z[8,7,0]  R2795     6.1813032627105713e-01
    z[8,7,0]  R2796     -4.4558876752853394e-01
    z[8,7,0]  R2797     6.5578132867813110e-01
    z[8,7,0]  R2798     5.6253653764724731e-01
    z[8,7,0]  R2799     3.7063813209533691e-01
    z[8,7,0]  R2800     2.3754149675369263e-01
    z[8,7,0]  R2801     -0.138264000415802
    z[8,7,0]  R2802     -1.8511675298213959e-01
    z[8,7,0]  R2803     -4.6320948004722595e-01
    z[8,7,0]  R2804     -3.7512639164924622e-01
    z[8,7,0]  R2805     -4.1988947987556458e-01
    z[8,7,0]  R2806     -0.35318723320961
    z[8,7,0]  R2807     -0.421892911195755
    z[8,7,0]  R2808     -1.8761147558689117e-01
    z[8,7,0]  R2809     -5.7019978761672974e-01
    z[8,7,0]  R2810     5.4557597637176514e-01
    z[8,7,0]  R2811     4.3389233946800232e-01
    z[8,7,0]  R2812     -4.4840371608734131e-01
    z[8,7,0]  R2813     -3.5936030745506287e-01
    z[8,7,0]  R2814     -5.6440997123718262e-01
    z[8,7,0]  R2815     -6.0405993461608887e-01
    z[8,7,0]  R2816     -2.4745118618011475e-01
    z[8,7,0]  R2817     4.6661216020584106e-01
    z[8,7,0]  R2818     6.2787905335426331e-02
    z[8,7,0]  R2819     -3.2162716984748840e-01
    z[8,7,0]  R2820     4.1591387242078781e-02
    z[8,7,0]  R2821     -2.3878654837608337e-01
    z[8,7,0]  R2822     5.1987826824188232e-01
    z[8,7,0]  R2823     -2.7496299147605896e-01
    z[8,7,0]  R2824     5.0926379859447479e-02
    z[8,7,0]  R2825     -1.8982946872711182e-01
    z[8,7,0]  R2826     -2.6450318098068237e-01
    z[8,7,0]  R2827     0.367813378572464
    z[8,7,0]  R2828     5.8785051107406616e-01
    z[8,7,0]  R2829     -2.0450721681118011e-01
    z[8,7,0]  R2830     -5.3593933582305908e-01
    z[8,7,0]  R2831     -0.239603653550148
    z[8,7,0]  R2832     -1.3740982115268707e-01
    z[8,7,0]  R2833     2.0276165008544922e-01
    z[8,7,0]  R2834     -1.6038633882999420e-01
    z[8,7,0]  R2835     -1.2973412871360779e-01
    z[8,7,0]  R2836     -3.3333939313888550e-01
    z[8,7,0]  R2837     5.7482933998107910e-01
    z[8,7,0]  R2838     -3.9732262492179871e-01
    z[8,7,0]  R2839     -3.3347824215888977e-01
    z[8,7,0]  R2840     -1.0597234219312668e-01
    z[8,7,0]  R2841     -4.5789030194282532e-01
    z[8,7,0]  R2842     -1.2106350809335709e-01
    z[8,7,0]  R2843     -7.2929584980010986e-01
    z[8,7,0]  R2844     -5.4588454961776733e-01
    z[8,7,0]  R2845     -6.7704671621322632e-01
    z[8,7,0]  R2846     -4.2286023497581482e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2705     -1
    z[8,7,1]  R2706     1
    z[8,7,1]  R2717     0.30374675989151
    z[8,7,1]  R2718     7.4504172801971436e-01
    z[8,7,1]  R2719     1.7645424604415894e-01
    z[8,7,1]  R2720     0.712421178817749
    z[8,7,1]  R2721     3.6899831891059875e-01
    z[8,7,1]  R2722     5.9653103351593018e-02
    z[8,7,1]  R2723     5.5840945243835449e-01
    z[8,7,1]  R2724     4.7310832142829895e-01
    z[8,7,1]  R2725     1.8774619698524475e-01
    z[8,7,1]  R2726     0.708575427532196
    z[8,7,1]  R2727     -5.0860875844955444e-01
    z[8,7,1]  R2728     -5.9739941358566284e-01
    z[8,7,1]  R2729     -5.6169933080673218e-01
    z[8,7,1]  R2730     -4.4880822300910950e-01
    z[8,7,1]  R2731     -5.3318786621093750e-01
    z[8,7,1]  R2732     -5.1414120197296143e-01
    z[8,7,1]  R2733     -3.5053873062133789e-01
    z[8,7,1]  R2734     3.0828055739402771e-01
    z[8,7,1]  R2735     5.2129125595092773e-01
    z[8,7,1]  R2736     5.5241715908050537e-01
    z[8,7,1]  R2737     6.9651472568511963e-01
    z[8,7,1]  R2738     6.7883557081222534e-01
    z[8,7,1]  R2739     6.0026526451110840e-01
    z[8,7,1]  R2740     5.7415229082107544e-01
    z[8,7,1]  R2741     5.8584743738174438e-01
    z[8,7,1]  R2742     5.5500334501266479e-01
    z[8,7,1]  R2743     5.3615683317184448e-01
    z[8,7,1]  R2744     0.540215015411377
    z[8,7,1]  R2745     6.7617017030715942e-01
    z[8,7,1]  R2746     7.3270970582962036e-01
    z[8,7,1]  R2747     7.4011689424514771e-01
    z[8,7,1]  R2748     7.8080952167510986e-01
    z[8,7,1]  R2749     6.4962941408157349e-01
    z[8,7,1]  R2750     7.3950606584548950e-01
    z[8,7,1]  R2751     7.0295256376266479e-01
    z[8,7,1]  R2752     -0.282776415348053
    z[8,7,1]  R2753     6.5165388584136963e-01
    z[8,7,1]  R2754     -6.9621199369430542e-01
    z[8,7,1]  R2755     -6.2677758932113647e-01
    z[8,7,1]  R2756     -6.9244033098220825e-01
    z[8,7,1]  R2757     4.4207695126533508e-01
    z[8,7,1]  R2758     9.8487166687846184e-03
    z[8,7,1]  R2759     1.4604867994785309e-01
    z[8,7,1]  R2760     -1.7323195934295654e-01
    z[8,7,1]  R2761     4.5368626713752747e-01
    z[8,7,1]  R2762     9.7142502665519714e-02
    z[8,7,1]  R2763     -6.1505597829818726e-01
    z[8,7,1]  R2764     -5.5039227008819580e-01
    z[8,7,1]  R2765     3.2359874248504639e-01
    z[8,7,1]  R2766     -6.2403416633605957e-01
    z[8,7,1]  R2767     8.3767253160476685e-01
    z[8,7,1]  R2768     7.2170168161392212e-01
    z[8,7,1]  R2769     7.8799778223037720e-01
    z[8,7,1]  R2770     0.663337767124176
    z[8,7,1]  R2771     -5.2512373775243759e-02
    z[8,7,1]  R2772     4.7200858592987061e-01
    z[8,7,1]  R2773     3.7658709287643433e-01
    z[8,7,1]  R2774     1.6975344717502594e-01
    z[8,7,1]  R2775     2.2284699603915215e-02
    z[8,7,1]  R2776     -4.1852882504463196e-01
    z[8,7,1]  R2777     0.803875207901001
    z[8,7,1]  R2778     -1.5951721370220184e-01
    z[8,7,1]  R2779     0.295402467250824
    z[8,7,1]  R2780     1.3658988475799561e-01
    z[8,7,1]  R2781     -4.7057133913040161e-01
    z[8,7,1]  R2782     -7.8113985061645508e-01
    z[8,7,1]  R2783     -6.2176591157913208e-01
    z[8,7,1]  R2784     -3.1555432081222534e-01
    z[8,7,1]  R2785     -7.0497810840606689e-01
    z[8,7,1]  R2786     -1.9482684135437012e-01
    z[8,7,1]  R2787     -6.5725374221801758e-01
    z[8,7,1]  R2788     -5.3161764144897461e-01
    z[8,7,1]  R2789     -7.3614805936813354e-01
    z[8,7,1]  R2790     -5.2352142333984375e-01
    z[8,7,1]  R2791     -1.1451903730630875e-01
    z[8,7,1]  R2792     -1.9247953593730927e-01
    z[8,7,1]  R2793     -3.2207658886909485e-01
    z[8,7,1]  R2794     -3.2849270105361938e-01
    z[8,7,1]  R2795     -5.9491980075836182e-01
    z[8,7,1]  R2796     -3.0491960048675537e-01
    z[8,7,1]  R2797     1.1435882002115250e-01
    z[8,7,1]  R2798     4.0142297744750977e-01
    z[8,7,1]  R2799     7.6485341787338257e-01
    z[8,7,1]  R2800     5.3542929887771606e-01
    z[8,7,1]  R2801     7.8002071380615234e-01
    z[8,7,1]  R2802     1.3832345604896545e-01
    z[8,7,1]  R2803     -4.7877561300992966e-02
    z[8,7,1]  R2804     -6.3829831779003143e-02
    z[8,7,1]  R2805     3.1923419237136841e-01
    z[8,7,1]  R2806     2.3087453842163086e-01
    z[8,7,1]  R2807     -2.1191075444221497e-01
    z[8,7,1]  R2808     -5.8906716108322144e-01
    z[8,7,1]  R2809     -5.2865590900182724e-02
    z[8,7,1]  R2810     -4.4142669439315796e-01
    z[8,7,1]  R2811     -7.1289384365081787e-01
    z[8,7,1]  R2812     -5.0402671098709106e-01
    z[8,7,1]  R2813     -7.4249184131622314e-01
    z[8,7,1]  R2814     -5.9427630901336670e-01
    z[8,7,1]  R2815     -4.1634941101074219e-01
    z[8,7,1]  R2816     -0.832743227481842
    z[8,7,1]  R2817     -2.4929188191890717e-01
    z[8,7,1]  R2818     1.9046372175216675e-01
    z[8,7,1]  R2819     -1.8191392719745636e-01
    z[8,7,1]  R2820     -1.6768236458301544e-01
    z[8,7,1]  R2821     -0.133817657828331
    z[8,7,1]  R2822     -1.0523710399866104e-01
    z[8,7,1]  R2823     -9.5723263919353485e-02
    z[8,7,1]  R2824     -0.186284601688385
    z[8,7,1]  R2825     -4.1939345002174377e-01
    z[8,7,1]  R2826     -3.8949453830718994e-01
    z[8,7,1]  R2827     2.4423290044069290e-02
    z[8,7,1]  R2828     -4.4574740529060364e-01
    z[8,7,1]  R2829     -4.0387764573097229e-01
    z[8,7,1]  R2830     -2.6248106360435486e-01
    z[8,7,1]  R2831     -4.1414785385131836e-01
    z[8,7,1]  R2832     -1.8218639492988586e-01
    z[8,7,1]  R2833     -1.4169288624543697e-04
    z[8,7,1]  R2834     6.4466185867786407e-02
    z[8,7,1]  R2835     -1.2670651078224182e-01
    z[8,7,1]  R2836     -1.5292043983936310e-01
    z[8,7,1]  R2837     0.437441885471344
    z[8,7,1]  R2838     -2.9498405754566193e-02
    z[8,7,1]  R2839     -2.9368460178375244e-01
    z[8,7,1]  R2840     1.3990128040313721e-01
    z[8,7,1]  R2841     -2.5596305727958679e-01
    z[8,7,1]  R2842     1.6905392706394196e-01
    z[8,7,1]  R2843     -2.0205664634704590e-01
    z[8,7,1]  R2844     4.3392226099967957e-01
    z[8,7,1]  R2845     1.8731987476348877e-01
    z[8,7,1]  R2846     4.3244999647140503e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2707     -1
    z[8,7,2]  R2708     1
    z[8,7,2]  R2717     5.7814067602157593e-01
    z[8,7,2]  R2718     1.7388562858104706e-01
    z[8,7,2]  R2719     7.1906256675720215e-01
    z[8,7,2]  R2720     3.2191246747970581e-01
    z[8,7,2]  R2721     7.6544874906539917e-01
    z[8,7,2]  R2722     0.505023717880249
    z[8,7,2]  R2723     6.0721164941787720e-01
    z[8,7,2]  R2724     6.0207647085189819e-01
    z[8,7,2]  R2725     6.1139428615570068e-01
    z[8,7,2]  R2726     3.8345783948898315e-01
    z[8,7,2]  R2727     -2.9519745148718357e-03
    z[8,7,2]  R2728     -8.7089262902736664e-02
    z[8,7,2]  R2729     -3.4792459011077881e-01
    z[8,7,2]  R2730     -2.7005153894424438e-01
    z[8,7,2]  R2731     1.1014468967914581e-01
    z[8,7,2]  R2732     -2.5249516963958740e-01
    z[8,7,2]  R2733     0.0291758980602026
    z[8,7,2]  R2734     -3.0748954415321350e-01
    z[8,7,2]  R2735     -3.1573307514190674e-01
    z[8,7,2]  R2736     -4.2549693584442139e-01
    z[8,7,2]  R2737     -3.6064156889915466e-01
    z[8,7,2]  R2738     -1.0769446939229965e-01
    z[8,7,2]  R2739     -1.9698448479175568e-01
    z[8,7,2]  R2740     -4.9072912335395813e-01
    z[8,7,2]  R2741     9.0174175798892975e-02
    z[8,7,2]  R2742     -5.2778005599975586e-01
    z[8,7,2]  R2743     -5.9519398212432861e-01
    z[8,7,2]  R2744     -3.6995080113410950e-01
    z[8,7,2]  R2745     -2.0785297453403473e-01
    z[8,7,2]  R2746     1.1789846420288086e-01
    z[8,7,2]  R2747     -3.0639493465423584e-01
    z[8,7,2]  R2748     4.8860549926757812e-02
    z[8,7,2]  R2749     -5.4658007621765137e-01
    z[8,7,2]  R2750     1.6758209466934204e-01
    z[8,7,2]  R2751     1.1022539436817169e-01
    z[8,7,2]  R2752     -8.1075555086135864e-01
    z[8,7,2]  R2753     1.1862143874168396e-01
    z[8,7,2]  R2754     -5.5827546119689941e-01
    z[8,7,2]  R2755     -6.7261105775833130e-01
    z[8,7,2]  R2756     -3.8340216875076294e-01
    z[8,7,2]  R2757     -5.7558870315551758e-01
    z[8,7,2]  R2758     -2.4053406715393066e-01
    z[8,7,2]  R2759     -3.0332398414611816e-01
    z[8,7,2]  R2760     -2.5991985201835632e-01
    z[8,7,2]  R2761     -9.3733951449394226e-02
    z[8,7,2]  R2762     -3.3817071467638016e-02
    z[8,7,2]  R2763     -4.5310333371162415e-01
    z[8,7,2]  R2764     -2.0347027480602264e-01
    z[8,7,2]  R2765     0.270241916179657
    z[8,7,2]  R2766     -3.4853389859199524e-01
    z[8,7,2]  R2767     3.8999080657958984e-02
    z[8,7,2]  R2768     -1.0526547580957413e-01
    z[8,7,2]  R2769     1.4102604985237122e-01
    z[8,7,2]  R2770     -3.3617219328880310e-01
    z[8,7,2]  R2771     -5.4828923940658569e-01
    z[8,7,2]  R2772     -4.7268554568290710e-01
    z[8,7,2]  R2773     -6.1010879278182983e-01
    z[8,7,2]  R2774     -2.1281237900257111e-01
    z[8,7,2]  R2775     -4.4417455792427063e-01
    z[8,7,2]  R2776     -1.3416640460491180e-01
    z[8,7,2]  R2777     -1.1298751085996628e-01
    z[8,7,2]  R2778     -4.2926058173179626e-01
    z[8,7,2]  R2779     -5.7679069042205811e-01
    z[8,7,2]  R2780     1.8374128639698029e-01
    z[8,7,2]  R2781     -3.8103365898132324e-01
    z[8,7,2]  R2782     -1.4756055176258087e-01
    z[8,7,2]  R2783     4.2118526995182037e-02
    z[8,7,2]  R2784     -0.535280704498291
    z[8,7,2]  R2785     2.7376702427864075e-01
    z[8,7,2]  R2786     -0.0871121808886528
    z[8,7,2]  R2787     -3.8658180832862854e-01
    z[8,7,2]  R2788     -5.9542137384414673e-01
    z[8,7,2]  R2789     -2.0386219024658203e-01
    z[8,7,2]  R2790     -9.4626814126968384e-02
    z[8,7,2]  R2791     -1.6701258718967438e-01
    z[8,7,2]  R2792     -1.1634702235460281e-01
    z[8,7,2]  R2793     3.6156069836579263e-04
    z[8,7,2]  R2794     1.2524689733982086e-01
    z[8,7,2]  R2795     -7.1765370666980743e-02
    z[8,7,2]  R2796     8.1551790237426758e-02
    z[8,7,2]  R2797     -3.3604586124420166e-01
    z[8,7,2]  R2798     -8.9773915708065033e-02
    z[8,7,2]  R2799     -2.6283088326454163e-01
    z[8,7,2]  R2800     -2.2129869461059570e-01
    z[8,7,2]  R2801     3.8711285591125488e-01
    z[8,7,2]  R2802     7.2691243886947632e-01
    z[8,7,2]  R2803     4.8589169979095459e-01
    z[8,7,2]  R2804     7.5987368822097778e-01
    z[8,7,2]  R2805     3.2897848635911942e-02
    z[8,7,2]  R2806     -8.8280633091926575e-02
    z[8,7,2]  R2807     4.2452374100685120e-01
    z[8,7,2]  R2808     -4.1473528742790222e-01
    z[8,7,2]  R2809     4.7904092073440552e-01
    z[8,7,2]  R2810     -3.3625373244285583e-01
    z[8,7,2]  R2811     -1.5323549509048462e-01
    z[8,7,2]  R2812     -2.1477967500686646e-01
    z[8,7,2]  R2813     -4.4494945555925369e-02
    z[8,7,2]  R2814     -4.4417638331651688e-02
    z[8,7,2]  R2815     5.2536106109619141e-01
    z[8,7,2]  R2816     -3.5484644770622253e-01
    z[8,7,2]  R2817     9.7630776464939117e-02
    z[8,7,2]  R2818     4.0585052967071533e-01
    z[8,7,2]  R2819     -2.9736492037773132e-01
    z[8,7,2]  R2820     6.2986373901367188e-01
    z[8,7,2]  R2821     2.7783477306365967e-01
    z[8,7,2]  R2822     -2.5348627567291260e-01
    z[8,7,2]  R2823     7.6207816600799561e-01
    z[8,7,2]  R2824     0.831156849861145
    z[8,7,2]  R2825     6.1910808086395264e-01
    z[8,7,2]  R2826     7.5966519117355347e-01
    z[8,7,2]  R2827     3.1685021519660950e-01
    z[8,7,2]  R2828     -3.6706620454788208e-01
    z[8,7,2]  R2829     -4.2125180363655090e-01
    z[8,7,2]  R2830     5.5523318052291870e-01
    z[8,7,2]  R2831     0.807011067867279
    z[8,7,2]  R2832     8.4683841466903687e-01
    z[8,7,2]  R2833     8.7419945001602173e-01
    z[8,7,2]  R2834     9.5148253440856934e-01
    z[8,7,2]  R2835     9.5361477136611938e-01
    z[8,7,2]  R2836     8.5782015323638916e-01
    z[8,7,2]  R2837     -3.0486200004816055e-02
    z[8,7,2]  R2838     -1.1528084427118301e-01
    z[8,7,2]  R2839     7.4738597869873047e-01
    z[8,7,2]  R2840     7.1247100830078125e-01
    z[8,7,2]  R2841     3.2485216856002808e-01
    z[8,7,2]  R2842     6.8495023250579834e-01
    z[8,7,2]  R2843     1.1261721700429916e-01
    z[8,7,2]  R2844     6.6891357302665710e-02
    z[8,7,2]  R2845     9.6072681248188019e-02
    z[8,7,2]  R2846     2.4772010743618011e-02
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2709     -1
    z[8,7,3]  R2710     1
    z[8,7,3]  R2717     5.1857795566320419e-02
    z[8,7,3]  R2718     1.8211877346038818e-01
    z[8,7,3]  R2719     1.1691156774759293e-01
    z[8,7,3]  R2720     -1.8961118161678314e-01
    z[8,7,3]  R2721     1.5626855194568634e-01
    z[8,7,3]  R2722     -8.3744160830974579e-02
    z[8,7,3]  R2723     1.5992085635662079e-01
    z[8,7,3]  R2724     -2.7161669731140137e-01
    z[8,7,3]  R2725     -1.2416200339794159e-01
    z[8,7,3]  R2726     3.6150798201560974e-02
    z[8,7,3]  R2727     -7.4238038063049316e-01
    z[8,7,3]  R2728     -3.5980746150016785e-01
    z[8,7,3]  R2729     -5.8321952819824219e-01
    z[8,7,3]  R2730     -2.1688893437385559e-01
    z[8,7,3]  R2731     -4.7954815626144409e-01
    z[8,7,3]  R2732     -5.9930962324142456e-01
    z[8,7,3]  R2733     -3.8831308484077454e-01
    z[8,7,3]  R2734     -5.0890469551086426e-01
    z[8,7,3]  R2735     -2.4170038104057312e-01
    z[8,7,3]  R2736     -3.9172795414924622e-01
    z[8,7,3]  R2737     1.9254611432552338e-01
    z[8,7,3]  R2738     2.5090974569320679e-01
    z[8,7,3]  R2739     2.9566147923469543e-01
    z[8,7,3]  R2740     -2.8940621018409729e-01
    z[8,7,3]  R2741     0.402680367231369
    z[8,7,3]  R2742     4.0484678745269775e-01
    z[8,7,3]  R2743     1.3354191184043884e-01
    z[8,7,3]  R2744     3.8730335235595703e-01
    z[8,7,3]  R2745     -0.429853230714798
    z[8,7,3]  R2746     -4.6079343557357788e-01
    z[8,7,3]  R2747     -3.1336975097656250e-01
    z[8,7,3]  R2748     -1.7450611293315887e-01
    z[8,7,3]  R2749     -2.0374611020088196e-01
    z[8,7,3]  R2750     4.9226158857345581e-01
    z[8,7,3]  R2751     -1.2572954595088959e-01
    z[8,7,3]  R2752     -3.4273895621299744e-01
    z[8,7,3]  R2753     1.3936059176921844e-01
    z[8,7,3]  R2754     1.9586777687072754e-01
    z[8,7,3]  R2755     1.9571746885776520e-01
    z[8,7,3]  R2756     4.9618965387344360e-01
    z[8,7,3]  R2757     -2.1210125088691711e-01
    z[8,7,3]  R2758     -0.767402708530426
    z[8,7,3]  R2759     -5.0298583507537842e-01
    z[8,7,3]  R2760     2.3538877069950104e-01
    z[8,7,3]  R2761     2.0210632681846619e-01
    z[8,7,3]  R2762     -7.3404544591903687e-01
    z[8,7,3]  R2763     -0.00976675283163786
    z[8,7,3]  R2764     -7.7435187995433807e-02
    z[8,7,3]  R2765     -7.9551786184310913e-01
    z[8,7,3]  R2766     1.9590778648853302e-01
    z[8,7,3]  R2767     -1.2370344996452332e-01
    z[8,7,3]  R2768     -1.1679595708847046e-01
    z[8,7,3]  R2769     -2.1719770133495331e-01
    z[8,7,3]  R2770     -1.4076061546802521e-01
    z[8,7,3]  R2771     -6.8923436105251312e-02
    z[8,7,3]  R2772     -4.8576775938272476e-02
    z[8,7,3]  R2773     -5.0221878290176392e-01
    z[8,7,3]  R2774     -7.7450329065322876e-01
    z[8,7,3]  R2775     -4.3196612596511841e-01
    z[8,7,3]  R2776     -3.6524653434753418e-02
    z[8,7,3]  R2777     -9.0609379112720490e-02
    z[8,7,3]  R2778     -7.5901877880096436e-01
    z[8,7,3]  R2779     -5.9787321090698242e-01
    z[8,7,3]  R2780     -5.1823216676712036e-01
    z[8,7,3]  R2781     2.4977408349514008e-01
    z[8,7,3]  R2782     1.6055627167224884e-01
    z[8,7,3]  R2783     0.374318391084671
    z[8,7,3]  R2784     2.2835499048233032e-01
    z[8,7,3]  R2785     2.3273542523384094e-01
    z[8,7,3]  R2786     8.0029904842376709e-01
    z[8,7,3]  R2787     -1.9853542745113373e-01
    z[8,7,3]  R2788     -2.3308378458023071e-01
    z[8,7,3]  R2789     1.1561270803213120e-01
    z[8,7,3]  R2790     4.7575098276138306e-01
    z[8,7,3]  R2791     6.0858130455017090e-01
    z[8,7,3]  R2792     8.5577911138534546e-01
    z[8,7,3]  R2793     0.516191840171814
    z[8,7,3]  R2794     0.539966881275177
    z[8,7,3]  R2795     1.7886368930339813e-01
    z[8,7,3]  R2796     5.5466693639755249e-01
    z[8,7,3]  R2797     1.7860975861549377e-01
    z[8,7,3]  R2798     3.2187944650650024e-01
    z[8,7,3]  R2799     1.0834605433046818e-02
    z[8,7,3]  R2800     3.2391202449798584e-01
    z[8,7,3]  R2801     2.0039199292659760e-01
    z[8,7,3]  R2802     1.2313036620616913e-01
    z[8,7,3]  R2803     -1.6694139689207077e-02
    z[8,7,3]  R2804     1.9584544003009796e-01
    z[8,7,3]  R2805     -7.0980352163314819e-01
    z[8,7,3]  R2806     -7.1118837594985962e-01
    z[8,7,3]  R2807     -2.2603254020214081e-01
    z[8,7,3]  R2808     -5.7955193519592285e-01
    z[8,7,3]  R2809     -1.2480422854423523e-01
    z[8,7,3]  R2810     -2.7611499652266502e-02
    z[8,7,3]  R2811     1.1606021970510483e-01
    z[8,7,3]  R2812     -0.664367139339447
    z[8,7,3]  R2813     -4.7494283318519592e-01
    z[8,7,3]  R2814     -4.8844027519226074e-01
    z[8,7,3]  R2815     -1.0250040888786316e-01
    z[8,7,3]  R2816     4.6880498528480530e-02
    z[8,7,3]  R2817     1.5337735414505005e-01
    z[8,7,3]  R2818     6.7403799295425415e-01
    z[8,7,3]  R2819     -3.1837800145149231e-01
    z[8,7,3]  R2820     -4.4210964441299438e-01
    z[8,7,3]  R2821     -3.6278063058853149e-01
    z[8,7,3]  R2822     4.9592819809913635e-01
    z[8,7,3]  R2823     1.2239511311054230e-01
    z[8,7,3]  R2824     2.6496684551239014e-01
    z[8,7,3]  R2825     0.199748694896698
    z[8,7,3]  R2826     3.2743549346923828e-01
    z[8,7,3]  R2827     7.1964037418365479e-01
    z[8,7,3]  R2828     2.1272291243076324e-01
    z[8,7,3]  R2829     -5.7984054088592529e-01
    z[8,7,3]  R2830     -4.1433432698249817e-01
    z[8,7,3]  R2831     1.1915339529514313e-01
    z[8,7,3]  R2832     -1.1254362016916275e-01
    z[8,7,3]  R2833     2.7752781286835670e-02
    z[8,7,3]  R2834     9.9605210125446320e-03
    z[8,7,3]  R2835     -1.5184667706489563e-01
    z[8,7,3]  R2836     -1.8563267588615417e-01
    z[8,7,3]  R2837     3.1545478105545044e-01
    z[8,7,3]  R2838     -2.9333594441413879e-01
    z[8,7,3]  R2839     1.9253598153591156e-01
    z[8,7,3]  R2840     -1.1768083274364471e-01
    z[8,7,3]  R2841     0.0886588916182518
    z[8,7,3]  R2842     -3.5248023271560669e-01
    z[8,7,3]  R2843     -2.3124119639396667e-01
    z[8,7,3]  R2844     -6.5944540500640869e-01
    z[8,7,3]  R2845     -6.8610537052154541e-01
    z[8,7,3]  R2846     -7.5621813535690308e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2711     -1
    z[8,7,4]  R2712     1
    z[8,7,4]  R2717     -3.0929857864975929e-02
    z[8,7,4]  R2718     4.3862223625183105e-02
    z[8,7,4]  R2719     -7.1362167596817017e-02
    z[8,7,4]  R2720     3.4079080820083618e-01
    z[8,7,4]  R2721     -0.17815001308918
    z[8,7,4]  R2722     -5.3338829427957535e-02
    z[8,7,4]  R2723     1.8202421069145203e-01
    z[8,7,4]  R2724     -1.1549197370186448e-03
    z[8,7,4]  R2725     1.7097112536430359e-01
    z[8,7,4]  R2726     1.6588468849658966e-01
    z[8,7,4]  R2727     -1.0755776613950729e-01
    z[8,7,4]  R2728     -3.3011589199304581e-02
    z[8,7,4]  R2729     1.8318261206150055e-01
    z[8,7,4]  R2730     -0.0909905806183815
    z[8,7,4]  R2731     -1.9154475629329681e-01
    z[8,7,4]  R2732     -1.0848290473222733e-01
    z[8,7,4]  R2733     -1.0991883277893066e-01
    z[8,7,4]  R2734     5.4228086024522781e-02
    z[8,7,4]  R2735     3.8252902030944824e-01
    z[8,7,4]  R2736     -4.4202274084091187e-01
    z[8,7,4]  R2737     -2.9359623789787292e-01
    z[8,7,4]  R2738     2.5340250134468079e-01
    z[8,7,4]  R2739     -2.7820026874542236e-01
    z[8,7,4]  R2740     2.5382417440414429e-01
    z[8,7,4]  R2741     -7.9937517642974854e-02
    z[8,7,4]  R2742     -3.2220691442489624e-01
    z[8,7,4]  R2743     3.4887593239545822e-02
    z[8,7,4]  R2744     5.7678680866956711e-02
    z[8,7,4]  R2745     -3.5977670550346375e-01
    z[8,7,4]  R2746     -1.0594666749238968e-01
    z[8,7,4]  R2747     1.8152515590190887e-01
    z[8,7,4]  R2748     -3.5370573401451111e-01
    z[8,7,4]  R2749     -7.6284185051918030e-02
    z[8,7,4]  R2750     -2.6278996467590332e-01
    z[8,7,4]  R2751     -5.0045949220657349e-01
    z[8,7,4]  R2752     9.5087058842182159e-02
    z[8,7,4]  R2753     1.3192920386791229e-01
    z[8,7,4]  R2754     -3.7163820862770081e-01
    z[8,7,4]  R2755     -1.5029367804527283e-01
    z[8,7,4]  R2756     -1.3495387136936188e-01
    z[8,7,4]  R2757     -2.0871834456920624e-01
    z[8,7,4]  R2758     1.8678975105285645e-01
    z[8,7,4]  R2759     2.5995094329118729e-02
    z[8,7,4]  R2760     2.8754368424415588e-01
    z[8,7,4]  R2761     2.7865159511566162e-01
    z[8,7,4]  R2762     -7.7265299856662750e-02
    z[8,7,4]  R2763     3.5431340336799622e-01
    z[8,7,4]  R2764     1.9545695185661316e-01
    z[8,7,4]  R2765     5.7299785315990448e-02
    z[8,7,4]  R2766     -8.0676466226577759e-02
    z[8,7,4]  R2767     7.4233666062355042e-02
    z[8,7,4]  R2768     -2.9526667669415474e-02
    z[8,7,4]  R2769     -1.7548096179962158e-01
    z[8,7,4]  R2770     -2.5313866138458252e-01
    z[8,7,4]  R2771     3.1068675220012665e-02
    z[8,7,4]  R2772     6.0402441024780273e-01
    z[8,7,4]  R2773     -2.0315755903720856e-01
    z[8,7,4]  R2774     -1.1944981664419174e-01
    z[8,7,4]  R2775     -3.3345988392829895e-01
    z[8,7,4]  R2776     4.9226564168930054e-01
    z[8,7,4]  R2777     0.192902609705925
    z[8,7,4]  R2778     -1.0200403630733490e-01
    z[8,7,4]  R2779     2.3301427066326141e-01
    z[8,7,4]  R2780     -3.9524596929550171e-01
    z[8,7,4]  R2781     -2.6711821556091309e-01
    z[8,7,4]  R2782     -4.3883770704269409e-01
    z[8,7,4]  R2783     -5.2055913209915161e-01
    z[8,7,4]  R2784     -7.5289912521839142e-02
    z[8,7,4]  R2785     -1.4688414335250854e-01
    z[8,7,4]  R2786     -4.3398797512054443e-01
    z[8,7,4]  R2787     3.2364809513092041e-01
    z[8,7,4]  R2788     3.2094126939773560e-01
    z[8,7,4]  R2789     -4.4822499155998230e-01
    z[8,7,4]  R2790     -5.5237084627151489e-01
    z[8,7,4]  R2791     -4.7012698650360107e-01
    z[8,7,4]  R2792     -3.3907783031463623e-01
    z[8,7,4]  R2793     -3.8905680179595947e-01
    z[8,7,4]  R2794     -3.0298039317131042e-01
    z[8,7,4]  R2795     5.9135757386684418e-02
    z[8,7,4]  R2796     -2.5848689675331116e-01
    z[8,7,4]  R2797     1.6010291874408722e-02
    z[8,7,4]  R2798     -1.0964769870042801e-01
    z[8,7,4]  R2799     2.1156449615955353e-01
    z[8,7,4]  R2800     0.655748188495636
    z[8,7,4]  R2801     -1.4161817729473114e-01
    z[8,7,4]  R2802     6.3251096010208130e-01
    z[8,7,4]  R2803     3.9920559525489807e-01
    z[8,7,4]  R2804     -6.1699371784925461e-02
    z[8,7,4]  R2805     3.5262140631675720e-01
    z[8,7,4]  R2806     -2.7352491393685341e-02
    z[8,7,4]  R2807     3.0771702527999878e-01
    z[8,7,4]  R2808     0.307492196559906
    z[8,7,4]  R2809     4.6538379788398743e-01
    z[8,7,4]  R2810     -2.9700118303298950e-01
    z[8,7,4]  R2811     -3.9172884821891785e-01
    z[8,7,4]  R2812     2.1518760919570923e-01
    z[8,7,4]  R2813     -1.0180468112230301e-01
    z[8,7,4]  R2814     2.2309435904026031e-01
    z[8,7,4]  R2815     -0.0850767120718956
    z[8,7,4]  R2816     -1.1955167353153229e-01
    z[8,7,4]  R2817     -8.1110924482345581e-01
    z[8,7,4]  R2818     -1.0898580402135849e-01
    z[8,7,4]  R2819     5.5226337909698486e-01
    z[8,7,4]  R2820     4.8057359457015991e-01
    z[8,7,4]  R2821     7.1364927291870117e-01
    z[8,7,4]  R2822     2.6871958374977112e-01
    z[8,7,4]  R2823     5.2876341342926025e-01
    z[8,7,4]  R2824     1.1409211903810501e-01
    z[8,7,4]  R2825     2.6202520728111267e-01
    z[8,7,4]  R2826     2.4984866380691528e-01
    z[8,7,4]  R2827     -3.6618936061859131e-01
    z[8,7,4]  R2828     -1.6661860048770905e-02
    z[8,7,4]  R2829     4.3248176574707031e-01
    z[8,7,4]  R2830     2.5308316946029663e-01
    z[8,7,4]  R2831     2.0223341882228851e-01
    z[8,7,4]  R2832     3.3913221955299377e-01
    z[8,7,4]  R2833     3.0128675699234009e-01
    z[8,7,4]  R2834     1.3564477860927582e-01
    z[8,7,4]  R2835     -2.7488607913255692e-02
    z[8,7,4]  R2836     4.8106640577316284e-02
    z[8,7,4]  R2837     -3.4481963515281677e-01
    z[8,7,4]  R2838     -2.0610374212265015e-01
    z[8,7,4]  R2839     2.7970704436302185e-01
    z[8,7,4]  R2840     5.1321285963058472e-01
    z[8,7,4]  R2841     6.8382078409194946e-01
    z[8,7,4]  R2842     7.9613149166107178e-02
    z[8,7,4]  R2843     5.0367474555969238e-01
    z[8,7,4]  R2844     -1.6412030905485153e-02
    z[8,7,4]  R2845     5.0547290593385696e-02
    z[8,7,4]  R2846     -2.2112096846103668e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2713     -1
    z[8,7,5]  R2714     1
    z[8,7,5]  R2717     -7.0518068969249725e-02
    z[8,7,5]  R2718     2.9320802539587021e-02
    z[8,7,5]  R2719     1.6049274802207947e-01
    z[8,7,5]  R2720     9.7442999482154846e-02
    z[8,7,5]  R2721     1.2150280922651291e-01
    z[8,7,5]  R2722     6.1087656766176224e-02
    z[8,7,5]  R2723     -8.9247547090053558e-02
    z[8,7,5]  R2724     8.4644109010696411e-02
    z[8,7,5]  R2725     2.7353477478027344e-01
    z[8,7,5]  R2726     4.0036666393280029e-01
    z[8,7,5]  R2727     3.6903893947601318e-01
    z[8,7,5]  R2728     6.8073374032974243e-01
    z[8,7,5]  R2729     4.3479007482528687e-01
    z[8,7,5]  R2730     8.1305164098739624e-01
    z[8,7,5]  R2731     5.3321695327758789e-01
    z[8,7,5]  R2732     4.6339431405067444e-01
    z[8,7,5]  R2733     5.6345325708389282e-01
    z[8,7,5]  R2734     -2.1080057322978973e-01
    z[8,7,5]  R2735     -0.598402738571167
    z[8,7,5]  R2736     1.0290031135082245e-01
    z[8,7,5]  R2737     -4.8102951049804688e-01
    z[8,7,5]  R2738     2.3012389242649078e-01
    z[8,7,5]  R2739     4.5984706282615662e-01
    z[8,7,5]  R2740     1.4776639640331268e-01
    z[8,7,5]  R2741     -5.0973349809646606e-01
    z[8,7,5]  R2742     1.6818402707576752e-01
    z[8,7,5]  R2743     -3.8613748550415039e-01
    z[8,7,5]  R2744     2.5651791691780090e-01
    z[8,7,5]  R2745     -2.0864118635654449e-01
    z[8,7,5]  R2746     2.4168965220451355e-01
    z[8,7,5]  R2747     3.4985315799713135e-01
    z[8,7,5]  R2748     0.411308616399765
    z[8,7,5]  R2749     1.1703790724277496e-01
    z[8,7,5]  R2750     -3.2389920949935913e-01
    z[8,7,5]  R2751     -0.0661073550581932
    z[8,7,5]  R2752     2.2231031954288483e-01
    z[8,7,5]  R2753     -2.4207718670368195e-01
    z[8,7,5]  R2754     -6.9456794299185276e-03
    z[8,7,5]  R2755     4.4466793537139893e-02
    z[8,7,5]  R2756     2.6548272371292114e-01
    z[8,7,5]  R2757     -2.4890737235546112e-01
    z[8,7,5]  R2758     -2.2501491010189056e-01
    z[8,7,5]  R2759     -1.0241493582725525e-01
    z[8,7,5]  R2760     7.6932793855667114e-01
    z[8,7,5]  R2761     7.6607394218444824e-01
    z[8,7,5]  R2762     8.9728303253650665e-02
    z[8,7,5]  R2763     -3.3832769840955734e-03
    z[8,7,5]  R2764     2.5807055830955505e-01
    z[8,7,5]  R2765     -2.2562643885612488e-01
    z[8,7,5]  R2766     1.8531037867069244e-01
    z[8,7,5]  R2767     -1.9545707106590271e-01
    z[8,7,5]  R2768     -1.3591052591800690e-01
    z[8,7,5]  R2769     -1.4011819660663605e-01
    z[8,7,5]  R2770     -5.3619122505187988e-01
    z[8,7,5]  R2771     8.0709677934646606e-01
    z[8,7,5]  R2772     -1.8276451528072357e-01
    z[8,7,5]  R2773     -1.6230879724025726e-01
    z[8,7,5]  R2774     2.7760567143559456e-02
    z[8,7,5]  R2775     6.0488367080688477e-01
    z[8,7,5]  R2776     3.2660558819770813e-01
    z[8,7,5]  R2777     3.5799962282180786e-01
    z[8,7,5]  R2778     4.3259340524673462e-01
    z[8,7,5]  R2779     -2.1127325296401978e-01
    z[8,7,5]  R2780     1.3093756139278412e-01
    z[8,7,5]  R2781     3.7043792009353638e-01
    z[8,7,5]  R2782     -0.0495392307639122
    z[8,7,5]  R2783     3.2732561230659485e-01
    z[8,7,5]  R2784     -2.2811965644359589e-01
    z[8,7,5]  R2785     -2.7723529934883118e-01
    z[8,7,5]  R2786     -1.8648815155029297e-01
    z[8,7,5]  R2787     3.0621299147605896e-01
    z[8,7,5]  R2788     1.3879445195198059e-01
    z[8,7,5]  R2789     1.6501431167125702e-01
    z[8,7,5]  R2790     3.9671370387077332e-01
    z[8,7,5]  R2791     -4.4743424654006958e-01
    z[8,7,5]  R2792     -2.1514873206615448e-01
    z[8,7,5]  R2793     -6.6480213403701782e-01
    z[8,7,5]  R2794     -7.0080637931823730e-01
    z[8,7,5]  R2795     5.6166354566812515e-02
    z[8,7,5]  R2796     -0.560685932636261
    z[8,7,5]  R2797     6.1092805862426758e-01
    z[8,7,5]  R2798     0.305328369140625
    z[8,7,5]  R2799     -3.2644817233085632e-01
    z[8,7,5]  R2800     2.7013307809829712e-01
    z[8,7,5]  R2801     3.8586756587028503e-01
    z[8,7,5]  R2802     -1.1724155396223068e-02
    z[8,7,5]  R2803     -5.4554667323827744e-02
    z[8,7,5]  R2804     -1.7589065432548523e-01
    z[8,7,5]  R2805     7.0996925234794617e-02
    z[8,7,5]  R2806     4.9334344267845154e-01
    z[8,7,5]  R2807     -0.647737979888916
    z[8,7,5]  R2808     2.6006600819528103e-03
    z[8,7,5]  R2809     -3.1988570094108582e-01
    z[8,7,5]  R2810     -5.3647315502166748e-01
    z[8,7,5]  R2811     -3.3451077342033386e-01
    z[8,7,5]  R2812     3.8160249590873718e-02
    z[8,7,5]  R2813     0.247584730386734
    z[8,7,5]  R2814     1.7031347751617432e-01
    z[8,7,5]  R2815     -3.9729550480842590e-01
    z[8,7,5]  R2816     2.6620325446128845e-01
    z[8,7,5]  R2817     -9.6859313547611237e-02
    z[8,7,5]  R2818     3.9680776000022888e-01
    z[8,7,5]  R2819     3.8803797960281372e-01
    z[8,7,5]  R2820     -3.6811605095863342e-01
    z[8,7,5]  R2821     -4.5355820655822754e-01
    z[8,7,5]  R2822     -3.7679061293601990e-01
    z[8,7,5]  R2823     -9.9245734512805939e-02
    z[8,7,5]  R2824     -3.6069911718368530e-01
    z[8,7,5]  R2825     -4.9722501635551453e-01
    z[8,7,5]  R2826     -6.0913139022886753e-03
    z[8,7,5]  R2827     -3.0868908762931824e-01
    z[8,7,5]  R2828     -2.5204730033874512e-01
    z[8,7,5]  R2829     2.2183644771575928e-01
    z[8,7,5]  R2830     -2.9326236248016357e-01
    z[8,7,5]  R2831     -2.0866183936595917e-01
    z[8,7,5]  R2832     -9.8147220909595490e-02
    z[8,7,5]  R2833     -2.2753703594207764e-01
    z[8,7,5]  R2834     -2.1214932203292847e-01
    z[8,7,5]  R2835     -1.6605599224567413e-01
    z[8,7,5]  R2836     -1.2479253858327866e-01
    z[8,7,5]  R2837     -5.0345528125762939e-01
    z[8,7,5]  R2838     0.754705548286438
    z[8,7,5]  R2839     -2.9630449414253235e-01
    z[8,7,5]  R2840     -3.5210517048835754e-01
    z[8,7,5]  R2841     -2.0151783525943756e-01
    z[8,7,5]  R2842     -5.6089985370635986e-01
    z[8,7,5]  R2843     -1.1960883438587189e-01
    z[8,7,5]  R2844     -2.6464805006980896e-01
    z[8,7,5]  R2845     -6.1810355633497238e-02
    z[8,7,5]  R2846     -4.4104088097810745e-02
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2715     -1
    z[8,7,6]  R2716     1
    z[8,7,6]  R2717     -1.4853195846080780e-01
    z[8,7,6]  R2718     -6.0669219493865967e-01
    z[8,7,6]  R2719     3.8330513983964920e-02
    z[8,7,6]  R2720     -3.5251826047897339e-01
    z[8,7,6]  R2721     -9.1001898050308228e-02
    z[8,7,6]  R2722     1.1751641333103180e-01
    z[8,7,6]  R2723     4.5755349099636078e-02
    z[8,7,6]  R2724     2.4354528635740280e-02
    z[8,7,6]  R2725     -5.3508855402469635e-02
    z[8,7,6]  R2726     -2.3536704480648041e-01
    z[8,7,6]  R2727     1.1895284801721573e-01
    z[8,7,6]  R2728     -1.0439812391996384e-01
    z[8,7,6]  R2729     1.0300076566636562e-02
    z[8,7,6]  R2730     -6.8263687193393707e-02
    z[8,7,6]  R2731     -3.1316304206848145e-01
    z[8,7,6]  R2732     -2.7121287584304810e-01
    z[8,7,6]  R2733     -5.6809592247009277e-01
    z[8,7,6]  R2734     -9.1780908405780792e-02
    z[8,7,6]  R2735     2.5107720494270325e-01
    z[8,7,6]  R2736     8.4061108529567719e-02
    z[8,7,6]  R2737     1.1446928232908249e-01
    z[8,7,6]  R2738     5.7627558708190918e-01
    z[8,7,6]  R2739     -4.0148171782493591e-01
    z[8,7,6]  R2740     -4.9632743000984192e-01
    z[8,7,6]  R2741     -2.4001958966255188e-01
    z[8,7,6]  R2742     8.0292999744415283e-02
    z[8,7,6]  R2743     -0.263278603553772
    z[8,7,6]  R2744     -3.5444416105747223e-02
    z[8,7,6]  R2745     -3.1469020247459412e-01
    z[8,7,6]  R2746     4.0821629762649536e-01
    z[8,7,6]  R2747     2.0155639946460724e-01
    z[8,7,6]  R2748     -2.5141993165016174e-01
    z[8,7,6]  R2749     3.7151420116424561e-01
    z[8,7,6]  R2750     8.0253079533576965e-02
    z[8,7,6]  R2751     -1.4116473495960236e-01
    z[8,7,6]  R2752     2.5778514146804810e-01
    z[8,7,6]  R2753     5.3164589405059814e-01
    z[8,7,6]  R2754     1.2013272196054459e-01
    z[8,7,6]  R2755     -2.3785415291786194e-01
    z[8,7,6]  R2756     -1.9478686153888702e-01
    z[8,7,6]  R2757     -4.6476888656616211e-01
    z[8,7,6]  R2758     1.7436721920967102e-01
    z[8,7,6]  R2759     -6.8205338716506958e-01
    z[8,7,6]  R2760     1.2163235992193222e-01
    z[8,7,6]  R2761     -2.7614856138825417e-02
    z[8,7,6]  R2762     -5.3601509332656860e-01
    z[8,7,6]  R2763     -3.3391021192073822e-02
    z[8,7,6]  R2764     -5.5280399322509766e-01
    z[8,7,6]  R2765     -2.1958464756608009e-02
    z[8,7,6]  R2766     2.9406201839447021e-01
    z[8,7,6]  R2767     2.1542693674564362e-01
    z[8,7,6]  R2768     -2.3527100682258606e-01
    z[8,7,6]  R2769     4.8838317394256592e-01
    z[8,7,6]  R2770     -1.5909896790981293e-01
    z[8,7,6]  R2771     0.198703795671463
    z[8,7,6]  R2772     -3.1156727671623230e-01
    z[8,7,6]  R2773     -1.5996801853179932e-01
    z[8,7,6]  R2774     -0.421928346157074
    z[8,7,6]  R2775     2.3076918721199036e-01
    z[8,7,6]  R2776     1.3824053108692169e-01
    z[8,7,6]  R2777     0.122501440346241
    z[8,7,6]  R2778     1.0997556149959564e-01
    z[8,7,6]  R2779     -2.1318021416664124e-01
    z[8,7,6]  R2780     -3.3069238066673279e-02
    z[8,7,6]  R2781     2.8779405355453491e-01
    z[8,7,6]  R2782     -1.6068504750728607e-01
    z[8,7,6]  R2783     2.2490942478179932e-01
    z[8,7,6]  R2784     -2.4933236837387085e-01
    z[8,7,6]  R2785     -2.3067300207912922e-04
    z[8,7,6]  R2786     -4.7878619283437729e-02
    z[8,7,6]  R2787     -1.1579968780279160e-01
    z[8,7,6]  R2788     2.3130239546298981e-01
    z[8,7,6]  R2789     -1.3899651356041431e-02
    z[8,7,6]  R2790     1.4802783727645874e-01
    z[8,7,6]  R2791     -1.4510647952556610e-01
    z[8,7,6]  R2792     -1.1211130023002625e-01
    z[8,7,6]  R2793     -2.7499282732605934e-02
    z[8,7,6]  R2794     1.1985295452177525e-02
    z[8,7,6]  R2795     -4.6924528479576111e-01
    z[8,7,6]  R2796     -1.1394876986742020e-01
    z[8,7,6]  R2797     -1.9635464251041412e-01
    z[8,7,6]  R2798     -5.5271911621093750e-01
    z[8,7,6]  R2799     -2.3895850777626038e-01
    z[8,7,6]  R2800     4.4609103351831436e-03
    z[8,7,6]  R2801     -1.1613752692937851e-01
    z[8,7,6]  R2802     -5.3179364651441574e-02
    z[8,7,6]  R2803     -6.2002742290496826e-01
    z[8,7,6]  R2804     -4.5243588089942932e-01
    z[8,7,6]  R2805     -0.295798122882843
    z[8,7,6]  R2806     -2.5345128774642944e-01
    z[8,7,6]  R2807     1.7758010327816010e-01
    z[8,7,6]  R2808     1.2392652779817581e-01
    z[8,7,6]  R2809     -3.2880410552024841e-01
    z[8,7,6]  R2810     1.3284260034561157e-01
    z[8,7,6]  R2811     -0.0349249504506588
    z[8,7,6]  R2812     -9.8057381808757782e-02
    z[8,7,6]  R2813     -1.4266440272331238e-01
    z[8,7,6]  R2814     -9.4616673886775970e-02
    z[8,7,6]  R2815     1.0085908323526382e-01
    z[8,7,6]  R2816     1.7898587882518768e-01
    z[8,7,6]  R2817     1.4067785441875458e-01
    z[8,7,6]  R2818     4.1401076316833496e-01
    z[8,7,6]  R2819     4.6701654791831970e-01
    z[8,7,6]  R2820     1.0725246369838715e-01
    z[8,7,6]  R2821     3.5518039017915726e-02
    z[8,7,6]  R2822     4.4076108932495117e-01
    z[8,7,6]  R2823     1.7334438860416412e-01
    z[8,7,6]  R2824     2.4198049306869507e-01
    z[8,7,6]  R2825     2.2133606672286987e-01
    z[8,7,6]  R2826     1.7766645550727844e-01
    z[8,7,6]  R2827     -1.2828439474105835e-01
    z[8,7,6]  R2828     4.6037697792053223e-01
    z[8,7,6]  R2829     -2.1246072649955750e-01
    z[8,7,6]  R2830     -1.1773724108934402e-01
    z[8,7,6]  R2831     -1.4549601078033447e-01
    z[8,7,6]  R2832     -3.0574795603752136e-01
    z[8,7,6]  R2833     2.2659644484519958e-01
    z[8,7,6]  R2834     3.5989217460155487e-02
    z[8,7,6]  R2835     -7.9660356044769287e-02
    z[8,7,6]  R2836     -2.7802494168281555e-01
    z[8,7,6]  R2837     7.3532208800315857e-02
    z[8,7,6]  R2838     3.6037430167198181e-01
    z[8,7,6]  R2839     2.0212219655513763e-01
    z[8,7,6]  R2840     -2.4569953978061676e-01
    z[8,7,6]  R2841     3.2126274704933167e-01
    z[8,7,6]  R2842     -2.0595690608024597e-01
    z[8,7,6]  R2843     3.0520647764205933e-01
    z[8,7,6]  R2844     6.3805043697357178e-02
    z[8,7,6]  R2845     -1.4203125238418579e-01
    z[8,7,6]  R2846     1.0419698059558868e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R81       1
    RHS1      R82       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[9,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,8]
 BV BND1      phi[8,3]
 BV BND1      phi[3,10]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[9,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,10]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[3,8,0]
 FR BND1      z[3,8,1]
 FR BND1      z[3,8,2]
 FR BND1      z[3,8,3]
 FR BND1      z[3,8,4]
 FR BND1      z[3,8,5]
 FR BND1      z[3,8,6]
 FR BND1      z[8,3,0]
 FR BND1      z[8,3,1]
 FR BND1      z[8,3,2]
 FR BND1      z[8,3,3]
 FR BND1      z[8,3,4]
 FR BND1      z[8,3,5]
 FR BND1      z[8,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
ENDATA
