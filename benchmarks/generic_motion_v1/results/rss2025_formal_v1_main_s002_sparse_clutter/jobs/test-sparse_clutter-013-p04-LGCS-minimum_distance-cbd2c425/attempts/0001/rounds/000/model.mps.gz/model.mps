NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  R2949   
 L  R2950   
 L  R2951   
 L  R2952   
 L  R2953   
 L  R2954   
 L  R2955   
 L  R2956   
 L  R2957   
 L  R2958   
 L  R2959   
 L  R2960   
 L  R2961   
 L  R2962   
 L  R2963   
 L  R2964   
 L  R2965   
 L  R2966   
 L  R2967   
 L  R2968   
 L  R2969   
 L  R2970   
 L  R2971   
 L  R2972   
 L  R2973   
 L  R2974   
 L  R2975   
 L  R2976   
 L  R2977   
 L  R2978   
 L  R2979   
 L  R2980   
 L  R2981   
 L  R2982   
 L  R2983   
 L  R2984   
 L  R2985   
 L  R2986   
 L  R2987   
 L  R2988   
 L  R2989   
 L  R2990   
 L  R2991   
 L  R2992   
 L  R2993   
 L  R2994   
 L  R2995   
 L  R2996   
 L  R2997   
 L  R2998   
 L  R2999   
 L  R3000   
 L  R3001   
 L  R3002   
 L  R3003   
 L  R3004   
 L  R3005   
 L  R3006   
 L  R3007   
 L  R3008   
 L  R3009   
 L  R3010   
 L  R3011   
 L  R3012   
 L  R3013   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -3.0999999046325684e+00
    phi[0,1]  R94       -2.2400000095367432e+00
    phi[0,1]  R95       -2.2400000095367432e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -3.0999999046325684e+00
    phi[0,1]  R98       -2.5699999332427979e+00
    phi[0,1]  R99       -2.5699999332427979e+00
    phi[0,1]  R100      -3.0999999046325684e+00
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -2.0899999141693115e+00
    phi[0,1]  R103      -2.0899999141693115e+00
    phi[0,1]  R104      -3.0999999046325684e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      -1.0232889652252197e+00
    phi[0,1]  R107      3.5786908864974976e-01
    phi[0,1]  R108      0.792243480682373
    phi[0,1]  R109      1.4092377424240112e+00
    phi[0,1]  R110      1.0327850580215454e+00
    phi[0,1]  R111      -1.3495792150497437e+00
    phi[0,1]  R112      -0.831960141658783
    phi[0,1]  R113      4.8476386070251465e-01
    phi[0,1]  R114      5.6117624044418335e-01
    phi[0,1]  R115      0.653398334980011
    phi[0,1]  R116      -2.8189139366149902e+00
    phi[0,1]  R117      -1.1891258955001831e+00
    phi[0,1]  R118      -1.2109819650650024e+00
    phi[0,1]  R119      1.7856364250183105e+00
    phi[0,1]  R120      8.8691306114196777e-01
    phi[0,1]  R121      1.0087047815322876e+00
    phi[0,1]  R122      0.677672266960144
    phi[0,1]  R123      3.4546223282814026e-01
    phi[0,1]  R124      -7.1463569998741150e-02
    phi[0,1]  R125      -6.4030355215072632e-01
    phi[0,1]  R126      -1.8571639060974121e+00
    phi[0,1]  R127      -1.5313794612884521e+00
    phi[0,1]  R128      7.1434521675109863e-01
    phi[0,1]  R129      2.4781946837902069e-01
    phi[0,1]  R130      1.7608387470245361e+00
    phi[0,1]  R131      -4.8314622044563293e-01
    phi[0,1]  R132      -8.8876855373382568e-01
    phi[0,1]  R133      -1.5842406749725342e+00
    phi[0,1]  R134      -3.7085118889808655e-01
    phi[0,1]  R135      -1.2310390472412109e+00
    phi[0,1]  R136      1.6361507177352905e+00
    phi[0,1]  R137      1.1735049486160278e+00
    phi[0,1]  R138      -1.4151252806186676e-01
    phi[0,1]  R139      1.3295363187789917e+00
    phi[0,1]  R140      1.62679922580719
    phi[0,1]  R141      1.5266609191894531e+00
    phi[0,1]  R142      4.2324081063270569e-01
    phi[0,1]  R143      5.4782360792160034e-01
    phi[0,1]  R144      1.1228002309799194e+00
    phi[0,1]  R145      1.2193865776062012e+00
    phi[0,1]  R146      -2.0016896724700928e+00
    phi[0,1]  R147      -1.3733358383178711e+00
    phi[0,1]  R148      -1.6341300010681152e+00
    phi[0,1]  R149      -7.5992363691329956e-01
    phi[0,1]  R150      -2.0463745594024658e+00
    phi[0,1]  R151      -2.3026545047760010e+00
    phi[0,1]  R152      -1.0696927309036255e+00
    phi[0,1]  R153      -2.6139483451843262e+00
    phi[0,1]  R154      -0.523598849773407
    phi[0,1]  R155      -1.0860439538955688e+00
    phi[0,1]  R156      -1.6229268312454224e+00
    phi[0,1]  R157      -2.3024783134460449e+00
    phi[0,1]  R158      4.7224009037017822e-01
    phi[0,1]  R159      4.0360659360885620e-01
    phi[0,1]  R160      1.3774034380912781e-01
    phi[0,1]  R161      -4.9206972122192383e-01
    phi[0,1]  R162      7.1789436042308807e-03
    phi[0,1]  R163      8.2730062305927277e-02
    phi[0,1]  R164      -5.4622024297714233e-01
    phi[0,1]  R165      -7.9469686746597290e-01
    phi[0,1]  R166      -1.0041936635971069e+00
    phi[0,1]  R167      1.4215276241302490e+00
    phi[0,1]  R168      -1.1953498125076294e+00
    phi[0,1]  R169      -2.1317377686500549e-01
    phi[0,1]  R170      -1.9219215214252472e-01
    phi[0,1]  R171      -9.0415865182876587e-01
    phi[0,1]  R172      -6.0124200582504272e-01
    phi[0,1]  R173      -3.4522488713264465e-01
    phi[0,1]  R174      7.0743060111999512e-01
    phi[0,1]  R175      3.2159495353698730e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R176      -3.0999999046325684e+00
    phi[1,0]  R177      -3.0999999046325684e+00
    phi[1,0]  R178      -2.2400000095367432e+00
    phi[1,0]  R179      -2.2400000095367432e+00
    phi[1,0]  R180      -3.0999999046325684e+00
    phi[1,0]  R181      -3.0999999046325684e+00
    phi[1,0]  R182      -2.5699999332427979e+00
    phi[1,0]  R183      -2.5699999332427979e+00
    phi[1,0]  R184      -3.0999999046325684e+00
    phi[1,0]  R185      -3.0999999046325684e+00
    phi[1,0]  R186      -2.0899999141693115e+00
    phi[1,0]  R187      -2.0899999141693115e+00
    phi[1,0]  R188      -3.0999999046325684e+00
    phi[1,0]  R189      -3.0999999046325684e+00
    phi[1,0]  R190      1.6361507177352905e+00
    phi[1,0]  R191      1.1735049486160278e+00
    phi[1,0]  R192      -1.4151252806186676e-01
    phi[1,0]  R193      1.3295363187789917e+00
    phi[1,0]  R194      1.62679922580719
    phi[1,0]  R195      1.5266609191894531e+00
    phi[1,0]  R196      4.2324081063270569e-01
    phi[1,0]  R197      5.4782360792160034e-01
    phi[1,0]  R198      1.1228002309799194e+00
    phi[1,0]  R199      1.2193865776062012e+00
    phi[1,0]  R200      -2.0016896724700928e+00
    phi[1,0]  R201      -1.3733358383178711e+00
    phi[1,0]  R202      -1.6341300010681152e+00
    phi[1,0]  R203      -7.5992363691329956e-01
    phi[1,0]  R204      -2.0463745594024658e+00
    phi[1,0]  R205      -2.3026545047760010e+00
    phi[1,0]  R206      -1.0696927309036255e+00
    phi[1,0]  R207      -2.6139483451843262e+00
    phi[1,0]  R208      -0.523598849773407
    phi[1,0]  R209      -1.0860439538955688e+00
    phi[1,0]  R210      -1.6229268312454224e+00
    phi[1,0]  R211      -2.3024783134460449e+00
    phi[1,0]  R212      4.7224009037017822e-01
    phi[1,0]  R213      4.0360659360885620e-01
    phi[1,0]  R214      1.3774034380912781e-01
    phi[1,0]  R215      -4.9206972122192383e-01
    phi[1,0]  R216      7.1789436042308807e-03
    phi[1,0]  R217      8.2730062305927277e-02
    phi[1,0]  R218      -5.4622024297714233e-01
    phi[1,0]  R219      -7.9469686746597290e-01
    phi[1,0]  R220      -1.0041936635971069e+00
    phi[1,0]  R221      1.4215276241302490e+00
    phi[1,0]  R222      -1.1953498125076294e+00
    phi[1,0]  R223      -2.1317377686500549e-01
    phi[1,0]  R224      -1.9219215214252472e-01
    phi[1,0]  R225      -9.0415865182876587e-01
    phi[1,0]  R226      -6.0124200582504272e-01
    phi[1,0]  R227      -3.4522488713264465e-01
    phi[1,0]  R228      7.0743060111999512e-01
    phi[1,0]  R229      3.2159495353698730e-01
    phi[1,0]  R230      -1.0232889652252197e+00
    phi[1,0]  R231      3.5786908864974976e-01
    phi[1,0]  R232      0.792243480682373
    phi[1,0]  R233      1.4092377424240112e+00
    phi[1,0]  R234      1.0327850580215454e+00
    phi[1,0]  R235      -1.3495792150497437e+00
    phi[1,0]  R236      -0.831960141658783
    phi[1,0]  R237      4.8476386070251465e-01
    phi[1,0]  R238      5.6117624044418335e-01
    phi[1,0]  R239      0.653398334980011
    phi[1,0]  R240      -2.8189139366149902e+00
    phi[1,0]  R241      -1.1891258955001831e+00
    phi[1,0]  R242      -1.2109819650650024e+00
    phi[1,0]  R243      1.7856364250183105e+00
    phi[1,0]  R244      8.8691306114196777e-01
    phi[1,0]  R245      1.0087047815322876e+00
    phi[1,0]  R246      0.677672266960144
    phi[1,0]  R247      3.4546223282814026e-01
    phi[1,0]  R248      -7.1463569998741150e-02
    phi[1,0]  R249      -6.4030355215072632e-01
    phi[1,0]  R250      -1.8571639060974121e+00
    phi[1,0]  R251      -1.5313794612884521e+00
    phi[1,0]  R252      7.1434521675109863e-01
    phi[1,0]  R253      2.4781946837902069e-01
    phi[1,0]  R254      1.7608387470245361e+00
    phi[1,0]  R255      -4.8314622044563293e-01
    phi[1,0]  R256      -8.8876855373382568e-01
    phi[1,0]  R257      -1.5842406749725342e+00
    phi[1,0]  R258      -3.7085118889808655e-01
    phi[1,0]  R259      -1.2310390472412109e+00
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R260      -3.0999999046325684e+00
    phi[0,5]  R261      -3.0999999046325684e+00
    phi[0,5]  R262      -2.2400000095367432e+00
    phi[0,5]  R263      -2.2400000095367432e+00
    phi[0,5]  R264      -3.0999999046325684e+00
    phi[0,5]  R265      -3.0999999046325684e+00
    phi[0,5]  R266      -2.5699999332427979e+00
    phi[0,5]  R267      -2.5699999332427979e+00
    phi[0,5]  R268      -3.0999999046325684e+00
    phi[0,5]  R269      -3.0999999046325684e+00
    phi[0,5]  R270      -2.0899999141693115e+00
    phi[0,5]  R271      -2.0899999141693115e+00
    phi[0,5]  R272      -3.0999999046325684e+00
    phi[0,5]  R273      -3.0999999046325684e+00
    phi[0,5]  R274      -1.0232889652252197e+00
    phi[0,5]  R275      3.5786908864974976e-01
    phi[0,5]  R276      0.792243480682373
    phi[0,5]  R277      1.4092377424240112e+00
    phi[0,5]  R278      1.0327850580215454e+00
    phi[0,5]  R279      -1.3495792150497437e+00
    phi[0,5]  R280      -0.831960141658783
    phi[0,5]  R281      4.8476386070251465e-01
    phi[0,5]  R282      5.6117624044418335e-01
    phi[0,5]  R283      0.653398334980011
    phi[0,5]  R284      -2.8189139366149902e+00
    phi[0,5]  R285      -1.1891258955001831e+00
    phi[0,5]  R286      -1.2109819650650024e+00
    phi[0,5]  R287      1.7856364250183105e+00
    phi[0,5]  R288      8.8691306114196777e-01
    phi[0,5]  R289      1.0087047815322876e+00
    phi[0,5]  R290      0.677672266960144
    phi[0,5]  R291      3.4546223282814026e-01
    phi[0,5]  R292      -7.1463569998741150e-02
    phi[0,5]  R293      -6.4030355215072632e-01
    phi[0,5]  R294      -1.8571639060974121e+00
    phi[0,5]  R295      -1.5313794612884521e+00
    phi[0,5]  R296      7.1434521675109863e-01
    phi[0,5]  R297      2.4781946837902069e-01
    phi[0,5]  R298      1.7608387470245361e+00
    phi[0,5]  R299      -4.8314622044563293e-01
    phi[0,5]  R300      -8.8876855373382568e-01
    phi[0,5]  R301      -1.5842406749725342e+00
    phi[0,5]  R302      -3.7085118889808655e-01
    phi[0,5]  R303      -1.2310390472412109e+00
    phi[0,5]  R304      -5.5226409435272217e-01
    phi[0,5]  R305      5.4206192493438721e-01
    phi[0,5]  R306      -2.6080548763275146e+00
    phi[0,5]  R307      1.1814839839935303e+00
    phi[0,5]  R308      -1.0769462585449219e+00
    phi[0,5]  R309      6.0016489028930664e-01
    phi[0,5]  R310      7.3969650268554688e-01
    phi[0,5]  R311      -1.0204908847808838e+00
    phi[0,5]  R312      6.9684582948684692e-01
    phi[0,5]  R313      -5.5375146865844727e-01
    phi[0,5]  R314      -0.172672301530838
    phi[0,5]  R315      -1.8707424402236938e+00
    phi[0,5]  R316      -2.4609239101409912e+00
    phi[0,5]  R317      8.1715232133865356e-01
    phi[0,5]  R318      -8.1758445501327515e-01
    phi[0,5]  R319      -2.0440040528774261e-01
    phi[0,5]  R320      -2.2904960811138153e-01
    phi[0,5]  R321      -1.4300264120101929e+00
    phi[0,5]  R322      -1.06353759765625
    phi[0,5]  R323      1.7268086969852448e-01
    phi[0,5]  R324      9.6812361478805542e-01
    phi[0,5]  R325      -1.1972683668136597e+00
    phi[0,5]  R326      -1.0630195140838623e+00
    phi[0,5]  R327      -6.8205523490905762e-01
    phi[0,5]  R328      6.2805622816085815e-01
    phi[0,5]  R329      9.8153114318847656e-01
    phi[0,5]  R330      -2.0366662740707397e-01
    phi[0,5]  R331      4.2998507618904114e-01
    phi[0,5]  R332      1.8881247043609619e+00
    phi[0,5]  R333      1.3821417093276978e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R334      -3.0999999046325684e+00
    phi[5,0]  R335      -3.0999999046325684e+00
    phi[5,0]  R336      -2.2400000095367432e+00
    phi[5,0]  R337      -2.2400000095367432e+00
    phi[5,0]  R338      -3.0999999046325684e+00
    phi[5,0]  R339      -3.0999999046325684e+00
    phi[5,0]  R340      -2.5699999332427979e+00
    phi[5,0]  R341      -2.5699999332427979e+00
    phi[5,0]  R342      -3.0999999046325684e+00
    phi[5,0]  R343      -3.0999999046325684e+00
    phi[5,0]  R344      -2.0899999141693115e+00
    phi[5,0]  R345      -2.0899999141693115e+00
    phi[5,0]  R346      -3.0999999046325684e+00
    phi[5,0]  R347      -3.0999999046325684e+00
    phi[5,0]  R348      -1.0232889652252197e+00
    phi[5,0]  R349      3.5786908864974976e-01
    phi[5,0]  R350      0.792243480682373
    phi[5,0]  R351      1.0327850580215454e+00
    phi[5,0]  R352      -1.3495792150497437e+00
    phi[5,0]  R353      -5.5226409435272217e-01
    phi[5,0]  R354      -0.831960141658783
    phi[5,0]  R355      4.8476386070251465e-01
    phi[5,0]  R356      5.6117624044418335e-01
    phi[5,0]  R357      5.4206192493438721e-01
    phi[5,0]  R358      -2.6080548763275146e+00
    phi[5,0]  R359      1.1814839839935303e+00
    phi[5,0]  R360      -1.0769462585449219e+00
    phi[5,0]  R361      6.0016489028930664e-01
    phi[5,0]  R362      7.3969650268554688e-01
    phi[5,0]  R363      -1.0204908847808838e+00
    phi[5,0]  R364      6.9684582948684692e-01
    phi[5,0]  R365      -5.5375146865844727e-01
    phi[5,0]  R366      -0.172672301530838
    phi[5,0]  R367      -1.8707424402236938e+00
    phi[5,0]  R368      -2.4609239101409912e+00
    phi[5,0]  R369      8.1715232133865356e-01
    phi[5,0]  R370      -8.1758445501327515e-01
    phi[5,0]  R371      -2.0440040528774261e-01
    phi[5,0]  R372      -2.2904960811138153e-01
    phi[5,0]  R373      -1.4300264120101929e+00
    phi[5,0]  R374      -1.06353759765625
    phi[5,0]  R375      1.7268086969852448e-01
    phi[5,0]  R376      9.6812361478805542e-01
    phi[5,0]  R377      -1.1972683668136597e+00
    phi[5,0]  R378      -1.0630195140838623e+00
    phi[5,0]  R379      -6.8205523490905762e-01
    phi[5,0]  R380      6.2805622816085815e-01
    phi[5,0]  R381      9.8153114318847656e-01
    phi[5,0]  R382      -2.0366662740707397e-01
    phi[5,0]  R383      4.2998507618904114e-01
    phi[5,0]  R384      1.8881247043609619e+00
    phi[5,0]  R385      1.3821417093276978e+00
    phi[5,0]  R386      1.4092377424240112e+00
    phi[5,0]  R387      0.653398334980011
    phi[5,0]  R388      -2.8189139366149902e+00
    phi[5,0]  R389      -1.1891258955001831e+00
    phi[5,0]  R390      -1.2109819650650024e+00
    phi[5,0]  R391      1.7856364250183105e+00
    phi[5,0]  R392      8.8691306114196777e-01
    phi[5,0]  R393      1.0087047815322876e+00
    phi[5,0]  R394      0.677672266960144
    phi[5,0]  R395      3.4546223282814026e-01
    phi[5,0]  R396      -7.1463569998741150e-02
    phi[5,0]  R397      -6.4030355215072632e-01
    phi[5,0]  R398      -1.8571639060974121e+00
    phi[5,0]  R399      -1.5313794612884521e+00
    phi[5,0]  R400      7.1434521675109863e-01
    phi[5,0]  R401      2.4781946837902069e-01
    phi[5,0]  R402      1.7608387470245361e+00
    phi[5,0]  R403      -4.8314622044563293e-01
    phi[5,0]  R404      -8.8876855373382568e-01
    phi[5,0]  R405      -1.5842406749725342e+00
    phi[5,0]  R406      -3.7085118889808655e-01
    phi[5,0]  R407      -1.2310390472412109e+00
    phi[0,6]  R0        1
    phi[0,6]  R1        1
    phi[0,6]  R54       -1
    phi[0,6]  R408      -3.0999999046325684e+00
    phi[0,6]  R409      -3.0999999046325684e+00
    phi[0,6]  R410      -2.2400000095367432e+00
    phi[0,6]  R411      -2.2400000095367432e+00
    phi[0,6]  R412      -3.0999999046325684e+00
    phi[0,6]  R413      -3.0999999046325684e+00
    phi[0,6]  R414      -2.5699999332427979e+00
    phi[0,6]  R415      -2.5699999332427979e+00
    phi[0,6]  R416      -3.0999999046325684e+00
    phi[0,6]  R417      -3.0999999046325684e+00
    phi[0,6]  R418      -2.0899999141693115e+00
    phi[0,6]  R419      -2.0899999141693115e+00
    phi[0,6]  R420      -3.0999999046325684e+00
    phi[0,6]  R421      -3.0999999046325684e+00
    phi[0,6]  R422      -1.0232889652252197e+00
    phi[0,6]  R423      3.5786908864974976e-01
    phi[0,6]  R424      0.792243480682373
    phi[0,6]  R425      1.4092377424240112e+00
    phi[0,6]  R426      1.0327850580215454e+00
    phi[0,6]  R427      -1.3495792150497437e+00
    phi[0,6]  R428      -0.831960141658783
    phi[0,6]  R429      4.8476386070251465e-01
    phi[0,6]  R430      5.6117624044418335e-01
    phi[0,6]  R431      0.653398334980011
    phi[0,6]  R432      -2.8189139366149902e+00
    phi[0,6]  R433      -1.1891258955001831e+00
    phi[0,6]  R434      -1.2109819650650024e+00
    phi[0,6]  R435      1.7856364250183105e+00
    phi[0,6]  R436      8.8691306114196777e-01
    phi[0,6]  R437      1.0087047815322876e+00
    phi[0,6]  R438      0.677672266960144
    phi[0,6]  R439      3.4546223282814026e-01
    phi[0,6]  R440      -7.1463569998741150e-02
    phi[0,6]  R441      -6.4030355215072632e-01
    phi[0,6]  R442      -1.8571639060974121e+00
    phi[0,6]  R443      -1.5313794612884521e+00
    phi[0,6]  R444      7.1434521675109863e-01
    phi[0,6]  R445      2.4781946837902069e-01
    phi[0,6]  R446      1.7608387470245361e+00
    phi[0,6]  R447      -4.8314622044563293e-01
    phi[0,6]  R448      -8.8876855373382568e-01
    phi[0,6]  R449      -1.5842406749725342e+00
    phi[0,6]  R450      -3.7085118889808655e-01
    phi[0,6]  R451      -1.2310390472412109e+00
    phi[0,6]  R452      1.00933039188385
    phi[0,6]  R453      1.2212057113647461e+00
    phi[0,6]  R454      4.3360418081283569e-01
    phi[0,6]  R455      -7.8252464532852173e-02
    phi[0,6]  R456      3.6776131391525269e-01
    phi[0,6]  R457      9.5782530307769775e-01
    phi[0,6]  R458      -0.779298722743988
    phi[0,6]  R459      -7.7718579769134521e-01
    phi[0,6]  R460      1.8897460699081421e+00
    phi[0,6]  R461      3.3889052271842957e-01
    phi[0,6]  R462      7.4318385124206543e-01
    phi[0,6]  R463      6.1616539955139160e-01
    phi[0,6]  R464      -0.672346293926239
    phi[0,6]  R465      -1.4117884635925293e+00
    phi[0,6]  R466      -4.8596712946891785e-01
    phi[0,6]  R467      -1.1458284854888916e+00
    phi[0,6]  R468      -9.5656543970108032e-01
    phi[0,6]  R469      -1.1626473665237427e+00
    phi[0,6]  R470      -1.3600634336471558e+00
    phi[0,6]  R471      -1.7584589719772339e+00
    phi[0,6]  R472      -1.4160325527191162e+00
    phi[0,6]  R473      -4.6216481924057007e-01
    phi[0,6]  R474      -1.2403523921966553e+00
    phi[0,6]  R475      -0.743035078048706
    phi[0,6]  R476      -1.8403687477111816e+00
    phi[0,6]  R477      -1.0509142875671387e+00
    phi[0,6]  R478      -1.1336144208908081e+00
    phi[0,6]  R479      -6.3730305433273315e-01
    phi[0,6]  R480      -1.1022298336029053e+00
    phi[0,6]  R481      -1.5698105096817017e+00
    phi[0,6]  R482      -1.3329949378967285e+00
    phi[0,6]  R483      1.5379105508327484e-01
    phi[0,6]  R484      -1.5817296504974365e+00
    phi[0,6]  R485      -1.3085422515869141e+00
    phi[0,6]  R486      -3.1768792867660522e-01
    phi[0,6]  R487      -3.8506698608398438e-01
    phi[0,6]  R488      -3.4213355183601379e-01
    phi[0,6]  R489      -1.5788037776947021e+00
    phi[0,6]  R490      -9.1159260272979736e-01
    phi[0,6]  R491      -9.8685455322265625e-01
    phi[0,6]  R492      -6.9986379146575928e-01
    phi[0,6]  R493      -1.3022774457931519e+00
    phi[0,6]  R494      -4.5435953140258789e-01
    phi[0,6]  R495      -8.2899320125579834e-01
    phi[0,6]  R496      -6.2494152784347534e-01
    phi[0,6]  R497      -1.3671209812164307e+00
    phi[0,6]  R498      -1.1223881244659424e+00
    phi[0,6]  R499      -0.910549521446228
    phi[0,6]  R500      -2.4844982624053955e+00
    phi[0,6]  R501      -2.74049711227417
    phi[6,0]  R0        -1
    phi[6,0]  R54       1
    phi[6,0]  R55       1
    phi[6,0]  R502      -3.0999999046325684e+00
    phi[6,0]  R503      -3.0999999046325684e+00
    phi[6,0]  R504      -2.2400000095367432e+00
    phi[6,0]  R505      -2.2400000095367432e+00
    phi[6,0]  R506      -3.0999999046325684e+00
    phi[6,0]  R507      -3.0999999046325684e+00
    phi[6,0]  R508      -2.5699999332427979e+00
    phi[6,0]  R509      -2.5699999332427979e+00
    phi[6,0]  R510      -3.0999999046325684e+00
    phi[6,0]  R511      -3.0999999046325684e+00
    phi[6,0]  R512      -2.0899999141693115e+00
    phi[6,0]  R513      -2.0899999141693115e+00
    phi[6,0]  R514      -3.0999999046325684e+00
    phi[6,0]  R515      -3.0999999046325684e+00
    phi[6,0]  R516      1.00933039188385
    phi[6,0]  R517      1.2212057113647461e+00
    phi[6,0]  R518      4.3360418081283569e-01
    phi[6,0]  R519      -7.8252464532852173e-02
    phi[6,0]  R520      3.6776131391525269e-01
    phi[6,0]  R521      9.5782530307769775e-01
    phi[6,0]  R522      -0.779298722743988
    phi[6,0]  R523      -7.7718579769134521e-01
    phi[6,0]  R524      1.8897460699081421e+00
    phi[6,0]  R525      3.3889052271842957e-01
    phi[6,0]  R526      7.4318385124206543e-01
    phi[6,0]  R527      6.1616539955139160e-01
    phi[6,0]  R528      -0.672346293926239
    phi[6,0]  R529      -1.4117884635925293e+00
    phi[6,0]  R530      -4.8596712946891785e-01
    phi[6,0]  R531      -1.1458284854888916e+00
    phi[6,0]  R532      -9.5656543970108032e-01
    phi[6,0]  R533      -1.1626473665237427e+00
    phi[6,0]  R534      -1.3600634336471558e+00
    phi[6,0]  R535      -1.7584589719772339e+00
    phi[6,0]  R536      -1.4160325527191162e+00
    phi[6,0]  R537      -4.6216481924057007e-01
    phi[6,0]  R538      -1.2403523921966553e+00
    phi[6,0]  R539      -0.743035078048706
    phi[6,0]  R540      -1.8403687477111816e+00
    phi[6,0]  R541      -1.0509142875671387e+00
    phi[6,0]  R542      -1.1336144208908081e+00
    phi[6,0]  R543      -6.3730305433273315e-01
    phi[6,0]  R544      -1.1022298336029053e+00
    phi[6,0]  R545      -1.5698105096817017e+00
    phi[6,0]  R546      -1.3329949378967285e+00
    phi[6,0]  R547      1.5379105508327484e-01
    phi[6,0]  R548      -1.5817296504974365e+00
    phi[6,0]  R549      -1.3085422515869141e+00
    phi[6,0]  R550      -3.1768792867660522e-01
    phi[6,0]  R551      -3.8506698608398438e-01
    phi[6,0]  R552      -3.4213355183601379e-01
    phi[6,0]  R553      -1.5788037776947021e+00
    phi[6,0]  R554      -9.1159260272979736e-01
    phi[6,0]  R555      -9.8685455322265625e-01
    phi[6,0]  R556      -6.9986379146575928e-01
    phi[6,0]  R557      -1.3022774457931519e+00
    phi[6,0]  R558      -4.5435953140258789e-01
    phi[6,0]  R559      -8.2899320125579834e-01
    phi[6,0]  R560      -6.2494152784347534e-01
    phi[6,0]  R561      -1.3671209812164307e+00
    phi[6,0]  R562      -1.1223881244659424e+00
    phi[6,0]  R563      -0.910549521446228
    phi[6,0]  R564      -2.4844982624053955e+00
    phi[6,0]  R565      -2.74049711227417
    phi[6,0]  R566      -1.0232889652252197e+00
    phi[6,0]  R567      3.5786908864974976e-01
    phi[6,0]  R568      0.792243480682373
    phi[6,0]  R569      1.4092377424240112e+00
    phi[6,0]  R570      1.0327850580215454e+00
    phi[6,0]  R571      -1.3495792150497437e+00
    phi[6,0]  R572      -0.831960141658783
    phi[6,0]  R573      4.8476386070251465e-01
    phi[6,0]  R574      5.6117624044418335e-01
    phi[6,0]  R575      0.653398334980011
    phi[6,0]  R576      -2.8189139366149902e+00
    phi[6,0]  R577      -1.1891258955001831e+00
    phi[6,0]  R578      -1.2109819650650024e+00
    phi[6,0]  R579      1.7856364250183105e+00
    phi[6,0]  R580      8.8691306114196777e-01
    phi[6,0]  R581      1.0087047815322876e+00
    phi[6,0]  R582      0.677672266960144
    phi[6,0]  R583      3.4546223282814026e-01
    phi[6,0]  R584      -7.1463569998741150e-02
    phi[6,0]  R585      -6.4030355215072632e-01
    phi[6,0]  R586      -1.8571639060974121e+00
    phi[6,0]  R587      -1.5313794612884521e+00
    phi[6,0]  R588      7.1434521675109863e-01
    phi[6,0]  R589      2.4781946837902069e-01
    phi[6,0]  R590      1.7608387470245361e+00
    phi[6,0]  R591      -4.8314622044563293e-01
    phi[6,0]  R592      -8.8876855373382568e-01
    phi[6,0]  R593      -1.5842406749725342e+00
    phi[6,0]  R594      -3.7085118889808655e-01
    phi[6,0]  R595      -1.2310390472412109e+00
    phi[10,0]  R0        -1
    phi[10,0]  R2        6.3284146634571048e-02
    phi[10,0]  R3        1.9934665805848018e+00
    phi[10,0]  R4        1.3499055787106520e+00
    phi[10,0]  R5        -7.8583313905015029e-01
    phi[10,0]  R6        2.4149177566934390e+00
    phi[10,0]  R7        8.6010458152915747e-01
    phi[10,0]  R8        1.3490414543132103e+00
    phi[10,0]  R90       1
    phi[10,0]  R596      -3.1632840512671394e+00
    phi[10,0]  R597      -3.0367157579979973e+00
    phi[10,0]  R598      -4.2334665901215445e+00
    phi[10,0]  R599      -2.4653342895194141e-01
    phi[10,0]  R600      -4.4499054833432208e+00
    phi[10,0]  R601      -1.7500943259219164e+00
    phi[10,0]  R602      -1.7841667941926476e+00
    phi[10,0]  R603      -3.3558330722929481e+00
    phi[10,0]  R604      -5.5149176613260078e+00
    phi[10,0]  R605      -6.8508214793912936e-01
    phi[10,0]  R606      -2.9501044956984690e+00
    phi[10,0]  R607      -1.2298953326401540e+00
    phi[10,0]  R608      -4.4490413589457791e+00
    phi[10,0]  R609      -1.7509584503193580e+00
    phi[10,0]  R610      -4.3637727355066991e-02
    phi[10,0]  R611      -0.0609259150274567
    phi[10,0]  R612      -6.1497990552638826e-02
    phi[10,0]  R613      -6.3806151896729890e-02
    phi[10,0]  R614      -6.3812901729580762e-02
    phi[10,0]  R615      -7.7651337237781393e-02
    phi[10,0]  R616      -0.0877068585752383
    phi[10,0]  R617      -1.1136617016812644e-01
    phi[10,0]  R618      -1.3209995774237460e-01
    phi[10,0]  R619      -2.1598603611215905e-01
    phi[10,0]  R620      -0.0745507447857432
    phi[10,0]  R621      -2.4599290483440761e-01
    phi[10,0]  R622      -3.3833275502274918e-01
    phi[10,0]  R623      -3.6776166571626012e-01
    phi[10,0]  R624      -3.7053685386156188e-01
    phi[10,0]  R625      -3.9260978659853740e-01
    phi[10,0]  R626      -0.501645169739046
    phi[10,0]  R627      -2.1458424893219870e+00
    phi[10,0]  R628      -2.0433588629128638e+00
    phi[10,0]  R629      -1.5959907744974258e+00
    phi[10,0]  R630      -1.0108569126551448e-02
    phi[10,0]  R631      -1.7190948727656252e-02
    phi[10,0]  R632      -0.149937584136836
    phi[10,0]  R633      -1.5060366595931618e-01
    phi[10,0]  R634      -1.6615806735547789e-01
    phi[10,0]  R635      -2.0273695003856884e-01
    phi[10,0]  R636      -2.5101003959953672e-01
    phi[10,0]  R637      -3.3076765701959854e-01
    phi[10,0]  R638      -3.4757006762709519e-01
    phi[10,0]  R639      -3.5795359501154056e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R640      -3.0999999046325684e+00
    phi[1,2]  R641      -3.0999999046325684e+00
    phi[1,2]  R642      -2.2400000095367432e+00
    phi[1,2]  R643      -2.2400000095367432e+00
    phi[1,2]  R644      -3.0999999046325684e+00
    phi[1,2]  R645      -3.0999999046325684e+00
    phi[1,2]  R646      -2.5699999332427979e+00
    phi[1,2]  R647      -2.5699999332427979e+00
    phi[1,2]  R648      -3.0999999046325684e+00
    phi[1,2]  R649      -3.0999999046325684e+00
    phi[1,2]  R650      -2.0899999141693115e+00
    phi[1,2]  R651      -2.0899999141693115e+00
    phi[1,2]  R652      -3.0999999046325684e+00
    phi[1,2]  R653      -3.0999999046325684e+00
    phi[1,2]  R654      1.6361507177352905e+00
    phi[1,2]  R655      1.1735049486160278e+00
    phi[1,2]  R656      -1.4151252806186676e-01
    phi[1,2]  R657      1.3295363187789917e+00
    phi[1,2]  R658      1.62679922580719
    phi[1,2]  R659      1.5266609191894531e+00
    phi[1,2]  R660      4.2324081063270569e-01
    phi[1,2]  R661      5.4782360792160034e-01
    phi[1,2]  R662      1.1228002309799194e+00
    phi[1,2]  R663      1.2193865776062012e+00
    phi[1,2]  R664      -2.0016896724700928e+00
    phi[1,2]  R665      -1.3733358383178711e+00
    phi[1,2]  R666      -1.6341300010681152e+00
    phi[1,2]  R667      -7.5992363691329956e-01
    phi[1,2]  R668      -2.0463745594024658e+00
    phi[1,2]  R669      -2.3026545047760010e+00
    phi[1,2]  R670      -1.0696927309036255e+00
    phi[1,2]  R671      -2.6139483451843262e+00
    phi[1,2]  R672      -0.523598849773407
    phi[1,2]  R673      -1.0860439538955688e+00
    phi[1,2]  R674      -1.6229268312454224e+00
    phi[1,2]  R675      -2.3024783134460449e+00
    phi[1,2]  R676      4.7224009037017822e-01
    phi[1,2]  R677      4.0360659360885620e-01
    phi[1,2]  R678      1.3774034380912781e-01
    phi[1,2]  R679      -4.9206972122192383e-01
    phi[1,2]  R680      7.1789436042308807e-03
    phi[1,2]  R681      8.2730062305927277e-02
    phi[1,2]  R682      -5.4622024297714233e-01
    phi[1,2]  R683      -7.9469686746597290e-01
    phi[1,2]  R684      -1.0041936635971069e+00
    phi[1,2]  R685      1.4215276241302490e+00
    phi[1,2]  R686      -1.1953498125076294e+00
    phi[1,2]  R687      -2.1317377686500549e-01
    phi[1,2]  R688      -1.9219215214252472e-01
    phi[1,2]  R689      -9.0415865182876587e-01
    phi[1,2]  R690      -6.0124200582504272e-01
    phi[1,2]  R691      -3.4522488713264465e-01
    phi[1,2]  R692      7.0743060111999512e-01
    phi[1,2]  R693      3.2159495353698730e-01
    phi[1,2]  R694      1.8246595859527588e+00
    phi[1,2]  R695      2.2224032878875732e+00
    phi[1,2]  R696      1.1582068204879761e+00
    phi[1,2]  R697      1.9939938783645630e+00
    phi[1,2]  R698      2.5680637359619141e-01
    phi[1,2]  R699      2.1178677082061768e+00
    phi[1,2]  R700      -8.5105526447296143e-01
    phi[1,2]  R701      -1.5151352882385254e+00
    phi[1,2]  R702      5.7385343313217163e-01
    phi[1,2]  R703      -4.2715695500373840e-01
    phi[1,2]  R704      -2.5558247566223145e+00
    phi[1,2]  R705      -2.8158311843872070e+00
    phi[1,2]  R706      -1.9218952953815460e-01
    phi[1,2]  R707      -8.9464426040649414e-01
    phi[1,2]  R708      -1.4767144620418549e-01
    phi[1,2]  R709      -3.4098121523857117e-01
    phi[1,2]  R710      -4.9026638269424438e-01
    phi[1,2]  R711      -1.6883240938186646e+00
    phi[1,2]  R712      -5.5318289995193481e-01
    phi[1,2]  R713      -1.1691745519638062e+00
    phi[1,2]  R714      -2.9611584544181824e-01
    phi[1,2]  R715      -9.8703014850616455e-01
    phi[1,2]  R716      1.1613722890615463e-01
    phi[1,2]  R717      6.0494804382324219e-01
    phi[1,2]  R718      -8.1679064035415649e-01
    phi[1,2]  R719      -1.5278806686401367e+00
    phi[1,2]  R720      2.8759082779288292e-02
    phi[1,2]  R721      -1.3866077661514282e+00
    phi[1,2]  R722      -1.4680533409118652e+00
    phi[1,2]  R723      -1.6146802902221680e+00
    phi[1,2]  R724      -2.12121844291687
    phi[1,2]  R725      -2.0795133709907532e-01
    phi[1,2]  R726      -1.3889361619949341e+00
    phi[1,2]  R727      -5.6404328346252441e-01
    phi[1,2]  R728      -1.0033478587865829e-01
    phi[1,2]  R729      5.7391047477722168e-02
    phi[1,2]  R730      -1.3352844119071960e-01
    phi[1,2]  R731      -2.0686526298522949e+00
    phi[1,2]  R732      -3.3407244086265564e-01
    phi[1,2]  R733      -4.7146242856979370e-01
    phi[1,2]  R734      -7.4739313125610352e-01
    phi[1,2]  R735      -8.9688688516616821e-01
    phi[1,2]  R736      -6.2688189744949341e-01
    phi[1,2]  R737      -1.6511464118957520e-01
    phi[1,2]  R738      -1.2634509801864624e+00
    phi[1,2]  R739      -1.5511387586593628e+00
    phi[1,2]  R740      -1.2417839765548706e+00
    phi[1,2]  R741      -9.3216109275817871e-01
    phi[1,2]  R742      5.8865404129028320e-01
    phi[1,2]  R743      2.2698564827442169e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R744      -3.0999999046325684e+00
    phi[2,1]  R745      -3.0999999046325684e+00
    phi[2,1]  R746      -2.2400000095367432e+00
    phi[2,1]  R747      -2.2400000095367432e+00
    phi[2,1]  R748      -3.0999999046325684e+00
    phi[2,1]  R749      -3.0999999046325684e+00
    phi[2,1]  R750      -2.5699999332427979e+00
    phi[2,1]  R751      -2.5699999332427979e+00
    phi[2,1]  R752      -3.0999999046325684e+00
    phi[2,1]  R753      -3.0999999046325684e+00
    phi[2,1]  R754      -2.0899999141693115e+00
    phi[2,1]  R755      -2.0899999141693115e+00
    phi[2,1]  R756      -3.0999999046325684e+00
    phi[2,1]  R757      -3.0999999046325684e+00
    phi[2,1]  R758      1.8246595859527588e+00
    phi[2,1]  R759      2.2224032878875732e+00
    phi[2,1]  R760      1.1582068204879761e+00
    phi[2,1]  R761      1.9939938783645630e+00
    phi[2,1]  R762      2.5680637359619141e-01
    phi[2,1]  R763      2.1178677082061768e+00
    phi[2,1]  R764      -8.5105526447296143e-01
    phi[2,1]  R765      -1.5151352882385254e+00
    phi[2,1]  R766      5.7385343313217163e-01
    phi[2,1]  R767      -4.2715695500373840e-01
    phi[2,1]  R768      -2.5558247566223145e+00
    phi[2,1]  R769      -2.8158311843872070e+00
    phi[2,1]  R770      -1.9218952953815460e-01
    phi[2,1]  R771      -8.9464426040649414e-01
    phi[2,1]  R772      -1.4767144620418549e-01
    phi[2,1]  R773      -3.4098121523857117e-01
    phi[2,1]  R774      -4.9026638269424438e-01
    phi[2,1]  R775      -1.6883240938186646e+00
    phi[2,1]  R776      -5.5318289995193481e-01
    phi[2,1]  R777      -1.1691745519638062e+00
    phi[2,1]  R778      -2.9611584544181824e-01
    phi[2,1]  R779      -9.8703014850616455e-01
    phi[2,1]  R780      1.1613722890615463e-01
    phi[2,1]  R781      6.0494804382324219e-01
    phi[2,1]  R782      -8.1679064035415649e-01
    phi[2,1]  R783      -1.5278806686401367e+00
    phi[2,1]  R784      2.8759082779288292e-02
    phi[2,1]  R785      -1.3866077661514282e+00
    phi[2,1]  R786      -1.4680533409118652e+00
    phi[2,1]  R787      -1.6146802902221680e+00
    phi[2,1]  R788      -2.12121844291687
    phi[2,1]  R789      -2.0795133709907532e-01
    phi[2,1]  R790      -1.3889361619949341e+00
    phi[2,1]  R791      -5.6404328346252441e-01
    phi[2,1]  R792      -1.0033478587865829e-01
    phi[2,1]  R793      5.7391047477722168e-02
    phi[2,1]  R794      -1.3352844119071960e-01
    phi[2,1]  R795      -2.0686526298522949e+00
    phi[2,1]  R796      -3.3407244086265564e-01
    phi[2,1]  R797      -4.7146242856979370e-01
    phi[2,1]  R798      -7.4739313125610352e-01
    phi[2,1]  R799      -8.9688688516616821e-01
    phi[2,1]  R800      -6.2688189744949341e-01
    phi[2,1]  R801      -1.6511464118957520e-01
    phi[2,1]  R802      -1.2634509801864624e+00
    phi[2,1]  R803      -1.5511387586593628e+00
    phi[2,1]  R804      -1.2417839765548706e+00
    phi[2,1]  R805      -9.3216109275817871e-01
    phi[2,1]  R806      5.8865404129028320e-01
    phi[2,1]  R807      2.2698564827442169e-01
    phi[2,1]  R808      1.6361507177352905e+00
    phi[2,1]  R809      1.1735049486160278e+00
    phi[2,1]  R810      -1.4151252806186676e-01
    phi[2,1]  R811      1.3295363187789917e+00
    phi[2,1]  R812      1.62679922580719
    phi[2,1]  R813      1.5266609191894531e+00
    phi[2,1]  R814      4.2324081063270569e-01
    phi[2,1]  R815      5.4782360792160034e-01
    phi[2,1]  R816      1.1228002309799194e+00
    phi[2,1]  R817      1.2193865776062012e+00
    phi[2,1]  R818      -2.0016896724700928e+00
    phi[2,1]  R819      -1.3733358383178711e+00
    phi[2,1]  R820      -1.6341300010681152e+00
    phi[2,1]  R821      -7.5992363691329956e-01
    phi[2,1]  R822      -2.0463745594024658e+00
    phi[2,1]  R823      -2.3026545047760010e+00
    phi[2,1]  R824      -1.0696927309036255e+00
    phi[2,1]  R825      -2.6139483451843262e+00
    phi[2,1]  R826      -0.523598849773407
    phi[2,1]  R827      -1.0860439538955688e+00
    phi[2,1]  R828      -1.6229268312454224e+00
    phi[2,1]  R829      -2.3024783134460449e+00
    phi[2,1]  R830      4.7224009037017822e-01
    phi[2,1]  R831      4.0360659360885620e-01
    phi[2,1]  R832      1.3774034380912781e-01
    phi[2,1]  R833      -4.9206972122192383e-01
    phi[2,1]  R834      7.1789436042308807e-03
    phi[2,1]  R835      8.2730062305927277e-02
    phi[2,1]  R836      -5.4622024297714233e-01
    phi[2,1]  R837      -7.9469686746597290e-01
    phi[2,1]  R838      -1.0041936635971069e+00
    phi[2,1]  R839      1.4215276241302490e+00
    phi[2,1]  R840      -1.1953498125076294e+00
    phi[2,1]  R841      -2.1317377686500549e-01
    phi[2,1]  R842      -1.9219215214252472e-01
    phi[2,1]  R843      -9.0415865182876587e-01
    phi[2,1]  R844      -6.0124200582504272e-01
    phi[2,1]  R845      -3.4522488713264465e-01
    phi[2,1]  R846      7.0743060111999512e-01
    phi[2,1]  R847      3.2159495353698730e-01
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R848      -3.0999999046325684e+00
    phi[1,5]  R849      -3.0999999046325684e+00
    phi[1,5]  R850      -2.2400000095367432e+00
    phi[1,5]  R851      -2.2400000095367432e+00
    phi[1,5]  R852      -3.0999999046325684e+00
    phi[1,5]  R853      -3.0999999046325684e+00
    phi[1,5]  R854      -2.5699999332427979e+00
    phi[1,5]  R855      -2.5699999332427979e+00
    phi[1,5]  R856      -3.0999999046325684e+00
    phi[1,5]  R857      -3.0999999046325684e+00
    phi[1,5]  R858      -2.0899999141693115e+00
    phi[1,5]  R859      -2.0899999141693115e+00
    phi[1,5]  R860      -3.0999999046325684e+00
    phi[1,5]  R861      -3.0999999046325684e+00
    phi[1,5]  R862      1.6361507177352905e+00
    phi[1,5]  R863      1.1735049486160278e+00
    phi[1,5]  R864      -1.4151252806186676e-01
    phi[1,5]  R865      1.3295363187789917e+00
    phi[1,5]  R866      1.62679922580719
    phi[1,5]  R867      1.5266609191894531e+00
    phi[1,5]  R868      4.2324081063270569e-01
    phi[1,5]  R869      5.4782360792160034e-01
    phi[1,5]  R870      1.1228002309799194e+00
    phi[1,5]  R871      1.2193865776062012e+00
    phi[1,5]  R872      -2.0016896724700928e+00
    phi[1,5]  R873      -1.3733358383178711e+00
    phi[1,5]  R874      -1.6341300010681152e+00
    phi[1,5]  R875      -7.5992363691329956e-01
    phi[1,5]  R876      -2.0463745594024658e+00
    phi[1,5]  R877      -2.3026545047760010e+00
    phi[1,5]  R878      -1.0696927309036255e+00
    phi[1,5]  R879      -2.6139483451843262e+00
    phi[1,5]  R880      -0.523598849773407
    phi[1,5]  R881      -1.0860439538955688e+00
    phi[1,5]  R882      -1.6229268312454224e+00
    phi[1,5]  R883      -2.3024783134460449e+00
    phi[1,5]  R884      4.7224009037017822e-01
    phi[1,5]  R885      4.0360659360885620e-01
    phi[1,5]  R886      1.3774034380912781e-01
    phi[1,5]  R887      -4.9206972122192383e-01
    phi[1,5]  R888      7.1789436042308807e-03
    phi[1,5]  R889      8.2730062305927277e-02
    phi[1,5]  R890      -5.4622024297714233e-01
    phi[1,5]  R891      -7.9469686746597290e-01
    phi[1,5]  R892      -1.0041936635971069e+00
    phi[1,5]  R893      1.4215276241302490e+00
    phi[1,5]  R894      -1.1953498125076294e+00
    phi[1,5]  R895      -2.1317377686500549e-01
    phi[1,5]  R896      -1.9219215214252472e-01
    phi[1,5]  R897      -9.0415865182876587e-01
    phi[1,5]  R898      -6.0124200582504272e-01
    phi[1,5]  R899      -3.4522488713264465e-01
    phi[1,5]  R900      7.0743060111999512e-01
    phi[1,5]  R901      3.2159495353698730e-01
    phi[1,5]  R902      -1.0232889652252197e+00
    phi[1,5]  R903      3.5786908864974976e-01
    phi[1,5]  R904      0.792243480682373
    phi[1,5]  R905      1.0327850580215454e+00
    phi[1,5]  R906      -1.3495792150497437e+00
    phi[1,5]  R907      -5.5226409435272217e-01
    phi[1,5]  R908      -0.831960141658783
    phi[1,5]  R909      4.8476386070251465e-01
    phi[1,5]  R910      5.6117624044418335e-01
    phi[1,5]  R911      5.4206192493438721e-01
    phi[1,5]  R912      -2.6080548763275146e+00
    phi[1,5]  R913      1.1814839839935303e+00
    phi[1,5]  R914      -1.0769462585449219e+00
    phi[1,5]  R915      6.0016489028930664e-01
    phi[1,5]  R916      7.3969650268554688e-01
    phi[1,5]  R917      -1.0204908847808838e+00
    phi[1,5]  R918      6.9684582948684692e-01
    phi[1,5]  R919      -5.5375146865844727e-01
    phi[1,5]  R920      -0.172672301530838
    phi[1,5]  R921      -1.8707424402236938e+00
    phi[1,5]  R922      -2.4609239101409912e+00
    phi[1,5]  R923      8.1715232133865356e-01
    phi[1,5]  R924      -8.1758445501327515e-01
    phi[1,5]  R925      -2.0440040528774261e-01
    phi[1,5]  R926      -2.2904960811138153e-01
    phi[1,5]  R927      -1.4300264120101929e+00
    phi[1,5]  R928      -1.06353759765625
    phi[1,5]  R929      1.7268086969852448e-01
    phi[1,5]  R930      9.6812361478805542e-01
    phi[1,5]  R931      -1.1972683668136597e+00
    phi[1,5]  R932      -1.0630195140838623e+00
    phi[1,5]  R933      -6.8205523490905762e-01
    phi[1,5]  R934      6.2805622816085815e-01
    phi[1,5]  R935      9.8153114318847656e-01
    phi[1,5]  R936      -2.0366662740707397e-01
    phi[1,5]  R937      4.2998507618904114e-01
    phi[1,5]  R938      1.8881247043609619e+00
    phi[1,5]  R939      1.3821417093276978e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R940      -3.0999999046325684e+00
    phi[5,1]  R941      -3.0999999046325684e+00
    phi[5,1]  R942      -2.2400000095367432e+00
    phi[5,1]  R943      -2.2400000095367432e+00
    phi[5,1]  R944      -3.0999999046325684e+00
    phi[5,1]  R945      -3.0999999046325684e+00
    phi[5,1]  R946      -2.5699999332427979e+00
    phi[5,1]  R947      -2.5699999332427979e+00
    phi[5,1]  R948      -3.0999999046325684e+00
    phi[5,1]  R949      -3.0999999046325684e+00
    phi[5,1]  R950      -2.0899999141693115e+00
    phi[5,1]  R951      -2.0899999141693115e+00
    phi[5,1]  R952      -3.0999999046325684e+00
    phi[5,1]  R953      -3.0999999046325684e+00
    phi[5,1]  R954      -1.0232889652252197e+00
    phi[5,1]  R955      3.5786908864974976e-01
    phi[5,1]  R956      0.792243480682373
    phi[5,1]  R957      1.0327850580215454e+00
    phi[5,1]  R958      -1.3495792150497437e+00
    phi[5,1]  R959      -5.5226409435272217e-01
    phi[5,1]  R960      -0.831960141658783
    phi[5,1]  R961      4.8476386070251465e-01
    phi[5,1]  R962      5.6117624044418335e-01
    phi[5,1]  R963      5.4206192493438721e-01
    phi[5,1]  R964      -2.6080548763275146e+00
    phi[5,1]  R965      1.1814839839935303e+00
    phi[5,1]  R966      -1.0769462585449219e+00
    phi[5,1]  R967      6.0016489028930664e-01
    phi[5,1]  R968      7.3969650268554688e-01
    phi[5,1]  R969      -1.0204908847808838e+00
    phi[5,1]  R970      6.9684582948684692e-01
    phi[5,1]  R971      -5.5375146865844727e-01
    phi[5,1]  R972      -0.172672301530838
    phi[5,1]  R973      -1.8707424402236938e+00
    phi[5,1]  R974      -2.4609239101409912e+00
    phi[5,1]  R975      8.1715232133865356e-01
    phi[5,1]  R976      -8.1758445501327515e-01
    phi[5,1]  R977      -2.0440040528774261e-01
    phi[5,1]  R978      -2.2904960811138153e-01
    phi[5,1]  R979      -1.4300264120101929e+00
    phi[5,1]  R980      -1.06353759765625
    phi[5,1]  R981      1.7268086969852448e-01
    phi[5,1]  R982      9.6812361478805542e-01
    phi[5,1]  R983      -1.1972683668136597e+00
    phi[5,1]  R984      -1.0630195140838623e+00
    phi[5,1]  R985      -6.8205523490905762e-01
    phi[5,1]  R986      6.2805622816085815e-01
    phi[5,1]  R987      9.8153114318847656e-01
    phi[5,1]  R988      -2.0366662740707397e-01
    phi[5,1]  R989      4.2998507618904114e-01
    phi[5,1]  R990      1.8881247043609619e+00
    phi[5,1]  R991      1.3821417093276978e+00
    phi[5,1]  R992      1.6361507177352905e+00
    phi[5,1]  R993      1.1735049486160278e+00
    phi[5,1]  R994      -1.4151252806186676e-01
    phi[5,1]  R995      1.3295363187789917e+00
    phi[5,1]  R996      1.62679922580719
    phi[5,1]  R997      1.5266609191894531e+00
    phi[5,1]  R998      4.2324081063270569e-01
    phi[5,1]  R999      5.4782360792160034e-01
    phi[5,1]  R1000     1.1228002309799194e+00
    phi[5,1]  R1001     1.2193865776062012e+00
    phi[5,1]  R1002     -2.0016896724700928e+00
    phi[5,1]  R1003     -1.3733358383178711e+00
    phi[5,1]  R1004     -1.6341300010681152e+00
    phi[5,1]  R1005     -7.5992363691329956e-01
    phi[5,1]  R1006     -2.0463745594024658e+00
    phi[5,1]  R1007     -2.3026545047760010e+00
    phi[5,1]  R1008     -1.0696927309036255e+00
    phi[5,1]  R1009     -2.6139483451843262e+00
    phi[5,1]  R1010     -0.523598849773407
    phi[5,1]  R1011     -1.0860439538955688e+00
    phi[5,1]  R1012     -1.6229268312454224e+00
    phi[5,1]  R1013     -2.3024783134460449e+00
    phi[5,1]  R1014     4.7224009037017822e-01
    phi[5,1]  R1015     4.0360659360885620e-01
    phi[5,1]  R1016     1.3774034380912781e-01
    phi[5,1]  R1017     -4.9206972122192383e-01
    phi[5,1]  R1018     7.1789436042308807e-03
    phi[5,1]  R1019     8.2730062305927277e-02
    phi[5,1]  R1020     -5.4622024297714233e-01
    phi[5,1]  R1021     -7.9469686746597290e-01
    phi[5,1]  R1022     -1.0041936635971069e+00
    phi[5,1]  R1023     1.4215276241302490e+00
    phi[5,1]  R1024     -1.1953498125076294e+00
    phi[5,1]  R1025     -2.1317377686500549e-01
    phi[5,1]  R1026     -1.9219215214252472e-01
    phi[5,1]  R1027     -9.0415865182876587e-01
    phi[5,1]  R1028     -6.0124200582504272e-01
    phi[5,1]  R1029     -3.4522488713264465e-01
    phi[5,1]  R1030     7.0743060111999512e-01
    phi[5,1]  R1031     3.2159495353698730e-01
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R1032     -3.0999999046325684e+00
    phi[1,6]  R1033     -3.0999999046325684e+00
    phi[1,6]  R1034     -2.2400000095367432e+00
    phi[1,6]  R1035     -2.2400000095367432e+00
    phi[1,6]  R1036     -3.0999999046325684e+00
    phi[1,6]  R1037     -3.0999999046325684e+00
    phi[1,6]  R1038     -2.5699999332427979e+00
    phi[1,6]  R1039     -2.5699999332427979e+00
    phi[1,6]  R1040     -3.0999999046325684e+00
    phi[1,6]  R1041     -3.0999999046325684e+00
    phi[1,6]  R1042     -2.0899999141693115e+00
    phi[1,6]  R1043     -2.0899999141693115e+00
    phi[1,6]  R1044     -3.0999999046325684e+00
    phi[1,6]  R1045     -3.0999999046325684e+00
    phi[1,6]  R1046     1.6361507177352905e+00
    phi[1,6]  R1047     1.1735049486160278e+00
    phi[1,6]  R1048     -1.4151252806186676e-01
    phi[1,6]  R1049     1.3295363187789917e+00
    phi[1,6]  R1050     1.62679922580719
    phi[1,6]  R1051     1.5266609191894531e+00
    phi[1,6]  R1052     4.2324081063270569e-01
    phi[1,6]  R1053     5.4782360792160034e-01
    phi[1,6]  R1054     1.1228002309799194e+00
    phi[1,6]  R1055     1.2193865776062012e+00
    phi[1,6]  R1056     -2.0016896724700928e+00
    phi[1,6]  R1057     -1.3733358383178711e+00
    phi[1,6]  R1058     -1.6341300010681152e+00
    phi[1,6]  R1059     -7.5992363691329956e-01
    phi[1,6]  R1060     -2.0463745594024658e+00
    phi[1,6]  R1061     -2.3026545047760010e+00
    phi[1,6]  R1062     -1.0696927309036255e+00
    phi[1,6]  R1063     -2.6139483451843262e+00
    phi[1,6]  R1064     -0.523598849773407
    phi[1,6]  R1065     -1.0860439538955688e+00
    phi[1,6]  R1066     -1.6229268312454224e+00
    phi[1,6]  R1067     -2.3024783134460449e+00
    phi[1,6]  R1068     4.7224009037017822e-01
    phi[1,6]  R1069     4.0360659360885620e-01
    phi[1,6]  R1070     1.3774034380912781e-01
    phi[1,6]  R1071     -4.9206972122192383e-01
    phi[1,6]  R1072     7.1789436042308807e-03
    phi[1,6]  R1073     8.2730062305927277e-02
    phi[1,6]  R1074     -5.4622024297714233e-01
    phi[1,6]  R1075     -7.9469686746597290e-01
    phi[1,6]  R1076     -1.0041936635971069e+00
    phi[1,6]  R1077     1.4215276241302490e+00
    phi[1,6]  R1078     -1.1953498125076294e+00
    phi[1,6]  R1079     -2.1317377686500549e-01
    phi[1,6]  R1080     -1.9219215214252472e-01
    phi[1,6]  R1081     -9.0415865182876587e-01
    phi[1,6]  R1082     -6.0124200582504272e-01
    phi[1,6]  R1083     -3.4522488713264465e-01
    phi[1,6]  R1084     7.0743060111999512e-01
    phi[1,6]  R1085     3.2159495353698730e-01
    phi[1,6]  R1086     1.00933039188385
    phi[1,6]  R1087     1.2212057113647461e+00
    phi[1,6]  R1088     4.3360418081283569e-01
    phi[1,6]  R1089     -7.8252464532852173e-02
    phi[1,6]  R1090     3.6776131391525269e-01
    phi[1,6]  R1091     9.5782530307769775e-01
    phi[1,6]  R1092     -0.779298722743988
    phi[1,6]  R1093     -7.7718579769134521e-01
    phi[1,6]  R1094     1.8897460699081421e+00
    phi[1,6]  R1095     3.3889052271842957e-01
    phi[1,6]  R1096     7.4318385124206543e-01
    phi[1,6]  R1097     6.1616539955139160e-01
    phi[1,6]  R1098     -0.672346293926239
    phi[1,6]  R1099     -1.4117884635925293e+00
    phi[1,6]  R1100     -4.8596712946891785e-01
    phi[1,6]  R1101     -1.1458284854888916e+00
    phi[1,6]  R1102     -9.5656543970108032e-01
    phi[1,6]  R1103     -1.1626473665237427e+00
    phi[1,6]  R1104     -1.3600634336471558e+00
    phi[1,6]  R1105     -1.7584589719772339e+00
    phi[1,6]  R1106     -1.4160325527191162e+00
    phi[1,6]  R1107     -4.6216481924057007e-01
    phi[1,6]  R1108     -1.2403523921966553e+00
    phi[1,6]  R1109     -0.743035078048706
    phi[1,6]  R1110     -1.8403687477111816e+00
    phi[1,6]  R1111     -1.0509142875671387e+00
    phi[1,6]  R1112     -1.1336144208908081e+00
    phi[1,6]  R1113     -6.3730305433273315e-01
    phi[1,6]  R1114     -1.1022298336029053e+00
    phi[1,6]  R1115     -1.5698105096817017e+00
    phi[1,6]  R1116     -1.3329949378967285e+00
    phi[1,6]  R1117     1.5379105508327484e-01
    phi[1,6]  R1118     -1.5817296504974365e+00
    phi[1,6]  R1119     -1.3085422515869141e+00
    phi[1,6]  R1120     -3.1768792867660522e-01
    phi[1,6]  R1121     -3.8506698608398438e-01
    phi[1,6]  R1122     -3.4213355183601379e-01
    phi[1,6]  R1123     -1.5788037776947021e+00
    phi[1,6]  R1124     -9.1159260272979736e-01
    phi[1,6]  R1125     -9.8685455322265625e-01
    phi[1,6]  R1126     -6.9986379146575928e-01
    phi[1,6]  R1127     -1.3022774457931519e+00
    phi[1,6]  R1128     -4.5435953140258789e-01
    phi[1,6]  R1129     -8.2899320125579834e-01
    phi[1,6]  R1130     -6.2494152784347534e-01
    phi[1,6]  R1131     -1.3671209812164307e+00
    phi[1,6]  R1132     -1.1223881244659424e+00
    phi[1,6]  R1133     -0.910549521446228
    phi[1,6]  R1134     -2.4844982624053955e+00
    phi[1,6]  R1135     -2.74049711227417
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R1136     -3.0999999046325684e+00
    phi[6,1]  R1137     -3.0999999046325684e+00
    phi[6,1]  R1138     -2.2400000095367432e+00
    phi[6,1]  R1139     -2.2400000095367432e+00
    phi[6,1]  R1140     -3.0999999046325684e+00
    phi[6,1]  R1141     -3.0999999046325684e+00
    phi[6,1]  R1142     -2.5699999332427979e+00
    phi[6,1]  R1143     -2.5699999332427979e+00
    phi[6,1]  R1144     -3.0999999046325684e+00
    phi[6,1]  R1145     -3.0999999046325684e+00
    phi[6,1]  R1146     -2.0899999141693115e+00
    phi[6,1]  R1147     -2.0899999141693115e+00
    phi[6,1]  R1148     -3.0999999046325684e+00
    phi[6,1]  R1149     -3.0999999046325684e+00
    phi[6,1]  R1150     1.00933039188385
    phi[6,1]  R1151     1.2212057113647461e+00
    phi[6,1]  R1152     4.3360418081283569e-01
    phi[6,1]  R1153     -7.8252464532852173e-02
    phi[6,1]  R1154     3.6776131391525269e-01
    phi[6,1]  R1155     9.5782530307769775e-01
    phi[6,1]  R1156     -0.779298722743988
    phi[6,1]  R1157     -7.7718579769134521e-01
    phi[6,1]  R1158     1.8897460699081421e+00
    phi[6,1]  R1159     3.3889052271842957e-01
    phi[6,1]  R1160     7.4318385124206543e-01
    phi[6,1]  R1161     6.1616539955139160e-01
    phi[6,1]  R1162     -0.672346293926239
    phi[6,1]  R1163     -1.4117884635925293e+00
    phi[6,1]  R1164     -4.8596712946891785e-01
    phi[6,1]  R1165     -1.1458284854888916e+00
    phi[6,1]  R1166     -9.5656543970108032e-01
    phi[6,1]  R1167     -1.1626473665237427e+00
    phi[6,1]  R1168     -1.3600634336471558e+00
    phi[6,1]  R1169     -1.7584589719772339e+00
    phi[6,1]  R1170     -1.4160325527191162e+00
    phi[6,1]  R1171     -4.6216481924057007e-01
    phi[6,1]  R1172     -1.2403523921966553e+00
    phi[6,1]  R1173     -0.743035078048706
    phi[6,1]  R1174     -1.8403687477111816e+00
    phi[6,1]  R1175     -1.0509142875671387e+00
    phi[6,1]  R1176     -1.1336144208908081e+00
    phi[6,1]  R1177     -6.3730305433273315e-01
    phi[6,1]  R1178     -1.1022298336029053e+00
    phi[6,1]  R1179     -1.5698105096817017e+00
    phi[6,1]  R1180     -1.3329949378967285e+00
    phi[6,1]  R1181     1.5379105508327484e-01
    phi[6,1]  R1182     -1.5817296504974365e+00
    phi[6,1]  R1183     -1.3085422515869141e+00
    phi[6,1]  R1184     -3.1768792867660522e-01
    phi[6,1]  R1185     -3.8506698608398438e-01
    phi[6,1]  R1186     -3.4213355183601379e-01
    phi[6,1]  R1187     -1.5788037776947021e+00
    phi[6,1]  R1188     -9.1159260272979736e-01
    phi[6,1]  R1189     -9.8685455322265625e-01
    phi[6,1]  R1190     -6.9986379146575928e-01
    phi[6,1]  R1191     -1.3022774457931519e+00
    phi[6,1]  R1192     -4.5435953140258789e-01
    phi[6,1]  R1193     -8.2899320125579834e-01
    phi[6,1]  R1194     -6.2494152784347534e-01
    phi[6,1]  R1195     -1.3671209812164307e+00
    phi[6,1]  R1196     -1.1223881244659424e+00
    phi[6,1]  R1197     -0.910549521446228
    phi[6,1]  R1198     -2.4844982624053955e+00
    phi[6,1]  R1199     -2.74049711227417
    phi[6,1]  R1200     1.6361507177352905e+00
    phi[6,1]  R1201     1.1735049486160278e+00
    phi[6,1]  R1202     -1.4151252806186676e-01
    phi[6,1]  R1203     1.3295363187789917e+00
    phi[6,1]  R1204     1.62679922580719
    phi[6,1]  R1205     1.5266609191894531e+00
    phi[6,1]  R1206     4.2324081063270569e-01
    phi[6,1]  R1207     5.4782360792160034e-01
    phi[6,1]  R1208     1.1228002309799194e+00
    phi[6,1]  R1209     1.2193865776062012e+00
    phi[6,1]  R1210     -2.0016896724700928e+00
    phi[6,1]  R1211     -1.3733358383178711e+00
    phi[6,1]  R1212     -1.6341300010681152e+00
    phi[6,1]  R1213     -7.5992363691329956e-01
    phi[6,1]  R1214     -2.0463745594024658e+00
    phi[6,1]  R1215     -2.3026545047760010e+00
    phi[6,1]  R1216     -1.0696927309036255e+00
    phi[6,1]  R1217     -2.6139483451843262e+00
    phi[6,1]  R1218     -0.523598849773407
    phi[6,1]  R1219     -1.0860439538955688e+00
    phi[6,1]  R1220     -1.6229268312454224e+00
    phi[6,1]  R1221     -2.3024783134460449e+00
    phi[6,1]  R1222     4.7224009037017822e-01
    phi[6,1]  R1223     4.0360659360885620e-01
    phi[6,1]  R1224     1.3774034380912781e-01
    phi[6,1]  R1225     -4.9206972122192383e-01
    phi[6,1]  R1226     7.1789436042308807e-03
    phi[6,1]  R1227     8.2730062305927277e-02
    phi[6,1]  R1228     -5.4622024297714233e-01
    phi[6,1]  R1229     -7.9469686746597290e-01
    phi[6,1]  R1230     -1.0041936635971069e+00
    phi[6,1]  R1231     1.4215276241302490e+00
    phi[6,1]  R1232     -1.1953498125076294e+00
    phi[6,1]  R1233     -2.1317377686500549e-01
    phi[6,1]  R1234     -1.9219215214252472e-01
    phi[6,1]  R1235     -9.0415865182876587e-01
    phi[6,1]  R1236     -6.0124200582504272e-01
    phi[6,1]  R1237     -3.4522488713264465e-01
    phi[6,1]  R1238     7.0743060111999512e-01
    phi[6,1]  R1239     3.2159495353698730e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1240     -3.0999999046325684e+00
    phi[2,3]  R1241     -3.0999999046325684e+00
    phi[2,3]  R1242     -2.2400000095367432e+00
    phi[2,3]  R1243     -2.2400000095367432e+00
    phi[2,3]  R1244     -3.0999999046325684e+00
    phi[2,3]  R1245     -3.0999999046325684e+00
    phi[2,3]  R1246     -2.5699999332427979e+00
    phi[2,3]  R1247     -2.5699999332427979e+00
    phi[2,3]  R1248     -3.0999999046325684e+00
    phi[2,3]  R1249     -3.0999999046325684e+00
    phi[2,3]  R1250     -2.0899999141693115e+00
    phi[2,3]  R1251     -2.0899999141693115e+00
    phi[2,3]  R1252     -3.0999999046325684e+00
    phi[2,3]  R1253     -3.0999999046325684e+00
    phi[2,3]  R1254     1.8246595859527588e+00
    phi[2,3]  R1255     2.2224032878875732e+00
    phi[2,3]  R1256     1.1582068204879761e+00
    phi[2,3]  R1257     1.9939938783645630e+00
    phi[2,3]  R1258     2.5680637359619141e-01
    phi[2,3]  R1259     2.1178677082061768e+00
    phi[2,3]  R1260     -8.5105526447296143e-01
    phi[2,3]  R1261     -1.5151352882385254e+00
    phi[2,3]  R1262     5.7385343313217163e-01
    phi[2,3]  R1263     -4.2715695500373840e-01
    phi[2,3]  R1264     -2.5558247566223145e+00
    phi[2,3]  R1265     -2.8158311843872070e+00
    phi[2,3]  R1266     -1.9218952953815460e-01
    phi[2,3]  R1267     -8.9464426040649414e-01
    phi[2,3]  R1268     -1.4767144620418549e-01
    phi[2,3]  R1269     -3.4098121523857117e-01
    phi[2,3]  R1270     -4.9026638269424438e-01
    phi[2,3]  R1271     -1.6883240938186646e+00
    phi[2,3]  R1272     -5.5318289995193481e-01
    phi[2,3]  R1273     -1.1691745519638062e+00
    phi[2,3]  R1274     -2.9611584544181824e-01
    phi[2,3]  R1275     -9.8703014850616455e-01
    phi[2,3]  R1276     1.1613722890615463e-01
    phi[2,3]  R1277     6.0494804382324219e-01
    phi[2,3]  R1278     -8.1679064035415649e-01
    phi[2,3]  R1279     -1.5278806686401367e+00
    phi[2,3]  R1280     2.8759082779288292e-02
    phi[2,3]  R1281     -1.3866077661514282e+00
    phi[2,3]  R1282     -1.4680533409118652e+00
    phi[2,3]  R1283     -1.6146802902221680e+00
    phi[2,3]  R1284     -2.12121844291687
    phi[2,3]  R1285     -2.0795133709907532e-01
    phi[2,3]  R1286     -1.3889361619949341e+00
    phi[2,3]  R1287     -5.6404328346252441e-01
    phi[2,3]  R1288     -1.0033478587865829e-01
    phi[2,3]  R1289     5.7391047477722168e-02
    phi[2,3]  R1290     -1.3352844119071960e-01
    phi[2,3]  R1291     -2.0686526298522949e+00
    phi[2,3]  R1292     -3.3407244086265564e-01
    phi[2,3]  R1293     -4.7146242856979370e-01
    phi[2,3]  R1294     -7.4739313125610352e-01
    phi[2,3]  R1295     -8.9688688516616821e-01
    phi[2,3]  R1296     -6.2688189744949341e-01
    phi[2,3]  R1297     -1.6511464118957520e-01
    phi[2,3]  R1298     -1.2634509801864624e+00
    phi[2,3]  R1299     -1.5511387586593628e+00
    phi[2,3]  R1300     -1.2417839765548706e+00
    phi[2,3]  R1301     -9.3216109275817871e-01
    phi[2,3]  R1302     5.8865404129028320e-01
    phi[2,3]  R1303     2.2698564827442169e-01
    phi[2,3]  R1304     1.5480201244354248e+00
    phi[2,3]  R1305     7.0049178600311279e-01
    phi[2,3]  R1306     1.54704749584198
    phi[2,3]  R1307     -2.0464763045310974e-01
    phi[2,3]  R1308     2.9985055327415466e-01
    phi[2,3]  R1309     8.1961852312088013e-01
    phi[2,3]  R1310     5.2425020933151245e-01
    phi[2,3]  R1311     1.0571087598800659e+00
    phi[2,3]  R1312     -8.1927388906478882e-02
    phi[2,3]  R1313     1.9017432928085327e+00
    phi[2,3]  R1314     -6.5997236967086792e-01
    phi[2,3]  R1315     -1.5832703113555908e+00
    phi[2,3]  R1316     -1.8651428222656250e+00
    phi[2,3]  R1317     -2.31382417678833
    phi[2,3]  R1318     -1.3079890012741089e+00
    phi[2,3]  R1319     7.4396979808807373e-01
    phi[2,3]  R1320     -2.3948801681399345e-02
    phi[2,3]  R1321     -1.3943114280700684e+00
    phi[2,3]  R1322     -6.8712645769119263e-01
    phi[2,3]  R1323     -1.3972475528717041e+00
    phi[2,3]  R1324     -2.7936937808990479e+00
    phi[2,3]  R1325     3.3975857496261597e-01
    phi[2,3]  R1326     -1.3209210634231567e+00
    phi[2,3]  R1327     3.7263658642768860e-01
    phi[2,3]  R1328     4.5043045282363892e-01
    phi[2,3]  R1329     0.0534965917468071
    phi[2,3]  R1330     -3.1751734018325806e-01
    phi[2,3]  R1331     5.1734995841979980e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1332     -3.0999999046325684e+00
    phi[3,2]  R1333     -3.0999999046325684e+00
    phi[3,2]  R1334     -2.2400000095367432e+00
    phi[3,2]  R1335     -2.2400000095367432e+00
    phi[3,2]  R1336     -3.0999999046325684e+00
    phi[3,2]  R1337     -3.0999999046325684e+00
    phi[3,2]  R1338     -2.5699999332427979e+00
    phi[3,2]  R1339     -2.5699999332427979e+00
    phi[3,2]  R1340     -3.0999999046325684e+00
    phi[3,2]  R1341     -3.0999999046325684e+00
    phi[3,2]  R1342     -2.0899999141693115e+00
    phi[3,2]  R1343     -2.0899999141693115e+00
    phi[3,2]  R1344     -3.0999999046325684e+00
    phi[3,2]  R1345     -3.0999999046325684e+00
    phi[3,2]  R1346     1.5480201244354248e+00
    phi[3,2]  R1347     7.0049178600311279e-01
    phi[3,2]  R1348     1.54704749584198
    phi[3,2]  R1349     -2.0464763045310974e-01
    phi[3,2]  R1350     2.9985055327415466e-01
    phi[3,2]  R1351     8.1961852312088013e-01
    phi[3,2]  R1352     5.2425020933151245e-01
    phi[3,2]  R1353     1.0571087598800659e+00
    phi[3,2]  R1354     -8.1927388906478882e-02
    phi[3,2]  R1355     1.9017432928085327e+00
    phi[3,2]  R1356     -6.5997236967086792e-01
    phi[3,2]  R1357     -1.5832703113555908e+00
    phi[3,2]  R1358     -1.8651428222656250e+00
    phi[3,2]  R1359     -2.31382417678833
    phi[3,2]  R1360     -1.3079890012741089e+00
    phi[3,2]  R1361     7.4396979808807373e-01
    phi[3,2]  R1362     -2.3948801681399345e-02
    phi[3,2]  R1363     -1.3943114280700684e+00
    phi[3,2]  R1364     -6.8712645769119263e-01
    phi[3,2]  R1365     -1.3972475528717041e+00
    phi[3,2]  R1366     -2.7936937808990479e+00
    phi[3,2]  R1367     3.3975857496261597e-01
    phi[3,2]  R1368     -1.3209210634231567e+00
    phi[3,2]  R1369     3.7263658642768860e-01
    phi[3,2]  R1370     4.5043045282363892e-01
    phi[3,2]  R1371     0.0534965917468071
    phi[3,2]  R1372     -3.1751734018325806e-01
    phi[3,2]  R1373     5.1734995841979980e-01
    phi[3,2]  R1374     1.8246595859527588e+00
    phi[3,2]  R1375     2.2224032878875732e+00
    phi[3,2]  R1376     1.1582068204879761e+00
    phi[3,2]  R1377     1.9939938783645630e+00
    phi[3,2]  R1378     2.5680637359619141e-01
    phi[3,2]  R1379     2.1178677082061768e+00
    phi[3,2]  R1380     -8.5105526447296143e-01
    phi[3,2]  R1381     -1.5151352882385254e+00
    phi[3,2]  R1382     5.7385343313217163e-01
    phi[3,2]  R1383     -4.2715695500373840e-01
    phi[3,2]  R1384     -2.5558247566223145e+00
    phi[3,2]  R1385     -2.8158311843872070e+00
    phi[3,2]  R1386     -1.9218952953815460e-01
    phi[3,2]  R1387     -8.9464426040649414e-01
    phi[3,2]  R1388     -1.4767144620418549e-01
    phi[3,2]  R1389     -3.4098121523857117e-01
    phi[3,2]  R1390     -4.9026638269424438e-01
    phi[3,2]  R1391     -1.6883240938186646e+00
    phi[3,2]  R1392     -5.5318289995193481e-01
    phi[3,2]  R1393     -1.1691745519638062e+00
    phi[3,2]  R1394     -2.9611584544181824e-01
    phi[3,2]  R1395     -9.8703014850616455e-01
    phi[3,2]  R1396     1.1613722890615463e-01
    phi[3,2]  R1397     6.0494804382324219e-01
    phi[3,2]  R1398     -8.1679064035415649e-01
    phi[3,2]  R1399     -1.5278806686401367e+00
    phi[3,2]  R1400     2.8759082779288292e-02
    phi[3,2]  R1401     -1.3866077661514282e+00
    phi[3,2]  R1402     -1.4680533409118652e+00
    phi[3,2]  R1403     -1.6146802902221680e+00
    phi[3,2]  R1404     -2.12121844291687
    phi[3,2]  R1405     -2.0795133709907532e-01
    phi[3,2]  R1406     -1.3889361619949341e+00
    phi[3,2]  R1407     -5.6404328346252441e-01
    phi[3,2]  R1408     -1.0033478587865829e-01
    phi[3,2]  R1409     5.7391047477722168e-02
    phi[3,2]  R1410     -1.3352844119071960e-01
    phi[3,2]  R1411     -2.0686526298522949e+00
    phi[3,2]  R1412     -3.3407244086265564e-01
    phi[3,2]  R1413     -4.7146242856979370e-01
    phi[3,2]  R1414     -7.4739313125610352e-01
    phi[3,2]  R1415     -8.9688688516616821e-01
    phi[3,2]  R1416     -6.2688189744949341e-01
    phi[3,2]  R1417     -1.6511464118957520e-01
    phi[3,2]  R1418     -1.2634509801864624e+00
    phi[3,2]  R1419     -1.5511387586593628e+00
    phi[3,2]  R1420     -1.2417839765548706e+00
    phi[3,2]  R1421     -9.3216109275817871e-01
    phi[3,2]  R1422     5.8865404129028320e-01
    phi[3,2]  R1423     2.2698564827442169e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1424     -3.0999999046325684e+00
    phi[3,4]  R1425     -3.0999999046325684e+00
    phi[3,4]  R1426     -2.2400000095367432e+00
    phi[3,4]  R1427     -2.2400000095367432e+00
    phi[3,4]  R1428     -3.0999999046325684e+00
    phi[3,4]  R1429     -3.0999999046325684e+00
    phi[3,4]  R1430     -2.5699999332427979e+00
    phi[3,4]  R1431     -2.5699999332427979e+00
    phi[3,4]  R1432     -3.0999999046325684e+00
    phi[3,4]  R1433     -3.0999999046325684e+00
    phi[3,4]  R1434     -2.0899999141693115e+00
    phi[3,4]  R1435     -2.0899999141693115e+00
    phi[3,4]  R1436     -3.0999999046325684e+00
    phi[3,4]  R1437     -3.0999999046325684e+00
    phi[3,4]  R1438     1.5480201244354248e+00
    phi[3,4]  R1439     7.0049178600311279e-01
    phi[3,4]  R1440     1.54704749584198
    phi[3,4]  R1441     -2.0464763045310974e-01
    phi[3,4]  R1442     2.9985055327415466e-01
    phi[3,4]  R1443     8.1961852312088013e-01
    phi[3,4]  R1444     5.2425020933151245e-01
    phi[3,4]  R1445     1.0571087598800659e+00
    phi[3,4]  R1446     -8.1927388906478882e-02
    phi[3,4]  R1447     1.9017432928085327e+00
    phi[3,4]  R1448     -6.5997236967086792e-01
    phi[3,4]  R1449     -1.5832703113555908e+00
    phi[3,4]  R1450     -1.8651428222656250e+00
    phi[3,4]  R1451     -2.31382417678833
    phi[3,4]  R1452     -1.3079890012741089e+00
    phi[3,4]  R1453     7.4396979808807373e-01
    phi[3,4]  R1454     -2.3948801681399345e-02
    phi[3,4]  R1455     -1.3943114280700684e+00
    phi[3,4]  R1456     -6.8712645769119263e-01
    phi[3,4]  R1457     -1.3972475528717041e+00
    phi[3,4]  R1458     -2.7936937808990479e+00
    phi[3,4]  R1459     3.3975857496261597e-01
    phi[3,4]  R1460     -1.3209210634231567e+00
    phi[3,4]  R1461     3.7263658642768860e-01
    phi[3,4]  R1462     4.5043045282363892e-01
    phi[3,4]  R1463     0.0534965917468071
    phi[3,4]  R1464     -3.1751734018325806e-01
    phi[3,4]  R1465     5.1734995841979980e-01
    phi[3,4]  R1466     6.2170600891113281e-01
    phi[3,4]  R1467     2.1279633045196533e+00
    phi[3,4]  R1468     2.0004837512969971e+00
    phi[3,4]  R1469     0.452804297208786
    phi[3,4]  R1470     1.5582925081253052e+00
    phi[3,4]  R1471     4.5388571918010712e-02
    phi[3,4]  R1472     2.5294992923736572e+00
    phi[3,4]  R1473     1.0002244710922241e+00
    phi[3,4]  R1474     2.4925587177276611e+00
    phi[3,4]  R1475     5.4746210575103760e-01
    phi[3,4]  R1476     2.4810819327831268e-01
    phi[3,4]  R1477     3.4580603241920471e-01
    phi[3,4]  R1478     5.6614893674850464e-01
    phi[3,4]  R1479     -2.3045943677425385e-01
    phi[3,4]  R1480     4.2967402935028076e-01
    phi[3,4]  R1481     9.3075297772884369e-02
    phi[3,4]  R1482     -7.8751826286315918e-01
    phi[3,4]  R1483     -3.4206229448318481e-01
    phi[3,4]  R1484     5.5558836460113525e-01
    phi[3,4]  R1485     -1.1211527585983276e+00
    phi[3,4]  R1486     9.8492264747619629e-02
    phi[3,4]  R1487     -1.3209887742996216e+00
    phi[3,4]  R1488     -1.4565176963806152e+00
    phi[3,4]  R1489     8.6437717080116272e-02
    phi[3,4]  R1490     -5.3539866209030151e-01
    phi[3,4]  R1491     7.7562093734741211e-01
    phi[3,4]  R1492     4.0582489967346191e-01
    phi[3,4]  R1493     -2.3410730361938477e+00
    phi[3,4]  R1494     -2.2030205726623535e+00
    phi[3,4]  R1495     -2.9685206413269043e+00
    phi[3,4]  R1496     3.7826669216156006e-01
    phi[3,4]  R1497     1.9905675947666168e-01
    phi[3,4]  R1498     -8.3196485042572021e-01
    phi[3,4]  R1499     -9.1985964775085449e-01
    phi[3,4]  R1500     4.0227809548377991e-01
    phi[3,4]  R1501     1.3068015873432159e-01
    phi[3,4]  R1502     9.8426455259323120e-01
    phi[3,4]  R1503     1.3313318490982056e+00
    phi[3,4]  R1504     1.5982537269592285e+00
    phi[3,4]  R1505     -1.1697568893432617e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1506     -3.0999999046325684e+00
    phi[4,3]  R1507     -3.0999999046325684e+00
    phi[4,3]  R1508     -2.2400000095367432e+00
    phi[4,3]  R1509     -2.2400000095367432e+00
    phi[4,3]  R1510     -3.0999999046325684e+00
    phi[4,3]  R1511     -3.0999999046325684e+00
    phi[4,3]  R1512     -2.5699999332427979e+00
    phi[4,3]  R1513     -2.5699999332427979e+00
    phi[4,3]  R1514     -3.0999999046325684e+00
    phi[4,3]  R1515     -3.0999999046325684e+00
    phi[4,3]  R1516     -2.0899999141693115e+00
    phi[4,3]  R1517     -2.0899999141693115e+00
    phi[4,3]  R1518     -3.0999999046325684e+00
    phi[4,3]  R1519     -3.0999999046325684e+00
    phi[4,3]  R1520     6.2170600891113281e-01
    phi[4,3]  R1521     2.1279633045196533e+00
    phi[4,3]  R1522     2.0004837512969971e+00
    phi[4,3]  R1523     0.452804297208786
    phi[4,3]  R1524     1.5582925081253052e+00
    phi[4,3]  R1525     4.5388571918010712e-02
    phi[4,3]  R1526     2.5294992923736572e+00
    phi[4,3]  R1527     1.0002244710922241e+00
    phi[4,3]  R1528     2.4925587177276611e+00
    phi[4,3]  R1529     5.4746210575103760e-01
    phi[4,3]  R1530     2.4810819327831268e-01
    phi[4,3]  R1531     3.4580603241920471e-01
    phi[4,3]  R1532     5.6614893674850464e-01
    phi[4,3]  R1533     -2.3045943677425385e-01
    phi[4,3]  R1534     4.2967402935028076e-01
    phi[4,3]  R1535     9.3075297772884369e-02
    phi[4,3]  R1536     -7.8751826286315918e-01
    phi[4,3]  R1537     -3.4206229448318481e-01
    phi[4,3]  R1538     5.5558836460113525e-01
    phi[4,3]  R1539     -1.1211527585983276e+00
    phi[4,3]  R1540     9.8492264747619629e-02
    phi[4,3]  R1541     -1.3209887742996216e+00
    phi[4,3]  R1542     -1.4565176963806152e+00
    phi[4,3]  R1543     8.6437717080116272e-02
    phi[4,3]  R1544     -5.3539866209030151e-01
    phi[4,3]  R1545     7.7562093734741211e-01
    phi[4,3]  R1546     4.0582489967346191e-01
    phi[4,3]  R1547     -2.3410730361938477e+00
    phi[4,3]  R1548     -2.2030205726623535e+00
    phi[4,3]  R1549     -2.9685206413269043e+00
    phi[4,3]  R1550     3.7826669216156006e-01
    phi[4,3]  R1551     1.9905675947666168e-01
    phi[4,3]  R1552     -8.3196485042572021e-01
    phi[4,3]  R1553     -9.1985964775085449e-01
    phi[4,3]  R1554     4.0227809548377991e-01
    phi[4,3]  R1555     1.3068015873432159e-01
    phi[4,3]  R1556     9.8426455259323120e-01
    phi[4,3]  R1557     1.3313318490982056e+00
    phi[4,3]  R1558     1.5982537269592285e+00
    phi[4,3]  R1559     -1.1697568893432617e+00
    phi[4,3]  R1560     1.5480201244354248e+00
    phi[4,3]  R1561     7.0049178600311279e-01
    phi[4,3]  R1562     1.54704749584198
    phi[4,3]  R1563     -2.0464763045310974e-01
    phi[4,3]  R1564     2.9985055327415466e-01
    phi[4,3]  R1565     8.1961852312088013e-01
    phi[4,3]  R1566     5.2425020933151245e-01
    phi[4,3]  R1567     1.0571087598800659e+00
    phi[4,3]  R1568     -8.1927388906478882e-02
    phi[4,3]  R1569     1.9017432928085327e+00
    phi[4,3]  R1570     -6.5997236967086792e-01
    phi[4,3]  R1571     -1.5832703113555908e+00
    phi[4,3]  R1572     -1.8651428222656250e+00
    phi[4,3]  R1573     -2.31382417678833
    phi[4,3]  R1574     -1.3079890012741089e+00
    phi[4,3]  R1575     7.4396979808807373e-01
    phi[4,3]  R1576     -2.3948801681399345e-02
    phi[4,3]  R1577     -1.3943114280700684e+00
    phi[4,3]  R1578     -6.8712645769119263e-01
    phi[4,3]  R1579     -1.3972475528717041e+00
    phi[4,3]  R1580     -2.7936937808990479e+00
    phi[4,3]  R1581     3.3975857496261597e-01
    phi[4,3]  R1582     -1.3209210634231567e+00
    phi[4,3]  R1583     3.7263658642768860e-01
    phi[4,3]  R1584     4.5043045282363892e-01
    phi[4,3]  R1585     0.0534965917468071
    phi[4,3]  R1586     -3.1751734018325806e-01
    phi[4,3]  R1587     5.1734995841979980e-01
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R72       -1
    phi[3,8]  R1588     -3.0999999046325684e+00
    phi[3,8]  R1589     -3.0999999046325684e+00
    phi[3,8]  R1590     -2.2400000095367432e+00
    phi[3,8]  R1591     -2.2400000095367432e+00
    phi[3,8]  R1592     -3.0999999046325684e+00
    phi[3,8]  R1593     -3.0999999046325684e+00
    phi[3,8]  R1594     -2.5699999332427979e+00
    phi[3,8]  R1595     -2.5699999332427979e+00
    phi[3,8]  R1596     -3.0999999046325684e+00
    phi[3,8]  R1597     -3.0999999046325684e+00
    phi[3,8]  R1598     -2.0899999141693115e+00
    phi[3,8]  R1599     -2.0899999141693115e+00
    phi[3,8]  R1600     -3.0999999046325684e+00
    phi[3,8]  R1601     -3.0999999046325684e+00
    phi[3,8]  R1602     1.5480201244354248e+00
    phi[3,8]  R1603     7.0049178600311279e-01
    phi[3,8]  R1604     1.54704749584198
    phi[3,8]  R1605     -2.0464763045310974e-01
    phi[3,8]  R1606     2.9985055327415466e-01
    phi[3,8]  R1607     8.1961852312088013e-01
    phi[3,8]  R1608     5.2425020933151245e-01
    phi[3,8]  R1609     1.0571087598800659e+00
    phi[3,8]  R1610     -8.1927388906478882e-02
    phi[3,8]  R1611     1.9017432928085327e+00
    phi[3,8]  R1612     -6.5997236967086792e-01
    phi[3,8]  R1613     -1.5832703113555908e+00
    phi[3,8]  R1614     -1.8651428222656250e+00
    phi[3,8]  R1615     -2.31382417678833
    phi[3,8]  R1616     -1.3079890012741089e+00
    phi[3,8]  R1617     7.4396979808807373e-01
    phi[3,8]  R1618     -2.3948801681399345e-02
    phi[3,8]  R1619     -1.3943114280700684e+00
    phi[3,8]  R1620     -6.8712645769119263e-01
    phi[3,8]  R1621     -1.3972475528717041e+00
    phi[3,8]  R1622     -2.7936937808990479e+00
    phi[3,8]  R1623     3.3975857496261597e-01
    phi[3,8]  R1624     -1.3209210634231567e+00
    phi[3,8]  R1625     3.7263658642768860e-01
    phi[3,8]  R1626     4.5043045282363892e-01
    phi[3,8]  R1627     0.0534965917468071
    phi[3,8]  R1628     -3.1751734018325806e-01
    phi[3,8]  R1629     5.1734995841979980e-01
    phi[3,8]  R1630     1.5900038480758667e+00
    phi[3,8]  R1631     1.3526426553726196e+00
    phi[3,8]  R1632     2.1643614768981934e+00
    phi[3,8]  R1633     3.1673642992973328e-01
    phi[3,8]  R1634     8.0866515636444092e-01
    phi[3,8]  R1635     3.5792659968137741e-02
    phi[3,8]  R1636     -7.1106158196926117e-02
    phi[3,8]  R1637     2.4370159953832626e-02
    phi[3,8]  R1638     -1.2409540265798569e-01
    phi[3,8]  R1639     4.5133709907531738e-01
    phi[3,8]  R1640     -3.1005780696868896e+00
    phi[3,8]  R1641     -1.9249148368835449e+00
    phi[3,8]  R1642     -1.3096462488174438e+00
    phi[3,8]  R1643     -3.1428072452545166e+00
    phi[3,8]  R1644     -8.0413514375686646e-01
    phi[3,8]  R1645     -1.4209822416305542e+00
    phi[3,8]  R1646     3.9826259016990662e-01
    phi[3,8]  R1647     -1.1001037359237671e+00
    phi[3,8]  R1648     -2.1943154335021973e+00
    phi[3,8]  R1649     6.7347484827041626e-01
    phi[3,8]  R1650     -1.8761850595474243e+00
    phi[3,8]  R1651     -1.5248543024063110e+00
    phi[3,8]  R1652     -2.7397339344024658e+00
    phi[3,8]  R1653     -3.1009871959686279e+00
    phi[3,8]  R1654     -2.2245254516601562e+00
    phi[3,8]  R1655     -1.8342665433883667e+00
    phi[3,8]  R1656     -1.8793213367462158e+00
    phi[3,8]  R1657     -1.4688704013824463e+00
    phi[3,8]  R1658     -3.6108803749084473e-01
    phi[3,8]  R1659     -1.7022855281829834e+00
    phi[3,8]  R1660     -1.1324381828308105e+00
    phi[3,8]  R1661     -4.3896457552909851e-01
    phi[3,8]  R1662     -8.1192421913146973e-01
    phi[3,8]  R1663     -1.0869233608245850e+00
    phi[3,8]  R1664     -8.6438196897506714e-01
    phi[3,8]  R1665     -4.5088860392570496e-01
    phi[3,8]  R1666     -3.8277313113212585e-01
    phi[3,8]  R1667     -3.8946744799613953e-01
    phi[3,8]  R1668     2.0883843302726746e-01
    phi[3,8]  R1669     -8.9241534471511841e-01
    phi[8,3]  R27       -1
    phi[8,3]  R72       1
    phi[8,3]  R73       1
    phi[8,3]  R1670     -3.0999999046325684e+00
    phi[8,3]  R1671     -3.0999999046325684e+00
    phi[8,3]  R1672     -2.2400000095367432e+00
    phi[8,3]  R1673     -2.2400000095367432e+00
    phi[8,3]  R1674     -3.0999999046325684e+00
    phi[8,3]  R1675     -3.0999999046325684e+00
    phi[8,3]  R1676     -2.5699999332427979e+00
    phi[8,3]  R1677     -2.5699999332427979e+00
    phi[8,3]  R1678     -3.0999999046325684e+00
    phi[8,3]  R1679     -3.0999999046325684e+00
    phi[8,3]  R1680     -2.0899999141693115e+00
    phi[8,3]  R1681     -2.0899999141693115e+00
    phi[8,3]  R1682     -3.0999999046325684e+00
    phi[8,3]  R1683     -3.0999999046325684e+00
    phi[8,3]  R1684     1.5900038480758667e+00
    phi[8,3]  R1685     1.3526426553726196e+00
    phi[8,3]  R1686     2.1643614768981934e+00
    phi[8,3]  R1687     3.1673642992973328e-01
    phi[8,3]  R1688     8.0866515636444092e-01
    phi[8,3]  R1689     3.5792659968137741e-02
    phi[8,3]  R1690     -7.1106158196926117e-02
    phi[8,3]  R1691     2.4370159953832626e-02
    phi[8,3]  R1692     -1.2409540265798569e-01
    phi[8,3]  R1693     4.5133709907531738e-01
    phi[8,3]  R1694     -3.1005780696868896e+00
    phi[8,3]  R1695     -1.9249148368835449e+00
    phi[8,3]  R1696     -1.3096462488174438e+00
    phi[8,3]  R1697     -3.1428072452545166e+00
    phi[8,3]  R1698     -8.0413514375686646e-01
    phi[8,3]  R1699     -1.4209822416305542e+00
    phi[8,3]  R1700     3.9826259016990662e-01
    phi[8,3]  R1701     -1.1001037359237671e+00
    phi[8,3]  R1702     -2.1943154335021973e+00
    phi[8,3]  R1703     6.7347484827041626e-01
    phi[8,3]  R1704     -1.8761850595474243e+00
    phi[8,3]  R1705     -1.5248543024063110e+00
    phi[8,3]  R1706     -2.7397339344024658e+00
    phi[8,3]  R1707     -3.1009871959686279e+00
    phi[8,3]  R1708     -2.2245254516601562e+00
    phi[8,3]  R1709     -1.8342665433883667e+00
    phi[8,3]  R1710     -1.8793213367462158e+00
    phi[8,3]  R1711     -1.4688704013824463e+00
    phi[8,3]  R1712     -3.6108803749084473e-01
    phi[8,3]  R1713     -1.7022855281829834e+00
    phi[8,3]  R1714     -1.1324381828308105e+00
    phi[8,3]  R1715     -4.3896457552909851e-01
    phi[8,3]  R1716     -8.1192421913146973e-01
    phi[8,3]  R1717     -1.0869233608245850e+00
    phi[8,3]  R1718     -8.6438196897506714e-01
    phi[8,3]  R1719     -4.5088860392570496e-01
    phi[8,3]  R1720     -3.8277313113212585e-01
    phi[8,3]  R1721     -3.8946744799613953e-01
    phi[8,3]  R1722     2.0883843302726746e-01
    phi[8,3]  R1723     -8.9241534471511841e-01
    phi[8,3]  R1724     1.5480201244354248e+00
    phi[8,3]  R1725     7.0049178600311279e-01
    phi[8,3]  R1726     1.54704749584198
    phi[8,3]  R1727     -2.0464763045310974e-01
    phi[8,3]  R1728     2.9985055327415466e-01
    phi[8,3]  R1729     8.1961852312088013e-01
    phi[8,3]  R1730     5.2425020933151245e-01
    phi[8,3]  R1731     1.0571087598800659e+00
    phi[8,3]  R1732     -8.1927388906478882e-02
    phi[8,3]  R1733     1.9017432928085327e+00
    phi[8,3]  R1734     -6.5997236967086792e-01
    phi[8,3]  R1735     -1.5832703113555908e+00
    phi[8,3]  R1736     -1.8651428222656250e+00
    phi[8,3]  R1737     -2.31382417678833
    phi[8,3]  R1738     -1.3079890012741089e+00
    phi[8,3]  R1739     7.4396979808807373e-01
    phi[8,3]  R1740     -2.3948801681399345e-02
    phi[8,3]  R1741     -1.3943114280700684e+00
    phi[8,3]  R1742     -6.8712645769119263e-01
    phi[8,3]  R1743     -1.3972475528717041e+00
    phi[8,3]  R1744     -2.7936937808990479e+00
    phi[8,3]  R1745     3.3975857496261597e-01
    phi[8,3]  R1746     -1.3209210634231567e+00
    phi[8,3]  R1747     3.7263658642768860e-01
    phi[8,3]  R1748     4.5043045282363892e-01
    phi[8,3]  R1749     0.0534965917468071
    phi[8,3]  R1750     -3.1751734018325806e-01
    phi[8,3]  R1751     5.1734995841979980e-01
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R81       -1
    phi[3,9]  R1752     -3.0999999046325684e+00
    phi[3,9]  R1753     -3.0999999046325684e+00
    phi[3,9]  R1754     -2.2400000095367432e+00
    phi[3,9]  R1755     -2.2400000095367432e+00
    phi[3,9]  R1756     -3.0999999046325684e+00
    phi[3,9]  R1757     -3.0999999046325684e+00
    phi[3,9]  R1758     -2.5699999332427979e+00
    phi[3,9]  R1759     -2.5699999332427979e+00
    phi[3,9]  R1760     -3.0999999046325684e+00
    phi[3,9]  R1761     -3.0999999046325684e+00
    phi[3,9]  R1762     -2.0899999141693115e+00
    phi[3,9]  R1763     -2.0899999141693115e+00
    phi[3,9]  R1764     -3.0999999046325684e+00
    phi[3,9]  R1765     -3.0999999046325684e+00
    phi[3,9]  R1766     1.5480201244354248e+00
    phi[3,9]  R1767     7.0049178600311279e-01
    phi[3,9]  R1768     1.54704749584198
    phi[3,9]  R1769     -2.0464763045310974e-01
    phi[3,9]  R1770     2.9985055327415466e-01
    phi[3,9]  R1771     8.1961852312088013e-01
    phi[3,9]  R1772     5.2425020933151245e-01
    phi[3,9]  R1773     1.0571087598800659e+00
    phi[3,9]  R1774     -8.1927388906478882e-02
    phi[3,9]  R1775     1.9017432928085327e+00
    phi[3,9]  R1776     -6.5997236967086792e-01
    phi[3,9]  R1777     -1.5832703113555908e+00
    phi[3,9]  R1778     -1.8651428222656250e+00
    phi[3,9]  R1779     -2.31382417678833
    phi[3,9]  R1780     -1.3079890012741089e+00
    phi[3,9]  R1781     7.4396979808807373e-01
    phi[3,9]  R1782     -2.3948801681399345e-02
    phi[3,9]  R1783     -1.3943114280700684e+00
    phi[3,9]  R1784     -6.8712645769119263e-01
    phi[3,9]  R1785     -1.3972475528717041e+00
    phi[3,9]  R1786     -2.7936937808990479e+00
    phi[3,9]  R1787     3.3975857496261597e-01
    phi[3,9]  R1788     -1.3209210634231567e+00
    phi[3,9]  R1789     3.7263658642768860e-01
    phi[3,9]  R1790     4.5043045282363892e-01
    phi[3,9]  R1791     0.0534965917468071
    phi[3,9]  R1792     -3.1751734018325806e-01
    phi[3,9]  R1793     5.1734995841979980e-01
    phi[3,9]  R1794     6.3460016250610352e-01
    phi[3,9]  R1795     2.2506461143493652e+00
    phi[3,9]  R1796     8.7076562643051147e-01
    phi[3,9]  R1797     1.1134877204895020e+00
    phi[3,9]  R1798     3.1637576222419739e-01
    phi[3,9]  R1799     2.1788221597671509e-01
    phi[3,9]  R1800     1.1377960443496704e+00
    phi[3,9]  R1801     1.7765930891036987e+00
    phi[3,9]  R1802     5.9639662504196167e-01
    phi[3,9]  R1803     2.9996076226234436e-01
    phi[3,9]  R1804     -1.5023715496063232e+00
    phi[3,9]  R1805     -7.5516235828399658e-01
    phi[3,9]  R1806     -7.0189911127090454e-01
    phi[3,9]  R1807     -2.0310158729553223e+00
    phi[3,9]  R1808     -1.3993563652038574e+00
    phi[3,9]  R1809     -5.4260241985321045e-01
    phi[3,9]  R1810     -1.6482514142990112e+00
    phi[3,9]  R1811     -1.6467052698135376e+00
    phi[3,9]  R1812     -3.9583319425582886e-01
    phi[3,9]  R1813     -1.1706986427307129e+00
    phi[3,9]  R1814     -1.4146103858947754e+00
    phi[3,9]  R1815     -1.2352807521820068e+00
    phi[3,9]  R1816     1.0694512128829956e+00
    phi[3,9]  R1817     -1.8712776899337769e-01
    phi[3,9]  R1818     -1.3669791221618652e+00
    phi[3,9]  R1819     -1.1871256828308105e+00
    phi[3,9]  R1820     1.9679437577724457e-01
    phi[3,9]  R1821     -2.2593417167663574e+00
    phi[3,9]  R1822     4.6024173498153687e-01
    phi[3,9]  R1823     0.0946318507194519
    phi[9,3]  R27       -1
    phi[9,3]  R81       1
    phi[9,3]  R82       1
    phi[9,3]  R1824     -3.0999999046325684e+00
    phi[9,3]  R1825     -3.0999999046325684e+00
    phi[9,3]  R1826     -2.2400000095367432e+00
    phi[9,3]  R1827     -2.2400000095367432e+00
    phi[9,3]  R1828     -3.0999999046325684e+00
    phi[9,3]  R1829     -3.0999999046325684e+00
    phi[9,3]  R1830     -2.5699999332427979e+00
    phi[9,3]  R1831     -2.5699999332427979e+00
    phi[9,3]  R1832     -3.0999999046325684e+00
    phi[9,3]  R1833     -3.0999999046325684e+00
    phi[9,3]  R1834     -2.0899999141693115e+00
    phi[9,3]  R1835     -2.0899999141693115e+00
    phi[9,3]  R1836     -3.0999999046325684e+00
    phi[9,3]  R1837     -3.0999999046325684e+00
    phi[9,3]  R1838     6.3460016250610352e-01
    phi[9,3]  R1839     2.2506461143493652e+00
    phi[9,3]  R1840     8.7076562643051147e-01
    phi[9,3]  R1841     1.1134877204895020e+00
    phi[9,3]  R1842     3.1637576222419739e-01
    phi[9,3]  R1843     2.1788221597671509e-01
    phi[9,3]  R1844     1.1377960443496704e+00
    phi[9,3]  R1845     1.7765930891036987e+00
    phi[9,3]  R1846     5.9639662504196167e-01
    phi[9,3]  R1847     2.9996076226234436e-01
    phi[9,3]  R1848     -1.5023715496063232e+00
    phi[9,3]  R1849     -7.5516235828399658e-01
    phi[9,3]  R1850     -7.0189911127090454e-01
    phi[9,3]  R1851     -2.0310158729553223e+00
    phi[9,3]  R1852     -1.3993563652038574e+00
    phi[9,3]  R1853     -5.4260241985321045e-01
    phi[9,3]  R1854     -1.6482514142990112e+00
    phi[9,3]  R1855     -1.6467052698135376e+00
    phi[9,3]  R1856     -3.9583319425582886e-01
    phi[9,3]  R1857     -1.1706986427307129e+00
    phi[9,3]  R1858     -1.4146103858947754e+00
    phi[9,3]  R1859     -1.2352807521820068e+00
    phi[9,3]  R1860     1.0694512128829956e+00
    phi[9,3]  R1861     -1.8712776899337769e-01
    phi[9,3]  R1862     -1.3669791221618652e+00
    phi[9,3]  R1863     -1.1871256828308105e+00
    phi[9,3]  R1864     1.9679437577724457e-01
    phi[9,3]  R1865     -2.2593417167663574e+00
    phi[9,3]  R1866     4.6024173498153687e-01
    phi[9,3]  R1867     0.0946318507194519
    phi[9,3]  R1868     1.5480201244354248e+00
    phi[9,3]  R1869     7.0049178600311279e-01
    phi[9,3]  R1870     1.54704749584198
    phi[9,3]  R1871     -2.0464763045310974e-01
    phi[9,3]  R1872     2.9985055327415466e-01
    phi[9,3]  R1873     8.1961852312088013e-01
    phi[9,3]  R1874     5.2425020933151245e-01
    phi[9,3]  R1875     1.0571087598800659e+00
    phi[9,3]  R1876     -8.1927388906478882e-02
    phi[9,3]  R1877     1.9017432928085327e+00
    phi[9,3]  R1878     -6.5997236967086792e-01
    phi[9,3]  R1879     -1.5832703113555908e+00
    phi[9,3]  R1880     -1.8651428222656250e+00
    phi[9,3]  R1881     -2.31382417678833
    phi[9,3]  R1882     -1.3079890012741089e+00
    phi[9,3]  R1883     7.4396979808807373e-01
    phi[9,3]  R1884     -2.3948801681399345e-02
    phi[9,3]  R1885     -1.3943114280700684e+00
    phi[9,3]  R1886     -6.8712645769119263e-01
    phi[9,3]  R1887     -1.3972475528717041e+00
    phi[9,3]  R1888     -2.7936937808990479e+00
    phi[9,3]  R1889     3.3975857496261597e-01
    phi[9,3]  R1890     -1.3209210634231567e+00
    phi[9,3]  R1891     3.7263658642768860e-01
    phi[9,3]  R1892     4.5043045282363892e-01
    phi[9,3]  R1893     0.0534965917468071
    phi[9,3]  R1894     -3.1751734018325806e-01
    phi[9,3]  R1895     5.1734995841979980e-01
    phi[4,9]  R36       1
    phi[4,9]  R37       1
    phi[4,9]  R81       -1
    phi[4,9]  R1896     -3.0999999046325684e+00
    phi[4,9]  R1897     -3.0999999046325684e+00
    phi[4,9]  R1898     -2.2400000095367432e+00
    phi[4,9]  R1899     -2.2400000095367432e+00
    phi[4,9]  R1900     -3.0999999046325684e+00
    phi[4,9]  R1901     -3.0999999046325684e+00
    phi[4,9]  R1902     -2.5699999332427979e+00
    phi[4,9]  R1903     -2.5699999332427979e+00
    phi[4,9]  R1904     -3.0999999046325684e+00
    phi[4,9]  R1905     -3.0999999046325684e+00
    phi[4,9]  R1906     -2.0899999141693115e+00
    phi[4,9]  R1907     -2.0899999141693115e+00
    phi[4,9]  R1908     -3.0999999046325684e+00
    phi[4,9]  R1909     -3.0999999046325684e+00
    phi[4,9]  R1910     6.2170600891113281e-01
    phi[4,9]  R1911     2.1279633045196533e+00
    phi[4,9]  R1912     2.0004837512969971e+00
    phi[4,9]  R1913     0.452804297208786
    phi[4,9]  R1914     1.5582925081253052e+00
    phi[4,9]  R1915     4.5388571918010712e-02
    phi[4,9]  R1916     2.5294992923736572e+00
    phi[4,9]  R1917     1.0002244710922241e+00
    phi[4,9]  R1918     2.4925587177276611e+00
    phi[4,9]  R1919     5.4746210575103760e-01
    phi[4,9]  R1920     2.4810819327831268e-01
    phi[4,9]  R1921     3.4580603241920471e-01
    phi[4,9]  R1922     5.6614893674850464e-01
    phi[4,9]  R1923     -2.3045943677425385e-01
    phi[4,9]  R1924     4.2967402935028076e-01
    phi[4,9]  R1925     9.3075297772884369e-02
    phi[4,9]  R1926     -7.8751826286315918e-01
    phi[4,9]  R1927     -3.4206229448318481e-01
    phi[4,9]  R1928     5.5558836460113525e-01
    phi[4,9]  R1929     -1.1211527585983276e+00
    phi[4,9]  R1930     9.8492264747619629e-02
    phi[4,9]  R1931     -1.3209887742996216e+00
    phi[4,9]  R1932     -1.4565176963806152e+00
    phi[4,9]  R1933     8.6437717080116272e-02
    phi[4,9]  R1934     -5.3539866209030151e-01
    phi[4,9]  R1935     7.7562093734741211e-01
    phi[4,9]  R1936     4.0582489967346191e-01
    phi[4,9]  R1937     -2.3410730361938477e+00
    phi[4,9]  R1938     -2.2030205726623535e+00
    phi[4,9]  R1939     -2.9685206413269043e+00
    phi[4,9]  R1940     3.7826669216156006e-01
    phi[4,9]  R1941     1.9905675947666168e-01
    phi[4,9]  R1942     -8.3196485042572021e-01
    phi[4,9]  R1943     -9.1985964775085449e-01
    phi[4,9]  R1944     4.0227809548377991e-01
    phi[4,9]  R1945     1.3068015873432159e-01
    phi[4,9]  R1946     9.8426455259323120e-01
    phi[4,9]  R1947     1.3313318490982056e+00
    phi[4,9]  R1948     1.5982537269592285e+00
    phi[4,9]  R1949     -1.1697568893432617e+00
    phi[4,9]  R1950     6.3460016250610352e-01
    phi[4,9]  R1951     2.2506461143493652e+00
    phi[4,9]  R1952     8.7076562643051147e-01
    phi[4,9]  R1953     1.1134877204895020e+00
    phi[4,9]  R1954     3.1637576222419739e-01
    phi[4,9]  R1955     2.1788221597671509e-01
    phi[4,9]  R1956     1.1377960443496704e+00
    phi[4,9]  R1957     1.7765930891036987e+00
    phi[4,9]  R1958     5.9639662504196167e-01
    phi[4,9]  R1959     2.9996076226234436e-01
    phi[4,9]  R1960     -1.5023715496063232e+00
    phi[4,9]  R1961     -7.5516235828399658e-01
    phi[4,9]  R1962     -7.0189911127090454e-01
    phi[4,9]  R1963     -2.0310158729553223e+00
    phi[4,9]  R1964     -1.3993563652038574e+00
    phi[4,9]  R1965     -5.4260241985321045e-01
    phi[4,9]  R1966     -1.6482514142990112e+00
    phi[4,9]  R1967     -1.6467052698135376e+00
    phi[4,9]  R1968     -3.9583319425582886e-01
    phi[4,9]  R1969     -1.1706986427307129e+00
    phi[4,9]  R1970     -1.4146103858947754e+00
    phi[4,9]  R1971     -1.2352807521820068e+00
    phi[4,9]  R1972     1.0694512128829956e+00
    phi[4,9]  R1973     -1.8712776899337769e-01
    phi[4,9]  R1974     -1.3669791221618652e+00
    phi[4,9]  R1975     -1.1871256828308105e+00
    phi[4,9]  R1976     1.9679437577724457e-01
    phi[4,9]  R1977     -2.2593417167663574e+00
    phi[4,9]  R1978     4.6024173498153687e-01
    phi[4,9]  R1979     0.0946318507194519
    phi[9,4]  R36       -1
    phi[9,4]  R81       1
    phi[9,4]  R82       1
    phi[9,4]  R1980     -3.0999999046325684e+00
    phi[9,4]  R1981     -3.0999999046325684e+00
    phi[9,4]  R1982     -2.2400000095367432e+00
    phi[9,4]  R1983     -2.2400000095367432e+00
    phi[9,4]  R1984     -3.0999999046325684e+00
    phi[9,4]  R1985     -3.0999999046325684e+00
    phi[9,4]  R1986     -2.5699999332427979e+00
    phi[9,4]  R1987     -2.5699999332427979e+00
    phi[9,4]  R1988     -3.0999999046325684e+00
    phi[9,4]  R1989     -3.0999999046325684e+00
    phi[9,4]  R1990     -2.0899999141693115e+00
    phi[9,4]  R1991     -2.0899999141693115e+00
    phi[9,4]  R1992     -3.0999999046325684e+00
    phi[9,4]  R1993     -3.0999999046325684e+00
    phi[9,4]  R1994     6.3460016250610352e-01
    phi[9,4]  R1995     2.2506461143493652e+00
    phi[9,4]  R1996     8.7076562643051147e-01
    phi[9,4]  R1997     1.1134877204895020e+00
    phi[9,4]  R1998     3.1637576222419739e-01
    phi[9,4]  R1999     2.1788221597671509e-01
    phi[9,4]  R2000     1.1377960443496704e+00
    phi[9,4]  R2001     1.7765930891036987e+00
    phi[9,4]  R2002     5.9639662504196167e-01
    phi[9,4]  R2003     2.9996076226234436e-01
    phi[9,4]  R2004     -1.5023715496063232e+00
    phi[9,4]  R2005     -7.5516235828399658e-01
    phi[9,4]  R2006     -7.0189911127090454e-01
    phi[9,4]  R2007     -2.0310158729553223e+00
    phi[9,4]  R2008     -1.3993563652038574e+00
    phi[9,4]  R2009     -5.4260241985321045e-01
    phi[9,4]  R2010     -1.6482514142990112e+00
    phi[9,4]  R2011     -1.6467052698135376e+00
    phi[9,4]  R2012     -3.9583319425582886e-01
    phi[9,4]  R2013     -1.1706986427307129e+00
    phi[9,4]  R2014     -1.4146103858947754e+00
    phi[9,4]  R2015     -1.2352807521820068e+00
    phi[9,4]  R2016     1.0694512128829956e+00
    phi[9,4]  R2017     -1.8712776899337769e-01
    phi[9,4]  R2018     -1.3669791221618652e+00
    phi[9,4]  R2019     -1.1871256828308105e+00
    phi[9,4]  R2020     1.9679437577724457e-01
    phi[9,4]  R2021     -2.2593417167663574e+00
    phi[9,4]  R2022     4.6024173498153687e-01
    phi[9,4]  R2023     0.0946318507194519
    phi[9,4]  R2024     6.2170600891113281e-01
    phi[9,4]  R2025     2.1279633045196533e+00
    phi[9,4]  R2026     2.0004837512969971e+00
    phi[9,4]  R2027     0.452804297208786
    phi[9,4]  R2028     1.5582925081253052e+00
    phi[9,4]  R2029     4.5388571918010712e-02
    phi[9,4]  R2030     2.5294992923736572e+00
    phi[9,4]  R2031     1.0002244710922241e+00
    phi[9,4]  R2032     2.4925587177276611e+00
    phi[9,4]  R2033     5.4746210575103760e-01
    phi[9,4]  R2034     2.4810819327831268e-01
    phi[9,4]  R2035     3.4580603241920471e-01
    phi[9,4]  R2036     5.6614893674850464e-01
    phi[9,4]  R2037     -2.3045943677425385e-01
    phi[9,4]  R2038     4.2967402935028076e-01
    phi[9,4]  R2039     9.3075297772884369e-02
    phi[9,4]  R2040     -7.8751826286315918e-01
    phi[9,4]  R2041     -3.4206229448318481e-01
    phi[9,4]  R2042     5.5558836460113525e-01
    phi[9,4]  R2043     -1.1211527585983276e+00
    phi[9,4]  R2044     9.8492264747619629e-02
    phi[9,4]  R2045     -1.3209887742996216e+00
    phi[9,4]  R2046     -1.4565176963806152e+00
    phi[9,4]  R2047     8.6437717080116272e-02
    phi[9,4]  R2048     -5.3539866209030151e-01
    phi[9,4]  R2049     7.7562093734741211e-01
    phi[9,4]  R2050     4.0582489967346191e-01
    phi[9,4]  R2051     -2.3410730361938477e+00
    phi[9,4]  R2052     -2.2030205726623535e+00
    phi[9,4]  R2053     -2.9685206413269043e+00
    phi[9,4]  R2054     3.7826669216156006e-01
    phi[9,4]  R2055     1.9905675947666168e-01
    phi[9,4]  R2056     -8.3196485042572021e-01
    phi[9,4]  R2057     -9.1985964775085449e-01
    phi[9,4]  R2058     4.0227809548377991e-01
    phi[9,4]  R2059     1.3068015873432159e-01
    phi[9,4]  R2060     9.8426455259323120e-01
    phi[9,4]  R2061     1.3313318490982056e+00
    phi[9,4]  R2062     1.5982537269592285e+00
    phi[9,4]  R2063     -1.1697568893432617e+00
    phi[4,11]  R36       1
    phi[4,11]  R37       1
    phi[4,11]  R38       2.8935070907851790e-01
    phi[4,11]  R39       1.8926485940464066e+00
    phi[4,11]  R40       -1.6427690033655087e+00
    phi[4,11]  R41       1.8707613542687318e+00
    phi[4,11]  R42       -7.0711386254929742e-01
    phi[4,11]  R43       1.3639273561480389e+00
    phi[4,11]  R44       -7.4278977211338582e-01
    phi[4,11]  R91       -1
    phi[4,11]  R2064     -2.8106491955540505e+00
    phi[4,11]  R2065     -3.3893506137110863e+00
    phi[4,11]  R2066     -3.4735141549033655e-01
    phi[4,11]  R2067     -4.1326486035831493e+00
    phi[4,11]  R2068     -4.7427689079980766e+00
    phi[4,11]  R2069     -1.4572309012670597e+00
    phi[4,11]  R2070     -0.699238578974066
    phi[4,11]  R2071     -4.4407612875115294e+00
    phi[4,11]  R2072     -3.8071137671818658e+00
    phi[4,11]  R2073     -2.3928860420832709e+00
    phi[4,11]  R2074     -7.2607255802127257e-01
    phi[4,11]  R2075     -3.4539272703173505e+00
    phi[4,11]  R2076     -3.8427896767459542e+00
    phi[4,11]  R2077     -2.3572101325191825e+00
    phi[4,11]  R2078     -5.5977454643009183e-02
    phi[4,11]  R2079     -6.6352741550498973e-02
    phi[4,11]  R2080     -6.9162242162868814e-02
    phi[4,11]  R2081     -6.9375611834894935e-02
    phi[4,11]  R2082     -7.4812229782706741e-02
    phi[4,11]  R2083     -8.1335888096669862e-02
    phi[4,11]  R2084     -8.2403013540525372e-02
    phi[4,11]  R2085     -8.2632536326724626e-02
    phi[4,11]  R2086     -8.6918408571279748e-02
    phi[4,11]  R2087     -8.8192796824676734e-02
    phi[4,11]  R2088     -8.8767943170322927e-01
    phi[4,11]  R2089     -3.8533092694322335e-01
    phi[4,11]  R2090     -0.929438464184581
    phi[4,11]  R2091     -1.3463087966431482e+00
    phi[4,11]  R2092     -1.6544306142669485e-01
    phi[4,11]  R2093     -5.9910211250378587e-01
    phi[4,11]  R2094     -1.8559962717074896e-01
    phi[4,11]  R2095     -4.2307053661906224e-01
    phi[4,11]  R2096     -2.4173609498351456e-01
    phi[4,11]  R2097     -4.9484764876050025e-01
    phi[4,11]  R2098     -7.5712662396477659e-01
    phi[4,11]  R2099     -1.7954533056654420e-01
    phi[4,11]  R2100     -6.6524151923293029e-01
    phi[4,11]  R2101     -1.5272111403493094e-01
    phi[4,11]  R2102     -1.6649962292301884e-01
    phi[4,11]  R2103     -1.6905826239825594e-01
    phi[4,11]  R2104     -1.9440420027343519e-01
    phi[4,11]  R2105     -1.9665932921789109e-01
    phi[4,11]  R2106     -2.1041263302524338e-01
    phi[4,11]  R2107     -2.1241590888518003e-01
    phi[4,11]  R2108     -4.3403634633276966e-01
    phi[4,11]  R2109     -5.6555571720631392e-01
    phi[4,11]  R2110     -4.8478303139586265e-01
    phi[4,11]  R2111     -1.3016756009190888e-01
    phi[4,11]  R2112     -1.3523087295607195e-01
    phi[4,11]  R2113     -1.1279387665444351e+00
    phi[4,11]  R2114     -3.6908607977485475e-01
    phi[4,11]  R2115     -1.7289053368036744e-01
    phi[4,11]  R2116     -1.7816674127234688e-01
    phi[4,11]  R2117     -2.7221122032264666e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2118     -3.0999999046325684e+00
    phi[5,6]  R2119     -3.0999999046325684e+00
    phi[5,6]  R2120     -2.2400000095367432e+00
    phi[5,6]  R2121     -2.2400000095367432e+00
    phi[5,6]  R2122     -3.0999999046325684e+00
    phi[5,6]  R2123     -3.0999999046325684e+00
    phi[5,6]  R2124     -2.5699999332427979e+00
    phi[5,6]  R2125     -2.5699999332427979e+00
    phi[5,6]  R2126     -3.0999999046325684e+00
    phi[5,6]  R2127     -3.0999999046325684e+00
    phi[5,6]  R2128     -2.0899999141693115e+00
    phi[5,6]  R2129     -2.0899999141693115e+00
    phi[5,6]  R2130     -3.0999999046325684e+00
    phi[5,6]  R2131     -3.0999999046325684e+00
    phi[5,6]  R2132     -1.0232889652252197e+00
    phi[5,6]  R2133     3.5786908864974976e-01
    phi[5,6]  R2134     0.792243480682373
    phi[5,6]  R2135     1.0327850580215454e+00
    phi[5,6]  R2136     -1.3495792150497437e+00
    phi[5,6]  R2137     -5.5226409435272217e-01
    phi[5,6]  R2138     -0.831960141658783
    phi[5,6]  R2139     4.8476386070251465e-01
    phi[5,6]  R2140     5.6117624044418335e-01
    phi[5,6]  R2141     5.4206192493438721e-01
    phi[5,6]  R2142     -2.6080548763275146e+00
    phi[5,6]  R2143     1.1814839839935303e+00
    phi[5,6]  R2144     -1.0769462585449219e+00
    phi[5,6]  R2145     6.0016489028930664e-01
    phi[5,6]  R2146     7.3969650268554688e-01
    phi[5,6]  R2147     -1.0204908847808838e+00
    phi[5,6]  R2148     6.9684582948684692e-01
    phi[5,6]  R2149     -5.5375146865844727e-01
    phi[5,6]  R2150     -0.172672301530838
    phi[5,6]  R2151     -1.8707424402236938e+00
    phi[5,6]  R2152     -2.4609239101409912e+00
    phi[5,6]  R2153     8.1715232133865356e-01
    phi[5,6]  R2154     -8.1758445501327515e-01
    phi[5,6]  R2155     -2.0440040528774261e-01
    phi[5,6]  R2156     -2.2904960811138153e-01
    phi[5,6]  R2157     -1.4300264120101929e+00
    phi[5,6]  R2158     -1.06353759765625
    phi[5,6]  R2159     1.7268086969852448e-01
    phi[5,6]  R2160     9.6812361478805542e-01
    phi[5,6]  R2161     -1.1972683668136597e+00
    phi[5,6]  R2162     -1.0630195140838623e+00
    phi[5,6]  R2163     -6.8205523490905762e-01
    phi[5,6]  R2164     6.2805622816085815e-01
    phi[5,6]  R2165     9.8153114318847656e-01
    phi[5,6]  R2166     -2.0366662740707397e-01
    phi[5,6]  R2167     4.2998507618904114e-01
    phi[5,6]  R2168     1.8881247043609619e+00
    phi[5,6]  R2169     1.3821417093276978e+00
    phi[5,6]  R2170     1.00933039188385
    phi[5,6]  R2171     1.2212057113647461e+00
    phi[5,6]  R2172     4.3360418081283569e-01
    phi[5,6]  R2173     -7.8252464532852173e-02
    phi[5,6]  R2174     3.6776131391525269e-01
    phi[5,6]  R2175     9.5782530307769775e-01
    phi[5,6]  R2176     -0.779298722743988
    phi[5,6]  R2177     -7.7718579769134521e-01
    phi[5,6]  R2178     1.8897460699081421e+00
    phi[5,6]  R2179     3.3889052271842957e-01
    phi[5,6]  R2180     7.4318385124206543e-01
    phi[5,6]  R2181     6.1616539955139160e-01
    phi[5,6]  R2182     -0.672346293926239
    phi[5,6]  R2183     -1.4117884635925293e+00
    phi[5,6]  R2184     -4.8596712946891785e-01
    phi[5,6]  R2185     -1.1458284854888916e+00
    phi[5,6]  R2186     -9.5656543970108032e-01
    phi[5,6]  R2187     -1.1626473665237427e+00
    phi[5,6]  R2188     -1.3600634336471558e+00
    phi[5,6]  R2189     -1.7584589719772339e+00
    phi[5,6]  R2190     -1.4160325527191162e+00
    phi[5,6]  R2191     -4.6216481924057007e-01
    phi[5,6]  R2192     -1.2403523921966553e+00
    phi[5,6]  R2193     -0.743035078048706
    phi[5,6]  R2194     -1.8403687477111816e+00
    phi[5,6]  R2195     -1.0509142875671387e+00
    phi[5,6]  R2196     -1.1336144208908081e+00
    phi[5,6]  R2197     -6.3730305433273315e-01
    phi[5,6]  R2198     -1.1022298336029053e+00
    phi[5,6]  R2199     -1.5698105096817017e+00
    phi[5,6]  R2200     -1.3329949378967285e+00
    phi[5,6]  R2201     1.5379105508327484e-01
    phi[5,6]  R2202     -1.5817296504974365e+00
    phi[5,6]  R2203     -1.3085422515869141e+00
    phi[5,6]  R2204     -3.1768792867660522e-01
    phi[5,6]  R2205     -3.8506698608398438e-01
    phi[5,6]  R2206     -3.4213355183601379e-01
    phi[5,6]  R2207     -1.5788037776947021e+00
    phi[5,6]  R2208     -9.1159260272979736e-01
    phi[5,6]  R2209     -9.8685455322265625e-01
    phi[5,6]  R2210     -6.9986379146575928e-01
    phi[5,6]  R2211     -1.3022774457931519e+00
    phi[5,6]  R2212     -4.5435953140258789e-01
    phi[5,6]  R2213     -8.2899320125579834e-01
    phi[5,6]  R2214     -6.2494152784347534e-01
    phi[5,6]  R2215     -1.3671209812164307e+00
    phi[5,6]  R2216     -1.1223881244659424e+00
    phi[5,6]  R2217     -0.910549521446228
    phi[5,6]  R2218     -2.4844982624053955e+00
    phi[5,6]  R2219     -2.74049711227417
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2220     -3.0999999046325684e+00
    phi[6,5]  R2221     -3.0999999046325684e+00
    phi[6,5]  R2222     -2.2400000095367432e+00
    phi[6,5]  R2223     -2.2400000095367432e+00
    phi[6,5]  R2224     -3.0999999046325684e+00
    phi[6,5]  R2225     -3.0999999046325684e+00
    phi[6,5]  R2226     -2.5699999332427979e+00
    phi[6,5]  R2227     -2.5699999332427979e+00
    phi[6,5]  R2228     -3.0999999046325684e+00
    phi[6,5]  R2229     -3.0999999046325684e+00
    phi[6,5]  R2230     -2.0899999141693115e+00
    phi[6,5]  R2231     -2.0899999141693115e+00
    phi[6,5]  R2232     -3.0999999046325684e+00
    phi[6,5]  R2233     -3.0999999046325684e+00
    phi[6,5]  R2234     1.00933039188385
    phi[6,5]  R2235     1.2212057113647461e+00
    phi[6,5]  R2236     4.3360418081283569e-01
    phi[6,5]  R2237     -7.8252464532852173e-02
    phi[6,5]  R2238     3.6776131391525269e-01
    phi[6,5]  R2239     9.5782530307769775e-01
    phi[6,5]  R2240     -0.779298722743988
    phi[6,5]  R2241     -7.7718579769134521e-01
    phi[6,5]  R2242     1.8897460699081421e+00
    phi[6,5]  R2243     3.3889052271842957e-01
    phi[6,5]  R2244     7.4318385124206543e-01
    phi[6,5]  R2245     6.1616539955139160e-01
    phi[6,5]  R2246     -0.672346293926239
    phi[6,5]  R2247     -1.4117884635925293e+00
    phi[6,5]  R2248     -4.8596712946891785e-01
    phi[6,5]  R2249     -1.1458284854888916e+00
    phi[6,5]  R2250     -9.5656543970108032e-01
    phi[6,5]  R2251     -1.1626473665237427e+00
    phi[6,5]  R2252     -1.3600634336471558e+00
    phi[6,5]  R2253     -1.7584589719772339e+00
    phi[6,5]  R2254     -1.4160325527191162e+00
    phi[6,5]  R2255     -4.6216481924057007e-01
    phi[6,5]  R2256     -1.2403523921966553e+00
    phi[6,5]  R2257     -0.743035078048706
    phi[6,5]  R2258     -1.8403687477111816e+00
    phi[6,5]  R2259     -1.0509142875671387e+00
    phi[6,5]  R2260     -1.1336144208908081e+00
    phi[6,5]  R2261     -6.3730305433273315e-01
    phi[6,5]  R2262     -1.1022298336029053e+00
    phi[6,5]  R2263     -1.5698105096817017e+00
    phi[6,5]  R2264     -1.3329949378967285e+00
    phi[6,5]  R2265     1.5379105508327484e-01
    phi[6,5]  R2266     -1.5817296504974365e+00
    phi[6,5]  R2267     -1.3085422515869141e+00
    phi[6,5]  R2268     -3.1768792867660522e-01
    phi[6,5]  R2269     -3.8506698608398438e-01
    phi[6,5]  R2270     -3.4213355183601379e-01
    phi[6,5]  R2271     -1.5788037776947021e+00
    phi[6,5]  R2272     -9.1159260272979736e-01
    phi[6,5]  R2273     -9.8685455322265625e-01
    phi[6,5]  R2274     -6.9986379146575928e-01
    phi[6,5]  R2275     -1.3022774457931519e+00
    phi[6,5]  R2276     -4.5435953140258789e-01
    phi[6,5]  R2277     -8.2899320125579834e-01
    phi[6,5]  R2278     -6.2494152784347534e-01
    phi[6,5]  R2279     -1.3671209812164307e+00
    phi[6,5]  R2280     -1.1223881244659424e+00
    phi[6,5]  R2281     -0.910549521446228
    phi[6,5]  R2282     -2.4844982624053955e+00
    phi[6,5]  R2283     -2.74049711227417
    phi[6,5]  R2284     -1.0232889652252197e+00
    phi[6,5]  R2285     3.5786908864974976e-01
    phi[6,5]  R2286     0.792243480682373
    phi[6,5]  R2287     1.0327850580215454e+00
    phi[6,5]  R2288     -1.3495792150497437e+00
    phi[6,5]  R2289     -5.5226409435272217e-01
    phi[6,5]  R2290     -0.831960141658783
    phi[6,5]  R2291     4.8476386070251465e-01
    phi[6,5]  R2292     5.6117624044418335e-01
    phi[6,5]  R2293     5.4206192493438721e-01
    phi[6,5]  R2294     -2.6080548763275146e+00
    phi[6,5]  R2295     1.1814839839935303e+00
    phi[6,5]  R2296     -1.0769462585449219e+00
    phi[6,5]  R2297     6.0016489028930664e-01
    phi[6,5]  R2298     7.3969650268554688e-01
    phi[6,5]  R2299     -1.0204908847808838e+00
    phi[6,5]  R2300     6.9684582948684692e-01
    phi[6,5]  R2301     -5.5375146865844727e-01
    phi[6,5]  R2302     -0.172672301530838
    phi[6,5]  R2303     -1.8707424402236938e+00
    phi[6,5]  R2304     -2.4609239101409912e+00
    phi[6,5]  R2305     8.1715232133865356e-01
    phi[6,5]  R2306     -8.1758445501327515e-01
    phi[6,5]  R2307     -2.0440040528774261e-01
    phi[6,5]  R2308     -2.2904960811138153e-01
    phi[6,5]  R2309     -1.4300264120101929e+00
    phi[6,5]  R2310     -1.06353759765625
    phi[6,5]  R2311     1.7268086969852448e-01
    phi[6,5]  R2312     9.6812361478805542e-01
    phi[6,5]  R2313     -1.1972683668136597e+00
    phi[6,5]  R2314     -1.0630195140838623e+00
    phi[6,5]  R2315     -6.8205523490905762e-01
    phi[6,5]  R2316     6.2805622816085815e-01
    phi[6,5]  R2317     9.8153114318847656e-01
    phi[6,5]  R2318     -2.0366662740707397e-01
    phi[6,5]  R2319     4.2998507618904114e-01
    phi[6,5]  R2320     1.8881247043609619e+00
    phi[6,5]  R2321     1.3821417093276978e+00
    phi[10,5]  R45       -1
    phi[10,5]  R47       6.3284146634571048e-02
    phi[10,5]  R48       1.9934665805848018e+00
    phi[10,5]  R49       1.3499055787106520e+00
    phi[10,5]  R50       -7.8583313905015029e-01
    phi[10,5]  R51       2.4149177566934390e+00
    phi[10,5]  R52       8.6010458152915747e-01
    phi[10,5]  R53       1.3490414543132103e+00
    phi[10,5]  R90       1
    phi[10,5]  R2322     -3.1632840512671394e+00
    phi[10,5]  R2323     -3.0367157579979973e+00
    phi[10,5]  R2324     -4.2334665901215445e+00
    phi[10,5]  R2325     -2.4653342895194141e-01
    phi[10,5]  R2326     -4.4499054833432208e+00
    phi[10,5]  R2327     -1.7500943259219164e+00
    phi[10,5]  R2328     -1.7841667941926476e+00
    phi[10,5]  R2329     -3.3558330722929481e+00
    phi[10,5]  R2330     -5.5149176613260078e+00
    phi[10,5]  R2331     -6.8508214793912936e-01
    phi[10,5]  R2332     -2.9501044956984690e+00
    phi[10,5]  R2333     -1.2298953326401540e+00
    phi[10,5]  R2334     -4.4490413589457791e+00
    phi[10,5]  R2335     -1.7509584503193580e+00
    phi[10,5]  R2336     -4.3637727355066991e-02
    phi[10,5]  R2337     -0.0609259150274567
    phi[10,5]  R2338     -6.1497990552638826e-02
    phi[10,5]  R2339     -6.3812901729580762e-02
    phi[10,5]  R2340     -7.7651337237781393e-02
    phi[10,5]  R2341     -0.0795294670214029
    phi[10,5]  R2342     -0.0877068585752383
    phi[10,5]  R2343     -1.1136617016812644e-01
    phi[10,5]  R2344     -1.3209995774237460e-01
    phi[10,5]  R2345     -2.1607854482427902e-01
    phi[10,5]  R2346     -6.6659858089807678e-02
    phi[10,5]  R2347     -1.5427794285535024e-01
    phi[10,5]  R2348     -2.8380744587747009e-01
    phi[10,5]  R2349     -1.0476770044709296e+00
    phi[10,5]  R2350     -1.8690911370697862e+00
    phi[10,5]  R2351     -3.9607530084481346e-01
    phi[10,5]  R2352     -4.2648477566789822e-01
    phi[10,5]  R2353     -4.2669377443511392e-01
    phi[10,5]  R2354     -1.8326592871252760e+00
    phi[10,5]  R2355     -4.3898204903833582e-01
    phi[10,5]  R2356     -0.00617327570229298
    phi[10,5]  R2357     -1.3188864042433968e-01
    phi[10,5]  R2358     -1.3748227619440967e-01
    phi[10,5]  R2359     -1.3886023907411332e-01
    phi[10,5]  R2360     -1.4169109692153209e-01
    phi[10,5]  R2361     -1.6233080361587837e-01
    phi[10,5]  R2362     -1.6292480760621886e-01
    phi[10,5]  R2363     -3.1399612603516469e-01
    phi[10,5]  R2364     -3.2589682232524742e-01
    phi[10,5]  R2365     -3.4197766951814357e-01
    phi[10,5]  R2366     -1.0178991647793667e-01
    phi[10,5]  R2367     -1.4784189906313538e-01
    phi[10,5]  R2368     -2.4509205668921552e-01
    phi[10,5]  R2369     -2.6225141426308607e-01
    phi[10,5]  R2370     -3.9422187438479706e-01
    phi[10,5]  R2371     -4.2742902634143554e-01
    phi[10,5]  R2372     -4.5961498192782724e-01
    phi[10,5]  R2373     -4.6433829355205103e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2374     -3.0999999046325684e+00
    phi[6,7]  R2375     -3.0999999046325684e+00
    phi[6,7]  R2376     -2.2400000095367432e+00
    phi[6,7]  R2377     -2.2400000095367432e+00
    phi[6,7]  R2378     -3.0999999046325684e+00
    phi[6,7]  R2379     -3.0999999046325684e+00
    phi[6,7]  R2380     -2.5699999332427979e+00
    phi[6,7]  R2381     -2.5699999332427979e+00
    phi[6,7]  R2382     -3.0999999046325684e+00
    phi[6,7]  R2383     -3.0999999046325684e+00
    phi[6,7]  R2384     -2.0899999141693115e+00
    phi[6,7]  R2385     -2.0899999141693115e+00
    phi[6,7]  R2386     -3.0999999046325684e+00
    phi[6,7]  R2387     -3.0999999046325684e+00
    phi[6,7]  R2388     1.00933039188385
    phi[6,7]  R2389     1.2212057113647461e+00
    phi[6,7]  R2390     4.3360418081283569e-01
    phi[6,7]  R2391     -7.8252464532852173e-02
    phi[6,7]  R2392     3.6776131391525269e-01
    phi[6,7]  R2393     9.5782530307769775e-01
    phi[6,7]  R2394     -0.779298722743988
    phi[6,7]  R2395     -7.7718579769134521e-01
    phi[6,7]  R2396     1.8897460699081421e+00
    phi[6,7]  R2397     3.3889052271842957e-01
    phi[6,7]  R2398     7.4318385124206543e-01
    phi[6,7]  R2399     6.1616539955139160e-01
    phi[6,7]  R2400     -0.672346293926239
    phi[6,7]  R2401     -1.4117884635925293e+00
    phi[6,7]  R2402     -4.8596712946891785e-01
    phi[6,7]  R2403     -1.1458284854888916e+00
    phi[6,7]  R2404     -9.5656543970108032e-01
    phi[6,7]  R2405     -1.1626473665237427e+00
    phi[6,7]  R2406     -1.3600634336471558e+00
    phi[6,7]  R2407     -1.7584589719772339e+00
    phi[6,7]  R2408     -1.4160325527191162e+00
    phi[6,7]  R2409     -4.6216481924057007e-01
    phi[6,7]  R2410     -1.2403523921966553e+00
    phi[6,7]  R2411     -0.743035078048706
    phi[6,7]  R2412     -1.8403687477111816e+00
    phi[6,7]  R2413     -1.0509142875671387e+00
    phi[6,7]  R2414     -1.1336144208908081e+00
    phi[6,7]  R2415     -6.3730305433273315e-01
    phi[6,7]  R2416     -1.1022298336029053e+00
    phi[6,7]  R2417     -1.5698105096817017e+00
    phi[6,7]  R2418     -1.3329949378967285e+00
    phi[6,7]  R2419     1.5379105508327484e-01
    phi[6,7]  R2420     -1.5817296504974365e+00
    phi[6,7]  R2421     -1.3085422515869141e+00
    phi[6,7]  R2422     -3.1768792867660522e-01
    phi[6,7]  R2423     -3.8506698608398438e-01
    phi[6,7]  R2424     -3.4213355183601379e-01
    phi[6,7]  R2425     -1.5788037776947021e+00
    phi[6,7]  R2426     -9.1159260272979736e-01
    phi[6,7]  R2427     -9.8685455322265625e-01
    phi[6,7]  R2428     -6.9986379146575928e-01
    phi[6,7]  R2429     -1.3022774457931519e+00
    phi[6,7]  R2430     -4.5435953140258789e-01
    phi[6,7]  R2431     -8.2899320125579834e-01
    phi[6,7]  R2432     -6.2494152784347534e-01
    phi[6,7]  R2433     -1.3671209812164307e+00
    phi[6,7]  R2434     -1.1223881244659424e+00
    phi[6,7]  R2435     -0.910549521446228
    phi[6,7]  R2436     -2.4844982624053955e+00
    phi[6,7]  R2437     -2.74049711227417
    phi[6,7]  R2438     9.5412752979639281e-01
    phi[6,7]  R2439     2.4081332683563232e+00
    phi[6,7]  R2440     -3.5349223017692566e-01
    phi[6,7]  R2441     -1.9212741851806641e+00
    phi[6,7]  R2442     -1.4245984554290771e+00
    phi[6,7]  R2443     -2.2612946033477783e+00
    phi[6,7]  R2444     -1.9504820108413696e+00
    phi[6,7]  R2445     -8.9333599805831909e-01
    phi[6,7]  R2446     -1.3268784284591675e+00
    phi[6,7]  R2447     -1.2889471054077148e+00
    phi[6,7]  R2448     -1.0366011330495168e+00
    phi[6,7]  R2449     -4.4552493095397949e-01
    phi[6,7]  R2450     -1.4129799604415894e+00
    phi[6,7]  R2451     -2.2874794006347656e+00
    phi[6,7]  R2452     -8.4408307075500488e-01
    phi[6,7]  R2453     -2.9539763927459717e-01
    phi[6,7]  R2454     -1.7826943099498749e-01
    phi[6,7]  R2455     1.3247278332710266e-01
    phi[6,7]  R2456     -7.8031766414642334e-01
    phi[6,7]  R2457     -4.6328330039978027e-01
    phi[6,7]  R2458     -1.1711057424545288e+00
    phi[6,7]  R2459     -1.4824794530868530e+00
    phi[6,7]  R2460     -6.1598169803619385e-01
    phi[6,7]  R2461     -8.9386105537414551e-01
    phi[6,7]  R2462     -5.0988280773162842e-01
    phi[6,7]  R2463     -2.6377265453338623e+00
    phi[6,7]  R2464     -1.8891127109527588e+00
    phi[6,7]  R2465     -1.3784049749374390e+00
    phi[6,7]  R2466     -1.7040363550186157e+00
    phi[6,7]  R2467     -1.7522053718566895e+00
    phi[6,7]  R2468     5.5654533207416534e-02
    phi[6,7]  R2469     -6.2666523456573486e-01
    phi[6,7]  R2470     -8.1862914562225342e-01
    phi[6,7]  R2471     -1.4181469380855560e-01
    phi[6,7]  R2472     -6.3180714845657349e-01
    phi[6,7]  R2473     -6.0405212640762329e-01
    phi[6,7]  R2474     -8.2486748695373535e-01
    phi[6,7]  R2475     -6.4504301548004150e-01
    phi[6,7]  R2476     -4.2968925833702087e-01
    phi[6,7]  R2477     -2.6872589588165283e+00
    phi[6,7]  R2478     -5.7698529958724976e-01
    phi[6,7]  R2479     -4.0441185235977173e-01
    phi[6,7]  R2480     -1.0153143107891083e-01
    phi[6,7]  R2481     -1.0225666761398315e+00
    phi[6,7]  R2482     -8.8235962390899658e-01
    phi[6,7]  R2483     -9.3144762516021729e-01
    phi[6,7]  R2484     -1.4224373102188110e+00
    phi[6,7]  R2485     -7.3237401247024536e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2486     -3.0999999046325684e+00
    phi[7,6]  R2487     -3.0999999046325684e+00
    phi[7,6]  R2488     -2.2400000095367432e+00
    phi[7,6]  R2489     -2.2400000095367432e+00
    phi[7,6]  R2490     -3.0999999046325684e+00
    phi[7,6]  R2491     -3.0999999046325684e+00
    phi[7,6]  R2492     -2.5699999332427979e+00
    phi[7,6]  R2493     -2.5699999332427979e+00
    phi[7,6]  R2494     -3.0999999046325684e+00
    phi[7,6]  R2495     -3.0999999046325684e+00
    phi[7,6]  R2496     -2.0899999141693115e+00
    phi[7,6]  R2497     -2.0899999141693115e+00
    phi[7,6]  R2498     -3.0999999046325684e+00
    phi[7,6]  R2499     -3.0999999046325684e+00
    phi[7,6]  R2500     9.5412752979639281e-01
    phi[7,6]  R2501     2.4081332683563232e+00
    phi[7,6]  R2502     -3.5349223017692566e-01
    phi[7,6]  R2503     -1.9212741851806641e+00
    phi[7,6]  R2504     -1.4245984554290771e+00
    phi[7,6]  R2505     -2.2612946033477783e+00
    phi[7,6]  R2506     -1.9504820108413696e+00
    phi[7,6]  R2507     -8.9333599805831909e-01
    phi[7,6]  R2508     -1.3268784284591675e+00
    phi[7,6]  R2509     -1.2889471054077148e+00
    phi[7,6]  R2510     -1.0366011330495168e+00
    phi[7,6]  R2511     -4.4552493095397949e-01
    phi[7,6]  R2512     -1.4129799604415894e+00
    phi[7,6]  R2513     -2.2874794006347656e+00
    phi[7,6]  R2514     -8.4408307075500488e-01
    phi[7,6]  R2515     -2.9539763927459717e-01
    phi[7,6]  R2516     -1.7826943099498749e-01
    phi[7,6]  R2517     1.3247278332710266e-01
    phi[7,6]  R2518     -7.8031766414642334e-01
    phi[7,6]  R2519     -4.6328330039978027e-01
    phi[7,6]  R2520     -1.1711057424545288e+00
    phi[7,6]  R2521     -1.4824794530868530e+00
    phi[7,6]  R2522     -6.1598169803619385e-01
    phi[7,6]  R2523     -8.9386105537414551e-01
    phi[7,6]  R2524     -5.0988280773162842e-01
    phi[7,6]  R2525     -2.6377265453338623e+00
    phi[7,6]  R2526     -1.8891127109527588e+00
    phi[7,6]  R2527     -1.3784049749374390e+00
    phi[7,6]  R2528     -1.7040363550186157e+00
    phi[7,6]  R2529     -1.7522053718566895e+00
    phi[7,6]  R2530     5.5654533207416534e-02
    phi[7,6]  R2531     -6.2666523456573486e-01
    phi[7,6]  R2532     -8.1862914562225342e-01
    phi[7,6]  R2533     -1.4181469380855560e-01
    phi[7,6]  R2534     -6.3180714845657349e-01
    phi[7,6]  R2535     -6.0405212640762329e-01
    phi[7,6]  R2536     -8.2486748695373535e-01
    phi[7,6]  R2537     -6.4504301548004150e-01
    phi[7,6]  R2538     -4.2968925833702087e-01
    phi[7,6]  R2539     -2.6872589588165283e+00
    phi[7,6]  R2540     -5.7698529958724976e-01
    phi[7,6]  R2541     -4.0441185235977173e-01
    phi[7,6]  R2542     -1.0153143107891083e-01
    phi[7,6]  R2543     -1.0225666761398315e+00
    phi[7,6]  R2544     -8.8235962390899658e-01
    phi[7,6]  R2545     -9.3144762516021729e-01
    phi[7,6]  R2546     -1.4224373102188110e+00
    phi[7,6]  R2547     -7.3237401247024536e-01
    phi[7,6]  R2548     1.00933039188385
    phi[7,6]  R2549     1.2212057113647461e+00
    phi[7,6]  R2550     4.3360418081283569e-01
    phi[7,6]  R2551     -7.8252464532852173e-02
    phi[7,6]  R2552     3.6776131391525269e-01
    phi[7,6]  R2553     9.5782530307769775e-01
    phi[7,6]  R2554     -0.779298722743988
    phi[7,6]  R2555     -7.7718579769134521e-01
    phi[7,6]  R2556     1.8897460699081421e+00
    phi[7,6]  R2557     3.3889052271842957e-01
    phi[7,6]  R2558     7.4318385124206543e-01
    phi[7,6]  R2559     6.1616539955139160e-01
    phi[7,6]  R2560     -0.672346293926239
    phi[7,6]  R2561     -1.4117884635925293e+00
    phi[7,6]  R2562     -4.8596712946891785e-01
    phi[7,6]  R2563     -1.1458284854888916e+00
    phi[7,6]  R2564     -9.5656543970108032e-01
    phi[7,6]  R2565     -1.1626473665237427e+00
    phi[7,6]  R2566     -1.3600634336471558e+00
    phi[7,6]  R2567     -1.7584589719772339e+00
    phi[7,6]  R2568     -1.4160325527191162e+00
    phi[7,6]  R2569     -4.6216481924057007e-01
    phi[7,6]  R2570     -1.2403523921966553e+00
    phi[7,6]  R2571     -0.743035078048706
    phi[7,6]  R2572     -1.8403687477111816e+00
    phi[7,6]  R2573     -1.0509142875671387e+00
    phi[7,6]  R2574     -1.1336144208908081e+00
    phi[7,6]  R2575     -6.3730305433273315e-01
    phi[7,6]  R2576     -1.1022298336029053e+00
    phi[7,6]  R2577     -1.5698105096817017e+00
    phi[7,6]  R2578     -1.3329949378967285e+00
    phi[7,6]  R2579     1.5379105508327484e-01
    phi[7,6]  R2580     -1.5817296504974365e+00
    phi[7,6]  R2581     -1.3085422515869141e+00
    phi[7,6]  R2582     -3.1768792867660522e-01
    phi[7,6]  R2583     -3.8506698608398438e-01
    phi[7,6]  R2584     -3.4213355183601379e-01
    phi[7,6]  R2585     -1.5788037776947021e+00
    phi[7,6]  R2586     -9.1159260272979736e-01
    phi[7,6]  R2587     -9.8685455322265625e-01
    phi[7,6]  R2588     -6.9986379146575928e-01
    phi[7,6]  R2589     -1.3022774457931519e+00
    phi[7,6]  R2590     -4.5435953140258789e-01
    phi[7,6]  R2591     -8.2899320125579834e-01
    phi[7,6]  R2592     -6.2494152784347534e-01
    phi[7,6]  R2593     -1.3671209812164307e+00
    phi[7,6]  R2594     -1.1223881244659424e+00
    phi[7,6]  R2595     -0.910549521446228
    phi[7,6]  R2596     -2.4844982624053955e+00
    phi[7,6]  R2597     -2.74049711227417
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2598     -3.0999999046325684e+00
    phi[7,8]  R2599     -3.0999999046325684e+00
    phi[7,8]  R2600     -2.2400000095367432e+00
    phi[7,8]  R2601     -2.2400000095367432e+00
    phi[7,8]  R2602     -3.0999999046325684e+00
    phi[7,8]  R2603     -3.0999999046325684e+00
    phi[7,8]  R2604     -2.5699999332427979e+00
    phi[7,8]  R2605     -2.5699999332427979e+00
    phi[7,8]  R2606     -3.0999999046325684e+00
    phi[7,8]  R2607     -3.0999999046325684e+00
    phi[7,8]  R2608     -2.0899999141693115e+00
    phi[7,8]  R2609     -2.0899999141693115e+00
    phi[7,8]  R2610     -3.0999999046325684e+00
    phi[7,8]  R2611     -3.0999999046325684e+00
    phi[7,8]  R2612     9.5412752979639281e-01
    phi[7,8]  R2613     2.4081332683563232e+00
    phi[7,8]  R2614     -3.5349223017692566e-01
    phi[7,8]  R2615     -1.9212741851806641e+00
    phi[7,8]  R2616     -1.4245984554290771e+00
    phi[7,8]  R2617     -2.2612946033477783e+00
    phi[7,8]  R2618     -1.9504820108413696e+00
    phi[7,8]  R2619     -8.9333599805831909e-01
    phi[7,8]  R2620     -1.3268784284591675e+00
    phi[7,8]  R2621     -1.2889471054077148e+00
    phi[7,8]  R2622     -1.0366011330495168e+00
    phi[7,8]  R2623     -4.4552493095397949e-01
    phi[7,8]  R2624     -1.4129799604415894e+00
    phi[7,8]  R2625     -2.2874794006347656e+00
    phi[7,8]  R2626     -8.4408307075500488e-01
    phi[7,8]  R2627     -2.9539763927459717e-01
    phi[7,8]  R2628     -1.7826943099498749e-01
    phi[7,8]  R2629     1.3247278332710266e-01
    phi[7,8]  R2630     -7.8031766414642334e-01
    phi[7,8]  R2631     -4.6328330039978027e-01
    phi[7,8]  R2632     -1.1711057424545288e+00
    phi[7,8]  R2633     -1.4824794530868530e+00
    phi[7,8]  R2634     -6.1598169803619385e-01
    phi[7,8]  R2635     -8.9386105537414551e-01
    phi[7,8]  R2636     -5.0988280773162842e-01
    phi[7,8]  R2637     -2.6377265453338623e+00
    phi[7,8]  R2638     -1.8891127109527588e+00
    phi[7,8]  R2639     -1.3784049749374390e+00
    phi[7,8]  R2640     -1.7040363550186157e+00
    phi[7,8]  R2641     -1.7522053718566895e+00
    phi[7,8]  R2642     5.5654533207416534e-02
    phi[7,8]  R2643     -6.2666523456573486e-01
    phi[7,8]  R2644     -8.1862914562225342e-01
    phi[7,8]  R2645     -1.4181469380855560e-01
    phi[7,8]  R2646     -6.3180714845657349e-01
    phi[7,8]  R2647     -6.0405212640762329e-01
    phi[7,8]  R2648     -8.2486748695373535e-01
    phi[7,8]  R2649     -6.4504301548004150e-01
    phi[7,8]  R2650     -4.2968925833702087e-01
    phi[7,8]  R2651     -2.6872589588165283e+00
    phi[7,8]  R2652     -5.7698529958724976e-01
    phi[7,8]  R2653     -4.0441185235977173e-01
    phi[7,8]  R2654     -1.0153143107891083e-01
    phi[7,8]  R2655     -1.0225666761398315e+00
    phi[7,8]  R2656     -8.8235962390899658e-01
    phi[7,8]  R2657     -9.3144762516021729e-01
    phi[7,8]  R2658     -1.4224373102188110e+00
    phi[7,8]  R2659     -7.3237401247024536e-01
    phi[7,8]  R2660     1.5900038480758667e+00
    phi[7,8]  R2661     1.3526426553726196e+00
    phi[7,8]  R2662     2.1643614768981934e+00
    phi[7,8]  R2663     3.1673642992973328e-01
    phi[7,8]  R2664     8.0866515636444092e-01
    phi[7,8]  R2665     3.5792659968137741e-02
    phi[7,8]  R2666     -7.1106158196926117e-02
    phi[7,8]  R2667     2.4370159953832626e-02
    phi[7,8]  R2668     -1.2409540265798569e-01
    phi[7,8]  R2669     4.5133709907531738e-01
    phi[7,8]  R2670     -3.1005780696868896e+00
    phi[7,8]  R2671     -1.9249148368835449e+00
    phi[7,8]  R2672     -1.3096462488174438e+00
    phi[7,8]  R2673     -3.1428072452545166e+00
    phi[7,8]  R2674     -8.0413514375686646e-01
    phi[7,8]  R2675     -1.4209822416305542e+00
    phi[7,8]  R2676     3.9826259016990662e-01
    phi[7,8]  R2677     -1.1001037359237671e+00
    phi[7,8]  R2678     -2.1943154335021973e+00
    phi[7,8]  R2679     6.7347484827041626e-01
    phi[7,8]  R2680     -1.8761850595474243e+00
    phi[7,8]  R2681     -1.5248543024063110e+00
    phi[7,8]  R2682     -2.7397339344024658e+00
    phi[7,8]  R2683     -3.1009871959686279e+00
    phi[7,8]  R2684     -2.2245254516601562e+00
    phi[7,8]  R2685     -1.8342665433883667e+00
    phi[7,8]  R2686     -1.8793213367462158e+00
    phi[7,8]  R2687     -1.4688704013824463e+00
    phi[7,8]  R2688     -3.6108803749084473e-01
    phi[7,8]  R2689     -1.7022855281829834e+00
    phi[7,8]  R2690     -1.1324381828308105e+00
    phi[7,8]  R2691     -4.3896457552909851e-01
    phi[7,8]  R2692     -8.1192421913146973e-01
    phi[7,8]  R2693     -1.0869233608245850e+00
    phi[7,8]  R2694     -8.6438196897506714e-01
    phi[7,8]  R2695     -4.5088860392570496e-01
    phi[7,8]  R2696     -3.8277313113212585e-01
    phi[7,8]  R2697     -3.8946744799613953e-01
    phi[7,8]  R2698     2.0883843302726746e-01
    phi[7,8]  R2699     -8.9241534471511841e-01
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2700     -3.0999999046325684e+00
    phi[8,7]  R2701     -3.0999999046325684e+00
    phi[8,7]  R2702     -2.2400000095367432e+00
    phi[8,7]  R2703     -2.2400000095367432e+00
    phi[8,7]  R2704     -3.0999999046325684e+00
    phi[8,7]  R2705     -3.0999999046325684e+00
    phi[8,7]  R2706     -2.5699999332427979e+00
    phi[8,7]  R2707     -2.5699999332427979e+00
    phi[8,7]  R2708     -3.0999999046325684e+00
    phi[8,7]  R2709     -3.0999999046325684e+00
    phi[8,7]  R2710     -2.0899999141693115e+00
    phi[8,7]  R2711     -2.0899999141693115e+00
    phi[8,7]  R2712     -3.0999999046325684e+00
    phi[8,7]  R2713     -3.0999999046325684e+00
    phi[8,7]  R2714     1.5900038480758667e+00
    phi[8,7]  R2715     1.3526426553726196e+00
    phi[8,7]  R2716     2.1643614768981934e+00
    phi[8,7]  R2717     3.1673642992973328e-01
    phi[8,7]  R2718     8.0866515636444092e-01
    phi[8,7]  R2719     3.5792659968137741e-02
    phi[8,7]  R2720     -7.1106158196926117e-02
    phi[8,7]  R2721     2.4370159953832626e-02
    phi[8,7]  R2722     -1.2409540265798569e-01
    phi[8,7]  R2723     4.5133709907531738e-01
    phi[8,7]  R2724     -3.1005780696868896e+00
    phi[8,7]  R2725     -1.9249148368835449e+00
    phi[8,7]  R2726     -1.3096462488174438e+00
    phi[8,7]  R2727     -3.1428072452545166e+00
    phi[8,7]  R2728     -8.0413514375686646e-01
    phi[8,7]  R2729     -1.4209822416305542e+00
    phi[8,7]  R2730     3.9826259016990662e-01
    phi[8,7]  R2731     -1.1001037359237671e+00
    phi[8,7]  R2732     -2.1943154335021973e+00
    phi[8,7]  R2733     6.7347484827041626e-01
    phi[8,7]  R2734     -1.8761850595474243e+00
    phi[8,7]  R2735     -1.5248543024063110e+00
    phi[8,7]  R2736     -2.7397339344024658e+00
    phi[8,7]  R2737     -3.1009871959686279e+00
    phi[8,7]  R2738     -2.2245254516601562e+00
    phi[8,7]  R2739     -1.8342665433883667e+00
    phi[8,7]  R2740     -1.8793213367462158e+00
    phi[8,7]  R2741     -1.4688704013824463e+00
    phi[8,7]  R2742     -3.6108803749084473e-01
    phi[8,7]  R2743     -1.7022855281829834e+00
    phi[8,7]  R2744     -1.1324381828308105e+00
    phi[8,7]  R2745     -4.3896457552909851e-01
    phi[8,7]  R2746     -8.1192421913146973e-01
    phi[8,7]  R2747     -1.0869233608245850e+00
    phi[8,7]  R2748     -8.6438196897506714e-01
    phi[8,7]  R2749     -4.5088860392570496e-01
    phi[8,7]  R2750     -3.8277313113212585e-01
    phi[8,7]  R2751     -3.8946744799613953e-01
    phi[8,7]  R2752     2.0883843302726746e-01
    phi[8,7]  R2753     -8.9241534471511841e-01
    phi[8,7]  R2754     9.5412752979639281e-01
    phi[8,7]  R2755     2.4081332683563232e+00
    phi[8,7]  R2756     -3.5349223017692566e-01
    phi[8,7]  R2757     -1.9212741851806641e+00
    phi[8,7]  R2758     -1.4245984554290771e+00
    phi[8,7]  R2759     -2.2612946033477783e+00
    phi[8,7]  R2760     -1.9504820108413696e+00
    phi[8,7]  R2761     -8.9333599805831909e-01
    phi[8,7]  R2762     -1.3268784284591675e+00
    phi[8,7]  R2763     -1.2889471054077148e+00
    phi[8,7]  R2764     -1.0366011330495168e+00
    phi[8,7]  R2765     -4.4552493095397949e-01
    phi[8,7]  R2766     -1.4129799604415894e+00
    phi[8,7]  R2767     -2.2874794006347656e+00
    phi[8,7]  R2768     -8.4408307075500488e-01
    phi[8,7]  R2769     -2.9539763927459717e-01
    phi[8,7]  R2770     -1.7826943099498749e-01
    phi[8,7]  R2771     1.3247278332710266e-01
    phi[8,7]  R2772     -7.8031766414642334e-01
    phi[8,7]  R2773     -4.6328330039978027e-01
    phi[8,7]  R2774     -1.1711057424545288e+00
    phi[8,7]  R2775     -1.4824794530868530e+00
    phi[8,7]  R2776     -6.1598169803619385e-01
    phi[8,7]  R2777     -8.9386105537414551e-01
    phi[8,7]  R2778     -5.0988280773162842e-01
    phi[8,7]  R2779     -2.6377265453338623e+00
    phi[8,7]  R2780     -1.8891127109527588e+00
    phi[8,7]  R2781     -1.3784049749374390e+00
    phi[8,7]  R2782     -1.7040363550186157e+00
    phi[8,7]  R2783     -1.7522053718566895e+00
    phi[8,7]  R2784     5.5654533207416534e-02
    phi[8,7]  R2785     -6.2666523456573486e-01
    phi[8,7]  R2786     -8.1862914562225342e-01
    phi[8,7]  R2787     -1.4181469380855560e-01
    phi[8,7]  R2788     -6.3180714845657349e-01
    phi[8,7]  R2789     -6.0405212640762329e-01
    phi[8,7]  R2790     -8.2486748695373535e-01
    phi[8,7]  R2791     -6.4504301548004150e-01
    phi[8,7]  R2792     -4.2968925833702087e-01
    phi[8,7]  R2793     -2.6872589588165283e+00
    phi[8,7]  R2794     -5.7698529958724976e-01
    phi[8,7]  R2795     -4.0441185235977173e-01
    phi[8,7]  R2796     -1.0153143107891083e-01
    phi[8,7]  R2797     -1.0225666761398315e+00
    phi[8,7]  R2798     -8.8235962390899658e-01
    phi[8,7]  R2799     -9.3144762516021729e-01
    phi[8,7]  R2800     -1.4224373102188110e+00
    phi[8,7]  R2801     -7.3237401247024536e-01
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2802     -3.0999999046325684e+00
    phi[8,9]  R2803     -3.0999999046325684e+00
    phi[8,9]  R2804     -2.2400000095367432e+00
    phi[8,9]  R2805     -2.2400000095367432e+00
    phi[8,9]  R2806     -3.0999999046325684e+00
    phi[8,9]  R2807     -3.0999999046325684e+00
    phi[8,9]  R2808     -2.5699999332427979e+00
    phi[8,9]  R2809     -2.5699999332427979e+00
    phi[8,9]  R2810     -3.0999999046325684e+00
    phi[8,9]  R2811     -3.0999999046325684e+00
    phi[8,9]  R2812     -2.0899999141693115e+00
    phi[8,9]  R2813     -2.0899999141693115e+00
    phi[8,9]  R2814     -3.0999999046325684e+00
    phi[8,9]  R2815     -3.0999999046325684e+00
    phi[8,9]  R2816     1.5900038480758667e+00
    phi[8,9]  R2817     1.3526426553726196e+00
    phi[8,9]  R2818     2.1643614768981934e+00
    phi[8,9]  R2819     3.1673642992973328e-01
    phi[8,9]  R2820     8.0866515636444092e-01
    phi[8,9]  R2821     3.5792659968137741e-02
    phi[8,9]  R2822     -7.1106158196926117e-02
    phi[8,9]  R2823     2.4370159953832626e-02
    phi[8,9]  R2824     -1.2409540265798569e-01
    phi[8,9]  R2825     4.5133709907531738e-01
    phi[8,9]  R2826     -3.1005780696868896e+00
    phi[8,9]  R2827     -1.9249148368835449e+00
    phi[8,9]  R2828     -1.3096462488174438e+00
    phi[8,9]  R2829     -3.1428072452545166e+00
    phi[8,9]  R2830     -8.0413514375686646e-01
    phi[8,9]  R2831     -1.4209822416305542e+00
    phi[8,9]  R2832     3.9826259016990662e-01
    phi[8,9]  R2833     -1.1001037359237671e+00
    phi[8,9]  R2834     -2.1943154335021973e+00
    phi[8,9]  R2835     6.7347484827041626e-01
    phi[8,9]  R2836     -1.8761850595474243e+00
    phi[8,9]  R2837     -1.5248543024063110e+00
    phi[8,9]  R2838     -2.7397339344024658e+00
    phi[8,9]  R2839     -3.1009871959686279e+00
    phi[8,9]  R2840     -2.2245254516601562e+00
    phi[8,9]  R2841     -1.8342665433883667e+00
    phi[8,9]  R2842     -1.8793213367462158e+00
    phi[8,9]  R2843     -1.4688704013824463e+00
    phi[8,9]  R2844     -3.6108803749084473e-01
    phi[8,9]  R2845     -1.7022855281829834e+00
    phi[8,9]  R2846     -1.1324381828308105e+00
    phi[8,9]  R2847     -4.3896457552909851e-01
    phi[8,9]  R2848     -8.1192421913146973e-01
    phi[8,9]  R2849     -1.0869233608245850e+00
    phi[8,9]  R2850     -8.6438196897506714e-01
    phi[8,9]  R2851     -4.5088860392570496e-01
    phi[8,9]  R2852     -3.8277313113212585e-01
    phi[8,9]  R2853     -3.8946744799613953e-01
    phi[8,9]  R2854     2.0883843302726746e-01
    phi[8,9]  R2855     -8.9241534471511841e-01
    phi[8,9]  R2856     6.3460016250610352e-01
    phi[8,9]  R2857     2.2506461143493652e+00
    phi[8,9]  R2858     8.7076562643051147e-01
    phi[8,9]  R2859     1.1134877204895020e+00
    phi[8,9]  R2860     3.1637576222419739e-01
    phi[8,9]  R2861     2.1788221597671509e-01
    phi[8,9]  R2862     1.1377960443496704e+00
    phi[8,9]  R2863     1.7765930891036987e+00
    phi[8,9]  R2864     5.9639662504196167e-01
    phi[8,9]  R2865     2.9996076226234436e-01
    phi[8,9]  R2866     -1.5023715496063232e+00
    phi[8,9]  R2867     -7.5516235828399658e-01
    phi[8,9]  R2868     -7.0189911127090454e-01
    phi[8,9]  R2869     -2.0310158729553223e+00
    phi[8,9]  R2870     -1.3993563652038574e+00
    phi[8,9]  R2871     -5.4260241985321045e-01
    phi[8,9]  R2872     -1.6482514142990112e+00
    phi[8,9]  R2873     -1.6467052698135376e+00
    phi[8,9]  R2874     -3.9583319425582886e-01
    phi[8,9]  R2875     -1.1706986427307129e+00
    phi[8,9]  R2876     -1.4146103858947754e+00
    phi[8,9]  R2877     -1.2352807521820068e+00
    phi[8,9]  R2878     1.0694512128829956e+00
    phi[8,9]  R2879     -1.8712776899337769e-01
    phi[8,9]  R2880     -1.3669791221618652e+00
    phi[8,9]  R2881     -1.1871256828308105e+00
    phi[8,9]  R2882     1.9679437577724457e-01
    phi[8,9]  R2883     -2.2593417167663574e+00
    phi[8,9]  R2884     4.6024173498153687e-01
    phi[8,9]  R2885     0.0946318507194519
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2886     -3.0999999046325684e+00
    phi[9,8]  R2887     -3.0999999046325684e+00
    phi[9,8]  R2888     -2.2400000095367432e+00
    phi[9,8]  R2889     -2.2400000095367432e+00
    phi[9,8]  R2890     -3.0999999046325684e+00
    phi[9,8]  R2891     -3.0999999046325684e+00
    phi[9,8]  R2892     -2.5699999332427979e+00
    phi[9,8]  R2893     -2.5699999332427979e+00
    phi[9,8]  R2894     -3.0999999046325684e+00
    phi[9,8]  R2895     -3.0999999046325684e+00
    phi[9,8]  R2896     -2.0899999141693115e+00
    phi[9,8]  R2897     -2.0899999141693115e+00
    phi[9,8]  R2898     -3.0999999046325684e+00
    phi[9,8]  R2899     -3.0999999046325684e+00
    phi[9,8]  R2900     6.3460016250610352e-01
    phi[9,8]  R2901     2.2506461143493652e+00
    phi[9,8]  R2902     8.7076562643051147e-01
    phi[9,8]  R2903     1.1134877204895020e+00
    phi[9,8]  R2904     3.1637576222419739e-01
    phi[9,8]  R2905     2.1788221597671509e-01
    phi[9,8]  R2906     1.1377960443496704e+00
    phi[9,8]  R2907     1.7765930891036987e+00
    phi[9,8]  R2908     5.9639662504196167e-01
    phi[9,8]  R2909     2.9996076226234436e-01
    phi[9,8]  R2910     -1.5023715496063232e+00
    phi[9,8]  R2911     -7.5516235828399658e-01
    phi[9,8]  R2912     -7.0189911127090454e-01
    phi[9,8]  R2913     -2.0310158729553223e+00
    phi[9,8]  R2914     -1.3993563652038574e+00
    phi[9,8]  R2915     -5.4260241985321045e-01
    phi[9,8]  R2916     -1.6482514142990112e+00
    phi[9,8]  R2917     -1.6467052698135376e+00
    phi[9,8]  R2918     -3.9583319425582886e-01
    phi[9,8]  R2919     -1.1706986427307129e+00
    phi[9,8]  R2920     -1.4146103858947754e+00
    phi[9,8]  R2921     -1.2352807521820068e+00
    phi[9,8]  R2922     1.0694512128829956e+00
    phi[9,8]  R2923     -1.8712776899337769e-01
    phi[9,8]  R2924     -1.3669791221618652e+00
    phi[9,8]  R2925     -1.1871256828308105e+00
    phi[9,8]  R2926     1.9679437577724457e-01
    phi[9,8]  R2927     -2.2593417167663574e+00
    phi[9,8]  R2928     4.6024173498153687e-01
    phi[9,8]  R2929     0.0946318507194519
    phi[9,8]  R2930     1.5900038480758667e+00
    phi[9,8]  R2931     1.3526426553726196e+00
    phi[9,8]  R2932     2.1643614768981934e+00
    phi[9,8]  R2933     3.1673642992973328e-01
    phi[9,8]  R2934     8.0866515636444092e-01
    phi[9,8]  R2935     3.5792659968137741e-02
    phi[9,8]  R2936     -7.1106158196926117e-02
    phi[9,8]  R2937     2.4370159953832626e-02
    phi[9,8]  R2938     -1.2409540265798569e-01
    phi[9,8]  R2939     4.5133709907531738e-01
    phi[9,8]  R2940     -3.1005780696868896e+00
    phi[9,8]  R2941     -1.9249148368835449e+00
    phi[9,8]  R2942     -1.3096462488174438e+00
    phi[9,8]  R2943     -3.1428072452545166e+00
    phi[9,8]  R2944     -8.0413514375686646e-01
    phi[9,8]  R2945     -1.4209822416305542e+00
    phi[9,8]  R2946     3.9826259016990662e-01
    phi[9,8]  R2947     -1.1001037359237671e+00
    phi[9,8]  R2948     -2.1943154335021973e+00
    phi[9,8]  R2949     6.7347484827041626e-01
    phi[9,8]  R2950     -1.8761850595474243e+00
    phi[9,8]  R2951     -1.5248543024063110e+00
    phi[9,8]  R2952     -2.7397339344024658e+00
    phi[9,8]  R2953     -3.1009871959686279e+00
    phi[9,8]  R2954     -2.2245254516601562e+00
    phi[9,8]  R2955     -1.8342665433883667e+00
    phi[9,8]  R2956     -1.8793213367462158e+00
    phi[9,8]  R2957     -1.4688704013824463e+00
    phi[9,8]  R2958     -3.6108803749084473e-01
    phi[9,8]  R2959     -1.7022855281829834e+00
    phi[9,8]  R2960     -1.1324381828308105e+00
    phi[9,8]  R2961     -4.3896457552909851e-01
    phi[9,8]  R2962     -8.1192421913146973e-01
    phi[9,8]  R2963     -1.0869233608245850e+00
    phi[9,8]  R2964     -8.6438196897506714e-01
    phi[9,8]  R2965     -4.5088860392570496e-01
    phi[9,8]  R2966     -3.8277313113212585e-01
    phi[9,8]  R2967     -3.8946744799613953e-01
    phi[9,8]  R2968     2.0883843302726746e-01
    phi[9,8]  R2969     -8.9241534471511841e-01
    phi[9,11]  R81       1
    phi[9,11]  R82       1
    phi[9,11]  R83       2.8935070907851790e-01
    phi[9,11]  R84       1.8926485940464066e+00
    phi[9,11]  R85       -1.6427690033655087e+00
    phi[9,11]  R86       1.8707613542687318e+00
    phi[9,11]  R87       -7.0711386254929742e-01
    phi[9,11]  R88       1.3639273561480389e+00
    phi[9,11]  R89       -7.4278977211338582e-01
    phi[9,11]  R91       -1
    phi[9,11]  R2970     -2.8106491955540505e+00
    phi[9,11]  R2971     -3.3893506137110863e+00
    phi[9,11]  R2972     -3.4735141549033655e-01
    phi[9,11]  R2973     -4.1326486035831493e+00
    phi[9,11]  R2974     -4.7427689079980766e+00
    phi[9,11]  R2975     -1.4572309012670597e+00
    phi[9,11]  R2976     -0.699238578974066
    phi[9,11]  R2977     -4.4407612875115294e+00
    phi[9,11]  R2978     -3.8071137671818658e+00
    phi[9,11]  R2979     -2.3928860420832709e+00
    phi[9,11]  R2980     -7.2607255802127257e-01
    phi[9,11]  R2981     -3.4539272703173505e+00
    phi[9,11]  R2982     -3.8427896767459542e+00
    phi[9,11]  R2983     -2.3572101325191825e+00
    phi[9,11]  R2984     -5.7755385362052936e-02
    phi[9,11]  R2985     -5.8593802860248179e-02
    phi[9,11]  R2986     -6.2023490533721359e-02
    phi[9,11]  R2987     -6.7727027604263634e-02
    phi[9,11]  R2988     -7.0102615568735871e-02
    phi[9,11]  R2989     -8.0529796063146752e-02
    phi[9,11]  R2990     -8.7691978008901827e-02
    phi[9,11]  R2991     -1.8171594954839776e-01
    phi[9,11]  R2992     -2.3143015067045758e-01
    phi[9,11]  R2993     -1.5636108652381089e+00
    phi[9,11]  R2994     -1.1084842234009207e-01
    phi[9,11]  R2995     -1.1315862383017361e-01
    phi[9,11]  R2996     -1.1803902046707748e-01
    phi[9,11]  R2997     -1.2125231941997505e-01
    phi[9,11]  R2998     -0.341979101027611
    phi[9,11]  R2999     -3.8933657132560717e-01
    phi[9,11]  R3000     -4.4665666657072522e-01
    phi[9,11]  R3001     -4.6659933223918881e-01
    phi[9,11]  R3002     -4.7289052637410350e-01
    phi[9,11]  R3003     -4.7819206398101866e-01
    phi[9,11]  R3004     -0.0920837742044105
    phi[9,11]  R3005     -1.5019554785649936e-01
    phi[9,11]  R3006     -0.178466213678234
    phi[9,11]  R3007     -2.3774367484224293e-01
    phi[9,11]  R3008     -2.4425830441977370e-01
    phi[9,11]  R3009     -2.8760110240879910e-01
    phi[9,11]  R3010     -2.9661324014757906e-01
    phi[9,11]  R3011     -3.0045150122918773e-01
    phi[9,11]  R3012     -4.0646278897312826e-01
    phi[9,11]  R3013     -1.2614114057938608e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R92       -1
    z[0,1,0]  R93       1
    z[0,1,0]  R106      -7.5358949601650238e-02
    z[0,1,0]  R107      1.5595360100269318e-01
    z[0,1,0]  R108      3.7856489419937134e-01
    z[0,1,0]  R109      5.7903724908828735e-01
    z[0,1,0]  R110      4.5991745591163635e-01
    z[0,1,0]  R111      5.6721532344818115e-01
    z[0,1,0]  R112      7.5176799297332764e-01
    z[0,1,0]  R113      2.5073993206024170e-01
    z[0,1,0]  R114      -5.2961182594299316e-01
    z[0,1,0]  R115      7.4970316886901855e-01
    z[0,1,0]  R116      -3.5578823089599609e-01
    z[0,1,0]  R117      2.3767025768756866e-01
    z[0,1,0]  R118      3.7304529547691345e-01
    z[0,1,0]  R119      1.1755401641130447e-01
    z[0,1,0]  R120      -3.4004725515842438e-02
    z[0,1,0]  R121      2.3310141265392303e-01
    z[0,1,0]  R122      -1.1395020037889481e-01
    z[0,1,0]  R123      -6.6100138425827026e-01
    z[0,1,0]  R124      -6.7390298843383789e-01
    z[0,1,0]  R125      -7.2265905141830444e-01
    z[0,1,0]  R126      2.5237640738487244e-01
    z[0,1,0]  R127      -4.7703701257705688e-01
    z[0,1,0]  R128      5.8202129602432251e-01
    z[0,1,0]  R129      6.7512148618698120e-01
    z[0,1,0]  R130      5.8907490968704224e-01
    z[0,1,0]  R131      3.7437388300895691e-01
    z[0,1,0]  R132      2.2523894906044006e-01
    z[0,1,0]  R133      -5.2928882837295532e-01
    z[0,1,0]  R134      -5.4311645030975342e-01
    z[0,1,0]  R135      -0.449020653963089
    z[0,1,0]  R136      4.8762276768684387e-01
    z[0,1,0]  R137      5.3526413440704346e-01
    z[0,1,0]  R138      4.7786450386047363e-01
    z[0,1,0]  R139      4.3266192078590393e-01
    z[0,1,0]  R140      4.8137810826301575e-01
    z[0,1,0]  R141      4.4484078884124756e-01
    z[0,1,0]  R142      2.2758446633815765e-01
    z[0,1,0]  R143      -3.2156670093536377e-01
    z[0,1,0]  R144      -6.7632973194122314e-02
    z[0,1,0]  R145      -1.2362013012170792e-01
    z[0,1,0]  R146      6.5048910677433014e-02
    z[0,1,0]  R147      -7.9278725385665894e-01
    z[0,1,0]  R148      -8.3439606428146362e-01
    z[0,1,0]  R149      -8.2489007711410522e-01
    z[0,1,0]  R150      -6.8961602449417114e-01
    z[0,1,0]  R151      -7.8425419330596924e-01
    z[0,1,0]  R152      -6.8020766973495483e-01
    z[0,1,0]  R153      -7.2894531488418579e-01
    z[0,1,0]  R154      -8.1985729932785034e-01
    z[0,1,0]  R155      -0.830944299697876
    z[0,1,0]  R156      1.1360311508178711e-01
    z[0,1,0]  R157      1.3797410763800144e-02
    z[0,1,0]  R158      -4.2373758554458618e-01
    z[0,1,0]  R159      -3.0192825198173523e-01
    z[0,1,0]  R160      -6.3382869958877563e-01
    z[0,1,0]  R161      -6.9172859191894531e-01
    z[0,1,0]  R162      -7.5065809488296509e-01
    z[0,1,0]  R163      -8.2509487867355347e-01
    z[0,1,0]  R164      -0.679706335067749
    z[0,1,0]  R165      -9.4545549154281616e-01
    z[0,1,0]  R166      0.0442180261015892
    z[0,1,0]  R167      -2.0517329871654510e-01
    z[0,1,0]  R168      -9.0681433677673340e-01
    z[0,1,0]  R169      -7.8480494022369385e-01
    z[0,1,0]  R170      -8.7693107128143311e-01
    z[0,1,0]  R171      -7.3673528432846069e-01
    z[0,1,0]  R172      -6.9118893146514893e-01
    z[0,1,0]  R173      -7.5684589147567749e-01
    z[0,1,0]  R174      -4.3756476044654846e-01
    z[0,1,0]  R175      -7.0736819505691528e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R94       -1
    z[0,1,1]  R95       1
    z[0,1,1]  R106      9.6793889999389648e-02
    z[0,1,1]  R107      9.5467088976874948e-04
    z[0,1,1]  R108      4.4080372899770737e-02
    z[0,1,1]  R109      3.8586426526308060e-02
    z[0,1,1]  R110      3.5572454333305359e-02
    z[0,1,1]  R111      7.6472297310829163e-02
    z[0,1,1]  R112      5.3024303168058395e-02
    z[0,1,1]  R113      4.7504503279924393e-02
    z[0,1,1]  R114      7.1272291243076324e-02
    z[0,1,1]  R115      -1.6442860662937164e-01
    z[0,1,1]  R116      2.6647645235061646e-01
    z[0,1,1]  R117      -5.1985198259353638e-01
    z[0,1,1]  R118      -1.8105420470237732e-01
    z[0,1,1]  R119      -5.4912024736404419e-01
    z[0,1,1]  R120      -6.2785738706588745e-01
    z[0,1,1]  R121      -3.5683214664459229e-01
    z[0,1,1]  R122      1.5637357532978058e-01
    z[0,1,1]  R123      -3.4449872374534607e-01
    z[0,1,1]  R124      -3.8743022084236145e-01
    z[0,1,1]  R125      -1.1335832625627518e-01
    z[0,1,1]  R126      8.7743246555328369e-01
    z[0,1,1]  R127      7.4273413419723511e-01
    z[0,1,1]  R128      -6.8861061334609985e-01
    z[0,1,1]  R129      -5.6328219175338745e-01
    z[0,1,1]  R130      -5.7809185981750488e-01
    z[0,1,1]  R131      -5.1152777671813965e-01
    z[0,1,1]  R132      -5.5766272544860840e-01
    z[0,1,1]  R133      -7.1173429489135742e-02
    z[0,1,1]  R134      -8.6887432262301445e-03
    z[0,1,1]  R135      -4.6204483509063721e-01
    z[0,1,1]  R136      3.1182876229286194e-01
    z[0,1,1]  R137      3.1679326295852661e-01
    z[0,1,1]  R138      2.8544783592224121e-01
    z[0,1,1]  R139      3.0021238327026367e-01
    z[0,1,1]  R140      3.7033927440643311e-01
    z[0,1,1]  R141      2.9730680584907532e-01
    z[0,1,1]  R142      2.9784691333770752e-01
    z[0,1,1]  R143      -0.76842200756073
    z[0,1,1]  R144      -7.2994166612625122e-01
    z[0,1,1]  R145      -6.3500648736953735e-01
    z[0,1,1]  R146      5.7323312759399414e-01
    z[0,1,1]  R147      -2.5927681475877762e-02
    z[0,1,1]  R148      7.2741672396659851e-02
    z[0,1,1]  R149      -1.9623391330242157e-01
    z[0,1,1]  R150      -2.3165687918663025e-02
    z[0,1,1]  R151      6.2084991484880447e-02
    z[0,1,1]  R152      -1.1389282345771790e-01
    z[0,1,1]  R153      1.4568357169628143e-01
    z[0,1,1]  R154      -0.0789308175444603
    z[0,1,1]  R155      -3.2679599523544312e-01
    z[0,1,1]  R156      5.8238863945007324e-01
    z[0,1,1]  R157      3.8293415307998657e-01
    z[0,1,1]  R158      -8.1575781106948853e-01
    z[0,1,1]  R159      -7.2446751594543457e-01
    z[0,1,1]  R160      -2.1643690764904022e-01
    z[0,1,1]  R161      -3.0542570352554321e-01
    z[0,1,1]  R162      -2.4331867694854736e-01
    z[0,1,1]  R163      -2.3857049643993378e-01
    z[0,1,1]  R164      -2.2109535336494446e-01
    z[0,1,1]  R165      -2.5237387418746948e-01
    z[0,1,1]  R166      5.4887527227401733e-01
    z[0,1,1]  R167      -0.756986141204834
    z[0,1,1]  R168      -2.5298237800598145e-01
    z[0,1,1]  R169      -0.319732129573822
    z[0,1,1]  R170      -4.1124969720840454e-01
    z[0,1,1]  R171      -3.0991527438163757e-01
    z[0,1,1]  R172      -4.4507080316543579e-01
    z[0,1,1]  R173      -2.6714438199996948e-01
    z[0,1,1]  R174      -7.5146359205245972e-01
    z[0,1,1]  R175      -3.3937805891036987e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R96       -1
    z[0,1,2]  R97       1
    z[0,1,2]  R106      6.4283972978591919e-01
    z[0,1,2]  R107      2.3409101366996765e-01
    z[0,1,2]  R108      2.7970978617668152e-01
    z[0,1,2]  R109      3.0148291587829590e-01
    z[0,1,2]  R110      0.496791809797287
    z[0,1,2]  R111      5.2066934108734131e-01
    z[0,1,2]  R112      4.2420539259910583e-01
    z[0,1,2]  R113      4.7645160555839539e-01
    z[0,1,2]  R114      2.7403315901756287e-01
    z[0,1,2]  R115      -4.6178337931632996e-01
    z[0,1,2]  R116      -1.3109797239303589e-01
    z[0,1,2]  R117      5.8739078044891357e-01
    z[0,1,2]  R118      2.1813666820526123e-01
    z[0,1,2]  R119      -2.7783304452896118e-01
    z[0,1,2]  R120      -2.8996571898460388e-01
    z[0,1,2]  R121      -5.2452516555786133e-01
    z[0,1,2]  R122      -0.766013503074646
    z[0,1,2]  R123      -2.6005801558494568e-01
    z[0,1,2]  R124      -3.7955591082572937e-01
    z[0,1,2]  R125      -5.3356665372848511e-01
    z[0,1,2]  R126      -1.0671491920948029e-01
    z[0,1,2]  R127      -2.4845926463603973e-01
    z[0,1,2]  R128      1.1095648258924484e-01
    z[0,1,2]  R129      -5.9024691581726074e-02
    z[0,1,2]  R130      -1.1720573902130127e-01
    z[0,1,2]  R131      3.5954797267913818e-01
    z[0,1,2]  R132      -1.7758095264434814e-01
    z[0,1,2]  R133      8.2312017679214478e-01
    z[0,1,2]  R134      5.6279665231704712e-01
    z[0,1,2]  R135      6.3541257381439209e-01
    z[0,1,2]  R136      -3.4188345074653625e-01
    z[0,1,2]  R137      1.6730089485645294e-01
    z[0,1,2]  R138      -3.2735043764114380e-01
    z[0,1,2]  R139      -1.1577780544757843e-01
    z[0,1,2]  R140      0.0608777217566967
    z[0,1,2]  R141      -4.4989970326423645e-01
    z[0,1,2]  R142      -6.7227369546890259e-01
    z[0,1,2]  R143      -4.3394207954406738e-01
    z[0,1,2]  R144      9.9671795964241028e-02
    z[0,1,2]  R145      -9.5330648124217987e-02
    z[0,1,2]  R146      6.7910069227218628e-01
    z[0,1,2]  R147      1.8427358567714691e-01
    z[0,1,2]  R148      3.8594490289688110e-01
    z[0,1,2]  R149      -1.6113594756461680e-04
    z[0,1,2]  R150      4.3455675244331360e-01
    z[0,1,2]  R151      2.2913278639316559e-01
    z[0,1,2]  R152      4.1522794961929321e-01
    z[0,1,2]  R153      4.0534734725952148e-01
    z[0,1,2]  R154      3.4077703952789307e-01
    z[0,1,2]  R155      2.7540290355682373e-01
    z[0,1,2]  R156      -0.0981765165925026
    z[0,1,2]  R157      -1.3510827720165253e-01
    z[0,1,2]  R158      1.9192628562450409e-02
    z[0,1,2]  R159      0.0211052056401968
    z[0,1,2]  R160      -0.00716095557436347
    z[0,1,2]  R161      -2.5757923722267151e-01
    z[0,1,2]  R162      2.5159388780593872e-01
    z[0,1,2]  R163      4.9874968826770782e-02
    z[0,1,2]  R164      1.4634981751441956e-01
    z[0,1,2]  R165      1.1708619445562363e-01
    z[0,1,2]  R166      4.4962030649185181e-01
    z[0,1,2]  R167      -1.3260406255722046e-01
    z[0,1,2]  R168      -4.1260927915573120e-02
    z[0,1,2]  R169      -2.3052366077899933e-01
    z[0,1,2]  R170      -4.2285788804292679e-02
    z[0,1,2]  R171      9.9219158291816711e-02
    z[0,1,2]  R172      2.9561412334442139e-01
    z[0,1,2]  R173      2.1575149893760681e-01
    z[0,1,2]  R174      2.2460678592324257e-02
    z[0,1,2]  R175      -3.4787702560424805e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R98       -1
    z[0,1,3]  R99       1
    z[0,1,3]  R106      -1.2030338868498802e-02
    z[0,1,3]  R107      7.1206682920455933e-01
    z[0,1,3]  R108      4.6227118372917175e-01
    z[0,1,3]  R109      4.6484208106994629e-01
    z[0,1,3]  R110      1.7022161185741425e-01
    z[0,1,3]  R111      -3.9080867171287537e-01
    z[0,1,3]  R112      -2.2143563628196716e-01
    z[0,1,3]  R113      -3.1327739357948303e-01
    z[0,1,3]  R114      -1.8965117633342743e-01
    z[0,1,3]  R115      4.0039411187171936e-01
    z[0,1,3]  R116      -2.8232035040855408e-01
    z[0,1,3]  R117      -7.3677316308021545e-02
    z[0,1,3]  R118      -2.8459736704826355e-01
    z[0,1,3]  R119      -5.1777446269989014e-01
    z[0,1,3]  R120      -2.0285290479660034e-01
    z[0,1,3]  R121      -6.5406644344329834e-01
    z[0,1,3]  R122      -3.8228946924209595e-01
    z[0,1,3]  R123      7.9646319150924683e-02
    z[0,1,3]  R124      2.0401114225387573e-01
    z[0,1,3]  R125      -0.0553707480430603
    z[0,1,3]  R126      -1.2512814998626709e-01
    z[0,1,3]  R127      2.2900892794132233e-01
    z[0,1,3]  R128      -1.9740380346775055e-01
    z[0,1,3]  R129      -2.7225196361541748e-01
    z[0,1,3]  R130      -4.1527125239372253e-01
    z[0,1,3]  R131      2.8835743665695190e-01
    z[0,1,3]  R132      -2.7360485401004553e-03
    z[0,1,3]  R133      -1.1131959408521652e-01
    z[0,1,3]  R134      1.2222599983215332e-01
    z[0,1,3]  R135      -1.0076513141393661e-01
    z[0,1,3]  R136      4.9243035912513733e-01
    z[0,1,3]  R137      5.0554656982421875e-01
    z[0,1,3]  R138      5.1138144731521606e-01
    z[0,1,3]  R139      3.3378553390502930e-01
    z[0,1,3]  R140      -1.8854171037673950e-01
    z[0,1,3]  R141      -1.4253887534141541e-01
    z[0,1,3]  R142      2.4872681498527527e-01
    z[0,1,3]  R143      2.1641846746206284e-02
    z[0,1,3]  R144      -1.9361507892608643e-01
    z[0,1,3]  R145      -4.4752854108810425e-01
    z[0,1,3]  R146      -4.4447034597396851e-02
    z[0,1,3]  R147      -5.2434122562408447e-01
    z[0,1,3]  R148      -3.5095199942588806e-01
    z[0,1,3]  R149      -3.1402194499969482e-01
    z[0,1,3]  R150      -3.2981792092323303e-01
    z[0,1,3]  R151      -2.9031160473823547e-01
    z[0,1,3]  R152      -5.5152559280395508e-01
    z[0,1,3]  R153      -1.7999365925788879e-01
    z[0,1,3]  R154      -0.319568932056427
    z[0,1,3]  R155      -0.0645049586892128
    z[0,1,3]  R156      -6.5557742118835449e-01
    z[0,1,3]  R157      -1.2081279419362545e-02
    z[0,1,3]  R158      -0.0806296318769455
    z[0,1,3]  R159      -1.9459196925163269e-01
    z[0,1,3]  R160      -6.4039933681488037e-01
    z[0,1,3]  R161      -4.7206792235374451e-01
    z[0,1,3]  R162      -3.4568536281585693e-01
    z[0,1,3]  R163      -2.2869020700454712e-01
    z[0,1,3]  R164      -4.5102012157440186e-01
    z[0,1,3]  R165      2.3547211661934853e-02
    z[0,1,3]  R166      -2.1843446791172028e-01
    z[0,1,3]  R167      3.8228464126586914e-01
    z[0,1,3]  R168      -2.4428358674049377e-01
    z[0,1,3]  R169      -3.6610227823257446e-01
    z[0,1,3]  R170      -7.9962633550167084e-02
    z[0,1,3]  R171      -4.3234610557556152e-01
    z[0,1,3]  R172      -4.3659138679504395e-01
    z[0,1,3]  R173      -4.0801870822906494e-01
    z[0,1,3]  R174      -3.2905688881874084e-01
    z[0,1,3]  R175      -4.3137919902801514e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R100      -1
    z[0,1,4]  R101      1
    z[0,1,4]  R106      -3.5819873213768005e-01
    z[0,1,4]  R107      8.4051378071308136e-02
    z[0,1,4]  R108      8.7837286293506622e-02
    z[0,1,4]  R109      -5.7816648483276367e-01
    z[0,1,4]  R110      -3.6483651399612427e-01
    z[0,1,4]  R111      2.0078261196613312e-01
    z[0,1,4]  R112      1.1413767933845520e-01
    z[0,1,4]  R113      -3.7626230716705322e-01
    z[0,1,4]  R114      -9.2131003737449646e-02
    z[0,1,4]  R115      1.4716595411300659e-01
    z[0,1,4]  R116      6.9416522979736328e-01
    z[0,1,4]  R117      1.3592466711997986e-01
    z[0,1,4]  R118      3.6502486467361450e-01
    z[0,1,4]  R119      -4.6036940813064575e-01
    z[0,1,4]  R120      7.7058456838130951e-02
    z[0,1,4]  R121      -3.0732330679893494e-01
    z[0,1,4]  R122      -3.5659581422805786e-01
    z[0,1,4]  R123      -5.9570330381393433e-01
    z[0,1,4]  R124      -3.5770753026008606e-01
    z[0,1,4]  R125      -1.8804828822612762e-01
    z[0,1,4]  R126      -1.5170462429523468e-01
    z[0,1,4]  R127      3.0439239740371704e-01
    z[0,1,4]  R128      2.2947153449058533e-01
    z[0,1,4]  R129      1.3315358757972717e-01
    z[0,1,4]  R130      -0.309390664100647
    z[0,1,4]  R131      2.5706894695758820e-02
    z[0,1,4]  R132      4.2895305156707764e-01
    z[0,1,4]  R133      5.7034876197576523e-02
    z[0,1,4]  R134      -3.9720979332923889e-01
    z[0,1,4]  R135      3.2676732540130615e-01
    z[0,1,4]  R136      -4.7869235277175903e-01
    z[0,1,4]  R137      -0.353411465883255
    z[0,1,4]  R138      2.1292430162429810e-01
    z[0,1,4]  R139      5.5049387738108635e-03
    z[0,1,4]  R140      -4.8308354616165161e-01
    z[0,1,4]  R141      -5.2213305234909058e-01
    z[0,1,4]  R142      1.1937224864959717e-01
    z[0,1,4]  R143      1.5014718472957611e-01
    z[0,1,4]  R144      -6.3855779170989990e-01
    z[0,1,4]  R145      -5.8134567737579346e-01
    z[0,1,4]  R146      1.7674861848354340e-01
    z[0,1,4]  R147      1.7360825836658478e-01
    z[0,1,4]  R148      1.3603407144546509e-01
    z[0,1,4]  R149      2.2222118079662323e-01
    z[0,1,4]  R150      4.4917544722557068e-01
    z[0,1,4]  R151      4.6200191974639893e-01
    z[0,1,4]  R152      -1.6582775115966797e-01
    z[0,1,4]  R153      4.5760747790336609e-01
    z[0,1,4]  R154      -2.6043057441711426e-01
    z[0,1,4]  R155      -1.2828649580478668e-01
    z[0,1,4]  R156      3.2459726929664612e-01
    z[0,1,4]  R157      1.5240977704524994e-01
    z[0,1,4]  R158      -2.9337859153747559e-01
    z[0,1,4]  R159      -1.7532658576965332e-01
    z[0,1,4]  R160      -1.3813933730125427e-01
    z[0,1,4]  R161      -2.4399299919605255e-01
    z[0,1,4]  R162      -1.8310281634330750e-01
    z[0,1,4]  R163      -4.3905708193778992e-01
    z[0,1,4]  R164      -3.6279231309890747e-01
    z[0,1,4]  R165      -1.6562348604202271e-01
    z[0,1,4]  R166      1.3291072845458984e-01
    z[0,1,4]  R167      -4.0647846460342407e-01
    z[0,1,4]  R168      3.4199748188257217e-02
    z[0,1,4]  R169      7.8203096985816956e-02
    z[0,1,4]  R170      -1.6141681373119354e-01
    z[0,1,4]  R171      -1.0343640297651291e-01
    z[0,1,4]  R172      -1.0888533294200897e-01
    z[0,1,4]  R173      -2.6009339094161987e-01
    z[0,1,4]  R174      -6.3789568841457367e-02
    z[0,1,4]  R175      -1.9778449833393097e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R102      -1
    z[0,1,5]  R103      1
    z[0,1,5]  R106      -1.2088346481323242e-01
    z[0,1,5]  R107      -6.2800031900405884e-01
    z[0,1,5]  R108      -4.0164360404014587e-01
    z[0,1,5]  R109      -1.0383608937263489e-01
    z[0,1,5]  R110      -5.4557675123214722e-01
    z[0,1,5]  R111      -4.5615857839584351e-01
    z[0,1,5]  R112      1.4392022788524628e-01
    z[0,1,5]  R113      2.1801939606666565e-01
    z[0,1,5]  R114      -6.6552406549453735e-01
    z[0,1,5]  R115      -1.0773006826639175e-01
    z[0,1,5]  R116      4.6527001261711121e-01
    z[0,1,5]  R117      4.7618106007575989e-01
    z[0,1,5]  R118      5.6284952163696289e-01
    z[0,1,5]  R119      -2.9629451036453247e-01
    z[0,1,5]  R120      -5.6557911634445190e-01
    z[0,1,5]  R121      8.1596568226814270e-02
    z[0,1,5]  R122      -2.2623999416828156e-01
    z[0,1,5]  R123      1.2408995628356934e-01
    z[0,1,5]  R124      -7.9403780400753021e-03
    z[0,1,5]  R125      -6.2764868140220642e-02
    z[0,1,5]  R126      2.8822100162506104e-01
    z[0,1,5]  R127      3.8251818623393774e-03
    z[0,1,5]  R128      1.7396403709426522e-03
    z[0,1,5]  R129      3.5765978693962097e-01
    z[0,1,5]  R130      2.7456291019916534e-02
    z[0,1,5]  R131      1.7912285029888153e-01
    z[0,1,5]  R132      7.6556608080863953e-02
    z[0,1,5]  R133      1.4506430923938751e-01
    z[0,1,5]  R134      -2.1472917497158051e-01
    z[0,1,5]  R135      -1.7509551346302032e-01
    z[0,1,5]  R136      -2.0041167736053467e-01
    z[0,1,5]  R137      -4.3665367364883423e-01
    z[0,1,5]  R138      -2.8782343864440918e-01
    z[0,1,5]  R139      -6.0278022289276123e-01
    z[0,1,5]  R140      -0.566609799861908
    z[0,1,5]  R141      -0.28685262799263
    z[0,1,5]  R142      1.5974249690771103e-02
    z[0,1,5]  R143      -3.0622237920761108e-01
    z[0,1,5]  R144      -8.5659280419349670e-02
    z[0,1,5]  R145      -9.4244204461574554e-02
    z[0,1,5]  R146      3.6924883723258972e-01
    z[0,1,5]  R147      9.4708538381382823e-04
    z[0,1,5]  R148      -0.0814613625407219
    z[0,1,5]  R149      -3.5854384303092957e-01
    z[0,1,5]  R150      -1.4186948537826538e-01
    z[0,1,5]  R151      9.6284836530685425e-02
    z[0,1,5]  R152      1.4110732078552246e-01
    z[0,1,5]  R153      4.8242881894111633e-03
    z[0,1,5]  R154      -0.0749167948961258
    z[0,1,5]  R155      2.7209895849227905e-01
    z[0,1,5]  R156      1.9273126125335693e-01
    z[0,1,5]  R157      7.6943945884704590e-01
    z[0,1,5]  R158      -4.8499464988708496e-02
    z[0,1,5]  R159      -2.7498283982276917e-01
    z[0,1,5]  R160      -3.4907805919647217e-01
    z[0,1,5]  R161      2.7364954352378845e-01
    z[0,1,5]  R162      -4.0097177028656006e-01
    z[0,1,5]  R163      -1.1034757643938065e-01
    z[0,1,5]  R164      0.32767453789711
    z[0,1,5]  R165      -3.4630617592483759e-03
    z[0,1,5]  R166      1.9378204643726349e-01
    z[0,1,5]  R167      -2.3140968382358551e-01
    z[0,1,5]  R168      2.0276030898094177e-01
    z[0,1,5]  R169      -2.6396793127059937e-01
    z[0,1,5]  R170      -5.3916919976472855e-02
    z[0,1,5]  R171      1.4100360684096813e-02
    z[0,1,5]  R172      1.1793158203363419e-01
    z[0,1,5]  R173      -1.5098898112773895e-01
    z[0,1,5]  R174      -3.3523935079574585e-01
    z[0,1,5]  R175      -1.8744681775569916e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R104      -1
    z[0,1,6]  R105      1
    z[0,1,6]  R106      0.654710054397583
    z[0,1,6]  R107      1.1131328344345093e-01
    z[0,1,6]  R108      -6.2751924991607666e-01
    z[0,1,6]  R109      -1.0582274943590164e-01
    z[0,1,6]  R110      -2.8403052687644958e-01
    z[0,1,6]  R111      -1.4015206135809422e-02
    z[0,1,6]  R112      -4.1147151589393616e-01
    z[0,1,6]  R113      -0.648550808429718
    z[0,1,6]  R114      -3.8981980085372925e-01
    z[0,1,6]  R115      6.3916943967342377e-02
    z[0,1,6]  R116      8.4687858819961548e-02
    z[0,1,6]  R117      2.7854385972023010e-01
    z[0,1,6]  R118      -4.9943429231643677e-01
    z[0,1,6]  R119      1.9908805191516876e-01
    z[0,1,6]  R120      3.9190784096717834e-01
    z[0,1,6]  R121      1.1957976222038269e-01
    z[0,1,6]  R122      2.2648532688617706e-01
    z[0,1,6]  R123      -1.2779808603227139e-02
    z[0,1,6]  R124      2.8644669055938721e-01
    z[0,1,6]  R125      3.7128555774688721e-01
    z[0,1,6]  R126      1.8244867026805878e-01
    z[0,1,6]  R127      -1.1804796010255814e-01
    z[0,1,6]  R128      -2.8831705451011658e-01
    z[0,1,6]  R129      -6.0568958520889282e-02
    z[0,1,6]  R130      -0.190096914768219
    z[0,1,6]  R131      5.9414887428283691e-01
    z[0,1,6]  R132      6.4565908908843994e-01
    z[0,1,6]  R133      -2.3918978869915009e-02
    z[0,1,6]  R134      4.1156476736068726e-01
    z[0,1,6]  R135      1.8318559229373932e-01
    z[0,1,6]  R136      -1.9053514301776886e-01
    z[0,1,6]  R137      1.1832785606384277e-01
    z[0,1,6]  R138      4.3967801332473755e-01
    z[0,1,6]  R139      -4.8423612117767334e-01
    z[0,1,6]  R140      1.9352915883064270e-01
    z[0,1,6]  R141      3.6890518665313721e-01
    z[0,1,6]  R142      -5.7547432184219360e-01
    z[0,1,6]  R143      3.2123643904924393e-02
    z[0,1,6]  R144      -9.8000364378094673e-03
    z[0,1,6]  R145      -1.5896634757518768e-01
    z[0,1,6]  R146      -1.9087785482406616e-01
    z[0,1,6]  R147      -1.7828333377838135e-01
    z[0,1,6]  R148      3.5070598125457764e-02
    z[0,1,6]  R149      -6.7103527486324310e-02
    z[0,1,6]  R150      6.6242665052413940e-02
    z[0,1,6]  R151      -1.4694066345691681e-01
    z[0,1,6]  R152      1.8468730151653290e-02
    z[0,1,6]  R153      2.0318174362182617e-01
    z[0,1,6]  R154      -1.7295676469802856e-01
    z[0,1,6]  R155      -1.7953509092330933e-01
    z[0,1,6]  R156      2.5688254833221436e-01
    z[0,1,6]  R157      4.6851357817649841e-01
    z[0,1,6]  R158      2.4432139098644257e-01
    z[0,1,6]  R159      4.8920312523841858e-01
    z[0,1,6]  R160      -1.7767407000064850e-02
    z[0,1,6]  R161      0.0679338276386261
    z[0,1,6]  R162      -1.4336473308503628e-02
    z[0,1,6]  R163      5.0678491592407227e-02
    z[0,1,6]  R164      -1.5902754664421082e-01
    z[0,1,6]  R165      2.6732046157121658e-02
    z[0,1,6]  R166      -6.2585294246673584e-01
    z[0,1,6]  R167      -4.8738211393356323e-02
    z[0,1,6]  R168      -1.0014757513999939e-01
    z[0,1,6]  R169      -1.3742519915103912e-01
    z[0,1,6]  R170      -1.5722940862178802e-01
    z[0,1,6]  R171      3.9180129766464233e-01
    z[0,1,6]  R172      -1.4284999668598175e-01
    z[0,1,6]  R173      2.2878804802894592e-01
    z[0,1,6]  R174      -1.3638909161090851e-01
    z[0,1,6]  R175      -5.5600155144929886e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R176      -1
    z[1,0,0]  R177      1
    z[1,0,0]  R190      4.8762276768684387e-01
    z[1,0,0]  R191      5.3526413440704346e-01
    z[1,0,0]  R192      4.7786450386047363e-01
    z[1,0,0]  R193      4.3266192078590393e-01
    z[1,0,0]  R194      4.8137810826301575e-01
    z[1,0,0]  R195      4.4484078884124756e-01
    z[1,0,0]  R196      2.2758446633815765e-01
    z[1,0,0]  R197      -3.2156670093536377e-01
    z[1,0,0]  R198      -6.7632973194122314e-02
    z[1,0,0]  R199      -1.2362013012170792e-01
    z[1,0,0]  R200      6.5048910677433014e-02
    z[1,0,0]  R201      -7.9278725385665894e-01
    z[1,0,0]  R202      -8.3439606428146362e-01
    z[1,0,0]  R203      -8.2489007711410522e-01
    z[1,0,0]  R204      -6.8961602449417114e-01
    z[1,0,0]  R205      -7.8425419330596924e-01
    z[1,0,0]  R206      -6.8020766973495483e-01
    z[1,0,0]  R207      -7.2894531488418579e-01
    z[1,0,0]  R208      -8.1985729932785034e-01
    z[1,0,0]  R209      -0.830944299697876
    z[1,0,0]  R210      1.1360311508178711e-01
    z[1,0,0]  R211      1.3797410763800144e-02
    z[1,0,0]  R212      -4.2373758554458618e-01
    z[1,0,0]  R213      -3.0192825198173523e-01
    z[1,0,0]  R214      -6.3382869958877563e-01
    z[1,0,0]  R215      -6.9172859191894531e-01
    z[1,0,0]  R216      -7.5065809488296509e-01
    z[1,0,0]  R217      -8.2509487867355347e-01
    z[1,0,0]  R218      -0.679706335067749
    z[1,0,0]  R219      -9.4545549154281616e-01
    z[1,0,0]  R220      0.0442180261015892
    z[1,0,0]  R221      -2.0517329871654510e-01
    z[1,0,0]  R222      -9.0681433677673340e-01
    z[1,0,0]  R223      -7.8480494022369385e-01
    z[1,0,0]  R224      -8.7693107128143311e-01
    z[1,0,0]  R225      -7.3673528432846069e-01
    z[1,0,0]  R226      -6.9118893146514893e-01
    z[1,0,0]  R227      -7.5684589147567749e-01
    z[1,0,0]  R228      -4.3756476044654846e-01
    z[1,0,0]  R229      -7.0736819505691528e-01
    z[1,0,0]  R230      -7.5358949601650238e-02
    z[1,0,0]  R231      1.5595360100269318e-01
    z[1,0,0]  R232      3.7856489419937134e-01
    z[1,0,0]  R233      5.7903724908828735e-01
    z[1,0,0]  R234      4.5991745591163635e-01
    z[1,0,0]  R235      5.6721532344818115e-01
    z[1,0,0]  R236      7.5176799297332764e-01
    z[1,0,0]  R237      2.5073993206024170e-01
    z[1,0,0]  R238      -5.2961182594299316e-01
    z[1,0,0]  R239      7.4970316886901855e-01
    z[1,0,0]  R240      -3.5578823089599609e-01
    z[1,0,0]  R241      2.3767025768756866e-01
    z[1,0,0]  R242      3.7304529547691345e-01
    z[1,0,0]  R243      1.1755401641130447e-01
    z[1,0,0]  R244      -3.4004725515842438e-02
    z[1,0,0]  R245      2.3310141265392303e-01
    z[1,0,0]  R246      -1.1395020037889481e-01
    z[1,0,0]  R247      -6.6100138425827026e-01
    z[1,0,0]  R248      -6.7390298843383789e-01
    z[1,0,0]  R249      -7.2265905141830444e-01
    z[1,0,0]  R250      2.5237640738487244e-01
    z[1,0,0]  R251      -4.7703701257705688e-01
    z[1,0,0]  R252      5.8202129602432251e-01
    z[1,0,0]  R253      6.7512148618698120e-01
    z[1,0,0]  R254      5.8907490968704224e-01
    z[1,0,0]  R255      3.7437388300895691e-01
    z[1,0,0]  R256      2.2523894906044006e-01
    z[1,0,0]  R257      -5.2928882837295532e-01
    z[1,0,0]  R258      -5.4311645030975342e-01
    z[1,0,0]  R259      -0.449020653963089
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R178      -1
    z[1,0,1]  R179      1
    z[1,0,1]  R190      3.1182876229286194e-01
    z[1,0,1]  R191      3.1679326295852661e-01
    z[1,0,1]  R192      2.8544783592224121e-01
    z[1,0,1]  R193      3.0021238327026367e-01
    z[1,0,1]  R194      3.7033927440643311e-01
    z[1,0,1]  R195      2.9730680584907532e-01
    z[1,0,1]  R196      2.9784691333770752e-01
    z[1,0,1]  R197      -0.76842200756073
    z[1,0,1]  R198      -7.2994166612625122e-01
    z[1,0,1]  R199      -6.3500648736953735e-01
    z[1,0,1]  R200      5.7323312759399414e-01
    z[1,0,1]  R201      -2.5927681475877762e-02
    z[1,0,1]  R202      7.2741672396659851e-02
    z[1,0,1]  R203      -1.9623391330242157e-01
    z[1,0,1]  R204      -2.3165687918663025e-02
    z[1,0,1]  R205      6.2084991484880447e-02
    z[1,0,1]  R206      -1.1389282345771790e-01
    z[1,0,1]  R207      1.4568357169628143e-01
    z[1,0,1]  R208      -0.0789308175444603
    z[1,0,1]  R209      -3.2679599523544312e-01
    z[1,0,1]  R210      5.8238863945007324e-01
    z[1,0,1]  R211      3.8293415307998657e-01
    z[1,0,1]  R212      -8.1575781106948853e-01
    z[1,0,1]  R213      -7.2446751594543457e-01
    z[1,0,1]  R214      -2.1643690764904022e-01
    z[1,0,1]  R215      -3.0542570352554321e-01
    z[1,0,1]  R216      -2.4331867694854736e-01
    z[1,0,1]  R217      -2.3857049643993378e-01
    z[1,0,1]  R218      -2.2109535336494446e-01
    z[1,0,1]  R219      -2.5237387418746948e-01
    z[1,0,1]  R220      5.4887527227401733e-01
    z[1,0,1]  R221      -0.756986141204834
    z[1,0,1]  R222      -2.5298237800598145e-01
    z[1,0,1]  R223      -0.319732129573822
    z[1,0,1]  R224      -4.1124969720840454e-01
    z[1,0,1]  R225      -3.0991527438163757e-01
    z[1,0,1]  R226      -4.4507080316543579e-01
    z[1,0,1]  R227      -2.6714438199996948e-01
    z[1,0,1]  R228      -7.5146359205245972e-01
    z[1,0,1]  R229      -3.3937805891036987e-01
    z[1,0,1]  R230      9.6793889999389648e-02
    z[1,0,1]  R231      9.5467088976874948e-04
    z[1,0,1]  R232      4.4080372899770737e-02
    z[1,0,1]  R233      3.8586426526308060e-02
    z[1,0,1]  R234      3.5572454333305359e-02
    z[1,0,1]  R235      7.6472297310829163e-02
    z[1,0,1]  R236      5.3024303168058395e-02
    z[1,0,1]  R237      4.7504503279924393e-02
    z[1,0,1]  R238      7.1272291243076324e-02
    z[1,0,1]  R239      -1.6442860662937164e-01
    z[1,0,1]  R240      2.6647645235061646e-01
    z[1,0,1]  R241      -5.1985198259353638e-01
    z[1,0,1]  R242      -1.8105420470237732e-01
    z[1,0,1]  R243      -5.4912024736404419e-01
    z[1,0,1]  R244      -6.2785738706588745e-01
    z[1,0,1]  R245      -3.5683214664459229e-01
    z[1,0,1]  R246      1.5637357532978058e-01
    z[1,0,1]  R247      -3.4449872374534607e-01
    z[1,0,1]  R248      -3.8743022084236145e-01
    z[1,0,1]  R249      -1.1335832625627518e-01
    z[1,0,1]  R250      8.7743246555328369e-01
    z[1,0,1]  R251      7.4273413419723511e-01
    z[1,0,1]  R252      -6.8861061334609985e-01
    z[1,0,1]  R253      -5.6328219175338745e-01
    z[1,0,1]  R254      -5.7809185981750488e-01
    z[1,0,1]  R255      -5.1152777671813965e-01
    z[1,0,1]  R256      -5.5766272544860840e-01
    z[1,0,1]  R257      -7.1173429489135742e-02
    z[1,0,1]  R258      -8.6887432262301445e-03
    z[1,0,1]  R259      -4.6204483509063721e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R180      -1
    z[1,0,2]  R181      1
    z[1,0,2]  R190      -3.4188345074653625e-01
    z[1,0,2]  R191      1.6730089485645294e-01
    z[1,0,2]  R192      -3.2735043764114380e-01
    z[1,0,2]  R193      -1.1577780544757843e-01
    z[1,0,2]  R194      0.0608777217566967
    z[1,0,2]  R195      -4.4989970326423645e-01
    z[1,0,2]  R196      -6.7227369546890259e-01
    z[1,0,2]  R197      -4.3394207954406738e-01
    z[1,0,2]  R198      9.9671795964241028e-02
    z[1,0,2]  R199      -9.5330648124217987e-02
    z[1,0,2]  R200      6.7910069227218628e-01
    z[1,0,2]  R201      1.8427358567714691e-01
    z[1,0,2]  R202      3.8594490289688110e-01
    z[1,0,2]  R203      -1.6113594756461680e-04
    z[1,0,2]  R204      4.3455675244331360e-01
    z[1,0,2]  R205      2.2913278639316559e-01
    z[1,0,2]  R206      4.1522794961929321e-01
    z[1,0,2]  R207      4.0534734725952148e-01
    z[1,0,2]  R208      3.4077703952789307e-01
    z[1,0,2]  R209      2.7540290355682373e-01
    z[1,0,2]  R210      -0.0981765165925026
    z[1,0,2]  R211      -1.3510827720165253e-01
    z[1,0,2]  R212      1.9192628562450409e-02
    z[1,0,2]  R213      0.0211052056401968
    z[1,0,2]  R214      -0.00716095557436347
    z[1,0,2]  R215      -2.5757923722267151e-01
    z[1,0,2]  R216      2.5159388780593872e-01
    z[1,0,2]  R217      4.9874968826770782e-02
    z[1,0,2]  R218      1.4634981751441956e-01
    z[1,0,2]  R219      1.1708619445562363e-01
    z[1,0,2]  R220      4.4962030649185181e-01
    z[1,0,2]  R221      -1.3260406255722046e-01
    z[1,0,2]  R222      -4.1260927915573120e-02
    z[1,0,2]  R223      -2.3052366077899933e-01
    z[1,0,2]  R224      -4.2285788804292679e-02
    z[1,0,2]  R225      9.9219158291816711e-02
    z[1,0,2]  R226      2.9561412334442139e-01
    z[1,0,2]  R227      2.1575149893760681e-01
    z[1,0,2]  R228      2.2460678592324257e-02
    z[1,0,2]  R229      -3.4787702560424805e-01
    z[1,0,2]  R230      6.4283972978591919e-01
    z[1,0,2]  R231      2.3409101366996765e-01
    z[1,0,2]  R232      2.7970978617668152e-01
    z[1,0,2]  R233      3.0148291587829590e-01
    z[1,0,2]  R234      0.496791809797287
    z[1,0,2]  R235      5.2066934108734131e-01
    z[1,0,2]  R236      4.2420539259910583e-01
    z[1,0,2]  R237      4.7645160555839539e-01
    z[1,0,2]  R238      2.7403315901756287e-01
    z[1,0,2]  R239      -4.6178337931632996e-01
    z[1,0,2]  R240      -1.3109797239303589e-01
    z[1,0,2]  R241      5.8739078044891357e-01
    z[1,0,2]  R242      2.1813666820526123e-01
    z[1,0,2]  R243      -2.7783304452896118e-01
    z[1,0,2]  R244      -2.8996571898460388e-01
    z[1,0,2]  R245      -5.2452516555786133e-01
    z[1,0,2]  R246      -0.766013503074646
    z[1,0,2]  R247      -2.6005801558494568e-01
    z[1,0,2]  R248      -3.7955591082572937e-01
    z[1,0,2]  R249      -5.3356665372848511e-01
    z[1,0,2]  R250      -1.0671491920948029e-01
    z[1,0,2]  R251      -2.4845926463603973e-01
    z[1,0,2]  R252      1.1095648258924484e-01
    z[1,0,2]  R253      -5.9024691581726074e-02
    z[1,0,2]  R254      -1.1720573902130127e-01
    z[1,0,2]  R255      3.5954797267913818e-01
    z[1,0,2]  R256      -1.7758095264434814e-01
    z[1,0,2]  R257      8.2312017679214478e-01
    z[1,0,2]  R258      5.6279665231704712e-01
    z[1,0,2]  R259      6.3541257381439209e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R182      -1
    z[1,0,3]  R183      1
    z[1,0,3]  R190      4.9243035912513733e-01
    z[1,0,3]  R191      5.0554656982421875e-01
    z[1,0,3]  R192      5.1138144731521606e-01
    z[1,0,3]  R193      3.3378553390502930e-01
    z[1,0,3]  R194      -1.8854171037673950e-01
    z[1,0,3]  R195      -1.4253887534141541e-01
    z[1,0,3]  R196      2.4872681498527527e-01
    z[1,0,3]  R197      2.1641846746206284e-02
    z[1,0,3]  R198      -1.9361507892608643e-01
    z[1,0,3]  R199      -4.4752854108810425e-01
    z[1,0,3]  R200      -4.4447034597396851e-02
    z[1,0,3]  R201      -5.2434122562408447e-01
    z[1,0,3]  R202      -3.5095199942588806e-01
    z[1,0,3]  R203      -3.1402194499969482e-01
    z[1,0,3]  R204      -3.2981792092323303e-01
    z[1,0,3]  R205      -2.9031160473823547e-01
    z[1,0,3]  R206      -5.5152559280395508e-01
    z[1,0,3]  R207      -1.7999365925788879e-01
    z[1,0,3]  R208      -0.319568932056427
    z[1,0,3]  R209      -0.0645049586892128
    z[1,0,3]  R210      -6.5557742118835449e-01
    z[1,0,3]  R211      -1.2081279419362545e-02
    z[1,0,3]  R212      -0.0806296318769455
    z[1,0,3]  R213      -1.9459196925163269e-01
    z[1,0,3]  R214      -6.4039933681488037e-01
    z[1,0,3]  R215      -4.7206792235374451e-01
    z[1,0,3]  R216      -3.4568536281585693e-01
    z[1,0,3]  R217      -2.2869020700454712e-01
    z[1,0,3]  R218      -4.5102012157440186e-01
    z[1,0,3]  R219      2.3547211661934853e-02
    z[1,0,3]  R220      -2.1843446791172028e-01
    z[1,0,3]  R221      3.8228464126586914e-01
    z[1,0,3]  R222      -2.4428358674049377e-01
    z[1,0,3]  R223      -3.6610227823257446e-01
    z[1,0,3]  R224      -7.9962633550167084e-02
    z[1,0,3]  R225      -4.3234610557556152e-01
    z[1,0,3]  R226      -4.3659138679504395e-01
    z[1,0,3]  R227      -4.0801870822906494e-01
    z[1,0,3]  R228      -3.2905688881874084e-01
    z[1,0,3]  R229      -4.3137919902801514e-01
    z[1,0,3]  R230      -1.2030338868498802e-02
    z[1,0,3]  R231      7.1206682920455933e-01
    z[1,0,3]  R232      4.6227118372917175e-01
    z[1,0,3]  R233      4.6484208106994629e-01
    z[1,0,3]  R234      1.7022161185741425e-01
    z[1,0,3]  R235      -3.9080867171287537e-01
    z[1,0,3]  R236      -2.2143563628196716e-01
    z[1,0,3]  R237      -3.1327739357948303e-01
    z[1,0,3]  R238      -1.8965117633342743e-01
    z[1,0,3]  R239      4.0039411187171936e-01
    z[1,0,3]  R240      -2.8232035040855408e-01
    z[1,0,3]  R241      -7.3677316308021545e-02
    z[1,0,3]  R242      -2.8459736704826355e-01
    z[1,0,3]  R243      -5.1777446269989014e-01
    z[1,0,3]  R244      -2.0285290479660034e-01
    z[1,0,3]  R245      -6.5406644344329834e-01
    z[1,0,3]  R246      -3.8228946924209595e-01
    z[1,0,3]  R247      7.9646319150924683e-02
    z[1,0,3]  R248      2.0401114225387573e-01
    z[1,0,3]  R249      -0.0553707480430603
    z[1,0,3]  R250      -1.2512814998626709e-01
    z[1,0,3]  R251      2.2900892794132233e-01
    z[1,0,3]  R252      -1.9740380346775055e-01
    z[1,0,3]  R253      -2.7225196361541748e-01
    z[1,0,3]  R254      -4.1527125239372253e-01
    z[1,0,3]  R255      2.8835743665695190e-01
    z[1,0,3]  R256      -2.7360485401004553e-03
    z[1,0,3]  R257      -1.1131959408521652e-01
    z[1,0,3]  R258      1.2222599983215332e-01
    z[1,0,3]  R259      -1.0076513141393661e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R184      -1
    z[1,0,4]  R185      1
    z[1,0,4]  R190      -4.7869235277175903e-01
    z[1,0,4]  R191      -0.353411465883255
    z[1,0,4]  R192      2.1292430162429810e-01
    z[1,0,4]  R193      5.5049387738108635e-03
    z[1,0,4]  R194      -4.8308354616165161e-01
    z[1,0,4]  R195      -5.2213305234909058e-01
    z[1,0,4]  R196      1.1937224864959717e-01
    z[1,0,4]  R197      1.5014718472957611e-01
    z[1,0,4]  R198      -6.3855779170989990e-01
    z[1,0,4]  R199      -5.8134567737579346e-01
    z[1,0,4]  R200      1.7674861848354340e-01
    z[1,0,4]  R201      1.7360825836658478e-01
    z[1,0,4]  R202      1.3603407144546509e-01
    z[1,0,4]  R203      2.2222118079662323e-01
    z[1,0,4]  R204      4.4917544722557068e-01
    z[1,0,4]  R205      4.6200191974639893e-01
    z[1,0,4]  R206      -1.6582775115966797e-01
    z[1,0,4]  R207      4.5760747790336609e-01
    z[1,0,4]  R208      -2.6043057441711426e-01
    z[1,0,4]  R209      -1.2828649580478668e-01
    z[1,0,4]  R210      3.2459726929664612e-01
    z[1,0,4]  R211      1.5240977704524994e-01
    z[1,0,4]  R212      -2.9337859153747559e-01
    z[1,0,4]  R213      -1.7532658576965332e-01
    z[1,0,4]  R214      -1.3813933730125427e-01
    z[1,0,4]  R215      -2.4399299919605255e-01
    z[1,0,4]  R216      -1.8310281634330750e-01
    z[1,0,4]  R217      -4.3905708193778992e-01
    z[1,0,4]  R218      -3.6279231309890747e-01
    z[1,0,4]  R219      -1.6562348604202271e-01
    z[1,0,4]  R220      1.3291072845458984e-01
    z[1,0,4]  R221      -4.0647846460342407e-01
    z[1,0,4]  R222      3.4199748188257217e-02
    z[1,0,4]  R223      7.8203096985816956e-02
    z[1,0,4]  R224      -1.6141681373119354e-01
    z[1,0,4]  R225      -1.0343640297651291e-01
    z[1,0,4]  R226      -1.0888533294200897e-01
    z[1,0,4]  R227      -2.6009339094161987e-01
    z[1,0,4]  R228      -6.3789568841457367e-02
    z[1,0,4]  R229      -1.9778449833393097e-01
    z[1,0,4]  R230      -3.5819873213768005e-01
    z[1,0,4]  R231      8.4051378071308136e-02
    z[1,0,4]  R232      8.7837286293506622e-02
    z[1,0,4]  R233      -5.7816648483276367e-01
    z[1,0,4]  R234      -3.6483651399612427e-01
    z[1,0,4]  R235      2.0078261196613312e-01
    z[1,0,4]  R236      1.1413767933845520e-01
    z[1,0,4]  R237      -3.7626230716705322e-01
    z[1,0,4]  R238      -9.2131003737449646e-02
    z[1,0,4]  R239      1.4716595411300659e-01
    z[1,0,4]  R240      6.9416522979736328e-01
    z[1,0,4]  R241      1.3592466711997986e-01
    z[1,0,4]  R242      3.6502486467361450e-01
    z[1,0,4]  R243      -4.6036940813064575e-01
    z[1,0,4]  R244      7.7058456838130951e-02
    z[1,0,4]  R245      -3.0732330679893494e-01
    z[1,0,4]  R246      -3.5659581422805786e-01
    z[1,0,4]  R247      -5.9570330381393433e-01
    z[1,0,4]  R248      -3.5770753026008606e-01
    z[1,0,4]  R249      -1.8804828822612762e-01
    z[1,0,4]  R250      -1.5170462429523468e-01
    z[1,0,4]  R251      3.0439239740371704e-01
    z[1,0,4]  R252      2.2947153449058533e-01
    z[1,0,4]  R253      1.3315358757972717e-01
    z[1,0,4]  R254      -0.309390664100647
    z[1,0,4]  R255      2.5706894695758820e-02
    z[1,0,4]  R256      4.2895305156707764e-01
    z[1,0,4]  R257      5.7034876197576523e-02
    z[1,0,4]  R258      -3.9720979332923889e-01
    z[1,0,4]  R259      3.2676732540130615e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R186      -1
    z[1,0,5]  R187      1
    z[1,0,5]  R190      -2.0041167736053467e-01
    z[1,0,5]  R191      -4.3665367364883423e-01
    z[1,0,5]  R192      -2.8782343864440918e-01
    z[1,0,5]  R193      -6.0278022289276123e-01
    z[1,0,5]  R194      -0.566609799861908
    z[1,0,5]  R195      -0.28685262799263
    z[1,0,5]  R196      1.5974249690771103e-02
    z[1,0,5]  R197      -3.0622237920761108e-01
    z[1,0,5]  R198      -8.5659280419349670e-02
    z[1,0,5]  R199      -9.4244204461574554e-02
    z[1,0,5]  R200      3.6924883723258972e-01
    z[1,0,5]  R201      9.4708538381382823e-04
    z[1,0,5]  R202      -0.0814613625407219
    z[1,0,5]  R203      -3.5854384303092957e-01
    z[1,0,5]  R204      -1.4186948537826538e-01
    z[1,0,5]  R205      9.6284836530685425e-02
    z[1,0,5]  R206      1.4110732078552246e-01
    z[1,0,5]  R207      4.8242881894111633e-03
    z[1,0,5]  R208      -0.0749167948961258
    z[1,0,5]  R209      2.7209895849227905e-01
    z[1,0,5]  R210      1.9273126125335693e-01
    z[1,0,5]  R211      7.6943945884704590e-01
    z[1,0,5]  R212      -4.8499464988708496e-02
    z[1,0,5]  R213      -2.7498283982276917e-01
    z[1,0,5]  R214      -3.4907805919647217e-01
    z[1,0,5]  R215      2.7364954352378845e-01
    z[1,0,5]  R216      -4.0097177028656006e-01
    z[1,0,5]  R217      -1.1034757643938065e-01
    z[1,0,5]  R218      0.32767453789711
    z[1,0,5]  R219      -3.4630617592483759e-03
    z[1,0,5]  R220      1.9378204643726349e-01
    z[1,0,5]  R221      -2.3140968382358551e-01
    z[1,0,5]  R222      2.0276030898094177e-01
    z[1,0,5]  R223      -2.6396793127059937e-01
    z[1,0,5]  R224      -5.3916919976472855e-02
    z[1,0,5]  R225      1.4100360684096813e-02
    z[1,0,5]  R226      1.1793158203363419e-01
    z[1,0,5]  R227      -1.5098898112773895e-01
    z[1,0,5]  R228      -3.3523935079574585e-01
    z[1,0,5]  R229      -1.8744681775569916e-01
    z[1,0,5]  R230      -1.2088346481323242e-01
    z[1,0,5]  R231      -6.2800031900405884e-01
    z[1,0,5]  R232      -4.0164360404014587e-01
    z[1,0,5]  R233      -1.0383608937263489e-01
    z[1,0,5]  R234      -5.4557675123214722e-01
    z[1,0,5]  R235      -4.5615857839584351e-01
    z[1,0,5]  R236      1.4392022788524628e-01
    z[1,0,5]  R237      2.1801939606666565e-01
    z[1,0,5]  R238      -6.6552406549453735e-01
    z[1,0,5]  R239      -1.0773006826639175e-01
    z[1,0,5]  R240      4.6527001261711121e-01
    z[1,0,5]  R241      4.7618106007575989e-01
    z[1,0,5]  R242      5.6284952163696289e-01
    z[1,0,5]  R243      -2.9629451036453247e-01
    z[1,0,5]  R244      -5.6557911634445190e-01
    z[1,0,5]  R245      8.1596568226814270e-02
    z[1,0,5]  R246      -2.2623999416828156e-01
    z[1,0,5]  R247      1.2408995628356934e-01
    z[1,0,5]  R248      -7.9403780400753021e-03
    z[1,0,5]  R249      -6.2764868140220642e-02
    z[1,0,5]  R250      2.8822100162506104e-01
    z[1,0,5]  R251      3.8251818623393774e-03
    z[1,0,5]  R252      1.7396403709426522e-03
    z[1,0,5]  R253      3.5765978693962097e-01
    z[1,0,5]  R254      2.7456291019916534e-02
    z[1,0,5]  R255      1.7912285029888153e-01
    z[1,0,5]  R256      7.6556608080863953e-02
    z[1,0,5]  R257      1.4506430923938751e-01
    z[1,0,5]  R258      -2.1472917497158051e-01
    z[1,0,5]  R259      -1.7509551346302032e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R188      -1
    z[1,0,6]  R189      1
    z[1,0,6]  R190      -1.9053514301776886e-01
    z[1,0,6]  R191      1.1832785606384277e-01
    z[1,0,6]  R192      4.3967801332473755e-01
    z[1,0,6]  R193      -4.8423612117767334e-01
    z[1,0,6]  R194      1.9352915883064270e-01
    z[1,0,6]  R195      3.6890518665313721e-01
    z[1,0,6]  R196      -5.7547432184219360e-01
    z[1,0,6]  R197      3.2123643904924393e-02
    z[1,0,6]  R198      -9.8000364378094673e-03
    z[1,0,6]  R199      -1.5896634757518768e-01
    z[1,0,6]  R200      -1.9087785482406616e-01
    z[1,0,6]  R201      -1.7828333377838135e-01
    z[1,0,6]  R202      3.5070598125457764e-02
    z[1,0,6]  R203      -6.7103527486324310e-02
    z[1,0,6]  R204      6.6242665052413940e-02
    z[1,0,6]  R205      -1.4694066345691681e-01
    z[1,0,6]  R206      1.8468730151653290e-02
    z[1,0,6]  R207      2.0318174362182617e-01
    z[1,0,6]  R208      -1.7295676469802856e-01
    z[1,0,6]  R209      -1.7953509092330933e-01
    z[1,0,6]  R210      2.5688254833221436e-01
    z[1,0,6]  R211      4.6851357817649841e-01
    z[1,0,6]  R212      2.4432139098644257e-01
    z[1,0,6]  R213      4.8920312523841858e-01
    z[1,0,6]  R214      -1.7767407000064850e-02
    z[1,0,6]  R215      0.0679338276386261
    z[1,0,6]  R216      -1.4336473308503628e-02
    z[1,0,6]  R217      5.0678491592407227e-02
    z[1,0,6]  R218      -1.5902754664421082e-01
    z[1,0,6]  R219      2.6732046157121658e-02
    z[1,0,6]  R220      -6.2585294246673584e-01
    z[1,0,6]  R221      -4.8738211393356323e-02
    z[1,0,6]  R222      -1.0014757513999939e-01
    z[1,0,6]  R223      -1.3742519915103912e-01
    z[1,0,6]  R224      -1.5722940862178802e-01
    z[1,0,6]  R225      3.9180129766464233e-01
    z[1,0,6]  R226      -1.4284999668598175e-01
    z[1,0,6]  R227      2.2878804802894592e-01
    z[1,0,6]  R228      -1.3638909161090851e-01
    z[1,0,6]  R229      -5.5600155144929886e-02
    z[1,0,6]  R230      0.654710054397583
    z[1,0,6]  R231      1.1131328344345093e-01
    z[1,0,6]  R232      -6.2751924991607666e-01
    z[1,0,6]  R233      -1.0582274943590164e-01
    z[1,0,6]  R234      -2.8403052687644958e-01
    z[1,0,6]  R235      -1.4015206135809422e-02
    z[1,0,6]  R236      -4.1147151589393616e-01
    z[1,0,6]  R237      -0.648550808429718
    z[1,0,6]  R238      -3.8981980085372925e-01
    z[1,0,6]  R239      6.3916943967342377e-02
    z[1,0,6]  R240      8.4687858819961548e-02
    z[1,0,6]  R241      2.7854385972023010e-01
    z[1,0,6]  R242      -4.9943429231643677e-01
    z[1,0,6]  R243      1.9908805191516876e-01
    z[1,0,6]  R244      3.9190784096717834e-01
    z[1,0,6]  R245      1.1957976222038269e-01
    z[1,0,6]  R246      2.2648532688617706e-01
    z[1,0,6]  R247      -1.2779808603227139e-02
    z[1,0,6]  R248      2.8644669055938721e-01
    z[1,0,6]  R249      3.7128555774688721e-01
    z[1,0,6]  R250      1.8244867026805878e-01
    z[1,0,6]  R251      -1.1804796010255814e-01
    z[1,0,6]  R252      -2.8831705451011658e-01
    z[1,0,6]  R253      -6.0568958520889282e-02
    z[1,0,6]  R254      -0.190096914768219
    z[1,0,6]  R255      5.9414887428283691e-01
    z[1,0,6]  R256      6.4565908908843994e-01
    z[1,0,6]  R257      -2.3918978869915009e-02
    z[1,0,6]  R258      4.1156476736068726e-01
    z[1,0,6]  R259      1.8318559229373932e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R260      -1
    z[0,5,0]  R261      1
    z[0,5,0]  R274      -7.5358949601650238e-02
    z[0,5,0]  R275      1.5595360100269318e-01
    z[0,5,0]  R276      3.7856489419937134e-01
    z[0,5,0]  R277      5.7903724908828735e-01
    z[0,5,0]  R278      4.5991745591163635e-01
    z[0,5,0]  R279      5.6721532344818115e-01
    z[0,5,0]  R280      7.5176799297332764e-01
    z[0,5,0]  R281      2.5073993206024170e-01
    z[0,5,0]  R282      -5.2961182594299316e-01
    z[0,5,0]  R283      7.4970316886901855e-01
    z[0,5,0]  R284      -3.5578823089599609e-01
    z[0,5,0]  R285      2.3767025768756866e-01
    z[0,5,0]  R286      3.7304529547691345e-01
    z[0,5,0]  R287      1.1755401641130447e-01
    z[0,5,0]  R288      -3.4004725515842438e-02
    z[0,5,0]  R289      2.3310141265392303e-01
    z[0,5,0]  R290      -1.1395020037889481e-01
    z[0,5,0]  R291      -6.6100138425827026e-01
    z[0,5,0]  R292      -6.7390298843383789e-01
    z[0,5,0]  R293      -7.2265905141830444e-01
    z[0,5,0]  R294      2.5237640738487244e-01
    z[0,5,0]  R295      -4.7703701257705688e-01
    z[0,5,0]  R296      5.8202129602432251e-01
    z[0,5,0]  R297      6.7512148618698120e-01
    z[0,5,0]  R298      5.8907490968704224e-01
    z[0,5,0]  R299      3.7437388300895691e-01
    z[0,5,0]  R300      2.2523894906044006e-01
    z[0,5,0]  R301      -5.2928882837295532e-01
    z[0,5,0]  R302      -5.4311645030975342e-01
    z[0,5,0]  R303      -0.449020653963089
    z[0,5,0]  R304      3.8353410363197327e-01
    z[0,5,0]  R305      7.2871428728103638e-01
    z[0,5,0]  R306      -0.573577880859375
    z[0,5,0]  R307      3.9125624299049377e-01
    z[0,5,0]  R308      -1.3802585005760193e-01
    z[0,5,0]  R309      -2.3197303712368011e-01
    z[0,5,0]  R310      -2.4491387605667114e-01
    z[0,5,0]  R311      -4.3502193689346313e-01
    z[0,5,0]  R312      1.7371350526809692e-01
    z[0,5,0]  R313      -3.4387665987014771e-01
    z[0,5,0]  R314      -2.6275321841239929e-01
    z[0,5,0]  R315      -2.6834350824356079e-01
    z[0,5,0]  R316      -1.1733414977788925e-01
    z[0,5,0]  R317      0.690343976020813
    z[0,5,0]  R318      -2.4170331656932831e-02
    z[0,5,0]  R319      -3.2999888062477112e-01
    z[0,5,0]  R320      5.5536341667175293e-01
    z[0,5,0]  R321      -1.2703700363636017e-01
    z[0,5,0]  R322      -5.0177562236785889e-01
    z[0,5,0]  R323      6.4959245920181274e-01
    z[0,5,0]  R324      5.0342237949371338e-01
    z[0,5,0]  R325      4.5965763926506042e-01
    z[0,5,0]  R326      -2.5962987542152405e-01
    z[0,5,0]  R327      6.8999834358692169e-02
    z[0,5,0]  R328      6.7577803134918213e-01
    z[0,5,0]  R329      6.9911277294158936e-01
    z[0,5,0]  R330      -5.1434552669525146e-01
    z[0,5,0]  R331      2.6208099722862244e-01
    z[0,5,0]  R332      2.0925863087177277e-01
    z[0,5,0]  R333      1.6149304807186127e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R262      -1
    z[0,5,1]  R263      1
    z[0,5,1]  R274      9.6793889999389648e-02
    z[0,5,1]  R275      9.5467088976874948e-04
    z[0,5,1]  R276      4.4080372899770737e-02
    z[0,5,1]  R277      3.8586426526308060e-02
    z[0,5,1]  R278      3.5572454333305359e-02
    z[0,5,1]  R279      7.6472297310829163e-02
    z[0,5,1]  R280      5.3024303168058395e-02
    z[0,5,1]  R281      4.7504503279924393e-02
    z[0,5,1]  R282      7.1272291243076324e-02
    z[0,5,1]  R283      -1.6442860662937164e-01
    z[0,5,1]  R284      2.6647645235061646e-01
    z[0,5,1]  R285      -5.1985198259353638e-01
    z[0,5,1]  R286      -1.8105420470237732e-01
    z[0,5,1]  R287      -5.4912024736404419e-01
    z[0,5,1]  R288      -6.2785738706588745e-01
    z[0,5,1]  R289      -3.5683214664459229e-01
    z[0,5,1]  R290      1.5637357532978058e-01
    z[0,5,1]  R291      -3.4449872374534607e-01
    z[0,5,1]  R292      -3.8743022084236145e-01
    z[0,5,1]  R293      -1.1335832625627518e-01
    z[0,5,1]  R294      8.7743246555328369e-01
    z[0,5,1]  R295      7.4273413419723511e-01
    z[0,5,1]  R296      -6.8861061334609985e-01
    z[0,5,1]  R297      -5.6328219175338745e-01
    z[0,5,1]  R298      -5.7809185981750488e-01
    z[0,5,1]  R299      -5.1152777671813965e-01
    z[0,5,1]  R300      -5.5766272544860840e-01
    z[0,5,1]  R301      -7.1173429489135742e-02
    z[0,5,1]  R302      -8.6887432262301445e-03
    z[0,5,1]  R303      -4.6204483509063721e-01
    z[0,5,1]  R304      -7.3419380933046341e-03
    z[0,5,1]  R305      5.3780563175678253e-02
    z[0,5,1]  R306      1.8765892088413239e-01
    z[0,5,1]  R307      4.5511212944984436e-01
    z[0,5,1]  R308      4.3033209443092346e-01
    z[0,5,1]  R309      -7.2222399711608887e-01
    z[0,5,1]  R310      -8.4902030229568481e-01
    z[0,5,1]  R311      3.3304911851882935e-01
    z[0,5,1]  R312      -9.1955929994583130e-01
    z[0,5,1]  R313      -0.737914502620697
    z[0,5,1]  R314      -6.8057817220687866e-01
    z[0,5,1]  R315      8.9732962846755981e-01
    z[0,5,1]  R316      9.5527225732803345e-01
    z[0,5,1]  R317      2.4952462315559387e-01
    z[0,5,1]  R318      5.9687721729278564e-01
    z[0,5,1]  R319      5.2242338657379150e-01
    z[0,5,1]  R320      4.3589583039283752e-01
    z[0,5,1]  R321      5.0764840841293335e-01
    z[0,5,1]  R322      3.8382586836814880e-01
    z[0,5,1]  R323      -4.3060076236724854e-01
    z[0,5,1]  R324      -5.8626502752304077e-01
    z[0,5,1]  R325      -3.7644475698471069e-01
    z[0,5,1]  R326      1.6134172910824418e-03
    z[0,5,1]  R327      6.9854617118835449e-01
    z[0,5,1]  R328      -3.0914485454559326e-01
    z[0,5,1]  R329      -5.4646706581115723e-01
    z[0,5,1]  R330      -5.0603449344635010e-01
    z[0,5,1]  R331      -0.873330295085907
    z[0,5,1]  R332      -8.2788646221160889e-01
    z[0,5,1]  R333      -9.1456514596939087e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R264      -1
    z[0,5,2]  R265      1
    z[0,5,2]  R274      6.4283972978591919e-01
    z[0,5,2]  R275      2.3409101366996765e-01
    z[0,5,2]  R276      2.7970978617668152e-01
    z[0,5,2]  R277      3.0148291587829590e-01
    z[0,5,2]  R278      0.496791809797287
    z[0,5,2]  R279      5.2066934108734131e-01
    z[0,5,2]  R280      4.2420539259910583e-01
    z[0,5,2]  R281      4.7645160555839539e-01
    z[0,5,2]  R282      2.7403315901756287e-01
    z[0,5,2]  R283      -4.6178337931632996e-01
    z[0,5,2]  R284      -1.3109797239303589e-01
    z[0,5,2]  R285      5.8739078044891357e-01
    z[0,5,2]  R286      2.1813666820526123e-01
    z[0,5,2]  R287      -2.7783304452896118e-01
    z[0,5,2]  R288      -2.8996571898460388e-01
    z[0,5,2]  R289      -5.2452516555786133e-01
    z[0,5,2]  R290      -0.766013503074646
    z[0,5,2]  R291      -2.6005801558494568e-01
    z[0,5,2]  R292      -3.7955591082572937e-01
    z[0,5,2]  R293      -5.3356665372848511e-01
    z[0,5,2]  R294      -1.0671491920948029e-01
    z[0,5,2]  R295      -2.4845926463603973e-01
    z[0,5,2]  R296      1.1095648258924484e-01
    z[0,5,2]  R297      -5.9024691581726074e-02
    z[0,5,2]  R298      -1.1720573902130127e-01
    z[0,5,2]  R299      3.5954797267913818e-01
    z[0,5,2]  R300      -1.7758095264434814e-01
    z[0,5,2]  R301      8.2312017679214478e-01
    z[0,5,2]  R302      5.6279665231704712e-01
    z[0,5,2]  R303      6.3541257381439209e-01
    z[0,5,2]  R304      5.8386647142469883e-03
    z[0,5,2]  R305      -5.0252193212509155e-01
    z[0,5,2]  R306      1.7684674263000488e-01
    z[0,5,2]  R307      -4.3406879901885986e-01
    z[0,5,2]  R308      -6.0438215732574463e-01
    z[0,5,2]  R309      -3.4850567579269409e-01
    z[0,5,2]  R310      -3.3150726556777954e-01
    z[0,5,2]  R311      -5.6343829631805420e-01
    z[0,5,2]  R312      -3.9096426218748093e-02
    z[0,5,2]  R313      2.4002294242382050e-01
    z[0,5,2]  R314      -0.611361563205719
    z[0,5,2]  R315      -1.1894062906503677e-01
    z[0,5,2]  R316      2.6409627869725227e-02
    z[0,5,2]  R317      6.1987121589481831e-03
    z[0,5,2]  R318      1.1879008263349533e-01
    z[0,5,2]  R319      5.3941982984542847e-01
    z[0,5,2]  R320      -8.7805025279521942e-02
    z[0,5,2]  R321      6.1530423164367676e-01
    z[0,5,2]  R322      4.2060518264770508e-01
    z[0,5,2]  R323      -3.6346417665481567e-01
    z[0,5,2]  R324      -5.2179563045501709e-01
    z[0,5,2]  R325      -3.2189390063285828e-01
    z[0,5,2]  R326      8.4723389148712158e-01
    z[0,5,2]  R327      2.8638830780982971e-01
    z[0,5,2]  R328      -6.1005878448486328e-01
    z[0,5,2]  R329      -2.6746904850006104e-01
    z[0,5,2]  R330      -0.0676533430814743
    z[0,5,2]  R331      8.0158248543739319e-02
    z[0,5,2]  R332      5.9549078345298767e-02
    z[0,5,2]  R333      1.6035138070583344e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R266      -1
    z[0,5,3]  R267      1
    z[0,5,3]  R274      -1.2030338868498802e-02
    z[0,5,3]  R275      7.1206682920455933e-01
    z[0,5,3]  R276      4.6227118372917175e-01
    z[0,5,3]  R277      4.6484208106994629e-01
    z[0,5,3]  R278      1.7022161185741425e-01
    z[0,5,3]  R279      -3.9080867171287537e-01
    z[0,5,3]  R280      -2.2143563628196716e-01
    z[0,5,3]  R281      -3.1327739357948303e-01
    z[0,5,3]  R282      -1.8965117633342743e-01
    z[0,5,3]  R283      4.0039411187171936e-01
    z[0,5,3]  R284      -2.8232035040855408e-01
    z[0,5,3]  R285      -7.3677316308021545e-02
    z[0,5,3]  R286      -2.8459736704826355e-01
    z[0,5,3]  R287      -5.1777446269989014e-01
    z[0,5,3]  R288      -2.0285290479660034e-01
    z[0,5,3]  R289      -6.5406644344329834e-01
    z[0,5,3]  R290      -3.8228946924209595e-01
    z[0,5,3]  R291      7.9646319150924683e-02
    z[0,5,3]  R292      2.0401114225387573e-01
    z[0,5,3]  R293      -0.0553707480430603
    z[0,5,3]  R294      -1.2512814998626709e-01
    z[0,5,3]  R295      2.2900892794132233e-01
    z[0,5,3]  R296      -1.9740380346775055e-01
    z[0,5,3]  R297      -2.7225196361541748e-01
    z[0,5,3]  R298      -4.1527125239372253e-01
    z[0,5,3]  R299      2.8835743665695190e-01
    z[0,5,3]  R300      -2.7360485401004553e-03
    z[0,5,3]  R301      -1.1131959408521652e-01
    z[0,5,3]  R302      1.2222599983215332e-01
    z[0,5,3]  R303      -1.0076513141393661e-01
    z[0,5,3]  R304      8.0488091707229614e-01
    z[0,5,3]  R305      -3.6215326189994812e-01
    z[0,5,3]  R306      -2.9161635041236877e-01
    z[0,5,3]  R307      -1.8511785566806793e-01
    z[0,5,3]  R308      -1.4170631766319275e-01
    z[0,5,3]  R309      -3.8046240806579590e-01
    z[0,5,3]  R310      -5.8095515705645084e-03
    z[0,5,3]  R311      -8.5485443472862244e-02
    z[0,5,3]  R312      -2.1694874763488770e-01
    z[0,5,3]  R313      -9.1061845421791077e-02
    z[0,5,3]  R314      -1.4058266580104828e-01
    z[0,5,3]  R315      2.7991944551467896e-01
    z[0,5,3]  R316      6.6506855189800262e-02
    z[0,5,3]  R317      4.5748311281204224e-01
    z[0,5,3]  R318      3.5309907793998718e-01
    z[0,5,3]  R319      6.7494444549083710e-02
    z[0,5,3]  R320      4.4161457568407059e-02
    z[0,5,3]  R321      4.5583176612854004e-01
    z[0,5,3]  R322      4.5203980803489685e-01
    z[0,5,3]  R323      -1.9308102130889893e-01
    z[0,5,3]  R324      -1.1954199522733688e-01
    z[0,5,3]  R325      -3.7935337424278259e-01
    z[0,5,3]  R326      3.4658986330032349e-01
    z[0,5,3]  R327      5.6162470579147339e-01
    z[0,5,3]  R328      -1.8775951862335205e-01
    z[0,5,3]  R329      -1.1313343793153763e-01
    z[0,5,3]  R330      2.4873189628124237e-02
    z[0,5,3]  R331      0.0875496044754982
    z[0,5,3]  R332      -1.2553407251834869e-01
    z[0,5,3]  R333      -1.7480676993727684e-02
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R268      -1
    z[0,5,4]  R269      1
    z[0,5,4]  R274      -3.5819873213768005e-01
    z[0,5,4]  R275      8.4051378071308136e-02
    z[0,5,4]  R276      8.7837286293506622e-02
    z[0,5,4]  R277      -5.7816648483276367e-01
    z[0,5,4]  R278      -3.6483651399612427e-01
    z[0,5,4]  R279      2.0078261196613312e-01
    z[0,5,4]  R280      1.1413767933845520e-01
    z[0,5,4]  R281      -3.7626230716705322e-01
    z[0,5,4]  R282      -9.2131003737449646e-02
    z[0,5,4]  R283      1.4716595411300659e-01
    z[0,5,4]  R284      6.9416522979736328e-01
    z[0,5,4]  R285      1.3592466711997986e-01
    z[0,5,4]  R286      3.6502486467361450e-01
    z[0,5,4]  R287      -4.6036940813064575e-01
    z[0,5,4]  R288      7.7058456838130951e-02
    z[0,5,4]  R289      -3.0732330679893494e-01
    z[0,5,4]  R290      -3.5659581422805786e-01
    z[0,5,4]  R291      -5.9570330381393433e-01
    z[0,5,4]  R292      -3.5770753026008606e-01
    z[0,5,4]  R293      -1.8804828822612762e-01
    z[0,5,4]  R294      -1.5170462429523468e-01
    z[0,5,4]  R295      3.0439239740371704e-01
    z[0,5,4]  R296      2.2947153449058533e-01
    z[0,5,4]  R297      1.3315358757972717e-01
    z[0,5,4]  R298      -0.309390664100647
    z[0,5,4]  R299      2.5706894695758820e-02
    z[0,5,4]  R300      4.2895305156707764e-01
    z[0,5,4]  R301      5.7034876197576523e-02
    z[0,5,4]  R302      -3.9720979332923889e-01
    z[0,5,4]  R303      3.2676732540130615e-01
    z[0,5,4]  R304      1.9267193973064423e-01
    z[0,5,4]  R305      -2.5089371204376221e-01
    z[0,5,4]  R306      5.0921601057052612e-01
    z[0,5,4]  R307      -5.7260245084762573e-01
    z[0,5,4]  R308      5.1801240444183350e-01
    z[0,5,4]  R309      -1.7598392069339752e-01
    z[0,5,4]  R310      -2.3380665481090546e-01
    z[0,5,4]  R311      4.7376893460750580e-02
    z[0,5,4]  R312      2.6536622643470764e-01
    z[0,5,4]  R313      2.1654200553894043e-01
    z[0,5,4]  R314      2.4909342825412750e-01
    z[0,5,4]  R315      -0.0775151476264
    z[0,5,4]  R316      2.5572302937507629e-01
    z[0,5,4]  R317      -4.9793016910552979e-01
    z[0,5,4]  R318      -4.9561339616775513e-01
    z[0,5,4]  R319      -5.1052731275558472e-01
    z[0,5,4]  R320      -4.8252606391906738e-01
    z[0,5,4]  R321      -2.0163437724113464e-01
    z[0,5,4]  R322      -2.0760956406593323e-01
    z[0,5,4]  R323      5.1144324243068695e-02
    z[0,5,4]  R324      2.9054602980613708e-01
    z[0,5,4]  R325      3.7746012210845947e-01
    z[0,5,4]  R326      -8.3451956510543823e-02
    z[0,5,4]  R327      -3.3074009418487549e-01
    z[0,5,4]  R328      1.0776181519031525e-01
    z[0,5,4]  R329      -1.6035382449626923e-01
    z[0,5,4]  R330      0.302490234375
    z[0,5,4]  R331      3.8686412572860718e-01
    z[0,5,4]  R332      -1.8753142654895782e-01
    z[0,5,4]  R333      -7.1950078010559082e-02
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R270      -1
    z[0,5,5]  R271      1
    z[0,5,5]  R274      -1.2088346481323242e-01
    z[0,5,5]  R275      -6.2800031900405884e-01
    z[0,5,5]  R276      -4.0164360404014587e-01
    z[0,5,5]  R277      -1.0383608937263489e-01
    z[0,5,5]  R278      -5.4557675123214722e-01
    z[0,5,5]  R279      -4.5615857839584351e-01
    z[0,5,5]  R280      1.4392022788524628e-01
    z[0,5,5]  R281      2.1801939606666565e-01
    z[0,5,5]  R282      -6.6552406549453735e-01
    z[0,5,5]  R283      -1.0773006826639175e-01
    z[0,5,5]  R284      4.6527001261711121e-01
    z[0,5,5]  R285      4.7618106007575989e-01
    z[0,5,5]  R286      5.6284952163696289e-01
    z[0,5,5]  R287      -2.9629451036453247e-01
    z[0,5,5]  R288      -5.6557911634445190e-01
    z[0,5,5]  R289      8.1596568226814270e-02
    z[0,5,5]  R290      -2.2623999416828156e-01
    z[0,5,5]  R291      1.2408995628356934e-01
    z[0,5,5]  R292      -7.9403780400753021e-03
    z[0,5,5]  R293      -6.2764868140220642e-02
    z[0,5,5]  R294      2.8822100162506104e-01
    z[0,5,5]  R295      3.8251818623393774e-03
    z[0,5,5]  R296      1.7396403709426522e-03
    z[0,5,5]  R297      3.5765978693962097e-01
    z[0,5,5]  R298      2.7456291019916534e-02
    z[0,5,5]  R299      1.7912285029888153e-01
    z[0,5,5]  R300      7.6556608080863953e-02
    z[0,5,5]  R301      1.4506430923938751e-01
    z[0,5,5]  R302      -2.1472917497158051e-01
    z[0,5,5]  R303      -1.7509551346302032e-01
    z[0,5,5]  R304      1.0082848370075226e-01
    z[0,5,5]  R305      -7.8395850956439972e-02
    z[0,5,5]  R306      5.0746500492095947e-01
    z[0,5,5]  R307      -2.4189466238021851e-01
    z[0,5,5]  R308      -2.1659222245216370e-01
    z[0,5,5]  R309      -7.7802293002605438e-02
    z[0,5,5]  R310      -1.5291871130466461e-01
    z[0,5,5]  R311      -2.2871309518814087e-01
    z[0,5,5]  R312      -7.2227261960506439e-02
    z[0,5,5]  R313      8.4162920713424683e-02
    z[0,5,5]  R314      -7.6263256371021271e-02
    z[0,5,5]  R315      2.2961314767599106e-02
    z[0,5,5]  R316      2.7249900624155998e-02
    z[0,5,5]  R317      6.1988379806280136e-02
    z[0,5,5]  R318      2.1062639355659485e-01
    z[0,5,5]  R319      -1.4936427772045135e-01
    z[0,5,5]  R320      5.0663727521896362e-01
    z[0,5,5]  R321      3.1477779150009155e-01
    z[0,5,5]  R322      -1.0706861317157745e-01
    z[0,5,5]  R323      4.5557871460914612e-01
    z[0,5,5]  R324      -1.5782682597637177e-01
    z[0,5,5]  R325      2.0386941730976105e-01
    z[0,5,5]  R326      2.9360356926918030e-01
    z[0,5,5]  R327      1.3964110985398293e-02
    z[0,5,5]  R328      1.6813308000564575e-01
    z[0,5,5]  R329      2.7296161651611328e-01
    z[0,5,5]  R330      -4.2952352762222290e-01
    z[0,5,5]  R331      -0.0528470054268837
    z[0,5,5]  R332      -4.6429717540740967e-01
    z[0,5,5]  R333      -3.0102476477622986e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R272      -1
    z[0,5,6]  R273      1
    z[0,5,6]  R274      0.654710054397583
    z[0,5,6]  R275      1.1131328344345093e-01
    z[0,5,6]  R276      -6.2751924991607666e-01
    z[0,5,6]  R277      -1.0582274943590164e-01
    z[0,5,6]  R278      -2.8403052687644958e-01
    z[0,5,6]  R279      -1.4015206135809422e-02
    z[0,5,6]  R280      -4.1147151589393616e-01
    z[0,5,6]  R281      -0.648550808429718
    z[0,5,6]  R282      -3.8981980085372925e-01
    z[0,5,6]  R283      6.3916943967342377e-02
    z[0,5,6]  R284      8.4687858819961548e-02
    z[0,5,6]  R285      2.7854385972023010e-01
    z[0,5,6]  R286      -4.9943429231643677e-01
    z[0,5,6]  R287      1.9908805191516876e-01
    z[0,5,6]  R288      3.9190784096717834e-01
    z[0,5,6]  R289      1.1957976222038269e-01
    z[0,5,6]  R290      2.2648532688617706e-01
    z[0,5,6]  R291      -1.2779808603227139e-02
    z[0,5,6]  R292      2.8644669055938721e-01
    z[0,5,6]  R293      3.7128555774688721e-01
    z[0,5,6]  R294      1.8244867026805878e-01
    z[0,5,6]  R295      -1.1804796010255814e-01
    z[0,5,6]  R296      -2.8831705451011658e-01
    z[0,5,6]  R297      -6.0568958520889282e-02
    z[0,5,6]  R298      -0.190096914768219
    z[0,5,6]  R299      5.9414887428283691e-01
    z[0,5,6]  R300      6.4565908908843994e-01
    z[0,5,6]  R301      -2.3918978869915009e-02
    z[0,5,6]  R302      4.1156476736068726e-01
    z[0,5,6]  R303      1.8318559229373932e-01
    z[0,5,6]  R304      3.9710375666618347e-01
    z[0,5,6]  R305      1.1535238474607468e-01
    z[0,5,6]  R306      5.1537081599235535e-02
    z[0,5,6]  R307      -1.7527288198471069e-01
    z[0,5,6]  R308      -0.308473140001297
    z[0,5,6]  R309      3.4835276007652283e-01
    z[0,5,6]  R310      1.7663891613483429e-01
    z[0,5,6]  R311      0.566135585308075
    z[0,5,6]  R312      1.7517418600618839e-03
    z[0,5,6]  R313      4.6621233224868774e-01
    z[0,5,6]  R314      -7.9900383949279785e-02
    z[0,5,6]  R315      1.5412263572216034e-01
    z[0,5,6]  R316      -4.9296006560325623e-02
    z[0,5,6]  R317      7.5118844397366047e-03
    z[0,5,6]  R318      4.6299794316291809e-01
    z[0,5,6]  R319      -1.9924205541610718e-01
    z[0,5,6]  R320      4.8924211412668228e-02
    z[0,5,6]  R321      5.5955359712243080e-03
    z[0,5,6]  R322      4.0630626678466797e-01
    z[0,5,6]  R323      1.1427410691976547e-01
    z[0,5,6]  R324      -8.3497636020183563e-02
    z[0,5,6]  R325      4.6415582299232483e-01
    z[0,5,6]  R326      3.8634572178125381e-02
    z[0,5,6]  R327      -1.5741581097245216e-02
    z[0,5,6]  R328      -2.1139627322554588e-02
    z[0,5,6]  R329      1.6749539971351624e-01
    z[0,5,6]  R330      4.4518679380416870e-01
    z[0,5,6]  R331      -4.5397195965051651e-02
    z[0,5,6]  R332      -2.7749935165047646e-02
    z[0,5,6]  R333      1.2521874904632568e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R334      -1
    z[5,0,0]  R335      1
    z[5,0,0]  R348      -7.5358949601650238e-02
    z[5,0,0]  R349      1.5595360100269318e-01
    z[5,0,0]  R350      3.7856489419937134e-01
    z[5,0,0]  R351      4.5991745591163635e-01
    z[5,0,0]  R352      5.6721532344818115e-01
    z[5,0,0]  R353      3.8353410363197327e-01
    z[5,0,0]  R354      7.5176799297332764e-01
    z[5,0,0]  R355      2.5073993206024170e-01
    z[5,0,0]  R356      -5.2961182594299316e-01
    z[5,0,0]  R357      7.2871428728103638e-01
    z[5,0,0]  R358      -0.573577880859375
    z[5,0,0]  R359      3.9125624299049377e-01
    z[5,0,0]  R360      -1.3802585005760193e-01
    z[5,0,0]  R361      -2.3197303712368011e-01
    z[5,0,0]  R362      -2.4491387605667114e-01
    z[5,0,0]  R363      -4.3502193689346313e-01
    z[5,0,0]  R364      1.7371350526809692e-01
    z[5,0,0]  R365      -3.4387665987014771e-01
    z[5,0,0]  R366      -2.6275321841239929e-01
    z[5,0,0]  R367      -2.6834350824356079e-01
    z[5,0,0]  R368      -1.1733414977788925e-01
    z[5,0,0]  R369      0.690343976020813
    z[5,0,0]  R370      -2.4170331656932831e-02
    z[5,0,0]  R371      -3.2999888062477112e-01
    z[5,0,0]  R372      5.5536341667175293e-01
    z[5,0,0]  R373      -1.2703700363636017e-01
    z[5,0,0]  R374      -5.0177562236785889e-01
    z[5,0,0]  R375      6.4959245920181274e-01
    z[5,0,0]  R376      5.0342237949371338e-01
    z[5,0,0]  R377      4.5965763926506042e-01
    z[5,0,0]  R378      -2.5962987542152405e-01
    z[5,0,0]  R379      6.8999834358692169e-02
    z[5,0,0]  R380      6.7577803134918213e-01
    z[5,0,0]  R381      6.9911277294158936e-01
    z[5,0,0]  R382      -5.1434552669525146e-01
    z[5,0,0]  R383      2.6208099722862244e-01
    z[5,0,0]  R384      2.0925863087177277e-01
    z[5,0,0]  R385      1.6149304807186127e-01
    z[5,0,0]  R386      5.7903724908828735e-01
    z[5,0,0]  R387      7.4970316886901855e-01
    z[5,0,0]  R388      -3.5578823089599609e-01
    z[5,0,0]  R389      2.3767025768756866e-01
    z[5,0,0]  R390      3.7304529547691345e-01
    z[5,0,0]  R391      1.1755401641130447e-01
    z[5,0,0]  R392      -3.4004725515842438e-02
    z[5,0,0]  R393      2.3310141265392303e-01
    z[5,0,0]  R394      -1.1395020037889481e-01
    z[5,0,0]  R395      -6.6100138425827026e-01
    z[5,0,0]  R396      -6.7390298843383789e-01
    z[5,0,0]  R397      -7.2265905141830444e-01
    z[5,0,0]  R398      2.5237640738487244e-01
    z[5,0,0]  R399      -4.7703701257705688e-01
    z[5,0,0]  R400      5.8202129602432251e-01
    z[5,0,0]  R401      6.7512148618698120e-01
    z[5,0,0]  R402      5.8907490968704224e-01
    z[5,0,0]  R403      3.7437388300895691e-01
    z[5,0,0]  R404      2.2523894906044006e-01
    z[5,0,0]  R405      -5.2928882837295532e-01
    z[5,0,0]  R406      -5.4311645030975342e-01
    z[5,0,0]  R407      -0.449020653963089
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R336      -1
    z[5,0,1]  R337      1
    z[5,0,1]  R348      9.6793889999389648e-02
    z[5,0,1]  R349      9.5467088976874948e-04
    z[5,0,1]  R350      4.4080372899770737e-02
    z[5,0,1]  R351      3.5572454333305359e-02
    z[5,0,1]  R352      7.6472297310829163e-02
    z[5,0,1]  R353      -7.3419380933046341e-03
    z[5,0,1]  R354      5.3024303168058395e-02
    z[5,0,1]  R355      4.7504503279924393e-02
    z[5,0,1]  R356      7.1272291243076324e-02
    z[5,0,1]  R357      5.3780563175678253e-02
    z[5,0,1]  R358      1.8765892088413239e-01
    z[5,0,1]  R359      4.5511212944984436e-01
    z[5,0,1]  R360      4.3033209443092346e-01
    z[5,0,1]  R361      -7.2222399711608887e-01
    z[5,0,1]  R362      -8.4902030229568481e-01
    z[5,0,1]  R363      3.3304911851882935e-01
    z[5,0,1]  R364      -9.1955929994583130e-01
    z[5,0,1]  R365      -0.737914502620697
    z[5,0,1]  R366      -6.8057817220687866e-01
    z[5,0,1]  R367      8.9732962846755981e-01
    z[5,0,1]  R368      9.5527225732803345e-01
    z[5,0,1]  R369      2.4952462315559387e-01
    z[5,0,1]  R370      5.9687721729278564e-01
    z[5,0,1]  R371      5.2242338657379150e-01
    z[5,0,1]  R372      4.3589583039283752e-01
    z[5,0,1]  R373      5.0764840841293335e-01
    z[5,0,1]  R374      3.8382586836814880e-01
    z[5,0,1]  R375      -4.3060076236724854e-01
    z[5,0,1]  R376      -5.8626502752304077e-01
    z[5,0,1]  R377      -3.7644475698471069e-01
    z[5,0,1]  R378      1.6134172910824418e-03
    z[5,0,1]  R379      6.9854617118835449e-01
    z[5,0,1]  R380      -3.0914485454559326e-01
    z[5,0,1]  R381      -5.4646706581115723e-01
    z[5,0,1]  R382      -5.0603449344635010e-01
    z[5,0,1]  R383      -0.873330295085907
    z[5,0,1]  R384      -8.2788646221160889e-01
    z[5,0,1]  R385      -9.1456514596939087e-01
    z[5,0,1]  R386      3.8586426526308060e-02
    z[5,0,1]  R387      -1.6442860662937164e-01
    z[5,0,1]  R388      2.6647645235061646e-01
    z[5,0,1]  R389      -5.1985198259353638e-01
    z[5,0,1]  R390      -1.8105420470237732e-01
    z[5,0,1]  R391      -5.4912024736404419e-01
    z[5,0,1]  R392      -6.2785738706588745e-01
    z[5,0,1]  R393      -3.5683214664459229e-01
    z[5,0,1]  R394      1.5637357532978058e-01
    z[5,0,1]  R395      -3.4449872374534607e-01
    z[5,0,1]  R396      -3.8743022084236145e-01
    z[5,0,1]  R397      -1.1335832625627518e-01
    z[5,0,1]  R398      8.7743246555328369e-01
    z[5,0,1]  R399      7.4273413419723511e-01
    z[5,0,1]  R400      -6.8861061334609985e-01
    z[5,0,1]  R401      -5.6328219175338745e-01
    z[5,0,1]  R402      -5.7809185981750488e-01
    z[5,0,1]  R403      -5.1152777671813965e-01
    z[5,0,1]  R404      -5.5766272544860840e-01
    z[5,0,1]  R405      -7.1173429489135742e-02
    z[5,0,1]  R406      -8.6887432262301445e-03
    z[5,0,1]  R407      -4.6204483509063721e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R338      -1
    z[5,0,2]  R339      1
    z[5,0,2]  R348      6.4283972978591919e-01
    z[5,0,2]  R349      2.3409101366996765e-01
    z[5,0,2]  R350      2.7970978617668152e-01
    z[5,0,2]  R351      0.496791809797287
    z[5,0,2]  R352      5.2066934108734131e-01
    z[5,0,2]  R353      5.8386647142469883e-03
    z[5,0,2]  R354      4.2420539259910583e-01
    z[5,0,2]  R355      4.7645160555839539e-01
    z[5,0,2]  R356      2.7403315901756287e-01
    z[5,0,2]  R357      -5.0252193212509155e-01
    z[5,0,2]  R358      1.7684674263000488e-01
    z[5,0,2]  R359      -4.3406879901885986e-01
    z[5,0,2]  R360      -6.0438215732574463e-01
    z[5,0,2]  R361      -3.4850567579269409e-01
    z[5,0,2]  R362      -3.3150726556777954e-01
    z[5,0,2]  R363      -5.6343829631805420e-01
    z[5,0,2]  R364      -3.9096426218748093e-02
    z[5,0,2]  R365      2.4002294242382050e-01
    z[5,0,2]  R366      -0.611361563205719
    z[5,0,2]  R367      -1.1894062906503677e-01
    z[5,0,2]  R368      2.6409627869725227e-02
    z[5,0,2]  R369      6.1987121589481831e-03
    z[5,0,2]  R370      1.1879008263349533e-01
    z[5,0,2]  R371      5.3941982984542847e-01
    z[5,0,2]  R372      -8.7805025279521942e-02
    z[5,0,2]  R373      6.1530423164367676e-01
    z[5,0,2]  R374      4.2060518264770508e-01
    z[5,0,2]  R375      -3.6346417665481567e-01
    z[5,0,2]  R376      -5.2179563045501709e-01
    z[5,0,2]  R377      -3.2189390063285828e-01
    z[5,0,2]  R378      8.4723389148712158e-01
    z[5,0,2]  R379      2.8638830780982971e-01
    z[5,0,2]  R380      -6.1005878448486328e-01
    z[5,0,2]  R381      -2.6746904850006104e-01
    z[5,0,2]  R382      -0.0676533430814743
    z[5,0,2]  R383      8.0158248543739319e-02
    z[5,0,2]  R384      5.9549078345298767e-02
    z[5,0,2]  R385      1.6035138070583344e-01
    z[5,0,2]  R386      3.0148291587829590e-01
    z[5,0,2]  R387      -4.6178337931632996e-01
    z[5,0,2]  R388      -1.3109797239303589e-01
    z[5,0,2]  R389      5.8739078044891357e-01
    z[5,0,2]  R390      2.1813666820526123e-01
    z[5,0,2]  R391      -2.7783304452896118e-01
    z[5,0,2]  R392      -2.8996571898460388e-01
    z[5,0,2]  R393      -5.2452516555786133e-01
    z[5,0,2]  R394      -0.766013503074646
    z[5,0,2]  R395      -2.6005801558494568e-01
    z[5,0,2]  R396      -3.7955591082572937e-01
    z[5,0,2]  R397      -5.3356665372848511e-01
    z[5,0,2]  R398      -1.0671491920948029e-01
    z[5,0,2]  R399      -2.4845926463603973e-01
    z[5,0,2]  R400      1.1095648258924484e-01
    z[5,0,2]  R401      -5.9024691581726074e-02
    z[5,0,2]  R402      -1.1720573902130127e-01
    z[5,0,2]  R403      3.5954797267913818e-01
    z[5,0,2]  R404      -1.7758095264434814e-01
    z[5,0,2]  R405      8.2312017679214478e-01
    z[5,0,2]  R406      5.6279665231704712e-01
    z[5,0,2]  R407      6.3541257381439209e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R340      -1
    z[5,0,3]  R341      1
    z[5,0,3]  R348      -1.2030338868498802e-02
    z[5,0,3]  R349      7.1206682920455933e-01
    z[5,0,3]  R350      4.6227118372917175e-01
    z[5,0,3]  R351      1.7022161185741425e-01
    z[5,0,3]  R352      -3.9080867171287537e-01
    z[5,0,3]  R353      8.0488091707229614e-01
    z[5,0,3]  R354      -2.2143563628196716e-01
    z[5,0,3]  R355      -3.1327739357948303e-01
    z[5,0,3]  R356      -1.8965117633342743e-01
    z[5,0,3]  R357      -3.6215326189994812e-01
    z[5,0,3]  R358      -2.9161635041236877e-01
    z[5,0,3]  R359      -1.8511785566806793e-01
    z[5,0,3]  R360      -1.4170631766319275e-01
    z[5,0,3]  R361      -3.8046240806579590e-01
    z[5,0,3]  R362      -5.8095515705645084e-03
    z[5,0,3]  R363      -8.5485443472862244e-02
    z[5,0,3]  R364      -2.1694874763488770e-01
    z[5,0,3]  R365      -9.1061845421791077e-02
    z[5,0,3]  R366      -1.4058266580104828e-01
    z[5,0,3]  R367      2.7991944551467896e-01
    z[5,0,3]  R368      6.6506855189800262e-02
    z[5,0,3]  R369      4.5748311281204224e-01
    z[5,0,3]  R370      3.5309907793998718e-01
    z[5,0,3]  R371      6.7494444549083710e-02
    z[5,0,3]  R372      4.4161457568407059e-02
    z[5,0,3]  R373      4.5583176612854004e-01
    z[5,0,3]  R374      4.5203980803489685e-01
    z[5,0,3]  R375      -1.9308102130889893e-01
    z[5,0,3]  R376      -1.1954199522733688e-01
    z[5,0,3]  R377      -3.7935337424278259e-01
    z[5,0,3]  R378      3.4658986330032349e-01
    z[5,0,3]  R379      5.6162470579147339e-01
    z[5,0,3]  R380      -1.8775951862335205e-01
    z[5,0,3]  R381      -1.1313343793153763e-01
    z[5,0,3]  R382      2.4873189628124237e-02
    z[5,0,3]  R383      0.0875496044754982
    z[5,0,3]  R384      -1.2553407251834869e-01
    z[5,0,3]  R385      -1.7480676993727684e-02
    z[5,0,3]  R386      4.6484208106994629e-01
    z[5,0,3]  R387      4.0039411187171936e-01
    z[5,0,3]  R388      -2.8232035040855408e-01
    z[5,0,3]  R389      -7.3677316308021545e-02
    z[5,0,3]  R390      -2.8459736704826355e-01
    z[5,0,3]  R391      -5.1777446269989014e-01
    z[5,0,3]  R392      -2.0285290479660034e-01
    z[5,0,3]  R393      -6.5406644344329834e-01
    z[5,0,3]  R394      -3.8228946924209595e-01
    z[5,0,3]  R395      7.9646319150924683e-02
    z[5,0,3]  R396      2.0401114225387573e-01
    z[5,0,3]  R397      -0.0553707480430603
    z[5,0,3]  R398      -1.2512814998626709e-01
    z[5,0,3]  R399      2.2900892794132233e-01
    z[5,0,3]  R400      -1.9740380346775055e-01
    z[5,0,3]  R401      -2.7225196361541748e-01
    z[5,0,3]  R402      -4.1527125239372253e-01
    z[5,0,3]  R403      2.8835743665695190e-01
    z[5,0,3]  R404      -2.7360485401004553e-03
    z[5,0,3]  R405      -1.1131959408521652e-01
    z[5,0,3]  R406      1.2222599983215332e-01
    z[5,0,3]  R407      -1.0076513141393661e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R342      -1
    z[5,0,4]  R343      1
    z[5,0,4]  R348      -3.5819873213768005e-01
    z[5,0,4]  R349      8.4051378071308136e-02
    z[5,0,4]  R350      8.7837286293506622e-02
    z[5,0,4]  R351      -3.6483651399612427e-01
    z[5,0,4]  R352      2.0078261196613312e-01
    z[5,0,4]  R353      1.9267193973064423e-01
    z[5,0,4]  R354      1.1413767933845520e-01
    z[5,0,4]  R355      -3.7626230716705322e-01
    z[5,0,4]  R356      -9.2131003737449646e-02
    z[5,0,4]  R357      -2.5089371204376221e-01
    z[5,0,4]  R358      5.0921601057052612e-01
    z[5,0,4]  R359      -5.7260245084762573e-01
    z[5,0,4]  R360      5.1801240444183350e-01
    z[5,0,4]  R361      -1.7598392069339752e-01
    z[5,0,4]  R362      -2.3380665481090546e-01
    z[5,0,4]  R363      4.7376893460750580e-02
    z[5,0,4]  R364      2.6536622643470764e-01
    z[5,0,4]  R365      2.1654200553894043e-01
    z[5,0,4]  R366      2.4909342825412750e-01
    z[5,0,4]  R367      -0.0775151476264
    z[5,0,4]  R368      2.5572302937507629e-01
    z[5,0,4]  R369      -4.9793016910552979e-01
    z[5,0,4]  R370      -4.9561339616775513e-01
    z[5,0,4]  R371      -5.1052731275558472e-01
    z[5,0,4]  R372      -4.8252606391906738e-01
    z[5,0,4]  R373      -2.0163437724113464e-01
    z[5,0,4]  R374      -2.0760956406593323e-01
    z[5,0,4]  R375      5.1144324243068695e-02
    z[5,0,4]  R376      2.9054602980613708e-01
    z[5,0,4]  R377      3.7746012210845947e-01
    z[5,0,4]  R378      -8.3451956510543823e-02
    z[5,0,4]  R379      -3.3074009418487549e-01
    z[5,0,4]  R380      1.0776181519031525e-01
    z[5,0,4]  R381      -1.6035382449626923e-01
    z[5,0,4]  R382      0.302490234375
    z[5,0,4]  R383      3.8686412572860718e-01
    z[5,0,4]  R384      -1.8753142654895782e-01
    z[5,0,4]  R385      -7.1950078010559082e-02
    z[5,0,4]  R386      -5.7816648483276367e-01
    z[5,0,4]  R387      1.4716595411300659e-01
    z[5,0,4]  R388      6.9416522979736328e-01
    z[5,0,4]  R389      1.3592466711997986e-01
    z[5,0,4]  R390      3.6502486467361450e-01
    z[5,0,4]  R391      -4.6036940813064575e-01
    z[5,0,4]  R392      7.7058456838130951e-02
    z[5,0,4]  R393      -3.0732330679893494e-01
    z[5,0,4]  R394      -3.5659581422805786e-01
    z[5,0,4]  R395      -5.9570330381393433e-01
    z[5,0,4]  R396      -3.5770753026008606e-01
    z[5,0,4]  R397      -1.8804828822612762e-01
    z[5,0,4]  R398      -1.5170462429523468e-01
    z[5,0,4]  R399      3.0439239740371704e-01
    z[5,0,4]  R400      2.2947153449058533e-01
    z[5,0,4]  R401      1.3315358757972717e-01
    z[5,0,4]  R402      -0.309390664100647
    z[5,0,4]  R403      2.5706894695758820e-02
    z[5,0,4]  R404      4.2895305156707764e-01
    z[5,0,4]  R405      5.7034876197576523e-02
    z[5,0,4]  R406      -3.9720979332923889e-01
    z[5,0,4]  R407      3.2676732540130615e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R344      -1
    z[5,0,5]  R345      1
    z[5,0,5]  R348      -1.2088346481323242e-01
    z[5,0,5]  R349      -6.2800031900405884e-01
    z[5,0,5]  R350      -4.0164360404014587e-01
    z[5,0,5]  R351      -5.4557675123214722e-01
    z[5,0,5]  R352      -4.5615857839584351e-01
    z[5,0,5]  R353      1.0082848370075226e-01
    z[5,0,5]  R354      1.4392022788524628e-01
    z[5,0,5]  R355      2.1801939606666565e-01
    z[5,0,5]  R356      -6.6552406549453735e-01
    z[5,0,5]  R357      -7.8395850956439972e-02
    z[5,0,5]  R358      5.0746500492095947e-01
    z[5,0,5]  R359      -2.4189466238021851e-01
    z[5,0,5]  R360      -2.1659222245216370e-01
    z[5,0,5]  R361      -7.7802293002605438e-02
    z[5,0,5]  R362      -1.5291871130466461e-01
    z[5,0,5]  R363      -2.2871309518814087e-01
    z[5,0,5]  R364      -7.2227261960506439e-02
    z[5,0,5]  R365      8.4162920713424683e-02
    z[5,0,5]  R366      -7.6263256371021271e-02
    z[5,0,5]  R367      2.2961314767599106e-02
    z[5,0,5]  R368      2.7249900624155998e-02
    z[5,0,5]  R369      6.1988379806280136e-02
    z[5,0,5]  R370      2.1062639355659485e-01
    z[5,0,5]  R371      -1.4936427772045135e-01
    z[5,0,5]  R372      5.0663727521896362e-01
    z[5,0,5]  R373      3.1477779150009155e-01
    z[5,0,5]  R374      -1.0706861317157745e-01
    z[5,0,5]  R375      4.5557871460914612e-01
    z[5,0,5]  R376      -1.5782682597637177e-01
    z[5,0,5]  R377      2.0386941730976105e-01
    z[5,0,5]  R378      2.9360356926918030e-01
    z[5,0,5]  R379      1.3964110985398293e-02
    z[5,0,5]  R380      1.6813308000564575e-01
    z[5,0,5]  R381      2.7296161651611328e-01
    z[5,0,5]  R382      -4.2952352762222290e-01
    z[5,0,5]  R383      -0.0528470054268837
    z[5,0,5]  R384      -4.6429717540740967e-01
    z[5,0,5]  R385      -3.0102476477622986e-01
    z[5,0,5]  R386      -1.0383608937263489e-01
    z[5,0,5]  R387      -1.0773006826639175e-01
    z[5,0,5]  R388      4.6527001261711121e-01
    z[5,0,5]  R389      4.7618106007575989e-01
    z[5,0,5]  R390      5.6284952163696289e-01
    z[5,0,5]  R391      -2.9629451036453247e-01
    z[5,0,5]  R392      -5.6557911634445190e-01
    z[5,0,5]  R393      8.1596568226814270e-02
    z[5,0,5]  R394      -2.2623999416828156e-01
    z[5,0,5]  R395      1.2408995628356934e-01
    z[5,0,5]  R396      -7.9403780400753021e-03
    z[5,0,5]  R397      -6.2764868140220642e-02
    z[5,0,5]  R398      2.8822100162506104e-01
    z[5,0,5]  R399      3.8251818623393774e-03
    z[5,0,5]  R400      1.7396403709426522e-03
    z[5,0,5]  R401      3.5765978693962097e-01
    z[5,0,5]  R402      2.7456291019916534e-02
    z[5,0,5]  R403      1.7912285029888153e-01
    z[5,0,5]  R404      7.6556608080863953e-02
    z[5,0,5]  R405      1.4506430923938751e-01
    z[5,0,5]  R406      -2.1472917497158051e-01
    z[5,0,5]  R407      -1.7509551346302032e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R346      -1
    z[5,0,6]  R347      1
    z[5,0,6]  R348      0.654710054397583
    z[5,0,6]  R349      1.1131328344345093e-01
    z[5,0,6]  R350      -6.2751924991607666e-01
    z[5,0,6]  R351      -2.8403052687644958e-01
    z[5,0,6]  R352      -1.4015206135809422e-02
    z[5,0,6]  R353      3.9710375666618347e-01
    z[5,0,6]  R354      -4.1147151589393616e-01
    z[5,0,6]  R355      -0.648550808429718
    z[5,0,6]  R356      -3.8981980085372925e-01
    z[5,0,6]  R357      1.1535238474607468e-01
    z[5,0,6]  R358      5.1537081599235535e-02
    z[5,0,6]  R359      -1.7527288198471069e-01
    z[5,0,6]  R360      -0.308473140001297
    z[5,0,6]  R361      3.4835276007652283e-01
    z[5,0,6]  R362      1.7663891613483429e-01
    z[5,0,6]  R363      0.566135585308075
    z[5,0,6]  R364      1.7517418600618839e-03
    z[5,0,6]  R365      4.6621233224868774e-01
    z[5,0,6]  R366      -7.9900383949279785e-02
    z[5,0,6]  R367      1.5412263572216034e-01
    z[5,0,6]  R368      -4.9296006560325623e-02
    z[5,0,6]  R369      7.5118844397366047e-03
    z[5,0,6]  R370      4.6299794316291809e-01
    z[5,0,6]  R371      -1.9924205541610718e-01
    z[5,0,6]  R372      4.8924211412668228e-02
    z[5,0,6]  R373      5.5955359712243080e-03
    z[5,0,6]  R374      4.0630626678466797e-01
    z[5,0,6]  R375      1.1427410691976547e-01
    z[5,0,6]  R376      -8.3497636020183563e-02
    z[5,0,6]  R377      4.6415582299232483e-01
    z[5,0,6]  R378      3.8634572178125381e-02
    z[5,0,6]  R379      -1.5741581097245216e-02
    z[5,0,6]  R380      -2.1139627322554588e-02
    z[5,0,6]  R381      1.6749539971351624e-01
    z[5,0,6]  R382      4.4518679380416870e-01
    z[5,0,6]  R383      -4.5397195965051651e-02
    z[5,0,6]  R384      -2.7749935165047646e-02
    z[5,0,6]  R385      1.2521874904632568e-01
    z[5,0,6]  R386      -1.0582274943590164e-01
    z[5,0,6]  R387      6.3916943967342377e-02
    z[5,0,6]  R388      8.4687858819961548e-02
    z[5,0,6]  R389      2.7854385972023010e-01
    z[5,0,6]  R390      -4.9943429231643677e-01
    z[5,0,6]  R391      1.9908805191516876e-01
    z[5,0,6]  R392      3.9190784096717834e-01
    z[5,0,6]  R393      1.1957976222038269e-01
    z[5,0,6]  R394      2.2648532688617706e-01
    z[5,0,6]  R395      -1.2779808603227139e-02
    z[5,0,6]  R396      2.8644669055938721e-01
    z[5,0,6]  R397      3.7128555774688721e-01
    z[5,0,6]  R398      1.8244867026805878e-01
    z[5,0,6]  R399      -1.1804796010255814e-01
    z[5,0,6]  R400      -2.8831705451011658e-01
    z[5,0,6]  R401      -6.0568958520889282e-02
    z[5,0,6]  R402      -0.190096914768219
    z[5,0,6]  R403      5.9414887428283691e-01
    z[5,0,6]  R404      6.4565908908843994e-01
    z[5,0,6]  R405      -2.3918978869915009e-02
    z[5,0,6]  R406      4.1156476736068726e-01
    z[5,0,6]  R407      1.8318559229373932e-01
    z[0,6,0]  R2        -1
    z[0,6,0]  R56       1
    z[0,6,0]  R408      -1
    z[0,6,0]  R409      1
    z[0,6,0]  R422      -7.5358949601650238e-02
    z[0,6,0]  R423      1.5595360100269318e-01
    z[0,6,0]  R424      3.7856489419937134e-01
    z[0,6,0]  R425      5.7903724908828735e-01
    z[0,6,0]  R426      4.5991745591163635e-01
    z[0,6,0]  R427      5.6721532344818115e-01
    z[0,6,0]  R428      7.5176799297332764e-01
    z[0,6,0]  R429      2.5073993206024170e-01
    z[0,6,0]  R430      -5.2961182594299316e-01
    z[0,6,0]  R431      7.4970316886901855e-01
    z[0,6,0]  R432      -3.5578823089599609e-01
    z[0,6,0]  R433      2.3767025768756866e-01
    z[0,6,0]  R434      3.7304529547691345e-01
    z[0,6,0]  R435      1.1755401641130447e-01
    z[0,6,0]  R436      -3.4004725515842438e-02
    z[0,6,0]  R437      2.3310141265392303e-01
    z[0,6,0]  R438      -1.1395020037889481e-01
    z[0,6,0]  R439      -6.6100138425827026e-01
    z[0,6,0]  R440      -6.7390298843383789e-01
    z[0,6,0]  R441      -7.2265905141830444e-01
    z[0,6,0]  R442      2.5237640738487244e-01
    z[0,6,0]  R443      -4.7703701257705688e-01
    z[0,6,0]  R444      5.8202129602432251e-01
    z[0,6,0]  R445      6.7512148618698120e-01
    z[0,6,0]  R446      5.8907490968704224e-01
    z[0,6,0]  R447      3.7437388300895691e-01
    z[0,6,0]  R448      2.2523894906044006e-01
    z[0,6,0]  R449      -5.2928882837295532e-01
    z[0,6,0]  R450      -5.4311645030975342e-01
    z[0,6,0]  R451      -0.449020653963089
    z[0,6,0]  R452      2.0031196996569633e-02
    z[0,6,0]  R453      4.7062397003173828e-01
    z[0,6,0]  R454      -2.0097967982292175e-01
    z[0,6,0]  R455      5.3255504369735718e-01
    z[0,6,0]  R456      -5.3218755871057510e-02
    z[0,6,0]  R457      -5.1938509941101074e-01
    z[0,6,0]  R458      7.6573394238948822e-02
    z[0,6,0]  R459      -6.3433700799942017e-01
    z[0,6,0]  R460      2.9662674292922020e-02
    z[0,6,0]  R461      5.4677534103393555e-01
    z[0,6,0]  R462      1.3562743365764618e-01
    z[0,6,0]  R463      1.5572011470794678e-01
    z[0,6,0]  R464      1.1420238018035889e-01
    z[0,6,0]  R465      2.3889848962426186e-02
    z[0,6,0]  R466      -1.5095965564250946e-01
    z[0,6,0]  R467      -3.1263357400894165e-01
    z[0,6,0]  R468      -2.6962655782699585e-01
    z[0,6,0]  R469      -2.3602253198623657e-01
    z[0,6,0]  R470      -2.9074054956436157e-01
    z[0,6,0]  R471      -3.3436134457588196e-01
    z[0,6,0]  R472      -1.2169932574033737e-01
    z[0,6,0]  R473      1.3749545812606812e-01
    z[0,6,0]  R474      -2.2975397109985352e-01
    z[0,6,0]  R475      -3.8394263386726379e-01
    z[0,6,0]  R476      -2.8801003098487854e-01
    z[0,6,0]  R477      -2.5030487775802612e-01
    z[0,6,0]  R478      5.4529821872711182e-01
    z[0,6,0]  R479      3.7663927674293518e-01
    z[0,6,0]  R480      -2.1984383463859558e-01
    z[0,6,0]  R481      -6.0424816608428955e-01
    z[0,6,0]  R482      3.0019545927643776e-02
    z[0,6,0]  R483      -1.9691903889179230e-01
    z[0,6,0]  R484      7.2666600346565247e-02
    z[0,6,0]  R485      -1.9034427404403687e-01
    z[0,6,0]  R486      1.2171491980552673e-01
    z[0,6,0]  R487      -0.00383838452398777
    z[0,6,0]  R488      -0.226633220911026
    z[0,6,0]  R489      -4.5925104618072510e-01
    z[0,6,0]  R490      -4.1722607612609863e-01
    z[0,6,0]  R491      -2.6629993319511414e-01
    z[0,6,0]  R492      -2.9132384061813354e-01
    z[0,6,0]  R493      -3.7018135190010071e-01
    z[0,6,0]  R494      1.9356849789619446e-01
    z[0,6,0]  R495      -3.1235665082931519e-01
    z[0,6,0]  R496      3.4809085726737976e-01
    z[0,6,0]  R497      5.3691053390502930e-01
    z[0,6,0]  R498      -4.8993730545043945e-01
    z[0,6,0]  R499      5.6050747632980347e-01
    z[0,6,0]  R500      -8.0752231180667877e-02
    z[0,6,0]  R501      -4.3593738228082657e-02
    z[0,6,1]  R3        -1
    z[0,6,1]  R57       1
    z[0,6,1]  R410      -1
    z[0,6,1]  R411      1
    z[0,6,1]  R422      9.6793889999389648e-02
    z[0,6,1]  R423      9.5467088976874948e-04
    z[0,6,1]  R424      4.4080372899770737e-02
    z[0,6,1]  R425      3.8586426526308060e-02
    z[0,6,1]  R426      3.5572454333305359e-02
    z[0,6,1]  R427      7.6472297310829163e-02
    z[0,6,1]  R428      5.3024303168058395e-02
    z[0,6,1]  R429      4.7504503279924393e-02
    z[0,6,1]  R430      7.1272291243076324e-02
    z[0,6,1]  R431      -1.6442860662937164e-01
    z[0,6,1]  R432      2.6647645235061646e-01
    z[0,6,1]  R433      -5.1985198259353638e-01
    z[0,6,1]  R434      -1.8105420470237732e-01
    z[0,6,1]  R435      -5.4912024736404419e-01
    z[0,6,1]  R436      -6.2785738706588745e-01
    z[0,6,1]  R437      -3.5683214664459229e-01
    z[0,6,1]  R438      1.5637357532978058e-01
    z[0,6,1]  R439      -3.4449872374534607e-01
    z[0,6,1]  R440      -3.8743022084236145e-01
    z[0,6,1]  R441      -1.1335832625627518e-01
    z[0,6,1]  R442      8.7743246555328369e-01
    z[0,6,1]  R443      7.4273413419723511e-01
    z[0,6,1]  R444      -6.8861061334609985e-01
    z[0,6,1]  R445      -5.6328219175338745e-01
    z[0,6,1]  R446      -5.7809185981750488e-01
    z[0,6,1]  R447      -5.1152777671813965e-01
    z[0,6,1]  R448      -5.5766272544860840e-01
    z[0,6,1]  R449      -7.1173429489135742e-02
    z[0,6,1]  R450      -8.6887432262301445e-03
    z[0,6,1]  R451      -4.6204483509063721e-01
    z[0,6,1]  R452      -7.8190410137176514e-01
    z[0,6,1]  R453      -3.6997714638710022e-01
    z[0,6,1]  R454      -6.0399180650711060e-01
    z[0,6,1]  R455      -4.4579467177391052e-01
    z[0,6,1]  R456      -8.2918137311935425e-01
    z[0,6,1]  R457      -6.4737731218338013e-01
    z[0,6,1]  R458      -2.8673955798149109e-01
    z[0,6,1]  R459      -5.9463238716125488e-01
    z[0,6,1]  R460      -4.4625002145767212e-01
    z[0,6,1]  R461      -3.0965870618820190e-01
    z[0,6,1]  R462      4.0525174140930176e-01
    z[0,6,1]  R463      2.8946825861930847e-01
    z[0,6,1]  R464      9.2991006374359131e-01
    z[0,6,1]  R465      8.6411511898040771e-01
    z[0,6,1]  R466      8.2175713777542114e-01
    z[0,6,1]  R467      6.9736850261688232e-01
    z[0,6,1]  R468      0.808444619178772
    z[0,6,1]  R469      7.2943145036697388e-01
    z[0,6,1]  R470      5.6239664554595947e-01
    z[0,6,1]  R471      6.5161406993865967e-01
    z[0,6,1]  R472      8.4629094600677490e-01
    z[0,6,1]  R473      8.7107741832733154e-01
    z[0,6,1]  R474      9.1347074508666992e-01
    z[0,6,1]  R475      6.5538221597671509e-01
    z[0,6,1]  R476      8.3171874284744263e-01
    z[0,6,1]  R477      3.9090868830680847e-01
    z[0,6,1]  R478      7.8255093097686768e-01
    z[0,6,1]  R479      3.5327199101448059e-01
    z[0,6,1]  R480      3.1925094127655029e-01
    z[0,6,1]  R481      5.1732963323593140e-01
    z[0,6,1]  R482      8.7808293104171753e-01
    z[0,6,1]  R483      6.3551861047744751e-01
    z[0,6,1]  R484      5.8599531650543213e-01
    z[0,6,1]  R485      8.0284309387207031e-01
    z[0,6,1]  R486      7.7548879384994507e-01
    z[0,6,1]  R487      7.5157040357589722e-01
    z[0,6,1]  R488      7.3652219772338867e-01
    z[0,6,1]  R489      7.1352082490921021e-01
    z[0,6,1]  R490      7.2306710481643677e-01
    z[0,6,1]  R491      3.7456589937210083e-01
    z[0,6,1]  R492      6.7980217933654785e-01
    z[0,6,1]  R493      7.6989412307739258e-01
    z[0,6,1]  R494      0.847685694694519
    z[0,6,1]  R495      0.807413637638092
    z[0,6,1]  R496      3.1038349866867065e-01
    z[0,6,1]  R497      7.4890291690826416e-01
    z[0,6,1]  R498      5.3914952278137207e-01
    z[0,6,1]  R499      1.5823675692081451e-01
    z[0,6,1]  R500      8.0106192827224731e-01
    z[0,6,1]  R501      7.4141615629196167e-01
    z[0,6,2]  R4        -1
    z[0,6,2]  R58       1
    z[0,6,2]  R412      -1
    z[0,6,2]  R413      1
    z[0,6,2]  R422      6.4283972978591919e-01
    z[0,6,2]  R423      2.3409101366996765e-01
    z[0,6,2]  R424      2.7970978617668152e-01
    z[0,6,2]  R425      3.0148291587829590e-01
    z[0,6,2]  R426      0.496791809797287
    z[0,6,2]  R427      5.2066934108734131e-01
    z[0,6,2]  R428      4.2420539259910583e-01
    z[0,6,2]  R429      4.7645160555839539e-01
    z[0,6,2]  R430      2.7403315901756287e-01
    z[0,6,2]  R431      -4.6178337931632996e-01
    z[0,6,2]  R432      -1.3109797239303589e-01
    z[0,6,2]  R433      5.8739078044891357e-01
    z[0,6,2]  R434      2.1813666820526123e-01
    z[0,6,2]  R435      -2.7783304452896118e-01
    z[0,6,2]  R436      -2.8996571898460388e-01
    z[0,6,2]  R437      -5.2452516555786133e-01
    z[0,6,2]  R438      -0.766013503074646
    z[0,6,2]  R439      -2.6005801558494568e-01
    z[0,6,2]  R440      -3.7955591082572937e-01
    z[0,6,2]  R441      -5.3356665372848511e-01
    z[0,6,2]  R442      -1.0671491920948029e-01
    z[0,6,2]  R443      -2.4845926463603973e-01
    z[0,6,2]  R444      1.1095648258924484e-01
    z[0,6,2]  R445      -5.9024691581726074e-02
    z[0,6,2]  R446      -1.1720573902130127e-01
    z[0,6,2]  R447      3.5954797267913818e-01
    z[0,6,2]  R448      -1.7758095264434814e-01
    z[0,6,2]  R449      8.2312017679214478e-01
    z[0,6,2]  R450      5.6279665231704712e-01
    z[0,6,2]  R451      6.3541257381439209e-01
    z[0,6,2]  R452      -1.3319614529609680e-01
    z[0,6,2]  R453      -3.3799886703491211e-01
    z[0,6,2]  R454      -2.8119698166847229e-01
    z[0,6,2]  R455      -6.3282884657382965e-03
    z[0,6,2]  R456      -4.1510784626007080e-01
    z[0,6,2]  R457      -2.1796886622905731e-01
    z[0,6,2]  R458      -3.6379560828208923e-02
    z[0,6,2]  R459      3.6675009876489639e-02
    z[0,6,2]  R460      -1.8968142569065094e-01
    z[0,6,2]  R461      -1.4247059822082520e-01
    z[0,6,2]  R462      -1.2563848495483398e-01
    z[0,6,2]  R463      -9.7060143947601318e-02
    z[0,6,2]  R464      -2.1673109382390976e-02
    z[0,6,2]  R465      -4.1682547330856323e-01
    z[0,6,2]  R466      -1.6679960489273071e-01
    z[0,6,2]  R467      -0.431225061416626
    z[0,6,2]  R468      0.111131452023983
    z[0,6,2]  R469      -4.5923840999603271e-01
    z[0,6,2]  R470      -7.5315505266189575e-01
    z[0,6,2]  R471      -5.0678777694702148e-01
    z[0,6,2]  R472      -2.5695204734802246e-01
    z[0,6,2]  R473      -2.2990810871124268e-01
    z[0,6,2]  R474      -9.1658405959606171e-02
    z[0,6,2]  R475      5.6675948202610016e-02
    z[0,6,2]  R476      -5.0259608775377274e-02
    z[0,6,2]  R477      1.0611893236637115e-01
    z[0,6,2]  R478      1.9353662431240082e-01
    z[0,6,2]  R479      1.5623576939105988e-01
    z[0,6,2]  R480      7.5560994446277618e-04
    z[0,6,2]  R481      3.2969883084297180e-01
    z[0,6,2]  R482      -4.0979039669036865e-01
    z[0,6,2]  R483      2.3030509054660797e-01
    z[0,6,2]  R484      4.4043174386024475e-01
    z[0,6,2]  R485      -2.1861056983470917e-01
    z[0,6,2]  R486      -3.9543649554252625e-01
    z[0,6,2]  R487      -4.8836305737495422e-01
    z[0,6,2]  R488      -1.5879217535257339e-03
    z[0,6,2]  R489      -2.4725767970085144e-01
    z[0,6,2]  R490      -1.1703561991453171e-01
    z[0,6,2]  R491      0.0369969867169857
    z[0,6,2]  R492      -3.4943285584449768e-01
    z[0,6,2]  R493      -2.9353508353233337e-01
    z[0,6,2]  R494      -7.9275742173194885e-03
    z[0,6,2]  R495      -2.2706474363803864e-01
    z[0,6,2]  R496      1.2162059545516968e-01
    z[0,6,2]  R497      1.8791253864765167e-01
    z[0,6,2]  R498      3.1081789731979370e-01
    z[0,6,2]  R499      -1.5064038336277008e-01
    z[0,6,2]  R500      4.1153150796890259e-01
    z[0,6,2]  R501      1.6199788451194763e-01
    z[0,6,3]  R5        -1
    z[0,6,3]  R59       1
    z[0,6,3]  R414      -1
    z[0,6,3]  R415      1
    z[0,6,3]  R422      -1.2030338868498802e-02
    z[0,6,3]  R423      7.1206682920455933e-01
    z[0,6,3]  R424      4.6227118372917175e-01
    z[0,6,3]  R425      4.6484208106994629e-01
    z[0,6,3]  R426      1.7022161185741425e-01
    z[0,6,3]  R427      -3.9080867171287537e-01
    z[0,6,3]  R428      -2.2143563628196716e-01
    z[0,6,3]  R429      -3.1327739357948303e-01
    z[0,6,3]  R430      -1.8965117633342743e-01
    z[0,6,3]  R431      4.0039411187171936e-01
    z[0,6,3]  R432      -2.8232035040855408e-01
    z[0,6,3]  R433      -7.3677316308021545e-02
    z[0,6,3]  R434      -2.8459736704826355e-01
    z[0,6,3]  R435      -5.1777446269989014e-01
    z[0,6,3]  R436      -2.0285290479660034e-01
    z[0,6,3]  R437      -6.5406644344329834e-01
    z[0,6,3]  R438      -3.8228946924209595e-01
    z[0,6,3]  R439      7.9646319150924683e-02
    z[0,6,3]  R440      2.0401114225387573e-01
    z[0,6,3]  R441      -0.0553707480430603
    z[0,6,3]  R442      -1.2512814998626709e-01
    z[0,6,3]  R443      2.2900892794132233e-01
    z[0,6,3]  R444      -1.9740380346775055e-01
    z[0,6,3]  R445      -2.7225196361541748e-01
    z[0,6,3]  R446      -4.1527125239372253e-01
    z[0,6,3]  R447      2.8835743665695190e-01
    z[0,6,3]  R448      -2.7360485401004553e-03
    z[0,6,3]  R449      -1.1131959408521652e-01
    z[0,6,3]  R450      1.2222599983215332e-01
    z[0,6,3]  R451      -1.0076513141393661e-01
    z[0,6,3]  R452      2.4851515889167786e-01
    z[0,6,3]  R453      4.2799273133277893e-01
    z[0,6,3]  R454      1.8995456397533417e-01
    z[0,6,3]  R455      0.647131085395813
    z[0,6,3]  R456      -3.3350121229887009e-02
    z[0,6,3]  R457      -1.3669732958078384e-02
    z[0,6,3]  R458      8.5663646459579468e-01
    z[0,6,3]  R459      -2.4247553944587708e-01
    z[0,6,3]  R460      1.1043892055749893e-01
    z[0,6,3]  R461      4.7907626628875732e-01
    z[0,6,3]  R462      -1.8333104252815247e-01
    z[0,6,3]  R463      -5.6412893533706665e-01
    z[0,6,3]  R464      1.4555303752422333e-01
    z[0,6,3]  R465      1.7127810278907418e-03
    z[0,6,3]  R466      -2.4269069731235504e-01
    z[0,6,3]  R467      1.1815001815557480e-01
    z[0,6,3]  R468      2.1872974932193756e-01
    z[0,6,3]  R469      -2.4208946526050568e-01
    z[0,6,3]  R470      1.3070549070835114e-01
    z[0,6,3]  R471      3.3484759926795959e-01
    z[0,6,3]  R472      3.0880925059318542e-01
    z[0,6,3]  R473      6.7955709993839264e-02
    z[0,6,3]  R474      -1.2718668580055237e-01
    z[0,6,3]  R475      3.0917921662330627e-01
    z[0,6,3]  R476      2.5221493840217590e-01
    z[0,6,3]  R477      -7.5860089063644409e-01
    z[0,6,3]  R478      -0.0707196369767189
    z[0,6,3]  R479      -4.6028646826744080e-01
    z[0,6,3]  R480      -7.2013401985168457e-01
    z[0,6,3]  R481      -3.5336297750473022e-01
    z[0,6,3]  R482      1.3543894886970520e-01
    z[0,6,3]  R483      -3.0731633305549622e-01
    z[0,6,3]  R484      2.5043663382530212e-01
    z[0,6,3]  R485      1.9921740889549255e-01
    z[0,6,3]  R486      -2.3116227984428406e-01
    z[0,6,3]  R487      -2.2955887019634247e-01
    z[0,6,3]  R488      -1.5074518509209156e-02
    z[0,6,3]  R489      0.347474604845047
    z[0,6,3]  R490      2.0738035440444946e-01
    z[0,6,3]  R491      -0.728060245513916
    z[0,6,3]  R492      2.4625155329704285e-01
    z[0,6,3]  R493      2.9551351070404053e-01
    z[0,6,3]  R494      0.180172398686409
    z[0,6,3]  R495      -6.9118700921535492e-02
    z[0,6,3]  R496      -4.9093249440193176e-01
    z[0,6,3]  R497      8.9788466691970825e-02
    z[0,6,3]  R498      -0.504069983959198
    z[0,6,3]  R499      -5.8053833246231079e-01
    z[0,6,3]  R500      5.4022260010242462e-02
    z[0,6,3]  R501      7.7676810324192047e-02
    z[0,6,4]  R6        -1
    z[0,6,4]  R60       1
    z[0,6,4]  R416      -1
    z[0,6,4]  R417      1
    z[0,6,4]  R422      -3.5819873213768005e-01
    z[0,6,4]  R423      8.4051378071308136e-02
    z[0,6,4]  R424      8.7837286293506622e-02
    z[0,6,4]  R425      -5.7816648483276367e-01
    z[0,6,4]  R426      -3.6483651399612427e-01
    z[0,6,4]  R427      2.0078261196613312e-01
    z[0,6,4]  R428      1.1413767933845520e-01
    z[0,6,4]  R429      -3.7626230716705322e-01
    z[0,6,4]  R430      -9.2131003737449646e-02
    z[0,6,4]  R431      1.4716595411300659e-01
    z[0,6,4]  R432      6.9416522979736328e-01
    z[0,6,4]  R433      1.3592466711997986e-01
    z[0,6,4]  R434      3.6502486467361450e-01
    z[0,6,4]  R435      -4.6036940813064575e-01
    z[0,6,4]  R436      7.7058456838130951e-02
    z[0,6,4]  R437      -3.0732330679893494e-01
    z[0,6,4]  R438      -3.5659581422805786e-01
    z[0,6,4]  R439      -5.9570330381393433e-01
    z[0,6,4]  R440      -3.5770753026008606e-01
    z[0,6,4]  R441      -1.8804828822612762e-01
    z[0,6,4]  R442      -1.5170462429523468e-01
    z[0,6,4]  R443      3.0439239740371704e-01
    z[0,6,4]  R444      2.2947153449058533e-01
    z[0,6,4]  R445      1.3315358757972717e-01
    z[0,6,4]  R446      -0.309390664100647
    z[0,6,4]  R447      2.5706894695758820e-02
    z[0,6,4]  R448      4.2895305156707764e-01
    z[0,6,4]  R449      5.7034876197576523e-02
    z[0,6,4]  R450      -3.9720979332923889e-01
    z[0,6,4]  R451      3.2676732540130615e-01
    z[0,6,4]  R452      -3.6935889720916748e-01
    z[0,6,4]  R453      -4.3102037906646729e-01
    z[0,6,4]  R454      -0.0522281676530838
    z[0,6,4]  R455      1.3389755785465240e-01
    z[0,6,4]  R456      3.5002410411834717e-01
    z[0,6,4]  R457      -3.5380309820175171e-01
    z[0,6,4]  R458      2.3240806162357330e-01
    z[0,6,4]  R459      1.6689166426658630e-01
    z[0,6,4]  R460      -7.7786058187484741e-01
    z[0,6,4]  R461      1.5104007720947266e-01
    z[0,6,4]  R462      2.6192682981491089e-01
    z[0,6,4]  R463      1.8555636703968048e-01
    z[0,6,4]  R464      -1.4745970070362091e-01
    z[0,6,4]  R465      -2.2623822093009949e-01
    z[0,6,4]  R466      -3.6451452970504761e-01
    z[0,6,4]  R467      -1.0220992378890514e-02
    z[0,6,4]  R468      -4.1237783432006836e-01
    z[0,6,4]  R469      -2.7822852134704590e-01
    z[0,6,4]  R470      -0.0856996551156044
    z[0,6,4]  R471      3.4416213631629944e-02
    z[0,6,4]  R472      -1.8395955860614777e-01
    z[0,6,4]  R473      -1.9225528836250305e-01
    z[0,6,4]  R474      -2.4892230331897736e-01
    z[0,6,4]  R475      -3.6046814918518066e-01
    z[0,6,4]  R476      -2.4335388839244843e-01
    z[0,6,4]  R477      -7.2335690259933472e-02
    z[0,6,4]  R478      1.1693262308835983e-01
    z[0,6,4]  R479      -3.5507228970527649e-01
    z[0,6,4]  R480      2.4996544420719147e-01
    z[0,6,4]  R481      -4.8424351960420609e-02
    z[0,6,4]  R482      -1.8865896761417389e-01
    z[0,6,4]  R483      -3.0305463075637817e-01
    z[0,6,4]  R484      -3.8017854094505310e-01
    z[0,6,4]  R485      -4.1649696230888367e-01
    z[0,6,4]  R486      -3.3740437030792236e-01
    z[0,6,4]  R487      -2.9558593034744263e-01
    z[0,6,4]  R488      -4.2544689774513245e-01
    z[0,6,4]  R489      -1.5303482115268707e-01
    z[0,6,4]  R490      -1.2073575705289841e-01
    z[0,6,4]  R491      2.4712586402893066e-01
    z[0,6,4]  R492      -2.2771361470222473e-01
    z[0,6,4]  R493      -1.0204493999481201e-01
    z[0,6,4]  R494      -4.4191029667854309e-01
    z[0,6,4]  R495      -2.8548830747604370e-01
    z[0,6,4]  R496      -4.4406521320343018e-01
    z[0,6,4]  R497      2.1089971065521240e-01
    z[0,6,4]  R498      -2.5434973835945129e-01
    z[0,6,4]  R499      2.2958418726921082e-01
    z[0,6,4]  R500      3.7069392204284668e-01
    z[0,6,4]  R501      6.0400164127349854e-01
    z[0,6,5]  R7        -1
    z[0,6,5]  R61       1
    z[0,6,5]  R418      -1
    z[0,6,5]  R419      1
    z[0,6,5]  R422      -1.2088346481323242e-01
    z[0,6,5]  R423      -6.2800031900405884e-01
    z[0,6,5]  R424      -4.0164360404014587e-01
    z[0,6,5]  R425      -1.0383608937263489e-01
    z[0,6,5]  R426      -5.4557675123214722e-01
    z[0,6,5]  R427      -4.5615857839584351e-01
    z[0,6,5]  R428      1.4392022788524628e-01
    z[0,6,5]  R429      2.1801939606666565e-01
    z[0,6,5]  R430      -6.6552406549453735e-01
    z[0,6,5]  R431      -1.0773006826639175e-01
    z[0,6,5]  R432      4.6527001261711121e-01
    z[0,6,5]  R433      4.7618106007575989e-01
    z[0,6,5]  R434      5.6284952163696289e-01
    z[0,6,5]  R435      -2.9629451036453247e-01
    z[0,6,5]  R436      -5.6557911634445190e-01
    z[0,6,5]  R437      8.1596568226814270e-02
    z[0,6,5]  R438      -2.2623999416828156e-01
    z[0,6,5]  R439      1.2408995628356934e-01
    z[0,6,5]  R440      -7.9403780400753021e-03
    z[0,6,5]  R441      -6.2764868140220642e-02
    z[0,6,5]  R442      2.8822100162506104e-01
    z[0,6,5]  R443      3.8251818623393774e-03
    z[0,6,5]  R444      1.7396403709426522e-03
    z[0,6,5]  R445      3.5765978693962097e-01
    z[0,6,5]  R446      2.7456291019916534e-02
    z[0,6,5]  R447      1.7912285029888153e-01
    z[0,6,5]  R448      7.6556608080863953e-02
    z[0,6,5]  R449      1.4506430923938751e-01
    z[0,6,5]  R450      -2.1472917497158051e-01
    z[0,6,5]  R451      -1.7509551346302032e-01
    z[0,6,5]  R452      -1.3205623626708984e-01
    z[0,6,5]  R453      2.3775672540068626e-02
    z[0,6,5]  R454      -2.3560172319412231e-01
    z[0,6,5]  R455      -2.4947191774845123e-01
    z[0,6,5]  R456      -2.1468194201588631e-02
    z[0,6,5]  R457      -3.0987852811813354e-01
    z[0,6,5]  R458      1.9926816225051880e-01
    z[0,6,5]  R459      2.4895383417606354e-01
    z[0,6,5]  R460      -2.3796521127223969e-01
    z[0,6,5]  R461      1.6448259353637695e-01
    z[0,6,5]  R462      -8.3478963375091553e-01
    z[0,6,5]  R463      -5.4874008893966675e-01
    z[0,6,5]  R464      -2.7937579154968262e-01
    z[0,6,5]  R465      1.6618889570236206e-01
    z[0,6,5]  R466      -2.8234788775444031e-01
    z[0,6,5]  R467      -3.3864060044288635e-01
    z[0,6,5]  R468      -1.9196757674217224e-01
    z[0,6,5]  R469      -2.1979844197630882e-02
    z[0,6,5]  R470      -8.6034417152404785e-02
    z[0,6,5]  R471      -6.9077193737030029e-02
    z[0,6,5]  R472      -4.2867638170719147e-02
    z[0,6,5]  R473      -0.271806925535202
    z[0,6,5]  R474      -8.6144261062145233e-02
    z[0,6,5]  R475      -3.9314371347427368e-01
    z[0,6,5]  R476      1.2027243524789810e-01
    z[0,6,5]  R477      7.5420483946800232e-02
    z[0,6,5]  R478      1.8396285176277161e-01
    z[0,6,5]  R479      4.9101737141609192e-01
    z[0,6,5]  R480      -8.1900522112846375e-02
    z[0,6,5]  R481      -1.1446280032396317e-01
    z[0,6,5]  R482      7.4930049479007721e-02
    z[0,6,5]  R483      -0.532384991645813
    z[0,6,5]  R484      4.9820342659950256e-01
    z[0,6,5]  R485      0.0839017704129219
    z[0,6,5]  R486      -1.7509314417839050e-01
    z[0,6,5]  R487      -2.3635946214199066e-01
    z[0,6,5]  R488      -4.0245339274406433e-01
    z[0,6,5]  R489      -1.5049065649509430e-01
    z[0,6,5]  R490      -4.7530877590179443e-01
    z[0,6,5]  R491      -1.7866681516170502e-01
    z[0,6,5]  R492      -4.0760576725006104e-01
    z[0,6,5]  R493      -2.7285388112068176e-01
    z[0,6,5]  R494      -9.9871069192886353e-02
    z[0,6,5]  R495      -2.8446984291076660e-01
    z[0,6,5]  R496      5.5914241075515747e-01
    z[0,6,5]  R497      2.0898316800594330e-01
    z[0,6,5]  R498      -8.0084212124347687e-02
    z[0,6,5]  R499      4.5964911580085754e-01
    z[0,6,5]  R500      1.5262268483638763e-01
    z[0,6,5]  R501      1.8325030803680420e-01
    z[0,6,6]  R8        -1
    z[0,6,6]  R62       1
    z[0,6,6]  R420      -1
    z[0,6,6]  R421      1
    z[0,6,6]  R422      0.654710054397583
    z[0,6,6]  R423      1.1131328344345093e-01
    z[0,6,6]  R424      -6.2751924991607666e-01
    z[0,6,6]  R425      -1.0582274943590164e-01
    z[0,6,6]  R426      -2.8403052687644958e-01
    z[0,6,6]  R427      -1.4015206135809422e-02
    z[0,6,6]  R428      -4.1147151589393616e-01
    z[0,6,6]  R429      -0.648550808429718
    z[0,6,6]  R430      -3.8981980085372925e-01
    z[0,6,6]  R431      6.3916943967342377e-02
    z[0,6,6]  R432      8.4687858819961548e-02
    z[0,6,6]  R433      2.7854385972023010e-01
    z[0,6,6]  R434      -4.9943429231643677e-01
    z[0,6,6]  R435      1.9908805191516876e-01
    z[0,6,6]  R436      3.9190784096717834e-01
    z[0,6,6]  R437      1.1957976222038269e-01
    z[0,6,6]  R438      2.2648532688617706e-01
    z[0,6,6]  R439      -1.2779808603227139e-02
    z[0,6,6]  R440      2.8644669055938721e-01
    z[0,6,6]  R441      3.7128555774688721e-01
    z[0,6,6]  R442      1.8244867026805878e-01
    z[0,6,6]  R443      -1.1804796010255814e-01
    z[0,6,6]  R444      -2.8831705451011658e-01
    z[0,6,6]  R445      -6.0568958520889282e-02
    z[0,6,6]  R446      -0.190096914768219
    z[0,6,6]  R447      5.9414887428283691e-01
    z[0,6,6]  R448      6.4565908908843994e-01
    z[0,6,6]  R449      -2.3918978869915009e-02
    z[0,6,6]  R450      4.1156476736068726e-01
    z[0,6,6]  R451      1.8318559229373932e-01
    z[0,6,6]  R452      -3.9352121949195862e-01
    z[0,6,6]  R453      0.397322416305542
    z[0,6,6]  R454      6.4916145801544189e-01
    z[0,6,6]  R455      1.3663363456726074e-01
    z[0,6,6]  R456      1.1498459428548813e-01
    z[0,6,6]  R457      2.0553120970726013e-01
    z[0,6,6]  R458      2.8817737102508545e-01
    z[0,6,6]  R459      -3.0668967962265015e-01
    z[0,6,6]  R460      -0.300184428691864
    z[0,6,6]  R461      -5.5269223451614380e-01
    z[0,6,6]  R462      5.0016533583402634e-02
    z[0,6,6]  R463      -4.7827857732772827e-01
    z[0,6,6]  R464      -2.7828231453895569e-02
    z[0,6,6]  R465      1.3620495796203613e-02
    z[0,6,6]  R466      5.1132321357727051e-02
    z[0,6,6]  R467      3.1818398833274841e-01
    z[0,6,6]  R468      -8.1356592476367950e-02
    z[0,6,6]  R469      2.5460091233253479e-01
    z[0,6,6]  R470      -1.0346055030822754e-02
    z[0,6,6]  R471      -2.9780656099319458e-01
    z[0,6,6]  R472      2.6816916465759277e-01
    z[0,6,6]  R473      -2.3238374292850494e-01
    z[0,6,6]  R474      -1.3719917833805084e-01
    z[0,6,6]  R475      1.9939646124839783e-01
    z[0,6,6]  R476      -2.9235085844993591e-01
    z[0,6,6]  R477      4.3229696154594421e-01
    z[0,6,6]  R478      1.7052348703145981e-02
    z[0,6,6]  R479      -3.6040824651718140e-01
    z[0,6,6]  R480      5.1182365417480469e-01
    z[0,6,6]  R481      0.343861848115921
    z[0,6,6]  R482      -0.0243021659553051
    z[0,6,6]  R483      -1.8595525622367859e-01
    z[0,6,6]  R484      -4.3452523648738861e-02
    z[0,6,6]  R485      -2.2632901370525360e-01
    z[0,6,6]  R486      1.7174807190895081e-01
    z[0,6,6]  R487      0.0263583455234766
    z[0,6,6]  R488      2.5093618035316467e-01
    z[0,6,6]  R489      -2.2811074554920197e-01
    z[0,6,6]  R490      -7.6790824532508850e-02
    z[0,6,6]  R491      4.0540233254432678e-01
    z[0,6,6]  R492      2.2860527038574219e-01
    z[0,6,6]  R493      -1.0897362232208252e-01
    z[0,6,6]  R494      -7.8589171171188354e-02
    z[0,6,6]  R495      -1.7819654941558838e-01
    z[0,6,6]  R496      -1.2982444465160370e-01
    z[0,6,6]  R497      1.3908928632736206e-01
    z[0,6,6]  R498      2.1789376437664032e-01
    z[0,6,6]  R499      1.9258503615856171e-01
    z[0,6,6]  R500      1.3709321618080139e-01
    z[0,6,6]  R501      -1.3313873112201691e-01
    z[6,0,0]  R2        1
    z[6,0,0]  R56       -1
    z[6,0,0]  R502      -1
    z[6,0,0]  R503      1
    z[6,0,0]  R516      2.0031196996569633e-02
    z[6,0,0]  R517      4.7062397003173828e-01
    z[6,0,0]  R518      -2.0097967982292175e-01
    z[6,0,0]  R519      5.3255504369735718e-01
    z[6,0,0]  R520      -5.3218755871057510e-02
    z[6,0,0]  R521      -5.1938509941101074e-01
    z[6,0,0]  R522      7.6573394238948822e-02
    z[6,0,0]  R523      -6.3433700799942017e-01
    z[6,0,0]  R524      2.9662674292922020e-02
    z[6,0,0]  R525      5.4677534103393555e-01
    z[6,0,0]  R526      1.3562743365764618e-01
    z[6,0,0]  R527      1.5572011470794678e-01
    z[6,0,0]  R528      1.1420238018035889e-01
    z[6,0,0]  R529      2.3889848962426186e-02
    z[6,0,0]  R530      -1.5095965564250946e-01
    z[6,0,0]  R531      -3.1263357400894165e-01
    z[6,0,0]  R532      -2.6962655782699585e-01
    z[6,0,0]  R533      -2.3602253198623657e-01
    z[6,0,0]  R534      -2.9074054956436157e-01
    z[6,0,0]  R535      -3.3436134457588196e-01
    z[6,0,0]  R536      -1.2169932574033737e-01
    z[6,0,0]  R537      1.3749545812606812e-01
    z[6,0,0]  R538      -2.2975397109985352e-01
    z[6,0,0]  R539      -3.8394263386726379e-01
    z[6,0,0]  R540      -2.8801003098487854e-01
    z[6,0,0]  R541      -2.5030487775802612e-01
    z[6,0,0]  R542      5.4529821872711182e-01
    z[6,0,0]  R543      3.7663927674293518e-01
    z[6,0,0]  R544      -2.1984383463859558e-01
    z[6,0,0]  R545      -6.0424816608428955e-01
    z[6,0,0]  R546      3.0019545927643776e-02
    z[6,0,0]  R547      -1.9691903889179230e-01
    z[6,0,0]  R548      7.2666600346565247e-02
    z[6,0,0]  R549      -1.9034427404403687e-01
    z[6,0,0]  R550      1.2171491980552673e-01
    z[6,0,0]  R551      -0.00383838452398777
    z[6,0,0]  R552      -0.226633220911026
    z[6,0,0]  R553      -4.5925104618072510e-01
    z[6,0,0]  R554      -4.1722607612609863e-01
    z[6,0,0]  R555      -2.6629993319511414e-01
    z[6,0,0]  R556      -2.9132384061813354e-01
    z[6,0,0]  R557      -3.7018135190010071e-01
    z[6,0,0]  R558      1.9356849789619446e-01
    z[6,0,0]  R559      -3.1235665082931519e-01
    z[6,0,0]  R560      3.4809085726737976e-01
    z[6,0,0]  R561      5.3691053390502930e-01
    z[6,0,0]  R562      -4.8993730545043945e-01
    z[6,0,0]  R563      5.6050747632980347e-01
    z[6,0,0]  R564      -8.0752231180667877e-02
    z[6,0,0]  R565      -4.3593738228082657e-02
    z[6,0,0]  R566      -7.5358949601650238e-02
    z[6,0,0]  R567      1.5595360100269318e-01
    z[6,0,0]  R568      3.7856489419937134e-01
    z[6,0,0]  R569      5.7903724908828735e-01
    z[6,0,0]  R570      4.5991745591163635e-01
    z[6,0,0]  R571      5.6721532344818115e-01
    z[6,0,0]  R572      7.5176799297332764e-01
    z[6,0,0]  R573      2.5073993206024170e-01
    z[6,0,0]  R574      -5.2961182594299316e-01
    z[6,0,0]  R575      7.4970316886901855e-01
    z[6,0,0]  R576      -3.5578823089599609e-01
    z[6,0,0]  R577      2.3767025768756866e-01
    z[6,0,0]  R578      3.7304529547691345e-01
    z[6,0,0]  R579      1.1755401641130447e-01
    z[6,0,0]  R580      -3.4004725515842438e-02
    z[6,0,0]  R581      2.3310141265392303e-01
    z[6,0,0]  R582      -1.1395020037889481e-01
    z[6,0,0]  R583      -6.6100138425827026e-01
    z[6,0,0]  R584      -6.7390298843383789e-01
    z[6,0,0]  R585      -7.2265905141830444e-01
    z[6,0,0]  R586      2.5237640738487244e-01
    z[6,0,0]  R587      -4.7703701257705688e-01
    z[6,0,0]  R588      5.8202129602432251e-01
    z[6,0,0]  R589      6.7512148618698120e-01
    z[6,0,0]  R590      5.8907490968704224e-01
    z[6,0,0]  R591      3.7437388300895691e-01
    z[6,0,0]  R592      2.2523894906044006e-01
    z[6,0,0]  R593      -5.2928882837295532e-01
    z[6,0,0]  R594      -5.4311645030975342e-01
    z[6,0,0]  R595      -0.449020653963089
    z[6,0,1]  R3        1
    z[6,0,1]  R57       -1
    z[6,0,1]  R504      -1
    z[6,0,1]  R505      1
    z[6,0,1]  R516      -7.8190410137176514e-01
    z[6,0,1]  R517      -3.6997714638710022e-01
    z[6,0,1]  R518      -6.0399180650711060e-01
    z[6,0,1]  R519      -4.4579467177391052e-01
    z[6,0,1]  R520      -8.2918137311935425e-01
    z[6,0,1]  R521      -6.4737731218338013e-01
    z[6,0,1]  R522      -2.8673955798149109e-01
    z[6,0,1]  R523      -5.9463238716125488e-01
    z[6,0,1]  R524      -4.4625002145767212e-01
    z[6,0,1]  R525      -3.0965870618820190e-01
    z[6,0,1]  R526      4.0525174140930176e-01
    z[6,0,1]  R527      2.8946825861930847e-01
    z[6,0,1]  R528      9.2991006374359131e-01
    z[6,0,1]  R529      8.6411511898040771e-01
    z[6,0,1]  R530      8.2175713777542114e-01
    z[6,0,1]  R531      6.9736850261688232e-01
    z[6,0,1]  R532      0.808444619178772
    z[6,0,1]  R533      7.2943145036697388e-01
    z[6,0,1]  R534      5.6239664554595947e-01
    z[6,0,1]  R535      6.5161406993865967e-01
    z[6,0,1]  R536      8.4629094600677490e-01
    z[6,0,1]  R537      8.7107741832733154e-01
    z[6,0,1]  R538      9.1347074508666992e-01
    z[6,0,1]  R539      6.5538221597671509e-01
    z[6,0,1]  R540      8.3171874284744263e-01
    z[6,0,1]  R541      3.9090868830680847e-01
    z[6,0,1]  R542      7.8255093097686768e-01
    z[6,0,1]  R543      3.5327199101448059e-01
    z[6,0,1]  R544      3.1925094127655029e-01
    z[6,0,1]  R545      5.1732963323593140e-01
    z[6,0,1]  R546      8.7808293104171753e-01
    z[6,0,1]  R547      6.3551861047744751e-01
    z[6,0,1]  R548      5.8599531650543213e-01
    z[6,0,1]  R549      8.0284309387207031e-01
    z[6,0,1]  R550      7.7548879384994507e-01
    z[6,0,1]  R551      7.5157040357589722e-01
    z[6,0,1]  R552      7.3652219772338867e-01
    z[6,0,1]  R553      7.1352082490921021e-01
    z[6,0,1]  R554      7.2306710481643677e-01
    z[6,0,1]  R555      3.7456589937210083e-01
    z[6,0,1]  R556      6.7980217933654785e-01
    z[6,0,1]  R557      7.6989412307739258e-01
    z[6,0,1]  R558      0.847685694694519
    z[6,0,1]  R559      0.807413637638092
    z[6,0,1]  R560      3.1038349866867065e-01
    z[6,0,1]  R561      7.4890291690826416e-01
    z[6,0,1]  R562      5.3914952278137207e-01
    z[6,0,1]  R563      1.5823675692081451e-01
    z[6,0,1]  R564      8.0106192827224731e-01
    z[6,0,1]  R565      7.4141615629196167e-01
    z[6,0,1]  R566      9.6793889999389648e-02
    z[6,0,1]  R567      9.5467088976874948e-04
    z[6,0,1]  R568      4.4080372899770737e-02
    z[6,0,1]  R569      3.8586426526308060e-02
    z[6,0,1]  R570      3.5572454333305359e-02
    z[6,0,1]  R571      7.6472297310829163e-02
    z[6,0,1]  R572      5.3024303168058395e-02
    z[6,0,1]  R573      4.7504503279924393e-02
    z[6,0,1]  R574      7.1272291243076324e-02
    z[6,0,1]  R575      -1.6442860662937164e-01
    z[6,0,1]  R576      2.6647645235061646e-01
    z[6,0,1]  R577      -5.1985198259353638e-01
    z[6,0,1]  R578      -1.8105420470237732e-01
    z[6,0,1]  R579      -5.4912024736404419e-01
    z[6,0,1]  R580      -6.2785738706588745e-01
    z[6,0,1]  R581      -3.5683214664459229e-01
    z[6,0,1]  R582      1.5637357532978058e-01
    z[6,0,1]  R583      -3.4449872374534607e-01
    z[6,0,1]  R584      -3.8743022084236145e-01
    z[6,0,1]  R585      -1.1335832625627518e-01
    z[6,0,1]  R586      8.7743246555328369e-01
    z[6,0,1]  R587      7.4273413419723511e-01
    z[6,0,1]  R588      -6.8861061334609985e-01
    z[6,0,1]  R589      -5.6328219175338745e-01
    z[6,0,1]  R590      -5.7809185981750488e-01
    z[6,0,1]  R591      -5.1152777671813965e-01
    z[6,0,1]  R592      -5.5766272544860840e-01
    z[6,0,1]  R593      -7.1173429489135742e-02
    z[6,0,1]  R594      -8.6887432262301445e-03
    z[6,0,1]  R595      -4.6204483509063721e-01
    z[6,0,2]  R4        1
    z[6,0,2]  R58       -1
    z[6,0,2]  R506      -1
    z[6,0,2]  R507      1
    z[6,0,2]  R516      -1.3319614529609680e-01
    z[6,0,2]  R517      -3.3799886703491211e-01
    z[6,0,2]  R518      -2.8119698166847229e-01
    z[6,0,2]  R519      -6.3282884657382965e-03
    z[6,0,2]  R520      -4.1510784626007080e-01
    z[6,0,2]  R521      -2.1796886622905731e-01
    z[6,0,2]  R522      -3.6379560828208923e-02
    z[6,0,2]  R523      3.6675009876489639e-02
    z[6,0,2]  R524      -1.8968142569065094e-01
    z[6,0,2]  R525      -1.4247059822082520e-01
    z[6,0,2]  R526      -1.2563848495483398e-01
    z[6,0,2]  R527      -9.7060143947601318e-02
    z[6,0,2]  R528      -2.1673109382390976e-02
    z[6,0,2]  R529      -4.1682547330856323e-01
    z[6,0,2]  R530      -1.6679960489273071e-01
    z[6,0,2]  R531      -0.431225061416626
    z[6,0,2]  R532      0.111131452023983
    z[6,0,2]  R533      -4.5923840999603271e-01
    z[6,0,2]  R534      -7.5315505266189575e-01
    z[6,0,2]  R535      -5.0678777694702148e-01
    z[6,0,2]  R536      -2.5695204734802246e-01
    z[6,0,2]  R537      -2.2990810871124268e-01
    z[6,0,2]  R538      -9.1658405959606171e-02
    z[6,0,2]  R539      5.6675948202610016e-02
    z[6,0,2]  R540      -5.0259608775377274e-02
    z[6,0,2]  R541      1.0611893236637115e-01
    z[6,0,2]  R542      1.9353662431240082e-01
    z[6,0,2]  R543      1.5623576939105988e-01
    z[6,0,2]  R544      7.5560994446277618e-04
    z[6,0,2]  R545      3.2969883084297180e-01
    z[6,0,2]  R546      -4.0979039669036865e-01
    z[6,0,2]  R547      2.3030509054660797e-01
    z[6,0,2]  R548      4.4043174386024475e-01
    z[6,0,2]  R549      -2.1861056983470917e-01
    z[6,0,2]  R550      -3.9543649554252625e-01
    z[6,0,2]  R551      -4.8836305737495422e-01
    z[6,0,2]  R552      -1.5879217535257339e-03
    z[6,0,2]  R553      -2.4725767970085144e-01
    z[6,0,2]  R554      -1.1703561991453171e-01
    z[6,0,2]  R555      0.0369969867169857
    z[6,0,2]  R556      -3.4943285584449768e-01
    z[6,0,2]  R557      -2.9353508353233337e-01
    z[6,0,2]  R558      -7.9275742173194885e-03
    z[6,0,2]  R559      -2.2706474363803864e-01
    z[6,0,2]  R560      1.2162059545516968e-01
    z[6,0,2]  R561      1.8791253864765167e-01
    z[6,0,2]  R562      3.1081789731979370e-01
    z[6,0,2]  R563      -1.5064038336277008e-01
    z[6,0,2]  R564      4.1153150796890259e-01
    z[6,0,2]  R565      1.6199788451194763e-01
    z[6,0,2]  R566      6.4283972978591919e-01
    z[6,0,2]  R567      2.3409101366996765e-01
    z[6,0,2]  R568      2.7970978617668152e-01
    z[6,0,2]  R569      3.0148291587829590e-01
    z[6,0,2]  R570      0.496791809797287
    z[6,0,2]  R571      5.2066934108734131e-01
    z[6,0,2]  R572      4.2420539259910583e-01
    z[6,0,2]  R573      4.7645160555839539e-01
    z[6,0,2]  R574      2.7403315901756287e-01
    z[6,0,2]  R575      -4.6178337931632996e-01
    z[6,0,2]  R576      -1.3109797239303589e-01
    z[6,0,2]  R577      5.8739078044891357e-01
    z[6,0,2]  R578      2.1813666820526123e-01
    z[6,0,2]  R579      -2.7783304452896118e-01
    z[6,0,2]  R580      -2.8996571898460388e-01
    z[6,0,2]  R581      -5.2452516555786133e-01
    z[6,0,2]  R582      -0.766013503074646
    z[6,0,2]  R583      -2.6005801558494568e-01
    z[6,0,2]  R584      -3.7955591082572937e-01
    z[6,0,2]  R585      -5.3356665372848511e-01
    z[6,0,2]  R586      -1.0671491920948029e-01
    z[6,0,2]  R587      -2.4845926463603973e-01
    z[6,0,2]  R588      1.1095648258924484e-01
    z[6,0,2]  R589      -5.9024691581726074e-02
    z[6,0,2]  R590      -1.1720573902130127e-01
    z[6,0,2]  R591      3.5954797267913818e-01
    z[6,0,2]  R592      -1.7758095264434814e-01
    z[6,0,2]  R593      8.2312017679214478e-01
    z[6,0,2]  R594      5.6279665231704712e-01
    z[6,0,2]  R595      6.3541257381439209e-01
    z[6,0,3]  R5        1
    z[6,0,3]  R59       -1
    z[6,0,3]  R508      -1
    z[6,0,3]  R509      1
    z[6,0,3]  R516      2.4851515889167786e-01
    z[6,0,3]  R517      4.2799273133277893e-01
    z[6,0,3]  R518      1.8995456397533417e-01
    z[6,0,3]  R519      0.647131085395813
    z[6,0,3]  R520      -3.3350121229887009e-02
    z[6,0,3]  R521      -1.3669732958078384e-02
    z[6,0,3]  R522      8.5663646459579468e-01
    z[6,0,3]  R523      -2.4247553944587708e-01
    z[6,0,3]  R524      1.1043892055749893e-01
    z[6,0,3]  R525      4.7907626628875732e-01
    z[6,0,3]  R526      -1.8333104252815247e-01
    z[6,0,3]  R527      -5.6412893533706665e-01
    z[6,0,3]  R528      1.4555303752422333e-01
    z[6,0,3]  R529      1.7127810278907418e-03
    z[6,0,3]  R530      -2.4269069731235504e-01
    z[6,0,3]  R531      1.1815001815557480e-01
    z[6,0,3]  R532      2.1872974932193756e-01
    z[6,0,3]  R533      -2.4208946526050568e-01
    z[6,0,3]  R534      1.3070549070835114e-01
    z[6,0,3]  R535      3.3484759926795959e-01
    z[6,0,3]  R536      3.0880925059318542e-01
    z[6,0,3]  R537      6.7955709993839264e-02
    z[6,0,3]  R538      -1.2718668580055237e-01
    z[6,0,3]  R539      3.0917921662330627e-01
    z[6,0,3]  R540      2.5221493840217590e-01
    z[6,0,3]  R541      -7.5860089063644409e-01
    z[6,0,3]  R542      -0.0707196369767189
    z[6,0,3]  R543      -4.6028646826744080e-01
    z[6,0,3]  R544      -7.2013401985168457e-01
    z[6,0,3]  R545      -3.5336297750473022e-01
    z[6,0,3]  R546      1.3543894886970520e-01
    z[6,0,3]  R547      -3.0731633305549622e-01
    z[6,0,3]  R548      2.5043663382530212e-01
    z[6,0,3]  R549      1.9921740889549255e-01
    z[6,0,3]  R550      -2.3116227984428406e-01
    z[6,0,3]  R551      -2.2955887019634247e-01
    z[6,0,3]  R552      -1.5074518509209156e-02
    z[6,0,3]  R553      0.347474604845047
    z[6,0,3]  R554      2.0738035440444946e-01
    z[6,0,3]  R555      -0.728060245513916
    z[6,0,3]  R556      2.4625155329704285e-01
    z[6,0,3]  R557      2.9551351070404053e-01
    z[6,0,3]  R558      0.180172398686409
    z[6,0,3]  R559      -6.9118700921535492e-02
    z[6,0,3]  R560      -4.9093249440193176e-01
    z[6,0,3]  R561      8.9788466691970825e-02
    z[6,0,3]  R562      -0.504069983959198
    z[6,0,3]  R563      -5.8053833246231079e-01
    z[6,0,3]  R564      5.4022260010242462e-02
    z[6,0,3]  R565      7.7676810324192047e-02
    z[6,0,3]  R566      -1.2030338868498802e-02
    z[6,0,3]  R567      7.1206682920455933e-01
    z[6,0,3]  R568      4.6227118372917175e-01
    z[6,0,3]  R569      4.6484208106994629e-01
    z[6,0,3]  R570      1.7022161185741425e-01
    z[6,0,3]  R571      -3.9080867171287537e-01
    z[6,0,3]  R572      -2.2143563628196716e-01
    z[6,0,3]  R573      -3.1327739357948303e-01
    z[6,0,3]  R574      -1.8965117633342743e-01
    z[6,0,3]  R575      4.0039411187171936e-01
    z[6,0,3]  R576      -2.8232035040855408e-01
    z[6,0,3]  R577      -7.3677316308021545e-02
    z[6,0,3]  R578      -2.8459736704826355e-01
    z[6,0,3]  R579      -5.1777446269989014e-01
    z[6,0,3]  R580      -2.0285290479660034e-01
    z[6,0,3]  R581      -6.5406644344329834e-01
    z[6,0,3]  R582      -3.8228946924209595e-01
    z[6,0,3]  R583      7.9646319150924683e-02
    z[6,0,3]  R584      2.0401114225387573e-01
    z[6,0,3]  R585      -0.0553707480430603
    z[6,0,3]  R586      -1.2512814998626709e-01
    z[6,0,3]  R587      2.2900892794132233e-01
    z[6,0,3]  R588      -1.9740380346775055e-01
    z[6,0,3]  R589      -2.7225196361541748e-01
    z[6,0,3]  R590      -4.1527125239372253e-01
    z[6,0,3]  R591      2.8835743665695190e-01
    z[6,0,3]  R592      -2.7360485401004553e-03
    z[6,0,3]  R593      -1.1131959408521652e-01
    z[6,0,3]  R594      1.2222599983215332e-01
    z[6,0,3]  R595      -1.0076513141393661e-01
    z[6,0,4]  R6        1
    z[6,0,4]  R60       -1
    z[6,0,4]  R510      -1
    z[6,0,4]  R511      1
    z[6,0,4]  R516      -3.6935889720916748e-01
    z[6,0,4]  R517      -4.3102037906646729e-01
    z[6,0,4]  R518      -0.0522281676530838
    z[6,0,4]  R519      1.3389755785465240e-01
    z[6,0,4]  R520      3.5002410411834717e-01
    z[6,0,4]  R521      -3.5380309820175171e-01
    z[6,0,4]  R522      2.3240806162357330e-01
    z[6,0,4]  R523      1.6689166426658630e-01
    z[6,0,4]  R524      -7.7786058187484741e-01
    z[6,0,4]  R525      1.5104007720947266e-01
    z[6,0,4]  R526      2.6192682981491089e-01
    z[6,0,4]  R527      1.8555636703968048e-01
    z[6,0,4]  R528      -1.4745970070362091e-01
    z[6,0,4]  R529      -2.2623822093009949e-01
    z[6,0,4]  R530      -3.6451452970504761e-01
    z[6,0,4]  R531      -1.0220992378890514e-02
    z[6,0,4]  R532      -4.1237783432006836e-01
    z[6,0,4]  R533      -2.7822852134704590e-01
    z[6,0,4]  R534      -0.0856996551156044
    z[6,0,4]  R535      3.4416213631629944e-02
    z[6,0,4]  R536      -1.8395955860614777e-01
    z[6,0,4]  R537      -1.9225528836250305e-01
    z[6,0,4]  R538      -2.4892230331897736e-01
    z[6,0,4]  R539      -3.6046814918518066e-01
    z[6,0,4]  R540      -2.4335388839244843e-01
    z[6,0,4]  R541      -7.2335690259933472e-02
    z[6,0,4]  R542      1.1693262308835983e-01
    z[6,0,4]  R543      -3.5507228970527649e-01
    z[6,0,4]  R544      2.4996544420719147e-01
    z[6,0,4]  R545      -4.8424351960420609e-02
    z[6,0,4]  R546      -1.8865896761417389e-01
    z[6,0,4]  R547      -3.0305463075637817e-01
    z[6,0,4]  R548      -3.8017854094505310e-01
    z[6,0,4]  R549      -4.1649696230888367e-01
    z[6,0,4]  R550      -3.3740437030792236e-01
    z[6,0,4]  R551      -2.9558593034744263e-01
    z[6,0,4]  R552      -4.2544689774513245e-01
    z[6,0,4]  R553      -1.5303482115268707e-01
    z[6,0,4]  R554      -1.2073575705289841e-01
    z[6,0,4]  R555      2.4712586402893066e-01
    z[6,0,4]  R556      -2.2771361470222473e-01
    z[6,0,4]  R557      -1.0204493999481201e-01
    z[6,0,4]  R558      -4.4191029667854309e-01
    z[6,0,4]  R559      -2.8548830747604370e-01
    z[6,0,4]  R560      -4.4406521320343018e-01
    z[6,0,4]  R561      2.1089971065521240e-01
    z[6,0,4]  R562      -2.5434973835945129e-01
    z[6,0,4]  R563      2.2958418726921082e-01
    z[6,0,4]  R564      3.7069392204284668e-01
    z[6,0,4]  R565      6.0400164127349854e-01
    z[6,0,4]  R566      -3.5819873213768005e-01
    z[6,0,4]  R567      8.4051378071308136e-02
    z[6,0,4]  R568      8.7837286293506622e-02
    z[6,0,4]  R569      -5.7816648483276367e-01
    z[6,0,4]  R570      -3.6483651399612427e-01
    z[6,0,4]  R571      2.0078261196613312e-01
    z[6,0,4]  R572      1.1413767933845520e-01
    z[6,0,4]  R573      -3.7626230716705322e-01
    z[6,0,4]  R574      -9.2131003737449646e-02
    z[6,0,4]  R575      1.4716595411300659e-01
    z[6,0,4]  R576      6.9416522979736328e-01
    z[6,0,4]  R577      1.3592466711997986e-01
    z[6,0,4]  R578      3.6502486467361450e-01
    z[6,0,4]  R579      -4.6036940813064575e-01
    z[6,0,4]  R580      7.7058456838130951e-02
    z[6,0,4]  R581      -3.0732330679893494e-01
    z[6,0,4]  R582      -3.5659581422805786e-01
    z[6,0,4]  R583      -5.9570330381393433e-01
    z[6,0,4]  R584      -3.5770753026008606e-01
    z[6,0,4]  R585      -1.8804828822612762e-01
    z[6,0,4]  R586      -1.5170462429523468e-01
    z[6,0,4]  R587      3.0439239740371704e-01
    z[6,0,4]  R588      2.2947153449058533e-01
    z[6,0,4]  R589      1.3315358757972717e-01
    z[6,0,4]  R590      -0.309390664100647
    z[6,0,4]  R591      2.5706894695758820e-02
    z[6,0,4]  R592      4.2895305156707764e-01
    z[6,0,4]  R593      5.7034876197576523e-02
    z[6,0,4]  R594      -3.9720979332923889e-01
    z[6,0,4]  R595      3.2676732540130615e-01
    z[6,0,5]  R7        1
    z[6,0,5]  R61       -1
    z[6,0,5]  R512      -1
    z[6,0,5]  R513      1
    z[6,0,5]  R516      -1.3205623626708984e-01
    z[6,0,5]  R517      2.3775672540068626e-02
    z[6,0,5]  R518      -2.3560172319412231e-01
    z[6,0,5]  R519      -2.4947191774845123e-01
    z[6,0,5]  R520      -2.1468194201588631e-02
    z[6,0,5]  R521      -3.0987852811813354e-01
    z[6,0,5]  R522      1.9926816225051880e-01
    z[6,0,5]  R523      2.4895383417606354e-01
    z[6,0,5]  R524      -2.3796521127223969e-01
    z[6,0,5]  R525      1.6448259353637695e-01
    z[6,0,5]  R526      -8.3478963375091553e-01
    z[6,0,5]  R527      -5.4874008893966675e-01
    z[6,0,5]  R528      -2.7937579154968262e-01
    z[6,0,5]  R529      1.6618889570236206e-01
    z[6,0,5]  R530      -2.8234788775444031e-01
    z[6,0,5]  R531      -3.3864060044288635e-01
    z[6,0,5]  R532      -1.9196757674217224e-01
    z[6,0,5]  R533      -2.1979844197630882e-02
    z[6,0,5]  R534      -8.6034417152404785e-02
    z[6,0,5]  R535      -6.9077193737030029e-02
    z[6,0,5]  R536      -4.2867638170719147e-02
    z[6,0,5]  R537      -0.271806925535202
    z[6,0,5]  R538      -8.6144261062145233e-02
    z[6,0,5]  R539      -3.9314371347427368e-01
    z[6,0,5]  R540      1.2027243524789810e-01
    z[6,0,5]  R541      7.5420483946800232e-02
    z[6,0,5]  R542      1.8396285176277161e-01
    z[6,0,5]  R543      4.9101737141609192e-01
    z[6,0,5]  R544      -8.1900522112846375e-02
    z[6,0,5]  R545      -1.1446280032396317e-01
    z[6,0,5]  R546      7.4930049479007721e-02
    z[6,0,5]  R547      -0.532384991645813
    z[6,0,5]  R548      4.9820342659950256e-01
    z[6,0,5]  R549      0.0839017704129219
    z[6,0,5]  R550      -1.7509314417839050e-01
    z[6,0,5]  R551      -2.3635946214199066e-01
    z[6,0,5]  R552      -4.0245339274406433e-01
    z[6,0,5]  R553      -1.5049065649509430e-01
    z[6,0,5]  R554      -4.7530877590179443e-01
    z[6,0,5]  R555      -1.7866681516170502e-01
    z[6,0,5]  R556      -4.0760576725006104e-01
    z[6,0,5]  R557      -2.7285388112068176e-01
    z[6,0,5]  R558      -9.9871069192886353e-02
    z[6,0,5]  R559      -2.8446984291076660e-01
    z[6,0,5]  R560      5.5914241075515747e-01
    z[6,0,5]  R561      2.0898316800594330e-01
    z[6,0,5]  R562      -8.0084212124347687e-02
    z[6,0,5]  R563      4.5964911580085754e-01
    z[6,0,5]  R564      1.5262268483638763e-01
    z[6,0,5]  R565      1.8325030803680420e-01
    z[6,0,5]  R566      -1.2088346481323242e-01
    z[6,0,5]  R567      -6.2800031900405884e-01
    z[6,0,5]  R568      -4.0164360404014587e-01
    z[6,0,5]  R569      -1.0383608937263489e-01
    z[6,0,5]  R570      -5.4557675123214722e-01
    z[6,0,5]  R571      -4.5615857839584351e-01
    z[6,0,5]  R572      1.4392022788524628e-01
    z[6,0,5]  R573      2.1801939606666565e-01
    z[6,0,5]  R574      -6.6552406549453735e-01
    z[6,0,5]  R575      -1.0773006826639175e-01
    z[6,0,5]  R576      4.6527001261711121e-01
    z[6,0,5]  R577      4.7618106007575989e-01
    z[6,0,5]  R578      5.6284952163696289e-01
    z[6,0,5]  R579      -2.9629451036453247e-01
    z[6,0,5]  R580      -5.6557911634445190e-01
    z[6,0,5]  R581      8.1596568226814270e-02
    z[6,0,5]  R582      -2.2623999416828156e-01
    z[6,0,5]  R583      1.2408995628356934e-01
    z[6,0,5]  R584      -7.9403780400753021e-03
    z[6,0,5]  R585      -6.2764868140220642e-02
    z[6,0,5]  R586      2.8822100162506104e-01
    z[6,0,5]  R587      3.8251818623393774e-03
    z[6,0,5]  R588      1.7396403709426522e-03
    z[6,0,5]  R589      3.5765978693962097e-01
    z[6,0,5]  R590      2.7456291019916534e-02
    z[6,0,5]  R591      1.7912285029888153e-01
    z[6,0,5]  R592      7.6556608080863953e-02
    z[6,0,5]  R593      1.4506430923938751e-01
    z[6,0,5]  R594      -2.1472917497158051e-01
    z[6,0,5]  R595      -1.7509551346302032e-01
    z[6,0,6]  R8        1
    z[6,0,6]  R62       -1
    z[6,0,6]  R514      -1
    z[6,0,6]  R515      1
    z[6,0,6]  R516      -3.9352121949195862e-01
    z[6,0,6]  R517      0.397322416305542
    z[6,0,6]  R518      6.4916145801544189e-01
    z[6,0,6]  R519      1.3663363456726074e-01
    z[6,0,6]  R520      1.1498459428548813e-01
    z[6,0,6]  R521      2.0553120970726013e-01
    z[6,0,6]  R522      2.8817737102508545e-01
    z[6,0,6]  R523      -3.0668967962265015e-01
    z[6,0,6]  R524      -0.300184428691864
    z[6,0,6]  R525      -5.5269223451614380e-01
    z[6,0,6]  R526      5.0016533583402634e-02
    z[6,0,6]  R527      -4.7827857732772827e-01
    z[6,0,6]  R528      -2.7828231453895569e-02
    z[6,0,6]  R529      1.3620495796203613e-02
    z[6,0,6]  R530      5.1132321357727051e-02
    z[6,0,6]  R531      3.1818398833274841e-01
    z[6,0,6]  R532      -8.1356592476367950e-02
    z[6,0,6]  R533      2.5460091233253479e-01
    z[6,0,6]  R534      -1.0346055030822754e-02
    z[6,0,6]  R535      -2.9780656099319458e-01
    z[6,0,6]  R536      2.6816916465759277e-01
    z[6,0,6]  R537      -2.3238374292850494e-01
    z[6,0,6]  R538      -1.3719917833805084e-01
    z[6,0,6]  R539      1.9939646124839783e-01
    z[6,0,6]  R540      -2.9235085844993591e-01
    z[6,0,6]  R541      4.3229696154594421e-01
    z[6,0,6]  R542      1.7052348703145981e-02
    z[6,0,6]  R543      -3.6040824651718140e-01
    z[6,0,6]  R544      5.1182365417480469e-01
    z[6,0,6]  R545      0.343861848115921
    z[6,0,6]  R546      -0.0243021659553051
    z[6,0,6]  R547      -1.8595525622367859e-01
    z[6,0,6]  R548      -4.3452523648738861e-02
    z[6,0,6]  R549      -2.2632901370525360e-01
    z[6,0,6]  R550      1.7174807190895081e-01
    z[6,0,6]  R551      0.0263583455234766
    z[6,0,6]  R552      2.5093618035316467e-01
    z[6,0,6]  R553      -2.2811074554920197e-01
    z[6,0,6]  R554      -7.6790824532508850e-02
    z[6,0,6]  R555      4.0540233254432678e-01
    z[6,0,6]  R556      2.2860527038574219e-01
    z[6,0,6]  R557      -1.0897362232208252e-01
    z[6,0,6]  R558      -7.8589171171188354e-02
    z[6,0,6]  R559      -1.7819654941558838e-01
    z[6,0,6]  R560      -1.2982444465160370e-01
    z[6,0,6]  R561      1.3908928632736206e-01
    z[6,0,6]  R562      2.1789376437664032e-01
    z[6,0,6]  R563      1.9258503615856171e-01
    z[6,0,6]  R564      1.3709321618080139e-01
    z[6,0,6]  R565      -1.3313873112201691e-01
    z[6,0,6]  R566      0.654710054397583
    z[6,0,6]  R567      1.1131328344345093e-01
    z[6,0,6]  R568      -6.2751924991607666e-01
    z[6,0,6]  R569      -1.0582274943590164e-01
    z[6,0,6]  R570      -2.8403052687644958e-01
    z[6,0,6]  R571      -1.4015206135809422e-02
    z[6,0,6]  R572      -4.1147151589393616e-01
    z[6,0,6]  R573      -0.648550808429718
    z[6,0,6]  R574      -3.8981980085372925e-01
    z[6,0,6]  R575      6.3916943967342377e-02
    z[6,0,6]  R576      8.4687858819961548e-02
    z[6,0,6]  R577      2.7854385972023010e-01
    z[6,0,6]  R578      -4.9943429231643677e-01
    z[6,0,6]  R579      1.9908805191516876e-01
    z[6,0,6]  R580      3.9190784096717834e-01
    z[6,0,6]  R581      1.1957976222038269e-01
    z[6,0,6]  R582      2.2648532688617706e-01
    z[6,0,6]  R583      -1.2779808603227139e-02
    z[6,0,6]  R584      2.8644669055938721e-01
    z[6,0,6]  R585      3.7128555774688721e-01
    z[6,0,6]  R586      1.8244867026805878e-01
    z[6,0,6]  R587      -1.1804796010255814e-01
    z[6,0,6]  R588      -2.8831705451011658e-01
    z[6,0,6]  R589      -6.0568958520889282e-02
    z[6,0,6]  R590      -0.190096914768219
    z[6,0,6]  R591      5.9414887428283691e-01
    z[6,0,6]  R592      6.4565908908843994e-01
    z[6,0,6]  R593      -2.3918978869915009e-02
    z[6,0,6]  R594      4.1156476736068726e-01
    z[6,0,6]  R595      1.8318559229373932e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R640      -1
    z[1,2,0]  R641      1
    z[1,2,0]  R654      4.8762276768684387e-01
    z[1,2,0]  R655      5.3526413440704346e-01
    z[1,2,0]  R656      4.7786450386047363e-01
    z[1,2,0]  R657      4.3266192078590393e-01
    z[1,2,0]  R658      4.8137810826301575e-01
    z[1,2,0]  R659      4.4484078884124756e-01
    z[1,2,0]  R660      2.2758446633815765e-01
    z[1,2,0]  R661      -3.2156670093536377e-01
    z[1,2,0]  R662      -6.7632973194122314e-02
    z[1,2,0]  R663      -1.2362013012170792e-01
    z[1,2,0]  R664      6.5048910677433014e-02
    z[1,2,0]  R665      -7.9278725385665894e-01
    z[1,2,0]  R666      -8.3439606428146362e-01
    z[1,2,0]  R667      -8.2489007711410522e-01
    z[1,2,0]  R668      -6.8961602449417114e-01
    z[1,2,0]  R669      -7.8425419330596924e-01
    z[1,2,0]  R670      -6.8020766973495483e-01
    z[1,2,0]  R671      -7.2894531488418579e-01
    z[1,2,0]  R672      -8.1985729932785034e-01
    z[1,2,0]  R673      -0.830944299697876
    z[1,2,0]  R674      1.1360311508178711e-01
    z[1,2,0]  R675      1.3797410763800144e-02
    z[1,2,0]  R676      -4.2373758554458618e-01
    z[1,2,0]  R677      -3.0192825198173523e-01
    z[1,2,0]  R678      -6.3382869958877563e-01
    z[1,2,0]  R679      -6.9172859191894531e-01
    z[1,2,0]  R680      -7.5065809488296509e-01
    z[1,2,0]  R681      -8.2509487867355347e-01
    z[1,2,0]  R682      -0.679706335067749
    z[1,2,0]  R683      -9.4545549154281616e-01
    z[1,2,0]  R684      0.0442180261015892
    z[1,2,0]  R685      -2.0517329871654510e-01
    z[1,2,0]  R686      -9.0681433677673340e-01
    z[1,2,0]  R687      -7.8480494022369385e-01
    z[1,2,0]  R688      -8.7693107128143311e-01
    z[1,2,0]  R689      -7.3673528432846069e-01
    z[1,2,0]  R690      -6.9118893146514893e-01
    z[1,2,0]  R691      -7.5684589147567749e-01
    z[1,2,0]  R692      -4.3756476044654846e-01
    z[1,2,0]  R693      -7.0736819505691528e-01
    z[1,2,0]  R694      -0.490815132856369
    z[1,2,0]  R695      -3.5189476609230042e-01
    z[1,2,0]  R696      -6.9665157794952393e-01
    z[1,2,0]  R697      -4.9690628051757812e-01
    z[1,2,0]  R698      -9.0260022878646851e-01
    z[1,2,0]  R699      -4.7346779704093933e-01
    z[1,2,0]  R700      5.3116691112518311e-01
    z[1,2,0]  R701      3.8319456577301025e-01
    z[1,2,0]  R702      1.0995641350746155e-01
    z[1,2,0]  R703      6.0583537817001343e-01
    z[1,2,0]  R704      1.7992122471332550e-01
    z[1,2,0]  R705      2.3500937223434448e-01
    z[1,2,0]  R706      8.7343639135360718e-01
    z[1,2,0]  R707      5.2674150466918945e-01
    z[1,2,0]  R708      5.6507551670074463e-01
    z[1,2,0]  R709      8.3293646574020386e-01
    z[1,2,0]  R710      7.2959405183792114e-01
    z[1,2,0]  R711      4.4843098521232605e-01
    z[1,2,0]  R712      8.3474791049957275e-01
    z[1,2,0]  R713      6.5822309255599976e-01
    z[1,2,0]  R714      6.0884815454483032e-01
    z[1,2,0]  R715      4.4912764430046082e-01
    z[1,2,0]  R716      2.8068712353706360e-01
    z[1,2,0]  R717      4.7725030779838562e-01
    z[1,2,0]  R718      5.1029217243194580e-01
    z[1,2,0]  R719      4.9956426024436951e-01
    z[1,2,0]  R720      1.3929453492164612e-01
    z[1,2,0]  R721      2.5833564996719360e-01
    z[1,2,0]  R722      3.2290109992027283e-01
    z[1,2,0]  R723      5.7730823755264282e-01
    z[1,2,0]  R724      5.5724453926086426e-01
    z[1,2,0]  R725      1.7468205094337463e-01
    z[1,2,0]  R726      4.3995073437690735e-01
    z[1,2,0]  R727      7.3243713378906250e-01
    z[1,2,0]  R728      7.2987407445907593e-01
    z[1,2,0]  R729      5.0881814956665039e-01
    z[1,2,0]  R730      4.4130480289459229e-01
    z[1,2,0]  R731      7.2296333312988281e-01
    z[1,2,0]  R732      4.8452901840209961e-01
    z[1,2,0]  R733      4.5559036731719971e-01
    z[1,2,0]  R734      4.4959786534309387e-01
    z[1,2,0]  R735      8.5046076774597168e-01
    z[1,2,0]  R736      3.8043540716171265e-01
    z[1,2,0]  R737      6.8055588006973267e-01
    z[1,2,0]  R738      6.8704360723495483e-01
    z[1,2,0]  R739      1.5266070840880275e-03
    z[1,2,0]  R740      5.1778149604797363e-01
    z[1,2,0]  R741      3.1060710549354553e-01
    z[1,2,0]  R742      2.0471620559692383e-01
    z[1,2,0]  R743      -1.1524931527674198e-02
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R642      -1
    z[1,2,1]  R643      1
    z[1,2,1]  R654      3.1182876229286194e-01
    z[1,2,1]  R655      3.1679326295852661e-01
    z[1,2,1]  R656      2.8544783592224121e-01
    z[1,2,1]  R657      3.0021238327026367e-01
    z[1,2,1]  R658      3.7033927440643311e-01
    z[1,2,1]  R659      2.9730680584907532e-01
    z[1,2,1]  R660      2.9784691333770752e-01
    z[1,2,1]  R661      -0.76842200756073
    z[1,2,1]  R662      -7.2994166612625122e-01
    z[1,2,1]  R663      -6.3500648736953735e-01
    z[1,2,1]  R664      5.7323312759399414e-01
    z[1,2,1]  R665      -2.5927681475877762e-02
    z[1,2,1]  R666      7.2741672396659851e-02
    z[1,2,1]  R667      -1.9623391330242157e-01
    z[1,2,1]  R668      -2.3165687918663025e-02
    z[1,2,1]  R669      6.2084991484880447e-02
    z[1,2,1]  R670      -1.1389282345771790e-01
    z[1,2,1]  R671      1.4568357169628143e-01
    z[1,2,1]  R672      -0.0789308175444603
    z[1,2,1]  R673      -3.2679599523544312e-01
    z[1,2,1]  R674      5.8238863945007324e-01
    z[1,2,1]  R675      3.8293415307998657e-01
    z[1,2,1]  R676      -8.1575781106948853e-01
    z[1,2,1]  R677      -7.2446751594543457e-01
    z[1,2,1]  R678      -2.1643690764904022e-01
    z[1,2,1]  R679      -3.0542570352554321e-01
    z[1,2,1]  R680      -2.4331867694854736e-01
    z[1,2,1]  R681      -2.3857049643993378e-01
    z[1,2,1]  R682      -2.2109535336494446e-01
    z[1,2,1]  R683      -2.5237387418746948e-01
    z[1,2,1]  R684      5.4887527227401733e-01
    z[1,2,1]  R685      -0.756986141204834
    z[1,2,1]  R686      -2.5298237800598145e-01
    z[1,2,1]  R687      -0.319732129573822
    z[1,2,1]  R688      -4.1124969720840454e-01
    z[1,2,1]  R689      -3.0991527438163757e-01
    z[1,2,1]  R690      -4.4507080316543579e-01
    z[1,2,1]  R691      -2.6714438199996948e-01
    z[1,2,1]  R692      -7.5146359205245972e-01
    z[1,2,1]  R693      -3.3937805891036987e-01
    z[1,2,1]  R694      -3.4972810745239258e-01
    z[1,2,1]  R695      -2.1696461737155914e-01
    z[1,2,1]  R696      -4.7060576081275940e-01
    z[1,2,1]  R697      -1.8660506606101990e-01
    z[1,2,1]  R698      -2.4373726546764374e-01
    z[1,2,1]  R699      -1.9525794684886932e-01
    z[1,2,1]  R700      -4.0694692730903625e-01
    z[1,2,1]  R701      -3.9544859528541565e-01
    z[1,2,1]  R702      7.0127922296524048e-01
    z[1,2,1]  R703      6.4099001884460449e-01
    z[1,2,1]  R704      -6.8807423114776611e-01
    z[1,2,1]  R705      -5.1114434003829956e-01
    z[1,2,1]  R706      3.2021689414978027e-01
    z[1,2,1]  R707      3.0431634187698364e-01
    z[1,2,1]  R708      6.7377209663391113e-02
    z[1,2,1]  R709      1.9425563514232635e-01
    z[1,2,1]  R710      -2.4642951320856810e-03
    z[1,2,1]  R711      4.8408966511487961e-02
    z[1,2,1]  R712      -0.149896040558815
    z[1,2,1]  R713      6.5576724708080292e-02
    z[1,2,1]  R714      6.2107443809509277e-01
    z[1,2,1]  R715      7.3644739389419556e-01
    z[1,2,1]  R716      7.7415573596954346e-01
    z[1,2,1]  R717      7.1338462829589844e-01
    z[1,2,1]  R718      6.2748807668685913e-01
    z[1,2,1]  R719      4.8782244324684143e-01
    z[1,2,1]  R720      6.2506145238876343e-01
    z[1,2,1]  R721      7.5948399305343628e-01
    z[1,2,1]  R722      7.4792701005935669e-01
    z[1,2,1]  R723      5.9795522689819336e-01
    z[1,2,1]  R724      -5.2683621644973755e-01
    z[1,2,1]  R725      8.2538014650344849e-01
    z[1,2,1]  R726      2.9217118024826050e-01
    z[1,2,1]  R727      1.2891595065593719e-01
    z[1,2,1]  R728      4.1784065961837769e-01
    z[1,2,1]  R729      4.3310755491256714e-01
    z[1,2,1]  R730      3.7485957145690918e-01
    z[1,2,1]  R731      7.1263968944549561e-02
    z[1,2,1]  R732      1.6778342425823212e-01
    z[1,2,1]  R733      1.9675391912460327e-01
    z[1,2,1]  R734      6.7743313312530518e-01
    z[1,2,1]  R735      2.3330783843994141e-01
    z[1,2,1]  R736      6.2655168771743774e-01
    z[1,2,1]  R737      2.1196378767490387e-01
    z[1,2,1]  R738      5.6680923700332642e-01
    z[1,2,1]  R739      3.3163674175739288e-02
    z[1,2,1]  R740      7.7464574575424194e-01
    z[1,2,1]  R741      8.4533131122589111e-01
    z[1,2,1]  R742      0.745384931564331
    z[1,2,1]  R743      7.7667677402496338e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R644      -1
    z[1,2,2]  R645      1
    z[1,2,2]  R654      -3.4188345074653625e-01
    z[1,2,2]  R655      1.6730089485645294e-01
    z[1,2,2]  R656      -3.2735043764114380e-01
    z[1,2,2]  R657      -1.1577780544757843e-01
    z[1,2,2]  R658      0.0608777217566967
    z[1,2,2]  R659      -4.4989970326423645e-01
    z[1,2,2]  R660      -6.7227369546890259e-01
    z[1,2,2]  R661      -4.3394207954406738e-01
    z[1,2,2]  R662      9.9671795964241028e-02
    z[1,2,2]  R663      -9.5330648124217987e-02
    z[1,2,2]  R664      6.7910069227218628e-01
    z[1,2,2]  R665      1.8427358567714691e-01
    z[1,2,2]  R666      3.8594490289688110e-01
    z[1,2,2]  R667      -1.6113594756461680e-04
    z[1,2,2]  R668      4.3455675244331360e-01
    z[1,2,2]  R669      2.2913278639316559e-01
    z[1,2,2]  R670      4.1522794961929321e-01
    z[1,2,2]  R671      4.0534734725952148e-01
    z[1,2,2]  R672      3.4077703952789307e-01
    z[1,2,2]  R673      2.7540290355682373e-01
    z[1,2,2]  R674      -0.0981765165925026
    z[1,2,2]  R675      -1.3510827720165253e-01
    z[1,2,2]  R676      1.9192628562450409e-02
    z[1,2,2]  R677      0.0211052056401968
    z[1,2,2]  R678      -0.00716095557436347
    z[1,2,2]  R679      -2.5757923722267151e-01
    z[1,2,2]  R680      2.5159388780593872e-01
    z[1,2,2]  R681      4.9874968826770782e-02
    z[1,2,2]  R682      1.4634981751441956e-01
    z[1,2,2]  R683      1.1708619445562363e-01
    z[1,2,2]  R684      4.4962030649185181e-01
    z[1,2,2]  R685      -1.3260406255722046e-01
    z[1,2,2]  R686      -4.1260927915573120e-02
    z[1,2,2]  R687      -2.3052366077899933e-01
    z[1,2,2]  R688      -4.2285788804292679e-02
    z[1,2,2]  R689      9.9219158291816711e-02
    z[1,2,2]  R690      2.9561412334442139e-01
    z[1,2,2]  R691      2.1575149893760681e-01
    z[1,2,2]  R692      2.2460678592324257e-02
    z[1,2,2]  R693      -3.4787702560424805e-01
    z[1,2,2]  R694      -4.9553540349006653e-01
    z[1,2,2]  R695      -6.0714691877365112e-01
    z[1,2,2]  R696      -2.7851250767707825e-01
    z[1,2,2]  R697      -5.6539791822433472e-01
    z[1,2,2]  R698      -3.0870464444160461e-01
    z[1,2,2]  R699      0.218109130859375
    z[1,2,2]  R700      -6.6253411769866943e-01
    z[1,2,2]  R701      9.3164056539535522e-02
    z[1,2,2]  R702      -3.3220261335372925e-01
    z[1,2,2]  R703      3.8047355413436890e-01
    z[1,2,2]  R704      2.3348897695541382e-01
    z[1,2,2]  R705      2.8866133093833923e-01
    z[1,2,2]  R706      6.9517545402050018e-02
    z[1,2,2]  R707      4.1357865929603577e-01
    z[1,2,2]  R708      5.2172702550888062e-01
    z[1,2,2]  R709      -6.8027332425117493e-02
    z[1,2,2]  R710      4.4569137692451477e-01
    z[1,2,2]  R711      5.8127278089523315e-01
    z[1,2,2]  R712      1.4774306118488312e-01
    z[1,2,2]  R713      1.8644580245018005e-01
    z[1,2,2]  R714      -6.2145132571458817e-02
    z[1,2,2]  R715      8.5463829338550568e-02
    z[1,2,2]  R716      -5.0757521390914917e-01
    z[1,2,2]  R717      -8.5780851542949677e-02
    z[1,2,2]  R718      3.4224835038185120e-01
    z[1,2,2]  R719      4.2534321546554565e-01
    z[1,2,2]  R720      -1.3075712323188782e-01
    z[1,2,2]  R721      -3.8576906919479370e-01
    z[1,2,2]  R722      2.0400781184434891e-02
    z[1,2,2]  R723      2.0019893348217010e-01
    z[1,2,2]  R724      1.3905979692935944e-01
    z[1,2,2]  R725      -0.289896696805954
    z[1,2,2]  R726      5.9983348846435547e-01
    z[1,2,2]  R727      5.6533169746398926e-01
    z[1,2,2]  R728      3.3473175764083862e-01
    z[1,2,2]  R729      0.591620922088623
    z[1,2,2]  R730      6.4955705404281616e-01
    z[1,2,2]  R731      4.2200678586959839e-01
    z[1,2,2]  R732      3.4381836652755737e-01
    z[1,2,2]  R733      7.5425392389297485e-01
    z[1,2,2]  R734      1.3663128018379211e-01
    z[1,2,2]  R735      2.3372364044189453e-01
    z[1,2,2]  R736      -2.8846305608749390e-01
    z[1,2,2]  R737      4.8309543728828430e-01
    z[1,2,2]  R738      -2.6111856102943420e-01
    z[1,2,2]  R739      -0.0473548024892807
    z[1,2,2]  R740      4.2363476008176804e-02
    z[1,2,2]  R741      1.9885657727718353e-01
    z[1,2,2]  R742      -1.9453147053718567e-01
    z[1,2,2]  R743      3.3912059664726257e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R646      -1
    z[1,2,3]  R647      1
    z[1,2,3]  R654      4.9243035912513733e-01
    z[1,2,3]  R655      5.0554656982421875e-01
    z[1,2,3]  R656      5.1138144731521606e-01
    z[1,2,3]  R657      3.3378553390502930e-01
    z[1,2,3]  R658      -1.8854171037673950e-01
    z[1,2,3]  R659      -1.4253887534141541e-01
    z[1,2,3]  R660      2.4872681498527527e-01
    z[1,2,3]  R661      2.1641846746206284e-02
    z[1,2,3]  R662      -1.9361507892608643e-01
    z[1,2,3]  R663      -4.4752854108810425e-01
    z[1,2,3]  R664      -4.4447034597396851e-02
    z[1,2,3]  R665      -5.2434122562408447e-01
    z[1,2,3]  R666      -3.5095199942588806e-01
    z[1,2,3]  R667      -3.1402194499969482e-01
    z[1,2,3]  R668      -3.2981792092323303e-01
    z[1,2,3]  R669      -2.9031160473823547e-01
    z[1,2,3]  R670      -5.5152559280395508e-01
    z[1,2,3]  R671      -1.7999365925788879e-01
    z[1,2,3]  R672      -0.319568932056427
    z[1,2,3]  R673      -0.0645049586892128
    z[1,2,3]  R674      -6.5557742118835449e-01
    z[1,2,3]  R675      -1.2081279419362545e-02
    z[1,2,3]  R676      -0.0806296318769455
    z[1,2,3]  R677      -1.9459196925163269e-01
    z[1,2,3]  R678      -6.4039933681488037e-01
    z[1,2,3]  R679      -4.7206792235374451e-01
    z[1,2,3]  R680      -3.4568536281585693e-01
    z[1,2,3]  R681      -2.2869020700454712e-01
    z[1,2,3]  R682      -4.5102012157440186e-01
    z[1,2,3]  R683      2.3547211661934853e-02
    z[1,2,3]  R684      -2.1843446791172028e-01
    z[1,2,3]  R685      3.8228464126586914e-01
    z[1,2,3]  R686      -2.4428358674049377e-01
    z[1,2,3]  R687      -3.6610227823257446e-01
    z[1,2,3]  R688      -7.9962633550167084e-02
    z[1,2,3]  R689      -4.3234610557556152e-01
    z[1,2,3]  R690      -4.3659138679504395e-01
    z[1,2,3]  R691      -4.0801870822906494e-01
    z[1,2,3]  R692      -3.2905688881874084e-01
    z[1,2,3]  R693      -4.3137919902801514e-01
    z[1,2,3]  R694      4.6444028615951538e-01
    z[1,2,3]  R695      1.4665301144123077e-01
    z[1,2,3]  R696      5.9248123317956924e-02
    z[1,2,3]  R697      -0.0647757425904274
    z[1,2,3]  R698      -3.3503524959087372e-02
    z[1,2,3]  R699      3.0617249011993408e-01
    z[1,2,3]  R700      -1.5060655772686005e-01
    z[1,2,3]  R701      -3.7506937980651855e-01
    z[1,2,3]  R702      4.7289678454399109e-01
    z[1,2,3]  R703      5.9952370822429657e-02
    z[1,2,3]  R704      2.2570972144603729e-01
    z[1,2,3]  R705      -4.0436097979545593e-01
    z[1,2,3]  R706      1.4787705242633820e-01
    z[1,2,3]  R707      3.8220247626304626e-01
    z[1,2,3]  R708      3.7393602728843689e-01
    z[1,2,3]  R709      2.1852149069309235e-01
    z[1,2,3]  R710      4.2644214630126953e-01
    z[1,2,3]  R711      3.7610808014869690e-01
    z[1,2,3]  R712      4.6936103701591492e-01
    z[1,2,3]  R713      3.8113737106323242e-01
    z[1,2,3]  R714      0.458217054605484
    z[1,2,3]  R715      3.4837085008621216e-01
    z[1,2,3]  R716      1.8025636672973633e-01
    z[1,2,3]  R717      2.6481881737709045e-01
    z[1,2,3]  R718      4.5567402243614197e-01
    z[1,2,3]  R719      4.8127308487892151e-02
    z[1,2,3]  R720      7.1094882488250732e-01
    z[1,2,3]  R721      -1.1758894473314285e-01
    z[1,2,3]  R722      -3.3963659405708313e-01
    z[1,2,3]  R723      -1.1370488256216049e-01
    z[1,2,3]  R724      -4.8172511160373688e-02
    z[1,2,3]  R725      3.3632761240005493e-01
    z[1,2,3]  R726      1.5562395751476288e-01
    z[1,2,3]  R727      2.5202763080596924e-01
    z[1,2,3]  R728      -9.6530042588710785e-02
    z[1,2,3]  R729      9.2465788125991821e-02
    z[1,2,3]  R730      0.26992267370224
    z[1,2,3]  R731      2.6868173480033875e-01
    z[1,2,3]  R732      4.7727242112159729e-01
    z[1,2,3]  R733      4.0019545704126358e-02
    z[1,2,3]  R734      4.2768466472625732e-01
    z[1,2,3]  R735      -9.6108177676796913e-03
    z[1,2,3]  R736      4.9866217374801636e-01
    z[1,2,3]  R737      2.4773922562599182e-01
    z[1,2,3]  R738      2.5836622714996338e-01
    z[1,2,3]  R739      -9.5853674411773682e-01
    z[1,2,3]  R740      -3.4687477350234985e-01
    z[1,2,3]  R741      -1.3818985223770142e-01
    z[1,2,3]  R742      -3.8389381766319275e-01
    z[1,2,3]  R743      -2.2529102861881256e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R648      -1
    z[1,2,4]  R649      1
    z[1,2,4]  R654      -4.7869235277175903e-01
    z[1,2,4]  R655      -0.353411465883255
    z[1,2,4]  R656      2.1292430162429810e-01
    z[1,2,4]  R657      5.5049387738108635e-03
    z[1,2,4]  R658      -4.8308354616165161e-01
    z[1,2,4]  R659      -5.2213305234909058e-01
    z[1,2,4]  R660      1.1937224864959717e-01
    z[1,2,4]  R661      1.5014718472957611e-01
    z[1,2,4]  R662      -6.3855779170989990e-01
    z[1,2,4]  R663      -5.8134567737579346e-01
    z[1,2,4]  R664      1.7674861848354340e-01
    z[1,2,4]  R665      1.7360825836658478e-01
    z[1,2,4]  R666      1.3603407144546509e-01
    z[1,2,4]  R667      2.2222118079662323e-01
    z[1,2,4]  R668      4.4917544722557068e-01
    z[1,2,4]  R669      4.6200191974639893e-01
    z[1,2,4]  R670      -1.6582775115966797e-01
    z[1,2,4]  R671      4.5760747790336609e-01
    z[1,2,4]  R672      -2.6043057441711426e-01
    z[1,2,4]  R673      -1.2828649580478668e-01
    z[1,2,4]  R674      3.2459726929664612e-01
    z[1,2,4]  R675      1.5240977704524994e-01
    z[1,2,4]  R676      -2.9337859153747559e-01
    z[1,2,4]  R677      -1.7532658576965332e-01
    z[1,2,4]  R678      -1.3813933730125427e-01
    z[1,2,4]  R679      -2.4399299919605255e-01
    z[1,2,4]  R680      -1.8310281634330750e-01
    z[1,2,4]  R681      -4.3905708193778992e-01
    z[1,2,4]  R682      -3.6279231309890747e-01
    z[1,2,4]  R683      -1.6562348604202271e-01
    z[1,2,4]  R684      1.3291072845458984e-01
    z[1,2,4]  R685      -4.0647846460342407e-01
    z[1,2,4]  R686      3.4199748188257217e-02
    z[1,2,4]  R687      7.8203096985816956e-02
    z[1,2,4]  R688      -1.6141681373119354e-01
    z[1,2,4]  R689      -1.0343640297651291e-01
    z[1,2,4]  R690      -1.0888533294200897e-01
    z[1,2,4]  R691      -2.6009339094161987e-01
    z[1,2,4]  R692      -6.3789568841457367e-02
    z[1,2,4]  R693      -1.9778449833393097e-01
    z[1,2,4]  R694      -2.8815552592277527e-01
    z[1,2,4]  R695      -6.5752822160720825e-01
    z[1,2,4]  R696      -1.6028371453285217e-01
    z[1,2,4]  R697      -2.5635886192321777e-01
    z[1,2,4]  R698      1.1484770476818085e-01
    z[1,2,4]  R699      -7.2272044420242310e-01
    z[1,2,4]  R700      2.5529885292053223e-01
    z[1,2,4]  R701      -4.5813828706741333e-01
    z[1,2,4]  R702      2.7722854167222977e-02
    z[1,2,4]  R703      -0.244576096534729
    z[1,2,4]  R704      4.5235726237297058e-01
    z[1,2,4]  R705      3.4507265686988831e-01
    z[1,2,4]  R706      -1.8130175769329071e-01
    z[1,2,4]  R707      1.6281618177890778e-01
    z[1,2,4]  R708      -1.6976632177829742e-02
    z[1,2,4]  R709      1.7127616703510284e-01
    z[1,2,4]  R710      -3.7139128893613815e-02
    z[1,2,4]  R711      4.7775000333786011e-01
    z[1,2,4]  R712      -1.0041683167219162e-01
    z[1,2,4]  R713      4.6058148145675659e-01
    z[1,2,4]  R714      -1.5805619955062866e-01
    z[1,2,4]  R715      2.7727490663528442e-01
    z[1,2,4]  R716      1.8001537770032883e-02
    z[1,2,4]  R717      -1.9209538400173187e-01
    z[1,2,4]  R718      -8.6982309818267822e-02
    z[1,2,4]  R719      4.2937391996383667e-01
    z[1,2,4]  R720      3.4035738557577133e-02
    z[1,2,4]  R721      3.4835720062255859e-01
    z[1,2,4]  R722      2.7765345573425293e-01
    z[1,2,4]  R723      3.1549766659736633e-01
    z[1,2,4]  R724      1.4113017916679382e-01
    z[1,2,4]  R725      -7.2040654718875885e-02
    z[1,2,4]  R726      4.3641266226768494e-01
    z[1,2,4]  R727      -1.7879876494407654e-01
    z[1,2,4]  R728      -0.354126900434494
    z[1,2,4]  R729      -3.4630599617958069e-01
    z[1,2,4]  R730      -0.170893132686615
    z[1,2,4]  R731      3.4464788436889648e-01
    z[1,2,4]  R732      2.5045084953308105e-01
    z[1,2,4]  R733      -3.4921568632125854e-01
    z[1,2,4]  R734      0.0611988827586174
    z[1,2,4]  R735      1.4504013955593109e-01
    z[1,2,4]  R736      1.7014007270336151e-01
    z[1,2,4]  R737      -8.7398067116737366e-02
    z[1,2,4]  R738      2.2325593233108521e-01
    z[1,2,4]  R739      -5.8964673429727554e-02
    z[1,2,4]  R740      9.7499601542949677e-02
    z[1,2,4]  R741      -7.8991755843162537e-02
    z[1,2,4]  R742      -4.2591953277587891e-01
    z[1,2,4]  R743      -1.2765172123908997e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R650      -1
    z[1,2,5]  R651      1
    z[1,2,5]  R654      -2.0041167736053467e-01
    z[1,2,5]  R655      -4.3665367364883423e-01
    z[1,2,5]  R656      -2.8782343864440918e-01
    z[1,2,5]  R657      -6.0278022289276123e-01
    z[1,2,5]  R658      -0.566609799861908
    z[1,2,5]  R659      -0.28685262799263
    z[1,2,5]  R660      1.5974249690771103e-02
    z[1,2,5]  R661      -3.0622237920761108e-01
    z[1,2,5]  R662      -8.5659280419349670e-02
    z[1,2,5]  R663      -9.4244204461574554e-02
    z[1,2,5]  R664      3.6924883723258972e-01
    z[1,2,5]  R665      9.4708538381382823e-04
    z[1,2,5]  R666      -0.0814613625407219
    z[1,2,5]  R667      -3.5854384303092957e-01
    z[1,2,5]  R668      -1.4186948537826538e-01
    z[1,2,5]  R669      9.6284836530685425e-02
    z[1,2,5]  R670      1.4110732078552246e-01
    z[1,2,5]  R671      4.8242881894111633e-03
    z[1,2,5]  R672      -0.0749167948961258
    z[1,2,5]  R673      2.7209895849227905e-01
    z[1,2,5]  R674      1.9273126125335693e-01
    z[1,2,5]  R675      7.6943945884704590e-01
    z[1,2,5]  R676      -4.8499464988708496e-02
    z[1,2,5]  R677      -2.7498283982276917e-01
    z[1,2,5]  R678      -3.4907805919647217e-01
    z[1,2,5]  R679      2.7364954352378845e-01
    z[1,2,5]  R680      -4.0097177028656006e-01
    z[1,2,5]  R681      -1.1034757643938065e-01
    z[1,2,5]  R682      0.32767453789711
    z[1,2,5]  R683      -3.4630617592483759e-03
    z[1,2,5]  R684      1.9378204643726349e-01
    z[1,2,5]  R685      -2.3140968382358551e-01
    z[1,2,5]  R686      2.0276030898094177e-01
    z[1,2,5]  R687      -2.6396793127059937e-01
    z[1,2,5]  R688      -5.3916919976472855e-02
    z[1,2,5]  R689      1.4100360684096813e-02
    z[1,2,5]  R690      1.1793158203363419e-01
    z[1,2,5]  R691      -1.5098898112773895e-01
    z[1,2,5]  R692      -3.3523935079574585e-01
    z[1,2,5]  R693      -1.8744681775569916e-01
    z[1,2,5]  R694      -2.2357408702373505e-01
    z[1,2,5]  R695      -1.5324714593589306e-02
    z[1,2,5]  R696      6.0758337378501892e-02
    z[1,2,5]  R697      -1.7199523746967316e-01
    z[1,2,5]  R698      8.3132229745388031e-02
    z[1,2,5]  R699      -1.2672264873981476e-01
    z[1,2,5]  R700      -1.5328468382358551e-01
    z[1,2,5]  R701      1.7406722903251648e-01
    z[1,2,5]  R702      -4.0122276544570923e-01
    z[1,2,5]  R703      -1.0973126441240311e-01
    z[1,2,5]  R704      4.1944679617881775e-01
    z[1,2,5]  R705      4.6755722165107727e-01
    z[1,2,5]  R706      -2.3887167870998383e-01
    z[1,2,5]  R707      -3.8349515199661255e-01
    z[1,2,5]  R708      -3.8785532116889954e-01
    z[1,2,5]  R709      -4.1204899549484253e-01
    z[1,2,5]  R710      -2.7068731188774109e-01
    z[1,2,5]  R711      -2.9718539118766785e-01
    z[1,2,5]  R712      -1.3412435352802277e-01
    z[1,2,5]  R713      -0.412482887506485
    z[1,2,5]  R714      4.7123548574745655e-03
    z[1,2,5]  R715      -2.1599614620208740e-01
    z[1,2,5]  R716      -1.2933824956417084e-01
    z[1,2,5]  R717      -3.5681214928627014e-01
    z[1,2,5]  R718      -2.7933532372117043e-02
    z[1,2,5]  R719      -3.3970877528190613e-01
    z[1,2,5]  R720      -1.4171645045280457e-01
    z[1,2,5]  R721      9.4780838117003441e-03
    z[1,2,5]  R722      -1.3779945671558380e-01
    z[1,2,5]  R723      -0.00695176562294364
    z[1,2,5]  R724      5.6822425127029419e-01
    z[1,2,5]  R725      -3.5686764866113663e-02
    z[1,2,5]  R726      -3.5881036520004272e-01
    z[1,2,5]  R727      -1.4847515523433685e-01
    z[1,2,5]  R728      -1.2488958239555359e-01
    z[1,2,5]  R729      -2.6262101531028748e-01
    z[1,2,5]  R730      -3.7424251437187195e-01
    z[1,2,5]  R731      -5.8189444243907928e-02
    z[1,2,5]  R732      -5.7193273305892944e-01
    z[1,2,5]  R733      -1.0489203967154026e-02
    z[1,2,5]  R734      1.4155525714159012e-02
    z[1,2,5]  R735      -2.0045363903045654e-01
    z[1,2,5]  R736      3.1995948404073715e-02
    z[1,2,5]  R737      -3.4491837024688721e-01
    z[1,2,5]  R738      1.4150644652545452e-02
    z[1,2,5]  R739      -2.5481337308883667e-01
    z[1,2,5]  R740      -2.1574825223069638e-04
    z[1,2,5]  R741      -0.0421307310461998
    z[1,2,5]  R742      -1.0680418461561203e-01
    z[1,2,5]  R743      -4.5179602503776550e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R652      -1
    z[1,2,6]  R653      1
    z[1,2,6]  R654      -1.9053514301776886e-01
    z[1,2,6]  R655      1.1832785606384277e-01
    z[1,2,6]  R656      4.3967801332473755e-01
    z[1,2,6]  R657      -4.8423612117767334e-01
    z[1,2,6]  R658      1.9352915883064270e-01
    z[1,2,6]  R659      3.6890518665313721e-01
    z[1,2,6]  R660      -5.7547432184219360e-01
    z[1,2,6]  R661      3.2123643904924393e-02
    z[1,2,6]  R662      -9.8000364378094673e-03
    z[1,2,6]  R663      -1.5896634757518768e-01
    z[1,2,6]  R664      -1.9087785482406616e-01
    z[1,2,6]  R665      -1.7828333377838135e-01
    z[1,2,6]  R666      3.5070598125457764e-02
    z[1,2,6]  R667      -6.7103527486324310e-02
    z[1,2,6]  R668      6.6242665052413940e-02
    z[1,2,6]  R669      -1.4694066345691681e-01
    z[1,2,6]  R670      1.8468730151653290e-02
    z[1,2,6]  R671      2.0318174362182617e-01
    z[1,2,6]  R672      -1.7295676469802856e-01
    z[1,2,6]  R673      -1.7953509092330933e-01
    z[1,2,6]  R674      2.5688254833221436e-01
    z[1,2,6]  R675      4.6851357817649841e-01
    z[1,2,6]  R676      2.4432139098644257e-01
    z[1,2,6]  R677      4.8920312523841858e-01
    z[1,2,6]  R678      -1.7767407000064850e-02
    z[1,2,6]  R679      0.0679338276386261
    z[1,2,6]  R680      -1.4336473308503628e-02
    z[1,2,6]  R681      5.0678491592407227e-02
    z[1,2,6]  R682      -1.5902754664421082e-01
    z[1,2,6]  R683      2.6732046157121658e-02
    z[1,2,6]  R684      -6.2585294246673584e-01
    z[1,2,6]  R685      -4.8738211393356323e-02
    z[1,2,6]  R686      -1.0014757513999939e-01
    z[1,2,6]  R687      -1.3742519915103912e-01
    z[1,2,6]  R688      -1.5722940862178802e-01
    z[1,2,6]  R689      3.9180129766464233e-01
    z[1,2,6]  R690      -1.4284999668598175e-01
    z[1,2,6]  R691      2.2878804802894592e-01
    z[1,2,6]  R692      -1.3638909161090851e-01
    z[1,2,6]  R693      -5.5600155144929886e-02
    z[1,2,6]  R694      2.0618361234664917e-01
    z[1,2,6]  R695      7.9898700118064880e-02
    z[1,2,6]  R696      -4.2748656868934631e-01
    z[1,2,6]  R697      -5.4689103364944458e-01
    z[1,2,6]  R698      9.6865154802799225e-02
    z[1,2,6]  R699      -2.4084423482418060e-01
    z[1,2,6]  R700      4.4141769409179688e-02
    z[1,2,6]  R701      0.554288387298584
    z[1,2,6]  R702      1.9463993608951569e-02
    z[1,2,6]  R703      -4.3386835604906082e-02
    z[1,2,6]  R704      9.0318925678730011e-02
    z[1,2,6]  R705      -3.1461721658706665e-01
    z[1,2,6]  R706      1.3393911719322205e-01
    z[1,2,6]  R707      3.7313720583915710e-01
    z[1,2,6]  R708      -3.3675307035446167e-01
    z[1,2,6]  R709      -1.3031649589538574e-01
    z[1,2,6]  R710      -1.1199028044939041e-01
    z[1,2,6]  R711      2.5821531191468239e-02
    z[1,2,6]  R712      1.0259898751974106e-01
    z[1,2,6]  R713      -1.1703076772391796e-02
    z[1,2,6]  R714      -6.8860031664371490e-02
    z[1,2,6]  R715      6.1053719371557236e-02
    z[1,2,6]  R716      -1.2132717669010162e-01
    z[1,2,6]  R717      -1.4700870215892792e-01
    z[1,2,6]  R718      1.1287894845008850e-01
    z[1,2,6]  R719      1.7166174948215485e-01
    z[1,2,6]  R720      -2.1472658216953278e-01
    z[1,2,6]  R721      2.6899653673171997e-01
    z[1,2,6]  R722      3.5283237695693970e-01
    z[1,2,6]  R723      -3.9568844437599182e-01
    z[1,2,6]  R724      -2.1786986291408539e-01
    z[1,2,6]  R725      2.9088482260704041e-01
    z[1,2,6]  R726      -1.3363888859748840e-01
    z[1,2,6]  R727      -9.8918646574020386e-02
    z[1,2,6]  R728      -1.7414465546607971e-01
    z[1,2,6]  R729      -7.7840596437454224e-02
    z[1,2,6]  R730      0.026185292750597
    z[1,2,6]  R731      3.1590768694877625e-01
    z[1,2,6]  R732      -3.5322561860084534e-02
    z[1,2,6]  R733      -2.4731151759624481e-01
    z[1,2,6]  R734      -3.6526456475257874e-01
    z[1,2,6]  R735      -3.2610824704170227e-01
    z[1,2,6]  R736      -3.1757766008377075e-01
    z[1,2,6]  R737      -2.6561614871025085e-01
    z[1,2,6]  R738      0.147373765707016
    z[1,2,6]  R739      9.7242005169391632e-02
    z[1,2,6]  R740      1.4258872717618942e-02
    z[1,2,6]  R741      3.4969004988670349e-01
    z[1,2,6]  R742      -1.5640050172805786e-01
    z[1,2,6]  R743      -1.0230807214975357e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R744      -1
    z[2,1,0]  R745      1
    z[2,1,0]  R758      -0.490815132856369
    z[2,1,0]  R759      -3.5189476609230042e-01
    z[2,1,0]  R760      -6.9665157794952393e-01
    z[2,1,0]  R761      -4.9690628051757812e-01
    z[2,1,0]  R762      -9.0260022878646851e-01
    z[2,1,0]  R763      -4.7346779704093933e-01
    z[2,1,0]  R764      5.3116691112518311e-01
    z[2,1,0]  R765      3.8319456577301025e-01
    z[2,1,0]  R766      1.0995641350746155e-01
    z[2,1,0]  R767      6.0583537817001343e-01
    z[2,1,0]  R768      1.7992122471332550e-01
    z[2,1,0]  R769      2.3500937223434448e-01
    z[2,1,0]  R770      8.7343639135360718e-01
    z[2,1,0]  R771      5.2674150466918945e-01
    z[2,1,0]  R772      5.6507551670074463e-01
    z[2,1,0]  R773      8.3293646574020386e-01
    z[2,1,0]  R774      7.2959405183792114e-01
    z[2,1,0]  R775      4.4843098521232605e-01
    z[2,1,0]  R776      8.3474791049957275e-01
    z[2,1,0]  R777      6.5822309255599976e-01
    z[2,1,0]  R778      6.0884815454483032e-01
    z[2,1,0]  R779      4.4912764430046082e-01
    z[2,1,0]  R780      2.8068712353706360e-01
    z[2,1,0]  R781      4.7725030779838562e-01
    z[2,1,0]  R782      5.1029217243194580e-01
    z[2,1,0]  R783      4.9956426024436951e-01
    z[2,1,0]  R784      1.3929453492164612e-01
    z[2,1,0]  R785      2.5833564996719360e-01
    z[2,1,0]  R786      3.2290109992027283e-01
    z[2,1,0]  R787      5.7730823755264282e-01
    z[2,1,0]  R788      5.5724453926086426e-01
    z[2,1,0]  R789      1.7468205094337463e-01
    z[2,1,0]  R790      4.3995073437690735e-01
    z[2,1,0]  R791      7.3243713378906250e-01
    z[2,1,0]  R792      7.2987407445907593e-01
    z[2,1,0]  R793      5.0881814956665039e-01
    z[2,1,0]  R794      4.4130480289459229e-01
    z[2,1,0]  R795      7.2296333312988281e-01
    z[2,1,0]  R796      4.8452901840209961e-01
    z[2,1,0]  R797      4.5559036731719971e-01
    z[2,1,0]  R798      4.4959786534309387e-01
    z[2,1,0]  R799      8.5046076774597168e-01
    z[2,1,0]  R800      3.8043540716171265e-01
    z[2,1,0]  R801      6.8055588006973267e-01
    z[2,1,0]  R802      6.8704360723495483e-01
    z[2,1,0]  R803      1.5266070840880275e-03
    z[2,1,0]  R804      5.1778149604797363e-01
    z[2,1,0]  R805      3.1060710549354553e-01
    z[2,1,0]  R806      2.0471620559692383e-01
    z[2,1,0]  R807      -1.1524931527674198e-02
    z[2,1,0]  R808      4.8762276768684387e-01
    z[2,1,0]  R809      5.3526413440704346e-01
    z[2,1,0]  R810      4.7786450386047363e-01
    z[2,1,0]  R811      4.3266192078590393e-01
    z[2,1,0]  R812      4.8137810826301575e-01
    z[2,1,0]  R813      4.4484078884124756e-01
    z[2,1,0]  R814      2.2758446633815765e-01
    z[2,1,0]  R815      -3.2156670093536377e-01
    z[2,1,0]  R816      -6.7632973194122314e-02
    z[2,1,0]  R817      -1.2362013012170792e-01
    z[2,1,0]  R818      6.5048910677433014e-02
    z[2,1,0]  R819      -7.9278725385665894e-01
    z[2,1,0]  R820      -8.3439606428146362e-01
    z[2,1,0]  R821      -8.2489007711410522e-01
    z[2,1,0]  R822      -6.8961602449417114e-01
    z[2,1,0]  R823      -7.8425419330596924e-01
    z[2,1,0]  R824      -6.8020766973495483e-01
    z[2,1,0]  R825      -7.2894531488418579e-01
    z[2,1,0]  R826      -8.1985729932785034e-01
    z[2,1,0]  R827      -0.830944299697876
    z[2,1,0]  R828      1.1360311508178711e-01
    z[2,1,0]  R829      1.3797410763800144e-02
    z[2,1,0]  R830      -4.2373758554458618e-01
    z[2,1,0]  R831      -3.0192825198173523e-01
    z[2,1,0]  R832      -6.3382869958877563e-01
    z[2,1,0]  R833      -6.9172859191894531e-01
    z[2,1,0]  R834      -7.5065809488296509e-01
    z[2,1,0]  R835      -8.2509487867355347e-01
    z[2,1,0]  R836      -0.679706335067749
    z[2,1,0]  R837      -9.4545549154281616e-01
    z[2,1,0]  R838      0.0442180261015892
    z[2,1,0]  R839      -2.0517329871654510e-01
    z[2,1,0]  R840      -9.0681433677673340e-01
    z[2,1,0]  R841      -7.8480494022369385e-01
    z[2,1,0]  R842      -8.7693107128143311e-01
    z[2,1,0]  R843      -7.3673528432846069e-01
    z[2,1,0]  R844      -6.9118893146514893e-01
    z[2,1,0]  R845      -7.5684589147567749e-01
    z[2,1,0]  R846      -4.3756476044654846e-01
    z[2,1,0]  R847      -7.0736819505691528e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R746      -1
    z[2,1,1]  R747      1
    z[2,1,1]  R758      -3.4972810745239258e-01
    z[2,1,1]  R759      -2.1696461737155914e-01
    z[2,1,1]  R760      -4.7060576081275940e-01
    z[2,1,1]  R761      -1.8660506606101990e-01
    z[2,1,1]  R762      -2.4373726546764374e-01
    z[2,1,1]  R763      -1.9525794684886932e-01
    z[2,1,1]  R764      -4.0694692730903625e-01
    z[2,1,1]  R765      -3.9544859528541565e-01
    z[2,1,1]  R766      7.0127922296524048e-01
    z[2,1,1]  R767      6.4099001884460449e-01
    z[2,1,1]  R768      -6.8807423114776611e-01
    z[2,1,1]  R769      -5.1114434003829956e-01
    z[2,1,1]  R770      3.2021689414978027e-01
    z[2,1,1]  R771      3.0431634187698364e-01
    z[2,1,1]  R772      6.7377209663391113e-02
    z[2,1,1]  R773      1.9425563514232635e-01
    z[2,1,1]  R774      -2.4642951320856810e-03
    z[2,1,1]  R775      4.8408966511487961e-02
    z[2,1,1]  R776      -0.149896040558815
    z[2,1,1]  R777      6.5576724708080292e-02
    z[2,1,1]  R778      6.2107443809509277e-01
    z[2,1,1]  R779      7.3644739389419556e-01
    z[2,1,1]  R780      7.7415573596954346e-01
    z[2,1,1]  R781      7.1338462829589844e-01
    z[2,1,1]  R782      6.2748807668685913e-01
    z[2,1,1]  R783      4.8782244324684143e-01
    z[2,1,1]  R784      6.2506145238876343e-01
    z[2,1,1]  R785      7.5948399305343628e-01
    z[2,1,1]  R786      7.4792701005935669e-01
    z[2,1,1]  R787      5.9795522689819336e-01
    z[2,1,1]  R788      -5.2683621644973755e-01
    z[2,1,1]  R789      8.2538014650344849e-01
    z[2,1,1]  R790      2.9217118024826050e-01
    z[2,1,1]  R791      1.2891595065593719e-01
    z[2,1,1]  R792      4.1784065961837769e-01
    z[2,1,1]  R793      4.3310755491256714e-01
    z[2,1,1]  R794      3.7485957145690918e-01
    z[2,1,1]  R795      7.1263968944549561e-02
    z[2,1,1]  R796      1.6778342425823212e-01
    z[2,1,1]  R797      1.9675391912460327e-01
    z[2,1,1]  R798      6.7743313312530518e-01
    z[2,1,1]  R799      2.3330783843994141e-01
    z[2,1,1]  R800      6.2655168771743774e-01
    z[2,1,1]  R801      2.1196378767490387e-01
    z[2,1,1]  R802      5.6680923700332642e-01
    z[2,1,1]  R803      3.3163674175739288e-02
    z[2,1,1]  R804      7.7464574575424194e-01
    z[2,1,1]  R805      8.4533131122589111e-01
    z[2,1,1]  R806      0.745384931564331
    z[2,1,1]  R807      7.7667677402496338e-01
    z[2,1,1]  R808      3.1182876229286194e-01
    z[2,1,1]  R809      3.1679326295852661e-01
    z[2,1,1]  R810      2.8544783592224121e-01
    z[2,1,1]  R811      3.0021238327026367e-01
    z[2,1,1]  R812      3.7033927440643311e-01
    z[2,1,1]  R813      2.9730680584907532e-01
    z[2,1,1]  R814      2.9784691333770752e-01
    z[2,1,1]  R815      -0.76842200756073
    z[2,1,1]  R816      -7.2994166612625122e-01
    z[2,1,1]  R817      -6.3500648736953735e-01
    z[2,1,1]  R818      5.7323312759399414e-01
    z[2,1,1]  R819      -2.5927681475877762e-02
    z[2,1,1]  R820      7.2741672396659851e-02
    z[2,1,1]  R821      -1.9623391330242157e-01
    z[2,1,1]  R822      -2.3165687918663025e-02
    z[2,1,1]  R823      6.2084991484880447e-02
    z[2,1,1]  R824      -1.1389282345771790e-01
    z[2,1,1]  R825      1.4568357169628143e-01
    z[2,1,1]  R826      -0.0789308175444603
    z[2,1,1]  R827      -3.2679599523544312e-01
    z[2,1,1]  R828      5.8238863945007324e-01
    z[2,1,1]  R829      3.8293415307998657e-01
    z[2,1,1]  R830      -8.1575781106948853e-01
    z[2,1,1]  R831      -7.2446751594543457e-01
    z[2,1,1]  R832      -2.1643690764904022e-01
    z[2,1,1]  R833      -3.0542570352554321e-01
    z[2,1,1]  R834      -2.4331867694854736e-01
    z[2,1,1]  R835      -2.3857049643993378e-01
    z[2,1,1]  R836      -2.2109535336494446e-01
    z[2,1,1]  R837      -2.5237387418746948e-01
    z[2,1,1]  R838      5.4887527227401733e-01
    z[2,1,1]  R839      -0.756986141204834
    z[2,1,1]  R840      -2.5298237800598145e-01
    z[2,1,1]  R841      -0.319732129573822
    z[2,1,1]  R842      -4.1124969720840454e-01
    z[2,1,1]  R843      -3.0991527438163757e-01
    z[2,1,1]  R844      -4.4507080316543579e-01
    z[2,1,1]  R845      -2.6714438199996948e-01
    z[2,1,1]  R846      -7.5146359205245972e-01
    z[2,1,1]  R847      -3.3937805891036987e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R748      -1
    z[2,1,2]  R749      1
    z[2,1,2]  R758      -4.9553540349006653e-01
    z[2,1,2]  R759      -6.0714691877365112e-01
    z[2,1,2]  R760      -2.7851250767707825e-01
    z[2,1,2]  R761      -5.6539791822433472e-01
    z[2,1,2]  R762      -3.0870464444160461e-01
    z[2,1,2]  R763      0.218109130859375
    z[2,1,2]  R764      -6.6253411769866943e-01
    z[2,1,2]  R765      9.3164056539535522e-02
    z[2,1,2]  R766      -3.3220261335372925e-01
    z[2,1,2]  R767      3.8047355413436890e-01
    z[2,1,2]  R768      2.3348897695541382e-01
    z[2,1,2]  R769      2.8866133093833923e-01
    z[2,1,2]  R770      6.9517545402050018e-02
    z[2,1,2]  R771      4.1357865929603577e-01
    z[2,1,2]  R772      5.2172702550888062e-01
    z[2,1,2]  R773      -6.8027332425117493e-02
    z[2,1,2]  R774      4.4569137692451477e-01
    z[2,1,2]  R775      5.8127278089523315e-01
    z[2,1,2]  R776      1.4774306118488312e-01
    z[2,1,2]  R777      1.8644580245018005e-01
    z[2,1,2]  R778      -6.2145132571458817e-02
    z[2,1,2]  R779      8.5463829338550568e-02
    z[2,1,2]  R780      -5.0757521390914917e-01
    z[2,1,2]  R781      -8.5780851542949677e-02
    z[2,1,2]  R782      3.4224835038185120e-01
    z[2,1,2]  R783      4.2534321546554565e-01
    z[2,1,2]  R784      -1.3075712323188782e-01
    z[2,1,2]  R785      -3.8576906919479370e-01
    z[2,1,2]  R786      2.0400781184434891e-02
    z[2,1,2]  R787      2.0019893348217010e-01
    z[2,1,2]  R788      1.3905979692935944e-01
    z[2,1,2]  R789      -0.289896696805954
    z[2,1,2]  R790      5.9983348846435547e-01
    z[2,1,2]  R791      5.6533169746398926e-01
    z[2,1,2]  R792      3.3473175764083862e-01
    z[2,1,2]  R793      0.591620922088623
    z[2,1,2]  R794      6.4955705404281616e-01
    z[2,1,2]  R795      4.2200678586959839e-01
    z[2,1,2]  R796      3.4381836652755737e-01
    z[2,1,2]  R797      7.5425392389297485e-01
    z[2,1,2]  R798      1.3663128018379211e-01
    z[2,1,2]  R799      2.3372364044189453e-01
    z[2,1,2]  R800      -2.8846305608749390e-01
    z[2,1,2]  R801      4.8309543728828430e-01
    z[2,1,2]  R802      -2.6111856102943420e-01
    z[2,1,2]  R803      -0.0473548024892807
    z[2,1,2]  R804      4.2363476008176804e-02
    z[2,1,2]  R805      1.9885657727718353e-01
    z[2,1,2]  R806      -1.9453147053718567e-01
    z[2,1,2]  R807      3.3912059664726257e-01
    z[2,1,2]  R808      -3.4188345074653625e-01
    z[2,1,2]  R809      1.6730089485645294e-01
    z[2,1,2]  R810      -3.2735043764114380e-01
    z[2,1,2]  R811      -1.1577780544757843e-01
    z[2,1,2]  R812      0.0608777217566967
    z[2,1,2]  R813      -4.4989970326423645e-01
    z[2,1,2]  R814      -6.7227369546890259e-01
    z[2,1,2]  R815      -4.3394207954406738e-01
    z[2,1,2]  R816      9.9671795964241028e-02
    z[2,1,2]  R817      -9.5330648124217987e-02
    z[2,1,2]  R818      6.7910069227218628e-01
    z[2,1,2]  R819      1.8427358567714691e-01
    z[2,1,2]  R820      3.8594490289688110e-01
    z[2,1,2]  R821      -1.6113594756461680e-04
    z[2,1,2]  R822      4.3455675244331360e-01
    z[2,1,2]  R823      2.2913278639316559e-01
    z[2,1,2]  R824      4.1522794961929321e-01
    z[2,1,2]  R825      4.0534734725952148e-01
    z[2,1,2]  R826      3.4077703952789307e-01
    z[2,1,2]  R827      2.7540290355682373e-01
    z[2,1,2]  R828      -0.0981765165925026
    z[2,1,2]  R829      -1.3510827720165253e-01
    z[2,1,2]  R830      1.9192628562450409e-02
    z[2,1,2]  R831      0.0211052056401968
    z[2,1,2]  R832      -0.00716095557436347
    z[2,1,2]  R833      -2.5757923722267151e-01
    z[2,1,2]  R834      2.5159388780593872e-01
    z[2,1,2]  R835      4.9874968826770782e-02
    z[2,1,2]  R836      1.4634981751441956e-01
    z[2,1,2]  R837      1.1708619445562363e-01
    z[2,1,2]  R838      4.4962030649185181e-01
    z[2,1,2]  R839      -1.3260406255722046e-01
    z[2,1,2]  R840      -4.1260927915573120e-02
    z[2,1,2]  R841      -2.3052366077899933e-01
    z[2,1,2]  R842      -4.2285788804292679e-02
    z[2,1,2]  R843      9.9219158291816711e-02
    z[2,1,2]  R844      2.9561412334442139e-01
    z[2,1,2]  R845      2.1575149893760681e-01
    z[2,1,2]  R846      2.2460678592324257e-02
    z[2,1,2]  R847      -3.4787702560424805e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R750      -1
    z[2,1,3]  R751      1
    z[2,1,3]  R758      4.6444028615951538e-01
    z[2,1,3]  R759      1.4665301144123077e-01
    z[2,1,3]  R760      5.9248123317956924e-02
    z[2,1,3]  R761      -0.0647757425904274
    z[2,1,3]  R762      -3.3503524959087372e-02
    z[2,1,3]  R763      3.0617249011993408e-01
    z[2,1,3]  R764      -1.5060655772686005e-01
    z[2,1,3]  R765      -3.7506937980651855e-01
    z[2,1,3]  R766      4.7289678454399109e-01
    z[2,1,3]  R767      5.9952370822429657e-02
    z[2,1,3]  R768      2.2570972144603729e-01
    z[2,1,3]  R769      -4.0436097979545593e-01
    z[2,1,3]  R770      1.4787705242633820e-01
    z[2,1,3]  R771      3.8220247626304626e-01
    z[2,1,3]  R772      3.7393602728843689e-01
    z[2,1,3]  R773      2.1852149069309235e-01
    z[2,1,3]  R774      4.2644214630126953e-01
    z[2,1,3]  R775      3.7610808014869690e-01
    z[2,1,3]  R776      4.6936103701591492e-01
    z[2,1,3]  R777      3.8113737106323242e-01
    z[2,1,3]  R778      0.458217054605484
    z[2,1,3]  R779      3.4837085008621216e-01
    z[2,1,3]  R780      1.8025636672973633e-01
    z[2,1,3]  R781      2.6481881737709045e-01
    z[2,1,3]  R782      4.5567402243614197e-01
    z[2,1,3]  R783      4.8127308487892151e-02
    z[2,1,3]  R784      7.1094882488250732e-01
    z[2,1,3]  R785      -1.1758894473314285e-01
    z[2,1,3]  R786      -3.3963659405708313e-01
    z[2,1,3]  R787      -1.1370488256216049e-01
    z[2,1,3]  R788      -4.8172511160373688e-02
    z[2,1,3]  R789      3.3632761240005493e-01
    z[2,1,3]  R790      1.5562395751476288e-01
    z[2,1,3]  R791      2.5202763080596924e-01
    z[2,1,3]  R792      -9.6530042588710785e-02
    z[2,1,3]  R793      9.2465788125991821e-02
    z[2,1,3]  R794      0.26992267370224
    z[2,1,3]  R795      2.6868173480033875e-01
    z[2,1,3]  R796      4.7727242112159729e-01
    z[2,1,3]  R797      4.0019545704126358e-02
    z[2,1,3]  R798      4.2768466472625732e-01
    z[2,1,3]  R799      -9.6108177676796913e-03
    z[2,1,3]  R800      4.9866217374801636e-01
    z[2,1,3]  R801      2.4773922562599182e-01
    z[2,1,3]  R802      2.5836622714996338e-01
    z[2,1,3]  R803      -9.5853674411773682e-01
    z[2,1,3]  R804      -3.4687477350234985e-01
    z[2,1,3]  R805      -1.3818985223770142e-01
    z[2,1,3]  R806      -3.8389381766319275e-01
    z[2,1,3]  R807      -2.2529102861881256e-01
    z[2,1,3]  R808      4.9243035912513733e-01
    z[2,1,3]  R809      5.0554656982421875e-01
    z[2,1,3]  R810      5.1138144731521606e-01
    z[2,1,3]  R811      3.3378553390502930e-01
    z[2,1,3]  R812      -1.8854171037673950e-01
    z[2,1,3]  R813      -1.4253887534141541e-01
    z[2,1,3]  R814      2.4872681498527527e-01
    z[2,1,3]  R815      2.1641846746206284e-02
    z[2,1,3]  R816      -1.9361507892608643e-01
    z[2,1,3]  R817      -4.4752854108810425e-01
    z[2,1,3]  R818      -4.4447034597396851e-02
    z[2,1,3]  R819      -5.2434122562408447e-01
    z[2,1,3]  R820      -3.5095199942588806e-01
    z[2,1,3]  R821      -3.1402194499969482e-01
    z[2,1,3]  R822      -3.2981792092323303e-01
    z[2,1,3]  R823      -2.9031160473823547e-01
    z[2,1,3]  R824      -5.5152559280395508e-01
    z[2,1,3]  R825      -1.7999365925788879e-01
    z[2,1,3]  R826      -0.319568932056427
    z[2,1,3]  R827      -0.0645049586892128
    z[2,1,3]  R828      -6.5557742118835449e-01
    z[2,1,3]  R829      -1.2081279419362545e-02
    z[2,1,3]  R830      -0.0806296318769455
    z[2,1,3]  R831      -1.9459196925163269e-01
    z[2,1,3]  R832      -6.4039933681488037e-01
    z[2,1,3]  R833      -4.7206792235374451e-01
    z[2,1,3]  R834      -3.4568536281585693e-01
    z[2,1,3]  R835      -2.2869020700454712e-01
    z[2,1,3]  R836      -4.5102012157440186e-01
    z[2,1,3]  R837      2.3547211661934853e-02
    z[2,1,3]  R838      -2.1843446791172028e-01
    z[2,1,3]  R839      3.8228464126586914e-01
    z[2,1,3]  R840      -2.4428358674049377e-01
    z[2,1,3]  R841      -3.6610227823257446e-01
    z[2,1,3]  R842      -7.9962633550167084e-02
    z[2,1,3]  R843      -4.3234610557556152e-01
    z[2,1,3]  R844      -4.3659138679504395e-01
    z[2,1,3]  R845      -4.0801870822906494e-01
    z[2,1,3]  R846      -3.2905688881874084e-01
    z[2,1,3]  R847      -4.3137919902801514e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R752      -1
    z[2,1,4]  R753      1
    z[2,1,4]  R758      -2.8815552592277527e-01
    z[2,1,4]  R759      -6.5752822160720825e-01
    z[2,1,4]  R760      -1.6028371453285217e-01
    z[2,1,4]  R761      -2.5635886192321777e-01
    z[2,1,4]  R762      1.1484770476818085e-01
    z[2,1,4]  R763      -7.2272044420242310e-01
    z[2,1,4]  R764      2.5529885292053223e-01
    z[2,1,4]  R765      -4.5813828706741333e-01
    z[2,1,4]  R766      2.7722854167222977e-02
    z[2,1,4]  R767      -0.244576096534729
    z[2,1,4]  R768      4.5235726237297058e-01
    z[2,1,4]  R769      3.4507265686988831e-01
    z[2,1,4]  R770      -1.8130175769329071e-01
    z[2,1,4]  R771      1.6281618177890778e-01
    z[2,1,4]  R772      -1.6976632177829742e-02
    z[2,1,4]  R773      1.7127616703510284e-01
    z[2,1,4]  R774      -3.7139128893613815e-02
    z[2,1,4]  R775      4.7775000333786011e-01
    z[2,1,4]  R776      -1.0041683167219162e-01
    z[2,1,4]  R777      4.6058148145675659e-01
    z[2,1,4]  R778      -1.5805619955062866e-01
    z[2,1,4]  R779      2.7727490663528442e-01
    z[2,1,4]  R780      1.8001537770032883e-02
    z[2,1,4]  R781      -1.9209538400173187e-01
    z[2,1,4]  R782      -8.6982309818267822e-02
    z[2,1,4]  R783      4.2937391996383667e-01
    z[2,1,4]  R784      3.4035738557577133e-02
    z[2,1,4]  R785      3.4835720062255859e-01
    z[2,1,4]  R786      2.7765345573425293e-01
    z[2,1,4]  R787      3.1549766659736633e-01
    z[2,1,4]  R788      1.4113017916679382e-01
    z[2,1,4]  R789      -7.2040654718875885e-02
    z[2,1,4]  R790      4.3641266226768494e-01
    z[2,1,4]  R791      -1.7879876494407654e-01
    z[2,1,4]  R792      -0.354126900434494
    z[2,1,4]  R793      -3.4630599617958069e-01
    z[2,1,4]  R794      -0.170893132686615
    z[2,1,4]  R795      3.4464788436889648e-01
    z[2,1,4]  R796      2.5045084953308105e-01
    z[2,1,4]  R797      -3.4921568632125854e-01
    z[2,1,4]  R798      0.0611988827586174
    z[2,1,4]  R799      1.4504013955593109e-01
    z[2,1,4]  R800      1.7014007270336151e-01
    z[2,1,4]  R801      -8.7398067116737366e-02
    z[2,1,4]  R802      2.2325593233108521e-01
    z[2,1,4]  R803      -5.8964673429727554e-02
    z[2,1,4]  R804      9.7499601542949677e-02
    z[2,1,4]  R805      -7.8991755843162537e-02
    z[2,1,4]  R806      -4.2591953277587891e-01
    z[2,1,4]  R807      -1.2765172123908997e-01
    z[2,1,4]  R808      -4.7869235277175903e-01
    z[2,1,4]  R809      -0.353411465883255
    z[2,1,4]  R810      2.1292430162429810e-01
    z[2,1,4]  R811      5.5049387738108635e-03
    z[2,1,4]  R812      -4.8308354616165161e-01
    z[2,1,4]  R813      -5.2213305234909058e-01
    z[2,1,4]  R814      1.1937224864959717e-01
    z[2,1,4]  R815      1.5014718472957611e-01
    z[2,1,4]  R816      -6.3855779170989990e-01
    z[2,1,4]  R817      -5.8134567737579346e-01
    z[2,1,4]  R818      1.7674861848354340e-01
    z[2,1,4]  R819      1.7360825836658478e-01
    z[2,1,4]  R820      1.3603407144546509e-01
    z[2,1,4]  R821      2.2222118079662323e-01
    z[2,1,4]  R822      4.4917544722557068e-01
    z[2,1,4]  R823      4.6200191974639893e-01
    z[2,1,4]  R824      -1.6582775115966797e-01
    z[2,1,4]  R825      4.5760747790336609e-01
    z[2,1,4]  R826      -2.6043057441711426e-01
    z[2,1,4]  R827      -1.2828649580478668e-01
    z[2,1,4]  R828      3.2459726929664612e-01
    z[2,1,4]  R829      1.5240977704524994e-01
    z[2,1,4]  R830      -2.9337859153747559e-01
    z[2,1,4]  R831      -1.7532658576965332e-01
    z[2,1,4]  R832      -1.3813933730125427e-01
    z[2,1,4]  R833      -2.4399299919605255e-01
    z[2,1,4]  R834      -1.8310281634330750e-01
    z[2,1,4]  R835      -4.3905708193778992e-01
    z[2,1,4]  R836      -3.6279231309890747e-01
    z[2,1,4]  R837      -1.6562348604202271e-01
    z[2,1,4]  R838      1.3291072845458984e-01
    z[2,1,4]  R839      -4.0647846460342407e-01
    z[2,1,4]  R840      3.4199748188257217e-02
    z[2,1,4]  R841      7.8203096985816956e-02
    z[2,1,4]  R842      -1.6141681373119354e-01
    z[2,1,4]  R843      -1.0343640297651291e-01
    z[2,1,4]  R844      -1.0888533294200897e-01
    z[2,1,4]  R845      -2.6009339094161987e-01
    z[2,1,4]  R846      -6.3789568841457367e-02
    z[2,1,4]  R847      -1.9778449833393097e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R754      -1
    z[2,1,5]  R755      1
    z[2,1,5]  R758      -2.2357408702373505e-01
    z[2,1,5]  R759      -1.5324714593589306e-02
    z[2,1,5]  R760      6.0758337378501892e-02
    z[2,1,5]  R761      -1.7199523746967316e-01
    z[2,1,5]  R762      8.3132229745388031e-02
    z[2,1,5]  R763      -1.2672264873981476e-01
    z[2,1,5]  R764      -1.5328468382358551e-01
    z[2,1,5]  R765      1.7406722903251648e-01
    z[2,1,5]  R766      -4.0122276544570923e-01
    z[2,1,5]  R767      -1.0973126441240311e-01
    z[2,1,5]  R768      4.1944679617881775e-01
    z[2,1,5]  R769      4.6755722165107727e-01
    z[2,1,5]  R770      -2.3887167870998383e-01
    z[2,1,5]  R771      -3.8349515199661255e-01
    z[2,1,5]  R772      -3.8785532116889954e-01
    z[2,1,5]  R773      -4.1204899549484253e-01
    z[2,1,5]  R774      -2.7068731188774109e-01
    z[2,1,5]  R775      -2.9718539118766785e-01
    z[2,1,5]  R776      -1.3412435352802277e-01
    z[2,1,5]  R777      -0.412482887506485
    z[2,1,5]  R778      4.7123548574745655e-03
    z[2,1,5]  R779      -2.1599614620208740e-01
    z[2,1,5]  R780      -1.2933824956417084e-01
    z[2,1,5]  R781      -3.5681214928627014e-01
    z[2,1,5]  R782      -2.7933532372117043e-02
    z[2,1,5]  R783      -3.3970877528190613e-01
    z[2,1,5]  R784      -1.4171645045280457e-01
    z[2,1,5]  R785      9.4780838117003441e-03
    z[2,1,5]  R786      -1.3779945671558380e-01
    z[2,1,5]  R787      -0.00695176562294364
    z[2,1,5]  R788      5.6822425127029419e-01
    z[2,1,5]  R789      -3.5686764866113663e-02
    z[2,1,5]  R790      -3.5881036520004272e-01
    z[2,1,5]  R791      -1.4847515523433685e-01
    z[2,1,5]  R792      -1.2488958239555359e-01
    z[2,1,5]  R793      -2.6262101531028748e-01
    z[2,1,5]  R794      -3.7424251437187195e-01
    z[2,1,5]  R795      -5.8189444243907928e-02
    z[2,1,5]  R796      -5.7193273305892944e-01
    z[2,1,5]  R797      -1.0489203967154026e-02
    z[2,1,5]  R798      1.4155525714159012e-02
    z[2,1,5]  R799      -2.0045363903045654e-01
    z[2,1,5]  R800      3.1995948404073715e-02
    z[2,1,5]  R801      -3.4491837024688721e-01
    z[2,1,5]  R802      1.4150644652545452e-02
    z[2,1,5]  R803      -2.5481337308883667e-01
    z[2,1,5]  R804      -2.1574825223069638e-04
    z[2,1,5]  R805      -0.0421307310461998
    z[2,1,5]  R806      -1.0680418461561203e-01
    z[2,1,5]  R807      -4.5179602503776550e-01
    z[2,1,5]  R808      -2.0041167736053467e-01
    z[2,1,5]  R809      -4.3665367364883423e-01
    z[2,1,5]  R810      -2.8782343864440918e-01
    z[2,1,5]  R811      -6.0278022289276123e-01
    z[2,1,5]  R812      -0.566609799861908
    z[2,1,5]  R813      -0.28685262799263
    z[2,1,5]  R814      1.5974249690771103e-02
    z[2,1,5]  R815      -3.0622237920761108e-01
    z[2,1,5]  R816      -8.5659280419349670e-02
    z[2,1,5]  R817      -9.4244204461574554e-02
    z[2,1,5]  R818      3.6924883723258972e-01
    z[2,1,5]  R819      9.4708538381382823e-04
    z[2,1,5]  R820      -0.0814613625407219
    z[2,1,5]  R821      -3.5854384303092957e-01
    z[2,1,5]  R822      -1.4186948537826538e-01
    z[2,1,5]  R823      9.6284836530685425e-02
    z[2,1,5]  R824      1.4110732078552246e-01
    z[2,1,5]  R825      4.8242881894111633e-03
    z[2,1,5]  R826      -0.0749167948961258
    z[2,1,5]  R827      2.7209895849227905e-01
    z[2,1,5]  R828      1.9273126125335693e-01
    z[2,1,5]  R829      7.6943945884704590e-01
    z[2,1,5]  R830      -4.8499464988708496e-02
    z[2,1,5]  R831      -2.7498283982276917e-01
    z[2,1,5]  R832      -3.4907805919647217e-01
    z[2,1,5]  R833      2.7364954352378845e-01
    z[2,1,5]  R834      -4.0097177028656006e-01
    z[2,1,5]  R835      -1.1034757643938065e-01
    z[2,1,5]  R836      0.32767453789711
    z[2,1,5]  R837      -3.4630617592483759e-03
    z[2,1,5]  R838      1.9378204643726349e-01
    z[2,1,5]  R839      -2.3140968382358551e-01
    z[2,1,5]  R840      2.0276030898094177e-01
    z[2,1,5]  R841      -2.6396793127059937e-01
    z[2,1,5]  R842      -5.3916919976472855e-02
    z[2,1,5]  R843      1.4100360684096813e-02
    z[2,1,5]  R844      1.1793158203363419e-01
    z[2,1,5]  R845      -1.5098898112773895e-01
    z[2,1,5]  R846      -3.3523935079574585e-01
    z[2,1,5]  R847      -1.8744681775569916e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R756      -1
    z[2,1,6]  R757      1
    z[2,1,6]  R758      2.0618361234664917e-01
    z[2,1,6]  R759      7.9898700118064880e-02
    z[2,1,6]  R760      -4.2748656868934631e-01
    z[2,1,6]  R761      -5.4689103364944458e-01
    z[2,1,6]  R762      9.6865154802799225e-02
    z[2,1,6]  R763      -2.4084423482418060e-01
    z[2,1,6]  R764      4.4141769409179688e-02
    z[2,1,6]  R765      0.554288387298584
    z[2,1,6]  R766      1.9463993608951569e-02
    z[2,1,6]  R767      -4.3386835604906082e-02
    z[2,1,6]  R768      9.0318925678730011e-02
    z[2,1,6]  R769      -3.1461721658706665e-01
    z[2,1,6]  R770      1.3393911719322205e-01
    z[2,1,6]  R771      3.7313720583915710e-01
    z[2,1,6]  R772      -3.3675307035446167e-01
    z[2,1,6]  R773      -1.3031649589538574e-01
    z[2,1,6]  R774      -1.1199028044939041e-01
    z[2,1,6]  R775      2.5821531191468239e-02
    z[2,1,6]  R776      1.0259898751974106e-01
    z[2,1,6]  R777      -1.1703076772391796e-02
    z[2,1,6]  R778      -6.8860031664371490e-02
    z[2,1,6]  R779      6.1053719371557236e-02
    z[2,1,6]  R780      -1.2132717669010162e-01
    z[2,1,6]  R781      -1.4700870215892792e-01
    z[2,1,6]  R782      1.1287894845008850e-01
    z[2,1,6]  R783      1.7166174948215485e-01
    z[2,1,6]  R784      -2.1472658216953278e-01
    z[2,1,6]  R785      2.6899653673171997e-01
    z[2,1,6]  R786      3.5283237695693970e-01
    z[2,1,6]  R787      -3.9568844437599182e-01
    z[2,1,6]  R788      -2.1786986291408539e-01
    z[2,1,6]  R789      2.9088482260704041e-01
    z[2,1,6]  R790      -1.3363888859748840e-01
    z[2,1,6]  R791      -9.8918646574020386e-02
    z[2,1,6]  R792      -1.7414465546607971e-01
    z[2,1,6]  R793      -7.7840596437454224e-02
    z[2,1,6]  R794      0.026185292750597
    z[2,1,6]  R795      3.1590768694877625e-01
    z[2,1,6]  R796      -3.5322561860084534e-02
    z[2,1,6]  R797      -2.4731151759624481e-01
    z[2,1,6]  R798      -3.6526456475257874e-01
    z[2,1,6]  R799      -3.2610824704170227e-01
    z[2,1,6]  R800      -3.1757766008377075e-01
    z[2,1,6]  R801      -2.6561614871025085e-01
    z[2,1,6]  R802      0.147373765707016
    z[2,1,6]  R803      9.7242005169391632e-02
    z[2,1,6]  R804      1.4258872717618942e-02
    z[2,1,6]  R805      3.4969004988670349e-01
    z[2,1,6]  R806      -1.5640050172805786e-01
    z[2,1,6]  R807      -1.0230807214975357e-01
    z[2,1,6]  R808      -1.9053514301776886e-01
    z[2,1,6]  R809      1.1832785606384277e-01
    z[2,1,6]  R810      4.3967801332473755e-01
    z[2,1,6]  R811      -4.8423612117767334e-01
    z[2,1,6]  R812      1.9352915883064270e-01
    z[2,1,6]  R813      3.6890518665313721e-01
    z[2,1,6]  R814      -5.7547432184219360e-01
    z[2,1,6]  R815      3.2123643904924393e-02
    z[2,1,6]  R816      -9.8000364378094673e-03
    z[2,1,6]  R817      -1.5896634757518768e-01
    z[2,1,6]  R818      -1.9087785482406616e-01
    z[2,1,6]  R819      -1.7828333377838135e-01
    z[2,1,6]  R820      3.5070598125457764e-02
    z[2,1,6]  R821      -6.7103527486324310e-02
    z[2,1,6]  R822      6.6242665052413940e-02
    z[2,1,6]  R823      -1.4694066345691681e-01
    z[2,1,6]  R824      1.8468730151653290e-02
    z[2,1,6]  R825      2.0318174362182617e-01
    z[2,1,6]  R826      -1.7295676469802856e-01
    z[2,1,6]  R827      -1.7953509092330933e-01
    z[2,1,6]  R828      2.5688254833221436e-01
    z[2,1,6]  R829      4.6851357817649841e-01
    z[2,1,6]  R830      2.4432139098644257e-01
    z[2,1,6]  R831      4.8920312523841858e-01
    z[2,1,6]  R832      -1.7767407000064850e-02
    z[2,1,6]  R833      0.0679338276386261
    z[2,1,6]  R834      -1.4336473308503628e-02
    z[2,1,6]  R835      5.0678491592407227e-02
    z[2,1,6]  R836      -1.5902754664421082e-01
    z[2,1,6]  R837      2.6732046157121658e-02
    z[2,1,6]  R838      -6.2585294246673584e-01
    z[2,1,6]  R839      -4.8738211393356323e-02
    z[2,1,6]  R840      -1.0014757513999939e-01
    z[2,1,6]  R841      -1.3742519915103912e-01
    z[2,1,6]  R842      -1.5722940862178802e-01
    z[2,1,6]  R843      3.9180129766464233e-01
    z[2,1,6]  R844      -1.4284999668598175e-01
    z[2,1,6]  R845      2.2878804802894592e-01
    z[2,1,6]  R846      -1.3638909161090851e-01
    z[2,1,6]  R847      -5.5600155144929886e-02
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R848      -1
    z[1,5,0]  R849      1
    z[1,5,0]  R862      4.8762276768684387e-01
    z[1,5,0]  R863      5.3526413440704346e-01
    z[1,5,0]  R864      4.7786450386047363e-01
    z[1,5,0]  R865      4.3266192078590393e-01
    z[1,5,0]  R866      4.8137810826301575e-01
    z[1,5,0]  R867      4.4484078884124756e-01
    z[1,5,0]  R868      2.2758446633815765e-01
    z[1,5,0]  R869      -3.2156670093536377e-01
    z[1,5,0]  R870      -6.7632973194122314e-02
    z[1,5,0]  R871      -1.2362013012170792e-01
    z[1,5,0]  R872      6.5048910677433014e-02
    z[1,5,0]  R873      -7.9278725385665894e-01
    z[1,5,0]  R874      -8.3439606428146362e-01
    z[1,5,0]  R875      -8.2489007711410522e-01
    z[1,5,0]  R876      -6.8961602449417114e-01
    z[1,5,0]  R877      -7.8425419330596924e-01
    z[1,5,0]  R878      -6.8020766973495483e-01
    z[1,5,0]  R879      -7.2894531488418579e-01
    z[1,5,0]  R880      -8.1985729932785034e-01
    z[1,5,0]  R881      -0.830944299697876
    z[1,5,0]  R882      1.1360311508178711e-01
    z[1,5,0]  R883      1.3797410763800144e-02
    z[1,5,0]  R884      -4.2373758554458618e-01
    z[1,5,0]  R885      -3.0192825198173523e-01
    z[1,5,0]  R886      -6.3382869958877563e-01
    z[1,5,0]  R887      -6.9172859191894531e-01
    z[1,5,0]  R888      -7.5065809488296509e-01
    z[1,5,0]  R889      -8.2509487867355347e-01
    z[1,5,0]  R890      -0.679706335067749
    z[1,5,0]  R891      -9.4545549154281616e-01
    z[1,5,0]  R892      0.0442180261015892
    z[1,5,0]  R893      -2.0517329871654510e-01
    z[1,5,0]  R894      -9.0681433677673340e-01
    z[1,5,0]  R895      -7.8480494022369385e-01
    z[1,5,0]  R896      -8.7693107128143311e-01
    z[1,5,0]  R897      -7.3673528432846069e-01
    z[1,5,0]  R898      -6.9118893146514893e-01
    z[1,5,0]  R899      -7.5684589147567749e-01
    z[1,5,0]  R900      -4.3756476044654846e-01
    z[1,5,0]  R901      -7.0736819505691528e-01
    z[1,5,0]  R902      -7.5358949601650238e-02
    z[1,5,0]  R903      1.5595360100269318e-01
    z[1,5,0]  R904      3.7856489419937134e-01
    z[1,5,0]  R905      4.5991745591163635e-01
    z[1,5,0]  R906      5.6721532344818115e-01
    z[1,5,0]  R907      3.8353410363197327e-01
    z[1,5,0]  R908      7.5176799297332764e-01
    z[1,5,0]  R909      2.5073993206024170e-01
    z[1,5,0]  R910      -5.2961182594299316e-01
    z[1,5,0]  R911      7.2871428728103638e-01
    z[1,5,0]  R912      -0.573577880859375
    z[1,5,0]  R913      3.9125624299049377e-01
    z[1,5,0]  R914      -1.3802585005760193e-01
    z[1,5,0]  R915      -2.3197303712368011e-01
    z[1,5,0]  R916      -2.4491387605667114e-01
    z[1,5,0]  R917      -4.3502193689346313e-01
    z[1,5,0]  R918      1.7371350526809692e-01
    z[1,5,0]  R919      -3.4387665987014771e-01
    z[1,5,0]  R920      -2.6275321841239929e-01
    z[1,5,0]  R921      -2.6834350824356079e-01
    z[1,5,0]  R922      -1.1733414977788925e-01
    z[1,5,0]  R923      0.690343976020813
    z[1,5,0]  R924      -2.4170331656932831e-02
    z[1,5,0]  R925      -3.2999888062477112e-01
    z[1,5,0]  R926      5.5536341667175293e-01
    z[1,5,0]  R927      -1.2703700363636017e-01
    z[1,5,0]  R928      -5.0177562236785889e-01
    z[1,5,0]  R929      6.4959245920181274e-01
    z[1,5,0]  R930      5.0342237949371338e-01
    z[1,5,0]  R931      4.5965763926506042e-01
    z[1,5,0]  R932      -2.5962987542152405e-01
    z[1,5,0]  R933      6.8999834358692169e-02
    z[1,5,0]  R934      6.7577803134918213e-01
    z[1,5,0]  R935      6.9911277294158936e-01
    z[1,5,0]  R936      -5.1434552669525146e-01
    z[1,5,0]  R937      2.6208099722862244e-01
    z[1,5,0]  R938      2.0925863087177277e-01
    z[1,5,0]  R939      1.6149304807186127e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R850      -1
    z[1,5,1]  R851      1
    z[1,5,1]  R862      3.1182876229286194e-01
    z[1,5,1]  R863      3.1679326295852661e-01
    z[1,5,1]  R864      2.8544783592224121e-01
    z[1,5,1]  R865      3.0021238327026367e-01
    z[1,5,1]  R866      3.7033927440643311e-01
    z[1,5,1]  R867      2.9730680584907532e-01
    z[1,5,1]  R868      2.9784691333770752e-01
    z[1,5,1]  R869      -0.76842200756073
    z[1,5,1]  R870      -7.2994166612625122e-01
    z[1,5,1]  R871      -6.3500648736953735e-01
    z[1,5,1]  R872      5.7323312759399414e-01
    z[1,5,1]  R873      -2.5927681475877762e-02
    z[1,5,1]  R874      7.2741672396659851e-02
    z[1,5,1]  R875      -1.9623391330242157e-01
    z[1,5,1]  R876      -2.3165687918663025e-02
    z[1,5,1]  R877      6.2084991484880447e-02
    z[1,5,1]  R878      -1.1389282345771790e-01
    z[1,5,1]  R879      1.4568357169628143e-01
    z[1,5,1]  R880      -0.0789308175444603
    z[1,5,1]  R881      -3.2679599523544312e-01
    z[1,5,1]  R882      5.8238863945007324e-01
    z[1,5,1]  R883      3.8293415307998657e-01
    z[1,5,1]  R884      -8.1575781106948853e-01
    z[1,5,1]  R885      -7.2446751594543457e-01
    z[1,5,1]  R886      -2.1643690764904022e-01
    z[1,5,1]  R887      -3.0542570352554321e-01
    z[1,5,1]  R888      -2.4331867694854736e-01
    z[1,5,1]  R889      -2.3857049643993378e-01
    z[1,5,1]  R890      -2.2109535336494446e-01
    z[1,5,1]  R891      -2.5237387418746948e-01
    z[1,5,1]  R892      5.4887527227401733e-01
    z[1,5,1]  R893      -0.756986141204834
    z[1,5,1]  R894      -2.5298237800598145e-01
    z[1,5,1]  R895      -0.319732129573822
    z[1,5,1]  R896      -4.1124969720840454e-01
    z[1,5,1]  R897      -3.0991527438163757e-01
    z[1,5,1]  R898      -4.4507080316543579e-01
    z[1,5,1]  R899      -2.6714438199996948e-01
    z[1,5,1]  R900      -7.5146359205245972e-01
    z[1,5,1]  R901      -3.3937805891036987e-01
    z[1,5,1]  R902      9.6793889999389648e-02
    z[1,5,1]  R903      9.5467088976874948e-04
    z[1,5,1]  R904      4.4080372899770737e-02
    z[1,5,1]  R905      3.5572454333305359e-02
    z[1,5,1]  R906      7.6472297310829163e-02
    z[1,5,1]  R907      -7.3419380933046341e-03
    z[1,5,1]  R908      5.3024303168058395e-02
    z[1,5,1]  R909      4.7504503279924393e-02
    z[1,5,1]  R910      7.1272291243076324e-02
    z[1,5,1]  R911      5.3780563175678253e-02
    z[1,5,1]  R912      1.8765892088413239e-01
    z[1,5,1]  R913      4.5511212944984436e-01
    z[1,5,1]  R914      4.3033209443092346e-01
    z[1,5,1]  R915      -7.2222399711608887e-01
    z[1,5,1]  R916      -8.4902030229568481e-01
    z[1,5,1]  R917      3.3304911851882935e-01
    z[1,5,1]  R918      -9.1955929994583130e-01
    z[1,5,1]  R919      -0.737914502620697
    z[1,5,1]  R920      -6.8057817220687866e-01
    z[1,5,1]  R921      8.9732962846755981e-01
    z[1,5,1]  R922      9.5527225732803345e-01
    z[1,5,1]  R923      2.4952462315559387e-01
    z[1,5,1]  R924      5.9687721729278564e-01
    z[1,5,1]  R925      5.2242338657379150e-01
    z[1,5,1]  R926      4.3589583039283752e-01
    z[1,5,1]  R927      5.0764840841293335e-01
    z[1,5,1]  R928      3.8382586836814880e-01
    z[1,5,1]  R929      -4.3060076236724854e-01
    z[1,5,1]  R930      -5.8626502752304077e-01
    z[1,5,1]  R931      -3.7644475698471069e-01
    z[1,5,1]  R932      1.6134172910824418e-03
    z[1,5,1]  R933      6.9854617118835449e-01
    z[1,5,1]  R934      -3.0914485454559326e-01
    z[1,5,1]  R935      -5.4646706581115723e-01
    z[1,5,1]  R936      -5.0603449344635010e-01
    z[1,5,1]  R937      -0.873330295085907
    z[1,5,1]  R938      -8.2788646221160889e-01
    z[1,5,1]  R939      -9.1456514596939087e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R852      -1
    z[1,5,2]  R853      1
    z[1,5,2]  R862      -3.4188345074653625e-01
    z[1,5,2]  R863      1.6730089485645294e-01
    z[1,5,2]  R864      -3.2735043764114380e-01
    z[1,5,2]  R865      -1.1577780544757843e-01
    z[1,5,2]  R866      0.0608777217566967
    z[1,5,2]  R867      -4.4989970326423645e-01
    z[1,5,2]  R868      -6.7227369546890259e-01
    z[1,5,2]  R869      -4.3394207954406738e-01
    z[1,5,2]  R870      9.9671795964241028e-02
    z[1,5,2]  R871      -9.5330648124217987e-02
    z[1,5,2]  R872      6.7910069227218628e-01
    z[1,5,2]  R873      1.8427358567714691e-01
    z[1,5,2]  R874      3.8594490289688110e-01
    z[1,5,2]  R875      -1.6113594756461680e-04
    z[1,5,2]  R876      4.3455675244331360e-01
    z[1,5,2]  R877      2.2913278639316559e-01
    z[1,5,2]  R878      4.1522794961929321e-01
    z[1,5,2]  R879      4.0534734725952148e-01
    z[1,5,2]  R880      3.4077703952789307e-01
    z[1,5,2]  R881      2.7540290355682373e-01
    z[1,5,2]  R882      -0.0981765165925026
    z[1,5,2]  R883      -1.3510827720165253e-01
    z[1,5,2]  R884      1.9192628562450409e-02
    z[1,5,2]  R885      0.0211052056401968
    z[1,5,2]  R886      -0.00716095557436347
    z[1,5,2]  R887      -2.5757923722267151e-01
    z[1,5,2]  R888      2.5159388780593872e-01
    z[1,5,2]  R889      4.9874968826770782e-02
    z[1,5,2]  R890      1.4634981751441956e-01
    z[1,5,2]  R891      1.1708619445562363e-01
    z[1,5,2]  R892      4.4962030649185181e-01
    z[1,5,2]  R893      -1.3260406255722046e-01
    z[1,5,2]  R894      -4.1260927915573120e-02
    z[1,5,2]  R895      -2.3052366077899933e-01
    z[1,5,2]  R896      -4.2285788804292679e-02
    z[1,5,2]  R897      9.9219158291816711e-02
    z[1,5,2]  R898      2.9561412334442139e-01
    z[1,5,2]  R899      2.1575149893760681e-01
    z[1,5,2]  R900      2.2460678592324257e-02
    z[1,5,2]  R901      -3.4787702560424805e-01
    z[1,5,2]  R902      6.4283972978591919e-01
    z[1,5,2]  R903      2.3409101366996765e-01
    z[1,5,2]  R904      2.7970978617668152e-01
    z[1,5,2]  R905      0.496791809797287
    z[1,5,2]  R906      5.2066934108734131e-01
    z[1,5,2]  R907      5.8386647142469883e-03
    z[1,5,2]  R908      4.2420539259910583e-01
    z[1,5,2]  R909      4.7645160555839539e-01
    z[1,5,2]  R910      2.7403315901756287e-01
    z[1,5,2]  R911      -5.0252193212509155e-01
    z[1,5,2]  R912      1.7684674263000488e-01
    z[1,5,2]  R913      -4.3406879901885986e-01
    z[1,5,2]  R914      -6.0438215732574463e-01
    z[1,5,2]  R915      -3.4850567579269409e-01
    z[1,5,2]  R916      -3.3150726556777954e-01
    z[1,5,2]  R917      -5.6343829631805420e-01
    z[1,5,2]  R918      -3.9096426218748093e-02
    z[1,5,2]  R919      2.4002294242382050e-01
    z[1,5,2]  R920      -0.611361563205719
    z[1,5,2]  R921      -1.1894062906503677e-01
    z[1,5,2]  R922      2.6409627869725227e-02
    z[1,5,2]  R923      6.1987121589481831e-03
    z[1,5,2]  R924      1.1879008263349533e-01
    z[1,5,2]  R925      5.3941982984542847e-01
    z[1,5,2]  R926      -8.7805025279521942e-02
    z[1,5,2]  R927      6.1530423164367676e-01
    z[1,5,2]  R928      4.2060518264770508e-01
    z[1,5,2]  R929      -3.6346417665481567e-01
    z[1,5,2]  R930      -5.2179563045501709e-01
    z[1,5,2]  R931      -3.2189390063285828e-01
    z[1,5,2]  R932      8.4723389148712158e-01
    z[1,5,2]  R933      2.8638830780982971e-01
    z[1,5,2]  R934      -6.1005878448486328e-01
    z[1,5,2]  R935      -2.6746904850006104e-01
    z[1,5,2]  R936      -0.0676533430814743
    z[1,5,2]  R937      8.0158248543739319e-02
    z[1,5,2]  R938      5.9549078345298767e-02
    z[1,5,2]  R939      1.6035138070583344e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R854      -1
    z[1,5,3]  R855      1
    z[1,5,3]  R862      4.9243035912513733e-01
    z[1,5,3]  R863      5.0554656982421875e-01
    z[1,5,3]  R864      5.1138144731521606e-01
    z[1,5,3]  R865      3.3378553390502930e-01
    z[1,5,3]  R866      -1.8854171037673950e-01
    z[1,5,3]  R867      -1.4253887534141541e-01
    z[1,5,3]  R868      2.4872681498527527e-01
    z[1,5,3]  R869      2.1641846746206284e-02
    z[1,5,3]  R870      -1.9361507892608643e-01
    z[1,5,3]  R871      -4.4752854108810425e-01
    z[1,5,3]  R872      -4.4447034597396851e-02
    z[1,5,3]  R873      -5.2434122562408447e-01
    z[1,5,3]  R874      -3.5095199942588806e-01
    z[1,5,3]  R875      -3.1402194499969482e-01
    z[1,5,3]  R876      -3.2981792092323303e-01
    z[1,5,3]  R877      -2.9031160473823547e-01
    z[1,5,3]  R878      -5.5152559280395508e-01
    z[1,5,3]  R879      -1.7999365925788879e-01
    z[1,5,3]  R880      -0.319568932056427
    z[1,5,3]  R881      -0.0645049586892128
    z[1,5,3]  R882      -6.5557742118835449e-01
    z[1,5,3]  R883      -1.2081279419362545e-02
    z[1,5,3]  R884      -0.0806296318769455
    z[1,5,3]  R885      -1.9459196925163269e-01
    z[1,5,3]  R886      -6.4039933681488037e-01
    z[1,5,3]  R887      -4.7206792235374451e-01
    z[1,5,3]  R888      -3.4568536281585693e-01
    z[1,5,3]  R889      -2.2869020700454712e-01
    z[1,5,3]  R890      -4.5102012157440186e-01
    z[1,5,3]  R891      2.3547211661934853e-02
    z[1,5,3]  R892      -2.1843446791172028e-01
    z[1,5,3]  R893      3.8228464126586914e-01
    z[1,5,3]  R894      -2.4428358674049377e-01
    z[1,5,3]  R895      -3.6610227823257446e-01
    z[1,5,3]  R896      -7.9962633550167084e-02
    z[1,5,3]  R897      -4.3234610557556152e-01
    z[1,5,3]  R898      -4.3659138679504395e-01
    z[1,5,3]  R899      -4.0801870822906494e-01
    z[1,5,3]  R900      -3.2905688881874084e-01
    z[1,5,3]  R901      -4.3137919902801514e-01
    z[1,5,3]  R902      -1.2030338868498802e-02
    z[1,5,3]  R903      7.1206682920455933e-01
    z[1,5,3]  R904      4.6227118372917175e-01
    z[1,5,3]  R905      1.7022161185741425e-01
    z[1,5,3]  R906      -3.9080867171287537e-01
    z[1,5,3]  R907      8.0488091707229614e-01
    z[1,5,3]  R908      -2.2143563628196716e-01
    z[1,5,3]  R909      -3.1327739357948303e-01
    z[1,5,3]  R910      -1.8965117633342743e-01
    z[1,5,3]  R911      -3.6215326189994812e-01
    z[1,5,3]  R912      -2.9161635041236877e-01
    z[1,5,3]  R913      -1.8511785566806793e-01
    z[1,5,3]  R914      -1.4170631766319275e-01
    z[1,5,3]  R915      -3.8046240806579590e-01
    z[1,5,3]  R916      -5.8095515705645084e-03
    z[1,5,3]  R917      -8.5485443472862244e-02
    z[1,5,3]  R918      -2.1694874763488770e-01
    z[1,5,3]  R919      -9.1061845421791077e-02
    z[1,5,3]  R920      -1.4058266580104828e-01
    z[1,5,3]  R921      2.7991944551467896e-01
    z[1,5,3]  R922      6.6506855189800262e-02
    z[1,5,3]  R923      4.5748311281204224e-01
    z[1,5,3]  R924      3.5309907793998718e-01
    z[1,5,3]  R925      6.7494444549083710e-02
    z[1,5,3]  R926      4.4161457568407059e-02
    z[1,5,3]  R927      4.5583176612854004e-01
    z[1,5,3]  R928      4.5203980803489685e-01
    z[1,5,3]  R929      -1.9308102130889893e-01
    z[1,5,3]  R930      -1.1954199522733688e-01
    z[1,5,3]  R931      -3.7935337424278259e-01
    z[1,5,3]  R932      3.4658986330032349e-01
    z[1,5,3]  R933      5.6162470579147339e-01
    z[1,5,3]  R934      -1.8775951862335205e-01
    z[1,5,3]  R935      -1.1313343793153763e-01
    z[1,5,3]  R936      2.4873189628124237e-02
    z[1,5,3]  R937      0.0875496044754982
    z[1,5,3]  R938      -1.2553407251834869e-01
    z[1,5,3]  R939      -1.7480676993727684e-02
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R856      -1
    z[1,5,4]  R857      1
    z[1,5,4]  R862      -4.7869235277175903e-01
    z[1,5,4]  R863      -0.353411465883255
    z[1,5,4]  R864      2.1292430162429810e-01
    z[1,5,4]  R865      5.5049387738108635e-03
    z[1,5,4]  R866      -4.8308354616165161e-01
    z[1,5,4]  R867      -5.2213305234909058e-01
    z[1,5,4]  R868      1.1937224864959717e-01
    z[1,5,4]  R869      1.5014718472957611e-01
    z[1,5,4]  R870      -6.3855779170989990e-01
    z[1,5,4]  R871      -5.8134567737579346e-01
    z[1,5,4]  R872      1.7674861848354340e-01
    z[1,5,4]  R873      1.7360825836658478e-01
    z[1,5,4]  R874      1.3603407144546509e-01
    z[1,5,4]  R875      2.2222118079662323e-01
    z[1,5,4]  R876      4.4917544722557068e-01
    z[1,5,4]  R877      4.6200191974639893e-01
    z[1,5,4]  R878      -1.6582775115966797e-01
    z[1,5,4]  R879      4.5760747790336609e-01
    z[1,5,4]  R880      -2.6043057441711426e-01
    z[1,5,4]  R881      -1.2828649580478668e-01
    z[1,5,4]  R882      3.2459726929664612e-01
    z[1,5,4]  R883      1.5240977704524994e-01
    z[1,5,4]  R884      -2.9337859153747559e-01
    z[1,5,4]  R885      -1.7532658576965332e-01
    z[1,5,4]  R886      -1.3813933730125427e-01
    z[1,5,4]  R887      -2.4399299919605255e-01
    z[1,5,4]  R888      -1.8310281634330750e-01
    z[1,5,4]  R889      -4.3905708193778992e-01
    z[1,5,4]  R890      -3.6279231309890747e-01
    z[1,5,4]  R891      -1.6562348604202271e-01
    z[1,5,4]  R892      1.3291072845458984e-01
    z[1,5,4]  R893      -4.0647846460342407e-01
    z[1,5,4]  R894      3.4199748188257217e-02
    z[1,5,4]  R895      7.8203096985816956e-02
    z[1,5,4]  R896      -1.6141681373119354e-01
    z[1,5,4]  R897      -1.0343640297651291e-01
    z[1,5,4]  R898      -1.0888533294200897e-01
    z[1,5,4]  R899      -2.6009339094161987e-01
    z[1,5,4]  R900      -6.3789568841457367e-02
    z[1,5,4]  R901      -1.9778449833393097e-01
    z[1,5,4]  R902      -3.5819873213768005e-01
    z[1,5,4]  R903      8.4051378071308136e-02
    z[1,5,4]  R904      8.7837286293506622e-02
    z[1,5,4]  R905      -3.6483651399612427e-01
    z[1,5,4]  R906      2.0078261196613312e-01
    z[1,5,4]  R907      1.9267193973064423e-01
    z[1,5,4]  R908      1.1413767933845520e-01
    z[1,5,4]  R909      -3.7626230716705322e-01
    z[1,5,4]  R910      -9.2131003737449646e-02
    z[1,5,4]  R911      -2.5089371204376221e-01
    z[1,5,4]  R912      5.0921601057052612e-01
    z[1,5,4]  R913      -5.7260245084762573e-01
    z[1,5,4]  R914      5.1801240444183350e-01
    z[1,5,4]  R915      -1.7598392069339752e-01
    z[1,5,4]  R916      -2.3380665481090546e-01
    z[1,5,4]  R917      4.7376893460750580e-02
    z[1,5,4]  R918      2.6536622643470764e-01
    z[1,5,4]  R919      2.1654200553894043e-01
    z[1,5,4]  R920      2.4909342825412750e-01
    z[1,5,4]  R921      -0.0775151476264
    z[1,5,4]  R922      2.5572302937507629e-01
    z[1,5,4]  R923      -4.9793016910552979e-01
    z[1,5,4]  R924      -4.9561339616775513e-01
    z[1,5,4]  R925      -5.1052731275558472e-01
    z[1,5,4]  R926      -4.8252606391906738e-01
    z[1,5,4]  R927      -2.0163437724113464e-01
    z[1,5,4]  R928      -2.0760956406593323e-01
    z[1,5,4]  R929      5.1144324243068695e-02
    z[1,5,4]  R930      2.9054602980613708e-01
    z[1,5,4]  R931      3.7746012210845947e-01
    z[1,5,4]  R932      -8.3451956510543823e-02
    z[1,5,4]  R933      -3.3074009418487549e-01
    z[1,5,4]  R934      1.0776181519031525e-01
    z[1,5,4]  R935      -1.6035382449626923e-01
    z[1,5,4]  R936      0.302490234375
    z[1,5,4]  R937      3.8686412572860718e-01
    z[1,5,4]  R938      -1.8753142654895782e-01
    z[1,5,4]  R939      -7.1950078010559082e-02
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R858      -1
    z[1,5,5]  R859      1
    z[1,5,5]  R862      -2.0041167736053467e-01
    z[1,5,5]  R863      -4.3665367364883423e-01
    z[1,5,5]  R864      -2.8782343864440918e-01
    z[1,5,5]  R865      -6.0278022289276123e-01
    z[1,5,5]  R866      -0.566609799861908
    z[1,5,5]  R867      -0.28685262799263
    z[1,5,5]  R868      1.5974249690771103e-02
    z[1,5,5]  R869      -3.0622237920761108e-01
    z[1,5,5]  R870      -8.5659280419349670e-02
    z[1,5,5]  R871      -9.4244204461574554e-02
    z[1,5,5]  R872      3.6924883723258972e-01
    z[1,5,5]  R873      9.4708538381382823e-04
    z[1,5,5]  R874      -0.0814613625407219
    z[1,5,5]  R875      -3.5854384303092957e-01
    z[1,5,5]  R876      -1.4186948537826538e-01
    z[1,5,5]  R877      9.6284836530685425e-02
    z[1,5,5]  R878      1.4110732078552246e-01
    z[1,5,5]  R879      4.8242881894111633e-03
    z[1,5,5]  R880      -0.0749167948961258
    z[1,5,5]  R881      2.7209895849227905e-01
    z[1,5,5]  R882      1.9273126125335693e-01
    z[1,5,5]  R883      7.6943945884704590e-01
    z[1,5,5]  R884      -4.8499464988708496e-02
    z[1,5,5]  R885      -2.7498283982276917e-01
    z[1,5,5]  R886      -3.4907805919647217e-01
    z[1,5,5]  R887      2.7364954352378845e-01
    z[1,5,5]  R888      -4.0097177028656006e-01
    z[1,5,5]  R889      -1.1034757643938065e-01
    z[1,5,5]  R890      0.32767453789711
    z[1,5,5]  R891      -3.4630617592483759e-03
    z[1,5,5]  R892      1.9378204643726349e-01
    z[1,5,5]  R893      -2.3140968382358551e-01
    z[1,5,5]  R894      2.0276030898094177e-01
    z[1,5,5]  R895      -2.6396793127059937e-01
    z[1,5,5]  R896      -5.3916919976472855e-02
    z[1,5,5]  R897      1.4100360684096813e-02
    z[1,5,5]  R898      1.1793158203363419e-01
    z[1,5,5]  R899      -1.5098898112773895e-01
    z[1,5,5]  R900      -3.3523935079574585e-01
    z[1,5,5]  R901      -1.8744681775569916e-01
    z[1,5,5]  R902      -1.2088346481323242e-01
    z[1,5,5]  R903      -6.2800031900405884e-01
    z[1,5,5]  R904      -4.0164360404014587e-01
    z[1,5,5]  R905      -5.4557675123214722e-01
    z[1,5,5]  R906      -4.5615857839584351e-01
    z[1,5,5]  R907      1.0082848370075226e-01
    z[1,5,5]  R908      1.4392022788524628e-01
    z[1,5,5]  R909      2.1801939606666565e-01
    z[1,5,5]  R910      -6.6552406549453735e-01
    z[1,5,5]  R911      -7.8395850956439972e-02
    z[1,5,5]  R912      5.0746500492095947e-01
    z[1,5,5]  R913      -2.4189466238021851e-01
    z[1,5,5]  R914      -2.1659222245216370e-01
    z[1,5,5]  R915      -7.7802293002605438e-02
    z[1,5,5]  R916      -1.5291871130466461e-01
    z[1,5,5]  R917      -2.2871309518814087e-01
    z[1,5,5]  R918      -7.2227261960506439e-02
    z[1,5,5]  R919      8.4162920713424683e-02
    z[1,5,5]  R920      -7.6263256371021271e-02
    z[1,5,5]  R921      2.2961314767599106e-02
    z[1,5,5]  R922      2.7249900624155998e-02
    z[1,5,5]  R923      6.1988379806280136e-02
    z[1,5,5]  R924      2.1062639355659485e-01
    z[1,5,5]  R925      -1.4936427772045135e-01
    z[1,5,5]  R926      5.0663727521896362e-01
    z[1,5,5]  R927      3.1477779150009155e-01
    z[1,5,5]  R928      -1.0706861317157745e-01
    z[1,5,5]  R929      4.5557871460914612e-01
    z[1,5,5]  R930      -1.5782682597637177e-01
    z[1,5,5]  R931      2.0386941730976105e-01
    z[1,5,5]  R932      2.9360356926918030e-01
    z[1,5,5]  R933      1.3964110985398293e-02
    z[1,5,5]  R934      1.6813308000564575e-01
    z[1,5,5]  R935      2.7296161651611328e-01
    z[1,5,5]  R936      -4.2952352762222290e-01
    z[1,5,5]  R937      -0.0528470054268837
    z[1,5,5]  R938      -4.6429717540740967e-01
    z[1,5,5]  R939      -3.0102476477622986e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R860      -1
    z[1,5,6]  R861      1
    z[1,5,6]  R862      -1.9053514301776886e-01
    z[1,5,6]  R863      1.1832785606384277e-01
    z[1,5,6]  R864      4.3967801332473755e-01
    z[1,5,6]  R865      -4.8423612117767334e-01
    z[1,5,6]  R866      1.9352915883064270e-01
    z[1,5,6]  R867      3.6890518665313721e-01
    z[1,5,6]  R868      -5.7547432184219360e-01
    z[1,5,6]  R869      3.2123643904924393e-02
    z[1,5,6]  R870      -9.8000364378094673e-03
    z[1,5,6]  R871      -1.5896634757518768e-01
    z[1,5,6]  R872      -1.9087785482406616e-01
    z[1,5,6]  R873      -1.7828333377838135e-01
    z[1,5,6]  R874      3.5070598125457764e-02
    z[1,5,6]  R875      -6.7103527486324310e-02
    z[1,5,6]  R876      6.6242665052413940e-02
    z[1,5,6]  R877      -1.4694066345691681e-01
    z[1,5,6]  R878      1.8468730151653290e-02
    z[1,5,6]  R879      2.0318174362182617e-01
    z[1,5,6]  R880      -1.7295676469802856e-01
    z[1,5,6]  R881      -1.7953509092330933e-01
    z[1,5,6]  R882      2.5688254833221436e-01
    z[1,5,6]  R883      4.6851357817649841e-01
    z[1,5,6]  R884      2.4432139098644257e-01
    z[1,5,6]  R885      4.8920312523841858e-01
    z[1,5,6]  R886      -1.7767407000064850e-02
    z[1,5,6]  R887      0.0679338276386261
    z[1,5,6]  R888      -1.4336473308503628e-02
    z[1,5,6]  R889      5.0678491592407227e-02
    z[1,5,6]  R890      -1.5902754664421082e-01
    z[1,5,6]  R891      2.6732046157121658e-02
    z[1,5,6]  R892      -6.2585294246673584e-01
    z[1,5,6]  R893      -4.8738211393356323e-02
    z[1,5,6]  R894      -1.0014757513999939e-01
    z[1,5,6]  R895      -1.3742519915103912e-01
    z[1,5,6]  R896      -1.5722940862178802e-01
    z[1,5,6]  R897      3.9180129766464233e-01
    z[1,5,6]  R898      -1.4284999668598175e-01
    z[1,5,6]  R899      2.2878804802894592e-01
    z[1,5,6]  R900      -1.3638909161090851e-01
    z[1,5,6]  R901      -5.5600155144929886e-02
    z[1,5,6]  R902      0.654710054397583
    z[1,5,6]  R903      1.1131328344345093e-01
    z[1,5,6]  R904      -6.2751924991607666e-01
    z[1,5,6]  R905      -2.8403052687644958e-01
    z[1,5,6]  R906      -1.4015206135809422e-02
    z[1,5,6]  R907      3.9710375666618347e-01
    z[1,5,6]  R908      -4.1147151589393616e-01
    z[1,5,6]  R909      -0.648550808429718
    z[1,5,6]  R910      -3.8981980085372925e-01
    z[1,5,6]  R911      1.1535238474607468e-01
    z[1,5,6]  R912      5.1537081599235535e-02
    z[1,5,6]  R913      -1.7527288198471069e-01
    z[1,5,6]  R914      -0.308473140001297
    z[1,5,6]  R915      3.4835276007652283e-01
    z[1,5,6]  R916      1.7663891613483429e-01
    z[1,5,6]  R917      0.566135585308075
    z[1,5,6]  R918      1.7517418600618839e-03
    z[1,5,6]  R919      4.6621233224868774e-01
    z[1,5,6]  R920      -7.9900383949279785e-02
    z[1,5,6]  R921      1.5412263572216034e-01
    z[1,5,6]  R922      -4.9296006560325623e-02
    z[1,5,6]  R923      7.5118844397366047e-03
    z[1,5,6]  R924      4.6299794316291809e-01
    z[1,5,6]  R925      -1.9924205541610718e-01
    z[1,5,6]  R926      4.8924211412668228e-02
    z[1,5,6]  R927      5.5955359712243080e-03
    z[1,5,6]  R928      4.0630626678466797e-01
    z[1,5,6]  R929      1.1427410691976547e-01
    z[1,5,6]  R930      -8.3497636020183563e-02
    z[1,5,6]  R931      4.6415582299232483e-01
    z[1,5,6]  R932      3.8634572178125381e-02
    z[1,5,6]  R933      -1.5741581097245216e-02
    z[1,5,6]  R934      -2.1139627322554588e-02
    z[1,5,6]  R935      1.6749539971351624e-01
    z[1,5,6]  R936      4.4518679380416870e-01
    z[1,5,6]  R937      -4.5397195965051651e-02
    z[1,5,6]  R938      -2.7749935165047646e-02
    z[1,5,6]  R939      1.2521874904632568e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R940      -1
    z[5,1,0]  R941      1
    z[5,1,0]  R954      -7.5358949601650238e-02
    z[5,1,0]  R955      1.5595360100269318e-01
    z[5,1,0]  R956      3.7856489419937134e-01
    z[5,1,0]  R957      4.5991745591163635e-01
    z[5,1,0]  R958      5.6721532344818115e-01
    z[5,1,0]  R959      3.8353410363197327e-01
    z[5,1,0]  R960      7.5176799297332764e-01
    z[5,1,0]  R961      2.5073993206024170e-01
    z[5,1,0]  R962      -5.2961182594299316e-01
    z[5,1,0]  R963      7.2871428728103638e-01
    z[5,1,0]  R964      -0.573577880859375
    z[5,1,0]  R965      3.9125624299049377e-01
    z[5,1,0]  R966      -1.3802585005760193e-01
    z[5,1,0]  R967      -2.3197303712368011e-01
    z[5,1,0]  R968      -2.4491387605667114e-01
    z[5,1,0]  R969      -4.3502193689346313e-01
    z[5,1,0]  R970      1.7371350526809692e-01
    z[5,1,0]  R971      -3.4387665987014771e-01
    z[5,1,0]  R972      -2.6275321841239929e-01
    z[5,1,0]  R973      -2.6834350824356079e-01
    z[5,1,0]  R974      -1.1733414977788925e-01
    z[5,1,0]  R975      0.690343976020813
    z[5,1,0]  R976      -2.4170331656932831e-02
    z[5,1,0]  R977      -3.2999888062477112e-01
    z[5,1,0]  R978      5.5536341667175293e-01
    z[5,1,0]  R979      -1.2703700363636017e-01
    z[5,1,0]  R980      -5.0177562236785889e-01
    z[5,1,0]  R981      6.4959245920181274e-01
    z[5,1,0]  R982      5.0342237949371338e-01
    z[5,1,0]  R983      4.5965763926506042e-01
    z[5,1,0]  R984      -2.5962987542152405e-01
    z[5,1,0]  R985      6.8999834358692169e-02
    z[5,1,0]  R986      6.7577803134918213e-01
    z[5,1,0]  R987      6.9911277294158936e-01
    z[5,1,0]  R988      -5.1434552669525146e-01
    z[5,1,0]  R989      2.6208099722862244e-01
    z[5,1,0]  R990      2.0925863087177277e-01
    z[5,1,0]  R991      1.6149304807186127e-01
    z[5,1,0]  R992      4.8762276768684387e-01
    z[5,1,0]  R993      5.3526413440704346e-01
    z[5,1,0]  R994      4.7786450386047363e-01
    z[5,1,0]  R995      4.3266192078590393e-01
    z[5,1,0]  R996      4.8137810826301575e-01
    z[5,1,0]  R997      4.4484078884124756e-01
    z[5,1,0]  R998      2.2758446633815765e-01
    z[5,1,0]  R999      -3.2156670093536377e-01
    z[5,1,0]  R1000     -6.7632973194122314e-02
    z[5,1,0]  R1001     -1.2362013012170792e-01
    z[5,1,0]  R1002     6.5048910677433014e-02
    z[5,1,0]  R1003     -7.9278725385665894e-01
    z[5,1,0]  R1004     -8.3439606428146362e-01
    z[5,1,0]  R1005     -8.2489007711410522e-01
    z[5,1,0]  R1006     -6.8961602449417114e-01
    z[5,1,0]  R1007     -7.8425419330596924e-01
    z[5,1,0]  R1008     -6.8020766973495483e-01
    z[5,1,0]  R1009     -7.2894531488418579e-01
    z[5,1,0]  R1010     -8.1985729932785034e-01
    z[5,1,0]  R1011     -0.830944299697876
    z[5,1,0]  R1012     1.1360311508178711e-01
    z[5,1,0]  R1013     1.3797410763800144e-02
    z[5,1,0]  R1014     -4.2373758554458618e-01
    z[5,1,0]  R1015     -3.0192825198173523e-01
    z[5,1,0]  R1016     -6.3382869958877563e-01
    z[5,1,0]  R1017     -6.9172859191894531e-01
    z[5,1,0]  R1018     -7.5065809488296509e-01
    z[5,1,0]  R1019     -8.2509487867355347e-01
    z[5,1,0]  R1020     -0.679706335067749
    z[5,1,0]  R1021     -9.4545549154281616e-01
    z[5,1,0]  R1022     0.0442180261015892
    z[5,1,0]  R1023     -2.0517329871654510e-01
    z[5,1,0]  R1024     -9.0681433677673340e-01
    z[5,1,0]  R1025     -7.8480494022369385e-01
    z[5,1,0]  R1026     -8.7693107128143311e-01
    z[5,1,0]  R1027     -7.3673528432846069e-01
    z[5,1,0]  R1028     -6.9118893146514893e-01
    z[5,1,0]  R1029     -7.5684589147567749e-01
    z[5,1,0]  R1030     -4.3756476044654846e-01
    z[5,1,0]  R1031     -7.0736819505691528e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R942      -1
    z[5,1,1]  R943      1
    z[5,1,1]  R954      9.6793889999389648e-02
    z[5,1,1]  R955      9.5467088976874948e-04
    z[5,1,1]  R956      4.4080372899770737e-02
    z[5,1,1]  R957      3.5572454333305359e-02
    z[5,1,1]  R958      7.6472297310829163e-02
    z[5,1,1]  R959      -7.3419380933046341e-03
    z[5,1,1]  R960      5.3024303168058395e-02
    z[5,1,1]  R961      4.7504503279924393e-02
    z[5,1,1]  R962      7.1272291243076324e-02
    z[5,1,1]  R963      5.3780563175678253e-02
    z[5,1,1]  R964      1.8765892088413239e-01
    z[5,1,1]  R965      4.5511212944984436e-01
    z[5,1,1]  R966      4.3033209443092346e-01
    z[5,1,1]  R967      -7.2222399711608887e-01
    z[5,1,1]  R968      -8.4902030229568481e-01
    z[5,1,1]  R969      3.3304911851882935e-01
    z[5,1,1]  R970      -9.1955929994583130e-01
    z[5,1,1]  R971      -0.737914502620697
    z[5,1,1]  R972      -6.8057817220687866e-01
    z[5,1,1]  R973      8.9732962846755981e-01
    z[5,1,1]  R974      9.5527225732803345e-01
    z[5,1,1]  R975      2.4952462315559387e-01
    z[5,1,1]  R976      5.9687721729278564e-01
    z[5,1,1]  R977      5.2242338657379150e-01
    z[5,1,1]  R978      4.3589583039283752e-01
    z[5,1,1]  R979      5.0764840841293335e-01
    z[5,1,1]  R980      3.8382586836814880e-01
    z[5,1,1]  R981      -4.3060076236724854e-01
    z[5,1,1]  R982      -5.8626502752304077e-01
    z[5,1,1]  R983      -3.7644475698471069e-01
    z[5,1,1]  R984      1.6134172910824418e-03
    z[5,1,1]  R985      6.9854617118835449e-01
    z[5,1,1]  R986      -3.0914485454559326e-01
    z[5,1,1]  R987      -5.4646706581115723e-01
    z[5,1,1]  R988      -5.0603449344635010e-01
    z[5,1,1]  R989      -0.873330295085907
    z[5,1,1]  R990      -8.2788646221160889e-01
    z[5,1,1]  R991      -9.1456514596939087e-01
    z[5,1,1]  R992      3.1182876229286194e-01
    z[5,1,1]  R993      3.1679326295852661e-01
    z[5,1,1]  R994      2.8544783592224121e-01
    z[5,1,1]  R995      3.0021238327026367e-01
    z[5,1,1]  R996      3.7033927440643311e-01
    z[5,1,1]  R997      2.9730680584907532e-01
    z[5,1,1]  R998      2.9784691333770752e-01
    z[5,1,1]  R999      -0.76842200756073
    z[5,1,1]  R1000     -7.2994166612625122e-01
    z[5,1,1]  R1001     -6.3500648736953735e-01
    z[5,1,1]  R1002     5.7323312759399414e-01
    z[5,1,1]  R1003     -2.5927681475877762e-02
    z[5,1,1]  R1004     7.2741672396659851e-02
    z[5,1,1]  R1005     -1.9623391330242157e-01
    z[5,1,1]  R1006     -2.3165687918663025e-02
    z[5,1,1]  R1007     6.2084991484880447e-02
    z[5,1,1]  R1008     -1.1389282345771790e-01
    z[5,1,1]  R1009     1.4568357169628143e-01
    z[5,1,1]  R1010     -0.0789308175444603
    z[5,1,1]  R1011     -3.2679599523544312e-01
    z[5,1,1]  R1012     5.8238863945007324e-01
    z[5,1,1]  R1013     3.8293415307998657e-01
    z[5,1,1]  R1014     -8.1575781106948853e-01
    z[5,1,1]  R1015     -7.2446751594543457e-01
    z[5,1,1]  R1016     -2.1643690764904022e-01
    z[5,1,1]  R1017     -3.0542570352554321e-01
    z[5,1,1]  R1018     -2.4331867694854736e-01
    z[5,1,1]  R1019     -2.3857049643993378e-01
    z[5,1,1]  R1020     -2.2109535336494446e-01
    z[5,1,1]  R1021     -2.5237387418746948e-01
    z[5,1,1]  R1022     5.4887527227401733e-01
    z[5,1,1]  R1023     -0.756986141204834
    z[5,1,1]  R1024     -2.5298237800598145e-01
    z[5,1,1]  R1025     -0.319732129573822
    z[5,1,1]  R1026     -4.1124969720840454e-01
    z[5,1,1]  R1027     -3.0991527438163757e-01
    z[5,1,1]  R1028     -4.4507080316543579e-01
    z[5,1,1]  R1029     -2.6714438199996948e-01
    z[5,1,1]  R1030     -7.5146359205245972e-01
    z[5,1,1]  R1031     -3.3937805891036987e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R944      -1
    z[5,1,2]  R945      1
    z[5,1,2]  R954      6.4283972978591919e-01
    z[5,1,2]  R955      2.3409101366996765e-01
    z[5,1,2]  R956      2.7970978617668152e-01
    z[5,1,2]  R957      0.496791809797287
    z[5,1,2]  R958      5.2066934108734131e-01
    z[5,1,2]  R959      5.8386647142469883e-03
    z[5,1,2]  R960      4.2420539259910583e-01
    z[5,1,2]  R961      4.7645160555839539e-01
    z[5,1,2]  R962      2.7403315901756287e-01
    z[5,1,2]  R963      -5.0252193212509155e-01
    z[5,1,2]  R964      1.7684674263000488e-01
    z[5,1,2]  R965      -4.3406879901885986e-01
    z[5,1,2]  R966      -6.0438215732574463e-01
    z[5,1,2]  R967      -3.4850567579269409e-01
    z[5,1,2]  R968      -3.3150726556777954e-01
    z[5,1,2]  R969      -5.6343829631805420e-01
    z[5,1,2]  R970      -3.9096426218748093e-02
    z[5,1,2]  R971      2.4002294242382050e-01
    z[5,1,2]  R972      -0.611361563205719
    z[5,1,2]  R973      -1.1894062906503677e-01
    z[5,1,2]  R974      2.6409627869725227e-02
    z[5,1,2]  R975      6.1987121589481831e-03
    z[5,1,2]  R976      1.1879008263349533e-01
    z[5,1,2]  R977      5.3941982984542847e-01
    z[5,1,2]  R978      -8.7805025279521942e-02
    z[5,1,2]  R979      6.1530423164367676e-01
    z[5,1,2]  R980      4.2060518264770508e-01
    z[5,1,2]  R981      -3.6346417665481567e-01
    z[5,1,2]  R982      -5.2179563045501709e-01
    z[5,1,2]  R983      -3.2189390063285828e-01
    z[5,1,2]  R984      8.4723389148712158e-01
    z[5,1,2]  R985      2.8638830780982971e-01
    z[5,1,2]  R986      -6.1005878448486328e-01
    z[5,1,2]  R987      -2.6746904850006104e-01
    z[5,1,2]  R988      -0.0676533430814743
    z[5,1,2]  R989      8.0158248543739319e-02
    z[5,1,2]  R990      5.9549078345298767e-02
    z[5,1,2]  R991      1.6035138070583344e-01
    z[5,1,2]  R992      -3.4188345074653625e-01
    z[5,1,2]  R993      1.6730089485645294e-01
    z[5,1,2]  R994      -3.2735043764114380e-01
    z[5,1,2]  R995      -1.1577780544757843e-01
    z[5,1,2]  R996      0.0608777217566967
    z[5,1,2]  R997      -4.4989970326423645e-01
    z[5,1,2]  R998      -6.7227369546890259e-01
    z[5,1,2]  R999      -4.3394207954406738e-01
    z[5,1,2]  R1000     9.9671795964241028e-02
    z[5,1,2]  R1001     -9.5330648124217987e-02
    z[5,1,2]  R1002     6.7910069227218628e-01
    z[5,1,2]  R1003     1.8427358567714691e-01
    z[5,1,2]  R1004     3.8594490289688110e-01
    z[5,1,2]  R1005     -1.6113594756461680e-04
    z[5,1,2]  R1006     4.3455675244331360e-01
    z[5,1,2]  R1007     2.2913278639316559e-01
    z[5,1,2]  R1008     4.1522794961929321e-01
    z[5,1,2]  R1009     4.0534734725952148e-01
    z[5,1,2]  R1010     3.4077703952789307e-01
    z[5,1,2]  R1011     2.7540290355682373e-01
    z[5,1,2]  R1012     -0.0981765165925026
    z[5,1,2]  R1013     -1.3510827720165253e-01
    z[5,1,2]  R1014     1.9192628562450409e-02
    z[5,1,2]  R1015     0.0211052056401968
    z[5,1,2]  R1016     -0.00716095557436347
    z[5,1,2]  R1017     -2.5757923722267151e-01
    z[5,1,2]  R1018     2.5159388780593872e-01
    z[5,1,2]  R1019     4.9874968826770782e-02
    z[5,1,2]  R1020     1.4634981751441956e-01
    z[5,1,2]  R1021     1.1708619445562363e-01
    z[5,1,2]  R1022     4.4962030649185181e-01
    z[5,1,2]  R1023     -1.3260406255722046e-01
    z[5,1,2]  R1024     -4.1260927915573120e-02
    z[5,1,2]  R1025     -2.3052366077899933e-01
    z[5,1,2]  R1026     -4.2285788804292679e-02
    z[5,1,2]  R1027     9.9219158291816711e-02
    z[5,1,2]  R1028     2.9561412334442139e-01
    z[5,1,2]  R1029     2.1575149893760681e-01
    z[5,1,2]  R1030     2.2460678592324257e-02
    z[5,1,2]  R1031     -3.4787702560424805e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R946      -1
    z[5,1,3]  R947      1
    z[5,1,3]  R954      -1.2030338868498802e-02
    z[5,1,3]  R955      7.1206682920455933e-01
    z[5,1,3]  R956      4.6227118372917175e-01
    z[5,1,3]  R957      1.7022161185741425e-01
    z[5,1,3]  R958      -3.9080867171287537e-01
    z[5,1,3]  R959      8.0488091707229614e-01
    z[5,1,3]  R960      -2.2143563628196716e-01
    z[5,1,3]  R961      -3.1327739357948303e-01
    z[5,1,3]  R962      -1.8965117633342743e-01
    z[5,1,3]  R963      -3.6215326189994812e-01
    z[5,1,3]  R964      -2.9161635041236877e-01
    z[5,1,3]  R965      -1.8511785566806793e-01
    z[5,1,3]  R966      -1.4170631766319275e-01
    z[5,1,3]  R967      -3.8046240806579590e-01
    z[5,1,3]  R968      -5.8095515705645084e-03
    z[5,1,3]  R969      -8.5485443472862244e-02
    z[5,1,3]  R970      -2.1694874763488770e-01
    z[5,1,3]  R971      -9.1061845421791077e-02
    z[5,1,3]  R972      -1.4058266580104828e-01
    z[5,1,3]  R973      2.7991944551467896e-01
    z[5,1,3]  R974      6.6506855189800262e-02
    z[5,1,3]  R975      4.5748311281204224e-01
    z[5,1,3]  R976      3.5309907793998718e-01
    z[5,1,3]  R977      6.7494444549083710e-02
    z[5,1,3]  R978      4.4161457568407059e-02
    z[5,1,3]  R979      4.5583176612854004e-01
    z[5,1,3]  R980      4.5203980803489685e-01
    z[5,1,3]  R981      -1.9308102130889893e-01
    z[5,1,3]  R982      -1.1954199522733688e-01
    z[5,1,3]  R983      -3.7935337424278259e-01
    z[5,1,3]  R984      3.4658986330032349e-01
    z[5,1,3]  R985      5.6162470579147339e-01
    z[5,1,3]  R986      -1.8775951862335205e-01
    z[5,1,3]  R987      -1.1313343793153763e-01
    z[5,1,3]  R988      2.4873189628124237e-02
    z[5,1,3]  R989      0.0875496044754982
    z[5,1,3]  R990      -1.2553407251834869e-01
    z[5,1,3]  R991      -1.7480676993727684e-02
    z[5,1,3]  R992      4.9243035912513733e-01
    z[5,1,3]  R993      5.0554656982421875e-01
    z[5,1,3]  R994      5.1138144731521606e-01
    z[5,1,3]  R995      3.3378553390502930e-01
    z[5,1,3]  R996      -1.8854171037673950e-01
    z[5,1,3]  R997      -1.4253887534141541e-01
    z[5,1,3]  R998      2.4872681498527527e-01
    z[5,1,3]  R999      2.1641846746206284e-02
    z[5,1,3]  R1000     -1.9361507892608643e-01
    z[5,1,3]  R1001     -4.4752854108810425e-01
    z[5,1,3]  R1002     -4.4447034597396851e-02
    z[5,1,3]  R1003     -5.2434122562408447e-01
    z[5,1,3]  R1004     -3.5095199942588806e-01
    z[5,1,3]  R1005     -3.1402194499969482e-01
    z[5,1,3]  R1006     -3.2981792092323303e-01
    z[5,1,3]  R1007     -2.9031160473823547e-01
    z[5,1,3]  R1008     -5.5152559280395508e-01
    z[5,1,3]  R1009     -1.7999365925788879e-01
    z[5,1,3]  R1010     -0.319568932056427
    z[5,1,3]  R1011     -0.0645049586892128
    z[5,1,3]  R1012     -6.5557742118835449e-01
    z[5,1,3]  R1013     -1.2081279419362545e-02
    z[5,1,3]  R1014     -0.0806296318769455
    z[5,1,3]  R1015     -1.9459196925163269e-01
    z[5,1,3]  R1016     -6.4039933681488037e-01
    z[5,1,3]  R1017     -4.7206792235374451e-01
    z[5,1,3]  R1018     -3.4568536281585693e-01
    z[5,1,3]  R1019     -2.2869020700454712e-01
    z[5,1,3]  R1020     -4.5102012157440186e-01
    z[5,1,3]  R1021     2.3547211661934853e-02
    z[5,1,3]  R1022     -2.1843446791172028e-01
    z[5,1,3]  R1023     3.8228464126586914e-01
    z[5,1,3]  R1024     -2.4428358674049377e-01
    z[5,1,3]  R1025     -3.6610227823257446e-01
    z[5,1,3]  R1026     -7.9962633550167084e-02
    z[5,1,3]  R1027     -4.3234610557556152e-01
    z[5,1,3]  R1028     -4.3659138679504395e-01
    z[5,1,3]  R1029     -4.0801870822906494e-01
    z[5,1,3]  R1030     -3.2905688881874084e-01
    z[5,1,3]  R1031     -4.3137919902801514e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R948      -1
    z[5,1,4]  R949      1
    z[5,1,4]  R954      -3.5819873213768005e-01
    z[5,1,4]  R955      8.4051378071308136e-02
    z[5,1,4]  R956      8.7837286293506622e-02
    z[5,1,4]  R957      -3.6483651399612427e-01
    z[5,1,4]  R958      2.0078261196613312e-01
    z[5,1,4]  R959      1.9267193973064423e-01
    z[5,1,4]  R960      1.1413767933845520e-01
    z[5,1,4]  R961      -3.7626230716705322e-01
    z[5,1,4]  R962      -9.2131003737449646e-02
    z[5,1,4]  R963      -2.5089371204376221e-01
    z[5,1,4]  R964      5.0921601057052612e-01
    z[5,1,4]  R965      -5.7260245084762573e-01
    z[5,1,4]  R966      5.1801240444183350e-01
    z[5,1,4]  R967      -1.7598392069339752e-01
    z[5,1,4]  R968      -2.3380665481090546e-01
    z[5,1,4]  R969      4.7376893460750580e-02
    z[5,1,4]  R970      2.6536622643470764e-01
    z[5,1,4]  R971      2.1654200553894043e-01
    z[5,1,4]  R972      2.4909342825412750e-01
    z[5,1,4]  R973      -0.0775151476264
    z[5,1,4]  R974      2.5572302937507629e-01
    z[5,1,4]  R975      -4.9793016910552979e-01
    z[5,1,4]  R976      -4.9561339616775513e-01
    z[5,1,4]  R977      -5.1052731275558472e-01
    z[5,1,4]  R978      -4.8252606391906738e-01
    z[5,1,4]  R979      -2.0163437724113464e-01
    z[5,1,4]  R980      -2.0760956406593323e-01
    z[5,1,4]  R981      5.1144324243068695e-02
    z[5,1,4]  R982      2.9054602980613708e-01
    z[5,1,4]  R983      3.7746012210845947e-01
    z[5,1,4]  R984      -8.3451956510543823e-02
    z[5,1,4]  R985      -3.3074009418487549e-01
    z[5,1,4]  R986      1.0776181519031525e-01
    z[5,1,4]  R987      -1.6035382449626923e-01
    z[5,1,4]  R988      0.302490234375
    z[5,1,4]  R989      3.8686412572860718e-01
    z[5,1,4]  R990      -1.8753142654895782e-01
    z[5,1,4]  R991      -7.1950078010559082e-02
    z[5,1,4]  R992      -4.7869235277175903e-01
    z[5,1,4]  R993      -0.353411465883255
    z[5,1,4]  R994      2.1292430162429810e-01
    z[5,1,4]  R995      5.5049387738108635e-03
    z[5,1,4]  R996      -4.8308354616165161e-01
    z[5,1,4]  R997      -5.2213305234909058e-01
    z[5,1,4]  R998      1.1937224864959717e-01
    z[5,1,4]  R999      1.5014718472957611e-01
    z[5,1,4]  R1000     -6.3855779170989990e-01
    z[5,1,4]  R1001     -5.8134567737579346e-01
    z[5,1,4]  R1002     1.7674861848354340e-01
    z[5,1,4]  R1003     1.7360825836658478e-01
    z[5,1,4]  R1004     1.3603407144546509e-01
    z[5,1,4]  R1005     2.2222118079662323e-01
    z[5,1,4]  R1006     4.4917544722557068e-01
    z[5,1,4]  R1007     4.6200191974639893e-01
    z[5,1,4]  R1008     -1.6582775115966797e-01
    z[5,1,4]  R1009     4.5760747790336609e-01
    z[5,1,4]  R1010     -2.6043057441711426e-01
    z[5,1,4]  R1011     -1.2828649580478668e-01
    z[5,1,4]  R1012     3.2459726929664612e-01
    z[5,1,4]  R1013     1.5240977704524994e-01
    z[5,1,4]  R1014     -2.9337859153747559e-01
    z[5,1,4]  R1015     -1.7532658576965332e-01
    z[5,1,4]  R1016     -1.3813933730125427e-01
    z[5,1,4]  R1017     -2.4399299919605255e-01
    z[5,1,4]  R1018     -1.8310281634330750e-01
    z[5,1,4]  R1019     -4.3905708193778992e-01
    z[5,1,4]  R1020     -3.6279231309890747e-01
    z[5,1,4]  R1021     -1.6562348604202271e-01
    z[5,1,4]  R1022     1.3291072845458984e-01
    z[5,1,4]  R1023     -4.0647846460342407e-01
    z[5,1,4]  R1024     3.4199748188257217e-02
    z[5,1,4]  R1025     7.8203096985816956e-02
    z[5,1,4]  R1026     -1.6141681373119354e-01
    z[5,1,4]  R1027     -1.0343640297651291e-01
    z[5,1,4]  R1028     -1.0888533294200897e-01
    z[5,1,4]  R1029     -2.6009339094161987e-01
    z[5,1,4]  R1030     -6.3789568841457367e-02
    z[5,1,4]  R1031     -1.9778449833393097e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R950      -1
    z[5,1,5]  R951      1
    z[5,1,5]  R954      -1.2088346481323242e-01
    z[5,1,5]  R955      -6.2800031900405884e-01
    z[5,1,5]  R956      -4.0164360404014587e-01
    z[5,1,5]  R957      -5.4557675123214722e-01
    z[5,1,5]  R958      -4.5615857839584351e-01
    z[5,1,5]  R959      1.0082848370075226e-01
    z[5,1,5]  R960      1.4392022788524628e-01
    z[5,1,5]  R961      2.1801939606666565e-01
    z[5,1,5]  R962      -6.6552406549453735e-01
    z[5,1,5]  R963      -7.8395850956439972e-02
    z[5,1,5]  R964      5.0746500492095947e-01
    z[5,1,5]  R965      -2.4189466238021851e-01
    z[5,1,5]  R966      -2.1659222245216370e-01
    z[5,1,5]  R967      -7.7802293002605438e-02
    z[5,1,5]  R968      -1.5291871130466461e-01
    z[5,1,5]  R969      -2.2871309518814087e-01
    z[5,1,5]  R970      -7.2227261960506439e-02
    z[5,1,5]  R971      8.4162920713424683e-02
    z[5,1,5]  R972      -7.6263256371021271e-02
    z[5,1,5]  R973      2.2961314767599106e-02
    z[5,1,5]  R974      2.7249900624155998e-02
    z[5,1,5]  R975      6.1988379806280136e-02
    z[5,1,5]  R976      2.1062639355659485e-01
    z[5,1,5]  R977      -1.4936427772045135e-01
    z[5,1,5]  R978      5.0663727521896362e-01
    z[5,1,5]  R979      3.1477779150009155e-01
    z[5,1,5]  R980      -1.0706861317157745e-01
    z[5,1,5]  R981      4.5557871460914612e-01
    z[5,1,5]  R982      -1.5782682597637177e-01
    z[5,1,5]  R983      2.0386941730976105e-01
    z[5,1,5]  R984      2.9360356926918030e-01
    z[5,1,5]  R985      1.3964110985398293e-02
    z[5,1,5]  R986      1.6813308000564575e-01
    z[5,1,5]  R987      2.7296161651611328e-01
    z[5,1,5]  R988      -4.2952352762222290e-01
    z[5,1,5]  R989      -0.0528470054268837
    z[5,1,5]  R990      -4.6429717540740967e-01
    z[5,1,5]  R991      -3.0102476477622986e-01
    z[5,1,5]  R992      -2.0041167736053467e-01
    z[5,1,5]  R993      -4.3665367364883423e-01
    z[5,1,5]  R994      -2.8782343864440918e-01
    z[5,1,5]  R995      -6.0278022289276123e-01
    z[5,1,5]  R996      -0.566609799861908
    z[5,1,5]  R997      -0.28685262799263
    z[5,1,5]  R998      1.5974249690771103e-02
    z[5,1,5]  R999      -3.0622237920761108e-01
    z[5,1,5]  R1000     -8.5659280419349670e-02
    z[5,1,5]  R1001     -9.4244204461574554e-02
    z[5,1,5]  R1002     3.6924883723258972e-01
    z[5,1,5]  R1003     9.4708538381382823e-04
    z[5,1,5]  R1004     -0.0814613625407219
    z[5,1,5]  R1005     -3.5854384303092957e-01
    z[5,1,5]  R1006     -1.4186948537826538e-01
    z[5,1,5]  R1007     9.6284836530685425e-02
    z[5,1,5]  R1008     1.4110732078552246e-01
    z[5,1,5]  R1009     4.8242881894111633e-03
    z[5,1,5]  R1010     -0.0749167948961258
    z[5,1,5]  R1011     2.7209895849227905e-01
    z[5,1,5]  R1012     1.9273126125335693e-01
    z[5,1,5]  R1013     7.6943945884704590e-01
    z[5,1,5]  R1014     -4.8499464988708496e-02
    z[5,1,5]  R1015     -2.7498283982276917e-01
    z[5,1,5]  R1016     -3.4907805919647217e-01
    z[5,1,5]  R1017     2.7364954352378845e-01
    z[5,1,5]  R1018     -4.0097177028656006e-01
    z[5,1,5]  R1019     -1.1034757643938065e-01
    z[5,1,5]  R1020     0.32767453789711
    z[5,1,5]  R1021     -3.4630617592483759e-03
    z[5,1,5]  R1022     1.9378204643726349e-01
    z[5,1,5]  R1023     -2.3140968382358551e-01
    z[5,1,5]  R1024     2.0276030898094177e-01
    z[5,1,5]  R1025     -2.6396793127059937e-01
    z[5,1,5]  R1026     -5.3916919976472855e-02
    z[5,1,5]  R1027     1.4100360684096813e-02
    z[5,1,5]  R1028     1.1793158203363419e-01
    z[5,1,5]  R1029     -1.5098898112773895e-01
    z[5,1,5]  R1030     -3.3523935079574585e-01
    z[5,1,5]  R1031     -1.8744681775569916e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R952      -1
    z[5,1,6]  R953      1
    z[5,1,6]  R954      0.654710054397583
    z[5,1,6]  R955      1.1131328344345093e-01
    z[5,1,6]  R956      -6.2751924991607666e-01
    z[5,1,6]  R957      -2.8403052687644958e-01
    z[5,1,6]  R958      -1.4015206135809422e-02
    z[5,1,6]  R959      3.9710375666618347e-01
    z[5,1,6]  R960      -4.1147151589393616e-01
    z[5,1,6]  R961      -0.648550808429718
    z[5,1,6]  R962      -3.8981980085372925e-01
    z[5,1,6]  R963      1.1535238474607468e-01
    z[5,1,6]  R964      5.1537081599235535e-02
    z[5,1,6]  R965      -1.7527288198471069e-01
    z[5,1,6]  R966      -0.308473140001297
    z[5,1,6]  R967      3.4835276007652283e-01
    z[5,1,6]  R968      1.7663891613483429e-01
    z[5,1,6]  R969      0.566135585308075
    z[5,1,6]  R970      1.7517418600618839e-03
    z[5,1,6]  R971      4.6621233224868774e-01
    z[5,1,6]  R972      -7.9900383949279785e-02
    z[5,1,6]  R973      1.5412263572216034e-01
    z[5,1,6]  R974      -4.9296006560325623e-02
    z[5,1,6]  R975      7.5118844397366047e-03
    z[5,1,6]  R976      4.6299794316291809e-01
    z[5,1,6]  R977      -1.9924205541610718e-01
    z[5,1,6]  R978      4.8924211412668228e-02
    z[5,1,6]  R979      5.5955359712243080e-03
    z[5,1,6]  R980      4.0630626678466797e-01
    z[5,1,6]  R981      1.1427410691976547e-01
    z[5,1,6]  R982      -8.3497636020183563e-02
    z[5,1,6]  R983      4.6415582299232483e-01
    z[5,1,6]  R984      3.8634572178125381e-02
    z[5,1,6]  R985      -1.5741581097245216e-02
    z[5,1,6]  R986      -2.1139627322554588e-02
    z[5,1,6]  R987      1.6749539971351624e-01
    z[5,1,6]  R988      4.4518679380416870e-01
    z[5,1,6]  R989      -4.5397195965051651e-02
    z[5,1,6]  R990      -2.7749935165047646e-02
    z[5,1,6]  R991      1.2521874904632568e-01
    z[5,1,6]  R992      -1.9053514301776886e-01
    z[5,1,6]  R993      1.1832785606384277e-01
    z[5,1,6]  R994      4.3967801332473755e-01
    z[5,1,6]  R995      -4.8423612117767334e-01
    z[5,1,6]  R996      1.9352915883064270e-01
    z[5,1,6]  R997      3.6890518665313721e-01
    z[5,1,6]  R998      -5.7547432184219360e-01
    z[5,1,6]  R999      3.2123643904924393e-02
    z[5,1,6]  R1000     -9.8000364378094673e-03
    z[5,1,6]  R1001     -1.5896634757518768e-01
    z[5,1,6]  R1002     -1.9087785482406616e-01
    z[5,1,6]  R1003     -1.7828333377838135e-01
    z[5,1,6]  R1004     3.5070598125457764e-02
    z[5,1,6]  R1005     -6.7103527486324310e-02
    z[5,1,6]  R1006     6.6242665052413940e-02
    z[5,1,6]  R1007     -1.4694066345691681e-01
    z[5,1,6]  R1008     1.8468730151653290e-02
    z[5,1,6]  R1009     2.0318174362182617e-01
    z[5,1,6]  R1010     -1.7295676469802856e-01
    z[5,1,6]  R1011     -1.7953509092330933e-01
    z[5,1,6]  R1012     2.5688254833221436e-01
    z[5,1,6]  R1013     4.6851357817649841e-01
    z[5,1,6]  R1014     2.4432139098644257e-01
    z[5,1,6]  R1015     4.8920312523841858e-01
    z[5,1,6]  R1016     -1.7767407000064850e-02
    z[5,1,6]  R1017     0.0679338276386261
    z[5,1,6]  R1018     -1.4336473308503628e-02
    z[5,1,6]  R1019     5.0678491592407227e-02
    z[5,1,6]  R1020     -1.5902754664421082e-01
    z[5,1,6]  R1021     2.6732046157121658e-02
    z[5,1,6]  R1022     -6.2585294246673584e-01
    z[5,1,6]  R1023     -4.8738211393356323e-02
    z[5,1,6]  R1024     -1.0014757513999939e-01
    z[5,1,6]  R1025     -1.3742519915103912e-01
    z[5,1,6]  R1026     -1.5722940862178802e-01
    z[5,1,6]  R1027     3.9180129766464233e-01
    z[5,1,6]  R1028     -1.4284999668598175e-01
    z[5,1,6]  R1029     2.2878804802894592e-01
    z[5,1,6]  R1030     -1.3638909161090851e-01
    z[5,1,6]  R1031     -5.5600155144929886e-02
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R1032     -1
    z[1,6,0]  R1033     1
    z[1,6,0]  R1046     4.8762276768684387e-01
    z[1,6,0]  R1047     5.3526413440704346e-01
    z[1,6,0]  R1048     4.7786450386047363e-01
    z[1,6,0]  R1049     4.3266192078590393e-01
    z[1,6,0]  R1050     4.8137810826301575e-01
    z[1,6,0]  R1051     4.4484078884124756e-01
    z[1,6,0]  R1052     2.2758446633815765e-01
    z[1,6,0]  R1053     -3.2156670093536377e-01
    z[1,6,0]  R1054     -6.7632973194122314e-02
    z[1,6,0]  R1055     -1.2362013012170792e-01
    z[1,6,0]  R1056     6.5048910677433014e-02
    z[1,6,0]  R1057     -7.9278725385665894e-01
    z[1,6,0]  R1058     -8.3439606428146362e-01
    z[1,6,0]  R1059     -8.2489007711410522e-01
    z[1,6,0]  R1060     -6.8961602449417114e-01
    z[1,6,0]  R1061     -7.8425419330596924e-01
    z[1,6,0]  R1062     -6.8020766973495483e-01
    z[1,6,0]  R1063     -7.2894531488418579e-01
    z[1,6,0]  R1064     -8.1985729932785034e-01
    z[1,6,0]  R1065     -0.830944299697876
    z[1,6,0]  R1066     1.1360311508178711e-01
    z[1,6,0]  R1067     1.3797410763800144e-02
    z[1,6,0]  R1068     -4.2373758554458618e-01
    z[1,6,0]  R1069     -3.0192825198173523e-01
    z[1,6,0]  R1070     -6.3382869958877563e-01
    z[1,6,0]  R1071     -6.9172859191894531e-01
    z[1,6,0]  R1072     -7.5065809488296509e-01
    z[1,6,0]  R1073     -8.2509487867355347e-01
    z[1,6,0]  R1074     -0.679706335067749
    z[1,6,0]  R1075     -9.4545549154281616e-01
    z[1,6,0]  R1076     0.0442180261015892
    z[1,6,0]  R1077     -2.0517329871654510e-01
    z[1,6,0]  R1078     -9.0681433677673340e-01
    z[1,6,0]  R1079     -7.8480494022369385e-01
    z[1,6,0]  R1080     -8.7693107128143311e-01
    z[1,6,0]  R1081     -7.3673528432846069e-01
    z[1,6,0]  R1082     -6.9118893146514893e-01
    z[1,6,0]  R1083     -7.5684589147567749e-01
    z[1,6,0]  R1084     -4.3756476044654846e-01
    z[1,6,0]  R1085     -7.0736819505691528e-01
    z[1,6,0]  R1086     2.0031196996569633e-02
    z[1,6,0]  R1087     4.7062397003173828e-01
    z[1,6,0]  R1088     -2.0097967982292175e-01
    z[1,6,0]  R1089     5.3255504369735718e-01
    z[1,6,0]  R1090     -5.3218755871057510e-02
    z[1,6,0]  R1091     -5.1938509941101074e-01
    z[1,6,0]  R1092     7.6573394238948822e-02
    z[1,6,0]  R1093     -6.3433700799942017e-01
    z[1,6,0]  R1094     2.9662674292922020e-02
    z[1,6,0]  R1095     5.4677534103393555e-01
    z[1,6,0]  R1096     1.3562743365764618e-01
    z[1,6,0]  R1097     1.5572011470794678e-01
    z[1,6,0]  R1098     1.1420238018035889e-01
    z[1,6,0]  R1099     2.3889848962426186e-02
    z[1,6,0]  R1100     -1.5095965564250946e-01
    z[1,6,0]  R1101     -3.1263357400894165e-01
    z[1,6,0]  R1102     -2.6962655782699585e-01
    z[1,6,0]  R1103     -2.3602253198623657e-01
    z[1,6,0]  R1104     -2.9074054956436157e-01
    z[1,6,0]  R1105     -3.3436134457588196e-01
    z[1,6,0]  R1106     -1.2169932574033737e-01
    z[1,6,0]  R1107     1.3749545812606812e-01
    z[1,6,0]  R1108     -2.2975397109985352e-01
    z[1,6,0]  R1109     -3.8394263386726379e-01
    z[1,6,0]  R1110     -2.8801003098487854e-01
    z[1,6,0]  R1111     -2.5030487775802612e-01
    z[1,6,0]  R1112     5.4529821872711182e-01
    z[1,6,0]  R1113     3.7663927674293518e-01
    z[1,6,0]  R1114     -2.1984383463859558e-01
    z[1,6,0]  R1115     -6.0424816608428955e-01
    z[1,6,0]  R1116     3.0019545927643776e-02
    z[1,6,0]  R1117     -1.9691903889179230e-01
    z[1,6,0]  R1118     7.2666600346565247e-02
    z[1,6,0]  R1119     -1.9034427404403687e-01
    z[1,6,0]  R1120     1.2171491980552673e-01
    z[1,6,0]  R1121     -0.00383838452398777
    z[1,6,0]  R1122     -0.226633220911026
    z[1,6,0]  R1123     -4.5925104618072510e-01
    z[1,6,0]  R1124     -4.1722607612609863e-01
    z[1,6,0]  R1125     -2.6629993319511414e-01
    z[1,6,0]  R1126     -2.9132384061813354e-01
    z[1,6,0]  R1127     -3.7018135190010071e-01
    z[1,6,0]  R1128     1.9356849789619446e-01
    z[1,6,0]  R1129     -3.1235665082931519e-01
    z[1,6,0]  R1130     3.4809085726737976e-01
    z[1,6,0]  R1131     5.3691053390502930e-01
    z[1,6,0]  R1132     -4.8993730545043945e-01
    z[1,6,0]  R1133     5.6050747632980347e-01
    z[1,6,0]  R1134     -8.0752231180667877e-02
    z[1,6,0]  R1135     -4.3593738228082657e-02
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R1034     -1
    z[1,6,1]  R1035     1
    z[1,6,1]  R1046     3.1182876229286194e-01
    z[1,6,1]  R1047     3.1679326295852661e-01
    z[1,6,1]  R1048     2.8544783592224121e-01
    z[1,6,1]  R1049     3.0021238327026367e-01
    z[1,6,1]  R1050     3.7033927440643311e-01
    z[1,6,1]  R1051     2.9730680584907532e-01
    z[1,6,1]  R1052     2.9784691333770752e-01
    z[1,6,1]  R1053     -0.76842200756073
    z[1,6,1]  R1054     -7.2994166612625122e-01
    z[1,6,1]  R1055     -6.3500648736953735e-01
    z[1,6,1]  R1056     5.7323312759399414e-01
    z[1,6,1]  R1057     -2.5927681475877762e-02
    z[1,6,1]  R1058     7.2741672396659851e-02
    z[1,6,1]  R1059     -1.9623391330242157e-01
    z[1,6,1]  R1060     -2.3165687918663025e-02
    z[1,6,1]  R1061     6.2084991484880447e-02
    z[1,6,1]  R1062     -1.1389282345771790e-01
    z[1,6,1]  R1063     1.4568357169628143e-01
    z[1,6,1]  R1064     -0.0789308175444603
    z[1,6,1]  R1065     -3.2679599523544312e-01
    z[1,6,1]  R1066     5.8238863945007324e-01
    z[1,6,1]  R1067     3.8293415307998657e-01
    z[1,6,1]  R1068     -8.1575781106948853e-01
    z[1,6,1]  R1069     -7.2446751594543457e-01
    z[1,6,1]  R1070     -2.1643690764904022e-01
    z[1,6,1]  R1071     -3.0542570352554321e-01
    z[1,6,1]  R1072     -2.4331867694854736e-01
    z[1,6,1]  R1073     -2.3857049643993378e-01
    z[1,6,1]  R1074     -2.2109535336494446e-01
    z[1,6,1]  R1075     -2.5237387418746948e-01
    z[1,6,1]  R1076     5.4887527227401733e-01
    z[1,6,1]  R1077     -0.756986141204834
    z[1,6,1]  R1078     -2.5298237800598145e-01
    z[1,6,1]  R1079     -0.319732129573822
    z[1,6,1]  R1080     -4.1124969720840454e-01
    z[1,6,1]  R1081     -3.0991527438163757e-01
    z[1,6,1]  R1082     -4.4507080316543579e-01
    z[1,6,1]  R1083     -2.6714438199996948e-01
    z[1,6,1]  R1084     -7.5146359205245972e-01
    z[1,6,1]  R1085     -3.3937805891036987e-01
    z[1,6,1]  R1086     -7.8190410137176514e-01
    z[1,6,1]  R1087     -3.6997714638710022e-01
    z[1,6,1]  R1088     -6.0399180650711060e-01
    z[1,6,1]  R1089     -4.4579467177391052e-01
    z[1,6,1]  R1090     -8.2918137311935425e-01
    z[1,6,1]  R1091     -6.4737731218338013e-01
    z[1,6,1]  R1092     -2.8673955798149109e-01
    z[1,6,1]  R1093     -5.9463238716125488e-01
    z[1,6,1]  R1094     -4.4625002145767212e-01
    z[1,6,1]  R1095     -3.0965870618820190e-01
    z[1,6,1]  R1096     4.0525174140930176e-01
    z[1,6,1]  R1097     2.8946825861930847e-01
    z[1,6,1]  R1098     9.2991006374359131e-01
    z[1,6,1]  R1099     8.6411511898040771e-01
    z[1,6,1]  R1100     8.2175713777542114e-01
    z[1,6,1]  R1101     6.9736850261688232e-01
    z[1,6,1]  R1102     0.808444619178772
    z[1,6,1]  R1103     7.2943145036697388e-01
    z[1,6,1]  R1104     5.6239664554595947e-01
    z[1,6,1]  R1105     6.5161406993865967e-01
    z[1,6,1]  R1106     8.4629094600677490e-01
    z[1,6,1]  R1107     8.7107741832733154e-01
    z[1,6,1]  R1108     9.1347074508666992e-01
    z[1,6,1]  R1109     6.5538221597671509e-01
    z[1,6,1]  R1110     8.3171874284744263e-01
    z[1,6,1]  R1111     3.9090868830680847e-01
    z[1,6,1]  R1112     7.8255093097686768e-01
    z[1,6,1]  R1113     3.5327199101448059e-01
    z[1,6,1]  R1114     3.1925094127655029e-01
    z[1,6,1]  R1115     5.1732963323593140e-01
    z[1,6,1]  R1116     8.7808293104171753e-01
    z[1,6,1]  R1117     6.3551861047744751e-01
    z[1,6,1]  R1118     5.8599531650543213e-01
    z[1,6,1]  R1119     8.0284309387207031e-01
    z[1,6,1]  R1120     7.7548879384994507e-01
    z[1,6,1]  R1121     7.5157040357589722e-01
    z[1,6,1]  R1122     7.3652219772338867e-01
    z[1,6,1]  R1123     7.1352082490921021e-01
    z[1,6,1]  R1124     7.2306710481643677e-01
    z[1,6,1]  R1125     3.7456589937210083e-01
    z[1,6,1]  R1126     6.7980217933654785e-01
    z[1,6,1]  R1127     7.6989412307739258e-01
    z[1,6,1]  R1128     0.847685694694519
    z[1,6,1]  R1129     0.807413637638092
    z[1,6,1]  R1130     3.1038349866867065e-01
    z[1,6,1]  R1131     7.4890291690826416e-01
    z[1,6,1]  R1132     5.3914952278137207e-01
    z[1,6,1]  R1133     1.5823675692081451e-01
    z[1,6,1]  R1134     8.0106192827224731e-01
    z[1,6,1]  R1135     7.4141615629196167e-01
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R1036     -1
    z[1,6,2]  R1037     1
    z[1,6,2]  R1046     -3.4188345074653625e-01
    z[1,6,2]  R1047     1.6730089485645294e-01
    z[1,6,2]  R1048     -3.2735043764114380e-01
    z[1,6,2]  R1049     -1.1577780544757843e-01
    z[1,6,2]  R1050     0.0608777217566967
    z[1,6,2]  R1051     -4.4989970326423645e-01
    z[1,6,2]  R1052     -6.7227369546890259e-01
    z[1,6,2]  R1053     -4.3394207954406738e-01
    z[1,6,2]  R1054     9.9671795964241028e-02
    z[1,6,2]  R1055     -9.5330648124217987e-02
    z[1,6,2]  R1056     6.7910069227218628e-01
    z[1,6,2]  R1057     1.8427358567714691e-01
    z[1,6,2]  R1058     3.8594490289688110e-01
    z[1,6,2]  R1059     -1.6113594756461680e-04
    z[1,6,2]  R1060     4.3455675244331360e-01
    z[1,6,2]  R1061     2.2913278639316559e-01
    z[1,6,2]  R1062     4.1522794961929321e-01
    z[1,6,2]  R1063     4.0534734725952148e-01
    z[1,6,2]  R1064     3.4077703952789307e-01
    z[1,6,2]  R1065     2.7540290355682373e-01
    z[1,6,2]  R1066     -0.0981765165925026
    z[1,6,2]  R1067     -1.3510827720165253e-01
    z[1,6,2]  R1068     1.9192628562450409e-02
    z[1,6,2]  R1069     0.0211052056401968
    z[1,6,2]  R1070     -0.00716095557436347
    z[1,6,2]  R1071     -2.5757923722267151e-01
    z[1,6,2]  R1072     2.5159388780593872e-01
    z[1,6,2]  R1073     4.9874968826770782e-02
    z[1,6,2]  R1074     1.4634981751441956e-01
    z[1,6,2]  R1075     1.1708619445562363e-01
    z[1,6,2]  R1076     4.4962030649185181e-01
    z[1,6,2]  R1077     -1.3260406255722046e-01
    z[1,6,2]  R1078     -4.1260927915573120e-02
    z[1,6,2]  R1079     -2.3052366077899933e-01
    z[1,6,2]  R1080     -4.2285788804292679e-02
    z[1,6,2]  R1081     9.9219158291816711e-02
    z[1,6,2]  R1082     2.9561412334442139e-01
    z[1,6,2]  R1083     2.1575149893760681e-01
    z[1,6,2]  R1084     2.2460678592324257e-02
    z[1,6,2]  R1085     -3.4787702560424805e-01
    z[1,6,2]  R1086     -1.3319614529609680e-01
    z[1,6,2]  R1087     -3.3799886703491211e-01
    z[1,6,2]  R1088     -2.8119698166847229e-01
    z[1,6,2]  R1089     -6.3282884657382965e-03
    z[1,6,2]  R1090     -4.1510784626007080e-01
    z[1,6,2]  R1091     -2.1796886622905731e-01
    z[1,6,2]  R1092     -3.6379560828208923e-02
    z[1,6,2]  R1093     3.6675009876489639e-02
    z[1,6,2]  R1094     -1.8968142569065094e-01
    z[1,6,2]  R1095     -1.4247059822082520e-01
    z[1,6,2]  R1096     -1.2563848495483398e-01
    z[1,6,2]  R1097     -9.7060143947601318e-02
    z[1,6,2]  R1098     -2.1673109382390976e-02
    z[1,6,2]  R1099     -4.1682547330856323e-01
    z[1,6,2]  R1100     -1.6679960489273071e-01
    z[1,6,2]  R1101     -0.431225061416626
    z[1,6,2]  R1102     0.111131452023983
    z[1,6,2]  R1103     -4.5923840999603271e-01
    z[1,6,2]  R1104     -7.5315505266189575e-01
    z[1,6,2]  R1105     -5.0678777694702148e-01
    z[1,6,2]  R1106     -2.5695204734802246e-01
    z[1,6,2]  R1107     -2.2990810871124268e-01
    z[1,6,2]  R1108     -9.1658405959606171e-02
    z[1,6,2]  R1109     5.6675948202610016e-02
    z[1,6,2]  R1110     -5.0259608775377274e-02
    z[1,6,2]  R1111     1.0611893236637115e-01
    z[1,6,2]  R1112     1.9353662431240082e-01
    z[1,6,2]  R1113     1.5623576939105988e-01
    z[1,6,2]  R1114     7.5560994446277618e-04
    z[1,6,2]  R1115     3.2969883084297180e-01
    z[1,6,2]  R1116     -4.0979039669036865e-01
    z[1,6,2]  R1117     2.3030509054660797e-01
    z[1,6,2]  R1118     4.4043174386024475e-01
    z[1,6,2]  R1119     -2.1861056983470917e-01
    z[1,6,2]  R1120     -3.9543649554252625e-01
    z[1,6,2]  R1121     -4.8836305737495422e-01
    z[1,6,2]  R1122     -1.5879217535257339e-03
    z[1,6,2]  R1123     -2.4725767970085144e-01
    z[1,6,2]  R1124     -1.1703561991453171e-01
    z[1,6,2]  R1125     0.0369969867169857
    z[1,6,2]  R1126     -3.4943285584449768e-01
    z[1,6,2]  R1127     -2.9353508353233337e-01
    z[1,6,2]  R1128     -7.9275742173194885e-03
    z[1,6,2]  R1129     -2.2706474363803864e-01
    z[1,6,2]  R1130     1.2162059545516968e-01
    z[1,6,2]  R1131     1.8791253864765167e-01
    z[1,6,2]  R1132     3.1081789731979370e-01
    z[1,6,2]  R1133     -1.5064038336277008e-01
    z[1,6,2]  R1134     4.1153150796890259e-01
    z[1,6,2]  R1135     1.6199788451194763e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R1038     -1
    z[1,6,3]  R1039     1
    z[1,6,3]  R1046     4.9243035912513733e-01
    z[1,6,3]  R1047     5.0554656982421875e-01
    z[1,6,3]  R1048     5.1138144731521606e-01
    z[1,6,3]  R1049     3.3378553390502930e-01
    z[1,6,3]  R1050     -1.8854171037673950e-01
    z[1,6,3]  R1051     -1.4253887534141541e-01
    z[1,6,3]  R1052     2.4872681498527527e-01
    z[1,6,3]  R1053     2.1641846746206284e-02
    z[1,6,3]  R1054     -1.9361507892608643e-01
    z[1,6,3]  R1055     -4.4752854108810425e-01
    z[1,6,3]  R1056     -4.4447034597396851e-02
    z[1,6,3]  R1057     -5.2434122562408447e-01
    z[1,6,3]  R1058     -3.5095199942588806e-01
    z[1,6,3]  R1059     -3.1402194499969482e-01
    z[1,6,3]  R1060     -3.2981792092323303e-01
    z[1,6,3]  R1061     -2.9031160473823547e-01
    z[1,6,3]  R1062     -5.5152559280395508e-01
    z[1,6,3]  R1063     -1.7999365925788879e-01
    z[1,6,3]  R1064     -0.319568932056427
    z[1,6,3]  R1065     -0.0645049586892128
    z[1,6,3]  R1066     -6.5557742118835449e-01
    z[1,6,3]  R1067     -1.2081279419362545e-02
    z[1,6,3]  R1068     -0.0806296318769455
    z[1,6,3]  R1069     -1.9459196925163269e-01
    z[1,6,3]  R1070     -6.4039933681488037e-01
    z[1,6,3]  R1071     -4.7206792235374451e-01
    z[1,6,3]  R1072     -3.4568536281585693e-01
    z[1,6,3]  R1073     -2.2869020700454712e-01
    z[1,6,3]  R1074     -4.5102012157440186e-01
    z[1,6,3]  R1075     2.3547211661934853e-02
    z[1,6,3]  R1076     -2.1843446791172028e-01
    z[1,6,3]  R1077     3.8228464126586914e-01
    z[1,6,3]  R1078     -2.4428358674049377e-01
    z[1,6,3]  R1079     -3.6610227823257446e-01
    z[1,6,3]  R1080     -7.9962633550167084e-02
    z[1,6,3]  R1081     -4.3234610557556152e-01
    z[1,6,3]  R1082     -4.3659138679504395e-01
    z[1,6,3]  R1083     -4.0801870822906494e-01
    z[1,6,3]  R1084     -3.2905688881874084e-01
    z[1,6,3]  R1085     -4.3137919902801514e-01
    z[1,6,3]  R1086     2.4851515889167786e-01
    z[1,6,3]  R1087     4.2799273133277893e-01
    z[1,6,3]  R1088     1.8995456397533417e-01
    z[1,6,3]  R1089     0.647131085395813
    z[1,6,3]  R1090     -3.3350121229887009e-02
    z[1,6,3]  R1091     -1.3669732958078384e-02
    z[1,6,3]  R1092     8.5663646459579468e-01
    z[1,6,3]  R1093     -2.4247553944587708e-01
    z[1,6,3]  R1094     1.1043892055749893e-01
    z[1,6,3]  R1095     4.7907626628875732e-01
    z[1,6,3]  R1096     -1.8333104252815247e-01
    z[1,6,3]  R1097     -5.6412893533706665e-01
    z[1,6,3]  R1098     1.4555303752422333e-01
    z[1,6,3]  R1099     1.7127810278907418e-03
    z[1,6,3]  R1100     -2.4269069731235504e-01
    z[1,6,3]  R1101     1.1815001815557480e-01
    z[1,6,3]  R1102     2.1872974932193756e-01
    z[1,6,3]  R1103     -2.4208946526050568e-01
    z[1,6,3]  R1104     1.3070549070835114e-01
    z[1,6,3]  R1105     3.3484759926795959e-01
    z[1,6,3]  R1106     3.0880925059318542e-01
    z[1,6,3]  R1107     6.7955709993839264e-02
    z[1,6,3]  R1108     -1.2718668580055237e-01
    z[1,6,3]  R1109     3.0917921662330627e-01
    z[1,6,3]  R1110     2.5221493840217590e-01
    z[1,6,3]  R1111     -7.5860089063644409e-01
    z[1,6,3]  R1112     -0.0707196369767189
    z[1,6,3]  R1113     -4.6028646826744080e-01
    z[1,6,3]  R1114     -7.2013401985168457e-01
    z[1,6,3]  R1115     -3.5336297750473022e-01
    z[1,6,3]  R1116     1.3543894886970520e-01
    z[1,6,3]  R1117     -3.0731633305549622e-01
    z[1,6,3]  R1118     2.5043663382530212e-01
    z[1,6,3]  R1119     1.9921740889549255e-01
    z[1,6,3]  R1120     -2.3116227984428406e-01
    z[1,6,3]  R1121     -2.2955887019634247e-01
    z[1,6,3]  R1122     -1.5074518509209156e-02
    z[1,6,3]  R1123     0.347474604845047
    z[1,6,3]  R1124     2.0738035440444946e-01
    z[1,6,3]  R1125     -0.728060245513916
    z[1,6,3]  R1126     2.4625155329704285e-01
    z[1,6,3]  R1127     2.9551351070404053e-01
    z[1,6,3]  R1128     0.180172398686409
    z[1,6,3]  R1129     -6.9118700921535492e-02
    z[1,6,3]  R1130     -4.9093249440193176e-01
    z[1,6,3]  R1131     8.9788466691970825e-02
    z[1,6,3]  R1132     -0.504069983959198
    z[1,6,3]  R1133     -5.8053833246231079e-01
    z[1,6,3]  R1134     5.4022260010242462e-02
    z[1,6,3]  R1135     7.7676810324192047e-02
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R1040     -1
    z[1,6,4]  R1041     1
    z[1,6,4]  R1046     -4.7869235277175903e-01
    z[1,6,4]  R1047     -0.353411465883255
    z[1,6,4]  R1048     2.1292430162429810e-01
    z[1,6,4]  R1049     5.5049387738108635e-03
    z[1,6,4]  R1050     -4.8308354616165161e-01
    z[1,6,4]  R1051     -5.2213305234909058e-01
    z[1,6,4]  R1052     1.1937224864959717e-01
    z[1,6,4]  R1053     1.5014718472957611e-01
    z[1,6,4]  R1054     -6.3855779170989990e-01
    z[1,6,4]  R1055     -5.8134567737579346e-01
    z[1,6,4]  R1056     1.7674861848354340e-01
    z[1,6,4]  R1057     1.7360825836658478e-01
    z[1,6,4]  R1058     1.3603407144546509e-01
    z[1,6,4]  R1059     2.2222118079662323e-01
    z[1,6,4]  R1060     4.4917544722557068e-01
    z[1,6,4]  R1061     4.6200191974639893e-01
    z[1,6,4]  R1062     -1.6582775115966797e-01
    z[1,6,4]  R1063     4.5760747790336609e-01
    z[1,6,4]  R1064     -2.6043057441711426e-01
    z[1,6,4]  R1065     -1.2828649580478668e-01
    z[1,6,4]  R1066     3.2459726929664612e-01
    z[1,6,4]  R1067     1.5240977704524994e-01
    z[1,6,4]  R1068     -2.9337859153747559e-01
    z[1,6,4]  R1069     -1.7532658576965332e-01
    z[1,6,4]  R1070     -1.3813933730125427e-01
    z[1,6,4]  R1071     -2.4399299919605255e-01
    z[1,6,4]  R1072     -1.8310281634330750e-01
    z[1,6,4]  R1073     -4.3905708193778992e-01
    z[1,6,4]  R1074     -3.6279231309890747e-01
    z[1,6,4]  R1075     -1.6562348604202271e-01
    z[1,6,4]  R1076     1.3291072845458984e-01
    z[1,6,4]  R1077     -4.0647846460342407e-01
    z[1,6,4]  R1078     3.4199748188257217e-02
    z[1,6,4]  R1079     7.8203096985816956e-02
    z[1,6,4]  R1080     -1.6141681373119354e-01
    z[1,6,4]  R1081     -1.0343640297651291e-01
    z[1,6,4]  R1082     -1.0888533294200897e-01
    z[1,6,4]  R1083     -2.6009339094161987e-01
    z[1,6,4]  R1084     -6.3789568841457367e-02
    z[1,6,4]  R1085     -1.9778449833393097e-01
    z[1,6,4]  R1086     -3.6935889720916748e-01
    z[1,6,4]  R1087     -4.3102037906646729e-01
    z[1,6,4]  R1088     -0.0522281676530838
    z[1,6,4]  R1089     1.3389755785465240e-01
    z[1,6,4]  R1090     3.5002410411834717e-01
    z[1,6,4]  R1091     -3.5380309820175171e-01
    z[1,6,4]  R1092     2.3240806162357330e-01
    z[1,6,4]  R1093     1.6689166426658630e-01
    z[1,6,4]  R1094     -7.7786058187484741e-01
    z[1,6,4]  R1095     1.5104007720947266e-01
    z[1,6,4]  R1096     2.6192682981491089e-01
    z[1,6,4]  R1097     1.8555636703968048e-01
    z[1,6,4]  R1098     -1.4745970070362091e-01
    z[1,6,4]  R1099     -2.2623822093009949e-01
    z[1,6,4]  R1100     -3.6451452970504761e-01
    z[1,6,4]  R1101     -1.0220992378890514e-02
    z[1,6,4]  R1102     -4.1237783432006836e-01
    z[1,6,4]  R1103     -2.7822852134704590e-01
    z[1,6,4]  R1104     -0.0856996551156044
    z[1,6,4]  R1105     3.4416213631629944e-02
    z[1,6,4]  R1106     -1.8395955860614777e-01
    z[1,6,4]  R1107     -1.9225528836250305e-01
    z[1,6,4]  R1108     -2.4892230331897736e-01
    z[1,6,4]  R1109     -3.6046814918518066e-01
    z[1,6,4]  R1110     -2.4335388839244843e-01
    z[1,6,4]  R1111     -7.2335690259933472e-02
    z[1,6,4]  R1112     1.1693262308835983e-01
    z[1,6,4]  R1113     -3.5507228970527649e-01
    z[1,6,4]  R1114     2.4996544420719147e-01
    z[1,6,4]  R1115     -4.8424351960420609e-02
    z[1,6,4]  R1116     -1.8865896761417389e-01
    z[1,6,4]  R1117     -3.0305463075637817e-01
    z[1,6,4]  R1118     -3.8017854094505310e-01
    z[1,6,4]  R1119     -4.1649696230888367e-01
    z[1,6,4]  R1120     -3.3740437030792236e-01
    z[1,6,4]  R1121     -2.9558593034744263e-01
    z[1,6,4]  R1122     -4.2544689774513245e-01
    z[1,6,4]  R1123     -1.5303482115268707e-01
    z[1,6,4]  R1124     -1.2073575705289841e-01
    z[1,6,4]  R1125     2.4712586402893066e-01
    z[1,6,4]  R1126     -2.2771361470222473e-01
    z[1,6,4]  R1127     -1.0204493999481201e-01
    z[1,6,4]  R1128     -4.4191029667854309e-01
    z[1,6,4]  R1129     -2.8548830747604370e-01
    z[1,6,4]  R1130     -4.4406521320343018e-01
    z[1,6,4]  R1131     2.1089971065521240e-01
    z[1,6,4]  R1132     -2.5434973835945129e-01
    z[1,6,4]  R1133     2.2958418726921082e-01
    z[1,6,4]  R1134     3.7069392204284668e-01
    z[1,6,4]  R1135     6.0400164127349854e-01
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R1042     -1
    z[1,6,5]  R1043     1
    z[1,6,5]  R1046     -2.0041167736053467e-01
    z[1,6,5]  R1047     -4.3665367364883423e-01
    z[1,6,5]  R1048     -2.8782343864440918e-01
    z[1,6,5]  R1049     -6.0278022289276123e-01
    z[1,6,5]  R1050     -0.566609799861908
    z[1,6,5]  R1051     -0.28685262799263
    z[1,6,5]  R1052     1.5974249690771103e-02
    z[1,6,5]  R1053     -3.0622237920761108e-01
    z[1,6,5]  R1054     -8.5659280419349670e-02
    z[1,6,5]  R1055     -9.4244204461574554e-02
    z[1,6,5]  R1056     3.6924883723258972e-01
    z[1,6,5]  R1057     9.4708538381382823e-04
    z[1,6,5]  R1058     -0.0814613625407219
    z[1,6,5]  R1059     -3.5854384303092957e-01
    z[1,6,5]  R1060     -1.4186948537826538e-01
    z[1,6,5]  R1061     9.6284836530685425e-02
    z[1,6,5]  R1062     1.4110732078552246e-01
    z[1,6,5]  R1063     4.8242881894111633e-03
    z[1,6,5]  R1064     -0.0749167948961258
    z[1,6,5]  R1065     2.7209895849227905e-01
    z[1,6,5]  R1066     1.9273126125335693e-01
    z[1,6,5]  R1067     7.6943945884704590e-01
    z[1,6,5]  R1068     -4.8499464988708496e-02
    z[1,6,5]  R1069     -2.7498283982276917e-01
    z[1,6,5]  R1070     -3.4907805919647217e-01
    z[1,6,5]  R1071     2.7364954352378845e-01
    z[1,6,5]  R1072     -4.0097177028656006e-01
    z[1,6,5]  R1073     -1.1034757643938065e-01
    z[1,6,5]  R1074     0.32767453789711
    z[1,6,5]  R1075     -3.4630617592483759e-03
    z[1,6,5]  R1076     1.9378204643726349e-01
    z[1,6,5]  R1077     -2.3140968382358551e-01
    z[1,6,5]  R1078     2.0276030898094177e-01
    z[1,6,5]  R1079     -2.6396793127059937e-01
    z[1,6,5]  R1080     -5.3916919976472855e-02
    z[1,6,5]  R1081     1.4100360684096813e-02
    z[1,6,5]  R1082     1.1793158203363419e-01
    z[1,6,5]  R1083     -1.5098898112773895e-01
    z[1,6,5]  R1084     -3.3523935079574585e-01
    z[1,6,5]  R1085     -1.8744681775569916e-01
    z[1,6,5]  R1086     -1.3205623626708984e-01
    z[1,6,5]  R1087     2.3775672540068626e-02
    z[1,6,5]  R1088     -2.3560172319412231e-01
    z[1,6,5]  R1089     -2.4947191774845123e-01
    z[1,6,5]  R1090     -2.1468194201588631e-02
    z[1,6,5]  R1091     -3.0987852811813354e-01
    z[1,6,5]  R1092     1.9926816225051880e-01
    z[1,6,5]  R1093     2.4895383417606354e-01
    z[1,6,5]  R1094     -2.3796521127223969e-01
    z[1,6,5]  R1095     1.6448259353637695e-01
    z[1,6,5]  R1096     -8.3478963375091553e-01
    z[1,6,5]  R1097     -5.4874008893966675e-01
    z[1,6,5]  R1098     -2.7937579154968262e-01
    z[1,6,5]  R1099     1.6618889570236206e-01
    z[1,6,5]  R1100     -2.8234788775444031e-01
    z[1,6,5]  R1101     -3.3864060044288635e-01
    z[1,6,5]  R1102     -1.9196757674217224e-01
    z[1,6,5]  R1103     -2.1979844197630882e-02
    z[1,6,5]  R1104     -8.6034417152404785e-02
    z[1,6,5]  R1105     -6.9077193737030029e-02
    z[1,6,5]  R1106     -4.2867638170719147e-02
    z[1,6,5]  R1107     -0.271806925535202
    z[1,6,5]  R1108     -8.6144261062145233e-02
    z[1,6,5]  R1109     -3.9314371347427368e-01
    z[1,6,5]  R1110     1.2027243524789810e-01
    z[1,6,5]  R1111     7.5420483946800232e-02
    z[1,6,5]  R1112     1.8396285176277161e-01
    z[1,6,5]  R1113     4.9101737141609192e-01
    z[1,6,5]  R1114     -8.1900522112846375e-02
    z[1,6,5]  R1115     -1.1446280032396317e-01
    z[1,6,5]  R1116     7.4930049479007721e-02
    z[1,6,5]  R1117     -0.532384991645813
    z[1,6,5]  R1118     4.9820342659950256e-01
    z[1,6,5]  R1119     0.0839017704129219
    z[1,6,5]  R1120     -1.7509314417839050e-01
    z[1,6,5]  R1121     -2.3635946214199066e-01
    z[1,6,5]  R1122     -4.0245339274406433e-01
    z[1,6,5]  R1123     -1.5049065649509430e-01
    z[1,6,5]  R1124     -4.7530877590179443e-01
    z[1,6,5]  R1125     -1.7866681516170502e-01
    z[1,6,5]  R1126     -4.0760576725006104e-01
    z[1,6,5]  R1127     -2.7285388112068176e-01
    z[1,6,5]  R1128     -9.9871069192886353e-02
    z[1,6,5]  R1129     -2.8446984291076660e-01
    z[1,6,5]  R1130     5.5914241075515747e-01
    z[1,6,5]  R1131     2.0898316800594330e-01
    z[1,6,5]  R1132     -8.0084212124347687e-02
    z[1,6,5]  R1133     4.5964911580085754e-01
    z[1,6,5]  R1134     1.5262268483638763e-01
    z[1,6,5]  R1135     1.8325030803680420e-01
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R1044     -1
    z[1,6,6]  R1045     1
    z[1,6,6]  R1046     -1.9053514301776886e-01
    z[1,6,6]  R1047     1.1832785606384277e-01
    z[1,6,6]  R1048     4.3967801332473755e-01
    z[1,6,6]  R1049     -4.8423612117767334e-01
    z[1,6,6]  R1050     1.9352915883064270e-01
    z[1,6,6]  R1051     3.6890518665313721e-01
    z[1,6,6]  R1052     -5.7547432184219360e-01
    z[1,6,6]  R1053     3.2123643904924393e-02
    z[1,6,6]  R1054     -9.8000364378094673e-03
    z[1,6,6]  R1055     -1.5896634757518768e-01
    z[1,6,6]  R1056     -1.9087785482406616e-01
    z[1,6,6]  R1057     -1.7828333377838135e-01
    z[1,6,6]  R1058     3.5070598125457764e-02
    z[1,6,6]  R1059     -6.7103527486324310e-02
    z[1,6,6]  R1060     6.6242665052413940e-02
    z[1,6,6]  R1061     -1.4694066345691681e-01
    z[1,6,6]  R1062     1.8468730151653290e-02
    z[1,6,6]  R1063     2.0318174362182617e-01
    z[1,6,6]  R1064     -1.7295676469802856e-01
    z[1,6,6]  R1065     -1.7953509092330933e-01
    z[1,6,6]  R1066     2.5688254833221436e-01
    z[1,6,6]  R1067     4.6851357817649841e-01
    z[1,6,6]  R1068     2.4432139098644257e-01
    z[1,6,6]  R1069     4.8920312523841858e-01
    z[1,6,6]  R1070     -1.7767407000064850e-02
    z[1,6,6]  R1071     0.0679338276386261
    z[1,6,6]  R1072     -1.4336473308503628e-02
    z[1,6,6]  R1073     5.0678491592407227e-02
    z[1,6,6]  R1074     -1.5902754664421082e-01
    z[1,6,6]  R1075     2.6732046157121658e-02
    z[1,6,6]  R1076     -6.2585294246673584e-01
    z[1,6,6]  R1077     -4.8738211393356323e-02
    z[1,6,6]  R1078     -1.0014757513999939e-01
    z[1,6,6]  R1079     -1.3742519915103912e-01
    z[1,6,6]  R1080     -1.5722940862178802e-01
    z[1,6,6]  R1081     3.9180129766464233e-01
    z[1,6,6]  R1082     -1.4284999668598175e-01
    z[1,6,6]  R1083     2.2878804802894592e-01
    z[1,6,6]  R1084     -1.3638909161090851e-01
    z[1,6,6]  R1085     -5.5600155144929886e-02
    z[1,6,6]  R1086     -3.9352121949195862e-01
    z[1,6,6]  R1087     0.397322416305542
    z[1,6,6]  R1088     6.4916145801544189e-01
    z[1,6,6]  R1089     1.3663363456726074e-01
    z[1,6,6]  R1090     1.1498459428548813e-01
    z[1,6,6]  R1091     2.0553120970726013e-01
    z[1,6,6]  R1092     2.8817737102508545e-01
    z[1,6,6]  R1093     -3.0668967962265015e-01
    z[1,6,6]  R1094     -0.300184428691864
    z[1,6,6]  R1095     -5.5269223451614380e-01
    z[1,6,6]  R1096     5.0016533583402634e-02
    z[1,6,6]  R1097     -4.7827857732772827e-01
    z[1,6,6]  R1098     -2.7828231453895569e-02
    z[1,6,6]  R1099     1.3620495796203613e-02
    z[1,6,6]  R1100     5.1132321357727051e-02
    z[1,6,6]  R1101     3.1818398833274841e-01
    z[1,6,6]  R1102     -8.1356592476367950e-02
    z[1,6,6]  R1103     2.5460091233253479e-01
    z[1,6,6]  R1104     -1.0346055030822754e-02
    z[1,6,6]  R1105     -2.9780656099319458e-01
    z[1,6,6]  R1106     2.6816916465759277e-01
    z[1,6,6]  R1107     -2.3238374292850494e-01
    z[1,6,6]  R1108     -1.3719917833805084e-01
    z[1,6,6]  R1109     1.9939646124839783e-01
    z[1,6,6]  R1110     -2.9235085844993591e-01
    z[1,6,6]  R1111     4.3229696154594421e-01
    z[1,6,6]  R1112     1.7052348703145981e-02
    z[1,6,6]  R1113     -3.6040824651718140e-01
    z[1,6,6]  R1114     5.1182365417480469e-01
    z[1,6,6]  R1115     0.343861848115921
    z[1,6,6]  R1116     -0.0243021659553051
    z[1,6,6]  R1117     -1.8595525622367859e-01
    z[1,6,6]  R1118     -4.3452523648738861e-02
    z[1,6,6]  R1119     -2.2632901370525360e-01
    z[1,6,6]  R1120     1.7174807190895081e-01
    z[1,6,6]  R1121     0.0263583455234766
    z[1,6,6]  R1122     2.5093618035316467e-01
    z[1,6,6]  R1123     -2.2811074554920197e-01
    z[1,6,6]  R1124     -7.6790824532508850e-02
    z[1,6,6]  R1125     4.0540233254432678e-01
    z[1,6,6]  R1126     2.2860527038574219e-01
    z[1,6,6]  R1127     -1.0897362232208252e-01
    z[1,6,6]  R1128     -7.8589171171188354e-02
    z[1,6,6]  R1129     -1.7819654941558838e-01
    z[1,6,6]  R1130     -1.2982444465160370e-01
    z[1,6,6]  R1131     1.3908928632736206e-01
    z[1,6,6]  R1132     2.1789376437664032e-01
    z[1,6,6]  R1133     1.9258503615856171e-01
    z[1,6,6]  R1134     1.3709321618080139e-01
    z[1,6,6]  R1135     -1.3313873112201691e-01
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R1136     -1
    z[6,1,0]  R1137     1
    z[6,1,0]  R1150     2.0031196996569633e-02
    z[6,1,0]  R1151     4.7062397003173828e-01
    z[6,1,0]  R1152     -2.0097967982292175e-01
    z[6,1,0]  R1153     5.3255504369735718e-01
    z[6,1,0]  R1154     -5.3218755871057510e-02
    z[6,1,0]  R1155     -5.1938509941101074e-01
    z[6,1,0]  R1156     7.6573394238948822e-02
    z[6,1,0]  R1157     -6.3433700799942017e-01
    z[6,1,0]  R1158     2.9662674292922020e-02
    z[6,1,0]  R1159     5.4677534103393555e-01
    z[6,1,0]  R1160     1.3562743365764618e-01
    z[6,1,0]  R1161     1.5572011470794678e-01
    z[6,1,0]  R1162     1.1420238018035889e-01
    z[6,1,0]  R1163     2.3889848962426186e-02
    z[6,1,0]  R1164     -1.5095965564250946e-01
    z[6,1,0]  R1165     -3.1263357400894165e-01
    z[6,1,0]  R1166     -2.6962655782699585e-01
    z[6,1,0]  R1167     -2.3602253198623657e-01
    z[6,1,0]  R1168     -2.9074054956436157e-01
    z[6,1,0]  R1169     -3.3436134457588196e-01
    z[6,1,0]  R1170     -1.2169932574033737e-01
    z[6,1,0]  R1171     1.3749545812606812e-01
    z[6,1,0]  R1172     -2.2975397109985352e-01
    z[6,1,0]  R1173     -3.8394263386726379e-01
    z[6,1,0]  R1174     -2.8801003098487854e-01
    z[6,1,0]  R1175     -2.5030487775802612e-01
    z[6,1,0]  R1176     5.4529821872711182e-01
    z[6,1,0]  R1177     3.7663927674293518e-01
    z[6,1,0]  R1178     -2.1984383463859558e-01
    z[6,1,0]  R1179     -6.0424816608428955e-01
    z[6,1,0]  R1180     3.0019545927643776e-02
    z[6,1,0]  R1181     -1.9691903889179230e-01
    z[6,1,0]  R1182     7.2666600346565247e-02
    z[6,1,0]  R1183     -1.9034427404403687e-01
    z[6,1,0]  R1184     1.2171491980552673e-01
    z[6,1,0]  R1185     -0.00383838452398777
    z[6,1,0]  R1186     -0.226633220911026
    z[6,1,0]  R1187     -4.5925104618072510e-01
    z[6,1,0]  R1188     -4.1722607612609863e-01
    z[6,1,0]  R1189     -2.6629993319511414e-01
    z[6,1,0]  R1190     -2.9132384061813354e-01
    z[6,1,0]  R1191     -3.7018135190010071e-01
    z[6,1,0]  R1192     1.9356849789619446e-01
    z[6,1,0]  R1193     -3.1235665082931519e-01
    z[6,1,0]  R1194     3.4809085726737976e-01
    z[6,1,0]  R1195     5.3691053390502930e-01
    z[6,1,0]  R1196     -4.8993730545043945e-01
    z[6,1,0]  R1197     5.6050747632980347e-01
    z[6,1,0]  R1198     -8.0752231180667877e-02
    z[6,1,0]  R1199     -4.3593738228082657e-02
    z[6,1,0]  R1200     4.8762276768684387e-01
    z[6,1,0]  R1201     5.3526413440704346e-01
    z[6,1,0]  R1202     4.7786450386047363e-01
    z[6,1,0]  R1203     4.3266192078590393e-01
    z[6,1,0]  R1204     4.8137810826301575e-01
    z[6,1,0]  R1205     4.4484078884124756e-01
    z[6,1,0]  R1206     2.2758446633815765e-01
    z[6,1,0]  R1207     -3.2156670093536377e-01
    z[6,1,0]  R1208     -6.7632973194122314e-02
    z[6,1,0]  R1209     -1.2362013012170792e-01
    z[6,1,0]  R1210     6.5048910677433014e-02
    z[6,1,0]  R1211     -7.9278725385665894e-01
    z[6,1,0]  R1212     -8.3439606428146362e-01
    z[6,1,0]  R1213     -8.2489007711410522e-01
    z[6,1,0]  R1214     -6.8961602449417114e-01
    z[6,1,0]  R1215     -7.8425419330596924e-01
    z[6,1,0]  R1216     -6.8020766973495483e-01
    z[6,1,0]  R1217     -7.2894531488418579e-01
    z[6,1,0]  R1218     -8.1985729932785034e-01
    z[6,1,0]  R1219     -0.830944299697876
    z[6,1,0]  R1220     1.1360311508178711e-01
    z[6,1,0]  R1221     1.3797410763800144e-02
    z[6,1,0]  R1222     -4.2373758554458618e-01
    z[6,1,0]  R1223     -3.0192825198173523e-01
    z[6,1,0]  R1224     -6.3382869958877563e-01
    z[6,1,0]  R1225     -6.9172859191894531e-01
    z[6,1,0]  R1226     -7.5065809488296509e-01
    z[6,1,0]  R1227     -8.2509487867355347e-01
    z[6,1,0]  R1228     -0.679706335067749
    z[6,1,0]  R1229     -9.4545549154281616e-01
    z[6,1,0]  R1230     0.0442180261015892
    z[6,1,0]  R1231     -2.0517329871654510e-01
    z[6,1,0]  R1232     -9.0681433677673340e-01
    z[6,1,0]  R1233     -7.8480494022369385e-01
    z[6,1,0]  R1234     -8.7693107128143311e-01
    z[6,1,0]  R1235     -7.3673528432846069e-01
    z[6,1,0]  R1236     -6.9118893146514893e-01
    z[6,1,0]  R1237     -7.5684589147567749e-01
    z[6,1,0]  R1238     -4.3756476044654846e-01
    z[6,1,0]  R1239     -7.0736819505691528e-01
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R1138     -1
    z[6,1,1]  R1139     1
    z[6,1,1]  R1150     -7.8190410137176514e-01
    z[6,1,1]  R1151     -3.6997714638710022e-01
    z[6,1,1]  R1152     -6.0399180650711060e-01
    z[6,1,1]  R1153     -4.4579467177391052e-01
    z[6,1,1]  R1154     -8.2918137311935425e-01
    z[6,1,1]  R1155     -6.4737731218338013e-01
    z[6,1,1]  R1156     -2.8673955798149109e-01
    z[6,1,1]  R1157     -5.9463238716125488e-01
    z[6,1,1]  R1158     -4.4625002145767212e-01
    z[6,1,1]  R1159     -3.0965870618820190e-01
    z[6,1,1]  R1160     4.0525174140930176e-01
    z[6,1,1]  R1161     2.8946825861930847e-01
    z[6,1,1]  R1162     9.2991006374359131e-01
    z[6,1,1]  R1163     8.6411511898040771e-01
    z[6,1,1]  R1164     8.2175713777542114e-01
    z[6,1,1]  R1165     6.9736850261688232e-01
    z[6,1,1]  R1166     0.808444619178772
    z[6,1,1]  R1167     7.2943145036697388e-01
    z[6,1,1]  R1168     5.6239664554595947e-01
    z[6,1,1]  R1169     6.5161406993865967e-01
    z[6,1,1]  R1170     8.4629094600677490e-01
    z[6,1,1]  R1171     8.7107741832733154e-01
    z[6,1,1]  R1172     9.1347074508666992e-01
    z[6,1,1]  R1173     6.5538221597671509e-01
    z[6,1,1]  R1174     8.3171874284744263e-01
    z[6,1,1]  R1175     3.9090868830680847e-01
    z[6,1,1]  R1176     7.8255093097686768e-01
    z[6,1,1]  R1177     3.5327199101448059e-01
    z[6,1,1]  R1178     3.1925094127655029e-01
    z[6,1,1]  R1179     5.1732963323593140e-01
    z[6,1,1]  R1180     8.7808293104171753e-01
    z[6,1,1]  R1181     6.3551861047744751e-01
    z[6,1,1]  R1182     5.8599531650543213e-01
    z[6,1,1]  R1183     8.0284309387207031e-01
    z[6,1,1]  R1184     7.7548879384994507e-01
    z[6,1,1]  R1185     7.5157040357589722e-01
    z[6,1,1]  R1186     7.3652219772338867e-01
    z[6,1,1]  R1187     7.1352082490921021e-01
    z[6,1,1]  R1188     7.2306710481643677e-01
    z[6,1,1]  R1189     3.7456589937210083e-01
    z[6,1,1]  R1190     6.7980217933654785e-01
    z[6,1,1]  R1191     7.6989412307739258e-01
    z[6,1,1]  R1192     0.847685694694519
    z[6,1,1]  R1193     0.807413637638092
    z[6,1,1]  R1194     3.1038349866867065e-01
    z[6,1,1]  R1195     7.4890291690826416e-01
    z[6,1,1]  R1196     5.3914952278137207e-01
    z[6,1,1]  R1197     1.5823675692081451e-01
    z[6,1,1]  R1198     8.0106192827224731e-01
    z[6,1,1]  R1199     7.4141615629196167e-01
    z[6,1,1]  R1200     3.1182876229286194e-01
    z[6,1,1]  R1201     3.1679326295852661e-01
    z[6,1,1]  R1202     2.8544783592224121e-01
    z[6,1,1]  R1203     3.0021238327026367e-01
    z[6,1,1]  R1204     3.7033927440643311e-01
    z[6,1,1]  R1205     2.9730680584907532e-01
    z[6,1,1]  R1206     2.9784691333770752e-01
    z[6,1,1]  R1207     -0.76842200756073
    z[6,1,1]  R1208     -7.2994166612625122e-01
    z[6,1,1]  R1209     -6.3500648736953735e-01
    z[6,1,1]  R1210     5.7323312759399414e-01
    z[6,1,1]  R1211     -2.5927681475877762e-02
    z[6,1,1]  R1212     7.2741672396659851e-02
    z[6,1,1]  R1213     -1.9623391330242157e-01
    z[6,1,1]  R1214     -2.3165687918663025e-02
    z[6,1,1]  R1215     6.2084991484880447e-02
    z[6,1,1]  R1216     -1.1389282345771790e-01
    z[6,1,1]  R1217     1.4568357169628143e-01
    z[6,1,1]  R1218     -0.0789308175444603
    z[6,1,1]  R1219     -3.2679599523544312e-01
    z[6,1,1]  R1220     5.8238863945007324e-01
    z[6,1,1]  R1221     3.8293415307998657e-01
    z[6,1,1]  R1222     -8.1575781106948853e-01
    z[6,1,1]  R1223     -7.2446751594543457e-01
    z[6,1,1]  R1224     -2.1643690764904022e-01
    z[6,1,1]  R1225     -3.0542570352554321e-01
    z[6,1,1]  R1226     -2.4331867694854736e-01
    z[6,1,1]  R1227     -2.3857049643993378e-01
    z[6,1,1]  R1228     -2.2109535336494446e-01
    z[6,1,1]  R1229     -2.5237387418746948e-01
    z[6,1,1]  R1230     5.4887527227401733e-01
    z[6,1,1]  R1231     -0.756986141204834
    z[6,1,1]  R1232     -2.5298237800598145e-01
    z[6,1,1]  R1233     -0.319732129573822
    z[6,1,1]  R1234     -4.1124969720840454e-01
    z[6,1,1]  R1235     -3.0991527438163757e-01
    z[6,1,1]  R1236     -4.4507080316543579e-01
    z[6,1,1]  R1237     -2.6714438199996948e-01
    z[6,1,1]  R1238     -7.5146359205245972e-01
    z[6,1,1]  R1239     -3.3937805891036987e-01
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R1140     -1
    z[6,1,2]  R1141     1
    z[6,1,2]  R1150     -1.3319614529609680e-01
    z[6,1,2]  R1151     -3.3799886703491211e-01
    z[6,1,2]  R1152     -2.8119698166847229e-01
    z[6,1,2]  R1153     -6.3282884657382965e-03
    z[6,1,2]  R1154     -4.1510784626007080e-01
    z[6,1,2]  R1155     -2.1796886622905731e-01
    z[6,1,2]  R1156     -3.6379560828208923e-02
    z[6,1,2]  R1157     3.6675009876489639e-02
    z[6,1,2]  R1158     -1.8968142569065094e-01
    z[6,1,2]  R1159     -1.4247059822082520e-01
    z[6,1,2]  R1160     -1.2563848495483398e-01
    z[6,1,2]  R1161     -9.7060143947601318e-02
    z[6,1,2]  R1162     -2.1673109382390976e-02
    z[6,1,2]  R1163     -4.1682547330856323e-01
    z[6,1,2]  R1164     -1.6679960489273071e-01
    z[6,1,2]  R1165     -0.431225061416626
    z[6,1,2]  R1166     0.111131452023983
    z[6,1,2]  R1167     -4.5923840999603271e-01
    z[6,1,2]  R1168     -7.5315505266189575e-01
    z[6,1,2]  R1169     -5.0678777694702148e-01
    z[6,1,2]  R1170     -2.5695204734802246e-01
    z[6,1,2]  R1171     -2.2990810871124268e-01
    z[6,1,2]  R1172     -9.1658405959606171e-02
    z[6,1,2]  R1173     5.6675948202610016e-02
    z[6,1,2]  R1174     -5.0259608775377274e-02
    z[6,1,2]  R1175     1.0611893236637115e-01
    z[6,1,2]  R1176     1.9353662431240082e-01
    z[6,1,2]  R1177     1.5623576939105988e-01
    z[6,1,2]  R1178     7.5560994446277618e-04
    z[6,1,2]  R1179     3.2969883084297180e-01
    z[6,1,2]  R1180     -4.0979039669036865e-01
    z[6,1,2]  R1181     2.3030509054660797e-01
    z[6,1,2]  R1182     4.4043174386024475e-01
    z[6,1,2]  R1183     -2.1861056983470917e-01
    z[6,1,2]  R1184     -3.9543649554252625e-01
    z[6,1,2]  R1185     -4.8836305737495422e-01
    z[6,1,2]  R1186     -1.5879217535257339e-03
    z[6,1,2]  R1187     -2.4725767970085144e-01
    z[6,1,2]  R1188     -1.1703561991453171e-01
    z[6,1,2]  R1189     0.0369969867169857
    z[6,1,2]  R1190     -3.4943285584449768e-01
    z[6,1,2]  R1191     -2.9353508353233337e-01
    z[6,1,2]  R1192     -7.9275742173194885e-03
    z[6,1,2]  R1193     -2.2706474363803864e-01
    z[6,1,2]  R1194     1.2162059545516968e-01
    z[6,1,2]  R1195     1.8791253864765167e-01
    z[6,1,2]  R1196     3.1081789731979370e-01
    z[6,1,2]  R1197     -1.5064038336277008e-01
    z[6,1,2]  R1198     4.1153150796890259e-01
    z[6,1,2]  R1199     1.6199788451194763e-01
    z[6,1,2]  R1200     -3.4188345074653625e-01
    z[6,1,2]  R1201     1.6730089485645294e-01
    z[6,1,2]  R1202     -3.2735043764114380e-01
    z[6,1,2]  R1203     -1.1577780544757843e-01
    z[6,1,2]  R1204     0.0608777217566967
    z[6,1,2]  R1205     -4.4989970326423645e-01
    z[6,1,2]  R1206     -6.7227369546890259e-01
    z[6,1,2]  R1207     -4.3394207954406738e-01
    z[6,1,2]  R1208     9.9671795964241028e-02
    z[6,1,2]  R1209     -9.5330648124217987e-02
    z[6,1,2]  R1210     6.7910069227218628e-01
    z[6,1,2]  R1211     1.8427358567714691e-01
    z[6,1,2]  R1212     3.8594490289688110e-01
    z[6,1,2]  R1213     -1.6113594756461680e-04
    z[6,1,2]  R1214     4.3455675244331360e-01
    z[6,1,2]  R1215     2.2913278639316559e-01
    z[6,1,2]  R1216     4.1522794961929321e-01
    z[6,1,2]  R1217     4.0534734725952148e-01
    z[6,1,2]  R1218     3.4077703952789307e-01
    z[6,1,2]  R1219     2.7540290355682373e-01
    z[6,1,2]  R1220     -0.0981765165925026
    z[6,1,2]  R1221     -1.3510827720165253e-01
    z[6,1,2]  R1222     1.9192628562450409e-02
    z[6,1,2]  R1223     0.0211052056401968
    z[6,1,2]  R1224     -0.00716095557436347
    z[6,1,2]  R1225     -2.5757923722267151e-01
    z[6,1,2]  R1226     2.5159388780593872e-01
    z[6,1,2]  R1227     4.9874968826770782e-02
    z[6,1,2]  R1228     1.4634981751441956e-01
    z[6,1,2]  R1229     1.1708619445562363e-01
    z[6,1,2]  R1230     4.4962030649185181e-01
    z[6,1,2]  R1231     -1.3260406255722046e-01
    z[6,1,2]  R1232     -4.1260927915573120e-02
    z[6,1,2]  R1233     -2.3052366077899933e-01
    z[6,1,2]  R1234     -4.2285788804292679e-02
    z[6,1,2]  R1235     9.9219158291816711e-02
    z[6,1,2]  R1236     2.9561412334442139e-01
    z[6,1,2]  R1237     2.1575149893760681e-01
    z[6,1,2]  R1238     2.2460678592324257e-02
    z[6,1,2]  R1239     -3.4787702560424805e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R1142     -1
    z[6,1,3]  R1143     1
    z[6,1,3]  R1150     2.4851515889167786e-01
    z[6,1,3]  R1151     4.2799273133277893e-01
    z[6,1,3]  R1152     1.8995456397533417e-01
    z[6,1,3]  R1153     0.647131085395813
    z[6,1,3]  R1154     -3.3350121229887009e-02
    z[6,1,3]  R1155     -1.3669732958078384e-02
    z[6,1,3]  R1156     8.5663646459579468e-01
    z[6,1,3]  R1157     -2.4247553944587708e-01
    z[6,1,3]  R1158     1.1043892055749893e-01
    z[6,1,3]  R1159     4.7907626628875732e-01
    z[6,1,3]  R1160     -1.8333104252815247e-01
    z[6,1,3]  R1161     -5.6412893533706665e-01
    z[6,1,3]  R1162     1.4555303752422333e-01
    z[6,1,3]  R1163     1.7127810278907418e-03
    z[6,1,3]  R1164     -2.4269069731235504e-01
    z[6,1,3]  R1165     1.1815001815557480e-01
    z[6,1,3]  R1166     2.1872974932193756e-01
    z[6,1,3]  R1167     -2.4208946526050568e-01
    z[6,1,3]  R1168     1.3070549070835114e-01
    z[6,1,3]  R1169     3.3484759926795959e-01
    z[6,1,3]  R1170     3.0880925059318542e-01
    z[6,1,3]  R1171     6.7955709993839264e-02
    z[6,1,3]  R1172     -1.2718668580055237e-01
    z[6,1,3]  R1173     3.0917921662330627e-01
    z[6,1,3]  R1174     2.5221493840217590e-01
    z[6,1,3]  R1175     -7.5860089063644409e-01
    z[6,1,3]  R1176     -0.0707196369767189
    z[6,1,3]  R1177     -4.6028646826744080e-01
    z[6,1,3]  R1178     -7.2013401985168457e-01
    z[6,1,3]  R1179     -3.5336297750473022e-01
    z[6,1,3]  R1180     1.3543894886970520e-01
    z[6,1,3]  R1181     -3.0731633305549622e-01
    z[6,1,3]  R1182     2.5043663382530212e-01
    z[6,1,3]  R1183     1.9921740889549255e-01
    z[6,1,3]  R1184     -2.3116227984428406e-01
    z[6,1,3]  R1185     -2.2955887019634247e-01
    z[6,1,3]  R1186     -1.5074518509209156e-02
    z[6,1,3]  R1187     0.347474604845047
    z[6,1,3]  R1188     2.0738035440444946e-01
    z[6,1,3]  R1189     -0.728060245513916
    z[6,1,3]  R1190     2.4625155329704285e-01
    z[6,1,3]  R1191     2.9551351070404053e-01
    z[6,1,3]  R1192     0.180172398686409
    z[6,1,3]  R1193     -6.9118700921535492e-02
    z[6,1,3]  R1194     -4.9093249440193176e-01
    z[6,1,3]  R1195     8.9788466691970825e-02
    z[6,1,3]  R1196     -0.504069983959198
    z[6,1,3]  R1197     -5.8053833246231079e-01
    z[6,1,3]  R1198     5.4022260010242462e-02
    z[6,1,3]  R1199     7.7676810324192047e-02
    z[6,1,3]  R1200     4.9243035912513733e-01
    z[6,1,3]  R1201     5.0554656982421875e-01
    z[6,1,3]  R1202     5.1138144731521606e-01
    z[6,1,3]  R1203     3.3378553390502930e-01
    z[6,1,3]  R1204     -1.8854171037673950e-01
    z[6,1,3]  R1205     -1.4253887534141541e-01
    z[6,1,3]  R1206     2.4872681498527527e-01
    z[6,1,3]  R1207     2.1641846746206284e-02
    z[6,1,3]  R1208     -1.9361507892608643e-01
    z[6,1,3]  R1209     -4.4752854108810425e-01
    z[6,1,3]  R1210     -4.4447034597396851e-02
    z[6,1,3]  R1211     -5.2434122562408447e-01
    z[6,1,3]  R1212     -3.5095199942588806e-01
    z[6,1,3]  R1213     -3.1402194499969482e-01
    z[6,1,3]  R1214     -3.2981792092323303e-01
    z[6,1,3]  R1215     -2.9031160473823547e-01
    z[6,1,3]  R1216     -5.5152559280395508e-01
    z[6,1,3]  R1217     -1.7999365925788879e-01
    z[6,1,3]  R1218     -0.319568932056427
    z[6,1,3]  R1219     -0.0645049586892128
    z[6,1,3]  R1220     -6.5557742118835449e-01
    z[6,1,3]  R1221     -1.2081279419362545e-02
    z[6,1,3]  R1222     -0.0806296318769455
    z[6,1,3]  R1223     -1.9459196925163269e-01
    z[6,1,3]  R1224     -6.4039933681488037e-01
    z[6,1,3]  R1225     -4.7206792235374451e-01
    z[6,1,3]  R1226     -3.4568536281585693e-01
    z[6,1,3]  R1227     -2.2869020700454712e-01
    z[6,1,3]  R1228     -4.5102012157440186e-01
    z[6,1,3]  R1229     2.3547211661934853e-02
    z[6,1,3]  R1230     -2.1843446791172028e-01
    z[6,1,3]  R1231     3.8228464126586914e-01
    z[6,1,3]  R1232     -2.4428358674049377e-01
    z[6,1,3]  R1233     -3.6610227823257446e-01
    z[6,1,3]  R1234     -7.9962633550167084e-02
    z[6,1,3]  R1235     -4.3234610557556152e-01
    z[6,1,3]  R1236     -4.3659138679504395e-01
    z[6,1,3]  R1237     -4.0801870822906494e-01
    z[6,1,3]  R1238     -3.2905688881874084e-01
    z[6,1,3]  R1239     -4.3137919902801514e-01
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R1144     -1
    z[6,1,4]  R1145     1
    z[6,1,4]  R1150     -3.6935889720916748e-01
    z[6,1,4]  R1151     -4.3102037906646729e-01
    z[6,1,4]  R1152     -0.0522281676530838
    z[6,1,4]  R1153     1.3389755785465240e-01
    z[6,1,4]  R1154     3.5002410411834717e-01
    z[6,1,4]  R1155     -3.5380309820175171e-01
    z[6,1,4]  R1156     2.3240806162357330e-01
    z[6,1,4]  R1157     1.6689166426658630e-01
    z[6,1,4]  R1158     -7.7786058187484741e-01
    z[6,1,4]  R1159     1.5104007720947266e-01
    z[6,1,4]  R1160     2.6192682981491089e-01
    z[6,1,4]  R1161     1.8555636703968048e-01
    z[6,1,4]  R1162     -1.4745970070362091e-01
    z[6,1,4]  R1163     -2.2623822093009949e-01
    z[6,1,4]  R1164     -3.6451452970504761e-01
    z[6,1,4]  R1165     -1.0220992378890514e-02
    z[6,1,4]  R1166     -4.1237783432006836e-01
    z[6,1,4]  R1167     -2.7822852134704590e-01
    z[6,1,4]  R1168     -0.0856996551156044
    z[6,1,4]  R1169     3.4416213631629944e-02
    z[6,1,4]  R1170     -1.8395955860614777e-01
    z[6,1,4]  R1171     -1.9225528836250305e-01
    z[6,1,4]  R1172     -2.4892230331897736e-01
    z[6,1,4]  R1173     -3.6046814918518066e-01
    z[6,1,4]  R1174     -2.4335388839244843e-01
    z[6,1,4]  R1175     -7.2335690259933472e-02
    z[6,1,4]  R1176     1.1693262308835983e-01
    z[6,1,4]  R1177     -3.5507228970527649e-01
    z[6,1,4]  R1178     2.4996544420719147e-01
    z[6,1,4]  R1179     -4.8424351960420609e-02
    z[6,1,4]  R1180     -1.8865896761417389e-01
    z[6,1,4]  R1181     -3.0305463075637817e-01
    z[6,1,4]  R1182     -3.8017854094505310e-01
    z[6,1,4]  R1183     -4.1649696230888367e-01
    z[6,1,4]  R1184     -3.3740437030792236e-01
    z[6,1,4]  R1185     -2.9558593034744263e-01
    z[6,1,4]  R1186     -4.2544689774513245e-01
    z[6,1,4]  R1187     -1.5303482115268707e-01
    z[6,1,4]  R1188     -1.2073575705289841e-01
    z[6,1,4]  R1189     2.4712586402893066e-01
    z[6,1,4]  R1190     -2.2771361470222473e-01
    z[6,1,4]  R1191     -1.0204493999481201e-01
    z[6,1,4]  R1192     -4.4191029667854309e-01
    z[6,1,4]  R1193     -2.8548830747604370e-01
    z[6,1,4]  R1194     -4.4406521320343018e-01
    z[6,1,4]  R1195     2.1089971065521240e-01
    z[6,1,4]  R1196     -2.5434973835945129e-01
    z[6,1,4]  R1197     2.2958418726921082e-01
    z[6,1,4]  R1198     3.7069392204284668e-01
    z[6,1,4]  R1199     6.0400164127349854e-01
    z[6,1,4]  R1200     -4.7869235277175903e-01
    z[6,1,4]  R1201     -0.353411465883255
    z[6,1,4]  R1202     2.1292430162429810e-01
    z[6,1,4]  R1203     5.5049387738108635e-03
    z[6,1,4]  R1204     -4.8308354616165161e-01
    z[6,1,4]  R1205     -5.2213305234909058e-01
    z[6,1,4]  R1206     1.1937224864959717e-01
    z[6,1,4]  R1207     1.5014718472957611e-01
    z[6,1,4]  R1208     -6.3855779170989990e-01
    z[6,1,4]  R1209     -5.8134567737579346e-01
    z[6,1,4]  R1210     1.7674861848354340e-01
    z[6,1,4]  R1211     1.7360825836658478e-01
    z[6,1,4]  R1212     1.3603407144546509e-01
    z[6,1,4]  R1213     2.2222118079662323e-01
    z[6,1,4]  R1214     4.4917544722557068e-01
    z[6,1,4]  R1215     4.6200191974639893e-01
    z[6,1,4]  R1216     -1.6582775115966797e-01
    z[6,1,4]  R1217     4.5760747790336609e-01
    z[6,1,4]  R1218     -2.6043057441711426e-01
    z[6,1,4]  R1219     -1.2828649580478668e-01
    z[6,1,4]  R1220     3.2459726929664612e-01
    z[6,1,4]  R1221     1.5240977704524994e-01
    z[6,1,4]  R1222     -2.9337859153747559e-01
    z[6,1,4]  R1223     -1.7532658576965332e-01
    z[6,1,4]  R1224     -1.3813933730125427e-01
    z[6,1,4]  R1225     -2.4399299919605255e-01
    z[6,1,4]  R1226     -1.8310281634330750e-01
    z[6,1,4]  R1227     -4.3905708193778992e-01
    z[6,1,4]  R1228     -3.6279231309890747e-01
    z[6,1,4]  R1229     -1.6562348604202271e-01
    z[6,1,4]  R1230     1.3291072845458984e-01
    z[6,1,4]  R1231     -4.0647846460342407e-01
    z[6,1,4]  R1232     3.4199748188257217e-02
    z[6,1,4]  R1233     7.8203096985816956e-02
    z[6,1,4]  R1234     -1.6141681373119354e-01
    z[6,1,4]  R1235     -1.0343640297651291e-01
    z[6,1,4]  R1236     -1.0888533294200897e-01
    z[6,1,4]  R1237     -2.6009339094161987e-01
    z[6,1,4]  R1238     -6.3789568841457367e-02
    z[6,1,4]  R1239     -1.9778449833393097e-01
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R1146     -1
    z[6,1,5]  R1147     1
    z[6,1,5]  R1150     -1.3205623626708984e-01
    z[6,1,5]  R1151     2.3775672540068626e-02
    z[6,1,5]  R1152     -2.3560172319412231e-01
    z[6,1,5]  R1153     -2.4947191774845123e-01
    z[6,1,5]  R1154     -2.1468194201588631e-02
    z[6,1,5]  R1155     -3.0987852811813354e-01
    z[6,1,5]  R1156     1.9926816225051880e-01
    z[6,1,5]  R1157     2.4895383417606354e-01
    z[6,1,5]  R1158     -2.3796521127223969e-01
    z[6,1,5]  R1159     1.6448259353637695e-01
    z[6,1,5]  R1160     -8.3478963375091553e-01
    z[6,1,5]  R1161     -5.4874008893966675e-01
    z[6,1,5]  R1162     -2.7937579154968262e-01
    z[6,1,5]  R1163     1.6618889570236206e-01
    z[6,1,5]  R1164     -2.8234788775444031e-01
    z[6,1,5]  R1165     -3.3864060044288635e-01
    z[6,1,5]  R1166     -1.9196757674217224e-01
    z[6,1,5]  R1167     -2.1979844197630882e-02
    z[6,1,5]  R1168     -8.6034417152404785e-02
    z[6,1,5]  R1169     -6.9077193737030029e-02
    z[6,1,5]  R1170     -4.2867638170719147e-02
    z[6,1,5]  R1171     -0.271806925535202
    z[6,1,5]  R1172     -8.6144261062145233e-02
    z[6,1,5]  R1173     -3.9314371347427368e-01
    z[6,1,5]  R1174     1.2027243524789810e-01
    z[6,1,5]  R1175     7.5420483946800232e-02
    z[6,1,5]  R1176     1.8396285176277161e-01
    z[6,1,5]  R1177     4.9101737141609192e-01
    z[6,1,5]  R1178     -8.1900522112846375e-02
    z[6,1,5]  R1179     -1.1446280032396317e-01
    z[6,1,5]  R1180     7.4930049479007721e-02
    z[6,1,5]  R1181     -0.532384991645813
    z[6,1,5]  R1182     4.9820342659950256e-01
    z[6,1,5]  R1183     0.0839017704129219
    z[6,1,5]  R1184     -1.7509314417839050e-01
    z[6,1,5]  R1185     -2.3635946214199066e-01
    z[6,1,5]  R1186     -4.0245339274406433e-01
    z[6,1,5]  R1187     -1.5049065649509430e-01
    z[6,1,5]  R1188     -4.7530877590179443e-01
    z[6,1,5]  R1189     -1.7866681516170502e-01
    z[6,1,5]  R1190     -4.0760576725006104e-01
    z[6,1,5]  R1191     -2.7285388112068176e-01
    z[6,1,5]  R1192     -9.9871069192886353e-02
    z[6,1,5]  R1193     -2.8446984291076660e-01
    z[6,1,5]  R1194     5.5914241075515747e-01
    z[6,1,5]  R1195     2.0898316800594330e-01
    z[6,1,5]  R1196     -8.0084212124347687e-02
    z[6,1,5]  R1197     4.5964911580085754e-01
    z[6,1,5]  R1198     1.5262268483638763e-01
    z[6,1,5]  R1199     1.8325030803680420e-01
    z[6,1,5]  R1200     -2.0041167736053467e-01
    z[6,1,5]  R1201     -4.3665367364883423e-01
    z[6,1,5]  R1202     -2.8782343864440918e-01
    z[6,1,5]  R1203     -6.0278022289276123e-01
    z[6,1,5]  R1204     -0.566609799861908
    z[6,1,5]  R1205     -0.28685262799263
    z[6,1,5]  R1206     1.5974249690771103e-02
    z[6,1,5]  R1207     -3.0622237920761108e-01
    z[6,1,5]  R1208     -8.5659280419349670e-02
    z[6,1,5]  R1209     -9.4244204461574554e-02
    z[6,1,5]  R1210     3.6924883723258972e-01
    z[6,1,5]  R1211     9.4708538381382823e-04
    z[6,1,5]  R1212     -0.0814613625407219
    z[6,1,5]  R1213     -3.5854384303092957e-01
    z[6,1,5]  R1214     -1.4186948537826538e-01
    z[6,1,5]  R1215     9.6284836530685425e-02
    z[6,1,5]  R1216     1.4110732078552246e-01
    z[6,1,5]  R1217     4.8242881894111633e-03
    z[6,1,5]  R1218     -0.0749167948961258
    z[6,1,5]  R1219     2.7209895849227905e-01
    z[6,1,5]  R1220     1.9273126125335693e-01
    z[6,1,5]  R1221     7.6943945884704590e-01
    z[6,1,5]  R1222     -4.8499464988708496e-02
    z[6,1,5]  R1223     -2.7498283982276917e-01
    z[6,1,5]  R1224     -3.4907805919647217e-01
    z[6,1,5]  R1225     2.7364954352378845e-01
    z[6,1,5]  R1226     -4.0097177028656006e-01
    z[6,1,5]  R1227     -1.1034757643938065e-01
    z[6,1,5]  R1228     0.32767453789711
    z[6,1,5]  R1229     -3.4630617592483759e-03
    z[6,1,5]  R1230     1.9378204643726349e-01
    z[6,1,5]  R1231     -2.3140968382358551e-01
    z[6,1,5]  R1232     2.0276030898094177e-01
    z[6,1,5]  R1233     -2.6396793127059937e-01
    z[6,1,5]  R1234     -5.3916919976472855e-02
    z[6,1,5]  R1235     1.4100360684096813e-02
    z[6,1,5]  R1236     1.1793158203363419e-01
    z[6,1,5]  R1237     -1.5098898112773895e-01
    z[6,1,5]  R1238     -3.3523935079574585e-01
    z[6,1,5]  R1239     -1.8744681775569916e-01
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R1148     -1
    z[6,1,6]  R1149     1
    z[6,1,6]  R1150     -3.9352121949195862e-01
    z[6,1,6]  R1151     0.397322416305542
    z[6,1,6]  R1152     6.4916145801544189e-01
    z[6,1,6]  R1153     1.3663363456726074e-01
    z[6,1,6]  R1154     1.1498459428548813e-01
    z[6,1,6]  R1155     2.0553120970726013e-01
    z[6,1,6]  R1156     2.8817737102508545e-01
    z[6,1,6]  R1157     -3.0668967962265015e-01
    z[6,1,6]  R1158     -0.300184428691864
    z[6,1,6]  R1159     -5.5269223451614380e-01
    z[6,1,6]  R1160     5.0016533583402634e-02
    z[6,1,6]  R1161     -4.7827857732772827e-01
    z[6,1,6]  R1162     -2.7828231453895569e-02
    z[6,1,6]  R1163     1.3620495796203613e-02
    z[6,1,6]  R1164     5.1132321357727051e-02
    z[6,1,6]  R1165     3.1818398833274841e-01
    z[6,1,6]  R1166     -8.1356592476367950e-02
    z[6,1,6]  R1167     2.5460091233253479e-01
    z[6,1,6]  R1168     -1.0346055030822754e-02
    z[6,1,6]  R1169     -2.9780656099319458e-01
    z[6,1,6]  R1170     2.6816916465759277e-01
    z[6,1,6]  R1171     -2.3238374292850494e-01
    z[6,1,6]  R1172     -1.3719917833805084e-01
    z[6,1,6]  R1173     1.9939646124839783e-01
    z[6,1,6]  R1174     -2.9235085844993591e-01
    z[6,1,6]  R1175     4.3229696154594421e-01
    z[6,1,6]  R1176     1.7052348703145981e-02
    z[6,1,6]  R1177     -3.6040824651718140e-01
    z[6,1,6]  R1178     5.1182365417480469e-01
    z[6,1,6]  R1179     0.343861848115921
    z[6,1,6]  R1180     -0.0243021659553051
    z[6,1,6]  R1181     -1.8595525622367859e-01
    z[6,1,6]  R1182     -4.3452523648738861e-02
    z[6,1,6]  R1183     -2.2632901370525360e-01
    z[6,1,6]  R1184     1.7174807190895081e-01
    z[6,1,6]  R1185     0.0263583455234766
    z[6,1,6]  R1186     2.5093618035316467e-01
    z[6,1,6]  R1187     -2.2811074554920197e-01
    z[6,1,6]  R1188     -7.6790824532508850e-02
    z[6,1,6]  R1189     4.0540233254432678e-01
    z[6,1,6]  R1190     2.2860527038574219e-01
    z[6,1,6]  R1191     -1.0897362232208252e-01
    z[6,1,6]  R1192     -7.8589171171188354e-02
    z[6,1,6]  R1193     -1.7819654941558838e-01
    z[6,1,6]  R1194     -1.2982444465160370e-01
    z[6,1,6]  R1195     1.3908928632736206e-01
    z[6,1,6]  R1196     2.1789376437664032e-01
    z[6,1,6]  R1197     1.9258503615856171e-01
    z[6,1,6]  R1198     1.3709321618080139e-01
    z[6,1,6]  R1199     -1.3313873112201691e-01
    z[6,1,6]  R1200     -1.9053514301776886e-01
    z[6,1,6]  R1201     1.1832785606384277e-01
    z[6,1,6]  R1202     4.3967801332473755e-01
    z[6,1,6]  R1203     -4.8423612117767334e-01
    z[6,1,6]  R1204     1.9352915883064270e-01
    z[6,1,6]  R1205     3.6890518665313721e-01
    z[6,1,6]  R1206     -5.7547432184219360e-01
    z[6,1,6]  R1207     3.2123643904924393e-02
    z[6,1,6]  R1208     -9.8000364378094673e-03
    z[6,1,6]  R1209     -1.5896634757518768e-01
    z[6,1,6]  R1210     -1.9087785482406616e-01
    z[6,1,6]  R1211     -1.7828333377838135e-01
    z[6,1,6]  R1212     3.5070598125457764e-02
    z[6,1,6]  R1213     -6.7103527486324310e-02
    z[6,1,6]  R1214     6.6242665052413940e-02
    z[6,1,6]  R1215     -1.4694066345691681e-01
    z[6,1,6]  R1216     1.8468730151653290e-02
    z[6,1,6]  R1217     2.0318174362182617e-01
    z[6,1,6]  R1218     -1.7295676469802856e-01
    z[6,1,6]  R1219     -1.7953509092330933e-01
    z[6,1,6]  R1220     2.5688254833221436e-01
    z[6,1,6]  R1221     4.6851357817649841e-01
    z[6,1,6]  R1222     2.4432139098644257e-01
    z[6,1,6]  R1223     4.8920312523841858e-01
    z[6,1,6]  R1224     -1.7767407000064850e-02
    z[6,1,6]  R1225     0.0679338276386261
    z[6,1,6]  R1226     -1.4336473308503628e-02
    z[6,1,6]  R1227     5.0678491592407227e-02
    z[6,1,6]  R1228     -1.5902754664421082e-01
    z[6,1,6]  R1229     2.6732046157121658e-02
    z[6,1,6]  R1230     -6.2585294246673584e-01
    z[6,1,6]  R1231     -4.8738211393356323e-02
    z[6,1,6]  R1232     -1.0014757513999939e-01
    z[6,1,6]  R1233     -1.3742519915103912e-01
    z[6,1,6]  R1234     -1.5722940862178802e-01
    z[6,1,6]  R1235     3.9180129766464233e-01
    z[6,1,6]  R1236     -1.4284999668598175e-01
    z[6,1,6]  R1237     2.2878804802894592e-01
    z[6,1,6]  R1238     -1.3638909161090851e-01
    z[6,1,6]  R1239     -5.5600155144929886e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1240     -1
    z[2,3,0]  R1241     1
    z[2,3,0]  R1254     -0.490815132856369
    z[2,3,0]  R1255     -3.5189476609230042e-01
    z[2,3,0]  R1256     -6.9665157794952393e-01
    z[2,3,0]  R1257     -4.9690628051757812e-01
    z[2,3,0]  R1258     -9.0260022878646851e-01
    z[2,3,0]  R1259     -4.7346779704093933e-01
    z[2,3,0]  R1260     5.3116691112518311e-01
    z[2,3,0]  R1261     3.8319456577301025e-01
    z[2,3,0]  R1262     1.0995641350746155e-01
    z[2,3,0]  R1263     6.0583537817001343e-01
    z[2,3,0]  R1264     1.7992122471332550e-01
    z[2,3,0]  R1265     2.3500937223434448e-01
    z[2,3,0]  R1266     8.7343639135360718e-01
    z[2,3,0]  R1267     5.2674150466918945e-01
    z[2,3,0]  R1268     5.6507551670074463e-01
    z[2,3,0]  R1269     8.3293646574020386e-01
    z[2,3,0]  R1270     7.2959405183792114e-01
    z[2,3,0]  R1271     4.4843098521232605e-01
    z[2,3,0]  R1272     8.3474791049957275e-01
    z[2,3,0]  R1273     6.5822309255599976e-01
    z[2,3,0]  R1274     6.0884815454483032e-01
    z[2,3,0]  R1275     4.4912764430046082e-01
    z[2,3,0]  R1276     2.8068712353706360e-01
    z[2,3,0]  R1277     4.7725030779838562e-01
    z[2,3,0]  R1278     5.1029217243194580e-01
    z[2,3,0]  R1279     4.9956426024436951e-01
    z[2,3,0]  R1280     1.3929453492164612e-01
    z[2,3,0]  R1281     2.5833564996719360e-01
    z[2,3,0]  R1282     3.2290109992027283e-01
    z[2,3,0]  R1283     5.7730823755264282e-01
    z[2,3,0]  R1284     5.5724453926086426e-01
    z[2,3,0]  R1285     1.7468205094337463e-01
    z[2,3,0]  R1286     4.3995073437690735e-01
    z[2,3,0]  R1287     7.3243713378906250e-01
    z[2,3,0]  R1288     7.2987407445907593e-01
    z[2,3,0]  R1289     5.0881814956665039e-01
    z[2,3,0]  R1290     4.4130480289459229e-01
    z[2,3,0]  R1291     7.2296333312988281e-01
    z[2,3,0]  R1292     4.8452901840209961e-01
    z[2,3,0]  R1293     4.5559036731719971e-01
    z[2,3,0]  R1294     4.4959786534309387e-01
    z[2,3,0]  R1295     8.5046076774597168e-01
    z[2,3,0]  R1296     3.8043540716171265e-01
    z[2,3,0]  R1297     6.8055588006973267e-01
    z[2,3,0]  R1298     6.8704360723495483e-01
    z[2,3,0]  R1299     1.5266070840880275e-03
    z[2,3,0]  R1300     5.1778149604797363e-01
    z[2,3,0]  R1301     3.1060710549354553e-01
    z[2,3,0]  R1302     2.0471620559692383e-01
    z[2,3,0]  R1303     -1.1524931527674198e-02
    z[2,3,0]  R1304     -3.8177676498889923e-02
    z[2,3,0]  R1305     4.8281392455101013e-01
    z[2,3,0]  R1306     -5.0466382503509521e-01
    z[2,3,0]  R1307     -5.7353466749191284e-01
    z[2,3,0]  R1308     1.0525610297918320e-01
    z[2,3,0]  R1309     -7.7337872982025146e-01
    z[2,3,0]  R1310     -6.4111167192459106e-01
    z[2,3,0]  R1311     -6.9564241170883179e-01
    z[2,3,0]  R1312     -6.2685352563858032e-01
    z[2,3,0]  R1313     -0.719005286693573
    z[2,3,0]  R1314     -3.7654018402099609e-01
    z[2,3,0]  R1315     1.6541968286037445e-01
    z[2,3,0]  R1316     9.5905058085918427e-02
    z[2,3,0]  R1317     -4.5115888118743896e-02
    z[2,3,0]  R1318     2.8157824277877808e-01
    z[2,3,0]  R1319     3.9633381366729736e-01
    z[2,3,0]  R1320     4.0888580679893494e-01
    z[2,3,0]  R1321     4.4836091995239258e-01
    z[2,3,0]  R1322     0.575560986995697
    z[2,3,0]  R1323     4.1028848290443420e-01
    z[2,3,0]  R1324     2.2562281787395477e-01
    z[2,3,0]  R1325     -2.0755213499069214e-01
    z[2,3,0]  R1326     -3.9948263764381409e-01
    z[2,3,0]  R1327     3.1391668319702148e-01
    z[2,3,0]  R1328     3.6903870105743408e-01
    z[2,3,0]  R1329     2.7826866507530212e-01
    z[2,3,0]  R1330     5.2810066938400269e-01
    z[2,3,0]  R1331     4.2486450076103210e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1242     -1
    z[2,3,1]  R1243     1
    z[2,3,1]  R1254     -3.4972810745239258e-01
    z[2,3,1]  R1255     -2.1696461737155914e-01
    z[2,3,1]  R1256     -4.7060576081275940e-01
    z[2,3,1]  R1257     -1.8660506606101990e-01
    z[2,3,1]  R1258     -2.4373726546764374e-01
    z[2,3,1]  R1259     -1.9525794684886932e-01
    z[2,3,1]  R1260     -4.0694692730903625e-01
    z[2,3,1]  R1261     -3.9544859528541565e-01
    z[2,3,1]  R1262     7.0127922296524048e-01
    z[2,3,1]  R1263     6.4099001884460449e-01
    z[2,3,1]  R1264     -6.8807423114776611e-01
    z[2,3,1]  R1265     -5.1114434003829956e-01
    z[2,3,1]  R1266     3.2021689414978027e-01
    z[2,3,1]  R1267     3.0431634187698364e-01
    z[2,3,1]  R1268     6.7377209663391113e-02
    z[2,3,1]  R1269     1.9425563514232635e-01
    z[2,3,1]  R1270     -2.4642951320856810e-03
    z[2,3,1]  R1271     4.8408966511487961e-02
    z[2,3,1]  R1272     -0.149896040558815
    z[2,3,1]  R1273     6.5576724708080292e-02
    z[2,3,1]  R1274     6.2107443809509277e-01
    z[2,3,1]  R1275     7.3644739389419556e-01
    z[2,3,1]  R1276     7.7415573596954346e-01
    z[2,3,1]  R1277     7.1338462829589844e-01
    z[2,3,1]  R1278     6.2748807668685913e-01
    z[2,3,1]  R1279     4.8782244324684143e-01
    z[2,3,1]  R1280     6.2506145238876343e-01
    z[2,3,1]  R1281     7.5948399305343628e-01
    z[2,3,1]  R1282     7.4792701005935669e-01
    z[2,3,1]  R1283     5.9795522689819336e-01
    z[2,3,1]  R1284     -5.2683621644973755e-01
    z[2,3,1]  R1285     8.2538014650344849e-01
    z[2,3,1]  R1286     2.9217118024826050e-01
    z[2,3,1]  R1287     1.2891595065593719e-01
    z[2,3,1]  R1288     4.1784065961837769e-01
    z[2,3,1]  R1289     4.3310755491256714e-01
    z[2,3,1]  R1290     3.7485957145690918e-01
    z[2,3,1]  R1291     7.1263968944549561e-02
    z[2,3,1]  R1292     1.6778342425823212e-01
    z[2,3,1]  R1293     1.9675391912460327e-01
    z[2,3,1]  R1294     6.7743313312530518e-01
    z[2,3,1]  R1295     2.3330783843994141e-01
    z[2,3,1]  R1296     6.2655168771743774e-01
    z[2,3,1]  R1297     2.1196378767490387e-01
    z[2,3,1]  R1298     5.6680923700332642e-01
    z[2,3,1]  R1299     3.3163674175739288e-02
    z[2,3,1]  R1300     7.7464574575424194e-01
    z[2,3,1]  R1301     8.4533131122589111e-01
    z[2,3,1]  R1302     0.745384931564331
    z[2,3,1]  R1303     7.7667677402496338e-01
    z[2,3,1]  R1304     -2.2855930030345917e-01
    z[2,3,1]  R1305     -2.2460272908210754e-01
    z[2,3,1]  R1306     3.2066803425550461e-02
    z[2,3,1]  R1307     -2.4953939020633698e-01
    z[2,3,1]  R1308     -3.4873235225677490e-01
    z[2,3,1]  R1309     8.6467780172824860e-02
    z[2,3,1]  R1310     1.0977321863174438e-01
    z[2,3,1]  R1311     1.7737165093421936e-01
    z[2,3,1]  R1312     6.5116435289382935e-02
    z[2,3,1]  R1313     2.6427105069160461e-01
    z[2,3,1]  R1314     1.6233828663825989e-01
    z[2,3,1]  R1315     3.5085299611091614e-01
    z[2,3,1]  R1316     3.7565350532531738e-01
    z[2,3,1]  R1317     -6.6838508844375610e-01
    z[2,3,1]  R1318     -7.0583873987197876e-01
    z[2,3,1]  R1319     7.8617835044860840e-01
    z[2,3,1]  R1320     3.8600188493728638e-01
    z[2,3,1]  R1321     2.1506385505199432e-01
    z[2,3,1]  R1322     -7.4995177984237671e-01
    z[2,3,1]  R1323     -5.3873974084854126e-01
    z[2,3,1]  R1324     -6.3138955831527710e-01
    z[2,3,1]  R1325     6.6662716865539551e-01
    z[2,3,1]  R1326     -7.1545474231243134e-02
    z[2,3,1]  R1327     7.5208085775375366e-01
    z[2,3,1]  R1328     6.2472069263458252e-01
    z[2,3,1]  R1329     5.6213027238845825e-01
    z[2,3,1]  R1330     4.2814698815345764e-01
    z[2,3,1]  R1331     6.2551081180572510e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1244     -1
    z[2,3,2]  R1245     1
    z[2,3,2]  R1254     -4.9553540349006653e-01
    z[2,3,2]  R1255     -6.0714691877365112e-01
    z[2,3,2]  R1256     -2.7851250767707825e-01
    z[2,3,2]  R1257     -5.6539791822433472e-01
    z[2,3,2]  R1258     -3.0870464444160461e-01
    z[2,3,2]  R1259     0.218109130859375
    z[2,3,2]  R1260     -6.6253411769866943e-01
    z[2,3,2]  R1261     9.3164056539535522e-02
    z[2,3,2]  R1262     -3.3220261335372925e-01
    z[2,3,2]  R1263     3.8047355413436890e-01
    z[2,3,2]  R1264     2.3348897695541382e-01
    z[2,3,2]  R1265     2.8866133093833923e-01
    z[2,3,2]  R1266     6.9517545402050018e-02
    z[2,3,2]  R1267     4.1357865929603577e-01
    z[2,3,2]  R1268     5.2172702550888062e-01
    z[2,3,2]  R1269     -6.8027332425117493e-02
    z[2,3,2]  R1270     4.4569137692451477e-01
    z[2,3,2]  R1271     5.8127278089523315e-01
    z[2,3,2]  R1272     1.4774306118488312e-01
    z[2,3,2]  R1273     1.8644580245018005e-01
    z[2,3,2]  R1274     -6.2145132571458817e-02
    z[2,3,2]  R1275     8.5463829338550568e-02
    z[2,3,2]  R1276     -5.0757521390914917e-01
    z[2,3,2]  R1277     -8.5780851542949677e-02
    z[2,3,2]  R1278     3.4224835038185120e-01
    z[2,3,2]  R1279     4.2534321546554565e-01
    z[2,3,2]  R1280     -1.3075712323188782e-01
    z[2,3,2]  R1281     -3.8576906919479370e-01
    z[2,3,2]  R1282     2.0400781184434891e-02
    z[2,3,2]  R1283     2.0019893348217010e-01
    z[2,3,2]  R1284     1.3905979692935944e-01
    z[2,3,2]  R1285     -0.289896696805954
    z[2,3,2]  R1286     5.9983348846435547e-01
    z[2,3,2]  R1287     5.6533169746398926e-01
    z[2,3,2]  R1288     3.3473175764083862e-01
    z[2,3,2]  R1289     0.591620922088623
    z[2,3,2]  R1290     6.4955705404281616e-01
    z[2,3,2]  R1291     4.2200678586959839e-01
    z[2,3,2]  R1292     3.4381836652755737e-01
    z[2,3,2]  R1293     7.5425392389297485e-01
    z[2,3,2]  R1294     1.3663128018379211e-01
    z[2,3,2]  R1295     2.3372364044189453e-01
    z[2,3,2]  R1296     -2.8846305608749390e-01
    z[2,3,2]  R1297     4.8309543728828430e-01
    z[2,3,2]  R1298     -2.6111856102943420e-01
    z[2,3,2]  R1299     -0.0473548024892807
    z[2,3,2]  R1300     4.2363476008176804e-02
    z[2,3,2]  R1301     1.9885657727718353e-01
    z[2,3,2]  R1302     -1.9453147053718567e-01
    z[2,3,2]  R1303     3.3912059664726257e-01
    z[2,3,2]  R1304     -7.5069051980972290e-01
    z[2,3,2]  R1305     -6.9352585077285767e-01
    z[2,3,2]  R1306     0.0881400927901268
    z[2,3,2]  R1307     -0.616380512714386
    z[2,3,2]  R1308     -0.812161922454834
    z[2,3,2]  R1309     1.8503734469413757e-01
    z[2,3,2]  R1310     3.2529249787330627e-01
    z[2,3,2]  R1311     -2.6412791013717651e-01
    z[2,3,2]  R1312     2.7396348118782043e-01
    z[2,3,2]  R1313     -2.3845118284225464e-01
    z[2,3,2]  R1314     -2.2934272885322571e-02
    z[2,3,2]  R1315     1.7681892216205597e-01
    z[2,3,2]  R1316     5.9974616765975952e-01
    z[2,3,2]  R1317     4.1776421666145325e-01
    z[2,3,2]  R1318     3.7270089983940125e-01
    z[2,3,2]  R1319     -5.5384196341037750e-02
    z[2,3,2]  R1320     4.2232406139373779e-01
    z[2,3,2]  R1321     2.1507011353969574e-01
    z[2,3,2]  R1322     -1.7446257174015045e-01
    z[2,3,2]  R1323     -5.5856686085462570e-02
    z[2,3,2]  R1324     8.0902762711048126e-03
    z[2,3,2]  R1325     -1.5333354473114014e-01
    z[2,3,2]  R1326     1.4602917432785034e-01
    z[2,3,2]  R1327     2.9094228148460388e-01
    z[2,3,2]  R1328     3.6671683192253113e-01
    z[2,3,2]  R1329     4.8931926488876343e-01
    z[2,3,2]  R1330     2.4885062873363495e-01
    z[2,3,2]  R1331     -0.0532621331512928
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1246     -1
    z[2,3,3]  R1247     1
    z[2,3,3]  R1254     4.6444028615951538e-01
    z[2,3,3]  R1255     1.4665301144123077e-01
    z[2,3,3]  R1256     5.9248123317956924e-02
    z[2,3,3]  R1257     -0.0647757425904274
    z[2,3,3]  R1258     -3.3503524959087372e-02
    z[2,3,3]  R1259     3.0617249011993408e-01
    z[2,3,3]  R1260     -1.5060655772686005e-01
    z[2,3,3]  R1261     -3.7506937980651855e-01
    z[2,3,3]  R1262     4.7289678454399109e-01
    z[2,3,3]  R1263     5.9952370822429657e-02
    z[2,3,3]  R1264     2.2570972144603729e-01
    z[2,3,3]  R1265     -4.0436097979545593e-01
    z[2,3,3]  R1266     1.4787705242633820e-01
    z[2,3,3]  R1267     3.8220247626304626e-01
    z[2,3,3]  R1268     3.7393602728843689e-01
    z[2,3,3]  R1269     2.1852149069309235e-01
    z[2,3,3]  R1270     4.2644214630126953e-01
    z[2,3,3]  R1271     3.7610808014869690e-01
    z[2,3,3]  R1272     4.6936103701591492e-01
    z[2,3,3]  R1273     3.8113737106323242e-01
    z[2,3,3]  R1274     0.458217054605484
    z[2,3,3]  R1275     3.4837085008621216e-01
    z[2,3,3]  R1276     1.8025636672973633e-01
    z[2,3,3]  R1277     2.6481881737709045e-01
    z[2,3,3]  R1278     4.5567402243614197e-01
    z[2,3,3]  R1279     4.8127308487892151e-02
    z[2,3,3]  R1280     7.1094882488250732e-01
    z[2,3,3]  R1281     -1.1758894473314285e-01
    z[2,3,3]  R1282     -3.3963659405708313e-01
    z[2,3,3]  R1283     -1.1370488256216049e-01
    z[2,3,3]  R1284     -4.8172511160373688e-02
    z[2,3,3]  R1285     3.3632761240005493e-01
    z[2,3,3]  R1286     1.5562395751476288e-01
    z[2,3,3]  R1287     2.5202763080596924e-01
    z[2,3,3]  R1288     -9.6530042588710785e-02
    z[2,3,3]  R1289     9.2465788125991821e-02
    z[2,3,3]  R1290     0.26992267370224
    z[2,3,3]  R1291     2.6868173480033875e-01
    z[2,3,3]  R1292     4.7727242112159729e-01
    z[2,3,3]  R1293     4.0019545704126358e-02
    z[2,3,3]  R1294     4.2768466472625732e-01
    z[2,3,3]  R1295     -9.6108177676796913e-03
    z[2,3,3]  R1296     4.9866217374801636e-01
    z[2,3,3]  R1297     2.4773922562599182e-01
    z[2,3,3]  R1298     2.5836622714996338e-01
    z[2,3,3]  R1299     -9.5853674411773682e-01
    z[2,3,3]  R1300     -3.4687477350234985e-01
    z[2,3,3]  R1301     -1.3818985223770142e-01
    z[2,3,3]  R1302     -3.8389381766319275e-01
    z[2,3,3]  R1303     -2.2529102861881256e-01
    z[2,3,3]  R1304     -2.0729070529341698e-02
    z[2,3,3]  R1305     1.4990265481173992e-02
    z[2,3,3]  R1306     8.1128489971160889e-01
    z[2,3,3]  R1307     2.8460944071412086e-02
    z[2,3,3]  R1308     2.4128781259059906e-01
    z[2,3,3]  R1309     5.1792770624160767e-01
    z[2,3,3]  R1310     5.9925496578216553e-01
    z[2,3,3]  R1311     5.5411982536315918e-01
    z[2,3,3]  R1312     4.8862314224243164e-01
    z[2,3,3]  R1313     4.1310253739356995e-01
    z[2,3,3]  R1314     -6.5624141693115234e-01
    z[2,3,3]  R1315     -5.3472006320953369e-01
    z[2,3,3]  R1316     -0.647748589515686
    z[2,3,3]  R1317     -3.3803331851959229e-01
    z[2,3,3]  R1318     2.0410838723182678e-01
    z[2,3,3]  R1319     3.1497529149055481e-01
    z[2,3,3]  R1320     2.0240074396133423e-01
    z[2,3,3]  R1321     3.8643366098403931e-01
    z[2,3,3]  R1322     2.1542568504810333e-01
    z[2,3,3]  R1323     -0.577997088432312
    z[2,3,3]  R1324     -6.2361329793930054e-01
    z[2,3,3]  R1325     -5.4922294616699219e-01
    z[2,3,3]  R1326     -6.4651709794998169e-01
    z[2,3,3]  R1327     4.4862103462219238e-01
    z[2,3,3]  R1328     4.9435773491859436e-01
    z[2,3,3]  R1329     4.2824935913085938e-01
    z[2,3,3]  R1330     6.4358937740325928e-01
    z[2,3,3]  R1331     5.6243580579757690e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1248     -1
    z[2,3,4]  R1249     1
    z[2,3,4]  R1254     -2.8815552592277527e-01
    z[2,3,4]  R1255     -6.5752822160720825e-01
    z[2,3,4]  R1256     -1.6028371453285217e-01
    z[2,3,4]  R1257     -2.5635886192321777e-01
    z[2,3,4]  R1258     1.1484770476818085e-01
    z[2,3,4]  R1259     -7.2272044420242310e-01
    z[2,3,4]  R1260     2.5529885292053223e-01
    z[2,3,4]  R1261     -4.5813828706741333e-01
    z[2,3,4]  R1262     2.7722854167222977e-02
    z[2,3,4]  R1263     -0.244576096534729
    z[2,3,4]  R1264     4.5235726237297058e-01
    z[2,3,4]  R1265     3.4507265686988831e-01
    z[2,3,4]  R1266     -1.8130175769329071e-01
    z[2,3,4]  R1267     1.6281618177890778e-01
    z[2,3,4]  R1268     -1.6976632177829742e-02
    z[2,3,4]  R1269     1.7127616703510284e-01
    z[2,3,4]  R1270     -3.7139128893613815e-02
    z[2,3,4]  R1271     4.7775000333786011e-01
    z[2,3,4]  R1272     -1.0041683167219162e-01
    z[2,3,4]  R1273     4.6058148145675659e-01
    z[2,3,4]  R1274     -1.5805619955062866e-01
    z[2,3,4]  R1275     2.7727490663528442e-01
    z[2,3,4]  R1276     1.8001537770032883e-02
    z[2,3,4]  R1277     -1.9209538400173187e-01
    z[2,3,4]  R1278     -8.6982309818267822e-02
    z[2,3,4]  R1279     4.2937391996383667e-01
    z[2,3,4]  R1280     3.4035738557577133e-02
    z[2,3,4]  R1281     3.4835720062255859e-01
    z[2,3,4]  R1282     2.7765345573425293e-01
    z[2,3,4]  R1283     3.1549766659736633e-01
    z[2,3,4]  R1284     1.4113017916679382e-01
    z[2,3,4]  R1285     -7.2040654718875885e-02
    z[2,3,4]  R1286     4.3641266226768494e-01
    z[2,3,4]  R1287     -1.7879876494407654e-01
    z[2,3,4]  R1288     -0.354126900434494
    z[2,3,4]  R1289     -3.4630599617958069e-01
    z[2,3,4]  R1290     -0.170893132686615
    z[2,3,4]  R1291     3.4464788436889648e-01
    z[2,3,4]  R1292     2.5045084953308105e-01
    z[2,3,4]  R1293     -3.4921568632125854e-01
    z[2,3,4]  R1294     0.0611988827586174
    z[2,3,4]  R1295     1.4504013955593109e-01
    z[2,3,4]  R1296     1.7014007270336151e-01
    z[2,3,4]  R1297     -8.7398067116737366e-02
    z[2,3,4]  R1298     2.2325593233108521e-01
    z[2,3,4]  R1299     -5.8964673429727554e-02
    z[2,3,4]  R1300     9.7499601542949677e-02
    z[2,3,4]  R1301     -7.8991755843162537e-02
    z[2,3,4]  R1302     -4.2591953277587891e-01
    z[2,3,4]  R1303     -1.2765172123908997e-01
    z[2,3,4]  R1304     -3.1282356381416321e-01
    z[2,3,4]  R1305     -4.0590861439704895e-01
    z[2,3,4]  R1306     -9.7965687513351440e-02
    z[2,3,4]  R1307     3.0620750784873962e-01
    z[2,3,4]  R1308     5.2551679313182831e-02
    z[2,3,4]  R1309     2.1951572597026825e-01
    z[2,3,4]  R1310     -1.1212415993213654e-01
    z[2,3,4]  R1311     1.7882628738880157e-01
    z[2,3,4]  R1312     8.6182296276092529e-02
    z[2,3,4]  R1313     -3.7112173438072205e-01
    z[2,3,4]  R1314     3.5811313986778259e-01
    z[2,3,4]  R1315     -6.5637670457363129e-02
    z[2,3,4]  R1316     -3.3531852066516876e-02
    z[2,3,4]  R1317     1.4174060523509979e-01
    z[2,3,4]  R1318     0.177893728017807
    z[2,3,4]  R1319     -1.0606989264488220e-01
    z[2,3,4]  R1320     -7.3660008609294891e-02
    z[2,3,4]  R1321     2.4465283751487732e-01
    z[2,3,4]  R1322     1.2989516369998455e-02
    z[2,3,4]  R1323     9.4605013728141785e-02
    z[2,3,4]  R1324     3.4848979115486145e-01
    z[2,3,4]  R1325     -3.3763018250465393e-01
    z[2,3,4]  R1326     -1.6866831481456757e-01
    z[2,3,4]  R1327     -7.3030188679695129e-02
    z[2,3,4]  R1328     -1.4280991256237030e-01
    z[2,3,4]  R1329     -5.0838004797697067e-02
    z[2,3,4]  R1330     1.5157523751258850e-01
    z[2,3,4]  R1331     1.3655400276184082e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1250     -1
    z[2,3,5]  R1251     1
    z[2,3,5]  R1254     -2.2357408702373505e-01
    z[2,3,5]  R1255     -1.5324714593589306e-02
    z[2,3,5]  R1256     6.0758337378501892e-02
    z[2,3,5]  R1257     -1.7199523746967316e-01
    z[2,3,5]  R1258     8.3132229745388031e-02
    z[2,3,5]  R1259     -1.2672264873981476e-01
    z[2,3,5]  R1260     -1.5328468382358551e-01
    z[2,3,5]  R1261     1.7406722903251648e-01
    z[2,3,5]  R1262     -4.0122276544570923e-01
    z[2,3,5]  R1263     -1.0973126441240311e-01
    z[2,3,5]  R1264     4.1944679617881775e-01
    z[2,3,5]  R1265     4.6755722165107727e-01
    z[2,3,5]  R1266     -2.3887167870998383e-01
    z[2,3,5]  R1267     -3.8349515199661255e-01
    z[2,3,5]  R1268     -3.8785532116889954e-01
    z[2,3,5]  R1269     -4.1204899549484253e-01
    z[2,3,5]  R1270     -2.7068731188774109e-01
    z[2,3,5]  R1271     -2.9718539118766785e-01
    z[2,3,5]  R1272     -1.3412435352802277e-01
    z[2,3,5]  R1273     -0.412482887506485
    z[2,3,5]  R1274     4.7123548574745655e-03
    z[2,3,5]  R1275     -2.1599614620208740e-01
    z[2,3,5]  R1276     -1.2933824956417084e-01
    z[2,3,5]  R1277     -3.5681214928627014e-01
    z[2,3,5]  R1278     -2.7933532372117043e-02
    z[2,3,5]  R1279     -3.3970877528190613e-01
    z[2,3,5]  R1280     -1.4171645045280457e-01
    z[2,3,5]  R1281     9.4780838117003441e-03
    z[2,3,5]  R1282     -1.3779945671558380e-01
    z[2,3,5]  R1283     -0.00695176562294364
    z[2,3,5]  R1284     5.6822425127029419e-01
    z[2,3,5]  R1285     -3.5686764866113663e-02
    z[2,3,5]  R1286     -3.5881036520004272e-01
    z[2,3,5]  R1287     -1.4847515523433685e-01
    z[2,3,5]  R1288     -1.2488958239555359e-01
    z[2,3,5]  R1289     -2.6262101531028748e-01
    z[2,3,5]  R1290     -3.7424251437187195e-01
    z[2,3,5]  R1291     -5.8189444243907928e-02
    z[2,3,5]  R1292     -5.7193273305892944e-01
    z[2,3,5]  R1293     -1.0489203967154026e-02
    z[2,3,5]  R1294     1.4155525714159012e-02
    z[2,3,5]  R1295     -2.0045363903045654e-01
    z[2,3,5]  R1296     3.1995948404073715e-02
    z[2,3,5]  R1297     -3.4491837024688721e-01
    z[2,3,5]  R1298     1.4150644652545452e-02
    z[2,3,5]  R1299     -2.5481337308883667e-01
    z[2,3,5]  R1300     -2.1574825223069638e-04
    z[2,3,5]  R1301     -0.0421307310461998
    z[2,3,5]  R1302     -1.0680418461561203e-01
    z[2,3,5]  R1303     -4.5179602503776550e-01
    z[2,3,5]  R1304     0.261923223733902
    z[2,3,5]  R1305     2.3837955296039581e-01
    z[2,3,5]  R1306     1.7931589484214783e-01
    z[2,3,5]  R1307     9.4692386686801910e-02
    z[2,3,5]  R1308     1.1864223517477512e-02
    z[2,3,5]  R1309     9.2396877706050873e-02
    z[2,3,5]  R1310     -2.9577752947807312e-01
    z[2,3,5]  R1311     4.6932362020015717e-03
    z[2,3,5]  R1312     3.8095137476921082e-01
    z[2,3,5]  R1313     -0.177132248878479
    z[2,3,5]  R1314     -4.0599358081817627e-01
    z[2,3,5]  R1315     -4.4231596589088440e-01
    z[2,3,5]  R1316     -1.8506981432437897e-02
    z[2,3,5]  R1317     4.2402917146682739e-01
    z[2,3,5]  R1318     9.0337663888931274e-02
    z[2,3,5]  R1319     -3.2538047432899475e-01
    z[2,3,5]  R1320     -4.9688392877578735e-01
    z[2,3,5]  R1321     -6.4921134710311890e-01
    z[2,3,5]  R1322     9.4749532639980316e-02
    z[2,3,5]  R1323     -6.7315645515918732e-02
    z[2,3,5]  R1324     4.0143728256225586e-03
    z[2,3,5]  R1325     1.2150320410728455e-01
    z[2,3,5]  R1326     0.606165885925293
    z[2,3,5]  R1327     -2.0348009467124939e-01
    z[2,3,5]  R1328     -2.7250227332115173e-01
    z[2,3,5]  R1329     -4.1970375180244446e-01
    z[2,3,5]  R1330     -1.8364740908145905e-01
    z[2,3,5]  R1331     -2.4095095694065094e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1252     -1
    z[2,3,6]  R1253     1
    z[2,3,6]  R1254     2.0618361234664917e-01
    z[2,3,6]  R1255     7.9898700118064880e-02
    z[2,3,6]  R1256     -4.2748656868934631e-01
    z[2,3,6]  R1257     -5.4689103364944458e-01
    z[2,3,6]  R1258     9.6865154802799225e-02
    z[2,3,6]  R1259     -2.4084423482418060e-01
    z[2,3,6]  R1260     4.4141769409179688e-02
    z[2,3,6]  R1261     0.554288387298584
    z[2,3,6]  R1262     1.9463993608951569e-02
    z[2,3,6]  R1263     -4.3386835604906082e-02
    z[2,3,6]  R1264     9.0318925678730011e-02
    z[2,3,6]  R1265     -3.1461721658706665e-01
    z[2,3,6]  R1266     1.3393911719322205e-01
    z[2,3,6]  R1267     3.7313720583915710e-01
    z[2,3,6]  R1268     -3.3675307035446167e-01
    z[2,3,6]  R1269     -1.3031649589538574e-01
    z[2,3,6]  R1270     -1.1199028044939041e-01
    z[2,3,6]  R1271     2.5821531191468239e-02
    z[2,3,6]  R1272     1.0259898751974106e-01
    z[2,3,6]  R1273     -1.1703076772391796e-02
    z[2,3,6]  R1274     -6.8860031664371490e-02
    z[2,3,6]  R1275     6.1053719371557236e-02
    z[2,3,6]  R1276     -1.2132717669010162e-01
    z[2,3,6]  R1277     -1.4700870215892792e-01
    z[2,3,6]  R1278     1.1287894845008850e-01
    z[2,3,6]  R1279     1.7166174948215485e-01
    z[2,3,6]  R1280     -2.1472658216953278e-01
    z[2,3,6]  R1281     2.6899653673171997e-01
    z[2,3,6]  R1282     3.5283237695693970e-01
    z[2,3,6]  R1283     -3.9568844437599182e-01
    z[2,3,6]  R1284     -2.1786986291408539e-01
    z[2,3,6]  R1285     2.9088482260704041e-01
    z[2,3,6]  R1286     -1.3363888859748840e-01
    z[2,3,6]  R1287     -9.8918646574020386e-02
    z[2,3,6]  R1288     -1.7414465546607971e-01
    z[2,3,6]  R1289     -7.7840596437454224e-02
    z[2,3,6]  R1290     0.026185292750597
    z[2,3,6]  R1291     3.1590768694877625e-01
    z[2,3,6]  R1292     -3.5322561860084534e-02
    z[2,3,6]  R1293     -2.4731151759624481e-01
    z[2,3,6]  R1294     -3.6526456475257874e-01
    z[2,3,6]  R1295     -3.2610824704170227e-01
    z[2,3,6]  R1296     -3.1757766008377075e-01
    z[2,3,6]  R1297     -2.6561614871025085e-01
    z[2,3,6]  R1298     0.147373765707016
    z[2,3,6]  R1299     9.7242005169391632e-02
    z[2,3,6]  R1300     1.4258872717618942e-02
    z[2,3,6]  R1301     3.4969004988670349e-01
    z[2,3,6]  R1302     -1.5640050172805786e-01
    z[2,3,6]  R1303     -1.0230807214975357e-01
    z[2,3,6]  R1304     -4.6462330222129822e-01
    z[2,3,6]  R1305     1.1685429513454437e-01
    z[2,3,6]  R1306     -1.9126628339290619e-01
    z[2,3,6]  R1307     3.5401052236557007e-01
    z[2,3,6]  R1308     3.8285449147224426e-01
    z[2,3,6]  R1309     -1.8760672211647034e-01
    z[2,3,6]  R1310     1.0930579155683517e-01
    z[2,3,6]  R1311     2.7533236145973206e-01
    z[2,3,6]  R1312     3.6939746141433716e-01
    z[2,3,6]  R1313     -1.2873359024524689e-01
    z[2,3,6]  R1314     -3.2803854346275330e-01
    z[2,3,6]  R1315     5.7653826475143433e-01
    z[2,3,6]  R1316     2.6257598400115967e-01
    z[2,3,6]  R1317     -2.5008264183998108e-01
    z[2,3,6]  R1318     -4.4959101080894470e-01
    z[2,3,6]  R1319     -7.3776558041572571e-02
    z[2,3,6]  R1320     -0.460621178150177
    z[2,3,6]  R1321     2.7532455325126648e-01
    z[2,3,6]  R1322     -1.4251363277435303e-01
    z[2,3,6]  R1323     -4.3673881888389587e-01
    z[2,3,6]  R1324     2.0005346834659576e-01
    z[2,3,6]  R1325     2.4210794270038605e-01
    z[2,3,6]  R1326     -9.9951634183526039e-03
    z[2,3,6]  R1327     5.6434098631143570e-02
    z[2,3,6]  R1328     -3.3775623887777328e-03
    z[2,3,6]  R1329     7.0777930319309235e-02
    z[2,3,6]  R1330     7.0458851754665375e-02
    z[2,3,6]  R1331     -1.7986442148685455e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1332     -1
    z[3,2,0]  R1333     1
    z[3,2,0]  R1346     -3.8177676498889923e-02
    z[3,2,0]  R1347     4.8281392455101013e-01
    z[3,2,0]  R1348     -5.0466382503509521e-01
    z[3,2,0]  R1349     -5.7353466749191284e-01
    z[3,2,0]  R1350     1.0525610297918320e-01
    z[3,2,0]  R1351     -7.7337872982025146e-01
    z[3,2,0]  R1352     -6.4111167192459106e-01
    z[3,2,0]  R1353     -6.9564241170883179e-01
    z[3,2,0]  R1354     -6.2685352563858032e-01
    z[3,2,0]  R1355     -0.719005286693573
    z[3,2,0]  R1356     -3.7654018402099609e-01
    z[3,2,0]  R1357     1.6541968286037445e-01
    z[3,2,0]  R1358     9.5905058085918427e-02
    z[3,2,0]  R1359     -4.5115888118743896e-02
    z[3,2,0]  R1360     2.8157824277877808e-01
    z[3,2,0]  R1361     3.9633381366729736e-01
    z[3,2,0]  R1362     4.0888580679893494e-01
    z[3,2,0]  R1363     4.4836091995239258e-01
    z[3,2,0]  R1364     0.575560986995697
    z[3,2,0]  R1365     4.1028848290443420e-01
    z[3,2,0]  R1366     2.2562281787395477e-01
    z[3,2,0]  R1367     -2.0755213499069214e-01
    z[3,2,0]  R1368     -3.9948263764381409e-01
    z[3,2,0]  R1369     3.1391668319702148e-01
    z[3,2,0]  R1370     3.6903870105743408e-01
    z[3,2,0]  R1371     2.7826866507530212e-01
    z[3,2,0]  R1372     5.2810066938400269e-01
    z[3,2,0]  R1373     4.2486450076103210e-01
    z[3,2,0]  R1374     -0.490815132856369
    z[3,2,0]  R1375     -3.5189476609230042e-01
    z[3,2,0]  R1376     -6.9665157794952393e-01
    z[3,2,0]  R1377     -4.9690628051757812e-01
    z[3,2,0]  R1378     -9.0260022878646851e-01
    z[3,2,0]  R1379     -4.7346779704093933e-01
    z[3,2,0]  R1380     5.3116691112518311e-01
    z[3,2,0]  R1381     3.8319456577301025e-01
    z[3,2,0]  R1382     1.0995641350746155e-01
    z[3,2,0]  R1383     6.0583537817001343e-01
    z[3,2,0]  R1384     1.7992122471332550e-01
    z[3,2,0]  R1385     2.3500937223434448e-01
    z[3,2,0]  R1386     8.7343639135360718e-01
    z[3,2,0]  R1387     5.2674150466918945e-01
    z[3,2,0]  R1388     5.6507551670074463e-01
    z[3,2,0]  R1389     8.3293646574020386e-01
    z[3,2,0]  R1390     7.2959405183792114e-01
    z[3,2,0]  R1391     4.4843098521232605e-01
    z[3,2,0]  R1392     8.3474791049957275e-01
    z[3,2,0]  R1393     6.5822309255599976e-01
    z[3,2,0]  R1394     6.0884815454483032e-01
    z[3,2,0]  R1395     4.4912764430046082e-01
    z[3,2,0]  R1396     2.8068712353706360e-01
    z[3,2,0]  R1397     4.7725030779838562e-01
    z[3,2,0]  R1398     5.1029217243194580e-01
    z[3,2,0]  R1399     4.9956426024436951e-01
    z[3,2,0]  R1400     1.3929453492164612e-01
    z[3,2,0]  R1401     2.5833564996719360e-01
    z[3,2,0]  R1402     3.2290109992027283e-01
    z[3,2,0]  R1403     5.7730823755264282e-01
    z[3,2,0]  R1404     5.5724453926086426e-01
    z[3,2,0]  R1405     1.7468205094337463e-01
    z[3,2,0]  R1406     4.3995073437690735e-01
    z[3,2,0]  R1407     7.3243713378906250e-01
    z[3,2,0]  R1408     7.2987407445907593e-01
    z[3,2,0]  R1409     5.0881814956665039e-01
    z[3,2,0]  R1410     4.4130480289459229e-01
    z[3,2,0]  R1411     7.2296333312988281e-01
    z[3,2,0]  R1412     4.8452901840209961e-01
    z[3,2,0]  R1413     4.5559036731719971e-01
    z[3,2,0]  R1414     4.4959786534309387e-01
    z[3,2,0]  R1415     8.5046076774597168e-01
    z[3,2,0]  R1416     3.8043540716171265e-01
    z[3,2,0]  R1417     6.8055588006973267e-01
    z[3,2,0]  R1418     6.8704360723495483e-01
    z[3,2,0]  R1419     1.5266070840880275e-03
    z[3,2,0]  R1420     5.1778149604797363e-01
    z[3,2,0]  R1421     3.1060710549354553e-01
    z[3,2,0]  R1422     2.0471620559692383e-01
    z[3,2,0]  R1423     -1.1524931527674198e-02
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1334     -1
    z[3,2,1]  R1335     1
    z[3,2,1]  R1346     -2.2855930030345917e-01
    z[3,2,1]  R1347     -2.2460272908210754e-01
    z[3,2,1]  R1348     3.2066803425550461e-02
    z[3,2,1]  R1349     -2.4953939020633698e-01
    z[3,2,1]  R1350     -3.4873235225677490e-01
    z[3,2,1]  R1351     8.6467780172824860e-02
    z[3,2,1]  R1352     1.0977321863174438e-01
    z[3,2,1]  R1353     1.7737165093421936e-01
    z[3,2,1]  R1354     6.5116435289382935e-02
    z[3,2,1]  R1355     2.6427105069160461e-01
    z[3,2,1]  R1356     1.6233828663825989e-01
    z[3,2,1]  R1357     3.5085299611091614e-01
    z[3,2,1]  R1358     3.7565350532531738e-01
    z[3,2,1]  R1359     -6.6838508844375610e-01
    z[3,2,1]  R1360     -7.0583873987197876e-01
    z[3,2,1]  R1361     7.8617835044860840e-01
    z[3,2,1]  R1362     3.8600188493728638e-01
    z[3,2,1]  R1363     2.1506385505199432e-01
    z[3,2,1]  R1364     -7.4995177984237671e-01
    z[3,2,1]  R1365     -5.3873974084854126e-01
    z[3,2,1]  R1366     -6.3138955831527710e-01
    z[3,2,1]  R1367     6.6662716865539551e-01
    z[3,2,1]  R1368     -7.1545474231243134e-02
    z[3,2,1]  R1369     7.5208085775375366e-01
    z[3,2,1]  R1370     6.2472069263458252e-01
    z[3,2,1]  R1371     5.6213027238845825e-01
    z[3,2,1]  R1372     4.2814698815345764e-01
    z[3,2,1]  R1373     6.2551081180572510e-01
    z[3,2,1]  R1374     -3.4972810745239258e-01
    z[3,2,1]  R1375     -2.1696461737155914e-01
    z[3,2,1]  R1376     -4.7060576081275940e-01
    z[3,2,1]  R1377     -1.8660506606101990e-01
    z[3,2,1]  R1378     -2.4373726546764374e-01
    z[3,2,1]  R1379     -1.9525794684886932e-01
    z[3,2,1]  R1380     -4.0694692730903625e-01
    z[3,2,1]  R1381     -3.9544859528541565e-01
    z[3,2,1]  R1382     7.0127922296524048e-01
    z[3,2,1]  R1383     6.4099001884460449e-01
    z[3,2,1]  R1384     -6.8807423114776611e-01
    z[3,2,1]  R1385     -5.1114434003829956e-01
    z[3,2,1]  R1386     3.2021689414978027e-01
    z[3,2,1]  R1387     3.0431634187698364e-01
    z[3,2,1]  R1388     6.7377209663391113e-02
    z[3,2,1]  R1389     1.9425563514232635e-01
    z[3,2,1]  R1390     -2.4642951320856810e-03
    z[3,2,1]  R1391     4.8408966511487961e-02
    z[3,2,1]  R1392     -0.149896040558815
    z[3,2,1]  R1393     6.5576724708080292e-02
    z[3,2,1]  R1394     6.2107443809509277e-01
    z[3,2,1]  R1395     7.3644739389419556e-01
    z[3,2,1]  R1396     7.7415573596954346e-01
    z[3,2,1]  R1397     7.1338462829589844e-01
    z[3,2,1]  R1398     6.2748807668685913e-01
    z[3,2,1]  R1399     4.8782244324684143e-01
    z[3,2,1]  R1400     6.2506145238876343e-01
    z[3,2,1]  R1401     7.5948399305343628e-01
    z[3,2,1]  R1402     7.4792701005935669e-01
    z[3,2,1]  R1403     5.9795522689819336e-01
    z[3,2,1]  R1404     -5.2683621644973755e-01
    z[3,2,1]  R1405     8.2538014650344849e-01
    z[3,2,1]  R1406     2.9217118024826050e-01
    z[3,2,1]  R1407     1.2891595065593719e-01
    z[3,2,1]  R1408     4.1784065961837769e-01
    z[3,2,1]  R1409     4.3310755491256714e-01
    z[3,2,1]  R1410     3.7485957145690918e-01
    z[3,2,1]  R1411     7.1263968944549561e-02
    z[3,2,1]  R1412     1.6778342425823212e-01
    z[3,2,1]  R1413     1.9675391912460327e-01
    z[3,2,1]  R1414     6.7743313312530518e-01
    z[3,2,1]  R1415     2.3330783843994141e-01
    z[3,2,1]  R1416     6.2655168771743774e-01
    z[3,2,1]  R1417     2.1196378767490387e-01
    z[3,2,1]  R1418     5.6680923700332642e-01
    z[3,2,1]  R1419     3.3163674175739288e-02
    z[3,2,1]  R1420     7.7464574575424194e-01
    z[3,2,1]  R1421     8.4533131122589111e-01
    z[3,2,1]  R1422     0.745384931564331
    z[3,2,1]  R1423     7.7667677402496338e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1336     -1
    z[3,2,2]  R1337     1
    z[3,2,2]  R1346     -7.5069051980972290e-01
    z[3,2,2]  R1347     -6.9352585077285767e-01
    z[3,2,2]  R1348     0.0881400927901268
    z[3,2,2]  R1349     -0.616380512714386
    z[3,2,2]  R1350     -0.812161922454834
    z[3,2,2]  R1351     1.8503734469413757e-01
    z[3,2,2]  R1352     3.2529249787330627e-01
    z[3,2,2]  R1353     -2.6412791013717651e-01
    z[3,2,2]  R1354     2.7396348118782043e-01
    z[3,2,2]  R1355     -2.3845118284225464e-01
    z[3,2,2]  R1356     -2.2934272885322571e-02
    z[3,2,2]  R1357     1.7681892216205597e-01
    z[3,2,2]  R1358     5.9974616765975952e-01
    z[3,2,2]  R1359     4.1776421666145325e-01
    z[3,2,2]  R1360     3.7270089983940125e-01
    z[3,2,2]  R1361     -5.5384196341037750e-02
    z[3,2,2]  R1362     4.2232406139373779e-01
    z[3,2,2]  R1363     2.1507011353969574e-01
    z[3,2,2]  R1364     -1.7446257174015045e-01
    z[3,2,2]  R1365     -5.5856686085462570e-02
    z[3,2,2]  R1366     8.0902762711048126e-03
    z[3,2,2]  R1367     -1.5333354473114014e-01
    z[3,2,2]  R1368     1.4602917432785034e-01
    z[3,2,2]  R1369     2.9094228148460388e-01
    z[3,2,2]  R1370     3.6671683192253113e-01
    z[3,2,2]  R1371     4.8931926488876343e-01
    z[3,2,2]  R1372     2.4885062873363495e-01
    z[3,2,2]  R1373     -0.0532621331512928
    z[3,2,2]  R1374     -4.9553540349006653e-01
    z[3,2,2]  R1375     -6.0714691877365112e-01
    z[3,2,2]  R1376     -2.7851250767707825e-01
    z[3,2,2]  R1377     -5.6539791822433472e-01
    z[3,2,2]  R1378     -3.0870464444160461e-01
    z[3,2,2]  R1379     0.218109130859375
    z[3,2,2]  R1380     -6.6253411769866943e-01
    z[3,2,2]  R1381     9.3164056539535522e-02
    z[3,2,2]  R1382     -3.3220261335372925e-01
    z[3,2,2]  R1383     3.8047355413436890e-01
    z[3,2,2]  R1384     2.3348897695541382e-01
    z[3,2,2]  R1385     2.8866133093833923e-01
    z[3,2,2]  R1386     6.9517545402050018e-02
    z[3,2,2]  R1387     4.1357865929603577e-01
    z[3,2,2]  R1388     5.2172702550888062e-01
    z[3,2,2]  R1389     -6.8027332425117493e-02
    z[3,2,2]  R1390     4.4569137692451477e-01
    z[3,2,2]  R1391     5.8127278089523315e-01
    z[3,2,2]  R1392     1.4774306118488312e-01
    z[3,2,2]  R1393     1.8644580245018005e-01
    z[3,2,2]  R1394     -6.2145132571458817e-02
    z[3,2,2]  R1395     8.5463829338550568e-02
    z[3,2,2]  R1396     -5.0757521390914917e-01
    z[3,2,2]  R1397     -8.5780851542949677e-02
    z[3,2,2]  R1398     3.4224835038185120e-01
    z[3,2,2]  R1399     4.2534321546554565e-01
    z[3,2,2]  R1400     -1.3075712323188782e-01
    z[3,2,2]  R1401     -3.8576906919479370e-01
    z[3,2,2]  R1402     2.0400781184434891e-02
    z[3,2,2]  R1403     2.0019893348217010e-01
    z[3,2,2]  R1404     1.3905979692935944e-01
    z[3,2,2]  R1405     -0.289896696805954
    z[3,2,2]  R1406     5.9983348846435547e-01
    z[3,2,2]  R1407     5.6533169746398926e-01
    z[3,2,2]  R1408     3.3473175764083862e-01
    z[3,2,2]  R1409     0.591620922088623
    z[3,2,2]  R1410     6.4955705404281616e-01
    z[3,2,2]  R1411     4.2200678586959839e-01
    z[3,2,2]  R1412     3.4381836652755737e-01
    z[3,2,2]  R1413     7.5425392389297485e-01
    z[3,2,2]  R1414     1.3663128018379211e-01
    z[3,2,2]  R1415     2.3372364044189453e-01
    z[3,2,2]  R1416     -2.8846305608749390e-01
    z[3,2,2]  R1417     4.8309543728828430e-01
    z[3,2,2]  R1418     -2.6111856102943420e-01
    z[3,2,2]  R1419     -0.0473548024892807
    z[3,2,2]  R1420     4.2363476008176804e-02
    z[3,2,2]  R1421     1.9885657727718353e-01
    z[3,2,2]  R1422     -1.9453147053718567e-01
    z[3,2,2]  R1423     3.3912059664726257e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1338     -1
    z[3,2,3]  R1339     1
    z[3,2,3]  R1346     -2.0729070529341698e-02
    z[3,2,3]  R1347     1.4990265481173992e-02
    z[3,2,3]  R1348     8.1128489971160889e-01
    z[3,2,3]  R1349     2.8460944071412086e-02
    z[3,2,3]  R1350     2.4128781259059906e-01
    z[3,2,3]  R1351     5.1792770624160767e-01
    z[3,2,3]  R1352     5.9925496578216553e-01
    z[3,2,3]  R1353     5.5411982536315918e-01
    z[3,2,3]  R1354     4.8862314224243164e-01
    z[3,2,3]  R1355     4.1310253739356995e-01
    z[3,2,3]  R1356     -6.5624141693115234e-01
    z[3,2,3]  R1357     -5.3472006320953369e-01
    z[3,2,3]  R1358     -0.647748589515686
    z[3,2,3]  R1359     -3.3803331851959229e-01
    z[3,2,3]  R1360     2.0410838723182678e-01
    z[3,2,3]  R1361     3.1497529149055481e-01
    z[3,2,3]  R1362     2.0240074396133423e-01
    z[3,2,3]  R1363     3.8643366098403931e-01
    z[3,2,3]  R1364     2.1542568504810333e-01
    z[3,2,3]  R1365     -0.577997088432312
    z[3,2,3]  R1366     -6.2361329793930054e-01
    z[3,2,3]  R1367     -5.4922294616699219e-01
    z[3,2,3]  R1368     -6.4651709794998169e-01
    z[3,2,3]  R1369     4.4862103462219238e-01
    z[3,2,3]  R1370     4.9435773491859436e-01
    z[3,2,3]  R1371     4.2824935913085938e-01
    z[3,2,3]  R1372     6.4358937740325928e-01
    z[3,2,3]  R1373     5.6243580579757690e-01
    z[3,2,3]  R1374     4.6444028615951538e-01
    z[3,2,3]  R1375     1.4665301144123077e-01
    z[3,2,3]  R1376     5.9248123317956924e-02
    z[3,2,3]  R1377     -0.0647757425904274
    z[3,2,3]  R1378     -3.3503524959087372e-02
    z[3,2,3]  R1379     3.0617249011993408e-01
    z[3,2,3]  R1380     -1.5060655772686005e-01
    z[3,2,3]  R1381     -3.7506937980651855e-01
    z[3,2,3]  R1382     4.7289678454399109e-01
    z[3,2,3]  R1383     5.9952370822429657e-02
    z[3,2,3]  R1384     2.2570972144603729e-01
    z[3,2,3]  R1385     -4.0436097979545593e-01
    z[3,2,3]  R1386     1.4787705242633820e-01
    z[3,2,3]  R1387     3.8220247626304626e-01
    z[3,2,3]  R1388     3.7393602728843689e-01
    z[3,2,3]  R1389     2.1852149069309235e-01
    z[3,2,3]  R1390     4.2644214630126953e-01
    z[3,2,3]  R1391     3.7610808014869690e-01
    z[3,2,3]  R1392     4.6936103701591492e-01
    z[3,2,3]  R1393     3.8113737106323242e-01
    z[3,2,3]  R1394     0.458217054605484
    z[3,2,3]  R1395     3.4837085008621216e-01
    z[3,2,3]  R1396     1.8025636672973633e-01
    z[3,2,3]  R1397     2.6481881737709045e-01
    z[3,2,3]  R1398     4.5567402243614197e-01
    z[3,2,3]  R1399     4.8127308487892151e-02
    z[3,2,3]  R1400     7.1094882488250732e-01
    z[3,2,3]  R1401     -1.1758894473314285e-01
    z[3,2,3]  R1402     -3.3963659405708313e-01
    z[3,2,3]  R1403     -1.1370488256216049e-01
    z[3,2,3]  R1404     -4.8172511160373688e-02
    z[3,2,3]  R1405     3.3632761240005493e-01
    z[3,2,3]  R1406     1.5562395751476288e-01
    z[3,2,3]  R1407     2.5202763080596924e-01
    z[3,2,3]  R1408     -9.6530042588710785e-02
    z[3,2,3]  R1409     9.2465788125991821e-02
    z[3,2,3]  R1410     0.26992267370224
    z[3,2,3]  R1411     2.6868173480033875e-01
    z[3,2,3]  R1412     4.7727242112159729e-01
    z[3,2,3]  R1413     4.0019545704126358e-02
    z[3,2,3]  R1414     4.2768466472625732e-01
    z[3,2,3]  R1415     -9.6108177676796913e-03
    z[3,2,3]  R1416     4.9866217374801636e-01
    z[3,2,3]  R1417     2.4773922562599182e-01
    z[3,2,3]  R1418     2.5836622714996338e-01
    z[3,2,3]  R1419     -9.5853674411773682e-01
    z[3,2,3]  R1420     -3.4687477350234985e-01
    z[3,2,3]  R1421     -1.3818985223770142e-01
    z[3,2,3]  R1422     -3.8389381766319275e-01
    z[3,2,3]  R1423     -2.2529102861881256e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1340     -1
    z[3,2,4]  R1341     1
    z[3,2,4]  R1346     -3.1282356381416321e-01
    z[3,2,4]  R1347     -4.0590861439704895e-01
    z[3,2,4]  R1348     -9.7965687513351440e-02
    z[3,2,4]  R1349     3.0620750784873962e-01
    z[3,2,4]  R1350     5.2551679313182831e-02
    z[3,2,4]  R1351     2.1951572597026825e-01
    z[3,2,4]  R1352     -1.1212415993213654e-01
    z[3,2,4]  R1353     1.7882628738880157e-01
    z[3,2,4]  R1354     8.6182296276092529e-02
    z[3,2,4]  R1355     -3.7112173438072205e-01
    z[3,2,4]  R1356     3.5811313986778259e-01
    z[3,2,4]  R1357     -6.5637670457363129e-02
    z[3,2,4]  R1358     -3.3531852066516876e-02
    z[3,2,4]  R1359     1.4174060523509979e-01
    z[3,2,4]  R1360     0.177893728017807
    z[3,2,4]  R1361     -1.0606989264488220e-01
    z[3,2,4]  R1362     -7.3660008609294891e-02
    z[3,2,4]  R1363     2.4465283751487732e-01
    z[3,2,4]  R1364     1.2989516369998455e-02
    z[3,2,4]  R1365     9.4605013728141785e-02
    z[3,2,4]  R1366     3.4848979115486145e-01
    z[3,2,4]  R1367     -3.3763018250465393e-01
    z[3,2,4]  R1368     -1.6866831481456757e-01
    z[3,2,4]  R1369     -7.3030188679695129e-02
    z[3,2,4]  R1370     -1.4280991256237030e-01
    z[3,2,4]  R1371     -5.0838004797697067e-02
    z[3,2,4]  R1372     1.5157523751258850e-01
    z[3,2,4]  R1373     1.3655400276184082e-01
    z[3,2,4]  R1374     -2.8815552592277527e-01
    z[3,2,4]  R1375     -6.5752822160720825e-01
    z[3,2,4]  R1376     -1.6028371453285217e-01
    z[3,2,4]  R1377     -2.5635886192321777e-01
    z[3,2,4]  R1378     1.1484770476818085e-01
    z[3,2,4]  R1379     -7.2272044420242310e-01
    z[3,2,4]  R1380     2.5529885292053223e-01
    z[3,2,4]  R1381     -4.5813828706741333e-01
    z[3,2,4]  R1382     2.7722854167222977e-02
    z[3,2,4]  R1383     -0.244576096534729
    z[3,2,4]  R1384     4.5235726237297058e-01
    z[3,2,4]  R1385     3.4507265686988831e-01
    z[3,2,4]  R1386     -1.8130175769329071e-01
    z[3,2,4]  R1387     1.6281618177890778e-01
    z[3,2,4]  R1388     -1.6976632177829742e-02
    z[3,2,4]  R1389     1.7127616703510284e-01
    z[3,2,4]  R1390     -3.7139128893613815e-02
    z[3,2,4]  R1391     4.7775000333786011e-01
    z[3,2,4]  R1392     -1.0041683167219162e-01
    z[3,2,4]  R1393     4.6058148145675659e-01
    z[3,2,4]  R1394     -1.5805619955062866e-01
    z[3,2,4]  R1395     2.7727490663528442e-01
    z[3,2,4]  R1396     1.8001537770032883e-02
    z[3,2,4]  R1397     -1.9209538400173187e-01
    z[3,2,4]  R1398     -8.6982309818267822e-02
    z[3,2,4]  R1399     4.2937391996383667e-01
    z[3,2,4]  R1400     3.4035738557577133e-02
    z[3,2,4]  R1401     3.4835720062255859e-01
    z[3,2,4]  R1402     2.7765345573425293e-01
    z[3,2,4]  R1403     3.1549766659736633e-01
    z[3,2,4]  R1404     1.4113017916679382e-01
    z[3,2,4]  R1405     -7.2040654718875885e-02
    z[3,2,4]  R1406     4.3641266226768494e-01
    z[3,2,4]  R1407     -1.7879876494407654e-01
    z[3,2,4]  R1408     -0.354126900434494
    z[3,2,4]  R1409     -3.4630599617958069e-01
    z[3,2,4]  R1410     -0.170893132686615
    z[3,2,4]  R1411     3.4464788436889648e-01
    z[3,2,4]  R1412     2.5045084953308105e-01
    z[3,2,4]  R1413     -3.4921568632125854e-01
    z[3,2,4]  R1414     0.0611988827586174
    z[3,2,4]  R1415     1.4504013955593109e-01
    z[3,2,4]  R1416     1.7014007270336151e-01
    z[3,2,4]  R1417     -8.7398067116737366e-02
    z[3,2,4]  R1418     2.2325593233108521e-01
    z[3,2,4]  R1419     -5.8964673429727554e-02
    z[3,2,4]  R1420     9.7499601542949677e-02
    z[3,2,4]  R1421     -7.8991755843162537e-02
    z[3,2,4]  R1422     -4.2591953277587891e-01
    z[3,2,4]  R1423     -1.2765172123908997e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1342     -1
    z[3,2,5]  R1343     1
    z[3,2,5]  R1346     0.261923223733902
    z[3,2,5]  R1347     2.3837955296039581e-01
    z[3,2,5]  R1348     1.7931589484214783e-01
    z[3,2,5]  R1349     9.4692386686801910e-02
    z[3,2,5]  R1350     1.1864223517477512e-02
    z[3,2,5]  R1351     9.2396877706050873e-02
    z[3,2,5]  R1352     -2.9577752947807312e-01
    z[3,2,5]  R1353     4.6932362020015717e-03
    z[3,2,5]  R1354     3.8095137476921082e-01
    z[3,2,5]  R1355     -0.177132248878479
    z[3,2,5]  R1356     -4.0599358081817627e-01
    z[3,2,5]  R1357     -4.4231596589088440e-01
    z[3,2,5]  R1358     -1.8506981432437897e-02
    z[3,2,5]  R1359     4.2402917146682739e-01
    z[3,2,5]  R1360     9.0337663888931274e-02
    z[3,2,5]  R1361     -3.2538047432899475e-01
    z[3,2,5]  R1362     -4.9688392877578735e-01
    z[3,2,5]  R1363     -6.4921134710311890e-01
    z[3,2,5]  R1364     9.4749532639980316e-02
    z[3,2,5]  R1365     -6.7315645515918732e-02
    z[3,2,5]  R1366     4.0143728256225586e-03
    z[3,2,5]  R1367     1.2150320410728455e-01
    z[3,2,5]  R1368     0.606165885925293
    z[3,2,5]  R1369     -2.0348009467124939e-01
    z[3,2,5]  R1370     -2.7250227332115173e-01
    z[3,2,5]  R1371     -4.1970375180244446e-01
    z[3,2,5]  R1372     -1.8364740908145905e-01
    z[3,2,5]  R1373     -2.4095095694065094e-01
    z[3,2,5]  R1374     -2.2357408702373505e-01
    z[3,2,5]  R1375     -1.5324714593589306e-02
    z[3,2,5]  R1376     6.0758337378501892e-02
    z[3,2,5]  R1377     -1.7199523746967316e-01
    z[3,2,5]  R1378     8.3132229745388031e-02
    z[3,2,5]  R1379     -1.2672264873981476e-01
    z[3,2,5]  R1380     -1.5328468382358551e-01
    z[3,2,5]  R1381     1.7406722903251648e-01
    z[3,2,5]  R1382     -4.0122276544570923e-01
    z[3,2,5]  R1383     -1.0973126441240311e-01
    z[3,2,5]  R1384     4.1944679617881775e-01
    z[3,2,5]  R1385     4.6755722165107727e-01
    z[3,2,5]  R1386     -2.3887167870998383e-01
    z[3,2,5]  R1387     -3.8349515199661255e-01
    z[3,2,5]  R1388     -3.8785532116889954e-01
    z[3,2,5]  R1389     -4.1204899549484253e-01
    z[3,2,5]  R1390     -2.7068731188774109e-01
    z[3,2,5]  R1391     -2.9718539118766785e-01
    z[3,2,5]  R1392     -1.3412435352802277e-01
    z[3,2,5]  R1393     -0.412482887506485
    z[3,2,5]  R1394     4.7123548574745655e-03
    z[3,2,5]  R1395     -2.1599614620208740e-01
    z[3,2,5]  R1396     -1.2933824956417084e-01
    z[3,2,5]  R1397     -3.5681214928627014e-01
    z[3,2,5]  R1398     -2.7933532372117043e-02
    z[3,2,5]  R1399     -3.3970877528190613e-01
    z[3,2,5]  R1400     -1.4171645045280457e-01
    z[3,2,5]  R1401     9.4780838117003441e-03
    z[3,2,5]  R1402     -1.3779945671558380e-01
    z[3,2,5]  R1403     -0.00695176562294364
    z[3,2,5]  R1404     5.6822425127029419e-01
    z[3,2,5]  R1405     -3.5686764866113663e-02
    z[3,2,5]  R1406     -3.5881036520004272e-01
    z[3,2,5]  R1407     -1.4847515523433685e-01
    z[3,2,5]  R1408     -1.2488958239555359e-01
    z[3,2,5]  R1409     -2.6262101531028748e-01
    z[3,2,5]  R1410     -3.7424251437187195e-01
    z[3,2,5]  R1411     -5.8189444243907928e-02
    z[3,2,5]  R1412     -5.7193273305892944e-01
    z[3,2,5]  R1413     -1.0489203967154026e-02
    z[3,2,5]  R1414     1.4155525714159012e-02
    z[3,2,5]  R1415     -2.0045363903045654e-01
    z[3,2,5]  R1416     3.1995948404073715e-02
    z[3,2,5]  R1417     -3.4491837024688721e-01
    z[3,2,5]  R1418     1.4150644652545452e-02
    z[3,2,5]  R1419     -2.5481337308883667e-01
    z[3,2,5]  R1420     -2.1574825223069638e-04
    z[3,2,5]  R1421     -0.0421307310461998
    z[3,2,5]  R1422     -1.0680418461561203e-01
    z[3,2,5]  R1423     -4.5179602503776550e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1344     -1
    z[3,2,6]  R1345     1
    z[3,2,6]  R1346     -4.6462330222129822e-01
    z[3,2,6]  R1347     1.1685429513454437e-01
    z[3,2,6]  R1348     -1.9126628339290619e-01
    z[3,2,6]  R1349     3.5401052236557007e-01
    z[3,2,6]  R1350     3.8285449147224426e-01
    z[3,2,6]  R1351     -1.8760672211647034e-01
    z[3,2,6]  R1352     1.0930579155683517e-01
    z[3,2,6]  R1353     2.7533236145973206e-01
    z[3,2,6]  R1354     3.6939746141433716e-01
    z[3,2,6]  R1355     -1.2873359024524689e-01
    z[3,2,6]  R1356     -3.2803854346275330e-01
    z[3,2,6]  R1357     5.7653826475143433e-01
    z[3,2,6]  R1358     2.6257598400115967e-01
    z[3,2,6]  R1359     -2.5008264183998108e-01
    z[3,2,6]  R1360     -4.4959101080894470e-01
    z[3,2,6]  R1361     -7.3776558041572571e-02
    z[3,2,6]  R1362     -0.460621178150177
    z[3,2,6]  R1363     2.7532455325126648e-01
    z[3,2,6]  R1364     -1.4251363277435303e-01
    z[3,2,6]  R1365     -4.3673881888389587e-01
    z[3,2,6]  R1366     2.0005346834659576e-01
    z[3,2,6]  R1367     2.4210794270038605e-01
    z[3,2,6]  R1368     -9.9951634183526039e-03
    z[3,2,6]  R1369     5.6434098631143570e-02
    z[3,2,6]  R1370     -3.3775623887777328e-03
    z[3,2,6]  R1371     7.0777930319309235e-02
    z[3,2,6]  R1372     7.0458851754665375e-02
    z[3,2,6]  R1373     -1.7986442148685455e-01
    z[3,2,6]  R1374     2.0618361234664917e-01
    z[3,2,6]  R1375     7.9898700118064880e-02
    z[3,2,6]  R1376     -4.2748656868934631e-01
    z[3,2,6]  R1377     -5.4689103364944458e-01
    z[3,2,6]  R1378     9.6865154802799225e-02
    z[3,2,6]  R1379     -2.4084423482418060e-01
    z[3,2,6]  R1380     4.4141769409179688e-02
    z[3,2,6]  R1381     0.554288387298584
    z[3,2,6]  R1382     1.9463993608951569e-02
    z[3,2,6]  R1383     -4.3386835604906082e-02
    z[3,2,6]  R1384     9.0318925678730011e-02
    z[3,2,6]  R1385     -3.1461721658706665e-01
    z[3,2,6]  R1386     1.3393911719322205e-01
    z[3,2,6]  R1387     3.7313720583915710e-01
    z[3,2,6]  R1388     -3.3675307035446167e-01
    z[3,2,6]  R1389     -1.3031649589538574e-01
    z[3,2,6]  R1390     -1.1199028044939041e-01
    z[3,2,6]  R1391     2.5821531191468239e-02
    z[3,2,6]  R1392     1.0259898751974106e-01
    z[3,2,6]  R1393     -1.1703076772391796e-02
    z[3,2,6]  R1394     -6.8860031664371490e-02
    z[3,2,6]  R1395     6.1053719371557236e-02
    z[3,2,6]  R1396     -1.2132717669010162e-01
    z[3,2,6]  R1397     -1.4700870215892792e-01
    z[3,2,6]  R1398     1.1287894845008850e-01
    z[3,2,6]  R1399     1.7166174948215485e-01
    z[3,2,6]  R1400     -2.1472658216953278e-01
    z[3,2,6]  R1401     2.6899653673171997e-01
    z[3,2,6]  R1402     3.5283237695693970e-01
    z[3,2,6]  R1403     -3.9568844437599182e-01
    z[3,2,6]  R1404     -2.1786986291408539e-01
    z[3,2,6]  R1405     2.9088482260704041e-01
    z[3,2,6]  R1406     -1.3363888859748840e-01
    z[3,2,6]  R1407     -9.8918646574020386e-02
    z[3,2,6]  R1408     -1.7414465546607971e-01
    z[3,2,6]  R1409     -7.7840596437454224e-02
    z[3,2,6]  R1410     0.026185292750597
    z[3,2,6]  R1411     3.1590768694877625e-01
    z[3,2,6]  R1412     -3.5322561860084534e-02
    z[3,2,6]  R1413     -2.4731151759624481e-01
    z[3,2,6]  R1414     -3.6526456475257874e-01
    z[3,2,6]  R1415     -3.2610824704170227e-01
    z[3,2,6]  R1416     -3.1757766008377075e-01
    z[3,2,6]  R1417     -2.6561614871025085e-01
    z[3,2,6]  R1418     0.147373765707016
    z[3,2,6]  R1419     9.7242005169391632e-02
    z[3,2,6]  R1420     1.4258872717618942e-02
    z[3,2,6]  R1421     3.4969004988670349e-01
    z[3,2,6]  R1422     -1.5640050172805786e-01
    z[3,2,6]  R1423     -1.0230807214975357e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1424     -1
    z[3,4,0]  R1425     1
    z[3,4,0]  R1438     -3.8177676498889923e-02
    z[3,4,0]  R1439     4.8281392455101013e-01
    z[3,4,0]  R1440     -5.0466382503509521e-01
    z[3,4,0]  R1441     -5.7353466749191284e-01
    z[3,4,0]  R1442     1.0525610297918320e-01
    z[3,4,0]  R1443     -7.7337872982025146e-01
    z[3,4,0]  R1444     -6.4111167192459106e-01
    z[3,4,0]  R1445     -6.9564241170883179e-01
    z[3,4,0]  R1446     -6.2685352563858032e-01
    z[3,4,0]  R1447     -0.719005286693573
    z[3,4,0]  R1448     -3.7654018402099609e-01
    z[3,4,0]  R1449     1.6541968286037445e-01
    z[3,4,0]  R1450     9.5905058085918427e-02
    z[3,4,0]  R1451     -4.5115888118743896e-02
    z[3,4,0]  R1452     2.8157824277877808e-01
    z[3,4,0]  R1453     3.9633381366729736e-01
    z[3,4,0]  R1454     4.0888580679893494e-01
    z[3,4,0]  R1455     4.4836091995239258e-01
    z[3,4,0]  R1456     0.575560986995697
    z[3,4,0]  R1457     4.1028848290443420e-01
    z[3,4,0]  R1458     2.2562281787395477e-01
    z[3,4,0]  R1459     -2.0755213499069214e-01
    z[3,4,0]  R1460     -3.9948263764381409e-01
    z[3,4,0]  R1461     3.1391668319702148e-01
    z[3,4,0]  R1462     3.6903870105743408e-01
    z[3,4,0]  R1463     2.7826866507530212e-01
    z[3,4,0]  R1464     5.2810066938400269e-01
    z[3,4,0]  R1465     4.2486450076103210e-01
    z[3,4,0]  R1466     -5.2687013149261475e-01
    z[3,4,0]  R1467     -3.8885253667831421e-01
    z[3,4,0]  R1468     -2.4269014596939087e-01
    z[3,4,0]  R1469     -2.4279505014419556e-01
    z[3,4,0]  R1470     -6.4317220449447632e-01
    z[3,4,0]  R1471     -6.3531851768493652e-01
    z[3,4,0]  R1472     -5.0438493490219116e-01
    z[3,4,0]  R1473     -0.51566481590271
    z[3,4,0]  R1474     -3.3373662829399109e-01
    z[3,4,0]  R1475     -8.7058585882186890e-01
    z[3,4,0]  R1476     3.5148042440414429e-01
    z[3,4,0]  R1477     4.7380456328392029e-01
    z[3,4,0]  R1478     6.3418948650360107e-01
    z[3,4,0]  R1479     3.3327743411064148e-01
    z[3,4,0]  R1480     3.6435019969940186e-01
    z[3,4,0]  R1481     3.3907625079154968e-01
    z[3,4,0]  R1482     3.4834814071655273e-01
    z[3,4,0]  R1483     1.4997689425945282e-01
    z[3,4,0]  R1484     3.4531596302986145e-01
    z[3,4,0]  R1485     -2.4426843225955963e-01
    z[3,4,0]  R1486     2.2999662160873413e-01
    z[3,4,0]  R1487     -7.7903396449983120e-03
    z[3,4,0]  R1488     3.0323010683059692e-01
    z[3,4,0]  R1489     4.4778436422348022e-01
    z[3,4,0]  R1490     1.1714530736207962e-01
    z[3,4,0]  R1491     2.7664223313331604e-01
    z[3,4,0]  R1492     1.6158106923103333e-01
    z[3,4,0]  R1493     1.1710673570632935e-01
    z[3,4,0]  R1494     5.9388820081949234e-02
    z[3,4,0]  R1495     6.7244619131088257e-02
    z[3,4,0]  R1496     -7.2806432843208313e-02
    z[3,4,0]  R1497     3.0438588932156563e-02
    z[3,4,0]  R1498     -2.0102904736995697e-01
    z[3,4,0]  R1499     2.8570486232638359e-02
    z[3,4,0]  R1500     6.5622992813587189e-02
    z[3,4,0]  R1501     3.4725448489189148e-01
    z[3,4,0]  R1502     9.2229962348937988e-02
    z[3,4,0]  R1503     4.8041760921478271e-01
    z[3,4,0]  R1504     5.3070294857025146e-01
    z[3,4,0]  R1505     -1.5743415057659149e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1426     -1
    z[3,4,1]  R1427     1
    z[3,4,1]  R1438     -2.2855930030345917e-01
    z[3,4,1]  R1439     -2.2460272908210754e-01
    z[3,4,1]  R1440     3.2066803425550461e-02
    z[3,4,1]  R1441     -2.4953939020633698e-01
    z[3,4,1]  R1442     -3.4873235225677490e-01
    z[3,4,1]  R1443     8.6467780172824860e-02
    z[3,4,1]  R1444     1.0977321863174438e-01
    z[3,4,1]  R1445     1.7737165093421936e-01
    z[3,4,1]  R1446     6.5116435289382935e-02
    z[3,4,1]  R1447     2.6427105069160461e-01
    z[3,4,1]  R1448     1.6233828663825989e-01
    z[3,4,1]  R1449     3.5085299611091614e-01
    z[3,4,1]  R1450     3.7565350532531738e-01
    z[3,4,1]  R1451     -6.6838508844375610e-01
    z[3,4,1]  R1452     -7.0583873987197876e-01
    z[3,4,1]  R1453     7.8617835044860840e-01
    z[3,4,1]  R1454     3.8600188493728638e-01
    z[3,4,1]  R1455     2.1506385505199432e-01
    z[3,4,1]  R1456     -7.4995177984237671e-01
    z[3,4,1]  R1457     -5.3873974084854126e-01
    z[3,4,1]  R1458     -6.3138955831527710e-01
    z[3,4,1]  R1459     6.6662716865539551e-01
    z[3,4,1]  R1460     -7.1545474231243134e-02
    z[3,4,1]  R1461     7.5208085775375366e-01
    z[3,4,1]  R1462     6.2472069263458252e-01
    z[3,4,1]  R1463     5.6213027238845825e-01
    z[3,4,1]  R1464     4.2814698815345764e-01
    z[3,4,1]  R1465     6.2551081180572510e-01
    z[3,4,1]  R1466     -4.7371357679367065e-02
    z[3,4,1]  R1467     4.9620330333709717e-01
    z[3,4,1]  R1468     0.249917671084404
    z[3,4,1]  R1469     1.2432807683944702e-01
    z[3,4,1]  R1470     6.3261699676513672e-01
    z[3,4,1]  R1471     1.8798816204071045e-01
    z[3,4,1]  R1472     1.8632699549198151e-01
    z[3,4,1]  R1473     1.9373770058155060e-01
    z[3,4,1]  R1474     5.3115576505661011e-01
    z[3,4,1]  R1475     -7.9930663108825684e-02
    z[3,4,1]  R1476     -1.1468087136745453e-01
    z[3,4,1]  R1477     -2.5782150030136108e-01
    z[3,4,1]  R1478     -1.1214705556631088e-01
    z[3,4,1]  R1479     -1.4951537549495697e-01
    z[3,4,1]  R1480     5.5012357234954834e-01
    z[3,4,1]  R1481     -9.5172375440597534e-02
    z[3,4,1]  R1482     5.0524824857711792e-01
    z[3,4,1]  R1483     -2.2338593006134033e-01
    z[3,4,1]  R1484     3.0758830904960632e-01
    z[3,4,1]  R1485     0.155996635556221
    z[3,4,1]  R1486     -6.5523695945739746e-01
    z[3,4,1]  R1487     -0.941007137298584
    z[3,4,1]  R1488     -7.8983032703399658e-01
    z[3,4,1]  R1489     7.2181189060211182e-01
    z[3,4,1]  R1490     0.701270580291748
    z[3,4,1]  R1491     5.3694558143615723e-01
    z[3,4,1]  R1492     -3.7327718734741211e-01
    z[3,4,1]  R1493     -8.3622777462005615e-01
    z[3,4,1]  R1494     -8.0783206224441528e-01
    z[3,4,1]  R1495     -8.1421262025833130e-01
    z[3,4,1]  R1496     -5.7421392202377319e-01
    z[3,4,1]  R1497     -5.5053830146789551e-01
    z[3,4,1]  R1498     -6.1403536796569824e-01
    z[3,4,1]  R1499     -7.8212535381317139e-01
    z[3,4,1]  R1500     7.3139268159866333e-01
    z[3,4,1]  R1501     -1.6193135082721710e-01
    z[3,4,1]  R1502     -7.0713929831981659e-02
    z[3,4,1]  R1503     -1.5904399752616882e-01
    z[3,4,1]  R1504     0.622560441493988
    z[3,4,1]  R1505     -0.65133136510849
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1428     -1
    z[3,4,2]  R1429     1
    z[3,4,2]  R1438     -7.5069051980972290e-01
    z[3,4,2]  R1439     -6.9352585077285767e-01
    z[3,4,2]  R1440     0.0881400927901268
    z[3,4,2]  R1441     -0.616380512714386
    z[3,4,2]  R1442     -0.812161922454834
    z[3,4,2]  R1443     1.8503734469413757e-01
    z[3,4,2]  R1444     3.2529249787330627e-01
    z[3,4,2]  R1445     -2.6412791013717651e-01
    z[3,4,2]  R1446     2.7396348118782043e-01
    z[3,4,2]  R1447     -2.3845118284225464e-01
    z[3,4,2]  R1448     -2.2934272885322571e-02
    z[3,4,2]  R1449     1.7681892216205597e-01
    z[3,4,2]  R1450     5.9974616765975952e-01
    z[3,4,2]  R1451     4.1776421666145325e-01
    z[3,4,2]  R1452     3.7270089983940125e-01
    z[3,4,2]  R1453     -5.5384196341037750e-02
    z[3,4,2]  R1454     4.2232406139373779e-01
    z[3,4,2]  R1455     2.1507011353969574e-01
    z[3,4,2]  R1456     -1.7446257174015045e-01
    z[3,4,2]  R1457     -5.5856686085462570e-02
    z[3,4,2]  R1458     8.0902762711048126e-03
    z[3,4,2]  R1459     -1.5333354473114014e-01
    z[3,4,2]  R1460     1.4602917432785034e-01
    z[3,4,2]  R1461     2.9094228148460388e-01
    z[3,4,2]  R1462     3.6671683192253113e-01
    z[3,4,2]  R1463     4.8931926488876343e-01
    z[3,4,2]  R1464     2.4885062873363495e-01
    z[3,4,2]  R1465     -0.0532621331512928
    z[3,4,2]  R1466     3.8109385967254639e-01
    z[3,4,2]  R1467     -9.2280693352222443e-02
    z[3,4,2]  R1468     -1.6449901461601257e-01
    z[3,4,2]  R1469     1.3156543672084808e-01
    z[3,4,2]  R1470     -2.0533861592411995e-02
    z[3,4,2]  R1471     1.7293557524681091e-01
    z[3,4,2]  R1472     -4.6211230754852295e-01
    z[3,4,2]  R1473     -9.1871142387390137e-02
    z[3,4,2]  R1474     2.2585256025195122e-02
    z[3,4,2]  R1475     -0.323942631483078
    z[3,4,2]  R1476     -7.6226669549942017e-01
    z[3,4,2]  R1477     -0.715878427028656
    z[3,4,2]  R1478     -7.0156681537628174e-01
    z[3,4,2]  R1479     -5.8445763587951660e-01
    z[3,4,2]  R1480     -1.9999657571315765e-01
    z[3,4,2]  R1481     -8.4788095951080322e-01
    z[3,4,2]  R1482     7.7022358775138855e-02
    z[3,4,2]  R1483     -5.7364231348037720e-01
    z[3,4,2]  R1484     -6.5900450944900513e-01
    z[3,4,2]  R1485     -0.00027977250283584
    z[3,4,2]  R1486     -2.8405159711837769e-01
    z[3,4,2]  R1487     -2.5056964159011841e-01
    z[3,4,2]  R1488     -2.8313216567039490e-01
    z[3,4,2]  R1489     3.5051146149635315e-01
    z[3,4,2]  R1490     2.1773280203342438e-01
    z[3,4,2]  R1491     0.0203268900513649
    z[3,4,2]  R1492     -7.4416553974151611e-01
    z[3,4,2]  R1493     -1.0377339087426662e-02
    z[3,4,2]  R1494     -1.9353257119655609e-01
    z[3,4,2]  R1495     3.7098485231399536e-01
    z[3,4,2]  R1496     -5.7792204618453979e-01
    z[3,4,2]  R1497     -6.0849994421005249e-01
    z[3,4,2]  R1498     -0.646791398525238
    z[3,4,2]  R1499     -5.6640064716339111e-01
    z[3,4,2]  R1500     -2.0056138932704926e-01
    z[3,4,2]  R1501     -6.0195660591125488e-01
    z[3,4,2]  R1502     -7.5881606340408325e-01
    z[3,4,2]  R1503     -7.5291055440902710e-01
    z[3,4,2]  R1504     -3.8880684971809387e-01
    z[3,4,2]  R1505     1.8105547130107880e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1430     -1
    z[3,4,3]  R1431     1
    z[3,4,3]  R1438     -2.0729070529341698e-02
    z[3,4,3]  R1439     1.4990265481173992e-02
    z[3,4,3]  R1440     8.1128489971160889e-01
    z[3,4,3]  R1441     2.8460944071412086e-02
    z[3,4,3]  R1442     2.4128781259059906e-01
    z[3,4,3]  R1443     5.1792770624160767e-01
    z[3,4,3]  R1444     5.9925496578216553e-01
    z[3,4,3]  R1445     5.5411982536315918e-01
    z[3,4,3]  R1446     4.8862314224243164e-01
    z[3,4,3]  R1447     4.1310253739356995e-01
    z[3,4,3]  R1448     -6.5624141693115234e-01
    z[3,4,3]  R1449     -5.3472006320953369e-01
    z[3,4,3]  R1450     -0.647748589515686
    z[3,4,3]  R1451     -3.3803331851959229e-01
    z[3,4,3]  R1452     2.0410838723182678e-01
    z[3,4,3]  R1453     3.1497529149055481e-01
    z[3,4,3]  R1454     2.0240074396133423e-01
    z[3,4,3]  R1455     3.8643366098403931e-01
    z[3,4,3]  R1456     2.1542568504810333e-01
    z[3,4,3]  R1457     -0.577997088432312
    z[3,4,3]  R1458     -6.2361329793930054e-01
    z[3,4,3]  R1459     -5.4922294616699219e-01
    z[3,4,3]  R1460     -6.4651709794998169e-01
    z[3,4,3]  R1461     4.4862103462219238e-01
    z[3,4,3]  R1462     4.9435773491859436e-01
    z[3,4,3]  R1463     4.2824935913085938e-01
    z[3,4,3]  R1464     6.4358937740325928e-01
    z[3,4,3]  R1465     5.6243580579757690e-01
    z[3,4,3]  R1466     7.5379502773284912e-01
    z[3,4,3]  R1467     7.2185969352722168e-01
    z[3,4,3]  R1468     8.0861675739288330e-01
    z[3,4,3]  R1469     7.5874310731887817e-01
    z[3,4,3]  R1470     3.6285862326622009e-01
    z[3,4,3]  R1471     3.2614475488662720e-01
    z[3,4,3]  R1472     5.6435036659240723e-01
    z[3,4,3]  R1473     0.485765665769577
    z[3,4,3]  R1474     0.478840172290802
    z[3,4,3]  R1475     3.0022773146629333e-01
    z[3,4,3]  R1476     -1.1939670890569687e-01
    z[3,4,3]  R1477     -1.6397005319595337e-01
    z[3,4,3]  R1478     1.1394886672496796e-01
    z[3,4,3]  R1479     -5.8058798313140869e-02
    z[3,4,3]  R1480     -5.0612813234329224e-01
    z[3,4,3]  R1481     -1.5639641880989075e-01
    z[3,4,3]  R1482     -7.6384562253952026e-01
    z[3,4,3]  R1483     -5.2899336814880371e-01
    z[3,4,3]  R1484     -3.6867135763168335e-01
    z[3,4,3]  R1485     -8.2957327365875244e-01
    z[3,4,3]  R1486     3.0132922530174255e-01
    z[3,4,3]  R1487     -1.3027971610426903e-02
    z[3,4,3]  R1488     -9.3312285840511322e-02
    z[3,4,3]  R1489     -3.8585272431373596e-01
    z[3,4,3]  R1490     -4.4136798381805420e-01
    z[3,4,3]  R1491     -5.2970415353775024e-01
    z[3,4,3]  R1492     3.6093601584434509e-01
    z[3,4,3]  R1493     -2.8059422969818115e-01
    z[3,4,3]  R1494     -4.1917464137077332e-01
    z[3,4,3]  R1495     -3.8996261358261108e-01
    z[3,4,3]  R1496     4.6877363324165344e-01
    z[3,4,3]  R1497     -8.6615577340126038e-02
    z[3,4,3]  R1498     -2.2012059390544891e-01
    z[3,4,3]  R1499     5.0543542951345444e-02
    z[3,4,3]  R1500     -6.3995105028152466e-01
    z[3,4,3]  R1501     3.0255696177482605e-01
    z[3,4,3]  R1502     -3.9645433425903320e-02
    z[3,4,3]  R1503     0.281955748796463
    z[3,4,3]  R1504     -2.4808716773986816e-01
    z[3,4,3]  R1505     -1.3536064326763153e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1432     -1
    z[3,4,4]  R1433     1
    z[3,4,4]  R1438     -3.1282356381416321e-01
    z[3,4,4]  R1439     -4.0590861439704895e-01
    z[3,4,4]  R1440     -9.7965687513351440e-02
    z[3,4,4]  R1441     3.0620750784873962e-01
    z[3,4,4]  R1442     5.2551679313182831e-02
    z[3,4,4]  R1443     2.1951572597026825e-01
    z[3,4,4]  R1444     -1.1212415993213654e-01
    z[3,4,4]  R1445     1.7882628738880157e-01
    z[3,4,4]  R1446     8.6182296276092529e-02
    z[3,4,4]  R1447     -3.7112173438072205e-01
    z[3,4,4]  R1448     3.5811313986778259e-01
    z[3,4,4]  R1449     -6.5637670457363129e-02
    z[3,4,4]  R1450     -3.3531852066516876e-02
    z[3,4,4]  R1451     1.4174060523509979e-01
    z[3,4,4]  R1452     0.177893728017807
    z[3,4,4]  R1453     -1.0606989264488220e-01
    z[3,4,4]  R1454     -7.3660008609294891e-02
    z[3,4,4]  R1455     2.4465283751487732e-01
    z[3,4,4]  R1456     1.2989516369998455e-02
    z[3,4,4]  R1457     9.4605013728141785e-02
    z[3,4,4]  R1458     3.4848979115486145e-01
    z[3,4,4]  R1459     -3.3763018250465393e-01
    z[3,4,4]  R1460     -1.6866831481456757e-01
    z[3,4,4]  R1461     -7.3030188679695129e-02
    z[3,4,4]  R1462     -1.4280991256237030e-01
    z[3,4,4]  R1463     -5.0838004797697067e-02
    z[3,4,4]  R1464     1.5157523751258850e-01
    z[3,4,4]  R1465     1.3655400276184082e-01
    z[3,4,4]  R1466     -5.0889246165752411e-02
    z[3,4,4]  R1467     -1.6214188933372498e-01
    z[3,4,4]  R1468     3.7026622891426086e-01
    z[3,4,4]  R1469     4.5634895563125610e-01
    z[3,4,4]  R1470     -1.3036662340164185e-01
    z[3,4,4]  R1471     6.4262598752975464e-01
    z[3,4,4]  R1472     -2.6475492119789124e-01
    z[3,4,4]  R1473     -0.507340669631958
    z[3,4,4]  R1474     -4.7905972599983215e-01
    z[3,4,4]  R1475     3.6090143024921417e-02
    z[3,4,4]  R1476     3.3842098712921143e-01
    z[3,4,4]  R1477     2.7324205636978149e-01
    z[3,4,4]  R1478     2.7367309667170048e-03
    z[3,4,4]  R1479     -4.4276732951402664e-02
    z[3,4,4]  R1480     -4.8324775695800781e-01
    z[3,4,4]  R1481     5.8567330241203308e-02
    z[3,4,4]  R1482     1.8050818145275116e-01
    z[3,4,4]  R1483     -5.3812479972839355e-01
    z[3,4,4]  R1484     4.4043079018592834e-01
    z[3,4,4]  R1485     -4.7311961650848389e-02
    z[3,4,4]  R1486     -1.9998279213905334e-01
    z[3,4,4]  R1487     0.0872771218419075
    z[3,4,4]  R1488     2.4556741118431091e-01
    z[3,4,4]  R1489     -4.0157355368137360e-02
    z[3,4,4]  R1490     -0.0919187143445015
    z[3,4,4]  R1491     -1.7670853435993195e-01
    z[3,4,4]  R1492     6.5559864044189453e-02
    z[3,4,4]  R1493     0.433892160654068
    z[3,4,4]  R1494     -2.6337581872940063e-01
    z[3,4,4]  R1495     -1.1109060049057007e-01
    z[3,4,4]  R1496     -2.6722019910812378e-01
    z[3,4,4]  R1497     -2.4733142554759979e-01
    z[3,4,4]  R1498     5.0069648772478104e-02
    z[3,4,4]  R1499     2.1795381605625153e-01
    z[3,4,4]  R1500     9.0350754559040070e-02
    z[3,4,4]  R1501     0.386310338973999
    z[3,4,4]  R1502     4.6342912316322327e-01
    z[3,4,4]  R1503     -1.7118453979492188e-01
    z[3,4,4]  R1504     -2.1818645298480988e-01
    z[3,4,4]  R1505     -6.3431066274642944e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1434     -1
    z[3,4,5]  R1435     1
    z[3,4,5]  R1438     0.261923223733902
    z[3,4,5]  R1439     2.3837955296039581e-01
    z[3,4,5]  R1440     1.7931589484214783e-01
    z[3,4,5]  R1441     9.4692386686801910e-02
    z[3,4,5]  R1442     1.1864223517477512e-02
    z[3,4,5]  R1443     9.2396877706050873e-02
    z[3,4,5]  R1444     -2.9577752947807312e-01
    z[3,4,5]  R1445     4.6932362020015717e-03
    z[3,4,5]  R1446     3.8095137476921082e-01
    z[3,4,5]  R1447     -0.177132248878479
    z[3,4,5]  R1448     -4.0599358081817627e-01
    z[3,4,5]  R1449     -4.4231596589088440e-01
    z[3,4,5]  R1450     -1.8506981432437897e-02
    z[3,4,5]  R1451     4.2402917146682739e-01
    z[3,4,5]  R1452     9.0337663888931274e-02
    z[3,4,5]  R1453     -3.2538047432899475e-01
    z[3,4,5]  R1454     -4.9688392877578735e-01
    z[3,4,5]  R1455     -6.4921134710311890e-01
    z[3,4,5]  R1456     9.4749532639980316e-02
    z[3,4,5]  R1457     -6.7315645515918732e-02
    z[3,4,5]  R1458     4.0143728256225586e-03
    z[3,4,5]  R1459     1.2150320410728455e-01
    z[3,4,5]  R1460     0.606165885925293
    z[3,4,5]  R1461     -2.0348009467124939e-01
    z[3,4,5]  R1462     -2.7250227332115173e-01
    z[3,4,5]  R1463     -4.1970375180244446e-01
    z[3,4,5]  R1464     -1.8364740908145905e-01
    z[3,4,5]  R1465     -2.4095095694065094e-01
    z[3,4,5]  R1466     5.4527290165424347e-02
    z[3,4,5]  R1467     -2.1007929742336273e-01
    z[3,4,5]  R1468     -2.6475070044398308e-02
    z[3,4,5]  R1469     -0.246475487947464
    z[3,4,5]  R1470     -3.0580822378396988e-02
    z[3,4,5]  R1471     9.2176623642444611e-02
    z[3,4,5]  R1472     1.3062807917594910e-01
    z[3,4,5]  R1473     -1.8804956972599030e-01
    z[3,4,5]  R1474     1.5617184340953827e-01
    z[3,4,5]  R1475     7.7737517654895782e-02
    z[3,4,5]  R1476     3.8307833671569824e-01
    z[3,4,5]  R1477     1.5141792595386505e-01
    z[3,4,5]  R1478     2.1675595641136169e-01
    z[3,4,5]  R1479     5.5689728260040283e-01
    z[3,4,5]  R1480     -1.2681010365486145e-01
    z[3,4,5]  R1481     -1.3120164163410664e-02
    z[3,4,5]  R1482     2.9955340549349785e-02
    z[3,4,5]  R1483     1.4351907372474670e-01
    z[3,4,5]  R1484     -5.1002725958824158e-02
    z[3,4,5]  R1485     4.7414085268974304e-01
    z[3,4,5]  R1486     5.0324422121047974e-01
    z[3,4,5]  R1487     1.5538723766803741e-01
    z[3,4,5]  R1488     3.6747229099273682e-01
    z[3,4,5]  R1489     -2.6824072003364563e-02
    z[3,4,5]  R1490     -2.0342393219470978e-01
    z[3,4,5]  R1491     2.7847746014595032e-01
    z[3,4,5]  R1492     -3.1787642836570740e-01
    z[3,4,5]  R1493     1.2250393629074097e-01
    z[3,4,5]  R1494     -1.2531944550573826e-02
    z[3,4,5]  R1495     9.7767621278762817e-02
    z[3,4,5]  R1496     3.7031225860118866e-02
    z[3,4,5]  R1497     4.6168947219848633e-01
    z[3,4,5]  R1498     2.8578832745552063e-01
    z[3,4,5]  R1499     -8.6044684052467346e-02
    z[3,4,5]  R1500     5.2624985575675964e-02
    z[3,4,5]  R1501     3.3586233854293823e-01
    z[3,4,5]  R1502     2.5605341792106628e-01
    z[3,4,5]  R1503     -2.2904913127422333e-01
    z[3,4,5]  R1504     -5.6428514420986176e-02
    z[3,4,5]  R1505     2.5904285907745361e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1436     -1
    z[3,4,6]  R1437     1
    z[3,4,6]  R1438     -4.6462330222129822e-01
    z[3,4,6]  R1439     1.1685429513454437e-01
    z[3,4,6]  R1440     -1.9126628339290619e-01
    z[3,4,6]  R1441     3.5401052236557007e-01
    z[3,4,6]  R1442     3.8285449147224426e-01
    z[3,4,6]  R1443     -1.8760672211647034e-01
    z[3,4,6]  R1444     1.0930579155683517e-01
    z[3,4,6]  R1445     2.7533236145973206e-01
    z[3,4,6]  R1446     3.6939746141433716e-01
    z[3,4,6]  R1447     -1.2873359024524689e-01
    z[3,4,6]  R1448     -3.2803854346275330e-01
    z[3,4,6]  R1449     5.7653826475143433e-01
    z[3,4,6]  R1450     2.6257598400115967e-01
    z[3,4,6]  R1451     -2.5008264183998108e-01
    z[3,4,6]  R1452     -4.4959101080894470e-01
    z[3,4,6]  R1453     -7.3776558041572571e-02
    z[3,4,6]  R1454     -0.460621178150177
    z[3,4,6]  R1455     2.7532455325126648e-01
    z[3,4,6]  R1456     -1.4251363277435303e-01
    z[3,4,6]  R1457     -4.3673881888389587e-01
    z[3,4,6]  R1458     2.0005346834659576e-01
    z[3,4,6]  R1459     2.4210794270038605e-01
    z[3,4,6]  R1460     -9.9951634183526039e-03
    z[3,4,6]  R1461     5.6434098631143570e-02
    z[3,4,6]  R1462     -3.3775623887777328e-03
    z[3,4,6]  R1463     7.0777930319309235e-02
    z[3,4,6]  R1464     7.0458851754665375e-02
    z[3,4,6]  R1465     -1.7986442148685455e-01
    z[3,4,6]  R1466     -3.4079443663358688e-02
    z[3,4,6]  R1467     -5.0551801919937134e-02
    z[3,4,6]  R1468     -2.4479311704635620e-01
    z[3,4,6]  R1469     2.5216671824455261e-01
    z[3,4,6]  R1470     1.9001729786396027e-01
    z[3,4,6]  R1471     5.7350657880306244e-02
    z[3,4,6]  R1472     -3.0278715491294861e-01
    z[3,4,6]  R1473     3.9923647046089172e-01
    z[3,4,6]  R1474     -3.5043925046920776e-01
    z[3,4,6]  R1475     1.8240106105804443e-01
    z[3,4,6]  R1476     8.2011222839355469e-02
    z[3,4,6]  R1477     -2.6847827434539795e-01
    z[3,4,6]  R1478     1.8181236088275909e-01
    z[3,4,6]  R1479     4.5772776007652283e-01
    z[3,4,6]  R1480     1.3725706934928894e-01
    z[3,4,6]  R1481     3.5917314887046814e-01
    z[3,4,6]  R1482     2.2462695837020874e-02
    z[3,4,6]  R1483     0.09235879778862
    z[3,4,6]  R1484     -1.3914184272289276e-01
    z[3,4,6]  R1485     -2.7535000815987587e-02
    z[3,4,6]  R1486     -2.3029008507728577e-01
    z[3,4,6]  R1487     -1.4045518636703491e-01
    z[3,4,6]  R1488     3.0451181810349226e-03
    z[3,4,6]  R1489     -6.6363111138343811e-02
    z[3,4,6]  R1490     0.449947714805603
    z[3,4,6]  R1491     -4.9536174535751343e-01
    z[3,4,6]  R1492     2.1249692142009735e-01
    z[3,4,6]  R1493     -0.0699910819530487
    z[3,4,6]  R1494     2.4737489223480225e-01
    z[3,4,6]  R1495     1.4469218254089355e-01
    z[3,4,6]  R1496     1.9610424339771271e-01
    z[3,4,6]  R1497     -2.0946766436100006e-01
    z[3,4,6]  R1498     1.7768968641757965e-01
    z[3,4,6]  R1499     9.5873691141605377e-02
    z[3,4,6]  R1500     7.9661142081022263e-03
    z[3,4,6]  R1501     3.7048736214637756e-01
    z[3,4,6]  R1502     -3.5887271165847778e-01
    z[3,4,6]  R1503     -1.2554962933063507e-01
    z[3,4,6]  R1504     -2.5935578346252441e-01
    z[3,4,6]  R1505     -1.7442846298217773e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1506     -1
    z[4,3,0]  R1507     1
    z[4,3,0]  R1520     -5.2687013149261475e-01
    z[4,3,0]  R1521     -3.8885253667831421e-01
    z[4,3,0]  R1522     -2.4269014596939087e-01
    z[4,3,0]  R1523     -2.4279505014419556e-01
    z[4,3,0]  R1524     -6.4317220449447632e-01
    z[4,3,0]  R1525     -6.3531851768493652e-01
    z[4,3,0]  R1526     -5.0438493490219116e-01
    z[4,3,0]  R1527     -0.51566481590271
    z[4,3,0]  R1528     -3.3373662829399109e-01
    z[4,3,0]  R1529     -8.7058585882186890e-01
    z[4,3,0]  R1530     3.5148042440414429e-01
    z[4,3,0]  R1531     4.7380456328392029e-01
    z[4,3,0]  R1532     6.3418948650360107e-01
    z[4,3,0]  R1533     3.3327743411064148e-01
    z[4,3,0]  R1534     3.6435019969940186e-01
    z[4,3,0]  R1535     3.3907625079154968e-01
    z[4,3,0]  R1536     3.4834814071655273e-01
    z[4,3,0]  R1537     1.4997689425945282e-01
    z[4,3,0]  R1538     3.4531596302986145e-01
    z[4,3,0]  R1539     -2.4426843225955963e-01
    z[4,3,0]  R1540     2.2999662160873413e-01
    z[4,3,0]  R1541     -7.7903396449983120e-03
    z[4,3,0]  R1542     3.0323010683059692e-01
    z[4,3,0]  R1543     4.4778436422348022e-01
    z[4,3,0]  R1544     1.1714530736207962e-01
    z[4,3,0]  R1545     2.7664223313331604e-01
    z[4,3,0]  R1546     1.6158106923103333e-01
    z[4,3,0]  R1547     1.1710673570632935e-01
    z[4,3,0]  R1548     5.9388820081949234e-02
    z[4,3,0]  R1549     6.7244619131088257e-02
    z[4,3,0]  R1550     -7.2806432843208313e-02
    z[4,3,0]  R1551     3.0438588932156563e-02
    z[4,3,0]  R1552     -2.0102904736995697e-01
    z[4,3,0]  R1553     2.8570486232638359e-02
    z[4,3,0]  R1554     6.5622992813587189e-02
    z[4,3,0]  R1555     3.4725448489189148e-01
    z[4,3,0]  R1556     9.2229962348937988e-02
    z[4,3,0]  R1557     4.8041760921478271e-01
    z[4,3,0]  R1558     5.3070294857025146e-01
    z[4,3,0]  R1559     -1.5743415057659149e-01
    z[4,3,0]  R1560     -3.8177676498889923e-02
    z[4,3,0]  R1561     4.8281392455101013e-01
    z[4,3,0]  R1562     -5.0466382503509521e-01
    z[4,3,0]  R1563     -5.7353466749191284e-01
    z[4,3,0]  R1564     1.0525610297918320e-01
    z[4,3,0]  R1565     -7.7337872982025146e-01
    z[4,3,0]  R1566     -6.4111167192459106e-01
    z[4,3,0]  R1567     -6.9564241170883179e-01
    z[4,3,0]  R1568     -6.2685352563858032e-01
    z[4,3,0]  R1569     -0.719005286693573
    z[4,3,0]  R1570     -3.7654018402099609e-01
    z[4,3,0]  R1571     1.6541968286037445e-01
    z[4,3,0]  R1572     9.5905058085918427e-02
    z[4,3,0]  R1573     -4.5115888118743896e-02
    z[4,3,0]  R1574     2.8157824277877808e-01
    z[4,3,0]  R1575     3.9633381366729736e-01
    z[4,3,0]  R1576     4.0888580679893494e-01
    z[4,3,0]  R1577     4.4836091995239258e-01
    z[4,3,0]  R1578     0.575560986995697
    z[4,3,0]  R1579     4.1028848290443420e-01
    z[4,3,0]  R1580     2.2562281787395477e-01
    z[4,3,0]  R1581     -2.0755213499069214e-01
    z[4,3,0]  R1582     -3.9948263764381409e-01
    z[4,3,0]  R1583     3.1391668319702148e-01
    z[4,3,0]  R1584     3.6903870105743408e-01
    z[4,3,0]  R1585     2.7826866507530212e-01
    z[4,3,0]  R1586     5.2810066938400269e-01
    z[4,3,0]  R1587     4.2486450076103210e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1508     -1
    z[4,3,1]  R1509     1
    z[4,3,1]  R1520     -4.7371357679367065e-02
    z[4,3,1]  R1521     4.9620330333709717e-01
    z[4,3,1]  R1522     0.249917671084404
    z[4,3,1]  R1523     1.2432807683944702e-01
    z[4,3,1]  R1524     6.3261699676513672e-01
    z[4,3,1]  R1525     1.8798816204071045e-01
    z[4,3,1]  R1526     1.8632699549198151e-01
    z[4,3,1]  R1527     1.9373770058155060e-01
    z[4,3,1]  R1528     5.3115576505661011e-01
    z[4,3,1]  R1529     -7.9930663108825684e-02
    z[4,3,1]  R1530     -1.1468087136745453e-01
    z[4,3,1]  R1531     -2.5782150030136108e-01
    z[4,3,1]  R1532     -1.1214705556631088e-01
    z[4,3,1]  R1533     -1.4951537549495697e-01
    z[4,3,1]  R1534     5.5012357234954834e-01
    z[4,3,1]  R1535     -9.5172375440597534e-02
    z[4,3,1]  R1536     5.0524824857711792e-01
    z[4,3,1]  R1537     -2.2338593006134033e-01
    z[4,3,1]  R1538     3.0758830904960632e-01
    z[4,3,1]  R1539     0.155996635556221
    z[4,3,1]  R1540     -6.5523695945739746e-01
    z[4,3,1]  R1541     -0.941007137298584
    z[4,3,1]  R1542     -7.8983032703399658e-01
    z[4,3,1]  R1543     7.2181189060211182e-01
    z[4,3,1]  R1544     0.701270580291748
    z[4,3,1]  R1545     5.3694558143615723e-01
    z[4,3,1]  R1546     -3.7327718734741211e-01
    z[4,3,1]  R1547     -8.3622777462005615e-01
    z[4,3,1]  R1548     -8.0783206224441528e-01
    z[4,3,1]  R1549     -8.1421262025833130e-01
    z[4,3,1]  R1550     -5.7421392202377319e-01
    z[4,3,1]  R1551     -5.5053830146789551e-01
    z[4,3,1]  R1552     -6.1403536796569824e-01
    z[4,3,1]  R1553     -7.8212535381317139e-01
    z[4,3,1]  R1554     7.3139268159866333e-01
    z[4,3,1]  R1555     -1.6193135082721710e-01
    z[4,3,1]  R1556     -7.0713929831981659e-02
    z[4,3,1]  R1557     -1.5904399752616882e-01
    z[4,3,1]  R1558     0.622560441493988
    z[4,3,1]  R1559     -0.65133136510849
    z[4,3,1]  R1560     -2.2855930030345917e-01
    z[4,3,1]  R1561     -2.2460272908210754e-01
    z[4,3,1]  R1562     3.2066803425550461e-02
    z[4,3,1]  R1563     -2.4953939020633698e-01
    z[4,3,1]  R1564     -3.4873235225677490e-01
    z[4,3,1]  R1565     8.6467780172824860e-02
    z[4,3,1]  R1566     1.0977321863174438e-01
    z[4,3,1]  R1567     1.7737165093421936e-01
    z[4,3,1]  R1568     6.5116435289382935e-02
    z[4,3,1]  R1569     2.6427105069160461e-01
    z[4,3,1]  R1570     1.6233828663825989e-01
    z[4,3,1]  R1571     3.5085299611091614e-01
    z[4,3,1]  R1572     3.7565350532531738e-01
    z[4,3,1]  R1573     -6.6838508844375610e-01
    z[4,3,1]  R1574     -7.0583873987197876e-01
    z[4,3,1]  R1575     7.8617835044860840e-01
    z[4,3,1]  R1576     3.8600188493728638e-01
    z[4,3,1]  R1577     2.1506385505199432e-01
    z[4,3,1]  R1578     -7.4995177984237671e-01
    z[4,3,1]  R1579     -5.3873974084854126e-01
    z[4,3,1]  R1580     -6.3138955831527710e-01
    z[4,3,1]  R1581     6.6662716865539551e-01
    z[4,3,1]  R1582     -7.1545474231243134e-02
    z[4,3,1]  R1583     7.5208085775375366e-01
    z[4,3,1]  R1584     6.2472069263458252e-01
    z[4,3,1]  R1585     5.6213027238845825e-01
    z[4,3,1]  R1586     4.2814698815345764e-01
    z[4,3,1]  R1587     6.2551081180572510e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1510     -1
    z[4,3,2]  R1511     1
    z[4,3,2]  R1520     3.8109385967254639e-01
    z[4,3,2]  R1521     -9.2280693352222443e-02
    z[4,3,2]  R1522     -1.6449901461601257e-01
    z[4,3,2]  R1523     1.3156543672084808e-01
    z[4,3,2]  R1524     -2.0533861592411995e-02
    z[4,3,2]  R1525     1.7293557524681091e-01
    z[4,3,2]  R1526     -4.6211230754852295e-01
    z[4,3,2]  R1527     -9.1871142387390137e-02
    z[4,3,2]  R1528     2.2585256025195122e-02
    z[4,3,2]  R1529     -0.323942631483078
    z[4,3,2]  R1530     -7.6226669549942017e-01
    z[4,3,2]  R1531     -0.715878427028656
    z[4,3,2]  R1532     -7.0156681537628174e-01
    z[4,3,2]  R1533     -5.8445763587951660e-01
    z[4,3,2]  R1534     -1.9999657571315765e-01
    z[4,3,2]  R1535     -8.4788095951080322e-01
    z[4,3,2]  R1536     7.7022358775138855e-02
    z[4,3,2]  R1537     -5.7364231348037720e-01
    z[4,3,2]  R1538     -6.5900450944900513e-01
    z[4,3,2]  R1539     -0.00027977250283584
    z[4,3,2]  R1540     -2.8405159711837769e-01
    z[4,3,2]  R1541     -2.5056964159011841e-01
    z[4,3,2]  R1542     -2.8313216567039490e-01
    z[4,3,2]  R1543     3.5051146149635315e-01
    z[4,3,2]  R1544     2.1773280203342438e-01
    z[4,3,2]  R1545     0.0203268900513649
    z[4,3,2]  R1546     -7.4416553974151611e-01
    z[4,3,2]  R1547     -1.0377339087426662e-02
    z[4,3,2]  R1548     -1.9353257119655609e-01
    z[4,3,2]  R1549     3.7098485231399536e-01
    z[4,3,2]  R1550     -5.7792204618453979e-01
    z[4,3,2]  R1551     -6.0849994421005249e-01
    z[4,3,2]  R1552     -0.646791398525238
    z[4,3,2]  R1553     -5.6640064716339111e-01
    z[4,3,2]  R1554     -2.0056138932704926e-01
    z[4,3,2]  R1555     -6.0195660591125488e-01
    z[4,3,2]  R1556     -7.5881606340408325e-01
    z[4,3,2]  R1557     -7.5291055440902710e-01
    z[4,3,2]  R1558     -3.8880684971809387e-01
    z[4,3,2]  R1559     1.8105547130107880e-01
    z[4,3,2]  R1560     -7.5069051980972290e-01
    z[4,3,2]  R1561     -6.9352585077285767e-01
    z[4,3,2]  R1562     0.0881400927901268
    z[4,3,2]  R1563     -0.616380512714386
    z[4,3,2]  R1564     -0.812161922454834
    z[4,3,2]  R1565     1.8503734469413757e-01
    z[4,3,2]  R1566     3.2529249787330627e-01
    z[4,3,2]  R1567     -2.6412791013717651e-01
    z[4,3,2]  R1568     2.7396348118782043e-01
    z[4,3,2]  R1569     -2.3845118284225464e-01
    z[4,3,2]  R1570     -2.2934272885322571e-02
    z[4,3,2]  R1571     1.7681892216205597e-01
    z[4,3,2]  R1572     5.9974616765975952e-01
    z[4,3,2]  R1573     4.1776421666145325e-01
    z[4,3,2]  R1574     3.7270089983940125e-01
    z[4,3,2]  R1575     -5.5384196341037750e-02
    z[4,3,2]  R1576     4.2232406139373779e-01
    z[4,3,2]  R1577     2.1507011353969574e-01
    z[4,3,2]  R1578     -1.7446257174015045e-01
    z[4,3,2]  R1579     -5.5856686085462570e-02
    z[4,3,2]  R1580     8.0902762711048126e-03
    z[4,3,2]  R1581     -1.5333354473114014e-01
    z[4,3,2]  R1582     1.4602917432785034e-01
    z[4,3,2]  R1583     2.9094228148460388e-01
    z[4,3,2]  R1584     3.6671683192253113e-01
    z[4,3,2]  R1585     4.8931926488876343e-01
    z[4,3,2]  R1586     2.4885062873363495e-01
    z[4,3,2]  R1587     -0.0532621331512928
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1512     -1
    z[4,3,3]  R1513     1
    z[4,3,3]  R1520     7.5379502773284912e-01
    z[4,3,3]  R1521     7.2185969352722168e-01
    z[4,3,3]  R1522     8.0861675739288330e-01
    z[4,3,3]  R1523     7.5874310731887817e-01
    z[4,3,3]  R1524     3.6285862326622009e-01
    z[4,3,3]  R1525     3.2614475488662720e-01
    z[4,3,3]  R1526     5.6435036659240723e-01
    z[4,3,3]  R1527     0.485765665769577
    z[4,3,3]  R1528     0.478840172290802
    z[4,3,3]  R1529     3.0022773146629333e-01
    z[4,3,3]  R1530     -1.1939670890569687e-01
    z[4,3,3]  R1531     -1.6397005319595337e-01
    z[4,3,3]  R1532     1.1394886672496796e-01
    z[4,3,3]  R1533     -5.8058798313140869e-02
    z[4,3,3]  R1534     -5.0612813234329224e-01
    z[4,3,3]  R1535     -1.5639641880989075e-01
    z[4,3,3]  R1536     -7.6384562253952026e-01
    z[4,3,3]  R1537     -5.2899336814880371e-01
    z[4,3,3]  R1538     -3.6867135763168335e-01
    z[4,3,3]  R1539     -8.2957327365875244e-01
    z[4,3,3]  R1540     3.0132922530174255e-01
    z[4,3,3]  R1541     -1.3027971610426903e-02
    z[4,3,3]  R1542     -9.3312285840511322e-02
    z[4,3,3]  R1543     -3.8585272431373596e-01
    z[4,3,3]  R1544     -4.4136798381805420e-01
    z[4,3,3]  R1545     -5.2970415353775024e-01
    z[4,3,3]  R1546     3.6093601584434509e-01
    z[4,3,3]  R1547     -2.8059422969818115e-01
    z[4,3,3]  R1548     -4.1917464137077332e-01
    z[4,3,3]  R1549     -3.8996261358261108e-01
    z[4,3,3]  R1550     4.6877363324165344e-01
    z[4,3,3]  R1551     -8.6615577340126038e-02
    z[4,3,3]  R1552     -2.2012059390544891e-01
    z[4,3,3]  R1553     5.0543542951345444e-02
    z[4,3,3]  R1554     -6.3995105028152466e-01
    z[4,3,3]  R1555     3.0255696177482605e-01
    z[4,3,3]  R1556     -3.9645433425903320e-02
    z[4,3,3]  R1557     0.281955748796463
    z[4,3,3]  R1558     -2.4808716773986816e-01
    z[4,3,3]  R1559     -1.3536064326763153e-01
    z[4,3,3]  R1560     -2.0729070529341698e-02
    z[4,3,3]  R1561     1.4990265481173992e-02
    z[4,3,3]  R1562     8.1128489971160889e-01
    z[4,3,3]  R1563     2.8460944071412086e-02
    z[4,3,3]  R1564     2.4128781259059906e-01
    z[4,3,3]  R1565     5.1792770624160767e-01
    z[4,3,3]  R1566     5.9925496578216553e-01
    z[4,3,3]  R1567     5.5411982536315918e-01
    z[4,3,3]  R1568     4.8862314224243164e-01
    z[4,3,3]  R1569     4.1310253739356995e-01
    z[4,3,3]  R1570     -6.5624141693115234e-01
    z[4,3,3]  R1571     -5.3472006320953369e-01
    z[4,3,3]  R1572     -0.647748589515686
    z[4,3,3]  R1573     -3.3803331851959229e-01
    z[4,3,3]  R1574     2.0410838723182678e-01
    z[4,3,3]  R1575     3.1497529149055481e-01
    z[4,3,3]  R1576     2.0240074396133423e-01
    z[4,3,3]  R1577     3.8643366098403931e-01
    z[4,3,3]  R1578     2.1542568504810333e-01
    z[4,3,3]  R1579     -0.577997088432312
    z[4,3,3]  R1580     -6.2361329793930054e-01
    z[4,3,3]  R1581     -5.4922294616699219e-01
    z[4,3,3]  R1582     -6.4651709794998169e-01
    z[4,3,3]  R1583     4.4862103462219238e-01
    z[4,3,3]  R1584     4.9435773491859436e-01
    z[4,3,3]  R1585     4.2824935913085938e-01
    z[4,3,3]  R1586     6.4358937740325928e-01
    z[4,3,3]  R1587     5.6243580579757690e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1514     -1
    z[4,3,4]  R1515     1
    z[4,3,4]  R1520     -5.0889246165752411e-02
    z[4,3,4]  R1521     -1.6214188933372498e-01
    z[4,3,4]  R1522     3.7026622891426086e-01
    z[4,3,4]  R1523     4.5634895563125610e-01
    z[4,3,4]  R1524     -1.3036662340164185e-01
    z[4,3,4]  R1525     6.4262598752975464e-01
    z[4,3,4]  R1526     -2.6475492119789124e-01
    z[4,3,4]  R1527     -0.507340669631958
    z[4,3,4]  R1528     -4.7905972599983215e-01
    z[4,3,4]  R1529     3.6090143024921417e-02
    z[4,3,4]  R1530     3.3842098712921143e-01
    z[4,3,4]  R1531     2.7324205636978149e-01
    z[4,3,4]  R1532     2.7367309667170048e-03
    z[4,3,4]  R1533     -4.4276732951402664e-02
    z[4,3,4]  R1534     -4.8324775695800781e-01
    z[4,3,4]  R1535     5.8567330241203308e-02
    z[4,3,4]  R1536     1.8050818145275116e-01
    z[4,3,4]  R1537     -5.3812479972839355e-01
    z[4,3,4]  R1538     4.4043079018592834e-01
    z[4,3,4]  R1539     -4.7311961650848389e-02
    z[4,3,4]  R1540     -1.9998279213905334e-01
    z[4,3,4]  R1541     0.0872771218419075
    z[4,3,4]  R1542     2.4556741118431091e-01
    z[4,3,4]  R1543     -4.0157355368137360e-02
    z[4,3,4]  R1544     -0.0919187143445015
    z[4,3,4]  R1545     -1.7670853435993195e-01
    z[4,3,4]  R1546     6.5559864044189453e-02
    z[4,3,4]  R1547     0.433892160654068
    z[4,3,4]  R1548     -2.6337581872940063e-01
    z[4,3,4]  R1549     -1.1109060049057007e-01
    z[4,3,4]  R1550     -2.6722019910812378e-01
    z[4,3,4]  R1551     -2.4733142554759979e-01
    z[4,3,4]  R1552     5.0069648772478104e-02
    z[4,3,4]  R1553     2.1795381605625153e-01
    z[4,3,4]  R1554     9.0350754559040070e-02
    z[4,3,4]  R1555     0.386310338973999
    z[4,3,4]  R1556     4.6342912316322327e-01
    z[4,3,4]  R1557     -1.7118453979492188e-01
    z[4,3,4]  R1558     -2.1818645298480988e-01
    z[4,3,4]  R1559     -6.3431066274642944e-01
    z[4,3,4]  R1560     -3.1282356381416321e-01
    z[4,3,4]  R1561     -4.0590861439704895e-01
    z[4,3,4]  R1562     -9.7965687513351440e-02
    z[4,3,4]  R1563     3.0620750784873962e-01
    z[4,3,4]  R1564     5.2551679313182831e-02
    z[4,3,4]  R1565     2.1951572597026825e-01
    z[4,3,4]  R1566     -1.1212415993213654e-01
    z[4,3,4]  R1567     1.7882628738880157e-01
    z[4,3,4]  R1568     8.6182296276092529e-02
    z[4,3,4]  R1569     -3.7112173438072205e-01
    z[4,3,4]  R1570     3.5811313986778259e-01
    z[4,3,4]  R1571     -6.5637670457363129e-02
    z[4,3,4]  R1572     -3.3531852066516876e-02
    z[4,3,4]  R1573     1.4174060523509979e-01
    z[4,3,4]  R1574     0.177893728017807
    z[4,3,4]  R1575     -1.0606989264488220e-01
    z[4,3,4]  R1576     -7.3660008609294891e-02
    z[4,3,4]  R1577     2.4465283751487732e-01
    z[4,3,4]  R1578     1.2989516369998455e-02
    z[4,3,4]  R1579     9.4605013728141785e-02
    z[4,3,4]  R1580     3.4848979115486145e-01
    z[4,3,4]  R1581     -3.3763018250465393e-01
    z[4,3,4]  R1582     -1.6866831481456757e-01
    z[4,3,4]  R1583     -7.3030188679695129e-02
    z[4,3,4]  R1584     -1.4280991256237030e-01
    z[4,3,4]  R1585     -5.0838004797697067e-02
    z[4,3,4]  R1586     1.5157523751258850e-01
    z[4,3,4]  R1587     1.3655400276184082e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1516     -1
    z[4,3,5]  R1517     1
    z[4,3,5]  R1520     5.4527290165424347e-02
    z[4,3,5]  R1521     -2.1007929742336273e-01
    z[4,3,5]  R1522     -2.6475070044398308e-02
    z[4,3,5]  R1523     -0.246475487947464
    z[4,3,5]  R1524     -3.0580822378396988e-02
    z[4,3,5]  R1525     9.2176623642444611e-02
    z[4,3,5]  R1526     1.3062807917594910e-01
    z[4,3,5]  R1527     -1.8804956972599030e-01
    z[4,3,5]  R1528     1.5617184340953827e-01
    z[4,3,5]  R1529     7.7737517654895782e-02
    z[4,3,5]  R1530     3.8307833671569824e-01
    z[4,3,5]  R1531     1.5141792595386505e-01
    z[4,3,5]  R1532     2.1675595641136169e-01
    z[4,3,5]  R1533     5.5689728260040283e-01
    z[4,3,5]  R1534     -1.2681010365486145e-01
    z[4,3,5]  R1535     -1.3120164163410664e-02
    z[4,3,5]  R1536     2.9955340549349785e-02
    z[4,3,5]  R1537     1.4351907372474670e-01
    z[4,3,5]  R1538     -5.1002725958824158e-02
    z[4,3,5]  R1539     4.7414085268974304e-01
    z[4,3,5]  R1540     5.0324422121047974e-01
    z[4,3,5]  R1541     1.5538723766803741e-01
    z[4,3,5]  R1542     3.6747229099273682e-01
    z[4,3,5]  R1543     -2.6824072003364563e-02
    z[4,3,5]  R1544     -2.0342393219470978e-01
    z[4,3,5]  R1545     2.7847746014595032e-01
    z[4,3,5]  R1546     -3.1787642836570740e-01
    z[4,3,5]  R1547     1.2250393629074097e-01
    z[4,3,5]  R1548     -1.2531944550573826e-02
    z[4,3,5]  R1549     9.7767621278762817e-02
    z[4,3,5]  R1550     3.7031225860118866e-02
    z[4,3,5]  R1551     4.6168947219848633e-01
    z[4,3,5]  R1552     2.8578832745552063e-01
    z[4,3,5]  R1553     -8.6044684052467346e-02
    z[4,3,5]  R1554     5.2624985575675964e-02
    z[4,3,5]  R1555     3.3586233854293823e-01
    z[4,3,5]  R1556     2.5605341792106628e-01
    z[4,3,5]  R1557     -2.2904913127422333e-01
    z[4,3,5]  R1558     -5.6428514420986176e-02
    z[4,3,5]  R1559     2.5904285907745361e-01
    z[4,3,5]  R1560     0.261923223733902
    z[4,3,5]  R1561     2.3837955296039581e-01
    z[4,3,5]  R1562     1.7931589484214783e-01
    z[4,3,5]  R1563     9.4692386686801910e-02
    z[4,3,5]  R1564     1.1864223517477512e-02
    z[4,3,5]  R1565     9.2396877706050873e-02
    z[4,3,5]  R1566     -2.9577752947807312e-01
    z[4,3,5]  R1567     4.6932362020015717e-03
    z[4,3,5]  R1568     3.8095137476921082e-01
    z[4,3,5]  R1569     -0.177132248878479
    z[4,3,5]  R1570     -4.0599358081817627e-01
    z[4,3,5]  R1571     -4.4231596589088440e-01
    z[4,3,5]  R1572     -1.8506981432437897e-02
    z[4,3,5]  R1573     4.2402917146682739e-01
    z[4,3,5]  R1574     9.0337663888931274e-02
    z[4,3,5]  R1575     -3.2538047432899475e-01
    z[4,3,5]  R1576     -4.9688392877578735e-01
    z[4,3,5]  R1577     -6.4921134710311890e-01
    z[4,3,5]  R1578     9.4749532639980316e-02
    z[4,3,5]  R1579     -6.7315645515918732e-02
    z[4,3,5]  R1580     4.0143728256225586e-03
    z[4,3,5]  R1581     1.2150320410728455e-01
    z[4,3,5]  R1582     0.606165885925293
    z[4,3,5]  R1583     -2.0348009467124939e-01
    z[4,3,5]  R1584     -2.7250227332115173e-01
    z[4,3,5]  R1585     -4.1970375180244446e-01
    z[4,3,5]  R1586     -1.8364740908145905e-01
    z[4,3,5]  R1587     -2.4095095694065094e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1518     -1
    z[4,3,6]  R1519     1
    z[4,3,6]  R1520     -3.4079443663358688e-02
    z[4,3,6]  R1521     -5.0551801919937134e-02
    z[4,3,6]  R1522     -2.4479311704635620e-01
    z[4,3,6]  R1523     2.5216671824455261e-01
    z[4,3,6]  R1524     1.9001729786396027e-01
    z[4,3,6]  R1525     5.7350657880306244e-02
    z[4,3,6]  R1526     -3.0278715491294861e-01
    z[4,3,6]  R1527     3.9923647046089172e-01
    z[4,3,6]  R1528     -3.5043925046920776e-01
    z[4,3,6]  R1529     1.8240106105804443e-01
    z[4,3,6]  R1530     8.2011222839355469e-02
    z[4,3,6]  R1531     -2.6847827434539795e-01
    z[4,3,6]  R1532     1.8181236088275909e-01
    z[4,3,6]  R1533     4.5772776007652283e-01
    z[4,3,6]  R1534     1.3725706934928894e-01
    z[4,3,6]  R1535     3.5917314887046814e-01
    z[4,3,6]  R1536     2.2462695837020874e-02
    z[4,3,6]  R1537     0.09235879778862
    z[4,3,6]  R1538     -1.3914184272289276e-01
    z[4,3,6]  R1539     -2.7535000815987587e-02
    z[4,3,6]  R1540     -2.3029008507728577e-01
    z[4,3,6]  R1541     -1.4045518636703491e-01
    z[4,3,6]  R1542     3.0451181810349226e-03
    z[4,3,6]  R1543     -6.6363111138343811e-02
    z[4,3,6]  R1544     0.449947714805603
    z[4,3,6]  R1545     -4.9536174535751343e-01
    z[4,3,6]  R1546     2.1249692142009735e-01
    z[4,3,6]  R1547     -0.0699910819530487
    z[4,3,6]  R1548     2.4737489223480225e-01
    z[4,3,6]  R1549     1.4469218254089355e-01
    z[4,3,6]  R1550     1.9610424339771271e-01
    z[4,3,6]  R1551     -2.0946766436100006e-01
    z[4,3,6]  R1552     1.7768968641757965e-01
    z[4,3,6]  R1553     9.5873691141605377e-02
    z[4,3,6]  R1554     7.9661142081022263e-03
    z[4,3,6]  R1555     3.7048736214637756e-01
    z[4,3,6]  R1556     -3.5887271165847778e-01
    z[4,3,6]  R1557     -1.2554962933063507e-01
    z[4,3,6]  R1558     -2.5935578346252441e-01
    z[4,3,6]  R1559     -1.7442846298217773e-01
    z[4,3,6]  R1560     -4.6462330222129822e-01
    z[4,3,6]  R1561     1.1685429513454437e-01
    z[4,3,6]  R1562     -1.9126628339290619e-01
    z[4,3,6]  R1563     3.5401052236557007e-01
    z[4,3,6]  R1564     3.8285449147224426e-01
    z[4,3,6]  R1565     -1.8760672211647034e-01
    z[4,3,6]  R1566     1.0930579155683517e-01
    z[4,3,6]  R1567     2.7533236145973206e-01
    z[4,3,6]  R1568     3.6939746141433716e-01
    z[4,3,6]  R1569     -1.2873359024524689e-01
    z[4,3,6]  R1570     -3.2803854346275330e-01
    z[4,3,6]  R1571     5.7653826475143433e-01
    z[4,3,6]  R1572     2.6257598400115967e-01
    z[4,3,6]  R1573     -2.5008264183998108e-01
    z[4,3,6]  R1574     -4.4959101080894470e-01
    z[4,3,6]  R1575     -7.3776558041572571e-02
    z[4,3,6]  R1576     -0.460621178150177
    z[4,3,6]  R1577     2.7532455325126648e-01
    z[4,3,6]  R1578     -1.4251363277435303e-01
    z[4,3,6]  R1579     -4.3673881888389587e-01
    z[4,3,6]  R1580     2.0005346834659576e-01
    z[4,3,6]  R1581     2.4210794270038605e-01
    z[4,3,6]  R1582     -9.9951634183526039e-03
    z[4,3,6]  R1583     5.6434098631143570e-02
    z[4,3,6]  R1584     -3.3775623887777328e-03
    z[4,3,6]  R1585     7.0777930319309235e-02
    z[4,3,6]  R1586     7.0458851754665375e-02
    z[4,3,6]  R1587     -1.7986442148685455e-01
    z[3,8,0]  R29       -1
    z[3,8,0]  R74       1
    z[3,8,0]  R1588     -1
    z[3,8,0]  R1589     1
    z[3,8,0]  R1602     -3.8177676498889923e-02
    z[3,8,0]  R1603     4.8281392455101013e-01
    z[3,8,0]  R1604     -5.0466382503509521e-01
    z[3,8,0]  R1605     -5.7353466749191284e-01
    z[3,8,0]  R1606     1.0525610297918320e-01
    z[3,8,0]  R1607     -7.7337872982025146e-01
    z[3,8,0]  R1608     -6.4111167192459106e-01
    z[3,8,0]  R1609     -6.9564241170883179e-01
    z[3,8,0]  R1610     -6.2685352563858032e-01
    z[3,8,0]  R1611     -0.719005286693573
    z[3,8,0]  R1612     -3.7654018402099609e-01
    z[3,8,0]  R1613     1.6541968286037445e-01
    z[3,8,0]  R1614     9.5905058085918427e-02
    z[3,8,0]  R1615     -4.5115888118743896e-02
    z[3,8,0]  R1616     2.8157824277877808e-01
    z[3,8,0]  R1617     3.9633381366729736e-01
    z[3,8,0]  R1618     4.0888580679893494e-01
    z[3,8,0]  R1619     4.4836091995239258e-01
    z[3,8,0]  R1620     0.575560986995697
    z[3,8,0]  R1621     4.1028848290443420e-01
    z[3,8,0]  R1622     2.2562281787395477e-01
    z[3,8,0]  R1623     -2.0755213499069214e-01
    z[3,8,0]  R1624     -3.9948263764381409e-01
    z[3,8,0]  R1625     3.1391668319702148e-01
    z[3,8,0]  R1626     3.6903870105743408e-01
    z[3,8,0]  R1627     2.7826866507530212e-01
    z[3,8,0]  R1628     5.2810066938400269e-01
    z[3,8,0]  R1629     4.2486450076103210e-01
    z[3,8,0]  R1630     -4.4458016753196716e-01
    z[3,8,0]  R1631     -5.4850107431411743e-01
    z[3,8,0]  R1632     -4.5679804682731628e-01
    z[3,8,0]  R1633     -5.3019177913665771e-01
    z[3,8,0]  R1634     -2.9695528745651245e-01
    z[3,8,0]  R1635     0.423216313123703
    z[3,8,0]  R1636     4.9933582544326782e-01
    z[3,8,0]  R1637     3.6802518367767334e-01
    z[3,8,0]  R1638     -2.4371489882469177e-02
    z[3,8,0]  R1639     3.4120373427867889e-02
    z[3,8,0]  R1640     -3.4763745963573456e-02
    z[3,8,0]  R1641     5.6848841905593872e-01
    z[3,8,0]  R1642     -3.4385025501251221e-01
    z[3,8,0]  R1643     1.7285591363906860e-01
    z[3,8,0]  R1644     4.4793954491615295e-01
    z[3,8,0]  R1645     8.7197288870811462e-02
    z[3,8,0]  R1646     2.3777349293231964e-01
    z[3,8,0]  R1647     6.7076951265335083e-01
    z[3,8,0]  R1648     7.3758906126022339e-01
    z[3,8,0]  R1649     3.9325261116027832e-01
    z[3,8,0]  R1650     -3.5049572587013245e-01
    z[3,8,0]  R1651     -6.2821739912033081e-01
    z[3,8,0]  R1652     -4.1651833802461624e-02
    z[3,8,0]  R1653     -1.3105449080467224e-01
    z[3,8,0]  R1654     3.7713015079498291e-01
    z[3,8,0]  R1655     4.3652275204658508e-01
    z[3,8,0]  R1656     2.2517924010753632e-01
    z[3,8,0]  R1657     8.0271774530410767e-01
    z[3,8,0]  R1658     3.5582551360130310e-01
    z[3,8,0]  R1659     4.1191452741622925e-01
    z[3,8,0]  R1660     -3.2250946760177612e-01
    z[3,8,0]  R1661     0.61336749792099
    z[3,8,0]  R1662     3.8357287645339966e-01
    z[3,8,0]  R1663     2.3956814408302307e-01
    z[3,8,0]  R1664     5.6480652093887329e-01
    z[3,8,0]  R1665     6.6074001789093018e-01
    z[3,8,0]  R1666     5.9936910867691040e-01
    z[3,8,0]  R1667     7.1849167346954346e-01
    z[3,8,0]  R1668     4.0731152892112732e-01
    z[3,8,0]  R1669     3.0544099211692810e-01
    z[3,8,1]  R30       -1
    z[3,8,1]  R75       1
    z[3,8,1]  R1590     -1
    z[3,8,1]  R1591     1
    z[3,8,1]  R1602     -2.2855930030345917e-01
    z[3,8,1]  R1603     -2.2460272908210754e-01
    z[3,8,1]  R1604     3.2066803425550461e-02
    z[3,8,1]  R1605     -2.4953939020633698e-01
    z[3,8,1]  R1606     -3.4873235225677490e-01
    z[3,8,1]  R1607     8.6467780172824860e-02
    z[3,8,1]  R1608     1.0977321863174438e-01
    z[3,8,1]  R1609     1.7737165093421936e-01
    z[3,8,1]  R1610     6.5116435289382935e-02
    z[3,8,1]  R1611     2.6427105069160461e-01
    z[3,8,1]  R1612     1.6233828663825989e-01
    z[3,8,1]  R1613     3.5085299611091614e-01
    z[3,8,1]  R1614     3.7565350532531738e-01
    z[3,8,1]  R1615     -6.6838508844375610e-01
    z[3,8,1]  R1616     -7.0583873987197876e-01
    z[3,8,1]  R1617     7.8617835044860840e-01
    z[3,8,1]  R1618     3.8600188493728638e-01
    z[3,8,1]  R1619     2.1506385505199432e-01
    z[3,8,1]  R1620     -7.4995177984237671e-01
    z[3,8,1]  R1621     -5.3873974084854126e-01
    z[3,8,1]  R1622     -6.3138955831527710e-01
    z[3,8,1]  R1623     6.6662716865539551e-01
    z[3,8,1]  R1624     -7.1545474231243134e-02
    z[3,8,1]  R1625     7.5208085775375366e-01
    z[3,8,1]  R1626     6.2472069263458252e-01
    z[3,8,1]  R1627     5.6213027238845825e-01
    z[3,8,1]  R1628     4.2814698815345764e-01
    z[3,8,1]  R1629     6.2551081180572510e-01
    z[3,8,1]  R1630     -1.4952081441879272e-01
    z[3,8,1]  R1631     -3.4902659058570862e-01
    z[3,8,1]  R1632     -1.8333059549331665e-01
    z[3,8,1]  R1633     -3.7707424163818359e-01
    z[3,8,1]  R1634     -2.2114260494709015e-01
    z[3,8,1]  R1635     -4.8019373416900635e-01
    z[3,8,1]  R1636     2.3389001190662384e-01
    z[3,8,1]  R1637     6.8756383657455444e-01
    z[3,8,1]  R1638     7.1067267656326294e-01
    z[3,8,1]  R1639     4.1083535552024841e-01
    z[3,8,1]  R1640     -6.6959851980209351e-01
    z[3,8,1]  R1641     3.6577469110488892e-01
    z[3,8,1]  R1642     -3.5648050904273987e-01
    z[3,8,1]  R1643     -2.8611627221107483e-01
    z[3,8,1]  R1644     4.1512030363082886e-01
    z[3,8,1]  R1645     4.0920725464820862e-01
    z[3,8,1]  R1646     7.3018616437911987e-01
    z[3,8,1]  R1647     4.6719476580619812e-01
    z[3,8,1]  R1648     7.3564932681620121e-03
    z[3,8,1]  R1649     7.6251387596130371e-01
    z[3,8,1]  R1650     -4.7746515274047852e-01
    z[3,8,1]  R1651     -0.389955997467041
    z[3,8,1]  R1652     -5.7755655050277710e-01
    z[3,8,1]  R1653     -0.517392098903656
    z[3,8,1]  R1654     -5.5999320745468140e-01
    z[3,8,1]  R1655     -5.9310501813888550e-01
    z[3,8,1]  R1656     -6.5441983938217163e-01
    z[3,8,1]  R1657     4.1583898663520813e-01
    z[3,8,1]  R1658     6.2891805171966553e-01
    z[3,8,1]  R1659     5.0711423158645630e-01
    z[3,8,1]  R1660     -7.9809540510177612e-01
    z[3,8,1]  R1661     5.7353240251541138e-01
    z[3,8,1]  R1662     5.6229871511459351e-01
    z[3,8,1]  R1663     6.2847858667373657e-01
    z[3,8,1]  R1664     5.8387905359268188e-01
    z[3,8,1]  R1665     5.1069349050521851e-01
    z[3,8,1]  R1666     5.4953384399414062e-01
    z[3,8,1]  R1667     4.4973301887512207e-01
    z[3,8,1]  R1668     8.3884263038635254e-01
    z[3,8,1]  R1669     -6.1183761805295944e-02
    z[3,8,2]  R31       -1
    z[3,8,2]  R76       1
    z[3,8,2]  R1592     -1
    z[3,8,2]  R1593     1
    z[3,8,2]  R1602     -7.5069051980972290e-01
    z[3,8,2]  R1603     -6.9352585077285767e-01
    z[3,8,2]  R1604     0.0881400927901268
    z[3,8,2]  R1605     -0.616380512714386
    z[3,8,2]  R1606     -0.812161922454834
    z[3,8,2]  R1607     1.8503734469413757e-01
    z[3,8,2]  R1608     3.2529249787330627e-01
    z[3,8,2]  R1609     -2.6412791013717651e-01
    z[3,8,2]  R1610     2.7396348118782043e-01
    z[3,8,2]  R1611     -2.3845118284225464e-01
    z[3,8,2]  R1612     -2.2934272885322571e-02
    z[3,8,2]  R1613     1.7681892216205597e-01
    z[3,8,2]  R1614     5.9974616765975952e-01
    z[3,8,2]  R1615     4.1776421666145325e-01
    z[3,8,2]  R1616     3.7270089983940125e-01
    z[3,8,2]  R1617     -5.5384196341037750e-02
    z[3,8,2]  R1618     4.2232406139373779e-01
    z[3,8,2]  R1619     2.1507011353969574e-01
    z[3,8,2]  R1620     -1.7446257174015045e-01
    z[3,8,2]  R1621     -5.5856686085462570e-02
    z[3,8,2]  R1622     8.0902762711048126e-03
    z[3,8,2]  R1623     -1.5333354473114014e-01
    z[3,8,2]  R1624     1.4602917432785034e-01
    z[3,8,2]  R1625     2.9094228148460388e-01
    z[3,8,2]  R1626     3.6671683192253113e-01
    z[3,8,2]  R1627     4.8931926488876343e-01
    z[3,8,2]  R1628     2.4885062873363495e-01
    z[3,8,2]  R1629     -0.0532621331512928
    z[3,8,2]  R1630     -7.2313450276851654e-02
    z[3,8,2]  R1631     -2.0828001201152802e-01
    z[3,8,2]  R1632     -6.3222104310989380e-01
    z[3,8,2]  R1633     -4.7749385237693787e-01
    z[3,8,2]  R1634     -3.7537348270416260e-01
    z[3,8,2]  R1635     7.1288786828517914e-02
    z[3,8,2]  R1636     -1.4393082261085510e-01
    z[3,8,2]  R1637     -4.0629264712333679e-01
    z[3,8,2]  R1638     -1.8006415665149689e-01
    z[3,8,2]  R1639     2.5981557369232178e-01
    z[3,8,2]  R1640     5.2251034975051880e-01
    z[3,8,2]  R1641     3.0749738216400146e-01
    z[3,8,2]  R1642     5.0228524208068848e-01
    z[3,8,2]  R1643     7.8247189521789551e-01
    z[3,8,2]  R1644     -2.6841390132904053e-01
    z[3,8,2]  R1645     7.8740239143371582e-02
    z[3,8,2]  R1646     1.1565643548965454e-01
    z[3,8,2]  R1647     2.5839990004897118e-02
    z[3,8,2]  R1648     5.9660609811544418e-02
    z[3,8,2]  R1649     -2.1689200401306152e-01
    z[3,8,2]  R1650     5.4515105485916138e-01
    z[3,8,2]  R1651     4.6969360113143921e-01
    z[3,8,2]  R1652     0.602246880531311
    z[3,8,2]  R1653     7.4190104007720947e-01
    z[3,8,2]  R1654     4.8270988464355469e-01
    z[3,8,2]  R1655     9.3167677521705627e-02
    z[3,8,2]  R1656     1.3593721389770508e-01
    z[3,8,2]  R1657     2.1563434600830078e-01
    z[3,8,2]  R1658     3.4316802024841309e-01
    z[3,8,2]  R1659     3.7187594175338745e-01
    z[3,8,2]  R1660     3.0238366127014160e-01
    z[3,8,2]  R1661     2.5595375895500183e-01
    z[3,8,2]  R1662     -1.0048946738243103e-01
    z[3,8,2]  R1663     2.8736475110054016e-01
    z[3,8,2]  R1664     7.0928917266428471e-03
    z[3,8,2]  R1665     -2.4468369781970978e-02
    z[3,8,2]  R1666     -2.1538768708705902e-01
    z[3,8,2]  R1667     -8.2435399293899536e-02
    z[3,8,2]  R1668     -8.5262157022953033e-02
    z[3,8,2]  R1669     -6.4637726545333862e-01
    z[3,8,3]  R32       -1
    z[3,8,3]  R77       1
    z[3,8,3]  R1594     -1
    z[3,8,3]  R1595     1
    z[3,8,3]  R1602     -2.0729070529341698e-02
    z[3,8,3]  R1603     1.4990265481173992e-02
    z[3,8,3]  R1604     8.1128489971160889e-01
    z[3,8,3]  R1605     2.8460944071412086e-02
    z[3,8,3]  R1606     2.4128781259059906e-01
    z[3,8,3]  R1607     5.1792770624160767e-01
    z[3,8,3]  R1608     5.9925496578216553e-01
    z[3,8,3]  R1609     5.5411982536315918e-01
    z[3,8,3]  R1610     4.8862314224243164e-01
    z[3,8,3]  R1611     4.1310253739356995e-01
    z[3,8,3]  R1612     -6.5624141693115234e-01
    z[3,8,3]  R1613     -5.3472006320953369e-01
    z[3,8,3]  R1614     -0.647748589515686
    z[3,8,3]  R1615     -3.3803331851959229e-01
    z[3,8,3]  R1616     2.0410838723182678e-01
    z[3,8,3]  R1617     3.1497529149055481e-01
    z[3,8,3]  R1618     2.0240074396133423e-01
    z[3,8,3]  R1619     3.8643366098403931e-01
    z[3,8,3]  R1620     2.1542568504810333e-01
    z[3,8,3]  R1621     -0.577997088432312
    z[3,8,3]  R1622     -6.2361329793930054e-01
    z[3,8,3]  R1623     -5.4922294616699219e-01
    z[3,8,3]  R1624     -6.4651709794998169e-01
    z[3,8,3]  R1625     4.4862103462219238e-01
    z[3,8,3]  R1626     4.9435773491859436e-01
    z[3,8,3]  R1627     4.2824935913085938e-01
    z[3,8,3]  R1628     6.4358937740325928e-01
    z[3,8,3]  R1629     5.6243580579757690e-01
    z[3,8,3]  R1630     6.5955489873886108e-01
    z[3,8,3]  R1631     3.9239451289176941e-01
    z[3,8,3]  R1632     5.1759058237075806e-01
    z[3,8,3]  R1633     3.2264402508735657e-01
    z[3,8,3]  R1634     6.9359415769577026e-01
    z[3,8,3]  R1635     5.3478151559829712e-01
    z[3,8,3]  R1636     -3.4646943211555481e-01
    z[3,8,3]  R1637     -1.5794529020786285e-01
    z[3,8,3]  R1638     -4.2564994096755981e-01
    z[3,8,3]  R1639     -2.9889088869094849e-01
    z[3,8,3]  R1640     -0.246913343667984
    z[3,8,3]  R1641     -5.8031529188156128e-01
    z[3,8,3]  R1642     -4.8298770189285278e-01
    z[3,8,3]  R1643     2.2590008378028870e-01
    z[3,8,3]  R1644     -4.5573893189430237e-01
    z[3,8,3]  R1645     -7.6772612333297729e-01
    z[3,8,3]  R1646     -3.6979529261589050e-01
    z[3,8,3]  R1647     3.1639475375413895e-02
    z[3,8,3]  R1648     -1.9011195003986359e-01
    z[3,8,3]  R1649     -3.7013092637062073e-01
    z[3,8,3]  R1650     -1.6484716534614563e-01
    z[3,8,3]  R1651     -4.4422093033790588e-01
    z[3,8,3]  R1652     1.3290122151374817e-02
    z[3,8,3]  R1653     2.0788276195526123e-01
    z[3,8,3]  R1654     3.7719729542732239e-01
    z[3,8,3]  R1655     2.3343847692012787e-01
    z[3,8,3]  R1656     -1.9757138192653656e-01
    z[3,8,3]  R1657     -1.8459393084049225e-01
    z[3,8,3]  R1658     -4.4518882036209106e-01
    z[3,8,3]  R1659     -3.6890691518783569e-01
    z[3,8,3]  R1660     1.7020741105079651e-01
    z[3,8,3]  R1661     -3.6183488368988037e-01
    z[3,8,3]  R1662     -5.9311485290527344e-01
    z[3,8,3]  R1663     -0.547701895236969
    z[3,8,3]  R1664     -3.9181855320930481e-01
    z[3,8,3]  R1665     -3.5032054781913757e-01
    z[3,8,3]  R1666     -2.9732406139373779e-01
    z[3,8,3]  R1667     -2.0701327919960022e-01
    z[3,8,3]  R1668     -2.9160299897193909e-01
    z[3,8,3]  R1669     -3.5774287581443787e-01
    z[3,8,4]  R33       -1
    z[3,8,4]  R78       1
    z[3,8,4]  R1596     -1
    z[3,8,4]  R1597     1
    z[3,8,4]  R1602     -3.1282356381416321e-01
    z[3,8,4]  R1603     -4.0590861439704895e-01
    z[3,8,4]  R1604     -9.7965687513351440e-02
    z[3,8,4]  R1605     3.0620750784873962e-01
    z[3,8,4]  R1606     5.2551679313182831e-02
    z[3,8,4]  R1607     2.1951572597026825e-01
    z[3,8,4]  R1608     -1.1212415993213654e-01
    z[3,8,4]  R1609     1.7882628738880157e-01
    z[3,8,4]  R1610     8.6182296276092529e-02
    z[3,8,4]  R1611     -3.7112173438072205e-01
    z[3,8,4]  R1612     3.5811313986778259e-01
    z[3,8,4]  R1613     -6.5637670457363129e-02
    z[3,8,4]  R1614     -3.3531852066516876e-02
    z[3,8,4]  R1615     1.4174060523509979e-01
    z[3,8,4]  R1616     0.177893728017807
    z[3,8,4]  R1617     -1.0606989264488220e-01
    z[3,8,4]  R1618     -7.3660008609294891e-02
    z[3,8,4]  R1619     2.4465283751487732e-01
    z[3,8,4]  R1620     1.2989516369998455e-02
    z[3,8,4]  R1621     9.4605013728141785e-02
    z[3,8,4]  R1622     3.4848979115486145e-01
    z[3,8,4]  R1623     -3.3763018250465393e-01
    z[3,8,4]  R1624     -1.6866831481456757e-01
    z[3,8,4]  R1625     -7.3030188679695129e-02
    z[3,8,4]  R1626     -1.4280991256237030e-01
    z[3,8,4]  R1627     -5.0838004797697067e-02
    z[3,8,4]  R1628     1.5157523751258850e-01
    z[3,8,4]  R1629     1.3655400276184082e-01
    z[3,8,4]  R1630     -4.3225738406181335e-01
    z[3,8,4]  R1631     -9.6025556325912476e-02
    z[3,8,4]  R1632     -1.6930563747882843e-01
    z[3,8,4]  R1633     2.7070051431655884e-01
    z[3,8,4]  R1634     2.6033800095319748e-02
    z[3,8,4]  R1635     -3.9280074834823608e-01
    z[3,8,4]  R1636     4.7101568430662155e-02
    z[3,8,4]  R1637     2.0662312209606171e-01
    z[3,8,4]  R1638     -9.2706166207790375e-02
    z[3,8,4]  R1639     -6.0750108957290649e-01
    z[3,8,4]  R1640     4.5477354526519775e-01
    z[3,8,4]  R1641     3.3346363902091980e-01
    z[3,8,4]  R1642     -4.4939586520195007e-01
    z[3,8,4]  R1643     4.1626536846160889e-01
    z[3,8,4]  R1644     4.2432454228401184e-01
    z[3,8,4]  R1645     1.6459852457046509e-01
    z[3,8,4]  R1646     -1.6018894314765930e-01
    z[3,8,4]  R1647     4.6183064579963684e-01
    z[3,8,4]  R1648     5.1293474435806274e-01
    z[3,8,4]  R1649     -0.149389386177063
    z[3,8,4]  R1650     -2.1702152490615845e-01
    z[3,8,4]  R1651     -1.1448127776384354e-01
    z[3,8,4]  R1652     3.3909571170806885e-01
    z[3,8,4]  R1653     0.295040488243103
    z[3,8,4]  R1654     3.1525182723999023e-01
    z[3,8,4]  R1655     5.7058739662170410e-01
    z[3,8,4]  R1656     3.7303307652473450e-01
    z[3,8,4]  R1657     2.7416849136352539e-01
    z[3,8,4]  R1658     -2.0591799914836884e-01
    z[3,8,4]  R1659     1.2502770125865936e-01
    z[3,8,4]  R1660     -2.1284098923206329e-01
    z[3,8,4]  R1661     -9.3588627874851227e-02
    z[3,8,4]  R1662     2.4951553344726562e-01
    z[3,8,4]  R1663     1.8155282735824585e-01
    z[3,8,4]  R1664     1.0902238637208939e-01
    z[3,8,4]  R1665     -6.7754969000816345e-02
    z[3,8,4]  R1666     4.0493637323379517e-01
    z[3,8,4]  R1667     2.9204267263412476e-01
    z[3,8,4]  R1668     -3.8247697055339813e-02
    z[3,8,4]  R1669     8.6044125258922577e-02
    z[3,8,5]  R34       -1
    z[3,8,5]  R79       1
    z[3,8,5]  R1598     -1
    z[3,8,5]  R1599     1
    z[3,8,5]  R1602     0.261923223733902
    z[3,8,5]  R1603     2.3837955296039581e-01
    z[3,8,5]  R1604     1.7931589484214783e-01
    z[3,8,5]  R1605     9.4692386686801910e-02
    z[3,8,5]  R1606     1.1864223517477512e-02
    z[3,8,5]  R1607     9.2396877706050873e-02
    z[3,8,5]  R1608     -2.9577752947807312e-01
    z[3,8,5]  R1609     4.6932362020015717e-03
    z[3,8,5]  R1610     3.8095137476921082e-01
    z[3,8,5]  R1611     -0.177132248878479
    z[3,8,5]  R1612     -4.0599358081817627e-01
    z[3,8,5]  R1613     -4.4231596589088440e-01
    z[3,8,5]  R1614     -1.8506981432437897e-02
    z[3,8,5]  R1615     4.2402917146682739e-01
    z[3,8,5]  R1616     9.0337663888931274e-02
    z[3,8,5]  R1617     -3.2538047432899475e-01
    z[3,8,5]  R1618     -4.9688392877578735e-01
    z[3,8,5]  R1619     -6.4921134710311890e-01
    z[3,8,5]  R1620     9.4749532639980316e-02
    z[3,8,5]  R1621     -6.7315645515918732e-02
    z[3,8,5]  R1622     4.0143728256225586e-03
    z[3,8,5]  R1623     1.2150320410728455e-01
    z[3,8,5]  R1624     0.606165885925293
    z[3,8,5]  R1625     -2.0348009467124939e-01
    z[3,8,5]  R1626     -2.7250227332115173e-01
    z[3,8,5]  R1627     -4.1970375180244446e-01
    z[3,8,5]  R1628     -1.8364740908145905e-01
    z[3,8,5]  R1629     -2.4095095694065094e-01
    z[3,8,5]  R1630     -3.4856861829757690e-01
    z[3,8,5]  R1631     -5.0777328014373779e-01
    z[3,8,5]  R1632     1.1540448665618896e-01
    z[3,8,5]  R1633     3.6164134740829468e-01
    z[3,8,5]  R1634     2.1607802808284760e-01
    z[3,8,5]  R1635     3.1600460410118103e-01
    z[3,8,5]  R1636     -4.1159119457006454e-02
    z[3,8,5]  R1637     3.5393068194389343e-01
    z[3,8,5]  R1638     3.9520743489265442e-01
    z[3,8,5]  R1639     -4.0473049879074097e-01
    z[3,8,5]  R1640     -5.7212188839912415e-02
    z[3,8,5]  R1641     1.1464828858152032e-03
    z[3,8,5]  R1642     2.3619933426380157e-01
    z[3,8,5]  R1643     -0.140846386551857
    z[3,8,5]  R1644     3.9206340909004211e-01
    z[3,8,5]  R1645     4.2794889211654663e-01
    z[3,8,5]  R1646     -4.6053481101989746e-01
    z[3,8,5]  R1647     -0.180740624666214
    z[3,8,5]  R1648     3.8827037811279297e-01
    z[3,8,5]  R1649     1.4511717855930328e-01
    z[3,8,5]  R1650     2.9735869169235229e-01
    z[3,8,5]  R1651     -2.2046746744308621e-04
    z[3,8,5]  R1652     -2.1009309589862823e-01
    z[3,8,5]  R1653     1.5780338644981384e-01
    z[3,8,5]  R1654     -2.2774039208889008e-01
    z[3,8,5]  R1655     -1.0596102476119995e-01
    z[3,8,5]  R1656     9.2661440372467041e-02
    z[3,8,5]  R1657     3.6456289235502481e-03
    z[3,8,5]  R1658     -3.4275129437446594e-01
    z[3,8,5]  R1659     6.2365125864744186e-02
    z[3,8,5]  R1660     2.9562655091285706e-01
    z[3,8,5]  R1661     -2.4623703956604004e-01
    z[3,8,5]  R1662     3.3548551797866821e-01
    z[3,8,5]  R1663     -3.0170193314552307e-01
    z[3,8,5]  R1664     3.7373638153076172e-01
    z[3,8,5]  R1665     4.0881726145744324e-01
    z[3,8,5]  R1666     -1.9105147570371628e-02
    z[3,8,5]  R1667     -1.7751030623912811e-01
    z[3,8,5]  R1668     5.6372337043285370e-02
    z[3,8,5]  R1669     -3.9458981156349182e-01
    z[3,8,6]  R35       -1
    z[3,8,6]  R80       1
    z[3,8,6]  R1600     -1
    z[3,8,6]  R1601     1
    z[3,8,6]  R1602     -4.6462330222129822e-01
    z[3,8,6]  R1603     1.1685429513454437e-01
    z[3,8,6]  R1604     -1.9126628339290619e-01
    z[3,8,6]  R1605     3.5401052236557007e-01
    z[3,8,6]  R1606     3.8285449147224426e-01
    z[3,8,6]  R1607     -1.8760672211647034e-01
    z[3,8,6]  R1608     1.0930579155683517e-01
    z[3,8,6]  R1609     2.7533236145973206e-01
    z[3,8,6]  R1610     3.6939746141433716e-01
    z[3,8,6]  R1611     -1.2873359024524689e-01
    z[3,8,6]  R1612     -3.2803854346275330e-01
    z[3,8,6]  R1613     5.7653826475143433e-01
    z[3,8,6]  R1614     2.6257598400115967e-01
    z[3,8,6]  R1615     -2.5008264183998108e-01
    z[3,8,6]  R1616     -4.4959101080894470e-01
    z[3,8,6]  R1617     -7.3776558041572571e-02
    z[3,8,6]  R1618     -0.460621178150177
    z[3,8,6]  R1619     2.7532455325126648e-01
    z[3,8,6]  R1620     -1.4251363277435303e-01
    z[3,8,6]  R1621     -4.3673881888389587e-01
    z[3,8,6]  R1622     2.0005346834659576e-01
    z[3,8,6]  R1623     2.4210794270038605e-01
    z[3,8,6]  R1624     -9.9951634183526039e-03
    z[3,8,6]  R1625     5.6434098631143570e-02
    z[3,8,6]  R1626     -3.3775623887777328e-03
    z[3,8,6]  R1627     7.0777930319309235e-02
    z[3,8,6]  R1628     7.0458851754665375e-02
    z[3,8,6]  R1629     -1.7986442148685455e-01
    z[3,8,6]  R1630     1.7721045017242432e-01
    z[3,8,6]  R1631     -3.3603328466415405e-01
    z[3,8,6]  R1632     -2.1940669417381287e-01
    z[3,8,6]  R1633     2.0136786997318268e-01
    z[3,8,6]  R1634     4.3996366858482361e-01
    z[3,8,6]  R1635     -2.1231368184089661e-01
    z[3,8,6]  R1636     -0.74248868227005
    z[3,8,6]  R1637     1.8393740057945251e-01
    z[3,8,6]  R1638     3.4053787589073181e-01
    z[3,8,6]  R1639     -3.7462761998176575e-01
    z[3,8,6]  R1640     7.9711131751537323e-02
    z[3,8,6]  R1641     2.2581171244382858e-02
    z[3,8,6]  R1642     -1.0665111243724823e-01
    z[3,8,6]  R1643     -1.7846764624118805e-01
    z[3,8,6]  R1644     -1.1625920981168747e-01
    z[3,8,6]  R1645     1.3823738694190979e-01
    z[3,8,6]  R1646     -1.4971335232257843e-01
    z[3,8,6]  R1647     2.9012712836265564e-01
    z[3,8,6]  R1648     0.0484800711274147
    z[3,8,6]  R1649     -1.9107541441917419e-01
    z[3,8,6]  R1650     4.3508040904998779e-01
    z[3,8,6]  R1651     1.4908677339553833e-01
    z[3,8,6]  R1652     3.7774410843849182e-01
    z[3,8,6]  R1653     9.7708672285079956e-02
    z[3,8,6]  R1654     1.3283225893974304e-01
    z[3,8,6]  R1655     -2.4021410942077637e-01
    z[3,8,6]  R1656     -5.6193929910659790e-01
    z[3,8,6]  R1657     1.6421730816364288e-01
    z[3,8,6]  R1658     -4.4859539717435837e-02
    z[3,8,6]  R1659     5.2844703197479248e-01
    z[3,8,6]  R1660     7.6997667551040649e-02
    z[3,8,6]  R1661     -1.7033047974109650e-01
    z[3,8,6]  R1662     -2.0931231847498566e-04
    z[3,8,6]  R1663     2.0268309116363525e-01
    z[3,8,6]  R1664     1.8692786991596222e-01
    z[3,8,6]  R1665     -0.0870007872581482
    z[3,8,6]  R1666     -1.9909110665321350e-01
    z[3,8,6]  R1667     -3.3920624852180481e-01
    z[3,8,6]  R1668     1.8302412331104279e-01
    z[3,8,6]  R1669     4.4053849577903748e-01
    z[8,3,0]  R29       1
    z[8,3,0]  R74       -1
    z[8,3,0]  R1670     -1
    z[8,3,0]  R1671     1
    z[8,3,0]  R1684     -4.4458016753196716e-01
    z[8,3,0]  R1685     -5.4850107431411743e-01
    z[8,3,0]  R1686     -4.5679804682731628e-01
    z[8,3,0]  R1687     -5.3019177913665771e-01
    z[8,3,0]  R1688     -2.9695528745651245e-01
    z[8,3,0]  R1689     0.423216313123703
    z[8,3,0]  R1690     4.9933582544326782e-01
    z[8,3,0]  R1691     3.6802518367767334e-01
    z[8,3,0]  R1692     -2.4371489882469177e-02
    z[8,3,0]  R1693     3.4120373427867889e-02
    z[8,3,0]  R1694     -3.4763745963573456e-02
    z[8,3,0]  R1695     5.6848841905593872e-01
    z[8,3,0]  R1696     -3.4385025501251221e-01
    z[8,3,0]  R1697     1.7285591363906860e-01
    z[8,3,0]  R1698     4.4793954491615295e-01
    z[8,3,0]  R1699     8.7197288870811462e-02
    z[8,3,0]  R1700     2.3777349293231964e-01
    z[8,3,0]  R1701     6.7076951265335083e-01
    z[8,3,0]  R1702     7.3758906126022339e-01
    z[8,3,0]  R1703     3.9325261116027832e-01
    z[8,3,0]  R1704     -3.5049572587013245e-01
    z[8,3,0]  R1705     -6.2821739912033081e-01
    z[8,3,0]  R1706     -4.1651833802461624e-02
    z[8,3,0]  R1707     -1.3105449080467224e-01
    z[8,3,0]  R1708     3.7713015079498291e-01
    z[8,3,0]  R1709     4.3652275204658508e-01
    z[8,3,0]  R1710     2.2517924010753632e-01
    z[8,3,0]  R1711     8.0271774530410767e-01
    z[8,3,0]  R1712     3.5582551360130310e-01
    z[8,3,0]  R1713     4.1191452741622925e-01
    z[8,3,0]  R1714     -3.2250946760177612e-01
    z[8,3,0]  R1715     0.61336749792099
    z[8,3,0]  R1716     3.8357287645339966e-01
    z[8,3,0]  R1717     2.3956814408302307e-01
    z[8,3,0]  R1718     5.6480652093887329e-01
    z[8,3,0]  R1719     6.6074001789093018e-01
    z[8,3,0]  R1720     5.9936910867691040e-01
    z[8,3,0]  R1721     7.1849167346954346e-01
    z[8,3,0]  R1722     4.0731152892112732e-01
    z[8,3,0]  R1723     3.0544099211692810e-01
    z[8,3,0]  R1724     -3.8177676498889923e-02
    z[8,3,0]  R1725     4.8281392455101013e-01
    z[8,3,0]  R1726     -5.0466382503509521e-01
    z[8,3,0]  R1727     -5.7353466749191284e-01
    z[8,3,0]  R1728     1.0525610297918320e-01
    z[8,3,0]  R1729     -7.7337872982025146e-01
    z[8,3,0]  R1730     -6.4111167192459106e-01
    z[8,3,0]  R1731     -6.9564241170883179e-01
    z[8,3,0]  R1732     -6.2685352563858032e-01
    z[8,3,0]  R1733     -0.719005286693573
    z[8,3,0]  R1734     -3.7654018402099609e-01
    z[8,3,0]  R1735     1.6541968286037445e-01
    z[8,3,0]  R1736     9.5905058085918427e-02
    z[8,3,0]  R1737     -4.5115888118743896e-02
    z[8,3,0]  R1738     2.8157824277877808e-01
    z[8,3,0]  R1739     3.9633381366729736e-01
    z[8,3,0]  R1740     4.0888580679893494e-01
    z[8,3,0]  R1741     4.4836091995239258e-01
    z[8,3,0]  R1742     0.575560986995697
    z[8,3,0]  R1743     4.1028848290443420e-01
    z[8,3,0]  R1744     2.2562281787395477e-01
    z[8,3,0]  R1745     -2.0755213499069214e-01
    z[8,3,0]  R1746     -3.9948263764381409e-01
    z[8,3,0]  R1747     3.1391668319702148e-01
    z[8,3,0]  R1748     3.6903870105743408e-01
    z[8,3,0]  R1749     2.7826866507530212e-01
    z[8,3,0]  R1750     5.2810066938400269e-01
    z[8,3,0]  R1751     4.2486450076103210e-01
    z[8,3,1]  R30       1
    z[8,3,1]  R75       -1
    z[8,3,1]  R1672     -1
    z[8,3,1]  R1673     1
    z[8,3,1]  R1684     -1.4952081441879272e-01
    z[8,3,1]  R1685     -3.4902659058570862e-01
    z[8,3,1]  R1686     -1.8333059549331665e-01
    z[8,3,1]  R1687     -3.7707424163818359e-01
    z[8,3,1]  R1688     -2.2114260494709015e-01
    z[8,3,1]  R1689     -4.8019373416900635e-01
    z[8,3,1]  R1690     2.3389001190662384e-01
    z[8,3,1]  R1691     6.8756383657455444e-01
    z[8,3,1]  R1692     7.1067267656326294e-01
    z[8,3,1]  R1693     4.1083535552024841e-01
    z[8,3,1]  R1694     -6.6959851980209351e-01
    z[8,3,1]  R1695     3.6577469110488892e-01
    z[8,3,1]  R1696     -3.5648050904273987e-01
    z[8,3,1]  R1697     -2.8611627221107483e-01
    z[8,3,1]  R1698     4.1512030363082886e-01
    z[8,3,1]  R1699     4.0920725464820862e-01
    z[8,3,1]  R1700     7.3018616437911987e-01
    z[8,3,1]  R1701     4.6719476580619812e-01
    z[8,3,1]  R1702     7.3564932681620121e-03
    z[8,3,1]  R1703     7.6251387596130371e-01
    z[8,3,1]  R1704     -4.7746515274047852e-01
    z[8,3,1]  R1705     -0.389955997467041
    z[8,3,1]  R1706     -5.7755655050277710e-01
    z[8,3,1]  R1707     -0.517392098903656
    z[8,3,1]  R1708     -5.5999320745468140e-01
    z[8,3,1]  R1709     -5.9310501813888550e-01
    z[8,3,1]  R1710     -6.5441983938217163e-01
    z[8,3,1]  R1711     4.1583898663520813e-01
    z[8,3,1]  R1712     6.2891805171966553e-01
    z[8,3,1]  R1713     5.0711423158645630e-01
    z[8,3,1]  R1714     -7.9809540510177612e-01
    z[8,3,1]  R1715     5.7353240251541138e-01
    z[8,3,1]  R1716     5.6229871511459351e-01
    z[8,3,1]  R1717     6.2847858667373657e-01
    z[8,3,1]  R1718     5.8387905359268188e-01
    z[8,3,1]  R1719     5.1069349050521851e-01
    z[8,3,1]  R1720     5.4953384399414062e-01
    z[8,3,1]  R1721     4.4973301887512207e-01
    z[8,3,1]  R1722     8.3884263038635254e-01
    z[8,3,1]  R1723     -6.1183761805295944e-02
    z[8,3,1]  R1724     -2.2855930030345917e-01
    z[8,3,1]  R1725     -2.2460272908210754e-01
    z[8,3,1]  R1726     3.2066803425550461e-02
    z[8,3,1]  R1727     -2.4953939020633698e-01
    z[8,3,1]  R1728     -3.4873235225677490e-01
    z[8,3,1]  R1729     8.6467780172824860e-02
    z[8,3,1]  R1730     1.0977321863174438e-01
    z[8,3,1]  R1731     1.7737165093421936e-01
    z[8,3,1]  R1732     6.5116435289382935e-02
    z[8,3,1]  R1733     2.6427105069160461e-01
    z[8,3,1]  R1734     1.6233828663825989e-01
    z[8,3,1]  R1735     3.5085299611091614e-01
    z[8,3,1]  R1736     3.7565350532531738e-01
    z[8,3,1]  R1737     -6.6838508844375610e-01
    z[8,3,1]  R1738     -7.0583873987197876e-01
    z[8,3,1]  R1739     7.8617835044860840e-01
    z[8,3,1]  R1740     3.8600188493728638e-01
    z[8,3,1]  R1741     2.1506385505199432e-01
    z[8,3,1]  R1742     -7.4995177984237671e-01
    z[8,3,1]  R1743     -5.3873974084854126e-01
    z[8,3,1]  R1744     -6.3138955831527710e-01
    z[8,3,1]  R1745     6.6662716865539551e-01
    z[8,3,1]  R1746     -7.1545474231243134e-02
    z[8,3,1]  R1747     7.5208085775375366e-01
    z[8,3,1]  R1748     6.2472069263458252e-01
    z[8,3,1]  R1749     5.6213027238845825e-01
    z[8,3,1]  R1750     4.2814698815345764e-01
    z[8,3,1]  R1751     6.2551081180572510e-01
    z[8,3,2]  R31       1
    z[8,3,2]  R76       -1
    z[8,3,2]  R1674     -1
    z[8,3,2]  R1675     1
    z[8,3,2]  R1684     -7.2313450276851654e-02
    z[8,3,2]  R1685     -2.0828001201152802e-01
    z[8,3,2]  R1686     -6.3222104310989380e-01
    z[8,3,2]  R1687     -4.7749385237693787e-01
    z[8,3,2]  R1688     -3.7537348270416260e-01
    z[8,3,2]  R1689     7.1288786828517914e-02
    z[8,3,2]  R1690     -1.4393082261085510e-01
    z[8,3,2]  R1691     -4.0629264712333679e-01
    z[8,3,2]  R1692     -1.8006415665149689e-01
    z[8,3,2]  R1693     2.5981557369232178e-01
    z[8,3,2]  R1694     5.2251034975051880e-01
    z[8,3,2]  R1695     3.0749738216400146e-01
    z[8,3,2]  R1696     5.0228524208068848e-01
    z[8,3,2]  R1697     7.8247189521789551e-01
    z[8,3,2]  R1698     -2.6841390132904053e-01
    z[8,3,2]  R1699     7.8740239143371582e-02
    z[8,3,2]  R1700     1.1565643548965454e-01
    z[8,3,2]  R1701     2.5839990004897118e-02
    z[8,3,2]  R1702     5.9660609811544418e-02
    z[8,3,2]  R1703     -2.1689200401306152e-01
    z[8,3,2]  R1704     5.4515105485916138e-01
    z[8,3,2]  R1705     4.6969360113143921e-01
    z[8,3,2]  R1706     0.602246880531311
    z[8,3,2]  R1707     7.4190104007720947e-01
    z[8,3,2]  R1708     4.8270988464355469e-01
    z[8,3,2]  R1709     9.3167677521705627e-02
    z[8,3,2]  R1710     1.3593721389770508e-01
    z[8,3,2]  R1711     2.1563434600830078e-01
    z[8,3,2]  R1712     3.4316802024841309e-01
    z[8,3,2]  R1713     3.7187594175338745e-01
    z[8,3,2]  R1714     3.0238366127014160e-01
    z[8,3,2]  R1715     2.5595375895500183e-01
    z[8,3,2]  R1716     -1.0048946738243103e-01
    z[8,3,2]  R1717     2.8736475110054016e-01
    z[8,3,2]  R1718     7.0928917266428471e-03
    z[8,3,2]  R1719     -2.4468369781970978e-02
    z[8,3,2]  R1720     -2.1538768708705902e-01
    z[8,3,2]  R1721     -8.2435399293899536e-02
    z[8,3,2]  R1722     -8.5262157022953033e-02
    z[8,3,2]  R1723     -6.4637726545333862e-01
    z[8,3,2]  R1724     -7.5069051980972290e-01
    z[8,3,2]  R1725     -6.9352585077285767e-01
    z[8,3,2]  R1726     0.0881400927901268
    z[8,3,2]  R1727     -0.616380512714386
    z[8,3,2]  R1728     -0.812161922454834
    z[8,3,2]  R1729     1.8503734469413757e-01
    z[8,3,2]  R1730     3.2529249787330627e-01
    z[8,3,2]  R1731     -2.6412791013717651e-01
    z[8,3,2]  R1732     2.7396348118782043e-01
    z[8,3,2]  R1733     -2.3845118284225464e-01
    z[8,3,2]  R1734     -2.2934272885322571e-02
    z[8,3,2]  R1735     1.7681892216205597e-01
    z[8,3,2]  R1736     5.9974616765975952e-01
    z[8,3,2]  R1737     4.1776421666145325e-01
    z[8,3,2]  R1738     3.7270089983940125e-01
    z[8,3,2]  R1739     -5.5384196341037750e-02
    z[8,3,2]  R1740     4.2232406139373779e-01
    z[8,3,2]  R1741     2.1507011353969574e-01
    z[8,3,2]  R1742     -1.7446257174015045e-01
    z[8,3,2]  R1743     -5.5856686085462570e-02
    z[8,3,2]  R1744     8.0902762711048126e-03
    z[8,3,2]  R1745     -1.5333354473114014e-01
    z[8,3,2]  R1746     1.4602917432785034e-01
    z[8,3,2]  R1747     2.9094228148460388e-01
    z[8,3,2]  R1748     3.6671683192253113e-01
    z[8,3,2]  R1749     4.8931926488876343e-01
    z[8,3,2]  R1750     2.4885062873363495e-01
    z[8,3,2]  R1751     -0.0532621331512928
    z[8,3,3]  R32       1
    z[8,3,3]  R77       -1
    z[8,3,3]  R1676     -1
    z[8,3,3]  R1677     1
    z[8,3,3]  R1684     6.5955489873886108e-01
    z[8,3,3]  R1685     3.9239451289176941e-01
    z[8,3,3]  R1686     5.1759058237075806e-01
    z[8,3,3]  R1687     3.2264402508735657e-01
    z[8,3,3]  R1688     6.9359415769577026e-01
    z[8,3,3]  R1689     5.3478151559829712e-01
    z[8,3,3]  R1690     -3.4646943211555481e-01
    z[8,3,3]  R1691     -1.5794529020786285e-01
    z[8,3,3]  R1692     -4.2564994096755981e-01
    z[8,3,3]  R1693     -2.9889088869094849e-01
    z[8,3,3]  R1694     -0.246913343667984
    z[8,3,3]  R1695     -5.8031529188156128e-01
    z[8,3,3]  R1696     -4.8298770189285278e-01
    z[8,3,3]  R1697     2.2590008378028870e-01
    z[8,3,3]  R1698     -4.5573893189430237e-01
    z[8,3,3]  R1699     -7.6772612333297729e-01
    z[8,3,3]  R1700     -3.6979529261589050e-01
    z[8,3,3]  R1701     3.1639475375413895e-02
    z[8,3,3]  R1702     -1.9011195003986359e-01
    z[8,3,3]  R1703     -3.7013092637062073e-01
    z[8,3,3]  R1704     -1.6484716534614563e-01
    z[8,3,3]  R1705     -4.4422093033790588e-01
    z[8,3,3]  R1706     1.3290122151374817e-02
    z[8,3,3]  R1707     2.0788276195526123e-01
    z[8,3,3]  R1708     3.7719729542732239e-01
    z[8,3,3]  R1709     2.3343847692012787e-01
    z[8,3,3]  R1710     -1.9757138192653656e-01
    z[8,3,3]  R1711     -1.8459393084049225e-01
    z[8,3,3]  R1712     -4.4518882036209106e-01
    z[8,3,3]  R1713     -3.6890691518783569e-01
    z[8,3,3]  R1714     1.7020741105079651e-01
    z[8,3,3]  R1715     -3.6183488368988037e-01
    z[8,3,3]  R1716     -5.9311485290527344e-01
    z[8,3,3]  R1717     -0.547701895236969
    z[8,3,3]  R1718     -3.9181855320930481e-01
    z[8,3,3]  R1719     -3.5032054781913757e-01
    z[8,3,3]  R1720     -2.9732406139373779e-01
    z[8,3,3]  R1721     -2.0701327919960022e-01
    z[8,3,3]  R1722     -2.9160299897193909e-01
    z[8,3,3]  R1723     -3.5774287581443787e-01
    z[8,3,3]  R1724     -2.0729070529341698e-02
    z[8,3,3]  R1725     1.4990265481173992e-02
    z[8,3,3]  R1726     8.1128489971160889e-01
    z[8,3,3]  R1727     2.8460944071412086e-02
    z[8,3,3]  R1728     2.4128781259059906e-01
    z[8,3,3]  R1729     5.1792770624160767e-01
    z[8,3,3]  R1730     5.9925496578216553e-01
    z[8,3,3]  R1731     5.5411982536315918e-01
    z[8,3,3]  R1732     4.8862314224243164e-01
    z[8,3,3]  R1733     4.1310253739356995e-01
    z[8,3,3]  R1734     -6.5624141693115234e-01
    z[8,3,3]  R1735     -5.3472006320953369e-01
    z[8,3,3]  R1736     -0.647748589515686
    z[8,3,3]  R1737     -3.3803331851959229e-01
    z[8,3,3]  R1738     2.0410838723182678e-01
    z[8,3,3]  R1739     3.1497529149055481e-01
    z[8,3,3]  R1740     2.0240074396133423e-01
    z[8,3,3]  R1741     3.8643366098403931e-01
    z[8,3,3]  R1742     2.1542568504810333e-01
    z[8,3,3]  R1743     -0.577997088432312
    z[8,3,3]  R1744     -6.2361329793930054e-01
    z[8,3,3]  R1745     -5.4922294616699219e-01
    z[8,3,3]  R1746     -6.4651709794998169e-01
    z[8,3,3]  R1747     4.4862103462219238e-01
    z[8,3,3]  R1748     4.9435773491859436e-01
    z[8,3,3]  R1749     4.2824935913085938e-01
    z[8,3,3]  R1750     6.4358937740325928e-01
    z[8,3,3]  R1751     5.6243580579757690e-01
    z[8,3,4]  R33       1
    z[8,3,4]  R78       -1
    z[8,3,4]  R1678     -1
    z[8,3,4]  R1679     1
    z[8,3,4]  R1684     -4.3225738406181335e-01
    z[8,3,4]  R1685     -9.6025556325912476e-02
    z[8,3,4]  R1686     -1.6930563747882843e-01
    z[8,3,4]  R1687     2.7070051431655884e-01
    z[8,3,4]  R1688     2.6033800095319748e-02
    z[8,3,4]  R1689     -3.9280074834823608e-01
    z[8,3,4]  R1690     4.7101568430662155e-02
    z[8,3,4]  R1691     2.0662312209606171e-01
    z[8,3,4]  R1692     -9.2706166207790375e-02
    z[8,3,4]  R1693     -6.0750108957290649e-01
    z[8,3,4]  R1694     4.5477354526519775e-01
    z[8,3,4]  R1695     3.3346363902091980e-01
    z[8,3,4]  R1696     -4.4939586520195007e-01
    z[8,3,4]  R1697     4.1626536846160889e-01
    z[8,3,4]  R1698     4.2432454228401184e-01
    z[8,3,4]  R1699     1.6459852457046509e-01
    z[8,3,4]  R1700     -1.6018894314765930e-01
    z[8,3,4]  R1701     4.6183064579963684e-01
    z[8,3,4]  R1702     5.1293474435806274e-01
    z[8,3,4]  R1703     -0.149389386177063
    z[8,3,4]  R1704     -2.1702152490615845e-01
    z[8,3,4]  R1705     -1.1448127776384354e-01
    z[8,3,4]  R1706     3.3909571170806885e-01
    z[8,3,4]  R1707     0.295040488243103
    z[8,3,4]  R1708     3.1525182723999023e-01
    z[8,3,4]  R1709     5.7058739662170410e-01
    z[8,3,4]  R1710     3.7303307652473450e-01
    z[8,3,4]  R1711     2.7416849136352539e-01
    z[8,3,4]  R1712     -2.0591799914836884e-01
    z[8,3,4]  R1713     1.2502770125865936e-01
    z[8,3,4]  R1714     -2.1284098923206329e-01
    z[8,3,4]  R1715     -9.3588627874851227e-02
    z[8,3,4]  R1716     2.4951553344726562e-01
    z[8,3,4]  R1717     1.8155282735824585e-01
    z[8,3,4]  R1718     1.0902238637208939e-01
    z[8,3,4]  R1719     -6.7754969000816345e-02
    z[8,3,4]  R1720     4.0493637323379517e-01
    z[8,3,4]  R1721     2.9204267263412476e-01
    z[8,3,4]  R1722     -3.8247697055339813e-02
    z[8,3,4]  R1723     8.6044125258922577e-02
    z[8,3,4]  R1724     -3.1282356381416321e-01
    z[8,3,4]  R1725     -4.0590861439704895e-01
    z[8,3,4]  R1726     -9.7965687513351440e-02
    z[8,3,4]  R1727     3.0620750784873962e-01
    z[8,3,4]  R1728     5.2551679313182831e-02
    z[8,3,4]  R1729     2.1951572597026825e-01
    z[8,3,4]  R1730     -1.1212415993213654e-01
    z[8,3,4]  R1731     1.7882628738880157e-01
    z[8,3,4]  R1732     8.6182296276092529e-02
    z[8,3,4]  R1733     -3.7112173438072205e-01
    z[8,3,4]  R1734     3.5811313986778259e-01
    z[8,3,4]  R1735     -6.5637670457363129e-02
    z[8,3,4]  R1736     -3.3531852066516876e-02
    z[8,3,4]  R1737     1.4174060523509979e-01
    z[8,3,4]  R1738     0.177893728017807
    z[8,3,4]  R1739     -1.0606989264488220e-01
    z[8,3,4]  R1740     -7.3660008609294891e-02
    z[8,3,4]  R1741     2.4465283751487732e-01
    z[8,3,4]  R1742     1.2989516369998455e-02
    z[8,3,4]  R1743     9.4605013728141785e-02
    z[8,3,4]  R1744     3.4848979115486145e-01
    z[8,3,4]  R1745     -3.3763018250465393e-01
    z[8,3,4]  R1746     -1.6866831481456757e-01
    z[8,3,4]  R1747     -7.3030188679695129e-02
    z[8,3,4]  R1748     -1.4280991256237030e-01
    z[8,3,4]  R1749     -5.0838004797697067e-02
    z[8,3,4]  R1750     1.5157523751258850e-01
    z[8,3,4]  R1751     1.3655400276184082e-01
    z[8,3,5]  R34       1
    z[8,3,5]  R79       -1
    z[8,3,5]  R1680     -1
    z[8,3,5]  R1681     1
    z[8,3,5]  R1684     -3.4856861829757690e-01
    z[8,3,5]  R1685     -5.0777328014373779e-01
    z[8,3,5]  R1686     1.1540448665618896e-01
    z[8,3,5]  R1687     3.6164134740829468e-01
    z[8,3,5]  R1688     2.1607802808284760e-01
    z[8,3,5]  R1689     3.1600460410118103e-01
    z[8,3,5]  R1690     -4.1159119457006454e-02
    z[8,3,5]  R1691     3.5393068194389343e-01
    z[8,3,5]  R1692     3.9520743489265442e-01
    z[8,3,5]  R1693     -4.0473049879074097e-01
    z[8,3,5]  R1694     -5.7212188839912415e-02
    z[8,3,5]  R1695     1.1464828858152032e-03
    z[8,3,5]  R1696     2.3619933426380157e-01
    z[8,3,5]  R1697     -0.140846386551857
    z[8,3,5]  R1698     3.9206340909004211e-01
    z[8,3,5]  R1699     4.2794889211654663e-01
    z[8,3,5]  R1700     -4.6053481101989746e-01
    z[8,3,5]  R1701     -0.180740624666214
    z[8,3,5]  R1702     3.8827037811279297e-01
    z[8,3,5]  R1703     1.4511717855930328e-01
    z[8,3,5]  R1704     2.9735869169235229e-01
    z[8,3,5]  R1705     -2.2046746744308621e-04
    z[8,3,5]  R1706     -2.1009309589862823e-01
    z[8,3,5]  R1707     1.5780338644981384e-01
    z[8,3,5]  R1708     -2.2774039208889008e-01
    z[8,3,5]  R1709     -1.0596102476119995e-01
    z[8,3,5]  R1710     9.2661440372467041e-02
    z[8,3,5]  R1711     3.6456289235502481e-03
    z[8,3,5]  R1712     -3.4275129437446594e-01
    z[8,3,5]  R1713     6.2365125864744186e-02
    z[8,3,5]  R1714     2.9562655091285706e-01
    z[8,3,5]  R1715     -2.4623703956604004e-01
    z[8,3,5]  R1716     3.3548551797866821e-01
    z[8,3,5]  R1717     -3.0170193314552307e-01
    z[8,3,5]  R1718     3.7373638153076172e-01
    z[8,3,5]  R1719     4.0881726145744324e-01
    z[8,3,5]  R1720     -1.9105147570371628e-02
    z[8,3,5]  R1721     -1.7751030623912811e-01
    z[8,3,5]  R1722     5.6372337043285370e-02
    z[8,3,5]  R1723     -3.9458981156349182e-01
    z[8,3,5]  R1724     0.261923223733902
    z[8,3,5]  R1725     2.3837955296039581e-01
    z[8,3,5]  R1726     1.7931589484214783e-01
    z[8,3,5]  R1727     9.4692386686801910e-02
    z[8,3,5]  R1728     1.1864223517477512e-02
    z[8,3,5]  R1729     9.2396877706050873e-02
    z[8,3,5]  R1730     -2.9577752947807312e-01
    z[8,3,5]  R1731     4.6932362020015717e-03
    z[8,3,5]  R1732     3.8095137476921082e-01
    z[8,3,5]  R1733     -0.177132248878479
    z[8,3,5]  R1734     -4.0599358081817627e-01
    z[8,3,5]  R1735     -4.4231596589088440e-01
    z[8,3,5]  R1736     -1.8506981432437897e-02
    z[8,3,5]  R1737     4.2402917146682739e-01
    z[8,3,5]  R1738     9.0337663888931274e-02
    z[8,3,5]  R1739     -3.2538047432899475e-01
    z[8,3,5]  R1740     -4.9688392877578735e-01
    z[8,3,5]  R1741     -6.4921134710311890e-01
    z[8,3,5]  R1742     9.4749532639980316e-02
    z[8,3,5]  R1743     -6.7315645515918732e-02
    z[8,3,5]  R1744     4.0143728256225586e-03
    z[8,3,5]  R1745     1.2150320410728455e-01
    z[8,3,5]  R1746     0.606165885925293
    z[8,3,5]  R1747     -2.0348009467124939e-01
    z[8,3,5]  R1748     -2.7250227332115173e-01
    z[8,3,5]  R1749     -4.1970375180244446e-01
    z[8,3,5]  R1750     -1.8364740908145905e-01
    z[8,3,5]  R1751     -2.4095095694065094e-01
    z[8,3,6]  R35       1
    z[8,3,6]  R80       -1
    z[8,3,6]  R1682     -1
    z[8,3,6]  R1683     1
    z[8,3,6]  R1684     1.7721045017242432e-01
    z[8,3,6]  R1685     -3.3603328466415405e-01
    z[8,3,6]  R1686     -2.1940669417381287e-01
    z[8,3,6]  R1687     2.0136786997318268e-01
    z[8,3,6]  R1688     4.3996366858482361e-01
    z[8,3,6]  R1689     -2.1231368184089661e-01
    z[8,3,6]  R1690     -0.74248868227005
    z[8,3,6]  R1691     1.8393740057945251e-01
    z[8,3,6]  R1692     3.4053787589073181e-01
    z[8,3,6]  R1693     -3.7462761998176575e-01
    z[8,3,6]  R1694     7.9711131751537323e-02
    z[8,3,6]  R1695     2.2581171244382858e-02
    z[8,3,6]  R1696     -1.0665111243724823e-01
    z[8,3,6]  R1697     -1.7846764624118805e-01
    z[8,3,6]  R1698     -1.1625920981168747e-01
    z[8,3,6]  R1699     1.3823738694190979e-01
    z[8,3,6]  R1700     -1.4971335232257843e-01
    z[8,3,6]  R1701     2.9012712836265564e-01
    z[8,3,6]  R1702     0.0484800711274147
    z[8,3,6]  R1703     -1.9107541441917419e-01
    z[8,3,6]  R1704     4.3508040904998779e-01
    z[8,3,6]  R1705     1.4908677339553833e-01
    z[8,3,6]  R1706     3.7774410843849182e-01
    z[8,3,6]  R1707     9.7708672285079956e-02
    z[8,3,6]  R1708     1.3283225893974304e-01
    z[8,3,6]  R1709     -2.4021410942077637e-01
    z[8,3,6]  R1710     -5.6193929910659790e-01
    z[8,3,6]  R1711     1.6421730816364288e-01
    z[8,3,6]  R1712     -4.4859539717435837e-02
    z[8,3,6]  R1713     5.2844703197479248e-01
    z[8,3,6]  R1714     7.6997667551040649e-02
    z[8,3,6]  R1715     -1.7033047974109650e-01
    z[8,3,6]  R1716     -2.0931231847498566e-04
    z[8,3,6]  R1717     2.0268309116363525e-01
    z[8,3,6]  R1718     1.8692786991596222e-01
    z[8,3,6]  R1719     -0.0870007872581482
    z[8,3,6]  R1720     -1.9909110665321350e-01
    z[8,3,6]  R1721     -3.3920624852180481e-01
    z[8,3,6]  R1722     1.8302412331104279e-01
    z[8,3,6]  R1723     4.4053849577903748e-01
    z[8,3,6]  R1724     -4.6462330222129822e-01
    z[8,3,6]  R1725     1.1685429513454437e-01
    z[8,3,6]  R1726     -1.9126628339290619e-01
    z[8,3,6]  R1727     3.5401052236557007e-01
    z[8,3,6]  R1728     3.8285449147224426e-01
    z[8,3,6]  R1729     -1.8760672211647034e-01
    z[8,3,6]  R1730     1.0930579155683517e-01
    z[8,3,6]  R1731     2.7533236145973206e-01
    z[8,3,6]  R1732     3.6939746141433716e-01
    z[8,3,6]  R1733     -1.2873359024524689e-01
    z[8,3,6]  R1734     -3.2803854346275330e-01
    z[8,3,6]  R1735     5.7653826475143433e-01
    z[8,3,6]  R1736     2.6257598400115967e-01
    z[8,3,6]  R1737     -2.5008264183998108e-01
    z[8,3,6]  R1738     -4.4959101080894470e-01
    z[8,3,6]  R1739     -7.3776558041572571e-02
    z[8,3,6]  R1740     -0.460621178150177
    z[8,3,6]  R1741     2.7532455325126648e-01
    z[8,3,6]  R1742     -1.4251363277435303e-01
    z[8,3,6]  R1743     -4.3673881888389587e-01
    z[8,3,6]  R1744     2.0005346834659576e-01
    z[8,3,6]  R1745     2.4210794270038605e-01
    z[8,3,6]  R1746     -9.9951634183526039e-03
    z[8,3,6]  R1747     5.6434098631143570e-02
    z[8,3,6]  R1748     -3.3775623887777328e-03
    z[8,3,6]  R1749     7.0777930319309235e-02
    z[8,3,6]  R1750     7.0458851754665375e-02
    z[8,3,6]  R1751     -1.7986442148685455e-01
    z[3,9,0]  R29       -1
    z[3,9,0]  R83       1
    z[3,9,0]  R1752     -1
    z[3,9,0]  R1753     1
    z[3,9,0]  R1766     -3.8177676498889923e-02
    z[3,9,0]  R1767     4.8281392455101013e-01
    z[3,9,0]  R1768     -5.0466382503509521e-01
    z[3,9,0]  R1769     -5.7353466749191284e-01
    z[3,9,0]  R1770     1.0525610297918320e-01
    z[3,9,0]  R1771     -7.7337872982025146e-01
    z[3,9,0]  R1772     -6.4111167192459106e-01
    z[3,9,0]  R1773     -6.9564241170883179e-01
    z[3,9,0]  R1774     -6.2685352563858032e-01
    z[3,9,0]  R1775     -0.719005286693573
    z[3,9,0]  R1776     -3.7654018402099609e-01
    z[3,9,0]  R1777     1.6541968286037445e-01
    z[3,9,0]  R1778     9.5905058085918427e-02
    z[3,9,0]  R1779     -4.5115888118743896e-02
    z[3,9,0]  R1780     2.8157824277877808e-01
    z[3,9,0]  R1781     3.9633381366729736e-01
    z[3,9,0]  R1782     4.0888580679893494e-01
    z[3,9,0]  R1783     4.4836091995239258e-01
    z[3,9,0]  R1784     0.575560986995697
    z[3,9,0]  R1785     4.1028848290443420e-01
    z[3,9,0]  R1786     2.2562281787395477e-01
    z[3,9,0]  R1787     -2.0755213499069214e-01
    z[3,9,0]  R1788     -3.9948263764381409e-01
    z[3,9,0]  R1789     3.1391668319702148e-01
    z[3,9,0]  R1790     3.6903870105743408e-01
    z[3,9,0]  R1791     2.7826866507530212e-01
    z[3,9,0]  R1792     5.2810066938400269e-01
    z[3,9,0]  R1793     4.2486450076103210e-01
    z[3,9,0]  R1794     -6.4548724889755249e-01
    z[3,9,0]  R1795     -4.4700339436531067e-01
    z[3,9,0]  R1796     -5.7674968242645264e-01
    z[3,9,0]  R1797     -5.1093703508377075e-01
    z[3,9,0]  R1798     -1.0504309833049774e-01
    z[3,9,0]  R1799     -1.6773472726345062e-01
    z[3,9,0]  R1800     -4.2771536111831665e-01
    z[3,9,0]  R1801     3.5226613283157349e-01
    z[3,9,0]  R1802     1.7311668395996094e-01
    z[3,9,0]  R1803     4.0123113989830017e-01
    z[3,9,0]  R1804     0.0276805367320776
    z[3,9,0]  R1805     -3.9720579981803894e-01
    z[3,9,0]  R1806     -2.8522130846977234e-01
    z[3,9,0]  R1807     -6.4319148659706116e-02
    z[3,9,0]  R1808     6.8526464700698853e-01
    z[3,9,0]  R1809     3.9928045868873596e-01
    z[3,9,0]  R1810     -2.7383902668952942e-01
    z[3,9,0]  R1811     2.9671835899353027e-01
    z[3,9,0]  R1812     5.3257542848587036e-01
    z[3,9,0]  R1813     3.9325863122940063e-01
    z[3,9,0]  R1814     3.3369913697242737e-01
    z[3,9,0]  R1815     4.9956884980201721e-01
    z[3,9,0]  R1816     2.3757702112197876e-01
    z[3,9,0]  R1817     3.2133832573890686e-01
    z[3,9,0]  R1818     3.3036302775144577e-02
    z[3,9,0]  R1819     4.1061779856681824e-01
    z[3,9,0]  R1820     -1.7351135611534119e-02
    z[3,9,0]  R1821     2.0395504310727119e-02
    z[3,9,0]  R1822     -1.4109697937965393e-01
    z[3,9,0]  R1823     1.5128690004348755e-01
    z[3,9,1]  R30       -1
    z[3,9,1]  R84       1
    z[3,9,1]  R1754     -1
    z[3,9,1]  R1755     1
    z[3,9,1]  R1766     -2.2855930030345917e-01
    z[3,9,1]  R1767     -2.2460272908210754e-01
    z[3,9,1]  R1768     3.2066803425550461e-02
    z[3,9,1]  R1769     -2.4953939020633698e-01
    z[3,9,1]  R1770     -3.4873235225677490e-01
    z[3,9,1]  R1771     8.6467780172824860e-02
    z[3,9,1]  R1772     1.0977321863174438e-01
    z[3,9,1]  R1773     1.7737165093421936e-01
    z[3,9,1]  R1774     6.5116435289382935e-02
    z[3,9,1]  R1775     2.6427105069160461e-01
    z[3,9,1]  R1776     1.6233828663825989e-01
    z[3,9,1]  R1777     3.5085299611091614e-01
    z[3,9,1]  R1778     3.7565350532531738e-01
    z[3,9,1]  R1779     -6.6838508844375610e-01
    z[3,9,1]  R1780     -7.0583873987197876e-01
    z[3,9,1]  R1781     7.8617835044860840e-01
    z[3,9,1]  R1782     3.8600188493728638e-01
    z[3,9,1]  R1783     2.1506385505199432e-01
    z[3,9,1]  R1784     -7.4995177984237671e-01
    z[3,9,1]  R1785     -5.3873974084854126e-01
    z[3,9,1]  R1786     -6.3138955831527710e-01
    z[3,9,1]  R1787     6.6662716865539551e-01
    z[3,9,1]  R1788     -7.1545474231243134e-02
    z[3,9,1]  R1789     7.5208085775375366e-01
    z[3,9,1]  R1790     6.2472069263458252e-01
    z[3,9,1]  R1791     5.6213027238845825e-01
    z[3,9,1]  R1792     4.2814698815345764e-01
    z[3,9,1]  R1793     6.2551081180572510e-01
    z[3,9,1]  R1794     2.2078971564769745e-01
    z[3,9,1]  R1795     2.4528747797012329e-01
    z[3,9,1]  R1796     2.2886614501476288e-01
    z[3,9,1]  R1797     6.2833614647388458e-02
    z[3,9,1]  R1798     0.0522940419614315
    z[3,9,1]  R1799     -2.3030752781778574e-03
    z[3,9,1]  R1800     3.7983089685440063e-01
    z[3,9,1]  R1801     4.4141745567321777e-01
    z[3,9,1]  R1802     2.0452353358268738e-01
    z[3,9,1]  R1803     -2.5731673836708069e-01
    z[3,9,1]  R1804     3.0860263109207153e-01
    z[3,9,1]  R1805     2.1323890984058380e-01
    z[3,9,1]  R1806     2.2095717489719391e-01
    z[3,9,1]  R1807     4.7474063932895660e-02
    z[3,9,1]  R1808     -4.9295875430107117e-01
    z[3,9,1]  R1809     1.2208233773708344e-01
    z[3,9,1]  R1810     -8.2709372043609619e-01
    z[3,9,1]  R1811     -7.6416867971420288e-01
    z[3,9,1]  R1812     -4.6448597311973572e-01
    z[3,9,1]  R1813     -7.0766109228134155e-01
    z[3,9,1]  R1814     3.9264941215515137e-01
    z[3,9,1]  R1815     2.8469431400299072e-01
    z[3,9,1]  R1816     3.3902174234390259e-01
    z[3,9,1]  R1817     -7.2685462236404419e-01
    z[3,9,1]  R1818     -8.2207417488098145e-01
    z[3,9,1]  R1819     -6.3087242841720581e-01
    z[3,9,1]  R1820     -6.2628740072250366e-01
    z[3,9,1]  R1821     -8.5059094429016113e-01
    z[3,9,1]  R1822     -4.3481594324111938e-01
    z[3,9,1]  R1823     -4.0053021907806396e-01
    z[3,9,2]  R31       -1
    z[3,9,2]  R85       1
    z[3,9,2]  R1756     -1
    z[3,9,2]  R1757     1
    z[3,9,2]  R1766     -7.5069051980972290e-01
    z[3,9,2]  R1767     -6.9352585077285767e-01
    z[3,9,2]  R1768     0.0881400927901268
    z[3,9,2]  R1769     -0.616380512714386
    z[3,9,2]  R1770     -0.812161922454834
    z[3,9,2]  R1771     1.8503734469413757e-01
    z[3,9,2]  R1772     3.2529249787330627e-01
    z[3,9,2]  R1773     -2.6412791013717651e-01
    z[3,9,2]  R1774     2.7396348118782043e-01
    z[3,9,2]  R1775     -2.3845118284225464e-01
    z[3,9,2]  R1776     -2.2934272885322571e-02
    z[3,9,2]  R1777     1.7681892216205597e-01
    z[3,9,2]  R1778     5.9974616765975952e-01
    z[3,9,2]  R1779     4.1776421666145325e-01
    z[3,9,2]  R1780     3.7270089983940125e-01
    z[3,9,2]  R1781     -5.5384196341037750e-02
    z[3,9,2]  R1782     4.2232406139373779e-01
    z[3,9,2]  R1783     2.1507011353969574e-01
    z[3,9,2]  R1784     -1.7446257174015045e-01
    z[3,9,2]  R1785     -5.5856686085462570e-02
    z[3,9,2]  R1786     8.0902762711048126e-03
    z[3,9,2]  R1787     -1.5333354473114014e-01
    z[3,9,2]  R1788     1.4602917432785034e-01
    z[3,9,2]  R1789     2.9094228148460388e-01
    z[3,9,2]  R1790     3.6671683192253113e-01
    z[3,9,2]  R1791     4.8931926488876343e-01
    z[3,9,2]  R1792     2.4885062873363495e-01
    z[3,9,2]  R1793     -0.0532621331512928
    z[3,9,2]  R1794     2.4331012368202209e-01
    z[3,9,2]  R1795     -1.3265152275562286e-01
    z[3,9,2]  R1796     1.2788438796997070e-01
    z[3,9,2]  R1797     2.6188468933105469e-01
    z[3,9,2]  R1798     4.9405732750892639e-01
    z[3,9,2]  R1799     4.7037251293659210e-02
    z[3,9,2]  R1800     -2.5888139009475708e-01
    z[3,9,2]  R1801     -5.1113259792327881e-01
    z[3,9,2]  R1802     -8.2068789005279541e-01
    z[3,9,2]  R1803     -7.1421772241592407e-01
    z[3,9,2]  R1804     7.4786305427551270e-01
    z[3,9,2]  R1805     -1.1644738167524338e-01
    z[3,9,2]  R1806     3.0187538266181946e-01
    z[3,9,2]  R1807     3.9523360133171082e-01
    z[3,9,2]  R1808     -1.0738720744848251e-01
    z[3,9,2]  R1809     7.8273884952068329e-02
    z[3,9,2]  R1810     -2.1103464066982269e-01
    z[3,9,2]  R1811     -1.7358438670635223e-01
    z[3,9,2]  R1812     -1.4429225027561188e-01
    z[3,9,2]  R1813     -1.3068130612373352e-01
    z[3,9,2]  R1814     3.3380672335624695e-01
    z[3,9,2]  R1815     0.0972277969121933
    z[3,9,2]  R1816     -4.9237540364265442e-01
    z[3,9,2]  R1817     -2.4246707558631897e-01
    z[3,9,2]  R1818     -3.6731344461441040e-01
    z[3,9,2]  R1819     2.0351560413837433e-01
    z[3,9,2]  R1820     -7.0530956983566284e-01
    z[3,9,2]  R1821     3.3843708038330078e-01
    z[3,9,2]  R1822     -8.0793344974517822e-01
    z[3,9,2]  R1823     -7.0788913965225220e-01
    z[3,9,3]  R32       -1
    z[3,9,3]  R86       1
    z[3,9,3]  R1758     -1
    z[3,9,3]  R1759     1
    z[3,9,3]  R1766     -2.0729070529341698e-02
    z[3,9,3]  R1767     1.4990265481173992e-02
    z[3,9,3]  R1768     8.1128489971160889e-01
    z[3,9,3]  R1769     2.8460944071412086e-02
    z[3,9,3]  R1770     2.4128781259059906e-01
    z[3,9,3]  R1771     5.1792770624160767e-01
    z[3,9,3]  R1772     5.9925496578216553e-01
    z[3,9,3]  R1773     5.5411982536315918e-01
    z[3,9,3]  R1774     4.8862314224243164e-01
    z[3,9,3]  R1775     4.1310253739356995e-01
    z[3,9,3]  R1776     -6.5624141693115234e-01
    z[3,9,3]  R1777     -5.3472006320953369e-01
    z[3,9,3]  R1778     -0.647748589515686
    z[3,9,3]  R1779     -3.3803331851959229e-01
    z[3,9,3]  R1780     2.0410838723182678e-01
    z[3,9,3]  R1781     3.1497529149055481e-01
    z[3,9,3]  R1782     2.0240074396133423e-01
    z[3,9,3]  R1783     3.8643366098403931e-01
    z[3,9,3]  R1784     2.1542568504810333e-01
    z[3,9,3]  R1785     -0.577997088432312
    z[3,9,3]  R1786     -6.2361329793930054e-01
    z[3,9,3]  R1787     -5.4922294616699219e-01
    z[3,9,3]  R1788     -6.4651709794998169e-01
    z[3,9,3]  R1789     4.4862103462219238e-01
    z[3,9,3]  R1790     4.9435773491859436e-01
    z[3,9,3]  R1791     4.2824935913085938e-01
    z[3,9,3]  R1792     6.4358937740325928e-01
    z[3,9,3]  R1793     5.6243580579757690e-01
    z[3,9,3]  R1794     6.4667350053787231e-01
    z[3,9,3]  R1795     8.1469595432281494e-01
    z[3,9,3]  R1796     5.7284229993820190e-01
    z[3,9,3]  R1797     5.4776233434677124e-01
    z[3,9,3]  R1798     7.6668906211853027e-01
    z[3,9,3]  R1799     0.730480432510376
    z[3,9,3]  R1800     4.7357723116874695e-01
    z[3,9,3]  R1801     -7.3143742978572845e-02
    z[3,9,3]  R1802     -0.0997811034321785
    z[3,9,3]  R1803     2.1516993641853333e-01
    z[3,9,3]  R1804     -5.5850225687026978e-01
    z[3,9,3]  R1805     -7.5867593288421631e-01
    z[3,9,3]  R1806     -7.0465826988220215e-01
    z[3,9,3]  R1807     -8.2727390527725220e-01
    z[3,9,3]  R1808     -9.1780357062816620e-02
    z[3,9,3]  R1809     -2.3147705197334290e-01
    z[3,9,3]  R1810     -5.9007301926612854e-02
    z[3,9,3]  R1811     -1.7165517807006836e-01
    z[3,9,3]  R1812     -7.4143759906291962e-02
    z[3,9,3]  R1813     -1.9601134955883026e-01
    z[3,9,3]  R1814     -5.2687042951583862e-01
    z[3,9,3]  R1815     -2.5929272174835205e-01
    z[3,9,3]  R1816     -1.1953826993703842e-01
    z[3,9,3]  R1817     4.2547813057899475e-01
    z[3,9,3]  R1818     -2.6645886898040771e-01
    z[3,9,3]  R1819     2.3811502754688263e-01
    z[3,9,3]  R1820     1.0545709729194641e-01
    z[3,9,3]  R1821     -1.3102434575557709e-01
    z[3,9,3]  R1822     -4.0756408125162125e-02
    z[3,9,3]  R1823     1.2913256883621216e-01
    z[3,9,4]  R33       -1
    z[3,9,4]  R87       1
    z[3,9,4]  R1760     -1
    z[3,9,4]  R1761     1
    z[3,9,4]  R1766     -3.1282356381416321e-01
    z[3,9,4]  R1767     -4.0590861439704895e-01
    z[3,9,4]  R1768     -9.7965687513351440e-02
    z[3,9,4]  R1769     3.0620750784873962e-01
    z[3,9,4]  R1770     5.2551679313182831e-02
    z[3,9,4]  R1771     2.1951572597026825e-01
    z[3,9,4]  R1772     -1.1212415993213654e-01
    z[3,9,4]  R1773     1.7882628738880157e-01
    z[3,9,4]  R1774     8.6182296276092529e-02
    z[3,9,4]  R1775     -3.7112173438072205e-01
    z[3,9,4]  R1776     3.5811313986778259e-01
    z[3,9,4]  R1777     -6.5637670457363129e-02
    z[3,9,4]  R1778     -3.3531852066516876e-02
    z[3,9,4]  R1779     1.4174060523509979e-01
    z[3,9,4]  R1780     0.177893728017807
    z[3,9,4]  R1781     -1.0606989264488220e-01
    z[3,9,4]  R1782     -7.3660008609294891e-02
    z[3,9,4]  R1783     2.4465283751487732e-01
    z[3,9,4]  R1784     1.2989516369998455e-02
    z[3,9,4]  R1785     9.4605013728141785e-02
    z[3,9,4]  R1786     3.4848979115486145e-01
    z[3,9,4]  R1787     -3.3763018250465393e-01
    z[3,9,4]  R1788     -1.6866831481456757e-01
    z[3,9,4]  R1789     -7.3030188679695129e-02
    z[3,9,4]  R1790     -1.4280991256237030e-01
    z[3,9,4]  R1791     -5.0838004797697067e-02
    z[3,9,4]  R1792     1.5157523751258850e-01
    z[3,9,4]  R1793     1.3655400276184082e-01
    z[3,9,4]  R1794     -8.6017400026321411e-03
    z[3,9,4]  R1795     -1.5056072175502777e-01
    z[3,9,4]  R1796     4.2689535021781921e-01
    z[3,9,4]  R1797     -5.1363629102706909e-01
    z[3,9,4]  R1798     -2.2283342480659485e-01
    z[3,9,4]  R1799     1.4258655905723572e-01
    z[3,9,4]  R1800     1.0501173883676529e-01
    z[3,9,4]  R1801     -6.3213360309600830e-01
    z[3,9,4]  R1802     3.6314094066619873e-01
    z[3,9,4]  R1803     5.1917150616645813e-02
    z[3,9,4]  R1804     -1.1632586270570755e-01
    z[3,9,4]  R1805     2.6178082823753357e-01
    z[3,9,4]  R1806     -1.4302109181880951e-01
    z[3,9,4]  R1807     2.1030455827713013e-03
    z[3,9,4]  R1808     -2.5131186842918396e-01
    z[3,9,4]  R1809     2.9953831434249878e-01
    z[3,9,4]  R1810     3.2541179656982422e-01
    z[3,9,4]  R1811     -3.2191792130470276e-01
    z[3,9,4]  R1812     -2.9407319426536560e-01
    z[3,9,4]  R1813     -1.6345328092575073e-01
    z[3,9,4]  R1814     -3.3638164401054382e-02
    z[3,9,4]  R1815     5.6115162372589111e-01
    z[3,9,4]  R1816     0.313353568315506
    z[3,9,4]  R1817     -1.4223536849021912e-01
    z[3,9,4]  R1818     -1.7988644540309906e-02
    z[3,9,4]  R1819     1.2636347115039825e-01
    z[3,9,4]  R1820     1.0123517364263535e-01
    z[3,9,4]  R1821     1.1130163073539734e-01
    z[3,9,4]  R1822     -9.8336994647979736e-02
    z[3,9,4]  R1823     -1.6293426975607872e-02
    z[3,9,5]  R34       -1
    z[3,9,5]  R88       1
    z[3,9,5]  R1762     -1
    z[3,9,5]  R1763     1
    z[3,9,5]  R1766     0.261923223733902
    z[3,9,5]  R1767     2.3837955296039581e-01
    z[3,9,5]  R1768     1.7931589484214783e-01
    z[3,9,5]  R1769     9.4692386686801910e-02
    z[3,9,5]  R1770     1.1864223517477512e-02
    z[3,9,5]  R1771     9.2396877706050873e-02
    z[3,9,5]  R1772     -2.9577752947807312e-01
    z[3,9,5]  R1773     4.6932362020015717e-03
    z[3,9,5]  R1774     3.8095137476921082e-01
    z[3,9,5]  R1775     -0.177132248878479
    z[3,9,5]  R1776     -4.0599358081817627e-01
    z[3,9,5]  R1777     -4.4231596589088440e-01
    z[3,9,5]  R1778     -1.8506981432437897e-02
    z[3,9,5]  R1779     4.2402917146682739e-01
    z[3,9,5]  R1780     9.0337663888931274e-02
    z[3,9,5]  R1781     -3.2538047432899475e-01
    z[3,9,5]  R1782     -4.9688392877578735e-01
    z[3,9,5]  R1783     -6.4921134710311890e-01
    z[3,9,5]  R1784     9.4749532639980316e-02
    z[3,9,5]  R1785     -6.7315645515918732e-02
    z[3,9,5]  R1786     4.0143728256225586e-03
    z[3,9,5]  R1787     1.2150320410728455e-01
    z[3,9,5]  R1788     0.606165885925293
    z[3,9,5]  R1789     -2.0348009467124939e-01
    z[3,9,5]  R1790     -2.7250227332115173e-01
    z[3,9,5]  R1791     -4.1970375180244446e-01
    z[3,9,5]  R1792     -1.8364740908145905e-01
    z[3,9,5]  R1793     -2.4095095694065094e-01
    z[3,9,5]  R1794     -1.6714364290237427e-01
    z[3,9,5]  R1795     -1.0922791436314583e-02
    z[3,9,5]  R1796     -0.0778147503733635
    z[3,9,5]  R1797     2.7469709515571594e-01
    z[3,9,5]  R1798     -2.0084667205810547e-01
    z[3,9,5]  R1799     -3.0417975783348083e-01
    z[3,9,5]  R1800     -1.1976343393325806e-01
    z[3,9,5]  R1801     -3.0184416100382805e-02
    z[3,9,5]  R1802     -2.6337811350822449e-01
    z[3,9,5]  R1803     4.4822424650192261e-01
    z[3,9,5]  R1804     1.3516438007354736e-01
    z[3,9,5]  R1805     0.371501088142395
    z[3,9,5]  R1806     4.6095588803291321e-01
    z[3,9,5]  R1807     2.9762476682662964e-01
    z[3,9,5]  R1808     -4.3573114275932312e-01
    z[3,9,5]  R1809     -2.2947339713573456e-01
    z[3,9,5]  R1810     2.8953146934509277e-01
    z[3,9,5]  R1811     1.8770781159400940e-01
    z[3,9,5]  R1812     2.4617239832878113e-02
    z[3,9,5]  R1813     1.5098921954631805e-01
    z[3,9,5]  R1814     -1.7260673642158508e-01
    z[3,9,5]  R1815     -5.2695637941360474e-01
    z[3,9,5]  R1816     -2.2647507488727570e-01
    z[3,9,5]  R1817     -1.3525488972663879e-01
    z[3,9,5]  R1818     3.0662909150123596e-01
    z[3,9,5]  R1819     -1.7903931438922882e-01
    z[3,9,5]  R1820     1.5412282943725586e-01
    z[3,9,5]  R1821     2.3304232954978943e-01
    z[3,9,5]  R1822     3.4626227617263794e-01
    z[3,9,5]  R1823     0.53646320104599
    z[3,9,6]  R35       -1
    z[3,9,6]  R89       1
    z[3,9,6]  R1764     -1
    z[3,9,6]  R1765     1
    z[3,9,6]  R1766     -4.6462330222129822e-01
    z[3,9,6]  R1767     1.1685429513454437e-01
    z[3,9,6]  R1768     -1.9126628339290619e-01
    z[3,9,6]  R1769     3.5401052236557007e-01
    z[3,9,6]  R1770     3.8285449147224426e-01
    z[3,9,6]  R1771     -1.8760672211647034e-01
    z[3,9,6]  R1772     1.0930579155683517e-01
    z[3,9,6]  R1773     2.7533236145973206e-01
    z[3,9,6]  R1774     3.6939746141433716e-01
    z[3,9,6]  R1775     -1.2873359024524689e-01
    z[3,9,6]  R1776     -3.2803854346275330e-01
    z[3,9,6]  R1777     5.7653826475143433e-01
    z[3,9,6]  R1778     2.6257598400115967e-01
    z[3,9,6]  R1779     -2.5008264183998108e-01
    z[3,9,6]  R1780     -4.4959101080894470e-01
    z[3,9,6]  R1781     -7.3776558041572571e-02
    z[3,9,6]  R1782     -0.460621178150177
    z[3,9,6]  R1783     2.7532455325126648e-01
    z[3,9,6]  R1784     -1.4251363277435303e-01
    z[3,9,6]  R1785     -4.3673881888389587e-01
    z[3,9,6]  R1786     2.0005346834659576e-01
    z[3,9,6]  R1787     2.4210794270038605e-01
    z[3,9,6]  R1788     -9.9951634183526039e-03
    z[3,9,6]  R1789     5.6434098631143570e-02
    z[3,9,6]  R1790     -3.3775623887777328e-03
    z[3,9,6]  R1791     7.0777930319309235e-02
    z[3,9,6]  R1792     7.0458851754665375e-02
    z[3,9,6]  R1793     -1.7986442148685455e-01
    z[3,9,6]  R1794     1.7088238894939423e-01
    z[3,9,6]  R1795     -1.8949435651302338e-01
    z[3,9,6]  R1796     -2.8667521476745605e-01
    z[3,9,6]  R1797     1.6458222270011902e-01
    z[3,9,6]  R1798     2.5363853573799133e-01
    z[3,9,6]  R1799     5.6849747896194458e-01
    z[3,9,6]  R1800     5.9675979614257812e-01
    z[3,9,6]  R1801     1.1810465157032013e-01
    z[3,9,6]  R1802     2.0851017534732819e-01
    z[3,9,6]  R1803     -1.1312078684568405e-01
    z[3,9,6]  R1804     -3.1195651739835739e-02
    z[3,9,6]  R1805     3.2639726996421814e-02
    z[3,9,6]  R1806     -2.2185422480106354e-01
    z[3,9,6]  R1807     2.5383546948432922e-01
    z[3,9,6]  R1808     -1.2012134492397308e-01
    z[3,9,6]  R1809     -7.8967171907424927e-01
    z[3,9,6]  R1810     -5.6475266814231873e-02
    z[3,9,6]  R1811     3.5991939902305603e-01
    z[3,9,6]  R1812     -6.2226498126983643e-01
    z[3,9,6]  R1813     -4.8943912982940674e-01
    z[3,9,6]  R1814     0.560827374458313
    z[3,9,6]  R1815     1.0953530669212341e-02
    z[3,9,6]  R1816     -0.649936318397522
    z[3,9,6]  R1817     -3.0012881755828857e-01
    z[3,9,6]  R1818     1.5112267434597015e-01
    z[3,9,6]  R1819     -5.3595972061157227e-01
    z[3,9,6]  R1820     -2.5471115112304688e-01
    z[3,9,6]  R1821     -2.7870258688926697e-01
    z[3,9,6]  R1822     8.3913028240203857e-02
    z[3,9,6]  R1823     1.0414987057447433e-01
    z[9,3,0]  R29       1
    z[9,3,0]  R83       -1
    z[9,3,0]  R1824     -1
    z[9,3,0]  R1825     1
    z[9,3,0]  R1838     -6.4548724889755249e-01
    z[9,3,0]  R1839     -4.4700339436531067e-01
    z[9,3,0]  R1840     -5.7674968242645264e-01
    z[9,3,0]  R1841     -5.1093703508377075e-01
    z[9,3,0]  R1842     -1.0504309833049774e-01
    z[9,3,0]  R1843     -1.6773472726345062e-01
    z[9,3,0]  R1844     -4.2771536111831665e-01
    z[9,3,0]  R1845     3.5226613283157349e-01
    z[9,3,0]  R1846     1.7311668395996094e-01
    z[9,3,0]  R1847     4.0123113989830017e-01
    z[9,3,0]  R1848     0.0276805367320776
    z[9,3,0]  R1849     -3.9720579981803894e-01
    z[9,3,0]  R1850     -2.8522130846977234e-01
    z[9,3,0]  R1851     -6.4319148659706116e-02
    z[9,3,0]  R1852     6.8526464700698853e-01
    z[9,3,0]  R1853     3.9928045868873596e-01
    z[9,3,0]  R1854     -2.7383902668952942e-01
    z[9,3,0]  R1855     2.9671835899353027e-01
    z[9,3,0]  R1856     5.3257542848587036e-01
    z[9,3,0]  R1857     3.9325863122940063e-01
    z[9,3,0]  R1858     3.3369913697242737e-01
    z[9,3,0]  R1859     4.9956884980201721e-01
    z[9,3,0]  R1860     2.3757702112197876e-01
    z[9,3,0]  R1861     3.2133832573890686e-01
    z[9,3,0]  R1862     3.3036302775144577e-02
    z[9,3,0]  R1863     4.1061779856681824e-01
    z[9,3,0]  R1864     -1.7351135611534119e-02
    z[9,3,0]  R1865     2.0395504310727119e-02
    z[9,3,0]  R1866     -1.4109697937965393e-01
    z[9,3,0]  R1867     1.5128690004348755e-01
    z[9,3,0]  R1868     -3.8177676498889923e-02
    z[9,3,0]  R1869     4.8281392455101013e-01
    z[9,3,0]  R1870     -5.0466382503509521e-01
    z[9,3,0]  R1871     -5.7353466749191284e-01
    z[9,3,0]  R1872     1.0525610297918320e-01
    z[9,3,0]  R1873     -7.7337872982025146e-01
    z[9,3,0]  R1874     -6.4111167192459106e-01
    z[9,3,0]  R1875     -6.9564241170883179e-01
    z[9,3,0]  R1876     -6.2685352563858032e-01
    z[9,3,0]  R1877     -0.719005286693573
    z[9,3,0]  R1878     -3.7654018402099609e-01
    z[9,3,0]  R1879     1.6541968286037445e-01
    z[9,3,0]  R1880     9.5905058085918427e-02
    z[9,3,0]  R1881     -4.5115888118743896e-02
    z[9,3,0]  R1882     2.8157824277877808e-01
    z[9,3,0]  R1883     3.9633381366729736e-01
    z[9,3,0]  R1884     4.0888580679893494e-01
    z[9,3,0]  R1885     4.4836091995239258e-01
    z[9,3,0]  R1886     0.575560986995697
    z[9,3,0]  R1887     4.1028848290443420e-01
    z[9,3,0]  R1888     2.2562281787395477e-01
    z[9,3,0]  R1889     -2.0755213499069214e-01
    z[9,3,0]  R1890     -3.9948263764381409e-01
    z[9,3,0]  R1891     3.1391668319702148e-01
    z[9,3,0]  R1892     3.6903870105743408e-01
    z[9,3,0]  R1893     2.7826866507530212e-01
    z[9,3,0]  R1894     5.2810066938400269e-01
    z[9,3,0]  R1895     4.2486450076103210e-01
    z[9,3,1]  R30       1
    z[9,3,1]  R84       -1
    z[9,3,1]  R1826     -1
    z[9,3,1]  R1827     1
    z[9,3,1]  R1838     2.2078971564769745e-01
    z[9,3,1]  R1839     2.4528747797012329e-01
    z[9,3,1]  R1840     2.2886614501476288e-01
    z[9,3,1]  R1841     6.2833614647388458e-02
    z[9,3,1]  R1842     0.0522940419614315
    z[9,3,1]  R1843     -2.3030752781778574e-03
    z[9,3,1]  R1844     3.7983089685440063e-01
    z[9,3,1]  R1845     4.4141745567321777e-01
    z[9,3,1]  R1846     2.0452353358268738e-01
    z[9,3,1]  R1847     -2.5731673836708069e-01
    z[9,3,1]  R1848     3.0860263109207153e-01
    z[9,3,1]  R1849     2.1323890984058380e-01
    z[9,3,1]  R1850     2.2095717489719391e-01
    z[9,3,1]  R1851     4.7474063932895660e-02
    z[9,3,1]  R1852     -4.9295875430107117e-01
    z[9,3,1]  R1853     1.2208233773708344e-01
    z[9,3,1]  R1854     -8.2709372043609619e-01
    z[9,3,1]  R1855     -7.6416867971420288e-01
    z[9,3,1]  R1856     -4.6448597311973572e-01
    z[9,3,1]  R1857     -7.0766109228134155e-01
    z[9,3,1]  R1858     3.9264941215515137e-01
    z[9,3,1]  R1859     2.8469431400299072e-01
    z[9,3,1]  R1860     3.3902174234390259e-01
    z[9,3,1]  R1861     -7.2685462236404419e-01
    z[9,3,1]  R1862     -8.2207417488098145e-01
    z[9,3,1]  R1863     -6.3087242841720581e-01
    z[9,3,1]  R1864     -6.2628740072250366e-01
    z[9,3,1]  R1865     -8.5059094429016113e-01
    z[9,3,1]  R1866     -4.3481594324111938e-01
    z[9,3,1]  R1867     -4.0053021907806396e-01
    z[9,3,1]  R1868     -2.2855930030345917e-01
    z[9,3,1]  R1869     -2.2460272908210754e-01
    z[9,3,1]  R1870     3.2066803425550461e-02
    z[9,3,1]  R1871     -2.4953939020633698e-01
    z[9,3,1]  R1872     -3.4873235225677490e-01
    z[9,3,1]  R1873     8.6467780172824860e-02
    z[9,3,1]  R1874     1.0977321863174438e-01
    z[9,3,1]  R1875     1.7737165093421936e-01
    z[9,3,1]  R1876     6.5116435289382935e-02
    z[9,3,1]  R1877     2.6427105069160461e-01
    z[9,3,1]  R1878     1.6233828663825989e-01
    z[9,3,1]  R1879     3.5085299611091614e-01
    z[9,3,1]  R1880     3.7565350532531738e-01
    z[9,3,1]  R1881     -6.6838508844375610e-01
    z[9,3,1]  R1882     -7.0583873987197876e-01
    z[9,3,1]  R1883     7.8617835044860840e-01
    z[9,3,1]  R1884     3.8600188493728638e-01
    z[9,3,1]  R1885     2.1506385505199432e-01
    z[9,3,1]  R1886     -7.4995177984237671e-01
    z[9,3,1]  R1887     -5.3873974084854126e-01
    z[9,3,1]  R1888     -6.3138955831527710e-01
    z[9,3,1]  R1889     6.6662716865539551e-01
    z[9,3,1]  R1890     -7.1545474231243134e-02
    z[9,3,1]  R1891     7.5208085775375366e-01
    z[9,3,1]  R1892     6.2472069263458252e-01
    z[9,3,1]  R1893     5.6213027238845825e-01
    z[9,3,1]  R1894     4.2814698815345764e-01
    z[9,3,1]  R1895     6.2551081180572510e-01
    z[9,3,2]  R31       1
    z[9,3,2]  R85       -1
    z[9,3,2]  R1828     -1
    z[9,3,2]  R1829     1
    z[9,3,2]  R1838     2.4331012368202209e-01
    z[9,3,2]  R1839     -1.3265152275562286e-01
    z[9,3,2]  R1840     1.2788438796997070e-01
    z[9,3,2]  R1841     2.6188468933105469e-01
    z[9,3,2]  R1842     4.9405732750892639e-01
    z[9,3,2]  R1843     4.7037251293659210e-02
    z[9,3,2]  R1844     -2.5888139009475708e-01
    z[9,3,2]  R1845     -5.1113259792327881e-01
    z[9,3,2]  R1846     -8.2068789005279541e-01
    z[9,3,2]  R1847     -7.1421772241592407e-01
    z[9,3,2]  R1848     7.4786305427551270e-01
    z[9,3,2]  R1849     -1.1644738167524338e-01
    z[9,3,2]  R1850     3.0187538266181946e-01
    z[9,3,2]  R1851     3.9523360133171082e-01
    z[9,3,2]  R1852     -1.0738720744848251e-01
    z[9,3,2]  R1853     7.8273884952068329e-02
    z[9,3,2]  R1854     -2.1103464066982269e-01
    z[9,3,2]  R1855     -1.7358438670635223e-01
    z[9,3,2]  R1856     -1.4429225027561188e-01
    z[9,3,2]  R1857     -1.3068130612373352e-01
    z[9,3,2]  R1858     3.3380672335624695e-01
    z[9,3,2]  R1859     0.0972277969121933
    z[9,3,2]  R1860     -4.9237540364265442e-01
    z[9,3,2]  R1861     -2.4246707558631897e-01
    z[9,3,2]  R1862     -3.6731344461441040e-01
    z[9,3,2]  R1863     2.0351560413837433e-01
    z[9,3,2]  R1864     -7.0530956983566284e-01
    z[9,3,2]  R1865     3.3843708038330078e-01
    z[9,3,2]  R1866     -8.0793344974517822e-01
    z[9,3,2]  R1867     -7.0788913965225220e-01
    z[9,3,2]  R1868     -7.5069051980972290e-01
    z[9,3,2]  R1869     -6.9352585077285767e-01
    z[9,3,2]  R1870     0.0881400927901268
    z[9,3,2]  R1871     -0.616380512714386
    z[9,3,2]  R1872     -0.812161922454834
    z[9,3,2]  R1873     1.8503734469413757e-01
    z[9,3,2]  R1874     3.2529249787330627e-01
    z[9,3,2]  R1875     -2.6412791013717651e-01
    z[9,3,2]  R1876     2.7396348118782043e-01
    z[9,3,2]  R1877     -2.3845118284225464e-01
    z[9,3,2]  R1878     -2.2934272885322571e-02
    z[9,3,2]  R1879     1.7681892216205597e-01
    z[9,3,2]  R1880     5.9974616765975952e-01
    z[9,3,2]  R1881     4.1776421666145325e-01
    z[9,3,2]  R1882     3.7270089983940125e-01
    z[9,3,2]  R1883     -5.5384196341037750e-02
    z[9,3,2]  R1884     4.2232406139373779e-01
    z[9,3,2]  R1885     2.1507011353969574e-01
    z[9,3,2]  R1886     -1.7446257174015045e-01
    z[9,3,2]  R1887     -5.5856686085462570e-02
    z[9,3,2]  R1888     8.0902762711048126e-03
    z[9,3,2]  R1889     -1.5333354473114014e-01
    z[9,3,2]  R1890     1.4602917432785034e-01
    z[9,3,2]  R1891     2.9094228148460388e-01
    z[9,3,2]  R1892     3.6671683192253113e-01
    z[9,3,2]  R1893     4.8931926488876343e-01
    z[9,3,2]  R1894     2.4885062873363495e-01
    z[9,3,2]  R1895     -0.0532621331512928
    z[9,3,3]  R32       1
    z[9,3,3]  R86       -1
    z[9,3,3]  R1830     -1
    z[9,3,3]  R1831     1
    z[9,3,3]  R1838     6.4667350053787231e-01
    z[9,3,3]  R1839     8.1469595432281494e-01
    z[9,3,3]  R1840     5.7284229993820190e-01
    z[9,3,3]  R1841     5.4776233434677124e-01
    z[9,3,3]  R1842     7.6668906211853027e-01
    z[9,3,3]  R1843     0.730480432510376
    z[9,3,3]  R1844     4.7357723116874695e-01
    z[9,3,3]  R1845     -7.3143742978572845e-02
    z[9,3,3]  R1846     -0.0997811034321785
    z[9,3,3]  R1847     2.1516993641853333e-01
    z[9,3,3]  R1848     -5.5850225687026978e-01
    z[9,3,3]  R1849     -7.5867593288421631e-01
    z[9,3,3]  R1850     -7.0465826988220215e-01
    z[9,3,3]  R1851     -8.2727390527725220e-01
    z[9,3,3]  R1852     -9.1780357062816620e-02
    z[9,3,3]  R1853     -2.3147705197334290e-01
    z[9,3,3]  R1854     -5.9007301926612854e-02
    z[9,3,3]  R1855     -1.7165517807006836e-01
    z[9,3,3]  R1856     -7.4143759906291962e-02
    z[9,3,3]  R1857     -1.9601134955883026e-01
    z[9,3,3]  R1858     -5.2687042951583862e-01
    z[9,3,3]  R1859     -2.5929272174835205e-01
    z[9,3,3]  R1860     -1.1953826993703842e-01
    z[9,3,3]  R1861     4.2547813057899475e-01
    z[9,3,3]  R1862     -2.6645886898040771e-01
    z[9,3,3]  R1863     2.3811502754688263e-01
    z[9,3,3]  R1864     1.0545709729194641e-01
    z[9,3,3]  R1865     -1.3102434575557709e-01
    z[9,3,3]  R1866     -4.0756408125162125e-02
    z[9,3,3]  R1867     1.2913256883621216e-01
    z[9,3,3]  R1868     -2.0729070529341698e-02
    z[9,3,3]  R1869     1.4990265481173992e-02
    z[9,3,3]  R1870     8.1128489971160889e-01
    z[9,3,3]  R1871     2.8460944071412086e-02
    z[9,3,3]  R1872     2.4128781259059906e-01
    z[9,3,3]  R1873     5.1792770624160767e-01
    z[9,3,3]  R1874     5.9925496578216553e-01
    z[9,3,3]  R1875     5.5411982536315918e-01
    z[9,3,3]  R1876     4.8862314224243164e-01
    z[9,3,3]  R1877     4.1310253739356995e-01
    z[9,3,3]  R1878     -6.5624141693115234e-01
    z[9,3,3]  R1879     -5.3472006320953369e-01
    z[9,3,3]  R1880     -0.647748589515686
    z[9,3,3]  R1881     -3.3803331851959229e-01
    z[9,3,3]  R1882     2.0410838723182678e-01
    z[9,3,3]  R1883     3.1497529149055481e-01
    z[9,3,3]  R1884     2.0240074396133423e-01
    z[9,3,3]  R1885     3.8643366098403931e-01
    z[9,3,3]  R1886     2.1542568504810333e-01
    z[9,3,3]  R1887     -0.577997088432312
    z[9,3,3]  R1888     -6.2361329793930054e-01
    z[9,3,3]  R1889     -5.4922294616699219e-01
    z[9,3,3]  R1890     -6.4651709794998169e-01
    z[9,3,3]  R1891     4.4862103462219238e-01
    z[9,3,3]  R1892     4.9435773491859436e-01
    z[9,3,3]  R1893     4.2824935913085938e-01
    z[9,3,3]  R1894     6.4358937740325928e-01
    z[9,3,3]  R1895     5.6243580579757690e-01
    z[9,3,4]  R33       1
    z[9,3,4]  R87       -1
    z[9,3,4]  R1832     -1
    z[9,3,4]  R1833     1
    z[9,3,4]  R1838     -8.6017400026321411e-03
    z[9,3,4]  R1839     -1.5056072175502777e-01
    z[9,3,4]  R1840     4.2689535021781921e-01
    z[9,3,4]  R1841     -5.1363629102706909e-01
    z[9,3,4]  R1842     -2.2283342480659485e-01
    z[9,3,4]  R1843     1.4258655905723572e-01
    z[9,3,4]  R1844     1.0501173883676529e-01
    z[9,3,4]  R1845     -6.3213360309600830e-01
    z[9,3,4]  R1846     3.6314094066619873e-01
    z[9,3,4]  R1847     5.1917150616645813e-02
    z[9,3,4]  R1848     -1.1632586270570755e-01
    z[9,3,4]  R1849     2.6178082823753357e-01
    z[9,3,4]  R1850     -1.4302109181880951e-01
    z[9,3,4]  R1851     2.1030455827713013e-03
    z[9,3,4]  R1852     -2.5131186842918396e-01
    z[9,3,4]  R1853     2.9953831434249878e-01
    z[9,3,4]  R1854     3.2541179656982422e-01
    z[9,3,4]  R1855     -3.2191792130470276e-01
    z[9,3,4]  R1856     -2.9407319426536560e-01
    z[9,3,4]  R1857     -1.6345328092575073e-01
    z[9,3,4]  R1858     -3.3638164401054382e-02
    z[9,3,4]  R1859     5.6115162372589111e-01
    z[9,3,4]  R1860     0.313353568315506
    z[9,3,4]  R1861     -1.4223536849021912e-01
    z[9,3,4]  R1862     -1.7988644540309906e-02
    z[9,3,4]  R1863     1.2636347115039825e-01
    z[9,3,4]  R1864     1.0123517364263535e-01
    z[9,3,4]  R1865     1.1130163073539734e-01
    z[9,3,4]  R1866     -9.8336994647979736e-02
    z[9,3,4]  R1867     -1.6293426975607872e-02
    z[9,3,4]  R1868     -3.1282356381416321e-01
    z[9,3,4]  R1869     -4.0590861439704895e-01
    z[9,3,4]  R1870     -9.7965687513351440e-02
    z[9,3,4]  R1871     3.0620750784873962e-01
    z[9,3,4]  R1872     5.2551679313182831e-02
    z[9,3,4]  R1873     2.1951572597026825e-01
    z[9,3,4]  R1874     -1.1212415993213654e-01
    z[9,3,4]  R1875     1.7882628738880157e-01
    z[9,3,4]  R1876     8.6182296276092529e-02
    z[9,3,4]  R1877     -3.7112173438072205e-01
    z[9,3,4]  R1878     3.5811313986778259e-01
    z[9,3,4]  R1879     -6.5637670457363129e-02
    z[9,3,4]  R1880     -3.3531852066516876e-02
    z[9,3,4]  R1881     1.4174060523509979e-01
    z[9,3,4]  R1882     0.177893728017807
    z[9,3,4]  R1883     -1.0606989264488220e-01
    z[9,3,4]  R1884     -7.3660008609294891e-02
    z[9,3,4]  R1885     2.4465283751487732e-01
    z[9,3,4]  R1886     1.2989516369998455e-02
    z[9,3,4]  R1887     9.4605013728141785e-02
    z[9,3,4]  R1888     3.4848979115486145e-01
    z[9,3,4]  R1889     -3.3763018250465393e-01
    z[9,3,4]  R1890     -1.6866831481456757e-01
    z[9,3,4]  R1891     -7.3030188679695129e-02
    z[9,3,4]  R1892     -1.4280991256237030e-01
    z[9,3,4]  R1893     -5.0838004797697067e-02
    z[9,3,4]  R1894     1.5157523751258850e-01
    z[9,3,4]  R1895     1.3655400276184082e-01
    z[9,3,5]  R34       1
    z[9,3,5]  R88       -1
    z[9,3,5]  R1834     -1
    z[9,3,5]  R1835     1
    z[9,3,5]  R1838     -1.6714364290237427e-01
    z[9,3,5]  R1839     -1.0922791436314583e-02
    z[9,3,5]  R1840     -0.0778147503733635
    z[9,3,5]  R1841     2.7469709515571594e-01
    z[9,3,5]  R1842     -2.0084667205810547e-01
    z[9,3,5]  R1843     -3.0417975783348083e-01
    z[9,3,5]  R1844     -1.1976343393325806e-01
    z[9,3,5]  R1845     -3.0184416100382805e-02
    z[9,3,5]  R1846     -2.6337811350822449e-01
    z[9,3,5]  R1847     4.4822424650192261e-01
    z[9,3,5]  R1848     1.3516438007354736e-01
    z[9,3,5]  R1849     0.371501088142395
    z[9,3,5]  R1850     4.6095588803291321e-01
    z[9,3,5]  R1851     2.9762476682662964e-01
    z[9,3,5]  R1852     -4.3573114275932312e-01
    z[9,3,5]  R1853     -2.2947339713573456e-01
    z[9,3,5]  R1854     2.8953146934509277e-01
    z[9,3,5]  R1855     1.8770781159400940e-01
    z[9,3,5]  R1856     2.4617239832878113e-02
    z[9,3,5]  R1857     1.5098921954631805e-01
    z[9,3,5]  R1858     -1.7260673642158508e-01
    z[9,3,5]  R1859     -5.2695637941360474e-01
    z[9,3,5]  R1860     -2.2647507488727570e-01
    z[9,3,5]  R1861     -1.3525488972663879e-01
    z[9,3,5]  R1862     3.0662909150123596e-01
    z[9,3,5]  R1863     -1.7903931438922882e-01
    z[9,3,5]  R1864     1.5412282943725586e-01
    z[9,3,5]  R1865     2.3304232954978943e-01
    z[9,3,5]  R1866     3.4626227617263794e-01
    z[9,3,5]  R1867     0.53646320104599
    z[9,3,5]  R1868     0.261923223733902
    z[9,3,5]  R1869     2.3837955296039581e-01
    z[9,3,5]  R1870     1.7931589484214783e-01
    z[9,3,5]  R1871     9.4692386686801910e-02
    z[9,3,5]  R1872     1.1864223517477512e-02
    z[9,3,5]  R1873     9.2396877706050873e-02
    z[9,3,5]  R1874     -2.9577752947807312e-01
    z[9,3,5]  R1875     4.6932362020015717e-03
    z[9,3,5]  R1876     3.8095137476921082e-01
    z[9,3,5]  R1877     -0.177132248878479
    z[9,3,5]  R1878     -4.0599358081817627e-01
    z[9,3,5]  R1879     -4.4231596589088440e-01
    z[9,3,5]  R1880     -1.8506981432437897e-02
    z[9,3,5]  R1881     4.2402917146682739e-01
    z[9,3,5]  R1882     9.0337663888931274e-02
    z[9,3,5]  R1883     -3.2538047432899475e-01
    z[9,3,5]  R1884     -4.9688392877578735e-01
    z[9,3,5]  R1885     -6.4921134710311890e-01
    z[9,3,5]  R1886     9.4749532639980316e-02
    z[9,3,5]  R1887     -6.7315645515918732e-02
    z[9,3,5]  R1888     4.0143728256225586e-03
    z[9,3,5]  R1889     1.2150320410728455e-01
    z[9,3,5]  R1890     0.606165885925293
    z[9,3,5]  R1891     -2.0348009467124939e-01
    z[9,3,5]  R1892     -2.7250227332115173e-01
    z[9,3,5]  R1893     -4.1970375180244446e-01
    z[9,3,5]  R1894     -1.8364740908145905e-01
    z[9,3,5]  R1895     -2.4095095694065094e-01
    z[9,3,6]  R35       1
    z[9,3,6]  R89       -1
    z[9,3,6]  R1836     -1
    z[9,3,6]  R1837     1
    z[9,3,6]  R1838     1.7088238894939423e-01
    z[9,3,6]  R1839     -1.8949435651302338e-01
    z[9,3,6]  R1840     -2.8667521476745605e-01
    z[9,3,6]  R1841     1.6458222270011902e-01
    z[9,3,6]  R1842     2.5363853573799133e-01
    z[9,3,6]  R1843     5.6849747896194458e-01
    z[9,3,6]  R1844     5.9675979614257812e-01
    z[9,3,6]  R1845     1.1810465157032013e-01
    z[9,3,6]  R1846     2.0851017534732819e-01
    z[9,3,6]  R1847     -1.1312078684568405e-01
    z[9,3,6]  R1848     -3.1195651739835739e-02
    z[9,3,6]  R1849     3.2639726996421814e-02
    z[9,3,6]  R1850     -2.2185422480106354e-01
    z[9,3,6]  R1851     2.5383546948432922e-01
    z[9,3,6]  R1852     -1.2012134492397308e-01
    z[9,3,6]  R1853     -7.8967171907424927e-01
    z[9,3,6]  R1854     -5.6475266814231873e-02
    z[9,3,6]  R1855     3.5991939902305603e-01
    z[9,3,6]  R1856     -6.2226498126983643e-01
    z[9,3,6]  R1857     -4.8943912982940674e-01
    z[9,3,6]  R1858     0.560827374458313
    z[9,3,6]  R1859     1.0953530669212341e-02
    z[9,3,6]  R1860     -0.649936318397522
    z[9,3,6]  R1861     -3.0012881755828857e-01
    z[9,3,6]  R1862     1.5112267434597015e-01
    z[9,3,6]  R1863     -5.3595972061157227e-01
    z[9,3,6]  R1864     -2.5471115112304688e-01
    z[9,3,6]  R1865     -2.7870258688926697e-01
    z[9,3,6]  R1866     8.3913028240203857e-02
    z[9,3,6]  R1867     1.0414987057447433e-01
    z[9,3,6]  R1868     -4.6462330222129822e-01
    z[9,3,6]  R1869     1.1685429513454437e-01
    z[9,3,6]  R1870     -1.9126628339290619e-01
    z[9,3,6]  R1871     3.5401052236557007e-01
    z[9,3,6]  R1872     3.8285449147224426e-01
    z[9,3,6]  R1873     -1.8760672211647034e-01
    z[9,3,6]  R1874     1.0930579155683517e-01
    z[9,3,6]  R1875     2.7533236145973206e-01
    z[9,3,6]  R1876     3.6939746141433716e-01
    z[9,3,6]  R1877     -1.2873359024524689e-01
    z[9,3,6]  R1878     -3.2803854346275330e-01
    z[9,3,6]  R1879     5.7653826475143433e-01
    z[9,3,6]  R1880     2.6257598400115967e-01
    z[9,3,6]  R1881     -2.5008264183998108e-01
    z[9,3,6]  R1882     -4.4959101080894470e-01
    z[9,3,6]  R1883     -7.3776558041572571e-02
    z[9,3,6]  R1884     -0.460621178150177
    z[9,3,6]  R1885     2.7532455325126648e-01
    z[9,3,6]  R1886     -1.4251363277435303e-01
    z[9,3,6]  R1887     -4.3673881888389587e-01
    z[9,3,6]  R1888     2.0005346834659576e-01
    z[9,3,6]  R1889     2.4210794270038605e-01
    z[9,3,6]  R1890     -9.9951634183526039e-03
    z[9,3,6]  R1891     5.6434098631143570e-02
    z[9,3,6]  R1892     -3.3775623887777328e-03
    z[9,3,6]  R1893     7.0777930319309235e-02
    z[9,3,6]  R1894     7.0458851754665375e-02
    z[9,3,6]  R1895     -1.7986442148685455e-01
    z[4,9,0]  R38       -1
    z[4,9,0]  R83       1
    z[4,9,0]  R1896     -1
    z[4,9,0]  R1897     1
    z[4,9,0]  R1910     -5.2687013149261475e-01
    z[4,9,0]  R1911     -3.8885253667831421e-01
    z[4,9,0]  R1912     -2.4269014596939087e-01
    z[4,9,0]  R1913     -2.4279505014419556e-01
    z[4,9,0]  R1914     -6.4317220449447632e-01
    z[4,9,0]  R1915     -6.3531851768493652e-01
    z[4,9,0]  R1916     -5.0438493490219116e-01
    z[4,9,0]  R1917     -0.51566481590271
    z[4,9,0]  R1918     -3.3373662829399109e-01
    z[4,9,0]  R1919     -8.7058585882186890e-01
    z[4,9,0]  R1920     3.5148042440414429e-01
    z[4,9,0]  R1921     4.7380456328392029e-01
    z[4,9,0]  R1922     6.3418948650360107e-01
    z[4,9,0]  R1923     3.3327743411064148e-01
    z[4,9,0]  R1924     3.6435019969940186e-01
    z[4,9,0]  R1925     3.3907625079154968e-01
    z[4,9,0]  R1926     3.4834814071655273e-01
    z[4,9,0]  R1927     1.4997689425945282e-01
    z[4,9,0]  R1928     3.4531596302986145e-01
    z[4,9,0]  R1929     -2.4426843225955963e-01
    z[4,9,0]  R1930     2.2999662160873413e-01
    z[4,9,0]  R1931     -7.7903396449983120e-03
    z[4,9,0]  R1932     3.0323010683059692e-01
    z[4,9,0]  R1933     4.4778436422348022e-01
    z[4,9,0]  R1934     1.1714530736207962e-01
    z[4,9,0]  R1935     2.7664223313331604e-01
    z[4,9,0]  R1936     1.6158106923103333e-01
    z[4,9,0]  R1937     1.1710673570632935e-01
    z[4,9,0]  R1938     5.9388820081949234e-02
    z[4,9,0]  R1939     6.7244619131088257e-02
    z[4,9,0]  R1940     -7.2806432843208313e-02
    z[4,9,0]  R1941     3.0438588932156563e-02
    z[4,9,0]  R1942     -2.0102904736995697e-01
    z[4,9,0]  R1943     2.8570486232638359e-02
    z[4,9,0]  R1944     6.5622992813587189e-02
    z[4,9,0]  R1945     3.4725448489189148e-01
    z[4,9,0]  R1946     9.2229962348937988e-02
    z[4,9,0]  R1947     4.8041760921478271e-01
    z[4,9,0]  R1948     5.3070294857025146e-01
    z[4,9,0]  R1949     -1.5743415057659149e-01
    z[4,9,0]  R1950     -6.4548724889755249e-01
    z[4,9,0]  R1951     -4.4700339436531067e-01
    z[4,9,0]  R1952     -5.7674968242645264e-01
    z[4,9,0]  R1953     -5.1093703508377075e-01
    z[4,9,0]  R1954     -1.0504309833049774e-01
    z[4,9,0]  R1955     -1.6773472726345062e-01
    z[4,9,0]  R1956     -4.2771536111831665e-01
    z[4,9,0]  R1957     3.5226613283157349e-01
    z[4,9,0]  R1958     1.7311668395996094e-01
    z[4,9,0]  R1959     4.0123113989830017e-01
    z[4,9,0]  R1960     0.0276805367320776
    z[4,9,0]  R1961     -3.9720579981803894e-01
    z[4,9,0]  R1962     -2.8522130846977234e-01
    z[4,9,0]  R1963     -6.4319148659706116e-02
    z[4,9,0]  R1964     6.8526464700698853e-01
    z[4,9,0]  R1965     3.9928045868873596e-01
    z[4,9,0]  R1966     -2.7383902668952942e-01
    z[4,9,0]  R1967     2.9671835899353027e-01
    z[4,9,0]  R1968     5.3257542848587036e-01
    z[4,9,0]  R1969     3.9325863122940063e-01
    z[4,9,0]  R1970     3.3369913697242737e-01
    z[4,9,0]  R1971     4.9956884980201721e-01
    z[4,9,0]  R1972     2.3757702112197876e-01
    z[4,9,0]  R1973     3.2133832573890686e-01
    z[4,9,0]  R1974     3.3036302775144577e-02
    z[4,9,0]  R1975     4.1061779856681824e-01
    z[4,9,0]  R1976     -1.7351135611534119e-02
    z[4,9,0]  R1977     2.0395504310727119e-02
    z[4,9,0]  R1978     -1.4109697937965393e-01
    z[4,9,0]  R1979     1.5128690004348755e-01
    z[4,9,1]  R39       -1
    z[4,9,1]  R84       1
    z[4,9,1]  R1898     -1
    z[4,9,1]  R1899     1
    z[4,9,1]  R1910     -4.7371357679367065e-02
    z[4,9,1]  R1911     4.9620330333709717e-01
    z[4,9,1]  R1912     0.249917671084404
    z[4,9,1]  R1913     1.2432807683944702e-01
    z[4,9,1]  R1914     6.3261699676513672e-01
    z[4,9,1]  R1915     1.8798816204071045e-01
    z[4,9,1]  R1916     1.8632699549198151e-01
    z[4,9,1]  R1917     1.9373770058155060e-01
    z[4,9,1]  R1918     5.3115576505661011e-01
    z[4,9,1]  R1919     -7.9930663108825684e-02
    z[4,9,1]  R1920     -1.1468087136745453e-01
    z[4,9,1]  R1921     -2.5782150030136108e-01
    z[4,9,1]  R1922     -1.1214705556631088e-01
    z[4,9,1]  R1923     -1.4951537549495697e-01
    z[4,9,1]  R1924     5.5012357234954834e-01
    z[4,9,1]  R1925     -9.5172375440597534e-02
    z[4,9,1]  R1926     5.0524824857711792e-01
    z[4,9,1]  R1927     -2.2338593006134033e-01
    z[4,9,1]  R1928     3.0758830904960632e-01
    z[4,9,1]  R1929     0.155996635556221
    z[4,9,1]  R1930     -6.5523695945739746e-01
    z[4,9,1]  R1931     -0.941007137298584
    z[4,9,1]  R1932     -7.8983032703399658e-01
    z[4,9,1]  R1933     7.2181189060211182e-01
    z[4,9,1]  R1934     0.701270580291748
    z[4,9,1]  R1935     5.3694558143615723e-01
    z[4,9,1]  R1936     -3.7327718734741211e-01
    z[4,9,1]  R1937     -8.3622777462005615e-01
    z[4,9,1]  R1938     -8.0783206224441528e-01
    z[4,9,1]  R1939     -8.1421262025833130e-01
    z[4,9,1]  R1940     -5.7421392202377319e-01
    z[4,9,1]  R1941     -5.5053830146789551e-01
    z[4,9,1]  R1942     -6.1403536796569824e-01
    z[4,9,1]  R1943     -7.8212535381317139e-01
    z[4,9,1]  R1944     7.3139268159866333e-01
    z[4,9,1]  R1945     -1.6193135082721710e-01
    z[4,9,1]  R1946     -7.0713929831981659e-02
    z[4,9,1]  R1947     -1.5904399752616882e-01
    z[4,9,1]  R1948     0.622560441493988
    z[4,9,1]  R1949     -0.65133136510849
    z[4,9,1]  R1950     2.2078971564769745e-01
    z[4,9,1]  R1951     2.4528747797012329e-01
    z[4,9,1]  R1952     2.2886614501476288e-01
    z[4,9,1]  R1953     6.2833614647388458e-02
    z[4,9,1]  R1954     0.0522940419614315
    z[4,9,1]  R1955     -2.3030752781778574e-03
    z[4,9,1]  R1956     3.7983089685440063e-01
    z[4,9,1]  R1957     4.4141745567321777e-01
    z[4,9,1]  R1958     2.0452353358268738e-01
    z[4,9,1]  R1959     -2.5731673836708069e-01
    z[4,9,1]  R1960     3.0860263109207153e-01
    z[4,9,1]  R1961     2.1323890984058380e-01
    z[4,9,1]  R1962     2.2095717489719391e-01
    z[4,9,1]  R1963     4.7474063932895660e-02
    z[4,9,1]  R1964     -4.9295875430107117e-01
    z[4,9,1]  R1965     1.2208233773708344e-01
    z[4,9,1]  R1966     -8.2709372043609619e-01
    z[4,9,1]  R1967     -7.6416867971420288e-01
    z[4,9,1]  R1968     -4.6448597311973572e-01
    z[4,9,1]  R1969     -7.0766109228134155e-01
    z[4,9,1]  R1970     3.9264941215515137e-01
    z[4,9,1]  R1971     2.8469431400299072e-01
    z[4,9,1]  R1972     3.3902174234390259e-01
    z[4,9,1]  R1973     -7.2685462236404419e-01
    z[4,9,1]  R1974     -8.2207417488098145e-01
    z[4,9,1]  R1975     -6.3087242841720581e-01
    z[4,9,1]  R1976     -6.2628740072250366e-01
    z[4,9,1]  R1977     -8.5059094429016113e-01
    z[4,9,1]  R1978     -4.3481594324111938e-01
    z[4,9,1]  R1979     -4.0053021907806396e-01
    z[4,9,2]  R40       -1
    z[4,9,2]  R85       1
    z[4,9,2]  R1900     -1
    z[4,9,2]  R1901     1
    z[4,9,2]  R1910     3.8109385967254639e-01
    z[4,9,2]  R1911     -9.2280693352222443e-02
    z[4,9,2]  R1912     -1.6449901461601257e-01
    z[4,9,2]  R1913     1.3156543672084808e-01
    z[4,9,2]  R1914     -2.0533861592411995e-02
    z[4,9,2]  R1915     1.7293557524681091e-01
    z[4,9,2]  R1916     -4.6211230754852295e-01
    z[4,9,2]  R1917     -9.1871142387390137e-02
    z[4,9,2]  R1918     2.2585256025195122e-02
    z[4,9,2]  R1919     -0.323942631483078
    z[4,9,2]  R1920     -7.6226669549942017e-01
    z[4,9,2]  R1921     -0.715878427028656
    z[4,9,2]  R1922     -7.0156681537628174e-01
    z[4,9,2]  R1923     -5.8445763587951660e-01
    z[4,9,2]  R1924     -1.9999657571315765e-01
    z[4,9,2]  R1925     -8.4788095951080322e-01
    z[4,9,2]  R1926     7.7022358775138855e-02
    z[4,9,2]  R1927     -5.7364231348037720e-01
    z[4,9,2]  R1928     -6.5900450944900513e-01
    z[4,9,2]  R1929     -0.00027977250283584
    z[4,9,2]  R1930     -2.8405159711837769e-01
    z[4,9,2]  R1931     -2.5056964159011841e-01
    z[4,9,2]  R1932     -2.8313216567039490e-01
    z[4,9,2]  R1933     3.5051146149635315e-01
    z[4,9,2]  R1934     2.1773280203342438e-01
    z[4,9,2]  R1935     0.0203268900513649
    z[4,9,2]  R1936     -7.4416553974151611e-01
    z[4,9,2]  R1937     -1.0377339087426662e-02
    z[4,9,2]  R1938     -1.9353257119655609e-01
    z[4,9,2]  R1939     3.7098485231399536e-01
    z[4,9,2]  R1940     -5.7792204618453979e-01
    z[4,9,2]  R1941     -6.0849994421005249e-01
    z[4,9,2]  R1942     -0.646791398525238
    z[4,9,2]  R1943     -5.6640064716339111e-01
    z[4,9,2]  R1944     -2.0056138932704926e-01
    z[4,9,2]  R1945     -6.0195660591125488e-01
    z[4,9,2]  R1946     -7.5881606340408325e-01
    z[4,9,2]  R1947     -7.5291055440902710e-01
    z[4,9,2]  R1948     -3.8880684971809387e-01
    z[4,9,2]  R1949     1.8105547130107880e-01
    z[4,9,2]  R1950     2.4331012368202209e-01
    z[4,9,2]  R1951     -1.3265152275562286e-01
    z[4,9,2]  R1952     1.2788438796997070e-01
    z[4,9,2]  R1953     2.6188468933105469e-01
    z[4,9,2]  R1954     4.9405732750892639e-01
    z[4,9,2]  R1955     4.7037251293659210e-02
    z[4,9,2]  R1956     -2.5888139009475708e-01
    z[4,9,2]  R1957     -5.1113259792327881e-01
    z[4,9,2]  R1958     -8.2068789005279541e-01
    z[4,9,2]  R1959     -7.1421772241592407e-01
    z[4,9,2]  R1960     7.4786305427551270e-01
    z[4,9,2]  R1961     -1.1644738167524338e-01
    z[4,9,2]  R1962     3.0187538266181946e-01
    z[4,9,2]  R1963     3.9523360133171082e-01
    z[4,9,2]  R1964     -1.0738720744848251e-01
    z[4,9,2]  R1965     7.8273884952068329e-02
    z[4,9,2]  R1966     -2.1103464066982269e-01
    z[4,9,2]  R1967     -1.7358438670635223e-01
    z[4,9,2]  R1968     -1.4429225027561188e-01
    z[4,9,2]  R1969     -1.3068130612373352e-01
    z[4,9,2]  R1970     3.3380672335624695e-01
    z[4,9,2]  R1971     0.0972277969121933
    z[4,9,2]  R1972     -4.9237540364265442e-01
    z[4,9,2]  R1973     -2.4246707558631897e-01
    z[4,9,2]  R1974     -3.6731344461441040e-01
    z[4,9,2]  R1975     2.0351560413837433e-01
    z[4,9,2]  R1976     -7.0530956983566284e-01
    z[4,9,2]  R1977     3.3843708038330078e-01
    z[4,9,2]  R1978     -8.0793344974517822e-01
    z[4,9,2]  R1979     -7.0788913965225220e-01
    z[4,9,3]  R41       -1
    z[4,9,3]  R86       1
    z[4,9,3]  R1902     -1
    z[4,9,3]  R1903     1
    z[4,9,3]  R1910     7.5379502773284912e-01
    z[4,9,3]  R1911     7.2185969352722168e-01
    z[4,9,3]  R1912     8.0861675739288330e-01
    z[4,9,3]  R1913     7.5874310731887817e-01
    z[4,9,3]  R1914     3.6285862326622009e-01
    z[4,9,3]  R1915     3.2614475488662720e-01
    z[4,9,3]  R1916     5.6435036659240723e-01
    z[4,9,3]  R1917     0.485765665769577
    z[4,9,3]  R1918     0.478840172290802
    z[4,9,3]  R1919     3.0022773146629333e-01
    z[4,9,3]  R1920     -1.1939670890569687e-01
    z[4,9,3]  R1921     -1.6397005319595337e-01
    z[4,9,3]  R1922     1.1394886672496796e-01
    z[4,9,3]  R1923     -5.8058798313140869e-02
    z[4,9,3]  R1924     -5.0612813234329224e-01
    z[4,9,3]  R1925     -1.5639641880989075e-01
    z[4,9,3]  R1926     -7.6384562253952026e-01
    z[4,9,3]  R1927     -5.2899336814880371e-01
    z[4,9,3]  R1928     -3.6867135763168335e-01
    z[4,9,3]  R1929     -8.2957327365875244e-01
    z[4,9,3]  R1930     3.0132922530174255e-01
    z[4,9,3]  R1931     -1.3027971610426903e-02
    z[4,9,3]  R1932     -9.3312285840511322e-02
    z[4,9,3]  R1933     -3.8585272431373596e-01
    z[4,9,3]  R1934     -4.4136798381805420e-01
    z[4,9,3]  R1935     -5.2970415353775024e-01
    z[4,9,3]  R1936     3.6093601584434509e-01
    z[4,9,3]  R1937     -2.8059422969818115e-01
    z[4,9,3]  R1938     -4.1917464137077332e-01
    z[4,9,3]  R1939     -3.8996261358261108e-01
    z[4,9,3]  R1940     4.6877363324165344e-01
    z[4,9,3]  R1941     -8.6615577340126038e-02
    z[4,9,3]  R1942     -2.2012059390544891e-01
    z[4,9,3]  R1943     5.0543542951345444e-02
    z[4,9,3]  R1944     -6.3995105028152466e-01
    z[4,9,3]  R1945     3.0255696177482605e-01
    z[4,9,3]  R1946     -3.9645433425903320e-02
    z[4,9,3]  R1947     0.281955748796463
    z[4,9,3]  R1948     -2.4808716773986816e-01
    z[4,9,3]  R1949     -1.3536064326763153e-01
    z[4,9,3]  R1950     6.4667350053787231e-01
    z[4,9,3]  R1951     8.1469595432281494e-01
    z[4,9,3]  R1952     5.7284229993820190e-01
    z[4,9,3]  R1953     5.4776233434677124e-01
    z[4,9,3]  R1954     7.6668906211853027e-01
    z[4,9,3]  R1955     0.730480432510376
    z[4,9,3]  R1956     4.7357723116874695e-01
    z[4,9,3]  R1957     -7.3143742978572845e-02
    z[4,9,3]  R1958     -0.0997811034321785
    z[4,9,3]  R1959     2.1516993641853333e-01
    z[4,9,3]  R1960     -5.5850225687026978e-01
    z[4,9,3]  R1961     -7.5867593288421631e-01
    z[4,9,3]  R1962     -7.0465826988220215e-01
    z[4,9,3]  R1963     -8.2727390527725220e-01
    z[4,9,3]  R1964     -9.1780357062816620e-02
    z[4,9,3]  R1965     -2.3147705197334290e-01
    z[4,9,3]  R1966     -5.9007301926612854e-02
    z[4,9,3]  R1967     -1.7165517807006836e-01
    z[4,9,3]  R1968     -7.4143759906291962e-02
    z[4,9,3]  R1969     -1.9601134955883026e-01
    z[4,9,3]  R1970     -5.2687042951583862e-01
    z[4,9,3]  R1971     -2.5929272174835205e-01
    z[4,9,3]  R1972     -1.1953826993703842e-01
    z[4,9,3]  R1973     4.2547813057899475e-01
    z[4,9,3]  R1974     -2.6645886898040771e-01
    z[4,9,3]  R1975     2.3811502754688263e-01
    z[4,9,3]  R1976     1.0545709729194641e-01
    z[4,9,3]  R1977     -1.3102434575557709e-01
    z[4,9,3]  R1978     -4.0756408125162125e-02
    z[4,9,3]  R1979     1.2913256883621216e-01
    z[4,9,4]  R42       -1
    z[4,9,4]  R87       1
    z[4,9,4]  R1904     -1
    z[4,9,4]  R1905     1
    z[4,9,4]  R1910     -5.0889246165752411e-02
    z[4,9,4]  R1911     -1.6214188933372498e-01
    z[4,9,4]  R1912     3.7026622891426086e-01
    z[4,9,4]  R1913     4.5634895563125610e-01
    z[4,9,4]  R1914     -1.3036662340164185e-01
    z[4,9,4]  R1915     6.4262598752975464e-01
    z[4,9,4]  R1916     -2.6475492119789124e-01
    z[4,9,4]  R1917     -0.507340669631958
    z[4,9,4]  R1918     -4.7905972599983215e-01
    z[4,9,4]  R1919     3.6090143024921417e-02
    z[4,9,4]  R1920     3.3842098712921143e-01
    z[4,9,4]  R1921     2.7324205636978149e-01
    z[4,9,4]  R1922     2.7367309667170048e-03
    z[4,9,4]  R1923     -4.4276732951402664e-02
    z[4,9,4]  R1924     -4.8324775695800781e-01
    z[4,9,4]  R1925     5.8567330241203308e-02
    z[4,9,4]  R1926     1.8050818145275116e-01
    z[4,9,4]  R1927     -5.3812479972839355e-01
    z[4,9,4]  R1928     4.4043079018592834e-01
    z[4,9,4]  R1929     -4.7311961650848389e-02
    z[4,9,4]  R1930     -1.9998279213905334e-01
    z[4,9,4]  R1931     0.0872771218419075
    z[4,9,4]  R1932     2.4556741118431091e-01
    z[4,9,4]  R1933     -4.0157355368137360e-02
    z[4,9,4]  R1934     -0.0919187143445015
    z[4,9,4]  R1935     -1.7670853435993195e-01
    z[4,9,4]  R1936     6.5559864044189453e-02
    z[4,9,4]  R1937     0.433892160654068
    z[4,9,4]  R1938     -2.6337581872940063e-01
    z[4,9,4]  R1939     -1.1109060049057007e-01
    z[4,9,4]  R1940     -2.6722019910812378e-01
    z[4,9,4]  R1941     -2.4733142554759979e-01
    z[4,9,4]  R1942     5.0069648772478104e-02
    z[4,9,4]  R1943     2.1795381605625153e-01
    z[4,9,4]  R1944     9.0350754559040070e-02
    z[4,9,4]  R1945     0.386310338973999
    z[4,9,4]  R1946     4.6342912316322327e-01
    z[4,9,4]  R1947     -1.7118453979492188e-01
    z[4,9,4]  R1948     -2.1818645298480988e-01
    z[4,9,4]  R1949     -6.3431066274642944e-01
    z[4,9,4]  R1950     -8.6017400026321411e-03
    z[4,9,4]  R1951     -1.5056072175502777e-01
    z[4,9,4]  R1952     4.2689535021781921e-01
    z[4,9,4]  R1953     -5.1363629102706909e-01
    z[4,9,4]  R1954     -2.2283342480659485e-01
    z[4,9,4]  R1955     1.4258655905723572e-01
    z[4,9,4]  R1956     1.0501173883676529e-01
    z[4,9,4]  R1957     -6.3213360309600830e-01
    z[4,9,4]  R1958     3.6314094066619873e-01
    z[4,9,4]  R1959     5.1917150616645813e-02
    z[4,9,4]  R1960     -1.1632586270570755e-01
    z[4,9,4]  R1961     2.6178082823753357e-01
    z[4,9,4]  R1962     -1.4302109181880951e-01
    z[4,9,4]  R1963     2.1030455827713013e-03
    z[4,9,4]  R1964     -2.5131186842918396e-01
    z[4,9,4]  R1965     2.9953831434249878e-01
    z[4,9,4]  R1966     3.2541179656982422e-01
    z[4,9,4]  R1967     -3.2191792130470276e-01
    z[4,9,4]  R1968     -2.9407319426536560e-01
    z[4,9,4]  R1969     -1.6345328092575073e-01
    z[4,9,4]  R1970     -3.3638164401054382e-02
    z[4,9,4]  R1971     5.6115162372589111e-01
    z[4,9,4]  R1972     0.313353568315506
    z[4,9,4]  R1973     -1.4223536849021912e-01
    z[4,9,4]  R1974     -1.7988644540309906e-02
    z[4,9,4]  R1975     1.2636347115039825e-01
    z[4,9,4]  R1976     1.0123517364263535e-01
    z[4,9,4]  R1977     1.1130163073539734e-01
    z[4,9,4]  R1978     -9.8336994647979736e-02
    z[4,9,4]  R1979     -1.6293426975607872e-02
    z[4,9,5]  R43       -1
    z[4,9,5]  R88       1
    z[4,9,5]  R1906     -1
    z[4,9,5]  R1907     1
    z[4,9,5]  R1910     5.4527290165424347e-02
    z[4,9,5]  R1911     -2.1007929742336273e-01
    z[4,9,5]  R1912     -2.6475070044398308e-02
    z[4,9,5]  R1913     -0.246475487947464
    z[4,9,5]  R1914     -3.0580822378396988e-02
    z[4,9,5]  R1915     9.2176623642444611e-02
    z[4,9,5]  R1916     1.3062807917594910e-01
    z[4,9,5]  R1917     -1.8804956972599030e-01
    z[4,9,5]  R1918     1.5617184340953827e-01
    z[4,9,5]  R1919     7.7737517654895782e-02
    z[4,9,5]  R1920     3.8307833671569824e-01
    z[4,9,5]  R1921     1.5141792595386505e-01
    z[4,9,5]  R1922     2.1675595641136169e-01
    z[4,9,5]  R1923     5.5689728260040283e-01
    z[4,9,5]  R1924     -1.2681010365486145e-01
    z[4,9,5]  R1925     -1.3120164163410664e-02
    z[4,9,5]  R1926     2.9955340549349785e-02
    z[4,9,5]  R1927     1.4351907372474670e-01
    z[4,9,5]  R1928     -5.1002725958824158e-02
    z[4,9,5]  R1929     4.7414085268974304e-01
    z[4,9,5]  R1930     5.0324422121047974e-01
    z[4,9,5]  R1931     1.5538723766803741e-01
    z[4,9,5]  R1932     3.6747229099273682e-01
    z[4,9,5]  R1933     -2.6824072003364563e-02
    z[4,9,5]  R1934     -2.0342393219470978e-01
    z[4,9,5]  R1935     2.7847746014595032e-01
    z[4,9,5]  R1936     -3.1787642836570740e-01
    z[4,9,5]  R1937     1.2250393629074097e-01
    z[4,9,5]  R1938     -1.2531944550573826e-02
    z[4,9,5]  R1939     9.7767621278762817e-02
    z[4,9,5]  R1940     3.7031225860118866e-02
    z[4,9,5]  R1941     4.6168947219848633e-01
    z[4,9,5]  R1942     2.8578832745552063e-01
    z[4,9,5]  R1943     -8.6044684052467346e-02
    z[4,9,5]  R1944     5.2624985575675964e-02
    z[4,9,5]  R1945     3.3586233854293823e-01
    z[4,9,5]  R1946     2.5605341792106628e-01
    z[4,9,5]  R1947     -2.2904913127422333e-01
    z[4,9,5]  R1948     -5.6428514420986176e-02
    z[4,9,5]  R1949     2.5904285907745361e-01
    z[4,9,5]  R1950     -1.6714364290237427e-01
    z[4,9,5]  R1951     -1.0922791436314583e-02
    z[4,9,5]  R1952     -0.0778147503733635
    z[4,9,5]  R1953     2.7469709515571594e-01
    z[4,9,5]  R1954     -2.0084667205810547e-01
    z[4,9,5]  R1955     -3.0417975783348083e-01
    z[4,9,5]  R1956     -1.1976343393325806e-01
    z[4,9,5]  R1957     -3.0184416100382805e-02
    z[4,9,5]  R1958     -2.6337811350822449e-01
    z[4,9,5]  R1959     4.4822424650192261e-01
    z[4,9,5]  R1960     1.3516438007354736e-01
    z[4,9,5]  R1961     0.371501088142395
    z[4,9,5]  R1962     4.6095588803291321e-01
    z[4,9,5]  R1963     2.9762476682662964e-01
    z[4,9,5]  R1964     -4.3573114275932312e-01
    z[4,9,5]  R1965     -2.2947339713573456e-01
    z[4,9,5]  R1966     2.8953146934509277e-01
    z[4,9,5]  R1967     1.8770781159400940e-01
    z[4,9,5]  R1968     2.4617239832878113e-02
    z[4,9,5]  R1969     1.5098921954631805e-01
    z[4,9,5]  R1970     -1.7260673642158508e-01
    z[4,9,5]  R1971     -5.2695637941360474e-01
    z[4,9,5]  R1972     -2.2647507488727570e-01
    z[4,9,5]  R1973     -1.3525488972663879e-01
    z[4,9,5]  R1974     3.0662909150123596e-01
    z[4,9,5]  R1975     -1.7903931438922882e-01
    z[4,9,5]  R1976     1.5412282943725586e-01
    z[4,9,5]  R1977     2.3304232954978943e-01
    z[4,9,5]  R1978     3.4626227617263794e-01
    z[4,9,5]  R1979     0.53646320104599
    z[4,9,6]  R44       -1
    z[4,9,6]  R89       1
    z[4,9,6]  R1908     -1
    z[4,9,6]  R1909     1
    z[4,9,6]  R1910     -3.4079443663358688e-02
    z[4,9,6]  R1911     -5.0551801919937134e-02
    z[4,9,6]  R1912     -2.4479311704635620e-01
    z[4,9,6]  R1913     2.5216671824455261e-01
    z[4,9,6]  R1914     1.9001729786396027e-01
    z[4,9,6]  R1915     5.7350657880306244e-02
    z[4,9,6]  R1916     -3.0278715491294861e-01
    z[4,9,6]  R1917     3.9923647046089172e-01
    z[4,9,6]  R1918     -3.5043925046920776e-01
    z[4,9,6]  R1919     1.8240106105804443e-01
    z[4,9,6]  R1920     8.2011222839355469e-02
    z[4,9,6]  R1921     -2.6847827434539795e-01
    z[4,9,6]  R1922     1.8181236088275909e-01
    z[4,9,6]  R1923     4.5772776007652283e-01
    z[4,9,6]  R1924     1.3725706934928894e-01
    z[4,9,6]  R1925     3.5917314887046814e-01
    z[4,9,6]  R1926     2.2462695837020874e-02
    z[4,9,6]  R1927     0.09235879778862
    z[4,9,6]  R1928     -1.3914184272289276e-01
    z[4,9,6]  R1929     -2.7535000815987587e-02
    z[4,9,6]  R1930     -2.3029008507728577e-01
    z[4,9,6]  R1931     -1.4045518636703491e-01
    z[4,9,6]  R1932     3.0451181810349226e-03
    z[4,9,6]  R1933     -6.6363111138343811e-02
    z[4,9,6]  R1934     0.449947714805603
    z[4,9,6]  R1935     -4.9536174535751343e-01
    z[4,9,6]  R1936     2.1249692142009735e-01
    z[4,9,6]  R1937     -0.0699910819530487
    z[4,9,6]  R1938     2.4737489223480225e-01
    z[4,9,6]  R1939     1.4469218254089355e-01
    z[4,9,6]  R1940     1.9610424339771271e-01
    z[4,9,6]  R1941     -2.0946766436100006e-01
    z[4,9,6]  R1942     1.7768968641757965e-01
    z[4,9,6]  R1943     9.5873691141605377e-02
    z[4,9,6]  R1944     7.9661142081022263e-03
    z[4,9,6]  R1945     3.7048736214637756e-01
    z[4,9,6]  R1946     -3.5887271165847778e-01
    z[4,9,6]  R1947     -1.2554962933063507e-01
    z[4,9,6]  R1948     -2.5935578346252441e-01
    z[4,9,6]  R1949     -1.7442846298217773e-01
    z[4,9,6]  R1950     1.7088238894939423e-01
    z[4,9,6]  R1951     -1.8949435651302338e-01
    z[4,9,6]  R1952     -2.8667521476745605e-01
    z[4,9,6]  R1953     1.6458222270011902e-01
    z[4,9,6]  R1954     2.5363853573799133e-01
    z[4,9,6]  R1955     5.6849747896194458e-01
    z[4,9,6]  R1956     5.9675979614257812e-01
    z[4,9,6]  R1957     1.1810465157032013e-01
    z[4,9,6]  R1958     2.0851017534732819e-01
    z[4,9,6]  R1959     -1.1312078684568405e-01
    z[4,9,6]  R1960     -3.1195651739835739e-02
    z[4,9,6]  R1961     3.2639726996421814e-02
    z[4,9,6]  R1962     -2.2185422480106354e-01
    z[4,9,6]  R1963     2.5383546948432922e-01
    z[4,9,6]  R1964     -1.2012134492397308e-01
    z[4,9,6]  R1965     -7.8967171907424927e-01
    z[4,9,6]  R1966     -5.6475266814231873e-02
    z[4,9,6]  R1967     3.5991939902305603e-01
    z[4,9,6]  R1968     -6.2226498126983643e-01
    z[4,9,6]  R1969     -4.8943912982940674e-01
    z[4,9,6]  R1970     0.560827374458313
    z[4,9,6]  R1971     1.0953530669212341e-02
    z[4,9,6]  R1972     -0.649936318397522
    z[4,9,6]  R1973     -3.0012881755828857e-01
    z[4,9,6]  R1974     1.5112267434597015e-01
    z[4,9,6]  R1975     -5.3595972061157227e-01
    z[4,9,6]  R1976     -2.5471115112304688e-01
    z[4,9,6]  R1977     -2.7870258688926697e-01
    z[4,9,6]  R1978     8.3913028240203857e-02
    z[4,9,6]  R1979     1.0414987057447433e-01
    z[9,4,0]  R38       1
    z[9,4,0]  R83       -1
    z[9,4,0]  R1980     -1
    z[9,4,0]  R1981     1
    z[9,4,0]  R1994     -6.4548724889755249e-01
    z[9,4,0]  R1995     -4.4700339436531067e-01
    z[9,4,0]  R1996     -5.7674968242645264e-01
    z[9,4,0]  R1997     -5.1093703508377075e-01
    z[9,4,0]  R1998     -1.0504309833049774e-01
    z[9,4,0]  R1999     -1.6773472726345062e-01
    z[9,4,0]  R2000     -4.2771536111831665e-01
    z[9,4,0]  R2001     3.5226613283157349e-01
    z[9,4,0]  R2002     1.7311668395996094e-01
    z[9,4,0]  R2003     4.0123113989830017e-01
    z[9,4,0]  R2004     0.0276805367320776
    z[9,4,0]  R2005     -3.9720579981803894e-01
    z[9,4,0]  R2006     -2.8522130846977234e-01
    z[9,4,0]  R2007     -6.4319148659706116e-02
    z[9,4,0]  R2008     6.8526464700698853e-01
    z[9,4,0]  R2009     3.9928045868873596e-01
    z[9,4,0]  R2010     -2.7383902668952942e-01
    z[9,4,0]  R2011     2.9671835899353027e-01
    z[9,4,0]  R2012     5.3257542848587036e-01
    z[9,4,0]  R2013     3.9325863122940063e-01
    z[9,4,0]  R2014     3.3369913697242737e-01
    z[9,4,0]  R2015     4.9956884980201721e-01
    z[9,4,0]  R2016     2.3757702112197876e-01
    z[9,4,0]  R2017     3.2133832573890686e-01
    z[9,4,0]  R2018     3.3036302775144577e-02
    z[9,4,0]  R2019     4.1061779856681824e-01
    z[9,4,0]  R2020     -1.7351135611534119e-02
    z[9,4,0]  R2021     2.0395504310727119e-02
    z[9,4,0]  R2022     -1.4109697937965393e-01
    z[9,4,0]  R2023     1.5128690004348755e-01
    z[9,4,0]  R2024     -5.2687013149261475e-01
    z[9,4,0]  R2025     -3.8885253667831421e-01
    z[9,4,0]  R2026     -2.4269014596939087e-01
    z[9,4,0]  R2027     -2.4279505014419556e-01
    z[9,4,0]  R2028     -6.4317220449447632e-01
    z[9,4,0]  R2029     -6.3531851768493652e-01
    z[9,4,0]  R2030     -5.0438493490219116e-01
    z[9,4,0]  R2031     -0.51566481590271
    z[9,4,0]  R2032     -3.3373662829399109e-01
    z[9,4,0]  R2033     -8.7058585882186890e-01
    z[9,4,0]  R2034     3.5148042440414429e-01
    z[9,4,0]  R2035     4.7380456328392029e-01
    z[9,4,0]  R2036     6.3418948650360107e-01
    z[9,4,0]  R2037     3.3327743411064148e-01
    z[9,4,0]  R2038     3.6435019969940186e-01
    z[9,4,0]  R2039     3.3907625079154968e-01
    z[9,4,0]  R2040     3.4834814071655273e-01
    z[9,4,0]  R2041     1.4997689425945282e-01
    z[9,4,0]  R2042     3.4531596302986145e-01
    z[9,4,0]  R2043     -2.4426843225955963e-01
    z[9,4,0]  R2044     2.2999662160873413e-01
    z[9,4,0]  R2045     -7.7903396449983120e-03
    z[9,4,0]  R2046     3.0323010683059692e-01
    z[9,4,0]  R2047     4.4778436422348022e-01
    z[9,4,0]  R2048     1.1714530736207962e-01
    z[9,4,0]  R2049     2.7664223313331604e-01
    z[9,4,0]  R2050     1.6158106923103333e-01
    z[9,4,0]  R2051     1.1710673570632935e-01
    z[9,4,0]  R2052     5.9388820081949234e-02
    z[9,4,0]  R2053     6.7244619131088257e-02
    z[9,4,0]  R2054     -7.2806432843208313e-02
    z[9,4,0]  R2055     3.0438588932156563e-02
    z[9,4,0]  R2056     -2.0102904736995697e-01
    z[9,4,0]  R2057     2.8570486232638359e-02
    z[9,4,0]  R2058     6.5622992813587189e-02
    z[9,4,0]  R2059     3.4725448489189148e-01
    z[9,4,0]  R2060     9.2229962348937988e-02
    z[9,4,0]  R2061     4.8041760921478271e-01
    z[9,4,0]  R2062     5.3070294857025146e-01
    z[9,4,0]  R2063     -1.5743415057659149e-01
    z[9,4,1]  R39       1
    z[9,4,1]  R84       -1
    z[9,4,1]  R1982     -1
    z[9,4,1]  R1983     1
    z[9,4,1]  R1994     2.2078971564769745e-01
    z[9,4,1]  R1995     2.4528747797012329e-01
    z[9,4,1]  R1996     2.2886614501476288e-01
    z[9,4,1]  R1997     6.2833614647388458e-02
    z[9,4,1]  R1998     0.0522940419614315
    z[9,4,1]  R1999     -2.3030752781778574e-03
    z[9,4,1]  R2000     3.7983089685440063e-01
    z[9,4,1]  R2001     4.4141745567321777e-01
    z[9,4,1]  R2002     2.0452353358268738e-01
    z[9,4,1]  R2003     -2.5731673836708069e-01
    z[9,4,1]  R2004     3.0860263109207153e-01
    z[9,4,1]  R2005     2.1323890984058380e-01
    z[9,4,1]  R2006     2.2095717489719391e-01
    z[9,4,1]  R2007     4.7474063932895660e-02
    z[9,4,1]  R2008     -4.9295875430107117e-01
    z[9,4,1]  R2009     1.2208233773708344e-01
    z[9,4,1]  R2010     -8.2709372043609619e-01
    z[9,4,1]  R2011     -7.6416867971420288e-01
    z[9,4,1]  R2012     -4.6448597311973572e-01
    z[9,4,1]  R2013     -7.0766109228134155e-01
    z[9,4,1]  R2014     3.9264941215515137e-01
    z[9,4,1]  R2015     2.8469431400299072e-01
    z[9,4,1]  R2016     3.3902174234390259e-01
    z[9,4,1]  R2017     -7.2685462236404419e-01
    z[9,4,1]  R2018     -8.2207417488098145e-01
    z[9,4,1]  R2019     -6.3087242841720581e-01
    z[9,4,1]  R2020     -6.2628740072250366e-01
    z[9,4,1]  R2021     -8.5059094429016113e-01
    z[9,4,1]  R2022     -4.3481594324111938e-01
    z[9,4,1]  R2023     -4.0053021907806396e-01
    z[9,4,1]  R2024     -4.7371357679367065e-02
    z[9,4,1]  R2025     4.9620330333709717e-01
    z[9,4,1]  R2026     0.249917671084404
    z[9,4,1]  R2027     1.2432807683944702e-01
    z[9,4,1]  R2028     6.3261699676513672e-01
    z[9,4,1]  R2029     1.8798816204071045e-01
    z[9,4,1]  R2030     1.8632699549198151e-01
    z[9,4,1]  R2031     1.9373770058155060e-01
    z[9,4,1]  R2032     5.3115576505661011e-01
    z[9,4,1]  R2033     -7.9930663108825684e-02
    z[9,4,1]  R2034     -1.1468087136745453e-01
    z[9,4,1]  R2035     -2.5782150030136108e-01
    z[9,4,1]  R2036     -1.1214705556631088e-01
    z[9,4,1]  R2037     -1.4951537549495697e-01
    z[9,4,1]  R2038     5.5012357234954834e-01
    z[9,4,1]  R2039     -9.5172375440597534e-02
    z[9,4,1]  R2040     5.0524824857711792e-01
    z[9,4,1]  R2041     -2.2338593006134033e-01
    z[9,4,1]  R2042     3.0758830904960632e-01
    z[9,4,1]  R2043     0.155996635556221
    z[9,4,1]  R2044     -6.5523695945739746e-01
    z[9,4,1]  R2045     -0.941007137298584
    z[9,4,1]  R2046     -7.8983032703399658e-01
    z[9,4,1]  R2047     7.2181189060211182e-01
    z[9,4,1]  R2048     0.701270580291748
    z[9,4,1]  R2049     5.3694558143615723e-01
    z[9,4,1]  R2050     -3.7327718734741211e-01
    z[9,4,1]  R2051     -8.3622777462005615e-01
    z[9,4,1]  R2052     -8.0783206224441528e-01
    z[9,4,1]  R2053     -8.1421262025833130e-01
    z[9,4,1]  R2054     -5.7421392202377319e-01
    z[9,4,1]  R2055     -5.5053830146789551e-01
    z[9,4,1]  R2056     -6.1403536796569824e-01
    z[9,4,1]  R2057     -7.8212535381317139e-01
    z[9,4,1]  R2058     7.3139268159866333e-01
    z[9,4,1]  R2059     -1.6193135082721710e-01
    z[9,4,1]  R2060     -7.0713929831981659e-02
    z[9,4,1]  R2061     -1.5904399752616882e-01
    z[9,4,1]  R2062     0.622560441493988
    z[9,4,1]  R2063     -0.65133136510849
    z[9,4,2]  R40       1
    z[9,4,2]  R85       -1
    z[9,4,2]  R1984     -1
    z[9,4,2]  R1985     1
    z[9,4,2]  R1994     2.4331012368202209e-01
    z[9,4,2]  R1995     -1.3265152275562286e-01
    z[9,4,2]  R1996     1.2788438796997070e-01
    z[9,4,2]  R1997     2.6188468933105469e-01
    z[9,4,2]  R1998     4.9405732750892639e-01
    z[9,4,2]  R1999     4.7037251293659210e-02
    z[9,4,2]  R2000     -2.5888139009475708e-01
    z[9,4,2]  R2001     -5.1113259792327881e-01
    z[9,4,2]  R2002     -8.2068789005279541e-01
    z[9,4,2]  R2003     -7.1421772241592407e-01
    z[9,4,2]  R2004     7.4786305427551270e-01
    z[9,4,2]  R2005     -1.1644738167524338e-01
    z[9,4,2]  R2006     3.0187538266181946e-01
    z[9,4,2]  R2007     3.9523360133171082e-01
    z[9,4,2]  R2008     -1.0738720744848251e-01
    z[9,4,2]  R2009     7.8273884952068329e-02
    z[9,4,2]  R2010     -2.1103464066982269e-01
    z[9,4,2]  R2011     -1.7358438670635223e-01
    z[9,4,2]  R2012     -1.4429225027561188e-01
    z[9,4,2]  R2013     -1.3068130612373352e-01
    z[9,4,2]  R2014     3.3380672335624695e-01
    z[9,4,2]  R2015     0.0972277969121933
    z[9,4,2]  R2016     -4.9237540364265442e-01
    z[9,4,2]  R2017     -2.4246707558631897e-01
    z[9,4,2]  R2018     -3.6731344461441040e-01
    z[9,4,2]  R2019     2.0351560413837433e-01
    z[9,4,2]  R2020     -7.0530956983566284e-01
    z[9,4,2]  R2021     3.3843708038330078e-01
    z[9,4,2]  R2022     -8.0793344974517822e-01
    z[9,4,2]  R2023     -7.0788913965225220e-01
    z[9,4,2]  R2024     3.8109385967254639e-01
    z[9,4,2]  R2025     -9.2280693352222443e-02
    z[9,4,2]  R2026     -1.6449901461601257e-01
    z[9,4,2]  R2027     1.3156543672084808e-01
    z[9,4,2]  R2028     -2.0533861592411995e-02
    z[9,4,2]  R2029     1.7293557524681091e-01
    z[9,4,2]  R2030     -4.6211230754852295e-01
    z[9,4,2]  R2031     -9.1871142387390137e-02
    z[9,4,2]  R2032     2.2585256025195122e-02
    z[9,4,2]  R2033     -0.323942631483078
    z[9,4,2]  R2034     -7.6226669549942017e-01
    z[9,4,2]  R2035     -0.715878427028656
    z[9,4,2]  R2036     -7.0156681537628174e-01
    z[9,4,2]  R2037     -5.8445763587951660e-01
    z[9,4,2]  R2038     -1.9999657571315765e-01
    z[9,4,2]  R2039     -8.4788095951080322e-01
    z[9,4,2]  R2040     7.7022358775138855e-02
    z[9,4,2]  R2041     -5.7364231348037720e-01
    z[9,4,2]  R2042     -6.5900450944900513e-01
    z[9,4,2]  R2043     -0.00027977250283584
    z[9,4,2]  R2044     -2.8405159711837769e-01
    z[9,4,2]  R2045     -2.5056964159011841e-01
    z[9,4,2]  R2046     -2.8313216567039490e-01
    z[9,4,2]  R2047     3.5051146149635315e-01
    z[9,4,2]  R2048     2.1773280203342438e-01
    z[9,4,2]  R2049     0.0203268900513649
    z[9,4,2]  R2050     -7.4416553974151611e-01
    z[9,4,2]  R2051     -1.0377339087426662e-02
    z[9,4,2]  R2052     -1.9353257119655609e-01
    z[9,4,2]  R2053     3.7098485231399536e-01
    z[9,4,2]  R2054     -5.7792204618453979e-01
    z[9,4,2]  R2055     -6.0849994421005249e-01
    z[9,4,2]  R2056     -0.646791398525238
    z[9,4,2]  R2057     -5.6640064716339111e-01
    z[9,4,2]  R2058     -2.0056138932704926e-01
    z[9,4,2]  R2059     -6.0195660591125488e-01
    z[9,4,2]  R2060     -7.5881606340408325e-01
    z[9,4,2]  R2061     -7.5291055440902710e-01
    z[9,4,2]  R2062     -3.8880684971809387e-01
    z[9,4,2]  R2063     1.8105547130107880e-01
    z[9,4,3]  R41       1
    z[9,4,3]  R86       -1
    z[9,4,3]  R1986     -1
    z[9,4,3]  R1987     1
    z[9,4,3]  R1994     6.4667350053787231e-01
    z[9,4,3]  R1995     8.1469595432281494e-01
    z[9,4,3]  R1996     5.7284229993820190e-01
    z[9,4,3]  R1997     5.4776233434677124e-01
    z[9,4,3]  R1998     7.6668906211853027e-01
    z[9,4,3]  R1999     0.730480432510376
    z[9,4,3]  R2000     4.7357723116874695e-01
    z[9,4,3]  R2001     -7.3143742978572845e-02
    z[9,4,3]  R2002     -0.0997811034321785
    z[9,4,3]  R2003     2.1516993641853333e-01
    z[9,4,3]  R2004     -5.5850225687026978e-01
    z[9,4,3]  R2005     -7.5867593288421631e-01
    z[9,4,3]  R2006     -7.0465826988220215e-01
    z[9,4,3]  R2007     -8.2727390527725220e-01
    z[9,4,3]  R2008     -9.1780357062816620e-02
    z[9,4,3]  R2009     -2.3147705197334290e-01
    z[9,4,3]  R2010     -5.9007301926612854e-02
    z[9,4,3]  R2011     -1.7165517807006836e-01
    z[9,4,3]  R2012     -7.4143759906291962e-02
    z[9,4,3]  R2013     -1.9601134955883026e-01
    z[9,4,3]  R2014     -5.2687042951583862e-01
    z[9,4,3]  R2015     -2.5929272174835205e-01
    z[9,4,3]  R2016     -1.1953826993703842e-01
    z[9,4,3]  R2017     4.2547813057899475e-01
    z[9,4,3]  R2018     -2.6645886898040771e-01
    z[9,4,3]  R2019     2.3811502754688263e-01
    z[9,4,3]  R2020     1.0545709729194641e-01
    z[9,4,3]  R2021     -1.3102434575557709e-01
    z[9,4,3]  R2022     -4.0756408125162125e-02
    z[9,4,3]  R2023     1.2913256883621216e-01
    z[9,4,3]  R2024     7.5379502773284912e-01
    z[9,4,3]  R2025     7.2185969352722168e-01
    z[9,4,3]  R2026     8.0861675739288330e-01
    z[9,4,3]  R2027     7.5874310731887817e-01
    z[9,4,3]  R2028     3.6285862326622009e-01
    z[9,4,3]  R2029     3.2614475488662720e-01
    z[9,4,3]  R2030     5.6435036659240723e-01
    z[9,4,3]  R2031     0.485765665769577
    z[9,4,3]  R2032     0.478840172290802
    z[9,4,3]  R2033     3.0022773146629333e-01
    z[9,4,3]  R2034     -1.1939670890569687e-01
    z[9,4,3]  R2035     -1.6397005319595337e-01
    z[9,4,3]  R2036     1.1394886672496796e-01
    z[9,4,3]  R2037     -5.8058798313140869e-02
    z[9,4,3]  R2038     -5.0612813234329224e-01
    z[9,4,3]  R2039     -1.5639641880989075e-01
    z[9,4,3]  R2040     -7.6384562253952026e-01
    z[9,4,3]  R2041     -5.2899336814880371e-01
    z[9,4,3]  R2042     -3.6867135763168335e-01
    z[9,4,3]  R2043     -8.2957327365875244e-01
    z[9,4,3]  R2044     3.0132922530174255e-01
    z[9,4,3]  R2045     -1.3027971610426903e-02
    z[9,4,3]  R2046     -9.3312285840511322e-02
    z[9,4,3]  R2047     -3.8585272431373596e-01
    z[9,4,3]  R2048     -4.4136798381805420e-01
    z[9,4,3]  R2049     -5.2970415353775024e-01
    z[9,4,3]  R2050     3.6093601584434509e-01
    z[9,4,3]  R2051     -2.8059422969818115e-01
    z[9,4,3]  R2052     -4.1917464137077332e-01
    z[9,4,3]  R2053     -3.8996261358261108e-01
    z[9,4,3]  R2054     4.6877363324165344e-01
    z[9,4,3]  R2055     -8.6615577340126038e-02
    z[9,4,3]  R2056     -2.2012059390544891e-01
    z[9,4,3]  R2057     5.0543542951345444e-02
    z[9,4,3]  R2058     -6.3995105028152466e-01
    z[9,4,3]  R2059     3.0255696177482605e-01
    z[9,4,3]  R2060     -3.9645433425903320e-02
    z[9,4,3]  R2061     0.281955748796463
    z[9,4,3]  R2062     -2.4808716773986816e-01
    z[9,4,3]  R2063     -1.3536064326763153e-01
    z[9,4,4]  R42       1
    z[9,4,4]  R87       -1
    z[9,4,4]  R1988     -1
    z[9,4,4]  R1989     1
    z[9,4,4]  R1994     -8.6017400026321411e-03
    z[9,4,4]  R1995     -1.5056072175502777e-01
    z[9,4,4]  R1996     4.2689535021781921e-01
    z[9,4,4]  R1997     -5.1363629102706909e-01
    z[9,4,4]  R1998     -2.2283342480659485e-01
    z[9,4,4]  R1999     1.4258655905723572e-01
    z[9,4,4]  R2000     1.0501173883676529e-01
    z[9,4,4]  R2001     -6.3213360309600830e-01
    z[9,4,4]  R2002     3.6314094066619873e-01
    z[9,4,4]  R2003     5.1917150616645813e-02
    z[9,4,4]  R2004     -1.1632586270570755e-01
    z[9,4,4]  R2005     2.6178082823753357e-01
    z[9,4,4]  R2006     -1.4302109181880951e-01
    z[9,4,4]  R2007     2.1030455827713013e-03
    z[9,4,4]  R2008     -2.5131186842918396e-01
    z[9,4,4]  R2009     2.9953831434249878e-01
    z[9,4,4]  R2010     3.2541179656982422e-01
    z[9,4,4]  R2011     -3.2191792130470276e-01
    z[9,4,4]  R2012     -2.9407319426536560e-01
    z[9,4,4]  R2013     -1.6345328092575073e-01
    z[9,4,4]  R2014     -3.3638164401054382e-02
    z[9,4,4]  R2015     5.6115162372589111e-01
    z[9,4,4]  R2016     0.313353568315506
    z[9,4,4]  R2017     -1.4223536849021912e-01
    z[9,4,4]  R2018     -1.7988644540309906e-02
    z[9,4,4]  R2019     1.2636347115039825e-01
    z[9,4,4]  R2020     1.0123517364263535e-01
    z[9,4,4]  R2021     1.1130163073539734e-01
    z[9,4,4]  R2022     -9.8336994647979736e-02
    z[9,4,4]  R2023     -1.6293426975607872e-02
    z[9,4,4]  R2024     -5.0889246165752411e-02
    z[9,4,4]  R2025     -1.6214188933372498e-01
    z[9,4,4]  R2026     3.7026622891426086e-01
    z[9,4,4]  R2027     4.5634895563125610e-01
    z[9,4,4]  R2028     -1.3036662340164185e-01
    z[9,4,4]  R2029     6.4262598752975464e-01
    z[9,4,4]  R2030     -2.6475492119789124e-01
    z[9,4,4]  R2031     -0.507340669631958
    z[9,4,4]  R2032     -4.7905972599983215e-01
    z[9,4,4]  R2033     3.6090143024921417e-02
    z[9,4,4]  R2034     3.3842098712921143e-01
    z[9,4,4]  R2035     2.7324205636978149e-01
    z[9,4,4]  R2036     2.7367309667170048e-03
    z[9,4,4]  R2037     -4.4276732951402664e-02
    z[9,4,4]  R2038     -4.8324775695800781e-01
    z[9,4,4]  R2039     5.8567330241203308e-02
    z[9,4,4]  R2040     1.8050818145275116e-01
    z[9,4,4]  R2041     -5.3812479972839355e-01
    z[9,4,4]  R2042     4.4043079018592834e-01
    z[9,4,4]  R2043     -4.7311961650848389e-02
    z[9,4,4]  R2044     -1.9998279213905334e-01
    z[9,4,4]  R2045     0.0872771218419075
    z[9,4,4]  R2046     2.4556741118431091e-01
    z[9,4,4]  R2047     -4.0157355368137360e-02
    z[9,4,4]  R2048     -0.0919187143445015
    z[9,4,4]  R2049     -1.7670853435993195e-01
    z[9,4,4]  R2050     6.5559864044189453e-02
    z[9,4,4]  R2051     0.433892160654068
    z[9,4,4]  R2052     -2.6337581872940063e-01
    z[9,4,4]  R2053     -1.1109060049057007e-01
    z[9,4,4]  R2054     -2.6722019910812378e-01
    z[9,4,4]  R2055     -2.4733142554759979e-01
    z[9,4,4]  R2056     5.0069648772478104e-02
    z[9,4,4]  R2057     2.1795381605625153e-01
    z[9,4,4]  R2058     9.0350754559040070e-02
    z[9,4,4]  R2059     0.386310338973999
    z[9,4,4]  R2060     4.6342912316322327e-01
    z[9,4,4]  R2061     -1.7118453979492188e-01
    z[9,4,4]  R2062     -2.1818645298480988e-01
    z[9,4,4]  R2063     -6.3431066274642944e-01
    z[9,4,5]  R43       1
    z[9,4,5]  R88       -1
    z[9,4,5]  R1990     -1
    z[9,4,5]  R1991     1
    z[9,4,5]  R1994     -1.6714364290237427e-01
    z[9,4,5]  R1995     -1.0922791436314583e-02
    z[9,4,5]  R1996     -0.0778147503733635
    z[9,4,5]  R1997     2.7469709515571594e-01
    z[9,4,5]  R1998     -2.0084667205810547e-01
    z[9,4,5]  R1999     -3.0417975783348083e-01
    z[9,4,5]  R2000     -1.1976343393325806e-01
    z[9,4,5]  R2001     -3.0184416100382805e-02
    z[9,4,5]  R2002     -2.6337811350822449e-01
    z[9,4,5]  R2003     4.4822424650192261e-01
    z[9,4,5]  R2004     1.3516438007354736e-01
    z[9,4,5]  R2005     0.371501088142395
    z[9,4,5]  R2006     4.6095588803291321e-01
    z[9,4,5]  R2007     2.9762476682662964e-01
    z[9,4,5]  R2008     -4.3573114275932312e-01
    z[9,4,5]  R2009     -2.2947339713573456e-01
    z[9,4,5]  R2010     2.8953146934509277e-01
    z[9,4,5]  R2011     1.8770781159400940e-01
    z[9,4,5]  R2012     2.4617239832878113e-02
    z[9,4,5]  R2013     1.5098921954631805e-01
    z[9,4,5]  R2014     -1.7260673642158508e-01
    z[9,4,5]  R2015     -5.2695637941360474e-01
    z[9,4,5]  R2016     -2.2647507488727570e-01
    z[9,4,5]  R2017     -1.3525488972663879e-01
    z[9,4,5]  R2018     3.0662909150123596e-01
    z[9,4,5]  R2019     -1.7903931438922882e-01
    z[9,4,5]  R2020     1.5412282943725586e-01
    z[9,4,5]  R2021     2.3304232954978943e-01
    z[9,4,5]  R2022     3.4626227617263794e-01
    z[9,4,5]  R2023     0.53646320104599
    z[9,4,5]  R2024     5.4527290165424347e-02
    z[9,4,5]  R2025     -2.1007929742336273e-01
    z[9,4,5]  R2026     -2.6475070044398308e-02
    z[9,4,5]  R2027     -0.246475487947464
    z[9,4,5]  R2028     -3.0580822378396988e-02
    z[9,4,5]  R2029     9.2176623642444611e-02
    z[9,4,5]  R2030     1.3062807917594910e-01
    z[9,4,5]  R2031     -1.8804956972599030e-01
    z[9,4,5]  R2032     1.5617184340953827e-01
    z[9,4,5]  R2033     7.7737517654895782e-02
    z[9,4,5]  R2034     3.8307833671569824e-01
    z[9,4,5]  R2035     1.5141792595386505e-01
    z[9,4,5]  R2036     2.1675595641136169e-01
    z[9,4,5]  R2037     5.5689728260040283e-01
    z[9,4,5]  R2038     -1.2681010365486145e-01
    z[9,4,5]  R2039     -1.3120164163410664e-02
    z[9,4,5]  R2040     2.9955340549349785e-02
    z[9,4,5]  R2041     1.4351907372474670e-01
    z[9,4,5]  R2042     -5.1002725958824158e-02
    z[9,4,5]  R2043     4.7414085268974304e-01
    z[9,4,5]  R2044     5.0324422121047974e-01
    z[9,4,5]  R2045     1.5538723766803741e-01
    z[9,4,5]  R2046     3.6747229099273682e-01
    z[9,4,5]  R2047     -2.6824072003364563e-02
    z[9,4,5]  R2048     -2.0342393219470978e-01
    z[9,4,5]  R2049     2.7847746014595032e-01
    z[9,4,5]  R2050     -3.1787642836570740e-01
    z[9,4,5]  R2051     1.2250393629074097e-01
    z[9,4,5]  R2052     -1.2531944550573826e-02
    z[9,4,5]  R2053     9.7767621278762817e-02
    z[9,4,5]  R2054     3.7031225860118866e-02
    z[9,4,5]  R2055     4.6168947219848633e-01
    z[9,4,5]  R2056     2.8578832745552063e-01
    z[9,4,5]  R2057     -8.6044684052467346e-02
    z[9,4,5]  R2058     5.2624985575675964e-02
    z[9,4,5]  R2059     3.3586233854293823e-01
    z[9,4,5]  R2060     2.5605341792106628e-01
    z[9,4,5]  R2061     -2.2904913127422333e-01
    z[9,4,5]  R2062     -5.6428514420986176e-02
    z[9,4,5]  R2063     2.5904285907745361e-01
    z[9,4,6]  R44       1
    z[9,4,6]  R89       -1
    z[9,4,6]  R1992     -1
    z[9,4,6]  R1993     1
    z[9,4,6]  R1994     1.7088238894939423e-01
    z[9,4,6]  R1995     -1.8949435651302338e-01
    z[9,4,6]  R1996     -2.8667521476745605e-01
    z[9,4,6]  R1997     1.6458222270011902e-01
    z[9,4,6]  R1998     2.5363853573799133e-01
    z[9,4,6]  R1999     5.6849747896194458e-01
    z[9,4,6]  R2000     5.9675979614257812e-01
    z[9,4,6]  R2001     1.1810465157032013e-01
    z[9,4,6]  R2002     2.0851017534732819e-01
    z[9,4,6]  R2003     -1.1312078684568405e-01
    z[9,4,6]  R2004     -3.1195651739835739e-02
    z[9,4,6]  R2005     3.2639726996421814e-02
    z[9,4,6]  R2006     -2.2185422480106354e-01
    z[9,4,6]  R2007     2.5383546948432922e-01
    z[9,4,6]  R2008     -1.2012134492397308e-01
    z[9,4,6]  R2009     -7.8967171907424927e-01
    z[9,4,6]  R2010     -5.6475266814231873e-02
    z[9,4,6]  R2011     3.5991939902305603e-01
    z[9,4,6]  R2012     -6.2226498126983643e-01
    z[9,4,6]  R2013     -4.8943912982940674e-01
    z[9,4,6]  R2014     0.560827374458313
    z[9,4,6]  R2015     1.0953530669212341e-02
    z[9,4,6]  R2016     -0.649936318397522
    z[9,4,6]  R2017     -3.0012881755828857e-01
    z[9,4,6]  R2018     1.5112267434597015e-01
    z[9,4,6]  R2019     -5.3595972061157227e-01
    z[9,4,6]  R2020     -2.5471115112304688e-01
    z[9,4,6]  R2021     -2.7870258688926697e-01
    z[9,4,6]  R2022     8.3913028240203857e-02
    z[9,4,6]  R2023     1.0414987057447433e-01
    z[9,4,6]  R2024     -3.4079443663358688e-02
    z[9,4,6]  R2025     -5.0551801919937134e-02
    z[9,4,6]  R2026     -2.4479311704635620e-01
    z[9,4,6]  R2027     2.5216671824455261e-01
    z[9,4,6]  R2028     1.9001729786396027e-01
    z[9,4,6]  R2029     5.7350657880306244e-02
    z[9,4,6]  R2030     -3.0278715491294861e-01
    z[9,4,6]  R2031     3.9923647046089172e-01
    z[9,4,6]  R2032     -3.5043925046920776e-01
    z[9,4,6]  R2033     1.8240106105804443e-01
    z[9,4,6]  R2034     8.2011222839355469e-02
    z[9,4,6]  R2035     -2.6847827434539795e-01
    z[9,4,6]  R2036     1.8181236088275909e-01
    z[9,4,6]  R2037     4.5772776007652283e-01
    z[9,4,6]  R2038     1.3725706934928894e-01
    z[9,4,6]  R2039     3.5917314887046814e-01
    z[9,4,6]  R2040     2.2462695837020874e-02
    z[9,4,6]  R2041     0.09235879778862
    z[9,4,6]  R2042     -1.3914184272289276e-01
    z[9,4,6]  R2043     -2.7535000815987587e-02
    z[9,4,6]  R2044     -2.3029008507728577e-01
    z[9,4,6]  R2045     -1.4045518636703491e-01
    z[9,4,6]  R2046     3.0451181810349226e-03
    z[9,4,6]  R2047     -6.6363111138343811e-02
    z[9,4,6]  R2048     0.449947714805603
    z[9,4,6]  R2049     -4.9536174535751343e-01
    z[9,4,6]  R2050     2.1249692142009735e-01
    z[9,4,6]  R2051     -0.0699910819530487
    z[9,4,6]  R2052     2.4737489223480225e-01
    z[9,4,6]  R2053     1.4469218254089355e-01
    z[9,4,6]  R2054     1.9610424339771271e-01
    z[9,4,6]  R2055     -2.0946766436100006e-01
    z[9,4,6]  R2056     1.7768968641757965e-01
    z[9,4,6]  R2057     9.5873691141605377e-02
    z[9,4,6]  R2058     7.9661142081022263e-03
    z[9,4,6]  R2059     3.7048736214637756e-01
    z[9,4,6]  R2060     -3.5887271165847778e-01
    z[9,4,6]  R2061     -1.2554962933063507e-01
    z[9,4,6]  R2062     -2.5935578346252441e-01
    z[9,4,6]  R2063     -1.7442846298217773e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2118     -1
    z[5,6,0]  R2119     1
    z[5,6,0]  R2132     -7.5358949601650238e-02
    z[5,6,0]  R2133     1.5595360100269318e-01
    z[5,6,0]  R2134     3.7856489419937134e-01
    z[5,6,0]  R2135     4.5991745591163635e-01
    z[5,6,0]  R2136     5.6721532344818115e-01
    z[5,6,0]  R2137     3.8353410363197327e-01
    z[5,6,0]  R2138     7.5176799297332764e-01
    z[5,6,0]  R2139     2.5073993206024170e-01
    z[5,6,0]  R2140     -5.2961182594299316e-01
    z[5,6,0]  R2141     7.2871428728103638e-01
    z[5,6,0]  R2142     -0.573577880859375
    z[5,6,0]  R2143     3.9125624299049377e-01
    z[5,6,0]  R2144     -1.3802585005760193e-01
    z[5,6,0]  R2145     -2.3197303712368011e-01
    z[5,6,0]  R2146     -2.4491387605667114e-01
    z[5,6,0]  R2147     -4.3502193689346313e-01
    z[5,6,0]  R2148     1.7371350526809692e-01
    z[5,6,0]  R2149     -3.4387665987014771e-01
    z[5,6,0]  R2150     -2.6275321841239929e-01
    z[5,6,0]  R2151     -2.6834350824356079e-01
    z[5,6,0]  R2152     -1.1733414977788925e-01
    z[5,6,0]  R2153     0.690343976020813
    z[5,6,0]  R2154     -2.4170331656932831e-02
    z[5,6,0]  R2155     -3.2999888062477112e-01
    z[5,6,0]  R2156     5.5536341667175293e-01
    z[5,6,0]  R2157     -1.2703700363636017e-01
    z[5,6,0]  R2158     -5.0177562236785889e-01
    z[5,6,0]  R2159     6.4959245920181274e-01
    z[5,6,0]  R2160     5.0342237949371338e-01
    z[5,6,0]  R2161     4.5965763926506042e-01
    z[5,6,0]  R2162     -2.5962987542152405e-01
    z[5,6,0]  R2163     6.8999834358692169e-02
    z[5,6,0]  R2164     6.7577803134918213e-01
    z[5,6,0]  R2165     6.9911277294158936e-01
    z[5,6,0]  R2166     -5.1434552669525146e-01
    z[5,6,0]  R2167     2.6208099722862244e-01
    z[5,6,0]  R2168     2.0925863087177277e-01
    z[5,6,0]  R2169     1.6149304807186127e-01
    z[5,6,0]  R2170     2.0031196996569633e-02
    z[5,6,0]  R2171     4.7062397003173828e-01
    z[5,6,0]  R2172     -2.0097967982292175e-01
    z[5,6,0]  R2173     5.3255504369735718e-01
    z[5,6,0]  R2174     -5.3218755871057510e-02
    z[5,6,0]  R2175     -5.1938509941101074e-01
    z[5,6,0]  R2176     7.6573394238948822e-02
    z[5,6,0]  R2177     -6.3433700799942017e-01
    z[5,6,0]  R2178     2.9662674292922020e-02
    z[5,6,0]  R2179     5.4677534103393555e-01
    z[5,6,0]  R2180     1.3562743365764618e-01
    z[5,6,0]  R2181     1.5572011470794678e-01
    z[5,6,0]  R2182     1.1420238018035889e-01
    z[5,6,0]  R2183     2.3889848962426186e-02
    z[5,6,0]  R2184     -1.5095965564250946e-01
    z[5,6,0]  R2185     -3.1263357400894165e-01
    z[5,6,0]  R2186     -2.6962655782699585e-01
    z[5,6,0]  R2187     -2.3602253198623657e-01
    z[5,6,0]  R2188     -2.9074054956436157e-01
    z[5,6,0]  R2189     -3.3436134457588196e-01
    z[5,6,0]  R2190     -1.2169932574033737e-01
    z[5,6,0]  R2191     1.3749545812606812e-01
    z[5,6,0]  R2192     -2.2975397109985352e-01
    z[5,6,0]  R2193     -3.8394263386726379e-01
    z[5,6,0]  R2194     -2.8801003098487854e-01
    z[5,6,0]  R2195     -2.5030487775802612e-01
    z[5,6,0]  R2196     5.4529821872711182e-01
    z[5,6,0]  R2197     3.7663927674293518e-01
    z[5,6,0]  R2198     -2.1984383463859558e-01
    z[5,6,0]  R2199     -6.0424816608428955e-01
    z[5,6,0]  R2200     3.0019545927643776e-02
    z[5,6,0]  R2201     -1.9691903889179230e-01
    z[5,6,0]  R2202     7.2666600346565247e-02
    z[5,6,0]  R2203     -1.9034427404403687e-01
    z[5,6,0]  R2204     1.2171491980552673e-01
    z[5,6,0]  R2205     -0.00383838452398777
    z[5,6,0]  R2206     -0.226633220911026
    z[5,6,0]  R2207     -4.5925104618072510e-01
    z[5,6,0]  R2208     -4.1722607612609863e-01
    z[5,6,0]  R2209     -2.6629993319511414e-01
    z[5,6,0]  R2210     -2.9132384061813354e-01
    z[5,6,0]  R2211     -3.7018135190010071e-01
    z[5,6,0]  R2212     1.9356849789619446e-01
    z[5,6,0]  R2213     -3.1235665082931519e-01
    z[5,6,0]  R2214     3.4809085726737976e-01
    z[5,6,0]  R2215     5.3691053390502930e-01
    z[5,6,0]  R2216     -4.8993730545043945e-01
    z[5,6,0]  R2217     5.6050747632980347e-01
    z[5,6,0]  R2218     -8.0752231180667877e-02
    z[5,6,0]  R2219     -4.3593738228082657e-02
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2120     -1
    z[5,6,1]  R2121     1
    z[5,6,1]  R2132     9.6793889999389648e-02
    z[5,6,1]  R2133     9.5467088976874948e-04
    z[5,6,1]  R2134     4.4080372899770737e-02
    z[5,6,1]  R2135     3.5572454333305359e-02
    z[5,6,1]  R2136     7.6472297310829163e-02
    z[5,6,1]  R2137     -7.3419380933046341e-03
    z[5,6,1]  R2138     5.3024303168058395e-02
    z[5,6,1]  R2139     4.7504503279924393e-02
    z[5,6,1]  R2140     7.1272291243076324e-02
    z[5,6,1]  R2141     5.3780563175678253e-02
    z[5,6,1]  R2142     1.8765892088413239e-01
    z[5,6,1]  R2143     4.5511212944984436e-01
    z[5,6,1]  R2144     4.3033209443092346e-01
    z[5,6,1]  R2145     -7.2222399711608887e-01
    z[5,6,1]  R2146     -8.4902030229568481e-01
    z[5,6,1]  R2147     3.3304911851882935e-01
    z[5,6,1]  R2148     -9.1955929994583130e-01
    z[5,6,1]  R2149     -0.737914502620697
    z[5,6,1]  R2150     -6.8057817220687866e-01
    z[5,6,1]  R2151     8.9732962846755981e-01
    z[5,6,1]  R2152     9.5527225732803345e-01
    z[5,6,1]  R2153     2.4952462315559387e-01
    z[5,6,1]  R2154     5.9687721729278564e-01
    z[5,6,1]  R2155     5.2242338657379150e-01
    z[5,6,1]  R2156     4.3589583039283752e-01
    z[5,6,1]  R2157     5.0764840841293335e-01
    z[5,6,1]  R2158     3.8382586836814880e-01
    z[5,6,1]  R2159     -4.3060076236724854e-01
    z[5,6,1]  R2160     -5.8626502752304077e-01
    z[5,6,1]  R2161     -3.7644475698471069e-01
    z[5,6,1]  R2162     1.6134172910824418e-03
    z[5,6,1]  R2163     6.9854617118835449e-01
    z[5,6,1]  R2164     -3.0914485454559326e-01
    z[5,6,1]  R2165     -5.4646706581115723e-01
    z[5,6,1]  R2166     -5.0603449344635010e-01
    z[5,6,1]  R2167     -0.873330295085907
    z[5,6,1]  R2168     -8.2788646221160889e-01
    z[5,6,1]  R2169     -9.1456514596939087e-01
    z[5,6,1]  R2170     -7.8190410137176514e-01
    z[5,6,1]  R2171     -3.6997714638710022e-01
    z[5,6,1]  R2172     -6.0399180650711060e-01
    z[5,6,1]  R2173     -4.4579467177391052e-01
    z[5,6,1]  R2174     -8.2918137311935425e-01
    z[5,6,1]  R2175     -6.4737731218338013e-01
    z[5,6,1]  R2176     -2.8673955798149109e-01
    z[5,6,1]  R2177     -5.9463238716125488e-01
    z[5,6,1]  R2178     -4.4625002145767212e-01
    z[5,6,1]  R2179     -3.0965870618820190e-01
    z[5,6,1]  R2180     4.0525174140930176e-01
    z[5,6,1]  R2181     2.8946825861930847e-01
    z[5,6,1]  R2182     9.2991006374359131e-01
    z[5,6,1]  R2183     8.6411511898040771e-01
    z[5,6,1]  R2184     8.2175713777542114e-01
    z[5,6,1]  R2185     6.9736850261688232e-01
    z[5,6,1]  R2186     0.808444619178772
    z[5,6,1]  R2187     7.2943145036697388e-01
    z[5,6,1]  R2188     5.6239664554595947e-01
    z[5,6,1]  R2189     6.5161406993865967e-01
    z[5,6,1]  R2190     8.4629094600677490e-01
    z[5,6,1]  R2191     8.7107741832733154e-01
    z[5,6,1]  R2192     9.1347074508666992e-01
    z[5,6,1]  R2193     6.5538221597671509e-01
    z[5,6,1]  R2194     8.3171874284744263e-01
    z[5,6,1]  R2195     3.9090868830680847e-01
    z[5,6,1]  R2196     7.8255093097686768e-01
    z[5,6,1]  R2197     3.5327199101448059e-01
    z[5,6,1]  R2198     3.1925094127655029e-01
    z[5,6,1]  R2199     5.1732963323593140e-01
    z[5,6,1]  R2200     8.7808293104171753e-01
    z[5,6,1]  R2201     6.3551861047744751e-01
    z[5,6,1]  R2202     5.8599531650543213e-01
    z[5,6,1]  R2203     8.0284309387207031e-01
    z[5,6,1]  R2204     7.7548879384994507e-01
    z[5,6,1]  R2205     7.5157040357589722e-01
    z[5,6,1]  R2206     7.3652219772338867e-01
    z[5,6,1]  R2207     7.1352082490921021e-01
    z[5,6,1]  R2208     7.2306710481643677e-01
    z[5,6,1]  R2209     3.7456589937210083e-01
    z[5,6,1]  R2210     6.7980217933654785e-01
    z[5,6,1]  R2211     7.6989412307739258e-01
    z[5,6,1]  R2212     0.847685694694519
    z[5,6,1]  R2213     0.807413637638092
    z[5,6,1]  R2214     3.1038349866867065e-01
    z[5,6,1]  R2215     7.4890291690826416e-01
    z[5,6,1]  R2216     5.3914952278137207e-01
    z[5,6,1]  R2217     1.5823675692081451e-01
    z[5,6,1]  R2218     8.0106192827224731e-01
    z[5,6,1]  R2219     7.4141615629196167e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2122     -1
    z[5,6,2]  R2123     1
    z[5,6,2]  R2132     6.4283972978591919e-01
    z[5,6,2]  R2133     2.3409101366996765e-01
    z[5,6,2]  R2134     2.7970978617668152e-01
    z[5,6,2]  R2135     0.496791809797287
    z[5,6,2]  R2136     5.2066934108734131e-01
    z[5,6,2]  R2137     5.8386647142469883e-03
    z[5,6,2]  R2138     4.2420539259910583e-01
    z[5,6,2]  R2139     4.7645160555839539e-01
    z[5,6,2]  R2140     2.7403315901756287e-01
    z[5,6,2]  R2141     -5.0252193212509155e-01
    z[5,6,2]  R2142     1.7684674263000488e-01
    z[5,6,2]  R2143     -4.3406879901885986e-01
    z[5,6,2]  R2144     -6.0438215732574463e-01
    z[5,6,2]  R2145     -3.4850567579269409e-01
    z[5,6,2]  R2146     -3.3150726556777954e-01
    z[5,6,2]  R2147     -5.6343829631805420e-01
    z[5,6,2]  R2148     -3.9096426218748093e-02
    z[5,6,2]  R2149     2.4002294242382050e-01
    z[5,6,2]  R2150     -0.611361563205719
    z[5,6,2]  R2151     -1.1894062906503677e-01
    z[5,6,2]  R2152     2.6409627869725227e-02
    z[5,6,2]  R2153     6.1987121589481831e-03
    z[5,6,2]  R2154     1.1879008263349533e-01
    z[5,6,2]  R2155     5.3941982984542847e-01
    z[5,6,2]  R2156     -8.7805025279521942e-02
    z[5,6,2]  R2157     6.1530423164367676e-01
    z[5,6,2]  R2158     4.2060518264770508e-01
    z[5,6,2]  R2159     -3.6346417665481567e-01
    z[5,6,2]  R2160     -5.2179563045501709e-01
    z[5,6,2]  R2161     -3.2189390063285828e-01
    z[5,6,2]  R2162     8.4723389148712158e-01
    z[5,6,2]  R2163     2.8638830780982971e-01
    z[5,6,2]  R2164     -6.1005878448486328e-01
    z[5,6,2]  R2165     -2.6746904850006104e-01
    z[5,6,2]  R2166     -0.0676533430814743
    z[5,6,2]  R2167     8.0158248543739319e-02
    z[5,6,2]  R2168     5.9549078345298767e-02
    z[5,6,2]  R2169     1.6035138070583344e-01
    z[5,6,2]  R2170     -1.3319614529609680e-01
    z[5,6,2]  R2171     -3.3799886703491211e-01
    z[5,6,2]  R2172     -2.8119698166847229e-01
    z[5,6,2]  R2173     -6.3282884657382965e-03
    z[5,6,2]  R2174     -4.1510784626007080e-01
    z[5,6,2]  R2175     -2.1796886622905731e-01
    z[5,6,2]  R2176     -3.6379560828208923e-02
    z[5,6,2]  R2177     3.6675009876489639e-02
    z[5,6,2]  R2178     -1.8968142569065094e-01
    z[5,6,2]  R2179     -1.4247059822082520e-01
    z[5,6,2]  R2180     -1.2563848495483398e-01
    z[5,6,2]  R2181     -9.7060143947601318e-02
    z[5,6,2]  R2182     -2.1673109382390976e-02
    z[5,6,2]  R2183     -4.1682547330856323e-01
    z[5,6,2]  R2184     -1.6679960489273071e-01
    z[5,6,2]  R2185     -0.431225061416626
    z[5,6,2]  R2186     0.111131452023983
    z[5,6,2]  R2187     -4.5923840999603271e-01
    z[5,6,2]  R2188     -7.5315505266189575e-01
    z[5,6,2]  R2189     -5.0678777694702148e-01
    z[5,6,2]  R2190     -2.5695204734802246e-01
    z[5,6,2]  R2191     -2.2990810871124268e-01
    z[5,6,2]  R2192     -9.1658405959606171e-02
    z[5,6,2]  R2193     5.6675948202610016e-02
    z[5,6,2]  R2194     -5.0259608775377274e-02
    z[5,6,2]  R2195     1.0611893236637115e-01
    z[5,6,2]  R2196     1.9353662431240082e-01
    z[5,6,2]  R2197     1.5623576939105988e-01
    z[5,6,2]  R2198     7.5560994446277618e-04
    z[5,6,2]  R2199     3.2969883084297180e-01
    z[5,6,2]  R2200     -4.0979039669036865e-01
    z[5,6,2]  R2201     2.3030509054660797e-01
    z[5,6,2]  R2202     4.4043174386024475e-01
    z[5,6,2]  R2203     -2.1861056983470917e-01
    z[5,6,2]  R2204     -3.9543649554252625e-01
    z[5,6,2]  R2205     -4.8836305737495422e-01
    z[5,6,2]  R2206     -1.5879217535257339e-03
    z[5,6,2]  R2207     -2.4725767970085144e-01
    z[5,6,2]  R2208     -1.1703561991453171e-01
    z[5,6,2]  R2209     0.0369969867169857
    z[5,6,2]  R2210     -3.4943285584449768e-01
    z[5,6,2]  R2211     -2.9353508353233337e-01
    z[5,6,2]  R2212     -7.9275742173194885e-03
    z[5,6,2]  R2213     -2.2706474363803864e-01
    z[5,6,2]  R2214     1.2162059545516968e-01
    z[5,6,2]  R2215     1.8791253864765167e-01
    z[5,6,2]  R2216     3.1081789731979370e-01
    z[5,6,2]  R2217     -1.5064038336277008e-01
    z[5,6,2]  R2218     4.1153150796890259e-01
    z[5,6,2]  R2219     1.6199788451194763e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2124     -1
    z[5,6,3]  R2125     1
    z[5,6,3]  R2132     -1.2030338868498802e-02
    z[5,6,3]  R2133     7.1206682920455933e-01
    z[5,6,3]  R2134     4.6227118372917175e-01
    z[5,6,3]  R2135     1.7022161185741425e-01
    z[5,6,3]  R2136     -3.9080867171287537e-01
    z[5,6,3]  R2137     8.0488091707229614e-01
    z[5,6,3]  R2138     -2.2143563628196716e-01
    z[5,6,3]  R2139     -3.1327739357948303e-01
    z[5,6,3]  R2140     -1.8965117633342743e-01
    z[5,6,3]  R2141     -3.6215326189994812e-01
    z[5,6,3]  R2142     -2.9161635041236877e-01
    z[5,6,3]  R2143     -1.8511785566806793e-01
    z[5,6,3]  R2144     -1.4170631766319275e-01
    z[5,6,3]  R2145     -3.8046240806579590e-01
    z[5,6,3]  R2146     -5.8095515705645084e-03
    z[5,6,3]  R2147     -8.5485443472862244e-02
    z[5,6,3]  R2148     -2.1694874763488770e-01
    z[5,6,3]  R2149     -9.1061845421791077e-02
    z[5,6,3]  R2150     -1.4058266580104828e-01
    z[5,6,3]  R2151     2.7991944551467896e-01
    z[5,6,3]  R2152     6.6506855189800262e-02
    z[5,6,3]  R2153     4.5748311281204224e-01
    z[5,6,3]  R2154     3.5309907793998718e-01
    z[5,6,3]  R2155     6.7494444549083710e-02
    z[5,6,3]  R2156     4.4161457568407059e-02
    z[5,6,3]  R2157     4.5583176612854004e-01
    z[5,6,3]  R2158     4.5203980803489685e-01
    z[5,6,3]  R2159     -1.9308102130889893e-01
    z[5,6,3]  R2160     -1.1954199522733688e-01
    z[5,6,3]  R2161     -3.7935337424278259e-01
    z[5,6,3]  R2162     3.4658986330032349e-01
    z[5,6,3]  R2163     5.6162470579147339e-01
    z[5,6,3]  R2164     -1.8775951862335205e-01
    z[5,6,3]  R2165     -1.1313343793153763e-01
    z[5,6,3]  R2166     2.4873189628124237e-02
    z[5,6,3]  R2167     0.0875496044754982
    z[5,6,3]  R2168     -1.2553407251834869e-01
    z[5,6,3]  R2169     -1.7480676993727684e-02
    z[5,6,3]  R2170     2.4851515889167786e-01
    z[5,6,3]  R2171     4.2799273133277893e-01
    z[5,6,3]  R2172     1.8995456397533417e-01
    z[5,6,3]  R2173     0.647131085395813
    z[5,6,3]  R2174     -3.3350121229887009e-02
    z[5,6,3]  R2175     -1.3669732958078384e-02
    z[5,6,3]  R2176     8.5663646459579468e-01
    z[5,6,3]  R2177     -2.4247553944587708e-01
    z[5,6,3]  R2178     1.1043892055749893e-01
    z[5,6,3]  R2179     4.7907626628875732e-01
    z[5,6,3]  R2180     -1.8333104252815247e-01
    z[5,6,3]  R2181     -5.6412893533706665e-01
    z[5,6,3]  R2182     1.4555303752422333e-01
    z[5,6,3]  R2183     1.7127810278907418e-03
    z[5,6,3]  R2184     -2.4269069731235504e-01
    z[5,6,3]  R2185     1.1815001815557480e-01
    z[5,6,3]  R2186     2.1872974932193756e-01
    z[5,6,3]  R2187     -2.4208946526050568e-01
    z[5,6,3]  R2188     1.3070549070835114e-01
    z[5,6,3]  R2189     3.3484759926795959e-01
    z[5,6,3]  R2190     3.0880925059318542e-01
    z[5,6,3]  R2191     6.7955709993839264e-02
    z[5,6,3]  R2192     -1.2718668580055237e-01
    z[5,6,3]  R2193     3.0917921662330627e-01
    z[5,6,3]  R2194     2.5221493840217590e-01
    z[5,6,3]  R2195     -7.5860089063644409e-01
    z[5,6,3]  R2196     -0.0707196369767189
    z[5,6,3]  R2197     -4.6028646826744080e-01
    z[5,6,3]  R2198     -7.2013401985168457e-01
    z[5,6,3]  R2199     -3.5336297750473022e-01
    z[5,6,3]  R2200     1.3543894886970520e-01
    z[5,6,3]  R2201     -3.0731633305549622e-01
    z[5,6,3]  R2202     2.5043663382530212e-01
    z[5,6,3]  R2203     1.9921740889549255e-01
    z[5,6,3]  R2204     -2.3116227984428406e-01
    z[5,6,3]  R2205     -2.2955887019634247e-01
    z[5,6,3]  R2206     -1.5074518509209156e-02
    z[5,6,3]  R2207     0.347474604845047
    z[5,6,3]  R2208     2.0738035440444946e-01
    z[5,6,3]  R2209     -0.728060245513916
    z[5,6,3]  R2210     2.4625155329704285e-01
    z[5,6,3]  R2211     2.9551351070404053e-01
    z[5,6,3]  R2212     0.180172398686409
    z[5,6,3]  R2213     -6.9118700921535492e-02
    z[5,6,3]  R2214     -4.9093249440193176e-01
    z[5,6,3]  R2215     8.9788466691970825e-02
    z[5,6,3]  R2216     -0.504069983959198
    z[5,6,3]  R2217     -5.8053833246231079e-01
    z[5,6,3]  R2218     5.4022260010242462e-02
    z[5,6,3]  R2219     7.7676810324192047e-02
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2126     -1
    z[5,6,4]  R2127     1
    z[5,6,4]  R2132     -3.5819873213768005e-01
    z[5,6,4]  R2133     8.4051378071308136e-02
    z[5,6,4]  R2134     8.7837286293506622e-02
    z[5,6,4]  R2135     -3.6483651399612427e-01
    z[5,6,4]  R2136     2.0078261196613312e-01
    z[5,6,4]  R2137     1.9267193973064423e-01
    z[5,6,4]  R2138     1.1413767933845520e-01
    z[5,6,4]  R2139     -3.7626230716705322e-01
    z[5,6,4]  R2140     -9.2131003737449646e-02
    z[5,6,4]  R2141     -2.5089371204376221e-01
    z[5,6,4]  R2142     5.0921601057052612e-01
    z[5,6,4]  R2143     -5.7260245084762573e-01
    z[5,6,4]  R2144     5.1801240444183350e-01
    z[5,6,4]  R2145     -1.7598392069339752e-01
    z[5,6,4]  R2146     -2.3380665481090546e-01
    z[5,6,4]  R2147     4.7376893460750580e-02
    z[5,6,4]  R2148     2.6536622643470764e-01
    z[5,6,4]  R2149     2.1654200553894043e-01
    z[5,6,4]  R2150     2.4909342825412750e-01
    z[5,6,4]  R2151     -0.0775151476264
    z[5,6,4]  R2152     2.5572302937507629e-01
    z[5,6,4]  R2153     -4.9793016910552979e-01
    z[5,6,4]  R2154     -4.9561339616775513e-01
    z[5,6,4]  R2155     -5.1052731275558472e-01
    z[5,6,4]  R2156     -4.8252606391906738e-01
    z[5,6,4]  R2157     -2.0163437724113464e-01
    z[5,6,4]  R2158     -2.0760956406593323e-01
    z[5,6,4]  R2159     5.1144324243068695e-02
    z[5,6,4]  R2160     2.9054602980613708e-01
    z[5,6,4]  R2161     3.7746012210845947e-01
    z[5,6,4]  R2162     -8.3451956510543823e-02
    z[5,6,4]  R2163     -3.3074009418487549e-01
    z[5,6,4]  R2164     1.0776181519031525e-01
    z[5,6,4]  R2165     -1.6035382449626923e-01
    z[5,6,4]  R2166     0.302490234375
    z[5,6,4]  R2167     3.8686412572860718e-01
    z[5,6,4]  R2168     -1.8753142654895782e-01
    z[5,6,4]  R2169     -7.1950078010559082e-02
    z[5,6,4]  R2170     -3.6935889720916748e-01
    z[5,6,4]  R2171     -4.3102037906646729e-01
    z[5,6,4]  R2172     -0.0522281676530838
    z[5,6,4]  R2173     1.3389755785465240e-01
    z[5,6,4]  R2174     3.5002410411834717e-01
    z[5,6,4]  R2175     -3.5380309820175171e-01
    z[5,6,4]  R2176     2.3240806162357330e-01
    z[5,6,4]  R2177     1.6689166426658630e-01
    z[5,6,4]  R2178     -7.7786058187484741e-01
    z[5,6,4]  R2179     1.5104007720947266e-01
    z[5,6,4]  R2180     2.6192682981491089e-01
    z[5,6,4]  R2181     1.8555636703968048e-01
    z[5,6,4]  R2182     -1.4745970070362091e-01
    z[5,6,4]  R2183     -2.2623822093009949e-01
    z[5,6,4]  R2184     -3.6451452970504761e-01
    z[5,6,4]  R2185     -1.0220992378890514e-02
    z[5,6,4]  R2186     -4.1237783432006836e-01
    z[5,6,4]  R2187     -2.7822852134704590e-01
    z[5,6,4]  R2188     -0.0856996551156044
    z[5,6,4]  R2189     3.4416213631629944e-02
    z[5,6,4]  R2190     -1.8395955860614777e-01
    z[5,6,4]  R2191     -1.9225528836250305e-01
    z[5,6,4]  R2192     -2.4892230331897736e-01
    z[5,6,4]  R2193     -3.6046814918518066e-01
    z[5,6,4]  R2194     -2.4335388839244843e-01
    z[5,6,4]  R2195     -7.2335690259933472e-02
    z[5,6,4]  R2196     1.1693262308835983e-01
    z[5,6,4]  R2197     -3.5507228970527649e-01
    z[5,6,4]  R2198     2.4996544420719147e-01
    z[5,6,4]  R2199     -4.8424351960420609e-02
    z[5,6,4]  R2200     -1.8865896761417389e-01
    z[5,6,4]  R2201     -3.0305463075637817e-01
    z[5,6,4]  R2202     -3.8017854094505310e-01
    z[5,6,4]  R2203     -4.1649696230888367e-01
    z[5,6,4]  R2204     -3.3740437030792236e-01
    z[5,6,4]  R2205     -2.9558593034744263e-01
    z[5,6,4]  R2206     -4.2544689774513245e-01
    z[5,6,4]  R2207     -1.5303482115268707e-01
    z[5,6,4]  R2208     -1.2073575705289841e-01
    z[5,6,4]  R2209     2.4712586402893066e-01
    z[5,6,4]  R2210     -2.2771361470222473e-01
    z[5,6,4]  R2211     -1.0204493999481201e-01
    z[5,6,4]  R2212     -4.4191029667854309e-01
    z[5,6,4]  R2213     -2.8548830747604370e-01
    z[5,6,4]  R2214     -4.4406521320343018e-01
    z[5,6,4]  R2215     2.1089971065521240e-01
    z[5,6,4]  R2216     -2.5434973835945129e-01
    z[5,6,4]  R2217     2.2958418726921082e-01
    z[5,6,4]  R2218     3.7069392204284668e-01
    z[5,6,4]  R2219     6.0400164127349854e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2128     -1
    z[5,6,5]  R2129     1
    z[5,6,5]  R2132     -1.2088346481323242e-01
    z[5,6,5]  R2133     -6.2800031900405884e-01
    z[5,6,5]  R2134     -4.0164360404014587e-01
    z[5,6,5]  R2135     -5.4557675123214722e-01
    z[5,6,5]  R2136     -4.5615857839584351e-01
    z[5,6,5]  R2137     1.0082848370075226e-01
    z[5,6,5]  R2138     1.4392022788524628e-01
    z[5,6,5]  R2139     2.1801939606666565e-01
    z[5,6,5]  R2140     -6.6552406549453735e-01
    z[5,6,5]  R2141     -7.8395850956439972e-02
    z[5,6,5]  R2142     5.0746500492095947e-01
    z[5,6,5]  R2143     -2.4189466238021851e-01
    z[5,6,5]  R2144     -2.1659222245216370e-01
    z[5,6,5]  R2145     -7.7802293002605438e-02
    z[5,6,5]  R2146     -1.5291871130466461e-01
    z[5,6,5]  R2147     -2.2871309518814087e-01
    z[5,6,5]  R2148     -7.2227261960506439e-02
    z[5,6,5]  R2149     8.4162920713424683e-02
    z[5,6,5]  R2150     -7.6263256371021271e-02
    z[5,6,5]  R2151     2.2961314767599106e-02
    z[5,6,5]  R2152     2.7249900624155998e-02
    z[5,6,5]  R2153     6.1988379806280136e-02
    z[5,6,5]  R2154     2.1062639355659485e-01
    z[5,6,5]  R2155     -1.4936427772045135e-01
    z[5,6,5]  R2156     5.0663727521896362e-01
    z[5,6,5]  R2157     3.1477779150009155e-01
    z[5,6,5]  R2158     -1.0706861317157745e-01
    z[5,6,5]  R2159     4.5557871460914612e-01
    z[5,6,5]  R2160     -1.5782682597637177e-01
    z[5,6,5]  R2161     2.0386941730976105e-01
    z[5,6,5]  R2162     2.9360356926918030e-01
    z[5,6,5]  R2163     1.3964110985398293e-02
    z[5,6,5]  R2164     1.6813308000564575e-01
    z[5,6,5]  R2165     2.7296161651611328e-01
    z[5,6,5]  R2166     -4.2952352762222290e-01
    z[5,6,5]  R2167     -0.0528470054268837
    z[5,6,5]  R2168     -4.6429717540740967e-01
    z[5,6,5]  R2169     -3.0102476477622986e-01
    z[5,6,5]  R2170     -1.3205623626708984e-01
    z[5,6,5]  R2171     2.3775672540068626e-02
    z[5,6,5]  R2172     -2.3560172319412231e-01
    z[5,6,5]  R2173     -2.4947191774845123e-01
    z[5,6,5]  R2174     -2.1468194201588631e-02
    z[5,6,5]  R2175     -3.0987852811813354e-01
    z[5,6,5]  R2176     1.9926816225051880e-01
    z[5,6,5]  R2177     2.4895383417606354e-01
    z[5,6,5]  R2178     -2.3796521127223969e-01
    z[5,6,5]  R2179     1.6448259353637695e-01
    z[5,6,5]  R2180     -8.3478963375091553e-01
    z[5,6,5]  R2181     -5.4874008893966675e-01
    z[5,6,5]  R2182     -2.7937579154968262e-01
    z[5,6,5]  R2183     1.6618889570236206e-01
    z[5,6,5]  R2184     -2.8234788775444031e-01
    z[5,6,5]  R2185     -3.3864060044288635e-01
    z[5,6,5]  R2186     -1.9196757674217224e-01
    z[5,6,5]  R2187     -2.1979844197630882e-02
    z[5,6,5]  R2188     -8.6034417152404785e-02
    z[5,6,5]  R2189     -6.9077193737030029e-02
    z[5,6,5]  R2190     -4.2867638170719147e-02
    z[5,6,5]  R2191     -0.271806925535202
    z[5,6,5]  R2192     -8.6144261062145233e-02
    z[5,6,5]  R2193     -3.9314371347427368e-01
    z[5,6,5]  R2194     1.2027243524789810e-01
    z[5,6,5]  R2195     7.5420483946800232e-02
    z[5,6,5]  R2196     1.8396285176277161e-01
    z[5,6,5]  R2197     4.9101737141609192e-01
    z[5,6,5]  R2198     -8.1900522112846375e-02
    z[5,6,5]  R2199     -1.1446280032396317e-01
    z[5,6,5]  R2200     7.4930049479007721e-02
    z[5,6,5]  R2201     -0.532384991645813
    z[5,6,5]  R2202     4.9820342659950256e-01
    z[5,6,5]  R2203     0.0839017704129219
    z[5,6,5]  R2204     -1.7509314417839050e-01
    z[5,6,5]  R2205     -2.3635946214199066e-01
    z[5,6,5]  R2206     -4.0245339274406433e-01
    z[5,6,5]  R2207     -1.5049065649509430e-01
    z[5,6,5]  R2208     -4.7530877590179443e-01
    z[5,6,5]  R2209     -1.7866681516170502e-01
    z[5,6,5]  R2210     -4.0760576725006104e-01
    z[5,6,5]  R2211     -2.7285388112068176e-01
    z[5,6,5]  R2212     -9.9871069192886353e-02
    z[5,6,5]  R2213     -2.8446984291076660e-01
    z[5,6,5]  R2214     5.5914241075515747e-01
    z[5,6,5]  R2215     2.0898316800594330e-01
    z[5,6,5]  R2216     -8.0084212124347687e-02
    z[5,6,5]  R2217     4.5964911580085754e-01
    z[5,6,5]  R2218     1.5262268483638763e-01
    z[5,6,5]  R2219     1.8325030803680420e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2130     -1
    z[5,6,6]  R2131     1
    z[5,6,6]  R2132     0.654710054397583
    z[5,6,6]  R2133     1.1131328344345093e-01
    z[5,6,6]  R2134     -6.2751924991607666e-01
    z[5,6,6]  R2135     -2.8403052687644958e-01
    z[5,6,6]  R2136     -1.4015206135809422e-02
    z[5,6,6]  R2137     3.9710375666618347e-01
    z[5,6,6]  R2138     -4.1147151589393616e-01
    z[5,6,6]  R2139     -0.648550808429718
    z[5,6,6]  R2140     -3.8981980085372925e-01
    z[5,6,6]  R2141     1.1535238474607468e-01
    z[5,6,6]  R2142     5.1537081599235535e-02
    z[5,6,6]  R2143     -1.7527288198471069e-01
    z[5,6,6]  R2144     -0.308473140001297
    z[5,6,6]  R2145     3.4835276007652283e-01
    z[5,6,6]  R2146     1.7663891613483429e-01
    z[5,6,6]  R2147     0.566135585308075
    z[5,6,6]  R2148     1.7517418600618839e-03
    z[5,6,6]  R2149     4.6621233224868774e-01
    z[5,6,6]  R2150     -7.9900383949279785e-02
    z[5,6,6]  R2151     1.5412263572216034e-01
    z[5,6,6]  R2152     -4.9296006560325623e-02
    z[5,6,6]  R2153     7.5118844397366047e-03
    z[5,6,6]  R2154     4.6299794316291809e-01
    z[5,6,6]  R2155     -1.9924205541610718e-01
    z[5,6,6]  R2156     4.8924211412668228e-02
    z[5,6,6]  R2157     5.5955359712243080e-03
    z[5,6,6]  R2158     4.0630626678466797e-01
    z[5,6,6]  R2159     1.1427410691976547e-01
    z[5,6,6]  R2160     -8.3497636020183563e-02
    z[5,6,6]  R2161     4.6415582299232483e-01
    z[5,6,6]  R2162     3.8634572178125381e-02
    z[5,6,6]  R2163     -1.5741581097245216e-02
    z[5,6,6]  R2164     -2.1139627322554588e-02
    z[5,6,6]  R2165     1.6749539971351624e-01
    z[5,6,6]  R2166     4.4518679380416870e-01
    z[5,6,6]  R2167     -4.5397195965051651e-02
    z[5,6,6]  R2168     -2.7749935165047646e-02
    z[5,6,6]  R2169     1.2521874904632568e-01
    z[5,6,6]  R2170     -3.9352121949195862e-01
    z[5,6,6]  R2171     0.397322416305542
    z[5,6,6]  R2172     6.4916145801544189e-01
    z[5,6,6]  R2173     1.3663363456726074e-01
    z[5,6,6]  R2174     1.1498459428548813e-01
    z[5,6,6]  R2175     2.0553120970726013e-01
    z[5,6,6]  R2176     2.8817737102508545e-01
    z[5,6,6]  R2177     -3.0668967962265015e-01
    z[5,6,6]  R2178     -0.300184428691864
    z[5,6,6]  R2179     -5.5269223451614380e-01
    z[5,6,6]  R2180     5.0016533583402634e-02
    z[5,6,6]  R2181     -4.7827857732772827e-01
    z[5,6,6]  R2182     -2.7828231453895569e-02
    z[5,6,6]  R2183     1.3620495796203613e-02
    z[5,6,6]  R2184     5.1132321357727051e-02
    z[5,6,6]  R2185     3.1818398833274841e-01
    z[5,6,6]  R2186     -8.1356592476367950e-02
    z[5,6,6]  R2187     2.5460091233253479e-01
    z[5,6,6]  R2188     -1.0346055030822754e-02
    z[5,6,6]  R2189     -2.9780656099319458e-01
    z[5,6,6]  R2190     2.6816916465759277e-01
    z[5,6,6]  R2191     -2.3238374292850494e-01
    z[5,6,6]  R2192     -1.3719917833805084e-01
    z[5,6,6]  R2193     1.9939646124839783e-01
    z[5,6,6]  R2194     -2.9235085844993591e-01
    z[5,6,6]  R2195     4.3229696154594421e-01
    z[5,6,6]  R2196     1.7052348703145981e-02
    z[5,6,6]  R2197     -3.6040824651718140e-01
    z[5,6,6]  R2198     5.1182365417480469e-01
    z[5,6,6]  R2199     0.343861848115921
    z[5,6,6]  R2200     -0.0243021659553051
    z[5,6,6]  R2201     -1.8595525622367859e-01
    z[5,6,6]  R2202     -4.3452523648738861e-02
    z[5,6,6]  R2203     -2.2632901370525360e-01
    z[5,6,6]  R2204     1.7174807190895081e-01
    z[5,6,6]  R2205     0.0263583455234766
    z[5,6,6]  R2206     2.5093618035316467e-01
    z[5,6,6]  R2207     -2.2811074554920197e-01
    z[5,6,6]  R2208     -7.6790824532508850e-02
    z[5,6,6]  R2209     4.0540233254432678e-01
    z[5,6,6]  R2210     2.2860527038574219e-01
    z[5,6,6]  R2211     -1.0897362232208252e-01
    z[5,6,6]  R2212     -7.8589171171188354e-02
    z[5,6,6]  R2213     -1.7819654941558838e-01
    z[5,6,6]  R2214     -1.2982444465160370e-01
    z[5,6,6]  R2215     1.3908928632736206e-01
    z[5,6,6]  R2216     2.1789376437664032e-01
    z[5,6,6]  R2217     1.9258503615856171e-01
    z[5,6,6]  R2218     1.3709321618080139e-01
    z[5,6,6]  R2219     -1.3313873112201691e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2220     -1
    z[6,5,0]  R2221     1
    z[6,5,0]  R2234     2.0031196996569633e-02
    z[6,5,0]  R2235     4.7062397003173828e-01
    z[6,5,0]  R2236     -2.0097967982292175e-01
    z[6,5,0]  R2237     5.3255504369735718e-01
    z[6,5,0]  R2238     -5.3218755871057510e-02
    z[6,5,0]  R2239     -5.1938509941101074e-01
    z[6,5,0]  R2240     7.6573394238948822e-02
    z[6,5,0]  R2241     -6.3433700799942017e-01
    z[6,5,0]  R2242     2.9662674292922020e-02
    z[6,5,0]  R2243     5.4677534103393555e-01
    z[6,5,0]  R2244     1.3562743365764618e-01
    z[6,5,0]  R2245     1.5572011470794678e-01
    z[6,5,0]  R2246     1.1420238018035889e-01
    z[6,5,0]  R2247     2.3889848962426186e-02
    z[6,5,0]  R2248     -1.5095965564250946e-01
    z[6,5,0]  R2249     -3.1263357400894165e-01
    z[6,5,0]  R2250     -2.6962655782699585e-01
    z[6,5,0]  R2251     -2.3602253198623657e-01
    z[6,5,0]  R2252     -2.9074054956436157e-01
    z[6,5,0]  R2253     -3.3436134457588196e-01
    z[6,5,0]  R2254     -1.2169932574033737e-01
    z[6,5,0]  R2255     1.3749545812606812e-01
    z[6,5,0]  R2256     -2.2975397109985352e-01
    z[6,5,0]  R2257     -3.8394263386726379e-01
    z[6,5,0]  R2258     -2.8801003098487854e-01
    z[6,5,0]  R2259     -2.5030487775802612e-01
    z[6,5,0]  R2260     5.4529821872711182e-01
    z[6,5,0]  R2261     3.7663927674293518e-01
    z[6,5,0]  R2262     -2.1984383463859558e-01
    z[6,5,0]  R2263     -6.0424816608428955e-01
    z[6,5,0]  R2264     3.0019545927643776e-02
    z[6,5,0]  R2265     -1.9691903889179230e-01
    z[6,5,0]  R2266     7.2666600346565247e-02
    z[6,5,0]  R2267     -1.9034427404403687e-01
    z[6,5,0]  R2268     1.2171491980552673e-01
    z[6,5,0]  R2269     -0.00383838452398777
    z[6,5,0]  R2270     -0.226633220911026
    z[6,5,0]  R2271     -4.5925104618072510e-01
    z[6,5,0]  R2272     -4.1722607612609863e-01
    z[6,5,0]  R2273     -2.6629993319511414e-01
    z[6,5,0]  R2274     -2.9132384061813354e-01
    z[6,5,0]  R2275     -3.7018135190010071e-01
    z[6,5,0]  R2276     1.9356849789619446e-01
    z[6,5,0]  R2277     -3.1235665082931519e-01
    z[6,5,0]  R2278     3.4809085726737976e-01
    z[6,5,0]  R2279     5.3691053390502930e-01
    z[6,5,0]  R2280     -4.8993730545043945e-01
    z[6,5,0]  R2281     5.6050747632980347e-01
    z[6,5,0]  R2282     -8.0752231180667877e-02
    z[6,5,0]  R2283     -4.3593738228082657e-02
    z[6,5,0]  R2284     -7.5358949601650238e-02
    z[6,5,0]  R2285     1.5595360100269318e-01
    z[6,5,0]  R2286     3.7856489419937134e-01
    z[6,5,0]  R2287     4.5991745591163635e-01
    z[6,5,0]  R2288     5.6721532344818115e-01
    z[6,5,0]  R2289     3.8353410363197327e-01
    z[6,5,0]  R2290     7.5176799297332764e-01
    z[6,5,0]  R2291     2.5073993206024170e-01
    z[6,5,0]  R2292     -5.2961182594299316e-01
    z[6,5,0]  R2293     7.2871428728103638e-01
    z[6,5,0]  R2294     -0.573577880859375
    z[6,5,0]  R2295     3.9125624299049377e-01
    z[6,5,0]  R2296     -1.3802585005760193e-01
    z[6,5,0]  R2297     -2.3197303712368011e-01
    z[6,5,0]  R2298     -2.4491387605667114e-01
    z[6,5,0]  R2299     -4.3502193689346313e-01
    z[6,5,0]  R2300     1.7371350526809692e-01
    z[6,5,0]  R2301     -3.4387665987014771e-01
    z[6,5,0]  R2302     -2.6275321841239929e-01
    z[6,5,0]  R2303     -2.6834350824356079e-01
    z[6,5,0]  R2304     -1.1733414977788925e-01
    z[6,5,0]  R2305     0.690343976020813
    z[6,5,0]  R2306     -2.4170331656932831e-02
    z[6,5,0]  R2307     -3.2999888062477112e-01
    z[6,5,0]  R2308     5.5536341667175293e-01
    z[6,5,0]  R2309     -1.2703700363636017e-01
    z[6,5,0]  R2310     -5.0177562236785889e-01
    z[6,5,0]  R2311     6.4959245920181274e-01
    z[6,5,0]  R2312     5.0342237949371338e-01
    z[6,5,0]  R2313     4.5965763926506042e-01
    z[6,5,0]  R2314     -2.5962987542152405e-01
    z[6,5,0]  R2315     6.8999834358692169e-02
    z[6,5,0]  R2316     6.7577803134918213e-01
    z[6,5,0]  R2317     6.9911277294158936e-01
    z[6,5,0]  R2318     -5.1434552669525146e-01
    z[6,5,0]  R2319     2.6208099722862244e-01
    z[6,5,0]  R2320     2.0925863087177277e-01
    z[6,5,0]  R2321     1.6149304807186127e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2222     -1
    z[6,5,1]  R2223     1
    z[6,5,1]  R2234     -7.8190410137176514e-01
    z[6,5,1]  R2235     -3.6997714638710022e-01
    z[6,5,1]  R2236     -6.0399180650711060e-01
    z[6,5,1]  R2237     -4.4579467177391052e-01
    z[6,5,1]  R2238     -8.2918137311935425e-01
    z[6,5,1]  R2239     -6.4737731218338013e-01
    z[6,5,1]  R2240     -2.8673955798149109e-01
    z[6,5,1]  R2241     -5.9463238716125488e-01
    z[6,5,1]  R2242     -4.4625002145767212e-01
    z[6,5,1]  R2243     -3.0965870618820190e-01
    z[6,5,1]  R2244     4.0525174140930176e-01
    z[6,5,1]  R2245     2.8946825861930847e-01
    z[6,5,1]  R2246     9.2991006374359131e-01
    z[6,5,1]  R2247     8.6411511898040771e-01
    z[6,5,1]  R2248     8.2175713777542114e-01
    z[6,5,1]  R2249     6.9736850261688232e-01
    z[6,5,1]  R2250     0.808444619178772
    z[6,5,1]  R2251     7.2943145036697388e-01
    z[6,5,1]  R2252     5.6239664554595947e-01
    z[6,5,1]  R2253     6.5161406993865967e-01
    z[6,5,1]  R2254     8.4629094600677490e-01
    z[6,5,1]  R2255     8.7107741832733154e-01
    z[6,5,1]  R2256     9.1347074508666992e-01
    z[6,5,1]  R2257     6.5538221597671509e-01
    z[6,5,1]  R2258     8.3171874284744263e-01
    z[6,5,1]  R2259     3.9090868830680847e-01
    z[6,5,1]  R2260     7.8255093097686768e-01
    z[6,5,1]  R2261     3.5327199101448059e-01
    z[6,5,1]  R2262     3.1925094127655029e-01
    z[6,5,1]  R2263     5.1732963323593140e-01
    z[6,5,1]  R2264     8.7808293104171753e-01
    z[6,5,1]  R2265     6.3551861047744751e-01
    z[6,5,1]  R2266     5.8599531650543213e-01
    z[6,5,1]  R2267     8.0284309387207031e-01
    z[6,5,1]  R2268     7.7548879384994507e-01
    z[6,5,1]  R2269     7.5157040357589722e-01
    z[6,5,1]  R2270     7.3652219772338867e-01
    z[6,5,1]  R2271     7.1352082490921021e-01
    z[6,5,1]  R2272     7.2306710481643677e-01
    z[6,5,1]  R2273     3.7456589937210083e-01
    z[6,5,1]  R2274     6.7980217933654785e-01
    z[6,5,1]  R2275     7.6989412307739258e-01
    z[6,5,1]  R2276     0.847685694694519
    z[6,5,1]  R2277     0.807413637638092
    z[6,5,1]  R2278     3.1038349866867065e-01
    z[6,5,1]  R2279     7.4890291690826416e-01
    z[6,5,1]  R2280     5.3914952278137207e-01
    z[6,5,1]  R2281     1.5823675692081451e-01
    z[6,5,1]  R2282     8.0106192827224731e-01
    z[6,5,1]  R2283     7.4141615629196167e-01
    z[6,5,1]  R2284     9.6793889999389648e-02
    z[6,5,1]  R2285     9.5467088976874948e-04
    z[6,5,1]  R2286     4.4080372899770737e-02
    z[6,5,1]  R2287     3.5572454333305359e-02
    z[6,5,1]  R2288     7.6472297310829163e-02
    z[6,5,1]  R2289     -7.3419380933046341e-03
    z[6,5,1]  R2290     5.3024303168058395e-02
    z[6,5,1]  R2291     4.7504503279924393e-02
    z[6,5,1]  R2292     7.1272291243076324e-02
    z[6,5,1]  R2293     5.3780563175678253e-02
    z[6,5,1]  R2294     1.8765892088413239e-01
    z[6,5,1]  R2295     4.5511212944984436e-01
    z[6,5,1]  R2296     4.3033209443092346e-01
    z[6,5,1]  R2297     -7.2222399711608887e-01
    z[6,5,1]  R2298     -8.4902030229568481e-01
    z[6,5,1]  R2299     3.3304911851882935e-01
    z[6,5,1]  R2300     -9.1955929994583130e-01
    z[6,5,1]  R2301     -0.737914502620697
    z[6,5,1]  R2302     -6.8057817220687866e-01
    z[6,5,1]  R2303     8.9732962846755981e-01
    z[6,5,1]  R2304     9.5527225732803345e-01
    z[6,5,1]  R2305     2.4952462315559387e-01
    z[6,5,1]  R2306     5.9687721729278564e-01
    z[6,5,1]  R2307     5.2242338657379150e-01
    z[6,5,1]  R2308     4.3589583039283752e-01
    z[6,5,1]  R2309     5.0764840841293335e-01
    z[6,5,1]  R2310     3.8382586836814880e-01
    z[6,5,1]  R2311     -4.3060076236724854e-01
    z[6,5,1]  R2312     -5.8626502752304077e-01
    z[6,5,1]  R2313     -3.7644475698471069e-01
    z[6,5,1]  R2314     1.6134172910824418e-03
    z[6,5,1]  R2315     6.9854617118835449e-01
    z[6,5,1]  R2316     -3.0914485454559326e-01
    z[6,5,1]  R2317     -5.4646706581115723e-01
    z[6,5,1]  R2318     -5.0603449344635010e-01
    z[6,5,1]  R2319     -0.873330295085907
    z[6,5,1]  R2320     -8.2788646221160889e-01
    z[6,5,1]  R2321     -9.1456514596939087e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2224     -1
    z[6,5,2]  R2225     1
    z[6,5,2]  R2234     -1.3319614529609680e-01
    z[6,5,2]  R2235     -3.3799886703491211e-01
    z[6,5,2]  R2236     -2.8119698166847229e-01
    z[6,5,2]  R2237     -6.3282884657382965e-03
    z[6,5,2]  R2238     -4.1510784626007080e-01
    z[6,5,2]  R2239     -2.1796886622905731e-01
    z[6,5,2]  R2240     -3.6379560828208923e-02
    z[6,5,2]  R2241     3.6675009876489639e-02
    z[6,5,2]  R2242     -1.8968142569065094e-01
    z[6,5,2]  R2243     -1.4247059822082520e-01
    z[6,5,2]  R2244     -1.2563848495483398e-01
    z[6,5,2]  R2245     -9.7060143947601318e-02
    z[6,5,2]  R2246     -2.1673109382390976e-02
    z[6,5,2]  R2247     -4.1682547330856323e-01
    z[6,5,2]  R2248     -1.6679960489273071e-01
    z[6,5,2]  R2249     -0.431225061416626
    z[6,5,2]  R2250     0.111131452023983
    z[6,5,2]  R2251     -4.5923840999603271e-01
    z[6,5,2]  R2252     -7.5315505266189575e-01
    z[6,5,2]  R2253     -5.0678777694702148e-01
    z[6,5,2]  R2254     -2.5695204734802246e-01
    z[6,5,2]  R2255     -2.2990810871124268e-01
    z[6,5,2]  R2256     -9.1658405959606171e-02
    z[6,5,2]  R2257     5.6675948202610016e-02
    z[6,5,2]  R2258     -5.0259608775377274e-02
    z[6,5,2]  R2259     1.0611893236637115e-01
    z[6,5,2]  R2260     1.9353662431240082e-01
    z[6,5,2]  R2261     1.5623576939105988e-01
    z[6,5,2]  R2262     7.5560994446277618e-04
    z[6,5,2]  R2263     3.2969883084297180e-01
    z[6,5,2]  R2264     -4.0979039669036865e-01
    z[6,5,2]  R2265     2.3030509054660797e-01
    z[6,5,2]  R2266     4.4043174386024475e-01
    z[6,5,2]  R2267     -2.1861056983470917e-01
    z[6,5,2]  R2268     -3.9543649554252625e-01
    z[6,5,2]  R2269     -4.8836305737495422e-01
    z[6,5,2]  R2270     -1.5879217535257339e-03
    z[6,5,2]  R2271     -2.4725767970085144e-01
    z[6,5,2]  R2272     -1.1703561991453171e-01
    z[6,5,2]  R2273     0.0369969867169857
    z[6,5,2]  R2274     -3.4943285584449768e-01
    z[6,5,2]  R2275     -2.9353508353233337e-01
    z[6,5,2]  R2276     -7.9275742173194885e-03
    z[6,5,2]  R2277     -2.2706474363803864e-01
    z[6,5,2]  R2278     1.2162059545516968e-01
    z[6,5,2]  R2279     1.8791253864765167e-01
    z[6,5,2]  R2280     3.1081789731979370e-01
    z[6,5,2]  R2281     -1.5064038336277008e-01
    z[6,5,2]  R2282     4.1153150796890259e-01
    z[6,5,2]  R2283     1.6199788451194763e-01
    z[6,5,2]  R2284     6.4283972978591919e-01
    z[6,5,2]  R2285     2.3409101366996765e-01
    z[6,5,2]  R2286     2.7970978617668152e-01
    z[6,5,2]  R2287     0.496791809797287
    z[6,5,2]  R2288     5.2066934108734131e-01
    z[6,5,2]  R2289     5.8386647142469883e-03
    z[6,5,2]  R2290     4.2420539259910583e-01
    z[6,5,2]  R2291     4.7645160555839539e-01
    z[6,5,2]  R2292     2.7403315901756287e-01
    z[6,5,2]  R2293     -5.0252193212509155e-01
    z[6,5,2]  R2294     1.7684674263000488e-01
    z[6,5,2]  R2295     -4.3406879901885986e-01
    z[6,5,2]  R2296     -6.0438215732574463e-01
    z[6,5,2]  R2297     -3.4850567579269409e-01
    z[6,5,2]  R2298     -3.3150726556777954e-01
    z[6,5,2]  R2299     -5.6343829631805420e-01
    z[6,5,2]  R2300     -3.9096426218748093e-02
    z[6,5,2]  R2301     2.4002294242382050e-01
    z[6,5,2]  R2302     -0.611361563205719
    z[6,5,2]  R2303     -1.1894062906503677e-01
    z[6,5,2]  R2304     2.6409627869725227e-02
    z[6,5,2]  R2305     6.1987121589481831e-03
    z[6,5,2]  R2306     1.1879008263349533e-01
    z[6,5,2]  R2307     5.3941982984542847e-01
    z[6,5,2]  R2308     -8.7805025279521942e-02
    z[6,5,2]  R2309     6.1530423164367676e-01
    z[6,5,2]  R2310     4.2060518264770508e-01
    z[6,5,2]  R2311     -3.6346417665481567e-01
    z[6,5,2]  R2312     -5.2179563045501709e-01
    z[6,5,2]  R2313     -3.2189390063285828e-01
    z[6,5,2]  R2314     8.4723389148712158e-01
    z[6,5,2]  R2315     2.8638830780982971e-01
    z[6,5,2]  R2316     -6.1005878448486328e-01
    z[6,5,2]  R2317     -2.6746904850006104e-01
    z[6,5,2]  R2318     -0.0676533430814743
    z[6,5,2]  R2319     8.0158248543739319e-02
    z[6,5,2]  R2320     5.9549078345298767e-02
    z[6,5,2]  R2321     1.6035138070583344e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2226     -1
    z[6,5,3]  R2227     1
    z[6,5,3]  R2234     2.4851515889167786e-01
    z[6,5,3]  R2235     4.2799273133277893e-01
    z[6,5,3]  R2236     1.8995456397533417e-01
    z[6,5,3]  R2237     0.647131085395813
    z[6,5,3]  R2238     -3.3350121229887009e-02
    z[6,5,3]  R2239     -1.3669732958078384e-02
    z[6,5,3]  R2240     8.5663646459579468e-01
    z[6,5,3]  R2241     -2.4247553944587708e-01
    z[6,5,3]  R2242     1.1043892055749893e-01
    z[6,5,3]  R2243     4.7907626628875732e-01
    z[6,5,3]  R2244     -1.8333104252815247e-01
    z[6,5,3]  R2245     -5.6412893533706665e-01
    z[6,5,3]  R2246     1.4555303752422333e-01
    z[6,5,3]  R2247     1.7127810278907418e-03
    z[6,5,3]  R2248     -2.4269069731235504e-01
    z[6,5,3]  R2249     1.1815001815557480e-01
    z[6,5,3]  R2250     2.1872974932193756e-01
    z[6,5,3]  R2251     -2.4208946526050568e-01
    z[6,5,3]  R2252     1.3070549070835114e-01
    z[6,5,3]  R2253     3.3484759926795959e-01
    z[6,5,3]  R2254     3.0880925059318542e-01
    z[6,5,3]  R2255     6.7955709993839264e-02
    z[6,5,3]  R2256     -1.2718668580055237e-01
    z[6,5,3]  R2257     3.0917921662330627e-01
    z[6,5,3]  R2258     2.5221493840217590e-01
    z[6,5,3]  R2259     -7.5860089063644409e-01
    z[6,5,3]  R2260     -0.0707196369767189
    z[6,5,3]  R2261     -4.6028646826744080e-01
    z[6,5,3]  R2262     -7.2013401985168457e-01
    z[6,5,3]  R2263     -3.5336297750473022e-01
    z[6,5,3]  R2264     1.3543894886970520e-01
    z[6,5,3]  R2265     -3.0731633305549622e-01
    z[6,5,3]  R2266     2.5043663382530212e-01
    z[6,5,3]  R2267     1.9921740889549255e-01
    z[6,5,3]  R2268     -2.3116227984428406e-01
    z[6,5,3]  R2269     -2.2955887019634247e-01
    z[6,5,3]  R2270     -1.5074518509209156e-02
    z[6,5,3]  R2271     0.347474604845047
    z[6,5,3]  R2272     2.0738035440444946e-01
    z[6,5,3]  R2273     -0.728060245513916
    z[6,5,3]  R2274     2.4625155329704285e-01
    z[6,5,3]  R2275     2.9551351070404053e-01
    z[6,5,3]  R2276     0.180172398686409
    z[6,5,3]  R2277     -6.9118700921535492e-02
    z[6,5,3]  R2278     -4.9093249440193176e-01
    z[6,5,3]  R2279     8.9788466691970825e-02
    z[6,5,3]  R2280     -0.504069983959198
    z[6,5,3]  R2281     -5.8053833246231079e-01
    z[6,5,3]  R2282     5.4022260010242462e-02
    z[6,5,3]  R2283     7.7676810324192047e-02
    z[6,5,3]  R2284     -1.2030338868498802e-02
    z[6,5,3]  R2285     7.1206682920455933e-01
    z[6,5,3]  R2286     4.6227118372917175e-01
    z[6,5,3]  R2287     1.7022161185741425e-01
    z[6,5,3]  R2288     -3.9080867171287537e-01
    z[6,5,3]  R2289     8.0488091707229614e-01
    z[6,5,3]  R2290     -2.2143563628196716e-01
    z[6,5,3]  R2291     -3.1327739357948303e-01
    z[6,5,3]  R2292     -1.8965117633342743e-01
    z[6,5,3]  R2293     -3.6215326189994812e-01
    z[6,5,3]  R2294     -2.9161635041236877e-01
    z[6,5,3]  R2295     -1.8511785566806793e-01
    z[6,5,3]  R2296     -1.4170631766319275e-01
    z[6,5,3]  R2297     -3.8046240806579590e-01
    z[6,5,3]  R2298     -5.8095515705645084e-03
    z[6,5,3]  R2299     -8.5485443472862244e-02
    z[6,5,3]  R2300     -2.1694874763488770e-01
    z[6,5,3]  R2301     -9.1061845421791077e-02
    z[6,5,3]  R2302     -1.4058266580104828e-01
    z[6,5,3]  R2303     2.7991944551467896e-01
    z[6,5,3]  R2304     6.6506855189800262e-02
    z[6,5,3]  R2305     4.5748311281204224e-01
    z[6,5,3]  R2306     3.5309907793998718e-01
    z[6,5,3]  R2307     6.7494444549083710e-02
    z[6,5,3]  R2308     4.4161457568407059e-02
    z[6,5,3]  R2309     4.5583176612854004e-01
    z[6,5,3]  R2310     4.5203980803489685e-01
    z[6,5,3]  R2311     -1.9308102130889893e-01
    z[6,5,3]  R2312     -1.1954199522733688e-01
    z[6,5,3]  R2313     -3.7935337424278259e-01
    z[6,5,3]  R2314     3.4658986330032349e-01
    z[6,5,3]  R2315     5.6162470579147339e-01
    z[6,5,3]  R2316     -1.8775951862335205e-01
    z[6,5,3]  R2317     -1.1313343793153763e-01
    z[6,5,3]  R2318     2.4873189628124237e-02
    z[6,5,3]  R2319     0.0875496044754982
    z[6,5,3]  R2320     -1.2553407251834869e-01
    z[6,5,3]  R2321     -1.7480676993727684e-02
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2228     -1
    z[6,5,4]  R2229     1
    z[6,5,4]  R2234     -3.6935889720916748e-01
    z[6,5,4]  R2235     -4.3102037906646729e-01
    z[6,5,4]  R2236     -0.0522281676530838
    z[6,5,4]  R2237     1.3389755785465240e-01
    z[6,5,4]  R2238     3.5002410411834717e-01
    z[6,5,4]  R2239     -3.5380309820175171e-01
    z[6,5,4]  R2240     2.3240806162357330e-01
    z[6,5,4]  R2241     1.6689166426658630e-01
    z[6,5,4]  R2242     -7.7786058187484741e-01
    z[6,5,4]  R2243     1.5104007720947266e-01
    z[6,5,4]  R2244     2.6192682981491089e-01
    z[6,5,4]  R2245     1.8555636703968048e-01
    z[6,5,4]  R2246     -1.4745970070362091e-01
    z[6,5,4]  R2247     -2.2623822093009949e-01
    z[6,5,4]  R2248     -3.6451452970504761e-01
    z[6,5,4]  R2249     -1.0220992378890514e-02
    z[6,5,4]  R2250     -4.1237783432006836e-01
    z[6,5,4]  R2251     -2.7822852134704590e-01
    z[6,5,4]  R2252     -0.0856996551156044
    z[6,5,4]  R2253     3.4416213631629944e-02
    z[6,5,4]  R2254     -1.8395955860614777e-01
    z[6,5,4]  R2255     -1.9225528836250305e-01
    z[6,5,4]  R2256     -2.4892230331897736e-01
    z[6,5,4]  R2257     -3.6046814918518066e-01
    z[6,5,4]  R2258     -2.4335388839244843e-01
    z[6,5,4]  R2259     -7.2335690259933472e-02
    z[6,5,4]  R2260     1.1693262308835983e-01
    z[6,5,4]  R2261     -3.5507228970527649e-01
    z[6,5,4]  R2262     2.4996544420719147e-01
    z[6,5,4]  R2263     -4.8424351960420609e-02
    z[6,5,4]  R2264     -1.8865896761417389e-01
    z[6,5,4]  R2265     -3.0305463075637817e-01
    z[6,5,4]  R2266     -3.8017854094505310e-01
    z[6,5,4]  R2267     -4.1649696230888367e-01
    z[6,5,4]  R2268     -3.3740437030792236e-01
    z[6,5,4]  R2269     -2.9558593034744263e-01
    z[6,5,4]  R2270     -4.2544689774513245e-01
    z[6,5,4]  R2271     -1.5303482115268707e-01
    z[6,5,4]  R2272     -1.2073575705289841e-01
    z[6,5,4]  R2273     2.4712586402893066e-01
    z[6,5,4]  R2274     -2.2771361470222473e-01
    z[6,5,4]  R2275     -1.0204493999481201e-01
    z[6,5,4]  R2276     -4.4191029667854309e-01
    z[6,5,4]  R2277     -2.8548830747604370e-01
    z[6,5,4]  R2278     -4.4406521320343018e-01
    z[6,5,4]  R2279     2.1089971065521240e-01
    z[6,5,4]  R2280     -2.5434973835945129e-01
    z[6,5,4]  R2281     2.2958418726921082e-01
    z[6,5,4]  R2282     3.7069392204284668e-01
    z[6,5,4]  R2283     6.0400164127349854e-01
    z[6,5,4]  R2284     -3.5819873213768005e-01
    z[6,5,4]  R2285     8.4051378071308136e-02
    z[6,5,4]  R2286     8.7837286293506622e-02
    z[6,5,4]  R2287     -3.6483651399612427e-01
    z[6,5,4]  R2288     2.0078261196613312e-01
    z[6,5,4]  R2289     1.9267193973064423e-01
    z[6,5,4]  R2290     1.1413767933845520e-01
    z[6,5,4]  R2291     -3.7626230716705322e-01
    z[6,5,4]  R2292     -9.2131003737449646e-02
    z[6,5,4]  R2293     -2.5089371204376221e-01
    z[6,5,4]  R2294     5.0921601057052612e-01
    z[6,5,4]  R2295     -5.7260245084762573e-01
    z[6,5,4]  R2296     5.1801240444183350e-01
    z[6,5,4]  R2297     -1.7598392069339752e-01
    z[6,5,4]  R2298     -2.3380665481090546e-01
    z[6,5,4]  R2299     4.7376893460750580e-02
    z[6,5,4]  R2300     2.6536622643470764e-01
    z[6,5,4]  R2301     2.1654200553894043e-01
    z[6,5,4]  R2302     2.4909342825412750e-01
    z[6,5,4]  R2303     -0.0775151476264
    z[6,5,4]  R2304     2.5572302937507629e-01
    z[6,5,4]  R2305     -4.9793016910552979e-01
    z[6,5,4]  R2306     -4.9561339616775513e-01
    z[6,5,4]  R2307     -5.1052731275558472e-01
    z[6,5,4]  R2308     -4.8252606391906738e-01
    z[6,5,4]  R2309     -2.0163437724113464e-01
    z[6,5,4]  R2310     -2.0760956406593323e-01
    z[6,5,4]  R2311     5.1144324243068695e-02
    z[6,5,4]  R2312     2.9054602980613708e-01
    z[6,5,4]  R2313     3.7746012210845947e-01
    z[6,5,4]  R2314     -8.3451956510543823e-02
    z[6,5,4]  R2315     -3.3074009418487549e-01
    z[6,5,4]  R2316     1.0776181519031525e-01
    z[6,5,4]  R2317     -1.6035382449626923e-01
    z[6,5,4]  R2318     0.302490234375
    z[6,5,4]  R2319     3.8686412572860718e-01
    z[6,5,4]  R2320     -1.8753142654895782e-01
    z[6,5,4]  R2321     -7.1950078010559082e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2230     -1
    z[6,5,5]  R2231     1
    z[6,5,5]  R2234     -1.3205623626708984e-01
    z[6,5,5]  R2235     2.3775672540068626e-02
    z[6,5,5]  R2236     -2.3560172319412231e-01
    z[6,5,5]  R2237     -2.4947191774845123e-01
    z[6,5,5]  R2238     -2.1468194201588631e-02
    z[6,5,5]  R2239     -3.0987852811813354e-01
    z[6,5,5]  R2240     1.9926816225051880e-01
    z[6,5,5]  R2241     2.4895383417606354e-01
    z[6,5,5]  R2242     -2.3796521127223969e-01
    z[6,5,5]  R2243     1.6448259353637695e-01
    z[6,5,5]  R2244     -8.3478963375091553e-01
    z[6,5,5]  R2245     -5.4874008893966675e-01
    z[6,5,5]  R2246     -2.7937579154968262e-01
    z[6,5,5]  R2247     1.6618889570236206e-01
    z[6,5,5]  R2248     -2.8234788775444031e-01
    z[6,5,5]  R2249     -3.3864060044288635e-01
    z[6,5,5]  R2250     -1.9196757674217224e-01
    z[6,5,5]  R2251     -2.1979844197630882e-02
    z[6,5,5]  R2252     -8.6034417152404785e-02
    z[6,5,5]  R2253     -6.9077193737030029e-02
    z[6,5,5]  R2254     -4.2867638170719147e-02
    z[6,5,5]  R2255     -0.271806925535202
    z[6,5,5]  R2256     -8.6144261062145233e-02
    z[6,5,5]  R2257     -3.9314371347427368e-01
    z[6,5,5]  R2258     1.2027243524789810e-01
    z[6,5,5]  R2259     7.5420483946800232e-02
    z[6,5,5]  R2260     1.8396285176277161e-01
    z[6,5,5]  R2261     4.9101737141609192e-01
    z[6,5,5]  R2262     -8.1900522112846375e-02
    z[6,5,5]  R2263     -1.1446280032396317e-01
    z[6,5,5]  R2264     7.4930049479007721e-02
    z[6,5,5]  R2265     -0.532384991645813
    z[6,5,5]  R2266     4.9820342659950256e-01
    z[6,5,5]  R2267     0.0839017704129219
    z[6,5,5]  R2268     -1.7509314417839050e-01
    z[6,5,5]  R2269     -2.3635946214199066e-01
    z[6,5,5]  R2270     -4.0245339274406433e-01
    z[6,5,5]  R2271     -1.5049065649509430e-01
    z[6,5,5]  R2272     -4.7530877590179443e-01
    z[6,5,5]  R2273     -1.7866681516170502e-01
    z[6,5,5]  R2274     -4.0760576725006104e-01
    z[6,5,5]  R2275     -2.7285388112068176e-01
    z[6,5,5]  R2276     -9.9871069192886353e-02
    z[6,5,5]  R2277     -2.8446984291076660e-01
    z[6,5,5]  R2278     5.5914241075515747e-01
    z[6,5,5]  R2279     2.0898316800594330e-01
    z[6,5,5]  R2280     -8.0084212124347687e-02
    z[6,5,5]  R2281     4.5964911580085754e-01
    z[6,5,5]  R2282     1.5262268483638763e-01
    z[6,5,5]  R2283     1.8325030803680420e-01
    z[6,5,5]  R2284     -1.2088346481323242e-01
    z[6,5,5]  R2285     -6.2800031900405884e-01
    z[6,5,5]  R2286     -4.0164360404014587e-01
    z[6,5,5]  R2287     -5.4557675123214722e-01
    z[6,5,5]  R2288     -4.5615857839584351e-01
    z[6,5,5]  R2289     1.0082848370075226e-01
    z[6,5,5]  R2290     1.4392022788524628e-01
    z[6,5,5]  R2291     2.1801939606666565e-01
    z[6,5,5]  R2292     -6.6552406549453735e-01
    z[6,5,5]  R2293     -7.8395850956439972e-02
    z[6,5,5]  R2294     5.0746500492095947e-01
    z[6,5,5]  R2295     -2.4189466238021851e-01
    z[6,5,5]  R2296     -2.1659222245216370e-01
    z[6,5,5]  R2297     -7.7802293002605438e-02
    z[6,5,5]  R2298     -1.5291871130466461e-01
    z[6,5,5]  R2299     -2.2871309518814087e-01
    z[6,5,5]  R2300     -7.2227261960506439e-02
    z[6,5,5]  R2301     8.4162920713424683e-02
    z[6,5,5]  R2302     -7.6263256371021271e-02
    z[6,5,5]  R2303     2.2961314767599106e-02
    z[6,5,5]  R2304     2.7249900624155998e-02
    z[6,5,5]  R2305     6.1988379806280136e-02
    z[6,5,5]  R2306     2.1062639355659485e-01
    z[6,5,5]  R2307     -1.4936427772045135e-01
    z[6,5,5]  R2308     5.0663727521896362e-01
    z[6,5,5]  R2309     3.1477779150009155e-01
    z[6,5,5]  R2310     -1.0706861317157745e-01
    z[6,5,5]  R2311     4.5557871460914612e-01
    z[6,5,5]  R2312     -1.5782682597637177e-01
    z[6,5,5]  R2313     2.0386941730976105e-01
    z[6,5,5]  R2314     2.9360356926918030e-01
    z[6,5,5]  R2315     1.3964110985398293e-02
    z[6,5,5]  R2316     1.6813308000564575e-01
    z[6,5,5]  R2317     2.7296161651611328e-01
    z[6,5,5]  R2318     -4.2952352762222290e-01
    z[6,5,5]  R2319     -0.0528470054268837
    z[6,5,5]  R2320     -4.6429717540740967e-01
    z[6,5,5]  R2321     -3.0102476477622986e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2232     -1
    z[6,5,6]  R2233     1
    z[6,5,6]  R2234     -3.9352121949195862e-01
    z[6,5,6]  R2235     0.397322416305542
    z[6,5,6]  R2236     6.4916145801544189e-01
    z[6,5,6]  R2237     1.3663363456726074e-01
    z[6,5,6]  R2238     1.1498459428548813e-01
    z[6,5,6]  R2239     2.0553120970726013e-01
    z[6,5,6]  R2240     2.8817737102508545e-01
    z[6,5,6]  R2241     -3.0668967962265015e-01
    z[6,5,6]  R2242     -0.300184428691864
    z[6,5,6]  R2243     -5.5269223451614380e-01
    z[6,5,6]  R2244     5.0016533583402634e-02
    z[6,5,6]  R2245     -4.7827857732772827e-01
    z[6,5,6]  R2246     -2.7828231453895569e-02
    z[6,5,6]  R2247     1.3620495796203613e-02
    z[6,5,6]  R2248     5.1132321357727051e-02
    z[6,5,6]  R2249     3.1818398833274841e-01
    z[6,5,6]  R2250     -8.1356592476367950e-02
    z[6,5,6]  R2251     2.5460091233253479e-01
    z[6,5,6]  R2252     -1.0346055030822754e-02
    z[6,5,6]  R2253     -2.9780656099319458e-01
    z[6,5,6]  R2254     2.6816916465759277e-01
    z[6,5,6]  R2255     -2.3238374292850494e-01
    z[6,5,6]  R2256     -1.3719917833805084e-01
    z[6,5,6]  R2257     1.9939646124839783e-01
    z[6,5,6]  R2258     -2.9235085844993591e-01
    z[6,5,6]  R2259     4.3229696154594421e-01
    z[6,5,6]  R2260     1.7052348703145981e-02
    z[6,5,6]  R2261     -3.6040824651718140e-01
    z[6,5,6]  R2262     5.1182365417480469e-01
    z[6,5,6]  R2263     0.343861848115921
    z[6,5,6]  R2264     -0.0243021659553051
    z[6,5,6]  R2265     -1.8595525622367859e-01
    z[6,5,6]  R2266     -4.3452523648738861e-02
    z[6,5,6]  R2267     -2.2632901370525360e-01
    z[6,5,6]  R2268     1.7174807190895081e-01
    z[6,5,6]  R2269     0.0263583455234766
    z[6,5,6]  R2270     2.5093618035316467e-01
    z[6,5,6]  R2271     -2.2811074554920197e-01
    z[6,5,6]  R2272     -7.6790824532508850e-02
    z[6,5,6]  R2273     4.0540233254432678e-01
    z[6,5,6]  R2274     2.2860527038574219e-01
    z[6,5,6]  R2275     -1.0897362232208252e-01
    z[6,5,6]  R2276     -7.8589171171188354e-02
    z[6,5,6]  R2277     -1.7819654941558838e-01
    z[6,5,6]  R2278     -1.2982444465160370e-01
    z[6,5,6]  R2279     1.3908928632736206e-01
    z[6,5,6]  R2280     2.1789376437664032e-01
    z[6,5,6]  R2281     1.9258503615856171e-01
    z[6,5,6]  R2282     1.3709321618080139e-01
    z[6,5,6]  R2283     -1.3313873112201691e-01
    z[6,5,6]  R2284     0.654710054397583
    z[6,5,6]  R2285     1.1131328344345093e-01
    z[6,5,6]  R2286     -6.2751924991607666e-01
    z[6,5,6]  R2287     -2.8403052687644958e-01
    z[6,5,6]  R2288     -1.4015206135809422e-02
    z[6,5,6]  R2289     3.9710375666618347e-01
    z[6,5,6]  R2290     -4.1147151589393616e-01
    z[6,5,6]  R2291     -0.648550808429718
    z[6,5,6]  R2292     -3.8981980085372925e-01
    z[6,5,6]  R2293     1.1535238474607468e-01
    z[6,5,6]  R2294     5.1537081599235535e-02
    z[6,5,6]  R2295     -1.7527288198471069e-01
    z[6,5,6]  R2296     -0.308473140001297
    z[6,5,6]  R2297     3.4835276007652283e-01
    z[6,5,6]  R2298     1.7663891613483429e-01
    z[6,5,6]  R2299     0.566135585308075
    z[6,5,6]  R2300     1.7517418600618839e-03
    z[6,5,6]  R2301     4.6621233224868774e-01
    z[6,5,6]  R2302     -7.9900383949279785e-02
    z[6,5,6]  R2303     1.5412263572216034e-01
    z[6,5,6]  R2304     -4.9296006560325623e-02
    z[6,5,6]  R2305     7.5118844397366047e-03
    z[6,5,6]  R2306     4.6299794316291809e-01
    z[6,5,6]  R2307     -1.9924205541610718e-01
    z[6,5,6]  R2308     4.8924211412668228e-02
    z[6,5,6]  R2309     5.5955359712243080e-03
    z[6,5,6]  R2310     4.0630626678466797e-01
    z[6,5,6]  R2311     1.1427410691976547e-01
    z[6,5,6]  R2312     -8.3497636020183563e-02
    z[6,5,6]  R2313     4.6415582299232483e-01
    z[6,5,6]  R2314     3.8634572178125381e-02
    z[6,5,6]  R2315     -1.5741581097245216e-02
    z[6,5,6]  R2316     -2.1139627322554588e-02
    z[6,5,6]  R2317     1.6749539971351624e-01
    z[6,5,6]  R2318     4.4518679380416870e-01
    z[6,5,6]  R2319     -4.5397195965051651e-02
    z[6,5,6]  R2320     -2.7749935165047646e-02
    z[6,5,6]  R2321     1.2521874904632568e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2374     -1
    z[6,7,0]  R2375     1
    z[6,7,0]  R2388     2.0031196996569633e-02
    z[6,7,0]  R2389     4.7062397003173828e-01
    z[6,7,0]  R2390     -2.0097967982292175e-01
    z[6,7,0]  R2391     5.3255504369735718e-01
    z[6,7,0]  R2392     -5.3218755871057510e-02
    z[6,7,0]  R2393     -5.1938509941101074e-01
    z[6,7,0]  R2394     7.6573394238948822e-02
    z[6,7,0]  R2395     -6.3433700799942017e-01
    z[6,7,0]  R2396     2.9662674292922020e-02
    z[6,7,0]  R2397     5.4677534103393555e-01
    z[6,7,0]  R2398     1.3562743365764618e-01
    z[6,7,0]  R2399     1.5572011470794678e-01
    z[6,7,0]  R2400     1.1420238018035889e-01
    z[6,7,0]  R2401     2.3889848962426186e-02
    z[6,7,0]  R2402     -1.5095965564250946e-01
    z[6,7,0]  R2403     -3.1263357400894165e-01
    z[6,7,0]  R2404     -2.6962655782699585e-01
    z[6,7,0]  R2405     -2.3602253198623657e-01
    z[6,7,0]  R2406     -2.9074054956436157e-01
    z[6,7,0]  R2407     -3.3436134457588196e-01
    z[6,7,0]  R2408     -1.2169932574033737e-01
    z[6,7,0]  R2409     1.3749545812606812e-01
    z[6,7,0]  R2410     -2.2975397109985352e-01
    z[6,7,0]  R2411     -3.8394263386726379e-01
    z[6,7,0]  R2412     -2.8801003098487854e-01
    z[6,7,0]  R2413     -2.5030487775802612e-01
    z[6,7,0]  R2414     5.4529821872711182e-01
    z[6,7,0]  R2415     3.7663927674293518e-01
    z[6,7,0]  R2416     -2.1984383463859558e-01
    z[6,7,0]  R2417     -6.0424816608428955e-01
    z[6,7,0]  R2418     3.0019545927643776e-02
    z[6,7,0]  R2419     -1.9691903889179230e-01
    z[6,7,0]  R2420     7.2666600346565247e-02
    z[6,7,0]  R2421     -1.9034427404403687e-01
    z[6,7,0]  R2422     1.2171491980552673e-01
    z[6,7,0]  R2423     -0.00383838452398777
    z[6,7,0]  R2424     -0.226633220911026
    z[6,7,0]  R2425     -4.5925104618072510e-01
    z[6,7,0]  R2426     -4.1722607612609863e-01
    z[6,7,0]  R2427     -2.6629993319511414e-01
    z[6,7,0]  R2428     -2.9132384061813354e-01
    z[6,7,0]  R2429     -3.7018135190010071e-01
    z[6,7,0]  R2430     1.9356849789619446e-01
    z[6,7,0]  R2431     -3.1235665082931519e-01
    z[6,7,0]  R2432     3.4809085726737976e-01
    z[6,7,0]  R2433     5.3691053390502930e-01
    z[6,7,0]  R2434     -4.8993730545043945e-01
    z[6,7,0]  R2435     5.6050747632980347e-01
    z[6,7,0]  R2436     -8.0752231180667877e-02
    z[6,7,0]  R2437     -4.3593738228082657e-02
    z[6,7,0]  R2438     -5.9910756535828114e-03
    z[6,7,0]  R2439     1.3063609600067139e-02
    z[6,7,0]  R2440     -8.1645393371582031e-01
    z[6,7,0]  R2441     1.2668228149414062e-01
    z[6,7,0]  R2442     6.4930331707000732e-01
    z[6,7,0]  R2443     6.6607165336608887e-01
    z[6,7,0]  R2444     4.8031106591224670e-01
    z[6,7,0]  R2445     7.8610196709632874e-02
    z[6,7,0]  R2446     6.0148149728775024e-01
    z[6,7,0]  R2447     7.0729398727416992e-01
    z[6,7,0]  R2448     3.1340315937995911e-01
    z[6,7,0]  R2449     4.8671886324882507e-01
    z[6,7,0]  R2450     6.2293016910552979e-01
    z[6,7,0]  R2451     5.7283890247344971e-01
    z[6,7,0]  R2452     -1.7958205193281174e-02
    z[6,7,0]  R2453     1.1035569012165070e-02
    z[6,7,0]  R2454     5.6998640298843384e-02
    z[6,7,0]  R2455     -1.9504573196172714e-02
    z[6,7,0]  R2456     -1.9807815551757812e-02
    z[6,7,0]  R2457     -1.6340428963303566e-02
    z[6,7,0]  R2458     5.3168445825576782e-02
    z[6,7,0]  R2459     0.707912266254425
    z[6,7,0]  R2460     -3.0555235221982002e-02
    z[6,7,0]  R2461     3.5212565213441849e-02
    z[6,7,0]  R2462     1.8329776823520660e-02
    z[6,7,0]  R2463     1.8452009558677673e-01
    z[6,7,0]  R2464     0.563755989074707
    z[6,7,0]  R2465     6.3438493013381958e-01
    z[6,7,0]  R2466     5.1289850473403931e-01
    z[6,7,0]  R2467     5.3781211376190186e-01
    z[6,7,0]  R2468     3.1111446022987366e-01
    z[6,7,0]  R2469     -2.7675172314047813e-02
    z[6,7,0]  R2470     0.0125663997605443
    z[6,7,0]  R2471     1.7356218770146370e-02
    z[6,7,0]  R2472     -4.0727756917476654e-02
    z[6,7,0]  R2473     -1.8608981743454933e-02
    z[6,7,0]  R2474     -1.7569025978446007e-02
    z[6,7,0]  R2475     -1.0819350183010101e-01
    z[6,7,0]  R2476     4.4395062327384949e-01
    z[6,7,0]  R2477     2.8860560059547424e-01
    z[6,7,0]  R2478     5.7375203818082809e-02
    z[6,7,0]  R2479     1.2621617875993252e-02
    z[6,7,0]  R2480     2.9631700366735458e-02
    z[6,7,0]  R2481     -3.8117118179798126e-02
    z[6,7,0]  R2482     4.1012534499168396e-01
    z[6,7,0]  R2483     4.6212357282638550e-01
    z[6,7,0]  R2484     4.2580339312553406e-01
    z[6,7,0]  R2485     3.7716484069824219e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2376     -1
    z[6,7,1]  R2377     1
    z[6,7,1]  R2388     -7.8190410137176514e-01
    z[6,7,1]  R2389     -3.6997714638710022e-01
    z[6,7,1]  R2390     -6.0399180650711060e-01
    z[6,7,1]  R2391     -4.4579467177391052e-01
    z[6,7,1]  R2392     -8.2918137311935425e-01
    z[6,7,1]  R2393     -6.4737731218338013e-01
    z[6,7,1]  R2394     -2.8673955798149109e-01
    z[6,7,1]  R2395     -5.9463238716125488e-01
    z[6,7,1]  R2396     -4.4625002145767212e-01
    z[6,7,1]  R2397     -3.0965870618820190e-01
    z[6,7,1]  R2398     4.0525174140930176e-01
    z[6,7,1]  R2399     2.8946825861930847e-01
    z[6,7,1]  R2400     9.2991006374359131e-01
    z[6,7,1]  R2401     8.6411511898040771e-01
    z[6,7,1]  R2402     8.2175713777542114e-01
    z[6,7,1]  R2403     6.9736850261688232e-01
    z[6,7,1]  R2404     0.808444619178772
    z[6,7,1]  R2405     7.2943145036697388e-01
    z[6,7,1]  R2406     5.6239664554595947e-01
    z[6,7,1]  R2407     6.5161406993865967e-01
    z[6,7,1]  R2408     8.4629094600677490e-01
    z[6,7,1]  R2409     8.7107741832733154e-01
    z[6,7,1]  R2410     9.1347074508666992e-01
    z[6,7,1]  R2411     6.5538221597671509e-01
    z[6,7,1]  R2412     8.3171874284744263e-01
    z[6,7,1]  R2413     3.9090868830680847e-01
    z[6,7,1]  R2414     7.8255093097686768e-01
    z[6,7,1]  R2415     3.5327199101448059e-01
    z[6,7,1]  R2416     3.1925094127655029e-01
    z[6,7,1]  R2417     5.1732963323593140e-01
    z[6,7,1]  R2418     8.7808293104171753e-01
    z[6,7,1]  R2419     6.3551861047744751e-01
    z[6,7,1]  R2420     5.8599531650543213e-01
    z[6,7,1]  R2421     8.0284309387207031e-01
    z[6,7,1]  R2422     7.7548879384994507e-01
    z[6,7,1]  R2423     7.5157040357589722e-01
    z[6,7,1]  R2424     7.3652219772338867e-01
    z[6,7,1]  R2425     7.1352082490921021e-01
    z[6,7,1]  R2426     7.2306710481643677e-01
    z[6,7,1]  R2427     3.7456589937210083e-01
    z[6,7,1]  R2428     6.7980217933654785e-01
    z[6,7,1]  R2429     7.6989412307739258e-01
    z[6,7,1]  R2430     0.847685694694519
    z[6,7,1]  R2431     0.807413637638092
    z[6,7,1]  R2432     3.1038349866867065e-01
    z[6,7,1]  R2433     7.4890291690826416e-01
    z[6,7,1]  R2434     5.3914952278137207e-01
    z[6,7,1]  R2435     1.5823675692081451e-01
    z[6,7,1]  R2436     8.0106192827224731e-01
    z[6,7,1]  R2437     7.4141615629196167e-01
    z[6,7,1]  R2438     -4.2655521631240845e-01
    z[6,7,1]  R2439     -2.8006985783576965e-01
    z[6,7,1]  R2440     -1.3057418167591095e-01
    z[6,7,1]  R2441     8.6231559514999390e-01
    z[6,7,1]  R2442     6.7569863796234131e-01
    z[6,7,1]  R2443     1.4423798024654388e-01
    z[6,7,1]  R2444     7.6201355457305908e-01
    z[6,7,1]  R2445     8.3235615491867065e-01
    z[6,7,1]  R2446     6.3679379224777222e-01
    z[6,7,1]  R2447     5.1596456766128540e-01
    z[6,7,1]  R2448     -3.4337392449378967e-01
    z[6,7,1]  R2449     5.2500668913125992e-02
    z[6,7,1]  R2450     -3.8583520799875259e-02
    z[6,7,1]  R2451     -3.3465981483459473e-01
    z[6,7,1]  R2452     9.7293472290039062e-01
    z[6,7,1]  R2453     9.0512287616729736e-01
    z[6,7,1]  R2454     9.4747757911682129e-01
    z[6,7,1]  R2455     9.5006054639816284e-01
    z[6,7,1]  R2456     0.967280924320221
    z[6,7,1]  R2457     9.4922721385955811e-01
    z[6,7,1]  R2458     -1.7480291426181793e-01
    z[6,7,1]  R2459     1.3711860775947571e-01
    z[6,7,1]  R2460     9.6915805339813232e-01
    z[6,7,1]  R2461     9.1265428066253662e-01
    z[6,7,1]  R2462     8.1704908609390259e-01
    z[6,7,1]  R2463     5.7714241743087769e-01
    z[6,7,1]  R2464     7.2377204895019531e-01
    z[6,7,1]  R2465     7.5220936536788940e-01
    z[6,7,1]  R2466     7.6439785957336426e-01
    z[6,7,1]  R2467     7.2237241268157959e-01
    z[6,7,1]  R2468     5.4793828725814819e-01
    z[6,7,1]  R2469     9.8418653011322021e-01
    z[6,7,1]  R2470     9.2435592412948608e-01
    z[6,7,1]  R2471     8.8267183303833008e-01
    z[6,7,1]  R2472     8.5710215568542480e-01
    z[6,7,1]  R2473     0.840378999710083
    z[6,7,1]  R2474     9.3658220767974854e-01
    z[6,7,1]  R2475     9.1933250427246094e-01
    z[6,7,1]  R2476     8.5234391689300537e-01
    z[6,7,1]  R2477     -2.7679893374443054e-01
    z[6,7,1]  R2478     8.6908000707626343e-01
    z[6,7,1]  R2479     9.6912008523941040e-01
    z[6,7,1]  R2480     9.0541845560073853e-01
    z[6,7,1]  R2481     0.900120735168457
    z[6,7,1]  R2482     0.884118378162384
    z[6,7,1]  R2483     8.3616447448730469e-01
    z[6,7,1]  R2484     8.4244924783706665e-01
    z[6,7,1]  R2485     8.7358832359313965e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2378     -1
    z[6,7,2]  R2379     1
    z[6,7,2]  R2388     -1.3319614529609680e-01
    z[6,7,2]  R2389     -3.3799886703491211e-01
    z[6,7,2]  R2390     -2.8119698166847229e-01
    z[6,7,2]  R2391     -6.3282884657382965e-03
    z[6,7,2]  R2392     -4.1510784626007080e-01
    z[6,7,2]  R2393     -2.1796886622905731e-01
    z[6,7,2]  R2394     -3.6379560828208923e-02
    z[6,7,2]  R2395     3.6675009876489639e-02
    z[6,7,2]  R2396     -1.8968142569065094e-01
    z[6,7,2]  R2397     -1.4247059822082520e-01
    z[6,7,2]  R2398     -1.2563848495483398e-01
    z[6,7,2]  R2399     -9.7060143947601318e-02
    z[6,7,2]  R2400     -2.1673109382390976e-02
    z[6,7,2]  R2401     -4.1682547330856323e-01
    z[6,7,2]  R2402     -1.6679960489273071e-01
    z[6,7,2]  R2403     -0.431225061416626
    z[6,7,2]  R2404     0.111131452023983
    z[6,7,2]  R2405     -4.5923840999603271e-01
    z[6,7,2]  R2406     -7.5315505266189575e-01
    z[6,7,2]  R2407     -5.0678777694702148e-01
    z[6,7,2]  R2408     -2.5695204734802246e-01
    z[6,7,2]  R2409     -2.2990810871124268e-01
    z[6,7,2]  R2410     -9.1658405959606171e-02
    z[6,7,2]  R2411     5.6675948202610016e-02
    z[6,7,2]  R2412     -5.0259608775377274e-02
    z[6,7,2]  R2413     1.0611893236637115e-01
    z[6,7,2]  R2414     1.9353662431240082e-01
    z[6,7,2]  R2415     1.5623576939105988e-01
    z[6,7,2]  R2416     7.5560994446277618e-04
    z[6,7,2]  R2417     3.2969883084297180e-01
    z[6,7,2]  R2418     -4.0979039669036865e-01
    z[6,7,2]  R2419     2.3030509054660797e-01
    z[6,7,2]  R2420     4.4043174386024475e-01
    z[6,7,2]  R2421     -2.1861056983470917e-01
    z[6,7,2]  R2422     -3.9543649554252625e-01
    z[6,7,2]  R2423     -4.8836305737495422e-01
    z[6,7,2]  R2424     -1.5879217535257339e-03
    z[6,7,2]  R2425     -2.4725767970085144e-01
    z[6,7,2]  R2426     -1.1703561991453171e-01
    z[6,7,2]  R2427     0.0369969867169857
    z[6,7,2]  R2428     -3.4943285584449768e-01
    z[6,7,2]  R2429     -2.9353508353233337e-01
    z[6,7,2]  R2430     -7.9275742173194885e-03
    z[6,7,2]  R2431     -2.2706474363803864e-01
    z[6,7,2]  R2432     1.2162059545516968e-01
    z[6,7,2]  R2433     1.8791253864765167e-01
    z[6,7,2]  R2434     3.1081789731979370e-01
    z[6,7,2]  R2435     -1.5064038336277008e-01
    z[6,7,2]  R2436     4.1153150796890259e-01
    z[6,7,2]  R2437     1.6199788451194763e-01
    z[6,7,2]  R2438     -1.5067394077777863e-01
    z[6,7,2]  R2439     -0.516549289226532
    z[6,7,2]  R2440     -6.6462293267250061e-02
    z[6,7,2]  R2441     1.8661996349692345e-02
    z[6,7,2]  R2442     1.3094486296176910e-01
    z[6,7,2]  R2443     -1.2780325114727020e-01
    z[6,7,2]  R2444     4.9446918070316315e-02
    z[6,7,2]  R2445     -0.163267582654953
    z[6,7,2]  R2446     -1.3015115261077881e-01
    z[6,7,2]  R2447     -0.0707424059510231
    z[6,7,2]  R2448     -0.0759369432926178
    z[6,7,2]  R2449     -4.3421775102615356e-01
    z[6,7,2]  R2450     -8.3179615437984467e-02
    z[6,7,2]  R2451     2.1237170696258545e-01
    z[6,7,2]  R2452     -0.0409720353782177
    z[6,7,2]  R2453     -9.2496760189533234e-02
    z[6,7,2]  R2454     -0.0654149055480957
    z[6,7,2]  R2455     -1.7862991988658905e-01
    z[6,7,2]  R2456     -0.072944276034832
    z[6,7,2]  R2457     -1.9429367035627365e-02
    z[6,7,2]  R2458     -7.5190417468547821e-02
    z[6,7,2]  R2459     2.7794721722602844e-01
    z[6,7,2]  R2460     0.0480441153049469
    z[6,7,2]  R2461     6.2870495021343231e-02
    z[6,7,2]  R2462     -2.7227871119976044e-02
    z[6,7,2]  R2463     3.2441091537475586e-01
    z[6,7,2]  R2464     3.2351487874984741e-01
    z[6,7,2]  R2465     1.6495469212532043e-01
    z[6,7,2]  R2466     3.3526563644409180e-01
    z[6,7,2]  R2467     0.269064724445343
    z[6,7,2]  R2468     -4.6142172813415527e-01
    z[6,7,2]  R2469     -5.3108941763639450e-02
    z[6,7,2]  R2470     5.4428409785032272e-03
    z[6,7,2]  R2471     -1.3304175436496735e-01
    z[6,7,2]  R2472     3.1891215592622757e-02
    z[6,7,2]  R2473     -6.6032111644744873e-02
    z[6,7,2]  R2474     -8.4833957254886627e-02
    z[6,7,2]  R2475     -9.7852818667888641e-02
    z[6,7,2]  R2476     -1.3732887804508209e-01
    z[6,7,2]  R2477     8.9185750484466553e-01
    z[6,7,2]  R2478     -1.8962593749165535e-02
    z[6,7,2]  R2479     -1.2604096531867981e-01
    z[6,7,2]  R2480     -2.0869433879852295e-01
    z[6,7,2]  R2481     6.8582065403461456e-02
    z[6,7,2]  R2482     8.9915379881858826e-02
    z[6,7,2]  R2483     -4.3222531676292419e-02
    z[6,7,2]  R2484     8.1388704478740692e-02
    z[6,7,2]  R2485     1.9947733730077744e-02
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2380     -1
    z[6,7,3]  R2381     1
    z[6,7,3]  R2388     2.4851515889167786e-01
    z[6,7,3]  R2389     4.2799273133277893e-01
    z[6,7,3]  R2390     1.8995456397533417e-01
    z[6,7,3]  R2391     0.647131085395813
    z[6,7,3]  R2392     -3.3350121229887009e-02
    z[6,7,3]  R2393     -1.3669732958078384e-02
    z[6,7,3]  R2394     8.5663646459579468e-01
    z[6,7,3]  R2395     -2.4247553944587708e-01
    z[6,7,3]  R2396     1.1043892055749893e-01
    z[6,7,3]  R2397     4.7907626628875732e-01
    z[6,7,3]  R2398     -1.8333104252815247e-01
    z[6,7,3]  R2399     -5.6412893533706665e-01
    z[6,7,3]  R2400     1.4555303752422333e-01
    z[6,7,3]  R2401     1.7127810278907418e-03
    z[6,7,3]  R2402     -2.4269069731235504e-01
    z[6,7,3]  R2403     1.1815001815557480e-01
    z[6,7,3]  R2404     2.1872974932193756e-01
    z[6,7,3]  R2405     -2.4208946526050568e-01
    z[6,7,3]  R2406     1.3070549070835114e-01
    z[6,7,3]  R2407     3.3484759926795959e-01
    z[6,7,3]  R2408     3.0880925059318542e-01
    z[6,7,3]  R2409     6.7955709993839264e-02
    z[6,7,3]  R2410     -1.2718668580055237e-01
    z[6,7,3]  R2411     3.0917921662330627e-01
    z[6,7,3]  R2412     2.5221493840217590e-01
    z[6,7,3]  R2413     -7.5860089063644409e-01
    z[6,7,3]  R2414     -0.0707196369767189
    z[6,7,3]  R2415     -4.6028646826744080e-01
    z[6,7,3]  R2416     -7.2013401985168457e-01
    z[6,7,3]  R2417     -3.5336297750473022e-01
    z[6,7,3]  R2418     1.3543894886970520e-01
    z[6,7,3]  R2419     -3.0731633305549622e-01
    z[6,7,3]  R2420     2.5043663382530212e-01
    z[6,7,3]  R2421     1.9921740889549255e-01
    z[6,7,3]  R2422     -2.3116227984428406e-01
    z[6,7,3]  R2423     -2.2955887019634247e-01
    z[6,7,3]  R2424     -1.5074518509209156e-02
    z[6,7,3]  R2425     0.347474604845047
    z[6,7,3]  R2426     2.0738035440444946e-01
    z[6,7,3]  R2427     -0.728060245513916
    z[6,7,3]  R2428     2.4625155329704285e-01
    z[6,7,3]  R2429     2.9551351070404053e-01
    z[6,7,3]  R2430     0.180172398686409
    z[6,7,3]  R2431     -6.9118700921535492e-02
    z[6,7,3]  R2432     -4.9093249440193176e-01
    z[6,7,3]  R2433     8.9788466691970825e-02
    z[6,7,3]  R2434     -0.504069983959198
    z[6,7,3]  R2435     -5.8053833246231079e-01
    z[6,7,3]  R2436     5.4022260010242462e-02
    z[6,7,3]  R2437     7.7676810324192047e-02
    z[6,7,3]  R2438     6.3924556970596313e-01
    z[6,7,3]  R2439     -2.3378323018550873e-01
    z[6,7,3]  R2440     -9.3613415956497192e-02
    z[6,7,3]  R2441     1.1116736382246017e-01
    z[6,7,3]  R2442     -7.1401178836822510e-02
    z[6,7,3]  R2443     -0.562372088432312
    z[6,7,3]  R2444     -1.9542230665683746e-01
    z[6,7,3]  R2445     -4.0477123856544495e-01
    z[6,7,3]  R2446     4.2328916490077972e-02
    z[6,7,3]  R2447     -3.7208297848701477e-01
    z[6,7,3]  R2448     1.5099371969699860e-01
    z[6,7,3]  R2449     -4.2236658930778503e-01
    z[6,7,3]  R2450     -2.6341335847973824e-02
    z[6,7,3]  R2451     -3.4813681244850159e-01
    z[6,7,3]  R2452     -1.9452878832817078e-01
    z[6,7,3]  R2453     -0.281643271446228
    z[6,7,3]  R2454     -7.8988246619701385e-02
    z[6,7,3]  R2455     4.7597393393516541e-02
    z[6,7,3]  R2456     1.9389341771602631e-01
    z[6,7,3]  R2457     1.1428778618574142e-01
    z[6,7,3]  R2458     -1.1311163753271103e-01
    z[6,7,3]  R2459     3.5076647996902466e-01
    z[6,7,3]  R2460     -1.4811113476753235e-01
    z[6,7,3]  R2461     -2.1685248613357544e-01
    z[6,7,3]  R2462     -5.2622330188751221e-01
    z[6,7,3]  R2463     -0.601436972618103
    z[6,7,3]  R2464     -2.1034187078475952e-01
    z[6,7,3]  R2465     -4.0511410683393478e-02
    z[6,7,3]  R2466     -1.0791692882776260e-01
    z[6,7,3]  R2467     -3.0945903062820435e-01
    z[6,7,3]  R2468     -1.8360719084739685e-01
    z[6,7,3]  R2469     8.8795781135559082e-02
    z[6,7,3]  R2470     -2.0583640038967133e-01
    z[6,7,3]  R2471     -3.7144848704338074e-01
    z[6,7,3]  R2472     -4.6119505167007446e-01
    z[6,7,3]  R2473     -4.9894705414772034e-01
    z[6,7,3]  R2474     4.6441480517387390e-02
    z[6,7,3]  R2475     2.1715940535068512e-01
    z[6,7,3]  R2476     1.5470547974109650e-01
    z[6,7,3]  R2477     -1.3947484083473682e-02
    z[6,7,3]  R2478     -4.6483775973320007e-01
    z[6,7,3]  R2479     1.0029217600822449e-01
    z[6,7,3]  R2480     2.2487128153443336e-02
    z[6,7,3]  R2481     1.1945168487727642e-02
    z[6,7,3]  R2482     -7.1909226477146149e-02
    z[6,7,3]  R2483     0.0812668427824974
    z[6,7,3]  R2484     2.6185283064842224e-01
    z[6,7,3]  R2485     1.2367559969425201e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2382     -1
    z[6,7,4]  R2383     1
    z[6,7,4]  R2388     -3.6935889720916748e-01
    z[6,7,4]  R2389     -4.3102037906646729e-01
    z[6,7,4]  R2390     -0.0522281676530838
    z[6,7,4]  R2391     1.3389755785465240e-01
    z[6,7,4]  R2392     3.5002410411834717e-01
    z[6,7,4]  R2393     -3.5380309820175171e-01
    z[6,7,4]  R2394     2.3240806162357330e-01
    z[6,7,4]  R2395     1.6689166426658630e-01
    z[6,7,4]  R2396     -7.7786058187484741e-01
    z[6,7,4]  R2397     1.5104007720947266e-01
    z[6,7,4]  R2398     2.6192682981491089e-01
    z[6,7,4]  R2399     1.8555636703968048e-01
    z[6,7,4]  R2400     -1.4745970070362091e-01
    z[6,7,4]  R2401     -2.2623822093009949e-01
    z[6,7,4]  R2402     -3.6451452970504761e-01
    z[6,7,4]  R2403     -1.0220992378890514e-02
    z[6,7,4]  R2404     -4.1237783432006836e-01
    z[6,7,4]  R2405     -2.7822852134704590e-01
    z[6,7,4]  R2406     -0.0856996551156044
    z[6,7,4]  R2407     3.4416213631629944e-02
    z[6,7,4]  R2408     -1.8395955860614777e-01
    z[6,7,4]  R2409     -1.9225528836250305e-01
    z[6,7,4]  R2410     -2.4892230331897736e-01
    z[6,7,4]  R2411     -3.6046814918518066e-01
    z[6,7,4]  R2412     -2.4335388839244843e-01
    z[6,7,4]  R2413     -7.2335690259933472e-02
    z[6,7,4]  R2414     1.1693262308835983e-01
    z[6,7,4]  R2415     -3.5507228970527649e-01
    z[6,7,4]  R2416     2.4996544420719147e-01
    z[6,7,4]  R2417     -4.8424351960420609e-02
    z[6,7,4]  R2418     -1.8865896761417389e-01
    z[6,7,4]  R2419     -3.0305463075637817e-01
    z[6,7,4]  R2420     -3.8017854094505310e-01
    z[6,7,4]  R2421     -4.1649696230888367e-01
    z[6,7,4]  R2422     -3.3740437030792236e-01
    z[6,7,4]  R2423     -2.9558593034744263e-01
    z[6,7,4]  R2424     -4.2544689774513245e-01
    z[6,7,4]  R2425     -1.5303482115268707e-01
    z[6,7,4]  R2426     -1.2073575705289841e-01
    z[6,7,4]  R2427     2.4712586402893066e-01
    z[6,7,4]  R2428     -2.2771361470222473e-01
    z[6,7,4]  R2429     -1.0204493999481201e-01
    z[6,7,4]  R2430     -4.4191029667854309e-01
    z[6,7,4]  R2431     -2.8548830747604370e-01
    z[6,7,4]  R2432     -4.4406521320343018e-01
    z[6,7,4]  R2433     2.1089971065521240e-01
    z[6,7,4]  R2434     -2.5434973835945129e-01
    z[6,7,4]  R2435     2.2958418726921082e-01
    z[6,7,4]  R2436     3.7069392204284668e-01
    z[6,7,4]  R2437     6.0400164127349854e-01
    z[6,7,4]  R2438     8.8644232600927353e-03
    z[6,7,4]  R2439     -7.4927335977554321e-01
    z[6,7,4]  R2440     3.0625921487808228e-01
    z[6,7,4]  R2441     4.1801303625106812e-01
    z[6,7,4]  R2442     4.5305993407964706e-02
    z[6,7,4]  R2443     3.3342137932777405e-01
    z[6,7,4]  R2444     3.5434964299201965e-01
    z[6,7,4]  R2445     1.5261656045913696e-01
    z[6,7,4]  R2446     1.4550904929637909e-01
    z[6,7,4]  R2447     2.9470531269907951e-02
    z[6,7,4]  R2448     1.7993970215320587e-01
    z[6,7,4]  R2449     5.4295492172241211e-01
    z[6,7,4]  R2450     4.2266571521759033e-01
    z[6,7,4]  R2451     2.8647667169570923e-01
    z[6,7,4]  R2452     9.8350614309310913e-02
    z[6,7,4]  R2453     -1.2155766040086746e-01
    z[6,7,4]  R2454     -2.1807126700878143e-01
    z[6,7,4]  R2455     -2.1742375195026398e-01
    z[6,7,4]  R2456     2.4495452642440796e-02
    z[6,7,4]  R2457     2.3121271282434464e-02
    z[6,7,4]  R2458     2.9923591017723083e-01
    z[6,7,4]  R2459     -1.8949364125728607e-01
    z[6,7,4]  R2460     -4.7363974153995514e-02
    z[6,7,4]  R2461     -2.7551156282424927e-01
    z[6,7,4]  R2462     -1.0807744413614273e-01
    z[6,7,4]  R2463     1.7851382493972778e-01
    z[6,7,4]  R2464     3.9771068841218948e-02
    z[6,7,4]  R2465     3.1845200806856155e-02
    z[6,7,4]  R2466     4.0859386324882507e-02
    z[6,7,4]  R2467     -2.5370957329869270e-02
    z[6,7,4]  R2468     3.1123542785644531e-01
    z[6,7,4]  R2469     8.4523171186447144e-02
    z[6,7,4]  R2470     -2.2215750813484192e-01
    z[6,7,4]  R2471     -1.1565688252449036e-01
    z[6,7,4]  R2472     -2.1413847804069519e-01
    z[6,7,4]  R2473     -1.1905162781476974e-01
    z[6,7,4]  R2474     -1.2807485461235046e-01
    z[6,7,4]  R2475     -7.5445085763931274e-02
    z[6,7,4]  R2476     1.1469919234514236e-01
    z[6,7,4]  R2477     -2.8472345322370529e-02
    z[6,7,4]  R2478     -1.2392916530370712e-01
    z[6,7,4]  R2479     -1.2288790196180344e-01
    z[6,7,4]  R2480     -2.4419040977954865e-01
    z[6,7,4]  R2481     6.0966327786445618e-02
    z[6,7,4]  R2482     -1.7420934140682220e-01
    z[6,7,4]  R2483     1.3803136348724365e-01
    z[6,7,4]  R2484     1.7871741950511932e-01
    z[6,7,4]  R2485     -4.2788442224264145e-03
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2384     -1
    z[6,7,5]  R2385     1
    z[6,7,5]  R2388     -1.3205623626708984e-01
    z[6,7,5]  R2389     2.3775672540068626e-02
    z[6,7,5]  R2390     -2.3560172319412231e-01
    z[6,7,5]  R2391     -2.4947191774845123e-01
    z[6,7,5]  R2392     -2.1468194201588631e-02
    z[6,7,5]  R2393     -3.0987852811813354e-01
    z[6,7,5]  R2394     1.9926816225051880e-01
    z[6,7,5]  R2395     2.4895383417606354e-01
    z[6,7,5]  R2396     -2.3796521127223969e-01
    z[6,7,5]  R2397     1.6448259353637695e-01
    z[6,7,5]  R2398     -8.3478963375091553e-01
    z[6,7,5]  R2399     -5.4874008893966675e-01
    z[6,7,5]  R2400     -2.7937579154968262e-01
    z[6,7,5]  R2401     1.6618889570236206e-01
    z[6,7,5]  R2402     -2.8234788775444031e-01
    z[6,7,5]  R2403     -3.3864060044288635e-01
    z[6,7,5]  R2404     -1.9196757674217224e-01
    z[6,7,5]  R2405     -2.1979844197630882e-02
    z[6,7,5]  R2406     -8.6034417152404785e-02
    z[6,7,5]  R2407     -6.9077193737030029e-02
    z[6,7,5]  R2408     -4.2867638170719147e-02
    z[6,7,5]  R2409     -0.271806925535202
    z[6,7,5]  R2410     -8.6144261062145233e-02
    z[6,7,5]  R2411     -3.9314371347427368e-01
    z[6,7,5]  R2412     1.2027243524789810e-01
    z[6,7,5]  R2413     7.5420483946800232e-02
    z[6,7,5]  R2414     1.8396285176277161e-01
    z[6,7,5]  R2415     4.9101737141609192e-01
    z[6,7,5]  R2416     -8.1900522112846375e-02
    z[6,7,5]  R2417     -1.1446280032396317e-01
    z[6,7,5]  R2418     7.4930049479007721e-02
    z[6,7,5]  R2419     -0.532384991645813
    z[6,7,5]  R2420     4.9820342659950256e-01
    z[6,7,5]  R2421     0.0839017704129219
    z[6,7,5]  R2422     -1.7509314417839050e-01
    z[6,7,5]  R2423     -2.3635946214199066e-01
    z[6,7,5]  R2424     -4.0245339274406433e-01
    z[6,7,5]  R2425     -1.5049065649509430e-01
    z[6,7,5]  R2426     -4.7530877590179443e-01
    z[6,7,5]  R2427     -1.7866681516170502e-01
    z[6,7,5]  R2428     -4.0760576725006104e-01
    z[6,7,5]  R2429     -2.7285388112068176e-01
    z[6,7,5]  R2430     -9.9871069192886353e-02
    z[6,7,5]  R2431     -2.8446984291076660e-01
    z[6,7,5]  R2432     5.5914241075515747e-01
    z[6,7,5]  R2433     2.0898316800594330e-01
    z[6,7,5]  R2434     -8.0084212124347687e-02
    z[6,7,5]  R2435     4.5964911580085754e-01
    z[6,7,5]  R2436     1.5262268483638763e-01
    z[6,7,5]  R2437     1.8325030803680420e-01
    z[6,7,5]  R2438     -6.2138122320175171e-01
    z[6,7,5]  R2439     1.3722437620162964e-01
    z[6,7,5]  R2440     1.7871128022670746e-01
    z[6,7,5]  R2441     2.1962702274322510e-01
    z[6,7,5]  R2442     5.2759596146643162e-03
    z[6,7,5]  R2443     2.7486076951026917e-01
    z[6,7,5]  R2444     2.4957705289125443e-02
    z[6,7,5]  R2445     -8.1500142812728882e-02
    z[6,7,5]  R2446     7.4070468544960022e-02
    z[6,7,5]  R2447     -2.0552995800971985e-01
    z[6,7,5]  R2448     4.1484162211418152e-01
    z[6,7,5]  R2449     -2.8942570090293884e-01
    z[6,7,5]  R2450     2.4505026638507843e-01
    z[6,7,5]  R2451     1.3290172815322876e-01
    z[6,7,5]  R2452     5.2438437938690186e-02
    z[6,7,5]  R2453     8.0746538937091827e-02
    z[6,7,5]  R2454     -1.1259089224040508e-02
    z[6,7,5]  R2455     -7.2387181222438812e-02
    z[6,7,5]  R2456     1.3499653339385986e-01
    z[6,7,5]  R2457     -2.3663581907749176e-01
    z[6,7,5]  R2458     2.1238164603710175e-01
    z[6,7,5]  R2459     2.7529197931289673e-01
    z[6,7,5]  R2460     -1.4961116015911102e-01
    z[6,7,5]  R2461     1.3873705267906189e-01
    z[6,7,5]  R2462     -1.8647591769695282e-01
    z[6,7,5]  R2463     3.6305510997772217e-01
    z[6,7,5]  R2464     5.6647438555955887e-02
    z[6,7,5]  R2465     1.0170963592827320e-02
    z[6,7,5]  R2466     -6.4028322696685791e-02
    z[6,7,5]  R2467     7.0482172071933746e-02
    z[6,7,5]  R2468     4.5426121354103088e-01
    z[6,7,5]  R2469     -6.1268504709005356e-02
    z[6,7,5]  R2470     1.4932899177074432e-01
    z[6,7,5]  R2471     -1.9573417305946350e-01
    z[6,7,5]  R2472     -5.0818540155887604e-02
    z[6,7,5]  R2473     -1.3272718526422977e-02
    z[6,7,5]  R2474     2.1538591384887695e-01
    z[6,7,5]  R2475     -8.4063664078712463e-02
    z[6,7,5]  R2476     -1.2831097841262817e-01
    z[6,7,5]  R2477     6.4674086868762970e-02
    z[6,7,5]  R2478     -6.3964784145355225e-02
    z[6,7,5]  R2479     0.134669229388237
    z[6,7,5]  R2480     -3.4824132919311523e-02
    z[6,7,5]  R2481     -3.3306530117988586e-01
    z[6,7,5]  R2482     -2.8563922271132469e-02
    z[6,7,5]  R2483     -1.3166102766990662e-01
    z[6,7,5]  R2484     1.2270816601812840e-02
    z[6,7,5]  R2485     -2.6073870062828064e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2386     -1
    z[6,7,6]  R2387     1
    z[6,7,6]  R2388     -3.9352121949195862e-01
    z[6,7,6]  R2389     0.397322416305542
    z[6,7,6]  R2390     6.4916145801544189e-01
    z[6,7,6]  R2391     1.3663363456726074e-01
    z[6,7,6]  R2392     1.1498459428548813e-01
    z[6,7,6]  R2393     2.0553120970726013e-01
    z[6,7,6]  R2394     2.8817737102508545e-01
    z[6,7,6]  R2395     -3.0668967962265015e-01
    z[6,7,6]  R2396     -0.300184428691864
    z[6,7,6]  R2397     -5.5269223451614380e-01
    z[6,7,6]  R2398     5.0016533583402634e-02
    z[6,7,6]  R2399     -4.7827857732772827e-01
    z[6,7,6]  R2400     -2.7828231453895569e-02
    z[6,7,6]  R2401     1.3620495796203613e-02
    z[6,7,6]  R2402     5.1132321357727051e-02
    z[6,7,6]  R2403     3.1818398833274841e-01
    z[6,7,6]  R2404     -8.1356592476367950e-02
    z[6,7,6]  R2405     2.5460091233253479e-01
    z[6,7,6]  R2406     -1.0346055030822754e-02
    z[6,7,6]  R2407     -2.9780656099319458e-01
    z[6,7,6]  R2408     2.6816916465759277e-01
    z[6,7,6]  R2409     -2.3238374292850494e-01
    z[6,7,6]  R2410     -1.3719917833805084e-01
    z[6,7,6]  R2411     1.9939646124839783e-01
    z[6,7,6]  R2412     -2.9235085844993591e-01
    z[6,7,6]  R2413     4.3229696154594421e-01
    z[6,7,6]  R2414     1.7052348703145981e-02
    z[6,7,6]  R2415     -3.6040824651718140e-01
    z[6,7,6]  R2416     5.1182365417480469e-01
    z[6,7,6]  R2417     0.343861848115921
    z[6,7,6]  R2418     -0.0243021659553051
    z[6,7,6]  R2419     -1.8595525622367859e-01
    z[6,7,6]  R2420     -4.3452523648738861e-02
    z[6,7,6]  R2421     -2.2632901370525360e-01
    z[6,7,6]  R2422     1.7174807190895081e-01
    z[6,7,6]  R2423     0.0263583455234766
    z[6,7,6]  R2424     2.5093618035316467e-01
    z[6,7,6]  R2425     -2.2811074554920197e-01
    z[6,7,6]  R2426     -7.6790824532508850e-02
    z[6,7,6]  R2427     4.0540233254432678e-01
    z[6,7,6]  R2428     2.2860527038574219e-01
    z[6,7,6]  R2429     -1.0897362232208252e-01
    z[6,7,6]  R2430     -7.8589171171188354e-02
    z[6,7,6]  R2431     -1.7819654941558838e-01
    z[6,7,6]  R2432     -1.2982444465160370e-01
    z[6,7,6]  R2433     1.3908928632736206e-01
    z[6,7,6]  R2434     2.1789376437664032e-01
    z[6,7,6]  R2435     1.9258503615856171e-01
    z[6,7,6]  R2436     1.3709321618080139e-01
    z[6,7,6]  R2437     -1.3313873112201691e-01
    z[6,7,6]  R2438     -2.2001625970005989e-02
    z[6,7,6]  R2439     -1.4025479555130005e-01
    z[6,7,6]  R2440     -4.2123657464981079e-01
    z[6,7,6]  R2441     6.8454399704933167e-02
    z[6,7,6]  R2442     -3.1226837635040283e-01
    z[6,7,6]  R2443     -1.2739579379558563e-01
    z[6,7,6]  R2444     1.4769941568374634e-01
    z[6,7,6]  R2445     2.8385478258132935e-01
    z[6,7,6]  R2446     4.3280860781669617e-01
    z[6,7,6]  R2447     2.1668995916843414e-01
    z[6,7,6]  R2448     7.4218285083770752e-01
    z[6,7,6]  R2449     -1.2182947993278503e-01
    z[6,7,6]  R2450     -6.0345727205276489e-01
    z[6,7,6]  R2451     -5.4205697774887085e-01
    z[6,7,6]  R2452     0.033658467233181
    z[6,7,6]  R2453     -2.6731219887733459e-01
    z[6,7,6]  R2454     -2.0208215713500977e-01
    z[6,7,6]  R2455     -1.0157459974288940e-01
    z[6,7,6]  R2456     -4.7281436622142792e-02
    z[6,7,6]  R2457     -1.6950058937072754e-01
    z[6,7,6]  R2458     9.0195411443710327e-01
    z[6,7,6]  R2459     -4.0996733307838440e-01
    z[6,7,6]  R2460     -1.0453238338232040e-01
    z[6,7,6]  R2461     1.4032112061977386e-01
    z[6,7,6]  R2462     8.9378423988819122e-02
    z[6,7,6]  R2463     -4.7050941735506058e-02
    z[6,7,6]  R2464     -6.8094715476036072e-02
    z[6,7,6]  R2465     4.2048010975122452e-02
    z[6,7,6]  R2466     -1.5103930234909058e-01
    z[6,7,6]  R2467     1.2314311414957047e-01
    z[6,7,6]  R2468     -2.3049747943878174e-01
    z[6,7,6]  R2469     -9.4908557832241058e-02
    z[6,7,6]  R2470     1.7707893252372742e-01
    z[6,7,6]  R2471     1.1500716954469681e-01
    z[6,7,6]  R2472     3.9514914155006409e-02
    z[6,7,6]  R2473     1.6049657762050629e-01
    z[6,7,6]  R2474     2.2440391778945923e-01
    z[6,7,6]  R2475     2.7134805917739868e-01
    z[6,7,6]  R2476     -6.3286080956459045e-02
    z[6,7,6]  R2477     -1.9872419536113739e-01
    z[6,7,6]  R2478     7.4325375258922577e-02
    z[6,7,6]  R2479     -3.8274798542261124e-02
    z[6,7,6]  R2480     2.7283474802970886e-01
    z[6,7,6]  R2481     2.6236274838447571e-01
    z[6,7,6]  R2482     0.0755741223692894
    z[6,7,6]  R2483     2.0593929290771484e-01
    z[6,7,6]  R2484     4.1099201887845993e-02
    z[6,7,6]  R2485     1.0437231510877609e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2486     -1
    z[7,6,0]  R2487     1
    z[7,6,0]  R2500     -5.9910756535828114e-03
    z[7,6,0]  R2501     1.3063609600067139e-02
    z[7,6,0]  R2502     -8.1645393371582031e-01
    z[7,6,0]  R2503     1.2668228149414062e-01
    z[7,6,0]  R2504     6.4930331707000732e-01
    z[7,6,0]  R2505     6.6607165336608887e-01
    z[7,6,0]  R2506     4.8031106591224670e-01
    z[7,6,0]  R2507     7.8610196709632874e-02
    z[7,6,0]  R2508     6.0148149728775024e-01
    z[7,6,0]  R2509     7.0729398727416992e-01
    z[7,6,0]  R2510     3.1340315937995911e-01
    z[7,6,0]  R2511     4.8671886324882507e-01
    z[7,6,0]  R2512     6.2293016910552979e-01
    z[7,6,0]  R2513     5.7283890247344971e-01
    z[7,6,0]  R2514     -1.7958205193281174e-02
    z[7,6,0]  R2515     1.1035569012165070e-02
    z[7,6,0]  R2516     5.6998640298843384e-02
    z[7,6,0]  R2517     -1.9504573196172714e-02
    z[7,6,0]  R2518     -1.9807815551757812e-02
    z[7,6,0]  R2519     -1.6340428963303566e-02
    z[7,6,0]  R2520     5.3168445825576782e-02
    z[7,6,0]  R2521     0.707912266254425
    z[7,6,0]  R2522     -3.0555235221982002e-02
    z[7,6,0]  R2523     3.5212565213441849e-02
    z[7,6,0]  R2524     1.8329776823520660e-02
    z[7,6,0]  R2525     1.8452009558677673e-01
    z[7,6,0]  R2526     0.563755989074707
    z[7,6,0]  R2527     6.3438493013381958e-01
    z[7,6,0]  R2528     5.1289850473403931e-01
    z[7,6,0]  R2529     5.3781211376190186e-01
    z[7,6,0]  R2530     3.1111446022987366e-01
    z[7,6,0]  R2531     -2.7675172314047813e-02
    z[7,6,0]  R2532     0.0125663997605443
    z[7,6,0]  R2533     1.7356218770146370e-02
    z[7,6,0]  R2534     -4.0727756917476654e-02
    z[7,6,0]  R2535     -1.8608981743454933e-02
    z[7,6,0]  R2536     -1.7569025978446007e-02
    z[7,6,0]  R2537     -1.0819350183010101e-01
    z[7,6,0]  R2538     4.4395062327384949e-01
    z[7,6,0]  R2539     2.8860560059547424e-01
    z[7,6,0]  R2540     5.7375203818082809e-02
    z[7,6,0]  R2541     1.2621617875993252e-02
    z[7,6,0]  R2542     2.9631700366735458e-02
    z[7,6,0]  R2543     -3.8117118179798126e-02
    z[7,6,0]  R2544     4.1012534499168396e-01
    z[7,6,0]  R2545     4.6212357282638550e-01
    z[7,6,0]  R2546     4.2580339312553406e-01
    z[7,6,0]  R2547     3.7716484069824219e-01
    z[7,6,0]  R2548     2.0031196996569633e-02
    z[7,6,0]  R2549     4.7062397003173828e-01
    z[7,6,0]  R2550     -2.0097967982292175e-01
    z[7,6,0]  R2551     5.3255504369735718e-01
    z[7,6,0]  R2552     -5.3218755871057510e-02
    z[7,6,0]  R2553     -5.1938509941101074e-01
    z[7,6,0]  R2554     7.6573394238948822e-02
    z[7,6,0]  R2555     -6.3433700799942017e-01
    z[7,6,0]  R2556     2.9662674292922020e-02
    z[7,6,0]  R2557     5.4677534103393555e-01
    z[7,6,0]  R2558     1.3562743365764618e-01
    z[7,6,0]  R2559     1.5572011470794678e-01
    z[7,6,0]  R2560     1.1420238018035889e-01
    z[7,6,0]  R2561     2.3889848962426186e-02
    z[7,6,0]  R2562     -1.5095965564250946e-01
    z[7,6,0]  R2563     -3.1263357400894165e-01
    z[7,6,0]  R2564     -2.6962655782699585e-01
    z[7,6,0]  R2565     -2.3602253198623657e-01
    z[7,6,0]  R2566     -2.9074054956436157e-01
    z[7,6,0]  R2567     -3.3436134457588196e-01
    z[7,6,0]  R2568     -1.2169932574033737e-01
    z[7,6,0]  R2569     1.3749545812606812e-01
    z[7,6,0]  R2570     -2.2975397109985352e-01
    z[7,6,0]  R2571     -3.8394263386726379e-01
    z[7,6,0]  R2572     -2.8801003098487854e-01
    z[7,6,0]  R2573     -2.5030487775802612e-01
    z[7,6,0]  R2574     5.4529821872711182e-01
    z[7,6,0]  R2575     3.7663927674293518e-01
    z[7,6,0]  R2576     -2.1984383463859558e-01
    z[7,6,0]  R2577     -6.0424816608428955e-01
    z[7,6,0]  R2578     3.0019545927643776e-02
    z[7,6,0]  R2579     -1.9691903889179230e-01
    z[7,6,0]  R2580     7.2666600346565247e-02
    z[7,6,0]  R2581     -1.9034427404403687e-01
    z[7,6,0]  R2582     1.2171491980552673e-01
    z[7,6,0]  R2583     -0.00383838452398777
    z[7,6,0]  R2584     -0.226633220911026
    z[7,6,0]  R2585     -4.5925104618072510e-01
    z[7,6,0]  R2586     -4.1722607612609863e-01
    z[7,6,0]  R2587     -2.6629993319511414e-01
    z[7,6,0]  R2588     -2.9132384061813354e-01
    z[7,6,0]  R2589     -3.7018135190010071e-01
    z[7,6,0]  R2590     1.9356849789619446e-01
    z[7,6,0]  R2591     -3.1235665082931519e-01
    z[7,6,0]  R2592     3.4809085726737976e-01
    z[7,6,0]  R2593     5.3691053390502930e-01
    z[7,6,0]  R2594     -4.8993730545043945e-01
    z[7,6,0]  R2595     5.6050747632980347e-01
    z[7,6,0]  R2596     -8.0752231180667877e-02
    z[7,6,0]  R2597     -4.3593738228082657e-02
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2488     -1
    z[7,6,1]  R2489     1
    z[7,6,1]  R2500     -4.2655521631240845e-01
    z[7,6,1]  R2501     -2.8006985783576965e-01
    z[7,6,1]  R2502     -1.3057418167591095e-01
    z[7,6,1]  R2503     8.6231559514999390e-01
    z[7,6,1]  R2504     6.7569863796234131e-01
    z[7,6,1]  R2505     1.4423798024654388e-01
    z[7,6,1]  R2506     7.6201355457305908e-01
    z[7,6,1]  R2507     8.3235615491867065e-01
    z[7,6,1]  R2508     6.3679379224777222e-01
    z[7,6,1]  R2509     5.1596456766128540e-01
    z[7,6,1]  R2510     -3.4337392449378967e-01
    z[7,6,1]  R2511     5.2500668913125992e-02
    z[7,6,1]  R2512     -3.8583520799875259e-02
    z[7,6,1]  R2513     -3.3465981483459473e-01
    z[7,6,1]  R2514     9.7293472290039062e-01
    z[7,6,1]  R2515     9.0512287616729736e-01
    z[7,6,1]  R2516     9.4747757911682129e-01
    z[7,6,1]  R2517     9.5006054639816284e-01
    z[7,6,1]  R2518     0.967280924320221
    z[7,6,1]  R2519     9.4922721385955811e-01
    z[7,6,1]  R2520     -1.7480291426181793e-01
    z[7,6,1]  R2521     1.3711860775947571e-01
    z[7,6,1]  R2522     9.6915805339813232e-01
    z[7,6,1]  R2523     9.1265428066253662e-01
    z[7,6,1]  R2524     8.1704908609390259e-01
    z[7,6,1]  R2525     5.7714241743087769e-01
    z[7,6,1]  R2526     7.2377204895019531e-01
    z[7,6,1]  R2527     7.5220936536788940e-01
    z[7,6,1]  R2528     7.6439785957336426e-01
    z[7,6,1]  R2529     7.2237241268157959e-01
    z[7,6,1]  R2530     5.4793828725814819e-01
    z[7,6,1]  R2531     9.8418653011322021e-01
    z[7,6,1]  R2532     9.2435592412948608e-01
    z[7,6,1]  R2533     8.8267183303833008e-01
    z[7,6,1]  R2534     8.5710215568542480e-01
    z[7,6,1]  R2535     0.840378999710083
    z[7,6,1]  R2536     9.3658220767974854e-01
    z[7,6,1]  R2537     9.1933250427246094e-01
    z[7,6,1]  R2538     8.5234391689300537e-01
    z[7,6,1]  R2539     -2.7679893374443054e-01
    z[7,6,1]  R2540     8.6908000707626343e-01
    z[7,6,1]  R2541     9.6912008523941040e-01
    z[7,6,1]  R2542     9.0541845560073853e-01
    z[7,6,1]  R2543     0.900120735168457
    z[7,6,1]  R2544     0.884118378162384
    z[7,6,1]  R2545     8.3616447448730469e-01
    z[7,6,1]  R2546     8.4244924783706665e-01
    z[7,6,1]  R2547     8.7358832359313965e-01
    z[7,6,1]  R2548     -7.8190410137176514e-01
    z[7,6,1]  R2549     -3.6997714638710022e-01
    z[7,6,1]  R2550     -6.0399180650711060e-01
    z[7,6,1]  R2551     -4.4579467177391052e-01
    z[7,6,1]  R2552     -8.2918137311935425e-01
    z[7,6,1]  R2553     -6.4737731218338013e-01
    z[7,6,1]  R2554     -2.8673955798149109e-01
    z[7,6,1]  R2555     -5.9463238716125488e-01
    z[7,6,1]  R2556     -4.4625002145767212e-01
    z[7,6,1]  R2557     -3.0965870618820190e-01
    z[7,6,1]  R2558     4.0525174140930176e-01
    z[7,6,1]  R2559     2.8946825861930847e-01
    z[7,6,1]  R2560     9.2991006374359131e-01
    z[7,6,1]  R2561     8.6411511898040771e-01
    z[7,6,1]  R2562     8.2175713777542114e-01
    z[7,6,1]  R2563     6.9736850261688232e-01
    z[7,6,1]  R2564     0.808444619178772
    z[7,6,1]  R2565     7.2943145036697388e-01
    z[7,6,1]  R2566     5.6239664554595947e-01
    z[7,6,1]  R2567     6.5161406993865967e-01
    z[7,6,1]  R2568     8.4629094600677490e-01
    z[7,6,1]  R2569     8.7107741832733154e-01
    z[7,6,1]  R2570     9.1347074508666992e-01
    z[7,6,1]  R2571     6.5538221597671509e-01
    z[7,6,1]  R2572     8.3171874284744263e-01
    z[7,6,1]  R2573     3.9090868830680847e-01
    z[7,6,1]  R2574     7.8255093097686768e-01
    z[7,6,1]  R2575     3.5327199101448059e-01
    z[7,6,1]  R2576     3.1925094127655029e-01
    z[7,6,1]  R2577     5.1732963323593140e-01
    z[7,6,1]  R2578     8.7808293104171753e-01
    z[7,6,1]  R2579     6.3551861047744751e-01
    z[7,6,1]  R2580     5.8599531650543213e-01
    z[7,6,1]  R2581     8.0284309387207031e-01
    z[7,6,1]  R2582     7.7548879384994507e-01
    z[7,6,1]  R2583     7.5157040357589722e-01
    z[7,6,1]  R2584     7.3652219772338867e-01
    z[7,6,1]  R2585     7.1352082490921021e-01
    z[7,6,1]  R2586     7.2306710481643677e-01
    z[7,6,1]  R2587     3.7456589937210083e-01
    z[7,6,1]  R2588     6.7980217933654785e-01
    z[7,6,1]  R2589     7.6989412307739258e-01
    z[7,6,1]  R2590     0.847685694694519
    z[7,6,1]  R2591     0.807413637638092
    z[7,6,1]  R2592     3.1038349866867065e-01
    z[7,6,1]  R2593     7.4890291690826416e-01
    z[7,6,1]  R2594     5.3914952278137207e-01
    z[7,6,1]  R2595     1.5823675692081451e-01
    z[7,6,1]  R2596     8.0106192827224731e-01
    z[7,6,1]  R2597     7.4141615629196167e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2490     -1
    z[7,6,2]  R2491     1
    z[7,6,2]  R2500     -1.5067394077777863e-01
    z[7,6,2]  R2501     -0.516549289226532
    z[7,6,2]  R2502     -6.6462293267250061e-02
    z[7,6,2]  R2503     1.8661996349692345e-02
    z[7,6,2]  R2504     1.3094486296176910e-01
    z[7,6,2]  R2505     -1.2780325114727020e-01
    z[7,6,2]  R2506     4.9446918070316315e-02
    z[7,6,2]  R2507     -0.163267582654953
    z[7,6,2]  R2508     -1.3015115261077881e-01
    z[7,6,2]  R2509     -0.0707424059510231
    z[7,6,2]  R2510     -0.0759369432926178
    z[7,6,2]  R2511     -4.3421775102615356e-01
    z[7,6,2]  R2512     -8.3179615437984467e-02
    z[7,6,2]  R2513     2.1237170696258545e-01
    z[7,6,2]  R2514     -0.0409720353782177
    z[7,6,2]  R2515     -9.2496760189533234e-02
    z[7,6,2]  R2516     -0.0654149055480957
    z[7,6,2]  R2517     -1.7862991988658905e-01
    z[7,6,2]  R2518     -0.072944276034832
    z[7,6,2]  R2519     -1.9429367035627365e-02
    z[7,6,2]  R2520     -7.5190417468547821e-02
    z[7,6,2]  R2521     2.7794721722602844e-01
    z[7,6,2]  R2522     0.0480441153049469
    z[7,6,2]  R2523     6.2870495021343231e-02
    z[7,6,2]  R2524     -2.7227871119976044e-02
    z[7,6,2]  R2525     3.2441091537475586e-01
    z[7,6,2]  R2526     3.2351487874984741e-01
    z[7,6,2]  R2527     1.6495469212532043e-01
    z[7,6,2]  R2528     3.3526563644409180e-01
    z[7,6,2]  R2529     0.269064724445343
    z[7,6,2]  R2530     -4.6142172813415527e-01
    z[7,6,2]  R2531     -5.3108941763639450e-02
    z[7,6,2]  R2532     5.4428409785032272e-03
    z[7,6,2]  R2533     -1.3304175436496735e-01
    z[7,6,2]  R2534     3.1891215592622757e-02
    z[7,6,2]  R2535     -6.6032111644744873e-02
    z[7,6,2]  R2536     -8.4833957254886627e-02
    z[7,6,2]  R2537     -9.7852818667888641e-02
    z[7,6,2]  R2538     -1.3732887804508209e-01
    z[7,6,2]  R2539     8.9185750484466553e-01
    z[7,6,2]  R2540     -1.8962593749165535e-02
    z[7,6,2]  R2541     -1.2604096531867981e-01
    z[7,6,2]  R2542     -2.0869433879852295e-01
    z[7,6,2]  R2543     6.8582065403461456e-02
    z[7,6,2]  R2544     8.9915379881858826e-02
    z[7,6,2]  R2545     -4.3222531676292419e-02
    z[7,6,2]  R2546     8.1388704478740692e-02
    z[7,6,2]  R2547     1.9947733730077744e-02
    z[7,6,2]  R2548     -1.3319614529609680e-01
    z[7,6,2]  R2549     -3.3799886703491211e-01
    z[7,6,2]  R2550     -2.8119698166847229e-01
    z[7,6,2]  R2551     -6.3282884657382965e-03
    z[7,6,2]  R2552     -4.1510784626007080e-01
    z[7,6,2]  R2553     -2.1796886622905731e-01
    z[7,6,2]  R2554     -3.6379560828208923e-02
    z[7,6,2]  R2555     3.6675009876489639e-02
    z[7,6,2]  R2556     -1.8968142569065094e-01
    z[7,6,2]  R2557     -1.4247059822082520e-01
    z[7,6,2]  R2558     -1.2563848495483398e-01
    z[7,6,2]  R2559     -9.7060143947601318e-02
    z[7,6,2]  R2560     -2.1673109382390976e-02
    z[7,6,2]  R2561     -4.1682547330856323e-01
    z[7,6,2]  R2562     -1.6679960489273071e-01
    z[7,6,2]  R2563     -0.431225061416626
    z[7,6,2]  R2564     0.111131452023983
    z[7,6,2]  R2565     -4.5923840999603271e-01
    z[7,6,2]  R2566     -7.5315505266189575e-01
    z[7,6,2]  R2567     -5.0678777694702148e-01
    z[7,6,2]  R2568     -2.5695204734802246e-01
    z[7,6,2]  R2569     -2.2990810871124268e-01
    z[7,6,2]  R2570     -9.1658405959606171e-02
    z[7,6,2]  R2571     5.6675948202610016e-02
    z[7,6,2]  R2572     -5.0259608775377274e-02
    z[7,6,2]  R2573     1.0611893236637115e-01
    z[7,6,2]  R2574     1.9353662431240082e-01
    z[7,6,2]  R2575     1.5623576939105988e-01
    z[7,6,2]  R2576     7.5560994446277618e-04
    z[7,6,2]  R2577     3.2969883084297180e-01
    z[7,6,2]  R2578     -4.0979039669036865e-01
    z[7,6,2]  R2579     2.3030509054660797e-01
    z[7,6,2]  R2580     4.4043174386024475e-01
    z[7,6,2]  R2581     -2.1861056983470917e-01
    z[7,6,2]  R2582     -3.9543649554252625e-01
    z[7,6,2]  R2583     -4.8836305737495422e-01
    z[7,6,2]  R2584     -1.5879217535257339e-03
    z[7,6,2]  R2585     -2.4725767970085144e-01
    z[7,6,2]  R2586     -1.1703561991453171e-01
    z[7,6,2]  R2587     0.0369969867169857
    z[7,6,2]  R2588     -3.4943285584449768e-01
    z[7,6,2]  R2589     -2.9353508353233337e-01
    z[7,6,2]  R2590     -7.9275742173194885e-03
    z[7,6,2]  R2591     -2.2706474363803864e-01
    z[7,6,2]  R2592     1.2162059545516968e-01
    z[7,6,2]  R2593     1.8791253864765167e-01
    z[7,6,2]  R2594     3.1081789731979370e-01
    z[7,6,2]  R2595     -1.5064038336277008e-01
    z[7,6,2]  R2596     4.1153150796890259e-01
    z[7,6,2]  R2597     1.6199788451194763e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2492     -1
    z[7,6,3]  R2493     1
    z[7,6,3]  R2500     6.3924556970596313e-01
    z[7,6,3]  R2501     -2.3378323018550873e-01
    z[7,6,3]  R2502     -9.3613415956497192e-02
    z[7,6,3]  R2503     1.1116736382246017e-01
    z[7,6,3]  R2504     -7.1401178836822510e-02
    z[7,6,3]  R2505     -0.562372088432312
    z[7,6,3]  R2506     -1.9542230665683746e-01
    z[7,6,3]  R2507     -4.0477123856544495e-01
    z[7,6,3]  R2508     4.2328916490077972e-02
    z[7,6,3]  R2509     -3.7208297848701477e-01
    z[7,6,3]  R2510     1.5099371969699860e-01
    z[7,6,3]  R2511     -4.2236658930778503e-01
    z[7,6,3]  R2512     -2.6341335847973824e-02
    z[7,6,3]  R2513     -3.4813681244850159e-01
    z[7,6,3]  R2514     -1.9452878832817078e-01
    z[7,6,3]  R2515     -0.281643271446228
    z[7,6,3]  R2516     -7.8988246619701385e-02
    z[7,6,3]  R2517     4.7597393393516541e-02
    z[7,6,3]  R2518     1.9389341771602631e-01
    z[7,6,3]  R2519     1.1428778618574142e-01
    z[7,6,3]  R2520     -1.1311163753271103e-01
    z[7,6,3]  R2521     3.5076647996902466e-01
    z[7,6,3]  R2522     -1.4811113476753235e-01
    z[7,6,3]  R2523     -2.1685248613357544e-01
    z[7,6,3]  R2524     -5.2622330188751221e-01
    z[7,6,3]  R2525     -0.601436972618103
    z[7,6,3]  R2526     -2.1034187078475952e-01
    z[7,6,3]  R2527     -4.0511410683393478e-02
    z[7,6,3]  R2528     -1.0791692882776260e-01
    z[7,6,3]  R2529     -3.0945903062820435e-01
    z[7,6,3]  R2530     -1.8360719084739685e-01
    z[7,6,3]  R2531     8.8795781135559082e-02
    z[7,6,3]  R2532     -2.0583640038967133e-01
    z[7,6,3]  R2533     -3.7144848704338074e-01
    z[7,6,3]  R2534     -4.6119505167007446e-01
    z[7,6,3]  R2535     -4.9894705414772034e-01
    z[7,6,3]  R2536     4.6441480517387390e-02
    z[7,6,3]  R2537     2.1715940535068512e-01
    z[7,6,3]  R2538     1.5470547974109650e-01
    z[7,6,3]  R2539     -1.3947484083473682e-02
    z[7,6,3]  R2540     -4.6483775973320007e-01
    z[7,6,3]  R2541     1.0029217600822449e-01
    z[7,6,3]  R2542     2.2487128153443336e-02
    z[7,6,3]  R2543     1.1945168487727642e-02
    z[7,6,3]  R2544     -7.1909226477146149e-02
    z[7,6,3]  R2545     0.0812668427824974
    z[7,6,3]  R2546     2.6185283064842224e-01
    z[7,6,3]  R2547     1.2367559969425201e-01
    z[7,6,3]  R2548     2.4851515889167786e-01
    z[7,6,3]  R2549     4.2799273133277893e-01
    z[7,6,3]  R2550     1.8995456397533417e-01
    z[7,6,3]  R2551     0.647131085395813
    z[7,6,3]  R2552     -3.3350121229887009e-02
    z[7,6,3]  R2553     -1.3669732958078384e-02
    z[7,6,3]  R2554     8.5663646459579468e-01
    z[7,6,3]  R2555     -2.4247553944587708e-01
    z[7,6,3]  R2556     1.1043892055749893e-01
    z[7,6,3]  R2557     4.7907626628875732e-01
    z[7,6,3]  R2558     -1.8333104252815247e-01
    z[7,6,3]  R2559     -5.6412893533706665e-01
    z[7,6,3]  R2560     1.4555303752422333e-01
    z[7,6,3]  R2561     1.7127810278907418e-03
    z[7,6,3]  R2562     -2.4269069731235504e-01
    z[7,6,3]  R2563     1.1815001815557480e-01
    z[7,6,3]  R2564     2.1872974932193756e-01
    z[7,6,3]  R2565     -2.4208946526050568e-01
    z[7,6,3]  R2566     1.3070549070835114e-01
    z[7,6,3]  R2567     3.3484759926795959e-01
    z[7,6,3]  R2568     3.0880925059318542e-01
    z[7,6,3]  R2569     6.7955709993839264e-02
    z[7,6,3]  R2570     -1.2718668580055237e-01
    z[7,6,3]  R2571     3.0917921662330627e-01
    z[7,6,3]  R2572     2.5221493840217590e-01
    z[7,6,3]  R2573     -7.5860089063644409e-01
    z[7,6,3]  R2574     -0.0707196369767189
    z[7,6,3]  R2575     -4.6028646826744080e-01
    z[7,6,3]  R2576     -7.2013401985168457e-01
    z[7,6,3]  R2577     -3.5336297750473022e-01
    z[7,6,3]  R2578     1.3543894886970520e-01
    z[7,6,3]  R2579     -3.0731633305549622e-01
    z[7,6,3]  R2580     2.5043663382530212e-01
    z[7,6,3]  R2581     1.9921740889549255e-01
    z[7,6,3]  R2582     -2.3116227984428406e-01
    z[7,6,3]  R2583     -2.2955887019634247e-01
    z[7,6,3]  R2584     -1.5074518509209156e-02
    z[7,6,3]  R2585     0.347474604845047
    z[7,6,3]  R2586     2.0738035440444946e-01
    z[7,6,3]  R2587     -0.728060245513916
    z[7,6,3]  R2588     2.4625155329704285e-01
    z[7,6,3]  R2589     2.9551351070404053e-01
    z[7,6,3]  R2590     0.180172398686409
    z[7,6,3]  R2591     -6.9118700921535492e-02
    z[7,6,3]  R2592     -4.9093249440193176e-01
    z[7,6,3]  R2593     8.9788466691970825e-02
    z[7,6,3]  R2594     -0.504069983959198
    z[7,6,3]  R2595     -5.8053833246231079e-01
    z[7,6,3]  R2596     5.4022260010242462e-02
    z[7,6,3]  R2597     7.7676810324192047e-02
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2494     -1
    z[7,6,4]  R2495     1
    z[7,6,4]  R2500     8.8644232600927353e-03
    z[7,6,4]  R2501     -7.4927335977554321e-01
    z[7,6,4]  R2502     3.0625921487808228e-01
    z[7,6,4]  R2503     4.1801303625106812e-01
    z[7,6,4]  R2504     4.5305993407964706e-02
    z[7,6,4]  R2505     3.3342137932777405e-01
    z[7,6,4]  R2506     3.5434964299201965e-01
    z[7,6,4]  R2507     1.5261656045913696e-01
    z[7,6,4]  R2508     1.4550904929637909e-01
    z[7,6,4]  R2509     2.9470531269907951e-02
    z[7,6,4]  R2510     1.7993970215320587e-01
    z[7,6,4]  R2511     5.4295492172241211e-01
    z[7,6,4]  R2512     4.2266571521759033e-01
    z[7,6,4]  R2513     2.8647667169570923e-01
    z[7,6,4]  R2514     9.8350614309310913e-02
    z[7,6,4]  R2515     -1.2155766040086746e-01
    z[7,6,4]  R2516     -2.1807126700878143e-01
    z[7,6,4]  R2517     -2.1742375195026398e-01
    z[7,6,4]  R2518     2.4495452642440796e-02
    z[7,6,4]  R2519     2.3121271282434464e-02
    z[7,6,4]  R2520     2.9923591017723083e-01
    z[7,6,4]  R2521     -1.8949364125728607e-01
    z[7,6,4]  R2522     -4.7363974153995514e-02
    z[7,6,4]  R2523     -2.7551156282424927e-01
    z[7,6,4]  R2524     -1.0807744413614273e-01
    z[7,6,4]  R2525     1.7851382493972778e-01
    z[7,6,4]  R2526     3.9771068841218948e-02
    z[7,6,4]  R2527     3.1845200806856155e-02
    z[7,6,4]  R2528     4.0859386324882507e-02
    z[7,6,4]  R2529     -2.5370957329869270e-02
    z[7,6,4]  R2530     3.1123542785644531e-01
    z[7,6,4]  R2531     8.4523171186447144e-02
    z[7,6,4]  R2532     -2.2215750813484192e-01
    z[7,6,4]  R2533     -1.1565688252449036e-01
    z[7,6,4]  R2534     -2.1413847804069519e-01
    z[7,6,4]  R2535     -1.1905162781476974e-01
    z[7,6,4]  R2536     -1.2807485461235046e-01
    z[7,6,4]  R2537     -7.5445085763931274e-02
    z[7,6,4]  R2538     1.1469919234514236e-01
    z[7,6,4]  R2539     -2.8472345322370529e-02
    z[7,6,4]  R2540     -1.2392916530370712e-01
    z[7,6,4]  R2541     -1.2288790196180344e-01
    z[7,6,4]  R2542     -2.4419040977954865e-01
    z[7,6,4]  R2543     6.0966327786445618e-02
    z[7,6,4]  R2544     -1.7420934140682220e-01
    z[7,6,4]  R2545     1.3803136348724365e-01
    z[7,6,4]  R2546     1.7871741950511932e-01
    z[7,6,4]  R2547     -4.2788442224264145e-03
    z[7,6,4]  R2548     -3.6935889720916748e-01
    z[7,6,4]  R2549     -4.3102037906646729e-01
    z[7,6,4]  R2550     -0.0522281676530838
    z[7,6,4]  R2551     1.3389755785465240e-01
    z[7,6,4]  R2552     3.5002410411834717e-01
    z[7,6,4]  R2553     -3.5380309820175171e-01
    z[7,6,4]  R2554     2.3240806162357330e-01
    z[7,6,4]  R2555     1.6689166426658630e-01
    z[7,6,4]  R2556     -7.7786058187484741e-01
    z[7,6,4]  R2557     1.5104007720947266e-01
    z[7,6,4]  R2558     2.6192682981491089e-01
    z[7,6,4]  R2559     1.8555636703968048e-01
    z[7,6,4]  R2560     -1.4745970070362091e-01
    z[7,6,4]  R2561     -2.2623822093009949e-01
    z[7,6,4]  R2562     -3.6451452970504761e-01
    z[7,6,4]  R2563     -1.0220992378890514e-02
    z[7,6,4]  R2564     -4.1237783432006836e-01
    z[7,6,4]  R2565     -2.7822852134704590e-01
    z[7,6,4]  R2566     -0.0856996551156044
    z[7,6,4]  R2567     3.4416213631629944e-02
    z[7,6,4]  R2568     -1.8395955860614777e-01
    z[7,6,4]  R2569     -1.9225528836250305e-01
    z[7,6,4]  R2570     -2.4892230331897736e-01
    z[7,6,4]  R2571     -3.6046814918518066e-01
    z[7,6,4]  R2572     -2.4335388839244843e-01
    z[7,6,4]  R2573     -7.2335690259933472e-02
    z[7,6,4]  R2574     1.1693262308835983e-01
    z[7,6,4]  R2575     -3.5507228970527649e-01
    z[7,6,4]  R2576     2.4996544420719147e-01
    z[7,6,4]  R2577     -4.8424351960420609e-02
    z[7,6,4]  R2578     -1.8865896761417389e-01
    z[7,6,4]  R2579     -3.0305463075637817e-01
    z[7,6,4]  R2580     -3.8017854094505310e-01
    z[7,6,4]  R2581     -4.1649696230888367e-01
    z[7,6,4]  R2582     -3.3740437030792236e-01
    z[7,6,4]  R2583     -2.9558593034744263e-01
    z[7,6,4]  R2584     -4.2544689774513245e-01
    z[7,6,4]  R2585     -1.5303482115268707e-01
    z[7,6,4]  R2586     -1.2073575705289841e-01
    z[7,6,4]  R2587     2.4712586402893066e-01
    z[7,6,4]  R2588     -2.2771361470222473e-01
    z[7,6,4]  R2589     -1.0204493999481201e-01
    z[7,6,4]  R2590     -4.4191029667854309e-01
    z[7,6,4]  R2591     -2.8548830747604370e-01
    z[7,6,4]  R2592     -4.4406521320343018e-01
    z[7,6,4]  R2593     2.1089971065521240e-01
    z[7,6,4]  R2594     -2.5434973835945129e-01
    z[7,6,4]  R2595     2.2958418726921082e-01
    z[7,6,4]  R2596     3.7069392204284668e-01
    z[7,6,4]  R2597     6.0400164127349854e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2496     -1
    z[7,6,5]  R2497     1
    z[7,6,5]  R2500     -6.2138122320175171e-01
    z[7,6,5]  R2501     1.3722437620162964e-01
    z[7,6,5]  R2502     1.7871128022670746e-01
    z[7,6,5]  R2503     2.1962702274322510e-01
    z[7,6,5]  R2504     5.2759596146643162e-03
    z[7,6,5]  R2505     2.7486076951026917e-01
    z[7,6,5]  R2506     2.4957705289125443e-02
    z[7,6,5]  R2507     -8.1500142812728882e-02
    z[7,6,5]  R2508     7.4070468544960022e-02
    z[7,6,5]  R2509     -2.0552995800971985e-01
    z[7,6,5]  R2510     4.1484162211418152e-01
    z[7,6,5]  R2511     -2.8942570090293884e-01
    z[7,6,5]  R2512     2.4505026638507843e-01
    z[7,6,5]  R2513     1.3290172815322876e-01
    z[7,6,5]  R2514     5.2438437938690186e-02
    z[7,6,5]  R2515     8.0746538937091827e-02
    z[7,6,5]  R2516     -1.1259089224040508e-02
    z[7,6,5]  R2517     -7.2387181222438812e-02
    z[7,6,5]  R2518     1.3499653339385986e-01
    z[7,6,5]  R2519     -2.3663581907749176e-01
    z[7,6,5]  R2520     2.1238164603710175e-01
    z[7,6,5]  R2521     2.7529197931289673e-01
    z[7,6,5]  R2522     -1.4961116015911102e-01
    z[7,6,5]  R2523     1.3873705267906189e-01
    z[7,6,5]  R2524     -1.8647591769695282e-01
    z[7,6,5]  R2525     3.6305510997772217e-01
    z[7,6,5]  R2526     5.6647438555955887e-02
    z[7,6,5]  R2527     1.0170963592827320e-02
    z[7,6,5]  R2528     -6.4028322696685791e-02
    z[7,6,5]  R2529     7.0482172071933746e-02
    z[7,6,5]  R2530     4.5426121354103088e-01
    z[7,6,5]  R2531     -6.1268504709005356e-02
    z[7,6,5]  R2532     1.4932899177074432e-01
    z[7,6,5]  R2533     -1.9573417305946350e-01
    z[7,6,5]  R2534     -5.0818540155887604e-02
    z[7,6,5]  R2535     -1.3272718526422977e-02
    z[7,6,5]  R2536     2.1538591384887695e-01
    z[7,6,5]  R2537     -8.4063664078712463e-02
    z[7,6,5]  R2538     -1.2831097841262817e-01
    z[7,6,5]  R2539     6.4674086868762970e-02
    z[7,6,5]  R2540     -6.3964784145355225e-02
    z[7,6,5]  R2541     0.134669229388237
    z[7,6,5]  R2542     -3.4824132919311523e-02
    z[7,6,5]  R2543     -3.3306530117988586e-01
    z[7,6,5]  R2544     -2.8563922271132469e-02
    z[7,6,5]  R2545     -1.3166102766990662e-01
    z[7,6,5]  R2546     1.2270816601812840e-02
    z[7,6,5]  R2547     -2.6073870062828064e-01
    z[7,6,5]  R2548     -1.3205623626708984e-01
    z[7,6,5]  R2549     2.3775672540068626e-02
    z[7,6,5]  R2550     -2.3560172319412231e-01
    z[7,6,5]  R2551     -2.4947191774845123e-01
    z[7,6,5]  R2552     -2.1468194201588631e-02
    z[7,6,5]  R2553     -3.0987852811813354e-01
    z[7,6,5]  R2554     1.9926816225051880e-01
    z[7,6,5]  R2555     2.4895383417606354e-01
    z[7,6,5]  R2556     -2.3796521127223969e-01
    z[7,6,5]  R2557     1.6448259353637695e-01
    z[7,6,5]  R2558     -8.3478963375091553e-01
    z[7,6,5]  R2559     -5.4874008893966675e-01
    z[7,6,5]  R2560     -2.7937579154968262e-01
    z[7,6,5]  R2561     1.6618889570236206e-01
    z[7,6,5]  R2562     -2.8234788775444031e-01
    z[7,6,5]  R2563     -3.3864060044288635e-01
    z[7,6,5]  R2564     -1.9196757674217224e-01
    z[7,6,5]  R2565     -2.1979844197630882e-02
    z[7,6,5]  R2566     -8.6034417152404785e-02
    z[7,6,5]  R2567     -6.9077193737030029e-02
    z[7,6,5]  R2568     -4.2867638170719147e-02
    z[7,6,5]  R2569     -0.271806925535202
    z[7,6,5]  R2570     -8.6144261062145233e-02
    z[7,6,5]  R2571     -3.9314371347427368e-01
    z[7,6,5]  R2572     1.2027243524789810e-01
    z[7,6,5]  R2573     7.5420483946800232e-02
    z[7,6,5]  R2574     1.8396285176277161e-01
    z[7,6,5]  R2575     4.9101737141609192e-01
    z[7,6,5]  R2576     -8.1900522112846375e-02
    z[7,6,5]  R2577     -1.1446280032396317e-01
    z[7,6,5]  R2578     7.4930049479007721e-02
    z[7,6,5]  R2579     -0.532384991645813
    z[7,6,5]  R2580     4.9820342659950256e-01
    z[7,6,5]  R2581     0.0839017704129219
    z[7,6,5]  R2582     -1.7509314417839050e-01
    z[7,6,5]  R2583     -2.3635946214199066e-01
    z[7,6,5]  R2584     -4.0245339274406433e-01
    z[7,6,5]  R2585     -1.5049065649509430e-01
    z[7,6,5]  R2586     -4.7530877590179443e-01
    z[7,6,5]  R2587     -1.7866681516170502e-01
    z[7,6,5]  R2588     -4.0760576725006104e-01
    z[7,6,5]  R2589     -2.7285388112068176e-01
    z[7,6,5]  R2590     -9.9871069192886353e-02
    z[7,6,5]  R2591     -2.8446984291076660e-01
    z[7,6,5]  R2592     5.5914241075515747e-01
    z[7,6,5]  R2593     2.0898316800594330e-01
    z[7,6,5]  R2594     -8.0084212124347687e-02
    z[7,6,5]  R2595     4.5964911580085754e-01
    z[7,6,5]  R2596     1.5262268483638763e-01
    z[7,6,5]  R2597     1.8325030803680420e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2498     -1
    z[7,6,6]  R2499     1
    z[7,6,6]  R2500     -2.2001625970005989e-02
    z[7,6,6]  R2501     -1.4025479555130005e-01
    z[7,6,6]  R2502     -4.2123657464981079e-01
    z[7,6,6]  R2503     6.8454399704933167e-02
    z[7,6,6]  R2504     -3.1226837635040283e-01
    z[7,6,6]  R2505     -1.2739579379558563e-01
    z[7,6,6]  R2506     1.4769941568374634e-01
    z[7,6,6]  R2507     2.8385478258132935e-01
    z[7,6,6]  R2508     4.3280860781669617e-01
    z[7,6,6]  R2509     2.1668995916843414e-01
    z[7,6,6]  R2510     7.4218285083770752e-01
    z[7,6,6]  R2511     -1.2182947993278503e-01
    z[7,6,6]  R2512     -6.0345727205276489e-01
    z[7,6,6]  R2513     -5.4205697774887085e-01
    z[7,6,6]  R2514     0.033658467233181
    z[7,6,6]  R2515     -2.6731219887733459e-01
    z[7,6,6]  R2516     -2.0208215713500977e-01
    z[7,6,6]  R2517     -1.0157459974288940e-01
    z[7,6,6]  R2518     -4.7281436622142792e-02
    z[7,6,6]  R2519     -1.6950058937072754e-01
    z[7,6,6]  R2520     9.0195411443710327e-01
    z[7,6,6]  R2521     -4.0996733307838440e-01
    z[7,6,6]  R2522     -1.0453238338232040e-01
    z[7,6,6]  R2523     1.4032112061977386e-01
    z[7,6,6]  R2524     8.9378423988819122e-02
    z[7,6,6]  R2525     -4.7050941735506058e-02
    z[7,6,6]  R2526     -6.8094715476036072e-02
    z[7,6,6]  R2527     4.2048010975122452e-02
    z[7,6,6]  R2528     -1.5103930234909058e-01
    z[7,6,6]  R2529     1.2314311414957047e-01
    z[7,6,6]  R2530     -2.3049747943878174e-01
    z[7,6,6]  R2531     -9.4908557832241058e-02
    z[7,6,6]  R2532     1.7707893252372742e-01
    z[7,6,6]  R2533     1.1500716954469681e-01
    z[7,6,6]  R2534     3.9514914155006409e-02
    z[7,6,6]  R2535     1.6049657762050629e-01
    z[7,6,6]  R2536     2.2440391778945923e-01
    z[7,6,6]  R2537     2.7134805917739868e-01
    z[7,6,6]  R2538     -6.3286080956459045e-02
    z[7,6,6]  R2539     -1.9872419536113739e-01
    z[7,6,6]  R2540     7.4325375258922577e-02
    z[7,6,6]  R2541     -3.8274798542261124e-02
    z[7,6,6]  R2542     2.7283474802970886e-01
    z[7,6,6]  R2543     2.6236274838447571e-01
    z[7,6,6]  R2544     0.0755741223692894
    z[7,6,6]  R2545     2.0593929290771484e-01
    z[7,6,6]  R2546     4.1099201887845993e-02
    z[7,6,6]  R2547     1.0437231510877609e-01
    z[7,6,6]  R2548     -3.9352121949195862e-01
    z[7,6,6]  R2549     0.397322416305542
    z[7,6,6]  R2550     6.4916145801544189e-01
    z[7,6,6]  R2551     1.3663363456726074e-01
    z[7,6,6]  R2552     1.1498459428548813e-01
    z[7,6,6]  R2553     2.0553120970726013e-01
    z[7,6,6]  R2554     2.8817737102508545e-01
    z[7,6,6]  R2555     -3.0668967962265015e-01
    z[7,6,6]  R2556     -0.300184428691864
    z[7,6,6]  R2557     -5.5269223451614380e-01
    z[7,6,6]  R2558     5.0016533583402634e-02
    z[7,6,6]  R2559     -4.7827857732772827e-01
    z[7,6,6]  R2560     -2.7828231453895569e-02
    z[7,6,6]  R2561     1.3620495796203613e-02
    z[7,6,6]  R2562     5.1132321357727051e-02
    z[7,6,6]  R2563     3.1818398833274841e-01
    z[7,6,6]  R2564     -8.1356592476367950e-02
    z[7,6,6]  R2565     2.5460091233253479e-01
    z[7,6,6]  R2566     -1.0346055030822754e-02
    z[7,6,6]  R2567     -2.9780656099319458e-01
    z[7,6,6]  R2568     2.6816916465759277e-01
    z[7,6,6]  R2569     -2.3238374292850494e-01
    z[7,6,6]  R2570     -1.3719917833805084e-01
    z[7,6,6]  R2571     1.9939646124839783e-01
    z[7,6,6]  R2572     -2.9235085844993591e-01
    z[7,6,6]  R2573     4.3229696154594421e-01
    z[7,6,6]  R2574     1.7052348703145981e-02
    z[7,6,6]  R2575     -3.6040824651718140e-01
    z[7,6,6]  R2576     5.1182365417480469e-01
    z[7,6,6]  R2577     0.343861848115921
    z[7,6,6]  R2578     -0.0243021659553051
    z[7,6,6]  R2579     -1.8595525622367859e-01
    z[7,6,6]  R2580     -4.3452523648738861e-02
    z[7,6,6]  R2581     -2.2632901370525360e-01
    z[7,6,6]  R2582     1.7174807190895081e-01
    z[7,6,6]  R2583     0.0263583455234766
    z[7,6,6]  R2584     2.5093618035316467e-01
    z[7,6,6]  R2585     -2.2811074554920197e-01
    z[7,6,6]  R2586     -7.6790824532508850e-02
    z[7,6,6]  R2587     4.0540233254432678e-01
    z[7,6,6]  R2588     2.2860527038574219e-01
    z[7,6,6]  R2589     -1.0897362232208252e-01
    z[7,6,6]  R2590     -7.8589171171188354e-02
    z[7,6,6]  R2591     -1.7819654941558838e-01
    z[7,6,6]  R2592     -1.2982444465160370e-01
    z[7,6,6]  R2593     1.3908928632736206e-01
    z[7,6,6]  R2594     2.1789376437664032e-01
    z[7,6,6]  R2595     1.9258503615856171e-01
    z[7,6,6]  R2596     1.3709321618080139e-01
    z[7,6,6]  R2597     -1.3313873112201691e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2598     -1
    z[7,8,0]  R2599     1
    z[7,8,0]  R2612     -5.9910756535828114e-03
    z[7,8,0]  R2613     1.3063609600067139e-02
    z[7,8,0]  R2614     -8.1645393371582031e-01
    z[7,8,0]  R2615     1.2668228149414062e-01
    z[7,8,0]  R2616     6.4930331707000732e-01
    z[7,8,0]  R2617     6.6607165336608887e-01
    z[7,8,0]  R2618     4.8031106591224670e-01
    z[7,8,0]  R2619     7.8610196709632874e-02
    z[7,8,0]  R2620     6.0148149728775024e-01
    z[7,8,0]  R2621     7.0729398727416992e-01
    z[7,8,0]  R2622     3.1340315937995911e-01
    z[7,8,0]  R2623     4.8671886324882507e-01
    z[7,8,0]  R2624     6.2293016910552979e-01
    z[7,8,0]  R2625     5.7283890247344971e-01
    z[7,8,0]  R2626     -1.7958205193281174e-02
    z[7,8,0]  R2627     1.1035569012165070e-02
    z[7,8,0]  R2628     5.6998640298843384e-02
    z[7,8,0]  R2629     -1.9504573196172714e-02
    z[7,8,0]  R2630     -1.9807815551757812e-02
    z[7,8,0]  R2631     -1.6340428963303566e-02
    z[7,8,0]  R2632     5.3168445825576782e-02
    z[7,8,0]  R2633     0.707912266254425
    z[7,8,0]  R2634     -3.0555235221982002e-02
    z[7,8,0]  R2635     3.5212565213441849e-02
    z[7,8,0]  R2636     1.8329776823520660e-02
    z[7,8,0]  R2637     1.8452009558677673e-01
    z[7,8,0]  R2638     0.563755989074707
    z[7,8,0]  R2639     6.3438493013381958e-01
    z[7,8,0]  R2640     5.1289850473403931e-01
    z[7,8,0]  R2641     5.3781211376190186e-01
    z[7,8,0]  R2642     3.1111446022987366e-01
    z[7,8,0]  R2643     -2.7675172314047813e-02
    z[7,8,0]  R2644     0.0125663997605443
    z[7,8,0]  R2645     1.7356218770146370e-02
    z[7,8,0]  R2646     -4.0727756917476654e-02
    z[7,8,0]  R2647     -1.8608981743454933e-02
    z[7,8,0]  R2648     -1.7569025978446007e-02
    z[7,8,0]  R2649     -1.0819350183010101e-01
    z[7,8,0]  R2650     4.4395062327384949e-01
    z[7,8,0]  R2651     2.8860560059547424e-01
    z[7,8,0]  R2652     5.7375203818082809e-02
    z[7,8,0]  R2653     1.2621617875993252e-02
    z[7,8,0]  R2654     2.9631700366735458e-02
    z[7,8,0]  R2655     -3.8117118179798126e-02
    z[7,8,0]  R2656     4.1012534499168396e-01
    z[7,8,0]  R2657     4.6212357282638550e-01
    z[7,8,0]  R2658     4.2580339312553406e-01
    z[7,8,0]  R2659     3.7716484069824219e-01
    z[7,8,0]  R2660     -4.4458016753196716e-01
    z[7,8,0]  R2661     -5.4850107431411743e-01
    z[7,8,0]  R2662     -4.5679804682731628e-01
    z[7,8,0]  R2663     -5.3019177913665771e-01
    z[7,8,0]  R2664     -2.9695528745651245e-01
    z[7,8,0]  R2665     0.423216313123703
    z[7,8,0]  R2666     4.9933582544326782e-01
    z[7,8,0]  R2667     3.6802518367767334e-01
    z[7,8,0]  R2668     -2.4371489882469177e-02
    z[7,8,0]  R2669     3.4120373427867889e-02
    z[7,8,0]  R2670     -3.4763745963573456e-02
    z[7,8,0]  R2671     5.6848841905593872e-01
    z[7,8,0]  R2672     -3.4385025501251221e-01
    z[7,8,0]  R2673     1.7285591363906860e-01
    z[7,8,0]  R2674     4.4793954491615295e-01
    z[7,8,0]  R2675     8.7197288870811462e-02
    z[7,8,0]  R2676     2.3777349293231964e-01
    z[7,8,0]  R2677     6.7076951265335083e-01
    z[7,8,0]  R2678     7.3758906126022339e-01
    z[7,8,0]  R2679     3.9325261116027832e-01
    z[7,8,0]  R2680     -3.5049572587013245e-01
    z[7,8,0]  R2681     -6.2821739912033081e-01
    z[7,8,0]  R2682     -4.1651833802461624e-02
    z[7,8,0]  R2683     -1.3105449080467224e-01
    z[7,8,0]  R2684     3.7713015079498291e-01
    z[7,8,0]  R2685     4.3652275204658508e-01
    z[7,8,0]  R2686     2.2517924010753632e-01
    z[7,8,0]  R2687     8.0271774530410767e-01
    z[7,8,0]  R2688     3.5582551360130310e-01
    z[7,8,0]  R2689     4.1191452741622925e-01
    z[7,8,0]  R2690     -3.2250946760177612e-01
    z[7,8,0]  R2691     0.61336749792099
    z[7,8,0]  R2692     3.8357287645339966e-01
    z[7,8,0]  R2693     2.3956814408302307e-01
    z[7,8,0]  R2694     5.6480652093887329e-01
    z[7,8,0]  R2695     6.6074001789093018e-01
    z[7,8,0]  R2696     5.9936910867691040e-01
    z[7,8,0]  R2697     7.1849167346954346e-01
    z[7,8,0]  R2698     4.0731152892112732e-01
    z[7,8,0]  R2699     3.0544099211692810e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2600     -1
    z[7,8,1]  R2601     1
    z[7,8,1]  R2612     -4.2655521631240845e-01
    z[7,8,1]  R2613     -2.8006985783576965e-01
    z[7,8,1]  R2614     -1.3057418167591095e-01
    z[7,8,1]  R2615     8.6231559514999390e-01
    z[7,8,1]  R2616     6.7569863796234131e-01
    z[7,8,1]  R2617     1.4423798024654388e-01
    z[7,8,1]  R2618     7.6201355457305908e-01
    z[7,8,1]  R2619     8.3235615491867065e-01
    z[7,8,1]  R2620     6.3679379224777222e-01
    z[7,8,1]  R2621     5.1596456766128540e-01
    z[7,8,1]  R2622     -3.4337392449378967e-01
    z[7,8,1]  R2623     5.2500668913125992e-02
    z[7,8,1]  R2624     -3.8583520799875259e-02
    z[7,8,1]  R2625     -3.3465981483459473e-01
    z[7,8,1]  R2626     9.7293472290039062e-01
    z[7,8,1]  R2627     9.0512287616729736e-01
    z[7,8,1]  R2628     9.4747757911682129e-01
    z[7,8,1]  R2629     9.5006054639816284e-01
    z[7,8,1]  R2630     0.967280924320221
    z[7,8,1]  R2631     9.4922721385955811e-01
    z[7,8,1]  R2632     -1.7480291426181793e-01
    z[7,8,1]  R2633     1.3711860775947571e-01
    z[7,8,1]  R2634     9.6915805339813232e-01
    z[7,8,1]  R2635     9.1265428066253662e-01
    z[7,8,1]  R2636     8.1704908609390259e-01
    z[7,8,1]  R2637     5.7714241743087769e-01
    z[7,8,1]  R2638     7.2377204895019531e-01
    z[7,8,1]  R2639     7.5220936536788940e-01
    z[7,8,1]  R2640     7.6439785957336426e-01
    z[7,8,1]  R2641     7.2237241268157959e-01
    z[7,8,1]  R2642     5.4793828725814819e-01
    z[7,8,1]  R2643     9.8418653011322021e-01
    z[7,8,1]  R2644     9.2435592412948608e-01
    z[7,8,1]  R2645     8.8267183303833008e-01
    z[7,8,1]  R2646     8.5710215568542480e-01
    z[7,8,1]  R2647     0.840378999710083
    z[7,8,1]  R2648     9.3658220767974854e-01
    z[7,8,1]  R2649     9.1933250427246094e-01
    z[7,8,1]  R2650     8.5234391689300537e-01
    z[7,8,1]  R2651     -2.7679893374443054e-01
    z[7,8,1]  R2652     8.6908000707626343e-01
    z[7,8,1]  R2653     9.6912008523941040e-01
    z[7,8,1]  R2654     9.0541845560073853e-01
    z[7,8,1]  R2655     0.900120735168457
    z[7,8,1]  R2656     0.884118378162384
    z[7,8,1]  R2657     8.3616447448730469e-01
    z[7,8,1]  R2658     8.4244924783706665e-01
    z[7,8,1]  R2659     8.7358832359313965e-01
    z[7,8,1]  R2660     -1.4952081441879272e-01
    z[7,8,1]  R2661     -3.4902659058570862e-01
    z[7,8,1]  R2662     -1.8333059549331665e-01
    z[7,8,1]  R2663     -3.7707424163818359e-01
    z[7,8,1]  R2664     -2.2114260494709015e-01
    z[7,8,1]  R2665     -4.8019373416900635e-01
    z[7,8,1]  R2666     2.3389001190662384e-01
    z[7,8,1]  R2667     6.8756383657455444e-01
    z[7,8,1]  R2668     7.1067267656326294e-01
    z[7,8,1]  R2669     4.1083535552024841e-01
    z[7,8,1]  R2670     -6.6959851980209351e-01
    z[7,8,1]  R2671     3.6577469110488892e-01
    z[7,8,1]  R2672     -3.5648050904273987e-01
    z[7,8,1]  R2673     -2.8611627221107483e-01
    z[7,8,1]  R2674     4.1512030363082886e-01
    z[7,8,1]  R2675     4.0920725464820862e-01
    z[7,8,1]  R2676     7.3018616437911987e-01
    z[7,8,1]  R2677     4.6719476580619812e-01
    z[7,8,1]  R2678     7.3564932681620121e-03
    z[7,8,1]  R2679     7.6251387596130371e-01
    z[7,8,1]  R2680     -4.7746515274047852e-01
    z[7,8,1]  R2681     -0.389955997467041
    z[7,8,1]  R2682     -5.7755655050277710e-01
    z[7,8,1]  R2683     -0.517392098903656
    z[7,8,1]  R2684     -5.5999320745468140e-01
    z[7,8,1]  R2685     -5.9310501813888550e-01
    z[7,8,1]  R2686     -6.5441983938217163e-01
    z[7,8,1]  R2687     4.1583898663520813e-01
    z[7,8,1]  R2688     6.2891805171966553e-01
    z[7,8,1]  R2689     5.0711423158645630e-01
    z[7,8,1]  R2690     -7.9809540510177612e-01
    z[7,8,1]  R2691     5.7353240251541138e-01
    z[7,8,1]  R2692     5.6229871511459351e-01
    z[7,8,1]  R2693     6.2847858667373657e-01
    z[7,8,1]  R2694     5.8387905359268188e-01
    z[7,8,1]  R2695     5.1069349050521851e-01
    z[7,8,1]  R2696     5.4953384399414062e-01
    z[7,8,1]  R2697     4.4973301887512207e-01
    z[7,8,1]  R2698     8.3884263038635254e-01
    z[7,8,1]  R2699     -6.1183761805295944e-02
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2602     -1
    z[7,8,2]  R2603     1
    z[7,8,2]  R2612     -1.5067394077777863e-01
    z[7,8,2]  R2613     -0.516549289226532
    z[7,8,2]  R2614     -6.6462293267250061e-02
    z[7,8,2]  R2615     1.8661996349692345e-02
    z[7,8,2]  R2616     1.3094486296176910e-01
    z[7,8,2]  R2617     -1.2780325114727020e-01
    z[7,8,2]  R2618     4.9446918070316315e-02
    z[7,8,2]  R2619     -0.163267582654953
    z[7,8,2]  R2620     -1.3015115261077881e-01
    z[7,8,2]  R2621     -0.0707424059510231
    z[7,8,2]  R2622     -0.0759369432926178
    z[7,8,2]  R2623     -4.3421775102615356e-01
    z[7,8,2]  R2624     -8.3179615437984467e-02
    z[7,8,2]  R2625     2.1237170696258545e-01
    z[7,8,2]  R2626     -0.0409720353782177
    z[7,8,2]  R2627     -9.2496760189533234e-02
    z[7,8,2]  R2628     -0.0654149055480957
    z[7,8,2]  R2629     -1.7862991988658905e-01
    z[7,8,2]  R2630     -0.072944276034832
    z[7,8,2]  R2631     -1.9429367035627365e-02
    z[7,8,2]  R2632     -7.5190417468547821e-02
    z[7,8,2]  R2633     2.7794721722602844e-01
    z[7,8,2]  R2634     0.0480441153049469
    z[7,8,2]  R2635     6.2870495021343231e-02
    z[7,8,2]  R2636     -2.7227871119976044e-02
    z[7,8,2]  R2637     3.2441091537475586e-01
    z[7,8,2]  R2638     3.2351487874984741e-01
    z[7,8,2]  R2639     1.6495469212532043e-01
    z[7,8,2]  R2640     3.3526563644409180e-01
    z[7,8,2]  R2641     0.269064724445343
    z[7,8,2]  R2642     -4.6142172813415527e-01
    z[7,8,2]  R2643     -5.3108941763639450e-02
    z[7,8,2]  R2644     5.4428409785032272e-03
    z[7,8,2]  R2645     -1.3304175436496735e-01
    z[7,8,2]  R2646     3.1891215592622757e-02
    z[7,8,2]  R2647     -6.6032111644744873e-02
    z[7,8,2]  R2648     -8.4833957254886627e-02
    z[7,8,2]  R2649     -9.7852818667888641e-02
    z[7,8,2]  R2650     -1.3732887804508209e-01
    z[7,8,2]  R2651     8.9185750484466553e-01
    z[7,8,2]  R2652     -1.8962593749165535e-02
    z[7,8,2]  R2653     -1.2604096531867981e-01
    z[7,8,2]  R2654     -2.0869433879852295e-01
    z[7,8,2]  R2655     6.8582065403461456e-02
    z[7,8,2]  R2656     8.9915379881858826e-02
    z[7,8,2]  R2657     -4.3222531676292419e-02
    z[7,8,2]  R2658     8.1388704478740692e-02
    z[7,8,2]  R2659     1.9947733730077744e-02
    z[7,8,2]  R2660     -7.2313450276851654e-02
    z[7,8,2]  R2661     -2.0828001201152802e-01
    z[7,8,2]  R2662     -6.3222104310989380e-01
    z[7,8,2]  R2663     -4.7749385237693787e-01
    z[7,8,2]  R2664     -3.7537348270416260e-01
    z[7,8,2]  R2665     7.1288786828517914e-02
    z[7,8,2]  R2666     -1.4393082261085510e-01
    z[7,8,2]  R2667     -4.0629264712333679e-01
    z[7,8,2]  R2668     -1.8006415665149689e-01
    z[7,8,2]  R2669     2.5981557369232178e-01
    z[7,8,2]  R2670     5.2251034975051880e-01
    z[7,8,2]  R2671     3.0749738216400146e-01
    z[7,8,2]  R2672     5.0228524208068848e-01
    z[7,8,2]  R2673     7.8247189521789551e-01
    z[7,8,2]  R2674     -2.6841390132904053e-01
    z[7,8,2]  R2675     7.8740239143371582e-02
    z[7,8,2]  R2676     1.1565643548965454e-01
    z[7,8,2]  R2677     2.5839990004897118e-02
    z[7,8,2]  R2678     5.9660609811544418e-02
    z[7,8,2]  R2679     -2.1689200401306152e-01
    z[7,8,2]  R2680     5.4515105485916138e-01
    z[7,8,2]  R2681     4.6969360113143921e-01
    z[7,8,2]  R2682     0.602246880531311
    z[7,8,2]  R2683     7.4190104007720947e-01
    z[7,8,2]  R2684     4.8270988464355469e-01
    z[7,8,2]  R2685     9.3167677521705627e-02
    z[7,8,2]  R2686     1.3593721389770508e-01
    z[7,8,2]  R2687     2.1563434600830078e-01
    z[7,8,2]  R2688     3.4316802024841309e-01
    z[7,8,2]  R2689     3.7187594175338745e-01
    z[7,8,2]  R2690     3.0238366127014160e-01
    z[7,8,2]  R2691     2.5595375895500183e-01
    z[7,8,2]  R2692     -1.0048946738243103e-01
    z[7,8,2]  R2693     2.8736475110054016e-01
    z[7,8,2]  R2694     7.0928917266428471e-03
    z[7,8,2]  R2695     -2.4468369781970978e-02
    z[7,8,2]  R2696     -2.1538768708705902e-01
    z[7,8,2]  R2697     -8.2435399293899536e-02
    z[7,8,2]  R2698     -8.5262157022953033e-02
    z[7,8,2]  R2699     -6.4637726545333862e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2604     -1
    z[7,8,3]  R2605     1
    z[7,8,3]  R2612     6.3924556970596313e-01
    z[7,8,3]  R2613     -2.3378323018550873e-01
    z[7,8,3]  R2614     -9.3613415956497192e-02
    z[7,8,3]  R2615     1.1116736382246017e-01
    z[7,8,3]  R2616     -7.1401178836822510e-02
    z[7,8,3]  R2617     -0.562372088432312
    z[7,8,3]  R2618     -1.9542230665683746e-01
    z[7,8,3]  R2619     -4.0477123856544495e-01
    z[7,8,3]  R2620     4.2328916490077972e-02
    z[7,8,3]  R2621     -3.7208297848701477e-01
    z[7,8,3]  R2622     1.5099371969699860e-01
    z[7,8,3]  R2623     -4.2236658930778503e-01
    z[7,8,3]  R2624     -2.6341335847973824e-02
    z[7,8,3]  R2625     -3.4813681244850159e-01
    z[7,8,3]  R2626     -1.9452878832817078e-01
    z[7,8,3]  R2627     -0.281643271446228
    z[7,8,3]  R2628     -7.8988246619701385e-02
    z[7,8,3]  R2629     4.7597393393516541e-02
    z[7,8,3]  R2630     1.9389341771602631e-01
    z[7,8,3]  R2631     1.1428778618574142e-01
    z[7,8,3]  R2632     -1.1311163753271103e-01
    z[7,8,3]  R2633     3.5076647996902466e-01
    z[7,8,3]  R2634     -1.4811113476753235e-01
    z[7,8,3]  R2635     -2.1685248613357544e-01
    z[7,8,3]  R2636     -5.2622330188751221e-01
    z[7,8,3]  R2637     -0.601436972618103
    z[7,8,3]  R2638     -2.1034187078475952e-01
    z[7,8,3]  R2639     -4.0511410683393478e-02
    z[7,8,3]  R2640     -1.0791692882776260e-01
    z[7,8,3]  R2641     -3.0945903062820435e-01
    z[7,8,3]  R2642     -1.8360719084739685e-01
    z[7,8,3]  R2643     8.8795781135559082e-02
    z[7,8,3]  R2644     -2.0583640038967133e-01
    z[7,8,3]  R2645     -3.7144848704338074e-01
    z[7,8,3]  R2646     -4.6119505167007446e-01
    z[7,8,3]  R2647     -4.9894705414772034e-01
    z[7,8,3]  R2648     4.6441480517387390e-02
    z[7,8,3]  R2649     2.1715940535068512e-01
    z[7,8,3]  R2650     1.5470547974109650e-01
    z[7,8,3]  R2651     -1.3947484083473682e-02
    z[7,8,3]  R2652     -4.6483775973320007e-01
    z[7,8,3]  R2653     1.0029217600822449e-01
    z[7,8,3]  R2654     2.2487128153443336e-02
    z[7,8,3]  R2655     1.1945168487727642e-02
    z[7,8,3]  R2656     -7.1909226477146149e-02
    z[7,8,3]  R2657     0.0812668427824974
    z[7,8,3]  R2658     2.6185283064842224e-01
    z[7,8,3]  R2659     1.2367559969425201e-01
    z[7,8,3]  R2660     6.5955489873886108e-01
    z[7,8,3]  R2661     3.9239451289176941e-01
    z[7,8,3]  R2662     5.1759058237075806e-01
    z[7,8,3]  R2663     3.2264402508735657e-01
    z[7,8,3]  R2664     6.9359415769577026e-01
    z[7,8,3]  R2665     5.3478151559829712e-01
    z[7,8,3]  R2666     -3.4646943211555481e-01
    z[7,8,3]  R2667     -1.5794529020786285e-01
    z[7,8,3]  R2668     -4.2564994096755981e-01
    z[7,8,3]  R2669     -2.9889088869094849e-01
    z[7,8,3]  R2670     -0.246913343667984
    z[7,8,3]  R2671     -5.8031529188156128e-01
    z[7,8,3]  R2672     -4.8298770189285278e-01
    z[7,8,3]  R2673     2.2590008378028870e-01
    z[7,8,3]  R2674     -4.5573893189430237e-01
    z[7,8,3]  R2675     -7.6772612333297729e-01
    z[7,8,3]  R2676     -3.6979529261589050e-01
    z[7,8,3]  R2677     3.1639475375413895e-02
    z[7,8,3]  R2678     -1.9011195003986359e-01
    z[7,8,3]  R2679     -3.7013092637062073e-01
    z[7,8,3]  R2680     -1.6484716534614563e-01
    z[7,8,3]  R2681     -4.4422093033790588e-01
    z[7,8,3]  R2682     1.3290122151374817e-02
    z[7,8,3]  R2683     2.0788276195526123e-01
    z[7,8,3]  R2684     3.7719729542732239e-01
    z[7,8,3]  R2685     2.3343847692012787e-01
    z[7,8,3]  R2686     -1.9757138192653656e-01
    z[7,8,3]  R2687     -1.8459393084049225e-01
    z[7,8,3]  R2688     -4.4518882036209106e-01
    z[7,8,3]  R2689     -3.6890691518783569e-01
    z[7,8,3]  R2690     1.7020741105079651e-01
    z[7,8,3]  R2691     -3.6183488368988037e-01
    z[7,8,3]  R2692     -5.9311485290527344e-01
    z[7,8,3]  R2693     -0.547701895236969
    z[7,8,3]  R2694     -3.9181855320930481e-01
    z[7,8,3]  R2695     -3.5032054781913757e-01
    z[7,8,3]  R2696     -2.9732406139373779e-01
    z[7,8,3]  R2697     -2.0701327919960022e-01
    z[7,8,3]  R2698     -2.9160299897193909e-01
    z[7,8,3]  R2699     -3.5774287581443787e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2606     -1
    z[7,8,4]  R2607     1
    z[7,8,4]  R2612     8.8644232600927353e-03
    z[7,8,4]  R2613     -7.4927335977554321e-01
    z[7,8,4]  R2614     3.0625921487808228e-01
    z[7,8,4]  R2615     4.1801303625106812e-01
    z[7,8,4]  R2616     4.5305993407964706e-02
    z[7,8,4]  R2617     3.3342137932777405e-01
    z[7,8,4]  R2618     3.5434964299201965e-01
    z[7,8,4]  R2619     1.5261656045913696e-01
    z[7,8,4]  R2620     1.4550904929637909e-01
    z[7,8,4]  R2621     2.9470531269907951e-02
    z[7,8,4]  R2622     1.7993970215320587e-01
    z[7,8,4]  R2623     5.4295492172241211e-01
    z[7,8,4]  R2624     4.2266571521759033e-01
    z[7,8,4]  R2625     2.8647667169570923e-01
    z[7,8,4]  R2626     9.8350614309310913e-02
    z[7,8,4]  R2627     -1.2155766040086746e-01
    z[7,8,4]  R2628     -2.1807126700878143e-01
    z[7,8,4]  R2629     -2.1742375195026398e-01
    z[7,8,4]  R2630     2.4495452642440796e-02
    z[7,8,4]  R2631     2.3121271282434464e-02
    z[7,8,4]  R2632     2.9923591017723083e-01
    z[7,8,4]  R2633     -1.8949364125728607e-01
    z[7,8,4]  R2634     -4.7363974153995514e-02
    z[7,8,4]  R2635     -2.7551156282424927e-01
    z[7,8,4]  R2636     -1.0807744413614273e-01
    z[7,8,4]  R2637     1.7851382493972778e-01
    z[7,8,4]  R2638     3.9771068841218948e-02
    z[7,8,4]  R2639     3.1845200806856155e-02
    z[7,8,4]  R2640     4.0859386324882507e-02
    z[7,8,4]  R2641     -2.5370957329869270e-02
    z[7,8,4]  R2642     3.1123542785644531e-01
    z[7,8,4]  R2643     8.4523171186447144e-02
    z[7,8,4]  R2644     -2.2215750813484192e-01
    z[7,8,4]  R2645     -1.1565688252449036e-01
    z[7,8,4]  R2646     -2.1413847804069519e-01
    z[7,8,4]  R2647     -1.1905162781476974e-01
    z[7,8,4]  R2648     -1.2807485461235046e-01
    z[7,8,4]  R2649     -7.5445085763931274e-02
    z[7,8,4]  R2650     1.1469919234514236e-01
    z[7,8,4]  R2651     -2.8472345322370529e-02
    z[7,8,4]  R2652     -1.2392916530370712e-01
    z[7,8,4]  R2653     -1.2288790196180344e-01
    z[7,8,4]  R2654     -2.4419040977954865e-01
    z[7,8,4]  R2655     6.0966327786445618e-02
    z[7,8,4]  R2656     -1.7420934140682220e-01
    z[7,8,4]  R2657     1.3803136348724365e-01
    z[7,8,4]  R2658     1.7871741950511932e-01
    z[7,8,4]  R2659     -4.2788442224264145e-03
    z[7,8,4]  R2660     -4.3225738406181335e-01
    z[7,8,4]  R2661     -9.6025556325912476e-02
    z[7,8,4]  R2662     -1.6930563747882843e-01
    z[7,8,4]  R2663     2.7070051431655884e-01
    z[7,8,4]  R2664     2.6033800095319748e-02
    z[7,8,4]  R2665     -3.9280074834823608e-01
    z[7,8,4]  R2666     4.7101568430662155e-02
    z[7,8,4]  R2667     2.0662312209606171e-01
    z[7,8,4]  R2668     -9.2706166207790375e-02
    z[7,8,4]  R2669     -6.0750108957290649e-01
    z[7,8,4]  R2670     4.5477354526519775e-01
    z[7,8,4]  R2671     3.3346363902091980e-01
    z[7,8,4]  R2672     -4.4939586520195007e-01
    z[7,8,4]  R2673     4.1626536846160889e-01
    z[7,8,4]  R2674     4.2432454228401184e-01
    z[7,8,4]  R2675     1.6459852457046509e-01
    z[7,8,4]  R2676     -1.6018894314765930e-01
    z[7,8,4]  R2677     4.6183064579963684e-01
    z[7,8,4]  R2678     5.1293474435806274e-01
    z[7,8,4]  R2679     -0.149389386177063
    z[7,8,4]  R2680     -2.1702152490615845e-01
    z[7,8,4]  R2681     -1.1448127776384354e-01
    z[7,8,4]  R2682     3.3909571170806885e-01
    z[7,8,4]  R2683     0.295040488243103
    z[7,8,4]  R2684     3.1525182723999023e-01
    z[7,8,4]  R2685     5.7058739662170410e-01
    z[7,8,4]  R2686     3.7303307652473450e-01
    z[7,8,4]  R2687     2.7416849136352539e-01
    z[7,8,4]  R2688     -2.0591799914836884e-01
    z[7,8,4]  R2689     1.2502770125865936e-01
    z[7,8,4]  R2690     -2.1284098923206329e-01
    z[7,8,4]  R2691     -9.3588627874851227e-02
    z[7,8,4]  R2692     2.4951553344726562e-01
    z[7,8,4]  R2693     1.8155282735824585e-01
    z[7,8,4]  R2694     1.0902238637208939e-01
    z[7,8,4]  R2695     -6.7754969000816345e-02
    z[7,8,4]  R2696     4.0493637323379517e-01
    z[7,8,4]  R2697     2.9204267263412476e-01
    z[7,8,4]  R2698     -3.8247697055339813e-02
    z[7,8,4]  R2699     8.6044125258922577e-02
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2608     -1
    z[7,8,5]  R2609     1
    z[7,8,5]  R2612     -6.2138122320175171e-01
    z[7,8,5]  R2613     1.3722437620162964e-01
    z[7,8,5]  R2614     1.7871128022670746e-01
    z[7,8,5]  R2615     2.1962702274322510e-01
    z[7,8,5]  R2616     5.2759596146643162e-03
    z[7,8,5]  R2617     2.7486076951026917e-01
    z[7,8,5]  R2618     2.4957705289125443e-02
    z[7,8,5]  R2619     -8.1500142812728882e-02
    z[7,8,5]  R2620     7.4070468544960022e-02
    z[7,8,5]  R2621     -2.0552995800971985e-01
    z[7,8,5]  R2622     4.1484162211418152e-01
    z[7,8,5]  R2623     -2.8942570090293884e-01
    z[7,8,5]  R2624     2.4505026638507843e-01
    z[7,8,5]  R2625     1.3290172815322876e-01
    z[7,8,5]  R2626     5.2438437938690186e-02
    z[7,8,5]  R2627     8.0746538937091827e-02
    z[7,8,5]  R2628     -1.1259089224040508e-02
    z[7,8,5]  R2629     -7.2387181222438812e-02
    z[7,8,5]  R2630     1.3499653339385986e-01
    z[7,8,5]  R2631     -2.3663581907749176e-01
    z[7,8,5]  R2632     2.1238164603710175e-01
    z[7,8,5]  R2633     2.7529197931289673e-01
    z[7,8,5]  R2634     -1.4961116015911102e-01
    z[7,8,5]  R2635     1.3873705267906189e-01
    z[7,8,5]  R2636     -1.8647591769695282e-01
    z[7,8,5]  R2637     3.6305510997772217e-01
    z[7,8,5]  R2638     5.6647438555955887e-02
    z[7,8,5]  R2639     1.0170963592827320e-02
    z[7,8,5]  R2640     -6.4028322696685791e-02
    z[7,8,5]  R2641     7.0482172071933746e-02
    z[7,8,5]  R2642     4.5426121354103088e-01
    z[7,8,5]  R2643     -6.1268504709005356e-02
    z[7,8,5]  R2644     1.4932899177074432e-01
    z[7,8,5]  R2645     -1.9573417305946350e-01
    z[7,8,5]  R2646     -5.0818540155887604e-02
    z[7,8,5]  R2647     -1.3272718526422977e-02
    z[7,8,5]  R2648     2.1538591384887695e-01
    z[7,8,5]  R2649     -8.4063664078712463e-02
    z[7,8,5]  R2650     -1.2831097841262817e-01
    z[7,8,5]  R2651     6.4674086868762970e-02
    z[7,8,5]  R2652     -6.3964784145355225e-02
    z[7,8,5]  R2653     0.134669229388237
    z[7,8,5]  R2654     -3.4824132919311523e-02
    z[7,8,5]  R2655     -3.3306530117988586e-01
    z[7,8,5]  R2656     -2.8563922271132469e-02
    z[7,8,5]  R2657     -1.3166102766990662e-01
    z[7,8,5]  R2658     1.2270816601812840e-02
    z[7,8,5]  R2659     -2.6073870062828064e-01
    z[7,8,5]  R2660     -3.4856861829757690e-01
    z[7,8,5]  R2661     -5.0777328014373779e-01
    z[7,8,5]  R2662     1.1540448665618896e-01
    z[7,8,5]  R2663     3.6164134740829468e-01
    z[7,8,5]  R2664     2.1607802808284760e-01
    z[7,8,5]  R2665     3.1600460410118103e-01
    z[7,8,5]  R2666     -4.1159119457006454e-02
    z[7,8,5]  R2667     3.5393068194389343e-01
    z[7,8,5]  R2668     3.9520743489265442e-01
    z[7,8,5]  R2669     -4.0473049879074097e-01
    z[7,8,5]  R2670     -5.7212188839912415e-02
    z[7,8,5]  R2671     1.1464828858152032e-03
    z[7,8,5]  R2672     2.3619933426380157e-01
    z[7,8,5]  R2673     -0.140846386551857
    z[7,8,5]  R2674     3.9206340909004211e-01
    z[7,8,5]  R2675     4.2794889211654663e-01
    z[7,8,5]  R2676     -4.6053481101989746e-01
    z[7,8,5]  R2677     -0.180740624666214
    z[7,8,5]  R2678     3.8827037811279297e-01
    z[7,8,5]  R2679     1.4511717855930328e-01
    z[7,8,5]  R2680     2.9735869169235229e-01
    z[7,8,5]  R2681     -2.2046746744308621e-04
    z[7,8,5]  R2682     -2.1009309589862823e-01
    z[7,8,5]  R2683     1.5780338644981384e-01
    z[7,8,5]  R2684     -2.2774039208889008e-01
    z[7,8,5]  R2685     -1.0596102476119995e-01
    z[7,8,5]  R2686     9.2661440372467041e-02
    z[7,8,5]  R2687     3.6456289235502481e-03
    z[7,8,5]  R2688     -3.4275129437446594e-01
    z[7,8,5]  R2689     6.2365125864744186e-02
    z[7,8,5]  R2690     2.9562655091285706e-01
    z[7,8,5]  R2691     -2.4623703956604004e-01
    z[7,8,5]  R2692     3.3548551797866821e-01
    z[7,8,5]  R2693     -3.0170193314552307e-01
    z[7,8,5]  R2694     3.7373638153076172e-01
    z[7,8,5]  R2695     4.0881726145744324e-01
    z[7,8,5]  R2696     -1.9105147570371628e-02
    z[7,8,5]  R2697     -1.7751030623912811e-01
    z[7,8,5]  R2698     5.6372337043285370e-02
    z[7,8,5]  R2699     -3.9458981156349182e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2610     -1
    z[7,8,6]  R2611     1
    z[7,8,6]  R2612     -2.2001625970005989e-02
    z[7,8,6]  R2613     -1.4025479555130005e-01
    z[7,8,6]  R2614     -4.2123657464981079e-01
    z[7,8,6]  R2615     6.8454399704933167e-02
    z[7,8,6]  R2616     -3.1226837635040283e-01
    z[7,8,6]  R2617     -1.2739579379558563e-01
    z[7,8,6]  R2618     1.4769941568374634e-01
    z[7,8,6]  R2619     2.8385478258132935e-01
    z[7,8,6]  R2620     4.3280860781669617e-01
    z[7,8,6]  R2621     2.1668995916843414e-01
    z[7,8,6]  R2622     7.4218285083770752e-01
    z[7,8,6]  R2623     -1.2182947993278503e-01
    z[7,8,6]  R2624     -6.0345727205276489e-01
    z[7,8,6]  R2625     -5.4205697774887085e-01
    z[7,8,6]  R2626     0.033658467233181
    z[7,8,6]  R2627     -2.6731219887733459e-01
    z[7,8,6]  R2628     -2.0208215713500977e-01
    z[7,8,6]  R2629     -1.0157459974288940e-01
    z[7,8,6]  R2630     -4.7281436622142792e-02
    z[7,8,6]  R2631     -1.6950058937072754e-01
    z[7,8,6]  R2632     9.0195411443710327e-01
    z[7,8,6]  R2633     -4.0996733307838440e-01
    z[7,8,6]  R2634     -1.0453238338232040e-01
    z[7,8,6]  R2635     1.4032112061977386e-01
    z[7,8,6]  R2636     8.9378423988819122e-02
    z[7,8,6]  R2637     -4.7050941735506058e-02
    z[7,8,6]  R2638     -6.8094715476036072e-02
    z[7,8,6]  R2639     4.2048010975122452e-02
    z[7,8,6]  R2640     -1.5103930234909058e-01
    z[7,8,6]  R2641     1.2314311414957047e-01
    z[7,8,6]  R2642     -2.3049747943878174e-01
    z[7,8,6]  R2643     -9.4908557832241058e-02
    z[7,8,6]  R2644     1.7707893252372742e-01
    z[7,8,6]  R2645     1.1500716954469681e-01
    z[7,8,6]  R2646     3.9514914155006409e-02
    z[7,8,6]  R2647     1.6049657762050629e-01
    z[7,8,6]  R2648     2.2440391778945923e-01
    z[7,8,6]  R2649     2.7134805917739868e-01
    z[7,8,6]  R2650     -6.3286080956459045e-02
    z[7,8,6]  R2651     -1.9872419536113739e-01
    z[7,8,6]  R2652     7.4325375258922577e-02
    z[7,8,6]  R2653     -3.8274798542261124e-02
    z[7,8,6]  R2654     2.7283474802970886e-01
    z[7,8,6]  R2655     2.6236274838447571e-01
    z[7,8,6]  R2656     0.0755741223692894
    z[7,8,6]  R2657     2.0593929290771484e-01
    z[7,8,6]  R2658     4.1099201887845993e-02
    z[7,8,6]  R2659     1.0437231510877609e-01
    z[7,8,6]  R2660     1.7721045017242432e-01
    z[7,8,6]  R2661     -3.3603328466415405e-01
    z[7,8,6]  R2662     -2.1940669417381287e-01
    z[7,8,6]  R2663     2.0136786997318268e-01
    z[7,8,6]  R2664     4.3996366858482361e-01
    z[7,8,6]  R2665     -2.1231368184089661e-01
    z[7,8,6]  R2666     -0.74248868227005
    z[7,8,6]  R2667     1.8393740057945251e-01
    z[7,8,6]  R2668     3.4053787589073181e-01
    z[7,8,6]  R2669     -3.7462761998176575e-01
    z[7,8,6]  R2670     7.9711131751537323e-02
    z[7,8,6]  R2671     2.2581171244382858e-02
    z[7,8,6]  R2672     -1.0665111243724823e-01
    z[7,8,6]  R2673     -1.7846764624118805e-01
    z[7,8,6]  R2674     -1.1625920981168747e-01
    z[7,8,6]  R2675     1.3823738694190979e-01
    z[7,8,6]  R2676     -1.4971335232257843e-01
    z[7,8,6]  R2677     2.9012712836265564e-01
    z[7,8,6]  R2678     0.0484800711274147
    z[7,8,6]  R2679     -1.9107541441917419e-01
    z[7,8,6]  R2680     4.3508040904998779e-01
    z[7,8,6]  R2681     1.4908677339553833e-01
    z[7,8,6]  R2682     3.7774410843849182e-01
    z[7,8,6]  R2683     9.7708672285079956e-02
    z[7,8,6]  R2684     1.3283225893974304e-01
    z[7,8,6]  R2685     -2.4021410942077637e-01
    z[7,8,6]  R2686     -5.6193929910659790e-01
    z[7,8,6]  R2687     1.6421730816364288e-01
    z[7,8,6]  R2688     -4.4859539717435837e-02
    z[7,8,6]  R2689     5.2844703197479248e-01
    z[7,8,6]  R2690     7.6997667551040649e-02
    z[7,8,6]  R2691     -1.7033047974109650e-01
    z[7,8,6]  R2692     -2.0931231847498566e-04
    z[7,8,6]  R2693     2.0268309116363525e-01
    z[7,8,6]  R2694     1.8692786991596222e-01
    z[7,8,6]  R2695     -0.0870007872581482
    z[7,8,6]  R2696     -1.9909110665321350e-01
    z[7,8,6]  R2697     -3.3920624852180481e-01
    z[7,8,6]  R2698     1.8302412331104279e-01
    z[7,8,6]  R2699     4.4053849577903748e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2700     -1
    z[8,7,0]  R2701     1
    z[8,7,0]  R2714     -4.4458016753196716e-01
    z[8,7,0]  R2715     -5.4850107431411743e-01
    z[8,7,0]  R2716     -4.5679804682731628e-01
    z[8,7,0]  R2717     -5.3019177913665771e-01
    z[8,7,0]  R2718     -2.9695528745651245e-01
    z[8,7,0]  R2719     0.423216313123703
    z[8,7,0]  R2720     4.9933582544326782e-01
    z[8,7,0]  R2721     3.6802518367767334e-01
    z[8,7,0]  R2722     -2.4371489882469177e-02
    z[8,7,0]  R2723     3.4120373427867889e-02
    z[8,7,0]  R2724     -3.4763745963573456e-02
    z[8,7,0]  R2725     5.6848841905593872e-01
    z[8,7,0]  R2726     -3.4385025501251221e-01
    z[8,7,0]  R2727     1.7285591363906860e-01
    z[8,7,0]  R2728     4.4793954491615295e-01
    z[8,7,0]  R2729     8.7197288870811462e-02
    z[8,7,0]  R2730     2.3777349293231964e-01
    z[8,7,0]  R2731     6.7076951265335083e-01
    z[8,7,0]  R2732     7.3758906126022339e-01
    z[8,7,0]  R2733     3.9325261116027832e-01
    z[8,7,0]  R2734     -3.5049572587013245e-01
    z[8,7,0]  R2735     -6.2821739912033081e-01
    z[8,7,0]  R2736     -4.1651833802461624e-02
    z[8,7,0]  R2737     -1.3105449080467224e-01
    z[8,7,0]  R2738     3.7713015079498291e-01
    z[8,7,0]  R2739     4.3652275204658508e-01
    z[8,7,0]  R2740     2.2517924010753632e-01
    z[8,7,0]  R2741     8.0271774530410767e-01
    z[8,7,0]  R2742     3.5582551360130310e-01
    z[8,7,0]  R2743     4.1191452741622925e-01
    z[8,7,0]  R2744     -3.2250946760177612e-01
    z[8,7,0]  R2745     0.61336749792099
    z[8,7,0]  R2746     3.8357287645339966e-01
    z[8,7,0]  R2747     2.3956814408302307e-01
    z[8,7,0]  R2748     5.6480652093887329e-01
    z[8,7,0]  R2749     6.6074001789093018e-01
    z[8,7,0]  R2750     5.9936910867691040e-01
    z[8,7,0]  R2751     7.1849167346954346e-01
    z[8,7,0]  R2752     4.0731152892112732e-01
    z[8,7,0]  R2753     3.0544099211692810e-01
    z[8,7,0]  R2754     -5.9910756535828114e-03
    z[8,7,0]  R2755     1.3063609600067139e-02
    z[8,7,0]  R2756     -8.1645393371582031e-01
    z[8,7,0]  R2757     1.2668228149414062e-01
    z[8,7,0]  R2758     6.4930331707000732e-01
    z[8,7,0]  R2759     6.6607165336608887e-01
    z[8,7,0]  R2760     4.8031106591224670e-01
    z[8,7,0]  R2761     7.8610196709632874e-02
    z[8,7,0]  R2762     6.0148149728775024e-01
    z[8,7,0]  R2763     7.0729398727416992e-01
    z[8,7,0]  R2764     3.1340315937995911e-01
    z[8,7,0]  R2765     4.8671886324882507e-01
    z[8,7,0]  R2766     6.2293016910552979e-01
    z[8,7,0]  R2767     5.7283890247344971e-01
    z[8,7,0]  R2768     -1.7958205193281174e-02
    z[8,7,0]  R2769     1.1035569012165070e-02
    z[8,7,0]  R2770     5.6998640298843384e-02
    z[8,7,0]  R2771     -1.9504573196172714e-02
    z[8,7,0]  R2772     -1.9807815551757812e-02
    z[8,7,0]  R2773     -1.6340428963303566e-02
    z[8,7,0]  R2774     5.3168445825576782e-02
    z[8,7,0]  R2775     0.707912266254425
    z[8,7,0]  R2776     -3.0555235221982002e-02
    z[8,7,0]  R2777     3.5212565213441849e-02
    z[8,7,0]  R2778     1.8329776823520660e-02
    z[8,7,0]  R2779     1.8452009558677673e-01
    z[8,7,0]  R2780     0.563755989074707
    z[8,7,0]  R2781     6.3438493013381958e-01
    z[8,7,0]  R2782     5.1289850473403931e-01
    z[8,7,0]  R2783     5.3781211376190186e-01
    z[8,7,0]  R2784     3.1111446022987366e-01
    z[8,7,0]  R2785     -2.7675172314047813e-02
    z[8,7,0]  R2786     0.0125663997605443
    z[8,7,0]  R2787     1.7356218770146370e-02
    z[8,7,0]  R2788     -4.0727756917476654e-02
    z[8,7,0]  R2789     -1.8608981743454933e-02
    z[8,7,0]  R2790     -1.7569025978446007e-02
    z[8,7,0]  R2791     -1.0819350183010101e-01
    z[8,7,0]  R2792     4.4395062327384949e-01
    z[8,7,0]  R2793     2.8860560059547424e-01
    z[8,7,0]  R2794     5.7375203818082809e-02
    z[8,7,0]  R2795     1.2621617875993252e-02
    z[8,7,0]  R2796     2.9631700366735458e-02
    z[8,7,0]  R2797     -3.8117118179798126e-02
    z[8,7,0]  R2798     4.1012534499168396e-01
    z[8,7,0]  R2799     4.6212357282638550e-01
    z[8,7,0]  R2800     4.2580339312553406e-01
    z[8,7,0]  R2801     3.7716484069824219e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2702     -1
    z[8,7,1]  R2703     1
    z[8,7,1]  R2714     -1.4952081441879272e-01
    z[8,7,1]  R2715     -3.4902659058570862e-01
    z[8,7,1]  R2716     -1.8333059549331665e-01
    z[8,7,1]  R2717     -3.7707424163818359e-01
    z[8,7,1]  R2718     -2.2114260494709015e-01
    z[8,7,1]  R2719     -4.8019373416900635e-01
    z[8,7,1]  R2720     2.3389001190662384e-01
    z[8,7,1]  R2721     6.8756383657455444e-01
    z[8,7,1]  R2722     7.1067267656326294e-01
    z[8,7,1]  R2723     4.1083535552024841e-01
    z[8,7,1]  R2724     -6.6959851980209351e-01
    z[8,7,1]  R2725     3.6577469110488892e-01
    z[8,7,1]  R2726     -3.5648050904273987e-01
    z[8,7,1]  R2727     -2.8611627221107483e-01
    z[8,7,1]  R2728     4.1512030363082886e-01
    z[8,7,1]  R2729     4.0920725464820862e-01
    z[8,7,1]  R2730     7.3018616437911987e-01
    z[8,7,1]  R2731     4.6719476580619812e-01
    z[8,7,1]  R2732     7.3564932681620121e-03
    z[8,7,1]  R2733     7.6251387596130371e-01
    z[8,7,1]  R2734     -4.7746515274047852e-01
    z[8,7,1]  R2735     -0.389955997467041
    z[8,7,1]  R2736     -5.7755655050277710e-01
    z[8,7,1]  R2737     -0.517392098903656
    z[8,7,1]  R2738     -5.5999320745468140e-01
    z[8,7,1]  R2739     -5.9310501813888550e-01
    z[8,7,1]  R2740     -6.5441983938217163e-01
    z[8,7,1]  R2741     4.1583898663520813e-01
    z[8,7,1]  R2742     6.2891805171966553e-01
    z[8,7,1]  R2743     5.0711423158645630e-01
    z[8,7,1]  R2744     -7.9809540510177612e-01
    z[8,7,1]  R2745     5.7353240251541138e-01
    z[8,7,1]  R2746     5.6229871511459351e-01
    z[8,7,1]  R2747     6.2847858667373657e-01
    z[8,7,1]  R2748     5.8387905359268188e-01
    z[8,7,1]  R2749     5.1069349050521851e-01
    z[8,7,1]  R2750     5.4953384399414062e-01
    z[8,7,1]  R2751     4.4973301887512207e-01
    z[8,7,1]  R2752     8.3884263038635254e-01
    z[8,7,1]  R2753     -6.1183761805295944e-02
    z[8,7,1]  R2754     -4.2655521631240845e-01
    z[8,7,1]  R2755     -2.8006985783576965e-01
    z[8,7,1]  R2756     -1.3057418167591095e-01
    z[8,7,1]  R2757     8.6231559514999390e-01
    z[8,7,1]  R2758     6.7569863796234131e-01
    z[8,7,1]  R2759     1.4423798024654388e-01
    z[8,7,1]  R2760     7.6201355457305908e-01
    z[8,7,1]  R2761     8.3235615491867065e-01
    z[8,7,1]  R2762     6.3679379224777222e-01
    z[8,7,1]  R2763     5.1596456766128540e-01
    z[8,7,1]  R2764     -3.4337392449378967e-01
    z[8,7,1]  R2765     5.2500668913125992e-02
    z[8,7,1]  R2766     -3.8583520799875259e-02
    z[8,7,1]  R2767     -3.3465981483459473e-01
    z[8,7,1]  R2768     9.7293472290039062e-01
    z[8,7,1]  R2769     9.0512287616729736e-01
    z[8,7,1]  R2770     9.4747757911682129e-01
    z[8,7,1]  R2771     9.5006054639816284e-01
    z[8,7,1]  R2772     0.967280924320221
    z[8,7,1]  R2773     9.4922721385955811e-01
    z[8,7,1]  R2774     -1.7480291426181793e-01
    z[8,7,1]  R2775     1.3711860775947571e-01
    z[8,7,1]  R2776     9.6915805339813232e-01
    z[8,7,1]  R2777     9.1265428066253662e-01
    z[8,7,1]  R2778     8.1704908609390259e-01
    z[8,7,1]  R2779     5.7714241743087769e-01
    z[8,7,1]  R2780     7.2377204895019531e-01
    z[8,7,1]  R2781     7.5220936536788940e-01
    z[8,7,1]  R2782     7.6439785957336426e-01
    z[8,7,1]  R2783     7.2237241268157959e-01
    z[8,7,1]  R2784     5.4793828725814819e-01
    z[8,7,1]  R2785     9.8418653011322021e-01
    z[8,7,1]  R2786     9.2435592412948608e-01
    z[8,7,1]  R2787     8.8267183303833008e-01
    z[8,7,1]  R2788     8.5710215568542480e-01
    z[8,7,1]  R2789     0.840378999710083
    z[8,7,1]  R2790     9.3658220767974854e-01
    z[8,7,1]  R2791     9.1933250427246094e-01
    z[8,7,1]  R2792     8.5234391689300537e-01
    z[8,7,1]  R2793     -2.7679893374443054e-01
    z[8,7,1]  R2794     8.6908000707626343e-01
    z[8,7,1]  R2795     9.6912008523941040e-01
    z[8,7,1]  R2796     9.0541845560073853e-01
    z[8,7,1]  R2797     0.900120735168457
    z[8,7,1]  R2798     0.884118378162384
    z[8,7,1]  R2799     8.3616447448730469e-01
    z[8,7,1]  R2800     8.4244924783706665e-01
    z[8,7,1]  R2801     8.7358832359313965e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2704     -1
    z[8,7,2]  R2705     1
    z[8,7,2]  R2714     -7.2313450276851654e-02
    z[8,7,2]  R2715     -2.0828001201152802e-01
    z[8,7,2]  R2716     -6.3222104310989380e-01
    z[8,7,2]  R2717     -4.7749385237693787e-01
    z[8,7,2]  R2718     -3.7537348270416260e-01
    z[8,7,2]  R2719     7.1288786828517914e-02
    z[8,7,2]  R2720     -1.4393082261085510e-01
    z[8,7,2]  R2721     -4.0629264712333679e-01
    z[8,7,2]  R2722     -1.8006415665149689e-01
    z[8,7,2]  R2723     2.5981557369232178e-01
    z[8,7,2]  R2724     5.2251034975051880e-01
    z[8,7,2]  R2725     3.0749738216400146e-01
    z[8,7,2]  R2726     5.0228524208068848e-01
    z[8,7,2]  R2727     7.8247189521789551e-01
    z[8,7,2]  R2728     -2.6841390132904053e-01
    z[8,7,2]  R2729     7.8740239143371582e-02
    z[8,7,2]  R2730     1.1565643548965454e-01
    z[8,7,2]  R2731     2.5839990004897118e-02
    z[8,7,2]  R2732     5.9660609811544418e-02
    z[8,7,2]  R2733     -2.1689200401306152e-01
    z[8,7,2]  R2734     5.4515105485916138e-01
    z[8,7,2]  R2735     4.6969360113143921e-01
    z[8,7,2]  R2736     0.602246880531311
    z[8,7,2]  R2737     7.4190104007720947e-01
    z[8,7,2]  R2738     4.8270988464355469e-01
    z[8,7,2]  R2739     9.3167677521705627e-02
    z[8,7,2]  R2740     1.3593721389770508e-01
    z[8,7,2]  R2741     2.1563434600830078e-01
    z[8,7,2]  R2742     3.4316802024841309e-01
    z[8,7,2]  R2743     3.7187594175338745e-01
    z[8,7,2]  R2744     3.0238366127014160e-01
    z[8,7,2]  R2745     2.5595375895500183e-01
    z[8,7,2]  R2746     -1.0048946738243103e-01
    z[8,7,2]  R2747     2.8736475110054016e-01
    z[8,7,2]  R2748     7.0928917266428471e-03
    z[8,7,2]  R2749     -2.4468369781970978e-02
    z[8,7,2]  R2750     -2.1538768708705902e-01
    z[8,7,2]  R2751     -8.2435399293899536e-02
    z[8,7,2]  R2752     -8.5262157022953033e-02
    z[8,7,2]  R2753     -6.4637726545333862e-01
    z[8,7,2]  R2754     -1.5067394077777863e-01
    z[8,7,2]  R2755     -0.516549289226532
    z[8,7,2]  R2756     -6.6462293267250061e-02
    z[8,7,2]  R2757     1.8661996349692345e-02
    z[8,7,2]  R2758     1.3094486296176910e-01
    z[8,7,2]  R2759     -1.2780325114727020e-01
    z[8,7,2]  R2760     4.9446918070316315e-02
    z[8,7,2]  R2761     -0.163267582654953
    z[8,7,2]  R2762     -1.3015115261077881e-01
    z[8,7,2]  R2763     -0.0707424059510231
    z[8,7,2]  R2764     -0.0759369432926178
    z[8,7,2]  R2765     -4.3421775102615356e-01
    z[8,7,2]  R2766     -8.3179615437984467e-02
    z[8,7,2]  R2767     2.1237170696258545e-01
    z[8,7,2]  R2768     -0.0409720353782177
    z[8,7,2]  R2769     -9.2496760189533234e-02
    z[8,7,2]  R2770     -0.0654149055480957
    z[8,7,2]  R2771     -1.7862991988658905e-01
    z[8,7,2]  R2772     -0.072944276034832
    z[8,7,2]  R2773     -1.9429367035627365e-02
    z[8,7,2]  R2774     -7.5190417468547821e-02
    z[8,7,2]  R2775     2.7794721722602844e-01
    z[8,7,2]  R2776     0.0480441153049469
    z[8,7,2]  R2777     6.2870495021343231e-02
    z[8,7,2]  R2778     -2.7227871119976044e-02
    z[8,7,2]  R2779     3.2441091537475586e-01
    z[8,7,2]  R2780     3.2351487874984741e-01
    z[8,7,2]  R2781     1.6495469212532043e-01
    z[8,7,2]  R2782     3.3526563644409180e-01
    z[8,7,2]  R2783     0.269064724445343
    z[8,7,2]  R2784     -4.6142172813415527e-01
    z[8,7,2]  R2785     -5.3108941763639450e-02
    z[8,7,2]  R2786     5.4428409785032272e-03
    z[8,7,2]  R2787     -1.3304175436496735e-01
    z[8,7,2]  R2788     3.1891215592622757e-02
    z[8,7,2]  R2789     -6.6032111644744873e-02
    z[8,7,2]  R2790     -8.4833957254886627e-02
    z[8,7,2]  R2791     -9.7852818667888641e-02
    z[8,7,2]  R2792     -1.3732887804508209e-01
    z[8,7,2]  R2793     8.9185750484466553e-01
    z[8,7,2]  R2794     -1.8962593749165535e-02
    z[8,7,2]  R2795     -1.2604096531867981e-01
    z[8,7,2]  R2796     -2.0869433879852295e-01
    z[8,7,2]  R2797     6.8582065403461456e-02
    z[8,7,2]  R2798     8.9915379881858826e-02
    z[8,7,2]  R2799     -4.3222531676292419e-02
    z[8,7,2]  R2800     8.1388704478740692e-02
    z[8,7,2]  R2801     1.9947733730077744e-02
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2706     -1
    z[8,7,3]  R2707     1
    z[8,7,3]  R2714     6.5955489873886108e-01
    z[8,7,3]  R2715     3.9239451289176941e-01
    z[8,7,3]  R2716     5.1759058237075806e-01
    z[8,7,3]  R2717     3.2264402508735657e-01
    z[8,7,3]  R2718     6.9359415769577026e-01
    z[8,7,3]  R2719     5.3478151559829712e-01
    z[8,7,3]  R2720     -3.4646943211555481e-01
    z[8,7,3]  R2721     -1.5794529020786285e-01
    z[8,7,3]  R2722     -4.2564994096755981e-01
    z[8,7,3]  R2723     -2.9889088869094849e-01
    z[8,7,3]  R2724     -0.246913343667984
    z[8,7,3]  R2725     -5.8031529188156128e-01
    z[8,7,3]  R2726     -4.8298770189285278e-01
    z[8,7,3]  R2727     2.2590008378028870e-01
    z[8,7,3]  R2728     -4.5573893189430237e-01
    z[8,7,3]  R2729     -7.6772612333297729e-01
    z[8,7,3]  R2730     -3.6979529261589050e-01
    z[8,7,3]  R2731     3.1639475375413895e-02
    z[8,7,3]  R2732     -1.9011195003986359e-01
    z[8,7,3]  R2733     -3.7013092637062073e-01
    z[8,7,3]  R2734     -1.6484716534614563e-01
    z[8,7,3]  R2735     -4.4422093033790588e-01
    z[8,7,3]  R2736     1.3290122151374817e-02
    z[8,7,3]  R2737     2.0788276195526123e-01
    z[8,7,3]  R2738     3.7719729542732239e-01
    z[8,7,3]  R2739     2.3343847692012787e-01
    z[8,7,3]  R2740     -1.9757138192653656e-01
    z[8,7,3]  R2741     -1.8459393084049225e-01
    z[8,7,3]  R2742     -4.4518882036209106e-01
    z[8,7,3]  R2743     -3.6890691518783569e-01
    z[8,7,3]  R2744     1.7020741105079651e-01
    z[8,7,3]  R2745     -3.6183488368988037e-01
    z[8,7,3]  R2746     -5.9311485290527344e-01
    z[8,7,3]  R2747     -0.547701895236969
    z[8,7,3]  R2748     -3.9181855320930481e-01
    z[8,7,3]  R2749     -3.5032054781913757e-01
    z[8,7,3]  R2750     -2.9732406139373779e-01
    z[8,7,3]  R2751     -2.0701327919960022e-01
    z[8,7,3]  R2752     -2.9160299897193909e-01
    z[8,7,3]  R2753     -3.5774287581443787e-01
    z[8,7,3]  R2754     6.3924556970596313e-01
    z[8,7,3]  R2755     -2.3378323018550873e-01
    z[8,7,3]  R2756     -9.3613415956497192e-02
    z[8,7,3]  R2757     1.1116736382246017e-01
    z[8,7,3]  R2758     -7.1401178836822510e-02
    z[8,7,3]  R2759     -0.562372088432312
    z[8,7,3]  R2760     -1.9542230665683746e-01
    z[8,7,3]  R2761     -4.0477123856544495e-01
    z[8,7,3]  R2762     4.2328916490077972e-02
    z[8,7,3]  R2763     -3.7208297848701477e-01
    z[8,7,3]  R2764     1.5099371969699860e-01
    z[8,7,3]  R2765     -4.2236658930778503e-01
    z[8,7,3]  R2766     -2.6341335847973824e-02
    z[8,7,3]  R2767     -3.4813681244850159e-01
    z[8,7,3]  R2768     -1.9452878832817078e-01
    z[8,7,3]  R2769     -0.281643271446228
    z[8,7,3]  R2770     -7.8988246619701385e-02
    z[8,7,3]  R2771     4.7597393393516541e-02
    z[8,7,3]  R2772     1.9389341771602631e-01
    z[8,7,3]  R2773     1.1428778618574142e-01
    z[8,7,3]  R2774     -1.1311163753271103e-01
    z[8,7,3]  R2775     3.5076647996902466e-01
    z[8,7,3]  R2776     -1.4811113476753235e-01
    z[8,7,3]  R2777     -2.1685248613357544e-01
    z[8,7,3]  R2778     -5.2622330188751221e-01
    z[8,7,3]  R2779     -0.601436972618103
    z[8,7,3]  R2780     -2.1034187078475952e-01
    z[8,7,3]  R2781     -4.0511410683393478e-02
    z[8,7,3]  R2782     -1.0791692882776260e-01
    z[8,7,3]  R2783     -3.0945903062820435e-01
    z[8,7,3]  R2784     -1.8360719084739685e-01
    z[8,7,3]  R2785     8.8795781135559082e-02
    z[8,7,3]  R2786     -2.0583640038967133e-01
    z[8,7,3]  R2787     -3.7144848704338074e-01
    z[8,7,3]  R2788     -4.6119505167007446e-01
    z[8,7,3]  R2789     -4.9894705414772034e-01
    z[8,7,3]  R2790     4.6441480517387390e-02
    z[8,7,3]  R2791     2.1715940535068512e-01
    z[8,7,3]  R2792     1.5470547974109650e-01
    z[8,7,3]  R2793     -1.3947484083473682e-02
    z[8,7,3]  R2794     -4.6483775973320007e-01
    z[8,7,3]  R2795     1.0029217600822449e-01
    z[8,7,3]  R2796     2.2487128153443336e-02
    z[8,7,3]  R2797     1.1945168487727642e-02
    z[8,7,3]  R2798     -7.1909226477146149e-02
    z[8,7,3]  R2799     0.0812668427824974
    z[8,7,3]  R2800     2.6185283064842224e-01
    z[8,7,3]  R2801     1.2367559969425201e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2708     -1
    z[8,7,4]  R2709     1
    z[8,7,4]  R2714     -4.3225738406181335e-01
    z[8,7,4]  R2715     -9.6025556325912476e-02
    z[8,7,4]  R2716     -1.6930563747882843e-01
    z[8,7,4]  R2717     2.7070051431655884e-01
    z[8,7,4]  R2718     2.6033800095319748e-02
    z[8,7,4]  R2719     -3.9280074834823608e-01
    z[8,7,4]  R2720     4.7101568430662155e-02
    z[8,7,4]  R2721     2.0662312209606171e-01
    z[8,7,4]  R2722     -9.2706166207790375e-02
    z[8,7,4]  R2723     -6.0750108957290649e-01
    z[8,7,4]  R2724     4.5477354526519775e-01
    z[8,7,4]  R2725     3.3346363902091980e-01
    z[8,7,4]  R2726     -4.4939586520195007e-01
    z[8,7,4]  R2727     4.1626536846160889e-01
    z[8,7,4]  R2728     4.2432454228401184e-01
    z[8,7,4]  R2729     1.6459852457046509e-01
    z[8,7,4]  R2730     -1.6018894314765930e-01
    z[8,7,4]  R2731     4.6183064579963684e-01
    z[8,7,4]  R2732     5.1293474435806274e-01
    z[8,7,4]  R2733     -0.149389386177063
    z[8,7,4]  R2734     -2.1702152490615845e-01
    z[8,7,4]  R2735     -1.1448127776384354e-01
    z[8,7,4]  R2736     3.3909571170806885e-01
    z[8,7,4]  R2737     0.295040488243103
    z[8,7,4]  R2738     3.1525182723999023e-01
    z[8,7,4]  R2739     5.7058739662170410e-01
    z[8,7,4]  R2740     3.7303307652473450e-01
    z[8,7,4]  R2741     2.7416849136352539e-01
    z[8,7,4]  R2742     -2.0591799914836884e-01
    z[8,7,4]  R2743     1.2502770125865936e-01
    z[8,7,4]  R2744     -2.1284098923206329e-01
    z[8,7,4]  R2745     -9.3588627874851227e-02
    z[8,7,4]  R2746     2.4951553344726562e-01
    z[8,7,4]  R2747     1.8155282735824585e-01
    z[8,7,4]  R2748     1.0902238637208939e-01
    z[8,7,4]  R2749     -6.7754969000816345e-02
    z[8,7,4]  R2750     4.0493637323379517e-01
    z[8,7,4]  R2751     2.9204267263412476e-01
    z[8,7,4]  R2752     -3.8247697055339813e-02
    z[8,7,4]  R2753     8.6044125258922577e-02
    z[8,7,4]  R2754     8.8644232600927353e-03
    z[8,7,4]  R2755     -7.4927335977554321e-01
    z[8,7,4]  R2756     3.0625921487808228e-01
    z[8,7,4]  R2757     4.1801303625106812e-01
    z[8,7,4]  R2758     4.5305993407964706e-02
    z[8,7,4]  R2759     3.3342137932777405e-01
    z[8,7,4]  R2760     3.5434964299201965e-01
    z[8,7,4]  R2761     1.5261656045913696e-01
    z[8,7,4]  R2762     1.4550904929637909e-01
    z[8,7,4]  R2763     2.9470531269907951e-02
    z[8,7,4]  R2764     1.7993970215320587e-01
    z[8,7,4]  R2765     5.4295492172241211e-01
    z[8,7,4]  R2766     4.2266571521759033e-01
    z[8,7,4]  R2767     2.8647667169570923e-01
    z[8,7,4]  R2768     9.8350614309310913e-02
    z[8,7,4]  R2769     -1.2155766040086746e-01
    z[8,7,4]  R2770     -2.1807126700878143e-01
    z[8,7,4]  R2771     -2.1742375195026398e-01
    z[8,7,4]  R2772     2.4495452642440796e-02
    z[8,7,4]  R2773     2.3121271282434464e-02
    z[8,7,4]  R2774     2.9923591017723083e-01
    z[8,7,4]  R2775     -1.8949364125728607e-01
    z[8,7,4]  R2776     -4.7363974153995514e-02
    z[8,7,4]  R2777     -2.7551156282424927e-01
    z[8,7,4]  R2778     -1.0807744413614273e-01
    z[8,7,4]  R2779     1.7851382493972778e-01
    z[8,7,4]  R2780     3.9771068841218948e-02
    z[8,7,4]  R2781     3.1845200806856155e-02
    z[8,7,4]  R2782     4.0859386324882507e-02
    z[8,7,4]  R2783     -2.5370957329869270e-02
    z[8,7,4]  R2784     3.1123542785644531e-01
    z[8,7,4]  R2785     8.4523171186447144e-02
    z[8,7,4]  R2786     -2.2215750813484192e-01
    z[8,7,4]  R2787     -1.1565688252449036e-01
    z[8,7,4]  R2788     -2.1413847804069519e-01
    z[8,7,4]  R2789     -1.1905162781476974e-01
    z[8,7,4]  R2790     -1.2807485461235046e-01
    z[8,7,4]  R2791     -7.5445085763931274e-02
    z[8,7,4]  R2792     1.1469919234514236e-01
    z[8,7,4]  R2793     -2.8472345322370529e-02
    z[8,7,4]  R2794     -1.2392916530370712e-01
    z[8,7,4]  R2795     -1.2288790196180344e-01
    z[8,7,4]  R2796     -2.4419040977954865e-01
    z[8,7,4]  R2797     6.0966327786445618e-02
    z[8,7,4]  R2798     -1.7420934140682220e-01
    z[8,7,4]  R2799     1.3803136348724365e-01
    z[8,7,4]  R2800     1.7871741950511932e-01
    z[8,7,4]  R2801     -4.2788442224264145e-03
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2710     -1
    z[8,7,5]  R2711     1
    z[8,7,5]  R2714     -3.4856861829757690e-01
    z[8,7,5]  R2715     -5.0777328014373779e-01
    z[8,7,5]  R2716     1.1540448665618896e-01
    z[8,7,5]  R2717     3.6164134740829468e-01
    z[8,7,5]  R2718     2.1607802808284760e-01
    z[8,7,5]  R2719     3.1600460410118103e-01
    z[8,7,5]  R2720     -4.1159119457006454e-02
    z[8,7,5]  R2721     3.5393068194389343e-01
    z[8,7,5]  R2722     3.9520743489265442e-01
    z[8,7,5]  R2723     -4.0473049879074097e-01
    z[8,7,5]  R2724     -5.7212188839912415e-02
    z[8,7,5]  R2725     1.1464828858152032e-03
    z[8,7,5]  R2726     2.3619933426380157e-01
    z[8,7,5]  R2727     -0.140846386551857
    z[8,7,5]  R2728     3.9206340909004211e-01
    z[8,7,5]  R2729     4.2794889211654663e-01
    z[8,7,5]  R2730     -4.6053481101989746e-01
    z[8,7,5]  R2731     -0.180740624666214
    z[8,7,5]  R2732     3.8827037811279297e-01
    z[8,7,5]  R2733     1.4511717855930328e-01
    z[8,7,5]  R2734     2.9735869169235229e-01
    z[8,7,5]  R2735     -2.2046746744308621e-04
    z[8,7,5]  R2736     -2.1009309589862823e-01
    z[8,7,5]  R2737     1.5780338644981384e-01
    z[8,7,5]  R2738     -2.2774039208889008e-01
    z[8,7,5]  R2739     -1.0596102476119995e-01
    z[8,7,5]  R2740     9.2661440372467041e-02
    z[8,7,5]  R2741     3.6456289235502481e-03
    z[8,7,5]  R2742     -3.4275129437446594e-01
    z[8,7,5]  R2743     6.2365125864744186e-02
    z[8,7,5]  R2744     2.9562655091285706e-01
    z[8,7,5]  R2745     -2.4623703956604004e-01
    z[8,7,5]  R2746     3.3548551797866821e-01
    z[8,7,5]  R2747     -3.0170193314552307e-01
    z[8,7,5]  R2748     3.7373638153076172e-01
    z[8,7,5]  R2749     4.0881726145744324e-01
    z[8,7,5]  R2750     -1.9105147570371628e-02
    z[8,7,5]  R2751     -1.7751030623912811e-01
    z[8,7,5]  R2752     5.6372337043285370e-02
    z[8,7,5]  R2753     -3.9458981156349182e-01
    z[8,7,5]  R2754     -6.2138122320175171e-01
    z[8,7,5]  R2755     1.3722437620162964e-01
    z[8,7,5]  R2756     1.7871128022670746e-01
    z[8,7,5]  R2757     2.1962702274322510e-01
    z[8,7,5]  R2758     5.2759596146643162e-03
    z[8,7,5]  R2759     2.7486076951026917e-01
    z[8,7,5]  R2760     2.4957705289125443e-02
    z[8,7,5]  R2761     -8.1500142812728882e-02
    z[8,7,5]  R2762     7.4070468544960022e-02
    z[8,7,5]  R2763     -2.0552995800971985e-01
    z[8,7,5]  R2764     4.1484162211418152e-01
    z[8,7,5]  R2765     -2.8942570090293884e-01
    z[8,7,5]  R2766     2.4505026638507843e-01
    z[8,7,5]  R2767     1.3290172815322876e-01
    z[8,7,5]  R2768     5.2438437938690186e-02
    z[8,7,5]  R2769     8.0746538937091827e-02
    z[8,7,5]  R2770     -1.1259089224040508e-02
    z[8,7,5]  R2771     -7.2387181222438812e-02
    z[8,7,5]  R2772     1.3499653339385986e-01
    z[8,7,5]  R2773     -2.3663581907749176e-01
    z[8,7,5]  R2774     2.1238164603710175e-01
    z[8,7,5]  R2775     2.7529197931289673e-01
    z[8,7,5]  R2776     -1.4961116015911102e-01
    z[8,7,5]  R2777     1.3873705267906189e-01
    z[8,7,5]  R2778     -1.8647591769695282e-01
    z[8,7,5]  R2779     3.6305510997772217e-01
    z[8,7,5]  R2780     5.6647438555955887e-02
    z[8,7,5]  R2781     1.0170963592827320e-02
    z[8,7,5]  R2782     -6.4028322696685791e-02
    z[8,7,5]  R2783     7.0482172071933746e-02
    z[8,7,5]  R2784     4.5426121354103088e-01
    z[8,7,5]  R2785     -6.1268504709005356e-02
    z[8,7,5]  R2786     1.4932899177074432e-01
    z[8,7,5]  R2787     -1.9573417305946350e-01
    z[8,7,5]  R2788     -5.0818540155887604e-02
    z[8,7,5]  R2789     -1.3272718526422977e-02
    z[8,7,5]  R2790     2.1538591384887695e-01
    z[8,7,5]  R2791     -8.4063664078712463e-02
    z[8,7,5]  R2792     -1.2831097841262817e-01
    z[8,7,5]  R2793     6.4674086868762970e-02
    z[8,7,5]  R2794     -6.3964784145355225e-02
    z[8,7,5]  R2795     0.134669229388237
    z[8,7,5]  R2796     -3.4824132919311523e-02
    z[8,7,5]  R2797     -3.3306530117988586e-01
    z[8,7,5]  R2798     -2.8563922271132469e-02
    z[8,7,5]  R2799     -1.3166102766990662e-01
    z[8,7,5]  R2800     1.2270816601812840e-02
    z[8,7,5]  R2801     -2.6073870062828064e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2712     -1
    z[8,7,6]  R2713     1
    z[8,7,6]  R2714     1.7721045017242432e-01
    z[8,7,6]  R2715     -3.3603328466415405e-01
    z[8,7,6]  R2716     -2.1940669417381287e-01
    z[8,7,6]  R2717     2.0136786997318268e-01
    z[8,7,6]  R2718     4.3996366858482361e-01
    z[8,7,6]  R2719     -2.1231368184089661e-01
    z[8,7,6]  R2720     -0.74248868227005
    z[8,7,6]  R2721     1.8393740057945251e-01
    z[8,7,6]  R2722     3.4053787589073181e-01
    z[8,7,6]  R2723     -3.7462761998176575e-01
    z[8,7,6]  R2724     7.9711131751537323e-02
    z[8,7,6]  R2725     2.2581171244382858e-02
    z[8,7,6]  R2726     -1.0665111243724823e-01
    z[8,7,6]  R2727     -1.7846764624118805e-01
    z[8,7,6]  R2728     -1.1625920981168747e-01
    z[8,7,6]  R2729     1.3823738694190979e-01
    z[8,7,6]  R2730     -1.4971335232257843e-01
    z[8,7,6]  R2731     2.9012712836265564e-01
    z[8,7,6]  R2732     0.0484800711274147
    z[8,7,6]  R2733     -1.9107541441917419e-01
    z[8,7,6]  R2734     4.3508040904998779e-01
    z[8,7,6]  R2735     1.4908677339553833e-01
    z[8,7,6]  R2736     3.7774410843849182e-01
    z[8,7,6]  R2737     9.7708672285079956e-02
    z[8,7,6]  R2738     1.3283225893974304e-01
    z[8,7,6]  R2739     -2.4021410942077637e-01
    z[8,7,6]  R2740     -5.6193929910659790e-01
    z[8,7,6]  R2741     1.6421730816364288e-01
    z[8,7,6]  R2742     -4.4859539717435837e-02
    z[8,7,6]  R2743     5.2844703197479248e-01
    z[8,7,6]  R2744     7.6997667551040649e-02
    z[8,7,6]  R2745     -1.7033047974109650e-01
    z[8,7,6]  R2746     -2.0931231847498566e-04
    z[8,7,6]  R2747     2.0268309116363525e-01
    z[8,7,6]  R2748     1.8692786991596222e-01
    z[8,7,6]  R2749     -0.0870007872581482
    z[8,7,6]  R2750     -1.9909110665321350e-01
    z[8,7,6]  R2751     -3.3920624852180481e-01
    z[8,7,6]  R2752     1.8302412331104279e-01
    z[8,7,6]  R2753     4.4053849577903748e-01
    z[8,7,6]  R2754     -2.2001625970005989e-02
    z[8,7,6]  R2755     -1.4025479555130005e-01
    z[8,7,6]  R2756     -4.2123657464981079e-01
    z[8,7,6]  R2757     6.8454399704933167e-02
    z[8,7,6]  R2758     -3.1226837635040283e-01
    z[8,7,6]  R2759     -1.2739579379558563e-01
    z[8,7,6]  R2760     1.4769941568374634e-01
    z[8,7,6]  R2761     2.8385478258132935e-01
    z[8,7,6]  R2762     4.3280860781669617e-01
    z[8,7,6]  R2763     2.1668995916843414e-01
    z[8,7,6]  R2764     7.4218285083770752e-01
    z[8,7,6]  R2765     -1.2182947993278503e-01
    z[8,7,6]  R2766     -6.0345727205276489e-01
    z[8,7,6]  R2767     -5.4205697774887085e-01
    z[8,7,6]  R2768     0.033658467233181
    z[8,7,6]  R2769     -2.6731219887733459e-01
    z[8,7,6]  R2770     -2.0208215713500977e-01
    z[8,7,6]  R2771     -1.0157459974288940e-01
    z[8,7,6]  R2772     -4.7281436622142792e-02
    z[8,7,6]  R2773     -1.6950058937072754e-01
    z[8,7,6]  R2774     9.0195411443710327e-01
    z[8,7,6]  R2775     -4.0996733307838440e-01
    z[8,7,6]  R2776     -1.0453238338232040e-01
    z[8,7,6]  R2777     1.4032112061977386e-01
    z[8,7,6]  R2778     8.9378423988819122e-02
    z[8,7,6]  R2779     -4.7050941735506058e-02
    z[8,7,6]  R2780     -6.8094715476036072e-02
    z[8,7,6]  R2781     4.2048010975122452e-02
    z[8,7,6]  R2782     -1.5103930234909058e-01
    z[8,7,6]  R2783     1.2314311414957047e-01
    z[8,7,6]  R2784     -2.3049747943878174e-01
    z[8,7,6]  R2785     -9.4908557832241058e-02
    z[8,7,6]  R2786     1.7707893252372742e-01
    z[8,7,6]  R2787     1.1500716954469681e-01
    z[8,7,6]  R2788     3.9514914155006409e-02
    z[8,7,6]  R2789     1.6049657762050629e-01
    z[8,7,6]  R2790     2.2440391778945923e-01
    z[8,7,6]  R2791     2.7134805917739868e-01
    z[8,7,6]  R2792     -6.3286080956459045e-02
    z[8,7,6]  R2793     -1.9872419536113739e-01
    z[8,7,6]  R2794     7.4325375258922577e-02
    z[8,7,6]  R2795     -3.8274798542261124e-02
    z[8,7,6]  R2796     2.7283474802970886e-01
    z[8,7,6]  R2797     2.6236274838447571e-01
    z[8,7,6]  R2798     0.0755741223692894
    z[8,7,6]  R2799     2.0593929290771484e-01
    z[8,7,6]  R2800     4.1099201887845993e-02
    z[8,7,6]  R2801     1.0437231510877609e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2802     -1
    z[8,9,0]  R2803     1
    z[8,9,0]  R2816     -4.4458016753196716e-01
    z[8,9,0]  R2817     -5.4850107431411743e-01
    z[8,9,0]  R2818     -4.5679804682731628e-01
    z[8,9,0]  R2819     -5.3019177913665771e-01
    z[8,9,0]  R2820     -2.9695528745651245e-01
    z[8,9,0]  R2821     0.423216313123703
    z[8,9,0]  R2822     4.9933582544326782e-01
    z[8,9,0]  R2823     3.6802518367767334e-01
    z[8,9,0]  R2824     -2.4371489882469177e-02
    z[8,9,0]  R2825     3.4120373427867889e-02
    z[8,9,0]  R2826     -3.4763745963573456e-02
    z[8,9,0]  R2827     5.6848841905593872e-01
    z[8,9,0]  R2828     -3.4385025501251221e-01
    z[8,9,0]  R2829     1.7285591363906860e-01
    z[8,9,0]  R2830     4.4793954491615295e-01
    z[8,9,0]  R2831     8.7197288870811462e-02
    z[8,9,0]  R2832     2.3777349293231964e-01
    z[8,9,0]  R2833     6.7076951265335083e-01
    z[8,9,0]  R2834     7.3758906126022339e-01
    z[8,9,0]  R2835     3.9325261116027832e-01
    z[8,9,0]  R2836     -3.5049572587013245e-01
    z[8,9,0]  R2837     -6.2821739912033081e-01
    z[8,9,0]  R2838     -4.1651833802461624e-02
    z[8,9,0]  R2839     -1.3105449080467224e-01
    z[8,9,0]  R2840     3.7713015079498291e-01
    z[8,9,0]  R2841     4.3652275204658508e-01
    z[8,9,0]  R2842     2.2517924010753632e-01
    z[8,9,0]  R2843     8.0271774530410767e-01
    z[8,9,0]  R2844     3.5582551360130310e-01
    z[8,9,0]  R2845     4.1191452741622925e-01
    z[8,9,0]  R2846     -3.2250946760177612e-01
    z[8,9,0]  R2847     0.61336749792099
    z[8,9,0]  R2848     3.8357287645339966e-01
    z[8,9,0]  R2849     2.3956814408302307e-01
    z[8,9,0]  R2850     5.6480652093887329e-01
    z[8,9,0]  R2851     6.6074001789093018e-01
    z[8,9,0]  R2852     5.9936910867691040e-01
    z[8,9,0]  R2853     7.1849167346954346e-01
    z[8,9,0]  R2854     4.0731152892112732e-01
    z[8,9,0]  R2855     3.0544099211692810e-01
    z[8,9,0]  R2856     -6.4548724889755249e-01
    z[8,9,0]  R2857     -4.4700339436531067e-01
    z[8,9,0]  R2858     -5.7674968242645264e-01
    z[8,9,0]  R2859     -5.1093703508377075e-01
    z[8,9,0]  R2860     -1.0504309833049774e-01
    z[8,9,0]  R2861     -1.6773472726345062e-01
    z[8,9,0]  R2862     -4.2771536111831665e-01
    z[8,9,0]  R2863     3.5226613283157349e-01
    z[8,9,0]  R2864     1.7311668395996094e-01
    z[8,9,0]  R2865     4.0123113989830017e-01
    z[8,9,0]  R2866     0.0276805367320776
    z[8,9,0]  R2867     -3.9720579981803894e-01
    z[8,9,0]  R2868     -2.8522130846977234e-01
    z[8,9,0]  R2869     -6.4319148659706116e-02
    z[8,9,0]  R2870     6.8526464700698853e-01
    z[8,9,0]  R2871     3.9928045868873596e-01
    z[8,9,0]  R2872     -2.7383902668952942e-01
    z[8,9,0]  R2873     2.9671835899353027e-01
    z[8,9,0]  R2874     5.3257542848587036e-01
    z[8,9,0]  R2875     3.9325863122940063e-01
    z[8,9,0]  R2876     3.3369913697242737e-01
    z[8,9,0]  R2877     4.9956884980201721e-01
    z[8,9,0]  R2878     2.3757702112197876e-01
    z[8,9,0]  R2879     3.2133832573890686e-01
    z[8,9,0]  R2880     3.3036302775144577e-02
    z[8,9,0]  R2881     4.1061779856681824e-01
    z[8,9,0]  R2882     -1.7351135611534119e-02
    z[8,9,0]  R2883     2.0395504310727119e-02
    z[8,9,0]  R2884     -1.4109697937965393e-01
    z[8,9,0]  R2885     1.5128690004348755e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2804     -1
    z[8,9,1]  R2805     1
    z[8,9,1]  R2816     -1.4952081441879272e-01
    z[8,9,1]  R2817     -3.4902659058570862e-01
    z[8,9,1]  R2818     -1.8333059549331665e-01
    z[8,9,1]  R2819     -3.7707424163818359e-01
    z[8,9,1]  R2820     -2.2114260494709015e-01
    z[8,9,1]  R2821     -4.8019373416900635e-01
    z[8,9,1]  R2822     2.3389001190662384e-01
    z[8,9,1]  R2823     6.8756383657455444e-01
    z[8,9,1]  R2824     7.1067267656326294e-01
    z[8,9,1]  R2825     4.1083535552024841e-01
    z[8,9,1]  R2826     -6.6959851980209351e-01
    z[8,9,1]  R2827     3.6577469110488892e-01
    z[8,9,1]  R2828     -3.5648050904273987e-01
    z[8,9,1]  R2829     -2.8611627221107483e-01
    z[8,9,1]  R2830     4.1512030363082886e-01
    z[8,9,1]  R2831     4.0920725464820862e-01
    z[8,9,1]  R2832     7.3018616437911987e-01
    z[8,9,1]  R2833     4.6719476580619812e-01
    z[8,9,1]  R2834     7.3564932681620121e-03
    z[8,9,1]  R2835     7.6251387596130371e-01
    z[8,9,1]  R2836     -4.7746515274047852e-01
    z[8,9,1]  R2837     -0.389955997467041
    z[8,9,1]  R2838     -5.7755655050277710e-01
    z[8,9,1]  R2839     -0.517392098903656
    z[8,9,1]  R2840     -5.5999320745468140e-01
    z[8,9,1]  R2841     -5.9310501813888550e-01
    z[8,9,1]  R2842     -6.5441983938217163e-01
    z[8,9,1]  R2843     4.1583898663520813e-01
    z[8,9,1]  R2844     6.2891805171966553e-01
    z[8,9,1]  R2845     5.0711423158645630e-01
    z[8,9,1]  R2846     -7.9809540510177612e-01
    z[8,9,1]  R2847     5.7353240251541138e-01
    z[8,9,1]  R2848     5.6229871511459351e-01
    z[8,9,1]  R2849     6.2847858667373657e-01
    z[8,9,1]  R2850     5.8387905359268188e-01
    z[8,9,1]  R2851     5.1069349050521851e-01
    z[8,9,1]  R2852     5.4953384399414062e-01
    z[8,9,1]  R2853     4.4973301887512207e-01
    z[8,9,1]  R2854     8.3884263038635254e-01
    z[8,9,1]  R2855     -6.1183761805295944e-02
    z[8,9,1]  R2856     2.2078971564769745e-01
    z[8,9,1]  R2857     2.4528747797012329e-01
    z[8,9,1]  R2858     2.2886614501476288e-01
    z[8,9,1]  R2859     6.2833614647388458e-02
    z[8,9,1]  R2860     0.0522940419614315
    z[8,9,1]  R2861     -2.3030752781778574e-03
    z[8,9,1]  R2862     3.7983089685440063e-01
    z[8,9,1]  R2863     4.4141745567321777e-01
    z[8,9,1]  R2864     2.0452353358268738e-01
    z[8,9,1]  R2865     -2.5731673836708069e-01
    z[8,9,1]  R2866     3.0860263109207153e-01
    z[8,9,1]  R2867     2.1323890984058380e-01
    z[8,9,1]  R2868     2.2095717489719391e-01
    z[8,9,1]  R2869     4.7474063932895660e-02
    z[8,9,1]  R2870     -4.9295875430107117e-01
    z[8,9,1]  R2871     1.2208233773708344e-01
    z[8,9,1]  R2872     -8.2709372043609619e-01
    z[8,9,1]  R2873     -7.6416867971420288e-01
    z[8,9,1]  R2874     -4.6448597311973572e-01
    z[8,9,1]  R2875     -7.0766109228134155e-01
    z[8,9,1]  R2876     3.9264941215515137e-01
    z[8,9,1]  R2877     2.8469431400299072e-01
    z[8,9,1]  R2878     3.3902174234390259e-01
    z[8,9,1]  R2879     -7.2685462236404419e-01
    z[8,9,1]  R2880     -8.2207417488098145e-01
    z[8,9,1]  R2881     -6.3087242841720581e-01
    z[8,9,1]  R2882     -6.2628740072250366e-01
    z[8,9,1]  R2883     -8.5059094429016113e-01
    z[8,9,1]  R2884     -4.3481594324111938e-01
    z[8,9,1]  R2885     -4.0053021907806396e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2806     -1
    z[8,9,2]  R2807     1
    z[8,9,2]  R2816     -7.2313450276851654e-02
    z[8,9,2]  R2817     -2.0828001201152802e-01
    z[8,9,2]  R2818     -6.3222104310989380e-01
    z[8,9,2]  R2819     -4.7749385237693787e-01
    z[8,9,2]  R2820     -3.7537348270416260e-01
    z[8,9,2]  R2821     7.1288786828517914e-02
    z[8,9,2]  R2822     -1.4393082261085510e-01
    z[8,9,2]  R2823     -4.0629264712333679e-01
    z[8,9,2]  R2824     -1.8006415665149689e-01
    z[8,9,2]  R2825     2.5981557369232178e-01
    z[8,9,2]  R2826     5.2251034975051880e-01
    z[8,9,2]  R2827     3.0749738216400146e-01
    z[8,9,2]  R2828     5.0228524208068848e-01
    z[8,9,2]  R2829     7.8247189521789551e-01
    z[8,9,2]  R2830     -2.6841390132904053e-01
    z[8,9,2]  R2831     7.8740239143371582e-02
    z[8,9,2]  R2832     1.1565643548965454e-01
    z[8,9,2]  R2833     2.5839990004897118e-02
    z[8,9,2]  R2834     5.9660609811544418e-02
    z[8,9,2]  R2835     -2.1689200401306152e-01
    z[8,9,2]  R2836     5.4515105485916138e-01
    z[8,9,2]  R2837     4.6969360113143921e-01
    z[8,9,2]  R2838     0.602246880531311
    z[8,9,2]  R2839     7.4190104007720947e-01
    z[8,9,2]  R2840     4.8270988464355469e-01
    z[8,9,2]  R2841     9.3167677521705627e-02
    z[8,9,2]  R2842     1.3593721389770508e-01
    z[8,9,2]  R2843     2.1563434600830078e-01
    z[8,9,2]  R2844     3.4316802024841309e-01
    z[8,9,2]  R2845     3.7187594175338745e-01
    z[8,9,2]  R2846     3.0238366127014160e-01
    z[8,9,2]  R2847     2.5595375895500183e-01
    z[8,9,2]  R2848     -1.0048946738243103e-01
    z[8,9,2]  R2849     2.8736475110054016e-01
    z[8,9,2]  R2850     7.0928917266428471e-03
    z[8,9,2]  R2851     -2.4468369781970978e-02
    z[8,9,2]  R2852     -2.1538768708705902e-01
    z[8,9,2]  R2853     -8.2435399293899536e-02
    z[8,9,2]  R2854     -8.5262157022953033e-02
    z[8,9,2]  R2855     -6.4637726545333862e-01
    z[8,9,2]  R2856     2.4331012368202209e-01
    z[8,9,2]  R2857     -1.3265152275562286e-01
    z[8,9,2]  R2858     1.2788438796997070e-01
    z[8,9,2]  R2859     2.6188468933105469e-01
    z[8,9,2]  R2860     4.9405732750892639e-01
    z[8,9,2]  R2861     4.7037251293659210e-02
    z[8,9,2]  R2862     -2.5888139009475708e-01
    z[8,9,2]  R2863     -5.1113259792327881e-01
    z[8,9,2]  R2864     -8.2068789005279541e-01
    z[8,9,2]  R2865     -7.1421772241592407e-01
    z[8,9,2]  R2866     7.4786305427551270e-01
    z[8,9,2]  R2867     -1.1644738167524338e-01
    z[8,9,2]  R2868     3.0187538266181946e-01
    z[8,9,2]  R2869     3.9523360133171082e-01
    z[8,9,2]  R2870     -1.0738720744848251e-01
    z[8,9,2]  R2871     7.8273884952068329e-02
    z[8,9,2]  R2872     -2.1103464066982269e-01
    z[8,9,2]  R2873     -1.7358438670635223e-01
    z[8,9,2]  R2874     -1.4429225027561188e-01
    z[8,9,2]  R2875     -1.3068130612373352e-01
    z[8,9,2]  R2876     3.3380672335624695e-01
    z[8,9,2]  R2877     0.0972277969121933
    z[8,9,2]  R2878     -4.9237540364265442e-01
    z[8,9,2]  R2879     -2.4246707558631897e-01
    z[8,9,2]  R2880     -3.6731344461441040e-01
    z[8,9,2]  R2881     2.0351560413837433e-01
    z[8,9,2]  R2882     -7.0530956983566284e-01
    z[8,9,2]  R2883     3.3843708038330078e-01
    z[8,9,2]  R2884     -8.0793344974517822e-01
    z[8,9,2]  R2885     -7.0788913965225220e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2808     -1
    z[8,9,3]  R2809     1
    z[8,9,3]  R2816     6.5955489873886108e-01
    z[8,9,3]  R2817     3.9239451289176941e-01
    z[8,9,3]  R2818     5.1759058237075806e-01
    z[8,9,3]  R2819     3.2264402508735657e-01
    z[8,9,3]  R2820     6.9359415769577026e-01
    z[8,9,3]  R2821     5.3478151559829712e-01
    z[8,9,3]  R2822     -3.4646943211555481e-01
    z[8,9,3]  R2823     -1.5794529020786285e-01
    z[8,9,3]  R2824     -4.2564994096755981e-01
    z[8,9,3]  R2825     -2.9889088869094849e-01
    z[8,9,3]  R2826     -0.246913343667984
    z[8,9,3]  R2827     -5.8031529188156128e-01
    z[8,9,3]  R2828     -4.8298770189285278e-01
    z[8,9,3]  R2829     2.2590008378028870e-01
    z[8,9,3]  R2830     -4.5573893189430237e-01
    z[8,9,3]  R2831     -7.6772612333297729e-01
    z[8,9,3]  R2832     -3.6979529261589050e-01
    z[8,9,3]  R2833     3.1639475375413895e-02
    z[8,9,3]  R2834     -1.9011195003986359e-01
    z[8,9,3]  R2835     -3.7013092637062073e-01
    z[8,9,3]  R2836     -1.6484716534614563e-01
    z[8,9,3]  R2837     -4.4422093033790588e-01
    z[8,9,3]  R2838     1.3290122151374817e-02
    z[8,9,3]  R2839     2.0788276195526123e-01
    z[8,9,3]  R2840     3.7719729542732239e-01
    z[8,9,3]  R2841     2.3343847692012787e-01
    z[8,9,3]  R2842     -1.9757138192653656e-01
    z[8,9,3]  R2843     -1.8459393084049225e-01
    z[8,9,3]  R2844     -4.4518882036209106e-01
    z[8,9,3]  R2845     -3.6890691518783569e-01
    z[8,9,3]  R2846     1.7020741105079651e-01
    z[8,9,3]  R2847     -3.6183488368988037e-01
    z[8,9,3]  R2848     -5.9311485290527344e-01
    z[8,9,3]  R2849     -0.547701895236969
    z[8,9,3]  R2850     -3.9181855320930481e-01
    z[8,9,3]  R2851     -3.5032054781913757e-01
    z[8,9,3]  R2852     -2.9732406139373779e-01
    z[8,9,3]  R2853     -2.0701327919960022e-01
    z[8,9,3]  R2854     -2.9160299897193909e-01
    z[8,9,3]  R2855     -3.5774287581443787e-01
    z[8,9,3]  R2856     6.4667350053787231e-01
    z[8,9,3]  R2857     8.1469595432281494e-01
    z[8,9,3]  R2858     5.7284229993820190e-01
    z[8,9,3]  R2859     5.4776233434677124e-01
    z[8,9,3]  R2860     7.6668906211853027e-01
    z[8,9,3]  R2861     0.730480432510376
    z[8,9,3]  R2862     4.7357723116874695e-01
    z[8,9,3]  R2863     -7.3143742978572845e-02
    z[8,9,3]  R2864     -0.0997811034321785
    z[8,9,3]  R2865     2.1516993641853333e-01
    z[8,9,3]  R2866     -5.5850225687026978e-01
    z[8,9,3]  R2867     -7.5867593288421631e-01
    z[8,9,3]  R2868     -7.0465826988220215e-01
    z[8,9,3]  R2869     -8.2727390527725220e-01
    z[8,9,3]  R2870     -9.1780357062816620e-02
    z[8,9,3]  R2871     -2.3147705197334290e-01
    z[8,9,3]  R2872     -5.9007301926612854e-02
    z[8,9,3]  R2873     -1.7165517807006836e-01
    z[8,9,3]  R2874     -7.4143759906291962e-02
    z[8,9,3]  R2875     -1.9601134955883026e-01
    z[8,9,3]  R2876     -5.2687042951583862e-01
    z[8,9,3]  R2877     -2.5929272174835205e-01
    z[8,9,3]  R2878     -1.1953826993703842e-01
    z[8,9,3]  R2879     4.2547813057899475e-01
    z[8,9,3]  R2880     -2.6645886898040771e-01
    z[8,9,3]  R2881     2.3811502754688263e-01
    z[8,9,3]  R2882     1.0545709729194641e-01
    z[8,9,3]  R2883     -1.3102434575557709e-01
    z[8,9,3]  R2884     -4.0756408125162125e-02
    z[8,9,3]  R2885     1.2913256883621216e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2810     -1
    z[8,9,4]  R2811     1
    z[8,9,4]  R2816     -4.3225738406181335e-01
    z[8,9,4]  R2817     -9.6025556325912476e-02
    z[8,9,4]  R2818     -1.6930563747882843e-01
    z[8,9,4]  R2819     2.7070051431655884e-01
    z[8,9,4]  R2820     2.6033800095319748e-02
    z[8,9,4]  R2821     -3.9280074834823608e-01
    z[8,9,4]  R2822     4.7101568430662155e-02
    z[8,9,4]  R2823     2.0662312209606171e-01
    z[8,9,4]  R2824     -9.2706166207790375e-02
    z[8,9,4]  R2825     -6.0750108957290649e-01
    z[8,9,4]  R2826     4.5477354526519775e-01
    z[8,9,4]  R2827     3.3346363902091980e-01
    z[8,9,4]  R2828     -4.4939586520195007e-01
    z[8,9,4]  R2829     4.1626536846160889e-01
    z[8,9,4]  R2830     4.2432454228401184e-01
    z[8,9,4]  R2831     1.6459852457046509e-01
    z[8,9,4]  R2832     -1.6018894314765930e-01
    z[8,9,4]  R2833     4.6183064579963684e-01
    z[8,9,4]  R2834     5.1293474435806274e-01
    z[8,9,4]  R2835     -0.149389386177063
    z[8,9,4]  R2836     -2.1702152490615845e-01
    z[8,9,4]  R2837     -1.1448127776384354e-01
    z[8,9,4]  R2838     3.3909571170806885e-01
    z[8,9,4]  R2839     0.295040488243103
    z[8,9,4]  R2840     3.1525182723999023e-01
    z[8,9,4]  R2841     5.7058739662170410e-01
    z[8,9,4]  R2842     3.7303307652473450e-01
    z[8,9,4]  R2843     2.7416849136352539e-01
    z[8,9,4]  R2844     -2.0591799914836884e-01
    z[8,9,4]  R2845     1.2502770125865936e-01
    z[8,9,4]  R2846     -2.1284098923206329e-01
    z[8,9,4]  R2847     -9.3588627874851227e-02
    z[8,9,4]  R2848     2.4951553344726562e-01
    z[8,9,4]  R2849     1.8155282735824585e-01
    z[8,9,4]  R2850     1.0902238637208939e-01
    z[8,9,4]  R2851     -6.7754969000816345e-02
    z[8,9,4]  R2852     4.0493637323379517e-01
    z[8,9,4]  R2853     2.9204267263412476e-01
    z[8,9,4]  R2854     -3.8247697055339813e-02
    z[8,9,4]  R2855     8.6044125258922577e-02
    z[8,9,4]  R2856     -8.6017400026321411e-03
    z[8,9,4]  R2857     -1.5056072175502777e-01
    z[8,9,4]  R2858     4.2689535021781921e-01
    z[8,9,4]  R2859     -5.1363629102706909e-01
    z[8,9,4]  R2860     -2.2283342480659485e-01
    z[8,9,4]  R2861     1.4258655905723572e-01
    z[8,9,4]  R2862     1.0501173883676529e-01
    z[8,9,4]  R2863     -6.3213360309600830e-01
    z[8,9,4]  R2864     3.6314094066619873e-01
    z[8,9,4]  R2865     5.1917150616645813e-02
    z[8,9,4]  R2866     -1.1632586270570755e-01
    z[8,9,4]  R2867     2.6178082823753357e-01
    z[8,9,4]  R2868     -1.4302109181880951e-01
    z[8,9,4]  R2869     2.1030455827713013e-03
    z[8,9,4]  R2870     -2.5131186842918396e-01
    z[8,9,4]  R2871     2.9953831434249878e-01
    z[8,9,4]  R2872     3.2541179656982422e-01
    z[8,9,4]  R2873     -3.2191792130470276e-01
    z[8,9,4]  R2874     -2.9407319426536560e-01
    z[8,9,4]  R2875     -1.6345328092575073e-01
    z[8,9,4]  R2876     -3.3638164401054382e-02
    z[8,9,4]  R2877     5.6115162372589111e-01
    z[8,9,4]  R2878     0.313353568315506
    z[8,9,4]  R2879     -1.4223536849021912e-01
    z[8,9,4]  R2880     -1.7988644540309906e-02
    z[8,9,4]  R2881     1.2636347115039825e-01
    z[8,9,4]  R2882     1.0123517364263535e-01
    z[8,9,4]  R2883     1.1130163073539734e-01
    z[8,9,4]  R2884     -9.8336994647979736e-02
    z[8,9,4]  R2885     -1.6293426975607872e-02
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2812     -1
    z[8,9,5]  R2813     1
    z[8,9,5]  R2816     -3.4856861829757690e-01
    z[8,9,5]  R2817     -5.0777328014373779e-01
    z[8,9,5]  R2818     1.1540448665618896e-01
    z[8,9,5]  R2819     3.6164134740829468e-01
    z[8,9,5]  R2820     2.1607802808284760e-01
    z[8,9,5]  R2821     3.1600460410118103e-01
    z[8,9,5]  R2822     -4.1159119457006454e-02
    z[8,9,5]  R2823     3.5393068194389343e-01
    z[8,9,5]  R2824     3.9520743489265442e-01
    z[8,9,5]  R2825     -4.0473049879074097e-01
    z[8,9,5]  R2826     -5.7212188839912415e-02
    z[8,9,5]  R2827     1.1464828858152032e-03
    z[8,9,5]  R2828     2.3619933426380157e-01
    z[8,9,5]  R2829     -0.140846386551857
    z[8,9,5]  R2830     3.9206340909004211e-01
    z[8,9,5]  R2831     4.2794889211654663e-01
    z[8,9,5]  R2832     -4.6053481101989746e-01
    z[8,9,5]  R2833     -0.180740624666214
    z[8,9,5]  R2834     3.8827037811279297e-01
    z[8,9,5]  R2835     1.4511717855930328e-01
    z[8,9,5]  R2836     2.9735869169235229e-01
    z[8,9,5]  R2837     -2.2046746744308621e-04
    z[8,9,5]  R2838     -2.1009309589862823e-01
    z[8,9,5]  R2839     1.5780338644981384e-01
    z[8,9,5]  R2840     -2.2774039208889008e-01
    z[8,9,5]  R2841     -1.0596102476119995e-01
    z[8,9,5]  R2842     9.2661440372467041e-02
    z[8,9,5]  R2843     3.6456289235502481e-03
    z[8,9,5]  R2844     -3.4275129437446594e-01
    z[8,9,5]  R2845     6.2365125864744186e-02
    z[8,9,5]  R2846     2.9562655091285706e-01
    z[8,9,5]  R2847     -2.4623703956604004e-01
    z[8,9,5]  R2848     3.3548551797866821e-01
    z[8,9,5]  R2849     -3.0170193314552307e-01
    z[8,9,5]  R2850     3.7373638153076172e-01
    z[8,9,5]  R2851     4.0881726145744324e-01
    z[8,9,5]  R2852     -1.9105147570371628e-02
    z[8,9,5]  R2853     -1.7751030623912811e-01
    z[8,9,5]  R2854     5.6372337043285370e-02
    z[8,9,5]  R2855     -3.9458981156349182e-01
    z[8,9,5]  R2856     -1.6714364290237427e-01
    z[8,9,5]  R2857     -1.0922791436314583e-02
    z[8,9,5]  R2858     -0.0778147503733635
    z[8,9,5]  R2859     2.7469709515571594e-01
    z[8,9,5]  R2860     -2.0084667205810547e-01
    z[8,9,5]  R2861     -3.0417975783348083e-01
    z[8,9,5]  R2862     -1.1976343393325806e-01
    z[8,9,5]  R2863     -3.0184416100382805e-02
    z[8,9,5]  R2864     -2.6337811350822449e-01
    z[8,9,5]  R2865     4.4822424650192261e-01
    z[8,9,5]  R2866     1.3516438007354736e-01
    z[8,9,5]  R2867     0.371501088142395
    z[8,9,5]  R2868     4.6095588803291321e-01
    z[8,9,5]  R2869     2.9762476682662964e-01
    z[8,9,5]  R2870     -4.3573114275932312e-01
    z[8,9,5]  R2871     -2.2947339713573456e-01
    z[8,9,5]  R2872     2.8953146934509277e-01
    z[8,9,5]  R2873     1.8770781159400940e-01
    z[8,9,5]  R2874     2.4617239832878113e-02
    z[8,9,5]  R2875     1.5098921954631805e-01
    z[8,9,5]  R2876     -1.7260673642158508e-01
    z[8,9,5]  R2877     -5.2695637941360474e-01
    z[8,9,5]  R2878     -2.2647507488727570e-01
    z[8,9,5]  R2879     -1.3525488972663879e-01
    z[8,9,5]  R2880     3.0662909150123596e-01
    z[8,9,5]  R2881     -1.7903931438922882e-01
    z[8,9,5]  R2882     1.5412282943725586e-01
    z[8,9,5]  R2883     2.3304232954978943e-01
    z[8,9,5]  R2884     3.4626227617263794e-01
    z[8,9,5]  R2885     0.53646320104599
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2814     -1
    z[8,9,6]  R2815     1
    z[8,9,6]  R2816     1.7721045017242432e-01
    z[8,9,6]  R2817     -3.3603328466415405e-01
    z[8,9,6]  R2818     -2.1940669417381287e-01
    z[8,9,6]  R2819     2.0136786997318268e-01
    z[8,9,6]  R2820     4.3996366858482361e-01
    z[8,9,6]  R2821     -2.1231368184089661e-01
    z[8,9,6]  R2822     -0.74248868227005
    z[8,9,6]  R2823     1.8393740057945251e-01
    z[8,9,6]  R2824     3.4053787589073181e-01
    z[8,9,6]  R2825     -3.7462761998176575e-01
    z[8,9,6]  R2826     7.9711131751537323e-02
    z[8,9,6]  R2827     2.2581171244382858e-02
    z[8,9,6]  R2828     -1.0665111243724823e-01
    z[8,9,6]  R2829     -1.7846764624118805e-01
    z[8,9,6]  R2830     -1.1625920981168747e-01
    z[8,9,6]  R2831     1.3823738694190979e-01
    z[8,9,6]  R2832     -1.4971335232257843e-01
    z[8,9,6]  R2833     2.9012712836265564e-01
    z[8,9,6]  R2834     0.0484800711274147
    z[8,9,6]  R2835     -1.9107541441917419e-01
    z[8,9,6]  R2836     4.3508040904998779e-01
    z[8,9,6]  R2837     1.4908677339553833e-01
    z[8,9,6]  R2838     3.7774410843849182e-01
    z[8,9,6]  R2839     9.7708672285079956e-02
    z[8,9,6]  R2840     1.3283225893974304e-01
    z[8,9,6]  R2841     -2.4021410942077637e-01
    z[8,9,6]  R2842     -5.6193929910659790e-01
    z[8,9,6]  R2843     1.6421730816364288e-01
    z[8,9,6]  R2844     -4.4859539717435837e-02
    z[8,9,6]  R2845     5.2844703197479248e-01
    z[8,9,6]  R2846     7.6997667551040649e-02
    z[8,9,6]  R2847     -1.7033047974109650e-01
    z[8,9,6]  R2848     -2.0931231847498566e-04
    z[8,9,6]  R2849     2.0268309116363525e-01
    z[8,9,6]  R2850     1.8692786991596222e-01
    z[8,9,6]  R2851     -0.0870007872581482
    z[8,9,6]  R2852     -1.9909110665321350e-01
    z[8,9,6]  R2853     -3.3920624852180481e-01
    z[8,9,6]  R2854     1.8302412331104279e-01
    z[8,9,6]  R2855     4.4053849577903748e-01
    z[8,9,6]  R2856     1.7088238894939423e-01
    z[8,9,6]  R2857     -1.8949435651302338e-01
    z[8,9,6]  R2858     -2.8667521476745605e-01
    z[8,9,6]  R2859     1.6458222270011902e-01
    z[8,9,6]  R2860     2.5363853573799133e-01
    z[8,9,6]  R2861     5.6849747896194458e-01
    z[8,9,6]  R2862     5.9675979614257812e-01
    z[8,9,6]  R2863     1.1810465157032013e-01
    z[8,9,6]  R2864     2.0851017534732819e-01
    z[8,9,6]  R2865     -1.1312078684568405e-01
    z[8,9,6]  R2866     -3.1195651739835739e-02
    z[8,9,6]  R2867     3.2639726996421814e-02
    z[8,9,6]  R2868     -2.2185422480106354e-01
    z[8,9,6]  R2869     2.5383546948432922e-01
    z[8,9,6]  R2870     -1.2012134492397308e-01
    z[8,9,6]  R2871     -7.8967171907424927e-01
    z[8,9,6]  R2872     -5.6475266814231873e-02
    z[8,9,6]  R2873     3.5991939902305603e-01
    z[8,9,6]  R2874     -6.2226498126983643e-01
    z[8,9,6]  R2875     -4.8943912982940674e-01
    z[8,9,6]  R2876     0.560827374458313
    z[8,9,6]  R2877     1.0953530669212341e-02
    z[8,9,6]  R2878     -0.649936318397522
    z[8,9,6]  R2879     -3.0012881755828857e-01
    z[8,9,6]  R2880     1.5112267434597015e-01
    z[8,9,6]  R2881     -5.3595972061157227e-01
    z[8,9,6]  R2882     -2.5471115112304688e-01
    z[8,9,6]  R2883     -2.7870258688926697e-01
    z[8,9,6]  R2884     8.3913028240203857e-02
    z[8,9,6]  R2885     1.0414987057447433e-01
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2886     -1
    z[9,8,0]  R2887     1
    z[9,8,0]  R2900     -6.4548724889755249e-01
    z[9,8,0]  R2901     -4.4700339436531067e-01
    z[9,8,0]  R2902     -5.7674968242645264e-01
    z[9,8,0]  R2903     -5.1093703508377075e-01
    z[9,8,0]  R2904     -1.0504309833049774e-01
    z[9,8,0]  R2905     -1.6773472726345062e-01
    z[9,8,0]  R2906     -4.2771536111831665e-01
    z[9,8,0]  R2907     3.5226613283157349e-01
    z[9,8,0]  R2908     1.7311668395996094e-01
    z[9,8,0]  R2909     4.0123113989830017e-01
    z[9,8,0]  R2910     0.0276805367320776
    z[9,8,0]  R2911     -3.9720579981803894e-01
    z[9,8,0]  R2912     -2.8522130846977234e-01
    z[9,8,0]  R2913     -6.4319148659706116e-02
    z[9,8,0]  R2914     6.8526464700698853e-01
    z[9,8,0]  R2915     3.9928045868873596e-01
    z[9,8,0]  R2916     -2.7383902668952942e-01
    z[9,8,0]  R2917     2.9671835899353027e-01
    z[9,8,0]  R2918     5.3257542848587036e-01
    z[9,8,0]  R2919     3.9325863122940063e-01
    z[9,8,0]  R2920     3.3369913697242737e-01
    z[9,8,0]  R2921     4.9956884980201721e-01
    z[9,8,0]  R2922     2.3757702112197876e-01
    z[9,8,0]  R2923     3.2133832573890686e-01
    z[9,8,0]  R2924     3.3036302775144577e-02
    z[9,8,0]  R2925     4.1061779856681824e-01
    z[9,8,0]  R2926     -1.7351135611534119e-02
    z[9,8,0]  R2927     2.0395504310727119e-02
    z[9,8,0]  R2928     -1.4109697937965393e-01
    z[9,8,0]  R2929     1.5128690004348755e-01
    z[9,8,0]  R2930     -4.4458016753196716e-01
    z[9,8,0]  R2931     -5.4850107431411743e-01
    z[9,8,0]  R2932     -4.5679804682731628e-01
    z[9,8,0]  R2933     -5.3019177913665771e-01
    z[9,8,0]  R2934     -2.9695528745651245e-01
    z[9,8,0]  R2935     0.423216313123703
    z[9,8,0]  R2936     4.9933582544326782e-01
    z[9,8,0]  R2937     3.6802518367767334e-01
    z[9,8,0]  R2938     -2.4371489882469177e-02
    z[9,8,0]  R2939     3.4120373427867889e-02
    z[9,8,0]  R2940     -3.4763745963573456e-02
    z[9,8,0]  R2941     5.6848841905593872e-01
    z[9,8,0]  R2942     -3.4385025501251221e-01
    z[9,8,0]  R2943     1.7285591363906860e-01
    z[9,8,0]  R2944     4.4793954491615295e-01
    z[9,8,0]  R2945     8.7197288870811462e-02
    z[9,8,0]  R2946     2.3777349293231964e-01
    z[9,8,0]  R2947     6.7076951265335083e-01
    z[9,8,0]  R2948     7.3758906126022339e-01
    z[9,8,0]  R2949     3.9325261116027832e-01
    z[9,8,0]  R2950     -3.5049572587013245e-01
    z[9,8,0]  R2951     -6.2821739912033081e-01
    z[9,8,0]  R2952     -4.1651833802461624e-02
    z[9,8,0]  R2953     -1.3105449080467224e-01
    z[9,8,0]  R2954     3.7713015079498291e-01
    z[9,8,0]  R2955     4.3652275204658508e-01
    z[9,8,0]  R2956     2.2517924010753632e-01
    z[9,8,0]  R2957     8.0271774530410767e-01
    z[9,8,0]  R2958     3.5582551360130310e-01
    z[9,8,0]  R2959     4.1191452741622925e-01
    z[9,8,0]  R2960     -3.2250946760177612e-01
    z[9,8,0]  R2961     0.61336749792099
    z[9,8,0]  R2962     3.8357287645339966e-01
    z[9,8,0]  R2963     2.3956814408302307e-01
    z[9,8,0]  R2964     5.6480652093887329e-01
    z[9,8,0]  R2965     6.6074001789093018e-01
    z[9,8,0]  R2966     5.9936910867691040e-01
    z[9,8,0]  R2967     7.1849167346954346e-01
    z[9,8,0]  R2968     4.0731152892112732e-01
    z[9,8,0]  R2969     3.0544099211692810e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2888     -1
    z[9,8,1]  R2889     1
    z[9,8,1]  R2900     2.2078971564769745e-01
    z[9,8,1]  R2901     2.4528747797012329e-01
    z[9,8,1]  R2902     2.2886614501476288e-01
    z[9,8,1]  R2903     6.2833614647388458e-02
    z[9,8,1]  R2904     0.0522940419614315
    z[9,8,1]  R2905     -2.3030752781778574e-03
    z[9,8,1]  R2906     3.7983089685440063e-01
    z[9,8,1]  R2907     4.4141745567321777e-01
    z[9,8,1]  R2908     2.0452353358268738e-01
    z[9,8,1]  R2909     -2.5731673836708069e-01
    z[9,8,1]  R2910     3.0860263109207153e-01
    z[9,8,1]  R2911     2.1323890984058380e-01
    z[9,8,1]  R2912     2.2095717489719391e-01
    z[9,8,1]  R2913     4.7474063932895660e-02
    z[9,8,1]  R2914     -4.9295875430107117e-01
    z[9,8,1]  R2915     1.2208233773708344e-01
    z[9,8,1]  R2916     -8.2709372043609619e-01
    z[9,8,1]  R2917     -7.6416867971420288e-01
    z[9,8,1]  R2918     -4.6448597311973572e-01
    z[9,8,1]  R2919     -7.0766109228134155e-01
    z[9,8,1]  R2920     3.9264941215515137e-01
    z[9,8,1]  R2921     2.8469431400299072e-01
    z[9,8,1]  R2922     3.3902174234390259e-01
    z[9,8,1]  R2923     -7.2685462236404419e-01
    z[9,8,1]  R2924     -8.2207417488098145e-01
    z[9,8,1]  R2925     -6.3087242841720581e-01
    z[9,8,1]  R2926     -6.2628740072250366e-01
    z[9,8,1]  R2927     -8.5059094429016113e-01
    z[9,8,1]  R2928     -4.3481594324111938e-01
    z[9,8,1]  R2929     -4.0053021907806396e-01
    z[9,8,1]  R2930     -1.4952081441879272e-01
    z[9,8,1]  R2931     -3.4902659058570862e-01
    z[9,8,1]  R2932     -1.8333059549331665e-01
    z[9,8,1]  R2933     -3.7707424163818359e-01
    z[9,8,1]  R2934     -2.2114260494709015e-01
    z[9,8,1]  R2935     -4.8019373416900635e-01
    z[9,8,1]  R2936     2.3389001190662384e-01
    z[9,8,1]  R2937     6.8756383657455444e-01
    z[9,8,1]  R2938     7.1067267656326294e-01
    z[9,8,1]  R2939     4.1083535552024841e-01
    z[9,8,1]  R2940     -6.6959851980209351e-01
    z[9,8,1]  R2941     3.6577469110488892e-01
    z[9,8,1]  R2942     -3.5648050904273987e-01
    z[9,8,1]  R2943     -2.8611627221107483e-01
    z[9,8,1]  R2944     4.1512030363082886e-01
    z[9,8,1]  R2945     4.0920725464820862e-01
    z[9,8,1]  R2946     7.3018616437911987e-01
    z[9,8,1]  R2947     4.6719476580619812e-01
    z[9,8,1]  R2948     7.3564932681620121e-03
    z[9,8,1]  R2949     7.6251387596130371e-01
    z[9,8,1]  R2950     -4.7746515274047852e-01
    z[9,8,1]  R2951     -0.389955997467041
    z[9,8,1]  R2952     -5.7755655050277710e-01
    z[9,8,1]  R2953     -0.517392098903656
    z[9,8,1]  R2954     -5.5999320745468140e-01
    z[9,8,1]  R2955     -5.9310501813888550e-01
    z[9,8,1]  R2956     -6.5441983938217163e-01
    z[9,8,1]  R2957     4.1583898663520813e-01
    z[9,8,1]  R2958     6.2891805171966553e-01
    z[9,8,1]  R2959     5.0711423158645630e-01
    z[9,8,1]  R2960     -7.9809540510177612e-01
    z[9,8,1]  R2961     5.7353240251541138e-01
    z[9,8,1]  R2962     5.6229871511459351e-01
    z[9,8,1]  R2963     6.2847858667373657e-01
    z[9,8,1]  R2964     5.8387905359268188e-01
    z[9,8,1]  R2965     5.1069349050521851e-01
    z[9,8,1]  R2966     5.4953384399414062e-01
    z[9,8,1]  R2967     4.4973301887512207e-01
    z[9,8,1]  R2968     8.3884263038635254e-01
    z[9,8,1]  R2969     -6.1183761805295944e-02
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2890     -1
    z[9,8,2]  R2891     1
    z[9,8,2]  R2900     2.4331012368202209e-01
    z[9,8,2]  R2901     -1.3265152275562286e-01
    z[9,8,2]  R2902     1.2788438796997070e-01
    z[9,8,2]  R2903     2.6188468933105469e-01
    z[9,8,2]  R2904     4.9405732750892639e-01
    z[9,8,2]  R2905     4.7037251293659210e-02
    z[9,8,2]  R2906     -2.5888139009475708e-01
    z[9,8,2]  R2907     -5.1113259792327881e-01
    z[9,8,2]  R2908     -8.2068789005279541e-01
    z[9,8,2]  R2909     -7.1421772241592407e-01
    z[9,8,2]  R2910     7.4786305427551270e-01
    z[9,8,2]  R2911     -1.1644738167524338e-01
    z[9,8,2]  R2912     3.0187538266181946e-01
    z[9,8,2]  R2913     3.9523360133171082e-01
    z[9,8,2]  R2914     -1.0738720744848251e-01
    z[9,8,2]  R2915     7.8273884952068329e-02
    z[9,8,2]  R2916     -2.1103464066982269e-01
    z[9,8,2]  R2917     -1.7358438670635223e-01
    z[9,8,2]  R2918     -1.4429225027561188e-01
    z[9,8,2]  R2919     -1.3068130612373352e-01
    z[9,8,2]  R2920     3.3380672335624695e-01
    z[9,8,2]  R2921     0.0972277969121933
    z[9,8,2]  R2922     -4.9237540364265442e-01
    z[9,8,2]  R2923     -2.4246707558631897e-01
    z[9,8,2]  R2924     -3.6731344461441040e-01
    z[9,8,2]  R2925     2.0351560413837433e-01
    z[9,8,2]  R2926     -7.0530956983566284e-01
    z[9,8,2]  R2927     3.3843708038330078e-01
    z[9,8,2]  R2928     -8.0793344974517822e-01
    z[9,8,2]  R2929     -7.0788913965225220e-01
    z[9,8,2]  R2930     -7.2313450276851654e-02
    z[9,8,2]  R2931     -2.0828001201152802e-01
    z[9,8,2]  R2932     -6.3222104310989380e-01
    z[9,8,2]  R2933     -4.7749385237693787e-01
    z[9,8,2]  R2934     -3.7537348270416260e-01
    z[9,8,2]  R2935     7.1288786828517914e-02
    z[9,8,2]  R2936     -1.4393082261085510e-01
    z[9,8,2]  R2937     -4.0629264712333679e-01
    z[9,8,2]  R2938     -1.8006415665149689e-01
    z[9,8,2]  R2939     2.5981557369232178e-01
    z[9,8,2]  R2940     5.2251034975051880e-01
    z[9,8,2]  R2941     3.0749738216400146e-01
    z[9,8,2]  R2942     5.0228524208068848e-01
    z[9,8,2]  R2943     7.8247189521789551e-01
    z[9,8,2]  R2944     -2.6841390132904053e-01
    z[9,8,2]  R2945     7.8740239143371582e-02
    z[9,8,2]  R2946     1.1565643548965454e-01
    z[9,8,2]  R2947     2.5839990004897118e-02
    z[9,8,2]  R2948     5.9660609811544418e-02
    z[9,8,2]  R2949     -2.1689200401306152e-01
    z[9,8,2]  R2950     5.4515105485916138e-01
    z[9,8,2]  R2951     4.6969360113143921e-01
    z[9,8,2]  R2952     0.602246880531311
    z[9,8,2]  R2953     7.4190104007720947e-01
    z[9,8,2]  R2954     4.8270988464355469e-01
    z[9,8,2]  R2955     9.3167677521705627e-02
    z[9,8,2]  R2956     1.3593721389770508e-01
    z[9,8,2]  R2957     2.1563434600830078e-01
    z[9,8,2]  R2958     3.4316802024841309e-01
    z[9,8,2]  R2959     3.7187594175338745e-01
    z[9,8,2]  R2960     3.0238366127014160e-01
    z[9,8,2]  R2961     2.5595375895500183e-01
    z[9,8,2]  R2962     -1.0048946738243103e-01
    z[9,8,2]  R2963     2.8736475110054016e-01
    z[9,8,2]  R2964     7.0928917266428471e-03
    z[9,8,2]  R2965     -2.4468369781970978e-02
    z[9,8,2]  R2966     -2.1538768708705902e-01
    z[9,8,2]  R2967     -8.2435399293899536e-02
    z[9,8,2]  R2968     -8.5262157022953033e-02
    z[9,8,2]  R2969     -6.4637726545333862e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2892     -1
    z[9,8,3]  R2893     1
    z[9,8,3]  R2900     6.4667350053787231e-01
    z[9,8,3]  R2901     8.1469595432281494e-01
    z[9,8,3]  R2902     5.7284229993820190e-01
    z[9,8,3]  R2903     5.4776233434677124e-01
    z[9,8,3]  R2904     7.6668906211853027e-01
    z[9,8,3]  R2905     0.730480432510376
    z[9,8,3]  R2906     4.7357723116874695e-01
    z[9,8,3]  R2907     -7.3143742978572845e-02
    z[9,8,3]  R2908     -0.0997811034321785
    z[9,8,3]  R2909     2.1516993641853333e-01
    z[9,8,3]  R2910     -5.5850225687026978e-01
    z[9,8,3]  R2911     -7.5867593288421631e-01
    z[9,8,3]  R2912     -7.0465826988220215e-01
    z[9,8,3]  R2913     -8.2727390527725220e-01
    z[9,8,3]  R2914     -9.1780357062816620e-02
    z[9,8,3]  R2915     -2.3147705197334290e-01
    z[9,8,3]  R2916     -5.9007301926612854e-02
    z[9,8,3]  R2917     -1.7165517807006836e-01
    z[9,8,3]  R2918     -7.4143759906291962e-02
    z[9,8,3]  R2919     -1.9601134955883026e-01
    z[9,8,3]  R2920     -5.2687042951583862e-01
    z[9,8,3]  R2921     -2.5929272174835205e-01
    z[9,8,3]  R2922     -1.1953826993703842e-01
    z[9,8,3]  R2923     4.2547813057899475e-01
    z[9,8,3]  R2924     -2.6645886898040771e-01
    z[9,8,3]  R2925     2.3811502754688263e-01
    z[9,8,3]  R2926     1.0545709729194641e-01
    z[9,8,3]  R2927     -1.3102434575557709e-01
    z[9,8,3]  R2928     -4.0756408125162125e-02
    z[9,8,3]  R2929     1.2913256883621216e-01
    z[9,8,3]  R2930     6.5955489873886108e-01
    z[9,8,3]  R2931     3.9239451289176941e-01
    z[9,8,3]  R2932     5.1759058237075806e-01
    z[9,8,3]  R2933     3.2264402508735657e-01
    z[9,8,3]  R2934     6.9359415769577026e-01
    z[9,8,3]  R2935     5.3478151559829712e-01
    z[9,8,3]  R2936     -3.4646943211555481e-01
    z[9,8,3]  R2937     -1.5794529020786285e-01
    z[9,8,3]  R2938     -4.2564994096755981e-01
    z[9,8,3]  R2939     -2.9889088869094849e-01
    z[9,8,3]  R2940     -0.246913343667984
    z[9,8,3]  R2941     -5.8031529188156128e-01
    z[9,8,3]  R2942     -4.8298770189285278e-01
    z[9,8,3]  R2943     2.2590008378028870e-01
    z[9,8,3]  R2944     -4.5573893189430237e-01
    z[9,8,3]  R2945     -7.6772612333297729e-01
    z[9,8,3]  R2946     -3.6979529261589050e-01
    z[9,8,3]  R2947     3.1639475375413895e-02
    z[9,8,3]  R2948     -1.9011195003986359e-01
    z[9,8,3]  R2949     -3.7013092637062073e-01
    z[9,8,3]  R2950     -1.6484716534614563e-01
    z[9,8,3]  R2951     -4.4422093033790588e-01
    z[9,8,3]  R2952     1.3290122151374817e-02
    z[9,8,3]  R2953     2.0788276195526123e-01
    z[9,8,3]  R2954     3.7719729542732239e-01
    z[9,8,3]  R2955     2.3343847692012787e-01
    z[9,8,3]  R2956     -1.9757138192653656e-01
    z[9,8,3]  R2957     -1.8459393084049225e-01
    z[9,8,3]  R2958     -4.4518882036209106e-01
    z[9,8,3]  R2959     -3.6890691518783569e-01
    z[9,8,3]  R2960     1.7020741105079651e-01
    z[9,8,3]  R2961     -3.6183488368988037e-01
    z[9,8,3]  R2962     -5.9311485290527344e-01
    z[9,8,3]  R2963     -0.547701895236969
    z[9,8,3]  R2964     -3.9181855320930481e-01
    z[9,8,3]  R2965     -3.5032054781913757e-01
    z[9,8,3]  R2966     -2.9732406139373779e-01
    z[9,8,3]  R2967     -2.0701327919960022e-01
    z[9,8,3]  R2968     -2.9160299897193909e-01
    z[9,8,3]  R2969     -3.5774287581443787e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2894     -1
    z[9,8,4]  R2895     1
    z[9,8,4]  R2900     -8.6017400026321411e-03
    z[9,8,4]  R2901     -1.5056072175502777e-01
    z[9,8,4]  R2902     4.2689535021781921e-01
    z[9,8,4]  R2903     -5.1363629102706909e-01
    z[9,8,4]  R2904     -2.2283342480659485e-01
    z[9,8,4]  R2905     1.4258655905723572e-01
    z[9,8,4]  R2906     1.0501173883676529e-01
    z[9,8,4]  R2907     -6.3213360309600830e-01
    z[9,8,4]  R2908     3.6314094066619873e-01
    z[9,8,4]  R2909     5.1917150616645813e-02
    z[9,8,4]  R2910     -1.1632586270570755e-01
    z[9,8,4]  R2911     2.6178082823753357e-01
    z[9,8,4]  R2912     -1.4302109181880951e-01
    z[9,8,4]  R2913     2.1030455827713013e-03
    z[9,8,4]  R2914     -2.5131186842918396e-01
    z[9,8,4]  R2915     2.9953831434249878e-01
    z[9,8,4]  R2916     3.2541179656982422e-01
    z[9,8,4]  R2917     -3.2191792130470276e-01
    z[9,8,4]  R2918     -2.9407319426536560e-01
    z[9,8,4]  R2919     -1.6345328092575073e-01
    z[9,8,4]  R2920     -3.3638164401054382e-02
    z[9,8,4]  R2921     5.6115162372589111e-01
    z[9,8,4]  R2922     0.313353568315506
    z[9,8,4]  R2923     -1.4223536849021912e-01
    z[9,8,4]  R2924     -1.7988644540309906e-02
    z[9,8,4]  R2925     1.2636347115039825e-01
    z[9,8,4]  R2926     1.0123517364263535e-01
    z[9,8,4]  R2927     1.1130163073539734e-01
    z[9,8,4]  R2928     -9.8336994647979736e-02
    z[9,8,4]  R2929     -1.6293426975607872e-02
    z[9,8,4]  R2930     -4.3225738406181335e-01
    z[9,8,4]  R2931     -9.6025556325912476e-02
    z[9,8,4]  R2932     -1.6930563747882843e-01
    z[9,8,4]  R2933     2.7070051431655884e-01
    z[9,8,4]  R2934     2.6033800095319748e-02
    z[9,8,4]  R2935     -3.9280074834823608e-01
    z[9,8,4]  R2936     4.7101568430662155e-02
    z[9,8,4]  R2937     2.0662312209606171e-01
    z[9,8,4]  R2938     -9.2706166207790375e-02
    z[9,8,4]  R2939     -6.0750108957290649e-01
    z[9,8,4]  R2940     4.5477354526519775e-01
    z[9,8,4]  R2941     3.3346363902091980e-01
    z[9,8,4]  R2942     -4.4939586520195007e-01
    z[9,8,4]  R2943     4.1626536846160889e-01
    z[9,8,4]  R2944     4.2432454228401184e-01
    z[9,8,4]  R2945     1.6459852457046509e-01
    z[9,8,4]  R2946     -1.6018894314765930e-01
    z[9,8,4]  R2947     4.6183064579963684e-01
    z[9,8,4]  R2948     5.1293474435806274e-01
    z[9,8,4]  R2949     -0.149389386177063
    z[9,8,4]  R2950     -2.1702152490615845e-01
    z[9,8,4]  R2951     -1.1448127776384354e-01
    z[9,8,4]  R2952     3.3909571170806885e-01
    z[9,8,4]  R2953     0.295040488243103
    z[9,8,4]  R2954     3.1525182723999023e-01
    z[9,8,4]  R2955     5.7058739662170410e-01
    z[9,8,4]  R2956     3.7303307652473450e-01
    z[9,8,4]  R2957     2.7416849136352539e-01
    z[9,8,4]  R2958     -2.0591799914836884e-01
    z[9,8,4]  R2959     1.2502770125865936e-01
    z[9,8,4]  R2960     -2.1284098923206329e-01
    z[9,8,4]  R2961     -9.3588627874851227e-02
    z[9,8,4]  R2962     2.4951553344726562e-01
    z[9,8,4]  R2963     1.8155282735824585e-01
    z[9,8,4]  R2964     1.0902238637208939e-01
    z[9,8,4]  R2965     -6.7754969000816345e-02
    z[9,8,4]  R2966     4.0493637323379517e-01
    z[9,8,4]  R2967     2.9204267263412476e-01
    z[9,8,4]  R2968     -3.8247697055339813e-02
    z[9,8,4]  R2969     8.6044125258922577e-02
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2896     -1
    z[9,8,5]  R2897     1
    z[9,8,5]  R2900     -1.6714364290237427e-01
    z[9,8,5]  R2901     -1.0922791436314583e-02
    z[9,8,5]  R2902     -0.0778147503733635
    z[9,8,5]  R2903     2.7469709515571594e-01
    z[9,8,5]  R2904     -2.0084667205810547e-01
    z[9,8,5]  R2905     -3.0417975783348083e-01
    z[9,8,5]  R2906     -1.1976343393325806e-01
    z[9,8,5]  R2907     -3.0184416100382805e-02
    z[9,8,5]  R2908     -2.6337811350822449e-01
    z[9,8,5]  R2909     4.4822424650192261e-01
    z[9,8,5]  R2910     1.3516438007354736e-01
    z[9,8,5]  R2911     0.371501088142395
    z[9,8,5]  R2912     4.6095588803291321e-01
    z[9,8,5]  R2913     2.9762476682662964e-01
    z[9,8,5]  R2914     -4.3573114275932312e-01
    z[9,8,5]  R2915     -2.2947339713573456e-01
    z[9,8,5]  R2916     2.8953146934509277e-01
    z[9,8,5]  R2917     1.8770781159400940e-01
    z[9,8,5]  R2918     2.4617239832878113e-02
    z[9,8,5]  R2919     1.5098921954631805e-01
    z[9,8,5]  R2920     -1.7260673642158508e-01
    z[9,8,5]  R2921     -5.2695637941360474e-01
    z[9,8,5]  R2922     -2.2647507488727570e-01
    z[9,8,5]  R2923     -1.3525488972663879e-01
    z[9,8,5]  R2924     3.0662909150123596e-01
    z[9,8,5]  R2925     -1.7903931438922882e-01
    z[9,8,5]  R2926     1.5412282943725586e-01
    z[9,8,5]  R2927     2.3304232954978943e-01
    z[9,8,5]  R2928     3.4626227617263794e-01
    z[9,8,5]  R2929     0.53646320104599
    z[9,8,5]  R2930     -3.4856861829757690e-01
    z[9,8,5]  R2931     -5.0777328014373779e-01
    z[9,8,5]  R2932     1.1540448665618896e-01
    z[9,8,5]  R2933     3.6164134740829468e-01
    z[9,8,5]  R2934     2.1607802808284760e-01
    z[9,8,5]  R2935     3.1600460410118103e-01
    z[9,8,5]  R2936     -4.1159119457006454e-02
    z[9,8,5]  R2937     3.5393068194389343e-01
    z[9,8,5]  R2938     3.9520743489265442e-01
    z[9,8,5]  R2939     -4.0473049879074097e-01
    z[9,8,5]  R2940     -5.7212188839912415e-02
    z[9,8,5]  R2941     1.1464828858152032e-03
    z[9,8,5]  R2942     2.3619933426380157e-01
    z[9,8,5]  R2943     -0.140846386551857
    z[9,8,5]  R2944     3.9206340909004211e-01
    z[9,8,5]  R2945     4.2794889211654663e-01
    z[9,8,5]  R2946     -4.6053481101989746e-01
    z[9,8,5]  R2947     -0.180740624666214
    z[9,8,5]  R2948     3.8827037811279297e-01
    z[9,8,5]  R2949     1.4511717855930328e-01
    z[9,8,5]  R2950     2.9735869169235229e-01
    z[9,8,5]  R2951     -2.2046746744308621e-04
    z[9,8,5]  R2952     -2.1009309589862823e-01
    z[9,8,5]  R2953     1.5780338644981384e-01
    z[9,8,5]  R2954     -2.2774039208889008e-01
    z[9,8,5]  R2955     -1.0596102476119995e-01
    z[9,8,5]  R2956     9.2661440372467041e-02
    z[9,8,5]  R2957     3.6456289235502481e-03
    z[9,8,5]  R2958     -3.4275129437446594e-01
    z[9,8,5]  R2959     6.2365125864744186e-02
    z[9,8,5]  R2960     2.9562655091285706e-01
    z[9,8,5]  R2961     -2.4623703956604004e-01
    z[9,8,5]  R2962     3.3548551797866821e-01
    z[9,8,5]  R2963     -3.0170193314552307e-01
    z[9,8,5]  R2964     3.7373638153076172e-01
    z[9,8,5]  R2965     4.0881726145744324e-01
    z[9,8,5]  R2966     -1.9105147570371628e-02
    z[9,8,5]  R2967     -1.7751030623912811e-01
    z[9,8,5]  R2968     5.6372337043285370e-02
    z[9,8,5]  R2969     -3.9458981156349182e-01
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2898     -1
    z[9,8,6]  R2899     1
    z[9,8,6]  R2900     1.7088238894939423e-01
    z[9,8,6]  R2901     -1.8949435651302338e-01
    z[9,8,6]  R2902     -2.8667521476745605e-01
    z[9,8,6]  R2903     1.6458222270011902e-01
    z[9,8,6]  R2904     2.5363853573799133e-01
    z[9,8,6]  R2905     5.6849747896194458e-01
    z[9,8,6]  R2906     5.9675979614257812e-01
    z[9,8,6]  R2907     1.1810465157032013e-01
    z[9,8,6]  R2908     2.0851017534732819e-01
    z[9,8,6]  R2909     -1.1312078684568405e-01
    z[9,8,6]  R2910     -3.1195651739835739e-02
    z[9,8,6]  R2911     3.2639726996421814e-02
    z[9,8,6]  R2912     -2.2185422480106354e-01
    z[9,8,6]  R2913     2.5383546948432922e-01
    z[9,8,6]  R2914     -1.2012134492397308e-01
    z[9,8,6]  R2915     -7.8967171907424927e-01
    z[9,8,6]  R2916     -5.6475266814231873e-02
    z[9,8,6]  R2917     3.5991939902305603e-01
    z[9,8,6]  R2918     -6.2226498126983643e-01
    z[9,8,6]  R2919     -4.8943912982940674e-01
    z[9,8,6]  R2920     0.560827374458313
    z[9,8,6]  R2921     1.0953530669212341e-02
    z[9,8,6]  R2922     -0.649936318397522
    z[9,8,6]  R2923     -3.0012881755828857e-01
    z[9,8,6]  R2924     1.5112267434597015e-01
    z[9,8,6]  R2925     -5.3595972061157227e-01
    z[9,8,6]  R2926     -2.5471115112304688e-01
    z[9,8,6]  R2927     -2.7870258688926697e-01
    z[9,8,6]  R2928     8.3913028240203857e-02
    z[9,8,6]  R2929     1.0414987057447433e-01
    z[9,8,6]  R2930     1.7721045017242432e-01
    z[9,8,6]  R2931     -3.3603328466415405e-01
    z[9,8,6]  R2932     -2.1940669417381287e-01
    z[9,8,6]  R2933     2.0136786997318268e-01
    z[9,8,6]  R2934     4.3996366858482361e-01
    z[9,8,6]  R2935     -2.1231368184089661e-01
    z[9,8,6]  R2936     -0.74248868227005
    z[9,8,6]  R2937     1.8393740057945251e-01
    z[9,8,6]  R2938     3.4053787589073181e-01
    z[9,8,6]  R2939     -3.7462761998176575e-01
    z[9,8,6]  R2940     7.9711131751537323e-02
    z[9,8,6]  R2941     2.2581171244382858e-02
    z[9,8,6]  R2942     -1.0665111243724823e-01
    z[9,8,6]  R2943     -1.7846764624118805e-01
    z[9,8,6]  R2944     -1.1625920981168747e-01
    z[9,8,6]  R2945     1.3823738694190979e-01
    z[9,8,6]  R2946     -1.4971335232257843e-01
    z[9,8,6]  R2947     2.9012712836265564e-01
    z[9,8,6]  R2948     0.0484800711274147
    z[9,8,6]  R2949     -1.9107541441917419e-01
    z[9,8,6]  R2950     4.3508040904998779e-01
    z[9,8,6]  R2951     1.4908677339553833e-01
    z[9,8,6]  R2952     3.7774410843849182e-01
    z[9,8,6]  R2953     9.7708672285079956e-02
    z[9,8,6]  R2954     1.3283225893974304e-01
    z[9,8,6]  R2955     -2.4021410942077637e-01
    z[9,8,6]  R2956     -5.6193929910659790e-01
    z[9,8,6]  R2957     1.6421730816364288e-01
    z[9,8,6]  R2958     -4.4859539717435837e-02
    z[9,8,6]  R2959     5.2844703197479248e-01
    z[9,8,6]  R2960     7.6997667551040649e-02
    z[9,8,6]  R2961     -1.7033047974109650e-01
    z[9,8,6]  R2962     -2.0931231847498566e-04
    z[9,8,6]  R2963     2.0268309116363525e-01
    z[9,8,6]  R2964     1.8692786991596222e-01
    z[9,8,6]  R2965     -0.0870007872581482
    z[9,8,6]  R2966     -1.9909110665321350e-01
    z[9,8,6]  R2967     -3.3920624852180481e-01
    z[9,8,6]  R2968     1.8302412331104279e-01
    z[9,8,6]  R2969     4.4053849577903748e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R90       1
    RHS1      R91       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[0,6]
 BV BND1      phi[6,0]
 BV BND1      phi[10,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,8]
 BV BND1      phi[8,3]
 BV BND1      phi[3,9]
 BV BND1      phi[9,3]
 BV BND1      phi[4,9]
 BV BND1      phi[9,4]
 BV BND1      phi[4,11]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[10,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,11]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[0,6,0]
 FR BND1      z[0,6,1]
 FR BND1      z[0,6,2]
 FR BND1      z[0,6,3]
 FR BND1      z[0,6,4]
 FR BND1      z[0,6,5]
 FR BND1      z[0,6,6]
 FR BND1      z[6,0,0]
 FR BND1      z[6,0,1]
 FR BND1      z[6,0,2]
 FR BND1      z[6,0,3]
 FR BND1      z[6,0,4]
 FR BND1      z[6,0,5]
 FR BND1      z[6,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,8,0]
 FR BND1      z[3,8,1]
 FR BND1      z[3,8,2]
 FR BND1      z[3,8,3]
 FR BND1      z[3,8,4]
 FR BND1      z[3,8,5]
 FR BND1      z[3,8,6]
 FR BND1      z[8,3,0]
 FR BND1      z[8,3,1]
 FR BND1      z[8,3,2]
 FR BND1      z[8,3,3]
 FR BND1      z[8,3,4]
 FR BND1      z[8,3,5]
 FR BND1      z[8,3,6]
 FR BND1      z[3,9,0]
 FR BND1      z[3,9,1]
 FR BND1      z[3,9,2]
 FR BND1      z[3,9,3]
 FR BND1      z[3,9,4]
 FR BND1      z[3,9,5]
 FR BND1      z[3,9,6]
 FR BND1      z[9,3,0]
 FR BND1      z[9,3,1]
 FR BND1      z[9,3,2]
 FR BND1      z[9,3,3]
 FR BND1      z[9,3,4]
 FR BND1      z[9,3,5]
 FR BND1      z[9,3,6]
 FR BND1      z[4,9,0]
 FR BND1      z[4,9,1]
 FR BND1      z[4,9,2]
 FR BND1      z[4,9,3]
 FR BND1      z[4,9,4]
 FR BND1      z[4,9,5]
 FR BND1      z[4,9,6]
 FR BND1      z[9,4,0]
 FR BND1      z[9,4,1]
 FR BND1      z[9,4,2]
 FR BND1      z[9,4,3]
 FR BND1      z[9,4,4]
 FR BND1      z[9,4,5]
 FR BND1      z[9,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
ENDATA
