NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       2.7008094787597656e+00
    phi[0,1]  R80       2.9423434734344482e+00
    phi[0,1]  R81       1.3048038482666016e+00
    phi[0,1]  R82       2.1839542388916016e+00
    phi[0,1]  R83       5.9856587648391724e-01
    phi[0,1]  R84       1.2843897342681885e+00
    phi[0,1]  R85       7.3068797588348389e-01
    phi[0,1]  R86       1.1818537712097168e+00
    phi[0,1]  R87       2.0249953269958496e+00
    phi[0,1]  R88       1.8040227890014648e+00
    phi[0,1]  R89       9.1845383867621422e-03
    phi[0,1]  R90       5.0237709283828735e-01
    phi[0,1]  R91       6.4863033592700958e-02
    phi[0,1]  R92       -1.5499385595321655e+00
    phi[0,1]  R93       -5.1743102073669434e-01
    phi[0,1]  R94       1.3209247589111328e-01
    phi[0,1]  R95       -1.4712499380111694e+00
    phi[0,1]  R96       8.5666114091873169e-01
    phi[0,1]  R97       -4.2244040966033936e-01
    phi[0,1]  R98       4.1526451706886292e-01
    phi[0,1]  R99       2.9089412093162537e-01
    phi[0,1]  R100      -1.5554897785186768e+00
    phi[0,1]  R101      -6.0135625302791595e-02
    phi[0,1]  R102      -1.3990097045898438e+00
    phi[0,1]  R103      -0.460441917181015
    phi[0,1]  R104      -1.5521408319473267e+00
    phi[0,1]  R105      0.395751953125
    phi[0,1]  R106      1.4217389747500420e-02
    phi[0,1]  R107      -1.9516204297542572e-01
    phi[0,1]  R108      -2.4324798583984375e+00
    phi[0,1]  R109      4.7721377015113831e-01
    phi[0,1]  R110      -5.8352375030517578e-01
    phi[0,1]  R111      -1.5069433450698853e+00
    phi[0,1]  R112      2.7136817574501038e-01
    phi[0,1]  R113      -1.2887331247329712e+00
    phi[0,1]  R114      7.1446937322616577e-01
    phi[0,1]  R115      -3.6254629492759705e-01
    phi[0,1]  R116      -7.2702020406723022e-01
    phi[0,1]  R117      -1.4106545448303223e+00
    phi[0,1]  R118      1.6881334781646729e+00
    phi[0,1]  R119      9.7508877515792847e-02
    phi[0,1]  R120      4.1329422593116760e-01
    phi[0,1]  R121      2.1722049713134766e+00
    phi[0,1]  R122      2.9597279429435730e-01
    phi[0,1]  R123      -3.5690584778785706e-01
    phi[0,1]  R124      -4.2878893017768860e-01
    phi[0,1]  R125      1.7423198223114014e+00
    phi[0,1]  R126      -5.2622210979461670e-01
    phi[0,1]  R127      -7.5246471166610718e-01
    phi[0,1]  R128      -5.3038060665130615e-02
    phi[0,1]  R129      7.4944800138473511e-01
    phi[0,1]  R130      7.6051235198974609e-01
    phi[0,1]  R131      -5.3711110353469849e-01
    phi[0,1]  R132      -6.9262200593948364e-01
    phi[0,1]  R133      -1.8059158697724342e-02
    phi[0,1]  R134      -1.9528608024120331e-01
    phi[0,1]  R135      -2.2749717235565186e+00
    phi[0,1]  R136      -1.3266341686248779e+00
    phi[0,1]  R137      -1.3349442481994629e+00
    phi[0,1]  R138      -2.2676289081573486e+00
    phi[0,1]  R139      -3.5531699657440186e-01
    phi[0,1]  R140      2.9937701225280762e+00
    phi[0,1]  R141      -9.0654975175857544e-01
    phi[0,1]  R142      1.4413275718688965e+00
    phi[0,1]  R143      -1.2324402332305908e+00
    phi[0,1]  R144      -1.7904045581817627e+00
    phi[0,1]  R145      -1.6254502534866333e+00
    phi[0,1]  R146      -2.7227997779846191e+00
    phi[0,1]  R147      -1.6479588747024536e+00
    phi[0,1]  R148      -2.6164932250976562e+00
    phi[0,1]  R149      9.2479670047760010e-01
    phi[0,1]  R150      5.8587819337844849e-01
    phi[0,1]  R151      2.1718363761901855e+00
    phi[0,1]  R152      2.3761842250823975e+00
    phi[0,1]  R153      1.3257734775543213e+00
    phi[0,1]  R154      2.91545033454895
    phi[0,1]  R155      1.7615007162094116e+00
    phi[0,1]  R156      -3.4013921022415161e-01
    phi[0,1]  R157      2.2066427767276764e-01
    phi[0,1]  R158      1.1798669099807739e+00
    phi[0,1]  R159      -1.4253823757171631e+00
    phi[0,1]  R160      -7.7125579118728638e-01
    phi[0,1]  R161      -1.3651198148727417e+00
    phi[0,1]  R162      -4.2086154222488403e-01
    phi[0,1]  R163      -1.3938299417495728e+00
    phi[0,1]  R164      -1.0939667224884033e+00
    phi[0,1]  R165      -1.8648535013198853e+00
    phi[0,1]  R166      -6.6122666001319885e-02
    phi[0,1]  R167      2.5188708305358887e-01
    phi[0,1]  R168      -2.8323154449462891e+00
    phi[0,1]  R169      2.6295294761657715e+00
    phi[0,1]  R170      1.7572919130325317e+00
    phi[0,1]  R171      -1.0829428434371948e+00
    phi[0,1]  R172      -4.3217343091964722e-01
    phi[0,1]  R173      -4.5466306805610657e-01
    phi[0,1]  R174      -4.7807395458221436e-01
    phi[0,1]  R175      -4.0644267201423645e-01
    phi[0,1]  R176      -1.5824794769287109e+00
    phi[0,1]  R177      -1.6067605018615723e+00
    phi[0,1]  R178      -1.1331107616424561e+00
    phi[0,1]  R179      1.0116927623748779e+00
    phi[0,1]  R180      1.0848578214645386e+00
    phi[0,1]  R181      -2.3093180358409882e-01
    phi[0,1]  R182      -1.1310173273086548e+00
    phi[0,1]  R183      -1.4873573780059814e+00
    phi[0,1]  R184      -1.7359263896942139e+00
    phi[0,1]  R185      -2.2480082511901855e+00
    phi[0,1]  R186      -1.8441220521926880e+00
    phi[0,1]  R187      3.0384758114814758e-01
    phi[0,1]  R188      -1.5255885124206543e+00
    phi[0,1]  R189      0.573358416557312
    phi[0,1]  R190      -1.1436494588851929e+00
    phi[0,1]  R191      -1.8349314928054810e+00
    phi[0,1]  R192      4.1966190934181213e-01
    phi[0,1]  R193      -1.4636507034301758e+00
    phi[0,1]  R194      -1.1290291547775269e+00
    phi[0,1]  R195      -1.9055145978927612e+00
    phi[0,1]  R196      -1.0711185932159424e+00
    phi[0,1]  R197      -7.7521079778671265e-01
    phi[0,1]  R198      -2.0303359031677246e+00
    phi[0,1]  R199      1.2600655555725098e+00
    phi[0,1]  R200      -2.4972167015075684e+00
    phi[0,1]  R201      -1.5432132482528687e+00
    phi[0,1]  R202      -1.8630646467208862e+00
    phi[0,1]  R203      2.0126066207885742e+00
    phi[0,1]  R204      -1.3858135938644409e+00
    phi[0,1]  R205      -2.2476251125335693e+00
    phi[0,1]  R206      -2.4001924991607666e+00
    phi[0,1]  R207      -1.0957145690917969e+00
    phi[0,1]  R208      -1.8581986427307129e-01
    phi[0,1]  R209      1.9705526828765869e+00
    phi[0,1]  R210      -5.1655524969100952e-01
    phi[0,1]  R211      -3.4542664885520935e-02
    phi[0,1]  R212      -1.9831803441047668e-01
    phi[0,1]  R213      -1.4024254679679871e-01
    phi[0,1]  R214      1.6017103195190430e+00
    phi[0,1]  R215      -7.2152537107467651e-01
    phi[0,1]  R216      -2.6122667789459229e+00
    phi[0,1]  R217      -1.0658208280801773e-01
    phi[0,1]  R218      1.4751167595386505e-01
    phi[0,1]  R219      1.2642068862915039e+00
    phi[0,1]  R220      1.0144374370574951e+00
    phi[0,1]  R221      -2.2751955986022949e+00
    phi[0,1]  R222      -3.0022695064544678e+00
    phi[0,1]  R223      3.4350106120109558e-01
    phi[0,1]  R224      -3.1894639134407043e-01
    phi[0,1]  R225      -3.7860441207885742e-01
    phi[0,1]  R226      -1.3986974954605103e+00
    phi[0,1]  R227      -1.1441575288772583e+00
    phi[0,1]  R228      -0.957409679889679
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R229      -3.0999999046325684e+00
    phi[1,0]  R230      -3.0999999046325684e+00
    phi[1,0]  R231      -2.2400000095367432e+00
    phi[1,0]  R232      -2.2400000095367432e+00
    phi[1,0]  R233      -3.0999999046325684e+00
    phi[1,0]  R234      -3.0999999046325684e+00
    phi[1,0]  R235      -2.5699999332427979e+00
    phi[1,0]  R236      -2.5699999332427979e+00
    phi[1,0]  R237      -3.0999999046325684e+00
    phi[1,0]  R238      -3.0999999046325684e+00
    phi[1,0]  R239      -2.0899999141693115e+00
    phi[1,0]  R240      -2.0899999141693115e+00
    phi[1,0]  R241      -3.0999999046325684e+00
    phi[1,0]  R242      -3.0999999046325684e+00
    phi[1,0]  R243      9.2479670047760010e-01
    phi[1,0]  R244      5.8587819337844849e-01
    phi[1,0]  R245      2.1718363761901855e+00
    phi[1,0]  R246      2.3761842250823975e+00
    phi[1,0]  R247      1.3257734775543213e+00
    phi[1,0]  R248      2.91545033454895
    phi[1,0]  R249      1.7615007162094116e+00
    phi[1,0]  R250      -3.4013921022415161e-01
    phi[1,0]  R251      2.2066427767276764e-01
    phi[1,0]  R252      1.1798669099807739e+00
    phi[1,0]  R253      -1.4253823757171631e+00
    phi[1,0]  R254      -7.7125579118728638e-01
    phi[1,0]  R255      -1.3651198148727417e+00
    phi[1,0]  R256      -4.2086154222488403e-01
    phi[1,0]  R257      -1.3938299417495728e+00
    phi[1,0]  R258      -1.0939667224884033e+00
    phi[1,0]  R259      -1.8648535013198853e+00
    phi[1,0]  R260      -6.6122666001319885e-02
    phi[1,0]  R261      2.5188708305358887e-01
    phi[1,0]  R262      -2.8323154449462891e+00
    phi[1,0]  R263      2.6295294761657715e+00
    phi[1,0]  R264      1.7572919130325317e+00
    phi[1,0]  R265      -1.0829428434371948e+00
    phi[1,0]  R266      -4.3217343091964722e-01
    phi[1,0]  R267      -4.5466306805610657e-01
    phi[1,0]  R268      -4.7807395458221436e-01
    phi[1,0]  R269      -4.0644267201423645e-01
    phi[1,0]  R270      -1.5824794769287109e+00
    phi[1,0]  R271      -1.6067605018615723e+00
    phi[1,0]  R272      -1.1331107616424561e+00
    phi[1,0]  R273      1.0116927623748779e+00
    phi[1,0]  R274      1.0848578214645386e+00
    phi[1,0]  R275      -2.3093180358409882e-01
    phi[1,0]  R276      -1.1310173273086548e+00
    phi[1,0]  R277      -1.4873573780059814e+00
    phi[1,0]  R278      -1.7359263896942139e+00
    phi[1,0]  R279      -2.2480082511901855e+00
    phi[1,0]  R280      -1.8441220521926880e+00
    phi[1,0]  R281      3.0384758114814758e-01
    phi[1,0]  R282      -1.5255885124206543e+00
    phi[1,0]  R283      0.573358416557312
    phi[1,0]  R284      -1.1436494588851929e+00
    phi[1,0]  R285      -1.8349314928054810e+00
    phi[1,0]  R286      4.1966190934181213e-01
    phi[1,0]  R287      -1.4636507034301758e+00
    phi[1,0]  R288      -1.1290291547775269e+00
    phi[1,0]  R289      -1.9055145978927612e+00
    phi[1,0]  R290      -1.0711185932159424e+00
    phi[1,0]  R291      -7.7521079778671265e-01
    phi[1,0]  R292      -2.0303359031677246e+00
    phi[1,0]  R293      1.2600655555725098e+00
    phi[1,0]  R294      -2.4972167015075684e+00
    phi[1,0]  R295      -1.5432132482528687e+00
    phi[1,0]  R296      -1.8630646467208862e+00
    phi[1,0]  R297      2.0126066207885742e+00
    phi[1,0]  R298      -1.3858135938644409e+00
    phi[1,0]  R299      -2.2476251125335693e+00
    phi[1,0]  R300      -2.4001924991607666e+00
    phi[1,0]  R301      -1.0957145690917969e+00
    phi[1,0]  R302      -1.8581986427307129e-01
    phi[1,0]  R303      1.9705526828765869e+00
    phi[1,0]  R304      -5.1655524969100952e-01
    phi[1,0]  R305      -3.4542664885520935e-02
    phi[1,0]  R306      -1.9831803441047668e-01
    phi[1,0]  R307      -1.4024254679679871e-01
    phi[1,0]  R308      1.6017103195190430e+00
    phi[1,0]  R309      -7.2152537107467651e-01
    phi[1,0]  R310      -2.6122667789459229e+00
    phi[1,0]  R311      -1.0658208280801773e-01
    phi[1,0]  R312      1.4751167595386505e-01
    phi[1,0]  R313      1.2642068862915039e+00
    phi[1,0]  R314      1.0144374370574951e+00
    phi[1,0]  R315      -2.2751955986022949e+00
    phi[1,0]  R316      -3.0022695064544678e+00
    phi[1,0]  R317      3.4350106120109558e-01
    phi[1,0]  R318      -3.1894639134407043e-01
    phi[1,0]  R319      -3.7860441207885742e-01
    phi[1,0]  R320      -1.3986974954605103e+00
    phi[1,0]  R321      -1.1441575288772583e+00
    phi[1,0]  R322      -0.957409679889679
    phi[1,0]  R323      2.7008094787597656e+00
    phi[1,0]  R324      2.9423434734344482e+00
    phi[1,0]  R325      1.3048038482666016e+00
    phi[1,0]  R326      2.1839542388916016e+00
    phi[1,0]  R327      5.9856587648391724e-01
    phi[1,0]  R328      1.2843897342681885e+00
    phi[1,0]  R329      7.3068797588348389e-01
    phi[1,0]  R330      1.1818537712097168e+00
    phi[1,0]  R331      2.0249953269958496e+00
    phi[1,0]  R332      1.8040227890014648e+00
    phi[1,0]  R333      9.1845383867621422e-03
    phi[1,0]  R334      5.0237709283828735e-01
    phi[1,0]  R335      6.4863033592700958e-02
    phi[1,0]  R336      -1.5499385595321655e+00
    phi[1,0]  R337      -5.1743102073669434e-01
    phi[1,0]  R338      1.3209247589111328e-01
    phi[1,0]  R339      -1.4712499380111694e+00
    phi[1,0]  R340      8.5666114091873169e-01
    phi[1,0]  R341      -4.2244040966033936e-01
    phi[1,0]  R342      4.1526451706886292e-01
    phi[1,0]  R343      2.9089412093162537e-01
    phi[1,0]  R344      -1.5554897785186768e+00
    phi[1,0]  R345      -6.0135625302791595e-02
    phi[1,0]  R346      -1.3990097045898438e+00
    phi[1,0]  R347      -0.460441917181015
    phi[1,0]  R348      -1.5521408319473267e+00
    phi[1,0]  R349      0.395751953125
    phi[1,0]  R350      1.4217389747500420e-02
    phi[1,0]  R351      -1.9516204297542572e-01
    phi[1,0]  R352      -2.4324798583984375e+00
    phi[1,0]  R353      4.7721377015113831e-01
    phi[1,0]  R354      -5.8352375030517578e-01
    phi[1,0]  R355      -1.5069433450698853e+00
    phi[1,0]  R356      2.7136817574501038e-01
    phi[1,0]  R357      -1.2887331247329712e+00
    phi[1,0]  R358      7.1446937322616577e-01
    phi[1,0]  R359      -3.6254629492759705e-01
    phi[1,0]  R360      -7.2702020406723022e-01
    phi[1,0]  R361      -1.4106545448303223e+00
    phi[1,0]  R362      1.6881334781646729e+00
    phi[1,0]  R363      9.7508877515792847e-02
    phi[1,0]  R364      4.1329422593116760e-01
    phi[1,0]  R365      2.1722049713134766e+00
    phi[1,0]  R366      2.9597279429435730e-01
    phi[1,0]  R367      -3.5690584778785706e-01
    phi[1,0]  R368      -4.2878893017768860e-01
    phi[1,0]  R369      1.7423198223114014e+00
    phi[1,0]  R370      -5.2622210979461670e-01
    phi[1,0]  R371      -7.5246471166610718e-01
    phi[1,0]  R372      -5.3038060665130615e-02
    phi[1,0]  R373      7.4944800138473511e-01
    phi[1,0]  R374      7.6051235198974609e-01
    phi[1,0]  R375      -5.3711110353469849e-01
    phi[1,0]  R376      -6.9262200593948364e-01
    phi[1,0]  R377      -1.8059158697724342e-02
    phi[1,0]  R378      -1.9528608024120331e-01
    phi[1,0]  R379      -2.2749717235565186e+00
    phi[1,0]  R380      -1.3266341686248779e+00
    phi[1,0]  R381      -1.3349442481994629e+00
    phi[1,0]  R382      -2.2676289081573486e+00
    phi[1,0]  R383      -3.5531699657440186e-01
    phi[1,0]  R384      2.9937701225280762e+00
    phi[1,0]  R385      -9.0654975175857544e-01
    phi[1,0]  R386      1.4413275718688965e+00
    phi[1,0]  R387      -1.2324402332305908e+00
    phi[1,0]  R388      -1.7904045581817627e+00
    phi[1,0]  R389      -1.6254502534866333e+00
    phi[1,0]  R390      -2.7227997779846191e+00
    phi[1,0]  R391      -1.6479588747024536e+00
    phi[1,0]  R392      -2.6164932250976562e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R393      -3.0999999046325684e+00
    phi[0,4]  R394      -3.0999999046325684e+00
    phi[0,4]  R395      -2.2400000095367432e+00
    phi[0,4]  R396      -2.2400000095367432e+00
    phi[0,4]  R397      -3.0999999046325684e+00
    phi[0,4]  R398      -3.0999999046325684e+00
    phi[0,4]  R399      -2.5699999332427979e+00
    phi[0,4]  R400      -2.5699999332427979e+00
    phi[0,4]  R401      -3.0999999046325684e+00
    phi[0,4]  R402      -3.0999999046325684e+00
    phi[0,4]  R403      -2.0899999141693115e+00
    phi[0,4]  R404      -2.0899999141693115e+00
    phi[0,4]  R405      -3.0999999046325684e+00
    phi[0,4]  R406      -3.0999999046325684e+00
    phi[0,4]  R407      2.7008094787597656e+00
    phi[0,4]  R408      2.9423434734344482e+00
    phi[0,4]  R409      1.3048038482666016e+00
    phi[0,4]  R410      2.1839542388916016e+00
    phi[0,4]  R411      5.9856587648391724e-01
    phi[0,4]  R412      1.2843897342681885e+00
    phi[0,4]  R413      7.3068797588348389e-01
    phi[0,4]  R414      1.1818537712097168e+00
    phi[0,4]  R415      2.0249953269958496e+00
    phi[0,4]  R416      1.8040227890014648e+00
    phi[0,4]  R417      9.1845383867621422e-03
    phi[0,4]  R418      5.0237709283828735e-01
    phi[0,4]  R419      6.4863033592700958e-02
    phi[0,4]  R420      -1.5499385595321655e+00
    phi[0,4]  R421      -5.1743102073669434e-01
    phi[0,4]  R422      1.3209247589111328e-01
    phi[0,4]  R423      -1.4712499380111694e+00
    phi[0,4]  R424      8.5666114091873169e-01
    phi[0,4]  R425      -4.2244040966033936e-01
    phi[0,4]  R426      4.1526451706886292e-01
    phi[0,4]  R427      2.9089412093162537e-01
    phi[0,4]  R428      -1.5554897785186768e+00
    phi[0,4]  R429      -6.0135625302791595e-02
    phi[0,4]  R430      -1.3990097045898438e+00
    phi[0,4]  R431      -0.460441917181015
    phi[0,4]  R432      -1.5521408319473267e+00
    phi[0,4]  R433      0.395751953125
    phi[0,4]  R434      1.4217389747500420e-02
    phi[0,4]  R435      -1.9516204297542572e-01
    phi[0,4]  R436      -2.4324798583984375e+00
    phi[0,4]  R437      4.7721377015113831e-01
    phi[0,4]  R438      -5.8352375030517578e-01
    phi[0,4]  R439      -1.5069433450698853e+00
    phi[0,4]  R440      2.7136817574501038e-01
    phi[0,4]  R441      -1.2887331247329712e+00
    phi[0,4]  R442      7.1446937322616577e-01
    phi[0,4]  R443      -3.6254629492759705e-01
    phi[0,4]  R444      -7.2702020406723022e-01
    phi[0,4]  R445      -1.4106545448303223e+00
    phi[0,4]  R446      1.6881334781646729e+00
    phi[0,4]  R447      9.7508877515792847e-02
    phi[0,4]  R448      4.1329422593116760e-01
    phi[0,4]  R449      2.1722049713134766e+00
    phi[0,4]  R450      2.9597279429435730e-01
    phi[0,4]  R451      -3.5690584778785706e-01
    phi[0,4]  R452      -4.2878893017768860e-01
    phi[0,4]  R453      1.7423198223114014e+00
    phi[0,4]  R454      -5.2622210979461670e-01
    phi[0,4]  R455      -7.5246471166610718e-01
    phi[0,4]  R456      -5.3038060665130615e-02
    phi[0,4]  R457      7.4944800138473511e-01
    phi[0,4]  R458      7.6051235198974609e-01
    phi[0,4]  R459      -5.3711110353469849e-01
    phi[0,4]  R460      -6.9262200593948364e-01
    phi[0,4]  R461      -1.8059158697724342e-02
    phi[0,4]  R462      -1.9528608024120331e-01
    phi[0,4]  R463      -2.2749717235565186e+00
    phi[0,4]  R464      -1.3266341686248779e+00
    phi[0,4]  R465      -1.3349442481994629e+00
    phi[0,4]  R466      -2.2676289081573486e+00
    phi[0,4]  R467      -3.5531699657440186e-01
    phi[0,4]  R468      2.9937701225280762e+00
    phi[0,4]  R469      -9.0654975175857544e-01
    phi[0,4]  R470      1.4413275718688965e+00
    phi[0,4]  R471      -1.2324402332305908e+00
    phi[0,4]  R472      -1.7904045581817627e+00
    phi[0,4]  R473      -1.6254502534866333e+00
    phi[0,4]  R474      -2.7227997779846191e+00
    phi[0,4]  R475      -1.6479588747024536e+00
    phi[0,4]  R476      -2.6164932250976562e+00
    phi[0,4]  R477      1.1403337717056274e+00
    phi[0,4]  R478      2.2187242507934570e+00
    phi[0,4]  R479      1.2167351245880127e+00
    phi[0,4]  R480      1.2702466249465942e+00
    phi[0,4]  R481      -6.1477798223495483e-01
    phi[0,4]  R482      2.1411089897155762e+00
    phi[0,4]  R483      1.9234117269515991e+00
    phi[0,4]  R484      9.2122542858123779e-01
    phi[0,4]  R485      -2.7807433605194092e+00
    phi[0,4]  R486      -8.6972367763519287e-01
    phi[0,4]  R487      -2.5525028705596924e+00
    phi[0,4]  R488      -1.4669482707977295e+00
    phi[0,4]  R489      -4.1162583231925964e-01
    phi[0,4]  R490      6.4589112997055054e-01
    phi[0,4]  R491      -3.2548463344573975e-01
    phi[0,4]  R492      9.3752861022949219e-01
    phi[0,4]  R493      -1.5661417245864868e+00
    phi[0,4]  R494      1.4478644728660583e-01
    phi[0,4]  R495      -1.9105530977249146e+00
    phi[0,4]  R496      -1.6939067840576172e+00
    phi[0,4]  R497      1.1600785255432129e+00
    phi[0,4]  R498      1.6215798854827881e+00
    phi[0,4]  R499      1.0405100584030151e+00
    phi[0,4]  R500      -2.9920685291290283e-01
    phi[0,4]  R501      1.2267171144485474e+00
    phi[0,4]  R502      1.2808082103729248e+00
    phi[0,4]  R503      1.10845947265625
    phi[0,4]  R504      -9.7849303483963013e-01
    phi[0,4]  R505      -5.4005157947540283e-01
    phi[0,4]  R506      4.7007542848587036e-01
    phi[0,4]  R507      4.6532204747200012e-01
    phi[0,4]  R508      1.2916998863220215e+00
    phi[0,4]  R509      7.2122913599014282e-01
    phi[0,4]  R510      1.0154050588607788e+00
    phi[0,4]  R511      2.3482432365417480e+00
    phi[0,4]  R512      1.4233335256576538e+00
    phi[0,4]  R513      1.0756527185440063e+00
    phi[0,4]  R514      1.5872042179107666e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R515      -3.0999999046325684e+00
    phi[4,0]  R516      -3.0999999046325684e+00
    phi[4,0]  R517      -2.2400000095367432e+00
    phi[4,0]  R518      -2.2400000095367432e+00
    phi[4,0]  R519      -3.0999999046325684e+00
    phi[4,0]  R520      -3.0999999046325684e+00
    phi[4,0]  R521      -2.5699999332427979e+00
    phi[4,0]  R522      -2.5699999332427979e+00
    phi[4,0]  R523      -3.0999999046325684e+00
    phi[4,0]  R524      -3.0999999046325684e+00
    phi[4,0]  R525      -2.0899999141693115e+00
    phi[4,0]  R526      -2.0899999141693115e+00
    phi[4,0]  R527      -3.0999999046325684e+00
    phi[4,0]  R528      -3.0999999046325684e+00
    phi[4,0]  R529      1.1403337717056274e+00
    phi[4,0]  R530      2.2187242507934570e+00
    phi[4,0]  R531      1.2167351245880127e+00
    phi[4,0]  R532      1.2702466249465942e+00
    phi[4,0]  R533      -6.1477798223495483e-01
    phi[4,0]  R534      1.3048038482666016e+00
    phi[4,0]  R535      2.1411089897155762e+00
    phi[4,0]  R536      1.9234117269515991e+00
    phi[4,0]  R537      9.2122542858123779e-01
    phi[4,0]  R538      -2.7807433605194092e+00
    phi[4,0]  R539      -8.6972367763519287e-01
    phi[4,0]  R540      -2.5525028705596924e+00
    phi[4,0]  R541      -1.4669482707977295e+00
    phi[4,0]  R542      -4.1162583231925964e-01
    phi[4,0]  R543      6.4589112997055054e-01
    phi[4,0]  R544      -3.2548463344573975e-01
    phi[4,0]  R545      9.3752861022949219e-01
    phi[4,0]  R546      -1.5661417245864868e+00
    phi[4,0]  R547      1.4478644728660583e-01
    phi[4,0]  R548      -1.9105530977249146e+00
    phi[4,0]  R549      -1.6939067840576172e+00
    phi[4,0]  R550      1.1600785255432129e+00
    phi[4,0]  R551      1.6215798854827881e+00
    phi[4,0]  R552      1.0405100584030151e+00
    phi[4,0]  R553      -2.9920685291290283e-01
    phi[4,0]  R554      1.2267171144485474e+00
    phi[4,0]  R555      1.2808082103729248e+00
    phi[4,0]  R556      1.10845947265625
    phi[4,0]  R557      -9.7849303483963013e-01
    phi[4,0]  R558      -5.4005157947540283e-01
    phi[4,0]  R559      4.7007542848587036e-01
    phi[4,0]  R560      4.6532204747200012e-01
    phi[4,0]  R561      1.2916998863220215e+00
    phi[4,0]  R562      7.2122913599014282e-01
    phi[4,0]  R563      1.0154050588607788e+00
    phi[4,0]  R564      2.3482432365417480e+00
    phi[4,0]  R565      1.4233335256576538e+00
    phi[4,0]  R566      1.0756527185440063e+00
    phi[4,0]  R567      1.5872042179107666e+00
    phi[4,0]  R568      2.7008094787597656e+00
    phi[4,0]  R569      2.9423434734344482e+00
    phi[4,0]  R570      2.1839542388916016e+00
    phi[4,0]  R571      5.9856587648391724e-01
    phi[4,0]  R572      1.2843897342681885e+00
    phi[4,0]  R573      7.3068797588348389e-01
    phi[4,0]  R574      1.1818537712097168e+00
    phi[4,0]  R575      2.0249953269958496e+00
    phi[4,0]  R576      1.8040227890014648e+00
    phi[4,0]  R577      9.1845383867621422e-03
    phi[4,0]  R578      5.0237709283828735e-01
    phi[4,0]  R579      6.4863033592700958e-02
    phi[4,0]  R580      -1.5499385595321655e+00
    phi[4,0]  R581      -5.1743102073669434e-01
    phi[4,0]  R582      1.3209247589111328e-01
    phi[4,0]  R583      -1.4712499380111694e+00
    phi[4,0]  R584      8.5666114091873169e-01
    phi[4,0]  R585      -4.2244040966033936e-01
    phi[4,0]  R586      4.1526451706886292e-01
    phi[4,0]  R587      2.9089412093162537e-01
    phi[4,0]  R588      -1.5554897785186768e+00
    phi[4,0]  R589      -6.0135625302791595e-02
    phi[4,0]  R590      -1.3990097045898438e+00
    phi[4,0]  R591      -0.460441917181015
    phi[4,0]  R592      -1.5521408319473267e+00
    phi[4,0]  R593      0.395751953125
    phi[4,0]  R594      1.4217389747500420e-02
    phi[4,0]  R595      -1.9516204297542572e-01
    phi[4,0]  R596      -2.4324798583984375e+00
    phi[4,0]  R597      4.7721377015113831e-01
    phi[4,0]  R598      -5.8352375030517578e-01
    phi[4,0]  R599      -1.5069433450698853e+00
    phi[4,0]  R600      2.7136817574501038e-01
    phi[4,0]  R601      -1.2887331247329712e+00
    phi[4,0]  R602      7.1446937322616577e-01
    phi[4,0]  R603      -3.6254629492759705e-01
    phi[4,0]  R604      -7.2702020406723022e-01
    phi[4,0]  R605      -1.4106545448303223e+00
    phi[4,0]  R606      1.6881334781646729e+00
    phi[4,0]  R607      9.7508877515792847e-02
    phi[4,0]  R608      4.1329422593116760e-01
    phi[4,0]  R609      2.1722049713134766e+00
    phi[4,0]  R610      2.9597279429435730e-01
    phi[4,0]  R611      -3.5690584778785706e-01
    phi[4,0]  R612      -4.2878893017768860e-01
    phi[4,0]  R613      1.7423198223114014e+00
    phi[4,0]  R614      -5.2622210979461670e-01
    phi[4,0]  R615      -7.5246471166610718e-01
    phi[4,0]  R616      -5.3038060665130615e-02
    phi[4,0]  R617      7.4944800138473511e-01
    phi[4,0]  R618      7.6051235198974609e-01
    phi[4,0]  R619      -5.3711110353469849e-01
    phi[4,0]  R620      -6.9262200593948364e-01
    phi[4,0]  R621      -1.8059158697724342e-02
    phi[4,0]  R622      -1.9528608024120331e-01
    phi[4,0]  R623      -2.2749717235565186e+00
    phi[4,0]  R624      -1.3266341686248779e+00
    phi[4,0]  R625      -1.3349442481994629e+00
    phi[4,0]  R626      -2.2676289081573486e+00
    phi[4,0]  R627      -3.5531699657440186e-01
    phi[4,0]  R628      2.9937701225280762e+00
    phi[4,0]  R629      -9.0654975175857544e-01
    phi[4,0]  R630      1.4413275718688965e+00
    phi[4,0]  R631      -1.2324402332305908e+00
    phi[4,0]  R632      -1.7904045581817627e+00
    phi[4,0]  R633      -1.6254502534866333e+00
    phi[4,0]  R634      -2.7227997779846191e+00
    phi[4,0]  R635      -1.6479588747024536e+00
    phi[4,0]  R636      -2.6164932250976562e+00
    phi[7,0]  R0        -1
    phi[7,0]  R2        -2.8603264434106697e+00
    phi[7,0]  R3        0.891117401530515
    phi[7,0]  R4        1.5049006028496676e+00
    phi[7,0]  R5        2.0325712769264768e+00
    phi[7,0]  R6        3.7566161019448296e-01
    phi[7,0]  R7        -6.2225911388230881e-01
    phi[7,0]  R8        6.7259382067619677e-01
    phi[7,0]  R63       1
    phi[7,0]  R637      -2.3967346122189870e-01
    phi[7,0]  R638      -5.9603263480432380e+00
    phi[7,0]  R639      -3.1311174110672582e+00
    phi[7,0]  R640      -1.3488826080062282e+00
    phi[7,0]  R641      -4.6049005074822364e+00
    phi[7,0]  R642      -1.5950993017829007e+00
    phi[7,0]  R643      -4.6025712101692751e+00
    phi[7,0]  R644      -5.3742865631632109e-01
    phi[7,0]  R645      -3.4756615148270513e+00
    phi[7,0]  R646      -2.7243382944380854e+00
    phi[7,0]  R647      -1.4677408002870027e+00
    phi[7,0]  R648      -2.71225902805162
    phi[7,0]  R649      -3.7725937253087651e+00
    phi[7,0]  R650      -2.4274060839563716e+00
    phi[7,0]  R651      -1.3126446873895192e-01
    phi[7,0]  R652      -1.7398153166397590e-01
    phi[7,0]  R653      -0.21514421226753
    phi[7,0]  R654      -2.2485377658780958e-01
    phi[7,0]  R655      -3.0847653266358477e-01
    phi[7,0]  R656      -3.2518762512725607e-01
    phi[7,0]  R657      -3.4307674821083411e-01
    phi[7,0]  R658      -3.4971005101340835e-01
    phi[7,0]  R659      -3.5394906581023022e-01
    phi[7,0]  R660      -3.9367765991763815e-01
    phi[7,0]  R661      -1.3481769681433764e-01
    phi[7,0]  R662      -1.4068020288518157e-01
    phi[7,0]  R663      -1.6323014941736277e-01
    phi[7,0]  R664      -1.6345628895588238e-01
    phi[7,0]  R665      -1.8830156590044023e-01
    phi[7,0]  R666      -1.9190783907797981e-01
    phi[7,0]  R667      -2.0322645567826214e-01
    phi[7,0]  R668      -2.2261318629156235e-01
    phi[7,0]  R669      -2.2291701994376809e-01
    phi[7,0]  R670      -2.2426077382428311e-01
    phi[7,0]  R671      -2.3999732678400276e-01
    phi[7,0]  R672      -2.6265069703103294e-01
    phi[7,0]  R673      -2.6890911156771408e-01
    phi[7,0]  R674      -2.7340208302572977e-01
    phi[7,0]  R675      -2.7512681738433675e-01
    phi[7,0]  R676      -2.7857399152246454e-01
    phi[7,0]  R677      -2.8731944250002106e-01
    phi[7,0]  R678      -2.9047181718121018e-01
    phi[7,0]  R679      -0.293058317819534
    phi[7,0]  R680      -2.9753614897960556e-01
    phi[7,0]  R681      -1.4710001852888022e-01
    phi[7,0]  R682      -1.9514702898950448e-01
    phi[7,0]  R683      -1.9827406880048426e-01
    phi[7,0]  R684      -2.3555269059315453e-01
    phi[7,0]  R685      -2.4002098749116074e-01
    phi[7,0]  R686      -2.4360026633846954e-01
    phi[7,0]  R687      -2.4860986376403615e-01
    phi[7,0]  R688      -2.4911043156519685e-01
    phi[7,0]  R689      -2.5043453724665277e-01
    phi[7,0]  R690      -2.5351453799882195e-01
    phi[7,0]  R691      -1.4920798802887514e-01
    phi[7,0]  R692      -1.6818961484612960e-01
    phi[7,0]  R693      -1.6940983864896397e-01
    phi[7,0]  R694      -1.7828120372696071e-01
    phi[7,0]  R695      -1.9511561169388753e-01
    phi[7,0]  R696      -2.0801974525761135e-01
    phi[7,0]  R697      -2.1980975040903705e-01
    phi[7,0]  R698      -2.2944433840166234e-01
    phi[7,0]  R699      -2.3364938554009251e-01
    phi[7,0]  R700      -2.4353371465597504e-01
    phi[7,0]  R701      -1.7495345631331649e-01
    phi[7,0]  R702      -1.7959795230991560e-01
    phi[7,0]  R703      -1.7982180488966099e-01
    phi[7,0]  R704      -2.0922251477228426e-01
    phi[7,0]  R705      -2.0924530689022197e-01
    phi[7,0]  R706      -2.1925925887715791e-01
    phi[7,0]  R707      -2.5222562939872395e-01
    phi[7,0]  R708      -2.6138234585944531e-01
    phi[7,0]  R709      -2.9710175167740771e-01
    phi[7,0]  R710      -3.6769618010259042e-01
    phi[7,0]  R711      -9.6486637074751969e-02
    phi[7,0]  R712      -1.1384624644945074e-01
    phi[7,0]  R713      -2.0662387595720377e-01
    phi[7,0]  R714      -2.1881987528997460e-01
    phi[7,0]  R715      -2.3526140933191186e-01
    phi[7,0]  R716      -2.4088880261258550e-01
    phi[7,0]  R717      -0.250556892183625
    phi[7,0]  R718      -3.5572652060960719e-01
    phi[7,0]  R719      -4.2525697053565237e-01
    phi[7,0]  R720      -4.8842453344817427e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R721      -3.0999999046325684e+00
    phi[1,2]  R722      -3.0999999046325684e+00
    phi[1,2]  R723      -2.2400000095367432e+00
    phi[1,2]  R724      -2.2400000095367432e+00
    phi[1,2]  R725      -3.0999999046325684e+00
    phi[1,2]  R726      -3.0999999046325684e+00
    phi[1,2]  R727      -2.5699999332427979e+00
    phi[1,2]  R728      -2.5699999332427979e+00
    phi[1,2]  R729      -3.0999999046325684e+00
    phi[1,2]  R730      -3.0999999046325684e+00
    phi[1,2]  R731      -2.0899999141693115e+00
    phi[1,2]  R732      -2.0899999141693115e+00
    phi[1,2]  R733      -3.0999999046325684e+00
    phi[1,2]  R734      -3.0999999046325684e+00
    phi[1,2]  R735      9.2479670047760010e-01
    phi[1,2]  R736      5.8587819337844849e-01
    phi[1,2]  R737      2.1718363761901855e+00
    phi[1,2]  R738      2.3761842250823975e+00
    phi[1,2]  R739      1.3257734775543213e+00
    phi[1,2]  R740      2.91545033454895
    phi[1,2]  R741      1.7615007162094116e+00
    phi[1,2]  R742      -3.4013921022415161e-01
    phi[1,2]  R743      2.2066427767276764e-01
    phi[1,2]  R744      1.1798669099807739e+00
    phi[1,2]  R745      -1.4253823757171631e+00
    phi[1,2]  R746      -7.7125579118728638e-01
    phi[1,2]  R747      -1.3651198148727417e+00
    phi[1,2]  R748      -4.2086154222488403e-01
    phi[1,2]  R749      -1.3938299417495728e+00
    phi[1,2]  R750      -1.0939667224884033e+00
    phi[1,2]  R751      -1.8648535013198853e+00
    phi[1,2]  R752      -6.6122666001319885e-02
    phi[1,2]  R753      2.5188708305358887e-01
    phi[1,2]  R754      -2.8323154449462891e+00
    phi[1,2]  R755      2.6295294761657715e+00
    phi[1,2]  R756      1.7572919130325317e+00
    phi[1,2]  R757      -1.0829428434371948e+00
    phi[1,2]  R758      -4.3217343091964722e-01
    phi[1,2]  R759      -4.5466306805610657e-01
    phi[1,2]  R760      -4.7807395458221436e-01
    phi[1,2]  R761      -4.0644267201423645e-01
    phi[1,2]  R762      -1.5824794769287109e+00
    phi[1,2]  R763      -1.6067605018615723e+00
    phi[1,2]  R764      -1.1331107616424561e+00
    phi[1,2]  R765      1.0116927623748779e+00
    phi[1,2]  R766      1.0848578214645386e+00
    phi[1,2]  R767      -2.3093180358409882e-01
    phi[1,2]  R768      -1.1310173273086548e+00
    phi[1,2]  R769      -1.4873573780059814e+00
    phi[1,2]  R770      -1.7359263896942139e+00
    phi[1,2]  R771      -2.2480082511901855e+00
    phi[1,2]  R772      -1.8441220521926880e+00
    phi[1,2]  R773      3.0384758114814758e-01
    phi[1,2]  R774      -1.5255885124206543e+00
    phi[1,2]  R775      0.573358416557312
    phi[1,2]  R776      -1.1436494588851929e+00
    phi[1,2]  R777      -1.8349314928054810e+00
    phi[1,2]  R778      4.1966190934181213e-01
    phi[1,2]  R779      -1.4636507034301758e+00
    phi[1,2]  R780      -1.1290291547775269e+00
    phi[1,2]  R781      -1.9055145978927612e+00
    phi[1,2]  R782      -1.0711185932159424e+00
    phi[1,2]  R783      -7.7521079778671265e-01
    phi[1,2]  R784      -2.0303359031677246e+00
    phi[1,2]  R785      1.2600655555725098e+00
    phi[1,2]  R786      -2.4972167015075684e+00
    phi[1,2]  R787      -1.5432132482528687e+00
    phi[1,2]  R788      -1.8630646467208862e+00
    phi[1,2]  R789      2.0126066207885742e+00
    phi[1,2]  R790      -1.3858135938644409e+00
    phi[1,2]  R791      -2.2476251125335693e+00
    phi[1,2]  R792      -2.4001924991607666e+00
    phi[1,2]  R793      -1.0957145690917969e+00
    phi[1,2]  R794      -1.8581986427307129e-01
    phi[1,2]  R795      1.9705526828765869e+00
    phi[1,2]  R796      -5.1655524969100952e-01
    phi[1,2]  R797      -3.4542664885520935e-02
    phi[1,2]  R798      -1.9831803441047668e-01
    phi[1,2]  R799      -1.4024254679679871e-01
    phi[1,2]  R800      1.6017103195190430e+00
    phi[1,2]  R801      -7.2152537107467651e-01
    phi[1,2]  R802      -2.6122667789459229e+00
    phi[1,2]  R803      -1.0658208280801773e-01
    phi[1,2]  R804      1.4751167595386505e-01
    phi[1,2]  R805      1.2642068862915039e+00
    phi[1,2]  R806      1.0144374370574951e+00
    phi[1,2]  R807      -2.2751955986022949e+00
    phi[1,2]  R808      -3.0022695064544678e+00
    phi[1,2]  R809      3.4350106120109558e-01
    phi[1,2]  R810      -3.1894639134407043e-01
    phi[1,2]  R811      -3.7860441207885742e-01
    phi[1,2]  R812      -1.3986974954605103e+00
    phi[1,2]  R813      -1.1441575288772583e+00
    phi[1,2]  R814      -0.957409679889679
    phi[1,2]  R815      0.869264543056488
    phi[1,2]  R816      8.0495625734329224e-01
    phi[1,2]  R817      -1.8013062477111816e+00
    phi[1,2]  R818      -7.7324277162551880e-01
    phi[1,2]  R819      1.9274877011775970e-01
    phi[1,2]  R820      -1.5505234897136688e-01
    phi[1,2]  R821      8.4718483686447144e-01
    phi[1,2]  R822      -1.6849370300769806e-01
    phi[1,2]  R823      3.6716657876968384e-01
    phi[1,2]  R824      2.6218071579933167e-02
    phi[1,2]  R825      -1.7875860631465912e-01
    phi[1,2]  R826      0.0358089916408062
    phi[1,2]  R827      6.8072825670242310e-01
    phi[1,2]  R828      6.9150112569332123e-02
    phi[1,2]  R829      3.4050163626670837e-01
    phi[1,2]  R830      -1.0912107229232788e+00
    phi[1,2]  R831      1.8743214011192322e-01
    phi[1,2]  R832      -5.4745352268218994e-01
    phi[1,2]  R833      -0.0281666349619627
    phi[1,2]  R834      9.7587215900421143e-01
    phi[1,2]  R835      3.0175495147705078e-01
    phi[1,2]  R836      -4.7132246196269989e-02
    phi[1,2]  R837      -5.9093236923217773e-01
    phi[1,2]  R838      -1.6270289421081543e+00
    phi[1,2]  R839      -1.2712978124618530e+00
    phi[1,2]  R840      -9.8178529739379883e-01
    phi[1,2]  R841      7.8718620538711548e-01
    phi[1,2]  R842      -1.4068396091461182e+00
    phi[1,2]  R843      -1.0365418195724487e+00
    phi[1,2]  R844      -1.4742389917373657e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R845      -3.0999999046325684e+00
    phi[2,1]  R846      -3.0999999046325684e+00
    phi[2,1]  R847      -2.2400000095367432e+00
    phi[2,1]  R848      -2.2400000095367432e+00
    phi[2,1]  R849      -3.0999999046325684e+00
    phi[2,1]  R850      -3.0999999046325684e+00
    phi[2,1]  R851      -2.5699999332427979e+00
    phi[2,1]  R852      -2.5699999332427979e+00
    phi[2,1]  R853      -3.0999999046325684e+00
    phi[2,1]  R854      -3.0999999046325684e+00
    phi[2,1]  R855      -2.0899999141693115e+00
    phi[2,1]  R856      -2.0899999141693115e+00
    phi[2,1]  R857      -3.0999999046325684e+00
    phi[2,1]  R858      -3.0999999046325684e+00
    phi[2,1]  R859      0.869264543056488
    phi[2,1]  R860      8.0495625734329224e-01
    phi[2,1]  R861      -1.8013062477111816e+00
    phi[2,1]  R862      -7.7324277162551880e-01
    phi[2,1]  R863      1.9274877011775970e-01
    phi[2,1]  R864      -1.5505234897136688e-01
    phi[2,1]  R865      8.4718483686447144e-01
    phi[2,1]  R866      -1.6849370300769806e-01
    phi[2,1]  R867      3.6716657876968384e-01
    phi[2,1]  R868      2.6218071579933167e-02
    phi[2,1]  R869      -1.7875860631465912e-01
    phi[2,1]  R870      0.0358089916408062
    phi[2,1]  R871      6.8072825670242310e-01
    phi[2,1]  R872      6.9150112569332123e-02
    phi[2,1]  R873      3.4050163626670837e-01
    phi[2,1]  R874      -1.0912107229232788e+00
    phi[2,1]  R875      1.8743214011192322e-01
    phi[2,1]  R876      -5.4745352268218994e-01
    phi[2,1]  R877      -0.0281666349619627
    phi[2,1]  R878      9.7587215900421143e-01
    phi[2,1]  R879      3.0175495147705078e-01
    phi[2,1]  R880      -4.7132246196269989e-02
    phi[2,1]  R881      -5.9093236923217773e-01
    phi[2,1]  R882      -1.6270289421081543e+00
    phi[2,1]  R883      -1.2712978124618530e+00
    phi[2,1]  R884      -9.8178529739379883e-01
    phi[2,1]  R885      7.8718620538711548e-01
    phi[2,1]  R886      -1.4068396091461182e+00
    phi[2,1]  R887      -1.0365418195724487e+00
    phi[2,1]  R888      -1.4742389917373657e+00
    phi[2,1]  R889      9.2479670047760010e-01
    phi[2,1]  R890      5.8587819337844849e-01
    phi[2,1]  R891      2.1718363761901855e+00
    phi[2,1]  R892      2.3761842250823975e+00
    phi[2,1]  R893      1.3257734775543213e+00
    phi[2,1]  R894      2.91545033454895
    phi[2,1]  R895      1.7615007162094116e+00
    phi[2,1]  R896      -3.4013921022415161e-01
    phi[2,1]  R897      2.2066427767276764e-01
    phi[2,1]  R898      1.1798669099807739e+00
    phi[2,1]  R899      -1.4253823757171631e+00
    phi[2,1]  R900      -7.7125579118728638e-01
    phi[2,1]  R901      -1.3651198148727417e+00
    phi[2,1]  R902      -4.2086154222488403e-01
    phi[2,1]  R903      -1.3938299417495728e+00
    phi[2,1]  R904      -1.0939667224884033e+00
    phi[2,1]  R905      -1.8648535013198853e+00
    phi[2,1]  R906      -6.6122666001319885e-02
    phi[2,1]  R907      2.5188708305358887e-01
    phi[2,1]  R908      -2.8323154449462891e+00
    phi[2,1]  R909      2.6295294761657715e+00
    phi[2,1]  R910      1.7572919130325317e+00
    phi[2,1]  R911      -1.0829428434371948e+00
    phi[2,1]  R912      -4.3217343091964722e-01
    phi[2,1]  R913      -4.5466306805610657e-01
    phi[2,1]  R914      -4.7807395458221436e-01
    phi[2,1]  R915      -4.0644267201423645e-01
    phi[2,1]  R916      -1.5824794769287109e+00
    phi[2,1]  R917      -1.6067605018615723e+00
    phi[2,1]  R918      -1.1331107616424561e+00
    phi[2,1]  R919      1.0116927623748779e+00
    phi[2,1]  R920      1.0848578214645386e+00
    phi[2,1]  R921      -2.3093180358409882e-01
    phi[2,1]  R922      -1.1310173273086548e+00
    phi[2,1]  R923      -1.4873573780059814e+00
    phi[2,1]  R924      -1.7359263896942139e+00
    phi[2,1]  R925      -2.2480082511901855e+00
    phi[2,1]  R926      -1.8441220521926880e+00
    phi[2,1]  R927      3.0384758114814758e-01
    phi[2,1]  R928      -1.5255885124206543e+00
    phi[2,1]  R929      0.573358416557312
    phi[2,1]  R930      -1.1436494588851929e+00
    phi[2,1]  R931      -1.8349314928054810e+00
    phi[2,1]  R932      4.1966190934181213e-01
    phi[2,1]  R933      -1.4636507034301758e+00
    phi[2,1]  R934      -1.1290291547775269e+00
    phi[2,1]  R935      -1.9055145978927612e+00
    phi[2,1]  R936      -1.0711185932159424e+00
    phi[2,1]  R937      -7.7521079778671265e-01
    phi[2,1]  R938      -2.0303359031677246e+00
    phi[2,1]  R939      1.2600655555725098e+00
    phi[2,1]  R940      -2.4972167015075684e+00
    phi[2,1]  R941      -1.5432132482528687e+00
    phi[2,1]  R942      -1.8630646467208862e+00
    phi[2,1]  R943      2.0126066207885742e+00
    phi[2,1]  R944      -1.3858135938644409e+00
    phi[2,1]  R945      -2.2476251125335693e+00
    phi[2,1]  R946      -2.4001924991607666e+00
    phi[2,1]  R947      -1.0957145690917969e+00
    phi[2,1]  R948      -1.8581986427307129e-01
    phi[2,1]  R949      1.9705526828765869e+00
    phi[2,1]  R950      -5.1655524969100952e-01
    phi[2,1]  R951      -3.4542664885520935e-02
    phi[2,1]  R952      -1.9831803441047668e-01
    phi[2,1]  R953      -1.4024254679679871e-01
    phi[2,1]  R954      1.6017103195190430e+00
    phi[2,1]  R955      -7.2152537107467651e-01
    phi[2,1]  R956      -2.6122667789459229e+00
    phi[2,1]  R957      -1.0658208280801773e-01
    phi[2,1]  R958      1.4751167595386505e-01
    phi[2,1]  R959      1.2642068862915039e+00
    phi[2,1]  R960      1.0144374370574951e+00
    phi[2,1]  R961      -2.2751955986022949e+00
    phi[2,1]  R962      -3.0022695064544678e+00
    phi[2,1]  R963      3.4350106120109558e-01
    phi[2,1]  R964      -3.1894639134407043e-01
    phi[2,1]  R965      -3.7860441207885742e-01
    phi[2,1]  R966      -1.3986974954605103e+00
    phi[2,1]  R967      -1.1441575288772583e+00
    phi[2,1]  R968      -0.957409679889679
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R969      -3.0999999046325684e+00
    phi[1,5]  R970      -3.0999999046325684e+00
    phi[1,5]  R971      -2.2400000095367432e+00
    phi[1,5]  R972      -2.2400000095367432e+00
    phi[1,5]  R973      -3.0999999046325684e+00
    phi[1,5]  R974      -3.0999999046325684e+00
    phi[1,5]  R975      -2.5699999332427979e+00
    phi[1,5]  R976      -2.5699999332427979e+00
    phi[1,5]  R977      -3.0999999046325684e+00
    phi[1,5]  R978      -3.0999999046325684e+00
    phi[1,5]  R979      -2.0899999141693115e+00
    phi[1,5]  R980      -2.0899999141693115e+00
    phi[1,5]  R981      -3.0999999046325684e+00
    phi[1,5]  R982      -3.0999999046325684e+00
    phi[1,5]  R983      9.2479670047760010e-01
    phi[1,5]  R984      5.8587819337844849e-01
    phi[1,5]  R985      2.1718363761901855e+00
    phi[1,5]  R986      2.3761842250823975e+00
    phi[1,5]  R987      1.3257734775543213e+00
    phi[1,5]  R988      2.91545033454895
    phi[1,5]  R989      1.7615007162094116e+00
    phi[1,5]  R990      -3.4013921022415161e-01
    phi[1,5]  R991      2.2066427767276764e-01
    phi[1,5]  R992      1.1798669099807739e+00
    phi[1,5]  R993      -1.4253823757171631e+00
    phi[1,5]  R994      -7.7125579118728638e-01
    phi[1,5]  R995      -1.3651198148727417e+00
    phi[1,5]  R996      -4.2086154222488403e-01
    phi[1,5]  R997      -1.3938299417495728e+00
    phi[1,5]  R998      -1.0939667224884033e+00
    phi[1,5]  R999      -1.8648535013198853e+00
    phi[1,5]  R1000     -6.6122666001319885e-02
    phi[1,5]  R1001     2.5188708305358887e-01
    phi[1,5]  R1002     -2.8323154449462891e+00
    phi[1,5]  R1003     2.6295294761657715e+00
    phi[1,5]  R1004     1.7572919130325317e+00
    phi[1,5]  R1005     -1.0829428434371948e+00
    phi[1,5]  R1006     -4.3217343091964722e-01
    phi[1,5]  R1007     -4.5466306805610657e-01
    phi[1,5]  R1008     -4.7807395458221436e-01
    phi[1,5]  R1009     -4.0644267201423645e-01
    phi[1,5]  R1010     -1.5824794769287109e+00
    phi[1,5]  R1011     -1.6067605018615723e+00
    phi[1,5]  R1012     -1.1331107616424561e+00
    phi[1,5]  R1013     1.0116927623748779e+00
    phi[1,5]  R1014     1.0848578214645386e+00
    phi[1,5]  R1015     -2.3093180358409882e-01
    phi[1,5]  R1016     -1.1310173273086548e+00
    phi[1,5]  R1017     -1.4873573780059814e+00
    phi[1,5]  R1018     -1.7359263896942139e+00
    phi[1,5]  R1019     -2.2480082511901855e+00
    phi[1,5]  R1020     -1.8441220521926880e+00
    phi[1,5]  R1021     3.0384758114814758e-01
    phi[1,5]  R1022     -1.5255885124206543e+00
    phi[1,5]  R1023     0.573358416557312
    phi[1,5]  R1024     -1.1436494588851929e+00
    phi[1,5]  R1025     -1.8349314928054810e+00
    phi[1,5]  R1026     4.1966190934181213e-01
    phi[1,5]  R1027     -1.4636507034301758e+00
    phi[1,5]  R1028     -1.1290291547775269e+00
    phi[1,5]  R1029     -1.9055145978927612e+00
    phi[1,5]  R1030     -1.0711185932159424e+00
    phi[1,5]  R1031     -7.7521079778671265e-01
    phi[1,5]  R1032     -2.0303359031677246e+00
    phi[1,5]  R1033     1.2600655555725098e+00
    phi[1,5]  R1034     -2.4972167015075684e+00
    phi[1,5]  R1035     -1.5432132482528687e+00
    phi[1,5]  R1036     -1.8630646467208862e+00
    phi[1,5]  R1037     2.0126066207885742e+00
    phi[1,5]  R1038     -1.3858135938644409e+00
    phi[1,5]  R1039     -2.2476251125335693e+00
    phi[1,5]  R1040     -2.4001924991607666e+00
    phi[1,5]  R1041     -1.0957145690917969e+00
    phi[1,5]  R1042     -1.8581986427307129e-01
    phi[1,5]  R1043     1.9705526828765869e+00
    phi[1,5]  R1044     -5.1655524969100952e-01
    phi[1,5]  R1045     -3.4542664885520935e-02
    phi[1,5]  R1046     -1.9831803441047668e-01
    phi[1,5]  R1047     -1.4024254679679871e-01
    phi[1,5]  R1048     1.6017103195190430e+00
    phi[1,5]  R1049     -7.2152537107467651e-01
    phi[1,5]  R1050     -2.6122667789459229e+00
    phi[1,5]  R1051     -1.0658208280801773e-01
    phi[1,5]  R1052     1.4751167595386505e-01
    phi[1,5]  R1053     1.2642068862915039e+00
    phi[1,5]  R1054     1.0144374370574951e+00
    phi[1,5]  R1055     -2.2751955986022949e+00
    phi[1,5]  R1056     -3.0022695064544678e+00
    phi[1,5]  R1057     3.4350106120109558e-01
    phi[1,5]  R1058     -3.1894639134407043e-01
    phi[1,5]  R1059     -3.7860441207885742e-01
    phi[1,5]  R1060     -1.3986974954605103e+00
    phi[1,5]  R1061     -1.1441575288772583e+00
    phi[1,5]  R1062     -0.957409679889679
    phi[1,5]  R1063     1.5325810015201569e-01
    phi[1,5]  R1064     5.7673519849777222e-01
    phi[1,5]  R1065     6.5352284908294678e-01
    phi[1,5]  R1066     5.8408007025718689e-02
    phi[1,5]  R1067     -2.3630050942301750e-02
    phi[1,5]  R1068     0.0279111098498106
    phi[1,5]  R1069     -1.1368327140808105e+00
    phi[1,5]  R1070     6.1336469650268555e-01
    phi[1,5]  R1071     1.2199049443006516e-01
    phi[1,5]  R1072     6.1222821474075317e-01
    phi[1,5]  R1073     -3.3533030748367310e-01
    phi[1,5]  R1074     -2.2070416808128357e-01
    phi[1,5]  R1075     2.0725883543491364e-02
    phi[1,5]  R1076     -3.5494214296340942e-01
    phi[1,5]  R1077     -7.1019774675369263e-01
    phi[1,5]  R1078     -4.6633702516555786e-01
    phi[1,5]  R1079     -4.7228738665580750e-02
    phi[1,5]  R1080     -3.6395901441574097e-01
    phi[1,5]  R1081     -3.0920368432998657e-01
    phi[1,5]  R1082     -5.9512734413146973e-02
    phi[1,5]  R1083     -1.5812058448791504e+00
    phi[1,5]  R1084     -1.1009780168533325e+00
    phi[1,5]  R1085     7.8923009335994720e-02
    phi[1,5]  R1086     5.1917374134063721e-01
    phi[1,5]  R1087     -7.4462151527404785e-01
    phi[1,5]  R1088     -2.3624037206172943e-01
    phi[1,5]  R1089     1.4395651221275330e-01
    phi[1,5]  R1090     -4.3079802393913269e-01
    phi[1,5]  R1091     -3.8315358757972717e-01
    phi[1,5]  R1092     -1.6121819019317627e+00
    phi[1,5]  R1093     -4.8885753750801086e-01
    phi[1,5]  R1094     -7.0004051923751831e-01
    phi[1,5]  R1095     -9.7059744596481323e-01
    phi[1,5]  R1096     -9.8894137144088745e-01
    phi[1,5]  R1097     3.3406534790992737e-01
    phi[1,5]  R1098     -7.3677271604537964e-01
    phi[1,5]  R1099     -1.4649345874786377e+00
    phi[1,5]  R1100     -2.0685672760009766e+00
    phi[1,5]  R1101     -4.3808495998382568e-01
    phi[1,5]  R1102     -4.4889110326766968e-01
    phi[1,5]  R1103     5.9810751676559448e-01
    phi[1,5]  R1104     -2.1640841960906982e+00
    phi[1,5]  R1105     -9.6639132499694824e-01
    phi[1,5]  R1106     6.5917536616325378e-02
    phi[1,5]  R1107     -4.7011050581932068e-01
    phi[1,5]  R1108     -1.7950711250305176e+00
    phi[1,5]  R1109     -1.9064352512359619e+00
    phi[1,5]  R1110     4.6391388773918152e-01
    phi[1,5]  R1111     -2.1599395275115967e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1112     -3.0999999046325684e+00
    phi[5,1]  R1113     -3.0999999046325684e+00
    phi[5,1]  R1114     -2.2400000095367432e+00
    phi[5,1]  R1115     -2.2400000095367432e+00
    phi[5,1]  R1116     -3.0999999046325684e+00
    phi[5,1]  R1117     -3.0999999046325684e+00
    phi[5,1]  R1118     -2.5699999332427979e+00
    phi[5,1]  R1119     -2.5699999332427979e+00
    phi[5,1]  R1120     -3.0999999046325684e+00
    phi[5,1]  R1121     -3.0999999046325684e+00
    phi[5,1]  R1122     -2.0899999141693115e+00
    phi[5,1]  R1123     -2.0899999141693115e+00
    phi[5,1]  R1124     -3.0999999046325684e+00
    phi[5,1]  R1125     -3.0999999046325684e+00
    phi[5,1]  R1126     1.5325810015201569e-01
    phi[5,1]  R1127     5.7673519849777222e-01
    phi[5,1]  R1128     6.5352284908294678e-01
    phi[5,1]  R1129     5.8408007025718689e-02
    phi[5,1]  R1130     -2.3630050942301750e-02
    phi[5,1]  R1131     0.0279111098498106
    phi[5,1]  R1132     -1.1368327140808105e+00
    phi[5,1]  R1133     6.1336469650268555e-01
    phi[5,1]  R1134     1.2199049443006516e-01
    phi[5,1]  R1135     6.1222821474075317e-01
    phi[5,1]  R1136     -3.3533030748367310e-01
    phi[5,1]  R1137     -2.2070416808128357e-01
    phi[5,1]  R1138     2.0725883543491364e-02
    phi[5,1]  R1139     -3.5494214296340942e-01
    phi[5,1]  R1140     -7.1019774675369263e-01
    phi[5,1]  R1141     -4.6633702516555786e-01
    phi[5,1]  R1142     -4.7228738665580750e-02
    phi[5,1]  R1143     -3.6395901441574097e-01
    phi[5,1]  R1144     -3.0920368432998657e-01
    phi[5,1]  R1145     -5.9512734413146973e-02
    phi[5,1]  R1146     -1.5812058448791504e+00
    phi[5,1]  R1147     -1.1009780168533325e+00
    phi[5,1]  R1148     7.8923009335994720e-02
    phi[5,1]  R1149     5.1917374134063721e-01
    phi[5,1]  R1150     -7.4462151527404785e-01
    phi[5,1]  R1151     -2.3624037206172943e-01
    phi[5,1]  R1152     1.4395651221275330e-01
    phi[5,1]  R1153     -4.3079802393913269e-01
    phi[5,1]  R1154     -3.8315358757972717e-01
    phi[5,1]  R1155     -1.6121819019317627e+00
    phi[5,1]  R1156     -4.8885753750801086e-01
    phi[5,1]  R1157     -7.0004051923751831e-01
    phi[5,1]  R1158     -9.7059744596481323e-01
    phi[5,1]  R1159     -9.8894137144088745e-01
    phi[5,1]  R1160     3.3406534790992737e-01
    phi[5,1]  R1161     -7.3677271604537964e-01
    phi[5,1]  R1162     -1.4649345874786377e+00
    phi[5,1]  R1163     -2.0685672760009766e+00
    phi[5,1]  R1164     -4.3808495998382568e-01
    phi[5,1]  R1165     -4.4889110326766968e-01
    phi[5,1]  R1166     5.9810751676559448e-01
    phi[5,1]  R1167     -2.1640841960906982e+00
    phi[5,1]  R1168     -9.6639132499694824e-01
    phi[5,1]  R1169     6.5917536616325378e-02
    phi[5,1]  R1170     -4.7011050581932068e-01
    phi[5,1]  R1171     -1.7950711250305176e+00
    phi[5,1]  R1172     -1.9064352512359619e+00
    phi[5,1]  R1173     4.6391388773918152e-01
    phi[5,1]  R1174     -2.1599395275115967e+00
    phi[5,1]  R1175     9.2479670047760010e-01
    phi[5,1]  R1176     5.8587819337844849e-01
    phi[5,1]  R1177     2.1718363761901855e+00
    phi[5,1]  R1178     2.3761842250823975e+00
    phi[5,1]  R1179     1.3257734775543213e+00
    phi[5,1]  R1180     2.91545033454895
    phi[5,1]  R1181     1.7615007162094116e+00
    phi[5,1]  R1182     -3.4013921022415161e-01
    phi[5,1]  R1183     2.2066427767276764e-01
    phi[5,1]  R1184     1.1798669099807739e+00
    phi[5,1]  R1185     -1.4253823757171631e+00
    phi[5,1]  R1186     -7.7125579118728638e-01
    phi[5,1]  R1187     -1.3651198148727417e+00
    phi[5,1]  R1188     -4.2086154222488403e-01
    phi[5,1]  R1189     -1.3938299417495728e+00
    phi[5,1]  R1190     -1.0939667224884033e+00
    phi[5,1]  R1191     -1.8648535013198853e+00
    phi[5,1]  R1192     -6.6122666001319885e-02
    phi[5,1]  R1193     2.5188708305358887e-01
    phi[5,1]  R1194     -2.8323154449462891e+00
    phi[5,1]  R1195     2.6295294761657715e+00
    phi[5,1]  R1196     1.7572919130325317e+00
    phi[5,1]  R1197     -1.0829428434371948e+00
    phi[5,1]  R1198     -4.3217343091964722e-01
    phi[5,1]  R1199     -4.5466306805610657e-01
    phi[5,1]  R1200     -4.7807395458221436e-01
    phi[5,1]  R1201     -4.0644267201423645e-01
    phi[5,1]  R1202     -1.5824794769287109e+00
    phi[5,1]  R1203     -1.6067605018615723e+00
    phi[5,1]  R1204     -1.1331107616424561e+00
    phi[5,1]  R1205     1.0116927623748779e+00
    phi[5,1]  R1206     1.0848578214645386e+00
    phi[5,1]  R1207     -2.3093180358409882e-01
    phi[5,1]  R1208     -1.1310173273086548e+00
    phi[5,1]  R1209     -1.4873573780059814e+00
    phi[5,1]  R1210     -1.7359263896942139e+00
    phi[5,1]  R1211     -2.2480082511901855e+00
    phi[5,1]  R1212     -1.8441220521926880e+00
    phi[5,1]  R1213     3.0384758114814758e-01
    phi[5,1]  R1214     -1.5255885124206543e+00
    phi[5,1]  R1215     0.573358416557312
    phi[5,1]  R1216     -1.1436494588851929e+00
    phi[5,1]  R1217     -1.8349314928054810e+00
    phi[5,1]  R1218     4.1966190934181213e-01
    phi[5,1]  R1219     -1.4636507034301758e+00
    phi[5,1]  R1220     -1.1290291547775269e+00
    phi[5,1]  R1221     -1.9055145978927612e+00
    phi[5,1]  R1222     -1.0711185932159424e+00
    phi[5,1]  R1223     -7.7521079778671265e-01
    phi[5,1]  R1224     -2.0303359031677246e+00
    phi[5,1]  R1225     1.2600655555725098e+00
    phi[5,1]  R1226     -2.4972167015075684e+00
    phi[5,1]  R1227     -1.5432132482528687e+00
    phi[5,1]  R1228     -1.8630646467208862e+00
    phi[5,1]  R1229     2.0126066207885742e+00
    phi[5,1]  R1230     -1.3858135938644409e+00
    phi[5,1]  R1231     -2.2476251125335693e+00
    phi[5,1]  R1232     -2.4001924991607666e+00
    phi[5,1]  R1233     -1.0957145690917969e+00
    phi[5,1]  R1234     -1.8581986427307129e-01
    phi[5,1]  R1235     1.9705526828765869e+00
    phi[5,1]  R1236     -5.1655524969100952e-01
    phi[5,1]  R1237     -3.4542664885520935e-02
    phi[5,1]  R1238     -1.9831803441047668e-01
    phi[5,1]  R1239     -1.4024254679679871e-01
    phi[5,1]  R1240     1.6017103195190430e+00
    phi[5,1]  R1241     -7.2152537107467651e-01
    phi[5,1]  R1242     -2.6122667789459229e+00
    phi[5,1]  R1243     -1.0658208280801773e-01
    phi[5,1]  R1244     1.4751167595386505e-01
    phi[5,1]  R1245     1.2642068862915039e+00
    phi[5,1]  R1246     1.0144374370574951e+00
    phi[5,1]  R1247     -2.2751955986022949e+00
    phi[5,1]  R1248     -3.0022695064544678e+00
    phi[5,1]  R1249     3.4350106120109558e-01
    phi[5,1]  R1250     -3.1894639134407043e-01
    phi[5,1]  R1251     -3.7860441207885742e-01
    phi[5,1]  R1252     -1.3986974954605103e+00
    phi[5,1]  R1253     -1.1441575288772583e+00
    phi[5,1]  R1254     -0.957409679889679
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1255     -3.0999999046325684e+00
    phi[2,3]  R1256     -3.0999999046325684e+00
    phi[2,3]  R1257     -2.2400000095367432e+00
    phi[2,3]  R1258     -2.2400000095367432e+00
    phi[2,3]  R1259     -3.0999999046325684e+00
    phi[2,3]  R1260     -3.0999999046325684e+00
    phi[2,3]  R1261     -2.5699999332427979e+00
    phi[2,3]  R1262     -2.5699999332427979e+00
    phi[2,3]  R1263     -3.0999999046325684e+00
    phi[2,3]  R1264     -3.0999999046325684e+00
    phi[2,3]  R1265     -2.0899999141693115e+00
    phi[2,3]  R1266     -2.0899999141693115e+00
    phi[2,3]  R1267     -3.0999999046325684e+00
    phi[2,3]  R1268     -3.0999999046325684e+00
    phi[2,3]  R1269     0.869264543056488
    phi[2,3]  R1270     8.0495625734329224e-01
    phi[2,3]  R1271     -1.8013062477111816e+00
    phi[2,3]  R1272     -7.7324277162551880e-01
    phi[2,3]  R1273     1.9274877011775970e-01
    phi[2,3]  R1274     -1.5505234897136688e-01
    phi[2,3]  R1275     8.4718483686447144e-01
    phi[2,3]  R1276     -1.6849370300769806e-01
    phi[2,3]  R1277     3.6716657876968384e-01
    phi[2,3]  R1278     2.6218071579933167e-02
    phi[2,3]  R1279     -1.7875860631465912e-01
    phi[2,3]  R1280     0.0358089916408062
    phi[2,3]  R1281     6.8072825670242310e-01
    phi[2,3]  R1282     6.9150112569332123e-02
    phi[2,3]  R1283     3.4050163626670837e-01
    phi[2,3]  R1284     -1.0912107229232788e+00
    phi[2,3]  R1285     1.8743214011192322e-01
    phi[2,3]  R1286     -5.4745352268218994e-01
    phi[2,3]  R1287     -0.0281666349619627
    phi[2,3]  R1288     9.7587215900421143e-01
    phi[2,3]  R1289     3.0175495147705078e-01
    phi[2,3]  R1290     -4.7132246196269989e-02
    phi[2,3]  R1291     -5.9093236923217773e-01
    phi[2,3]  R1292     -1.6270289421081543e+00
    phi[2,3]  R1293     -1.2712978124618530e+00
    phi[2,3]  R1294     -9.8178529739379883e-01
    phi[2,3]  R1295     7.8718620538711548e-01
    phi[2,3]  R1296     -1.4068396091461182e+00
    phi[2,3]  R1297     -1.0365418195724487e+00
    phi[2,3]  R1298     -1.4742389917373657e+00
    phi[2,3]  R1299     -3.5601980984210968e-02
    phi[2,3]  R1300     -2.0091648101806641e+00
    phi[2,3]  R1301     2.6701334118843079e-01
    phi[2,3]  R1302     -1.7497508227825165e-01
    phi[2,3]  R1303     1.9002988934516907e-02
    phi[2,3]  R1304     -1.1127890348434448e+00
    phi[2,3]  R1305     -7.0565289258956909e-01
    phi[2,3]  R1306     1.4529807567596436e+00
    phi[2,3]  R1307     1.2837707996368408e+00
    phi[2,3]  R1308     -2.7198210358619690e-01
    phi[2,3]  R1309     1.1850296258926392e+00
    phi[2,3]  R1310     8.0340665578842163e-01
    phi[2,3]  R1311     8.7472432851791382e-01
    phi[2,3]  R1312     1.0581958293914795e+00
    phi[2,3]  R1313     5.8327007293701172e-01
    phi[2,3]  R1314     0.373644083738327
    phi[2,3]  R1315     2.4458359181880951e-01
    phi[2,3]  R1316     -4.5529860258102417e-01
    phi[2,3]  R1317     -9.7418487071990967e-01
    phi[2,3]  R1318     -1.8380020558834076e-01
    phi[2,3]  R1319     -2.0293862819671631e+00
    phi[2,3]  R1320     -3.2236984372138977e-01
    phi[2,3]  R1321     -1.2023220062255859e+00
    phi[2,3]  R1322     -1.3782145977020264e+00
    phi[2,3]  R1323     5.4403585195541382e-01
    phi[2,3]  R1324     -2.8852421045303345e-01
    phi[2,3]  R1325     -6.2107962369918823e-01
    phi[2,3]  R1326     -1.8109947443008423e+00
    phi[2,3]  R1327     -1.5881599187850952e+00
    phi[2,3]  R1328     -2.1651620864868164e+00
    phi[2,3]  R1329     -1.6871854066848755e+00
    phi[2,3]  R1330     -2.7312755584716797e-01
    phi[2,3]  R1331     -1.7245821952819824e+00
    phi[2,3]  R1332     -9.9549138545989990e-01
    phi[2,3]  R1333     -2.3040804862976074e+00
    phi[2,3]  R1334     -1.8529220819473267e+00
    phi[2,3]  R1335     -2.0636497437953949e-01
    phi[2,3]  R1336     3.0884258449077606e-02
    phi[2,3]  R1337     1.7679098844528198e+00
    phi[2,3]  R1338     -3.9496263861656189e-01
    phi[2,3]  R1339     -1.1728961020708084e-02
    phi[2,3]  R1340     -3.1642013788223267e-01
    phi[2,3]  R1341     -2.3237879276275635e+00
    phi[2,3]  R1342     -1.2783237695693970e+00
    phi[2,3]  R1343     -1.1449443101882935e+00
    phi[2,3]  R1344     6.9839906692504883e-01
    phi[2,3]  R1345     -1.8353886604309082e+00
    phi[2,3]  R1346     -2.2414343357086182e+00
    phi[2,3]  R1347     -1.7773462533950806e+00
    phi[2,3]  R1348     -2.4791257381439209e+00
    phi[2,3]  R1349     -1.4807873964309692e+00
    phi[2,3]  R1350     -1.2853094339370728e+00
    phi[2,3]  R1351     -1.5846395492553711e+00
    phi[2,3]  R1352     -2.4775044918060303e+00
    phi[2,3]  R1353     -1.3673295974731445e+00
    phi[2,3]  R1354     -3.0236017704010010e-01
    phi[2,3]  R1355     -3.5025903582572937e-01
    phi[2,3]  R1356     -1.2491627931594849e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1357     -3.0999999046325684e+00
    phi[3,2]  R1358     -3.0999999046325684e+00
    phi[3,2]  R1359     -2.2400000095367432e+00
    phi[3,2]  R1360     -2.2400000095367432e+00
    phi[3,2]  R1361     -3.0999999046325684e+00
    phi[3,2]  R1362     -3.0999999046325684e+00
    phi[3,2]  R1363     -2.5699999332427979e+00
    phi[3,2]  R1364     -2.5699999332427979e+00
    phi[3,2]  R1365     -3.0999999046325684e+00
    phi[3,2]  R1366     -3.0999999046325684e+00
    phi[3,2]  R1367     -2.0899999141693115e+00
    phi[3,2]  R1368     -2.0899999141693115e+00
    phi[3,2]  R1369     -3.0999999046325684e+00
    phi[3,2]  R1370     -3.0999999046325684e+00
    phi[3,2]  R1371     -3.5601980984210968e-02
    phi[3,2]  R1372     -2.0091648101806641e+00
    phi[3,2]  R1373     2.6701334118843079e-01
    phi[3,2]  R1374     -1.7497508227825165e-01
    phi[3,2]  R1375     1.9002988934516907e-02
    phi[3,2]  R1376     -1.1127890348434448e+00
    phi[3,2]  R1377     -7.0565289258956909e-01
    phi[3,2]  R1378     1.4529807567596436e+00
    phi[3,2]  R1379     1.2837707996368408e+00
    phi[3,2]  R1380     -2.7198210358619690e-01
    phi[3,2]  R1381     1.1850296258926392e+00
    phi[3,2]  R1382     8.0340665578842163e-01
    phi[3,2]  R1383     8.7472432851791382e-01
    phi[3,2]  R1384     1.0581958293914795e+00
    phi[3,2]  R1385     5.8327007293701172e-01
    phi[3,2]  R1386     0.373644083738327
    phi[3,2]  R1387     2.4458359181880951e-01
    phi[3,2]  R1388     -4.5529860258102417e-01
    phi[3,2]  R1389     -9.7418487071990967e-01
    phi[3,2]  R1390     -1.8380020558834076e-01
    phi[3,2]  R1391     -2.0293862819671631e+00
    phi[3,2]  R1392     -3.2236984372138977e-01
    phi[3,2]  R1393     -1.2023220062255859e+00
    phi[3,2]  R1394     -1.3782145977020264e+00
    phi[3,2]  R1395     5.4403585195541382e-01
    phi[3,2]  R1396     -2.8852421045303345e-01
    phi[3,2]  R1397     -6.2107962369918823e-01
    phi[3,2]  R1398     -1.8109947443008423e+00
    phi[3,2]  R1399     -1.5881599187850952e+00
    phi[3,2]  R1400     -2.1651620864868164e+00
    phi[3,2]  R1401     -1.6871854066848755e+00
    phi[3,2]  R1402     -2.7312755584716797e-01
    phi[3,2]  R1403     -1.7245821952819824e+00
    phi[3,2]  R1404     -9.9549138545989990e-01
    phi[3,2]  R1405     -2.3040804862976074e+00
    phi[3,2]  R1406     -1.8529220819473267e+00
    phi[3,2]  R1407     -2.0636497437953949e-01
    phi[3,2]  R1408     3.0884258449077606e-02
    phi[3,2]  R1409     1.7679098844528198e+00
    phi[3,2]  R1410     -3.9496263861656189e-01
    phi[3,2]  R1411     -1.1728961020708084e-02
    phi[3,2]  R1412     -3.1642013788223267e-01
    phi[3,2]  R1413     -2.3237879276275635e+00
    phi[3,2]  R1414     -1.2783237695693970e+00
    phi[3,2]  R1415     -1.1449443101882935e+00
    phi[3,2]  R1416     6.9839906692504883e-01
    phi[3,2]  R1417     -1.8353886604309082e+00
    phi[3,2]  R1418     -2.2414343357086182e+00
    phi[3,2]  R1419     -1.7773462533950806e+00
    phi[3,2]  R1420     -2.4791257381439209e+00
    phi[3,2]  R1421     -1.4807873964309692e+00
    phi[3,2]  R1422     -1.2853094339370728e+00
    phi[3,2]  R1423     -1.5846395492553711e+00
    phi[3,2]  R1424     -2.4775044918060303e+00
    phi[3,2]  R1425     -1.3673295974731445e+00
    phi[3,2]  R1426     -3.0236017704010010e-01
    phi[3,2]  R1427     -3.5025903582572937e-01
    phi[3,2]  R1428     -1.2491627931594849e+00
    phi[3,2]  R1429     0.869264543056488
    phi[3,2]  R1430     8.0495625734329224e-01
    phi[3,2]  R1431     -1.8013062477111816e+00
    phi[3,2]  R1432     -7.7324277162551880e-01
    phi[3,2]  R1433     1.9274877011775970e-01
    phi[3,2]  R1434     -1.5505234897136688e-01
    phi[3,2]  R1435     8.4718483686447144e-01
    phi[3,2]  R1436     -1.6849370300769806e-01
    phi[3,2]  R1437     3.6716657876968384e-01
    phi[3,2]  R1438     2.6218071579933167e-02
    phi[3,2]  R1439     -1.7875860631465912e-01
    phi[3,2]  R1440     0.0358089916408062
    phi[3,2]  R1441     6.8072825670242310e-01
    phi[3,2]  R1442     6.9150112569332123e-02
    phi[3,2]  R1443     3.4050163626670837e-01
    phi[3,2]  R1444     -1.0912107229232788e+00
    phi[3,2]  R1445     1.8743214011192322e-01
    phi[3,2]  R1446     -5.4745352268218994e-01
    phi[3,2]  R1447     -0.0281666349619627
    phi[3,2]  R1448     9.7587215900421143e-01
    phi[3,2]  R1449     3.0175495147705078e-01
    phi[3,2]  R1450     -4.7132246196269989e-02
    phi[3,2]  R1451     -5.9093236923217773e-01
    phi[3,2]  R1452     -1.6270289421081543e+00
    phi[3,2]  R1453     -1.2712978124618530e+00
    phi[3,2]  R1454     -9.8178529739379883e-01
    phi[3,2]  R1455     7.8718620538711548e-01
    phi[3,2]  R1456     -1.4068396091461182e+00
    phi[3,2]  R1457     -1.0365418195724487e+00
    phi[3,2]  R1458     -1.4742389917373657e+00
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1459     -3.0999999046325684e+00
    phi[2,5]  R1460     -3.0999999046325684e+00
    phi[2,5]  R1461     -2.2400000095367432e+00
    phi[2,5]  R1462     -2.2400000095367432e+00
    phi[2,5]  R1463     -3.0999999046325684e+00
    phi[2,5]  R1464     -3.0999999046325684e+00
    phi[2,5]  R1465     -2.5699999332427979e+00
    phi[2,5]  R1466     -2.5699999332427979e+00
    phi[2,5]  R1467     -3.0999999046325684e+00
    phi[2,5]  R1468     -3.0999999046325684e+00
    phi[2,5]  R1469     -2.0899999141693115e+00
    phi[2,5]  R1470     -2.0899999141693115e+00
    phi[2,5]  R1471     -3.0999999046325684e+00
    phi[2,5]  R1472     -3.0999999046325684e+00
    phi[2,5]  R1473     0.869264543056488
    phi[2,5]  R1474     8.0495625734329224e-01
    phi[2,5]  R1475     -1.8013062477111816e+00
    phi[2,5]  R1476     -7.7324277162551880e-01
    phi[2,5]  R1477     1.9274877011775970e-01
    phi[2,5]  R1478     -1.5505234897136688e-01
    phi[2,5]  R1479     8.4718483686447144e-01
    phi[2,5]  R1480     -1.6849370300769806e-01
    phi[2,5]  R1481     3.6716657876968384e-01
    phi[2,5]  R1482     2.6218071579933167e-02
    phi[2,5]  R1483     -1.7875860631465912e-01
    phi[2,5]  R1484     0.0358089916408062
    phi[2,5]  R1485     6.8072825670242310e-01
    phi[2,5]  R1486     6.9150112569332123e-02
    phi[2,5]  R1487     3.4050163626670837e-01
    phi[2,5]  R1488     -1.0912107229232788e+00
    phi[2,5]  R1489     1.8743214011192322e-01
    phi[2,5]  R1490     -5.4745352268218994e-01
    phi[2,5]  R1491     -0.0281666349619627
    phi[2,5]  R1492     9.7587215900421143e-01
    phi[2,5]  R1493     3.0175495147705078e-01
    phi[2,5]  R1494     -4.7132246196269989e-02
    phi[2,5]  R1495     -5.9093236923217773e-01
    phi[2,5]  R1496     -1.6270289421081543e+00
    phi[2,5]  R1497     -1.2712978124618530e+00
    phi[2,5]  R1498     -9.8178529739379883e-01
    phi[2,5]  R1499     7.8718620538711548e-01
    phi[2,5]  R1500     -1.4068396091461182e+00
    phi[2,5]  R1501     -1.0365418195724487e+00
    phi[2,5]  R1502     -1.4742389917373657e+00
    phi[2,5]  R1503     1.5325810015201569e-01
    phi[2,5]  R1504     5.7673519849777222e-01
    phi[2,5]  R1505     6.5352284908294678e-01
    phi[2,5]  R1506     5.8408007025718689e-02
    phi[2,5]  R1507     -2.3630050942301750e-02
    phi[2,5]  R1508     0.0279111098498106
    phi[2,5]  R1509     -1.1368327140808105e+00
    phi[2,5]  R1510     6.1336469650268555e-01
    phi[2,5]  R1511     1.2199049443006516e-01
    phi[2,5]  R1512     6.1222821474075317e-01
    phi[2,5]  R1513     -3.3533030748367310e-01
    phi[2,5]  R1514     -2.2070416808128357e-01
    phi[2,5]  R1515     2.0725883543491364e-02
    phi[2,5]  R1516     -3.5494214296340942e-01
    phi[2,5]  R1517     -7.1019774675369263e-01
    phi[2,5]  R1518     -4.6633702516555786e-01
    phi[2,5]  R1519     -4.7228738665580750e-02
    phi[2,5]  R1520     -3.6395901441574097e-01
    phi[2,5]  R1521     -3.0920368432998657e-01
    phi[2,5]  R1522     -5.9512734413146973e-02
    phi[2,5]  R1523     -1.5812058448791504e+00
    phi[2,5]  R1524     -1.1009780168533325e+00
    phi[2,5]  R1525     7.8923009335994720e-02
    phi[2,5]  R1526     5.1917374134063721e-01
    phi[2,5]  R1527     -7.4462151527404785e-01
    phi[2,5]  R1528     -2.3624037206172943e-01
    phi[2,5]  R1529     1.4395651221275330e-01
    phi[2,5]  R1530     -4.3079802393913269e-01
    phi[2,5]  R1531     -3.8315358757972717e-01
    phi[2,5]  R1532     -1.6121819019317627e+00
    phi[2,5]  R1533     -4.8885753750801086e-01
    phi[2,5]  R1534     -7.0004051923751831e-01
    phi[2,5]  R1535     -9.7059744596481323e-01
    phi[2,5]  R1536     -9.8894137144088745e-01
    phi[2,5]  R1537     3.3406534790992737e-01
    phi[2,5]  R1538     -7.3677271604537964e-01
    phi[2,5]  R1539     -1.4649345874786377e+00
    phi[2,5]  R1540     -2.0685672760009766e+00
    phi[2,5]  R1541     -4.3808495998382568e-01
    phi[2,5]  R1542     -4.4889110326766968e-01
    phi[2,5]  R1543     5.9810751676559448e-01
    phi[2,5]  R1544     -2.1640841960906982e+00
    phi[2,5]  R1545     -9.6639132499694824e-01
    phi[2,5]  R1546     6.5917536616325378e-02
    phi[2,5]  R1547     -4.7011050581932068e-01
    phi[2,5]  R1548     -1.7950711250305176e+00
    phi[2,5]  R1549     -1.9064352512359619e+00
    phi[2,5]  R1550     4.6391388773918152e-01
    phi[2,5]  R1551     -2.1599395275115967e+00
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1552     -3.0999999046325684e+00
    phi[5,2]  R1553     -3.0999999046325684e+00
    phi[5,2]  R1554     -2.2400000095367432e+00
    phi[5,2]  R1555     -2.2400000095367432e+00
    phi[5,2]  R1556     -3.0999999046325684e+00
    phi[5,2]  R1557     -3.0999999046325684e+00
    phi[5,2]  R1558     -2.5699999332427979e+00
    phi[5,2]  R1559     -2.5699999332427979e+00
    phi[5,2]  R1560     -3.0999999046325684e+00
    phi[5,2]  R1561     -3.0999999046325684e+00
    phi[5,2]  R1562     -2.0899999141693115e+00
    phi[5,2]  R1563     -2.0899999141693115e+00
    phi[5,2]  R1564     -3.0999999046325684e+00
    phi[5,2]  R1565     -3.0999999046325684e+00
    phi[5,2]  R1566     1.5325810015201569e-01
    phi[5,2]  R1567     5.7673519849777222e-01
    phi[5,2]  R1568     6.5352284908294678e-01
    phi[5,2]  R1569     5.8408007025718689e-02
    phi[5,2]  R1570     -2.3630050942301750e-02
    phi[5,2]  R1571     0.0279111098498106
    phi[5,2]  R1572     -1.1368327140808105e+00
    phi[5,2]  R1573     6.1336469650268555e-01
    phi[5,2]  R1574     1.2199049443006516e-01
    phi[5,2]  R1575     6.1222821474075317e-01
    phi[5,2]  R1576     -3.3533030748367310e-01
    phi[5,2]  R1577     -2.2070416808128357e-01
    phi[5,2]  R1578     2.0725883543491364e-02
    phi[5,2]  R1579     -3.5494214296340942e-01
    phi[5,2]  R1580     -7.1019774675369263e-01
    phi[5,2]  R1581     -4.6633702516555786e-01
    phi[5,2]  R1582     -4.7228738665580750e-02
    phi[5,2]  R1583     -3.6395901441574097e-01
    phi[5,2]  R1584     -3.0920368432998657e-01
    phi[5,2]  R1585     -5.9512734413146973e-02
    phi[5,2]  R1586     -1.5812058448791504e+00
    phi[5,2]  R1587     -1.1009780168533325e+00
    phi[5,2]  R1588     7.8923009335994720e-02
    phi[5,2]  R1589     5.1917374134063721e-01
    phi[5,2]  R1590     -7.4462151527404785e-01
    phi[5,2]  R1591     -2.3624037206172943e-01
    phi[5,2]  R1592     1.4395651221275330e-01
    phi[5,2]  R1593     -4.3079802393913269e-01
    phi[5,2]  R1594     -3.8315358757972717e-01
    phi[5,2]  R1595     -1.6121819019317627e+00
    phi[5,2]  R1596     -4.8885753750801086e-01
    phi[5,2]  R1597     -7.0004051923751831e-01
    phi[5,2]  R1598     -9.7059744596481323e-01
    phi[5,2]  R1599     -9.8894137144088745e-01
    phi[5,2]  R1600     3.3406534790992737e-01
    phi[5,2]  R1601     -7.3677271604537964e-01
    phi[5,2]  R1602     -1.4649345874786377e+00
    phi[5,2]  R1603     -2.0685672760009766e+00
    phi[5,2]  R1604     -4.3808495998382568e-01
    phi[5,2]  R1605     -4.4889110326766968e-01
    phi[5,2]  R1606     5.9810751676559448e-01
    phi[5,2]  R1607     -2.1640841960906982e+00
    phi[5,2]  R1608     -9.6639132499694824e-01
    phi[5,2]  R1609     6.5917536616325378e-02
    phi[5,2]  R1610     -4.7011050581932068e-01
    phi[5,2]  R1611     -1.7950711250305176e+00
    phi[5,2]  R1612     -1.9064352512359619e+00
    phi[5,2]  R1613     4.6391388773918152e-01
    phi[5,2]  R1614     -2.1599395275115967e+00
    phi[5,2]  R1615     0.869264543056488
    phi[5,2]  R1616     8.0495625734329224e-01
    phi[5,2]  R1617     -1.8013062477111816e+00
    phi[5,2]  R1618     -7.7324277162551880e-01
    phi[5,2]  R1619     1.9274877011775970e-01
    phi[5,2]  R1620     -1.5505234897136688e-01
    phi[5,2]  R1621     8.4718483686447144e-01
    phi[5,2]  R1622     -1.6849370300769806e-01
    phi[5,2]  R1623     3.6716657876968384e-01
    phi[5,2]  R1624     2.6218071579933167e-02
    phi[5,2]  R1625     -1.7875860631465912e-01
    phi[5,2]  R1626     0.0358089916408062
    phi[5,2]  R1627     6.8072825670242310e-01
    phi[5,2]  R1628     6.9150112569332123e-02
    phi[5,2]  R1629     3.4050163626670837e-01
    phi[5,2]  R1630     -1.0912107229232788e+00
    phi[5,2]  R1631     1.8743214011192322e-01
    phi[5,2]  R1632     -5.4745352268218994e-01
    phi[5,2]  R1633     -0.0281666349619627
    phi[5,2]  R1634     9.7587215900421143e-01
    phi[5,2]  R1635     3.0175495147705078e-01
    phi[5,2]  R1636     -4.7132246196269989e-02
    phi[5,2]  R1637     -5.9093236923217773e-01
    phi[5,2]  R1638     -1.6270289421081543e+00
    phi[5,2]  R1639     -1.2712978124618530e+00
    phi[5,2]  R1640     -9.8178529739379883e-01
    phi[5,2]  R1641     7.8718620538711548e-01
    phi[5,2]  R1642     -1.4068396091461182e+00
    phi[5,2]  R1643     -1.0365418195724487e+00
    phi[5,2]  R1644     -1.4742389917373657e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1645     -3.0999999046325684e+00
    phi[2,6]  R1646     -3.0999999046325684e+00
    phi[2,6]  R1647     -2.2400000095367432e+00
    phi[2,6]  R1648     -2.2400000095367432e+00
    phi[2,6]  R1649     -3.0999999046325684e+00
    phi[2,6]  R1650     -3.0999999046325684e+00
    phi[2,6]  R1651     -2.5699999332427979e+00
    phi[2,6]  R1652     -2.5699999332427979e+00
    phi[2,6]  R1653     -3.0999999046325684e+00
    phi[2,6]  R1654     -3.0999999046325684e+00
    phi[2,6]  R1655     -2.0899999141693115e+00
    phi[2,6]  R1656     -2.0899999141693115e+00
    phi[2,6]  R1657     -3.0999999046325684e+00
    phi[2,6]  R1658     -3.0999999046325684e+00
    phi[2,6]  R1659     0.869264543056488
    phi[2,6]  R1660     8.0495625734329224e-01
    phi[2,6]  R1661     -1.8013062477111816e+00
    phi[2,6]  R1662     -7.7324277162551880e-01
    phi[2,6]  R1663     1.9274877011775970e-01
    phi[2,6]  R1664     -1.5505234897136688e-01
    phi[2,6]  R1665     8.4718483686447144e-01
    phi[2,6]  R1666     -1.6849370300769806e-01
    phi[2,6]  R1667     3.6716657876968384e-01
    phi[2,6]  R1668     2.6218071579933167e-02
    phi[2,6]  R1669     -1.7875860631465912e-01
    phi[2,6]  R1670     0.0358089916408062
    phi[2,6]  R1671     6.8072825670242310e-01
    phi[2,6]  R1672     6.9150112569332123e-02
    phi[2,6]  R1673     3.4050163626670837e-01
    phi[2,6]  R1674     -1.0912107229232788e+00
    phi[2,6]  R1675     1.8743214011192322e-01
    phi[2,6]  R1676     -5.4745352268218994e-01
    phi[2,6]  R1677     -0.0281666349619627
    phi[2,6]  R1678     9.7587215900421143e-01
    phi[2,6]  R1679     3.0175495147705078e-01
    phi[2,6]  R1680     -4.7132246196269989e-02
    phi[2,6]  R1681     -5.9093236923217773e-01
    phi[2,6]  R1682     -1.6270289421081543e+00
    phi[2,6]  R1683     -1.2712978124618530e+00
    phi[2,6]  R1684     -9.8178529739379883e-01
    phi[2,6]  R1685     7.8718620538711548e-01
    phi[2,6]  R1686     -1.4068396091461182e+00
    phi[2,6]  R1687     -1.0365418195724487e+00
    phi[2,6]  R1688     -1.4742389917373657e+00
    phi[2,6]  R1689     -3.2760536670684814e-01
    phi[2,6]  R1690     -4.6339789032936096e-01
    phi[2,6]  R1691     2.3866379261016846e-01
    phi[2,6]  R1692     -9.4490915536880493e-01
    phi[2,6]  R1693     -1.0642709732055664e+00
    phi[2,6]  R1694     -3.3107733726501465e-01
    phi[2,6]  R1695     1.6220751404762268e-01
    phi[2,6]  R1696     -1.2295907735824585e+00
    phi[2,6]  R1697     -3.8355121016502380e-01
    phi[2,6]  R1698     -2.4086223915219307e-02
    phi[2,6]  R1699     -1.4405786991119385e-01
    phi[2,6]  R1700     1.3001175597310066e-02
    phi[2,6]  R1701     -0.490697979927063
    phi[2,6]  R1702     -3.3605548739433289e-01
    phi[2,6]  R1703     -7.0406931638717651e-01
    phi[2,6]  R1704     -1.4762908220291138e+00
    phi[2,6]  R1705     -6.8852889537811279e-01
    phi[2,6]  R1706     -9.7410839796066284e-01
    phi[2,6]  R1707     1.9746525585651398e-01
    phi[2,6]  R1708     -1.3183850049972534e+00
    phi[2,6]  R1709     -9.7448450326919556e-01
    phi[2,6]  R1710     -8.2670742273330688e-01
    phi[2,6]  R1711     -6.8360388278961182e-01
    phi[2,6]  R1712     -0.641730546951294
    phi[2,6]  R1713     -4.1614958643913269e-01
    phi[2,6]  R1714     -1.2708084583282471e+00
    phi[2,6]  R1715     -3.9488604664802551e-01
    phi[2,6]  R1716     -3.7095078825950623e-01
    phi[2,6]  R1717     -1.1115583181381226e+00
    phi[2,6]  R1718     -2.0326276123523712e-01
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1719     -3.0999999046325684e+00
    phi[6,2]  R1720     -3.0999999046325684e+00
    phi[6,2]  R1721     -2.2400000095367432e+00
    phi[6,2]  R1722     -2.2400000095367432e+00
    phi[6,2]  R1723     -3.0999999046325684e+00
    phi[6,2]  R1724     -3.0999999046325684e+00
    phi[6,2]  R1725     -2.5699999332427979e+00
    phi[6,2]  R1726     -2.5699999332427979e+00
    phi[6,2]  R1727     -3.0999999046325684e+00
    phi[6,2]  R1728     -3.0999999046325684e+00
    phi[6,2]  R1729     -2.0899999141693115e+00
    phi[6,2]  R1730     -2.0899999141693115e+00
    phi[6,2]  R1731     -3.0999999046325684e+00
    phi[6,2]  R1732     -3.0999999046325684e+00
    phi[6,2]  R1733     -3.2760536670684814e-01
    phi[6,2]  R1734     -4.6339789032936096e-01
    phi[6,2]  R1735     2.3866379261016846e-01
    phi[6,2]  R1736     -9.4490915536880493e-01
    phi[6,2]  R1737     -1.0642709732055664e+00
    phi[6,2]  R1738     -3.3107733726501465e-01
    phi[6,2]  R1739     1.6220751404762268e-01
    phi[6,2]  R1740     -1.2295907735824585e+00
    phi[6,2]  R1741     -3.8355121016502380e-01
    phi[6,2]  R1742     -2.4086223915219307e-02
    phi[6,2]  R1743     -1.4405786991119385e-01
    phi[6,2]  R1744     1.3001175597310066e-02
    phi[6,2]  R1745     -0.490697979927063
    phi[6,2]  R1746     -3.3605548739433289e-01
    phi[6,2]  R1747     -7.0406931638717651e-01
    phi[6,2]  R1748     -1.4762908220291138e+00
    phi[6,2]  R1749     -6.8852889537811279e-01
    phi[6,2]  R1750     -9.7410839796066284e-01
    phi[6,2]  R1751     1.9746525585651398e-01
    phi[6,2]  R1752     -1.3183850049972534e+00
    phi[6,2]  R1753     -9.7448450326919556e-01
    phi[6,2]  R1754     -8.2670742273330688e-01
    phi[6,2]  R1755     -6.8360388278961182e-01
    phi[6,2]  R1756     -0.641730546951294
    phi[6,2]  R1757     -4.1614958643913269e-01
    phi[6,2]  R1758     -1.2708084583282471e+00
    phi[6,2]  R1759     -3.9488604664802551e-01
    phi[6,2]  R1760     -3.7095078825950623e-01
    phi[6,2]  R1761     -1.1115583181381226e+00
    phi[6,2]  R1762     -2.0326276123523712e-01
    phi[6,2]  R1763     0.869264543056488
    phi[6,2]  R1764     8.0495625734329224e-01
    phi[6,2]  R1765     -1.8013062477111816e+00
    phi[6,2]  R1766     -7.7324277162551880e-01
    phi[6,2]  R1767     1.9274877011775970e-01
    phi[6,2]  R1768     -1.5505234897136688e-01
    phi[6,2]  R1769     8.4718483686447144e-01
    phi[6,2]  R1770     -1.6849370300769806e-01
    phi[6,2]  R1771     3.6716657876968384e-01
    phi[6,2]  R1772     2.6218071579933167e-02
    phi[6,2]  R1773     -1.7875860631465912e-01
    phi[6,2]  R1774     0.0358089916408062
    phi[6,2]  R1775     6.8072825670242310e-01
    phi[6,2]  R1776     6.9150112569332123e-02
    phi[6,2]  R1777     3.4050163626670837e-01
    phi[6,2]  R1778     -1.0912107229232788e+00
    phi[6,2]  R1779     1.8743214011192322e-01
    phi[6,2]  R1780     -5.4745352268218994e-01
    phi[6,2]  R1781     -0.0281666349619627
    phi[6,2]  R1782     9.7587215900421143e-01
    phi[6,2]  R1783     3.0175495147705078e-01
    phi[6,2]  R1784     -4.7132246196269989e-02
    phi[6,2]  R1785     -5.9093236923217773e-01
    phi[6,2]  R1786     -1.6270289421081543e+00
    phi[6,2]  R1787     -1.2712978124618530e+00
    phi[6,2]  R1788     -9.8178529739379883e-01
    phi[6,2]  R1789     7.8718620538711548e-01
    phi[6,2]  R1790     -1.4068396091461182e+00
    phi[6,2]  R1791     -1.0365418195724487e+00
    phi[6,2]  R1792     -1.4742389917373657e+00
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1793     -3.0999999046325684e+00
    phi[3,6]  R1794     -3.0999999046325684e+00
    phi[3,6]  R1795     -2.2400000095367432e+00
    phi[3,6]  R1796     -2.2400000095367432e+00
    phi[3,6]  R1797     -3.0999999046325684e+00
    phi[3,6]  R1798     -3.0999999046325684e+00
    phi[3,6]  R1799     -2.5699999332427979e+00
    phi[3,6]  R1800     -2.5699999332427979e+00
    phi[3,6]  R1801     -3.0999999046325684e+00
    phi[3,6]  R1802     -3.0999999046325684e+00
    phi[3,6]  R1803     -2.0899999141693115e+00
    phi[3,6]  R1804     -2.0899999141693115e+00
    phi[3,6]  R1805     -3.0999999046325684e+00
    phi[3,6]  R1806     -3.0999999046325684e+00
    phi[3,6]  R1807     -3.5601980984210968e-02
    phi[3,6]  R1808     -2.0091648101806641e+00
    phi[3,6]  R1809     2.6701334118843079e-01
    phi[3,6]  R1810     -1.7497508227825165e-01
    phi[3,6]  R1811     1.9002988934516907e-02
    phi[3,6]  R1812     -1.1127890348434448e+00
    phi[3,6]  R1813     -7.0565289258956909e-01
    phi[3,6]  R1814     1.4529807567596436e+00
    phi[3,6]  R1815     1.2837707996368408e+00
    phi[3,6]  R1816     -2.7198210358619690e-01
    phi[3,6]  R1817     1.1850296258926392e+00
    phi[3,6]  R1818     8.0340665578842163e-01
    phi[3,6]  R1819     8.7472432851791382e-01
    phi[3,6]  R1820     1.0581958293914795e+00
    phi[3,6]  R1821     5.8327007293701172e-01
    phi[3,6]  R1822     0.373644083738327
    phi[3,6]  R1823     2.4458359181880951e-01
    phi[3,6]  R1824     -4.5529860258102417e-01
    phi[3,6]  R1825     -9.7418487071990967e-01
    phi[3,6]  R1826     -1.8380020558834076e-01
    phi[3,6]  R1827     -2.0293862819671631e+00
    phi[3,6]  R1828     -3.2236984372138977e-01
    phi[3,6]  R1829     -1.2023220062255859e+00
    phi[3,6]  R1830     -1.3782145977020264e+00
    phi[3,6]  R1831     5.4403585195541382e-01
    phi[3,6]  R1832     -2.8852421045303345e-01
    phi[3,6]  R1833     -6.2107962369918823e-01
    phi[3,6]  R1834     -1.8109947443008423e+00
    phi[3,6]  R1835     -1.5881599187850952e+00
    phi[3,6]  R1836     -2.1651620864868164e+00
    phi[3,6]  R1837     -1.6871854066848755e+00
    phi[3,6]  R1838     -2.7312755584716797e-01
    phi[3,6]  R1839     -1.7245821952819824e+00
    phi[3,6]  R1840     -9.9549138545989990e-01
    phi[3,6]  R1841     -2.3040804862976074e+00
    phi[3,6]  R1842     -1.8529220819473267e+00
    phi[3,6]  R1843     -2.0636497437953949e-01
    phi[3,6]  R1844     3.0884258449077606e-02
    phi[3,6]  R1845     1.7679098844528198e+00
    phi[3,6]  R1846     -3.9496263861656189e-01
    phi[3,6]  R1847     -1.1728961020708084e-02
    phi[3,6]  R1848     -3.1642013788223267e-01
    phi[3,6]  R1849     -2.3237879276275635e+00
    phi[3,6]  R1850     -1.2783237695693970e+00
    phi[3,6]  R1851     -1.1449443101882935e+00
    phi[3,6]  R1852     6.9839906692504883e-01
    phi[3,6]  R1853     -1.8353886604309082e+00
    phi[3,6]  R1854     -2.2414343357086182e+00
    phi[3,6]  R1855     -1.7773462533950806e+00
    phi[3,6]  R1856     -2.4791257381439209e+00
    phi[3,6]  R1857     -1.4807873964309692e+00
    phi[3,6]  R1858     -1.2853094339370728e+00
    phi[3,6]  R1859     -1.5846395492553711e+00
    phi[3,6]  R1860     -2.4775044918060303e+00
    phi[3,6]  R1861     -1.3673295974731445e+00
    phi[3,6]  R1862     -3.0236017704010010e-01
    phi[3,6]  R1863     -3.5025903582572937e-01
    phi[3,6]  R1864     -1.2491627931594849e+00
    phi[3,6]  R1865     -3.2760536670684814e-01
    phi[3,6]  R1866     -4.6339789032936096e-01
    phi[3,6]  R1867     2.3866379261016846e-01
    phi[3,6]  R1868     -9.4490915536880493e-01
    phi[3,6]  R1869     -1.0642709732055664e+00
    phi[3,6]  R1870     -3.3107733726501465e-01
    phi[3,6]  R1871     1.6220751404762268e-01
    phi[3,6]  R1872     -1.2295907735824585e+00
    phi[3,6]  R1873     -3.8355121016502380e-01
    phi[3,6]  R1874     -2.4086223915219307e-02
    phi[3,6]  R1875     -1.4405786991119385e-01
    phi[3,6]  R1876     1.3001175597310066e-02
    phi[3,6]  R1877     -0.490697979927063
    phi[3,6]  R1878     -3.3605548739433289e-01
    phi[3,6]  R1879     -7.0406931638717651e-01
    phi[3,6]  R1880     -1.4762908220291138e+00
    phi[3,6]  R1881     -6.8852889537811279e-01
    phi[3,6]  R1882     -9.7410839796066284e-01
    phi[3,6]  R1883     1.9746525585651398e-01
    phi[3,6]  R1884     -1.3183850049972534e+00
    phi[3,6]  R1885     -9.7448450326919556e-01
    phi[3,6]  R1886     -8.2670742273330688e-01
    phi[3,6]  R1887     -6.8360388278961182e-01
    phi[3,6]  R1888     -0.641730546951294
    phi[3,6]  R1889     -4.1614958643913269e-01
    phi[3,6]  R1890     -1.2708084583282471e+00
    phi[3,6]  R1891     -3.9488604664802551e-01
    phi[3,6]  R1892     -3.7095078825950623e-01
    phi[3,6]  R1893     -1.1115583181381226e+00
    phi[3,6]  R1894     -2.0326276123523712e-01
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1895     -3.0999999046325684e+00
    phi[6,3]  R1896     -3.0999999046325684e+00
    phi[6,3]  R1897     -2.2400000095367432e+00
    phi[6,3]  R1898     -2.2400000095367432e+00
    phi[6,3]  R1899     -3.0999999046325684e+00
    phi[6,3]  R1900     -3.0999999046325684e+00
    phi[6,3]  R1901     -2.5699999332427979e+00
    phi[6,3]  R1902     -2.5699999332427979e+00
    phi[6,3]  R1903     -3.0999999046325684e+00
    phi[6,3]  R1904     -3.0999999046325684e+00
    phi[6,3]  R1905     -2.0899999141693115e+00
    phi[6,3]  R1906     -2.0899999141693115e+00
    phi[6,3]  R1907     -3.0999999046325684e+00
    phi[6,3]  R1908     -3.0999999046325684e+00
    phi[6,3]  R1909     -3.2760536670684814e-01
    phi[6,3]  R1910     -4.6339789032936096e-01
    phi[6,3]  R1911     2.3866379261016846e-01
    phi[6,3]  R1912     -9.4490915536880493e-01
    phi[6,3]  R1913     -1.0642709732055664e+00
    phi[6,3]  R1914     -3.3107733726501465e-01
    phi[6,3]  R1915     1.6220751404762268e-01
    phi[6,3]  R1916     -1.2295907735824585e+00
    phi[6,3]  R1917     -3.8355121016502380e-01
    phi[6,3]  R1918     -2.4086223915219307e-02
    phi[6,3]  R1919     -1.4405786991119385e-01
    phi[6,3]  R1920     1.3001175597310066e-02
    phi[6,3]  R1921     -0.490697979927063
    phi[6,3]  R1922     -3.3605548739433289e-01
    phi[6,3]  R1923     -7.0406931638717651e-01
    phi[6,3]  R1924     -1.4762908220291138e+00
    phi[6,3]  R1925     -6.8852889537811279e-01
    phi[6,3]  R1926     -9.7410839796066284e-01
    phi[6,3]  R1927     1.9746525585651398e-01
    phi[6,3]  R1928     -1.3183850049972534e+00
    phi[6,3]  R1929     -9.7448450326919556e-01
    phi[6,3]  R1930     -8.2670742273330688e-01
    phi[6,3]  R1931     -6.8360388278961182e-01
    phi[6,3]  R1932     -0.641730546951294
    phi[6,3]  R1933     -4.1614958643913269e-01
    phi[6,3]  R1934     -1.2708084583282471e+00
    phi[6,3]  R1935     -3.9488604664802551e-01
    phi[6,3]  R1936     -3.7095078825950623e-01
    phi[6,3]  R1937     -1.1115583181381226e+00
    phi[6,3]  R1938     -2.0326276123523712e-01
    phi[6,3]  R1939     -3.5601980984210968e-02
    phi[6,3]  R1940     -2.0091648101806641e+00
    phi[6,3]  R1941     2.6701334118843079e-01
    phi[6,3]  R1942     -1.7497508227825165e-01
    phi[6,3]  R1943     1.9002988934516907e-02
    phi[6,3]  R1944     -1.1127890348434448e+00
    phi[6,3]  R1945     -7.0565289258956909e-01
    phi[6,3]  R1946     1.4529807567596436e+00
    phi[6,3]  R1947     1.2837707996368408e+00
    phi[6,3]  R1948     -2.7198210358619690e-01
    phi[6,3]  R1949     1.1850296258926392e+00
    phi[6,3]  R1950     8.0340665578842163e-01
    phi[6,3]  R1951     8.7472432851791382e-01
    phi[6,3]  R1952     1.0581958293914795e+00
    phi[6,3]  R1953     5.8327007293701172e-01
    phi[6,3]  R1954     0.373644083738327
    phi[6,3]  R1955     2.4458359181880951e-01
    phi[6,3]  R1956     -4.5529860258102417e-01
    phi[6,3]  R1957     -9.7418487071990967e-01
    phi[6,3]  R1958     -1.8380020558834076e-01
    phi[6,3]  R1959     -2.0293862819671631e+00
    phi[6,3]  R1960     -3.2236984372138977e-01
    phi[6,3]  R1961     -1.2023220062255859e+00
    phi[6,3]  R1962     -1.3782145977020264e+00
    phi[6,3]  R1963     5.4403585195541382e-01
    phi[6,3]  R1964     -2.8852421045303345e-01
    phi[6,3]  R1965     -6.2107962369918823e-01
    phi[6,3]  R1966     -1.8109947443008423e+00
    phi[6,3]  R1967     -1.5881599187850952e+00
    phi[6,3]  R1968     -2.1651620864868164e+00
    phi[6,3]  R1969     -1.6871854066848755e+00
    phi[6,3]  R1970     -2.7312755584716797e-01
    phi[6,3]  R1971     -1.7245821952819824e+00
    phi[6,3]  R1972     -9.9549138545989990e-01
    phi[6,3]  R1973     -2.3040804862976074e+00
    phi[6,3]  R1974     -1.8529220819473267e+00
    phi[6,3]  R1975     -2.0636497437953949e-01
    phi[6,3]  R1976     3.0884258449077606e-02
    phi[6,3]  R1977     1.7679098844528198e+00
    phi[6,3]  R1978     -3.9496263861656189e-01
    phi[6,3]  R1979     -1.1728961020708084e-02
    phi[6,3]  R1980     -3.1642013788223267e-01
    phi[6,3]  R1981     -2.3237879276275635e+00
    phi[6,3]  R1982     -1.2783237695693970e+00
    phi[6,3]  R1983     -1.1449443101882935e+00
    phi[6,3]  R1984     6.9839906692504883e-01
    phi[6,3]  R1985     -1.8353886604309082e+00
    phi[6,3]  R1986     -2.2414343357086182e+00
    phi[6,3]  R1987     -1.7773462533950806e+00
    phi[6,3]  R1988     -2.4791257381439209e+00
    phi[6,3]  R1989     -1.4807873964309692e+00
    phi[6,3]  R1990     -1.2853094339370728e+00
    phi[6,3]  R1991     -1.5846395492553711e+00
    phi[6,3]  R1992     -2.4775044918060303e+00
    phi[6,3]  R1993     -1.3673295974731445e+00
    phi[6,3]  R1994     -3.0236017704010010e-01
    phi[6,3]  R1995     -3.5025903582572937e-01
    phi[6,3]  R1996     -1.2491627931594849e+00
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R29       -2.4520310301910944e+00
    phi[3,8]  R30       -3.7607365201031140e-02
    phi[3,8]  R31       -2.4145287913469855e+00
    phi[3,8]  R32       -1.2147648659205896e+00
    phi[3,8]  R33       4.1852085624594437e-01
    phi[3,8]  R34       7.7177737662014834e-01
    phi[3,8]  R35       -1.1283302472094747e+00
    phi[3,8]  R64       -1
    phi[3,8]  R1997     -5.5520309348236623e+00
    phi[3,8]  R1998     -0.647968874441474
    phi[3,8]  R1999     -2.2776073747377743e+00
    phi[3,8]  R2000     -2.2023926443357120e+00
    phi[3,8]  R2001     -5.5145286959795534e+00
    phi[3,8]  R2002     -6.8547111328558286e-01
    phi[3,8]  R2003     -3.7847647991633875e+00
    phi[3,8]  R2004     -1.3552350673222082e+00
    phi[3,8]  R2005     -2.6814790483866240e+00
    phi[3,8]  R2006     -3.5185207608785127e+00
    phi[3,8]  R2007     -1.3182225375491632e+00
    phi[3,8]  R2008     -2.86177729078946
    phi[3,8]  R2009     -4.2283301518420426e+00
    phi[3,8]  R2010     -1.9716696574230936e+00
    phi[3,8]  R2011     -2.3326058056240320e-01
    phi[3,8]  R2012     -2.3649834000117487e-01
    phi[3,8]  R2013     -2.4089050932747380e-01
    phi[3,8]  R2014     -2.4193807498743303e-01
    phi[3,8]  R2015     -2.4661429721546768e-01
    phi[3,8]  R2016     -2.5378421439112819e-01
    phi[3,8]  R2017     -2.6972322527935855e-01
    phi[3,8]  R2018     -2.8968440061143341e-01
    phi[3,8]  R2019     -3.1585060394228082e-01
    phi[3,8]  R2020     -3.5794184308277210e-01
    phi[3,8]  R2021     -5.7791803025354738e-01
    phi[3,8]  R2022     -5.8009587041207666e-01
    phi[3,8]  R2023     -5.8253733783294215e-01
    phi[3,8]  R2024     -6.2893804413578636e-01
    phi[3,8]  R2025     -6.3233786847176821e-01
    phi[3,8]  R2026     -6.5528287072330826e-01
    phi[3,8]  R2027     -6.7107986883515836e-01
    phi[3,8]  R2028     -7.0927513030408373e-01
    phi[3,8]  R2029     -7.4943177614909573e-01
    phi[3,8]  R2030     -7.0486469949853681e-01
    phi[3,8]  R2031     -5.8818275401547160e-01
    phi[3,8]  R2032     -6.6521193339007578e-01
    phi[3,8]  R2033     -6.6920585688502476e-01
    phi[3,8]  R2034     -7.6811676418986419e-01
    phi[3,8]  R2035     -1.4929642944115238e+00
    phi[3,8]  R2036     -1.2990629939847216e+00
    phi[3,8]  R2037     -8.1812321535671928e-01
    phi[3,8]  R2038     -8.5524449619841769e-01
    phi[3,8]  R2039     -9.8527623493910077e-01
    phi[3,8]  R2040     -9.8780012315790455e-01
    phi[3,8]  R2041     -4.3109165630509971e-01
    phi[3,8]  R2042     -4.5838179040343985e-01
    phi[3,8]  R2043     -4.7964887429189096e-01
    phi[3,8]  R2044     -5.3416322401643224e-01
    phi[3,8]  R2045     -5.7792155636931430e-01
    phi[3,8]  R2046     -5.9203147685838342e-01
    phi[3,8]  R2047     -6.0458185178486479e-01
    phi[3,8]  R2048     -6.4050103732893482e-01
    phi[3,8]  R2049     -7.2401877116631486e-01
    phi[3,8]  R2050     -9.9549803800677250e-01
    phi[3,8]  R2051     -3.2459805993325097e-01
    phi[3,8]  R2052     -0.46372860495945
    phi[3,8]  R2053     -4.8663824790885024e-01
    phi[3,8]  R2054     -5.0449040030100945e-01
    phi[3,8]  R2055     -8.0348589385277536e-01
    phi[3,8]  R2056     -7.0941780003776111e-01
    phi[3,8]  R2057     -9.3972927542642315e-01
    phi[3,8]  R2058     -1.0050318801565259e+00
    phi[3,8]  R2059     -9.7159381963008284e-01
    phi[3,8]  R2060     -9.9538612596881082e-01
    phi[3,8]  R2061     -3.5514921454348314e-01
    phi[3,8]  R2062     -4.1513152673902542e-01
    phi[3,8]  R2063     -9.5134135217842908e-01
    phi[3,8]  R2064     -1.1133287540258143e+00
    phi[3,8]  R2065     -1.4373395771836484e+00
    phi[3,8]  R2066     -1.7997182111622885e+00
    phi[3,8]  R2067     -2.0398697420085563e+00
    phi[3,8]  R2068     -1.9042493011064239e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2069     -3.0999999046325684e+00
    phi[4,5]  R2070     -3.0999999046325684e+00
    phi[4,5]  R2071     -2.2400000095367432e+00
    phi[4,5]  R2072     -2.2400000095367432e+00
    phi[4,5]  R2073     -3.0999999046325684e+00
    phi[4,5]  R2074     -3.0999999046325684e+00
    phi[4,5]  R2075     -2.5699999332427979e+00
    phi[4,5]  R2076     -2.5699999332427979e+00
    phi[4,5]  R2077     -3.0999999046325684e+00
    phi[4,5]  R2078     -3.0999999046325684e+00
    phi[4,5]  R2079     -2.0899999141693115e+00
    phi[4,5]  R2080     -2.0899999141693115e+00
    phi[4,5]  R2081     -3.0999999046325684e+00
    phi[4,5]  R2082     -3.0999999046325684e+00
    phi[4,5]  R2083     1.1403337717056274e+00
    phi[4,5]  R2084     2.2187242507934570e+00
    phi[4,5]  R2085     1.2167351245880127e+00
    phi[4,5]  R2086     1.2702466249465942e+00
    phi[4,5]  R2087     -6.1477798223495483e-01
    phi[4,5]  R2088     1.3048038482666016e+00
    phi[4,5]  R2089     2.1411089897155762e+00
    phi[4,5]  R2090     1.9234117269515991e+00
    phi[4,5]  R2091     9.2122542858123779e-01
    phi[4,5]  R2092     -2.7807433605194092e+00
    phi[4,5]  R2093     -8.6972367763519287e-01
    phi[4,5]  R2094     -2.5525028705596924e+00
    phi[4,5]  R2095     -1.4669482707977295e+00
    phi[4,5]  R2096     -4.1162583231925964e-01
    phi[4,5]  R2097     6.4589112997055054e-01
    phi[4,5]  R2098     -3.2548463344573975e-01
    phi[4,5]  R2099     9.3752861022949219e-01
    phi[4,5]  R2100     -1.5661417245864868e+00
    phi[4,5]  R2101     1.4478644728660583e-01
    phi[4,5]  R2102     -1.9105530977249146e+00
    phi[4,5]  R2103     -1.6939067840576172e+00
    phi[4,5]  R2104     1.1600785255432129e+00
    phi[4,5]  R2105     1.6215798854827881e+00
    phi[4,5]  R2106     1.0405100584030151e+00
    phi[4,5]  R2107     -2.9920685291290283e-01
    phi[4,5]  R2108     1.2267171144485474e+00
    phi[4,5]  R2109     1.2808082103729248e+00
    phi[4,5]  R2110     1.10845947265625
    phi[4,5]  R2111     -9.7849303483963013e-01
    phi[4,5]  R2112     -5.4005157947540283e-01
    phi[4,5]  R2113     4.7007542848587036e-01
    phi[4,5]  R2114     4.6532204747200012e-01
    phi[4,5]  R2115     1.2916998863220215e+00
    phi[4,5]  R2116     7.2122913599014282e-01
    phi[4,5]  R2117     1.0154050588607788e+00
    phi[4,5]  R2118     2.3482432365417480e+00
    phi[4,5]  R2119     1.4233335256576538e+00
    phi[4,5]  R2120     1.0756527185440063e+00
    phi[4,5]  R2121     1.5872042179107666e+00
    phi[4,5]  R2122     1.5325810015201569e-01
    phi[4,5]  R2123     5.7673519849777222e-01
    phi[4,5]  R2124     6.5352284908294678e-01
    phi[4,5]  R2125     5.8408007025718689e-02
    phi[4,5]  R2126     -2.3630050942301750e-02
    phi[4,5]  R2127     0.0279111098498106
    phi[4,5]  R2128     -1.1368327140808105e+00
    phi[4,5]  R2129     6.1336469650268555e-01
    phi[4,5]  R2130     1.2199049443006516e-01
    phi[4,5]  R2131     6.1222821474075317e-01
    phi[4,5]  R2132     -3.3533030748367310e-01
    phi[4,5]  R2133     -2.2070416808128357e-01
    phi[4,5]  R2134     2.0725883543491364e-02
    phi[4,5]  R2135     -3.5494214296340942e-01
    phi[4,5]  R2136     -7.1019774675369263e-01
    phi[4,5]  R2137     -4.6633702516555786e-01
    phi[4,5]  R2138     -4.7228738665580750e-02
    phi[4,5]  R2139     -3.6395901441574097e-01
    phi[4,5]  R2140     -3.0920368432998657e-01
    phi[4,5]  R2141     -5.9512734413146973e-02
    phi[4,5]  R2142     -1.5812058448791504e+00
    phi[4,5]  R2143     -1.1009780168533325e+00
    phi[4,5]  R2144     7.8923009335994720e-02
    phi[4,5]  R2145     5.1917374134063721e-01
    phi[4,5]  R2146     -7.4462151527404785e-01
    phi[4,5]  R2147     -2.3624037206172943e-01
    phi[4,5]  R2148     1.4395651221275330e-01
    phi[4,5]  R2149     -4.3079802393913269e-01
    phi[4,5]  R2150     -3.8315358757972717e-01
    phi[4,5]  R2151     -1.6121819019317627e+00
    phi[4,5]  R2152     -4.8885753750801086e-01
    phi[4,5]  R2153     -7.0004051923751831e-01
    phi[4,5]  R2154     -9.7059744596481323e-01
    phi[4,5]  R2155     -9.8894137144088745e-01
    phi[4,5]  R2156     3.3406534790992737e-01
    phi[4,5]  R2157     -7.3677271604537964e-01
    phi[4,5]  R2158     -1.4649345874786377e+00
    phi[4,5]  R2159     -2.0685672760009766e+00
    phi[4,5]  R2160     -4.3808495998382568e-01
    phi[4,5]  R2161     -4.4889110326766968e-01
    phi[4,5]  R2162     5.9810751676559448e-01
    phi[4,5]  R2163     -2.1640841960906982e+00
    phi[4,5]  R2164     -9.6639132499694824e-01
    phi[4,5]  R2165     6.5917536616325378e-02
    phi[4,5]  R2166     -4.7011050581932068e-01
    phi[4,5]  R2167     -1.7950711250305176e+00
    phi[4,5]  R2168     -1.9064352512359619e+00
    phi[4,5]  R2169     4.6391388773918152e-01
    phi[4,5]  R2170     -2.1599395275115967e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2171     -3.0999999046325684e+00
    phi[5,4]  R2172     -3.0999999046325684e+00
    phi[5,4]  R2173     -2.2400000095367432e+00
    phi[5,4]  R2174     -2.2400000095367432e+00
    phi[5,4]  R2175     -3.0999999046325684e+00
    phi[5,4]  R2176     -3.0999999046325684e+00
    phi[5,4]  R2177     -2.5699999332427979e+00
    phi[5,4]  R2178     -2.5699999332427979e+00
    phi[5,4]  R2179     -3.0999999046325684e+00
    phi[5,4]  R2180     -3.0999999046325684e+00
    phi[5,4]  R2181     -2.0899999141693115e+00
    phi[5,4]  R2182     -2.0899999141693115e+00
    phi[5,4]  R2183     -3.0999999046325684e+00
    phi[5,4]  R2184     -3.0999999046325684e+00
    phi[5,4]  R2185     1.5325810015201569e-01
    phi[5,4]  R2186     5.7673519849777222e-01
    phi[5,4]  R2187     6.5352284908294678e-01
    phi[5,4]  R2188     5.8408007025718689e-02
    phi[5,4]  R2189     -2.3630050942301750e-02
    phi[5,4]  R2190     0.0279111098498106
    phi[5,4]  R2191     -1.1368327140808105e+00
    phi[5,4]  R2192     6.1336469650268555e-01
    phi[5,4]  R2193     1.2199049443006516e-01
    phi[5,4]  R2194     6.1222821474075317e-01
    phi[5,4]  R2195     -3.3533030748367310e-01
    phi[5,4]  R2196     -2.2070416808128357e-01
    phi[5,4]  R2197     2.0725883543491364e-02
    phi[5,4]  R2198     -3.5494214296340942e-01
    phi[5,4]  R2199     -7.1019774675369263e-01
    phi[5,4]  R2200     -4.6633702516555786e-01
    phi[5,4]  R2201     -4.7228738665580750e-02
    phi[5,4]  R2202     -3.6395901441574097e-01
    phi[5,4]  R2203     -3.0920368432998657e-01
    phi[5,4]  R2204     -5.9512734413146973e-02
    phi[5,4]  R2205     -1.5812058448791504e+00
    phi[5,4]  R2206     -1.1009780168533325e+00
    phi[5,4]  R2207     7.8923009335994720e-02
    phi[5,4]  R2208     5.1917374134063721e-01
    phi[5,4]  R2209     -7.4462151527404785e-01
    phi[5,4]  R2210     -2.3624037206172943e-01
    phi[5,4]  R2211     1.4395651221275330e-01
    phi[5,4]  R2212     -4.3079802393913269e-01
    phi[5,4]  R2213     -3.8315358757972717e-01
    phi[5,4]  R2214     -1.6121819019317627e+00
    phi[5,4]  R2215     -4.8885753750801086e-01
    phi[5,4]  R2216     -7.0004051923751831e-01
    phi[5,4]  R2217     -9.7059744596481323e-01
    phi[5,4]  R2218     -9.8894137144088745e-01
    phi[5,4]  R2219     3.3406534790992737e-01
    phi[5,4]  R2220     -7.3677271604537964e-01
    phi[5,4]  R2221     -1.4649345874786377e+00
    phi[5,4]  R2222     -2.0685672760009766e+00
    phi[5,4]  R2223     -4.3808495998382568e-01
    phi[5,4]  R2224     -4.4889110326766968e-01
    phi[5,4]  R2225     5.9810751676559448e-01
    phi[5,4]  R2226     -2.1640841960906982e+00
    phi[5,4]  R2227     -9.6639132499694824e-01
    phi[5,4]  R2228     6.5917536616325378e-02
    phi[5,4]  R2229     -4.7011050581932068e-01
    phi[5,4]  R2230     -1.7950711250305176e+00
    phi[5,4]  R2231     -1.9064352512359619e+00
    phi[5,4]  R2232     4.6391388773918152e-01
    phi[5,4]  R2233     -2.1599395275115967e+00
    phi[5,4]  R2234     1.1403337717056274e+00
    phi[5,4]  R2235     2.2187242507934570e+00
    phi[5,4]  R2236     1.2167351245880127e+00
    phi[5,4]  R2237     1.2702466249465942e+00
    phi[5,4]  R2238     -6.1477798223495483e-01
    phi[5,4]  R2239     1.3048038482666016e+00
    phi[5,4]  R2240     2.1411089897155762e+00
    phi[5,4]  R2241     1.9234117269515991e+00
    phi[5,4]  R2242     9.2122542858123779e-01
    phi[5,4]  R2243     -2.7807433605194092e+00
    phi[5,4]  R2244     -8.6972367763519287e-01
    phi[5,4]  R2245     -2.5525028705596924e+00
    phi[5,4]  R2246     -1.4669482707977295e+00
    phi[5,4]  R2247     -4.1162583231925964e-01
    phi[5,4]  R2248     6.4589112997055054e-01
    phi[5,4]  R2249     -3.2548463344573975e-01
    phi[5,4]  R2250     9.3752861022949219e-01
    phi[5,4]  R2251     -1.5661417245864868e+00
    phi[5,4]  R2252     1.4478644728660583e-01
    phi[5,4]  R2253     -1.9105530977249146e+00
    phi[5,4]  R2254     -1.6939067840576172e+00
    phi[5,4]  R2255     1.1600785255432129e+00
    phi[5,4]  R2256     1.6215798854827881e+00
    phi[5,4]  R2257     1.0405100584030151e+00
    phi[5,4]  R2258     -2.9920685291290283e-01
    phi[5,4]  R2259     1.2267171144485474e+00
    phi[5,4]  R2260     1.2808082103729248e+00
    phi[5,4]  R2261     1.10845947265625
    phi[5,4]  R2262     -9.7849303483963013e-01
    phi[5,4]  R2263     -5.4005157947540283e-01
    phi[5,4]  R2264     4.7007542848587036e-01
    phi[5,4]  R2265     4.6532204747200012e-01
    phi[5,4]  R2266     1.2916998863220215e+00
    phi[5,4]  R2267     7.2122913599014282e-01
    phi[5,4]  R2268     1.0154050588607788e+00
    phi[5,4]  R2269     2.3482432365417480e+00
    phi[5,4]  R2270     1.4233335256576538e+00
    phi[5,4]  R2271     1.0756527185440063e+00
    phi[5,4]  R2272     1.5872042179107666e+00
    phi[7,4]  R36       -1
    phi[7,4]  R38       -2.8603264434106697e+00
    phi[7,4]  R39       0.891117401530515
    phi[7,4]  R40       1.5049006028496676e+00
    phi[7,4]  R41       2.0325712769264768e+00
    phi[7,4]  R42       3.7566161019448296e-01
    phi[7,4]  R43       -6.2225911388230881e-01
    phi[7,4]  R44       6.7259382067619677e-01
    phi[7,4]  R63       1
    phi[7,4]  R2273     -2.3967346122189870e-01
    phi[7,4]  R2274     -5.9603263480432380e+00
    phi[7,4]  R2275     -3.1311174110672582e+00
    phi[7,4]  R2276     -1.3488826080062282e+00
    phi[7,4]  R2277     -4.6049005074822364e+00
    phi[7,4]  R2278     -1.5950993017829007e+00
    phi[7,4]  R2279     -4.6025712101692751e+00
    phi[7,4]  R2280     -5.3742865631632109e-01
    phi[7,4]  R2281     -3.4756615148270513e+00
    phi[7,4]  R2282     -2.7243382944380854e+00
    phi[7,4]  R2283     -1.4677408002870027e+00
    phi[7,4]  R2284     -2.71225902805162
    phi[7,4]  R2285     -3.7725937253087651e+00
    phi[7,4]  R2286     -2.4274060839563716e+00
    phi[7,4]  R2287     -4.0986653770769044e-02
    phi[7,4]  R2288     -4.4372064564686564e-02
    phi[7,4]  R2289     -4.4517564730035764e-02
    phi[7,4]  R2290     -4.8033239116775928e-02
    phi[7,4]  R2291     -1.5426292174479272e-01
    phi[7,4]  R2292     -0.21514421226753
    phi[7,4]  R2293     -2.2927429821473533e-01
    phi[7,4]  R2294     -2.6972111165239765e-01
    phi[7,4]  R2295     -0.316555256910414
    phi[7,4]  R2296     -6.2696706542082037e-02
    phi[7,4]  R2297     -0.0883573479654105
    phi[7,4]  R2298     -1.3494490764336309e-01
    phi[7,4]  R2299     -1.4038269168676321e-01
    phi[7,4]  R2300     -1.7417940917833782e-01
    phi[7,4]  R2301     -2.0308768104606434e-01
    phi[7,4]  R2302     -2.1529740473255710e-01
    phi[7,4]  R2303     -2.1622603721781664e-01
    phi[7,4]  R2304     -2.1746432852502395e-01
    phi[7,4]  R2305     -2.2616027810110428e-01
    phi[7,4]  R2306     -5.3838970011367060e-02
    phi[7,4]  R2307     -9.2043462227852979e-02
    phi[7,4]  R2308     -1.7961578523042721e-01
    phi[7,4]  R2309     -1.7987093247627395e-01
    phi[7,4]  R2310     -1.8321031425411749e-01
    phi[7,4]  R2311     -1.8444452500611785e-01
    phi[7,4]  R2312     -1.8467285592542138e-01
    phi[7,4]  R2313     -1.8468496767739651e-01
    phi[7,4]  R2314     -1.8573193797403964e-01
    phi[7,4]  R2315     -1.8932600666167931e-01
    phi[7,4]  R2316     -1.7810117242687351e-01
    phi[7,4]  R2317     -1.8918093750108012e-01
    phi[7,4]  R2318     -2.2323723195695266e-01
    phi[7,4]  R2319     -2.2494263337363263e-01
    phi[7,4]  R2320     -2.2688196459305587e-01
    phi[7,4]  R2321     -2.2933836030967547e-01
    phi[7,4]  R2322     -2.3302787320006457e-01
    phi[7,4]  R2323     -2.3491068802090842e-01
    phi[7,4]  R2324     -2.5582729174260743e-01
    phi[7,4]  R2325     -2.5832292097229992e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2326     -3.0999999046325684e+00
    phi[5,6]  R2327     -3.0999999046325684e+00
    phi[5,6]  R2328     -2.2400000095367432e+00
    phi[5,6]  R2329     -2.2400000095367432e+00
    phi[5,6]  R2330     -3.0999999046325684e+00
    phi[5,6]  R2331     -3.0999999046325684e+00
    phi[5,6]  R2332     -2.5699999332427979e+00
    phi[5,6]  R2333     -2.5699999332427979e+00
    phi[5,6]  R2334     -3.0999999046325684e+00
    phi[5,6]  R2335     -3.0999999046325684e+00
    phi[5,6]  R2336     -2.0899999141693115e+00
    phi[5,6]  R2337     -2.0899999141693115e+00
    phi[5,6]  R2338     -3.0999999046325684e+00
    phi[5,6]  R2339     -3.0999999046325684e+00
    phi[5,6]  R2340     1.5325810015201569e-01
    phi[5,6]  R2341     5.7673519849777222e-01
    phi[5,6]  R2342     6.5352284908294678e-01
    phi[5,6]  R2343     5.8408007025718689e-02
    phi[5,6]  R2344     -2.3630050942301750e-02
    phi[5,6]  R2345     0.0279111098498106
    phi[5,6]  R2346     -1.1368327140808105e+00
    phi[5,6]  R2347     6.1336469650268555e-01
    phi[5,6]  R2348     1.2199049443006516e-01
    phi[5,6]  R2349     6.1222821474075317e-01
    phi[5,6]  R2350     -3.3533030748367310e-01
    phi[5,6]  R2351     -2.2070416808128357e-01
    phi[5,6]  R2352     2.0725883543491364e-02
    phi[5,6]  R2353     -3.5494214296340942e-01
    phi[5,6]  R2354     -7.1019774675369263e-01
    phi[5,6]  R2355     -4.6633702516555786e-01
    phi[5,6]  R2356     -4.7228738665580750e-02
    phi[5,6]  R2357     -3.6395901441574097e-01
    phi[5,6]  R2358     -3.0920368432998657e-01
    phi[5,6]  R2359     -5.9512734413146973e-02
    phi[5,6]  R2360     -1.5812058448791504e+00
    phi[5,6]  R2361     -1.1009780168533325e+00
    phi[5,6]  R2362     7.8923009335994720e-02
    phi[5,6]  R2363     5.1917374134063721e-01
    phi[5,6]  R2364     -7.4462151527404785e-01
    phi[5,6]  R2365     -2.3624037206172943e-01
    phi[5,6]  R2366     1.4395651221275330e-01
    phi[5,6]  R2367     -4.3079802393913269e-01
    phi[5,6]  R2368     -3.8315358757972717e-01
    phi[5,6]  R2369     -1.6121819019317627e+00
    phi[5,6]  R2370     -4.8885753750801086e-01
    phi[5,6]  R2371     -7.0004051923751831e-01
    phi[5,6]  R2372     -9.7059744596481323e-01
    phi[5,6]  R2373     -9.8894137144088745e-01
    phi[5,6]  R2374     3.3406534790992737e-01
    phi[5,6]  R2375     -7.3677271604537964e-01
    phi[5,6]  R2376     -1.4649345874786377e+00
    phi[5,6]  R2377     -2.0685672760009766e+00
    phi[5,6]  R2378     -4.3808495998382568e-01
    phi[5,6]  R2379     -4.4889110326766968e-01
    phi[5,6]  R2380     5.9810751676559448e-01
    phi[5,6]  R2381     -2.1640841960906982e+00
    phi[5,6]  R2382     -9.6639132499694824e-01
    phi[5,6]  R2383     6.5917536616325378e-02
    phi[5,6]  R2384     -4.7011050581932068e-01
    phi[5,6]  R2385     -1.7950711250305176e+00
    phi[5,6]  R2386     -1.9064352512359619e+00
    phi[5,6]  R2387     4.6391388773918152e-01
    phi[5,6]  R2388     -2.1599395275115967e+00
    phi[5,6]  R2389     -3.2760536670684814e-01
    phi[5,6]  R2390     -4.6339789032936096e-01
    phi[5,6]  R2391     2.3866379261016846e-01
    phi[5,6]  R2392     -9.4490915536880493e-01
    phi[5,6]  R2393     -1.0642709732055664e+00
    phi[5,6]  R2394     -3.3107733726501465e-01
    phi[5,6]  R2395     1.6220751404762268e-01
    phi[5,6]  R2396     -1.2295907735824585e+00
    phi[5,6]  R2397     -3.8355121016502380e-01
    phi[5,6]  R2398     -2.4086223915219307e-02
    phi[5,6]  R2399     -1.4405786991119385e-01
    phi[5,6]  R2400     1.3001175597310066e-02
    phi[5,6]  R2401     -0.490697979927063
    phi[5,6]  R2402     -3.3605548739433289e-01
    phi[5,6]  R2403     -7.0406931638717651e-01
    phi[5,6]  R2404     -1.4762908220291138e+00
    phi[5,6]  R2405     -6.8852889537811279e-01
    phi[5,6]  R2406     -9.7410839796066284e-01
    phi[5,6]  R2407     1.9746525585651398e-01
    phi[5,6]  R2408     -1.3183850049972534e+00
    phi[5,6]  R2409     -9.7448450326919556e-01
    phi[5,6]  R2410     -8.2670742273330688e-01
    phi[5,6]  R2411     -6.8360388278961182e-01
    phi[5,6]  R2412     -0.641730546951294
    phi[5,6]  R2413     -4.1614958643913269e-01
    phi[5,6]  R2414     -1.2708084583282471e+00
    phi[5,6]  R2415     -3.9488604664802551e-01
    phi[5,6]  R2416     -3.7095078825950623e-01
    phi[5,6]  R2417     -1.1115583181381226e+00
    phi[5,6]  R2418     -2.0326276123523712e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2419     -3.0999999046325684e+00
    phi[6,5]  R2420     -3.0999999046325684e+00
    phi[6,5]  R2421     -2.2400000095367432e+00
    phi[6,5]  R2422     -2.2400000095367432e+00
    phi[6,5]  R2423     -3.0999999046325684e+00
    phi[6,5]  R2424     -3.0999999046325684e+00
    phi[6,5]  R2425     -2.5699999332427979e+00
    phi[6,5]  R2426     -2.5699999332427979e+00
    phi[6,5]  R2427     -3.0999999046325684e+00
    phi[6,5]  R2428     -3.0999999046325684e+00
    phi[6,5]  R2429     -2.0899999141693115e+00
    phi[6,5]  R2430     -2.0899999141693115e+00
    phi[6,5]  R2431     -3.0999999046325684e+00
    phi[6,5]  R2432     -3.0999999046325684e+00
    phi[6,5]  R2433     -3.2760536670684814e-01
    phi[6,5]  R2434     -4.6339789032936096e-01
    phi[6,5]  R2435     2.3866379261016846e-01
    phi[6,5]  R2436     -9.4490915536880493e-01
    phi[6,5]  R2437     -1.0642709732055664e+00
    phi[6,5]  R2438     -3.3107733726501465e-01
    phi[6,5]  R2439     1.6220751404762268e-01
    phi[6,5]  R2440     -1.2295907735824585e+00
    phi[6,5]  R2441     -3.8355121016502380e-01
    phi[6,5]  R2442     -2.4086223915219307e-02
    phi[6,5]  R2443     -1.4405786991119385e-01
    phi[6,5]  R2444     1.3001175597310066e-02
    phi[6,5]  R2445     -0.490697979927063
    phi[6,5]  R2446     -3.3605548739433289e-01
    phi[6,5]  R2447     -7.0406931638717651e-01
    phi[6,5]  R2448     -1.4762908220291138e+00
    phi[6,5]  R2449     -6.8852889537811279e-01
    phi[6,5]  R2450     -9.7410839796066284e-01
    phi[6,5]  R2451     1.9746525585651398e-01
    phi[6,5]  R2452     -1.3183850049972534e+00
    phi[6,5]  R2453     -9.7448450326919556e-01
    phi[6,5]  R2454     -8.2670742273330688e-01
    phi[6,5]  R2455     -6.8360388278961182e-01
    phi[6,5]  R2456     -0.641730546951294
    phi[6,5]  R2457     -4.1614958643913269e-01
    phi[6,5]  R2458     -1.2708084583282471e+00
    phi[6,5]  R2459     -3.9488604664802551e-01
    phi[6,5]  R2460     -3.7095078825950623e-01
    phi[6,5]  R2461     -1.1115583181381226e+00
    phi[6,5]  R2462     -2.0326276123523712e-01
    phi[6,5]  R2463     1.5325810015201569e-01
    phi[6,5]  R2464     5.7673519849777222e-01
    phi[6,5]  R2465     6.5352284908294678e-01
    phi[6,5]  R2466     5.8408007025718689e-02
    phi[6,5]  R2467     -2.3630050942301750e-02
    phi[6,5]  R2468     0.0279111098498106
    phi[6,5]  R2469     -1.1368327140808105e+00
    phi[6,5]  R2470     6.1336469650268555e-01
    phi[6,5]  R2471     1.2199049443006516e-01
    phi[6,5]  R2472     6.1222821474075317e-01
    phi[6,5]  R2473     -3.3533030748367310e-01
    phi[6,5]  R2474     -2.2070416808128357e-01
    phi[6,5]  R2475     2.0725883543491364e-02
    phi[6,5]  R2476     -3.5494214296340942e-01
    phi[6,5]  R2477     -7.1019774675369263e-01
    phi[6,5]  R2478     -4.6633702516555786e-01
    phi[6,5]  R2479     -4.7228738665580750e-02
    phi[6,5]  R2480     -3.6395901441574097e-01
    phi[6,5]  R2481     -3.0920368432998657e-01
    phi[6,5]  R2482     -5.9512734413146973e-02
    phi[6,5]  R2483     -1.5812058448791504e+00
    phi[6,5]  R2484     -1.1009780168533325e+00
    phi[6,5]  R2485     7.8923009335994720e-02
    phi[6,5]  R2486     5.1917374134063721e-01
    phi[6,5]  R2487     -7.4462151527404785e-01
    phi[6,5]  R2488     -2.3624037206172943e-01
    phi[6,5]  R2489     1.4395651221275330e-01
    phi[6,5]  R2490     -4.3079802393913269e-01
    phi[6,5]  R2491     -3.8315358757972717e-01
    phi[6,5]  R2492     -1.6121819019317627e+00
    phi[6,5]  R2493     -4.8885753750801086e-01
    phi[6,5]  R2494     -7.0004051923751831e-01
    phi[6,5]  R2495     -9.7059744596481323e-01
    phi[6,5]  R2496     -9.8894137144088745e-01
    phi[6,5]  R2497     3.3406534790992737e-01
    phi[6,5]  R2498     -7.3677271604537964e-01
    phi[6,5]  R2499     -1.4649345874786377e+00
    phi[6,5]  R2500     -2.0685672760009766e+00
    phi[6,5]  R2501     -4.3808495998382568e-01
    phi[6,5]  R2502     -4.4889110326766968e-01
    phi[6,5]  R2503     5.9810751676559448e-01
    phi[6,5]  R2504     -2.1640841960906982e+00
    phi[6,5]  R2505     -9.6639132499694824e-01
    phi[6,5]  R2506     6.5917536616325378e-02
    phi[6,5]  R2507     -4.7011050581932068e-01
    phi[6,5]  R2508     -1.7950711250305176e+00
    phi[6,5]  R2509     -1.9064352512359619e+00
    phi[6,5]  R2510     4.6391388773918152e-01
    phi[6,5]  R2511     -2.1599395275115967e+00
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       -2.4520310301910944e+00
    phi[6,8]  R57       -3.7607365201031140e-02
    phi[6,8]  R58       -2.4145287913469855e+00
    phi[6,8]  R59       -1.2147648659205896e+00
    phi[6,8]  R60       4.1852085624594437e-01
    phi[6,8]  R61       7.7177737662014834e-01
    phi[6,8]  R62       -1.1283302472094747e+00
    phi[6,8]  R64       -1
    phi[6,8]  R2512     -5.5520309348236623e+00
    phi[6,8]  R2513     -0.647968874441474
    phi[6,8]  R2514     -2.2776073747377743e+00
    phi[6,8]  R2515     -2.2023926443357120e+00
    phi[6,8]  R2516     -5.5145286959795534e+00
    phi[6,8]  R2517     -6.8547111328558286e-01
    phi[6,8]  R2518     -3.7847647991633875e+00
    phi[6,8]  R2519     -1.3552350673222082e+00
    phi[6,8]  R2520     -2.6814790483866240e+00
    phi[6,8]  R2521     -3.5185207608785127e+00
    phi[6,8]  R2522     -1.3182225375491632e+00
    phi[6,8]  R2523     -2.86177729078946
    phi[6,8]  R2524     -4.2283301518420426e+00
    phi[6,8]  R2525     -1.9716696574230936e+00
    phi[6,8]  R2526     -1.0210676343910463e-01
    phi[6,8]  R2527     -1.0663868252001651e-01
    phi[6,8]  R2528     -1.1529897572361142e-01
    phi[6,8]  R2529     -1.2296000072326929e-01
    phi[6,8]  R2530     -1.2833610141898077e-01
    phi[6,8]  R2531     -1.2930819063739238e-01
    phi[6,8]  R2532     -1.2939385757237232e-01
    phi[6,8]  R2533     -0.145059411250259
    phi[6,8]  R2534     -1.5822085803809460e-01
    phi[6,8]  R2535     -1.8974802108995603e-01
    phi[6,8]  R2536     -8.0483852583010318e-01
    phi[6,8]  R2537     -3.4867677699454858e-01
    phi[6,8]  R2538     -1.1974560167688897e+00
    phi[6,8]  R2539     -4.7181556939743363e-01
    phi[6,8]  R2540     -9.1969609943267627e-01
    phi[6,8]  R2541     -9.3320026397015354e-01
    phi[6,8]  R2542     -9.5733809568810324e-01
    phi[6,8]  R2543     -9.7950106366064571e-01
    phi[6,8]  R2544     -9.9791370975166660e-01
    phi[6,8]  R2545     -1.0267118879982009e+00
    phi[6,8]  R2546     -3.5308849249513008e-01
    phi[6,8]  R2547     -3.8452193902070930e-01
    phi[6,8]  R2548     -4.7685155720487515e-01
    phi[6,8]  R2549     -6.6568402820467409e-01
    phi[6,8]  R2550     -6.9063547373100576e-01
    phi[6,8]  R2551     -6.9365614084238547e-01
    phi[6,8]  R2552     -7.1245419587718306e-01
    phi[6,8]  R2553     -2.6519614524959430e+00
    phi[6,8]  R2554     -0.772925461304031
    phi[6,8]  R2555     -7.8640238340885227e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       6.5370810031890869e-01
    z[0,1,0]  R80       7.1117323637008667e-01
    z[0,1,0]  R81       8.4120273590087891e-01
    z[0,1,0]  R82       5.2209275960922241e-01
    z[0,1,0]  R83       6.1571907252073288e-02
    z[0,1,0]  R84       -8.9026167988777161e-03
    z[0,1,0]  R85       -3.8989506661891937e-02
    z[0,1,0]  R86       6.7693866789340973e-02
    z[0,1,0]  R87       4.4584628194570541e-02
    z[0,1,0]  R88       7.4828721582889557e-02
    z[0,1,0]  R89       -1.4557796716690063e-01
    z[0,1,0]  R90       -2.9112884402275085e-01
    z[0,1,0]  R91       1.5809562802314758e-01
    z[0,1,0]  R92       -1.6295441985130310e-01
    z[0,1,0]  R93       -1.3062354922294617e-01
    z[0,1,0]  R94       5.8467328548431396e-02
    z[0,1,0]  R95       -1.6511309146881104e-01
    z[0,1,0]  R96       0.758529543876648
    z[0,1,0]  R97       3.8202244043350220e-01
    z[0,1,0]  R98       0.561324417591095
    z[0,1,0]  R99       -0.367117315530777
    z[0,1,0]  R100      2.5374794006347656e-01
    z[0,1,0]  R101      5.7250201702117920e-01
    z[0,1,0]  R102      3.8465201854705811e-01
    z[0,1,0]  R103      1.7563463747501373e-01
    z[0,1,0]  R104      9.1865532100200653e-02
    z[0,1,0]  R105      -1.8892130255699158e-01
    z[0,1,0]  R106      -0.326642781496048
    z[0,1,0]  R107      -4.1802617907524109e-01
    z[0,1,0]  R108      7.2994068264961243e-02
    z[0,1,0]  R109      -1.6578853130340576e-01
    z[0,1,0]  R110      4.3377479910850525e-01
    z[0,1,0]  R111      3.9455017447471619e-01
    z[0,1,0]  R112      6.7611508071422577e-02
    z[0,1,0]  R113      2.4134321510791779e-01
    z[0,1,0]  R114      4.6399539709091187e-01
    z[0,1,0]  R115      5.6151503324508667e-01
    z[0,1,0]  R116      3.8915482163429260e-01
    z[0,1,0]  R117      2.5209689140319824e-01
    z[0,1,0]  R118      0.612575888633728
    z[0,1,0]  R119      2.2815930843353271e-01
    z[0,1,0]  R120      -2.3585041984915733e-02
    z[0,1,0]  R121      4.1781631112098694e-01
    z[0,1,0]  R122      0.655974805355072
    z[0,1,0]  R123      6.3054978847503662e-01
    z[0,1,0]  R124      4.2497199773788452e-01
    z[0,1,0]  R125      8.3781987428665161e-01
    z[0,1,0]  R126      -6.5555536746978760e-01
    z[0,1,0]  R127      -3.9329436421394348e-01
    z[0,1,0]  R128      6.2401664257049561e-01
    z[0,1,0]  R129      0.505494236946106
    z[0,1,0]  R130      6.6037893295288086e-01
    z[0,1,0]  R131      4.4774687290191650e-01
    z[0,1,0]  R132      4.8437824845314026e-01
    z[0,1,0]  R133      5.3428411483764648e-01
    z[0,1,0]  R134      6.4832133054733276e-01
    z[0,1,0]  R135      -7.6235592365264893e-02
    z[0,1,0]  R136      4.9269955605268478e-02
    z[0,1,0]  R137      -3.7443125247955322e-01
    z[0,1,0]  R138      -2.6094339787960052e-02
    z[0,1,0]  R139      -1.7339763045310974e-01
    z[0,1,0]  R140      5.1582396030426025e-01
    z[0,1,0]  R141      3.8748210668563843e-01
    z[0,1,0]  R142      6.2199622392654419e-01
    z[0,1,0]  R143      1.6083106398582458e-01
    z[0,1,0]  R144      -5.0983637571334839e-01
    z[0,1,0]  R145      -5.4045480489730835e-01
    z[0,1,0]  R146      -1.6421714425086975e-01
    z[0,1,0]  R147      7.4362337589263916e-02
    z[0,1,0]  R148      -3.0733120441436768e-01
    z[0,1,0]  R149      1.2190082669258118e-01
    z[0,1,0]  R150      8.7008059024810791e-02
    z[0,1,0]  R151      3.0221480131149292e-01
    z[0,1,0]  R152      2.6016193628311157e-01
    z[0,1,0]  R153      2.4748301506042480e-01
    z[0,1,0]  R154      7.8136193752288818e-01
    z[0,1,0]  R155      4.5540583133697510e-01
    z[0,1,0]  R156      -0.0655539408326149
    z[0,1,0]  R157      -9.9040046334266663e-02
    z[0,1,0]  R158      1.5701797604560852e-01
    z[0,1,0]  R159      4.4143640995025635e-01
    z[0,1,0]  R160      3.5963547229766846e-01
    z[0,1,0]  R161      -2.4248990416526794e-01
    z[0,1,0]  R162      1.7267766594886780e-01
    z[0,1,0]  R163      -8.9693062007427216e-02
    z[0,1,0]  R164      2.3396338522434235e-01
    z[0,1,0]  R165      -1.8763886392116547e-01
    z[0,1,0]  R166      6.3462473452091217e-02
    z[0,1,0]  R167      5.1345992088317871e-01
    z[0,1,0]  R168      -2.9811403155326843e-01
    z[0,1,0]  R169      0.645882785320282
    z[0,1,0]  R170      6.6964232921600342e-01
    z[0,1,0]  R171      3.2339587807655334e-01
    z[0,1,0]  R172      0.0756298080086708
    z[0,1,0]  R173      1.8386992812156677e-01
    z[0,1,0]  R174      2.7939921617507935e-01
    z[0,1,0]  R175      2.6959127187728882e-01
    z[0,1,0]  R176      5.9965625405311584e-02
    z[0,1,0]  R177      3.8612468633800745e-03
    z[0,1,0]  R178      -3.8516032695770264e-01
    z[0,1,0]  R179      2.8719830513000488e-01
    z[0,1,0]  R180      -1.0021450370550156e-01
    z[0,1,0]  R181      -1.3037898577749729e-02
    z[0,1,0]  R182      2.0253281295299530e-01
    z[0,1,0]  R183      1.2343436479568481e-01
    z[0,1,0]  R184      1.8908047676086426e-01
    z[0,1,0]  R185      -3.3509114384651184e-01
    z[0,1,0]  R186      -2.0382659137248993e-01
    z[0,1,0]  R187      7.2123610973358154e-01
    z[0,1,0]  R188      2.8315272927284241e-01
    z[0,1,0]  R189      2.6582491397857666e-01
    z[0,1,0]  R190      -1.4259302616119385e-01
    z[0,1,0]  R191      1.0283294320106506e-01
    z[0,1,0]  R192      3.0567729473114014e-01
    z[0,1,0]  R193      1.2950356304645538e-01
    z[0,1,0]  R194      2.6565348729491234e-02
    z[0,1,0]  R195      -8.7781930342316628e-03
    z[0,1,0]  R196      -9.1276951134204865e-02
    z[0,1,0]  R197      5.2722871303558350e-01
    z[0,1,0]  R198      1.9307661568745971e-04
    z[0,1,0]  R199      7.6995693147182465e-02
    z[0,1,0]  R200      -1.2734183669090271e-01
    z[0,1,0]  R201      3.3917301893234253e-01
    z[0,1,0]  R202      2.6374366134405136e-02
    z[0,1,0]  R203      8.2131153345108032e-01
    z[0,1,0]  R204      4.5522559434175491e-02
    z[0,1,0]  R205      2.7312453836202621e-02
    z[0,1,0]  R206      -1.0336112976074219e-01
    z[0,1,0]  R207      -3.2615110278129578e-01
    z[0,1,0]  R208      -3.4594023227691650e-01
    z[0,1,0]  R209      2.8148117661476135e-01
    z[0,1,0]  R210      3.4922760725021362e-01
    z[0,1,0]  R211      3.0996146798133850e-01
    z[0,1,0]  R212      1.2708684802055359e-01
    z[0,1,0]  R213      1.3786189258098602e-01
    z[0,1,0]  R214      3.7735259532928467e-01
    z[0,1,0]  R215      2.9833212494850159e-01
    z[0,1,0]  R216      -1.2803736329078674e-01
    z[0,1,0]  R217      -1.1106203496456146e-01
    z[0,1,0]  R218      2.8687962330877781e-03
    z[0,1,0]  R219      2.8190642595291138e-01
    z[0,1,0]  R220      3.4562137722969055e-01
    z[0,1,0]  R221      -2.3160532116889954e-02
    z[0,1,0]  R222      -1.2331695854663849e-01
    z[0,1,0]  R223      3.4004177898168564e-02
    z[0,1,0]  R224      -4.1489630937576294e-01
    z[0,1,0]  R225      -2.6557642221450806e-01
    z[0,1,0]  R226      -1.1845907568931580e-01
    z[0,1,0]  R227      -1.9464151561260223e-01
    z[0,1,0]  R228      2.8730336576700211e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       -2.2679312527179718e-01
    z[0,1,1]  R80       -2.9191309213638306e-01
    z[0,1,1]  R81       2.7506455779075623e-01
    z[0,1,1]  R82       1.9605407491326332e-02
    z[0,1,1]  R83       -1.2485348433256149e-01
    z[0,1,1]  R84       1.9079299271106720e-01
    z[0,1,1]  R85       3.5919818282127380e-01
    z[0,1,1]  R86       2.1217736601829529e-01
    z[0,1,1]  R87       1.9420032203197479e-01
    z[0,1,1]  R88       2.6884013414382935e-01
    z[0,1,1]  R89       -4.5313993096351624e-01
    z[0,1,1]  R90       -3.1489136815071106e-01
    z[0,1,1]  R91       -3.5165268182754517e-01
    z[0,1,1]  R92       -2.2898840904235840e-01
    z[0,1,1]  R93       -4.1955053806304932e-02
    z[0,1,1]  R94       -1.4321479201316833e-01
    z[0,1,1]  R95       -2.4670347571372986e-01
    z[0,1,1]  R96       -0.0705266073346138
    z[0,1,1]  R97       -3.3981472253799438e-01
    z[0,1,1]  R98       -1.7385317385196686e-01
    z[0,1,1]  R99       2.9062485694885254e-01
    z[0,1,1]  R100      -7.2948127985000610e-02
    z[0,1,1]  R101      0.00988028198480606
    z[0,1,1]  R102      -3.7674322724342346e-02
    z[0,1,1]  R103      -3.2302632927894592e-02
    z[0,1,1]  R104      -2.0202779769897461e-01
    z[0,1,1]  R105      1.7496684193611145e-01
    z[0,1,1]  R106      2.7793058753013611e-01
    z[0,1,1]  R107      3.4806916117668152e-01
    z[0,1,1]  R108      2.6849013566970825e-01
    z[0,1,1]  R109      -8.3844490349292755e-02
    z[0,1,1]  R110      -9.4447515904903412e-02
    z[0,1,1]  R111      9.4490736722946167e-02
    z[0,1,1]  R112      -2.3460227251052856e-01
    z[0,1,1]  R113      -1.5209205448627472e-01
    z[0,1,1]  R114      1.8347331881523132e-01
    z[0,1,1]  R115      6.4633525907993317e-02
    z[0,1,1]  R116      4.3670570850372314e-01
    z[0,1,1]  R117      -1.0524497926235199e-01
    z[0,1,1]  R118      -5.0707951188087463e-02
    z[0,1,1]  R119      -3.4030193090438843e-01
    z[0,1,1]  R120      -2.0597891509532928e-01
    z[0,1,1]  R121      -1.4286459982395172e-01
    z[0,1,1]  R122      1.0545502603054047e-01
    z[0,1,1]  R123      1.5984825789928436e-01
    z[0,1,1]  R124      -2.7552312612533569e-01
    z[0,1,1]  R125      -2.2291575372219086e-01
    z[0,1,1]  R126      1.9611382484436035e-01
    z[0,1,1]  R127      3.6403939127922058e-01
    z[0,1,1]  R128      -2.1743577718734741e-01
    z[0,1,1]  R129      -2.6841464638710022e-01
    z[0,1,1]  R130      -0.270877480506897
    z[0,1,1]  R131      -2.9492446780204773e-01
    z[0,1,1]  R132      -1.5599857270717621e-01
    z[0,1,1]  R133      -0.0677003264427185
    z[0,1,1]  R134      -1.4299592934548855e-02
    z[0,1,1]  R135      -4.6287972480058670e-02
    z[0,1,1]  R136      -1.0172042250633240e-01
    z[0,1,1]  R137      4.3016073107719421e-01
    z[0,1,1]  R138      0.08734080940485
    z[0,1,1]  R139      -4.4155126810073853e-01
    z[0,1,1]  R140      -0.0909222811460495
    z[0,1,1]  R141      1.6748405992984772e-01
    z[0,1,1]  R142      4.7551002353429794e-02
    z[0,1,1]  R143      -3.4410160034894943e-02
    z[0,1,1]  R144      3.6228740215301514e-01
    z[0,1,1]  R145      3.5348224639892578e-01
    z[0,1,1]  R146      2.6601800322532654e-01
    z[0,1,1]  R147      2.8902328014373779e-01
    z[0,1,1]  R148      9.1782903671264648e-01
    z[0,1,1]  R149      -1.6991697251796722e-01
    z[0,1,1]  R150      -1.2021198123693466e-01
    z[0,1,1]  R151      5.0322914123535156e-01
    z[0,1,1]  R152      4.2183393239974976e-01
    z[0,1,1]  R153      4.2930355668067932e-01
    z[0,1,1]  R154      1.9643928110599518e-01
    z[0,1,1]  R155      7.2861391305923462e-01
    z[0,1,1]  R156      7.2586512565612793e-01
    z[0,1,1]  R157      6.2076145410537720e-01
    z[0,1,1]  R158      5.3477644920349121e-01
    z[0,1,1]  R159      -5.7719420641660690e-02
    z[0,1,1]  R160      4.3008357286453247e-01
    z[0,1,1]  R161      7.1668881177902222e-01
    z[0,1,1]  R162      -0.883419394493103
    z[0,1,1]  R163      3.3213075995445251e-01
    z[0,1,1]  R164      6.6292655467987061e-01
    z[0,1,1]  R165      7.8095215559005737e-01
    z[0,1,1]  R166      5.9684544801712036e-01
    z[0,1,1]  R167      4.7032064199447632e-01
    z[0,1,1]  R168      3.3033528923988342e-01
    z[0,1,1]  R169      -1.8666094541549683e-01
    z[0,1,1]  R170      4.6317240595817566e-01
    z[0,1,1]  R171      -1.3988637924194336e-01
    z[0,1,1]  R172      5.5366027355194092e-01
    z[0,1,1]  R173      2.9774689674377441e-01
    z[0,1,1]  R174      5.5339790880680084e-02
    z[0,1,1]  R175      -5.6207644939422607e-01
    z[0,1,1]  R176      1.1363073438405991e-01
    z[0,1,1]  R177      5.7327234745025635e-01
    z[0,1,1]  R178      8.8000553846359253e-01
    z[0,1,1]  R179      8.5935018956661224e-02
    z[0,1,1]  R180      1.2243407964706421e-01
    z[0,1,1]  R181      1.2666161358356476e-01
    z[0,1,1]  R182      -1.5021903812885284e-01
    z[0,1,1]  R183      2.1114858984947205e-01
    z[0,1,1]  R184      -4.9134314060211182e-01
    z[0,1,1]  R185      3.0135393142700195e-01
    z[0,1,1]  R186      4.8563334345817566e-01
    z[0,1,1]  R187      -0.431154727935791
    z[0,1,1]  R188      3.3930018544197083e-01
    z[0,1,1]  R189      -5.1909035444259644e-01
    z[0,1,1]  R190      -8.2570560276508331e-02
    z[0,1,1]  R191      0.361701637506485
    z[0,1,1]  R192      2.4564903974533081e-01
    z[0,1,1]  R193      2.9356616735458374e-01
    z[0,1,1]  R194      1.5386205911636353e-01
    z[0,1,1]  R195      -5.1868957281112671e-01
    z[0,1,1]  R196      8.2093916833400726e-02
    z[0,1,1]  R197      -4.4982436299324036e-01
    z[0,1,1]  R198      3.2640573382377625e-01
    z[0,1,1]  R199      4.1391676664352417e-01
    z[0,1,1]  R200      -2.6323437690734863e-01
    z[0,1,1]  R201      -1.6353602707386017e-01
    z[0,1,1]  R202      -8.1723339855670929e-02
    z[0,1,1]  R203      5.5401228368282318e-02
    z[0,1,1]  R204      -1.9173620641231537e-01
    z[0,1,1]  R205      -5.3725861012935638e-02
    z[0,1,1]  R206      6.6931024193763733e-02
    z[0,1,1]  R207      7.4424481391906738e-01
    z[0,1,1]  R208      6.7177957296371460e-01
    z[0,1,1]  R209      4.7372713685035706e-01
    z[0,1,1]  R210      -1.3733093440532684e-01
    z[0,1,1]  R211      -5.6713593006134033e-01
    z[0,1,1]  R212      5.3955519199371338e-01
    z[0,1,1]  R213      7.9679578542709351e-02
    z[0,1,1]  R214      -2.2865033149719238e-01
    z[0,1,1]  R215      4.1618752479553223e-01
    z[0,1,1]  R216      4.9980757758021355e-03
    z[0,1,1]  R217      0.787831723690033
    z[0,1,1]  R218      7.3669201135635376e-01
    z[0,1,1]  R219      -3.4342417120933533e-01
    z[0,1,1]  R220      5.0888639688491821e-01
    z[0,1,1]  R221      -1.3661010563373566e-01
    z[0,1,1]  R222      -4.2335250973701477e-01
    z[0,1,1]  R223      7.9447090625762939e-01
    z[0,1,1]  R224      6.1699497699737549e-01
    z[0,1,1]  R225      6.7754375934600830e-01
    z[0,1,1]  R226      -7.0698434114456177e-01
    z[0,1,1]  R227      -6.3214230537414551e-01
    z[0,1,1]  R228      -7.0445472002029419e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       8.3470441401004791e-02
    z[0,1,2]  R80       3.8476087152957916e-02
    z[0,1,2]  R81       2.8873598575592041e-01
    z[0,1,2]  R82       1.6556492447853088e-01
    z[0,1,2]  R83       2.8725165128707886e-01
    z[0,1,2]  R84       -8.4224832057952881e-01
    z[0,1,2]  R85       -5.8925980329513550e-01
    z[0,1,2]  R86       -6.7917782068252563e-01
    z[0,1,2]  R87       -7.1529638767242432e-01
    z[0,1,2]  R88       -5.9789091348648071e-01
    z[0,1,2]  R89       2.9072910547256470e-01
    z[0,1,2]  R90       3.1898257136344910e-01
    z[0,1,2]  R91       7.5956201553344727e-01
    z[0,1,2]  R92       7.4666303396224976e-01
    z[0,1,2]  R93       0.505126416683197
    z[0,1,2]  R94       1.7032857239246368e-01
    z[0,1,2]  R95       4.6780437231063843e-01
    z[0,1,2]  R96       7.2464540600776672e-02
    z[0,1,2]  R97       6.0924118757247925e-01
    z[0,1,2]  R98       3.5284444689750671e-01
    z[0,1,2]  R99       -8.1702905893325806e-01
    z[0,1,2]  R100      5.5323904752731323e-01
    z[0,1,2]  R101      4.4137695431709290e-01
    z[0,1,2]  R102      5.7123631238937378e-01
    z[0,1,2]  R103      2.5803306698799133e-01
    z[0,1,2]  R104      6.0710644721984863e-01
    z[0,1,2]  R105      -5.4919117689132690e-01
    z[0,1,2]  R106      -0.506799042224884
    z[0,1,2]  R107      -4.6140092611312866e-01
    z[0,1,2]  R108      3.8230541348457336e-01
    z[0,1,2]  R109      1.3293799757957458e-01
    z[0,1,2]  R110      4.8885592818260193e-01
    z[0,1,2]  R111      4.8153975605964661e-01
    z[0,1,2]  R112      1.2029406428337097e-01
    z[0,1,2]  R113      6.9337779283523560e-01
    z[0,1,2]  R114      4.2525851726531982e-01
    z[0,1,2]  R115      2.5272551178932190e-01
    z[0,1,2]  R116      4.4809684157371521e-01
    z[0,1,2]  R117      7.2975230216979980e-01
    z[0,1,2]  R118      0.188186377286911
    z[0,1,2]  R119      2.5500911474227905e-01
    z[0,1,2]  R120      -8.5257776081562042e-03
    z[0,1,2]  R121      3.4689456224441528e-02
    z[0,1,2]  R122      5.5537760257720947e-01
    z[0,1,2]  R123      6.4251339435577393e-01
    z[0,1,2]  R124      6.6550296545028687e-01
    z[0,1,2]  R125      1.0407479852437973e-01
    z[0,1,2]  R126      -4.6777981519699097e-01
    z[0,1,2]  R127      -6.9043183326721191e-01
    z[0,1,2]  R128      5.1425766944885254e-01
    z[0,1,2]  R129      3.2647156715393066e-01
    z[0,1,2]  R130      5.0981956720352173e-01
    z[0,1,2]  R131      7.0545291900634766e-01
    z[0,1,2]  R132      5.3512346744537354e-01
    z[0,1,2]  R133      4.9972110986709595e-01
    z[0,1,2]  R134      0.391156941652298
    z[0,1,2]  R135      3.2480636239051819e-01
    z[0,1,2]  R136      2.7096980810165405e-01
    z[0,1,2]  R137      -4.1731411218643188e-01
    z[0,1,2]  R138      -0.178622305393219
    z[0,1,2]  R139      6.4340072870254517e-01
    z[0,1,2]  R140      -3.1454391777515411e-02
    z[0,1,2]  R141      5.2287101745605469e-01
    z[0,1,2]  R142      2.2768445312976837e-01
    z[0,1,2]  R143      4.5462402701377869e-01
    z[0,1,2]  R144      -5.8153760433197021e-01
    z[0,1,2]  R145      -6.9444268941879272e-01
    z[0,1,2]  R146      -2.5282454490661621e-01
    z[0,1,2]  R147      -2.2663612663745880e-01
    z[0,1,2]  R148      1.1399599909782410e-01
    z[0,1,2]  R149      5.9869188070297241e-01
    z[0,1,2]  R150      2.9843065142631531e-01
    z[0,1,2]  R151      2.6460850238800049e-01
    z[0,1,2]  R152      3.4760057926177979e-02
    z[0,1,2]  R153      3.0230289697647095e-01
    z[0,1,2]  R154      -2.0901657640933990e-01
    z[0,1,2]  R155      1.1959838122129440e-01
    z[0,1,2]  R156      6.6681647300720215e-01
    z[0,1,2]  R157      -4.3016105890274048e-01
    z[0,1,2]  R158      -6.4490920305252075e-01
    z[0,1,2]  R159      2.7831861376762390e-01
    z[0,1,2]  R160      3.2640692591667175e-01
    z[0,1,2]  R161      -2.5030997395515442e-01
    z[0,1,2]  R162      2.2311314940452576e-01
    z[0,1,2]  R163      3.3854430913925171e-01
    z[0,1,2]  R164      2.9363412410020828e-02
    z[0,1,2]  R165      -1.3518701493740082e-01
    z[0,1,2]  R166      -3.1465950608253479e-01
    z[0,1,2]  R167      -3.4053522348403931e-01
    z[0,1,2]  R168      3.8307452201843262e-01
    z[0,1,2]  R169      1.5904194116592407e-01
    z[0,1,2]  R170      4.5045712590217590e-01
    z[0,1,2]  R171      -3.6079365015029907e-01
    z[0,1,2]  R172      5.9527742862701416e-01
    z[0,1,2]  R173      6.1822026968002319e-01
    z[0,1,2]  R174      4.3528366088867188e-01
    z[0,1,2]  R175      -1.3250146806240082e-01
    z[0,1,2]  R176      7.8870460391044617e-02
    z[0,1,2]  R177      -2.5467187166213989e-02
    z[0,1,2]  R178      -7.9486265778541565e-02
    z[0,1,2]  R179      7.1662414073944092e-01
    z[0,1,2]  R180      6.2009769678115845e-01
    z[0,1,2]  R181      6.6452652215957642e-01
    z[0,1,2]  R182      8.1538534164428711e-01
    z[0,1,2]  R183      1.4778582751750946e-01
    z[0,1,2]  R184      1.0131459683179855e-01
    z[0,1,2]  R185      0.688653290271759
    z[0,1,2]  R186      5.4570317268371582e-01
    z[0,1,2]  R187      -9.4202525913715363e-02
    z[0,1,2]  R188      -5.0470698624849319e-02
    z[0,1,2]  R189      4.8978269100189209e-01
    z[0,1,2]  R190      8.9249360561370850e-01
    z[0,1,2]  R191      1.2544372677803040e-01
    z[0,1,2]  R192      3.1213113665580750e-01
    z[0,1,2]  R193      -2.7585986256599426e-01
    z[0,1,2]  R194      -3.1035137176513672e-01
    z[0,1,2]  R195      -4.3089857697486877e-01
    z[0,1,2]  R196      -1.1614146083593369e-01
    z[0,1,2]  R197      -5.8289320440962911e-04
    z[0,1,2]  R198      -2.4012021720409393e-01
    z[0,1,2]  R199      4.1218116879463196e-01
    z[0,1,2]  R200      -3.3402808010578156e-02
    z[0,1,2]  R201      -1.1080418527126312e-01
    z[0,1,2]  R202      2.7810338139533997e-01
    z[0,1,2]  R203      1.9780190289020538e-01
    z[0,1,2]  R204      -3.7223607301712036e-01
    z[0,1,2]  R205      1.3389432430267334e-01
    z[0,1,2]  R206      -1.4040251076221466e-01
    z[0,1,2]  R207      -4.5583599805831909e-01
    z[0,1,2]  R208      -5.4609888792037964e-01
    z[0,1,2]  R209      4.7746098041534424e-01
    z[0,1,2]  R210      7.1907371282577515e-01
    z[0,1,2]  R211      4.9191007018089294e-01
    z[0,1,2]  R212      7.5943440198898315e-01
    z[0,1,2]  R213      6.0824835300445557e-01
    z[0,1,2]  R214      3.2030174136161804e-01
    z[0,1,2]  R215      6.9243609905242920e-01
    z[0,1,2]  R216      -0.016898138448596
    z[0,1,2]  R217      -3.6733978986740112e-01
    z[0,1,2]  R218      -2.9070207476615906e-01
    z[0,1,2]  R219      5.8625358343124390e-01
    z[0,1,2]  R220      0.732223391532898
    z[0,1,2]  R221      -9.6521571278572083e-02
    z[0,1,2]  R222      -1.9231060519814491e-02
    z[0,1,2]  R223      -0.481898695230484
    z[0,1,2]  R224      -3.1801348924636841e-01
    z[0,1,2]  R225      -1.2653756141662598e-01
    z[0,1,2]  R226      -1.1570768803358078e-01
    z[0,1,2]  R227      -2.9008877277374268e-01
    z[0,1,2]  R228      -4.9061864614486694e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       -4.7666269540786743e-01
    z[0,1,3]  R80       -4.4922330975532532e-01
    z[0,1,3]  R81       6.1476852744817734e-02
    z[0,1,3]  R82       -3.2740056514739990e-01
    z[0,1,3]  R83       -6.3198663294315338e-02
    z[0,1,3]  R84       -3.5486346483230591e-01
    z[0,1,3]  R85       -4.3319106101989746e-01
    z[0,1,3]  R86       -4.7567120194435120e-01
    z[0,1,3]  R87       -6.6029065847396851e-01
    z[0,1,3]  R88       -0.583728551864624
    z[0,1,3]  R89       -3.2236695289611816e-01
    z[0,1,3]  R90       -7.2486883401870728e-01
    z[0,1,3]  R91       -2.7400314807891846e-01
    z[0,1,3]  R92       -2.1184596419334412e-01
    z[0,1,3]  R93       -4.4912162423133850e-01
    z[0,1,3]  R94       -4.5159086585044861e-01
    z[0,1,3]  R95       1.6839260933920741e-03
    z[0,1,3]  R96       0.598764181137085
    z[0,1,3]  R97       4.4689339399337769e-01
    z[0,1,3]  R98       5.1332950592041016e-01
    z[0,1,3]  R99       -2.8303396701812744e-01
    z[0,1,3]  R100      0.466047078371048
    z[0,1,3]  R101      2.2941111028194427e-01
    z[0,1,3]  R102      0.624661386013031
    z[0,1,3]  R103      4.3578910827636719e-01
    z[0,1,3]  R104      2.3679597675800323e-01
    z[0,1,3]  R105      -5.4818040132522583e-01
    z[0,1,3]  R106      -5.4645639657974243e-01
    z[0,1,3]  R107      -3.0926057696342468e-01
    z[0,1,3]  R108      6.7048561573028564e-01
    z[0,1,3]  R109      -8.0479115247726440e-01
    z[0,1,3]  R110      6.2632894515991211e-01
    z[0,1,3]  R111      6.9283038377761841e-01
    z[0,1,3]  R112      4.7617882490158081e-02
    z[0,1,3]  R113      3.4029385447502136e-01
    z[0,1,3]  R114      7.7173836529254913e-02
    z[0,1,3]  R115      3.3433189988136292e-01
    z[0,1,3]  R116      3.0583688616752625e-01
    z[0,1,3]  R117      4.6924594044685364e-01
    z[0,1,3]  R118      1.2052089720964432e-01
    z[0,1,3]  R119      -1.3106903433799744e-01
    z[0,1,3]  R120      -1.8353970348834991e-01
    z[0,1,3]  R121      -1.2935988605022430e-01
    z[0,1,3]  R122      2.5674277544021606e-01
    z[0,1,3]  R123      3.4229108691215515e-01
    z[0,1,3]  R124      4.6737492084503174e-01
    z[0,1,3]  R125      2.9534491896629333e-01
    z[0,1,3]  R126      -5.4688894748687744e-01
    z[0,1,3]  R127      -1.1105062067508698e-01
    z[0,1,3]  R128      4.0439051389694214e-01
    z[0,1,3]  R129      0.212955504655838
    z[0,1,3]  R130      3.5166999697685242e-01
    z[0,1,3]  R131      4.3048301339149475e-01
    z[0,1,3]  R132      4.8108947277069092e-01
    z[0,1,3]  R133      3.6428511142730713e-01
    z[0,1,3]  R134      5.4846316576004028e-01
    z[0,1,3]  R135      0.813058078289032
    z[0,1,3]  R136      0.588672399520874
    z[0,1,3]  R137      5.4731898009777069e-02
    z[0,1,3]  R138      6.9241464138031006e-01
    z[0,1,3]  R139      -3.9888751506805420e-01
    z[0,1,3]  R140      -7.6385718584060669e-01
    z[0,1,3]  R141      3.9119008183479309e-01
    z[0,1,3]  R142      -1.2299574166536331e-01
    z[0,1,3]  R143      0.621128261089325
    z[0,1,3]  R144      1.0593704134225845e-01
    z[0,1,3]  R145      2.2778582572937012e-01
    z[0,1,3]  R146      0.863503098487854
    z[0,1,3]  R147      7.6651722192764282e-01
    z[0,1,3]  R148      1.5615323185920715e-01
    z[0,1,3]  R149      -2.0467333495616913e-01
    z[0,1,3]  R150      -1.1645700782537460e-01
    z[0,1,3]  R151      -5.9696710109710693e-01
    z[0,1,3]  R152      -4.8272362351417542e-01
    z[0,1,3]  R153      -3.1169405579566956e-01
    z[0,1,3]  R154      -2.3703196644783020e-01
    z[0,1,3]  R155      2.1501252427697182e-02
    z[0,1,3]  R156      -1.0696186125278473e-01
    z[0,1,3]  R157      1.3313871622085571e-01
    z[0,1,3]  R158      -9.0374141931533813e-02
    z[0,1,3]  R159      6.6211920976638794e-01
    z[0,1,3]  R160      6.6893637180328369e-01
    z[0,1,3]  R161      1.3354264199733734e-01
    z[0,1,3]  R162      -2.5457942485809326e-01
    z[0,1,3]  R163      4.3280407786369324e-01
    z[0,1,3]  R164      4.4959440827369690e-01
    z[0,1,3]  R165      3.7001997232437134e-01
    z[0,1,3]  R166      1.1925332993268967e-01
    z[0,1,3]  R167      5.7252246141433716e-01
    z[0,1,3]  R168      6.6730004549026489e-01
    z[0,1,3]  R169      -2.0880065858364105e-01
    z[0,1,3]  R170      0.145756796002388
    z[0,1,3]  R171      5.6535619497299194e-01
    z[0,1,3]  R172      1.3385847210884094e-01
    z[0,1,3]  R173      3.8668472319841385e-02
    z[0,1,3]  R174      -8.6569473147392273e-02
    z[0,1,3]  R175      4.1128662228584290e-01
    z[0,1,3]  R176      0.780555784702301
    z[0,1,3]  R177      5.4355055093765259e-01
    z[0,1,3]  R178      1.0336114466190338e-01
    z[0,1,3]  R179      -5.1157391071319580e-01
    z[0,1,3]  R180      -6.9933813810348511e-01
    z[0,1,3]  R181      -3.5331344604492188e-01
    z[0,1,3]  R182      9.6488796174526215e-02
    z[0,1,3]  R183      7.0612180233001709e-01
    z[0,1,3]  R184      7.0649206638336182e-01
    z[0,1,3]  R185      3.6217209696769714e-01
    z[0,1,3]  R186      3.6982360482215881e-01
    z[0,1,3]  R187      4.9719414114952087e-01
    z[0,1,3]  R188      7.3084467649459839e-01
    z[0,1,3]  R189      1.0725892148911953e-02
    z[0,1,3]  R190      2.5985460728406906e-02
    z[0,1,3]  R191      8.8379764556884766e-01
    z[0,1,3]  R192      4.0583640336990356e-01
    z[0,1,3]  R193      7.6214724779129028e-01
    z[0,1,3]  R194      6.1278021335601807e-01
    z[0,1,3]  R195      5.9152060747146606e-01
    z[0,1,3]  R196      0.557911217212677
    z[0,1,3]  R197      0.557619571685791
    z[0,1,3]  R198      5.5516934394836426e-01
    z[0,1,3]  R199      -3.0751907825469971e-01
    z[0,1,3]  R200      8.1406724452972412e-01
    z[0,1,3]  R201      0.834414541721344
    z[0,1,3]  R202      7.9402446746826172e-01
    z[0,1,3]  R203      1.5916527807712555e-01
    z[0,1,3]  R204      7.1639132499694824e-01
    z[0,1,3]  R205      6.7942863702774048e-01
    z[0,1,3]  R206      5.9608709812164307e-01
    z[0,1,3]  R207      2.4663527309894562e-01
    z[0,1,3]  R208      -1.5179876983165741e-01
    z[0,1,3]  R209      -0.399173766374588
    z[0,1,3]  R210      1.4233709871768951e-01
    z[0,1,3]  R211      1.9738802686333656e-02
    z[0,1,3]  R212      3.9049752056598663e-02
    z[0,1,3]  R213      1.8538008630275726e-01
    z[0,1,3]  R214      -3.6137807369232178e-01
    z[0,1,3]  R215      4.7713780403137207e-01
    z[0,1,3]  R216      6.3309156894683838e-01
    z[0,1,3]  R217      -8.0035179853439331e-02
    z[0,1,3]  R218      -1.6489619016647339e-01
    z[0,1,3]  R219      -5.2144950628280640e-01
    z[0,1,3]  R220      -1.9632993265986443e-02
    z[0,1,3]  R221      8.7787830829620361e-01
    z[0,1,3]  R222      0.608786940574646
    z[0,1,3]  R223      6.7621201276779175e-02
    z[0,1,3]  R224      -4.9428176134824753e-02
    z[0,1,3]  R225      -0.13033527135849
    z[0,1,3]  R226      -3.5813841223716736e-01
    z[0,1,3]  R227      -4.6140113472938538e-01
    z[0,1,3]  R228      -2.6908096671104431e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       2.9816165566444397e-01
    z[0,1,4]  R80       -4.0204051136970520e-01
    z[0,1,4]  R81       -1.3788822293281555e-01
    z[0,1,4]  R82       2.4161966145038605e-01
    z[0,1,4]  R83       -0.403253436088562
    z[0,1,4]  R84       -2.0957843959331512e-01
    z[0,1,4]  R85       5.3887295722961426e-01
    z[0,1,4]  R86       3.3918201923370361e-01
    z[0,1,4]  R87       9.6655443310737610e-02
    z[0,1,4]  R88       0.0228701401501894
    z[0,1,4]  R89       -5.0021409988403320e-01
    z[0,1,4]  R90       -0.421298086643219
    z[0,1,4]  R91       -2.2560994327068329e-01
    z[0,1,4]  R92       1.8830461800098419e-01
    z[0,1,4]  R93       2.6118096709251404e-01
    z[0,1,4]  R94       -9.3708731234073639e-02
    z[0,1,4]  R95       -4.7579240798950195e-01
    z[0,1,4]  R96       -1.8810595571994781e-01
    z[0,1,4]  R97       -2.3870684206485748e-01
    z[0,1,4]  R98       -3.8813826441764832e-01
    z[0,1,4]  R99       -1.7493402957916260e-01
    z[0,1,4]  R100      0.600666344165802
    z[0,1,4]  R101      5.8888554573059082e-01
    z[0,1,4]  R102      2.6410397887229919e-01
    z[0,1,4]  R103      2.0973308384418488e-01
    z[0,1,4]  R104      4.8397764563560486e-01
    z[0,1,4]  R105      1.9514480233192444e-01
    z[0,1,4]  R106      3.6094364523887634e-01
    z[0,1,4]  R107      0.411279559135437
    z[0,1,4]  R108      1.5228706598281860e-01
    z[0,1,4]  R109      1.7387558519840240e-01
    z[0,1,4]  R110      -3.7655362486839294e-01
    z[0,1,4]  R111      -3.9956696331501007e-02
    z[0,1,4]  R112      -9.3102556467056274e-01
    z[0,1,4]  R113      5.3309971094131470e-01
    z[0,1,4]  R114      -3.3064141869544983e-01
    z[0,1,4]  R115      5.1917344331741333e-01
    z[0,1,4]  R116      4.5456290245056152e-01
    z[0,1,4]  R117      3.2867538928985596e-01
    z[0,1,4]  R118      4.8040706664323807e-02
    z[0,1,4]  R119      -3.5176917910575867e-01
    z[0,1,4]  R120      -8.6738181114196777e-01
    z[0,1,4]  R121      -5.9705656766891479e-01
    z[0,1,4]  R122      2.7617081999778748e-01
    z[0,1,4]  R123      -7.1254797279834747e-02
    z[0,1,4]  R124      -1.8082691729068756e-01
    z[0,1,4]  R125      -2.3732826113700867e-01
    z[0,1,4]  R126      0.0220558512955904
    z[0,1,4]  R127      4.0378373861312866e-01
    z[0,1,4]  R128      -1.3024382293224335e-01
    z[0,1,4]  R129      -0.657317578792572
    z[0,1,4]  R130      -2.4231974780559540e-01
    z[0,1,4]  R131      -1.3833306729793549e-01
    z[0,1,4]  R132      3.9530539512634277e-01
    z[0,1,4]  R133      4.7931128740310669e-01
    z[0,1,4]  R134      2.4191793799400330e-01
    z[0,1,4]  R135      -1.6981212794780731e-01
    z[0,1,4]  R136      1.2120685726404190e-01
    z[0,1,4]  R137      1.2582322955131531e-01
    z[0,1,4]  R138      1.8317420035600662e-02
    z[0,1,4]  R139      -4.1541165113449097e-01
    z[0,1,4]  R140      0.360927551984787
    z[0,1,4]  R141      -1.6938069462776184e-01
    z[0,1,4]  R142      1.7857013642787933e-01
    z[0,1,4]  R143      1.2255582958459854e-01
    z[0,1,4]  R144      7.8928455710411072e-02
    z[0,1,4]  R145      -1.3981994986534119e-01
    z[0,1,4]  R146      0.024102833122015
    z[0,1,4]  R147      -2.0186141133308411e-01
    z[0,1,4]  R148      -1.5936891734600067e-01
    z[0,1,4]  R149      -4.6744459867477417e-01
    z[0,1,4]  R150      -7.1737915277481079e-01
    z[0,1,4]  R151      2.9983532428741455e-01
    z[0,1,4]  R152      -1.6825450956821442e-01
    z[0,1,4]  R153      -7.1868272498250008e-03
    z[0,1,4]  R154      2.2731561958789825e-01
    z[0,1,4]  R155      -1.0865645855665207e-01
    z[0,1,4]  R156      -5.3962741047143936e-02
    z[0,1,4]  R157      -9.2491157352924347e-02
    z[0,1,4]  R158      2.4923919141292572e-01
    z[0,1,4]  R159      2.6803153753280640e-01
    z[0,1,4]  R160      1.7255203798413277e-02
    z[0,1,4]  R161      5.4292237758636475e-01
    z[0,1,4]  R162      -3.7150489515624940e-04
    z[0,1,4]  R163      -1.1027441918849945e-01
    z[0,1,4]  R164      2.9504260420799255e-01
    z[0,1,4]  R165      2.5163173675537109e-01
    z[0,1,4]  R166      0.491325318813324
    z[0,1,4]  R167      -1.8503305315971375e-01
    z[0,1,4]  R168      -3.6048030853271484e-01
    z[0,1,4]  R169      -3.8829880952835083e-01
    z[0,1,4]  R170      -1.3295862078666687e-01
    z[0,1,4]  R171      2.2157919406890869e-01
    z[0,1,4]  R172      1.8929013609886169e-01
    z[0,1,4]  R173      0.424519419670105
    z[0,1,4]  R174      4.7867378592491150e-01
    z[0,1,4]  R175      3.7761986255645752e-02
    z[0,1,4]  R176      -5.9292191267013550e-01
    z[0,1,4]  R177      4.1246834397315979e-01
    z[0,1,4]  R178      1.3459983468055725e-01
    z[0,1,4]  R179      3.4256622195243835e-01
    z[0,1,4]  R180      -1.3956628739833832e-01
    z[0,1,4]  R181      -3.4333132207393646e-03
    z[0,1,4]  R182      1.0232302546501160e-01
    z[0,1,4]  R183      1.4482711255550385e-01
    z[0,1,4]  R184      -1.5411286056041718e-01
    z[0,1,4]  R185      -4.0778371691703796e-01
    z[0,1,4]  R186      -4.0476894378662109e-01
    z[0,1,4]  R187      1.7956039309501648e-01
    z[0,1,4]  R188      3.3553296327590942e-01
    z[0,1,4]  R189      -0.539141058921814
    z[0,1,4]  R190      -3.7009525299072266e-01
    z[0,1,4]  R191      -0.0699705109000206
    z[0,1,4]  R192      -6.4956271648406982e-01
    z[0,1,4]  R193      -1.1231047660112381e-01
    z[0,1,4]  R194      3.6462938785552979e-01
    z[0,1,4]  R195      3.8490617275238037e-01
    z[0,1,4]  R196      4.4420263729989529e-03
    z[0,1,4]  R197      -0.00312254810705781
    z[0,1,4]  R198      0.638698935508728
    z[0,1,4]  R199      -4.8643991351127625e-01
    z[0,1,4]  R200      -0.00611188355833292
    z[0,1,4]  R201      2.7820187807083130e-01
    z[0,1,4]  R202      -5.2202165126800537e-01
    z[0,1,4]  R203      1.3742050528526306e-01
    z[0,1,4]  R204      1.1549419909715652e-01
    z[0,1,4]  R205      -4.0852095931768417e-02
    z[0,1,4]  R206      7.2771638631820679e-01
    z[0,1,4]  R207      1.8970780074596405e-01
    z[0,1,4]  R208      2.0771621167659760e-01
    z[0,1,4]  R209      -2.5147604942321777e-01
    z[0,1,4]  R210      -1.2091477960348129e-01
    z[0,1,4]  R211      -1.9797105342149734e-02
    z[0,1,4]  R212      -1.4402748644351959e-01
    z[0,1,4]  R213      -1.0693571716547012e-01
    z[0,1,4]  R214      3.4225240349769592e-01
    z[0,1,4]  R215      -4.7265164554119110e-02
    z[0,1,4]  R216      6.9808769226074219e-01
    z[0,1,4]  R217      2.2988188266754150e-01
    z[0,1,4]  R218      5.8784735202789307e-01
    z[0,1,4]  R219      -1.7248657345771790e-01
    z[0,1,4]  R220      -5.7757817208766937e-02
    z[0,1,4]  R221      2.5371652841567993e-01
    z[0,1,4]  R222      4.8426890862174332e-04
    z[0,1,4]  R223      1.9570238888263702e-01
    z[0,1,4]  R224      -2.5386002659797668e-01
    z[0,1,4]  R225      3.7076970934867859e-01
    z[0,1,4]  R226      3.8136407732963562e-01
    z[0,1,4]  R227      2.7218326926231384e-01
    z[0,1,4]  R228      -1.1834619939327240e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       3.4737229347229004e-01
    z[0,1,5]  R80       -1.8110331892967224e-01
    z[0,1,5]  R81       1.2058693170547485e-01
    z[0,1,5]  R82       0.224329873919487
    z[0,1,5]  R83       0.464220255613327
    z[0,1,5]  R84       -1.5976129472255707e-01
    z[0,1,5]  R85       -1.9083958864212036e-01
    z[0,1,5]  R86       -1.5940341353416443e-01
    z[0,1,5]  R87       5.6714892387390137e-02
    z[0,1,5]  R88       -2.1884283423423767e-01
    z[0,1,5]  R89       1.9040863215923309e-01
    z[0,1,5]  R90       -3.7888143211603165e-02
    z[0,1,5]  R91       -3.0807375907897949e-01
    z[0,1,5]  R92       -5.3016918897628784e-01
    z[0,1,5]  R93       -5.2946358919143677e-01
    z[0,1,5]  R94       -8.2591062784194946e-01
    z[0,1,5]  R95       -6.7597693204879761e-01
    z[0,1,5]  R96       1.4166536927223206e-01
    z[0,1,5]  R97       3.2088515162467957e-01
    z[0,1,5]  R98       1.8555650115013123e-01
    z[0,1,5]  R99       -5.0146546214818954e-02
    z[0,1,5]  R100      0.0869283527135849
    z[0,1,5]  R101      -2.4803197383880615e-01
    z[0,1,5]  R102      -2.0745231211185455e-01
    z[0,1,5]  R103      7.8759455680847168e-01
    z[0,1,5]  R104      2.7698749303817749e-01
    z[0,1,5]  R105      -4.3448275327682495e-01
    z[0,1,5]  R106      -3.5858809947967529e-01
    z[0,1,5]  R107      3.0285245180130005e-01
    z[0,1,5]  R108      3.1407546997070312e-01
    z[0,1,5]  R109      -0.518271267414093
    z[0,1,5]  R110      8.4684297442436218e-02
    z[0,1,5]  R111      -4.5331515138968825e-04
    z[0,1,5]  R112      -1.4894120395183563e-01
    z[0,1,5]  R113      1.7933075129985809e-01
    z[0,1,5]  R114      0.670393705368042
    z[0,1,5]  R115      -1.5988458693027496e-01
    z[0,1,5]  R116      3.9508423209190369e-01
    z[0,1,5]  R117      5.3369738161563873e-02
    z[0,1,5]  R118      5.4483890533447266e-01
    z[0,1,5]  R119      -5.0387692451477051e-01
    z[0,1,5]  R120      -4.1310015320777893e-01
    z[0,1,5]  R121      3.1898081302642822e-01
    z[0,1,5]  R122      3.2117792963981628e-01
    z[0,1,5]  R123      -1.3050472736358643e-01
    z[0,1,5]  R124      1.7264391481876373e-01
    z[0,1,5]  R125      2.4910381436347961e-01
    z[0,1,5]  R126      -1.1318525671958923e-01
    z[0,1,5]  R127      -2.8795739635825157e-02
    z[0,1,5]  R128      -3.4137246012687683e-01
    z[0,1,5]  R129      -2.6963651180267334e-01
    z[0,1,5]  R130      1.5881730616092682e-01
    z[0,1,5]  R131      6.1862353235483170e-02
    z[0,1,5]  R132      1.2337491661310196e-01
    z[0,1,5]  R133      2.6799678802490234e-01
    z[0,1,5]  R134      -2.2233279049396515e-01
    z[0,1,5]  R135      4.3911975622177124e-01
    z[0,1,5]  R136      7.2828143835067749e-01
    z[0,1,5]  R137      -5.4702842235565186e-01
    z[0,1,5]  R138      -2.8476619720458984e-01
    z[0,1,5]  R139      -1.3484671711921692e-01
    z[0,1,5]  R140      9.6714220941066742e-02
    z[0,1,5]  R141      3.2574611902236938e-01
    z[0,1,5]  R142      -4.5938301086425781e-01
    z[0,1,5]  R143      5.5679249763488770e-01
    z[0,1,5]  R144      -4.8105788230895996e-01
    z[0,1,5]  R145      -1.5010836720466614e-01
    z[0,1,5]  R146      -2.2828640043735504e-01
    z[0,1,5]  R147      -3.7901112437248230e-01
    z[0,1,5]  R148      1.2325149029493332e-02
    z[0,1,5]  R149      0.572059154510498
    z[0,1,5]  R150      2.0224650204181671e-01
    z[0,1,5]  R151      3.2499879598617554e-01
    z[0,1,5]  R152      5.7566791772842407e-01
    z[0,1,5]  R153      3.4185257554054260e-01
    z[0,1,5]  R154      3.9359909296035767e-01
    z[0,1,5]  R155      4.4418856501579285e-01
    z[0,1,5]  R156      9.8158992826938629e-02
    z[0,1,5]  R157      5.9080576896667480e-01
    z[0,1,5]  R158      4.4936811923980713e-01
    z[0,1,5]  R159      -4.0780159831047058e-01
    z[0,1,5]  R160      8.4364823997020721e-02
    z[0,1,5]  R161      -1.5487454831600189e-01
    z[0,1,5]  R162      -1.2571081519126892e-01
    z[0,1,5]  R163      3.1980958580970764e-01
    z[0,1,5]  R164      -3.6274725198745728e-01
    z[0,1,5]  R165      -3.0109253525733948e-01
    z[0,1,5]  R166      0.257143497467041
    z[0,1,5]  R167      1.9259685277938843e-01
    z[0,1,5]  R168      -6.8089640699326992e-03
    z[0,1,5]  R169      4.8340019583702087e-01
    z[0,1,5]  R170      2.7367675304412842e-01
    z[0,1,5]  R171      -3.3563733100891113e-01
    z[0,1,5]  R172      1.4590451121330261e-01
    z[0,1,5]  R173      -5.5856868624687195e-02
    z[0,1,5]  R174      -2.2697854042053223e-01
    z[0,1,5]  R175      5.9576934576034546e-01
    z[0,1,5]  R176      7.0278368890285492e-02
    z[0,1,5]  R177      -1.0773368924856186e-01
    z[0,1,5]  R178      1.5290841460227966e-01
    z[0,1,5]  R179      -1.1612065881490707e-01
    z[0,1,5]  R180      2.8547903895378113e-01
    z[0,1,5]  R181      -2.3959022760391235e-01
    z[0,1,5]  R182      -5.0130861997604370e-01
    z[0,1,5]  R183      1.5951279550790787e-02
    z[0,1,5]  R184      -1.2310817837715149e-01
    z[0,1,5]  R185      -5.1310826092958450e-02
    z[0,1,5]  R186      -1.8648105859756470e-01
    z[0,1,5]  R187      0.0703989565372467
    z[0,1,5]  R188      -3.9049103856086731e-01
    z[0,1,5]  R189      3.1631711125373840e-01
    z[0,1,5]  R190      -2.3108754307031631e-02
    z[0,1,5]  R191      -1.6224546730518341e-01
    z[0,1,5]  R192      3.4271883964538574e-01
    z[0,1,5]  R193      -3.0070307850837708e-01
    z[0,1,5]  R194      6.0025727748870850e-01
    z[0,1,5]  R195      1.8479205667972565e-01
    z[0,1,5]  R196      7.8040468692779541e-01
    z[0,1,5]  R197      -4.1192230582237244e-01
    z[0,1,5]  R198      -2.6334571838378906e-01
    z[0,1,5]  R199      3.3801969885826111e-01
    z[0,1,5]  R200      3.5301876068115234e-01
    z[0,1,5]  R201      -7.6438359916210175e-02
    z[0,1,5]  R202      5.9744093567132950e-02
    z[0,1,5]  R203      3.6693602800369263e-01
    z[0,1,5]  R204      2.9750075936317444e-01
    z[0,1,5]  R205      -1.7647065222263336e-01
    z[0,1,5]  R206      3.5998750478029251e-02
    z[0,1,5]  R207      1.4218123257160187e-01
    z[0,1,5]  R208      2.5382840633392334e-01
    z[0,1,5]  R209      3.3892911672592163e-01
    z[0,1,5]  R210      -4.3619722127914429e-01
    z[0,1,5]  R211      2.8107947111129761e-01
    z[0,1,5]  R212      -1.2996278703212738e-01
    z[0,1,5]  R213      3.3217015862464905e-01
    z[0,1,5]  R214      5.5026316642761230e-01
    z[0,1,5]  R215      -1.1787935346364975e-01
    z[0,1,5]  R216      1.0426397621631622e-01
    z[0,1,5]  R217      -2.3423854261636734e-02
    z[0,1,5]  R218      2.0529115572571754e-03
    z[0,1,5]  R219      4.4440496712923050e-02
    z[0,1,5]  R220      2.4768424034118652e-01
    z[0,1,5]  R221      3.6937782168388367e-01
    z[0,1,5]  R222      -6.5523582696914673e-01
    z[0,1,5]  R223      1.7465998232364655e-01
    z[0,1,5]  R224      5.2527469396591187e-01
    z[0,1,5]  R225      2.9900896549224854e-01
    z[0,1,5]  R226      -4.4401895999908447e-01
    z[0,1,5]  R227      -3.8961264491081238e-01
    z[0,1,5]  R228      -2.4709609150886536e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       2.7836680412292480e-01
    z[0,1,6]  R80       1.0631252825260162e-01
    z[0,1,6]  R81       3.0986329913139343e-01
    z[0,1,6]  R82       -6.9550549983978271e-01
    z[0,1,6]  R83       -7.1833074092864990e-01
    z[0,1,6]  R84       2.4240817129611969e-01
    z[0,1,6]  R85       -0.0881536602973938
    z[0,1,6]  R86       3.4985548257827759e-01
    z[0,1,6]  R87       -1.0338597930967808e-02
    z[0,1,6]  R88       -4.1892459988594055e-01
    z[0,1,6]  R89       5.4640448093414307e-01
    z[0,1,6]  R90       -9.9875830113887787e-02
    z[0,1,6]  R91       -2.3135414719581604e-01
    z[0,1,6]  R92       4.5691672712564468e-02
    z[0,1,6]  R93       -4.1924589872360229e-01
    z[0,1,6]  R94       2.2850631177425385e-01
    z[0,1,6]  R95       0.0985293835401535
    z[0,1,6]  R96       -2.0890440791845322e-02
    z[0,1,6]  R97       8.8022947311401367e-02
    z[0,1,6]  R98       -2.8565886616706848e-01
    z[0,1,6]  R99       -0.000894435215741396
    z[0,1,6]  R100      1.9662292301654816e-01
    z[0,1,6]  R101      -1.2804168462753296e-01
    z[0,1,6]  R102      -1.4602464437484741e-01
    z[0,1,6]  R103      -2.1753750741481781e-01
    z[0,1,6]  R104      4.6383023262023926e-01
    z[0,1,6]  R105      3.2361376285552979e-01
    z[0,1,6]  R106      0.0416349358856678
    z[0,1,6]  R107      -3.6701294779777527e-01
    z[0,1,6]  R108      4.5281535387039185e-01
    z[0,1,6]  R109      3.5848800092935562e-02
    z[0,1,6]  R110      -1.5062198042869568e-01
    z[0,1,6]  R111      3.4915685653686523e-01
    z[0,1,6]  R112      -1.8617257475852966e-01
    z[0,1,6]  R113      7.5459092855453491e-02
    z[0,1,6]  R114      -7.4120283126831055e-02
    z[0,1,6]  R115      4.5800793170928955e-01
    z[0,1,6]  R116      -2.8293453156948090e-02
    z[0,1,6]  R117      -2.4852499365806580e-01
    z[0,1,6]  R118      -5.2257311344146729e-01
    z[0,1,6]  R119      6.1016047000885010e-01
    z[0,1,6]  R120      -1.5936326235532761e-02
    z[0,1,6]  R121      -0.573460042476654
    z[0,1,6]  R122      6.9207169115543365e-02
    z[0,1,6]  R123      1.5735353529453278e-01
    z[0,1,6]  R124      -1.4017136394977570e-01
    z[0,1,6]  R125      1.7868627607822418e-01
    z[0,1,6]  R126      -2.4157559499144554e-02
    z[0,1,6]  R127      2.4473662674427032e-01
    z[0,1,6]  R128      4.2823340743780136e-02
    z[0,1,6]  R129      -1.2539999186992645e-01
    z[0,1,6]  R130      -1.5164235234260559e-01
    z[0,1,6]  R131      8.1238850951194763e-02
    z[0,1,6]  R132      2.2748689353466034e-01
    z[0,1,6]  R133      -1.6115474700927734e-01
    z[0,1,6]  R134      -1.3305296003818512e-01
    z[0,1,6]  R135      0.0618111714720726
    z[0,1,6]  R136      1.4893175661563873e-01
    z[0,1,6]  R137      -4.2725256085395813e-01
    z[0,1,6]  R138      6.3160061836242676e-01
    z[0,1,6]  R139      1.0554412007331848e-01
    z[0,1,6]  R140      -3.9614457637071609e-02
    z[0,1,6]  R141      5.1047289371490479e-01
    z[0,1,6]  R142      -0.548608660697937
    z[0,1,6]  R143      -0.235431969165802
    z[0,1,6]  R144      1.4751152694225311e-01
    z[0,1,6]  R145      8.2095600664615631e-02
    z[0,1,6]  R146      2.0003418624401093e-01
    z[0,1,6]  R147      -2.9601639509201050e-01
    z[0,1,6]  R148      1.4422810636460781e-02
    z[0,1,6]  R149      -1.0094126313924789e-01
    z[0,1,6]  R150      5.6552541255950928e-01
    z[0,1,6]  R151      1.8306763470172882e-01
    z[0,1,6]  R152      4.0054774284362793e-01
    z[0,1,6]  R153      6.7007130384445190e-01
    z[0,1,6]  R154      2.1076177060604095e-01
    z[0,1,6]  R155      1.9455462694168091e-01
    z[0,1,6]  R156      1.3794803060591221e-02
    z[0,1,6]  R157      -2.1089243888854980e-01
    z[0,1,6]  R158      -3.5103622823953629e-02
    z[0,1,6]  R159      -2.1862334012985229e-01
    z[0,1,6]  R160      -3.5250243544578552e-01
    z[0,1,6]  R161      -1.6827414929866791e-01
    z[0,1,6]  R162      -2.4363709986209869e-01
    z[0,1,6]  R163      -6.8211001157760620e-01
    z[0,1,6]  R164      2.9009729623794556e-01
    z[0,1,6]  R165      2.1386879682540894e-01
    z[0,1,6]  R166      -4.6796661615371704e-01
    z[0,1,6]  R167      -0.00897196028381586
    z[0,1,6]  R168      -2.8280505537986755e-01
    z[0,1,6]  R169      3.0765134096145630e-01
    z[0,1,6]  R170      1.4253717660903931e-01
    z[0,1,6]  R171      5.1409882307052612e-01
    z[0,1,6]  R172      -5.0827968120574951e-01
    z[0,1,6]  R173      -5.5723458528518677e-01
    z[0,1,6]  R174      6.6427379846572876e-01
    z[0,1,6]  R175      -2.6136210560798645e-01
    z[0,1,6]  R176      1.0727969557046890e-01
    z[0,1,6]  R177      -4.3989929556846619e-01
    z[0,1,6]  R178      -1.3690182566642761e-01
    z[0,1,6]  R179      -6.3550300896167755e-02
    z[0,1,6]  R180      -1.9873073324561119e-02
    z[0,1,6]  R181      5.9995472431182861e-01
    z[0,1,6]  R182      2.1704828366637230e-02
    z[0,1,6]  R183      -6.3127028942108154e-01
    z[0,1,6]  R184      -4.1776600480079651e-01
    z[0,1,6]  R185      -1.5022459626197815e-01
    z[0,1,6]  R186      2.9906576871871948e-01
    z[0,1,6]  R187      -2.5497548282146454e-02
    z[0,1,6]  R188      -5.4342824965715408e-02
    z[0,1,6]  R189      -1.7073558270931244e-01
    z[0,1,6]  R190      -1.9525590538978577e-01
    z[0,1,6]  R191      -1.7476680874824524e-01
    z[0,1,6]  R192      2.1142615377902985e-01
    z[0,1,6]  R193      3.7019538879394531e-01
    z[0,1,6]  R194      1.0266381502151489e-01
    z[0,1,6]  R195      -1.1407420039176941e-01
    z[0,1,6]  R196      -2.2610634565353394e-01
    z[0,1,6]  R197      1.9763161242008209e-01
    z[0,1,6]  R198      2.2427958250045776e-01
    z[0,1,6]  R199      4.5541429519653320e-01
    z[0,1,6]  R200      3.5498014092445374e-01
    z[0,1,6]  R201      2.5778535008430481e-01
    z[0,1,6]  R202      0.0934520810842514
    z[0,1,6]  R203      -3.2309833168983459e-01
    z[0,1,6]  R204      -4.5556899905204773e-01
    z[0,1,6]  R205      0.695705235004425
    z[0,1,6]  R206      -2.8095710277557373e-01
    z[0,1,6]  R207      -1.2208689749240875e-01
    z[0,1,6]  R208      1.3990619219839573e-02
    z[0,1,6]  R209      3.6184132099151611e-01
    z[0,1,6]  R210      3.4200161695480347e-01
    z[0,1,6]  R211      5.1040965318679810e-01
    z[0,1,6]  R212      0.277180939912796
    z[0,1,6]  R213      -6.6973221302032471e-01
    z[0,1,6]  R214      -3.9014154672622681e-01
    z[0,1,6]  R215      -1.2053254991769791e-01
    z[0,1,6]  R216      -2.9033371806144714e-01
    z[0,1,6]  R217      4.1502752900123596e-01
    z[0,1,6]  R218      -3.0794525519013405e-03
    z[0,1,6]  R219      3.9402934908866882e-01
    z[0,1,6]  R220      -1.4269025623798370e-01
    z[0,1,6]  R221      1.5831559430807829e-03
    z[0,1,6]  R222      7.2386696934700012e-02
    z[0,1,6]  R223      2.4910837411880493e-01
    z[0,1,6]  R224      -5.6955751031637192e-02
    z[0,1,6]  R225      -4.5883330702781677e-01
    z[0,1,6]  R226      -4.3563794344663620e-02
    z[0,1,6]  R227      1.9896394014358521e-01
    z[0,1,6]  R228      -3.3873987197875977e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R229      -1
    z[1,0,0]  R230      1
    z[1,0,0]  R243      1.2190082669258118e-01
    z[1,0,0]  R244      8.7008059024810791e-02
    z[1,0,0]  R245      3.0221480131149292e-01
    z[1,0,0]  R246      2.6016193628311157e-01
    z[1,0,0]  R247      2.4748301506042480e-01
    z[1,0,0]  R248      7.8136193752288818e-01
    z[1,0,0]  R249      4.5540583133697510e-01
    z[1,0,0]  R250      -0.0655539408326149
    z[1,0,0]  R251      -9.9040046334266663e-02
    z[1,0,0]  R252      1.5701797604560852e-01
    z[1,0,0]  R253      4.4143640995025635e-01
    z[1,0,0]  R254      3.5963547229766846e-01
    z[1,0,0]  R255      -2.4248990416526794e-01
    z[1,0,0]  R256      1.7267766594886780e-01
    z[1,0,0]  R257      -8.9693062007427216e-02
    z[1,0,0]  R258      2.3396338522434235e-01
    z[1,0,0]  R259      -1.8763886392116547e-01
    z[1,0,0]  R260      6.3462473452091217e-02
    z[1,0,0]  R261      5.1345992088317871e-01
    z[1,0,0]  R262      -2.9811403155326843e-01
    z[1,0,0]  R263      0.645882785320282
    z[1,0,0]  R264      6.6964232921600342e-01
    z[1,0,0]  R265      3.2339587807655334e-01
    z[1,0,0]  R266      0.0756298080086708
    z[1,0,0]  R267      1.8386992812156677e-01
    z[1,0,0]  R268      2.7939921617507935e-01
    z[1,0,0]  R269      2.6959127187728882e-01
    z[1,0,0]  R270      5.9965625405311584e-02
    z[1,0,0]  R271      3.8612468633800745e-03
    z[1,0,0]  R272      -3.8516032695770264e-01
    z[1,0,0]  R273      2.8719830513000488e-01
    z[1,0,0]  R274      -1.0021450370550156e-01
    z[1,0,0]  R275      -1.3037898577749729e-02
    z[1,0,0]  R276      2.0253281295299530e-01
    z[1,0,0]  R277      1.2343436479568481e-01
    z[1,0,0]  R278      1.8908047676086426e-01
    z[1,0,0]  R279      -3.3509114384651184e-01
    z[1,0,0]  R280      -2.0382659137248993e-01
    z[1,0,0]  R281      7.2123610973358154e-01
    z[1,0,0]  R282      2.8315272927284241e-01
    z[1,0,0]  R283      2.6582491397857666e-01
    z[1,0,0]  R284      -1.4259302616119385e-01
    z[1,0,0]  R285      1.0283294320106506e-01
    z[1,0,0]  R286      3.0567729473114014e-01
    z[1,0,0]  R287      1.2950356304645538e-01
    z[1,0,0]  R288      2.6565348729491234e-02
    z[1,0,0]  R289      -8.7781930342316628e-03
    z[1,0,0]  R290      -9.1276951134204865e-02
    z[1,0,0]  R291      5.2722871303558350e-01
    z[1,0,0]  R292      1.9307661568745971e-04
    z[1,0,0]  R293      7.6995693147182465e-02
    z[1,0,0]  R294      -1.2734183669090271e-01
    z[1,0,0]  R295      3.3917301893234253e-01
    z[1,0,0]  R296      2.6374366134405136e-02
    z[1,0,0]  R297      8.2131153345108032e-01
    z[1,0,0]  R298      4.5522559434175491e-02
    z[1,0,0]  R299      2.7312453836202621e-02
    z[1,0,0]  R300      -1.0336112976074219e-01
    z[1,0,0]  R301      -3.2615110278129578e-01
    z[1,0,0]  R302      -3.4594023227691650e-01
    z[1,0,0]  R303      2.8148117661476135e-01
    z[1,0,0]  R304      3.4922760725021362e-01
    z[1,0,0]  R305      3.0996146798133850e-01
    z[1,0,0]  R306      1.2708684802055359e-01
    z[1,0,0]  R307      1.3786189258098602e-01
    z[1,0,0]  R308      3.7735259532928467e-01
    z[1,0,0]  R309      2.9833212494850159e-01
    z[1,0,0]  R310      -1.2803736329078674e-01
    z[1,0,0]  R311      -1.1106203496456146e-01
    z[1,0,0]  R312      2.8687962330877781e-03
    z[1,0,0]  R313      2.8190642595291138e-01
    z[1,0,0]  R314      3.4562137722969055e-01
    z[1,0,0]  R315      -2.3160532116889954e-02
    z[1,0,0]  R316      -1.2331695854663849e-01
    z[1,0,0]  R317      3.4004177898168564e-02
    z[1,0,0]  R318      -4.1489630937576294e-01
    z[1,0,0]  R319      -2.6557642221450806e-01
    z[1,0,0]  R320      -1.1845907568931580e-01
    z[1,0,0]  R321      -1.9464151561260223e-01
    z[1,0,0]  R322      2.8730336576700211e-02
    z[1,0,0]  R323      6.5370810031890869e-01
    z[1,0,0]  R324      7.1117323637008667e-01
    z[1,0,0]  R325      8.4120273590087891e-01
    z[1,0,0]  R326      5.2209275960922241e-01
    z[1,0,0]  R327      6.1571907252073288e-02
    z[1,0,0]  R328      -8.9026167988777161e-03
    z[1,0,0]  R329      -3.8989506661891937e-02
    z[1,0,0]  R330      6.7693866789340973e-02
    z[1,0,0]  R331      4.4584628194570541e-02
    z[1,0,0]  R332      7.4828721582889557e-02
    z[1,0,0]  R333      -1.4557796716690063e-01
    z[1,0,0]  R334      -2.9112884402275085e-01
    z[1,0,0]  R335      1.5809562802314758e-01
    z[1,0,0]  R336      -1.6295441985130310e-01
    z[1,0,0]  R337      -1.3062354922294617e-01
    z[1,0,0]  R338      5.8467328548431396e-02
    z[1,0,0]  R339      -1.6511309146881104e-01
    z[1,0,0]  R340      0.758529543876648
    z[1,0,0]  R341      3.8202244043350220e-01
    z[1,0,0]  R342      0.561324417591095
    z[1,0,0]  R343      -0.367117315530777
    z[1,0,0]  R344      2.5374794006347656e-01
    z[1,0,0]  R345      5.7250201702117920e-01
    z[1,0,0]  R346      3.8465201854705811e-01
    z[1,0,0]  R347      1.7563463747501373e-01
    z[1,0,0]  R348      9.1865532100200653e-02
    z[1,0,0]  R349      -1.8892130255699158e-01
    z[1,0,0]  R350      -0.326642781496048
    z[1,0,0]  R351      -4.1802617907524109e-01
    z[1,0,0]  R352      7.2994068264961243e-02
    z[1,0,0]  R353      -1.6578853130340576e-01
    z[1,0,0]  R354      4.3377479910850525e-01
    z[1,0,0]  R355      3.9455017447471619e-01
    z[1,0,0]  R356      6.7611508071422577e-02
    z[1,0,0]  R357      2.4134321510791779e-01
    z[1,0,0]  R358      4.6399539709091187e-01
    z[1,0,0]  R359      5.6151503324508667e-01
    z[1,0,0]  R360      3.8915482163429260e-01
    z[1,0,0]  R361      2.5209689140319824e-01
    z[1,0,0]  R362      0.612575888633728
    z[1,0,0]  R363      2.2815930843353271e-01
    z[1,0,0]  R364      -2.3585041984915733e-02
    z[1,0,0]  R365      4.1781631112098694e-01
    z[1,0,0]  R366      0.655974805355072
    z[1,0,0]  R367      6.3054978847503662e-01
    z[1,0,0]  R368      4.2497199773788452e-01
    z[1,0,0]  R369      8.3781987428665161e-01
    z[1,0,0]  R370      -6.5555536746978760e-01
    z[1,0,0]  R371      -3.9329436421394348e-01
    z[1,0,0]  R372      6.2401664257049561e-01
    z[1,0,0]  R373      0.505494236946106
    z[1,0,0]  R374      6.6037893295288086e-01
    z[1,0,0]  R375      4.4774687290191650e-01
    z[1,0,0]  R376      4.8437824845314026e-01
    z[1,0,0]  R377      5.3428411483764648e-01
    z[1,0,0]  R378      6.4832133054733276e-01
    z[1,0,0]  R379      -7.6235592365264893e-02
    z[1,0,0]  R380      4.9269955605268478e-02
    z[1,0,0]  R381      -3.7443125247955322e-01
    z[1,0,0]  R382      -2.6094339787960052e-02
    z[1,0,0]  R383      -1.7339763045310974e-01
    z[1,0,0]  R384      5.1582396030426025e-01
    z[1,0,0]  R385      3.8748210668563843e-01
    z[1,0,0]  R386      6.2199622392654419e-01
    z[1,0,0]  R387      1.6083106398582458e-01
    z[1,0,0]  R388      -5.0983637571334839e-01
    z[1,0,0]  R389      -5.4045480489730835e-01
    z[1,0,0]  R390      -1.6421714425086975e-01
    z[1,0,0]  R391      7.4362337589263916e-02
    z[1,0,0]  R392      -3.0733120441436768e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R231      -1
    z[1,0,1]  R232      1
    z[1,0,1]  R243      -1.6991697251796722e-01
    z[1,0,1]  R244      -1.2021198123693466e-01
    z[1,0,1]  R245      5.0322914123535156e-01
    z[1,0,1]  R246      4.2183393239974976e-01
    z[1,0,1]  R247      4.2930355668067932e-01
    z[1,0,1]  R248      1.9643928110599518e-01
    z[1,0,1]  R249      7.2861391305923462e-01
    z[1,0,1]  R250      7.2586512565612793e-01
    z[1,0,1]  R251      6.2076145410537720e-01
    z[1,0,1]  R252      5.3477644920349121e-01
    z[1,0,1]  R253      -5.7719420641660690e-02
    z[1,0,1]  R254      4.3008357286453247e-01
    z[1,0,1]  R255      7.1668881177902222e-01
    z[1,0,1]  R256      -0.883419394493103
    z[1,0,1]  R257      3.3213075995445251e-01
    z[1,0,1]  R258      6.6292655467987061e-01
    z[1,0,1]  R259      7.8095215559005737e-01
    z[1,0,1]  R260      5.9684544801712036e-01
    z[1,0,1]  R261      4.7032064199447632e-01
    z[1,0,1]  R262      3.3033528923988342e-01
    z[1,0,1]  R263      -1.8666094541549683e-01
    z[1,0,1]  R264      4.6317240595817566e-01
    z[1,0,1]  R265      -1.3988637924194336e-01
    z[1,0,1]  R266      5.5366027355194092e-01
    z[1,0,1]  R267      2.9774689674377441e-01
    z[1,0,1]  R268      5.5339790880680084e-02
    z[1,0,1]  R269      -5.6207644939422607e-01
    z[1,0,1]  R270      1.1363073438405991e-01
    z[1,0,1]  R271      5.7327234745025635e-01
    z[1,0,1]  R272      8.8000553846359253e-01
    z[1,0,1]  R273      8.5935018956661224e-02
    z[1,0,1]  R274      1.2243407964706421e-01
    z[1,0,1]  R275      1.2666161358356476e-01
    z[1,0,1]  R276      -1.5021903812885284e-01
    z[1,0,1]  R277      2.1114858984947205e-01
    z[1,0,1]  R278      -4.9134314060211182e-01
    z[1,0,1]  R279      3.0135393142700195e-01
    z[1,0,1]  R280      4.8563334345817566e-01
    z[1,0,1]  R281      -0.431154727935791
    z[1,0,1]  R282      3.3930018544197083e-01
    z[1,0,1]  R283      -5.1909035444259644e-01
    z[1,0,1]  R284      -8.2570560276508331e-02
    z[1,0,1]  R285      0.361701637506485
    z[1,0,1]  R286      2.4564903974533081e-01
    z[1,0,1]  R287      2.9356616735458374e-01
    z[1,0,1]  R288      1.5386205911636353e-01
    z[1,0,1]  R289      -5.1868957281112671e-01
    z[1,0,1]  R290      8.2093916833400726e-02
    z[1,0,1]  R291      -4.4982436299324036e-01
    z[1,0,1]  R292      3.2640573382377625e-01
    z[1,0,1]  R293      4.1391676664352417e-01
    z[1,0,1]  R294      -2.6323437690734863e-01
    z[1,0,1]  R295      -1.6353602707386017e-01
    z[1,0,1]  R296      -8.1723339855670929e-02
    z[1,0,1]  R297      5.5401228368282318e-02
    z[1,0,1]  R298      -1.9173620641231537e-01
    z[1,0,1]  R299      -5.3725861012935638e-02
    z[1,0,1]  R300      6.6931024193763733e-02
    z[1,0,1]  R301      7.4424481391906738e-01
    z[1,0,1]  R302      6.7177957296371460e-01
    z[1,0,1]  R303      4.7372713685035706e-01
    z[1,0,1]  R304      -1.3733093440532684e-01
    z[1,0,1]  R305      -5.6713593006134033e-01
    z[1,0,1]  R306      5.3955519199371338e-01
    z[1,0,1]  R307      7.9679578542709351e-02
    z[1,0,1]  R308      -2.2865033149719238e-01
    z[1,0,1]  R309      4.1618752479553223e-01
    z[1,0,1]  R310      4.9980757758021355e-03
    z[1,0,1]  R311      0.787831723690033
    z[1,0,1]  R312      7.3669201135635376e-01
    z[1,0,1]  R313      -3.4342417120933533e-01
    z[1,0,1]  R314      5.0888639688491821e-01
    z[1,0,1]  R315      -1.3661010563373566e-01
    z[1,0,1]  R316      -4.2335250973701477e-01
    z[1,0,1]  R317      7.9447090625762939e-01
    z[1,0,1]  R318      6.1699497699737549e-01
    z[1,0,1]  R319      6.7754375934600830e-01
    z[1,0,1]  R320      -7.0698434114456177e-01
    z[1,0,1]  R321      -6.3214230537414551e-01
    z[1,0,1]  R322      -7.0445472002029419e-01
    z[1,0,1]  R323      -2.2679312527179718e-01
    z[1,0,1]  R324      -2.9191309213638306e-01
    z[1,0,1]  R325      2.7506455779075623e-01
    z[1,0,1]  R326      1.9605407491326332e-02
    z[1,0,1]  R327      -1.2485348433256149e-01
    z[1,0,1]  R328      1.9079299271106720e-01
    z[1,0,1]  R329      3.5919818282127380e-01
    z[1,0,1]  R330      2.1217736601829529e-01
    z[1,0,1]  R331      1.9420032203197479e-01
    z[1,0,1]  R332      2.6884013414382935e-01
    z[1,0,1]  R333      -4.5313993096351624e-01
    z[1,0,1]  R334      -3.1489136815071106e-01
    z[1,0,1]  R335      -3.5165268182754517e-01
    z[1,0,1]  R336      -2.2898840904235840e-01
    z[1,0,1]  R337      -4.1955053806304932e-02
    z[1,0,1]  R338      -1.4321479201316833e-01
    z[1,0,1]  R339      -2.4670347571372986e-01
    z[1,0,1]  R340      -0.0705266073346138
    z[1,0,1]  R341      -3.3981472253799438e-01
    z[1,0,1]  R342      -1.7385317385196686e-01
    z[1,0,1]  R343      2.9062485694885254e-01
    z[1,0,1]  R344      -7.2948127985000610e-02
    z[1,0,1]  R345      0.00988028198480606
    z[1,0,1]  R346      -3.7674322724342346e-02
    z[1,0,1]  R347      -3.2302632927894592e-02
    z[1,0,1]  R348      -2.0202779769897461e-01
    z[1,0,1]  R349      1.7496684193611145e-01
    z[1,0,1]  R350      2.7793058753013611e-01
    z[1,0,1]  R351      3.4806916117668152e-01
    z[1,0,1]  R352      2.6849013566970825e-01
    z[1,0,1]  R353      -8.3844490349292755e-02
    z[1,0,1]  R354      -9.4447515904903412e-02
    z[1,0,1]  R355      9.4490736722946167e-02
    z[1,0,1]  R356      -2.3460227251052856e-01
    z[1,0,1]  R357      -1.5209205448627472e-01
    z[1,0,1]  R358      1.8347331881523132e-01
    z[1,0,1]  R359      6.4633525907993317e-02
    z[1,0,1]  R360      4.3670570850372314e-01
    z[1,0,1]  R361      -1.0524497926235199e-01
    z[1,0,1]  R362      -5.0707951188087463e-02
    z[1,0,1]  R363      -3.4030193090438843e-01
    z[1,0,1]  R364      -2.0597891509532928e-01
    z[1,0,1]  R365      -1.4286459982395172e-01
    z[1,0,1]  R366      1.0545502603054047e-01
    z[1,0,1]  R367      1.5984825789928436e-01
    z[1,0,1]  R368      -2.7552312612533569e-01
    z[1,0,1]  R369      -2.2291575372219086e-01
    z[1,0,1]  R370      1.9611382484436035e-01
    z[1,0,1]  R371      3.6403939127922058e-01
    z[1,0,1]  R372      -2.1743577718734741e-01
    z[1,0,1]  R373      -2.6841464638710022e-01
    z[1,0,1]  R374      -0.270877480506897
    z[1,0,1]  R375      -2.9492446780204773e-01
    z[1,0,1]  R376      -1.5599857270717621e-01
    z[1,0,1]  R377      -0.0677003264427185
    z[1,0,1]  R378      -1.4299592934548855e-02
    z[1,0,1]  R379      -4.6287972480058670e-02
    z[1,0,1]  R380      -1.0172042250633240e-01
    z[1,0,1]  R381      4.3016073107719421e-01
    z[1,0,1]  R382      0.08734080940485
    z[1,0,1]  R383      -4.4155126810073853e-01
    z[1,0,1]  R384      -0.0909222811460495
    z[1,0,1]  R385      1.6748405992984772e-01
    z[1,0,1]  R386      4.7551002353429794e-02
    z[1,0,1]  R387      -3.4410160034894943e-02
    z[1,0,1]  R388      3.6228740215301514e-01
    z[1,0,1]  R389      3.5348224639892578e-01
    z[1,0,1]  R390      2.6601800322532654e-01
    z[1,0,1]  R391      2.8902328014373779e-01
    z[1,0,1]  R392      9.1782903671264648e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R233      -1
    z[1,0,2]  R234      1
    z[1,0,2]  R243      5.9869188070297241e-01
    z[1,0,2]  R244      2.9843065142631531e-01
    z[1,0,2]  R245      2.6460850238800049e-01
    z[1,0,2]  R246      3.4760057926177979e-02
    z[1,0,2]  R247      3.0230289697647095e-01
    z[1,0,2]  R248      -2.0901657640933990e-01
    z[1,0,2]  R249      1.1959838122129440e-01
    z[1,0,2]  R250      6.6681647300720215e-01
    z[1,0,2]  R251      -4.3016105890274048e-01
    z[1,0,2]  R252      -6.4490920305252075e-01
    z[1,0,2]  R253      2.7831861376762390e-01
    z[1,0,2]  R254      3.2640692591667175e-01
    z[1,0,2]  R255      -2.5030997395515442e-01
    z[1,0,2]  R256      2.2311314940452576e-01
    z[1,0,2]  R257      3.3854430913925171e-01
    z[1,0,2]  R258      2.9363412410020828e-02
    z[1,0,2]  R259      -1.3518701493740082e-01
    z[1,0,2]  R260      -3.1465950608253479e-01
    z[1,0,2]  R261      -3.4053522348403931e-01
    z[1,0,2]  R262      3.8307452201843262e-01
    z[1,0,2]  R263      1.5904194116592407e-01
    z[1,0,2]  R264      4.5045712590217590e-01
    z[1,0,2]  R265      -3.6079365015029907e-01
    z[1,0,2]  R266      5.9527742862701416e-01
    z[1,0,2]  R267      6.1822026968002319e-01
    z[1,0,2]  R268      4.3528366088867188e-01
    z[1,0,2]  R269      -1.3250146806240082e-01
    z[1,0,2]  R270      7.8870460391044617e-02
    z[1,0,2]  R271      -2.5467187166213989e-02
    z[1,0,2]  R272      -7.9486265778541565e-02
    z[1,0,2]  R273      7.1662414073944092e-01
    z[1,0,2]  R274      6.2009769678115845e-01
    z[1,0,2]  R275      6.6452652215957642e-01
    z[1,0,2]  R276      8.1538534164428711e-01
    z[1,0,2]  R277      1.4778582751750946e-01
    z[1,0,2]  R278      1.0131459683179855e-01
    z[1,0,2]  R279      0.688653290271759
    z[1,0,2]  R280      5.4570317268371582e-01
    z[1,0,2]  R281      -9.4202525913715363e-02
    z[1,0,2]  R282      -5.0470698624849319e-02
    z[1,0,2]  R283      4.8978269100189209e-01
    z[1,0,2]  R284      8.9249360561370850e-01
    z[1,0,2]  R285      1.2544372677803040e-01
    z[1,0,2]  R286      3.1213113665580750e-01
    z[1,0,2]  R287      -2.7585986256599426e-01
    z[1,0,2]  R288      -3.1035137176513672e-01
    z[1,0,2]  R289      -4.3089857697486877e-01
    z[1,0,2]  R290      -1.1614146083593369e-01
    z[1,0,2]  R291      -5.8289320440962911e-04
    z[1,0,2]  R292      -2.4012021720409393e-01
    z[1,0,2]  R293      4.1218116879463196e-01
    z[1,0,2]  R294      -3.3402808010578156e-02
    z[1,0,2]  R295      -1.1080418527126312e-01
    z[1,0,2]  R296      2.7810338139533997e-01
    z[1,0,2]  R297      1.9780190289020538e-01
    z[1,0,2]  R298      -3.7223607301712036e-01
    z[1,0,2]  R299      1.3389432430267334e-01
    z[1,0,2]  R300      -1.4040251076221466e-01
    z[1,0,2]  R301      -4.5583599805831909e-01
    z[1,0,2]  R302      -5.4609888792037964e-01
    z[1,0,2]  R303      4.7746098041534424e-01
    z[1,0,2]  R304      7.1907371282577515e-01
    z[1,0,2]  R305      4.9191007018089294e-01
    z[1,0,2]  R306      7.5943440198898315e-01
    z[1,0,2]  R307      6.0824835300445557e-01
    z[1,0,2]  R308      3.2030174136161804e-01
    z[1,0,2]  R309      6.9243609905242920e-01
    z[1,0,2]  R310      -0.016898138448596
    z[1,0,2]  R311      -3.6733978986740112e-01
    z[1,0,2]  R312      -2.9070207476615906e-01
    z[1,0,2]  R313      5.8625358343124390e-01
    z[1,0,2]  R314      0.732223391532898
    z[1,0,2]  R315      -9.6521571278572083e-02
    z[1,0,2]  R316      -1.9231060519814491e-02
    z[1,0,2]  R317      -0.481898695230484
    z[1,0,2]  R318      -3.1801348924636841e-01
    z[1,0,2]  R319      -1.2653756141662598e-01
    z[1,0,2]  R320      -1.1570768803358078e-01
    z[1,0,2]  R321      -2.9008877277374268e-01
    z[1,0,2]  R322      -4.9061864614486694e-01
    z[1,0,2]  R323      8.3470441401004791e-02
    z[1,0,2]  R324      3.8476087152957916e-02
    z[1,0,2]  R325      2.8873598575592041e-01
    z[1,0,2]  R326      1.6556492447853088e-01
    z[1,0,2]  R327      2.8725165128707886e-01
    z[1,0,2]  R328      -8.4224832057952881e-01
    z[1,0,2]  R329      -5.8925980329513550e-01
    z[1,0,2]  R330      -6.7917782068252563e-01
    z[1,0,2]  R331      -7.1529638767242432e-01
    z[1,0,2]  R332      -5.9789091348648071e-01
    z[1,0,2]  R333      2.9072910547256470e-01
    z[1,0,2]  R334      3.1898257136344910e-01
    z[1,0,2]  R335      7.5956201553344727e-01
    z[1,0,2]  R336      7.4666303396224976e-01
    z[1,0,2]  R337      0.505126416683197
    z[1,0,2]  R338      1.7032857239246368e-01
    z[1,0,2]  R339      4.6780437231063843e-01
    z[1,0,2]  R340      7.2464540600776672e-02
    z[1,0,2]  R341      6.0924118757247925e-01
    z[1,0,2]  R342      3.5284444689750671e-01
    z[1,0,2]  R343      -8.1702905893325806e-01
    z[1,0,2]  R344      5.5323904752731323e-01
    z[1,0,2]  R345      4.4137695431709290e-01
    z[1,0,2]  R346      5.7123631238937378e-01
    z[1,0,2]  R347      2.5803306698799133e-01
    z[1,0,2]  R348      6.0710644721984863e-01
    z[1,0,2]  R349      -5.4919117689132690e-01
    z[1,0,2]  R350      -0.506799042224884
    z[1,0,2]  R351      -4.6140092611312866e-01
    z[1,0,2]  R352      3.8230541348457336e-01
    z[1,0,2]  R353      1.3293799757957458e-01
    z[1,0,2]  R354      4.8885592818260193e-01
    z[1,0,2]  R355      4.8153975605964661e-01
    z[1,0,2]  R356      1.2029406428337097e-01
    z[1,0,2]  R357      6.9337779283523560e-01
    z[1,0,2]  R358      4.2525851726531982e-01
    z[1,0,2]  R359      2.5272551178932190e-01
    z[1,0,2]  R360      4.4809684157371521e-01
    z[1,0,2]  R361      7.2975230216979980e-01
    z[1,0,2]  R362      0.188186377286911
    z[1,0,2]  R363      2.5500911474227905e-01
    z[1,0,2]  R364      -8.5257776081562042e-03
    z[1,0,2]  R365      3.4689456224441528e-02
    z[1,0,2]  R366      5.5537760257720947e-01
    z[1,0,2]  R367      6.4251339435577393e-01
    z[1,0,2]  R368      6.6550296545028687e-01
    z[1,0,2]  R369      1.0407479852437973e-01
    z[1,0,2]  R370      -4.6777981519699097e-01
    z[1,0,2]  R371      -6.9043183326721191e-01
    z[1,0,2]  R372      5.1425766944885254e-01
    z[1,0,2]  R373      3.2647156715393066e-01
    z[1,0,2]  R374      5.0981956720352173e-01
    z[1,0,2]  R375      7.0545291900634766e-01
    z[1,0,2]  R376      5.3512346744537354e-01
    z[1,0,2]  R377      4.9972110986709595e-01
    z[1,0,2]  R378      0.391156941652298
    z[1,0,2]  R379      3.2480636239051819e-01
    z[1,0,2]  R380      2.7096980810165405e-01
    z[1,0,2]  R381      -4.1731411218643188e-01
    z[1,0,2]  R382      -0.178622305393219
    z[1,0,2]  R383      6.4340072870254517e-01
    z[1,0,2]  R384      -3.1454391777515411e-02
    z[1,0,2]  R385      5.2287101745605469e-01
    z[1,0,2]  R386      2.2768445312976837e-01
    z[1,0,2]  R387      4.5462402701377869e-01
    z[1,0,2]  R388      -5.8153760433197021e-01
    z[1,0,2]  R389      -6.9444268941879272e-01
    z[1,0,2]  R390      -2.5282454490661621e-01
    z[1,0,2]  R391      -2.2663612663745880e-01
    z[1,0,2]  R392      1.1399599909782410e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R235      -1
    z[1,0,3]  R236      1
    z[1,0,3]  R243      -2.0467333495616913e-01
    z[1,0,3]  R244      -1.1645700782537460e-01
    z[1,0,3]  R245      -5.9696710109710693e-01
    z[1,0,3]  R246      -4.8272362351417542e-01
    z[1,0,3]  R247      -3.1169405579566956e-01
    z[1,0,3]  R248      -2.3703196644783020e-01
    z[1,0,3]  R249      2.1501252427697182e-02
    z[1,0,3]  R250      -1.0696186125278473e-01
    z[1,0,3]  R251      1.3313871622085571e-01
    z[1,0,3]  R252      -9.0374141931533813e-02
    z[1,0,3]  R253      6.6211920976638794e-01
    z[1,0,3]  R254      6.6893637180328369e-01
    z[1,0,3]  R255      1.3354264199733734e-01
    z[1,0,3]  R256      -2.5457942485809326e-01
    z[1,0,3]  R257      4.3280407786369324e-01
    z[1,0,3]  R258      4.4959440827369690e-01
    z[1,0,3]  R259      3.7001997232437134e-01
    z[1,0,3]  R260      1.1925332993268967e-01
    z[1,0,3]  R261      5.7252246141433716e-01
    z[1,0,3]  R262      6.6730004549026489e-01
    z[1,0,3]  R263      -2.0880065858364105e-01
    z[1,0,3]  R264      0.145756796002388
    z[1,0,3]  R265      5.6535619497299194e-01
    z[1,0,3]  R266      1.3385847210884094e-01
    z[1,0,3]  R267      3.8668472319841385e-02
    z[1,0,3]  R268      -8.6569473147392273e-02
    z[1,0,3]  R269      4.1128662228584290e-01
    z[1,0,3]  R270      0.780555784702301
    z[1,0,3]  R271      5.4355055093765259e-01
    z[1,0,3]  R272      1.0336114466190338e-01
    z[1,0,3]  R273      -5.1157391071319580e-01
    z[1,0,3]  R274      -6.9933813810348511e-01
    z[1,0,3]  R275      -3.5331344604492188e-01
    z[1,0,3]  R276      9.6488796174526215e-02
    z[1,0,3]  R277      7.0612180233001709e-01
    z[1,0,3]  R278      7.0649206638336182e-01
    z[1,0,3]  R279      3.6217209696769714e-01
    z[1,0,3]  R280      3.6982360482215881e-01
    z[1,0,3]  R281      4.9719414114952087e-01
    z[1,0,3]  R282      7.3084467649459839e-01
    z[1,0,3]  R283      1.0725892148911953e-02
    z[1,0,3]  R284      2.5985460728406906e-02
    z[1,0,3]  R285      8.8379764556884766e-01
    z[1,0,3]  R286      4.0583640336990356e-01
    z[1,0,3]  R287      7.6214724779129028e-01
    z[1,0,3]  R288      6.1278021335601807e-01
    z[1,0,3]  R289      5.9152060747146606e-01
    z[1,0,3]  R290      0.557911217212677
    z[1,0,3]  R291      0.557619571685791
    z[1,0,3]  R292      5.5516934394836426e-01
    z[1,0,3]  R293      -3.0751907825469971e-01
    z[1,0,3]  R294      8.1406724452972412e-01
    z[1,0,3]  R295      0.834414541721344
    z[1,0,3]  R296      7.9402446746826172e-01
    z[1,0,3]  R297      1.5916527807712555e-01
    z[1,0,3]  R298      7.1639132499694824e-01
    z[1,0,3]  R299      6.7942863702774048e-01
    z[1,0,3]  R300      5.9608709812164307e-01
    z[1,0,3]  R301      2.4663527309894562e-01
    z[1,0,3]  R302      -1.5179876983165741e-01
    z[1,0,3]  R303      -0.399173766374588
    z[1,0,3]  R304      1.4233709871768951e-01
    z[1,0,3]  R305      1.9738802686333656e-02
    z[1,0,3]  R306      3.9049752056598663e-02
    z[1,0,3]  R307      1.8538008630275726e-01
    z[1,0,3]  R308      -3.6137807369232178e-01
    z[1,0,3]  R309      4.7713780403137207e-01
    z[1,0,3]  R310      6.3309156894683838e-01
    z[1,0,3]  R311      -8.0035179853439331e-02
    z[1,0,3]  R312      -1.6489619016647339e-01
    z[1,0,3]  R313      -5.2144950628280640e-01
    z[1,0,3]  R314      -1.9632993265986443e-02
    z[1,0,3]  R315      8.7787830829620361e-01
    z[1,0,3]  R316      0.608786940574646
    z[1,0,3]  R317      6.7621201276779175e-02
    z[1,0,3]  R318      -4.9428176134824753e-02
    z[1,0,3]  R319      -0.13033527135849
    z[1,0,3]  R320      -3.5813841223716736e-01
    z[1,0,3]  R321      -4.6140113472938538e-01
    z[1,0,3]  R322      -2.6908096671104431e-01
    z[1,0,3]  R323      -4.7666269540786743e-01
    z[1,0,3]  R324      -4.4922330975532532e-01
    z[1,0,3]  R325      6.1476852744817734e-02
    z[1,0,3]  R326      -3.2740056514739990e-01
    z[1,0,3]  R327      -6.3198663294315338e-02
    z[1,0,3]  R328      -3.5486346483230591e-01
    z[1,0,3]  R329      -4.3319106101989746e-01
    z[1,0,3]  R330      -4.7567120194435120e-01
    z[1,0,3]  R331      -6.6029065847396851e-01
    z[1,0,3]  R332      -0.583728551864624
    z[1,0,3]  R333      -3.2236695289611816e-01
    z[1,0,3]  R334      -7.2486883401870728e-01
    z[1,0,3]  R335      -2.7400314807891846e-01
    z[1,0,3]  R336      -2.1184596419334412e-01
    z[1,0,3]  R337      -4.4912162423133850e-01
    z[1,0,3]  R338      -4.5159086585044861e-01
    z[1,0,3]  R339      1.6839260933920741e-03
    z[1,0,3]  R340      0.598764181137085
    z[1,0,3]  R341      4.4689339399337769e-01
    z[1,0,3]  R342      5.1332950592041016e-01
    z[1,0,3]  R343      -2.8303396701812744e-01
    z[1,0,3]  R344      0.466047078371048
    z[1,0,3]  R345      2.2941111028194427e-01
    z[1,0,3]  R346      0.624661386013031
    z[1,0,3]  R347      4.3578910827636719e-01
    z[1,0,3]  R348      2.3679597675800323e-01
    z[1,0,3]  R349      -5.4818040132522583e-01
    z[1,0,3]  R350      -5.4645639657974243e-01
    z[1,0,3]  R351      -3.0926057696342468e-01
    z[1,0,3]  R352      6.7048561573028564e-01
    z[1,0,3]  R353      -8.0479115247726440e-01
    z[1,0,3]  R354      6.2632894515991211e-01
    z[1,0,3]  R355      6.9283038377761841e-01
    z[1,0,3]  R356      4.7617882490158081e-02
    z[1,0,3]  R357      3.4029385447502136e-01
    z[1,0,3]  R358      7.7173836529254913e-02
    z[1,0,3]  R359      3.3433189988136292e-01
    z[1,0,3]  R360      3.0583688616752625e-01
    z[1,0,3]  R361      4.6924594044685364e-01
    z[1,0,3]  R362      1.2052089720964432e-01
    z[1,0,3]  R363      -1.3106903433799744e-01
    z[1,0,3]  R364      -1.8353970348834991e-01
    z[1,0,3]  R365      -1.2935988605022430e-01
    z[1,0,3]  R366      2.5674277544021606e-01
    z[1,0,3]  R367      3.4229108691215515e-01
    z[1,0,3]  R368      4.6737492084503174e-01
    z[1,0,3]  R369      2.9534491896629333e-01
    z[1,0,3]  R370      -5.4688894748687744e-01
    z[1,0,3]  R371      -1.1105062067508698e-01
    z[1,0,3]  R372      4.0439051389694214e-01
    z[1,0,3]  R373      0.212955504655838
    z[1,0,3]  R374      3.5166999697685242e-01
    z[1,0,3]  R375      4.3048301339149475e-01
    z[1,0,3]  R376      4.8108947277069092e-01
    z[1,0,3]  R377      3.6428511142730713e-01
    z[1,0,3]  R378      5.4846316576004028e-01
    z[1,0,3]  R379      0.813058078289032
    z[1,0,3]  R380      0.588672399520874
    z[1,0,3]  R381      5.4731898009777069e-02
    z[1,0,3]  R382      6.9241464138031006e-01
    z[1,0,3]  R383      -3.9888751506805420e-01
    z[1,0,3]  R384      -7.6385718584060669e-01
    z[1,0,3]  R385      3.9119008183479309e-01
    z[1,0,3]  R386      -1.2299574166536331e-01
    z[1,0,3]  R387      0.621128261089325
    z[1,0,3]  R388      1.0593704134225845e-01
    z[1,0,3]  R389      2.2778582572937012e-01
    z[1,0,3]  R390      0.863503098487854
    z[1,0,3]  R391      7.6651722192764282e-01
    z[1,0,3]  R392      1.5615323185920715e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R237      -1
    z[1,0,4]  R238      1
    z[1,0,4]  R243      -4.6744459867477417e-01
    z[1,0,4]  R244      -7.1737915277481079e-01
    z[1,0,4]  R245      2.9983532428741455e-01
    z[1,0,4]  R246      -1.6825450956821442e-01
    z[1,0,4]  R247      -7.1868272498250008e-03
    z[1,0,4]  R248      2.2731561958789825e-01
    z[1,0,4]  R249      -1.0865645855665207e-01
    z[1,0,4]  R250      -5.3962741047143936e-02
    z[1,0,4]  R251      -9.2491157352924347e-02
    z[1,0,4]  R252      2.4923919141292572e-01
    z[1,0,4]  R253      2.6803153753280640e-01
    z[1,0,4]  R254      1.7255203798413277e-02
    z[1,0,4]  R255      5.4292237758636475e-01
    z[1,0,4]  R256      -3.7150489515624940e-04
    z[1,0,4]  R257      -1.1027441918849945e-01
    z[1,0,4]  R258      2.9504260420799255e-01
    z[1,0,4]  R259      2.5163173675537109e-01
    z[1,0,4]  R260      0.491325318813324
    z[1,0,4]  R261      -1.8503305315971375e-01
    z[1,0,4]  R262      -3.6048030853271484e-01
    z[1,0,4]  R263      -3.8829880952835083e-01
    z[1,0,4]  R264      -1.3295862078666687e-01
    z[1,0,4]  R265      2.2157919406890869e-01
    z[1,0,4]  R266      1.8929013609886169e-01
    z[1,0,4]  R267      0.424519419670105
    z[1,0,4]  R268      4.7867378592491150e-01
    z[1,0,4]  R269      3.7761986255645752e-02
    z[1,0,4]  R270      -5.9292191267013550e-01
    z[1,0,4]  R271      4.1246834397315979e-01
    z[1,0,4]  R272      1.3459983468055725e-01
    z[1,0,4]  R273      3.4256622195243835e-01
    z[1,0,4]  R274      -1.3956628739833832e-01
    z[1,0,4]  R275      -3.4333132207393646e-03
    z[1,0,4]  R276      1.0232302546501160e-01
    z[1,0,4]  R277      1.4482711255550385e-01
    z[1,0,4]  R278      -1.5411286056041718e-01
    z[1,0,4]  R279      -4.0778371691703796e-01
    z[1,0,4]  R280      -4.0476894378662109e-01
    z[1,0,4]  R281      1.7956039309501648e-01
    z[1,0,4]  R282      3.3553296327590942e-01
    z[1,0,4]  R283      -0.539141058921814
    z[1,0,4]  R284      -3.7009525299072266e-01
    z[1,0,4]  R285      -0.0699705109000206
    z[1,0,4]  R286      -6.4956271648406982e-01
    z[1,0,4]  R287      -1.1231047660112381e-01
    z[1,0,4]  R288      3.6462938785552979e-01
    z[1,0,4]  R289      3.8490617275238037e-01
    z[1,0,4]  R290      4.4420263729989529e-03
    z[1,0,4]  R291      -0.00312254810705781
    z[1,0,4]  R292      0.638698935508728
    z[1,0,4]  R293      -4.8643991351127625e-01
    z[1,0,4]  R294      -0.00611188355833292
    z[1,0,4]  R295      2.7820187807083130e-01
    z[1,0,4]  R296      -5.2202165126800537e-01
    z[1,0,4]  R297      1.3742050528526306e-01
    z[1,0,4]  R298      1.1549419909715652e-01
    z[1,0,4]  R299      -4.0852095931768417e-02
    z[1,0,4]  R300      7.2771638631820679e-01
    z[1,0,4]  R301      1.8970780074596405e-01
    z[1,0,4]  R302      2.0771621167659760e-01
    z[1,0,4]  R303      -2.5147604942321777e-01
    z[1,0,4]  R304      -1.2091477960348129e-01
    z[1,0,4]  R305      -1.9797105342149734e-02
    z[1,0,4]  R306      -1.4402748644351959e-01
    z[1,0,4]  R307      -1.0693571716547012e-01
    z[1,0,4]  R308      3.4225240349769592e-01
    z[1,0,4]  R309      -4.7265164554119110e-02
    z[1,0,4]  R310      6.9808769226074219e-01
    z[1,0,4]  R311      2.2988188266754150e-01
    z[1,0,4]  R312      5.8784735202789307e-01
    z[1,0,4]  R313      -1.7248657345771790e-01
    z[1,0,4]  R314      -5.7757817208766937e-02
    z[1,0,4]  R315      2.5371652841567993e-01
    z[1,0,4]  R316      4.8426890862174332e-04
    z[1,0,4]  R317      1.9570238888263702e-01
    z[1,0,4]  R318      -2.5386002659797668e-01
    z[1,0,4]  R319      3.7076970934867859e-01
    z[1,0,4]  R320      3.8136407732963562e-01
    z[1,0,4]  R321      2.7218326926231384e-01
    z[1,0,4]  R322      -1.1834619939327240e-01
    z[1,0,4]  R323      2.9816165566444397e-01
    z[1,0,4]  R324      -4.0204051136970520e-01
    z[1,0,4]  R325      -1.3788822293281555e-01
    z[1,0,4]  R326      2.4161966145038605e-01
    z[1,0,4]  R327      -0.403253436088562
    z[1,0,4]  R328      -2.0957843959331512e-01
    z[1,0,4]  R329      5.3887295722961426e-01
    z[1,0,4]  R330      3.3918201923370361e-01
    z[1,0,4]  R331      9.6655443310737610e-02
    z[1,0,4]  R332      0.0228701401501894
    z[1,0,4]  R333      -5.0021409988403320e-01
    z[1,0,4]  R334      -0.421298086643219
    z[1,0,4]  R335      -2.2560994327068329e-01
    z[1,0,4]  R336      1.8830461800098419e-01
    z[1,0,4]  R337      2.6118096709251404e-01
    z[1,0,4]  R338      -9.3708731234073639e-02
    z[1,0,4]  R339      -4.7579240798950195e-01
    z[1,0,4]  R340      -1.8810595571994781e-01
    z[1,0,4]  R341      -2.3870684206485748e-01
    z[1,0,4]  R342      -3.8813826441764832e-01
    z[1,0,4]  R343      -1.7493402957916260e-01
    z[1,0,4]  R344      0.600666344165802
    z[1,0,4]  R345      5.8888554573059082e-01
    z[1,0,4]  R346      2.6410397887229919e-01
    z[1,0,4]  R347      2.0973308384418488e-01
    z[1,0,4]  R348      4.8397764563560486e-01
    z[1,0,4]  R349      1.9514480233192444e-01
    z[1,0,4]  R350      3.6094364523887634e-01
    z[1,0,4]  R351      0.411279559135437
    z[1,0,4]  R352      1.5228706598281860e-01
    z[1,0,4]  R353      1.7387558519840240e-01
    z[1,0,4]  R354      -3.7655362486839294e-01
    z[1,0,4]  R355      -3.9956696331501007e-02
    z[1,0,4]  R356      -9.3102556467056274e-01
    z[1,0,4]  R357      5.3309971094131470e-01
    z[1,0,4]  R358      -3.3064141869544983e-01
    z[1,0,4]  R359      5.1917344331741333e-01
    z[1,0,4]  R360      4.5456290245056152e-01
    z[1,0,4]  R361      3.2867538928985596e-01
    z[1,0,4]  R362      4.8040706664323807e-02
    z[1,0,4]  R363      -3.5176917910575867e-01
    z[1,0,4]  R364      -8.6738181114196777e-01
    z[1,0,4]  R365      -5.9705656766891479e-01
    z[1,0,4]  R366      2.7617081999778748e-01
    z[1,0,4]  R367      -7.1254797279834747e-02
    z[1,0,4]  R368      -1.8082691729068756e-01
    z[1,0,4]  R369      -2.3732826113700867e-01
    z[1,0,4]  R370      0.0220558512955904
    z[1,0,4]  R371      4.0378373861312866e-01
    z[1,0,4]  R372      -1.3024382293224335e-01
    z[1,0,4]  R373      -0.657317578792572
    z[1,0,4]  R374      -2.4231974780559540e-01
    z[1,0,4]  R375      -1.3833306729793549e-01
    z[1,0,4]  R376      3.9530539512634277e-01
    z[1,0,4]  R377      4.7931128740310669e-01
    z[1,0,4]  R378      2.4191793799400330e-01
    z[1,0,4]  R379      -1.6981212794780731e-01
    z[1,0,4]  R380      1.2120685726404190e-01
    z[1,0,4]  R381      1.2582322955131531e-01
    z[1,0,4]  R382      1.8317420035600662e-02
    z[1,0,4]  R383      -4.1541165113449097e-01
    z[1,0,4]  R384      0.360927551984787
    z[1,0,4]  R385      -1.6938069462776184e-01
    z[1,0,4]  R386      1.7857013642787933e-01
    z[1,0,4]  R387      1.2255582958459854e-01
    z[1,0,4]  R388      7.8928455710411072e-02
    z[1,0,4]  R389      -1.3981994986534119e-01
    z[1,0,4]  R390      0.024102833122015
    z[1,0,4]  R391      -2.0186141133308411e-01
    z[1,0,4]  R392      -1.5936891734600067e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R239      -1
    z[1,0,5]  R240      1
    z[1,0,5]  R243      0.572059154510498
    z[1,0,5]  R244      2.0224650204181671e-01
    z[1,0,5]  R245      3.2499879598617554e-01
    z[1,0,5]  R246      5.7566791772842407e-01
    z[1,0,5]  R247      3.4185257554054260e-01
    z[1,0,5]  R248      3.9359909296035767e-01
    z[1,0,5]  R249      4.4418856501579285e-01
    z[1,0,5]  R250      9.8158992826938629e-02
    z[1,0,5]  R251      5.9080576896667480e-01
    z[1,0,5]  R252      4.4936811923980713e-01
    z[1,0,5]  R253      -4.0780159831047058e-01
    z[1,0,5]  R254      8.4364823997020721e-02
    z[1,0,5]  R255      -1.5487454831600189e-01
    z[1,0,5]  R256      -1.2571081519126892e-01
    z[1,0,5]  R257      3.1980958580970764e-01
    z[1,0,5]  R258      -3.6274725198745728e-01
    z[1,0,5]  R259      -3.0109253525733948e-01
    z[1,0,5]  R260      0.257143497467041
    z[1,0,5]  R261      1.9259685277938843e-01
    z[1,0,5]  R262      -6.8089640699326992e-03
    z[1,0,5]  R263      4.8340019583702087e-01
    z[1,0,5]  R264      2.7367675304412842e-01
    z[1,0,5]  R265      -3.3563733100891113e-01
    z[1,0,5]  R266      1.4590451121330261e-01
    z[1,0,5]  R267      -5.5856868624687195e-02
    z[1,0,5]  R268      -2.2697854042053223e-01
    z[1,0,5]  R269      5.9576934576034546e-01
    z[1,0,5]  R270      7.0278368890285492e-02
    z[1,0,5]  R271      -1.0773368924856186e-01
    z[1,0,5]  R272      1.5290841460227966e-01
    z[1,0,5]  R273      -1.1612065881490707e-01
    z[1,0,5]  R274      2.8547903895378113e-01
    z[1,0,5]  R275      -2.3959022760391235e-01
    z[1,0,5]  R276      -5.0130861997604370e-01
    z[1,0,5]  R277      1.5951279550790787e-02
    z[1,0,5]  R278      -1.2310817837715149e-01
    z[1,0,5]  R279      -5.1310826092958450e-02
    z[1,0,5]  R280      -1.8648105859756470e-01
    z[1,0,5]  R281      0.0703989565372467
    z[1,0,5]  R282      -3.9049103856086731e-01
    z[1,0,5]  R283      3.1631711125373840e-01
    z[1,0,5]  R284      -2.3108754307031631e-02
    z[1,0,5]  R285      -1.6224546730518341e-01
    z[1,0,5]  R286      3.4271883964538574e-01
    z[1,0,5]  R287      -3.0070307850837708e-01
    z[1,0,5]  R288      6.0025727748870850e-01
    z[1,0,5]  R289      1.8479205667972565e-01
    z[1,0,5]  R290      7.8040468692779541e-01
    z[1,0,5]  R291      -4.1192230582237244e-01
    z[1,0,5]  R292      -2.6334571838378906e-01
    z[1,0,5]  R293      3.3801969885826111e-01
    z[1,0,5]  R294      3.5301876068115234e-01
    z[1,0,5]  R295      -7.6438359916210175e-02
    z[1,0,5]  R296      5.9744093567132950e-02
    z[1,0,5]  R297      3.6693602800369263e-01
    z[1,0,5]  R298      2.9750075936317444e-01
    z[1,0,5]  R299      -1.7647065222263336e-01
    z[1,0,5]  R300      3.5998750478029251e-02
    z[1,0,5]  R301      1.4218123257160187e-01
    z[1,0,5]  R302      2.5382840633392334e-01
    z[1,0,5]  R303      3.3892911672592163e-01
    z[1,0,5]  R304      -4.3619722127914429e-01
    z[1,0,5]  R305      2.8107947111129761e-01
    z[1,0,5]  R306      -1.2996278703212738e-01
    z[1,0,5]  R307      3.3217015862464905e-01
    z[1,0,5]  R308      5.5026316642761230e-01
    z[1,0,5]  R309      -1.1787935346364975e-01
    z[1,0,5]  R310      1.0426397621631622e-01
    z[1,0,5]  R311      -2.3423854261636734e-02
    z[1,0,5]  R312      2.0529115572571754e-03
    z[1,0,5]  R313      4.4440496712923050e-02
    z[1,0,5]  R314      2.4768424034118652e-01
    z[1,0,5]  R315      3.6937782168388367e-01
    z[1,0,5]  R316      -6.5523582696914673e-01
    z[1,0,5]  R317      1.7465998232364655e-01
    z[1,0,5]  R318      5.2527469396591187e-01
    z[1,0,5]  R319      2.9900896549224854e-01
    z[1,0,5]  R320      -4.4401895999908447e-01
    z[1,0,5]  R321      -3.8961264491081238e-01
    z[1,0,5]  R322      -2.4709609150886536e-01
    z[1,0,5]  R323      3.4737229347229004e-01
    z[1,0,5]  R324      -1.8110331892967224e-01
    z[1,0,5]  R325      1.2058693170547485e-01
    z[1,0,5]  R326      0.224329873919487
    z[1,0,5]  R327      0.464220255613327
    z[1,0,5]  R328      -1.5976129472255707e-01
    z[1,0,5]  R329      -1.9083958864212036e-01
    z[1,0,5]  R330      -1.5940341353416443e-01
    z[1,0,5]  R331      5.6714892387390137e-02
    z[1,0,5]  R332      -2.1884283423423767e-01
    z[1,0,5]  R333      1.9040863215923309e-01
    z[1,0,5]  R334      -3.7888143211603165e-02
    z[1,0,5]  R335      -3.0807375907897949e-01
    z[1,0,5]  R336      -5.3016918897628784e-01
    z[1,0,5]  R337      -5.2946358919143677e-01
    z[1,0,5]  R338      -8.2591062784194946e-01
    z[1,0,5]  R339      -6.7597693204879761e-01
    z[1,0,5]  R340      1.4166536927223206e-01
    z[1,0,5]  R341      3.2088515162467957e-01
    z[1,0,5]  R342      1.8555650115013123e-01
    z[1,0,5]  R343      -5.0146546214818954e-02
    z[1,0,5]  R344      0.0869283527135849
    z[1,0,5]  R345      -2.4803197383880615e-01
    z[1,0,5]  R346      -2.0745231211185455e-01
    z[1,0,5]  R347      7.8759455680847168e-01
    z[1,0,5]  R348      2.7698749303817749e-01
    z[1,0,5]  R349      -4.3448275327682495e-01
    z[1,0,5]  R350      -3.5858809947967529e-01
    z[1,0,5]  R351      3.0285245180130005e-01
    z[1,0,5]  R352      3.1407546997070312e-01
    z[1,0,5]  R353      -0.518271267414093
    z[1,0,5]  R354      8.4684297442436218e-02
    z[1,0,5]  R355      -4.5331515138968825e-04
    z[1,0,5]  R356      -1.4894120395183563e-01
    z[1,0,5]  R357      1.7933075129985809e-01
    z[1,0,5]  R358      0.670393705368042
    z[1,0,5]  R359      -1.5988458693027496e-01
    z[1,0,5]  R360      3.9508423209190369e-01
    z[1,0,5]  R361      5.3369738161563873e-02
    z[1,0,5]  R362      5.4483890533447266e-01
    z[1,0,5]  R363      -5.0387692451477051e-01
    z[1,0,5]  R364      -4.1310015320777893e-01
    z[1,0,5]  R365      3.1898081302642822e-01
    z[1,0,5]  R366      3.2117792963981628e-01
    z[1,0,5]  R367      -1.3050472736358643e-01
    z[1,0,5]  R368      1.7264391481876373e-01
    z[1,0,5]  R369      2.4910381436347961e-01
    z[1,0,5]  R370      -1.1318525671958923e-01
    z[1,0,5]  R371      -2.8795739635825157e-02
    z[1,0,5]  R372      -3.4137246012687683e-01
    z[1,0,5]  R373      -2.6963651180267334e-01
    z[1,0,5]  R374      1.5881730616092682e-01
    z[1,0,5]  R375      6.1862353235483170e-02
    z[1,0,5]  R376      1.2337491661310196e-01
    z[1,0,5]  R377      2.6799678802490234e-01
    z[1,0,5]  R378      -2.2233279049396515e-01
    z[1,0,5]  R379      4.3911975622177124e-01
    z[1,0,5]  R380      7.2828143835067749e-01
    z[1,0,5]  R381      -5.4702842235565186e-01
    z[1,0,5]  R382      -2.8476619720458984e-01
    z[1,0,5]  R383      -1.3484671711921692e-01
    z[1,0,5]  R384      9.6714220941066742e-02
    z[1,0,5]  R385      3.2574611902236938e-01
    z[1,0,5]  R386      -4.5938301086425781e-01
    z[1,0,5]  R387      5.5679249763488770e-01
    z[1,0,5]  R388      -4.8105788230895996e-01
    z[1,0,5]  R389      -1.5010836720466614e-01
    z[1,0,5]  R390      -2.2828640043735504e-01
    z[1,0,5]  R391      -3.7901112437248230e-01
    z[1,0,5]  R392      1.2325149029493332e-02
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R241      -1
    z[1,0,6]  R242      1
    z[1,0,6]  R243      -1.0094126313924789e-01
    z[1,0,6]  R244      5.6552541255950928e-01
    z[1,0,6]  R245      1.8306763470172882e-01
    z[1,0,6]  R246      4.0054774284362793e-01
    z[1,0,6]  R247      6.7007130384445190e-01
    z[1,0,6]  R248      2.1076177060604095e-01
    z[1,0,6]  R249      1.9455462694168091e-01
    z[1,0,6]  R250      1.3794803060591221e-02
    z[1,0,6]  R251      -2.1089243888854980e-01
    z[1,0,6]  R252      -3.5103622823953629e-02
    z[1,0,6]  R253      -2.1862334012985229e-01
    z[1,0,6]  R254      -3.5250243544578552e-01
    z[1,0,6]  R255      -1.6827414929866791e-01
    z[1,0,6]  R256      -2.4363709986209869e-01
    z[1,0,6]  R257      -6.8211001157760620e-01
    z[1,0,6]  R258      2.9009729623794556e-01
    z[1,0,6]  R259      2.1386879682540894e-01
    z[1,0,6]  R260      -4.6796661615371704e-01
    z[1,0,6]  R261      -0.00897196028381586
    z[1,0,6]  R262      -2.8280505537986755e-01
    z[1,0,6]  R263      3.0765134096145630e-01
    z[1,0,6]  R264      1.4253717660903931e-01
    z[1,0,6]  R265      5.1409882307052612e-01
    z[1,0,6]  R266      -5.0827968120574951e-01
    z[1,0,6]  R267      -5.5723458528518677e-01
    z[1,0,6]  R268      6.6427379846572876e-01
    z[1,0,6]  R269      -2.6136210560798645e-01
    z[1,0,6]  R270      1.0727969557046890e-01
    z[1,0,6]  R271      -4.3989929556846619e-01
    z[1,0,6]  R272      -1.3690182566642761e-01
    z[1,0,6]  R273      -6.3550300896167755e-02
    z[1,0,6]  R274      -1.9873073324561119e-02
    z[1,0,6]  R275      5.9995472431182861e-01
    z[1,0,6]  R276      2.1704828366637230e-02
    z[1,0,6]  R277      -6.3127028942108154e-01
    z[1,0,6]  R278      -4.1776600480079651e-01
    z[1,0,6]  R279      -1.5022459626197815e-01
    z[1,0,6]  R280      2.9906576871871948e-01
    z[1,0,6]  R281      -2.5497548282146454e-02
    z[1,0,6]  R282      -5.4342824965715408e-02
    z[1,0,6]  R283      -1.7073558270931244e-01
    z[1,0,6]  R284      -1.9525590538978577e-01
    z[1,0,6]  R285      -1.7476680874824524e-01
    z[1,0,6]  R286      2.1142615377902985e-01
    z[1,0,6]  R287      3.7019538879394531e-01
    z[1,0,6]  R288      1.0266381502151489e-01
    z[1,0,6]  R289      -1.1407420039176941e-01
    z[1,0,6]  R290      -2.2610634565353394e-01
    z[1,0,6]  R291      1.9763161242008209e-01
    z[1,0,6]  R292      2.2427958250045776e-01
    z[1,0,6]  R293      4.5541429519653320e-01
    z[1,0,6]  R294      3.5498014092445374e-01
    z[1,0,6]  R295      2.5778535008430481e-01
    z[1,0,6]  R296      0.0934520810842514
    z[1,0,6]  R297      -3.2309833168983459e-01
    z[1,0,6]  R298      -4.5556899905204773e-01
    z[1,0,6]  R299      0.695705235004425
    z[1,0,6]  R300      -2.8095710277557373e-01
    z[1,0,6]  R301      -1.2208689749240875e-01
    z[1,0,6]  R302      1.3990619219839573e-02
    z[1,0,6]  R303      3.6184132099151611e-01
    z[1,0,6]  R304      3.4200161695480347e-01
    z[1,0,6]  R305      5.1040965318679810e-01
    z[1,0,6]  R306      0.277180939912796
    z[1,0,6]  R307      -6.6973221302032471e-01
    z[1,0,6]  R308      -3.9014154672622681e-01
    z[1,0,6]  R309      -1.2053254991769791e-01
    z[1,0,6]  R310      -2.9033371806144714e-01
    z[1,0,6]  R311      4.1502752900123596e-01
    z[1,0,6]  R312      -3.0794525519013405e-03
    z[1,0,6]  R313      3.9402934908866882e-01
    z[1,0,6]  R314      -1.4269025623798370e-01
    z[1,0,6]  R315      1.5831559430807829e-03
    z[1,0,6]  R316      7.2386696934700012e-02
    z[1,0,6]  R317      2.4910837411880493e-01
    z[1,0,6]  R318      -5.6955751031637192e-02
    z[1,0,6]  R319      -4.5883330702781677e-01
    z[1,0,6]  R320      -4.3563794344663620e-02
    z[1,0,6]  R321      1.9896394014358521e-01
    z[1,0,6]  R322      -3.3873987197875977e-01
    z[1,0,6]  R323      2.7836680412292480e-01
    z[1,0,6]  R324      1.0631252825260162e-01
    z[1,0,6]  R325      3.0986329913139343e-01
    z[1,0,6]  R326      -6.9550549983978271e-01
    z[1,0,6]  R327      -7.1833074092864990e-01
    z[1,0,6]  R328      2.4240817129611969e-01
    z[1,0,6]  R329      -0.0881536602973938
    z[1,0,6]  R330      3.4985548257827759e-01
    z[1,0,6]  R331      -1.0338597930967808e-02
    z[1,0,6]  R332      -4.1892459988594055e-01
    z[1,0,6]  R333      5.4640448093414307e-01
    z[1,0,6]  R334      -9.9875830113887787e-02
    z[1,0,6]  R335      -2.3135414719581604e-01
    z[1,0,6]  R336      4.5691672712564468e-02
    z[1,0,6]  R337      -4.1924589872360229e-01
    z[1,0,6]  R338      2.2850631177425385e-01
    z[1,0,6]  R339      0.0985293835401535
    z[1,0,6]  R340      -2.0890440791845322e-02
    z[1,0,6]  R341      8.8022947311401367e-02
    z[1,0,6]  R342      -2.8565886616706848e-01
    z[1,0,6]  R343      -0.000894435215741396
    z[1,0,6]  R344      1.9662292301654816e-01
    z[1,0,6]  R345      -1.2804168462753296e-01
    z[1,0,6]  R346      -1.4602464437484741e-01
    z[1,0,6]  R347      -2.1753750741481781e-01
    z[1,0,6]  R348      4.6383023262023926e-01
    z[1,0,6]  R349      3.2361376285552979e-01
    z[1,0,6]  R350      0.0416349358856678
    z[1,0,6]  R351      -3.6701294779777527e-01
    z[1,0,6]  R352      4.5281535387039185e-01
    z[1,0,6]  R353      3.5848800092935562e-02
    z[1,0,6]  R354      -1.5062198042869568e-01
    z[1,0,6]  R355      3.4915685653686523e-01
    z[1,0,6]  R356      -1.8617257475852966e-01
    z[1,0,6]  R357      7.5459092855453491e-02
    z[1,0,6]  R358      -7.4120283126831055e-02
    z[1,0,6]  R359      4.5800793170928955e-01
    z[1,0,6]  R360      -2.8293453156948090e-02
    z[1,0,6]  R361      -2.4852499365806580e-01
    z[1,0,6]  R362      -5.2257311344146729e-01
    z[1,0,6]  R363      6.1016047000885010e-01
    z[1,0,6]  R364      -1.5936326235532761e-02
    z[1,0,6]  R365      -0.573460042476654
    z[1,0,6]  R366      6.9207169115543365e-02
    z[1,0,6]  R367      1.5735353529453278e-01
    z[1,0,6]  R368      -1.4017136394977570e-01
    z[1,0,6]  R369      1.7868627607822418e-01
    z[1,0,6]  R370      -2.4157559499144554e-02
    z[1,0,6]  R371      2.4473662674427032e-01
    z[1,0,6]  R372      4.2823340743780136e-02
    z[1,0,6]  R373      -1.2539999186992645e-01
    z[1,0,6]  R374      -1.5164235234260559e-01
    z[1,0,6]  R375      8.1238850951194763e-02
    z[1,0,6]  R376      2.2748689353466034e-01
    z[1,0,6]  R377      -1.6115474700927734e-01
    z[1,0,6]  R378      -1.3305296003818512e-01
    z[1,0,6]  R379      0.0618111714720726
    z[1,0,6]  R380      1.4893175661563873e-01
    z[1,0,6]  R381      -4.2725256085395813e-01
    z[1,0,6]  R382      6.3160061836242676e-01
    z[1,0,6]  R383      1.0554412007331848e-01
    z[1,0,6]  R384      -3.9614457637071609e-02
    z[1,0,6]  R385      5.1047289371490479e-01
    z[1,0,6]  R386      -0.548608660697937
    z[1,0,6]  R387      -0.235431969165802
    z[1,0,6]  R388      1.4751152694225311e-01
    z[1,0,6]  R389      8.2095600664615631e-02
    z[1,0,6]  R390      2.0003418624401093e-01
    z[1,0,6]  R391      -2.9601639509201050e-01
    z[1,0,6]  R392      1.4422810636460781e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R393      -1
    z[0,4,0]  R394      1
    z[0,4,0]  R407      6.5370810031890869e-01
    z[0,4,0]  R408      7.1117323637008667e-01
    z[0,4,0]  R409      8.4120273590087891e-01
    z[0,4,0]  R410      5.2209275960922241e-01
    z[0,4,0]  R411      6.1571907252073288e-02
    z[0,4,0]  R412      -8.9026167988777161e-03
    z[0,4,0]  R413      -3.8989506661891937e-02
    z[0,4,0]  R414      6.7693866789340973e-02
    z[0,4,0]  R415      4.4584628194570541e-02
    z[0,4,0]  R416      7.4828721582889557e-02
    z[0,4,0]  R417      -1.4557796716690063e-01
    z[0,4,0]  R418      -2.9112884402275085e-01
    z[0,4,0]  R419      1.5809562802314758e-01
    z[0,4,0]  R420      -1.6295441985130310e-01
    z[0,4,0]  R421      -1.3062354922294617e-01
    z[0,4,0]  R422      5.8467328548431396e-02
    z[0,4,0]  R423      -1.6511309146881104e-01
    z[0,4,0]  R424      0.758529543876648
    z[0,4,0]  R425      3.8202244043350220e-01
    z[0,4,0]  R426      0.561324417591095
    z[0,4,0]  R427      -0.367117315530777
    z[0,4,0]  R428      2.5374794006347656e-01
    z[0,4,0]  R429      5.7250201702117920e-01
    z[0,4,0]  R430      3.8465201854705811e-01
    z[0,4,0]  R431      1.7563463747501373e-01
    z[0,4,0]  R432      9.1865532100200653e-02
    z[0,4,0]  R433      -1.8892130255699158e-01
    z[0,4,0]  R434      -0.326642781496048
    z[0,4,0]  R435      -4.1802617907524109e-01
    z[0,4,0]  R436      7.2994068264961243e-02
    z[0,4,0]  R437      -1.6578853130340576e-01
    z[0,4,0]  R438      4.3377479910850525e-01
    z[0,4,0]  R439      3.9455017447471619e-01
    z[0,4,0]  R440      6.7611508071422577e-02
    z[0,4,0]  R441      2.4134321510791779e-01
    z[0,4,0]  R442      4.6399539709091187e-01
    z[0,4,0]  R443      5.6151503324508667e-01
    z[0,4,0]  R444      3.8915482163429260e-01
    z[0,4,0]  R445      2.5209689140319824e-01
    z[0,4,0]  R446      0.612575888633728
    z[0,4,0]  R447      2.2815930843353271e-01
    z[0,4,0]  R448      -2.3585041984915733e-02
    z[0,4,0]  R449      4.1781631112098694e-01
    z[0,4,0]  R450      0.655974805355072
    z[0,4,0]  R451      6.3054978847503662e-01
    z[0,4,0]  R452      4.2497199773788452e-01
    z[0,4,0]  R453      8.3781987428665161e-01
    z[0,4,0]  R454      -6.5555536746978760e-01
    z[0,4,0]  R455      -3.9329436421394348e-01
    z[0,4,0]  R456      6.2401664257049561e-01
    z[0,4,0]  R457      0.505494236946106
    z[0,4,0]  R458      6.6037893295288086e-01
    z[0,4,0]  R459      4.4774687290191650e-01
    z[0,4,0]  R460      4.8437824845314026e-01
    z[0,4,0]  R461      5.3428411483764648e-01
    z[0,4,0]  R462      6.4832133054733276e-01
    z[0,4,0]  R463      -7.6235592365264893e-02
    z[0,4,0]  R464      4.9269955605268478e-02
    z[0,4,0]  R465      -3.7443125247955322e-01
    z[0,4,0]  R466      -2.6094339787960052e-02
    z[0,4,0]  R467      -1.7339763045310974e-01
    z[0,4,0]  R468      5.1582396030426025e-01
    z[0,4,0]  R469      3.8748210668563843e-01
    z[0,4,0]  R470      6.2199622392654419e-01
    z[0,4,0]  R471      1.6083106398582458e-01
    z[0,4,0]  R472      -5.0983637571334839e-01
    z[0,4,0]  R473      -5.4045480489730835e-01
    z[0,4,0]  R474      -1.6421714425086975e-01
    z[0,4,0]  R475      7.4362337589263916e-02
    z[0,4,0]  R476      -3.0733120441436768e-01
    z[0,4,0]  R477      -2.5392469018697739e-02
    z[0,4,0]  R478      1.0203232616186142e-01
    z[0,4,0]  R479      0.0551738440990448
    z[0,4,0]  R480      3.4000761806964874e-02
    z[0,4,0]  R481      1.6986259818077087e-01
    z[0,4,0]  R482      6.4190936088562012e-01
    z[0,4,0]  R483      8.0839961767196655e-01
    z[0,4,0]  R484      3.1775695085525513e-01
    z[0,4,0]  R485      -5.4890990257263184e-01
    z[0,4,0]  R486      -5.3098142147064209e-01
    z[0,4,0]  R487      -5.1513737440109253e-01
    z[0,4,0]  R488      -5.3131037950515747e-01
    z[0,4,0]  R489      5.3540289402008057e-01
    z[0,4,0]  R490      5.3422939777374268e-01
    z[0,4,0]  R491      4.5881351828575134e-01
    z[0,4,0]  R492      5.3400319814682007e-01
    z[0,4,0]  R493      2.5074765086174011e-01
    z[0,4,0]  R494      5.8973252773284912e-01
    z[0,4,0]  R495      -8.4130299091339111e-01
    z[0,4,0]  R496      -2.4495464563369751e-01
    z[0,4,0]  R497      7.4004429578781128e-01
    z[0,4,0]  R498      8.2299959659576416e-01
    z[0,4,0]  R499      6.7126452922821045e-01
    z[0,4,0]  R500      5.6011730432510376e-01
    z[0,4,0]  R501      7.4564450979232788e-01
    z[0,4,0]  R502      8.5695606470108032e-01
    z[0,4,0]  R503      6.5311104059219360e-01
    z[0,4,0]  R504      3.7618693709373474e-01
    z[0,4,0]  R505      3.7892970442771912e-01
    z[0,4,0]  R506      6.7926585674285889e-01
    z[0,4,0]  R507      5.6380158662796021e-01
    z[0,4,0]  R508      8.2849204540252686e-01
    z[0,4,0]  R509      5.0105530023574829e-01
    z[0,4,0]  R510      4.3442982435226440e-01
    z[0,4,0]  R511      8.3988642692565918e-01
    z[0,4,0]  R512      3.2327917218208313e-01
    z[0,4,0]  R513      2.8911077976226807e-01
    z[0,4,0]  R514      4.1249915957450867e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R395      -1
    z[0,4,1]  R396      1
    z[0,4,1]  R407      -2.2679312527179718e-01
    z[0,4,1]  R408      -2.9191309213638306e-01
    z[0,4,1]  R409      2.7506455779075623e-01
    z[0,4,1]  R410      1.9605407491326332e-02
    z[0,4,1]  R411      -1.2485348433256149e-01
    z[0,4,1]  R412      1.9079299271106720e-01
    z[0,4,1]  R413      3.5919818282127380e-01
    z[0,4,1]  R414      2.1217736601829529e-01
    z[0,4,1]  R415      1.9420032203197479e-01
    z[0,4,1]  R416      2.6884013414382935e-01
    z[0,4,1]  R417      -4.5313993096351624e-01
    z[0,4,1]  R418      -3.1489136815071106e-01
    z[0,4,1]  R419      -3.5165268182754517e-01
    z[0,4,1]  R420      -2.2898840904235840e-01
    z[0,4,1]  R421      -4.1955053806304932e-02
    z[0,4,1]  R422      -1.4321479201316833e-01
    z[0,4,1]  R423      -2.4670347571372986e-01
    z[0,4,1]  R424      -0.0705266073346138
    z[0,4,1]  R425      -3.3981472253799438e-01
    z[0,4,1]  R426      -1.7385317385196686e-01
    z[0,4,1]  R427      2.9062485694885254e-01
    z[0,4,1]  R428      -7.2948127985000610e-02
    z[0,4,1]  R429      0.00988028198480606
    z[0,4,1]  R430      -3.7674322724342346e-02
    z[0,4,1]  R431      -3.2302632927894592e-02
    z[0,4,1]  R432      -2.0202779769897461e-01
    z[0,4,1]  R433      1.7496684193611145e-01
    z[0,4,1]  R434      2.7793058753013611e-01
    z[0,4,1]  R435      3.4806916117668152e-01
    z[0,4,1]  R436      2.6849013566970825e-01
    z[0,4,1]  R437      -8.3844490349292755e-02
    z[0,4,1]  R438      -9.4447515904903412e-02
    z[0,4,1]  R439      9.4490736722946167e-02
    z[0,4,1]  R440      -2.3460227251052856e-01
    z[0,4,1]  R441      -1.5209205448627472e-01
    z[0,4,1]  R442      1.8347331881523132e-01
    z[0,4,1]  R443      6.4633525907993317e-02
    z[0,4,1]  R444      4.3670570850372314e-01
    z[0,4,1]  R445      -1.0524497926235199e-01
    z[0,4,1]  R446      -5.0707951188087463e-02
    z[0,4,1]  R447      -3.4030193090438843e-01
    z[0,4,1]  R448      -2.0597891509532928e-01
    z[0,4,1]  R449      -1.4286459982395172e-01
    z[0,4,1]  R450      1.0545502603054047e-01
    z[0,4,1]  R451      1.5984825789928436e-01
    z[0,4,1]  R452      -2.7552312612533569e-01
    z[0,4,1]  R453      -2.2291575372219086e-01
    z[0,4,1]  R454      1.9611382484436035e-01
    z[0,4,1]  R455      3.6403939127922058e-01
    z[0,4,1]  R456      -2.1743577718734741e-01
    z[0,4,1]  R457      -2.6841464638710022e-01
    z[0,4,1]  R458      -0.270877480506897
    z[0,4,1]  R459      -2.9492446780204773e-01
    z[0,4,1]  R460      -1.5599857270717621e-01
    z[0,4,1]  R461      -0.0677003264427185
    z[0,4,1]  R462      -1.4299592934548855e-02
    z[0,4,1]  R463      -4.6287972480058670e-02
    z[0,4,1]  R464      -1.0172042250633240e-01
    z[0,4,1]  R465      4.3016073107719421e-01
    z[0,4,1]  R466      0.08734080940485
    z[0,4,1]  R467      -4.4155126810073853e-01
    z[0,4,1]  R468      -0.0909222811460495
    z[0,4,1]  R469      1.6748405992984772e-01
    z[0,4,1]  R470      4.7551002353429794e-02
    z[0,4,1]  R471      -3.4410160034894943e-02
    z[0,4,1]  R472      3.6228740215301514e-01
    z[0,4,1]  R473      3.5348224639892578e-01
    z[0,4,1]  R474      2.6601800322532654e-01
    z[0,4,1]  R475      2.8902328014373779e-01
    z[0,4,1]  R476      9.1782903671264648e-01
    z[0,4,1]  R477      1.5553353726863861e-01
    z[0,4,1]  R478      1.6742932796478271e-01
    z[0,4,1]  R479      1.3639301061630249e-01
    z[0,4,1]  R480      3.3267110586166382e-01
    z[0,4,1]  R481      8.4872043132781982e-01
    z[0,4,1]  R482      -3.9586371183395386e-01
    z[0,4,1]  R483      6.0734614729881287e-02
    z[0,4,1]  R484      -5.4834067821502686e-01
    z[0,4,1]  R485      4.6457564830780029e-01
    z[0,4,1]  R486      2.2648283839225769e-01
    z[0,4,1]  R487      1.0711296647787094e-01
    z[0,4,1]  R488      -3.5957047343254089e-01
    z[0,4,1]  R489      -6.4243339002132416e-02
    z[0,4,1]  R490      -1.0019612312316895e-01
    z[0,4,1]  R491      -4.1654875874519348e-01
    z[0,4,1]  R492      -2.7685368061065674e-01
    z[0,4,1]  R493      -3.2248803973197937e-01
    z[0,4,1]  R494      -4.5288011431694031e-02
    z[0,4,1]  R495      -1.2615230679512024e-01
    z[0,4,1]  R496      7.4578225612640381e-01
    z[0,4,1]  R497      1.1409156024456024e-01
    z[0,4,1]  R498      -2.9845565557479858e-01
    z[0,4,1]  R499      -4.6609482169151306e-01
    z[0,4,1]  R500      2.2150099277496338e-01
    z[0,4,1]  R501      -2.2309708595275879e-01
    z[0,4,1]  R502      -8.4515297785401344e-03
    z[0,4,1]  R503      -2.4895490705966949e-01
    z[0,4,1]  R504      -8.9898578822612762e-02
    z[0,4,1]  R505      -2.9223543405532837e-01
    z[0,4,1]  R506      1.1659777164459229e-01
    z[0,4,1]  R507      -5.0466316938400269e-01
    z[0,4,1]  R508      2.9510464519262314e-02
    z[0,4,1]  R509      -2.6673266291618347e-01
    z[0,4,1]  R510      -5.7460623979568481e-01
    z[0,4,1]  R511      -4.6372163295745850e-01
    z[0,4,1]  R512      -5.5609703063964844e-01
    z[0,4,1]  R513      -7.3463952541351318e-01
    z[0,4,1]  R514      -0.791696310043335
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R397      -1
    z[0,4,2]  R398      1
    z[0,4,2]  R407      8.3470441401004791e-02
    z[0,4,2]  R408      3.8476087152957916e-02
    z[0,4,2]  R409      2.8873598575592041e-01
    z[0,4,2]  R410      1.6556492447853088e-01
    z[0,4,2]  R411      2.8725165128707886e-01
    z[0,4,2]  R412      -8.4224832057952881e-01
    z[0,4,2]  R413      -5.8925980329513550e-01
    z[0,4,2]  R414      -6.7917782068252563e-01
    z[0,4,2]  R415      -7.1529638767242432e-01
    z[0,4,2]  R416      -5.9789091348648071e-01
    z[0,4,2]  R417      2.9072910547256470e-01
    z[0,4,2]  R418      3.1898257136344910e-01
    z[0,4,2]  R419      7.5956201553344727e-01
    z[0,4,2]  R420      7.4666303396224976e-01
    z[0,4,2]  R421      0.505126416683197
    z[0,4,2]  R422      1.7032857239246368e-01
    z[0,4,2]  R423      4.6780437231063843e-01
    z[0,4,2]  R424      7.2464540600776672e-02
    z[0,4,2]  R425      6.0924118757247925e-01
    z[0,4,2]  R426      3.5284444689750671e-01
    z[0,4,2]  R427      -8.1702905893325806e-01
    z[0,4,2]  R428      5.5323904752731323e-01
    z[0,4,2]  R429      4.4137695431709290e-01
    z[0,4,2]  R430      5.7123631238937378e-01
    z[0,4,2]  R431      2.5803306698799133e-01
    z[0,4,2]  R432      6.0710644721984863e-01
    z[0,4,2]  R433      -5.4919117689132690e-01
    z[0,4,2]  R434      -0.506799042224884
    z[0,4,2]  R435      -4.6140092611312866e-01
    z[0,4,2]  R436      3.8230541348457336e-01
    z[0,4,2]  R437      1.3293799757957458e-01
    z[0,4,2]  R438      4.8885592818260193e-01
    z[0,4,2]  R439      4.8153975605964661e-01
    z[0,4,2]  R440      1.2029406428337097e-01
    z[0,4,2]  R441      6.9337779283523560e-01
    z[0,4,2]  R442      4.2525851726531982e-01
    z[0,4,2]  R443      2.5272551178932190e-01
    z[0,4,2]  R444      4.4809684157371521e-01
    z[0,4,2]  R445      7.2975230216979980e-01
    z[0,4,2]  R446      0.188186377286911
    z[0,4,2]  R447      2.5500911474227905e-01
    z[0,4,2]  R448      -8.5257776081562042e-03
    z[0,4,2]  R449      3.4689456224441528e-02
    z[0,4,2]  R450      5.5537760257720947e-01
    z[0,4,2]  R451      6.4251339435577393e-01
    z[0,4,2]  R452      6.6550296545028687e-01
    z[0,4,2]  R453      1.0407479852437973e-01
    z[0,4,2]  R454      -4.6777981519699097e-01
    z[0,4,2]  R455      -6.9043183326721191e-01
    z[0,4,2]  R456      5.1425766944885254e-01
    z[0,4,2]  R457      3.2647156715393066e-01
    z[0,4,2]  R458      5.0981956720352173e-01
    z[0,4,2]  R459      7.0545291900634766e-01
    z[0,4,2]  R460      5.3512346744537354e-01
    z[0,4,2]  R461      4.9972110986709595e-01
    z[0,4,2]  R462      0.391156941652298
    z[0,4,2]  R463      3.2480636239051819e-01
    z[0,4,2]  R464      2.7096980810165405e-01
    z[0,4,2]  R465      -4.1731411218643188e-01
    z[0,4,2]  R466      -0.178622305393219
    z[0,4,2]  R467      6.4340072870254517e-01
    z[0,4,2]  R468      -3.1454391777515411e-02
    z[0,4,2]  R469      5.2287101745605469e-01
    z[0,4,2]  R470      2.2768445312976837e-01
    z[0,4,2]  R471      4.5462402701377869e-01
    z[0,4,2]  R472      -5.8153760433197021e-01
    z[0,4,2]  R473      -6.9444268941879272e-01
    z[0,4,2]  R474      -2.5282454490661621e-01
    z[0,4,2]  R475      -2.2663612663745880e-01
    z[0,4,2]  R476      1.1399599909782410e-01
    z[0,4,2]  R477      -3.3531033992767334e-01
    z[0,4,2]  R478      -4.4973435997962952e-01
    z[0,4,2]  R479      -6.0888135433197021e-01
    z[0,4,2]  R480      -5.8807331323623657e-01
    z[0,4,2]  R481      -5.0384733825922012e-02
    z[0,4,2]  R482      3.9323827624320984e-01
    z[0,4,2]  R483      2.6337489485740662e-01
    z[0,4,2]  R484      3.6571112275123596e-01
    z[0,4,2]  R485      -2.9900306463241577e-01
    z[0,4,2]  R486      3.7387913465499878e-01
    z[0,4,2]  R487      3.2314866781234741e-01
    z[0,4,2]  R488      2.5590887665748596e-01
    z[0,4,2]  R489      5.8135926723480225e-01
    z[0,4,2]  R490      4.1173884272575378e-01
    z[0,4,2]  R491      1.9148686528205872e-01
    z[0,4,2]  R492      4.0773135423660278e-01
    z[0,4,2]  R493      5.1898753643035889e-01
    z[0,4,2]  R494      4.3880489468574524e-01
    z[0,4,2]  R495      1.0552560538053513e-01
    z[0,4,2]  R496      1.1646560579538345e-01
    z[0,4,2]  R497      4.1714864969253540e-01
    z[0,4,2]  R498      8.2238681614398956e-02
    z[0,4,2]  R499      3.9859315752983093e-01
    z[0,4,2]  R500      3.9502510428428650e-01
    z[0,4,2]  R501      5.2484279870986938e-01
    z[0,4,2]  R502      8.7059482932090759e-02
    z[0,4,2]  R503      1.9846706092357635e-01
    z[0,4,2]  R504      5.2390646934509277e-01
    z[0,4,2]  R505      4.8633712530136108e-01
    z[0,4,2]  R506      6.1409723758697510e-01
    z[0,4,2]  R507      3.5800164937973022e-01
    z[0,4,2]  R508      3.9475083351135254e-01
    z[0,4,2]  R509      6.2169307470321655e-01
    z[0,4,2]  R510      5.6073254346847534e-01
    z[0,4,2]  R511      1.9272992014884949e-01
    z[0,4,2]  R512      5.3977102041244507e-01
    z[0,4,2]  R513      0.449907124042511
    z[0,4,2]  R514      3.3825227618217468e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R399      -1
    z[0,4,3]  R400      1
    z[0,4,3]  R407      -4.7666269540786743e-01
    z[0,4,3]  R408      -4.4922330975532532e-01
    z[0,4,3]  R409      6.1476852744817734e-02
    z[0,4,3]  R410      -3.2740056514739990e-01
    z[0,4,3]  R411      -6.3198663294315338e-02
    z[0,4,3]  R412      -3.5486346483230591e-01
    z[0,4,3]  R413      -4.3319106101989746e-01
    z[0,4,3]  R414      -4.7567120194435120e-01
    z[0,4,3]  R415      -6.6029065847396851e-01
    z[0,4,3]  R416      -0.583728551864624
    z[0,4,3]  R417      -3.2236695289611816e-01
    z[0,4,3]  R418      -7.2486883401870728e-01
    z[0,4,3]  R419      -2.7400314807891846e-01
    z[0,4,3]  R420      -2.1184596419334412e-01
    z[0,4,3]  R421      -4.4912162423133850e-01
    z[0,4,3]  R422      -4.5159086585044861e-01
    z[0,4,3]  R423      1.6839260933920741e-03
    z[0,4,3]  R424      0.598764181137085
    z[0,4,3]  R425      4.4689339399337769e-01
    z[0,4,3]  R426      5.1332950592041016e-01
    z[0,4,3]  R427      -2.8303396701812744e-01
    z[0,4,3]  R428      0.466047078371048
    z[0,4,3]  R429      2.2941111028194427e-01
    z[0,4,3]  R430      0.624661386013031
    z[0,4,3]  R431      4.3578910827636719e-01
    z[0,4,3]  R432      2.3679597675800323e-01
    z[0,4,3]  R433      -5.4818040132522583e-01
    z[0,4,3]  R434      -5.4645639657974243e-01
    z[0,4,3]  R435      -3.0926057696342468e-01
    z[0,4,3]  R436      6.7048561573028564e-01
    z[0,4,3]  R437      -8.0479115247726440e-01
    z[0,4,3]  R438      6.2632894515991211e-01
    z[0,4,3]  R439      6.9283038377761841e-01
    z[0,4,3]  R440      4.7617882490158081e-02
    z[0,4,3]  R441      3.4029385447502136e-01
    z[0,4,3]  R442      7.7173836529254913e-02
    z[0,4,3]  R443      3.3433189988136292e-01
    z[0,4,3]  R444      3.0583688616752625e-01
    z[0,4,3]  R445      4.6924594044685364e-01
    z[0,4,3]  R446      1.2052089720964432e-01
    z[0,4,3]  R447      -1.3106903433799744e-01
    z[0,4,3]  R448      -1.8353970348834991e-01
    z[0,4,3]  R449      -1.2935988605022430e-01
    z[0,4,3]  R450      2.5674277544021606e-01
    z[0,4,3]  R451      3.4229108691215515e-01
    z[0,4,3]  R452      4.6737492084503174e-01
    z[0,4,3]  R453      2.9534491896629333e-01
    z[0,4,3]  R454      -5.4688894748687744e-01
    z[0,4,3]  R455      -1.1105062067508698e-01
    z[0,4,3]  R456      4.0439051389694214e-01
    z[0,4,3]  R457      0.212955504655838
    z[0,4,3]  R458      3.5166999697685242e-01
    z[0,4,3]  R459      4.3048301339149475e-01
    z[0,4,3]  R460      4.8108947277069092e-01
    z[0,4,3]  R461      3.6428511142730713e-01
    z[0,4,3]  R462      5.4846316576004028e-01
    z[0,4,3]  R463      0.813058078289032
    z[0,4,3]  R464      0.588672399520874
    z[0,4,3]  R465      5.4731898009777069e-02
    z[0,4,3]  R466      6.9241464138031006e-01
    z[0,4,3]  R467      -3.9888751506805420e-01
    z[0,4,3]  R468      -7.6385718584060669e-01
    z[0,4,3]  R469      3.9119008183479309e-01
    z[0,4,3]  R470      -1.2299574166536331e-01
    z[0,4,3]  R471      0.621128261089325
    z[0,4,3]  R472      1.0593704134225845e-01
    z[0,4,3]  R473      2.2778582572937012e-01
    z[0,4,3]  R474      0.863503098487854
    z[0,4,3]  R475      7.6651722192764282e-01
    z[0,4,3]  R476      1.5615323185920715e-01
    z[0,4,3]  R477      -2.0572341978549957e-01
    z[0,4,3]  R478      -0.718946635723114
    z[0,4,3]  R479      -4.0803977847099304e-01
    z[0,4,3]  R480      -3.6046928167343140e-01
    z[0,4,3]  R481      0.00858311913907528
    z[0,4,3]  R482      -1.3553509116172791e-01
    z[0,4,3]  R483      -1.1303997784852982e-01
    z[0,4,3]  R484      -3.0554416775703430e-01
    z[0,4,3]  R485      6.0953569412231445e-01
    z[0,4,3]  R486      -0.520353376865387
    z[0,4,3]  R487      6.1089444905519485e-02
    z[0,4,3]  R488      -3.4144330024719238e-01
    z[0,4,3]  R489      5.6526422500610352e-01
    z[0,4,3]  R490      1.2899178266525269e-01
    z[0,4,3]  R491      6.7346578836441040e-01
    z[0,4,3]  R492      1.6318507492542267e-02
    z[0,4,3]  R493      5.9263265132904053e-01
    z[0,4,3]  R494      4.2944005131721497e-01
    z[0,4,3]  R495      -4.1192913055419922e-01
    z[0,4,3]  R496      -7.6644122600555420e-02
    z[0,4,3]  R497      2.0884402096271515e-01
    z[0,4,3]  R498      3.2799789309501648e-01
    z[0,4,3]  R499      3.0698782205581665e-01
    z[0,4,3]  R500      4.4939696788787842e-01
    z[0,4,3]  R501      1.0506445914506912e-01
    z[0,4,3]  R502      4.7404372692108154e-01
    z[0,4,3]  R503      2.8486651182174683e-01
    z[0,4,3]  R504      4.7162207961082458e-01
    z[0,4,3]  R505      0.529949963092804
    z[0,4,3]  R506      8.8852927088737488e-02
    z[0,4,3]  R507      2.8940027952194214e-01
    z[0,4,3]  R508      -1.3750459067523479e-02
    z[0,4,3]  R509      -0.197368323802948
    z[0,4,3]  R510      -2.3361812531948090e-01
    z[0,4,3]  R511      -1.0043931752443314e-01
    z[0,4,3]  R512      -4.6339428424835205e-01
    z[0,4,3]  R513      -3.1964552402496338e-01
    z[0,4,3]  R514      -1.7776307463645935e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R401      -1
    z[0,4,4]  R402      1
    z[0,4,4]  R407      2.9816165566444397e-01
    z[0,4,4]  R408      -4.0204051136970520e-01
    z[0,4,4]  R409      -1.3788822293281555e-01
    z[0,4,4]  R410      2.4161966145038605e-01
    z[0,4,4]  R411      -0.403253436088562
    z[0,4,4]  R412      -2.0957843959331512e-01
    z[0,4,4]  R413      5.3887295722961426e-01
    z[0,4,4]  R414      3.3918201923370361e-01
    z[0,4,4]  R415      9.6655443310737610e-02
    z[0,4,4]  R416      0.0228701401501894
    z[0,4,4]  R417      -5.0021409988403320e-01
    z[0,4,4]  R418      -0.421298086643219
    z[0,4,4]  R419      -2.2560994327068329e-01
    z[0,4,4]  R420      1.8830461800098419e-01
    z[0,4,4]  R421      2.6118096709251404e-01
    z[0,4,4]  R422      -9.3708731234073639e-02
    z[0,4,4]  R423      -4.7579240798950195e-01
    z[0,4,4]  R424      -1.8810595571994781e-01
    z[0,4,4]  R425      -2.3870684206485748e-01
    z[0,4,4]  R426      -3.8813826441764832e-01
    z[0,4,4]  R427      -1.7493402957916260e-01
    z[0,4,4]  R428      0.600666344165802
    z[0,4,4]  R429      5.8888554573059082e-01
    z[0,4,4]  R430      2.6410397887229919e-01
    z[0,4,4]  R431      2.0973308384418488e-01
    z[0,4,4]  R432      4.8397764563560486e-01
    z[0,4,4]  R433      1.9514480233192444e-01
    z[0,4,4]  R434      3.6094364523887634e-01
    z[0,4,4]  R435      0.411279559135437
    z[0,4,4]  R436      1.5228706598281860e-01
    z[0,4,4]  R437      1.7387558519840240e-01
    z[0,4,4]  R438      -3.7655362486839294e-01
    z[0,4,4]  R439      -3.9956696331501007e-02
    z[0,4,4]  R440      -9.3102556467056274e-01
    z[0,4,4]  R441      5.3309971094131470e-01
    z[0,4,4]  R442      -3.3064141869544983e-01
    z[0,4,4]  R443      5.1917344331741333e-01
    z[0,4,4]  R444      4.5456290245056152e-01
    z[0,4,4]  R445      3.2867538928985596e-01
    z[0,4,4]  R446      4.8040706664323807e-02
    z[0,4,4]  R447      -3.5176917910575867e-01
    z[0,4,4]  R448      -8.6738181114196777e-01
    z[0,4,4]  R449      -5.9705656766891479e-01
    z[0,4,4]  R450      2.7617081999778748e-01
    z[0,4,4]  R451      -7.1254797279834747e-02
    z[0,4,4]  R452      -1.8082691729068756e-01
    z[0,4,4]  R453      -2.3732826113700867e-01
    z[0,4,4]  R454      0.0220558512955904
    z[0,4,4]  R455      4.0378373861312866e-01
    z[0,4,4]  R456      -1.3024382293224335e-01
    z[0,4,4]  R457      -0.657317578792572
    z[0,4,4]  R458      -2.4231974780559540e-01
    z[0,4,4]  R459      -1.3833306729793549e-01
    z[0,4,4]  R460      3.9530539512634277e-01
    z[0,4,4]  R461      4.7931128740310669e-01
    z[0,4,4]  R462      2.4191793799400330e-01
    z[0,4,4]  R463      -1.6981212794780731e-01
    z[0,4,4]  R464      1.2120685726404190e-01
    z[0,4,4]  R465      1.2582322955131531e-01
    z[0,4,4]  R466      1.8317420035600662e-02
    z[0,4,4]  R467      -4.1541165113449097e-01
    z[0,4,4]  R468      0.360927551984787
    z[0,4,4]  R469      -1.6938069462776184e-01
    z[0,4,4]  R470      1.7857013642787933e-01
    z[0,4,4]  R471      1.2255582958459854e-01
    z[0,4,4]  R472      7.8928455710411072e-02
    z[0,4,4]  R473      -1.3981994986534119e-01
    z[0,4,4]  R474      0.024102833122015
    z[0,4,4]  R475      -2.0186141133308411e-01
    z[0,4,4]  R476      -1.5936891734600067e-01
    z[0,4,4]  R477      5.1540863513946533e-01
    z[0,4,4]  R478      4.0010219812393188e-01
    z[0,4,4]  R479      5.1996868848800659e-01
    z[0,4,4]  R480      -3.3404279500246048e-02
    z[0,4,4]  R481      -6.8096712231636047e-02
    z[0,4,4]  R482      -2.3109939694404602e-01
    z[0,4,4]  R483      -4.7391152381896973e-01
    z[0,4,4]  R484      -3.2091453671455383e-01
    z[0,4,4]  R485      -1.4757290482521057e-01
    z[0,4,4]  R486      -3.8310667872428894e-01
    z[0,4,4]  R487      2.7381709218025208e-01
    z[0,4,4]  R488      4.2095455527305603e-01
    z[0,4,4]  R489      1.7630970105528831e-02
    z[0,4,4]  R490      3.8901785016059875e-01
    z[0,4,4]  R491      3.2643833756446838e-01
    z[0,4,4]  R492      -2.8026765584945679e-01
    z[0,4,4]  R493      1.1587437987327576e-01
    z[0,4,4]  R494      -5.0967586040496826e-01
    z[0,4,4]  R495      2.3534177243709564e-01
    z[0,4,4]  R496      1.1257145553827286e-02
    z[0,4,4]  R497      -1.5665613114833832e-01
    z[0,4,4]  R498      1.7417942872270942e-03
    z[0,4,4]  R499      -2.6921004056930542e-01
    z[0,4,4]  R500      3.3037438988685608e-02
    z[0,4,4]  R501      -3.1110098958015442e-01
    z[0,4,4]  R502      -0.0326436311006546
    z[0,4,4]  R503      3.3059865236282349e-01
    z[0,4,4]  R504      2.4304026365280151e-01
    z[0,4,4]  R505      -1.0596216470003128e-01
    z[0,4,4]  R506      -7.2717433795332909e-03
    z[0,4,4]  R507      4.3784198164939880e-01
    z[0,4,4]  R508      3.3182597160339355e-01
    z[0,4,4]  R509      -3.3863988518714905e-01
    z[0,4,4]  R510      7.8207127749919891e-02
    z[0,4,4]  R511      1.2676453590393066e-01
    z[0,4,4]  R512      0.0924171581864357
    z[0,4,4]  R513      -1.1691863834857941e-01
    z[0,4,4]  R514      -6.5099135041236877e-02
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R403      -1
    z[0,4,5]  R404      1
    z[0,4,5]  R407      3.4737229347229004e-01
    z[0,4,5]  R408      -1.8110331892967224e-01
    z[0,4,5]  R409      1.2058693170547485e-01
    z[0,4,5]  R410      0.224329873919487
    z[0,4,5]  R411      0.464220255613327
    z[0,4,5]  R412      -1.5976129472255707e-01
    z[0,4,5]  R413      -1.9083958864212036e-01
    z[0,4,5]  R414      -1.5940341353416443e-01
    z[0,4,5]  R415      5.6714892387390137e-02
    z[0,4,5]  R416      -2.1884283423423767e-01
    z[0,4,5]  R417      1.9040863215923309e-01
    z[0,4,5]  R418      -3.7888143211603165e-02
    z[0,4,5]  R419      -3.0807375907897949e-01
    z[0,4,5]  R420      -5.3016918897628784e-01
    z[0,4,5]  R421      -5.2946358919143677e-01
    z[0,4,5]  R422      -8.2591062784194946e-01
    z[0,4,5]  R423      -6.7597693204879761e-01
    z[0,4,5]  R424      1.4166536927223206e-01
    z[0,4,5]  R425      3.2088515162467957e-01
    z[0,4,5]  R426      1.8555650115013123e-01
    z[0,4,5]  R427      -5.0146546214818954e-02
    z[0,4,5]  R428      0.0869283527135849
    z[0,4,5]  R429      -2.4803197383880615e-01
    z[0,4,5]  R430      -2.0745231211185455e-01
    z[0,4,5]  R431      7.8759455680847168e-01
    z[0,4,5]  R432      2.7698749303817749e-01
    z[0,4,5]  R433      -4.3448275327682495e-01
    z[0,4,5]  R434      -3.5858809947967529e-01
    z[0,4,5]  R435      3.0285245180130005e-01
    z[0,4,5]  R436      3.1407546997070312e-01
    z[0,4,5]  R437      -0.518271267414093
    z[0,4,5]  R438      8.4684297442436218e-02
    z[0,4,5]  R439      -4.5331515138968825e-04
    z[0,4,5]  R440      -1.4894120395183563e-01
    z[0,4,5]  R441      1.7933075129985809e-01
    z[0,4,5]  R442      0.670393705368042
    z[0,4,5]  R443      -1.5988458693027496e-01
    z[0,4,5]  R444      3.9508423209190369e-01
    z[0,4,5]  R445      5.3369738161563873e-02
    z[0,4,5]  R446      5.4483890533447266e-01
    z[0,4,5]  R447      -5.0387692451477051e-01
    z[0,4,5]  R448      -4.1310015320777893e-01
    z[0,4,5]  R449      3.1898081302642822e-01
    z[0,4,5]  R450      3.2117792963981628e-01
    z[0,4,5]  R451      -1.3050472736358643e-01
    z[0,4,5]  R452      1.7264391481876373e-01
    z[0,4,5]  R453      2.4910381436347961e-01
    z[0,4,5]  R454      -1.1318525671958923e-01
    z[0,4,5]  R455      -2.8795739635825157e-02
    z[0,4,5]  R456      -3.4137246012687683e-01
    z[0,4,5]  R457      -2.6963651180267334e-01
    z[0,4,5]  R458      1.5881730616092682e-01
    z[0,4,5]  R459      6.1862353235483170e-02
    z[0,4,5]  R460      1.2337491661310196e-01
    z[0,4,5]  R461      2.6799678802490234e-01
    z[0,4,5]  R462      -2.2233279049396515e-01
    z[0,4,5]  R463      4.3911975622177124e-01
    z[0,4,5]  R464      7.2828143835067749e-01
    z[0,4,5]  R465      -5.4702842235565186e-01
    z[0,4,5]  R466      -2.8476619720458984e-01
    z[0,4,5]  R467      -1.3484671711921692e-01
    z[0,4,5]  R468      9.6714220941066742e-02
    z[0,4,5]  R469      3.2574611902236938e-01
    z[0,4,5]  R470      -4.5938301086425781e-01
    z[0,4,5]  R471      5.5679249763488770e-01
    z[0,4,5]  R472      -4.8105788230895996e-01
    z[0,4,5]  R473      -1.5010836720466614e-01
    z[0,4,5]  R474      -2.2828640043735504e-01
    z[0,4,5]  R475      -3.7901112437248230e-01
    z[0,4,5]  R476      1.2325149029493332e-02
    z[0,4,5]  R477      3.6336949467658997e-01
    z[0,4,5]  R478      2.8015589714050293e-01
    z[0,4,5]  R479      -8.6010143160820007e-02
    z[0,4,5]  R480      3.7844744324684143e-01
    z[0,4,5]  R481      -4.9127709865570068e-01
    z[0,4,5]  R482      3.4868514537811279e-01
    z[0,4,5]  R483      6.8540379405021667e-02
    z[0,4,5]  R484      -4.2214468121528625e-03
    z[0,4,5]  R485      8.7181003764271736e-03
    z[0,4,5]  R486      2.5557172298431396e-01
    z[0,4,5]  R487      -6.2870115041732788e-01
    z[0,4,5]  R488      -4.7782656550407410e-01
    z[0,4,5]  R489      1.2138541787862778e-01
    z[0,4,5]  R490      5.8549094200134277e-01
    z[0,4,5]  R491      9.0634517371654510e-02
    z[0,4,5]  R492      3.9740687608718872e-01
    z[0,4,5]  R493      -4.0575500577688217e-02
    z[0,4,5]  R494      -9.4991348683834076e-02
    z[0,4,5]  R495      -1.9459149241447449e-01
    z[0,4,5]  R496      -0.566662073135376
    z[0,4,5]  R497      4.3897858262062073e-01
    z[0,4,5]  R498      2.3217049241065979e-01
    z[0,4,5]  R499      6.6998794674873352e-02
    z[0,4,5]  R500      3.8771173357963562e-01
    z[0,4,5]  R501      4.6987339854240417e-02
    z[0,4,5]  R502      1.7671336233615875e-01
    z[0,4,5]  R503      5.0558310747146606e-01
    z[0,4,5]  R504      3.0969861149787903e-01
    z[0,4,5]  R505      4.0456745028495789e-01
    z[0,4,5]  R506      2.0982122421264648e-01
    z[0,4,5]  R507      -1.5313214063644409e-01
    z[0,4,5]  R508      -2.1586470305919647e-01
    z[0,4,5]  R509      -0.335225373506546
    z[0,4,5]  R510      -3.0429592728614807e-01
    z[0,4,5]  R511      -1.2198971211910248e-01
    z[0,4,5]  R512      -5.3398627787828445e-02
    z[0,4,5]  R513      -0.00661705294623971
    z[0,4,5]  R514      2.1670649945735931e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R405      -1
    z[0,4,6]  R406      1
    z[0,4,6]  R407      2.7836680412292480e-01
    z[0,4,6]  R408      1.0631252825260162e-01
    z[0,4,6]  R409      3.0986329913139343e-01
    z[0,4,6]  R410      -6.9550549983978271e-01
    z[0,4,6]  R411      -7.1833074092864990e-01
    z[0,4,6]  R412      2.4240817129611969e-01
    z[0,4,6]  R413      -0.0881536602973938
    z[0,4,6]  R414      3.4985548257827759e-01
    z[0,4,6]  R415      -1.0338597930967808e-02
    z[0,4,6]  R416      -4.1892459988594055e-01
    z[0,4,6]  R417      5.4640448093414307e-01
    z[0,4,6]  R418      -9.9875830113887787e-02
    z[0,4,6]  R419      -2.3135414719581604e-01
    z[0,4,6]  R420      4.5691672712564468e-02
    z[0,4,6]  R421      -4.1924589872360229e-01
    z[0,4,6]  R422      2.2850631177425385e-01
    z[0,4,6]  R423      0.0985293835401535
    z[0,4,6]  R424      -2.0890440791845322e-02
    z[0,4,6]  R425      8.8022947311401367e-02
    z[0,4,6]  R426      -2.8565886616706848e-01
    z[0,4,6]  R427      -0.000894435215741396
    z[0,4,6]  R428      1.9662292301654816e-01
    z[0,4,6]  R429      -1.2804168462753296e-01
    z[0,4,6]  R430      -1.4602464437484741e-01
    z[0,4,6]  R431      -2.1753750741481781e-01
    z[0,4,6]  R432      4.6383023262023926e-01
    z[0,4,6]  R433      3.2361376285552979e-01
    z[0,4,6]  R434      0.0416349358856678
    z[0,4,6]  R435      -3.6701294779777527e-01
    z[0,4,6]  R436      4.5281535387039185e-01
    z[0,4,6]  R437      3.5848800092935562e-02
    z[0,4,6]  R438      -1.5062198042869568e-01
    z[0,4,6]  R439      3.4915685653686523e-01
    z[0,4,6]  R440      -1.8617257475852966e-01
    z[0,4,6]  R441      7.5459092855453491e-02
    z[0,4,6]  R442      -7.4120283126831055e-02
    z[0,4,6]  R443      4.5800793170928955e-01
    z[0,4,6]  R444      -2.8293453156948090e-02
    z[0,4,6]  R445      -2.4852499365806580e-01
    z[0,4,6]  R446      -5.2257311344146729e-01
    z[0,4,6]  R447      6.1016047000885010e-01
    z[0,4,6]  R448      -1.5936326235532761e-02
    z[0,4,6]  R449      -0.573460042476654
    z[0,4,6]  R450      6.9207169115543365e-02
    z[0,4,6]  R451      1.5735353529453278e-01
    z[0,4,6]  R452      -1.4017136394977570e-01
    z[0,4,6]  R453      1.7868627607822418e-01
    z[0,4,6]  R454      -2.4157559499144554e-02
    z[0,4,6]  R455      2.4473662674427032e-01
    z[0,4,6]  R456      4.2823340743780136e-02
    z[0,4,6]  R457      -1.2539999186992645e-01
    z[0,4,6]  R458      -1.5164235234260559e-01
    z[0,4,6]  R459      8.1238850951194763e-02
    z[0,4,6]  R460      2.2748689353466034e-01
    z[0,4,6]  R461      -1.6115474700927734e-01
    z[0,4,6]  R462      -1.3305296003818512e-01
    z[0,4,6]  R463      0.0618111714720726
    z[0,4,6]  R464      1.4893175661563873e-01
    z[0,4,6]  R465      -4.2725256085395813e-01
    z[0,4,6]  R466      6.3160061836242676e-01
    z[0,4,6]  R467      1.0554412007331848e-01
    z[0,4,6]  R468      -3.9614457637071609e-02
    z[0,4,6]  R469      5.1047289371490479e-01
    z[0,4,6]  R470      -0.548608660697937
    z[0,4,6]  R471      -0.235431969165802
    z[0,4,6]  R472      1.4751152694225311e-01
    z[0,4,6]  R473      8.2095600664615631e-02
    z[0,4,6]  R474      2.0003418624401093e-01
    z[0,4,6]  R475      -2.9601639509201050e-01
    z[0,4,6]  R476      1.4422810636460781e-02
    z[0,4,6]  R477      -6.5017372369766235e-01
    z[0,4,6]  R478      0.0619877427816391
    z[0,4,6]  R479      4.0417158603668213e-01
    z[0,4,6]  R480      5.1775211095809937e-01
    z[0,4,6]  R481      -0.0470924936234951
    z[0,4,6]  R482      -2.8853079676628113e-01
    z[0,4,6]  R483      1.7710734903812408e-01
    z[0,4,6]  R484      5.1792579889297485e-01
    z[0,4,6]  R485      8.7738549336791039e-03
    z[0,4,6]  R486      -0.210055410861969
    z[0,4,6]  R487      -3.8047656416893005e-01
    z[0,4,6]  R488      -2.8715729713439941e-02
    z[0,4,6]  R489      -0.19149149954319
    z[0,4,6]  R490      1.5574800968170166e-01
    z[0,4,6]  R491      1.0477259755134583e-01
    z[0,4,6]  R492      4.8497340083122253e-01
    z[0,4,6]  R493      4.4440111517906189e-01
    z[0,4,6]  R494      -6.6356673836708069e-02
    z[0,4,6]  R495      4.7136954963207245e-02
    z[0,4,6]  R496      -2.0768925547599792e-01
    z[0,4,6]  R497      -6.6673986613750458e-02
    z[0,4,6]  R498      2.5562450289726257e-01
    z[0,4,6]  R499      4.5592587441205978e-02
    z[0,4,6]  R500      3.5747972130775452e-01
    z[0,4,6]  R501      9.3551538884639740e-02
    z[0,4,6]  R502      3.1063543632626534e-02
    z[0,4,6]  R503      1.6130568087100983e-01
    z[0,4,6]  R504      4.4554957747459412e-01
    z[0,4,6]  R505      2.8060135245323181e-01
    z[0,4,6]  R506      3.0970117449760437e-01
    z[0,4,6]  R507      -1.9239617511630058e-02
    z[0,4,6]  R508      2.5689511094242334e-03
    z[0,4,6]  R509      1.5902109444141388e-01
    z[0,4,6]  R510      -1.1570470035076141e-01
    z[0,4,6]  R511      3.7005368620157242e-02
    z[0,4,6]  R512      -2.6223507523536682e-01
    z[0,4,6]  R513      2.4169474840164185e-01
    z[0,4,6]  R514      7.6468706130981445e-02
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R515      -1
    z[4,0,0]  R516      1
    z[4,0,0]  R529      -2.5392469018697739e-02
    z[4,0,0]  R530      1.0203232616186142e-01
    z[4,0,0]  R531      0.0551738440990448
    z[4,0,0]  R532      3.4000761806964874e-02
    z[4,0,0]  R533      1.6986259818077087e-01
    z[4,0,0]  R534      8.4120273590087891e-01
    z[4,0,0]  R535      6.4190936088562012e-01
    z[4,0,0]  R536      8.0839961767196655e-01
    z[4,0,0]  R537      3.1775695085525513e-01
    z[4,0,0]  R538      -5.4890990257263184e-01
    z[4,0,0]  R539      -5.3098142147064209e-01
    z[4,0,0]  R540      -5.1513737440109253e-01
    z[4,0,0]  R541      -5.3131037950515747e-01
    z[4,0,0]  R542      5.3540289402008057e-01
    z[4,0,0]  R543      5.3422939777374268e-01
    z[4,0,0]  R544      4.5881351828575134e-01
    z[4,0,0]  R545      5.3400319814682007e-01
    z[4,0,0]  R546      2.5074765086174011e-01
    z[4,0,0]  R547      5.8973252773284912e-01
    z[4,0,0]  R548      -8.4130299091339111e-01
    z[4,0,0]  R549      -2.4495464563369751e-01
    z[4,0,0]  R550      7.4004429578781128e-01
    z[4,0,0]  R551      8.2299959659576416e-01
    z[4,0,0]  R552      6.7126452922821045e-01
    z[4,0,0]  R553      5.6011730432510376e-01
    z[4,0,0]  R554      7.4564450979232788e-01
    z[4,0,0]  R555      8.5695606470108032e-01
    z[4,0,0]  R556      6.5311104059219360e-01
    z[4,0,0]  R557      3.7618693709373474e-01
    z[4,0,0]  R558      3.7892970442771912e-01
    z[4,0,0]  R559      6.7926585674285889e-01
    z[4,0,0]  R560      5.6380158662796021e-01
    z[4,0,0]  R561      8.2849204540252686e-01
    z[4,0,0]  R562      5.0105530023574829e-01
    z[4,0,0]  R563      4.3442982435226440e-01
    z[4,0,0]  R564      8.3988642692565918e-01
    z[4,0,0]  R565      3.2327917218208313e-01
    z[4,0,0]  R566      2.8911077976226807e-01
    z[4,0,0]  R567      4.1249915957450867e-01
    z[4,0,0]  R568      6.5370810031890869e-01
    z[4,0,0]  R569      7.1117323637008667e-01
    z[4,0,0]  R570      5.2209275960922241e-01
    z[4,0,0]  R571      6.1571907252073288e-02
    z[4,0,0]  R572      -8.9026167988777161e-03
    z[4,0,0]  R573      -3.8989506661891937e-02
    z[4,0,0]  R574      6.7693866789340973e-02
    z[4,0,0]  R575      4.4584628194570541e-02
    z[4,0,0]  R576      7.4828721582889557e-02
    z[4,0,0]  R577      -1.4557796716690063e-01
    z[4,0,0]  R578      -2.9112884402275085e-01
    z[4,0,0]  R579      1.5809562802314758e-01
    z[4,0,0]  R580      -1.6295441985130310e-01
    z[4,0,0]  R581      -1.3062354922294617e-01
    z[4,0,0]  R582      5.8467328548431396e-02
    z[4,0,0]  R583      -1.6511309146881104e-01
    z[4,0,0]  R584      0.758529543876648
    z[4,0,0]  R585      3.8202244043350220e-01
    z[4,0,0]  R586      0.561324417591095
    z[4,0,0]  R587      -0.367117315530777
    z[4,0,0]  R588      2.5374794006347656e-01
    z[4,0,0]  R589      5.7250201702117920e-01
    z[4,0,0]  R590      3.8465201854705811e-01
    z[4,0,0]  R591      1.7563463747501373e-01
    z[4,0,0]  R592      9.1865532100200653e-02
    z[4,0,0]  R593      -1.8892130255699158e-01
    z[4,0,0]  R594      -0.326642781496048
    z[4,0,0]  R595      -4.1802617907524109e-01
    z[4,0,0]  R596      7.2994068264961243e-02
    z[4,0,0]  R597      -1.6578853130340576e-01
    z[4,0,0]  R598      4.3377479910850525e-01
    z[4,0,0]  R599      3.9455017447471619e-01
    z[4,0,0]  R600      6.7611508071422577e-02
    z[4,0,0]  R601      2.4134321510791779e-01
    z[4,0,0]  R602      4.6399539709091187e-01
    z[4,0,0]  R603      5.6151503324508667e-01
    z[4,0,0]  R604      3.8915482163429260e-01
    z[4,0,0]  R605      2.5209689140319824e-01
    z[4,0,0]  R606      0.612575888633728
    z[4,0,0]  R607      2.2815930843353271e-01
    z[4,0,0]  R608      -2.3585041984915733e-02
    z[4,0,0]  R609      4.1781631112098694e-01
    z[4,0,0]  R610      0.655974805355072
    z[4,0,0]  R611      6.3054978847503662e-01
    z[4,0,0]  R612      4.2497199773788452e-01
    z[4,0,0]  R613      8.3781987428665161e-01
    z[4,0,0]  R614      -6.5555536746978760e-01
    z[4,0,0]  R615      -3.9329436421394348e-01
    z[4,0,0]  R616      6.2401664257049561e-01
    z[4,0,0]  R617      0.505494236946106
    z[4,0,0]  R618      6.6037893295288086e-01
    z[4,0,0]  R619      4.4774687290191650e-01
    z[4,0,0]  R620      4.8437824845314026e-01
    z[4,0,0]  R621      5.3428411483764648e-01
    z[4,0,0]  R622      6.4832133054733276e-01
    z[4,0,0]  R623      -7.6235592365264893e-02
    z[4,0,0]  R624      4.9269955605268478e-02
    z[4,0,0]  R625      -3.7443125247955322e-01
    z[4,0,0]  R626      -2.6094339787960052e-02
    z[4,0,0]  R627      -1.7339763045310974e-01
    z[4,0,0]  R628      5.1582396030426025e-01
    z[4,0,0]  R629      3.8748210668563843e-01
    z[4,0,0]  R630      6.2199622392654419e-01
    z[4,0,0]  R631      1.6083106398582458e-01
    z[4,0,0]  R632      -5.0983637571334839e-01
    z[4,0,0]  R633      -5.4045480489730835e-01
    z[4,0,0]  R634      -1.6421714425086975e-01
    z[4,0,0]  R635      7.4362337589263916e-02
    z[4,0,0]  R636      -3.0733120441436768e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R517      -1
    z[4,0,1]  R518      1
    z[4,0,1]  R529      1.5553353726863861e-01
    z[4,0,1]  R530      1.6742932796478271e-01
    z[4,0,1]  R531      1.3639301061630249e-01
    z[4,0,1]  R532      3.3267110586166382e-01
    z[4,0,1]  R533      8.4872043132781982e-01
    z[4,0,1]  R534      2.7506455779075623e-01
    z[4,0,1]  R535      -3.9586371183395386e-01
    z[4,0,1]  R536      6.0734614729881287e-02
    z[4,0,1]  R537      -5.4834067821502686e-01
    z[4,0,1]  R538      4.6457564830780029e-01
    z[4,0,1]  R539      2.2648283839225769e-01
    z[4,0,1]  R540      1.0711296647787094e-01
    z[4,0,1]  R541      -3.5957047343254089e-01
    z[4,0,1]  R542      -6.4243339002132416e-02
    z[4,0,1]  R543      -1.0019612312316895e-01
    z[4,0,1]  R544      -4.1654875874519348e-01
    z[4,0,1]  R545      -2.7685368061065674e-01
    z[4,0,1]  R546      -3.2248803973197937e-01
    z[4,0,1]  R547      -4.5288011431694031e-02
    z[4,0,1]  R548      -1.2615230679512024e-01
    z[4,0,1]  R549      7.4578225612640381e-01
    z[4,0,1]  R550      1.1409156024456024e-01
    z[4,0,1]  R551      -2.9845565557479858e-01
    z[4,0,1]  R552      -4.6609482169151306e-01
    z[4,0,1]  R553      2.2150099277496338e-01
    z[4,0,1]  R554      -2.2309708595275879e-01
    z[4,0,1]  R555      -8.4515297785401344e-03
    z[4,0,1]  R556      -2.4895490705966949e-01
    z[4,0,1]  R557      -8.9898578822612762e-02
    z[4,0,1]  R558      -2.9223543405532837e-01
    z[4,0,1]  R559      1.1659777164459229e-01
    z[4,0,1]  R560      -5.0466316938400269e-01
    z[4,0,1]  R561      2.9510464519262314e-02
    z[4,0,1]  R562      -2.6673266291618347e-01
    z[4,0,1]  R563      -5.7460623979568481e-01
    z[4,0,1]  R564      -4.6372163295745850e-01
    z[4,0,1]  R565      -5.5609703063964844e-01
    z[4,0,1]  R566      -7.3463952541351318e-01
    z[4,0,1]  R567      -0.791696310043335
    z[4,0,1]  R568      -2.2679312527179718e-01
    z[4,0,1]  R569      -2.9191309213638306e-01
    z[4,0,1]  R570      1.9605407491326332e-02
    z[4,0,1]  R571      -1.2485348433256149e-01
    z[4,0,1]  R572      1.9079299271106720e-01
    z[4,0,1]  R573      3.5919818282127380e-01
    z[4,0,1]  R574      2.1217736601829529e-01
    z[4,0,1]  R575      1.9420032203197479e-01
    z[4,0,1]  R576      2.6884013414382935e-01
    z[4,0,1]  R577      -4.5313993096351624e-01
    z[4,0,1]  R578      -3.1489136815071106e-01
    z[4,0,1]  R579      -3.5165268182754517e-01
    z[4,0,1]  R580      -2.2898840904235840e-01
    z[4,0,1]  R581      -4.1955053806304932e-02
    z[4,0,1]  R582      -1.4321479201316833e-01
    z[4,0,1]  R583      -2.4670347571372986e-01
    z[4,0,1]  R584      -0.0705266073346138
    z[4,0,1]  R585      -3.3981472253799438e-01
    z[4,0,1]  R586      -1.7385317385196686e-01
    z[4,0,1]  R587      2.9062485694885254e-01
    z[4,0,1]  R588      -7.2948127985000610e-02
    z[4,0,1]  R589      0.00988028198480606
    z[4,0,1]  R590      -3.7674322724342346e-02
    z[4,0,1]  R591      -3.2302632927894592e-02
    z[4,0,1]  R592      -2.0202779769897461e-01
    z[4,0,1]  R593      1.7496684193611145e-01
    z[4,0,1]  R594      2.7793058753013611e-01
    z[4,0,1]  R595      3.4806916117668152e-01
    z[4,0,1]  R596      2.6849013566970825e-01
    z[4,0,1]  R597      -8.3844490349292755e-02
    z[4,0,1]  R598      -9.4447515904903412e-02
    z[4,0,1]  R599      9.4490736722946167e-02
    z[4,0,1]  R600      -2.3460227251052856e-01
    z[4,0,1]  R601      -1.5209205448627472e-01
    z[4,0,1]  R602      1.8347331881523132e-01
    z[4,0,1]  R603      6.4633525907993317e-02
    z[4,0,1]  R604      4.3670570850372314e-01
    z[4,0,1]  R605      -1.0524497926235199e-01
    z[4,0,1]  R606      -5.0707951188087463e-02
    z[4,0,1]  R607      -3.4030193090438843e-01
    z[4,0,1]  R608      -2.0597891509532928e-01
    z[4,0,1]  R609      -1.4286459982395172e-01
    z[4,0,1]  R610      1.0545502603054047e-01
    z[4,0,1]  R611      1.5984825789928436e-01
    z[4,0,1]  R612      -2.7552312612533569e-01
    z[4,0,1]  R613      -2.2291575372219086e-01
    z[4,0,1]  R614      1.9611382484436035e-01
    z[4,0,1]  R615      3.6403939127922058e-01
    z[4,0,1]  R616      -2.1743577718734741e-01
    z[4,0,1]  R617      -2.6841464638710022e-01
    z[4,0,1]  R618      -0.270877480506897
    z[4,0,1]  R619      -2.9492446780204773e-01
    z[4,0,1]  R620      -1.5599857270717621e-01
    z[4,0,1]  R621      -0.0677003264427185
    z[4,0,1]  R622      -1.4299592934548855e-02
    z[4,0,1]  R623      -4.6287972480058670e-02
    z[4,0,1]  R624      -1.0172042250633240e-01
    z[4,0,1]  R625      4.3016073107719421e-01
    z[4,0,1]  R626      0.08734080940485
    z[4,0,1]  R627      -4.4155126810073853e-01
    z[4,0,1]  R628      -0.0909222811460495
    z[4,0,1]  R629      1.6748405992984772e-01
    z[4,0,1]  R630      4.7551002353429794e-02
    z[4,0,1]  R631      -3.4410160034894943e-02
    z[4,0,1]  R632      3.6228740215301514e-01
    z[4,0,1]  R633      3.5348224639892578e-01
    z[4,0,1]  R634      2.6601800322532654e-01
    z[4,0,1]  R635      2.8902328014373779e-01
    z[4,0,1]  R636      9.1782903671264648e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R519      -1
    z[4,0,2]  R520      1
    z[4,0,2]  R529      -3.3531033992767334e-01
    z[4,0,2]  R530      -4.4973435997962952e-01
    z[4,0,2]  R531      -6.0888135433197021e-01
    z[4,0,2]  R532      -5.8807331323623657e-01
    z[4,0,2]  R533      -5.0384733825922012e-02
    z[4,0,2]  R534      2.8873598575592041e-01
    z[4,0,2]  R535      3.9323827624320984e-01
    z[4,0,2]  R536      2.6337489485740662e-01
    z[4,0,2]  R537      3.6571112275123596e-01
    z[4,0,2]  R538      -2.9900306463241577e-01
    z[4,0,2]  R539      3.7387913465499878e-01
    z[4,0,2]  R540      3.2314866781234741e-01
    z[4,0,2]  R541      2.5590887665748596e-01
    z[4,0,2]  R542      5.8135926723480225e-01
    z[4,0,2]  R543      4.1173884272575378e-01
    z[4,0,2]  R544      1.9148686528205872e-01
    z[4,0,2]  R545      4.0773135423660278e-01
    z[4,0,2]  R546      5.1898753643035889e-01
    z[4,0,2]  R547      4.3880489468574524e-01
    z[4,0,2]  R548      1.0552560538053513e-01
    z[4,0,2]  R549      1.1646560579538345e-01
    z[4,0,2]  R550      4.1714864969253540e-01
    z[4,0,2]  R551      8.2238681614398956e-02
    z[4,0,2]  R552      3.9859315752983093e-01
    z[4,0,2]  R553      3.9502510428428650e-01
    z[4,0,2]  R554      5.2484279870986938e-01
    z[4,0,2]  R555      8.7059482932090759e-02
    z[4,0,2]  R556      1.9846706092357635e-01
    z[4,0,2]  R557      5.2390646934509277e-01
    z[4,0,2]  R558      4.8633712530136108e-01
    z[4,0,2]  R559      6.1409723758697510e-01
    z[4,0,2]  R560      3.5800164937973022e-01
    z[4,0,2]  R561      3.9475083351135254e-01
    z[4,0,2]  R562      6.2169307470321655e-01
    z[4,0,2]  R563      5.6073254346847534e-01
    z[4,0,2]  R564      1.9272992014884949e-01
    z[4,0,2]  R565      5.3977102041244507e-01
    z[4,0,2]  R566      0.449907124042511
    z[4,0,2]  R567      3.3825227618217468e-01
    z[4,0,2]  R568      8.3470441401004791e-02
    z[4,0,2]  R569      3.8476087152957916e-02
    z[4,0,2]  R570      1.6556492447853088e-01
    z[4,0,2]  R571      2.8725165128707886e-01
    z[4,0,2]  R572      -8.4224832057952881e-01
    z[4,0,2]  R573      -5.8925980329513550e-01
    z[4,0,2]  R574      -6.7917782068252563e-01
    z[4,0,2]  R575      -7.1529638767242432e-01
    z[4,0,2]  R576      -5.9789091348648071e-01
    z[4,0,2]  R577      2.9072910547256470e-01
    z[4,0,2]  R578      3.1898257136344910e-01
    z[4,0,2]  R579      7.5956201553344727e-01
    z[4,0,2]  R580      7.4666303396224976e-01
    z[4,0,2]  R581      0.505126416683197
    z[4,0,2]  R582      1.7032857239246368e-01
    z[4,0,2]  R583      4.6780437231063843e-01
    z[4,0,2]  R584      7.2464540600776672e-02
    z[4,0,2]  R585      6.0924118757247925e-01
    z[4,0,2]  R586      3.5284444689750671e-01
    z[4,0,2]  R587      -8.1702905893325806e-01
    z[4,0,2]  R588      5.5323904752731323e-01
    z[4,0,2]  R589      4.4137695431709290e-01
    z[4,0,2]  R590      5.7123631238937378e-01
    z[4,0,2]  R591      2.5803306698799133e-01
    z[4,0,2]  R592      6.0710644721984863e-01
    z[4,0,2]  R593      -5.4919117689132690e-01
    z[4,0,2]  R594      -0.506799042224884
    z[4,0,2]  R595      -4.6140092611312866e-01
    z[4,0,2]  R596      3.8230541348457336e-01
    z[4,0,2]  R597      1.3293799757957458e-01
    z[4,0,2]  R598      4.8885592818260193e-01
    z[4,0,2]  R599      4.8153975605964661e-01
    z[4,0,2]  R600      1.2029406428337097e-01
    z[4,0,2]  R601      6.9337779283523560e-01
    z[4,0,2]  R602      4.2525851726531982e-01
    z[4,0,2]  R603      2.5272551178932190e-01
    z[4,0,2]  R604      4.4809684157371521e-01
    z[4,0,2]  R605      7.2975230216979980e-01
    z[4,0,2]  R606      0.188186377286911
    z[4,0,2]  R607      2.5500911474227905e-01
    z[4,0,2]  R608      -8.5257776081562042e-03
    z[4,0,2]  R609      3.4689456224441528e-02
    z[4,0,2]  R610      5.5537760257720947e-01
    z[4,0,2]  R611      6.4251339435577393e-01
    z[4,0,2]  R612      6.6550296545028687e-01
    z[4,0,2]  R613      1.0407479852437973e-01
    z[4,0,2]  R614      -4.6777981519699097e-01
    z[4,0,2]  R615      -6.9043183326721191e-01
    z[4,0,2]  R616      5.1425766944885254e-01
    z[4,0,2]  R617      3.2647156715393066e-01
    z[4,0,2]  R618      5.0981956720352173e-01
    z[4,0,2]  R619      7.0545291900634766e-01
    z[4,0,2]  R620      5.3512346744537354e-01
    z[4,0,2]  R621      4.9972110986709595e-01
    z[4,0,2]  R622      0.391156941652298
    z[4,0,2]  R623      3.2480636239051819e-01
    z[4,0,2]  R624      2.7096980810165405e-01
    z[4,0,2]  R625      -4.1731411218643188e-01
    z[4,0,2]  R626      -0.178622305393219
    z[4,0,2]  R627      6.4340072870254517e-01
    z[4,0,2]  R628      -3.1454391777515411e-02
    z[4,0,2]  R629      5.2287101745605469e-01
    z[4,0,2]  R630      2.2768445312976837e-01
    z[4,0,2]  R631      4.5462402701377869e-01
    z[4,0,2]  R632      -5.8153760433197021e-01
    z[4,0,2]  R633      -6.9444268941879272e-01
    z[4,0,2]  R634      -2.5282454490661621e-01
    z[4,0,2]  R635      -2.2663612663745880e-01
    z[4,0,2]  R636      1.1399599909782410e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R521      -1
    z[4,0,3]  R522      1
    z[4,0,3]  R529      -2.0572341978549957e-01
    z[4,0,3]  R530      -0.718946635723114
    z[4,0,3]  R531      -4.0803977847099304e-01
    z[4,0,3]  R532      -3.6046928167343140e-01
    z[4,0,3]  R533      0.00858311913907528
    z[4,0,3]  R534      6.1476852744817734e-02
    z[4,0,3]  R535      -1.3553509116172791e-01
    z[4,0,3]  R536      -1.1303997784852982e-01
    z[4,0,3]  R537      -3.0554416775703430e-01
    z[4,0,3]  R538      6.0953569412231445e-01
    z[4,0,3]  R539      -0.520353376865387
    z[4,0,3]  R540      6.1089444905519485e-02
    z[4,0,3]  R541      -3.4144330024719238e-01
    z[4,0,3]  R542      5.6526422500610352e-01
    z[4,0,3]  R543      1.2899178266525269e-01
    z[4,0,3]  R544      6.7346578836441040e-01
    z[4,0,3]  R545      1.6318507492542267e-02
    z[4,0,3]  R546      5.9263265132904053e-01
    z[4,0,3]  R547      4.2944005131721497e-01
    z[4,0,3]  R548      -4.1192913055419922e-01
    z[4,0,3]  R549      -7.6644122600555420e-02
    z[4,0,3]  R550      2.0884402096271515e-01
    z[4,0,3]  R551      3.2799789309501648e-01
    z[4,0,3]  R552      3.0698782205581665e-01
    z[4,0,3]  R553      4.4939696788787842e-01
    z[4,0,3]  R554      1.0506445914506912e-01
    z[4,0,3]  R555      4.7404372692108154e-01
    z[4,0,3]  R556      2.8486651182174683e-01
    z[4,0,3]  R557      4.7162207961082458e-01
    z[4,0,3]  R558      0.529949963092804
    z[4,0,3]  R559      8.8852927088737488e-02
    z[4,0,3]  R560      2.8940027952194214e-01
    z[4,0,3]  R561      -1.3750459067523479e-02
    z[4,0,3]  R562      -0.197368323802948
    z[4,0,3]  R563      -2.3361812531948090e-01
    z[4,0,3]  R564      -1.0043931752443314e-01
    z[4,0,3]  R565      -4.6339428424835205e-01
    z[4,0,3]  R566      -3.1964552402496338e-01
    z[4,0,3]  R567      -1.7776307463645935e-01
    z[4,0,3]  R568      -4.7666269540786743e-01
    z[4,0,3]  R569      -4.4922330975532532e-01
    z[4,0,3]  R570      -3.2740056514739990e-01
    z[4,0,3]  R571      -6.3198663294315338e-02
    z[4,0,3]  R572      -3.5486346483230591e-01
    z[4,0,3]  R573      -4.3319106101989746e-01
    z[4,0,3]  R574      -4.7567120194435120e-01
    z[4,0,3]  R575      -6.6029065847396851e-01
    z[4,0,3]  R576      -0.583728551864624
    z[4,0,3]  R577      -3.2236695289611816e-01
    z[4,0,3]  R578      -7.2486883401870728e-01
    z[4,0,3]  R579      -2.7400314807891846e-01
    z[4,0,3]  R580      -2.1184596419334412e-01
    z[4,0,3]  R581      -4.4912162423133850e-01
    z[4,0,3]  R582      -4.5159086585044861e-01
    z[4,0,3]  R583      1.6839260933920741e-03
    z[4,0,3]  R584      0.598764181137085
    z[4,0,3]  R585      4.4689339399337769e-01
    z[4,0,3]  R586      5.1332950592041016e-01
    z[4,0,3]  R587      -2.8303396701812744e-01
    z[4,0,3]  R588      0.466047078371048
    z[4,0,3]  R589      2.2941111028194427e-01
    z[4,0,3]  R590      0.624661386013031
    z[4,0,3]  R591      4.3578910827636719e-01
    z[4,0,3]  R592      2.3679597675800323e-01
    z[4,0,3]  R593      -5.4818040132522583e-01
    z[4,0,3]  R594      -5.4645639657974243e-01
    z[4,0,3]  R595      -3.0926057696342468e-01
    z[4,0,3]  R596      6.7048561573028564e-01
    z[4,0,3]  R597      -8.0479115247726440e-01
    z[4,0,3]  R598      6.2632894515991211e-01
    z[4,0,3]  R599      6.9283038377761841e-01
    z[4,0,3]  R600      4.7617882490158081e-02
    z[4,0,3]  R601      3.4029385447502136e-01
    z[4,0,3]  R602      7.7173836529254913e-02
    z[4,0,3]  R603      3.3433189988136292e-01
    z[4,0,3]  R604      3.0583688616752625e-01
    z[4,0,3]  R605      4.6924594044685364e-01
    z[4,0,3]  R606      1.2052089720964432e-01
    z[4,0,3]  R607      -1.3106903433799744e-01
    z[4,0,3]  R608      -1.8353970348834991e-01
    z[4,0,3]  R609      -1.2935988605022430e-01
    z[4,0,3]  R610      2.5674277544021606e-01
    z[4,0,3]  R611      3.4229108691215515e-01
    z[4,0,3]  R612      4.6737492084503174e-01
    z[4,0,3]  R613      2.9534491896629333e-01
    z[4,0,3]  R614      -5.4688894748687744e-01
    z[4,0,3]  R615      -1.1105062067508698e-01
    z[4,0,3]  R616      4.0439051389694214e-01
    z[4,0,3]  R617      0.212955504655838
    z[4,0,3]  R618      3.5166999697685242e-01
    z[4,0,3]  R619      4.3048301339149475e-01
    z[4,0,3]  R620      4.8108947277069092e-01
    z[4,0,3]  R621      3.6428511142730713e-01
    z[4,0,3]  R622      5.4846316576004028e-01
    z[4,0,3]  R623      0.813058078289032
    z[4,0,3]  R624      0.588672399520874
    z[4,0,3]  R625      5.4731898009777069e-02
    z[4,0,3]  R626      6.9241464138031006e-01
    z[4,0,3]  R627      -3.9888751506805420e-01
    z[4,0,3]  R628      -7.6385718584060669e-01
    z[4,0,3]  R629      3.9119008183479309e-01
    z[4,0,3]  R630      -1.2299574166536331e-01
    z[4,0,3]  R631      0.621128261089325
    z[4,0,3]  R632      1.0593704134225845e-01
    z[4,0,3]  R633      2.2778582572937012e-01
    z[4,0,3]  R634      0.863503098487854
    z[4,0,3]  R635      7.6651722192764282e-01
    z[4,0,3]  R636      1.5615323185920715e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R523      -1
    z[4,0,4]  R524      1
    z[4,0,4]  R529      5.1540863513946533e-01
    z[4,0,4]  R530      4.0010219812393188e-01
    z[4,0,4]  R531      5.1996868848800659e-01
    z[4,0,4]  R532      -3.3404279500246048e-02
    z[4,0,4]  R533      -6.8096712231636047e-02
    z[4,0,4]  R534      -1.3788822293281555e-01
    z[4,0,4]  R535      -2.3109939694404602e-01
    z[4,0,4]  R536      -4.7391152381896973e-01
    z[4,0,4]  R537      -3.2091453671455383e-01
    z[4,0,4]  R538      -1.4757290482521057e-01
    z[4,0,4]  R539      -3.8310667872428894e-01
    z[4,0,4]  R540      2.7381709218025208e-01
    z[4,0,4]  R541      4.2095455527305603e-01
    z[4,0,4]  R542      1.7630970105528831e-02
    z[4,0,4]  R543      3.8901785016059875e-01
    z[4,0,4]  R544      3.2643833756446838e-01
    z[4,0,4]  R545      -2.8026765584945679e-01
    z[4,0,4]  R546      1.1587437987327576e-01
    z[4,0,4]  R547      -5.0967586040496826e-01
    z[4,0,4]  R548      2.3534177243709564e-01
    z[4,0,4]  R549      1.1257145553827286e-02
    z[4,0,4]  R550      -1.5665613114833832e-01
    z[4,0,4]  R551      1.7417942872270942e-03
    z[4,0,4]  R552      -2.6921004056930542e-01
    z[4,0,4]  R553      3.3037438988685608e-02
    z[4,0,4]  R554      -3.1110098958015442e-01
    z[4,0,4]  R555      -0.0326436311006546
    z[4,0,4]  R556      3.3059865236282349e-01
    z[4,0,4]  R557      2.4304026365280151e-01
    z[4,0,4]  R558      -1.0596216470003128e-01
    z[4,0,4]  R559      -7.2717433795332909e-03
    z[4,0,4]  R560      4.3784198164939880e-01
    z[4,0,4]  R561      3.3182597160339355e-01
    z[4,0,4]  R562      -3.3863988518714905e-01
    z[4,0,4]  R563      7.8207127749919891e-02
    z[4,0,4]  R564      1.2676453590393066e-01
    z[4,0,4]  R565      0.0924171581864357
    z[4,0,4]  R566      -1.1691863834857941e-01
    z[4,0,4]  R567      -6.5099135041236877e-02
    z[4,0,4]  R568      2.9816165566444397e-01
    z[4,0,4]  R569      -4.0204051136970520e-01
    z[4,0,4]  R570      2.4161966145038605e-01
    z[4,0,4]  R571      -0.403253436088562
    z[4,0,4]  R572      -2.0957843959331512e-01
    z[4,0,4]  R573      5.3887295722961426e-01
    z[4,0,4]  R574      3.3918201923370361e-01
    z[4,0,4]  R575      9.6655443310737610e-02
    z[4,0,4]  R576      0.0228701401501894
    z[4,0,4]  R577      -5.0021409988403320e-01
    z[4,0,4]  R578      -0.421298086643219
    z[4,0,4]  R579      -2.2560994327068329e-01
    z[4,0,4]  R580      1.8830461800098419e-01
    z[4,0,4]  R581      2.6118096709251404e-01
    z[4,0,4]  R582      -9.3708731234073639e-02
    z[4,0,4]  R583      -4.7579240798950195e-01
    z[4,0,4]  R584      -1.8810595571994781e-01
    z[4,0,4]  R585      -2.3870684206485748e-01
    z[4,0,4]  R586      -3.8813826441764832e-01
    z[4,0,4]  R587      -1.7493402957916260e-01
    z[4,0,4]  R588      0.600666344165802
    z[4,0,4]  R589      5.8888554573059082e-01
    z[4,0,4]  R590      2.6410397887229919e-01
    z[4,0,4]  R591      2.0973308384418488e-01
    z[4,0,4]  R592      4.8397764563560486e-01
    z[4,0,4]  R593      1.9514480233192444e-01
    z[4,0,4]  R594      3.6094364523887634e-01
    z[4,0,4]  R595      0.411279559135437
    z[4,0,4]  R596      1.5228706598281860e-01
    z[4,0,4]  R597      1.7387558519840240e-01
    z[4,0,4]  R598      -3.7655362486839294e-01
    z[4,0,4]  R599      -3.9956696331501007e-02
    z[4,0,4]  R600      -9.3102556467056274e-01
    z[4,0,4]  R601      5.3309971094131470e-01
    z[4,0,4]  R602      -3.3064141869544983e-01
    z[4,0,4]  R603      5.1917344331741333e-01
    z[4,0,4]  R604      4.5456290245056152e-01
    z[4,0,4]  R605      3.2867538928985596e-01
    z[4,0,4]  R606      4.8040706664323807e-02
    z[4,0,4]  R607      -3.5176917910575867e-01
    z[4,0,4]  R608      -8.6738181114196777e-01
    z[4,0,4]  R609      -5.9705656766891479e-01
    z[4,0,4]  R610      2.7617081999778748e-01
    z[4,0,4]  R611      -7.1254797279834747e-02
    z[4,0,4]  R612      -1.8082691729068756e-01
    z[4,0,4]  R613      -2.3732826113700867e-01
    z[4,0,4]  R614      0.0220558512955904
    z[4,0,4]  R615      4.0378373861312866e-01
    z[4,0,4]  R616      -1.3024382293224335e-01
    z[4,0,4]  R617      -0.657317578792572
    z[4,0,4]  R618      -2.4231974780559540e-01
    z[4,0,4]  R619      -1.3833306729793549e-01
    z[4,0,4]  R620      3.9530539512634277e-01
    z[4,0,4]  R621      4.7931128740310669e-01
    z[4,0,4]  R622      2.4191793799400330e-01
    z[4,0,4]  R623      -1.6981212794780731e-01
    z[4,0,4]  R624      1.2120685726404190e-01
    z[4,0,4]  R625      1.2582322955131531e-01
    z[4,0,4]  R626      1.8317420035600662e-02
    z[4,0,4]  R627      -4.1541165113449097e-01
    z[4,0,4]  R628      0.360927551984787
    z[4,0,4]  R629      -1.6938069462776184e-01
    z[4,0,4]  R630      1.7857013642787933e-01
    z[4,0,4]  R631      1.2255582958459854e-01
    z[4,0,4]  R632      7.8928455710411072e-02
    z[4,0,4]  R633      -1.3981994986534119e-01
    z[4,0,4]  R634      0.024102833122015
    z[4,0,4]  R635      -2.0186141133308411e-01
    z[4,0,4]  R636      -1.5936891734600067e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R525      -1
    z[4,0,5]  R526      1
    z[4,0,5]  R529      3.6336949467658997e-01
    z[4,0,5]  R530      2.8015589714050293e-01
    z[4,0,5]  R531      -8.6010143160820007e-02
    z[4,0,5]  R532      3.7844744324684143e-01
    z[4,0,5]  R533      -4.9127709865570068e-01
    z[4,0,5]  R534      1.2058693170547485e-01
    z[4,0,5]  R535      3.4868514537811279e-01
    z[4,0,5]  R536      6.8540379405021667e-02
    z[4,0,5]  R537      -4.2214468121528625e-03
    z[4,0,5]  R538      8.7181003764271736e-03
    z[4,0,5]  R539      2.5557172298431396e-01
    z[4,0,5]  R540      -6.2870115041732788e-01
    z[4,0,5]  R541      -4.7782656550407410e-01
    z[4,0,5]  R542      1.2138541787862778e-01
    z[4,0,5]  R543      5.8549094200134277e-01
    z[4,0,5]  R544      9.0634517371654510e-02
    z[4,0,5]  R545      3.9740687608718872e-01
    z[4,0,5]  R546      -4.0575500577688217e-02
    z[4,0,5]  R547      -9.4991348683834076e-02
    z[4,0,5]  R548      -1.9459149241447449e-01
    z[4,0,5]  R549      -0.566662073135376
    z[4,0,5]  R550      4.3897858262062073e-01
    z[4,0,5]  R551      2.3217049241065979e-01
    z[4,0,5]  R552      6.6998794674873352e-02
    z[4,0,5]  R553      3.8771173357963562e-01
    z[4,0,5]  R554      4.6987339854240417e-02
    z[4,0,5]  R555      1.7671336233615875e-01
    z[4,0,5]  R556      5.0558310747146606e-01
    z[4,0,5]  R557      3.0969861149787903e-01
    z[4,0,5]  R558      4.0456745028495789e-01
    z[4,0,5]  R559      2.0982122421264648e-01
    z[4,0,5]  R560      -1.5313214063644409e-01
    z[4,0,5]  R561      -2.1586470305919647e-01
    z[4,0,5]  R562      -0.335225373506546
    z[4,0,5]  R563      -3.0429592728614807e-01
    z[4,0,5]  R564      -1.2198971211910248e-01
    z[4,0,5]  R565      -5.3398627787828445e-02
    z[4,0,5]  R566      -0.00661705294623971
    z[4,0,5]  R567      2.1670649945735931e-01
    z[4,0,5]  R568      3.4737229347229004e-01
    z[4,0,5]  R569      -1.8110331892967224e-01
    z[4,0,5]  R570      0.224329873919487
    z[4,0,5]  R571      0.464220255613327
    z[4,0,5]  R572      -1.5976129472255707e-01
    z[4,0,5]  R573      -1.9083958864212036e-01
    z[4,0,5]  R574      -1.5940341353416443e-01
    z[4,0,5]  R575      5.6714892387390137e-02
    z[4,0,5]  R576      -2.1884283423423767e-01
    z[4,0,5]  R577      1.9040863215923309e-01
    z[4,0,5]  R578      -3.7888143211603165e-02
    z[4,0,5]  R579      -3.0807375907897949e-01
    z[4,0,5]  R580      -5.3016918897628784e-01
    z[4,0,5]  R581      -5.2946358919143677e-01
    z[4,0,5]  R582      -8.2591062784194946e-01
    z[4,0,5]  R583      -6.7597693204879761e-01
    z[4,0,5]  R584      1.4166536927223206e-01
    z[4,0,5]  R585      3.2088515162467957e-01
    z[4,0,5]  R586      1.8555650115013123e-01
    z[4,0,5]  R587      -5.0146546214818954e-02
    z[4,0,5]  R588      0.0869283527135849
    z[4,0,5]  R589      -2.4803197383880615e-01
    z[4,0,5]  R590      -2.0745231211185455e-01
    z[4,0,5]  R591      7.8759455680847168e-01
    z[4,0,5]  R592      2.7698749303817749e-01
    z[4,0,5]  R593      -4.3448275327682495e-01
    z[4,0,5]  R594      -3.5858809947967529e-01
    z[4,0,5]  R595      3.0285245180130005e-01
    z[4,0,5]  R596      3.1407546997070312e-01
    z[4,0,5]  R597      -0.518271267414093
    z[4,0,5]  R598      8.4684297442436218e-02
    z[4,0,5]  R599      -4.5331515138968825e-04
    z[4,0,5]  R600      -1.4894120395183563e-01
    z[4,0,5]  R601      1.7933075129985809e-01
    z[4,0,5]  R602      0.670393705368042
    z[4,0,5]  R603      -1.5988458693027496e-01
    z[4,0,5]  R604      3.9508423209190369e-01
    z[4,0,5]  R605      5.3369738161563873e-02
    z[4,0,5]  R606      5.4483890533447266e-01
    z[4,0,5]  R607      -5.0387692451477051e-01
    z[4,0,5]  R608      -4.1310015320777893e-01
    z[4,0,5]  R609      3.1898081302642822e-01
    z[4,0,5]  R610      3.2117792963981628e-01
    z[4,0,5]  R611      -1.3050472736358643e-01
    z[4,0,5]  R612      1.7264391481876373e-01
    z[4,0,5]  R613      2.4910381436347961e-01
    z[4,0,5]  R614      -1.1318525671958923e-01
    z[4,0,5]  R615      -2.8795739635825157e-02
    z[4,0,5]  R616      -3.4137246012687683e-01
    z[4,0,5]  R617      -2.6963651180267334e-01
    z[4,0,5]  R618      1.5881730616092682e-01
    z[4,0,5]  R619      6.1862353235483170e-02
    z[4,0,5]  R620      1.2337491661310196e-01
    z[4,0,5]  R621      2.6799678802490234e-01
    z[4,0,5]  R622      -2.2233279049396515e-01
    z[4,0,5]  R623      4.3911975622177124e-01
    z[4,0,5]  R624      7.2828143835067749e-01
    z[4,0,5]  R625      -5.4702842235565186e-01
    z[4,0,5]  R626      -2.8476619720458984e-01
    z[4,0,5]  R627      -1.3484671711921692e-01
    z[4,0,5]  R628      9.6714220941066742e-02
    z[4,0,5]  R629      3.2574611902236938e-01
    z[4,0,5]  R630      -4.5938301086425781e-01
    z[4,0,5]  R631      5.5679249763488770e-01
    z[4,0,5]  R632      -4.8105788230895996e-01
    z[4,0,5]  R633      -1.5010836720466614e-01
    z[4,0,5]  R634      -2.2828640043735504e-01
    z[4,0,5]  R635      -3.7901112437248230e-01
    z[4,0,5]  R636      1.2325149029493332e-02
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R527      -1
    z[4,0,6]  R528      1
    z[4,0,6]  R529      -6.5017372369766235e-01
    z[4,0,6]  R530      0.0619877427816391
    z[4,0,6]  R531      4.0417158603668213e-01
    z[4,0,6]  R532      5.1775211095809937e-01
    z[4,0,6]  R533      -0.0470924936234951
    z[4,0,6]  R534      3.0986329913139343e-01
    z[4,0,6]  R535      -2.8853079676628113e-01
    z[4,0,6]  R536      1.7710734903812408e-01
    z[4,0,6]  R537      5.1792579889297485e-01
    z[4,0,6]  R538      8.7738549336791039e-03
    z[4,0,6]  R539      -0.210055410861969
    z[4,0,6]  R540      -3.8047656416893005e-01
    z[4,0,6]  R541      -2.8715729713439941e-02
    z[4,0,6]  R542      -0.19149149954319
    z[4,0,6]  R543      1.5574800968170166e-01
    z[4,0,6]  R544      1.0477259755134583e-01
    z[4,0,6]  R545      4.8497340083122253e-01
    z[4,0,6]  R546      4.4440111517906189e-01
    z[4,0,6]  R547      -6.6356673836708069e-02
    z[4,0,6]  R548      4.7136954963207245e-02
    z[4,0,6]  R549      -2.0768925547599792e-01
    z[4,0,6]  R550      -6.6673986613750458e-02
    z[4,0,6]  R551      2.5562450289726257e-01
    z[4,0,6]  R552      4.5592587441205978e-02
    z[4,0,6]  R553      3.5747972130775452e-01
    z[4,0,6]  R554      9.3551538884639740e-02
    z[4,0,6]  R555      3.1063543632626534e-02
    z[4,0,6]  R556      1.6130568087100983e-01
    z[4,0,6]  R557      4.4554957747459412e-01
    z[4,0,6]  R558      2.8060135245323181e-01
    z[4,0,6]  R559      3.0970117449760437e-01
    z[4,0,6]  R560      -1.9239617511630058e-02
    z[4,0,6]  R561      2.5689511094242334e-03
    z[4,0,6]  R562      1.5902109444141388e-01
    z[4,0,6]  R563      -1.1570470035076141e-01
    z[4,0,6]  R564      3.7005368620157242e-02
    z[4,0,6]  R565      -2.6223507523536682e-01
    z[4,0,6]  R566      2.4169474840164185e-01
    z[4,0,6]  R567      7.6468706130981445e-02
    z[4,0,6]  R568      2.7836680412292480e-01
    z[4,0,6]  R569      1.0631252825260162e-01
    z[4,0,6]  R570      -6.9550549983978271e-01
    z[4,0,6]  R571      -7.1833074092864990e-01
    z[4,0,6]  R572      2.4240817129611969e-01
    z[4,0,6]  R573      -0.0881536602973938
    z[4,0,6]  R574      3.4985548257827759e-01
    z[4,0,6]  R575      -1.0338597930967808e-02
    z[4,0,6]  R576      -4.1892459988594055e-01
    z[4,0,6]  R577      5.4640448093414307e-01
    z[4,0,6]  R578      -9.9875830113887787e-02
    z[4,0,6]  R579      -2.3135414719581604e-01
    z[4,0,6]  R580      4.5691672712564468e-02
    z[4,0,6]  R581      -4.1924589872360229e-01
    z[4,0,6]  R582      2.2850631177425385e-01
    z[4,0,6]  R583      0.0985293835401535
    z[4,0,6]  R584      -2.0890440791845322e-02
    z[4,0,6]  R585      8.8022947311401367e-02
    z[4,0,6]  R586      -2.8565886616706848e-01
    z[4,0,6]  R587      -0.000894435215741396
    z[4,0,6]  R588      1.9662292301654816e-01
    z[4,0,6]  R589      -1.2804168462753296e-01
    z[4,0,6]  R590      -1.4602464437484741e-01
    z[4,0,6]  R591      -2.1753750741481781e-01
    z[4,0,6]  R592      4.6383023262023926e-01
    z[4,0,6]  R593      3.2361376285552979e-01
    z[4,0,6]  R594      0.0416349358856678
    z[4,0,6]  R595      -3.6701294779777527e-01
    z[4,0,6]  R596      4.5281535387039185e-01
    z[4,0,6]  R597      3.5848800092935562e-02
    z[4,0,6]  R598      -1.5062198042869568e-01
    z[4,0,6]  R599      3.4915685653686523e-01
    z[4,0,6]  R600      -1.8617257475852966e-01
    z[4,0,6]  R601      7.5459092855453491e-02
    z[4,0,6]  R602      -7.4120283126831055e-02
    z[4,0,6]  R603      4.5800793170928955e-01
    z[4,0,6]  R604      -2.8293453156948090e-02
    z[4,0,6]  R605      -2.4852499365806580e-01
    z[4,0,6]  R606      -5.2257311344146729e-01
    z[4,0,6]  R607      6.1016047000885010e-01
    z[4,0,6]  R608      -1.5936326235532761e-02
    z[4,0,6]  R609      -0.573460042476654
    z[4,0,6]  R610      6.9207169115543365e-02
    z[4,0,6]  R611      1.5735353529453278e-01
    z[4,0,6]  R612      -1.4017136394977570e-01
    z[4,0,6]  R613      1.7868627607822418e-01
    z[4,0,6]  R614      -2.4157559499144554e-02
    z[4,0,6]  R615      2.4473662674427032e-01
    z[4,0,6]  R616      4.2823340743780136e-02
    z[4,0,6]  R617      -1.2539999186992645e-01
    z[4,0,6]  R618      -1.5164235234260559e-01
    z[4,0,6]  R619      8.1238850951194763e-02
    z[4,0,6]  R620      2.2748689353466034e-01
    z[4,0,6]  R621      -1.6115474700927734e-01
    z[4,0,6]  R622      -1.3305296003818512e-01
    z[4,0,6]  R623      0.0618111714720726
    z[4,0,6]  R624      1.4893175661563873e-01
    z[4,0,6]  R625      -4.2725256085395813e-01
    z[4,0,6]  R626      6.3160061836242676e-01
    z[4,0,6]  R627      1.0554412007331848e-01
    z[4,0,6]  R628      -3.9614457637071609e-02
    z[4,0,6]  R629      5.1047289371490479e-01
    z[4,0,6]  R630      -0.548608660697937
    z[4,0,6]  R631      -0.235431969165802
    z[4,0,6]  R632      1.4751152694225311e-01
    z[4,0,6]  R633      8.2095600664615631e-02
    z[4,0,6]  R634      2.0003418624401093e-01
    z[4,0,6]  R635      -2.9601639509201050e-01
    z[4,0,6]  R636      1.4422810636460781e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R721      -1
    z[1,2,0]  R722      1
    z[1,2,0]  R735      1.2190082669258118e-01
    z[1,2,0]  R736      8.7008059024810791e-02
    z[1,2,0]  R737      3.0221480131149292e-01
    z[1,2,0]  R738      2.6016193628311157e-01
    z[1,2,0]  R739      2.4748301506042480e-01
    z[1,2,0]  R740      7.8136193752288818e-01
    z[1,2,0]  R741      4.5540583133697510e-01
    z[1,2,0]  R742      -0.0655539408326149
    z[1,2,0]  R743      -9.9040046334266663e-02
    z[1,2,0]  R744      1.5701797604560852e-01
    z[1,2,0]  R745      4.4143640995025635e-01
    z[1,2,0]  R746      3.5963547229766846e-01
    z[1,2,0]  R747      -2.4248990416526794e-01
    z[1,2,0]  R748      1.7267766594886780e-01
    z[1,2,0]  R749      -8.9693062007427216e-02
    z[1,2,0]  R750      2.3396338522434235e-01
    z[1,2,0]  R751      -1.8763886392116547e-01
    z[1,2,0]  R752      6.3462473452091217e-02
    z[1,2,0]  R753      5.1345992088317871e-01
    z[1,2,0]  R754      -2.9811403155326843e-01
    z[1,2,0]  R755      0.645882785320282
    z[1,2,0]  R756      6.6964232921600342e-01
    z[1,2,0]  R757      3.2339587807655334e-01
    z[1,2,0]  R758      0.0756298080086708
    z[1,2,0]  R759      1.8386992812156677e-01
    z[1,2,0]  R760      2.7939921617507935e-01
    z[1,2,0]  R761      2.6959127187728882e-01
    z[1,2,0]  R762      5.9965625405311584e-02
    z[1,2,0]  R763      3.8612468633800745e-03
    z[1,2,0]  R764      -3.8516032695770264e-01
    z[1,2,0]  R765      2.8719830513000488e-01
    z[1,2,0]  R766      -1.0021450370550156e-01
    z[1,2,0]  R767      -1.3037898577749729e-02
    z[1,2,0]  R768      2.0253281295299530e-01
    z[1,2,0]  R769      1.2343436479568481e-01
    z[1,2,0]  R770      1.8908047676086426e-01
    z[1,2,0]  R771      -3.3509114384651184e-01
    z[1,2,0]  R772      -2.0382659137248993e-01
    z[1,2,0]  R773      7.2123610973358154e-01
    z[1,2,0]  R774      2.8315272927284241e-01
    z[1,2,0]  R775      2.6582491397857666e-01
    z[1,2,0]  R776      -1.4259302616119385e-01
    z[1,2,0]  R777      1.0283294320106506e-01
    z[1,2,0]  R778      3.0567729473114014e-01
    z[1,2,0]  R779      1.2950356304645538e-01
    z[1,2,0]  R780      2.6565348729491234e-02
    z[1,2,0]  R781      -8.7781930342316628e-03
    z[1,2,0]  R782      -9.1276951134204865e-02
    z[1,2,0]  R783      5.2722871303558350e-01
    z[1,2,0]  R784      1.9307661568745971e-04
    z[1,2,0]  R785      7.6995693147182465e-02
    z[1,2,0]  R786      -1.2734183669090271e-01
    z[1,2,0]  R787      3.3917301893234253e-01
    z[1,2,0]  R788      2.6374366134405136e-02
    z[1,2,0]  R789      8.2131153345108032e-01
    z[1,2,0]  R790      4.5522559434175491e-02
    z[1,2,0]  R791      2.7312453836202621e-02
    z[1,2,0]  R792      -1.0336112976074219e-01
    z[1,2,0]  R793      -3.2615110278129578e-01
    z[1,2,0]  R794      -3.4594023227691650e-01
    z[1,2,0]  R795      2.8148117661476135e-01
    z[1,2,0]  R796      3.4922760725021362e-01
    z[1,2,0]  R797      3.0996146798133850e-01
    z[1,2,0]  R798      1.2708684802055359e-01
    z[1,2,0]  R799      1.3786189258098602e-01
    z[1,2,0]  R800      3.7735259532928467e-01
    z[1,2,0]  R801      2.9833212494850159e-01
    z[1,2,0]  R802      -1.2803736329078674e-01
    z[1,2,0]  R803      -1.1106203496456146e-01
    z[1,2,0]  R804      2.8687962330877781e-03
    z[1,2,0]  R805      2.8190642595291138e-01
    z[1,2,0]  R806      3.4562137722969055e-01
    z[1,2,0]  R807      -2.3160532116889954e-02
    z[1,2,0]  R808      -1.2331695854663849e-01
    z[1,2,0]  R809      3.4004177898168564e-02
    z[1,2,0]  R810      -4.1489630937576294e-01
    z[1,2,0]  R811      -2.6557642221450806e-01
    z[1,2,0]  R812      -1.1845907568931580e-01
    z[1,2,0]  R813      -1.9464151561260223e-01
    z[1,2,0]  R814      2.8730336576700211e-02
    z[1,2,0]  R815      -7.6891683042049408e-02
    z[1,2,0]  R816      9.7774147987365723e-02
    z[1,2,0]  R817      -1.1200371384620667e-01
    z[1,2,0]  R818      -1.0103247128427029e-02
    z[1,2,0]  R819      1.8761040270328522e-01
    z[1,2,0]  R820      -1.8172055482864380e-01
    z[1,2,0]  R821      1.5545558929443359e-01
    z[1,2,0]  R822      1.4082913100719452e-01
    z[1,2,0]  R823      3.0249828100204468e-01
    z[1,2,0]  R824      1.1991544812917709e-01
    z[1,2,0]  R825      -1.2291748821735382e-01
    z[1,2,0]  R826      2.8967265039682388e-02
    z[1,2,0]  R827      -0.0217283982783556
    z[1,2,0]  R828      -1.7278583347797394e-01
    z[1,2,0]  R829      -2.3908168077468872e-02
    z[1,2,0]  R830      -8.7013579905033112e-02
    z[1,2,0]  R831      0.06809101998806
    z[1,2,0]  R832      -1.0040861368179321e-01
    z[1,2,0]  R833      -6.5120466053485870e-02
    z[1,2,0]  R834      1.5014787018299103e-01
    z[1,2,0]  R835      -6.3791498541831970e-02
    z[1,2,0]  R836      1.9312863051891327e-01
    z[1,2,0]  R837      -2.5318851694464684e-02
    z[1,2,0]  R838      2.2771932184696198e-02
    z[1,2,0]  R839      -3.4576624631881714e-02
    z[1,2,0]  R840      -9.8926816135644913e-03
    z[1,2,0]  R841      -1.0351626574993134e-01
    z[1,2,0]  R842      1.6009204089641571e-01
    z[1,2,0]  R843      3.1615566462278366e-02
    z[1,2,0]  R844      -1.4451977610588074e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R723      -1
    z[1,2,1]  R724      1
    z[1,2,1]  R735      -1.6991697251796722e-01
    z[1,2,1]  R736      -1.2021198123693466e-01
    z[1,2,1]  R737      5.0322914123535156e-01
    z[1,2,1]  R738      4.2183393239974976e-01
    z[1,2,1]  R739      4.2930355668067932e-01
    z[1,2,1]  R740      1.9643928110599518e-01
    z[1,2,1]  R741      7.2861391305923462e-01
    z[1,2,1]  R742      7.2586512565612793e-01
    z[1,2,1]  R743      6.2076145410537720e-01
    z[1,2,1]  R744      5.3477644920349121e-01
    z[1,2,1]  R745      -5.7719420641660690e-02
    z[1,2,1]  R746      4.3008357286453247e-01
    z[1,2,1]  R747      7.1668881177902222e-01
    z[1,2,1]  R748      -0.883419394493103
    z[1,2,1]  R749      3.3213075995445251e-01
    z[1,2,1]  R750      6.6292655467987061e-01
    z[1,2,1]  R751      7.8095215559005737e-01
    z[1,2,1]  R752      5.9684544801712036e-01
    z[1,2,1]  R753      4.7032064199447632e-01
    z[1,2,1]  R754      3.3033528923988342e-01
    z[1,2,1]  R755      -1.8666094541549683e-01
    z[1,2,1]  R756      4.6317240595817566e-01
    z[1,2,1]  R757      -1.3988637924194336e-01
    z[1,2,1]  R758      5.5366027355194092e-01
    z[1,2,1]  R759      2.9774689674377441e-01
    z[1,2,1]  R760      5.5339790880680084e-02
    z[1,2,1]  R761      -5.6207644939422607e-01
    z[1,2,1]  R762      1.1363073438405991e-01
    z[1,2,1]  R763      5.7327234745025635e-01
    z[1,2,1]  R764      8.8000553846359253e-01
    z[1,2,1]  R765      8.5935018956661224e-02
    z[1,2,1]  R766      1.2243407964706421e-01
    z[1,2,1]  R767      1.2666161358356476e-01
    z[1,2,1]  R768      -1.5021903812885284e-01
    z[1,2,1]  R769      2.1114858984947205e-01
    z[1,2,1]  R770      -4.9134314060211182e-01
    z[1,2,1]  R771      3.0135393142700195e-01
    z[1,2,1]  R772      4.8563334345817566e-01
    z[1,2,1]  R773      -0.431154727935791
    z[1,2,1]  R774      3.3930018544197083e-01
    z[1,2,1]  R775      -5.1909035444259644e-01
    z[1,2,1]  R776      -8.2570560276508331e-02
    z[1,2,1]  R777      0.361701637506485
    z[1,2,1]  R778      2.4564903974533081e-01
    z[1,2,1]  R779      2.9356616735458374e-01
    z[1,2,1]  R780      1.5386205911636353e-01
    z[1,2,1]  R781      -5.1868957281112671e-01
    z[1,2,1]  R782      8.2093916833400726e-02
    z[1,2,1]  R783      -4.4982436299324036e-01
    z[1,2,1]  R784      3.2640573382377625e-01
    z[1,2,1]  R785      4.1391676664352417e-01
    z[1,2,1]  R786      -2.6323437690734863e-01
    z[1,2,1]  R787      -1.6353602707386017e-01
    z[1,2,1]  R788      -8.1723339855670929e-02
    z[1,2,1]  R789      5.5401228368282318e-02
    z[1,2,1]  R790      -1.9173620641231537e-01
    z[1,2,1]  R791      -5.3725861012935638e-02
    z[1,2,1]  R792      6.6931024193763733e-02
    z[1,2,1]  R793      7.4424481391906738e-01
    z[1,2,1]  R794      6.7177957296371460e-01
    z[1,2,1]  R795      4.7372713685035706e-01
    z[1,2,1]  R796      -1.3733093440532684e-01
    z[1,2,1]  R797      -5.6713593006134033e-01
    z[1,2,1]  R798      5.3955519199371338e-01
    z[1,2,1]  R799      7.9679578542709351e-02
    z[1,2,1]  R800      -2.2865033149719238e-01
    z[1,2,1]  R801      4.1618752479553223e-01
    z[1,2,1]  R802      4.9980757758021355e-03
    z[1,2,1]  R803      0.787831723690033
    z[1,2,1]  R804      7.3669201135635376e-01
    z[1,2,1]  R805      -3.4342417120933533e-01
    z[1,2,1]  R806      5.0888639688491821e-01
    z[1,2,1]  R807      -1.3661010563373566e-01
    z[1,2,1]  R808      -4.2335250973701477e-01
    z[1,2,1]  R809      7.9447090625762939e-01
    z[1,2,1]  R810      6.1699497699737549e-01
    z[1,2,1]  R811      6.7754375934600830e-01
    z[1,2,1]  R812      -7.0698434114456177e-01
    z[1,2,1]  R813      -6.3214230537414551e-01
    z[1,2,1]  R814      -7.0445472002029419e-01
    z[1,2,1]  R815      -5.5581796169281006e-01
    z[1,2,1]  R816      -4.0392491221427917e-01
    z[1,2,1]  R817      -0.71854567527771
    z[1,2,1]  R818      -7.7100795507431030e-01
    z[1,2,1]  R819      -9.0539109706878662e-01
    z[1,2,1]  R820      -0.53448086977005
    z[1,2,1]  R821      -4.0648657083511353e-01
    z[1,2,1]  R822      -6.4921647310256958e-01
    z[1,2,1]  R823      -4.3055734038352966e-01
    z[1,2,1]  R824      -4.0923115611076355e-01
    z[1,2,1]  R825      0.808269202709198
    z[1,2,1]  R826      0.915841817855835
    z[1,2,1]  R827      8.5408157110214233e-01
    z[1,2,1]  R828      8.2139098644256592e-01
    z[1,2,1]  R829      6.9976997375488281e-01
    z[1,2,1]  R830      8.7637430429458618e-01
    z[1,2,1]  R831      7.0686239004135132e-01
    z[1,2,1]  R832      7.2135227918624878e-01
    z[1,2,1]  R833      8.4297072887420654e-01
    z[1,2,1]  R834      5.6277406215667725e-01
    z[1,2,1]  R835      8.6787194013595581e-01
    z[1,2,1]  R836      0.759022057056427
    z[1,2,1]  R837      3.3177286386489868e-01
    z[1,2,1]  R838      2.6639896631240845e-01
    z[1,2,1]  R839      5.8427613973617554e-01
    z[1,2,1]  R840      3.9753732085227966e-01
    z[1,2,1]  R841      6.0654246807098389e-01
    z[1,2,1]  R842      0.597892701625824
    z[1,2,1]  R843      5.7512110471725464e-01
    z[1,2,1]  R844      6.0753285884857178e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R725      -1
    z[1,2,2]  R726      1
    z[1,2,2]  R735      5.9869188070297241e-01
    z[1,2,2]  R736      2.9843065142631531e-01
    z[1,2,2]  R737      2.6460850238800049e-01
    z[1,2,2]  R738      3.4760057926177979e-02
    z[1,2,2]  R739      3.0230289697647095e-01
    z[1,2,2]  R740      -2.0901657640933990e-01
    z[1,2,2]  R741      1.1959838122129440e-01
    z[1,2,2]  R742      6.6681647300720215e-01
    z[1,2,2]  R743      -4.3016105890274048e-01
    z[1,2,2]  R744      -6.4490920305252075e-01
    z[1,2,2]  R745      2.7831861376762390e-01
    z[1,2,2]  R746      3.2640692591667175e-01
    z[1,2,2]  R747      -2.5030997395515442e-01
    z[1,2,2]  R748      2.2311314940452576e-01
    z[1,2,2]  R749      3.3854430913925171e-01
    z[1,2,2]  R750      2.9363412410020828e-02
    z[1,2,2]  R751      -1.3518701493740082e-01
    z[1,2,2]  R752      -3.1465950608253479e-01
    z[1,2,2]  R753      -3.4053522348403931e-01
    z[1,2,2]  R754      3.8307452201843262e-01
    z[1,2,2]  R755      1.5904194116592407e-01
    z[1,2,2]  R756      4.5045712590217590e-01
    z[1,2,2]  R757      -3.6079365015029907e-01
    z[1,2,2]  R758      5.9527742862701416e-01
    z[1,2,2]  R759      6.1822026968002319e-01
    z[1,2,2]  R760      4.3528366088867188e-01
    z[1,2,2]  R761      -1.3250146806240082e-01
    z[1,2,2]  R762      7.8870460391044617e-02
    z[1,2,2]  R763      -2.5467187166213989e-02
    z[1,2,2]  R764      -7.9486265778541565e-02
    z[1,2,2]  R765      7.1662414073944092e-01
    z[1,2,2]  R766      6.2009769678115845e-01
    z[1,2,2]  R767      6.6452652215957642e-01
    z[1,2,2]  R768      8.1538534164428711e-01
    z[1,2,2]  R769      1.4778582751750946e-01
    z[1,2,2]  R770      1.0131459683179855e-01
    z[1,2,2]  R771      0.688653290271759
    z[1,2,2]  R772      5.4570317268371582e-01
    z[1,2,2]  R773      -9.4202525913715363e-02
    z[1,2,2]  R774      -5.0470698624849319e-02
    z[1,2,2]  R775      4.8978269100189209e-01
    z[1,2,2]  R776      8.9249360561370850e-01
    z[1,2,2]  R777      1.2544372677803040e-01
    z[1,2,2]  R778      3.1213113665580750e-01
    z[1,2,2]  R779      -2.7585986256599426e-01
    z[1,2,2]  R780      -3.1035137176513672e-01
    z[1,2,2]  R781      -4.3089857697486877e-01
    z[1,2,2]  R782      -1.1614146083593369e-01
    z[1,2,2]  R783      -5.8289320440962911e-04
    z[1,2,2]  R784      -2.4012021720409393e-01
    z[1,2,2]  R785      4.1218116879463196e-01
    z[1,2,2]  R786      -3.3402808010578156e-02
    z[1,2,2]  R787      -1.1080418527126312e-01
    z[1,2,2]  R788      2.7810338139533997e-01
    z[1,2,2]  R789      1.9780190289020538e-01
    z[1,2,2]  R790      -3.7223607301712036e-01
    z[1,2,2]  R791      1.3389432430267334e-01
    z[1,2,2]  R792      -1.4040251076221466e-01
    z[1,2,2]  R793      -4.5583599805831909e-01
    z[1,2,2]  R794      -5.4609888792037964e-01
    z[1,2,2]  R795      4.7746098041534424e-01
    z[1,2,2]  R796      7.1907371282577515e-01
    z[1,2,2]  R797      4.9191007018089294e-01
    z[1,2,2]  R798      7.5943440198898315e-01
    z[1,2,2]  R799      6.0824835300445557e-01
    z[1,2,2]  R800      3.2030174136161804e-01
    z[1,2,2]  R801      6.9243609905242920e-01
    z[1,2,2]  R802      -0.016898138448596
    z[1,2,2]  R803      -3.6733978986740112e-01
    z[1,2,2]  R804      -2.9070207476615906e-01
    z[1,2,2]  R805      5.8625358343124390e-01
    z[1,2,2]  R806      0.732223391532898
    z[1,2,2]  R807      -9.6521571278572083e-02
    z[1,2,2]  R808      -1.9231060519814491e-02
    z[1,2,2]  R809      -0.481898695230484
    z[1,2,2]  R810      -3.1801348924636841e-01
    z[1,2,2]  R811      -1.2653756141662598e-01
    z[1,2,2]  R812      -1.1570768803358078e-01
    z[1,2,2]  R813      -2.9008877277374268e-01
    z[1,2,2]  R814      -4.9061864614486694e-01
    z[1,2,2]  R815      -3.6512367427349091e-02
    z[1,2,2]  R816      -2.8309595584869385e-01
    z[1,2,2]  R817      4.8948526382446289e-01
    z[1,2,2]  R818      -6.1697751283645630e-02
    z[1,2,2]  R819      -7.4687354266643524e-02
    z[1,2,2]  R820      2.9746848344802856e-01
    z[1,2,2]  R821      -0.0318966880440712
    z[1,2,2]  R822      -4.6656516194343567e-01
    z[1,2,2]  R823      -2.1023957431316376e-01
    z[1,2,2]  R824      1.2792116403579712e-01
    z[1,2,2]  R825      4.3497156351804733e-02
    z[1,2,2]  R826      -2.8441622853279114e-01
    z[1,2,2]  R827      -2.7528798580169678e-01
    z[1,2,2]  R828      2.6707369089126587e-01
    z[1,2,2]  R829      -3.1428366899490356e-01
    z[1,2,2]  R830      1.5977898240089417e-01
    z[1,2,2]  R831      4.0474005043506622e-02
    z[1,2,2]  R832      9.6002802252769470e-02
    z[1,2,2]  R833      -3.2728922367095947e-01
    z[1,2,2]  R834      -2.9421791434288025e-01
    z[1,2,2]  R835      8.5515398532152176e-03
    z[1,2,2]  R836      -4.5370987057685852e-01
    z[1,2,2]  R837      2.7419024705886841e-01
    z[1,2,2]  R838      3.0780667066574097e-01
    z[1,2,2]  R839      6.1520017683506012e-02
    z[1,2,2]  R840      -0.297622412443161
    z[1,2,2]  R841      -4.1597130894660950e-01
    z[1,2,2]  R842      -1.5419314801692963e-01
    z[1,2,2]  R843      3.0139547586441040e-01
    z[1,2,2]  R844      -9.3728266656398773e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R727      -1
    z[1,2,3]  R728      1
    z[1,2,3]  R735      -2.0467333495616913e-01
    z[1,2,3]  R736      -1.1645700782537460e-01
    z[1,2,3]  R737      -5.9696710109710693e-01
    z[1,2,3]  R738      -4.8272362351417542e-01
    z[1,2,3]  R739      -3.1169405579566956e-01
    z[1,2,3]  R740      -2.3703196644783020e-01
    z[1,2,3]  R741      2.1501252427697182e-02
    z[1,2,3]  R742      -1.0696186125278473e-01
    z[1,2,3]  R743      1.3313871622085571e-01
    z[1,2,3]  R744      -9.0374141931533813e-02
    z[1,2,3]  R745      6.6211920976638794e-01
    z[1,2,3]  R746      6.6893637180328369e-01
    z[1,2,3]  R747      1.3354264199733734e-01
    z[1,2,3]  R748      -2.5457942485809326e-01
    z[1,2,3]  R749      4.3280407786369324e-01
    z[1,2,3]  R750      4.4959440827369690e-01
    z[1,2,3]  R751      3.7001997232437134e-01
    z[1,2,3]  R752      1.1925332993268967e-01
    z[1,2,3]  R753      5.7252246141433716e-01
    z[1,2,3]  R754      6.6730004549026489e-01
    z[1,2,3]  R755      -2.0880065858364105e-01
    z[1,2,3]  R756      0.145756796002388
    z[1,2,3]  R757      5.6535619497299194e-01
    z[1,2,3]  R758      1.3385847210884094e-01
    z[1,2,3]  R759      3.8668472319841385e-02
    z[1,2,3]  R760      -8.6569473147392273e-02
    z[1,2,3]  R761      4.1128662228584290e-01
    z[1,2,3]  R762      0.780555784702301
    z[1,2,3]  R763      5.4355055093765259e-01
    z[1,2,3]  R764      1.0336114466190338e-01
    z[1,2,3]  R765      -5.1157391071319580e-01
    z[1,2,3]  R766      -6.9933813810348511e-01
    z[1,2,3]  R767      -3.5331344604492188e-01
    z[1,2,3]  R768      9.6488796174526215e-02
    z[1,2,3]  R769      7.0612180233001709e-01
    z[1,2,3]  R770      7.0649206638336182e-01
    z[1,2,3]  R771      3.6217209696769714e-01
    z[1,2,3]  R772      3.6982360482215881e-01
    z[1,2,3]  R773      4.9719414114952087e-01
    z[1,2,3]  R774      7.3084467649459839e-01
    z[1,2,3]  R775      1.0725892148911953e-02
    z[1,2,3]  R776      2.5985460728406906e-02
    z[1,2,3]  R777      8.8379764556884766e-01
    z[1,2,3]  R778      4.0583640336990356e-01
    z[1,2,3]  R779      7.6214724779129028e-01
    z[1,2,3]  R780      6.1278021335601807e-01
    z[1,2,3]  R781      5.9152060747146606e-01
    z[1,2,3]  R782      0.557911217212677
    z[1,2,3]  R783      0.557619571685791
    z[1,2,3]  R784      5.5516934394836426e-01
    z[1,2,3]  R785      -3.0751907825469971e-01
    z[1,2,3]  R786      8.1406724452972412e-01
    z[1,2,3]  R787      0.834414541721344
    z[1,2,3]  R788      7.9402446746826172e-01
    z[1,2,3]  R789      1.5916527807712555e-01
    z[1,2,3]  R790      7.1639132499694824e-01
    z[1,2,3]  R791      6.7942863702774048e-01
    z[1,2,3]  R792      5.9608709812164307e-01
    z[1,2,3]  R793      2.4663527309894562e-01
    z[1,2,3]  R794      -1.5179876983165741e-01
    z[1,2,3]  R795      -0.399173766374588
    z[1,2,3]  R796      1.4233709871768951e-01
    z[1,2,3]  R797      1.9738802686333656e-02
    z[1,2,3]  R798      3.9049752056598663e-02
    z[1,2,3]  R799      1.8538008630275726e-01
    z[1,2,3]  R800      -3.6137807369232178e-01
    z[1,2,3]  R801      4.7713780403137207e-01
    z[1,2,3]  R802      6.3309156894683838e-01
    z[1,2,3]  R803      -8.0035179853439331e-02
    z[1,2,3]  R804      -1.6489619016647339e-01
    z[1,2,3]  R805      -5.2144950628280640e-01
    z[1,2,3]  R806      -1.9632993265986443e-02
    z[1,2,3]  R807      8.7787830829620361e-01
    z[1,2,3]  R808      0.608786940574646
    z[1,2,3]  R809      6.7621201276779175e-02
    z[1,2,3]  R810      -4.9428176134824753e-02
    z[1,2,3]  R811      -0.13033527135849
    z[1,2,3]  R812      -3.5813841223716736e-01
    z[1,2,3]  R813      -4.6140113472938538e-01
    z[1,2,3]  R814      -2.6908096671104431e-01
    z[1,2,3]  R815      -5.7133636437356472e-03
    z[1,2,3]  R816      6.0302615165710449e-02
    z[1,2,3]  R817      4.3359076976776123e-01
    z[1,2,3]  R818      4.4179043173789978e-01
    z[1,2,3]  R819      -2.4320727214217186e-02
    z[1,2,3]  R820      -1.8579587340354919e-01
    z[1,2,3]  R821      1.1626062542200089e-01
    z[1,2,3]  R822      5.6650150567293167e-02
    z[1,2,3]  R823      2.9676252603530884e-01
    z[1,2,3]  R824      -5.9717226773500443e-02
    z[1,2,3]  R825      3.2643941044807434e-01
    z[1,2,3]  R826      1.9942989945411682e-01
    z[1,2,3]  R827      -1.4164198935031891e-01
    z[1,2,3]  R828      -6.9845512509346008e-02
    z[1,2,3]  R829      1.9365318119525909e-01
    z[1,2,3]  R830      3.1281337141990662e-01
    z[1,2,3]  R831      1.5215082466602325e-01
    z[1,2,3]  R832      3.1471386551856995e-01
    z[1,2,3]  R833      -2.0695790648460388e-01
    z[1,2,3]  R834      -1.8547067046165466e-01
    z[1,2,3]  R835      -3.7688681483268738e-01
    z[1,2,3]  R836      -1.6205094754695892e-02
    z[1,2,3]  R837      6.4295977354049683e-01
    z[1,2,3]  R838      7.9940801858901978e-01
    z[1,2,3]  R839      5.2079373598098755e-01
    z[1,2,3]  R840      7.0280265808105469e-01
    z[1,2,3]  R841      -4.1959017515182495e-01
    z[1,2,3]  R842      6.6072773933410645e-01
    z[1,2,3]  R843      -1.7309138178825378e-01
    z[1,2,3]  R844      3.5341003537178040e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R729      -1
    z[1,2,4]  R730      1
    z[1,2,4]  R735      -4.6744459867477417e-01
    z[1,2,4]  R736      -7.1737915277481079e-01
    z[1,2,4]  R737      2.9983532428741455e-01
    z[1,2,4]  R738      -1.6825450956821442e-01
    z[1,2,4]  R739      -7.1868272498250008e-03
    z[1,2,4]  R740      2.2731561958789825e-01
    z[1,2,4]  R741      -1.0865645855665207e-01
    z[1,2,4]  R742      -5.3962741047143936e-02
    z[1,2,4]  R743      -9.2491157352924347e-02
    z[1,2,4]  R744      2.4923919141292572e-01
    z[1,2,4]  R745      2.6803153753280640e-01
    z[1,2,4]  R746      1.7255203798413277e-02
    z[1,2,4]  R747      5.4292237758636475e-01
    z[1,2,4]  R748      -3.7150489515624940e-04
    z[1,2,4]  R749      -1.1027441918849945e-01
    z[1,2,4]  R750      2.9504260420799255e-01
    z[1,2,4]  R751      2.5163173675537109e-01
    z[1,2,4]  R752      0.491325318813324
    z[1,2,4]  R753      -1.8503305315971375e-01
    z[1,2,4]  R754      -3.6048030853271484e-01
    z[1,2,4]  R755      -3.8829880952835083e-01
    z[1,2,4]  R756      -1.3295862078666687e-01
    z[1,2,4]  R757      2.2157919406890869e-01
    z[1,2,4]  R758      1.8929013609886169e-01
    z[1,2,4]  R759      0.424519419670105
    z[1,2,4]  R760      4.7867378592491150e-01
    z[1,2,4]  R761      3.7761986255645752e-02
    z[1,2,4]  R762      -5.9292191267013550e-01
    z[1,2,4]  R763      4.1246834397315979e-01
    z[1,2,4]  R764      1.3459983468055725e-01
    z[1,2,4]  R765      3.4256622195243835e-01
    z[1,2,4]  R766      -1.3956628739833832e-01
    z[1,2,4]  R767      -3.4333132207393646e-03
    z[1,2,4]  R768      1.0232302546501160e-01
    z[1,2,4]  R769      1.4482711255550385e-01
    z[1,2,4]  R770      -1.5411286056041718e-01
    z[1,2,4]  R771      -4.0778371691703796e-01
    z[1,2,4]  R772      -4.0476894378662109e-01
    z[1,2,4]  R773      1.7956039309501648e-01
    z[1,2,4]  R774      3.3553296327590942e-01
    z[1,2,4]  R775      -0.539141058921814
    z[1,2,4]  R776      -3.7009525299072266e-01
    z[1,2,4]  R777      -0.0699705109000206
    z[1,2,4]  R778      -6.4956271648406982e-01
    z[1,2,4]  R779      -1.1231047660112381e-01
    z[1,2,4]  R780      3.6462938785552979e-01
    z[1,2,4]  R781      3.8490617275238037e-01
    z[1,2,4]  R782      4.4420263729989529e-03
    z[1,2,4]  R783      -0.00312254810705781
    z[1,2,4]  R784      0.638698935508728
    z[1,2,4]  R785      -4.8643991351127625e-01
    z[1,2,4]  R786      -0.00611188355833292
    z[1,2,4]  R787      2.7820187807083130e-01
    z[1,2,4]  R788      -5.2202165126800537e-01
    z[1,2,4]  R789      1.3742050528526306e-01
    z[1,2,4]  R790      1.1549419909715652e-01
    z[1,2,4]  R791      -4.0852095931768417e-02
    z[1,2,4]  R792      7.2771638631820679e-01
    z[1,2,4]  R793      1.8970780074596405e-01
    z[1,2,4]  R794      2.0771621167659760e-01
    z[1,2,4]  R795      -2.5147604942321777e-01
    z[1,2,4]  R796      -1.2091477960348129e-01
    z[1,2,4]  R797      -1.9797105342149734e-02
    z[1,2,4]  R798      -1.4402748644351959e-01
    z[1,2,4]  R799      -1.0693571716547012e-01
    z[1,2,4]  R800      3.4225240349769592e-01
    z[1,2,4]  R801      -4.7265164554119110e-02
    z[1,2,4]  R802      6.9808769226074219e-01
    z[1,2,4]  R803      2.2988188266754150e-01
    z[1,2,4]  R804      5.8784735202789307e-01
    z[1,2,4]  R805      -1.7248657345771790e-01
    z[1,2,4]  R806      -5.7757817208766937e-02
    z[1,2,4]  R807      2.5371652841567993e-01
    z[1,2,4]  R808      4.8426890862174332e-04
    z[1,2,4]  R809      1.9570238888263702e-01
    z[1,2,4]  R810      -2.5386002659797668e-01
    z[1,2,4]  R811      3.7076970934867859e-01
    z[1,2,4]  R812      3.8136407732963562e-01
    z[1,2,4]  R813      2.7218326926231384e-01
    z[1,2,4]  R814      -1.1834619939327240e-01
    z[1,2,4]  R815      -3.4494879841804504e-01
    z[1,2,4]  R816      -6.2019479274749756e-01
    z[1,2,4]  R817      -1.2619766592979431e-01
    z[1,2,4]  R818      1.2386779487133026e-01
    z[1,2,4]  R819      1.1356448382139206e-01
    z[1,2,4]  R820      -0.685459315776825
    z[1,2,4]  R821      -1.7781707644462585e-01
    z[1,2,4]  R822      -5.6831365823745728e-01
    z[1,2,4]  R823      -8.9890755712985992e-02
    z[1,2,4]  R824      -0.570176362991333
    z[1,2,4]  R825      -5.1463317126035690e-02
    z[1,2,4]  R826      4.9570216797292233e-03
    z[1,2,4]  R827      -2.1611016988754272e-01
    z[1,2,4]  R828      3.0435770750045776e-01
    z[1,2,4]  R829      3.5316145420074463e-01
    z[1,2,4]  R830      2.9572373628616333e-01
    z[1,2,4]  R831      4.7489190101623535e-01
    z[1,2,4]  R832      5.1569879055023193e-01
    z[1,2,4]  R833      -2.3159846663475037e-01
    z[1,2,4]  R834      6.1637425422668457e-01
    z[1,2,4]  R835      -2.5623646378517151e-01
    z[1,2,4]  R836      2.5742354989051819e-01
    z[1,2,4]  R837      3.6368942260742188e-01
    z[1,2,4]  R838      -2.6839458942413330e-01
    z[1,2,4]  R839      -0.610956072807312
    z[1,2,4]  R840      -2.6510828733444214e-01
    z[1,2,4]  R841      7.2587326169013977e-02
    z[1,2,4]  R842      -2.4104593694210052e-01
    z[1,2,4]  R843      0.389614462852478
    z[1,2,4]  R844      -4.4050836563110352e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R731      -1
    z[1,2,5]  R732      1
    z[1,2,5]  R735      0.572059154510498
    z[1,2,5]  R736      2.0224650204181671e-01
    z[1,2,5]  R737      3.2499879598617554e-01
    z[1,2,5]  R738      5.7566791772842407e-01
    z[1,2,5]  R739      3.4185257554054260e-01
    z[1,2,5]  R740      3.9359909296035767e-01
    z[1,2,5]  R741      4.4418856501579285e-01
    z[1,2,5]  R742      9.8158992826938629e-02
    z[1,2,5]  R743      5.9080576896667480e-01
    z[1,2,5]  R744      4.4936811923980713e-01
    z[1,2,5]  R745      -4.0780159831047058e-01
    z[1,2,5]  R746      8.4364823997020721e-02
    z[1,2,5]  R747      -1.5487454831600189e-01
    z[1,2,5]  R748      -1.2571081519126892e-01
    z[1,2,5]  R749      3.1980958580970764e-01
    z[1,2,5]  R750      -3.6274725198745728e-01
    z[1,2,5]  R751      -3.0109253525733948e-01
    z[1,2,5]  R752      0.257143497467041
    z[1,2,5]  R753      1.9259685277938843e-01
    z[1,2,5]  R754      -6.8089640699326992e-03
    z[1,2,5]  R755      4.8340019583702087e-01
    z[1,2,5]  R756      2.7367675304412842e-01
    z[1,2,5]  R757      -3.3563733100891113e-01
    z[1,2,5]  R758      1.4590451121330261e-01
    z[1,2,5]  R759      -5.5856868624687195e-02
    z[1,2,5]  R760      -2.2697854042053223e-01
    z[1,2,5]  R761      5.9576934576034546e-01
    z[1,2,5]  R762      7.0278368890285492e-02
    z[1,2,5]  R763      -1.0773368924856186e-01
    z[1,2,5]  R764      1.5290841460227966e-01
    z[1,2,5]  R765      -1.1612065881490707e-01
    z[1,2,5]  R766      2.8547903895378113e-01
    z[1,2,5]  R767      -2.3959022760391235e-01
    z[1,2,5]  R768      -5.0130861997604370e-01
    z[1,2,5]  R769      1.5951279550790787e-02
    z[1,2,5]  R770      -1.2310817837715149e-01
    z[1,2,5]  R771      -5.1310826092958450e-02
    z[1,2,5]  R772      -1.8648105859756470e-01
    z[1,2,5]  R773      0.0703989565372467
    z[1,2,5]  R774      -3.9049103856086731e-01
    z[1,2,5]  R775      3.1631711125373840e-01
    z[1,2,5]  R776      -2.3108754307031631e-02
    z[1,2,5]  R777      -1.6224546730518341e-01
    z[1,2,5]  R778      3.4271883964538574e-01
    z[1,2,5]  R779      -3.0070307850837708e-01
    z[1,2,5]  R780      6.0025727748870850e-01
    z[1,2,5]  R781      1.8479205667972565e-01
    z[1,2,5]  R782      7.8040468692779541e-01
    z[1,2,5]  R783      -4.1192230582237244e-01
    z[1,2,5]  R784      -2.6334571838378906e-01
    z[1,2,5]  R785      3.3801969885826111e-01
    z[1,2,5]  R786      3.5301876068115234e-01
    z[1,2,5]  R787      -7.6438359916210175e-02
    z[1,2,5]  R788      5.9744093567132950e-02
    z[1,2,5]  R789      3.6693602800369263e-01
    z[1,2,5]  R790      2.9750075936317444e-01
    z[1,2,5]  R791      -1.7647065222263336e-01
    z[1,2,5]  R792      3.5998750478029251e-02
    z[1,2,5]  R793      1.4218123257160187e-01
    z[1,2,5]  R794      2.5382840633392334e-01
    z[1,2,5]  R795      3.3892911672592163e-01
    z[1,2,5]  R796      -4.3619722127914429e-01
    z[1,2,5]  R797      2.8107947111129761e-01
    z[1,2,5]  R798      -1.2996278703212738e-01
    z[1,2,5]  R799      3.3217015862464905e-01
    z[1,2,5]  R800      5.5026316642761230e-01
    z[1,2,5]  R801      -1.1787935346364975e-01
    z[1,2,5]  R802      1.0426397621631622e-01
    z[1,2,5]  R803      -2.3423854261636734e-02
    z[1,2,5]  R804      2.0529115572571754e-03
    z[1,2,5]  R805      4.4440496712923050e-02
    z[1,2,5]  R806      2.4768424034118652e-01
    z[1,2,5]  R807      3.6937782168388367e-01
    z[1,2,5]  R808      -6.5523582696914673e-01
    z[1,2,5]  R809      1.7465998232364655e-01
    z[1,2,5]  R810      5.2527469396591187e-01
    z[1,2,5]  R811      2.9900896549224854e-01
    z[1,2,5]  R812      -4.4401895999908447e-01
    z[1,2,5]  R813      -3.8961264491081238e-01
    z[1,2,5]  R814      -2.4709609150886536e-01
    z[1,2,5]  R815      7.3272442817687988e-01
    z[1,2,5]  R816      5.7743382453918457e-01
    z[1,2,5]  R817      -1.1910753697156906e-01
    z[1,2,5]  R818      9.9070534110069275e-02
    z[1,2,5]  R819      1.4756646752357483e-01
    z[1,2,5]  R820      2.8583604097366333e-01
    z[1,2,5]  R821      7.0279783010482788e-01
    z[1,2,5]  R822      -5.8415614068508148e-02
    z[1,2,5]  R823      4.1297596693038940e-01
    z[1,2,5]  R824      2.5528600811958313e-01
    z[1,2,5]  R825      4.4018706679344177e-01
    z[1,2,5]  R826      1.9469425082206726e-01
    z[1,2,5]  R827      3.5704341530799866e-01
    z[1,2,5]  R828      3.5296735167503357e-01
    z[1,2,5]  R829      3.7022951245307922e-01
    z[1,2,5]  R830      -6.9216839969158173e-02
    z[1,2,5]  R831      3.6752417683601379e-01
    z[1,2,5]  R832      1.9860202074050903e-01
    z[1,2,5]  R833      -8.5678435862064362e-02
    z[1,2,5]  R834      3.0596208572387695e-01
    z[1,2,5]  R835      3.2019170466810465e-03
    z[1,2,5]  R836      -2.9590100049972534e-01
    z[1,2,5]  R837      5.0767010450363159e-01
    z[1,2,5]  R838      1.7190322279930115e-01
    z[1,2,5]  R839      6.0550201684236526e-02
    z[1,2,5]  R840      1.5664808452129364e-01
    z[1,2,5]  R841      8.2535691559314728e-02
    z[1,2,5]  R842      -1.4474037289619446e-01
    z[1,2,5]  R843      -4.6410274505615234e-01
    z[1,2,5]  R844      -2.1927395462989807e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R733      -1
    z[1,2,6]  R734      1
    z[1,2,6]  R735      -1.0094126313924789e-01
    z[1,2,6]  R736      5.6552541255950928e-01
    z[1,2,6]  R737      1.8306763470172882e-01
    z[1,2,6]  R738      4.0054774284362793e-01
    z[1,2,6]  R739      6.7007130384445190e-01
    z[1,2,6]  R740      2.1076177060604095e-01
    z[1,2,6]  R741      1.9455462694168091e-01
    z[1,2,6]  R742      1.3794803060591221e-02
    z[1,2,6]  R743      -2.1089243888854980e-01
    z[1,2,6]  R744      -3.5103622823953629e-02
    z[1,2,6]  R745      -2.1862334012985229e-01
    z[1,2,6]  R746      -3.5250243544578552e-01
    z[1,2,6]  R747      -1.6827414929866791e-01
    z[1,2,6]  R748      -2.4363709986209869e-01
    z[1,2,6]  R749      -6.8211001157760620e-01
    z[1,2,6]  R750      2.9009729623794556e-01
    z[1,2,6]  R751      2.1386879682540894e-01
    z[1,2,6]  R752      -4.6796661615371704e-01
    z[1,2,6]  R753      -0.00897196028381586
    z[1,2,6]  R754      -2.8280505537986755e-01
    z[1,2,6]  R755      3.0765134096145630e-01
    z[1,2,6]  R756      1.4253717660903931e-01
    z[1,2,6]  R757      5.1409882307052612e-01
    z[1,2,6]  R758      -5.0827968120574951e-01
    z[1,2,6]  R759      -5.5723458528518677e-01
    z[1,2,6]  R760      6.6427379846572876e-01
    z[1,2,6]  R761      -2.6136210560798645e-01
    z[1,2,6]  R762      1.0727969557046890e-01
    z[1,2,6]  R763      -4.3989929556846619e-01
    z[1,2,6]  R764      -1.3690182566642761e-01
    z[1,2,6]  R765      -6.3550300896167755e-02
    z[1,2,6]  R766      -1.9873073324561119e-02
    z[1,2,6]  R767      5.9995472431182861e-01
    z[1,2,6]  R768      2.1704828366637230e-02
    z[1,2,6]  R769      -6.3127028942108154e-01
    z[1,2,6]  R770      -4.1776600480079651e-01
    z[1,2,6]  R771      -1.5022459626197815e-01
    z[1,2,6]  R772      2.9906576871871948e-01
    z[1,2,6]  R773      -2.5497548282146454e-02
    z[1,2,6]  R774      -5.4342824965715408e-02
    z[1,2,6]  R775      -1.7073558270931244e-01
    z[1,2,6]  R776      -1.9525590538978577e-01
    z[1,2,6]  R777      -1.7476680874824524e-01
    z[1,2,6]  R778      2.1142615377902985e-01
    z[1,2,6]  R779      3.7019538879394531e-01
    z[1,2,6]  R780      1.0266381502151489e-01
    z[1,2,6]  R781      -1.1407420039176941e-01
    z[1,2,6]  R782      -2.2610634565353394e-01
    z[1,2,6]  R783      1.9763161242008209e-01
    z[1,2,6]  R784      2.2427958250045776e-01
    z[1,2,6]  R785      4.5541429519653320e-01
    z[1,2,6]  R786      3.5498014092445374e-01
    z[1,2,6]  R787      2.5778535008430481e-01
    z[1,2,6]  R788      0.0934520810842514
    z[1,2,6]  R789      -3.2309833168983459e-01
    z[1,2,6]  R790      -4.5556899905204773e-01
    z[1,2,6]  R791      0.695705235004425
    z[1,2,6]  R792      -2.8095710277557373e-01
    z[1,2,6]  R793      -1.2208689749240875e-01
    z[1,2,6]  R794      1.3990619219839573e-02
    z[1,2,6]  R795      3.6184132099151611e-01
    z[1,2,6]  R796      3.4200161695480347e-01
    z[1,2,6]  R797      5.1040965318679810e-01
    z[1,2,6]  R798      0.277180939912796
    z[1,2,6]  R799      -6.6973221302032471e-01
    z[1,2,6]  R800      -3.9014154672622681e-01
    z[1,2,6]  R801      -1.2053254991769791e-01
    z[1,2,6]  R802      -2.9033371806144714e-01
    z[1,2,6]  R803      4.1502752900123596e-01
    z[1,2,6]  R804      -3.0794525519013405e-03
    z[1,2,6]  R805      3.9402934908866882e-01
    z[1,2,6]  R806      -1.4269025623798370e-01
    z[1,2,6]  R807      1.5831559430807829e-03
    z[1,2,6]  R808      7.2386696934700012e-02
    z[1,2,6]  R809      2.4910837411880493e-01
    z[1,2,6]  R810      -5.6955751031637192e-02
    z[1,2,6]  R811      -4.5883330702781677e-01
    z[1,2,6]  R812      -4.3563794344663620e-02
    z[1,2,6]  R813      1.9896394014358521e-01
    z[1,2,6]  R814      -3.3873987197875977e-01
    z[1,2,6]  R815      1.6707342863082886e-01
    z[1,2,6]  R816      -1.5947981178760529e-01
    z[1,2,6]  R817      1.1592247337102890e-01
    z[1,2,6]  R818      4.2579475045204163e-01
    z[1,2,6]  R819      -3.2284185290336609e-01
    z[1,2,6]  R820      8.2118771970272064e-02
    z[1,2,6]  R821      -5.2011966705322266e-01
    z[1,2,6]  R822      0.106770820915699
    z[1,2,6]  R823      -6.4204132556915283e-01
    z[1,2,6]  R824      -0.638708233833313
    z[1,2,6]  R825      1.6347558796405792e-01
    z[1,2,6]  R826      4.2418867349624634e-02
    z[1,2,6]  R827      6.5617696382105350e-03
    z[1,2,6]  R828      4.5117955654859543e-02
    z[1,2,6]  R829      3.3418801426887512e-01
    z[1,2,6]  R830      9.3657158315181732e-02
    z[1,2,6]  R831      -3.3215171098709106e-01
    z[1,2,6]  R832      2.3647336661815643e-01
    z[1,2,6]  R833      2.7245423197746277e-01
    z[1,2,6]  R834      -0.257385790348053
    z[1,2,6]  R835      -1.8693499267101288e-01
    z[1,2,6]  R836      -1.6323995590209961e-01
    z[1,2,6]  R837      -1.0348517447710037e-01
    z[1,2,6]  R838      -3.0516979098320007e-01
    z[1,2,6]  R839      -7.4036069214344025e-02
    z[1,2,6]  R840      4.0562847256660461e-01
    z[1,2,6]  R841      5.1011914014816284e-01
    z[1,2,6]  R842      -2.7839767932891846e-01
    z[1,2,6]  R843      -4.2455330491065979e-01
    z[1,2,6]  R844      4.8394781351089478e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R845      -1
    z[2,1,0]  R846      1
    z[2,1,0]  R859      -7.6891683042049408e-02
    z[2,1,0]  R860      9.7774147987365723e-02
    z[2,1,0]  R861      -1.1200371384620667e-01
    z[2,1,0]  R862      -1.0103247128427029e-02
    z[2,1,0]  R863      1.8761040270328522e-01
    z[2,1,0]  R864      -1.8172055482864380e-01
    z[2,1,0]  R865      1.5545558929443359e-01
    z[2,1,0]  R866      1.4082913100719452e-01
    z[2,1,0]  R867      3.0249828100204468e-01
    z[2,1,0]  R868      1.1991544812917709e-01
    z[2,1,0]  R869      -1.2291748821735382e-01
    z[2,1,0]  R870      2.8967265039682388e-02
    z[2,1,0]  R871      -0.0217283982783556
    z[2,1,0]  R872      -1.7278583347797394e-01
    z[2,1,0]  R873      -2.3908168077468872e-02
    z[2,1,0]  R874      -8.7013579905033112e-02
    z[2,1,0]  R875      0.06809101998806
    z[2,1,0]  R876      -1.0040861368179321e-01
    z[2,1,0]  R877      -6.5120466053485870e-02
    z[2,1,0]  R878      1.5014787018299103e-01
    z[2,1,0]  R879      -6.3791498541831970e-02
    z[2,1,0]  R880      1.9312863051891327e-01
    z[2,1,0]  R881      -2.5318851694464684e-02
    z[2,1,0]  R882      2.2771932184696198e-02
    z[2,1,0]  R883      -3.4576624631881714e-02
    z[2,1,0]  R884      -9.8926816135644913e-03
    z[2,1,0]  R885      -1.0351626574993134e-01
    z[2,1,0]  R886      1.6009204089641571e-01
    z[2,1,0]  R887      3.1615566462278366e-02
    z[2,1,0]  R888      -1.4451977610588074e-01
    z[2,1,0]  R889      1.2190082669258118e-01
    z[2,1,0]  R890      8.7008059024810791e-02
    z[2,1,0]  R891      3.0221480131149292e-01
    z[2,1,0]  R892      2.6016193628311157e-01
    z[2,1,0]  R893      2.4748301506042480e-01
    z[2,1,0]  R894      7.8136193752288818e-01
    z[2,1,0]  R895      4.5540583133697510e-01
    z[2,1,0]  R896      -0.0655539408326149
    z[2,1,0]  R897      -9.9040046334266663e-02
    z[2,1,0]  R898      1.5701797604560852e-01
    z[2,1,0]  R899      4.4143640995025635e-01
    z[2,1,0]  R900      3.5963547229766846e-01
    z[2,1,0]  R901      -2.4248990416526794e-01
    z[2,1,0]  R902      1.7267766594886780e-01
    z[2,1,0]  R903      -8.9693062007427216e-02
    z[2,1,0]  R904      2.3396338522434235e-01
    z[2,1,0]  R905      -1.8763886392116547e-01
    z[2,1,0]  R906      6.3462473452091217e-02
    z[2,1,0]  R907      5.1345992088317871e-01
    z[2,1,0]  R908      -2.9811403155326843e-01
    z[2,1,0]  R909      0.645882785320282
    z[2,1,0]  R910      6.6964232921600342e-01
    z[2,1,0]  R911      3.2339587807655334e-01
    z[2,1,0]  R912      0.0756298080086708
    z[2,1,0]  R913      1.8386992812156677e-01
    z[2,1,0]  R914      2.7939921617507935e-01
    z[2,1,0]  R915      2.6959127187728882e-01
    z[2,1,0]  R916      5.9965625405311584e-02
    z[2,1,0]  R917      3.8612468633800745e-03
    z[2,1,0]  R918      -3.8516032695770264e-01
    z[2,1,0]  R919      2.8719830513000488e-01
    z[2,1,0]  R920      -1.0021450370550156e-01
    z[2,1,0]  R921      -1.3037898577749729e-02
    z[2,1,0]  R922      2.0253281295299530e-01
    z[2,1,0]  R923      1.2343436479568481e-01
    z[2,1,0]  R924      1.8908047676086426e-01
    z[2,1,0]  R925      -3.3509114384651184e-01
    z[2,1,0]  R926      -2.0382659137248993e-01
    z[2,1,0]  R927      7.2123610973358154e-01
    z[2,1,0]  R928      2.8315272927284241e-01
    z[2,1,0]  R929      2.6582491397857666e-01
    z[2,1,0]  R930      -1.4259302616119385e-01
    z[2,1,0]  R931      1.0283294320106506e-01
    z[2,1,0]  R932      3.0567729473114014e-01
    z[2,1,0]  R933      1.2950356304645538e-01
    z[2,1,0]  R934      2.6565348729491234e-02
    z[2,1,0]  R935      -8.7781930342316628e-03
    z[2,1,0]  R936      -9.1276951134204865e-02
    z[2,1,0]  R937      5.2722871303558350e-01
    z[2,1,0]  R938      1.9307661568745971e-04
    z[2,1,0]  R939      7.6995693147182465e-02
    z[2,1,0]  R940      -1.2734183669090271e-01
    z[2,1,0]  R941      3.3917301893234253e-01
    z[2,1,0]  R942      2.6374366134405136e-02
    z[2,1,0]  R943      8.2131153345108032e-01
    z[2,1,0]  R944      4.5522559434175491e-02
    z[2,1,0]  R945      2.7312453836202621e-02
    z[2,1,0]  R946      -1.0336112976074219e-01
    z[2,1,0]  R947      -3.2615110278129578e-01
    z[2,1,0]  R948      -3.4594023227691650e-01
    z[2,1,0]  R949      2.8148117661476135e-01
    z[2,1,0]  R950      3.4922760725021362e-01
    z[2,1,0]  R951      3.0996146798133850e-01
    z[2,1,0]  R952      1.2708684802055359e-01
    z[2,1,0]  R953      1.3786189258098602e-01
    z[2,1,0]  R954      3.7735259532928467e-01
    z[2,1,0]  R955      2.9833212494850159e-01
    z[2,1,0]  R956      -1.2803736329078674e-01
    z[2,1,0]  R957      -1.1106203496456146e-01
    z[2,1,0]  R958      2.8687962330877781e-03
    z[2,1,0]  R959      2.8190642595291138e-01
    z[2,1,0]  R960      3.4562137722969055e-01
    z[2,1,0]  R961      -2.3160532116889954e-02
    z[2,1,0]  R962      -1.2331695854663849e-01
    z[2,1,0]  R963      3.4004177898168564e-02
    z[2,1,0]  R964      -4.1489630937576294e-01
    z[2,1,0]  R965      -2.6557642221450806e-01
    z[2,1,0]  R966      -1.1845907568931580e-01
    z[2,1,0]  R967      -1.9464151561260223e-01
    z[2,1,0]  R968      2.8730336576700211e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R847      -1
    z[2,1,1]  R848      1
    z[2,1,1]  R859      -5.5581796169281006e-01
    z[2,1,1]  R860      -4.0392491221427917e-01
    z[2,1,1]  R861      -0.71854567527771
    z[2,1,1]  R862      -7.7100795507431030e-01
    z[2,1,1]  R863      -9.0539109706878662e-01
    z[2,1,1]  R864      -0.53448086977005
    z[2,1,1]  R865      -4.0648657083511353e-01
    z[2,1,1]  R866      -6.4921647310256958e-01
    z[2,1,1]  R867      -4.3055734038352966e-01
    z[2,1,1]  R868      -4.0923115611076355e-01
    z[2,1,1]  R869      0.808269202709198
    z[2,1,1]  R870      0.915841817855835
    z[2,1,1]  R871      8.5408157110214233e-01
    z[2,1,1]  R872      8.2139098644256592e-01
    z[2,1,1]  R873      6.9976997375488281e-01
    z[2,1,1]  R874      8.7637430429458618e-01
    z[2,1,1]  R875      7.0686239004135132e-01
    z[2,1,1]  R876      7.2135227918624878e-01
    z[2,1,1]  R877      8.4297072887420654e-01
    z[2,1,1]  R878      5.6277406215667725e-01
    z[2,1,1]  R879      8.6787194013595581e-01
    z[2,1,1]  R880      0.759022057056427
    z[2,1,1]  R881      3.3177286386489868e-01
    z[2,1,1]  R882      2.6639896631240845e-01
    z[2,1,1]  R883      5.8427613973617554e-01
    z[2,1,1]  R884      3.9753732085227966e-01
    z[2,1,1]  R885      6.0654246807098389e-01
    z[2,1,1]  R886      0.597892701625824
    z[2,1,1]  R887      5.7512110471725464e-01
    z[2,1,1]  R888      6.0753285884857178e-01
    z[2,1,1]  R889      -1.6991697251796722e-01
    z[2,1,1]  R890      -1.2021198123693466e-01
    z[2,1,1]  R891      5.0322914123535156e-01
    z[2,1,1]  R892      4.2183393239974976e-01
    z[2,1,1]  R893      4.2930355668067932e-01
    z[2,1,1]  R894      1.9643928110599518e-01
    z[2,1,1]  R895      7.2861391305923462e-01
    z[2,1,1]  R896      7.2586512565612793e-01
    z[2,1,1]  R897      6.2076145410537720e-01
    z[2,1,1]  R898      5.3477644920349121e-01
    z[2,1,1]  R899      -5.7719420641660690e-02
    z[2,1,1]  R900      4.3008357286453247e-01
    z[2,1,1]  R901      7.1668881177902222e-01
    z[2,1,1]  R902      -0.883419394493103
    z[2,1,1]  R903      3.3213075995445251e-01
    z[2,1,1]  R904      6.6292655467987061e-01
    z[2,1,1]  R905      7.8095215559005737e-01
    z[2,1,1]  R906      5.9684544801712036e-01
    z[2,1,1]  R907      4.7032064199447632e-01
    z[2,1,1]  R908      3.3033528923988342e-01
    z[2,1,1]  R909      -1.8666094541549683e-01
    z[2,1,1]  R910      4.6317240595817566e-01
    z[2,1,1]  R911      -1.3988637924194336e-01
    z[2,1,1]  R912      5.5366027355194092e-01
    z[2,1,1]  R913      2.9774689674377441e-01
    z[2,1,1]  R914      5.5339790880680084e-02
    z[2,1,1]  R915      -5.6207644939422607e-01
    z[2,1,1]  R916      1.1363073438405991e-01
    z[2,1,1]  R917      5.7327234745025635e-01
    z[2,1,1]  R918      8.8000553846359253e-01
    z[2,1,1]  R919      8.5935018956661224e-02
    z[2,1,1]  R920      1.2243407964706421e-01
    z[2,1,1]  R921      1.2666161358356476e-01
    z[2,1,1]  R922      -1.5021903812885284e-01
    z[2,1,1]  R923      2.1114858984947205e-01
    z[2,1,1]  R924      -4.9134314060211182e-01
    z[2,1,1]  R925      3.0135393142700195e-01
    z[2,1,1]  R926      4.8563334345817566e-01
    z[2,1,1]  R927      -0.431154727935791
    z[2,1,1]  R928      3.3930018544197083e-01
    z[2,1,1]  R929      -5.1909035444259644e-01
    z[2,1,1]  R930      -8.2570560276508331e-02
    z[2,1,1]  R931      0.361701637506485
    z[2,1,1]  R932      2.4564903974533081e-01
    z[2,1,1]  R933      2.9356616735458374e-01
    z[2,1,1]  R934      1.5386205911636353e-01
    z[2,1,1]  R935      -5.1868957281112671e-01
    z[2,1,1]  R936      8.2093916833400726e-02
    z[2,1,1]  R937      -4.4982436299324036e-01
    z[2,1,1]  R938      3.2640573382377625e-01
    z[2,1,1]  R939      4.1391676664352417e-01
    z[2,1,1]  R940      -2.6323437690734863e-01
    z[2,1,1]  R941      -1.6353602707386017e-01
    z[2,1,1]  R942      -8.1723339855670929e-02
    z[2,1,1]  R943      5.5401228368282318e-02
    z[2,1,1]  R944      -1.9173620641231537e-01
    z[2,1,1]  R945      -5.3725861012935638e-02
    z[2,1,1]  R946      6.6931024193763733e-02
    z[2,1,1]  R947      7.4424481391906738e-01
    z[2,1,1]  R948      6.7177957296371460e-01
    z[2,1,1]  R949      4.7372713685035706e-01
    z[2,1,1]  R950      -1.3733093440532684e-01
    z[2,1,1]  R951      -5.6713593006134033e-01
    z[2,1,1]  R952      5.3955519199371338e-01
    z[2,1,1]  R953      7.9679578542709351e-02
    z[2,1,1]  R954      -2.2865033149719238e-01
    z[2,1,1]  R955      4.1618752479553223e-01
    z[2,1,1]  R956      4.9980757758021355e-03
    z[2,1,1]  R957      0.787831723690033
    z[2,1,1]  R958      7.3669201135635376e-01
    z[2,1,1]  R959      -3.4342417120933533e-01
    z[2,1,1]  R960      5.0888639688491821e-01
    z[2,1,1]  R961      -1.3661010563373566e-01
    z[2,1,1]  R962      -4.2335250973701477e-01
    z[2,1,1]  R963      7.9447090625762939e-01
    z[2,1,1]  R964      6.1699497699737549e-01
    z[2,1,1]  R965      6.7754375934600830e-01
    z[2,1,1]  R966      -7.0698434114456177e-01
    z[2,1,1]  R967      -6.3214230537414551e-01
    z[2,1,1]  R968      -7.0445472002029419e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R849      -1
    z[2,1,2]  R850      1
    z[2,1,2]  R859      -3.6512367427349091e-02
    z[2,1,2]  R860      -2.8309595584869385e-01
    z[2,1,2]  R861      4.8948526382446289e-01
    z[2,1,2]  R862      -6.1697751283645630e-02
    z[2,1,2]  R863      -7.4687354266643524e-02
    z[2,1,2]  R864      2.9746848344802856e-01
    z[2,1,2]  R865      -0.0318966880440712
    z[2,1,2]  R866      -4.6656516194343567e-01
    z[2,1,2]  R867      -2.1023957431316376e-01
    z[2,1,2]  R868      1.2792116403579712e-01
    z[2,1,2]  R869      4.3497156351804733e-02
    z[2,1,2]  R870      -2.8441622853279114e-01
    z[2,1,2]  R871      -2.7528798580169678e-01
    z[2,1,2]  R872      2.6707369089126587e-01
    z[2,1,2]  R873      -3.1428366899490356e-01
    z[2,1,2]  R874      1.5977898240089417e-01
    z[2,1,2]  R875      4.0474005043506622e-02
    z[2,1,2]  R876      9.6002802252769470e-02
    z[2,1,2]  R877      -3.2728922367095947e-01
    z[2,1,2]  R878      -2.9421791434288025e-01
    z[2,1,2]  R879      8.5515398532152176e-03
    z[2,1,2]  R880      -4.5370987057685852e-01
    z[2,1,2]  R881      2.7419024705886841e-01
    z[2,1,2]  R882      3.0780667066574097e-01
    z[2,1,2]  R883      6.1520017683506012e-02
    z[2,1,2]  R884      -0.297622412443161
    z[2,1,2]  R885      -4.1597130894660950e-01
    z[2,1,2]  R886      -1.5419314801692963e-01
    z[2,1,2]  R887      3.0139547586441040e-01
    z[2,1,2]  R888      -9.3728266656398773e-02
    z[2,1,2]  R889      5.9869188070297241e-01
    z[2,1,2]  R890      2.9843065142631531e-01
    z[2,1,2]  R891      2.6460850238800049e-01
    z[2,1,2]  R892      3.4760057926177979e-02
    z[2,1,2]  R893      3.0230289697647095e-01
    z[2,1,2]  R894      -2.0901657640933990e-01
    z[2,1,2]  R895      1.1959838122129440e-01
    z[2,1,2]  R896      6.6681647300720215e-01
    z[2,1,2]  R897      -4.3016105890274048e-01
    z[2,1,2]  R898      -6.4490920305252075e-01
    z[2,1,2]  R899      2.7831861376762390e-01
    z[2,1,2]  R900      3.2640692591667175e-01
    z[2,1,2]  R901      -2.5030997395515442e-01
    z[2,1,2]  R902      2.2311314940452576e-01
    z[2,1,2]  R903      3.3854430913925171e-01
    z[2,1,2]  R904      2.9363412410020828e-02
    z[2,1,2]  R905      -1.3518701493740082e-01
    z[2,1,2]  R906      -3.1465950608253479e-01
    z[2,1,2]  R907      -3.4053522348403931e-01
    z[2,1,2]  R908      3.8307452201843262e-01
    z[2,1,2]  R909      1.5904194116592407e-01
    z[2,1,2]  R910      4.5045712590217590e-01
    z[2,1,2]  R911      -3.6079365015029907e-01
    z[2,1,2]  R912      5.9527742862701416e-01
    z[2,1,2]  R913      6.1822026968002319e-01
    z[2,1,2]  R914      4.3528366088867188e-01
    z[2,1,2]  R915      -1.3250146806240082e-01
    z[2,1,2]  R916      7.8870460391044617e-02
    z[2,1,2]  R917      -2.5467187166213989e-02
    z[2,1,2]  R918      -7.9486265778541565e-02
    z[2,1,2]  R919      7.1662414073944092e-01
    z[2,1,2]  R920      6.2009769678115845e-01
    z[2,1,2]  R921      6.6452652215957642e-01
    z[2,1,2]  R922      8.1538534164428711e-01
    z[2,1,2]  R923      1.4778582751750946e-01
    z[2,1,2]  R924      1.0131459683179855e-01
    z[2,1,2]  R925      0.688653290271759
    z[2,1,2]  R926      5.4570317268371582e-01
    z[2,1,2]  R927      -9.4202525913715363e-02
    z[2,1,2]  R928      -5.0470698624849319e-02
    z[2,1,2]  R929      4.8978269100189209e-01
    z[2,1,2]  R930      8.9249360561370850e-01
    z[2,1,2]  R931      1.2544372677803040e-01
    z[2,1,2]  R932      3.1213113665580750e-01
    z[2,1,2]  R933      -2.7585986256599426e-01
    z[2,1,2]  R934      -3.1035137176513672e-01
    z[2,1,2]  R935      -4.3089857697486877e-01
    z[2,1,2]  R936      -1.1614146083593369e-01
    z[2,1,2]  R937      -5.8289320440962911e-04
    z[2,1,2]  R938      -2.4012021720409393e-01
    z[2,1,2]  R939      4.1218116879463196e-01
    z[2,1,2]  R940      -3.3402808010578156e-02
    z[2,1,2]  R941      -1.1080418527126312e-01
    z[2,1,2]  R942      2.7810338139533997e-01
    z[2,1,2]  R943      1.9780190289020538e-01
    z[2,1,2]  R944      -3.7223607301712036e-01
    z[2,1,2]  R945      1.3389432430267334e-01
    z[2,1,2]  R946      -1.4040251076221466e-01
    z[2,1,2]  R947      -4.5583599805831909e-01
    z[2,1,2]  R948      -5.4609888792037964e-01
    z[2,1,2]  R949      4.7746098041534424e-01
    z[2,1,2]  R950      7.1907371282577515e-01
    z[2,1,2]  R951      4.9191007018089294e-01
    z[2,1,2]  R952      7.5943440198898315e-01
    z[2,1,2]  R953      6.0824835300445557e-01
    z[2,1,2]  R954      3.2030174136161804e-01
    z[2,1,2]  R955      6.9243609905242920e-01
    z[2,1,2]  R956      -0.016898138448596
    z[2,1,2]  R957      -3.6733978986740112e-01
    z[2,1,2]  R958      -2.9070207476615906e-01
    z[2,1,2]  R959      5.8625358343124390e-01
    z[2,1,2]  R960      0.732223391532898
    z[2,1,2]  R961      -9.6521571278572083e-02
    z[2,1,2]  R962      -1.9231060519814491e-02
    z[2,1,2]  R963      -0.481898695230484
    z[2,1,2]  R964      -3.1801348924636841e-01
    z[2,1,2]  R965      -1.2653756141662598e-01
    z[2,1,2]  R966      -1.1570768803358078e-01
    z[2,1,2]  R967      -2.9008877277374268e-01
    z[2,1,2]  R968      -4.9061864614486694e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R851      -1
    z[2,1,3]  R852      1
    z[2,1,3]  R859      -5.7133636437356472e-03
    z[2,1,3]  R860      6.0302615165710449e-02
    z[2,1,3]  R861      4.3359076976776123e-01
    z[2,1,3]  R862      4.4179043173789978e-01
    z[2,1,3]  R863      -2.4320727214217186e-02
    z[2,1,3]  R864      -1.8579587340354919e-01
    z[2,1,3]  R865      1.1626062542200089e-01
    z[2,1,3]  R866      5.6650150567293167e-02
    z[2,1,3]  R867      2.9676252603530884e-01
    z[2,1,3]  R868      -5.9717226773500443e-02
    z[2,1,3]  R869      3.2643941044807434e-01
    z[2,1,3]  R870      1.9942989945411682e-01
    z[2,1,3]  R871      -1.4164198935031891e-01
    z[2,1,3]  R872      -6.9845512509346008e-02
    z[2,1,3]  R873      1.9365318119525909e-01
    z[2,1,3]  R874      3.1281337141990662e-01
    z[2,1,3]  R875      1.5215082466602325e-01
    z[2,1,3]  R876      3.1471386551856995e-01
    z[2,1,3]  R877      -2.0695790648460388e-01
    z[2,1,3]  R878      -1.8547067046165466e-01
    z[2,1,3]  R879      -3.7688681483268738e-01
    z[2,1,3]  R880      -1.6205094754695892e-02
    z[2,1,3]  R881      6.4295977354049683e-01
    z[2,1,3]  R882      7.9940801858901978e-01
    z[2,1,3]  R883      5.2079373598098755e-01
    z[2,1,3]  R884      7.0280265808105469e-01
    z[2,1,3]  R885      -4.1959017515182495e-01
    z[2,1,3]  R886      6.6072773933410645e-01
    z[2,1,3]  R887      -1.7309138178825378e-01
    z[2,1,3]  R888      3.5341003537178040e-01
    z[2,1,3]  R889      -2.0467333495616913e-01
    z[2,1,3]  R890      -1.1645700782537460e-01
    z[2,1,3]  R891      -5.9696710109710693e-01
    z[2,1,3]  R892      -4.8272362351417542e-01
    z[2,1,3]  R893      -3.1169405579566956e-01
    z[2,1,3]  R894      -2.3703196644783020e-01
    z[2,1,3]  R895      2.1501252427697182e-02
    z[2,1,3]  R896      -1.0696186125278473e-01
    z[2,1,3]  R897      1.3313871622085571e-01
    z[2,1,3]  R898      -9.0374141931533813e-02
    z[2,1,3]  R899      6.6211920976638794e-01
    z[2,1,3]  R900      6.6893637180328369e-01
    z[2,1,3]  R901      1.3354264199733734e-01
    z[2,1,3]  R902      -2.5457942485809326e-01
    z[2,1,3]  R903      4.3280407786369324e-01
    z[2,1,3]  R904      4.4959440827369690e-01
    z[2,1,3]  R905      3.7001997232437134e-01
    z[2,1,3]  R906      1.1925332993268967e-01
    z[2,1,3]  R907      5.7252246141433716e-01
    z[2,1,3]  R908      6.6730004549026489e-01
    z[2,1,3]  R909      -2.0880065858364105e-01
    z[2,1,3]  R910      0.145756796002388
    z[2,1,3]  R911      5.6535619497299194e-01
    z[2,1,3]  R912      1.3385847210884094e-01
    z[2,1,3]  R913      3.8668472319841385e-02
    z[2,1,3]  R914      -8.6569473147392273e-02
    z[2,1,3]  R915      4.1128662228584290e-01
    z[2,1,3]  R916      0.780555784702301
    z[2,1,3]  R917      5.4355055093765259e-01
    z[2,1,3]  R918      1.0336114466190338e-01
    z[2,1,3]  R919      -5.1157391071319580e-01
    z[2,1,3]  R920      -6.9933813810348511e-01
    z[2,1,3]  R921      -3.5331344604492188e-01
    z[2,1,3]  R922      9.6488796174526215e-02
    z[2,1,3]  R923      7.0612180233001709e-01
    z[2,1,3]  R924      7.0649206638336182e-01
    z[2,1,3]  R925      3.6217209696769714e-01
    z[2,1,3]  R926      3.6982360482215881e-01
    z[2,1,3]  R927      4.9719414114952087e-01
    z[2,1,3]  R928      7.3084467649459839e-01
    z[2,1,3]  R929      1.0725892148911953e-02
    z[2,1,3]  R930      2.5985460728406906e-02
    z[2,1,3]  R931      8.8379764556884766e-01
    z[2,1,3]  R932      4.0583640336990356e-01
    z[2,1,3]  R933      7.6214724779129028e-01
    z[2,1,3]  R934      6.1278021335601807e-01
    z[2,1,3]  R935      5.9152060747146606e-01
    z[2,1,3]  R936      0.557911217212677
    z[2,1,3]  R937      0.557619571685791
    z[2,1,3]  R938      5.5516934394836426e-01
    z[2,1,3]  R939      -3.0751907825469971e-01
    z[2,1,3]  R940      8.1406724452972412e-01
    z[2,1,3]  R941      0.834414541721344
    z[2,1,3]  R942      7.9402446746826172e-01
    z[2,1,3]  R943      1.5916527807712555e-01
    z[2,1,3]  R944      7.1639132499694824e-01
    z[2,1,3]  R945      6.7942863702774048e-01
    z[2,1,3]  R946      5.9608709812164307e-01
    z[2,1,3]  R947      2.4663527309894562e-01
    z[2,1,3]  R948      -1.5179876983165741e-01
    z[2,1,3]  R949      -0.399173766374588
    z[2,1,3]  R950      1.4233709871768951e-01
    z[2,1,3]  R951      1.9738802686333656e-02
    z[2,1,3]  R952      3.9049752056598663e-02
    z[2,1,3]  R953      1.8538008630275726e-01
    z[2,1,3]  R954      -3.6137807369232178e-01
    z[2,1,3]  R955      4.7713780403137207e-01
    z[2,1,3]  R956      6.3309156894683838e-01
    z[2,1,3]  R957      -8.0035179853439331e-02
    z[2,1,3]  R958      -1.6489619016647339e-01
    z[2,1,3]  R959      -5.2144950628280640e-01
    z[2,1,3]  R960      -1.9632993265986443e-02
    z[2,1,3]  R961      8.7787830829620361e-01
    z[2,1,3]  R962      0.608786940574646
    z[2,1,3]  R963      6.7621201276779175e-02
    z[2,1,3]  R964      -4.9428176134824753e-02
    z[2,1,3]  R965      -0.13033527135849
    z[2,1,3]  R966      -3.5813841223716736e-01
    z[2,1,3]  R967      -4.6140113472938538e-01
    z[2,1,3]  R968      -2.6908096671104431e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R853      -1
    z[2,1,4]  R854      1
    z[2,1,4]  R859      -3.4494879841804504e-01
    z[2,1,4]  R860      -6.2019479274749756e-01
    z[2,1,4]  R861      -1.2619766592979431e-01
    z[2,1,4]  R862      1.2386779487133026e-01
    z[2,1,4]  R863      1.1356448382139206e-01
    z[2,1,4]  R864      -0.685459315776825
    z[2,1,4]  R865      -1.7781707644462585e-01
    z[2,1,4]  R866      -5.6831365823745728e-01
    z[2,1,4]  R867      -8.9890755712985992e-02
    z[2,1,4]  R868      -0.570176362991333
    z[2,1,4]  R869      -5.1463317126035690e-02
    z[2,1,4]  R870      4.9570216797292233e-03
    z[2,1,4]  R871      -2.1611016988754272e-01
    z[2,1,4]  R872      3.0435770750045776e-01
    z[2,1,4]  R873      3.5316145420074463e-01
    z[2,1,4]  R874      2.9572373628616333e-01
    z[2,1,4]  R875      4.7489190101623535e-01
    z[2,1,4]  R876      5.1569879055023193e-01
    z[2,1,4]  R877      -2.3159846663475037e-01
    z[2,1,4]  R878      6.1637425422668457e-01
    z[2,1,4]  R879      -2.5623646378517151e-01
    z[2,1,4]  R880      2.5742354989051819e-01
    z[2,1,4]  R881      3.6368942260742188e-01
    z[2,1,4]  R882      -2.6839458942413330e-01
    z[2,1,4]  R883      -0.610956072807312
    z[2,1,4]  R884      -2.6510828733444214e-01
    z[2,1,4]  R885      7.2587326169013977e-02
    z[2,1,4]  R886      -2.4104593694210052e-01
    z[2,1,4]  R887      0.389614462852478
    z[2,1,4]  R888      -4.4050836563110352e-01
    z[2,1,4]  R889      -4.6744459867477417e-01
    z[2,1,4]  R890      -7.1737915277481079e-01
    z[2,1,4]  R891      2.9983532428741455e-01
    z[2,1,4]  R892      -1.6825450956821442e-01
    z[2,1,4]  R893      -7.1868272498250008e-03
    z[2,1,4]  R894      2.2731561958789825e-01
    z[2,1,4]  R895      -1.0865645855665207e-01
    z[2,1,4]  R896      -5.3962741047143936e-02
    z[2,1,4]  R897      -9.2491157352924347e-02
    z[2,1,4]  R898      2.4923919141292572e-01
    z[2,1,4]  R899      2.6803153753280640e-01
    z[2,1,4]  R900      1.7255203798413277e-02
    z[2,1,4]  R901      5.4292237758636475e-01
    z[2,1,4]  R902      -3.7150489515624940e-04
    z[2,1,4]  R903      -1.1027441918849945e-01
    z[2,1,4]  R904      2.9504260420799255e-01
    z[2,1,4]  R905      2.5163173675537109e-01
    z[2,1,4]  R906      0.491325318813324
    z[2,1,4]  R907      -1.8503305315971375e-01
    z[2,1,4]  R908      -3.6048030853271484e-01
    z[2,1,4]  R909      -3.8829880952835083e-01
    z[2,1,4]  R910      -1.3295862078666687e-01
    z[2,1,4]  R911      2.2157919406890869e-01
    z[2,1,4]  R912      1.8929013609886169e-01
    z[2,1,4]  R913      0.424519419670105
    z[2,1,4]  R914      4.7867378592491150e-01
    z[2,1,4]  R915      3.7761986255645752e-02
    z[2,1,4]  R916      -5.9292191267013550e-01
    z[2,1,4]  R917      4.1246834397315979e-01
    z[2,1,4]  R918      1.3459983468055725e-01
    z[2,1,4]  R919      3.4256622195243835e-01
    z[2,1,4]  R920      -1.3956628739833832e-01
    z[2,1,4]  R921      -3.4333132207393646e-03
    z[2,1,4]  R922      1.0232302546501160e-01
    z[2,1,4]  R923      1.4482711255550385e-01
    z[2,1,4]  R924      -1.5411286056041718e-01
    z[2,1,4]  R925      -4.0778371691703796e-01
    z[2,1,4]  R926      -4.0476894378662109e-01
    z[2,1,4]  R927      1.7956039309501648e-01
    z[2,1,4]  R928      3.3553296327590942e-01
    z[2,1,4]  R929      -0.539141058921814
    z[2,1,4]  R930      -3.7009525299072266e-01
    z[2,1,4]  R931      -0.0699705109000206
    z[2,1,4]  R932      -6.4956271648406982e-01
    z[2,1,4]  R933      -1.1231047660112381e-01
    z[2,1,4]  R934      3.6462938785552979e-01
    z[2,1,4]  R935      3.8490617275238037e-01
    z[2,1,4]  R936      4.4420263729989529e-03
    z[2,1,4]  R937      -0.00312254810705781
    z[2,1,4]  R938      0.638698935508728
    z[2,1,4]  R939      -4.8643991351127625e-01
    z[2,1,4]  R940      -0.00611188355833292
    z[2,1,4]  R941      2.7820187807083130e-01
    z[2,1,4]  R942      -5.2202165126800537e-01
    z[2,1,4]  R943      1.3742050528526306e-01
    z[2,1,4]  R944      1.1549419909715652e-01
    z[2,1,4]  R945      -4.0852095931768417e-02
    z[2,1,4]  R946      7.2771638631820679e-01
    z[2,1,4]  R947      1.8970780074596405e-01
    z[2,1,4]  R948      2.0771621167659760e-01
    z[2,1,4]  R949      -2.5147604942321777e-01
    z[2,1,4]  R950      -1.2091477960348129e-01
    z[2,1,4]  R951      -1.9797105342149734e-02
    z[2,1,4]  R952      -1.4402748644351959e-01
    z[2,1,4]  R953      -1.0693571716547012e-01
    z[2,1,4]  R954      3.4225240349769592e-01
    z[2,1,4]  R955      -4.7265164554119110e-02
    z[2,1,4]  R956      6.9808769226074219e-01
    z[2,1,4]  R957      2.2988188266754150e-01
    z[2,1,4]  R958      5.8784735202789307e-01
    z[2,1,4]  R959      -1.7248657345771790e-01
    z[2,1,4]  R960      -5.7757817208766937e-02
    z[2,1,4]  R961      2.5371652841567993e-01
    z[2,1,4]  R962      4.8426890862174332e-04
    z[2,1,4]  R963      1.9570238888263702e-01
    z[2,1,4]  R964      -2.5386002659797668e-01
    z[2,1,4]  R965      3.7076970934867859e-01
    z[2,1,4]  R966      3.8136407732963562e-01
    z[2,1,4]  R967      2.7218326926231384e-01
    z[2,1,4]  R968      -1.1834619939327240e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R855      -1
    z[2,1,5]  R856      1
    z[2,1,5]  R859      7.3272442817687988e-01
    z[2,1,5]  R860      5.7743382453918457e-01
    z[2,1,5]  R861      -1.1910753697156906e-01
    z[2,1,5]  R862      9.9070534110069275e-02
    z[2,1,5]  R863      1.4756646752357483e-01
    z[2,1,5]  R864      2.8583604097366333e-01
    z[2,1,5]  R865      7.0279783010482788e-01
    z[2,1,5]  R866      -5.8415614068508148e-02
    z[2,1,5]  R867      4.1297596693038940e-01
    z[2,1,5]  R868      2.5528600811958313e-01
    z[2,1,5]  R869      4.4018706679344177e-01
    z[2,1,5]  R870      1.9469425082206726e-01
    z[2,1,5]  R871      3.5704341530799866e-01
    z[2,1,5]  R872      3.5296735167503357e-01
    z[2,1,5]  R873      3.7022951245307922e-01
    z[2,1,5]  R874      -6.9216839969158173e-02
    z[2,1,5]  R875      3.6752417683601379e-01
    z[2,1,5]  R876      1.9860202074050903e-01
    z[2,1,5]  R877      -8.5678435862064362e-02
    z[2,1,5]  R878      3.0596208572387695e-01
    z[2,1,5]  R879      3.2019170466810465e-03
    z[2,1,5]  R880      -2.9590100049972534e-01
    z[2,1,5]  R881      5.0767010450363159e-01
    z[2,1,5]  R882      1.7190322279930115e-01
    z[2,1,5]  R883      6.0550201684236526e-02
    z[2,1,5]  R884      1.5664808452129364e-01
    z[2,1,5]  R885      8.2535691559314728e-02
    z[2,1,5]  R886      -1.4474037289619446e-01
    z[2,1,5]  R887      -4.6410274505615234e-01
    z[2,1,5]  R888      -2.1927395462989807e-01
    z[2,1,5]  R889      0.572059154510498
    z[2,1,5]  R890      2.0224650204181671e-01
    z[2,1,5]  R891      3.2499879598617554e-01
    z[2,1,5]  R892      5.7566791772842407e-01
    z[2,1,5]  R893      3.4185257554054260e-01
    z[2,1,5]  R894      3.9359909296035767e-01
    z[2,1,5]  R895      4.4418856501579285e-01
    z[2,1,5]  R896      9.8158992826938629e-02
    z[2,1,5]  R897      5.9080576896667480e-01
    z[2,1,5]  R898      4.4936811923980713e-01
    z[2,1,5]  R899      -4.0780159831047058e-01
    z[2,1,5]  R900      8.4364823997020721e-02
    z[2,1,5]  R901      -1.5487454831600189e-01
    z[2,1,5]  R902      -1.2571081519126892e-01
    z[2,1,5]  R903      3.1980958580970764e-01
    z[2,1,5]  R904      -3.6274725198745728e-01
    z[2,1,5]  R905      -3.0109253525733948e-01
    z[2,1,5]  R906      0.257143497467041
    z[2,1,5]  R907      1.9259685277938843e-01
    z[2,1,5]  R908      -6.8089640699326992e-03
    z[2,1,5]  R909      4.8340019583702087e-01
    z[2,1,5]  R910      2.7367675304412842e-01
    z[2,1,5]  R911      -3.3563733100891113e-01
    z[2,1,5]  R912      1.4590451121330261e-01
    z[2,1,5]  R913      -5.5856868624687195e-02
    z[2,1,5]  R914      -2.2697854042053223e-01
    z[2,1,5]  R915      5.9576934576034546e-01
    z[2,1,5]  R916      7.0278368890285492e-02
    z[2,1,5]  R917      -1.0773368924856186e-01
    z[2,1,5]  R918      1.5290841460227966e-01
    z[2,1,5]  R919      -1.1612065881490707e-01
    z[2,1,5]  R920      2.8547903895378113e-01
    z[2,1,5]  R921      -2.3959022760391235e-01
    z[2,1,5]  R922      -5.0130861997604370e-01
    z[2,1,5]  R923      1.5951279550790787e-02
    z[2,1,5]  R924      -1.2310817837715149e-01
    z[2,1,5]  R925      -5.1310826092958450e-02
    z[2,1,5]  R926      -1.8648105859756470e-01
    z[2,1,5]  R927      0.0703989565372467
    z[2,1,5]  R928      -3.9049103856086731e-01
    z[2,1,5]  R929      3.1631711125373840e-01
    z[2,1,5]  R930      -2.3108754307031631e-02
    z[2,1,5]  R931      -1.6224546730518341e-01
    z[2,1,5]  R932      3.4271883964538574e-01
    z[2,1,5]  R933      -3.0070307850837708e-01
    z[2,1,5]  R934      6.0025727748870850e-01
    z[2,1,5]  R935      1.8479205667972565e-01
    z[2,1,5]  R936      7.8040468692779541e-01
    z[2,1,5]  R937      -4.1192230582237244e-01
    z[2,1,5]  R938      -2.6334571838378906e-01
    z[2,1,5]  R939      3.3801969885826111e-01
    z[2,1,5]  R940      3.5301876068115234e-01
    z[2,1,5]  R941      -7.6438359916210175e-02
    z[2,1,5]  R942      5.9744093567132950e-02
    z[2,1,5]  R943      3.6693602800369263e-01
    z[2,1,5]  R944      2.9750075936317444e-01
    z[2,1,5]  R945      -1.7647065222263336e-01
    z[2,1,5]  R946      3.5998750478029251e-02
    z[2,1,5]  R947      1.4218123257160187e-01
    z[2,1,5]  R948      2.5382840633392334e-01
    z[2,1,5]  R949      3.3892911672592163e-01
    z[2,1,5]  R950      -4.3619722127914429e-01
    z[2,1,5]  R951      2.8107947111129761e-01
    z[2,1,5]  R952      -1.2996278703212738e-01
    z[2,1,5]  R953      3.3217015862464905e-01
    z[2,1,5]  R954      5.5026316642761230e-01
    z[2,1,5]  R955      -1.1787935346364975e-01
    z[2,1,5]  R956      1.0426397621631622e-01
    z[2,1,5]  R957      -2.3423854261636734e-02
    z[2,1,5]  R958      2.0529115572571754e-03
    z[2,1,5]  R959      4.4440496712923050e-02
    z[2,1,5]  R960      2.4768424034118652e-01
    z[2,1,5]  R961      3.6937782168388367e-01
    z[2,1,5]  R962      -6.5523582696914673e-01
    z[2,1,5]  R963      1.7465998232364655e-01
    z[2,1,5]  R964      5.2527469396591187e-01
    z[2,1,5]  R965      2.9900896549224854e-01
    z[2,1,5]  R966      -4.4401895999908447e-01
    z[2,1,5]  R967      -3.8961264491081238e-01
    z[2,1,5]  R968      -2.4709609150886536e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R857      -1
    z[2,1,6]  R858      1
    z[2,1,6]  R859      1.6707342863082886e-01
    z[2,1,6]  R860      -1.5947981178760529e-01
    z[2,1,6]  R861      1.1592247337102890e-01
    z[2,1,6]  R862      4.2579475045204163e-01
    z[2,1,6]  R863      -3.2284185290336609e-01
    z[2,1,6]  R864      8.2118771970272064e-02
    z[2,1,6]  R865      -5.2011966705322266e-01
    z[2,1,6]  R866      0.106770820915699
    z[2,1,6]  R867      -6.4204132556915283e-01
    z[2,1,6]  R868      -0.638708233833313
    z[2,1,6]  R869      1.6347558796405792e-01
    z[2,1,6]  R870      4.2418867349624634e-02
    z[2,1,6]  R871      6.5617696382105350e-03
    z[2,1,6]  R872      4.5117955654859543e-02
    z[2,1,6]  R873      3.3418801426887512e-01
    z[2,1,6]  R874      9.3657158315181732e-02
    z[2,1,6]  R875      -3.3215171098709106e-01
    z[2,1,6]  R876      2.3647336661815643e-01
    z[2,1,6]  R877      2.7245423197746277e-01
    z[2,1,6]  R878      -0.257385790348053
    z[2,1,6]  R879      -1.8693499267101288e-01
    z[2,1,6]  R880      -1.6323995590209961e-01
    z[2,1,6]  R881      -1.0348517447710037e-01
    z[2,1,6]  R882      -3.0516979098320007e-01
    z[2,1,6]  R883      -7.4036069214344025e-02
    z[2,1,6]  R884      4.0562847256660461e-01
    z[2,1,6]  R885      5.1011914014816284e-01
    z[2,1,6]  R886      -2.7839767932891846e-01
    z[2,1,6]  R887      -4.2455330491065979e-01
    z[2,1,6]  R888      4.8394781351089478e-01
    z[2,1,6]  R889      -1.0094126313924789e-01
    z[2,1,6]  R890      5.6552541255950928e-01
    z[2,1,6]  R891      1.8306763470172882e-01
    z[2,1,6]  R892      4.0054774284362793e-01
    z[2,1,6]  R893      6.7007130384445190e-01
    z[2,1,6]  R894      2.1076177060604095e-01
    z[2,1,6]  R895      1.9455462694168091e-01
    z[2,1,6]  R896      1.3794803060591221e-02
    z[2,1,6]  R897      -2.1089243888854980e-01
    z[2,1,6]  R898      -3.5103622823953629e-02
    z[2,1,6]  R899      -2.1862334012985229e-01
    z[2,1,6]  R900      -3.5250243544578552e-01
    z[2,1,6]  R901      -1.6827414929866791e-01
    z[2,1,6]  R902      -2.4363709986209869e-01
    z[2,1,6]  R903      -6.8211001157760620e-01
    z[2,1,6]  R904      2.9009729623794556e-01
    z[2,1,6]  R905      2.1386879682540894e-01
    z[2,1,6]  R906      -4.6796661615371704e-01
    z[2,1,6]  R907      -0.00897196028381586
    z[2,1,6]  R908      -2.8280505537986755e-01
    z[2,1,6]  R909      3.0765134096145630e-01
    z[2,1,6]  R910      1.4253717660903931e-01
    z[2,1,6]  R911      5.1409882307052612e-01
    z[2,1,6]  R912      -5.0827968120574951e-01
    z[2,1,6]  R913      -5.5723458528518677e-01
    z[2,1,6]  R914      6.6427379846572876e-01
    z[2,1,6]  R915      -2.6136210560798645e-01
    z[2,1,6]  R916      1.0727969557046890e-01
    z[2,1,6]  R917      -4.3989929556846619e-01
    z[2,1,6]  R918      -1.3690182566642761e-01
    z[2,1,6]  R919      -6.3550300896167755e-02
    z[2,1,6]  R920      -1.9873073324561119e-02
    z[2,1,6]  R921      5.9995472431182861e-01
    z[2,1,6]  R922      2.1704828366637230e-02
    z[2,1,6]  R923      -6.3127028942108154e-01
    z[2,1,6]  R924      -4.1776600480079651e-01
    z[2,1,6]  R925      -1.5022459626197815e-01
    z[2,1,6]  R926      2.9906576871871948e-01
    z[2,1,6]  R927      -2.5497548282146454e-02
    z[2,1,6]  R928      -5.4342824965715408e-02
    z[2,1,6]  R929      -1.7073558270931244e-01
    z[2,1,6]  R930      -1.9525590538978577e-01
    z[2,1,6]  R931      -1.7476680874824524e-01
    z[2,1,6]  R932      2.1142615377902985e-01
    z[2,1,6]  R933      3.7019538879394531e-01
    z[2,1,6]  R934      1.0266381502151489e-01
    z[2,1,6]  R935      -1.1407420039176941e-01
    z[2,1,6]  R936      -2.2610634565353394e-01
    z[2,1,6]  R937      1.9763161242008209e-01
    z[2,1,6]  R938      2.2427958250045776e-01
    z[2,1,6]  R939      4.5541429519653320e-01
    z[2,1,6]  R940      3.5498014092445374e-01
    z[2,1,6]  R941      2.5778535008430481e-01
    z[2,1,6]  R942      0.0934520810842514
    z[2,1,6]  R943      -3.2309833168983459e-01
    z[2,1,6]  R944      -4.5556899905204773e-01
    z[2,1,6]  R945      0.695705235004425
    z[2,1,6]  R946      -2.8095710277557373e-01
    z[2,1,6]  R947      -1.2208689749240875e-01
    z[2,1,6]  R948      1.3990619219839573e-02
    z[2,1,6]  R949      3.6184132099151611e-01
    z[2,1,6]  R950      3.4200161695480347e-01
    z[2,1,6]  R951      5.1040965318679810e-01
    z[2,1,6]  R952      0.277180939912796
    z[2,1,6]  R953      -6.6973221302032471e-01
    z[2,1,6]  R954      -3.9014154672622681e-01
    z[2,1,6]  R955      -1.2053254991769791e-01
    z[2,1,6]  R956      -2.9033371806144714e-01
    z[2,1,6]  R957      4.1502752900123596e-01
    z[2,1,6]  R958      -3.0794525519013405e-03
    z[2,1,6]  R959      3.9402934908866882e-01
    z[2,1,6]  R960      -1.4269025623798370e-01
    z[2,1,6]  R961      1.5831559430807829e-03
    z[2,1,6]  R962      7.2386696934700012e-02
    z[2,1,6]  R963      2.4910837411880493e-01
    z[2,1,6]  R964      -5.6955751031637192e-02
    z[2,1,6]  R965      -4.5883330702781677e-01
    z[2,1,6]  R966      -4.3563794344663620e-02
    z[2,1,6]  R967      1.9896394014358521e-01
    z[2,1,6]  R968      -3.3873987197875977e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R969      -1
    z[1,5,0]  R970      1
    z[1,5,0]  R983      1.2190082669258118e-01
    z[1,5,0]  R984      8.7008059024810791e-02
    z[1,5,0]  R985      3.0221480131149292e-01
    z[1,5,0]  R986      2.6016193628311157e-01
    z[1,5,0]  R987      2.4748301506042480e-01
    z[1,5,0]  R988      7.8136193752288818e-01
    z[1,5,0]  R989      4.5540583133697510e-01
    z[1,5,0]  R990      -0.0655539408326149
    z[1,5,0]  R991      -9.9040046334266663e-02
    z[1,5,0]  R992      1.5701797604560852e-01
    z[1,5,0]  R993      4.4143640995025635e-01
    z[1,5,0]  R994      3.5963547229766846e-01
    z[1,5,0]  R995      -2.4248990416526794e-01
    z[1,5,0]  R996      1.7267766594886780e-01
    z[1,5,0]  R997      -8.9693062007427216e-02
    z[1,5,0]  R998      2.3396338522434235e-01
    z[1,5,0]  R999      -1.8763886392116547e-01
    z[1,5,0]  R1000     6.3462473452091217e-02
    z[1,5,0]  R1001     5.1345992088317871e-01
    z[1,5,0]  R1002     -2.9811403155326843e-01
    z[1,5,0]  R1003     0.645882785320282
    z[1,5,0]  R1004     6.6964232921600342e-01
    z[1,5,0]  R1005     3.2339587807655334e-01
    z[1,5,0]  R1006     0.0756298080086708
    z[1,5,0]  R1007     1.8386992812156677e-01
    z[1,5,0]  R1008     2.7939921617507935e-01
    z[1,5,0]  R1009     2.6959127187728882e-01
    z[1,5,0]  R1010     5.9965625405311584e-02
    z[1,5,0]  R1011     3.8612468633800745e-03
    z[1,5,0]  R1012     -3.8516032695770264e-01
    z[1,5,0]  R1013     2.8719830513000488e-01
    z[1,5,0]  R1014     -1.0021450370550156e-01
    z[1,5,0]  R1015     -1.3037898577749729e-02
    z[1,5,0]  R1016     2.0253281295299530e-01
    z[1,5,0]  R1017     1.2343436479568481e-01
    z[1,5,0]  R1018     1.8908047676086426e-01
    z[1,5,0]  R1019     -3.3509114384651184e-01
    z[1,5,0]  R1020     -2.0382659137248993e-01
    z[1,5,0]  R1021     7.2123610973358154e-01
    z[1,5,0]  R1022     2.8315272927284241e-01
    z[1,5,0]  R1023     2.6582491397857666e-01
    z[1,5,0]  R1024     -1.4259302616119385e-01
    z[1,5,0]  R1025     1.0283294320106506e-01
    z[1,5,0]  R1026     3.0567729473114014e-01
    z[1,5,0]  R1027     1.2950356304645538e-01
    z[1,5,0]  R1028     2.6565348729491234e-02
    z[1,5,0]  R1029     -8.7781930342316628e-03
    z[1,5,0]  R1030     -9.1276951134204865e-02
    z[1,5,0]  R1031     5.2722871303558350e-01
    z[1,5,0]  R1032     1.9307661568745971e-04
    z[1,5,0]  R1033     7.6995693147182465e-02
    z[1,5,0]  R1034     -1.2734183669090271e-01
    z[1,5,0]  R1035     3.3917301893234253e-01
    z[1,5,0]  R1036     2.6374366134405136e-02
    z[1,5,0]  R1037     8.2131153345108032e-01
    z[1,5,0]  R1038     4.5522559434175491e-02
    z[1,5,0]  R1039     2.7312453836202621e-02
    z[1,5,0]  R1040     -1.0336112976074219e-01
    z[1,5,0]  R1041     -3.2615110278129578e-01
    z[1,5,0]  R1042     -3.4594023227691650e-01
    z[1,5,0]  R1043     2.8148117661476135e-01
    z[1,5,0]  R1044     3.4922760725021362e-01
    z[1,5,0]  R1045     3.0996146798133850e-01
    z[1,5,0]  R1046     1.2708684802055359e-01
    z[1,5,0]  R1047     1.3786189258098602e-01
    z[1,5,0]  R1048     3.7735259532928467e-01
    z[1,5,0]  R1049     2.9833212494850159e-01
    z[1,5,0]  R1050     -1.2803736329078674e-01
    z[1,5,0]  R1051     -1.1106203496456146e-01
    z[1,5,0]  R1052     2.8687962330877781e-03
    z[1,5,0]  R1053     2.8190642595291138e-01
    z[1,5,0]  R1054     3.4562137722969055e-01
    z[1,5,0]  R1055     -2.3160532116889954e-02
    z[1,5,0]  R1056     -1.2331695854663849e-01
    z[1,5,0]  R1057     3.4004177898168564e-02
    z[1,5,0]  R1058     -4.1489630937576294e-01
    z[1,5,0]  R1059     -2.6557642221450806e-01
    z[1,5,0]  R1060     -1.1845907568931580e-01
    z[1,5,0]  R1061     -1.9464151561260223e-01
    z[1,5,0]  R1062     2.8730336576700211e-02
    z[1,5,0]  R1063     3.2114568352699280e-01
    z[1,5,0]  R1064     1.2799820979125798e-04
    z[1,5,0]  R1065     5.5457610636949539e-02
    z[1,5,0]  R1066     5.2234575152397156e-02
    z[1,5,0]  R1067     8.2452498376369476e-02
    z[1,5,0]  R1068     4.3067926168441772e-01
    z[1,5,0]  R1069     -1.3426003046333790e-02
    z[1,5,0]  R1070     -2.3636072874069214e-02
    z[1,5,0]  R1071     5.2429482340812683e-02
    z[1,5,0]  R1072     -7.5056720525026321e-03
    z[1,5,0]  R1073     7.0652149617671967e-02
    z[1,5,0]  R1074     2.7111560106277466e-01
    z[1,5,0]  R1075     1.9415850937366486e-01
    z[1,5,0]  R1076     1.1719628423452377e-01
    z[1,5,0]  R1077     -7.2154819965362549e-02
    z[1,5,0]  R1078     -1.4037913084030151e-01
    z[1,5,0]  R1079     -5.4189842194318771e-03
    z[1,5,0]  R1080     1.1443827301263809e-01
    z[1,5,0]  R1081     -1.8866352736949921e-01
    z[1,5,0]  R1082     4.2419081926345825e-01
    z[1,5,0]  R1083     2.6447597146034241e-01
    z[1,5,0]  R1084     4.4845908880233765e-02
    z[1,5,0]  R1085     -7.4253201484680176e-02
    z[1,5,0]  R1086     -1.0336951166391373e-01
    z[1,5,0]  R1087     -2.4555101990699768e-03
    z[1,5,0]  R1088     -1.0886755585670471e-01
    z[1,5,0]  R1089     -4.8941407352685928e-02
    z[1,5,0]  R1090     -1.8093822896480560e-01
    z[1,5,0]  R1091     -1.2569734454154968e-01
    z[1,5,0]  R1092     1.0660402476787567e-01
    z[1,5,0]  R1093     1.9257423281669617e-01
    z[1,5,0]  R1094     2.3337945342063904e-01
    z[1,5,0]  R1095     2.6228129863739014e-01
    z[1,5,0]  R1096     3.3634158968925476e-01
    z[1,5,0]  R1097     -9.8939023911952972e-02
    z[1,5,0]  R1098     -4.1293105483055115e-01
    z[1,5,0]  R1099     2.5201907753944397e-01
    z[1,5,0]  R1100     -3.2411229610443115e-01
    z[1,5,0]  R1101     3.0029773712158203e-01
    z[1,5,0]  R1102     -1.3278488814830780e-01
    z[1,5,0]  R1103     -1.9313894212245941e-01
    z[1,5,0]  R1104     -0.614051342010498
    z[1,5,0]  R1105     3.2096934318542480e-01
    z[1,5,0]  R1106     3.5385772585868835e-02
    z[1,5,0]  R1107     -0.0406770296394825
    z[1,5,0]  R1108     -5.2866542339324951e-01
    z[1,5,0]  R1109     -4.5177474617958069e-01
    z[1,5,0]  R1110     4.5386098325252533e-02
    z[1,5,0]  R1111     -1.3763718307018280e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R971      -1
    z[1,5,1]  R972      1
    z[1,5,1]  R983      -1.6991697251796722e-01
    z[1,5,1]  R984      -1.2021198123693466e-01
    z[1,5,1]  R985      5.0322914123535156e-01
    z[1,5,1]  R986      4.2183393239974976e-01
    z[1,5,1]  R987      4.2930355668067932e-01
    z[1,5,1]  R988      1.9643928110599518e-01
    z[1,5,1]  R989      7.2861391305923462e-01
    z[1,5,1]  R990      7.2586512565612793e-01
    z[1,5,1]  R991      6.2076145410537720e-01
    z[1,5,1]  R992      5.3477644920349121e-01
    z[1,5,1]  R993      -5.7719420641660690e-02
    z[1,5,1]  R994      4.3008357286453247e-01
    z[1,5,1]  R995      7.1668881177902222e-01
    z[1,5,1]  R996      -0.883419394493103
    z[1,5,1]  R997      3.3213075995445251e-01
    z[1,5,1]  R998      6.6292655467987061e-01
    z[1,5,1]  R999      7.8095215559005737e-01
    z[1,5,1]  R1000     5.9684544801712036e-01
    z[1,5,1]  R1001     4.7032064199447632e-01
    z[1,5,1]  R1002     3.3033528923988342e-01
    z[1,5,1]  R1003     -1.8666094541549683e-01
    z[1,5,1]  R1004     4.6317240595817566e-01
    z[1,5,1]  R1005     -1.3988637924194336e-01
    z[1,5,1]  R1006     5.5366027355194092e-01
    z[1,5,1]  R1007     2.9774689674377441e-01
    z[1,5,1]  R1008     5.5339790880680084e-02
    z[1,5,1]  R1009     -5.6207644939422607e-01
    z[1,5,1]  R1010     1.1363073438405991e-01
    z[1,5,1]  R1011     5.7327234745025635e-01
    z[1,5,1]  R1012     8.8000553846359253e-01
    z[1,5,1]  R1013     8.5935018956661224e-02
    z[1,5,1]  R1014     1.2243407964706421e-01
    z[1,5,1]  R1015     1.2666161358356476e-01
    z[1,5,1]  R1016     -1.5021903812885284e-01
    z[1,5,1]  R1017     2.1114858984947205e-01
    z[1,5,1]  R1018     -4.9134314060211182e-01
    z[1,5,1]  R1019     3.0135393142700195e-01
    z[1,5,1]  R1020     4.8563334345817566e-01
    z[1,5,1]  R1021     -0.431154727935791
    z[1,5,1]  R1022     3.3930018544197083e-01
    z[1,5,1]  R1023     -5.1909035444259644e-01
    z[1,5,1]  R1024     -8.2570560276508331e-02
    z[1,5,1]  R1025     0.361701637506485
    z[1,5,1]  R1026     2.4564903974533081e-01
    z[1,5,1]  R1027     2.9356616735458374e-01
    z[1,5,1]  R1028     1.5386205911636353e-01
    z[1,5,1]  R1029     -5.1868957281112671e-01
    z[1,5,1]  R1030     8.2093916833400726e-02
    z[1,5,1]  R1031     -4.4982436299324036e-01
    z[1,5,1]  R1032     3.2640573382377625e-01
    z[1,5,1]  R1033     4.1391676664352417e-01
    z[1,5,1]  R1034     -2.6323437690734863e-01
    z[1,5,1]  R1035     -1.6353602707386017e-01
    z[1,5,1]  R1036     -8.1723339855670929e-02
    z[1,5,1]  R1037     5.5401228368282318e-02
    z[1,5,1]  R1038     -1.9173620641231537e-01
    z[1,5,1]  R1039     -5.3725861012935638e-02
    z[1,5,1]  R1040     6.6931024193763733e-02
    z[1,5,1]  R1041     7.4424481391906738e-01
    z[1,5,1]  R1042     6.7177957296371460e-01
    z[1,5,1]  R1043     4.7372713685035706e-01
    z[1,5,1]  R1044     -1.3733093440532684e-01
    z[1,5,1]  R1045     -5.6713593006134033e-01
    z[1,5,1]  R1046     5.3955519199371338e-01
    z[1,5,1]  R1047     7.9679578542709351e-02
    z[1,5,1]  R1048     -2.2865033149719238e-01
    z[1,5,1]  R1049     4.1618752479553223e-01
    z[1,5,1]  R1050     4.9980757758021355e-03
    z[1,5,1]  R1051     0.787831723690033
    z[1,5,1]  R1052     7.3669201135635376e-01
    z[1,5,1]  R1053     -3.4342417120933533e-01
    z[1,5,1]  R1054     5.0888639688491821e-01
    z[1,5,1]  R1055     -1.3661010563373566e-01
    z[1,5,1]  R1056     -4.2335250973701477e-01
    z[1,5,1]  R1057     7.9447090625762939e-01
    z[1,5,1]  R1058     6.1699497699737549e-01
    z[1,5,1]  R1059     6.7754375934600830e-01
    z[1,5,1]  R1060     -7.0698434114456177e-01
    z[1,5,1]  R1061     -6.3214230537414551e-01
    z[1,5,1]  R1062     -7.0445472002029419e-01
    z[1,5,1]  R1063     5.0134855508804321e-01
    z[1,5,1]  R1064     4.5813700556755066e-01
    z[1,5,1]  R1065     0.432682067155838
    z[1,5,1]  R1066     4.6237125992774963e-01
    z[1,5,1]  R1067     5.0908207893371582e-01
    z[1,5,1]  R1068     4.8563095927238464e-01
    z[1,5,1]  R1069     8.2065206766128540e-01
    z[1,5,1]  R1070     3.0611601471900940e-01
    z[1,5,1]  R1071     5.0296491384506226e-01
    z[1,5,1]  R1072     0.327528178691864
    z[1,5,1]  R1073     -8.1756854057312012e-01
    z[1,5,1]  R1074     -5.9623104333877563e-01
    z[1,5,1]  R1075     -7.5222784280776978e-01
    z[1,5,1]  R1076     -4.9451699852943420e-01
    z[1,5,1]  R1077     -6.9143062829971313e-01
    z[1,5,1]  R1078     -7.4074578285217285e-01
    z[1,5,1]  R1079     -6.7811751365661621e-01
    z[1,5,1]  R1080     -5.4823744297027588e-01
    z[1,5,1]  R1081     -0.549148678779602
    z[1,5,1]  R1082     -5.0057750940322876e-01
    z[1,5,1]  R1083     2.4117852747440338e-01
    z[1,5,1]  R1084     3.7038120627403259e-01
    z[1,5,1]  R1085     0.503020703792572
    z[1,5,1]  R1086     7.1465331315994263e-01
    z[1,5,1]  R1087     1.6307540237903595e-01
    z[1,5,1]  R1088     5.4639625549316406e-01
    z[1,5,1]  R1089     5.1106256246566772e-01
    z[1,5,1]  R1090     2.0135138928890228e-01
    z[1,5,1]  R1091     5.1603823900222778e-01
    z[1,5,1]  R1092     -4.3186736106872559e-01
    z[1,5,1]  R1093     7.7884471416473389e-01
    z[1,5,1]  R1094     0.612871527671814
    z[1,5,1]  R1095     1.5017915284261107e-03
    z[1,5,1]  R1096     1.7503488063812256e-01
    z[1,5,1]  R1097     6.4956796169281006e-01
    z[1,5,1]  R1098     5.9445953369140625e-01
    z[1,5,1]  R1099     1.1809966713190079e-01
    z[1,5,1]  R1100     -1.1558468639850616e-01
    z[1,5,1]  R1101     2.3782048374414444e-02
    z[1,5,1]  R1102     4.9197566509246826e-01
    z[1,5,1]  R1103     4.1021221876144409e-01
    z[1,5,1]  R1104     5.9973281621932983e-01
    z[1,5,1]  R1105     4.4935470819473267e-01
    z[1,5,1]  R1106     2.8569960594177246e-01
    z[1,5,1]  R1107     4.9081340432167053e-01
    z[1,5,1]  R1108     5.5745017528533936e-01
    z[1,5,1]  R1109     -8.5575558245182037e-02
    z[1,5,1]  R1110     5.8053910732269287e-01
    z[1,5,1]  R1111     -4.2640173435211182e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R973      -1
    z[1,5,2]  R974      1
    z[1,5,2]  R983      5.9869188070297241e-01
    z[1,5,2]  R984      2.9843065142631531e-01
    z[1,5,2]  R985      2.6460850238800049e-01
    z[1,5,2]  R986      3.4760057926177979e-02
    z[1,5,2]  R987      3.0230289697647095e-01
    z[1,5,2]  R988      -2.0901657640933990e-01
    z[1,5,2]  R989      1.1959838122129440e-01
    z[1,5,2]  R990      6.6681647300720215e-01
    z[1,5,2]  R991      -4.3016105890274048e-01
    z[1,5,2]  R992      -6.4490920305252075e-01
    z[1,5,2]  R993      2.7831861376762390e-01
    z[1,5,2]  R994      3.2640692591667175e-01
    z[1,5,2]  R995      -2.5030997395515442e-01
    z[1,5,2]  R996      2.2311314940452576e-01
    z[1,5,2]  R997      3.3854430913925171e-01
    z[1,5,2]  R998      2.9363412410020828e-02
    z[1,5,2]  R999      -1.3518701493740082e-01
    z[1,5,2]  R1000     -3.1465950608253479e-01
    z[1,5,2]  R1001     -3.4053522348403931e-01
    z[1,5,2]  R1002     3.8307452201843262e-01
    z[1,5,2]  R1003     1.5904194116592407e-01
    z[1,5,2]  R1004     4.5045712590217590e-01
    z[1,5,2]  R1005     -3.6079365015029907e-01
    z[1,5,2]  R1006     5.9527742862701416e-01
    z[1,5,2]  R1007     6.1822026968002319e-01
    z[1,5,2]  R1008     4.3528366088867188e-01
    z[1,5,2]  R1009     -1.3250146806240082e-01
    z[1,5,2]  R1010     7.8870460391044617e-02
    z[1,5,2]  R1011     -2.5467187166213989e-02
    z[1,5,2]  R1012     -7.9486265778541565e-02
    z[1,5,2]  R1013     7.1662414073944092e-01
    z[1,5,2]  R1014     6.2009769678115845e-01
    z[1,5,2]  R1015     6.6452652215957642e-01
    z[1,5,2]  R1016     8.1538534164428711e-01
    z[1,5,2]  R1017     1.4778582751750946e-01
    z[1,5,2]  R1018     1.0131459683179855e-01
    z[1,5,2]  R1019     0.688653290271759
    z[1,5,2]  R1020     5.4570317268371582e-01
    z[1,5,2]  R1021     -9.4202525913715363e-02
    z[1,5,2]  R1022     -5.0470698624849319e-02
    z[1,5,2]  R1023     4.8978269100189209e-01
    z[1,5,2]  R1024     8.9249360561370850e-01
    z[1,5,2]  R1025     1.2544372677803040e-01
    z[1,5,2]  R1026     3.1213113665580750e-01
    z[1,5,2]  R1027     -2.7585986256599426e-01
    z[1,5,2]  R1028     -3.1035137176513672e-01
    z[1,5,2]  R1029     -4.3089857697486877e-01
    z[1,5,2]  R1030     -1.1614146083593369e-01
    z[1,5,2]  R1031     -5.8289320440962911e-04
    z[1,5,2]  R1032     -2.4012021720409393e-01
    z[1,5,2]  R1033     4.1218116879463196e-01
    z[1,5,2]  R1034     -3.3402808010578156e-02
    z[1,5,2]  R1035     -1.1080418527126312e-01
    z[1,5,2]  R1036     2.7810338139533997e-01
    z[1,5,2]  R1037     1.9780190289020538e-01
    z[1,5,2]  R1038     -3.7223607301712036e-01
    z[1,5,2]  R1039     1.3389432430267334e-01
    z[1,5,2]  R1040     -1.4040251076221466e-01
    z[1,5,2]  R1041     -4.5583599805831909e-01
    z[1,5,2]  R1042     -5.4609888792037964e-01
    z[1,5,2]  R1043     4.7746098041534424e-01
    z[1,5,2]  R1044     7.1907371282577515e-01
    z[1,5,2]  R1045     4.9191007018089294e-01
    z[1,5,2]  R1046     7.5943440198898315e-01
    z[1,5,2]  R1047     6.0824835300445557e-01
    z[1,5,2]  R1048     3.2030174136161804e-01
    z[1,5,2]  R1049     6.9243609905242920e-01
    z[1,5,2]  R1050     -0.016898138448596
    z[1,5,2]  R1051     -3.6733978986740112e-01
    z[1,5,2]  R1052     -2.9070207476615906e-01
    z[1,5,2]  R1053     5.8625358343124390e-01
    z[1,5,2]  R1054     0.732223391532898
    z[1,5,2]  R1055     -9.6521571278572083e-02
    z[1,5,2]  R1056     -1.9231060519814491e-02
    z[1,5,2]  R1057     -0.481898695230484
    z[1,5,2]  R1058     -3.1801348924636841e-01
    z[1,5,2]  R1059     -1.2653756141662598e-01
    z[1,5,2]  R1060     -1.1570768803358078e-01
    z[1,5,2]  R1061     -2.9008877277374268e-01
    z[1,5,2]  R1062     -4.9061864614486694e-01
    z[1,5,2]  R1063     5.5939173698425293e-01
    z[1,5,2]  R1064     -9.1380871832370758e-02
    z[1,5,2]  R1065     -5.2853405475616455e-01
    z[1,5,2]  R1066     -7.1074366569519043e-01
    z[1,5,2]  R1067     -7.0286047458648682e-01
    z[1,5,2]  R1068     2.5660511851310730e-01
    z[1,5,2]  R1069     -3.3238753676414490e-01
    z[1,5,2]  R1070     -0.294884592294693
    z[1,5,2]  R1071     -6.1701703071594238e-01
    z[1,5,2]  R1072     -5.3743177652359009e-01
    z[1,5,2]  R1073     1.2026625871658325e-01
    z[1,5,2]  R1074     3.4989011287689209e-01
    z[1,5,2]  R1075     -1.1586213111877441e-01
    z[1,5,2]  R1076     -9.3651607632637024e-02
    z[1,5,2]  R1077     -3.5125061869621277e-01
    z[1,5,2]  R1078     2.9583710432052612e-01
    z[1,5,2]  R1079     1.0643537156283855e-02
    z[1,5,2]  R1080     -2.1485063433647156e-01
    z[1,5,2]  R1081     1.8233244121074677e-01
    z[1,5,2]  R1082     -4.7685351222753525e-02
    z[1,5,2]  R1083     -1.6669457778334618e-02
    z[1,5,2]  R1084     1.2669166922569275e-01
    z[1,5,2]  R1085     1.1230615526437759e-01
    z[1,5,2]  R1086     1.9065700471401215e-01
    z[1,5,2]  R1087     4.4778954982757568e-01
    z[1,5,2]  R1088     3.6488610506057739e-01
    z[1,5,2]  R1089     2.6896793395280838e-02
    z[1,5,2]  R1090     1.7822082340717316e-01
    z[1,5,2]  R1091     1.7628322541713715e-01
    z[1,5,2]  R1092     1.2772007286548615e-01
    z[1,5,2]  R1093     -2.4267971515655518e-01
    z[1,5,2]  R1094     -1.1833103001117706e-01
    z[1,5,2]  R1095     -2.2095292806625366e-01
    z[1,5,2]  R1096     2.4815934896469116e-01
    z[1,5,2]  R1097     0.269465833902359
    z[1,5,2]  R1098     2.2802762687206268e-01
    z[1,5,2]  R1099     2.2638346254825592e-01
    z[1,5,2]  R1100     -4.9153584241867065e-01
    z[1,5,2]  R1101     -1.8757960200309753e-01
    z[1,5,2]  R1102     1.7887100577354431e-01
    z[1,5,2]  R1103     -8.5737422108650208e-02
    z[1,5,2]  R1104     2.5774728506803513e-02
    z[1,5,2]  R1105     3.8702264428138733e-01
    z[1,5,2]  R1106     4.7996929287910461e-01
    z[1,5,2]  R1107     -3.9740979671478271e-01
    z[1,5,2]  R1108     4.5599198341369629e-01
    z[1,5,2]  R1109     -1.8403373658657074e-01
    z[1,5,2]  R1110     3.6123567819595337e-01
    z[1,5,2]  R1111     5.4145264625549316e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R975      -1
    z[1,5,3]  R976      1
    z[1,5,3]  R983      -2.0467333495616913e-01
    z[1,5,3]  R984      -1.1645700782537460e-01
    z[1,5,3]  R985      -5.9696710109710693e-01
    z[1,5,3]  R986      -4.8272362351417542e-01
    z[1,5,3]  R987      -3.1169405579566956e-01
    z[1,5,3]  R988      -2.3703196644783020e-01
    z[1,5,3]  R989      2.1501252427697182e-02
    z[1,5,3]  R990      -1.0696186125278473e-01
    z[1,5,3]  R991      1.3313871622085571e-01
    z[1,5,3]  R992      -9.0374141931533813e-02
    z[1,5,3]  R993      6.6211920976638794e-01
    z[1,5,3]  R994      6.6893637180328369e-01
    z[1,5,3]  R995      1.3354264199733734e-01
    z[1,5,3]  R996      -2.5457942485809326e-01
    z[1,5,3]  R997      4.3280407786369324e-01
    z[1,5,3]  R998      4.4959440827369690e-01
    z[1,5,3]  R999      3.7001997232437134e-01
    z[1,5,3]  R1000     1.1925332993268967e-01
    z[1,5,3]  R1001     5.7252246141433716e-01
    z[1,5,3]  R1002     6.6730004549026489e-01
    z[1,5,3]  R1003     -2.0880065858364105e-01
    z[1,5,3]  R1004     0.145756796002388
    z[1,5,3]  R1005     5.6535619497299194e-01
    z[1,5,3]  R1006     1.3385847210884094e-01
    z[1,5,3]  R1007     3.8668472319841385e-02
    z[1,5,3]  R1008     -8.6569473147392273e-02
    z[1,5,3]  R1009     4.1128662228584290e-01
    z[1,5,3]  R1010     0.780555784702301
    z[1,5,3]  R1011     5.4355055093765259e-01
    z[1,5,3]  R1012     1.0336114466190338e-01
    z[1,5,3]  R1013     -5.1157391071319580e-01
    z[1,5,3]  R1014     -6.9933813810348511e-01
    z[1,5,3]  R1015     -3.5331344604492188e-01
    z[1,5,3]  R1016     9.6488796174526215e-02
    z[1,5,3]  R1017     7.0612180233001709e-01
    z[1,5,3]  R1018     7.0649206638336182e-01
    z[1,5,3]  R1019     3.6217209696769714e-01
    z[1,5,3]  R1020     3.6982360482215881e-01
    z[1,5,3]  R1021     4.9719414114952087e-01
    z[1,5,3]  R1022     7.3084467649459839e-01
    z[1,5,3]  R1023     1.0725892148911953e-02
    z[1,5,3]  R1024     2.5985460728406906e-02
    z[1,5,3]  R1025     8.8379764556884766e-01
    z[1,5,3]  R1026     4.0583640336990356e-01
    z[1,5,3]  R1027     7.6214724779129028e-01
    z[1,5,3]  R1028     6.1278021335601807e-01
    z[1,5,3]  R1029     5.9152060747146606e-01
    z[1,5,3]  R1030     0.557911217212677
    z[1,5,3]  R1031     0.557619571685791
    z[1,5,3]  R1032     5.5516934394836426e-01
    z[1,5,3]  R1033     -3.0751907825469971e-01
    z[1,5,3]  R1034     8.1406724452972412e-01
    z[1,5,3]  R1035     0.834414541721344
    z[1,5,3]  R1036     7.9402446746826172e-01
    z[1,5,3]  R1037     1.5916527807712555e-01
    z[1,5,3]  R1038     7.1639132499694824e-01
    z[1,5,3]  R1039     6.7942863702774048e-01
    z[1,5,3]  R1040     5.9608709812164307e-01
    z[1,5,3]  R1041     2.4663527309894562e-01
    z[1,5,3]  R1042     -1.5179876983165741e-01
    z[1,5,3]  R1043     -0.399173766374588
    z[1,5,3]  R1044     1.4233709871768951e-01
    z[1,5,3]  R1045     1.9738802686333656e-02
    z[1,5,3]  R1046     3.9049752056598663e-02
    z[1,5,3]  R1047     1.8538008630275726e-01
    z[1,5,3]  R1048     -3.6137807369232178e-01
    z[1,5,3]  R1049     4.7713780403137207e-01
    z[1,5,3]  R1050     6.3309156894683838e-01
    z[1,5,3]  R1051     -8.0035179853439331e-02
    z[1,5,3]  R1052     -1.6489619016647339e-01
    z[1,5,3]  R1053     -5.2144950628280640e-01
    z[1,5,3]  R1054     -1.9632993265986443e-02
    z[1,5,3]  R1055     8.7787830829620361e-01
    z[1,5,3]  R1056     0.608786940574646
    z[1,5,3]  R1057     6.7621201276779175e-02
    z[1,5,3]  R1058     -4.9428176134824753e-02
    z[1,5,3]  R1059     -0.13033527135849
    z[1,5,3]  R1060     -3.5813841223716736e-01
    z[1,5,3]  R1061     -4.6140113472938538e-01
    z[1,5,3]  R1062     -2.6908096671104431e-01
    z[1,5,3]  R1063     1.5760849416255951e-01
    z[1,5,3]  R1064     2.3670193552970886e-01
    z[1,5,3]  R1065     7.3240667581558228e-02
    z[1,5,3]  R1066     5.2571866661310196e-02
    z[1,5,3]  R1067     1.6801701486110687e-01
    z[1,5,3]  R1068     2.7998885512351990e-01
    z[1,5,3]  R1069     3.1080448627471924e-01
    z[1,5,3]  R1070     6.3498966395854950e-02
    z[1,5,3]  R1071     -0.07258290797472
    z[1,5,3]  R1072     -1.0689292103052139e-01
    z[1,5,3]  R1073     -4.5449972152709961e-01
    z[1,5,3]  R1074     -5.6289356946945190e-01
    z[1,5,3]  R1075     -4.6246212720870972e-01
    z[1,5,3]  R1076     -0.708291232585907
    z[1,5,3]  R1077     -4.3603339791297913e-01
    z[1,5,3]  R1078     -3.6672791838645935e-01
    z[1,5,3]  R1079     -5.9832257032394409e-01
    z[1,5,3]  R1080     -0.545274555683136
    z[1,5,3]  R1081     -6.8221920728683472e-01
    z[1,5,3]  R1082     -5.6845504045486450e-01
    z[1,5,3]  R1083     5.5740290880203247e-01
    z[1,5,3]  R1084     0.578544020652771
    z[1,5,3]  R1085     -6.0288065671920776e-01
    z[1,5,3]  R1086     -3.4921801090240479e-01
    z[1,5,3]  R1087     6.2654447555541992e-01
    z[1,5,3]  R1088     -5.2741795778274536e-01
    z[1,5,3]  R1089     -7.4762272834777832e-01
    z[1,5,3]  R1090     3.4952321648597717e-01
    z[1,5,3]  R1091     5.9685643762350082e-02
    z[1,5,3]  R1092     8.6430960893630981e-01
    z[1,5,3]  R1093     2.3574048280715942e-01
    z[1,5,3]  R1094     5.7690471410751343e-01
    z[1,5,3]  R1095     8.9302927255630493e-01
    z[1,5,3]  R1096     9.8066650331020355e-02
    z[1,5,3]  R1097     -2.5251312181353569e-02
    z[1,5,3]  R1098     -6.1161148548126221e-01
    z[1,5,3]  R1099     5.6304007768630981e-01
    z[1,5,3]  R1100     0.721450924873352
    z[1,5,3]  R1101     -0.00906460452824831
    z[1,5,3]  R1102     -4.1713351011276245e-01
    z[1,5,3]  R1103     0.0668509304523468
    z[1,5,3]  R1104     -4.4703356921672821e-02
    z[1,5,3]  R1105     5.5620354413986206e-01
    z[1,5,3]  R1106     5.3038930892944336e-01
    z[1,5,3]  R1107     3.3827179670333862e-01
    z[1,5,3]  R1108     2.0165410637855530e-01
    z[1,5,3]  R1109     6.4370816946029663e-01
    z[1,5,3]  R1110     -1.5139554627239704e-02
    z[1,5,3]  R1111     5.7504045963287354e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R977      -1
    z[1,5,4]  R978      1
    z[1,5,4]  R983      -4.6744459867477417e-01
    z[1,5,4]  R984      -7.1737915277481079e-01
    z[1,5,4]  R985      2.9983532428741455e-01
    z[1,5,4]  R986      -1.6825450956821442e-01
    z[1,5,4]  R987      -7.1868272498250008e-03
    z[1,5,4]  R988      2.2731561958789825e-01
    z[1,5,4]  R989      -1.0865645855665207e-01
    z[1,5,4]  R990      -5.3962741047143936e-02
    z[1,5,4]  R991      -9.2491157352924347e-02
    z[1,5,4]  R992      2.4923919141292572e-01
    z[1,5,4]  R993      2.6803153753280640e-01
    z[1,5,4]  R994      1.7255203798413277e-02
    z[1,5,4]  R995      5.4292237758636475e-01
    z[1,5,4]  R996      -3.7150489515624940e-04
    z[1,5,4]  R997      -1.1027441918849945e-01
    z[1,5,4]  R998      2.9504260420799255e-01
    z[1,5,4]  R999      2.5163173675537109e-01
    z[1,5,4]  R1000     0.491325318813324
    z[1,5,4]  R1001     -1.8503305315971375e-01
    z[1,5,4]  R1002     -3.6048030853271484e-01
    z[1,5,4]  R1003     -3.8829880952835083e-01
    z[1,5,4]  R1004     -1.3295862078666687e-01
    z[1,5,4]  R1005     2.2157919406890869e-01
    z[1,5,4]  R1006     1.8929013609886169e-01
    z[1,5,4]  R1007     0.424519419670105
    z[1,5,4]  R1008     4.7867378592491150e-01
    z[1,5,4]  R1009     3.7761986255645752e-02
    z[1,5,4]  R1010     -5.9292191267013550e-01
    z[1,5,4]  R1011     4.1246834397315979e-01
    z[1,5,4]  R1012     1.3459983468055725e-01
    z[1,5,4]  R1013     3.4256622195243835e-01
    z[1,5,4]  R1014     -1.3956628739833832e-01
    z[1,5,4]  R1015     -3.4333132207393646e-03
    z[1,5,4]  R1016     1.0232302546501160e-01
    z[1,5,4]  R1017     1.4482711255550385e-01
    z[1,5,4]  R1018     -1.5411286056041718e-01
    z[1,5,4]  R1019     -4.0778371691703796e-01
    z[1,5,4]  R1020     -4.0476894378662109e-01
    z[1,5,4]  R1021     1.7956039309501648e-01
    z[1,5,4]  R1022     3.3553296327590942e-01
    z[1,5,4]  R1023     -0.539141058921814
    z[1,5,4]  R1024     -3.7009525299072266e-01
    z[1,5,4]  R1025     -0.0699705109000206
    z[1,5,4]  R1026     -6.4956271648406982e-01
    z[1,5,4]  R1027     -1.1231047660112381e-01
    z[1,5,4]  R1028     3.6462938785552979e-01
    z[1,5,4]  R1029     3.8490617275238037e-01
    z[1,5,4]  R1030     4.4420263729989529e-03
    z[1,5,4]  R1031     -0.00312254810705781
    z[1,5,4]  R1032     0.638698935508728
    z[1,5,4]  R1033     -4.8643991351127625e-01
    z[1,5,4]  R1034     -0.00611188355833292
    z[1,5,4]  R1035     2.7820187807083130e-01
    z[1,5,4]  R1036     -5.2202165126800537e-01
    z[1,5,4]  R1037     1.3742050528526306e-01
    z[1,5,4]  R1038     1.1549419909715652e-01
    z[1,5,4]  R1039     -4.0852095931768417e-02
    z[1,5,4]  R1040     7.2771638631820679e-01
    z[1,5,4]  R1041     1.8970780074596405e-01
    z[1,5,4]  R1042     2.0771621167659760e-01
    z[1,5,4]  R1043     -2.5147604942321777e-01
    z[1,5,4]  R1044     -1.2091477960348129e-01
    z[1,5,4]  R1045     -1.9797105342149734e-02
    z[1,5,4]  R1046     -1.4402748644351959e-01
    z[1,5,4]  R1047     -1.0693571716547012e-01
    z[1,5,4]  R1048     3.4225240349769592e-01
    z[1,5,4]  R1049     -4.7265164554119110e-02
    z[1,5,4]  R1050     6.9808769226074219e-01
    z[1,5,4]  R1051     2.2988188266754150e-01
    z[1,5,4]  R1052     5.8784735202789307e-01
    z[1,5,4]  R1053     -1.7248657345771790e-01
    z[1,5,4]  R1054     -5.7757817208766937e-02
    z[1,5,4]  R1055     2.5371652841567993e-01
    z[1,5,4]  R1056     4.8426890862174332e-04
    z[1,5,4]  R1057     1.9570238888263702e-01
    z[1,5,4]  R1058     -2.5386002659797668e-01
    z[1,5,4]  R1059     3.7076970934867859e-01
    z[1,5,4]  R1060     3.8136407732963562e-01
    z[1,5,4]  R1061     2.7218326926231384e-01
    z[1,5,4]  R1062     -1.1834619939327240e-01
    z[1,5,4]  R1063     -5.2295696735382080e-01
    z[1,5,4]  R1064     -7.3008544743061066e-02
    z[1,5,4]  R1065     6.6151313483715057e-02
    z[1,5,4]  R1066     -3.2162305712699890e-01
    z[1,5,4]  R1067     0.0360804907977581
    z[1,5,4]  R1068     -3.5811248421669006e-01
    z[1,5,4]  R1069     -2.3946642875671387e-01
    z[1,5,4]  R1070     -2.9947438836097717e-01
    z[1,5,4]  R1071     -4.9453905224800110e-01
    z[1,5,4]  R1072     -3.8763910531997681e-01
    z[1,5,4]  R1073     -1.1475600302219391e-01
    z[1,5,4]  R1074     -4.1680745780467987e-03
    z[1,5,4]  R1075     2.9905638098716736e-01
    z[1,5,4]  R1076     7.8380726277828217e-02
    z[1,5,4]  R1077     2.1771165728569031e-01
    z[1,5,4]  R1078     2.9940694570541382e-01
    z[1,5,4]  R1079     4.2538410425186157e-01
    z[1,5,4]  R1080     -0.0423019640147686
    z[1,5,4]  R1081     2.6569724082946777e-01
    z[1,5,4]  R1082     5.8113500475883484e-02
    z[1,5,4]  R1083     -1.3618029654026031e-01
    z[1,5,4]  R1084     5.5409145355224609e-01
    z[1,5,4]  R1085     4.0063974261283875e-01
    z[1,5,4]  R1086     0.537505567073822
    z[1,5,4]  R1087     5.9833395481109619e-01
    z[1,5,4]  R1088     3.5292837023735046e-01
    z[1,5,4]  R1089     1.5173371136188507e-01
    z[1,5,4]  R1090     8.2123500108718872e-01
    z[1,5,4]  R1091     7.8610116243362427e-01
    z[1,5,4]  R1092     -3.6398649215698242e-02
    z[1,5,4]  R1093     1.8064025044441223e-01
    z[1,5,4]  R1094     0.0169846098870039
    z[1,5,4]  R1095     -2.3943005502223969e-01
    z[1,5,4]  R1096     -6.4937502145767212e-01
    z[1,5,4]  R1097     5.4747790098190308e-01
    z[1,5,4]  R1098     1.4513424038887024e-01
    z[1,5,4]  R1099     -2.9419302940368652e-01
    z[1,5,4]  R1100     2.1047417819499969e-01
    z[1,5,4]  R1101     -0.92336106300354
    z[1,5,4]  R1102     0.0594811849296093
    z[1,5,4]  R1103     5.9035980701446533e-01
    z[1,5,4]  R1104     -4.6010011434555054e-01
    z[1,5,4]  R1105     3.3176541328430176e-02
    z[1,5,4]  R1106     3.0229237675666809e-01
    z[1,5,4]  R1107     6.2527048587799072e-01
    z[1,5,4]  R1108     3.3453187346458435e-01
    z[1,5,4]  R1109     5.0589525699615479e-01
    z[1,5,4]  R1110     5.4702854156494141e-01
    z[1,5,4]  R1111     -4.0859675407409668e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R979      -1
    z[1,5,5]  R980      1
    z[1,5,5]  R983      0.572059154510498
    z[1,5,5]  R984      2.0224650204181671e-01
    z[1,5,5]  R985      3.2499879598617554e-01
    z[1,5,5]  R986      5.7566791772842407e-01
    z[1,5,5]  R987      3.4185257554054260e-01
    z[1,5,5]  R988      3.9359909296035767e-01
    z[1,5,5]  R989      4.4418856501579285e-01
    z[1,5,5]  R990      9.8158992826938629e-02
    z[1,5,5]  R991      5.9080576896667480e-01
    z[1,5,5]  R992      4.4936811923980713e-01
    z[1,5,5]  R993      -4.0780159831047058e-01
    z[1,5,5]  R994      8.4364823997020721e-02
    z[1,5,5]  R995      -1.5487454831600189e-01
    z[1,5,5]  R996      -1.2571081519126892e-01
    z[1,5,5]  R997      3.1980958580970764e-01
    z[1,5,5]  R998      -3.6274725198745728e-01
    z[1,5,5]  R999      -3.0109253525733948e-01
    z[1,5,5]  R1000     0.257143497467041
    z[1,5,5]  R1001     1.9259685277938843e-01
    z[1,5,5]  R1002     -6.8089640699326992e-03
    z[1,5,5]  R1003     4.8340019583702087e-01
    z[1,5,5]  R1004     2.7367675304412842e-01
    z[1,5,5]  R1005     -3.3563733100891113e-01
    z[1,5,5]  R1006     1.4590451121330261e-01
    z[1,5,5]  R1007     -5.5856868624687195e-02
    z[1,5,5]  R1008     -2.2697854042053223e-01
    z[1,5,5]  R1009     5.9576934576034546e-01
    z[1,5,5]  R1010     7.0278368890285492e-02
    z[1,5,5]  R1011     -1.0773368924856186e-01
    z[1,5,5]  R1012     1.5290841460227966e-01
    z[1,5,5]  R1013     -1.1612065881490707e-01
    z[1,5,5]  R1014     2.8547903895378113e-01
    z[1,5,5]  R1015     -2.3959022760391235e-01
    z[1,5,5]  R1016     -5.0130861997604370e-01
    z[1,5,5]  R1017     1.5951279550790787e-02
    z[1,5,5]  R1018     -1.2310817837715149e-01
    z[1,5,5]  R1019     -5.1310826092958450e-02
    z[1,5,5]  R1020     -1.8648105859756470e-01
    z[1,5,5]  R1021     0.0703989565372467
    z[1,5,5]  R1022     -3.9049103856086731e-01
    z[1,5,5]  R1023     3.1631711125373840e-01
    z[1,5,5]  R1024     -2.3108754307031631e-02
    z[1,5,5]  R1025     -1.6224546730518341e-01
    z[1,5,5]  R1026     3.4271883964538574e-01
    z[1,5,5]  R1027     -3.0070307850837708e-01
    z[1,5,5]  R1028     6.0025727748870850e-01
    z[1,5,5]  R1029     1.8479205667972565e-01
    z[1,5,5]  R1030     7.8040468692779541e-01
    z[1,5,5]  R1031     -4.1192230582237244e-01
    z[1,5,5]  R1032     -2.6334571838378906e-01
    z[1,5,5]  R1033     3.3801969885826111e-01
    z[1,5,5]  R1034     3.5301876068115234e-01
    z[1,5,5]  R1035     -7.6438359916210175e-02
    z[1,5,5]  R1036     5.9744093567132950e-02
    z[1,5,5]  R1037     3.6693602800369263e-01
    z[1,5,5]  R1038     2.9750075936317444e-01
    z[1,5,5]  R1039     -1.7647065222263336e-01
    z[1,5,5]  R1040     3.5998750478029251e-02
    z[1,5,5]  R1041     1.4218123257160187e-01
    z[1,5,5]  R1042     2.5382840633392334e-01
    z[1,5,5]  R1043     3.3892911672592163e-01
    z[1,5,5]  R1044     -4.3619722127914429e-01
    z[1,5,5]  R1045     2.8107947111129761e-01
    z[1,5,5]  R1046     -1.2996278703212738e-01
    z[1,5,5]  R1047     3.3217015862464905e-01
    z[1,5,5]  R1048     5.5026316642761230e-01
    z[1,5,5]  R1049     -1.1787935346364975e-01
    z[1,5,5]  R1050     1.0426397621631622e-01
    z[1,5,5]  R1051     -2.3423854261636734e-02
    z[1,5,5]  R1052     2.0529115572571754e-03
    z[1,5,5]  R1053     4.4440496712923050e-02
    z[1,5,5]  R1054     2.4768424034118652e-01
    z[1,5,5]  R1055     3.6937782168388367e-01
    z[1,5,5]  R1056     -6.5523582696914673e-01
    z[1,5,5]  R1057     1.7465998232364655e-01
    z[1,5,5]  R1058     5.2527469396591187e-01
    z[1,5,5]  R1059     2.9900896549224854e-01
    z[1,5,5]  R1060     -4.4401895999908447e-01
    z[1,5,5]  R1061     -3.8961264491081238e-01
    z[1,5,5]  R1062     -2.4709609150886536e-01
    z[1,5,5]  R1063     1.7254360020160675e-01
    z[1,5,5]  R1064     0.782616138458252
    z[1,5,5]  R1065     4.1756004095077515e-01
    z[1,5,5]  R1066     2.6718342304229736e-01
    z[1,5,5]  R1067     5.2473846822977066e-02
    z[1,5,5]  R1068     -1.7000629007816315e-01
    z[1,5,5]  R1069     -4.7777980566024780e-02
    z[1,5,5]  R1070     8.3798050880432129e-01
    z[1,5,5]  R1071     3.3537822961807251e-01
    z[1,5,5]  R1072     0.630859911441803
    z[1,5,5]  R1073     -2.0510685443878174e-01
    z[1,5,5]  R1074     -3.3171677589416504e-01
    z[1,5,5]  R1075     -4.5201838016510010e-02
    z[1,5,5]  R1076     -4.7424682974815369e-01
    z[1,5,5]  R1077     -3.8958451151847839e-01
    z[1,5,5]  R1078     -2.3353940248489380e-01
    z[1,5,5]  R1079     -3.1496521085500717e-02
    z[1,5,5]  R1080     -4.7385808825492859e-01
    z[1,5,5]  R1081     -3.0427780747413635e-01
    z[1,5,5]  R1082     -3.7121587991714478e-01
    z[1,5,5]  R1083     -5.8360165357589722e-01
    z[1,5,5]  R1084     -2.2560764849185944e-01
    z[1,5,5]  R1085     -0.407821923494339
    z[1,5,5]  R1086     1.6855373978614807e-01
    z[1,5,5]  R1087     1.0096298158168793e-01
    z[1,5,5]  R1088     -3.8624534010887146e-01
    z[1,5,5]  R1089     -3.9207586646080017e-01
    z[1,5,5]  R1090     2.3046796023845673e-01
    z[1,5,5]  R1091     -0.0591965913772583
    z[1,5,5]  R1092     -5.5470943450927734e-02
    z[1,5,5]  R1093     -3.2538297772407532e-01
    z[1,5,5]  R1094     -7.1658574044704437e-02
    z[1,5,5]  R1095     1.0443413257598877e-01
    z[1,5,5]  R1096     -0.562673032283783
    z[1,5,5]  R1097     3.3719030022621155e-01
    z[1,5,5]  R1098     -1.6899110376834869e-01
    z[1,5,5]  R1099     -0.410017728805542
    z[1,5,5]  R1100     5.1297504454851151e-02
    z[1,5,5]  R1101     -1.3205739855766296e-01
    z[1,5,5]  R1102     -1.3057488203048706e-01
    z[1,5,5]  R1103     6.3000130653381348e-01
    z[1,5,5]  R1104     1.3500395417213440e-01
    z[1,5,5]  R1105     -4.7661134600639343e-01
    z[1,5,5]  R1106     5.5322146415710449e-01
    z[1,5,5]  R1107     -5.1534615457057953e-02
    z[1,5,5]  R1108     4.5814774930477142e-02
    z[1,5,5]  R1109     1.0212268680334091e-01
    z[1,5,5]  R1110     1.0070103406906128e-01
    z[1,5,5]  R1111     -8.0719053745269775e-02
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R981      -1
    z[1,5,6]  R982      1
    z[1,5,6]  R983      -1.0094126313924789e-01
    z[1,5,6]  R984      5.6552541255950928e-01
    z[1,5,6]  R985      1.8306763470172882e-01
    z[1,5,6]  R986      4.0054774284362793e-01
    z[1,5,6]  R987      6.7007130384445190e-01
    z[1,5,6]  R988      2.1076177060604095e-01
    z[1,5,6]  R989      1.9455462694168091e-01
    z[1,5,6]  R990      1.3794803060591221e-02
    z[1,5,6]  R991      -2.1089243888854980e-01
    z[1,5,6]  R992      -3.5103622823953629e-02
    z[1,5,6]  R993      -2.1862334012985229e-01
    z[1,5,6]  R994      -3.5250243544578552e-01
    z[1,5,6]  R995      -1.6827414929866791e-01
    z[1,5,6]  R996      -2.4363709986209869e-01
    z[1,5,6]  R997      -6.8211001157760620e-01
    z[1,5,6]  R998      2.9009729623794556e-01
    z[1,5,6]  R999      2.1386879682540894e-01
    z[1,5,6]  R1000     -4.6796661615371704e-01
    z[1,5,6]  R1001     -0.00897196028381586
    z[1,5,6]  R1002     -2.8280505537986755e-01
    z[1,5,6]  R1003     3.0765134096145630e-01
    z[1,5,6]  R1004     1.4253717660903931e-01
    z[1,5,6]  R1005     5.1409882307052612e-01
    z[1,5,6]  R1006     -5.0827968120574951e-01
    z[1,5,6]  R1007     -5.5723458528518677e-01
    z[1,5,6]  R1008     6.6427379846572876e-01
    z[1,5,6]  R1009     -2.6136210560798645e-01
    z[1,5,6]  R1010     1.0727969557046890e-01
    z[1,5,6]  R1011     -4.3989929556846619e-01
    z[1,5,6]  R1012     -1.3690182566642761e-01
    z[1,5,6]  R1013     -6.3550300896167755e-02
    z[1,5,6]  R1014     -1.9873073324561119e-02
    z[1,5,6]  R1015     5.9995472431182861e-01
    z[1,5,6]  R1016     2.1704828366637230e-02
    z[1,5,6]  R1017     -6.3127028942108154e-01
    z[1,5,6]  R1018     -4.1776600480079651e-01
    z[1,5,6]  R1019     -1.5022459626197815e-01
    z[1,5,6]  R1020     2.9906576871871948e-01
    z[1,5,6]  R1021     -2.5497548282146454e-02
    z[1,5,6]  R1022     -5.4342824965715408e-02
    z[1,5,6]  R1023     -1.7073558270931244e-01
    z[1,5,6]  R1024     -1.9525590538978577e-01
    z[1,5,6]  R1025     -1.7476680874824524e-01
    z[1,5,6]  R1026     2.1142615377902985e-01
    z[1,5,6]  R1027     3.7019538879394531e-01
    z[1,5,6]  R1028     1.0266381502151489e-01
    z[1,5,6]  R1029     -1.1407420039176941e-01
    z[1,5,6]  R1030     -2.2610634565353394e-01
    z[1,5,6]  R1031     1.9763161242008209e-01
    z[1,5,6]  R1032     2.2427958250045776e-01
    z[1,5,6]  R1033     4.5541429519653320e-01
    z[1,5,6]  R1034     3.5498014092445374e-01
    z[1,5,6]  R1035     2.5778535008430481e-01
    z[1,5,6]  R1036     0.0934520810842514
    z[1,5,6]  R1037     -3.2309833168983459e-01
    z[1,5,6]  R1038     -4.5556899905204773e-01
    z[1,5,6]  R1039     0.695705235004425
    z[1,5,6]  R1040     -2.8095710277557373e-01
    z[1,5,6]  R1041     -1.2208689749240875e-01
    z[1,5,6]  R1042     1.3990619219839573e-02
    z[1,5,6]  R1043     3.6184132099151611e-01
    z[1,5,6]  R1044     3.4200161695480347e-01
    z[1,5,6]  R1045     5.1040965318679810e-01
    z[1,5,6]  R1046     0.277180939912796
    z[1,5,6]  R1047     -6.6973221302032471e-01
    z[1,5,6]  R1048     -3.9014154672622681e-01
    z[1,5,6]  R1049     -1.2053254991769791e-01
    z[1,5,6]  R1050     -2.9033371806144714e-01
    z[1,5,6]  R1051     4.1502752900123596e-01
    z[1,5,6]  R1052     -3.0794525519013405e-03
    z[1,5,6]  R1053     3.9402934908866882e-01
    z[1,5,6]  R1054     -1.4269025623798370e-01
    z[1,5,6]  R1055     1.5831559430807829e-03
    z[1,5,6]  R1056     7.2386696934700012e-02
    z[1,5,6]  R1057     2.4910837411880493e-01
    z[1,5,6]  R1058     -5.6955751031637192e-02
    z[1,5,6]  R1059     -4.5883330702781677e-01
    z[1,5,6]  R1060     -4.3563794344663620e-02
    z[1,5,6]  R1061     1.9896394014358521e-01
    z[1,5,6]  R1062     -3.3873987197875977e-01
    z[1,5,6]  R1063     -6.7084066569805145e-02
    z[1,5,6]  R1064     3.2850247621536255e-01
    z[1,5,6]  R1065     5.8844357728958130e-01
    z[1,5,6]  R1066     3.1738871335983276e-01
    z[1,5,6]  R1067     4.5578393340110779e-01
    z[1,5,6]  R1068     5.2658468484878540e-01
    z[1,5,6]  R1069     -2.4421733617782593e-01
    z[1,5,6]  R1070     -1.5115892887115479e-01
    z[1,5,6]  R1071     -3.5378482192754745e-02
    z[1,5,6]  R1072     2.1014676988124847e-01
    z[1,5,6]  R1073     2.2431743144989014e-01
    z[1,5,6]  R1074     1.4723828434944153e-01
    z[1,5,6]  R1075     2.7871602773666382e-01
    z[1,5,6]  R1076     -1.4741206541657448e-02
    z[1,5,6]  R1077     -6.3567437231540680e-02
    z[1,5,6]  R1078     2.5572484731674194e-01
    z[1,5,6]  R1079     -8.9660808444023132e-03
    z[1,5,6]  R1080     3.4135526418685913e-01
    z[1,5,6]  R1081     3.1523339450359344e-02
    z[1,5,6]  R1082     3.2076603174209595e-01
    z[1,5,6]  R1083     -4.4919201731681824e-01
    z[1,5,6]  R1084     -3.9003399014472961e-01
    z[1,5,6]  R1085     1.9633628427982330e-01
    z[1,5,6]  R1086     -5.4399389773607254e-02
    z[1,5,6]  R1087     -1.1013595014810562e-01
    z[1,5,6]  R1088     -6.7405253648757935e-02
    z[1,5,6]  R1089     3.1717678066343069e-03
    z[1,5,6]  R1090     -2.1271444857120514e-01
    z[1,5,6]  R1091     -2.4861088395118713e-01
    z[1,5,6]  R1092     -1.8542063236236572e-01
    z[1,5,6]  R1093     -3.2147186994552612e-01
    z[1,5,6]  R1094     -4.6655958890914917e-01
    z[1,5,6]  R1095     -1.2904070317745209e-01
    z[1,5,6]  R1096     -2.1621312201023102e-01
    z[1,5,6]  R1097     -2.8564631938934326e-01
    z[1,5,6]  R1098     -2.0460499450564384e-02
    z[1,5,6]  R1099     -0.547367513179779
    z[1,5,6]  R1100     -2.6937276124954224e-01
    z[1,5,6]  R1101     -6.2870413064956665e-02
    z[1,5,6]  R1102     -7.1676015853881836e-01
    z[1,5,6]  R1103     -1.9281332194805145e-01
    z[1,5,6]  R1104     1.7515836656093597e-01
    z[1,5,6]  R1105     -8.7471000850200653e-02
    z[1,5,6]  R1106     -8.9473605155944824e-02
    z[1,5,6]  R1107     -3.0243399739265442e-01
    z[1,5,6]  R1108     2.1716007590293884e-01
    z[1,5,6]  R1109     2.7200832962989807e-01
    z[1,5,6]  R1110     4.6990740299224854e-01
    z[1,5,6]  R1111     0.0439128652215004
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1112     -1
    z[5,1,0]  R1113     1
    z[5,1,0]  R1126     3.2114568352699280e-01
    z[5,1,0]  R1127     1.2799820979125798e-04
    z[5,1,0]  R1128     5.5457610636949539e-02
    z[5,1,0]  R1129     5.2234575152397156e-02
    z[5,1,0]  R1130     8.2452498376369476e-02
    z[5,1,0]  R1131     4.3067926168441772e-01
    z[5,1,0]  R1132     -1.3426003046333790e-02
    z[5,1,0]  R1133     -2.3636072874069214e-02
    z[5,1,0]  R1134     5.2429482340812683e-02
    z[5,1,0]  R1135     -7.5056720525026321e-03
    z[5,1,0]  R1136     7.0652149617671967e-02
    z[5,1,0]  R1137     2.7111560106277466e-01
    z[5,1,0]  R1138     1.9415850937366486e-01
    z[5,1,0]  R1139     1.1719628423452377e-01
    z[5,1,0]  R1140     -7.2154819965362549e-02
    z[5,1,0]  R1141     -1.4037913084030151e-01
    z[5,1,0]  R1142     -5.4189842194318771e-03
    z[5,1,0]  R1143     1.1443827301263809e-01
    z[5,1,0]  R1144     -1.8866352736949921e-01
    z[5,1,0]  R1145     4.2419081926345825e-01
    z[5,1,0]  R1146     2.6447597146034241e-01
    z[5,1,0]  R1147     4.4845908880233765e-02
    z[5,1,0]  R1148     -7.4253201484680176e-02
    z[5,1,0]  R1149     -1.0336951166391373e-01
    z[5,1,0]  R1150     -2.4555101990699768e-03
    z[5,1,0]  R1151     -1.0886755585670471e-01
    z[5,1,0]  R1152     -4.8941407352685928e-02
    z[5,1,0]  R1153     -1.8093822896480560e-01
    z[5,1,0]  R1154     -1.2569734454154968e-01
    z[5,1,0]  R1155     1.0660402476787567e-01
    z[5,1,0]  R1156     1.9257423281669617e-01
    z[5,1,0]  R1157     2.3337945342063904e-01
    z[5,1,0]  R1158     2.6228129863739014e-01
    z[5,1,0]  R1159     3.3634158968925476e-01
    z[5,1,0]  R1160     -9.8939023911952972e-02
    z[5,1,0]  R1161     -4.1293105483055115e-01
    z[5,1,0]  R1162     2.5201907753944397e-01
    z[5,1,0]  R1163     -3.2411229610443115e-01
    z[5,1,0]  R1164     3.0029773712158203e-01
    z[5,1,0]  R1165     -1.3278488814830780e-01
    z[5,1,0]  R1166     -1.9313894212245941e-01
    z[5,1,0]  R1167     -0.614051342010498
    z[5,1,0]  R1168     3.2096934318542480e-01
    z[5,1,0]  R1169     3.5385772585868835e-02
    z[5,1,0]  R1170     -0.0406770296394825
    z[5,1,0]  R1171     -5.2866542339324951e-01
    z[5,1,0]  R1172     -4.5177474617958069e-01
    z[5,1,0]  R1173     4.5386098325252533e-02
    z[5,1,0]  R1174     -1.3763718307018280e-01
    z[5,1,0]  R1175     1.2190082669258118e-01
    z[5,1,0]  R1176     8.7008059024810791e-02
    z[5,1,0]  R1177     3.0221480131149292e-01
    z[5,1,0]  R1178     2.6016193628311157e-01
    z[5,1,0]  R1179     2.4748301506042480e-01
    z[5,1,0]  R1180     7.8136193752288818e-01
    z[5,1,0]  R1181     4.5540583133697510e-01
    z[5,1,0]  R1182     -0.0655539408326149
    z[5,1,0]  R1183     -9.9040046334266663e-02
    z[5,1,0]  R1184     1.5701797604560852e-01
    z[5,1,0]  R1185     4.4143640995025635e-01
    z[5,1,0]  R1186     3.5963547229766846e-01
    z[5,1,0]  R1187     -2.4248990416526794e-01
    z[5,1,0]  R1188     1.7267766594886780e-01
    z[5,1,0]  R1189     -8.9693062007427216e-02
    z[5,1,0]  R1190     2.3396338522434235e-01
    z[5,1,0]  R1191     -1.8763886392116547e-01
    z[5,1,0]  R1192     6.3462473452091217e-02
    z[5,1,0]  R1193     5.1345992088317871e-01
    z[5,1,0]  R1194     -2.9811403155326843e-01
    z[5,1,0]  R1195     0.645882785320282
    z[5,1,0]  R1196     6.6964232921600342e-01
    z[5,1,0]  R1197     3.2339587807655334e-01
    z[5,1,0]  R1198     0.0756298080086708
    z[5,1,0]  R1199     1.8386992812156677e-01
    z[5,1,0]  R1200     2.7939921617507935e-01
    z[5,1,0]  R1201     2.6959127187728882e-01
    z[5,1,0]  R1202     5.9965625405311584e-02
    z[5,1,0]  R1203     3.8612468633800745e-03
    z[5,1,0]  R1204     -3.8516032695770264e-01
    z[5,1,0]  R1205     2.8719830513000488e-01
    z[5,1,0]  R1206     -1.0021450370550156e-01
    z[5,1,0]  R1207     -1.3037898577749729e-02
    z[5,1,0]  R1208     2.0253281295299530e-01
    z[5,1,0]  R1209     1.2343436479568481e-01
    z[5,1,0]  R1210     1.8908047676086426e-01
    z[5,1,0]  R1211     -3.3509114384651184e-01
    z[5,1,0]  R1212     -2.0382659137248993e-01
    z[5,1,0]  R1213     7.2123610973358154e-01
    z[5,1,0]  R1214     2.8315272927284241e-01
    z[5,1,0]  R1215     2.6582491397857666e-01
    z[5,1,0]  R1216     -1.4259302616119385e-01
    z[5,1,0]  R1217     1.0283294320106506e-01
    z[5,1,0]  R1218     3.0567729473114014e-01
    z[5,1,0]  R1219     1.2950356304645538e-01
    z[5,1,0]  R1220     2.6565348729491234e-02
    z[5,1,0]  R1221     -8.7781930342316628e-03
    z[5,1,0]  R1222     -9.1276951134204865e-02
    z[5,1,0]  R1223     5.2722871303558350e-01
    z[5,1,0]  R1224     1.9307661568745971e-04
    z[5,1,0]  R1225     7.6995693147182465e-02
    z[5,1,0]  R1226     -1.2734183669090271e-01
    z[5,1,0]  R1227     3.3917301893234253e-01
    z[5,1,0]  R1228     2.6374366134405136e-02
    z[5,1,0]  R1229     8.2131153345108032e-01
    z[5,1,0]  R1230     4.5522559434175491e-02
    z[5,1,0]  R1231     2.7312453836202621e-02
    z[5,1,0]  R1232     -1.0336112976074219e-01
    z[5,1,0]  R1233     -3.2615110278129578e-01
    z[5,1,0]  R1234     -3.4594023227691650e-01
    z[5,1,0]  R1235     2.8148117661476135e-01
    z[5,1,0]  R1236     3.4922760725021362e-01
    z[5,1,0]  R1237     3.0996146798133850e-01
    z[5,1,0]  R1238     1.2708684802055359e-01
    z[5,1,0]  R1239     1.3786189258098602e-01
    z[5,1,0]  R1240     3.7735259532928467e-01
    z[5,1,0]  R1241     2.9833212494850159e-01
    z[5,1,0]  R1242     -1.2803736329078674e-01
    z[5,1,0]  R1243     -1.1106203496456146e-01
    z[5,1,0]  R1244     2.8687962330877781e-03
    z[5,1,0]  R1245     2.8190642595291138e-01
    z[5,1,0]  R1246     3.4562137722969055e-01
    z[5,1,0]  R1247     -2.3160532116889954e-02
    z[5,1,0]  R1248     -1.2331695854663849e-01
    z[5,1,0]  R1249     3.4004177898168564e-02
    z[5,1,0]  R1250     -4.1489630937576294e-01
    z[5,1,0]  R1251     -2.6557642221450806e-01
    z[5,1,0]  R1252     -1.1845907568931580e-01
    z[5,1,0]  R1253     -1.9464151561260223e-01
    z[5,1,0]  R1254     2.8730336576700211e-02
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1114     -1
    z[5,1,1]  R1115     1
    z[5,1,1]  R1126     5.0134855508804321e-01
    z[5,1,1]  R1127     4.5813700556755066e-01
    z[5,1,1]  R1128     0.432682067155838
    z[5,1,1]  R1129     4.6237125992774963e-01
    z[5,1,1]  R1130     5.0908207893371582e-01
    z[5,1,1]  R1131     4.8563095927238464e-01
    z[5,1,1]  R1132     8.2065206766128540e-01
    z[5,1,1]  R1133     3.0611601471900940e-01
    z[5,1,1]  R1134     5.0296491384506226e-01
    z[5,1,1]  R1135     0.327528178691864
    z[5,1,1]  R1136     -8.1756854057312012e-01
    z[5,1,1]  R1137     -5.9623104333877563e-01
    z[5,1,1]  R1138     -7.5222784280776978e-01
    z[5,1,1]  R1139     -4.9451699852943420e-01
    z[5,1,1]  R1140     -6.9143062829971313e-01
    z[5,1,1]  R1141     -7.4074578285217285e-01
    z[5,1,1]  R1142     -6.7811751365661621e-01
    z[5,1,1]  R1143     -5.4823744297027588e-01
    z[5,1,1]  R1144     -0.549148678779602
    z[5,1,1]  R1145     -5.0057750940322876e-01
    z[5,1,1]  R1146     2.4117852747440338e-01
    z[5,1,1]  R1147     3.7038120627403259e-01
    z[5,1,1]  R1148     0.503020703792572
    z[5,1,1]  R1149     7.1465331315994263e-01
    z[5,1,1]  R1150     1.6307540237903595e-01
    z[5,1,1]  R1151     5.4639625549316406e-01
    z[5,1,1]  R1152     5.1106256246566772e-01
    z[5,1,1]  R1153     2.0135138928890228e-01
    z[5,1,1]  R1154     5.1603823900222778e-01
    z[5,1,1]  R1155     -4.3186736106872559e-01
    z[5,1,1]  R1156     7.7884471416473389e-01
    z[5,1,1]  R1157     0.612871527671814
    z[5,1,1]  R1158     1.5017915284261107e-03
    z[5,1,1]  R1159     1.7503488063812256e-01
    z[5,1,1]  R1160     6.4956796169281006e-01
    z[5,1,1]  R1161     5.9445953369140625e-01
    z[5,1,1]  R1162     1.1809966713190079e-01
    z[5,1,1]  R1163     -1.1558468639850616e-01
    z[5,1,1]  R1164     2.3782048374414444e-02
    z[5,1,1]  R1165     4.9197566509246826e-01
    z[5,1,1]  R1166     4.1021221876144409e-01
    z[5,1,1]  R1167     5.9973281621932983e-01
    z[5,1,1]  R1168     4.4935470819473267e-01
    z[5,1,1]  R1169     2.8569960594177246e-01
    z[5,1,1]  R1170     4.9081340432167053e-01
    z[5,1,1]  R1171     5.5745017528533936e-01
    z[5,1,1]  R1172     -8.5575558245182037e-02
    z[5,1,1]  R1173     5.8053910732269287e-01
    z[5,1,1]  R1174     -4.2640173435211182e-01
    z[5,1,1]  R1175     -1.6991697251796722e-01
    z[5,1,1]  R1176     -1.2021198123693466e-01
    z[5,1,1]  R1177     5.0322914123535156e-01
    z[5,1,1]  R1178     4.2183393239974976e-01
    z[5,1,1]  R1179     4.2930355668067932e-01
    z[5,1,1]  R1180     1.9643928110599518e-01
    z[5,1,1]  R1181     7.2861391305923462e-01
    z[5,1,1]  R1182     7.2586512565612793e-01
    z[5,1,1]  R1183     6.2076145410537720e-01
    z[5,1,1]  R1184     5.3477644920349121e-01
    z[5,1,1]  R1185     -5.7719420641660690e-02
    z[5,1,1]  R1186     4.3008357286453247e-01
    z[5,1,1]  R1187     7.1668881177902222e-01
    z[5,1,1]  R1188     -0.883419394493103
    z[5,1,1]  R1189     3.3213075995445251e-01
    z[5,1,1]  R1190     6.6292655467987061e-01
    z[5,1,1]  R1191     7.8095215559005737e-01
    z[5,1,1]  R1192     5.9684544801712036e-01
    z[5,1,1]  R1193     4.7032064199447632e-01
    z[5,1,1]  R1194     3.3033528923988342e-01
    z[5,1,1]  R1195     -1.8666094541549683e-01
    z[5,1,1]  R1196     4.6317240595817566e-01
    z[5,1,1]  R1197     -1.3988637924194336e-01
    z[5,1,1]  R1198     5.5366027355194092e-01
    z[5,1,1]  R1199     2.9774689674377441e-01
    z[5,1,1]  R1200     5.5339790880680084e-02
    z[5,1,1]  R1201     -5.6207644939422607e-01
    z[5,1,1]  R1202     1.1363073438405991e-01
    z[5,1,1]  R1203     5.7327234745025635e-01
    z[5,1,1]  R1204     8.8000553846359253e-01
    z[5,1,1]  R1205     8.5935018956661224e-02
    z[5,1,1]  R1206     1.2243407964706421e-01
    z[5,1,1]  R1207     1.2666161358356476e-01
    z[5,1,1]  R1208     -1.5021903812885284e-01
    z[5,1,1]  R1209     2.1114858984947205e-01
    z[5,1,1]  R1210     -4.9134314060211182e-01
    z[5,1,1]  R1211     3.0135393142700195e-01
    z[5,1,1]  R1212     4.8563334345817566e-01
    z[5,1,1]  R1213     -0.431154727935791
    z[5,1,1]  R1214     3.3930018544197083e-01
    z[5,1,1]  R1215     -5.1909035444259644e-01
    z[5,1,1]  R1216     -8.2570560276508331e-02
    z[5,1,1]  R1217     0.361701637506485
    z[5,1,1]  R1218     2.4564903974533081e-01
    z[5,1,1]  R1219     2.9356616735458374e-01
    z[5,1,1]  R1220     1.5386205911636353e-01
    z[5,1,1]  R1221     -5.1868957281112671e-01
    z[5,1,1]  R1222     8.2093916833400726e-02
    z[5,1,1]  R1223     -4.4982436299324036e-01
    z[5,1,1]  R1224     3.2640573382377625e-01
    z[5,1,1]  R1225     4.1391676664352417e-01
    z[5,1,1]  R1226     -2.6323437690734863e-01
    z[5,1,1]  R1227     -1.6353602707386017e-01
    z[5,1,1]  R1228     -8.1723339855670929e-02
    z[5,1,1]  R1229     5.5401228368282318e-02
    z[5,1,1]  R1230     -1.9173620641231537e-01
    z[5,1,1]  R1231     -5.3725861012935638e-02
    z[5,1,1]  R1232     6.6931024193763733e-02
    z[5,1,1]  R1233     7.4424481391906738e-01
    z[5,1,1]  R1234     6.7177957296371460e-01
    z[5,1,1]  R1235     4.7372713685035706e-01
    z[5,1,1]  R1236     -1.3733093440532684e-01
    z[5,1,1]  R1237     -5.6713593006134033e-01
    z[5,1,1]  R1238     5.3955519199371338e-01
    z[5,1,1]  R1239     7.9679578542709351e-02
    z[5,1,1]  R1240     -2.2865033149719238e-01
    z[5,1,1]  R1241     4.1618752479553223e-01
    z[5,1,1]  R1242     4.9980757758021355e-03
    z[5,1,1]  R1243     0.787831723690033
    z[5,1,1]  R1244     7.3669201135635376e-01
    z[5,1,1]  R1245     -3.4342417120933533e-01
    z[5,1,1]  R1246     5.0888639688491821e-01
    z[5,1,1]  R1247     -1.3661010563373566e-01
    z[5,1,1]  R1248     -4.2335250973701477e-01
    z[5,1,1]  R1249     7.9447090625762939e-01
    z[5,1,1]  R1250     6.1699497699737549e-01
    z[5,1,1]  R1251     6.7754375934600830e-01
    z[5,1,1]  R1252     -7.0698434114456177e-01
    z[5,1,1]  R1253     -6.3214230537414551e-01
    z[5,1,1]  R1254     -7.0445472002029419e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1116     -1
    z[5,1,2]  R1117     1
    z[5,1,2]  R1126     5.5939173698425293e-01
    z[5,1,2]  R1127     -9.1380871832370758e-02
    z[5,1,2]  R1128     -5.2853405475616455e-01
    z[5,1,2]  R1129     -7.1074366569519043e-01
    z[5,1,2]  R1130     -7.0286047458648682e-01
    z[5,1,2]  R1131     2.5660511851310730e-01
    z[5,1,2]  R1132     -3.3238753676414490e-01
    z[5,1,2]  R1133     -0.294884592294693
    z[5,1,2]  R1134     -6.1701703071594238e-01
    z[5,1,2]  R1135     -5.3743177652359009e-01
    z[5,1,2]  R1136     1.2026625871658325e-01
    z[5,1,2]  R1137     3.4989011287689209e-01
    z[5,1,2]  R1138     -1.1586213111877441e-01
    z[5,1,2]  R1139     -9.3651607632637024e-02
    z[5,1,2]  R1140     -3.5125061869621277e-01
    z[5,1,2]  R1141     2.9583710432052612e-01
    z[5,1,2]  R1142     1.0643537156283855e-02
    z[5,1,2]  R1143     -2.1485063433647156e-01
    z[5,1,2]  R1144     1.8233244121074677e-01
    z[5,1,2]  R1145     -4.7685351222753525e-02
    z[5,1,2]  R1146     -1.6669457778334618e-02
    z[5,1,2]  R1147     1.2669166922569275e-01
    z[5,1,2]  R1148     1.1230615526437759e-01
    z[5,1,2]  R1149     1.9065700471401215e-01
    z[5,1,2]  R1150     4.4778954982757568e-01
    z[5,1,2]  R1151     3.6488610506057739e-01
    z[5,1,2]  R1152     2.6896793395280838e-02
    z[5,1,2]  R1153     1.7822082340717316e-01
    z[5,1,2]  R1154     1.7628322541713715e-01
    z[5,1,2]  R1155     1.2772007286548615e-01
    z[5,1,2]  R1156     -2.4267971515655518e-01
    z[5,1,2]  R1157     -1.1833103001117706e-01
    z[5,1,2]  R1158     -2.2095292806625366e-01
    z[5,1,2]  R1159     2.4815934896469116e-01
    z[5,1,2]  R1160     0.269465833902359
    z[5,1,2]  R1161     2.2802762687206268e-01
    z[5,1,2]  R1162     2.2638346254825592e-01
    z[5,1,2]  R1163     -4.9153584241867065e-01
    z[5,1,2]  R1164     -1.8757960200309753e-01
    z[5,1,2]  R1165     1.7887100577354431e-01
    z[5,1,2]  R1166     -8.5737422108650208e-02
    z[5,1,2]  R1167     2.5774728506803513e-02
    z[5,1,2]  R1168     3.8702264428138733e-01
    z[5,1,2]  R1169     4.7996929287910461e-01
    z[5,1,2]  R1170     -3.9740979671478271e-01
    z[5,1,2]  R1171     4.5599198341369629e-01
    z[5,1,2]  R1172     -1.8403373658657074e-01
    z[5,1,2]  R1173     3.6123567819595337e-01
    z[5,1,2]  R1174     5.4145264625549316e-01
    z[5,1,2]  R1175     5.9869188070297241e-01
    z[5,1,2]  R1176     2.9843065142631531e-01
    z[5,1,2]  R1177     2.6460850238800049e-01
    z[5,1,2]  R1178     3.4760057926177979e-02
    z[5,1,2]  R1179     3.0230289697647095e-01
    z[5,1,2]  R1180     -2.0901657640933990e-01
    z[5,1,2]  R1181     1.1959838122129440e-01
    z[5,1,2]  R1182     6.6681647300720215e-01
    z[5,1,2]  R1183     -4.3016105890274048e-01
    z[5,1,2]  R1184     -6.4490920305252075e-01
    z[5,1,2]  R1185     2.7831861376762390e-01
    z[5,1,2]  R1186     3.2640692591667175e-01
    z[5,1,2]  R1187     -2.5030997395515442e-01
    z[5,1,2]  R1188     2.2311314940452576e-01
    z[5,1,2]  R1189     3.3854430913925171e-01
    z[5,1,2]  R1190     2.9363412410020828e-02
    z[5,1,2]  R1191     -1.3518701493740082e-01
    z[5,1,2]  R1192     -3.1465950608253479e-01
    z[5,1,2]  R1193     -3.4053522348403931e-01
    z[5,1,2]  R1194     3.8307452201843262e-01
    z[5,1,2]  R1195     1.5904194116592407e-01
    z[5,1,2]  R1196     4.5045712590217590e-01
    z[5,1,2]  R1197     -3.6079365015029907e-01
    z[5,1,2]  R1198     5.9527742862701416e-01
    z[5,1,2]  R1199     6.1822026968002319e-01
    z[5,1,2]  R1200     4.3528366088867188e-01
    z[5,1,2]  R1201     -1.3250146806240082e-01
    z[5,1,2]  R1202     7.8870460391044617e-02
    z[5,1,2]  R1203     -2.5467187166213989e-02
    z[5,1,2]  R1204     -7.9486265778541565e-02
    z[5,1,2]  R1205     7.1662414073944092e-01
    z[5,1,2]  R1206     6.2009769678115845e-01
    z[5,1,2]  R1207     6.6452652215957642e-01
    z[5,1,2]  R1208     8.1538534164428711e-01
    z[5,1,2]  R1209     1.4778582751750946e-01
    z[5,1,2]  R1210     1.0131459683179855e-01
    z[5,1,2]  R1211     0.688653290271759
    z[5,1,2]  R1212     5.4570317268371582e-01
    z[5,1,2]  R1213     -9.4202525913715363e-02
    z[5,1,2]  R1214     -5.0470698624849319e-02
    z[5,1,2]  R1215     4.8978269100189209e-01
    z[5,1,2]  R1216     8.9249360561370850e-01
    z[5,1,2]  R1217     1.2544372677803040e-01
    z[5,1,2]  R1218     3.1213113665580750e-01
    z[5,1,2]  R1219     -2.7585986256599426e-01
    z[5,1,2]  R1220     -3.1035137176513672e-01
    z[5,1,2]  R1221     -4.3089857697486877e-01
    z[5,1,2]  R1222     -1.1614146083593369e-01
    z[5,1,2]  R1223     -5.8289320440962911e-04
    z[5,1,2]  R1224     -2.4012021720409393e-01
    z[5,1,2]  R1225     4.1218116879463196e-01
    z[5,1,2]  R1226     -3.3402808010578156e-02
    z[5,1,2]  R1227     -1.1080418527126312e-01
    z[5,1,2]  R1228     2.7810338139533997e-01
    z[5,1,2]  R1229     1.9780190289020538e-01
    z[5,1,2]  R1230     -3.7223607301712036e-01
    z[5,1,2]  R1231     1.3389432430267334e-01
    z[5,1,2]  R1232     -1.4040251076221466e-01
    z[5,1,2]  R1233     -4.5583599805831909e-01
    z[5,1,2]  R1234     -5.4609888792037964e-01
    z[5,1,2]  R1235     4.7746098041534424e-01
    z[5,1,2]  R1236     7.1907371282577515e-01
    z[5,1,2]  R1237     4.9191007018089294e-01
    z[5,1,2]  R1238     7.5943440198898315e-01
    z[5,1,2]  R1239     6.0824835300445557e-01
    z[5,1,2]  R1240     3.2030174136161804e-01
    z[5,1,2]  R1241     6.9243609905242920e-01
    z[5,1,2]  R1242     -0.016898138448596
    z[5,1,2]  R1243     -3.6733978986740112e-01
    z[5,1,2]  R1244     -2.9070207476615906e-01
    z[5,1,2]  R1245     5.8625358343124390e-01
    z[5,1,2]  R1246     0.732223391532898
    z[5,1,2]  R1247     -9.6521571278572083e-02
    z[5,1,2]  R1248     -1.9231060519814491e-02
    z[5,1,2]  R1249     -0.481898695230484
    z[5,1,2]  R1250     -3.1801348924636841e-01
    z[5,1,2]  R1251     -1.2653756141662598e-01
    z[5,1,2]  R1252     -1.1570768803358078e-01
    z[5,1,2]  R1253     -2.9008877277374268e-01
    z[5,1,2]  R1254     -4.9061864614486694e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1118     -1
    z[5,1,3]  R1119     1
    z[5,1,3]  R1126     1.5760849416255951e-01
    z[5,1,3]  R1127     2.3670193552970886e-01
    z[5,1,3]  R1128     7.3240667581558228e-02
    z[5,1,3]  R1129     5.2571866661310196e-02
    z[5,1,3]  R1130     1.6801701486110687e-01
    z[5,1,3]  R1131     2.7998885512351990e-01
    z[5,1,3]  R1132     3.1080448627471924e-01
    z[5,1,3]  R1133     6.3498966395854950e-02
    z[5,1,3]  R1134     -0.07258290797472
    z[5,1,3]  R1135     -1.0689292103052139e-01
    z[5,1,3]  R1136     -4.5449972152709961e-01
    z[5,1,3]  R1137     -5.6289356946945190e-01
    z[5,1,3]  R1138     -4.6246212720870972e-01
    z[5,1,3]  R1139     -0.708291232585907
    z[5,1,3]  R1140     -4.3603339791297913e-01
    z[5,1,3]  R1141     -3.6672791838645935e-01
    z[5,1,3]  R1142     -5.9832257032394409e-01
    z[5,1,3]  R1143     -0.545274555683136
    z[5,1,3]  R1144     -6.8221920728683472e-01
    z[5,1,3]  R1145     -5.6845504045486450e-01
    z[5,1,3]  R1146     5.5740290880203247e-01
    z[5,1,3]  R1147     0.578544020652771
    z[5,1,3]  R1148     -6.0288065671920776e-01
    z[5,1,3]  R1149     -3.4921801090240479e-01
    z[5,1,3]  R1150     6.2654447555541992e-01
    z[5,1,3]  R1151     -5.2741795778274536e-01
    z[5,1,3]  R1152     -7.4762272834777832e-01
    z[5,1,3]  R1153     3.4952321648597717e-01
    z[5,1,3]  R1154     5.9685643762350082e-02
    z[5,1,3]  R1155     8.6430960893630981e-01
    z[5,1,3]  R1156     2.3574048280715942e-01
    z[5,1,3]  R1157     5.7690471410751343e-01
    z[5,1,3]  R1158     8.9302927255630493e-01
    z[5,1,3]  R1159     9.8066650331020355e-02
    z[5,1,3]  R1160     -2.5251312181353569e-02
    z[5,1,3]  R1161     -6.1161148548126221e-01
    z[5,1,3]  R1162     5.6304007768630981e-01
    z[5,1,3]  R1163     0.721450924873352
    z[5,1,3]  R1164     -0.00906460452824831
    z[5,1,3]  R1165     -4.1713351011276245e-01
    z[5,1,3]  R1166     0.0668509304523468
    z[5,1,3]  R1167     -4.4703356921672821e-02
    z[5,1,3]  R1168     5.5620354413986206e-01
    z[5,1,3]  R1169     5.3038930892944336e-01
    z[5,1,3]  R1170     3.3827179670333862e-01
    z[5,1,3]  R1171     2.0165410637855530e-01
    z[5,1,3]  R1172     6.4370816946029663e-01
    z[5,1,3]  R1173     -1.5139554627239704e-02
    z[5,1,3]  R1174     5.7504045963287354e-01
    z[5,1,3]  R1175     -2.0467333495616913e-01
    z[5,1,3]  R1176     -1.1645700782537460e-01
    z[5,1,3]  R1177     -5.9696710109710693e-01
    z[5,1,3]  R1178     -4.8272362351417542e-01
    z[5,1,3]  R1179     -3.1169405579566956e-01
    z[5,1,3]  R1180     -2.3703196644783020e-01
    z[5,1,3]  R1181     2.1501252427697182e-02
    z[5,1,3]  R1182     -1.0696186125278473e-01
    z[5,1,3]  R1183     1.3313871622085571e-01
    z[5,1,3]  R1184     -9.0374141931533813e-02
    z[5,1,3]  R1185     6.6211920976638794e-01
    z[5,1,3]  R1186     6.6893637180328369e-01
    z[5,1,3]  R1187     1.3354264199733734e-01
    z[5,1,3]  R1188     -2.5457942485809326e-01
    z[5,1,3]  R1189     4.3280407786369324e-01
    z[5,1,3]  R1190     4.4959440827369690e-01
    z[5,1,3]  R1191     3.7001997232437134e-01
    z[5,1,3]  R1192     1.1925332993268967e-01
    z[5,1,3]  R1193     5.7252246141433716e-01
    z[5,1,3]  R1194     6.6730004549026489e-01
    z[5,1,3]  R1195     -2.0880065858364105e-01
    z[5,1,3]  R1196     0.145756796002388
    z[5,1,3]  R1197     5.6535619497299194e-01
    z[5,1,3]  R1198     1.3385847210884094e-01
    z[5,1,3]  R1199     3.8668472319841385e-02
    z[5,1,3]  R1200     -8.6569473147392273e-02
    z[5,1,3]  R1201     4.1128662228584290e-01
    z[5,1,3]  R1202     0.780555784702301
    z[5,1,3]  R1203     5.4355055093765259e-01
    z[5,1,3]  R1204     1.0336114466190338e-01
    z[5,1,3]  R1205     -5.1157391071319580e-01
    z[5,1,3]  R1206     -6.9933813810348511e-01
    z[5,1,3]  R1207     -3.5331344604492188e-01
    z[5,1,3]  R1208     9.6488796174526215e-02
    z[5,1,3]  R1209     7.0612180233001709e-01
    z[5,1,3]  R1210     7.0649206638336182e-01
    z[5,1,3]  R1211     3.6217209696769714e-01
    z[5,1,3]  R1212     3.6982360482215881e-01
    z[5,1,3]  R1213     4.9719414114952087e-01
    z[5,1,3]  R1214     7.3084467649459839e-01
    z[5,1,3]  R1215     1.0725892148911953e-02
    z[5,1,3]  R1216     2.5985460728406906e-02
    z[5,1,3]  R1217     8.8379764556884766e-01
    z[5,1,3]  R1218     4.0583640336990356e-01
    z[5,1,3]  R1219     7.6214724779129028e-01
    z[5,1,3]  R1220     6.1278021335601807e-01
    z[5,1,3]  R1221     5.9152060747146606e-01
    z[5,1,3]  R1222     0.557911217212677
    z[5,1,3]  R1223     0.557619571685791
    z[5,1,3]  R1224     5.5516934394836426e-01
    z[5,1,3]  R1225     -3.0751907825469971e-01
    z[5,1,3]  R1226     8.1406724452972412e-01
    z[5,1,3]  R1227     0.834414541721344
    z[5,1,3]  R1228     7.9402446746826172e-01
    z[5,1,3]  R1229     1.5916527807712555e-01
    z[5,1,3]  R1230     7.1639132499694824e-01
    z[5,1,3]  R1231     6.7942863702774048e-01
    z[5,1,3]  R1232     5.9608709812164307e-01
    z[5,1,3]  R1233     2.4663527309894562e-01
    z[5,1,3]  R1234     -1.5179876983165741e-01
    z[5,1,3]  R1235     -0.399173766374588
    z[5,1,3]  R1236     1.4233709871768951e-01
    z[5,1,3]  R1237     1.9738802686333656e-02
    z[5,1,3]  R1238     3.9049752056598663e-02
    z[5,1,3]  R1239     1.8538008630275726e-01
    z[5,1,3]  R1240     -3.6137807369232178e-01
    z[5,1,3]  R1241     4.7713780403137207e-01
    z[5,1,3]  R1242     6.3309156894683838e-01
    z[5,1,3]  R1243     -8.0035179853439331e-02
    z[5,1,3]  R1244     -1.6489619016647339e-01
    z[5,1,3]  R1245     -5.2144950628280640e-01
    z[5,1,3]  R1246     -1.9632993265986443e-02
    z[5,1,3]  R1247     8.7787830829620361e-01
    z[5,1,3]  R1248     0.608786940574646
    z[5,1,3]  R1249     6.7621201276779175e-02
    z[5,1,3]  R1250     -4.9428176134824753e-02
    z[5,1,3]  R1251     -0.13033527135849
    z[5,1,3]  R1252     -3.5813841223716736e-01
    z[5,1,3]  R1253     -4.6140113472938538e-01
    z[5,1,3]  R1254     -2.6908096671104431e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1120     -1
    z[5,1,4]  R1121     1
    z[5,1,4]  R1126     -5.2295696735382080e-01
    z[5,1,4]  R1127     -7.3008544743061066e-02
    z[5,1,4]  R1128     6.6151313483715057e-02
    z[5,1,4]  R1129     -3.2162305712699890e-01
    z[5,1,4]  R1130     0.0360804907977581
    z[5,1,4]  R1131     -3.5811248421669006e-01
    z[5,1,4]  R1132     -2.3946642875671387e-01
    z[5,1,4]  R1133     -2.9947438836097717e-01
    z[5,1,4]  R1134     -4.9453905224800110e-01
    z[5,1,4]  R1135     -3.8763910531997681e-01
    z[5,1,4]  R1136     -1.1475600302219391e-01
    z[5,1,4]  R1137     -4.1680745780467987e-03
    z[5,1,4]  R1138     2.9905638098716736e-01
    z[5,1,4]  R1139     7.8380726277828217e-02
    z[5,1,4]  R1140     2.1771165728569031e-01
    z[5,1,4]  R1141     2.9940694570541382e-01
    z[5,1,4]  R1142     4.2538410425186157e-01
    z[5,1,4]  R1143     -0.0423019640147686
    z[5,1,4]  R1144     2.6569724082946777e-01
    z[5,1,4]  R1145     5.8113500475883484e-02
    z[5,1,4]  R1146     -1.3618029654026031e-01
    z[5,1,4]  R1147     5.5409145355224609e-01
    z[5,1,4]  R1148     4.0063974261283875e-01
    z[5,1,4]  R1149     0.537505567073822
    z[5,1,4]  R1150     5.9833395481109619e-01
    z[5,1,4]  R1151     3.5292837023735046e-01
    z[5,1,4]  R1152     1.5173371136188507e-01
    z[5,1,4]  R1153     8.2123500108718872e-01
    z[5,1,4]  R1154     7.8610116243362427e-01
    z[5,1,4]  R1155     -3.6398649215698242e-02
    z[5,1,4]  R1156     1.8064025044441223e-01
    z[5,1,4]  R1157     0.0169846098870039
    z[5,1,4]  R1158     -2.3943005502223969e-01
    z[5,1,4]  R1159     -6.4937502145767212e-01
    z[5,1,4]  R1160     5.4747790098190308e-01
    z[5,1,4]  R1161     1.4513424038887024e-01
    z[5,1,4]  R1162     -2.9419302940368652e-01
    z[5,1,4]  R1163     2.1047417819499969e-01
    z[5,1,4]  R1164     -0.92336106300354
    z[5,1,4]  R1165     0.0594811849296093
    z[5,1,4]  R1166     5.9035980701446533e-01
    z[5,1,4]  R1167     -4.6010011434555054e-01
    z[5,1,4]  R1168     3.3176541328430176e-02
    z[5,1,4]  R1169     3.0229237675666809e-01
    z[5,1,4]  R1170     6.2527048587799072e-01
    z[5,1,4]  R1171     3.3453187346458435e-01
    z[5,1,4]  R1172     5.0589525699615479e-01
    z[5,1,4]  R1173     5.4702854156494141e-01
    z[5,1,4]  R1174     -4.0859675407409668e-01
    z[5,1,4]  R1175     -4.6744459867477417e-01
    z[5,1,4]  R1176     -7.1737915277481079e-01
    z[5,1,4]  R1177     2.9983532428741455e-01
    z[5,1,4]  R1178     -1.6825450956821442e-01
    z[5,1,4]  R1179     -7.1868272498250008e-03
    z[5,1,4]  R1180     2.2731561958789825e-01
    z[5,1,4]  R1181     -1.0865645855665207e-01
    z[5,1,4]  R1182     -5.3962741047143936e-02
    z[5,1,4]  R1183     -9.2491157352924347e-02
    z[5,1,4]  R1184     2.4923919141292572e-01
    z[5,1,4]  R1185     2.6803153753280640e-01
    z[5,1,4]  R1186     1.7255203798413277e-02
    z[5,1,4]  R1187     5.4292237758636475e-01
    z[5,1,4]  R1188     -3.7150489515624940e-04
    z[5,1,4]  R1189     -1.1027441918849945e-01
    z[5,1,4]  R1190     2.9504260420799255e-01
    z[5,1,4]  R1191     2.5163173675537109e-01
    z[5,1,4]  R1192     0.491325318813324
    z[5,1,4]  R1193     -1.8503305315971375e-01
    z[5,1,4]  R1194     -3.6048030853271484e-01
    z[5,1,4]  R1195     -3.8829880952835083e-01
    z[5,1,4]  R1196     -1.3295862078666687e-01
    z[5,1,4]  R1197     2.2157919406890869e-01
    z[5,1,4]  R1198     1.8929013609886169e-01
    z[5,1,4]  R1199     0.424519419670105
    z[5,1,4]  R1200     4.7867378592491150e-01
    z[5,1,4]  R1201     3.7761986255645752e-02
    z[5,1,4]  R1202     -5.9292191267013550e-01
    z[5,1,4]  R1203     4.1246834397315979e-01
    z[5,1,4]  R1204     1.3459983468055725e-01
    z[5,1,4]  R1205     3.4256622195243835e-01
    z[5,1,4]  R1206     -1.3956628739833832e-01
    z[5,1,4]  R1207     -3.4333132207393646e-03
    z[5,1,4]  R1208     1.0232302546501160e-01
    z[5,1,4]  R1209     1.4482711255550385e-01
    z[5,1,4]  R1210     -1.5411286056041718e-01
    z[5,1,4]  R1211     -4.0778371691703796e-01
    z[5,1,4]  R1212     -4.0476894378662109e-01
    z[5,1,4]  R1213     1.7956039309501648e-01
    z[5,1,4]  R1214     3.3553296327590942e-01
    z[5,1,4]  R1215     -0.539141058921814
    z[5,1,4]  R1216     -3.7009525299072266e-01
    z[5,1,4]  R1217     -0.0699705109000206
    z[5,1,4]  R1218     -6.4956271648406982e-01
    z[5,1,4]  R1219     -1.1231047660112381e-01
    z[5,1,4]  R1220     3.6462938785552979e-01
    z[5,1,4]  R1221     3.8490617275238037e-01
    z[5,1,4]  R1222     4.4420263729989529e-03
    z[5,1,4]  R1223     -0.00312254810705781
    z[5,1,4]  R1224     0.638698935508728
    z[5,1,4]  R1225     -4.8643991351127625e-01
    z[5,1,4]  R1226     -0.00611188355833292
    z[5,1,4]  R1227     2.7820187807083130e-01
    z[5,1,4]  R1228     -5.2202165126800537e-01
    z[5,1,4]  R1229     1.3742050528526306e-01
    z[5,1,4]  R1230     1.1549419909715652e-01
    z[5,1,4]  R1231     -4.0852095931768417e-02
    z[5,1,4]  R1232     7.2771638631820679e-01
    z[5,1,4]  R1233     1.8970780074596405e-01
    z[5,1,4]  R1234     2.0771621167659760e-01
    z[5,1,4]  R1235     -2.5147604942321777e-01
    z[5,1,4]  R1236     -1.2091477960348129e-01
    z[5,1,4]  R1237     -1.9797105342149734e-02
    z[5,1,4]  R1238     -1.4402748644351959e-01
    z[5,1,4]  R1239     -1.0693571716547012e-01
    z[5,1,4]  R1240     3.4225240349769592e-01
    z[5,1,4]  R1241     -4.7265164554119110e-02
    z[5,1,4]  R1242     6.9808769226074219e-01
    z[5,1,4]  R1243     2.2988188266754150e-01
    z[5,1,4]  R1244     5.8784735202789307e-01
    z[5,1,4]  R1245     -1.7248657345771790e-01
    z[5,1,4]  R1246     -5.7757817208766937e-02
    z[5,1,4]  R1247     2.5371652841567993e-01
    z[5,1,4]  R1248     4.8426890862174332e-04
    z[5,1,4]  R1249     1.9570238888263702e-01
    z[5,1,4]  R1250     -2.5386002659797668e-01
    z[5,1,4]  R1251     3.7076970934867859e-01
    z[5,1,4]  R1252     3.8136407732963562e-01
    z[5,1,4]  R1253     2.7218326926231384e-01
    z[5,1,4]  R1254     -1.1834619939327240e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1122     -1
    z[5,1,5]  R1123     1
    z[5,1,5]  R1126     1.7254360020160675e-01
    z[5,1,5]  R1127     0.782616138458252
    z[5,1,5]  R1128     4.1756004095077515e-01
    z[5,1,5]  R1129     2.6718342304229736e-01
    z[5,1,5]  R1130     5.2473846822977066e-02
    z[5,1,5]  R1131     -1.7000629007816315e-01
    z[5,1,5]  R1132     -4.7777980566024780e-02
    z[5,1,5]  R1133     8.3798050880432129e-01
    z[5,1,5]  R1134     3.3537822961807251e-01
    z[5,1,5]  R1135     0.630859911441803
    z[5,1,5]  R1136     -2.0510685443878174e-01
    z[5,1,5]  R1137     -3.3171677589416504e-01
    z[5,1,5]  R1138     -4.5201838016510010e-02
    z[5,1,5]  R1139     -4.7424682974815369e-01
    z[5,1,5]  R1140     -3.8958451151847839e-01
    z[5,1,5]  R1141     -2.3353940248489380e-01
    z[5,1,5]  R1142     -3.1496521085500717e-02
    z[5,1,5]  R1143     -4.7385808825492859e-01
    z[5,1,5]  R1144     -3.0427780747413635e-01
    z[5,1,5]  R1145     -3.7121587991714478e-01
    z[5,1,5]  R1146     -5.8360165357589722e-01
    z[5,1,5]  R1147     -2.2560764849185944e-01
    z[5,1,5]  R1148     -0.407821923494339
    z[5,1,5]  R1149     1.6855373978614807e-01
    z[5,1,5]  R1150     1.0096298158168793e-01
    z[5,1,5]  R1151     -3.8624534010887146e-01
    z[5,1,5]  R1152     -3.9207586646080017e-01
    z[5,1,5]  R1153     2.3046796023845673e-01
    z[5,1,5]  R1154     -0.0591965913772583
    z[5,1,5]  R1155     -5.5470943450927734e-02
    z[5,1,5]  R1156     -3.2538297772407532e-01
    z[5,1,5]  R1157     -7.1658574044704437e-02
    z[5,1,5]  R1158     1.0443413257598877e-01
    z[5,1,5]  R1159     -0.562673032283783
    z[5,1,5]  R1160     3.3719030022621155e-01
    z[5,1,5]  R1161     -1.6899110376834869e-01
    z[5,1,5]  R1162     -0.410017728805542
    z[5,1,5]  R1163     5.1297504454851151e-02
    z[5,1,5]  R1164     -1.3205739855766296e-01
    z[5,1,5]  R1165     -1.3057488203048706e-01
    z[5,1,5]  R1166     6.3000130653381348e-01
    z[5,1,5]  R1167     1.3500395417213440e-01
    z[5,1,5]  R1168     -4.7661134600639343e-01
    z[5,1,5]  R1169     5.5322146415710449e-01
    z[5,1,5]  R1170     -5.1534615457057953e-02
    z[5,1,5]  R1171     4.5814774930477142e-02
    z[5,1,5]  R1172     1.0212268680334091e-01
    z[5,1,5]  R1173     1.0070103406906128e-01
    z[5,1,5]  R1174     -8.0719053745269775e-02
    z[5,1,5]  R1175     0.572059154510498
    z[5,1,5]  R1176     2.0224650204181671e-01
    z[5,1,5]  R1177     3.2499879598617554e-01
    z[5,1,5]  R1178     5.7566791772842407e-01
    z[5,1,5]  R1179     3.4185257554054260e-01
    z[5,1,5]  R1180     3.9359909296035767e-01
    z[5,1,5]  R1181     4.4418856501579285e-01
    z[5,1,5]  R1182     9.8158992826938629e-02
    z[5,1,5]  R1183     5.9080576896667480e-01
    z[5,1,5]  R1184     4.4936811923980713e-01
    z[5,1,5]  R1185     -4.0780159831047058e-01
    z[5,1,5]  R1186     8.4364823997020721e-02
    z[5,1,5]  R1187     -1.5487454831600189e-01
    z[5,1,5]  R1188     -1.2571081519126892e-01
    z[5,1,5]  R1189     3.1980958580970764e-01
    z[5,1,5]  R1190     -3.6274725198745728e-01
    z[5,1,5]  R1191     -3.0109253525733948e-01
    z[5,1,5]  R1192     0.257143497467041
    z[5,1,5]  R1193     1.9259685277938843e-01
    z[5,1,5]  R1194     -6.8089640699326992e-03
    z[5,1,5]  R1195     4.8340019583702087e-01
    z[5,1,5]  R1196     2.7367675304412842e-01
    z[5,1,5]  R1197     -3.3563733100891113e-01
    z[5,1,5]  R1198     1.4590451121330261e-01
    z[5,1,5]  R1199     -5.5856868624687195e-02
    z[5,1,5]  R1200     -2.2697854042053223e-01
    z[5,1,5]  R1201     5.9576934576034546e-01
    z[5,1,5]  R1202     7.0278368890285492e-02
    z[5,1,5]  R1203     -1.0773368924856186e-01
    z[5,1,5]  R1204     1.5290841460227966e-01
    z[5,1,5]  R1205     -1.1612065881490707e-01
    z[5,1,5]  R1206     2.8547903895378113e-01
    z[5,1,5]  R1207     -2.3959022760391235e-01
    z[5,1,5]  R1208     -5.0130861997604370e-01
    z[5,1,5]  R1209     1.5951279550790787e-02
    z[5,1,5]  R1210     -1.2310817837715149e-01
    z[5,1,5]  R1211     -5.1310826092958450e-02
    z[5,1,5]  R1212     -1.8648105859756470e-01
    z[5,1,5]  R1213     0.0703989565372467
    z[5,1,5]  R1214     -3.9049103856086731e-01
    z[5,1,5]  R1215     3.1631711125373840e-01
    z[5,1,5]  R1216     -2.3108754307031631e-02
    z[5,1,5]  R1217     -1.6224546730518341e-01
    z[5,1,5]  R1218     3.4271883964538574e-01
    z[5,1,5]  R1219     -3.0070307850837708e-01
    z[5,1,5]  R1220     6.0025727748870850e-01
    z[5,1,5]  R1221     1.8479205667972565e-01
    z[5,1,5]  R1222     7.8040468692779541e-01
    z[5,1,5]  R1223     -4.1192230582237244e-01
    z[5,1,5]  R1224     -2.6334571838378906e-01
    z[5,1,5]  R1225     3.3801969885826111e-01
    z[5,1,5]  R1226     3.5301876068115234e-01
    z[5,1,5]  R1227     -7.6438359916210175e-02
    z[5,1,5]  R1228     5.9744093567132950e-02
    z[5,1,5]  R1229     3.6693602800369263e-01
    z[5,1,5]  R1230     2.9750075936317444e-01
    z[5,1,5]  R1231     -1.7647065222263336e-01
    z[5,1,5]  R1232     3.5998750478029251e-02
    z[5,1,5]  R1233     1.4218123257160187e-01
    z[5,1,5]  R1234     2.5382840633392334e-01
    z[5,1,5]  R1235     3.3892911672592163e-01
    z[5,1,5]  R1236     -4.3619722127914429e-01
    z[5,1,5]  R1237     2.8107947111129761e-01
    z[5,1,5]  R1238     -1.2996278703212738e-01
    z[5,1,5]  R1239     3.3217015862464905e-01
    z[5,1,5]  R1240     5.5026316642761230e-01
    z[5,1,5]  R1241     -1.1787935346364975e-01
    z[5,1,5]  R1242     1.0426397621631622e-01
    z[5,1,5]  R1243     -2.3423854261636734e-02
    z[5,1,5]  R1244     2.0529115572571754e-03
    z[5,1,5]  R1245     4.4440496712923050e-02
    z[5,1,5]  R1246     2.4768424034118652e-01
    z[5,1,5]  R1247     3.6937782168388367e-01
    z[5,1,5]  R1248     -6.5523582696914673e-01
    z[5,1,5]  R1249     1.7465998232364655e-01
    z[5,1,5]  R1250     5.2527469396591187e-01
    z[5,1,5]  R1251     2.9900896549224854e-01
    z[5,1,5]  R1252     -4.4401895999908447e-01
    z[5,1,5]  R1253     -3.8961264491081238e-01
    z[5,1,5]  R1254     -2.4709609150886536e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1124     -1
    z[5,1,6]  R1125     1
    z[5,1,6]  R1126     -6.7084066569805145e-02
    z[5,1,6]  R1127     3.2850247621536255e-01
    z[5,1,6]  R1128     5.8844357728958130e-01
    z[5,1,6]  R1129     3.1738871335983276e-01
    z[5,1,6]  R1130     4.5578393340110779e-01
    z[5,1,6]  R1131     5.2658468484878540e-01
    z[5,1,6]  R1132     -2.4421733617782593e-01
    z[5,1,6]  R1133     -1.5115892887115479e-01
    z[5,1,6]  R1134     -3.5378482192754745e-02
    z[5,1,6]  R1135     2.1014676988124847e-01
    z[5,1,6]  R1136     2.2431743144989014e-01
    z[5,1,6]  R1137     1.4723828434944153e-01
    z[5,1,6]  R1138     2.7871602773666382e-01
    z[5,1,6]  R1139     -1.4741206541657448e-02
    z[5,1,6]  R1140     -6.3567437231540680e-02
    z[5,1,6]  R1141     2.5572484731674194e-01
    z[5,1,6]  R1142     -8.9660808444023132e-03
    z[5,1,6]  R1143     3.4135526418685913e-01
    z[5,1,6]  R1144     3.1523339450359344e-02
    z[5,1,6]  R1145     3.2076603174209595e-01
    z[5,1,6]  R1146     -4.4919201731681824e-01
    z[5,1,6]  R1147     -3.9003399014472961e-01
    z[5,1,6]  R1148     1.9633628427982330e-01
    z[5,1,6]  R1149     -5.4399389773607254e-02
    z[5,1,6]  R1150     -1.1013595014810562e-01
    z[5,1,6]  R1151     -6.7405253648757935e-02
    z[5,1,6]  R1152     3.1717678066343069e-03
    z[5,1,6]  R1153     -2.1271444857120514e-01
    z[5,1,6]  R1154     -2.4861088395118713e-01
    z[5,1,6]  R1155     -1.8542063236236572e-01
    z[5,1,6]  R1156     -3.2147186994552612e-01
    z[5,1,6]  R1157     -4.6655958890914917e-01
    z[5,1,6]  R1158     -1.2904070317745209e-01
    z[5,1,6]  R1159     -2.1621312201023102e-01
    z[5,1,6]  R1160     -2.8564631938934326e-01
    z[5,1,6]  R1161     -2.0460499450564384e-02
    z[5,1,6]  R1162     -0.547367513179779
    z[5,1,6]  R1163     -2.6937276124954224e-01
    z[5,1,6]  R1164     -6.2870413064956665e-02
    z[5,1,6]  R1165     -7.1676015853881836e-01
    z[5,1,6]  R1166     -1.9281332194805145e-01
    z[5,1,6]  R1167     1.7515836656093597e-01
    z[5,1,6]  R1168     -8.7471000850200653e-02
    z[5,1,6]  R1169     -8.9473605155944824e-02
    z[5,1,6]  R1170     -3.0243399739265442e-01
    z[5,1,6]  R1171     2.1716007590293884e-01
    z[5,1,6]  R1172     2.7200832962989807e-01
    z[5,1,6]  R1173     4.6990740299224854e-01
    z[5,1,6]  R1174     0.0439128652215004
    z[5,1,6]  R1175     -1.0094126313924789e-01
    z[5,1,6]  R1176     5.6552541255950928e-01
    z[5,1,6]  R1177     1.8306763470172882e-01
    z[5,1,6]  R1178     4.0054774284362793e-01
    z[5,1,6]  R1179     6.7007130384445190e-01
    z[5,1,6]  R1180     2.1076177060604095e-01
    z[5,1,6]  R1181     1.9455462694168091e-01
    z[5,1,6]  R1182     1.3794803060591221e-02
    z[5,1,6]  R1183     -2.1089243888854980e-01
    z[5,1,6]  R1184     -3.5103622823953629e-02
    z[5,1,6]  R1185     -2.1862334012985229e-01
    z[5,1,6]  R1186     -3.5250243544578552e-01
    z[5,1,6]  R1187     -1.6827414929866791e-01
    z[5,1,6]  R1188     -2.4363709986209869e-01
    z[5,1,6]  R1189     -6.8211001157760620e-01
    z[5,1,6]  R1190     2.9009729623794556e-01
    z[5,1,6]  R1191     2.1386879682540894e-01
    z[5,1,6]  R1192     -4.6796661615371704e-01
    z[5,1,6]  R1193     -0.00897196028381586
    z[5,1,6]  R1194     -2.8280505537986755e-01
    z[5,1,6]  R1195     3.0765134096145630e-01
    z[5,1,6]  R1196     1.4253717660903931e-01
    z[5,1,6]  R1197     5.1409882307052612e-01
    z[5,1,6]  R1198     -5.0827968120574951e-01
    z[5,1,6]  R1199     -5.5723458528518677e-01
    z[5,1,6]  R1200     6.6427379846572876e-01
    z[5,1,6]  R1201     -2.6136210560798645e-01
    z[5,1,6]  R1202     1.0727969557046890e-01
    z[5,1,6]  R1203     -4.3989929556846619e-01
    z[5,1,6]  R1204     -1.3690182566642761e-01
    z[5,1,6]  R1205     -6.3550300896167755e-02
    z[5,1,6]  R1206     -1.9873073324561119e-02
    z[5,1,6]  R1207     5.9995472431182861e-01
    z[5,1,6]  R1208     2.1704828366637230e-02
    z[5,1,6]  R1209     -6.3127028942108154e-01
    z[5,1,6]  R1210     -4.1776600480079651e-01
    z[5,1,6]  R1211     -1.5022459626197815e-01
    z[5,1,6]  R1212     2.9906576871871948e-01
    z[5,1,6]  R1213     -2.5497548282146454e-02
    z[5,1,6]  R1214     -5.4342824965715408e-02
    z[5,1,6]  R1215     -1.7073558270931244e-01
    z[5,1,6]  R1216     -1.9525590538978577e-01
    z[5,1,6]  R1217     -1.7476680874824524e-01
    z[5,1,6]  R1218     2.1142615377902985e-01
    z[5,1,6]  R1219     3.7019538879394531e-01
    z[5,1,6]  R1220     1.0266381502151489e-01
    z[5,1,6]  R1221     -1.1407420039176941e-01
    z[5,1,6]  R1222     -2.2610634565353394e-01
    z[5,1,6]  R1223     1.9763161242008209e-01
    z[5,1,6]  R1224     2.2427958250045776e-01
    z[5,1,6]  R1225     4.5541429519653320e-01
    z[5,1,6]  R1226     3.5498014092445374e-01
    z[5,1,6]  R1227     2.5778535008430481e-01
    z[5,1,6]  R1228     0.0934520810842514
    z[5,1,6]  R1229     -3.2309833168983459e-01
    z[5,1,6]  R1230     -4.5556899905204773e-01
    z[5,1,6]  R1231     0.695705235004425
    z[5,1,6]  R1232     -2.8095710277557373e-01
    z[5,1,6]  R1233     -1.2208689749240875e-01
    z[5,1,6]  R1234     1.3990619219839573e-02
    z[5,1,6]  R1235     3.6184132099151611e-01
    z[5,1,6]  R1236     3.4200161695480347e-01
    z[5,1,6]  R1237     5.1040965318679810e-01
    z[5,1,6]  R1238     0.277180939912796
    z[5,1,6]  R1239     -6.6973221302032471e-01
    z[5,1,6]  R1240     -3.9014154672622681e-01
    z[5,1,6]  R1241     -1.2053254991769791e-01
    z[5,1,6]  R1242     -2.9033371806144714e-01
    z[5,1,6]  R1243     4.1502752900123596e-01
    z[5,1,6]  R1244     -3.0794525519013405e-03
    z[5,1,6]  R1245     3.9402934908866882e-01
    z[5,1,6]  R1246     -1.4269025623798370e-01
    z[5,1,6]  R1247     1.5831559430807829e-03
    z[5,1,6]  R1248     7.2386696934700012e-02
    z[5,1,6]  R1249     2.4910837411880493e-01
    z[5,1,6]  R1250     -5.6955751031637192e-02
    z[5,1,6]  R1251     -4.5883330702781677e-01
    z[5,1,6]  R1252     -4.3563794344663620e-02
    z[5,1,6]  R1253     1.9896394014358521e-01
    z[5,1,6]  R1254     -3.3873987197875977e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1255     -1
    z[2,3,0]  R1256     1
    z[2,3,0]  R1269     -7.6891683042049408e-02
    z[2,3,0]  R1270     9.7774147987365723e-02
    z[2,3,0]  R1271     -1.1200371384620667e-01
    z[2,3,0]  R1272     -1.0103247128427029e-02
    z[2,3,0]  R1273     1.8761040270328522e-01
    z[2,3,0]  R1274     -1.8172055482864380e-01
    z[2,3,0]  R1275     1.5545558929443359e-01
    z[2,3,0]  R1276     1.4082913100719452e-01
    z[2,3,0]  R1277     3.0249828100204468e-01
    z[2,3,0]  R1278     1.1991544812917709e-01
    z[2,3,0]  R1279     -1.2291748821735382e-01
    z[2,3,0]  R1280     2.8967265039682388e-02
    z[2,3,0]  R1281     -0.0217283982783556
    z[2,3,0]  R1282     -1.7278583347797394e-01
    z[2,3,0]  R1283     -2.3908168077468872e-02
    z[2,3,0]  R1284     -8.7013579905033112e-02
    z[2,3,0]  R1285     0.06809101998806
    z[2,3,0]  R1286     -1.0040861368179321e-01
    z[2,3,0]  R1287     -6.5120466053485870e-02
    z[2,3,0]  R1288     1.5014787018299103e-01
    z[2,3,0]  R1289     -6.3791498541831970e-02
    z[2,3,0]  R1290     1.9312863051891327e-01
    z[2,3,0]  R1291     -2.5318851694464684e-02
    z[2,3,0]  R1292     2.2771932184696198e-02
    z[2,3,0]  R1293     -3.4576624631881714e-02
    z[2,3,0]  R1294     -9.8926816135644913e-03
    z[2,3,0]  R1295     -1.0351626574993134e-01
    z[2,3,0]  R1296     1.6009204089641571e-01
    z[2,3,0]  R1297     3.1615566462278366e-02
    z[2,3,0]  R1298     -1.4451977610588074e-01
    z[2,3,0]  R1299     3.6170229315757751e-01
    z[2,3,0]  R1300     1.6324986517429352e-01
    z[2,3,0]  R1301     -4.1269157081842422e-02
    z[2,3,0]  R1302     1.2358608096837997e-01
    z[2,3,0]  R1303     -2.3048009723424911e-02
    z[2,3,0]  R1304     1.8776720762252808e-01
    z[2,3,0]  R1305     -1.5722067654132843e-01
    z[2,3,0]  R1306     -9.7374036908149719e-02
    z[2,3,0]  R1307     -1.9575388729572296e-01
    z[2,3,0]  R1308     9.2036321759223938e-02
    z[2,3,0]  R1309     -3.2675590366125107e-02
    z[2,3,0]  R1310     -3.6611091345548630e-02
    z[2,3,0]  R1311     -2.2188383340835571e-01
    z[2,3,0]  R1312     -1.9630396738648415e-02
    z[2,3,0]  R1313     1.5862879157066345e-01
    z[2,3,0]  R1314     1.8542206287384033e-01
    z[2,3,0]  R1315     1.9136006012558937e-02
    z[2,3,0]  R1316     4.1606724262237549e-01
    z[2,3,0]  R1317     2.1164511144161224e-01
    z[2,3,0]  R1318     2.6832106709480286e-01
    z[2,3,0]  R1319     1.8306382000446320e-01
    z[2,3,0]  R1320     3.1629450619220734e-02
    z[2,3,0]  R1321     6.9233119487762451e-02
    z[2,3,0]  R1322     -8.5436977446079254e-02
    z[2,3,0]  R1323     -6.9607138633728027e-01
    z[2,3,0]  R1324     -3.7381795048713684e-01
    z[2,3,0]  R1325     -5.0426310300827026e-01
    z[2,3,0]  R1326     -7.4039585888385773e-02
    z[2,3,0]  R1327     1.8637432157993317e-01
    z[2,3,0]  R1328     1.1229066550731659e-01
    z[2,3,0]  R1329     3.1533634662628174e-01
    z[2,3,0]  R1330     -3.6027842760086060e-01
    z[2,3,0]  R1331     4.6952001750469208e-02
    z[2,3,0]  R1332     3.3584558963775635e-01
    z[2,3,0]  R1333     -1.8386675417423248e-01
    z[2,3,0]  R1334     1.9078862667083740e-01
    z[2,3,0]  R1335     -5.7934051752090454e-01
    z[2,3,0]  R1336     2.6301616430282593e-01
    z[2,3,0]  R1337     -7.2893661260604858e-01
    z[2,3,0]  R1338     1.1756321042776108e-01
    z[2,3,0]  R1339     -2.0802223682403564e-01
    z[2,3,0]  R1340     -3.6427670717239380e-01
    z[2,3,0]  R1341     -9.3302980065345764e-02
    z[2,3,0]  R1342     -8.6929149925708771e-02
    z[2,3,0]  R1343     4.3205675482749939e-01
    z[2,3,0]  R1344     0.0286989975720644
    z[2,3,0]  R1345     2.3792499303817749e-01
    z[2,3,0]  R1346     4.8042505979537964e-01
    z[2,3,0]  R1347     1.2228551506996155e-01
    z[2,3,0]  R1348     1.5694823861122131e-01
    z[2,3,0]  R1349     3.7377968430519104e-01
    z[2,3,0]  R1350     5.0766885280609131e-01
    z[2,3,0]  R1351     2.6414486765861511e-01
    z[2,3,0]  R1352     4.0131795406341553e-01
    z[2,3,0]  R1353     -4.0726464986801147e-01
    z[2,3,0]  R1354     -2.2311198711395264e-01
    z[2,3,0]  R1355     -5.9472423791885376e-01
    z[2,3,0]  R1356     -3.7742203567177057e-03
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1257     -1
    z[2,3,1]  R1258     1
    z[2,3,1]  R1269     -5.5581796169281006e-01
    z[2,3,1]  R1270     -4.0392491221427917e-01
    z[2,3,1]  R1271     -0.71854567527771
    z[2,3,1]  R1272     -7.7100795507431030e-01
    z[2,3,1]  R1273     -9.0539109706878662e-01
    z[2,3,1]  R1274     -0.53448086977005
    z[2,3,1]  R1275     -4.0648657083511353e-01
    z[2,3,1]  R1276     -6.4921647310256958e-01
    z[2,3,1]  R1277     -4.3055734038352966e-01
    z[2,3,1]  R1278     -4.0923115611076355e-01
    z[2,3,1]  R1279     0.808269202709198
    z[2,3,1]  R1280     0.915841817855835
    z[2,3,1]  R1281     8.5408157110214233e-01
    z[2,3,1]  R1282     8.2139098644256592e-01
    z[2,3,1]  R1283     6.9976997375488281e-01
    z[2,3,1]  R1284     8.7637430429458618e-01
    z[2,3,1]  R1285     7.0686239004135132e-01
    z[2,3,1]  R1286     7.2135227918624878e-01
    z[2,3,1]  R1287     8.4297072887420654e-01
    z[2,3,1]  R1288     5.6277406215667725e-01
    z[2,3,1]  R1289     8.6787194013595581e-01
    z[2,3,1]  R1290     0.759022057056427
    z[2,3,1]  R1291     3.3177286386489868e-01
    z[2,3,1]  R1292     2.6639896631240845e-01
    z[2,3,1]  R1293     5.8427613973617554e-01
    z[2,3,1]  R1294     3.9753732085227966e-01
    z[2,3,1]  R1295     6.0654246807098389e-01
    z[2,3,1]  R1296     0.597892701625824
    z[2,3,1]  R1297     5.7512110471725464e-01
    z[2,3,1]  R1298     6.0753285884857178e-01
    z[2,3,1]  R1299     -0.806343674659729
    z[2,3,1]  R1300     -7.4787521362304688e-01
    z[2,3,1]  R1301     -5.4697972536087036e-01
    z[2,3,1]  R1302     -7.7965390682220459e-01
    z[2,3,1]  R1303     -6.1561739444732666e-01
    z[2,3,1]  R1304     -6.6225737333297729e-01
    z[2,3,1]  R1305     -7.7129900455474854e-01
    z[2,3,1]  R1306     -6.8135350942611694e-01
    z[2,3,1]  R1307     -5.6042784452438354e-01
    z[2,3,1]  R1308     -3.6967614293098450e-01
    z[2,3,1]  R1309     5.6595337390899658e-01
    z[2,3,1]  R1310     5.1366031169891357e-01
    z[2,3,1]  R1311     5.6661015748977661e-01
    z[2,3,1]  R1312     5.9830093383789062e-01
    z[2,3,1]  R1313     6.0357969999313354e-01
    z[2,3,1]  R1314     8.0633997917175293e-01
    z[2,3,1]  R1315     9.2627406120300293e-01
    z[2,3,1]  R1316     6.8232113122940063e-01
    z[2,3,1]  R1317     7.1411836147308350e-01
    z[2,3,1]  R1318     6.5283042192459106e-01
    z[2,3,1]  R1319     2.1240106225013733e-01
    z[2,3,1]  R1320     1.2077067792415619e-01
    z[2,3,1]  R1321     3.3731155097484589e-02
    z[2,3,1]  R1322     -4.0616673231124878e-01
    z[2,3,1]  R1323     -9.4405815005302429e-02
    z[2,3,1]  R1324     -2.6088034734129906e-02
    z[2,3,1]  R1325     -3.3746039867401123e-01
    z[2,3,1]  R1326     4.0909877419471741e-01
    z[2,3,1]  R1327     6.6235578060150146e-01
    z[2,3,1]  R1328     7.8362166881561279e-01
    z[2,3,1]  R1329     1.4579404890537262e-01
    z[2,3,1]  R1330     -7.1627922356128693e-02
    z[2,3,1]  R1331     3.8499668240547180e-02
    z[2,3,1]  R1332     -1.4943755231797695e-02
    z[2,3,1]  R1333     -1.2556684203445911e-02
    z[2,3,1]  R1334     2.5044474005699158e-01
    z[2,3,1]  R1335     -4.3855917453765869e-01
    z[2,3,1]  R1336     7.7784001827239990e-01
    z[2,3,1]  R1337     -3.8717139512300491e-02
    z[2,3,1]  R1338     -5.4183810949325562e-01
    z[2,3,1]  R1339     -7.7265053987503052e-01
    z[2,3,1]  R1340     2.3995118215680122e-02
    z[2,3,1]  R1341     8.0874115228652954e-02
    z[2,3,1]  R1342     -5.1484964787960052e-03
    z[2,3,1]  R1343     -3.8053739070892334e-01
    z[2,3,1]  R1344     8.0667048692703247e-01
    z[2,3,1]  R1345     7.8709441423416138e-01
    z[2,3,1]  R1346     6.7205429077148438e-01
    z[2,3,1]  R1347     0.721260130405426
    z[2,3,1]  R1348     7.9820042848587036e-01
    z[2,3,1]  R1349     -3.7496453523635864e-01
    z[2,3,1]  R1350     -2.9170952737331390e-02
    z[2,3,1]  R1351     7.6787370443344116e-01
    z[2,3,1]  R1352     4.9740001559257507e-01
    z[2,3,1]  R1353     6.7751801013946533e-01
    z[2,3,1]  R1354     -2.4190092086791992e-01
    z[2,3,1]  R1355     4.2945200204849243e-01
    z[2,3,1]  R1356     2.6404294371604919e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1259     -1
    z[2,3,2]  R1260     1
    z[2,3,2]  R1269     -3.6512367427349091e-02
    z[2,3,2]  R1270     -2.8309595584869385e-01
    z[2,3,2]  R1271     4.8948526382446289e-01
    z[2,3,2]  R1272     -6.1697751283645630e-02
    z[2,3,2]  R1273     -7.4687354266643524e-02
    z[2,3,2]  R1274     2.9746848344802856e-01
    z[2,3,2]  R1275     -0.0318966880440712
    z[2,3,2]  R1276     -4.6656516194343567e-01
    z[2,3,2]  R1277     -2.1023957431316376e-01
    z[2,3,2]  R1278     1.2792116403579712e-01
    z[2,3,2]  R1279     4.3497156351804733e-02
    z[2,3,2]  R1280     -2.8441622853279114e-01
    z[2,3,2]  R1281     -2.7528798580169678e-01
    z[2,3,2]  R1282     2.6707369089126587e-01
    z[2,3,2]  R1283     -3.1428366899490356e-01
    z[2,3,2]  R1284     1.5977898240089417e-01
    z[2,3,2]  R1285     4.0474005043506622e-02
    z[2,3,2]  R1286     9.6002802252769470e-02
    z[2,3,2]  R1287     -3.2728922367095947e-01
    z[2,3,2]  R1288     -2.9421791434288025e-01
    z[2,3,2]  R1289     8.5515398532152176e-03
    z[2,3,2]  R1290     -4.5370987057685852e-01
    z[2,3,2]  R1291     2.7419024705886841e-01
    z[2,3,2]  R1292     3.0780667066574097e-01
    z[2,3,2]  R1293     6.1520017683506012e-02
    z[2,3,2]  R1294     -0.297622412443161
    z[2,3,2]  R1295     -4.1597130894660950e-01
    z[2,3,2]  R1296     -1.5419314801692963e-01
    z[2,3,2]  R1297     3.0139547586441040e-01
    z[2,3,2]  R1298     -9.3728266656398773e-02
    z[2,3,2]  R1299     -4.0706697106361389e-01
    z[2,3,2]  R1300     2.7609580755233765e-01
    z[2,3,2]  R1301     -1.5832577645778656e-01
    z[2,3,2]  R1302     -2.0530427992343903e-01
    z[2,3,2]  R1303     -2.1107414364814758e-01
    z[2,3,2]  R1304     -1.9327521324157715e-01
    z[2,3,2]  R1305     -2.5243712589144707e-02
    z[2,3,2]  R1306     -2.3439349234104156e-01
    z[2,3,2]  R1307     9.7869625315070152e-03
    z[2,3,2]  R1308     1.3684664852917194e-02
    z[2,3,2]  R1309     -0.608640730381012
    z[2,3,2]  R1310     -6.2675130367279053e-01
    z[2,3,2]  R1311     -4.3944120407104492e-01
    z[2,3,2]  R1312     -4.6132189035415649e-01
    z[2,3,2]  R1313     -5.5187779664993286e-01
    z[2,3,2]  R1314     -4.5976600050926208e-01
    z[2,3,2]  R1315     -3.1907999515533447e-01
    z[2,3,2]  R1316     -5.5827200412750244e-01
    z[2,3,2]  R1317     -3.4449258446693420e-01
    z[2,3,2]  R1318     -0.47967329621315
    z[2,3,2]  R1319     3.5087114572525024e-01
    z[2,3,2]  R1320     -1.4752382040023804e-01
    z[2,3,2]  R1321     2.0647323690354824e-03
    z[2,3,2]  R1322     5.1708000898361206e-01
    z[2,3,2]  R1323     -3.9517989754676819e-01
    z[2,3,2]  R1324     -3.5510140657424927e-01
    z[2,3,2]  R1325     6.6694790124893188e-01
    z[2,3,2]  R1326     5.2773706614971161e-02
    z[2,3,2]  R1327     2.2508682310581207e-01
    z[2,3,2]  R1328     3.2976818084716797e-01
    z[2,3,2]  R1329     -1.6189638525247574e-02
    z[2,3,2]  R1330     -2.3209549486637115e-02
    z[2,3,2]  R1331     4.3543872237205505e-01
    z[2,3,2]  R1332     -4.9028575420379639e-01
    z[2,3,2]  R1333     5.7964944839477539e-01
    z[2,3,2]  R1334     -2.1978507936000824e-01
    z[2,3,2]  R1335     6.2940829992294312e-01
    z[2,3,2]  R1336     -4.6362683176994324e-01
    z[2,3,2]  R1337     -1.1675927042961121e-01
    z[2,3,2]  R1338     3.5269770771265030e-02
    z[2,3,2]  R1339     1.3527289032936096e-01
    z[2,3,2]  R1340     1.5156303346157074e-01
    z[2,3,2]  R1341     4.1148793697357178e-01
    z[2,3,2]  R1342     1.2999449670314789e-01
    z[2,3,2]  R1343     2.2236153483390808e-02
    z[2,3,2]  R1344     -2.7773118019104004e-01
    z[2,3,2]  R1345     2.0093873143196106e-01
    z[2,3,2]  R1346     -8.3115048706531525e-02
    z[2,3,2]  R1347     9.2648655176162720e-02
    z[2,3,2]  R1348     2.6972818374633789e-01
    z[2,3,2]  R1349     -9.5397032797336578e-02
    z[2,3,2]  R1350     -6.7495889961719513e-02
    z[2,3,2]  R1351     1.4342764019966125e-01
    z[2,3,2]  R1352     -2.6181939244270325e-01
    z[2,3,2]  R1353     4.7308516502380371e-01
    z[2,3,2]  R1354     -8.9823201298713684e-02
    z[2,3,2]  R1355     2.9901077970862389e-02
    z[2,3,2]  R1356     2.3564234375953674e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1261     -1
    z[2,3,3]  R1262     1
    z[2,3,3]  R1269     -5.7133636437356472e-03
    z[2,3,3]  R1270     6.0302615165710449e-02
    z[2,3,3]  R1271     4.3359076976776123e-01
    z[2,3,3]  R1272     4.4179043173789978e-01
    z[2,3,3]  R1273     -2.4320727214217186e-02
    z[2,3,3]  R1274     -1.8579587340354919e-01
    z[2,3,3]  R1275     1.1626062542200089e-01
    z[2,3,3]  R1276     5.6650150567293167e-02
    z[2,3,3]  R1277     2.9676252603530884e-01
    z[2,3,3]  R1278     -5.9717226773500443e-02
    z[2,3,3]  R1279     3.2643941044807434e-01
    z[2,3,3]  R1280     1.9942989945411682e-01
    z[2,3,3]  R1281     -1.4164198935031891e-01
    z[2,3,3]  R1282     -6.9845512509346008e-02
    z[2,3,3]  R1283     1.9365318119525909e-01
    z[2,3,3]  R1284     3.1281337141990662e-01
    z[2,3,3]  R1285     1.5215082466602325e-01
    z[2,3,3]  R1286     3.1471386551856995e-01
    z[2,3,3]  R1287     -2.0695790648460388e-01
    z[2,3,3]  R1288     -1.8547067046165466e-01
    z[2,3,3]  R1289     -3.7688681483268738e-01
    z[2,3,3]  R1290     -1.6205094754695892e-02
    z[2,3,3]  R1291     6.4295977354049683e-01
    z[2,3,3]  R1292     7.9940801858901978e-01
    z[2,3,3]  R1293     5.2079373598098755e-01
    z[2,3,3]  R1294     7.0280265808105469e-01
    z[2,3,3]  R1295     -4.1959017515182495e-01
    z[2,3,3]  R1296     6.6072773933410645e-01
    z[2,3,3]  R1297     -1.7309138178825378e-01
    z[2,3,3]  R1298     3.5341003537178040e-01
    z[2,3,3]  R1299     6.1551958322525024e-02
    z[2,3,3]  R1300     4.7896894812583923e-01
    z[2,3,3]  R1301     2.5067204236984253e-01
    z[2,3,3]  R1302     4.6751942485570908e-02
    z[2,3,3]  R1303     1.4026145637035370e-01
    z[2,3,3]  R1304     1.5647675096988678e-01
    z[2,3,3]  R1305     1.7780081927776337e-01
    z[2,3,3]  R1306     -1.3124364614486694e-01
    z[2,3,3]  R1307     1.5760404989123344e-02
    z[2,3,3]  R1308     2.5649723410606384e-01
    z[2,3,3]  R1309     2.4812524020671844e-01
    z[2,3,3]  R1310     3.5732197761535645e-01
    z[2,3,3]  R1311     4.4686308503150940e-01
    z[2,3,3]  R1312     1.5797902643680573e-01
    z[2,3,3]  R1313     2.2483283281326294e-01
    z[2,3,3]  R1314     5.8787297457456589e-03
    z[2,3,3]  R1315     -5.5460810661315918e-02
    z[2,3,3]  R1316     1.8514537811279297e-01
    z[2,3,3]  R1317     5.3036159276962280e-01
    z[2,3,3]  R1318     -2.1677853539586067e-02
    z[2,3,3]  R1319     6.0600304603576660e-01
    z[2,3,3]  R1320     5.8472746610641479e-01
    z[2,3,3]  R1321     6.8398469686508179e-01
    z[2,3,3]  R1322     -3.9802172780036926e-01
    z[2,3,3]  R1323     5.8413773775100708e-01
    z[2,3,3]  R1324     8.2769459486007690e-01
    z[2,3,3]  R1325     -3.2512679696083069e-01
    z[2,3,3]  R1326     7.4470067024230957e-01
    z[2,3,3]  R1327     -5.3577250242233276e-01
    z[2,3,3]  R1328     -8.4929518401622772e-02
    z[2,3,3]  R1329     8.5579985380172729e-01
    z[2,3,3]  R1330     7.4300438165664673e-01
    z[2,3,3]  R1331     6.4403080940246582e-01
    z[2,3,3]  R1332     6.7152398824691772e-01
    z[2,3,3]  R1333     5.8258867263793945e-01
    z[2,3,3]  R1334     8.9625442028045654e-01
    z[2,3,3]  R1335     -2.3738366365432739e-01
    z[2,3,3]  R1336     1.0044626891613007e-01
    z[2,3,3]  R1337     1.3373105227947235e-01
    z[2,3,3]  R1338     -4.7404131293296814e-01
    z[2,3,3]  R1339     2.4768961966037750e-01
    z[2,3,3]  R1340     7.8221571445465088e-01
    z[2,3,3]  R1341     5.4474240541458130e-01
    z[2,3,3]  R1342     8.0291819572448730e-01
    z[2,3,3]  R1343     -1.3453532755374908e-01
    z[2,3,3]  R1344     -3.0108213424682617e-01
    z[2,3,3]  R1345     -4.1620391607284546e-01
    z[2,3,3]  R1346     -1.4135645329952240e-01
    z[2,3,3]  R1347     -2.6950651407241821e-01
    z[2,3,3]  R1348     -0.0194667000323534
    z[2,3,3]  R1349     5.1125931739807129e-01
    z[2,3,3]  R1350     5.4380977153778076e-01
    z[2,3,3]  R1351     -4.5670115947723389e-01
    z[2,3,3]  R1352     2.3274455219507217e-02
    z[2,3,3]  R1353     -3.3306321501731873e-01
    z[2,3,3]  R1354     -8.4590435028076172e-01
    z[2,3,3]  R1355     -0.573287844657898
    z[2,3,3]  R1356     -7.3486495018005371e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1263     -1
    z[2,3,4]  R1264     1
    z[2,3,4]  R1269     -3.4494879841804504e-01
    z[2,3,4]  R1270     -6.2019479274749756e-01
    z[2,3,4]  R1271     -1.2619766592979431e-01
    z[2,3,4]  R1272     1.2386779487133026e-01
    z[2,3,4]  R1273     1.1356448382139206e-01
    z[2,3,4]  R1274     -0.685459315776825
    z[2,3,4]  R1275     -1.7781707644462585e-01
    z[2,3,4]  R1276     -5.6831365823745728e-01
    z[2,3,4]  R1277     -8.9890755712985992e-02
    z[2,3,4]  R1278     -0.570176362991333
    z[2,3,4]  R1279     -5.1463317126035690e-02
    z[2,3,4]  R1280     4.9570216797292233e-03
    z[2,3,4]  R1281     -2.1611016988754272e-01
    z[2,3,4]  R1282     3.0435770750045776e-01
    z[2,3,4]  R1283     3.5316145420074463e-01
    z[2,3,4]  R1284     2.9572373628616333e-01
    z[2,3,4]  R1285     4.7489190101623535e-01
    z[2,3,4]  R1286     5.1569879055023193e-01
    z[2,3,4]  R1287     -2.3159846663475037e-01
    z[2,3,4]  R1288     6.1637425422668457e-01
    z[2,3,4]  R1289     -2.5623646378517151e-01
    z[2,3,4]  R1290     2.5742354989051819e-01
    z[2,3,4]  R1291     3.6368942260742188e-01
    z[2,3,4]  R1292     -2.6839458942413330e-01
    z[2,3,4]  R1293     -0.610956072807312
    z[2,3,4]  R1294     -2.6510828733444214e-01
    z[2,3,4]  R1295     7.2587326169013977e-02
    z[2,3,4]  R1296     -2.4104593694210052e-01
    z[2,3,4]  R1297     0.389614462852478
    z[2,3,4]  R1298     -4.4050836563110352e-01
    z[2,3,4]  R1299     -9.3001998960971832e-02
    z[2,3,4]  R1300     -0.243952676653862
    z[2,3,4]  R1301     -2.0971670746803284e-01
    z[2,3,4]  R1302     2.3346078395843506e-01
    z[2,3,4]  R1303     -6.7958253622055054e-01
    z[2,3,4]  R1304     -3.7784937024116516e-01
    z[2,3,4]  R1305     -4.1286323219537735e-02
    z[2,3,4]  R1306     8.5462033748626709e-02
    z[2,3,4]  R1307     2.0253455638885498e-01
    z[2,3,4]  R1308     -5.8184742927551270e-01
    z[2,3,4]  R1309     5.2968215197324753e-02
    z[2,3,4]  R1310     0.19495889544487
    z[2,3,4]  R1311     1.6109964251518250e-01
    z[2,3,4]  R1312     4.7200888395309448e-01
    z[2,3,4]  R1313     3.9044788479804993e-01
    z[2,3,4]  R1314     -4.2544011026620865e-02
    z[2,3,4]  R1315     -4.1648335754871368e-02
    z[2,3,4]  R1316     3.6156203597784042e-02
    z[2,3,4]  R1317     2.1014837920665741e-01
    z[2,3,4]  R1318     4.9418565630912781e-01
    z[2,3,4]  R1319     4.8908448219299316e-01
    z[2,3,4]  R1320     7.0103943347930908e-01
    z[2,3,4]  R1321     0.702874481678009
    z[2,3,4]  R1322     5.2173024415969849e-01
    z[2,3,4]  R1323     4.0692262351512909e-02
    z[2,3,4]  R1324     1.3809283077716827e-01
    z[2,3,4]  R1325     0.253192275762558
    z[2,3,4]  R1326     -4.7943615913391113e-01
    z[2,3,4]  R1327     2.1010509133338928e-01
    z[2,3,4]  R1328     3.3108437061309814e-01
    z[2,3,4]  R1329     6.7822962999343872e-02
    z[2,3,4]  R1330     4.7397625446319580e-01
    z[2,3,4]  R1331     0.380689412355423
    z[2,3,4]  R1332     4.0593007206916809e-01
    z[2,3,4]  R1333     4.5717760920524597e-01
    z[2,3,4]  R1334     0.0681137964129448
    z[2,3,4]  R1335     3.3291794359683990e-02
    z[2,3,4]  R1336     2.6483932137489319e-01
    z[2,3,4]  R1337     2.0271314308047295e-02
    z[2,3,4]  R1338     4.1267621517181396e-01
    z[2,3,4]  R1339     5.1104915142059326e-01
    z[2,3,4]  R1340     -1.2227982282638550e-01
    z[2,3,4]  R1341     1.0072357952594757e-01
    z[2,3,4]  R1342     5.7149904966354370e-01
    z[2,3,4]  R1343     4.1737398505210876e-01
    z[2,3,4]  R1344     3.5202163457870483e-01
    z[2,3,4]  R1345     1.8234199285507202e-01
    z[2,3,4]  R1346     -4.2491161823272705e-01
    z[2,3,4]  R1347     3.2057291269302368e-01
    z[2,3,4]  R1348     2.3103576898574829e-01
    z[2,3,4]  R1349     6.3102084398269653e-01
    z[2,3,4]  R1350     -4.9971025437116623e-02
    z[2,3,4]  R1351     -6.2883630394935608e-02
    z[2,3,4]  R1352     -4.3417948484420776e-01
    z[2,3,4]  R1353     -1.5676176548004150e-01
    z[2,3,4]  R1354     -2.7827453613281250e-01
    z[2,3,4]  R1355     5.6708522140979767e-02
    z[2,3,4]  R1356     -0.393111914396286
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1265     -1
    z[2,3,5]  R1266     1
    z[2,3,5]  R1269     7.3272442817687988e-01
    z[2,3,5]  R1270     5.7743382453918457e-01
    z[2,3,5]  R1271     -1.1910753697156906e-01
    z[2,3,5]  R1272     9.9070534110069275e-02
    z[2,3,5]  R1273     1.4756646752357483e-01
    z[2,3,5]  R1274     2.8583604097366333e-01
    z[2,3,5]  R1275     7.0279783010482788e-01
    z[2,3,5]  R1276     -5.8415614068508148e-02
    z[2,3,5]  R1277     4.1297596693038940e-01
    z[2,3,5]  R1278     2.5528600811958313e-01
    z[2,3,5]  R1279     4.4018706679344177e-01
    z[2,3,5]  R1280     1.9469425082206726e-01
    z[2,3,5]  R1281     3.5704341530799866e-01
    z[2,3,5]  R1282     3.5296735167503357e-01
    z[2,3,5]  R1283     3.7022951245307922e-01
    z[2,3,5]  R1284     -6.9216839969158173e-02
    z[2,3,5]  R1285     3.6752417683601379e-01
    z[2,3,5]  R1286     1.9860202074050903e-01
    z[2,3,5]  R1287     -8.5678435862064362e-02
    z[2,3,5]  R1288     3.0596208572387695e-01
    z[2,3,5]  R1289     3.2019170466810465e-03
    z[2,3,5]  R1290     -2.9590100049972534e-01
    z[2,3,5]  R1291     5.0767010450363159e-01
    z[2,3,5]  R1292     1.7190322279930115e-01
    z[2,3,5]  R1293     6.0550201684236526e-02
    z[2,3,5]  R1294     1.5664808452129364e-01
    z[2,3,5]  R1295     8.2535691559314728e-02
    z[2,3,5]  R1296     -1.4474037289619446e-01
    z[2,3,5]  R1297     -4.6410274505615234e-01
    z[2,3,5]  R1298     -2.1927395462989807e-01
    z[2,3,5]  R1299     2.0027369260787964e-01
    z[2,3,5]  R1300     -2.0059290528297424e-01
    z[2,3,5]  R1301     7.3737972974777222e-01
    z[2,3,5]  R1302     3.3789855241775513e-01
    z[2,3,5]  R1303     2.9510873556137085e-01
    z[2,3,5]  R1304     1.1082833260297775e-01
    z[2,3,5]  R1305     -1.8597602844238281e-02
    z[2,3,5]  R1306     6.3809168338775635e-01
    z[2,3,5]  R1307     5.1412415504455566e-01
    z[2,3,5]  R1308     2.2193567454814911e-01
    z[2,3,5]  R1309     4.7651696205139160e-01
    z[2,3,5]  R1310     3.9702513813972473e-01
    z[2,3,5]  R1311     4.5929023623466492e-01
    z[2,3,5]  R1312     3.5141962766647339e-01
    z[2,3,5]  R1313     2.6954549551010132e-01
    z[2,3,5]  R1314     2.2822347283363342e-01
    z[2,3,5]  R1315     1.8463383615016937e-01
    z[2,3,5]  R1316     5.9028938412666321e-02
    z[2,3,5]  R1317     1.6448110342025757e-02
    z[2,3,5]  R1318     -2.9617862310260534e-03
    z[2,3,5]  R1319     4.3487283587455750e-01
    z[2,3,5]  R1320     0.246379092335701
    z[2,3,5]  R1321     -2.6688998565077782e-02
    z[2,3,5]  R1322     -3.6006936430931091e-01
    z[2,3,5]  R1323     -3.3044733107089996e-02
    z[2,3,5]  R1324     -1.2369648553431034e-02
    z[2,3,5]  R1325     -0.078908272087574
    z[2,3,5]  R1326     1.9652260839939117e-01
    z[2,3,5]  R1327     -3.7982729077339172e-01
    z[2,3,5]  R1328     -3.8389933109283447e-01
    z[2,3,5]  R1329     1.1742393672466278e-01
    z[2,3,5]  R1330     2.2076445817947388e-01
    z[2,3,5]  R1331     -1.8585156649351120e-02
    z[2,3,5]  R1332     2.5669746100902557e-02
    z[2,3,5]  R1333     -2.8313967585563660e-01
    z[2,3,5]  R1334     -2.1947419270873070e-02
    z[2,3,5]  R1335     4.3435059487819672e-02
    z[2,3,5]  R1336     1.1600136011838913e-01
    z[2,3,5]  R1337     6.5694665908813477e-01
    z[2,3,5]  R1338     -3.4724801778793335e-01
    z[2,3,5]  R1339     8.6945161223411560e-02
    z[2,3,5]  R1340     3.3828487992286682e-01
    z[2,3,5]  R1341     0.336469441652298
    z[2,3,5]  R1342     -1.1990658938884735e-02
    z[2,3,5]  R1343     -3.3678838610649109e-01
    z[2,3,5]  R1344     1.4801153540611267e-01
    z[2,3,5]  R1345     -1.5591630339622498e-01
    z[2,3,5]  R1346     -3.3089622855186462e-01
    z[2,3,5]  R1347     -3.6007410287857056e-01
    z[2,3,5]  R1348     -4.1901135444641113e-01
    z[2,3,5]  R1349     -2.1696336567401886e-01
    z[2,3,5]  R1350     2.7509140968322754e-01
    z[2,3,5]  R1351     -3.1465375423431396e-01
    z[2,3,5]  R1352     -2.6323834061622620e-01
    z[2,3,5]  R1353     -1.2563192844390869e-01
    z[2,3,5]  R1354     -2.9858118295669556e-01
    z[2,3,5]  R1355     -3.3711439371109009e-01
    z[2,3,5]  R1356     3.8634178042411804e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1267     -1
    z[2,3,6]  R1268     1
    z[2,3,6]  R1269     1.6707342863082886e-01
    z[2,3,6]  R1270     -1.5947981178760529e-01
    z[2,3,6]  R1271     1.1592247337102890e-01
    z[2,3,6]  R1272     4.2579475045204163e-01
    z[2,3,6]  R1273     -3.2284185290336609e-01
    z[2,3,6]  R1274     8.2118771970272064e-02
    z[2,3,6]  R1275     -5.2011966705322266e-01
    z[2,3,6]  R1276     0.106770820915699
    z[2,3,6]  R1277     -6.4204132556915283e-01
    z[2,3,6]  R1278     -0.638708233833313
    z[2,3,6]  R1279     1.6347558796405792e-01
    z[2,3,6]  R1280     4.2418867349624634e-02
    z[2,3,6]  R1281     6.5617696382105350e-03
    z[2,3,6]  R1282     4.5117955654859543e-02
    z[2,3,6]  R1283     3.3418801426887512e-01
    z[2,3,6]  R1284     9.3657158315181732e-02
    z[2,3,6]  R1285     -3.3215171098709106e-01
    z[2,3,6]  R1286     2.3647336661815643e-01
    z[2,3,6]  R1287     2.7245423197746277e-01
    z[2,3,6]  R1288     -0.257385790348053
    z[2,3,6]  R1289     -1.8693499267101288e-01
    z[2,3,6]  R1290     -1.6323995590209961e-01
    z[2,3,6]  R1291     -1.0348517447710037e-01
    z[2,3,6]  R1292     -3.0516979098320007e-01
    z[2,3,6]  R1293     -7.4036069214344025e-02
    z[2,3,6]  R1294     4.0562847256660461e-01
    z[2,3,6]  R1295     5.1011914014816284e-01
    z[2,3,6]  R1296     -2.7839767932891846e-01
    z[2,3,6]  R1297     -4.2455330491065979e-01
    z[2,3,6]  R1298     4.8394781351089478e-01
    z[2,3,6]  R1299     -2.7024172246456146e-02
    z[2,3,6]  R1300     -9.2960305511951447e-02
    z[2,3,6]  R1301     1.5328544378280640e-01
    z[2,3,6]  R1302     4.0478572249412537e-01
    z[2,3,6]  R1303     8.5655406117439270e-02
    z[2,3,6]  R1304     5.5611610412597656e-01
    z[2,3,6]  R1305     5.8828455209732056e-01
    z[2,3,6]  R1306     -1.9911254942417145e-01
    z[2,3,6]  R1307     -5.8473336696624756e-01
    z[2,3,6]  R1308     -6.3331574201583862e-01
    z[2,3,6]  R1309     -1.2940365076065063e-01
    z[2,3,6]  R1310     1.3666908442974091e-01
    z[2,3,6]  R1311     4.9621118232607841e-03
    z[2,3,6]  R1312     -2.3997332155704498e-01
    z[2,3,6]  R1313     -1.7408396303653717e-01
    z[2,3,6]  R1314     -0.223873108625412
    z[2,3,6]  R1315     -3.0624959617853165e-02
    z[2,3,6]  R1316     -1.0289679467678070e-01
    z[2,3,6]  R1317     -2.9153700917959213e-02
    z[2,3,6]  R1318     1.6441315412521362e-01
    z[2,3,6]  R1319     -5.2010573446750641e-02
    z[2,3,6]  R1320     -2.6188856363296509e-01
    z[2,3,6]  R1321     -1.7743955552577972e-01
    z[2,3,6]  R1322     9.1521563008427620e-03
    z[2,3,6]  R1323     -0.0802517980337143
    z[2,3,6]  R1324     -1.7082595825195312e-01
    z[2,3,6]  R1325     -1.0478270053863525e-01
    z[2,3,6]  R1326     0.0362219400703907
    z[2,3,6]  R1327     2.0498305559158325e-02
    z[2,3,6]  R1328     1.9291643053293228e-02
    z[2,3,6]  R1329     -3.5813847184181213e-01
    z[2,3,6]  R1330     1.9769731163978577e-01
    z[2,3,6]  R1331     -4.9664962291717529e-01
    z[2,3,6]  R1332     1.7384378612041473e-01
    z[2,3,6]  R1333     3.8115769624710083e-02
    z[2,3,6]  R1334     2.1018664538860321e-01
    z[2,3,6]  R1335     -1.2856742739677429e-01
    z[2,3,6]  R1336     -1.3096508383750916e-01
    z[2,3,6]  R1337     -6.0381293296813965e-02
    z[2,3,6]  R1338     -4.1922357678413391e-01
    z[2,3,6]  R1339     -1.0657577216625214e-01
    z[2,3,6]  R1340     -3.2016387581825256e-01
    z[2,3,6]  R1341     6.2875300645828247e-01
    z[2,3,6]  R1342     -6.3919365406036377e-02
    z[2,3,6]  R1343     -6.0191076993942261e-01
    z[2,3,6]  R1344     -1.8667422235012054e-01
    z[2,3,6]  R1345     2.2959427535533905e-01
    z[2,3,6]  R1346     -2.4552170187234879e-02
    z[2,3,6]  R1347     3.8883426785469055e-01
    z[2,3,6]  R1348     0.190166175365448
    z[2,3,6]  R1349     -6.2794364988803864e-02
    z[2,3,6]  R1350     -6.0246515274047852e-01
    z[2,3,6]  R1351     -0.0921337753534317
    z[2,3,6]  R1352     5.1443153619766235e-01
    z[2,3,6]  R1353     2.5557265616953373e-03
    z[2,3,6]  R1354     -3.8667377084493637e-02
    z[2,3,6]  R1355     1.2433449923992157e-01
    z[2,3,6]  R1356     -1.7583039402961731e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1357     -1
    z[3,2,0]  R1358     1
    z[3,2,0]  R1371     3.6170229315757751e-01
    z[3,2,0]  R1372     1.6324986517429352e-01
    z[3,2,0]  R1373     -4.1269157081842422e-02
    z[3,2,0]  R1374     1.2358608096837997e-01
    z[3,2,0]  R1375     -2.3048009723424911e-02
    z[3,2,0]  R1376     1.8776720762252808e-01
    z[3,2,0]  R1377     -1.5722067654132843e-01
    z[3,2,0]  R1378     -9.7374036908149719e-02
    z[3,2,0]  R1379     -1.9575388729572296e-01
    z[3,2,0]  R1380     9.2036321759223938e-02
    z[3,2,0]  R1381     -3.2675590366125107e-02
    z[3,2,0]  R1382     -3.6611091345548630e-02
    z[3,2,0]  R1383     -2.2188383340835571e-01
    z[3,2,0]  R1384     -1.9630396738648415e-02
    z[3,2,0]  R1385     1.5862879157066345e-01
    z[3,2,0]  R1386     1.8542206287384033e-01
    z[3,2,0]  R1387     1.9136006012558937e-02
    z[3,2,0]  R1388     4.1606724262237549e-01
    z[3,2,0]  R1389     2.1164511144161224e-01
    z[3,2,0]  R1390     2.6832106709480286e-01
    z[3,2,0]  R1391     1.8306382000446320e-01
    z[3,2,0]  R1392     3.1629450619220734e-02
    z[3,2,0]  R1393     6.9233119487762451e-02
    z[3,2,0]  R1394     -8.5436977446079254e-02
    z[3,2,0]  R1395     -6.9607138633728027e-01
    z[3,2,0]  R1396     -3.7381795048713684e-01
    z[3,2,0]  R1397     -5.0426310300827026e-01
    z[3,2,0]  R1398     -7.4039585888385773e-02
    z[3,2,0]  R1399     1.8637432157993317e-01
    z[3,2,0]  R1400     1.1229066550731659e-01
    z[3,2,0]  R1401     3.1533634662628174e-01
    z[3,2,0]  R1402     -3.6027842760086060e-01
    z[3,2,0]  R1403     4.6952001750469208e-02
    z[3,2,0]  R1404     3.3584558963775635e-01
    z[3,2,0]  R1405     -1.8386675417423248e-01
    z[3,2,0]  R1406     1.9078862667083740e-01
    z[3,2,0]  R1407     -5.7934051752090454e-01
    z[3,2,0]  R1408     2.6301616430282593e-01
    z[3,2,0]  R1409     -7.2893661260604858e-01
    z[3,2,0]  R1410     1.1756321042776108e-01
    z[3,2,0]  R1411     -2.0802223682403564e-01
    z[3,2,0]  R1412     -3.6427670717239380e-01
    z[3,2,0]  R1413     -9.3302980065345764e-02
    z[3,2,0]  R1414     -8.6929149925708771e-02
    z[3,2,0]  R1415     4.3205675482749939e-01
    z[3,2,0]  R1416     0.0286989975720644
    z[3,2,0]  R1417     2.3792499303817749e-01
    z[3,2,0]  R1418     4.8042505979537964e-01
    z[3,2,0]  R1419     1.2228551506996155e-01
    z[3,2,0]  R1420     1.5694823861122131e-01
    z[3,2,0]  R1421     3.7377968430519104e-01
    z[3,2,0]  R1422     5.0766885280609131e-01
    z[3,2,0]  R1423     2.6414486765861511e-01
    z[3,2,0]  R1424     4.0131795406341553e-01
    z[3,2,0]  R1425     -4.0726464986801147e-01
    z[3,2,0]  R1426     -2.2311198711395264e-01
    z[3,2,0]  R1427     -5.9472423791885376e-01
    z[3,2,0]  R1428     -3.7742203567177057e-03
    z[3,2,0]  R1429     -7.6891683042049408e-02
    z[3,2,0]  R1430     9.7774147987365723e-02
    z[3,2,0]  R1431     -1.1200371384620667e-01
    z[3,2,0]  R1432     -1.0103247128427029e-02
    z[3,2,0]  R1433     1.8761040270328522e-01
    z[3,2,0]  R1434     -1.8172055482864380e-01
    z[3,2,0]  R1435     1.5545558929443359e-01
    z[3,2,0]  R1436     1.4082913100719452e-01
    z[3,2,0]  R1437     3.0249828100204468e-01
    z[3,2,0]  R1438     1.1991544812917709e-01
    z[3,2,0]  R1439     -1.2291748821735382e-01
    z[3,2,0]  R1440     2.8967265039682388e-02
    z[3,2,0]  R1441     -0.0217283982783556
    z[3,2,0]  R1442     -1.7278583347797394e-01
    z[3,2,0]  R1443     -2.3908168077468872e-02
    z[3,2,0]  R1444     -8.7013579905033112e-02
    z[3,2,0]  R1445     0.06809101998806
    z[3,2,0]  R1446     -1.0040861368179321e-01
    z[3,2,0]  R1447     -6.5120466053485870e-02
    z[3,2,0]  R1448     1.5014787018299103e-01
    z[3,2,0]  R1449     -6.3791498541831970e-02
    z[3,2,0]  R1450     1.9312863051891327e-01
    z[3,2,0]  R1451     -2.5318851694464684e-02
    z[3,2,0]  R1452     2.2771932184696198e-02
    z[3,2,0]  R1453     -3.4576624631881714e-02
    z[3,2,0]  R1454     -9.8926816135644913e-03
    z[3,2,0]  R1455     -1.0351626574993134e-01
    z[3,2,0]  R1456     1.6009204089641571e-01
    z[3,2,0]  R1457     3.1615566462278366e-02
    z[3,2,0]  R1458     -1.4451977610588074e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1359     -1
    z[3,2,1]  R1360     1
    z[3,2,1]  R1371     -0.806343674659729
    z[3,2,1]  R1372     -7.4787521362304688e-01
    z[3,2,1]  R1373     -5.4697972536087036e-01
    z[3,2,1]  R1374     -7.7965390682220459e-01
    z[3,2,1]  R1375     -6.1561739444732666e-01
    z[3,2,1]  R1376     -6.6225737333297729e-01
    z[3,2,1]  R1377     -7.7129900455474854e-01
    z[3,2,1]  R1378     -6.8135350942611694e-01
    z[3,2,1]  R1379     -5.6042784452438354e-01
    z[3,2,1]  R1380     -3.6967614293098450e-01
    z[3,2,1]  R1381     5.6595337390899658e-01
    z[3,2,1]  R1382     5.1366031169891357e-01
    z[3,2,1]  R1383     5.6661015748977661e-01
    z[3,2,1]  R1384     5.9830093383789062e-01
    z[3,2,1]  R1385     6.0357969999313354e-01
    z[3,2,1]  R1386     8.0633997917175293e-01
    z[3,2,1]  R1387     9.2627406120300293e-01
    z[3,2,1]  R1388     6.8232113122940063e-01
    z[3,2,1]  R1389     7.1411836147308350e-01
    z[3,2,1]  R1390     6.5283042192459106e-01
    z[3,2,1]  R1391     2.1240106225013733e-01
    z[3,2,1]  R1392     1.2077067792415619e-01
    z[3,2,1]  R1393     3.3731155097484589e-02
    z[3,2,1]  R1394     -4.0616673231124878e-01
    z[3,2,1]  R1395     -9.4405815005302429e-02
    z[3,2,1]  R1396     -2.6088034734129906e-02
    z[3,2,1]  R1397     -3.3746039867401123e-01
    z[3,2,1]  R1398     4.0909877419471741e-01
    z[3,2,1]  R1399     6.6235578060150146e-01
    z[3,2,1]  R1400     7.8362166881561279e-01
    z[3,2,1]  R1401     1.4579404890537262e-01
    z[3,2,1]  R1402     -7.1627922356128693e-02
    z[3,2,1]  R1403     3.8499668240547180e-02
    z[3,2,1]  R1404     -1.4943755231797695e-02
    z[3,2,1]  R1405     -1.2556684203445911e-02
    z[3,2,1]  R1406     2.5044474005699158e-01
    z[3,2,1]  R1407     -4.3855917453765869e-01
    z[3,2,1]  R1408     7.7784001827239990e-01
    z[3,2,1]  R1409     -3.8717139512300491e-02
    z[3,2,1]  R1410     -5.4183810949325562e-01
    z[3,2,1]  R1411     -7.7265053987503052e-01
    z[3,2,1]  R1412     2.3995118215680122e-02
    z[3,2,1]  R1413     8.0874115228652954e-02
    z[3,2,1]  R1414     -5.1484964787960052e-03
    z[3,2,1]  R1415     -3.8053739070892334e-01
    z[3,2,1]  R1416     8.0667048692703247e-01
    z[3,2,1]  R1417     7.8709441423416138e-01
    z[3,2,1]  R1418     6.7205429077148438e-01
    z[3,2,1]  R1419     0.721260130405426
    z[3,2,1]  R1420     7.9820042848587036e-01
    z[3,2,1]  R1421     -3.7496453523635864e-01
    z[3,2,1]  R1422     -2.9170952737331390e-02
    z[3,2,1]  R1423     7.6787370443344116e-01
    z[3,2,1]  R1424     4.9740001559257507e-01
    z[3,2,1]  R1425     6.7751801013946533e-01
    z[3,2,1]  R1426     -2.4190092086791992e-01
    z[3,2,1]  R1427     4.2945200204849243e-01
    z[3,2,1]  R1428     2.6404294371604919e-01
    z[3,2,1]  R1429     -5.5581796169281006e-01
    z[3,2,1]  R1430     -4.0392491221427917e-01
    z[3,2,1]  R1431     -0.71854567527771
    z[3,2,1]  R1432     -7.7100795507431030e-01
    z[3,2,1]  R1433     -9.0539109706878662e-01
    z[3,2,1]  R1434     -0.53448086977005
    z[3,2,1]  R1435     -4.0648657083511353e-01
    z[3,2,1]  R1436     -6.4921647310256958e-01
    z[3,2,1]  R1437     -4.3055734038352966e-01
    z[3,2,1]  R1438     -4.0923115611076355e-01
    z[3,2,1]  R1439     0.808269202709198
    z[3,2,1]  R1440     0.915841817855835
    z[3,2,1]  R1441     8.5408157110214233e-01
    z[3,2,1]  R1442     8.2139098644256592e-01
    z[3,2,1]  R1443     6.9976997375488281e-01
    z[3,2,1]  R1444     8.7637430429458618e-01
    z[3,2,1]  R1445     7.0686239004135132e-01
    z[3,2,1]  R1446     7.2135227918624878e-01
    z[3,2,1]  R1447     8.4297072887420654e-01
    z[3,2,1]  R1448     5.6277406215667725e-01
    z[3,2,1]  R1449     8.6787194013595581e-01
    z[3,2,1]  R1450     0.759022057056427
    z[3,2,1]  R1451     3.3177286386489868e-01
    z[3,2,1]  R1452     2.6639896631240845e-01
    z[3,2,1]  R1453     5.8427613973617554e-01
    z[3,2,1]  R1454     3.9753732085227966e-01
    z[3,2,1]  R1455     6.0654246807098389e-01
    z[3,2,1]  R1456     0.597892701625824
    z[3,2,1]  R1457     5.7512110471725464e-01
    z[3,2,1]  R1458     6.0753285884857178e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1361     -1
    z[3,2,2]  R1362     1
    z[3,2,2]  R1371     -4.0706697106361389e-01
    z[3,2,2]  R1372     2.7609580755233765e-01
    z[3,2,2]  R1373     -1.5832577645778656e-01
    z[3,2,2]  R1374     -2.0530427992343903e-01
    z[3,2,2]  R1375     -2.1107414364814758e-01
    z[3,2,2]  R1376     -1.9327521324157715e-01
    z[3,2,2]  R1377     -2.5243712589144707e-02
    z[3,2,2]  R1378     -2.3439349234104156e-01
    z[3,2,2]  R1379     9.7869625315070152e-03
    z[3,2,2]  R1380     1.3684664852917194e-02
    z[3,2,2]  R1381     -0.608640730381012
    z[3,2,2]  R1382     -6.2675130367279053e-01
    z[3,2,2]  R1383     -4.3944120407104492e-01
    z[3,2,2]  R1384     -4.6132189035415649e-01
    z[3,2,2]  R1385     -5.5187779664993286e-01
    z[3,2,2]  R1386     -4.5976600050926208e-01
    z[3,2,2]  R1387     -3.1907999515533447e-01
    z[3,2,2]  R1388     -5.5827200412750244e-01
    z[3,2,2]  R1389     -3.4449258446693420e-01
    z[3,2,2]  R1390     -0.47967329621315
    z[3,2,2]  R1391     3.5087114572525024e-01
    z[3,2,2]  R1392     -1.4752382040023804e-01
    z[3,2,2]  R1393     2.0647323690354824e-03
    z[3,2,2]  R1394     5.1708000898361206e-01
    z[3,2,2]  R1395     -3.9517989754676819e-01
    z[3,2,2]  R1396     -3.5510140657424927e-01
    z[3,2,2]  R1397     6.6694790124893188e-01
    z[3,2,2]  R1398     5.2773706614971161e-02
    z[3,2,2]  R1399     2.2508682310581207e-01
    z[3,2,2]  R1400     3.2976818084716797e-01
    z[3,2,2]  R1401     -1.6189638525247574e-02
    z[3,2,2]  R1402     -2.3209549486637115e-02
    z[3,2,2]  R1403     4.3543872237205505e-01
    z[3,2,2]  R1404     -4.9028575420379639e-01
    z[3,2,2]  R1405     5.7964944839477539e-01
    z[3,2,2]  R1406     -2.1978507936000824e-01
    z[3,2,2]  R1407     6.2940829992294312e-01
    z[3,2,2]  R1408     -4.6362683176994324e-01
    z[3,2,2]  R1409     -1.1675927042961121e-01
    z[3,2,2]  R1410     3.5269770771265030e-02
    z[3,2,2]  R1411     1.3527289032936096e-01
    z[3,2,2]  R1412     1.5156303346157074e-01
    z[3,2,2]  R1413     4.1148793697357178e-01
    z[3,2,2]  R1414     1.2999449670314789e-01
    z[3,2,2]  R1415     2.2236153483390808e-02
    z[3,2,2]  R1416     -2.7773118019104004e-01
    z[3,2,2]  R1417     2.0093873143196106e-01
    z[3,2,2]  R1418     -8.3115048706531525e-02
    z[3,2,2]  R1419     9.2648655176162720e-02
    z[3,2,2]  R1420     2.6972818374633789e-01
    z[3,2,2]  R1421     -9.5397032797336578e-02
    z[3,2,2]  R1422     -6.7495889961719513e-02
    z[3,2,2]  R1423     1.4342764019966125e-01
    z[3,2,2]  R1424     -2.6181939244270325e-01
    z[3,2,2]  R1425     4.7308516502380371e-01
    z[3,2,2]  R1426     -8.9823201298713684e-02
    z[3,2,2]  R1427     2.9901077970862389e-02
    z[3,2,2]  R1428     2.3564234375953674e-01
    z[3,2,2]  R1429     -3.6512367427349091e-02
    z[3,2,2]  R1430     -2.8309595584869385e-01
    z[3,2,2]  R1431     4.8948526382446289e-01
    z[3,2,2]  R1432     -6.1697751283645630e-02
    z[3,2,2]  R1433     -7.4687354266643524e-02
    z[3,2,2]  R1434     2.9746848344802856e-01
    z[3,2,2]  R1435     -0.0318966880440712
    z[3,2,2]  R1436     -4.6656516194343567e-01
    z[3,2,2]  R1437     -2.1023957431316376e-01
    z[3,2,2]  R1438     1.2792116403579712e-01
    z[3,2,2]  R1439     4.3497156351804733e-02
    z[3,2,2]  R1440     -2.8441622853279114e-01
    z[3,2,2]  R1441     -2.7528798580169678e-01
    z[3,2,2]  R1442     2.6707369089126587e-01
    z[3,2,2]  R1443     -3.1428366899490356e-01
    z[3,2,2]  R1444     1.5977898240089417e-01
    z[3,2,2]  R1445     4.0474005043506622e-02
    z[3,2,2]  R1446     9.6002802252769470e-02
    z[3,2,2]  R1447     -3.2728922367095947e-01
    z[3,2,2]  R1448     -2.9421791434288025e-01
    z[3,2,2]  R1449     8.5515398532152176e-03
    z[3,2,2]  R1450     -4.5370987057685852e-01
    z[3,2,2]  R1451     2.7419024705886841e-01
    z[3,2,2]  R1452     3.0780667066574097e-01
    z[3,2,2]  R1453     6.1520017683506012e-02
    z[3,2,2]  R1454     -0.297622412443161
    z[3,2,2]  R1455     -4.1597130894660950e-01
    z[3,2,2]  R1456     -1.5419314801692963e-01
    z[3,2,2]  R1457     3.0139547586441040e-01
    z[3,2,2]  R1458     -9.3728266656398773e-02
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1363     -1
    z[3,2,3]  R1364     1
    z[3,2,3]  R1371     6.1551958322525024e-02
    z[3,2,3]  R1372     4.7896894812583923e-01
    z[3,2,3]  R1373     2.5067204236984253e-01
    z[3,2,3]  R1374     4.6751942485570908e-02
    z[3,2,3]  R1375     1.4026145637035370e-01
    z[3,2,3]  R1376     1.5647675096988678e-01
    z[3,2,3]  R1377     1.7780081927776337e-01
    z[3,2,3]  R1378     -1.3124364614486694e-01
    z[3,2,3]  R1379     1.5760404989123344e-02
    z[3,2,3]  R1380     2.5649723410606384e-01
    z[3,2,3]  R1381     2.4812524020671844e-01
    z[3,2,3]  R1382     3.5732197761535645e-01
    z[3,2,3]  R1383     4.4686308503150940e-01
    z[3,2,3]  R1384     1.5797902643680573e-01
    z[3,2,3]  R1385     2.2483283281326294e-01
    z[3,2,3]  R1386     5.8787297457456589e-03
    z[3,2,3]  R1387     -5.5460810661315918e-02
    z[3,2,3]  R1388     1.8514537811279297e-01
    z[3,2,3]  R1389     5.3036159276962280e-01
    z[3,2,3]  R1390     -2.1677853539586067e-02
    z[3,2,3]  R1391     6.0600304603576660e-01
    z[3,2,3]  R1392     5.8472746610641479e-01
    z[3,2,3]  R1393     6.8398469686508179e-01
    z[3,2,3]  R1394     -3.9802172780036926e-01
    z[3,2,3]  R1395     5.8413773775100708e-01
    z[3,2,3]  R1396     8.2769459486007690e-01
    z[3,2,3]  R1397     -3.2512679696083069e-01
    z[3,2,3]  R1398     7.4470067024230957e-01
    z[3,2,3]  R1399     -5.3577250242233276e-01
    z[3,2,3]  R1400     -8.4929518401622772e-02
    z[3,2,3]  R1401     8.5579985380172729e-01
    z[3,2,3]  R1402     7.4300438165664673e-01
    z[3,2,3]  R1403     6.4403080940246582e-01
    z[3,2,3]  R1404     6.7152398824691772e-01
    z[3,2,3]  R1405     5.8258867263793945e-01
    z[3,2,3]  R1406     8.9625442028045654e-01
    z[3,2,3]  R1407     -2.3738366365432739e-01
    z[3,2,3]  R1408     1.0044626891613007e-01
    z[3,2,3]  R1409     1.3373105227947235e-01
    z[3,2,3]  R1410     -4.7404131293296814e-01
    z[3,2,3]  R1411     2.4768961966037750e-01
    z[3,2,3]  R1412     7.8221571445465088e-01
    z[3,2,3]  R1413     5.4474240541458130e-01
    z[3,2,3]  R1414     8.0291819572448730e-01
    z[3,2,3]  R1415     -1.3453532755374908e-01
    z[3,2,3]  R1416     -3.0108213424682617e-01
    z[3,2,3]  R1417     -4.1620391607284546e-01
    z[3,2,3]  R1418     -1.4135645329952240e-01
    z[3,2,3]  R1419     -2.6950651407241821e-01
    z[3,2,3]  R1420     -0.0194667000323534
    z[3,2,3]  R1421     5.1125931739807129e-01
    z[3,2,3]  R1422     5.4380977153778076e-01
    z[3,2,3]  R1423     -4.5670115947723389e-01
    z[3,2,3]  R1424     2.3274455219507217e-02
    z[3,2,3]  R1425     -3.3306321501731873e-01
    z[3,2,3]  R1426     -8.4590435028076172e-01
    z[3,2,3]  R1427     -0.573287844657898
    z[3,2,3]  R1428     -7.3486495018005371e-01
    z[3,2,3]  R1429     -5.7133636437356472e-03
    z[3,2,3]  R1430     6.0302615165710449e-02
    z[3,2,3]  R1431     4.3359076976776123e-01
    z[3,2,3]  R1432     4.4179043173789978e-01
    z[3,2,3]  R1433     -2.4320727214217186e-02
    z[3,2,3]  R1434     -1.8579587340354919e-01
    z[3,2,3]  R1435     1.1626062542200089e-01
    z[3,2,3]  R1436     5.6650150567293167e-02
    z[3,2,3]  R1437     2.9676252603530884e-01
    z[3,2,3]  R1438     -5.9717226773500443e-02
    z[3,2,3]  R1439     3.2643941044807434e-01
    z[3,2,3]  R1440     1.9942989945411682e-01
    z[3,2,3]  R1441     -1.4164198935031891e-01
    z[3,2,3]  R1442     -6.9845512509346008e-02
    z[3,2,3]  R1443     1.9365318119525909e-01
    z[3,2,3]  R1444     3.1281337141990662e-01
    z[3,2,3]  R1445     1.5215082466602325e-01
    z[3,2,3]  R1446     3.1471386551856995e-01
    z[3,2,3]  R1447     -2.0695790648460388e-01
    z[3,2,3]  R1448     -1.8547067046165466e-01
    z[3,2,3]  R1449     -3.7688681483268738e-01
    z[3,2,3]  R1450     -1.6205094754695892e-02
    z[3,2,3]  R1451     6.4295977354049683e-01
    z[3,2,3]  R1452     7.9940801858901978e-01
    z[3,2,3]  R1453     5.2079373598098755e-01
    z[3,2,3]  R1454     7.0280265808105469e-01
    z[3,2,3]  R1455     -4.1959017515182495e-01
    z[3,2,3]  R1456     6.6072773933410645e-01
    z[3,2,3]  R1457     -1.7309138178825378e-01
    z[3,2,3]  R1458     3.5341003537178040e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1365     -1
    z[3,2,4]  R1366     1
    z[3,2,4]  R1371     -9.3001998960971832e-02
    z[3,2,4]  R1372     -0.243952676653862
    z[3,2,4]  R1373     -2.0971670746803284e-01
    z[3,2,4]  R1374     2.3346078395843506e-01
    z[3,2,4]  R1375     -6.7958253622055054e-01
    z[3,2,4]  R1376     -3.7784937024116516e-01
    z[3,2,4]  R1377     -4.1286323219537735e-02
    z[3,2,4]  R1378     8.5462033748626709e-02
    z[3,2,4]  R1379     2.0253455638885498e-01
    z[3,2,4]  R1380     -5.8184742927551270e-01
    z[3,2,4]  R1381     5.2968215197324753e-02
    z[3,2,4]  R1382     0.19495889544487
    z[3,2,4]  R1383     1.6109964251518250e-01
    z[3,2,4]  R1384     4.7200888395309448e-01
    z[3,2,4]  R1385     3.9044788479804993e-01
    z[3,2,4]  R1386     -4.2544011026620865e-02
    z[3,2,4]  R1387     -4.1648335754871368e-02
    z[3,2,4]  R1388     3.6156203597784042e-02
    z[3,2,4]  R1389     2.1014837920665741e-01
    z[3,2,4]  R1390     4.9418565630912781e-01
    z[3,2,4]  R1391     4.8908448219299316e-01
    z[3,2,4]  R1392     7.0103943347930908e-01
    z[3,2,4]  R1393     0.702874481678009
    z[3,2,4]  R1394     5.2173024415969849e-01
    z[3,2,4]  R1395     4.0692262351512909e-02
    z[3,2,4]  R1396     1.3809283077716827e-01
    z[3,2,4]  R1397     0.253192275762558
    z[3,2,4]  R1398     -4.7943615913391113e-01
    z[3,2,4]  R1399     2.1010509133338928e-01
    z[3,2,4]  R1400     3.3108437061309814e-01
    z[3,2,4]  R1401     6.7822962999343872e-02
    z[3,2,4]  R1402     4.7397625446319580e-01
    z[3,2,4]  R1403     0.380689412355423
    z[3,2,4]  R1404     4.0593007206916809e-01
    z[3,2,4]  R1405     4.5717760920524597e-01
    z[3,2,4]  R1406     0.0681137964129448
    z[3,2,4]  R1407     3.3291794359683990e-02
    z[3,2,4]  R1408     2.6483932137489319e-01
    z[3,2,4]  R1409     2.0271314308047295e-02
    z[3,2,4]  R1410     4.1267621517181396e-01
    z[3,2,4]  R1411     5.1104915142059326e-01
    z[3,2,4]  R1412     -1.2227982282638550e-01
    z[3,2,4]  R1413     1.0072357952594757e-01
    z[3,2,4]  R1414     5.7149904966354370e-01
    z[3,2,4]  R1415     4.1737398505210876e-01
    z[3,2,4]  R1416     3.5202163457870483e-01
    z[3,2,4]  R1417     1.8234199285507202e-01
    z[3,2,4]  R1418     -4.2491161823272705e-01
    z[3,2,4]  R1419     3.2057291269302368e-01
    z[3,2,4]  R1420     2.3103576898574829e-01
    z[3,2,4]  R1421     6.3102084398269653e-01
    z[3,2,4]  R1422     -4.9971025437116623e-02
    z[3,2,4]  R1423     -6.2883630394935608e-02
    z[3,2,4]  R1424     -4.3417948484420776e-01
    z[3,2,4]  R1425     -1.5676176548004150e-01
    z[3,2,4]  R1426     -2.7827453613281250e-01
    z[3,2,4]  R1427     5.6708522140979767e-02
    z[3,2,4]  R1428     -0.393111914396286
    z[3,2,4]  R1429     -3.4494879841804504e-01
    z[3,2,4]  R1430     -6.2019479274749756e-01
    z[3,2,4]  R1431     -1.2619766592979431e-01
    z[3,2,4]  R1432     1.2386779487133026e-01
    z[3,2,4]  R1433     1.1356448382139206e-01
    z[3,2,4]  R1434     -0.685459315776825
    z[3,2,4]  R1435     -1.7781707644462585e-01
    z[3,2,4]  R1436     -5.6831365823745728e-01
    z[3,2,4]  R1437     -8.9890755712985992e-02
    z[3,2,4]  R1438     -0.570176362991333
    z[3,2,4]  R1439     -5.1463317126035690e-02
    z[3,2,4]  R1440     4.9570216797292233e-03
    z[3,2,4]  R1441     -2.1611016988754272e-01
    z[3,2,4]  R1442     3.0435770750045776e-01
    z[3,2,4]  R1443     3.5316145420074463e-01
    z[3,2,4]  R1444     2.9572373628616333e-01
    z[3,2,4]  R1445     4.7489190101623535e-01
    z[3,2,4]  R1446     5.1569879055023193e-01
    z[3,2,4]  R1447     -2.3159846663475037e-01
    z[3,2,4]  R1448     6.1637425422668457e-01
    z[3,2,4]  R1449     -2.5623646378517151e-01
    z[3,2,4]  R1450     2.5742354989051819e-01
    z[3,2,4]  R1451     3.6368942260742188e-01
    z[3,2,4]  R1452     -2.6839458942413330e-01
    z[3,2,4]  R1453     -0.610956072807312
    z[3,2,4]  R1454     -2.6510828733444214e-01
    z[3,2,4]  R1455     7.2587326169013977e-02
    z[3,2,4]  R1456     -2.4104593694210052e-01
    z[3,2,4]  R1457     0.389614462852478
    z[3,2,4]  R1458     -4.4050836563110352e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1367     -1
    z[3,2,5]  R1368     1
    z[3,2,5]  R1371     2.0027369260787964e-01
    z[3,2,5]  R1372     -2.0059290528297424e-01
    z[3,2,5]  R1373     7.3737972974777222e-01
    z[3,2,5]  R1374     3.3789855241775513e-01
    z[3,2,5]  R1375     2.9510873556137085e-01
    z[3,2,5]  R1376     1.1082833260297775e-01
    z[3,2,5]  R1377     -1.8597602844238281e-02
    z[3,2,5]  R1378     6.3809168338775635e-01
    z[3,2,5]  R1379     5.1412415504455566e-01
    z[3,2,5]  R1380     2.2193567454814911e-01
    z[3,2,5]  R1381     4.7651696205139160e-01
    z[3,2,5]  R1382     3.9702513813972473e-01
    z[3,2,5]  R1383     4.5929023623466492e-01
    z[3,2,5]  R1384     3.5141962766647339e-01
    z[3,2,5]  R1385     2.6954549551010132e-01
    z[3,2,5]  R1386     2.2822347283363342e-01
    z[3,2,5]  R1387     1.8463383615016937e-01
    z[3,2,5]  R1388     5.9028938412666321e-02
    z[3,2,5]  R1389     1.6448110342025757e-02
    z[3,2,5]  R1390     -2.9617862310260534e-03
    z[3,2,5]  R1391     4.3487283587455750e-01
    z[3,2,5]  R1392     0.246379092335701
    z[3,2,5]  R1393     -2.6688998565077782e-02
    z[3,2,5]  R1394     -3.6006936430931091e-01
    z[3,2,5]  R1395     -3.3044733107089996e-02
    z[3,2,5]  R1396     -1.2369648553431034e-02
    z[3,2,5]  R1397     -0.078908272087574
    z[3,2,5]  R1398     1.9652260839939117e-01
    z[3,2,5]  R1399     -3.7982729077339172e-01
    z[3,2,5]  R1400     -3.8389933109283447e-01
    z[3,2,5]  R1401     1.1742393672466278e-01
    z[3,2,5]  R1402     2.2076445817947388e-01
    z[3,2,5]  R1403     -1.8585156649351120e-02
    z[3,2,5]  R1404     2.5669746100902557e-02
    z[3,2,5]  R1405     -2.8313967585563660e-01
    z[3,2,5]  R1406     -2.1947419270873070e-02
    z[3,2,5]  R1407     4.3435059487819672e-02
    z[3,2,5]  R1408     1.1600136011838913e-01
    z[3,2,5]  R1409     6.5694665908813477e-01
    z[3,2,5]  R1410     -3.4724801778793335e-01
    z[3,2,5]  R1411     8.6945161223411560e-02
    z[3,2,5]  R1412     3.3828487992286682e-01
    z[3,2,5]  R1413     0.336469441652298
    z[3,2,5]  R1414     -1.1990658938884735e-02
    z[3,2,5]  R1415     -3.3678838610649109e-01
    z[3,2,5]  R1416     1.4801153540611267e-01
    z[3,2,5]  R1417     -1.5591630339622498e-01
    z[3,2,5]  R1418     -3.3089622855186462e-01
    z[3,2,5]  R1419     -3.6007410287857056e-01
    z[3,2,5]  R1420     -4.1901135444641113e-01
    z[3,2,5]  R1421     -2.1696336567401886e-01
    z[3,2,5]  R1422     2.7509140968322754e-01
    z[3,2,5]  R1423     -3.1465375423431396e-01
    z[3,2,5]  R1424     -2.6323834061622620e-01
    z[3,2,5]  R1425     -1.2563192844390869e-01
    z[3,2,5]  R1426     -2.9858118295669556e-01
    z[3,2,5]  R1427     -3.3711439371109009e-01
    z[3,2,5]  R1428     3.8634178042411804e-01
    z[3,2,5]  R1429     7.3272442817687988e-01
    z[3,2,5]  R1430     5.7743382453918457e-01
    z[3,2,5]  R1431     -1.1910753697156906e-01
    z[3,2,5]  R1432     9.9070534110069275e-02
    z[3,2,5]  R1433     1.4756646752357483e-01
    z[3,2,5]  R1434     2.8583604097366333e-01
    z[3,2,5]  R1435     7.0279783010482788e-01
    z[3,2,5]  R1436     -5.8415614068508148e-02
    z[3,2,5]  R1437     4.1297596693038940e-01
    z[3,2,5]  R1438     2.5528600811958313e-01
    z[3,2,5]  R1439     4.4018706679344177e-01
    z[3,2,5]  R1440     1.9469425082206726e-01
    z[3,2,5]  R1441     3.5704341530799866e-01
    z[3,2,5]  R1442     3.5296735167503357e-01
    z[3,2,5]  R1443     3.7022951245307922e-01
    z[3,2,5]  R1444     -6.9216839969158173e-02
    z[3,2,5]  R1445     3.6752417683601379e-01
    z[3,2,5]  R1446     1.9860202074050903e-01
    z[3,2,5]  R1447     -8.5678435862064362e-02
    z[3,2,5]  R1448     3.0596208572387695e-01
    z[3,2,5]  R1449     3.2019170466810465e-03
    z[3,2,5]  R1450     -2.9590100049972534e-01
    z[3,2,5]  R1451     5.0767010450363159e-01
    z[3,2,5]  R1452     1.7190322279930115e-01
    z[3,2,5]  R1453     6.0550201684236526e-02
    z[3,2,5]  R1454     1.5664808452129364e-01
    z[3,2,5]  R1455     8.2535691559314728e-02
    z[3,2,5]  R1456     -1.4474037289619446e-01
    z[3,2,5]  R1457     -4.6410274505615234e-01
    z[3,2,5]  R1458     -2.1927395462989807e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1369     -1
    z[3,2,6]  R1370     1
    z[3,2,6]  R1371     -2.7024172246456146e-02
    z[3,2,6]  R1372     -9.2960305511951447e-02
    z[3,2,6]  R1373     1.5328544378280640e-01
    z[3,2,6]  R1374     4.0478572249412537e-01
    z[3,2,6]  R1375     8.5655406117439270e-02
    z[3,2,6]  R1376     5.5611610412597656e-01
    z[3,2,6]  R1377     5.8828455209732056e-01
    z[3,2,6]  R1378     -1.9911254942417145e-01
    z[3,2,6]  R1379     -5.8473336696624756e-01
    z[3,2,6]  R1380     -6.3331574201583862e-01
    z[3,2,6]  R1381     -1.2940365076065063e-01
    z[3,2,6]  R1382     1.3666908442974091e-01
    z[3,2,6]  R1383     4.9621118232607841e-03
    z[3,2,6]  R1384     -2.3997332155704498e-01
    z[3,2,6]  R1385     -1.7408396303653717e-01
    z[3,2,6]  R1386     -0.223873108625412
    z[3,2,6]  R1387     -3.0624959617853165e-02
    z[3,2,6]  R1388     -1.0289679467678070e-01
    z[3,2,6]  R1389     -2.9153700917959213e-02
    z[3,2,6]  R1390     1.6441315412521362e-01
    z[3,2,6]  R1391     -5.2010573446750641e-02
    z[3,2,6]  R1392     -2.6188856363296509e-01
    z[3,2,6]  R1393     -1.7743955552577972e-01
    z[3,2,6]  R1394     9.1521563008427620e-03
    z[3,2,6]  R1395     -0.0802517980337143
    z[3,2,6]  R1396     -1.7082595825195312e-01
    z[3,2,6]  R1397     -1.0478270053863525e-01
    z[3,2,6]  R1398     0.0362219400703907
    z[3,2,6]  R1399     2.0498305559158325e-02
    z[3,2,6]  R1400     1.9291643053293228e-02
    z[3,2,6]  R1401     -3.5813847184181213e-01
    z[3,2,6]  R1402     1.9769731163978577e-01
    z[3,2,6]  R1403     -4.9664962291717529e-01
    z[3,2,6]  R1404     1.7384378612041473e-01
    z[3,2,6]  R1405     3.8115769624710083e-02
    z[3,2,6]  R1406     2.1018664538860321e-01
    z[3,2,6]  R1407     -1.2856742739677429e-01
    z[3,2,6]  R1408     -1.3096508383750916e-01
    z[3,2,6]  R1409     -6.0381293296813965e-02
    z[3,2,6]  R1410     -4.1922357678413391e-01
    z[3,2,6]  R1411     -1.0657577216625214e-01
    z[3,2,6]  R1412     -3.2016387581825256e-01
    z[3,2,6]  R1413     6.2875300645828247e-01
    z[3,2,6]  R1414     -6.3919365406036377e-02
    z[3,2,6]  R1415     -6.0191076993942261e-01
    z[3,2,6]  R1416     -1.8667422235012054e-01
    z[3,2,6]  R1417     2.2959427535533905e-01
    z[3,2,6]  R1418     -2.4552170187234879e-02
    z[3,2,6]  R1419     3.8883426785469055e-01
    z[3,2,6]  R1420     0.190166175365448
    z[3,2,6]  R1421     -6.2794364988803864e-02
    z[3,2,6]  R1422     -6.0246515274047852e-01
    z[3,2,6]  R1423     -0.0921337753534317
    z[3,2,6]  R1424     5.1443153619766235e-01
    z[3,2,6]  R1425     2.5557265616953373e-03
    z[3,2,6]  R1426     -3.8667377084493637e-02
    z[3,2,6]  R1427     1.2433449923992157e-01
    z[3,2,6]  R1428     -1.7583039402961731e-01
    z[3,2,6]  R1429     1.6707342863082886e-01
    z[3,2,6]  R1430     -1.5947981178760529e-01
    z[3,2,6]  R1431     1.1592247337102890e-01
    z[3,2,6]  R1432     4.2579475045204163e-01
    z[3,2,6]  R1433     -3.2284185290336609e-01
    z[3,2,6]  R1434     8.2118771970272064e-02
    z[3,2,6]  R1435     -5.2011966705322266e-01
    z[3,2,6]  R1436     0.106770820915699
    z[3,2,6]  R1437     -6.4204132556915283e-01
    z[3,2,6]  R1438     -0.638708233833313
    z[3,2,6]  R1439     1.6347558796405792e-01
    z[3,2,6]  R1440     4.2418867349624634e-02
    z[3,2,6]  R1441     6.5617696382105350e-03
    z[3,2,6]  R1442     4.5117955654859543e-02
    z[3,2,6]  R1443     3.3418801426887512e-01
    z[3,2,6]  R1444     9.3657158315181732e-02
    z[3,2,6]  R1445     -3.3215171098709106e-01
    z[3,2,6]  R1446     2.3647336661815643e-01
    z[3,2,6]  R1447     2.7245423197746277e-01
    z[3,2,6]  R1448     -0.257385790348053
    z[3,2,6]  R1449     -1.8693499267101288e-01
    z[3,2,6]  R1450     -1.6323995590209961e-01
    z[3,2,6]  R1451     -1.0348517447710037e-01
    z[3,2,6]  R1452     -3.0516979098320007e-01
    z[3,2,6]  R1453     -7.4036069214344025e-02
    z[3,2,6]  R1454     4.0562847256660461e-01
    z[3,2,6]  R1455     5.1011914014816284e-01
    z[3,2,6]  R1456     -2.7839767932891846e-01
    z[3,2,6]  R1457     -4.2455330491065979e-01
    z[3,2,6]  R1458     4.8394781351089478e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1459     -1
    z[2,5,0]  R1460     1
    z[2,5,0]  R1473     -7.6891683042049408e-02
    z[2,5,0]  R1474     9.7774147987365723e-02
    z[2,5,0]  R1475     -1.1200371384620667e-01
    z[2,5,0]  R1476     -1.0103247128427029e-02
    z[2,5,0]  R1477     1.8761040270328522e-01
    z[2,5,0]  R1478     -1.8172055482864380e-01
    z[2,5,0]  R1479     1.5545558929443359e-01
    z[2,5,0]  R1480     1.4082913100719452e-01
    z[2,5,0]  R1481     3.0249828100204468e-01
    z[2,5,0]  R1482     1.1991544812917709e-01
    z[2,5,0]  R1483     -1.2291748821735382e-01
    z[2,5,0]  R1484     2.8967265039682388e-02
    z[2,5,0]  R1485     -0.0217283982783556
    z[2,5,0]  R1486     -1.7278583347797394e-01
    z[2,5,0]  R1487     -2.3908168077468872e-02
    z[2,5,0]  R1488     -8.7013579905033112e-02
    z[2,5,0]  R1489     0.06809101998806
    z[2,5,0]  R1490     -1.0040861368179321e-01
    z[2,5,0]  R1491     -6.5120466053485870e-02
    z[2,5,0]  R1492     1.5014787018299103e-01
    z[2,5,0]  R1493     -6.3791498541831970e-02
    z[2,5,0]  R1494     1.9312863051891327e-01
    z[2,5,0]  R1495     -2.5318851694464684e-02
    z[2,5,0]  R1496     2.2771932184696198e-02
    z[2,5,0]  R1497     -3.4576624631881714e-02
    z[2,5,0]  R1498     -9.8926816135644913e-03
    z[2,5,0]  R1499     -1.0351626574993134e-01
    z[2,5,0]  R1500     1.6009204089641571e-01
    z[2,5,0]  R1501     3.1615566462278366e-02
    z[2,5,0]  R1502     -1.4451977610588074e-01
    z[2,5,0]  R1503     3.2114568352699280e-01
    z[2,5,0]  R1504     1.2799820979125798e-04
    z[2,5,0]  R1505     5.5457610636949539e-02
    z[2,5,0]  R1506     5.2234575152397156e-02
    z[2,5,0]  R1507     8.2452498376369476e-02
    z[2,5,0]  R1508     4.3067926168441772e-01
    z[2,5,0]  R1509     -1.3426003046333790e-02
    z[2,5,0]  R1510     -2.3636072874069214e-02
    z[2,5,0]  R1511     5.2429482340812683e-02
    z[2,5,0]  R1512     -7.5056720525026321e-03
    z[2,5,0]  R1513     7.0652149617671967e-02
    z[2,5,0]  R1514     2.7111560106277466e-01
    z[2,5,0]  R1515     1.9415850937366486e-01
    z[2,5,0]  R1516     1.1719628423452377e-01
    z[2,5,0]  R1517     -7.2154819965362549e-02
    z[2,5,0]  R1518     -1.4037913084030151e-01
    z[2,5,0]  R1519     -5.4189842194318771e-03
    z[2,5,0]  R1520     1.1443827301263809e-01
    z[2,5,0]  R1521     -1.8866352736949921e-01
    z[2,5,0]  R1522     4.2419081926345825e-01
    z[2,5,0]  R1523     2.6447597146034241e-01
    z[2,5,0]  R1524     4.4845908880233765e-02
    z[2,5,0]  R1525     -7.4253201484680176e-02
    z[2,5,0]  R1526     -1.0336951166391373e-01
    z[2,5,0]  R1527     -2.4555101990699768e-03
    z[2,5,0]  R1528     -1.0886755585670471e-01
    z[2,5,0]  R1529     -4.8941407352685928e-02
    z[2,5,0]  R1530     -1.8093822896480560e-01
    z[2,5,0]  R1531     -1.2569734454154968e-01
    z[2,5,0]  R1532     1.0660402476787567e-01
    z[2,5,0]  R1533     1.9257423281669617e-01
    z[2,5,0]  R1534     2.3337945342063904e-01
    z[2,5,0]  R1535     2.6228129863739014e-01
    z[2,5,0]  R1536     3.3634158968925476e-01
    z[2,5,0]  R1537     -9.8939023911952972e-02
    z[2,5,0]  R1538     -4.1293105483055115e-01
    z[2,5,0]  R1539     2.5201907753944397e-01
    z[2,5,0]  R1540     -3.2411229610443115e-01
    z[2,5,0]  R1541     3.0029773712158203e-01
    z[2,5,0]  R1542     -1.3278488814830780e-01
    z[2,5,0]  R1543     -1.9313894212245941e-01
    z[2,5,0]  R1544     -0.614051342010498
    z[2,5,0]  R1545     3.2096934318542480e-01
    z[2,5,0]  R1546     3.5385772585868835e-02
    z[2,5,0]  R1547     -0.0406770296394825
    z[2,5,0]  R1548     -5.2866542339324951e-01
    z[2,5,0]  R1549     -4.5177474617958069e-01
    z[2,5,0]  R1550     4.5386098325252533e-02
    z[2,5,0]  R1551     -1.3763718307018280e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1461     -1
    z[2,5,1]  R1462     1
    z[2,5,1]  R1473     -5.5581796169281006e-01
    z[2,5,1]  R1474     -4.0392491221427917e-01
    z[2,5,1]  R1475     -0.71854567527771
    z[2,5,1]  R1476     -7.7100795507431030e-01
    z[2,5,1]  R1477     -9.0539109706878662e-01
    z[2,5,1]  R1478     -0.53448086977005
    z[2,5,1]  R1479     -4.0648657083511353e-01
    z[2,5,1]  R1480     -6.4921647310256958e-01
    z[2,5,1]  R1481     -4.3055734038352966e-01
    z[2,5,1]  R1482     -4.0923115611076355e-01
    z[2,5,1]  R1483     0.808269202709198
    z[2,5,1]  R1484     0.915841817855835
    z[2,5,1]  R1485     8.5408157110214233e-01
    z[2,5,1]  R1486     8.2139098644256592e-01
    z[2,5,1]  R1487     6.9976997375488281e-01
    z[2,5,1]  R1488     8.7637430429458618e-01
    z[2,5,1]  R1489     7.0686239004135132e-01
    z[2,5,1]  R1490     7.2135227918624878e-01
    z[2,5,1]  R1491     8.4297072887420654e-01
    z[2,5,1]  R1492     5.6277406215667725e-01
    z[2,5,1]  R1493     8.6787194013595581e-01
    z[2,5,1]  R1494     0.759022057056427
    z[2,5,1]  R1495     3.3177286386489868e-01
    z[2,5,1]  R1496     2.6639896631240845e-01
    z[2,5,1]  R1497     5.8427613973617554e-01
    z[2,5,1]  R1498     3.9753732085227966e-01
    z[2,5,1]  R1499     6.0654246807098389e-01
    z[2,5,1]  R1500     0.597892701625824
    z[2,5,1]  R1501     5.7512110471725464e-01
    z[2,5,1]  R1502     6.0753285884857178e-01
    z[2,5,1]  R1503     5.0134855508804321e-01
    z[2,5,1]  R1504     4.5813700556755066e-01
    z[2,5,1]  R1505     0.432682067155838
    z[2,5,1]  R1506     4.6237125992774963e-01
    z[2,5,1]  R1507     5.0908207893371582e-01
    z[2,5,1]  R1508     4.8563095927238464e-01
    z[2,5,1]  R1509     8.2065206766128540e-01
    z[2,5,1]  R1510     3.0611601471900940e-01
    z[2,5,1]  R1511     5.0296491384506226e-01
    z[2,5,1]  R1512     0.327528178691864
    z[2,5,1]  R1513     -8.1756854057312012e-01
    z[2,5,1]  R1514     -5.9623104333877563e-01
    z[2,5,1]  R1515     -7.5222784280776978e-01
    z[2,5,1]  R1516     -4.9451699852943420e-01
    z[2,5,1]  R1517     -6.9143062829971313e-01
    z[2,5,1]  R1518     -7.4074578285217285e-01
    z[2,5,1]  R1519     -6.7811751365661621e-01
    z[2,5,1]  R1520     -5.4823744297027588e-01
    z[2,5,1]  R1521     -0.549148678779602
    z[2,5,1]  R1522     -5.0057750940322876e-01
    z[2,5,1]  R1523     2.4117852747440338e-01
    z[2,5,1]  R1524     3.7038120627403259e-01
    z[2,5,1]  R1525     0.503020703792572
    z[2,5,1]  R1526     7.1465331315994263e-01
    z[2,5,1]  R1527     1.6307540237903595e-01
    z[2,5,1]  R1528     5.4639625549316406e-01
    z[2,5,1]  R1529     5.1106256246566772e-01
    z[2,5,1]  R1530     2.0135138928890228e-01
    z[2,5,1]  R1531     5.1603823900222778e-01
    z[2,5,1]  R1532     -4.3186736106872559e-01
    z[2,5,1]  R1533     7.7884471416473389e-01
    z[2,5,1]  R1534     0.612871527671814
    z[2,5,1]  R1535     1.5017915284261107e-03
    z[2,5,1]  R1536     1.7503488063812256e-01
    z[2,5,1]  R1537     6.4956796169281006e-01
    z[2,5,1]  R1538     5.9445953369140625e-01
    z[2,5,1]  R1539     1.1809966713190079e-01
    z[2,5,1]  R1540     -1.1558468639850616e-01
    z[2,5,1]  R1541     2.3782048374414444e-02
    z[2,5,1]  R1542     4.9197566509246826e-01
    z[2,5,1]  R1543     4.1021221876144409e-01
    z[2,5,1]  R1544     5.9973281621932983e-01
    z[2,5,1]  R1545     4.4935470819473267e-01
    z[2,5,1]  R1546     2.8569960594177246e-01
    z[2,5,1]  R1547     4.9081340432167053e-01
    z[2,5,1]  R1548     5.5745017528533936e-01
    z[2,5,1]  R1549     -8.5575558245182037e-02
    z[2,5,1]  R1550     5.8053910732269287e-01
    z[2,5,1]  R1551     -4.2640173435211182e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1463     -1
    z[2,5,2]  R1464     1
    z[2,5,2]  R1473     -3.6512367427349091e-02
    z[2,5,2]  R1474     -2.8309595584869385e-01
    z[2,5,2]  R1475     4.8948526382446289e-01
    z[2,5,2]  R1476     -6.1697751283645630e-02
    z[2,5,2]  R1477     -7.4687354266643524e-02
    z[2,5,2]  R1478     2.9746848344802856e-01
    z[2,5,2]  R1479     -0.0318966880440712
    z[2,5,2]  R1480     -4.6656516194343567e-01
    z[2,5,2]  R1481     -2.1023957431316376e-01
    z[2,5,2]  R1482     1.2792116403579712e-01
    z[2,5,2]  R1483     4.3497156351804733e-02
    z[2,5,2]  R1484     -2.8441622853279114e-01
    z[2,5,2]  R1485     -2.7528798580169678e-01
    z[2,5,2]  R1486     2.6707369089126587e-01
    z[2,5,2]  R1487     -3.1428366899490356e-01
    z[2,5,2]  R1488     1.5977898240089417e-01
    z[2,5,2]  R1489     4.0474005043506622e-02
    z[2,5,2]  R1490     9.6002802252769470e-02
    z[2,5,2]  R1491     -3.2728922367095947e-01
    z[2,5,2]  R1492     -2.9421791434288025e-01
    z[2,5,2]  R1493     8.5515398532152176e-03
    z[2,5,2]  R1494     -4.5370987057685852e-01
    z[2,5,2]  R1495     2.7419024705886841e-01
    z[2,5,2]  R1496     3.0780667066574097e-01
    z[2,5,2]  R1497     6.1520017683506012e-02
    z[2,5,2]  R1498     -0.297622412443161
    z[2,5,2]  R1499     -4.1597130894660950e-01
    z[2,5,2]  R1500     -1.5419314801692963e-01
    z[2,5,2]  R1501     3.0139547586441040e-01
    z[2,5,2]  R1502     -9.3728266656398773e-02
    z[2,5,2]  R1503     5.5939173698425293e-01
    z[2,5,2]  R1504     -9.1380871832370758e-02
    z[2,5,2]  R1505     -5.2853405475616455e-01
    z[2,5,2]  R1506     -7.1074366569519043e-01
    z[2,5,2]  R1507     -7.0286047458648682e-01
    z[2,5,2]  R1508     2.5660511851310730e-01
    z[2,5,2]  R1509     -3.3238753676414490e-01
    z[2,5,2]  R1510     -0.294884592294693
    z[2,5,2]  R1511     -6.1701703071594238e-01
    z[2,5,2]  R1512     -5.3743177652359009e-01
    z[2,5,2]  R1513     1.2026625871658325e-01
    z[2,5,2]  R1514     3.4989011287689209e-01
    z[2,5,2]  R1515     -1.1586213111877441e-01
    z[2,5,2]  R1516     -9.3651607632637024e-02
    z[2,5,2]  R1517     -3.5125061869621277e-01
    z[2,5,2]  R1518     2.9583710432052612e-01
    z[2,5,2]  R1519     1.0643537156283855e-02
    z[2,5,2]  R1520     -2.1485063433647156e-01
    z[2,5,2]  R1521     1.8233244121074677e-01
    z[2,5,2]  R1522     -4.7685351222753525e-02
    z[2,5,2]  R1523     -1.6669457778334618e-02
    z[2,5,2]  R1524     1.2669166922569275e-01
    z[2,5,2]  R1525     1.1230615526437759e-01
    z[2,5,2]  R1526     1.9065700471401215e-01
    z[2,5,2]  R1527     4.4778954982757568e-01
    z[2,5,2]  R1528     3.6488610506057739e-01
    z[2,5,2]  R1529     2.6896793395280838e-02
    z[2,5,2]  R1530     1.7822082340717316e-01
    z[2,5,2]  R1531     1.7628322541713715e-01
    z[2,5,2]  R1532     1.2772007286548615e-01
    z[2,5,2]  R1533     -2.4267971515655518e-01
    z[2,5,2]  R1534     -1.1833103001117706e-01
    z[2,5,2]  R1535     -2.2095292806625366e-01
    z[2,5,2]  R1536     2.4815934896469116e-01
    z[2,5,2]  R1537     0.269465833902359
    z[2,5,2]  R1538     2.2802762687206268e-01
    z[2,5,2]  R1539     2.2638346254825592e-01
    z[2,5,2]  R1540     -4.9153584241867065e-01
    z[2,5,2]  R1541     -1.8757960200309753e-01
    z[2,5,2]  R1542     1.7887100577354431e-01
    z[2,5,2]  R1543     -8.5737422108650208e-02
    z[2,5,2]  R1544     2.5774728506803513e-02
    z[2,5,2]  R1545     3.8702264428138733e-01
    z[2,5,2]  R1546     4.7996929287910461e-01
    z[2,5,2]  R1547     -3.9740979671478271e-01
    z[2,5,2]  R1548     4.5599198341369629e-01
    z[2,5,2]  R1549     -1.8403373658657074e-01
    z[2,5,2]  R1550     3.6123567819595337e-01
    z[2,5,2]  R1551     5.4145264625549316e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1465     -1
    z[2,5,3]  R1466     1
    z[2,5,3]  R1473     -5.7133636437356472e-03
    z[2,5,3]  R1474     6.0302615165710449e-02
    z[2,5,3]  R1475     4.3359076976776123e-01
    z[2,5,3]  R1476     4.4179043173789978e-01
    z[2,5,3]  R1477     -2.4320727214217186e-02
    z[2,5,3]  R1478     -1.8579587340354919e-01
    z[2,5,3]  R1479     1.1626062542200089e-01
    z[2,5,3]  R1480     5.6650150567293167e-02
    z[2,5,3]  R1481     2.9676252603530884e-01
    z[2,5,3]  R1482     -5.9717226773500443e-02
    z[2,5,3]  R1483     3.2643941044807434e-01
    z[2,5,3]  R1484     1.9942989945411682e-01
    z[2,5,3]  R1485     -1.4164198935031891e-01
    z[2,5,3]  R1486     -6.9845512509346008e-02
    z[2,5,3]  R1487     1.9365318119525909e-01
    z[2,5,3]  R1488     3.1281337141990662e-01
    z[2,5,3]  R1489     1.5215082466602325e-01
    z[2,5,3]  R1490     3.1471386551856995e-01
    z[2,5,3]  R1491     -2.0695790648460388e-01
    z[2,5,3]  R1492     -1.8547067046165466e-01
    z[2,5,3]  R1493     -3.7688681483268738e-01
    z[2,5,3]  R1494     -1.6205094754695892e-02
    z[2,5,3]  R1495     6.4295977354049683e-01
    z[2,5,3]  R1496     7.9940801858901978e-01
    z[2,5,3]  R1497     5.2079373598098755e-01
    z[2,5,3]  R1498     7.0280265808105469e-01
    z[2,5,3]  R1499     -4.1959017515182495e-01
    z[2,5,3]  R1500     6.6072773933410645e-01
    z[2,5,3]  R1501     -1.7309138178825378e-01
    z[2,5,3]  R1502     3.5341003537178040e-01
    z[2,5,3]  R1503     1.5760849416255951e-01
    z[2,5,3]  R1504     2.3670193552970886e-01
    z[2,5,3]  R1505     7.3240667581558228e-02
    z[2,5,3]  R1506     5.2571866661310196e-02
    z[2,5,3]  R1507     1.6801701486110687e-01
    z[2,5,3]  R1508     2.7998885512351990e-01
    z[2,5,3]  R1509     3.1080448627471924e-01
    z[2,5,3]  R1510     6.3498966395854950e-02
    z[2,5,3]  R1511     -0.07258290797472
    z[2,5,3]  R1512     -1.0689292103052139e-01
    z[2,5,3]  R1513     -4.5449972152709961e-01
    z[2,5,3]  R1514     -5.6289356946945190e-01
    z[2,5,3]  R1515     -4.6246212720870972e-01
    z[2,5,3]  R1516     -0.708291232585907
    z[2,5,3]  R1517     -4.3603339791297913e-01
    z[2,5,3]  R1518     -3.6672791838645935e-01
    z[2,5,3]  R1519     -5.9832257032394409e-01
    z[2,5,3]  R1520     -0.545274555683136
    z[2,5,3]  R1521     -6.8221920728683472e-01
    z[2,5,3]  R1522     -5.6845504045486450e-01
    z[2,5,3]  R1523     5.5740290880203247e-01
    z[2,5,3]  R1524     0.578544020652771
    z[2,5,3]  R1525     -6.0288065671920776e-01
    z[2,5,3]  R1526     -3.4921801090240479e-01
    z[2,5,3]  R1527     6.2654447555541992e-01
    z[2,5,3]  R1528     -5.2741795778274536e-01
    z[2,5,3]  R1529     -7.4762272834777832e-01
    z[2,5,3]  R1530     3.4952321648597717e-01
    z[2,5,3]  R1531     5.9685643762350082e-02
    z[2,5,3]  R1532     8.6430960893630981e-01
    z[2,5,3]  R1533     2.3574048280715942e-01
    z[2,5,3]  R1534     5.7690471410751343e-01
    z[2,5,3]  R1535     8.9302927255630493e-01
    z[2,5,3]  R1536     9.8066650331020355e-02
    z[2,5,3]  R1537     -2.5251312181353569e-02
    z[2,5,3]  R1538     -6.1161148548126221e-01
    z[2,5,3]  R1539     5.6304007768630981e-01
    z[2,5,3]  R1540     0.721450924873352
    z[2,5,3]  R1541     -0.00906460452824831
    z[2,5,3]  R1542     -4.1713351011276245e-01
    z[2,5,3]  R1543     0.0668509304523468
    z[2,5,3]  R1544     -4.4703356921672821e-02
    z[2,5,3]  R1545     5.5620354413986206e-01
    z[2,5,3]  R1546     5.3038930892944336e-01
    z[2,5,3]  R1547     3.3827179670333862e-01
    z[2,5,3]  R1548     2.0165410637855530e-01
    z[2,5,3]  R1549     6.4370816946029663e-01
    z[2,5,3]  R1550     -1.5139554627239704e-02
    z[2,5,3]  R1551     5.7504045963287354e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1467     -1
    z[2,5,4]  R1468     1
    z[2,5,4]  R1473     -3.4494879841804504e-01
    z[2,5,4]  R1474     -6.2019479274749756e-01
    z[2,5,4]  R1475     -1.2619766592979431e-01
    z[2,5,4]  R1476     1.2386779487133026e-01
    z[2,5,4]  R1477     1.1356448382139206e-01
    z[2,5,4]  R1478     -0.685459315776825
    z[2,5,4]  R1479     -1.7781707644462585e-01
    z[2,5,4]  R1480     -5.6831365823745728e-01
    z[2,5,4]  R1481     -8.9890755712985992e-02
    z[2,5,4]  R1482     -0.570176362991333
    z[2,5,4]  R1483     -5.1463317126035690e-02
    z[2,5,4]  R1484     4.9570216797292233e-03
    z[2,5,4]  R1485     -2.1611016988754272e-01
    z[2,5,4]  R1486     3.0435770750045776e-01
    z[2,5,4]  R1487     3.5316145420074463e-01
    z[2,5,4]  R1488     2.9572373628616333e-01
    z[2,5,4]  R1489     4.7489190101623535e-01
    z[2,5,4]  R1490     5.1569879055023193e-01
    z[2,5,4]  R1491     -2.3159846663475037e-01
    z[2,5,4]  R1492     6.1637425422668457e-01
    z[2,5,4]  R1493     -2.5623646378517151e-01
    z[2,5,4]  R1494     2.5742354989051819e-01
    z[2,5,4]  R1495     3.6368942260742188e-01
    z[2,5,4]  R1496     -2.6839458942413330e-01
    z[2,5,4]  R1497     -0.610956072807312
    z[2,5,4]  R1498     -2.6510828733444214e-01
    z[2,5,4]  R1499     7.2587326169013977e-02
    z[2,5,4]  R1500     -2.4104593694210052e-01
    z[2,5,4]  R1501     0.389614462852478
    z[2,5,4]  R1502     -4.4050836563110352e-01
    z[2,5,4]  R1503     -5.2295696735382080e-01
    z[2,5,4]  R1504     -7.3008544743061066e-02
    z[2,5,4]  R1505     6.6151313483715057e-02
    z[2,5,4]  R1506     -3.2162305712699890e-01
    z[2,5,4]  R1507     0.0360804907977581
    z[2,5,4]  R1508     -3.5811248421669006e-01
    z[2,5,4]  R1509     -2.3946642875671387e-01
    z[2,5,4]  R1510     -2.9947438836097717e-01
    z[2,5,4]  R1511     -4.9453905224800110e-01
    z[2,5,4]  R1512     -3.8763910531997681e-01
    z[2,5,4]  R1513     -1.1475600302219391e-01
    z[2,5,4]  R1514     -4.1680745780467987e-03
    z[2,5,4]  R1515     2.9905638098716736e-01
    z[2,5,4]  R1516     7.8380726277828217e-02
    z[2,5,4]  R1517     2.1771165728569031e-01
    z[2,5,4]  R1518     2.9940694570541382e-01
    z[2,5,4]  R1519     4.2538410425186157e-01
    z[2,5,4]  R1520     -0.0423019640147686
    z[2,5,4]  R1521     2.6569724082946777e-01
    z[2,5,4]  R1522     5.8113500475883484e-02
    z[2,5,4]  R1523     -1.3618029654026031e-01
    z[2,5,4]  R1524     5.5409145355224609e-01
    z[2,5,4]  R1525     4.0063974261283875e-01
    z[2,5,4]  R1526     0.537505567073822
    z[2,5,4]  R1527     5.9833395481109619e-01
    z[2,5,4]  R1528     3.5292837023735046e-01
    z[2,5,4]  R1529     1.5173371136188507e-01
    z[2,5,4]  R1530     8.2123500108718872e-01
    z[2,5,4]  R1531     7.8610116243362427e-01
    z[2,5,4]  R1532     -3.6398649215698242e-02
    z[2,5,4]  R1533     1.8064025044441223e-01
    z[2,5,4]  R1534     0.0169846098870039
    z[2,5,4]  R1535     -2.3943005502223969e-01
    z[2,5,4]  R1536     -6.4937502145767212e-01
    z[2,5,4]  R1537     5.4747790098190308e-01
    z[2,5,4]  R1538     1.4513424038887024e-01
    z[2,5,4]  R1539     -2.9419302940368652e-01
    z[2,5,4]  R1540     2.1047417819499969e-01
    z[2,5,4]  R1541     -0.92336106300354
    z[2,5,4]  R1542     0.0594811849296093
    z[2,5,4]  R1543     5.9035980701446533e-01
    z[2,5,4]  R1544     -4.6010011434555054e-01
    z[2,5,4]  R1545     3.3176541328430176e-02
    z[2,5,4]  R1546     3.0229237675666809e-01
    z[2,5,4]  R1547     6.2527048587799072e-01
    z[2,5,4]  R1548     3.3453187346458435e-01
    z[2,5,4]  R1549     5.0589525699615479e-01
    z[2,5,4]  R1550     5.4702854156494141e-01
    z[2,5,4]  R1551     -4.0859675407409668e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1469     -1
    z[2,5,5]  R1470     1
    z[2,5,5]  R1473     7.3272442817687988e-01
    z[2,5,5]  R1474     5.7743382453918457e-01
    z[2,5,5]  R1475     -1.1910753697156906e-01
    z[2,5,5]  R1476     9.9070534110069275e-02
    z[2,5,5]  R1477     1.4756646752357483e-01
    z[2,5,5]  R1478     2.8583604097366333e-01
    z[2,5,5]  R1479     7.0279783010482788e-01
    z[2,5,5]  R1480     -5.8415614068508148e-02
    z[2,5,5]  R1481     4.1297596693038940e-01
    z[2,5,5]  R1482     2.5528600811958313e-01
    z[2,5,5]  R1483     4.4018706679344177e-01
    z[2,5,5]  R1484     1.9469425082206726e-01
    z[2,5,5]  R1485     3.5704341530799866e-01
    z[2,5,5]  R1486     3.5296735167503357e-01
    z[2,5,5]  R1487     3.7022951245307922e-01
    z[2,5,5]  R1488     -6.9216839969158173e-02
    z[2,5,5]  R1489     3.6752417683601379e-01
    z[2,5,5]  R1490     1.9860202074050903e-01
    z[2,5,5]  R1491     -8.5678435862064362e-02
    z[2,5,5]  R1492     3.0596208572387695e-01
    z[2,5,5]  R1493     3.2019170466810465e-03
    z[2,5,5]  R1494     -2.9590100049972534e-01
    z[2,5,5]  R1495     5.0767010450363159e-01
    z[2,5,5]  R1496     1.7190322279930115e-01
    z[2,5,5]  R1497     6.0550201684236526e-02
    z[2,5,5]  R1498     1.5664808452129364e-01
    z[2,5,5]  R1499     8.2535691559314728e-02
    z[2,5,5]  R1500     -1.4474037289619446e-01
    z[2,5,5]  R1501     -4.6410274505615234e-01
    z[2,5,5]  R1502     -2.1927395462989807e-01
    z[2,5,5]  R1503     1.7254360020160675e-01
    z[2,5,5]  R1504     0.782616138458252
    z[2,5,5]  R1505     4.1756004095077515e-01
    z[2,5,5]  R1506     2.6718342304229736e-01
    z[2,5,5]  R1507     5.2473846822977066e-02
    z[2,5,5]  R1508     -1.7000629007816315e-01
    z[2,5,5]  R1509     -4.7777980566024780e-02
    z[2,5,5]  R1510     8.3798050880432129e-01
    z[2,5,5]  R1511     3.3537822961807251e-01
    z[2,5,5]  R1512     0.630859911441803
    z[2,5,5]  R1513     -2.0510685443878174e-01
    z[2,5,5]  R1514     -3.3171677589416504e-01
    z[2,5,5]  R1515     -4.5201838016510010e-02
    z[2,5,5]  R1516     -4.7424682974815369e-01
    z[2,5,5]  R1517     -3.8958451151847839e-01
    z[2,5,5]  R1518     -2.3353940248489380e-01
    z[2,5,5]  R1519     -3.1496521085500717e-02
    z[2,5,5]  R1520     -4.7385808825492859e-01
    z[2,5,5]  R1521     -3.0427780747413635e-01
    z[2,5,5]  R1522     -3.7121587991714478e-01
    z[2,5,5]  R1523     -5.8360165357589722e-01
    z[2,5,5]  R1524     -2.2560764849185944e-01
    z[2,5,5]  R1525     -0.407821923494339
    z[2,5,5]  R1526     1.6855373978614807e-01
    z[2,5,5]  R1527     1.0096298158168793e-01
    z[2,5,5]  R1528     -3.8624534010887146e-01
    z[2,5,5]  R1529     -3.9207586646080017e-01
    z[2,5,5]  R1530     2.3046796023845673e-01
    z[2,5,5]  R1531     -0.0591965913772583
    z[2,5,5]  R1532     -5.5470943450927734e-02
    z[2,5,5]  R1533     -3.2538297772407532e-01
    z[2,5,5]  R1534     -7.1658574044704437e-02
    z[2,5,5]  R1535     1.0443413257598877e-01
    z[2,5,5]  R1536     -0.562673032283783
    z[2,5,5]  R1537     3.3719030022621155e-01
    z[2,5,5]  R1538     -1.6899110376834869e-01
    z[2,5,5]  R1539     -0.410017728805542
    z[2,5,5]  R1540     5.1297504454851151e-02
    z[2,5,5]  R1541     -1.3205739855766296e-01
    z[2,5,5]  R1542     -1.3057488203048706e-01
    z[2,5,5]  R1543     6.3000130653381348e-01
    z[2,5,5]  R1544     1.3500395417213440e-01
    z[2,5,5]  R1545     -4.7661134600639343e-01
    z[2,5,5]  R1546     5.5322146415710449e-01
    z[2,5,5]  R1547     -5.1534615457057953e-02
    z[2,5,5]  R1548     4.5814774930477142e-02
    z[2,5,5]  R1549     1.0212268680334091e-01
    z[2,5,5]  R1550     1.0070103406906128e-01
    z[2,5,5]  R1551     -8.0719053745269775e-02
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1471     -1
    z[2,5,6]  R1472     1
    z[2,5,6]  R1473     1.6707342863082886e-01
    z[2,5,6]  R1474     -1.5947981178760529e-01
    z[2,5,6]  R1475     1.1592247337102890e-01
    z[2,5,6]  R1476     4.2579475045204163e-01
    z[2,5,6]  R1477     -3.2284185290336609e-01
    z[2,5,6]  R1478     8.2118771970272064e-02
    z[2,5,6]  R1479     -5.2011966705322266e-01
    z[2,5,6]  R1480     0.106770820915699
    z[2,5,6]  R1481     -6.4204132556915283e-01
    z[2,5,6]  R1482     -0.638708233833313
    z[2,5,6]  R1483     1.6347558796405792e-01
    z[2,5,6]  R1484     4.2418867349624634e-02
    z[2,5,6]  R1485     6.5617696382105350e-03
    z[2,5,6]  R1486     4.5117955654859543e-02
    z[2,5,6]  R1487     3.3418801426887512e-01
    z[2,5,6]  R1488     9.3657158315181732e-02
    z[2,5,6]  R1489     -3.3215171098709106e-01
    z[2,5,6]  R1490     2.3647336661815643e-01
    z[2,5,6]  R1491     2.7245423197746277e-01
    z[2,5,6]  R1492     -0.257385790348053
    z[2,5,6]  R1493     -1.8693499267101288e-01
    z[2,5,6]  R1494     -1.6323995590209961e-01
    z[2,5,6]  R1495     -1.0348517447710037e-01
    z[2,5,6]  R1496     -3.0516979098320007e-01
    z[2,5,6]  R1497     -7.4036069214344025e-02
    z[2,5,6]  R1498     4.0562847256660461e-01
    z[2,5,6]  R1499     5.1011914014816284e-01
    z[2,5,6]  R1500     -2.7839767932891846e-01
    z[2,5,6]  R1501     -4.2455330491065979e-01
    z[2,5,6]  R1502     4.8394781351089478e-01
    z[2,5,6]  R1503     -6.7084066569805145e-02
    z[2,5,6]  R1504     3.2850247621536255e-01
    z[2,5,6]  R1505     5.8844357728958130e-01
    z[2,5,6]  R1506     3.1738871335983276e-01
    z[2,5,6]  R1507     4.5578393340110779e-01
    z[2,5,6]  R1508     5.2658468484878540e-01
    z[2,5,6]  R1509     -2.4421733617782593e-01
    z[2,5,6]  R1510     -1.5115892887115479e-01
    z[2,5,6]  R1511     -3.5378482192754745e-02
    z[2,5,6]  R1512     2.1014676988124847e-01
    z[2,5,6]  R1513     2.2431743144989014e-01
    z[2,5,6]  R1514     1.4723828434944153e-01
    z[2,5,6]  R1515     2.7871602773666382e-01
    z[2,5,6]  R1516     -1.4741206541657448e-02
    z[2,5,6]  R1517     -6.3567437231540680e-02
    z[2,5,6]  R1518     2.5572484731674194e-01
    z[2,5,6]  R1519     -8.9660808444023132e-03
    z[2,5,6]  R1520     3.4135526418685913e-01
    z[2,5,6]  R1521     3.1523339450359344e-02
    z[2,5,6]  R1522     3.2076603174209595e-01
    z[2,5,6]  R1523     -4.4919201731681824e-01
    z[2,5,6]  R1524     -3.9003399014472961e-01
    z[2,5,6]  R1525     1.9633628427982330e-01
    z[2,5,6]  R1526     -5.4399389773607254e-02
    z[2,5,6]  R1527     -1.1013595014810562e-01
    z[2,5,6]  R1528     -6.7405253648757935e-02
    z[2,5,6]  R1529     3.1717678066343069e-03
    z[2,5,6]  R1530     -2.1271444857120514e-01
    z[2,5,6]  R1531     -2.4861088395118713e-01
    z[2,5,6]  R1532     -1.8542063236236572e-01
    z[2,5,6]  R1533     -3.2147186994552612e-01
    z[2,5,6]  R1534     -4.6655958890914917e-01
    z[2,5,6]  R1535     -1.2904070317745209e-01
    z[2,5,6]  R1536     -2.1621312201023102e-01
    z[2,5,6]  R1537     -2.8564631938934326e-01
    z[2,5,6]  R1538     -2.0460499450564384e-02
    z[2,5,6]  R1539     -0.547367513179779
    z[2,5,6]  R1540     -2.6937276124954224e-01
    z[2,5,6]  R1541     -6.2870413064956665e-02
    z[2,5,6]  R1542     -7.1676015853881836e-01
    z[2,5,6]  R1543     -1.9281332194805145e-01
    z[2,5,6]  R1544     1.7515836656093597e-01
    z[2,5,6]  R1545     -8.7471000850200653e-02
    z[2,5,6]  R1546     -8.9473605155944824e-02
    z[2,5,6]  R1547     -3.0243399739265442e-01
    z[2,5,6]  R1548     2.1716007590293884e-01
    z[2,5,6]  R1549     2.7200832962989807e-01
    z[2,5,6]  R1550     4.6990740299224854e-01
    z[2,5,6]  R1551     0.0439128652215004
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1552     -1
    z[5,2,0]  R1553     1
    z[5,2,0]  R1566     3.2114568352699280e-01
    z[5,2,0]  R1567     1.2799820979125798e-04
    z[5,2,0]  R1568     5.5457610636949539e-02
    z[5,2,0]  R1569     5.2234575152397156e-02
    z[5,2,0]  R1570     8.2452498376369476e-02
    z[5,2,0]  R1571     4.3067926168441772e-01
    z[5,2,0]  R1572     -1.3426003046333790e-02
    z[5,2,0]  R1573     -2.3636072874069214e-02
    z[5,2,0]  R1574     5.2429482340812683e-02
    z[5,2,0]  R1575     -7.5056720525026321e-03
    z[5,2,0]  R1576     7.0652149617671967e-02
    z[5,2,0]  R1577     2.7111560106277466e-01
    z[5,2,0]  R1578     1.9415850937366486e-01
    z[5,2,0]  R1579     1.1719628423452377e-01
    z[5,2,0]  R1580     -7.2154819965362549e-02
    z[5,2,0]  R1581     -1.4037913084030151e-01
    z[5,2,0]  R1582     -5.4189842194318771e-03
    z[5,2,0]  R1583     1.1443827301263809e-01
    z[5,2,0]  R1584     -1.8866352736949921e-01
    z[5,2,0]  R1585     4.2419081926345825e-01
    z[5,2,0]  R1586     2.6447597146034241e-01
    z[5,2,0]  R1587     4.4845908880233765e-02
    z[5,2,0]  R1588     -7.4253201484680176e-02
    z[5,2,0]  R1589     -1.0336951166391373e-01
    z[5,2,0]  R1590     -2.4555101990699768e-03
    z[5,2,0]  R1591     -1.0886755585670471e-01
    z[5,2,0]  R1592     -4.8941407352685928e-02
    z[5,2,0]  R1593     -1.8093822896480560e-01
    z[5,2,0]  R1594     -1.2569734454154968e-01
    z[5,2,0]  R1595     1.0660402476787567e-01
    z[5,2,0]  R1596     1.9257423281669617e-01
    z[5,2,0]  R1597     2.3337945342063904e-01
    z[5,2,0]  R1598     2.6228129863739014e-01
    z[5,2,0]  R1599     3.3634158968925476e-01
    z[5,2,0]  R1600     -9.8939023911952972e-02
    z[5,2,0]  R1601     -4.1293105483055115e-01
    z[5,2,0]  R1602     2.5201907753944397e-01
    z[5,2,0]  R1603     -3.2411229610443115e-01
    z[5,2,0]  R1604     3.0029773712158203e-01
    z[5,2,0]  R1605     -1.3278488814830780e-01
    z[5,2,0]  R1606     -1.9313894212245941e-01
    z[5,2,0]  R1607     -0.614051342010498
    z[5,2,0]  R1608     3.2096934318542480e-01
    z[5,2,0]  R1609     3.5385772585868835e-02
    z[5,2,0]  R1610     -0.0406770296394825
    z[5,2,0]  R1611     -5.2866542339324951e-01
    z[5,2,0]  R1612     -4.5177474617958069e-01
    z[5,2,0]  R1613     4.5386098325252533e-02
    z[5,2,0]  R1614     -1.3763718307018280e-01
    z[5,2,0]  R1615     -7.6891683042049408e-02
    z[5,2,0]  R1616     9.7774147987365723e-02
    z[5,2,0]  R1617     -1.1200371384620667e-01
    z[5,2,0]  R1618     -1.0103247128427029e-02
    z[5,2,0]  R1619     1.8761040270328522e-01
    z[5,2,0]  R1620     -1.8172055482864380e-01
    z[5,2,0]  R1621     1.5545558929443359e-01
    z[5,2,0]  R1622     1.4082913100719452e-01
    z[5,2,0]  R1623     3.0249828100204468e-01
    z[5,2,0]  R1624     1.1991544812917709e-01
    z[5,2,0]  R1625     -1.2291748821735382e-01
    z[5,2,0]  R1626     2.8967265039682388e-02
    z[5,2,0]  R1627     -0.0217283982783556
    z[5,2,0]  R1628     -1.7278583347797394e-01
    z[5,2,0]  R1629     -2.3908168077468872e-02
    z[5,2,0]  R1630     -8.7013579905033112e-02
    z[5,2,0]  R1631     0.06809101998806
    z[5,2,0]  R1632     -1.0040861368179321e-01
    z[5,2,0]  R1633     -6.5120466053485870e-02
    z[5,2,0]  R1634     1.5014787018299103e-01
    z[5,2,0]  R1635     -6.3791498541831970e-02
    z[5,2,0]  R1636     1.9312863051891327e-01
    z[5,2,0]  R1637     -2.5318851694464684e-02
    z[5,2,0]  R1638     2.2771932184696198e-02
    z[5,2,0]  R1639     -3.4576624631881714e-02
    z[5,2,0]  R1640     -9.8926816135644913e-03
    z[5,2,0]  R1641     -1.0351626574993134e-01
    z[5,2,0]  R1642     1.6009204089641571e-01
    z[5,2,0]  R1643     3.1615566462278366e-02
    z[5,2,0]  R1644     -1.4451977610588074e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1554     -1
    z[5,2,1]  R1555     1
    z[5,2,1]  R1566     5.0134855508804321e-01
    z[5,2,1]  R1567     4.5813700556755066e-01
    z[5,2,1]  R1568     0.432682067155838
    z[5,2,1]  R1569     4.6237125992774963e-01
    z[5,2,1]  R1570     5.0908207893371582e-01
    z[5,2,1]  R1571     4.8563095927238464e-01
    z[5,2,1]  R1572     8.2065206766128540e-01
    z[5,2,1]  R1573     3.0611601471900940e-01
    z[5,2,1]  R1574     5.0296491384506226e-01
    z[5,2,1]  R1575     0.327528178691864
    z[5,2,1]  R1576     -8.1756854057312012e-01
    z[5,2,1]  R1577     -5.9623104333877563e-01
    z[5,2,1]  R1578     -7.5222784280776978e-01
    z[5,2,1]  R1579     -4.9451699852943420e-01
    z[5,2,1]  R1580     -6.9143062829971313e-01
    z[5,2,1]  R1581     -7.4074578285217285e-01
    z[5,2,1]  R1582     -6.7811751365661621e-01
    z[5,2,1]  R1583     -5.4823744297027588e-01
    z[5,2,1]  R1584     -0.549148678779602
    z[5,2,1]  R1585     -5.0057750940322876e-01
    z[5,2,1]  R1586     2.4117852747440338e-01
    z[5,2,1]  R1587     3.7038120627403259e-01
    z[5,2,1]  R1588     0.503020703792572
    z[5,2,1]  R1589     7.1465331315994263e-01
    z[5,2,1]  R1590     1.6307540237903595e-01
    z[5,2,1]  R1591     5.4639625549316406e-01
    z[5,2,1]  R1592     5.1106256246566772e-01
    z[5,2,1]  R1593     2.0135138928890228e-01
    z[5,2,1]  R1594     5.1603823900222778e-01
    z[5,2,1]  R1595     -4.3186736106872559e-01
    z[5,2,1]  R1596     7.7884471416473389e-01
    z[5,2,1]  R1597     0.612871527671814
    z[5,2,1]  R1598     1.5017915284261107e-03
    z[5,2,1]  R1599     1.7503488063812256e-01
    z[5,2,1]  R1600     6.4956796169281006e-01
    z[5,2,1]  R1601     5.9445953369140625e-01
    z[5,2,1]  R1602     1.1809966713190079e-01
    z[5,2,1]  R1603     -1.1558468639850616e-01
    z[5,2,1]  R1604     2.3782048374414444e-02
    z[5,2,1]  R1605     4.9197566509246826e-01
    z[5,2,1]  R1606     4.1021221876144409e-01
    z[5,2,1]  R1607     5.9973281621932983e-01
    z[5,2,1]  R1608     4.4935470819473267e-01
    z[5,2,1]  R1609     2.8569960594177246e-01
    z[5,2,1]  R1610     4.9081340432167053e-01
    z[5,2,1]  R1611     5.5745017528533936e-01
    z[5,2,1]  R1612     -8.5575558245182037e-02
    z[5,2,1]  R1613     5.8053910732269287e-01
    z[5,2,1]  R1614     -4.2640173435211182e-01
    z[5,2,1]  R1615     -5.5581796169281006e-01
    z[5,2,1]  R1616     -4.0392491221427917e-01
    z[5,2,1]  R1617     -0.71854567527771
    z[5,2,1]  R1618     -7.7100795507431030e-01
    z[5,2,1]  R1619     -9.0539109706878662e-01
    z[5,2,1]  R1620     -0.53448086977005
    z[5,2,1]  R1621     -4.0648657083511353e-01
    z[5,2,1]  R1622     -6.4921647310256958e-01
    z[5,2,1]  R1623     -4.3055734038352966e-01
    z[5,2,1]  R1624     -4.0923115611076355e-01
    z[5,2,1]  R1625     0.808269202709198
    z[5,2,1]  R1626     0.915841817855835
    z[5,2,1]  R1627     8.5408157110214233e-01
    z[5,2,1]  R1628     8.2139098644256592e-01
    z[5,2,1]  R1629     6.9976997375488281e-01
    z[5,2,1]  R1630     8.7637430429458618e-01
    z[5,2,1]  R1631     7.0686239004135132e-01
    z[5,2,1]  R1632     7.2135227918624878e-01
    z[5,2,1]  R1633     8.4297072887420654e-01
    z[5,2,1]  R1634     5.6277406215667725e-01
    z[5,2,1]  R1635     8.6787194013595581e-01
    z[5,2,1]  R1636     0.759022057056427
    z[5,2,1]  R1637     3.3177286386489868e-01
    z[5,2,1]  R1638     2.6639896631240845e-01
    z[5,2,1]  R1639     5.8427613973617554e-01
    z[5,2,1]  R1640     3.9753732085227966e-01
    z[5,2,1]  R1641     6.0654246807098389e-01
    z[5,2,1]  R1642     0.597892701625824
    z[5,2,1]  R1643     5.7512110471725464e-01
    z[5,2,1]  R1644     6.0753285884857178e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1556     -1
    z[5,2,2]  R1557     1
    z[5,2,2]  R1566     5.5939173698425293e-01
    z[5,2,2]  R1567     -9.1380871832370758e-02
    z[5,2,2]  R1568     -5.2853405475616455e-01
    z[5,2,2]  R1569     -7.1074366569519043e-01
    z[5,2,2]  R1570     -7.0286047458648682e-01
    z[5,2,2]  R1571     2.5660511851310730e-01
    z[5,2,2]  R1572     -3.3238753676414490e-01
    z[5,2,2]  R1573     -0.294884592294693
    z[5,2,2]  R1574     -6.1701703071594238e-01
    z[5,2,2]  R1575     -5.3743177652359009e-01
    z[5,2,2]  R1576     1.2026625871658325e-01
    z[5,2,2]  R1577     3.4989011287689209e-01
    z[5,2,2]  R1578     -1.1586213111877441e-01
    z[5,2,2]  R1579     -9.3651607632637024e-02
    z[5,2,2]  R1580     -3.5125061869621277e-01
    z[5,2,2]  R1581     2.9583710432052612e-01
    z[5,2,2]  R1582     1.0643537156283855e-02
    z[5,2,2]  R1583     -2.1485063433647156e-01
    z[5,2,2]  R1584     1.8233244121074677e-01
    z[5,2,2]  R1585     -4.7685351222753525e-02
    z[5,2,2]  R1586     -1.6669457778334618e-02
    z[5,2,2]  R1587     1.2669166922569275e-01
    z[5,2,2]  R1588     1.1230615526437759e-01
    z[5,2,2]  R1589     1.9065700471401215e-01
    z[5,2,2]  R1590     4.4778954982757568e-01
    z[5,2,2]  R1591     3.6488610506057739e-01
    z[5,2,2]  R1592     2.6896793395280838e-02
    z[5,2,2]  R1593     1.7822082340717316e-01
    z[5,2,2]  R1594     1.7628322541713715e-01
    z[5,2,2]  R1595     1.2772007286548615e-01
    z[5,2,2]  R1596     -2.4267971515655518e-01
    z[5,2,2]  R1597     -1.1833103001117706e-01
    z[5,2,2]  R1598     -2.2095292806625366e-01
    z[5,2,2]  R1599     2.4815934896469116e-01
    z[5,2,2]  R1600     0.269465833902359
    z[5,2,2]  R1601     2.2802762687206268e-01
    z[5,2,2]  R1602     2.2638346254825592e-01
    z[5,2,2]  R1603     -4.9153584241867065e-01
    z[5,2,2]  R1604     -1.8757960200309753e-01
    z[5,2,2]  R1605     1.7887100577354431e-01
    z[5,2,2]  R1606     -8.5737422108650208e-02
    z[5,2,2]  R1607     2.5774728506803513e-02
    z[5,2,2]  R1608     3.8702264428138733e-01
    z[5,2,2]  R1609     4.7996929287910461e-01
    z[5,2,2]  R1610     -3.9740979671478271e-01
    z[5,2,2]  R1611     4.5599198341369629e-01
    z[5,2,2]  R1612     -1.8403373658657074e-01
    z[5,2,2]  R1613     3.6123567819595337e-01
    z[5,2,2]  R1614     5.4145264625549316e-01
    z[5,2,2]  R1615     -3.6512367427349091e-02
    z[5,2,2]  R1616     -2.8309595584869385e-01
    z[5,2,2]  R1617     4.8948526382446289e-01
    z[5,2,2]  R1618     -6.1697751283645630e-02
    z[5,2,2]  R1619     -7.4687354266643524e-02
    z[5,2,2]  R1620     2.9746848344802856e-01
    z[5,2,2]  R1621     -0.0318966880440712
    z[5,2,2]  R1622     -4.6656516194343567e-01
    z[5,2,2]  R1623     -2.1023957431316376e-01
    z[5,2,2]  R1624     1.2792116403579712e-01
    z[5,2,2]  R1625     4.3497156351804733e-02
    z[5,2,2]  R1626     -2.8441622853279114e-01
    z[5,2,2]  R1627     -2.7528798580169678e-01
    z[5,2,2]  R1628     2.6707369089126587e-01
    z[5,2,2]  R1629     -3.1428366899490356e-01
    z[5,2,2]  R1630     1.5977898240089417e-01
    z[5,2,2]  R1631     4.0474005043506622e-02
    z[5,2,2]  R1632     9.6002802252769470e-02
    z[5,2,2]  R1633     -3.2728922367095947e-01
    z[5,2,2]  R1634     -2.9421791434288025e-01
    z[5,2,2]  R1635     8.5515398532152176e-03
    z[5,2,2]  R1636     -4.5370987057685852e-01
    z[5,2,2]  R1637     2.7419024705886841e-01
    z[5,2,2]  R1638     3.0780667066574097e-01
    z[5,2,2]  R1639     6.1520017683506012e-02
    z[5,2,2]  R1640     -0.297622412443161
    z[5,2,2]  R1641     -4.1597130894660950e-01
    z[5,2,2]  R1642     -1.5419314801692963e-01
    z[5,2,2]  R1643     3.0139547586441040e-01
    z[5,2,2]  R1644     -9.3728266656398773e-02
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1558     -1
    z[5,2,3]  R1559     1
    z[5,2,3]  R1566     1.5760849416255951e-01
    z[5,2,3]  R1567     2.3670193552970886e-01
    z[5,2,3]  R1568     7.3240667581558228e-02
    z[5,2,3]  R1569     5.2571866661310196e-02
    z[5,2,3]  R1570     1.6801701486110687e-01
    z[5,2,3]  R1571     2.7998885512351990e-01
    z[5,2,3]  R1572     3.1080448627471924e-01
    z[5,2,3]  R1573     6.3498966395854950e-02
    z[5,2,3]  R1574     -0.07258290797472
    z[5,2,3]  R1575     -1.0689292103052139e-01
    z[5,2,3]  R1576     -4.5449972152709961e-01
    z[5,2,3]  R1577     -5.6289356946945190e-01
    z[5,2,3]  R1578     -4.6246212720870972e-01
    z[5,2,3]  R1579     -0.708291232585907
    z[5,2,3]  R1580     -4.3603339791297913e-01
    z[5,2,3]  R1581     -3.6672791838645935e-01
    z[5,2,3]  R1582     -5.9832257032394409e-01
    z[5,2,3]  R1583     -0.545274555683136
    z[5,2,3]  R1584     -6.8221920728683472e-01
    z[5,2,3]  R1585     -5.6845504045486450e-01
    z[5,2,3]  R1586     5.5740290880203247e-01
    z[5,2,3]  R1587     0.578544020652771
    z[5,2,3]  R1588     -6.0288065671920776e-01
    z[5,2,3]  R1589     -3.4921801090240479e-01
    z[5,2,3]  R1590     6.2654447555541992e-01
    z[5,2,3]  R1591     -5.2741795778274536e-01
    z[5,2,3]  R1592     -7.4762272834777832e-01
    z[5,2,3]  R1593     3.4952321648597717e-01
    z[5,2,3]  R1594     5.9685643762350082e-02
    z[5,2,3]  R1595     8.6430960893630981e-01
    z[5,2,3]  R1596     2.3574048280715942e-01
    z[5,2,3]  R1597     5.7690471410751343e-01
    z[5,2,3]  R1598     8.9302927255630493e-01
    z[5,2,3]  R1599     9.8066650331020355e-02
    z[5,2,3]  R1600     -2.5251312181353569e-02
    z[5,2,3]  R1601     -6.1161148548126221e-01
    z[5,2,3]  R1602     5.6304007768630981e-01
    z[5,2,3]  R1603     0.721450924873352
    z[5,2,3]  R1604     -0.00906460452824831
    z[5,2,3]  R1605     -4.1713351011276245e-01
    z[5,2,3]  R1606     0.0668509304523468
    z[5,2,3]  R1607     -4.4703356921672821e-02
    z[5,2,3]  R1608     5.5620354413986206e-01
    z[5,2,3]  R1609     5.3038930892944336e-01
    z[5,2,3]  R1610     3.3827179670333862e-01
    z[5,2,3]  R1611     2.0165410637855530e-01
    z[5,2,3]  R1612     6.4370816946029663e-01
    z[5,2,3]  R1613     -1.5139554627239704e-02
    z[5,2,3]  R1614     5.7504045963287354e-01
    z[5,2,3]  R1615     -5.7133636437356472e-03
    z[5,2,3]  R1616     6.0302615165710449e-02
    z[5,2,3]  R1617     4.3359076976776123e-01
    z[5,2,3]  R1618     4.4179043173789978e-01
    z[5,2,3]  R1619     -2.4320727214217186e-02
    z[5,2,3]  R1620     -1.8579587340354919e-01
    z[5,2,3]  R1621     1.1626062542200089e-01
    z[5,2,3]  R1622     5.6650150567293167e-02
    z[5,2,3]  R1623     2.9676252603530884e-01
    z[5,2,3]  R1624     -5.9717226773500443e-02
    z[5,2,3]  R1625     3.2643941044807434e-01
    z[5,2,3]  R1626     1.9942989945411682e-01
    z[5,2,3]  R1627     -1.4164198935031891e-01
    z[5,2,3]  R1628     -6.9845512509346008e-02
    z[5,2,3]  R1629     1.9365318119525909e-01
    z[5,2,3]  R1630     3.1281337141990662e-01
    z[5,2,3]  R1631     1.5215082466602325e-01
    z[5,2,3]  R1632     3.1471386551856995e-01
    z[5,2,3]  R1633     -2.0695790648460388e-01
    z[5,2,3]  R1634     -1.8547067046165466e-01
    z[5,2,3]  R1635     -3.7688681483268738e-01
    z[5,2,3]  R1636     -1.6205094754695892e-02
    z[5,2,3]  R1637     6.4295977354049683e-01
    z[5,2,3]  R1638     7.9940801858901978e-01
    z[5,2,3]  R1639     5.2079373598098755e-01
    z[5,2,3]  R1640     7.0280265808105469e-01
    z[5,2,3]  R1641     -4.1959017515182495e-01
    z[5,2,3]  R1642     6.6072773933410645e-01
    z[5,2,3]  R1643     -1.7309138178825378e-01
    z[5,2,3]  R1644     3.5341003537178040e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1560     -1
    z[5,2,4]  R1561     1
    z[5,2,4]  R1566     -5.2295696735382080e-01
    z[5,2,4]  R1567     -7.3008544743061066e-02
    z[5,2,4]  R1568     6.6151313483715057e-02
    z[5,2,4]  R1569     -3.2162305712699890e-01
    z[5,2,4]  R1570     0.0360804907977581
    z[5,2,4]  R1571     -3.5811248421669006e-01
    z[5,2,4]  R1572     -2.3946642875671387e-01
    z[5,2,4]  R1573     -2.9947438836097717e-01
    z[5,2,4]  R1574     -4.9453905224800110e-01
    z[5,2,4]  R1575     -3.8763910531997681e-01
    z[5,2,4]  R1576     -1.1475600302219391e-01
    z[5,2,4]  R1577     -4.1680745780467987e-03
    z[5,2,4]  R1578     2.9905638098716736e-01
    z[5,2,4]  R1579     7.8380726277828217e-02
    z[5,2,4]  R1580     2.1771165728569031e-01
    z[5,2,4]  R1581     2.9940694570541382e-01
    z[5,2,4]  R1582     4.2538410425186157e-01
    z[5,2,4]  R1583     -0.0423019640147686
    z[5,2,4]  R1584     2.6569724082946777e-01
    z[5,2,4]  R1585     5.8113500475883484e-02
    z[5,2,4]  R1586     -1.3618029654026031e-01
    z[5,2,4]  R1587     5.5409145355224609e-01
    z[5,2,4]  R1588     4.0063974261283875e-01
    z[5,2,4]  R1589     0.537505567073822
    z[5,2,4]  R1590     5.9833395481109619e-01
    z[5,2,4]  R1591     3.5292837023735046e-01
    z[5,2,4]  R1592     1.5173371136188507e-01
    z[5,2,4]  R1593     8.2123500108718872e-01
    z[5,2,4]  R1594     7.8610116243362427e-01
    z[5,2,4]  R1595     -3.6398649215698242e-02
    z[5,2,4]  R1596     1.8064025044441223e-01
    z[5,2,4]  R1597     0.0169846098870039
    z[5,2,4]  R1598     -2.3943005502223969e-01
    z[5,2,4]  R1599     -6.4937502145767212e-01
    z[5,2,4]  R1600     5.4747790098190308e-01
    z[5,2,4]  R1601     1.4513424038887024e-01
    z[5,2,4]  R1602     -2.9419302940368652e-01
    z[5,2,4]  R1603     2.1047417819499969e-01
    z[5,2,4]  R1604     -0.92336106300354
    z[5,2,4]  R1605     0.0594811849296093
    z[5,2,4]  R1606     5.9035980701446533e-01
    z[5,2,4]  R1607     -4.6010011434555054e-01
    z[5,2,4]  R1608     3.3176541328430176e-02
    z[5,2,4]  R1609     3.0229237675666809e-01
    z[5,2,4]  R1610     6.2527048587799072e-01
    z[5,2,4]  R1611     3.3453187346458435e-01
    z[5,2,4]  R1612     5.0589525699615479e-01
    z[5,2,4]  R1613     5.4702854156494141e-01
    z[5,2,4]  R1614     -4.0859675407409668e-01
    z[5,2,4]  R1615     -3.4494879841804504e-01
    z[5,2,4]  R1616     -6.2019479274749756e-01
    z[5,2,4]  R1617     -1.2619766592979431e-01
    z[5,2,4]  R1618     1.2386779487133026e-01
    z[5,2,4]  R1619     1.1356448382139206e-01
    z[5,2,4]  R1620     -0.685459315776825
    z[5,2,4]  R1621     -1.7781707644462585e-01
    z[5,2,4]  R1622     -5.6831365823745728e-01
    z[5,2,4]  R1623     -8.9890755712985992e-02
    z[5,2,4]  R1624     -0.570176362991333
    z[5,2,4]  R1625     -5.1463317126035690e-02
    z[5,2,4]  R1626     4.9570216797292233e-03
    z[5,2,4]  R1627     -2.1611016988754272e-01
    z[5,2,4]  R1628     3.0435770750045776e-01
    z[5,2,4]  R1629     3.5316145420074463e-01
    z[5,2,4]  R1630     2.9572373628616333e-01
    z[5,2,4]  R1631     4.7489190101623535e-01
    z[5,2,4]  R1632     5.1569879055023193e-01
    z[5,2,4]  R1633     -2.3159846663475037e-01
    z[5,2,4]  R1634     6.1637425422668457e-01
    z[5,2,4]  R1635     -2.5623646378517151e-01
    z[5,2,4]  R1636     2.5742354989051819e-01
    z[5,2,4]  R1637     3.6368942260742188e-01
    z[5,2,4]  R1638     -2.6839458942413330e-01
    z[5,2,4]  R1639     -0.610956072807312
    z[5,2,4]  R1640     -2.6510828733444214e-01
    z[5,2,4]  R1641     7.2587326169013977e-02
    z[5,2,4]  R1642     -2.4104593694210052e-01
    z[5,2,4]  R1643     0.389614462852478
    z[5,2,4]  R1644     -4.4050836563110352e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1562     -1
    z[5,2,5]  R1563     1
    z[5,2,5]  R1566     1.7254360020160675e-01
    z[5,2,5]  R1567     0.782616138458252
    z[5,2,5]  R1568     4.1756004095077515e-01
    z[5,2,5]  R1569     2.6718342304229736e-01
    z[5,2,5]  R1570     5.2473846822977066e-02
    z[5,2,5]  R1571     -1.7000629007816315e-01
    z[5,2,5]  R1572     -4.7777980566024780e-02
    z[5,2,5]  R1573     8.3798050880432129e-01
    z[5,2,5]  R1574     3.3537822961807251e-01
    z[5,2,5]  R1575     0.630859911441803
    z[5,2,5]  R1576     -2.0510685443878174e-01
    z[5,2,5]  R1577     -3.3171677589416504e-01
    z[5,2,5]  R1578     -4.5201838016510010e-02
    z[5,2,5]  R1579     -4.7424682974815369e-01
    z[5,2,5]  R1580     -3.8958451151847839e-01
    z[5,2,5]  R1581     -2.3353940248489380e-01
    z[5,2,5]  R1582     -3.1496521085500717e-02
    z[5,2,5]  R1583     -4.7385808825492859e-01
    z[5,2,5]  R1584     -3.0427780747413635e-01
    z[5,2,5]  R1585     -3.7121587991714478e-01
    z[5,2,5]  R1586     -5.8360165357589722e-01
    z[5,2,5]  R1587     -2.2560764849185944e-01
    z[5,2,5]  R1588     -0.407821923494339
    z[5,2,5]  R1589     1.6855373978614807e-01
    z[5,2,5]  R1590     1.0096298158168793e-01
    z[5,2,5]  R1591     -3.8624534010887146e-01
    z[5,2,5]  R1592     -3.9207586646080017e-01
    z[5,2,5]  R1593     2.3046796023845673e-01
    z[5,2,5]  R1594     -0.0591965913772583
    z[5,2,5]  R1595     -5.5470943450927734e-02
    z[5,2,5]  R1596     -3.2538297772407532e-01
    z[5,2,5]  R1597     -7.1658574044704437e-02
    z[5,2,5]  R1598     1.0443413257598877e-01
    z[5,2,5]  R1599     -0.562673032283783
    z[5,2,5]  R1600     3.3719030022621155e-01
    z[5,2,5]  R1601     -1.6899110376834869e-01
    z[5,2,5]  R1602     -0.410017728805542
    z[5,2,5]  R1603     5.1297504454851151e-02
    z[5,2,5]  R1604     -1.3205739855766296e-01
    z[5,2,5]  R1605     -1.3057488203048706e-01
    z[5,2,5]  R1606     6.3000130653381348e-01
    z[5,2,5]  R1607     1.3500395417213440e-01
    z[5,2,5]  R1608     -4.7661134600639343e-01
    z[5,2,5]  R1609     5.5322146415710449e-01
    z[5,2,5]  R1610     -5.1534615457057953e-02
    z[5,2,5]  R1611     4.5814774930477142e-02
    z[5,2,5]  R1612     1.0212268680334091e-01
    z[5,2,5]  R1613     1.0070103406906128e-01
    z[5,2,5]  R1614     -8.0719053745269775e-02
    z[5,2,5]  R1615     7.3272442817687988e-01
    z[5,2,5]  R1616     5.7743382453918457e-01
    z[5,2,5]  R1617     -1.1910753697156906e-01
    z[5,2,5]  R1618     9.9070534110069275e-02
    z[5,2,5]  R1619     1.4756646752357483e-01
    z[5,2,5]  R1620     2.8583604097366333e-01
    z[5,2,5]  R1621     7.0279783010482788e-01
    z[5,2,5]  R1622     -5.8415614068508148e-02
    z[5,2,5]  R1623     4.1297596693038940e-01
    z[5,2,5]  R1624     2.5528600811958313e-01
    z[5,2,5]  R1625     4.4018706679344177e-01
    z[5,2,5]  R1626     1.9469425082206726e-01
    z[5,2,5]  R1627     3.5704341530799866e-01
    z[5,2,5]  R1628     3.5296735167503357e-01
    z[5,2,5]  R1629     3.7022951245307922e-01
    z[5,2,5]  R1630     -6.9216839969158173e-02
    z[5,2,5]  R1631     3.6752417683601379e-01
    z[5,2,5]  R1632     1.9860202074050903e-01
    z[5,2,5]  R1633     -8.5678435862064362e-02
    z[5,2,5]  R1634     3.0596208572387695e-01
    z[5,2,5]  R1635     3.2019170466810465e-03
    z[5,2,5]  R1636     -2.9590100049972534e-01
    z[5,2,5]  R1637     5.0767010450363159e-01
    z[5,2,5]  R1638     1.7190322279930115e-01
    z[5,2,5]  R1639     6.0550201684236526e-02
    z[5,2,5]  R1640     1.5664808452129364e-01
    z[5,2,5]  R1641     8.2535691559314728e-02
    z[5,2,5]  R1642     -1.4474037289619446e-01
    z[5,2,5]  R1643     -4.6410274505615234e-01
    z[5,2,5]  R1644     -2.1927395462989807e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1564     -1
    z[5,2,6]  R1565     1
    z[5,2,6]  R1566     -6.7084066569805145e-02
    z[5,2,6]  R1567     3.2850247621536255e-01
    z[5,2,6]  R1568     5.8844357728958130e-01
    z[5,2,6]  R1569     3.1738871335983276e-01
    z[5,2,6]  R1570     4.5578393340110779e-01
    z[5,2,6]  R1571     5.2658468484878540e-01
    z[5,2,6]  R1572     -2.4421733617782593e-01
    z[5,2,6]  R1573     -1.5115892887115479e-01
    z[5,2,6]  R1574     -3.5378482192754745e-02
    z[5,2,6]  R1575     2.1014676988124847e-01
    z[5,2,6]  R1576     2.2431743144989014e-01
    z[5,2,6]  R1577     1.4723828434944153e-01
    z[5,2,6]  R1578     2.7871602773666382e-01
    z[5,2,6]  R1579     -1.4741206541657448e-02
    z[5,2,6]  R1580     -6.3567437231540680e-02
    z[5,2,6]  R1581     2.5572484731674194e-01
    z[5,2,6]  R1582     -8.9660808444023132e-03
    z[5,2,6]  R1583     3.4135526418685913e-01
    z[5,2,6]  R1584     3.1523339450359344e-02
    z[5,2,6]  R1585     3.2076603174209595e-01
    z[5,2,6]  R1586     -4.4919201731681824e-01
    z[5,2,6]  R1587     -3.9003399014472961e-01
    z[5,2,6]  R1588     1.9633628427982330e-01
    z[5,2,6]  R1589     -5.4399389773607254e-02
    z[5,2,6]  R1590     -1.1013595014810562e-01
    z[5,2,6]  R1591     -6.7405253648757935e-02
    z[5,2,6]  R1592     3.1717678066343069e-03
    z[5,2,6]  R1593     -2.1271444857120514e-01
    z[5,2,6]  R1594     -2.4861088395118713e-01
    z[5,2,6]  R1595     -1.8542063236236572e-01
    z[5,2,6]  R1596     -3.2147186994552612e-01
    z[5,2,6]  R1597     -4.6655958890914917e-01
    z[5,2,6]  R1598     -1.2904070317745209e-01
    z[5,2,6]  R1599     -2.1621312201023102e-01
    z[5,2,6]  R1600     -2.8564631938934326e-01
    z[5,2,6]  R1601     -2.0460499450564384e-02
    z[5,2,6]  R1602     -0.547367513179779
    z[5,2,6]  R1603     -2.6937276124954224e-01
    z[5,2,6]  R1604     -6.2870413064956665e-02
    z[5,2,6]  R1605     -7.1676015853881836e-01
    z[5,2,6]  R1606     -1.9281332194805145e-01
    z[5,2,6]  R1607     1.7515836656093597e-01
    z[5,2,6]  R1608     -8.7471000850200653e-02
    z[5,2,6]  R1609     -8.9473605155944824e-02
    z[5,2,6]  R1610     -3.0243399739265442e-01
    z[5,2,6]  R1611     2.1716007590293884e-01
    z[5,2,6]  R1612     2.7200832962989807e-01
    z[5,2,6]  R1613     4.6990740299224854e-01
    z[5,2,6]  R1614     0.0439128652215004
    z[5,2,6]  R1615     1.6707342863082886e-01
    z[5,2,6]  R1616     -1.5947981178760529e-01
    z[5,2,6]  R1617     1.1592247337102890e-01
    z[5,2,6]  R1618     4.2579475045204163e-01
    z[5,2,6]  R1619     -3.2284185290336609e-01
    z[5,2,6]  R1620     8.2118771970272064e-02
    z[5,2,6]  R1621     -5.2011966705322266e-01
    z[5,2,6]  R1622     0.106770820915699
    z[5,2,6]  R1623     -6.4204132556915283e-01
    z[5,2,6]  R1624     -0.638708233833313
    z[5,2,6]  R1625     1.6347558796405792e-01
    z[5,2,6]  R1626     4.2418867349624634e-02
    z[5,2,6]  R1627     6.5617696382105350e-03
    z[5,2,6]  R1628     4.5117955654859543e-02
    z[5,2,6]  R1629     3.3418801426887512e-01
    z[5,2,6]  R1630     9.3657158315181732e-02
    z[5,2,6]  R1631     -3.3215171098709106e-01
    z[5,2,6]  R1632     2.3647336661815643e-01
    z[5,2,6]  R1633     2.7245423197746277e-01
    z[5,2,6]  R1634     -0.257385790348053
    z[5,2,6]  R1635     -1.8693499267101288e-01
    z[5,2,6]  R1636     -1.6323995590209961e-01
    z[5,2,6]  R1637     -1.0348517447710037e-01
    z[5,2,6]  R1638     -3.0516979098320007e-01
    z[5,2,6]  R1639     -7.4036069214344025e-02
    z[5,2,6]  R1640     4.0562847256660461e-01
    z[5,2,6]  R1641     5.1011914014816284e-01
    z[5,2,6]  R1642     -2.7839767932891846e-01
    z[5,2,6]  R1643     -4.2455330491065979e-01
    z[5,2,6]  R1644     4.8394781351089478e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1645     -1
    z[2,6,0]  R1646     1
    z[2,6,0]  R1659     -7.6891683042049408e-02
    z[2,6,0]  R1660     9.7774147987365723e-02
    z[2,6,0]  R1661     -1.1200371384620667e-01
    z[2,6,0]  R1662     -1.0103247128427029e-02
    z[2,6,0]  R1663     1.8761040270328522e-01
    z[2,6,0]  R1664     -1.8172055482864380e-01
    z[2,6,0]  R1665     1.5545558929443359e-01
    z[2,6,0]  R1666     1.4082913100719452e-01
    z[2,6,0]  R1667     3.0249828100204468e-01
    z[2,6,0]  R1668     1.1991544812917709e-01
    z[2,6,0]  R1669     -1.2291748821735382e-01
    z[2,6,0]  R1670     2.8967265039682388e-02
    z[2,6,0]  R1671     -0.0217283982783556
    z[2,6,0]  R1672     -1.7278583347797394e-01
    z[2,6,0]  R1673     -2.3908168077468872e-02
    z[2,6,0]  R1674     -8.7013579905033112e-02
    z[2,6,0]  R1675     0.06809101998806
    z[2,6,0]  R1676     -1.0040861368179321e-01
    z[2,6,0]  R1677     -6.5120466053485870e-02
    z[2,6,0]  R1678     1.5014787018299103e-01
    z[2,6,0]  R1679     -6.3791498541831970e-02
    z[2,6,0]  R1680     1.9312863051891327e-01
    z[2,6,0]  R1681     -2.5318851694464684e-02
    z[2,6,0]  R1682     2.2771932184696198e-02
    z[2,6,0]  R1683     -3.4576624631881714e-02
    z[2,6,0]  R1684     -9.8926816135644913e-03
    z[2,6,0]  R1685     -1.0351626574993134e-01
    z[2,6,0]  R1686     1.6009204089641571e-01
    z[2,6,0]  R1687     3.1615566462278366e-02
    z[2,6,0]  R1688     -1.4451977610588074e-01
    z[2,6,0]  R1689     -4.8729193210601807e-01
    z[2,6,0]  R1690     -6.0099172592163086e-01
    z[2,6,0]  R1691     -3.2954074442386627e-02
    z[2,6,0]  R1692     7.5554296374320984e-02
    z[2,6,0]  R1693     -9.7896084189414978e-02
    z[2,6,0]  R1694     -3.8970449566841125e-01
    z[2,6,0]  R1695     1.2374044954776764e-01
    z[2,6,0]  R1696     2.8977102041244507e-01
    z[2,6,0]  R1697     -4.6530212275683880e-03
    z[2,6,0]  R1698     7.6810702681541443e-02
    z[2,6,0]  R1699     2.7076140046119690e-01
    z[2,6,0]  R1700     2.0435069501399994e-01
    z[2,6,0]  R1701     4.8351809382438660e-03
    z[2,6,0]  R1702     2.4945285916328430e-01
    z[2,6,0]  R1703     0.213861882686615
    z[2,6,0]  R1704     1.9959162175655365e-01
    z[2,6,0]  R1705     1.0795354098081589e-01
    z[2,6,0]  R1706     0.0949750691652298
    z[2,6,0]  R1707     1.0327365249395370e-01
    z[2,6,0]  R1708     -1.4315104484558105e-01
    z[2,6,0]  R1709     1.0323889553546906e-01
    z[2,6,0]  R1710     -0.086922287940979
    z[2,6,0]  R1711     4.8406824469566345e-01
    z[2,6,0]  R1712     1.0395500808954239e-02
    z[2,6,0]  R1713     -1.1849900335073471e-01
    z[2,6,0]  R1714     -4.7565117478370667e-02
    z[2,6,0]  R1715     -2.8622692823410034e-01
    z[2,6,0]  R1716     2.3305535316467285e-02
    z[2,6,0]  R1717     -1.2474393099546432e-01
    z[2,6,0]  R1718     -2.1036426723003387e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1647     -1
    z[2,6,1]  R1648     1
    z[2,6,1]  R1659     -5.5581796169281006e-01
    z[2,6,1]  R1660     -4.0392491221427917e-01
    z[2,6,1]  R1661     -0.71854567527771
    z[2,6,1]  R1662     -7.7100795507431030e-01
    z[2,6,1]  R1663     -9.0539109706878662e-01
    z[2,6,1]  R1664     -0.53448086977005
    z[2,6,1]  R1665     -4.0648657083511353e-01
    z[2,6,1]  R1666     -6.4921647310256958e-01
    z[2,6,1]  R1667     -4.3055734038352966e-01
    z[2,6,1]  R1668     -4.0923115611076355e-01
    z[2,6,1]  R1669     0.808269202709198
    z[2,6,1]  R1670     0.915841817855835
    z[2,6,1]  R1671     8.5408157110214233e-01
    z[2,6,1]  R1672     8.2139098644256592e-01
    z[2,6,1]  R1673     6.9976997375488281e-01
    z[2,6,1]  R1674     8.7637430429458618e-01
    z[2,6,1]  R1675     7.0686239004135132e-01
    z[2,6,1]  R1676     7.2135227918624878e-01
    z[2,6,1]  R1677     8.4297072887420654e-01
    z[2,6,1]  R1678     5.6277406215667725e-01
    z[2,6,1]  R1679     8.6787194013595581e-01
    z[2,6,1]  R1680     0.759022057056427
    z[2,6,1]  R1681     3.3177286386489868e-01
    z[2,6,1]  R1682     2.6639896631240845e-01
    z[2,6,1]  R1683     5.8427613973617554e-01
    z[2,6,1]  R1684     3.9753732085227966e-01
    z[2,6,1]  R1685     6.0654246807098389e-01
    z[2,6,1]  R1686     0.597892701625824
    z[2,6,1]  R1687     5.7512110471725464e-01
    z[2,6,1]  R1688     6.0753285884857178e-01
    z[2,6,1]  R1689     -3.5702398419380188e-01
    z[2,6,1]  R1690     -1.5415129065513611e-01
    z[2,6,1]  R1691     -6.7099016904830933e-01
    z[2,6,1]  R1692     -7.4068850278854370e-01
    z[2,6,1]  R1693     -5.4062509536743164e-01
    z[2,6,1]  R1694     -6.6204947233200073e-01
    z[2,6,1]  R1695     -4.0233135223388672e-01
    z[2,6,1]  R1696     -3.5219326615333557e-01
    z[2,6,1]  R1697     -2.4606880545616150e-01
    z[2,6,1]  R1698     4.4106975197792053e-01
    z[2,6,1]  R1699     -3.9074367284774780e-01
    z[2,6,1]  R1700     -3.0664929747581482e-01
    z[2,6,1]  R1701     -1.6096708178520203e-01
    z[2,6,1]  R1702     3.9459779858589172e-01
    z[2,6,1]  R1703     7.5173395872116089e-01
    z[2,6,1]  R1704     7.4822336435317993e-01
    z[2,6,1]  R1705     6.6282504796981812e-01
    z[2,6,1]  R1706     8.2198286056518555e-01
    z[2,6,1]  R1707     6.5111505985260010e-01
    z[2,6,1]  R1708     8.3069866895675659e-01
    z[2,6,1]  R1709     -4.4804677367210388e-01
    z[2,6,1]  R1710     -3.9826601743698120e-01
    z[2,6,1]  R1711     -2.6746892929077148e-01
    z[2,6,1]  R1712     9.1232210397720337e-01
    z[2,6,1]  R1713     9.3661522865295410e-01
    z[2,6,1]  R1714     7.7929776906967163e-01
    z[2,6,1]  R1715     9.1708499193191528e-01
    z[2,6,1]  R1716     -1.9481889903545380e-01
    z[2,6,1]  R1717     6.5784966945648193e-01
    z[2,6,1]  R1718     0.863397479057312
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1649     -1
    z[2,6,2]  R1650     1
    z[2,6,2]  R1659     -3.6512367427349091e-02
    z[2,6,2]  R1660     -2.8309595584869385e-01
    z[2,6,2]  R1661     4.8948526382446289e-01
    z[2,6,2]  R1662     -6.1697751283645630e-02
    z[2,6,2]  R1663     -7.4687354266643524e-02
    z[2,6,2]  R1664     2.9746848344802856e-01
    z[2,6,2]  R1665     -0.0318966880440712
    z[2,6,2]  R1666     -4.6656516194343567e-01
    z[2,6,2]  R1667     -2.1023957431316376e-01
    z[2,6,2]  R1668     1.2792116403579712e-01
    z[2,6,2]  R1669     4.3497156351804733e-02
    z[2,6,2]  R1670     -2.8441622853279114e-01
    z[2,6,2]  R1671     -2.7528798580169678e-01
    z[2,6,2]  R1672     2.6707369089126587e-01
    z[2,6,2]  R1673     -3.1428366899490356e-01
    z[2,6,2]  R1674     1.5977898240089417e-01
    z[2,6,2]  R1675     4.0474005043506622e-02
    z[2,6,2]  R1676     9.6002802252769470e-02
    z[2,6,2]  R1677     -3.2728922367095947e-01
    z[2,6,2]  R1678     -2.9421791434288025e-01
    z[2,6,2]  R1679     8.5515398532152176e-03
    z[2,6,2]  R1680     -4.5370987057685852e-01
    z[2,6,2]  R1681     2.7419024705886841e-01
    z[2,6,2]  R1682     3.0780667066574097e-01
    z[2,6,2]  R1683     6.1520017683506012e-02
    z[2,6,2]  R1684     -0.297622412443161
    z[2,6,2]  R1685     -4.1597130894660950e-01
    z[2,6,2]  R1686     -1.5419314801692963e-01
    z[2,6,2]  R1687     3.0139547586441040e-01
    z[2,6,2]  R1688     -9.3728266656398773e-02
    z[2,6,2]  R1689     3.3122763037681580e-01
    z[2,6,2]  R1690     5.5581283569335938e-01
    z[2,6,2]  R1691     1.5156951732933521e-02
    z[2,6,2]  R1692     2.4588094651699066e-01
    z[2,6,2]  R1693     -5.8745924383401871e-02
    z[2,6,2]  R1694     4.3144565820693970e-01
    z[2,6,2]  R1695     -2.6238444447517395e-01
    z[2,6,2]  R1696     -1.4579498767852783e-01
    z[2,6,2]  R1697     2.3747770488262177e-01
    z[2,6,2]  R1698     -5.1327288150787354e-01
    z[2,6,2]  R1699     -9.1044150292873383e-02
    z[2,6,2]  R1700     -6.8464823067188263e-02
    z[2,6,2]  R1701     2.3217935115098953e-02
    z[2,6,2]  R1702     -1.6536971926689148e-01
    z[2,6,2]  R1703     8.6744002997875214e-02
    z[2,6,2]  R1704     2.3347425460815430e-01
    z[2,6,2]  R1705     -1.0240331292152405e-01
    z[2,6,2]  R1706     6.9272637367248535e-02
    z[2,6,2]  R1707     -4.7520559281110764e-02
    z[2,6,2]  R1708     2.3230488598346710e-01
    z[2,6,2]  R1709     1.0994613170623779e-01
    z[2,6,2]  R1710     5.5095762014389038e-01
    z[2,6,2]  R1711     -2.7092188596725464e-01
    z[2,6,2]  R1712     5.5401004850864410e-02
    z[2,6,2]  R1713     3.7188478745520115e-03
    z[2,6,2]  R1714     5.7915952056646347e-02
    z[2,6,2]  R1715     1.3038368523120880e-01
    z[2,6,2]  R1716     -8.4326320886611938e-01
    z[2,6,2]  R1717     -4.6066680806688964e-04
    z[2,6,2]  R1718     2.4493815004825592e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1651     -1
    z[2,6,3]  R1652     1
    z[2,6,3]  R1659     -5.7133636437356472e-03
    z[2,6,3]  R1660     6.0302615165710449e-02
    z[2,6,3]  R1661     4.3359076976776123e-01
    z[2,6,3]  R1662     4.4179043173789978e-01
    z[2,6,3]  R1663     -2.4320727214217186e-02
    z[2,6,3]  R1664     -1.8579587340354919e-01
    z[2,6,3]  R1665     1.1626062542200089e-01
    z[2,6,3]  R1666     5.6650150567293167e-02
    z[2,6,3]  R1667     2.9676252603530884e-01
    z[2,6,3]  R1668     -5.9717226773500443e-02
    z[2,6,3]  R1669     3.2643941044807434e-01
    z[2,6,3]  R1670     1.9942989945411682e-01
    z[2,6,3]  R1671     -1.4164198935031891e-01
    z[2,6,3]  R1672     -6.9845512509346008e-02
    z[2,6,3]  R1673     1.9365318119525909e-01
    z[2,6,3]  R1674     3.1281337141990662e-01
    z[2,6,3]  R1675     1.5215082466602325e-01
    z[2,6,3]  R1676     3.1471386551856995e-01
    z[2,6,3]  R1677     -2.0695790648460388e-01
    z[2,6,3]  R1678     -1.8547067046165466e-01
    z[2,6,3]  R1679     -3.7688681483268738e-01
    z[2,6,3]  R1680     -1.6205094754695892e-02
    z[2,6,3]  R1681     6.4295977354049683e-01
    z[2,6,3]  R1682     7.9940801858901978e-01
    z[2,6,3]  R1683     5.2079373598098755e-01
    z[2,6,3]  R1684     7.0280265808105469e-01
    z[2,6,3]  R1685     -4.1959017515182495e-01
    z[2,6,3]  R1686     6.6072773933410645e-01
    z[2,6,3]  R1687     -1.7309138178825378e-01
    z[2,6,3]  R1688     3.5341003537178040e-01
    z[2,6,3]  R1689     3.4000462293624878e-01
    z[2,6,3]  R1690     4.3322449922561646e-01
    z[2,6,3]  R1691     1.7993398010730743e-01
    z[2,6,3]  R1692     4.8892334103584290e-01
    z[2,6,3]  R1693     5.5010837316513062e-01
    z[2,6,3]  R1694     1.3757245242595673e-01
    z[2,6,3]  R1695     1.3948038220405579e-01
    z[2,6,3]  R1696     5.0318348407745361e-01
    z[2,6,3]  R1697     2.5663191080093384e-01
    z[2,6,3]  R1698     5.1807653903961182e-01
    z[2,6,3]  R1699     -7.7442824840545654e-01
    z[2,6,3]  R1700     -8.5130870342254639e-01
    z[2,6,3]  R1701     -6.3003784418106079e-01
    z[2,6,3]  R1702     2.8973874449729919e-01
    z[2,6,3]  R1703     -5.4302328824996948e-01
    z[2,6,3]  R1704     -4.9294564127922058e-01
    z[2,6,3]  R1705     -4.6769458055496216e-01
    z[2,6,3]  R1706     -1.9529570639133453e-01
    z[2,6,3]  R1707     -4.9641317129135132e-01
    z[2,6,3]  R1708     1.0120025277137756e-01
    z[2,6,3]  R1709     -4.3710049986839294e-01
    z[2,6,3]  R1710     -4.9073022603988647e-01
    z[2,6,3]  R1711     -2.5777477025985718e-01
    z[2,6,3]  R1712     -1.5390133485198021e-02
    z[2,6,3]  R1713     -6.4651072025299072e-02
    z[2,6,3]  R1714     2.9587191343307495e-01
    z[2,6,3]  R1715     -1.4695847034454346e-01
    z[2,6,3]  R1716     -0.332194447517395
    z[2,6,3]  R1717     1.6896338760852814e-01
    z[2,6,3]  R1718     -1.7404754459857941e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1653     -1
    z[2,6,4]  R1654     1
    z[2,6,4]  R1659     -3.4494879841804504e-01
    z[2,6,4]  R1660     -6.2019479274749756e-01
    z[2,6,4]  R1661     -1.2619766592979431e-01
    z[2,6,4]  R1662     1.2386779487133026e-01
    z[2,6,4]  R1663     1.1356448382139206e-01
    z[2,6,4]  R1664     -0.685459315776825
    z[2,6,4]  R1665     -1.7781707644462585e-01
    z[2,6,4]  R1666     -5.6831365823745728e-01
    z[2,6,4]  R1667     -8.9890755712985992e-02
    z[2,6,4]  R1668     -0.570176362991333
    z[2,6,4]  R1669     -5.1463317126035690e-02
    z[2,6,4]  R1670     4.9570216797292233e-03
    z[2,6,4]  R1671     -2.1611016988754272e-01
    z[2,6,4]  R1672     3.0435770750045776e-01
    z[2,6,4]  R1673     3.5316145420074463e-01
    z[2,6,4]  R1674     2.9572373628616333e-01
    z[2,6,4]  R1675     4.7489190101623535e-01
    z[2,6,4]  R1676     5.1569879055023193e-01
    z[2,6,4]  R1677     -2.3159846663475037e-01
    z[2,6,4]  R1678     6.1637425422668457e-01
    z[2,6,4]  R1679     -2.5623646378517151e-01
    z[2,6,4]  R1680     2.5742354989051819e-01
    z[2,6,4]  R1681     3.6368942260742188e-01
    z[2,6,4]  R1682     -2.6839458942413330e-01
    z[2,6,4]  R1683     -0.610956072807312
    z[2,6,4]  R1684     -2.6510828733444214e-01
    z[2,6,4]  R1685     7.2587326169013977e-02
    z[2,6,4]  R1686     -2.4104593694210052e-01
    z[2,6,4]  R1687     0.389614462852478
    z[2,6,4]  R1688     -4.4050836563110352e-01
    z[2,6,4]  R1689     -4.6212986111640930e-01
    z[2,6,4]  R1690     -1.0306835174560547e-01
    z[2,6,4]  R1691     2.4907572567462921e-01
    z[2,6,4]  R1692     3.5415120422840118e-02
    z[2,6,4]  R1693     2.5946739315986633e-01
    z[2,6,4]  R1694     3.1383502483367920e-01
    z[2,6,4]  R1695     -6.5896719694137573e-01
    z[2,6,4]  R1696     -0.596753716468811
    z[2,6,4]  R1697     -6.1668014526367188e-01
    z[2,6,4]  R1698     -0.358946830034256
    z[2,6,4]  R1699     6.9367498159408569e-02
    z[2,6,4]  R1700     -0.0192574355751276
    z[2,6,4]  R1701     5.4983311891555786e-01
    z[2,6,4]  R1702     7.6512259244918823e-01
    z[2,6,4]  R1703     1.8830262124538422e-02
    z[2,6,4]  R1704     1.5435796976089478e-01
    z[2,6,4]  R1705     4.5882749557495117e-01
    z[2,6,4]  R1706     -4.8992950469255447e-02
    z[2,6,4]  R1707     2.2206287086009979e-01
    z[2,6,4]  R1708     0.18660868704319
    z[2,6,4]  R1709     -2.0885774865746498e-02
    z[2,6,4]  R1710     -6.6024191677570343e-02
    z[2,6,4]  R1711     5.5955165624618530e-01
    z[2,6,4]  R1712     1.1262305080890656e-01
    z[2,6,4]  R1713     2.5707712769508362e-01
    z[2,6,4]  R1714     1.4648343622684479e-01
    z[2,6,4]  R1715     4.4894441962242126e-02
    z[2,6,4]  R1716     0.320562481880188
    z[2,6,4]  R1717     4.6578127145767212e-01
    z[2,6,4]  R1718     1.7981793731451035e-02
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1655     -1
    z[2,6,5]  R1656     1
    z[2,6,5]  R1659     7.3272442817687988e-01
    z[2,6,5]  R1660     5.7743382453918457e-01
    z[2,6,5]  R1661     -1.1910753697156906e-01
    z[2,6,5]  R1662     9.9070534110069275e-02
    z[2,6,5]  R1663     1.4756646752357483e-01
    z[2,6,5]  R1664     2.8583604097366333e-01
    z[2,6,5]  R1665     7.0279783010482788e-01
    z[2,6,5]  R1666     -5.8415614068508148e-02
    z[2,6,5]  R1667     4.1297596693038940e-01
    z[2,6,5]  R1668     2.5528600811958313e-01
    z[2,6,5]  R1669     4.4018706679344177e-01
    z[2,6,5]  R1670     1.9469425082206726e-01
    z[2,6,5]  R1671     3.5704341530799866e-01
    z[2,6,5]  R1672     3.5296735167503357e-01
    z[2,6,5]  R1673     3.7022951245307922e-01
    z[2,6,5]  R1674     -6.9216839969158173e-02
    z[2,6,5]  R1675     3.6752417683601379e-01
    z[2,6,5]  R1676     1.9860202074050903e-01
    z[2,6,5]  R1677     -8.5678435862064362e-02
    z[2,6,5]  R1678     3.0596208572387695e-01
    z[2,6,5]  R1679     3.2019170466810465e-03
    z[2,6,5]  R1680     -2.9590100049972534e-01
    z[2,6,5]  R1681     5.0767010450363159e-01
    z[2,6,5]  R1682     1.7190322279930115e-01
    z[2,6,5]  R1683     6.0550201684236526e-02
    z[2,6,5]  R1684     1.5664808452129364e-01
    z[2,6,5]  R1685     8.2535691559314728e-02
    z[2,6,5]  R1686     -1.4474037289619446e-01
    z[2,6,5]  R1687     -4.6410274505615234e-01
    z[2,6,5]  R1688     -2.1927395462989807e-01
    z[2,6,5]  R1689     3.5383099317550659e-01
    z[2,6,5]  R1690     0.298246830701828
    z[2,6,5]  R1691     6.6604816913604736e-01
    z[2,6,5]  R1692     1.4240823686122894e-01
    z[2,6,5]  R1693     -3.3883821964263916e-01
    z[2,6,5]  R1694     2.1826688945293427e-01
    z[2,6,5]  R1695     5.4729700088500977e-01
    z[2,6,5]  R1696     -2.7310594916343689e-01
    z[2,6,5]  R1697     4.3495544791221619e-01
    z[2,6,5]  R1698     2.6600891351699829e-01
    z[2,6,5]  R1699     -2.7356579899787903e-01
    z[2,6,5]  R1700     -0.362730473279953
    z[2,6,5]  R1701     -0.503667414188385
    z[2,6,5]  R1702     1.2624172866344452e-01
    z[2,6,5]  R1703     -2.6105238124728203e-02
    z[2,6,5]  R1704     -2.7103149890899658e-01
    z[2,6,5]  R1705     -1.5463612973690033e-01
    z[2,6,5]  R1706     -3.1710001826286316e-01
    z[2,6,5]  R1707     4.2258673906326294e-01
    z[2,6,5]  R1708     -3.6251193284988403e-01
    z[2,6,5]  R1709     -7.6343721151351929e-01
    z[2,6,5]  R1710     -3.9944148063659668e-01
    z[2,6,5]  R1711     -4.7607335448265076e-01
    z[2,6,5]  R1712     -2.4536564946174622e-01
    z[2,6,5]  R1713     -1.9593752920627594e-01
    z[2,6,5]  R1714     -5.0675994157791138e-01
    z[2,6,5]  R1715     -1.6763083636760712e-01
    z[2,6,5]  R1716     -3.7964764982461929e-02
    z[2,6,5]  R1717     -5.2175086736679077e-01
    z[2,6,5]  R1718     2.1028614044189453e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1657     -1
    z[2,6,6]  R1658     1
    z[2,6,6]  R1659     1.6707342863082886e-01
    z[2,6,6]  R1660     -1.5947981178760529e-01
    z[2,6,6]  R1661     1.1592247337102890e-01
    z[2,6,6]  R1662     4.2579475045204163e-01
    z[2,6,6]  R1663     -3.2284185290336609e-01
    z[2,6,6]  R1664     8.2118771970272064e-02
    z[2,6,6]  R1665     -5.2011966705322266e-01
    z[2,6,6]  R1666     0.106770820915699
    z[2,6,6]  R1667     -6.4204132556915283e-01
    z[2,6,6]  R1668     -0.638708233833313
    z[2,6,6]  R1669     1.6347558796405792e-01
    z[2,6,6]  R1670     4.2418867349624634e-02
    z[2,6,6]  R1671     6.5617696382105350e-03
    z[2,6,6]  R1672     4.5117955654859543e-02
    z[2,6,6]  R1673     3.3418801426887512e-01
    z[2,6,6]  R1674     9.3657158315181732e-02
    z[2,6,6]  R1675     -3.3215171098709106e-01
    z[2,6,6]  R1676     2.3647336661815643e-01
    z[2,6,6]  R1677     2.7245423197746277e-01
    z[2,6,6]  R1678     -0.257385790348053
    z[2,6,6]  R1679     -1.8693499267101288e-01
    z[2,6,6]  R1680     -1.6323995590209961e-01
    z[2,6,6]  R1681     -1.0348517447710037e-01
    z[2,6,6]  R1682     -3.0516979098320007e-01
    z[2,6,6]  R1683     -7.4036069214344025e-02
    z[2,6,6]  R1684     4.0562847256660461e-01
    z[2,6,6]  R1685     5.1011914014816284e-01
    z[2,6,6]  R1686     -2.7839767932891846e-01
    z[2,6,6]  R1687     -4.2455330491065979e-01
    z[2,6,6]  R1688     4.8394781351089478e-01
    z[2,6,6]  R1689     2.6646783947944641e-01
    z[2,6,6]  R1690     1.3733452558517456e-01
    z[2,6,6]  R1691     1.0208512842655182e-01
    z[2,6,6]  R1692     -3.5303589701652527e-01
    z[2,6,6]  R1693     4.5818752050399780e-01
    z[2,6,6]  R1694     0.242108553647995
    z[2,6,6]  R1695     2.7308214455842972e-02
    z[2,6,6]  R1696     -2.9468801617622375e-01
    z[2,6,6]  R1697     -4.9768692255020142e-01
    z[2,6,6]  R1698     2.6096296310424805e-01
    z[2,6,6]  R1699     -2.9381856322288513e-01
    z[2,6,6]  R1700     5.3373958915472031e-02
    z[2,6,6]  R1701     -1.4346466958522797e-01
    z[2,6,6]  R1702     -2.6347804069519043e-01
    z[2,6,6]  R1703     -2.9278692603111267e-01
    z[2,6,6]  R1704     -7.4396848678588867e-02
    z[2,6,6]  R1705     2.9214599728584290e-01
    z[2,6,6]  R1706     -4.1162124276161194e-01
    z[2,6,6]  R1707     -2.9800674319267273e-01
    z[2,6,6]  R1708     -2.4290467798709869e-01
    z[2,6,6]  R1709     4.6672880649566650e-02
    z[2,6,6]  R1710     -3.5432377457618713e-01
    z[2,6,6]  R1711     -1.2061487138271332e-01
    z[2,6,6]  R1712     -3.0226796865463257e-01
    z[2,6,6]  R1713     6.0109067708253860e-03
    z[2,6,6]  R1714     -1.4585968852043152e-01
    z[2,6,6]  R1715     9.1197066009044647e-02
    z[2,6,6]  R1716     1.8935346603393555e-01
    z[2,6,6]  R1717     1.8424926698207855e-01
    z[2,6,6]  R1718     -2.7470108866691589e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1719     -1
    z[6,2,0]  R1720     1
    z[6,2,0]  R1733     -4.8729193210601807e-01
    z[6,2,0]  R1734     -6.0099172592163086e-01
    z[6,2,0]  R1735     -3.2954074442386627e-02
    z[6,2,0]  R1736     7.5554296374320984e-02
    z[6,2,0]  R1737     -9.7896084189414978e-02
    z[6,2,0]  R1738     -3.8970449566841125e-01
    z[6,2,0]  R1739     1.2374044954776764e-01
    z[6,2,0]  R1740     2.8977102041244507e-01
    z[6,2,0]  R1741     -4.6530212275683880e-03
    z[6,2,0]  R1742     7.6810702681541443e-02
    z[6,2,0]  R1743     2.7076140046119690e-01
    z[6,2,0]  R1744     2.0435069501399994e-01
    z[6,2,0]  R1745     4.8351809382438660e-03
    z[6,2,0]  R1746     2.4945285916328430e-01
    z[6,2,0]  R1747     0.213861882686615
    z[6,2,0]  R1748     1.9959162175655365e-01
    z[6,2,0]  R1749     1.0795354098081589e-01
    z[6,2,0]  R1750     0.0949750691652298
    z[6,2,0]  R1751     1.0327365249395370e-01
    z[6,2,0]  R1752     -1.4315104484558105e-01
    z[6,2,0]  R1753     1.0323889553546906e-01
    z[6,2,0]  R1754     -0.086922287940979
    z[6,2,0]  R1755     4.8406824469566345e-01
    z[6,2,0]  R1756     1.0395500808954239e-02
    z[6,2,0]  R1757     -1.1849900335073471e-01
    z[6,2,0]  R1758     -4.7565117478370667e-02
    z[6,2,0]  R1759     -2.8622692823410034e-01
    z[6,2,0]  R1760     2.3305535316467285e-02
    z[6,2,0]  R1761     -1.2474393099546432e-01
    z[6,2,0]  R1762     -2.1036426723003387e-01
    z[6,2,0]  R1763     -7.6891683042049408e-02
    z[6,2,0]  R1764     9.7774147987365723e-02
    z[6,2,0]  R1765     -1.1200371384620667e-01
    z[6,2,0]  R1766     -1.0103247128427029e-02
    z[6,2,0]  R1767     1.8761040270328522e-01
    z[6,2,0]  R1768     -1.8172055482864380e-01
    z[6,2,0]  R1769     1.5545558929443359e-01
    z[6,2,0]  R1770     1.4082913100719452e-01
    z[6,2,0]  R1771     3.0249828100204468e-01
    z[6,2,0]  R1772     1.1991544812917709e-01
    z[6,2,0]  R1773     -1.2291748821735382e-01
    z[6,2,0]  R1774     2.8967265039682388e-02
    z[6,2,0]  R1775     -0.0217283982783556
    z[6,2,0]  R1776     -1.7278583347797394e-01
    z[6,2,0]  R1777     -2.3908168077468872e-02
    z[6,2,0]  R1778     -8.7013579905033112e-02
    z[6,2,0]  R1779     0.06809101998806
    z[6,2,0]  R1780     -1.0040861368179321e-01
    z[6,2,0]  R1781     -6.5120466053485870e-02
    z[6,2,0]  R1782     1.5014787018299103e-01
    z[6,2,0]  R1783     -6.3791498541831970e-02
    z[6,2,0]  R1784     1.9312863051891327e-01
    z[6,2,0]  R1785     -2.5318851694464684e-02
    z[6,2,0]  R1786     2.2771932184696198e-02
    z[6,2,0]  R1787     -3.4576624631881714e-02
    z[6,2,0]  R1788     -9.8926816135644913e-03
    z[6,2,0]  R1789     -1.0351626574993134e-01
    z[6,2,0]  R1790     1.6009204089641571e-01
    z[6,2,0]  R1791     3.1615566462278366e-02
    z[6,2,0]  R1792     -1.4451977610588074e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1721     -1
    z[6,2,1]  R1722     1
    z[6,2,1]  R1733     -3.5702398419380188e-01
    z[6,2,1]  R1734     -1.5415129065513611e-01
    z[6,2,1]  R1735     -6.7099016904830933e-01
    z[6,2,1]  R1736     -7.4068850278854370e-01
    z[6,2,1]  R1737     -5.4062509536743164e-01
    z[6,2,1]  R1738     -6.6204947233200073e-01
    z[6,2,1]  R1739     -4.0233135223388672e-01
    z[6,2,1]  R1740     -3.5219326615333557e-01
    z[6,2,1]  R1741     -2.4606880545616150e-01
    z[6,2,1]  R1742     4.4106975197792053e-01
    z[6,2,1]  R1743     -3.9074367284774780e-01
    z[6,2,1]  R1744     -3.0664929747581482e-01
    z[6,2,1]  R1745     -1.6096708178520203e-01
    z[6,2,1]  R1746     3.9459779858589172e-01
    z[6,2,1]  R1747     7.5173395872116089e-01
    z[6,2,1]  R1748     7.4822336435317993e-01
    z[6,2,1]  R1749     6.6282504796981812e-01
    z[6,2,1]  R1750     8.2198286056518555e-01
    z[6,2,1]  R1751     6.5111505985260010e-01
    z[6,2,1]  R1752     8.3069866895675659e-01
    z[6,2,1]  R1753     -4.4804677367210388e-01
    z[6,2,1]  R1754     -3.9826601743698120e-01
    z[6,2,1]  R1755     -2.6746892929077148e-01
    z[6,2,1]  R1756     9.1232210397720337e-01
    z[6,2,1]  R1757     9.3661522865295410e-01
    z[6,2,1]  R1758     7.7929776906967163e-01
    z[6,2,1]  R1759     9.1708499193191528e-01
    z[6,2,1]  R1760     -1.9481889903545380e-01
    z[6,2,1]  R1761     6.5784966945648193e-01
    z[6,2,1]  R1762     0.863397479057312
    z[6,2,1]  R1763     -5.5581796169281006e-01
    z[6,2,1]  R1764     -4.0392491221427917e-01
    z[6,2,1]  R1765     -0.71854567527771
    z[6,2,1]  R1766     -7.7100795507431030e-01
    z[6,2,1]  R1767     -9.0539109706878662e-01
    z[6,2,1]  R1768     -0.53448086977005
    z[6,2,1]  R1769     -4.0648657083511353e-01
    z[6,2,1]  R1770     -6.4921647310256958e-01
    z[6,2,1]  R1771     -4.3055734038352966e-01
    z[6,2,1]  R1772     -4.0923115611076355e-01
    z[6,2,1]  R1773     0.808269202709198
    z[6,2,1]  R1774     0.915841817855835
    z[6,2,1]  R1775     8.5408157110214233e-01
    z[6,2,1]  R1776     8.2139098644256592e-01
    z[6,2,1]  R1777     6.9976997375488281e-01
    z[6,2,1]  R1778     8.7637430429458618e-01
    z[6,2,1]  R1779     7.0686239004135132e-01
    z[6,2,1]  R1780     7.2135227918624878e-01
    z[6,2,1]  R1781     8.4297072887420654e-01
    z[6,2,1]  R1782     5.6277406215667725e-01
    z[6,2,1]  R1783     8.6787194013595581e-01
    z[6,2,1]  R1784     0.759022057056427
    z[6,2,1]  R1785     3.3177286386489868e-01
    z[6,2,1]  R1786     2.6639896631240845e-01
    z[6,2,1]  R1787     5.8427613973617554e-01
    z[6,2,1]  R1788     3.9753732085227966e-01
    z[6,2,1]  R1789     6.0654246807098389e-01
    z[6,2,1]  R1790     0.597892701625824
    z[6,2,1]  R1791     5.7512110471725464e-01
    z[6,2,1]  R1792     6.0753285884857178e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1723     -1
    z[6,2,2]  R1724     1
    z[6,2,2]  R1733     3.3122763037681580e-01
    z[6,2,2]  R1734     5.5581283569335938e-01
    z[6,2,2]  R1735     1.5156951732933521e-02
    z[6,2,2]  R1736     2.4588094651699066e-01
    z[6,2,2]  R1737     -5.8745924383401871e-02
    z[6,2,2]  R1738     4.3144565820693970e-01
    z[6,2,2]  R1739     -2.6238444447517395e-01
    z[6,2,2]  R1740     -1.4579498767852783e-01
    z[6,2,2]  R1741     2.3747770488262177e-01
    z[6,2,2]  R1742     -5.1327288150787354e-01
    z[6,2,2]  R1743     -9.1044150292873383e-02
    z[6,2,2]  R1744     -6.8464823067188263e-02
    z[6,2,2]  R1745     2.3217935115098953e-02
    z[6,2,2]  R1746     -1.6536971926689148e-01
    z[6,2,2]  R1747     8.6744002997875214e-02
    z[6,2,2]  R1748     2.3347425460815430e-01
    z[6,2,2]  R1749     -1.0240331292152405e-01
    z[6,2,2]  R1750     6.9272637367248535e-02
    z[6,2,2]  R1751     -4.7520559281110764e-02
    z[6,2,2]  R1752     2.3230488598346710e-01
    z[6,2,2]  R1753     1.0994613170623779e-01
    z[6,2,2]  R1754     5.5095762014389038e-01
    z[6,2,2]  R1755     -2.7092188596725464e-01
    z[6,2,2]  R1756     5.5401004850864410e-02
    z[6,2,2]  R1757     3.7188478745520115e-03
    z[6,2,2]  R1758     5.7915952056646347e-02
    z[6,2,2]  R1759     1.3038368523120880e-01
    z[6,2,2]  R1760     -8.4326320886611938e-01
    z[6,2,2]  R1761     -4.6066680806688964e-04
    z[6,2,2]  R1762     2.4493815004825592e-01
    z[6,2,2]  R1763     -3.6512367427349091e-02
    z[6,2,2]  R1764     -2.8309595584869385e-01
    z[6,2,2]  R1765     4.8948526382446289e-01
    z[6,2,2]  R1766     -6.1697751283645630e-02
    z[6,2,2]  R1767     -7.4687354266643524e-02
    z[6,2,2]  R1768     2.9746848344802856e-01
    z[6,2,2]  R1769     -0.0318966880440712
    z[6,2,2]  R1770     -4.6656516194343567e-01
    z[6,2,2]  R1771     -2.1023957431316376e-01
    z[6,2,2]  R1772     1.2792116403579712e-01
    z[6,2,2]  R1773     4.3497156351804733e-02
    z[6,2,2]  R1774     -2.8441622853279114e-01
    z[6,2,2]  R1775     -2.7528798580169678e-01
    z[6,2,2]  R1776     2.6707369089126587e-01
    z[6,2,2]  R1777     -3.1428366899490356e-01
    z[6,2,2]  R1778     1.5977898240089417e-01
    z[6,2,2]  R1779     4.0474005043506622e-02
    z[6,2,2]  R1780     9.6002802252769470e-02
    z[6,2,2]  R1781     -3.2728922367095947e-01
    z[6,2,2]  R1782     -2.9421791434288025e-01
    z[6,2,2]  R1783     8.5515398532152176e-03
    z[6,2,2]  R1784     -4.5370987057685852e-01
    z[6,2,2]  R1785     2.7419024705886841e-01
    z[6,2,2]  R1786     3.0780667066574097e-01
    z[6,2,2]  R1787     6.1520017683506012e-02
    z[6,2,2]  R1788     -0.297622412443161
    z[6,2,2]  R1789     -4.1597130894660950e-01
    z[6,2,2]  R1790     -1.5419314801692963e-01
    z[6,2,2]  R1791     3.0139547586441040e-01
    z[6,2,2]  R1792     -9.3728266656398773e-02
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1725     -1
    z[6,2,3]  R1726     1
    z[6,2,3]  R1733     3.4000462293624878e-01
    z[6,2,3]  R1734     4.3322449922561646e-01
    z[6,2,3]  R1735     1.7993398010730743e-01
    z[6,2,3]  R1736     4.8892334103584290e-01
    z[6,2,3]  R1737     5.5010837316513062e-01
    z[6,2,3]  R1738     1.3757245242595673e-01
    z[6,2,3]  R1739     1.3948038220405579e-01
    z[6,2,3]  R1740     5.0318348407745361e-01
    z[6,2,3]  R1741     2.5663191080093384e-01
    z[6,2,3]  R1742     5.1807653903961182e-01
    z[6,2,3]  R1743     -7.7442824840545654e-01
    z[6,2,3]  R1744     -8.5130870342254639e-01
    z[6,2,3]  R1745     -6.3003784418106079e-01
    z[6,2,3]  R1746     2.8973874449729919e-01
    z[6,2,3]  R1747     -5.4302328824996948e-01
    z[6,2,3]  R1748     -4.9294564127922058e-01
    z[6,2,3]  R1749     -4.6769458055496216e-01
    z[6,2,3]  R1750     -1.9529570639133453e-01
    z[6,2,3]  R1751     -4.9641317129135132e-01
    z[6,2,3]  R1752     1.0120025277137756e-01
    z[6,2,3]  R1753     -4.3710049986839294e-01
    z[6,2,3]  R1754     -4.9073022603988647e-01
    z[6,2,3]  R1755     -2.5777477025985718e-01
    z[6,2,3]  R1756     -1.5390133485198021e-02
    z[6,2,3]  R1757     -6.4651072025299072e-02
    z[6,2,3]  R1758     2.9587191343307495e-01
    z[6,2,3]  R1759     -1.4695847034454346e-01
    z[6,2,3]  R1760     -0.332194447517395
    z[6,2,3]  R1761     1.6896338760852814e-01
    z[6,2,3]  R1762     -1.7404754459857941e-01
    z[6,2,3]  R1763     -5.7133636437356472e-03
    z[6,2,3]  R1764     6.0302615165710449e-02
    z[6,2,3]  R1765     4.3359076976776123e-01
    z[6,2,3]  R1766     4.4179043173789978e-01
    z[6,2,3]  R1767     -2.4320727214217186e-02
    z[6,2,3]  R1768     -1.8579587340354919e-01
    z[6,2,3]  R1769     1.1626062542200089e-01
    z[6,2,3]  R1770     5.6650150567293167e-02
    z[6,2,3]  R1771     2.9676252603530884e-01
    z[6,2,3]  R1772     -5.9717226773500443e-02
    z[6,2,3]  R1773     3.2643941044807434e-01
    z[6,2,3]  R1774     1.9942989945411682e-01
    z[6,2,3]  R1775     -1.4164198935031891e-01
    z[6,2,3]  R1776     -6.9845512509346008e-02
    z[6,2,3]  R1777     1.9365318119525909e-01
    z[6,2,3]  R1778     3.1281337141990662e-01
    z[6,2,3]  R1779     1.5215082466602325e-01
    z[6,2,3]  R1780     3.1471386551856995e-01
    z[6,2,3]  R1781     -2.0695790648460388e-01
    z[6,2,3]  R1782     -1.8547067046165466e-01
    z[6,2,3]  R1783     -3.7688681483268738e-01
    z[6,2,3]  R1784     -1.6205094754695892e-02
    z[6,2,3]  R1785     6.4295977354049683e-01
    z[6,2,3]  R1786     7.9940801858901978e-01
    z[6,2,3]  R1787     5.2079373598098755e-01
    z[6,2,3]  R1788     7.0280265808105469e-01
    z[6,2,3]  R1789     -4.1959017515182495e-01
    z[6,2,3]  R1790     6.6072773933410645e-01
    z[6,2,3]  R1791     -1.7309138178825378e-01
    z[6,2,3]  R1792     3.5341003537178040e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1727     -1
    z[6,2,4]  R1728     1
    z[6,2,4]  R1733     -4.6212986111640930e-01
    z[6,2,4]  R1734     -1.0306835174560547e-01
    z[6,2,4]  R1735     2.4907572567462921e-01
    z[6,2,4]  R1736     3.5415120422840118e-02
    z[6,2,4]  R1737     2.5946739315986633e-01
    z[6,2,4]  R1738     3.1383502483367920e-01
    z[6,2,4]  R1739     -6.5896719694137573e-01
    z[6,2,4]  R1740     -0.596753716468811
    z[6,2,4]  R1741     -6.1668014526367188e-01
    z[6,2,4]  R1742     -0.358946830034256
    z[6,2,4]  R1743     6.9367498159408569e-02
    z[6,2,4]  R1744     -0.0192574355751276
    z[6,2,4]  R1745     5.4983311891555786e-01
    z[6,2,4]  R1746     7.6512259244918823e-01
    z[6,2,4]  R1747     1.8830262124538422e-02
    z[6,2,4]  R1748     1.5435796976089478e-01
    z[6,2,4]  R1749     4.5882749557495117e-01
    z[6,2,4]  R1750     -4.8992950469255447e-02
    z[6,2,4]  R1751     2.2206287086009979e-01
    z[6,2,4]  R1752     0.18660868704319
    z[6,2,4]  R1753     -2.0885774865746498e-02
    z[6,2,4]  R1754     -6.6024191677570343e-02
    z[6,2,4]  R1755     5.5955165624618530e-01
    z[6,2,4]  R1756     1.1262305080890656e-01
    z[6,2,4]  R1757     2.5707712769508362e-01
    z[6,2,4]  R1758     1.4648343622684479e-01
    z[6,2,4]  R1759     4.4894441962242126e-02
    z[6,2,4]  R1760     0.320562481880188
    z[6,2,4]  R1761     4.6578127145767212e-01
    z[6,2,4]  R1762     1.7981793731451035e-02
    z[6,2,4]  R1763     -3.4494879841804504e-01
    z[6,2,4]  R1764     -6.2019479274749756e-01
    z[6,2,4]  R1765     -1.2619766592979431e-01
    z[6,2,4]  R1766     1.2386779487133026e-01
    z[6,2,4]  R1767     1.1356448382139206e-01
    z[6,2,4]  R1768     -0.685459315776825
    z[6,2,4]  R1769     -1.7781707644462585e-01
    z[6,2,4]  R1770     -5.6831365823745728e-01
    z[6,2,4]  R1771     -8.9890755712985992e-02
    z[6,2,4]  R1772     -0.570176362991333
    z[6,2,4]  R1773     -5.1463317126035690e-02
    z[6,2,4]  R1774     4.9570216797292233e-03
    z[6,2,4]  R1775     -2.1611016988754272e-01
    z[6,2,4]  R1776     3.0435770750045776e-01
    z[6,2,4]  R1777     3.5316145420074463e-01
    z[6,2,4]  R1778     2.9572373628616333e-01
    z[6,2,4]  R1779     4.7489190101623535e-01
    z[6,2,4]  R1780     5.1569879055023193e-01
    z[6,2,4]  R1781     -2.3159846663475037e-01
    z[6,2,4]  R1782     6.1637425422668457e-01
    z[6,2,4]  R1783     -2.5623646378517151e-01
    z[6,2,4]  R1784     2.5742354989051819e-01
    z[6,2,4]  R1785     3.6368942260742188e-01
    z[6,2,4]  R1786     -2.6839458942413330e-01
    z[6,2,4]  R1787     -0.610956072807312
    z[6,2,4]  R1788     -2.6510828733444214e-01
    z[6,2,4]  R1789     7.2587326169013977e-02
    z[6,2,4]  R1790     -2.4104593694210052e-01
    z[6,2,4]  R1791     0.389614462852478
    z[6,2,4]  R1792     -4.4050836563110352e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1729     -1
    z[6,2,5]  R1730     1
    z[6,2,5]  R1733     3.5383099317550659e-01
    z[6,2,5]  R1734     0.298246830701828
    z[6,2,5]  R1735     6.6604816913604736e-01
    z[6,2,5]  R1736     1.4240823686122894e-01
    z[6,2,5]  R1737     -3.3883821964263916e-01
    z[6,2,5]  R1738     2.1826688945293427e-01
    z[6,2,5]  R1739     5.4729700088500977e-01
    z[6,2,5]  R1740     -2.7310594916343689e-01
    z[6,2,5]  R1741     4.3495544791221619e-01
    z[6,2,5]  R1742     2.6600891351699829e-01
    z[6,2,5]  R1743     -2.7356579899787903e-01
    z[6,2,5]  R1744     -0.362730473279953
    z[6,2,5]  R1745     -0.503667414188385
    z[6,2,5]  R1746     1.2624172866344452e-01
    z[6,2,5]  R1747     -2.6105238124728203e-02
    z[6,2,5]  R1748     -2.7103149890899658e-01
    z[6,2,5]  R1749     -1.5463612973690033e-01
    z[6,2,5]  R1750     -3.1710001826286316e-01
    z[6,2,5]  R1751     4.2258673906326294e-01
    z[6,2,5]  R1752     -3.6251193284988403e-01
    z[6,2,5]  R1753     -7.6343721151351929e-01
    z[6,2,5]  R1754     -3.9944148063659668e-01
    z[6,2,5]  R1755     -4.7607335448265076e-01
    z[6,2,5]  R1756     -2.4536564946174622e-01
    z[6,2,5]  R1757     -1.9593752920627594e-01
    z[6,2,5]  R1758     -5.0675994157791138e-01
    z[6,2,5]  R1759     -1.6763083636760712e-01
    z[6,2,5]  R1760     -3.7964764982461929e-02
    z[6,2,5]  R1761     -5.2175086736679077e-01
    z[6,2,5]  R1762     2.1028614044189453e-01
    z[6,2,5]  R1763     7.3272442817687988e-01
    z[6,2,5]  R1764     5.7743382453918457e-01
    z[6,2,5]  R1765     -1.1910753697156906e-01
    z[6,2,5]  R1766     9.9070534110069275e-02
    z[6,2,5]  R1767     1.4756646752357483e-01
    z[6,2,5]  R1768     2.8583604097366333e-01
    z[6,2,5]  R1769     7.0279783010482788e-01
    z[6,2,5]  R1770     -5.8415614068508148e-02
    z[6,2,5]  R1771     4.1297596693038940e-01
    z[6,2,5]  R1772     2.5528600811958313e-01
    z[6,2,5]  R1773     4.4018706679344177e-01
    z[6,2,5]  R1774     1.9469425082206726e-01
    z[6,2,5]  R1775     3.5704341530799866e-01
    z[6,2,5]  R1776     3.5296735167503357e-01
    z[6,2,5]  R1777     3.7022951245307922e-01
    z[6,2,5]  R1778     -6.9216839969158173e-02
    z[6,2,5]  R1779     3.6752417683601379e-01
    z[6,2,5]  R1780     1.9860202074050903e-01
    z[6,2,5]  R1781     -8.5678435862064362e-02
    z[6,2,5]  R1782     3.0596208572387695e-01
    z[6,2,5]  R1783     3.2019170466810465e-03
    z[6,2,5]  R1784     -2.9590100049972534e-01
    z[6,2,5]  R1785     5.0767010450363159e-01
    z[6,2,5]  R1786     1.7190322279930115e-01
    z[6,2,5]  R1787     6.0550201684236526e-02
    z[6,2,5]  R1788     1.5664808452129364e-01
    z[6,2,5]  R1789     8.2535691559314728e-02
    z[6,2,5]  R1790     -1.4474037289619446e-01
    z[6,2,5]  R1791     -4.6410274505615234e-01
    z[6,2,5]  R1792     -2.1927395462989807e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1731     -1
    z[6,2,6]  R1732     1
    z[6,2,6]  R1733     2.6646783947944641e-01
    z[6,2,6]  R1734     1.3733452558517456e-01
    z[6,2,6]  R1735     1.0208512842655182e-01
    z[6,2,6]  R1736     -3.5303589701652527e-01
    z[6,2,6]  R1737     4.5818752050399780e-01
    z[6,2,6]  R1738     0.242108553647995
    z[6,2,6]  R1739     2.7308214455842972e-02
    z[6,2,6]  R1740     -2.9468801617622375e-01
    z[6,2,6]  R1741     -4.9768692255020142e-01
    z[6,2,6]  R1742     2.6096296310424805e-01
    z[6,2,6]  R1743     -2.9381856322288513e-01
    z[6,2,6]  R1744     5.3373958915472031e-02
    z[6,2,6]  R1745     -1.4346466958522797e-01
    z[6,2,6]  R1746     -2.6347804069519043e-01
    z[6,2,6]  R1747     -2.9278692603111267e-01
    z[6,2,6]  R1748     -7.4396848678588867e-02
    z[6,2,6]  R1749     2.9214599728584290e-01
    z[6,2,6]  R1750     -4.1162124276161194e-01
    z[6,2,6]  R1751     -2.9800674319267273e-01
    z[6,2,6]  R1752     -2.4290467798709869e-01
    z[6,2,6]  R1753     4.6672880649566650e-02
    z[6,2,6]  R1754     -3.5432377457618713e-01
    z[6,2,6]  R1755     -1.2061487138271332e-01
    z[6,2,6]  R1756     -3.0226796865463257e-01
    z[6,2,6]  R1757     6.0109067708253860e-03
    z[6,2,6]  R1758     -1.4585968852043152e-01
    z[6,2,6]  R1759     9.1197066009044647e-02
    z[6,2,6]  R1760     1.8935346603393555e-01
    z[6,2,6]  R1761     1.8424926698207855e-01
    z[6,2,6]  R1762     -2.7470108866691589e-01
    z[6,2,6]  R1763     1.6707342863082886e-01
    z[6,2,6]  R1764     -1.5947981178760529e-01
    z[6,2,6]  R1765     1.1592247337102890e-01
    z[6,2,6]  R1766     4.2579475045204163e-01
    z[6,2,6]  R1767     -3.2284185290336609e-01
    z[6,2,6]  R1768     8.2118771970272064e-02
    z[6,2,6]  R1769     -5.2011966705322266e-01
    z[6,2,6]  R1770     0.106770820915699
    z[6,2,6]  R1771     -6.4204132556915283e-01
    z[6,2,6]  R1772     -0.638708233833313
    z[6,2,6]  R1773     1.6347558796405792e-01
    z[6,2,6]  R1774     4.2418867349624634e-02
    z[6,2,6]  R1775     6.5617696382105350e-03
    z[6,2,6]  R1776     4.5117955654859543e-02
    z[6,2,6]  R1777     3.3418801426887512e-01
    z[6,2,6]  R1778     9.3657158315181732e-02
    z[6,2,6]  R1779     -3.3215171098709106e-01
    z[6,2,6]  R1780     2.3647336661815643e-01
    z[6,2,6]  R1781     2.7245423197746277e-01
    z[6,2,6]  R1782     -0.257385790348053
    z[6,2,6]  R1783     -1.8693499267101288e-01
    z[6,2,6]  R1784     -1.6323995590209961e-01
    z[6,2,6]  R1785     -1.0348517447710037e-01
    z[6,2,6]  R1786     -3.0516979098320007e-01
    z[6,2,6]  R1787     -7.4036069214344025e-02
    z[6,2,6]  R1788     4.0562847256660461e-01
    z[6,2,6]  R1789     5.1011914014816284e-01
    z[6,2,6]  R1790     -2.7839767932891846e-01
    z[6,2,6]  R1791     -4.2455330491065979e-01
    z[6,2,6]  R1792     4.8394781351089478e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1793     -1
    z[3,6,0]  R1794     1
    z[3,6,0]  R1807     3.6170229315757751e-01
    z[3,6,0]  R1808     1.6324986517429352e-01
    z[3,6,0]  R1809     -4.1269157081842422e-02
    z[3,6,0]  R1810     1.2358608096837997e-01
    z[3,6,0]  R1811     -2.3048009723424911e-02
    z[3,6,0]  R1812     1.8776720762252808e-01
    z[3,6,0]  R1813     -1.5722067654132843e-01
    z[3,6,0]  R1814     -9.7374036908149719e-02
    z[3,6,0]  R1815     -1.9575388729572296e-01
    z[3,6,0]  R1816     9.2036321759223938e-02
    z[3,6,0]  R1817     -3.2675590366125107e-02
    z[3,6,0]  R1818     -3.6611091345548630e-02
    z[3,6,0]  R1819     -2.2188383340835571e-01
    z[3,6,0]  R1820     -1.9630396738648415e-02
    z[3,6,0]  R1821     1.5862879157066345e-01
    z[3,6,0]  R1822     1.8542206287384033e-01
    z[3,6,0]  R1823     1.9136006012558937e-02
    z[3,6,0]  R1824     4.1606724262237549e-01
    z[3,6,0]  R1825     2.1164511144161224e-01
    z[3,6,0]  R1826     2.6832106709480286e-01
    z[3,6,0]  R1827     1.8306382000446320e-01
    z[3,6,0]  R1828     3.1629450619220734e-02
    z[3,6,0]  R1829     6.9233119487762451e-02
    z[3,6,0]  R1830     -8.5436977446079254e-02
    z[3,6,0]  R1831     -6.9607138633728027e-01
    z[3,6,0]  R1832     -3.7381795048713684e-01
    z[3,6,0]  R1833     -5.0426310300827026e-01
    z[3,6,0]  R1834     -7.4039585888385773e-02
    z[3,6,0]  R1835     1.8637432157993317e-01
    z[3,6,0]  R1836     1.1229066550731659e-01
    z[3,6,0]  R1837     3.1533634662628174e-01
    z[3,6,0]  R1838     -3.6027842760086060e-01
    z[3,6,0]  R1839     4.6952001750469208e-02
    z[3,6,0]  R1840     3.3584558963775635e-01
    z[3,6,0]  R1841     -1.8386675417423248e-01
    z[3,6,0]  R1842     1.9078862667083740e-01
    z[3,6,0]  R1843     -5.7934051752090454e-01
    z[3,6,0]  R1844     2.6301616430282593e-01
    z[3,6,0]  R1845     -7.2893661260604858e-01
    z[3,6,0]  R1846     1.1756321042776108e-01
    z[3,6,0]  R1847     -2.0802223682403564e-01
    z[3,6,0]  R1848     -3.6427670717239380e-01
    z[3,6,0]  R1849     -9.3302980065345764e-02
    z[3,6,0]  R1850     -8.6929149925708771e-02
    z[3,6,0]  R1851     4.3205675482749939e-01
    z[3,6,0]  R1852     0.0286989975720644
    z[3,6,0]  R1853     2.3792499303817749e-01
    z[3,6,0]  R1854     4.8042505979537964e-01
    z[3,6,0]  R1855     1.2228551506996155e-01
    z[3,6,0]  R1856     1.5694823861122131e-01
    z[3,6,0]  R1857     3.7377968430519104e-01
    z[3,6,0]  R1858     5.0766885280609131e-01
    z[3,6,0]  R1859     2.6414486765861511e-01
    z[3,6,0]  R1860     4.0131795406341553e-01
    z[3,6,0]  R1861     -4.0726464986801147e-01
    z[3,6,0]  R1862     -2.2311198711395264e-01
    z[3,6,0]  R1863     -5.9472423791885376e-01
    z[3,6,0]  R1864     -3.7742203567177057e-03
    z[3,6,0]  R1865     -4.8729193210601807e-01
    z[3,6,0]  R1866     -6.0099172592163086e-01
    z[3,6,0]  R1867     -3.2954074442386627e-02
    z[3,6,0]  R1868     7.5554296374320984e-02
    z[3,6,0]  R1869     -9.7896084189414978e-02
    z[3,6,0]  R1870     -3.8970449566841125e-01
    z[3,6,0]  R1871     1.2374044954776764e-01
    z[3,6,0]  R1872     2.8977102041244507e-01
    z[3,6,0]  R1873     -4.6530212275683880e-03
    z[3,6,0]  R1874     7.6810702681541443e-02
    z[3,6,0]  R1875     2.7076140046119690e-01
    z[3,6,0]  R1876     2.0435069501399994e-01
    z[3,6,0]  R1877     4.8351809382438660e-03
    z[3,6,0]  R1878     2.4945285916328430e-01
    z[3,6,0]  R1879     0.213861882686615
    z[3,6,0]  R1880     1.9959162175655365e-01
    z[3,6,0]  R1881     1.0795354098081589e-01
    z[3,6,0]  R1882     0.0949750691652298
    z[3,6,0]  R1883     1.0327365249395370e-01
    z[3,6,0]  R1884     -1.4315104484558105e-01
    z[3,6,0]  R1885     1.0323889553546906e-01
    z[3,6,0]  R1886     -0.086922287940979
    z[3,6,0]  R1887     4.8406824469566345e-01
    z[3,6,0]  R1888     1.0395500808954239e-02
    z[3,6,0]  R1889     -1.1849900335073471e-01
    z[3,6,0]  R1890     -4.7565117478370667e-02
    z[3,6,0]  R1891     -2.8622692823410034e-01
    z[3,6,0]  R1892     2.3305535316467285e-02
    z[3,6,0]  R1893     -1.2474393099546432e-01
    z[3,6,0]  R1894     -2.1036426723003387e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1795     -1
    z[3,6,1]  R1796     1
    z[3,6,1]  R1807     -0.806343674659729
    z[3,6,1]  R1808     -7.4787521362304688e-01
    z[3,6,1]  R1809     -5.4697972536087036e-01
    z[3,6,1]  R1810     -7.7965390682220459e-01
    z[3,6,1]  R1811     -6.1561739444732666e-01
    z[3,6,1]  R1812     -6.6225737333297729e-01
    z[3,6,1]  R1813     -7.7129900455474854e-01
    z[3,6,1]  R1814     -6.8135350942611694e-01
    z[3,6,1]  R1815     -5.6042784452438354e-01
    z[3,6,1]  R1816     -3.6967614293098450e-01
    z[3,6,1]  R1817     5.6595337390899658e-01
    z[3,6,1]  R1818     5.1366031169891357e-01
    z[3,6,1]  R1819     5.6661015748977661e-01
    z[3,6,1]  R1820     5.9830093383789062e-01
    z[3,6,1]  R1821     6.0357969999313354e-01
    z[3,6,1]  R1822     8.0633997917175293e-01
    z[3,6,1]  R1823     9.2627406120300293e-01
    z[3,6,1]  R1824     6.8232113122940063e-01
    z[3,6,1]  R1825     7.1411836147308350e-01
    z[3,6,1]  R1826     6.5283042192459106e-01
    z[3,6,1]  R1827     2.1240106225013733e-01
    z[3,6,1]  R1828     1.2077067792415619e-01
    z[3,6,1]  R1829     3.3731155097484589e-02
    z[3,6,1]  R1830     -4.0616673231124878e-01
    z[3,6,1]  R1831     -9.4405815005302429e-02
    z[3,6,1]  R1832     -2.6088034734129906e-02
    z[3,6,1]  R1833     -3.3746039867401123e-01
    z[3,6,1]  R1834     4.0909877419471741e-01
    z[3,6,1]  R1835     6.6235578060150146e-01
    z[3,6,1]  R1836     7.8362166881561279e-01
    z[3,6,1]  R1837     1.4579404890537262e-01
    z[3,6,1]  R1838     -7.1627922356128693e-02
    z[3,6,1]  R1839     3.8499668240547180e-02
    z[3,6,1]  R1840     -1.4943755231797695e-02
    z[3,6,1]  R1841     -1.2556684203445911e-02
    z[3,6,1]  R1842     2.5044474005699158e-01
    z[3,6,1]  R1843     -4.3855917453765869e-01
    z[3,6,1]  R1844     7.7784001827239990e-01
    z[3,6,1]  R1845     -3.8717139512300491e-02
    z[3,6,1]  R1846     -5.4183810949325562e-01
    z[3,6,1]  R1847     -7.7265053987503052e-01
    z[3,6,1]  R1848     2.3995118215680122e-02
    z[3,6,1]  R1849     8.0874115228652954e-02
    z[3,6,1]  R1850     -5.1484964787960052e-03
    z[3,6,1]  R1851     -3.8053739070892334e-01
    z[3,6,1]  R1852     8.0667048692703247e-01
    z[3,6,1]  R1853     7.8709441423416138e-01
    z[3,6,1]  R1854     6.7205429077148438e-01
    z[3,6,1]  R1855     0.721260130405426
    z[3,6,1]  R1856     7.9820042848587036e-01
    z[3,6,1]  R1857     -3.7496453523635864e-01
    z[3,6,1]  R1858     -2.9170952737331390e-02
    z[3,6,1]  R1859     7.6787370443344116e-01
    z[3,6,1]  R1860     4.9740001559257507e-01
    z[3,6,1]  R1861     6.7751801013946533e-01
    z[3,6,1]  R1862     -2.4190092086791992e-01
    z[3,6,1]  R1863     4.2945200204849243e-01
    z[3,6,1]  R1864     2.6404294371604919e-01
    z[3,6,1]  R1865     -3.5702398419380188e-01
    z[3,6,1]  R1866     -1.5415129065513611e-01
    z[3,6,1]  R1867     -6.7099016904830933e-01
    z[3,6,1]  R1868     -7.4068850278854370e-01
    z[3,6,1]  R1869     -5.4062509536743164e-01
    z[3,6,1]  R1870     -6.6204947233200073e-01
    z[3,6,1]  R1871     -4.0233135223388672e-01
    z[3,6,1]  R1872     -3.5219326615333557e-01
    z[3,6,1]  R1873     -2.4606880545616150e-01
    z[3,6,1]  R1874     4.4106975197792053e-01
    z[3,6,1]  R1875     -3.9074367284774780e-01
    z[3,6,1]  R1876     -3.0664929747581482e-01
    z[3,6,1]  R1877     -1.6096708178520203e-01
    z[3,6,1]  R1878     3.9459779858589172e-01
    z[3,6,1]  R1879     7.5173395872116089e-01
    z[3,6,1]  R1880     7.4822336435317993e-01
    z[3,6,1]  R1881     6.6282504796981812e-01
    z[3,6,1]  R1882     8.2198286056518555e-01
    z[3,6,1]  R1883     6.5111505985260010e-01
    z[3,6,1]  R1884     8.3069866895675659e-01
    z[3,6,1]  R1885     -4.4804677367210388e-01
    z[3,6,1]  R1886     -3.9826601743698120e-01
    z[3,6,1]  R1887     -2.6746892929077148e-01
    z[3,6,1]  R1888     9.1232210397720337e-01
    z[3,6,1]  R1889     9.3661522865295410e-01
    z[3,6,1]  R1890     7.7929776906967163e-01
    z[3,6,1]  R1891     9.1708499193191528e-01
    z[3,6,1]  R1892     -1.9481889903545380e-01
    z[3,6,1]  R1893     6.5784966945648193e-01
    z[3,6,1]  R1894     0.863397479057312
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1797     -1
    z[3,6,2]  R1798     1
    z[3,6,2]  R1807     -4.0706697106361389e-01
    z[3,6,2]  R1808     2.7609580755233765e-01
    z[3,6,2]  R1809     -1.5832577645778656e-01
    z[3,6,2]  R1810     -2.0530427992343903e-01
    z[3,6,2]  R1811     -2.1107414364814758e-01
    z[3,6,2]  R1812     -1.9327521324157715e-01
    z[3,6,2]  R1813     -2.5243712589144707e-02
    z[3,6,2]  R1814     -2.3439349234104156e-01
    z[3,6,2]  R1815     9.7869625315070152e-03
    z[3,6,2]  R1816     1.3684664852917194e-02
    z[3,6,2]  R1817     -0.608640730381012
    z[3,6,2]  R1818     -6.2675130367279053e-01
    z[3,6,2]  R1819     -4.3944120407104492e-01
    z[3,6,2]  R1820     -4.6132189035415649e-01
    z[3,6,2]  R1821     -5.5187779664993286e-01
    z[3,6,2]  R1822     -4.5976600050926208e-01
    z[3,6,2]  R1823     -3.1907999515533447e-01
    z[3,6,2]  R1824     -5.5827200412750244e-01
    z[3,6,2]  R1825     -3.4449258446693420e-01
    z[3,6,2]  R1826     -0.47967329621315
    z[3,6,2]  R1827     3.5087114572525024e-01
    z[3,6,2]  R1828     -1.4752382040023804e-01
    z[3,6,2]  R1829     2.0647323690354824e-03
    z[3,6,2]  R1830     5.1708000898361206e-01
    z[3,6,2]  R1831     -3.9517989754676819e-01
    z[3,6,2]  R1832     -3.5510140657424927e-01
    z[3,6,2]  R1833     6.6694790124893188e-01
    z[3,6,2]  R1834     5.2773706614971161e-02
    z[3,6,2]  R1835     2.2508682310581207e-01
    z[3,6,2]  R1836     3.2976818084716797e-01
    z[3,6,2]  R1837     -1.6189638525247574e-02
    z[3,6,2]  R1838     -2.3209549486637115e-02
    z[3,6,2]  R1839     4.3543872237205505e-01
    z[3,6,2]  R1840     -4.9028575420379639e-01
    z[3,6,2]  R1841     5.7964944839477539e-01
    z[3,6,2]  R1842     -2.1978507936000824e-01
    z[3,6,2]  R1843     6.2940829992294312e-01
    z[3,6,2]  R1844     -4.6362683176994324e-01
    z[3,6,2]  R1845     -1.1675927042961121e-01
    z[3,6,2]  R1846     3.5269770771265030e-02
    z[3,6,2]  R1847     1.3527289032936096e-01
    z[3,6,2]  R1848     1.5156303346157074e-01
    z[3,6,2]  R1849     4.1148793697357178e-01
    z[3,6,2]  R1850     1.2999449670314789e-01
    z[3,6,2]  R1851     2.2236153483390808e-02
    z[3,6,2]  R1852     -2.7773118019104004e-01
    z[3,6,2]  R1853     2.0093873143196106e-01
    z[3,6,2]  R1854     -8.3115048706531525e-02
    z[3,6,2]  R1855     9.2648655176162720e-02
    z[3,6,2]  R1856     2.6972818374633789e-01
    z[3,6,2]  R1857     -9.5397032797336578e-02
    z[3,6,2]  R1858     -6.7495889961719513e-02
    z[3,6,2]  R1859     1.4342764019966125e-01
    z[3,6,2]  R1860     -2.6181939244270325e-01
    z[3,6,2]  R1861     4.7308516502380371e-01
    z[3,6,2]  R1862     -8.9823201298713684e-02
    z[3,6,2]  R1863     2.9901077970862389e-02
    z[3,6,2]  R1864     2.3564234375953674e-01
    z[3,6,2]  R1865     3.3122763037681580e-01
    z[3,6,2]  R1866     5.5581283569335938e-01
    z[3,6,2]  R1867     1.5156951732933521e-02
    z[3,6,2]  R1868     2.4588094651699066e-01
    z[3,6,2]  R1869     -5.8745924383401871e-02
    z[3,6,2]  R1870     4.3144565820693970e-01
    z[3,6,2]  R1871     -2.6238444447517395e-01
    z[3,6,2]  R1872     -1.4579498767852783e-01
    z[3,6,2]  R1873     2.3747770488262177e-01
    z[3,6,2]  R1874     -5.1327288150787354e-01
    z[3,6,2]  R1875     -9.1044150292873383e-02
    z[3,6,2]  R1876     -6.8464823067188263e-02
    z[3,6,2]  R1877     2.3217935115098953e-02
    z[3,6,2]  R1878     -1.6536971926689148e-01
    z[3,6,2]  R1879     8.6744002997875214e-02
    z[3,6,2]  R1880     2.3347425460815430e-01
    z[3,6,2]  R1881     -1.0240331292152405e-01
    z[3,6,2]  R1882     6.9272637367248535e-02
    z[3,6,2]  R1883     -4.7520559281110764e-02
    z[3,6,2]  R1884     2.3230488598346710e-01
    z[3,6,2]  R1885     1.0994613170623779e-01
    z[3,6,2]  R1886     5.5095762014389038e-01
    z[3,6,2]  R1887     -2.7092188596725464e-01
    z[3,6,2]  R1888     5.5401004850864410e-02
    z[3,6,2]  R1889     3.7188478745520115e-03
    z[3,6,2]  R1890     5.7915952056646347e-02
    z[3,6,2]  R1891     1.3038368523120880e-01
    z[3,6,2]  R1892     -8.4326320886611938e-01
    z[3,6,2]  R1893     -4.6066680806688964e-04
    z[3,6,2]  R1894     2.4493815004825592e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1799     -1
    z[3,6,3]  R1800     1
    z[3,6,3]  R1807     6.1551958322525024e-02
    z[3,6,3]  R1808     4.7896894812583923e-01
    z[3,6,3]  R1809     2.5067204236984253e-01
    z[3,6,3]  R1810     4.6751942485570908e-02
    z[3,6,3]  R1811     1.4026145637035370e-01
    z[3,6,3]  R1812     1.5647675096988678e-01
    z[3,6,3]  R1813     1.7780081927776337e-01
    z[3,6,3]  R1814     -1.3124364614486694e-01
    z[3,6,3]  R1815     1.5760404989123344e-02
    z[3,6,3]  R1816     2.5649723410606384e-01
    z[3,6,3]  R1817     2.4812524020671844e-01
    z[3,6,3]  R1818     3.5732197761535645e-01
    z[3,6,3]  R1819     4.4686308503150940e-01
    z[3,6,3]  R1820     1.5797902643680573e-01
    z[3,6,3]  R1821     2.2483283281326294e-01
    z[3,6,3]  R1822     5.8787297457456589e-03
    z[3,6,3]  R1823     -5.5460810661315918e-02
    z[3,6,3]  R1824     1.8514537811279297e-01
    z[3,6,3]  R1825     5.3036159276962280e-01
    z[3,6,3]  R1826     -2.1677853539586067e-02
    z[3,6,3]  R1827     6.0600304603576660e-01
    z[3,6,3]  R1828     5.8472746610641479e-01
    z[3,6,3]  R1829     6.8398469686508179e-01
    z[3,6,3]  R1830     -3.9802172780036926e-01
    z[3,6,3]  R1831     5.8413773775100708e-01
    z[3,6,3]  R1832     8.2769459486007690e-01
    z[3,6,3]  R1833     -3.2512679696083069e-01
    z[3,6,3]  R1834     7.4470067024230957e-01
    z[3,6,3]  R1835     -5.3577250242233276e-01
    z[3,6,3]  R1836     -8.4929518401622772e-02
    z[3,6,3]  R1837     8.5579985380172729e-01
    z[3,6,3]  R1838     7.4300438165664673e-01
    z[3,6,3]  R1839     6.4403080940246582e-01
    z[3,6,3]  R1840     6.7152398824691772e-01
    z[3,6,3]  R1841     5.8258867263793945e-01
    z[3,6,3]  R1842     8.9625442028045654e-01
    z[3,6,3]  R1843     -2.3738366365432739e-01
    z[3,6,3]  R1844     1.0044626891613007e-01
    z[3,6,3]  R1845     1.3373105227947235e-01
    z[3,6,3]  R1846     -4.7404131293296814e-01
    z[3,6,3]  R1847     2.4768961966037750e-01
    z[3,6,3]  R1848     7.8221571445465088e-01
    z[3,6,3]  R1849     5.4474240541458130e-01
    z[3,6,3]  R1850     8.0291819572448730e-01
    z[3,6,3]  R1851     -1.3453532755374908e-01
    z[3,6,3]  R1852     -3.0108213424682617e-01
    z[3,6,3]  R1853     -4.1620391607284546e-01
    z[3,6,3]  R1854     -1.4135645329952240e-01
    z[3,6,3]  R1855     -2.6950651407241821e-01
    z[3,6,3]  R1856     -0.0194667000323534
    z[3,6,3]  R1857     5.1125931739807129e-01
    z[3,6,3]  R1858     5.4380977153778076e-01
    z[3,6,3]  R1859     -4.5670115947723389e-01
    z[3,6,3]  R1860     2.3274455219507217e-02
    z[3,6,3]  R1861     -3.3306321501731873e-01
    z[3,6,3]  R1862     -8.4590435028076172e-01
    z[3,6,3]  R1863     -0.573287844657898
    z[3,6,3]  R1864     -7.3486495018005371e-01
    z[3,6,3]  R1865     3.4000462293624878e-01
    z[3,6,3]  R1866     4.3322449922561646e-01
    z[3,6,3]  R1867     1.7993398010730743e-01
    z[3,6,3]  R1868     4.8892334103584290e-01
    z[3,6,3]  R1869     5.5010837316513062e-01
    z[3,6,3]  R1870     1.3757245242595673e-01
    z[3,6,3]  R1871     1.3948038220405579e-01
    z[3,6,3]  R1872     5.0318348407745361e-01
    z[3,6,3]  R1873     2.5663191080093384e-01
    z[3,6,3]  R1874     5.1807653903961182e-01
    z[3,6,3]  R1875     -7.7442824840545654e-01
    z[3,6,3]  R1876     -8.5130870342254639e-01
    z[3,6,3]  R1877     -6.3003784418106079e-01
    z[3,6,3]  R1878     2.8973874449729919e-01
    z[3,6,3]  R1879     -5.4302328824996948e-01
    z[3,6,3]  R1880     -4.9294564127922058e-01
    z[3,6,3]  R1881     -4.6769458055496216e-01
    z[3,6,3]  R1882     -1.9529570639133453e-01
    z[3,6,3]  R1883     -4.9641317129135132e-01
    z[3,6,3]  R1884     1.0120025277137756e-01
    z[3,6,3]  R1885     -4.3710049986839294e-01
    z[3,6,3]  R1886     -4.9073022603988647e-01
    z[3,6,3]  R1887     -2.5777477025985718e-01
    z[3,6,3]  R1888     -1.5390133485198021e-02
    z[3,6,3]  R1889     -6.4651072025299072e-02
    z[3,6,3]  R1890     2.9587191343307495e-01
    z[3,6,3]  R1891     -1.4695847034454346e-01
    z[3,6,3]  R1892     -0.332194447517395
    z[3,6,3]  R1893     1.6896338760852814e-01
    z[3,6,3]  R1894     -1.7404754459857941e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1801     -1
    z[3,6,4]  R1802     1
    z[3,6,4]  R1807     -9.3001998960971832e-02
    z[3,6,4]  R1808     -0.243952676653862
    z[3,6,4]  R1809     -2.0971670746803284e-01
    z[3,6,4]  R1810     2.3346078395843506e-01
    z[3,6,4]  R1811     -6.7958253622055054e-01
    z[3,6,4]  R1812     -3.7784937024116516e-01
    z[3,6,4]  R1813     -4.1286323219537735e-02
    z[3,6,4]  R1814     8.5462033748626709e-02
    z[3,6,4]  R1815     2.0253455638885498e-01
    z[3,6,4]  R1816     -5.8184742927551270e-01
    z[3,6,4]  R1817     5.2968215197324753e-02
    z[3,6,4]  R1818     0.19495889544487
    z[3,6,4]  R1819     1.6109964251518250e-01
    z[3,6,4]  R1820     4.7200888395309448e-01
    z[3,6,4]  R1821     3.9044788479804993e-01
    z[3,6,4]  R1822     -4.2544011026620865e-02
    z[3,6,4]  R1823     -4.1648335754871368e-02
    z[3,6,4]  R1824     3.6156203597784042e-02
    z[3,6,4]  R1825     2.1014837920665741e-01
    z[3,6,4]  R1826     4.9418565630912781e-01
    z[3,6,4]  R1827     4.8908448219299316e-01
    z[3,6,4]  R1828     7.0103943347930908e-01
    z[3,6,4]  R1829     0.702874481678009
    z[3,6,4]  R1830     5.2173024415969849e-01
    z[3,6,4]  R1831     4.0692262351512909e-02
    z[3,6,4]  R1832     1.3809283077716827e-01
    z[3,6,4]  R1833     0.253192275762558
    z[3,6,4]  R1834     -4.7943615913391113e-01
    z[3,6,4]  R1835     2.1010509133338928e-01
    z[3,6,4]  R1836     3.3108437061309814e-01
    z[3,6,4]  R1837     6.7822962999343872e-02
    z[3,6,4]  R1838     4.7397625446319580e-01
    z[3,6,4]  R1839     0.380689412355423
    z[3,6,4]  R1840     4.0593007206916809e-01
    z[3,6,4]  R1841     4.5717760920524597e-01
    z[3,6,4]  R1842     0.0681137964129448
    z[3,6,4]  R1843     3.3291794359683990e-02
    z[3,6,4]  R1844     2.6483932137489319e-01
    z[3,6,4]  R1845     2.0271314308047295e-02
    z[3,6,4]  R1846     4.1267621517181396e-01
    z[3,6,4]  R1847     5.1104915142059326e-01
    z[3,6,4]  R1848     -1.2227982282638550e-01
    z[3,6,4]  R1849     1.0072357952594757e-01
    z[3,6,4]  R1850     5.7149904966354370e-01
    z[3,6,4]  R1851     4.1737398505210876e-01
    z[3,6,4]  R1852     3.5202163457870483e-01
    z[3,6,4]  R1853     1.8234199285507202e-01
    z[3,6,4]  R1854     -4.2491161823272705e-01
    z[3,6,4]  R1855     3.2057291269302368e-01
    z[3,6,4]  R1856     2.3103576898574829e-01
    z[3,6,4]  R1857     6.3102084398269653e-01
    z[3,6,4]  R1858     -4.9971025437116623e-02
    z[3,6,4]  R1859     -6.2883630394935608e-02
    z[3,6,4]  R1860     -4.3417948484420776e-01
    z[3,6,4]  R1861     -1.5676176548004150e-01
    z[3,6,4]  R1862     -2.7827453613281250e-01
    z[3,6,4]  R1863     5.6708522140979767e-02
    z[3,6,4]  R1864     -0.393111914396286
    z[3,6,4]  R1865     -4.6212986111640930e-01
    z[3,6,4]  R1866     -1.0306835174560547e-01
    z[3,6,4]  R1867     2.4907572567462921e-01
    z[3,6,4]  R1868     3.5415120422840118e-02
    z[3,6,4]  R1869     2.5946739315986633e-01
    z[3,6,4]  R1870     3.1383502483367920e-01
    z[3,6,4]  R1871     -6.5896719694137573e-01
    z[3,6,4]  R1872     -0.596753716468811
    z[3,6,4]  R1873     -6.1668014526367188e-01
    z[3,6,4]  R1874     -0.358946830034256
    z[3,6,4]  R1875     6.9367498159408569e-02
    z[3,6,4]  R1876     -0.0192574355751276
    z[3,6,4]  R1877     5.4983311891555786e-01
    z[3,6,4]  R1878     7.6512259244918823e-01
    z[3,6,4]  R1879     1.8830262124538422e-02
    z[3,6,4]  R1880     1.5435796976089478e-01
    z[3,6,4]  R1881     4.5882749557495117e-01
    z[3,6,4]  R1882     -4.8992950469255447e-02
    z[3,6,4]  R1883     2.2206287086009979e-01
    z[3,6,4]  R1884     0.18660868704319
    z[3,6,4]  R1885     -2.0885774865746498e-02
    z[3,6,4]  R1886     -6.6024191677570343e-02
    z[3,6,4]  R1887     5.5955165624618530e-01
    z[3,6,4]  R1888     1.1262305080890656e-01
    z[3,6,4]  R1889     2.5707712769508362e-01
    z[3,6,4]  R1890     1.4648343622684479e-01
    z[3,6,4]  R1891     4.4894441962242126e-02
    z[3,6,4]  R1892     0.320562481880188
    z[3,6,4]  R1893     4.6578127145767212e-01
    z[3,6,4]  R1894     1.7981793731451035e-02
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1803     -1
    z[3,6,5]  R1804     1
    z[3,6,5]  R1807     2.0027369260787964e-01
    z[3,6,5]  R1808     -2.0059290528297424e-01
    z[3,6,5]  R1809     7.3737972974777222e-01
    z[3,6,5]  R1810     3.3789855241775513e-01
    z[3,6,5]  R1811     2.9510873556137085e-01
    z[3,6,5]  R1812     1.1082833260297775e-01
    z[3,6,5]  R1813     -1.8597602844238281e-02
    z[3,6,5]  R1814     6.3809168338775635e-01
    z[3,6,5]  R1815     5.1412415504455566e-01
    z[3,6,5]  R1816     2.2193567454814911e-01
    z[3,6,5]  R1817     4.7651696205139160e-01
    z[3,6,5]  R1818     3.9702513813972473e-01
    z[3,6,5]  R1819     4.5929023623466492e-01
    z[3,6,5]  R1820     3.5141962766647339e-01
    z[3,6,5]  R1821     2.6954549551010132e-01
    z[3,6,5]  R1822     2.2822347283363342e-01
    z[3,6,5]  R1823     1.8463383615016937e-01
    z[3,6,5]  R1824     5.9028938412666321e-02
    z[3,6,5]  R1825     1.6448110342025757e-02
    z[3,6,5]  R1826     -2.9617862310260534e-03
    z[3,6,5]  R1827     4.3487283587455750e-01
    z[3,6,5]  R1828     0.246379092335701
    z[3,6,5]  R1829     -2.6688998565077782e-02
    z[3,6,5]  R1830     -3.6006936430931091e-01
    z[3,6,5]  R1831     -3.3044733107089996e-02
    z[3,6,5]  R1832     -1.2369648553431034e-02
    z[3,6,5]  R1833     -0.078908272087574
    z[3,6,5]  R1834     1.9652260839939117e-01
    z[3,6,5]  R1835     -3.7982729077339172e-01
    z[3,6,5]  R1836     -3.8389933109283447e-01
    z[3,6,5]  R1837     1.1742393672466278e-01
    z[3,6,5]  R1838     2.2076445817947388e-01
    z[3,6,5]  R1839     -1.8585156649351120e-02
    z[3,6,5]  R1840     2.5669746100902557e-02
    z[3,6,5]  R1841     -2.8313967585563660e-01
    z[3,6,5]  R1842     -2.1947419270873070e-02
    z[3,6,5]  R1843     4.3435059487819672e-02
    z[3,6,5]  R1844     1.1600136011838913e-01
    z[3,6,5]  R1845     6.5694665908813477e-01
    z[3,6,5]  R1846     -3.4724801778793335e-01
    z[3,6,5]  R1847     8.6945161223411560e-02
    z[3,6,5]  R1848     3.3828487992286682e-01
    z[3,6,5]  R1849     0.336469441652298
    z[3,6,5]  R1850     -1.1990658938884735e-02
    z[3,6,5]  R1851     -3.3678838610649109e-01
    z[3,6,5]  R1852     1.4801153540611267e-01
    z[3,6,5]  R1853     -1.5591630339622498e-01
    z[3,6,5]  R1854     -3.3089622855186462e-01
    z[3,6,5]  R1855     -3.6007410287857056e-01
    z[3,6,5]  R1856     -4.1901135444641113e-01
    z[3,6,5]  R1857     -2.1696336567401886e-01
    z[3,6,5]  R1858     2.7509140968322754e-01
    z[3,6,5]  R1859     -3.1465375423431396e-01
    z[3,6,5]  R1860     -2.6323834061622620e-01
    z[3,6,5]  R1861     -1.2563192844390869e-01
    z[3,6,5]  R1862     -2.9858118295669556e-01
    z[3,6,5]  R1863     -3.3711439371109009e-01
    z[3,6,5]  R1864     3.8634178042411804e-01
    z[3,6,5]  R1865     3.5383099317550659e-01
    z[3,6,5]  R1866     0.298246830701828
    z[3,6,5]  R1867     6.6604816913604736e-01
    z[3,6,5]  R1868     1.4240823686122894e-01
    z[3,6,5]  R1869     -3.3883821964263916e-01
    z[3,6,5]  R1870     2.1826688945293427e-01
    z[3,6,5]  R1871     5.4729700088500977e-01
    z[3,6,5]  R1872     -2.7310594916343689e-01
    z[3,6,5]  R1873     4.3495544791221619e-01
    z[3,6,5]  R1874     2.6600891351699829e-01
    z[3,6,5]  R1875     -2.7356579899787903e-01
    z[3,6,5]  R1876     -0.362730473279953
    z[3,6,5]  R1877     -0.503667414188385
    z[3,6,5]  R1878     1.2624172866344452e-01
    z[3,6,5]  R1879     -2.6105238124728203e-02
    z[3,6,5]  R1880     -2.7103149890899658e-01
    z[3,6,5]  R1881     -1.5463612973690033e-01
    z[3,6,5]  R1882     -3.1710001826286316e-01
    z[3,6,5]  R1883     4.2258673906326294e-01
    z[3,6,5]  R1884     -3.6251193284988403e-01
    z[3,6,5]  R1885     -7.6343721151351929e-01
    z[3,6,5]  R1886     -3.9944148063659668e-01
    z[3,6,5]  R1887     -4.7607335448265076e-01
    z[3,6,5]  R1888     -2.4536564946174622e-01
    z[3,6,5]  R1889     -1.9593752920627594e-01
    z[3,6,5]  R1890     -5.0675994157791138e-01
    z[3,6,5]  R1891     -1.6763083636760712e-01
    z[3,6,5]  R1892     -3.7964764982461929e-02
    z[3,6,5]  R1893     -5.2175086736679077e-01
    z[3,6,5]  R1894     2.1028614044189453e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1805     -1
    z[3,6,6]  R1806     1
    z[3,6,6]  R1807     -2.7024172246456146e-02
    z[3,6,6]  R1808     -9.2960305511951447e-02
    z[3,6,6]  R1809     1.5328544378280640e-01
    z[3,6,6]  R1810     4.0478572249412537e-01
    z[3,6,6]  R1811     8.5655406117439270e-02
    z[3,6,6]  R1812     5.5611610412597656e-01
    z[3,6,6]  R1813     5.8828455209732056e-01
    z[3,6,6]  R1814     -1.9911254942417145e-01
    z[3,6,6]  R1815     -5.8473336696624756e-01
    z[3,6,6]  R1816     -6.3331574201583862e-01
    z[3,6,6]  R1817     -1.2940365076065063e-01
    z[3,6,6]  R1818     1.3666908442974091e-01
    z[3,6,6]  R1819     4.9621118232607841e-03
    z[3,6,6]  R1820     -2.3997332155704498e-01
    z[3,6,6]  R1821     -1.7408396303653717e-01
    z[3,6,6]  R1822     -0.223873108625412
    z[3,6,6]  R1823     -3.0624959617853165e-02
    z[3,6,6]  R1824     -1.0289679467678070e-01
    z[3,6,6]  R1825     -2.9153700917959213e-02
    z[3,6,6]  R1826     1.6441315412521362e-01
    z[3,6,6]  R1827     -5.2010573446750641e-02
    z[3,6,6]  R1828     -2.6188856363296509e-01
    z[3,6,6]  R1829     -1.7743955552577972e-01
    z[3,6,6]  R1830     9.1521563008427620e-03
    z[3,6,6]  R1831     -0.0802517980337143
    z[3,6,6]  R1832     -1.7082595825195312e-01
    z[3,6,6]  R1833     -1.0478270053863525e-01
    z[3,6,6]  R1834     0.0362219400703907
    z[3,6,6]  R1835     2.0498305559158325e-02
    z[3,6,6]  R1836     1.9291643053293228e-02
    z[3,6,6]  R1837     -3.5813847184181213e-01
    z[3,6,6]  R1838     1.9769731163978577e-01
    z[3,6,6]  R1839     -4.9664962291717529e-01
    z[3,6,6]  R1840     1.7384378612041473e-01
    z[3,6,6]  R1841     3.8115769624710083e-02
    z[3,6,6]  R1842     2.1018664538860321e-01
    z[3,6,6]  R1843     -1.2856742739677429e-01
    z[3,6,6]  R1844     -1.3096508383750916e-01
    z[3,6,6]  R1845     -6.0381293296813965e-02
    z[3,6,6]  R1846     -4.1922357678413391e-01
    z[3,6,6]  R1847     -1.0657577216625214e-01
    z[3,6,6]  R1848     -3.2016387581825256e-01
    z[3,6,6]  R1849     6.2875300645828247e-01
    z[3,6,6]  R1850     -6.3919365406036377e-02
    z[3,6,6]  R1851     -6.0191076993942261e-01
    z[3,6,6]  R1852     -1.8667422235012054e-01
    z[3,6,6]  R1853     2.2959427535533905e-01
    z[3,6,6]  R1854     -2.4552170187234879e-02
    z[3,6,6]  R1855     3.8883426785469055e-01
    z[3,6,6]  R1856     0.190166175365448
    z[3,6,6]  R1857     -6.2794364988803864e-02
    z[3,6,6]  R1858     -6.0246515274047852e-01
    z[3,6,6]  R1859     -0.0921337753534317
    z[3,6,6]  R1860     5.1443153619766235e-01
    z[3,6,6]  R1861     2.5557265616953373e-03
    z[3,6,6]  R1862     -3.8667377084493637e-02
    z[3,6,6]  R1863     1.2433449923992157e-01
    z[3,6,6]  R1864     -1.7583039402961731e-01
    z[3,6,6]  R1865     2.6646783947944641e-01
    z[3,6,6]  R1866     1.3733452558517456e-01
    z[3,6,6]  R1867     1.0208512842655182e-01
    z[3,6,6]  R1868     -3.5303589701652527e-01
    z[3,6,6]  R1869     4.5818752050399780e-01
    z[3,6,6]  R1870     0.242108553647995
    z[3,6,6]  R1871     2.7308214455842972e-02
    z[3,6,6]  R1872     -2.9468801617622375e-01
    z[3,6,6]  R1873     -4.9768692255020142e-01
    z[3,6,6]  R1874     2.6096296310424805e-01
    z[3,6,6]  R1875     -2.9381856322288513e-01
    z[3,6,6]  R1876     5.3373958915472031e-02
    z[3,6,6]  R1877     -1.4346466958522797e-01
    z[3,6,6]  R1878     -2.6347804069519043e-01
    z[3,6,6]  R1879     -2.9278692603111267e-01
    z[3,6,6]  R1880     -7.4396848678588867e-02
    z[3,6,6]  R1881     2.9214599728584290e-01
    z[3,6,6]  R1882     -4.1162124276161194e-01
    z[3,6,6]  R1883     -2.9800674319267273e-01
    z[3,6,6]  R1884     -2.4290467798709869e-01
    z[3,6,6]  R1885     4.6672880649566650e-02
    z[3,6,6]  R1886     -3.5432377457618713e-01
    z[3,6,6]  R1887     -1.2061487138271332e-01
    z[3,6,6]  R1888     -3.0226796865463257e-01
    z[3,6,6]  R1889     6.0109067708253860e-03
    z[3,6,6]  R1890     -1.4585968852043152e-01
    z[3,6,6]  R1891     9.1197066009044647e-02
    z[3,6,6]  R1892     1.8935346603393555e-01
    z[3,6,6]  R1893     1.8424926698207855e-01
    z[3,6,6]  R1894     -2.7470108866691589e-01
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1895     -1
    z[6,3,0]  R1896     1
    z[6,3,0]  R1909     -4.8729193210601807e-01
    z[6,3,0]  R1910     -6.0099172592163086e-01
    z[6,3,0]  R1911     -3.2954074442386627e-02
    z[6,3,0]  R1912     7.5554296374320984e-02
    z[6,3,0]  R1913     -9.7896084189414978e-02
    z[6,3,0]  R1914     -3.8970449566841125e-01
    z[6,3,0]  R1915     1.2374044954776764e-01
    z[6,3,0]  R1916     2.8977102041244507e-01
    z[6,3,0]  R1917     -4.6530212275683880e-03
    z[6,3,0]  R1918     7.6810702681541443e-02
    z[6,3,0]  R1919     2.7076140046119690e-01
    z[6,3,0]  R1920     2.0435069501399994e-01
    z[6,3,0]  R1921     4.8351809382438660e-03
    z[6,3,0]  R1922     2.4945285916328430e-01
    z[6,3,0]  R1923     0.213861882686615
    z[6,3,0]  R1924     1.9959162175655365e-01
    z[6,3,0]  R1925     1.0795354098081589e-01
    z[6,3,0]  R1926     0.0949750691652298
    z[6,3,0]  R1927     1.0327365249395370e-01
    z[6,3,0]  R1928     -1.4315104484558105e-01
    z[6,3,0]  R1929     1.0323889553546906e-01
    z[6,3,0]  R1930     -0.086922287940979
    z[6,3,0]  R1931     4.8406824469566345e-01
    z[6,3,0]  R1932     1.0395500808954239e-02
    z[6,3,0]  R1933     -1.1849900335073471e-01
    z[6,3,0]  R1934     -4.7565117478370667e-02
    z[6,3,0]  R1935     -2.8622692823410034e-01
    z[6,3,0]  R1936     2.3305535316467285e-02
    z[6,3,0]  R1937     -1.2474393099546432e-01
    z[6,3,0]  R1938     -2.1036426723003387e-01
    z[6,3,0]  R1939     3.6170229315757751e-01
    z[6,3,0]  R1940     1.6324986517429352e-01
    z[6,3,0]  R1941     -4.1269157081842422e-02
    z[6,3,0]  R1942     1.2358608096837997e-01
    z[6,3,0]  R1943     -2.3048009723424911e-02
    z[6,3,0]  R1944     1.8776720762252808e-01
    z[6,3,0]  R1945     -1.5722067654132843e-01
    z[6,3,0]  R1946     -9.7374036908149719e-02
    z[6,3,0]  R1947     -1.9575388729572296e-01
    z[6,3,0]  R1948     9.2036321759223938e-02
    z[6,3,0]  R1949     -3.2675590366125107e-02
    z[6,3,0]  R1950     -3.6611091345548630e-02
    z[6,3,0]  R1951     -2.2188383340835571e-01
    z[6,3,0]  R1952     -1.9630396738648415e-02
    z[6,3,0]  R1953     1.5862879157066345e-01
    z[6,3,0]  R1954     1.8542206287384033e-01
    z[6,3,0]  R1955     1.9136006012558937e-02
    z[6,3,0]  R1956     4.1606724262237549e-01
    z[6,3,0]  R1957     2.1164511144161224e-01
    z[6,3,0]  R1958     2.6832106709480286e-01
    z[6,3,0]  R1959     1.8306382000446320e-01
    z[6,3,0]  R1960     3.1629450619220734e-02
    z[6,3,0]  R1961     6.9233119487762451e-02
    z[6,3,0]  R1962     -8.5436977446079254e-02
    z[6,3,0]  R1963     -6.9607138633728027e-01
    z[6,3,0]  R1964     -3.7381795048713684e-01
    z[6,3,0]  R1965     -5.0426310300827026e-01
    z[6,3,0]  R1966     -7.4039585888385773e-02
    z[6,3,0]  R1967     1.8637432157993317e-01
    z[6,3,0]  R1968     1.1229066550731659e-01
    z[6,3,0]  R1969     3.1533634662628174e-01
    z[6,3,0]  R1970     -3.6027842760086060e-01
    z[6,3,0]  R1971     4.6952001750469208e-02
    z[6,3,0]  R1972     3.3584558963775635e-01
    z[6,3,0]  R1973     -1.8386675417423248e-01
    z[6,3,0]  R1974     1.9078862667083740e-01
    z[6,3,0]  R1975     -5.7934051752090454e-01
    z[6,3,0]  R1976     2.6301616430282593e-01
    z[6,3,0]  R1977     -7.2893661260604858e-01
    z[6,3,0]  R1978     1.1756321042776108e-01
    z[6,3,0]  R1979     -2.0802223682403564e-01
    z[6,3,0]  R1980     -3.6427670717239380e-01
    z[6,3,0]  R1981     -9.3302980065345764e-02
    z[6,3,0]  R1982     -8.6929149925708771e-02
    z[6,3,0]  R1983     4.3205675482749939e-01
    z[6,3,0]  R1984     0.0286989975720644
    z[6,3,0]  R1985     2.3792499303817749e-01
    z[6,3,0]  R1986     4.8042505979537964e-01
    z[6,3,0]  R1987     1.2228551506996155e-01
    z[6,3,0]  R1988     1.5694823861122131e-01
    z[6,3,0]  R1989     3.7377968430519104e-01
    z[6,3,0]  R1990     5.0766885280609131e-01
    z[6,3,0]  R1991     2.6414486765861511e-01
    z[6,3,0]  R1992     4.0131795406341553e-01
    z[6,3,0]  R1993     -4.0726464986801147e-01
    z[6,3,0]  R1994     -2.2311198711395264e-01
    z[6,3,0]  R1995     -5.9472423791885376e-01
    z[6,3,0]  R1996     -3.7742203567177057e-03
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1897     -1
    z[6,3,1]  R1898     1
    z[6,3,1]  R1909     -3.5702398419380188e-01
    z[6,3,1]  R1910     -1.5415129065513611e-01
    z[6,3,1]  R1911     -6.7099016904830933e-01
    z[6,3,1]  R1912     -7.4068850278854370e-01
    z[6,3,1]  R1913     -5.4062509536743164e-01
    z[6,3,1]  R1914     -6.6204947233200073e-01
    z[6,3,1]  R1915     -4.0233135223388672e-01
    z[6,3,1]  R1916     -3.5219326615333557e-01
    z[6,3,1]  R1917     -2.4606880545616150e-01
    z[6,3,1]  R1918     4.4106975197792053e-01
    z[6,3,1]  R1919     -3.9074367284774780e-01
    z[6,3,1]  R1920     -3.0664929747581482e-01
    z[6,3,1]  R1921     -1.6096708178520203e-01
    z[6,3,1]  R1922     3.9459779858589172e-01
    z[6,3,1]  R1923     7.5173395872116089e-01
    z[6,3,1]  R1924     7.4822336435317993e-01
    z[6,3,1]  R1925     6.6282504796981812e-01
    z[6,3,1]  R1926     8.2198286056518555e-01
    z[6,3,1]  R1927     6.5111505985260010e-01
    z[6,3,1]  R1928     8.3069866895675659e-01
    z[6,3,1]  R1929     -4.4804677367210388e-01
    z[6,3,1]  R1930     -3.9826601743698120e-01
    z[6,3,1]  R1931     -2.6746892929077148e-01
    z[6,3,1]  R1932     9.1232210397720337e-01
    z[6,3,1]  R1933     9.3661522865295410e-01
    z[6,3,1]  R1934     7.7929776906967163e-01
    z[6,3,1]  R1935     9.1708499193191528e-01
    z[6,3,1]  R1936     -1.9481889903545380e-01
    z[6,3,1]  R1937     6.5784966945648193e-01
    z[6,3,1]  R1938     0.863397479057312
    z[6,3,1]  R1939     -0.806343674659729
    z[6,3,1]  R1940     -7.4787521362304688e-01
    z[6,3,1]  R1941     -5.4697972536087036e-01
    z[6,3,1]  R1942     -7.7965390682220459e-01
    z[6,3,1]  R1943     -6.1561739444732666e-01
    z[6,3,1]  R1944     -6.6225737333297729e-01
    z[6,3,1]  R1945     -7.7129900455474854e-01
    z[6,3,1]  R1946     -6.8135350942611694e-01
    z[6,3,1]  R1947     -5.6042784452438354e-01
    z[6,3,1]  R1948     -3.6967614293098450e-01
    z[6,3,1]  R1949     5.6595337390899658e-01
    z[6,3,1]  R1950     5.1366031169891357e-01
    z[6,3,1]  R1951     5.6661015748977661e-01
    z[6,3,1]  R1952     5.9830093383789062e-01
    z[6,3,1]  R1953     6.0357969999313354e-01
    z[6,3,1]  R1954     8.0633997917175293e-01
    z[6,3,1]  R1955     9.2627406120300293e-01
    z[6,3,1]  R1956     6.8232113122940063e-01
    z[6,3,1]  R1957     7.1411836147308350e-01
    z[6,3,1]  R1958     6.5283042192459106e-01
    z[6,3,1]  R1959     2.1240106225013733e-01
    z[6,3,1]  R1960     1.2077067792415619e-01
    z[6,3,1]  R1961     3.3731155097484589e-02
    z[6,3,1]  R1962     -4.0616673231124878e-01
    z[6,3,1]  R1963     -9.4405815005302429e-02
    z[6,3,1]  R1964     -2.6088034734129906e-02
    z[6,3,1]  R1965     -3.3746039867401123e-01
    z[6,3,1]  R1966     4.0909877419471741e-01
    z[6,3,1]  R1967     6.6235578060150146e-01
    z[6,3,1]  R1968     7.8362166881561279e-01
    z[6,3,1]  R1969     1.4579404890537262e-01
    z[6,3,1]  R1970     -7.1627922356128693e-02
    z[6,3,1]  R1971     3.8499668240547180e-02
    z[6,3,1]  R1972     -1.4943755231797695e-02
    z[6,3,1]  R1973     -1.2556684203445911e-02
    z[6,3,1]  R1974     2.5044474005699158e-01
    z[6,3,1]  R1975     -4.3855917453765869e-01
    z[6,3,1]  R1976     7.7784001827239990e-01
    z[6,3,1]  R1977     -3.8717139512300491e-02
    z[6,3,1]  R1978     -5.4183810949325562e-01
    z[6,3,1]  R1979     -7.7265053987503052e-01
    z[6,3,1]  R1980     2.3995118215680122e-02
    z[6,3,1]  R1981     8.0874115228652954e-02
    z[6,3,1]  R1982     -5.1484964787960052e-03
    z[6,3,1]  R1983     -3.8053739070892334e-01
    z[6,3,1]  R1984     8.0667048692703247e-01
    z[6,3,1]  R1985     7.8709441423416138e-01
    z[6,3,1]  R1986     6.7205429077148438e-01
    z[6,3,1]  R1987     0.721260130405426
    z[6,3,1]  R1988     7.9820042848587036e-01
    z[6,3,1]  R1989     -3.7496453523635864e-01
    z[6,3,1]  R1990     -2.9170952737331390e-02
    z[6,3,1]  R1991     7.6787370443344116e-01
    z[6,3,1]  R1992     4.9740001559257507e-01
    z[6,3,1]  R1993     6.7751801013946533e-01
    z[6,3,1]  R1994     -2.4190092086791992e-01
    z[6,3,1]  R1995     4.2945200204849243e-01
    z[6,3,1]  R1996     2.6404294371604919e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1899     -1
    z[6,3,2]  R1900     1
    z[6,3,2]  R1909     3.3122763037681580e-01
    z[6,3,2]  R1910     5.5581283569335938e-01
    z[6,3,2]  R1911     1.5156951732933521e-02
    z[6,3,2]  R1912     2.4588094651699066e-01
    z[6,3,2]  R1913     -5.8745924383401871e-02
    z[6,3,2]  R1914     4.3144565820693970e-01
    z[6,3,2]  R1915     -2.6238444447517395e-01
    z[6,3,2]  R1916     -1.4579498767852783e-01
    z[6,3,2]  R1917     2.3747770488262177e-01
    z[6,3,2]  R1918     -5.1327288150787354e-01
    z[6,3,2]  R1919     -9.1044150292873383e-02
    z[6,3,2]  R1920     -6.8464823067188263e-02
    z[6,3,2]  R1921     2.3217935115098953e-02
    z[6,3,2]  R1922     -1.6536971926689148e-01
    z[6,3,2]  R1923     8.6744002997875214e-02
    z[6,3,2]  R1924     2.3347425460815430e-01
    z[6,3,2]  R1925     -1.0240331292152405e-01
    z[6,3,2]  R1926     6.9272637367248535e-02
    z[6,3,2]  R1927     -4.7520559281110764e-02
    z[6,3,2]  R1928     2.3230488598346710e-01
    z[6,3,2]  R1929     1.0994613170623779e-01
    z[6,3,2]  R1930     5.5095762014389038e-01
    z[6,3,2]  R1931     -2.7092188596725464e-01
    z[6,3,2]  R1932     5.5401004850864410e-02
    z[6,3,2]  R1933     3.7188478745520115e-03
    z[6,3,2]  R1934     5.7915952056646347e-02
    z[6,3,2]  R1935     1.3038368523120880e-01
    z[6,3,2]  R1936     -8.4326320886611938e-01
    z[6,3,2]  R1937     -4.6066680806688964e-04
    z[6,3,2]  R1938     2.4493815004825592e-01
    z[6,3,2]  R1939     -4.0706697106361389e-01
    z[6,3,2]  R1940     2.7609580755233765e-01
    z[6,3,2]  R1941     -1.5832577645778656e-01
    z[6,3,2]  R1942     -2.0530427992343903e-01
    z[6,3,2]  R1943     -2.1107414364814758e-01
    z[6,3,2]  R1944     -1.9327521324157715e-01
    z[6,3,2]  R1945     -2.5243712589144707e-02
    z[6,3,2]  R1946     -2.3439349234104156e-01
    z[6,3,2]  R1947     9.7869625315070152e-03
    z[6,3,2]  R1948     1.3684664852917194e-02
    z[6,3,2]  R1949     -0.608640730381012
    z[6,3,2]  R1950     -6.2675130367279053e-01
    z[6,3,2]  R1951     -4.3944120407104492e-01
    z[6,3,2]  R1952     -4.6132189035415649e-01
    z[6,3,2]  R1953     -5.5187779664993286e-01
    z[6,3,2]  R1954     -4.5976600050926208e-01
    z[6,3,2]  R1955     -3.1907999515533447e-01
    z[6,3,2]  R1956     -5.5827200412750244e-01
    z[6,3,2]  R1957     -3.4449258446693420e-01
    z[6,3,2]  R1958     -0.47967329621315
    z[6,3,2]  R1959     3.5087114572525024e-01
    z[6,3,2]  R1960     -1.4752382040023804e-01
    z[6,3,2]  R1961     2.0647323690354824e-03
    z[6,3,2]  R1962     5.1708000898361206e-01
    z[6,3,2]  R1963     -3.9517989754676819e-01
    z[6,3,2]  R1964     -3.5510140657424927e-01
    z[6,3,2]  R1965     6.6694790124893188e-01
    z[6,3,2]  R1966     5.2773706614971161e-02
    z[6,3,2]  R1967     2.2508682310581207e-01
    z[6,3,2]  R1968     3.2976818084716797e-01
    z[6,3,2]  R1969     -1.6189638525247574e-02
    z[6,3,2]  R1970     -2.3209549486637115e-02
    z[6,3,2]  R1971     4.3543872237205505e-01
    z[6,3,2]  R1972     -4.9028575420379639e-01
    z[6,3,2]  R1973     5.7964944839477539e-01
    z[6,3,2]  R1974     -2.1978507936000824e-01
    z[6,3,2]  R1975     6.2940829992294312e-01
    z[6,3,2]  R1976     -4.6362683176994324e-01
    z[6,3,2]  R1977     -1.1675927042961121e-01
    z[6,3,2]  R1978     3.5269770771265030e-02
    z[6,3,2]  R1979     1.3527289032936096e-01
    z[6,3,2]  R1980     1.5156303346157074e-01
    z[6,3,2]  R1981     4.1148793697357178e-01
    z[6,3,2]  R1982     1.2999449670314789e-01
    z[6,3,2]  R1983     2.2236153483390808e-02
    z[6,3,2]  R1984     -2.7773118019104004e-01
    z[6,3,2]  R1985     2.0093873143196106e-01
    z[6,3,2]  R1986     -8.3115048706531525e-02
    z[6,3,2]  R1987     9.2648655176162720e-02
    z[6,3,2]  R1988     2.6972818374633789e-01
    z[6,3,2]  R1989     -9.5397032797336578e-02
    z[6,3,2]  R1990     -6.7495889961719513e-02
    z[6,3,2]  R1991     1.4342764019966125e-01
    z[6,3,2]  R1992     -2.6181939244270325e-01
    z[6,3,2]  R1993     4.7308516502380371e-01
    z[6,3,2]  R1994     -8.9823201298713684e-02
    z[6,3,2]  R1995     2.9901077970862389e-02
    z[6,3,2]  R1996     2.3564234375953674e-01
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1901     -1
    z[6,3,3]  R1902     1
    z[6,3,3]  R1909     3.4000462293624878e-01
    z[6,3,3]  R1910     4.3322449922561646e-01
    z[6,3,3]  R1911     1.7993398010730743e-01
    z[6,3,3]  R1912     4.8892334103584290e-01
    z[6,3,3]  R1913     5.5010837316513062e-01
    z[6,3,3]  R1914     1.3757245242595673e-01
    z[6,3,3]  R1915     1.3948038220405579e-01
    z[6,3,3]  R1916     5.0318348407745361e-01
    z[6,3,3]  R1917     2.5663191080093384e-01
    z[6,3,3]  R1918     5.1807653903961182e-01
    z[6,3,3]  R1919     -7.7442824840545654e-01
    z[6,3,3]  R1920     -8.5130870342254639e-01
    z[6,3,3]  R1921     -6.3003784418106079e-01
    z[6,3,3]  R1922     2.8973874449729919e-01
    z[6,3,3]  R1923     -5.4302328824996948e-01
    z[6,3,3]  R1924     -4.9294564127922058e-01
    z[6,3,3]  R1925     -4.6769458055496216e-01
    z[6,3,3]  R1926     -1.9529570639133453e-01
    z[6,3,3]  R1927     -4.9641317129135132e-01
    z[6,3,3]  R1928     1.0120025277137756e-01
    z[6,3,3]  R1929     -4.3710049986839294e-01
    z[6,3,3]  R1930     -4.9073022603988647e-01
    z[6,3,3]  R1931     -2.5777477025985718e-01
    z[6,3,3]  R1932     -1.5390133485198021e-02
    z[6,3,3]  R1933     -6.4651072025299072e-02
    z[6,3,3]  R1934     2.9587191343307495e-01
    z[6,3,3]  R1935     -1.4695847034454346e-01
    z[6,3,3]  R1936     -0.332194447517395
    z[6,3,3]  R1937     1.6896338760852814e-01
    z[6,3,3]  R1938     -1.7404754459857941e-01
    z[6,3,3]  R1939     6.1551958322525024e-02
    z[6,3,3]  R1940     4.7896894812583923e-01
    z[6,3,3]  R1941     2.5067204236984253e-01
    z[6,3,3]  R1942     4.6751942485570908e-02
    z[6,3,3]  R1943     1.4026145637035370e-01
    z[6,3,3]  R1944     1.5647675096988678e-01
    z[6,3,3]  R1945     1.7780081927776337e-01
    z[6,3,3]  R1946     -1.3124364614486694e-01
    z[6,3,3]  R1947     1.5760404989123344e-02
    z[6,3,3]  R1948     2.5649723410606384e-01
    z[6,3,3]  R1949     2.4812524020671844e-01
    z[6,3,3]  R1950     3.5732197761535645e-01
    z[6,3,3]  R1951     4.4686308503150940e-01
    z[6,3,3]  R1952     1.5797902643680573e-01
    z[6,3,3]  R1953     2.2483283281326294e-01
    z[6,3,3]  R1954     5.8787297457456589e-03
    z[6,3,3]  R1955     -5.5460810661315918e-02
    z[6,3,3]  R1956     1.8514537811279297e-01
    z[6,3,3]  R1957     5.3036159276962280e-01
    z[6,3,3]  R1958     -2.1677853539586067e-02
    z[6,3,3]  R1959     6.0600304603576660e-01
    z[6,3,3]  R1960     5.8472746610641479e-01
    z[6,3,3]  R1961     6.8398469686508179e-01
    z[6,3,3]  R1962     -3.9802172780036926e-01
    z[6,3,3]  R1963     5.8413773775100708e-01
    z[6,3,3]  R1964     8.2769459486007690e-01
    z[6,3,3]  R1965     -3.2512679696083069e-01
    z[6,3,3]  R1966     7.4470067024230957e-01
    z[6,3,3]  R1967     -5.3577250242233276e-01
    z[6,3,3]  R1968     -8.4929518401622772e-02
    z[6,3,3]  R1969     8.5579985380172729e-01
    z[6,3,3]  R1970     7.4300438165664673e-01
    z[6,3,3]  R1971     6.4403080940246582e-01
    z[6,3,3]  R1972     6.7152398824691772e-01
    z[6,3,3]  R1973     5.8258867263793945e-01
    z[6,3,3]  R1974     8.9625442028045654e-01
    z[6,3,3]  R1975     -2.3738366365432739e-01
    z[6,3,3]  R1976     1.0044626891613007e-01
    z[6,3,3]  R1977     1.3373105227947235e-01
    z[6,3,3]  R1978     -4.7404131293296814e-01
    z[6,3,3]  R1979     2.4768961966037750e-01
    z[6,3,3]  R1980     7.8221571445465088e-01
    z[6,3,3]  R1981     5.4474240541458130e-01
    z[6,3,3]  R1982     8.0291819572448730e-01
    z[6,3,3]  R1983     -1.3453532755374908e-01
    z[6,3,3]  R1984     -3.0108213424682617e-01
    z[6,3,3]  R1985     -4.1620391607284546e-01
    z[6,3,3]  R1986     -1.4135645329952240e-01
    z[6,3,3]  R1987     -2.6950651407241821e-01
    z[6,3,3]  R1988     -0.0194667000323534
    z[6,3,3]  R1989     5.1125931739807129e-01
    z[6,3,3]  R1990     5.4380977153778076e-01
    z[6,3,3]  R1991     -4.5670115947723389e-01
    z[6,3,3]  R1992     2.3274455219507217e-02
    z[6,3,3]  R1993     -3.3306321501731873e-01
    z[6,3,3]  R1994     -8.4590435028076172e-01
    z[6,3,3]  R1995     -0.573287844657898
    z[6,3,3]  R1996     -7.3486495018005371e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1903     -1
    z[6,3,4]  R1904     1
    z[6,3,4]  R1909     -4.6212986111640930e-01
    z[6,3,4]  R1910     -1.0306835174560547e-01
    z[6,3,4]  R1911     2.4907572567462921e-01
    z[6,3,4]  R1912     3.5415120422840118e-02
    z[6,3,4]  R1913     2.5946739315986633e-01
    z[6,3,4]  R1914     3.1383502483367920e-01
    z[6,3,4]  R1915     -6.5896719694137573e-01
    z[6,3,4]  R1916     -0.596753716468811
    z[6,3,4]  R1917     -6.1668014526367188e-01
    z[6,3,4]  R1918     -0.358946830034256
    z[6,3,4]  R1919     6.9367498159408569e-02
    z[6,3,4]  R1920     -0.0192574355751276
    z[6,3,4]  R1921     5.4983311891555786e-01
    z[6,3,4]  R1922     7.6512259244918823e-01
    z[6,3,4]  R1923     1.8830262124538422e-02
    z[6,3,4]  R1924     1.5435796976089478e-01
    z[6,3,4]  R1925     4.5882749557495117e-01
    z[6,3,4]  R1926     -4.8992950469255447e-02
    z[6,3,4]  R1927     2.2206287086009979e-01
    z[6,3,4]  R1928     0.18660868704319
    z[6,3,4]  R1929     -2.0885774865746498e-02
    z[6,3,4]  R1930     -6.6024191677570343e-02
    z[6,3,4]  R1931     5.5955165624618530e-01
    z[6,3,4]  R1932     1.1262305080890656e-01
    z[6,3,4]  R1933     2.5707712769508362e-01
    z[6,3,4]  R1934     1.4648343622684479e-01
    z[6,3,4]  R1935     4.4894441962242126e-02
    z[6,3,4]  R1936     0.320562481880188
    z[6,3,4]  R1937     4.6578127145767212e-01
    z[6,3,4]  R1938     1.7981793731451035e-02
    z[6,3,4]  R1939     -9.3001998960971832e-02
    z[6,3,4]  R1940     -0.243952676653862
    z[6,3,4]  R1941     -2.0971670746803284e-01
    z[6,3,4]  R1942     2.3346078395843506e-01
    z[6,3,4]  R1943     -6.7958253622055054e-01
    z[6,3,4]  R1944     -3.7784937024116516e-01
    z[6,3,4]  R1945     -4.1286323219537735e-02
    z[6,3,4]  R1946     8.5462033748626709e-02
    z[6,3,4]  R1947     2.0253455638885498e-01
    z[6,3,4]  R1948     -5.8184742927551270e-01
    z[6,3,4]  R1949     5.2968215197324753e-02
    z[6,3,4]  R1950     0.19495889544487
    z[6,3,4]  R1951     1.6109964251518250e-01
    z[6,3,4]  R1952     4.7200888395309448e-01
    z[6,3,4]  R1953     3.9044788479804993e-01
    z[6,3,4]  R1954     -4.2544011026620865e-02
    z[6,3,4]  R1955     -4.1648335754871368e-02
    z[6,3,4]  R1956     3.6156203597784042e-02
    z[6,3,4]  R1957     2.1014837920665741e-01
    z[6,3,4]  R1958     4.9418565630912781e-01
    z[6,3,4]  R1959     4.8908448219299316e-01
    z[6,3,4]  R1960     7.0103943347930908e-01
    z[6,3,4]  R1961     0.702874481678009
    z[6,3,4]  R1962     5.2173024415969849e-01
    z[6,3,4]  R1963     4.0692262351512909e-02
    z[6,3,4]  R1964     1.3809283077716827e-01
    z[6,3,4]  R1965     0.253192275762558
    z[6,3,4]  R1966     -4.7943615913391113e-01
    z[6,3,4]  R1967     2.1010509133338928e-01
    z[6,3,4]  R1968     3.3108437061309814e-01
    z[6,3,4]  R1969     6.7822962999343872e-02
    z[6,3,4]  R1970     4.7397625446319580e-01
    z[6,3,4]  R1971     0.380689412355423
    z[6,3,4]  R1972     4.0593007206916809e-01
    z[6,3,4]  R1973     4.5717760920524597e-01
    z[6,3,4]  R1974     0.0681137964129448
    z[6,3,4]  R1975     3.3291794359683990e-02
    z[6,3,4]  R1976     2.6483932137489319e-01
    z[6,3,4]  R1977     2.0271314308047295e-02
    z[6,3,4]  R1978     4.1267621517181396e-01
    z[6,3,4]  R1979     5.1104915142059326e-01
    z[6,3,4]  R1980     -1.2227982282638550e-01
    z[6,3,4]  R1981     1.0072357952594757e-01
    z[6,3,4]  R1982     5.7149904966354370e-01
    z[6,3,4]  R1983     4.1737398505210876e-01
    z[6,3,4]  R1984     3.5202163457870483e-01
    z[6,3,4]  R1985     1.8234199285507202e-01
    z[6,3,4]  R1986     -4.2491161823272705e-01
    z[6,3,4]  R1987     3.2057291269302368e-01
    z[6,3,4]  R1988     2.3103576898574829e-01
    z[6,3,4]  R1989     6.3102084398269653e-01
    z[6,3,4]  R1990     -4.9971025437116623e-02
    z[6,3,4]  R1991     -6.2883630394935608e-02
    z[6,3,4]  R1992     -4.3417948484420776e-01
    z[6,3,4]  R1993     -1.5676176548004150e-01
    z[6,3,4]  R1994     -2.7827453613281250e-01
    z[6,3,4]  R1995     5.6708522140979767e-02
    z[6,3,4]  R1996     -0.393111914396286
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1905     -1
    z[6,3,5]  R1906     1
    z[6,3,5]  R1909     3.5383099317550659e-01
    z[6,3,5]  R1910     0.298246830701828
    z[6,3,5]  R1911     6.6604816913604736e-01
    z[6,3,5]  R1912     1.4240823686122894e-01
    z[6,3,5]  R1913     -3.3883821964263916e-01
    z[6,3,5]  R1914     2.1826688945293427e-01
    z[6,3,5]  R1915     5.4729700088500977e-01
    z[6,3,5]  R1916     -2.7310594916343689e-01
    z[6,3,5]  R1917     4.3495544791221619e-01
    z[6,3,5]  R1918     2.6600891351699829e-01
    z[6,3,5]  R1919     -2.7356579899787903e-01
    z[6,3,5]  R1920     -0.362730473279953
    z[6,3,5]  R1921     -0.503667414188385
    z[6,3,5]  R1922     1.2624172866344452e-01
    z[6,3,5]  R1923     -2.6105238124728203e-02
    z[6,3,5]  R1924     -2.7103149890899658e-01
    z[6,3,5]  R1925     -1.5463612973690033e-01
    z[6,3,5]  R1926     -3.1710001826286316e-01
    z[6,3,5]  R1927     4.2258673906326294e-01
    z[6,3,5]  R1928     -3.6251193284988403e-01
    z[6,3,5]  R1929     -7.6343721151351929e-01
    z[6,3,5]  R1930     -3.9944148063659668e-01
    z[6,3,5]  R1931     -4.7607335448265076e-01
    z[6,3,5]  R1932     -2.4536564946174622e-01
    z[6,3,5]  R1933     -1.9593752920627594e-01
    z[6,3,5]  R1934     -5.0675994157791138e-01
    z[6,3,5]  R1935     -1.6763083636760712e-01
    z[6,3,5]  R1936     -3.7964764982461929e-02
    z[6,3,5]  R1937     -5.2175086736679077e-01
    z[6,3,5]  R1938     2.1028614044189453e-01
    z[6,3,5]  R1939     2.0027369260787964e-01
    z[6,3,5]  R1940     -2.0059290528297424e-01
    z[6,3,5]  R1941     7.3737972974777222e-01
    z[6,3,5]  R1942     3.3789855241775513e-01
    z[6,3,5]  R1943     2.9510873556137085e-01
    z[6,3,5]  R1944     1.1082833260297775e-01
    z[6,3,5]  R1945     -1.8597602844238281e-02
    z[6,3,5]  R1946     6.3809168338775635e-01
    z[6,3,5]  R1947     5.1412415504455566e-01
    z[6,3,5]  R1948     2.2193567454814911e-01
    z[6,3,5]  R1949     4.7651696205139160e-01
    z[6,3,5]  R1950     3.9702513813972473e-01
    z[6,3,5]  R1951     4.5929023623466492e-01
    z[6,3,5]  R1952     3.5141962766647339e-01
    z[6,3,5]  R1953     2.6954549551010132e-01
    z[6,3,5]  R1954     2.2822347283363342e-01
    z[6,3,5]  R1955     1.8463383615016937e-01
    z[6,3,5]  R1956     5.9028938412666321e-02
    z[6,3,5]  R1957     1.6448110342025757e-02
    z[6,3,5]  R1958     -2.9617862310260534e-03
    z[6,3,5]  R1959     4.3487283587455750e-01
    z[6,3,5]  R1960     0.246379092335701
    z[6,3,5]  R1961     -2.6688998565077782e-02
    z[6,3,5]  R1962     -3.6006936430931091e-01
    z[6,3,5]  R1963     -3.3044733107089996e-02
    z[6,3,5]  R1964     -1.2369648553431034e-02
    z[6,3,5]  R1965     -0.078908272087574
    z[6,3,5]  R1966     1.9652260839939117e-01
    z[6,3,5]  R1967     -3.7982729077339172e-01
    z[6,3,5]  R1968     -3.8389933109283447e-01
    z[6,3,5]  R1969     1.1742393672466278e-01
    z[6,3,5]  R1970     2.2076445817947388e-01
    z[6,3,5]  R1971     -1.8585156649351120e-02
    z[6,3,5]  R1972     2.5669746100902557e-02
    z[6,3,5]  R1973     -2.8313967585563660e-01
    z[6,3,5]  R1974     -2.1947419270873070e-02
    z[6,3,5]  R1975     4.3435059487819672e-02
    z[6,3,5]  R1976     1.1600136011838913e-01
    z[6,3,5]  R1977     6.5694665908813477e-01
    z[6,3,5]  R1978     -3.4724801778793335e-01
    z[6,3,5]  R1979     8.6945161223411560e-02
    z[6,3,5]  R1980     3.3828487992286682e-01
    z[6,3,5]  R1981     0.336469441652298
    z[6,3,5]  R1982     -1.1990658938884735e-02
    z[6,3,5]  R1983     -3.3678838610649109e-01
    z[6,3,5]  R1984     1.4801153540611267e-01
    z[6,3,5]  R1985     -1.5591630339622498e-01
    z[6,3,5]  R1986     -3.3089622855186462e-01
    z[6,3,5]  R1987     -3.6007410287857056e-01
    z[6,3,5]  R1988     -4.1901135444641113e-01
    z[6,3,5]  R1989     -2.1696336567401886e-01
    z[6,3,5]  R1990     2.7509140968322754e-01
    z[6,3,5]  R1991     -3.1465375423431396e-01
    z[6,3,5]  R1992     -2.6323834061622620e-01
    z[6,3,5]  R1993     -1.2563192844390869e-01
    z[6,3,5]  R1994     -2.9858118295669556e-01
    z[6,3,5]  R1995     -3.3711439371109009e-01
    z[6,3,5]  R1996     3.8634178042411804e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1907     -1
    z[6,3,6]  R1908     1
    z[6,3,6]  R1909     2.6646783947944641e-01
    z[6,3,6]  R1910     1.3733452558517456e-01
    z[6,3,6]  R1911     1.0208512842655182e-01
    z[6,3,6]  R1912     -3.5303589701652527e-01
    z[6,3,6]  R1913     4.5818752050399780e-01
    z[6,3,6]  R1914     0.242108553647995
    z[6,3,6]  R1915     2.7308214455842972e-02
    z[6,3,6]  R1916     -2.9468801617622375e-01
    z[6,3,6]  R1917     -4.9768692255020142e-01
    z[6,3,6]  R1918     2.6096296310424805e-01
    z[6,3,6]  R1919     -2.9381856322288513e-01
    z[6,3,6]  R1920     5.3373958915472031e-02
    z[6,3,6]  R1921     -1.4346466958522797e-01
    z[6,3,6]  R1922     -2.6347804069519043e-01
    z[6,3,6]  R1923     -2.9278692603111267e-01
    z[6,3,6]  R1924     -7.4396848678588867e-02
    z[6,3,6]  R1925     2.9214599728584290e-01
    z[6,3,6]  R1926     -4.1162124276161194e-01
    z[6,3,6]  R1927     -2.9800674319267273e-01
    z[6,3,6]  R1928     -2.4290467798709869e-01
    z[6,3,6]  R1929     4.6672880649566650e-02
    z[6,3,6]  R1930     -3.5432377457618713e-01
    z[6,3,6]  R1931     -1.2061487138271332e-01
    z[6,3,6]  R1932     -3.0226796865463257e-01
    z[6,3,6]  R1933     6.0109067708253860e-03
    z[6,3,6]  R1934     -1.4585968852043152e-01
    z[6,3,6]  R1935     9.1197066009044647e-02
    z[6,3,6]  R1936     1.8935346603393555e-01
    z[6,3,6]  R1937     1.8424926698207855e-01
    z[6,3,6]  R1938     -2.7470108866691589e-01
    z[6,3,6]  R1939     -2.7024172246456146e-02
    z[6,3,6]  R1940     -9.2960305511951447e-02
    z[6,3,6]  R1941     1.5328544378280640e-01
    z[6,3,6]  R1942     4.0478572249412537e-01
    z[6,3,6]  R1943     8.5655406117439270e-02
    z[6,3,6]  R1944     5.5611610412597656e-01
    z[6,3,6]  R1945     5.8828455209732056e-01
    z[6,3,6]  R1946     -1.9911254942417145e-01
    z[6,3,6]  R1947     -5.8473336696624756e-01
    z[6,3,6]  R1948     -6.3331574201583862e-01
    z[6,3,6]  R1949     -1.2940365076065063e-01
    z[6,3,6]  R1950     1.3666908442974091e-01
    z[6,3,6]  R1951     4.9621118232607841e-03
    z[6,3,6]  R1952     -2.3997332155704498e-01
    z[6,3,6]  R1953     -1.7408396303653717e-01
    z[6,3,6]  R1954     -0.223873108625412
    z[6,3,6]  R1955     -3.0624959617853165e-02
    z[6,3,6]  R1956     -1.0289679467678070e-01
    z[6,3,6]  R1957     -2.9153700917959213e-02
    z[6,3,6]  R1958     1.6441315412521362e-01
    z[6,3,6]  R1959     -5.2010573446750641e-02
    z[6,3,6]  R1960     -2.6188856363296509e-01
    z[6,3,6]  R1961     -1.7743955552577972e-01
    z[6,3,6]  R1962     9.1521563008427620e-03
    z[6,3,6]  R1963     -0.0802517980337143
    z[6,3,6]  R1964     -1.7082595825195312e-01
    z[6,3,6]  R1965     -1.0478270053863525e-01
    z[6,3,6]  R1966     0.0362219400703907
    z[6,3,6]  R1967     2.0498305559158325e-02
    z[6,3,6]  R1968     1.9291643053293228e-02
    z[6,3,6]  R1969     -3.5813847184181213e-01
    z[6,3,6]  R1970     1.9769731163978577e-01
    z[6,3,6]  R1971     -4.9664962291717529e-01
    z[6,3,6]  R1972     1.7384378612041473e-01
    z[6,3,6]  R1973     3.8115769624710083e-02
    z[6,3,6]  R1974     2.1018664538860321e-01
    z[6,3,6]  R1975     -1.2856742739677429e-01
    z[6,3,6]  R1976     -1.3096508383750916e-01
    z[6,3,6]  R1977     -6.0381293296813965e-02
    z[6,3,6]  R1978     -4.1922357678413391e-01
    z[6,3,6]  R1979     -1.0657577216625214e-01
    z[6,3,6]  R1980     -3.2016387581825256e-01
    z[6,3,6]  R1981     6.2875300645828247e-01
    z[6,3,6]  R1982     -6.3919365406036377e-02
    z[6,3,6]  R1983     -6.0191076993942261e-01
    z[6,3,6]  R1984     -1.8667422235012054e-01
    z[6,3,6]  R1985     2.2959427535533905e-01
    z[6,3,6]  R1986     -2.4552170187234879e-02
    z[6,3,6]  R1987     3.8883426785469055e-01
    z[6,3,6]  R1988     0.190166175365448
    z[6,3,6]  R1989     -6.2794364988803864e-02
    z[6,3,6]  R1990     -6.0246515274047852e-01
    z[6,3,6]  R1991     -0.0921337753534317
    z[6,3,6]  R1992     5.1443153619766235e-01
    z[6,3,6]  R1993     2.5557265616953373e-03
    z[6,3,6]  R1994     -3.8667377084493637e-02
    z[6,3,6]  R1995     1.2433449923992157e-01
    z[6,3,6]  R1996     -1.7583039402961731e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2069     -1
    z[4,5,0]  R2070     1
    z[4,5,0]  R2083     -2.5392469018697739e-02
    z[4,5,0]  R2084     1.0203232616186142e-01
    z[4,5,0]  R2085     0.0551738440990448
    z[4,5,0]  R2086     3.4000761806964874e-02
    z[4,5,0]  R2087     1.6986259818077087e-01
    z[4,5,0]  R2088     8.4120273590087891e-01
    z[4,5,0]  R2089     6.4190936088562012e-01
    z[4,5,0]  R2090     8.0839961767196655e-01
    z[4,5,0]  R2091     3.1775695085525513e-01
    z[4,5,0]  R2092     -5.4890990257263184e-01
    z[4,5,0]  R2093     -5.3098142147064209e-01
    z[4,5,0]  R2094     -5.1513737440109253e-01
    z[4,5,0]  R2095     -5.3131037950515747e-01
    z[4,5,0]  R2096     5.3540289402008057e-01
    z[4,5,0]  R2097     5.3422939777374268e-01
    z[4,5,0]  R2098     4.5881351828575134e-01
    z[4,5,0]  R2099     5.3400319814682007e-01
    z[4,5,0]  R2100     2.5074765086174011e-01
    z[4,5,0]  R2101     5.8973252773284912e-01
    z[4,5,0]  R2102     -8.4130299091339111e-01
    z[4,5,0]  R2103     -2.4495464563369751e-01
    z[4,5,0]  R2104     7.4004429578781128e-01
    z[4,5,0]  R2105     8.2299959659576416e-01
    z[4,5,0]  R2106     6.7126452922821045e-01
    z[4,5,0]  R2107     5.6011730432510376e-01
    z[4,5,0]  R2108     7.4564450979232788e-01
    z[4,5,0]  R2109     8.5695606470108032e-01
    z[4,5,0]  R2110     6.5311104059219360e-01
    z[4,5,0]  R2111     3.7618693709373474e-01
    z[4,5,0]  R2112     3.7892970442771912e-01
    z[4,5,0]  R2113     6.7926585674285889e-01
    z[4,5,0]  R2114     5.6380158662796021e-01
    z[4,5,0]  R2115     8.2849204540252686e-01
    z[4,5,0]  R2116     5.0105530023574829e-01
    z[4,5,0]  R2117     4.3442982435226440e-01
    z[4,5,0]  R2118     8.3988642692565918e-01
    z[4,5,0]  R2119     3.2327917218208313e-01
    z[4,5,0]  R2120     2.8911077976226807e-01
    z[4,5,0]  R2121     4.1249915957450867e-01
    z[4,5,0]  R2122     3.2114568352699280e-01
    z[4,5,0]  R2123     1.2799820979125798e-04
    z[4,5,0]  R2124     5.5457610636949539e-02
    z[4,5,0]  R2125     5.2234575152397156e-02
    z[4,5,0]  R2126     8.2452498376369476e-02
    z[4,5,0]  R2127     4.3067926168441772e-01
    z[4,5,0]  R2128     -1.3426003046333790e-02
    z[4,5,0]  R2129     -2.3636072874069214e-02
    z[4,5,0]  R2130     5.2429482340812683e-02
    z[4,5,0]  R2131     -7.5056720525026321e-03
    z[4,5,0]  R2132     7.0652149617671967e-02
    z[4,5,0]  R2133     2.7111560106277466e-01
    z[4,5,0]  R2134     1.9415850937366486e-01
    z[4,5,0]  R2135     1.1719628423452377e-01
    z[4,5,0]  R2136     -7.2154819965362549e-02
    z[4,5,0]  R2137     -1.4037913084030151e-01
    z[4,5,0]  R2138     -5.4189842194318771e-03
    z[4,5,0]  R2139     1.1443827301263809e-01
    z[4,5,0]  R2140     -1.8866352736949921e-01
    z[4,5,0]  R2141     4.2419081926345825e-01
    z[4,5,0]  R2142     2.6447597146034241e-01
    z[4,5,0]  R2143     4.4845908880233765e-02
    z[4,5,0]  R2144     -7.4253201484680176e-02
    z[4,5,0]  R2145     -1.0336951166391373e-01
    z[4,5,0]  R2146     -2.4555101990699768e-03
    z[4,5,0]  R2147     -1.0886755585670471e-01
    z[4,5,0]  R2148     -4.8941407352685928e-02
    z[4,5,0]  R2149     -1.8093822896480560e-01
    z[4,5,0]  R2150     -1.2569734454154968e-01
    z[4,5,0]  R2151     1.0660402476787567e-01
    z[4,5,0]  R2152     1.9257423281669617e-01
    z[4,5,0]  R2153     2.3337945342063904e-01
    z[4,5,0]  R2154     2.6228129863739014e-01
    z[4,5,0]  R2155     3.3634158968925476e-01
    z[4,5,0]  R2156     -9.8939023911952972e-02
    z[4,5,0]  R2157     -4.1293105483055115e-01
    z[4,5,0]  R2158     2.5201907753944397e-01
    z[4,5,0]  R2159     -3.2411229610443115e-01
    z[4,5,0]  R2160     3.0029773712158203e-01
    z[4,5,0]  R2161     -1.3278488814830780e-01
    z[4,5,0]  R2162     -1.9313894212245941e-01
    z[4,5,0]  R2163     -0.614051342010498
    z[4,5,0]  R2164     3.2096934318542480e-01
    z[4,5,0]  R2165     3.5385772585868835e-02
    z[4,5,0]  R2166     -0.0406770296394825
    z[4,5,0]  R2167     -5.2866542339324951e-01
    z[4,5,0]  R2168     -4.5177474617958069e-01
    z[4,5,0]  R2169     4.5386098325252533e-02
    z[4,5,0]  R2170     -1.3763718307018280e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2071     -1
    z[4,5,1]  R2072     1
    z[4,5,1]  R2083     1.5553353726863861e-01
    z[4,5,1]  R2084     1.6742932796478271e-01
    z[4,5,1]  R2085     1.3639301061630249e-01
    z[4,5,1]  R2086     3.3267110586166382e-01
    z[4,5,1]  R2087     8.4872043132781982e-01
    z[4,5,1]  R2088     2.7506455779075623e-01
    z[4,5,1]  R2089     -3.9586371183395386e-01
    z[4,5,1]  R2090     6.0734614729881287e-02
    z[4,5,1]  R2091     -5.4834067821502686e-01
    z[4,5,1]  R2092     4.6457564830780029e-01
    z[4,5,1]  R2093     2.2648283839225769e-01
    z[4,5,1]  R2094     1.0711296647787094e-01
    z[4,5,1]  R2095     -3.5957047343254089e-01
    z[4,5,1]  R2096     -6.4243339002132416e-02
    z[4,5,1]  R2097     -1.0019612312316895e-01
    z[4,5,1]  R2098     -4.1654875874519348e-01
    z[4,5,1]  R2099     -2.7685368061065674e-01
    z[4,5,1]  R2100     -3.2248803973197937e-01
    z[4,5,1]  R2101     -4.5288011431694031e-02
    z[4,5,1]  R2102     -1.2615230679512024e-01
    z[4,5,1]  R2103     7.4578225612640381e-01
    z[4,5,1]  R2104     1.1409156024456024e-01
    z[4,5,1]  R2105     -2.9845565557479858e-01
    z[4,5,1]  R2106     -4.6609482169151306e-01
    z[4,5,1]  R2107     2.2150099277496338e-01
    z[4,5,1]  R2108     -2.2309708595275879e-01
    z[4,5,1]  R2109     -8.4515297785401344e-03
    z[4,5,1]  R2110     -2.4895490705966949e-01
    z[4,5,1]  R2111     -8.9898578822612762e-02
    z[4,5,1]  R2112     -2.9223543405532837e-01
    z[4,5,1]  R2113     1.1659777164459229e-01
    z[4,5,1]  R2114     -5.0466316938400269e-01
    z[4,5,1]  R2115     2.9510464519262314e-02
    z[4,5,1]  R2116     -2.6673266291618347e-01
    z[4,5,1]  R2117     -5.7460623979568481e-01
    z[4,5,1]  R2118     -4.6372163295745850e-01
    z[4,5,1]  R2119     -5.5609703063964844e-01
    z[4,5,1]  R2120     -7.3463952541351318e-01
    z[4,5,1]  R2121     -0.791696310043335
    z[4,5,1]  R2122     5.0134855508804321e-01
    z[4,5,1]  R2123     4.5813700556755066e-01
    z[4,5,1]  R2124     0.432682067155838
    z[4,5,1]  R2125     4.6237125992774963e-01
    z[4,5,1]  R2126     5.0908207893371582e-01
    z[4,5,1]  R2127     4.8563095927238464e-01
    z[4,5,1]  R2128     8.2065206766128540e-01
    z[4,5,1]  R2129     3.0611601471900940e-01
    z[4,5,1]  R2130     5.0296491384506226e-01
    z[4,5,1]  R2131     0.327528178691864
    z[4,5,1]  R2132     -8.1756854057312012e-01
    z[4,5,1]  R2133     -5.9623104333877563e-01
    z[4,5,1]  R2134     -7.5222784280776978e-01
    z[4,5,1]  R2135     -4.9451699852943420e-01
    z[4,5,1]  R2136     -6.9143062829971313e-01
    z[4,5,1]  R2137     -7.4074578285217285e-01
    z[4,5,1]  R2138     -6.7811751365661621e-01
    z[4,5,1]  R2139     -5.4823744297027588e-01
    z[4,5,1]  R2140     -0.549148678779602
    z[4,5,1]  R2141     -5.0057750940322876e-01
    z[4,5,1]  R2142     2.4117852747440338e-01
    z[4,5,1]  R2143     3.7038120627403259e-01
    z[4,5,1]  R2144     0.503020703792572
    z[4,5,1]  R2145     7.1465331315994263e-01
    z[4,5,1]  R2146     1.6307540237903595e-01
    z[4,5,1]  R2147     5.4639625549316406e-01
    z[4,5,1]  R2148     5.1106256246566772e-01
    z[4,5,1]  R2149     2.0135138928890228e-01
    z[4,5,1]  R2150     5.1603823900222778e-01
    z[4,5,1]  R2151     -4.3186736106872559e-01
    z[4,5,1]  R2152     7.7884471416473389e-01
    z[4,5,1]  R2153     0.612871527671814
    z[4,5,1]  R2154     1.5017915284261107e-03
    z[4,5,1]  R2155     1.7503488063812256e-01
    z[4,5,1]  R2156     6.4956796169281006e-01
    z[4,5,1]  R2157     5.9445953369140625e-01
    z[4,5,1]  R2158     1.1809966713190079e-01
    z[4,5,1]  R2159     -1.1558468639850616e-01
    z[4,5,1]  R2160     2.3782048374414444e-02
    z[4,5,1]  R2161     4.9197566509246826e-01
    z[4,5,1]  R2162     4.1021221876144409e-01
    z[4,5,1]  R2163     5.9973281621932983e-01
    z[4,5,1]  R2164     4.4935470819473267e-01
    z[4,5,1]  R2165     2.8569960594177246e-01
    z[4,5,1]  R2166     4.9081340432167053e-01
    z[4,5,1]  R2167     5.5745017528533936e-01
    z[4,5,1]  R2168     -8.5575558245182037e-02
    z[4,5,1]  R2169     5.8053910732269287e-01
    z[4,5,1]  R2170     -4.2640173435211182e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2073     -1
    z[4,5,2]  R2074     1
    z[4,5,2]  R2083     -3.3531033992767334e-01
    z[4,5,2]  R2084     -4.4973435997962952e-01
    z[4,5,2]  R2085     -6.0888135433197021e-01
    z[4,5,2]  R2086     -5.8807331323623657e-01
    z[4,5,2]  R2087     -5.0384733825922012e-02
    z[4,5,2]  R2088     2.8873598575592041e-01
    z[4,5,2]  R2089     3.9323827624320984e-01
    z[4,5,2]  R2090     2.6337489485740662e-01
    z[4,5,2]  R2091     3.6571112275123596e-01
    z[4,5,2]  R2092     -2.9900306463241577e-01
    z[4,5,2]  R2093     3.7387913465499878e-01
    z[4,5,2]  R2094     3.2314866781234741e-01
    z[4,5,2]  R2095     2.5590887665748596e-01
    z[4,5,2]  R2096     5.8135926723480225e-01
    z[4,5,2]  R2097     4.1173884272575378e-01
    z[4,5,2]  R2098     1.9148686528205872e-01
    z[4,5,2]  R2099     4.0773135423660278e-01
    z[4,5,2]  R2100     5.1898753643035889e-01
    z[4,5,2]  R2101     4.3880489468574524e-01
    z[4,5,2]  R2102     1.0552560538053513e-01
    z[4,5,2]  R2103     1.1646560579538345e-01
    z[4,5,2]  R2104     4.1714864969253540e-01
    z[4,5,2]  R2105     8.2238681614398956e-02
    z[4,5,2]  R2106     3.9859315752983093e-01
    z[4,5,2]  R2107     3.9502510428428650e-01
    z[4,5,2]  R2108     5.2484279870986938e-01
    z[4,5,2]  R2109     8.7059482932090759e-02
    z[4,5,2]  R2110     1.9846706092357635e-01
    z[4,5,2]  R2111     5.2390646934509277e-01
    z[4,5,2]  R2112     4.8633712530136108e-01
    z[4,5,2]  R2113     6.1409723758697510e-01
    z[4,5,2]  R2114     3.5800164937973022e-01
    z[4,5,2]  R2115     3.9475083351135254e-01
    z[4,5,2]  R2116     6.2169307470321655e-01
    z[4,5,2]  R2117     5.6073254346847534e-01
    z[4,5,2]  R2118     1.9272992014884949e-01
    z[4,5,2]  R2119     5.3977102041244507e-01
    z[4,5,2]  R2120     0.449907124042511
    z[4,5,2]  R2121     3.3825227618217468e-01
    z[4,5,2]  R2122     5.5939173698425293e-01
    z[4,5,2]  R2123     -9.1380871832370758e-02
    z[4,5,2]  R2124     -5.2853405475616455e-01
    z[4,5,2]  R2125     -7.1074366569519043e-01
    z[4,5,2]  R2126     -7.0286047458648682e-01
    z[4,5,2]  R2127     2.5660511851310730e-01
    z[4,5,2]  R2128     -3.3238753676414490e-01
    z[4,5,2]  R2129     -0.294884592294693
    z[4,5,2]  R2130     -6.1701703071594238e-01
    z[4,5,2]  R2131     -5.3743177652359009e-01
    z[4,5,2]  R2132     1.2026625871658325e-01
    z[4,5,2]  R2133     3.4989011287689209e-01
    z[4,5,2]  R2134     -1.1586213111877441e-01
    z[4,5,2]  R2135     -9.3651607632637024e-02
    z[4,5,2]  R2136     -3.5125061869621277e-01
    z[4,5,2]  R2137     2.9583710432052612e-01
    z[4,5,2]  R2138     1.0643537156283855e-02
    z[4,5,2]  R2139     -2.1485063433647156e-01
    z[4,5,2]  R2140     1.8233244121074677e-01
    z[4,5,2]  R2141     -4.7685351222753525e-02
    z[4,5,2]  R2142     -1.6669457778334618e-02
    z[4,5,2]  R2143     1.2669166922569275e-01
    z[4,5,2]  R2144     1.1230615526437759e-01
    z[4,5,2]  R2145     1.9065700471401215e-01
    z[4,5,2]  R2146     4.4778954982757568e-01
    z[4,5,2]  R2147     3.6488610506057739e-01
    z[4,5,2]  R2148     2.6896793395280838e-02
    z[4,5,2]  R2149     1.7822082340717316e-01
    z[4,5,2]  R2150     1.7628322541713715e-01
    z[4,5,2]  R2151     1.2772007286548615e-01
    z[4,5,2]  R2152     -2.4267971515655518e-01
    z[4,5,2]  R2153     -1.1833103001117706e-01
    z[4,5,2]  R2154     -2.2095292806625366e-01
    z[4,5,2]  R2155     2.4815934896469116e-01
    z[4,5,2]  R2156     0.269465833902359
    z[4,5,2]  R2157     2.2802762687206268e-01
    z[4,5,2]  R2158     2.2638346254825592e-01
    z[4,5,2]  R2159     -4.9153584241867065e-01
    z[4,5,2]  R2160     -1.8757960200309753e-01
    z[4,5,2]  R2161     1.7887100577354431e-01
    z[4,5,2]  R2162     -8.5737422108650208e-02
    z[4,5,2]  R2163     2.5774728506803513e-02
    z[4,5,2]  R2164     3.8702264428138733e-01
    z[4,5,2]  R2165     4.7996929287910461e-01
    z[4,5,2]  R2166     -3.9740979671478271e-01
    z[4,5,2]  R2167     4.5599198341369629e-01
    z[4,5,2]  R2168     -1.8403373658657074e-01
    z[4,5,2]  R2169     3.6123567819595337e-01
    z[4,5,2]  R2170     5.4145264625549316e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2075     -1
    z[4,5,3]  R2076     1
    z[4,5,3]  R2083     -2.0572341978549957e-01
    z[4,5,3]  R2084     -0.718946635723114
    z[4,5,3]  R2085     -4.0803977847099304e-01
    z[4,5,3]  R2086     -3.6046928167343140e-01
    z[4,5,3]  R2087     0.00858311913907528
    z[4,5,3]  R2088     6.1476852744817734e-02
    z[4,5,3]  R2089     -1.3553509116172791e-01
    z[4,5,3]  R2090     -1.1303997784852982e-01
    z[4,5,3]  R2091     -3.0554416775703430e-01
    z[4,5,3]  R2092     6.0953569412231445e-01
    z[4,5,3]  R2093     -0.520353376865387
    z[4,5,3]  R2094     6.1089444905519485e-02
    z[4,5,3]  R2095     -3.4144330024719238e-01
    z[4,5,3]  R2096     5.6526422500610352e-01
    z[4,5,3]  R2097     1.2899178266525269e-01
    z[4,5,3]  R2098     6.7346578836441040e-01
    z[4,5,3]  R2099     1.6318507492542267e-02
    z[4,5,3]  R2100     5.9263265132904053e-01
    z[4,5,3]  R2101     4.2944005131721497e-01
    z[4,5,3]  R2102     -4.1192913055419922e-01
    z[4,5,3]  R2103     -7.6644122600555420e-02
    z[4,5,3]  R2104     2.0884402096271515e-01
    z[4,5,3]  R2105     3.2799789309501648e-01
    z[4,5,3]  R2106     3.0698782205581665e-01
    z[4,5,3]  R2107     4.4939696788787842e-01
    z[4,5,3]  R2108     1.0506445914506912e-01
    z[4,5,3]  R2109     4.7404372692108154e-01
    z[4,5,3]  R2110     2.8486651182174683e-01
    z[4,5,3]  R2111     4.7162207961082458e-01
    z[4,5,3]  R2112     0.529949963092804
    z[4,5,3]  R2113     8.8852927088737488e-02
    z[4,5,3]  R2114     2.8940027952194214e-01
    z[4,5,3]  R2115     -1.3750459067523479e-02
    z[4,5,3]  R2116     -0.197368323802948
    z[4,5,3]  R2117     -2.3361812531948090e-01
    z[4,5,3]  R2118     -1.0043931752443314e-01
    z[4,5,3]  R2119     -4.6339428424835205e-01
    z[4,5,3]  R2120     -3.1964552402496338e-01
    z[4,5,3]  R2121     -1.7776307463645935e-01
    z[4,5,3]  R2122     1.5760849416255951e-01
    z[4,5,3]  R2123     2.3670193552970886e-01
    z[4,5,3]  R2124     7.3240667581558228e-02
    z[4,5,3]  R2125     5.2571866661310196e-02
    z[4,5,3]  R2126     1.6801701486110687e-01
    z[4,5,3]  R2127     2.7998885512351990e-01
    z[4,5,3]  R2128     3.1080448627471924e-01
    z[4,5,3]  R2129     6.3498966395854950e-02
    z[4,5,3]  R2130     -0.07258290797472
    z[4,5,3]  R2131     -1.0689292103052139e-01
    z[4,5,3]  R2132     -4.5449972152709961e-01
    z[4,5,3]  R2133     -5.6289356946945190e-01
    z[4,5,3]  R2134     -4.6246212720870972e-01
    z[4,5,3]  R2135     -0.708291232585907
    z[4,5,3]  R2136     -4.3603339791297913e-01
    z[4,5,3]  R2137     -3.6672791838645935e-01
    z[4,5,3]  R2138     -5.9832257032394409e-01
    z[4,5,3]  R2139     -0.545274555683136
    z[4,5,3]  R2140     -6.8221920728683472e-01
    z[4,5,3]  R2141     -5.6845504045486450e-01
    z[4,5,3]  R2142     5.5740290880203247e-01
    z[4,5,3]  R2143     0.578544020652771
    z[4,5,3]  R2144     -6.0288065671920776e-01
    z[4,5,3]  R2145     -3.4921801090240479e-01
    z[4,5,3]  R2146     6.2654447555541992e-01
    z[4,5,3]  R2147     -5.2741795778274536e-01
    z[4,5,3]  R2148     -7.4762272834777832e-01
    z[4,5,3]  R2149     3.4952321648597717e-01
    z[4,5,3]  R2150     5.9685643762350082e-02
    z[4,5,3]  R2151     8.6430960893630981e-01
    z[4,5,3]  R2152     2.3574048280715942e-01
    z[4,5,3]  R2153     5.7690471410751343e-01
    z[4,5,3]  R2154     8.9302927255630493e-01
    z[4,5,3]  R2155     9.8066650331020355e-02
    z[4,5,3]  R2156     -2.5251312181353569e-02
    z[4,5,3]  R2157     -6.1161148548126221e-01
    z[4,5,3]  R2158     5.6304007768630981e-01
    z[4,5,3]  R2159     0.721450924873352
    z[4,5,3]  R2160     -0.00906460452824831
    z[4,5,3]  R2161     -4.1713351011276245e-01
    z[4,5,3]  R2162     0.0668509304523468
    z[4,5,3]  R2163     -4.4703356921672821e-02
    z[4,5,3]  R2164     5.5620354413986206e-01
    z[4,5,3]  R2165     5.3038930892944336e-01
    z[4,5,3]  R2166     3.3827179670333862e-01
    z[4,5,3]  R2167     2.0165410637855530e-01
    z[4,5,3]  R2168     6.4370816946029663e-01
    z[4,5,3]  R2169     -1.5139554627239704e-02
    z[4,5,3]  R2170     5.7504045963287354e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2077     -1
    z[4,5,4]  R2078     1
    z[4,5,4]  R2083     5.1540863513946533e-01
    z[4,5,4]  R2084     4.0010219812393188e-01
    z[4,5,4]  R2085     5.1996868848800659e-01
    z[4,5,4]  R2086     -3.3404279500246048e-02
    z[4,5,4]  R2087     -6.8096712231636047e-02
    z[4,5,4]  R2088     -1.3788822293281555e-01
    z[4,5,4]  R2089     -2.3109939694404602e-01
    z[4,5,4]  R2090     -4.7391152381896973e-01
    z[4,5,4]  R2091     -3.2091453671455383e-01
    z[4,5,4]  R2092     -1.4757290482521057e-01
    z[4,5,4]  R2093     -3.8310667872428894e-01
    z[4,5,4]  R2094     2.7381709218025208e-01
    z[4,5,4]  R2095     4.2095455527305603e-01
    z[4,5,4]  R2096     1.7630970105528831e-02
    z[4,5,4]  R2097     3.8901785016059875e-01
    z[4,5,4]  R2098     3.2643833756446838e-01
    z[4,5,4]  R2099     -2.8026765584945679e-01
    z[4,5,4]  R2100     1.1587437987327576e-01
    z[4,5,4]  R2101     -5.0967586040496826e-01
    z[4,5,4]  R2102     2.3534177243709564e-01
    z[4,5,4]  R2103     1.1257145553827286e-02
    z[4,5,4]  R2104     -1.5665613114833832e-01
    z[4,5,4]  R2105     1.7417942872270942e-03
    z[4,5,4]  R2106     -2.6921004056930542e-01
    z[4,5,4]  R2107     3.3037438988685608e-02
    z[4,5,4]  R2108     -3.1110098958015442e-01
    z[4,5,4]  R2109     -0.0326436311006546
    z[4,5,4]  R2110     3.3059865236282349e-01
    z[4,5,4]  R2111     2.4304026365280151e-01
    z[4,5,4]  R2112     -1.0596216470003128e-01
    z[4,5,4]  R2113     -7.2717433795332909e-03
    z[4,5,4]  R2114     4.3784198164939880e-01
    z[4,5,4]  R2115     3.3182597160339355e-01
    z[4,5,4]  R2116     -3.3863988518714905e-01
    z[4,5,4]  R2117     7.8207127749919891e-02
    z[4,5,4]  R2118     1.2676453590393066e-01
    z[4,5,4]  R2119     0.0924171581864357
    z[4,5,4]  R2120     -1.1691863834857941e-01
    z[4,5,4]  R2121     -6.5099135041236877e-02
    z[4,5,4]  R2122     -5.2295696735382080e-01
    z[4,5,4]  R2123     -7.3008544743061066e-02
    z[4,5,4]  R2124     6.6151313483715057e-02
    z[4,5,4]  R2125     -3.2162305712699890e-01
    z[4,5,4]  R2126     0.0360804907977581
    z[4,5,4]  R2127     -3.5811248421669006e-01
    z[4,5,4]  R2128     -2.3946642875671387e-01
    z[4,5,4]  R2129     -2.9947438836097717e-01
    z[4,5,4]  R2130     -4.9453905224800110e-01
    z[4,5,4]  R2131     -3.8763910531997681e-01
    z[4,5,4]  R2132     -1.1475600302219391e-01
    z[4,5,4]  R2133     -4.1680745780467987e-03
    z[4,5,4]  R2134     2.9905638098716736e-01
    z[4,5,4]  R2135     7.8380726277828217e-02
    z[4,5,4]  R2136     2.1771165728569031e-01
    z[4,5,4]  R2137     2.9940694570541382e-01
    z[4,5,4]  R2138     4.2538410425186157e-01
    z[4,5,4]  R2139     -0.0423019640147686
    z[4,5,4]  R2140     2.6569724082946777e-01
    z[4,5,4]  R2141     5.8113500475883484e-02
    z[4,5,4]  R2142     -1.3618029654026031e-01
    z[4,5,4]  R2143     5.5409145355224609e-01
    z[4,5,4]  R2144     4.0063974261283875e-01
    z[4,5,4]  R2145     0.537505567073822
    z[4,5,4]  R2146     5.9833395481109619e-01
    z[4,5,4]  R2147     3.5292837023735046e-01
    z[4,5,4]  R2148     1.5173371136188507e-01
    z[4,5,4]  R2149     8.2123500108718872e-01
    z[4,5,4]  R2150     7.8610116243362427e-01
    z[4,5,4]  R2151     -3.6398649215698242e-02
    z[4,5,4]  R2152     1.8064025044441223e-01
    z[4,5,4]  R2153     0.0169846098870039
    z[4,5,4]  R2154     -2.3943005502223969e-01
    z[4,5,4]  R2155     -6.4937502145767212e-01
    z[4,5,4]  R2156     5.4747790098190308e-01
    z[4,5,4]  R2157     1.4513424038887024e-01
    z[4,5,4]  R2158     -2.9419302940368652e-01
    z[4,5,4]  R2159     2.1047417819499969e-01
    z[4,5,4]  R2160     -0.92336106300354
    z[4,5,4]  R2161     0.0594811849296093
    z[4,5,4]  R2162     5.9035980701446533e-01
    z[4,5,4]  R2163     -4.6010011434555054e-01
    z[4,5,4]  R2164     3.3176541328430176e-02
    z[4,5,4]  R2165     3.0229237675666809e-01
    z[4,5,4]  R2166     6.2527048587799072e-01
    z[4,5,4]  R2167     3.3453187346458435e-01
    z[4,5,4]  R2168     5.0589525699615479e-01
    z[4,5,4]  R2169     5.4702854156494141e-01
    z[4,5,4]  R2170     -4.0859675407409668e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2079     -1
    z[4,5,5]  R2080     1
    z[4,5,5]  R2083     3.6336949467658997e-01
    z[4,5,5]  R2084     2.8015589714050293e-01
    z[4,5,5]  R2085     -8.6010143160820007e-02
    z[4,5,5]  R2086     3.7844744324684143e-01
    z[4,5,5]  R2087     -4.9127709865570068e-01
    z[4,5,5]  R2088     1.2058693170547485e-01
    z[4,5,5]  R2089     3.4868514537811279e-01
    z[4,5,5]  R2090     6.8540379405021667e-02
    z[4,5,5]  R2091     -4.2214468121528625e-03
    z[4,5,5]  R2092     8.7181003764271736e-03
    z[4,5,5]  R2093     2.5557172298431396e-01
    z[4,5,5]  R2094     -6.2870115041732788e-01
    z[4,5,5]  R2095     -4.7782656550407410e-01
    z[4,5,5]  R2096     1.2138541787862778e-01
    z[4,5,5]  R2097     5.8549094200134277e-01
    z[4,5,5]  R2098     9.0634517371654510e-02
    z[4,5,5]  R2099     3.9740687608718872e-01
    z[4,5,5]  R2100     -4.0575500577688217e-02
    z[4,5,5]  R2101     -9.4991348683834076e-02
    z[4,5,5]  R2102     -1.9459149241447449e-01
    z[4,5,5]  R2103     -0.566662073135376
    z[4,5,5]  R2104     4.3897858262062073e-01
    z[4,5,5]  R2105     2.3217049241065979e-01
    z[4,5,5]  R2106     6.6998794674873352e-02
    z[4,5,5]  R2107     3.8771173357963562e-01
    z[4,5,5]  R2108     4.6987339854240417e-02
    z[4,5,5]  R2109     1.7671336233615875e-01
    z[4,5,5]  R2110     5.0558310747146606e-01
    z[4,5,5]  R2111     3.0969861149787903e-01
    z[4,5,5]  R2112     4.0456745028495789e-01
    z[4,5,5]  R2113     2.0982122421264648e-01
    z[4,5,5]  R2114     -1.5313214063644409e-01
    z[4,5,5]  R2115     -2.1586470305919647e-01
    z[4,5,5]  R2116     -0.335225373506546
    z[4,5,5]  R2117     -3.0429592728614807e-01
    z[4,5,5]  R2118     -1.2198971211910248e-01
    z[4,5,5]  R2119     -5.3398627787828445e-02
    z[4,5,5]  R2120     -0.00661705294623971
    z[4,5,5]  R2121     2.1670649945735931e-01
    z[4,5,5]  R2122     1.7254360020160675e-01
    z[4,5,5]  R2123     0.782616138458252
    z[4,5,5]  R2124     4.1756004095077515e-01
    z[4,5,5]  R2125     2.6718342304229736e-01
    z[4,5,5]  R2126     5.2473846822977066e-02
    z[4,5,5]  R2127     -1.7000629007816315e-01
    z[4,5,5]  R2128     -4.7777980566024780e-02
    z[4,5,5]  R2129     8.3798050880432129e-01
    z[4,5,5]  R2130     3.3537822961807251e-01
    z[4,5,5]  R2131     0.630859911441803
    z[4,5,5]  R2132     -2.0510685443878174e-01
    z[4,5,5]  R2133     -3.3171677589416504e-01
    z[4,5,5]  R2134     -4.5201838016510010e-02
    z[4,5,5]  R2135     -4.7424682974815369e-01
    z[4,5,5]  R2136     -3.8958451151847839e-01
    z[4,5,5]  R2137     -2.3353940248489380e-01
    z[4,5,5]  R2138     -3.1496521085500717e-02
    z[4,5,5]  R2139     -4.7385808825492859e-01
    z[4,5,5]  R2140     -3.0427780747413635e-01
    z[4,5,5]  R2141     -3.7121587991714478e-01
    z[4,5,5]  R2142     -5.8360165357589722e-01
    z[4,5,5]  R2143     -2.2560764849185944e-01
    z[4,5,5]  R2144     -0.407821923494339
    z[4,5,5]  R2145     1.6855373978614807e-01
    z[4,5,5]  R2146     1.0096298158168793e-01
    z[4,5,5]  R2147     -3.8624534010887146e-01
    z[4,5,5]  R2148     -3.9207586646080017e-01
    z[4,5,5]  R2149     2.3046796023845673e-01
    z[4,5,5]  R2150     -0.0591965913772583
    z[4,5,5]  R2151     -5.5470943450927734e-02
    z[4,5,5]  R2152     -3.2538297772407532e-01
    z[4,5,5]  R2153     -7.1658574044704437e-02
    z[4,5,5]  R2154     1.0443413257598877e-01
    z[4,5,5]  R2155     -0.562673032283783
    z[4,5,5]  R2156     3.3719030022621155e-01
    z[4,5,5]  R2157     -1.6899110376834869e-01
    z[4,5,5]  R2158     -0.410017728805542
    z[4,5,5]  R2159     5.1297504454851151e-02
    z[4,5,5]  R2160     -1.3205739855766296e-01
    z[4,5,5]  R2161     -1.3057488203048706e-01
    z[4,5,5]  R2162     6.3000130653381348e-01
    z[4,5,5]  R2163     1.3500395417213440e-01
    z[4,5,5]  R2164     -4.7661134600639343e-01
    z[4,5,5]  R2165     5.5322146415710449e-01
    z[4,5,5]  R2166     -5.1534615457057953e-02
    z[4,5,5]  R2167     4.5814774930477142e-02
    z[4,5,5]  R2168     1.0212268680334091e-01
    z[4,5,5]  R2169     1.0070103406906128e-01
    z[4,5,5]  R2170     -8.0719053745269775e-02
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2081     -1
    z[4,5,6]  R2082     1
    z[4,5,6]  R2083     -6.5017372369766235e-01
    z[4,5,6]  R2084     0.0619877427816391
    z[4,5,6]  R2085     4.0417158603668213e-01
    z[4,5,6]  R2086     5.1775211095809937e-01
    z[4,5,6]  R2087     -0.0470924936234951
    z[4,5,6]  R2088     3.0986329913139343e-01
    z[4,5,6]  R2089     -2.8853079676628113e-01
    z[4,5,6]  R2090     1.7710734903812408e-01
    z[4,5,6]  R2091     5.1792579889297485e-01
    z[4,5,6]  R2092     8.7738549336791039e-03
    z[4,5,6]  R2093     -0.210055410861969
    z[4,5,6]  R2094     -3.8047656416893005e-01
    z[4,5,6]  R2095     -2.8715729713439941e-02
    z[4,5,6]  R2096     -0.19149149954319
    z[4,5,6]  R2097     1.5574800968170166e-01
    z[4,5,6]  R2098     1.0477259755134583e-01
    z[4,5,6]  R2099     4.8497340083122253e-01
    z[4,5,6]  R2100     4.4440111517906189e-01
    z[4,5,6]  R2101     -6.6356673836708069e-02
    z[4,5,6]  R2102     4.7136954963207245e-02
    z[4,5,6]  R2103     -2.0768925547599792e-01
    z[4,5,6]  R2104     -6.6673986613750458e-02
    z[4,5,6]  R2105     2.5562450289726257e-01
    z[4,5,6]  R2106     4.5592587441205978e-02
    z[4,5,6]  R2107     3.5747972130775452e-01
    z[4,5,6]  R2108     9.3551538884639740e-02
    z[4,5,6]  R2109     3.1063543632626534e-02
    z[4,5,6]  R2110     1.6130568087100983e-01
    z[4,5,6]  R2111     4.4554957747459412e-01
    z[4,5,6]  R2112     2.8060135245323181e-01
    z[4,5,6]  R2113     3.0970117449760437e-01
    z[4,5,6]  R2114     -1.9239617511630058e-02
    z[4,5,6]  R2115     2.5689511094242334e-03
    z[4,5,6]  R2116     1.5902109444141388e-01
    z[4,5,6]  R2117     -1.1570470035076141e-01
    z[4,5,6]  R2118     3.7005368620157242e-02
    z[4,5,6]  R2119     -2.6223507523536682e-01
    z[4,5,6]  R2120     2.4169474840164185e-01
    z[4,5,6]  R2121     7.6468706130981445e-02
    z[4,5,6]  R2122     -6.7084066569805145e-02
    z[4,5,6]  R2123     3.2850247621536255e-01
    z[4,5,6]  R2124     5.8844357728958130e-01
    z[4,5,6]  R2125     3.1738871335983276e-01
    z[4,5,6]  R2126     4.5578393340110779e-01
    z[4,5,6]  R2127     5.2658468484878540e-01
    z[4,5,6]  R2128     -2.4421733617782593e-01
    z[4,5,6]  R2129     -1.5115892887115479e-01
    z[4,5,6]  R2130     -3.5378482192754745e-02
    z[4,5,6]  R2131     2.1014676988124847e-01
    z[4,5,6]  R2132     2.2431743144989014e-01
    z[4,5,6]  R2133     1.4723828434944153e-01
    z[4,5,6]  R2134     2.7871602773666382e-01
    z[4,5,6]  R2135     -1.4741206541657448e-02
    z[4,5,6]  R2136     -6.3567437231540680e-02
    z[4,5,6]  R2137     2.5572484731674194e-01
    z[4,5,6]  R2138     -8.9660808444023132e-03
    z[4,5,6]  R2139     3.4135526418685913e-01
    z[4,5,6]  R2140     3.1523339450359344e-02
    z[4,5,6]  R2141     3.2076603174209595e-01
    z[4,5,6]  R2142     -4.4919201731681824e-01
    z[4,5,6]  R2143     -3.9003399014472961e-01
    z[4,5,6]  R2144     1.9633628427982330e-01
    z[4,5,6]  R2145     -5.4399389773607254e-02
    z[4,5,6]  R2146     -1.1013595014810562e-01
    z[4,5,6]  R2147     -6.7405253648757935e-02
    z[4,5,6]  R2148     3.1717678066343069e-03
    z[4,5,6]  R2149     -2.1271444857120514e-01
    z[4,5,6]  R2150     -2.4861088395118713e-01
    z[4,5,6]  R2151     -1.8542063236236572e-01
    z[4,5,6]  R2152     -3.2147186994552612e-01
    z[4,5,6]  R2153     -4.6655958890914917e-01
    z[4,5,6]  R2154     -1.2904070317745209e-01
    z[4,5,6]  R2155     -2.1621312201023102e-01
    z[4,5,6]  R2156     -2.8564631938934326e-01
    z[4,5,6]  R2157     -2.0460499450564384e-02
    z[4,5,6]  R2158     -0.547367513179779
    z[4,5,6]  R2159     -2.6937276124954224e-01
    z[4,5,6]  R2160     -6.2870413064956665e-02
    z[4,5,6]  R2161     -7.1676015853881836e-01
    z[4,5,6]  R2162     -1.9281332194805145e-01
    z[4,5,6]  R2163     1.7515836656093597e-01
    z[4,5,6]  R2164     -8.7471000850200653e-02
    z[4,5,6]  R2165     -8.9473605155944824e-02
    z[4,5,6]  R2166     -3.0243399739265442e-01
    z[4,5,6]  R2167     2.1716007590293884e-01
    z[4,5,6]  R2168     2.7200832962989807e-01
    z[4,5,6]  R2169     4.6990740299224854e-01
    z[4,5,6]  R2170     0.0439128652215004
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2171     -1
    z[5,4,0]  R2172     1
    z[5,4,0]  R2185     3.2114568352699280e-01
    z[5,4,0]  R2186     1.2799820979125798e-04
    z[5,4,0]  R2187     5.5457610636949539e-02
    z[5,4,0]  R2188     5.2234575152397156e-02
    z[5,4,0]  R2189     8.2452498376369476e-02
    z[5,4,0]  R2190     4.3067926168441772e-01
    z[5,4,0]  R2191     -1.3426003046333790e-02
    z[5,4,0]  R2192     -2.3636072874069214e-02
    z[5,4,0]  R2193     5.2429482340812683e-02
    z[5,4,0]  R2194     -7.5056720525026321e-03
    z[5,4,0]  R2195     7.0652149617671967e-02
    z[5,4,0]  R2196     2.7111560106277466e-01
    z[5,4,0]  R2197     1.9415850937366486e-01
    z[5,4,0]  R2198     1.1719628423452377e-01
    z[5,4,0]  R2199     -7.2154819965362549e-02
    z[5,4,0]  R2200     -1.4037913084030151e-01
    z[5,4,0]  R2201     -5.4189842194318771e-03
    z[5,4,0]  R2202     1.1443827301263809e-01
    z[5,4,0]  R2203     -1.8866352736949921e-01
    z[5,4,0]  R2204     4.2419081926345825e-01
    z[5,4,0]  R2205     2.6447597146034241e-01
    z[5,4,0]  R2206     4.4845908880233765e-02
    z[5,4,0]  R2207     -7.4253201484680176e-02
    z[5,4,0]  R2208     -1.0336951166391373e-01
    z[5,4,0]  R2209     -2.4555101990699768e-03
    z[5,4,0]  R2210     -1.0886755585670471e-01
    z[5,4,0]  R2211     -4.8941407352685928e-02
    z[5,4,0]  R2212     -1.8093822896480560e-01
    z[5,4,0]  R2213     -1.2569734454154968e-01
    z[5,4,0]  R2214     1.0660402476787567e-01
    z[5,4,0]  R2215     1.9257423281669617e-01
    z[5,4,0]  R2216     2.3337945342063904e-01
    z[5,4,0]  R2217     2.6228129863739014e-01
    z[5,4,0]  R2218     3.3634158968925476e-01
    z[5,4,0]  R2219     -9.8939023911952972e-02
    z[5,4,0]  R2220     -4.1293105483055115e-01
    z[5,4,0]  R2221     2.5201907753944397e-01
    z[5,4,0]  R2222     -3.2411229610443115e-01
    z[5,4,0]  R2223     3.0029773712158203e-01
    z[5,4,0]  R2224     -1.3278488814830780e-01
    z[5,4,0]  R2225     -1.9313894212245941e-01
    z[5,4,0]  R2226     -0.614051342010498
    z[5,4,0]  R2227     3.2096934318542480e-01
    z[5,4,0]  R2228     3.5385772585868835e-02
    z[5,4,0]  R2229     -0.0406770296394825
    z[5,4,0]  R2230     -5.2866542339324951e-01
    z[5,4,0]  R2231     -4.5177474617958069e-01
    z[5,4,0]  R2232     4.5386098325252533e-02
    z[5,4,0]  R2233     -1.3763718307018280e-01
    z[5,4,0]  R2234     -2.5392469018697739e-02
    z[5,4,0]  R2235     1.0203232616186142e-01
    z[5,4,0]  R2236     0.0551738440990448
    z[5,4,0]  R2237     3.4000761806964874e-02
    z[5,4,0]  R2238     1.6986259818077087e-01
    z[5,4,0]  R2239     8.4120273590087891e-01
    z[5,4,0]  R2240     6.4190936088562012e-01
    z[5,4,0]  R2241     8.0839961767196655e-01
    z[5,4,0]  R2242     3.1775695085525513e-01
    z[5,4,0]  R2243     -5.4890990257263184e-01
    z[5,4,0]  R2244     -5.3098142147064209e-01
    z[5,4,0]  R2245     -5.1513737440109253e-01
    z[5,4,0]  R2246     -5.3131037950515747e-01
    z[5,4,0]  R2247     5.3540289402008057e-01
    z[5,4,0]  R2248     5.3422939777374268e-01
    z[5,4,0]  R2249     4.5881351828575134e-01
    z[5,4,0]  R2250     5.3400319814682007e-01
    z[5,4,0]  R2251     2.5074765086174011e-01
    z[5,4,0]  R2252     5.8973252773284912e-01
    z[5,4,0]  R2253     -8.4130299091339111e-01
    z[5,4,0]  R2254     -2.4495464563369751e-01
    z[5,4,0]  R2255     7.4004429578781128e-01
    z[5,4,0]  R2256     8.2299959659576416e-01
    z[5,4,0]  R2257     6.7126452922821045e-01
    z[5,4,0]  R2258     5.6011730432510376e-01
    z[5,4,0]  R2259     7.4564450979232788e-01
    z[5,4,0]  R2260     8.5695606470108032e-01
    z[5,4,0]  R2261     6.5311104059219360e-01
    z[5,4,0]  R2262     3.7618693709373474e-01
    z[5,4,0]  R2263     3.7892970442771912e-01
    z[5,4,0]  R2264     6.7926585674285889e-01
    z[5,4,0]  R2265     5.6380158662796021e-01
    z[5,4,0]  R2266     8.2849204540252686e-01
    z[5,4,0]  R2267     5.0105530023574829e-01
    z[5,4,0]  R2268     4.3442982435226440e-01
    z[5,4,0]  R2269     8.3988642692565918e-01
    z[5,4,0]  R2270     3.2327917218208313e-01
    z[5,4,0]  R2271     2.8911077976226807e-01
    z[5,4,0]  R2272     4.1249915957450867e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2173     -1
    z[5,4,1]  R2174     1
    z[5,4,1]  R2185     5.0134855508804321e-01
    z[5,4,1]  R2186     4.5813700556755066e-01
    z[5,4,1]  R2187     0.432682067155838
    z[5,4,1]  R2188     4.6237125992774963e-01
    z[5,4,1]  R2189     5.0908207893371582e-01
    z[5,4,1]  R2190     4.8563095927238464e-01
    z[5,4,1]  R2191     8.2065206766128540e-01
    z[5,4,1]  R2192     3.0611601471900940e-01
    z[5,4,1]  R2193     5.0296491384506226e-01
    z[5,4,1]  R2194     0.327528178691864
    z[5,4,1]  R2195     -8.1756854057312012e-01
    z[5,4,1]  R2196     -5.9623104333877563e-01
    z[5,4,1]  R2197     -7.5222784280776978e-01
    z[5,4,1]  R2198     -4.9451699852943420e-01
    z[5,4,1]  R2199     -6.9143062829971313e-01
    z[5,4,1]  R2200     -7.4074578285217285e-01
    z[5,4,1]  R2201     -6.7811751365661621e-01
    z[5,4,1]  R2202     -5.4823744297027588e-01
    z[5,4,1]  R2203     -0.549148678779602
    z[5,4,1]  R2204     -5.0057750940322876e-01
    z[5,4,1]  R2205     2.4117852747440338e-01
    z[5,4,1]  R2206     3.7038120627403259e-01
    z[5,4,1]  R2207     0.503020703792572
    z[5,4,1]  R2208     7.1465331315994263e-01
    z[5,4,1]  R2209     1.6307540237903595e-01
    z[5,4,1]  R2210     5.4639625549316406e-01
    z[5,4,1]  R2211     5.1106256246566772e-01
    z[5,4,1]  R2212     2.0135138928890228e-01
    z[5,4,1]  R2213     5.1603823900222778e-01
    z[5,4,1]  R2214     -4.3186736106872559e-01
    z[5,4,1]  R2215     7.7884471416473389e-01
    z[5,4,1]  R2216     0.612871527671814
    z[5,4,1]  R2217     1.5017915284261107e-03
    z[5,4,1]  R2218     1.7503488063812256e-01
    z[5,4,1]  R2219     6.4956796169281006e-01
    z[5,4,1]  R2220     5.9445953369140625e-01
    z[5,4,1]  R2221     1.1809966713190079e-01
    z[5,4,1]  R2222     -1.1558468639850616e-01
    z[5,4,1]  R2223     2.3782048374414444e-02
    z[5,4,1]  R2224     4.9197566509246826e-01
    z[5,4,1]  R2225     4.1021221876144409e-01
    z[5,4,1]  R2226     5.9973281621932983e-01
    z[5,4,1]  R2227     4.4935470819473267e-01
    z[5,4,1]  R2228     2.8569960594177246e-01
    z[5,4,1]  R2229     4.9081340432167053e-01
    z[5,4,1]  R2230     5.5745017528533936e-01
    z[5,4,1]  R2231     -8.5575558245182037e-02
    z[5,4,1]  R2232     5.8053910732269287e-01
    z[5,4,1]  R2233     -4.2640173435211182e-01
    z[5,4,1]  R2234     1.5553353726863861e-01
    z[5,4,1]  R2235     1.6742932796478271e-01
    z[5,4,1]  R2236     1.3639301061630249e-01
    z[5,4,1]  R2237     3.3267110586166382e-01
    z[5,4,1]  R2238     8.4872043132781982e-01
    z[5,4,1]  R2239     2.7506455779075623e-01
    z[5,4,1]  R2240     -3.9586371183395386e-01
    z[5,4,1]  R2241     6.0734614729881287e-02
    z[5,4,1]  R2242     -5.4834067821502686e-01
    z[5,4,1]  R2243     4.6457564830780029e-01
    z[5,4,1]  R2244     2.2648283839225769e-01
    z[5,4,1]  R2245     1.0711296647787094e-01
    z[5,4,1]  R2246     -3.5957047343254089e-01
    z[5,4,1]  R2247     -6.4243339002132416e-02
    z[5,4,1]  R2248     -1.0019612312316895e-01
    z[5,4,1]  R2249     -4.1654875874519348e-01
    z[5,4,1]  R2250     -2.7685368061065674e-01
    z[5,4,1]  R2251     -3.2248803973197937e-01
    z[5,4,1]  R2252     -4.5288011431694031e-02
    z[5,4,1]  R2253     -1.2615230679512024e-01
    z[5,4,1]  R2254     7.4578225612640381e-01
    z[5,4,1]  R2255     1.1409156024456024e-01
    z[5,4,1]  R2256     -2.9845565557479858e-01
    z[5,4,1]  R2257     -4.6609482169151306e-01
    z[5,4,1]  R2258     2.2150099277496338e-01
    z[5,4,1]  R2259     -2.2309708595275879e-01
    z[5,4,1]  R2260     -8.4515297785401344e-03
    z[5,4,1]  R2261     -2.4895490705966949e-01
    z[5,4,1]  R2262     -8.9898578822612762e-02
    z[5,4,1]  R2263     -2.9223543405532837e-01
    z[5,4,1]  R2264     1.1659777164459229e-01
    z[5,4,1]  R2265     -5.0466316938400269e-01
    z[5,4,1]  R2266     2.9510464519262314e-02
    z[5,4,1]  R2267     -2.6673266291618347e-01
    z[5,4,1]  R2268     -5.7460623979568481e-01
    z[5,4,1]  R2269     -4.6372163295745850e-01
    z[5,4,1]  R2270     -5.5609703063964844e-01
    z[5,4,1]  R2271     -7.3463952541351318e-01
    z[5,4,1]  R2272     -0.791696310043335
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2175     -1
    z[5,4,2]  R2176     1
    z[5,4,2]  R2185     5.5939173698425293e-01
    z[5,4,2]  R2186     -9.1380871832370758e-02
    z[5,4,2]  R2187     -5.2853405475616455e-01
    z[5,4,2]  R2188     -7.1074366569519043e-01
    z[5,4,2]  R2189     -7.0286047458648682e-01
    z[5,4,2]  R2190     2.5660511851310730e-01
    z[5,4,2]  R2191     -3.3238753676414490e-01
    z[5,4,2]  R2192     -0.294884592294693
    z[5,4,2]  R2193     -6.1701703071594238e-01
    z[5,4,2]  R2194     -5.3743177652359009e-01
    z[5,4,2]  R2195     1.2026625871658325e-01
    z[5,4,2]  R2196     3.4989011287689209e-01
    z[5,4,2]  R2197     -1.1586213111877441e-01
    z[5,4,2]  R2198     -9.3651607632637024e-02
    z[5,4,2]  R2199     -3.5125061869621277e-01
    z[5,4,2]  R2200     2.9583710432052612e-01
    z[5,4,2]  R2201     1.0643537156283855e-02
    z[5,4,2]  R2202     -2.1485063433647156e-01
    z[5,4,2]  R2203     1.8233244121074677e-01
    z[5,4,2]  R2204     -4.7685351222753525e-02
    z[5,4,2]  R2205     -1.6669457778334618e-02
    z[5,4,2]  R2206     1.2669166922569275e-01
    z[5,4,2]  R2207     1.1230615526437759e-01
    z[5,4,2]  R2208     1.9065700471401215e-01
    z[5,4,2]  R2209     4.4778954982757568e-01
    z[5,4,2]  R2210     3.6488610506057739e-01
    z[5,4,2]  R2211     2.6896793395280838e-02
    z[5,4,2]  R2212     1.7822082340717316e-01
    z[5,4,2]  R2213     1.7628322541713715e-01
    z[5,4,2]  R2214     1.2772007286548615e-01
    z[5,4,2]  R2215     -2.4267971515655518e-01
    z[5,4,2]  R2216     -1.1833103001117706e-01
    z[5,4,2]  R2217     -2.2095292806625366e-01
    z[5,4,2]  R2218     2.4815934896469116e-01
    z[5,4,2]  R2219     0.269465833902359
    z[5,4,2]  R2220     2.2802762687206268e-01
    z[5,4,2]  R2221     2.2638346254825592e-01
    z[5,4,2]  R2222     -4.9153584241867065e-01
    z[5,4,2]  R2223     -1.8757960200309753e-01
    z[5,4,2]  R2224     1.7887100577354431e-01
    z[5,4,2]  R2225     -8.5737422108650208e-02
    z[5,4,2]  R2226     2.5774728506803513e-02
    z[5,4,2]  R2227     3.8702264428138733e-01
    z[5,4,2]  R2228     4.7996929287910461e-01
    z[5,4,2]  R2229     -3.9740979671478271e-01
    z[5,4,2]  R2230     4.5599198341369629e-01
    z[5,4,2]  R2231     -1.8403373658657074e-01
    z[5,4,2]  R2232     3.6123567819595337e-01
    z[5,4,2]  R2233     5.4145264625549316e-01
    z[5,4,2]  R2234     -3.3531033992767334e-01
    z[5,4,2]  R2235     -4.4973435997962952e-01
    z[5,4,2]  R2236     -6.0888135433197021e-01
    z[5,4,2]  R2237     -5.8807331323623657e-01
    z[5,4,2]  R2238     -5.0384733825922012e-02
    z[5,4,2]  R2239     2.8873598575592041e-01
    z[5,4,2]  R2240     3.9323827624320984e-01
    z[5,4,2]  R2241     2.6337489485740662e-01
    z[5,4,2]  R2242     3.6571112275123596e-01
    z[5,4,2]  R2243     -2.9900306463241577e-01
    z[5,4,2]  R2244     3.7387913465499878e-01
    z[5,4,2]  R2245     3.2314866781234741e-01
    z[5,4,2]  R2246     2.5590887665748596e-01
    z[5,4,2]  R2247     5.8135926723480225e-01
    z[5,4,2]  R2248     4.1173884272575378e-01
    z[5,4,2]  R2249     1.9148686528205872e-01
    z[5,4,2]  R2250     4.0773135423660278e-01
    z[5,4,2]  R2251     5.1898753643035889e-01
    z[5,4,2]  R2252     4.3880489468574524e-01
    z[5,4,2]  R2253     1.0552560538053513e-01
    z[5,4,2]  R2254     1.1646560579538345e-01
    z[5,4,2]  R2255     4.1714864969253540e-01
    z[5,4,2]  R2256     8.2238681614398956e-02
    z[5,4,2]  R2257     3.9859315752983093e-01
    z[5,4,2]  R2258     3.9502510428428650e-01
    z[5,4,2]  R2259     5.2484279870986938e-01
    z[5,4,2]  R2260     8.7059482932090759e-02
    z[5,4,2]  R2261     1.9846706092357635e-01
    z[5,4,2]  R2262     5.2390646934509277e-01
    z[5,4,2]  R2263     4.8633712530136108e-01
    z[5,4,2]  R2264     6.1409723758697510e-01
    z[5,4,2]  R2265     3.5800164937973022e-01
    z[5,4,2]  R2266     3.9475083351135254e-01
    z[5,4,2]  R2267     6.2169307470321655e-01
    z[5,4,2]  R2268     5.6073254346847534e-01
    z[5,4,2]  R2269     1.9272992014884949e-01
    z[5,4,2]  R2270     5.3977102041244507e-01
    z[5,4,2]  R2271     0.449907124042511
    z[5,4,2]  R2272     3.3825227618217468e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2177     -1
    z[5,4,3]  R2178     1
    z[5,4,3]  R2185     1.5760849416255951e-01
    z[5,4,3]  R2186     2.3670193552970886e-01
    z[5,4,3]  R2187     7.3240667581558228e-02
    z[5,4,3]  R2188     5.2571866661310196e-02
    z[5,4,3]  R2189     1.6801701486110687e-01
    z[5,4,3]  R2190     2.7998885512351990e-01
    z[5,4,3]  R2191     3.1080448627471924e-01
    z[5,4,3]  R2192     6.3498966395854950e-02
    z[5,4,3]  R2193     -0.07258290797472
    z[5,4,3]  R2194     -1.0689292103052139e-01
    z[5,4,3]  R2195     -4.5449972152709961e-01
    z[5,4,3]  R2196     -5.6289356946945190e-01
    z[5,4,3]  R2197     -4.6246212720870972e-01
    z[5,4,3]  R2198     -0.708291232585907
    z[5,4,3]  R2199     -4.3603339791297913e-01
    z[5,4,3]  R2200     -3.6672791838645935e-01
    z[5,4,3]  R2201     -5.9832257032394409e-01
    z[5,4,3]  R2202     -0.545274555683136
    z[5,4,3]  R2203     -6.8221920728683472e-01
    z[5,4,3]  R2204     -5.6845504045486450e-01
    z[5,4,3]  R2205     5.5740290880203247e-01
    z[5,4,3]  R2206     0.578544020652771
    z[5,4,3]  R2207     -6.0288065671920776e-01
    z[5,4,3]  R2208     -3.4921801090240479e-01
    z[5,4,3]  R2209     6.2654447555541992e-01
    z[5,4,3]  R2210     -5.2741795778274536e-01
    z[5,4,3]  R2211     -7.4762272834777832e-01
    z[5,4,3]  R2212     3.4952321648597717e-01
    z[5,4,3]  R2213     5.9685643762350082e-02
    z[5,4,3]  R2214     8.6430960893630981e-01
    z[5,4,3]  R2215     2.3574048280715942e-01
    z[5,4,3]  R2216     5.7690471410751343e-01
    z[5,4,3]  R2217     8.9302927255630493e-01
    z[5,4,3]  R2218     9.8066650331020355e-02
    z[5,4,3]  R2219     -2.5251312181353569e-02
    z[5,4,3]  R2220     -6.1161148548126221e-01
    z[5,4,3]  R2221     5.6304007768630981e-01
    z[5,4,3]  R2222     0.721450924873352
    z[5,4,3]  R2223     -0.00906460452824831
    z[5,4,3]  R2224     -4.1713351011276245e-01
    z[5,4,3]  R2225     0.0668509304523468
    z[5,4,3]  R2226     -4.4703356921672821e-02
    z[5,4,3]  R2227     5.5620354413986206e-01
    z[5,4,3]  R2228     5.3038930892944336e-01
    z[5,4,3]  R2229     3.3827179670333862e-01
    z[5,4,3]  R2230     2.0165410637855530e-01
    z[5,4,3]  R2231     6.4370816946029663e-01
    z[5,4,3]  R2232     -1.5139554627239704e-02
    z[5,4,3]  R2233     5.7504045963287354e-01
    z[5,4,3]  R2234     -2.0572341978549957e-01
    z[5,4,3]  R2235     -0.718946635723114
    z[5,4,3]  R2236     -4.0803977847099304e-01
    z[5,4,3]  R2237     -3.6046928167343140e-01
    z[5,4,3]  R2238     0.00858311913907528
    z[5,4,3]  R2239     6.1476852744817734e-02
    z[5,4,3]  R2240     -1.3553509116172791e-01
    z[5,4,3]  R2241     -1.1303997784852982e-01
    z[5,4,3]  R2242     -3.0554416775703430e-01
    z[5,4,3]  R2243     6.0953569412231445e-01
    z[5,4,3]  R2244     -0.520353376865387
    z[5,4,3]  R2245     6.1089444905519485e-02
    z[5,4,3]  R2246     -3.4144330024719238e-01
    z[5,4,3]  R2247     5.6526422500610352e-01
    z[5,4,3]  R2248     1.2899178266525269e-01
    z[5,4,3]  R2249     6.7346578836441040e-01
    z[5,4,3]  R2250     1.6318507492542267e-02
    z[5,4,3]  R2251     5.9263265132904053e-01
    z[5,4,3]  R2252     4.2944005131721497e-01
    z[5,4,3]  R2253     -4.1192913055419922e-01
    z[5,4,3]  R2254     -7.6644122600555420e-02
    z[5,4,3]  R2255     2.0884402096271515e-01
    z[5,4,3]  R2256     3.2799789309501648e-01
    z[5,4,3]  R2257     3.0698782205581665e-01
    z[5,4,3]  R2258     4.4939696788787842e-01
    z[5,4,3]  R2259     1.0506445914506912e-01
    z[5,4,3]  R2260     4.7404372692108154e-01
    z[5,4,3]  R2261     2.8486651182174683e-01
    z[5,4,3]  R2262     4.7162207961082458e-01
    z[5,4,3]  R2263     0.529949963092804
    z[5,4,3]  R2264     8.8852927088737488e-02
    z[5,4,3]  R2265     2.8940027952194214e-01
    z[5,4,3]  R2266     -1.3750459067523479e-02
    z[5,4,3]  R2267     -0.197368323802948
    z[5,4,3]  R2268     -2.3361812531948090e-01
    z[5,4,3]  R2269     -1.0043931752443314e-01
    z[5,4,3]  R2270     -4.6339428424835205e-01
    z[5,4,3]  R2271     -3.1964552402496338e-01
    z[5,4,3]  R2272     -1.7776307463645935e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2179     -1
    z[5,4,4]  R2180     1
    z[5,4,4]  R2185     -5.2295696735382080e-01
    z[5,4,4]  R2186     -7.3008544743061066e-02
    z[5,4,4]  R2187     6.6151313483715057e-02
    z[5,4,4]  R2188     -3.2162305712699890e-01
    z[5,4,4]  R2189     0.0360804907977581
    z[5,4,4]  R2190     -3.5811248421669006e-01
    z[5,4,4]  R2191     -2.3946642875671387e-01
    z[5,4,4]  R2192     -2.9947438836097717e-01
    z[5,4,4]  R2193     -4.9453905224800110e-01
    z[5,4,4]  R2194     -3.8763910531997681e-01
    z[5,4,4]  R2195     -1.1475600302219391e-01
    z[5,4,4]  R2196     -4.1680745780467987e-03
    z[5,4,4]  R2197     2.9905638098716736e-01
    z[5,4,4]  R2198     7.8380726277828217e-02
    z[5,4,4]  R2199     2.1771165728569031e-01
    z[5,4,4]  R2200     2.9940694570541382e-01
    z[5,4,4]  R2201     4.2538410425186157e-01
    z[5,4,4]  R2202     -0.0423019640147686
    z[5,4,4]  R2203     2.6569724082946777e-01
    z[5,4,4]  R2204     5.8113500475883484e-02
    z[5,4,4]  R2205     -1.3618029654026031e-01
    z[5,4,4]  R2206     5.5409145355224609e-01
    z[5,4,4]  R2207     4.0063974261283875e-01
    z[5,4,4]  R2208     0.537505567073822
    z[5,4,4]  R2209     5.9833395481109619e-01
    z[5,4,4]  R2210     3.5292837023735046e-01
    z[5,4,4]  R2211     1.5173371136188507e-01
    z[5,4,4]  R2212     8.2123500108718872e-01
    z[5,4,4]  R2213     7.8610116243362427e-01
    z[5,4,4]  R2214     -3.6398649215698242e-02
    z[5,4,4]  R2215     1.8064025044441223e-01
    z[5,4,4]  R2216     0.0169846098870039
    z[5,4,4]  R2217     -2.3943005502223969e-01
    z[5,4,4]  R2218     -6.4937502145767212e-01
    z[5,4,4]  R2219     5.4747790098190308e-01
    z[5,4,4]  R2220     1.4513424038887024e-01
    z[5,4,4]  R2221     -2.9419302940368652e-01
    z[5,4,4]  R2222     2.1047417819499969e-01
    z[5,4,4]  R2223     -0.92336106300354
    z[5,4,4]  R2224     0.0594811849296093
    z[5,4,4]  R2225     5.9035980701446533e-01
    z[5,4,4]  R2226     -4.6010011434555054e-01
    z[5,4,4]  R2227     3.3176541328430176e-02
    z[5,4,4]  R2228     3.0229237675666809e-01
    z[5,4,4]  R2229     6.2527048587799072e-01
    z[5,4,4]  R2230     3.3453187346458435e-01
    z[5,4,4]  R2231     5.0589525699615479e-01
    z[5,4,4]  R2232     5.4702854156494141e-01
    z[5,4,4]  R2233     -4.0859675407409668e-01
    z[5,4,4]  R2234     5.1540863513946533e-01
    z[5,4,4]  R2235     4.0010219812393188e-01
    z[5,4,4]  R2236     5.1996868848800659e-01
    z[5,4,4]  R2237     -3.3404279500246048e-02
    z[5,4,4]  R2238     -6.8096712231636047e-02
    z[5,4,4]  R2239     -1.3788822293281555e-01
    z[5,4,4]  R2240     -2.3109939694404602e-01
    z[5,4,4]  R2241     -4.7391152381896973e-01
    z[5,4,4]  R2242     -3.2091453671455383e-01
    z[5,4,4]  R2243     -1.4757290482521057e-01
    z[5,4,4]  R2244     -3.8310667872428894e-01
    z[5,4,4]  R2245     2.7381709218025208e-01
    z[5,4,4]  R2246     4.2095455527305603e-01
    z[5,4,4]  R2247     1.7630970105528831e-02
    z[5,4,4]  R2248     3.8901785016059875e-01
    z[5,4,4]  R2249     3.2643833756446838e-01
    z[5,4,4]  R2250     -2.8026765584945679e-01
    z[5,4,4]  R2251     1.1587437987327576e-01
    z[5,4,4]  R2252     -5.0967586040496826e-01
    z[5,4,4]  R2253     2.3534177243709564e-01
    z[5,4,4]  R2254     1.1257145553827286e-02
    z[5,4,4]  R2255     -1.5665613114833832e-01
    z[5,4,4]  R2256     1.7417942872270942e-03
    z[5,4,4]  R2257     -2.6921004056930542e-01
    z[5,4,4]  R2258     3.3037438988685608e-02
    z[5,4,4]  R2259     -3.1110098958015442e-01
    z[5,4,4]  R2260     -0.0326436311006546
    z[5,4,4]  R2261     3.3059865236282349e-01
    z[5,4,4]  R2262     2.4304026365280151e-01
    z[5,4,4]  R2263     -1.0596216470003128e-01
    z[5,4,4]  R2264     -7.2717433795332909e-03
    z[5,4,4]  R2265     4.3784198164939880e-01
    z[5,4,4]  R2266     3.3182597160339355e-01
    z[5,4,4]  R2267     -3.3863988518714905e-01
    z[5,4,4]  R2268     7.8207127749919891e-02
    z[5,4,4]  R2269     1.2676453590393066e-01
    z[5,4,4]  R2270     0.0924171581864357
    z[5,4,4]  R2271     -1.1691863834857941e-01
    z[5,4,4]  R2272     -6.5099135041236877e-02
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2181     -1
    z[5,4,5]  R2182     1
    z[5,4,5]  R2185     1.7254360020160675e-01
    z[5,4,5]  R2186     0.782616138458252
    z[5,4,5]  R2187     4.1756004095077515e-01
    z[5,4,5]  R2188     2.6718342304229736e-01
    z[5,4,5]  R2189     5.2473846822977066e-02
    z[5,4,5]  R2190     -1.7000629007816315e-01
    z[5,4,5]  R2191     -4.7777980566024780e-02
    z[5,4,5]  R2192     8.3798050880432129e-01
    z[5,4,5]  R2193     3.3537822961807251e-01
    z[5,4,5]  R2194     0.630859911441803
    z[5,4,5]  R2195     -2.0510685443878174e-01
    z[5,4,5]  R2196     -3.3171677589416504e-01
    z[5,4,5]  R2197     -4.5201838016510010e-02
    z[5,4,5]  R2198     -4.7424682974815369e-01
    z[5,4,5]  R2199     -3.8958451151847839e-01
    z[5,4,5]  R2200     -2.3353940248489380e-01
    z[5,4,5]  R2201     -3.1496521085500717e-02
    z[5,4,5]  R2202     -4.7385808825492859e-01
    z[5,4,5]  R2203     -3.0427780747413635e-01
    z[5,4,5]  R2204     -3.7121587991714478e-01
    z[5,4,5]  R2205     -5.8360165357589722e-01
    z[5,4,5]  R2206     -2.2560764849185944e-01
    z[5,4,5]  R2207     -0.407821923494339
    z[5,4,5]  R2208     1.6855373978614807e-01
    z[5,4,5]  R2209     1.0096298158168793e-01
    z[5,4,5]  R2210     -3.8624534010887146e-01
    z[5,4,5]  R2211     -3.9207586646080017e-01
    z[5,4,5]  R2212     2.3046796023845673e-01
    z[5,4,5]  R2213     -0.0591965913772583
    z[5,4,5]  R2214     -5.5470943450927734e-02
    z[5,4,5]  R2215     -3.2538297772407532e-01
    z[5,4,5]  R2216     -7.1658574044704437e-02
    z[5,4,5]  R2217     1.0443413257598877e-01
    z[5,4,5]  R2218     -0.562673032283783
    z[5,4,5]  R2219     3.3719030022621155e-01
    z[5,4,5]  R2220     -1.6899110376834869e-01
    z[5,4,5]  R2221     -0.410017728805542
    z[5,4,5]  R2222     5.1297504454851151e-02
    z[5,4,5]  R2223     -1.3205739855766296e-01
    z[5,4,5]  R2224     -1.3057488203048706e-01
    z[5,4,5]  R2225     6.3000130653381348e-01
    z[5,4,5]  R2226     1.3500395417213440e-01
    z[5,4,5]  R2227     -4.7661134600639343e-01
    z[5,4,5]  R2228     5.5322146415710449e-01
    z[5,4,5]  R2229     -5.1534615457057953e-02
    z[5,4,5]  R2230     4.5814774930477142e-02
    z[5,4,5]  R2231     1.0212268680334091e-01
    z[5,4,5]  R2232     1.0070103406906128e-01
    z[5,4,5]  R2233     -8.0719053745269775e-02
    z[5,4,5]  R2234     3.6336949467658997e-01
    z[5,4,5]  R2235     2.8015589714050293e-01
    z[5,4,5]  R2236     -8.6010143160820007e-02
    z[5,4,5]  R2237     3.7844744324684143e-01
    z[5,4,5]  R2238     -4.9127709865570068e-01
    z[5,4,5]  R2239     1.2058693170547485e-01
    z[5,4,5]  R2240     3.4868514537811279e-01
    z[5,4,5]  R2241     6.8540379405021667e-02
    z[5,4,5]  R2242     -4.2214468121528625e-03
    z[5,4,5]  R2243     8.7181003764271736e-03
    z[5,4,5]  R2244     2.5557172298431396e-01
    z[5,4,5]  R2245     -6.2870115041732788e-01
    z[5,4,5]  R2246     -4.7782656550407410e-01
    z[5,4,5]  R2247     1.2138541787862778e-01
    z[5,4,5]  R2248     5.8549094200134277e-01
    z[5,4,5]  R2249     9.0634517371654510e-02
    z[5,4,5]  R2250     3.9740687608718872e-01
    z[5,4,5]  R2251     -4.0575500577688217e-02
    z[5,4,5]  R2252     -9.4991348683834076e-02
    z[5,4,5]  R2253     -1.9459149241447449e-01
    z[5,4,5]  R2254     -0.566662073135376
    z[5,4,5]  R2255     4.3897858262062073e-01
    z[5,4,5]  R2256     2.3217049241065979e-01
    z[5,4,5]  R2257     6.6998794674873352e-02
    z[5,4,5]  R2258     3.8771173357963562e-01
    z[5,4,5]  R2259     4.6987339854240417e-02
    z[5,4,5]  R2260     1.7671336233615875e-01
    z[5,4,5]  R2261     5.0558310747146606e-01
    z[5,4,5]  R2262     3.0969861149787903e-01
    z[5,4,5]  R2263     4.0456745028495789e-01
    z[5,4,5]  R2264     2.0982122421264648e-01
    z[5,4,5]  R2265     -1.5313214063644409e-01
    z[5,4,5]  R2266     -2.1586470305919647e-01
    z[5,4,5]  R2267     -0.335225373506546
    z[5,4,5]  R2268     -3.0429592728614807e-01
    z[5,4,5]  R2269     -1.2198971211910248e-01
    z[5,4,5]  R2270     -5.3398627787828445e-02
    z[5,4,5]  R2271     -0.00661705294623971
    z[5,4,5]  R2272     2.1670649945735931e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2183     -1
    z[5,4,6]  R2184     1
    z[5,4,6]  R2185     -6.7084066569805145e-02
    z[5,4,6]  R2186     3.2850247621536255e-01
    z[5,4,6]  R2187     5.8844357728958130e-01
    z[5,4,6]  R2188     3.1738871335983276e-01
    z[5,4,6]  R2189     4.5578393340110779e-01
    z[5,4,6]  R2190     5.2658468484878540e-01
    z[5,4,6]  R2191     -2.4421733617782593e-01
    z[5,4,6]  R2192     -1.5115892887115479e-01
    z[5,4,6]  R2193     -3.5378482192754745e-02
    z[5,4,6]  R2194     2.1014676988124847e-01
    z[5,4,6]  R2195     2.2431743144989014e-01
    z[5,4,6]  R2196     1.4723828434944153e-01
    z[5,4,6]  R2197     2.7871602773666382e-01
    z[5,4,6]  R2198     -1.4741206541657448e-02
    z[5,4,6]  R2199     -6.3567437231540680e-02
    z[5,4,6]  R2200     2.5572484731674194e-01
    z[5,4,6]  R2201     -8.9660808444023132e-03
    z[5,4,6]  R2202     3.4135526418685913e-01
    z[5,4,6]  R2203     3.1523339450359344e-02
    z[5,4,6]  R2204     3.2076603174209595e-01
    z[5,4,6]  R2205     -4.4919201731681824e-01
    z[5,4,6]  R2206     -3.9003399014472961e-01
    z[5,4,6]  R2207     1.9633628427982330e-01
    z[5,4,6]  R2208     -5.4399389773607254e-02
    z[5,4,6]  R2209     -1.1013595014810562e-01
    z[5,4,6]  R2210     -6.7405253648757935e-02
    z[5,4,6]  R2211     3.1717678066343069e-03
    z[5,4,6]  R2212     -2.1271444857120514e-01
    z[5,4,6]  R2213     -2.4861088395118713e-01
    z[5,4,6]  R2214     -1.8542063236236572e-01
    z[5,4,6]  R2215     -3.2147186994552612e-01
    z[5,4,6]  R2216     -4.6655958890914917e-01
    z[5,4,6]  R2217     -1.2904070317745209e-01
    z[5,4,6]  R2218     -2.1621312201023102e-01
    z[5,4,6]  R2219     -2.8564631938934326e-01
    z[5,4,6]  R2220     -2.0460499450564384e-02
    z[5,4,6]  R2221     -0.547367513179779
    z[5,4,6]  R2222     -2.6937276124954224e-01
    z[5,4,6]  R2223     -6.2870413064956665e-02
    z[5,4,6]  R2224     -7.1676015853881836e-01
    z[5,4,6]  R2225     -1.9281332194805145e-01
    z[5,4,6]  R2226     1.7515836656093597e-01
    z[5,4,6]  R2227     -8.7471000850200653e-02
    z[5,4,6]  R2228     -8.9473605155944824e-02
    z[5,4,6]  R2229     -3.0243399739265442e-01
    z[5,4,6]  R2230     2.1716007590293884e-01
    z[5,4,6]  R2231     2.7200832962989807e-01
    z[5,4,6]  R2232     4.6990740299224854e-01
    z[5,4,6]  R2233     0.0439128652215004
    z[5,4,6]  R2234     -6.5017372369766235e-01
    z[5,4,6]  R2235     0.0619877427816391
    z[5,4,6]  R2236     4.0417158603668213e-01
    z[5,4,6]  R2237     5.1775211095809937e-01
    z[5,4,6]  R2238     -0.0470924936234951
    z[5,4,6]  R2239     3.0986329913139343e-01
    z[5,4,6]  R2240     -2.8853079676628113e-01
    z[5,4,6]  R2241     1.7710734903812408e-01
    z[5,4,6]  R2242     5.1792579889297485e-01
    z[5,4,6]  R2243     8.7738549336791039e-03
    z[5,4,6]  R2244     -0.210055410861969
    z[5,4,6]  R2245     -3.8047656416893005e-01
    z[5,4,6]  R2246     -2.8715729713439941e-02
    z[5,4,6]  R2247     -0.19149149954319
    z[5,4,6]  R2248     1.5574800968170166e-01
    z[5,4,6]  R2249     1.0477259755134583e-01
    z[5,4,6]  R2250     4.8497340083122253e-01
    z[5,4,6]  R2251     4.4440111517906189e-01
    z[5,4,6]  R2252     -6.6356673836708069e-02
    z[5,4,6]  R2253     4.7136954963207245e-02
    z[5,4,6]  R2254     -2.0768925547599792e-01
    z[5,4,6]  R2255     -6.6673986613750458e-02
    z[5,4,6]  R2256     2.5562450289726257e-01
    z[5,4,6]  R2257     4.5592587441205978e-02
    z[5,4,6]  R2258     3.5747972130775452e-01
    z[5,4,6]  R2259     9.3551538884639740e-02
    z[5,4,6]  R2260     3.1063543632626534e-02
    z[5,4,6]  R2261     1.6130568087100983e-01
    z[5,4,6]  R2262     4.4554957747459412e-01
    z[5,4,6]  R2263     2.8060135245323181e-01
    z[5,4,6]  R2264     3.0970117449760437e-01
    z[5,4,6]  R2265     -1.9239617511630058e-02
    z[5,4,6]  R2266     2.5689511094242334e-03
    z[5,4,6]  R2267     1.5902109444141388e-01
    z[5,4,6]  R2268     -1.1570470035076141e-01
    z[5,4,6]  R2269     3.7005368620157242e-02
    z[5,4,6]  R2270     -2.6223507523536682e-01
    z[5,4,6]  R2271     2.4169474840164185e-01
    z[5,4,6]  R2272     7.6468706130981445e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2326     -1
    z[5,6,0]  R2327     1
    z[5,6,0]  R2340     3.2114568352699280e-01
    z[5,6,0]  R2341     1.2799820979125798e-04
    z[5,6,0]  R2342     5.5457610636949539e-02
    z[5,6,0]  R2343     5.2234575152397156e-02
    z[5,6,0]  R2344     8.2452498376369476e-02
    z[5,6,0]  R2345     4.3067926168441772e-01
    z[5,6,0]  R2346     -1.3426003046333790e-02
    z[5,6,0]  R2347     -2.3636072874069214e-02
    z[5,6,0]  R2348     5.2429482340812683e-02
    z[5,6,0]  R2349     -7.5056720525026321e-03
    z[5,6,0]  R2350     7.0652149617671967e-02
    z[5,6,0]  R2351     2.7111560106277466e-01
    z[5,6,0]  R2352     1.9415850937366486e-01
    z[5,6,0]  R2353     1.1719628423452377e-01
    z[5,6,0]  R2354     -7.2154819965362549e-02
    z[5,6,0]  R2355     -1.4037913084030151e-01
    z[5,6,0]  R2356     -5.4189842194318771e-03
    z[5,6,0]  R2357     1.1443827301263809e-01
    z[5,6,0]  R2358     -1.8866352736949921e-01
    z[5,6,0]  R2359     4.2419081926345825e-01
    z[5,6,0]  R2360     2.6447597146034241e-01
    z[5,6,0]  R2361     4.4845908880233765e-02
    z[5,6,0]  R2362     -7.4253201484680176e-02
    z[5,6,0]  R2363     -1.0336951166391373e-01
    z[5,6,0]  R2364     -2.4555101990699768e-03
    z[5,6,0]  R2365     -1.0886755585670471e-01
    z[5,6,0]  R2366     -4.8941407352685928e-02
    z[5,6,0]  R2367     -1.8093822896480560e-01
    z[5,6,0]  R2368     -1.2569734454154968e-01
    z[5,6,0]  R2369     1.0660402476787567e-01
    z[5,6,0]  R2370     1.9257423281669617e-01
    z[5,6,0]  R2371     2.3337945342063904e-01
    z[5,6,0]  R2372     2.6228129863739014e-01
    z[5,6,0]  R2373     3.3634158968925476e-01
    z[5,6,0]  R2374     -9.8939023911952972e-02
    z[5,6,0]  R2375     -4.1293105483055115e-01
    z[5,6,0]  R2376     2.5201907753944397e-01
    z[5,6,0]  R2377     -3.2411229610443115e-01
    z[5,6,0]  R2378     3.0029773712158203e-01
    z[5,6,0]  R2379     -1.3278488814830780e-01
    z[5,6,0]  R2380     -1.9313894212245941e-01
    z[5,6,0]  R2381     -0.614051342010498
    z[5,6,0]  R2382     3.2096934318542480e-01
    z[5,6,0]  R2383     3.5385772585868835e-02
    z[5,6,0]  R2384     -0.0406770296394825
    z[5,6,0]  R2385     -5.2866542339324951e-01
    z[5,6,0]  R2386     -4.5177474617958069e-01
    z[5,6,0]  R2387     4.5386098325252533e-02
    z[5,6,0]  R2388     -1.3763718307018280e-01
    z[5,6,0]  R2389     -4.8729193210601807e-01
    z[5,6,0]  R2390     -6.0099172592163086e-01
    z[5,6,0]  R2391     -3.2954074442386627e-02
    z[5,6,0]  R2392     7.5554296374320984e-02
    z[5,6,0]  R2393     -9.7896084189414978e-02
    z[5,6,0]  R2394     -3.8970449566841125e-01
    z[5,6,0]  R2395     1.2374044954776764e-01
    z[5,6,0]  R2396     2.8977102041244507e-01
    z[5,6,0]  R2397     -4.6530212275683880e-03
    z[5,6,0]  R2398     7.6810702681541443e-02
    z[5,6,0]  R2399     2.7076140046119690e-01
    z[5,6,0]  R2400     2.0435069501399994e-01
    z[5,6,0]  R2401     4.8351809382438660e-03
    z[5,6,0]  R2402     2.4945285916328430e-01
    z[5,6,0]  R2403     0.213861882686615
    z[5,6,0]  R2404     1.9959162175655365e-01
    z[5,6,0]  R2405     1.0795354098081589e-01
    z[5,6,0]  R2406     0.0949750691652298
    z[5,6,0]  R2407     1.0327365249395370e-01
    z[5,6,0]  R2408     -1.4315104484558105e-01
    z[5,6,0]  R2409     1.0323889553546906e-01
    z[5,6,0]  R2410     -0.086922287940979
    z[5,6,0]  R2411     4.8406824469566345e-01
    z[5,6,0]  R2412     1.0395500808954239e-02
    z[5,6,0]  R2413     -1.1849900335073471e-01
    z[5,6,0]  R2414     -4.7565117478370667e-02
    z[5,6,0]  R2415     -2.8622692823410034e-01
    z[5,6,0]  R2416     2.3305535316467285e-02
    z[5,6,0]  R2417     -1.2474393099546432e-01
    z[5,6,0]  R2418     -2.1036426723003387e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2328     -1
    z[5,6,1]  R2329     1
    z[5,6,1]  R2340     5.0134855508804321e-01
    z[5,6,1]  R2341     4.5813700556755066e-01
    z[5,6,1]  R2342     0.432682067155838
    z[5,6,1]  R2343     4.6237125992774963e-01
    z[5,6,1]  R2344     5.0908207893371582e-01
    z[5,6,1]  R2345     4.8563095927238464e-01
    z[5,6,1]  R2346     8.2065206766128540e-01
    z[5,6,1]  R2347     3.0611601471900940e-01
    z[5,6,1]  R2348     5.0296491384506226e-01
    z[5,6,1]  R2349     0.327528178691864
    z[5,6,1]  R2350     -8.1756854057312012e-01
    z[5,6,1]  R2351     -5.9623104333877563e-01
    z[5,6,1]  R2352     -7.5222784280776978e-01
    z[5,6,1]  R2353     -4.9451699852943420e-01
    z[5,6,1]  R2354     -6.9143062829971313e-01
    z[5,6,1]  R2355     -7.4074578285217285e-01
    z[5,6,1]  R2356     -6.7811751365661621e-01
    z[5,6,1]  R2357     -5.4823744297027588e-01
    z[5,6,1]  R2358     -0.549148678779602
    z[5,6,1]  R2359     -5.0057750940322876e-01
    z[5,6,1]  R2360     2.4117852747440338e-01
    z[5,6,1]  R2361     3.7038120627403259e-01
    z[5,6,1]  R2362     0.503020703792572
    z[5,6,1]  R2363     7.1465331315994263e-01
    z[5,6,1]  R2364     1.6307540237903595e-01
    z[5,6,1]  R2365     5.4639625549316406e-01
    z[5,6,1]  R2366     5.1106256246566772e-01
    z[5,6,1]  R2367     2.0135138928890228e-01
    z[5,6,1]  R2368     5.1603823900222778e-01
    z[5,6,1]  R2369     -4.3186736106872559e-01
    z[5,6,1]  R2370     7.7884471416473389e-01
    z[5,6,1]  R2371     0.612871527671814
    z[5,6,1]  R2372     1.5017915284261107e-03
    z[5,6,1]  R2373     1.7503488063812256e-01
    z[5,6,1]  R2374     6.4956796169281006e-01
    z[5,6,1]  R2375     5.9445953369140625e-01
    z[5,6,1]  R2376     1.1809966713190079e-01
    z[5,6,1]  R2377     -1.1558468639850616e-01
    z[5,6,1]  R2378     2.3782048374414444e-02
    z[5,6,1]  R2379     4.9197566509246826e-01
    z[5,6,1]  R2380     4.1021221876144409e-01
    z[5,6,1]  R2381     5.9973281621932983e-01
    z[5,6,1]  R2382     4.4935470819473267e-01
    z[5,6,1]  R2383     2.8569960594177246e-01
    z[5,6,1]  R2384     4.9081340432167053e-01
    z[5,6,1]  R2385     5.5745017528533936e-01
    z[5,6,1]  R2386     -8.5575558245182037e-02
    z[5,6,1]  R2387     5.8053910732269287e-01
    z[5,6,1]  R2388     -4.2640173435211182e-01
    z[5,6,1]  R2389     -3.5702398419380188e-01
    z[5,6,1]  R2390     -1.5415129065513611e-01
    z[5,6,1]  R2391     -6.7099016904830933e-01
    z[5,6,1]  R2392     -7.4068850278854370e-01
    z[5,6,1]  R2393     -5.4062509536743164e-01
    z[5,6,1]  R2394     -6.6204947233200073e-01
    z[5,6,1]  R2395     -4.0233135223388672e-01
    z[5,6,1]  R2396     -3.5219326615333557e-01
    z[5,6,1]  R2397     -2.4606880545616150e-01
    z[5,6,1]  R2398     4.4106975197792053e-01
    z[5,6,1]  R2399     -3.9074367284774780e-01
    z[5,6,1]  R2400     -3.0664929747581482e-01
    z[5,6,1]  R2401     -1.6096708178520203e-01
    z[5,6,1]  R2402     3.9459779858589172e-01
    z[5,6,1]  R2403     7.5173395872116089e-01
    z[5,6,1]  R2404     7.4822336435317993e-01
    z[5,6,1]  R2405     6.6282504796981812e-01
    z[5,6,1]  R2406     8.2198286056518555e-01
    z[5,6,1]  R2407     6.5111505985260010e-01
    z[5,6,1]  R2408     8.3069866895675659e-01
    z[5,6,1]  R2409     -4.4804677367210388e-01
    z[5,6,1]  R2410     -3.9826601743698120e-01
    z[5,6,1]  R2411     -2.6746892929077148e-01
    z[5,6,1]  R2412     9.1232210397720337e-01
    z[5,6,1]  R2413     9.3661522865295410e-01
    z[5,6,1]  R2414     7.7929776906967163e-01
    z[5,6,1]  R2415     9.1708499193191528e-01
    z[5,6,1]  R2416     -1.9481889903545380e-01
    z[5,6,1]  R2417     6.5784966945648193e-01
    z[5,6,1]  R2418     0.863397479057312
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2330     -1
    z[5,6,2]  R2331     1
    z[5,6,2]  R2340     5.5939173698425293e-01
    z[5,6,2]  R2341     -9.1380871832370758e-02
    z[5,6,2]  R2342     -5.2853405475616455e-01
    z[5,6,2]  R2343     -7.1074366569519043e-01
    z[5,6,2]  R2344     -7.0286047458648682e-01
    z[5,6,2]  R2345     2.5660511851310730e-01
    z[5,6,2]  R2346     -3.3238753676414490e-01
    z[5,6,2]  R2347     -0.294884592294693
    z[5,6,2]  R2348     -6.1701703071594238e-01
    z[5,6,2]  R2349     -5.3743177652359009e-01
    z[5,6,2]  R2350     1.2026625871658325e-01
    z[5,6,2]  R2351     3.4989011287689209e-01
    z[5,6,2]  R2352     -1.1586213111877441e-01
    z[5,6,2]  R2353     -9.3651607632637024e-02
    z[5,6,2]  R2354     -3.5125061869621277e-01
    z[5,6,2]  R2355     2.9583710432052612e-01
    z[5,6,2]  R2356     1.0643537156283855e-02
    z[5,6,2]  R2357     -2.1485063433647156e-01
    z[5,6,2]  R2358     1.8233244121074677e-01
    z[5,6,2]  R2359     -4.7685351222753525e-02
    z[5,6,2]  R2360     -1.6669457778334618e-02
    z[5,6,2]  R2361     1.2669166922569275e-01
    z[5,6,2]  R2362     1.1230615526437759e-01
    z[5,6,2]  R2363     1.9065700471401215e-01
    z[5,6,2]  R2364     4.4778954982757568e-01
    z[5,6,2]  R2365     3.6488610506057739e-01
    z[5,6,2]  R2366     2.6896793395280838e-02
    z[5,6,2]  R2367     1.7822082340717316e-01
    z[5,6,2]  R2368     1.7628322541713715e-01
    z[5,6,2]  R2369     1.2772007286548615e-01
    z[5,6,2]  R2370     -2.4267971515655518e-01
    z[5,6,2]  R2371     -1.1833103001117706e-01
    z[5,6,2]  R2372     -2.2095292806625366e-01
    z[5,6,2]  R2373     2.4815934896469116e-01
    z[5,6,2]  R2374     0.269465833902359
    z[5,6,2]  R2375     2.2802762687206268e-01
    z[5,6,2]  R2376     2.2638346254825592e-01
    z[5,6,2]  R2377     -4.9153584241867065e-01
    z[5,6,2]  R2378     -1.8757960200309753e-01
    z[5,6,2]  R2379     1.7887100577354431e-01
    z[5,6,2]  R2380     -8.5737422108650208e-02
    z[5,6,2]  R2381     2.5774728506803513e-02
    z[5,6,2]  R2382     3.8702264428138733e-01
    z[5,6,2]  R2383     4.7996929287910461e-01
    z[5,6,2]  R2384     -3.9740979671478271e-01
    z[5,6,2]  R2385     4.5599198341369629e-01
    z[5,6,2]  R2386     -1.8403373658657074e-01
    z[5,6,2]  R2387     3.6123567819595337e-01
    z[5,6,2]  R2388     5.4145264625549316e-01
    z[5,6,2]  R2389     3.3122763037681580e-01
    z[5,6,2]  R2390     5.5581283569335938e-01
    z[5,6,2]  R2391     1.5156951732933521e-02
    z[5,6,2]  R2392     2.4588094651699066e-01
    z[5,6,2]  R2393     -5.8745924383401871e-02
    z[5,6,2]  R2394     4.3144565820693970e-01
    z[5,6,2]  R2395     -2.6238444447517395e-01
    z[5,6,2]  R2396     -1.4579498767852783e-01
    z[5,6,2]  R2397     2.3747770488262177e-01
    z[5,6,2]  R2398     -5.1327288150787354e-01
    z[5,6,2]  R2399     -9.1044150292873383e-02
    z[5,6,2]  R2400     -6.8464823067188263e-02
    z[5,6,2]  R2401     2.3217935115098953e-02
    z[5,6,2]  R2402     -1.6536971926689148e-01
    z[5,6,2]  R2403     8.6744002997875214e-02
    z[5,6,2]  R2404     2.3347425460815430e-01
    z[5,6,2]  R2405     -1.0240331292152405e-01
    z[5,6,2]  R2406     6.9272637367248535e-02
    z[5,6,2]  R2407     -4.7520559281110764e-02
    z[5,6,2]  R2408     2.3230488598346710e-01
    z[5,6,2]  R2409     1.0994613170623779e-01
    z[5,6,2]  R2410     5.5095762014389038e-01
    z[5,6,2]  R2411     -2.7092188596725464e-01
    z[5,6,2]  R2412     5.5401004850864410e-02
    z[5,6,2]  R2413     3.7188478745520115e-03
    z[5,6,2]  R2414     5.7915952056646347e-02
    z[5,6,2]  R2415     1.3038368523120880e-01
    z[5,6,2]  R2416     -8.4326320886611938e-01
    z[5,6,2]  R2417     -4.6066680806688964e-04
    z[5,6,2]  R2418     2.4493815004825592e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2332     -1
    z[5,6,3]  R2333     1
    z[5,6,3]  R2340     1.5760849416255951e-01
    z[5,6,3]  R2341     2.3670193552970886e-01
    z[5,6,3]  R2342     7.3240667581558228e-02
    z[5,6,3]  R2343     5.2571866661310196e-02
    z[5,6,3]  R2344     1.6801701486110687e-01
    z[5,6,3]  R2345     2.7998885512351990e-01
    z[5,6,3]  R2346     3.1080448627471924e-01
    z[5,6,3]  R2347     6.3498966395854950e-02
    z[5,6,3]  R2348     -0.07258290797472
    z[5,6,3]  R2349     -1.0689292103052139e-01
    z[5,6,3]  R2350     -4.5449972152709961e-01
    z[5,6,3]  R2351     -5.6289356946945190e-01
    z[5,6,3]  R2352     -4.6246212720870972e-01
    z[5,6,3]  R2353     -0.708291232585907
    z[5,6,3]  R2354     -4.3603339791297913e-01
    z[5,6,3]  R2355     -3.6672791838645935e-01
    z[5,6,3]  R2356     -5.9832257032394409e-01
    z[5,6,3]  R2357     -0.545274555683136
    z[5,6,3]  R2358     -6.8221920728683472e-01
    z[5,6,3]  R2359     -5.6845504045486450e-01
    z[5,6,3]  R2360     5.5740290880203247e-01
    z[5,6,3]  R2361     0.578544020652771
    z[5,6,3]  R2362     -6.0288065671920776e-01
    z[5,6,3]  R2363     -3.4921801090240479e-01
    z[5,6,3]  R2364     6.2654447555541992e-01
    z[5,6,3]  R2365     -5.2741795778274536e-01
    z[5,6,3]  R2366     -7.4762272834777832e-01
    z[5,6,3]  R2367     3.4952321648597717e-01
    z[5,6,3]  R2368     5.9685643762350082e-02
    z[5,6,3]  R2369     8.6430960893630981e-01
    z[5,6,3]  R2370     2.3574048280715942e-01
    z[5,6,3]  R2371     5.7690471410751343e-01
    z[5,6,3]  R2372     8.9302927255630493e-01
    z[5,6,3]  R2373     9.8066650331020355e-02
    z[5,6,3]  R2374     -2.5251312181353569e-02
    z[5,6,3]  R2375     -6.1161148548126221e-01
    z[5,6,3]  R2376     5.6304007768630981e-01
    z[5,6,3]  R2377     0.721450924873352
    z[5,6,3]  R2378     -0.00906460452824831
    z[5,6,3]  R2379     -4.1713351011276245e-01
    z[5,6,3]  R2380     0.0668509304523468
    z[5,6,3]  R2381     -4.4703356921672821e-02
    z[5,6,3]  R2382     5.5620354413986206e-01
    z[5,6,3]  R2383     5.3038930892944336e-01
    z[5,6,3]  R2384     3.3827179670333862e-01
    z[5,6,3]  R2385     2.0165410637855530e-01
    z[5,6,3]  R2386     6.4370816946029663e-01
    z[5,6,3]  R2387     -1.5139554627239704e-02
    z[5,6,3]  R2388     5.7504045963287354e-01
    z[5,6,3]  R2389     3.4000462293624878e-01
    z[5,6,3]  R2390     4.3322449922561646e-01
    z[5,6,3]  R2391     1.7993398010730743e-01
    z[5,6,3]  R2392     4.8892334103584290e-01
    z[5,6,3]  R2393     5.5010837316513062e-01
    z[5,6,3]  R2394     1.3757245242595673e-01
    z[5,6,3]  R2395     1.3948038220405579e-01
    z[5,6,3]  R2396     5.0318348407745361e-01
    z[5,6,3]  R2397     2.5663191080093384e-01
    z[5,6,3]  R2398     5.1807653903961182e-01
    z[5,6,3]  R2399     -7.7442824840545654e-01
    z[5,6,3]  R2400     -8.5130870342254639e-01
    z[5,6,3]  R2401     -6.3003784418106079e-01
    z[5,6,3]  R2402     2.8973874449729919e-01
    z[5,6,3]  R2403     -5.4302328824996948e-01
    z[5,6,3]  R2404     -4.9294564127922058e-01
    z[5,6,3]  R2405     -4.6769458055496216e-01
    z[5,6,3]  R2406     -1.9529570639133453e-01
    z[5,6,3]  R2407     -4.9641317129135132e-01
    z[5,6,3]  R2408     1.0120025277137756e-01
    z[5,6,3]  R2409     -4.3710049986839294e-01
    z[5,6,3]  R2410     -4.9073022603988647e-01
    z[5,6,3]  R2411     -2.5777477025985718e-01
    z[5,6,3]  R2412     -1.5390133485198021e-02
    z[5,6,3]  R2413     -6.4651072025299072e-02
    z[5,6,3]  R2414     2.9587191343307495e-01
    z[5,6,3]  R2415     -1.4695847034454346e-01
    z[5,6,3]  R2416     -0.332194447517395
    z[5,6,3]  R2417     1.6896338760852814e-01
    z[5,6,3]  R2418     -1.7404754459857941e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2334     -1
    z[5,6,4]  R2335     1
    z[5,6,4]  R2340     -5.2295696735382080e-01
    z[5,6,4]  R2341     -7.3008544743061066e-02
    z[5,6,4]  R2342     6.6151313483715057e-02
    z[5,6,4]  R2343     -3.2162305712699890e-01
    z[5,6,4]  R2344     0.0360804907977581
    z[5,6,4]  R2345     -3.5811248421669006e-01
    z[5,6,4]  R2346     -2.3946642875671387e-01
    z[5,6,4]  R2347     -2.9947438836097717e-01
    z[5,6,4]  R2348     -4.9453905224800110e-01
    z[5,6,4]  R2349     -3.8763910531997681e-01
    z[5,6,4]  R2350     -1.1475600302219391e-01
    z[5,6,4]  R2351     -4.1680745780467987e-03
    z[5,6,4]  R2352     2.9905638098716736e-01
    z[5,6,4]  R2353     7.8380726277828217e-02
    z[5,6,4]  R2354     2.1771165728569031e-01
    z[5,6,4]  R2355     2.9940694570541382e-01
    z[5,6,4]  R2356     4.2538410425186157e-01
    z[5,6,4]  R2357     -0.0423019640147686
    z[5,6,4]  R2358     2.6569724082946777e-01
    z[5,6,4]  R2359     5.8113500475883484e-02
    z[5,6,4]  R2360     -1.3618029654026031e-01
    z[5,6,4]  R2361     5.5409145355224609e-01
    z[5,6,4]  R2362     4.0063974261283875e-01
    z[5,6,4]  R2363     0.537505567073822
    z[5,6,4]  R2364     5.9833395481109619e-01
    z[5,6,4]  R2365     3.5292837023735046e-01
    z[5,6,4]  R2366     1.5173371136188507e-01
    z[5,6,4]  R2367     8.2123500108718872e-01
    z[5,6,4]  R2368     7.8610116243362427e-01
    z[5,6,4]  R2369     -3.6398649215698242e-02
    z[5,6,4]  R2370     1.8064025044441223e-01
    z[5,6,4]  R2371     0.0169846098870039
    z[5,6,4]  R2372     -2.3943005502223969e-01
    z[5,6,4]  R2373     -6.4937502145767212e-01
    z[5,6,4]  R2374     5.4747790098190308e-01
    z[5,6,4]  R2375     1.4513424038887024e-01
    z[5,6,4]  R2376     -2.9419302940368652e-01
    z[5,6,4]  R2377     2.1047417819499969e-01
    z[5,6,4]  R2378     -0.92336106300354
    z[5,6,4]  R2379     0.0594811849296093
    z[5,6,4]  R2380     5.9035980701446533e-01
    z[5,6,4]  R2381     -4.6010011434555054e-01
    z[5,6,4]  R2382     3.3176541328430176e-02
    z[5,6,4]  R2383     3.0229237675666809e-01
    z[5,6,4]  R2384     6.2527048587799072e-01
    z[5,6,4]  R2385     3.3453187346458435e-01
    z[5,6,4]  R2386     5.0589525699615479e-01
    z[5,6,4]  R2387     5.4702854156494141e-01
    z[5,6,4]  R2388     -4.0859675407409668e-01
    z[5,6,4]  R2389     -4.6212986111640930e-01
    z[5,6,4]  R2390     -1.0306835174560547e-01
    z[5,6,4]  R2391     2.4907572567462921e-01
    z[5,6,4]  R2392     3.5415120422840118e-02
    z[5,6,4]  R2393     2.5946739315986633e-01
    z[5,6,4]  R2394     3.1383502483367920e-01
    z[5,6,4]  R2395     -6.5896719694137573e-01
    z[5,6,4]  R2396     -0.596753716468811
    z[5,6,4]  R2397     -6.1668014526367188e-01
    z[5,6,4]  R2398     -0.358946830034256
    z[5,6,4]  R2399     6.9367498159408569e-02
    z[5,6,4]  R2400     -0.0192574355751276
    z[5,6,4]  R2401     5.4983311891555786e-01
    z[5,6,4]  R2402     7.6512259244918823e-01
    z[5,6,4]  R2403     1.8830262124538422e-02
    z[5,6,4]  R2404     1.5435796976089478e-01
    z[5,6,4]  R2405     4.5882749557495117e-01
    z[5,6,4]  R2406     -4.8992950469255447e-02
    z[5,6,4]  R2407     2.2206287086009979e-01
    z[5,6,4]  R2408     0.18660868704319
    z[5,6,4]  R2409     -2.0885774865746498e-02
    z[5,6,4]  R2410     -6.6024191677570343e-02
    z[5,6,4]  R2411     5.5955165624618530e-01
    z[5,6,4]  R2412     1.1262305080890656e-01
    z[5,6,4]  R2413     2.5707712769508362e-01
    z[5,6,4]  R2414     1.4648343622684479e-01
    z[5,6,4]  R2415     4.4894441962242126e-02
    z[5,6,4]  R2416     0.320562481880188
    z[5,6,4]  R2417     4.6578127145767212e-01
    z[5,6,4]  R2418     1.7981793731451035e-02
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2336     -1
    z[5,6,5]  R2337     1
    z[5,6,5]  R2340     1.7254360020160675e-01
    z[5,6,5]  R2341     0.782616138458252
    z[5,6,5]  R2342     4.1756004095077515e-01
    z[5,6,5]  R2343     2.6718342304229736e-01
    z[5,6,5]  R2344     5.2473846822977066e-02
    z[5,6,5]  R2345     -1.7000629007816315e-01
    z[5,6,5]  R2346     -4.7777980566024780e-02
    z[5,6,5]  R2347     8.3798050880432129e-01
    z[5,6,5]  R2348     3.3537822961807251e-01
    z[5,6,5]  R2349     0.630859911441803
    z[5,6,5]  R2350     -2.0510685443878174e-01
    z[5,6,5]  R2351     -3.3171677589416504e-01
    z[5,6,5]  R2352     -4.5201838016510010e-02
    z[5,6,5]  R2353     -4.7424682974815369e-01
    z[5,6,5]  R2354     -3.8958451151847839e-01
    z[5,6,5]  R2355     -2.3353940248489380e-01
    z[5,6,5]  R2356     -3.1496521085500717e-02
    z[5,6,5]  R2357     -4.7385808825492859e-01
    z[5,6,5]  R2358     -3.0427780747413635e-01
    z[5,6,5]  R2359     -3.7121587991714478e-01
    z[5,6,5]  R2360     -5.8360165357589722e-01
    z[5,6,5]  R2361     -2.2560764849185944e-01
    z[5,6,5]  R2362     -0.407821923494339
    z[5,6,5]  R2363     1.6855373978614807e-01
    z[5,6,5]  R2364     1.0096298158168793e-01
    z[5,6,5]  R2365     -3.8624534010887146e-01
    z[5,6,5]  R2366     -3.9207586646080017e-01
    z[5,6,5]  R2367     2.3046796023845673e-01
    z[5,6,5]  R2368     -0.0591965913772583
    z[5,6,5]  R2369     -5.5470943450927734e-02
    z[5,6,5]  R2370     -3.2538297772407532e-01
    z[5,6,5]  R2371     -7.1658574044704437e-02
    z[5,6,5]  R2372     1.0443413257598877e-01
    z[5,6,5]  R2373     -0.562673032283783
    z[5,6,5]  R2374     3.3719030022621155e-01
    z[5,6,5]  R2375     -1.6899110376834869e-01
    z[5,6,5]  R2376     -0.410017728805542
    z[5,6,5]  R2377     5.1297504454851151e-02
    z[5,6,5]  R2378     -1.3205739855766296e-01
    z[5,6,5]  R2379     -1.3057488203048706e-01
    z[5,6,5]  R2380     6.3000130653381348e-01
    z[5,6,5]  R2381     1.3500395417213440e-01
    z[5,6,5]  R2382     -4.7661134600639343e-01
    z[5,6,5]  R2383     5.5322146415710449e-01
    z[5,6,5]  R2384     -5.1534615457057953e-02
    z[5,6,5]  R2385     4.5814774930477142e-02
    z[5,6,5]  R2386     1.0212268680334091e-01
    z[5,6,5]  R2387     1.0070103406906128e-01
    z[5,6,5]  R2388     -8.0719053745269775e-02
    z[5,6,5]  R2389     3.5383099317550659e-01
    z[5,6,5]  R2390     0.298246830701828
    z[5,6,5]  R2391     6.6604816913604736e-01
    z[5,6,5]  R2392     1.4240823686122894e-01
    z[5,6,5]  R2393     -3.3883821964263916e-01
    z[5,6,5]  R2394     2.1826688945293427e-01
    z[5,6,5]  R2395     5.4729700088500977e-01
    z[5,6,5]  R2396     -2.7310594916343689e-01
    z[5,6,5]  R2397     4.3495544791221619e-01
    z[5,6,5]  R2398     2.6600891351699829e-01
    z[5,6,5]  R2399     -2.7356579899787903e-01
    z[5,6,5]  R2400     -0.362730473279953
    z[5,6,5]  R2401     -0.503667414188385
    z[5,6,5]  R2402     1.2624172866344452e-01
    z[5,6,5]  R2403     -2.6105238124728203e-02
    z[5,6,5]  R2404     -2.7103149890899658e-01
    z[5,6,5]  R2405     -1.5463612973690033e-01
    z[5,6,5]  R2406     -3.1710001826286316e-01
    z[5,6,5]  R2407     4.2258673906326294e-01
    z[5,6,5]  R2408     -3.6251193284988403e-01
    z[5,6,5]  R2409     -7.6343721151351929e-01
    z[5,6,5]  R2410     -3.9944148063659668e-01
    z[5,6,5]  R2411     -4.7607335448265076e-01
    z[5,6,5]  R2412     -2.4536564946174622e-01
    z[5,6,5]  R2413     -1.9593752920627594e-01
    z[5,6,5]  R2414     -5.0675994157791138e-01
    z[5,6,5]  R2415     -1.6763083636760712e-01
    z[5,6,5]  R2416     -3.7964764982461929e-02
    z[5,6,5]  R2417     -5.2175086736679077e-01
    z[5,6,5]  R2418     2.1028614044189453e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2338     -1
    z[5,6,6]  R2339     1
    z[5,6,6]  R2340     -6.7084066569805145e-02
    z[5,6,6]  R2341     3.2850247621536255e-01
    z[5,6,6]  R2342     5.8844357728958130e-01
    z[5,6,6]  R2343     3.1738871335983276e-01
    z[5,6,6]  R2344     4.5578393340110779e-01
    z[5,6,6]  R2345     5.2658468484878540e-01
    z[5,6,6]  R2346     -2.4421733617782593e-01
    z[5,6,6]  R2347     -1.5115892887115479e-01
    z[5,6,6]  R2348     -3.5378482192754745e-02
    z[5,6,6]  R2349     2.1014676988124847e-01
    z[5,6,6]  R2350     2.2431743144989014e-01
    z[5,6,6]  R2351     1.4723828434944153e-01
    z[5,6,6]  R2352     2.7871602773666382e-01
    z[5,6,6]  R2353     -1.4741206541657448e-02
    z[5,6,6]  R2354     -6.3567437231540680e-02
    z[5,6,6]  R2355     2.5572484731674194e-01
    z[5,6,6]  R2356     -8.9660808444023132e-03
    z[5,6,6]  R2357     3.4135526418685913e-01
    z[5,6,6]  R2358     3.1523339450359344e-02
    z[5,6,6]  R2359     3.2076603174209595e-01
    z[5,6,6]  R2360     -4.4919201731681824e-01
    z[5,6,6]  R2361     -3.9003399014472961e-01
    z[5,6,6]  R2362     1.9633628427982330e-01
    z[5,6,6]  R2363     -5.4399389773607254e-02
    z[5,6,6]  R2364     -1.1013595014810562e-01
    z[5,6,6]  R2365     -6.7405253648757935e-02
    z[5,6,6]  R2366     3.1717678066343069e-03
    z[5,6,6]  R2367     -2.1271444857120514e-01
    z[5,6,6]  R2368     -2.4861088395118713e-01
    z[5,6,6]  R2369     -1.8542063236236572e-01
    z[5,6,6]  R2370     -3.2147186994552612e-01
    z[5,6,6]  R2371     -4.6655958890914917e-01
    z[5,6,6]  R2372     -1.2904070317745209e-01
    z[5,6,6]  R2373     -2.1621312201023102e-01
    z[5,6,6]  R2374     -2.8564631938934326e-01
    z[5,6,6]  R2375     -2.0460499450564384e-02
    z[5,6,6]  R2376     -0.547367513179779
    z[5,6,6]  R2377     -2.6937276124954224e-01
    z[5,6,6]  R2378     -6.2870413064956665e-02
    z[5,6,6]  R2379     -7.1676015853881836e-01
    z[5,6,6]  R2380     -1.9281332194805145e-01
    z[5,6,6]  R2381     1.7515836656093597e-01
    z[5,6,6]  R2382     -8.7471000850200653e-02
    z[5,6,6]  R2383     -8.9473605155944824e-02
    z[5,6,6]  R2384     -3.0243399739265442e-01
    z[5,6,6]  R2385     2.1716007590293884e-01
    z[5,6,6]  R2386     2.7200832962989807e-01
    z[5,6,6]  R2387     4.6990740299224854e-01
    z[5,6,6]  R2388     0.0439128652215004
    z[5,6,6]  R2389     2.6646783947944641e-01
    z[5,6,6]  R2390     1.3733452558517456e-01
    z[5,6,6]  R2391     1.0208512842655182e-01
    z[5,6,6]  R2392     -3.5303589701652527e-01
    z[5,6,6]  R2393     4.5818752050399780e-01
    z[5,6,6]  R2394     0.242108553647995
    z[5,6,6]  R2395     2.7308214455842972e-02
    z[5,6,6]  R2396     -2.9468801617622375e-01
    z[5,6,6]  R2397     -4.9768692255020142e-01
    z[5,6,6]  R2398     2.6096296310424805e-01
    z[5,6,6]  R2399     -2.9381856322288513e-01
    z[5,6,6]  R2400     5.3373958915472031e-02
    z[5,6,6]  R2401     -1.4346466958522797e-01
    z[5,6,6]  R2402     -2.6347804069519043e-01
    z[5,6,6]  R2403     -2.9278692603111267e-01
    z[5,6,6]  R2404     -7.4396848678588867e-02
    z[5,6,6]  R2405     2.9214599728584290e-01
    z[5,6,6]  R2406     -4.1162124276161194e-01
    z[5,6,6]  R2407     -2.9800674319267273e-01
    z[5,6,6]  R2408     -2.4290467798709869e-01
    z[5,6,6]  R2409     4.6672880649566650e-02
    z[5,6,6]  R2410     -3.5432377457618713e-01
    z[5,6,6]  R2411     -1.2061487138271332e-01
    z[5,6,6]  R2412     -3.0226796865463257e-01
    z[5,6,6]  R2413     6.0109067708253860e-03
    z[5,6,6]  R2414     -1.4585968852043152e-01
    z[5,6,6]  R2415     9.1197066009044647e-02
    z[5,6,6]  R2416     1.8935346603393555e-01
    z[5,6,6]  R2417     1.8424926698207855e-01
    z[5,6,6]  R2418     -2.7470108866691589e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2419     -1
    z[6,5,0]  R2420     1
    z[6,5,0]  R2433     -4.8729193210601807e-01
    z[6,5,0]  R2434     -6.0099172592163086e-01
    z[6,5,0]  R2435     -3.2954074442386627e-02
    z[6,5,0]  R2436     7.5554296374320984e-02
    z[6,5,0]  R2437     -9.7896084189414978e-02
    z[6,5,0]  R2438     -3.8970449566841125e-01
    z[6,5,0]  R2439     1.2374044954776764e-01
    z[6,5,0]  R2440     2.8977102041244507e-01
    z[6,5,0]  R2441     -4.6530212275683880e-03
    z[6,5,0]  R2442     7.6810702681541443e-02
    z[6,5,0]  R2443     2.7076140046119690e-01
    z[6,5,0]  R2444     2.0435069501399994e-01
    z[6,5,0]  R2445     4.8351809382438660e-03
    z[6,5,0]  R2446     2.4945285916328430e-01
    z[6,5,0]  R2447     0.213861882686615
    z[6,5,0]  R2448     1.9959162175655365e-01
    z[6,5,0]  R2449     1.0795354098081589e-01
    z[6,5,0]  R2450     0.0949750691652298
    z[6,5,0]  R2451     1.0327365249395370e-01
    z[6,5,0]  R2452     -1.4315104484558105e-01
    z[6,5,0]  R2453     1.0323889553546906e-01
    z[6,5,0]  R2454     -0.086922287940979
    z[6,5,0]  R2455     4.8406824469566345e-01
    z[6,5,0]  R2456     1.0395500808954239e-02
    z[6,5,0]  R2457     -1.1849900335073471e-01
    z[6,5,0]  R2458     -4.7565117478370667e-02
    z[6,5,0]  R2459     -2.8622692823410034e-01
    z[6,5,0]  R2460     2.3305535316467285e-02
    z[6,5,0]  R2461     -1.2474393099546432e-01
    z[6,5,0]  R2462     -2.1036426723003387e-01
    z[6,5,0]  R2463     3.2114568352699280e-01
    z[6,5,0]  R2464     1.2799820979125798e-04
    z[6,5,0]  R2465     5.5457610636949539e-02
    z[6,5,0]  R2466     5.2234575152397156e-02
    z[6,5,0]  R2467     8.2452498376369476e-02
    z[6,5,0]  R2468     4.3067926168441772e-01
    z[6,5,0]  R2469     -1.3426003046333790e-02
    z[6,5,0]  R2470     -2.3636072874069214e-02
    z[6,5,0]  R2471     5.2429482340812683e-02
    z[6,5,0]  R2472     -7.5056720525026321e-03
    z[6,5,0]  R2473     7.0652149617671967e-02
    z[6,5,0]  R2474     2.7111560106277466e-01
    z[6,5,0]  R2475     1.9415850937366486e-01
    z[6,5,0]  R2476     1.1719628423452377e-01
    z[6,5,0]  R2477     -7.2154819965362549e-02
    z[6,5,0]  R2478     -1.4037913084030151e-01
    z[6,5,0]  R2479     -5.4189842194318771e-03
    z[6,5,0]  R2480     1.1443827301263809e-01
    z[6,5,0]  R2481     -1.8866352736949921e-01
    z[6,5,0]  R2482     4.2419081926345825e-01
    z[6,5,0]  R2483     2.6447597146034241e-01
    z[6,5,0]  R2484     4.4845908880233765e-02
    z[6,5,0]  R2485     -7.4253201484680176e-02
    z[6,5,0]  R2486     -1.0336951166391373e-01
    z[6,5,0]  R2487     -2.4555101990699768e-03
    z[6,5,0]  R2488     -1.0886755585670471e-01
    z[6,5,0]  R2489     -4.8941407352685928e-02
    z[6,5,0]  R2490     -1.8093822896480560e-01
    z[6,5,0]  R2491     -1.2569734454154968e-01
    z[6,5,0]  R2492     1.0660402476787567e-01
    z[6,5,0]  R2493     1.9257423281669617e-01
    z[6,5,0]  R2494     2.3337945342063904e-01
    z[6,5,0]  R2495     2.6228129863739014e-01
    z[6,5,0]  R2496     3.3634158968925476e-01
    z[6,5,0]  R2497     -9.8939023911952972e-02
    z[6,5,0]  R2498     -4.1293105483055115e-01
    z[6,5,0]  R2499     2.5201907753944397e-01
    z[6,5,0]  R2500     -3.2411229610443115e-01
    z[6,5,0]  R2501     3.0029773712158203e-01
    z[6,5,0]  R2502     -1.3278488814830780e-01
    z[6,5,0]  R2503     -1.9313894212245941e-01
    z[6,5,0]  R2504     -0.614051342010498
    z[6,5,0]  R2505     3.2096934318542480e-01
    z[6,5,0]  R2506     3.5385772585868835e-02
    z[6,5,0]  R2507     -0.0406770296394825
    z[6,5,0]  R2508     -5.2866542339324951e-01
    z[6,5,0]  R2509     -4.5177474617958069e-01
    z[6,5,0]  R2510     4.5386098325252533e-02
    z[6,5,0]  R2511     -1.3763718307018280e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2421     -1
    z[6,5,1]  R2422     1
    z[6,5,1]  R2433     -3.5702398419380188e-01
    z[6,5,1]  R2434     -1.5415129065513611e-01
    z[6,5,1]  R2435     -6.7099016904830933e-01
    z[6,5,1]  R2436     -7.4068850278854370e-01
    z[6,5,1]  R2437     -5.4062509536743164e-01
    z[6,5,1]  R2438     -6.6204947233200073e-01
    z[6,5,1]  R2439     -4.0233135223388672e-01
    z[6,5,1]  R2440     -3.5219326615333557e-01
    z[6,5,1]  R2441     -2.4606880545616150e-01
    z[6,5,1]  R2442     4.4106975197792053e-01
    z[6,5,1]  R2443     -3.9074367284774780e-01
    z[6,5,1]  R2444     -3.0664929747581482e-01
    z[6,5,1]  R2445     -1.6096708178520203e-01
    z[6,5,1]  R2446     3.9459779858589172e-01
    z[6,5,1]  R2447     7.5173395872116089e-01
    z[6,5,1]  R2448     7.4822336435317993e-01
    z[6,5,1]  R2449     6.6282504796981812e-01
    z[6,5,1]  R2450     8.2198286056518555e-01
    z[6,5,1]  R2451     6.5111505985260010e-01
    z[6,5,1]  R2452     8.3069866895675659e-01
    z[6,5,1]  R2453     -4.4804677367210388e-01
    z[6,5,1]  R2454     -3.9826601743698120e-01
    z[6,5,1]  R2455     -2.6746892929077148e-01
    z[6,5,1]  R2456     9.1232210397720337e-01
    z[6,5,1]  R2457     9.3661522865295410e-01
    z[6,5,1]  R2458     7.7929776906967163e-01
    z[6,5,1]  R2459     9.1708499193191528e-01
    z[6,5,1]  R2460     -1.9481889903545380e-01
    z[6,5,1]  R2461     6.5784966945648193e-01
    z[6,5,1]  R2462     0.863397479057312
    z[6,5,1]  R2463     5.0134855508804321e-01
    z[6,5,1]  R2464     4.5813700556755066e-01
    z[6,5,1]  R2465     0.432682067155838
    z[6,5,1]  R2466     4.6237125992774963e-01
    z[6,5,1]  R2467     5.0908207893371582e-01
    z[6,5,1]  R2468     4.8563095927238464e-01
    z[6,5,1]  R2469     8.2065206766128540e-01
    z[6,5,1]  R2470     3.0611601471900940e-01
    z[6,5,1]  R2471     5.0296491384506226e-01
    z[6,5,1]  R2472     0.327528178691864
    z[6,5,1]  R2473     -8.1756854057312012e-01
    z[6,5,1]  R2474     -5.9623104333877563e-01
    z[6,5,1]  R2475     -7.5222784280776978e-01
    z[6,5,1]  R2476     -4.9451699852943420e-01
    z[6,5,1]  R2477     -6.9143062829971313e-01
    z[6,5,1]  R2478     -7.4074578285217285e-01
    z[6,5,1]  R2479     -6.7811751365661621e-01
    z[6,5,1]  R2480     -5.4823744297027588e-01
    z[6,5,1]  R2481     -0.549148678779602
    z[6,5,1]  R2482     -5.0057750940322876e-01
    z[6,5,1]  R2483     2.4117852747440338e-01
    z[6,5,1]  R2484     3.7038120627403259e-01
    z[6,5,1]  R2485     0.503020703792572
    z[6,5,1]  R2486     7.1465331315994263e-01
    z[6,5,1]  R2487     1.6307540237903595e-01
    z[6,5,1]  R2488     5.4639625549316406e-01
    z[6,5,1]  R2489     5.1106256246566772e-01
    z[6,5,1]  R2490     2.0135138928890228e-01
    z[6,5,1]  R2491     5.1603823900222778e-01
    z[6,5,1]  R2492     -4.3186736106872559e-01
    z[6,5,1]  R2493     7.7884471416473389e-01
    z[6,5,1]  R2494     0.612871527671814
    z[6,5,1]  R2495     1.5017915284261107e-03
    z[6,5,1]  R2496     1.7503488063812256e-01
    z[6,5,1]  R2497     6.4956796169281006e-01
    z[6,5,1]  R2498     5.9445953369140625e-01
    z[6,5,1]  R2499     1.1809966713190079e-01
    z[6,5,1]  R2500     -1.1558468639850616e-01
    z[6,5,1]  R2501     2.3782048374414444e-02
    z[6,5,1]  R2502     4.9197566509246826e-01
    z[6,5,1]  R2503     4.1021221876144409e-01
    z[6,5,1]  R2504     5.9973281621932983e-01
    z[6,5,1]  R2505     4.4935470819473267e-01
    z[6,5,1]  R2506     2.8569960594177246e-01
    z[6,5,1]  R2507     4.9081340432167053e-01
    z[6,5,1]  R2508     5.5745017528533936e-01
    z[6,5,1]  R2509     -8.5575558245182037e-02
    z[6,5,1]  R2510     5.8053910732269287e-01
    z[6,5,1]  R2511     -4.2640173435211182e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2423     -1
    z[6,5,2]  R2424     1
    z[6,5,2]  R2433     3.3122763037681580e-01
    z[6,5,2]  R2434     5.5581283569335938e-01
    z[6,5,2]  R2435     1.5156951732933521e-02
    z[6,5,2]  R2436     2.4588094651699066e-01
    z[6,5,2]  R2437     -5.8745924383401871e-02
    z[6,5,2]  R2438     4.3144565820693970e-01
    z[6,5,2]  R2439     -2.6238444447517395e-01
    z[6,5,2]  R2440     -1.4579498767852783e-01
    z[6,5,2]  R2441     2.3747770488262177e-01
    z[6,5,2]  R2442     -5.1327288150787354e-01
    z[6,5,2]  R2443     -9.1044150292873383e-02
    z[6,5,2]  R2444     -6.8464823067188263e-02
    z[6,5,2]  R2445     2.3217935115098953e-02
    z[6,5,2]  R2446     -1.6536971926689148e-01
    z[6,5,2]  R2447     8.6744002997875214e-02
    z[6,5,2]  R2448     2.3347425460815430e-01
    z[6,5,2]  R2449     -1.0240331292152405e-01
    z[6,5,2]  R2450     6.9272637367248535e-02
    z[6,5,2]  R2451     -4.7520559281110764e-02
    z[6,5,2]  R2452     2.3230488598346710e-01
    z[6,5,2]  R2453     1.0994613170623779e-01
    z[6,5,2]  R2454     5.5095762014389038e-01
    z[6,5,2]  R2455     -2.7092188596725464e-01
    z[6,5,2]  R2456     5.5401004850864410e-02
    z[6,5,2]  R2457     3.7188478745520115e-03
    z[6,5,2]  R2458     5.7915952056646347e-02
    z[6,5,2]  R2459     1.3038368523120880e-01
    z[6,5,2]  R2460     -8.4326320886611938e-01
    z[6,5,2]  R2461     -4.6066680806688964e-04
    z[6,5,2]  R2462     2.4493815004825592e-01
    z[6,5,2]  R2463     5.5939173698425293e-01
    z[6,5,2]  R2464     -9.1380871832370758e-02
    z[6,5,2]  R2465     -5.2853405475616455e-01
    z[6,5,2]  R2466     -7.1074366569519043e-01
    z[6,5,2]  R2467     -7.0286047458648682e-01
    z[6,5,2]  R2468     2.5660511851310730e-01
    z[6,5,2]  R2469     -3.3238753676414490e-01
    z[6,5,2]  R2470     -0.294884592294693
    z[6,5,2]  R2471     -6.1701703071594238e-01
    z[6,5,2]  R2472     -5.3743177652359009e-01
    z[6,5,2]  R2473     1.2026625871658325e-01
    z[6,5,2]  R2474     3.4989011287689209e-01
    z[6,5,2]  R2475     -1.1586213111877441e-01
    z[6,5,2]  R2476     -9.3651607632637024e-02
    z[6,5,2]  R2477     -3.5125061869621277e-01
    z[6,5,2]  R2478     2.9583710432052612e-01
    z[6,5,2]  R2479     1.0643537156283855e-02
    z[6,5,2]  R2480     -2.1485063433647156e-01
    z[6,5,2]  R2481     1.8233244121074677e-01
    z[6,5,2]  R2482     -4.7685351222753525e-02
    z[6,5,2]  R2483     -1.6669457778334618e-02
    z[6,5,2]  R2484     1.2669166922569275e-01
    z[6,5,2]  R2485     1.1230615526437759e-01
    z[6,5,2]  R2486     1.9065700471401215e-01
    z[6,5,2]  R2487     4.4778954982757568e-01
    z[6,5,2]  R2488     3.6488610506057739e-01
    z[6,5,2]  R2489     2.6896793395280838e-02
    z[6,5,2]  R2490     1.7822082340717316e-01
    z[6,5,2]  R2491     1.7628322541713715e-01
    z[6,5,2]  R2492     1.2772007286548615e-01
    z[6,5,2]  R2493     -2.4267971515655518e-01
    z[6,5,2]  R2494     -1.1833103001117706e-01
    z[6,5,2]  R2495     -2.2095292806625366e-01
    z[6,5,2]  R2496     2.4815934896469116e-01
    z[6,5,2]  R2497     0.269465833902359
    z[6,5,2]  R2498     2.2802762687206268e-01
    z[6,5,2]  R2499     2.2638346254825592e-01
    z[6,5,2]  R2500     -4.9153584241867065e-01
    z[6,5,2]  R2501     -1.8757960200309753e-01
    z[6,5,2]  R2502     1.7887100577354431e-01
    z[6,5,2]  R2503     -8.5737422108650208e-02
    z[6,5,2]  R2504     2.5774728506803513e-02
    z[6,5,2]  R2505     3.8702264428138733e-01
    z[6,5,2]  R2506     4.7996929287910461e-01
    z[6,5,2]  R2507     -3.9740979671478271e-01
    z[6,5,2]  R2508     4.5599198341369629e-01
    z[6,5,2]  R2509     -1.8403373658657074e-01
    z[6,5,2]  R2510     3.6123567819595337e-01
    z[6,5,2]  R2511     5.4145264625549316e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2425     -1
    z[6,5,3]  R2426     1
    z[6,5,3]  R2433     3.4000462293624878e-01
    z[6,5,3]  R2434     4.3322449922561646e-01
    z[6,5,3]  R2435     1.7993398010730743e-01
    z[6,5,3]  R2436     4.8892334103584290e-01
    z[6,5,3]  R2437     5.5010837316513062e-01
    z[6,5,3]  R2438     1.3757245242595673e-01
    z[6,5,3]  R2439     1.3948038220405579e-01
    z[6,5,3]  R2440     5.0318348407745361e-01
    z[6,5,3]  R2441     2.5663191080093384e-01
    z[6,5,3]  R2442     5.1807653903961182e-01
    z[6,5,3]  R2443     -7.7442824840545654e-01
    z[6,5,3]  R2444     -8.5130870342254639e-01
    z[6,5,3]  R2445     -6.3003784418106079e-01
    z[6,5,3]  R2446     2.8973874449729919e-01
    z[6,5,3]  R2447     -5.4302328824996948e-01
    z[6,5,3]  R2448     -4.9294564127922058e-01
    z[6,5,3]  R2449     -4.6769458055496216e-01
    z[6,5,3]  R2450     -1.9529570639133453e-01
    z[6,5,3]  R2451     -4.9641317129135132e-01
    z[6,5,3]  R2452     1.0120025277137756e-01
    z[6,5,3]  R2453     -4.3710049986839294e-01
    z[6,5,3]  R2454     -4.9073022603988647e-01
    z[6,5,3]  R2455     -2.5777477025985718e-01
    z[6,5,3]  R2456     -1.5390133485198021e-02
    z[6,5,3]  R2457     -6.4651072025299072e-02
    z[6,5,3]  R2458     2.9587191343307495e-01
    z[6,5,3]  R2459     -1.4695847034454346e-01
    z[6,5,3]  R2460     -0.332194447517395
    z[6,5,3]  R2461     1.6896338760852814e-01
    z[6,5,3]  R2462     -1.7404754459857941e-01
    z[6,5,3]  R2463     1.5760849416255951e-01
    z[6,5,3]  R2464     2.3670193552970886e-01
    z[6,5,3]  R2465     7.3240667581558228e-02
    z[6,5,3]  R2466     5.2571866661310196e-02
    z[6,5,3]  R2467     1.6801701486110687e-01
    z[6,5,3]  R2468     2.7998885512351990e-01
    z[6,5,3]  R2469     3.1080448627471924e-01
    z[6,5,3]  R2470     6.3498966395854950e-02
    z[6,5,3]  R2471     -0.07258290797472
    z[6,5,3]  R2472     -1.0689292103052139e-01
    z[6,5,3]  R2473     -4.5449972152709961e-01
    z[6,5,3]  R2474     -5.6289356946945190e-01
    z[6,5,3]  R2475     -4.6246212720870972e-01
    z[6,5,3]  R2476     -0.708291232585907
    z[6,5,3]  R2477     -4.3603339791297913e-01
    z[6,5,3]  R2478     -3.6672791838645935e-01
    z[6,5,3]  R2479     -5.9832257032394409e-01
    z[6,5,3]  R2480     -0.545274555683136
    z[6,5,3]  R2481     -6.8221920728683472e-01
    z[6,5,3]  R2482     -5.6845504045486450e-01
    z[6,5,3]  R2483     5.5740290880203247e-01
    z[6,5,3]  R2484     0.578544020652771
    z[6,5,3]  R2485     -6.0288065671920776e-01
    z[6,5,3]  R2486     -3.4921801090240479e-01
    z[6,5,3]  R2487     6.2654447555541992e-01
    z[6,5,3]  R2488     -5.2741795778274536e-01
    z[6,5,3]  R2489     -7.4762272834777832e-01
    z[6,5,3]  R2490     3.4952321648597717e-01
    z[6,5,3]  R2491     5.9685643762350082e-02
    z[6,5,3]  R2492     8.6430960893630981e-01
    z[6,5,3]  R2493     2.3574048280715942e-01
    z[6,5,3]  R2494     5.7690471410751343e-01
    z[6,5,3]  R2495     8.9302927255630493e-01
    z[6,5,3]  R2496     9.8066650331020355e-02
    z[6,5,3]  R2497     -2.5251312181353569e-02
    z[6,5,3]  R2498     -6.1161148548126221e-01
    z[6,5,3]  R2499     5.6304007768630981e-01
    z[6,5,3]  R2500     0.721450924873352
    z[6,5,3]  R2501     -0.00906460452824831
    z[6,5,3]  R2502     -4.1713351011276245e-01
    z[6,5,3]  R2503     0.0668509304523468
    z[6,5,3]  R2504     -4.4703356921672821e-02
    z[6,5,3]  R2505     5.5620354413986206e-01
    z[6,5,3]  R2506     5.3038930892944336e-01
    z[6,5,3]  R2507     3.3827179670333862e-01
    z[6,5,3]  R2508     2.0165410637855530e-01
    z[6,5,3]  R2509     6.4370816946029663e-01
    z[6,5,3]  R2510     -1.5139554627239704e-02
    z[6,5,3]  R2511     5.7504045963287354e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2427     -1
    z[6,5,4]  R2428     1
    z[6,5,4]  R2433     -4.6212986111640930e-01
    z[6,5,4]  R2434     -1.0306835174560547e-01
    z[6,5,4]  R2435     2.4907572567462921e-01
    z[6,5,4]  R2436     3.5415120422840118e-02
    z[6,5,4]  R2437     2.5946739315986633e-01
    z[6,5,4]  R2438     3.1383502483367920e-01
    z[6,5,4]  R2439     -6.5896719694137573e-01
    z[6,5,4]  R2440     -0.596753716468811
    z[6,5,4]  R2441     -6.1668014526367188e-01
    z[6,5,4]  R2442     -0.358946830034256
    z[6,5,4]  R2443     6.9367498159408569e-02
    z[6,5,4]  R2444     -0.0192574355751276
    z[6,5,4]  R2445     5.4983311891555786e-01
    z[6,5,4]  R2446     7.6512259244918823e-01
    z[6,5,4]  R2447     1.8830262124538422e-02
    z[6,5,4]  R2448     1.5435796976089478e-01
    z[6,5,4]  R2449     4.5882749557495117e-01
    z[6,5,4]  R2450     -4.8992950469255447e-02
    z[6,5,4]  R2451     2.2206287086009979e-01
    z[6,5,4]  R2452     0.18660868704319
    z[6,5,4]  R2453     -2.0885774865746498e-02
    z[6,5,4]  R2454     -6.6024191677570343e-02
    z[6,5,4]  R2455     5.5955165624618530e-01
    z[6,5,4]  R2456     1.1262305080890656e-01
    z[6,5,4]  R2457     2.5707712769508362e-01
    z[6,5,4]  R2458     1.4648343622684479e-01
    z[6,5,4]  R2459     4.4894441962242126e-02
    z[6,5,4]  R2460     0.320562481880188
    z[6,5,4]  R2461     4.6578127145767212e-01
    z[6,5,4]  R2462     1.7981793731451035e-02
    z[6,5,4]  R2463     -5.2295696735382080e-01
    z[6,5,4]  R2464     -7.3008544743061066e-02
    z[6,5,4]  R2465     6.6151313483715057e-02
    z[6,5,4]  R2466     -3.2162305712699890e-01
    z[6,5,4]  R2467     0.0360804907977581
    z[6,5,4]  R2468     -3.5811248421669006e-01
    z[6,5,4]  R2469     -2.3946642875671387e-01
    z[6,5,4]  R2470     -2.9947438836097717e-01
    z[6,5,4]  R2471     -4.9453905224800110e-01
    z[6,5,4]  R2472     -3.8763910531997681e-01
    z[6,5,4]  R2473     -1.1475600302219391e-01
    z[6,5,4]  R2474     -4.1680745780467987e-03
    z[6,5,4]  R2475     2.9905638098716736e-01
    z[6,5,4]  R2476     7.8380726277828217e-02
    z[6,5,4]  R2477     2.1771165728569031e-01
    z[6,5,4]  R2478     2.9940694570541382e-01
    z[6,5,4]  R2479     4.2538410425186157e-01
    z[6,5,4]  R2480     -0.0423019640147686
    z[6,5,4]  R2481     2.6569724082946777e-01
    z[6,5,4]  R2482     5.8113500475883484e-02
    z[6,5,4]  R2483     -1.3618029654026031e-01
    z[6,5,4]  R2484     5.5409145355224609e-01
    z[6,5,4]  R2485     4.0063974261283875e-01
    z[6,5,4]  R2486     0.537505567073822
    z[6,5,4]  R2487     5.9833395481109619e-01
    z[6,5,4]  R2488     3.5292837023735046e-01
    z[6,5,4]  R2489     1.5173371136188507e-01
    z[6,5,4]  R2490     8.2123500108718872e-01
    z[6,5,4]  R2491     7.8610116243362427e-01
    z[6,5,4]  R2492     -3.6398649215698242e-02
    z[6,5,4]  R2493     1.8064025044441223e-01
    z[6,5,4]  R2494     0.0169846098870039
    z[6,5,4]  R2495     -2.3943005502223969e-01
    z[6,5,4]  R2496     -6.4937502145767212e-01
    z[6,5,4]  R2497     5.4747790098190308e-01
    z[6,5,4]  R2498     1.4513424038887024e-01
    z[6,5,4]  R2499     -2.9419302940368652e-01
    z[6,5,4]  R2500     2.1047417819499969e-01
    z[6,5,4]  R2501     -0.92336106300354
    z[6,5,4]  R2502     0.0594811849296093
    z[6,5,4]  R2503     5.9035980701446533e-01
    z[6,5,4]  R2504     -4.6010011434555054e-01
    z[6,5,4]  R2505     3.3176541328430176e-02
    z[6,5,4]  R2506     3.0229237675666809e-01
    z[6,5,4]  R2507     6.2527048587799072e-01
    z[6,5,4]  R2508     3.3453187346458435e-01
    z[6,5,4]  R2509     5.0589525699615479e-01
    z[6,5,4]  R2510     5.4702854156494141e-01
    z[6,5,4]  R2511     -4.0859675407409668e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2429     -1
    z[6,5,5]  R2430     1
    z[6,5,5]  R2433     3.5383099317550659e-01
    z[6,5,5]  R2434     0.298246830701828
    z[6,5,5]  R2435     6.6604816913604736e-01
    z[6,5,5]  R2436     1.4240823686122894e-01
    z[6,5,5]  R2437     -3.3883821964263916e-01
    z[6,5,5]  R2438     2.1826688945293427e-01
    z[6,5,5]  R2439     5.4729700088500977e-01
    z[6,5,5]  R2440     -2.7310594916343689e-01
    z[6,5,5]  R2441     4.3495544791221619e-01
    z[6,5,5]  R2442     2.6600891351699829e-01
    z[6,5,5]  R2443     -2.7356579899787903e-01
    z[6,5,5]  R2444     -0.362730473279953
    z[6,5,5]  R2445     -0.503667414188385
    z[6,5,5]  R2446     1.2624172866344452e-01
    z[6,5,5]  R2447     -2.6105238124728203e-02
    z[6,5,5]  R2448     -2.7103149890899658e-01
    z[6,5,5]  R2449     -1.5463612973690033e-01
    z[6,5,5]  R2450     -3.1710001826286316e-01
    z[6,5,5]  R2451     4.2258673906326294e-01
    z[6,5,5]  R2452     -3.6251193284988403e-01
    z[6,5,5]  R2453     -7.6343721151351929e-01
    z[6,5,5]  R2454     -3.9944148063659668e-01
    z[6,5,5]  R2455     -4.7607335448265076e-01
    z[6,5,5]  R2456     -2.4536564946174622e-01
    z[6,5,5]  R2457     -1.9593752920627594e-01
    z[6,5,5]  R2458     -5.0675994157791138e-01
    z[6,5,5]  R2459     -1.6763083636760712e-01
    z[6,5,5]  R2460     -3.7964764982461929e-02
    z[6,5,5]  R2461     -5.2175086736679077e-01
    z[6,5,5]  R2462     2.1028614044189453e-01
    z[6,5,5]  R2463     1.7254360020160675e-01
    z[6,5,5]  R2464     0.782616138458252
    z[6,5,5]  R2465     4.1756004095077515e-01
    z[6,5,5]  R2466     2.6718342304229736e-01
    z[6,5,5]  R2467     5.2473846822977066e-02
    z[6,5,5]  R2468     -1.7000629007816315e-01
    z[6,5,5]  R2469     -4.7777980566024780e-02
    z[6,5,5]  R2470     8.3798050880432129e-01
    z[6,5,5]  R2471     3.3537822961807251e-01
    z[6,5,5]  R2472     0.630859911441803
    z[6,5,5]  R2473     -2.0510685443878174e-01
    z[6,5,5]  R2474     -3.3171677589416504e-01
    z[6,5,5]  R2475     -4.5201838016510010e-02
    z[6,5,5]  R2476     -4.7424682974815369e-01
    z[6,5,5]  R2477     -3.8958451151847839e-01
    z[6,5,5]  R2478     -2.3353940248489380e-01
    z[6,5,5]  R2479     -3.1496521085500717e-02
    z[6,5,5]  R2480     -4.7385808825492859e-01
    z[6,5,5]  R2481     -3.0427780747413635e-01
    z[6,5,5]  R2482     -3.7121587991714478e-01
    z[6,5,5]  R2483     -5.8360165357589722e-01
    z[6,5,5]  R2484     -2.2560764849185944e-01
    z[6,5,5]  R2485     -0.407821923494339
    z[6,5,5]  R2486     1.6855373978614807e-01
    z[6,5,5]  R2487     1.0096298158168793e-01
    z[6,5,5]  R2488     -3.8624534010887146e-01
    z[6,5,5]  R2489     -3.9207586646080017e-01
    z[6,5,5]  R2490     2.3046796023845673e-01
    z[6,5,5]  R2491     -0.0591965913772583
    z[6,5,5]  R2492     -5.5470943450927734e-02
    z[6,5,5]  R2493     -3.2538297772407532e-01
    z[6,5,5]  R2494     -7.1658574044704437e-02
    z[6,5,5]  R2495     1.0443413257598877e-01
    z[6,5,5]  R2496     -0.562673032283783
    z[6,5,5]  R2497     3.3719030022621155e-01
    z[6,5,5]  R2498     -1.6899110376834869e-01
    z[6,5,5]  R2499     -0.410017728805542
    z[6,5,5]  R2500     5.1297504454851151e-02
    z[6,5,5]  R2501     -1.3205739855766296e-01
    z[6,5,5]  R2502     -1.3057488203048706e-01
    z[6,5,5]  R2503     6.3000130653381348e-01
    z[6,5,5]  R2504     1.3500395417213440e-01
    z[6,5,5]  R2505     -4.7661134600639343e-01
    z[6,5,5]  R2506     5.5322146415710449e-01
    z[6,5,5]  R2507     -5.1534615457057953e-02
    z[6,5,5]  R2508     4.5814774930477142e-02
    z[6,5,5]  R2509     1.0212268680334091e-01
    z[6,5,5]  R2510     1.0070103406906128e-01
    z[6,5,5]  R2511     -8.0719053745269775e-02
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2431     -1
    z[6,5,6]  R2432     1
    z[6,5,6]  R2433     2.6646783947944641e-01
    z[6,5,6]  R2434     1.3733452558517456e-01
    z[6,5,6]  R2435     1.0208512842655182e-01
    z[6,5,6]  R2436     -3.5303589701652527e-01
    z[6,5,6]  R2437     4.5818752050399780e-01
    z[6,5,6]  R2438     0.242108553647995
    z[6,5,6]  R2439     2.7308214455842972e-02
    z[6,5,6]  R2440     -2.9468801617622375e-01
    z[6,5,6]  R2441     -4.9768692255020142e-01
    z[6,5,6]  R2442     2.6096296310424805e-01
    z[6,5,6]  R2443     -2.9381856322288513e-01
    z[6,5,6]  R2444     5.3373958915472031e-02
    z[6,5,6]  R2445     -1.4346466958522797e-01
    z[6,5,6]  R2446     -2.6347804069519043e-01
    z[6,5,6]  R2447     -2.9278692603111267e-01
    z[6,5,6]  R2448     -7.4396848678588867e-02
    z[6,5,6]  R2449     2.9214599728584290e-01
    z[6,5,6]  R2450     -4.1162124276161194e-01
    z[6,5,6]  R2451     -2.9800674319267273e-01
    z[6,5,6]  R2452     -2.4290467798709869e-01
    z[6,5,6]  R2453     4.6672880649566650e-02
    z[6,5,6]  R2454     -3.5432377457618713e-01
    z[6,5,6]  R2455     -1.2061487138271332e-01
    z[6,5,6]  R2456     -3.0226796865463257e-01
    z[6,5,6]  R2457     6.0109067708253860e-03
    z[6,5,6]  R2458     -1.4585968852043152e-01
    z[6,5,6]  R2459     9.1197066009044647e-02
    z[6,5,6]  R2460     1.8935346603393555e-01
    z[6,5,6]  R2461     1.8424926698207855e-01
    z[6,5,6]  R2462     -2.7470108866691589e-01
    z[6,5,6]  R2463     -6.7084066569805145e-02
    z[6,5,6]  R2464     3.2850247621536255e-01
    z[6,5,6]  R2465     5.8844357728958130e-01
    z[6,5,6]  R2466     3.1738871335983276e-01
    z[6,5,6]  R2467     4.5578393340110779e-01
    z[6,5,6]  R2468     5.2658468484878540e-01
    z[6,5,6]  R2469     -2.4421733617782593e-01
    z[6,5,6]  R2470     -1.5115892887115479e-01
    z[6,5,6]  R2471     -3.5378482192754745e-02
    z[6,5,6]  R2472     2.1014676988124847e-01
    z[6,5,6]  R2473     2.2431743144989014e-01
    z[6,5,6]  R2474     1.4723828434944153e-01
    z[6,5,6]  R2475     2.7871602773666382e-01
    z[6,5,6]  R2476     -1.4741206541657448e-02
    z[6,5,6]  R2477     -6.3567437231540680e-02
    z[6,5,6]  R2478     2.5572484731674194e-01
    z[6,5,6]  R2479     -8.9660808444023132e-03
    z[6,5,6]  R2480     3.4135526418685913e-01
    z[6,5,6]  R2481     3.1523339450359344e-02
    z[6,5,6]  R2482     3.2076603174209595e-01
    z[6,5,6]  R2483     -4.4919201731681824e-01
    z[6,5,6]  R2484     -3.9003399014472961e-01
    z[6,5,6]  R2485     1.9633628427982330e-01
    z[6,5,6]  R2486     -5.4399389773607254e-02
    z[6,5,6]  R2487     -1.1013595014810562e-01
    z[6,5,6]  R2488     -6.7405253648757935e-02
    z[6,5,6]  R2489     3.1717678066343069e-03
    z[6,5,6]  R2490     -2.1271444857120514e-01
    z[6,5,6]  R2491     -2.4861088395118713e-01
    z[6,5,6]  R2492     -1.8542063236236572e-01
    z[6,5,6]  R2493     -3.2147186994552612e-01
    z[6,5,6]  R2494     -4.6655958890914917e-01
    z[6,5,6]  R2495     -1.2904070317745209e-01
    z[6,5,6]  R2496     -2.1621312201023102e-01
    z[6,5,6]  R2497     -2.8564631938934326e-01
    z[6,5,6]  R2498     -2.0460499450564384e-02
    z[6,5,6]  R2499     -0.547367513179779
    z[6,5,6]  R2500     -2.6937276124954224e-01
    z[6,5,6]  R2501     -6.2870413064956665e-02
    z[6,5,6]  R2502     -7.1676015853881836e-01
    z[6,5,6]  R2503     -1.9281332194805145e-01
    z[6,5,6]  R2504     1.7515836656093597e-01
    z[6,5,6]  R2505     -8.7471000850200653e-02
    z[6,5,6]  R2506     -8.9473605155944824e-02
    z[6,5,6]  R2507     -3.0243399739265442e-01
    z[6,5,6]  R2508     2.1716007590293884e-01
    z[6,5,6]  R2509     2.7200832962989807e-01
    z[6,5,6]  R2510     4.6990740299224854e-01
    z[6,5,6]  R2511     0.0439128652215004
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,8]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[7,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
