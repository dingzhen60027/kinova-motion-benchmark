NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       2.6157422065734863e+00
    phi[0,1]  R89       3.4984321594238281e+00
    phi[0,1]  R90       3.0857973098754883e+00
    phi[0,1]  R91       2.1429793834686279e+00
    phi[0,1]  R92       1.7277643680572510e+00
    phi[0,1]  R93       1.4769130945205688e+00
    phi[0,1]  R94       2.1519777774810791e+00
    phi[0,1]  R95       2.8141708374023438e+00
    phi[0,1]  R96       1.7630393505096436e+00
    phi[0,1]  R97       1.2200624942779541e+00
    phi[0,1]  R98       6.5499210357666016e-01
    phi[0,1]  R99       -1.8682315349578857e+00
    phi[0,1]  R100      7.4882604181766510e-02
    phi[0,1]  R101      -1.4402084350585938e+00
    phi[0,1]  R102      -2.9155077934265137e+00
    phi[0,1]  R103      -2.0621032714843750e+00
    phi[0,1]  R104      -1.8036371469497681e+00
    phi[0,1]  R105      -2.0142946243286133e+00
    phi[0,1]  R106      -1.8758676052093506e+00
    phi[0,1]  R107      6.3090139627456665e-01
    phi[0,1]  R108      2.8656992316246033e-01
    phi[0,1]  R109      -7.1085792779922485e-01
    phi[0,1]  R110      -3.5326974391937256e+00
    phi[0,1]  R111      -3.1176834106445312e+00
    phi[0,1]  R112      -2.4946537017822266e+00
    phi[0,1]  R113      1.1102612018585205e+00
    phi[0,1]  R114      -1.6898038387298584e+00
    phi[0,1]  R115      -1.5859068632125854e+00
    phi[0,1]  R116      -4.3703576922416687e-01
    phi[0,1]  R117      -1.0693446397781372e+00
    phi[0,1]  R118      2.6126177310943604e+00
    phi[0,1]  R119      1.5704927444458008e+00
    phi[0,1]  R120      7.5794732570648193e-01
    phi[0,1]  R121      3.1836397647857666e+00
    phi[0,1]  R122      1.6320019960403442e+00
    phi[0,1]  R123      2.4731736183166504e+00
    phi[0,1]  R124      1.4730331897735596e+00
    phi[0,1]  R125      2.4531056880950928e+00
    phi[0,1]  R126      2.7766110897064209e+00
    phi[0,1]  R127      -1.8515540361404419e+00
    phi[0,1]  R128      -2.9533631801605225e+00
    phi[0,1]  R129      -3.0183370113372803e+00
    phi[0,1]  R130      -3.9356119632720947e+00
    phi[0,1]  R131      -4.6908438205718994e-01
    phi[0,1]  R132      -3.1374628543853760e+00
    phi[0,1]  R133      -3.1096434593200684e+00
    phi[0,1]  R134      -2.4364817142486572e+00
    phi[0,1]  R135      -8.1958872079849243e-01
    phi[0,1]  R136      -2.6413817405700684e+00
    phi[0,1]  R137      -1.6340504884719849e+00
    phi[0,1]  R138      -9.0022522211074829e-01
    phi[0,1]  R139      -7.7695703506469727e-01
    phi[0,1]  R140      -1.1260414123535156e+00
    phi[0,1]  R141      -2.0485693216323853e-01
    phi[0,1]  R142      1.4550510644912720e+00
    phi[0,1]  R143      -1.0401009321212769e+00
    phi[0,1]  R144      1.3192950189113617e-01
    phi[0,1]  R145      -1.1619919538497925e+00
    phi[0,1]  R146      -5.1517164707183838e-01
    phi[0,1]  R147      -2.8970115184783936e+00
    phi[0,1]  R148      -1.2580102682113647e+00
    phi[0,1]  R149      -0.576869010925293
    phi[0,1]  R150      -1.0263688564300537e+00
    phi[0,1]  R151      -0.0836499035358429
    phi[0,1]  R152      -2.5835003852844238e+00
    phi[0,1]  R153      4.1880589723587036e-01
    phi[0,1]  R154      -1.7979124188423157e-01
    phi[0,1]  R155      0.462185800075531
    phi[0,1]  R156      5.6358379125595093e-01
    phi[0,1]  R157      -2.9672653675079346e+00
    phi[0,1]  R158      -2.7175994589924812e-02
    phi[0,1]  R159      -2.8232073783874512e+00
    phi[0,1]  R160      -2.2640435695648193e+00
    phi[0,1]  R161      -1.3041093349456787e+00
    phi[0,1]  R162      -4.5928782224655151e-01
    phi[0,1]  R163      -9.5551824569702148e-01
    phi[0,1]  R164      -6.3410186767578125e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R165      -3.0999999046325684e+00
    phi[1,0]  R166      -3.0999999046325684e+00
    phi[1,0]  R167      -2.2400000095367432e+00
    phi[1,0]  R168      -2.2400000095367432e+00
    phi[1,0]  R169      -3.0999999046325684e+00
    phi[1,0]  R170      -3.0999999046325684e+00
    phi[1,0]  R171      -2.5699999332427979e+00
    phi[1,0]  R172      -2.5699999332427979e+00
    phi[1,0]  R173      -3.0999999046325684e+00
    phi[1,0]  R174      -3.0999999046325684e+00
    phi[1,0]  R175      -2.0899999141693115e+00
    phi[1,0]  R176      -2.0899999141693115e+00
    phi[1,0]  R177      -3.0999999046325684e+00
    phi[1,0]  R178      -3.0999999046325684e+00
    phi[1,0]  R179      2.6126177310943604e+00
    phi[1,0]  R180      1.5704927444458008e+00
    phi[1,0]  R181      7.5794732570648193e-01
    phi[1,0]  R182      3.1836397647857666e+00
    phi[1,0]  R183      1.6320019960403442e+00
    phi[1,0]  R184      2.4731736183166504e+00
    phi[1,0]  R185      1.4730331897735596e+00
    phi[1,0]  R186      2.4531056880950928e+00
    phi[1,0]  R187      2.7766110897064209e+00
    phi[1,0]  R188      -1.8515540361404419e+00
    phi[1,0]  R189      -2.9533631801605225e+00
    phi[1,0]  R190      -3.0183370113372803e+00
    phi[1,0]  R191      -3.9356119632720947e+00
    phi[1,0]  R192      -4.6908438205718994e-01
    phi[1,0]  R193      -3.1374628543853760e+00
    phi[1,0]  R194      -3.1096434593200684e+00
    phi[1,0]  R195      -2.4364817142486572e+00
    phi[1,0]  R196      -8.1958872079849243e-01
    phi[1,0]  R197      -2.6413817405700684e+00
    phi[1,0]  R198      -1.6340504884719849e+00
    phi[1,0]  R199      -9.0022522211074829e-01
    phi[1,0]  R200      -7.7695703506469727e-01
    phi[1,0]  R201      -1.1260414123535156e+00
    phi[1,0]  R202      -2.0485693216323853e-01
    phi[1,0]  R203      1.4550510644912720e+00
    phi[1,0]  R204      -1.0401009321212769e+00
    phi[1,0]  R205      1.3192950189113617e-01
    phi[1,0]  R206      -1.1619919538497925e+00
    phi[1,0]  R207      -5.1517164707183838e-01
    phi[1,0]  R208      -2.8970115184783936e+00
    phi[1,0]  R209      -1.2580102682113647e+00
    phi[1,0]  R210      -0.576869010925293
    phi[1,0]  R211      -1.0263688564300537e+00
    phi[1,0]  R212      -0.0836499035358429
    phi[1,0]  R213      -2.5835003852844238e+00
    phi[1,0]  R214      4.1880589723587036e-01
    phi[1,0]  R215      -1.7979124188423157e-01
    phi[1,0]  R216      0.462185800075531
    phi[1,0]  R217      5.6358379125595093e-01
    phi[1,0]  R218      -2.9672653675079346e+00
    phi[1,0]  R219      -2.7175994589924812e-02
    phi[1,0]  R220      -2.8232073783874512e+00
    phi[1,0]  R221      -2.2640435695648193e+00
    phi[1,0]  R222      -1.3041093349456787e+00
    phi[1,0]  R223      -4.5928782224655151e-01
    phi[1,0]  R224      -9.5551824569702148e-01
    phi[1,0]  R225      -6.3410186767578125e-01
    phi[1,0]  R226      2.6157422065734863e+00
    phi[1,0]  R227      3.4984321594238281e+00
    phi[1,0]  R228      3.0857973098754883e+00
    phi[1,0]  R229      2.1429793834686279e+00
    phi[1,0]  R230      1.7277643680572510e+00
    phi[1,0]  R231      1.4769130945205688e+00
    phi[1,0]  R232      2.1519777774810791e+00
    phi[1,0]  R233      2.8141708374023438e+00
    phi[1,0]  R234      1.7630393505096436e+00
    phi[1,0]  R235      1.2200624942779541e+00
    phi[1,0]  R236      6.5499210357666016e-01
    phi[1,0]  R237      -1.8682315349578857e+00
    phi[1,0]  R238      7.4882604181766510e-02
    phi[1,0]  R239      -1.4402084350585938e+00
    phi[1,0]  R240      -2.9155077934265137e+00
    phi[1,0]  R241      -2.0621032714843750e+00
    phi[1,0]  R242      -1.8036371469497681e+00
    phi[1,0]  R243      -2.0142946243286133e+00
    phi[1,0]  R244      -1.8758676052093506e+00
    phi[1,0]  R245      6.3090139627456665e-01
    phi[1,0]  R246      2.8656992316246033e-01
    phi[1,0]  R247      -7.1085792779922485e-01
    phi[1,0]  R248      -3.5326974391937256e+00
    phi[1,0]  R249      -3.1176834106445312e+00
    phi[1,0]  R250      -2.4946537017822266e+00
    phi[1,0]  R251      1.1102612018585205e+00
    phi[1,0]  R252      -1.6898038387298584e+00
    phi[1,0]  R253      -1.5859068632125854e+00
    phi[1,0]  R254      -4.3703576922416687e-01
    phi[1,0]  R255      -1.0693446397781372e+00
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R256      -3.0999999046325684e+00
    phi[0,5]  R257      -3.0999999046325684e+00
    phi[0,5]  R258      -2.2400000095367432e+00
    phi[0,5]  R259      -2.2400000095367432e+00
    phi[0,5]  R260      -3.0999999046325684e+00
    phi[0,5]  R261      -3.0999999046325684e+00
    phi[0,5]  R262      -2.5699999332427979e+00
    phi[0,5]  R263      -2.5699999332427979e+00
    phi[0,5]  R264      -3.0999999046325684e+00
    phi[0,5]  R265      -3.0999999046325684e+00
    phi[0,5]  R266      -2.0899999141693115e+00
    phi[0,5]  R267      -2.0899999141693115e+00
    phi[0,5]  R268      -3.0999999046325684e+00
    phi[0,5]  R269      -3.0999999046325684e+00
    phi[0,5]  R270      2.6157422065734863e+00
    phi[0,5]  R271      3.4984321594238281e+00
    phi[0,5]  R272      3.0857973098754883e+00
    phi[0,5]  R273      2.1429793834686279e+00
    phi[0,5]  R274      1.7277643680572510e+00
    phi[0,5]  R275      1.4769130945205688e+00
    phi[0,5]  R276      2.1519777774810791e+00
    phi[0,5]  R277      2.8141708374023438e+00
    phi[0,5]  R278      1.7630393505096436e+00
    phi[0,5]  R279      1.2200624942779541e+00
    phi[0,5]  R280      6.5499210357666016e-01
    phi[0,5]  R281      -1.8682315349578857e+00
    phi[0,5]  R282      7.4882604181766510e-02
    phi[0,5]  R283      -1.4402084350585938e+00
    phi[0,5]  R284      -2.9155077934265137e+00
    phi[0,5]  R285      -2.0621032714843750e+00
    phi[0,5]  R286      -1.8036371469497681e+00
    phi[0,5]  R287      -2.0142946243286133e+00
    phi[0,5]  R288      -1.8758676052093506e+00
    phi[0,5]  R289      6.3090139627456665e-01
    phi[0,5]  R290      2.8656992316246033e-01
    phi[0,5]  R291      -7.1085792779922485e-01
    phi[0,5]  R292      -3.5326974391937256e+00
    phi[0,5]  R293      -3.1176834106445312e+00
    phi[0,5]  R294      -2.4946537017822266e+00
    phi[0,5]  R295      1.1102612018585205e+00
    phi[0,5]  R296      -1.6898038387298584e+00
    phi[0,5]  R297      -1.5859068632125854e+00
    phi[0,5]  R298      -4.3703576922416687e-01
    phi[0,5]  R299      -1.0693446397781372e+00
    phi[0,5]  R300      3.2479326725006104e+00
    phi[0,5]  R301      1.6247555017471313e+00
    phi[0,5]  R302      3.3914930820465088e+00
    phi[0,5]  R303      3.0739970207214355e+00
    phi[0,5]  R304      3.7849428653717041e+00
    phi[0,5]  R305      2.4234609603881836e+00
    phi[0,5]  R306      -1.7760206013917923e-02
    phi[0,5]  R307      -1.0389789342880249e+00
    phi[0,5]  R308      -2.7524518966674805e+00
    phi[0,5]  R309      -2.1403837203979492e+00
    phi[0,5]  R310      2.1624360978603363e-01
    phi[0,5]  R311      -1.3960171937942505e+00
    phi[0,5]  R312      -1.8711503744125366e+00
    phi[0,5]  R313      -1.1130977869033813e+00
    phi[0,5]  R314      -2.0367376804351807e+00
    phi[0,5]  R315      -2.2653191089630127e+00
    phi[0,5]  R316      -1.81752610206604
    phi[0,5]  R317      -1.9954869747161865e+00
    phi[0,5]  R318      -2.0656652450561523e+00
    phi[0,5]  R319      -2.3404552936553955e+00
    phi[0,5]  R320      -1.8564933538436890e+00
    phi[0,5]  R321      -1.3937898874282837e+00
    phi[0,5]  R322      -3.3122777938842773e+00
    phi[0,5]  R323      -2.8184773921966553e+00
    phi[0,5]  R324      -1.7431690692901611e+00
    phi[0,5]  R325      -8.6689352989196777e-01
    phi[0,5]  R326      -2.0262813568115234e+00
    phi[0,5]  R327      -2.0563969612121582e+00
    phi[0,5]  R328      2.5259044766426086e-01
    phi[0,5]  R329      -0.625604510307312
    phi[0,5]  R330      -4.2457967996597290e-01
    phi[0,5]  R331      -2.1121010780334473e+00
    phi[0,5]  R332      -4.6376881599426270e+00
    phi[0,5]  R333      -3.1730980873107910e+00
    phi[0,5]  R334      -1.5191409587860107e+00
    phi[0,5]  R335      -3.0325779914855957e+00
    phi[0,5]  R336      -1.0819907486438751e-01
    phi[0,5]  R337      -6.5798111259937286e-02
    phi[0,5]  R338      5.5893272161483765e-02
    phi[0,5]  R339      1.8404124975204468e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R340      -3.0999999046325684e+00
    phi[5,0]  R341      -3.0999999046325684e+00
    phi[5,0]  R342      -2.2400000095367432e+00
    phi[5,0]  R343      -2.2400000095367432e+00
    phi[5,0]  R344      -3.0999999046325684e+00
    phi[5,0]  R345      -3.0999999046325684e+00
    phi[5,0]  R346      -2.5699999332427979e+00
    phi[5,0]  R347      -2.5699999332427979e+00
    phi[5,0]  R348      -3.0999999046325684e+00
    phi[5,0]  R349      -3.0999999046325684e+00
    phi[5,0]  R350      -2.0899999141693115e+00
    phi[5,0]  R351      -2.0899999141693115e+00
    phi[5,0]  R352      -3.0999999046325684e+00
    phi[5,0]  R353      -3.0999999046325684e+00
    phi[5,0]  R354      3.2479326725006104e+00
    phi[5,0]  R355      1.6247555017471313e+00
    phi[5,0]  R356      3.3914930820465088e+00
    phi[5,0]  R357      3.0739970207214355e+00
    phi[5,0]  R358      3.7849428653717041e+00
    phi[5,0]  R359      2.4234609603881836e+00
    phi[5,0]  R360      -1.7760206013917923e-02
    phi[5,0]  R361      -1.0389789342880249e+00
    phi[5,0]  R362      -2.7524518966674805e+00
    phi[5,0]  R363      -2.1403837203979492e+00
    phi[5,0]  R364      2.1624360978603363e-01
    phi[5,0]  R365      -1.3960171937942505e+00
    phi[5,0]  R366      -1.8711503744125366e+00
    phi[5,0]  R367      -1.1130977869033813e+00
    phi[5,0]  R368      -2.0367376804351807e+00
    phi[5,0]  R369      -2.2653191089630127e+00
    phi[5,0]  R370      -1.81752610206604
    phi[5,0]  R371      -1.9954869747161865e+00
    phi[5,0]  R372      -2.0656652450561523e+00
    phi[5,0]  R373      -2.3404552936553955e+00
    phi[5,0]  R374      -1.8564933538436890e+00
    phi[5,0]  R375      -1.3937898874282837e+00
    phi[5,0]  R376      -3.3122777938842773e+00
    phi[5,0]  R377      -2.8184773921966553e+00
    phi[5,0]  R378      -1.7431690692901611e+00
    phi[5,0]  R379      -8.6689352989196777e-01
    phi[5,0]  R380      -2.0262813568115234e+00
    phi[5,0]  R381      -2.0563969612121582e+00
    phi[5,0]  R382      2.5259044766426086e-01
    phi[5,0]  R383      -0.625604510307312
    phi[5,0]  R384      -4.2457967996597290e-01
    phi[5,0]  R385      -2.1121010780334473e+00
    phi[5,0]  R386      -4.6376881599426270e+00
    phi[5,0]  R387      -3.1730980873107910e+00
    phi[5,0]  R388      -1.5191409587860107e+00
    phi[5,0]  R389      -3.0325779914855957e+00
    phi[5,0]  R390      -1.0819907486438751e-01
    phi[5,0]  R391      -6.5798111259937286e-02
    phi[5,0]  R392      5.5893272161483765e-02
    phi[5,0]  R393      1.8404124975204468e+00
    phi[5,0]  R394      2.6157422065734863e+00
    phi[5,0]  R395      3.4984321594238281e+00
    phi[5,0]  R396      3.0857973098754883e+00
    phi[5,0]  R397      2.1429793834686279e+00
    phi[5,0]  R398      1.7277643680572510e+00
    phi[5,0]  R399      1.4769130945205688e+00
    phi[5,0]  R400      2.1519777774810791e+00
    phi[5,0]  R401      2.8141708374023438e+00
    phi[5,0]  R402      1.7630393505096436e+00
    phi[5,0]  R403      1.2200624942779541e+00
    phi[5,0]  R404      6.5499210357666016e-01
    phi[5,0]  R405      -1.8682315349578857e+00
    phi[5,0]  R406      7.4882604181766510e-02
    phi[5,0]  R407      -1.4402084350585938e+00
    phi[5,0]  R408      -2.9155077934265137e+00
    phi[5,0]  R409      -2.0621032714843750e+00
    phi[5,0]  R410      -1.8036371469497681e+00
    phi[5,0]  R411      -2.0142946243286133e+00
    phi[5,0]  R412      -1.8758676052093506e+00
    phi[5,0]  R413      6.3090139627456665e-01
    phi[5,0]  R414      2.8656992316246033e-01
    phi[5,0]  R415      -7.1085792779922485e-01
    phi[5,0]  R416      -3.5326974391937256e+00
    phi[5,0]  R417      -3.1176834106445312e+00
    phi[5,0]  R418      -2.4946537017822266e+00
    phi[5,0]  R419      1.1102612018585205e+00
    phi[5,0]  R420      -1.6898038387298584e+00
    phi[5,0]  R421      -1.5859068632125854e+00
    phi[5,0]  R422      -4.3703576922416687e-01
    phi[5,0]  R423      -1.0693446397781372e+00
    phi[8,0]  R0        -1
    phi[8,0]  R2        -1.7289651198297549e+00
    phi[8,0]  R3        -1.8093803027456130e+00
    phi[8,0]  R4        -1.9256126674763803e+00
    phi[8,0]  R5        -8.3901003280382347e-01
    phi[8,0]  R6        -1.5294524773794249e-01
    phi[8,0]  R7        -3.9487401100852626e-01
    phi[8,0]  R8        3.0340050726388754e+00
    phi[8,0]  R72       1
    phi[8,0]  R424      -1.3710347848028135e+00
    phi[8,0]  R425      -4.8289650244623230e+00
    phi[8,0]  R426      -4.3061970679113015e-01
    phi[8,0]  R427      -4.0493803122823557e+00
    phi[8,0]  R428      -1.1743872371561881e+00
    phi[8,0]  R429      -5.0256125721089484e+00
    phi[8,0]  R430      -1.7309899004389744e+00
    phi[8,0]  R431      -3.4090099660466215e+00
    phi[8,0]  R432      -2.9470546568946259e+00
    phi[8,0]  R433      -3.2529451523705109e+00
    phi[8,0]  R434      -1.6951259031607853e+00
    phi[8,0]  R435      -2.4848739251778378e+00
    phi[8,0]  R436      -6.1340049772714433e+00
    phi[8,0]  R437      -6.5994831993692937e-02
    phi[8,0]  R438      -1.9464772429392463e-01
    phi[8,0]  R439      -2.0699071773940858e-01
    phi[8,0]  R440      -2.0733571295548714e-01
    phi[8,0]  R441      -2.2403530579829889e-01
    phi[8,0]  R442      -2.8257696373347496e-01
    phi[8,0]  R443      -2.8722896578871837e-01
    phi[8,0]  R444      -2.9898103666286246e-01
    phi[8,0]  R445      -3.0273910787339009e-01
    phi[8,0]  R446      -3.1077446245927165e-01
    phi[8,0]  R447      -3.1221373837768640e-01
    phi[8,0]  R448      -1.7125207661193409e-01
    phi[8,0]  R449      -1.8837698593754393e-01
    phi[8,0]  R450      -2.0364108030775147e-01
    phi[8,0]  R451      -2.1248736103855670e-01
    phi[8,0]  R452      -2.1364039200566731e-01
    phi[8,0]  R453      -2.1387448038508627e-01
    phi[8,0]  R454      -2.2747597865295210e-01
    phi[8,0]  R455      -2.3297346829770071e-01
    phi[8,0]  R456      -2.4857483005674430e-01
    phi[8,0]  R457      -2.5325812209119314e-01
    phi[8,0]  R458      -1.8226985618564273e-01
    phi[8,0]  R459      -2.0322424044618792e-01
    phi[8,0]  R460      -2.1473719583016715e-01
    phi[8,0]  R461      -2.2073945054892619e-01
    phi[8,0]  R462      -2.4096003203551142e-01
    phi[8,0]  R463      -2.4377042703291929e-01
    phi[8,0]  R464      -2.5816759157502456e-01
    phi[8,0]  R465      -2.6492838451564982e-01
    phi[8,0]  R466      -2.8455791178434175e-01
    phi[8,0]  R467      -3.4214485177384013e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R468      -3.0999999046325684e+00
    phi[1,2]  R469      -3.0999999046325684e+00
    phi[1,2]  R470      -2.2400000095367432e+00
    phi[1,2]  R471      -2.2400000095367432e+00
    phi[1,2]  R472      -3.0999999046325684e+00
    phi[1,2]  R473      -3.0999999046325684e+00
    phi[1,2]  R474      -2.5699999332427979e+00
    phi[1,2]  R475      -2.5699999332427979e+00
    phi[1,2]  R476      -3.0999999046325684e+00
    phi[1,2]  R477      -3.0999999046325684e+00
    phi[1,2]  R478      -2.0899999141693115e+00
    phi[1,2]  R479      -2.0899999141693115e+00
    phi[1,2]  R480      -3.0999999046325684e+00
    phi[1,2]  R481      -3.0999999046325684e+00
    phi[1,2]  R482      2.6126177310943604e+00
    phi[1,2]  R483      1.5704927444458008e+00
    phi[1,2]  R484      7.5794732570648193e-01
    phi[1,2]  R485      3.1836397647857666e+00
    phi[1,2]  R486      1.6320019960403442e+00
    phi[1,2]  R487      2.4731736183166504e+00
    phi[1,2]  R488      1.4730331897735596e+00
    phi[1,2]  R489      2.4531056880950928e+00
    phi[1,2]  R490      2.7766110897064209e+00
    phi[1,2]  R491      -1.8515540361404419e+00
    phi[1,2]  R492      -2.9533631801605225e+00
    phi[1,2]  R493      -3.0183370113372803e+00
    phi[1,2]  R494      -3.9356119632720947e+00
    phi[1,2]  R495      -4.6908438205718994e-01
    phi[1,2]  R496      -3.1374628543853760e+00
    phi[1,2]  R497      -3.1096434593200684e+00
    phi[1,2]  R498      -2.4364817142486572e+00
    phi[1,2]  R499      -8.1958872079849243e-01
    phi[1,2]  R500      -2.6413817405700684e+00
    phi[1,2]  R501      -1.6340504884719849e+00
    phi[1,2]  R502      -9.0022522211074829e-01
    phi[1,2]  R503      -7.7695703506469727e-01
    phi[1,2]  R504      -1.1260414123535156e+00
    phi[1,2]  R505      -2.0485693216323853e-01
    phi[1,2]  R506      1.4550510644912720e+00
    phi[1,2]  R507      -1.0401009321212769e+00
    phi[1,2]  R508      1.3192950189113617e-01
    phi[1,2]  R509      -1.1619919538497925e+00
    phi[1,2]  R510      -5.1517164707183838e-01
    phi[1,2]  R511      -2.8970115184783936e+00
    phi[1,2]  R512      -1.2580102682113647e+00
    phi[1,2]  R513      -0.576869010925293
    phi[1,2]  R514      -1.0263688564300537e+00
    phi[1,2]  R515      -0.0836499035358429
    phi[1,2]  R516      -2.5835003852844238e+00
    phi[1,2]  R517      4.1880589723587036e-01
    phi[1,2]  R518      -1.7979124188423157e-01
    phi[1,2]  R519      0.462185800075531
    phi[1,2]  R520      5.6358379125595093e-01
    phi[1,2]  R521      -2.9672653675079346e+00
    phi[1,2]  R522      -2.7175994589924812e-02
    phi[1,2]  R523      -2.8232073783874512e+00
    phi[1,2]  R524      -2.2640435695648193e+00
    phi[1,2]  R525      -1.3041093349456787e+00
    phi[1,2]  R526      -4.5928782224655151e-01
    phi[1,2]  R527      -9.5551824569702148e-01
    phi[1,2]  R528      -6.3410186767578125e-01
    phi[1,2]  R529      -5.2856284379959106e-01
    phi[1,2]  R530      4.1689109802246094e-01
    phi[1,2]  R531      3.3879888057708740e+00
    phi[1,2]  R532      2.0232355594635010e+00
    phi[1,2]  R533      1.9480997323989868e+00
    phi[1,2]  R534      2.5601906776428223e+00
    phi[1,2]  R535      1.12332284450531
    phi[1,2]  R536      3.4492025375366211e+00
    phi[1,2]  R537      1.0026541948318481e+00
    phi[1,2]  R538      5.9128038585186005e-02
    phi[1,2]  R539      -2.5096411705017090e+00
    phi[1,2]  R540      -1.8392314910888672e+00
    phi[1,2]  R541      -1.5134216547012329e+00
    phi[1,2]  R542      -0.550279438495636
    phi[1,2]  R543      -3.4930701255798340e+00
    phi[1,2]  R544      -5.7144898176193237e-01
    phi[1,2]  R545      -1.6383970975875854e+00
    phi[1,2]  R546      -2.38240385055542
    phi[1,2]  R547      -2.8534548282623291e+00
    phi[1,2]  R548      1.4129395484924316e+00
    phi[1,2]  R549      -2.0874135494232178e+00
    phi[1,2]  R550      -7.3791497945785522e-01
    phi[1,2]  R551      -3.3249359130859375e+00
    phi[1,2]  R552      1.6763608157634735e-01
    phi[1,2]  R553      -1.1447379589080811e+00
    phi[1,2]  R554      6.7553412914276123e-01
    phi[1,2]  R555      -8.3803486824035645e-01
    phi[1,2]  R556      -5.8878606557846069e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R557      -3.0999999046325684e+00
    phi[2,1]  R558      -3.0999999046325684e+00
    phi[2,1]  R559      -2.2400000095367432e+00
    phi[2,1]  R560      -2.2400000095367432e+00
    phi[2,1]  R561      -3.0999999046325684e+00
    phi[2,1]  R562      -3.0999999046325684e+00
    phi[2,1]  R563      -2.5699999332427979e+00
    phi[2,1]  R564      -2.5699999332427979e+00
    phi[2,1]  R565      -3.0999999046325684e+00
    phi[2,1]  R566      -3.0999999046325684e+00
    phi[2,1]  R567      -2.0899999141693115e+00
    phi[2,1]  R568      -2.0899999141693115e+00
    phi[2,1]  R569      -3.0999999046325684e+00
    phi[2,1]  R570      -3.0999999046325684e+00
    phi[2,1]  R571      -5.2856284379959106e-01
    phi[2,1]  R572      4.1689109802246094e-01
    phi[2,1]  R573      3.3879888057708740e+00
    phi[2,1]  R574      2.0232355594635010e+00
    phi[2,1]  R575      1.9480997323989868e+00
    phi[2,1]  R576      2.5601906776428223e+00
    phi[2,1]  R577      1.12332284450531
    phi[2,1]  R578      3.4492025375366211e+00
    phi[2,1]  R579      1.0026541948318481e+00
    phi[2,1]  R580      5.9128038585186005e-02
    phi[2,1]  R581      -2.5096411705017090e+00
    phi[2,1]  R582      -1.8392314910888672e+00
    phi[2,1]  R583      -1.5134216547012329e+00
    phi[2,1]  R584      -0.550279438495636
    phi[2,1]  R585      -3.4930701255798340e+00
    phi[2,1]  R586      -5.7144898176193237e-01
    phi[2,1]  R587      -1.6383970975875854e+00
    phi[2,1]  R588      -2.38240385055542
    phi[2,1]  R589      -2.8534548282623291e+00
    phi[2,1]  R590      1.4129395484924316e+00
    phi[2,1]  R591      -2.0874135494232178e+00
    phi[2,1]  R592      -7.3791497945785522e-01
    phi[2,1]  R593      -3.3249359130859375e+00
    phi[2,1]  R594      1.6763608157634735e-01
    phi[2,1]  R595      -1.1447379589080811e+00
    phi[2,1]  R596      6.7553412914276123e-01
    phi[2,1]  R597      -8.3803486824035645e-01
    phi[2,1]  R598      -5.8878606557846069e-01
    phi[2,1]  R599      2.6126177310943604e+00
    phi[2,1]  R600      1.5704927444458008e+00
    phi[2,1]  R601      7.5794732570648193e-01
    phi[2,1]  R602      3.1836397647857666e+00
    phi[2,1]  R603      1.6320019960403442e+00
    phi[2,1]  R604      2.4731736183166504e+00
    phi[2,1]  R605      1.4730331897735596e+00
    phi[2,1]  R606      2.4531056880950928e+00
    phi[2,1]  R607      2.7766110897064209e+00
    phi[2,1]  R608      -1.8515540361404419e+00
    phi[2,1]  R609      -2.9533631801605225e+00
    phi[2,1]  R610      -3.0183370113372803e+00
    phi[2,1]  R611      -3.9356119632720947e+00
    phi[2,1]  R612      -4.6908438205718994e-01
    phi[2,1]  R613      -3.1374628543853760e+00
    phi[2,1]  R614      -3.1096434593200684e+00
    phi[2,1]  R615      -2.4364817142486572e+00
    phi[2,1]  R616      -8.1958872079849243e-01
    phi[2,1]  R617      -2.6413817405700684e+00
    phi[2,1]  R618      -1.6340504884719849e+00
    phi[2,1]  R619      -9.0022522211074829e-01
    phi[2,1]  R620      -7.7695703506469727e-01
    phi[2,1]  R621      -1.1260414123535156e+00
    phi[2,1]  R622      -2.0485693216323853e-01
    phi[2,1]  R623      1.4550510644912720e+00
    phi[2,1]  R624      -1.0401009321212769e+00
    phi[2,1]  R625      1.3192950189113617e-01
    phi[2,1]  R626      -1.1619919538497925e+00
    phi[2,1]  R627      -5.1517164707183838e-01
    phi[2,1]  R628      -2.8970115184783936e+00
    phi[2,1]  R629      -1.2580102682113647e+00
    phi[2,1]  R630      -0.576869010925293
    phi[2,1]  R631      -1.0263688564300537e+00
    phi[2,1]  R632      -0.0836499035358429
    phi[2,1]  R633      -2.5835003852844238e+00
    phi[2,1]  R634      4.1880589723587036e-01
    phi[2,1]  R635      -1.7979124188423157e-01
    phi[2,1]  R636      0.462185800075531
    phi[2,1]  R637      5.6358379125595093e-01
    phi[2,1]  R638      -2.9672653675079346e+00
    phi[2,1]  R639      -2.7175994589924812e-02
    phi[2,1]  R640      -2.8232073783874512e+00
    phi[2,1]  R641      -2.2640435695648193e+00
    phi[2,1]  R642      -1.3041093349456787e+00
    phi[2,1]  R643      -4.5928782224655151e-01
    phi[2,1]  R644      -9.5551824569702148e-01
    phi[2,1]  R645      -6.3410186767578125e-01
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R646      -3.0999999046325684e+00
    phi[1,5]  R647      -3.0999999046325684e+00
    phi[1,5]  R648      -2.2400000095367432e+00
    phi[1,5]  R649      -2.2400000095367432e+00
    phi[1,5]  R650      -3.0999999046325684e+00
    phi[1,5]  R651      -3.0999999046325684e+00
    phi[1,5]  R652      -2.5699999332427979e+00
    phi[1,5]  R653      -2.5699999332427979e+00
    phi[1,5]  R654      -3.0999999046325684e+00
    phi[1,5]  R655      -3.0999999046325684e+00
    phi[1,5]  R656      -2.0899999141693115e+00
    phi[1,5]  R657      -2.0899999141693115e+00
    phi[1,5]  R658      -3.0999999046325684e+00
    phi[1,5]  R659      -3.0999999046325684e+00
    phi[1,5]  R660      2.6126177310943604e+00
    phi[1,5]  R661      1.5704927444458008e+00
    phi[1,5]  R662      7.5794732570648193e-01
    phi[1,5]  R663      3.1836397647857666e+00
    phi[1,5]  R664      1.6320019960403442e+00
    phi[1,5]  R665      2.4731736183166504e+00
    phi[1,5]  R666      1.4730331897735596e+00
    phi[1,5]  R667      2.4531056880950928e+00
    phi[1,5]  R668      2.7766110897064209e+00
    phi[1,5]  R669      -1.8515540361404419e+00
    phi[1,5]  R670      -2.9533631801605225e+00
    phi[1,5]  R671      -3.0183370113372803e+00
    phi[1,5]  R672      -3.9356119632720947e+00
    phi[1,5]  R673      -4.6908438205718994e-01
    phi[1,5]  R674      -3.1374628543853760e+00
    phi[1,5]  R675      -3.1096434593200684e+00
    phi[1,5]  R676      -2.4364817142486572e+00
    phi[1,5]  R677      -8.1958872079849243e-01
    phi[1,5]  R678      -2.6413817405700684e+00
    phi[1,5]  R679      -1.6340504884719849e+00
    phi[1,5]  R680      -9.0022522211074829e-01
    phi[1,5]  R681      -7.7695703506469727e-01
    phi[1,5]  R682      -1.1260414123535156e+00
    phi[1,5]  R683      -2.0485693216323853e-01
    phi[1,5]  R684      1.4550510644912720e+00
    phi[1,5]  R685      -1.0401009321212769e+00
    phi[1,5]  R686      1.3192950189113617e-01
    phi[1,5]  R687      -1.1619919538497925e+00
    phi[1,5]  R688      -5.1517164707183838e-01
    phi[1,5]  R689      -2.8970115184783936e+00
    phi[1,5]  R690      -1.2580102682113647e+00
    phi[1,5]  R691      -0.576869010925293
    phi[1,5]  R692      -1.0263688564300537e+00
    phi[1,5]  R693      -0.0836499035358429
    phi[1,5]  R694      -2.5835003852844238e+00
    phi[1,5]  R695      4.1880589723587036e-01
    phi[1,5]  R696      -1.7979124188423157e-01
    phi[1,5]  R697      0.462185800075531
    phi[1,5]  R698      5.6358379125595093e-01
    phi[1,5]  R699      -2.9672653675079346e+00
    phi[1,5]  R700      -2.7175994589924812e-02
    phi[1,5]  R701      -2.8232073783874512e+00
    phi[1,5]  R702      -2.2640435695648193e+00
    phi[1,5]  R703      -1.3041093349456787e+00
    phi[1,5]  R704      -4.5928782224655151e-01
    phi[1,5]  R705      -9.5551824569702148e-01
    phi[1,5]  R706      -6.3410186767578125e-01
    phi[1,5]  R707      3.2479326725006104e+00
    phi[1,5]  R708      1.6247555017471313e+00
    phi[1,5]  R709      3.3914930820465088e+00
    phi[1,5]  R710      3.0739970207214355e+00
    phi[1,5]  R711      3.7849428653717041e+00
    phi[1,5]  R712      2.4234609603881836e+00
    phi[1,5]  R713      -1.7760206013917923e-02
    phi[1,5]  R714      -1.0389789342880249e+00
    phi[1,5]  R715      -2.7524518966674805e+00
    phi[1,5]  R716      -2.1403837203979492e+00
    phi[1,5]  R717      2.1624360978603363e-01
    phi[1,5]  R718      -1.3960171937942505e+00
    phi[1,5]  R719      -1.8711503744125366e+00
    phi[1,5]  R720      -1.1130977869033813e+00
    phi[1,5]  R721      -2.0367376804351807e+00
    phi[1,5]  R722      -2.2653191089630127e+00
    phi[1,5]  R723      -1.81752610206604
    phi[1,5]  R724      -1.9954869747161865e+00
    phi[1,5]  R725      -2.0656652450561523e+00
    phi[1,5]  R726      -2.3404552936553955e+00
    phi[1,5]  R727      -1.8564933538436890e+00
    phi[1,5]  R728      -1.3937898874282837e+00
    phi[1,5]  R729      -3.3122777938842773e+00
    phi[1,5]  R730      -2.8184773921966553e+00
    phi[1,5]  R731      -1.7431690692901611e+00
    phi[1,5]  R732      -8.6689352989196777e-01
    phi[1,5]  R733      -2.0262813568115234e+00
    phi[1,5]  R734      -2.0563969612121582e+00
    phi[1,5]  R735      2.5259044766426086e-01
    phi[1,5]  R736      -0.625604510307312
    phi[1,5]  R737      -4.2457967996597290e-01
    phi[1,5]  R738      -2.1121010780334473e+00
    phi[1,5]  R739      -4.6376881599426270e+00
    phi[1,5]  R740      -3.1730980873107910e+00
    phi[1,5]  R741      -1.5191409587860107e+00
    phi[1,5]  R742      -3.0325779914855957e+00
    phi[1,5]  R743      -1.0819907486438751e-01
    phi[1,5]  R744      -6.5798111259937286e-02
    phi[1,5]  R745      5.5893272161483765e-02
    phi[1,5]  R746      1.8404124975204468e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R747      -3.0999999046325684e+00
    phi[5,1]  R748      -3.0999999046325684e+00
    phi[5,1]  R749      -2.2400000095367432e+00
    phi[5,1]  R750      -2.2400000095367432e+00
    phi[5,1]  R751      -3.0999999046325684e+00
    phi[5,1]  R752      -3.0999999046325684e+00
    phi[5,1]  R753      -2.5699999332427979e+00
    phi[5,1]  R754      -2.5699999332427979e+00
    phi[5,1]  R755      -3.0999999046325684e+00
    phi[5,1]  R756      -3.0999999046325684e+00
    phi[5,1]  R757      -2.0899999141693115e+00
    phi[5,1]  R758      -2.0899999141693115e+00
    phi[5,1]  R759      -3.0999999046325684e+00
    phi[5,1]  R760      -3.0999999046325684e+00
    phi[5,1]  R761      3.2479326725006104e+00
    phi[5,1]  R762      1.6247555017471313e+00
    phi[5,1]  R763      3.3914930820465088e+00
    phi[5,1]  R764      3.0739970207214355e+00
    phi[5,1]  R765      3.7849428653717041e+00
    phi[5,1]  R766      2.4234609603881836e+00
    phi[5,1]  R767      -1.7760206013917923e-02
    phi[5,1]  R768      -1.0389789342880249e+00
    phi[5,1]  R769      -2.7524518966674805e+00
    phi[5,1]  R770      -2.1403837203979492e+00
    phi[5,1]  R771      2.1624360978603363e-01
    phi[5,1]  R772      -1.3960171937942505e+00
    phi[5,1]  R773      -1.8711503744125366e+00
    phi[5,1]  R774      -1.1130977869033813e+00
    phi[5,1]  R775      -2.0367376804351807e+00
    phi[5,1]  R776      -2.2653191089630127e+00
    phi[5,1]  R777      -1.81752610206604
    phi[5,1]  R778      -1.9954869747161865e+00
    phi[5,1]  R779      -2.0656652450561523e+00
    phi[5,1]  R780      -2.3404552936553955e+00
    phi[5,1]  R781      -1.8564933538436890e+00
    phi[5,1]  R782      -1.3937898874282837e+00
    phi[5,1]  R783      -3.3122777938842773e+00
    phi[5,1]  R784      -2.8184773921966553e+00
    phi[5,1]  R785      -1.7431690692901611e+00
    phi[5,1]  R786      -8.6689352989196777e-01
    phi[5,1]  R787      -2.0262813568115234e+00
    phi[5,1]  R788      -2.0563969612121582e+00
    phi[5,1]  R789      2.5259044766426086e-01
    phi[5,1]  R790      -0.625604510307312
    phi[5,1]  R791      -4.2457967996597290e-01
    phi[5,1]  R792      -2.1121010780334473e+00
    phi[5,1]  R793      -4.6376881599426270e+00
    phi[5,1]  R794      -3.1730980873107910e+00
    phi[5,1]  R795      -1.5191409587860107e+00
    phi[5,1]  R796      -3.0325779914855957e+00
    phi[5,1]  R797      -1.0819907486438751e-01
    phi[5,1]  R798      -6.5798111259937286e-02
    phi[5,1]  R799      5.5893272161483765e-02
    phi[5,1]  R800      1.8404124975204468e+00
    phi[5,1]  R801      2.6126177310943604e+00
    phi[5,1]  R802      1.5704927444458008e+00
    phi[5,1]  R803      7.5794732570648193e-01
    phi[5,1]  R804      3.1836397647857666e+00
    phi[5,1]  R805      1.6320019960403442e+00
    phi[5,1]  R806      2.4731736183166504e+00
    phi[5,1]  R807      1.4730331897735596e+00
    phi[5,1]  R808      2.4531056880950928e+00
    phi[5,1]  R809      2.7766110897064209e+00
    phi[5,1]  R810      -1.8515540361404419e+00
    phi[5,1]  R811      -2.9533631801605225e+00
    phi[5,1]  R812      -3.0183370113372803e+00
    phi[5,1]  R813      -3.9356119632720947e+00
    phi[5,1]  R814      -4.6908438205718994e-01
    phi[5,1]  R815      -3.1374628543853760e+00
    phi[5,1]  R816      -3.1096434593200684e+00
    phi[5,1]  R817      -2.4364817142486572e+00
    phi[5,1]  R818      -8.1958872079849243e-01
    phi[5,1]  R819      -2.6413817405700684e+00
    phi[5,1]  R820      -1.6340504884719849e+00
    phi[5,1]  R821      -9.0022522211074829e-01
    phi[5,1]  R822      -7.7695703506469727e-01
    phi[5,1]  R823      -1.1260414123535156e+00
    phi[5,1]  R824      -2.0485693216323853e-01
    phi[5,1]  R825      1.4550510644912720e+00
    phi[5,1]  R826      -1.0401009321212769e+00
    phi[5,1]  R827      1.3192950189113617e-01
    phi[5,1]  R828      -1.1619919538497925e+00
    phi[5,1]  R829      -5.1517164707183838e-01
    phi[5,1]  R830      -2.8970115184783936e+00
    phi[5,1]  R831      -1.2580102682113647e+00
    phi[5,1]  R832      -0.576869010925293
    phi[5,1]  R833      -1.0263688564300537e+00
    phi[5,1]  R834      -0.0836499035358429
    phi[5,1]  R835      -2.5835003852844238e+00
    phi[5,1]  R836      4.1880589723587036e-01
    phi[5,1]  R837      -1.7979124188423157e-01
    phi[5,1]  R838      0.462185800075531
    phi[5,1]  R839      5.6358379125595093e-01
    phi[5,1]  R840      -2.9672653675079346e+00
    phi[5,1]  R841      -2.7175994589924812e-02
    phi[5,1]  R842      -2.8232073783874512e+00
    phi[5,1]  R843      -2.2640435695648193e+00
    phi[5,1]  R844      -1.3041093349456787e+00
    phi[5,1]  R845      -4.5928782224655151e-01
    phi[5,1]  R846      -9.5551824569702148e-01
    phi[5,1]  R847      -6.3410186767578125e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R848      -3.0999999046325684e+00
    phi[2,3]  R849      -3.0999999046325684e+00
    phi[2,3]  R850      -2.2400000095367432e+00
    phi[2,3]  R851      -2.2400000095367432e+00
    phi[2,3]  R852      -3.0999999046325684e+00
    phi[2,3]  R853      -3.0999999046325684e+00
    phi[2,3]  R854      -2.5699999332427979e+00
    phi[2,3]  R855      -2.5699999332427979e+00
    phi[2,3]  R856      -3.0999999046325684e+00
    phi[2,3]  R857      -3.0999999046325684e+00
    phi[2,3]  R858      -2.0899999141693115e+00
    phi[2,3]  R859      -2.0899999141693115e+00
    phi[2,3]  R860      -3.0999999046325684e+00
    phi[2,3]  R861      -3.0999999046325684e+00
    phi[2,3]  R862      -5.2856284379959106e-01
    phi[2,3]  R863      4.1689109802246094e-01
    phi[2,3]  R864      3.3879888057708740e+00
    phi[2,3]  R865      2.0232355594635010e+00
    phi[2,3]  R866      1.9480997323989868e+00
    phi[2,3]  R867      2.5601906776428223e+00
    phi[2,3]  R868      1.12332284450531
    phi[2,3]  R869      3.4492025375366211e+00
    phi[2,3]  R870      1.0026541948318481e+00
    phi[2,3]  R871      5.9128038585186005e-02
    phi[2,3]  R872      -2.5096411705017090e+00
    phi[2,3]  R873      -1.8392314910888672e+00
    phi[2,3]  R874      -1.5134216547012329e+00
    phi[2,3]  R875      -0.550279438495636
    phi[2,3]  R876      -3.4930701255798340e+00
    phi[2,3]  R877      -5.7144898176193237e-01
    phi[2,3]  R878      -1.6383970975875854e+00
    phi[2,3]  R879      -2.38240385055542
    phi[2,3]  R880      -2.8534548282623291e+00
    phi[2,3]  R881      1.4129395484924316e+00
    phi[2,3]  R882      -2.0874135494232178e+00
    phi[2,3]  R883      -7.3791497945785522e-01
    phi[2,3]  R884      -3.3249359130859375e+00
    phi[2,3]  R885      1.6763608157634735e-01
    phi[2,3]  R886      -1.1447379589080811e+00
    phi[2,3]  R887      6.7553412914276123e-01
    phi[2,3]  R888      -8.3803486824035645e-01
    phi[2,3]  R889      -5.8878606557846069e-01
    phi[2,3]  R890      5.0745338201522827e-01
    phi[2,3]  R891      8.9110630750656128e-01
    phi[2,3]  R892      1.4240763187408447e+00
    phi[2,3]  R893      9.4183725118637085e-01
    phi[2,3]  R894      1.0605401992797852e+00
    phi[2,3]  R895      1.7971543073654175e+00
    phi[2,3]  R896      2.2241299152374268e+00
    phi[2,3]  R897      1.2460120916366577e+00
    phi[2,3]  R898      1.2202658653259277e+00
    phi[2,3]  R899      -4.9424678087234497e-01
    phi[2,3]  R900      -3.4570839405059814e+00
    phi[2,3]  R901      -1.4220961332321167e+00
    phi[2,3]  R902      -2.9759931564331055e+00
    phi[2,3]  R903      -2.6479539871215820e+00
    phi[2,3]  R904      -1.29734468460083
    phi[2,3]  R905      -2.0743198394775391e+00
    phi[2,3]  R906      -1.6001542806625366e+00
    phi[2,3]  R907      -1.3967503309249878e+00
    phi[2,3]  R908      -1.1128625869750977e+00
    phi[2,3]  R909      -1.0474383831024170e-01
    phi[2,3]  R910      -1.8971928954124451e-01
    phi[2,3]  R911      -0.0905231386423111
    phi[2,3]  R912      1.0984394550323486e+00
    phi[2,3]  R913      4.6089610457420349e-01
    phi[2,3]  R914      -3.3479893207550049e-01
    phi[2,3]  R915      -1.5185858011245728e+00
    phi[2,3]  R916      -2.7172853946685791e+00
    phi[2,3]  R917      -1.1727275848388672e+00
    phi[2,3]  R918      4.2846730351448059e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R919      -3.0999999046325684e+00
    phi[3,2]  R920      -3.0999999046325684e+00
    phi[3,2]  R921      -2.2400000095367432e+00
    phi[3,2]  R922      -2.2400000095367432e+00
    phi[3,2]  R923      -3.0999999046325684e+00
    phi[3,2]  R924      -3.0999999046325684e+00
    phi[3,2]  R925      -2.5699999332427979e+00
    phi[3,2]  R926      -2.5699999332427979e+00
    phi[3,2]  R927      -3.0999999046325684e+00
    phi[3,2]  R928      -3.0999999046325684e+00
    phi[3,2]  R929      -2.0899999141693115e+00
    phi[3,2]  R930      -2.0899999141693115e+00
    phi[3,2]  R931      -3.0999999046325684e+00
    phi[3,2]  R932      -3.0999999046325684e+00
    phi[3,2]  R933      5.0745338201522827e-01
    phi[3,2]  R934      8.9110630750656128e-01
    phi[3,2]  R935      1.4240763187408447e+00
    phi[3,2]  R936      9.4183725118637085e-01
    phi[3,2]  R937      1.0605401992797852e+00
    phi[3,2]  R938      1.7971543073654175e+00
    phi[3,2]  R939      2.2241299152374268e+00
    phi[3,2]  R940      1.2460120916366577e+00
    phi[3,2]  R941      1.2202658653259277e+00
    phi[3,2]  R942      -4.9424678087234497e-01
    phi[3,2]  R943      -3.4570839405059814e+00
    phi[3,2]  R944      -1.4220961332321167e+00
    phi[3,2]  R945      -2.9759931564331055e+00
    phi[3,2]  R946      -2.6479539871215820e+00
    phi[3,2]  R947      -1.29734468460083
    phi[3,2]  R948      -2.0743198394775391e+00
    phi[3,2]  R949      -1.6001542806625366e+00
    phi[3,2]  R950      -1.3967503309249878e+00
    phi[3,2]  R951      -1.1128625869750977e+00
    phi[3,2]  R952      -1.0474383831024170e-01
    phi[3,2]  R953      -1.8971928954124451e-01
    phi[3,2]  R954      -0.0905231386423111
    phi[3,2]  R955      1.0984394550323486e+00
    phi[3,2]  R956      4.6089610457420349e-01
    phi[3,2]  R957      -3.3479893207550049e-01
    phi[3,2]  R958      -1.5185858011245728e+00
    phi[3,2]  R959      -2.7172853946685791e+00
    phi[3,2]  R960      -1.1727275848388672e+00
    phi[3,2]  R961      4.2846730351448059e-01
    phi[3,2]  R962      -5.2856284379959106e-01
    phi[3,2]  R963      4.1689109802246094e-01
    phi[3,2]  R964      3.3879888057708740e+00
    phi[3,2]  R965      2.0232355594635010e+00
    phi[3,2]  R966      1.9480997323989868e+00
    phi[3,2]  R967      2.5601906776428223e+00
    phi[3,2]  R968      1.12332284450531
    phi[3,2]  R969      3.4492025375366211e+00
    phi[3,2]  R970      1.0026541948318481e+00
    phi[3,2]  R971      5.9128038585186005e-02
    phi[3,2]  R972      -2.5096411705017090e+00
    phi[3,2]  R973      -1.8392314910888672e+00
    phi[3,2]  R974      -1.5134216547012329e+00
    phi[3,2]  R975      -0.550279438495636
    phi[3,2]  R976      -3.4930701255798340e+00
    phi[3,2]  R977      -5.7144898176193237e-01
    phi[3,2]  R978      -1.6383970975875854e+00
    phi[3,2]  R979      -2.38240385055542
    phi[3,2]  R980      -2.8534548282623291e+00
    phi[3,2]  R981      1.4129395484924316e+00
    phi[3,2]  R982      -2.0874135494232178e+00
    phi[3,2]  R983      -7.3791497945785522e-01
    phi[3,2]  R984      -3.3249359130859375e+00
    phi[3,2]  R985      1.6763608157634735e-01
    phi[3,2]  R986      -1.1447379589080811e+00
    phi[3,2]  R987      6.7553412914276123e-01
    phi[3,2]  R988      -8.3803486824035645e-01
    phi[3,2]  R989      -5.8878606557846069e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R990      -3.0999999046325684e+00
    phi[3,4]  R991      -3.0999999046325684e+00
    phi[3,4]  R992      -2.2400000095367432e+00
    phi[3,4]  R993      -2.2400000095367432e+00
    phi[3,4]  R994      -3.0999999046325684e+00
    phi[3,4]  R995      -3.0999999046325684e+00
    phi[3,4]  R996      -2.5699999332427979e+00
    phi[3,4]  R997      -2.5699999332427979e+00
    phi[3,4]  R998      -3.0999999046325684e+00
    phi[3,4]  R999      -3.0999999046325684e+00
    phi[3,4]  R1000     -2.0899999141693115e+00
    phi[3,4]  R1001     -2.0899999141693115e+00
    phi[3,4]  R1002     -3.0999999046325684e+00
    phi[3,4]  R1003     -3.0999999046325684e+00
    phi[3,4]  R1004     5.0745338201522827e-01
    phi[3,4]  R1005     8.9110630750656128e-01
    phi[3,4]  R1006     1.4240763187408447e+00
    phi[3,4]  R1007     9.4183725118637085e-01
    phi[3,4]  R1008     1.0605401992797852e+00
    phi[3,4]  R1009     1.7971543073654175e+00
    phi[3,4]  R1010     2.2241299152374268e+00
    phi[3,4]  R1011     1.2460120916366577e+00
    phi[3,4]  R1012     1.2202658653259277e+00
    phi[3,4]  R1013     -4.9424678087234497e-01
    phi[3,4]  R1014     -3.4570839405059814e+00
    phi[3,4]  R1015     -1.4220961332321167e+00
    phi[3,4]  R1016     -2.9759931564331055e+00
    phi[3,4]  R1017     -2.6479539871215820e+00
    phi[3,4]  R1018     -1.29734468460083
    phi[3,4]  R1019     -2.0743198394775391e+00
    phi[3,4]  R1020     -1.6001542806625366e+00
    phi[3,4]  R1021     -1.3967503309249878e+00
    phi[3,4]  R1022     -1.1128625869750977e+00
    phi[3,4]  R1023     -1.0474383831024170e-01
    phi[3,4]  R1024     -1.8971928954124451e-01
    phi[3,4]  R1025     -0.0905231386423111
    phi[3,4]  R1026     1.0984394550323486e+00
    phi[3,4]  R1027     4.6089610457420349e-01
    phi[3,4]  R1028     -3.3479893207550049e-01
    phi[3,4]  R1029     -1.5185858011245728e+00
    phi[3,4]  R1030     -2.7172853946685791e+00
    phi[3,4]  R1031     -1.1727275848388672e+00
    phi[3,4]  R1032     4.2846730351448059e-01
    phi[3,4]  R1033     4.8187974095344543e-01
    phi[3,4]  R1034     2.0093200206756592e+00
    phi[3,4]  R1035     1.7898755073547363e+00
    phi[3,4]  R1036     2.6218130588531494e+00
    phi[3,4]  R1037     2.0890166759490967e+00
    phi[3,4]  R1038     1.5692213773727417e+00
    phi[3,4]  R1039     -5.4353260993957520e-01
    phi[3,4]  R1040     9.6373111009597778e-01
    phi[3,4]  R1041     1.4591118097305298e+00
    phi[3,4]  R1042     3.4484589099884033e-01
    phi[3,4]  R1043     -1.4573565721511841e+00
    phi[3,4]  R1044     -2.9137597084045410e+00
    phi[3,4]  R1045     -6.1391180753707886e-01
    phi[3,4]  R1046     -3.2690780162811279e+00
    phi[3,4]  R1047     -3.0009763240814209e+00
    phi[3,4]  R1048     -5.3161704540252686e-01
    phi[3,4]  R1049     -2.0279216766357422e+00
    phi[3,4]  R1050     -1.4070169925689697e+00
    phi[3,4]  R1051     -1.2895026206970215e+00
    phi[3,4]  R1052     -2.0862873643636703e-03
    phi[3,4]  R1053     -2.6962976455688477e+00
    phi[3,4]  R1054     -1.3191516399383545e+00
    phi[3,4]  R1055     -0.628633975982666
    phi[3,4]  R1056     1.1832149028778076e+00
    phi[3,4]  R1057     2.6629621982574463e+00
    phi[3,4]  R1058     1.1491990089416504e-01
    phi[3,4]  R1059     1.0011961460113525e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1060     -3.0999999046325684e+00
    phi[4,3]  R1061     -3.0999999046325684e+00
    phi[4,3]  R1062     -2.2400000095367432e+00
    phi[4,3]  R1063     -2.2400000095367432e+00
    phi[4,3]  R1064     -3.0999999046325684e+00
    phi[4,3]  R1065     -3.0999999046325684e+00
    phi[4,3]  R1066     -2.5699999332427979e+00
    phi[4,3]  R1067     -2.5699999332427979e+00
    phi[4,3]  R1068     -3.0999999046325684e+00
    phi[4,3]  R1069     -3.0999999046325684e+00
    phi[4,3]  R1070     -2.0899999141693115e+00
    phi[4,3]  R1071     -2.0899999141693115e+00
    phi[4,3]  R1072     -3.0999999046325684e+00
    phi[4,3]  R1073     -3.0999999046325684e+00
    phi[4,3]  R1074     4.8187974095344543e-01
    phi[4,3]  R1075     2.0093200206756592e+00
    phi[4,3]  R1076     1.7898755073547363e+00
    phi[4,3]  R1077     2.6218130588531494e+00
    phi[4,3]  R1078     2.0890166759490967e+00
    phi[4,3]  R1079     1.5692213773727417e+00
    phi[4,3]  R1080     -5.4353260993957520e-01
    phi[4,3]  R1081     9.6373111009597778e-01
    phi[4,3]  R1082     1.4591118097305298e+00
    phi[4,3]  R1083     3.4484589099884033e-01
    phi[4,3]  R1084     -1.4573565721511841e+00
    phi[4,3]  R1085     -2.9137597084045410e+00
    phi[4,3]  R1086     -6.1391180753707886e-01
    phi[4,3]  R1087     -3.2690780162811279e+00
    phi[4,3]  R1088     -3.0009763240814209e+00
    phi[4,3]  R1089     -5.3161704540252686e-01
    phi[4,3]  R1090     -2.0279216766357422e+00
    phi[4,3]  R1091     -1.4070169925689697e+00
    phi[4,3]  R1092     -1.2895026206970215e+00
    phi[4,3]  R1093     -2.0862873643636703e-03
    phi[4,3]  R1094     -2.6962976455688477e+00
    phi[4,3]  R1095     -1.3191516399383545e+00
    phi[4,3]  R1096     -0.628633975982666
    phi[4,3]  R1097     1.1832149028778076e+00
    phi[4,3]  R1098     2.6629621982574463e+00
    phi[4,3]  R1099     1.1491990089416504e-01
    phi[4,3]  R1100     1.0011961460113525e+00
    phi[4,3]  R1101     5.0745338201522827e-01
    phi[4,3]  R1102     8.9110630750656128e-01
    phi[4,3]  R1103     1.4240763187408447e+00
    phi[4,3]  R1104     9.4183725118637085e-01
    phi[4,3]  R1105     1.0605401992797852e+00
    phi[4,3]  R1106     1.7971543073654175e+00
    phi[4,3]  R1107     2.2241299152374268e+00
    phi[4,3]  R1108     1.2460120916366577e+00
    phi[4,3]  R1109     1.2202658653259277e+00
    phi[4,3]  R1110     -4.9424678087234497e-01
    phi[4,3]  R1111     -3.4570839405059814e+00
    phi[4,3]  R1112     -1.4220961332321167e+00
    phi[4,3]  R1113     -2.9759931564331055e+00
    phi[4,3]  R1114     -2.6479539871215820e+00
    phi[4,3]  R1115     -1.29734468460083
    phi[4,3]  R1116     -2.0743198394775391e+00
    phi[4,3]  R1117     -1.6001542806625366e+00
    phi[4,3]  R1118     -1.3967503309249878e+00
    phi[4,3]  R1119     -1.1128625869750977e+00
    phi[4,3]  R1120     -1.0474383831024170e-01
    phi[4,3]  R1121     -1.8971928954124451e-01
    phi[4,3]  R1122     -0.0905231386423111
    phi[4,3]  R1123     1.0984394550323486e+00
    phi[4,3]  R1124     4.6089610457420349e-01
    phi[4,3]  R1125     -3.3479893207550049e-01
    phi[4,3]  R1126     -1.5185858011245728e+00
    phi[4,3]  R1127     -2.7172853946685791e+00
    phi[4,3]  R1128     -1.1727275848388672e+00
    phi[4,3]  R1129     4.2846730351448059e-01
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1130     -3.0999999046325684e+00
    phi[3,6]  R1131     -3.0999999046325684e+00
    phi[3,6]  R1132     -2.2400000095367432e+00
    phi[3,6]  R1133     -2.2400000095367432e+00
    phi[3,6]  R1134     -3.0999999046325684e+00
    phi[3,6]  R1135     -3.0999999046325684e+00
    phi[3,6]  R1136     -2.5699999332427979e+00
    phi[3,6]  R1137     -2.5699999332427979e+00
    phi[3,6]  R1138     -3.0999999046325684e+00
    phi[3,6]  R1139     -3.0999999046325684e+00
    phi[3,6]  R1140     -2.0899999141693115e+00
    phi[3,6]  R1141     -2.0899999141693115e+00
    phi[3,6]  R1142     -3.0999999046325684e+00
    phi[3,6]  R1143     -3.0999999046325684e+00
    phi[3,6]  R1144     5.0745338201522827e-01
    phi[3,6]  R1145     8.9110630750656128e-01
    phi[3,6]  R1146     1.4240763187408447e+00
    phi[3,6]  R1147     9.4183725118637085e-01
    phi[3,6]  R1148     1.0605401992797852e+00
    phi[3,6]  R1149     1.7971543073654175e+00
    phi[3,6]  R1150     2.2241299152374268e+00
    phi[3,6]  R1151     1.2460120916366577e+00
    phi[3,6]  R1152     1.2202658653259277e+00
    phi[3,6]  R1153     -4.9424678087234497e-01
    phi[3,6]  R1154     -3.4570839405059814e+00
    phi[3,6]  R1155     -1.4220961332321167e+00
    phi[3,6]  R1156     -2.9759931564331055e+00
    phi[3,6]  R1157     -2.6479539871215820e+00
    phi[3,6]  R1158     -1.29734468460083
    phi[3,6]  R1159     -2.0743198394775391e+00
    phi[3,6]  R1160     -1.6001542806625366e+00
    phi[3,6]  R1161     -1.3967503309249878e+00
    phi[3,6]  R1162     -1.1128625869750977e+00
    phi[3,6]  R1163     -1.0474383831024170e-01
    phi[3,6]  R1164     -1.8971928954124451e-01
    phi[3,6]  R1165     -0.0905231386423111
    phi[3,6]  R1166     1.0984394550323486e+00
    phi[3,6]  R1167     4.6089610457420349e-01
    phi[3,6]  R1168     -3.3479893207550049e-01
    phi[3,6]  R1169     -1.5185858011245728e+00
    phi[3,6]  R1170     -2.7172853946685791e+00
    phi[3,6]  R1171     -1.1727275848388672e+00
    phi[3,6]  R1172     4.2846730351448059e-01
    phi[3,6]  R1173     1.8038105964660645e+00
    phi[3,6]  R1174     2.0212562084198
    phi[3,6]  R1175     2.2199401855468750e+00
    phi[3,6]  R1176     1.8166892528533936e+00
    phi[3,6]  R1177     1.3593620061874390e+00
    phi[3,6]  R1178     2.4568644165992737e-01
    phi[3,6]  R1179     5.2529424428939819e-01
    phi[3,6]  R1180     1.0967795848846436e+00
    phi[3,6]  R1181     1.2748793363571167e+00
    phi[3,6]  R1182     -2.2362039089202881e+00
    phi[3,6]  R1183     -9.8868167400360107e-01
    phi[3,6]  R1184     -7.6130986213684082e-01
    phi[3,6]  R1185     -2.1482448577880859e+00
    phi[3,6]  R1186     -1.1539065837860107e+00
    phi[3,6]  R1187     -1.6417894363403320e+00
    phi[3,6]  R1188     -2.8224108219146729e+00
    phi[3,6]  R1189     -1.8637168407440186e-01
    phi[3,6]  R1190     -2.1704065799713135e-01
    phi[3,6]  R1191     5.3738448768854141e-03
    phi[3,6]  R1192     1.3588632643222809e-01
    phi[3,6]  R1193     -2.0460567474365234e+00
    phi[3,6]  R1194     -8.2387423515319824e-01
    phi[3,6]  R1195     -1.7387566566467285e+00
    phi[3,6]  R1196     -2.5483138561248779e+00
    phi[3,6]  R1197     -1.9092139005661011e+00
    phi[3,6]  R1198     -2.5550856590270996e+00
    phi[3,6]  R1199     -9.8190808296203613e-01
    phi[3,6]  R1200     -1.6184545755386353e+00
    phi[3,6]  R1201     -2.6678955554962158e+00
    phi[3,6]  R1202     -3.1588549613952637e+00
    phi[3,6]  R1203     -1.5635890960693359e+00
    phi[3,6]  R1204     -1.2759013175964355e+00
    phi[3,6]  R1205     -1.0144550800323486e+00
    phi[3,6]  R1206     -1.4135593175888062e+00
    phi[3,6]  R1207     -2.5997298955917358e-01
    phi[3,6]  R1208     -1.5232124924659729e-01
    phi[3,6]  R1209     -1.2059509754180908e+00
    phi[3,6]  R1210     -0.713696300983429
    phi[3,6]  R1211     -1.6927288770675659e+00
    phi[3,6]  R1212     -2.0090565681457520e+00
    phi[3,6]  R1213     -6.8751549720764160e-01
    phi[3,6]  R1214     -1.5216176509857178e+00
    phi[3,6]  R1215     -1.9370281696319580e+00
    phi[3,6]  R1216     -1.2172225713729858e+00
    phi[3,6]  R1217     -1.3048487901687622e-01
    phi[3,6]  R1218     -3.3392570018768311e+00
    phi[3,6]  R1219     -3.4945511817932129e+00
    phi[3,6]  R1220     -4.1890792846679688e+00
    phi[3,6]  R1221     -0.908643364906311
    phi[3,6]  R1222     -7.3544424772262573e-01
    phi[3,6]  R1223     -1.9967169761657715e+00
    phi[3,6]  R1224     -1.0128711909055710e-01
    phi[3,6]  R1225     -2.4434425830841064e+00
    phi[3,6]  R1226     -2.03611159324646
    phi[3,6]  R1227     -2.2333424091339111e+00
    phi[3,6]  R1228     -4.1757197380065918e+00
    phi[3,6]  R1229     -2.0170805454254150e+00
    phi[3,6]  R1230     -0.543626070022583
    phi[3,6]  R1231     5.3729015588760376e-01
    phi[3,6]  R1232     -7.5084561109542847e-01
    phi[3,6]  R1233     -1.9941475391387939e+00
    phi[3,6]  R1234     -2.2276562452316284e-01
    phi[3,6]  R1235     -3.6721739768981934e+00
    phi[3,6]  R1236     -4.1953749656677246e+00
    phi[3,6]  R1237     -3.0330622196197510e+00
    phi[3,6]  R1238     -1.5494794845581055e+00
    phi[3,6]  R1239     -2.7240601181983948e-01
    phi[3,6]  R1240     -1.2311660051345825e+00
    phi[3,6]  R1241     -1.9987718760967255e-01
    phi[3,6]  R1242     -1.0165917873382568e+00
    phi[3,6]  R1243     -1.2333720922470093e-02
    phi[3,6]  R1244     -1.8869051933288574e+00
    phi[3,6]  R1245     -2.6290321350097656e+00
    phi[3,6]  R1246     -6.8977195024490356e-01
    phi[3,6]  R1247     -1.0673456192016602e+00
    phi[3,6]  R1248     -1.1832598447799683e+00
    phi[3,6]  R1249     -6.7660528421401978e-01
    phi[3,6]  R1250     2.8066933155059814e-01
    phi[3,6]  R1251     -8.3757573366165161e-01
    phi[3,6]  R1252     3.1437245011329651e-01
    phi[3,6]  R1253     -1.7640326023101807e+00
    phi[3,6]  R1254     -1.7597335577011108e-01
    phi[3,6]  R1255     -8.1570214033126831e-01
    phi[3,6]  R1256     -1.4162975549697876e+00
    phi[3,6]  R1257     -1.4853594303131104e+00
    phi[3,6]  R1258     -2.5981919765472412e+00
    phi[3,6]  R1259     5.5796223878860474e-01
    phi[3,6]  R1260     -1.5960524082183838e+00
    phi[3,6]  R1261     -3.2067394256591797e-01
    phi[3,6]  R1262     -2.2537949085235596e+00
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1263     -3.0999999046325684e+00
    phi[6,3]  R1264     -3.0999999046325684e+00
    phi[6,3]  R1265     -2.2400000095367432e+00
    phi[6,3]  R1266     -2.2400000095367432e+00
    phi[6,3]  R1267     -3.0999999046325684e+00
    phi[6,3]  R1268     -3.0999999046325684e+00
    phi[6,3]  R1269     -2.5699999332427979e+00
    phi[6,3]  R1270     -2.5699999332427979e+00
    phi[6,3]  R1271     -3.0999999046325684e+00
    phi[6,3]  R1272     -3.0999999046325684e+00
    phi[6,3]  R1273     -2.0899999141693115e+00
    phi[6,3]  R1274     -2.0899999141693115e+00
    phi[6,3]  R1275     -3.0999999046325684e+00
    phi[6,3]  R1276     -3.0999999046325684e+00
    phi[6,3]  R1277     1.8038105964660645e+00
    phi[6,3]  R1278     2.0212562084198
    phi[6,3]  R1279     2.2199401855468750e+00
    phi[6,3]  R1280     1.8166892528533936e+00
    phi[6,3]  R1281     1.3593620061874390e+00
    phi[6,3]  R1282     2.4568644165992737e-01
    phi[6,3]  R1283     5.2529424428939819e-01
    phi[6,3]  R1284     1.0967795848846436e+00
    phi[6,3]  R1285     1.2748793363571167e+00
    phi[6,3]  R1286     -2.2362039089202881e+00
    phi[6,3]  R1287     -9.8868167400360107e-01
    phi[6,3]  R1288     -7.6130986213684082e-01
    phi[6,3]  R1289     -2.1482448577880859e+00
    phi[6,3]  R1290     -1.1539065837860107e+00
    phi[6,3]  R1291     -1.6417894363403320e+00
    phi[6,3]  R1292     -2.8224108219146729e+00
    phi[6,3]  R1293     -1.8637168407440186e-01
    phi[6,3]  R1294     -2.1704065799713135e-01
    phi[6,3]  R1295     5.3738448768854141e-03
    phi[6,3]  R1296     1.3588632643222809e-01
    phi[6,3]  R1297     -2.0460567474365234e+00
    phi[6,3]  R1298     -8.2387423515319824e-01
    phi[6,3]  R1299     -1.7387566566467285e+00
    phi[6,3]  R1300     -2.5483138561248779e+00
    phi[6,3]  R1301     -1.9092139005661011e+00
    phi[6,3]  R1302     -2.5550856590270996e+00
    phi[6,3]  R1303     -9.8190808296203613e-01
    phi[6,3]  R1304     -1.6184545755386353e+00
    phi[6,3]  R1305     -2.6678955554962158e+00
    phi[6,3]  R1306     -3.1588549613952637e+00
    phi[6,3]  R1307     -1.5635890960693359e+00
    phi[6,3]  R1308     -1.2759013175964355e+00
    phi[6,3]  R1309     -1.0144550800323486e+00
    phi[6,3]  R1310     -1.4135593175888062e+00
    phi[6,3]  R1311     -2.5997298955917358e-01
    phi[6,3]  R1312     -1.5232124924659729e-01
    phi[6,3]  R1313     -1.2059509754180908e+00
    phi[6,3]  R1314     -0.713696300983429
    phi[6,3]  R1315     -1.6927288770675659e+00
    phi[6,3]  R1316     -2.0090565681457520e+00
    phi[6,3]  R1317     -6.8751549720764160e-01
    phi[6,3]  R1318     -1.5216176509857178e+00
    phi[6,3]  R1319     -1.9370281696319580e+00
    phi[6,3]  R1320     -1.2172225713729858e+00
    phi[6,3]  R1321     -1.3048487901687622e-01
    phi[6,3]  R1322     -3.3392570018768311e+00
    phi[6,3]  R1323     -3.4945511817932129e+00
    phi[6,3]  R1324     -4.1890792846679688e+00
    phi[6,3]  R1325     -0.908643364906311
    phi[6,3]  R1326     -7.3544424772262573e-01
    phi[6,3]  R1327     -1.9967169761657715e+00
    phi[6,3]  R1328     -1.0128711909055710e-01
    phi[6,3]  R1329     -2.4434425830841064e+00
    phi[6,3]  R1330     -2.03611159324646
    phi[6,3]  R1331     -2.2333424091339111e+00
    phi[6,3]  R1332     -4.1757197380065918e+00
    phi[6,3]  R1333     -2.0170805454254150e+00
    phi[6,3]  R1334     -0.543626070022583
    phi[6,3]  R1335     5.3729015588760376e-01
    phi[6,3]  R1336     -7.5084561109542847e-01
    phi[6,3]  R1337     -1.9941475391387939e+00
    phi[6,3]  R1338     -2.2276562452316284e-01
    phi[6,3]  R1339     -3.6721739768981934e+00
    phi[6,3]  R1340     -4.1953749656677246e+00
    phi[6,3]  R1341     -3.0330622196197510e+00
    phi[6,3]  R1342     -1.5494794845581055e+00
    phi[6,3]  R1343     -2.7240601181983948e-01
    phi[6,3]  R1344     -1.2311660051345825e+00
    phi[6,3]  R1345     -1.9987718760967255e-01
    phi[6,3]  R1346     -1.0165917873382568e+00
    phi[6,3]  R1347     -1.2333720922470093e-02
    phi[6,3]  R1348     -1.8869051933288574e+00
    phi[6,3]  R1349     -2.6290321350097656e+00
    phi[6,3]  R1350     -6.8977195024490356e-01
    phi[6,3]  R1351     -1.0673456192016602e+00
    phi[6,3]  R1352     -1.1832598447799683e+00
    phi[6,3]  R1353     -6.7660528421401978e-01
    phi[6,3]  R1354     2.8066933155059814e-01
    phi[6,3]  R1355     -8.3757573366165161e-01
    phi[6,3]  R1356     3.1437245011329651e-01
    phi[6,3]  R1357     -1.7640326023101807e+00
    phi[6,3]  R1358     -1.7597335577011108e-01
    phi[6,3]  R1359     -8.1570214033126831e-01
    phi[6,3]  R1360     -1.4162975549697876e+00
    phi[6,3]  R1361     -1.4853594303131104e+00
    phi[6,3]  R1362     -2.5981919765472412e+00
    phi[6,3]  R1363     5.5796223878860474e-01
    phi[6,3]  R1364     -1.5960524082183838e+00
    phi[6,3]  R1365     -3.2067394256591797e-01
    phi[6,3]  R1366     -2.2537949085235596e+00
    phi[6,3]  R1367     5.0745338201522827e-01
    phi[6,3]  R1368     8.9110630750656128e-01
    phi[6,3]  R1369     1.4240763187408447e+00
    phi[6,3]  R1370     9.4183725118637085e-01
    phi[6,3]  R1371     1.0605401992797852e+00
    phi[6,3]  R1372     1.7971543073654175e+00
    phi[6,3]  R1373     2.2241299152374268e+00
    phi[6,3]  R1374     1.2460120916366577e+00
    phi[6,3]  R1375     1.2202658653259277e+00
    phi[6,3]  R1376     -4.9424678087234497e-01
    phi[6,3]  R1377     -3.4570839405059814e+00
    phi[6,3]  R1378     -1.4220961332321167e+00
    phi[6,3]  R1379     -2.9759931564331055e+00
    phi[6,3]  R1380     -2.6479539871215820e+00
    phi[6,3]  R1381     -1.29734468460083
    phi[6,3]  R1382     -2.0743198394775391e+00
    phi[6,3]  R1383     -1.6001542806625366e+00
    phi[6,3]  R1384     -1.3967503309249878e+00
    phi[6,3]  R1385     -1.1128625869750977e+00
    phi[6,3]  R1386     -1.0474383831024170e-01
    phi[6,3]  R1387     -1.8971928954124451e-01
    phi[6,3]  R1388     -0.0905231386423111
    phi[6,3]  R1389     1.0984394550323486e+00
    phi[6,3]  R1390     4.6089610457420349e-01
    phi[6,3]  R1391     -3.3479893207550049e-01
    phi[6,3]  R1392     -1.5185858011245728e+00
    phi[6,3]  R1393     -2.7172853946685791e+00
    phi[6,3]  R1394     -1.1727275848388672e+00
    phi[6,3]  R1395     4.2846730351448059e-01
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R54       -1
    phi[4,6]  R1396     -3.0999999046325684e+00
    phi[4,6]  R1397     -3.0999999046325684e+00
    phi[4,6]  R1398     -2.2400000095367432e+00
    phi[4,6]  R1399     -2.2400000095367432e+00
    phi[4,6]  R1400     -3.0999999046325684e+00
    phi[4,6]  R1401     -3.0999999046325684e+00
    phi[4,6]  R1402     -2.5699999332427979e+00
    phi[4,6]  R1403     -2.5699999332427979e+00
    phi[4,6]  R1404     -3.0999999046325684e+00
    phi[4,6]  R1405     -3.0999999046325684e+00
    phi[4,6]  R1406     -2.0899999141693115e+00
    phi[4,6]  R1407     -2.0899999141693115e+00
    phi[4,6]  R1408     -3.0999999046325684e+00
    phi[4,6]  R1409     -3.0999999046325684e+00
    phi[4,6]  R1410     4.8187974095344543e-01
    phi[4,6]  R1411     2.0093200206756592e+00
    phi[4,6]  R1412     1.7898755073547363e+00
    phi[4,6]  R1413     2.6218130588531494e+00
    phi[4,6]  R1414     2.0890166759490967e+00
    phi[4,6]  R1415     1.5692213773727417e+00
    phi[4,6]  R1416     -5.4353260993957520e-01
    phi[4,6]  R1417     9.6373111009597778e-01
    phi[4,6]  R1418     1.4591118097305298e+00
    phi[4,6]  R1419     3.4484589099884033e-01
    phi[4,6]  R1420     -1.4573565721511841e+00
    phi[4,6]  R1421     -2.9137597084045410e+00
    phi[4,6]  R1422     -6.1391180753707886e-01
    phi[4,6]  R1423     -3.2690780162811279e+00
    phi[4,6]  R1424     -3.0009763240814209e+00
    phi[4,6]  R1425     -5.3161704540252686e-01
    phi[4,6]  R1426     -2.0279216766357422e+00
    phi[4,6]  R1427     -1.4070169925689697e+00
    phi[4,6]  R1428     -1.2895026206970215e+00
    phi[4,6]  R1429     -2.0862873643636703e-03
    phi[4,6]  R1430     -2.6962976455688477e+00
    phi[4,6]  R1431     -1.3191516399383545e+00
    phi[4,6]  R1432     -0.628633975982666
    phi[4,6]  R1433     1.1832149028778076e+00
    phi[4,6]  R1434     2.6629621982574463e+00
    phi[4,6]  R1435     1.1491990089416504e-01
    phi[4,6]  R1436     1.0011961460113525e+00
    phi[4,6]  R1437     1.8038105964660645e+00
    phi[4,6]  R1438     2.0212562084198
    phi[4,6]  R1439     2.2199401855468750e+00
    phi[4,6]  R1440     1.8166892528533936e+00
    phi[4,6]  R1441     1.3593620061874390e+00
    phi[4,6]  R1442     2.4568644165992737e-01
    phi[4,6]  R1443     5.2529424428939819e-01
    phi[4,6]  R1444     1.0967795848846436e+00
    phi[4,6]  R1445     1.2748793363571167e+00
    phi[4,6]  R1446     -2.2362039089202881e+00
    phi[4,6]  R1447     -9.8868167400360107e-01
    phi[4,6]  R1448     -7.6130986213684082e-01
    phi[4,6]  R1449     -2.1482448577880859e+00
    phi[4,6]  R1450     -1.1539065837860107e+00
    phi[4,6]  R1451     -1.6417894363403320e+00
    phi[4,6]  R1452     -2.8224108219146729e+00
    phi[4,6]  R1453     -1.8637168407440186e-01
    phi[4,6]  R1454     -2.1704065799713135e-01
    phi[4,6]  R1455     5.3738448768854141e-03
    phi[4,6]  R1456     1.3588632643222809e-01
    phi[4,6]  R1457     -2.0460567474365234e+00
    phi[4,6]  R1458     -8.2387423515319824e-01
    phi[4,6]  R1459     -1.7387566566467285e+00
    phi[4,6]  R1460     -2.5483138561248779e+00
    phi[4,6]  R1461     -1.9092139005661011e+00
    phi[4,6]  R1462     -2.5550856590270996e+00
    phi[4,6]  R1463     -9.8190808296203613e-01
    phi[4,6]  R1464     -1.6184545755386353e+00
    phi[4,6]  R1465     -2.6678955554962158e+00
    phi[4,6]  R1466     -3.1588549613952637e+00
    phi[4,6]  R1467     -1.5635890960693359e+00
    phi[4,6]  R1468     -1.2759013175964355e+00
    phi[4,6]  R1469     -1.0144550800323486e+00
    phi[4,6]  R1470     -1.4135593175888062e+00
    phi[4,6]  R1471     -2.5997298955917358e-01
    phi[4,6]  R1472     -1.5232124924659729e-01
    phi[4,6]  R1473     -1.2059509754180908e+00
    phi[4,6]  R1474     -0.713696300983429
    phi[4,6]  R1475     -1.6927288770675659e+00
    phi[4,6]  R1476     -2.0090565681457520e+00
    phi[4,6]  R1477     -6.8751549720764160e-01
    phi[4,6]  R1478     -1.5216176509857178e+00
    phi[4,6]  R1479     -1.9370281696319580e+00
    phi[4,6]  R1480     -1.2172225713729858e+00
    phi[4,6]  R1481     -1.3048487901687622e-01
    phi[4,6]  R1482     -3.3392570018768311e+00
    phi[4,6]  R1483     -3.4945511817932129e+00
    phi[4,6]  R1484     -4.1890792846679688e+00
    phi[4,6]  R1485     -0.908643364906311
    phi[4,6]  R1486     -7.3544424772262573e-01
    phi[4,6]  R1487     -1.9967169761657715e+00
    phi[4,6]  R1488     -1.0128711909055710e-01
    phi[4,6]  R1489     -2.4434425830841064e+00
    phi[4,6]  R1490     -2.03611159324646
    phi[4,6]  R1491     -2.2333424091339111e+00
    phi[4,6]  R1492     -4.1757197380065918e+00
    phi[4,6]  R1493     -2.0170805454254150e+00
    phi[4,6]  R1494     -0.543626070022583
    phi[4,6]  R1495     5.3729015588760376e-01
    phi[4,6]  R1496     -7.5084561109542847e-01
    phi[4,6]  R1497     -1.9941475391387939e+00
    phi[4,6]  R1498     -2.2276562452316284e-01
    phi[4,6]  R1499     -3.6721739768981934e+00
    phi[4,6]  R1500     -4.1953749656677246e+00
    phi[4,6]  R1501     -3.0330622196197510e+00
    phi[4,6]  R1502     -1.5494794845581055e+00
    phi[4,6]  R1503     -2.7240601181983948e-01
    phi[4,6]  R1504     -1.2311660051345825e+00
    phi[4,6]  R1505     -1.9987718760967255e-01
    phi[4,6]  R1506     -1.0165917873382568e+00
    phi[4,6]  R1507     -1.2333720922470093e-02
    phi[4,6]  R1508     -1.8869051933288574e+00
    phi[4,6]  R1509     -2.6290321350097656e+00
    phi[4,6]  R1510     -6.8977195024490356e-01
    phi[4,6]  R1511     -1.0673456192016602e+00
    phi[4,6]  R1512     -1.1832598447799683e+00
    phi[4,6]  R1513     -6.7660528421401978e-01
    phi[4,6]  R1514     2.8066933155059814e-01
    phi[4,6]  R1515     -8.3757573366165161e-01
    phi[4,6]  R1516     3.1437245011329651e-01
    phi[4,6]  R1517     -1.7640326023101807e+00
    phi[4,6]  R1518     -1.7597335577011108e-01
    phi[4,6]  R1519     -8.1570214033126831e-01
    phi[4,6]  R1520     -1.4162975549697876e+00
    phi[4,6]  R1521     -1.4853594303131104e+00
    phi[4,6]  R1522     -2.5981919765472412e+00
    phi[4,6]  R1523     5.5796223878860474e-01
    phi[4,6]  R1524     -1.5960524082183838e+00
    phi[4,6]  R1525     -3.2067394256591797e-01
    phi[4,6]  R1526     -2.2537949085235596e+00
    phi[6,4]  R36       -1
    phi[6,4]  R54       1
    phi[6,4]  R55       1
    phi[6,4]  R1527     -3.0999999046325684e+00
    phi[6,4]  R1528     -3.0999999046325684e+00
    phi[6,4]  R1529     -2.2400000095367432e+00
    phi[6,4]  R1530     -2.2400000095367432e+00
    phi[6,4]  R1531     -3.0999999046325684e+00
    phi[6,4]  R1532     -3.0999999046325684e+00
    phi[6,4]  R1533     -2.5699999332427979e+00
    phi[6,4]  R1534     -2.5699999332427979e+00
    phi[6,4]  R1535     -3.0999999046325684e+00
    phi[6,4]  R1536     -3.0999999046325684e+00
    phi[6,4]  R1537     -2.0899999141693115e+00
    phi[6,4]  R1538     -2.0899999141693115e+00
    phi[6,4]  R1539     -3.0999999046325684e+00
    phi[6,4]  R1540     -3.0999999046325684e+00
    phi[6,4]  R1541     1.8038105964660645e+00
    phi[6,4]  R1542     2.0212562084198
    phi[6,4]  R1543     2.2199401855468750e+00
    phi[6,4]  R1544     1.8166892528533936e+00
    phi[6,4]  R1545     1.3593620061874390e+00
    phi[6,4]  R1546     2.4568644165992737e-01
    phi[6,4]  R1547     5.2529424428939819e-01
    phi[6,4]  R1548     1.0967795848846436e+00
    phi[6,4]  R1549     1.2748793363571167e+00
    phi[6,4]  R1550     -2.2362039089202881e+00
    phi[6,4]  R1551     -9.8868167400360107e-01
    phi[6,4]  R1552     -7.6130986213684082e-01
    phi[6,4]  R1553     -2.1482448577880859e+00
    phi[6,4]  R1554     -1.1539065837860107e+00
    phi[6,4]  R1555     -1.6417894363403320e+00
    phi[6,4]  R1556     -2.8224108219146729e+00
    phi[6,4]  R1557     -1.8637168407440186e-01
    phi[6,4]  R1558     -2.1704065799713135e-01
    phi[6,4]  R1559     5.3738448768854141e-03
    phi[6,4]  R1560     1.3588632643222809e-01
    phi[6,4]  R1561     -2.0460567474365234e+00
    phi[6,4]  R1562     -8.2387423515319824e-01
    phi[6,4]  R1563     -1.7387566566467285e+00
    phi[6,4]  R1564     -2.5483138561248779e+00
    phi[6,4]  R1565     -1.9092139005661011e+00
    phi[6,4]  R1566     -2.5550856590270996e+00
    phi[6,4]  R1567     -9.8190808296203613e-01
    phi[6,4]  R1568     -1.6184545755386353e+00
    phi[6,4]  R1569     -2.6678955554962158e+00
    phi[6,4]  R1570     -3.1588549613952637e+00
    phi[6,4]  R1571     -1.5635890960693359e+00
    phi[6,4]  R1572     -1.2759013175964355e+00
    phi[6,4]  R1573     -1.0144550800323486e+00
    phi[6,4]  R1574     -1.4135593175888062e+00
    phi[6,4]  R1575     -2.5997298955917358e-01
    phi[6,4]  R1576     -1.5232124924659729e-01
    phi[6,4]  R1577     -1.2059509754180908e+00
    phi[6,4]  R1578     -0.713696300983429
    phi[6,4]  R1579     -1.6927288770675659e+00
    phi[6,4]  R1580     -2.0090565681457520e+00
    phi[6,4]  R1581     -6.8751549720764160e-01
    phi[6,4]  R1582     -1.5216176509857178e+00
    phi[6,4]  R1583     -1.9370281696319580e+00
    phi[6,4]  R1584     -1.2172225713729858e+00
    phi[6,4]  R1585     -1.3048487901687622e-01
    phi[6,4]  R1586     -3.3392570018768311e+00
    phi[6,4]  R1587     -3.4945511817932129e+00
    phi[6,4]  R1588     -4.1890792846679688e+00
    phi[6,4]  R1589     -0.908643364906311
    phi[6,4]  R1590     -7.3544424772262573e-01
    phi[6,4]  R1591     -1.9967169761657715e+00
    phi[6,4]  R1592     -1.0128711909055710e-01
    phi[6,4]  R1593     -2.4434425830841064e+00
    phi[6,4]  R1594     -2.03611159324646
    phi[6,4]  R1595     -2.2333424091339111e+00
    phi[6,4]  R1596     -4.1757197380065918e+00
    phi[6,4]  R1597     -2.0170805454254150e+00
    phi[6,4]  R1598     -0.543626070022583
    phi[6,4]  R1599     5.3729015588760376e-01
    phi[6,4]  R1600     -7.5084561109542847e-01
    phi[6,4]  R1601     -1.9941475391387939e+00
    phi[6,4]  R1602     -2.2276562452316284e-01
    phi[6,4]  R1603     -3.6721739768981934e+00
    phi[6,4]  R1604     -4.1953749656677246e+00
    phi[6,4]  R1605     -3.0330622196197510e+00
    phi[6,4]  R1606     -1.5494794845581055e+00
    phi[6,4]  R1607     -2.7240601181983948e-01
    phi[6,4]  R1608     -1.2311660051345825e+00
    phi[6,4]  R1609     -1.9987718760967255e-01
    phi[6,4]  R1610     -1.0165917873382568e+00
    phi[6,4]  R1611     -1.2333720922470093e-02
    phi[6,4]  R1612     -1.8869051933288574e+00
    phi[6,4]  R1613     -2.6290321350097656e+00
    phi[6,4]  R1614     -6.8977195024490356e-01
    phi[6,4]  R1615     -1.0673456192016602e+00
    phi[6,4]  R1616     -1.1832598447799683e+00
    phi[6,4]  R1617     -6.7660528421401978e-01
    phi[6,4]  R1618     2.8066933155059814e-01
    phi[6,4]  R1619     -8.3757573366165161e-01
    phi[6,4]  R1620     3.1437245011329651e-01
    phi[6,4]  R1621     -1.7640326023101807e+00
    phi[6,4]  R1622     -1.7597335577011108e-01
    phi[6,4]  R1623     -8.1570214033126831e-01
    phi[6,4]  R1624     -1.4162975549697876e+00
    phi[6,4]  R1625     -1.4853594303131104e+00
    phi[6,4]  R1626     -2.5981919765472412e+00
    phi[6,4]  R1627     5.5796223878860474e-01
    phi[6,4]  R1628     -1.5960524082183838e+00
    phi[6,4]  R1629     -3.2067394256591797e-01
    phi[6,4]  R1630     -2.2537949085235596e+00
    phi[6,4]  R1631     4.8187974095344543e-01
    phi[6,4]  R1632     2.0093200206756592e+00
    phi[6,4]  R1633     1.7898755073547363e+00
    phi[6,4]  R1634     2.6218130588531494e+00
    phi[6,4]  R1635     2.0890166759490967e+00
    phi[6,4]  R1636     1.5692213773727417e+00
    phi[6,4]  R1637     -5.4353260993957520e-01
    phi[6,4]  R1638     9.6373111009597778e-01
    phi[6,4]  R1639     1.4591118097305298e+00
    phi[6,4]  R1640     3.4484589099884033e-01
    phi[6,4]  R1641     -1.4573565721511841e+00
    phi[6,4]  R1642     -2.9137597084045410e+00
    phi[6,4]  R1643     -6.1391180753707886e-01
    phi[6,4]  R1644     -3.2690780162811279e+00
    phi[6,4]  R1645     -3.0009763240814209e+00
    phi[6,4]  R1646     -5.3161704540252686e-01
    phi[6,4]  R1647     -2.0279216766357422e+00
    phi[6,4]  R1648     -1.4070169925689697e+00
    phi[6,4]  R1649     -1.2895026206970215e+00
    phi[6,4]  R1650     -2.0862873643636703e-03
    phi[6,4]  R1651     -2.6962976455688477e+00
    phi[6,4]  R1652     -1.3191516399383545e+00
    phi[6,4]  R1653     -0.628633975982666
    phi[6,4]  R1654     1.1832149028778076e+00
    phi[6,4]  R1655     2.6629621982574463e+00
    phi[6,4]  R1656     1.1491990089416504e-01
    phi[6,4]  R1657     1.0011961460113525e+00
    phi[4,7]  R36       1
    phi[4,7]  R37       1
    phi[4,7]  R63       -1
    phi[4,7]  R1658     -3.0999999046325684e+00
    phi[4,7]  R1659     -3.0999999046325684e+00
    phi[4,7]  R1660     -2.2400000095367432e+00
    phi[4,7]  R1661     -2.2400000095367432e+00
    phi[4,7]  R1662     -3.0999999046325684e+00
    phi[4,7]  R1663     -3.0999999046325684e+00
    phi[4,7]  R1664     -2.5699999332427979e+00
    phi[4,7]  R1665     -2.5699999332427979e+00
    phi[4,7]  R1666     -3.0999999046325684e+00
    phi[4,7]  R1667     -3.0999999046325684e+00
    phi[4,7]  R1668     -2.0899999141693115e+00
    phi[4,7]  R1669     -2.0899999141693115e+00
    phi[4,7]  R1670     -3.0999999046325684e+00
    phi[4,7]  R1671     -3.0999999046325684e+00
    phi[4,7]  R1672     4.8187974095344543e-01
    phi[4,7]  R1673     2.0093200206756592e+00
    phi[4,7]  R1674     1.7898755073547363e+00
    phi[4,7]  R1675     2.6218130588531494e+00
    phi[4,7]  R1676     2.0890166759490967e+00
    phi[4,7]  R1677     1.5692213773727417e+00
    phi[4,7]  R1678     -5.4353260993957520e-01
    phi[4,7]  R1679     9.6373111009597778e-01
    phi[4,7]  R1680     1.4591118097305298e+00
    phi[4,7]  R1681     3.4484589099884033e-01
    phi[4,7]  R1682     -1.4573565721511841e+00
    phi[4,7]  R1683     -2.9137597084045410e+00
    phi[4,7]  R1684     -6.1391180753707886e-01
    phi[4,7]  R1685     -3.2690780162811279e+00
    phi[4,7]  R1686     -3.0009763240814209e+00
    phi[4,7]  R1687     -5.3161704540252686e-01
    phi[4,7]  R1688     -2.0279216766357422e+00
    phi[4,7]  R1689     -1.4070169925689697e+00
    phi[4,7]  R1690     -1.2895026206970215e+00
    phi[4,7]  R1691     -2.0862873643636703e-03
    phi[4,7]  R1692     -2.6962976455688477e+00
    phi[4,7]  R1693     -1.3191516399383545e+00
    phi[4,7]  R1694     -0.628633975982666
    phi[4,7]  R1695     1.1832149028778076e+00
    phi[4,7]  R1696     2.6629621982574463e+00
    phi[4,7]  R1697     1.1491990089416504e-01
    phi[4,7]  R1698     1.0011961460113525e+00
    phi[4,7]  R1699     2.0150413513183594e+00
    phi[4,7]  R1700     1.4968860149383545e+00
    phi[4,7]  R1701     -2.8438096046447754e+00
    phi[4,7]  R1702     1.0826414078474045e-01
    phi[4,7]  R1703     1.7752689123153687e-01
    phi[4,7]  R1704     4.3617266416549683e-01
    phi[4,7]  R1705     4.0436872839927673e-01
    phi[4,7]  R1706     -3.7800329923629761e-01
    phi[4,7]  R1707     8.4761154651641846e-01
    phi[4,7]  R1708     0.651405394077301
    phi[4,7]  R1709     -4.4037094712257385e-01
    phi[4,7]  R1710     -1.4560825824737549e+00
    phi[4,7]  R1711     -1.7932511568069458e+00
    phi[4,7]  R1712     -1.7454859018325806e+00
    phi[4,7]  R1713     -1.5633412599563599e+00
    phi[4,7]  R1714     -3.8430997729301453e-01
    phi[4,7]  R1715     -2.6706447601318359e+00
    phi[4,7]  R1716     -4.6246060729026794e-01
    phi[4,7]  R1717     -3.06062912940979
    phi[4,7]  R1718     -1.2439155578613281e+00
    phi[4,7]  R1719     -6.3279181718826294e-01
    phi[4,7]  R1720     5.9808656573295593e-02
    phi[4,7]  R1721     -1.6550880670547485e+00
    phi[4,7]  R1722     1.7244294285774231e-01
    phi[4,7]  R1723     1.1380119323730469e+00
    phi[4,7]  R1724     -8.9563065767288208e-01
    phi[4,7]  R1725     -1.9534405469894409e+00
    phi[4,7]  R1726     -3.6958918571472168e+00
    phi[4,7]  R1727     -1.7569239437580109e-01
    phi[4,7]  R1728     1.0592563152313232e+00
    phi[4,7]  R1729     0.43216472864151
    phi[4,7]  R1730     8.5986185073852539e-01
    phi[4,7]  R1731     -7.9572558403015137e-01
    phi[4,7]  R1732     -1.6109818220138550e+00
    phi[4,7]  R1733     -1.7519693374633789e+00
    phi[4,7]  R1734     -3.6704263091087341e-01
    phi[4,7]  R1735     -1.2753430604934692e+00
    phi[4,7]  R1736     0.68264240026474
    phi[4,7]  R1737     2.3619375228881836e+00
    phi[4,7]  R1738     -1.00785231590271
    phi[4,7]  R1739     1.6111788749694824e+00
    phi[4,7]  R1740     -2.7809832096099854e+00
    phi[4,7]  R1741     -2.3177402019500732e+00
    phi[4,7]  R1742     -5.4667842388153076e-01
    phi[4,7]  R1743     2.1975574493408203e+00
    phi[4,7]  R1744     -2.4117450416088104e-01
    phi[4,7]  R1745     -1.9167350530624390e+00
    phi[4,7]  R1746     -2.27809739112854
    phi[4,7]  R1747     1.4740236103534698e-01
    phi[4,7]  R1748     -1.9550332427024841e-01
    phi[4,7]  R1749     1.7372554540634155e+00
    phi[4,7]  R1750     1.1902285814285278e+00
    phi[4,7]  R1751     -2.0217165946960449e+00
    phi[4,7]  R1752     -6.1438417434692383e-01
    phi[4,7]  R1753     -3.1733589172363281e+00
    phi[4,7]  R1754     2.4761250019073486e+00
    phi[4,7]  R1755     -1.2785010039806366e-01
    phi[4,7]  R1756     -7.3760515451431274e-01
    phi[4,7]  R1757     -5.0078493356704712e-01
    phi[4,7]  R1758     -2.7051886916160583e-01
    phi[4,7]  R1759     6.9690513610839844e-01
    phi[4,7]  R1760     1.9463976621627808e+00
    phi[4,7]  R1761     -1.0962697267532349e+00
    phi[4,7]  R1762     -2.54120135307312
    phi[4,7]  R1763     -2.1767981052398682e+00
    phi[4,7]  R1764     -1.0964717864990234e+00
    phi[4,7]  R1765     -5.0864791870117188e-01
    phi[4,7]  R1766     1.8637862801551819e-01
    phi[4,7]  R1767     4.7918297350406647e-02
    phi[4,7]  R1768     -2.8022947907447815e-01
    phi[4,7]  R1769     2.3254683613777161e-01
    phi[4,7]  R1770     -7.3991787433624268e-01
    phi[4,7]  R1771     6.7616409063339233e-01
    phi[4,7]  R1772     -4.9957323074340820e-01
    phi[4,7]  R1773     -1.3796045780181885e+00
    phi[4,7]  R1774     0.939115583896637
    phi[4,7]  R1775     -9.8183810710906982e-01
    phi[4,7]  R1776     5.6823700666427612e-01
    phi[7,4]  R36       -1
    phi[7,4]  R63       1
    phi[7,4]  R64       1
    phi[7,4]  R1777     -3.0999999046325684e+00
    phi[7,4]  R1778     -3.0999999046325684e+00
    phi[7,4]  R1779     -2.2400000095367432e+00
    phi[7,4]  R1780     -2.2400000095367432e+00
    phi[7,4]  R1781     -3.0999999046325684e+00
    phi[7,4]  R1782     -3.0999999046325684e+00
    phi[7,4]  R1783     -2.5699999332427979e+00
    phi[7,4]  R1784     -2.5699999332427979e+00
    phi[7,4]  R1785     -3.0999999046325684e+00
    phi[7,4]  R1786     -3.0999999046325684e+00
    phi[7,4]  R1787     -2.0899999141693115e+00
    phi[7,4]  R1788     -2.0899999141693115e+00
    phi[7,4]  R1789     -3.0999999046325684e+00
    phi[7,4]  R1790     -3.0999999046325684e+00
    phi[7,4]  R1791     2.0150413513183594e+00
    phi[7,4]  R1792     1.4968860149383545e+00
    phi[7,4]  R1793     -2.8438096046447754e+00
    phi[7,4]  R1794     1.0826414078474045e-01
    phi[7,4]  R1795     1.7752689123153687e-01
    phi[7,4]  R1796     4.3617266416549683e-01
    phi[7,4]  R1797     4.0436872839927673e-01
    phi[7,4]  R1798     -3.7800329923629761e-01
    phi[7,4]  R1799     8.4761154651641846e-01
    phi[7,4]  R1800     0.651405394077301
    phi[7,4]  R1801     -4.4037094712257385e-01
    phi[7,4]  R1802     -1.4560825824737549e+00
    phi[7,4]  R1803     -1.7932511568069458e+00
    phi[7,4]  R1804     -1.7454859018325806e+00
    phi[7,4]  R1805     -1.5633412599563599e+00
    phi[7,4]  R1806     -3.8430997729301453e-01
    phi[7,4]  R1807     -2.6706447601318359e+00
    phi[7,4]  R1808     -4.6246060729026794e-01
    phi[7,4]  R1809     -3.06062912940979
    phi[7,4]  R1810     -1.2439155578613281e+00
    phi[7,4]  R1811     -6.3279181718826294e-01
    phi[7,4]  R1812     5.9808656573295593e-02
    phi[7,4]  R1813     -1.6550880670547485e+00
    phi[7,4]  R1814     1.7244294285774231e-01
    phi[7,4]  R1815     1.1380119323730469e+00
    phi[7,4]  R1816     -8.9563065767288208e-01
    phi[7,4]  R1817     -1.9534405469894409e+00
    phi[7,4]  R1818     -3.6958918571472168e+00
    phi[7,4]  R1819     -1.7569239437580109e-01
    phi[7,4]  R1820     1.0592563152313232e+00
    phi[7,4]  R1821     0.43216472864151
    phi[7,4]  R1822     8.5986185073852539e-01
    phi[7,4]  R1823     -7.9572558403015137e-01
    phi[7,4]  R1824     -1.6109818220138550e+00
    phi[7,4]  R1825     -1.7519693374633789e+00
    phi[7,4]  R1826     -3.6704263091087341e-01
    phi[7,4]  R1827     -1.2753430604934692e+00
    phi[7,4]  R1828     0.68264240026474
    phi[7,4]  R1829     2.3619375228881836e+00
    phi[7,4]  R1830     -1.00785231590271
    phi[7,4]  R1831     1.6111788749694824e+00
    phi[7,4]  R1832     -2.7809832096099854e+00
    phi[7,4]  R1833     -2.3177402019500732e+00
    phi[7,4]  R1834     -5.4667842388153076e-01
    phi[7,4]  R1835     2.1975574493408203e+00
    phi[7,4]  R1836     -2.4117450416088104e-01
    phi[7,4]  R1837     -1.9167350530624390e+00
    phi[7,4]  R1838     -2.27809739112854
    phi[7,4]  R1839     1.4740236103534698e-01
    phi[7,4]  R1840     -1.9550332427024841e-01
    phi[7,4]  R1841     1.7372554540634155e+00
    phi[7,4]  R1842     1.1902285814285278e+00
    phi[7,4]  R1843     -2.0217165946960449e+00
    phi[7,4]  R1844     -6.1438417434692383e-01
    phi[7,4]  R1845     -3.1733589172363281e+00
    phi[7,4]  R1846     2.4761250019073486e+00
    phi[7,4]  R1847     -1.2785010039806366e-01
    phi[7,4]  R1848     -7.3760515451431274e-01
    phi[7,4]  R1849     -5.0078493356704712e-01
    phi[7,4]  R1850     -2.7051886916160583e-01
    phi[7,4]  R1851     6.9690513610839844e-01
    phi[7,4]  R1852     1.9463976621627808e+00
    phi[7,4]  R1853     -1.0962697267532349e+00
    phi[7,4]  R1854     -2.54120135307312
    phi[7,4]  R1855     -2.1767981052398682e+00
    phi[7,4]  R1856     -1.0964717864990234e+00
    phi[7,4]  R1857     -5.0864791870117188e-01
    phi[7,4]  R1858     1.8637862801551819e-01
    phi[7,4]  R1859     4.7918297350406647e-02
    phi[7,4]  R1860     -2.8022947907447815e-01
    phi[7,4]  R1861     2.3254683613777161e-01
    phi[7,4]  R1862     -7.3991787433624268e-01
    phi[7,4]  R1863     6.7616409063339233e-01
    phi[7,4]  R1864     -4.9957323074340820e-01
    phi[7,4]  R1865     -1.3796045780181885e+00
    phi[7,4]  R1866     0.939115583896637
    phi[7,4]  R1867     -9.8183810710906982e-01
    phi[7,4]  R1868     5.6823700666427612e-01
    phi[7,4]  R1869     4.8187974095344543e-01
    phi[7,4]  R1870     2.0093200206756592e+00
    phi[7,4]  R1871     1.7898755073547363e+00
    phi[7,4]  R1872     2.6218130588531494e+00
    phi[7,4]  R1873     2.0890166759490967e+00
    phi[7,4]  R1874     1.5692213773727417e+00
    phi[7,4]  R1875     -5.4353260993957520e-01
    phi[7,4]  R1876     9.6373111009597778e-01
    phi[7,4]  R1877     1.4591118097305298e+00
    phi[7,4]  R1878     3.4484589099884033e-01
    phi[7,4]  R1879     -1.4573565721511841e+00
    phi[7,4]  R1880     -2.9137597084045410e+00
    phi[7,4]  R1881     -6.1391180753707886e-01
    phi[7,4]  R1882     -3.2690780162811279e+00
    phi[7,4]  R1883     -3.0009763240814209e+00
    phi[7,4]  R1884     -5.3161704540252686e-01
    phi[7,4]  R1885     -2.0279216766357422e+00
    phi[7,4]  R1886     -1.4070169925689697e+00
    phi[7,4]  R1887     -1.2895026206970215e+00
    phi[7,4]  R1888     -2.0862873643636703e-03
    phi[7,4]  R1889     -2.6962976455688477e+00
    phi[7,4]  R1890     -1.3191516399383545e+00
    phi[7,4]  R1891     -0.628633975982666
    phi[7,4]  R1892     1.1832149028778076e+00
    phi[7,4]  R1893     2.6629621982574463e+00
    phi[7,4]  R1894     1.1491990089416504e-01
    phi[7,4]  R1895     1.0011961460113525e+00
    phi[4,9]  R36       1
    phi[4,9]  R37       1
    phi[4,9]  R38       -2.5128214674305025e+00
    phi[4,9]  R39       1.71553783194945
    phi[4,9]  R40       -1.2953827123674704e+00
    phi[4,9]  R41       -1.9660003644834090e-01
    phi[4,9]  R42       -5.2692172127935244e-01
    phi[4,9]  R43       1.8262669626668846e+00
    phi[4,9]  R44       -1.1980901301459501e+00
    phi[4,9]  R73       -1
    phi[4,9]  R1896     -5.61282137206307
    phi[4,9]  R1897     -5.8717843720206586e-01
    phi[4,9]  R1898     -5.2446217758729308e-01
    phi[4,9]  R1899     -3.9555378414861933e+00
    phi[4,9]  R1900     -4.3953826170000383e+00
    phi[4,9]  R1901     -1.8046171922650980e+00
    phi[4,9]  R1902     -2.7665999696911387e+00
    phi[4,9]  R1903     -2.3733998967944570e+00
    phi[4,9]  R1904     -3.6269216259119208e+00
    phi[4,9]  R1905     -2.5730781833532159e+00
    phi[4,9]  R1906     -2.6373295150242693e-01
    phi[4,9]  R1907     -3.9162668768361959e+00
    phi[4,9]  R1908     -4.2980900347785180e+00
    phi[4,9]  R1909     -1.9019097744866182e+00
    phi[4,9]  R1910     -1.7125836934656569e-01
    phi[4,9]  R1911     -7.3172321237305171e-01
    phi[4,9]  R1912     -1.4359321817268729e+00
    phi[4,9]  R1913     -4.1373224478431503e-01
    phi[4,9]  R1914     -1.03741873062246
    phi[4,9]  R1915     -2.3350071956751828e-01
    phi[4,9]  R1916     -0.23480011562664
    phi[4,9]  R1917     -2.5077750166708745e-01
    phi[4,9]  R1918     -2.5133424092941858e-01
    phi[4,9]  R1919     -3.8888546673288760e-01
    phi[4,9]  R1920     -1.3427776260916735e-01
    phi[4,9]  R1921     -1.4646983239164735e-01
    phi[4,9]  R1922     -1.4885263845296970e-01
    phi[4,9]  R1923     -1.5199403205486828e-01
    phi[4,9]  R1924     -1.5660153900800511e-01
    phi[4,9]  R1925     -1.5926374198722087e-01
    phi[4,9]  R1926     -2.6649535607035379e-01
    phi[4,9]  R1927     -2.6878491214117028e-01
    phi[4,9]  R1928     -2.9930092738718239e-01
    phi[4,9]  R1929     -3.2359552879268655e-01
    phi[4,9]  R1930     -1.1873541228804285e-01
    phi[4,9]  R1931     -1.2951482583484486e-01
    phi[4,9]  R1932     -1.3748707728586029e-01
    phi[4,9]  R1933     -1.4445607834646346e-01
    phi[4,9]  R1934     -2.1517907672360970e-01
    phi[4,9]  R1935     -3.4456794890778697e-01
    phi[4,9]  R1936     -8.4714500732524423e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1937     -3.0999999046325684e+00
    phi[5,6]  R1938     -3.0999999046325684e+00
    phi[5,6]  R1939     -2.2400000095367432e+00
    phi[5,6]  R1940     -2.2400000095367432e+00
    phi[5,6]  R1941     -3.0999999046325684e+00
    phi[5,6]  R1942     -3.0999999046325684e+00
    phi[5,6]  R1943     -2.5699999332427979e+00
    phi[5,6]  R1944     -2.5699999332427979e+00
    phi[5,6]  R1945     -3.0999999046325684e+00
    phi[5,6]  R1946     -3.0999999046325684e+00
    phi[5,6]  R1947     -2.0899999141693115e+00
    phi[5,6]  R1948     -2.0899999141693115e+00
    phi[5,6]  R1949     -3.0999999046325684e+00
    phi[5,6]  R1950     -3.0999999046325684e+00
    phi[5,6]  R1951     3.2479326725006104e+00
    phi[5,6]  R1952     1.6247555017471313e+00
    phi[5,6]  R1953     3.3914930820465088e+00
    phi[5,6]  R1954     3.0739970207214355e+00
    phi[5,6]  R1955     3.7849428653717041e+00
    phi[5,6]  R1956     2.4234609603881836e+00
    phi[5,6]  R1957     -1.7760206013917923e-02
    phi[5,6]  R1958     -1.0389789342880249e+00
    phi[5,6]  R1959     -2.7524518966674805e+00
    phi[5,6]  R1960     -2.1403837203979492e+00
    phi[5,6]  R1961     2.1624360978603363e-01
    phi[5,6]  R1962     -1.3960171937942505e+00
    phi[5,6]  R1963     -1.8711503744125366e+00
    phi[5,6]  R1964     -1.1130977869033813e+00
    phi[5,6]  R1965     -2.0367376804351807e+00
    phi[5,6]  R1966     -2.2653191089630127e+00
    phi[5,6]  R1967     -1.81752610206604
    phi[5,6]  R1968     -1.9954869747161865e+00
    phi[5,6]  R1969     -2.0656652450561523e+00
    phi[5,6]  R1970     -2.3404552936553955e+00
    phi[5,6]  R1971     -1.8564933538436890e+00
    phi[5,6]  R1972     -1.3937898874282837e+00
    phi[5,6]  R1973     -3.3122777938842773e+00
    phi[5,6]  R1974     -2.8184773921966553e+00
    phi[5,6]  R1975     -1.7431690692901611e+00
    phi[5,6]  R1976     -8.6689352989196777e-01
    phi[5,6]  R1977     -2.0262813568115234e+00
    phi[5,6]  R1978     -2.0563969612121582e+00
    phi[5,6]  R1979     2.5259044766426086e-01
    phi[5,6]  R1980     -0.625604510307312
    phi[5,6]  R1981     -4.2457967996597290e-01
    phi[5,6]  R1982     -2.1121010780334473e+00
    phi[5,6]  R1983     -4.6376881599426270e+00
    phi[5,6]  R1984     -3.1730980873107910e+00
    phi[5,6]  R1985     -1.5191409587860107e+00
    phi[5,6]  R1986     -3.0325779914855957e+00
    phi[5,6]  R1987     -1.0819907486438751e-01
    phi[5,6]  R1988     -6.5798111259937286e-02
    phi[5,6]  R1989     5.5893272161483765e-02
    phi[5,6]  R1990     1.8404124975204468e+00
    phi[5,6]  R1991     1.8038105964660645e+00
    phi[5,6]  R1992     2.0212562084198
    phi[5,6]  R1993     2.2199401855468750e+00
    phi[5,6]  R1994     1.8166892528533936e+00
    phi[5,6]  R1995     1.3593620061874390e+00
    phi[5,6]  R1996     2.4568644165992737e-01
    phi[5,6]  R1997     5.2529424428939819e-01
    phi[5,6]  R1998     1.0967795848846436e+00
    phi[5,6]  R1999     1.2748793363571167e+00
    phi[5,6]  R2000     -2.2362039089202881e+00
    phi[5,6]  R2001     -9.8868167400360107e-01
    phi[5,6]  R2002     -7.6130986213684082e-01
    phi[5,6]  R2003     -2.1482448577880859e+00
    phi[5,6]  R2004     -1.1539065837860107e+00
    phi[5,6]  R2005     -1.6417894363403320e+00
    phi[5,6]  R2006     -2.8224108219146729e+00
    phi[5,6]  R2007     -1.8637168407440186e-01
    phi[5,6]  R2008     -2.1704065799713135e-01
    phi[5,6]  R2009     5.3738448768854141e-03
    phi[5,6]  R2010     1.3588632643222809e-01
    phi[5,6]  R2011     -2.0460567474365234e+00
    phi[5,6]  R2012     -8.2387423515319824e-01
    phi[5,6]  R2013     -1.7387566566467285e+00
    phi[5,6]  R2014     -2.5483138561248779e+00
    phi[5,6]  R2015     -1.9092139005661011e+00
    phi[5,6]  R2016     -2.5550856590270996e+00
    phi[5,6]  R2017     -9.8190808296203613e-01
    phi[5,6]  R2018     -1.6184545755386353e+00
    phi[5,6]  R2019     -2.6678955554962158e+00
    phi[5,6]  R2020     -3.1588549613952637e+00
    phi[5,6]  R2021     -1.5635890960693359e+00
    phi[5,6]  R2022     -1.2759013175964355e+00
    phi[5,6]  R2023     -1.0144550800323486e+00
    phi[5,6]  R2024     -1.4135593175888062e+00
    phi[5,6]  R2025     -2.5997298955917358e-01
    phi[5,6]  R2026     -1.5232124924659729e-01
    phi[5,6]  R2027     -1.2059509754180908e+00
    phi[5,6]  R2028     -0.713696300983429
    phi[5,6]  R2029     -1.6927288770675659e+00
    phi[5,6]  R2030     -2.0090565681457520e+00
    phi[5,6]  R2031     -6.8751549720764160e-01
    phi[5,6]  R2032     -1.5216176509857178e+00
    phi[5,6]  R2033     -1.9370281696319580e+00
    phi[5,6]  R2034     -1.2172225713729858e+00
    phi[5,6]  R2035     -1.3048487901687622e-01
    phi[5,6]  R2036     -3.3392570018768311e+00
    phi[5,6]  R2037     -3.4945511817932129e+00
    phi[5,6]  R2038     -4.1890792846679688e+00
    phi[5,6]  R2039     -0.908643364906311
    phi[5,6]  R2040     -7.3544424772262573e-01
    phi[5,6]  R2041     -1.9967169761657715e+00
    phi[5,6]  R2042     -1.0128711909055710e-01
    phi[5,6]  R2043     -2.4434425830841064e+00
    phi[5,6]  R2044     -2.03611159324646
    phi[5,6]  R2045     -2.2333424091339111e+00
    phi[5,6]  R2046     -4.1757197380065918e+00
    phi[5,6]  R2047     -2.0170805454254150e+00
    phi[5,6]  R2048     -0.543626070022583
    phi[5,6]  R2049     5.3729015588760376e-01
    phi[5,6]  R2050     -7.5084561109542847e-01
    phi[5,6]  R2051     -1.9941475391387939e+00
    phi[5,6]  R2052     -2.2276562452316284e-01
    phi[5,6]  R2053     -3.6721739768981934e+00
    phi[5,6]  R2054     -4.1953749656677246e+00
    phi[5,6]  R2055     -3.0330622196197510e+00
    phi[5,6]  R2056     -1.5494794845581055e+00
    phi[5,6]  R2057     -2.7240601181983948e-01
    phi[5,6]  R2058     -1.2311660051345825e+00
    phi[5,6]  R2059     -1.9987718760967255e-01
    phi[5,6]  R2060     -1.0165917873382568e+00
    phi[5,6]  R2061     -1.2333720922470093e-02
    phi[5,6]  R2062     -1.8869051933288574e+00
    phi[5,6]  R2063     -2.6290321350097656e+00
    phi[5,6]  R2064     -6.8977195024490356e-01
    phi[5,6]  R2065     -1.0673456192016602e+00
    phi[5,6]  R2066     -1.1832598447799683e+00
    phi[5,6]  R2067     -6.7660528421401978e-01
    phi[5,6]  R2068     2.8066933155059814e-01
    phi[5,6]  R2069     -8.3757573366165161e-01
    phi[5,6]  R2070     3.1437245011329651e-01
    phi[5,6]  R2071     -1.7640326023101807e+00
    phi[5,6]  R2072     -1.7597335577011108e-01
    phi[5,6]  R2073     -8.1570214033126831e-01
    phi[5,6]  R2074     -1.4162975549697876e+00
    phi[5,6]  R2075     -1.4853594303131104e+00
    phi[5,6]  R2076     -2.5981919765472412e+00
    phi[5,6]  R2077     5.5796223878860474e-01
    phi[5,6]  R2078     -1.5960524082183838e+00
    phi[5,6]  R2079     -3.2067394256591797e-01
    phi[5,6]  R2080     -2.2537949085235596e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2081     -3.0999999046325684e+00
    phi[6,5]  R2082     -3.0999999046325684e+00
    phi[6,5]  R2083     -2.2400000095367432e+00
    phi[6,5]  R2084     -2.2400000095367432e+00
    phi[6,5]  R2085     -3.0999999046325684e+00
    phi[6,5]  R2086     -3.0999999046325684e+00
    phi[6,5]  R2087     -2.5699999332427979e+00
    phi[6,5]  R2088     -2.5699999332427979e+00
    phi[6,5]  R2089     -3.0999999046325684e+00
    phi[6,5]  R2090     -3.0999999046325684e+00
    phi[6,5]  R2091     -2.0899999141693115e+00
    phi[6,5]  R2092     -2.0899999141693115e+00
    phi[6,5]  R2093     -3.0999999046325684e+00
    phi[6,5]  R2094     -3.0999999046325684e+00
    phi[6,5]  R2095     1.8038105964660645e+00
    phi[6,5]  R2096     2.0212562084198
    phi[6,5]  R2097     2.2199401855468750e+00
    phi[6,5]  R2098     1.8166892528533936e+00
    phi[6,5]  R2099     1.3593620061874390e+00
    phi[6,5]  R2100     2.4568644165992737e-01
    phi[6,5]  R2101     5.2529424428939819e-01
    phi[6,5]  R2102     1.0967795848846436e+00
    phi[6,5]  R2103     1.2748793363571167e+00
    phi[6,5]  R2104     -2.2362039089202881e+00
    phi[6,5]  R2105     -9.8868167400360107e-01
    phi[6,5]  R2106     -7.6130986213684082e-01
    phi[6,5]  R2107     -2.1482448577880859e+00
    phi[6,5]  R2108     -1.1539065837860107e+00
    phi[6,5]  R2109     -1.6417894363403320e+00
    phi[6,5]  R2110     -2.8224108219146729e+00
    phi[6,5]  R2111     -1.8637168407440186e-01
    phi[6,5]  R2112     -2.1704065799713135e-01
    phi[6,5]  R2113     5.3738448768854141e-03
    phi[6,5]  R2114     1.3588632643222809e-01
    phi[6,5]  R2115     -2.0460567474365234e+00
    phi[6,5]  R2116     -8.2387423515319824e-01
    phi[6,5]  R2117     -1.7387566566467285e+00
    phi[6,5]  R2118     -2.5483138561248779e+00
    phi[6,5]  R2119     -1.9092139005661011e+00
    phi[6,5]  R2120     -2.5550856590270996e+00
    phi[6,5]  R2121     -9.8190808296203613e-01
    phi[6,5]  R2122     -1.6184545755386353e+00
    phi[6,5]  R2123     -2.6678955554962158e+00
    phi[6,5]  R2124     -3.1588549613952637e+00
    phi[6,5]  R2125     -1.5635890960693359e+00
    phi[6,5]  R2126     -1.2759013175964355e+00
    phi[6,5]  R2127     -1.0144550800323486e+00
    phi[6,5]  R2128     -1.4135593175888062e+00
    phi[6,5]  R2129     -2.5997298955917358e-01
    phi[6,5]  R2130     -1.5232124924659729e-01
    phi[6,5]  R2131     -1.2059509754180908e+00
    phi[6,5]  R2132     -0.713696300983429
    phi[6,5]  R2133     -1.6927288770675659e+00
    phi[6,5]  R2134     -2.0090565681457520e+00
    phi[6,5]  R2135     -6.8751549720764160e-01
    phi[6,5]  R2136     -1.5216176509857178e+00
    phi[6,5]  R2137     -1.9370281696319580e+00
    phi[6,5]  R2138     -1.2172225713729858e+00
    phi[6,5]  R2139     -1.3048487901687622e-01
    phi[6,5]  R2140     -3.3392570018768311e+00
    phi[6,5]  R2141     -3.4945511817932129e+00
    phi[6,5]  R2142     -4.1890792846679688e+00
    phi[6,5]  R2143     -0.908643364906311
    phi[6,5]  R2144     -7.3544424772262573e-01
    phi[6,5]  R2145     -1.9967169761657715e+00
    phi[6,5]  R2146     -1.0128711909055710e-01
    phi[6,5]  R2147     -2.4434425830841064e+00
    phi[6,5]  R2148     -2.03611159324646
    phi[6,5]  R2149     -2.2333424091339111e+00
    phi[6,5]  R2150     -4.1757197380065918e+00
    phi[6,5]  R2151     -2.0170805454254150e+00
    phi[6,5]  R2152     -0.543626070022583
    phi[6,5]  R2153     5.3729015588760376e-01
    phi[6,5]  R2154     -7.5084561109542847e-01
    phi[6,5]  R2155     -1.9941475391387939e+00
    phi[6,5]  R2156     -2.2276562452316284e-01
    phi[6,5]  R2157     -3.6721739768981934e+00
    phi[6,5]  R2158     -4.1953749656677246e+00
    phi[6,5]  R2159     -3.0330622196197510e+00
    phi[6,5]  R2160     -1.5494794845581055e+00
    phi[6,5]  R2161     -2.7240601181983948e-01
    phi[6,5]  R2162     -1.2311660051345825e+00
    phi[6,5]  R2163     -1.9987718760967255e-01
    phi[6,5]  R2164     -1.0165917873382568e+00
    phi[6,5]  R2165     -1.2333720922470093e-02
    phi[6,5]  R2166     -1.8869051933288574e+00
    phi[6,5]  R2167     -2.6290321350097656e+00
    phi[6,5]  R2168     -6.8977195024490356e-01
    phi[6,5]  R2169     -1.0673456192016602e+00
    phi[6,5]  R2170     -1.1832598447799683e+00
    phi[6,5]  R2171     -6.7660528421401978e-01
    phi[6,5]  R2172     2.8066933155059814e-01
    phi[6,5]  R2173     -8.3757573366165161e-01
    phi[6,5]  R2174     3.1437245011329651e-01
    phi[6,5]  R2175     -1.7640326023101807e+00
    phi[6,5]  R2176     -1.7597335577011108e-01
    phi[6,5]  R2177     -8.1570214033126831e-01
    phi[6,5]  R2178     -1.4162975549697876e+00
    phi[6,5]  R2179     -1.4853594303131104e+00
    phi[6,5]  R2180     -2.5981919765472412e+00
    phi[6,5]  R2181     5.5796223878860474e-01
    phi[6,5]  R2182     -1.5960524082183838e+00
    phi[6,5]  R2183     -3.2067394256591797e-01
    phi[6,5]  R2184     -2.2537949085235596e+00
    phi[6,5]  R2185     3.2479326725006104e+00
    phi[6,5]  R2186     1.6247555017471313e+00
    phi[6,5]  R2187     3.3914930820465088e+00
    phi[6,5]  R2188     3.0739970207214355e+00
    phi[6,5]  R2189     3.7849428653717041e+00
    phi[6,5]  R2190     2.4234609603881836e+00
    phi[6,5]  R2191     -1.7760206013917923e-02
    phi[6,5]  R2192     -1.0389789342880249e+00
    phi[6,5]  R2193     -2.7524518966674805e+00
    phi[6,5]  R2194     -2.1403837203979492e+00
    phi[6,5]  R2195     2.1624360978603363e-01
    phi[6,5]  R2196     -1.3960171937942505e+00
    phi[6,5]  R2197     -1.8711503744125366e+00
    phi[6,5]  R2198     -1.1130977869033813e+00
    phi[6,5]  R2199     -2.0367376804351807e+00
    phi[6,5]  R2200     -2.2653191089630127e+00
    phi[6,5]  R2201     -1.81752610206604
    phi[6,5]  R2202     -1.9954869747161865e+00
    phi[6,5]  R2203     -2.0656652450561523e+00
    phi[6,5]  R2204     -2.3404552936553955e+00
    phi[6,5]  R2205     -1.8564933538436890e+00
    phi[6,5]  R2206     -1.3937898874282837e+00
    phi[6,5]  R2207     -3.3122777938842773e+00
    phi[6,5]  R2208     -2.8184773921966553e+00
    phi[6,5]  R2209     -1.7431690692901611e+00
    phi[6,5]  R2210     -8.6689352989196777e-01
    phi[6,5]  R2211     -2.0262813568115234e+00
    phi[6,5]  R2212     -2.0563969612121582e+00
    phi[6,5]  R2213     2.5259044766426086e-01
    phi[6,5]  R2214     -0.625604510307312
    phi[6,5]  R2215     -4.2457967996597290e-01
    phi[6,5]  R2216     -2.1121010780334473e+00
    phi[6,5]  R2217     -4.6376881599426270e+00
    phi[6,5]  R2218     -3.1730980873107910e+00
    phi[6,5]  R2219     -1.5191409587860107e+00
    phi[6,5]  R2220     -3.0325779914855957e+00
    phi[6,5]  R2221     -1.0819907486438751e-01
    phi[6,5]  R2222     -6.5798111259937286e-02
    phi[6,5]  R2223     5.5893272161483765e-02
    phi[6,5]  R2224     1.8404124975204468e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2225     -3.0999999046325684e+00
    phi[6,7]  R2226     -3.0999999046325684e+00
    phi[6,7]  R2227     -2.2400000095367432e+00
    phi[6,7]  R2228     -2.2400000095367432e+00
    phi[6,7]  R2229     -3.0999999046325684e+00
    phi[6,7]  R2230     -3.0999999046325684e+00
    phi[6,7]  R2231     -2.5699999332427979e+00
    phi[6,7]  R2232     -2.5699999332427979e+00
    phi[6,7]  R2233     -3.0999999046325684e+00
    phi[6,7]  R2234     -3.0999999046325684e+00
    phi[6,7]  R2235     -2.0899999141693115e+00
    phi[6,7]  R2236     -2.0899999141693115e+00
    phi[6,7]  R2237     -3.0999999046325684e+00
    phi[6,7]  R2238     -3.0999999046325684e+00
    phi[6,7]  R2239     1.8038105964660645e+00
    phi[6,7]  R2240     2.0212562084198
    phi[6,7]  R2241     2.2199401855468750e+00
    phi[6,7]  R2242     1.8166892528533936e+00
    phi[6,7]  R2243     1.3593620061874390e+00
    phi[6,7]  R2244     2.4568644165992737e-01
    phi[6,7]  R2245     5.2529424428939819e-01
    phi[6,7]  R2246     1.0967795848846436e+00
    phi[6,7]  R2247     1.2748793363571167e+00
    phi[6,7]  R2248     -2.2362039089202881e+00
    phi[6,7]  R2249     -9.8868167400360107e-01
    phi[6,7]  R2250     -7.6130986213684082e-01
    phi[6,7]  R2251     -2.1482448577880859e+00
    phi[6,7]  R2252     -1.1539065837860107e+00
    phi[6,7]  R2253     -1.6417894363403320e+00
    phi[6,7]  R2254     -2.8224108219146729e+00
    phi[6,7]  R2255     -1.8637168407440186e-01
    phi[6,7]  R2256     -2.1704065799713135e-01
    phi[6,7]  R2257     5.3738448768854141e-03
    phi[6,7]  R2258     1.3588632643222809e-01
    phi[6,7]  R2259     -2.0460567474365234e+00
    phi[6,7]  R2260     -8.2387423515319824e-01
    phi[6,7]  R2261     -1.7387566566467285e+00
    phi[6,7]  R2262     -2.5483138561248779e+00
    phi[6,7]  R2263     -1.9092139005661011e+00
    phi[6,7]  R2264     -2.5550856590270996e+00
    phi[6,7]  R2265     -9.8190808296203613e-01
    phi[6,7]  R2266     -1.6184545755386353e+00
    phi[6,7]  R2267     -2.6678955554962158e+00
    phi[6,7]  R2268     -3.1588549613952637e+00
    phi[6,7]  R2269     -1.5635890960693359e+00
    phi[6,7]  R2270     -1.2759013175964355e+00
    phi[6,7]  R2271     -1.0144550800323486e+00
    phi[6,7]  R2272     -1.4135593175888062e+00
    phi[6,7]  R2273     -2.5997298955917358e-01
    phi[6,7]  R2274     -1.5232124924659729e-01
    phi[6,7]  R2275     -1.2059509754180908e+00
    phi[6,7]  R2276     -0.713696300983429
    phi[6,7]  R2277     -1.6927288770675659e+00
    phi[6,7]  R2278     -2.0090565681457520e+00
    phi[6,7]  R2279     -6.8751549720764160e-01
    phi[6,7]  R2280     -1.5216176509857178e+00
    phi[6,7]  R2281     -1.9370281696319580e+00
    phi[6,7]  R2282     -1.2172225713729858e+00
    phi[6,7]  R2283     -1.3048487901687622e-01
    phi[6,7]  R2284     -3.3392570018768311e+00
    phi[6,7]  R2285     -3.4945511817932129e+00
    phi[6,7]  R2286     -4.1890792846679688e+00
    phi[6,7]  R2287     -0.908643364906311
    phi[6,7]  R2288     -7.3544424772262573e-01
    phi[6,7]  R2289     -1.9967169761657715e+00
    phi[6,7]  R2290     -1.0128711909055710e-01
    phi[6,7]  R2291     -2.4434425830841064e+00
    phi[6,7]  R2292     -2.03611159324646
    phi[6,7]  R2293     -2.2333424091339111e+00
    phi[6,7]  R2294     -4.1757197380065918e+00
    phi[6,7]  R2295     -2.0170805454254150e+00
    phi[6,7]  R2296     -0.543626070022583
    phi[6,7]  R2297     5.3729015588760376e-01
    phi[6,7]  R2298     -7.5084561109542847e-01
    phi[6,7]  R2299     -1.9941475391387939e+00
    phi[6,7]  R2300     -2.2276562452316284e-01
    phi[6,7]  R2301     -3.6721739768981934e+00
    phi[6,7]  R2302     -4.1953749656677246e+00
    phi[6,7]  R2303     -3.0330622196197510e+00
    phi[6,7]  R2304     -1.5494794845581055e+00
    phi[6,7]  R2305     -2.7240601181983948e-01
    phi[6,7]  R2306     -1.2311660051345825e+00
    phi[6,7]  R2307     -1.9987718760967255e-01
    phi[6,7]  R2308     -1.0165917873382568e+00
    phi[6,7]  R2309     -1.2333720922470093e-02
    phi[6,7]  R2310     -1.8869051933288574e+00
    phi[6,7]  R2311     -2.6290321350097656e+00
    phi[6,7]  R2312     -6.8977195024490356e-01
    phi[6,7]  R2313     -1.0673456192016602e+00
    phi[6,7]  R2314     -1.1832598447799683e+00
    phi[6,7]  R2315     -6.7660528421401978e-01
    phi[6,7]  R2316     2.8066933155059814e-01
    phi[6,7]  R2317     -8.3757573366165161e-01
    phi[6,7]  R2318     3.1437245011329651e-01
    phi[6,7]  R2319     -1.7640326023101807e+00
    phi[6,7]  R2320     -1.7597335577011108e-01
    phi[6,7]  R2321     -8.1570214033126831e-01
    phi[6,7]  R2322     -1.4162975549697876e+00
    phi[6,7]  R2323     -1.4853594303131104e+00
    phi[6,7]  R2324     -2.5981919765472412e+00
    phi[6,7]  R2325     5.5796223878860474e-01
    phi[6,7]  R2326     -1.5960524082183838e+00
    phi[6,7]  R2327     -3.2067394256591797e-01
    phi[6,7]  R2328     -2.2537949085235596e+00
    phi[6,7]  R2329     2.0150413513183594e+00
    phi[6,7]  R2330     1.4968860149383545e+00
    phi[6,7]  R2331     -2.8438096046447754e+00
    phi[6,7]  R2332     1.0826414078474045e-01
    phi[6,7]  R2333     1.7752689123153687e-01
    phi[6,7]  R2334     4.3617266416549683e-01
    phi[6,7]  R2335     4.0436872839927673e-01
    phi[6,7]  R2336     -3.7800329923629761e-01
    phi[6,7]  R2337     8.4761154651641846e-01
    phi[6,7]  R2338     0.651405394077301
    phi[6,7]  R2339     -4.4037094712257385e-01
    phi[6,7]  R2340     -1.4560825824737549e+00
    phi[6,7]  R2341     -1.7932511568069458e+00
    phi[6,7]  R2342     -1.7454859018325806e+00
    phi[6,7]  R2343     -1.5633412599563599e+00
    phi[6,7]  R2344     -3.8430997729301453e-01
    phi[6,7]  R2345     -2.6706447601318359e+00
    phi[6,7]  R2346     -4.6246060729026794e-01
    phi[6,7]  R2347     -3.06062912940979
    phi[6,7]  R2348     -1.2439155578613281e+00
    phi[6,7]  R2349     -6.3279181718826294e-01
    phi[6,7]  R2350     5.9808656573295593e-02
    phi[6,7]  R2351     -1.6550880670547485e+00
    phi[6,7]  R2352     1.7244294285774231e-01
    phi[6,7]  R2353     1.1380119323730469e+00
    phi[6,7]  R2354     -8.9563065767288208e-01
    phi[6,7]  R2355     -1.9534405469894409e+00
    phi[6,7]  R2356     -3.6958918571472168e+00
    phi[6,7]  R2357     -1.7569239437580109e-01
    phi[6,7]  R2358     1.0592563152313232e+00
    phi[6,7]  R2359     0.43216472864151
    phi[6,7]  R2360     8.5986185073852539e-01
    phi[6,7]  R2361     -7.9572558403015137e-01
    phi[6,7]  R2362     -1.6109818220138550e+00
    phi[6,7]  R2363     -1.7519693374633789e+00
    phi[6,7]  R2364     -3.6704263091087341e-01
    phi[6,7]  R2365     -1.2753430604934692e+00
    phi[6,7]  R2366     0.68264240026474
    phi[6,7]  R2367     2.3619375228881836e+00
    phi[6,7]  R2368     -1.00785231590271
    phi[6,7]  R2369     1.6111788749694824e+00
    phi[6,7]  R2370     -2.7809832096099854e+00
    phi[6,7]  R2371     -2.3177402019500732e+00
    phi[6,7]  R2372     -5.4667842388153076e-01
    phi[6,7]  R2373     2.1975574493408203e+00
    phi[6,7]  R2374     -2.4117450416088104e-01
    phi[6,7]  R2375     -1.9167350530624390e+00
    phi[6,7]  R2376     -2.27809739112854
    phi[6,7]  R2377     1.4740236103534698e-01
    phi[6,7]  R2378     -1.9550332427024841e-01
    phi[6,7]  R2379     1.7372554540634155e+00
    phi[6,7]  R2380     1.1902285814285278e+00
    phi[6,7]  R2381     -2.0217165946960449e+00
    phi[6,7]  R2382     -6.1438417434692383e-01
    phi[6,7]  R2383     -3.1733589172363281e+00
    phi[6,7]  R2384     2.4761250019073486e+00
    phi[6,7]  R2385     -1.2785010039806366e-01
    phi[6,7]  R2386     -7.3760515451431274e-01
    phi[6,7]  R2387     -5.0078493356704712e-01
    phi[6,7]  R2388     -2.7051886916160583e-01
    phi[6,7]  R2389     6.9690513610839844e-01
    phi[6,7]  R2390     1.9463976621627808e+00
    phi[6,7]  R2391     -1.0962697267532349e+00
    phi[6,7]  R2392     -2.54120135307312
    phi[6,7]  R2393     -2.1767981052398682e+00
    phi[6,7]  R2394     -1.0964717864990234e+00
    phi[6,7]  R2395     -5.0864791870117188e-01
    phi[6,7]  R2396     1.8637862801551819e-01
    phi[6,7]  R2397     4.7918297350406647e-02
    phi[6,7]  R2398     -2.8022947907447815e-01
    phi[6,7]  R2399     2.3254683613777161e-01
    phi[6,7]  R2400     -7.3991787433624268e-01
    phi[6,7]  R2401     6.7616409063339233e-01
    phi[6,7]  R2402     -4.9957323074340820e-01
    phi[6,7]  R2403     -1.3796045780181885e+00
    phi[6,7]  R2404     0.939115583896637
    phi[6,7]  R2405     -9.8183810710906982e-01
    phi[6,7]  R2406     5.6823700666427612e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2407     -3.0999999046325684e+00
    phi[7,6]  R2408     -3.0999999046325684e+00
    phi[7,6]  R2409     -2.2400000095367432e+00
    phi[7,6]  R2410     -2.2400000095367432e+00
    phi[7,6]  R2411     -3.0999999046325684e+00
    phi[7,6]  R2412     -3.0999999046325684e+00
    phi[7,6]  R2413     -2.5699999332427979e+00
    phi[7,6]  R2414     -2.5699999332427979e+00
    phi[7,6]  R2415     -3.0999999046325684e+00
    phi[7,6]  R2416     -3.0999999046325684e+00
    phi[7,6]  R2417     -2.0899999141693115e+00
    phi[7,6]  R2418     -2.0899999141693115e+00
    phi[7,6]  R2419     -3.0999999046325684e+00
    phi[7,6]  R2420     -3.0999999046325684e+00
    phi[7,6]  R2421     2.0150413513183594e+00
    phi[7,6]  R2422     1.4968860149383545e+00
    phi[7,6]  R2423     -2.8438096046447754e+00
    phi[7,6]  R2424     1.0826414078474045e-01
    phi[7,6]  R2425     1.7752689123153687e-01
    phi[7,6]  R2426     4.3617266416549683e-01
    phi[7,6]  R2427     4.0436872839927673e-01
    phi[7,6]  R2428     -3.7800329923629761e-01
    phi[7,6]  R2429     8.4761154651641846e-01
    phi[7,6]  R2430     0.651405394077301
    phi[7,6]  R2431     -4.4037094712257385e-01
    phi[7,6]  R2432     -1.4560825824737549e+00
    phi[7,6]  R2433     -1.7932511568069458e+00
    phi[7,6]  R2434     -1.7454859018325806e+00
    phi[7,6]  R2435     -1.5633412599563599e+00
    phi[7,6]  R2436     -3.8430997729301453e-01
    phi[7,6]  R2437     -2.6706447601318359e+00
    phi[7,6]  R2438     -4.6246060729026794e-01
    phi[7,6]  R2439     -3.06062912940979
    phi[7,6]  R2440     -1.2439155578613281e+00
    phi[7,6]  R2441     -6.3279181718826294e-01
    phi[7,6]  R2442     5.9808656573295593e-02
    phi[7,6]  R2443     -1.6550880670547485e+00
    phi[7,6]  R2444     1.7244294285774231e-01
    phi[7,6]  R2445     1.1380119323730469e+00
    phi[7,6]  R2446     -8.9563065767288208e-01
    phi[7,6]  R2447     -1.9534405469894409e+00
    phi[7,6]  R2448     -3.6958918571472168e+00
    phi[7,6]  R2449     -1.7569239437580109e-01
    phi[7,6]  R2450     1.0592563152313232e+00
    phi[7,6]  R2451     0.43216472864151
    phi[7,6]  R2452     8.5986185073852539e-01
    phi[7,6]  R2453     -7.9572558403015137e-01
    phi[7,6]  R2454     -1.6109818220138550e+00
    phi[7,6]  R2455     -1.7519693374633789e+00
    phi[7,6]  R2456     -3.6704263091087341e-01
    phi[7,6]  R2457     -1.2753430604934692e+00
    phi[7,6]  R2458     0.68264240026474
    phi[7,6]  R2459     2.3619375228881836e+00
    phi[7,6]  R2460     -1.00785231590271
    phi[7,6]  R2461     1.6111788749694824e+00
    phi[7,6]  R2462     -2.7809832096099854e+00
    phi[7,6]  R2463     -2.3177402019500732e+00
    phi[7,6]  R2464     -5.4667842388153076e-01
    phi[7,6]  R2465     2.1975574493408203e+00
    phi[7,6]  R2466     -2.4117450416088104e-01
    phi[7,6]  R2467     -1.9167350530624390e+00
    phi[7,6]  R2468     -2.27809739112854
    phi[7,6]  R2469     1.4740236103534698e-01
    phi[7,6]  R2470     -1.9550332427024841e-01
    phi[7,6]  R2471     1.7372554540634155e+00
    phi[7,6]  R2472     1.1902285814285278e+00
    phi[7,6]  R2473     -2.0217165946960449e+00
    phi[7,6]  R2474     -6.1438417434692383e-01
    phi[7,6]  R2475     -3.1733589172363281e+00
    phi[7,6]  R2476     2.4761250019073486e+00
    phi[7,6]  R2477     -1.2785010039806366e-01
    phi[7,6]  R2478     -7.3760515451431274e-01
    phi[7,6]  R2479     -5.0078493356704712e-01
    phi[7,6]  R2480     -2.7051886916160583e-01
    phi[7,6]  R2481     6.9690513610839844e-01
    phi[7,6]  R2482     1.9463976621627808e+00
    phi[7,6]  R2483     -1.0962697267532349e+00
    phi[7,6]  R2484     -2.54120135307312
    phi[7,6]  R2485     -2.1767981052398682e+00
    phi[7,6]  R2486     -1.0964717864990234e+00
    phi[7,6]  R2487     -5.0864791870117188e-01
    phi[7,6]  R2488     1.8637862801551819e-01
    phi[7,6]  R2489     4.7918297350406647e-02
    phi[7,6]  R2490     -2.8022947907447815e-01
    phi[7,6]  R2491     2.3254683613777161e-01
    phi[7,6]  R2492     -7.3991787433624268e-01
    phi[7,6]  R2493     6.7616409063339233e-01
    phi[7,6]  R2494     -4.9957323074340820e-01
    phi[7,6]  R2495     -1.3796045780181885e+00
    phi[7,6]  R2496     0.939115583896637
    phi[7,6]  R2497     -9.8183810710906982e-01
    phi[7,6]  R2498     5.6823700666427612e-01
    phi[7,6]  R2499     1.8038105964660645e+00
    phi[7,6]  R2500     2.0212562084198
    phi[7,6]  R2501     2.2199401855468750e+00
    phi[7,6]  R2502     1.8166892528533936e+00
    phi[7,6]  R2503     1.3593620061874390e+00
    phi[7,6]  R2504     2.4568644165992737e-01
    phi[7,6]  R2505     5.2529424428939819e-01
    phi[7,6]  R2506     1.0967795848846436e+00
    phi[7,6]  R2507     1.2748793363571167e+00
    phi[7,6]  R2508     -2.2362039089202881e+00
    phi[7,6]  R2509     -9.8868167400360107e-01
    phi[7,6]  R2510     -7.6130986213684082e-01
    phi[7,6]  R2511     -2.1482448577880859e+00
    phi[7,6]  R2512     -1.1539065837860107e+00
    phi[7,6]  R2513     -1.6417894363403320e+00
    phi[7,6]  R2514     -2.8224108219146729e+00
    phi[7,6]  R2515     -1.8637168407440186e-01
    phi[7,6]  R2516     -2.1704065799713135e-01
    phi[7,6]  R2517     5.3738448768854141e-03
    phi[7,6]  R2518     1.3588632643222809e-01
    phi[7,6]  R2519     -2.0460567474365234e+00
    phi[7,6]  R2520     -8.2387423515319824e-01
    phi[7,6]  R2521     -1.7387566566467285e+00
    phi[7,6]  R2522     -2.5483138561248779e+00
    phi[7,6]  R2523     -1.9092139005661011e+00
    phi[7,6]  R2524     -2.5550856590270996e+00
    phi[7,6]  R2525     -9.8190808296203613e-01
    phi[7,6]  R2526     -1.6184545755386353e+00
    phi[7,6]  R2527     -2.6678955554962158e+00
    phi[7,6]  R2528     -3.1588549613952637e+00
    phi[7,6]  R2529     -1.5635890960693359e+00
    phi[7,6]  R2530     -1.2759013175964355e+00
    phi[7,6]  R2531     -1.0144550800323486e+00
    phi[7,6]  R2532     -1.4135593175888062e+00
    phi[7,6]  R2533     -2.5997298955917358e-01
    phi[7,6]  R2534     -1.5232124924659729e-01
    phi[7,6]  R2535     -1.2059509754180908e+00
    phi[7,6]  R2536     -0.713696300983429
    phi[7,6]  R2537     -1.6927288770675659e+00
    phi[7,6]  R2538     -2.0090565681457520e+00
    phi[7,6]  R2539     -6.8751549720764160e-01
    phi[7,6]  R2540     -1.5216176509857178e+00
    phi[7,6]  R2541     -1.9370281696319580e+00
    phi[7,6]  R2542     -1.2172225713729858e+00
    phi[7,6]  R2543     -1.3048487901687622e-01
    phi[7,6]  R2544     -3.3392570018768311e+00
    phi[7,6]  R2545     -3.4945511817932129e+00
    phi[7,6]  R2546     -4.1890792846679688e+00
    phi[7,6]  R2547     -0.908643364906311
    phi[7,6]  R2548     -7.3544424772262573e-01
    phi[7,6]  R2549     -1.9967169761657715e+00
    phi[7,6]  R2550     -1.0128711909055710e-01
    phi[7,6]  R2551     -2.4434425830841064e+00
    phi[7,6]  R2552     -2.03611159324646
    phi[7,6]  R2553     -2.2333424091339111e+00
    phi[7,6]  R2554     -4.1757197380065918e+00
    phi[7,6]  R2555     -2.0170805454254150e+00
    phi[7,6]  R2556     -0.543626070022583
    phi[7,6]  R2557     5.3729015588760376e-01
    phi[7,6]  R2558     -7.5084561109542847e-01
    phi[7,6]  R2559     -1.9941475391387939e+00
    phi[7,6]  R2560     -2.2276562452316284e-01
    phi[7,6]  R2561     -3.6721739768981934e+00
    phi[7,6]  R2562     -4.1953749656677246e+00
    phi[7,6]  R2563     -3.0330622196197510e+00
    phi[7,6]  R2564     -1.5494794845581055e+00
    phi[7,6]  R2565     -2.7240601181983948e-01
    phi[7,6]  R2566     -1.2311660051345825e+00
    phi[7,6]  R2567     -1.9987718760967255e-01
    phi[7,6]  R2568     -1.0165917873382568e+00
    phi[7,6]  R2569     -1.2333720922470093e-02
    phi[7,6]  R2570     -1.8869051933288574e+00
    phi[7,6]  R2571     -2.6290321350097656e+00
    phi[7,6]  R2572     -6.8977195024490356e-01
    phi[7,6]  R2573     -1.0673456192016602e+00
    phi[7,6]  R2574     -1.1832598447799683e+00
    phi[7,6]  R2575     -6.7660528421401978e-01
    phi[7,6]  R2576     2.8066933155059814e-01
    phi[7,6]  R2577     -8.3757573366165161e-01
    phi[7,6]  R2578     3.1437245011329651e-01
    phi[7,6]  R2579     -1.7640326023101807e+00
    phi[7,6]  R2580     -1.7597335577011108e-01
    phi[7,6]  R2581     -8.1570214033126831e-01
    phi[7,6]  R2582     -1.4162975549697876e+00
    phi[7,6]  R2583     -1.4853594303131104e+00
    phi[7,6]  R2584     -2.5981919765472412e+00
    phi[7,6]  R2585     5.5796223878860474e-01
    phi[7,6]  R2586     -1.5960524082183838e+00
    phi[7,6]  R2587     -3.2067394256591797e-01
    phi[7,6]  R2588     -2.2537949085235596e+00
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       -2.5128214674305025e+00
    phi[7,9]  R66       1.71553783194945
    phi[7,9]  R67       -1.2953827123674704e+00
    phi[7,9]  R68       -1.9660003644834090e-01
    phi[7,9]  R69       -5.2692172127935244e-01
    phi[7,9]  R70       1.8262669626668846e+00
    phi[7,9]  R71       -1.1980901301459501e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2589     -5.61282137206307
    phi[7,9]  R2590     -5.8717843720206586e-01
    phi[7,9]  R2591     -5.2446217758729308e-01
    phi[7,9]  R2592     -3.9555378414861933e+00
    phi[7,9]  R2593     -4.3953826170000383e+00
    phi[7,9]  R2594     -1.8046171922650980e+00
    phi[7,9]  R2595     -2.7665999696911387e+00
    phi[7,9]  R2596     -2.3733998967944570e+00
    phi[7,9]  R2597     -3.6269216259119208e+00
    phi[7,9]  R2598     -2.5730781833532159e+00
    phi[7,9]  R2599     -2.6373295150242693e-01
    phi[7,9]  R2600     -3.9162668768361959e+00
    phi[7,9]  R2601     -4.2980900347785180e+00
    phi[7,9]  R2602     -1.9019097744866182e+00
    phi[7,9]  R2603     -2.1266303266233066e-01
    phi[7,9]  R2604     -2.5719918371942541e-01
    phi[7,9]  R2605     -2.5736437058794071e-01
    phi[7,9]  R2606     -4.5678821644646650e-01
    phi[7,9]  R2607     -5.0154428042587618e-01
    phi[7,9]  R2608     -5.1400022307435822e-01
    phi[7,9]  R2609     -5.3535391762288453e-01
    phi[7,9]  R2610     -5.5846081039697082e-01
    phi[7,9]  R2611     -5.9613758327822319e-01
    phi[7,9]  R2612     -6.1564840484223571e-01
    phi[7,9]  R2613     -2.5107662720352342e-01
    phi[7,9]  R2614     -2.6763506627148104e-01
    phi[7,9]  R2615     -3.1159342781342714e-01
    phi[7,9]  R2616     -3.1677955772835054e-01
    phi[7,9]  R2617     -3.3157065866638624e-01
    phi[7,9]  R2618     -3.4235811689859230e-01
    phi[7,9]  R2619     -3.4563708802975768e-01
    phi[7,9]  R2620     -3.5098573965689817e-01
    phi[7,9]  R2621     -3.5361061044854747e-01
    phi[7,9]  R2622     -3.5604677479333069e-01
    phi[7,9]  R2623     -1.9975086993263558e-01
    phi[7,9]  R2624     -2.6300209467075059e-01
    phi[7,9]  R2625     -2.8797536999342066e-01
    phi[7,9]  R2626     -3.3056659255443110e-01
    phi[7,9]  R2627     -3.3767862958514572e-01
    phi[7,9]  R2628     -3.4200110650259541e-01
    phi[7,9]  R2629     -3.4707850317552547e-01
    phi[7,9]  R2630     -3.5074007014661523e-01
    phi[7,9]  R2631     -3.6266472919993820e-01
    phi[7,9]  R2632     -4.9691028579215368e-01
    phi[7,9]  R2633     -2.6380863324686266e-01
    phi[7,9]  R2634     -3.0277706630239276e-01
    phi[7,9]  R2635     -3.0559568372940910e-01
    phi[7,9]  R2636     -3.2213942191813483e-01
    phi[7,9]  R2637     -3.2926306441870290e-01
    phi[7,9]  R2638     -3.3307098925311485e-01
    phi[7,9]  R2639     -3.3877186183555164e-01
    phi[7,9]  R2640     -3.5311160014312559e-01
    phi[7,9]  R2641     -3.5506478793232255e-01
    phi[7,9]  R2642     -3.9816395380484548e-01
    phi[7,9]  R2643     -2.0839959007154651e-01
    phi[7,9]  R2644     -2.1736110877946579e-01
    phi[7,9]  R2645     -2.4105689492628013e-01
    phi[7,9]  R2646     -2.4819891004330952e-01
    phi[7,9]  R2647     -3.1491832636617145e-01
    phi[7,9]  R2648     -3.2748752900926459e-01
    phi[7,9]  R2649     -3.7601383243236031e-01
    phi[7,9]  R2650     -3.7837621057142923e-01
    phi[7,9]  R2651     -1.2457105671824558e+00
    phi[7,9]  R2652     -1.2289539542802275e+00
    phi[7,9]  R2653     -2.3838009901457058e-01
    phi[7,9]  R2654     -0.24272038305109
    phi[7,9]  R2655     -2.5637508707304724e-01
    phi[7,9]  R2656     -2.8605438370296088e-01
    phi[7,9]  R2657     -2.9000070382925625e-01
    phi[7,9]  R2658     -2.9967567805850415e-01
    phi[7,9]  R2659     -3.5441865831569236e-01
    phi[7,9]  R2660     -3.9737402060082028e-01
    phi[7,9]  R2661     -1.0619320436638113e+00
    phi[7,9]  R2662     -6.2987199280347239e-01
    phi[7,9]  R2663     -2.0642972758030242e-01
    phi[7,9]  R2664     -2.2690144980063387e-01
    phi[7,9]  R2665     -2.4236029187918129e-01
    phi[7,9]  R2666     -2.9277958808551263e-01
    phi[7,9]  R2667     -2.9683248835778420e-01
    phi[7,9]  R2668     -3.6612920839022034e-01
    phi[7,9]  R2669     -8.6813918994747907e-01
    phi[7,9]  R2670     -8.0501818735774089e-01
    phi[7,9]  R2671     -6.0754055712570376e-01
    phi[7,9]  R2672     -6.3997371003388870e-01
    phi[7,9]  R2673     -1.9225151268256868e-01
    phi[7,9]  R2674     -3.0174095059494865e-01
    phi[7,9]  R2675     -1.4281236333562766e+00
    phi[7,9]  R2676     -1.6123902871271665e+00
    phi[7,9]  R2677     -2.0272712853884434e+00
    phi[7,9]  R2678     -1.4948358929929748e+00
    phi[7,9]  R2679     -2.1069288609644241e+00
    phi[7,9]  R2680     -2.3116539011027410e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       6.3193216919898987e-02
    z[0,1,0]  R89       4.9101456999778748e-02
    z[0,1,0]  R90       -1.6371060907840729e-01
    z[0,1,0]  R91       3.8743871450424194e-01
    z[0,1,0]  R92       -1.4517836272716522e-01
    z[0,1,0]  R93       4.0826085209846497e-01
    z[0,1,0]  R94       4.9306243658065796e-01
    z[0,1,0]  R95       4.5678767561912537e-01
    z[0,1,0]  R96       4.7633597254753113e-01
    z[0,1,0]  R97       6.7837619781494141e-01
    z[0,1,0]  R98       3.7534731626510620e-01
    z[0,1,0]  R99       3.1785193830728531e-02
    z[0,1,0]  R100      0.476936012506485
    z[0,1,0]  R101      4.5526400208473206e-01
    z[0,1,0]  R102      -4.7595086693763733e-01
    z[0,1,0]  R103      -1.4402058720588684e-01
    z[0,1,0]  R104      1.4602072536945343e-01
    z[0,1,0]  R105      -8.8987782597541809e-02
    z[0,1,0]  R106      6.5973460674285889e-02
    z[0,1,0]  R107      -1.0765879601240158e-01
    z[0,1,0]  R108      1.4987038075923920e-01
    z[0,1,0]  R109      -4.1974384337663651e-02
    z[0,1,0]  R110      2.8343917801976204e-03
    z[0,1,0]  R111      -0.399278849363327
    z[0,1,0]  R112      -2.4735212326049805e-01
    z[0,1,0]  R113      -6.7140311002731323e-02
    z[0,1,0]  R114      -4.1777658462524414e-01
    z[0,1,0]  R115      6.7546620965003967e-02
    z[0,1,0]  R116      -1.3360929489135742e-01
    z[0,1,0]  R117      -5.4297035932540894e-01
    z[0,1,0]  R118      2.7373647689819336e-01
    z[0,1,0]  R119      -2.9731979966163635e-01
    z[0,1,0]  R120      1.1816011369228363e-01
    z[0,1,0]  R121      -2.8915387392044067e-01
    z[0,1,0]  R122      -2.1819458901882172e-01
    z[0,1,0]  R123      -6.5947575494647026e-03
    z[0,1,0]  R124      3.4752342104911804e-01
    z[0,1,0]  R125      -3.7871897220611572e-01
    z[0,1,0]  R126      -4.6609845757484436e-01
    z[0,1,0]  R127      -3.5970714688301086e-01
    z[0,1,0]  R128      -1.0812094062566757e-01
    z[0,1,0]  R129      -1.2537581846117973e-02
    z[0,1,0]  R130      3.5242241621017456e-01
    z[0,1,0]  R131      -6.9711968302726746e-02
    z[0,1,0]  R132      1.9990468025207520e-01
    z[0,1,0]  R133      2.8056003153324127e-02
    z[0,1,0]  R134      -0.5154989361763
    z[0,1,0]  R135      2.2655533254146576e-01
    z[0,1,0]  R136      3.1677171587944031e-01
    z[0,1,0]  R137      3.0139264464378357e-01
    z[0,1,0]  R138      -3.4421378374099731e-01
    z[0,1,0]  R139      2.2422590851783752e-01
    z[0,1,0]  R140      1.9792316854000092e-01
    z[0,1,0]  R141      3.1178635358810425e-01
    z[0,1,0]  R142      -2.1497267484664917e-01
    z[0,1,0]  R143      1.9140347838401794e-01
    z[0,1,0]  R144      -2.8798022866249084e-01
    z[0,1,0]  R145      -8.8347524404525757e-02
    z[0,1,0]  R146      -7.1481841802597046e-01
    z[0,1,0]  R147      2.5166258215904236e-01
    z[0,1,0]  R148      -2.2615826129913330e-01
    z[0,1,0]  R149      -2.4861498177051544e-01
    z[0,1,0]  R150      -9.1641299426555634e-02
    z[0,1,0]  R151      4.0413862466812134e-01
    z[0,1,0]  R152      3.9909341931343079e-01
    z[0,1,0]  R153      1.1803105473518372e-01
    z[0,1,0]  R154      4.0218746662139893e-01
    z[0,1,0]  R155      4.5351126790046692e-01
    z[0,1,0]  R156      -1.5146599709987640e-01
    z[0,1,0]  R157      1.8265716731548309e-01
    z[0,1,0]  R158      -5.0401080399751663e-02
    z[0,1,0]  R159      4.2824089527130127e-01
    z[0,1,0]  R160      1.5922770835459232e-03
    z[0,1,0]  R161      7.5826868414878845e-02
    z[0,1,0]  R162      1.2530748546123505e-01
    z[0,1,0]  R163      -6.1307537555694580e-01
    z[0,1,0]  R164      -3.1183484196662903e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       8.2392197847366333e-01
    z[0,1,1]  R89       6.8016415834426880e-01
    z[0,1,1]  R90       7.7156919240951538e-01
    z[0,1,1]  R91       7.2993814945220947e-01
    z[0,1,1]  R92       5.9321910142898560e-01
    z[0,1,1]  R93       5.7834815979003906e-01
    z[0,1,1]  R94       6.2786775827407837e-01
    z[0,1,1]  R95       5.5659162998199463e-01
    z[0,1,1]  R96       -4.3671395629644394e-02
    z[0,1,1]  R97       3.2095119357109070e-02
    z[0,1,1]  R98       -4.9491804838180542e-01
    z[0,1,1]  R99       -6.5591049194335938e-01
    z[0,1,1]  R100      -0.452214777469635
    z[0,1,1]  R101      -7.0627099275588989e-01
    z[0,1,1]  R102      -5.5401831865310669e-01
    z[0,1,1]  R103      -4.3831315636634827e-01
    z[0,1,1]  R104      -5.4018628597259521e-01
    z[0,1,1]  R105      -5.2345865964889526e-01
    z[0,1,1]  R106      -8.2594347000122070e-01
    z[0,1,1]  R107      -5.3371143341064453e-01
    z[0,1,1]  R108      -8.2987940311431885e-01
    z[0,1,1]  R109      -6.1525815725326538e-01
    z[0,1,1]  R110      -7.6073414087295532e-01
    z[0,1,1]  R111      -0.863974928855896
    z[0,1,1]  R112      -8.1962603330612183e-01
    z[0,1,1]  R113      -3.3098754286766052e-01
    z[0,1,1]  R114      -7.0585000514984131e-01
    z[0,1,1]  R115      6.5138167142868042e-01
    z[0,1,1]  R116      -6.0313898324966431e-01
    z[0,1,1]  R117      -4.6534386277198792e-01
    z[0,1,1]  R118      -3.3498278260231018e-01
    z[0,1,1]  R119      8.9675587415695190e-01
    z[0,1,1]  R120      8.7505888938903809e-01
    z[0,1,1]  R121      -6.1318643391132355e-02
    z[0,1,1]  R122      6.6259676218032837e-01
    z[0,1,1]  R123      0.692440390586853
    z[0,1,1]  R124      7.0537883043289185e-01
    z[0,1,1]  R125      7.3126709461212158e-01
    z[0,1,1]  R126      -6.4546540379524231e-02
    z[0,1,1]  R127      -0.858400285243988
    z[0,1,1]  R128      -0.876112699508667
    z[0,1,1]  R129      -8.0603712797164917e-01
    z[0,1,1]  R130      -7.7500116825103760e-01
    z[0,1,1]  R131      -7.7883827686309814e-01
    z[0,1,1]  R132      -6.4629852771759033e-01
    z[0,1,1]  R133      -3.9202803373336792e-01
    z[0,1,1]  R134      -7.4260437488555908e-01
    z[0,1,1]  R135      -7.1300995349884033e-01
    z[0,1,1]  R136      -7.1007263660430908e-01
    z[0,1,1]  R137      -7.9286617040634155e-01
    z[0,1,1]  R138      2.7025574445724487e-01
    z[0,1,1]  R139      8.4632793441414833e-03
    z[0,1,1]  R140      1.5935626626014709e-01
    z[0,1,1]  R141      4.2423886060714722e-01
    z[0,1,1]  R142      7.1896232664585114e-02
    z[0,1,1]  R143      -2.3277062922716141e-02
    z[0,1,1]  R144      -1.3731746375560760e-01
    z[0,1,1]  R145      -2.2696368396282196e-01
    z[0,1,1]  R146      4.0837100148200989e-01
    z[0,1,1]  R147      -8.0349564552307129e-01
    z[0,1,1]  R148      1.5217198431491852e-01
    z[0,1,1]  R149      3.4239817410707474e-02
    z[0,1,1]  R150      -6.0378062725067139e-01
    z[0,1,1]  R151      3.2040509581565857e-01
    z[0,1,1]  R152      3.1255221366882324e-01
    z[0,1,1]  R153      2.8163838386535645e-01
    z[0,1,1]  R154      -2.9545217752456665e-01
    z[0,1,1]  R155      -3.1975455582141876e-02
    z[0,1,1]  R156      1.0061888396739960e-01
    z[0,1,1]  R157      -4.9161937087774277e-02
    z[0,1,1]  R158      2.2024077177047729e-01
    z[0,1,1]  R159      -2.2849030792713165e-01
    z[0,1,1]  R160      -1.7041325569152832e-02
    z[0,1,1]  R161      -0.54848712682724
    z[0,1,1]  R162      -2.8677159547805786e-01
    z[0,1,1]  R163      5.2385908365249634e-01
    z[0,1,1]  R164      0.618018388748169
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       2.4155406281352043e-02
    z[0,1,2]  R89       5.0916379690170288e-01
    z[0,1,2]  R90       2.7194762229919434e-01
    z[0,1,2]  R91       2.7120593190193176e-01
    z[0,1,2]  R92       -0.0447147935628891
    z[0,1,2]  R93       -8.6999922990798950e-02
    z[0,1,2]  R94       2.9580566287040710e-01
    z[0,1,2]  R95       4.2334303259849548e-01
    z[0,1,2]  R96       2.2294847294688225e-02
    z[0,1,2]  R97       -8.3603955805301666e-02
    z[0,1,2]  R98       6.1550474166870117e-01
    z[0,1,2]  R99       3.8957926630973816e-01
    z[0,1,2]  R100      0.15157450735569
    z[0,1,2]  R101      2.9771193861961365e-01
    z[0,1,2]  R102      1.3639959692955017e-01
    z[0,1,2]  R103      -3.1166866421699524e-01
    z[0,1,2]  R104      1.3838428258895874e-01
    z[0,1,2]  R105      -6.9160008430480957e-01
    z[0,1,2]  R106      -1.3008992373943329e-01
    z[0,1,2]  R107      4.6579241752624512e-01
    z[0,1,2]  R108      1.8765021860599518e-01
    z[0,1,2]  R109      -3.0872235074639320e-02
    z[0,1,2]  R110      -3.5853850841522217e-01
    z[0,1,2]  R111      -1.5256865322589874e-01
    z[0,1,2]  R112      -2.3540411889553070e-01
    z[0,1,2]  R113      6.5041255950927734e-01
    z[0,1,2]  R114      -2.5383287668228149e-01
    z[0,1,2]  R115      -5.7006269693374634e-01
    z[0,1,2]  R116      -1.8810448050498962e-01
    z[0,1,2]  R117      5.6214940547943115e-01
    z[0,1,2]  R118      7.7378839254379272e-01
    z[0,1,2]  R119      1.0274402797222137e-01
    z[0,1,2]  R120      2.4186423420906067e-01
    z[0,1,2]  R121      7.5274819135665894e-01
    z[0,1,2]  R122      4.1259959340095520e-02
    z[0,1,2]  R123      0.307152658700943
    z[0,1,2]  R124      2.2188268601894379e-02
    z[0,1,2]  R125      1.6515260562300682e-02
    z[0,1,2]  R126      1.7743951082229614e-01
    z[0,1,2]  R127      4.5016493648290634e-02
    z[0,1,2]  R128      -1.2014707922935486e-01
    z[0,1,2]  R129      -2.7345892786979675e-01
    z[0,1,2]  R130      -1.5424926578998566e-01
    z[0,1,2]  R131      -2.4860759079456329e-01
    z[0,1,2]  R132      -1.7490682005882263e-01
    z[0,1,2]  R133      -7.5999490916728973e-02
    z[0,1,2]  R134      -2.2708848118782043e-01
    z[0,1,2]  R135      2.1298274397850037e-02
    z[0,1,2]  R136      -0.270439088344574
    z[0,1,2]  R137      1.4696128666400909e-01
    z[0,1,2]  R138      1.8496122956275940e-01
    z[0,1,2]  R139      2.1626810729503632e-01
    z[0,1,2]  R140      -0.299159973859787
    z[0,1,2]  R141      1.9976884126663208e-02
    z[0,1,2]  R142      5.4376077651977539e-01
    z[0,1,2]  R143      0.306511789560318
    z[0,1,2]  R144      3.1260961294174194e-01
    z[0,1,2]  R145      5.8296412229537964e-02
    z[0,1,2]  R146      -2.2257991135120392e-01
    z[0,1,2]  R147      1.4338243007659912e-01
    z[0,1,2]  R148      -6.4063794910907745e-02
    z[0,1,2]  R149      2.4304716289043427e-01
    z[0,1,2]  R150      4.9997827410697937e-01
    z[0,1,2]  R151      3.6259759217500687e-02
    z[0,1,2]  R152      -3.6870157718658447e-01
    z[0,1,2]  R153      5.1369881629943848e-01
    z[0,1,2]  R154      1.7250214517116547e-01
    z[0,1,2]  R155      2.9760643839836121e-01
    z[0,1,2]  R156      -3.1268224120140076e-01
    z[0,1,2]  R157      -1.5565671026706696e-01
    z[0,1,2]  R158      1.4295632019639015e-02
    z[0,1,2]  R159      -1.7127253115177155e-02
    z[0,1,2]  R160      -3.6432725191116333e-01
    z[0,1,2]  R161      -1.4075274765491486e-01
    z[0,1,2]  R162      -3.3891963958740234e-01
    z[0,1,2]  R163      -0.280981183052063
    z[0,1,2]  R164      1.2004150450229645e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       -0.0815090611577034
    z[0,1,3]  R89       -5.7429186999797821e-02
    z[0,1,3]  R90       -1.7642995342612267e-02
    z[0,1,3]  R91       -0.0578574538230896
    z[0,1,3]  R92       8.0894403159618378e-02
    z[0,1,3]  R93       -1.4554880559444427e-01
    z[0,1,3]  R94       3.9082306623458862e-01
    z[0,1,3]  R95       3.0799075961112976e-01
    z[0,1,3]  R96       8.3900749683380127e-01
    z[0,1,3]  R97       7.1428561210632324e-01
    z[0,1,3]  R98       1.5387716889381409e-01
    z[0,1,3]  R99       -5.2593696117401123e-01
    z[0,1,3]  R100      -2.1382157504558563e-01
    z[0,1,3]  R101      4.8487573862075806e-02
    z[0,1,3]  R102      -4.1771572828292847e-01
    z[0,1,3]  R103      -5.1616907119750977e-01
    z[0,1,3]  R104      -3.9053648710250854e-01
    z[0,1,3]  R105      4.4514226913452148e-01
    z[0,1,3]  R106      3.9098021388053894e-01
    z[0,1,3]  R107      3.1502255797386169e-01
    z[0,1,3]  R108      2.0046825706958771e-01
    z[0,1,3]  R109      4.6570390462875366e-01
    z[0,1,3]  R110      -0.22982257604599
    z[0,1,3]  R111      -1.3328652083873749e-01
    z[0,1,3]  R112      3.6576956510543823e-02
    z[0,1,3]  R113      -2.6202449202537537e-01
    z[0,1,3]  R114      -1.2374115735292435e-01
    z[0,1,3]  R115      -0.0840914323925972
    z[0,1,3]  R116      1.5043315291404724e-01
    z[0,1,3]  R117      2.9802948236465454e-01
    z[0,1,3]  R118      3.8225373625755310e-01
    z[0,1,3]  R119      -3.9157648570835590e-03
    z[0,1,3]  R120      3.4162499941885471e-03
    z[0,1,3]  R121      5.1377767324447632e-01
    z[0,1,3]  R122      -4.1259959340095520e-02
    z[0,1,3]  R123      -1.7851822078227997e-01
    z[0,1,3]  R124      2.2214195132255554e-01
    z[0,1,3]  R125      -8.9437246322631836e-02
    z[0,1,3]  R126      5.8046829700469971e-01
    z[0,1,3]  R127      -3.0088746547698975e-01
    z[0,1,3]  R128      -1.5492798388004303e-01
    z[0,1,3]  R129      6.3656136393547058e-02
    z[0,1,3]  R130      -2.5527718663215637e-01
    z[0,1,3]  R131      4.5975369215011597e-01
    z[0,1,3]  R132      1.4882178604602814e-01
    z[0,1,3]  R133      2.5903906673192978e-02
    z[0,1,3]  R134      2.0706845819950104e-01
    z[0,1,3]  R135      1.3117501139640808e-01
    z[0,1,3]  R136      -3.1659743189811707e-01
    z[0,1,3]  R137      -3.2407918572425842e-01
    z[0,1,3]  R138      -6.2176507711410522e-01
    z[0,1,3]  R139      -5.0077027082443237e-01
    z[0,1,3]  R140      -5.9560501575469971e-01
    z[0,1,3]  R141      -5.1182800531387329e-01
    z[0,1,3]  R142      -4.4937032461166382e-01
    z[0,1,3]  R143      -4.1226205229759216e-01
    z[0,1,3]  R144      -5.3184306621551514e-01
    z[0,1,3]  R145      -3.8543307781219482e-01
    z[0,1,3]  R146      1.0902522504329681e-01
    z[0,1,3]  R147      -4.0261375904083252e-01
    z[0,1,3]  R148      -6.8117129802703857e-01
    z[0,1,3]  R149      -8.1062769889831543e-01
    z[0,1,3]  R150      -2.4668163061141968e-01
    z[0,1,3]  R151      -5.5053102970123291e-01
    z[0,1,3]  R152      -5.8346831798553467e-01
    z[0,1,3]  R153      -5.0937640666961670e-01
    z[0,1,3]  R154      -5.2619791030883789e-01
    z[0,1,3]  R155      -5.8378511667251587e-01
    z[0,1,3]  R156      0.871620774269104
    z[0,1,3]  R157      -6.9143766164779663e-01
    z[0,1,3]  R158      3.3501684665679932e-01
    z[0,1,3]  R159      -5.4444384574890137e-01
    z[0,1,3]  R160      -6.1271136999130249e-01
    z[0,1,3]  R161      1.0101101547479630e-01
    z[0,1,3]  R162      4.2658537626266479e-01
    z[0,1,3]  R163      3.9055773522704840e-03
    z[0,1,3]  R164      -2.2685249149799347e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       -3.5928165912628174e-01
    z[0,1,4]  R89       -1.5359874069690704e-01
    z[0,1,4]  R90       6.9122023880481720e-02
    z[0,1,4]  R91       -0.476299911737442
    z[0,1,4]  R92       5.7867527008056641e-01
    z[0,1,4]  R93       -1.3218839466571808e-01
    z[0,1,4]  R94       3.1100383400917053e-01
    z[0,1,4]  R95       3.9548650383949280e-01
    z[0,1,4]  R96       1.7993319034576416e-01
    z[0,1,4]  R97       -0.139604389667511
    z[0,1,4]  R98       -2.9799956083297729e-01
    z[0,1,4]  R99       -2.6043140888214111e-01
    z[0,1,4]  R100      -3.6377736926078796e-01
    z[0,1,4]  R101      -2.3236876353621483e-02
    z[0,1,4]  R102      -9.0952344238758087e-02
    z[0,1,4]  R103      -1.6560812294483185e-01
    z[0,1,4]  R104      2.5459712743759155e-01
    z[0,1,4]  R105      -1.6350033879280090e-01
    z[0,1,4]  R106      -1.6215749084949493e-01
    z[0,1,4]  R107      5.4695618152618408e-01
    z[0,1,4]  R108      6.3911923207342625e-03
    z[0,1,4]  R109      6.2209874391555786e-01
    z[0,1,4]  R110      -3.3168774843215942e-01
    z[0,1,4]  R111      -2.6557940989732742e-02
    z[0,1,4]  R112      3.8847821950912476e-01
    z[0,1,4]  R113      4.2505535483360291e-01
    z[0,1,4]  R114      -2.9733118414878845e-01
    z[0,1,4]  R115      -1.2829910218715668e-01
    z[0,1,4]  R116      -5.4046303033828735e-01
    z[0,1,4]  R117      -1.3540554046630859e-01
    z[0,1,4]  R118      -1.4558282494544983e-01
    z[0,1,4]  R119      0.163810133934021
    z[0,1,4]  R120      -4.0570143610239029e-03
    z[0,1,4]  R121      1.6149160265922546e-01
    z[0,1,4]  R122      -2.0794370770454407e-01
    z[0,1,4]  R123      -4.6127480268478394e-01
    z[0,1,4]  R124      -2.1602858603000641e-01
    z[0,1,4]  R125      -4.1730195283889771e-01
    z[0,1,4]  R126      2.8576115146279335e-02
    z[0,1,4]  R127      -7.9619465395808220e-03
    z[0,1,4]  R128      -3.2067483663558960e-01
    z[0,1,4]  R129      4.8926392197608948e-01
    z[0,1,4]  R130      1.0910187661647797e-01
    z[0,1,4]  R131      -1.6284523904323578e-01
    z[0,1,4]  R132      5.8057814836502075e-01
    z[0,1,4]  R133      7.0143383741378784e-01
    z[0,1,4]  R134      1.6695725917816162e-01
    z[0,1,4]  R135      1.5419793128967285e-01
    z[0,1,4]  R136      -1.5438987314701080e-01
    z[0,1,4]  R137      2.3761963844299316e-01
    z[0,1,4]  R138      -4.1758334636688232e-01
    z[0,1,4]  R139      -6.3946652412414551e-01
    z[0,1,4]  R140      -0.51181960105896
    z[0,1,4]  R141      -6.6047418117523193e-01
    z[0,1,4]  R142      -0.664966881275177
    z[0,1,4]  R143      -5.8735400438308716e-01
    z[0,1,4]  R144      -0.590451717376709
    z[0,1,4]  R145      -0.0902474895119667
    z[0,1,4]  R146      4.6288406848907471e-01
    z[0,1,4]  R147      3.0597427487373352e-01
    z[0,1,4]  R148      -5.7819157838821411e-01
    z[0,1,4]  R149      -3.3972835540771484e-01
    z[0,1,4]  R150      1.6309560835361481e-01
    z[0,1,4]  R151      -5.4928815364837646e-01
    z[0,1,4]  R152      -3.8938489556312561e-01
    z[0,1,4]  R153      -4.7194615006446838e-01
    z[0,1,4]  R154      -4.4284597039222717e-01
    z[0,1,4]  R155      -4.9810793995857239e-01
    z[0,1,4]  R156      6.9485092535614967e-03
    z[0,1,4]  R157      -1.9424900412559509e-01
    z[0,1,4]  R158      1.0263490676879883e-01
    z[0,1,4]  R159      -4.7431486845016479e-01
    z[0,1,4]  R160      -5.9538251161575317e-01
    z[0,1,4]  R161      2.4018044769763947e-01
    z[0,1,4]  R162      -7.2686426341533661e-02
    z[0,1,4]  R163      3.9153233170509338e-01
    z[0,1,4]  R164      2.3492768406867981e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       1.1591717600822449e-01
    z[0,1,5]  R89       -0.0569237619638443
    z[0,1,5]  R90       5.5946819484233856e-03
    z[0,1,5]  R91       -1.1520248651504517e-01
    z[0,1,5]  R92       4.3139973282814026e-01
    z[0,1,5]  R93       6.7250800132751465e-01
    z[0,1,5]  R94       8.0121923238039017e-03
    z[0,1,5]  R95       2.2366911172866821e-01
    z[0,1,5]  R96       -1.5002716332674026e-02
    z[0,1,5]  R97       0.0206812284886837
    z[0,1,5]  R98       -3.4997123479843140e-01
    z[0,1,5]  R99       4.9335736548528075e-04
    z[0,1,5]  R100      6.0575842857360840e-01
    z[0,1,5]  R101      3.4417361021041870e-02
    z[0,1,5]  R102      -4.7730904817581177e-01
    z[0,1,5]  R103      6.2939971685409546e-01
    z[0,1,5]  R104      5.7388257980346680e-01
    z[0,1,5]  R105      -5.7849872857332230e-02
    z[0,1,5]  R106      -3.3820700645446777e-01
    z[0,1,5]  R107      -1.1151006072759628e-01
    z[0,1,5]  R108      3.0157443881034851e-01
    z[0,1,5]  R109      9.9785745143890381e-02
    z[0,1,5]  R110      9.8893940448760986e-02
    z[0,1,5]  R111      -2.2379116714000702e-01
    z[0,1,5]  R112      2.4236758053302765e-01
    z[0,1,5]  R113      3.7398687005043030e-01
    z[0,1,5]  R114      -9.7883641719818115e-03
    z[0,1,5]  R115      7.4246022850275040e-03
    z[0,1,5]  R116      -1.1341685056686401e-01
    z[0,1,5]  R117      2.2863309085369110e-01
    z[0,1,5]  R118      -1.6474494338035583e-01
    z[0,1,5]  R119      1.0680849105119705e-01
    z[0,1,5]  R120      -2.0315544307231903e-01
    z[0,1,5]  R121      1.4713162183761597e-01
    z[0,1,5]  R122      5.8734047412872314e-01
    z[0,1,5]  R123      4.0463688969612122e-01
    z[0,1,5]  R124      -1.7513585090637207e-01
    z[0,1,5]  R125      4.1197489947080612e-02
    z[0,1,5]  R126      -8.0205485224723816e-02
    z[0,1,5]  R127      1.2168951332569122e-01
    z[0,1,5]  R128      -2.0801538228988647e-01
    z[0,1,5]  R129      0.0840618684887886
    z[0,1,5]  R130      -1.9511045515537262e-01
    z[0,1,5]  R131      2.8341525793075562e-01
    z[0,1,5]  R132      -2.2321467101573944e-01
    z[0,1,5]  R133      -5.3270065784454346e-01
    z[0,1,5]  R134      -1.6856868565082550e-01
    z[0,1,5]  R135      5.8082717657089233e-01
    z[0,1,5]  R136      4.1606637835502625e-01
    z[0,1,5]  R137      2.6745957136154175e-01
    z[0,1,5]  R138      -4.6029236912727356e-01
    z[0,1,5]  R139      -4.8587009310722351e-01
    z[0,1,5]  R140      -1.2921129167079926e-01
    z[0,1,5]  R141      -1.5246525406837463e-01
    z[0,1,5]  R142      8.5285924375057220e-02
    z[0,1,5]  R143      -1.6475403308868408e-01
    z[0,1,5]  R144      3.6474382877349854e-01
    z[0,1,5]  R145      -5.9170073270797729e-01
    z[0,1,5]  R146      7.1492088027298450e-03
    z[0,1,5]  R147      -1.1673893034458160e-01
    z[0,1,5]  R148      -3.0481332540512085e-01
    z[0,1,5]  R149      -1.1750492453575134e-01
    z[0,1,5]  R150      2.3797427117824554e-01
    z[0,1,5]  R151      -1.9681325554847717e-01
    z[0,1,5]  R152      -2.7384012937545776e-01
    z[0,1,5]  R153      -2.0077195018529892e-02
    z[0,1,5]  R154      7.6294876635074615e-02
    z[0,1,5]  R155      2.1059630811214447e-01
    z[0,1,5]  R156      -3.1465789675712585e-01
    z[0,1,5]  R157      -6.2353044748306274e-01
    z[0,1,5]  R158      -8.8545608520507812e-01
    z[0,1,5]  R159      -3.4213870763778687e-01
    z[0,1,5]  R160      2.4994868040084839e-01
    z[0,1,5]  R161      -4.3828555941581726e-01
    z[0,1,5]  R162      -4.9683102965354919e-01
    z[0,1,5]  R163      -0.0399838462471962
    z[0,1,5]  R164      -0.0658000111579895
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -4.0916001796722412e-01
    z[0,1,6]  R89       -4.9556735157966614e-01
    z[0,1,6]  R90       -5.4662948846817017e-01
    z[0,1,6]  R91       -0.00693955272436142
    z[0,1,6]  R92       -3.1225019693374634e-01
    z[0,1,6]  R93       -1.8499717116355896e-02
    z[0,1,6]  R94       1.6012579202651978e-01
    z[0,1,6]  R95       -3.2182909548282623e-02
    z[0,1,6]  R96       -1.8483851850032806e-01
    z[0,1,6]  R97       4.0805283933877945e-02
    z[0,1,6]  R98       1.9043911248445511e-02
    z[0,1,6]  R99       2.6937791705131531e-01
    z[0,1,6]  R100      7.8737903386354446e-03
    z[0,1,6]  R101      4.4856214523315430e-01
    z[0,1,6]  R102      1.9325365126132965e-01
    z[0,1,6]  R103      -0.00127637037076056
    z[0,1,6]  R104      3.4791791439056396e-01
    z[0,1,6]  R105      -1.0738164931535721e-01
    z[0,1,6]  R106      5.4744761437177658e-02
    z[0,1,6]  R107      -2.7525332570075989e-01
    z[0,1,6]  R108      -3.4992974996566772e-01
    z[0,1,6]  R109      -6.9987498223781586e-02
    z[0,1,6]  R110      3.4656971693038940e-01
    z[0,1,6]  R111      4.7889653593301773e-02
    z[0,1,6]  R112      2.4893535301089287e-02
    z[0,1,6]  R113      -2.7149191498756409e-01
    z[0,1,6]  R114      -3.9874041080474854e-01
    z[0,1,6]  R115      4.7178462147712708e-01
    z[0,1,6]  R116      -5.0536626577377319e-01
    z[0,1,6]  R117      1.1487862467765808e-01
    z[0,1,6]  R118      -0.140189990401268
    z[0,1,6]  R119      -2.4210827052593231e-01
    z[0,1,6]  R120      3.4714812040328979e-01
    z[0,1,6]  R121      1.8521706759929657e-01
    z[0,1,6]  R122      3.4891620278358459e-01
    z[0,1,6]  R123      1.3328856229782104e-01
    z[0,1,6]  R124      -5.0446790456771851e-01
    z[0,1,6]  R125      -3.7109351158142090e-01
    z[0,1,6]  R126      -6.3475054502487183e-01
    z[0,1,6]  R127      -1.6226026415824890e-01
    z[0,1,6]  R128      1.9025182723999023e-01
    z[0,1,6]  R129      1.5770034492015839e-01
    z[0,1,6]  R130      3.6910846829414368e-01
    z[0,1,6]  R131      -9.2354238033294678e-02
    z[0,1,6]  R132      3.2046881318092346e-01
    z[0,1,6]  R133      2.5159615278244019e-01
    z[0,1,6]  R134      1.7906135320663452e-01
    z[0,1,6]  R135      2.4797524511814117e-01
    z[0,1,6]  R136      1.5853638947010040e-01
    z[0,1,6]  R137      -1.6094410419464111e-01
    z[0,1,6]  R138      3.7831205874681473e-02
    z[0,1,6]  R139      -8.4387667477130890e-02
    z[0,1,6]  R140      -4.6101531386375427e-01
    z[0,1,6]  R141      3.1176095828413963e-02
    z[0,1,6]  R142      -3.9415098726749420e-02
    z[0,1,6]  R143      0.571651041507721
    z[0,1,6]  R144      1.8962664902210236e-01
    z[0,1,6]  R145      -6.5610265731811523e-01
    z[0,1,6]  R146      2.1570038795471191e-01
    z[0,1,6]  R147      3.4002907574176788e-02
    z[0,1,6]  R148      -1.7430160939693451e-01
    z[0,1,6]  R149      -3.0266538262367249e-01
    z[0,1,6]  R150      4.8268902301788330e-01
    z[0,1,6]  R151      -2.9859754443168640e-01
    z[0,1,6]  R152      2.0012594759464264e-01
    z[0,1,6]  R153      4.0032669901847839e-01
    z[0,1,6]  R154      -4.9231955409049988e-01
    z[0,1,6]  R155      -2.6733508706092834e-01
    z[0,1,6]  R156      1.0189716517925262e-01
    z[0,1,6]  R157      -1.8809950351715088e-01
    z[0,1,6]  R158      -2.0480866730213165e-01
    z[0,1,6]  R159      3.5448002815246582e-01
    z[0,1,6]  R160      2.7313491702079773e-01
    z[0,1,6]  R161      -0.643130362033844
    z[0,1,6]  R162      -5.9421718120574951e-01
    z[0,1,6]  R163      3.4036511182785034e-01
    z[0,1,6]  R164      0.62882399559021
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R165      -1
    z[1,0,0]  R166      1
    z[1,0,0]  R179      2.7373647689819336e-01
    z[1,0,0]  R180      -2.9731979966163635e-01
    z[1,0,0]  R181      1.1816011369228363e-01
    z[1,0,0]  R182      -2.8915387392044067e-01
    z[1,0,0]  R183      -2.1819458901882172e-01
    z[1,0,0]  R184      -6.5947575494647026e-03
    z[1,0,0]  R185      3.4752342104911804e-01
    z[1,0,0]  R186      -3.7871897220611572e-01
    z[1,0,0]  R187      -4.6609845757484436e-01
    z[1,0,0]  R188      -3.5970714688301086e-01
    z[1,0,0]  R189      -1.0812094062566757e-01
    z[1,0,0]  R190      -1.2537581846117973e-02
    z[1,0,0]  R191      3.5242241621017456e-01
    z[1,0,0]  R192      -6.9711968302726746e-02
    z[1,0,0]  R193      1.9990468025207520e-01
    z[1,0,0]  R194      2.8056003153324127e-02
    z[1,0,0]  R195      -0.5154989361763
    z[1,0,0]  R196      2.2655533254146576e-01
    z[1,0,0]  R197      3.1677171587944031e-01
    z[1,0,0]  R198      3.0139264464378357e-01
    z[1,0,0]  R199      -3.4421378374099731e-01
    z[1,0,0]  R200      2.2422590851783752e-01
    z[1,0,0]  R201      1.9792316854000092e-01
    z[1,0,0]  R202      3.1178635358810425e-01
    z[1,0,0]  R203      -2.1497267484664917e-01
    z[1,0,0]  R204      1.9140347838401794e-01
    z[1,0,0]  R205      -2.8798022866249084e-01
    z[1,0,0]  R206      -8.8347524404525757e-02
    z[1,0,0]  R207      -7.1481841802597046e-01
    z[1,0,0]  R208      2.5166258215904236e-01
    z[1,0,0]  R209      -2.2615826129913330e-01
    z[1,0,0]  R210      -2.4861498177051544e-01
    z[1,0,0]  R211      -9.1641299426555634e-02
    z[1,0,0]  R212      4.0413862466812134e-01
    z[1,0,0]  R213      3.9909341931343079e-01
    z[1,0,0]  R214      1.1803105473518372e-01
    z[1,0,0]  R215      4.0218746662139893e-01
    z[1,0,0]  R216      4.5351126790046692e-01
    z[1,0,0]  R217      -1.5146599709987640e-01
    z[1,0,0]  R218      1.8265716731548309e-01
    z[1,0,0]  R219      -5.0401080399751663e-02
    z[1,0,0]  R220      4.2824089527130127e-01
    z[1,0,0]  R221      1.5922770835459232e-03
    z[1,0,0]  R222      7.5826868414878845e-02
    z[1,0,0]  R223      1.2530748546123505e-01
    z[1,0,0]  R224      -6.1307537555694580e-01
    z[1,0,0]  R225      -3.1183484196662903e-01
    z[1,0,0]  R226      6.3193216919898987e-02
    z[1,0,0]  R227      4.9101456999778748e-02
    z[1,0,0]  R228      -1.6371060907840729e-01
    z[1,0,0]  R229      3.8743871450424194e-01
    z[1,0,0]  R230      -1.4517836272716522e-01
    z[1,0,0]  R231      4.0826085209846497e-01
    z[1,0,0]  R232      4.9306243658065796e-01
    z[1,0,0]  R233      4.5678767561912537e-01
    z[1,0,0]  R234      4.7633597254753113e-01
    z[1,0,0]  R235      6.7837619781494141e-01
    z[1,0,0]  R236      3.7534731626510620e-01
    z[1,0,0]  R237      3.1785193830728531e-02
    z[1,0,0]  R238      0.476936012506485
    z[1,0,0]  R239      4.5526400208473206e-01
    z[1,0,0]  R240      -4.7595086693763733e-01
    z[1,0,0]  R241      -1.4402058720588684e-01
    z[1,0,0]  R242      1.4602072536945343e-01
    z[1,0,0]  R243      -8.8987782597541809e-02
    z[1,0,0]  R244      6.5973460674285889e-02
    z[1,0,0]  R245      -1.0765879601240158e-01
    z[1,0,0]  R246      1.4987038075923920e-01
    z[1,0,0]  R247      -4.1974384337663651e-02
    z[1,0,0]  R248      2.8343917801976204e-03
    z[1,0,0]  R249      -0.399278849363327
    z[1,0,0]  R250      -2.4735212326049805e-01
    z[1,0,0]  R251      -6.7140311002731323e-02
    z[1,0,0]  R252      -4.1777658462524414e-01
    z[1,0,0]  R253      6.7546620965003967e-02
    z[1,0,0]  R254      -1.3360929489135742e-01
    z[1,0,0]  R255      -5.4297035932540894e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R167      -1
    z[1,0,1]  R168      1
    z[1,0,1]  R179      -3.3498278260231018e-01
    z[1,0,1]  R180      8.9675587415695190e-01
    z[1,0,1]  R181      8.7505888938903809e-01
    z[1,0,1]  R182      -6.1318643391132355e-02
    z[1,0,1]  R183      6.6259676218032837e-01
    z[1,0,1]  R184      0.692440390586853
    z[1,0,1]  R185      7.0537883043289185e-01
    z[1,0,1]  R186      7.3126709461212158e-01
    z[1,0,1]  R187      -6.4546540379524231e-02
    z[1,0,1]  R188      -0.858400285243988
    z[1,0,1]  R189      -0.876112699508667
    z[1,0,1]  R190      -8.0603712797164917e-01
    z[1,0,1]  R191      -7.7500116825103760e-01
    z[1,0,1]  R192      -7.7883827686309814e-01
    z[1,0,1]  R193      -6.4629852771759033e-01
    z[1,0,1]  R194      -3.9202803373336792e-01
    z[1,0,1]  R195      -7.4260437488555908e-01
    z[1,0,1]  R196      -7.1300995349884033e-01
    z[1,0,1]  R197      -7.1007263660430908e-01
    z[1,0,1]  R198      -7.9286617040634155e-01
    z[1,0,1]  R199      2.7025574445724487e-01
    z[1,0,1]  R200      8.4632793441414833e-03
    z[1,0,1]  R201      1.5935626626014709e-01
    z[1,0,1]  R202      4.2423886060714722e-01
    z[1,0,1]  R203      7.1896232664585114e-02
    z[1,0,1]  R204      -2.3277062922716141e-02
    z[1,0,1]  R205      -1.3731746375560760e-01
    z[1,0,1]  R206      -2.2696368396282196e-01
    z[1,0,1]  R207      4.0837100148200989e-01
    z[1,0,1]  R208      -8.0349564552307129e-01
    z[1,0,1]  R209      1.5217198431491852e-01
    z[1,0,1]  R210      3.4239817410707474e-02
    z[1,0,1]  R211      -6.0378062725067139e-01
    z[1,0,1]  R212      3.2040509581565857e-01
    z[1,0,1]  R213      3.1255221366882324e-01
    z[1,0,1]  R214      2.8163838386535645e-01
    z[1,0,1]  R215      -2.9545217752456665e-01
    z[1,0,1]  R216      -3.1975455582141876e-02
    z[1,0,1]  R217      1.0061888396739960e-01
    z[1,0,1]  R218      -4.9161937087774277e-02
    z[1,0,1]  R219      2.2024077177047729e-01
    z[1,0,1]  R220      -2.2849030792713165e-01
    z[1,0,1]  R221      -1.7041325569152832e-02
    z[1,0,1]  R222      -0.54848712682724
    z[1,0,1]  R223      -2.8677159547805786e-01
    z[1,0,1]  R224      5.2385908365249634e-01
    z[1,0,1]  R225      0.618018388748169
    z[1,0,1]  R226      8.2392197847366333e-01
    z[1,0,1]  R227      6.8016415834426880e-01
    z[1,0,1]  R228      7.7156919240951538e-01
    z[1,0,1]  R229      7.2993814945220947e-01
    z[1,0,1]  R230      5.9321910142898560e-01
    z[1,0,1]  R231      5.7834815979003906e-01
    z[1,0,1]  R232      6.2786775827407837e-01
    z[1,0,1]  R233      5.5659162998199463e-01
    z[1,0,1]  R234      -4.3671395629644394e-02
    z[1,0,1]  R235      3.2095119357109070e-02
    z[1,0,1]  R236      -4.9491804838180542e-01
    z[1,0,1]  R237      -6.5591049194335938e-01
    z[1,0,1]  R238      -0.452214777469635
    z[1,0,1]  R239      -7.0627099275588989e-01
    z[1,0,1]  R240      -5.5401831865310669e-01
    z[1,0,1]  R241      -4.3831315636634827e-01
    z[1,0,1]  R242      -5.4018628597259521e-01
    z[1,0,1]  R243      -5.2345865964889526e-01
    z[1,0,1]  R244      -8.2594347000122070e-01
    z[1,0,1]  R245      -5.3371143341064453e-01
    z[1,0,1]  R246      -8.2987940311431885e-01
    z[1,0,1]  R247      -6.1525815725326538e-01
    z[1,0,1]  R248      -7.6073414087295532e-01
    z[1,0,1]  R249      -0.863974928855896
    z[1,0,1]  R250      -8.1962603330612183e-01
    z[1,0,1]  R251      -3.3098754286766052e-01
    z[1,0,1]  R252      -7.0585000514984131e-01
    z[1,0,1]  R253      6.5138167142868042e-01
    z[1,0,1]  R254      -6.0313898324966431e-01
    z[1,0,1]  R255      -4.6534386277198792e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R169      -1
    z[1,0,2]  R170      1
    z[1,0,2]  R179      7.7378839254379272e-01
    z[1,0,2]  R180      1.0274402797222137e-01
    z[1,0,2]  R181      2.4186423420906067e-01
    z[1,0,2]  R182      7.5274819135665894e-01
    z[1,0,2]  R183      4.1259959340095520e-02
    z[1,0,2]  R184      0.307152658700943
    z[1,0,2]  R185      2.2188268601894379e-02
    z[1,0,2]  R186      1.6515260562300682e-02
    z[1,0,2]  R187      1.7743951082229614e-01
    z[1,0,2]  R188      4.5016493648290634e-02
    z[1,0,2]  R189      -1.2014707922935486e-01
    z[1,0,2]  R190      -2.7345892786979675e-01
    z[1,0,2]  R191      -1.5424926578998566e-01
    z[1,0,2]  R192      -2.4860759079456329e-01
    z[1,0,2]  R193      -1.7490682005882263e-01
    z[1,0,2]  R194      -7.5999490916728973e-02
    z[1,0,2]  R195      -2.2708848118782043e-01
    z[1,0,2]  R196      2.1298274397850037e-02
    z[1,0,2]  R197      -0.270439088344574
    z[1,0,2]  R198      1.4696128666400909e-01
    z[1,0,2]  R199      1.8496122956275940e-01
    z[1,0,2]  R200      2.1626810729503632e-01
    z[1,0,2]  R201      -0.299159973859787
    z[1,0,2]  R202      1.9976884126663208e-02
    z[1,0,2]  R203      5.4376077651977539e-01
    z[1,0,2]  R204      0.306511789560318
    z[1,0,2]  R205      3.1260961294174194e-01
    z[1,0,2]  R206      5.8296412229537964e-02
    z[1,0,2]  R207      -2.2257991135120392e-01
    z[1,0,2]  R208      1.4338243007659912e-01
    z[1,0,2]  R209      -6.4063794910907745e-02
    z[1,0,2]  R210      2.4304716289043427e-01
    z[1,0,2]  R211      4.9997827410697937e-01
    z[1,0,2]  R212      3.6259759217500687e-02
    z[1,0,2]  R213      -3.6870157718658447e-01
    z[1,0,2]  R214      5.1369881629943848e-01
    z[1,0,2]  R215      1.7250214517116547e-01
    z[1,0,2]  R216      2.9760643839836121e-01
    z[1,0,2]  R217      -3.1268224120140076e-01
    z[1,0,2]  R218      -1.5565671026706696e-01
    z[1,0,2]  R219      1.4295632019639015e-02
    z[1,0,2]  R220      -1.7127253115177155e-02
    z[1,0,2]  R221      -3.6432725191116333e-01
    z[1,0,2]  R222      -1.4075274765491486e-01
    z[1,0,2]  R223      -3.3891963958740234e-01
    z[1,0,2]  R224      -0.280981183052063
    z[1,0,2]  R225      1.2004150450229645e-01
    z[1,0,2]  R226      2.4155406281352043e-02
    z[1,0,2]  R227      5.0916379690170288e-01
    z[1,0,2]  R228      2.7194762229919434e-01
    z[1,0,2]  R229      2.7120593190193176e-01
    z[1,0,2]  R230      -0.0447147935628891
    z[1,0,2]  R231      -8.6999922990798950e-02
    z[1,0,2]  R232      2.9580566287040710e-01
    z[1,0,2]  R233      4.2334303259849548e-01
    z[1,0,2]  R234      2.2294847294688225e-02
    z[1,0,2]  R235      -8.3603955805301666e-02
    z[1,0,2]  R236      6.1550474166870117e-01
    z[1,0,2]  R237      3.8957926630973816e-01
    z[1,0,2]  R238      0.15157450735569
    z[1,0,2]  R239      2.9771193861961365e-01
    z[1,0,2]  R240      1.3639959692955017e-01
    z[1,0,2]  R241      -3.1166866421699524e-01
    z[1,0,2]  R242      1.3838428258895874e-01
    z[1,0,2]  R243      -6.9160008430480957e-01
    z[1,0,2]  R244      -1.3008992373943329e-01
    z[1,0,2]  R245      4.6579241752624512e-01
    z[1,0,2]  R246      1.8765021860599518e-01
    z[1,0,2]  R247      -3.0872235074639320e-02
    z[1,0,2]  R248      -3.5853850841522217e-01
    z[1,0,2]  R249      -1.5256865322589874e-01
    z[1,0,2]  R250      -2.3540411889553070e-01
    z[1,0,2]  R251      6.5041255950927734e-01
    z[1,0,2]  R252      -2.5383287668228149e-01
    z[1,0,2]  R253      -5.7006269693374634e-01
    z[1,0,2]  R254      -1.8810448050498962e-01
    z[1,0,2]  R255      5.6214940547943115e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R171      -1
    z[1,0,3]  R172      1
    z[1,0,3]  R179      3.8225373625755310e-01
    z[1,0,3]  R180      -3.9157648570835590e-03
    z[1,0,3]  R181      3.4162499941885471e-03
    z[1,0,3]  R182      5.1377767324447632e-01
    z[1,0,3]  R183      -4.1259959340095520e-02
    z[1,0,3]  R184      -1.7851822078227997e-01
    z[1,0,3]  R185      2.2214195132255554e-01
    z[1,0,3]  R186      -8.9437246322631836e-02
    z[1,0,3]  R187      5.8046829700469971e-01
    z[1,0,3]  R188      -3.0088746547698975e-01
    z[1,0,3]  R189      -1.5492798388004303e-01
    z[1,0,3]  R190      6.3656136393547058e-02
    z[1,0,3]  R191      -2.5527718663215637e-01
    z[1,0,3]  R192      4.5975369215011597e-01
    z[1,0,3]  R193      1.4882178604602814e-01
    z[1,0,3]  R194      2.5903906673192978e-02
    z[1,0,3]  R195      2.0706845819950104e-01
    z[1,0,3]  R196      1.3117501139640808e-01
    z[1,0,3]  R197      -3.1659743189811707e-01
    z[1,0,3]  R198      -3.2407918572425842e-01
    z[1,0,3]  R199      -6.2176507711410522e-01
    z[1,0,3]  R200      -5.0077027082443237e-01
    z[1,0,3]  R201      -5.9560501575469971e-01
    z[1,0,3]  R202      -5.1182800531387329e-01
    z[1,0,3]  R203      -4.4937032461166382e-01
    z[1,0,3]  R204      -4.1226205229759216e-01
    z[1,0,3]  R205      -5.3184306621551514e-01
    z[1,0,3]  R206      -3.8543307781219482e-01
    z[1,0,3]  R207      1.0902522504329681e-01
    z[1,0,3]  R208      -4.0261375904083252e-01
    z[1,0,3]  R209      -6.8117129802703857e-01
    z[1,0,3]  R210      -8.1062769889831543e-01
    z[1,0,3]  R211      -2.4668163061141968e-01
    z[1,0,3]  R212      -5.5053102970123291e-01
    z[1,0,3]  R213      -5.8346831798553467e-01
    z[1,0,3]  R214      -5.0937640666961670e-01
    z[1,0,3]  R215      -5.2619791030883789e-01
    z[1,0,3]  R216      -5.8378511667251587e-01
    z[1,0,3]  R217      0.871620774269104
    z[1,0,3]  R218      -6.9143766164779663e-01
    z[1,0,3]  R219      3.3501684665679932e-01
    z[1,0,3]  R220      -5.4444384574890137e-01
    z[1,0,3]  R221      -6.1271136999130249e-01
    z[1,0,3]  R222      1.0101101547479630e-01
    z[1,0,3]  R223      4.2658537626266479e-01
    z[1,0,3]  R224      3.9055773522704840e-03
    z[1,0,3]  R225      -2.2685249149799347e-01
    z[1,0,3]  R226      -0.0815090611577034
    z[1,0,3]  R227      -5.7429186999797821e-02
    z[1,0,3]  R228      -1.7642995342612267e-02
    z[1,0,3]  R229      -0.0578574538230896
    z[1,0,3]  R230      8.0894403159618378e-02
    z[1,0,3]  R231      -1.4554880559444427e-01
    z[1,0,3]  R232      3.9082306623458862e-01
    z[1,0,3]  R233      3.0799075961112976e-01
    z[1,0,3]  R234      8.3900749683380127e-01
    z[1,0,3]  R235      7.1428561210632324e-01
    z[1,0,3]  R236      1.5387716889381409e-01
    z[1,0,3]  R237      -5.2593696117401123e-01
    z[1,0,3]  R238      -2.1382157504558563e-01
    z[1,0,3]  R239      4.8487573862075806e-02
    z[1,0,3]  R240      -4.1771572828292847e-01
    z[1,0,3]  R241      -5.1616907119750977e-01
    z[1,0,3]  R242      -3.9053648710250854e-01
    z[1,0,3]  R243      4.4514226913452148e-01
    z[1,0,3]  R244      3.9098021388053894e-01
    z[1,0,3]  R245      3.1502255797386169e-01
    z[1,0,3]  R246      2.0046825706958771e-01
    z[1,0,3]  R247      4.6570390462875366e-01
    z[1,0,3]  R248      -0.22982257604599
    z[1,0,3]  R249      -1.3328652083873749e-01
    z[1,0,3]  R250      3.6576956510543823e-02
    z[1,0,3]  R251      -2.6202449202537537e-01
    z[1,0,3]  R252      -1.2374115735292435e-01
    z[1,0,3]  R253      -0.0840914323925972
    z[1,0,3]  R254      1.5043315291404724e-01
    z[1,0,3]  R255      2.9802948236465454e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R173      -1
    z[1,0,4]  R174      1
    z[1,0,4]  R179      -1.4558282494544983e-01
    z[1,0,4]  R180      0.163810133934021
    z[1,0,4]  R181      -4.0570143610239029e-03
    z[1,0,4]  R182      1.6149160265922546e-01
    z[1,0,4]  R183      -2.0794370770454407e-01
    z[1,0,4]  R184      -4.6127480268478394e-01
    z[1,0,4]  R185      -2.1602858603000641e-01
    z[1,0,4]  R186      -4.1730195283889771e-01
    z[1,0,4]  R187      2.8576115146279335e-02
    z[1,0,4]  R188      -7.9619465395808220e-03
    z[1,0,4]  R189      -3.2067483663558960e-01
    z[1,0,4]  R190      4.8926392197608948e-01
    z[1,0,4]  R191      1.0910187661647797e-01
    z[1,0,4]  R192      -1.6284523904323578e-01
    z[1,0,4]  R193      5.8057814836502075e-01
    z[1,0,4]  R194      7.0143383741378784e-01
    z[1,0,4]  R195      1.6695725917816162e-01
    z[1,0,4]  R196      1.5419793128967285e-01
    z[1,0,4]  R197      -1.5438987314701080e-01
    z[1,0,4]  R198      2.3761963844299316e-01
    z[1,0,4]  R199      -4.1758334636688232e-01
    z[1,0,4]  R200      -6.3946652412414551e-01
    z[1,0,4]  R201      -0.51181960105896
    z[1,0,4]  R202      -6.6047418117523193e-01
    z[1,0,4]  R203      -0.664966881275177
    z[1,0,4]  R204      -5.8735400438308716e-01
    z[1,0,4]  R205      -0.590451717376709
    z[1,0,4]  R206      -0.0902474895119667
    z[1,0,4]  R207      4.6288406848907471e-01
    z[1,0,4]  R208      3.0597427487373352e-01
    z[1,0,4]  R209      -5.7819157838821411e-01
    z[1,0,4]  R210      -3.3972835540771484e-01
    z[1,0,4]  R211      1.6309560835361481e-01
    z[1,0,4]  R212      -5.4928815364837646e-01
    z[1,0,4]  R213      -3.8938489556312561e-01
    z[1,0,4]  R214      -4.7194615006446838e-01
    z[1,0,4]  R215      -4.4284597039222717e-01
    z[1,0,4]  R216      -4.9810793995857239e-01
    z[1,0,4]  R217      6.9485092535614967e-03
    z[1,0,4]  R218      -1.9424900412559509e-01
    z[1,0,4]  R219      1.0263490676879883e-01
    z[1,0,4]  R220      -4.7431486845016479e-01
    z[1,0,4]  R221      -5.9538251161575317e-01
    z[1,0,4]  R222      2.4018044769763947e-01
    z[1,0,4]  R223      -7.2686426341533661e-02
    z[1,0,4]  R224      3.9153233170509338e-01
    z[1,0,4]  R225      2.3492768406867981e-01
    z[1,0,4]  R226      -3.5928165912628174e-01
    z[1,0,4]  R227      -1.5359874069690704e-01
    z[1,0,4]  R228      6.9122023880481720e-02
    z[1,0,4]  R229      -0.476299911737442
    z[1,0,4]  R230      5.7867527008056641e-01
    z[1,0,4]  R231      -1.3218839466571808e-01
    z[1,0,4]  R232      3.1100383400917053e-01
    z[1,0,4]  R233      3.9548650383949280e-01
    z[1,0,4]  R234      1.7993319034576416e-01
    z[1,0,4]  R235      -0.139604389667511
    z[1,0,4]  R236      -2.9799956083297729e-01
    z[1,0,4]  R237      -2.6043140888214111e-01
    z[1,0,4]  R238      -3.6377736926078796e-01
    z[1,0,4]  R239      -2.3236876353621483e-02
    z[1,0,4]  R240      -9.0952344238758087e-02
    z[1,0,4]  R241      -1.6560812294483185e-01
    z[1,0,4]  R242      2.5459712743759155e-01
    z[1,0,4]  R243      -1.6350033879280090e-01
    z[1,0,4]  R244      -1.6215749084949493e-01
    z[1,0,4]  R245      5.4695618152618408e-01
    z[1,0,4]  R246      6.3911923207342625e-03
    z[1,0,4]  R247      6.2209874391555786e-01
    z[1,0,4]  R248      -3.3168774843215942e-01
    z[1,0,4]  R249      -2.6557940989732742e-02
    z[1,0,4]  R250      3.8847821950912476e-01
    z[1,0,4]  R251      4.2505535483360291e-01
    z[1,0,4]  R252      -2.9733118414878845e-01
    z[1,0,4]  R253      -1.2829910218715668e-01
    z[1,0,4]  R254      -5.4046303033828735e-01
    z[1,0,4]  R255      -1.3540554046630859e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R175      -1
    z[1,0,5]  R176      1
    z[1,0,5]  R179      -1.6474494338035583e-01
    z[1,0,5]  R180      1.0680849105119705e-01
    z[1,0,5]  R181      -2.0315544307231903e-01
    z[1,0,5]  R182      1.4713162183761597e-01
    z[1,0,5]  R183      5.8734047412872314e-01
    z[1,0,5]  R184      4.0463688969612122e-01
    z[1,0,5]  R185      -1.7513585090637207e-01
    z[1,0,5]  R186      4.1197489947080612e-02
    z[1,0,5]  R187      -8.0205485224723816e-02
    z[1,0,5]  R188      1.2168951332569122e-01
    z[1,0,5]  R189      -2.0801538228988647e-01
    z[1,0,5]  R190      0.0840618684887886
    z[1,0,5]  R191      -1.9511045515537262e-01
    z[1,0,5]  R192      2.8341525793075562e-01
    z[1,0,5]  R193      -2.2321467101573944e-01
    z[1,0,5]  R194      -5.3270065784454346e-01
    z[1,0,5]  R195      -1.6856868565082550e-01
    z[1,0,5]  R196      5.8082717657089233e-01
    z[1,0,5]  R197      4.1606637835502625e-01
    z[1,0,5]  R198      2.6745957136154175e-01
    z[1,0,5]  R199      -4.6029236912727356e-01
    z[1,0,5]  R200      -4.8587009310722351e-01
    z[1,0,5]  R201      -1.2921129167079926e-01
    z[1,0,5]  R202      -1.5246525406837463e-01
    z[1,0,5]  R203      8.5285924375057220e-02
    z[1,0,5]  R204      -1.6475403308868408e-01
    z[1,0,5]  R205      3.6474382877349854e-01
    z[1,0,5]  R206      -5.9170073270797729e-01
    z[1,0,5]  R207      7.1492088027298450e-03
    z[1,0,5]  R208      -1.1673893034458160e-01
    z[1,0,5]  R209      -3.0481332540512085e-01
    z[1,0,5]  R210      -1.1750492453575134e-01
    z[1,0,5]  R211      2.3797427117824554e-01
    z[1,0,5]  R212      -1.9681325554847717e-01
    z[1,0,5]  R213      -2.7384012937545776e-01
    z[1,0,5]  R214      -2.0077195018529892e-02
    z[1,0,5]  R215      7.6294876635074615e-02
    z[1,0,5]  R216      2.1059630811214447e-01
    z[1,0,5]  R217      -3.1465789675712585e-01
    z[1,0,5]  R218      -6.2353044748306274e-01
    z[1,0,5]  R219      -8.8545608520507812e-01
    z[1,0,5]  R220      -3.4213870763778687e-01
    z[1,0,5]  R221      2.4994868040084839e-01
    z[1,0,5]  R222      -4.3828555941581726e-01
    z[1,0,5]  R223      -4.9683102965354919e-01
    z[1,0,5]  R224      -0.0399838462471962
    z[1,0,5]  R225      -0.0658000111579895
    z[1,0,5]  R226      1.1591717600822449e-01
    z[1,0,5]  R227      -0.0569237619638443
    z[1,0,5]  R228      5.5946819484233856e-03
    z[1,0,5]  R229      -1.1520248651504517e-01
    z[1,0,5]  R230      4.3139973282814026e-01
    z[1,0,5]  R231      6.7250800132751465e-01
    z[1,0,5]  R232      8.0121923238039017e-03
    z[1,0,5]  R233      2.2366911172866821e-01
    z[1,0,5]  R234      -1.5002716332674026e-02
    z[1,0,5]  R235      0.0206812284886837
    z[1,0,5]  R236      -3.4997123479843140e-01
    z[1,0,5]  R237      4.9335736548528075e-04
    z[1,0,5]  R238      6.0575842857360840e-01
    z[1,0,5]  R239      3.4417361021041870e-02
    z[1,0,5]  R240      -4.7730904817581177e-01
    z[1,0,5]  R241      6.2939971685409546e-01
    z[1,0,5]  R242      5.7388257980346680e-01
    z[1,0,5]  R243      -5.7849872857332230e-02
    z[1,0,5]  R244      -3.3820700645446777e-01
    z[1,0,5]  R245      -1.1151006072759628e-01
    z[1,0,5]  R246      3.0157443881034851e-01
    z[1,0,5]  R247      9.9785745143890381e-02
    z[1,0,5]  R248      9.8893940448760986e-02
    z[1,0,5]  R249      -2.2379116714000702e-01
    z[1,0,5]  R250      2.4236758053302765e-01
    z[1,0,5]  R251      3.7398687005043030e-01
    z[1,0,5]  R252      -9.7883641719818115e-03
    z[1,0,5]  R253      7.4246022850275040e-03
    z[1,0,5]  R254      -1.1341685056686401e-01
    z[1,0,5]  R255      2.2863309085369110e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R177      -1
    z[1,0,6]  R178      1
    z[1,0,6]  R179      -0.140189990401268
    z[1,0,6]  R180      -2.4210827052593231e-01
    z[1,0,6]  R181      3.4714812040328979e-01
    z[1,0,6]  R182      1.8521706759929657e-01
    z[1,0,6]  R183      3.4891620278358459e-01
    z[1,0,6]  R184      1.3328856229782104e-01
    z[1,0,6]  R185      -5.0446790456771851e-01
    z[1,0,6]  R186      -3.7109351158142090e-01
    z[1,0,6]  R187      -6.3475054502487183e-01
    z[1,0,6]  R188      -1.6226026415824890e-01
    z[1,0,6]  R189      1.9025182723999023e-01
    z[1,0,6]  R190      1.5770034492015839e-01
    z[1,0,6]  R191      3.6910846829414368e-01
    z[1,0,6]  R192      -9.2354238033294678e-02
    z[1,0,6]  R193      3.2046881318092346e-01
    z[1,0,6]  R194      2.5159615278244019e-01
    z[1,0,6]  R195      1.7906135320663452e-01
    z[1,0,6]  R196      2.4797524511814117e-01
    z[1,0,6]  R197      1.5853638947010040e-01
    z[1,0,6]  R198      -1.6094410419464111e-01
    z[1,0,6]  R199      3.7831205874681473e-02
    z[1,0,6]  R200      -8.4387667477130890e-02
    z[1,0,6]  R201      -4.6101531386375427e-01
    z[1,0,6]  R202      3.1176095828413963e-02
    z[1,0,6]  R203      -3.9415098726749420e-02
    z[1,0,6]  R204      0.571651041507721
    z[1,0,6]  R205      1.8962664902210236e-01
    z[1,0,6]  R206      -6.5610265731811523e-01
    z[1,0,6]  R207      2.1570038795471191e-01
    z[1,0,6]  R208      3.4002907574176788e-02
    z[1,0,6]  R209      -1.7430160939693451e-01
    z[1,0,6]  R210      -3.0266538262367249e-01
    z[1,0,6]  R211      4.8268902301788330e-01
    z[1,0,6]  R212      -2.9859754443168640e-01
    z[1,0,6]  R213      2.0012594759464264e-01
    z[1,0,6]  R214      4.0032669901847839e-01
    z[1,0,6]  R215      -4.9231955409049988e-01
    z[1,0,6]  R216      -2.6733508706092834e-01
    z[1,0,6]  R217      1.0189716517925262e-01
    z[1,0,6]  R218      -1.8809950351715088e-01
    z[1,0,6]  R219      -2.0480866730213165e-01
    z[1,0,6]  R220      3.5448002815246582e-01
    z[1,0,6]  R221      2.7313491702079773e-01
    z[1,0,6]  R222      -0.643130362033844
    z[1,0,6]  R223      -5.9421718120574951e-01
    z[1,0,6]  R224      3.4036511182785034e-01
    z[1,0,6]  R225      0.62882399559021
    z[1,0,6]  R226      -4.0916001796722412e-01
    z[1,0,6]  R227      -4.9556735157966614e-01
    z[1,0,6]  R228      -5.4662948846817017e-01
    z[1,0,6]  R229      -0.00693955272436142
    z[1,0,6]  R230      -3.1225019693374634e-01
    z[1,0,6]  R231      -1.8499717116355896e-02
    z[1,0,6]  R232      1.6012579202651978e-01
    z[1,0,6]  R233      -3.2182909548282623e-02
    z[1,0,6]  R234      -1.8483851850032806e-01
    z[1,0,6]  R235      4.0805283933877945e-02
    z[1,0,6]  R236      1.9043911248445511e-02
    z[1,0,6]  R237      2.6937791705131531e-01
    z[1,0,6]  R238      7.8737903386354446e-03
    z[1,0,6]  R239      4.4856214523315430e-01
    z[1,0,6]  R240      1.9325365126132965e-01
    z[1,0,6]  R241      -0.00127637037076056
    z[1,0,6]  R242      3.4791791439056396e-01
    z[1,0,6]  R243      -1.0738164931535721e-01
    z[1,0,6]  R244      5.4744761437177658e-02
    z[1,0,6]  R245      -2.7525332570075989e-01
    z[1,0,6]  R246      -3.4992974996566772e-01
    z[1,0,6]  R247      -6.9987498223781586e-02
    z[1,0,6]  R248      3.4656971693038940e-01
    z[1,0,6]  R249      4.7889653593301773e-02
    z[1,0,6]  R250      2.4893535301089287e-02
    z[1,0,6]  R251      -2.7149191498756409e-01
    z[1,0,6]  R252      -3.9874041080474854e-01
    z[1,0,6]  R253      4.7178462147712708e-01
    z[1,0,6]  R254      -5.0536626577377319e-01
    z[1,0,6]  R255      1.1487862467765808e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R256      -1
    z[0,5,0]  R257      1
    z[0,5,0]  R270      6.3193216919898987e-02
    z[0,5,0]  R271      4.9101456999778748e-02
    z[0,5,0]  R272      -1.6371060907840729e-01
    z[0,5,0]  R273      3.8743871450424194e-01
    z[0,5,0]  R274      -1.4517836272716522e-01
    z[0,5,0]  R275      4.0826085209846497e-01
    z[0,5,0]  R276      4.9306243658065796e-01
    z[0,5,0]  R277      4.5678767561912537e-01
    z[0,5,0]  R278      4.7633597254753113e-01
    z[0,5,0]  R279      6.7837619781494141e-01
    z[0,5,0]  R280      3.7534731626510620e-01
    z[0,5,0]  R281      3.1785193830728531e-02
    z[0,5,0]  R282      0.476936012506485
    z[0,5,0]  R283      4.5526400208473206e-01
    z[0,5,0]  R284      -4.7595086693763733e-01
    z[0,5,0]  R285      -1.4402058720588684e-01
    z[0,5,0]  R286      1.4602072536945343e-01
    z[0,5,0]  R287      -8.8987782597541809e-02
    z[0,5,0]  R288      6.5973460674285889e-02
    z[0,5,0]  R289      -1.0765879601240158e-01
    z[0,5,0]  R290      1.4987038075923920e-01
    z[0,5,0]  R291      -4.1974384337663651e-02
    z[0,5,0]  R292      2.8343917801976204e-03
    z[0,5,0]  R293      -0.399278849363327
    z[0,5,0]  R294      -2.4735212326049805e-01
    z[0,5,0]  R295      -6.7140311002731323e-02
    z[0,5,0]  R296      -4.1777658462524414e-01
    z[0,5,0]  R297      6.7546620965003967e-02
    z[0,5,0]  R298      -1.3360929489135742e-01
    z[0,5,0]  R299      -5.4297035932540894e-01
    z[0,5,0]  R300      -5.7996219396591187e-01
    z[0,5,0]  R301      -7.9358226060867310e-01
    z[0,5,0]  R302      -0.518456757068634
    z[0,5,0]  R303      -6.3096517324447632e-01
    z[0,5,0]  R304      -3.6290261149406433e-01
    z[0,5,0]  R305      -5.1928228139877319e-01
    z[0,5,0]  R306      -2.2811952233314514e-01
    z[0,5,0]  R307      4.1172024607658386e-01
    z[0,5,0]  R308      5.6369763612747192e-01
    z[0,5,0]  R309      6.7790520191192627e-01
    z[0,5,0]  R310      2.5977733731269836e-01
    z[0,5,0]  R311      3.2061547040939331e-01
    z[0,5,0]  R312      1.3840182125568390e-01
    z[0,5,0]  R313      -3.0481213331222534e-01
    z[0,5,0]  R314      -5.0336980819702148e-01
    z[0,5,0]  R315      -1.9695284962654114e-01
    z[0,5,0]  R316      -1.1693647503852844e-01
    z[0,5,0]  R317      5.1186162233352661e-01
    z[0,5,0]  R318      6.1486173421144485e-02
    z[0,5,0]  R319      0.04227314889431
    z[0,5,0]  R320      -3.9250290393829346e-01
    z[0,5,0]  R321      2.1174551546573639e-01
    z[0,5,0]  R322      -7.1806021034717560e-02
    z[0,5,0]  R323      -3.5093218088150024e-02
    z[0,5,0]  R324      3.3915615081787109e-01
    z[0,5,0]  R325      -1.1973375082015991e-01
    z[0,5,0]  R326      -3.8449484109878540e-01
    z[0,5,0]  R327      -1.7956182360649109e-01
    z[0,5,0]  R328      -0.182621568441391
    z[0,5,0]  R329      1.0773085057735443e-01
    z[0,5,0]  R330      -0.0769742876291275
    z[0,5,0]  R331      3.2144537568092346e-01
    z[0,5,0]  R332      1.9060429930686951e-01
    z[0,5,0]  R333      2.5585165619850159e-01
    z[0,5,0]  R334      -2.3111756891012192e-02
    z[0,5,0]  R335      3.3616542816162109e-01
    z[0,5,0]  R336      2.4032276868820190e-01
    z[0,5,0]  R337      -8.9384570717811584e-02
    z[0,5,0]  R338      -2.1971440315246582e-01
    z[0,5,0]  R339      -2.1087791025638580e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R258      -1
    z[0,5,1]  R259      1
    z[0,5,1]  R270      8.2392197847366333e-01
    z[0,5,1]  R271      6.8016415834426880e-01
    z[0,5,1]  R272      7.7156919240951538e-01
    z[0,5,1]  R273      7.2993814945220947e-01
    z[0,5,1]  R274      5.9321910142898560e-01
    z[0,5,1]  R275      5.7834815979003906e-01
    z[0,5,1]  R276      6.2786775827407837e-01
    z[0,5,1]  R277      5.5659162998199463e-01
    z[0,5,1]  R278      -4.3671395629644394e-02
    z[0,5,1]  R279      3.2095119357109070e-02
    z[0,5,1]  R280      -4.9491804838180542e-01
    z[0,5,1]  R281      -6.5591049194335938e-01
    z[0,5,1]  R282      -0.452214777469635
    z[0,5,1]  R283      -7.0627099275588989e-01
    z[0,5,1]  R284      -5.5401831865310669e-01
    z[0,5,1]  R285      -4.3831315636634827e-01
    z[0,5,1]  R286      -5.4018628597259521e-01
    z[0,5,1]  R287      -5.2345865964889526e-01
    z[0,5,1]  R288      -8.2594347000122070e-01
    z[0,5,1]  R289      -5.3371143341064453e-01
    z[0,5,1]  R290      -8.2987940311431885e-01
    z[0,5,1]  R291      -6.1525815725326538e-01
    z[0,5,1]  R292      -7.6073414087295532e-01
    z[0,5,1]  R293      -0.863974928855896
    z[0,5,1]  R294      -8.1962603330612183e-01
    z[0,5,1]  R295      -3.3098754286766052e-01
    z[0,5,1]  R296      -7.0585000514984131e-01
    z[0,5,1]  R297      6.5138167142868042e-01
    z[0,5,1]  R298      -6.0313898324966431e-01
    z[0,5,1]  R299      -4.6534386277198792e-01
    z[0,5,1]  R300      2.3080082237720490e-01
    z[0,5,1]  R301      -0.0527375154197216
    z[0,5,1]  R302      2.0245993137359619e-01
    z[0,5,1]  R303      2.6000419165939093e-03
    z[0,5,1]  R304      -2.0599098876118660e-02
    z[0,5,1]  R305      -5.4028481245040894e-02
    z[0,5,1]  R306      6.0787373781204224e-01
    z[0,5,1]  R307      6.5360605716705322e-02
    z[0,5,1]  R308      2.1668045222759247e-01
    z[0,5,1]  R309      -1.9635602831840515e-02
    z[0,5,1]  R310      -7.4423557519912720e-01
    z[0,5,1]  R311      -7.7088785171508789e-01
    z[0,5,1]  R312      -6.4877432584762573e-01
    z[0,5,1]  R313      -6.7080420255661011e-01
    z[0,5,1]  R314      -0.663345456123352
    z[0,5,1]  R315      -5.3227263689041138e-01
    z[0,5,1]  R316      -0.687248170375824
    z[0,5,1]  R317      -0.569867730140686
    z[0,5,1]  R318      -0.77773118019104
    z[0,5,1]  R319      -3.8848367333412170e-01
    z[0,5,1]  R320      -8.5708284378051758e-01
    z[0,5,1]  R321      -0.671985387802124
    z[0,5,1]  R322      -7.8402262926101685e-01
    z[0,5,1]  R323      -0.723905086517334
    z[0,5,1]  R324      -5.6439733505249023e-01
    z[0,5,1]  R325      -0.00883125513792038
    z[0,5,1]  R326      -0.103699691593647
    z[0,5,1]  R327      5.3361009806394577e-02
    z[0,5,1]  R328      5.5084377527236938e-01
    z[0,5,1]  R329      5.8834302425384521e-01
    z[0,5,1]  R330      -0.764907956123352
    z[0,5,1]  R331      -9.2994827032089233e-01
    z[0,5,1]  R332      -7.1044009923934937e-01
    z[0,5,1]  R333      -6.4333051443099976e-01
    z[0,5,1]  R334      2.3180831968784332e-01
    z[0,5,1]  R335      -6.7275100946426392e-01
    z[0,5,1]  R336      2.0524153113365173e-01
    z[0,5,1]  R337      7.5061500072479248e-02
    z[0,5,1]  R338      4.4072076678276062e-01
    z[0,5,1]  R339      8.9551174640655518e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R260      -1
    z[0,5,2]  R261      1
    z[0,5,2]  R270      2.4155406281352043e-02
    z[0,5,2]  R271      5.0916379690170288e-01
    z[0,5,2]  R272      2.7194762229919434e-01
    z[0,5,2]  R273      2.7120593190193176e-01
    z[0,5,2]  R274      -0.0447147935628891
    z[0,5,2]  R275      -8.6999922990798950e-02
    z[0,5,2]  R276      2.9580566287040710e-01
    z[0,5,2]  R277      4.2334303259849548e-01
    z[0,5,2]  R278      2.2294847294688225e-02
    z[0,5,2]  R279      -8.3603955805301666e-02
    z[0,5,2]  R280      6.1550474166870117e-01
    z[0,5,2]  R281      3.8957926630973816e-01
    z[0,5,2]  R282      0.15157450735569
    z[0,5,2]  R283      2.9771193861961365e-01
    z[0,5,2]  R284      1.3639959692955017e-01
    z[0,5,2]  R285      -3.1166866421699524e-01
    z[0,5,2]  R286      1.3838428258895874e-01
    z[0,5,2]  R287      -6.9160008430480957e-01
    z[0,5,2]  R288      -1.3008992373943329e-01
    z[0,5,2]  R289      4.6579241752624512e-01
    z[0,5,2]  R290      1.8765021860599518e-01
    z[0,5,2]  R291      -3.0872235074639320e-02
    z[0,5,2]  R292      -3.5853850841522217e-01
    z[0,5,2]  R293      -1.5256865322589874e-01
    z[0,5,2]  R294      -2.3540411889553070e-01
    z[0,5,2]  R295      6.5041255950927734e-01
    z[0,5,2]  R296      -2.5383287668228149e-01
    z[0,5,2]  R297      -5.7006269693374634e-01
    z[0,5,2]  R298      -1.8810448050498962e-01
    z[0,5,2]  R299      5.6214940547943115e-01
    z[0,5,2]  R300      4.1230174899101257e-01
    z[0,5,2]  R301      3.5707753896713257e-01
    z[0,5,2]  R302      8.0414557456970215e-01
    z[0,5,2]  R303      6.6721254587173462e-01
    z[0,5,2]  R304      6.7652350664138794e-01
    z[0,5,2]  R305      2.7625033259391785e-01
    z[0,5,2]  R306      1.0251188278198242e-01
    z[0,5,2]  R307      -1.7896650359034538e-02
    z[0,5,2]  R308      -2.8267744928598404e-03
    z[0,5,2]  R309      5.4159498214721680e-01
    z[0,5,2]  R310      1.3479290902614594e-01
    z[0,5,2]  R311      2.1449199318885803e-01
    z[0,5,2]  R312      1.9075600802898407e-01
    z[0,5,2]  R313      -9.1220803558826447e-02
    z[0,5,2]  R314      -7.3211520910263062e-02
    z[0,5,2]  R315      2.7145119383931160e-02
    z[0,5,2]  R316      -3.1677749752998352e-01
    z[0,5,2]  R317      3.5254955291748047e-01
    z[0,5,2]  R318      -5.6832976639270782e-02
    z[0,5,2]  R319      9.8804473876953125e-02
    z[0,5,2]  R320      -2.0342530310153961e-01
    z[0,5,2]  R321      2.1533285081386566e-01
    z[0,5,2]  R322      -1.9392953813076019e-01
    z[0,5,2]  R323      -3.7211760878562927e-01
    z[0,5,2]  R324      3.8335654139518738e-01
    z[0,5,2]  R325      -2.6121586561203003e-01
    z[0,5,2]  R326      -4.1250422596931458e-01
    z[0,5,2]  R327      -4.9788277596235275e-02
    z[0,5,2]  R328      1.2829124927520752e-01
    z[0,5,2]  R329      2.3098066449165344e-01
    z[0,5,2]  R330      3.1553870439529419e-01
    z[0,5,2]  R331      0.0686025395989418
    z[0,5,2]  R332      -4.4498926401138306e-01
    z[0,5,2]  R333      -4.5791637897491455e-01
    z[0,5,2]  R334      1.6195403039455414e-01
    z[0,5,2]  R335      -2.5885558128356934e-01
    z[0,5,2]  R336      2.4468574672937393e-02
    z[0,5,2]  R337      3.8558891415596008e-01
    z[0,5,2]  R338      -1.9540810957551003e-02
    z[0,5,2]  R339      -5.6084785610437393e-02
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R262      -1
    z[0,5,3]  R263      1
    z[0,5,3]  R270      -0.0815090611577034
    z[0,5,3]  R271      -5.7429186999797821e-02
    z[0,5,3]  R272      -1.7642995342612267e-02
    z[0,5,3]  R273      -0.0578574538230896
    z[0,5,3]  R274      8.0894403159618378e-02
    z[0,5,3]  R275      -1.4554880559444427e-01
    z[0,5,3]  R276      3.9082306623458862e-01
    z[0,5,3]  R277      3.0799075961112976e-01
    z[0,5,3]  R278      8.3900749683380127e-01
    z[0,5,3]  R279      7.1428561210632324e-01
    z[0,5,3]  R280      1.5387716889381409e-01
    z[0,5,3]  R281      -5.2593696117401123e-01
    z[0,5,3]  R282      -2.1382157504558563e-01
    z[0,5,3]  R283      4.8487573862075806e-02
    z[0,5,3]  R284      -4.1771572828292847e-01
    z[0,5,3]  R285      -5.1616907119750977e-01
    z[0,5,3]  R286      -3.9053648710250854e-01
    z[0,5,3]  R287      4.4514226913452148e-01
    z[0,5,3]  R288      3.9098021388053894e-01
    z[0,5,3]  R289      3.1502255797386169e-01
    z[0,5,3]  R290      2.0046825706958771e-01
    z[0,5,3]  R291      4.6570390462875366e-01
    z[0,5,3]  R292      -0.22982257604599
    z[0,5,3]  R293      -1.3328652083873749e-01
    z[0,5,3]  R294      3.6576956510543823e-02
    z[0,5,3]  R295      -2.6202449202537537e-01
    z[0,5,3]  R296      -1.2374115735292435e-01
    z[0,5,3]  R297      -0.0840914323925972
    z[0,5,3]  R298      1.5043315291404724e-01
    z[0,5,3]  R299      2.9802948236465454e-01
    z[0,5,3]  R300      5.7542663812637329e-01
    z[0,5,3]  R301      4.0845578908920288e-01
    z[0,5,3]  R302      1.5528170764446259e-01
    z[0,5,3]  R303      1.2737837433815002e-01
    z[0,5,3]  R304      3.0088528990745544e-01
    z[0,5,3]  R305      4.5655813813209534e-01
    z[0,5,3]  R306      -4.9563857913017273e-01
    z[0,5,3]  R307      -3.1470906734466553e-01
    z[0,5,3]  R308      1.1076045036315918e-01
    z[0,5,3]  R309      -3.1615990400314331e-01
    z[0,5,3]  R310      2.7734089642763138e-02
    z[0,5,3]  R311      -3.6465135216712952e-01
    z[0,5,3]  R312      -1.1362092941999435e-01
    z[0,5,3]  R313      -2.0058588683605194e-01
    z[0,5,3]  R314      -2.3111377656459808e-01
    z[0,5,3]  R315      -1.4693267643451691e-01
    z[0,5,3]  R316      3.1360420584678650e-01
    z[0,5,3]  R317      -1.1760506778955460e-01
    z[0,5,3]  R318      3.6228078603744507e-01
    z[0,5,3]  R319      -3.5031415522098541e-02
    z[0,5,3]  R320      -3.0206680297851562e-02
    z[0,5,3]  R321      2.3643206059932709e-01
    z[0,5,3]  R322      2.0475223660469055e-02
    z[0,5,3]  R323      3.4598565101623535e-01
    z[0,5,3]  R324      -1.1399001628160477e-01
    z[0,5,3]  R325      -5.4585546255111694e-01
    z[0,5,3]  R326      -5.9481322765350342e-01
    z[0,5,3]  R327      -5.2916777133941650e-01
    z[0,5,3]  R328      -3.3844679594039917e-01
    z[0,5,3]  R329      -4.7032311558723450e-01
    z[0,5,3]  R330      2.7833151817321777e-01
    z[0,5,3]  R331      6.9129839539527893e-03
    z[0,5,3]  R332      -2.2999511659145355e-01
    z[0,5,3]  R333      -5.7330571115016937e-02
    z[0,5,3]  R334      -5.9929913282394409e-01
    z[0,5,3]  R335      -2.2839865088462830e-01
    z[0,5,3]  R336      -6.1922895908355713e-01
    z[0,5,3]  R337      -0.387405127286911
    z[0,5,3]  R338      -5.4892927408218384e-01
    z[0,5,3]  R339      -1.1917480081319809e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R264      -1
    z[0,5,4]  R265      1
    z[0,5,4]  R270      -3.5928165912628174e-01
    z[0,5,4]  R271      -1.5359874069690704e-01
    z[0,5,4]  R272      6.9122023880481720e-02
    z[0,5,4]  R273      -0.476299911737442
    z[0,5,4]  R274      5.7867527008056641e-01
    z[0,5,4]  R275      -1.3218839466571808e-01
    z[0,5,4]  R276      3.1100383400917053e-01
    z[0,5,4]  R277      3.9548650383949280e-01
    z[0,5,4]  R278      1.7993319034576416e-01
    z[0,5,4]  R279      -0.139604389667511
    z[0,5,4]  R280      -2.9799956083297729e-01
    z[0,5,4]  R281      -2.6043140888214111e-01
    z[0,5,4]  R282      -3.6377736926078796e-01
    z[0,5,4]  R283      -2.3236876353621483e-02
    z[0,5,4]  R284      -9.0952344238758087e-02
    z[0,5,4]  R285      -1.6560812294483185e-01
    z[0,5,4]  R286      2.5459712743759155e-01
    z[0,5,4]  R287      -1.6350033879280090e-01
    z[0,5,4]  R288      -1.6215749084949493e-01
    z[0,5,4]  R289      5.4695618152618408e-01
    z[0,5,4]  R290      6.3911923207342625e-03
    z[0,5,4]  R291      6.2209874391555786e-01
    z[0,5,4]  R292      -3.3168774843215942e-01
    z[0,5,4]  R293      -2.6557940989732742e-02
    z[0,5,4]  R294      3.8847821950912476e-01
    z[0,5,4]  R295      4.2505535483360291e-01
    z[0,5,4]  R296      -2.9733118414878845e-01
    z[0,5,4]  R297      -1.2829910218715668e-01
    z[0,5,4]  R298      -5.4046303033828735e-01
    z[0,5,4]  R299      -1.3540554046630859e-01
    z[0,5,4]  R300      2.3986333608627319e-01
    z[0,5,4]  R301      -1.1049579083919525e-01
    z[0,5,4]  R302      1.5271799638867378e-02
    z[0,5,4]  R303      -2.7204152941703796e-01
    z[0,5,4]  R304      1.8960656225681305e-01
    z[0,5,4]  R305      2.0966078341007233e-01
    z[0,5,4]  R306      -4.7962281107902527e-01
    z[0,5,4]  R307      -1.6468434035778046e-01
    z[0,5,4]  R308      7.1353238821029663e-01
    z[0,5,4]  R309      3.5656622052192688e-01
    z[0,5,4]  R310      2.0278191193938255e-02
    z[0,5,4]  R311      -2.1379841864109039e-01
    z[0,5,4]  R312      1.2891350686550140e-01
    z[0,5,4]  R313      -5.8095979690551758e-01
    z[0,5,4]  R314      3.6111617088317871e-01
    z[0,5,4]  R315      -4.2486825585365295e-01
    z[0,5,4]  R316      -1.2635989487171173e-01
    z[0,5,4]  R317      2.6446551084518433e-01
    z[0,5,4]  R318      1.8629802763462067e-01
    z[0,5,4]  R319      8.6344647407531738e-01
    z[0,5,4]  R320      5.4700754582881927e-02
    z[0,5,4]  R321      4.2301544547080994e-01
    z[0,5,4]  R322      -2.1201588213443756e-01
    z[0,5,4]  R323      3.5059813410043716e-02
    z[0,5,4]  R324      5.1355826854705811e-01
    z[0,5,4]  R325      -6.5954226255416870e-01
    z[0,5,4]  R326      -0.523227334022522
    z[0,5,4]  R327      -6.3495433330535889e-01
    z[0,5,4]  R328      -2.1799956262111664e-01
    z[0,5,4]  R329      -2.0397461950778961e-01
    z[0,5,4]  R330      3.1452763080596924e-01
    z[0,5,4]  R331      9.4894334673881531e-02
    z[0,5,4]  R332      6.2800779938697815e-02
    z[0,5,4]  R333      4.9770158529281616e-01
    z[0,5,4]  R334      -0.483572393655777
    z[0,5,4]  R335      -2.8351143002510071e-01
    z[0,5,4]  R336      -5.1582843065261841e-01
    z[0,5,4]  R337      -0.463644415140152
    z[0,5,4]  R338      -6.7330557107925415e-01
    z[0,5,4]  R339      -0.00819708127528429
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R266      -1
    z[0,5,5]  R267      1
    z[0,5,5]  R270      1.1591717600822449e-01
    z[0,5,5]  R271      -0.0569237619638443
    z[0,5,5]  R272      5.5946819484233856e-03
    z[0,5,5]  R273      -1.1520248651504517e-01
    z[0,5,5]  R274      4.3139973282814026e-01
    z[0,5,5]  R275      6.7250800132751465e-01
    z[0,5,5]  R276      8.0121923238039017e-03
    z[0,5,5]  R277      2.2366911172866821e-01
    z[0,5,5]  R278      -1.5002716332674026e-02
    z[0,5,5]  R279      0.0206812284886837
    z[0,5,5]  R280      -3.4997123479843140e-01
    z[0,5,5]  R281      4.9335736548528075e-04
    z[0,5,5]  R282      6.0575842857360840e-01
    z[0,5,5]  R283      3.4417361021041870e-02
    z[0,5,5]  R284      -4.7730904817581177e-01
    z[0,5,5]  R285      6.2939971685409546e-01
    z[0,5,5]  R286      5.7388257980346680e-01
    z[0,5,5]  R287      -5.7849872857332230e-02
    z[0,5,5]  R288      -3.3820700645446777e-01
    z[0,5,5]  R289      -1.1151006072759628e-01
    z[0,5,5]  R290      3.0157443881034851e-01
    z[0,5,5]  R291      9.9785745143890381e-02
    z[0,5,5]  R292      9.8893940448760986e-02
    z[0,5,5]  R293      -2.2379116714000702e-01
    z[0,5,5]  R294      2.4236758053302765e-01
    z[0,5,5]  R295      3.7398687005043030e-01
    z[0,5,5]  R296      -9.7883641719818115e-03
    z[0,5,5]  R297      7.4246022850275040e-03
    z[0,5,5]  R298      -1.1341685056686401e-01
    z[0,5,5]  R299      2.2863309085369110e-01
    z[0,5,5]  R300      -0.0593063160777092
    z[0,5,5]  R301      -1.0239279270172119e-01
    z[0,5,5]  R302      1.3108867406845093e-01
    z[0,5,5]  R303      -2.9137039557099342e-02
    z[0,5,5]  R304      4.7710424661636353e-01
    z[0,5,5]  R305      6.1132764816284180e-01
    z[0,5,5]  R306      -2.5607712566852570e-02
    z[0,5,5]  R307      -1.0598448663949966e-01
    z[0,5,5]  R308      0.0591808557510376
    z[0,5,5]  R309      -1.3488078117370605e-01
    z[0,5,5]  R310      2.9261562228202820e-01
    z[0,5,5]  R311      2.7521508932113647e-01
    z[0,5,5]  R312      -6.4297604560852051e-01
    z[0,5,5]  R313      2.6581525802612305e-01
    z[0,5,5]  R314      -7.7289767563343048e-02
    z[0,5,5]  R315      -0.688133716583252
    z[0,5,5]  R316      -4.5649823546409607e-01
    z[0,5,5]  R317      -3.7620106339454651e-01
    z[0,5,5]  R318      -4.7036531567573547e-01
    z[0,5,5]  R319      -2.5837129354476929e-01
    z[0,5,5]  R320      1.5638881921768188e-01
    z[0,5,5]  R321      7.5854189693927765e-02
    z[0,5,5]  R322      -2.7757662534713745e-01
    z[0,5,5]  R323      -4.5461425185203552e-01
    z[0,5,5]  R324      -3.6846312880516052e-01
    z[0,5,5]  R325      -4.2448961175978184e-03
    z[0,5,5]  R326      4.9633193761110306e-02
    z[0,5,5]  R327      -2.2574605047702789e-01
    z[0,5,5]  R328      -6.1993849277496338e-01
    z[0,5,5]  R329      -0.504638671875
    z[0,5,5]  R330      2.2373767197132111e-01
    z[0,5,5]  R331      2.8344575315713882e-02
    z[0,5,5]  R332      -2.1390955150127411e-01
    z[0,5,5]  R333      2.4122843146324158e-01
    z[0,5,5]  R334      -0.284828782081604
    z[0,5,5]  R335      -4.4182983040809631e-01
    z[0,5,5]  R336      -1.4362284541130066e-01
    z[0,5,5]  R337      -6.5854269266128540e-01
    z[0,5,5]  R338      -3.1300477683544159e-02
    z[0,5,5]  R339      3.6749291419982910e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R268      -1
    z[0,5,6]  R269      1
    z[0,5,6]  R270      -4.0916001796722412e-01
    z[0,5,6]  R271      -4.9556735157966614e-01
    z[0,5,6]  R272      -5.4662948846817017e-01
    z[0,5,6]  R273      -0.00693955272436142
    z[0,5,6]  R274      -3.1225019693374634e-01
    z[0,5,6]  R275      -1.8499717116355896e-02
    z[0,5,6]  R276      1.6012579202651978e-01
    z[0,5,6]  R277      -3.2182909548282623e-02
    z[0,5,6]  R278      -1.8483851850032806e-01
    z[0,5,6]  R279      4.0805283933877945e-02
    z[0,5,6]  R280      1.9043911248445511e-02
    z[0,5,6]  R281      2.6937791705131531e-01
    z[0,5,6]  R282      7.8737903386354446e-03
    z[0,5,6]  R283      4.4856214523315430e-01
    z[0,5,6]  R284      1.9325365126132965e-01
    z[0,5,6]  R285      -0.00127637037076056
    z[0,5,6]  R286      3.4791791439056396e-01
    z[0,5,6]  R287      -1.0738164931535721e-01
    z[0,5,6]  R288      5.4744761437177658e-02
    z[0,5,6]  R289      -2.7525332570075989e-01
    z[0,5,6]  R290      -3.4992974996566772e-01
    z[0,5,6]  R291      -6.9987498223781586e-02
    z[0,5,6]  R292      3.4656971693038940e-01
    z[0,5,6]  R293      4.7889653593301773e-02
    z[0,5,6]  R294      2.4893535301089287e-02
    z[0,5,6]  R295      -2.7149191498756409e-01
    z[0,5,6]  R296      -3.9874041080474854e-01
    z[0,5,6]  R297      4.7178462147712708e-01
    z[0,5,6]  R298      -5.0536626577377319e-01
    z[0,5,6]  R299      1.1487862467765808e-01
    z[0,5,6]  R300      -2.1957848966121674e-01
    z[0,5,6]  R301      2.2452560067176819e-01
    z[0,5,6]  R302      4.5085042715072632e-02
    z[0,5,6]  R303      -2.5616922974586487e-01
    z[0,5,6]  R304      -2.3681713640689850e-01
    z[0,5,6]  R305      1.5807650983333588e-01
    z[0,5,6]  R306      3.0263975262641907e-01
    z[0,5,6]  R307      -8.2975822687149048e-01
    z[0,5,6]  R308      3.3224666118621826e-01
    z[0,5,6]  R309      3.8006670773029327e-02
    z[0,5,6]  R310      -0.523121178150177
    z[0,5,6]  R311      5.0070118159055710e-02
    z[0,5,6]  R312      -2.8390547633171082e-01
    z[0,5,6]  R313      -1.9579039886593819e-02
    z[0,5,6]  R314      -3.3382558822631836e-01
    z[0,5,6]  R315      3.9094928652048111e-02
    z[0,5,6]  R316      -3.0160054564476013e-01
    z[0,5,6]  R317      2.5230368971824646e-01
    z[0,5,6]  R318      0.0304279662668705
    z[0,5,6]  R319      1.5494583547115326e-01
    z[0,5,6]  R320      -2.0397663116455078e-01
    z[0,5,6]  R321      4.6544083952903748e-01
    z[0,5,6]  R322      0.469174861907959
    z[0,5,6]  R323      9.3000024557113647e-02
    z[0,5,6]  R324      8.3460107445716858e-02
    z[0,5,6]  R325      -4.2939484119415283e-01
    z[0,5,6]  R326      -2.0302060246467590e-01
    z[0,5,6]  R327      4.7779113054275513e-01
    z[0,5,6]  R328      -3.1680914759635925e-01
    z[0,5,6]  R329      2.6725429296493530e-01
    z[0,5,6]  R330      2.8804758191108704e-01
    z[0,5,6]  R331      1.3155448436737061e-01
    z[0,5,6]  R332      3.9790770411491394e-01
    z[0,5,6]  R333      4.2352247983217239e-02
    z[0,5,6]  R334      4.9535080790519714e-01
    z[0,5,6]  R335      -1.9908405840396881e-01
    z[0,5,6]  R336      -4.7892707586288452e-01
    z[0,5,6]  R337      -1.9740824401378632e-01
    z[0,5,6]  R338      -3.8281716406345367e-02
    z[0,5,6]  R339      -3.3507876098155975e-02
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R340      -1
    z[5,0,0]  R341      1
    z[5,0,0]  R354      -5.7996219396591187e-01
    z[5,0,0]  R355      -7.9358226060867310e-01
    z[5,0,0]  R356      -0.518456757068634
    z[5,0,0]  R357      -6.3096517324447632e-01
    z[5,0,0]  R358      -3.6290261149406433e-01
    z[5,0,0]  R359      -5.1928228139877319e-01
    z[5,0,0]  R360      -2.2811952233314514e-01
    z[5,0,0]  R361      4.1172024607658386e-01
    z[5,0,0]  R362      5.6369763612747192e-01
    z[5,0,0]  R363      6.7790520191192627e-01
    z[5,0,0]  R364      2.5977733731269836e-01
    z[5,0,0]  R365      3.2061547040939331e-01
    z[5,0,0]  R366      1.3840182125568390e-01
    z[5,0,0]  R367      -3.0481213331222534e-01
    z[5,0,0]  R368      -5.0336980819702148e-01
    z[5,0,0]  R369      -1.9695284962654114e-01
    z[5,0,0]  R370      -1.1693647503852844e-01
    z[5,0,0]  R371      5.1186162233352661e-01
    z[5,0,0]  R372      6.1486173421144485e-02
    z[5,0,0]  R373      0.04227314889431
    z[5,0,0]  R374      -3.9250290393829346e-01
    z[5,0,0]  R375      2.1174551546573639e-01
    z[5,0,0]  R376      -7.1806021034717560e-02
    z[5,0,0]  R377      -3.5093218088150024e-02
    z[5,0,0]  R378      3.3915615081787109e-01
    z[5,0,0]  R379      -1.1973375082015991e-01
    z[5,0,0]  R380      -3.8449484109878540e-01
    z[5,0,0]  R381      -1.7956182360649109e-01
    z[5,0,0]  R382      -0.182621568441391
    z[5,0,0]  R383      1.0773085057735443e-01
    z[5,0,0]  R384      -0.0769742876291275
    z[5,0,0]  R385      3.2144537568092346e-01
    z[5,0,0]  R386      1.9060429930686951e-01
    z[5,0,0]  R387      2.5585165619850159e-01
    z[5,0,0]  R388      -2.3111756891012192e-02
    z[5,0,0]  R389      3.3616542816162109e-01
    z[5,0,0]  R390      2.4032276868820190e-01
    z[5,0,0]  R391      -8.9384570717811584e-02
    z[5,0,0]  R392      -2.1971440315246582e-01
    z[5,0,0]  R393      -2.1087791025638580e-01
    z[5,0,0]  R394      6.3193216919898987e-02
    z[5,0,0]  R395      4.9101456999778748e-02
    z[5,0,0]  R396      -1.6371060907840729e-01
    z[5,0,0]  R397      3.8743871450424194e-01
    z[5,0,0]  R398      -1.4517836272716522e-01
    z[5,0,0]  R399      4.0826085209846497e-01
    z[5,0,0]  R400      4.9306243658065796e-01
    z[5,0,0]  R401      4.5678767561912537e-01
    z[5,0,0]  R402      4.7633597254753113e-01
    z[5,0,0]  R403      6.7837619781494141e-01
    z[5,0,0]  R404      3.7534731626510620e-01
    z[5,0,0]  R405      3.1785193830728531e-02
    z[5,0,0]  R406      0.476936012506485
    z[5,0,0]  R407      4.5526400208473206e-01
    z[5,0,0]  R408      -4.7595086693763733e-01
    z[5,0,0]  R409      -1.4402058720588684e-01
    z[5,0,0]  R410      1.4602072536945343e-01
    z[5,0,0]  R411      -8.8987782597541809e-02
    z[5,0,0]  R412      6.5973460674285889e-02
    z[5,0,0]  R413      -1.0765879601240158e-01
    z[5,0,0]  R414      1.4987038075923920e-01
    z[5,0,0]  R415      -4.1974384337663651e-02
    z[5,0,0]  R416      2.8343917801976204e-03
    z[5,0,0]  R417      -0.399278849363327
    z[5,0,0]  R418      -2.4735212326049805e-01
    z[5,0,0]  R419      -6.7140311002731323e-02
    z[5,0,0]  R420      -4.1777658462524414e-01
    z[5,0,0]  R421      6.7546620965003967e-02
    z[5,0,0]  R422      -1.3360929489135742e-01
    z[5,0,0]  R423      -5.4297035932540894e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R342      -1
    z[5,0,1]  R343      1
    z[5,0,1]  R354      2.3080082237720490e-01
    z[5,0,1]  R355      -0.0527375154197216
    z[5,0,1]  R356      2.0245993137359619e-01
    z[5,0,1]  R357      2.6000419165939093e-03
    z[5,0,1]  R358      -2.0599098876118660e-02
    z[5,0,1]  R359      -5.4028481245040894e-02
    z[5,0,1]  R360      6.0787373781204224e-01
    z[5,0,1]  R361      6.5360605716705322e-02
    z[5,0,1]  R362      2.1668045222759247e-01
    z[5,0,1]  R363      -1.9635602831840515e-02
    z[5,0,1]  R364      -7.4423557519912720e-01
    z[5,0,1]  R365      -7.7088785171508789e-01
    z[5,0,1]  R366      -6.4877432584762573e-01
    z[5,0,1]  R367      -6.7080420255661011e-01
    z[5,0,1]  R368      -0.663345456123352
    z[5,0,1]  R369      -5.3227263689041138e-01
    z[5,0,1]  R370      -0.687248170375824
    z[5,0,1]  R371      -0.569867730140686
    z[5,0,1]  R372      -0.77773118019104
    z[5,0,1]  R373      -3.8848367333412170e-01
    z[5,0,1]  R374      -8.5708284378051758e-01
    z[5,0,1]  R375      -0.671985387802124
    z[5,0,1]  R376      -7.8402262926101685e-01
    z[5,0,1]  R377      -0.723905086517334
    z[5,0,1]  R378      -5.6439733505249023e-01
    z[5,0,1]  R379      -0.00883125513792038
    z[5,0,1]  R380      -0.103699691593647
    z[5,0,1]  R381      5.3361009806394577e-02
    z[5,0,1]  R382      5.5084377527236938e-01
    z[5,0,1]  R383      5.8834302425384521e-01
    z[5,0,1]  R384      -0.764907956123352
    z[5,0,1]  R385      -9.2994827032089233e-01
    z[5,0,1]  R386      -7.1044009923934937e-01
    z[5,0,1]  R387      -6.4333051443099976e-01
    z[5,0,1]  R388      2.3180831968784332e-01
    z[5,0,1]  R389      -6.7275100946426392e-01
    z[5,0,1]  R390      2.0524153113365173e-01
    z[5,0,1]  R391      7.5061500072479248e-02
    z[5,0,1]  R392      4.4072076678276062e-01
    z[5,0,1]  R393      8.9551174640655518e-01
    z[5,0,1]  R394      8.2392197847366333e-01
    z[5,0,1]  R395      6.8016415834426880e-01
    z[5,0,1]  R396      7.7156919240951538e-01
    z[5,0,1]  R397      7.2993814945220947e-01
    z[5,0,1]  R398      5.9321910142898560e-01
    z[5,0,1]  R399      5.7834815979003906e-01
    z[5,0,1]  R400      6.2786775827407837e-01
    z[5,0,1]  R401      5.5659162998199463e-01
    z[5,0,1]  R402      -4.3671395629644394e-02
    z[5,0,1]  R403      3.2095119357109070e-02
    z[5,0,1]  R404      -4.9491804838180542e-01
    z[5,0,1]  R405      -6.5591049194335938e-01
    z[5,0,1]  R406      -0.452214777469635
    z[5,0,1]  R407      -7.0627099275588989e-01
    z[5,0,1]  R408      -5.5401831865310669e-01
    z[5,0,1]  R409      -4.3831315636634827e-01
    z[5,0,1]  R410      -5.4018628597259521e-01
    z[5,0,1]  R411      -5.2345865964889526e-01
    z[5,0,1]  R412      -8.2594347000122070e-01
    z[5,0,1]  R413      -5.3371143341064453e-01
    z[5,0,1]  R414      -8.2987940311431885e-01
    z[5,0,1]  R415      -6.1525815725326538e-01
    z[5,0,1]  R416      -7.6073414087295532e-01
    z[5,0,1]  R417      -0.863974928855896
    z[5,0,1]  R418      -8.1962603330612183e-01
    z[5,0,1]  R419      -3.3098754286766052e-01
    z[5,0,1]  R420      -7.0585000514984131e-01
    z[5,0,1]  R421      6.5138167142868042e-01
    z[5,0,1]  R422      -6.0313898324966431e-01
    z[5,0,1]  R423      -4.6534386277198792e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R344      -1
    z[5,0,2]  R345      1
    z[5,0,2]  R354      4.1230174899101257e-01
    z[5,0,2]  R355      3.5707753896713257e-01
    z[5,0,2]  R356      8.0414557456970215e-01
    z[5,0,2]  R357      6.6721254587173462e-01
    z[5,0,2]  R358      6.7652350664138794e-01
    z[5,0,2]  R359      2.7625033259391785e-01
    z[5,0,2]  R360      1.0251188278198242e-01
    z[5,0,2]  R361      -1.7896650359034538e-02
    z[5,0,2]  R362      -2.8267744928598404e-03
    z[5,0,2]  R363      5.4159498214721680e-01
    z[5,0,2]  R364      1.3479290902614594e-01
    z[5,0,2]  R365      2.1449199318885803e-01
    z[5,0,2]  R366      1.9075600802898407e-01
    z[5,0,2]  R367      -9.1220803558826447e-02
    z[5,0,2]  R368      -7.3211520910263062e-02
    z[5,0,2]  R369      2.7145119383931160e-02
    z[5,0,2]  R370      -3.1677749752998352e-01
    z[5,0,2]  R371      3.5254955291748047e-01
    z[5,0,2]  R372      -5.6832976639270782e-02
    z[5,0,2]  R373      9.8804473876953125e-02
    z[5,0,2]  R374      -2.0342530310153961e-01
    z[5,0,2]  R375      2.1533285081386566e-01
    z[5,0,2]  R376      -1.9392953813076019e-01
    z[5,0,2]  R377      -3.7211760878562927e-01
    z[5,0,2]  R378      3.8335654139518738e-01
    z[5,0,2]  R379      -2.6121586561203003e-01
    z[5,0,2]  R380      -4.1250422596931458e-01
    z[5,0,2]  R381      -4.9788277596235275e-02
    z[5,0,2]  R382      1.2829124927520752e-01
    z[5,0,2]  R383      2.3098066449165344e-01
    z[5,0,2]  R384      3.1553870439529419e-01
    z[5,0,2]  R385      0.0686025395989418
    z[5,0,2]  R386      -4.4498926401138306e-01
    z[5,0,2]  R387      -4.5791637897491455e-01
    z[5,0,2]  R388      1.6195403039455414e-01
    z[5,0,2]  R389      -2.5885558128356934e-01
    z[5,0,2]  R390      2.4468574672937393e-02
    z[5,0,2]  R391      3.8558891415596008e-01
    z[5,0,2]  R392      -1.9540810957551003e-02
    z[5,0,2]  R393      -5.6084785610437393e-02
    z[5,0,2]  R394      2.4155406281352043e-02
    z[5,0,2]  R395      5.0916379690170288e-01
    z[5,0,2]  R396      2.7194762229919434e-01
    z[5,0,2]  R397      2.7120593190193176e-01
    z[5,0,2]  R398      -0.0447147935628891
    z[5,0,2]  R399      -8.6999922990798950e-02
    z[5,0,2]  R400      2.9580566287040710e-01
    z[5,0,2]  R401      4.2334303259849548e-01
    z[5,0,2]  R402      2.2294847294688225e-02
    z[5,0,2]  R403      -8.3603955805301666e-02
    z[5,0,2]  R404      6.1550474166870117e-01
    z[5,0,2]  R405      3.8957926630973816e-01
    z[5,0,2]  R406      0.15157450735569
    z[5,0,2]  R407      2.9771193861961365e-01
    z[5,0,2]  R408      1.3639959692955017e-01
    z[5,0,2]  R409      -3.1166866421699524e-01
    z[5,0,2]  R410      1.3838428258895874e-01
    z[5,0,2]  R411      -6.9160008430480957e-01
    z[5,0,2]  R412      -1.3008992373943329e-01
    z[5,0,2]  R413      4.6579241752624512e-01
    z[5,0,2]  R414      1.8765021860599518e-01
    z[5,0,2]  R415      -3.0872235074639320e-02
    z[5,0,2]  R416      -3.5853850841522217e-01
    z[5,0,2]  R417      -1.5256865322589874e-01
    z[5,0,2]  R418      -2.3540411889553070e-01
    z[5,0,2]  R419      6.5041255950927734e-01
    z[5,0,2]  R420      -2.5383287668228149e-01
    z[5,0,2]  R421      -5.7006269693374634e-01
    z[5,0,2]  R422      -1.8810448050498962e-01
    z[5,0,2]  R423      5.6214940547943115e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R346      -1
    z[5,0,3]  R347      1
    z[5,0,3]  R354      5.7542663812637329e-01
    z[5,0,3]  R355      4.0845578908920288e-01
    z[5,0,3]  R356      1.5528170764446259e-01
    z[5,0,3]  R357      1.2737837433815002e-01
    z[5,0,3]  R358      3.0088528990745544e-01
    z[5,0,3]  R359      4.5655813813209534e-01
    z[5,0,3]  R360      -4.9563857913017273e-01
    z[5,0,3]  R361      -3.1470906734466553e-01
    z[5,0,3]  R362      1.1076045036315918e-01
    z[5,0,3]  R363      -3.1615990400314331e-01
    z[5,0,3]  R364      2.7734089642763138e-02
    z[5,0,3]  R365      -3.6465135216712952e-01
    z[5,0,3]  R366      -1.1362092941999435e-01
    z[5,0,3]  R367      -2.0058588683605194e-01
    z[5,0,3]  R368      -2.3111377656459808e-01
    z[5,0,3]  R369      -1.4693267643451691e-01
    z[5,0,3]  R370      3.1360420584678650e-01
    z[5,0,3]  R371      -1.1760506778955460e-01
    z[5,0,3]  R372      3.6228078603744507e-01
    z[5,0,3]  R373      -3.5031415522098541e-02
    z[5,0,3]  R374      -3.0206680297851562e-02
    z[5,0,3]  R375      2.3643206059932709e-01
    z[5,0,3]  R376      2.0475223660469055e-02
    z[5,0,3]  R377      3.4598565101623535e-01
    z[5,0,3]  R378      -1.1399001628160477e-01
    z[5,0,3]  R379      -5.4585546255111694e-01
    z[5,0,3]  R380      -5.9481322765350342e-01
    z[5,0,3]  R381      -5.2916777133941650e-01
    z[5,0,3]  R382      -3.3844679594039917e-01
    z[5,0,3]  R383      -4.7032311558723450e-01
    z[5,0,3]  R384      2.7833151817321777e-01
    z[5,0,3]  R385      6.9129839539527893e-03
    z[5,0,3]  R386      -2.2999511659145355e-01
    z[5,0,3]  R387      -5.7330571115016937e-02
    z[5,0,3]  R388      -5.9929913282394409e-01
    z[5,0,3]  R389      -2.2839865088462830e-01
    z[5,0,3]  R390      -6.1922895908355713e-01
    z[5,0,3]  R391      -0.387405127286911
    z[5,0,3]  R392      -5.4892927408218384e-01
    z[5,0,3]  R393      -1.1917480081319809e-01
    z[5,0,3]  R394      -0.0815090611577034
    z[5,0,3]  R395      -5.7429186999797821e-02
    z[5,0,3]  R396      -1.7642995342612267e-02
    z[5,0,3]  R397      -0.0578574538230896
    z[5,0,3]  R398      8.0894403159618378e-02
    z[5,0,3]  R399      -1.4554880559444427e-01
    z[5,0,3]  R400      3.9082306623458862e-01
    z[5,0,3]  R401      3.0799075961112976e-01
    z[5,0,3]  R402      8.3900749683380127e-01
    z[5,0,3]  R403      7.1428561210632324e-01
    z[5,0,3]  R404      1.5387716889381409e-01
    z[5,0,3]  R405      -5.2593696117401123e-01
    z[5,0,3]  R406      -2.1382157504558563e-01
    z[5,0,3]  R407      4.8487573862075806e-02
    z[5,0,3]  R408      -4.1771572828292847e-01
    z[5,0,3]  R409      -5.1616907119750977e-01
    z[5,0,3]  R410      -3.9053648710250854e-01
    z[5,0,3]  R411      4.4514226913452148e-01
    z[5,0,3]  R412      3.9098021388053894e-01
    z[5,0,3]  R413      3.1502255797386169e-01
    z[5,0,3]  R414      2.0046825706958771e-01
    z[5,0,3]  R415      4.6570390462875366e-01
    z[5,0,3]  R416      -0.22982257604599
    z[5,0,3]  R417      -1.3328652083873749e-01
    z[5,0,3]  R418      3.6576956510543823e-02
    z[5,0,3]  R419      -2.6202449202537537e-01
    z[5,0,3]  R420      -1.2374115735292435e-01
    z[5,0,3]  R421      -0.0840914323925972
    z[5,0,3]  R422      1.5043315291404724e-01
    z[5,0,3]  R423      2.9802948236465454e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R348      -1
    z[5,0,4]  R349      1
    z[5,0,4]  R354      2.3986333608627319e-01
    z[5,0,4]  R355      -1.1049579083919525e-01
    z[5,0,4]  R356      1.5271799638867378e-02
    z[5,0,4]  R357      -2.7204152941703796e-01
    z[5,0,4]  R358      1.8960656225681305e-01
    z[5,0,4]  R359      2.0966078341007233e-01
    z[5,0,4]  R360      -4.7962281107902527e-01
    z[5,0,4]  R361      -1.6468434035778046e-01
    z[5,0,4]  R362      7.1353238821029663e-01
    z[5,0,4]  R363      3.5656622052192688e-01
    z[5,0,4]  R364      2.0278191193938255e-02
    z[5,0,4]  R365      -2.1379841864109039e-01
    z[5,0,4]  R366      1.2891350686550140e-01
    z[5,0,4]  R367      -5.8095979690551758e-01
    z[5,0,4]  R368      3.6111617088317871e-01
    z[5,0,4]  R369      -4.2486825585365295e-01
    z[5,0,4]  R370      -1.2635989487171173e-01
    z[5,0,4]  R371      2.6446551084518433e-01
    z[5,0,4]  R372      1.8629802763462067e-01
    z[5,0,4]  R373      8.6344647407531738e-01
    z[5,0,4]  R374      5.4700754582881927e-02
    z[5,0,4]  R375      4.2301544547080994e-01
    z[5,0,4]  R376      -2.1201588213443756e-01
    z[5,0,4]  R377      3.5059813410043716e-02
    z[5,0,4]  R378      5.1355826854705811e-01
    z[5,0,4]  R379      -6.5954226255416870e-01
    z[5,0,4]  R380      -0.523227334022522
    z[5,0,4]  R381      -6.3495433330535889e-01
    z[5,0,4]  R382      -2.1799956262111664e-01
    z[5,0,4]  R383      -2.0397461950778961e-01
    z[5,0,4]  R384      3.1452763080596924e-01
    z[5,0,4]  R385      9.4894334673881531e-02
    z[5,0,4]  R386      6.2800779938697815e-02
    z[5,0,4]  R387      4.9770158529281616e-01
    z[5,0,4]  R388      -0.483572393655777
    z[5,0,4]  R389      -2.8351143002510071e-01
    z[5,0,4]  R390      -5.1582843065261841e-01
    z[5,0,4]  R391      -0.463644415140152
    z[5,0,4]  R392      -6.7330557107925415e-01
    z[5,0,4]  R393      -0.00819708127528429
    z[5,0,4]  R394      -3.5928165912628174e-01
    z[5,0,4]  R395      -1.5359874069690704e-01
    z[5,0,4]  R396      6.9122023880481720e-02
    z[5,0,4]  R397      -0.476299911737442
    z[5,0,4]  R398      5.7867527008056641e-01
    z[5,0,4]  R399      -1.3218839466571808e-01
    z[5,0,4]  R400      3.1100383400917053e-01
    z[5,0,4]  R401      3.9548650383949280e-01
    z[5,0,4]  R402      1.7993319034576416e-01
    z[5,0,4]  R403      -0.139604389667511
    z[5,0,4]  R404      -2.9799956083297729e-01
    z[5,0,4]  R405      -2.6043140888214111e-01
    z[5,0,4]  R406      -3.6377736926078796e-01
    z[5,0,4]  R407      -2.3236876353621483e-02
    z[5,0,4]  R408      -9.0952344238758087e-02
    z[5,0,4]  R409      -1.6560812294483185e-01
    z[5,0,4]  R410      2.5459712743759155e-01
    z[5,0,4]  R411      -1.6350033879280090e-01
    z[5,0,4]  R412      -1.6215749084949493e-01
    z[5,0,4]  R413      5.4695618152618408e-01
    z[5,0,4]  R414      6.3911923207342625e-03
    z[5,0,4]  R415      6.2209874391555786e-01
    z[5,0,4]  R416      -3.3168774843215942e-01
    z[5,0,4]  R417      -2.6557940989732742e-02
    z[5,0,4]  R418      3.8847821950912476e-01
    z[5,0,4]  R419      4.2505535483360291e-01
    z[5,0,4]  R420      -2.9733118414878845e-01
    z[5,0,4]  R421      -1.2829910218715668e-01
    z[5,0,4]  R422      -5.4046303033828735e-01
    z[5,0,4]  R423      -1.3540554046630859e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R350      -1
    z[5,0,5]  R351      1
    z[5,0,5]  R354      -0.0593063160777092
    z[5,0,5]  R355      -1.0239279270172119e-01
    z[5,0,5]  R356      1.3108867406845093e-01
    z[5,0,5]  R357      -2.9137039557099342e-02
    z[5,0,5]  R358      4.7710424661636353e-01
    z[5,0,5]  R359      6.1132764816284180e-01
    z[5,0,5]  R360      -2.5607712566852570e-02
    z[5,0,5]  R361      -1.0598448663949966e-01
    z[5,0,5]  R362      0.0591808557510376
    z[5,0,5]  R363      -1.3488078117370605e-01
    z[5,0,5]  R364      2.9261562228202820e-01
    z[5,0,5]  R365      2.7521508932113647e-01
    z[5,0,5]  R366      -6.4297604560852051e-01
    z[5,0,5]  R367      2.6581525802612305e-01
    z[5,0,5]  R368      -7.7289767563343048e-02
    z[5,0,5]  R369      -0.688133716583252
    z[5,0,5]  R370      -4.5649823546409607e-01
    z[5,0,5]  R371      -3.7620106339454651e-01
    z[5,0,5]  R372      -4.7036531567573547e-01
    z[5,0,5]  R373      -2.5837129354476929e-01
    z[5,0,5]  R374      1.5638881921768188e-01
    z[5,0,5]  R375      7.5854189693927765e-02
    z[5,0,5]  R376      -2.7757662534713745e-01
    z[5,0,5]  R377      -4.5461425185203552e-01
    z[5,0,5]  R378      -3.6846312880516052e-01
    z[5,0,5]  R379      -4.2448961175978184e-03
    z[5,0,5]  R380      4.9633193761110306e-02
    z[5,0,5]  R381      -2.2574605047702789e-01
    z[5,0,5]  R382      -6.1993849277496338e-01
    z[5,0,5]  R383      -0.504638671875
    z[5,0,5]  R384      2.2373767197132111e-01
    z[5,0,5]  R385      2.8344575315713882e-02
    z[5,0,5]  R386      -2.1390955150127411e-01
    z[5,0,5]  R387      2.4122843146324158e-01
    z[5,0,5]  R388      -0.284828782081604
    z[5,0,5]  R389      -4.4182983040809631e-01
    z[5,0,5]  R390      -1.4362284541130066e-01
    z[5,0,5]  R391      -6.5854269266128540e-01
    z[5,0,5]  R392      -3.1300477683544159e-02
    z[5,0,5]  R393      3.6749291419982910e-01
    z[5,0,5]  R394      1.1591717600822449e-01
    z[5,0,5]  R395      -0.0569237619638443
    z[5,0,5]  R396      5.5946819484233856e-03
    z[5,0,5]  R397      -1.1520248651504517e-01
    z[5,0,5]  R398      4.3139973282814026e-01
    z[5,0,5]  R399      6.7250800132751465e-01
    z[5,0,5]  R400      8.0121923238039017e-03
    z[5,0,5]  R401      2.2366911172866821e-01
    z[5,0,5]  R402      -1.5002716332674026e-02
    z[5,0,5]  R403      0.0206812284886837
    z[5,0,5]  R404      -3.4997123479843140e-01
    z[5,0,5]  R405      4.9335736548528075e-04
    z[5,0,5]  R406      6.0575842857360840e-01
    z[5,0,5]  R407      3.4417361021041870e-02
    z[5,0,5]  R408      -4.7730904817581177e-01
    z[5,0,5]  R409      6.2939971685409546e-01
    z[5,0,5]  R410      5.7388257980346680e-01
    z[5,0,5]  R411      -5.7849872857332230e-02
    z[5,0,5]  R412      -3.3820700645446777e-01
    z[5,0,5]  R413      -1.1151006072759628e-01
    z[5,0,5]  R414      3.0157443881034851e-01
    z[5,0,5]  R415      9.9785745143890381e-02
    z[5,0,5]  R416      9.8893940448760986e-02
    z[5,0,5]  R417      -2.2379116714000702e-01
    z[5,0,5]  R418      2.4236758053302765e-01
    z[5,0,5]  R419      3.7398687005043030e-01
    z[5,0,5]  R420      -9.7883641719818115e-03
    z[5,0,5]  R421      7.4246022850275040e-03
    z[5,0,5]  R422      -1.1341685056686401e-01
    z[5,0,5]  R423      2.2863309085369110e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R352      -1
    z[5,0,6]  R353      1
    z[5,0,6]  R354      -2.1957848966121674e-01
    z[5,0,6]  R355      2.2452560067176819e-01
    z[5,0,6]  R356      4.5085042715072632e-02
    z[5,0,6]  R357      -2.5616922974586487e-01
    z[5,0,6]  R358      -2.3681713640689850e-01
    z[5,0,6]  R359      1.5807650983333588e-01
    z[5,0,6]  R360      3.0263975262641907e-01
    z[5,0,6]  R361      -8.2975822687149048e-01
    z[5,0,6]  R362      3.3224666118621826e-01
    z[5,0,6]  R363      3.8006670773029327e-02
    z[5,0,6]  R364      -0.523121178150177
    z[5,0,6]  R365      5.0070118159055710e-02
    z[5,0,6]  R366      -2.8390547633171082e-01
    z[5,0,6]  R367      -1.9579039886593819e-02
    z[5,0,6]  R368      -3.3382558822631836e-01
    z[5,0,6]  R369      3.9094928652048111e-02
    z[5,0,6]  R370      -3.0160054564476013e-01
    z[5,0,6]  R371      2.5230368971824646e-01
    z[5,0,6]  R372      0.0304279662668705
    z[5,0,6]  R373      1.5494583547115326e-01
    z[5,0,6]  R374      -2.0397663116455078e-01
    z[5,0,6]  R375      4.6544083952903748e-01
    z[5,0,6]  R376      0.469174861907959
    z[5,0,6]  R377      9.3000024557113647e-02
    z[5,0,6]  R378      8.3460107445716858e-02
    z[5,0,6]  R379      -4.2939484119415283e-01
    z[5,0,6]  R380      -2.0302060246467590e-01
    z[5,0,6]  R381      4.7779113054275513e-01
    z[5,0,6]  R382      -3.1680914759635925e-01
    z[5,0,6]  R383      2.6725429296493530e-01
    z[5,0,6]  R384      2.8804758191108704e-01
    z[5,0,6]  R385      1.3155448436737061e-01
    z[5,0,6]  R386      3.9790770411491394e-01
    z[5,0,6]  R387      4.2352247983217239e-02
    z[5,0,6]  R388      4.9535080790519714e-01
    z[5,0,6]  R389      -1.9908405840396881e-01
    z[5,0,6]  R390      -4.7892707586288452e-01
    z[5,0,6]  R391      -1.9740824401378632e-01
    z[5,0,6]  R392      -3.8281716406345367e-02
    z[5,0,6]  R393      -3.3507876098155975e-02
    z[5,0,6]  R394      -4.0916001796722412e-01
    z[5,0,6]  R395      -4.9556735157966614e-01
    z[5,0,6]  R396      -5.4662948846817017e-01
    z[5,0,6]  R397      -0.00693955272436142
    z[5,0,6]  R398      -3.1225019693374634e-01
    z[5,0,6]  R399      -1.8499717116355896e-02
    z[5,0,6]  R400      1.6012579202651978e-01
    z[5,0,6]  R401      -3.2182909548282623e-02
    z[5,0,6]  R402      -1.8483851850032806e-01
    z[5,0,6]  R403      4.0805283933877945e-02
    z[5,0,6]  R404      1.9043911248445511e-02
    z[5,0,6]  R405      2.6937791705131531e-01
    z[5,0,6]  R406      7.8737903386354446e-03
    z[5,0,6]  R407      4.4856214523315430e-01
    z[5,0,6]  R408      1.9325365126132965e-01
    z[5,0,6]  R409      -0.00127637037076056
    z[5,0,6]  R410      3.4791791439056396e-01
    z[5,0,6]  R411      -1.0738164931535721e-01
    z[5,0,6]  R412      5.4744761437177658e-02
    z[5,0,6]  R413      -2.7525332570075989e-01
    z[5,0,6]  R414      -3.4992974996566772e-01
    z[5,0,6]  R415      -6.9987498223781586e-02
    z[5,0,6]  R416      3.4656971693038940e-01
    z[5,0,6]  R417      4.7889653593301773e-02
    z[5,0,6]  R418      2.4893535301089287e-02
    z[5,0,6]  R419      -2.7149191498756409e-01
    z[5,0,6]  R420      -3.9874041080474854e-01
    z[5,0,6]  R421      4.7178462147712708e-01
    z[5,0,6]  R422      -5.0536626577377319e-01
    z[5,0,6]  R423      1.1487862467765808e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R468      -1
    z[1,2,0]  R469      1
    z[1,2,0]  R482      2.7373647689819336e-01
    z[1,2,0]  R483      -2.9731979966163635e-01
    z[1,2,0]  R484      1.1816011369228363e-01
    z[1,2,0]  R485      -2.8915387392044067e-01
    z[1,2,0]  R486      -2.1819458901882172e-01
    z[1,2,0]  R487      -6.5947575494647026e-03
    z[1,2,0]  R488      3.4752342104911804e-01
    z[1,2,0]  R489      -3.7871897220611572e-01
    z[1,2,0]  R490      -4.6609845757484436e-01
    z[1,2,0]  R491      -3.5970714688301086e-01
    z[1,2,0]  R492      -1.0812094062566757e-01
    z[1,2,0]  R493      -1.2537581846117973e-02
    z[1,2,0]  R494      3.5242241621017456e-01
    z[1,2,0]  R495      -6.9711968302726746e-02
    z[1,2,0]  R496      1.9990468025207520e-01
    z[1,2,0]  R497      2.8056003153324127e-02
    z[1,2,0]  R498      -0.5154989361763
    z[1,2,0]  R499      2.2655533254146576e-01
    z[1,2,0]  R500      3.1677171587944031e-01
    z[1,2,0]  R501      3.0139264464378357e-01
    z[1,2,0]  R502      -3.4421378374099731e-01
    z[1,2,0]  R503      2.2422590851783752e-01
    z[1,2,0]  R504      1.9792316854000092e-01
    z[1,2,0]  R505      3.1178635358810425e-01
    z[1,2,0]  R506      -2.1497267484664917e-01
    z[1,2,0]  R507      1.9140347838401794e-01
    z[1,2,0]  R508      -2.8798022866249084e-01
    z[1,2,0]  R509      -8.8347524404525757e-02
    z[1,2,0]  R510      -7.1481841802597046e-01
    z[1,2,0]  R511      2.5166258215904236e-01
    z[1,2,0]  R512      -2.2615826129913330e-01
    z[1,2,0]  R513      -2.4861498177051544e-01
    z[1,2,0]  R514      -9.1641299426555634e-02
    z[1,2,0]  R515      4.0413862466812134e-01
    z[1,2,0]  R516      3.9909341931343079e-01
    z[1,2,0]  R517      1.1803105473518372e-01
    z[1,2,0]  R518      4.0218746662139893e-01
    z[1,2,0]  R519      4.5351126790046692e-01
    z[1,2,0]  R520      -1.5146599709987640e-01
    z[1,2,0]  R521      1.8265716731548309e-01
    z[1,2,0]  R522      -5.0401080399751663e-02
    z[1,2,0]  R523      4.2824089527130127e-01
    z[1,2,0]  R524      1.5922770835459232e-03
    z[1,2,0]  R525      7.5826868414878845e-02
    z[1,2,0]  R526      1.2530748546123505e-01
    z[1,2,0]  R527      -6.1307537555694580e-01
    z[1,2,0]  R528      -3.1183484196662903e-01
    z[1,2,0]  R529      2.5846919417381287e-01
    z[1,2,0]  R530      2.8779031708836555e-02
    z[1,2,0]  R531      -7.3980921506881714e-01
    z[1,2,0]  R532      -1.1959360539913177e-01
    z[1,2,0]  R533      -2.6762092113494873e-01
    z[1,2,0]  R534      -1.7991174757480621e-01
    z[1,2,0]  R535      -2.8292530775070190e-01
    z[1,2,0]  R536      -2.8297838568687439e-01
    z[1,2,0]  R537      -7.7906721830368042e-01
    z[1,2,0]  R538      -0.076054647564888
    z[1,2,0]  R539      -3.9875549077987671e-01
    z[1,2,0]  R540      1.1275541782379150e-01
    z[1,2,0]  R541      -4.3298348784446716e-02
    z[1,2,0]  R542      -3.5161290317773819e-02
    z[1,2,0]  R543      4.9804711341857910e-01
    z[1,2,0]  R544      -5.5517643690109253e-01
    z[1,2,0]  R545      9.2943632602691650e-01
    z[1,2,0]  R546      8.9745700359344482e-01
    z[1,2,0]  R547      3.7250635027885437e-01
    z[1,2,0]  R548      -3.1514719128608704e-01
    z[1,2,0]  R549      -4.7950640320777893e-01
    z[1,2,0]  R550      -5.1822578907012939e-01
    z[1,2,0]  R551      -0.445139616727829
    z[1,2,0]  R552      -8.6039073765277863e-02
    z[1,2,0]  R553      -1.7476458847522736e-01
    z[1,2,0]  R554      4.5696116983890533e-02
    z[1,2,0]  R555      -4.2043957114219666e-01
    z[1,2,0]  R556      -1.2850791215896606e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R470      -1
    z[1,2,1]  R471      1
    z[1,2,1]  R482      -3.3498278260231018e-01
    z[1,2,1]  R483      8.9675587415695190e-01
    z[1,2,1]  R484      8.7505888938903809e-01
    z[1,2,1]  R485      -6.1318643391132355e-02
    z[1,2,1]  R486      6.6259676218032837e-01
    z[1,2,1]  R487      0.692440390586853
    z[1,2,1]  R488      7.0537883043289185e-01
    z[1,2,1]  R489      7.3126709461212158e-01
    z[1,2,1]  R490      -6.4546540379524231e-02
    z[1,2,1]  R491      -0.858400285243988
    z[1,2,1]  R492      -0.876112699508667
    z[1,2,1]  R493      -8.0603712797164917e-01
    z[1,2,1]  R494      -7.7500116825103760e-01
    z[1,2,1]  R495      -7.7883827686309814e-01
    z[1,2,1]  R496      -6.4629852771759033e-01
    z[1,2,1]  R497      -3.9202803373336792e-01
    z[1,2,1]  R498      -7.4260437488555908e-01
    z[1,2,1]  R499      -7.1300995349884033e-01
    z[1,2,1]  R500      -7.1007263660430908e-01
    z[1,2,1]  R501      -7.9286617040634155e-01
    z[1,2,1]  R502      2.7025574445724487e-01
    z[1,2,1]  R503      8.4632793441414833e-03
    z[1,2,1]  R504      1.5935626626014709e-01
    z[1,2,1]  R505      4.2423886060714722e-01
    z[1,2,1]  R506      7.1896232664585114e-02
    z[1,2,1]  R507      -2.3277062922716141e-02
    z[1,2,1]  R508      -1.3731746375560760e-01
    z[1,2,1]  R509      -2.2696368396282196e-01
    z[1,2,1]  R510      4.0837100148200989e-01
    z[1,2,1]  R511      -8.0349564552307129e-01
    z[1,2,1]  R512      1.5217198431491852e-01
    z[1,2,1]  R513      3.4239817410707474e-02
    z[1,2,1]  R514      -6.0378062725067139e-01
    z[1,2,1]  R515      3.2040509581565857e-01
    z[1,2,1]  R516      3.1255221366882324e-01
    z[1,2,1]  R517      2.8163838386535645e-01
    z[1,2,1]  R518      -2.9545217752456665e-01
    z[1,2,1]  R519      -3.1975455582141876e-02
    z[1,2,1]  R520      1.0061888396739960e-01
    z[1,2,1]  R521      -4.9161937087774277e-02
    z[1,2,1]  R522      2.2024077177047729e-01
    z[1,2,1]  R523      -2.2849030792713165e-01
    z[1,2,1]  R524      -1.7041325569152832e-02
    z[1,2,1]  R525      -0.54848712682724
    z[1,2,1]  R526      -2.8677159547805786e-01
    z[1,2,1]  R527      5.2385908365249634e-01
    z[1,2,1]  R528      0.618018388748169
    z[1,2,1]  R529      -4.8973181843757629e-01
    z[1,2,1]  R530      9.2658340930938721e-01
    z[1,2,1]  R531      2.1738986670970917e-01
    z[1,2,1]  R532      8.1173330545425415e-01
    z[1,2,1]  R533      7.5879991054534912e-01
    z[1,2,1]  R534      0.610985279083252
    z[1,2,1]  R535      -3.8118717074394226e-01
    z[1,2,1]  R536      -1.9773192703723907e-01
    z[1,2,1]  R537      -2.6757544279098511e-01
    z[1,2,1]  R538      -0.325523316860199
    z[1,2,1]  R539      -6.6528119146823883e-02
    z[1,2,1]  R540      -8.0690783262252808e-01
    z[1,2,1]  R541      -1.4767971634864807e-01
    z[1,2,1]  R542      -3.5519865155220032e-01
    z[1,2,1]  R543      -5.5346727371215820e-01
    z[1,2,1]  R544      -5.6559547781944275e-02
    z[1,2,1]  R545      2.9945811629295349e-01
    z[1,2,1]  R546      2.3160910606384277e-01
    z[1,2,1]  R547      3.8794466853141785e-01
    z[1,2,1]  R548      6.9825100898742676e-01
    z[1,2,1]  R549      1.3087838888168335e-01
    z[1,2,1]  R550      -6.2799239158630371e-01
    z[1,2,1]  R551      8.7105512619018555e-02
    z[1,2,1]  R552      -8.4105068445205688e-01
    z[1,2,1]  R553      -6.2222665548324585e-01
    z[1,2,1]  R554      -4.5931825041770935e-01
    z[1,2,1]  R555      -2.9663187265396118e-01
    z[1,2,1]  R556      -4.0094795823097229e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R472      -1
    z[1,2,2]  R473      1
    z[1,2,2]  R482      7.7378839254379272e-01
    z[1,2,2]  R483      1.0274402797222137e-01
    z[1,2,2]  R484      2.4186423420906067e-01
    z[1,2,2]  R485      7.5274819135665894e-01
    z[1,2,2]  R486      4.1259959340095520e-02
    z[1,2,2]  R487      0.307152658700943
    z[1,2,2]  R488      2.2188268601894379e-02
    z[1,2,2]  R489      1.6515260562300682e-02
    z[1,2,2]  R490      1.7743951082229614e-01
    z[1,2,2]  R491      4.5016493648290634e-02
    z[1,2,2]  R492      -1.2014707922935486e-01
    z[1,2,2]  R493      -2.7345892786979675e-01
    z[1,2,2]  R494      -1.5424926578998566e-01
    z[1,2,2]  R495      -2.4860759079456329e-01
    z[1,2,2]  R496      -1.7490682005882263e-01
    z[1,2,2]  R497      -7.5999490916728973e-02
    z[1,2,2]  R498      -2.2708848118782043e-01
    z[1,2,2]  R499      2.1298274397850037e-02
    z[1,2,2]  R500      -0.270439088344574
    z[1,2,2]  R501      1.4696128666400909e-01
    z[1,2,2]  R502      1.8496122956275940e-01
    z[1,2,2]  R503      2.1626810729503632e-01
    z[1,2,2]  R504      -0.299159973859787
    z[1,2,2]  R505      1.9976884126663208e-02
    z[1,2,2]  R506      5.4376077651977539e-01
    z[1,2,2]  R507      0.306511789560318
    z[1,2,2]  R508      3.1260961294174194e-01
    z[1,2,2]  R509      5.8296412229537964e-02
    z[1,2,2]  R510      -2.2257991135120392e-01
    z[1,2,2]  R511      1.4338243007659912e-01
    z[1,2,2]  R512      -6.4063794910907745e-02
    z[1,2,2]  R513      2.4304716289043427e-01
    z[1,2,2]  R514      4.9997827410697937e-01
    z[1,2,2]  R515      3.6259759217500687e-02
    z[1,2,2]  R516      -3.6870157718658447e-01
    z[1,2,2]  R517      5.1369881629943848e-01
    z[1,2,2]  R518      1.7250214517116547e-01
    z[1,2,2]  R519      2.9760643839836121e-01
    z[1,2,2]  R520      -3.1268224120140076e-01
    z[1,2,2]  R521      -1.5565671026706696e-01
    z[1,2,2]  R522      1.4295632019639015e-02
    z[1,2,2]  R523      -1.7127253115177155e-02
    z[1,2,2]  R524      -3.6432725191116333e-01
    z[1,2,2]  R525      -1.4075274765491486e-01
    z[1,2,2]  R526      -3.3891963958740234e-01
    z[1,2,2]  R527      -0.280981183052063
    z[1,2,2]  R528      1.2004150450229645e-01
    z[1,2,2]  R529      1.5313675999641418e-01
    z[1,2,2]  R530      2.0283766090869904e-01
    z[1,2,2]  R531      5.8625018596649170e-01
    z[1,2,2]  R532      7.3909483850002289e-02
    z[1,2,2]  R533      1.4069521427154541e-01
    z[1,2,2]  R534      3.3644123468548059e-03
    z[1,2,2]  R535      -3.4357404708862305e-01
    z[1,2,2]  R536      0.349021315574646
    z[1,2,2]  R537      -1.1797043681144714e-01
    z[1,2,2]  R538      0.51185142993927
    z[1,2,2]  R539      -5.3328055143356323e-01
    z[1,2,2]  R540      -1.5672446787357330e-01
    z[1,2,2]  R541      -4.3450468778610229e-01
    z[1,2,2]  R542      7.5958654284477234e-02
    z[1,2,2]  R543      -1.2493695318698883e-01
    z[1,2,2]  R544      -5.4223573207855225e-01
    z[1,2,2]  R545      -3.6449797451496124e-02
    z[1,2,2]  R546      -9.9842166528105736e-03
    z[1,2,2]  R547      -4.7936826944351196e-01
    z[1,2,2]  R548      -2.4158288538455963e-01
    z[1,2,2]  R549      -4.8367372155189514e-01
    z[1,2,2]  R550      -5.5697569623589516e-03
    z[1,2,2]  R551      -5.0500237941741943e-01
    z[1,2,2]  R552      4.2073997855186462e-01
    z[1,2,2]  R553      3.9887708425521851e-01
    z[1,2,2]  R554      5.9302794933319092e-01
    z[1,2,2]  R555      -2.3319745063781738e-01
    z[1,2,2]  R556      5.2027142047882080e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R474      -1
    z[1,2,3]  R475      1
    z[1,2,3]  R482      3.8225373625755310e-01
    z[1,2,3]  R483      -3.9157648570835590e-03
    z[1,2,3]  R484      3.4162499941885471e-03
    z[1,2,3]  R485      5.1377767324447632e-01
    z[1,2,3]  R486      -4.1259959340095520e-02
    z[1,2,3]  R487      -1.7851822078227997e-01
    z[1,2,3]  R488      2.2214195132255554e-01
    z[1,2,3]  R489      -8.9437246322631836e-02
    z[1,2,3]  R490      5.8046829700469971e-01
    z[1,2,3]  R491      -3.0088746547698975e-01
    z[1,2,3]  R492      -1.5492798388004303e-01
    z[1,2,3]  R493      6.3656136393547058e-02
    z[1,2,3]  R494      -2.5527718663215637e-01
    z[1,2,3]  R495      4.5975369215011597e-01
    z[1,2,3]  R496      1.4882178604602814e-01
    z[1,2,3]  R497      2.5903906673192978e-02
    z[1,2,3]  R498      2.0706845819950104e-01
    z[1,2,3]  R499      1.3117501139640808e-01
    z[1,2,3]  R500      -3.1659743189811707e-01
    z[1,2,3]  R501      -3.2407918572425842e-01
    z[1,2,3]  R502      -6.2176507711410522e-01
    z[1,2,3]  R503      -5.0077027082443237e-01
    z[1,2,3]  R504      -5.9560501575469971e-01
    z[1,2,3]  R505      -5.1182800531387329e-01
    z[1,2,3]  R506      -4.4937032461166382e-01
    z[1,2,3]  R507      -4.1226205229759216e-01
    z[1,2,3]  R508      -5.3184306621551514e-01
    z[1,2,3]  R509      -3.8543307781219482e-01
    z[1,2,3]  R510      1.0902522504329681e-01
    z[1,2,3]  R511      -4.0261375904083252e-01
    z[1,2,3]  R512      -6.8117129802703857e-01
    z[1,2,3]  R513      -8.1062769889831543e-01
    z[1,2,3]  R514      -2.4668163061141968e-01
    z[1,2,3]  R515      -5.5053102970123291e-01
    z[1,2,3]  R516      -5.8346831798553467e-01
    z[1,2,3]  R517      -5.0937640666961670e-01
    z[1,2,3]  R518      -5.2619791030883789e-01
    z[1,2,3]  R519      -5.8378511667251587e-01
    z[1,2,3]  R520      0.871620774269104
    z[1,2,3]  R521      -6.9143766164779663e-01
    z[1,2,3]  R522      3.3501684665679932e-01
    z[1,2,3]  R523      -5.4444384574890137e-01
    z[1,2,3]  R524      -6.1271136999130249e-01
    z[1,2,3]  R525      1.0101101547479630e-01
    z[1,2,3]  R526      4.2658537626266479e-01
    z[1,2,3]  R527      3.9055773522704840e-03
    z[1,2,3]  R528      -2.2685249149799347e-01
    z[1,2,3]  R529      8.0298662185668945e-01
    z[1,2,3]  R530      -1.2950956821441650e-01
    z[1,2,3]  R531      -7.1744054555892944e-02
    z[1,2,3]  R532      5.4765632376074791e-03
    z[1,2,3]  R533      -3.2654855400323868e-02
    z[1,2,3]  R534      -9.6853971481323242e-02
    z[1,2,3]  R535      2.7009862661361694e-01
    z[1,2,3]  R536      1.7252631485462189e-02
    z[1,2,3]  R537      -8.3704240387305617e-04
    z[1,2,3]  R538      -8.2604862749576569e-02
    z[1,2,3]  R539      1.1904376745223999e-01
    z[1,2,3]  R540      -1.2835939228534698e-01
    z[1,2,3]  R541      5.3151566535234451e-02
    z[1,2,3]  R542      -1.4652781188488007e-01
    z[1,2,3]  R543      -1.6926433145999908e-01
    z[1,2,3]  R544      1.9480009377002716e-01
    z[1,2,3]  R545      4.4538501650094986e-02
    z[1,2,3]  R546      -5.5179011542350054e-04
    z[1,2,3]  R547      -6.7013156414031982e-01
    z[1,2,3]  R548      1.4224714040756226e-01
    z[1,2,3]  R549      -4.2256537079811096e-01
    z[1,2,3]  R550      -1.1562841385602951e-01
    z[1,2,3]  R551      -3.7999153137207031e-01
    z[1,2,3]  R552      -2.7202051877975464e-01
    z[1,2,3]  R553      -2.8553810715675354e-01
    z[1,2,3]  R554      -2.1384359896183014e-01
    z[1,2,3]  R555      5.2082948386669159e-02
    z[1,2,3]  R556      -3.3588975667953491e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R476      -1
    z[1,2,4]  R477      1
    z[1,2,4]  R482      -1.4558282494544983e-01
    z[1,2,4]  R483      0.163810133934021
    z[1,2,4]  R484      -4.0570143610239029e-03
    z[1,2,4]  R485      1.6149160265922546e-01
    z[1,2,4]  R486      -2.0794370770454407e-01
    z[1,2,4]  R487      -4.6127480268478394e-01
    z[1,2,4]  R488      -2.1602858603000641e-01
    z[1,2,4]  R489      -4.1730195283889771e-01
    z[1,2,4]  R490      2.8576115146279335e-02
    z[1,2,4]  R491      -7.9619465395808220e-03
    z[1,2,4]  R492      -3.2067483663558960e-01
    z[1,2,4]  R493      4.8926392197608948e-01
    z[1,2,4]  R494      1.0910187661647797e-01
    z[1,2,4]  R495      -1.6284523904323578e-01
    z[1,2,4]  R496      5.8057814836502075e-01
    z[1,2,4]  R497      7.0143383741378784e-01
    z[1,2,4]  R498      1.6695725917816162e-01
    z[1,2,4]  R499      1.5419793128967285e-01
    z[1,2,4]  R500      -1.5438987314701080e-01
    z[1,2,4]  R501      2.3761963844299316e-01
    z[1,2,4]  R502      -4.1758334636688232e-01
    z[1,2,4]  R503      -6.3946652412414551e-01
    z[1,2,4]  R504      -0.51181960105896
    z[1,2,4]  R505      -6.6047418117523193e-01
    z[1,2,4]  R506      -0.664966881275177
    z[1,2,4]  R507      -5.8735400438308716e-01
    z[1,2,4]  R508      -0.590451717376709
    z[1,2,4]  R509      -0.0902474895119667
    z[1,2,4]  R510      4.6288406848907471e-01
    z[1,2,4]  R511      3.0597427487373352e-01
    z[1,2,4]  R512      -5.7819157838821411e-01
    z[1,2,4]  R513      -3.3972835540771484e-01
    z[1,2,4]  R514      1.6309560835361481e-01
    z[1,2,4]  R515      -5.4928815364837646e-01
    z[1,2,4]  R516      -3.8938489556312561e-01
    z[1,2,4]  R517      -4.7194615006446838e-01
    z[1,2,4]  R518      -4.4284597039222717e-01
    z[1,2,4]  R519      -4.9810793995857239e-01
    z[1,2,4]  R520      6.9485092535614967e-03
    z[1,2,4]  R521      -1.9424900412559509e-01
    z[1,2,4]  R522      1.0263490676879883e-01
    z[1,2,4]  R523      -4.7431486845016479e-01
    z[1,2,4]  R524      -5.9538251161575317e-01
    z[1,2,4]  R525      2.4018044769763947e-01
    z[1,2,4]  R526      -7.2686426341533661e-02
    z[1,2,4]  R527      3.9153233170509338e-01
    z[1,2,4]  R528      2.3492768406867981e-01
    z[1,2,4]  R529      -1.5403665602207184e-01
    z[1,2,4]  R530      2.1440730988979340e-01
    z[1,2,4]  R531      -2.3786747455596924e-01
    z[1,2,4]  R532      -0.0471666194498539
    z[1,2,4]  R533      -3.3482363820075989e-01
    z[1,2,4]  R534      -5.9827786684036255e-01
    z[1,2,4]  R535      -6.7842954397201538e-01
    z[1,2,4]  R536      -8.4002345800399780e-01
    z[1,2,4]  R537      8.3586469292640686e-02
    z[1,2,4]  R538      -1.8240779638290405e-01
    z[1,2,4]  R539      3.0084878206253052e-01
    z[1,2,4]  R540      -2.7551990002393723e-02
    z[1,2,4]  R541      1.6298310458660126e-01
    z[1,2,4]  R542      2.2394415736198425e-01
    z[1,2,4]  R543      0.522490918636322
    z[1,2,4]  R544      -2.9241707921028137e-01
    z[1,2,4]  R545      1.4526424929499626e-02
    z[1,2,4]  R546      1.0862758755683899e-01
    z[1,2,4]  R547      -1.0530197620391846e-01
    z[1,2,4]  R548      -3.4162408113479614e-01
    z[1,2,4]  R549      -1.2223538011312485e-01
    z[1,2,4]  R550      -8.8653936982154846e-02
    z[1,2,4]  R551      4.6802088618278503e-01
    z[1,2,4]  R552      -7.8435122966766357e-02
    z[1,2,4]  R553      2.5598713755607605e-01
    z[1,2,4]  R554      -3.1511259078979492e-01
    z[1,2,4]  R555      -1.4939607679843903e-01
    z[1,2,4]  R556      6.0841619968414307e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R478      -1
    z[1,2,5]  R479      1
    z[1,2,5]  R482      -1.6474494338035583e-01
    z[1,2,5]  R483      1.0680849105119705e-01
    z[1,2,5]  R484      -2.0315544307231903e-01
    z[1,2,5]  R485      1.4713162183761597e-01
    z[1,2,5]  R486      5.8734047412872314e-01
    z[1,2,5]  R487      4.0463688969612122e-01
    z[1,2,5]  R488      -1.7513585090637207e-01
    z[1,2,5]  R489      4.1197489947080612e-02
    z[1,2,5]  R490      -8.0205485224723816e-02
    z[1,2,5]  R491      1.2168951332569122e-01
    z[1,2,5]  R492      -2.0801538228988647e-01
    z[1,2,5]  R493      0.0840618684887886
    z[1,2,5]  R494      -1.9511045515537262e-01
    z[1,2,5]  R495      2.8341525793075562e-01
    z[1,2,5]  R496      -2.2321467101573944e-01
    z[1,2,5]  R497      -5.3270065784454346e-01
    z[1,2,5]  R498      -1.6856868565082550e-01
    z[1,2,5]  R499      5.8082717657089233e-01
    z[1,2,5]  R500      4.1606637835502625e-01
    z[1,2,5]  R501      2.6745957136154175e-01
    z[1,2,5]  R502      -4.6029236912727356e-01
    z[1,2,5]  R503      -4.8587009310722351e-01
    z[1,2,5]  R504      -1.2921129167079926e-01
    z[1,2,5]  R505      -1.5246525406837463e-01
    z[1,2,5]  R506      8.5285924375057220e-02
    z[1,2,5]  R507      -1.6475403308868408e-01
    z[1,2,5]  R508      3.6474382877349854e-01
    z[1,2,5]  R509      -5.9170073270797729e-01
    z[1,2,5]  R510      7.1492088027298450e-03
    z[1,2,5]  R511      -1.1673893034458160e-01
    z[1,2,5]  R512      -3.0481332540512085e-01
    z[1,2,5]  R513      -1.1750492453575134e-01
    z[1,2,5]  R514      2.3797427117824554e-01
    z[1,2,5]  R515      -1.9681325554847717e-01
    z[1,2,5]  R516      -2.7384012937545776e-01
    z[1,2,5]  R517      -2.0077195018529892e-02
    z[1,2,5]  R518      7.6294876635074615e-02
    z[1,2,5]  R519      2.1059630811214447e-01
    z[1,2,5]  R520      -3.1465789675712585e-01
    z[1,2,5]  R521      -6.2353044748306274e-01
    z[1,2,5]  R522      -8.8545608520507812e-01
    z[1,2,5]  R523      -3.4213870763778687e-01
    z[1,2,5]  R524      2.4994868040084839e-01
    z[1,2,5]  R525      -4.3828555941581726e-01
    z[1,2,5]  R526      -4.9683102965354919e-01
    z[1,2,5]  R527      -0.0399838462471962
    z[1,2,5]  R528      -0.0658000111579895
    z[1,2,5]  R529      -1.4355553314089775e-02
    z[1,2,5]  R530      -1.8618127703666687e-01
    z[1,2,5]  R531      -1.6590122831985354e-03
    z[1,2,5]  R532      5.2180910110473633e-01
    z[1,2,5]  R533      2.1531239151954651e-01
    z[1,2,5]  R534      0.0934302806854248
    z[1,2,5]  R535      3.4997311234474182e-01
    z[1,2,5]  R536      1.8963402509689331e-01
    z[1,2,5]  R537      5.0546127557754517e-01
    z[1,2,5]  R538      -3.7152278423309326e-01
    z[1,2,5]  R539      -6.6386508941650391e-01
    z[1,2,5]  R540      -4.1977947950363159e-01
    z[1,2,5]  R541      -4.7290486097335815e-01
    z[1,2,5]  R542      -3.5780504345893860e-01
    z[1,2,5]  R543      2.1147643029689789e-01
    z[1,2,5]  R544      -5.1907891035079956e-01
    z[1,2,5]  R545      -1.1003150045871735e-01
    z[1,2,5]  R546      -3.5787490010261536e-01
    z[1,2,5]  R547      -1.2733571231365204e-01
    z[1,2,5]  R548      -3.5000103712081909e-01
    z[1,2,5]  R549      -2.0416064560413361e-01
    z[1,2,5]  R550      -5.4127085208892822e-01
    z[1,2,5]  R551      -3.6222544312477112e-01
    z[1,2,5]  R552      1.6663667559623718e-01
    z[1,2,5]  R553      -7.9163469374179840e-02
    z[1,2,5]  R554      -7.1162022650241852e-02
    z[1,2,5]  R555      1.6889117658138275e-01
    z[1,2,5]  R556      1.0090171545743942e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R480      -1
    z[1,2,6]  R481      1
    z[1,2,6]  R482      -0.140189990401268
    z[1,2,6]  R483      -2.4210827052593231e-01
    z[1,2,6]  R484      3.4714812040328979e-01
    z[1,2,6]  R485      1.8521706759929657e-01
    z[1,2,6]  R486      3.4891620278358459e-01
    z[1,2,6]  R487      1.3328856229782104e-01
    z[1,2,6]  R488      -5.0446790456771851e-01
    z[1,2,6]  R489      -3.7109351158142090e-01
    z[1,2,6]  R490      -6.3475054502487183e-01
    z[1,2,6]  R491      -1.6226026415824890e-01
    z[1,2,6]  R492      1.9025182723999023e-01
    z[1,2,6]  R493      1.5770034492015839e-01
    z[1,2,6]  R494      3.6910846829414368e-01
    z[1,2,6]  R495      -9.2354238033294678e-02
    z[1,2,6]  R496      3.2046881318092346e-01
    z[1,2,6]  R497      2.5159615278244019e-01
    z[1,2,6]  R498      1.7906135320663452e-01
    z[1,2,6]  R499      2.4797524511814117e-01
    z[1,2,6]  R500      1.5853638947010040e-01
    z[1,2,6]  R501      -1.6094410419464111e-01
    z[1,2,6]  R502      3.7831205874681473e-02
    z[1,2,6]  R503      -8.4387667477130890e-02
    z[1,2,6]  R504      -4.6101531386375427e-01
    z[1,2,6]  R505      3.1176095828413963e-02
    z[1,2,6]  R506      -3.9415098726749420e-02
    z[1,2,6]  R507      0.571651041507721
    z[1,2,6]  R508      1.8962664902210236e-01
    z[1,2,6]  R509      -6.5610265731811523e-01
    z[1,2,6]  R510      2.1570038795471191e-01
    z[1,2,6]  R511      3.4002907574176788e-02
    z[1,2,6]  R512      -1.7430160939693451e-01
    z[1,2,6]  R513      -3.0266538262367249e-01
    z[1,2,6]  R514      4.8268902301788330e-01
    z[1,2,6]  R515      -2.9859754443168640e-01
    z[1,2,6]  R516      2.0012594759464264e-01
    z[1,2,6]  R517      4.0032669901847839e-01
    z[1,2,6]  R518      -4.9231955409049988e-01
    z[1,2,6]  R519      -2.6733508706092834e-01
    z[1,2,6]  R520      1.0189716517925262e-01
    z[1,2,6]  R521      -1.8809950351715088e-01
    z[1,2,6]  R522      -2.0480866730213165e-01
    z[1,2,6]  R523      3.5448002815246582e-01
    z[1,2,6]  R524      2.7313491702079773e-01
    z[1,2,6]  R525      -0.643130362033844
    z[1,2,6]  R526      -5.9421718120574951e-01
    z[1,2,6]  R527      3.4036511182785034e-01
    z[1,2,6]  R528      0.62882399559021
    z[1,2,6]  R529      -3.4419938921928406e-02
    z[1,2,6]  R530      4.5443259179592133e-02
    z[1,2,6]  R531      1.9602021202445030e-03
    z[1,2,6]  R532      -2.1629691123962402e-01
    z[1,2,6]  R533      4.1626194119453430e-01
    z[1,2,6]  R534      -4.6719488501548767e-01
    z[1,2,6]  R535      3.0087681487202644e-02
    z[1,2,6]  R536      -1.3081052899360657e-01
    z[1,2,6]  R537      -2.1227811276912689e-01
    z[1,2,6]  R538      6.6942739486694336e-01
    z[1,2,6]  R539      8.2351088523864746e-02
    z[1,2,6]  R540      -0.343763530254364
    z[1,2,6]  R541      -7.3109096288681030e-01
    z[1,2,6]  R542      -8.1681215763092041e-01
    z[1,2,6]  R543      2.8921341896057129e-01
    z[1,2,6]  R544      4.0778901427984238e-02
    z[1,2,6]  R545      -1.7562095820903778e-01
    z[1,2,6]  R546      3.0883124098181725e-02
    z[1,2,6]  R547      -6.7563906311988831e-02
    z[1,2,6]  R548      -3.0874508619308472e-01
    z[1,2,6]  R549      5.3274726867675781e-01
    z[1,2,6]  R550      1.5110582113265991e-01
    z[1,2,6]  R551      2.1116735041141510e-01
    z[1,2,6]  R552      1.7141979187726974e-02
    z[1,2,6]  R553      5.1948052644729614e-01
    z[1,2,6]  R554      0.534010648727417
    z[1,2,6]  R555      7.9202461242675781e-01
    z[1,2,6]  R556      -2.4263311922550201e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R557      -1
    z[2,1,0]  R558      1
    z[2,1,0]  R571      2.5846919417381287e-01
    z[2,1,0]  R572      2.8779031708836555e-02
    z[2,1,0]  R573      -7.3980921506881714e-01
    z[2,1,0]  R574      -1.1959360539913177e-01
    z[2,1,0]  R575      -2.6762092113494873e-01
    z[2,1,0]  R576      -1.7991174757480621e-01
    z[2,1,0]  R577      -2.8292530775070190e-01
    z[2,1,0]  R578      -2.8297838568687439e-01
    z[2,1,0]  R579      -7.7906721830368042e-01
    z[2,1,0]  R580      -0.076054647564888
    z[2,1,0]  R581      -3.9875549077987671e-01
    z[2,1,0]  R582      1.1275541782379150e-01
    z[2,1,0]  R583      -4.3298348784446716e-02
    z[2,1,0]  R584      -3.5161290317773819e-02
    z[2,1,0]  R585      4.9804711341857910e-01
    z[2,1,0]  R586      -5.5517643690109253e-01
    z[2,1,0]  R587      9.2943632602691650e-01
    z[2,1,0]  R588      8.9745700359344482e-01
    z[2,1,0]  R589      3.7250635027885437e-01
    z[2,1,0]  R590      -3.1514719128608704e-01
    z[2,1,0]  R591      -4.7950640320777893e-01
    z[2,1,0]  R592      -5.1822578907012939e-01
    z[2,1,0]  R593      -0.445139616727829
    z[2,1,0]  R594      -8.6039073765277863e-02
    z[2,1,0]  R595      -1.7476458847522736e-01
    z[2,1,0]  R596      4.5696116983890533e-02
    z[2,1,0]  R597      -4.2043957114219666e-01
    z[2,1,0]  R598      -1.2850791215896606e-01
    z[2,1,0]  R599      2.7373647689819336e-01
    z[2,1,0]  R600      -2.9731979966163635e-01
    z[2,1,0]  R601      1.1816011369228363e-01
    z[2,1,0]  R602      -2.8915387392044067e-01
    z[2,1,0]  R603      -2.1819458901882172e-01
    z[2,1,0]  R604      -6.5947575494647026e-03
    z[2,1,0]  R605      3.4752342104911804e-01
    z[2,1,0]  R606      -3.7871897220611572e-01
    z[2,1,0]  R607      -4.6609845757484436e-01
    z[2,1,0]  R608      -3.5970714688301086e-01
    z[2,1,0]  R609      -1.0812094062566757e-01
    z[2,1,0]  R610      -1.2537581846117973e-02
    z[2,1,0]  R611      3.5242241621017456e-01
    z[2,1,0]  R612      -6.9711968302726746e-02
    z[2,1,0]  R613      1.9990468025207520e-01
    z[2,1,0]  R614      2.8056003153324127e-02
    z[2,1,0]  R615      -0.5154989361763
    z[2,1,0]  R616      2.2655533254146576e-01
    z[2,1,0]  R617      3.1677171587944031e-01
    z[2,1,0]  R618      3.0139264464378357e-01
    z[2,1,0]  R619      -3.4421378374099731e-01
    z[2,1,0]  R620      2.2422590851783752e-01
    z[2,1,0]  R621      1.9792316854000092e-01
    z[2,1,0]  R622      3.1178635358810425e-01
    z[2,1,0]  R623      -2.1497267484664917e-01
    z[2,1,0]  R624      1.9140347838401794e-01
    z[2,1,0]  R625      -2.8798022866249084e-01
    z[2,1,0]  R626      -8.8347524404525757e-02
    z[2,1,0]  R627      -7.1481841802597046e-01
    z[2,1,0]  R628      2.5166258215904236e-01
    z[2,1,0]  R629      -2.2615826129913330e-01
    z[2,1,0]  R630      -2.4861498177051544e-01
    z[2,1,0]  R631      -9.1641299426555634e-02
    z[2,1,0]  R632      4.0413862466812134e-01
    z[2,1,0]  R633      3.9909341931343079e-01
    z[2,1,0]  R634      1.1803105473518372e-01
    z[2,1,0]  R635      4.0218746662139893e-01
    z[2,1,0]  R636      4.5351126790046692e-01
    z[2,1,0]  R637      -1.5146599709987640e-01
    z[2,1,0]  R638      1.8265716731548309e-01
    z[2,1,0]  R639      -5.0401080399751663e-02
    z[2,1,0]  R640      4.2824089527130127e-01
    z[2,1,0]  R641      1.5922770835459232e-03
    z[2,1,0]  R642      7.5826868414878845e-02
    z[2,1,0]  R643      1.2530748546123505e-01
    z[2,1,0]  R644      -6.1307537555694580e-01
    z[2,1,0]  R645      -3.1183484196662903e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R559      -1
    z[2,1,1]  R560      1
    z[2,1,1]  R571      -4.8973181843757629e-01
    z[2,1,1]  R572      9.2658340930938721e-01
    z[2,1,1]  R573      2.1738986670970917e-01
    z[2,1,1]  R574      8.1173330545425415e-01
    z[2,1,1]  R575      7.5879991054534912e-01
    z[2,1,1]  R576      0.610985279083252
    z[2,1,1]  R577      -3.8118717074394226e-01
    z[2,1,1]  R578      -1.9773192703723907e-01
    z[2,1,1]  R579      -2.6757544279098511e-01
    z[2,1,1]  R580      -0.325523316860199
    z[2,1,1]  R581      -6.6528119146823883e-02
    z[2,1,1]  R582      -8.0690783262252808e-01
    z[2,1,1]  R583      -1.4767971634864807e-01
    z[2,1,1]  R584      -3.5519865155220032e-01
    z[2,1,1]  R585      -5.5346727371215820e-01
    z[2,1,1]  R586      -5.6559547781944275e-02
    z[2,1,1]  R587      2.9945811629295349e-01
    z[2,1,1]  R588      2.3160910606384277e-01
    z[2,1,1]  R589      3.8794466853141785e-01
    z[2,1,1]  R590      6.9825100898742676e-01
    z[2,1,1]  R591      1.3087838888168335e-01
    z[2,1,1]  R592      -6.2799239158630371e-01
    z[2,1,1]  R593      8.7105512619018555e-02
    z[2,1,1]  R594      -8.4105068445205688e-01
    z[2,1,1]  R595      -6.2222665548324585e-01
    z[2,1,1]  R596      -4.5931825041770935e-01
    z[2,1,1]  R597      -2.9663187265396118e-01
    z[2,1,1]  R598      -4.0094795823097229e-01
    z[2,1,1]  R599      -3.3498278260231018e-01
    z[2,1,1]  R600      8.9675587415695190e-01
    z[2,1,1]  R601      8.7505888938903809e-01
    z[2,1,1]  R602      -6.1318643391132355e-02
    z[2,1,1]  R603      6.6259676218032837e-01
    z[2,1,1]  R604      0.692440390586853
    z[2,1,1]  R605      7.0537883043289185e-01
    z[2,1,1]  R606      7.3126709461212158e-01
    z[2,1,1]  R607      -6.4546540379524231e-02
    z[2,1,1]  R608      -0.858400285243988
    z[2,1,1]  R609      -0.876112699508667
    z[2,1,1]  R610      -8.0603712797164917e-01
    z[2,1,1]  R611      -7.7500116825103760e-01
    z[2,1,1]  R612      -7.7883827686309814e-01
    z[2,1,1]  R613      -6.4629852771759033e-01
    z[2,1,1]  R614      -3.9202803373336792e-01
    z[2,1,1]  R615      -7.4260437488555908e-01
    z[2,1,1]  R616      -7.1300995349884033e-01
    z[2,1,1]  R617      -7.1007263660430908e-01
    z[2,1,1]  R618      -7.9286617040634155e-01
    z[2,1,1]  R619      2.7025574445724487e-01
    z[2,1,1]  R620      8.4632793441414833e-03
    z[2,1,1]  R621      1.5935626626014709e-01
    z[2,1,1]  R622      4.2423886060714722e-01
    z[2,1,1]  R623      7.1896232664585114e-02
    z[2,1,1]  R624      -2.3277062922716141e-02
    z[2,1,1]  R625      -1.3731746375560760e-01
    z[2,1,1]  R626      -2.2696368396282196e-01
    z[2,1,1]  R627      4.0837100148200989e-01
    z[2,1,1]  R628      -8.0349564552307129e-01
    z[2,1,1]  R629      1.5217198431491852e-01
    z[2,1,1]  R630      3.4239817410707474e-02
    z[2,1,1]  R631      -6.0378062725067139e-01
    z[2,1,1]  R632      3.2040509581565857e-01
    z[2,1,1]  R633      3.1255221366882324e-01
    z[2,1,1]  R634      2.8163838386535645e-01
    z[2,1,1]  R635      -2.9545217752456665e-01
    z[2,1,1]  R636      -3.1975455582141876e-02
    z[2,1,1]  R637      1.0061888396739960e-01
    z[2,1,1]  R638      -4.9161937087774277e-02
    z[2,1,1]  R639      2.2024077177047729e-01
    z[2,1,1]  R640      -2.2849030792713165e-01
    z[2,1,1]  R641      -1.7041325569152832e-02
    z[2,1,1]  R642      -0.54848712682724
    z[2,1,1]  R643      -2.8677159547805786e-01
    z[2,1,1]  R644      5.2385908365249634e-01
    z[2,1,1]  R645      0.618018388748169
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R561      -1
    z[2,1,2]  R562      1
    z[2,1,2]  R571      1.5313675999641418e-01
    z[2,1,2]  R572      2.0283766090869904e-01
    z[2,1,2]  R573      5.8625018596649170e-01
    z[2,1,2]  R574      7.3909483850002289e-02
    z[2,1,2]  R575      1.4069521427154541e-01
    z[2,1,2]  R576      3.3644123468548059e-03
    z[2,1,2]  R577      -3.4357404708862305e-01
    z[2,1,2]  R578      0.349021315574646
    z[2,1,2]  R579      -1.1797043681144714e-01
    z[2,1,2]  R580      0.51185142993927
    z[2,1,2]  R581      -5.3328055143356323e-01
    z[2,1,2]  R582      -1.5672446787357330e-01
    z[2,1,2]  R583      -4.3450468778610229e-01
    z[2,1,2]  R584      7.5958654284477234e-02
    z[2,1,2]  R585      -1.2493695318698883e-01
    z[2,1,2]  R586      -5.4223573207855225e-01
    z[2,1,2]  R587      -3.6449797451496124e-02
    z[2,1,2]  R588      -9.9842166528105736e-03
    z[2,1,2]  R589      -4.7936826944351196e-01
    z[2,1,2]  R590      -2.4158288538455963e-01
    z[2,1,2]  R591      -4.8367372155189514e-01
    z[2,1,2]  R592      -5.5697569623589516e-03
    z[2,1,2]  R593      -5.0500237941741943e-01
    z[2,1,2]  R594      4.2073997855186462e-01
    z[2,1,2]  R595      3.9887708425521851e-01
    z[2,1,2]  R596      5.9302794933319092e-01
    z[2,1,2]  R597      -2.3319745063781738e-01
    z[2,1,2]  R598      5.2027142047882080e-01
    z[2,1,2]  R599      7.7378839254379272e-01
    z[2,1,2]  R600      1.0274402797222137e-01
    z[2,1,2]  R601      2.4186423420906067e-01
    z[2,1,2]  R602      7.5274819135665894e-01
    z[2,1,2]  R603      4.1259959340095520e-02
    z[2,1,2]  R604      0.307152658700943
    z[2,1,2]  R605      2.2188268601894379e-02
    z[2,1,2]  R606      1.6515260562300682e-02
    z[2,1,2]  R607      1.7743951082229614e-01
    z[2,1,2]  R608      4.5016493648290634e-02
    z[2,1,2]  R609      -1.2014707922935486e-01
    z[2,1,2]  R610      -2.7345892786979675e-01
    z[2,1,2]  R611      -1.5424926578998566e-01
    z[2,1,2]  R612      -2.4860759079456329e-01
    z[2,1,2]  R613      -1.7490682005882263e-01
    z[2,1,2]  R614      -7.5999490916728973e-02
    z[2,1,2]  R615      -2.2708848118782043e-01
    z[2,1,2]  R616      2.1298274397850037e-02
    z[2,1,2]  R617      -0.270439088344574
    z[2,1,2]  R618      1.4696128666400909e-01
    z[2,1,2]  R619      1.8496122956275940e-01
    z[2,1,2]  R620      2.1626810729503632e-01
    z[2,1,2]  R621      -0.299159973859787
    z[2,1,2]  R622      1.9976884126663208e-02
    z[2,1,2]  R623      5.4376077651977539e-01
    z[2,1,2]  R624      0.306511789560318
    z[2,1,2]  R625      3.1260961294174194e-01
    z[2,1,2]  R626      5.8296412229537964e-02
    z[2,1,2]  R627      -2.2257991135120392e-01
    z[2,1,2]  R628      1.4338243007659912e-01
    z[2,1,2]  R629      -6.4063794910907745e-02
    z[2,1,2]  R630      2.4304716289043427e-01
    z[2,1,2]  R631      4.9997827410697937e-01
    z[2,1,2]  R632      3.6259759217500687e-02
    z[2,1,2]  R633      -3.6870157718658447e-01
    z[2,1,2]  R634      5.1369881629943848e-01
    z[2,1,2]  R635      1.7250214517116547e-01
    z[2,1,2]  R636      2.9760643839836121e-01
    z[2,1,2]  R637      -3.1268224120140076e-01
    z[2,1,2]  R638      -1.5565671026706696e-01
    z[2,1,2]  R639      1.4295632019639015e-02
    z[2,1,2]  R640      -1.7127253115177155e-02
    z[2,1,2]  R641      -3.6432725191116333e-01
    z[2,1,2]  R642      -1.4075274765491486e-01
    z[2,1,2]  R643      -3.3891963958740234e-01
    z[2,1,2]  R644      -0.280981183052063
    z[2,1,2]  R645      1.2004150450229645e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R563      -1
    z[2,1,3]  R564      1
    z[2,1,3]  R571      8.0298662185668945e-01
    z[2,1,3]  R572      -1.2950956821441650e-01
    z[2,1,3]  R573      -7.1744054555892944e-02
    z[2,1,3]  R574      5.4765632376074791e-03
    z[2,1,3]  R575      -3.2654855400323868e-02
    z[2,1,3]  R576      -9.6853971481323242e-02
    z[2,1,3]  R577      2.7009862661361694e-01
    z[2,1,3]  R578      1.7252631485462189e-02
    z[2,1,3]  R579      -8.3704240387305617e-04
    z[2,1,3]  R580      -8.2604862749576569e-02
    z[2,1,3]  R581      1.1904376745223999e-01
    z[2,1,3]  R582      -1.2835939228534698e-01
    z[2,1,3]  R583      5.3151566535234451e-02
    z[2,1,3]  R584      -1.4652781188488007e-01
    z[2,1,3]  R585      -1.6926433145999908e-01
    z[2,1,3]  R586      1.9480009377002716e-01
    z[2,1,3]  R587      4.4538501650094986e-02
    z[2,1,3]  R588      -5.5179011542350054e-04
    z[2,1,3]  R589      -6.7013156414031982e-01
    z[2,1,3]  R590      1.4224714040756226e-01
    z[2,1,3]  R591      -4.2256537079811096e-01
    z[2,1,3]  R592      -1.1562841385602951e-01
    z[2,1,3]  R593      -3.7999153137207031e-01
    z[2,1,3]  R594      -2.7202051877975464e-01
    z[2,1,3]  R595      -2.8553810715675354e-01
    z[2,1,3]  R596      -2.1384359896183014e-01
    z[2,1,3]  R597      5.2082948386669159e-02
    z[2,1,3]  R598      -3.3588975667953491e-01
    z[2,1,3]  R599      3.8225373625755310e-01
    z[2,1,3]  R600      -3.9157648570835590e-03
    z[2,1,3]  R601      3.4162499941885471e-03
    z[2,1,3]  R602      5.1377767324447632e-01
    z[2,1,3]  R603      -4.1259959340095520e-02
    z[2,1,3]  R604      -1.7851822078227997e-01
    z[2,1,3]  R605      2.2214195132255554e-01
    z[2,1,3]  R606      -8.9437246322631836e-02
    z[2,1,3]  R607      5.8046829700469971e-01
    z[2,1,3]  R608      -3.0088746547698975e-01
    z[2,1,3]  R609      -1.5492798388004303e-01
    z[2,1,3]  R610      6.3656136393547058e-02
    z[2,1,3]  R611      -2.5527718663215637e-01
    z[2,1,3]  R612      4.5975369215011597e-01
    z[2,1,3]  R613      1.4882178604602814e-01
    z[2,1,3]  R614      2.5903906673192978e-02
    z[2,1,3]  R615      2.0706845819950104e-01
    z[2,1,3]  R616      1.3117501139640808e-01
    z[2,1,3]  R617      -3.1659743189811707e-01
    z[2,1,3]  R618      -3.2407918572425842e-01
    z[2,1,3]  R619      -6.2176507711410522e-01
    z[2,1,3]  R620      -5.0077027082443237e-01
    z[2,1,3]  R621      -5.9560501575469971e-01
    z[2,1,3]  R622      -5.1182800531387329e-01
    z[2,1,3]  R623      -4.4937032461166382e-01
    z[2,1,3]  R624      -4.1226205229759216e-01
    z[2,1,3]  R625      -5.3184306621551514e-01
    z[2,1,3]  R626      -3.8543307781219482e-01
    z[2,1,3]  R627      1.0902522504329681e-01
    z[2,1,3]  R628      -4.0261375904083252e-01
    z[2,1,3]  R629      -6.8117129802703857e-01
    z[2,1,3]  R630      -8.1062769889831543e-01
    z[2,1,3]  R631      -2.4668163061141968e-01
    z[2,1,3]  R632      -5.5053102970123291e-01
    z[2,1,3]  R633      -5.8346831798553467e-01
    z[2,1,3]  R634      -5.0937640666961670e-01
    z[2,1,3]  R635      -5.2619791030883789e-01
    z[2,1,3]  R636      -5.8378511667251587e-01
    z[2,1,3]  R637      0.871620774269104
    z[2,1,3]  R638      -6.9143766164779663e-01
    z[2,1,3]  R639      3.3501684665679932e-01
    z[2,1,3]  R640      -5.4444384574890137e-01
    z[2,1,3]  R641      -6.1271136999130249e-01
    z[2,1,3]  R642      1.0101101547479630e-01
    z[2,1,3]  R643      4.2658537626266479e-01
    z[2,1,3]  R644      3.9055773522704840e-03
    z[2,1,3]  R645      -2.2685249149799347e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R565      -1
    z[2,1,4]  R566      1
    z[2,1,4]  R571      -1.5403665602207184e-01
    z[2,1,4]  R572      2.1440730988979340e-01
    z[2,1,4]  R573      -2.3786747455596924e-01
    z[2,1,4]  R574      -0.0471666194498539
    z[2,1,4]  R575      -3.3482363820075989e-01
    z[2,1,4]  R576      -5.9827786684036255e-01
    z[2,1,4]  R577      -6.7842954397201538e-01
    z[2,1,4]  R578      -8.4002345800399780e-01
    z[2,1,4]  R579      8.3586469292640686e-02
    z[2,1,4]  R580      -1.8240779638290405e-01
    z[2,1,4]  R581      3.0084878206253052e-01
    z[2,1,4]  R582      -2.7551990002393723e-02
    z[2,1,4]  R583      1.6298310458660126e-01
    z[2,1,4]  R584      2.2394415736198425e-01
    z[2,1,4]  R585      0.522490918636322
    z[2,1,4]  R586      -2.9241707921028137e-01
    z[2,1,4]  R587      1.4526424929499626e-02
    z[2,1,4]  R588      1.0862758755683899e-01
    z[2,1,4]  R589      -1.0530197620391846e-01
    z[2,1,4]  R590      -3.4162408113479614e-01
    z[2,1,4]  R591      -1.2223538011312485e-01
    z[2,1,4]  R592      -8.8653936982154846e-02
    z[2,1,4]  R593      4.6802088618278503e-01
    z[2,1,4]  R594      -7.8435122966766357e-02
    z[2,1,4]  R595      2.5598713755607605e-01
    z[2,1,4]  R596      -3.1511259078979492e-01
    z[2,1,4]  R597      -1.4939607679843903e-01
    z[2,1,4]  R598      6.0841619968414307e-01
    z[2,1,4]  R599      -1.4558282494544983e-01
    z[2,1,4]  R600      0.163810133934021
    z[2,1,4]  R601      -4.0570143610239029e-03
    z[2,1,4]  R602      1.6149160265922546e-01
    z[2,1,4]  R603      -2.0794370770454407e-01
    z[2,1,4]  R604      -4.6127480268478394e-01
    z[2,1,4]  R605      -2.1602858603000641e-01
    z[2,1,4]  R606      -4.1730195283889771e-01
    z[2,1,4]  R607      2.8576115146279335e-02
    z[2,1,4]  R608      -7.9619465395808220e-03
    z[2,1,4]  R609      -3.2067483663558960e-01
    z[2,1,4]  R610      4.8926392197608948e-01
    z[2,1,4]  R611      1.0910187661647797e-01
    z[2,1,4]  R612      -1.6284523904323578e-01
    z[2,1,4]  R613      5.8057814836502075e-01
    z[2,1,4]  R614      7.0143383741378784e-01
    z[2,1,4]  R615      1.6695725917816162e-01
    z[2,1,4]  R616      1.5419793128967285e-01
    z[2,1,4]  R617      -1.5438987314701080e-01
    z[2,1,4]  R618      2.3761963844299316e-01
    z[2,1,4]  R619      -4.1758334636688232e-01
    z[2,1,4]  R620      -6.3946652412414551e-01
    z[2,1,4]  R621      -0.51181960105896
    z[2,1,4]  R622      -6.6047418117523193e-01
    z[2,1,4]  R623      -0.664966881275177
    z[2,1,4]  R624      -5.8735400438308716e-01
    z[2,1,4]  R625      -0.590451717376709
    z[2,1,4]  R626      -0.0902474895119667
    z[2,1,4]  R627      4.6288406848907471e-01
    z[2,1,4]  R628      3.0597427487373352e-01
    z[2,1,4]  R629      -5.7819157838821411e-01
    z[2,1,4]  R630      -3.3972835540771484e-01
    z[2,1,4]  R631      1.6309560835361481e-01
    z[2,1,4]  R632      -5.4928815364837646e-01
    z[2,1,4]  R633      -3.8938489556312561e-01
    z[2,1,4]  R634      -4.7194615006446838e-01
    z[2,1,4]  R635      -4.4284597039222717e-01
    z[2,1,4]  R636      -4.9810793995857239e-01
    z[2,1,4]  R637      6.9485092535614967e-03
    z[2,1,4]  R638      -1.9424900412559509e-01
    z[2,1,4]  R639      1.0263490676879883e-01
    z[2,1,4]  R640      -4.7431486845016479e-01
    z[2,1,4]  R641      -5.9538251161575317e-01
    z[2,1,4]  R642      2.4018044769763947e-01
    z[2,1,4]  R643      -7.2686426341533661e-02
    z[2,1,4]  R644      3.9153233170509338e-01
    z[2,1,4]  R645      2.3492768406867981e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R567      -1
    z[2,1,5]  R568      1
    z[2,1,5]  R571      -1.4355553314089775e-02
    z[2,1,5]  R572      -1.8618127703666687e-01
    z[2,1,5]  R573      -1.6590122831985354e-03
    z[2,1,5]  R574      5.2180910110473633e-01
    z[2,1,5]  R575      2.1531239151954651e-01
    z[2,1,5]  R576      0.0934302806854248
    z[2,1,5]  R577      3.4997311234474182e-01
    z[2,1,5]  R578      1.8963402509689331e-01
    z[2,1,5]  R579      5.0546127557754517e-01
    z[2,1,5]  R580      -3.7152278423309326e-01
    z[2,1,5]  R581      -6.6386508941650391e-01
    z[2,1,5]  R582      -4.1977947950363159e-01
    z[2,1,5]  R583      -4.7290486097335815e-01
    z[2,1,5]  R584      -3.5780504345893860e-01
    z[2,1,5]  R585      2.1147643029689789e-01
    z[2,1,5]  R586      -5.1907891035079956e-01
    z[2,1,5]  R587      -1.1003150045871735e-01
    z[2,1,5]  R588      -3.5787490010261536e-01
    z[2,1,5]  R589      -1.2733571231365204e-01
    z[2,1,5]  R590      -3.5000103712081909e-01
    z[2,1,5]  R591      -2.0416064560413361e-01
    z[2,1,5]  R592      -5.4127085208892822e-01
    z[2,1,5]  R593      -3.6222544312477112e-01
    z[2,1,5]  R594      1.6663667559623718e-01
    z[2,1,5]  R595      -7.9163469374179840e-02
    z[2,1,5]  R596      -7.1162022650241852e-02
    z[2,1,5]  R597      1.6889117658138275e-01
    z[2,1,5]  R598      1.0090171545743942e-01
    z[2,1,5]  R599      -1.6474494338035583e-01
    z[2,1,5]  R600      1.0680849105119705e-01
    z[2,1,5]  R601      -2.0315544307231903e-01
    z[2,1,5]  R602      1.4713162183761597e-01
    z[2,1,5]  R603      5.8734047412872314e-01
    z[2,1,5]  R604      4.0463688969612122e-01
    z[2,1,5]  R605      -1.7513585090637207e-01
    z[2,1,5]  R606      4.1197489947080612e-02
    z[2,1,5]  R607      -8.0205485224723816e-02
    z[2,1,5]  R608      1.2168951332569122e-01
    z[2,1,5]  R609      -2.0801538228988647e-01
    z[2,1,5]  R610      0.0840618684887886
    z[2,1,5]  R611      -1.9511045515537262e-01
    z[2,1,5]  R612      2.8341525793075562e-01
    z[2,1,5]  R613      -2.2321467101573944e-01
    z[2,1,5]  R614      -5.3270065784454346e-01
    z[2,1,5]  R615      -1.6856868565082550e-01
    z[2,1,5]  R616      5.8082717657089233e-01
    z[2,1,5]  R617      4.1606637835502625e-01
    z[2,1,5]  R618      2.6745957136154175e-01
    z[2,1,5]  R619      -4.6029236912727356e-01
    z[2,1,5]  R620      -4.8587009310722351e-01
    z[2,1,5]  R621      -1.2921129167079926e-01
    z[2,1,5]  R622      -1.5246525406837463e-01
    z[2,1,5]  R623      8.5285924375057220e-02
    z[2,1,5]  R624      -1.6475403308868408e-01
    z[2,1,5]  R625      3.6474382877349854e-01
    z[2,1,5]  R626      -5.9170073270797729e-01
    z[2,1,5]  R627      7.1492088027298450e-03
    z[2,1,5]  R628      -1.1673893034458160e-01
    z[2,1,5]  R629      -3.0481332540512085e-01
    z[2,1,5]  R630      -1.1750492453575134e-01
    z[2,1,5]  R631      2.3797427117824554e-01
    z[2,1,5]  R632      -1.9681325554847717e-01
    z[2,1,5]  R633      -2.7384012937545776e-01
    z[2,1,5]  R634      -2.0077195018529892e-02
    z[2,1,5]  R635      7.6294876635074615e-02
    z[2,1,5]  R636      2.1059630811214447e-01
    z[2,1,5]  R637      -3.1465789675712585e-01
    z[2,1,5]  R638      -6.2353044748306274e-01
    z[2,1,5]  R639      -8.8545608520507812e-01
    z[2,1,5]  R640      -3.4213870763778687e-01
    z[2,1,5]  R641      2.4994868040084839e-01
    z[2,1,5]  R642      -4.3828555941581726e-01
    z[2,1,5]  R643      -4.9683102965354919e-01
    z[2,1,5]  R644      -0.0399838462471962
    z[2,1,5]  R645      -0.0658000111579895
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R569      -1
    z[2,1,6]  R570      1
    z[2,1,6]  R571      -3.4419938921928406e-02
    z[2,1,6]  R572      4.5443259179592133e-02
    z[2,1,6]  R573      1.9602021202445030e-03
    z[2,1,6]  R574      -2.1629691123962402e-01
    z[2,1,6]  R575      4.1626194119453430e-01
    z[2,1,6]  R576      -4.6719488501548767e-01
    z[2,1,6]  R577      3.0087681487202644e-02
    z[2,1,6]  R578      -1.3081052899360657e-01
    z[2,1,6]  R579      -2.1227811276912689e-01
    z[2,1,6]  R580      6.6942739486694336e-01
    z[2,1,6]  R581      8.2351088523864746e-02
    z[2,1,6]  R582      -0.343763530254364
    z[2,1,6]  R583      -7.3109096288681030e-01
    z[2,1,6]  R584      -8.1681215763092041e-01
    z[2,1,6]  R585      2.8921341896057129e-01
    z[2,1,6]  R586      4.0778901427984238e-02
    z[2,1,6]  R587      -1.7562095820903778e-01
    z[2,1,6]  R588      3.0883124098181725e-02
    z[2,1,6]  R589      -6.7563906311988831e-02
    z[2,1,6]  R590      -3.0874508619308472e-01
    z[2,1,6]  R591      5.3274726867675781e-01
    z[2,1,6]  R592      1.5110582113265991e-01
    z[2,1,6]  R593      2.1116735041141510e-01
    z[2,1,6]  R594      1.7141979187726974e-02
    z[2,1,6]  R595      5.1948052644729614e-01
    z[2,1,6]  R596      0.534010648727417
    z[2,1,6]  R597      7.9202461242675781e-01
    z[2,1,6]  R598      -2.4263311922550201e-01
    z[2,1,6]  R599      -0.140189990401268
    z[2,1,6]  R600      -2.4210827052593231e-01
    z[2,1,6]  R601      3.4714812040328979e-01
    z[2,1,6]  R602      1.8521706759929657e-01
    z[2,1,6]  R603      3.4891620278358459e-01
    z[2,1,6]  R604      1.3328856229782104e-01
    z[2,1,6]  R605      -5.0446790456771851e-01
    z[2,1,6]  R606      -3.7109351158142090e-01
    z[2,1,6]  R607      -6.3475054502487183e-01
    z[2,1,6]  R608      -1.6226026415824890e-01
    z[2,1,6]  R609      1.9025182723999023e-01
    z[2,1,6]  R610      1.5770034492015839e-01
    z[2,1,6]  R611      3.6910846829414368e-01
    z[2,1,6]  R612      -9.2354238033294678e-02
    z[2,1,6]  R613      3.2046881318092346e-01
    z[2,1,6]  R614      2.5159615278244019e-01
    z[2,1,6]  R615      1.7906135320663452e-01
    z[2,1,6]  R616      2.4797524511814117e-01
    z[2,1,6]  R617      1.5853638947010040e-01
    z[2,1,6]  R618      -1.6094410419464111e-01
    z[2,1,6]  R619      3.7831205874681473e-02
    z[2,1,6]  R620      -8.4387667477130890e-02
    z[2,1,6]  R621      -4.6101531386375427e-01
    z[2,1,6]  R622      3.1176095828413963e-02
    z[2,1,6]  R623      -3.9415098726749420e-02
    z[2,1,6]  R624      0.571651041507721
    z[2,1,6]  R625      1.8962664902210236e-01
    z[2,1,6]  R626      -6.5610265731811523e-01
    z[2,1,6]  R627      2.1570038795471191e-01
    z[2,1,6]  R628      3.4002907574176788e-02
    z[2,1,6]  R629      -1.7430160939693451e-01
    z[2,1,6]  R630      -3.0266538262367249e-01
    z[2,1,6]  R631      4.8268902301788330e-01
    z[2,1,6]  R632      -2.9859754443168640e-01
    z[2,1,6]  R633      2.0012594759464264e-01
    z[2,1,6]  R634      4.0032669901847839e-01
    z[2,1,6]  R635      -4.9231955409049988e-01
    z[2,1,6]  R636      -2.6733508706092834e-01
    z[2,1,6]  R637      1.0189716517925262e-01
    z[2,1,6]  R638      -1.8809950351715088e-01
    z[2,1,6]  R639      -2.0480866730213165e-01
    z[2,1,6]  R640      3.5448002815246582e-01
    z[2,1,6]  R641      2.7313491702079773e-01
    z[2,1,6]  R642      -0.643130362033844
    z[2,1,6]  R643      -5.9421718120574951e-01
    z[2,1,6]  R644      3.4036511182785034e-01
    z[2,1,6]  R645      0.62882399559021
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R646      -1
    z[1,5,0]  R647      1
    z[1,5,0]  R660      2.7373647689819336e-01
    z[1,5,0]  R661      -2.9731979966163635e-01
    z[1,5,0]  R662      1.1816011369228363e-01
    z[1,5,0]  R663      -2.8915387392044067e-01
    z[1,5,0]  R664      -2.1819458901882172e-01
    z[1,5,0]  R665      -6.5947575494647026e-03
    z[1,5,0]  R666      3.4752342104911804e-01
    z[1,5,0]  R667      -3.7871897220611572e-01
    z[1,5,0]  R668      -4.6609845757484436e-01
    z[1,5,0]  R669      -3.5970714688301086e-01
    z[1,5,0]  R670      -1.0812094062566757e-01
    z[1,5,0]  R671      -1.2537581846117973e-02
    z[1,5,0]  R672      3.5242241621017456e-01
    z[1,5,0]  R673      -6.9711968302726746e-02
    z[1,5,0]  R674      1.9990468025207520e-01
    z[1,5,0]  R675      2.8056003153324127e-02
    z[1,5,0]  R676      -0.5154989361763
    z[1,5,0]  R677      2.2655533254146576e-01
    z[1,5,0]  R678      3.1677171587944031e-01
    z[1,5,0]  R679      3.0139264464378357e-01
    z[1,5,0]  R680      -3.4421378374099731e-01
    z[1,5,0]  R681      2.2422590851783752e-01
    z[1,5,0]  R682      1.9792316854000092e-01
    z[1,5,0]  R683      3.1178635358810425e-01
    z[1,5,0]  R684      -2.1497267484664917e-01
    z[1,5,0]  R685      1.9140347838401794e-01
    z[1,5,0]  R686      -2.8798022866249084e-01
    z[1,5,0]  R687      -8.8347524404525757e-02
    z[1,5,0]  R688      -7.1481841802597046e-01
    z[1,5,0]  R689      2.5166258215904236e-01
    z[1,5,0]  R690      -2.2615826129913330e-01
    z[1,5,0]  R691      -2.4861498177051544e-01
    z[1,5,0]  R692      -9.1641299426555634e-02
    z[1,5,0]  R693      4.0413862466812134e-01
    z[1,5,0]  R694      3.9909341931343079e-01
    z[1,5,0]  R695      1.1803105473518372e-01
    z[1,5,0]  R696      4.0218746662139893e-01
    z[1,5,0]  R697      4.5351126790046692e-01
    z[1,5,0]  R698      -1.5146599709987640e-01
    z[1,5,0]  R699      1.8265716731548309e-01
    z[1,5,0]  R700      -5.0401080399751663e-02
    z[1,5,0]  R701      4.2824089527130127e-01
    z[1,5,0]  R702      1.5922770835459232e-03
    z[1,5,0]  R703      7.5826868414878845e-02
    z[1,5,0]  R704      1.2530748546123505e-01
    z[1,5,0]  R705      -6.1307537555694580e-01
    z[1,5,0]  R706      -3.1183484196662903e-01
    z[1,5,0]  R707      -5.7996219396591187e-01
    z[1,5,0]  R708      -7.9358226060867310e-01
    z[1,5,0]  R709      -0.518456757068634
    z[1,5,0]  R710      -6.3096517324447632e-01
    z[1,5,0]  R711      -3.6290261149406433e-01
    z[1,5,0]  R712      -5.1928228139877319e-01
    z[1,5,0]  R713      -2.2811952233314514e-01
    z[1,5,0]  R714      4.1172024607658386e-01
    z[1,5,0]  R715      5.6369763612747192e-01
    z[1,5,0]  R716      6.7790520191192627e-01
    z[1,5,0]  R717      2.5977733731269836e-01
    z[1,5,0]  R718      3.2061547040939331e-01
    z[1,5,0]  R719      1.3840182125568390e-01
    z[1,5,0]  R720      -3.0481213331222534e-01
    z[1,5,0]  R721      -5.0336980819702148e-01
    z[1,5,0]  R722      -1.9695284962654114e-01
    z[1,5,0]  R723      -1.1693647503852844e-01
    z[1,5,0]  R724      5.1186162233352661e-01
    z[1,5,0]  R725      6.1486173421144485e-02
    z[1,5,0]  R726      0.04227314889431
    z[1,5,0]  R727      -3.9250290393829346e-01
    z[1,5,0]  R728      2.1174551546573639e-01
    z[1,5,0]  R729      -7.1806021034717560e-02
    z[1,5,0]  R730      -3.5093218088150024e-02
    z[1,5,0]  R731      3.3915615081787109e-01
    z[1,5,0]  R732      -1.1973375082015991e-01
    z[1,5,0]  R733      -3.8449484109878540e-01
    z[1,5,0]  R734      -1.7956182360649109e-01
    z[1,5,0]  R735      -0.182621568441391
    z[1,5,0]  R736      1.0773085057735443e-01
    z[1,5,0]  R737      -0.0769742876291275
    z[1,5,0]  R738      3.2144537568092346e-01
    z[1,5,0]  R739      1.9060429930686951e-01
    z[1,5,0]  R740      2.5585165619850159e-01
    z[1,5,0]  R741      -2.3111756891012192e-02
    z[1,5,0]  R742      3.3616542816162109e-01
    z[1,5,0]  R743      2.4032276868820190e-01
    z[1,5,0]  R744      -8.9384570717811584e-02
    z[1,5,0]  R745      -2.1971440315246582e-01
    z[1,5,0]  R746      -2.1087791025638580e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R648      -1
    z[1,5,1]  R649      1
    z[1,5,1]  R660      -3.3498278260231018e-01
    z[1,5,1]  R661      8.9675587415695190e-01
    z[1,5,1]  R662      8.7505888938903809e-01
    z[1,5,1]  R663      -6.1318643391132355e-02
    z[1,5,1]  R664      6.6259676218032837e-01
    z[1,5,1]  R665      0.692440390586853
    z[1,5,1]  R666      7.0537883043289185e-01
    z[1,5,1]  R667      7.3126709461212158e-01
    z[1,5,1]  R668      -6.4546540379524231e-02
    z[1,5,1]  R669      -0.858400285243988
    z[1,5,1]  R670      -0.876112699508667
    z[1,5,1]  R671      -8.0603712797164917e-01
    z[1,5,1]  R672      -7.7500116825103760e-01
    z[1,5,1]  R673      -7.7883827686309814e-01
    z[1,5,1]  R674      -6.4629852771759033e-01
    z[1,5,1]  R675      -3.9202803373336792e-01
    z[1,5,1]  R676      -7.4260437488555908e-01
    z[1,5,1]  R677      -7.1300995349884033e-01
    z[1,5,1]  R678      -7.1007263660430908e-01
    z[1,5,1]  R679      -7.9286617040634155e-01
    z[1,5,1]  R680      2.7025574445724487e-01
    z[1,5,1]  R681      8.4632793441414833e-03
    z[1,5,1]  R682      1.5935626626014709e-01
    z[1,5,1]  R683      4.2423886060714722e-01
    z[1,5,1]  R684      7.1896232664585114e-02
    z[1,5,1]  R685      -2.3277062922716141e-02
    z[1,5,1]  R686      -1.3731746375560760e-01
    z[1,5,1]  R687      -2.2696368396282196e-01
    z[1,5,1]  R688      4.0837100148200989e-01
    z[1,5,1]  R689      -8.0349564552307129e-01
    z[1,5,1]  R690      1.5217198431491852e-01
    z[1,5,1]  R691      3.4239817410707474e-02
    z[1,5,1]  R692      -6.0378062725067139e-01
    z[1,5,1]  R693      3.2040509581565857e-01
    z[1,5,1]  R694      3.1255221366882324e-01
    z[1,5,1]  R695      2.8163838386535645e-01
    z[1,5,1]  R696      -2.9545217752456665e-01
    z[1,5,1]  R697      -3.1975455582141876e-02
    z[1,5,1]  R698      1.0061888396739960e-01
    z[1,5,1]  R699      -4.9161937087774277e-02
    z[1,5,1]  R700      2.2024077177047729e-01
    z[1,5,1]  R701      -2.2849030792713165e-01
    z[1,5,1]  R702      -1.7041325569152832e-02
    z[1,5,1]  R703      -0.54848712682724
    z[1,5,1]  R704      -2.8677159547805786e-01
    z[1,5,1]  R705      5.2385908365249634e-01
    z[1,5,1]  R706      0.618018388748169
    z[1,5,1]  R707      2.3080082237720490e-01
    z[1,5,1]  R708      -0.0527375154197216
    z[1,5,1]  R709      2.0245993137359619e-01
    z[1,5,1]  R710      2.6000419165939093e-03
    z[1,5,1]  R711      -2.0599098876118660e-02
    z[1,5,1]  R712      -5.4028481245040894e-02
    z[1,5,1]  R713      6.0787373781204224e-01
    z[1,5,1]  R714      6.5360605716705322e-02
    z[1,5,1]  R715      2.1668045222759247e-01
    z[1,5,1]  R716      -1.9635602831840515e-02
    z[1,5,1]  R717      -7.4423557519912720e-01
    z[1,5,1]  R718      -7.7088785171508789e-01
    z[1,5,1]  R719      -6.4877432584762573e-01
    z[1,5,1]  R720      -6.7080420255661011e-01
    z[1,5,1]  R721      -0.663345456123352
    z[1,5,1]  R722      -5.3227263689041138e-01
    z[1,5,1]  R723      -0.687248170375824
    z[1,5,1]  R724      -0.569867730140686
    z[1,5,1]  R725      -0.77773118019104
    z[1,5,1]  R726      -3.8848367333412170e-01
    z[1,5,1]  R727      -8.5708284378051758e-01
    z[1,5,1]  R728      -0.671985387802124
    z[1,5,1]  R729      -7.8402262926101685e-01
    z[1,5,1]  R730      -0.723905086517334
    z[1,5,1]  R731      -5.6439733505249023e-01
    z[1,5,1]  R732      -0.00883125513792038
    z[1,5,1]  R733      -0.103699691593647
    z[1,5,1]  R734      5.3361009806394577e-02
    z[1,5,1]  R735      5.5084377527236938e-01
    z[1,5,1]  R736      5.8834302425384521e-01
    z[1,5,1]  R737      -0.764907956123352
    z[1,5,1]  R738      -9.2994827032089233e-01
    z[1,5,1]  R739      -7.1044009923934937e-01
    z[1,5,1]  R740      -6.4333051443099976e-01
    z[1,5,1]  R741      2.3180831968784332e-01
    z[1,5,1]  R742      -6.7275100946426392e-01
    z[1,5,1]  R743      2.0524153113365173e-01
    z[1,5,1]  R744      7.5061500072479248e-02
    z[1,5,1]  R745      4.4072076678276062e-01
    z[1,5,1]  R746      8.9551174640655518e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R650      -1
    z[1,5,2]  R651      1
    z[1,5,2]  R660      7.7378839254379272e-01
    z[1,5,2]  R661      1.0274402797222137e-01
    z[1,5,2]  R662      2.4186423420906067e-01
    z[1,5,2]  R663      7.5274819135665894e-01
    z[1,5,2]  R664      4.1259959340095520e-02
    z[1,5,2]  R665      0.307152658700943
    z[1,5,2]  R666      2.2188268601894379e-02
    z[1,5,2]  R667      1.6515260562300682e-02
    z[1,5,2]  R668      1.7743951082229614e-01
    z[1,5,2]  R669      4.5016493648290634e-02
    z[1,5,2]  R670      -1.2014707922935486e-01
    z[1,5,2]  R671      -2.7345892786979675e-01
    z[1,5,2]  R672      -1.5424926578998566e-01
    z[1,5,2]  R673      -2.4860759079456329e-01
    z[1,5,2]  R674      -1.7490682005882263e-01
    z[1,5,2]  R675      -7.5999490916728973e-02
    z[1,5,2]  R676      -2.2708848118782043e-01
    z[1,5,2]  R677      2.1298274397850037e-02
    z[1,5,2]  R678      -0.270439088344574
    z[1,5,2]  R679      1.4696128666400909e-01
    z[1,5,2]  R680      1.8496122956275940e-01
    z[1,5,2]  R681      2.1626810729503632e-01
    z[1,5,2]  R682      -0.299159973859787
    z[1,5,2]  R683      1.9976884126663208e-02
    z[1,5,2]  R684      5.4376077651977539e-01
    z[1,5,2]  R685      0.306511789560318
    z[1,5,2]  R686      3.1260961294174194e-01
    z[1,5,2]  R687      5.8296412229537964e-02
    z[1,5,2]  R688      -2.2257991135120392e-01
    z[1,5,2]  R689      1.4338243007659912e-01
    z[1,5,2]  R690      -6.4063794910907745e-02
    z[1,5,2]  R691      2.4304716289043427e-01
    z[1,5,2]  R692      4.9997827410697937e-01
    z[1,5,2]  R693      3.6259759217500687e-02
    z[1,5,2]  R694      -3.6870157718658447e-01
    z[1,5,2]  R695      5.1369881629943848e-01
    z[1,5,2]  R696      1.7250214517116547e-01
    z[1,5,2]  R697      2.9760643839836121e-01
    z[1,5,2]  R698      -3.1268224120140076e-01
    z[1,5,2]  R699      -1.5565671026706696e-01
    z[1,5,2]  R700      1.4295632019639015e-02
    z[1,5,2]  R701      -1.7127253115177155e-02
    z[1,5,2]  R702      -3.6432725191116333e-01
    z[1,5,2]  R703      -1.4075274765491486e-01
    z[1,5,2]  R704      -3.3891963958740234e-01
    z[1,5,2]  R705      -0.280981183052063
    z[1,5,2]  R706      1.2004150450229645e-01
    z[1,5,2]  R707      4.1230174899101257e-01
    z[1,5,2]  R708      3.5707753896713257e-01
    z[1,5,2]  R709      8.0414557456970215e-01
    z[1,5,2]  R710      6.6721254587173462e-01
    z[1,5,2]  R711      6.7652350664138794e-01
    z[1,5,2]  R712      2.7625033259391785e-01
    z[1,5,2]  R713      1.0251188278198242e-01
    z[1,5,2]  R714      -1.7896650359034538e-02
    z[1,5,2]  R715      -2.8267744928598404e-03
    z[1,5,2]  R716      5.4159498214721680e-01
    z[1,5,2]  R717      1.3479290902614594e-01
    z[1,5,2]  R718      2.1449199318885803e-01
    z[1,5,2]  R719      1.9075600802898407e-01
    z[1,5,2]  R720      -9.1220803558826447e-02
    z[1,5,2]  R721      -7.3211520910263062e-02
    z[1,5,2]  R722      2.7145119383931160e-02
    z[1,5,2]  R723      -3.1677749752998352e-01
    z[1,5,2]  R724      3.5254955291748047e-01
    z[1,5,2]  R725      -5.6832976639270782e-02
    z[1,5,2]  R726      9.8804473876953125e-02
    z[1,5,2]  R727      -2.0342530310153961e-01
    z[1,5,2]  R728      2.1533285081386566e-01
    z[1,5,2]  R729      -1.9392953813076019e-01
    z[1,5,2]  R730      -3.7211760878562927e-01
    z[1,5,2]  R731      3.8335654139518738e-01
    z[1,5,2]  R732      -2.6121586561203003e-01
    z[1,5,2]  R733      -4.1250422596931458e-01
    z[1,5,2]  R734      -4.9788277596235275e-02
    z[1,5,2]  R735      1.2829124927520752e-01
    z[1,5,2]  R736      2.3098066449165344e-01
    z[1,5,2]  R737      3.1553870439529419e-01
    z[1,5,2]  R738      0.0686025395989418
    z[1,5,2]  R739      -4.4498926401138306e-01
    z[1,5,2]  R740      -4.5791637897491455e-01
    z[1,5,2]  R741      1.6195403039455414e-01
    z[1,5,2]  R742      -2.5885558128356934e-01
    z[1,5,2]  R743      2.4468574672937393e-02
    z[1,5,2]  R744      3.8558891415596008e-01
    z[1,5,2]  R745      -1.9540810957551003e-02
    z[1,5,2]  R746      -5.6084785610437393e-02
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R652      -1
    z[1,5,3]  R653      1
    z[1,5,3]  R660      3.8225373625755310e-01
    z[1,5,3]  R661      -3.9157648570835590e-03
    z[1,5,3]  R662      3.4162499941885471e-03
    z[1,5,3]  R663      5.1377767324447632e-01
    z[1,5,3]  R664      -4.1259959340095520e-02
    z[1,5,3]  R665      -1.7851822078227997e-01
    z[1,5,3]  R666      2.2214195132255554e-01
    z[1,5,3]  R667      -8.9437246322631836e-02
    z[1,5,3]  R668      5.8046829700469971e-01
    z[1,5,3]  R669      -3.0088746547698975e-01
    z[1,5,3]  R670      -1.5492798388004303e-01
    z[1,5,3]  R671      6.3656136393547058e-02
    z[1,5,3]  R672      -2.5527718663215637e-01
    z[1,5,3]  R673      4.5975369215011597e-01
    z[1,5,3]  R674      1.4882178604602814e-01
    z[1,5,3]  R675      2.5903906673192978e-02
    z[1,5,3]  R676      2.0706845819950104e-01
    z[1,5,3]  R677      1.3117501139640808e-01
    z[1,5,3]  R678      -3.1659743189811707e-01
    z[1,5,3]  R679      -3.2407918572425842e-01
    z[1,5,3]  R680      -6.2176507711410522e-01
    z[1,5,3]  R681      -5.0077027082443237e-01
    z[1,5,3]  R682      -5.9560501575469971e-01
    z[1,5,3]  R683      -5.1182800531387329e-01
    z[1,5,3]  R684      -4.4937032461166382e-01
    z[1,5,3]  R685      -4.1226205229759216e-01
    z[1,5,3]  R686      -5.3184306621551514e-01
    z[1,5,3]  R687      -3.8543307781219482e-01
    z[1,5,3]  R688      1.0902522504329681e-01
    z[1,5,3]  R689      -4.0261375904083252e-01
    z[1,5,3]  R690      -6.8117129802703857e-01
    z[1,5,3]  R691      -8.1062769889831543e-01
    z[1,5,3]  R692      -2.4668163061141968e-01
    z[1,5,3]  R693      -5.5053102970123291e-01
    z[1,5,3]  R694      -5.8346831798553467e-01
    z[1,5,3]  R695      -5.0937640666961670e-01
    z[1,5,3]  R696      -5.2619791030883789e-01
    z[1,5,3]  R697      -5.8378511667251587e-01
    z[1,5,3]  R698      0.871620774269104
    z[1,5,3]  R699      -6.9143766164779663e-01
    z[1,5,3]  R700      3.3501684665679932e-01
    z[1,5,3]  R701      -5.4444384574890137e-01
    z[1,5,3]  R702      -6.1271136999130249e-01
    z[1,5,3]  R703      1.0101101547479630e-01
    z[1,5,3]  R704      4.2658537626266479e-01
    z[1,5,3]  R705      3.9055773522704840e-03
    z[1,5,3]  R706      -2.2685249149799347e-01
    z[1,5,3]  R707      5.7542663812637329e-01
    z[1,5,3]  R708      4.0845578908920288e-01
    z[1,5,3]  R709      1.5528170764446259e-01
    z[1,5,3]  R710      1.2737837433815002e-01
    z[1,5,3]  R711      3.0088528990745544e-01
    z[1,5,3]  R712      4.5655813813209534e-01
    z[1,5,3]  R713      -4.9563857913017273e-01
    z[1,5,3]  R714      -3.1470906734466553e-01
    z[1,5,3]  R715      1.1076045036315918e-01
    z[1,5,3]  R716      -3.1615990400314331e-01
    z[1,5,3]  R717      2.7734089642763138e-02
    z[1,5,3]  R718      -3.6465135216712952e-01
    z[1,5,3]  R719      -1.1362092941999435e-01
    z[1,5,3]  R720      -2.0058588683605194e-01
    z[1,5,3]  R721      -2.3111377656459808e-01
    z[1,5,3]  R722      -1.4693267643451691e-01
    z[1,5,3]  R723      3.1360420584678650e-01
    z[1,5,3]  R724      -1.1760506778955460e-01
    z[1,5,3]  R725      3.6228078603744507e-01
    z[1,5,3]  R726      -3.5031415522098541e-02
    z[1,5,3]  R727      -3.0206680297851562e-02
    z[1,5,3]  R728      2.3643206059932709e-01
    z[1,5,3]  R729      2.0475223660469055e-02
    z[1,5,3]  R730      3.4598565101623535e-01
    z[1,5,3]  R731      -1.1399001628160477e-01
    z[1,5,3]  R732      -5.4585546255111694e-01
    z[1,5,3]  R733      -5.9481322765350342e-01
    z[1,5,3]  R734      -5.2916777133941650e-01
    z[1,5,3]  R735      -3.3844679594039917e-01
    z[1,5,3]  R736      -4.7032311558723450e-01
    z[1,5,3]  R737      2.7833151817321777e-01
    z[1,5,3]  R738      6.9129839539527893e-03
    z[1,5,3]  R739      -2.2999511659145355e-01
    z[1,5,3]  R740      -5.7330571115016937e-02
    z[1,5,3]  R741      -5.9929913282394409e-01
    z[1,5,3]  R742      -2.2839865088462830e-01
    z[1,5,3]  R743      -6.1922895908355713e-01
    z[1,5,3]  R744      -0.387405127286911
    z[1,5,3]  R745      -5.4892927408218384e-01
    z[1,5,3]  R746      -1.1917480081319809e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R654      -1
    z[1,5,4]  R655      1
    z[1,5,4]  R660      -1.4558282494544983e-01
    z[1,5,4]  R661      0.163810133934021
    z[1,5,4]  R662      -4.0570143610239029e-03
    z[1,5,4]  R663      1.6149160265922546e-01
    z[1,5,4]  R664      -2.0794370770454407e-01
    z[1,5,4]  R665      -4.6127480268478394e-01
    z[1,5,4]  R666      -2.1602858603000641e-01
    z[1,5,4]  R667      -4.1730195283889771e-01
    z[1,5,4]  R668      2.8576115146279335e-02
    z[1,5,4]  R669      -7.9619465395808220e-03
    z[1,5,4]  R670      -3.2067483663558960e-01
    z[1,5,4]  R671      4.8926392197608948e-01
    z[1,5,4]  R672      1.0910187661647797e-01
    z[1,5,4]  R673      -1.6284523904323578e-01
    z[1,5,4]  R674      5.8057814836502075e-01
    z[1,5,4]  R675      7.0143383741378784e-01
    z[1,5,4]  R676      1.6695725917816162e-01
    z[1,5,4]  R677      1.5419793128967285e-01
    z[1,5,4]  R678      -1.5438987314701080e-01
    z[1,5,4]  R679      2.3761963844299316e-01
    z[1,5,4]  R680      -4.1758334636688232e-01
    z[1,5,4]  R681      -6.3946652412414551e-01
    z[1,5,4]  R682      -0.51181960105896
    z[1,5,4]  R683      -6.6047418117523193e-01
    z[1,5,4]  R684      -0.664966881275177
    z[1,5,4]  R685      -5.8735400438308716e-01
    z[1,5,4]  R686      -0.590451717376709
    z[1,5,4]  R687      -0.0902474895119667
    z[1,5,4]  R688      4.6288406848907471e-01
    z[1,5,4]  R689      3.0597427487373352e-01
    z[1,5,4]  R690      -5.7819157838821411e-01
    z[1,5,4]  R691      -3.3972835540771484e-01
    z[1,5,4]  R692      1.6309560835361481e-01
    z[1,5,4]  R693      -5.4928815364837646e-01
    z[1,5,4]  R694      -3.8938489556312561e-01
    z[1,5,4]  R695      -4.7194615006446838e-01
    z[1,5,4]  R696      -4.4284597039222717e-01
    z[1,5,4]  R697      -4.9810793995857239e-01
    z[1,5,4]  R698      6.9485092535614967e-03
    z[1,5,4]  R699      -1.9424900412559509e-01
    z[1,5,4]  R700      1.0263490676879883e-01
    z[1,5,4]  R701      -4.7431486845016479e-01
    z[1,5,4]  R702      -5.9538251161575317e-01
    z[1,5,4]  R703      2.4018044769763947e-01
    z[1,5,4]  R704      -7.2686426341533661e-02
    z[1,5,4]  R705      3.9153233170509338e-01
    z[1,5,4]  R706      2.3492768406867981e-01
    z[1,5,4]  R707      2.3986333608627319e-01
    z[1,5,4]  R708      -1.1049579083919525e-01
    z[1,5,4]  R709      1.5271799638867378e-02
    z[1,5,4]  R710      -2.7204152941703796e-01
    z[1,5,4]  R711      1.8960656225681305e-01
    z[1,5,4]  R712      2.0966078341007233e-01
    z[1,5,4]  R713      -4.7962281107902527e-01
    z[1,5,4]  R714      -1.6468434035778046e-01
    z[1,5,4]  R715      7.1353238821029663e-01
    z[1,5,4]  R716      3.5656622052192688e-01
    z[1,5,4]  R717      2.0278191193938255e-02
    z[1,5,4]  R718      -2.1379841864109039e-01
    z[1,5,4]  R719      1.2891350686550140e-01
    z[1,5,4]  R720      -5.8095979690551758e-01
    z[1,5,4]  R721      3.6111617088317871e-01
    z[1,5,4]  R722      -4.2486825585365295e-01
    z[1,5,4]  R723      -1.2635989487171173e-01
    z[1,5,4]  R724      2.6446551084518433e-01
    z[1,5,4]  R725      1.8629802763462067e-01
    z[1,5,4]  R726      8.6344647407531738e-01
    z[1,5,4]  R727      5.4700754582881927e-02
    z[1,5,4]  R728      4.2301544547080994e-01
    z[1,5,4]  R729      -2.1201588213443756e-01
    z[1,5,4]  R730      3.5059813410043716e-02
    z[1,5,4]  R731      5.1355826854705811e-01
    z[1,5,4]  R732      -6.5954226255416870e-01
    z[1,5,4]  R733      -0.523227334022522
    z[1,5,4]  R734      -6.3495433330535889e-01
    z[1,5,4]  R735      -2.1799956262111664e-01
    z[1,5,4]  R736      -2.0397461950778961e-01
    z[1,5,4]  R737      3.1452763080596924e-01
    z[1,5,4]  R738      9.4894334673881531e-02
    z[1,5,4]  R739      6.2800779938697815e-02
    z[1,5,4]  R740      4.9770158529281616e-01
    z[1,5,4]  R741      -0.483572393655777
    z[1,5,4]  R742      -2.8351143002510071e-01
    z[1,5,4]  R743      -5.1582843065261841e-01
    z[1,5,4]  R744      -0.463644415140152
    z[1,5,4]  R745      -6.7330557107925415e-01
    z[1,5,4]  R746      -0.00819708127528429
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R656      -1
    z[1,5,5]  R657      1
    z[1,5,5]  R660      -1.6474494338035583e-01
    z[1,5,5]  R661      1.0680849105119705e-01
    z[1,5,5]  R662      -2.0315544307231903e-01
    z[1,5,5]  R663      1.4713162183761597e-01
    z[1,5,5]  R664      5.8734047412872314e-01
    z[1,5,5]  R665      4.0463688969612122e-01
    z[1,5,5]  R666      -1.7513585090637207e-01
    z[1,5,5]  R667      4.1197489947080612e-02
    z[1,5,5]  R668      -8.0205485224723816e-02
    z[1,5,5]  R669      1.2168951332569122e-01
    z[1,5,5]  R670      -2.0801538228988647e-01
    z[1,5,5]  R671      0.0840618684887886
    z[1,5,5]  R672      -1.9511045515537262e-01
    z[1,5,5]  R673      2.8341525793075562e-01
    z[1,5,5]  R674      -2.2321467101573944e-01
    z[1,5,5]  R675      -5.3270065784454346e-01
    z[1,5,5]  R676      -1.6856868565082550e-01
    z[1,5,5]  R677      5.8082717657089233e-01
    z[1,5,5]  R678      4.1606637835502625e-01
    z[1,5,5]  R679      2.6745957136154175e-01
    z[1,5,5]  R680      -4.6029236912727356e-01
    z[1,5,5]  R681      -4.8587009310722351e-01
    z[1,5,5]  R682      -1.2921129167079926e-01
    z[1,5,5]  R683      -1.5246525406837463e-01
    z[1,5,5]  R684      8.5285924375057220e-02
    z[1,5,5]  R685      -1.6475403308868408e-01
    z[1,5,5]  R686      3.6474382877349854e-01
    z[1,5,5]  R687      -5.9170073270797729e-01
    z[1,5,5]  R688      7.1492088027298450e-03
    z[1,5,5]  R689      -1.1673893034458160e-01
    z[1,5,5]  R690      -3.0481332540512085e-01
    z[1,5,5]  R691      -1.1750492453575134e-01
    z[1,5,5]  R692      2.3797427117824554e-01
    z[1,5,5]  R693      -1.9681325554847717e-01
    z[1,5,5]  R694      -2.7384012937545776e-01
    z[1,5,5]  R695      -2.0077195018529892e-02
    z[1,5,5]  R696      7.6294876635074615e-02
    z[1,5,5]  R697      2.1059630811214447e-01
    z[1,5,5]  R698      -3.1465789675712585e-01
    z[1,5,5]  R699      -6.2353044748306274e-01
    z[1,5,5]  R700      -8.8545608520507812e-01
    z[1,5,5]  R701      -3.4213870763778687e-01
    z[1,5,5]  R702      2.4994868040084839e-01
    z[1,5,5]  R703      -4.3828555941581726e-01
    z[1,5,5]  R704      -4.9683102965354919e-01
    z[1,5,5]  R705      -0.0399838462471962
    z[1,5,5]  R706      -0.0658000111579895
    z[1,5,5]  R707      -0.0593063160777092
    z[1,5,5]  R708      -1.0239279270172119e-01
    z[1,5,5]  R709      1.3108867406845093e-01
    z[1,5,5]  R710      -2.9137039557099342e-02
    z[1,5,5]  R711      4.7710424661636353e-01
    z[1,5,5]  R712      6.1132764816284180e-01
    z[1,5,5]  R713      -2.5607712566852570e-02
    z[1,5,5]  R714      -1.0598448663949966e-01
    z[1,5,5]  R715      0.0591808557510376
    z[1,5,5]  R716      -1.3488078117370605e-01
    z[1,5,5]  R717      2.9261562228202820e-01
    z[1,5,5]  R718      2.7521508932113647e-01
    z[1,5,5]  R719      -6.4297604560852051e-01
    z[1,5,5]  R720      2.6581525802612305e-01
    z[1,5,5]  R721      -7.7289767563343048e-02
    z[1,5,5]  R722      -0.688133716583252
    z[1,5,5]  R723      -4.5649823546409607e-01
    z[1,5,5]  R724      -3.7620106339454651e-01
    z[1,5,5]  R725      -4.7036531567573547e-01
    z[1,5,5]  R726      -2.5837129354476929e-01
    z[1,5,5]  R727      1.5638881921768188e-01
    z[1,5,5]  R728      7.5854189693927765e-02
    z[1,5,5]  R729      -2.7757662534713745e-01
    z[1,5,5]  R730      -4.5461425185203552e-01
    z[1,5,5]  R731      -3.6846312880516052e-01
    z[1,5,5]  R732      -4.2448961175978184e-03
    z[1,5,5]  R733      4.9633193761110306e-02
    z[1,5,5]  R734      -2.2574605047702789e-01
    z[1,5,5]  R735      -6.1993849277496338e-01
    z[1,5,5]  R736      -0.504638671875
    z[1,5,5]  R737      2.2373767197132111e-01
    z[1,5,5]  R738      2.8344575315713882e-02
    z[1,5,5]  R739      -2.1390955150127411e-01
    z[1,5,5]  R740      2.4122843146324158e-01
    z[1,5,5]  R741      -0.284828782081604
    z[1,5,5]  R742      -4.4182983040809631e-01
    z[1,5,5]  R743      -1.4362284541130066e-01
    z[1,5,5]  R744      -6.5854269266128540e-01
    z[1,5,5]  R745      -3.1300477683544159e-02
    z[1,5,5]  R746      3.6749291419982910e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R658      -1
    z[1,5,6]  R659      1
    z[1,5,6]  R660      -0.140189990401268
    z[1,5,6]  R661      -2.4210827052593231e-01
    z[1,5,6]  R662      3.4714812040328979e-01
    z[1,5,6]  R663      1.8521706759929657e-01
    z[1,5,6]  R664      3.4891620278358459e-01
    z[1,5,6]  R665      1.3328856229782104e-01
    z[1,5,6]  R666      -5.0446790456771851e-01
    z[1,5,6]  R667      -3.7109351158142090e-01
    z[1,5,6]  R668      -6.3475054502487183e-01
    z[1,5,6]  R669      -1.6226026415824890e-01
    z[1,5,6]  R670      1.9025182723999023e-01
    z[1,5,6]  R671      1.5770034492015839e-01
    z[1,5,6]  R672      3.6910846829414368e-01
    z[1,5,6]  R673      -9.2354238033294678e-02
    z[1,5,6]  R674      3.2046881318092346e-01
    z[1,5,6]  R675      2.5159615278244019e-01
    z[1,5,6]  R676      1.7906135320663452e-01
    z[1,5,6]  R677      2.4797524511814117e-01
    z[1,5,6]  R678      1.5853638947010040e-01
    z[1,5,6]  R679      -1.6094410419464111e-01
    z[1,5,6]  R680      3.7831205874681473e-02
    z[1,5,6]  R681      -8.4387667477130890e-02
    z[1,5,6]  R682      -4.6101531386375427e-01
    z[1,5,6]  R683      3.1176095828413963e-02
    z[1,5,6]  R684      -3.9415098726749420e-02
    z[1,5,6]  R685      0.571651041507721
    z[1,5,6]  R686      1.8962664902210236e-01
    z[1,5,6]  R687      -6.5610265731811523e-01
    z[1,5,6]  R688      2.1570038795471191e-01
    z[1,5,6]  R689      3.4002907574176788e-02
    z[1,5,6]  R690      -1.7430160939693451e-01
    z[1,5,6]  R691      -3.0266538262367249e-01
    z[1,5,6]  R692      4.8268902301788330e-01
    z[1,5,6]  R693      -2.9859754443168640e-01
    z[1,5,6]  R694      2.0012594759464264e-01
    z[1,5,6]  R695      4.0032669901847839e-01
    z[1,5,6]  R696      -4.9231955409049988e-01
    z[1,5,6]  R697      -2.6733508706092834e-01
    z[1,5,6]  R698      1.0189716517925262e-01
    z[1,5,6]  R699      -1.8809950351715088e-01
    z[1,5,6]  R700      -2.0480866730213165e-01
    z[1,5,6]  R701      3.5448002815246582e-01
    z[1,5,6]  R702      2.7313491702079773e-01
    z[1,5,6]  R703      -0.643130362033844
    z[1,5,6]  R704      -5.9421718120574951e-01
    z[1,5,6]  R705      3.4036511182785034e-01
    z[1,5,6]  R706      0.62882399559021
    z[1,5,6]  R707      -2.1957848966121674e-01
    z[1,5,6]  R708      2.2452560067176819e-01
    z[1,5,6]  R709      4.5085042715072632e-02
    z[1,5,6]  R710      -2.5616922974586487e-01
    z[1,5,6]  R711      -2.3681713640689850e-01
    z[1,5,6]  R712      1.5807650983333588e-01
    z[1,5,6]  R713      3.0263975262641907e-01
    z[1,5,6]  R714      -8.2975822687149048e-01
    z[1,5,6]  R715      3.3224666118621826e-01
    z[1,5,6]  R716      3.8006670773029327e-02
    z[1,5,6]  R717      -0.523121178150177
    z[1,5,6]  R718      5.0070118159055710e-02
    z[1,5,6]  R719      -2.8390547633171082e-01
    z[1,5,6]  R720      -1.9579039886593819e-02
    z[1,5,6]  R721      -3.3382558822631836e-01
    z[1,5,6]  R722      3.9094928652048111e-02
    z[1,5,6]  R723      -3.0160054564476013e-01
    z[1,5,6]  R724      2.5230368971824646e-01
    z[1,5,6]  R725      0.0304279662668705
    z[1,5,6]  R726      1.5494583547115326e-01
    z[1,5,6]  R727      -2.0397663116455078e-01
    z[1,5,6]  R728      4.6544083952903748e-01
    z[1,5,6]  R729      0.469174861907959
    z[1,5,6]  R730      9.3000024557113647e-02
    z[1,5,6]  R731      8.3460107445716858e-02
    z[1,5,6]  R732      -4.2939484119415283e-01
    z[1,5,6]  R733      -2.0302060246467590e-01
    z[1,5,6]  R734      4.7779113054275513e-01
    z[1,5,6]  R735      -3.1680914759635925e-01
    z[1,5,6]  R736      2.6725429296493530e-01
    z[1,5,6]  R737      2.8804758191108704e-01
    z[1,5,6]  R738      1.3155448436737061e-01
    z[1,5,6]  R739      3.9790770411491394e-01
    z[1,5,6]  R740      4.2352247983217239e-02
    z[1,5,6]  R741      4.9535080790519714e-01
    z[1,5,6]  R742      -1.9908405840396881e-01
    z[1,5,6]  R743      -4.7892707586288452e-01
    z[1,5,6]  R744      -1.9740824401378632e-01
    z[1,5,6]  R745      -3.8281716406345367e-02
    z[1,5,6]  R746      -3.3507876098155975e-02
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R747      -1
    z[5,1,0]  R748      1
    z[5,1,0]  R761      -5.7996219396591187e-01
    z[5,1,0]  R762      -7.9358226060867310e-01
    z[5,1,0]  R763      -0.518456757068634
    z[5,1,0]  R764      -6.3096517324447632e-01
    z[5,1,0]  R765      -3.6290261149406433e-01
    z[5,1,0]  R766      -5.1928228139877319e-01
    z[5,1,0]  R767      -2.2811952233314514e-01
    z[5,1,0]  R768      4.1172024607658386e-01
    z[5,1,0]  R769      5.6369763612747192e-01
    z[5,1,0]  R770      6.7790520191192627e-01
    z[5,1,0]  R771      2.5977733731269836e-01
    z[5,1,0]  R772      3.2061547040939331e-01
    z[5,1,0]  R773      1.3840182125568390e-01
    z[5,1,0]  R774      -3.0481213331222534e-01
    z[5,1,0]  R775      -5.0336980819702148e-01
    z[5,1,0]  R776      -1.9695284962654114e-01
    z[5,1,0]  R777      -1.1693647503852844e-01
    z[5,1,0]  R778      5.1186162233352661e-01
    z[5,1,0]  R779      6.1486173421144485e-02
    z[5,1,0]  R780      0.04227314889431
    z[5,1,0]  R781      -3.9250290393829346e-01
    z[5,1,0]  R782      2.1174551546573639e-01
    z[5,1,0]  R783      -7.1806021034717560e-02
    z[5,1,0]  R784      -3.5093218088150024e-02
    z[5,1,0]  R785      3.3915615081787109e-01
    z[5,1,0]  R786      -1.1973375082015991e-01
    z[5,1,0]  R787      -3.8449484109878540e-01
    z[5,1,0]  R788      -1.7956182360649109e-01
    z[5,1,0]  R789      -0.182621568441391
    z[5,1,0]  R790      1.0773085057735443e-01
    z[5,1,0]  R791      -0.0769742876291275
    z[5,1,0]  R792      3.2144537568092346e-01
    z[5,1,0]  R793      1.9060429930686951e-01
    z[5,1,0]  R794      2.5585165619850159e-01
    z[5,1,0]  R795      -2.3111756891012192e-02
    z[5,1,0]  R796      3.3616542816162109e-01
    z[5,1,0]  R797      2.4032276868820190e-01
    z[5,1,0]  R798      -8.9384570717811584e-02
    z[5,1,0]  R799      -2.1971440315246582e-01
    z[5,1,0]  R800      -2.1087791025638580e-01
    z[5,1,0]  R801      2.7373647689819336e-01
    z[5,1,0]  R802      -2.9731979966163635e-01
    z[5,1,0]  R803      1.1816011369228363e-01
    z[5,1,0]  R804      -2.8915387392044067e-01
    z[5,1,0]  R805      -2.1819458901882172e-01
    z[5,1,0]  R806      -6.5947575494647026e-03
    z[5,1,0]  R807      3.4752342104911804e-01
    z[5,1,0]  R808      -3.7871897220611572e-01
    z[5,1,0]  R809      -4.6609845757484436e-01
    z[5,1,0]  R810      -3.5970714688301086e-01
    z[5,1,0]  R811      -1.0812094062566757e-01
    z[5,1,0]  R812      -1.2537581846117973e-02
    z[5,1,0]  R813      3.5242241621017456e-01
    z[5,1,0]  R814      -6.9711968302726746e-02
    z[5,1,0]  R815      1.9990468025207520e-01
    z[5,1,0]  R816      2.8056003153324127e-02
    z[5,1,0]  R817      -0.5154989361763
    z[5,1,0]  R818      2.2655533254146576e-01
    z[5,1,0]  R819      3.1677171587944031e-01
    z[5,1,0]  R820      3.0139264464378357e-01
    z[5,1,0]  R821      -3.4421378374099731e-01
    z[5,1,0]  R822      2.2422590851783752e-01
    z[5,1,0]  R823      1.9792316854000092e-01
    z[5,1,0]  R824      3.1178635358810425e-01
    z[5,1,0]  R825      -2.1497267484664917e-01
    z[5,1,0]  R826      1.9140347838401794e-01
    z[5,1,0]  R827      -2.8798022866249084e-01
    z[5,1,0]  R828      -8.8347524404525757e-02
    z[5,1,0]  R829      -7.1481841802597046e-01
    z[5,1,0]  R830      2.5166258215904236e-01
    z[5,1,0]  R831      -2.2615826129913330e-01
    z[5,1,0]  R832      -2.4861498177051544e-01
    z[5,1,0]  R833      -9.1641299426555634e-02
    z[5,1,0]  R834      4.0413862466812134e-01
    z[5,1,0]  R835      3.9909341931343079e-01
    z[5,1,0]  R836      1.1803105473518372e-01
    z[5,1,0]  R837      4.0218746662139893e-01
    z[5,1,0]  R838      4.5351126790046692e-01
    z[5,1,0]  R839      -1.5146599709987640e-01
    z[5,1,0]  R840      1.8265716731548309e-01
    z[5,1,0]  R841      -5.0401080399751663e-02
    z[5,1,0]  R842      4.2824089527130127e-01
    z[5,1,0]  R843      1.5922770835459232e-03
    z[5,1,0]  R844      7.5826868414878845e-02
    z[5,1,0]  R845      1.2530748546123505e-01
    z[5,1,0]  R846      -6.1307537555694580e-01
    z[5,1,0]  R847      -3.1183484196662903e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R749      -1
    z[5,1,1]  R750      1
    z[5,1,1]  R761      2.3080082237720490e-01
    z[5,1,1]  R762      -0.0527375154197216
    z[5,1,1]  R763      2.0245993137359619e-01
    z[5,1,1]  R764      2.6000419165939093e-03
    z[5,1,1]  R765      -2.0599098876118660e-02
    z[5,1,1]  R766      -5.4028481245040894e-02
    z[5,1,1]  R767      6.0787373781204224e-01
    z[5,1,1]  R768      6.5360605716705322e-02
    z[5,1,1]  R769      2.1668045222759247e-01
    z[5,1,1]  R770      -1.9635602831840515e-02
    z[5,1,1]  R771      -7.4423557519912720e-01
    z[5,1,1]  R772      -7.7088785171508789e-01
    z[5,1,1]  R773      -6.4877432584762573e-01
    z[5,1,1]  R774      -6.7080420255661011e-01
    z[5,1,1]  R775      -0.663345456123352
    z[5,1,1]  R776      -5.3227263689041138e-01
    z[5,1,1]  R777      -0.687248170375824
    z[5,1,1]  R778      -0.569867730140686
    z[5,1,1]  R779      -0.77773118019104
    z[5,1,1]  R780      -3.8848367333412170e-01
    z[5,1,1]  R781      -8.5708284378051758e-01
    z[5,1,1]  R782      -0.671985387802124
    z[5,1,1]  R783      -7.8402262926101685e-01
    z[5,1,1]  R784      -0.723905086517334
    z[5,1,1]  R785      -5.6439733505249023e-01
    z[5,1,1]  R786      -0.00883125513792038
    z[5,1,1]  R787      -0.103699691593647
    z[5,1,1]  R788      5.3361009806394577e-02
    z[5,1,1]  R789      5.5084377527236938e-01
    z[5,1,1]  R790      5.8834302425384521e-01
    z[5,1,1]  R791      -0.764907956123352
    z[5,1,1]  R792      -9.2994827032089233e-01
    z[5,1,1]  R793      -7.1044009923934937e-01
    z[5,1,1]  R794      -6.4333051443099976e-01
    z[5,1,1]  R795      2.3180831968784332e-01
    z[5,1,1]  R796      -6.7275100946426392e-01
    z[5,1,1]  R797      2.0524153113365173e-01
    z[5,1,1]  R798      7.5061500072479248e-02
    z[5,1,1]  R799      4.4072076678276062e-01
    z[5,1,1]  R800      8.9551174640655518e-01
    z[5,1,1]  R801      -3.3498278260231018e-01
    z[5,1,1]  R802      8.9675587415695190e-01
    z[5,1,1]  R803      8.7505888938903809e-01
    z[5,1,1]  R804      -6.1318643391132355e-02
    z[5,1,1]  R805      6.6259676218032837e-01
    z[5,1,1]  R806      0.692440390586853
    z[5,1,1]  R807      7.0537883043289185e-01
    z[5,1,1]  R808      7.3126709461212158e-01
    z[5,1,1]  R809      -6.4546540379524231e-02
    z[5,1,1]  R810      -0.858400285243988
    z[5,1,1]  R811      -0.876112699508667
    z[5,1,1]  R812      -8.0603712797164917e-01
    z[5,1,1]  R813      -7.7500116825103760e-01
    z[5,1,1]  R814      -7.7883827686309814e-01
    z[5,1,1]  R815      -6.4629852771759033e-01
    z[5,1,1]  R816      -3.9202803373336792e-01
    z[5,1,1]  R817      -7.4260437488555908e-01
    z[5,1,1]  R818      -7.1300995349884033e-01
    z[5,1,1]  R819      -7.1007263660430908e-01
    z[5,1,1]  R820      -7.9286617040634155e-01
    z[5,1,1]  R821      2.7025574445724487e-01
    z[5,1,1]  R822      8.4632793441414833e-03
    z[5,1,1]  R823      1.5935626626014709e-01
    z[5,1,1]  R824      4.2423886060714722e-01
    z[5,1,1]  R825      7.1896232664585114e-02
    z[5,1,1]  R826      -2.3277062922716141e-02
    z[5,1,1]  R827      -1.3731746375560760e-01
    z[5,1,1]  R828      -2.2696368396282196e-01
    z[5,1,1]  R829      4.0837100148200989e-01
    z[5,1,1]  R830      -8.0349564552307129e-01
    z[5,1,1]  R831      1.5217198431491852e-01
    z[5,1,1]  R832      3.4239817410707474e-02
    z[5,1,1]  R833      -6.0378062725067139e-01
    z[5,1,1]  R834      3.2040509581565857e-01
    z[5,1,1]  R835      3.1255221366882324e-01
    z[5,1,1]  R836      2.8163838386535645e-01
    z[5,1,1]  R837      -2.9545217752456665e-01
    z[5,1,1]  R838      -3.1975455582141876e-02
    z[5,1,1]  R839      1.0061888396739960e-01
    z[5,1,1]  R840      -4.9161937087774277e-02
    z[5,1,1]  R841      2.2024077177047729e-01
    z[5,1,1]  R842      -2.2849030792713165e-01
    z[5,1,1]  R843      -1.7041325569152832e-02
    z[5,1,1]  R844      -0.54848712682724
    z[5,1,1]  R845      -2.8677159547805786e-01
    z[5,1,1]  R846      5.2385908365249634e-01
    z[5,1,1]  R847      0.618018388748169
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R751      -1
    z[5,1,2]  R752      1
    z[5,1,2]  R761      4.1230174899101257e-01
    z[5,1,2]  R762      3.5707753896713257e-01
    z[5,1,2]  R763      8.0414557456970215e-01
    z[5,1,2]  R764      6.6721254587173462e-01
    z[5,1,2]  R765      6.7652350664138794e-01
    z[5,1,2]  R766      2.7625033259391785e-01
    z[5,1,2]  R767      1.0251188278198242e-01
    z[5,1,2]  R768      -1.7896650359034538e-02
    z[5,1,2]  R769      -2.8267744928598404e-03
    z[5,1,2]  R770      5.4159498214721680e-01
    z[5,1,2]  R771      1.3479290902614594e-01
    z[5,1,2]  R772      2.1449199318885803e-01
    z[5,1,2]  R773      1.9075600802898407e-01
    z[5,1,2]  R774      -9.1220803558826447e-02
    z[5,1,2]  R775      -7.3211520910263062e-02
    z[5,1,2]  R776      2.7145119383931160e-02
    z[5,1,2]  R777      -3.1677749752998352e-01
    z[5,1,2]  R778      3.5254955291748047e-01
    z[5,1,2]  R779      -5.6832976639270782e-02
    z[5,1,2]  R780      9.8804473876953125e-02
    z[5,1,2]  R781      -2.0342530310153961e-01
    z[5,1,2]  R782      2.1533285081386566e-01
    z[5,1,2]  R783      -1.9392953813076019e-01
    z[5,1,2]  R784      -3.7211760878562927e-01
    z[5,1,2]  R785      3.8335654139518738e-01
    z[5,1,2]  R786      -2.6121586561203003e-01
    z[5,1,2]  R787      -4.1250422596931458e-01
    z[5,1,2]  R788      -4.9788277596235275e-02
    z[5,1,2]  R789      1.2829124927520752e-01
    z[5,1,2]  R790      2.3098066449165344e-01
    z[5,1,2]  R791      3.1553870439529419e-01
    z[5,1,2]  R792      0.0686025395989418
    z[5,1,2]  R793      -4.4498926401138306e-01
    z[5,1,2]  R794      -4.5791637897491455e-01
    z[5,1,2]  R795      1.6195403039455414e-01
    z[5,1,2]  R796      -2.5885558128356934e-01
    z[5,1,2]  R797      2.4468574672937393e-02
    z[5,1,2]  R798      3.8558891415596008e-01
    z[5,1,2]  R799      -1.9540810957551003e-02
    z[5,1,2]  R800      -5.6084785610437393e-02
    z[5,1,2]  R801      7.7378839254379272e-01
    z[5,1,2]  R802      1.0274402797222137e-01
    z[5,1,2]  R803      2.4186423420906067e-01
    z[5,1,2]  R804      7.5274819135665894e-01
    z[5,1,2]  R805      4.1259959340095520e-02
    z[5,1,2]  R806      0.307152658700943
    z[5,1,2]  R807      2.2188268601894379e-02
    z[5,1,2]  R808      1.6515260562300682e-02
    z[5,1,2]  R809      1.7743951082229614e-01
    z[5,1,2]  R810      4.5016493648290634e-02
    z[5,1,2]  R811      -1.2014707922935486e-01
    z[5,1,2]  R812      -2.7345892786979675e-01
    z[5,1,2]  R813      -1.5424926578998566e-01
    z[5,1,2]  R814      -2.4860759079456329e-01
    z[5,1,2]  R815      -1.7490682005882263e-01
    z[5,1,2]  R816      -7.5999490916728973e-02
    z[5,1,2]  R817      -2.2708848118782043e-01
    z[5,1,2]  R818      2.1298274397850037e-02
    z[5,1,2]  R819      -0.270439088344574
    z[5,1,2]  R820      1.4696128666400909e-01
    z[5,1,2]  R821      1.8496122956275940e-01
    z[5,1,2]  R822      2.1626810729503632e-01
    z[5,1,2]  R823      -0.299159973859787
    z[5,1,2]  R824      1.9976884126663208e-02
    z[5,1,2]  R825      5.4376077651977539e-01
    z[5,1,2]  R826      0.306511789560318
    z[5,1,2]  R827      3.1260961294174194e-01
    z[5,1,2]  R828      5.8296412229537964e-02
    z[5,1,2]  R829      -2.2257991135120392e-01
    z[5,1,2]  R830      1.4338243007659912e-01
    z[5,1,2]  R831      -6.4063794910907745e-02
    z[5,1,2]  R832      2.4304716289043427e-01
    z[5,1,2]  R833      4.9997827410697937e-01
    z[5,1,2]  R834      3.6259759217500687e-02
    z[5,1,2]  R835      -3.6870157718658447e-01
    z[5,1,2]  R836      5.1369881629943848e-01
    z[5,1,2]  R837      1.7250214517116547e-01
    z[5,1,2]  R838      2.9760643839836121e-01
    z[5,1,2]  R839      -3.1268224120140076e-01
    z[5,1,2]  R840      -1.5565671026706696e-01
    z[5,1,2]  R841      1.4295632019639015e-02
    z[5,1,2]  R842      -1.7127253115177155e-02
    z[5,1,2]  R843      -3.6432725191116333e-01
    z[5,1,2]  R844      -1.4075274765491486e-01
    z[5,1,2]  R845      -3.3891963958740234e-01
    z[5,1,2]  R846      -0.280981183052063
    z[5,1,2]  R847      1.2004150450229645e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R753      -1
    z[5,1,3]  R754      1
    z[5,1,3]  R761      5.7542663812637329e-01
    z[5,1,3]  R762      4.0845578908920288e-01
    z[5,1,3]  R763      1.5528170764446259e-01
    z[5,1,3]  R764      1.2737837433815002e-01
    z[5,1,3]  R765      3.0088528990745544e-01
    z[5,1,3]  R766      4.5655813813209534e-01
    z[5,1,3]  R767      -4.9563857913017273e-01
    z[5,1,3]  R768      -3.1470906734466553e-01
    z[5,1,3]  R769      1.1076045036315918e-01
    z[5,1,3]  R770      -3.1615990400314331e-01
    z[5,1,3]  R771      2.7734089642763138e-02
    z[5,1,3]  R772      -3.6465135216712952e-01
    z[5,1,3]  R773      -1.1362092941999435e-01
    z[5,1,3]  R774      -2.0058588683605194e-01
    z[5,1,3]  R775      -2.3111377656459808e-01
    z[5,1,3]  R776      -1.4693267643451691e-01
    z[5,1,3]  R777      3.1360420584678650e-01
    z[5,1,3]  R778      -1.1760506778955460e-01
    z[5,1,3]  R779      3.6228078603744507e-01
    z[5,1,3]  R780      -3.5031415522098541e-02
    z[5,1,3]  R781      -3.0206680297851562e-02
    z[5,1,3]  R782      2.3643206059932709e-01
    z[5,1,3]  R783      2.0475223660469055e-02
    z[5,1,3]  R784      3.4598565101623535e-01
    z[5,1,3]  R785      -1.1399001628160477e-01
    z[5,1,3]  R786      -5.4585546255111694e-01
    z[5,1,3]  R787      -5.9481322765350342e-01
    z[5,1,3]  R788      -5.2916777133941650e-01
    z[5,1,3]  R789      -3.3844679594039917e-01
    z[5,1,3]  R790      -4.7032311558723450e-01
    z[5,1,3]  R791      2.7833151817321777e-01
    z[5,1,3]  R792      6.9129839539527893e-03
    z[5,1,3]  R793      -2.2999511659145355e-01
    z[5,1,3]  R794      -5.7330571115016937e-02
    z[5,1,3]  R795      -5.9929913282394409e-01
    z[5,1,3]  R796      -2.2839865088462830e-01
    z[5,1,3]  R797      -6.1922895908355713e-01
    z[5,1,3]  R798      -0.387405127286911
    z[5,1,3]  R799      -5.4892927408218384e-01
    z[5,1,3]  R800      -1.1917480081319809e-01
    z[5,1,3]  R801      3.8225373625755310e-01
    z[5,1,3]  R802      -3.9157648570835590e-03
    z[5,1,3]  R803      3.4162499941885471e-03
    z[5,1,3]  R804      5.1377767324447632e-01
    z[5,1,3]  R805      -4.1259959340095520e-02
    z[5,1,3]  R806      -1.7851822078227997e-01
    z[5,1,3]  R807      2.2214195132255554e-01
    z[5,1,3]  R808      -8.9437246322631836e-02
    z[5,1,3]  R809      5.8046829700469971e-01
    z[5,1,3]  R810      -3.0088746547698975e-01
    z[5,1,3]  R811      -1.5492798388004303e-01
    z[5,1,3]  R812      6.3656136393547058e-02
    z[5,1,3]  R813      -2.5527718663215637e-01
    z[5,1,3]  R814      4.5975369215011597e-01
    z[5,1,3]  R815      1.4882178604602814e-01
    z[5,1,3]  R816      2.5903906673192978e-02
    z[5,1,3]  R817      2.0706845819950104e-01
    z[5,1,3]  R818      1.3117501139640808e-01
    z[5,1,3]  R819      -3.1659743189811707e-01
    z[5,1,3]  R820      -3.2407918572425842e-01
    z[5,1,3]  R821      -6.2176507711410522e-01
    z[5,1,3]  R822      -5.0077027082443237e-01
    z[5,1,3]  R823      -5.9560501575469971e-01
    z[5,1,3]  R824      -5.1182800531387329e-01
    z[5,1,3]  R825      -4.4937032461166382e-01
    z[5,1,3]  R826      -4.1226205229759216e-01
    z[5,1,3]  R827      -5.3184306621551514e-01
    z[5,1,3]  R828      -3.8543307781219482e-01
    z[5,1,3]  R829      1.0902522504329681e-01
    z[5,1,3]  R830      -4.0261375904083252e-01
    z[5,1,3]  R831      -6.8117129802703857e-01
    z[5,1,3]  R832      -8.1062769889831543e-01
    z[5,1,3]  R833      -2.4668163061141968e-01
    z[5,1,3]  R834      -5.5053102970123291e-01
    z[5,1,3]  R835      -5.8346831798553467e-01
    z[5,1,3]  R836      -5.0937640666961670e-01
    z[5,1,3]  R837      -5.2619791030883789e-01
    z[5,1,3]  R838      -5.8378511667251587e-01
    z[5,1,3]  R839      0.871620774269104
    z[5,1,3]  R840      -6.9143766164779663e-01
    z[5,1,3]  R841      3.3501684665679932e-01
    z[5,1,3]  R842      -5.4444384574890137e-01
    z[5,1,3]  R843      -6.1271136999130249e-01
    z[5,1,3]  R844      1.0101101547479630e-01
    z[5,1,3]  R845      4.2658537626266479e-01
    z[5,1,3]  R846      3.9055773522704840e-03
    z[5,1,3]  R847      -2.2685249149799347e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R755      -1
    z[5,1,4]  R756      1
    z[5,1,4]  R761      2.3986333608627319e-01
    z[5,1,4]  R762      -1.1049579083919525e-01
    z[5,1,4]  R763      1.5271799638867378e-02
    z[5,1,4]  R764      -2.7204152941703796e-01
    z[5,1,4]  R765      1.8960656225681305e-01
    z[5,1,4]  R766      2.0966078341007233e-01
    z[5,1,4]  R767      -4.7962281107902527e-01
    z[5,1,4]  R768      -1.6468434035778046e-01
    z[5,1,4]  R769      7.1353238821029663e-01
    z[5,1,4]  R770      3.5656622052192688e-01
    z[5,1,4]  R771      2.0278191193938255e-02
    z[5,1,4]  R772      -2.1379841864109039e-01
    z[5,1,4]  R773      1.2891350686550140e-01
    z[5,1,4]  R774      -5.8095979690551758e-01
    z[5,1,4]  R775      3.6111617088317871e-01
    z[5,1,4]  R776      -4.2486825585365295e-01
    z[5,1,4]  R777      -1.2635989487171173e-01
    z[5,1,4]  R778      2.6446551084518433e-01
    z[5,1,4]  R779      1.8629802763462067e-01
    z[5,1,4]  R780      8.6344647407531738e-01
    z[5,1,4]  R781      5.4700754582881927e-02
    z[5,1,4]  R782      4.2301544547080994e-01
    z[5,1,4]  R783      -2.1201588213443756e-01
    z[5,1,4]  R784      3.5059813410043716e-02
    z[5,1,4]  R785      5.1355826854705811e-01
    z[5,1,4]  R786      -6.5954226255416870e-01
    z[5,1,4]  R787      -0.523227334022522
    z[5,1,4]  R788      -6.3495433330535889e-01
    z[5,1,4]  R789      -2.1799956262111664e-01
    z[5,1,4]  R790      -2.0397461950778961e-01
    z[5,1,4]  R791      3.1452763080596924e-01
    z[5,1,4]  R792      9.4894334673881531e-02
    z[5,1,4]  R793      6.2800779938697815e-02
    z[5,1,4]  R794      4.9770158529281616e-01
    z[5,1,4]  R795      -0.483572393655777
    z[5,1,4]  R796      -2.8351143002510071e-01
    z[5,1,4]  R797      -5.1582843065261841e-01
    z[5,1,4]  R798      -0.463644415140152
    z[5,1,4]  R799      -6.7330557107925415e-01
    z[5,1,4]  R800      -0.00819708127528429
    z[5,1,4]  R801      -1.4558282494544983e-01
    z[5,1,4]  R802      0.163810133934021
    z[5,1,4]  R803      -4.0570143610239029e-03
    z[5,1,4]  R804      1.6149160265922546e-01
    z[5,1,4]  R805      -2.0794370770454407e-01
    z[5,1,4]  R806      -4.6127480268478394e-01
    z[5,1,4]  R807      -2.1602858603000641e-01
    z[5,1,4]  R808      -4.1730195283889771e-01
    z[5,1,4]  R809      2.8576115146279335e-02
    z[5,1,4]  R810      -7.9619465395808220e-03
    z[5,1,4]  R811      -3.2067483663558960e-01
    z[5,1,4]  R812      4.8926392197608948e-01
    z[5,1,4]  R813      1.0910187661647797e-01
    z[5,1,4]  R814      -1.6284523904323578e-01
    z[5,1,4]  R815      5.8057814836502075e-01
    z[5,1,4]  R816      7.0143383741378784e-01
    z[5,1,4]  R817      1.6695725917816162e-01
    z[5,1,4]  R818      1.5419793128967285e-01
    z[5,1,4]  R819      -1.5438987314701080e-01
    z[5,1,4]  R820      2.3761963844299316e-01
    z[5,1,4]  R821      -4.1758334636688232e-01
    z[5,1,4]  R822      -6.3946652412414551e-01
    z[5,1,4]  R823      -0.51181960105896
    z[5,1,4]  R824      -6.6047418117523193e-01
    z[5,1,4]  R825      -0.664966881275177
    z[5,1,4]  R826      -5.8735400438308716e-01
    z[5,1,4]  R827      -0.590451717376709
    z[5,1,4]  R828      -0.0902474895119667
    z[5,1,4]  R829      4.6288406848907471e-01
    z[5,1,4]  R830      3.0597427487373352e-01
    z[5,1,4]  R831      -5.7819157838821411e-01
    z[5,1,4]  R832      -3.3972835540771484e-01
    z[5,1,4]  R833      1.6309560835361481e-01
    z[5,1,4]  R834      -5.4928815364837646e-01
    z[5,1,4]  R835      -3.8938489556312561e-01
    z[5,1,4]  R836      -4.7194615006446838e-01
    z[5,1,4]  R837      -4.4284597039222717e-01
    z[5,1,4]  R838      -4.9810793995857239e-01
    z[5,1,4]  R839      6.9485092535614967e-03
    z[5,1,4]  R840      -1.9424900412559509e-01
    z[5,1,4]  R841      1.0263490676879883e-01
    z[5,1,4]  R842      -4.7431486845016479e-01
    z[5,1,4]  R843      -5.9538251161575317e-01
    z[5,1,4]  R844      2.4018044769763947e-01
    z[5,1,4]  R845      -7.2686426341533661e-02
    z[5,1,4]  R846      3.9153233170509338e-01
    z[5,1,4]  R847      2.3492768406867981e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R757      -1
    z[5,1,5]  R758      1
    z[5,1,5]  R761      -0.0593063160777092
    z[5,1,5]  R762      -1.0239279270172119e-01
    z[5,1,5]  R763      1.3108867406845093e-01
    z[5,1,5]  R764      -2.9137039557099342e-02
    z[5,1,5]  R765      4.7710424661636353e-01
    z[5,1,5]  R766      6.1132764816284180e-01
    z[5,1,5]  R767      -2.5607712566852570e-02
    z[5,1,5]  R768      -1.0598448663949966e-01
    z[5,1,5]  R769      0.0591808557510376
    z[5,1,5]  R770      -1.3488078117370605e-01
    z[5,1,5]  R771      2.9261562228202820e-01
    z[5,1,5]  R772      2.7521508932113647e-01
    z[5,1,5]  R773      -6.4297604560852051e-01
    z[5,1,5]  R774      2.6581525802612305e-01
    z[5,1,5]  R775      -7.7289767563343048e-02
    z[5,1,5]  R776      -0.688133716583252
    z[5,1,5]  R777      -4.5649823546409607e-01
    z[5,1,5]  R778      -3.7620106339454651e-01
    z[5,1,5]  R779      -4.7036531567573547e-01
    z[5,1,5]  R780      -2.5837129354476929e-01
    z[5,1,5]  R781      1.5638881921768188e-01
    z[5,1,5]  R782      7.5854189693927765e-02
    z[5,1,5]  R783      -2.7757662534713745e-01
    z[5,1,5]  R784      -4.5461425185203552e-01
    z[5,1,5]  R785      -3.6846312880516052e-01
    z[5,1,5]  R786      -4.2448961175978184e-03
    z[5,1,5]  R787      4.9633193761110306e-02
    z[5,1,5]  R788      -2.2574605047702789e-01
    z[5,1,5]  R789      -6.1993849277496338e-01
    z[5,1,5]  R790      -0.504638671875
    z[5,1,5]  R791      2.2373767197132111e-01
    z[5,1,5]  R792      2.8344575315713882e-02
    z[5,1,5]  R793      -2.1390955150127411e-01
    z[5,1,5]  R794      2.4122843146324158e-01
    z[5,1,5]  R795      -0.284828782081604
    z[5,1,5]  R796      -4.4182983040809631e-01
    z[5,1,5]  R797      -1.4362284541130066e-01
    z[5,1,5]  R798      -6.5854269266128540e-01
    z[5,1,5]  R799      -3.1300477683544159e-02
    z[5,1,5]  R800      3.6749291419982910e-01
    z[5,1,5]  R801      -1.6474494338035583e-01
    z[5,1,5]  R802      1.0680849105119705e-01
    z[5,1,5]  R803      -2.0315544307231903e-01
    z[5,1,5]  R804      1.4713162183761597e-01
    z[5,1,5]  R805      5.8734047412872314e-01
    z[5,1,5]  R806      4.0463688969612122e-01
    z[5,1,5]  R807      -1.7513585090637207e-01
    z[5,1,5]  R808      4.1197489947080612e-02
    z[5,1,5]  R809      -8.0205485224723816e-02
    z[5,1,5]  R810      1.2168951332569122e-01
    z[5,1,5]  R811      -2.0801538228988647e-01
    z[5,1,5]  R812      0.0840618684887886
    z[5,1,5]  R813      -1.9511045515537262e-01
    z[5,1,5]  R814      2.8341525793075562e-01
    z[5,1,5]  R815      -2.2321467101573944e-01
    z[5,1,5]  R816      -5.3270065784454346e-01
    z[5,1,5]  R817      -1.6856868565082550e-01
    z[5,1,5]  R818      5.8082717657089233e-01
    z[5,1,5]  R819      4.1606637835502625e-01
    z[5,1,5]  R820      2.6745957136154175e-01
    z[5,1,5]  R821      -4.6029236912727356e-01
    z[5,1,5]  R822      -4.8587009310722351e-01
    z[5,1,5]  R823      -1.2921129167079926e-01
    z[5,1,5]  R824      -1.5246525406837463e-01
    z[5,1,5]  R825      8.5285924375057220e-02
    z[5,1,5]  R826      -1.6475403308868408e-01
    z[5,1,5]  R827      3.6474382877349854e-01
    z[5,1,5]  R828      -5.9170073270797729e-01
    z[5,1,5]  R829      7.1492088027298450e-03
    z[5,1,5]  R830      -1.1673893034458160e-01
    z[5,1,5]  R831      -3.0481332540512085e-01
    z[5,1,5]  R832      -1.1750492453575134e-01
    z[5,1,5]  R833      2.3797427117824554e-01
    z[5,1,5]  R834      -1.9681325554847717e-01
    z[5,1,5]  R835      -2.7384012937545776e-01
    z[5,1,5]  R836      -2.0077195018529892e-02
    z[5,1,5]  R837      7.6294876635074615e-02
    z[5,1,5]  R838      2.1059630811214447e-01
    z[5,1,5]  R839      -3.1465789675712585e-01
    z[5,1,5]  R840      -6.2353044748306274e-01
    z[5,1,5]  R841      -8.8545608520507812e-01
    z[5,1,5]  R842      -3.4213870763778687e-01
    z[5,1,5]  R843      2.4994868040084839e-01
    z[5,1,5]  R844      -4.3828555941581726e-01
    z[5,1,5]  R845      -4.9683102965354919e-01
    z[5,1,5]  R846      -0.0399838462471962
    z[5,1,5]  R847      -0.0658000111579895
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R759      -1
    z[5,1,6]  R760      1
    z[5,1,6]  R761      -2.1957848966121674e-01
    z[5,1,6]  R762      2.2452560067176819e-01
    z[5,1,6]  R763      4.5085042715072632e-02
    z[5,1,6]  R764      -2.5616922974586487e-01
    z[5,1,6]  R765      -2.3681713640689850e-01
    z[5,1,6]  R766      1.5807650983333588e-01
    z[5,1,6]  R767      3.0263975262641907e-01
    z[5,1,6]  R768      -8.2975822687149048e-01
    z[5,1,6]  R769      3.3224666118621826e-01
    z[5,1,6]  R770      3.8006670773029327e-02
    z[5,1,6]  R771      -0.523121178150177
    z[5,1,6]  R772      5.0070118159055710e-02
    z[5,1,6]  R773      -2.8390547633171082e-01
    z[5,1,6]  R774      -1.9579039886593819e-02
    z[5,1,6]  R775      -3.3382558822631836e-01
    z[5,1,6]  R776      3.9094928652048111e-02
    z[5,1,6]  R777      -3.0160054564476013e-01
    z[5,1,6]  R778      2.5230368971824646e-01
    z[5,1,6]  R779      0.0304279662668705
    z[5,1,6]  R780      1.5494583547115326e-01
    z[5,1,6]  R781      -2.0397663116455078e-01
    z[5,1,6]  R782      4.6544083952903748e-01
    z[5,1,6]  R783      0.469174861907959
    z[5,1,6]  R784      9.3000024557113647e-02
    z[5,1,6]  R785      8.3460107445716858e-02
    z[5,1,6]  R786      -4.2939484119415283e-01
    z[5,1,6]  R787      -2.0302060246467590e-01
    z[5,1,6]  R788      4.7779113054275513e-01
    z[5,1,6]  R789      -3.1680914759635925e-01
    z[5,1,6]  R790      2.6725429296493530e-01
    z[5,1,6]  R791      2.8804758191108704e-01
    z[5,1,6]  R792      1.3155448436737061e-01
    z[5,1,6]  R793      3.9790770411491394e-01
    z[5,1,6]  R794      4.2352247983217239e-02
    z[5,1,6]  R795      4.9535080790519714e-01
    z[5,1,6]  R796      -1.9908405840396881e-01
    z[5,1,6]  R797      -4.7892707586288452e-01
    z[5,1,6]  R798      -1.9740824401378632e-01
    z[5,1,6]  R799      -3.8281716406345367e-02
    z[5,1,6]  R800      -3.3507876098155975e-02
    z[5,1,6]  R801      -0.140189990401268
    z[5,1,6]  R802      -2.4210827052593231e-01
    z[5,1,6]  R803      3.4714812040328979e-01
    z[5,1,6]  R804      1.8521706759929657e-01
    z[5,1,6]  R805      3.4891620278358459e-01
    z[5,1,6]  R806      1.3328856229782104e-01
    z[5,1,6]  R807      -5.0446790456771851e-01
    z[5,1,6]  R808      -3.7109351158142090e-01
    z[5,1,6]  R809      -6.3475054502487183e-01
    z[5,1,6]  R810      -1.6226026415824890e-01
    z[5,1,6]  R811      1.9025182723999023e-01
    z[5,1,6]  R812      1.5770034492015839e-01
    z[5,1,6]  R813      3.6910846829414368e-01
    z[5,1,6]  R814      -9.2354238033294678e-02
    z[5,1,6]  R815      3.2046881318092346e-01
    z[5,1,6]  R816      2.5159615278244019e-01
    z[5,1,6]  R817      1.7906135320663452e-01
    z[5,1,6]  R818      2.4797524511814117e-01
    z[5,1,6]  R819      1.5853638947010040e-01
    z[5,1,6]  R820      -1.6094410419464111e-01
    z[5,1,6]  R821      3.7831205874681473e-02
    z[5,1,6]  R822      -8.4387667477130890e-02
    z[5,1,6]  R823      -4.6101531386375427e-01
    z[5,1,6]  R824      3.1176095828413963e-02
    z[5,1,6]  R825      -3.9415098726749420e-02
    z[5,1,6]  R826      0.571651041507721
    z[5,1,6]  R827      1.8962664902210236e-01
    z[5,1,6]  R828      -6.5610265731811523e-01
    z[5,1,6]  R829      2.1570038795471191e-01
    z[5,1,6]  R830      3.4002907574176788e-02
    z[5,1,6]  R831      -1.7430160939693451e-01
    z[5,1,6]  R832      -3.0266538262367249e-01
    z[5,1,6]  R833      4.8268902301788330e-01
    z[5,1,6]  R834      -2.9859754443168640e-01
    z[5,1,6]  R835      2.0012594759464264e-01
    z[5,1,6]  R836      4.0032669901847839e-01
    z[5,1,6]  R837      -4.9231955409049988e-01
    z[5,1,6]  R838      -2.6733508706092834e-01
    z[5,1,6]  R839      1.0189716517925262e-01
    z[5,1,6]  R840      -1.8809950351715088e-01
    z[5,1,6]  R841      -2.0480866730213165e-01
    z[5,1,6]  R842      3.5448002815246582e-01
    z[5,1,6]  R843      2.7313491702079773e-01
    z[5,1,6]  R844      -0.643130362033844
    z[5,1,6]  R845      -5.9421718120574951e-01
    z[5,1,6]  R846      3.4036511182785034e-01
    z[5,1,6]  R847      0.62882399559021
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R848      -1
    z[2,3,0]  R849      1
    z[2,3,0]  R862      2.5846919417381287e-01
    z[2,3,0]  R863      2.8779031708836555e-02
    z[2,3,0]  R864      -7.3980921506881714e-01
    z[2,3,0]  R865      -1.1959360539913177e-01
    z[2,3,0]  R866      -2.6762092113494873e-01
    z[2,3,0]  R867      -1.7991174757480621e-01
    z[2,3,0]  R868      -2.8292530775070190e-01
    z[2,3,0]  R869      -2.8297838568687439e-01
    z[2,3,0]  R870      -7.7906721830368042e-01
    z[2,3,0]  R871      -0.076054647564888
    z[2,3,0]  R872      -3.9875549077987671e-01
    z[2,3,0]  R873      1.1275541782379150e-01
    z[2,3,0]  R874      -4.3298348784446716e-02
    z[2,3,0]  R875      -3.5161290317773819e-02
    z[2,3,0]  R876      4.9804711341857910e-01
    z[2,3,0]  R877      -5.5517643690109253e-01
    z[2,3,0]  R878      9.2943632602691650e-01
    z[2,3,0]  R879      8.9745700359344482e-01
    z[2,3,0]  R880      3.7250635027885437e-01
    z[2,3,0]  R881      -3.1514719128608704e-01
    z[2,3,0]  R882      -4.7950640320777893e-01
    z[2,3,0]  R883      -5.1822578907012939e-01
    z[2,3,0]  R884      -0.445139616727829
    z[2,3,0]  R885      -8.6039073765277863e-02
    z[2,3,0]  R886      -1.7476458847522736e-01
    z[2,3,0]  R887      4.5696116983890533e-02
    z[2,3,0]  R888      -4.2043957114219666e-01
    z[2,3,0]  R889      -1.2850791215896606e-01
    z[2,3,0]  R890      -3.8403651118278503e-01
    z[2,3,0]  R891      -5.9794867038726807e-01
    z[2,3,0]  R892      -5.3884852677583694e-02
    z[2,3,0]  R893      -5.6895685195922852e-01
    z[2,3,0]  R894      -4.6248784661293030e-01
    z[2,3,0]  R895      -5.1832705736160278e-01
    z[2,3,0]  R896      0.127742201089859
    z[2,3,0]  R897      1.5131257474422455e-01
    z[2,3,0]  R898      -4.2566746473312378e-01
    z[2,3,0]  R899      2.5695389509201050e-01
    z[2,3,0]  R900      3.7997964024543762e-01
    z[2,3,0]  R901      -1.9350335001945496e-01
    z[2,3,0]  R902      -1.9371852278709412e-01
    z[2,3,0]  R903      -1.5649942681193352e-02
    z[2,3,0]  R904      -2.6204961538314819e-01
    z[2,3,0]  R905      4.7014385461807251e-01
    z[2,3,0]  R906      5.2563732862472534e-01
    z[2,3,0]  R907      3.9286059141159058e-01
    z[2,3,0]  R908      5.6286227703094482e-01
    z[2,3,0]  R909      -1.9090999662876129e-01
    z[2,3,0]  R910      7.5469031929969788e-02
    z[2,3,0]  R911      9.2340342700481415e-02
    z[2,3,0]  R912      -6.3228809833526611e-01
    z[2,3,0]  R913      8.7768651545047760e-02
    z[2,3,0]  R914      2.1279385685920715e-01
    z[2,3,0]  R915      0.648888111114502
    z[2,3,0]  R916      3.8861066102981567e-01
    z[2,3,0]  R917      5.9374624490737915e-01
    z[2,3,0]  R918      1.5713982284069061e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R850      -1
    z[2,3,1]  R851      1
    z[2,3,1]  R862      -4.8973181843757629e-01
    z[2,3,1]  R863      9.2658340930938721e-01
    z[2,3,1]  R864      2.1738986670970917e-01
    z[2,3,1]  R865      8.1173330545425415e-01
    z[2,3,1]  R866      7.5879991054534912e-01
    z[2,3,1]  R867      0.610985279083252
    z[2,3,1]  R868      -3.8118717074394226e-01
    z[2,3,1]  R869      -1.9773192703723907e-01
    z[2,3,1]  R870      -2.6757544279098511e-01
    z[2,3,1]  R871      -0.325523316860199
    z[2,3,1]  R872      -6.6528119146823883e-02
    z[2,3,1]  R873      -8.0690783262252808e-01
    z[2,3,1]  R874      -1.4767971634864807e-01
    z[2,3,1]  R875      -3.5519865155220032e-01
    z[2,3,1]  R876      -5.5346727371215820e-01
    z[2,3,1]  R877      -5.6559547781944275e-02
    z[2,3,1]  R878      2.9945811629295349e-01
    z[2,3,1]  R879      2.3160910606384277e-01
    z[2,3,1]  R880      3.8794466853141785e-01
    z[2,3,1]  R881      6.9825100898742676e-01
    z[2,3,1]  R882      1.3087838888168335e-01
    z[2,3,1]  R883      -6.2799239158630371e-01
    z[2,3,1]  R884      8.7105512619018555e-02
    z[2,3,1]  R885      -8.4105068445205688e-01
    z[2,3,1]  R886      -6.2222665548324585e-01
    z[2,3,1]  R887      -4.5931825041770935e-01
    z[2,3,1]  R888      -2.9663187265396118e-01
    z[2,3,1]  R889      -4.0094795823097229e-01
    z[2,3,1]  R890      -2.6050320267677307e-01
    z[2,3,1]  R891      -2.4094755947589874e-01
    z[2,3,1]  R892      -4.4638451933860779e-01
    z[2,3,1]  R893      -2.0303604006767273e-01
    z[2,3,1]  R894      -1.8426011502742767e-01
    z[2,3,1]  R895      -0.243020698428154
    z[2,3,1]  R896      1.4757326245307922e-01
    z[2,3,1]  R897      4.0068429708480835e-01
    z[2,3,1]  R898      -3.7591388821601868e-01
    z[2,3,1]  R899      -4.4722664356231689e-01
    z[2,3,1]  R900      -5.9642869234085083e-01
    z[2,3,1]  R901      -6.8538486957550049e-01
    z[2,3,1]  R902      -0.549904465675354
    z[2,3,1]  R903      -6.5866059064865112e-01
    z[2,3,1]  R904      -4.8701807856559753e-01
    z[2,3,1]  R905      2.3313693702220917e-01
    z[2,3,1]  R906      6.3290292024612427e-01
    z[2,3,1]  R907      6.4746099710464478e-01
    z[2,3,1]  R908      5.0144141912460327e-01
    z[2,3,1]  R909      0.707349956035614
    z[2,3,1]  R910      -7.4920213222503662e-01
    z[2,3,1]  R911      -3.9429777860641479e-01
    z[2,3,1]  R912      -6.5100133419036865e-01
    z[2,3,1]  R913      4.4579941034317017e-01
    z[2,3,1]  R914      -1.8676178157329559e-01
    z[2,3,1]  R915      1.2372772395610809e-01
    z[2,3,1]  R916      -1.3339424133300781e-01
    z[2,3,1]  R917      6.0084593296051025e-01
    z[2,3,1]  R918      6.8531692028045654e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R852      -1
    z[2,3,2]  R853      1
    z[2,3,2]  R862      1.5313675999641418e-01
    z[2,3,2]  R863      2.0283766090869904e-01
    z[2,3,2]  R864      5.8625018596649170e-01
    z[2,3,2]  R865      7.3909483850002289e-02
    z[2,3,2]  R866      1.4069521427154541e-01
    z[2,3,2]  R867      3.3644123468548059e-03
    z[2,3,2]  R868      -3.4357404708862305e-01
    z[2,3,2]  R869      0.349021315574646
    z[2,3,2]  R870      -1.1797043681144714e-01
    z[2,3,2]  R871      0.51185142993927
    z[2,3,2]  R872      -5.3328055143356323e-01
    z[2,3,2]  R873      -1.5672446787357330e-01
    z[2,3,2]  R874      -4.3450468778610229e-01
    z[2,3,2]  R875      7.5958654284477234e-02
    z[2,3,2]  R876      -1.2493695318698883e-01
    z[2,3,2]  R877      -5.4223573207855225e-01
    z[2,3,2]  R878      -3.6449797451496124e-02
    z[2,3,2]  R879      -9.9842166528105736e-03
    z[2,3,2]  R880      -4.7936826944351196e-01
    z[2,3,2]  R881      -2.4158288538455963e-01
    z[2,3,2]  R882      -4.8367372155189514e-01
    z[2,3,2]  R883      -5.5697569623589516e-03
    z[2,3,2]  R884      -5.0500237941741943e-01
    z[2,3,2]  R885      4.2073997855186462e-01
    z[2,3,2]  R886      3.9887708425521851e-01
    z[2,3,2]  R887      5.9302794933319092e-01
    z[2,3,2]  R888      -2.3319745063781738e-01
    z[2,3,2]  R889      5.2027142047882080e-01
    z[2,3,2]  R890      5.3643748164176941e-02
    z[2,3,2]  R891      3.8907316327095032e-01
    z[2,3,2]  R892      1.7657142877578735e-01
    z[2,3,2]  R893      1.2870785593986511e-01
    z[2,3,2]  R894      -2.1501055359840393e-01
    z[2,3,2]  R895      -1.6630896925926208e-01
    z[2,3,2]  R896      2.1442010998725891e-01
    z[2,3,2]  R897      -1.0274353623390198e-01
    z[2,3,2]  R898      1.2185801565647125e-01
    z[2,3,2]  R899      0.476277619600296
    z[2,3,2]  R900      -4.4175478816032410e-01
    z[2,3,2]  R901      2.8016316890716553e-01
    z[2,3,2]  R902      -6.3626688718795776e-01
    z[2,3,2]  R903      -2.1197710931301117e-01
    z[2,3,2]  R904      -3.2583191990852356e-01
    z[2,3,2]  R905      -1.7851114273071289e-01
    z[2,3,2]  R906      -1.9553038477897644e-01
    z[2,3,2]  R907      3.9250016212463379e-01
    z[2,3,2]  R908      -1.1277581006288528e-01
    z[2,3,2]  R909      -4.5033130049705505e-01
    z[2,3,2]  R910      1.2961444258689880e-01
    z[2,3,2]  R911      3.1226860359311104e-02
    z[2,3,2]  R912      1.1279319971799850e-01
    z[2,3,2]  R913      4.8092040419578552e-01
    z[2,3,2]  R914      -6.0414797067642212e-01
    z[2,3,2]  R915      -1.0588270425796509e-01
    z[2,3,2]  R916      -4.0186974406242371e-01
    z[2,3,2]  R917      -8.4704078733921051e-02
    z[2,3,2]  R918      3.1920984387397766e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R854      -1
    z[2,3,3]  R855      1
    z[2,3,3]  R862      8.0298662185668945e-01
    z[2,3,3]  R863      -1.2950956821441650e-01
    z[2,3,3]  R864      -7.1744054555892944e-02
    z[2,3,3]  R865      5.4765632376074791e-03
    z[2,3,3]  R866      -3.2654855400323868e-02
    z[2,3,3]  R867      -9.6853971481323242e-02
    z[2,3,3]  R868      2.7009862661361694e-01
    z[2,3,3]  R869      1.7252631485462189e-02
    z[2,3,3]  R870      -8.3704240387305617e-04
    z[2,3,3]  R871      -8.2604862749576569e-02
    z[2,3,3]  R872      1.1904376745223999e-01
    z[2,3,3]  R873      -1.2835939228534698e-01
    z[2,3,3]  R874      5.3151566535234451e-02
    z[2,3,3]  R875      -1.4652781188488007e-01
    z[2,3,3]  R876      -1.6926433145999908e-01
    z[2,3,3]  R877      1.9480009377002716e-01
    z[2,3,3]  R878      4.4538501650094986e-02
    z[2,3,3]  R879      -5.5179011542350054e-04
    z[2,3,3]  R880      -6.7013156414031982e-01
    z[2,3,3]  R881      1.4224714040756226e-01
    z[2,3,3]  R882      -4.2256537079811096e-01
    z[2,3,3]  R883      -1.1562841385602951e-01
    z[2,3,3]  R884      -3.7999153137207031e-01
    z[2,3,3]  R885      -2.7202051877975464e-01
    z[2,3,3]  R886      -2.8553810715675354e-01
    z[2,3,3]  R887      -2.1384359896183014e-01
    z[2,3,3]  R888      5.2082948386669159e-02
    z[2,3,3]  R889      -3.3588975667953491e-01
    z[2,3,3]  R890      4.3109700083732605e-01
    z[2,3,3]  R891      6.4160728454589844e-01
    z[2,3,3]  R892      2.4229782819747925e-01
    z[2,3,3]  R893      5.0953966379165649e-01
    z[2,3,3]  R894      4.9407321214675903e-01
    z[2,3,3]  R895      3.6014896631240845e-01
    z[2,3,3]  R896      -1.5400671958923340e-01
    z[2,3,3]  R897      -2.0644627511501312e-02
    z[2,3,3]  R898      7.1278929710388184e-01
    z[2,3,3]  R899      5.4631787538528442e-01
    z[2,3,3]  R900      1.4938473701477051e-01
    z[2,3,3]  R901      -4.2482399940490723e-01
    z[2,3,3]  R902      -0.322973370552063
    z[2,3,3]  R903      -5.8784484863281250e-01
    z[2,3,3]  R904      -0.518854558467865
    z[2,3,3]  R905      -7.3962485790252686e-01
    z[2,3,3]  R906      -1.8000417947769165e-01
    z[2,3,3]  R907      1.7879299819469452e-01
    z[2,3,3]  R908      4.8344683647155762e-01
    z[2,3,3]  R909      1.3597738742828369e-01
    z[2,3,3]  R910      8.8223300874233246e-02
    z[2,3,3]  R911      7.8663372993469238e-01
    z[2,3,3]  R912      -1.1369927227497101e-01
    z[2,3,3]  R913      -4.2779183387756348e-01
    z[2,3,3]  R914      1.4524123072624207e-01
    z[2,3,3]  R915      -6.0591280460357666e-01
    z[2,3,3]  R916      3.6464402079582214e-01
    z[2,3,3]  R917      4.4875079393386841e-01
    z[2,3,3]  R918      5.4512494802474976e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R856      -1
    z[2,3,4]  R857      1
    z[2,3,4]  R862      -1.5403665602207184e-01
    z[2,3,4]  R863      2.1440730988979340e-01
    z[2,3,4]  R864      -2.3786747455596924e-01
    z[2,3,4]  R865      -0.0471666194498539
    z[2,3,4]  R866      -3.3482363820075989e-01
    z[2,3,4]  R867      -5.9827786684036255e-01
    z[2,3,4]  R868      -6.7842954397201538e-01
    z[2,3,4]  R869      -8.4002345800399780e-01
    z[2,3,4]  R870      8.3586469292640686e-02
    z[2,3,4]  R871      -1.8240779638290405e-01
    z[2,3,4]  R872      3.0084878206253052e-01
    z[2,3,4]  R873      -2.7551990002393723e-02
    z[2,3,4]  R874      1.6298310458660126e-01
    z[2,3,4]  R875      2.2394415736198425e-01
    z[2,3,4]  R876      0.522490918636322
    z[2,3,4]  R877      -2.9241707921028137e-01
    z[2,3,4]  R878      1.4526424929499626e-02
    z[2,3,4]  R879      1.0862758755683899e-01
    z[2,3,4]  R880      -1.0530197620391846e-01
    z[2,3,4]  R881      -3.4162408113479614e-01
    z[2,3,4]  R882      -1.2223538011312485e-01
    z[2,3,4]  R883      -8.8653936982154846e-02
    z[2,3,4]  R884      4.6802088618278503e-01
    z[2,3,4]  R885      -7.8435122966766357e-02
    z[2,3,4]  R886      2.5598713755607605e-01
    z[2,3,4]  R887      -3.1511259078979492e-01
    z[2,3,4]  R888      -1.4939607679843903e-01
    z[2,3,4]  R889      6.0841619968414307e-01
    z[2,3,4]  R890      7.7099494636058807e-02
    z[2,3,4]  R891      1.4336153864860535e-01
    z[2,3,4]  R892      -2.2197237610816956e-01
    z[2,3,4]  R893      -2.4536329507827759e-01
    z[2,3,4]  R894      -4.9715104699134827e-01
    z[2,3,4]  R895      -4.2462694644927979e-01
    z[2,3,4]  R896      -1.4687924087047577e-01
    z[2,3,4]  R897      -2.6961660385131836e-01
    z[2,3,4]  R898      -3.5215571522712708e-01
    z[2,3,4]  R899      0.305738627910614
    z[2,3,4]  R900      3.1410478055477142e-02
    z[2,3,4]  R901      3.0677413940429688e-01
    z[2,3,4]  R902      3.3142006397247314e-01
    z[2,3,4]  R903      3.7239551544189453e-01
    z[2,3,4]  R904      -1.5976226329803467e-01
    z[2,3,4]  R905      3.6165577173233032e-01
    z[2,3,4]  R906      3.3996206521987915e-01
    z[2,3,4]  R907      3.0345523357391357e-01
    z[2,3,4]  R908      -1.5989659726619720e-01
    z[2,3,4]  R909      -3.4453293681144714e-01
    z[2,3,4]  R910      -1.4251527190208435e-01
    z[2,3,4]  R911      -2.1376316249370575e-01
    z[2,3,4]  R912      -3.2532259821891785e-01
    z[2,3,4]  R913      0.474231094121933
    z[2,3,4]  R914      -4.9816173315048218e-01
    z[2,3,4]  R915      3.1092768907546997e-01
    z[2,3,4]  R916      5.5697995424270630e-01
    z[2,3,4]  R917      2.6597961783409119e-01
    z[2,3,4]  R918      3.0822345614433289e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R858      -1
    z[2,3,5]  R859      1
    z[2,3,5]  R862      -1.4355553314089775e-02
    z[2,3,5]  R863      -1.8618127703666687e-01
    z[2,3,5]  R864      -1.6590122831985354e-03
    z[2,3,5]  R865      5.2180910110473633e-01
    z[2,3,5]  R866      2.1531239151954651e-01
    z[2,3,5]  R867      0.0934302806854248
    z[2,3,5]  R868      3.4997311234474182e-01
    z[2,3,5]  R869      1.8963402509689331e-01
    z[2,3,5]  R870      5.0546127557754517e-01
    z[2,3,5]  R871      -3.7152278423309326e-01
    z[2,3,5]  R872      -6.6386508941650391e-01
    z[2,3,5]  R873      -4.1977947950363159e-01
    z[2,3,5]  R874      -4.7290486097335815e-01
    z[2,3,5]  R875      -3.5780504345893860e-01
    z[2,3,5]  R876      2.1147643029689789e-01
    z[2,3,5]  R877      -5.1907891035079956e-01
    z[2,3,5]  R878      -1.1003150045871735e-01
    z[2,3,5]  R879      -3.5787490010261536e-01
    z[2,3,5]  R880      -1.2733571231365204e-01
    z[2,3,5]  R881      -3.5000103712081909e-01
    z[2,3,5]  R882      -2.0416064560413361e-01
    z[2,3,5]  R883      -5.4127085208892822e-01
    z[2,3,5]  R884      -3.6222544312477112e-01
    z[2,3,5]  R885      1.6663667559623718e-01
    z[2,3,5]  R886      -7.9163469374179840e-02
    z[2,3,5]  R887      -7.1162022650241852e-02
    z[2,3,5]  R888      1.6889117658138275e-01
    z[2,3,5]  R889      1.0090171545743942e-01
    z[2,3,5]  R890      -2.2628612816333771e-01
    z[2,3,5]  R891      2.8383467346429825e-02
    z[2,3,5]  R892      2.7258491516113281e-01
    z[2,3,5]  R893      1.6982145607471466e-01
    z[2,3,5]  R894      3.2328939437866211e-01
    z[2,3,5]  R895      1.5535542368888855e-01
    z[2,3,5]  R896      8.0995744466781616e-01
    z[2,3,5]  R897      7.9695820808410645e-01
    z[2,3,5]  R898      -2.2832190617918968e-02
    z[2,3,5]  R899      2.9667469859123230e-01
    z[2,3,5]  R900      -3.6605009436607361e-01
    z[2,3,5]  R901      -2.8311079740524292e-01
    z[2,3,5]  R902      7.1407124400138855e-02
    z[2,3,5]  R903      -1.0312648862600327e-01
    z[2,3,5]  R904      -5.3364062309265137e-01
    z[2,3,5]  R905      -1.2207627296447754e-01
    z[2,3,5]  R906      -2.5423637032508850e-01
    z[2,3,5]  R907      -2.7033188939094543e-01
    z[2,3,5]  R908      -2.3554079234600067e-01
    z[2,3,5]  R909      -3.5050097107887268e-01
    z[2,3,5]  R910      5.8041650056838989e-01
    z[2,3,5]  R911      3.7163376808166504e-01
    z[2,3,5]  R912      -1.5019933879375458e-01
    z[2,3,5]  R913      3.3966881036758423e-01
    z[2,3,5]  R914      -6.6731266677379608e-02
    z[2,3,5]  R915      2.8604209423065186e-01
    z[2,3,5]  R916      3.7263652682304382e-01
    z[2,3,5]  R917      7.8697368502616882e-02
    z[2,3,5]  R918      1.0498242825269699e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R860      -1
    z[2,3,6]  R861      1
    z[2,3,6]  R862      -3.4419938921928406e-02
    z[2,3,6]  R863      4.5443259179592133e-02
    z[2,3,6]  R864      1.9602021202445030e-03
    z[2,3,6]  R865      -2.1629691123962402e-01
    z[2,3,6]  R866      4.1626194119453430e-01
    z[2,3,6]  R867      -4.6719488501548767e-01
    z[2,3,6]  R868      3.0087681487202644e-02
    z[2,3,6]  R869      -1.3081052899360657e-01
    z[2,3,6]  R870      -2.1227811276912689e-01
    z[2,3,6]  R871      6.6942739486694336e-01
    z[2,3,6]  R872      8.2351088523864746e-02
    z[2,3,6]  R873      -0.343763530254364
    z[2,3,6]  R874      -7.3109096288681030e-01
    z[2,3,6]  R875      -8.1681215763092041e-01
    z[2,3,6]  R876      2.8921341896057129e-01
    z[2,3,6]  R877      4.0778901427984238e-02
    z[2,3,6]  R878      -1.7562095820903778e-01
    z[2,3,6]  R879      3.0883124098181725e-02
    z[2,3,6]  R880      -6.7563906311988831e-02
    z[2,3,6]  R881      -3.0874508619308472e-01
    z[2,3,6]  R882      5.3274726867675781e-01
    z[2,3,6]  R883      1.5110582113265991e-01
    z[2,3,6]  R884      2.1116735041141510e-01
    z[2,3,6]  R885      1.7141979187726974e-02
    z[2,3,6]  R886      5.1948052644729614e-01
    z[2,3,6]  R887      0.534010648727417
    z[2,3,6]  R888      7.9202461242675781e-01
    z[2,3,6]  R889      -2.4263311922550201e-01
    z[2,3,6]  R890      -7.3401778936386108e-01
    z[2,3,6]  R891      2.3921218235045671e-03
    z[2,3,6]  R892      -7.6444578170776367e-01
    z[2,3,6]  R893      5.1944744586944580e-01
    z[2,3,6]  R894      3.3187377452850342e-01
    z[2,3,6]  R895      -5.5719721317291260e-01
    z[2,3,6]  R896      -4.6325522661209106e-01
    z[2,3,6]  R897      3.1263187527656555e-01
    z[2,3,6]  R898      -1.7332918941974640e-01
    z[2,3,6]  R899      -1.6482527554035187e-01
    z[2,3,6]  R900      3.8398674130439758e-01
    z[2,3,6]  R901      2.4408011138439178e-01
    z[2,3,6]  R902      1.8971693515777588e-01
    z[2,3,6]  R903      1.6159202158451080e-01
    z[2,3,6]  R904      0.0920364037156105
    z[2,3,6]  R905      1.8101497553288937e-03
    z[2,3,6]  R906      -2.6887786388397217e-01
    z[2,3,6]  R907      2.7434840798377991e-01
    z[2,3,6]  R908      -3.2288864254951477e-01
    z[2,3,6]  R909      1.9168620929121971e-02
    z[2,3,6]  R910      2.2632595896720886e-01
    z[2,3,6]  R911      1.8007853627204895e-01
    z[2,3,6]  R912      -1.4954796433448792e-01
    z[2,3,6]  R913      1.9748227298259735e-01
    z[2,3,6]  R914      -5.3021764755249023e-01
    z[2,3,6]  R915      -8.2450456917285919e-02
    z[2,3,6]  R916      -0.296037882566452
    z[2,3,6]  R917      -3.0968451872467995e-02
    z[2,3,6]  R918      -2.3845938965678215e-02
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R919      -1
    z[3,2,0]  R920      1
    z[3,2,0]  R933      -3.8403651118278503e-01
    z[3,2,0]  R934      -5.9794867038726807e-01
    z[3,2,0]  R935      -5.3884852677583694e-02
    z[3,2,0]  R936      -5.6895685195922852e-01
    z[3,2,0]  R937      -4.6248784661293030e-01
    z[3,2,0]  R938      -5.1832705736160278e-01
    z[3,2,0]  R939      0.127742201089859
    z[3,2,0]  R940      1.5131257474422455e-01
    z[3,2,0]  R941      -4.2566746473312378e-01
    z[3,2,0]  R942      2.5695389509201050e-01
    z[3,2,0]  R943      3.7997964024543762e-01
    z[3,2,0]  R944      -1.9350335001945496e-01
    z[3,2,0]  R945      -1.9371852278709412e-01
    z[3,2,0]  R946      -1.5649942681193352e-02
    z[3,2,0]  R947      -2.6204961538314819e-01
    z[3,2,0]  R948      4.7014385461807251e-01
    z[3,2,0]  R949      5.2563732862472534e-01
    z[3,2,0]  R950      3.9286059141159058e-01
    z[3,2,0]  R951      5.6286227703094482e-01
    z[3,2,0]  R952      -1.9090999662876129e-01
    z[3,2,0]  R953      7.5469031929969788e-02
    z[3,2,0]  R954      9.2340342700481415e-02
    z[3,2,0]  R955      -6.3228809833526611e-01
    z[3,2,0]  R956      8.7768651545047760e-02
    z[3,2,0]  R957      2.1279385685920715e-01
    z[3,2,0]  R958      0.648888111114502
    z[3,2,0]  R959      3.8861066102981567e-01
    z[3,2,0]  R960      5.9374624490737915e-01
    z[3,2,0]  R961      1.5713982284069061e-01
    z[3,2,0]  R962      2.5846919417381287e-01
    z[3,2,0]  R963      2.8779031708836555e-02
    z[3,2,0]  R964      -7.3980921506881714e-01
    z[3,2,0]  R965      -1.1959360539913177e-01
    z[3,2,0]  R966      -2.6762092113494873e-01
    z[3,2,0]  R967      -1.7991174757480621e-01
    z[3,2,0]  R968      -2.8292530775070190e-01
    z[3,2,0]  R969      -2.8297838568687439e-01
    z[3,2,0]  R970      -7.7906721830368042e-01
    z[3,2,0]  R971      -0.076054647564888
    z[3,2,0]  R972      -3.9875549077987671e-01
    z[3,2,0]  R973      1.1275541782379150e-01
    z[3,2,0]  R974      -4.3298348784446716e-02
    z[3,2,0]  R975      -3.5161290317773819e-02
    z[3,2,0]  R976      4.9804711341857910e-01
    z[3,2,0]  R977      -5.5517643690109253e-01
    z[3,2,0]  R978      9.2943632602691650e-01
    z[3,2,0]  R979      8.9745700359344482e-01
    z[3,2,0]  R980      3.7250635027885437e-01
    z[3,2,0]  R981      -3.1514719128608704e-01
    z[3,2,0]  R982      -4.7950640320777893e-01
    z[3,2,0]  R983      -5.1822578907012939e-01
    z[3,2,0]  R984      -0.445139616727829
    z[3,2,0]  R985      -8.6039073765277863e-02
    z[3,2,0]  R986      -1.7476458847522736e-01
    z[3,2,0]  R987      4.5696116983890533e-02
    z[3,2,0]  R988      -4.2043957114219666e-01
    z[3,2,0]  R989      -1.2850791215896606e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R921      -1
    z[3,2,1]  R922      1
    z[3,2,1]  R933      -2.6050320267677307e-01
    z[3,2,1]  R934      -2.4094755947589874e-01
    z[3,2,1]  R935      -4.4638451933860779e-01
    z[3,2,1]  R936      -2.0303604006767273e-01
    z[3,2,1]  R937      -1.8426011502742767e-01
    z[3,2,1]  R938      -0.243020698428154
    z[3,2,1]  R939      1.4757326245307922e-01
    z[3,2,1]  R940      4.0068429708480835e-01
    z[3,2,1]  R941      -3.7591388821601868e-01
    z[3,2,1]  R942      -4.4722664356231689e-01
    z[3,2,1]  R943      -5.9642869234085083e-01
    z[3,2,1]  R944      -6.8538486957550049e-01
    z[3,2,1]  R945      -0.549904465675354
    z[3,2,1]  R946      -6.5866059064865112e-01
    z[3,2,1]  R947      -4.8701807856559753e-01
    z[3,2,1]  R948      2.3313693702220917e-01
    z[3,2,1]  R949      6.3290292024612427e-01
    z[3,2,1]  R950      6.4746099710464478e-01
    z[3,2,1]  R951      5.0144141912460327e-01
    z[3,2,1]  R952      0.707349956035614
    z[3,2,1]  R953      -7.4920213222503662e-01
    z[3,2,1]  R954      -3.9429777860641479e-01
    z[3,2,1]  R955      -6.5100133419036865e-01
    z[3,2,1]  R956      4.4579941034317017e-01
    z[3,2,1]  R957      -1.8676178157329559e-01
    z[3,2,1]  R958      1.2372772395610809e-01
    z[3,2,1]  R959      -1.3339424133300781e-01
    z[3,2,1]  R960      6.0084593296051025e-01
    z[3,2,1]  R961      6.8531692028045654e-01
    z[3,2,1]  R962      -4.8973181843757629e-01
    z[3,2,1]  R963      9.2658340930938721e-01
    z[3,2,1]  R964      2.1738986670970917e-01
    z[3,2,1]  R965      8.1173330545425415e-01
    z[3,2,1]  R966      7.5879991054534912e-01
    z[3,2,1]  R967      0.610985279083252
    z[3,2,1]  R968      -3.8118717074394226e-01
    z[3,2,1]  R969      -1.9773192703723907e-01
    z[3,2,1]  R970      -2.6757544279098511e-01
    z[3,2,1]  R971      -0.325523316860199
    z[3,2,1]  R972      -6.6528119146823883e-02
    z[3,2,1]  R973      -8.0690783262252808e-01
    z[3,2,1]  R974      -1.4767971634864807e-01
    z[3,2,1]  R975      -3.5519865155220032e-01
    z[3,2,1]  R976      -5.5346727371215820e-01
    z[3,2,1]  R977      -5.6559547781944275e-02
    z[3,2,1]  R978      2.9945811629295349e-01
    z[3,2,1]  R979      2.3160910606384277e-01
    z[3,2,1]  R980      3.8794466853141785e-01
    z[3,2,1]  R981      6.9825100898742676e-01
    z[3,2,1]  R982      1.3087838888168335e-01
    z[3,2,1]  R983      -6.2799239158630371e-01
    z[3,2,1]  R984      8.7105512619018555e-02
    z[3,2,1]  R985      -8.4105068445205688e-01
    z[3,2,1]  R986      -6.2222665548324585e-01
    z[3,2,1]  R987      -4.5931825041770935e-01
    z[3,2,1]  R988      -2.9663187265396118e-01
    z[3,2,1]  R989      -4.0094795823097229e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R923      -1
    z[3,2,2]  R924      1
    z[3,2,2]  R933      5.3643748164176941e-02
    z[3,2,2]  R934      3.8907316327095032e-01
    z[3,2,2]  R935      1.7657142877578735e-01
    z[3,2,2]  R936      1.2870785593986511e-01
    z[3,2,2]  R937      -2.1501055359840393e-01
    z[3,2,2]  R938      -1.6630896925926208e-01
    z[3,2,2]  R939      2.1442010998725891e-01
    z[3,2,2]  R940      -1.0274353623390198e-01
    z[3,2,2]  R941      1.2185801565647125e-01
    z[3,2,2]  R942      0.476277619600296
    z[3,2,2]  R943      -4.4175478816032410e-01
    z[3,2,2]  R944      2.8016316890716553e-01
    z[3,2,2]  R945      -6.3626688718795776e-01
    z[3,2,2]  R946      -2.1197710931301117e-01
    z[3,2,2]  R947      -3.2583191990852356e-01
    z[3,2,2]  R948      -1.7851114273071289e-01
    z[3,2,2]  R949      -1.9553038477897644e-01
    z[3,2,2]  R950      3.9250016212463379e-01
    z[3,2,2]  R951      -1.1277581006288528e-01
    z[3,2,2]  R952      -4.5033130049705505e-01
    z[3,2,2]  R953      1.2961444258689880e-01
    z[3,2,2]  R954      3.1226860359311104e-02
    z[3,2,2]  R955      1.1279319971799850e-01
    z[3,2,2]  R956      4.8092040419578552e-01
    z[3,2,2]  R957      -6.0414797067642212e-01
    z[3,2,2]  R958      -1.0588270425796509e-01
    z[3,2,2]  R959      -4.0186974406242371e-01
    z[3,2,2]  R960      -8.4704078733921051e-02
    z[3,2,2]  R961      3.1920984387397766e-01
    z[3,2,2]  R962      1.5313675999641418e-01
    z[3,2,2]  R963      2.0283766090869904e-01
    z[3,2,2]  R964      5.8625018596649170e-01
    z[3,2,2]  R965      7.3909483850002289e-02
    z[3,2,2]  R966      1.4069521427154541e-01
    z[3,2,2]  R967      3.3644123468548059e-03
    z[3,2,2]  R968      -3.4357404708862305e-01
    z[3,2,2]  R969      0.349021315574646
    z[3,2,2]  R970      -1.1797043681144714e-01
    z[3,2,2]  R971      0.51185142993927
    z[3,2,2]  R972      -5.3328055143356323e-01
    z[3,2,2]  R973      -1.5672446787357330e-01
    z[3,2,2]  R974      -4.3450468778610229e-01
    z[3,2,2]  R975      7.5958654284477234e-02
    z[3,2,2]  R976      -1.2493695318698883e-01
    z[3,2,2]  R977      -5.4223573207855225e-01
    z[3,2,2]  R978      -3.6449797451496124e-02
    z[3,2,2]  R979      -9.9842166528105736e-03
    z[3,2,2]  R980      -4.7936826944351196e-01
    z[3,2,2]  R981      -2.4158288538455963e-01
    z[3,2,2]  R982      -4.8367372155189514e-01
    z[3,2,2]  R983      -5.5697569623589516e-03
    z[3,2,2]  R984      -5.0500237941741943e-01
    z[3,2,2]  R985      4.2073997855186462e-01
    z[3,2,2]  R986      3.9887708425521851e-01
    z[3,2,2]  R987      5.9302794933319092e-01
    z[3,2,2]  R988      -2.3319745063781738e-01
    z[3,2,2]  R989      5.2027142047882080e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R925      -1
    z[3,2,3]  R926      1
    z[3,2,3]  R933      4.3109700083732605e-01
    z[3,2,3]  R934      6.4160728454589844e-01
    z[3,2,3]  R935      2.4229782819747925e-01
    z[3,2,3]  R936      5.0953966379165649e-01
    z[3,2,3]  R937      4.9407321214675903e-01
    z[3,2,3]  R938      3.6014896631240845e-01
    z[3,2,3]  R939      -1.5400671958923340e-01
    z[3,2,3]  R940      -2.0644627511501312e-02
    z[3,2,3]  R941      7.1278929710388184e-01
    z[3,2,3]  R942      5.4631787538528442e-01
    z[3,2,3]  R943      1.4938473701477051e-01
    z[3,2,3]  R944      -4.2482399940490723e-01
    z[3,2,3]  R945      -0.322973370552063
    z[3,2,3]  R946      -5.8784484863281250e-01
    z[3,2,3]  R947      -0.518854558467865
    z[3,2,3]  R948      -7.3962485790252686e-01
    z[3,2,3]  R949      -1.8000417947769165e-01
    z[3,2,3]  R950      1.7879299819469452e-01
    z[3,2,3]  R951      4.8344683647155762e-01
    z[3,2,3]  R952      1.3597738742828369e-01
    z[3,2,3]  R953      8.8223300874233246e-02
    z[3,2,3]  R954      7.8663372993469238e-01
    z[3,2,3]  R955      -1.1369927227497101e-01
    z[3,2,3]  R956      -4.2779183387756348e-01
    z[3,2,3]  R957      1.4524123072624207e-01
    z[3,2,3]  R958      -6.0591280460357666e-01
    z[3,2,3]  R959      3.6464402079582214e-01
    z[3,2,3]  R960      4.4875079393386841e-01
    z[3,2,3]  R961      5.4512494802474976e-01
    z[3,2,3]  R962      8.0298662185668945e-01
    z[3,2,3]  R963      -1.2950956821441650e-01
    z[3,2,3]  R964      -7.1744054555892944e-02
    z[3,2,3]  R965      5.4765632376074791e-03
    z[3,2,3]  R966      -3.2654855400323868e-02
    z[3,2,3]  R967      -9.6853971481323242e-02
    z[3,2,3]  R968      2.7009862661361694e-01
    z[3,2,3]  R969      1.7252631485462189e-02
    z[3,2,3]  R970      -8.3704240387305617e-04
    z[3,2,3]  R971      -8.2604862749576569e-02
    z[3,2,3]  R972      1.1904376745223999e-01
    z[3,2,3]  R973      -1.2835939228534698e-01
    z[3,2,3]  R974      5.3151566535234451e-02
    z[3,2,3]  R975      -1.4652781188488007e-01
    z[3,2,3]  R976      -1.6926433145999908e-01
    z[3,2,3]  R977      1.9480009377002716e-01
    z[3,2,3]  R978      4.4538501650094986e-02
    z[3,2,3]  R979      -5.5179011542350054e-04
    z[3,2,3]  R980      -6.7013156414031982e-01
    z[3,2,3]  R981      1.4224714040756226e-01
    z[3,2,3]  R982      -4.2256537079811096e-01
    z[3,2,3]  R983      -1.1562841385602951e-01
    z[3,2,3]  R984      -3.7999153137207031e-01
    z[3,2,3]  R985      -2.7202051877975464e-01
    z[3,2,3]  R986      -2.8553810715675354e-01
    z[3,2,3]  R987      -2.1384359896183014e-01
    z[3,2,3]  R988      5.2082948386669159e-02
    z[3,2,3]  R989      -3.3588975667953491e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R927      -1
    z[3,2,4]  R928      1
    z[3,2,4]  R933      7.7099494636058807e-02
    z[3,2,4]  R934      1.4336153864860535e-01
    z[3,2,4]  R935      -2.2197237610816956e-01
    z[3,2,4]  R936      -2.4536329507827759e-01
    z[3,2,4]  R937      -4.9715104699134827e-01
    z[3,2,4]  R938      -4.2462694644927979e-01
    z[3,2,4]  R939      -1.4687924087047577e-01
    z[3,2,4]  R940      -2.6961660385131836e-01
    z[3,2,4]  R941      -3.5215571522712708e-01
    z[3,2,4]  R942      0.305738627910614
    z[3,2,4]  R943      3.1410478055477142e-02
    z[3,2,4]  R944      3.0677413940429688e-01
    z[3,2,4]  R945      3.3142006397247314e-01
    z[3,2,4]  R946      3.7239551544189453e-01
    z[3,2,4]  R947      -1.5976226329803467e-01
    z[3,2,4]  R948      3.6165577173233032e-01
    z[3,2,4]  R949      3.3996206521987915e-01
    z[3,2,4]  R950      3.0345523357391357e-01
    z[3,2,4]  R951      -1.5989659726619720e-01
    z[3,2,4]  R952      -3.4453293681144714e-01
    z[3,2,4]  R953      -1.4251527190208435e-01
    z[3,2,4]  R954      -2.1376316249370575e-01
    z[3,2,4]  R955      -3.2532259821891785e-01
    z[3,2,4]  R956      0.474231094121933
    z[3,2,4]  R957      -4.9816173315048218e-01
    z[3,2,4]  R958      3.1092768907546997e-01
    z[3,2,4]  R959      5.5697995424270630e-01
    z[3,2,4]  R960      2.6597961783409119e-01
    z[3,2,4]  R961      3.0822345614433289e-01
    z[3,2,4]  R962      -1.5403665602207184e-01
    z[3,2,4]  R963      2.1440730988979340e-01
    z[3,2,4]  R964      -2.3786747455596924e-01
    z[3,2,4]  R965      -0.0471666194498539
    z[3,2,4]  R966      -3.3482363820075989e-01
    z[3,2,4]  R967      -5.9827786684036255e-01
    z[3,2,4]  R968      -6.7842954397201538e-01
    z[3,2,4]  R969      -8.4002345800399780e-01
    z[3,2,4]  R970      8.3586469292640686e-02
    z[3,2,4]  R971      -1.8240779638290405e-01
    z[3,2,4]  R972      3.0084878206253052e-01
    z[3,2,4]  R973      -2.7551990002393723e-02
    z[3,2,4]  R974      1.6298310458660126e-01
    z[3,2,4]  R975      2.2394415736198425e-01
    z[3,2,4]  R976      0.522490918636322
    z[3,2,4]  R977      -2.9241707921028137e-01
    z[3,2,4]  R978      1.4526424929499626e-02
    z[3,2,4]  R979      1.0862758755683899e-01
    z[3,2,4]  R980      -1.0530197620391846e-01
    z[3,2,4]  R981      -3.4162408113479614e-01
    z[3,2,4]  R982      -1.2223538011312485e-01
    z[3,2,4]  R983      -8.8653936982154846e-02
    z[3,2,4]  R984      4.6802088618278503e-01
    z[3,2,4]  R985      -7.8435122966766357e-02
    z[3,2,4]  R986      2.5598713755607605e-01
    z[3,2,4]  R987      -3.1511259078979492e-01
    z[3,2,4]  R988      -1.4939607679843903e-01
    z[3,2,4]  R989      6.0841619968414307e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R929      -1
    z[3,2,5]  R930      1
    z[3,2,5]  R933      -2.2628612816333771e-01
    z[3,2,5]  R934      2.8383467346429825e-02
    z[3,2,5]  R935      2.7258491516113281e-01
    z[3,2,5]  R936      1.6982145607471466e-01
    z[3,2,5]  R937      3.2328939437866211e-01
    z[3,2,5]  R938      1.5535542368888855e-01
    z[3,2,5]  R939      8.0995744466781616e-01
    z[3,2,5]  R940      7.9695820808410645e-01
    z[3,2,5]  R941      -2.2832190617918968e-02
    z[3,2,5]  R942      2.9667469859123230e-01
    z[3,2,5]  R943      -3.6605009436607361e-01
    z[3,2,5]  R944      -2.8311079740524292e-01
    z[3,2,5]  R945      7.1407124400138855e-02
    z[3,2,5]  R946      -1.0312648862600327e-01
    z[3,2,5]  R947      -5.3364062309265137e-01
    z[3,2,5]  R948      -1.2207627296447754e-01
    z[3,2,5]  R949      -2.5423637032508850e-01
    z[3,2,5]  R950      -2.7033188939094543e-01
    z[3,2,5]  R951      -2.3554079234600067e-01
    z[3,2,5]  R952      -3.5050097107887268e-01
    z[3,2,5]  R953      5.8041650056838989e-01
    z[3,2,5]  R954      3.7163376808166504e-01
    z[3,2,5]  R955      -1.5019933879375458e-01
    z[3,2,5]  R956      3.3966881036758423e-01
    z[3,2,5]  R957      -6.6731266677379608e-02
    z[3,2,5]  R958      2.8604209423065186e-01
    z[3,2,5]  R959      3.7263652682304382e-01
    z[3,2,5]  R960      7.8697368502616882e-02
    z[3,2,5]  R961      1.0498242825269699e-01
    z[3,2,5]  R962      -1.4355553314089775e-02
    z[3,2,5]  R963      -1.8618127703666687e-01
    z[3,2,5]  R964      -1.6590122831985354e-03
    z[3,2,5]  R965      5.2180910110473633e-01
    z[3,2,5]  R966      2.1531239151954651e-01
    z[3,2,5]  R967      0.0934302806854248
    z[3,2,5]  R968      3.4997311234474182e-01
    z[3,2,5]  R969      1.8963402509689331e-01
    z[3,2,5]  R970      5.0546127557754517e-01
    z[3,2,5]  R971      -3.7152278423309326e-01
    z[3,2,5]  R972      -6.6386508941650391e-01
    z[3,2,5]  R973      -4.1977947950363159e-01
    z[3,2,5]  R974      -4.7290486097335815e-01
    z[3,2,5]  R975      -3.5780504345893860e-01
    z[3,2,5]  R976      2.1147643029689789e-01
    z[3,2,5]  R977      -5.1907891035079956e-01
    z[3,2,5]  R978      -1.1003150045871735e-01
    z[3,2,5]  R979      -3.5787490010261536e-01
    z[3,2,5]  R980      -1.2733571231365204e-01
    z[3,2,5]  R981      -3.5000103712081909e-01
    z[3,2,5]  R982      -2.0416064560413361e-01
    z[3,2,5]  R983      -5.4127085208892822e-01
    z[3,2,5]  R984      -3.6222544312477112e-01
    z[3,2,5]  R985      1.6663667559623718e-01
    z[3,2,5]  R986      -7.9163469374179840e-02
    z[3,2,5]  R987      -7.1162022650241852e-02
    z[3,2,5]  R988      1.6889117658138275e-01
    z[3,2,5]  R989      1.0090171545743942e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R931      -1
    z[3,2,6]  R932      1
    z[3,2,6]  R933      -7.3401778936386108e-01
    z[3,2,6]  R934      2.3921218235045671e-03
    z[3,2,6]  R935      -7.6444578170776367e-01
    z[3,2,6]  R936      5.1944744586944580e-01
    z[3,2,6]  R937      3.3187377452850342e-01
    z[3,2,6]  R938      -5.5719721317291260e-01
    z[3,2,6]  R939      -4.6325522661209106e-01
    z[3,2,6]  R940      3.1263187527656555e-01
    z[3,2,6]  R941      -1.7332918941974640e-01
    z[3,2,6]  R942      -1.6482527554035187e-01
    z[3,2,6]  R943      3.8398674130439758e-01
    z[3,2,6]  R944      2.4408011138439178e-01
    z[3,2,6]  R945      1.8971693515777588e-01
    z[3,2,6]  R946      1.6159202158451080e-01
    z[3,2,6]  R947      0.0920364037156105
    z[3,2,6]  R948      1.8101497553288937e-03
    z[3,2,6]  R949      -2.6887786388397217e-01
    z[3,2,6]  R950      2.7434840798377991e-01
    z[3,2,6]  R951      -3.2288864254951477e-01
    z[3,2,6]  R952      1.9168620929121971e-02
    z[3,2,6]  R953      2.2632595896720886e-01
    z[3,2,6]  R954      1.8007853627204895e-01
    z[3,2,6]  R955      -1.4954796433448792e-01
    z[3,2,6]  R956      1.9748227298259735e-01
    z[3,2,6]  R957      -5.3021764755249023e-01
    z[3,2,6]  R958      -8.2450456917285919e-02
    z[3,2,6]  R959      -0.296037882566452
    z[3,2,6]  R960      -3.0968451872467995e-02
    z[3,2,6]  R961      -2.3845938965678215e-02
    z[3,2,6]  R962      -3.4419938921928406e-02
    z[3,2,6]  R963      4.5443259179592133e-02
    z[3,2,6]  R964      1.9602021202445030e-03
    z[3,2,6]  R965      -2.1629691123962402e-01
    z[3,2,6]  R966      4.1626194119453430e-01
    z[3,2,6]  R967      -4.6719488501548767e-01
    z[3,2,6]  R968      3.0087681487202644e-02
    z[3,2,6]  R969      -1.3081052899360657e-01
    z[3,2,6]  R970      -2.1227811276912689e-01
    z[3,2,6]  R971      6.6942739486694336e-01
    z[3,2,6]  R972      8.2351088523864746e-02
    z[3,2,6]  R973      -0.343763530254364
    z[3,2,6]  R974      -7.3109096288681030e-01
    z[3,2,6]  R975      -8.1681215763092041e-01
    z[3,2,6]  R976      2.8921341896057129e-01
    z[3,2,6]  R977      4.0778901427984238e-02
    z[3,2,6]  R978      -1.7562095820903778e-01
    z[3,2,6]  R979      3.0883124098181725e-02
    z[3,2,6]  R980      -6.7563906311988831e-02
    z[3,2,6]  R981      -3.0874508619308472e-01
    z[3,2,6]  R982      5.3274726867675781e-01
    z[3,2,6]  R983      1.5110582113265991e-01
    z[3,2,6]  R984      2.1116735041141510e-01
    z[3,2,6]  R985      1.7141979187726974e-02
    z[3,2,6]  R986      5.1948052644729614e-01
    z[3,2,6]  R987      0.534010648727417
    z[3,2,6]  R988      7.9202461242675781e-01
    z[3,2,6]  R989      -2.4263311922550201e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R990      -1
    z[3,4,0]  R991      1
    z[3,4,0]  R1004     -3.8403651118278503e-01
    z[3,4,0]  R1005     -5.9794867038726807e-01
    z[3,4,0]  R1006     -5.3884852677583694e-02
    z[3,4,0]  R1007     -5.6895685195922852e-01
    z[3,4,0]  R1008     -4.6248784661293030e-01
    z[3,4,0]  R1009     -5.1832705736160278e-01
    z[3,4,0]  R1010     0.127742201089859
    z[3,4,0]  R1011     1.5131257474422455e-01
    z[3,4,0]  R1012     -4.2566746473312378e-01
    z[3,4,0]  R1013     2.5695389509201050e-01
    z[3,4,0]  R1014     3.7997964024543762e-01
    z[3,4,0]  R1015     -1.9350335001945496e-01
    z[3,4,0]  R1016     -1.9371852278709412e-01
    z[3,4,0]  R1017     -1.5649942681193352e-02
    z[3,4,0]  R1018     -2.6204961538314819e-01
    z[3,4,0]  R1019     4.7014385461807251e-01
    z[3,4,0]  R1020     5.2563732862472534e-01
    z[3,4,0]  R1021     3.9286059141159058e-01
    z[3,4,0]  R1022     5.6286227703094482e-01
    z[3,4,0]  R1023     -1.9090999662876129e-01
    z[3,4,0]  R1024     7.5469031929969788e-02
    z[3,4,0]  R1025     9.2340342700481415e-02
    z[3,4,0]  R1026     -6.3228809833526611e-01
    z[3,4,0]  R1027     8.7768651545047760e-02
    z[3,4,0]  R1028     2.1279385685920715e-01
    z[3,4,0]  R1029     0.648888111114502
    z[3,4,0]  R1030     3.8861066102981567e-01
    z[3,4,0]  R1031     5.9374624490737915e-01
    z[3,4,0]  R1032     1.5713982284069061e-01
    z[3,4,0]  R1033     -1.5911825001239777e-01
    z[3,4,0]  R1034     -8.3460539579391479e-02
    z[3,4,0]  R1035     -2.9796180129051208e-01
    z[3,4,0]  R1036     -0.10040283203125
    z[3,4,0]  R1037     -1.1207935959100723e-01
    z[3,4,0]  R1038     -5.4521399736404419e-01
    z[3,4,0]  R1039     2.1134330017957836e-04
    z[3,4,0]  R1040     1.8737228214740753e-01
    z[3,4,0]  R1041     -3.7565141916275024e-01
    z[3,4,0]  R1042     -1.3508066534996033e-01
    z[3,4,0]  R1043     7.3875255882740021e-02
    z[3,4,0]  R1044     2.6147386431694031e-01
    z[3,4,0]  R1045     -5.3577542304992676e-01
    z[3,4,0]  R1046     4.5376780629158020e-01
    z[3,4,0]  R1047     6.9701528549194336e-01
    z[3,4,0]  R1048     -2.9086044430732727e-01
    z[3,4,0]  R1049     6.3951069116592407e-01
    z[3,4,0]  R1050     0.605835497379303
    z[3,4,0]  R1051     7.0761835575103760e-01
    z[3,4,0]  R1052     3.8629552721977234e-01
    z[3,4,0]  R1053     3.6952725052833557e-01
    z[3,4,0]  R1054     -9.5478974282741547e-02
    z[3,4,0]  R1055     -5.1158881187438965e-01
    z[3,4,0]  R1056     -4.5761802792549133e-01
    z[3,4,0]  R1057     -4.9912708997726440e-01
    z[3,4,0]  R1058     5.7854449748992920e-01
    z[3,4,0]  R1059     -2.5291821360588074e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R992      -1
    z[3,4,1]  R993      1
    z[3,4,1]  R1004     -2.6050320267677307e-01
    z[3,4,1]  R1005     -2.4094755947589874e-01
    z[3,4,1]  R1006     -4.4638451933860779e-01
    z[3,4,1]  R1007     -2.0303604006767273e-01
    z[3,4,1]  R1008     -1.8426011502742767e-01
    z[3,4,1]  R1009     -0.243020698428154
    z[3,4,1]  R1010     1.4757326245307922e-01
    z[3,4,1]  R1011     4.0068429708480835e-01
    z[3,4,1]  R1012     -3.7591388821601868e-01
    z[3,4,1]  R1013     -4.4722664356231689e-01
    z[3,4,1]  R1014     -5.9642869234085083e-01
    z[3,4,1]  R1015     -6.8538486957550049e-01
    z[3,4,1]  R1016     -0.549904465675354
    z[3,4,1]  R1017     -6.5866059064865112e-01
    z[3,4,1]  R1018     -4.8701807856559753e-01
    z[3,4,1]  R1019     2.3313693702220917e-01
    z[3,4,1]  R1020     6.3290292024612427e-01
    z[3,4,1]  R1021     6.4746099710464478e-01
    z[3,4,1]  R1022     5.0144141912460327e-01
    z[3,4,1]  R1023     0.707349956035614
    z[3,4,1]  R1024     -7.4920213222503662e-01
    z[3,4,1]  R1025     -3.9429777860641479e-01
    z[3,4,1]  R1026     -6.5100133419036865e-01
    z[3,4,1]  R1027     4.4579941034317017e-01
    z[3,4,1]  R1028     -1.8676178157329559e-01
    z[3,4,1]  R1029     1.2372772395610809e-01
    z[3,4,1]  R1030     -1.3339424133300781e-01
    z[3,4,1]  R1031     6.0084593296051025e-01
    z[3,4,1]  R1032     6.8531692028045654e-01
    z[3,4,1]  R1033     -2.1109507977962494e-01
    z[3,4,1]  R1034     3.6115714907646179e-01
    z[3,4,1]  R1035     5.0819098949432373e-01
    z[3,4,1]  R1036     6.0065197944641113e-01
    z[3,4,1]  R1037     2.9567638039588928e-01
    z[3,4,1]  R1038     -2.9722964763641357e-01
    z[3,4,1]  R1039     -2.6562201976776123e-01
    z[3,4,1]  R1040     -1.9744651019573212e-01
    z[3,4,1]  R1041     -1.0959574580192566e-01
    z[3,4,1]  R1042     -1.5208879113197327e-01
    z[3,4,1]  R1043     -7.6956021785736084e-01
    z[3,4,1]  R1044     -8.6423909664154053e-01
    z[3,4,1]  R1045     -7.2976911067962646e-01
    z[3,4,1]  R1046     -6.6835129261016846e-01
    z[3,4,1]  R1047     -6.9223767518997192e-01
    z[3,4,1]  R1048     -0.820530116558075
    z[3,4,1]  R1049     4.5963096618652344e-01
    z[3,4,1]  R1050     7.0677846670150757e-01
    z[3,4,1]  R1051     3.9970946311950684e-01
    z[3,4,1]  R1052     0.728522002696991
    z[3,4,1]  R1053     -7.0043218135833740e-01
    z[3,4,1]  R1054     -6.0439997911453247e-01
    z[3,4,1]  R1055     -7.9351294040679932e-01
    z[3,4,1]  R1056     -5.0827115774154663e-01
    z[3,4,1]  R1057     2.3698510229587555e-01
    z[3,4,1]  R1058     6.2553894519805908e-01
    z[3,4,1]  R1059     4.3601259589195251e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R994      -1
    z[3,4,2]  R995      1
    z[3,4,2]  R1004     5.3643748164176941e-02
    z[3,4,2]  R1005     3.8907316327095032e-01
    z[3,4,2]  R1006     1.7657142877578735e-01
    z[3,4,2]  R1007     1.2870785593986511e-01
    z[3,4,2]  R1008     -2.1501055359840393e-01
    z[3,4,2]  R1009     -1.6630896925926208e-01
    z[3,4,2]  R1010     2.1442010998725891e-01
    z[3,4,2]  R1011     -1.0274353623390198e-01
    z[3,4,2]  R1012     1.2185801565647125e-01
    z[3,4,2]  R1013     0.476277619600296
    z[3,4,2]  R1014     -4.4175478816032410e-01
    z[3,4,2]  R1015     2.8016316890716553e-01
    z[3,4,2]  R1016     -6.3626688718795776e-01
    z[3,4,2]  R1017     -2.1197710931301117e-01
    z[3,4,2]  R1018     -3.2583191990852356e-01
    z[3,4,2]  R1019     -1.7851114273071289e-01
    z[3,4,2]  R1020     -1.9553038477897644e-01
    z[3,4,2]  R1021     3.9250016212463379e-01
    z[3,4,2]  R1022     -1.1277581006288528e-01
    z[3,4,2]  R1023     -4.5033130049705505e-01
    z[3,4,2]  R1024     1.2961444258689880e-01
    z[3,4,2]  R1025     3.1226860359311104e-02
    z[3,4,2]  R1026     1.1279319971799850e-01
    z[3,4,2]  R1027     4.8092040419578552e-01
    z[3,4,2]  R1028     -6.0414797067642212e-01
    z[3,4,2]  R1029     -1.0588270425796509e-01
    z[3,4,2]  R1030     -4.0186974406242371e-01
    z[3,4,2]  R1031     -8.4704078733921051e-02
    z[3,4,2]  R1032     3.1920984387397766e-01
    z[3,4,2]  R1033     -1.8154074251651764e-01
    z[3,4,2]  R1034     -2.8845322132110596e-01
    z[3,4,2]  R1035     -3.8084396719932556e-01
    z[3,4,2]  R1036     -0.0054810531437397
    z[3,4,2]  R1037     -2.6502066850662231e-01
    z[3,4,2]  R1038     -1.4793653041124344e-02
    z[3,4,2]  R1039     1.4257819950580597e-01
    z[3,4,2]  R1040     -1.3961243629455566e-01
    z[3,4,2]  R1041     1.1071675270795822e-01
    z[3,4,2]  R1042     1.3990931212902069e-01
    z[3,4,2]  R1043     -2.8753346204757690e-01
    z[3,4,2]  R1044     -1.6213077306747437e-01
    z[3,4,2]  R1045     -1.3287785649299622e-01
    z[3,4,2]  R1046     -1.4928828179836273e-01
    z[3,4,2]  R1047     -1.3702154159545898e-01
    z[3,4,2]  R1048     -5.3955212235450745e-02
    z[3,4,2]  R1049     2.1143613755702972e-01
    z[3,4,2]  R1050     1.2658575177192688e-01
    z[3,4,2]  R1051     9.6190765500068665e-02
    z[3,4,2]  R1052     3.9736970211379230e-04
    z[3,4,2]  R1053     -4.7123380005359650e-02
    z[3,4,2]  R1054     -7.1347869932651520e-02
    z[3,4,2]  R1055     -8.1454485654830933e-02
    z[3,4,2]  R1056     -1.7367942631244659e-01
    z[3,4,2]  R1057     1.4274470508098602e-01
    z[3,4,2]  R1058     -1.7110915854573250e-02
    z[3,4,2]  R1059     -1.8773204088211060e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R996      -1
    z[3,4,3]  R997      1
    z[3,4,3]  R1004     4.3109700083732605e-01
    z[3,4,3]  R1005     6.4160728454589844e-01
    z[3,4,3]  R1006     2.4229782819747925e-01
    z[3,4,3]  R1007     5.0953966379165649e-01
    z[3,4,3]  R1008     4.9407321214675903e-01
    z[3,4,3]  R1009     3.6014896631240845e-01
    z[3,4,3]  R1010     -1.5400671958923340e-01
    z[3,4,3]  R1011     -2.0644627511501312e-02
    z[3,4,3]  R1012     7.1278929710388184e-01
    z[3,4,3]  R1013     5.4631787538528442e-01
    z[3,4,3]  R1014     1.4938473701477051e-01
    z[3,4,3]  R1015     -4.2482399940490723e-01
    z[3,4,3]  R1016     -0.322973370552063
    z[3,4,3]  R1017     -5.8784484863281250e-01
    z[3,4,3]  R1018     -0.518854558467865
    z[3,4,3]  R1019     -7.3962485790252686e-01
    z[3,4,3]  R1020     -1.8000417947769165e-01
    z[3,4,3]  R1021     1.7879299819469452e-01
    z[3,4,3]  R1022     4.8344683647155762e-01
    z[3,4,3]  R1023     1.3597738742828369e-01
    z[3,4,3]  R1024     8.8223300874233246e-02
    z[3,4,3]  R1025     7.8663372993469238e-01
    z[3,4,3]  R1026     -1.1369927227497101e-01
    z[3,4,3]  R1027     -4.2779183387756348e-01
    z[3,4,3]  R1028     1.4524123072624207e-01
    z[3,4,3]  R1029     -6.0591280460357666e-01
    z[3,4,3]  R1030     3.6464402079582214e-01
    z[3,4,3]  R1031     4.4875079393386841e-01
    z[3,4,3]  R1032     5.4512494802474976e-01
    z[3,4,3]  R1033     -6.6604685783386230e-01
    z[3,4,3]  R1034     1.4893932640552521e-01
    z[3,4,3]  R1035     3.7170371413230896e-01
    z[3,4,3]  R1036     -1.8350727856159210e-01
    z[3,4,3]  R1037     0.0356985442340374
    z[3,4,3]  R1038     -4.7900900244712830e-01
    z[3,4,3]  R1039     -8.2958471775054932e-01
    z[3,4,3]  R1040     -4.9599045515060425e-01
    z[3,4,3]  R1041     -3.3634263277053833e-01
    z[3,4,3]  R1042     -4.4997262954711914e-01
    z[3,4,3]  R1043     0.351880818605423
    z[3,4,3]  R1044     1.5563932061195374e-01
    z[3,4,3]  R1045     0.0896289050579071
    z[3,4,3]  R1046     4.4433671981096268e-02
    z[3,4,3]  R1047     1.1404450237751007e-01
    z[3,4,3]  R1048     0.393184632062912
    z[3,4,3]  R1049     -4.0812357328832150e-03
    z[3,4,3]  R1050     3.0470450874418020e-03
    z[3,4,3]  R1051     4.4962140917778015e-01
    z[3,4,3]  R1052     -2.7278661727905273e-01
    z[3,4,3]  R1053     -5.2548497915267944e-01
    z[3,4,3]  R1054     -7.1449923515319824e-01
    z[3,4,3]  R1055     8.6602732539176941e-02
    z[3,4,3]  R1056     -0.456758052110672
    z[3,4,3]  R1057     5.5406648665666580e-02
    z[3,4,3]  R1058     5.1946036517620087e-02
    z[3,4,3]  R1059     4.9007901549339294e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R998      -1
    z[3,4,4]  R999      1
    z[3,4,4]  R1004     7.7099494636058807e-02
    z[3,4,4]  R1005     1.4336153864860535e-01
    z[3,4,4]  R1006     -2.2197237610816956e-01
    z[3,4,4]  R1007     -2.4536329507827759e-01
    z[3,4,4]  R1008     -4.9715104699134827e-01
    z[3,4,4]  R1009     -4.2462694644927979e-01
    z[3,4,4]  R1010     -1.4687924087047577e-01
    z[3,4,4]  R1011     -2.6961660385131836e-01
    z[3,4,4]  R1012     -3.5215571522712708e-01
    z[3,4,4]  R1013     0.305738627910614
    z[3,4,4]  R1014     3.1410478055477142e-02
    z[3,4,4]  R1015     3.0677413940429688e-01
    z[3,4,4]  R1016     3.3142006397247314e-01
    z[3,4,4]  R1017     3.7239551544189453e-01
    z[3,4,4]  R1018     -1.5976226329803467e-01
    z[3,4,4]  R1019     3.6165577173233032e-01
    z[3,4,4]  R1020     3.3996206521987915e-01
    z[3,4,4]  R1021     3.0345523357391357e-01
    z[3,4,4]  R1022     -1.5989659726619720e-01
    z[3,4,4]  R1023     -3.4453293681144714e-01
    z[3,4,4]  R1024     -1.4251527190208435e-01
    z[3,4,4]  R1025     -2.1376316249370575e-01
    z[3,4,4]  R1026     -3.2532259821891785e-01
    z[3,4,4]  R1027     0.474231094121933
    z[3,4,4]  R1028     -4.9816173315048218e-01
    z[3,4,4]  R1029     3.1092768907546997e-01
    z[3,4,4]  R1030     5.5697995424270630e-01
    z[3,4,4]  R1031     2.6597961783409119e-01
    z[3,4,4]  R1032     3.0822345614433289e-01
    z[3,4,4]  R1033     -6.1221265792846680e-01
    z[3,4,4]  R1034     -4.4700881838798523e-01
    z[3,4,4]  R1035     1.2542865239083767e-02
    z[3,4,4]  R1036     -1.7818284034729004e-01
    z[3,4,4]  R1037     -3.4217327833175659e-02
    z[3,4,4]  R1038     -2.6628868654370308e-02
    z[3,4,4]  R1039     2.5206291675567627e-01
    z[3,4,4]  R1040     -4.1365686058998108e-01
    z[3,4,4]  R1041     5.7872142642736435e-02
    z[3,4,4]  R1042     3.1724950671195984e-01
    z[3,4,4]  R1043     -3.1405866146087646e-01
    z[3,4,4]  R1044     0.023549759760499
    z[3,4,4]  R1045     -1.1894471943378448e-01
    z[3,4,4]  R1046     -7.0711731910705566e-02
    z[3,4,4]  R1047     5.1908683031797409e-02
    z[3,4,4]  R1048     2.0215994119644165e-01
    z[3,4,4]  R1049     5.2272111177444458e-01
    z[3,4,4]  R1050     1.8284878134727478e-01
    z[3,4,4]  R1051     2.5019386410713196e-01
    z[3,4,4]  R1052     -2.1078962087631226e-01
    z[3,4,4]  R1053     1.0750237107276917e-01
    z[3,4,4]  R1054     -5.4194923490285873e-02
    z[3,4,4]  R1055     1.0144741833209991e-01
    z[3,4,4]  R1056     -3.7986236810684204e-01
    z[3,4,4]  R1057     9.0818911790847778e-02
    z[3,4,4]  R1058     -2.8622266650199890e-01
    z[3,4,4]  R1059     -6.6355979442596436e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1000     -1
    z[3,4,5]  R1001     1
    z[3,4,5]  R1004     -2.2628612816333771e-01
    z[3,4,5]  R1005     2.8383467346429825e-02
    z[3,4,5]  R1006     2.7258491516113281e-01
    z[3,4,5]  R1007     1.6982145607471466e-01
    z[3,4,5]  R1008     3.2328939437866211e-01
    z[3,4,5]  R1009     1.5535542368888855e-01
    z[3,4,5]  R1010     8.0995744466781616e-01
    z[3,4,5]  R1011     7.9695820808410645e-01
    z[3,4,5]  R1012     -2.2832190617918968e-02
    z[3,4,5]  R1013     2.9667469859123230e-01
    z[3,4,5]  R1014     -3.6605009436607361e-01
    z[3,4,5]  R1015     -2.8311079740524292e-01
    z[3,4,5]  R1016     7.1407124400138855e-02
    z[3,4,5]  R1017     -1.0312648862600327e-01
    z[3,4,5]  R1018     -5.3364062309265137e-01
    z[3,4,5]  R1019     -1.2207627296447754e-01
    z[3,4,5]  R1020     -2.5423637032508850e-01
    z[3,4,5]  R1021     -2.7033188939094543e-01
    z[3,4,5]  R1022     -2.3554079234600067e-01
    z[3,4,5]  R1023     -3.5050097107887268e-01
    z[3,4,5]  R1024     5.8041650056838989e-01
    z[3,4,5]  R1025     3.7163376808166504e-01
    z[3,4,5]  R1026     -1.5019933879375458e-01
    z[3,4,5]  R1027     3.3966881036758423e-01
    z[3,4,5]  R1028     -6.6731266677379608e-02
    z[3,4,5]  R1029     2.8604209423065186e-01
    z[3,4,5]  R1030     3.7263652682304382e-01
    z[3,4,5]  R1031     7.8697368502616882e-02
    z[3,4,5]  R1032     1.0498242825269699e-01
    z[3,4,5]  R1033     1.2477570027112961e-01
    z[3,4,5]  R1034     7.4614512920379639e-01
    z[3,4,5]  R1035     6.0330617427825928e-01
    z[3,4,5]  R1036     6.8889522552490234e-01
    z[3,4,5]  R1037     7.2982782125473022e-01
    z[3,4,5]  R1038     4.0736641734838486e-02
    z[3,4,5]  R1039     3.1953501701354980e-01
    z[3,4,5]  R1040     5.8904135227203369e-01
    z[3,4,5]  R1041     7.8732502460479736e-01
    z[3,4,5]  R1042     7.2251111268997192e-01
    z[3,4,5]  R1043     -2.6467683911323547e-01
    z[3,4,5]  R1044     -3.2396441698074341e-01
    z[3,4,5]  R1045     -2.3210351169109344e-01
    z[3,4,5]  R1046     -2.4184677004814148e-01
    z[3,4,5]  R1047     -2.1703690290451050e-02
    z[3,4,5]  R1048     2.0627363026142120e-01
    z[3,4,5]  R1049     -2.4471905827522278e-01
    z[3,4,5]  R1050     -2.8761044144630432e-01
    z[3,4,5]  R1051     2.5541490316390991e-01
    z[3,4,5]  R1052     -2.9075062274932861e-01
    z[3,4,5]  R1053     -1.3820463418960571e-01
    z[3,4,5]  R1054     -3.2267281413078308e-01
    z[3,4,5]  R1055     -2.8438609838485718e-01
    z[3,4,5]  R1056     4.0883723646402359e-02
    z[3,4,5]  R1057     0.81397944688797
    z[3,4,5]  R1058     4.2648872733116150e-01
    z[3,4,5]  R1059     8.2856327295303345e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1002     -1
    z[3,4,6]  R1003     1
    z[3,4,6]  R1004     -7.3401778936386108e-01
    z[3,4,6]  R1005     2.3921218235045671e-03
    z[3,4,6]  R1006     -7.6444578170776367e-01
    z[3,4,6]  R1007     5.1944744586944580e-01
    z[3,4,6]  R1008     3.3187377452850342e-01
    z[3,4,6]  R1009     -5.5719721317291260e-01
    z[3,4,6]  R1010     -4.6325522661209106e-01
    z[3,4,6]  R1011     3.1263187527656555e-01
    z[3,4,6]  R1012     -1.7332918941974640e-01
    z[3,4,6]  R1013     -1.6482527554035187e-01
    z[3,4,6]  R1014     3.8398674130439758e-01
    z[3,4,6]  R1015     2.4408011138439178e-01
    z[3,4,6]  R1016     1.8971693515777588e-01
    z[3,4,6]  R1017     1.6159202158451080e-01
    z[3,4,6]  R1018     0.0920364037156105
    z[3,4,6]  R1019     1.8101497553288937e-03
    z[3,4,6]  R1020     -2.6887786388397217e-01
    z[3,4,6]  R1021     2.7434840798377991e-01
    z[3,4,6]  R1022     -3.2288864254951477e-01
    z[3,4,6]  R1023     1.9168620929121971e-02
    z[3,4,6]  R1024     2.2632595896720886e-01
    z[3,4,6]  R1025     1.8007853627204895e-01
    z[3,4,6]  R1026     -1.4954796433448792e-01
    z[3,4,6]  R1027     1.9748227298259735e-01
    z[3,4,6]  R1028     -5.3021764755249023e-01
    z[3,4,6]  R1029     -8.2450456917285919e-02
    z[3,4,6]  R1030     -0.296037882566452
    z[3,4,6]  R1031     -3.0968451872467995e-02
    z[3,4,6]  R1032     -2.3845938965678215e-02
    z[3,4,6]  R1033     2.5133961439132690e-01
    z[3,4,6]  R1034     2.5733998045325279e-02
    z[3,4,6]  R1035     -7.4962019920349121e-02
    z[3,4,6]  R1036     -2.9850602149963379e-01
    z[3,4,6]  R1037     -5.4284799098968506e-01
    z[3,4,6]  R1038     -6.1835199594497681e-01
    z[3,4,6]  R1039     2.3508971929550171e-01
    z[3,4,6]  R1040     -3.7726196646690369e-01
    z[3,4,6]  R1041     3.1346493959426880e-01
    z[3,4,6]  R1042     0.337494820356369
    z[3,4,6]  R1043     -1.6473412513732910e-01
    z[3,4,6]  R1044     1.6942480206489563e-01
    z[3,4,6]  R1045     2.9440093040466309e-01
    z[3,4,6]  R1046     5.0955861806869507e-01
    z[3,4,6]  R1047     -5.4874587804079056e-03
    z[3,4,6]  R1048     -3.4751974046230316e-02
    z[3,4,6]  R1049     -4.3802503496408463e-02
    z[3,4,6]  R1050     3.5226356238126755e-02
    z[3,4,6]  R1051     1.6212120652198792e-02
    z[3,4,6]  R1052     -3.4154140949249268e-01
    z[3,4,6]  R1053     2.5265011191368103e-01
    z[3,4,6]  R1054     5.4128278046846390e-02
    z[3,4,6]  R1055     -5.7553578168153763e-02
    z[3,4,6]  R1056     -3.8404011726379395e-01
    z[3,4,6]  R1057     2.1300770342350006e-02
    z[3,4,6]  R1058     8.4735400974750519e-02
    z[3,4,6]  R1059     1.5273508429527283e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1060     -1
    z[4,3,0]  R1061     1
    z[4,3,0]  R1074     -1.5911825001239777e-01
    z[4,3,0]  R1075     -8.3460539579391479e-02
    z[4,3,0]  R1076     -2.9796180129051208e-01
    z[4,3,0]  R1077     -0.10040283203125
    z[4,3,0]  R1078     -1.1207935959100723e-01
    z[4,3,0]  R1079     -5.4521399736404419e-01
    z[4,3,0]  R1080     2.1134330017957836e-04
    z[4,3,0]  R1081     1.8737228214740753e-01
    z[4,3,0]  R1082     -3.7565141916275024e-01
    z[4,3,0]  R1083     -1.3508066534996033e-01
    z[4,3,0]  R1084     7.3875255882740021e-02
    z[4,3,0]  R1085     2.6147386431694031e-01
    z[4,3,0]  R1086     -5.3577542304992676e-01
    z[4,3,0]  R1087     4.5376780629158020e-01
    z[4,3,0]  R1088     6.9701528549194336e-01
    z[4,3,0]  R1089     -2.9086044430732727e-01
    z[4,3,0]  R1090     6.3951069116592407e-01
    z[4,3,0]  R1091     0.605835497379303
    z[4,3,0]  R1092     7.0761835575103760e-01
    z[4,3,0]  R1093     3.8629552721977234e-01
    z[4,3,0]  R1094     3.6952725052833557e-01
    z[4,3,0]  R1095     -9.5478974282741547e-02
    z[4,3,0]  R1096     -5.1158881187438965e-01
    z[4,3,0]  R1097     -4.5761802792549133e-01
    z[4,3,0]  R1098     -4.9912708997726440e-01
    z[4,3,0]  R1099     5.7854449748992920e-01
    z[4,3,0]  R1100     -2.5291821360588074e-01
    z[4,3,0]  R1101     -3.8403651118278503e-01
    z[4,3,0]  R1102     -5.9794867038726807e-01
    z[4,3,0]  R1103     -5.3884852677583694e-02
    z[4,3,0]  R1104     -5.6895685195922852e-01
    z[4,3,0]  R1105     -4.6248784661293030e-01
    z[4,3,0]  R1106     -5.1832705736160278e-01
    z[4,3,0]  R1107     0.127742201089859
    z[4,3,0]  R1108     1.5131257474422455e-01
    z[4,3,0]  R1109     -4.2566746473312378e-01
    z[4,3,0]  R1110     2.5695389509201050e-01
    z[4,3,0]  R1111     3.7997964024543762e-01
    z[4,3,0]  R1112     -1.9350335001945496e-01
    z[4,3,0]  R1113     -1.9371852278709412e-01
    z[4,3,0]  R1114     -1.5649942681193352e-02
    z[4,3,0]  R1115     -2.6204961538314819e-01
    z[4,3,0]  R1116     4.7014385461807251e-01
    z[4,3,0]  R1117     5.2563732862472534e-01
    z[4,3,0]  R1118     3.9286059141159058e-01
    z[4,3,0]  R1119     5.6286227703094482e-01
    z[4,3,0]  R1120     -1.9090999662876129e-01
    z[4,3,0]  R1121     7.5469031929969788e-02
    z[4,3,0]  R1122     9.2340342700481415e-02
    z[4,3,0]  R1123     -6.3228809833526611e-01
    z[4,3,0]  R1124     8.7768651545047760e-02
    z[4,3,0]  R1125     2.1279385685920715e-01
    z[4,3,0]  R1126     0.648888111114502
    z[4,3,0]  R1127     3.8861066102981567e-01
    z[4,3,0]  R1128     5.9374624490737915e-01
    z[4,3,0]  R1129     1.5713982284069061e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1062     -1
    z[4,3,1]  R1063     1
    z[4,3,1]  R1074     -2.1109507977962494e-01
    z[4,3,1]  R1075     3.6115714907646179e-01
    z[4,3,1]  R1076     5.0819098949432373e-01
    z[4,3,1]  R1077     6.0065197944641113e-01
    z[4,3,1]  R1078     2.9567638039588928e-01
    z[4,3,1]  R1079     -2.9722964763641357e-01
    z[4,3,1]  R1080     -2.6562201976776123e-01
    z[4,3,1]  R1081     -1.9744651019573212e-01
    z[4,3,1]  R1082     -1.0959574580192566e-01
    z[4,3,1]  R1083     -1.5208879113197327e-01
    z[4,3,1]  R1084     -7.6956021785736084e-01
    z[4,3,1]  R1085     -8.6423909664154053e-01
    z[4,3,1]  R1086     -7.2976911067962646e-01
    z[4,3,1]  R1087     -6.6835129261016846e-01
    z[4,3,1]  R1088     -6.9223767518997192e-01
    z[4,3,1]  R1089     -0.820530116558075
    z[4,3,1]  R1090     4.5963096618652344e-01
    z[4,3,1]  R1091     7.0677846670150757e-01
    z[4,3,1]  R1092     3.9970946311950684e-01
    z[4,3,1]  R1093     0.728522002696991
    z[4,3,1]  R1094     -7.0043218135833740e-01
    z[4,3,1]  R1095     -6.0439997911453247e-01
    z[4,3,1]  R1096     -7.9351294040679932e-01
    z[4,3,1]  R1097     -5.0827115774154663e-01
    z[4,3,1]  R1098     2.3698510229587555e-01
    z[4,3,1]  R1099     6.2553894519805908e-01
    z[4,3,1]  R1100     4.3601259589195251e-01
    z[4,3,1]  R1101     -2.6050320267677307e-01
    z[4,3,1]  R1102     -2.4094755947589874e-01
    z[4,3,1]  R1103     -4.4638451933860779e-01
    z[4,3,1]  R1104     -2.0303604006767273e-01
    z[4,3,1]  R1105     -1.8426011502742767e-01
    z[4,3,1]  R1106     -0.243020698428154
    z[4,3,1]  R1107     1.4757326245307922e-01
    z[4,3,1]  R1108     4.0068429708480835e-01
    z[4,3,1]  R1109     -3.7591388821601868e-01
    z[4,3,1]  R1110     -4.4722664356231689e-01
    z[4,3,1]  R1111     -5.9642869234085083e-01
    z[4,3,1]  R1112     -6.8538486957550049e-01
    z[4,3,1]  R1113     -0.549904465675354
    z[4,3,1]  R1114     -6.5866059064865112e-01
    z[4,3,1]  R1115     -4.8701807856559753e-01
    z[4,3,1]  R1116     2.3313693702220917e-01
    z[4,3,1]  R1117     6.3290292024612427e-01
    z[4,3,1]  R1118     6.4746099710464478e-01
    z[4,3,1]  R1119     5.0144141912460327e-01
    z[4,3,1]  R1120     0.707349956035614
    z[4,3,1]  R1121     -7.4920213222503662e-01
    z[4,3,1]  R1122     -3.9429777860641479e-01
    z[4,3,1]  R1123     -6.5100133419036865e-01
    z[4,3,1]  R1124     4.4579941034317017e-01
    z[4,3,1]  R1125     -1.8676178157329559e-01
    z[4,3,1]  R1126     1.2372772395610809e-01
    z[4,3,1]  R1127     -1.3339424133300781e-01
    z[4,3,1]  R1128     6.0084593296051025e-01
    z[4,3,1]  R1129     6.8531692028045654e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1064     -1
    z[4,3,2]  R1065     1
    z[4,3,2]  R1074     -1.8154074251651764e-01
    z[4,3,2]  R1075     -2.8845322132110596e-01
    z[4,3,2]  R1076     -3.8084396719932556e-01
    z[4,3,2]  R1077     -0.0054810531437397
    z[4,3,2]  R1078     -2.6502066850662231e-01
    z[4,3,2]  R1079     -1.4793653041124344e-02
    z[4,3,2]  R1080     1.4257819950580597e-01
    z[4,3,2]  R1081     -1.3961243629455566e-01
    z[4,3,2]  R1082     1.1071675270795822e-01
    z[4,3,2]  R1083     1.3990931212902069e-01
    z[4,3,2]  R1084     -2.8753346204757690e-01
    z[4,3,2]  R1085     -1.6213077306747437e-01
    z[4,3,2]  R1086     -1.3287785649299622e-01
    z[4,3,2]  R1087     -1.4928828179836273e-01
    z[4,3,2]  R1088     -1.3702154159545898e-01
    z[4,3,2]  R1089     -5.3955212235450745e-02
    z[4,3,2]  R1090     2.1143613755702972e-01
    z[4,3,2]  R1091     1.2658575177192688e-01
    z[4,3,2]  R1092     9.6190765500068665e-02
    z[4,3,2]  R1093     3.9736970211379230e-04
    z[4,3,2]  R1094     -4.7123380005359650e-02
    z[4,3,2]  R1095     -7.1347869932651520e-02
    z[4,3,2]  R1096     -8.1454485654830933e-02
    z[4,3,2]  R1097     -1.7367942631244659e-01
    z[4,3,2]  R1098     1.4274470508098602e-01
    z[4,3,2]  R1099     -1.7110915854573250e-02
    z[4,3,2]  R1100     -1.8773204088211060e-01
    z[4,3,2]  R1101     5.3643748164176941e-02
    z[4,3,2]  R1102     3.8907316327095032e-01
    z[4,3,2]  R1103     1.7657142877578735e-01
    z[4,3,2]  R1104     1.2870785593986511e-01
    z[4,3,2]  R1105     -2.1501055359840393e-01
    z[4,3,2]  R1106     -1.6630896925926208e-01
    z[4,3,2]  R1107     2.1442010998725891e-01
    z[4,3,2]  R1108     -1.0274353623390198e-01
    z[4,3,2]  R1109     1.2185801565647125e-01
    z[4,3,2]  R1110     0.476277619600296
    z[4,3,2]  R1111     -4.4175478816032410e-01
    z[4,3,2]  R1112     2.8016316890716553e-01
    z[4,3,2]  R1113     -6.3626688718795776e-01
    z[4,3,2]  R1114     -2.1197710931301117e-01
    z[4,3,2]  R1115     -3.2583191990852356e-01
    z[4,3,2]  R1116     -1.7851114273071289e-01
    z[4,3,2]  R1117     -1.9553038477897644e-01
    z[4,3,2]  R1118     3.9250016212463379e-01
    z[4,3,2]  R1119     -1.1277581006288528e-01
    z[4,3,2]  R1120     -4.5033130049705505e-01
    z[4,3,2]  R1121     1.2961444258689880e-01
    z[4,3,2]  R1122     3.1226860359311104e-02
    z[4,3,2]  R1123     1.1279319971799850e-01
    z[4,3,2]  R1124     4.8092040419578552e-01
    z[4,3,2]  R1125     -6.0414797067642212e-01
    z[4,3,2]  R1126     -1.0588270425796509e-01
    z[4,3,2]  R1127     -4.0186974406242371e-01
    z[4,3,2]  R1128     -8.4704078733921051e-02
    z[4,3,2]  R1129     3.1920984387397766e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1066     -1
    z[4,3,3]  R1067     1
    z[4,3,3]  R1074     -6.6604685783386230e-01
    z[4,3,3]  R1075     1.4893932640552521e-01
    z[4,3,3]  R1076     3.7170371413230896e-01
    z[4,3,3]  R1077     -1.8350727856159210e-01
    z[4,3,3]  R1078     0.0356985442340374
    z[4,3,3]  R1079     -4.7900900244712830e-01
    z[4,3,3]  R1080     -8.2958471775054932e-01
    z[4,3,3]  R1081     -4.9599045515060425e-01
    z[4,3,3]  R1082     -3.3634263277053833e-01
    z[4,3,3]  R1083     -4.4997262954711914e-01
    z[4,3,3]  R1084     0.351880818605423
    z[4,3,3]  R1085     1.5563932061195374e-01
    z[4,3,3]  R1086     0.0896289050579071
    z[4,3,3]  R1087     4.4433671981096268e-02
    z[4,3,3]  R1088     1.1404450237751007e-01
    z[4,3,3]  R1089     0.393184632062912
    z[4,3,3]  R1090     -4.0812357328832150e-03
    z[4,3,3]  R1091     3.0470450874418020e-03
    z[4,3,3]  R1092     4.4962140917778015e-01
    z[4,3,3]  R1093     -2.7278661727905273e-01
    z[4,3,3]  R1094     -5.2548497915267944e-01
    z[4,3,3]  R1095     -7.1449923515319824e-01
    z[4,3,3]  R1096     8.6602732539176941e-02
    z[4,3,3]  R1097     -0.456758052110672
    z[4,3,3]  R1098     5.5406648665666580e-02
    z[4,3,3]  R1099     5.1946036517620087e-02
    z[4,3,3]  R1100     4.9007901549339294e-01
    z[4,3,3]  R1101     4.3109700083732605e-01
    z[4,3,3]  R1102     6.4160728454589844e-01
    z[4,3,3]  R1103     2.4229782819747925e-01
    z[4,3,3]  R1104     5.0953966379165649e-01
    z[4,3,3]  R1105     4.9407321214675903e-01
    z[4,3,3]  R1106     3.6014896631240845e-01
    z[4,3,3]  R1107     -1.5400671958923340e-01
    z[4,3,3]  R1108     -2.0644627511501312e-02
    z[4,3,3]  R1109     7.1278929710388184e-01
    z[4,3,3]  R1110     5.4631787538528442e-01
    z[4,3,3]  R1111     1.4938473701477051e-01
    z[4,3,3]  R1112     -4.2482399940490723e-01
    z[4,3,3]  R1113     -0.322973370552063
    z[4,3,3]  R1114     -5.8784484863281250e-01
    z[4,3,3]  R1115     -0.518854558467865
    z[4,3,3]  R1116     -7.3962485790252686e-01
    z[4,3,3]  R1117     -1.8000417947769165e-01
    z[4,3,3]  R1118     1.7879299819469452e-01
    z[4,3,3]  R1119     4.8344683647155762e-01
    z[4,3,3]  R1120     1.3597738742828369e-01
    z[4,3,3]  R1121     8.8223300874233246e-02
    z[4,3,3]  R1122     7.8663372993469238e-01
    z[4,3,3]  R1123     -1.1369927227497101e-01
    z[4,3,3]  R1124     -4.2779183387756348e-01
    z[4,3,3]  R1125     1.4524123072624207e-01
    z[4,3,3]  R1126     -6.0591280460357666e-01
    z[4,3,3]  R1127     3.6464402079582214e-01
    z[4,3,3]  R1128     4.4875079393386841e-01
    z[4,3,3]  R1129     5.4512494802474976e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1068     -1
    z[4,3,4]  R1069     1
    z[4,3,4]  R1074     -6.1221265792846680e-01
    z[4,3,4]  R1075     -4.4700881838798523e-01
    z[4,3,4]  R1076     1.2542865239083767e-02
    z[4,3,4]  R1077     -1.7818284034729004e-01
    z[4,3,4]  R1078     -3.4217327833175659e-02
    z[4,3,4]  R1079     -2.6628868654370308e-02
    z[4,3,4]  R1080     2.5206291675567627e-01
    z[4,3,4]  R1081     -4.1365686058998108e-01
    z[4,3,4]  R1082     5.7872142642736435e-02
    z[4,3,4]  R1083     3.1724950671195984e-01
    z[4,3,4]  R1084     -3.1405866146087646e-01
    z[4,3,4]  R1085     0.023549759760499
    z[4,3,4]  R1086     -1.1894471943378448e-01
    z[4,3,4]  R1087     -7.0711731910705566e-02
    z[4,3,4]  R1088     5.1908683031797409e-02
    z[4,3,4]  R1089     2.0215994119644165e-01
    z[4,3,4]  R1090     5.2272111177444458e-01
    z[4,3,4]  R1091     1.8284878134727478e-01
    z[4,3,4]  R1092     2.5019386410713196e-01
    z[4,3,4]  R1093     -2.1078962087631226e-01
    z[4,3,4]  R1094     1.0750237107276917e-01
    z[4,3,4]  R1095     -5.4194923490285873e-02
    z[4,3,4]  R1096     1.0144741833209991e-01
    z[4,3,4]  R1097     -3.7986236810684204e-01
    z[4,3,4]  R1098     9.0818911790847778e-02
    z[4,3,4]  R1099     -2.8622266650199890e-01
    z[4,3,4]  R1100     -6.6355979442596436e-01
    z[4,3,4]  R1101     7.7099494636058807e-02
    z[4,3,4]  R1102     1.4336153864860535e-01
    z[4,3,4]  R1103     -2.2197237610816956e-01
    z[4,3,4]  R1104     -2.4536329507827759e-01
    z[4,3,4]  R1105     -4.9715104699134827e-01
    z[4,3,4]  R1106     -4.2462694644927979e-01
    z[4,3,4]  R1107     -1.4687924087047577e-01
    z[4,3,4]  R1108     -2.6961660385131836e-01
    z[4,3,4]  R1109     -3.5215571522712708e-01
    z[4,3,4]  R1110     0.305738627910614
    z[4,3,4]  R1111     3.1410478055477142e-02
    z[4,3,4]  R1112     3.0677413940429688e-01
    z[4,3,4]  R1113     3.3142006397247314e-01
    z[4,3,4]  R1114     3.7239551544189453e-01
    z[4,3,4]  R1115     -1.5976226329803467e-01
    z[4,3,4]  R1116     3.6165577173233032e-01
    z[4,3,4]  R1117     3.3996206521987915e-01
    z[4,3,4]  R1118     3.0345523357391357e-01
    z[4,3,4]  R1119     -1.5989659726619720e-01
    z[4,3,4]  R1120     -3.4453293681144714e-01
    z[4,3,4]  R1121     -1.4251527190208435e-01
    z[4,3,4]  R1122     -2.1376316249370575e-01
    z[4,3,4]  R1123     -3.2532259821891785e-01
    z[4,3,4]  R1124     0.474231094121933
    z[4,3,4]  R1125     -4.9816173315048218e-01
    z[4,3,4]  R1126     3.1092768907546997e-01
    z[4,3,4]  R1127     5.5697995424270630e-01
    z[4,3,4]  R1128     2.6597961783409119e-01
    z[4,3,4]  R1129     3.0822345614433289e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1070     -1
    z[4,3,5]  R1071     1
    z[4,3,5]  R1074     1.2477570027112961e-01
    z[4,3,5]  R1075     7.4614512920379639e-01
    z[4,3,5]  R1076     6.0330617427825928e-01
    z[4,3,5]  R1077     6.8889522552490234e-01
    z[4,3,5]  R1078     7.2982782125473022e-01
    z[4,3,5]  R1079     4.0736641734838486e-02
    z[4,3,5]  R1080     3.1953501701354980e-01
    z[4,3,5]  R1081     5.8904135227203369e-01
    z[4,3,5]  R1082     7.8732502460479736e-01
    z[4,3,5]  R1083     7.2251111268997192e-01
    z[4,3,5]  R1084     -2.6467683911323547e-01
    z[4,3,5]  R1085     -3.2396441698074341e-01
    z[4,3,5]  R1086     -2.3210351169109344e-01
    z[4,3,5]  R1087     -2.4184677004814148e-01
    z[4,3,5]  R1088     -2.1703690290451050e-02
    z[4,3,5]  R1089     2.0627363026142120e-01
    z[4,3,5]  R1090     -2.4471905827522278e-01
    z[4,3,5]  R1091     -2.8761044144630432e-01
    z[4,3,5]  R1092     2.5541490316390991e-01
    z[4,3,5]  R1093     -2.9075062274932861e-01
    z[4,3,5]  R1094     -1.3820463418960571e-01
    z[4,3,5]  R1095     -3.2267281413078308e-01
    z[4,3,5]  R1096     -2.8438609838485718e-01
    z[4,3,5]  R1097     4.0883723646402359e-02
    z[4,3,5]  R1098     0.81397944688797
    z[4,3,5]  R1099     4.2648872733116150e-01
    z[4,3,5]  R1100     8.2856327295303345e-02
    z[4,3,5]  R1101     -2.2628612816333771e-01
    z[4,3,5]  R1102     2.8383467346429825e-02
    z[4,3,5]  R1103     2.7258491516113281e-01
    z[4,3,5]  R1104     1.6982145607471466e-01
    z[4,3,5]  R1105     3.2328939437866211e-01
    z[4,3,5]  R1106     1.5535542368888855e-01
    z[4,3,5]  R1107     8.0995744466781616e-01
    z[4,3,5]  R1108     7.9695820808410645e-01
    z[4,3,5]  R1109     -2.2832190617918968e-02
    z[4,3,5]  R1110     2.9667469859123230e-01
    z[4,3,5]  R1111     -3.6605009436607361e-01
    z[4,3,5]  R1112     -2.8311079740524292e-01
    z[4,3,5]  R1113     7.1407124400138855e-02
    z[4,3,5]  R1114     -1.0312648862600327e-01
    z[4,3,5]  R1115     -5.3364062309265137e-01
    z[4,3,5]  R1116     -1.2207627296447754e-01
    z[4,3,5]  R1117     -2.5423637032508850e-01
    z[4,3,5]  R1118     -2.7033188939094543e-01
    z[4,3,5]  R1119     -2.3554079234600067e-01
    z[4,3,5]  R1120     -3.5050097107887268e-01
    z[4,3,5]  R1121     5.8041650056838989e-01
    z[4,3,5]  R1122     3.7163376808166504e-01
    z[4,3,5]  R1123     -1.5019933879375458e-01
    z[4,3,5]  R1124     3.3966881036758423e-01
    z[4,3,5]  R1125     -6.6731266677379608e-02
    z[4,3,5]  R1126     2.8604209423065186e-01
    z[4,3,5]  R1127     3.7263652682304382e-01
    z[4,3,5]  R1128     7.8697368502616882e-02
    z[4,3,5]  R1129     1.0498242825269699e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1072     -1
    z[4,3,6]  R1073     1
    z[4,3,6]  R1074     2.5133961439132690e-01
    z[4,3,6]  R1075     2.5733998045325279e-02
    z[4,3,6]  R1076     -7.4962019920349121e-02
    z[4,3,6]  R1077     -2.9850602149963379e-01
    z[4,3,6]  R1078     -5.4284799098968506e-01
    z[4,3,6]  R1079     -6.1835199594497681e-01
    z[4,3,6]  R1080     2.3508971929550171e-01
    z[4,3,6]  R1081     -3.7726196646690369e-01
    z[4,3,6]  R1082     3.1346493959426880e-01
    z[4,3,6]  R1083     0.337494820356369
    z[4,3,6]  R1084     -1.6473412513732910e-01
    z[4,3,6]  R1085     1.6942480206489563e-01
    z[4,3,6]  R1086     2.9440093040466309e-01
    z[4,3,6]  R1087     5.0955861806869507e-01
    z[4,3,6]  R1088     -5.4874587804079056e-03
    z[4,3,6]  R1089     -3.4751974046230316e-02
    z[4,3,6]  R1090     -4.3802503496408463e-02
    z[4,3,6]  R1091     3.5226356238126755e-02
    z[4,3,6]  R1092     1.6212120652198792e-02
    z[4,3,6]  R1093     -3.4154140949249268e-01
    z[4,3,6]  R1094     2.5265011191368103e-01
    z[4,3,6]  R1095     5.4128278046846390e-02
    z[4,3,6]  R1096     -5.7553578168153763e-02
    z[4,3,6]  R1097     -3.8404011726379395e-01
    z[4,3,6]  R1098     2.1300770342350006e-02
    z[4,3,6]  R1099     8.4735400974750519e-02
    z[4,3,6]  R1100     1.5273508429527283e-01
    z[4,3,6]  R1101     -7.3401778936386108e-01
    z[4,3,6]  R1102     2.3921218235045671e-03
    z[4,3,6]  R1103     -7.6444578170776367e-01
    z[4,3,6]  R1104     5.1944744586944580e-01
    z[4,3,6]  R1105     3.3187377452850342e-01
    z[4,3,6]  R1106     -5.5719721317291260e-01
    z[4,3,6]  R1107     -4.6325522661209106e-01
    z[4,3,6]  R1108     3.1263187527656555e-01
    z[4,3,6]  R1109     -1.7332918941974640e-01
    z[4,3,6]  R1110     -1.6482527554035187e-01
    z[4,3,6]  R1111     3.8398674130439758e-01
    z[4,3,6]  R1112     2.4408011138439178e-01
    z[4,3,6]  R1113     1.8971693515777588e-01
    z[4,3,6]  R1114     1.6159202158451080e-01
    z[4,3,6]  R1115     0.0920364037156105
    z[4,3,6]  R1116     1.8101497553288937e-03
    z[4,3,6]  R1117     -2.6887786388397217e-01
    z[4,3,6]  R1118     2.7434840798377991e-01
    z[4,3,6]  R1119     -3.2288864254951477e-01
    z[4,3,6]  R1120     1.9168620929121971e-02
    z[4,3,6]  R1121     2.2632595896720886e-01
    z[4,3,6]  R1122     1.8007853627204895e-01
    z[4,3,6]  R1123     -1.4954796433448792e-01
    z[4,3,6]  R1124     1.9748227298259735e-01
    z[4,3,6]  R1125     -5.3021764755249023e-01
    z[4,3,6]  R1126     -8.2450456917285919e-02
    z[4,3,6]  R1127     -0.296037882566452
    z[4,3,6]  R1128     -3.0968451872467995e-02
    z[4,3,6]  R1129     -2.3845938965678215e-02
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1130     -1
    z[3,6,0]  R1131     1
    z[3,6,0]  R1144     -3.8403651118278503e-01
    z[3,6,0]  R1145     -5.9794867038726807e-01
    z[3,6,0]  R1146     -5.3884852677583694e-02
    z[3,6,0]  R1147     -5.6895685195922852e-01
    z[3,6,0]  R1148     -4.6248784661293030e-01
    z[3,6,0]  R1149     -5.1832705736160278e-01
    z[3,6,0]  R1150     0.127742201089859
    z[3,6,0]  R1151     1.5131257474422455e-01
    z[3,6,0]  R1152     -4.2566746473312378e-01
    z[3,6,0]  R1153     2.5695389509201050e-01
    z[3,6,0]  R1154     3.7997964024543762e-01
    z[3,6,0]  R1155     -1.9350335001945496e-01
    z[3,6,0]  R1156     -1.9371852278709412e-01
    z[3,6,0]  R1157     -1.5649942681193352e-02
    z[3,6,0]  R1158     -2.6204961538314819e-01
    z[3,6,0]  R1159     4.7014385461807251e-01
    z[3,6,0]  R1160     5.2563732862472534e-01
    z[3,6,0]  R1161     3.9286059141159058e-01
    z[3,6,0]  R1162     5.6286227703094482e-01
    z[3,6,0]  R1163     -1.9090999662876129e-01
    z[3,6,0]  R1164     7.5469031929969788e-02
    z[3,6,0]  R1165     9.2340342700481415e-02
    z[3,6,0]  R1166     -6.3228809833526611e-01
    z[3,6,0]  R1167     8.7768651545047760e-02
    z[3,6,0]  R1168     2.1279385685920715e-01
    z[3,6,0]  R1169     0.648888111114502
    z[3,6,0]  R1170     3.8861066102981567e-01
    z[3,6,0]  R1171     5.9374624490737915e-01
    z[3,6,0]  R1172     1.5713982284069061e-01
    z[3,6,0]  R1173     -9.0638458728790283e-01
    z[3,6,0]  R1174     -8.2799595594406128e-01
    z[3,6,0]  R1175     -7.8493207693099976e-01
    z[3,6,0]  R1176     -7.0772647857666016e-01
    z[3,6,0]  R1177     -0.819678008556366
    z[3,6,0]  R1178     -6.6300272941589355e-01
    z[3,6,0]  R1179     -8.1264919042587280e-01
    z[3,6,0]  R1180     -6.8940824270248413e-01
    z[3,6,0]  R1181     -8.8037103414535522e-01
    z[3,6,0]  R1182     2.9375693202018738e-01
    z[3,6,0]  R1183     -3.8623297587037086e-04
    z[3,6,0]  R1184     4.9018543958663940e-01
    z[3,6,0]  R1185     4.9586838483810425e-01
    z[3,6,0]  R1186     4.3103596568107605e-01
    z[3,6,0]  R1187     2.0347057282924652e-01
    z[3,6,0]  R1188     3.9923486113548279e-01
    z[3,6,0]  R1189     0.421084463596344
    z[3,6,0]  R1190     2.6942405104637146e-01
    z[3,6,0]  R1191     3.8349777460098267e-01
    z[3,6,0]  R1192     3.8672599196434021e-01
    z[3,6,0]  R1193     0.599850058555603
    z[3,6,0]  R1194     3.9805805683135986e-01
    z[3,6,0]  R1195     9.7217820584774017e-02
    z[3,6,0]  R1196     3.7836232781410217e-01
    z[3,6,0]  R1197     2.1848320960998535e-01
    z[3,6,0]  R1198     4.0968227386474609e-01
    z[3,6,0]  R1199     5.7834142446517944e-01
    z[3,6,0]  R1200     -4.1519635915756226e-01
    z[3,6,0]  R1201     -2.0829349756240845e-01
    z[3,6,0]  R1202     1.6713143885135651e-01
    z[3,6,0]  R1203     0.291344553232193
    z[3,6,0]  R1204     2.0175081491470337e-01
    z[3,6,0]  R1205     -1.8293541669845581e-01
    z[3,6,0]  R1206     -1.5737058222293854e-01
    z[3,6,0]  R1207     -7.6309749856591225e-03
    z[3,6,0]  R1208     -3.4955191612243652e-01
    z[3,6,0]  R1209     -4.1043874621391296e-01
    z[3,6,0]  R1210     1.1732964962720871e-01
    z[3,6,0]  R1211     -4.1289508342742920e-01
    z[3,6,0]  R1212     6.7198120057582855e-02
    z[3,6,0]  R1213     1.4178267121315002e-01
    z[3,6,0]  R1214     -3.6966481804847717e-01
    z[3,6,0]  R1215     4.9518829584121704e-01
    z[3,6,0]  R1216     -2.0473115146160126e-01
    z[3,6,0]  R1217     -8.2797199487686157e-01
    z[3,6,0]  R1218     0.617081344127655
    z[3,6,0]  R1219     5.0851190090179443e-01
    z[3,6,0]  R1220     3.9375400543212891e-01
    z[3,6,0]  R1221     0.809958279132843
    z[3,6,0]  R1222     8.5605132579803467e-01
    z[3,6,0]  R1223     -2.9784919694066048e-02
    z[3,6,0]  R1224     -0.286978155374527
    z[3,6,0]  R1225     1.6640554368495941e-01
    z[3,6,0]  R1226     7.2376525402069092e-01
    z[3,6,0]  R1227     -1.7412005364894867e-01
    z[3,6,0]  R1228     8.0571383237838745e-02
    z[3,6,0]  R1229     8.3700728416442871e-01
    z[3,6,0]  R1230     1.3343612849712372e-01
    z[3,6,0]  R1231     -6.4536012709140778e-02
    z[3,6,0]  R1232     4.4132387638092041e-01
    z[3,6,0]  R1233     6.9306713342666626e-01
    z[3,6,0]  R1234     -2.6543736457824707e-01
    z[3,6,0]  R1235     4.8704367876052856e-01
    z[3,6,0]  R1236     3.5728746652603149e-01
    z[3,6,0]  R1237     2.4972066283226013e-01
    z[3,6,0]  R1238     2.2820445895195007e-01
    z[3,6,0]  R1239     4.4021755456924438e-01
    z[3,6,0]  R1240     8.7229609489440918e-01
    z[3,6,0]  R1241     1.6437853872776031e-01
    z[3,6,0]  R1242     4.1851267218589783e-01
    z[3,6,0]  R1243     -9.3097686767578125e-02
    z[3,6,0]  R1244     0.0915379747748375
    z[3,6,0]  R1245     -0.0588078498840332
    z[3,6,0]  R1246     4.6570891141891479e-01
    z[3,6,0]  R1247     -3.0314895510673523e-01
    z[3,6,0]  R1248     3.5545620322227478e-01
    z[3,6,0]  R1249     -2.0369479060173035e-01
    z[3,6,0]  R1250     -1.8442565202713013e-01
    z[3,6,0]  R1251     4.4914808869361877e-01
    z[3,6,0]  R1252     5.8731153607368469e-02
    z[3,6,0]  R1253     0.0049970424734056
    z[3,6,0]  R1254     -3.4934845566749573e-01
    z[3,6,0]  R1255     -7.5006228685379028e-01
    z[3,6,0]  R1256     4.0946078300476074e-01
    z[3,6,0]  R1257     -1.1233063042163849e-01
    z[3,6,0]  R1258     7.2808766365051270e-01
    z[3,6,0]  R1259     -2.4780279025435448e-02
    z[3,6,0]  R1260     -3.3136874437332153e-02
    z[3,6,0]  R1261     3.3650982379913330e-01
    z[3,6,0]  R1262     3.7405374646186829e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1132     -1
    z[3,6,1]  R1133     1
    z[3,6,1]  R1144     -2.6050320267677307e-01
    z[3,6,1]  R1145     -2.4094755947589874e-01
    z[3,6,1]  R1146     -4.4638451933860779e-01
    z[3,6,1]  R1147     -2.0303604006767273e-01
    z[3,6,1]  R1148     -1.8426011502742767e-01
    z[3,6,1]  R1149     -0.243020698428154
    z[3,6,1]  R1150     1.4757326245307922e-01
    z[3,6,1]  R1151     4.0068429708480835e-01
    z[3,6,1]  R1152     -3.7591388821601868e-01
    z[3,6,1]  R1153     -4.4722664356231689e-01
    z[3,6,1]  R1154     -5.9642869234085083e-01
    z[3,6,1]  R1155     -6.8538486957550049e-01
    z[3,6,1]  R1156     -0.549904465675354
    z[3,6,1]  R1157     -6.5866059064865112e-01
    z[3,6,1]  R1158     -4.8701807856559753e-01
    z[3,6,1]  R1159     2.3313693702220917e-01
    z[3,6,1]  R1160     6.3290292024612427e-01
    z[3,6,1]  R1161     6.4746099710464478e-01
    z[3,6,1]  R1162     5.0144141912460327e-01
    z[3,6,1]  R1163     0.707349956035614
    z[3,6,1]  R1164     -7.4920213222503662e-01
    z[3,6,1]  R1165     -3.9429777860641479e-01
    z[3,6,1]  R1166     -6.5100133419036865e-01
    z[3,6,1]  R1167     4.4579941034317017e-01
    z[3,6,1]  R1168     -1.8676178157329559e-01
    z[3,6,1]  R1169     1.2372772395610809e-01
    z[3,6,1]  R1170     -1.3339424133300781e-01
    z[3,6,1]  R1171     6.0084593296051025e-01
    z[3,6,1]  R1172     6.8531692028045654e-01
    z[3,6,1]  R1173     2.3567005991935730e-01
    z[3,6,1]  R1174     -4.1897028684616089e-02
    z[3,6,1]  R1175     2.8792524710297585e-02
    z[3,6,1]  R1176     -1.2074025720357895e-01
    z[3,6,1]  R1177     -8.2762926816940308e-02
    z[3,6,1]  R1178     -1.4048515260219574e-01
    z[3,6,1]  R1179     4.6277213841676712e-02
    z[3,6,1]  R1180     -1.1682908982038498e-01
    z[3,6,1]  R1181     -1.0781950503587723e-01
    z[3,6,1]  R1182     -2.0093406736850739e-01
    z[3,6,1]  R1183     -8.9190477132797241e-01
    z[3,6,1]  R1184     -3.7189406156539917e-01
    z[3,6,1]  R1185     -4.8617777228355408e-01
    z[3,6,1]  R1186     -5.5693954229354858e-01
    z[3,6,1]  R1187     -6.9330793619155884e-01
    z[3,6,1]  R1188     -7.2400510311126709e-01
    z[3,6,1]  R1189     8.9146637916564941e-01
    z[3,6,1]  R1190     9.2655897140502930e-01
    z[3,6,1]  R1191     8.8261890411376953e-01
    z[3,6,1]  R1192     0.881799578666687
    z[3,6,1]  R1193     -5.0700485706329346e-01
    z[3,6,1]  R1194     -7.7167344093322754e-01
    z[3,6,1]  R1195     -8.0269873142242432e-01
    z[3,6,1]  R1196     -3.3003348112106323e-01
    z[3,6,1]  R1197     -3.3140763640403748e-01
    z[3,6,1]  R1198     -7.5931972265243530e-01
    z[3,6,1]  R1199     -1.2345468252897263e-01
    z[3,6,1]  R1200     -7.6918292045593262e-01
    z[3,6,1]  R1201     -0.752150297164917
    z[3,6,1]  R1202     -7.9434764385223389e-01
    z[3,6,1]  R1203     -9.1375911235809326e-01
    z[3,6,1]  R1204     -7.7818918228149414e-01
    z[3,6,1]  R1205     -9.4941031932830811e-01
    z[3,6,1]  R1206     -9.4771158695220947e-01
    z[3,6,1]  R1207     -6.0370171070098877e-01
    z[3,6,1]  R1208     -8.1486070156097412e-01
    z[3,6,1]  R1209     -7.2885221242904663e-01
    z[3,6,1]  R1210     -6.8084597587585449e-01
    z[3,6,1]  R1211     -7.7136713266372681e-01
    z[3,6,1]  R1212     -7.2400116920471191e-01
    z[3,6,1]  R1213     -0.770193874835968
    z[3,6,1]  R1214     -8.5195004940032959e-01
    z[3,6,1]  R1215     4.2647279798984528e-02
    z[3,6,1]  R1216     -8.0612915754318237e-01
    z[3,6,1]  R1217     -3.8849323987960815e-01
    z[3,6,1]  R1218     -3.4533193707466125e-01
    z[3,6,1]  R1219     -5.2539217472076416e-01
    z[3,6,1]  R1220     -3.1653749942779541e-01
    z[3,6,1]  R1221     -3.4983004443347454e-03
    z[3,6,1]  R1222     0.0690355971455574
    z[3,6,1]  R1223     -8.1956321001052856e-01
    z[3,6,1]  R1224     -5.9959208965301514e-01
    z[3,6,1]  R1225     -7.6063059270381927e-02
    z[3,6,1]  R1226     -2.0901305973529816e-01
    z[3,6,1]  R1227     -4.9557766318321228e-01
    z[3,6,1]  R1228     -5.0943940877914429e-01
    z[3,6,1]  R1229     -2.6115508750081062e-02
    z[3,6,1]  R1230     7.8820818662643433e-01
    z[3,6,1]  R1231     9.4797450304031372e-01
    z[3,6,1]  R1232     5.7311809062957764e-01
    z[3,6,1]  R1233     -9.0785082429647446e-03
    z[3,6,1]  R1234     -5.7964098453521729e-01
    z[3,6,1]  R1235     -4.8482900857925415e-01
    z[3,6,1]  R1236     -1.7932601273059845e-01
    z[3,6,1]  R1237     -3.6394849419593811e-01
    z[3,6,1]  R1238     -0.682121753692627
    z[3,6,1]  R1239     -7.4453867971897125e-02
    z[3,6,1]  R1240     6.0457970947027206e-02
    z[3,6,1]  R1241     -0.321254700422287
    z[3,6,1]  R1242     -1.4761339128017426e-01
    z[3,6,1]  R1243     -7.9079437255859375e-01
    z[3,6,1]  R1244     -8.0034458637237549e-01
    z[3,6,1]  R1245     -8.2423675060272217e-01
    z[3,6,1]  R1246     -5.2353560924530029e-02
    z[3,6,1]  R1247     -5.6139910221099854e-01
    z[3,6,1]  R1248     -1.7574384808540344e-01
    z[3,6,1]  R1249     -4.8669952154159546e-01
    z[3,6,1]  R1250     0.811751663684845
    z[3,6,1]  R1251     0.639335036277771
    z[3,6,1]  R1252     7.7055817842483521e-01
    z[3,6,1]  R1253     -9.2000114917755127e-01
    z[3,6,1]  R1254     -8.1789934635162354e-01
    z[3,6,1]  R1255     -5.2259933948516846e-01
    z[3,6,1]  R1256     -0.166182741522789
    z[3,6,1]  R1257     -0.468726247549057
    z[3,6,1]  R1258     -1.8806332349777222e-01
    z[3,6,1]  R1259     8.7126356363296509e-01
    z[3,6,1]  R1260     4.3835404515266418e-01
    z[3,6,1]  R1261     7.1538448333740234e-01
    z[3,6,1]  R1262     5.4896432161331177e-01
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1134     -1
    z[3,6,2]  R1135     1
    z[3,6,2]  R1144     5.3643748164176941e-02
    z[3,6,2]  R1145     3.8907316327095032e-01
    z[3,6,2]  R1146     1.7657142877578735e-01
    z[3,6,2]  R1147     1.2870785593986511e-01
    z[3,6,2]  R1148     -2.1501055359840393e-01
    z[3,6,2]  R1149     -1.6630896925926208e-01
    z[3,6,2]  R1150     2.1442010998725891e-01
    z[3,6,2]  R1151     -1.0274353623390198e-01
    z[3,6,2]  R1152     1.2185801565647125e-01
    z[3,6,2]  R1153     0.476277619600296
    z[3,6,2]  R1154     -4.4175478816032410e-01
    z[3,6,2]  R1155     2.8016316890716553e-01
    z[3,6,2]  R1156     -6.3626688718795776e-01
    z[3,6,2]  R1157     -2.1197710931301117e-01
    z[3,6,2]  R1158     -3.2583191990852356e-01
    z[3,6,2]  R1159     -1.7851114273071289e-01
    z[3,6,2]  R1160     -1.9553038477897644e-01
    z[3,6,2]  R1161     3.9250016212463379e-01
    z[3,6,2]  R1162     -1.1277581006288528e-01
    z[3,6,2]  R1163     -4.5033130049705505e-01
    z[3,6,2]  R1164     1.2961444258689880e-01
    z[3,6,2]  R1165     3.1226860359311104e-02
    z[3,6,2]  R1166     1.1279319971799850e-01
    z[3,6,2]  R1167     4.8092040419578552e-01
    z[3,6,2]  R1168     -6.0414797067642212e-01
    z[3,6,2]  R1169     -1.0588270425796509e-01
    z[3,6,2]  R1170     -4.0186974406242371e-01
    z[3,6,2]  R1171     -8.4704078733921051e-02
    z[3,6,2]  R1172     3.1920984387397766e-01
    z[3,6,2]  R1173     4.8219002783298492e-02
    z[3,6,2]  R1174     2.4617350101470947e-01
    z[3,6,2]  R1175     0.0839306190609932
    z[3,6,2]  R1176     2.1931204199790955e-01
    z[3,6,2]  R1177     -1.4509050548076630e-01
    z[3,6,2]  R1178     -1.1842354387044907e-01
    z[3,6,2]  R1179     -3.0637830495834351e-01
    z[3,6,2]  R1180     -2.6090177893638611e-01
    z[3,6,2]  R1181     -1.3556927442550659e-01
    z[3,6,2]  R1182     -1.7798444628715515e-01
    z[3,6,2]  R1183     -5.5900290608406067e-02
    z[3,6,2]  R1184     -2.9828870296478271e-01
    z[3,6,2]  R1185     -1.3427162542939186e-02
    z[3,6,2]  R1186     4.1312953829765320e-01
    z[3,6,2]  R1187     -3.4522205591201782e-01
    z[3,6,2]  R1188     0.289383202791214
    z[3,6,2]  R1189     1.4852622523903847e-02
    z[3,6,2]  R1190     2.1137434244155884e-01
    z[3,6,2]  R1191     6.5856881439685822e-02
    z[3,6,2]  R1192     2.1253588795661926e-01
    z[3,6,2]  R1193     1.0035727173089981e-01
    z[3,6,2]  R1194     1.6829672455787659e-01
    z[3,6,2]  R1195     -1.9416575133800507e-01
    z[3,6,2]  R1196     -1.8333847820758820e-01
    z[3,6,2]  R1197     -5.2161026000976562e-01
    z[3,6,2]  R1198     3.4443494677543640e-01
    z[3,6,2]  R1199     2.2141848504543304e-01
    z[3,6,2]  R1200     1.4933940954506397e-02
    z[3,6,2]  R1201     -1.5962953865528107e-01
    z[3,6,2]  R1202     3.8431543856859207e-02
    z[3,6,2]  R1203     0.095056913793087
    z[3,6,2]  R1204     -9.1186009347438812e-02
    z[3,6,2]  R1205     2.2850561141967773e-01
    z[3,6,2]  R1206     1.8350470066070557e-01
    z[3,6,2]  R1207     -1.0992185026407242e-01
    z[3,6,2]  R1208     -6.4968854188919067e-02
    z[3,6,2]  R1209     1.5266297757625580e-01
    z[3,6,2]  R1210     0.0628947913646698
    z[3,6,2]  R1211     -1.3236106932163239e-01
    z[3,6,2]  R1212     1.4494094066321850e-02
    z[3,6,2]  R1213     2.4858203530311584e-01
    z[3,6,2]  R1214     -9.9425628781318665e-02
    z[3,6,2]  R1215     -4.5960783958435059e-01
    z[3,6,2]  R1216     -1.3062451779842377e-01
    z[3,6,2]  R1217     2.0609753206372261e-02
    z[3,6,2]  R1218     -1.2111578881740570e-01
    z[3,6,2]  R1219     -5.5107390880584717e-01
    z[3,6,2]  R1220     -6.5184015035629272e-01
    z[3,6,2]  R1221     1.5165668725967407e-01
    z[3,6,2]  R1222     9.4467557966709137e-02
    z[3,6,2]  R1223     3.7212669849395752e-01
    z[3,6,2]  R1224     0.510319173336029
    z[3,6,2]  R1225     -7.9994976520538330e-01
    z[3,6,2]  R1226     -2.0820085704326630e-01
    z[3,6,2]  R1227     -2.5144013762474060e-01
    z[3,6,2]  R1228     -4.7872957587242126e-01
    z[3,6,2]  R1229     3.4862619638442993e-01
    z[3,6,2]  R1230     -4.0366011857986450e-01
    z[3,6,2]  R1231     -1.7312115430831909e-01
    z[3,6,2]  R1232     -3.5301384329795837e-01
    z[3,6,2]  R1233     -3.4765001386404037e-02
    z[3,6,2]  R1234     4.2130580544471741e-01
    z[3,6,2]  R1235     -5.7477647066116333e-01
    z[3,6,2]  R1236     -0.645080029964447
    z[3,6,2]  R1237     -5.4246175289154053e-01
    z[3,6,2]  R1238     -1.1096552014350891e-01
    z[3,6,2]  R1239     -2.7713960409164429e-01
    z[3,6,2]  R1240     1.6731685400009155e-01
    z[3,6,2]  R1241     -5.4264806210994720e-02
    z[3,6,2]  R1242     -2.9492408037185669e-01
    z[3,6,2]  R1243     -5.9931054711341858e-02
    z[3,6,2]  R1244     5.0907637923955917e-02
    z[3,6,2]  R1245     -5.9057138860225677e-02
    z[3,6,2]  R1246     1.0383627563714981e-01
    z[3,6,2]  R1247     -4.1855287551879883e-01
    z[3,6,2]  R1248     -2.0485353469848633e-01
    z[3,6,2]  R1249     1.7963831126689911e-01
    z[3,6,2]  R1250     -3.7469189614057541e-02
    z[3,6,2]  R1251     -2.6761874556541443e-01
    z[3,6,2]  R1252     -3.3364719152450562e-01
    z[3,6,2]  R1253     3.4020170569419861e-02
    z[3,6,2]  R1254     1.9581666216254234e-02
    z[3,6,2]  R1255     2.5441735982894897e-02
    z[3,6,2]  R1256     -0.199344664812088
    z[3,6,2]  R1257     4.2731454968452454e-01
    z[3,6,2]  R1258     2.1485167741775513e-01
    z[3,6,2]  R1259     -3.7014293670654297e-01
    z[3,6,2]  R1260     3.8449708372354507e-02
    z[3,6,2]  R1261     -2.8615200892090797e-02
    z[3,6,2]  R1262     -3.9972978830337524e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1136     -1
    z[3,6,3]  R1137     1
    z[3,6,3]  R1144     4.3109700083732605e-01
    z[3,6,3]  R1145     6.4160728454589844e-01
    z[3,6,3]  R1146     2.4229782819747925e-01
    z[3,6,3]  R1147     5.0953966379165649e-01
    z[3,6,3]  R1148     4.9407321214675903e-01
    z[3,6,3]  R1149     3.6014896631240845e-01
    z[3,6,3]  R1150     -1.5400671958923340e-01
    z[3,6,3]  R1151     -2.0644627511501312e-02
    z[3,6,3]  R1152     7.1278929710388184e-01
    z[3,6,3]  R1153     5.4631787538528442e-01
    z[3,6,3]  R1154     1.4938473701477051e-01
    z[3,6,3]  R1155     -4.2482399940490723e-01
    z[3,6,3]  R1156     -0.322973370552063
    z[3,6,3]  R1157     -5.8784484863281250e-01
    z[3,6,3]  R1158     -0.518854558467865
    z[3,6,3]  R1159     -7.3962485790252686e-01
    z[3,6,3]  R1160     -1.8000417947769165e-01
    z[3,6,3]  R1161     1.7879299819469452e-01
    z[3,6,3]  R1162     4.8344683647155762e-01
    z[3,6,3]  R1163     1.3597738742828369e-01
    z[3,6,3]  R1164     8.8223300874233246e-02
    z[3,6,3]  R1165     7.8663372993469238e-01
    z[3,6,3]  R1166     -1.1369927227497101e-01
    z[3,6,3]  R1167     -4.2779183387756348e-01
    z[3,6,3]  R1168     1.4524123072624207e-01
    z[3,6,3]  R1169     -6.0591280460357666e-01
    z[3,6,3]  R1170     3.6464402079582214e-01
    z[3,6,3]  R1171     4.4875079393386841e-01
    z[3,6,3]  R1172     5.4512494802474976e-01
    z[3,6,3]  R1173     -3.3907768130302429e-01
    z[3,6,3]  R1174     -2.9924616217613220e-01
    z[3,6,3]  R1175     -3.3888214826583862e-01
    z[3,6,3]  R1176     -5.9020549058914185e-01
    z[3,6,3]  R1177     -2.7884083986282349e-01
    z[3,6,3]  R1178     -5.5373167991638184e-01
    z[3,6,3]  R1179     -1.9600987434387207e-01
    z[3,6,3]  R1180     -3.7111577391624451e-01
    z[3,6,3]  R1181     2.6010829210281372e-01
    z[3,6,3]  R1182     8.1559962034225464e-01
    z[3,6,3]  R1183     1.2610229849815369e-01
    z[3,6,3]  R1184     9.3165948987007141e-02
    z[3,6,3]  R1185     -4.9079051613807678e-01
    z[3,6,3]  R1186     -4.9664461612701416e-01
    z[3,6,3]  R1187     3.9586505293846130e-01
    z[3,6,3]  R1188     2.1753889322280884e-01
    z[3,6,3]  R1189     -5.1467999815940857e-02
    z[3,6,3]  R1190     1.1947729438543320e-01
    z[3,6,3]  R1191     1.1300613731145859e-01
    z[3,6,3]  R1192     -3.8399152457714081e-02
    z[3,6,3]  R1193     3.9864072203636169e-01
    z[3,6,3]  R1194     -0.0781896784901619
    z[3,6,3]  R1195     5.0997996330261230e-01
    z[3,6,3]  R1196     -0.0290201585739851
    z[3,6,3]  R1197     3.3412650227546692e-02
    z[3,6,3]  R1198     6.9710515439510345e-02
    z[3,6,3]  R1199     3.3124664425849915e-01
    z[3,6,3]  R1200     9.6823759377002716e-02
    z[3,6,3]  R1201     2.7094164490699768e-01
    z[3,6,3]  R1202     1.2503567337989807e-01
    z[3,6,3]  R1203     1.2436323612928391e-01
    z[3,6,3]  R1204     -2.3279446363449097e-01
    z[3,6,3]  R1205     -5.4520197212696075e-02
    z[3,6,3]  R1206     -1.1272186040878296e-01
    z[3,6,3]  R1207     -3.9822015166282654e-01
    z[3,6,3]  R1208     1.9771383702754974e-01
    z[3,6,3]  R1209     -3.5733717679977417e-01
    z[3,6,3]  R1210     9.8374977707862854e-02
    z[3,6,3]  R1211     4.0437778830528259e-01
    z[3,6,3]  R1212     3.5644698143005371e-01
    z[3,6,3]  R1213     -3.9706024527549744e-01
    z[3,6,3]  R1214     2.9846101999282837e-01
    z[3,6,3]  R1215     2.7269285917282104e-01
    z[3,6,3]  R1216     1.0264895856380463e-01
    z[3,6,3]  R1217     2.5535422563552856e-01
    z[3,6,3]  R1218     4.0238106250762939e-01
    z[3,6,3]  R1219     -8.0770663917064667e-03
    z[3,6,3]  R1220     7.5806421227753162e-03
    z[3,6,3]  R1221     -1.4889647066593170e-01
    z[3,6,3]  R1222     1.0548835247755051e-01
    z[3,6,3]  R1223     -1.6698397696018219e-02
    z[3,6,3]  R1224     -3.6903306841850281e-01
    z[3,6,3]  R1225     3.1129187345504761e-01
    z[3,6,3]  R1226     2.8346312046051025e-01
    z[3,6,3]  R1227     7.2360301017761230e-01
    z[3,6,3]  R1228     4.1686362028121948e-01
    z[3,6,3]  R1229     1.5570640563964844e-01
    z[3,6,3]  R1230     1.2262795865535736e-01
    z[3,6,3]  R1231     -1.3377287983894348e-01
    z[3,6,3]  R1232     1.1306324601173401e-01
    z[3,6,3]  R1233     5.3718948364257812e-01
    z[3,6,3]  R1234     -0.571797788143158
    z[3,6,3]  R1235     2.1838736534118652e-01
    z[3,6,3]  R1236     3.0689904093742371e-01
    z[3,6,3]  R1237     6.3965070247650146e-01
    z[3,6,3]  R1238     5.1850110292434692e-01
    z[3,6,3]  R1239     5.0610125064849854e-01
    z[3,6,3]  R1240     2.2512586414813995e-01
    z[3,6,3]  R1241     5.3207403421401978e-01
    z[3,6,3]  R1242     6.9865804910659790e-01
    z[3,6,3]  R1243     -2.8843320906162262e-02
    z[3,6,3]  R1244     4.2975005507469177e-01
    z[3,6,3]  R1245     3.2536211609840393e-01
    z[3,6,3]  R1246     5.2024662494659424e-01
    z[3,6,3]  R1247     -1.0241288691759109e-01
    z[3,6,3]  R1248     0.801220178604126
    z[3,6,3]  R1249     4.1895386576652527e-01
    z[3,6,3]  R1250     2.0774005353450775e-01
    z[3,6,3]  R1251     2.7850806713104248e-01
    z[3,6,3]  R1252     -1.0500277578830719e-01
    z[3,6,3]  R1253     -3.9494130760431290e-02
    z[3,6,3]  R1254     -2.1544608473777771e-01
    z[3,6,3]  R1255     -7.8749559819698334e-02
    z[3,6,3]  R1256     8.2119709253311157e-01
    z[3,6,3]  R1257     -5.1762568950653076e-01
    z[3,6,3]  R1258     1.3576522469520569e-01
    z[3,6,3]  R1259     0.0986611545085907
    z[3,6,3]  R1260     7.8905093669891357e-01
    z[3,6,3]  R1261     -2.1489325165748596e-01
    z[3,6,3]  R1262     -4.4135209918022156e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1138     -1
    z[3,6,4]  R1139     1
    z[3,6,4]  R1144     7.7099494636058807e-02
    z[3,6,4]  R1145     1.4336153864860535e-01
    z[3,6,4]  R1146     -2.2197237610816956e-01
    z[3,6,4]  R1147     -2.4536329507827759e-01
    z[3,6,4]  R1148     -4.9715104699134827e-01
    z[3,6,4]  R1149     -4.2462694644927979e-01
    z[3,6,4]  R1150     -1.4687924087047577e-01
    z[3,6,4]  R1151     -2.6961660385131836e-01
    z[3,6,4]  R1152     -3.5215571522712708e-01
    z[3,6,4]  R1153     0.305738627910614
    z[3,6,4]  R1154     3.1410478055477142e-02
    z[3,6,4]  R1155     3.0677413940429688e-01
    z[3,6,4]  R1156     3.3142006397247314e-01
    z[3,6,4]  R1157     3.7239551544189453e-01
    z[3,6,4]  R1158     -1.5976226329803467e-01
    z[3,6,4]  R1159     3.6165577173233032e-01
    z[3,6,4]  R1160     3.3996206521987915e-01
    z[3,6,4]  R1161     3.0345523357391357e-01
    z[3,6,4]  R1162     -1.5989659726619720e-01
    z[3,6,4]  R1163     -3.4453293681144714e-01
    z[3,6,4]  R1164     -1.4251527190208435e-01
    z[3,6,4]  R1165     -2.1376316249370575e-01
    z[3,6,4]  R1166     -3.2532259821891785e-01
    z[3,6,4]  R1167     0.474231094121933
    z[3,6,4]  R1168     -4.9816173315048218e-01
    z[3,6,4]  R1169     3.1092768907546997e-01
    z[3,6,4]  R1170     5.5697995424270630e-01
    z[3,6,4]  R1171     2.6597961783409119e-01
    z[3,6,4]  R1172     3.0822345614433289e-01
    z[3,6,4]  R1173     -4.6573806554079056e-02
    z[3,6,4]  R1174     -1.8613596260547638e-01
    z[3,6,4]  R1175     4.7604110091924667e-02
    z[3,6,4]  R1176     -1.3970064930617809e-02
    z[3,6,4]  R1177     3.3509659767150879e-01
    z[3,6,4]  R1178     4.5216381549835205e-01
    z[3,6,4]  R1179     4.3756440281867981e-01
    z[3,6,4]  R1180     3.0622169375419617e-01
    z[3,6,4]  R1181     -3.3020820468664169e-02
    z[3,6,4]  R1182     -4.0312924981117249e-01
    z[3,6,4]  R1183     2.3207981884479523e-01
    z[3,6,4]  R1184     1.8537633121013641e-01
    z[3,6,4]  R1185     5.0928640365600586e-01
    z[3,6,4]  R1186     -1.3969862461090088e-01
    z[3,6,4]  R1187     3.4669709205627441e-01
    z[3,6,4]  R1188     -1.7271824181079865e-01
    z[3,6,4]  R1189     3.9200261235237122e-02
    z[3,6,4]  R1190     9.2002548277378082e-02
    z[3,6,4]  R1191     -1.8937504291534424e-01
    z[3,6,4]  R1192     -1.4360065758228302e-01
    z[3,6,4]  R1193     -2.8094735741615295e-01
    z[3,6,4]  R1194     -2.1369270980358124e-02
    z[3,6,4]  R1195     3.4329418092966080e-02
    z[3,6,4]  R1196     -6.6291856765747070e-01
    z[3,6,4]  R1197     -4.8803728818893433e-01
    z[3,6,4]  R1198     -1.5790884196758270e-01
    z[3,6,4]  R1199     -5.5078315734863281e-01
    z[3,6,4]  R1200     -8.3766520023345947e-02
    z[3,6,4]  R1201     -2.1506768465042114e-01
    z[3,6,4]  R1202     2.0711828768253326e-01
    z[3,6,4]  R1203     -3.0013337731361389e-02
    z[3,6,4]  R1204     2.7905574440956116e-01
    z[3,6,4]  R1205     -4.8334106802940369e-02
    z[3,6,4]  R1206     -3.0210144817829132e-02
    z[3,6,4]  R1207     5.2105122804641724e-01
    z[3,6,4]  R1208     -1.3227945193648338e-02
    z[3,6,4]  R1209     2.3158590495586395e-01
    z[3,6,4]  R1210     2.3669071495532990e-01
    z[3,6,4]  R1211     4.9811866134405136e-02
    z[3,6,4]  R1212     1.8622530996799469e-01
    z[3,6,4]  R1213     2.2148312628269196e-01
    z[3,6,4]  R1214     3.5426761955022812e-02
    z[3,6,4]  R1215     -2.9519531130790710e-01
    z[3,6,4]  R1216     4.0074518322944641e-01
    z[3,6,4]  R1217     -2.4200105667114258e-01
    z[3,6,4]  R1218     1.2927709519863129e-01
    z[3,6,4]  R1219     2.2059883177280426e-01
    z[3,6,4]  R1220     2.1980078890919685e-02
    z[3,6,4]  R1221     1.5698119997978210e-01
    z[3,6,4]  R1222     -7.6411046087741852e-02
    z[3,6,4]  R1223     -1.6664180159568787e-01
    z[3,6,4]  R1224     -3.8733837008476257e-01
    z[3,6,4]  R1225     -7.0992313325405121e-02
    z[3,6,4]  R1226     3.9768660068511963e-01
    z[3,6,4]  R1227     -1.9679825007915497e-01
    z[3,6,4]  R1228     -0.302804559469223
    z[3,6,4]  R1229     -3.0368554592132568e-01
    z[3,6,4]  R1230     1.0551684349775314e-01
    z[3,6,4]  R1231     -1.9355788826942444e-02
    z[3,6,4]  R1232     6.2445417046546936e-02
    z[3,6,4]  R1233     -1.5688581764698029e-01
    z[3,6,4]  R1234     -1.8737266957759857e-01
    z[3,6,4]  R1235     1.3259534537792206e-01
    z[3,6,4]  R1236     -1.9866687059402466e-01
    z[3,6,4]  R1237     -3.0559748411178589e-01
    z[3,6,4]  R1238     1.3698628544807434e-01
    z[3,6,4]  R1239     -5.0602819770574570e-02
    z[3,6,4]  R1240     -1.5582096576690674e-01
    z[3,6,4]  R1241     -4.6497333049774170e-01
    z[3,6,4]  R1242     6.6649354994297028e-02
    z[3,6,4]  R1243     1.2416181713342667e-01
    z[3,6,4]  R1244     3.8874413818120956e-02
    z[3,6,4]  R1245     1.6988384723663330e-01
    z[3,6,4]  R1246     -6.0564088821411133e-01
    z[3,6,4]  R1247     5.5132603645324707e-01
    z[3,6,4]  R1248     -6.8614810705184937e-02
    z[3,6,4]  R1249     -0.664197564125061
    z[3,6,4]  R1250     -4.2081409692764282e-01
    z[3,6,4]  R1251     -1.2498825043439865e-01
    z[3,6,4]  R1252     1.0058642923831940e-01
    z[3,6,4]  R1253     4.0197573602199554e-02
    z[3,6,4]  R1254     8.1931173801422119e-02
    z[3,6,4]  R1255     4.4640928506851196e-02
    z[3,6,4]  R1256     -1.0576204210519791e-01
    z[3,6,4]  R1257     6.1329182237386703e-02
    z[3,6,4]  R1258     6.8140506744384766e-02
    z[3,6,4]  R1259     1.2142547965049744e-01
    z[3,6,4]  R1260     -1.1520221084356308e-01
    z[3,6,4]  R1261     -1.8276037275791168e-01
    z[3,6,4]  R1262     2.3541533946990967e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1140     -1
    z[3,6,5]  R1141     1
    z[3,6,5]  R1144     -2.2628612816333771e-01
    z[3,6,5]  R1145     2.8383467346429825e-02
    z[3,6,5]  R1146     2.7258491516113281e-01
    z[3,6,5]  R1147     1.6982145607471466e-01
    z[3,6,5]  R1148     3.2328939437866211e-01
    z[3,6,5]  R1149     1.5535542368888855e-01
    z[3,6,5]  R1150     8.0995744466781616e-01
    z[3,6,5]  R1151     7.9695820808410645e-01
    z[3,6,5]  R1152     -2.2832190617918968e-02
    z[3,6,5]  R1153     2.9667469859123230e-01
    z[3,6,5]  R1154     -3.6605009436607361e-01
    z[3,6,5]  R1155     -2.8311079740524292e-01
    z[3,6,5]  R1156     7.1407124400138855e-02
    z[3,6,5]  R1157     -1.0312648862600327e-01
    z[3,6,5]  R1158     -5.3364062309265137e-01
    z[3,6,5]  R1159     -1.2207627296447754e-01
    z[3,6,5]  R1160     -2.5423637032508850e-01
    z[3,6,5]  R1161     -2.7033188939094543e-01
    z[3,6,5]  R1162     -2.3554079234600067e-01
    z[3,6,5]  R1163     -3.5050097107887268e-01
    z[3,6,5]  R1164     5.8041650056838989e-01
    z[3,6,5]  R1165     3.7163376808166504e-01
    z[3,6,5]  R1166     -1.5019933879375458e-01
    z[3,6,5]  R1167     3.3966881036758423e-01
    z[3,6,5]  R1168     -6.6731266677379608e-02
    z[3,6,5]  R1169     2.8604209423065186e-01
    z[3,6,5]  R1170     3.7263652682304382e-01
    z[3,6,5]  R1171     7.8697368502616882e-02
    z[3,6,5]  R1172     1.0498242825269699e-01
    z[3,6,5]  R1173     5.0448134541511536e-02
    z[3,6,5]  R1174     3.5628405213356018e-01
    z[3,6,5]  R1175     4.9841940402984619e-01
    z[3,6,5]  R1176     2.3097988963127136e-01
    z[3,6,5]  R1177     3.3193412423133850e-01
    z[3,6,5]  R1178     -9.6335709095001221e-02
    z[3,6,5]  R1179     1.0548584163188934e-02
    z[3,6,5]  R1180     -4.0202800184488297e-02
    z[3,6,5]  R1181     0.355111688375473
    z[3,6,5]  R1182     -1.7216829583048820e-02
    z[3,6,5]  R1183     3.4412688016891479e-01
    z[3,6,5]  R1184     5.2093285322189331e-01
    z[3,6,5]  R1185     -1.3080455362796783e-01
    z[3,6,5]  R1186     -1.1704389750957489e-01
    z[3,6,5]  R1187     1.8582293391227722e-01
    z[3,6,5]  R1188     -1.4288491010665894e-01
    z[3,6,5]  R1189     1.0768998414278030e-01
    z[3,6,5]  R1190     -2.9755065217614174e-02
    z[3,6,5]  R1191     1.2650847434997559e-01
    z[3,6,5]  R1192     6.8607471883296967e-02
    z[3,6,5]  R1193     3.4096702933311462e-01
    z[3,6,5]  R1194     2.5523445010185242e-01
    z[3,6,5]  R1195     -2.1300630643963814e-02
    z[3,6,5]  R1196     4.8581507802009583e-01
    z[3,6,5]  R1197     5.2268964052200317e-01
    z[3,6,5]  R1198     -1.1703015118837357e-01
    z[3,6,5]  R1199     4.3361055850982666e-01
    z[3,6,5]  R1200     -4.6812698245048523e-01
    z[3,6,5]  R1201     1.3619804382324219e-01
    z[3,6,5]  R1202     -2.6303318142890930e-01
    z[3,6,5]  R1203     3.7050571292638779e-02
    z[3,6,5]  R1204     -1.2478940188884735e-01
    z[3,6,5]  R1205     8.6288809776306152e-02
    z[3,6,5]  R1206     -1.6528807580471039e-01
    z[3,6,5]  R1207     3.5488995909690857e-01
    z[3,6,5]  R1208     1.9388712942600250e-01
    z[3,6,5]  R1209     -9.8234914243221283e-02
    z[3,6,5]  R1210     6.5929156541824341e-01
    z[3,6,5]  R1211     -1.6213320195674896e-01
    z[3,6,5]  R1212     3.0738005042076111e-01
    z[3,6,5]  R1213     3.4320649504661560e-01
    z[3,6,5]  R1214     -1.9283334910869598e-01
    z[3,6,5]  R1215     6.1310482025146484e-01
    z[3,6,5]  R1216     2.9591289162635803e-01
    z[3,6,5]  R1217     -1.7603531479835510e-01
    z[3,6,5]  R1218     8.6186133325099945e-02
    z[3,6,5]  R1219     2.8385239839553833e-01
    z[3,6,5]  R1220     2.4412062764167786e-01
    z[3,6,5]  R1221     5.2332830429077148e-01
    z[3,6,5]  R1222     4.1580680012702942e-01
    z[3,6,5]  R1223     -1.2333630770444870e-01
    z[3,6,5]  R1224     -0.0711502805352211
    z[3,6,5]  R1225     4.6585026383399963e-01
    z[3,6,5]  R1226     3.6016803979873657e-01
    z[3,6,5]  R1227     3.2151695340871811e-02
    z[3,6,5]  R1228     -4.0721049904823303e-01
    z[3,6,5]  R1229     1.1348453909158707e-01
    z[3,6,5]  R1230     -3.0042484402656555e-01
    z[3,6,5]  R1231     -9.7968660295009613e-02
    z[3,6,5]  R1232     -2.2801715135574341e-01
    z[3,6,5]  R1233     3.3695498108863831e-01
    z[3,6,5]  R1234     -1.9032275676727295e-01
    z[3,6,5]  R1235     2.3500597476959229e-01
    z[3,6,5]  R1236     0.0966220423579216
    z[3,6,5]  R1237     6.5530523657798767e-02
    z[3,6,5]  R1238     4.1757243871688843e-01
    z[3,6,5]  R1239     3.0980497598648071e-01
    z[3,6,5]  R1240     3.6398828029632568e-01
    z[3,6,5]  R1241     3.1032985448837280e-01
    z[3,6,5]  R1242     4.4034352898597717e-01
    z[3,6,5]  R1243     2.8430068492889404e-01
    z[3,6,5]  R1244     2.5482922792434692e-01
    z[3,6,5]  R1245     -1.6160987317562103e-01
    z[3,6,5]  R1246     2.4246735870838165e-01
    z[3,6,5]  R1247     -1.6973756253719330e-01
    z[3,6,5]  R1248     3.9245158433914185e-01
    z[3,6,5]  R1249     -7.2402499616146088e-02
    z[3,6,5]  R1250     -2.5813108682632446e-01
    z[3,6,5]  R1251     -2.4999319016933441e-01
    z[3,6,5]  R1252     -1.6648904979228973e-01
    z[3,6,5]  R1253     -3.2943961024284363e-01
    z[3,6,5]  R1254     -3.5980053246021271e-02
    z[3,6,5]  R1255     -3.1049215793609619e-01
    z[3,6,5]  R1256     2.8177076578140259e-01
    z[3,6,5]  R1257     -1.1477879434823990e-01
    z[3,6,5]  R1258     2.0424258708953857e-01
    z[3,6,5]  R1259     6.9125302135944366e-02
    z[3,6,5]  R1260     -7.8146345913410187e-02
    z[3,6,5]  R1261     -3.4167268872261047e-01
    z[3,6,5]  R1262     -3.8538447022438049e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1142     -1
    z[3,6,6]  R1143     1
    z[3,6,6]  R1144     -7.3401778936386108e-01
    z[3,6,6]  R1145     2.3921218235045671e-03
    z[3,6,6]  R1146     -7.6444578170776367e-01
    z[3,6,6]  R1147     5.1944744586944580e-01
    z[3,6,6]  R1148     3.3187377452850342e-01
    z[3,6,6]  R1149     -5.5719721317291260e-01
    z[3,6,6]  R1150     -4.6325522661209106e-01
    z[3,6,6]  R1151     3.1263187527656555e-01
    z[3,6,6]  R1152     -1.7332918941974640e-01
    z[3,6,6]  R1153     -1.6482527554035187e-01
    z[3,6,6]  R1154     3.8398674130439758e-01
    z[3,6,6]  R1155     2.4408011138439178e-01
    z[3,6,6]  R1156     1.8971693515777588e-01
    z[3,6,6]  R1157     1.6159202158451080e-01
    z[3,6,6]  R1158     0.0920364037156105
    z[3,6,6]  R1159     1.8101497553288937e-03
    z[3,6,6]  R1160     -2.6887786388397217e-01
    z[3,6,6]  R1161     2.7434840798377991e-01
    z[3,6,6]  R1162     -3.2288864254951477e-01
    z[3,6,6]  R1163     1.9168620929121971e-02
    z[3,6,6]  R1164     2.2632595896720886e-01
    z[3,6,6]  R1165     1.8007853627204895e-01
    z[3,6,6]  R1166     -1.4954796433448792e-01
    z[3,6,6]  R1167     1.9748227298259735e-01
    z[3,6,6]  R1168     -5.3021764755249023e-01
    z[3,6,6]  R1169     -8.2450456917285919e-02
    z[3,6,6]  R1170     -0.296037882566452
    z[3,6,6]  R1171     -3.0968451872467995e-02
    z[3,6,6]  R1172     -2.3845938965678215e-02
    z[3,6,6]  R1173     -3.0224621295928955e-02
    z[3,6,6]  R1174     -3.0544428154826164e-02
    z[3,6,6]  R1175     -1.0236737877130508e-01
    z[3,6,6]  R1176     -1.8589726090431213e-01
    z[3,6,6]  R1177     2.1918751299381256e-03
    z[3,6,6]  R1178     0.079471655189991
    z[3,6,6]  R1179     1.1661176383495331e-01
    z[3,6,6]  R1180     -4.5812937617301941e-01
    z[3,6,6]  R1181     -9.5765674486756325e-03
    z[3,6,6]  R1182     1.1679705977439880e-01
    z[3,6,6]  R1183     -1.1486873030662537e-01
    z[3,6,6]  R1184     -4.6692779660224915e-01
    z[3,6,6]  R1185     1.4410948380827904e-02
    z[3,6,6]  R1186     -2.3125639557838440e-01
    z[3,6,6]  R1187     -2.1750238537788391e-01
    z[3,6,6]  R1188     3.6757946014404297e-01
    z[3,6,6]  R1189     1.0941742360591888e-01
    z[3,6,6]  R1190     2.4398863315582275e-02
    z[3,6,6]  R1191     0.0702752098441124
    z[3,6,6]  R1192     -2.9970180243253708e-02
    z[3,6,6]  R1193     1.3765922188758850e-01
    z[3,6,6]  R1194     -3.8214033842086792e-01
    z[3,6,6]  R1195     -2.1635919809341431e-01
    z[3,6,6]  R1196     1.9490335881710052e-01
    z[3,6,6]  R1197     -2.4053165316581726e-01
    z[3,6,6]  R1198     3.0572479963302612e-01
    z[3,6,6]  R1199     -1.2226716615259647e-02
    z[3,6,6]  R1200     -1.4560225419700146e-02
    z[3,6,6]  R1201     4.7664329409599304e-01
    z[3,6,6]  R1202     4.6030825376510620e-01
    z[3,6,6]  R1203     -2.3105631768703461e-01
    z[3,6,6]  R1204     -4.4470822811126709e-01
    z[3,6,6]  R1205     1.3618775643408298e-02
    z[3,6,6]  R1206     -0.049640953540802
    z[3,6,6]  R1207     -0.259581595659256
    z[3,6,6]  R1208     -3.6433029174804688e-01
    z[3,6,6]  R1209     2.9331985116004944e-01
    z[3,6,6]  R1210     1.3550363481044769e-01
    z[3,6,6]  R1211     1.5716609358787537e-01
    z[3,6,6]  R1212     0.46355140209198
    z[3,6,6]  R1213     2.0093612372875214e-02
    z[3,6,6]  R1214     1.1167913675308228e-02
    z[3,6,6]  R1215     6.5813146531581879e-02
    z[3,6,6]  R1216     1.8022309243679047e-01
    z[3,6,6]  R1217     9.1388203203678131e-02
    z[3,6,6]  R1218     5.4702490568161011e-01
    z[3,6,6]  R1219     1.7998608946800232e-01
    z[3,6,6]  R1220     5.0963789224624634e-01
    z[3,6,6]  R1221     1.6429116949439049e-02
    z[3,6,6]  R1222     -2.5223836302757263e-01
    z[3,6,6]  R1223     3.8169443607330322e-01
    z[3,6,6]  R1224     -8.0177947878837585e-02
    z[3,6,6]  R1225     0.0874348059296608
    z[3,6,6]  R1226     1.4457820355892181e-01
    z[3,6,6]  R1227     3.1224694848060608e-01
    z[3,6,6]  R1228     2.7112990617752075e-01
    z[3,6,6]  R1229     2.1874293684959412e-01
    z[3,6,6]  R1230     -2.8557786345481873e-01
    z[3,6,6]  R1231     -1.9834528863430023e-01
    z[3,6,6]  R1232     -5.3242433071136475e-01
    z[3,6,6]  R1233     3.0272516608238220e-01
    z[3,6,6]  R1234     -1.3332915306091309e-01
    z[3,6,6]  R1235     2.7723437547683716e-01
    z[3,6,6]  R1236     5.3015863895416260e-01
    z[3,6,6]  R1237     6.3868030905723572e-02
    z[3,6,6]  R1238     9.1345183551311493e-02
    z[3,6,6]  R1239     -6.0760229825973511e-01
    z[3,6,6]  R1240     -2.4147087242454290e-04
    z[3,6,6]  R1241     -5.2079045772552490e-01
    z[3,6,6]  R1242     -1.7207440733909607e-01
    z[3,6,6]  R1243     -5.1508295536041260e-01
    z[3,6,6]  R1244     3.1199935078620911e-01
    z[3,6,6]  R1245     3.9095902442932129e-01
    z[3,6,6]  R1246     -2.7082201838493347e-01
    z[3,6,6]  R1247     -2.7292063832283020e-01
    z[3,6,6]  R1248     -1.0957321152091026e-02
    z[3,6,6]  R1249     -2.5969070196151733e-01
    z[3,6,6]  R1250     -1.3700519502162933e-01
    z[3,6,6]  R1251     -4.0275490283966064e-01
    z[3,6,6]  R1252     -4.9255305528640747e-01
    z[3,6,6]  R1253     -2.0176558196544647e-01
    z[3,6,6]  R1254     -0.392668753862381
    z[3,6,6]  R1255     2.4300108850002289e-01
    z[3,6,6]  R1256     -0.00647188164293766
    z[3,6,6]  R1257     5.4791235923767090e-01
    z[3,6,6]  R1258     0.568831205368042
    z[3,6,6]  R1259     -2.7207210659980774e-01
    z[3,6,6]  R1260     4.0409117937088013e-01
    z[3,6,6]  R1261     -4.2171877622604370e-01
    z[3,6,6]  R1262     -1.4311835169792175e-02
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1263     -1
    z[6,3,0]  R1264     1
    z[6,3,0]  R1277     -9.0638458728790283e-01
    z[6,3,0]  R1278     -8.2799595594406128e-01
    z[6,3,0]  R1279     -7.8493207693099976e-01
    z[6,3,0]  R1280     -7.0772647857666016e-01
    z[6,3,0]  R1281     -0.819678008556366
    z[6,3,0]  R1282     -6.6300272941589355e-01
    z[6,3,0]  R1283     -8.1264919042587280e-01
    z[6,3,0]  R1284     -6.8940824270248413e-01
    z[6,3,0]  R1285     -8.8037103414535522e-01
    z[6,3,0]  R1286     2.9375693202018738e-01
    z[6,3,0]  R1287     -3.8623297587037086e-04
    z[6,3,0]  R1288     4.9018543958663940e-01
    z[6,3,0]  R1289     4.9586838483810425e-01
    z[6,3,0]  R1290     4.3103596568107605e-01
    z[6,3,0]  R1291     2.0347057282924652e-01
    z[6,3,0]  R1292     3.9923486113548279e-01
    z[6,3,0]  R1293     0.421084463596344
    z[6,3,0]  R1294     2.6942405104637146e-01
    z[6,3,0]  R1295     3.8349777460098267e-01
    z[6,3,0]  R1296     3.8672599196434021e-01
    z[6,3,0]  R1297     0.599850058555603
    z[6,3,0]  R1298     3.9805805683135986e-01
    z[6,3,0]  R1299     9.7217820584774017e-02
    z[6,3,0]  R1300     3.7836232781410217e-01
    z[6,3,0]  R1301     2.1848320960998535e-01
    z[6,3,0]  R1302     4.0968227386474609e-01
    z[6,3,0]  R1303     5.7834142446517944e-01
    z[6,3,0]  R1304     -4.1519635915756226e-01
    z[6,3,0]  R1305     -2.0829349756240845e-01
    z[6,3,0]  R1306     1.6713143885135651e-01
    z[6,3,0]  R1307     0.291344553232193
    z[6,3,0]  R1308     2.0175081491470337e-01
    z[6,3,0]  R1309     -1.8293541669845581e-01
    z[6,3,0]  R1310     -1.5737058222293854e-01
    z[6,3,0]  R1311     -7.6309749856591225e-03
    z[6,3,0]  R1312     -3.4955191612243652e-01
    z[6,3,0]  R1313     -4.1043874621391296e-01
    z[6,3,0]  R1314     1.1732964962720871e-01
    z[6,3,0]  R1315     -4.1289508342742920e-01
    z[6,3,0]  R1316     6.7198120057582855e-02
    z[6,3,0]  R1317     1.4178267121315002e-01
    z[6,3,0]  R1318     -3.6966481804847717e-01
    z[6,3,0]  R1319     4.9518829584121704e-01
    z[6,3,0]  R1320     -2.0473115146160126e-01
    z[6,3,0]  R1321     -8.2797199487686157e-01
    z[6,3,0]  R1322     0.617081344127655
    z[6,3,0]  R1323     5.0851190090179443e-01
    z[6,3,0]  R1324     3.9375400543212891e-01
    z[6,3,0]  R1325     0.809958279132843
    z[6,3,0]  R1326     8.5605132579803467e-01
    z[6,3,0]  R1327     -2.9784919694066048e-02
    z[6,3,0]  R1328     -0.286978155374527
    z[6,3,0]  R1329     1.6640554368495941e-01
    z[6,3,0]  R1330     7.2376525402069092e-01
    z[6,3,0]  R1331     -1.7412005364894867e-01
    z[6,3,0]  R1332     8.0571383237838745e-02
    z[6,3,0]  R1333     8.3700728416442871e-01
    z[6,3,0]  R1334     1.3343612849712372e-01
    z[6,3,0]  R1335     -6.4536012709140778e-02
    z[6,3,0]  R1336     4.4132387638092041e-01
    z[6,3,0]  R1337     6.9306713342666626e-01
    z[6,3,0]  R1338     -2.6543736457824707e-01
    z[6,3,0]  R1339     4.8704367876052856e-01
    z[6,3,0]  R1340     3.5728746652603149e-01
    z[6,3,0]  R1341     2.4972066283226013e-01
    z[6,3,0]  R1342     2.2820445895195007e-01
    z[6,3,0]  R1343     4.4021755456924438e-01
    z[6,3,0]  R1344     8.7229609489440918e-01
    z[6,3,0]  R1345     1.6437853872776031e-01
    z[6,3,0]  R1346     4.1851267218589783e-01
    z[6,3,0]  R1347     -9.3097686767578125e-02
    z[6,3,0]  R1348     0.0915379747748375
    z[6,3,0]  R1349     -0.0588078498840332
    z[6,3,0]  R1350     4.6570891141891479e-01
    z[6,3,0]  R1351     -3.0314895510673523e-01
    z[6,3,0]  R1352     3.5545620322227478e-01
    z[6,3,0]  R1353     -2.0369479060173035e-01
    z[6,3,0]  R1354     -1.8442565202713013e-01
    z[6,3,0]  R1355     4.4914808869361877e-01
    z[6,3,0]  R1356     5.8731153607368469e-02
    z[6,3,0]  R1357     0.0049970424734056
    z[6,3,0]  R1358     -3.4934845566749573e-01
    z[6,3,0]  R1359     -7.5006228685379028e-01
    z[6,3,0]  R1360     4.0946078300476074e-01
    z[6,3,0]  R1361     -1.1233063042163849e-01
    z[6,3,0]  R1362     7.2808766365051270e-01
    z[6,3,0]  R1363     -2.4780279025435448e-02
    z[6,3,0]  R1364     -3.3136874437332153e-02
    z[6,3,0]  R1365     3.3650982379913330e-01
    z[6,3,0]  R1366     3.7405374646186829e-01
    z[6,3,0]  R1367     -3.8403651118278503e-01
    z[6,3,0]  R1368     -5.9794867038726807e-01
    z[6,3,0]  R1369     -5.3884852677583694e-02
    z[6,3,0]  R1370     -5.6895685195922852e-01
    z[6,3,0]  R1371     -4.6248784661293030e-01
    z[6,3,0]  R1372     -5.1832705736160278e-01
    z[6,3,0]  R1373     0.127742201089859
    z[6,3,0]  R1374     1.5131257474422455e-01
    z[6,3,0]  R1375     -4.2566746473312378e-01
    z[6,3,0]  R1376     2.5695389509201050e-01
    z[6,3,0]  R1377     3.7997964024543762e-01
    z[6,3,0]  R1378     -1.9350335001945496e-01
    z[6,3,0]  R1379     -1.9371852278709412e-01
    z[6,3,0]  R1380     -1.5649942681193352e-02
    z[6,3,0]  R1381     -2.6204961538314819e-01
    z[6,3,0]  R1382     4.7014385461807251e-01
    z[6,3,0]  R1383     5.2563732862472534e-01
    z[6,3,0]  R1384     3.9286059141159058e-01
    z[6,3,0]  R1385     5.6286227703094482e-01
    z[6,3,0]  R1386     -1.9090999662876129e-01
    z[6,3,0]  R1387     7.5469031929969788e-02
    z[6,3,0]  R1388     9.2340342700481415e-02
    z[6,3,0]  R1389     -6.3228809833526611e-01
    z[6,3,0]  R1390     8.7768651545047760e-02
    z[6,3,0]  R1391     2.1279385685920715e-01
    z[6,3,0]  R1392     0.648888111114502
    z[6,3,0]  R1393     3.8861066102981567e-01
    z[6,3,0]  R1394     5.9374624490737915e-01
    z[6,3,0]  R1395     1.5713982284069061e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1265     -1
    z[6,3,1]  R1266     1
    z[6,3,1]  R1277     2.3567005991935730e-01
    z[6,3,1]  R1278     -4.1897028684616089e-02
    z[6,3,1]  R1279     2.8792524710297585e-02
    z[6,3,1]  R1280     -1.2074025720357895e-01
    z[6,3,1]  R1281     -8.2762926816940308e-02
    z[6,3,1]  R1282     -1.4048515260219574e-01
    z[6,3,1]  R1283     4.6277213841676712e-02
    z[6,3,1]  R1284     -1.1682908982038498e-01
    z[6,3,1]  R1285     -1.0781950503587723e-01
    z[6,3,1]  R1286     -2.0093406736850739e-01
    z[6,3,1]  R1287     -8.9190477132797241e-01
    z[6,3,1]  R1288     -3.7189406156539917e-01
    z[6,3,1]  R1289     -4.8617777228355408e-01
    z[6,3,1]  R1290     -5.5693954229354858e-01
    z[6,3,1]  R1291     -6.9330793619155884e-01
    z[6,3,1]  R1292     -7.2400510311126709e-01
    z[6,3,1]  R1293     8.9146637916564941e-01
    z[6,3,1]  R1294     9.2655897140502930e-01
    z[6,3,1]  R1295     8.8261890411376953e-01
    z[6,3,1]  R1296     0.881799578666687
    z[6,3,1]  R1297     -5.0700485706329346e-01
    z[6,3,1]  R1298     -7.7167344093322754e-01
    z[6,3,1]  R1299     -8.0269873142242432e-01
    z[6,3,1]  R1300     -3.3003348112106323e-01
    z[6,3,1]  R1301     -3.3140763640403748e-01
    z[6,3,1]  R1302     -7.5931972265243530e-01
    z[6,3,1]  R1303     -1.2345468252897263e-01
    z[6,3,1]  R1304     -7.6918292045593262e-01
    z[6,3,1]  R1305     -0.752150297164917
    z[6,3,1]  R1306     -7.9434764385223389e-01
    z[6,3,1]  R1307     -9.1375911235809326e-01
    z[6,3,1]  R1308     -7.7818918228149414e-01
    z[6,3,1]  R1309     -9.4941031932830811e-01
    z[6,3,1]  R1310     -9.4771158695220947e-01
    z[6,3,1]  R1311     -6.0370171070098877e-01
    z[6,3,1]  R1312     -8.1486070156097412e-01
    z[6,3,1]  R1313     -7.2885221242904663e-01
    z[6,3,1]  R1314     -6.8084597587585449e-01
    z[6,3,1]  R1315     -7.7136713266372681e-01
    z[6,3,1]  R1316     -7.2400116920471191e-01
    z[6,3,1]  R1317     -0.770193874835968
    z[6,3,1]  R1318     -8.5195004940032959e-01
    z[6,3,1]  R1319     4.2647279798984528e-02
    z[6,3,1]  R1320     -8.0612915754318237e-01
    z[6,3,1]  R1321     -3.8849323987960815e-01
    z[6,3,1]  R1322     -3.4533193707466125e-01
    z[6,3,1]  R1323     -5.2539217472076416e-01
    z[6,3,1]  R1324     -3.1653749942779541e-01
    z[6,3,1]  R1325     -3.4983004443347454e-03
    z[6,3,1]  R1326     0.0690355971455574
    z[6,3,1]  R1327     -8.1956321001052856e-01
    z[6,3,1]  R1328     -5.9959208965301514e-01
    z[6,3,1]  R1329     -7.6063059270381927e-02
    z[6,3,1]  R1330     -2.0901305973529816e-01
    z[6,3,1]  R1331     -4.9557766318321228e-01
    z[6,3,1]  R1332     -5.0943940877914429e-01
    z[6,3,1]  R1333     -2.6115508750081062e-02
    z[6,3,1]  R1334     7.8820818662643433e-01
    z[6,3,1]  R1335     9.4797450304031372e-01
    z[6,3,1]  R1336     5.7311809062957764e-01
    z[6,3,1]  R1337     -9.0785082429647446e-03
    z[6,3,1]  R1338     -5.7964098453521729e-01
    z[6,3,1]  R1339     -4.8482900857925415e-01
    z[6,3,1]  R1340     -1.7932601273059845e-01
    z[6,3,1]  R1341     -3.6394849419593811e-01
    z[6,3,1]  R1342     -0.682121753692627
    z[6,3,1]  R1343     -7.4453867971897125e-02
    z[6,3,1]  R1344     6.0457970947027206e-02
    z[6,3,1]  R1345     -0.321254700422287
    z[6,3,1]  R1346     -1.4761339128017426e-01
    z[6,3,1]  R1347     -7.9079437255859375e-01
    z[6,3,1]  R1348     -8.0034458637237549e-01
    z[6,3,1]  R1349     -8.2423675060272217e-01
    z[6,3,1]  R1350     -5.2353560924530029e-02
    z[6,3,1]  R1351     -5.6139910221099854e-01
    z[6,3,1]  R1352     -1.7574384808540344e-01
    z[6,3,1]  R1353     -4.8669952154159546e-01
    z[6,3,1]  R1354     0.811751663684845
    z[6,3,1]  R1355     0.639335036277771
    z[6,3,1]  R1356     7.7055817842483521e-01
    z[6,3,1]  R1357     -9.2000114917755127e-01
    z[6,3,1]  R1358     -8.1789934635162354e-01
    z[6,3,1]  R1359     -5.2259933948516846e-01
    z[6,3,1]  R1360     -0.166182741522789
    z[6,3,1]  R1361     -0.468726247549057
    z[6,3,1]  R1362     -1.8806332349777222e-01
    z[6,3,1]  R1363     8.7126356363296509e-01
    z[6,3,1]  R1364     4.3835404515266418e-01
    z[6,3,1]  R1365     7.1538448333740234e-01
    z[6,3,1]  R1366     5.4896432161331177e-01
    z[6,3,1]  R1367     -2.6050320267677307e-01
    z[6,3,1]  R1368     -2.4094755947589874e-01
    z[6,3,1]  R1369     -4.4638451933860779e-01
    z[6,3,1]  R1370     -2.0303604006767273e-01
    z[6,3,1]  R1371     -1.8426011502742767e-01
    z[6,3,1]  R1372     -0.243020698428154
    z[6,3,1]  R1373     1.4757326245307922e-01
    z[6,3,1]  R1374     4.0068429708480835e-01
    z[6,3,1]  R1375     -3.7591388821601868e-01
    z[6,3,1]  R1376     -4.4722664356231689e-01
    z[6,3,1]  R1377     -5.9642869234085083e-01
    z[6,3,1]  R1378     -6.8538486957550049e-01
    z[6,3,1]  R1379     -0.549904465675354
    z[6,3,1]  R1380     -6.5866059064865112e-01
    z[6,3,1]  R1381     -4.8701807856559753e-01
    z[6,3,1]  R1382     2.3313693702220917e-01
    z[6,3,1]  R1383     6.3290292024612427e-01
    z[6,3,1]  R1384     6.4746099710464478e-01
    z[6,3,1]  R1385     5.0144141912460327e-01
    z[6,3,1]  R1386     0.707349956035614
    z[6,3,1]  R1387     -7.4920213222503662e-01
    z[6,3,1]  R1388     -3.9429777860641479e-01
    z[6,3,1]  R1389     -6.5100133419036865e-01
    z[6,3,1]  R1390     4.4579941034317017e-01
    z[6,3,1]  R1391     -1.8676178157329559e-01
    z[6,3,1]  R1392     1.2372772395610809e-01
    z[6,3,1]  R1393     -1.3339424133300781e-01
    z[6,3,1]  R1394     6.0084593296051025e-01
    z[6,3,1]  R1395     6.8531692028045654e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1267     -1
    z[6,3,2]  R1268     1
    z[6,3,2]  R1277     4.8219002783298492e-02
    z[6,3,2]  R1278     2.4617350101470947e-01
    z[6,3,2]  R1279     0.0839306190609932
    z[6,3,2]  R1280     2.1931204199790955e-01
    z[6,3,2]  R1281     -1.4509050548076630e-01
    z[6,3,2]  R1282     -1.1842354387044907e-01
    z[6,3,2]  R1283     -3.0637830495834351e-01
    z[6,3,2]  R1284     -2.6090177893638611e-01
    z[6,3,2]  R1285     -1.3556927442550659e-01
    z[6,3,2]  R1286     -1.7798444628715515e-01
    z[6,3,2]  R1287     -5.5900290608406067e-02
    z[6,3,2]  R1288     -2.9828870296478271e-01
    z[6,3,2]  R1289     -1.3427162542939186e-02
    z[6,3,2]  R1290     4.1312953829765320e-01
    z[6,3,2]  R1291     -3.4522205591201782e-01
    z[6,3,2]  R1292     0.289383202791214
    z[6,3,2]  R1293     1.4852622523903847e-02
    z[6,3,2]  R1294     2.1137434244155884e-01
    z[6,3,2]  R1295     6.5856881439685822e-02
    z[6,3,2]  R1296     2.1253588795661926e-01
    z[6,3,2]  R1297     1.0035727173089981e-01
    z[6,3,2]  R1298     1.6829672455787659e-01
    z[6,3,2]  R1299     -1.9416575133800507e-01
    z[6,3,2]  R1300     -1.8333847820758820e-01
    z[6,3,2]  R1301     -5.2161026000976562e-01
    z[6,3,2]  R1302     3.4443494677543640e-01
    z[6,3,2]  R1303     2.2141848504543304e-01
    z[6,3,2]  R1304     1.4933940954506397e-02
    z[6,3,2]  R1305     -1.5962953865528107e-01
    z[6,3,2]  R1306     3.8431543856859207e-02
    z[6,3,2]  R1307     0.095056913793087
    z[6,3,2]  R1308     -9.1186009347438812e-02
    z[6,3,2]  R1309     2.2850561141967773e-01
    z[6,3,2]  R1310     1.8350470066070557e-01
    z[6,3,2]  R1311     -1.0992185026407242e-01
    z[6,3,2]  R1312     -6.4968854188919067e-02
    z[6,3,2]  R1313     1.5266297757625580e-01
    z[6,3,2]  R1314     0.0628947913646698
    z[6,3,2]  R1315     -1.3236106932163239e-01
    z[6,3,2]  R1316     1.4494094066321850e-02
    z[6,3,2]  R1317     2.4858203530311584e-01
    z[6,3,2]  R1318     -9.9425628781318665e-02
    z[6,3,2]  R1319     -4.5960783958435059e-01
    z[6,3,2]  R1320     -1.3062451779842377e-01
    z[6,3,2]  R1321     2.0609753206372261e-02
    z[6,3,2]  R1322     -1.2111578881740570e-01
    z[6,3,2]  R1323     -5.5107390880584717e-01
    z[6,3,2]  R1324     -6.5184015035629272e-01
    z[6,3,2]  R1325     1.5165668725967407e-01
    z[6,3,2]  R1326     9.4467557966709137e-02
    z[6,3,2]  R1327     3.7212669849395752e-01
    z[6,3,2]  R1328     0.510319173336029
    z[6,3,2]  R1329     -7.9994976520538330e-01
    z[6,3,2]  R1330     -2.0820085704326630e-01
    z[6,3,2]  R1331     -2.5144013762474060e-01
    z[6,3,2]  R1332     -4.7872957587242126e-01
    z[6,3,2]  R1333     3.4862619638442993e-01
    z[6,3,2]  R1334     -4.0366011857986450e-01
    z[6,3,2]  R1335     -1.7312115430831909e-01
    z[6,3,2]  R1336     -3.5301384329795837e-01
    z[6,3,2]  R1337     -3.4765001386404037e-02
    z[6,3,2]  R1338     4.2130580544471741e-01
    z[6,3,2]  R1339     -5.7477647066116333e-01
    z[6,3,2]  R1340     -0.645080029964447
    z[6,3,2]  R1341     -5.4246175289154053e-01
    z[6,3,2]  R1342     -1.1096552014350891e-01
    z[6,3,2]  R1343     -2.7713960409164429e-01
    z[6,3,2]  R1344     1.6731685400009155e-01
    z[6,3,2]  R1345     -5.4264806210994720e-02
    z[6,3,2]  R1346     -2.9492408037185669e-01
    z[6,3,2]  R1347     -5.9931054711341858e-02
    z[6,3,2]  R1348     5.0907637923955917e-02
    z[6,3,2]  R1349     -5.9057138860225677e-02
    z[6,3,2]  R1350     1.0383627563714981e-01
    z[6,3,2]  R1351     -4.1855287551879883e-01
    z[6,3,2]  R1352     -2.0485353469848633e-01
    z[6,3,2]  R1353     1.7963831126689911e-01
    z[6,3,2]  R1354     -3.7469189614057541e-02
    z[6,3,2]  R1355     -2.6761874556541443e-01
    z[6,3,2]  R1356     -3.3364719152450562e-01
    z[6,3,2]  R1357     3.4020170569419861e-02
    z[6,3,2]  R1358     1.9581666216254234e-02
    z[6,3,2]  R1359     2.5441735982894897e-02
    z[6,3,2]  R1360     -0.199344664812088
    z[6,3,2]  R1361     4.2731454968452454e-01
    z[6,3,2]  R1362     2.1485167741775513e-01
    z[6,3,2]  R1363     -3.7014293670654297e-01
    z[6,3,2]  R1364     3.8449708372354507e-02
    z[6,3,2]  R1365     -2.8615200892090797e-02
    z[6,3,2]  R1366     -3.9972978830337524e-01
    z[6,3,2]  R1367     5.3643748164176941e-02
    z[6,3,2]  R1368     3.8907316327095032e-01
    z[6,3,2]  R1369     1.7657142877578735e-01
    z[6,3,2]  R1370     1.2870785593986511e-01
    z[6,3,2]  R1371     -2.1501055359840393e-01
    z[6,3,2]  R1372     -1.6630896925926208e-01
    z[6,3,2]  R1373     2.1442010998725891e-01
    z[6,3,2]  R1374     -1.0274353623390198e-01
    z[6,3,2]  R1375     1.2185801565647125e-01
    z[6,3,2]  R1376     0.476277619600296
    z[6,3,2]  R1377     -4.4175478816032410e-01
    z[6,3,2]  R1378     2.8016316890716553e-01
    z[6,3,2]  R1379     -6.3626688718795776e-01
    z[6,3,2]  R1380     -2.1197710931301117e-01
    z[6,3,2]  R1381     -3.2583191990852356e-01
    z[6,3,2]  R1382     -1.7851114273071289e-01
    z[6,3,2]  R1383     -1.9553038477897644e-01
    z[6,3,2]  R1384     3.9250016212463379e-01
    z[6,3,2]  R1385     -1.1277581006288528e-01
    z[6,3,2]  R1386     -4.5033130049705505e-01
    z[6,3,2]  R1387     1.2961444258689880e-01
    z[6,3,2]  R1388     3.1226860359311104e-02
    z[6,3,2]  R1389     1.1279319971799850e-01
    z[6,3,2]  R1390     4.8092040419578552e-01
    z[6,3,2]  R1391     -6.0414797067642212e-01
    z[6,3,2]  R1392     -1.0588270425796509e-01
    z[6,3,2]  R1393     -4.0186974406242371e-01
    z[6,3,2]  R1394     -8.4704078733921051e-02
    z[6,3,2]  R1395     3.1920984387397766e-01
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1269     -1
    z[6,3,3]  R1270     1
    z[6,3,3]  R1277     -3.3907768130302429e-01
    z[6,3,3]  R1278     -2.9924616217613220e-01
    z[6,3,3]  R1279     -3.3888214826583862e-01
    z[6,3,3]  R1280     -5.9020549058914185e-01
    z[6,3,3]  R1281     -2.7884083986282349e-01
    z[6,3,3]  R1282     -5.5373167991638184e-01
    z[6,3,3]  R1283     -1.9600987434387207e-01
    z[6,3,3]  R1284     -3.7111577391624451e-01
    z[6,3,3]  R1285     2.6010829210281372e-01
    z[6,3,3]  R1286     8.1559962034225464e-01
    z[6,3,3]  R1287     1.2610229849815369e-01
    z[6,3,3]  R1288     9.3165948987007141e-02
    z[6,3,3]  R1289     -4.9079051613807678e-01
    z[6,3,3]  R1290     -4.9664461612701416e-01
    z[6,3,3]  R1291     3.9586505293846130e-01
    z[6,3,3]  R1292     2.1753889322280884e-01
    z[6,3,3]  R1293     -5.1467999815940857e-02
    z[6,3,3]  R1294     1.1947729438543320e-01
    z[6,3,3]  R1295     1.1300613731145859e-01
    z[6,3,3]  R1296     -3.8399152457714081e-02
    z[6,3,3]  R1297     3.9864072203636169e-01
    z[6,3,3]  R1298     -0.0781896784901619
    z[6,3,3]  R1299     5.0997996330261230e-01
    z[6,3,3]  R1300     -0.0290201585739851
    z[6,3,3]  R1301     3.3412650227546692e-02
    z[6,3,3]  R1302     6.9710515439510345e-02
    z[6,3,3]  R1303     3.3124664425849915e-01
    z[6,3,3]  R1304     9.6823759377002716e-02
    z[6,3,3]  R1305     2.7094164490699768e-01
    z[6,3,3]  R1306     1.2503567337989807e-01
    z[6,3,3]  R1307     1.2436323612928391e-01
    z[6,3,3]  R1308     -2.3279446363449097e-01
    z[6,3,3]  R1309     -5.4520197212696075e-02
    z[6,3,3]  R1310     -1.1272186040878296e-01
    z[6,3,3]  R1311     -3.9822015166282654e-01
    z[6,3,3]  R1312     1.9771383702754974e-01
    z[6,3,3]  R1313     -3.5733717679977417e-01
    z[6,3,3]  R1314     9.8374977707862854e-02
    z[6,3,3]  R1315     4.0437778830528259e-01
    z[6,3,3]  R1316     3.5644698143005371e-01
    z[6,3,3]  R1317     -3.9706024527549744e-01
    z[6,3,3]  R1318     2.9846101999282837e-01
    z[6,3,3]  R1319     2.7269285917282104e-01
    z[6,3,3]  R1320     1.0264895856380463e-01
    z[6,3,3]  R1321     2.5535422563552856e-01
    z[6,3,3]  R1322     4.0238106250762939e-01
    z[6,3,3]  R1323     -8.0770663917064667e-03
    z[6,3,3]  R1324     7.5806421227753162e-03
    z[6,3,3]  R1325     -1.4889647066593170e-01
    z[6,3,3]  R1326     1.0548835247755051e-01
    z[6,3,3]  R1327     -1.6698397696018219e-02
    z[6,3,3]  R1328     -3.6903306841850281e-01
    z[6,3,3]  R1329     3.1129187345504761e-01
    z[6,3,3]  R1330     2.8346312046051025e-01
    z[6,3,3]  R1331     7.2360301017761230e-01
    z[6,3,3]  R1332     4.1686362028121948e-01
    z[6,3,3]  R1333     1.5570640563964844e-01
    z[6,3,3]  R1334     1.2262795865535736e-01
    z[6,3,3]  R1335     -1.3377287983894348e-01
    z[6,3,3]  R1336     1.1306324601173401e-01
    z[6,3,3]  R1337     5.3718948364257812e-01
    z[6,3,3]  R1338     -0.571797788143158
    z[6,3,3]  R1339     2.1838736534118652e-01
    z[6,3,3]  R1340     3.0689904093742371e-01
    z[6,3,3]  R1341     6.3965070247650146e-01
    z[6,3,3]  R1342     5.1850110292434692e-01
    z[6,3,3]  R1343     5.0610125064849854e-01
    z[6,3,3]  R1344     2.2512586414813995e-01
    z[6,3,3]  R1345     5.3207403421401978e-01
    z[6,3,3]  R1346     6.9865804910659790e-01
    z[6,3,3]  R1347     -2.8843320906162262e-02
    z[6,3,3]  R1348     4.2975005507469177e-01
    z[6,3,3]  R1349     3.2536211609840393e-01
    z[6,3,3]  R1350     5.2024662494659424e-01
    z[6,3,3]  R1351     -1.0241288691759109e-01
    z[6,3,3]  R1352     0.801220178604126
    z[6,3,3]  R1353     4.1895386576652527e-01
    z[6,3,3]  R1354     2.0774005353450775e-01
    z[6,3,3]  R1355     2.7850806713104248e-01
    z[6,3,3]  R1356     -1.0500277578830719e-01
    z[6,3,3]  R1357     -3.9494130760431290e-02
    z[6,3,3]  R1358     -2.1544608473777771e-01
    z[6,3,3]  R1359     -7.8749559819698334e-02
    z[6,3,3]  R1360     8.2119709253311157e-01
    z[6,3,3]  R1361     -5.1762568950653076e-01
    z[6,3,3]  R1362     1.3576522469520569e-01
    z[6,3,3]  R1363     0.0986611545085907
    z[6,3,3]  R1364     7.8905093669891357e-01
    z[6,3,3]  R1365     -2.1489325165748596e-01
    z[6,3,3]  R1366     -4.4135209918022156e-01
    z[6,3,3]  R1367     4.3109700083732605e-01
    z[6,3,3]  R1368     6.4160728454589844e-01
    z[6,3,3]  R1369     2.4229782819747925e-01
    z[6,3,3]  R1370     5.0953966379165649e-01
    z[6,3,3]  R1371     4.9407321214675903e-01
    z[6,3,3]  R1372     3.6014896631240845e-01
    z[6,3,3]  R1373     -1.5400671958923340e-01
    z[6,3,3]  R1374     -2.0644627511501312e-02
    z[6,3,3]  R1375     7.1278929710388184e-01
    z[6,3,3]  R1376     5.4631787538528442e-01
    z[6,3,3]  R1377     1.4938473701477051e-01
    z[6,3,3]  R1378     -4.2482399940490723e-01
    z[6,3,3]  R1379     -0.322973370552063
    z[6,3,3]  R1380     -5.8784484863281250e-01
    z[6,3,3]  R1381     -0.518854558467865
    z[6,3,3]  R1382     -7.3962485790252686e-01
    z[6,3,3]  R1383     -1.8000417947769165e-01
    z[6,3,3]  R1384     1.7879299819469452e-01
    z[6,3,3]  R1385     4.8344683647155762e-01
    z[6,3,3]  R1386     1.3597738742828369e-01
    z[6,3,3]  R1387     8.8223300874233246e-02
    z[6,3,3]  R1388     7.8663372993469238e-01
    z[6,3,3]  R1389     -1.1369927227497101e-01
    z[6,3,3]  R1390     -4.2779183387756348e-01
    z[6,3,3]  R1391     1.4524123072624207e-01
    z[6,3,3]  R1392     -6.0591280460357666e-01
    z[6,3,3]  R1393     3.6464402079582214e-01
    z[6,3,3]  R1394     4.4875079393386841e-01
    z[6,3,3]  R1395     5.4512494802474976e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1271     -1
    z[6,3,4]  R1272     1
    z[6,3,4]  R1277     -4.6573806554079056e-02
    z[6,3,4]  R1278     -1.8613596260547638e-01
    z[6,3,4]  R1279     4.7604110091924667e-02
    z[6,3,4]  R1280     -1.3970064930617809e-02
    z[6,3,4]  R1281     3.3509659767150879e-01
    z[6,3,4]  R1282     4.5216381549835205e-01
    z[6,3,4]  R1283     4.3756440281867981e-01
    z[6,3,4]  R1284     3.0622169375419617e-01
    z[6,3,4]  R1285     -3.3020820468664169e-02
    z[6,3,4]  R1286     -4.0312924981117249e-01
    z[6,3,4]  R1287     2.3207981884479523e-01
    z[6,3,4]  R1288     1.8537633121013641e-01
    z[6,3,4]  R1289     5.0928640365600586e-01
    z[6,3,4]  R1290     -1.3969862461090088e-01
    z[6,3,4]  R1291     3.4669709205627441e-01
    z[6,3,4]  R1292     -1.7271824181079865e-01
    z[6,3,4]  R1293     3.9200261235237122e-02
    z[6,3,4]  R1294     9.2002548277378082e-02
    z[6,3,4]  R1295     -1.8937504291534424e-01
    z[6,3,4]  R1296     -1.4360065758228302e-01
    z[6,3,4]  R1297     -2.8094735741615295e-01
    z[6,3,4]  R1298     -2.1369270980358124e-02
    z[6,3,4]  R1299     3.4329418092966080e-02
    z[6,3,4]  R1300     -6.6291856765747070e-01
    z[6,3,4]  R1301     -4.8803728818893433e-01
    z[6,3,4]  R1302     -1.5790884196758270e-01
    z[6,3,4]  R1303     -5.5078315734863281e-01
    z[6,3,4]  R1304     -8.3766520023345947e-02
    z[6,3,4]  R1305     -2.1506768465042114e-01
    z[6,3,4]  R1306     2.0711828768253326e-01
    z[6,3,4]  R1307     -3.0013337731361389e-02
    z[6,3,4]  R1308     2.7905574440956116e-01
    z[6,3,4]  R1309     -4.8334106802940369e-02
    z[6,3,4]  R1310     -3.0210144817829132e-02
    z[6,3,4]  R1311     5.2105122804641724e-01
    z[6,3,4]  R1312     -1.3227945193648338e-02
    z[6,3,4]  R1313     2.3158590495586395e-01
    z[6,3,4]  R1314     2.3669071495532990e-01
    z[6,3,4]  R1315     4.9811866134405136e-02
    z[6,3,4]  R1316     1.8622530996799469e-01
    z[6,3,4]  R1317     2.2148312628269196e-01
    z[6,3,4]  R1318     3.5426761955022812e-02
    z[6,3,4]  R1319     -2.9519531130790710e-01
    z[6,3,4]  R1320     4.0074518322944641e-01
    z[6,3,4]  R1321     -2.4200105667114258e-01
    z[6,3,4]  R1322     1.2927709519863129e-01
    z[6,3,4]  R1323     2.2059883177280426e-01
    z[6,3,4]  R1324     2.1980078890919685e-02
    z[6,3,4]  R1325     1.5698119997978210e-01
    z[6,3,4]  R1326     -7.6411046087741852e-02
    z[6,3,4]  R1327     -1.6664180159568787e-01
    z[6,3,4]  R1328     -3.8733837008476257e-01
    z[6,3,4]  R1329     -7.0992313325405121e-02
    z[6,3,4]  R1330     3.9768660068511963e-01
    z[6,3,4]  R1331     -1.9679825007915497e-01
    z[6,3,4]  R1332     -0.302804559469223
    z[6,3,4]  R1333     -3.0368554592132568e-01
    z[6,3,4]  R1334     1.0551684349775314e-01
    z[6,3,4]  R1335     -1.9355788826942444e-02
    z[6,3,4]  R1336     6.2445417046546936e-02
    z[6,3,4]  R1337     -1.5688581764698029e-01
    z[6,3,4]  R1338     -1.8737266957759857e-01
    z[6,3,4]  R1339     1.3259534537792206e-01
    z[6,3,4]  R1340     -1.9866687059402466e-01
    z[6,3,4]  R1341     -3.0559748411178589e-01
    z[6,3,4]  R1342     1.3698628544807434e-01
    z[6,3,4]  R1343     -5.0602819770574570e-02
    z[6,3,4]  R1344     -1.5582096576690674e-01
    z[6,3,4]  R1345     -4.6497333049774170e-01
    z[6,3,4]  R1346     6.6649354994297028e-02
    z[6,3,4]  R1347     1.2416181713342667e-01
    z[6,3,4]  R1348     3.8874413818120956e-02
    z[6,3,4]  R1349     1.6988384723663330e-01
    z[6,3,4]  R1350     -6.0564088821411133e-01
    z[6,3,4]  R1351     5.5132603645324707e-01
    z[6,3,4]  R1352     -6.8614810705184937e-02
    z[6,3,4]  R1353     -0.664197564125061
    z[6,3,4]  R1354     -4.2081409692764282e-01
    z[6,3,4]  R1355     -1.2498825043439865e-01
    z[6,3,4]  R1356     1.0058642923831940e-01
    z[6,3,4]  R1357     4.0197573602199554e-02
    z[6,3,4]  R1358     8.1931173801422119e-02
    z[6,3,4]  R1359     4.4640928506851196e-02
    z[6,3,4]  R1360     -1.0576204210519791e-01
    z[6,3,4]  R1361     6.1329182237386703e-02
    z[6,3,4]  R1362     6.8140506744384766e-02
    z[6,3,4]  R1363     1.2142547965049744e-01
    z[6,3,4]  R1364     -1.1520221084356308e-01
    z[6,3,4]  R1365     -1.8276037275791168e-01
    z[6,3,4]  R1366     2.3541533946990967e-01
    z[6,3,4]  R1367     7.7099494636058807e-02
    z[6,3,4]  R1368     1.4336153864860535e-01
    z[6,3,4]  R1369     -2.2197237610816956e-01
    z[6,3,4]  R1370     -2.4536329507827759e-01
    z[6,3,4]  R1371     -4.9715104699134827e-01
    z[6,3,4]  R1372     -4.2462694644927979e-01
    z[6,3,4]  R1373     -1.4687924087047577e-01
    z[6,3,4]  R1374     -2.6961660385131836e-01
    z[6,3,4]  R1375     -3.5215571522712708e-01
    z[6,3,4]  R1376     0.305738627910614
    z[6,3,4]  R1377     3.1410478055477142e-02
    z[6,3,4]  R1378     3.0677413940429688e-01
    z[6,3,4]  R1379     3.3142006397247314e-01
    z[6,3,4]  R1380     3.7239551544189453e-01
    z[6,3,4]  R1381     -1.5976226329803467e-01
    z[6,3,4]  R1382     3.6165577173233032e-01
    z[6,3,4]  R1383     3.3996206521987915e-01
    z[6,3,4]  R1384     3.0345523357391357e-01
    z[6,3,4]  R1385     -1.5989659726619720e-01
    z[6,3,4]  R1386     -3.4453293681144714e-01
    z[6,3,4]  R1387     -1.4251527190208435e-01
    z[6,3,4]  R1388     -2.1376316249370575e-01
    z[6,3,4]  R1389     -3.2532259821891785e-01
    z[6,3,4]  R1390     0.474231094121933
    z[6,3,4]  R1391     -4.9816173315048218e-01
    z[6,3,4]  R1392     3.1092768907546997e-01
    z[6,3,4]  R1393     5.5697995424270630e-01
    z[6,3,4]  R1394     2.6597961783409119e-01
    z[6,3,4]  R1395     3.0822345614433289e-01
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1273     -1
    z[6,3,5]  R1274     1
    z[6,3,5]  R1277     5.0448134541511536e-02
    z[6,3,5]  R1278     3.5628405213356018e-01
    z[6,3,5]  R1279     4.9841940402984619e-01
    z[6,3,5]  R1280     2.3097988963127136e-01
    z[6,3,5]  R1281     3.3193412423133850e-01
    z[6,3,5]  R1282     -9.6335709095001221e-02
    z[6,3,5]  R1283     1.0548584163188934e-02
    z[6,3,5]  R1284     -4.0202800184488297e-02
    z[6,3,5]  R1285     0.355111688375473
    z[6,3,5]  R1286     -1.7216829583048820e-02
    z[6,3,5]  R1287     3.4412688016891479e-01
    z[6,3,5]  R1288     5.2093285322189331e-01
    z[6,3,5]  R1289     -1.3080455362796783e-01
    z[6,3,5]  R1290     -1.1704389750957489e-01
    z[6,3,5]  R1291     1.8582293391227722e-01
    z[6,3,5]  R1292     -1.4288491010665894e-01
    z[6,3,5]  R1293     1.0768998414278030e-01
    z[6,3,5]  R1294     -2.9755065217614174e-02
    z[6,3,5]  R1295     1.2650847434997559e-01
    z[6,3,5]  R1296     6.8607471883296967e-02
    z[6,3,5]  R1297     3.4096702933311462e-01
    z[6,3,5]  R1298     2.5523445010185242e-01
    z[6,3,5]  R1299     -2.1300630643963814e-02
    z[6,3,5]  R1300     4.8581507802009583e-01
    z[6,3,5]  R1301     5.2268964052200317e-01
    z[6,3,5]  R1302     -1.1703015118837357e-01
    z[6,3,5]  R1303     4.3361055850982666e-01
    z[6,3,5]  R1304     -4.6812698245048523e-01
    z[6,3,5]  R1305     1.3619804382324219e-01
    z[6,3,5]  R1306     -2.6303318142890930e-01
    z[6,3,5]  R1307     3.7050571292638779e-02
    z[6,3,5]  R1308     -1.2478940188884735e-01
    z[6,3,5]  R1309     8.6288809776306152e-02
    z[6,3,5]  R1310     -1.6528807580471039e-01
    z[6,3,5]  R1311     3.5488995909690857e-01
    z[6,3,5]  R1312     1.9388712942600250e-01
    z[6,3,5]  R1313     -9.8234914243221283e-02
    z[6,3,5]  R1314     6.5929156541824341e-01
    z[6,3,5]  R1315     -1.6213320195674896e-01
    z[6,3,5]  R1316     3.0738005042076111e-01
    z[6,3,5]  R1317     3.4320649504661560e-01
    z[6,3,5]  R1318     -1.9283334910869598e-01
    z[6,3,5]  R1319     6.1310482025146484e-01
    z[6,3,5]  R1320     2.9591289162635803e-01
    z[6,3,5]  R1321     -1.7603531479835510e-01
    z[6,3,5]  R1322     8.6186133325099945e-02
    z[6,3,5]  R1323     2.8385239839553833e-01
    z[6,3,5]  R1324     2.4412062764167786e-01
    z[6,3,5]  R1325     5.2332830429077148e-01
    z[6,3,5]  R1326     4.1580680012702942e-01
    z[6,3,5]  R1327     -1.2333630770444870e-01
    z[6,3,5]  R1328     -0.0711502805352211
    z[6,3,5]  R1329     4.6585026383399963e-01
    z[6,3,5]  R1330     3.6016803979873657e-01
    z[6,3,5]  R1331     3.2151695340871811e-02
    z[6,3,5]  R1332     -4.0721049904823303e-01
    z[6,3,5]  R1333     1.1348453909158707e-01
    z[6,3,5]  R1334     -3.0042484402656555e-01
    z[6,3,5]  R1335     -9.7968660295009613e-02
    z[6,3,5]  R1336     -2.2801715135574341e-01
    z[6,3,5]  R1337     3.3695498108863831e-01
    z[6,3,5]  R1338     -1.9032275676727295e-01
    z[6,3,5]  R1339     2.3500597476959229e-01
    z[6,3,5]  R1340     0.0966220423579216
    z[6,3,5]  R1341     6.5530523657798767e-02
    z[6,3,5]  R1342     4.1757243871688843e-01
    z[6,3,5]  R1343     3.0980497598648071e-01
    z[6,3,5]  R1344     3.6398828029632568e-01
    z[6,3,5]  R1345     3.1032985448837280e-01
    z[6,3,5]  R1346     4.4034352898597717e-01
    z[6,3,5]  R1347     2.8430068492889404e-01
    z[6,3,5]  R1348     2.5482922792434692e-01
    z[6,3,5]  R1349     -1.6160987317562103e-01
    z[6,3,5]  R1350     2.4246735870838165e-01
    z[6,3,5]  R1351     -1.6973756253719330e-01
    z[6,3,5]  R1352     3.9245158433914185e-01
    z[6,3,5]  R1353     -7.2402499616146088e-02
    z[6,3,5]  R1354     -2.5813108682632446e-01
    z[6,3,5]  R1355     -2.4999319016933441e-01
    z[6,3,5]  R1356     -1.6648904979228973e-01
    z[6,3,5]  R1357     -3.2943961024284363e-01
    z[6,3,5]  R1358     -3.5980053246021271e-02
    z[6,3,5]  R1359     -3.1049215793609619e-01
    z[6,3,5]  R1360     2.8177076578140259e-01
    z[6,3,5]  R1361     -1.1477879434823990e-01
    z[6,3,5]  R1362     2.0424258708953857e-01
    z[6,3,5]  R1363     6.9125302135944366e-02
    z[6,3,5]  R1364     -7.8146345913410187e-02
    z[6,3,5]  R1365     -3.4167268872261047e-01
    z[6,3,5]  R1366     -3.8538447022438049e-01
    z[6,3,5]  R1367     -2.2628612816333771e-01
    z[6,3,5]  R1368     2.8383467346429825e-02
    z[6,3,5]  R1369     2.7258491516113281e-01
    z[6,3,5]  R1370     1.6982145607471466e-01
    z[6,3,5]  R1371     3.2328939437866211e-01
    z[6,3,5]  R1372     1.5535542368888855e-01
    z[6,3,5]  R1373     8.0995744466781616e-01
    z[6,3,5]  R1374     7.9695820808410645e-01
    z[6,3,5]  R1375     -2.2832190617918968e-02
    z[6,3,5]  R1376     2.9667469859123230e-01
    z[6,3,5]  R1377     -3.6605009436607361e-01
    z[6,3,5]  R1378     -2.8311079740524292e-01
    z[6,3,5]  R1379     7.1407124400138855e-02
    z[6,3,5]  R1380     -1.0312648862600327e-01
    z[6,3,5]  R1381     -5.3364062309265137e-01
    z[6,3,5]  R1382     -1.2207627296447754e-01
    z[6,3,5]  R1383     -2.5423637032508850e-01
    z[6,3,5]  R1384     -2.7033188939094543e-01
    z[6,3,5]  R1385     -2.3554079234600067e-01
    z[6,3,5]  R1386     -3.5050097107887268e-01
    z[6,3,5]  R1387     5.8041650056838989e-01
    z[6,3,5]  R1388     3.7163376808166504e-01
    z[6,3,5]  R1389     -1.5019933879375458e-01
    z[6,3,5]  R1390     3.3966881036758423e-01
    z[6,3,5]  R1391     -6.6731266677379608e-02
    z[6,3,5]  R1392     2.8604209423065186e-01
    z[6,3,5]  R1393     3.7263652682304382e-01
    z[6,3,5]  R1394     7.8697368502616882e-02
    z[6,3,5]  R1395     1.0498242825269699e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1275     -1
    z[6,3,6]  R1276     1
    z[6,3,6]  R1277     -3.0224621295928955e-02
    z[6,3,6]  R1278     -3.0544428154826164e-02
    z[6,3,6]  R1279     -1.0236737877130508e-01
    z[6,3,6]  R1280     -1.8589726090431213e-01
    z[6,3,6]  R1281     2.1918751299381256e-03
    z[6,3,6]  R1282     0.079471655189991
    z[6,3,6]  R1283     1.1661176383495331e-01
    z[6,3,6]  R1284     -4.5812937617301941e-01
    z[6,3,6]  R1285     -9.5765674486756325e-03
    z[6,3,6]  R1286     1.1679705977439880e-01
    z[6,3,6]  R1287     -1.1486873030662537e-01
    z[6,3,6]  R1288     -4.6692779660224915e-01
    z[6,3,6]  R1289     1.4410948380827904e-02
    z[6,3,6]  R1290     -2.3125639557838440e-01
    z[6,3,6]  R1291     -2.1750238537788391e-01
    z[6,3,6]  R1292     3.6757946014404297e-01
    z[6,3,6]  R1293     1.0941742360591888e-01
    z[6,3,6]  R1294     2.4398863315582275e-02
    z[6,3,6]  R1295     0.0702752098441124
    z[6,3,6]  R1296     -2.9970180243253708e-02
    z[6,3,6]  R1297     1.3765922188758850e-01
    z[6,3,6]  R1298     -3.8214033842086792e-01
    z[6,3,6]  R1299     -2.1635919809341431e-01
    z[6,3,6]  R1300     1.9490335881710052e-01
    z[6,3,6]  R1301     -2.4053165316581726e-01
    z[6,3,6]  R1302     3.0572479963302612e-01
    z[6,3,6]  R1303     -1.2226716615259647e-02
    z[6,3,6]  R1304     -1.4560225419700146e-02
    z[6,3,6]  R1305     4.7664329409599304e-01
    z[6,3,6]  R1306     4.6030825376510620e-01
    z[6,3,6]  R1307     -2.3105631768703461e-01
    z[6,3,6]  R1308     -4.4470822811126709e-01
    z[6,3,6]  R1309     1.3618775643408298e-02
    z[6,3,6]  R1310     -0.049640953540802
    z[6,3,6]  R1311     -0.259581595659256
    z[6,3,6]  R1312     -3.6433029174804688e-01
    z[6,3,6]  R1313     2.9331985116004944e-01
    z[6,3,6]  R1314     1.3550363481044769e-01
    z[6,3,6]  R1315     1.5716609358787537e-01
    z[6,3,6]  R1316     0.46355140209198
    z[6,3,6]  R1317     2.0093612372875214e-02
    z[6,3,6]  R1318     1.1167913675308228e-02
    z[6,3,6]  R1319     6.5813146531581879e-02
    z[6,3,6]  R1320     1.8022309243679047e-01
    z[6,3,6]  R1321     9.1388203203678131e-02
    z[6,3,6]  R1322     5.4702490568161011e-01
    z[6,3,6]  R1323     1.7998608946800232e-01
    z[6,3,6]  R1324     5.0963789224624634e-01
    z[6,3,6]  R1325     1.6429116949439049e-02
    z[6,3,6]  R1326     -2.5223836302757263e-01
    z[6,3,6]  R1327     3.8169443607330322e-01
    z[6,3,6]  R1328     -8.0177947878837585e-02
    z[6,3,6]  R1329     0.0874348059296608
    z[6,3,6]  R1330     1.4457820355892181e-01
    z[6,3,6]  R1331     3.1224694848060608e-01
    z[6,3,6]  R1332     2.7112990617752075e-01
    z[6,3,6]  R1333     2.1874293684959412e-01
    z[6,3,6]  R1334     -2.8557786345481873e-01
    z[6,3,6]  R1335     -1.9834528863430023e-01
    z[6,3,6]  R1336     -5.3242433071136475e-01
    z[6,3,6]  R1337     3.0272516608238220e-01
    z[6,3,6]  R1338     -1.3332915306091309e-01
    z[6,3,6]  R1339     2.7723437547683716e-01
    z[6,3,6]  R1340     5.3015863895416260e-01
    z[6,3,6]  R1341     6.3868030905723572e-02
    z[6,3,6]  R1342     9.1345183551311493e-02
    z[6,3,6]  R1343     -6.0760229825973511e-01
    z[6,3,6]  R1344     -2.4147087242454290e-04
    z[6,3,6]  R1345     -5.2079045772552490e-01
    z[6,3,6]  R1346     -1.7207440733909607e-01
    z[6,3,6]  R1347     -5.1508295536041260e-01
    z[6,3,6]  R1348     3.1199935078620911e-01
    z[6,3,6]  R1349     3.9095902442932129e-01
    z[6,3,6]  R1350     -2.7082201838493347e-01
    z[6,3,6]  R1351     -2.7292063832283020e-01
    z[6,3,6]  R1352     -1.0957321152091026e-02
    z[6,3,6]  R1353     -2.5969070196151733e-01
    z[6,3,6]  R1354     -1.3700519502162933e-01
    z[6,3,6]  R1355     -4.0275490283966064e-01
    z[6,3,6]  R1356     -4.9255305528640747e-01
    z[6,3,6]  R1357     -2.0176558196544647e-01
    z[6,3,6]  R1358     -0.392668753862381
    z[6,3,6]  R1359     2.4300108850002289e-01
    z[6,3,6]  R1360     -0.00647188164293766
    z[6,3,6]  R1361     5.4791235923767090e-01
    z[6,3,6]  R1362     0.568831205368042
    z[6,3,6]  R1363     -2.7207210659980774e-01
    z[6,3,6]  R1364     4.0409117937088013e-01
    z[6,3,6]  R1365     -4.2171877622604370e-01
    z[6,3,6]  R1366     -1.4311835169792175e-02
    z[6,3,6]  R1367     -7.3401778936386108e-01
    z[6,3,6]  R1368     2.3921218235045671e-03
    z[6,3,6]  R1369     -7.6444578170776367e-01
    z[6,3,6]  R1370     5.1944744586944580e-01
    z[6,3,6]  R1371     3.3187377452850342e-01
    z[6,3,6]  R1372     -5.5719721317291260e-01
    z[6,3,6]  R1373     -4.6325522661209106e-01
    z[6,3,6]  R1374     3.1263187527656555e-01
    z[6,3,6]  R1375     -1.7332918941974640e-01
    z[6,3,6]  R1376     -1.6482527554035187e-01
    z[6,3,6]  R1377     3.8398674130439758e-01
    z[6,3,6]  R1378     2.4408011138439178e-01
    z[6,3,6]  R1379     1.8971693515777588e-01
    z[6,3,6]  R1380     1.6159202158451080e-01
    z[6,3,6]  R1381     0.0920364037156105
    z[6,3,6]  R1382     1.8101497553288937e-03
    z[6,3,6]  R1383     -2.6887786388397217e-01
    z[6,3,6]  R1384     2.7434840798377991e-01
    z[6,3,6]  R1385     -3.2288864254951477e-01
    z[6,3,6]  R1386     1.9168620929121971e-02
    z[6,3,6]  R1387     2.2632595896720886e-01
    z[6,3,6]  R1388     1.8007853627204895e-01
    z[6,3,6]  R1389     -1.4954796433448792e-01
    z[6,3,6]  R1390     1.9748227298259735e-01
    z[6,3,6]  R1391     -5.3021764755249023e-01
    z[6,3,6]  R1392     -8.2450456917285919e-02
    z[6,3,6]  R1393     -0.296037882566452
    z[6,3,6]  R1394     -3.0968451872467995e-02
    z[6,3,6]  R1395     -2.3845938965678215e-02
    z[4,6,0]  R38       -1
    z[4,6,0]  R56       1
    z[4,6,0]  R1396     -1
    z[4,6,0]  R1397     1
    z[4,6,0]  R1410     -1.5911825001239777e-01
    z[4,6,0]  R1411     -8.3460539579391479e-02
    z[4,6,0]  R1412     -2.9796180129051208e-01
    z[4,6,0]  R1413     -0.10040283203125
    z[4,6,0]  R1414     -1.1207935959100723e-01
    z[4,6,0]  R1415     -5.4521399736404419e-01
    z[4,6,0]  R1416     2.1134330017957836e-04
    z[4,6,0]  R1417     1.8737228214740753e-01
    z[4,6,0]  R1418     -3.7565141916275024e-01
    z[4,6,0]  R1419     -1.3508066534996033e-01
    z[4,6,0]  R1420     7.3875255882740021e-02
    z[4,6,0]  R1421     2.6147386431694031e-01
    z[4,6,0]  R1422     -5.3577542304992676e-01
    z[4,6,0]  R1423     4.5376780629158020e-01
    z[4,6,0]  R1424     6.9701528549194336e-01
    z[4,6,0]  R1425     -2.9086044430732727e-01
    z[4,6,0]  R1426     6.3951069116592407e-01
    z[4,6,0]  R1427     0.605835497379303
    z[4,6,0]  R1428     7.0761835575103760e-01
    z[4,6,0]  R1429     3.8629552721977234e-01
    z[4,6,0]  R1430     3.6952725052833557e-01
    z[4,6,0]  R1431     -9.5478974282741547e-02
    z[4,6,0]  R1432     -5.1158881187438965e-01
    z[4,6,0]  R1433     -4.5761802792549133e-01
    z[4,6,0]  R1434     -4.9912708997726440e-01
    z[4,6,0]  R1435     5.7854449748992920e-01
    z[4,6,0]  R1436     -2.5291821360588074e-01
    z[4,6,0]  R1437     -9.0638458728790283e-01
    z[4,6,0]  R1438     -8.2799595594406128e-01
    z[4,6,0]  R1439     -7.8493207693099976e-01
    z[4,6,0]  R1440     -7.0772647857666016e-01
    z[4,6,0]  R1441     -0.819678008556366
    z[4,6,0]  R1442     -6.6300272941589355e-01
    z[4,6,0]  R1443     -8.1264919042587280e-01
    z[4,6,0]  R1444     -6.8940824270248413e-01
    z[4,6,0]  R1445     -8.8037103414535522e-01
    z[4,6,0]  R1446     2.9375693202018738e-01
    z[4,6,0]  R1447     -3.8623297587037086e-04
    z[4,6,0]  R1448     4.9018543958663940e-01
    z[4,6,0]  R1449     4.9586838483810425e-01
    z[4,6,0]  R1450     4.3103596568107605e-01
    z[4,6,0]  R1451     2.0347057282924652e-01
    z[4,6,0]  R1452     3.9923486113548279e-01
    z[4,6,0]  R1453     0.421084463596344
    z[4,6,0]  R1454     2.6942405104637146e-01
    z[4,6,0]  R1455     3.8349777460098267e-01
    z[4,6,0]  R1456     3.8672599196434021e-01
    z[4,6,0]  R1457     0.599850058555603
    z[4,6,0]  R1458     3.9805805683135986e-01
    z[4,6,0]  R1459     9.7217820584774017e-02
    z[4,6,0]  R1460     3.7836232781410217e-01
    z[4,6,0]  R1461     2.1848320960998535e-01
    z[4,6,0]  R1462     4.0968227386474609e-01
    z[4,6,0]  R1463     5.7834142446517944e-01
    z[4,6,0]  R1464     -4.1519635915756226e-01
    z[4,6,0]  R1465     -2.0829349756240845e-01
    z[4,6,0]  R1466     1.6713143885135651e-01
    z[4,6,0]  R1467     0.291344553232193
    z[4,6,0]  R1468     2.0175081491470337e-01
    z[4,6,0]  R1469     -1.8293541669845581e-01
    z[4,6,0]  R1470     -1.5737058222293854e-01
    z[4,6,0]  R1471     -7.6309749856591225e-03
    z[4,6,0]  R1472     -3.4955191612243652e-01
    z[4,6,0]  R1473     -4.1043874621391296e-01
    z[4,6,0]  R1474     1.1732964962720871e-01
    z[4,6,0]  R1475     -4.1289508342742920e-01
    z[4,6,0]  R1476     6.7198120057582855e-02
    z[4,6,0]  R1477     1.4178267121315002e-01
    z[4,6,0]  R1478     -3.6966481804847717e-01
    z[4,6,0]  R1479     4.9518829584121704e-01
    z[4,6,0]  R1480     -2.0473115146160126e-01
    z[4,6,0]  R1481     -8.2797199487686157e-01
    z[4,6,0]  R1482     0.617081344127655
    z[4,6,0]  R1483     5.0851190090179443e-01
    z[4,6,0]  R1484     3.9375400543212891e-01
    z[4,6,0]  R1485     0.809958279132843
    z[4,6,0]  R1486     8.5605132579803467e-01
    z[4,6,0]  R1487     -2.9784919694066048e-02
    z[4,6,0]  R1488     -0.286978155374527
    z[4,6,0]  R1489     1.6640554368495941e-01
    z[4,6,0]  R1490     7.2376525402069092e-01
    z[4,6,0]  R1491     -1.7412005364894867e-01
    z[4,6,0]  R1492     8.0571383237838745e-02
    z[4,6,0]  R1493     8.3700728416442871e-01
    z[4,6,0]  R1494     1.3343612849712372e-01
    z[4,6,0]  R1495     -6.4536012709140778e-02
    z[4,6,0]  R1496     4.4132387638092041e-01
    z[4,6,0]  R1497     6.9306713342666626e-01
    z[4,6,0]  R1498     -2.6543736457824707e-01
    z[4,6,0]  R1499     4.8704367876052856e-01
    z[4,6,0]  R1500     3.5728746652603149e-01
    z[4,6,0]  R1501     2.4972066283226013e-01
    z[4,6,0]  R1502     2.2820445895195007e-01
    z[4,6,0]  R1503     4.4021755456924438e-01
    z[4,6,0]  R1504     8.7229609489440918e-01
    z[4,6,0]  R1505     1.6437853872776031e-01
    z[4,6,0]  R1506     4.1851267218589783e-01
    z[4,6,0]  R1507     -9.3097686767578125e-02
    z[4,6,0]  R1508     0.0915379747748375
    z[4,6,0]  R1509     -0.0588078498840332
    z[4,6,0]  R1510     4.6570891141891479e-01
    z[4,6,0]  R1511     -3.0314895510673523e-01
    z[4,6,0]  R1512     3.5545620322227478e-01
    z[4,6,0]  R1513     -2.0369479060173035e-01
    z[4,6,0]  R1514     -1.8442565202713013e-01
    z[4,6,0]  R1515     4.4914808869361877e-01
    z[4,6,0]  R1516     5.8731153607368469e-02
    z[4,6,0]  R1517     0.0049970424734056
    z[4,6,0]  R1518     -3.4934845566749573e-01
    z[4,6,0]  R1519     -7.5006228685379028e-01
    z[4,6,0]  R1520     4.0946078300476074e-01
    z[4,6,0]  R1521     -1.1233063042163849e-01
    z[4,6,0]  R1522     7.2808766365051270e-01
    z[4,6,0]  R1523     -2.4780279025435448e-02
    z[4,6,0]  R1524     -3.3136874437332153e-02
    z[4,6,0]  R1525     3.3650982379913330e-01
    z[4,6,0]  R1526     3.7405374646186829e-01
    z[4,6,1]  R39       -1
    z[4,6,1]  R57       1
    z[4,6,1]  R1398     -1
    z[4,6,1]  R1399     1
    z[4,6,1]  R1410     -2.1109507977962494e-01
    z[4,6,1]  R1411     3.6115714907646179e-01
    z[4,6,1]  R1412     5.0819098949432373e-01
    z[4,6,1]  R1413     6.0065197944641113e-01
    z[4,6,1]  R1414     2.9567638039588928e-01
    z[4,6,1]  R1415     -2.9722964763641357e-01
    z[4,6,1]  R1416     -2.6562201976776123e-01
    z[4,6,1]  R1417     -1.9744651019573212e-01
    z[4,6,1]  R1418     -1.0959574580192566e-01
    z[4,6,1]  R1419     -1.5208879113197327e-01
    z[4,6,1]  R1420     -7.6956021785736084e-01
    z[4,6,1]  R1421     -8.6423909664154053e-01
    z[4,6,1]  R1422     -7.2976911067962646e-01
    z[4,6,1]  R1423     -6.6835129261016846e-01
    z[4,6,1]  R1424     -6.9223767518997192e-01
    z[4,6,1]  R1425     -0.820530116558075
    z[4,6,1]  R1426     4.5963096618652344e-01
    z[4,6,1]  R1427     7.0677846670150757e-01
    z[4,6,1]  R1428     3.9970946311950684e-01
    z[4,6,1]  R1429     0.728522002696991
    z[4,6,1]  R1430     -7.0043218135833740e-01
    z[4,6,1]  R1431     -6.0439997911453247e-01
    z[4,6,1]  R1432     -7.9351294040679932e-01
    z[4,6,1]  R1433     -5.0827115774154663e-01
    z[4,6,1]  R1434     2.3698510229587555e-01
    z[4,6,1]  R1435     6.2553894519805908e-01
    z[4,6,1]  R1436     4.3601259589195251e-01
    z[4,6,1]  R1437     2.3567005991935730e-01
    z[4,6,1]  R1438     -4.1897028684616089e-02
    z[4,6,1]  R1439     2.8792524710297585e-02
    z[4,6,1]  R1440     -1.2074025720357895e-01
    z[4,6,1]  R1441     -8.2762926816940308e-02
    z[4,6,1]  R1442     -1.4048515260219574e-01
    z[4,6,1]  R1443     4.6277213841676712e-02
    z[4,6,1]  R1444     -1.1682908982038498e-01
    z[4,6,1]  R1445     -1.0781950503587723e-01
    z[4,6,1]  R1446     -2.0093406736850739e-01
    z[4,6,1]  R1447     -8.9190477132797241e-01
    z[4,6,1]  R1448     -3.7189406156539917e-01
    z[4,6,1]  R1449     -4.8617777228355408e-01
    z[4,6,1]  R1450     -5.5693954229354858e-01
    z[4,6,1]  R1451     -6.9330793619155884e-01
    z[4,6,1]  R1452     -7.2400510311126709e-01
    z[4,6,1]  R1453     8.9146637916564941e-01
    z[4,6,1]  R1454     9.2655897140502930e-01
    z[4,6,1]  R1455     8.8261890411376953e-01
    z[4,6,1]  R1456     0.881799578666687
    z[4,6,1]  R1457     -5.0700485706329346e-01
    z[4,6,1]  R1458     -7.7167344093322754e-01
    z[4,6,1]  R1459     -8.0269873142242432e-01
    z[4,6,1]  R1460     -3.3003348112106323e-01
    z[4,6,1]  R1461     -3.3140763640403748e-01
    z[4,6,1]  R1462     -7.5931972265243530e-01
    z[4,6,1]  R1463     -1.2345468252897263e-01
    z[4,6,1]  R1464     -7.6918292045593262e-01
    z[4,6,1]  R1465     -0.752150297164917
    z[4,6,1]  R1466     -7.9434764385223389e-01
    z[4,6,1]  R1467     -9.1375911235809326e-01
    z[4,6,1]  R1468     -7.7818918228149414e-01
    z[4,6,1]  R1469     -9.4941031932830811e-01
    z[4,6,1]  R1470     -9.4771158695220947e-01
    z[4,6,1]  R1471     -6.0370171070098877e-01
    z[4,6,1]  R1472     -8.1486070156097412e-01
    z[4,6,1]  R1473     -7.2885221242904663e-01
    z[4,6,1]  R1474     -6.8084597587585449e-01
    z[4,6,1]  R1475     -7.7136713266372681e-01
    z[4,6,1]  R1476     -7.2400116920471191e-01
    z[4,6,1]  R1477     -0.770193874835968
    z[4,6,1]  R1478     -8.5195004940032959e-01
    z[4,6,1]  R1479     4.2647279798984528e-02
    z[4,6,1]  R1480     -8.0612915754318237e-01
    z[4,6,1]  R1481     -3.8849323987960815e-01
    z[4,6,1]  R1482     -3.4533193707466125e-01
    z[4,6,1]  R1483     -5.2539217472076416e-01
    z[4,6,1]  R1484     -3.1653749942779541e-01
    z[4,6,1]  R1485     -3.4983004443347454e-03
    z[4,6,1]  R1486     0.0690355971455574
    z[4,6,1]  R1487     -8.1956321001052856e-01
    z[4,6,1]  R1488     -5.9959208965301514e-01
    z[4,6,1]  R1489     -7.6063059270381927e-02
    z[4,6,1]  R1490     -2.0901305973529816e-01
    z[4,6,1]  R1491     -4.9557766318321228e-01
    z[4,6,1]  R1492     -5.0943940877914429e-01
    z[4,6,1]  R1493     -2.6115508750081062e-02
    z[4,6,1]  R1494     7.8820818662643433e-01
    z[4,6,1]  R1495     9.4797450304031372e-01
    z[4,6,1]  R1496     5.7311809062957764e-01
    z[4,6,1]  R1497     -9.0785082429647446e-03
    z[4,6,1]  R1498     -5.7964098453521729e-01
    z[4,6,1]  R1499     -4.8482900857925415e-01
    z[4,6,1]  R1500     -1.7932601273059845e-01
    z[4,6,1]  R1501     -3.6394849419593811e-01
    z[4,6,1]  R1502     -0.682121753692627
    z[4,6,1]  R1503     -7.4453867971897125e-02
    z[4,6,1]  R1504     6.0457970947027206e-02
    z[4,6,1]  R1505     -0.321254700422287
    z[4,6,1]  R1506     -1.4761339128017426e-01
    z[4,6,1]  R1507     -7.9079437255859375e-01
    z[4,6,1]  R1508     -8.0034458637237549e-01
    z[4,6,1]  R1509     -8.2423675060272217e-01
    z[4,6,1]  R1510     -5.2353560924530029e-02
    z[4,6,1]  R1511     -5.6139910221099854e-01
    z[4,6,1]  R1512     -1.7574384808540344e-01
    z[4,6,1]  R1513     -4.8669952154159546e-01
    z[4,6,1]  R1514     0.811751663684845
    z[4,6,1]  R1515     0.639335036277771
    z[4,6,1]  R1516     7.7055817842483521e-01
    z[4,6,1]  R1517     -9.2000114917755127e-01
    z[4,6,1]  R1518     -8.1789934635162354e-01
    z[4,6,1]  R1519     -5.2259933948516846e-01
    z[4,6,1]  R1520     -0.166182741522789
    z[4,6,1]  R1521     -0.468726247549057
    z[4,6,1]  R1522     -1.8806332349777222e-01
    z[4,6,1]  R1523     8.7126356363296509e-01
    z[4,6,1]  R1524     4.3835404515266418e-01
    z[4,6,1]  R1525     7.1538448333740234e-01
    z[4,6,1]  R1526     5.4896432161331177e-01
    z[4,6,2]  R40       -1
    z[4,6,2]  R58       1
    z[4,6,2]  R1400     -1
    z[4,6,2]  R1401     1
    z[4,6,2]  R1410     -1.8154074251651764e-01
    z[4,6,2]  R1411     -2.8845322132110596e-01
    z[4,6,2]  R1412     -3.8084396719932556e-01
    z[4,6,2]  R1413     -0.0054810531437397
    z[4,6,2]  R1414     -2.6502066850662231e-01
    z[4,6,2]  R1415     -1.4793653041124344e-02
    z[4,6,2]  R1416     1.4257819950580597e-01
    z[4,6,2]  R1417     -1.3961243629455566e-01
    z[4,6,2]  R1418     1.1071675270795822e-01
    z[4,6,2]  R1419     1.3990931212902069e-01
    z[4,6,2]  R1420     -2.8753346204757690e-01
    z[4,6,2]  R1421     -1.6213077306747437e-01
    z[4,6,2]  R1422     -1.3287785649299622e-01
    z[4,6,2]  R1423     -1.4928828179836273e-01
    z[4,6,2]  R1424     -1.3702154159545898e-01
    z[4,6,2]  R1425     -5.3955212235450745e-02
    z[4,6,2]  R1426     2.1143613755702972e-01
    z[4,6,2]  R1427     1.2658575177192688e-01
    z[4,6,2]  R1428     9.6190765500068665e-02
    z[4,6,2]  R1429     3.9736970211379230e-04
    z[4,6,2]  R1430     -4.7123380005359650e-02
    z[4,6,2]  R1431     -7.1347869932651520e-02
    z[4,6,2]  R1432     -8.1454485654830933e-02
    z[4,6,2]  R1433     -1.7367942631244659e-01
    z[4,6,2]  R1434     1.4274470508098602e-01
    z[4,6,2]  R1435     -1.7110915854573250e-02
    z[4,6,2]  R1436     -1.8773204088211060e-01
    z[4,6,2]  R1437     4.8219002783298492e-02
    z[4,6,2]  R1438     2.4617350101470947e-01
    z[4,6,2]  R1439     0.0839306190609932
    z[4,6,2]  R1440     2.1931204199790955e-01
    z[4,6,2]  R1441     -1.4509050548076630e-01
    z[4,6,2]  R1442     -1.1842354387044907e-01
    z[4,6,2]  R1443     -3.0637830495834351e-01
    z[4,6,2]  R1444     -2.6090177893638611e-01
    z[4,6,2]  R1445     -1.3556927442550659e-01
    z[4,6,2]  R1446     -1.7798444628715515e-01
    z[4,6,2]  R1447     -5.5900290608406067e-02
    z[4,6,2]  R1448     -2.9828870296478271e-01
    z[4,6,2]  R1449     -1.3427162542939186e-02
    z[4,6,2]  R1450     4.1312953829765320e-01
    z[4,6,2]  R1451     -3.4522205591201782e-01
    z[4,6,2]  R1452     0.289383202791214
    z[4,6,2]  R1453     1.4852622523903847e-02
    z[4,6,2]  R1454     2.1137434244155884e-01
    z[4,6,2]  R1455     6.5856881439685822e-02
    z[4,6,2]  R1456     2.1253588795661926e-01
    z[4,6,2]  R1457     1.0035727173089981e-01
    z[4,6,2]  R1458     1.6829672455787659e-01
    z[4,6,2]  R1459     -1.9416575133800507e-01
    z[4,6,2]  R1460     -1.8333847820758820e-01
    z[4,6,2]  R1461     -5.2161026000976562e-01
    z[4,6,2]  R1462     3.4443494677543640e-01
    z[4,6,2]  R1463     2.2141848504543304e-01
    z[4,6,2]  R1464     1.4933940954506397e-02
    z[4,6,2]  R1465     -1.5962953865528107e-01
    z[4,6,2]  R1466     3.8431543856859207e-02
    z[4,6,2]  R1467     0.095056913793087
    z[4,6,2]  R1468     -9.1186009347438812e-02
    z[4,6,2]  R1469     2.2850561141967773e-01
    z[4,6,2]  R1470     1.8350470066070557e-01
    z[4,6,2]  R1471     -1.0992185026407242e-01
    z[4,6,2]  R1472     -6.4968854188919067e-02
    z[4,6,2]  R1473     1.5266297757625580e-01
    z[4,6,2]  R1474     0.0628947913646698
    z[4,6,2]  R1475     -1.3236106932163239e-01
    z[4,6,2]  R1476     1.4494094066321850e-02
    z[4,6,2]  R1477     2.4858203530311584e-01
    z[4,6,2]  R1478     -9.9425628781318665e-02
    z[4,6,2]  R1479     -4.5960783958435059e-01
    z[4,6,2]  R1480     -1.3062451779842377e-01
    z[4,6,2]  R1481     2.0609753206372261e-02
    z[4,6,2]  R1482     -1.2111578881740570e-01
    z[4,6,2]  R1483     -5.5107390880584717e-01
    z[4,6,2]  R1484     -6.5184015035629272e-01
    z[4,6,2]  R1485     1.5165668725967407e-01
    z[4,6,2]  R1486     9.4467557966709137e-02
    z[4,6,2]  R1487     3.7212669849395752e-01
    z[4,6,2]  R1488     0.510319173336029
    z[4,6,2]  R1489     -7.9994976520538330e-01
    z[4,6,2]  R1490     -2.0820085704326630e-01
    z[4,6,2]  R1491     -2.5144013762474060e-01
    z[4,6,2]  R1492     -4.7872957587242126e-01
    z[4,6,2]  R1493     3.4862619638442993e-01
    z[4,6,2]  R1494     -4.0366011857986450e-01
    z[4,6,2]  R1495     -1.7312115430831909e-01
    z[4,6,2]  R1496     -3.5301384329795837e-01
    z[4,6,2]  R1497     -3.4765001386404037e-02
    z[4,6,2]  R1498     4.2130580544471741e-01
    z[4,6,2]  R1499     -5.7477647066116333e-01
    z[4,6,2]  R1500     -0.645080029964447
    z[4,6,2]  R1501     -5.4246175289154053e-01
    z[4,6,2]  R1502     -1.1096552014350891e-01
    z[4,6,2]  R1503     -2.7713960409164429e-01
    z[4,6,2]  R1504     1.6731685400009155e-01
    z[4,6,2]  R1505     -5.4264806210994720e-02
    z[4,6,2]  R1506     -2.9492408037185669e-01
    z[4,6,2]  R1507     -5.9931054711341858e-02
    z[4,6,2]  R1508     5.0907637923955917e-02
    z[4,6,2]  R1509     -5.9057138860225677e-02
    z[4,6,2]  R1510     1.0383627563714981e-01
    z[4,6,2]  R1511     -4.1855287551879883e-01
    z[4,6,2]  R1512     -2.0485353469848633e-01
    z[4,6,2]  R1513     1.7963831126689911e-01
    z[4,6,2]  R1514     -3.7469189614057541e-02
    z[4,6,2]  R1515     -2.6761874556541443e-01
    z[4,6,2]  R1516     -3.3364719152450562e-01
    z[4,6,2]  R1517     3.4020170569419861e-02
    z[4,6,2]  R1518     1.9581666216254234e-02
    z[4,6,2]  R1519     2.5441735982894897e-02
    z[4,6,2]  R1520     -0.199344664812088
    z[4,6,2]  R1521     4.2731454968452454e-01
    z[4,6,2]  R1522     2.1485167741775513e-01
    z[4,6,2]  R1523     -3.7014293670654297e-01
    z[4,6,2]  R1524     3.8449708372354507e-02
    z[4,6,2]  R1525     -2.8615200892090797e-02
    z[4,6,2]  R1526     -3.9972978830337524e-01
    z[4,6,3]  R41       -1
    z[4,6,3]  R59       1
    z[4,6,3]  R1402     -1
    z[4,6,3]  R1403     1
    z[4,6,3]  R1410     -6.6604685783386230e-01
    z[4,6,3]  R1411     1.4893932640552521e-01
    z[4,6,3]  R1412     3.7170371413230896e-01
    z[4,6,3]  R1413     -1.8350727856159210e-01
    z[4,6,3]  R1414     0.0356985442340374
    z[4,6,3]  R1415     -4.7900900244712830e-01
    z[4,6,3]  R1416     -8.2958471775054932e-01
    z[4,6,3]  R1417     -4.9599045515060425e-01
    z[4,6,3]  R1418     -3.3634263277053833e-01
    z[4,6,3]  R1419     -4.4997262954711914e-01
    z[4,6,3]  R1420     0.351880818605423
    z[4,6,3]  R1421     1.5563932061195374e-01
    z[4,6,3]  R1422     0.0896289050579071
    z[4,6,3]  R1423     4.4433671981096268e-02
    z[4,6,3]  R1424     1.1404450237751007e-01
    z[4,6,3]  R1425     0.393184632062912
    z[4,6,3]  R1426     -4.0812357328832150e-03
    z[4,6,3]  R1427     3.0470450874418020e-03
    z[4,6,3]  R1428     4.4962140917778015e-01
    z[4,6,3]  R1429     -2.7278661727905273e-01
    z[4,6,3]  R1430     -5.2548497915267944e-01
    z[4,6,3]  R1431     -7.1449923515319824e-01
    z[4,6,3]  R1432     8.6602732539176941e-02
    z[4,6,3]  R1433     -0.456758052110672
    z[4,6,3]  R1434     5.5406648665666580e-02
    z[4,6,3]  R1435     5.1946036517620087e-02
    z[4,6,3]  R1436     4.9007901549339294e-01
    z[4,6,3]  R1437     -3.3907768130302429e-01
    z[4,6,3]  R1438     -2.9924616217613220e-01
    z[4,6,3]  R1439     -3.3888214826583862e-01
    z[4,6,3]  R1440     -5.9020549058914185e-01
    z[4,6,3]  R1441     -2.7884083986282349e-01
    z[4,6,3]  R1442     -5.5373167991638184e-01
    z[4,6,3]  R1443     -1.9600987434387207e-01
    z[4,6,3]  R1444     -3.7111577391624451e-01
    z[4,6,3]  R1445     2.6010829210281372e-01
    z[4,6,3]  R1446     8.1559962034225464e-01
    z[4,6,3]  R1447     1.2610229849815369e-01
    z[4,6,3]  R1448     9.3165948987007141e-02
    z[4,6,3]  R1449     -4.9079051613807678e-01
    z[4,6,3]  R1450     -4.9664461612701416e-01
    z[4,6,3]  R1451     3.9586505293846130e-01
    z[4,6,3]  R1452     2.1753889322280884e-01
    z[4,6,3]  R1453     -5.1467999815940857e-02
    z[4,6,3]  R1454     1.1947729438543320e-01
    z[4,6,3]  R1455     1.1300613731145859e-01
    z[4,6,3]  R1456     -3.8399152457714081e-02
    z[4,6,3]  R1457     3.9864072203636169e-01
    z[4,6,3]  R1458     -0.0781896784901619
    z[4,6,3]  R1459     5.0997996330261230e-01
    z[4,6,3]  R1460     -0.0290201585739851
    z[4,6,3]  R1461     3.3412650227546692e-02
    z[4,6,3]  R1462     6.9710515439510345e-02
    z[4,6,3]  R1463     3.3124664425849915e-01
    z[4,6,3]  R1464     9.6823759377002716e-02
    z[4,6,3]  R1465     2.7094164490699768e-01
    z[4,6,3]  R1466     1.2503567337989807e-01
    z[4,6,3]  R1467     1.2436323612928391e-01
    z[4,6,3]  R1468     -2.3279446363449097e-01
    z[4,6,3]  R1469     -5.4520197212696075e-02
    z[4,6,3]  R1470     -1.1272186040878296e-01
    z[4,6,3]  R1471     -3.9822015166282654e-01
    z[4,6,3]  R1472     1.9771383702754974e-01
    z[4,6,3]  R1473     -3.5733717679977417e-01
    z[4,6,3]  R1474     9.8374977707862854e-02
    z[4,6,3]  R1475     4.0437778830528259e-01
    z[4,6,3]  R1476     3.5644698143005371e-01
    z[4,6,3]  R1477     -3.9706024527549744e-01
    z[4,6,3]  R1478     2.9846101999282837e-01
    z[4,6,3]  R1479     2.7269285917282104e-01
    z[4,6,3]  R1480     1.0264895856380463e-01
    z[4,6,3]  R1481     2.5535422563552856e-01
    z[4,6,3]  R1482     4.0238106250762939e-01
    z[4,6,3]  R1483     -8.0770663917064667e-03
    z[4,6,3]  R1484     7.5806421227753162e-03
    z[4,6,3]  R1485     -1.4889647066593170e-01
    z[4,6,3]  R1486     1.0548835247755051e-01
    z[4,6,3]  R1487     -1.6698397696018219e-02
    z[4,6,3]  R1488     -3.6903306841850281e-01
    z[4,6,3]  R1489     3.1129187345504761e-01
    z[4,6,3]  R1490     2.8346312046051025e-01
    z[4,6,3]  R1491     7.2360301017761230e-01
    z[4,6,3]  R1492     4.1686362028121948e-01
    z[4,6,3]  R1493     1.5570640563964844e-01
    z[4,6,3]  R1494     1.2262795865535736e-01
    z[4,6,3]  R1495     -1.3377287983894348e-01
    z[4,6,3]  R1496     1.1306324601173401e-01
    z[4,6,3]  R1497     5.3718948364257812e-01
    z[4,6,3]  R1498     -0.571797788143158
    z[4,6,3]  R1499     2.1838736534118652e-01
    z[4,6,3]  R1500     3.0689904093742371e-01
    z[4,6,3]  R1501     6.3965070247650146e-01
    z[4,6,3]  R1502     5.1850110292434692e-01
    z[4,6,3]  R1503     5.0610125064849854e-01
    z[4,6,3]  R1504     2.2512586414813995e-01
    z[4,6,3]  R1505     5.3207403421401978e-01
    z[4,6,3]  R1506     6.9865804910659790e-01
    z[4,6,3]  R1507     -2.8843320906162262e-02
    z[4,6,3]  R1508     4.2975005507469177e-01
    z[4,6,3]  R1509     3.2536211609840393e-01
    z[4,6,3]  R1510     5.2024662494659424e-01
    z[4,6,3]  R1511     -1.0241288691759109e-01
    z[4,6,3]  R1512     0.801220178604126
    z[4,6,3]  R1513     4.1895386576652527e-01
    z[4,6,3]  R1514     2.0774005353450775e-01
    z[4,6,3]  R1515     2.7850806713104248e-01
    z[4,6,3]  R1516     -1.0500277578830719e-01
    z[4,6,3]  R1517     -3.9494130760431290e-02
    z[4,6,3]  R1518     -2.1544608473777771e-01
    z[4,6,3]  R1519     -7.8749559819698334e-02
    z[4,6,3]  R1520     8.2119709253311157e-01
    z[4,6,3]  R1521     -5.1762568950653076e-01
    z[4,6,3]  R1522     1.3576522469520569e-01
    z[4,6,3]  R1523     0.0986611545085907
    z[4,6,3]  R1524     7.8905093669891357e-01
    z[4,6,3]  R1525     -2.1489325165748596e-01
    z[4,6,3]  R1526     -4.4135209918022156e-01
    z[4,6,4]  R42       -1
    z[4,6,4]  R60       1
    z[4,6,4]  R1404     -1
    z[4,6,4]  R1405     1
    z[4,6,4]  R1410     -6.1221265792846680e-01
    z[4,6,4]  R1411     -4.4700881838798523e-01
    z[4,6,4]  R1412     1.2542865239083767e-02
    z[4,6,4]  R1413     -1.7818284034729004e-01
    z[4,6,4]  R1414     -3.4217327833175659e-02
    z[4,6,4]  R1415     -2.6628868654370308e-02
    z[4,6,4]  R1416     2.5206291675567627e-01
    z[4,6,4]  R1417     -4.1365686058998108e-01
    z[4,6,4]  R1418     5.7872142642736435e-02
    z[4,6,4]  R1419     3.1724950671195984e-01
    z[4,6,4]  R1420     -3.1405866146087646e-01
    z[4,6,4]  R1421     0.023549759760499
    z[4,6,4]  R1422     -1.1894471943378448e-01
    z[4,6,4]  R1423     -7.0711731910705566e-02
    z[4,6,4]  R1424     5.1908683031797409e-02
    z[4,6,4]  R1425     2.0215994119644165e-01
    z[4,6,4]  R1426     5.2272111177444458e-01
    z[4,6,4]  R1427     1.8284878134727478e-01
    z[4,6,4]  R1428     2.5019386410713196e-01
    z[4,6,4]  R1429     -2.1078962087631226e-01
    z[4,6,4]  R1430     1.0750237107276917e-01
    z[4,6,4]  R1431     -5.4194923490285873e-02
    z[4,6,4]  R1432     1.0144741833209991e-01
    z[4,6,4]  R1433     -3.7986236810684204e-01
    z[4,6,4]  R1434     9.0818911790847778e-02
    z[4,6,4]  R1435     -2.8622266650199890e-01
    z[4,6,4]  R1436     -6.6355979442596436e-01
    z[4,6,4]  R1437     -4.6573806554079056e-02
    z[4,6,4]  R1438     -1.8613596260547638e-01
    z[4,6,4]  R1439     4.7604110091924667e-02
    z[4,6,4]  R1440     -1.3970064930617809e-02
    z[4,6,4]  R1441     3.3509659767150879e-01
    z[4,6,4]  R1442     4.5216381549835205e-01
    z[4,6,4]  R1443     4.3756440281867981e-01
    z[4,6,4]  R1444     3.0622169375419617e-01
    z[4,6,4]  R1445     -3.3020820468664169e-02
    z[4,6,4]  R1446     -4.0312924981117249e-01
    z[4,6,4]  R1447     2.3207981884479523e-01
    z[4,6,4]  R1448     1.8537633121013641e-01
    z[4,6,4]  R1449     5.0928640365600586e-01
    z[4,6,4]  R1450     -1.3969862461090088e-01
    z[4,6,4]  R1451     3.4669709205627441e-01
    z[4,6,4]  R1452     -1.7271824181079865e-01
    z[4,6,4]  R1453     3.9200261235237122e-02
    z[4,6,4]  R1454     9.2002548277378082e-02
    z[4,6,4]  R1455     -1.8937504291534424e-01
    z[4,6,4]  R1456     -1.4360065758228302e-01
    z[4,6,4]  R1457     -2.8094735741615295e-01
    z[4,6,4]  R1458     -2.1369270980358124e-02
    z[4,6,4]  R1459     3.4329418092966080e-02
    z[4,6,4]  R1460     -6.6291856765747070e-01
    z[4,6,4]  R1461     -4.8803728818893433e-01
    z[4,6,4]  R1462     -1.5790884196758270e-01
    z[4,6,4]  R1463     -5.5078315734863281e-01
    z[4,6,4]  R1464     -8.3766520023345947e-02
    z[4,6,4]  R1465     -2.1506768465042114e-01
    z[4,6,4]  R1466     2.0711828768253326e-01
    z[4,6,4]  R1467     -3.0013337731361389e-02
    z[4,6,4]  R1468     2.7905574440956116e-01
    z[4,6,4]  R1469     -4.8334106802940369e-02
    z[4,6,4]  R1470     -3.0210144817829132e-02
    z[4,6,4]  R1471     5.2105122804641724e-01
    z[4,6,4]  R1472     -1.3227945193648338e-02
    z[4,6,4]  R1473     2.3158590495586395e-01
    z[4,6,4]  R1474     2.3669071495532990e-01
    z[4,6,4]  R1475     4.9811866134405136e-02
    z[4,6,4]  R1476     1.8622530996799469e-01
    z[4,6,4]  R1477     2.2148312628269196e-01
    z[4,6,4]  R1478     3.5426761955022812e-02
    z[4,6,4]  R1479     -2.9519531130790710e-01
    z[4,6,4]  R1480     4.0074518322944641e-01
    z[4,6,4]  R1481     -2.4200105667114258e-01
    z[4,6,4]  R1482     1.2927709519863129e-01
    z[4,6,4]  R1483     2.2059883177280426e-01
    z[4,6,4]  R1484     2.1980078890919685e-02
    z[4,6,4]  R1485     1.5698119997978210e-01
    z[4,6,4]  R1486     -7.6411046087741852e-02
    z[4,6,4]  R1487     -1.6664180159568787e-01
    z[4,6,4]  R1488     -3.8733837008476257e-01
    z[4,6,4]  R1489     -7.0992313325405121e-02
    z[4,6,4]  R1490     3.9768660068511963e-01
    z[4,6,4]  R1491     -1.9679825007915497e-01
    z[4,6,4]  R1492     -0.302804559469223
    z[4,6,4]  R1493     -3.0368554592132568e-01
    z[4,6,4]  R1494     1.0551684349775314e-01
    z[4,6,4]  R1495     -1.9355788826942444e-02
    z[4,6,4]  R1496     6.2445417046546936e-02
    z[4,6,4]  R1497     -1.5688581764698029e-01
    z[4,6,4]  R1498     -1.8737266957759857e-01
    z[4,6,4]  R1499     1.3259534537792206e-01
    z[4,6,4]  R1500     -1.9866687059402466e-01
    z[4,6,4]  R1501     -3.0559748411178589e-01
    z[4,6,4]  R1502     1.3698628544807434e-01
    z[4,6,4]  R1503     -5.0602819770574570e-02
    z[4,6,4]  R1504     -1.5582096576690674e-01
    z[4,6,4]  R1505     -4.6497333049774170e-01
    z[4,6,4]  R1506     6.6649354994297028e-02
    z[4,6,4]  R1507     1.2416181713342667e-01
    z[4,6,4]  R1508     3.8874413818120956e-02
    z[4,6,4]  R1509     1.6988384723663330e-01
    z[4,6,4]  R1510     -6.0564088821411133e-01
    z[4,6,4]  R1511     5.5132603645324707e-01
    z[4,6,4]  R1512     -6.8614810705184937e-02
    z[4,6,4]  R1513     -0.664197564125061
    z[4,6,4]  R1514     -4.2081409692764282e-01
    z[4,6,4]  R1515     -1.2498825043439865e-01
    z[4,6,4]  R1516     1.0058642923831940e-01
    z[4,6,4]  R1517     4.0197573602199554e-02
    z[4,6,4]  R1518     8.1931173801422119e-02
    z[4,6,4]  R1519     4.4640928506851196e-02
    z[4,6,4]  R1520     -1.0576204210519791e-01
    z[4,6,4]  R1521     6.1329182237386703e-02
    z[4,6,4]  R1522     6.8140506744384766e-02
    z[4,6,4]  R1523     1.2142547965049744e-01
    z[4,6,4]  R1524     -1.1520221084356308e-01
    z[4,6,4]  R1525     -1.8276037275791168e-01
    z[4,6,4]  R1526     2.3541533946990967e-01
    z[4,6,5]  R43       -1
    z[4,6,5]  R61       1
    z[4,6,5]  R1406     -1
    z[4,6,5]  R1407     1
    z[4,6,5]  R1410     1.2477570027112961e-01
    z[4,6,5]  R1411     7.4614512920379639e-01
    z[4,6,5]  R1412     6.0330617427825928e-01
    z[4,6,5]  R1413     6.8889522552490234e-01
    z[4,6,5]  R1414     7.2982782125473022e-01
    z[4,6,5]  R1415     4.0736641734838486e-02
    z[4,6,5]  R1416     3.1953501701354980e-01
    z[4,6,5]  R1417     5.8904135227203369e-01
    z[4,6,5]  R1418     7.8732502460479736e-01
    z[4,6,5]  R1419     7.2251111268997192e-01
    z[4,6,5]  R1420     -2.6467683911323547e-01
    z[4,6,5]  R1421     -3.2396441698074341e-01
    z[4,6,5]  R1422     -2.3210351169109344e-01
    z[4,6,5]  R1423     -2.4184677004814148e-01
    z[4,6,5]  R1424     -2.1703690290451050e-02
    z[4,6,5]  R1425     2.0627363026142120e-01
    z[4,6,5]  R1426     -2.4471905827522278e-01
    z[4,6,5]  R1427     -2.8761044144630432e-01
    z[4,6,5]  R1428     2.5541490316390991e-01
    z[4,6,5]  R1429     -2.9075062274932861e-01
    z[4,6,5]  R1430     -1.3820463418960571e-01
    z[4,6,5]  R1431     -3.2267281413078308e-01
    z[4,6,5]  R1432     -2.8438609838485718e-01
    z[4,6,5]  R1433     4.0883723646402359e-02
    z[4,6,5]  R1434     0.81397944688797
    z[4,6,5]  R1435     4.2648872733116150e-01
    z[4,6,5]  R1436     8.2856327295303345e-02
    z[4,6,5]  R1437     5.0448134541511536e-02
    z[4,6,5]  R1438     3.5628405213356018e-01
    z[4,6,5]  R1439     4.9841940402984619e-01
    z[4,6,5]  R1440     2.3097988963127136e-01
    z[4,6,5]  R1441     3.3193412423133850e-01
    z[4,6,5]  R1442     -9.6335709095001221e-02
    z[4,6,5]  R1443     1.0548584163188934e-02
    z[4,6,5]  R1444     -4.0202800184488297e-02
    z[4,6,5]  R1445     0.355111688375473
    z[4,6,5]  R1446     -1.7216829583048820e-02
    z[4,6,5]  R1447     3.4412688016891479e-01
    z[4,6,5]  R1448     5.2093285322189331e-01
    z[4,6,5]  R1449     -1.3080455362796783e-01
    z[4,6,5]  R1450     -1.1704389750957489e-01
    z[4,6,5]  R1451     1.8582293391227722e-01
    z[4,6,5]  R1452     -1.4288491010665894e-01
    z[4,6,5]  R1453     1.0768998414278030e-01
    z[4,6,5]  R1454     -2.9755065217614174e-02
    z[4,6,5]  R1455     1.2650847434997559e-01
    z[4,6,5]  R1456     6.8607471883296967e-02
    z[4,6,5]  R1457     3.4096702933311462e-01
    z[4,6,5]  R1458     2.5523445010185242e-01
    z[4,6,5]  R1459     -2.1300630643963814e-02
    z[4,6,5]  R1460     4.8581507802009583e-01
    z[4,6,5]  R1461     5.2268964052200317e-01
    z[4,6,5]  R1462     -1.1703015118837357e-01
    z[4,6,5]  R1463     4.3361055850982666e-01
    z[4,6,5]  R1464     -4.6812698245048523e-01
    z[4,6,5]  R1465     1.3619804382324219e-01
    z[4,6,5]  R1466     -2.6303318142890930e-01
    z[4,6,5]  R1467     3.7050571292638779e-02
    z[4,6,5]  R1468     -1.2478940188884735e-01
    z[4,6,5]  R1469     8.6288809776306152e-02
    z[4,6,5]  R1470     -1.6528807580471039e-01
    z[4,6,5]  R1471     3.5488995909690857e-01
    z[4,6,5]  R1472     1.9388712942600250e-01
    z[4,6,5]  R1473     -9.8234914243221283e-02
    z[4,6,5]  R1474     6.5929156541824341e-01
    z[4,6,5]  R1475     -1.6213320195674896e-01
    z[4,6,5]  R1476     3.0738005042076111e-01
    z[4,6,5]  R1477     3.4320649504661560e-01
    z[4,6,5]  R1478     -1.9283334910869598e-01
    z[4,6,5]  R1479     6.1310482025146484e-01
    z[4,6,5]  R1480     2.9591289162635803e-01
    z[4,6,5]  R1481     -1.7603531479835510e-01
    z[4,6,5]  R1482     8.6186133325099945e-02
    z[4,6,5]  R1483     2.8385239839553833e-01
    z[4,6,5]  R1484     2.4412062764167786e-01
    z[4,6,5]  R1485     5.2332830429077148e-01
    z[4,6,5]  R1486     4.1580680012702942e-01
    z[4,6,5]  R1487     -1.2333630770444870e-01
    z[4,6,5]  R1488     -0.0711502805352211
    z[4,6,5]  R1489     4.6585026383399963e-01
    z[4,6,5]  R1490     3.6016803979873657e-01
    z[4,6,5]  R1491     3.2151695340871811e-02
    z[4,6,5]  R1492     -4.0721049904823303e-01
    z[4,6,5]  R1493     1.1348453909158707e-01
    z[4,6,5]  R1494     -3.0042484402656555e-01
    z[4,6,5]  R1495     -9.7968660295009613e-02
    z[4,6,5]  R1496     -2.2801715135574341e-01
    z[4,6,5]  R1497     3.3695498108863831e-01
    z[4,6,5]  R1498     -1.9032275676727295e-01
    z[4,6,5]  R1499     2.3500597476959229e-01
    z[4,6,5]  R1500     0.0966220423579216
    z[4,6,5]  R1501     6.5530523657798767e-02
    z[4,6,5]  R1502     4.1757243871688843e-01
    z[4,6,5]  R1503     3.0980497598648071e-01
    z[4,6,5]  R1504     3.6398828029632568e-01
    z[4,6,5]  R1505     3.1032985448837280e-01
    z[4,6,5]  R1506     4.4034352898597717e-01
    z[4,6,5]  R1507     2.8430068492889404e-01
    z[4,6,5]  R1508     2.5482922792434692e-01
    z[4,6,5]  R1509     -1.6160987317562103e-01
    z[4,6,5]  R1510     2.4246735870838165e-01
    z[4,6,5]  R1511     -1.6973756253719330e-01
    z[4,6,5]  R1512     3.9245158433914185e-01
    z[4,6,5]  R1513     -7.2402499616146088e-02
    z[4,6,5]  R1514     -2.5813108682632446e-01
    z[4,6,5]  R1515     -2.4999319016933441e-01
    z[4,6,5]  R1516     -1.6648904979228973e-01
    z[4,6,5]  R1517     -3.2943961024284363e-01
    z[4,6,5]  R1518     -3.5980053246021271e-02
    z[4,6,5]  R1519     -3.1049215793609619e-01
    z[4,6,5]  R1520     2.8177076578140259e-01
    z[4,6,5]  R1521     -1.1477879434823990e-01
    z[4,6,5]  R1522     2.0424258708953857e-01
    z[4,6,5]  R1523     6.9125302135944366e-02
    z[4,6,5]  R1524     -7.8146345913410187e-02
    z[4,6,5]  R1525     -3.4167268872261047e-01
    z[4,6,5]  R1526     -3.8538447022438049e-01
    z[4,6,6]  R44       -1
    z[4,6,6]  R62       1
    z[4,6,6]  R1408     -1
    z[4,6,6]  R1409     1
    z[4,6,6]  R1410     2.5133961439132690e-01
    z[4,6,6]  R1411     2.5733998045325279e-02
    z[4,6,6]  R1412     -7.4962019920349121e-02
    z[4,6,6]  R1413     -2.9850602149963379e-01
    z[4,6,6]  R1414     -5.4284799098968506e-01
    z[4,6,6]  R1415     -6.1835199594497681e-01
    z[4,6,6]  R1416     2.3508971929550171e-01
    z[4,6,6]  R1417     -3.7726196646690369e-01
    z[4,6,6]  R1418     3.1346493959426880e-01
    z[4,6,6]  R1419     0.337494820356369
    z[4,6,6]  R1420     -1.6473412513732910e-01
    z[4,6,6]  R1421     1.6942480206489563e-01
    z[4,6,6]  R1422     2.9440093040466309e-01
    z[4,6,6]  R1423     5.0955861806869507e-01
    z[4,6,6]  R1424     -5.4874587804079056e-03
    z[4,6,6]  R1425     -3.4751974046230316e-02
    z[4,6,6]  R1426     -4.3802503496408463e-02
    z[4,6,6]  R1427     3.5226356238126755e-02
    z[4,6,6]  R1428     1.6212120652198792e-02
    z[4,6,6]  R1429     -3.4154140949249268e-01
    z[4,6,6]  R1430     2.5265011191368103e-01
    z[4,6,6]  R1431     5.4128278046846390e-02
    z[4,6,6]  R1432     -5.7553578168153763e-02
    z[4,6,6]  R1433     -3.8404011726379395e-01
    z[4,6,6]  R1434     2.1300770342350006e-02
    z[4,6,6]  R1435     8.4735400974750519e-02
    z[4,6,6]  R1436     1.5273508429527283e-01
    z[4,6,6]  R1437     -3.0224621295928955e-02
    z[4,6,6]  R1438     -3.0544428154826164e-02
    z[4,6,6]  R1439     -1.0236737877130508e-01
    z[4,6,6]  R1440     -1.8589726090431213e-01
    z[4,6,6]  R1441     2.1918751299381256e-03
    z[4,6,6]  R1442     0.079471655189991
    z[4,6,6]  R1443     1.1661176383495331e-01
    z[4,6,6]  R1444     -4.5812937617301941e-01
    z[4,6,6]  R1445     -9.5765674486756325e-03
    z[4,6,6]  R1446     1.1679705977439880e-01
    z[4,6,6]  R1447     -1.1486873030662537e-01
    z[4,6,6]  R1448     -4.6692779660224915e-01
    z[4,6,6]  R1449     1.4410948380827904e-02
    z[4,6,6]  R1450     -2.3125639557838440e-01
    z[4,6,6]  R1451     -2.1750238537788391e-01
    z[4,6,6]  R1452     3.6757946014404297e-01
    z[4,6,6]  R1453     1.0941742360591888e-01
    z[4,6,6]  R1454     2.4398863315582275e-02
    z[4,6,6]  R1455     0.0702752098441124
    z[4,6,6]  R1456     -2.9970180243253708e-02
    z[4,6,6]  R1457     1.3765922188758850e-01
    z[4,6,6]  R1458     -3.8214033842086792e-01
    z[4,6,6]  R1459     -2.1635919809341431e-01
    z[4,6,6]  R1460     1.9490335881710052e-01
    z[4,6,6]  R1461     -2.4053165316581726e-01
    z[4,6,6]  R1462     3.0572479963302612e-01
    z[4,6,6]  R1463     -1.2226716615259647e-02
    z[4,6,6]  R1464     -1.4560225419700146e-02
    z[4,6,6]  R1465     4.7664329409599304e-01
    z[4,6,6]  R1466     4.6030825376510620e-01
    z[4,6,6]  R1467     -2.3105631768703461e-01
    z[4,6,6]  R1468     -4.4470822811126709e-01
    z[4,6,6]  R1469     1.3618775643408298e-02
    z[4,6,6]  R1470     -0.049640953540802
    z[4,6,6]  R1471     -0.259581595659256
    z[4,6,6]  R1472     -3.6433029174804688e-01
    z[4,6,6]  R1473     2.9331985116004944e-01
    z[4,6,6]  R1474     1.3550363481044769e-01
    z[4,6,6]  R1475     1.5716609358787537e-01
    z[4,6,6]  R1476     0.46355140209198
    z[4,6,6]  R1477     2.0093612372875214e-02
    z[4,6,6]  R1478     1.1167913675308228e-02
    z[4,6,6]  R1479     6.5813146531581879e-02
    z[4,6,6]  R1480     1.8022309243679047e-01
    z[4,6,6]  R1481     9.1388203203678131e-02
    z[4,6,6]  R1482     5.4702490568161011e-01
    z[4,6,6]  R1483     1.7998608946800232e-01
    z[4,6,6]  R1484     5.0963789224624634e-01
    z[4,6,6]  R1485     1.6429116949439049e-02
    z[4,6,6]  R1486     -2.5223836302757263e-01
    z[4,6,6]  R1487     3.8169443607330322e-01
    z[4,6,6]  R1488     -8.0177947878837585e-02
    z[4,6,6]  R1489     0.0874348059296608
    z[4,6,6]  R1490     1.4457820355892181e-01
    z[4,6,6]  R1491     3.1224694848060608e-01
    z[4,6,6]  R1492     2.7112990617752075e-01
    z[4,6,6]  R1493     2.1874293684959412e-01
    z[4,6,6]  R1494     -2.8557786345481873e-01
    z[4,6,6]  R1495     -1.9834528863430023e-01
    z[4,6,6]  R1496     -5.3242433071136475e-01
    z[4,6,6]  R1497     3.0272516608238220e-01
    z[4,6,6]  R1498     -1.3332915306091309e-01
    z[4,6,6]  R1499     2.7723437547683716e-01
    z[4,6,6]  R1500     5.3015863895416260e-01
    z[4,6,6]  R1501     6.3868030905723572e-02
    z[4,6,6]  R1502     9.1345183551311493e-02
    z[4,6,6]  R1503     -6.0760229825973511e-01
    z[4,6,6]  R1504     -2.4147087242454290e-04
    z[4,6,6]  R1505     -5.2079045772552490e-01
    z[4,6,6]  R1506     -1.7207440733909607e-01
    z[4,6,6]  R1507     -5.1508295536041260e-01
    z[4,6,6]  R1508     3.1199935078620911e-01
    z[4,6,6]  R1509     3.9095902442932129e-01
    z[4,6,6]  R1510     -2.7082201838493347e-01
    z[4,6,6]  R1511     -2.7292063832283020e-01
    z[4,6,6]  R1512     -1.0957321152091026e-02
    z[4,6,6]  R1513     -2.5969070196151733e-01
    z[4,6,6]  R1514     -1.3700519502162933e-01
    z[4,6,6]  R1515     -4.0275490283966064e-01
    z[4,6,6]  R1516     -4.9255305528640747e-01
    z[4,6,6]  R1517     -2.0176558196544647e-01
    z[4,6,6]  R1518     -0.392668753862381
    z[4,6,6]  R1519     2.4300108850002289e-01
    z[4,6,6]  R1520     -0.00647188164293766
    z[4,6,6]  R1521     5.4791235923767090e-01
    z[4,6,6]  R1522     0.568831205368042
    z[4,6,6]  R1523     -2.7207210659980774e-01
    z[4,6,6]  R1524     4.0409117937088013e-01
    z[4,6,6]  R1525     -4.2171877622604370e-01
    z[4,6,6]  R1526     -1.4311835169792175e-02
    z[6,4,0]  R38       1
    z[6,4,0]  R56       -1
    z[6,4,0]  R1527     -1
    z[6,4,0]  R1528     1
    z[6,4,0]  R1541     -9.0638458728790283e-01
    z[6,4,0]  R1542     -8.2799595594406128e-01
    z[6,4,0]  R1543     -7.8493207693099976e-01
    z[6,4,0]  R1544     -7.0772647857666016e-01
    z[6,4,0]  R1545     -0.819678008556366
    z[6,4,0]  R1546     -6.6300272941589355e-01
    z[6,4,0]  R1547     -8.1264919042587280e-01
    z[6,4,0]  R1548     -6.8940824270248413e-01
    z[6,4,0]  R1549     -8.8037103414535522e-01
    z[6,4,0]  R1550     2.9375693202018738e-01
    z[6,4,0]  R1551     -3.8623297587037086e-04
    z[6,4,0]  R1552     4.9018543958663940e-01
    z[6,4,0]  R1553     4.9586838483810425e-01
    z[6,4,0]  R1554     4.3103596568107605e-01
    z[6,4,0]  R1555     2.0347057282924652e-01
    z[6,4,0]  R1556     3.9923486113548279e-01
    z[6,4,0]  R1557     0.421084463596344
    z[6,4,0]  R1558     2.6942405104637146e-01
    z[6,4,0]  R1559     3.8349777460098267e-01
    z[6,4,0]  R1560     3.8672599196434021e-01
    z[6,4,0]  R1561     0.599850058555603
    z[6,4,0]  R1562     3.9805805683135986e-01
    z[6,4,0]  R1563     9.7217820584774017e-02
    z[6,4,0]  R1564     3.7836232781410217e-01
    z[6,4,0]  R1565     2.1848320960998535e-01
    z[6,4,0]  R1566     4.0968227386474609e-01
    z[6,4,0]  R1567     5.7834142446517944e-01
    z[6,4,0]  R1568     -4.1519635915756226e-01
    z[6,4,0]  R1569     -2.0829349756240845e-01
    z[6,4,0]  R1570     1.6713143885135651e-01
    z[6,4,0]  R1571     0.291344553232193
    z[6,4,0]  R1572     2.0175081491470337e-01
    z[6,4,0]  R1573     -1.8293541669845581e-01
    z[6,4,0]  R1574     -1.5737058222293854e-01
    z[6,4,0]  R1575     -7.6309749856591225e-03
    z[6,4,0]  R1576     -3.4955191612243652e-01
    z[6,4,0]  R1577     -4.1043874621391296e-01
    z[6,4,0]  R1578     1.1732964962720871e-01
    z[6,4,0]  R1579     -4.1289508342742920e-01
    z[6,4,0]  R1580     6.7198120057582855e-02
    z[6,4,0]  R1581     1.4178267121315002e-01
    z[6,4,0]  R1582     -3.6966481804847717e-01
    z[6,4,0]  R1583     4.9518829584121704e-01
    z[6,4,0]  R1584     -2.0473115146160126e-01
    z[6,4,0]  R1585     -8.2797199487686157e-01
    z[6,4,0]  R1586     0.617081344127655
    z[6,4,0]  R1587     5.0851190090179443e-01
    z[6,4,0]  R1588     3.9375400543212891e-01
    z[6,4,0]  R1589     0.809958279132843
    z[6,4,0]  R1590     8.5605132579803467e-01
    z[6,4,0]  R1591     -2.9784919694066048e-02
    z[6,4,0]  R1592     -0.286978155374527
    z[6,4,0]  R1593     1.6640554368495941e-01
    z[6,4,0]  R1594     7.2376525402069092e-01
    z[6,4,0]  R1595     -1.7412005364894867e-01
    z[6,4,0]  R1596     8.0571383237838745e-02
    z[6,4,0]  R1597     8.3700728416442871e-01
    z[6,4,0]  R1598     1.3343612849712372e-01
    z[6,4,0]  R1599     -6.4536012709140778e-02
    z[6,4,0]  R1600     4.4132387638092041e-01
    z[6,4,0]  R1601     6.9306713342666626e-01
    z[6,4,0]  R1602     -2.6543736457824707e-01
    z[6,4,0]  R1603     4.8704367876052856e-01
    z[6,4,0]  R1604     3.5728746652603149e-01
    z[6,4,0]  R1605     2.4972066283226013e-01
    z[6,4,0]  R1606     2.2820445895195007e-01
    z[6,4,0]  R1607     4.4021755456924438e-01
    z[6,4,0]  R1608     8.7229609489440918e-01
    z[6,4,0]  R1609     1.6437853872776031e-01
    z[6,4,0]  R1610     4.1851267218589783e-01
    z[6,4,0]  R1611     -9.3097686767578125e-02
    z[6,4,0]  R1612     0.0915379747748375
    z[6,4,0]  R1613     -0.0588078498840332
    z[6,4,0]  R1614     4.6570891141891479e-01
    z[6,4,0]  R1615     -3.0314895510673523e-01
    z[6,4,0]  R1616     3.5545620322227478e-01
    z[6,4,0]  R1617     -2.0369479060173035e-01
    z[6,4,0]  R1618     -1.8442565202713013e-01
    z[6,4,0]  R1619     4.4914808869361877e-01
    z[6,4,0]  R1620     5.8731153607368469e-02
    z[6,4,0]  R1621     0.0049970424734056
    z[6,4,0]  R1622     -3.4934845566749573e-01
    z[6,4,0]  R1623     -7.5006228685379028e-01
    z[6,4,0]  R1624     4.0946078300476074e-01
    z[6,4,0]  R1625     -1.1233063042163849e-01
    z[6,4,0]  R1626     7.2808766365051270e-01
    z[6,4,0]  R1627     -2.4780279025435448e-02
    z[6,4,0]  R1628     -3.3136874437332153e-02
    z[6,4,0]  R1629     3.3650982379913330e-01
    z[6,4,0]  R1630     3.7405374646186829e-01
    z[6,4,0]  R1631     -1.5911825001239777e-01
    z[6,4,0]  R1632     -8.3460539579391479e-02
    z[6,4,0]  R1633     -2.9796180129051208e-01
    z[6,4,0]  R1634     -0.10040283203125
    z[6,4,0]  R1635     -1.1207935959100723e-01
    z[6,4,0]  R1636     -5.4521399736404419e-01
    z[6,4,0]  R1637     2.1134330017957836e-04
    z[6,4,0]  R1638     1.8737228214740753e-01
    z[6,4,0]  R1639     -3.7565141916275024e-01
    z[6,4,0]  R1640     -1.3508066534996033e-01
    z[6,4,0]  R1641     7.3875255882740021e-02
    z[6,4,0]  R1642     2.6147386431694031e-01
    z[6,4,0]  R1643     -5.3577542304992676e-01
    z[6,4,0]  R1644     4.5376780629158020e-01
    z[6,4,0]  R1645     6.9701528549194336e-01
    z[6,4,0]  R1646     -2.9086044430732727e-01
    z[6,4,0]  R1647     6.3951069116592407e-01
    z[6,4,0]  R1648     0.605835497379303
    z[6,4,0]  R1649     7.0761835575103760e-01
    z[6,4,0]  R1650     3.8629552721977234e-01
    z[6,4,0]  R1651     3.6952725052833557e-01
    z[6,4,0]  R1652     -9.5478974282741547e-02
    z[6,4,0]  R1653     -5.1158881187438965e-01
    z[6,4,0]  R1654     -4.5761802792549133e-01
    z[6,4,0]  R1655     -4.9912708997726440e-01
    z[6,4,0]  R1656     5.7854449748992920e-01
    z[6,4,0]  R1657     -2.5291821360588074e-01
    z[6,4,1]  R39       1
    z[6,4,1]  R57       -1
    z[6,4,1]  R1529     -1
    z[6,4,1]  R1530     1
    z[6,4,1]  R1541     2.3567005991935730e-01
    z[6,4,1]  R1542     -4.1897028684616089e-02
    z[6,4,1]  R1543     2.8792524710297585e-02
    z[6,4,1]  R1544     -1.2074025720357895e-01
    z[6,4,1]  R1545     -8.2762926816940308e-02
    z[6,4,1]  R1546     -1.4048515260219574e-01
    z[6,4,1]  R1547     4.6277213841676712e-02
    z[6,4,1]  R1548     -1.1682908982038498e-01
    z[6,4,1]  R1549     -1.0781950503587723e-01
    z[6,4,1]  R1550     -2.0093406736850739e-01
    z[6,4,1]  R1551     -8.9190477132797241e-01
    z[6,4,1]  R1552     -3.7189406156539917e-01
    z[6,4,1]  R1553     -4.8617777228355408e-01
    z[6,4,1]  R1554     -5.5693954229354858e-01
    z[6,4,1]  R1555     -6.9330793619155884e-01
    z[6,4,1]  R1556     -7.2400510311126709e-01
    z[6,4,1]  R1557     8.9146637916564941e-01
    z[6,4,1]  R1558     9.2655897140502930e-01
    z[6,4,1]  R1559     8.8261890411376953e-01
    z[6,4,1]  R1560     0.881799578666687
    z[6,4,1]  R1561     -5.0700485706329346e-01
    z[6,4,1]  R1562     -7.7167344093322754e-01
    z[6,4,1]  R1563     -8.0269873142242432e-01
    z[6,4,1]  R1564     -3.3003348112106323e-01
    z[6,4,1]  R1565     -3.3140763640403748e-01
    z[6,4,1]  R1566     -7.5931972265243530e-01
    z[6,4,1]  R1567     -1.2345468252897263e-01
    z[6,4,1]  R1568     -7.6918292045593262e-01
    z[6,4,1]  R1569     -0.752150297164917
    z[6,4,1]  R1570     -7.9434764385223389e-01
    z[6,4,1]  R1571     -9.1375911235809326e-01
    z[6,4,1]  R1572     -7.7818918228149414e-01
    z[6,4,1]  R1573     -9.4941031932830811e-01
    z[6,4,1]  R1574     -9.4771158695220947e-01
    z[6,4,1]  R1575     -6.0370171070098877e-01
    z[6,4,1]  R1576     -8.1486070156097412e-01
    z[6,4,1]  R1577     -7.2885221242904663e-01
    z[6,4,1]  R1578     -6.8084597587585449e-01
    z[6,4,1]  R1579     -7.7136713266372681e-01
    z[6,4,1]  R1580     -7.2400116920471191e-01
    z[6,4,1]  R1581     -0.770193874835968
    z[6,4,1]  R1582     -8.5195004940032959e-01
    z[6,4,1]  R1583     4.2647279798984528e-02
    z[6,4,1]  R1584     -8.0612915754318237e-01
    z[6,4,1]  R1585     -3.8849323987960815e-01
    z[6,4,1]  R1586     -3.4533193707466125e-01
    z[6,4,1]  R1587     -5.2539217472076416e-01
    z[6,4,1]  R1588     -3.1653749942779541e-01
    z[6,4,1]  R1589     -3.4983004443347454e-03
    z[6,4,1]  R1590     0.0690355971455574
    z[6,4,1]  R1591     -8.1956321001052856e-01
    z[6,4,1]  R1592     -5.9959208965301514e-01
    z[6,4,1]  R1593     -7.6063059270381927e-02
    z[6,4,1]  R1594     -2.0901305973529816e-01
    z[6,4,1]  R1595     -4.9557766318321228e-01
    z[6,4,1]  R1596     -5.0943940877914429e-01
    z[6,4,1]  R1597     -2.6115508750081062e-02
    z[6,4,1]  R1598     7.8820818662643433e-01
    z[6,4,1]  R1599     9.4797450304031372e-01
    z[6,4,1]  R1600     5.7311809062957764e-01
    z[6,4,1]  R1601     -9.0785082429647446e-03
    z[6,4,1]  R1602     -5.7964098453521729e-01
    z[6,4,1]  R1603     -4.8482900857925415e-01
    z[6,4,1]  R1604     -1.7932601273059845e-01
    z[6,4,1]  R1605     -3.6394849419593811e-01
    z[6,4,1]  R1606     -0.682121753692627
    z[6,4,1]  R1607     -7.4453867971897125e-02
    z[6,4,1]  R1608     6.0457970947027206e-02
    z[6,4,1]  R1609     -0.321254700422287
    z[6,4,1]  R1610     -1.4761339128017426e-01
    z[6,4,1]  R1611     -7.9079437255859375e-01
    z[6,4,1]  R1612     -8.0034458637237549e-01
    z[6,4,1]  R1613     -8.2423675060272217e-01
    z[6,4,1]  R1614     -5.2353560924530029e-02
    z[6,4,1]  R1615     -5.6139910221099854e-01
    z[6,4,1]  R1616     -1.7574384808540344e-01
    z[6,4,1]  R1617     -4.8669952154159546e-01
    z[6,4,1]  R1618     0.811751663684845
    z[6,4,1]  R1619     0.639335036277771
    z[6,4,1]  R1620     7.7055817842483521e-01
    z[6,4,1]  R1621     -9.2000114917755127e-01
    z[6,4,1]  R1622     -8.1789934635162354e-01
    z[6,4,1]  R1623     -5.2259933948516846e-01
    z[6,4,1]  R1624     -0.166182741522789
    z[6,4,1]  R1625     -0.468726247549057
    z[6,4,1]  R1626     -1.8806332349777222e-01
    z[6,4,1]  R1627     8.7126356363296509e-01
    z[6,4,1]  R1628     4.3835404515266418e-01
    z[6,4,1]  R1629     7.1538448333740234e-01
    z[6,4,1]  R1630     5.4896432161331177e-01
    z[6,4,1]  R1631     -2.1109507977962494e-01
    z[6,4,1]  R1632     3.6115714907646179e-01
    z[6,4,1]  R1633     5.0819098949432373e-01
    z[6,4,1]  R1634     6.0065197944641113e-01
    z[6,4,1]  R1635     2.9567638039588928e-01
    z[6,4,1]  R1636     -2.9722964763641357e-01
    z[6,4,1]  R1637     -2.6562201976776123e-01
    z[6,4,1]  R1638     -1.9744651019573212e-01
    z[6,4,1]  R1639     -1.0959574580192566e-01
    z[6,4,1]  R1640     -1.5208879113197327e-01
    z[6,4,1]  R1641     -7.6956021785736084e-01
    z[6,4,1]  R1642     -8.6423909664154053e-01
    z[6,4,1]  R1643     -7.2976911067962646e-01
    z[6,4,1]  R1644     -6.6835129261016846e-01
    z[6,4,1]  R1645     -6.9223767518997192e-01
    z[6,4,1]  R1646     -0.820530116558075
    z[6,4,1]  R1647     4.5963096618652344e-01
    z[6,4,1]  R1648     7.0677846670150757e-01
    z[6,4,1]  R1649     3.9970946311950684e-01
    z[6,4,1]  R1650     0.728522002696991
    z[6,4,1]  R1651     -7.0043218135833740e-01
    z[6,4,1]  R1652     -6.0439997911453247e-01
    z[6,4,1]  R1653     -7.9351294040679932e-01
    z[6,4,1]  R1654     -5.0827115774154663e-01
    z[6,4,1]  R1655     2.3698510229587555e-01
    z[6,4,1]  R1656     6.2553894519805908e-01
    z[6,4,1]  R1657     4.3601259589195251e-01
    z[6,4,2]  R40       1
    z[6,4,2]  R58       -1
    z[6,4,2]  R1531     -1
    z[6,4,2]  R1532     1
    z[6,4,2]  R1541     4.8219002783298492e-02
    z[6,4,2]  R1542     2.4617350101470947e-01
    z[6,4,2]  R1543     0.0839306190609932
    z[6,4,2]  R1544     2.1931204199790955e-01
    z[6,4,2]  R1545     -1.4509050548076630e-01
    z[6,4,2]  R1546     -1.1842354387044907e-01
    z[6,4,2]  R1547     -3.0637830495834351e-01
    z[6,4,2]  R1548     -2.6090177893638611e-01
    z[6,4,2]  R1549     -1.3556927442550659e-01
    z[6,4,2]  R1550     -1.7798444628715515e-01
    z[6,4,2]  R1551     -5.5900290608406067e-02
    z[6,4,2]  R1552     -2.9828870296478271e-01
    z[6,4,2]  R1553     -1.3427162542939186e-02
    z[6,4,2]  R1554     4.1312953829765320e-01
    z[6,4,2]  R1555     -3.4522205591201782e-01
    z[6,4,2]  R1556     0.289383202791214
    z[6,4,2]  R1557     1.4852622523903847e-02
    z[6,4,2]  R1558     2.1137434244155884e-01
    z[6,4,2]  R1559     6.5856881439685822e-02
    z[6,4,2]  R1560     2.1253588795661926e-01
    z[6,4,2]  R1561     1.0035727173089981e-01
    z[6,4,2]  R1562     1.6829672455787659e-01
    z[6,4,2]  R1563     -1.9416575133800507e-01
    z[6,4,2]  R1564     -1.8333847820758820e-01
    z[6,4,2]  R1565     -5.2161026000976562e-01
    z[6,4,2]  R1566     3.4443494677543640e-01
    z[6,4,2]  R1567     2.2141848504543304e-01
    z[6,4,2]  R1568     1.4933940954506397e-02
    z[6,4,2]  R1569     -1.5962953865528107e-01
    z[6,4,2]  R1570     3.8431543856859207e-02
    z[6,4,2]  R1571     0.095056913793087
    z[6,4,2]  R1572     -9.1186009347438812e-02
    z[6,4,2]  R1573     2.2850561141967773e-01
    z[6,4,2]  R1574     1.8350470066070557e-01
    z[6,4,2]  R1575     -1.0992185026407242e-01
    z[6,4,2]  R1576     -6.4968854188919067e-02
    z[6,4,2]  R1577     1.5266297757625580e-01
    z[6,4,2]  R1578     0.0628947913646698
    z[6,4,2]  R1579     -1.3236106932163239e-01
    z[6,4,2]  R1580     1.4494094066321850e-02
    z[6,4,2]  R1581     2.4858203530311584e-01
    z[6,4,2]  R1582     -9.9425628781318665e-02
    z[6,4,2]  R1583     -4.5960783958435059e-01
    z[6,4,2]  R1584     -1.3062451779842377e-01
    z[6,4,2]  R1585     2.0609753206372261e-02
    z[6,4,2]  R1586     -1.2111578881740570e-01
    z[6,4,2]  R1587     -5.5107390880584717e-01
    z[6,4,2]  R1588     -6.5184015035629272e-01
    z[6,4,2]  R1589     1.5165668725967407e-01
    z[6,4,2]  R1590     9.4467557966709137e-02
    z[6,4,2]  R1591     3.7212669849395752e-01
    z[6,4,2]  R1592     0.510319173336029
    z[6,4,2]  R1593     -7.9994976520538330e-01
    z[6,4,2]  R1594     -2.0820085704326630e-01
    z[6,4,2]  R1595     -2.5144013762474060e-01
    z[6,4,2]  R1596     -4.7872957587242126e-01
    z[6,4,2]  R1597     3.4862619638442993e-01
    z[6,4,2]  R1598     -4.0366011857986450e-01
    z[6,4,2]  R1599     -1.7312115430831909e-01
    z[6,4,2]  R1600     -3.5301384329795837e-01
    z[6,4,2]  R1601     -3.4765001386404037e-02
    z[6,4,2]  R1602     4.2130580544471741e-01
    z[6,4,2]  R1603     -5.7477647066116333e-01
    z[6,4,2]  R1604     -0.645080029964447
    z[6,4,2]  R1605     -5.4246175289154053e-01
    z[6,4,2]  R1606     -1.1096552014350891e-01
    z[6,4,2]  R1607     -2.7713960409164429e-01
    z[6,4,2]  R1608     1.6731685400009155e-01
    z[6,4,2]  R1609     -5.4264806210994720e-02
    z[6,4,2]  R1610     -2.9492408037185669e-01
    z[6,4,2]  R1611     -5.9931054711341858e-02
    z[6,4,2]  R1612     5.0907637923955917e-02
    z[6,4,2]  R1613     -5.9057138860225677e-02
    z[6,4,2]  R1614     1.0383627563714981e-01
    z[6,4,2]  R1615     -4.1855287551879883e-01
    z[6,4,2]  R1616     -2.0485353469848633e-01
    z[6,4,2]  R1617     1.7963831126689911e-01
    z[6,4,2]  R1618     -3.7469189614057541e-02
    z[6,4,2]  R1619     -2.6761874556541443e-01
    z[6,4,2]  R1620     -3.3364719152450562e-01
    z[6,4,2]  R1621     3.4020170569419861e-02
    z[6,4,2]  R1622     1.9581666216254234e-02
    z[6,4,2]  R1623     2.5441735982894897e-02
    z[6,4,2]  R1624     -0.199344664812088
    z[6,4,2]  R1625     4.2731454968452454e-01
    z[6,4,2]  R1626     2.1485167741775513e-01
    z[6,4,2]  R1627     -3.7014293670654297e-01
    z[6,4,2]  R1628     3.8449708372354507e-02
    z[6,4,2]  R1629     -2.8615200892090797e-02
    z[6,4,2]  R1630     -3.9972978830337524e-01
    z[6,4,2]  R1631     -1.8154074251651764e-01
    z[6,4,2]  R1632     -2.8845322132110596e-01
    z[6,4,2]  R1633     -3.8084396719932556e-01
    z[6,4,2]  R1634     -0.0054810531437397
    z[6,4,2]  R1635     -2.6502066850662231e-01
    z[6,4,2]  R1636     -1.4793653041124344e-02
    z[6,4,2]  R1637     1.4257819950580597e-01
    z[6,4,2]  R1638     -1.3961243629455566e-01
    z[6,4,2]  R1639     1.1071675270795822e-01
    z[6,4,2]  R1640     1.3990931212902069e-01
    z[6,4,2]  R1641     -2.8753346204757690e-01
    z[6,4,2]  R1642     -1.6213077306747437e-01
    z[6,4,2]  R1643     -1.3287785649299622e-01
    z[6,4,2]  R1644     -1.4928828179836273e-01
    z[6,4,2]  R1645     -1.3702154159545898e-01
    z[6,4,2]  R1646     -5.3955212235450745e-02
    z[6,4,2]  R1647     2.1143613755702972e-01
    z[6,4,2]  R1648     1.2658575177192688e-01
    z[6,4,2]  R1649     9.6190765500068665e-02
    z[6,4,2]  R1650     3.9736970211379230e-04
    z[6,4,2]  R1651     -4.7123380005359650e-02
    z[6,4,2]  R1652     -7.1347869932651520e-02
    z[6,4,2]  R1653     -8.1454485654830933e-02
    z[6,4,2]  R1654     -1.7367942631244659e-01
    z[6,4,2]  R1655     1.4274470508098602e-01
    z[6,4,2]  R1656     -1.7110915854573250e-02
    z[6,4,2]  R1657     -1.8773204088211060e-01
    z[6,4,3]  R41       1
    z[6,4,3]  R59       -1
    z[6,4,3]  R1533     -1
    z[6,4,3]  R1534     1
    z[6,4,3]  R1541     -3.3907768130302429e-01
    z[6,4,3]  R1542     -2.9924616217613220e-01
    z[6,4,3]  R1543     -3.3888214826583862e-01
    z[6,4,3]  R1544     -5.9020549058914185e-01
    z[6,4,3]  R1545     -2.7884083986282349e-01
    z[6,4,3]  R1546     -5.5373167991638184e-01
    z[6,4,3]  R1547     -1.9600987434387207e-01
    z[6,4,3]  R1548     -3.7111577391624451e-01
    z[6,4,3]  R1549     2.6010829210281372e-01
    z[6,4,3]  R1550     8.1559962034225464e-01
    z[6,4,3]  R1551     1.2610229849815369e-01
    z[6,4,3]  R1552     9.3165948987007141e-02
    z[6,4,3]  R1553     -4.9079051613807678e-01
    z[6,4,3]  R1554     -4.9664461612701416e-01
    z[6,4,3]  R1555     3.9586505293846130e-01
    z[6,4,3]  R1556     2.1753889322280884e-01
    z[6,4,3]  R1557     -5.1467999815940857e-02
    z[6,4,3]  R1558     1.1947729438543320e-01
    z[6,4,3]  R1559     1.1300613731145859e-01
    z[6,4,3]  R1560     -3.8399152457714081e-02
    z[6,4,3]  R1561     3.9864072203636169e-01
    z[6,4,3]  R1562     -0.0781896784901619
    z[6,4,3]  R1563     5.0997996330261230e-01
    z[6,4,3]  R1564     -0.0290201585739851
    z[6,4,3]  R1565     3.3412650227546692e-02
    z[6,4,3]  R1566     6.9710515439510345e-02
    z[6,4,3]  R1567     3.3124664425849915e-01
    z[6,4,3]  R1568     9.6823759377002716e-02
    z[6,4,3]  R1569     2.7094164490699768e-01
    z[6,4,3]  R1570     1.2503567337989807e-01
    z[6,4,3]  R1571     1.2436323612928391e-01
    z[6,4,3]  R1572     -2.3279446363449097e-01
    z[6,4,3]  R1573     -5.4520197212696075e-02
    z[6,4,3]  R1574     -1.1272186040878296e-01
    z[6,4,3]  R1575     -3.9822015166282654e-01
    z[6,4,3]  R1576     1.9771383702754974e-01
    z[6,4,3]  R1577     -3.5733717679977417e-01
    z[6,4,3]  R1578     9.8374977707862854e-02
    z[6,4,3]  R1579     4.0437778830528259e-01
    z[6,4,3]  R1580     3.5644698143005371e-01
    z[6,4,3]  R1581     -3.9706024527549744e-01
    z[6,4,3]  R1582     2.9846101999282837e-01
    z[6,4,3]  R1583     2.7269285917282104e-01
    z[6,4,3]  R1584     1.0264895856380463e-01
    z[6,4,3]  R1585     2.5535422563552856e-01
    z[6,4,3]  R1586     4.0238106250762939e-01
    z[6,4,3]  R1587     -8.0770663917064667e-03
    z[6,4,3]  R1588     7.5806421227753162e-03
    z[6,4,3]  R1589     -1.4889647066593170e-01
    z[6,4,3]  R1590     1.0548835247755051e-01
    z[6,4,3]  R1591     -1.6698397696018219e-02
    z[6,4,3]  R1592     -3.6903306841850281e-01
    z[6,4,3]  R1593     3.1129187345504761e-01
    z[6,4,3]  R1594     2.8346312046051025e-01
    z[6,4,3]  R1595     7.2360301017761230e-01
    z[6,4,3]  R1596     4.1686362028121948e-01
    z[6,4,3]  R1597     1.5570640563964844e-01
    z[6,4,3]  R1598     1.2262795865535736e-01
    z[6,4,3]  R1599     -1.3377287983894348e-01
    z[6,4,3]  R1600     1.1306324601173401e-01
    z[6,4,3]  R1601     5.3718948364257812e-01
    z[6,4,3]  R1602     -0.571797788143158
    z[6,4,3]  R1603     2.1838736534118652e-01
    z[6,4,3]  R1604     3.0689904093742371e-01
    z[6,4,3]  R1605     6.3965070247650146e-01
    z[6,4,3]  R1606     5.1850110292434692e-01
    z[6,4,3]  R1607     5.0610125064849854e-01
    z[6,4,3]  R1608     2.2512586414813995e-01
    z[6,4,3]  R1609     5.3207403421401978e-01
    z[6,4,3]  R1610     6.9865804910659790e-01
    z[6,4,3]  R1611     -2.8843320906162262e-02
    z[6,4,3]  R1612     4.2975005507469177e-01
    z[6,4,3]  R1613     3.2536211609840393e-01
    z[6,4,3]  R1614     5.2024662494659424e-01
    z[6,4,3]  R1615     -1.0241288691759109e-01
    z[6,4,3]  R1616     0.801220178604126
    z[6,4,3]  R1617     4.1895386576652527e-01
    z[6,4,3]  R1618     2.0774005353450775e-01
    z[6,4,3]  R1619     2.7850806713104248e-01
    z[6,4,3]  R1620     -1.0500277578830719e-01
    z[6,4,3]  R1621     -3.9494130760431290e-02
    z[6,4,3]  R1622     -2.1544608473777771e-01
    z[6,4,3]  R1623     -7.8749559819698334e-02
    z[6,4,3]  R1624     8.2119709253311157e-01
    z[6,4,3]  R1625     -5.1762568950653076e-01
    z[6,4,3]  R1626     1.3576522469520569e-01
    z[6,4,3]  R1627     0.0986611545085907
    z[6,4,3]  R1628     7.8905093669891357e-01
    z[6,4,3]  R1629     -2.1489325165748596e-01
    z[6,4,3]  R1630     -4.4135209918022156e-01
    z[6,4,3]  R1631     -6.6604685783386230e-01
    z[6,4,3]  R1632     1.4893932640552521e-01
    z[6,4,3]  R1633     3.7170371413230896e-01
    z[6,4,3]  R1634     -1.8350727856159210e-01
    z[6,4,3]  R1635     0.0356985442340374
    z[6,4,3]  R1636     -4.7900900244712830e-01
    z[6,4,3]  R1637     -8.2958471775054932e-01
    z[6,4,3]  R1638     -4.9599045515060425e-01
    z[6,4,3]  R1639     -3.3634263277053833e-01
    z[6,4,3]  R1640     -4.4997262954711914e-01
    z[6,4,3]  R1641     0.351880818605423
    z[6,4,3]  R1642     1.5563932061195374e-01
    z[6,4,3]  R1643     0.0896289050579071
    z[6,4,3]  R1644     4.4433671981096268e-02
    z[6,4,3]  R1645     1.1404450237751007e-01
    z[6,4,3]  R1646     0.393184632062912
    z[6,4,3]  R1647     -4.0812357328832150e-03
    z[6,4,3]  R1648     3.0470450874418020e-03
    z[6,4,3]  R1649     4.4962140917778015e-01
    z[6,4,3]  R1650     -2.7278661727905273e-01
    z[6,4,3]  R1651     -5.2548497915267944e-01
    z[6,4,3]  R1652     -7.1449923515319824e-01
    z[6,4,3]  R1653     8.6602732539176941e-02
    z[6,4,3]  R1654     -0.456758052110672
    z[6,4,3]  R1655     5.5406648665666580e-02
    z[6,4,3]  R1656     5.1946036517620087e-02
    z[6,4,3]  R1657     4.9007901549339294e-01
    z[6,4,4]  R42       1
    z[6,4,4]  R60       -1
    z[6,4,4]  R1535     -1
    z[6,4,4]  R1536     1
    z[6,4,4]  R1541     -4.6573806554079056e-02
    z[6,4,4]  R1542     -1.8613596260547638e-01
    z[6,4,4]  R1543     4.7604110091924667e-02
    z[6,4,4]  R1544     -1.3970064930617809e-02
    z[6,4,4]  R1545     3.3509659767150879e-01
    z[6,4,4]  R1546     4.5216381549835205e-01
    z[6,4,4]  R1547     4.3756440281867981e-01
    z[6,4,4]  R1548     3.0622169375419617e-01
    z[6,4,4]  R1549     -3.3020820468664169e-02
    z[6,4,4]  R1550     -4.0312924981117249e-01
    z[6,4,4]  R1551     2.3207981884479523e-01
    z[6,4,4]  R1552     1.8537633121013641e-01
    z[6,4,4]  R1553     5.0928640365600586e-01
    z[6,4,4]  R1554     -1.3969862461090088e-01
    z[6,4,4]  R1555     3.4669709205627441e-01
    z[6,4,4]  R1556     -1.7271824181079865e-01
    z[6,4,4]  R1557     3.9200261235237122e-02
    z[6,4,4]  R1558     9.2002548277378082e-02
    z[6,4,4]  R1559     -1.8937504291534424e-01
    z[6,4,4]  R1560     -1.4360065758228302e-01
    z[6,4,4]  R1561     -2.8094735741615295e-01
    z[6,4,4]  R1562     -2.1369270980358124e-02
    z[6,4,4]  R1563     3.4329418092966080e-02
    z[6,4,4]  R1564     -6.6291856765747070e-01
    z[6,4,4]  R1565     -4.8803728818893433e-01
    z[6,4,4]  R1566     -1.5790884196758270e-01
    z[6,4,4]  R1567     -5.5078315734863281e-01
    z[6,4,4]  R1568     -8.3766520023345947e-02
    z[6,4,4]  R1569     -2.1506768465042114e-01
    z[6,4,4]  R1570     2.0711828768253326e-01
    z[6,4,4]  R1571     -3.0013337731361389e-02
    z[6,4,4]  R1572     2.7905574440956116e-01
    z[6,4,4]  R1573     -4.8334106802940369e-02
    z[6,4,4]  R1574     -3.0210144817829132e-02
    z[6,4,4]  R1575     5.2105122804641724e-01
    z[6,4,4]  R1576     -1.3227945193648338e-02
    z[6,4,4]  R1577     2.3158590495586395e-01
    z[6,4,4]  R1578     2.3669071495532990e-01
    z[6,4,4]  R1579     4.9811866134405136e-02
    z[6,4,4]  R1580     1.8622530996799469e-01
    z[6,4,4]  R1581     2.2148312628269196e-01
    z[6,4,4]  R1582     3.5426761955022812e-02
    z[6,4,4]  R1583     -2.9519531130790710e-01
    z[6,4,4]  R1584     4.0074518322944641e-01
    z[6,4,4]  R1585     -2.4200105667114258e-01
    z[6,4,4]  R1586     1.2927709519863129e-01
    z[6,4,4]  R1587     2.2059883177280426e-01
    z[6,4,4]  R1588     2.1980078890919685e-02
    z[6,4,4]  R1589     1.5698119997978210e-01
    z[6,4,4]  R1590     -7.6411046087741852e-02
    z[6,4,4]  R1591     -1.6664180159568787e-01
    z[6,4,4]  R1592     -3.8733837008476257e-01
    z[6,4,4]  R1593     -7.0992313325405121e-02
    z[6,4,4]  R1594     3.9768660068511963e-01
    z[6,4,4]  R1595     -1.9679825007915497e-01
    z[6,4,4]  R1596     -0.302804559469223
    z[6,4,4]  R1597     -3.0368554592132568e-01
    z[6,4,4]  R1598     1.0551684349775314e-01
    z[6,4,4]  R1599     -1.9355788826942444e-02
    z[6,4,4]  R1600     6.2445417046546936e-02
    z[6,4,4]  R1601     -1.5688581764698029e-01
    z[6,4,4]  R1602     -1.8737266957759857e-01
    z[6,4,4]  R1603     1.3259534537792206e-01
    z[6,4,4]  R1604     -1.9866687059402466e-01
    z[6,4,4]  R1605     -3.0559748411178589e-01
    z[6,4,4]  R1606     1.3698628544807434e-01
    z[6,4,4]  R1607     -5.0602819770574570e-02
    z[6,4,4]  R1608     -1.5582096576690674e-01
    z[6,4,4]  R1609     -4.6497333049774170e-01
    z[6,4,4]  R1610     6.6649354994297028e-02
    z[6,4,4]  R1611     1.2416181713342667e-01
    z[6,4,4]  R1612     3.8874413818120956e-02
    z[6,4,4]  R1613     1.6988384723663330e-01
    z[6,4,4]  R1614     -6.0564088821411133e-01
    z[6,4,4]  R1615     5.5132603645324707e-01
    z[6,4,4]  R1616     -6.8614810705184937e-02
    z[6,4,4]  R1617     -0.664197564125061
    z[6,4,4]  R1618     -4.2081409692764282e-01
    z[6,4,4]  R1619     -1.2498825043439865e-01
    z[6,4,4]  R1620     1.0058642923831940e-01
    z[6,4,4]  R1621     4.0197573602199554e-02
    z[6,4,4]  R1622     8.1931173801422119e-02
    z[6,4,4]  R1623     4.4640928506851196e-02
    z[6,4,4]  R1624     -1.0576204210519791e-01
    z[6,4,4]  R1625     6.1329182237386703e-02
    z[6,4,4]  R1626     6.8140506744384766e-02
    z[6,4,4]  R1627     1.2142547965049744e-01
    z[6,4,4]  R1628     -1.1520221084356308e-01
    z[6,4,4]  R1629     -1.8276037275791168e-01
    z[6,4,4]  R1630     2.3541533946990967e-01
    z[6,4,4]  R1631     -6.1221265792846680e-01
    z[6,4,4]  R1632     -4.4700881838798523e-01
    z[6,4,4]  R1633     1.2542865239083767e-02
    z[6,4,4]  R1634     -1.7818284034729004e-01
    z[6,4,4]  R1635     -3.4217327833175659e-02
    z[6,4,4]  R1636     -2.6628868654370308e-02
    z[6,4,4]  R1637     2.5206291675567627e-01
    z[6,4,4]  R1638     -4.1365686058998108e-01
    z[6,4,4]  R1639     5.7872142642736435e-02
    z[6,4,4]  R1640     3.1724950671195984e-01
    z[6,4,4]  R1641     -3.1405866146087646e-01
    z[6,4,4]  R1642     0.023549759760499
    z[6,4,4]  R1643     -1.1894471943378448e-01
    z[6,4,4]  R1644     -7.0711731910705566e-02
    z[6,4,4]  R1645     5.1908683031797409e-02
    z[6,4,4]  R1646     2.0215994119644165e-01
    z[6,4,4]  R1647     5.2272111177444458e-01
    z[6,4,4]  R1648     1.8284878134727478e-01
    z[6,4,4]  R1649     2.5019386410713196e-01
    z[6,4,4]  R1650     -2.1078962087631226e-01
    z[6,4,4]  R1651     1.0750237107276917e-01
    z[6,4,4]  R1652     -5.4194923490285873e-02
    z[6,4,4]  R1653     1.0144741833209991e-01
    z[6,4,4]  R1654     -3.7986236810684204e-01
    z[6,4,4]  R1655     9.0818911790847778e-02
    z[6,4,4]  R1656     -2.8622266650199890e-01
    z[6,4,4]  R1657     -6.6355979442596436e-01
    z[6,4,5]  R43       1
    z[6,4,5]  R61       -1
    z[6,4,5]  R1537     -1
    z[6,4,5]  R1538     1
    z[6,4,5]  R1541     5.0448134541511536e-02
    z[6,4,5]  R1542     3.5628405213356018e-01
    z[6,4,5]  R1543     4.9841940402984619e-01
    z[6,4,5]  R1544     2.3097988963127136e-01
    z[6,4,5]  R1545     3.3193412423133850e-01
    z[6,4,5]  R1546     -9.6335709095001221e-02
    z[6,4,5]  R1547     1.0548584163188934e-02
    z[6,4,5]  R1548     -4.0202800184488297e-02
    z[6,4,5]  R1549     0.355111688375473
    z[6,4,5]  R1550     -1.7216829583048820e-02
    z[6,4,5]  R1551     3.4412688016891479e-01
    z[6,4,5]  R1552     5.2093285322189331e-01
    z[6,4,5]  R1553     -1.3080455362796783e-01
    z[6,4,5]  R1554     -1.1704389750957489e-01
    z[6,4,5]  R1555     1.8582293391227722e-01
    z[6,4,5]  R1556     -1.4288491010665894e-01
    z[6,4,5]  R1557     1.0768998414278030e-01
    z[6,4,5]  R1558     -2.9755065217614174e-02
    z[6,4,5]  R1559     1.2650847434997559e-01
    z[6,4,5]  R1560     6.8607471883296967e-02
    z[6,4,5]  R1561     3.4096702933311462e-01
    z[6,4,5]  R1562     2.5523445010185242e-01
    z[6,4,5]  R1563     -2.1300630643963814e-02
    z[6,4,5]  R1564     4.8581507802009583e-01
    z[6,4,5]  R1565     5.2268964052200317e-01
    z[6,4,5]  R1566     -1.1703015118837357e-01
    z[6,4,5]  R1567     4.3361055850982666e-01
    z[6,4,5]  R1568     -4.6812698245048523e-01
    z[6,4,5]  R1569     1.3619804382324219e-01
    z[6,4,5]  R1570     -2.6303318142890930e-01
    z[6,4,5]  R1571     3.7050571292638779e-02
    z[6,4,5]  R1572     -1.2478940188884735e-01
    z[6,4,5]  R1573     8.6288809776306152e-02
    z[6,4,5]  R1574     -1.6528807580471039e-01
    z[6,4,5]  R1575     3.5488995909690857e-01
    z[6,4,5]  R1576     1.9388712942600250e-01
    z[6,4,5]  R1577     -9.8234914243221283e-02
    z[6,4,5]  R1578     6.5929156541824341e-01
    z[6,4,5]  R1579     -1.6213320195674896e-01
    z[6,4,5]  R1580     3.0738005042076111e-01
    z[6,4,5]  R1581     3.4320649504661560e-01
    z[6,4,5]  R1582     -1.9283334910869598e-01
    z[6,4,5]  R1583     6.1310482025146484e-01
    z[6,4,5]  R1584     2.9591289162635803e-01
    z[6,4,5]  R1585     -1.7603531479835510e-01
    z[6,4,5]  R1586     8.6186133325099945e-02
    z[6,4,5]  R1587     2.8385239839553833e-01
    z[6,4,5]  R1588     2.4412062764167786e-01
    z[6,4,5]  R1589     5.2332830429077148e-01
    z[6,4,5]  R1590     4.1580680012702942e-01
    z[6,4,5]  R1591     -1.2333630770444870e-01
    z[6,4,5]  R1592     -0.0711502805352211
    z[6,4,5]  R1593     4.6585026383399963e-01
    z[6,4,5]  R1594     3.6016803979873657e-01
    z[6,4,5]  R1595     3.2151695340871811e-02
    z[6,4,5]  R1596     -4.0721049904823303e-01
    z[6,4,5]  R1597     1.1348453909158707e-01
    z[6,4,5]  R1598     -3.0042484402656555e-01
    z[6,4,5]  R1599     -9.7968660295009613e-02
    z[6,4,5]  R1600     -2.2801715135574341e-01
    z[6,4,5]  R1601     3.3695498108863831e-01
    z[6,4,5]  R1602     -1.9032275676727295e-01
    z[6,4,5]  R1603     2.3500597476959229e-01
    z[6,4,5]  R1604     0.0966220423579216
    z[6,4,5]  R1605     6.5530523657798767e-02
    z[6,4,5]  R1606     4.1757243871688843e-01
    z[6,4,5]  R1607     3.0980497598648071e-01
    z[6,4,5]  R1608     3.6398828029632568e-01
    z[6,4,5]  R1609     3.1032985448837280e-01
    z[6,4,5]  R1610     4.4034352898597717e-01
    z[6,4,5]  R1611     2.8430068492889404e-01
    z[6,4,5]  R1612     2.5482922792434692e-01
    z[6,4,5]  R1613     -1.6160987317562103e-01
    z[6,4,5]  R1614     2.4246735870838165e-01
    z[6,4,5]  R1615     -1.6973756253719330e-01
    z[6,4,5]  R1616     3.9245158433914185e-01
    z[6,4,5]  R1617     -7.2402499616146088e-02
    z[6,4,5]  R1618     -2.5813108682632446e-01
    z[6,4,5]  R1619     -2.4999319016933441e-01
    z[6,4,5]  R1620     -1.6648904979228973e-01
    z[6,4,5]  R1621     -3.2943961024284363e-01
    z[6,4,5]  R1622     -3.5980053246021271e-02
    z[6,4,5]  R1623     -3.1049215793609619e-01
    z[6,4,5]  R1624     2.8177076578140259e-01
    z[6,4,5]  R1625     -1.1477879434823990e-01
    z[6,4,5]  R1626     2.0424258708953857e-01
    z[6,4,5]  R1627     6.9125302135944366e-02
    z[6,4,5]  R1628     -7.8146345913410187e-02
    z[6,4,5]  R1629     -3.4167268872261047e-01
    z[6,4,5]  R1630     -3.8538447022438049e-01
    z[6,4,5]  R1631     1.2477570027112961e-01
    z[6,4,5]  R1632     7.4614512920379639e-01
    z[6,4,5]  R1633     6.0330617427825928e-01
    z[6,4,5]  R1634     6.8889522552490234e-01
    z[6,4,5]  R1635     7.2982782125473022e-01
    z[6,4,5]  R1636     4.0736641734838486e-02
    z[6,4,5]  R1637     3.1953501701354980e-01
    z[6,4,5]  R1638     5.8904135227203369e-01
    z[6,4,5]  R1639     7.8732502460479736e-01
    z[6,4,5]  R1640     7.2251111268997192e-01
    z[6,4,5]  R1641     -2.6467683911323547e-01
    z[6,4,5]  R1642     -3.2396441698074341e-01
    z[6,4,5]  R1643     -2.3210351169109344e-01
    z[6,4,5]  R1644     -2.4184677004814148e-01
    z[6,4,5]  R1645     -2.1703690290451050e-02
    z[6,4,5]  R1646     2.0627363026142120e-01
    z[6,4,5]  R1647     -2.4471905827522278e-01
    z[6,4,5]  R1648     -2.8761044144630432e-01
    z[6,4,5]  R1649     2.5541490316390991e-01
    z[6,4,5]  R1650     -2.9075062274932861e-01
    z[6,4,5]  R1651     -1.3820463418960571e-01
    z[6,4,5]  R1652     -3.2267281413078308e-01
    z[6,4,5]  R1653     -2.8438609838485718e-01
    z[6,4,5]  R1654     4.0883723646402359e-02
    z[6,4,5]  R1655     0.81397944688797
    z[6,4,5]  R1656     4.2648872733116150e-01
    z[6,4,5]  R1657     8.2856327295303345e-02
    z[6,4,6]  R44       1
    z[6,4,6]  R62       -1
    z[6,4,6]  R1539     -1
    z[6,4,6]  R1540     1
    z[6,4,6]  R1541     -3.0224621295928955e-02
    z[6,4,6]  R1542     -3.0544428154826164e-02
    z[6,4,6]  R1543     -1.0236737877130508e-01
    z[6,4,6]  R1544     -1.8589726090431213e-01
    z[6,4,6]  R1545     2.1918751299381256e-03
    z[6,4,6]  R1546     0.079471655189991
    z[6,4,6]  R1547     1.1661176383495331e-01
    z[6,4,6]  R1548     -4.5812937617301941e-01
    z[6,4,6]  R1549     -9.5765674486756325e-03
    z[6,4,6]  R1550     1.1679705977439880e-01
    z[6,4,6]  R1551     -1.1486873030662537e-01
    z[6,4,6]  R1552     -4.6692779660224915e-01
    z[6,4,6]  R1553     1.4410948380827904e-02
    z[6,4,6]  R1554     -2.3125639557838440e-01
    z[6,4,6]  R1555     -2.1750238537788391e-01
    z[6,4,6]  R1556     3.6757946014404297e-01
    z[6,4,6]  R1557     1.0941742360591888e-01
    z[6,4,6]  R1558     2.4398863315582275e-02
    z[6,4,6]  R1559     0.0702752098441124
    z[6,4,6]  R1560     -2.9970180243253708e-02
    z[6,4,6]  R1561     1.3765922188758850e-01
    z[6,4,6]  R1562     -3.8214033842086792e-01
    z[6,4,6]  R1563     -2.1635919809341431e-01
    z[6,4,6]  R1564     1.9490335881710052e-01
    z[6,4,6]  R1565     -2.4053165316581726e-01
    z[6,4,6]  R1566     3.0572479963302612e-01
    z[6,4,6]  R1567     -1.2226716615259647e-02
    z[6,4,6]  R1568     -1.4560225419700146e-02
    z[6,4,6]  R1569     4.7664329409599304e-01
    z[6,4,6]  R1570     4.6030825376510620e-01
    z[6,4,6]  R1571     -2.3105631768703461e-01
    z[6,4,6]  R1572     -4.4470822811126709e-01
    z[6,4,6]  R1573     1.3618775643408298e-02
    z[6,4,6]  R1574     -0.049640953540802
    z[6,4,6]  R1575     -0.259581595659256
    z[6,4,6]  R1576     -3.6433029174804688e-01
    z[6,4,6]  R1577     2.9331985116004944e-01
    z[6,4,6]  R1578     1.3550363481044769e-01
    z[6,4,6]  R1579     1.5716609358787537e-01
    z[6,4,6]  R1580     0.46355140209198
    z[6,4,6]  R1581     2.0093612372875214e-02
    z[6,4,6]  R1582     1.1167913675308228e-02
    z[6,4,6]  R1583     6.5813146531581879e-02
    z[6,4,6]  R1584     1.8022309243679047e-01
    z[6,4,6]  R1585     9.1388203203678131e-02
    z[6,4,6]  R1586     5.4702490568161011e-01
    z[6,4,6]  R1587     1.7998608946800232e-01
    z[6,4,6]  R1588     5.0963789224624634e-01
    z[6,4,6]  R1589     1.6429116949439049e-02
    z[6,4,6]  R1590     -2.5223836302757263e-01
    z[6,4,6]  R1591     3.8169443607330322e-01
    z[6,4,6]  R1592     -8.0177947878837585e-02
    z[6,4,6]  R1593     0.0874348059296608
    z[6,4,6]  R1594     1.4457820355892181e-01
    z[6,4,6]  R1595     3.1224694848060608e-01
    z[6,4,6]  R1596     2.7112990617752075e-01
    z[6,4,6]  R1597     2.1874293684959412e-01
    z[6,4,6]  R1598     -2.8557786345481873e-01
    z[6,4,6]  R1599     -1.9834528863430023e-01
    z[6,4,6]  R1600     -5.3242433071136475e-01
    z[6,4,6]  R1601     3.0272516608238220e-01
    z[6,4,6]  R1602     -1.3332915306091309e-01
    z[6,4,6]  R1603     2.7723437547683716e-01
    z[6,4,6]  R1604     5.3015863895416260e-01
    z[6,4,6]  R1605     6.3868030905723572e-02
    z[6,4,6]  R1606     9.1345183551311493e-02
    z[6,4,6]  R1607     -6.0760229825973511e-01
    z[6,4,6]  R1608     -2.4147087242454290e-04
    z[6,4,6]  R1609     -5.2079045772552490e-01
    z[6,4,6]  R1610     -1.7207440733909607e-01
    z[6,4,6]  R1611     -5.1508295536041260e-01
    z[6,4,6]  R1612     3.1199935078620911e-01
    z[6,4,6]  R1613     3.9095902442932129e-01
    z[6,4,6]  R1614     -2.7082201838493347e-01
    z[6,4,6]  R1615     -2.7292063832283020e-01
    z[6,4,6]  R1616     -1.0957321152091026e-02
    z[6,4,6]  R1617     -2.5969070196151733e-01
    z[6,4,6]  R1618     -1.3700519502162933e-01
    z[6,4,6]  R1619     -4.0275490283966064e-01
    z[6,4,6]  R1620     -4.9255305528640747e-01
    z[6,4,6]  R1621     -2.0176558196544647e-01
    z[6,4,6]  R1622     -0.392668753862381
    z[6,4,6]  R1623     2.4300108850002289e-01
    z[6,4,6]  R1624     -0.00647188164293766
    z[6,4,6]  R1625     5.4791235923767090e-01
    z[6,4,6]  R1626     0.568831205368042
    z[6,4,6]  R1627     -2.7207210659980774e-01
    z[6,4,6]  R1628     4.0409117937088013e-01
    z[6,4,6]  R1629     -4.2171877622604370e-01
    z[6,4,6]  R1630     -1.4311835169792175e-02
    z[6,4,6]  R1631     2.5133961439132690e-01
    z[6,4,6]  R1632     2.5733998045325279e-02
    z[6,4,6]  R1633     -7.4962019920349121e-02
    z[6,4,6]  R1634     -2.9850602149963379e-01
    z[6,4,6]  R1635     -5.4284799098968506e-01
    z[6,4,6]  R1636     -6.1835199594497681e-01
    z[6,4,6]  R1637     2.3508971929550171e-01
    z[6,4,6]  R1638     -3.7726196646690369e-01
    z[6,4,6]  R1639     3.1346493959426880e-01
    z[6,4,6]  R1640     0.337494820356369
    z[6,4,6]  R1641     -1.6473412513732910e-01
    z[6,4,6]  R1642     1.6942480206489563e-01
    z[6,4,6]  R1643     2.9440093040466309e-01
    z[6,4,6]  R1644     5.0955861806869507e-01
    z[6,4,6]  R1645     -5.4874587804079056e-03
    z[6,4,6]  R1646     -3.4751974046230316e-02
    z[6,4,6]  R1647     -4.3802503496408463e-02
    z[6,4,6]  R1648     3.5226356238126755e-02
    z[6,4,6]  R1649     1.6212120652198792e-02
    z[6,4,6]  R1650     -3.4154140949249268e-01
    z[6,4,6]  R1651     2.5265011191368103e-01
    z[6,4,6]  R1652     5.4128278046846390e-02
    z[6,4,6]  R1653     -5.7553578168153763e-02
    z[6,4,6]  R1654     -3.8404011726379395e-01
    z[6,4,6]  R1655     2.1300770342350006e-02
    z[6,4,6]  R1656     8.4735400974750519e-02
    z[6,4,6]  R1657     1.5273508429527283e-01
    z[4,7,0]  R38       -1
    z[4,7,0]  R65       1
    z[4,7,0]  R1658     -1
    z[4,7,0]  R1659     1
    z[4,7,0]  R1672     -1.5911825001239777e-01
    z[4,7,0]  R1673     -8.3460539579391479e-02
    z[4,7,0]  R1674     -2.9796180129051208e-01
    z[4,7,0]  R1675     -0.10040283203125
    z[4,7,0]  R1676     -1.1207935959100723e-01
    z[4,7,0]  R1677     -5.4521399736404419e-01
    z[4,7,0]  R1678     2.1134330017957836e-04
    z[4,7,0]  R1679     1.8737228214740753e-01
    z[4,7,0]  R1680     -3.7565141916275024e-01
    z[4,7,0]  R1681     -1.3508066534996033e-01
    z[4,7,0]  R1682     7.3875255882740021e-02
    z[4,7,0]  R1683     2.6147386431694031e-01
    z[4,7,0]  R1684     -5.3577542304992676e-01
    z[4,7,0]  R1685     4.5376780629158020e-01
    z[4,7,0]  R1686     6.9701528549194336e-01
    z[4,7,0]  R1687     -2.9086044430732727e-01
    z[4,7,0]  R1688     6.3951069116592407e-01
    z[4,7,0]  R1689     0.605835497379303
    z[4,7,0]  R1690     7.0761835575103760e-01
    z[4,7,0]  R1691     3.8629552721977234e-01
    z[4,7,0]  R1692     3.6952725052833557e-01
    z[4,7,0]  R1693     -9.5478974282741547e-02
    z[4,7,0]  R1694     -5.1158881187438965e-01
    z[4,7,0]  R1695     -4.5761802792549133e-01
    z[4,7,0]  R1696     -4.9912708997726440e-01
    z[4,7,0]  R1697     5.7854449748992920e-01
    z[4,7,0]  R1698     -2.5291821360588074e-01
    z[4,7,0]  R1699     1.2360244244337082e-01
    z[4,7,0]  R1700     0.0306143369525671
    z[4,7,0]  R1701     5.4720234870910645e-01
    z[4,7,0]  R1702     -2.0705135166645050e-01
    z[4,7,0]  R1703     1.3450443744659424e-01
    z[4,7,0]  R1704     -0.511566698551178
    z[4,7,0]  R1705     1.0518323630094528e-01
    z[4,7,0]  R1706     -2.5864261388778687e-01
    z[4,7,0]  R1707     1.4801529049873352e-01
    z[4,7,0]  R1708     3.2486591488122940e-02
    z[4,7,0]  R1709     -3.0512461066246033e-01
    z[4,7,0]  R1710     7.9080504179000854e-01
    z[4,7,0]  R1711     1.4882269501686096e-01
    z[4,7,0]  R1712     -1.1800559610128403e-01
    z[4,7,0]  R1713     6.5329587459564209e-01
    z[4,7,0]  R1714     -3.3021083474159241e-01
    z[4,7,0]  R1715     7.9478567838668823e-01
    z[4,7,0]  R1716     5.5110937356948853e-01
    z[4,7,0]  R1717     4.3531551957130432e-01
    z[4,7,0]  R1718     3.7732085585594177e-01
    z[4,7,0]  R1719     -1.6677637398242950e-01
    z[4,7,0]  R1720     2.7080655097961426e-01
    z[4,7,0]  R1721     -0.333111971616745
    z[4,7,0]  R1722     -1.1851393431425095e-01
    z[4,7,0]  R1723     -4.5830646157264709e-01
    z[4,7,0]  R1724     4.4970255345106125e-02
    z[4,7,0]  R1725     -1.8352389335632324e-01
    z[4,7,0]  R1726     5.0772237777709961e-01
    z[4,7,0]  R1727     -6.1997871845960617e-02
    z[4,7,0]  R1728     -4.8145502805709839e-01
    z[4,7,0]  R1729     8.8104113936424255e-02
    z[4,7,0]  R1730     -4.3010520935058594e-01
    z[4,7,0]  R1731     4.6591836214065552e-01
    z[4,7,0]  R1732     6.7357790470123291e-01
    z[4,7,0]  R1733     -7.2544604539871216e-02
    z[4,7,0]  R1734     3.9823567867279053e-01
    z[4,7,0]  R1735     3.9311617612838745e-01
    z[4,7,0]  R1736     -2.2881540656089783e-01
    z[4,7,0]  R1737     -4.2141190171241760e-01
    z[4,7,0]  R1738     4.0351420640945435e-01
    z[4,7,0]  R1739     -8.3761967718601227e-02
    z[4,7,0]  R1740     -7.7193096280097961e-02
    z[4,7,0]  R1741     1.5632240474224091e-01
    z[4,7,0]  R1742     6.7632240056991577e-01
    z[4,7,0]  R1743     -4.5164099335670471e-01
    z[4,7,0]  R1744     -4.4391790032386780e-01
    z[4,7,0]  R1745     6.6559958457946777e-01
    z[4,7,0]  R1746     4.1964778304100037e-01
    z[4,7,0]  R1747     2.3575158417224884e-01
    z[4,7,0]  R1748     0.111433245241642
    z[4,7,0]  R1749     -4.4875025749206543e-01
    z[4,7,0]  R1750     -3.7401786446571350e-01
    z[4,7,0]  R1751     4.4309237599372864e-01
    z[4,7,0]  R1752     -5.9246625751256943e-02
    z[4,7,0]  R1753     7.8633022308349609e-01
    z[4,7,0]  R1754     -1.7872239649295807e-01
    z[4,7,0]  R1755     0.093810074031353
    z[4,7,0]  R1756     4.2910650372505188e-01
    z[4,7,0]  R1757     3.7557142972946167e-01
    z[4,7,0]  R1758     3.7017074227333069e-01
    z[4,7,0]  R1759     2.1927321329712868e-02
    z[4,7,0]  R1760     3.6122921854257584e-02
    z[4,7,0]  R1761     -4.5800682902336121e-01
    z[4,7,0]  R1762     5.4896444082260132e-01
    z[4,7,0]  R1763     7.0793789625167847e-01
    z[4,7,0]  R1764     0.505699872970581
    z[4,7,0]  R1765     3.4056031703948975e-01
    z[4,7,0]  R1766     2.2189356386661530e-01
    z[4,7,0]  R1767     2.6149040460586548e-01
    z[4,7,0]  R1768     1.1316373199224472e-01
    z[4,7,0]  R1769     -1.7203774303197861e-02
    z[4,7,0]  R1770     7.8943118453025818e-02
    z[4,7,0]  R1771     -3.1039005517959595e-01
    z[4,7,0]  R1772     2.4173296988010406e-02
    z[4,7,0]  R1773     -6.1115708202123642e-02
    z[4,7,0]  R1774     -4.9999356269836426e-01
    z[4,7,0]  R1775     -2.6486939191818237e-01
    z[4,7,0]  R1776     -5.6621241569519043e-01
    z[4,7,1]  R39       -1
    z[4,7,1]  R66       1
    z[4,7,1]  R1660     -1
    z[4,7,1]  R1661     1
    z[4,7,1]  R1672     -2.1109507977962494e-01
    z[4,7,1]  R1673     3.6115714907646179e-01
    z[4,7,1]  R1674     5.0819098949432373e-01
    z[4,7,1]  R1675     6.0065197944641113e-01
    z[4,7,1]  R1676     2.9567638039588928e-01
    z[4,7,1]  R1677     -2.9722964763641357e-01
    z[4,7,1]  R1678     -2.6562201976776123e-01
    z[4,7,1]  R1679     -1.9744651019573212e-01
    z[4,7,1]  R1680     -1.0959574580192566e-01
    z[4,7,1]  R1681     -1.5208879113197327e-01
    z[4,7,1]  R1682     -7.6956021785736084e-01
    z[4,7,1]  R1683     -8.6423909664154053e-01
    z[4,7,1]  R1684     -7.2976911067962646e-01
    z[4,7,1]  R1685     -6.6835129261016846e-01
    z[4,7,1]  R1686     -6.9223767518997192e-01
    z[4,7,1]  R1687     -0.820530116558075
    z[4,7,1]  R1688     4.5963096618652344e-01
    z[4,7,1]  R1689     7.0677846670150757e-01
    z[4,7,1]  R1690     3.9970946311950684e-01
    z[4,7,1]  R1691     0.728522002696991
    z[4,7,1]  R1692     -7.0043218135833740e-01
    z[4,7,1]  R1693     -6.0439997911453247e-01
    z[4,7,1]  R1694     -7.9351294040679932e-01
    z[4,7,1]  R1695     -5.0827115774154663e-01
    z[4,7,1]  R1696     2.3698510229587555e-01
    z[4,7,1]  R1697     6.2553894519805908e-01
    z[4,7,1]  R1698     4.3601259589195251e-01
    z[4,7,1]  R1699     1.2836413085460663e-01
    z[4,7,1]  R1700     -7.6285108923912048e-02
    z[4,7,1]  R1701     -5.3504884243011475e-01
    z[4,7,1]  R1702     -2.1105191111564636e-01
    z[4,7,1]  R1703     5.5811733007431030e-01
    z[4,7,1]  R1704     -2.0206277072429657e-01
    z[4,7,1]  R1705     8.3387774229049683e-01
    z[4,7,1]  R1706     -8.2305364310741425e-02
    z[4,7,1]  R1707     7.9791676998138428e-01
    z[4,7,1]  R1708     0.586044430732727
    z[4,7,1]  R1709     -5.3130376338958740e-01
    z[4,7,1]  R1710     3.3108010888099670e-01
    z[4,7,1]  R1711     -7.8599143028259277e-01
    z[4,7,1]  R1712     -8.3646696805953979e-01
    z[4,7,1]  R1713     6.7285680770874023e-01
    z[4,7,1]  R1714     -7.8959834575653076e-01
    z[4,7,1]  R1715     2.3742099106311798e-01
    z[4,7,1]  R1716     2.6344174146652222e-01
    z[4,7,1]  R1717     -4.5459401607513428e-01
    z[4,7,1]  R1718     -4.6511086821556091e-01
    z[4,7,1]  R1719     -0.762222409248352
    z[4,7,1]  R1720     -1.6407574713230133e-01
    z[4,7,1]  R1721     -5.3735202550888062e-01
    z[4,7,1]  R1722     -4.3657287955284119e-01
    z[4,7,1]  R1723     -4.2445501685142517e-01
    z[4,7,1]  R1724     -8.2359558343887329e-01
    z[4,7,1]  R1725     -4.7783127427101135e-01
    z[4,7,1]  R1726     -4.5591521263122559e-01
    z[4,7,1]  R1727     -1.6740456223487854e-02
    z[4,7,1]  R1728     2.0488715171813965e-01
    z[4,7,1]  R1729     -2.7302113175392151e-01
    z[4,7,1]  R1730     -7.5260102748870850e-02
    z[4,7,1]  R1731     4.2384776473045349e-01
    z[4,7,1]  R1732     4.9414092302322388e-01
    z[4,7,1]  R1733     -4.0998184680938721e-01
    z[4,7,1]  R1734     6.5227466821670532e-01
    z[4,7,1]  R1735     3.4529119729995728e-01
    z[4,7,1]  R1736     -4.3794006109237671e-01
    z[4,7,1]  R1737     2.8829118609428406e-01
    z[4,7,1]  R1738     -4.0004888176918030e-01
    z[4,7,1]  R1739     -1.4097803831100464e-01
    z[4,7,1]  R1740     -7.5582391023635864e-01
    z[4,7,1]  R1741     -8.4233134984970093e-01
    z[4,7,1]  R1742     6.8047583103179932e-01
    z[4,7,1]  R1743     -0.270486056804657
    z[4,7,1]  R1744     -5.3289192914962769e-01
    z[4,7,1]  R1745     1.0219454765319824e-01
    z[4,7,1]  R1746     3.2792839407920837e-01
    z[4,7,1]  R1747     9.3890947103500366e-01
    z[4,7,1]  R1748     9.6040832996368408e-01
    z[4,7,1]  R1749     -4.1371452808380127e-01
    z[4,7,1]  R1750     6.7751012742519379e-02
    z[4,7,1]  R1751     -0.66004878282547
    z[4,7,1]  R1752     -5.4887789487838745e-01
    z[4,7,1]  R1753     -5.1548504829406738e-01
    z[4,7,1]  R1754     3.7859001755714417e-01
    z[4,7,1]  R1755     -3.9288067817687988e-01
    z[4,7,1]  R1756     -3.5894498229026794e-01
    z[4,7,1]  R1757     8.3690589666366577e-01
    z[4,7,1]  R1758     8.2600378990173340e-01
    z[4,7,1]  R1759     -3.0824273824691772e-01
    z[4,7,1]  R1760     4.1268173605203629e-02
    z[4,7,1]  R1761     -6.1525326967239380e-01
    z[4,7,1]  R1762     2.7501374483108521e-01
    z[4,7,1]  R1763     1.1398664861917496e-01
    z[4,7,1]  R1764     -4.1105547547340393e-01
    z[4,7,1]  R1765     9.1148459911346436e-01
    z[4,7,1]  R1766     9.2428731918334961e-01
    z[4,7,1]  R1767     9.2195343971252441e-01
    z[4,7,1]  R1768     9.0650641918182373e-01
    z[4,7,1]  R1769     -1.7797312140464783e-01
    z[4,7,1]  R1770     -0.44866743683815
    z[4,7,1]  R1771     9.2515224218368530e-01
    z[4,7,1]  R1772     6.3834863901138306e-01
    z[4,7,1]  R1773     5.8140450716018677e-01
    z[4,7,1]  R1774     7.2880762815475464e-01
    z[4,7,1]  R1775     5.9469151496887207e-01
    z[4,7,1]  R1776     0.667008638381958
    z[4,7,2]  R40       -1
    z[4,7,2]  R67       1
    z[4,7,2]  R1662     -1
    z[4,7,2]  R1663     1
    z[4,7,2]  R1672     -1.8154074251651764e-01
    z[4,7,2]  R1673     -2.8845322132110596e-01
    z[4,7,2]  R1674     -3.8084396719932556e-01
    z[4,7,2]  R1675     -0.0054810531437397
    z[4,7,2]  R1676     -2.6502066850662231e-01
    z[4,7,2]  R1677     -1.4793653041124344e-02
    z[4,7,2]  R1678     1.4257819950580597e-01
    z[4,7,2]  R1679     -1.3961243629455566e-01
    z[4,7,2]  R1680     1.1071675270795822e-01
    z[4,7,2]  R1681     1.3990931212902069e-01
    z[4,7,2]  R1682     -2.8753346204757690e-01
    z[4,7,2]  R1683     -1.6213077306747437e-01
    z[4,7,2]  R1684     -1.3287785649299622e-01
    z[4,7,2]  R1685     -1.4928828179836273e-01
    z[4,7,2]  R1686     -1.3702154159545898e-01
    z[4,7,2]  R1687     -5.3955212235450745e-02
    z[4,7,2]  R1688     2.1143613755702972e-01
    z[4,7,2]  R1689     1.2658575177192688e-01
    z[4,7,2]  R1690     9.6190765500068665e-02
    z[4,7,2]  R1691     3.9736970211379230e-04
    z[4,7,2]  R1692     -4.7123380005359650e-02
    z[4,7,2]  R1693     -7.1347869932651520e-02
    z[4,7,2]  R1694     -8.1454485654830933e-02
    z[4,7,2]  R1695     -1.7367942631244659e-01
    z[4,7,2]  R1696     1.4274470508098602e-01
    z[4,7,2]  R1697     -1.7110915854573250e-02
    z[4,7,2]  R1698     -1.8773204088211060e-01
    z[4,7,2]  R1699     -3.6473503708839417e-01
    z[4,7,2]  R1700     -0.315572589635849
    z[4,7,2]  R1701     2.5939446687698364e-01
    z[4,7,2]  R1702     1.5178416669368744e-01
    z[4,7,2]  R1703     3.3390790224075317e-01
    z[4,7,2]  R1704     4.8268872499465942e-01
    z[4,7,2]  R1705     1.5913186967372894e-01
    z[4,7,2]  R1706     6.3994270563125610e-01
    z[4,7,2]  R1707     2.3718601465225220e-01
    z[4,7,2]  R1708     3.4481936693191528e-01
    z[4,7,2]  R1709     1.7182333767414093e-01
    z[4,7,2]  R1710     2.6018142700195312e-01
    z[4,7,2]  R1711     -4.2362990975379944e-01
    z[4,7,2]  R1712     -2.2558629512786865e-01
    z[4,7,2]  R1713     1.8069089949131012e-01
    z[4,7,2]  R1714     -1.9469912350177765e-01
    z[4,7,2]  R1715     5.2703386172652245e-03
    z[4,7,2]  R1716     -3.4479784965515137e-01
    z[4,7,2]  R1717     -8.1773988902568817e-02
    z[4,7,2]  R1718     2.2669050097465515e-01
    z[4,7,2]  R1719     2.6220592856407166e-01
    z[4,7,2]  R1720     -1.3925200700759888e-01
    z[4,7,2]  R1721     5.2966678142547607e-01
    z[4,7,2]  R1722     -3.4921181201934814e-01
    z[4,7,2]  R1723     1.3471728563308716e-01
    z[4,7,2]  R1724     -4.7267618775367737e-01
    z[4,7,2]  R1725     2.4360284209251404e-01
    z[4,7,2]  R1726     4.5246556401252747e-01
    z[4,7,2]  R1727     3.6115118861198425e-01
    z[4,7,2]  R1728     3.9397758245468140e-01
    z[4,7,2]  R1729     -2.2256558761000633e-02
    z[4,7,2]  R1730     0.428076833486557
    z[4,7,2]  R1731     2.8458023443818092e-03
    z[4,7,2]  R1732     2.1882055699825287e-01
    z[4,7,2]  R1733     1.9023905694484711e-01
    z[4,7,2]  R1734     1.5313657000660896e-02
    z[4,7,2]  R1735     -9.7747206687927246e-02
    z[4,7,2]  R1736     -3.2966170459985733e-02
    z[4,7,2]  R1737     3.1236311793327332e-01
    z[4,7,2]  R1738     -6.5187156200408936e-01
    z[4,7,2]  R1739     -5.4828889667987823e-02
    z[4,7,2]  R1740     1.0606251657009125e-01
    z[4,7,2]  R1741     -2.7343055605888367e-01
    z[4,7,2]  R1742     1.9612836185842752e-03
    z[4,7,2]  R1743     3.8312498945742846e-03
    z[4,7,2]  R1744     -1.1785271763801575e-01
    z[4,7,2]  R1745     -2.9135072231292725e-01
    z[4,7,2]  R1746     6.2200218439102173e-01
    z[4,7,2]  R1747     -1.9933420419692993e-01
    z[4,7,2]  R1748     -9.5623753964900970e-02
    z[4,7,2]  R1749     2.1981850266456604e-02
    z[4,7,2]  R1750     4.2391413450241089e-01
    z[4,7,2]  R1751     -9.2750638723373413e-02
    z[4,7,2]  R1752     1.4911958575248718e-01
    z[4,7,2]  R1753     2.6723194122314453e-01
    z[4,7,2]  R1754     1.3118797540664673e-01
    z[4,7,2]  R1755     -0.584646463394165
    z[4,7,2]  R1756     -5.7222151756286621e-01
    z[4,7,2]  R1757     -9.1069459915161133e-02
    z[4,7,2]  R1758     9.5958143472671509e-02
    z[4,7,2]  R1759     2.0737320184707642e-02
    z[4,7,2]  R1760     -1.0694067925214767e-01
    z[4,7,2]  R1761     1.4552344381809235e-01
    z[4,7,2]  R1762     1.8929733335971832e-01
    z[4,7,2]  R1763     -7.9540058970451355e-02
    z[4,7,2]  R1764     -6.1340779066085815e-01
    z[4,7,2]  R1765     4.8959512263536453e-02
    z[4,7,2]  R1766     -4.5501585118472576e-03
    z[4,7,2]  R1767     1.9258438050746918e-01
    z[4,7,2]  R1768     3.5356727242469788e-01
    z[4,7,2]  R1769     2.0872248709201813e-01
    z[4,7,2]  R1770     -3.4142377972602844e-01
    z[4,7,2]  R1771     1.2800908088684082e-01
    z[4,7,2]  R1772     -9.1829463839530945e-02
    z[4,7,2]  R1773     -2.1675500273704529e-01
    z[4,7,2]  R1774     -2.1271312609314919e-02
    z[4,7,2]  R1775     -1.1073148995637894e-01
    z[4,7,2]  R1776     -3.6913838982582092e-01
    z[4,7,3]  R41       -1
    z[4,7,3]  R68       1
    z[4,7,3]  R1664     -1
    z[4,7,3]  R1665     1
    z[4,7,3]  R1672     -6.6604685783386230e-01
    z[4,7,3]  R1673     1.4893932640552521e-01
    z[4,7,3]  R1674     3.7170371413230896e-01
    z[4,7,3]  R1675     -1.8350727856159210e-01
    z[4,7,3]  R1676     0.0356985442340374
    z[4,7,3]  R1677     -4.7900900244712830e-01
    z[4,7,3]  R1678     -8.2958471775054932e-01
    z[4,7,3]  R1679     -4.9599045515060425e-01
    z[4,7,3]  R1680     -3.3634263277053833e-01
    z[4,7,3]  R1681     -4.4997262954711914e-01
    z[4,7,3]  R1682     0.351880818605423
    z[4,7,3]  R1683     1.5563932061195374e-01
    z[4,7,3]  R1684     0.0896289050579071
    z[4,7,3]  R1685     4.4433671981096268e-02
    z[4,7,3]  R1686     1.1404450237751007e-01
    z[4,7,3]  R1687     0.393184632062912
    z[4,7,3]  R1688     -4.0812357328832150e-03
    z[4,7,3]  R1689     3.0470450874418020e-03
    z[4,7,3]  R1690     4.4962140917778015e-01
    z[4,7,3]  R1691     -2.7278661727905273e-01
    z[4,7,3]  R1692     -5.2548497915267944e-01
    z[4,7,3]  R1693     -7.1449923515319824e-01
    z[4,7,3]  R1694     8.6602732539176941e-02
    z[4,7,3]  R1695     -0.456758052110672
    z[4,7,3]  R1696     5.5406648665666580e-02
    z[4,7,3]  R1697     5.1946036517620087e-02
    z[4,7,3]  R1698     4.9007901549339294e-01
    z[4,7,3]  R1699     -2.9773136973381042e-01
    z[4,7,3]  R1700     -4.7056525945663452e-01
    z[4,7,3]  R1701     -5.1373803615570068e-01
    z[4,7,3]  R1702     -9.6666947007179260e-02
    z[4,7,3]  R1703     -5.6725364923477173e-01
    z[4,7,3]  R1704     5.3634798526763916e-01
    z[4,7,3]  R1705     -4.5542147755622864e-01
    z[4,7,3]  R1706     3.9375522732734680e-01
    z[4,7,3]  R1707     -3.3225673437118530e-01
    z[4,7,3]  R1708     -6.4335089921951294e-01
    z[4,7,3]  R1709     -6.6603964567184448e-01
    z[4,7,3]  R1710     -2.0372414588928223e-01
    z[4,7,3]  R1711     1.4815287292003632e-01
    z[4,7,3]  R1712     -1.4601313509047031e-02
    z[4,7,3]  R1713     2.0684491097927094e-01
    z[4,7,3]  R1714     -3.8015641272068024e-02
    z[4,7,3]  R1715     4.5650738477706909e-01
    z[4,7,3]  R1716     -2.1075144410133362e-01
    z[4,7,3]  R1717     -1.9165011122822762e-02
    z[4,7,3]  R1718     3.7987983226776123e-01
    z[4,7,3]  R1719     1.0237257182598114e-01
    z[4,7,3]  R1720     3.8853892683982849e-01
    z[4,7,3]  R1721     4.2647641897201538e-01
    z[4,7,3]  R1722     -1.4260447025299072e-01
    z[4,7,3]  R1723     2.6867750287055969e-01
    z[4,7,3]  R1724     -1.5323288738727570e-01
    z[4,7,3]  R1725     2.7281916141510010e-01
    z[4,7,3]  R1726     4.9727344512939453e-01
    z[4,7,3]  R1727     7.3696893453598022e-01
    z[4,7,3]  R1728     2.2377386689186096e-02
    z[4,7,3]  R1729     4.9843266606330872e-01
    z[4,7,3]  R1730     5.5681866407394409e-01
    z[4,7,3]  R1731     -6.0512870550155640e-01
    z[4,7,3]  R1732     0.0890241339802742
    z[4,7,3]  R1733     -4.6217706799507141e-01
    z[4,7,3]  R1734     -4.0138861536979675e-01
    z[4,7,3]  R1735     -6.1015748977661133e-01
    z[4,7,3]  R1736     2.2263512015342712e-01
    z[4,7,3]  R1737     2.0708565413951874e-01
    z[4,7,3]  R1738     -4.8841637372970581e-01
    z[4,7,3]  R1739     1.5461874008178711e-01
    z[4,7,3]  R1740     2.8776556253433228e-01
    z[4,7,3]  R1741     2.1502895653247833e-01
    z[4,7,3]  R1742     -2.0312415063381195e-01
    z[4,7,3]  R1743     -1.0942038893699646e-01
    z[4,7,3]  R1744     -5.6919389963150024e-01
    z[4,7,3]  R1745     -4.9499401450157166e-01
    z[4,7,3]  R1746     -4.2022615671157837e-01
    z[4,7,3]  R1747     1.2178914248943329e-01
    z[4,7,3]  R1748     2.4164592847228050e-02
    z[4,7,3]  R1749     -1.6868244856595993e-02
    z[4,7,3]  R1750     3.1191563606262207e-01
    z[4,7,3]  R1751     9.8548196256160736e-02
    z[4,7,3]  R1752     -2.2359421476721764e-02
    z[4,7,3]  R1753     -1.6333516687154770e-02
    z[4,7,3]  R1754     3.0073146335780621e-03
    z[4,7,3]  R1755     -5.5990648269653320e-01
    z[4,7,3]  R1756     3.5550169646739960e-02
    z[4,7,3]  R1757     8.1884294748306274e-02
    z[4,7,3]  R1758     1.6896691918373108e-01
    z[4,7,3]  R1759     5.1314628124237061e-01
    z[4,7,3]  R1760     1.3779959082603455e-01
    z[4,7,3]  R1761     -1.9642950594425201e-01
    z[4,7,3]  R1762     -5.2982360124588013e-01
    z[4,7,3]  R1763     -3.9600214362144470e-01
    z[4,7,3]  R1764     3.2492477446794510e-02
    z[4,7,3]  R1765     1.7291373014450073e-01
    z[4,7,3]  R1766     -0.0959969162940979
    z[4,7,3]  R1767     1.9805204123258591e-02
    z[4,7,3]  R1768     1.8201887607574463e-02
    z[4,7,3]  R1769     5.6374704837799072e-01
    z[4,7,3]  R1770     -6.0380709171295166e-01
    z[4,7,3]  R1771     1.7328624427318573e-01
    z[4,7,3]  R1772     7.2874200344085693e-01
    z[4,7,3]  R1773     7.1704608201980591e-01
    z[4,7,3]  R1774     -2.5790292024612427e-01
    z[4,7,3]  R1775     6.7493087053298950e-01
    z[4,7,3]  R1776     -1.8290762603282928e-01
    z[4,7,4]  R42       -1
    z[4,7,4]  R69       1
    z[4,7,4]  R1666     -1
    z[4,7,4]  R1667     1
    z[4,7,4]  R1672     -6.1221265792846680e-01
    z[4,7,4]  R1673     -4.4700881838798523e-01
    z[4,7,4]  R1674     1.2542865239083767e-02
    z[4,7,4]  R1675     -1.7818284034729004e-01
    z[4,7,4]  R1676     -3.4217327833175659e-02
    z[4,7,4]  R1677     -2.6628868654370308e-02
    z[4,7,4]  R1678     2.5206291675567627e-01
    z[4,7,4]  R1679     -4.1365686058998108e-01
    z[4,7,4]  R1680     5.7872142642736435e-02
    z[4,7,4]  R1681     3.1724950671195984e-01
    z[4,7,4]  R1682     -3.1405866146087646e-01
    z[4,7,4]  R1683     0.023549759760499
    z[4,7,4]  R1684     -1.1894471943378448e-01
    z[4,7,4]  R1685     -7.0711731910705566e-02
    z[4,7,4]  R1686     5.1908683031797409e-02
    z[4,7,4]  R1687     2.0215994119644165e-01
    z[4,7,4]  R1688     5.2272111177444458e-01
    z[4,7,4]  R1689     1.8284878134727478e-01
    z[4,7,4]  R1690     2.5019386410713196e-01
    z[4,7,4]  R1691     -2.1078962087631226e-01
    z[4,7,4]  R1692     1.0750237107276917e-01
    z[4,7,4]  R1693     -5.4194923490285873e-02
    z[4,7,4]  R1694     1.0144741833209991e-01
    z[4,7,4]  R1695     -3.7986236810684204e-01
    z[4,7,4]  R1696     9.0818911790847778e-02
    z[4,7,4]  R1697     -2.8622266650199890e-01
    z[4,7,4]  R1698     -6.6355979442596436e-01
    z[4,7,4]  R1699     -0.514081597328186
    z[4,7,4]  R1700     -1.2707982957363129e-01
    z[4,7,4]  R1701     -2.6603189110755920e-01
    z[4,7,4]  R1702     6.1554533243179321e-01
    z[4,7,4]  R1703     -4.0420621633529663e-01
    z[4,7,4]  R1704     1.7329661548137665e-01
    z[4,7,4]  R1705     1.4906750619411469e-01
    z[4,7,4]  R1706     2.7997341752052307e-01
    z[4,7,4]  R1707     1.4735132455825806e-02
    z[4,7,4]  R1708     1.0696996748447418e-01
    z[4,7,4]  R1709     -3.8329381495714188e-02
    z[4,7,4]  R1710     2.4498523771762848e-01
    z[4,7,4]  R1711     -3.0189722776412964e-01
    z[4,7,4]  R1712     -1.3840667903423309e-01
    z[4,7,4]  R1713     1.9698446616530418e-02
    z[4,7,4]  R1714     -4.2618361115455627e-01
    z[4,7,4]  R1715     9.0292975306510925e-02
    z[4,7,4]  R1716     4.4573080539703369e-01
    z[4,7,4]  R1717     7.0526683330535889e-01
    z[4,7,4]  R1718     2.2930772602558136e-01
    z[4,7,4]  R1719     2.5002929568290710e-01
    z[4,7,4]  R1720     -3.4208881855010986e-01
    z[4,7,4]  R1721     1.9140517711639404e-01
    z[4,7,4]  R1722     -8.0715966224670410e-01
    z[4,7,4]  R1723     -3.9832934737205505e-01
    z[4,7,4]  R1724     9.0377889573574066e-02
    z[4,7,4]  R1725     -5.5513745546340942e-01
    z[4,7,4]  R1726     1.2700709700584412e-01
    z[4,7,4]  R1727     -8.0024421215057373e-02
    z[4,7,4]  R1728     -3.8305470347404480e-01
    z[4,7,4]  R1729     2.8270408511161804e-01
    z[4,7,4]  R1730     -3.2083618640899658e-01
    z[4,7,4]  R1731     -3.7383839488029480e-01
    z[4,7,4]  R1732     -2.9608780145645142e-01
    z[4,7,4]  R1733     2.8118072077631950e-02
    z[4,7,4]  R1734     -2.6770675182342529e-01
    z[4,7,4]  R1735     2.5118380784988403e-01
    z[4,7,4]  R1736     -6.5479505062103271e-01
    z[4,7,4]  R1737     -4.5285901427268982e-01
    z[4,7,4]  R1738     0.0766245424747467
    z[4,7,4]  R1739     -3.6809706687927246e-01
    z[4,7,4]  R1740     4.2856097221374512e-02
    z[4,7,4]  R1741     1.2355703860521317e-01
    z[4,7,4]  R1742     -1.7000260949134827e-01
    z[4,7,4]  R1743     -1.7644479870796204e-02
    z[4,7,4]  R1744     -5.0424743443727493e-02
    z[4,7,4]  R1745     4.4696271419525146e-01
    z[4,7,4]  R1746     -0.0360000804066658
    z[4,7,4]  R1747     -7.9047113656997681e-02
    z[4,7,4]  R1748     -4.9157503992319107e-02
    z[4,7,4]  R1749     1.4077517390251160e-01
    z[4,7,4]  R1750     -2.8249008581042290e-02
    z[4,7,4]  R1751     -5.6559729576110840e-01
    z[4,7,4]  R1752     -6.1346596479415894e-01
    z[4,7,4]  R1753     1.0119650512933731e-02
    z[4,7,4]  R1754     1.6915602609515190e-02
    z[4,7,4]  R1755     -3.8995620608329773e-01
    z[4,7,4]  R1756     -2.7812096476554871e-01
    z[4,7,4]  R1757     2.9832589626312256e-01
    z[4,7,4]  R1758     -3.5633894801139832e-01
    z[4,7,4]  R1759     4.3829031288623810e-02
    z[4,7,4]  R1760     1.8756887875497341e-03
    z[4,7,4]  R1761     -3.6813512444496155e-01
    z[4,7,4]  R1762     1.4003157615661621e-01
    z[4,7,4]  R1763     3.8114407658576965e-01
    z[4,7,4]  R1764     -2.4910818040370941e-01
    z[4,7,4]  R1765     6.7822217941284180e-02
    z[4,7,4]  R1766     -1.9547192752361298e-01
    z[4,7,4]  R1767     -1.9871446490287781e-01
    z[4,7,4]  R1768     5.5680975317955017e-02
    z[4,7,4]  R1769     1.2122242152690887e-01
    z[4,7,4]  R1770     1.2970919907093048e-01
    z[4,7,4]  R1771     -3.7139644846320152e-03
    z[4,7,4]  R1772     -1.3720582425594330e-01
    z[4,7,4]  R1773     1.1584879830479622e-03
    z[4,7,4]  R1774     -3.3810895681381226e-01
    z[4,7,4]  R1775     2.6022934913635254e-01
    z[4,7,4]  R1776     1.8798503279685974e-01
    z[4,7,5]  R43       -1
    z[4,7,5]  R70       1
    z[4,7,5]  R1668     -1
    z[4,7,5]  R1669     1
    z[4,7,5]  R1672     1.2477570027112961e-01
    z[4,7,5]  R1673     7.4614512920379639e-01
    z[4,7,5]  R1674     6.0330617427825928e-01
    z[4,7,5]  R1675     6.8889522552490234e-01
    z[4,7,5]  R1676     7.2982782125473022e-01
    z[4,7,5]  R1677     4.0736641734838486e-02
    z[4,7,5]  R1678     3.1953501701354980e-01
    z[4,7,5]  R1679     5.8904135227203369e-01
    z[4,7,5]  R1680     7.8732502460479736e-01
    z[4,7,5]  R1681     7.2251111268997192e-01
    z[4,7,5]  R1682     -2.6467683911323547e-01
    z[4,7,5]  R1683     -3.2396441698074341e-01
    z[4,7,5]  R1684     -2.3210351169109344e-01
    z[4,7,5]  R1685     -2.4184677004814148e-01
    z[4,7,5]  R1686     -2.1703690290451050e-02
    z[4,7,5]  R1687     2.0627363026142120e-01
    z[4,7,5]  R1688     -2.4471905827522278e-01
    z[4,7,5]  R1689     -2.8761044144630432e-01
    z[4,7,5]  R1690     2.5541490316390991e-01
    z[4,7,5]  R1691     -2.9075062274932861e-01
    z[4,7,5]  R1692     -1.3820463418960571e-01
    z[4,7,5]  R1693     -3.2267281413078308e-01
    z[4,7,5]  R1694     -2.8438609838485718e-01
    z[4,7,5]  R1695     4.0883723646402359e-02
    z[4,7,5]  R1696     0.81397944688797
    z[4,7,5]  R1697     4.2648872733116150e-01
    z[4,7,5]  R1698     8.2856327295303345e-02
    z[4,7,5]  R1699     5.9163773059844971e-01
    z[4,7,5]  R1700     8.0719190835952759e-01
    z[4,7,5]  R1701     -4.1230313479900360e-02
    z[4,7,5]  R1702     0.662135660648346
    z[4,7,5]  R1703     2.0706829428672791e-01
    z[4,7,5]  R1704     3.3804544806480408e-01
    z[4,7,5]  R1705     9.5515400171279907e-02
    z[4,7,5]  R1706     0.505935549736023
    z[4,7,5]  R1707     1.1857295036315918e-01
    z[4,7,5]  R1708     2.4743312597274780e-01
    z[4,7,5]  R1709     -2.0205296576023102e-01
    z[4,7,5]  R1710     2.1121473610401154e-01
    z[4,7,5]  R1711     -2.5830811262130737e-01
    z[4,7,5]  R1712     -5.7815372943878174e-02
    z[4,7,5]  R1713     -1.8703229725360870e-01
    z[4,7,5]  R1714     1.1776927113533020e-01
    z[4,7,5]  R1715     -1.4460229873657227e-01
    z[4,7,5]  R1716     -2.6085074990987778e-02
    z[4,7,5]  R1717     -3.1523931026458740e-01
    z[4,7,5]  R1718     4.5445635914802551e-01
    z[4,7,5]  R1719     4.9852064251899719e-01
    z[4,7,5]  R1720     7.3102825880050659e-01
    z[4,7,5]  R1721     -0.29815673828125
    z[4,7,5]  R1722     5.6530215078964829e-04
    z[4,7,5]  R1723     6.0024946928024292e-01
    z[4,7,5]  R1724     0.0422833114862442
    z[4,7,5]  R1725     -4.9906989932060242e-01
    z[4,7,5]  R1726     -2.4751673638820648e-01
    z[4,7,5]  R1727     5.0589424371719360e-01
    z[4,7,5]  R1728     4.6643459796905518e-01
    z[4,7,5]  R1729     4.9176892638206482e-01
    z[4,7,5]  R1730     4.5104572176933289e-01
    z[4,7,5]  R1731     -2.8282532095909119e-01
    z[4,7,5]  R1732     9.0691685676574707e-02
    z[4,7,5]  R1733     9.3692235648632050e-02
    z[4,7,5]  R1734     8.2366280257701874e-02
    z[4,7,5]  R1735     -1.0965884663164616e-02
    z[4,7,5]  R1736     1.4352850615978241e-01
    z[4,7,5]  R1737     5.3257197141647339e-01
    z[4,7,5]  R1738     6.5734423696994781e-02
    z[4,7,5]  R1739     9.0009754896163940e-01
    z[4,7,5]  R1740     -5.0257092714309692e-01
    z[4,7,5]  R1741     -3.0434669926762581e-02
    z[4,7,5]  R1742     -5.0444877706468105e-03
    z[4,7,5]  R1743     6.1857527494430542e-01
    z[4,7,5]  R1744     5.2670907229185104e-02
    z[4,7,5]  R1745     -1.1368764191865921e-01
    z[4,7,5]  R1746     -1.4943751692771912e-01
    z[4,7,5]  R1747     3.6455500870943069e-02
    z[4,7,5]  R1748     -2.2192882001399994e-01
    z[4,7,5]  R1749     5.3731882572174072e-01
    z[4,7,5]  R1750     7.1017998456954956e-01
    z[4,7,5]  R1751     1.2367139756679535e-01
    z[4,7,5]  R1752     -1.6047137975692749e-01
    z[4,7,5]  R1753     2.0586515963077545e-01
    z[4,7,5]  R1754     5.5116474628448486e-01
    z[4,7,5]  R1755     -0.068540558218956
    z[4,7,5]  R1756     -0.0843089371919632
    z[4,7,5]  R1757     1.7187568545341492e-01
    z[4,7,5]  R1758     -1.1723558604717255e-01
    z[4,7,5]  R1759     7.7866941690444946e-01
    z[4,7,5]  R1760     6.6610980033874512e-01
    z[4,7,5]  R1761     -3.2666981220245361e-01
    z[4,7,5]  R1762     -3.5131010413169861e-01
    z[4,7,5]  R1763     1.1444703489542007e-01
    z[4,7,5]  R1764     -6.0068786144256592e-02
    z[4,7,5]  R1765     -1.2698693573474884e-01
    z[4,7,5]  R1766     -1.7714734375476837e-01
    z[4,7,5]  R1767     -2.4065764620900154e-02
    z[4,7,5]  R1768     -1.6155165433883667e-01
    z[4,7,5]  R1769     7.4525499343872070e-01
    z[4,7,5]  R1770     3.1178635358810425e-01
    z[4,7,5]  R1771     -1.3313570991158485e-02
    z[4,7,5]  R1772     -8.8597349822521210e-02
    z[4,7,5]  R1773     -1.8960566818714142e-01
    z[4,7,5]  R1774     -1.9285212457180023e-01
    z[4,7,5]  R1775     -1.8472701311111450e-01
    z[4,7,5]  R1776     5.1409624516963959e-02
    z[4,7,6]  R44       -1
    z[4,7,6]  R71       1
    z[4,7,6]  R1670     -1
    z[4,7,6]  R1671     1
    z[4,7,6]  R1672     2.5133961439132690e-01
    z[4,7,6]  R1673     2.5733998045325279e-02
    z[4,7,6]  R1674     -7.4962019920349121e-02
    z[4,7,6]  R1675     -2.9850602149963379e-01
    z[4,7,6]  R1676     -5.4284799098968506e-01
    z[4,7,6]  R1677     -6.1835199594497681e-01
    z[4,7,6]  R1678     2.3508971929550171e-01
    z[4,7,6]  R1679     -3.7726196646690369e-01
    z[4,7,6]  R1680     3.1346493959426880e-01
    z[4,7,6]  R1681     0.337494820356369
    z[4,7,6]  R1682     -1.6473412513732910e-01
    z[4,7,6]  R1683     1.6942480206489563e-01
    z[4,7,6]  R1684     2.9440093040466309e-01
    z[4,7,6]  R1685     5.0955861806869507e-01
    z[4,7,6]  R1686     -5.4874587804079056e-03
    z[4,7,6]  R1687     -3.4751974046230316e-02
    z[4,7,6]  R1688     -4.3802503496408463e-02
    z[4,7,6]  R1689     3.5226356238126755e-02
    z[4,7,6]  R1690     1.6212120652198792e-02
    z[4,7,6]  R1691     -3.4154140949249268e-01
    z[4,7,6]  R1692     2.5265011191368103e-01
    z[4,7,6]  R1693     5.4128278046846390e-02
    z[4,7,6]  R1694     -5.7553578168153763e-02
    z[4,7,6]  R1695     -3.8404011726379395e-01
    z[4,7,6]  R1696     2.1300770342350006e-02
    z[4,7,6]  R1697     8.4735400974750519e-02
    z[4,7,6]  R1698     1.5273508429527283e-01
    z[4,7,6]  R1699     -3.6366802453994751e-01
    z[4,7,6]  R1700     6.7211896181106567e-02
    z[4,7,6]  R1701     1.0299152135848999e-01
    z[4,7,6]  R1702     2.5076711177825928e-01
    z[4,7,6]  R1703     1.7573399841785431e-01
    z[4,7,6]  R1704     -1.8029412627220154e-01
    z[4,7,6]  R1705     1.7178039252758026e-01
    z[4,7,6]  R1706     0.165541410446167
    z[4,7,6]  R1707     -4.0061435103416443e-01
    z[4,7,6]  R1708     -2.2367390990257263e-01
    z[4,7,6]  R1709     -0.330437034368515
    z[4,7,6]  R1710     -0.226243257522583
    z[4,7,6]  R1711     -0.0281552542001009
    z[4,7,6]  R1712     4.6129834651947021e-01
    z[4,7,6]  R1713     9.8311454057693481e-02
    z[4,7,6]  R1714     1.8066602945327759e-01
    z[4,7,6]  R1715     2.7286899089813232e-01
    z[4,7,6]  R1716     -5.1402223110198975e-01
    z[4,7,6]  R1717     -3.6391206085681915e-03
    z[4,7,6]  R1718     -4.3184596300125122e-01
    z[4,7,6]  R1719     -3.0547572299838066e-02
    z[4,7,6]  R1720     2.7921709418296814e-01
    z[4,7,6]  R1721     -1.1102665215730667e-01
    z[4,7,6]  R1722     -3.9580602198839188e-02
    z[4,7,6]  R1723     2.2164296358823776e-02
    z[4,7,6]  R1724     -2.5061666965484619e-01
    z[4,7,6]  R1725     2.1673756837844849e-01
    z[4,7,6]  R1726     7.0413582026958466e-02
    z[4,7,6]  R1727     2.4492797255516052e-01
    z[4,7,6]  R1728     4.5410472154617310e-01
    z[4,7,6]  R1729     -5.8907425403594971e-01
    z[4,7,6]  R1730     9.8338752985000610e-02
    z[4,7,6]  R1731     -1.3167785108089447e-01
    z[4,7,6]  R1732     3.8783612847328186e-01
    z[4,7,6]  R1733     7.5318306684494019e-01
    z[4,7,6]  R1734     4.1969934105873108e-01
    z[4,7,6]  R1735     5.3025788068771362e-01
    z[4,7,6]  R1736     -5.0580805540084839e-01
    z[4,7,6]  R1737     -0.331859827041626
    z[4,7,6]  R1738     -5.8802329003810883e-02
    z[4,7,6]  R1739     2.2911757230758667e-02
    z[4,7,6]  R1740     2.7257823944091797e-01
    z[4,7,6]  R1741     3.5895255208015442e-01
    z[4,7,6]  R1742     -0.0967012494802475
    z[4,7,6]  R1743     -5.7264614105224609e-01
    z[4,7,6]  R1744     4.1925567388534546e-01
    z[4,7,6]  R1745     0.0626790001988411
    z[4,7,6]  R1746     3.5951954126358032e-01
    z[4,7,6]  R1747     -2.6943216100335121e-02
    z[4,7,6]  R1748     6.1659656465053558e-02
    z[4,7,6]  R1749     -5.6406247615814209e-01
    z[4,7,6]  R1750     2.7087292075157166e-01
    z[4,7,6]  R1751     1.2039686739444733e-01
    z[4,7,6]  R1752     -5.1999503374099731e-01
    z[4,7,6]  R1753     4.2394686490297318e-02
    z[4,7,6]  R1754     -7.0953494310379028e-01
    z[4,7,6]  R1755     -1.5739767253398895e-01
    z[4,7,6]  R1756     -5.2332168817520142e-01
    z[4,7,6]  R1757     1.5810205042362213e-01
    z[4,7,6]  R1758     -4.7031126916408539e-02
    z[4,7,6]  R1759     -1.8030360341072083e-01
    z[4,7,6]  R1760     -7.2309148311614990e-01
    z[4,7,6]  R1761     3.3120226860046387e-01
    z[4,7,6]  R1762     4.0426653623580933e-01
    z[4,7,6]  R1763     4.0536105632781982e-01
    z[4,7,6]  R1764     -3.6374846100807190e-01
    z[4,7,6]  R1765     -1.3886626809835434e-02
    z[4,7,6]  R1766     -1.3277682662010193e-01
    z[4,7,6]  R1767     0.0638522282242775
    z[4,7,6]  R1768     1.0440131276845932e-01
    z[4,7,6]  R1769     0.191190704703331
    z[4,7,6]  R1770     4.4415897130966187e-01
    z[4,7,6]  R1771     3.3849492669105530e-02
    z[4,7,6]  R1772     -1.6048131883144379e-01
    z[4,7,6]  R1773     2.4727353453636169e-01
    z[4,7,6]  R1774     -1.9234076142311096e-02
    z[4,7,6]  R1775     8.0929987132549286e-02
    z[4,7,6]  R1776     1.6371706128120422e-01
    z[7,4,0]  R38       1
    z[7,4,0]  R65       -1
    z[7,4,0]  R1777     -1
    z[7,4,0]  R1778     1
    z[7,4,0]  R1791     1.2360244244337082e-01
    z[7,4,0]  R1792     0.0306143369525671
    z[7,4,0]  R1793     5.4720234870910645e-01
    z[7,4,0]  R1794     -2.0705135166645050e-01
    z[7,4,0]  R1795     1.3450443744659424e-01
    z[7,4,0]  R1796     -0.511566698551178
    z[7,4,0]  R1797     1.0518323630094528e-01
    z[7,4,0]  R1798     -2.5864261388778687e-01
    z[7,4,0]  R1799     1.4801529049873352e-01
    z[7,4,0]  R1800     3.2486591488122940e-02
    z[7,4,0]  R1801     -3.0512461066246033e-01
    z[7,4,0]  R1802     7.9080504179000854e-01
    z[7,4,0]  R1803     1.4882269501686096e-01
    z[7,4,0]  R1804     -1.1800559610128403e-01
    z[7,4,0]  R1805     6.5329587459564209e-01
    z[7,4,0]  R1806     -3.3021083474159241e-01
    z[7,4,0]  R1807     7.9478567838668823e-01
    z[7,4,0]  R1808     5.5110937356948853e-01
    z[7,4,0]  R1809     4.3531551957130432e-01
    z[7,4,0]  R1810     3.7732085585594177e-01
    z[7,4,0]  R1811     -1.6677637398242950e-01
    z[7,4,0]  R1812     2.7080655097961426e-01
    z[7,4,0]  R1813     -0.333111971616745
    z[7,4,0]  R1814     -1.1851393431425095e-01
    z[7,4,0]  R1815     -4.5830646157264709e-01
    z[7,4,0]  R1816     4.4970255345106125e-02
    z[7,4,0]  R1817     -1.8352389335632324e-01
    z[7,4,0]  R1818     5.0772237777709961e-01
    z[7,4,0]  R1819     -6.1997871845960617e-02
    z[7,4,0]  R1820     -4.8145502805709839e-01
    z[7,4,0]  R1821     8.8104113936424255e-02
    z[7,4,0]  R1822     -4.3010520935058594e-01
    z[7,4,0]  R1823     4.6591836214065552e-01
    z[7,4,0]  R1824     6.7357790470123291e-01
    z[7,4,0]  R1825     -7.2544604539871216e-02
    z[7,4,0]  R1826     3.9823567867279053e-01
    z[7,4,0]  R1827     3.9311617612838745e-01
    z[7,4,0]  R1828     -2.2881540656089783e-01
    z[7,4,0]  R1829     -4.2141190171241760e-01
    z[7,4,0]  R1830     4.0351420640945435e-01
    z[7,4,0]  R1831     -8.3761967718601227e-02
    z[7,4,0]  R1832     -7.7193096280097961e-02
    z[7,4,0]  R1833     1.5632240474224091e-01
    z[7,4,0]  R1834     6.7632240056991577e-01
    z[7,4,0]  R1835     -4.5164099335670471e-01
    z[7,4,0]  R1836     -4.4391790032386780e-01
    z[7,4,0]  R1837     6.6559958457946777e-01
    z[7,4,0]  R1838     4.1964778304100037e-01
    z[7,4,0]  R1839     2.3575158417224884e-01
    z[7,4,0]  R1840     0.111433245241642
    z[7,4,0]  R1841     -4.4875025749206543e-01
    z[7,4,0]  R1842     -3.7401786446571350e-01
    z[7,4,0]  R1843     4.4309237599372864e-01
    z[7,4,0]  R1844     -5.9246625751256943e-02
    z[7,4,0]  R1845     7.8633022308349609e-01
    z[7,4,0]  R1846     -1.7872239649295807e-01
    z[7,4,0]  R1847     0.093810074031353
    z[7,4,0]  R1848     4.2910650372505188e-01
    z[7,4,0]  R1849     3.7557142972946167e-01
    z[7,4,0]  R1850     3.7017074227333069e-01
    z[7,4,0]  R1851     2.1927321329712868e-02
    z[7,4,0]  R1852     3.6122921854257584e-02
    z[7,4,0]  R1853     -4.5800682902336121e-01
    z[7,4,0]  R1854     5.4896444082260132e-01
    z[7,4,0]  R1855     7.0793789625167847e-01
    z[7,4,0]  R1856     0.505699872970581
    z[7,4,0]  R1857     3.4056031703948975e-01
    z[7,4,0]  R1858     2.2189356386661530e-01
    z[7,4,0]  R1859     2.6149040460586548e-01
    z[7,4,0]  R1860     1.1316373199224472e-01
    z[7,4,0]  R1861     -1.7203774303197861e-02
    z[7,4,0]  R1862     7.8943118453025818e-02
    z[7,4,0]  R1863     -3.1039005517959595e-01
    z[7,4,0]  R1864     2.4173296988010406e-02
    z[7,4,0]  R1865     -6.1115708202123642e-02
    z[7,4,0]  R1866     -4.9999356269836426e-01
    z[7,4,0]  R1867     -2.6486939191818237e-01
    z[7,4,0]  R1868     -5.6621241569519043e-01
    z[7,4,0]  R1869     -1.5911825001239777e-01
    z[7,4,0]  R1870     -8.3460539579391479e-02
    z[7,4,0]  R1871     -2.9796180129051208e-01
    z[7,4,0]  R1872     -0.10040283203125
    z[7,4,0]  R1873     -1.1207935959100723e-01
    z[7,4,0]  R1874     -5.4521399736404419e-01
    z[7,4,0]  R1875     2.1134330017957836e-04
    z[7,4,0]  R1876     1.8737228214740753e-01
    z[7,4,0]  R1877     -3.7565141916275024e-01
    z[7,4,0]  R1878     -1.3508066534996033e-01
    z[7,4,0]  R1879     7.3875255882740021e-02
    z[7,4,0]  R1880     2.6147386431694031e-01
    z[7,4,0]  R1881     -5.3577542304992676e-01
    z[7,4,0]  R1882     4.5376780629158020e-01
    z[7,4,0]  R1883     6.9701528549194336e-01
    z[7,4,0]  R1884     -2.9086044430732727e-01
    z[7,4,0]  R1885     6.3951069116592407e-01
    z[7,4,0]  R1886     0.605835497379303
    z[7,4,0]  R1887     7.0761835575103760e-01
    z[7,4,0]  R1888     3.8629552721977234e-01
    z[7,4,0]  R1889     3.6952725052833557e-01
    z[7,4,0]  R1890     -9.5478974282741547e-02
    z[7,4,0]  R1891     -5.1158881187438965e-01
    z[7,4,0]  R1892     -4.5761802792549133e-01
    z[7,4,0]  R1893     -4.9912708997726440e-01
    z[7,4,0]  R1894     5.7854449748992920e-01
    z[7,4,0]  R1895     -2.5291821360588074e-01
    z[7,4,1]  R39       1
    z[7,4,1]  R66       -1
    z[7,4,1]  R1779     -1
    z[7,4,1]  R1780     1
    z[7,4,1]  R1791     1.2836413085460663e-01
    z[7,4,1]  R1792     -7.6285108923912048e-02
    z[7,4,1]  R1793     -5.3504884243011475e-01
    z[7,4,1]  R1794     -2.1105191111564636e-01
    z[7,4,1]  R1795     5.5811733007431030e-01
    z[7,4,1]  R1796     -2.0206277072429657e-01
    z[7,4,1]  R1797     8.3387774229049683e-01
    z[7,4,1]  R1798     -8.2305364310741425e-02
    z[7,4,1]  R1799     7.9791676998138428e-01
    z[7,4,1]  R1800     0.586044430732727
    z[7,4,1]  R1801     -5.3130376338958740e-01
    z[7,4,1]  R1802     3.3108010888099670e-01
    z[7,4,1]  R1803     -7.8599143028259277e-01
    z[7,4,1]  R1804     -8.3646696805953979e-01
    z[7,4,1]  R1805     6.7285680770874023e-01
    z[7,4,1]  R1806     -7.8959834575653076e-01
    z[7,4,1]  R1807     2.3742099106311798e-01
    z[7,4,1]  R1808     2.6344174146652222e-01
    z[7,4,1]  R1809     -4.5459401607513428e-01
    z[7,4,1]  R1810     -4.6511086821556091e-01
    z[7,4,1]  R1811     -0.762222409248352
    z[7,4,1]  R1812     -1.6407574713230133e-01
    z[7,4,1]  R1813     -5.3735202550888062e-01
    z[7,4,1]  R1814     -4.3657287955284119e-01
    z[7,4,1]  R1815     -4.2445501685142517e-01
    z[7,4,1]  R1816     -8.2359558343887329e-01
    z[7,4,1]  R1817     -4.7783127427101135e-01
    z[7,4,1]  R1818     -4.5591521263122559e-01
    z[7,4,1]  R1819     -1.6740456223487854e-02
    z[7,4,1]  R1820     2.0488715171813965e-01
    z[7,4,1]  R1821     -2.7302113175392151e-01
    z[7,4,1]  R1822     -7.5260102748870850e-02
    z[7,4,1]  R1823     4.2384776473045349e-01
    z[7,4,1]  R1824     4.9414092302322388e-01
    z[7,4,1]  R1825     -4.0998184680938721e-01
    z[7,4,1]  R1826     6.5227466821670532e-01
    z[7,4,1]  R1827     3.4529119729995728e-01
    z[7,4,1]  R1828     -4.3794006109237671e-01
    z[7,4,1]  R1829     2.8829118609428406e-01
    z[7,4,1]  R1830     -4.0004888176918030e-01
    z[7,4,1]  R1831     -1.4097803831100464e-01
    z[7,4,1]  R1832     -7.5582391023635864e-01
    z[7,4,1]  R1833     -8.4233134984970093e-01
    z[7,4,1]  R1834     6.8047583103179932e-01
    z[7,4,1]  R1835     -0.270486056804657
    z[7,4,1]  R1836     -5.3289192914962769e-01
    z[7,4,1]  R1837     1.0219454765319824e-01
    z[7,4,1]  R1838     3.2792839407920837e-01
    z[7,4,1]  R1839     9.3890947103500366e-01
    z[7,4,1]  R1840     9.6040832996368408e-01
    z[7,4,1]  R1841     -4.1371452808380127e-01
    z[7,4,1]  R1842     6.7751012742519379e-02
    z[7,4,1]  R1843     -0.66004878282547
    z[7,4,1]  R1844     -5.4887789487838745e-01
    z[7,4,1]  R1845     -5.1548504829406738e-01
    z[7,4,1]  R1846     3.7859001755714417e-01
    z[7,4,1]  R1847     -3.9288067817687988e-01
    z[7,4,1]  R1848     -3.5894498229026794e-01
    z[7,4,1]  R1849     8.3690589666366577e-01
    z[7,4,1]  R1850     8.2600378990173340e-01
    z[7,4,1]  R1851     -3.0824273824691772e-01
    z[7,4,1]  R1852     4.1268173605203629e-02
    z[7,4,1]  R1853     -6.1525326967239380e-01
    z[7,4,1]  R1854     2.7501374483108521e-01
    z[7,4,1]  R1855     1.1398664861917496e-01
    z[7,4,1]  R1856     -4.1105547547340393e-01
    z[7,4,1]  R1857     9.1148459911346436e-01
    z[7,4,1]  R1858     9.2428731918334961e-01
    z[7,4,1]  R1859     9.2195343971252441e-01
    z[7,4,1]  R1860     9.0650641918182373e-01
    z[7,4,1]  R1861     -1.7797312140464783e-01
    z[7,4,1]  R1862     -0.44866743683815
    z[7,4,1]  R1863     9.2515224218368530e-01
    z[7,4,1]  R1864     6.3834863901138306e-01
    z[7,4,1]  R1865     5.8140450716018677e-01
    z[7,4,1]  R1866     7.2880762815475464e-01
    z[7,4,1]  R1867     5.9469151496887207e-01
    z[7,4,1]  R1868     0.667008638381958
    z[7,4,1]  R1869     -2.1109507977962494e-01
    z[7,4,1]  R1870     3.6115714907646179e-01
    z[7,4,1]  R1871     5.0819098949432373e-01
    z[7,4,1]  R1872     6.0065197944641113e-01
    z[7,4,1]  R1873     2.9567638039588928e-01
    z[7,4,1]  R1874     -2.9722964763641357e-01
    z[7,4,1]  R1875     -2.6562201976776123e-01
    z[7,4,1]  R1876     -1.9744651019573212e-01
    z[7,4,1]  R1877     -1.0959574580192566e-01
    z[7,4,1]  R1878     -1.5208879113197327e-01
    z[7,4,1]  R1879     -7.6956021785736084e-01
    z[7,4,1]  R1880     -8.6423909664154053e-01
    z[7,4,1]  R1881     -7.2976911067962646e-01
    z[7,4,1]  R1882     -6.6835129261016846e-01
    z[7,4,1]  R1883     -6.9223767518997192e-01
    z[7,4,1]  R1884     -0.820530116558075
    z[7,4,1]  R1885     4.5963096618652344e-01
    z[7,4,1]  R1886     7.0677846670150757e-01
    z[7,4,1]  R1887     3.9970946311950684e-01
    z[7,4,1]  R1888     0.728522002696991
    z[7,4,1]  R1889     -7.0043218135833740e-01
    z[7,4,1]  R1890     -6.0439997911453247e-01
    z[7,4,1]  R1891     -7.9351294040679932e-01
    z[7,4,1]  R1892     -5.0827115774154663e-01
    z[7,4,1]  R1893     2.3698510229587555e-01
    z[7,4,1]  R1894     6.2553894519805908e-01
    z[7,4,1]  R1895     4.3601259589195251e-01
    z[7,4,2]  R40       1
    z[7,4,2]  R67       -1
    z[7,4,2]  R1781     -1
    z[7,4,2]  R1782     1
    z[7,4,2]  R1791     -3.6473503708839417e-01
    z[7,4,2]  R1792     -0.315572589635849
    z[7,4,2]  R1793     2.5939446687698364e-01
    z[7,4,2]  R1794     1.5178416669368744e-01
    z[7,4,2]  R1795     3.3390790224075317e-01
    z[7,4,2]  R1796     4.8268872499465942e-01
    z[7,4,2]  R1797     1.5913186967372894e-01
    z[7,4,2]  R1798     6.3994270563125610e-01
    z[7,4,2]  R1799     2.3718601465225220e-01
    z[7,4,2]  R1800     3.4481936693191528e-01
    z[7,4,2]  R1801     1.7182333767414093e-01
    z[7,4,2]  R1802     2.6018142700195312e-01
    z[7,4,2]  R1803     -4.2362990975379944e-01
    z[7,4,2]  R1804     -2.2558629512786865e-01
    z[7,4,2]  R1805     1.8069089949131012e-01
    z[7,4,2]  R1806     -1.9469912350177765e-01
    z[7,4,2]  R1807     5.2703386172652245e-03
    z[7,4,2]  R1808     -3.4479784965515137e-01
    z[7,4,2]  R1809     -8.1773988902568817e-02
    z[7,4,2]  R1810     2.2669050097465515e-01
    z[7,4,2]  R1811     2.6220592856407166e-01
    z[7,4,2]  R1812     -1.3925200700759888e-01
    z[7,4,2]  R1813     5.2966678142547607e-01
    z[7,4,2]  R1814     -3.4921181201934814e-01
    z[7,4,2]  R1815     1.3471728563308716e-01
    z[7,4,2]  R1816     -4.7267618775367737e-01
    z[7,4,2]  R1817     2.4360284209251404e-01
    z[7,4,2]  R1818     4.5246556401252747e-01
    z[7,4,2]  R1819     3.6115118861198425e-01
    z[7,4,2]  R1820     3.9397758245468140e-01
    z[7,4,2]  R1821     -2.2256558761000633e-02
    z[7,4,2]  R1822     0.428076833486557
    z[7,4,2]  R1823     2.8458023443818092e-03
    z[7,4,2]  R1824     2.1882055699825287e-01
    z[7,4,2]  R1825     1.9023905694484711e-01
    z[7,4,2]  R1826     1.5313657000660896e-02
    z[7,4,2]  R1827     -9.7747206687927246e-02
    z[7,4,2]  R1828     -3.2966170459985733e-02
    z[7,4,2]  R1829     3.1236311793327332e-01
    z[7,4,2]  R1830     -6.5187156200408936e-01
    z[7,4,2]  R1831     -5.4828889667987823e-02
    z[7,4,2]  R1832     1.0606251657009125e-01
    z[7,4,2]  R1833     -2.7343055605888367e-01
    z[7,4,2]  R1834     1.9612836185842752e-03
    z[7,4,2]  R1835     3.8312498945742846e-03
    z[7,4,2]  R1836     -1.1785271763801575e-01
    z[7,4,2]  R1837     -2.9135072231292725e-01
    z[7,4,2]  R1838     6.2200218439102173e-01
    z[7,4,2]  R1839     -1.9933420419692993e-01
    z[7,4,2]  R1840     -9.5623753964900970e-02
    z[7,4,2]  R1841     2.1981850266456604e-02
    z[7,4,2]  R1842     4.2391413450241089e-01
    z[7,4,2]  R1843     -9.2750638723373413e-02
    z[7,4,2]  R1844     1.4911958575248718e-01
    z[7,4,2]  R1845     2.6723194122314453e-01
    z[7,4,2]  R1846     1.3118797540664673e-01
    z[7,4,2]  R1847     -0.584646463394165
    z[7,4,2]  R1848     -5.7222151756286621e-01
    z[7,4,2]  R1849     -9.1069459915161133e-02
    z[7,4,2]  R1850     9.5958143472671509e-02
    z[7,4,2]  R1851     2.0737320184707642e-02
    z[7,4,2]  R1852     -1.0694067925214767e-01
    z[7,4,2]  R1853     1.4552344381809235e-01
    z[7,4,2]  R1854     1.8929733335971832e-01
    z[7,4,2]  R1855     -7.9540058970451355e-02
    z[7,4,2]  R1856     -6.1340779066085815e-01
    z[7,4,2]  R1857     4.8959512263536453e-02
    z[7,4,2]  R1858     -4.5501585118472576e-03
    z[7,4,2]  R1859     1.9258438050746918e-01
    z[7,4,2]  R1860     3.5356727242469788e-01
    z[7,4,2]  R1861     2.0872248709201813e-01
    z[7,4,2]  R1862     -3.4142377972602844e-01
    z[7,4,2]  R1863     1.2800908088684082e-01
    z[7,4,2]  R1864     -9.1829463839530945e-02
    z[7,4,2]  R1865     -2.1675500273704529e-01
    z[7,4,2]  R1866     -2.1271312609314919e-02
    z[7,4,2]  R1867     -1.1073148995637894e-01
    z[7,4,2]  R1868     -3.6913838982582092e-01
    z[7,4,2]  R1869     -1.8154074251651764e-01
    z[7,4,2]  R1870     -2.8845322132110596e-01
    z[7,4,2]  R1871     -3.8084396719932556e-01
    z[7,4,2]  R1872     -0.0054810531437397
    z[7,4,2]  R1873     -2.6502066850662231e-01
    z[7,4,2]  R1874     -1.4793653041124344e-02
    z[7,4,2]  R1875     1.4257819950580597e-01
    z[7,4,2]  R1876     -1.3961243629455566e-01
    z[7,4,2]  R1877     1.1071675270795822e-01
    z[7,4,2]  R1878     1.3990931212902069e-01
    z[7,4,2]  R1879     -2.8753346204757690e-01
    z[7,4,2]  R1880     -1.6213077306747437e-01
    z[7,4,2]  R1881     -1.3287785649299622e-01
    z[7,4,2]  R1882     -1.4928828179836273e-01
    z[7,4,2]  R1883     -1.3702154159545898e-01
    z[7,4,2]  R1884     -5.3955212235450745e-02
    z[7,4,2]  R1885     2.1143613755702972e-01
    z[7,4,2]  R1886     1.2658575177192688e-01
    z[7,4,2]  R1887     9.6190765500068665e-02
    z[7,4,2]  R1888     3.9736970211379230e-04
    z[7,4,2]  R1889     -4.7123380005359650e-02
    z[7,4,2]  R1890     -7.1347869932651520e-02
    z[7,4,2]  R1891     -8.1454485654830933e-02
    z[7,4,2]  R1892     -1.7367942631244659e-01
    z[7,4,2]  R1893     1.4274470508098602e-01
    z[7,4,2]  R1894     -1.7110915854573250e-02
    z[7,4,2]  R1895     -1.8773204088211060e-01
    z[7,4,3]  R41       1
    z[7,4,3]  R68       -1
    z[7,4,3]  R1783     -1
    z[7,4,3]  R1784     1
    z[7,4,3]  R1791     -2.9773136973381042e-01
    z[7,4,3]  R1792     -4.7056525945663452e-01
    z[7,4,3]  R1793     -5.1373803615570068e-01
    z[7,4,3]  R1794     -9.6666947007179260e-02
    z[7,4,3]  R1795     -5.6725364923477173e-01
    z[7,4,3]  R1796     5.3634798526763916e-01
    z[7,4,3]  R1797     -4.5542147755622864e-01
    z[7,4,3]  R1798     3.9375522732734680e-01
    z[7,4,3]  R1799     -3.3225673437118530e-01
    z[7,4,3]  R1800     -6.4335089921951294e-01
    z[7,4,3]  R1801     -6.6603964567184448e-01
    z[7,4,3]  R1802     -2.0372414588928223e-01
    z[7,4,3]  R1803     1.4815287292003632e-01
    z[7,4,3]  R1804     -1.4601313509047031e-02
    z[7,4,3]  R1805     2.0684491097927094e-01
    z[7,4,3]  R1806     -3.8015641272068024e-02
    z[7,4,3]  R1807     4.5650738477706909e-01
    z[7,4,3]  R1808     -2.1075144410133362e-01
    z[7,4,3]  R1809     -1.9165011122822762e-02
    z[7,4,3]  R1810     3.7987983226776123e-01
    z[7,4,3]  R1811     1.0237257182598114e-01
    z[7,4,3]  R1812     3.8853892683982849e-01
    z[7,4,3]  R1813     4.2647641897201538e-01
    z[7,4,3]  R1814     -1.4260447025299072e-01
    z[7,4,3]  R1815     2.6867750287055969e-01
    z[7,4,3]  R1816     -1.5323288738727570e-01
    z[7,4,3]  R1817     2.7281916141510010e-01
    z[7,4,3]  R1818     4.9727344512939453e-01
    z[7,4,3]  R1819     7.3696893453598022e-01
    z[7,4,3]  R1820     2.2377386689186096e-02
    z[7,4,3]  R1821     4.9843266606330872e-01
    z[7,4,3]  R1822     5.5681866407394409e-01
    z[7,4,3]  R1823     -6.0512870550155640e-01
    z[7,4,3]  R1824     0.0890241339802742
    z[7,4,3]  R1825     -4.6217706799507141e-01
    z[7,4,3]  R1826     -4.0138861536979675e-01
    z[7,4,3]  R1827     -6.1015748977661133e-01
    z[7,4,3]  R1828     2.2263512015342712e-01
    z[7,4,3]  R1829     2.0708565413951874e-01
    z[7,4,3]  R1830     -4.8841637372970581e-01
    z[7,4,3]  R1831     1.5461874008178711e-01
    z[7,4,3]  R1832     2.8776556253433228e-01
    z[7,4,3]  R1833     2.1502895653247833e-01
    z[7,4,3]  R1834     -2.0312415063381195e-01
    z[7,4,3]  R1835     -1.0942038893699646e-01
    z[7,4,3]  R1836     -5.6919389963150024e-01
    z[7,4,3]  R1837     -4.9499401450157166e-01
    z[7,4,3]  R1838     -4.2022615671157837e-01
    z[7,4,3]  R1839     1.2178914248943329e-01
    z[7,4,3]  R1840     2.4164592847228050e-02
    z[7,4,3]  R1841     -1.6868244856595993e-02
    z[7,4,3]  R1842     3.1191563606262207e-01
    z[7,4,3]  R1843     9.8548196256160736e-02
    z[7,4,3]  R1844     -2.2359421476721764e-02
    z[7,4,3]  R1845     -1.6333516687154770e-02
    z[7,4,3]  R1846     3.0073146335780621e-03
    z[7,4,3]  R1847     -5.5990648269653320e-01
    z[7,4,3]  R1848     3.5550169646739960e-02
    z[7,4,3]  R1849     8.1884294748306274e-02
    z[7,4,3]  R1850     1.6896691918373108e-01
    z[7,4,3]  R1851     5.1314628124237061e-01
    z[7,4,3]  R1852     1.3779959082603455e-01
    z[7,4,3]  R1853     -1.9642950594425201e-01
    z[7,4,3]  R1854     -5.2982360124588013e-01
    z[7,4,3]  R1855     -3.9600214362144470e-01
    z[7,4,3]  R1856     3.2492477446794510e-02
    z[7,4,3]  R1857     1.7291373014450073e-01
    z[7,4,3]  R1858     -0.0959969162940979
    z[7,4,3]  R1859     1.9805204123258591e-02
    z[7,4,3]  R1860     1.8201887607574463e-02
    z[7,4,3]  R1861     5.6374704837799072e-01
    z[7,4,3]  R1862     -6.0380709171295166e-01
    z[7,4,3]  R1863     1.7328624427318573e-01
    z[7,4,3]  R1864     7.2874200344085693e-01
    z[7,4,3]  R1865     7.1704608201980591e-01
    z[7,4,3]  R1866     -2.5790292024612427e-01
    z[7,4,3]  R1867     6.7493087053298950e-01
    z[7,4,3]  R1868     -1.8290762603282928e-01
    z[7,4,3]  R1869     -6.6604685783386230e-01
    z[7,4,3]  R1870     1.4893932640552521e-01
    z[7,4,3]  R1871     3.7170371413230896e-01
    z[7,4,3]  R1872     -1.8350727856159210e-01
    z[7,4,3]  R1873     0.0356985442340374
    z[7,4,3]  R1874     -4.7900900244712830e-01
    z[7,4,3]  R1875     -8.2958471775054932e-01
    z[7,4,3]  R1876     -4.9599045515060425e-01
    z[7,4,3]  R1877     -3.3634263277053833e-01
    z[7,4,3]  R1878     -4.4997262954711914e-01
    z[7,4,3]  R1879     0.351880818605423
    z[7,4,3]  R1880     1.5563932061195374e-01
    z[7,4,3]  R1881     0.0896289050579071
    z[7,4,3]  R1882     4.4433671981096268e-02
    z[7,4,3]  R1883     1.1404450237751007e-01
    z[7,4,3]  R1884     0.393184632062912
    z[7,4,3]  R1885     -4.0812357328832150e-03
    z[7,4,3]  R1886     3.0470450874418020e-03
    z[7,4,3]  R1887     4.4962140917778015e-01
    z[7,4,3]  R1888     -2.7278661727905273e-01
    z[7,4,3]  R1889     -5.2548497915267944e-01
    z[7,4,3]  R1890     -7.1449923515319824e-01
    z[7,4,3]  R1891     8.6602732539176941e-02
    z[7,4,3]  R1892     -0.456758052110672
    z[7,4,3]  R1893     5.5406648665666580e-02
    z[7,4,3]  R1894     5.1946036517620087e-02
    z[7,4,3]  R1895     4.9007901549339294e-01
    z[7,4,4]  R42       1
    z[7,4,4]  R69       -1
    z[7,4,4]  R1785     -1
    z[7,4,4]  R1786     1
    z[7,4,4]  R1791     -0.514081597328186
    z[7,4,4]  R1792     -1.2707982957363129e-01
    z[7,4,4]  R1793     -2.6603189110755920e-01
    z[7,4,4]  R1794     6.1554533243179321e-01
    z[7,4,4]  R1795     -4.0420621633529663e-01
    z[7,4,4]  R1796     1.7329661548137665e-01
    z[7,4,4]  R1797     1.4906750619411469e-01
    z[7,4,4]  R1798     2.7997341752052307e-01
    z[7,4,4]  R1799     1.4735132455825806e-02
    z[7,4,4]  R1800     1.0696996748447418e-01
    z[7,4,4]  R1801     -3.8329381495714188e-02
    z[7,4,4]  R1802     2.4498523771762848e-01
    z[7,4,4]  R1803     -3.0189722776412964e-01
    z[7,4,4]  R1804     -1.3840667903423309e-01
    z[7,4,4]  R1805     1.9698446616530418e-02
    z[7,4,4]  R1806     -4.2618361115455627e-01
    z[7,4,4]  R1807     9.0292975306510925e-02
    z[7,4,4]  R1808     4.4573080539703369e-01
    z[7,4,4]  R1809     7.0526683330535889e-01
    z[7,4,4]  R1810     2.2930772602558136e-01
    z[7,4,4]  R1811     2.5002929568290710e-01
    z[7,4,4]  R1812     -3.4208881855010986e-01
    z[7,4,4]  R1813     1.9140517711639404e-01
    z[7,4,4]  R1814     -8.0715966224670410e-01
    z[7,4,4]  R1815     -3.9832934737205505e-01
    z[7,4,4]  R1816     9.0377889573574066e-02
    z[7,4,4]  R1817     -5.5513745546340942e-01
    z[7,4,4]  R1818     1.2700709700584412e-01
    z[7,4,4]  R1819     -8.0024421215057373e-02
    z[7,4,4]  R1820     -3.8305470347404480e-01
    z[7,4,4]  R1821     2.8270408511161804e-01
    z[7,4,4]  R1822     -3.2083618640899658e-01
    z[7,4,4]  R1823     -3.7383839488029480e-01
    z[7,4,4]  R1824     -2.9608780145645142e-01
    z[7,4,4]  R1825     2.8118072077631950e-02
    z[7,4,4]  R1826     -2.6770675182342529e-01
    z[7,4,4]  R1827     2.5118380784988403e-01
    z[7,4,4]  R1828     -6.5479505062103271e-01
    z[7,4,4]  R1829     -4.5285901427268982e-01
    z[7,4,4]  R1830     0.0766245424747467
    z[7,4,4]  R1831     -3.6809706687927246e-01
    z[7,4,4]  R1832     4.2856097221374512e-02
    z[7,4,4]  R1833     1.2355703860521317e-01
    z[7,4,4]  R1834     -1.7000260949134827e-01
    z[7,4,4]  R1835     -1.7644479870796204e-02
    z[7,4,4]  R1836     -5.0424743443727493e-02
    z[7,4,4]  R1837     4.4696271419525146e-01
    z[7,4,4]  R1838     -0.0360000804066658
    z[7,4,4]  R1839     -7.9047113656997681e-02
    z[7,4,4]  R1840     -4.9157503992319107e-02
    z[7,4,4]  R1841     1.4077517390251160e-01
    z[7,4,4]  R1842     -2.8249008581042290e-02
    z[7,4,4]  R1843     -5.6559729576110840e-01
    z[7,4,4]  R1844     -6.1346596479415894e-01
    z[7,4,4]  R1845     1.0119650512933731e-02
    z[7,4,4]  R1846     1.6915602609515190e-02
    z[7,4,4]  R1847     -3.8995620608329773e-01
    z[7,4,4]  R1848     -2.7812096476554871e-01
    z[7,4,4]  R1849     2.9832589626312256e-01
    z[7,4,4]  R1850     -3.5633894801139832e-01
    z[7,4,4]  R1851     4.3829031288623810e-02
    z[7,4,4]  R1852     1.8756887875497341e-03
    z[7,4,4]  R1853     -3.6813512444496155e-01
    z[7,4,4]  R1854     1.4003157615661621e-01
    z[7,4,4]  R1855     3.8114407658576965e-01
    z[7,4,4]  R1856     -2.4910818040370941e-01
    z[7,4,4]  R1857     6.7822217941284180e-02
    z[7,4,4]  R1858     -1.9547192752361298e-01
    z[7,4,4]  R1859     -1.9871446490287781e-01
    z[7,4,4]  R1860     5.5680975317955017e-02
    z[7,4,4]  R1861     1.2122242152690887e-01
    z[7,4,4]  R1862     1.2970919907093048e-01
    z[7,4,4]  R1863     -3.7139644846320152e-03
    z[7,4,4]  R1864     -1.3720582425594330e-01
    z[7,4,4]  R1865     1.1584879830479622e-03
    z[7,4,4]  R1866     -3.3810895681381226e-01
    z[7,4,4]  R1867     2.6022934913635254e-01
    z[7,4,4]  R1868     1.8798503279685974e-01
    z[7,4,4]  R1869     -6.1221265792846680e-01
    z[7,4,4]  R1870     -4.4700881838798523e-01
    z[7,4,4]  R1871     1.2542865239083767e-02
    z[7,4,4]  R1872     -1.7818284034729004e-01
    z[7,4,4]  R1873     -3.4217327833175659e-02
    z[7,4,4]  R1874     -2.6628868654370308e-02
    z[7,4,4]  R1875     2.5206291675567627e-01
    z[7,4,4]  R1876     -4.1365686058998108e-01
    z[7,4,4]  R1877     5.7872142642736435e-02
    z[7,4,4]  R1878     3.1724950671195984e-01
    z[7,4,4]  R1879     -3.1405866146087646e-01
    z[7,4,4]  R1880     0.023549759760499
    z[7,4,4]  R1881     -1.1894471943378448e-01
    z[7,4,4]  R1882     -7.0711731910705566e-02
    z[7,4,4]  R1883     5.1908683031797409e-02
    z[7,4,4]  R1884     2.0215994119644165e-01
    z[7,4,4]  R1885     5.2272111177444458e-01
    z[7,4,4]  R1886     1.8284878134727478e-01
    z[7,4,4]  R1887     2.5019386410713196e-01
    z[7,4,4]  R1888     -2.1078962087631226e-01
    z[7,4,4]  R1889     1.0750237107276917e-01
    z[7,4,4]  R1890     -5.4194923490285873e-02
    z[7,4,4]  R1891     1.0144741833209991e-01
    z[7,4,4]  R1892     -3.7986236810684204e-01
    z[7,4,4]  R1893     9.0818911790847778e-02
    z[7,4,4]  R1894     -2.8622266650199890e-01
    z[7,4,4]  R1895     -6.6355979442596436e-01
    z[7,4,5]  R43       1
    z[7,4,5]  R70       -1
    z[7,4,5]  R1787     -1
    z[7,4,5]  R1788     1
    z[7,4,5]  R1791     5.9163773059844971e-01
    z[7,4,5]  R1792     8.0719190835952759e-01
    z[7,4,5]  R1793     -4.1230313479900360e-02
    z[7,4,5]  R1794     0.662135660648346
    z[7,4,5]  R1795     2.0706829428672791e-01
    z[7,4,5]  R1796     3.3804544806480408e-01
    z[7,4,5]  R1797     9.5515400171279907e-02
    z[7,4,5]  R1798     0.505935549736023
    z[7,4,5]  R1799     1.1857295036315918e-01
    z[7,4,5]  R1800     2.4743312597274780e-01
    z[7,4,5]  R1801     -2.0205296576023102e-01
    z[7,4,5]  R1802     2.1121473610401154e-01
    z[7,4,5]  R1803     -2.5830811262130737e-01
    z[7,4,5]  R1804     -5.7815372943878174e-02
    z[7,4,5]  R1805     -1.8703229725360870e-01
    z[7,4,5]  R1806     1.1776927113533020e-01
    z[7,4,5]  R1807     -1.4460229873657227e-01
    z[7,4,5]  R1808     -2.6085074990987778e-02
    z[7,4,5]  R1809     -3.1523931026458740e-01
    z[7,4,5]  R1810     4.5445635914802551e-01
    z[7,4,5]  R1811     4.9852064251899719e-01
    z[7,4,5]  R1812     7.3102825880050659e-01
    z[7,4,5]  R1813     -0.29815673828125
    z[7,4,5]  R1814     5.6530215078964829e-04
    z[7,4,5]  R1815     6.0024946928024292e-01
    z[7,4,5]  R1816     0.0422833114862442
    z[7,4,5]  R1817     -4.9906989932060242e-01
    z[7,4,5]  R1818     -2.4751673638820648e-01
    z[7,4,5]  R1819     5.0589424371719360e-01
    z[7,4,5]  R1820     4.6643459796905518e-01
    z[7,4,5]  R1821     4.9176892638206482e-01
    z[7,4,5]  R1822     4.5104572176933289e-01
    z[7,4,5]  R1823     -2.8282532095909119e-01
    z[7,4,5]  R1824     9.0691685676574707e-02
    z[7,4,5]  R1825     9.3692235648632050e-02
    z[7,4,5]  R1826     8.2366280257701874e-02
    z[7,4,5]  R1827     -1.0965884663164616e-02
    z[7,4,5]  R1828     1.4352850615978241e-01
    z[7,4,5]  R1829     5.3257197141647339e-01
    z[7,4,5]  R1830     6.5734423696994781e-02
    z[7,4,5]  R1831     9.0009754896163940e-01
    z[7,4,5]  R1832     -5.0257092714309692e-01
    z[7,4,5]  R1833     -3.0434669926762581e-02
    z[7,4,5]  R1834     -5.0444877706468105e-03
    z[7,4,5]  R1835     6.1857527494430542e-01
    z[7,4,5]  R1836     5.2670907229185104e-02
    z[7,4,5]  R1837     -1.1368764191865921e-01
    z[7,4,5]  R1838     -1.4943751692771912e-01
    z[7,4,5]  R1839     3.6455500870943069e-02
    z[7,4,5]  R1840     -2.2192882001399994e-01
    z[7,4,5]  R1841     5.3731882572174072e-01
    z[7,4,5]  R1842     7.1017998456954956e-01
    z[7,4,5]  R1843     1.2367139756679535e-01
    z[7,4,5]  R1844     -1.6047137975692749e-01
    z[7,4,5]  R1845     2.0586515963077545e-01
    z[7,4,5]  R1846     5.5116474628448486e-01
    z[7,4,5]  R1847     -0.068540558218956
    z[7,4,5]  R1848     -0.0843089371919632
    z[7,4,5]  R1849     1.7187568545341492e-01
    z[7,4,5]  R1850     -1.1723558604717255e-01
    z[7,4,5]  R1851     7.7866941690444946e-01
    z[7,4,5]  R1852     6.6610980033874512e-01
    z[7,4,5]  R1853     -3.2666981220245361e-01
    z[7,4,5]  R1854     -3.5131010413169861e-01
    z[7,4,5]  R1855     1.1444703489542007e-01
    z[7,4,5]  R1856     -6.0068786144256592e-02
    z[7,4,5]  R1857     -1.2698693573474884e-01
    z[7,4,5]  R1858     -1.7714734375476837e-01
    z[7,4,5]  R1859     -2.4065764620900154e-02
    z[7,4,5]  R1860     -1.6155165433883667e-01
    z[7,4,5]  R1861     7.4525499343872070e-01
    z[7,4,5]  R1862     3.1178635358810425e-01
    z[7,4,5]  R1863     -1.3313570991158485e-02
    z[7,4,5]  R1864     -8.8597349822521210e-02
    z[7,4,5]  R1865     -1.8960566818714142e-01
    z[7,4,5]  R1866     -1.9285212457180023e-01
    z[7,4,5]  R1867     -1.8472701311111450e-01
    z[7,4,5]  R1868     5.1409624516963959e-02
    z[7,4,5]  R1869     1.2477570027112961e-01
    z[7,4,5]  R1870     7.4614512920379639e-01
    z[7,4,5]  R1871     6.0330617427825928e-01
    z[7,4,5]  R1872     6.8889522552490234e-01
    z[7,4,5]  R1873     7.2982782125473022e-01
    z[7,4,5]  R1874     4.0736641734838486e-02
    z[7,4,5]  R1875     3.1953501701354980e-01
    z[7,4,5]  R1876     5.8904135227203369e-01
    z[7,4,5]  R1877     7.8732502460479736e-01
    z[7,4,5]  R1878     7.2251111268997192e-01
    z[7,4,5]  R1879     -2.6467683911323547e-01
    z[7,4,5]  R1880     -3.2396441698074341e-01
    z[7,4,5]  R1881     -2.3210351169109344e-01
    z[7,4,5]  R1882     -2.4184677004814148e-01
    z[7,4,5]  R1883     -2.1703690290451050e-02
    z[7,4,5]  R1884     2.0627363026142120e-01
    z[7,4,5]  R1885     -2.4471905827522278e-01
    z[7,4,5]  R1886     -2.8761044144630432e-01
    z[7,4,5]  R1887     2.5541490316390991e-01
    z[7,4,5]  R1888     -2.9075062274932861e-01
    z[7,4,5]  R1889     -1.3820463418960571e-01
    z[7,4,5]  R1890     -3.2267281413078308e-01
    z[7,4,5]  R1891     -2.8438609838485718e-01
    z[7,4,5]  R1892     4.0883723646402359e-02
    z[7,4,5]  R1893     0.81397944688797
    z[7,4,5]  R1894     4.2648872733116150e-01
    z[7,4,5]  R1895     8.2856327295303345e-02
    z[7,4,6]  R44       1
    z[7,4,6]  R71       -1
    z[7,4,6]  R1789     -1
    z[7,4,6]  R1790     1
    z[7,4,6]  R1791     -3.6366802453994751e-01
    z[7,4,6]  R1792     6.7211896181106567e-02
    z[7,4,6]  R1793     1.0299152135848999e-01
    z[7,4,6]  R1794     2.5076711177825928e-01
    z[7,4,6]  R1795     1.7573399841785431e-01
    z[7,4,6]  R1796     -1.8029412627220154e-01
    z[7,4,6]  R1797     1.7178039252758026e-01
    z[7,4,6]  R1798     0.165541410446167
    z[7,4,6]  R1799     -4.0061435103416443e-01
    z[7,4,6]  R1800     -2.2367390990257263e-01
    z[7,4,6]  R1801     -0.330437034368515
    z[7,4,6]  R1802     -0.226243257522583
    z[7,4,6]  R1803     -0.0281552542001009
    z[7,4,6]  R1804     4.6129834651947021e-01
    z[7,4,6]  R1805     9.8311454057693481e-02
    z[7,4,6]  R1806     1.8066602945327759e-01
    z[7,4,6]  R1807     2.7286899089813232e-01
    z[7,4,6]  R1808     -5.1402223110198975e-01
    z[7,4,6]  R1809     -3.6391206085681915e-03
    z[7,4,6]  R1810     -4.3184596300125122e-01
    z[7,4,6]  R1811     -3.0547572299838066e-02
    z[7,4,6]  R1812     2.7921709418296814e-01
    z[7,4,6]  R1813     -1.1102665215730667e-01
    z[7,4,6]  R1814     -3.9580602198839188e-02
    z[7,4,6]  R1815     2.2164296358823776e-02
    z[7,4,6]  R1816     -2.5061666965484619e-01
    z[7,4,6]  R1817     2.1673756837844849e-01
    z[7,4,6]  R1818     7.0413582026958466e-02
    z[7,4,6]  R1819     2.4492797255516052e-01
    z[7,4,6]  R1820     4.5410472154617310e-01
    z[7,4,6]  R1821     -5.8907425403594971e-01
    z[7,4,6]  R1822     9.8338752985000610e-02
    z[7,4,6]  R1823     -1.3167785108089447e-01
    z[7,4,6]  R1824     3.8783612847328186e-01
    z[7,4,6]  R1825     7.5318306684494019e-01
    z[7,4,6]  R1826     4.1969934105873108e-01
    z[7,4,6]  R1827     5.3025788068771362e-01
    z[7,4,6]  R1828     -5.0580805540084839e-01
    z[7,4,6]  R1829     -0.331859827041626
    z[7,4,6]  R1830     -5.8802329003810883e-02
    z[7,4,6]  R1831     2.2911757230758667e-02
    z[7,4,6]  R1832     2.7257823944091797e-01
    z[7,4,6]  R1833     3.5895255208015442e-01
    z[7,4,6]  R1834     -0.0967012494802475
    z[7,4,6]  R1835     -5.7264614105224609e-01
    z[7,4,6]  R1836     4.1925567388534546e-01
    z[7,4,6]  R1837     0.0626790001988411
    z[7,4,6]  R1838     3.5951954126358032e-01
    z[7,4,6]  R1839     -2.6943216100335121e-02
    z[7,4,6]  R1840     6.1659656465053558e-02
    z[7,4,6]  R1841     -5.6406247615814209e-01
    z[7,4,6]  R1842     2.7087292075157166e-01
    z[7,4,6]  R1843     1.2039686739444733e-01
    z[7,4,6]  R1844     -5.1999503374099731e-01
    z[7,4,6]  R1845     4.2394686490297318e-02
    z[7,4,6]  R1846     -7.0953494310379028e-01
    z[7,4,6]  R1847     -1.5739767253398895e-01
    z[7,4,6]  R1848     -5.2332168817520142e-01
    z[7,4,6]  R1849     1.5810205042362213e-01
    z[7,4,6]  R1850     -4.7031126916408539e-02
    z[7,4,6]  R1851     -1.8030360341072083e-01
    z[7,4,6]  R1852     -7.2309148311614990e-01
    z[7,4,6]  R1853     3.3120226860046387e-01
    z[7,4,6]  R1854     4.0426653623580933e-01
    z[7,4,6]  R1855     4.0536105632781982e-01
    z[7,4,6]  R1856     -3.6374846100807190e-01
    z[7,4,6]  R1857     -1.3886626809835434e-02
    z[7,4,6]  R1858     -1.3277682662010193e-01
    z[7,4,6]  R1859     0.0638522282242775
    z[7,4,6]  R1860     1.0440131276845932e-01
    z[7,4,6]  R1861     0.191190704703331
    z[7,4,6]  R1862     4.4415897130966187e-01
    z[7,4,6]  R1863     3.3849492669105530e-02
    z[7,4,6]  R1864     -1.6048131883144379e-01
    z[7,4,6]  R1865     2.4727353453636169e-01
    z[7,4,6]  R1866     -1.9234076142311096e-02
    z[7,4,6]  R1867     8.0929987132549286e-02
    z[7,4,6]  R1868     1.6371706128120422e-01
    z[7,4,6]  R1869     2.5133961439132690e-01
    z[7,4,6]  R1870     2.5733998045325279e-02
    z[7,4,6]  R1871     -7.4962019920349121e-02
    z[7,4,6]  R1872     -2.9850602149963379e-01
    z[7,4,6]  R1873     -5.4284799098968506e-01
    z[7,4,6]  R1874     -6.1835199594497681e-01
    z[7,4,6]  R1875     2.3508971929550171e-01
    z[7,4,6]  R1876     -3.7726196646690369e-01
    z[7,4,6]  R1877     3.1346493959426880e-01
    z[7,4,6]  R1878     0.337494820356369
    z[7,4,6]  R1879     -1.6473412513732910e-01
    z[7,4,6]  R1880     1.6942480206489563e-01
    z[7,4,6]  R1881     2.9440093040466309e-01
    z[7,4,6]  R1882     5.0955861806869507e-01
    z[7,4,6]  R1883     -5.4874587804079056e-03
    z[7,4,6]  R1884     -3.4751974046230316e-02
    z[7,4,6]  R1885     -4.3802503496408463e-02
    z[7,4,6]  R1886     3.5226356238126755e-02
    z[7,4,6]  R1887     1.6212120652198792e-02
    z[7,4,6]  R1888     -3.4154140949249268e-01
    z[7,4,6]  R1889     2.5265011191368103e-01
    z[7,4,6]  R1890     5.4128278046846390e-02
    z[7,4,6]  R1891     -5.7553578168153763e-02
    z[7,4,6]  R1892     -3.8404011726379395e-01
    z[7,4,6]  R1893     2.1300770342350006e-02
    z[7,4,6]  R1894     8.4735400974750519e-02
    z[7,4,6]  R1895     1.5273508429527283e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1937     -1
    z[5,6,0]  R1938     1
    z[5,6,0]  R1951     -5.7996219396591187e-01
    z[5,6,0]  R1952     -7.9358226060867310e-01
    z[5,6,0]  R1953     -0.518456757068634
    z[5,6,0]  R1954     -6.3096517324447632e-01
    z[5,6,0]  R1955     -3.6290261149406433e-01
    z[5,6,0]  R1956     -5.1928228139877319e-01
    z[5,6,0]  R1957     -2.2811952233314514e-01
    z[5,6,0]  R1958     4.1172024607658386e-01
    z[5,6,0]  R1959     5.6369763612747192e-01
    z[5,6,0]  R1960     6.7790520191192627e-01
    z[5,6,0]  R1961     2.5977733731269836e-01
    z[5,6,0]  R1962     3.2061547040939331e-01
    z[5,6,0]  R1963     1.3840182125568390e-01
    z[5,6,0]  R1964     -3.0481213331222534e-01
    z[5,6,0]  R1965     -5.0336980819702148e-01
    z[5,6,0]  R1966     -1.9695284962654114e-01
    z[5,6,0]  R1967     -1.1693647503852844e-01
    z[5,6,0]  R1968     5.1186162233352661e-01
    z[5,6,0]  R1969     6.1486173421144485e-02
    z[5,6,0]  R1970     0.04227314889431
    z[5,6,0]  R1971     -3.9250290393829346e-01
    z[5,6,0]  R1972     2.1174551546573639e-01
    z[5,6,0]  R1973     -7.1806021034717560e-02
    z[5,6,0]  R1974     -3.5093218088150024e-02
    z[5,6,0]  R1975     3.3915615081787109e-01
    z[5,6,0]  R1976     -1.1973375082015991e-01
    z[5,6,0]  R1977     -3.8449484109878540e-01
    z[5,6,0]  R1978     -1.7956182360649109e-01
    z[5,6,0]  R1979     -0.182621568441391
    z[5,6,0]  R1980     1.0773085057735443e-01
    z[5,6,0]  R1981     -0.0769742876291275
    z[5,6,0]  R1982     3.2144537568092346e-01
    z[5,6,0]  R1983     1.9060429930686951e-01
    z[5,6,0]  R1984     2.5585165619850159e-01
    z[5,6,0]  R1985     -2.3111756891012192e-02
    z[5,6,0]  R1986     3.3616542816162109e-01
    z[5,6,0]  R1987     2.4032276868820190e-01
    z[5,6,0]  R1988     -8.9384570717811584e-02
    z[5,6,0]  R1989     -2.1971440315246582e-01
    z[5,6,0]  R1990     -2.1087791025638580e-01
    z[5,6,0]  R1991     -9.0638458728790283e-01
    z[5,6,0]  R1992     -8.2799595594406128e-01
    z[5,6,0]  R1993     -7.8493207693099976e-01
    z[5,6,0]  R1994     -7.0772647857666016e-01
    z[5,6,0]  R1995     -0.819678008556366
    z[5,6,0]  R1996     -6.6300272941589355e-01
    z[5,6,0]  R1997     -8.1264919042587280e-01
    z[5,6,0]  R1998     -6.8940824270248413e-01
    z[5,6,0]  R1999     -8.8037103414535522e-01
    z[5,6,0]  R2000     2.9375693202018738e-01
    z[5,6,0]  R2001     -3.8623297587037086e-04
    z[5,6,0]  R2002     4.9018543958663940e-01
    z[5,6,0]  R2003     4.9586838483810425e-01
    z[5,6,0]  R2004     4.3103596568107605e-01
    z[5,6,0]  R2005     2.0347057282924652e-01
    z[5,6,0]  R2006     3.9923486113548279e-01
    z[5,6,0]  R2007     0.421084463596344
    z[5,6,0]  R2008     2.6942405104637146e-01
    z[5,6,0]  R2009     3.8349777460098267e-01
    z[5,6,0]  R2010     3.8672599196434021e-01
    z[5,6,0]  R2011     0.599850058555603
    z[5,6,0]  R2012     3.9805805683135986e-01
    z[5,6,0]  R2013     9.7217820584774017e-02
    z[5,6,0]  R2014     3.7836232781410217e-01
    z[5,6,0]  R2015     2.1848320960998535e-01
    z[5,6,0]  R2016     4.0968227386474609e-01
    z[5,6,0]  R2017     5.7834142446517944e-01
    z[5,6,0]  R2018     -4.1519635915756226e-01
    z[5,6,0]  R2019     -2.0829349756240845e-01
    z[5,6,0]  R2020     1.6713143885135651e-01
    z[5,6,0]  R2021     0.291344553232193
    z[5,6,0]  R2022     2.0175081491470337e-01
    z[5,6,0]  R2023     -1.8293541669845581e-01
    z[5,6,0]  R2024     -1.5737058222293854e-01
    z[5,6,0]  R2025     -7.6309749856591225e-03
    z[5,6,0]  R2026     -3.4955191612243652e-01
    z[5,6,0]  R2027     -4.1043874621391296e-01
    z[5,6,0]  R2028     1.1732964962720871e-01
    z[5,6,0]  R2029     -4.1289508342742920e-01
    z[5,6,0]  R2030     6.7198120057582855e-02
    z[5,6,0]  R2031     1.4178267121315002e-01
    z[5,6,0]  R2032     -3.6966481804847717e-01
    z[5,6,0]  R2033     4.9518829584121704e-01
    z[5,6,0]  R2034     -2.0473115146160126e-01
    z[5,6,0]  R2035     -8.2797199487686157e-01
    z[5,6,0]  R2036     0.617081344127655
    z[5,6,0]  R2037     5.0851190090179443e-01
    z[5,6,0]  R2038     3.9375400543212891e-01
    z[5,6,0]  R2039     0.809958279132843
    z[5,6,0]  R2040     8.5605132579803467e-01
    z[5,6,0]  R2041     -2.9784919694066048e-02
    z[5,6,0]  R2042     -0.286978155374527
    z[5,6,0]  R2043     1.6640554368495941e-01
    z[5,6,0]  R2044     7.2376525402069092e-01
    z[5,6,0]  R2045     -1.7412005364894867e-01
    z[5,6,0]  R2046     8.0571383237838745e-02
    z[5,6,0]  R2047     8.3700728416442871e-01
    z[5,6,0]  R2048     1.3343612849712372e-01
    z[5,6,0]  R2049     -6.4536012709140778e-02
    z[5,6,0]  R2050     4.4132387638092041e-01
    z[5,6,0]  R2051     6.9306713342666626e-01
    z[5,6,0]  R2052     -2.6543736457824707e-01
    z[5,6,0]  R2053     4.8704367876052856e-01
    z[5,6,0]  R2054     3.5728746652603149e-01
    z[5,6,0]  R2055     2.4972066283226013e-01
    z[5,6,0]  R2056     2.2820445895195007e-01
    z[5,6,0]  R2057     4.4021755456924438e-01
    z[5,6,0]  R2058     8.7229609489440918e-01
    z[5,6,0]  R2059     1.6437853872776031e-01
    z[5,6,0]  R2060     4.1851267218589783e-01
    z[5,6,0]  R2061     -9.3097686767578125e-02
    z[5,6,0]  R2062     0.0915379747748375
    z[5,6,0]  R2063     -0.0588078498840332
    z[5,6,0]  R2064     4.6570891141891479e-01
    z[5,6,0]  R2065     -3.0314895510673523e-01
    z[5,6,0]  R2066     3.5545620322227478e-01
    z[5,6,0]  R2067     -2.0369479060173035e-01
    z[5,6,0]  R2068     -1.8442565202713013e-01
    z[5,6,0]  R2069     4.4914808869361877e-01
    z[5,6,0]  R2070     5.8731153607368469e-02
    z[5,6,0]  R2071     0.0049970424734056
    z[5,6,0]  R2072     -3.4934845566749573e-01
    z[5,6,0]  R2073     -7.5006228685379028e-01
    z[5,6,0]  R2074     4.0946078300476074e-01
    z[5,6,0]  R2075     -1.1233063042163849e-01
    z[5,6,0]  R2076     7.2808766365051270e-01
    z[5,6,0]  R2077     -2.4780279025435448e-02
    z[5,6,0]  R2078     -3.3136874437332153e-02
    z[5,6,0]  R2079     3.3650982379913330e-01
    z[5,6,0]  R2080     3.7405374646186829e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1939     -1
    z[5,6,1]  R1940     1
    z[5,6,1]  R1951     2.3080082237720490e-01
    z[5,6,1]  R1952     -0.0527375154197216
    z[5,6,1]  R1953     2.0245993137359619e-01
    z[5,6,1]  R1954     2.6000419165939093e-03
    z[5,6,1]  R1955     -2.0599098876118660e-02
    z[5,6,1]  R1956     -5.4028481245040894e-02
    z[5,6,1]  R1957     6.0787373781204224e-01
    z[5,6,1]  R1958     6.5360605716705322e-02
    z[5,6,1]  R1959     2.1668045222759247e-01
    z[5,6,1]  R1960     -1.9635602831840515e-02
    z[5,6,1]  R1961     -7.4423557519912720e-01
    z[5,6,1]  R1962     -7.7088785171508789e-01
    z[5,6,1]  R1963     -6.4877432584762573e-01
    z[5,6,1]  R1964     -6.7080420255661011e-01
    z[5,6,1]  R1965     -0.663345456123352
    z[5,6,1]  R1966     -5.3227263689041138e-01
    z[5,6,1]  R1967     -0.687248170375824
    z[5,6,1]  R1968     -0.569867730140686
    z[5,6,1]  R1969     -0.77773118019104
    z[5,6,1]  R1970     -3.8848367333412170e-01
    z[5,6,1]  R1971     -8.5708284378051758e-01
    z[5,6,1]  R1972     -0.671985387802124
    z[5,6,1]  R1973     -7.8402262926101685e-01
    z[5,6,1]  R1974     -0.723905086517334
    z[5,6,1]  R1975     -5.6439733505249023e-01
    z[5,6,1]  R1976     -0.00883125513792038
    z[5,6,1]  R1977     -0.103699691593647
    z[5,6,1]  R1978     5.3361009806394577e-02
    z[5,6,1]  R1979     5.5084377527236938e-01
    z[5,6,1]  R1980     5.8834302425384521e-01
    z[5,6,1]  R1981     -0.764907956123352
    z[5,6,1]  R1982     -9.2994827032089233e-01
    z[5,6,1]  R1983     -7.1044009923934937e-01
    z[5,6,1]  R1984     -6.4333051443099976e-01
    z[5,6,1]  R1985     2.3180831968784332e-01
    z[5,6,1]  R1986     -6.7275100946426392e-01
    z[5,6,1]  R1987     2.0524153113365173e-01
    z[5,6,1]  R1988     7.5061500072479248e-02
    z[5,6,1]  R1989     4.4072076678276062e-01
    z[5,6,1]  R1990     8.9551174640655518e-01
    z[5,6,1]  R1991     2.3567005991935730e-01
    z[5,6,1]  R1992     -4.1897028684616089e-02
    z[5,6,1]  R1993     2.8792524710297585e-02
    z[5,6,1]  R1994     -1.2074025720357895e-01
    z[5,6,1]  R1995     -8.2762926816940308e-02
    z[5,6,1]  R1996     -1.4048515260219574e-01
    z[5,6,1]  R1997     4.6277213841676712e-02
    z[5,6,1]  R1998     -1.1682908982038498e-01
    z[5,6,1]  R1999     -1.0781950503587723e-01
    z[5,6,1]  R2000     -2.0093406736850739e-01
    z[5,6,1]  R2001     -8.9190477132797241e-01
    z[5,6,1]  R2002     -3.7189406156539917e-01
    z[5,6,1]  R2003     -4.8617777228355408e-01
    z[5,6,1]  R2004     -5.5693954229354858e-01
    z[5,6,1]  R2005     -6.9330793619155884e-01
    z[5,6,1]  R2006     -7.2400510311126709e-01
    z[5,6,1]  R2007     8.9146637916564941e-01
    z[5,6,1]  R2008     9.2655897140502930e-01
    z[5,6,1]  R2009     8.8261890411376953e-01
    z[5,6,1]  R2010     0.881799578666687
    z[5,6,1]  R2011     -5.0700485706329346e-01
    z[5,6,1]  R2012     -7.7167344093322754e-01
    z[5,6,1]  R2013     -8.0269873142242432e-01
    z[5,6,1]  R2014     -3.3003348112106323e-01
    z[5,6,1]  R2015     -3.3140763640403748e-01
    z[5,6,1]  R2016     -7.5931972265243530e-01
    z[5,6,1]  R2017     -1.2345468252897263e-01
    z[5,6,1]  R2018     -7.6918292045593262e-01
    z[5,6,1]  R2019     -0.752150297164917
    z[5,6,1]  R2020     -7.9434764385223389e-01
    z[5,6,1]  R2021     -9.1375911235809326e-01
    z[5,6,1]  R2022     -7.7818918228149414e-01
    z[5,6,1]  R2023     -9.4941031932830811e-01
    z[5,6,1]  R2024     -9.4771158695220947e-01
    z[5,6,1]  R2025     -6.0370171070098877e-01
    z[5,6,1]  R2026     -8.1486070156097412e-01
    z[5,6,1]  R2027     -7.2885221242904663e-01
    z[5,6,1]  R2028     -6.8084597587585449e-01
    z[5,6,1]  R2029     -7.7136713266372681e-01
    z[5,6,1]  R2030     -7.2400116920471191e-01
    z[5,6,1]  R2031     -0.770193874835968
    z[5,6,1]  R2032     -8.5195004940032959e-01
    z[5,6,1]  R2033     4.2647279798984528e-02
    z[5,6,1]  R2034     -8.0612915754318237e-01
    z[5,6,1]  R2035     -3.8849323987960815e-01
    z[5,6,1]  R2036     -3.4533193707466125e-01
    z[5,6,1]  R2037     -5.2539217472076416e-01
    z[5,6,1]  R2038     -3.1653749942779541e-01
    z[5,6,1]  R2039     -3.4983004443347454e-03
    z[5,6,1]  R2040     0.0690355971455574
    z[5,6,1]  R2041     -8.1956321001052856e-01
    z[5,6,1]  R2042     -5.9959208965301514e-01
    z[5,6,1]  R2043     -7.6063059270381927e-02
    z[5,6,1]  R2044     -2.0901305973529816e-01
    z[5,6,1]  R2045     -4.9557766318321228e-01
    z[5,6,1]  R2046     -5.0943940877914429e-01
    z[5,6,1]  R2047     -2.6115508750081062e-02
    z[5,6,1]  R2048     7.8820818662643433e-01
    z[5,6,1]  R2049     9.4797450304031372e-01
    z[5,6,1]  R2050     5.7311809062957764e-01
    z[5,6,1]  R2051     -9.0785082429647446e-03
    z[5,6,1]  R2052     -5.7964098453521729e-01
    z[5,6,1]  R2053     -4.8482900857925415e-01
    z[5,6,1]  R2054     -1.7932601273059845e-01
    z[5,6,1]  R2055     -3.6394849419593811e-01
    z[5,6,1]  R2056     -0.682121753692627
    z[5,6,1]  R2057     -7.4453867971897125e-02
    z[5,6,1]  R2058     6.0457970947027206e-02
    z[5,6,1]  R2059     -0.321254700422287
    z[5,6,1]  R2060     -1.4761339128017426e-01
    z[5,6,1]  R2061     -7.9079437255859375e-01
    z[5,6,1]  R2062     -8.0034458637237549e-01
    z[5,6,1]  R2063     -8.2423675060272217e-01
    z[5,6,1]  R2064     -5.2353560924530029e-02
    z[5,6,1]  R2065     -5.6139910221099854e-01
    z[5,6,1]  R2066     -1.7574384808540344e-01
    z[5,6,1]  R2067     -4.8669952154159546e-01
    z[5,6,1]  R2068     0.811751663684845
    z[5,6,1]  R2069     0.639335036277771
    z[5,6,1]  R2070     7.7055817842483521e-01
    z[5,6,1]  R2071     -9.2000114917755127e-01
    z[5,6,1]  R2072     -8.1789934635162354e-01
    z[5,6,1]  R2073     -5.2259933948516846e-01
    z[5,6,1]  R2074     -0.166182741522789
    z[5,6,1]  R2075     -0.468726247549057
    z[5,6,1]  R2076     -1.8806332349777222e-01
    z[5,6,1]  R2077     8.7126356363296509e-01
    z[5,6,1]  R2078     4.3835404515266418e-01
    z[5,6,1]  R2079     7.1538448333740234e-01
    z[5,6,1]  R2080     5.4896432161331177e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1941     -1
    z[5,6,2]  R1942     1
    z[5,6,2]  R1951     4.1230174899101257e-01
    z[5,6,2]  R1952     3.5707753896713257e-01
    z[5,6,2]  R1953     8.0414557456970215e-01
    z[5,6,2]  R1954     6.6721254587173462e-01
    z[5,6,2]  R1955     6.7652350664138794e-01
    z[5,6,2]  R1956     2.7625033259391785e-01
    z[5,6,2]  R1957     1.0251188278198242e-01
    z[5,6,2]  R1958     -1.7896650359034538e-02
    z[5,6,2]  R1959     -2.8267744928598404e-03
    z[5,6,2]  R1960     5.4159498214721680e-01
    z[5,6,2]  R1961     1.3479290902614594e-01
    z[5,6,2]  R1962     2.1449199318885803e-01
    z[5,6,2]  R1963     1.9075600802898407e-01
    z[5,6,2]  R1964     -9.1220803558826447e-02
    z[5,6,2]  R1965     -7.3211520910263062e-02
    z[5,6,2]  R1966     2.7145119383931160e-02
    z[5,6,2]  R1967     -3.1677749752998352e-01
    z[5,6,2]  R1968     3.5254955291748047e-01
    z[5,6,2]  R1969     -5.6832976639270782e-02
    z[5,6,2]  R1970     9.8804473876953125e-02
    z[5,6,2]  R1971     -2.0342530310153961e-01
    z[5,6,2]  R1972     2.1533285081386566e-01
    z[5,6,2]  R1973     -1.9392953813076019e-01
    z[5,6,2]  R1974     -3.7211760878562927e-01
    z[5,6,2]  R1975     3.8335654139518738e-01
    z[5,6,2]  R1976     -2.6121586561203003e-01
    z[5,6,2]  R1977     -4.1250422596931458e-01
    z[5,6,2]  R1978     -4.9788277596235275e-02
    z[5,6,2]  R1979     1.2829124927520752e-01
    z[5,6,2]  R1980     2.3098066449165344e-01
    z[5,6,2]  R1981     3.1553870439529419e-01
    z[5,6,2]  R1982     0.0686025395989418
    z[5,6,2]  R1983     -4.4498926401138306e-01
    z[5,6,2]  R1984     -4.5791637897491455e-01
    z[5,6,2]  R1985     1.6195403039455414e-01
    z[5,6,2]  R1986     -2.5885558128356934e-01
    z[5,6,2]  R1987     2.4468574672937393e-02
    z[5,6,2]  R1988     3.8558891415596008e-01
    z[5,6,2]  R1989     -1.9540810957551003e-02
    z[5,6,2]  R1990     -5.6084785610437393e-02
    z[5,6,2]  R1991     4.8219002783298492e-02
    z[5,6,2]  R1992     2.4617350101470947e-01
    z[5,6,2]  R1993     0.0839306190609932
    z[5,6,2]  R1994     2.1931204199790955e-01
    z[5,6,2]  R1995     -1.4509050548076630e-01
    z[5,6,2]  R1996     -1.1842354387044907e-01
    z[5,6,2]  R1997     -3.0637830495834351e-01
    z[5,6,2]  R1998     -2.6090177893638611e-01
    z[5,6,2]  R1999     -1.3556927442550659e-01
    z[5,6,2]  R2000     -1.7798444628715515e-01
    z[5,6,2]  R2001     -5.5900290608406067e-02
    z[5,6,2]  R2002     -2.9828870296478271e-01
    z[5,6,2]  R2003     -1.3427162542939186e-02
    z[5,6,2]  R2004     4.1312953829765320e-01
    z[5,6,2]  R2005     -3.4522205591201782e-01
    z[5,6,2]  R2006     0.289383202791214
    z[5,6,2]  R2007     1.4852622523903847e-02
    z[5,6,2]  R2008     2.1137434244155884e-01
    z[5,6,2]  R2009     6.5856881439685822e-02
    z[5,6,2]  R2010     2.1253588795661926e-01
    z[5,6,2]  R2011     1.0035727173089981e-01
    z[5,6,2]  R2012     1.6829672455787659e-01
    z[5,6,2]  R2013     -1.9416575133800507e-01
    z[5,6,2]  R2014     -1.8333847820758820e-01
    z[5,6,2]  R2015     -5.2161026000976562e-01
    z[5,6,2]  R2016     3.4443494677543640e-01
    z[5,6,2]  R2017     2.2141848504543304e-01
    z[5,6,2]  R2018     1.4933940954506397e-02
    z[5,6,2]  R2019     -1.5962953865528107e-01
    z[5,6,2]  R2020     3.8431543856859207e-02
    z[5,6,2]  R2021     0.095056913793087
    z[5,6,2]  R2022     -9.1186009347438812e-02
    z[5,6,2]  R2023     2.2850561141967773e-01
    z[5,6,2]  R2024     1.8350470066070557e-01
    z[5,6,2]  R2025     -1.0992185026407242e-01
    z[5,6,2]  R2026     -6.4968854188919067e-02
    z[5,6,2]  R2027     1.5266297757625580e-01
    z[5,6,2]  R2028     0.0628947913646698
    z[5,6,2]  R2029     -1.3236106932163239e-01
    z[5,6,2]  R2030     1.4494094066321850e-02
    z[5,6,2]  R2031     2.4858203530311584e-01
    z[5,6,2]  R2032     -9.9425628781318665e-02
    z[5,6,2]  R2033     -4.5960783958435059e-01
    z[5,6,2]  R2034     -1.3062451779842377e-01
    z[5,6,2]  R2035     2.0609753206372261e-02
    z[5,6,2]  R2036     -1.2111578881740570e-01
    z[5,6,2]  R2037     -5.5107390880584717e-01
    z[5,6,2]  R2038     -6.5184015035629272e-01
    z[5,6,2]  R2039     1.5165668725967407e-01
    z[5,6,2]  R2040     9.4467557966709137e-02
    z[5,6,2]  R2041     3.7212669849395752e-01
    z[5,6,2]  R2042     0.510319173336029
    z[5,6,2]  R2043     -7.9994976520538330e-01
    z[5,6,2]  R2044     -2.0820085704326630e-01
    z[5,6,2]  R2045     -2.5144013762474060e-01
    z[5,6,2]  R2046     -4.7872957587242126e-01
    z[5,6,2]  R2047     3.4862619638442993e-01
    z[5,6,2]  R2048     -4.0366011857986450e-01
    z[5,6,2]  R2049     -1.7312115430831909e-01
    z[5,6,2]  R2050     -3.5301384329795837e-01
    z[5,6,2]  R2051     -3.4765001386404037e-02
    z[5,6,2]  R2052     4.2130580544471741e-01
    z[5,6,2]  R2053     -5.7477647066116333e-01
    z[5,6,2]  R2054     -0.645080029964447
    z[5,6,2]  R2055     -5.4246175289154053e-01
    z[5,6,2]  R2056     -1.1096552014350891e-01
    z[5,6,2]  R2057     -2.7713960409164429e-01
    z[5,6,2]  R2058     1.6731685400009155e-01
    z[5,6,2]  R2059     -5.4264806210994720e-02
    z[5,6,2]  R2060     -2.9492408037185669e-01
    z[5,6,2]  R2061     -5.9931054711341858e-02
    z[5,6,2]  R2062     5.0907637923955917e-02
    z[5,6,2]  R2063     -5.9057138860225677e-02
    z[5,6,2]  R2064     1.0383627563714981e-01
    z[5,6,2]  R2065     -4.1855287551879883e-01
    z[5,6,2]  R2066     -2.0485353469848633e-01
    z[5,6,2]  R2067     1.7963831126689911e-01
    z[5,6,2]  R2068     -3.7469189614057541e-02
    z[5,6,2]  R2069     -2.6761874556541443e-01
    z[5,6,2]  R2070     -3.3364719152450562e-01
    z[5,6,2]  R2071     3.4020170569419861e-02
    z[5,6,2]  R2072     1.9581666216254234e-02
    z[5,6,2]  R2073     2.5441735982894897e-02
    z[5,6,2]  R2074     -0.199344664812088
    z[5,6,2]  R2075     4.2731454968452454e-01
    z[5,6,2]  R2076     2.1485167741775513e-01
    z[5,6,2]  R2077     -3.7014293670654297e-01
    z[5,6,2]  R2078     3.8449708372354507e-02
    z[5,6,2]  R2079     -2.8615200892090797e-02
    z[5,6,2]  R2080     -3.9972978830337524e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1943     -1
    z[5,6,3]  R1944     1
    z[5,6,3]  R1951     5.7542663812637329e-01
    z[5,6,3]  R1952     4.0845578908920288e-01
    z[5,6,3]  R1953     1.5528170764446259e-01
    z[5,6,3]  R1954     1.2737837433815002e-01
    z[5,6,3]  R1955     3.0088528990745544e-01
    z[5,6,3]  R1956     4.5655813813209534e-01
    z[5,6,3]  R1957     -4.9563857913017273e-01
    z[5,6,3]  R1958     -3.1470906734466553e-01
    z[5,6,3]  R1959     1.1076045036315918e-01
    z[5,6,3]  R1960     -3.1615990400314331e-01
    z[5,6,3]  R1961     2.7734089642763138e-02
    z[5,6,3]  R1962     -3.6465135216712952e-01
    z[5,6,3]  R1963     -1.1362092941999435e-01
    z[5,6,3]  R1964     -2.0058588683605194e-01
    z[5,6,3]  R1965     -2.3111377656459808e-01
    z[5,6,3]  R1966     -1.4693267643451691e-01
    z[5,6,3]  R1967     3.1360420584678650e-01
    z[5,6,3]  R1968     -1.1760506778955460e-01
    z[5,6,3]  R1969     3.6228078603744507e-01
    z[5,6,3]  R1970     -3.5031415522098541e-02
    z[5,6,3]  R1971     -3.0206680297851562e-02
    z[5,6,3]  R1972     2.3643206059932709e-01
    z[5,6,3]  R1973     2.0475223660469055e-02
    z[5,6,3]  R1974     3.4598565101623535e-01
    z[5,6,3]  R1975     -1.1399001628160477e-01
    z[5,6,3]  R1976     -5.4585546255111694e-01
    z[5,6,3]  R1977     -5.9481322765350342e-01
    z[5,6,3]  R1978     -5.2916777133941650e-01
    z[5,6,3]  R1979     -3.3844679594039917e-01
    z[5,6,3]  R1980     -4.7032311558723450e-01
    z[5,6,3]  R1981     2.7833151817321777e-01
    z[5,6,3]  R1982     6.9129839539527893e-03
    z[5,6,3]  R1983     -2.2999511659145355e-01
    z[5,6,3]  R1984     -5.7330571115016937e-02
    z[5,6,3]  R1985     -5.9929913282394409e-01
    z[5,6,3]  R1986     -2.2839865088462830e-01
    z[5,6,3]  R1987     -6.1922895908355713e-01
    z[5,6,3]  R1988     -0.387405127286911
    z[5,6,3]  R1989     -5.4892927408218384e-01
    z[5,6,3]  R1990     -1.1917480081319809e-01
    z[5,6,3]  R1991     -3.3907768130302429e-01
    z[5,6,3]  R1992     -2.9924616217613220e-01
    z[5,6,3]  R1993     -3.3888214826583862e-01
    z[5,6,3]  R1994     -5.9020549058914185e-01
    z[5,6,3]  R1995     -2.7884083986282349e-01
    z[5,6,3]  R1996     -5.5373167991638184e-01
    z[5,6,3]  R1997     -1.9600987434387207e-01
    z[5,6,3]  R1998     -3.7111577391624451e-01
    z[5,6,3]  R1999     2.6010829210281372e-01
    z[5,6,3]  R2000     8.1559962034225464e-01
    z[5,6,3]  R2001     1.2610229849815369e-01
    z[5,6,3]  R2002     9.3165948987007141e-02
    z[5,6,3]  R2003     -4.9079051613807678e-01
    z[5,6,3]  R2004     -4.9664461612701416e-01
    z[5,6,3]  R2005     3.9586505293846130e-01
    z[5,6,3]  R2006     2.1753889322280884e-01
    z[5,6,3]  R2007     -5.1467999815940857e-02
    z[5,6,3]  R2008     1.1947729438543320e-01
    z[5,6,3]  R2009     1.1300613731145859e-01
    z[5,6,3]  R2010     -3.8399152457714081e-02
    z[5,6,3]  R2011     3.9864072203636169e-01
    z[5,6,3]  R2012     -0.0781896784901619
    z[5,6,3]  R2013     5.0997996330261230e-01
    z[5,6,3]  R2014     -0.0290201585739851
    z[5,6,3]  R2015     3.3412650227546692e-02
    z[5,6,3]  R2016     6.9710515439510345e-02
    z[5,6,3]  R2017     3.3124664425849915e-01
    z[5,6,3]  R2018     9.6823759377002716e-02
    z[5,6,3]  R2019     2.7094164490699768e-01
    z[5,6,3]  R2020     1.2503567337989807e-01
    z[5,6,3]  R2021     1.2436323612928391e-01
    z[5,6,3]  R2022     -2.3279446363449097e-01
    z[5,6,3]  R2023     -5.4520197212696075e-02
    z[5,6,3]  R2024     -1.1272186040878296e-01
    z[5,6,3]  R2025     -3.9822015166282654e-01
    z[5,6,3]  R2026     1.9771383702754974e-01
    z[5,6,3]  R2027     -3.5733717679977417e-01
    z[5,6,3]  R2028     9.8374977707862854e-02
    z[5,6,3]  R2029     4.0437778830528259e-01
    z[5,6,3]  R2030     3.5644698143005371e-01
    z[5,6,3]  R2031     -3.9706024527549744e-01
    z[5,6,3]  R2032     2.9846101999282837e-01
    z[5,6,3]  R2033     2.7269285917282104e-01
    z[5,6,3]  R2034     1.0264895856380463e-01
    z[5,6,3]  R2035     2.5535422563552856e-01
    z[5,6,3]  R2036     4.0238106250762939e-01
    z[5,6,3]  R2037     -8.0770663917064667e-03
    z[5,6,3]  R2038     7.5806421227753162e-03
    z[5,6,3]  R2039     -1.4889647066593170e-01
    z[5,6,3]  R2040     1.0548835247755051e-01
    z[5,6,3]  R2041     -1.6698397696018219e-02
    z[5,6,3]  R2042     -3.6903306841850281e-01
    z[5,6,3]  R2043     3.1129187345504761e-01
    z[5,6,3]  R2044     2.8346312046051025e-01
    z[5,6,3]  R2045     7.2360301017761230e-01
    z[5,6,3]  R2046     4.1686362028121948e-01
    z[5,6,3]  R2047     1.5570640563964844e-01
    z[5,6,3]  R2048     1.2262795865535736e-01
    z[5,6,3]  R2049     -1.3377287983894348e-01
    z[5,6,3]  R2050     1.1306324601173401e-01
    z[5,6,3]  R2051     5.3718948364257812e-01
    z[5,6,3]  R2052     -0.571797788143158
    z[5,6,3]  R2053     2.1838736534118652e-01
    z[5,6,3]  R2054     3.0689904093742371e-01
    z[5,6,3]  R2055     6.3965070247650146e-01
    z[5,6,3]  R2056     5.1850110292434692e-01
    z[5,6,3]  R2057     5.0610125064849854e-01
    z[5,6,3]  R2058     2.2512586414813995e-01
    z[5,6,3]  R2059     5.3207403421401978e-01
    z[5,6,3]  R2060     6.9865804910659790e-01
    z[5,6,3]  R2061     -2.8843320906162262e-02
    z[5,6,3]  R2062     4.2975005507469177e-01
    z[5,6,3]  R2063     3.2536211609840393e-01
    z[5,6,3]  R2064     5.2024662494659424e-01
    z[5,6,3]  R2065     -1.0241288691759109e-01
    z[5,6,3]  R2066     0.801220178604126
    z[5,6,3]  R2067     4.1895386576652527e-01
    z[5,6,3]  R2068     2.0774005353450775e-01
    z[5,6,3]  R2069     2.7850806713104248e-01
    z[5,6,3]  R2070     -1.0500277578830719e-01
    z[5,6,3]  R2071     -3.9494130760431290e-02
    z[5,6,3]  R2072     -2.1544608473777771e-01
    z[5,6,3]  R2073     -7.8749559819698334e-02
    z[5,6,3]  R2074     8.2119709253311157e-01
    z[5,6,3]  R2075     -5.1762568950653076e-01
    z[5,6,3]  R2076     1.3576522469520569e-01
    z[5,6,3]  R2077     0.0986611545085907
    z[5,6,3]  R2078     7.8905093669891357e-01
    z[5,6,3]  R2079     -2.1489325165748596e-01
    z[5,6,3]  R2080     -4.4135209918022156e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1945     -1
    z[5,6,4]  R1946     1
    z[5,6,4]  R1951     2.3986333608627319e-01
    z[5,6,4]  R1952     -1.1049579083919525e-01
    z[5,6,4]  R1953     1.5271799638867378e-02
    z[5,6,4]  R1954     -2.7204152941703796e-01
    z[5,6,4]  R1955     1.8960656225681305e-01
    z[5,6,4]  R1956     2.0966078341007233e-01
    z[5,6,4]  R1957     -4.7962281107902527e-01
    z[5,6,4]  R1958     -1.6468434035778046e-01
    z[5,6,4]  R1959     7.1353238821029663e-01
    z[5,6,4]  R1960     3.5656622052192688e-01
    z[5,6,4]  R1961     2.0278191193938255e-02
    z[5,6,4]  R1962     -2.1379841864109039e-01
    z[5,6,4]  R1963     1.2891350686550140e-01
    z[5,6,4]  R1964     -5.8095979690551758e-01
    z[5,6,4]  R1965     3.6111617088317871e-01
    z[5,6,4]  R1966     -4.2486825585365295e-01
    z[5,6,4]  R1967     -1.2635989487171173e-01
    z[5,6,4]  R1968     2.6446551084518433e-01
    z[5,6,4]  R1969     1.8629802763462067e-01
    z[5,6,4]  R1970     8.6344647407531738e-01
    z[5,6,4]  R1971     5.4700754582881927e-02
    z[5,6,4]  R1972     4.2301544547080994e-01
    z[5,6,4]  R1973     -2.1201588213443756e-01
    z[5,6,4]  R1974     3.5059813410043716e-02
    z[5,6,4]  R1975     5.1355826854705811e-01
    z[5,6,4]  R1976     -6.5954226255416870e-01
    z[5,6,4]  R1977     -0.523227334022522
    z[5,6,4]  R1978     -6.3495433330535889e-01
    z[5,6,4]  R1979     -2.1799956262111664e-01
    z[5,6,4]  R1980     -2.0397461950778961e-01
    z[5,6,4]  R1981     3.1452763080596924e-01
    z[5,6,4]  R1982     9.4894334673881531e-02
    z[5,6,4]  R1983     6.2800779938697815e-02
    z[5,6,4]  R1984     4.9770158529281616e-01
    z[5,6,4]  R1985     -0.483572393655777
    z[5,6,4]  R1986     -2.8351143002510071e-01
    z[5,6,4]  R1987     -5.1582843065261841e-01
    z[5,6,4]  R1988     -0.463644415140152
    z[5,6,4]  R1989     -6.7330557107925415e-01
    z[5,6,4]  R1990     -0.00819708127528429
    z[5,6,4]  R1991     -4.6573806554079056e-02
    z[5,6,4]  R1992     -1.8613596260547638e-01
    z[5,6,4]  R1993     4.7604110091924667e-02
    z[5,6,4]  R1994     -1.3970064930617809e-02
    z[5,6,4]  R1995     3.3509659767150879e-01
    z[5,6,4]  R1996     4.5216381549835205e-01
    z[5,6,4]  R1997     4.3756440281867981e-01
    z[5,6,4]  R1998     3.0622169375419617e-01
    z[5,6,4]  R1999     -3.3020820468664169e-02
    z[5,6,4]  R2000     -4.0312924981117249e-01
    z[5,6,4]  R2001     2.3207981884479523e-01
    z[5,6,4]  R2002     1.8537633121013641e-01
    z[5,6,4]  R2003     5.0928640365600586e-01
    z[5,6,4]  R2004     -1.3969862461090088e-01
    z[5,6,4]  R2005     3.4669709205627441e-01
    z[5,6,4]  R2006     -1.7271824181079865e-01
    z[5,6,4]  R2007     3.9200261235237122e-02
    z[5,6,4]  R2008     9.2002548277378082e-02
    z[5,6,4]  R2009     -1.8937504291534424e-01
    z[5,6,4]  R2010     -1.4360065758228302e-01
    z[5,6,4]  R2011     -2.8094735741615295e-01
    z[5,6,4]  R2012     -2.1369270980358124e-02
    z[5,6,4]  R2013     3.4329418092966080e-02
    z[5,6,4]  R2014     -6.6291856765747070e-01
    z[5,6,4]  R2015     -4.8803728818893433e-01
    z[5,6,4]  R2016     -1.5790884196758270e-01
    z[5,6,4]  R2017     -5.5078315734863281e-01
    z[5,6,4]  R2018     -8.3766520023345947e-02
    z[5,6,4]  R2019     -2.1506768465042114e-01
    z[5,6,4]  R2020     2.0711828768253326e-01
    z[5,6,4]  R2021     -3.0013337731361389e-02
    z[5,6,4]  R2022     2.7905574440956116e-01
    z[5,6,4]  R2023     -4.8334106802940369e-02
    z[5,6,4]  R2024     -3.0210144817829132e-02
    z[5,6,4]  R2025     5.2105122804641724e-01
    z[5,6,4]  R2026     -1.3227945193648338e-02
    z[5,6,4]  R2027     2.3158590495586395e-01
    z[5,6,4]  R2028     2.3669071495532990e-01
    z[5,6,4]  R2029     4.9811866134405136e-02
    z[5,6,4]  R2030     1.8622530996799469e-01
    z[5,6,4]  R2031     2.2148312628269196e-01
    z[5,6,4]  R2032     3.5426761955022812e-02
    z[5,6,4]  R2033     -2.9519531130790710e-01
    z[5,6,4]  R2034     4.0074518322944641e-01
    z[5,6,4]  R2035     -2.4200105667114258e-01
    z[5,6,4]  R2036     1.2927709519863129e-01
    z[5,6,4]  R2037     2.2059883177280426e-01
    z[5,6,4]  R2038     2.1980078890919685e-02
    z[5,6,4]  R2039     1.5698119997978210e-01
    z[5,6,4]  R2040     -7.6411046087741852e-02
    z[5,6,4]  R2041     -1.6664180159568787e-01
    z[5,6,4]  R2042     -3.8733837008476257e-01
    z[5,6,4]  R2043     -7.0992313325405121e-02
    z[5,6,4]  R2044     3.9768660068511963e-01
    z[5,6,4]  R2045     -1.9679825007915497e-01
    z[5,6,4]  R2046     -0.302804559469223
    z[5,6,4]  R2047     -3.0368554592132568e-01
    z[5,6,4]  R2048     1.0551684349775314e-01
    z[5,6,4]  R2049     -1.9355788826942444e-02
    z[5,6,4]  R2050     6.2445417046546936e-02
    z[5,6,4]  R2051     -1.5688581764698029e-01
    z[5,6,4]  R2052     -1.8737266957759857e-01
    z[5,6,4]  R2053     1.3259534537792206e-01
    z[5,6,4]  R2054     -1.9866687059402466e-01
    z[5,6,4]  R2055     -3.0559748411178589e-01
    z[5,6,4]  R2056     1.3698628544807434e-01
    z[5,6,4]  R2057     -5.0602819770574570e-02
    z[5,6,4]  R2058     -1.5582096576690674e-01
    z[5,6,4]  R2059     -4.6497333049774170e-01
    z[5,6,4]  R2060     6.6649354994297028e-02
    z[5,6,4]  R2061     1.2416181713342667e-01
    z[5,6,4]  R2062     3.8874413818120956e-02
    z[5,6,4]  R2063     1.6988384723663330e-01
    z[5,6,4]  R2064     -6.0564088821411133e-01
    z[5,6,4]  R2065     5.5132603645324707e-01
    z[5,6,4]  R2066     -6.8614810705184937e-02
    z[5,6,4]  R2067     -0.664197564125061
    z[5,6,4]  R2068     -4.2081409692764282e-01
    z[5,6,4]  R2069     -1.2498825043439865e-01
    z[5,6,4]  R2070     1.0058642923831940e-01
    z[5,6,4]  R2071     4.0197573602199554e-02
    z[5,6,4]  R2072     8.1931173801422119e-02
    z[5,6,4]  R2073     4.4640928506851196e-02
    z[5,6,4]  R2074     -1.0576204210519791e-01
    z[5,6,4]  R2075     6.1329182237386703e-02
    z[5,6,4]  R2076     6.8140506744384766e-02
    z[5,6,4]  R2077     1.2142547965049744e-01
    z[5,6,4]  R2078     -1.1520221084356308e-01
    z[5,6,4]  R2079     -1.8276037275791168e-01
    z[5,6,4]  R2080     2.3541533946990967e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1947     -1
    z[5,6,5]  R1948     1
    z[5,6,5]  R1951     -0.0593063160777092
    z[5,6,5]  R1952     -1.0239279270172119e-01
    z[5,6,5]  R1953     1.3108867406845093e-01
    z[5,6,5]  R1954     -2.9137039557099342e-02
    z[5,6,5]  R1955     4.7710424661636353e-01
    z[5,6,5]  R1956     6.1132764816284180e-01
    z[5,6,5]  R1957     -2.5607712566852570e-02
    z[5,6,5]  R1958     -1.0598448663949966e-01
    z[5,6,5]  R1959     0.0591808557510376
    z[5,6,5]  R1960     -1.3488078117370605e-01
    z[5,6,5]  R1961     2.9261562228202820e-01
    z[5,6,5]  R1962     2.7521508932113647e-01
    z[5,6,5]  R1963     -6.4297604560852051e-01
    z[5,6,5]  R1964     2.6581525802612305e-01
    z[5,6,5]  R1965     -7.7289767563343048e-02
    z[5,6,5]  R1966     -0.688133716583252
    z[5,6,5]  R1967     -4.5649823546409607e-01
    z[5,6,5]  R1968     -3.7620106339454651e-01
    z[5,6,5]  R1969     -4.7036531567573547e-01
    z[5,6,5]  R1970     -2.5837129354476929e-01
    z[5,6,5]  R1971     1.5638881921768188e-01
    z[5,6,5]  R1972     7.5854189693927765e-02
    z[5,6,5]  R1973     -2.7757662534713745e-01
    z[5,6,5]  R1974     -4.5461425185203552e-01
    z[5,6,5]  R1975     -3.6846312880516052e-01
    z[5,6,5]  R1976     -4.2448961175978184e-03
    z[5,6,5]  R1977     4.9633193761110306e-02
    z[5,6,5]  R1978     -2.2574605047702789e-01
    z[5,6,5]  R1979     -6.1993849277496338e-01
    z[5,6,5]  R1980     -0.504638671875
    z[5,6,5]  R1981     2.2373767197132111e-01
    z[5,6,5]  R1982     2.8344575315713882e-02
    z[5,6,5]  R1983     -2.1390955150127411e-01
    z[5,6,5]  R1984     2.4122843146324158e-01
    z[5,6,5]  R1985     -0.284828782081604
    z[5,6,5]  R1986     -4.4182983040809631e-01
    z[5,6,5]  R1987     -1.4362284541130066e-01
    z[5,6,5]  R1988     -6.5854269266128540e-01
    z[5,6,5]  R1989     -3.1300477683544159e-02
    z[5,6,5]  R1990     3.6749291419982910e-01
    z[5,6,5]  R1991     5.0448134541511536e-02
    z[5,6,5]  R1992     3.5628405213356018e-01
    z[5,6,5]  R1993     4.9841940402984619e-01
    z[5,6,5]  R1994     2.3097988963127136e-01
    z[5,6,5]  R1995     3.3193412423133850e-01
    z[5,6,5]  R1996     -9.6335709095001221e-02
    z[5,6,5]  R1997     1.0548584163188934e-02
    z[5,6,5]  R1998     -4.0202800184488297e-02
    z[5,6,5]  R1999     0.355111688375473
    z[5,6,5]  R2000     -1.7216829583048820e-02
    z[5,6,5]  R2001     3.4412688016891479e-01
    z[5,6,5]  R2002     5.2093285322189331e-01
    z[5,6,5]  R2003     -1.3080455362796783e-01
    z[5,6,5]  R2004     -1.1704389750957489e-01
    z[5,6,5]  R2005     1.8582293391227722e-01
    z[5,6,5]  R2006     -1.4288491010665894e-01
    z[5,6,5]  R2007     1.0768998414278030e-01
    z[5,6,5]  R2008     -2.9755065217614174e-02
    z[5,6,5]  R2009     1.2650847434997559e-01
    z[5,6,5]  R2010     6.8607471883296967e-02
    z[5,6,5]  R2011     3.4096702933311462e-01
    z[5,6,5]  R2012     2.5523445010185242e-01
    z[5,6,5]  R2013     -2.1300630643963814e-02
    z[5,6,5]  R2014     4.8581507802009583e-01
    z[5,6,5]  R2015     5.2268964052200317e-01
    z[5,6,5]  R2016     -1.1703015118837357e-01
    z[5,6,5]  R2017     4.3361055850982666e-01
    z[5,6,5]  R2018     -4.6812698245048523e-01
    z[5,6,5]  R2019     1.3619804382324219e-01
    z[5,6,5]  R2020     -2.6303318142890930e-01
    z[5,6,5]  R2021     3.7050571292638779e-02
    z[5,6,5]  R2022     -1.2478940188884735e-01
    z[5,6,5]  R2023     8.6288809776306152e-02
    z[5,6,5]  R2024     -1.6528807580471039e-01
    z[5,6,5]  R2025     3.5488995909690857e-01
    z[5,6,5]  R2026     1.9388712942600250e-01
    z[5,6,5]  R2027     -9.8234914243221283e-02
    z[5,6,5]  R2028     6.5929156541824341e-01
    z[5,6,5]  R2029     -1.6213320195674896e-01
    z[5,6,5]  R2030     3.0738005042076111e-01
    z[5,6,5]  R2031     3.4320649504661560e-01
    z[5,6,5]  R2032     -1.9283334910869598e-01
    z[5,6,5]  R2033     6.1310482025146484e-01
    z[5,6,5]  R2034     2.9591289162635803e-01
    z[5,6,5]  R2035     -1.7603531479835510e-01
    z[5,6,5]  R2036     8.6186133325099945e-02
    z[5,6,5]  R2037     2.8385239839553833e-01
    z[5,6,5]  R2038     2.4412062764167786e-01
    z[5,6,5]  R2039     5.2332830429077148e-01
    z[5,6,5]  R2040     4.1580680012702942e-01
    z[5,6,5]  R2041     -1.2333630770444870e-01
    z[5,6,5]  R2042     -0.0711502805352211
    z[5,6,5]  R2043     4.6585026383399963e-01
    z[5,6,5]  R2044     3.6016803979873657e-01
    z[5,6,5]  R2045     3.2151695340871811e-02
    z[5,6,5]  R2046     -4.0721049904823303e-01
    z[5,6,5]  R2047     1.1348453909158707e-01
    z[5,6,5]  R2048     -3.0042484402656555e-01
    z[5,6,5]  R2049     -9.7968660295009613e-02
    z[5,6,5]  R2050     -2.2801715135574341e-01
    z[5,6,5]  R2051     3.3695498108863831e-01
    z[5,6,5]  R2052     -1.9032275676727295e-01
    z[5,6,5]  R2053     2.3500597476959229e-01
    z[5,6,5]  R2054     0.0966220423579216
    z[5,6,5]  R2055     6.5530523657798767e-02
    z[5,6,5]  R2056     4.1757243871688843e-01
    z[5,6,5]  R2057     3.0980497598648071e-01
    z[5,6,5]  R2058     3.6398828029632568e-01
    z[5,6,5]  R2059     3.1032985448837280e-01
    z[5,6,5]  R2060     4.4034352898597717e-01
    z[5,6,5]  R2061     2.8430068492889404e-01
    z[5,6,5]  R2062     2.5482922792434692e-01
    z[5,6,5]  R2063     -1.6160987317562103e-01
    z[5,6,5]  R2064     2.4246735870838165e-01
    z[5,6,5]  R2065     -1.6973756253719330e-01
    z[5,6,5]  R2066     3.9245158433914185e-01
    z[5,6,5]  R2067     -7.2402499616146088e-02
    z[5,6,5]  R2068     -2.5813108682632446e-01
    z[5,6,5]  R2069     -2.4999319016933441e-01
    z[5,6,5]  R2070     -1.6648904979228973e-01
    z[5,6,5]  R2071     -3.2943961024284363e-01
    z[5,6,5]  R2072     -3.5980053246021271e-02
    z[5,6,5]  R2073     -3.1049215793609619e-01
    z[5,6,5]  R2074     2.8177076578140259e-01
    z[5,6,5]  R2075     -1.1477879434823990e-01
    z[5,6,5]  R2076     2.0424258708953857e-01
    z[5,6,5]  R2077     6.9125302135944366e-02
    z[5,6,5]  R2078     -7.8146345913410187e-02
    z[5,6,5]  R2079     -3.4167268872261047e-01
    z[5,6,5]  R2080     -3.8538447022438049e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1949     -1
    z[5,6,6]  R1950     1
    z[5,6,6]  R1951     -2.1957848966121674e-01
    z[5,6,6]  R1952     2.2452560067176819e-01
    z[5,6,6]  R1953     4.5085042715072632e-02
    z[5,6,6]  R1954     -2.5616922974586487e-01
    z[5,6,6]  R1955     -2.3681713640689850e-01
    z[5,6,6]  R1956     1.5807650983333588e-01
    z[5,6,6]  R1957     3.0263975262641907e-01
    z[5,6,6]  R1958     -8.2975822687149048e-01
    z[5,6,6]  R1959     3.3224666118621826e-01
    z[5,6,6]  R1960     3.8006670773029327e-02
    z[5,6,6]  R1961     -0.523121178150177
    z[5,6,6]  R1962     5.0070118159055710e-02
    z[5,6,6]  R1963     -2.8390547633171082e-01
    z[5,6,6]  R1964     -1.9579039886593819e-02
    z[5,6,6]  R1965     -3.3382558822631836e-01
    z[5,6,6]  R1966     3.9094928652048111e-02
    z[5,6,6]  R1967     -3.0160054564476013e-01
    z[5,6,6]  R1968     2.5230368971824646e-01
    z[5,6,6]  R1969     0.0304279662668705
    z[5,6,6]  R1970     1.5494583547115326e-01
    z[5,6,6]  R1971     -2.0397663116455078e-01
    z[5,6,6]  R1972     4.6544083952903748e-01
    z[5,6,6]  R1973     0.469174861907959
    z[5,6,6]  R1974     9.3000024557113647e-02
    z[5,6,6]  R1975     8.3460107445716858e-02
    z[5,6,6]  R1976     -4.2939484119415283e-01
    z[5,6,6]  R1977     -2.0302060246467590e-01
    z[5,6,6]  R1978     4.7779113054275513e-01
    z[5,6,6]  R1979     -3.1680914759635925e-01
    z[5,6,6]  R1980     2.6725429296493530e-01
    z[5,6,6]  R1981     2.8804758191108704e-01
    z[5,6,6]  R1982     1.3155448436737061e-01
    z[5,6,6]  R1983     3.9790770411491394e-01
    z[5,6,6]  R1984     4.2352247983217239e-02
    z[5,6,6]  R1985     4.9535080790519714e-01
    z[5,6,6]  R1986     -1.9908405840396881e-01
    z[5,6,6]  R1987     -4.7892707586288452e-01
    z[5,6,6]  R1988     -1.9740824401378632e-01
    z[5,6,6]  R1989     -3.8281716406345367e-02
    z[5,6,6]  R1990     -3.3507876098155975e-02
    z[5,6,6]  R1991     -3.0224621295928955e-02
    z[5,6,6]  R1992     -3.0544428154826164e-02
    z[5,6,6]  R1993     -1.0236737877130508e-01
    z[5,6,6]  R1994     -1.8589726090431213e-01
    z[5,6,6]  R1995     2.1918751299381256e-03
    z[5,6,6]  R1996     0.079471655189991
    z[5,6,6]  R1997     1.1661176383495331e-01
    z[5,6,6]  R1998     -4.5812937617301941e-01
    z[5,6,6]  R1999     -9.5765674486756325e-03
    z[5,6,6]  R2000     1.1679705977439880e-01
    z[5,6,6]  R2001     -1.1486873030662537e-01
    z[5,6,6]  R2002     -4.6692779660224915e-01
    z[5,6,6]  R2003     1.4410948380827904e-02
    z[5,6,6]  R2004     -2.3125639557838440e-01
    z[5,6,6]  R2005     -2.1750238537788391e-01
    z[5,6,6]  R2006     3.6757946014404297e-01
    z[5,6,6]  R2007     1.0941742360591888e-01
    z[5,6,6]  R2008     2.4398863315582275e-02
    z[5,6,6]  R2009     0.0702752098441124
    z[5,6,6]  R2010     -2.9970180243253708e-02
    z[5,6,6]  R2011     1.3765922188758850e-01
    z[5,6,6]  R2012     -3.8214033842086792e-01
    z[5,6,6]  R2013     -2.1635919809341431e-01
    z[5,6,6]  R2014     1.9490335881710052e-01
    z[5,6,6]  R2015     -2.4053165316581726e-01
    z[5,6,6]  R2016     3.0572479963302612e-01
    z[5,6,6]  R2017     -1.2226716615259647e-02
    z[5,6,6]  R2018     -1.4560225419700146e-02
    z[5,6,6]  R2019     4.7664329409599304e-01
    z[5,6,6]  R2020     4.6030825376510620e-01
    z[5,6,6]  R2021     -2.3105631768703461e-01
    z[5,6,6]  R2022     -4.4470822811126709e-01
    z[5,6,6]  R2023     1.3618775643408298e-02
    z[5,6,6]  R2024     -0.049640953540802
    z[5,6,6]  R2025     -0.259581595659256
    z[5,6,6]  R2026     -3.6433029174804688e-01
    z[5,6,6]  R2027     2.9331985116004944e-01
    z[5,6,6]  R2028     1.3550363481044769e-01
    z[5,6,6]  R2029     1.5716609358787537e-01
    z[5,6,6]  R2030     0.46355140209198
    z[5,6,6]  R2031     2.0093612372875214e-02
    z[5,6,6]  R2032     1.1167913675308228e-02
    z[5,6,6]  R2033     6.5813146531581879e-02
    z[5,6,6]  R2034     1.8022309243679047e-01
    z[5,6,6]  R2035     9.1388203203678131e-02
    z[5,6,6]  R2036     5.4702490568161011e-01
    z[5,6,6]  R2037     1.7998608946800232e-01
    z[5,6,6]  R2038     5.0963789224624634e-01
    z[5,6,6]  R2039     1.6429116949439049e-02
    z[5,6,6]  R2040     -2.5223836302757263e-01
    z[5,6,6]  R2041     3.8169443607330322e-01
    z[5,6,6]  R2042     -8.0177947878837585e-02
    z[5,6,6]  R2043     0.0874348059296608
    z[5,6,6]  R2044     1.4457820355892181e-01
    z[5,6,6]  R2045     3.1224694848060608e-01
    z[5,6,6]  R2046     2.7112990617752075e-01
    z[5,6,6]  R2047     2.1874293684959412e-01
    z[5,6,6]  R2048     -2.8557786345481873e-01
    z[5,6,6]  R2049     -1.9834528863430023e-01
    z[5,6,6]  R2050     -5.3242433071136475e-01
    z[5,6,6]  R2051     3.0272516608238220e-01
    z[5,6,6]  R2052     -1.3332915306091309e-01
    z[5,6,6]  R2053     2.7723437547683716e-01
    z[5,6,6]  R2054     5.3015863895416260e-01
    z[5,6,6]  R2055     6.3868030905723572e-02
    z[5,6,6]  R2056     9.1345183551311493e-02
    z[5,6,6]  R2057     -6.0760229825973511e-01
    z[5,6,6]  R2058     -2.4147087242454290e-04
    z[5,6,6]  R2059     -5.2079045772552490e-01
    z[5,6,6]  R2060     -1.7207440733909607e-01
    z[5,6,6]  R2061     -5.1508295536041260e-01
    z[5,6,6]  R2062     3.1199935078620911e-01
    z[5,6,6]  R2063     3.9095902442932129e-01
    z[5,6,6]  R2064     -2.7082201838493347e-01
    z[5,6,6]  R2065     -2.7292063832283020e-01
    z[5,6,6]  R2066     -1.0957321152091026e-02
    z[5,6,6]  R2067     -2.5969070196151733e-01
    z[5,6,6]  R2068     -1.3700519502162933e-01
    z[5,6,6]  R2069     -4.0275490283966064e-01
    z[5,6,6]  R2070     -4.9255305528640747e-01
    z[5,6,6]  R2071     -2.0176558196544647e-01
    z[5,6,6]  R2072     -0.392668753862381
    z[5,6,6]  R2073     2.4300108850002289e-01
    z[5,6,6]  R2074     -0.00647188164293766
    z[5,6,6]  R2075     5.4791235923767090e-01
    z[5,6,6]  R2076     0.568831205368042
    z[5,6,6]  R2077     -2.7207210659980774e-01
    z[5,6,6]  R2078     4.0409117937088013e-01
    z[5,6,6]  R2079     -4.2171877622604370e-01
    z[5,6,6]  R2080     -1.4311835169792175e-02
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2081     -1
    z[6,5,0]  R2082     1
    z[6,5,0]  R2095     -9.0638458728790283e-01
    z[6,5,0]  R2096     -8.2799595594406128e-01
    z[6,5,0]  R2097     -7.8493207693099976e-01
    z[6,5,0]  R2098     -7.0772647857666016e-01
    z[6,5,0]  R2099     -0.819678008556366
    z[6,5,0]  R2100     -6.6300272941589355e-01
    z[6,5,0]  R2101     -8.1264919042587280e-01
    z[6,5,0]  R2102     -6.8940824270248413e-01
    z[6,5,0]  R2103     -8.8037103414535522e-01
    z[6,5,0]  R2104     2.9375693202018738e-01
    z[6,5,0]  R2105     -3.8623297587037086e-04
    z[6,5,0]  R2106     4.9018543958663940e-01
    z[6,5,0]  R2107     4.9586838483810425e-01
    z[6,5,0]  R2108     4.3103596568107605e-01
    z[6,5,0]  R2109     2.0347057282924652e-01
    z[6,5,0]  R2110     3.9923486113548279e-01
    z[6,5,0]  R2111     0.421084463596344
    z[6,5,0]  R2112     2.6942405104637146e-01
    z[6,5,0]  R2113     3.8349777460098267e-01
    z[6,5,0]  R2114     3.8672599196434021e-01
    z[6,5,0]  R2115     0.599850058555603
    z[6,5,0]  R2116     3.9805805683135986e-01
    z[6,5,0]  R2117     9.7217820584774017e-02
    z[6,5,0]  R2118     3.7836232781410217e-01
    z[6,5,0]  R2119     2.1848320960998535e-01
    z[6,5,0]  R2120     4.0968227386474609e-01
    z[6,5,0]  R2121     5.7834142446517944e-01
    z[6,5,0]  R2122     -4.1519635915756226e-01
    z[6,5,0]  R2123     -2.0829349756240845e-01
    z[6,5,0]  R2124     1.6713143885135651e-01
    z[6,5,0]  R2125     0.291344553232193
    z[6,5,0]  R2126     2.0175081491470337e-01
    z[6,5,0]  R2127     -1.8293541669845581e-01
    z[6,5,0]  R2128     -1.5737058222293854e-01
    z[6,5,0]  R2129     -7.6309749856591225e-03
    z[6,5,0]  R2130     -3.4955191612243652e-01
    z[6,5,0]  R2131     -4.1043874621391296e-01
    z[6,5,0]  R2132     1.1732964962720871e-01
    z[6,5,0]  R2133     -4.1289508342742920e-01
    z[6,5,0]  R2134     6.7198120057582855e-02
    z[6,5,0]  R2135     1.4178267121315002e-01
    z[6,5,0]  R2136     -3.6966481804847717e-01
    z[6,5,0]  R2137     4.9518829584121704e-01
    z[6,5,0]  R2138     -2.0473115146160126e-01
    z[6,5,0]  R2139     -8.2797199487686157e-01
    z[6,5,0]  R2140     0.617081344127655
    z[6,5,0]  R2141     5.0851190090179443e-01
    z[6,5,0]  R2142     3.9375400543212891e-01
    z[6,5,0]  R2143     0.809958279132843
    z[6,5,0]  R2144     8.5605132579803467e-01
    z[6,5,0]  R2145     -2.9784919694066048e-02
    z[6,5,0]  R2146     -0.286978155374527
    z[6,5,0]  R2147     1.6640554368495941e-01
    z[6,5,0]  R2148     7.2376525402069092e-01
    z[6,5,0]  R2149     -1.7412005364894867e-01
    z[6,5,0]  R2150     8.0571383237838745e-02
    z[6,5,0]  R2151     8.3700728416442871e-01
    z[6,5,0]  R2152     1.3343612849712372e-01
    z[6,5,0]  R2153     -6.4536012709140778e-02
    z[6,5,0]  R2154     4.4132387638092041e-01
    z[6,5,0]  R2155     6.9306713342666626e-01
    z[6,5,0]  R2156     -2.6543736457824707e-01
    z[6,5,0]  R2157     4.8704367876052856e-01
    z[6,5,0]  R2158     3.5728746652603149e-01
    z[6,5,0]  R2159     2.4972066283226013e-01
    z[6,5,0]  R2160     2.2820445895195007e-01
    z[6,5,0]  R2161     4.4021755456924438e-01
    z[6,5,0]  R2162     8.7229609489440918e-01
    z[6,5,0]  R2163     1.6437853872776031e-01
    z[6,5,0]  R2164     4.1851267218589783e-01
    z[6,5,0]  R2165     -9.3097686767578125e-02
    z[6,5,0]  R2166     0.0915379747748375
    z[6,5,0]  R2167     -0.0588078498840332
    z[6,5,0]  R2168     4.6570891141891479e-01
    z[6,5,0]  R2169     -3.0314895510673523e-01
    z[6,5,0]  R2170     3.5545620322227478e-01
    z[6,5,0]  R2171     -2.0369479060173035e-01
    z[6,5,0]  R2172     -1.8442565202713013e-01
    z[6,5,0]  R2173     4.4914808869361877e-01
    z[6,5,0]  R2174     5.8731153607368469e-02
    z[6,5,0]  R2175     0.0049970424734056
    z[6,5,0]  R2176     -3.4934845566749573e-01
    z[6,5,0]  R2177     -7.5006228685379028e-01
    z[6,5,0]  R2178     4.0946078300476074e-01
    z[6,5,0]  R2179     -1.1233063042163849e-01
    z[6,5,0]  R2180     7.2808766365051270e-01
    z[6,5,0]  R2181     -2.4780279025435448e-02
    z[6,5,0]  R2182     -3.3136874437332153e-02
    z[6,5,0]  R2183     3.3650982379913330e-01
    z[6,5,0]  R2184     3.7405374646186829e-01
    z[6,5,0]  R2185     -5.7996219396591187e-01
    z[6,5,0]  R2186     -7.9358226060867310e-01
    z[6,5,0]  R2187     -0.518456757068634
    z[6,5,0]  R2188     -6.3096517324447632e-01
    z[6,5,0]  R2189     -3.6290261149406433e-01
    z[6,5,0]  R2190     -5.1928228139877319e-01
    z[6,5,0]  R2191     -2.2811952233314514e-01
    z[6,5,0]  R2192     4.1172024607658386e-01
    z[6,5,0]  R2193     5.6369763612747192e-01
    z[6,5,0]  R2194     6.7790520191192627e-01
    z[6,5,0]  R2195     2.5977733731269836e-01
    z[6,5,0]  R2196     3.2061547040939331e-01
    z[6,5,0]  R2197     1.3840182125568390e-01
    z[6,5,0]  R2198     -3.0481213331222534e-01
    z[6,5,0]  R2199     -5.0336980819702148e-01
    z[6,5,0]  R2200     -1.9695284962654114e-01
    z[6,5,0]  R2201     -1.1693647503852844e-01
    z[6,5,0]  R2202     5.1186162233352661e-01
    z[6,5,0]  R2203     6.1486173421144485e-02
    z[6,5,0]  R2204     0.04227314889431
    z[6,5,0]  R2205     -3.9250290393829346e-01
    z[6,5,0]  R2206     2.1174551546573639e-01
    z[6,5,0]  R2207     -7.1806021034717560e-02
    z[6,5,0]  R2208     -3.5093218088150024e-02
    z[6,5,0]  R2209     3.3915615081787109e-01
    z[6,5,0]  R2210     -1.1973375082015991e-01
    z[6,5,0]  R2211     -3.8449484109878540e-01
    z[6,5,0]  R2212     -1.7956182360649109e-01
    z[6,5,0]  R2213     -0.182621568441391
    z[6,5,0]  R2214     1.0773085057735443e-01
    z[6,5,0]  R2215     -0.0769742876291275
    z[6,5,0]  R2216     3.2144537568092346e-01
    z[6,5,0]  R2217     1.9060429930686951e-01
    z[6,5,0]  R2218     2.5585165619850159e-01
    z[6,5,0]  R2219     -2.3111756891012192e-02
    z[6,5,0]  R2220     3.3616542816162109e-01
    z[6,5,0]  R2221     2.4032276868820190e-01
    z[6,5,0]  R2222     -8.9384570717811584e-02
    z[6,5,0]  R2223     -2.1971440315246582e-01
    z[6,5,0]  R2224     -2.1087791025638580e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2083     -1
    z[6,5,1]  R2084     1
    z[6,5,1]  R2095     2.3567005991935730e-01
    z[6,5,1]  R2096     -4.1897028684616089e-02
    z[6,5,1]  R2097     2.8792524710297585e-02
    z[6,5,1]  R2098     -1.2074025720357895e-01
    z[6,5,1]  R2099     -8.2762926816940308e-02
    z[6,5,1]  R2100     -1.4048515260219574e-01
    z[6,5,1]  R2101     4.6277213841676712e-02
    z[6,5,1]  R2102     -1.1682908982038498e-01
    z[6,5,1]  R2103     -1.0781950503587723e-01
    z[6,5,1]  R2104     -2.0093406736850739e-01
    z[6,5,1]  R2105     -8.9190477132797241e-01
    z[6,5,1]  R2106     -3.7189406156539917e-01
    z[6,5,1]  R2107     -4.8617777228355408e-01
    z[6,5,1]  R2108     -5.5693954229354858e-01
    z[6,5,1]  R2109     -6.9330793619155884e-01
    z[6,5,1]  R2110     -7.2400510311126709e-01
    z[6,5,1]  R2111     8.9146637916564941e-01
    z[6,5,1]  R2112     9.2655897140502930e-01
    z[6,5,1]  R2113     8.8261890411376953e-01
    z[6,5,1]  R2114     0.881799578666687
    z[6,5,1]  R2115     -5.0700485706329346e-01
    z[6,5,1]  R2116     -7.7167344093322754e-01
    z[6,5,1]  R2117     -8.0269873142242432e-01
    z[6,5,1]  R2118     -3.3003348112106323e-01
    z[6,5,1]  R2119     -3.3140763640403748e-01
    z[6,5,1]  R2120     -7.5931972265243530e-01
    z[6,5,1]  R2121     -1.2345468252897263e-01
    z[6,5,1]  R2122     -7.6918292045593262e-01
    z[6,5,1]  R2123     -0.752150297164917
    z[6,5,1]  R2124     -7.9434764385223389e-01
    z[6,5,1]  R2125     -9.1375911235809326e-01
    z[6,5,1]  R2126     -7.7818918228149414e-01
    z[6,5,1]  R2127     -9.4941031932830811e-01
    z[6,5,1]  R2128     -9.4771158695220947e-01
    z[6,5,1]  R2129     -6.0370171070098877e-01
    z[6,5,1]  R2130     -8.1486070156097412e-01
    z[6,5,1]  R2131     -7.2885221242904663e-01
    z[6,5,1]  R2132     -6.8084597587585449e-01
    z[6,5,1]  R2133     -7.7136713266372681e-01
    z[6,5,1]  R2134     -7.2400116920471191e-01
    z[6,5,1]  R2135     -0.770193874835968
    z[6,5,1]  R2136     -8.5195004940032959e-01
    z[6,5,1]  R2137     4.2647279798984528e-02
    z[6,5,1]  R2138     -8.0612915754318237e-01
    z[6,5,1]  R2139     -3.8849323987960815e-01
    z[6,5,1]  R2140     -3.4533193707466125e-01
    z[6,5,1]  R2141     -5.2539217472076416e-01
    z[6,5,1]  R2142     -3.1653749942779541e-01
    z[6,5,1]  R2143     -3.4983004443347454e-03
    z[6,5,1]  R2144     0.0690355971455574
    z[6,5,1]  R2145     -8.1956321001052856e-01
    z[6,5,1]  R2146     -5.9959208965301514e-01
    z[6,5,1]  R2147     -7.6063059270381927e-02
    z[6,5,1]  R2148     -2.0901305973529816e-01
    z[6,5,1]  R2149     -4.9557766318321228e-01
    z[6,5,1]  R2150     -5.0943940877914429e-01
    z[6,5,1]  R2151     -2.6115508750081062e-02
    z[6,5,1]  R2152     7.8820818662643433e-01
    z[6,5,1]  R2153     9.4797450304031372e-01
    z[6,5,1]  R2154     5.7311809062957764e-01
    z[6,5,1]  R2155     -9.0785082429647446e-03
    z[6,5,1]  R2156     -5.7964098453521729e-01
    z[6,5,1]  R2157     -4.8482900857925415e-01
    z[6,5,1]  R2158     -1.7932601273059845e-01
    z[6,5,1]  R2159     -3.6394849419593811e-01
    z[6,5,1]  R2160     -0.682121753692627
    z[6,5,1]  R2161     -7.4453867971897125e-02
    z[6,5,1]  R2162     6.0457970947027206e-02
    z[6,5,1]  R2163     -0.321254700422287
    z[6,5,1]  R2164     -1.4761339128017426e-01
    z[6,5,1]  R2165     -7.9079437255859375e-01
    z[6,5,1]  R2166     -8.0034458637237549e-01
    z[6,5,1]  R2167     -8.2423675060272217e-01
    z[6,5,1]  R2168     -5.2353560924530029e-02
    z[6,5,1]  R2169     -5.6139910221099854e-01
    z[6,5,1]  R2170     -1.7574384808540344e-01
    z[6,5,1]  R2171     -4.8669952154159546e-01
    z[6,5,1]  R2172     0.811751663684845
    z[6,5,1]  R2173     0.639335036277771
    z[6,5,1]  R2174     7.7055817842483521e-01
    z[6,5,1]  R2175     -9.2000114917755127e-01
    z[6,5,1]  R2176     -8.1789934635162354e-01
    z[6,5,1]  R2177     -5.2259933948516846e-01
    z[6,5,1]  R2178     -0.166182741522789
    z[6,5,1]  R2179     -0.468726247549057
    z[6,5,1]  R2180     -1.8806332349777222e-01
    z[6,5,1]  R2181     8.7126356363296509e-01
    z[6,5,1]  R2182     4.3835404515266418e-01
    z[6,5,1]  R2183     7.1538448333740234e-01
    z[6,5,1]  R2184     5.4896432161331177e-01
    z[6,5,1]  R2185     2.3080082237720490e-01
    z[6,5,1]  R2186     -0.0527375154197216
    z[6,5,1]  R2187     2.0245993137359619e-01
    z[6,5,1]  R2188     2.6000419165939093e-03
    z[6,5,1]  R2189     -2.0599098876118660e-02
    z[6,5,1]  R2190     -5.4028481245040894e-02
    z[6,5,1]  R2191     6.0787373781204224e-01
    z[6,5,1]  R2192     6.5360605716705322e-02
    z[6,5,1]  R2193     2.1668045222759247e-01
    z[6,5,1]  R2194     -1.9635602831840515e-02
    z[6,5,1]  R2195     -7.4423557519912720e-01
    z[6,5,1]  R2196     -7.7088785171508789e-01
    z[6,5,1]  R2197     -6.4877432584762573e-01
    z[6,5,1]  R2198     -6.7080420255661011e-01
    z[6,5,1]  R2199     -0.663345456123352
    z[6,5,1]  R2200     -5.3227263689041138e-01
    z[6,5,1]  R2201     -0.687248170375824
    z[6,5,1]  R2202     -0.569867730140686
    z[6,5,1]  R2203     -0.77773118019104
    z[6,5,1]  R2204     -3.8848367333412170e-01
    z[6,5,1]  R2205     -8.5708284378051758e-01
    z[6,5,1]  R2206     -0.671985387802124
    z[6,5,1]  R2207     -7.8402262926101685e-01
    z[6,5,1]  R2208     -0.723905086517334
    z[6,5,1]  R2209     -5.6439733505249023e-01
    z[6,5,1]  R2210     -0.00883125513792038
    z[6,5,1]  R2211     -0.103699691593647
    z[6,5,1]  R2212     5.3361009806394577e-02
    z[6,5,1]  R2213     5.5084377527236938e-01
    z[6,5,1]  R2214     5.8834302425384521e-01
    z[6,5,1]  R2215     -0.764907956123352
    z[6,5,1]  R2216     -9.2994827032089233e-01
    z[6,5,1]  R2217     -7.1044009923934937e-01
    z[6,5,1]  R2218     -6.4333051443099976e-01
    z[6,5,1]  R2219     2.3180831968784332e-01
    z[6,5,1]  R2220     -6.7275100946426392e-01
    z[6,5,1]  R2221     2.0524153113365173e-01
    z[6,5,1]  R2222     7.5061500072479248e-02
    z[6,5,1]  R2223     4.4072076678276062e-01
    z[6,5,1]  R2224     8.9551174640655518e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2085     -1
    z[6,5,2]  R2086     1
    z[6,5,2]  R2095     4.8219002783298492e-02
    z[6,5,2]  R2096     2.4617350101470947e-01
    z[6,5,2]  R2097     0.0839306190609932
    z[6,5,2]  R2098     2.1931204199790955e-01
    z[6,5,2]  R2099     -1.4509050548076630e-01
    z[6,5,2]  R2100     -1.1842354387044907e-01
    z[6,5,2]  R2101     -3.0637830495834351e-01
    z[6,5,2]  R2102     -2.6090177893638611e-01
    z[6,5,2]  R2103     -1.3556927442550659e-01
    z[6,5,2]  R2104     -1.7798444628715515e-01
    z[6,5,2]  R2105     -5.5900290608406067e-02
    z[6,5,2]  R2106     -2.9828870296478271e-01
    z[6,5,2]  R2107     -1.3427162542939186e-02
    z[6,5,2]  R2108     4.1312953829765320e-01
    z[6,5,2]  R2109     -3.4522205591201782e-01
    z[6,5,2]  R2110     0.289383202791214
    z[6,5,2]  R2111     1.4852622523903847e-02
    z[6,5,2]  R2112     2.1137434244155884e-01
    z[6,5,2]  R2113     6.5856881439685822e-02
    z[6,5,2]  R2114     2.1253588795661926e-01
    z[6,5,2]  R2115     1.0035727173089981e-01
    z[6,5,2]  R2116     1.6829672455787659e-01
    z[6,5,2]  R2117     -1.9416575133800507e-01
    z[6,5,2]  R2118     -1.8333847820758820e-01
    z[6,5,2]  R2119     -5.2161026000976562e-01
    z[6,5,2]  R2120     3.4443494677543640e-01
    z[6,5,2]  R2121     2.2141848504543304e-01
    z[6,5,2]  R2122     1.4933940954506397e-02
    z[6,5,2]  R2123     -1.5962953865528107e-01
    z[6,5,2]  R2124     3.8431543856859207e-02
    z[6,5,2]  R2125     0.095056913793087
    z[6,5,2]  R2126     -9.1186009347438812e-02
    z[6,5,2]  R2127     2.2850561141967773e-01
    z[6,5,2]  R2128     1.8350470066070557e-01
    z[6,5,2]  R2129     -1.0992185026407242e-01
    z[6,5,2]  R2130     -6.4968854188919067e-02
    z[6,5,2]  R2131     1.5266297757625580e-01
    z[6,5,2]  R2132     0.0628947913646698
    z[6,5,2]  R2133     -1.3236106932163239e-01
    z[6,5,2]  R2134     1.4494094066321850e-02
    z[6,5,2]  R2135     2.4858203530311584e-01
    z[6,5,2]  R2136     -9.9425628781318665e-02
    z[6,5,2]  R2137     -4.5960783958435059e-01
    z[6,5,2]  R2138     -1.3062451779842377e-01
    z[6,5,2]  R2139     2.0609753206372261e-02
    z[6,5,2]  R2140     -1.2111578881740570e-01
    z[6,5,2]  R2141     -5.5107390880584717e-01
    z[6,5,2]  R2142     -6.5184015035629272e-01
    z[6,5,2]  R2143     1.5165668725967407e-01
    z[6,5,2]  R2144     9.4467557966709137e-02
    z[6,5,2]  R2145     3.7212669849395752e-01
    z[6,5,2]  R2146     0.510319173336029
    z[6,5,2]  R2147     -7.9994976520538330e-01
    z[6,5,2]  R2148     -2.0820085704326630e-01
    z[6,5,2]  R2149     -2.5144013762474060e-01
    z[6,5,2]  R2150     -4.7872957587242126e-01
    z[6,5,2]  R2151     3.4862619638442993e-01
    z[6,5,2]  R2152     -4.0366011857986450e-01
    z[6,5,2]  R2153     -1.7312115430831909e-01
    z[6,5,2]  R2154     -3.5301384329795837e-01
    z[6,5,2]  R2155     -3.4765001386404037e-02
    z[6,5,2]  R2156     4.2130580544471741e-01
    z[6,5,2]  R2157     -5.7477647066116333e-01
    z[6,5,2]  R2158     -0.645080029964447
    z[6,5,2]  R2159     -5.4246175289154053e-01
    z[6,5,2]  R2160     -1.1096552014350891e-01
    z[6,5,2]  R2161     -2.7713960409164429e-01
    z[6,5,2]  R2162     1.6731685400009155e-01
    z[6,5,2]  R2163     -5.4264806210994720e-02
    z[6,5,2]  R2164     -2.9492408037185669e-01
    z[6,5,2]  R2165     -5.9931054711341858e-02
    z[6,5,2]  R2166     5.0907637923955917e-02
    z[6,5,2]  R2167     -5.9057138860225677e-02
    z[6,5,2]  R2168     1.0383627563714981e-01
    z[6,5,2]  R2169     -4.1855287551879883e-01
    z[6,5,2]  R2170     -2.0485353469848633e-01
    z[6,5,2]  R2171     1.7963831126689911e-01
    z[6,5,2]  R2172     -3.7469189614057541e-02
    z[6,5,2]  R2173     -2.6761874556541443e-01
    z[6,5,2]  R2174     -3.3364719152450562e-01
    z[6,5,2]  R2175     3.4020170569419861e-02
    z[6,5,2]  R2176     1.9581666216254234e-02
    z[6,5,2]  R2177     2.5441735982894897e-02
    z[6,5,2]  R2178     -0.199344664812088
    z[6,5,2]  R2179     4.2731454968452454e-01
    z[6,5,2]  R2180     2.1485167741775513e-01
    z[6,5,2]  R2181     -3.7014293670654297e-01
    z[6,5,2]  R2182     3.8449708372354507e-02
    z[6,5,2]  R2183     -2.8615200892090797e-02
    z[6,5,2]  R2184     -3.9972978830337524e-01
    z[6,5,2]  R2185     4.1230174899101257e-01
    z[6,5,2]  R2186     3.5707753896713257e-01
    z[6,5,2]  R2187     8.0414557456970215e-01
    z[6,5,2]  R2188     6.6721254587173462e-01
    z[6,5,2]  R2189     6.7652350664138794e-01
    z[6,5,2]  R2190     2.7625033259391785e-01
    z[6,5,2]  R2191     1.0251188278198242e-01
    z[6,5,2]  R2192     -1.7896650359034538e-02
    z[6,5,2]  R2193     -2.8267744928598404e-03
    z[6,5,2]  R2194     5.4159498214721680e-01
    z[6,5,2]  R2195     1.3479290902614594e-01
    z[6,5,2]  R2196     2.1449199318885803e-01
    z[6,5,2]  R2197     1.9075600802898407e-01
    z[6,5,2]  R2198     -9.1220803558826447e-02
    z[6,5,2]  R2199     -7.3211520910263062e-02
    z[6,5,2]  R2200     2.7145119383931160e-02
    z[6,5,2]  R2201     -3.1677749752998352e-01
    z[6,5,2]  R2202     3.5254955291748047e-01
    z[6,5,2]  R2203     -5.6832976639270782e-02
    z[6,5,2]  R2204     9.8804473876953125e-02
    z[6,5,2]  R2205     -2.0342530310153961e-01
    z[6,5,2]  R2206     2.1533285081386566e-01
    z[6,5,2]  R2207     -1.9392953813076019e-01
    z[6,5,2]  R2208     -3.7211760878562927e-01
    z[6,5,2]  R2209     3.8335654139518738e-01
    z[6,5,2]  R2210     -2.6121586561203003e-01
    z[6,5,2]  R2211     -4.1250422596931458e-01
    z[6,5,2]  R2212     -4.9788277596235275e-02
    z[6,5,2]  R2213     1.2829124927520752e-01
    z[6,5,2]  R2214     2.3098066449165344e-01
    z[6,5,2]  R2215     3.1553870439529419e-01
    z[6,5,2]  R2216     0.0686025395989418
    z[6,5,2]  R2217     -4.4498926401138306e-01
    z[6,5,2]  R2218     -4.5791637897491455e-01
    z[6,5,2]  R2219     1.6195403039455414e-01
    z[6,5,2]  R2220     -2.5885558128356934e-01
    z[6,5,2]  R2221     2.4468574672937393e-02
    z[6,5,2]  R2222     3.8558891415596008e-01
    z[6,5,2]  R2223     -1.9540810957551003e-02
    z[6,5,2]  R2224     -5.6084785610437393e-02
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2087     -1
    z[6,5,3]  R2088     1
    z[6,5,3]  R2095     -3.3907768130302429e-01
    z[6,5,3]  R2096     -2.9924616217613220e-01
    z[6,5,3]  R2097     -3.3888214826583862e-01
    z[6,5,3]  R2098     -5.9020549058914185e-01
    z[6,5,3]  R2099     -2.7884083986282349e-01
    z[6,5,3]  R2100     -5.5373167991638184e-01
    z[6,5,3]  R2101     -1.9600987434387207e-01
    z[6,5,3]  R2102     -3.7111577391624451e-01
    z[6,5,3]  R2103     2.6010829210281372e-01
    z[6,5,3]  R2104     8.1559962034225464e-01
    z[6,5,3]  R2105     1.2610229849815369e-01
    z[6,5,3]  R2106     9.3165948987007141e-02
    z[6,5,3]  R2107     -4.9079051613807678e-01
    z[6,5,3]  R2108     -4.9664461612701416e-01
    z[6,5,3]  R2109     3.9586505293846130e-01
    z[6,5,3]  R2110     2.1753889322280884e-01
    z[6,5,3]  R2111     -5.1467999815940857e-02
    z[6,5,3]  R2112     1.1947729438543320e-01
    z[6,5,3]  R2113     1.1300613731145859e-01
    z[6,5,3]  R2114     -3.8399152457714081e-02
    z[6,5,3]  R2115     3.9864072203636169e-01
    z[6,5,3]  R2116     -0.0781896784901619
    z[6,5,3]  R2117     5.0997996330261230e-01
    z[6,5,3]  R2118     -0.0290201585739851
    z[6,5,3]  R2119     3.3412650227546692e-02
    z[6,5,3]  R2120     6.9710515439510345e-02
    z[6,5,3]  R2121     3.3124664425849915e-01
    z[6,5,3]  R2122     9.6823759377002716e-02
    z[6,5,3]  R2123     2.7094164490699768e-01
    z[6,5,3]  R2124     1.2503567337989807e-01
    z[6,5,3]  R2125     1.2436323612928391e-01
    z[6,5,3]  R2126     -2.3279446363449097e-01
    z[6,5,3]  R2127     -5.4520197212696075e-02
    z[6,5,3]  R2128     -1.1272186040878296e-01
    z[6,5,3]  R2129     -3.9822015166282654e-01
    z[6,5,3]  R2130     1.9771383702754974e-01
    z[6,5,3]  R2131     -3.5733717679977417e-01
    z[6,5,3]  R2132     9.8374977707862854e-02
    z[6,5,3]  R2133     4.0437778830528259e-01
    z[6,5,3]  R2134     3.5644698143005371e-01
    z[6,5,3]  R2135     -3.9706024527549744e-01
    z[6,5,3]  R2136     2.9846101999282837e-01
    z[6,5,3]  R2137     2.7269285917282104e-01
    z[6,5,3]  R2138     1.0264895856380463e-01
    z[6,5,3]  R2139     2.5535422563552856e-01
    z[6,5,3]  R2140     4.0238106250762939e-01
    z[6,5,3]  R2141     -8.0770663917064667e-03
    z[6,5,3]  R2142     7.5806421227753162e-03
    z[6,5,3]  R2143     -1.4889647066593170e-01
    z[6,5,3]  R2144     1.0548835247755051e-01
    z[6,5,3]  R2145     -1.6698397696018219e-02
    z[6,5,3]  R2146     -3.6903306841850281e-01
    z[6,5,3]  R2147     3.1129187345504761e-01
    z[6,5,3]  R2148     2.8346312046051025e-01
    z[6,5,3]  R2149     7.2360301017761230e-01
    z[6,5,3]  R2150     4.1686362028121948e-01
    z[6,5,3]  R2151     1.5570640563964844e-01
    z[6,5,3]  R2152     1.2262795865535736e-01
    z[6,5,3]  R2153     -1.3377287983894348e-01
    z[6,5,3]  R2154     1.1306324601173401e-01
    z[6,5,3]  R2155     5.3718948364257812e-01
    z[6,5,3]  R2156     -0.571797788143158
    z[6,5,3]  R2157     2.1838736534118652e-01
    z[6,5,3]  R2158     3.0689904093742371e-01
    z[6,5,3]  R2159     6.3965070247650146e-01
    z[6,5,3]  R2160     5.1850110292434692e-01
    z[6,5,3]  R2161     5.0610125064849854e-01
    z[6,5,3]  R2162     2.2512586414813995e-01
    z[6,5,3]  R2163     5.3207403421401978e-01
    z[6,5,3]  R2164     6.9865804910659790e-01
    z[6,5,3]  R2165     -2.8843320906162262e-02
    z[6,5,3]  R2166     4.2975005507469177e-01
    z[6,5,3]  R2167     3.2536211609840393e-01
    z[6,5,3]  R2168     5.2024662494659424e-01
    z[6,5,3]  R2169     -1.0241288691759109e-01
    z[6,5,3]  R2170     0.801220178604126
    z[6,5,3]  R2171     4.1895386576652527e-01
    z[6,5,3]  R2172     2.0774005353450775e-01
    z[6,5,3]  R2173     2.7850806713104248e-01
    z[6,5,3]  R2174     -1.0500277578830719e-01
    z[6,5,3]  R2175     -3.9494130760431290e-02
    z[6,5,3]  R2176     -2.1544608473777771e-01
    z[6,5,3]  R2177     -7.8749559819698334e-02
    z[6,5,3]  R2178     8.2119709253311157e-01
    z[6,5,3]  R2179     -5.1762568950653076e-01
    z[6,5,3]  R2180     1.3576522469520569e-01
    z[6,5,3]  R2181     0.0986611545085907
    z[6,5,3]  R2182     7.8905093669891357e-01
    z[6,5,3]  R2183     -2.1489325165748596e-01
    z[6,5,3]  R2184     -4.4135209918022156e-01
    z[6,5,3]  R2185     5.7542663812637329e-01
    z[6,5,3]  R2186     4.0845578908920288e-01
    z[6,5,3]  R2187     1.5528170764446259e-01
    z[6,5,3]  R2188     1.2737837433815002e-01
    z[6,5,3]  R2189     3.0088528990745544e-01
    z[6,5,3]  R2190     4.5655813813209534e-01
    z[6,5,3]  R2191     -4.9563857913017273e-01
    z[6,5,3]  R2192     -3.1470906734466553e-01
    z[6,5,3]  R2193     1.1076045036315918e-01
    z[6,5,3]  R2194     -3.1615990400314331e-01
    z[6,5,3]  R2195     2.7734089642763138e-02
    z[6,5,3]  R2196     -3.6465135216712952e-01
    z[6,5,3]  R2197     -1.1362092941999435e-01
    z[6,5,3]  R2198     -2.0058588683605194e-01
    z[6,5,3]  R2199     -2.3111377656459808e-01
    z[6,5,3]  R2200     -1.4693267643451691e-01
    z[6,5,3]  R2201     3.1360420584678650e-01
    z[6,5,3]  R2202     -1.1760506778955460e-01
    z[6,5,3]  R2203     3.6228078603744507e-01
    z[6,5,3]  R2204     -3.5031415522098541e-02
    z[6,5,3]  R2205     -3.0206680297851562e-02
    z[6,5,3]  R2206     2.3643206059932709e-01
    z[6,5,3]  R2207     2.0475223660469055e-02
    z[6,5,3]  R2208     3.4598565101623535e-01
    z[6,5,3]  R2209     -1.1399001628160477e-01
    z[6,5,3]  R2210     -5.4585546255111694e-01
    z[6,5,3]  R2211     -5.9481322765350342e-01
    z[6,5,3]  R2212     -5.2916777133941650e-01
    z[6,5,3]  R2213     -3.3844679594039917e-01
    z[6,5,3]  R2214     -4.7032311558723450e-01
    z[6,5,3]  R2215     2.7833151817321777e-01
    z[6,5,3]  R2216     6.9129839539527893e-03
    z[6,5,3]  R2217     -2.2999511659145355e-01
    z[6,5,3]  R2218     -5.7330571115016937e-02
    z[6,5,3]  R2219     -5.9929913282394409e-01
    z[6,5,3]  R2220     -2.2839865088462830e-01
    z[6,5,3]  R2221     -6.1922895908355713e-01
    z[6,5,3]  R2222     -0.387405127286911
    z[6,5,3]  R2223     -5.4892927408218384e-01
    z[6,5,3]  R2224     -1.1917480081319809e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2089     -1
    z[6,5,4]  R2090     1
    z[6,5,4]  R2095     -4.6573806554079056e-02
    z[6,5,4]  R2096     -1.8613596260547638e-01
    z[6,5,4]  R2097     4.7604110091924667e-02
    z[6,5,4]  R2098     -1.3970064930617809e-02
    z[6,5,4]  R2099     3.3509659767150879e-01
    z[6,5,4]  R2100     4.5216381549835205e-01
    z[6,5,4]  R2101     4.3756440281867981e-01
    z[6,5,4]  R2102     3.0622169375419617e-01
    z[6,5,4]  R2103     -3.3020820468664169e-02
    z[6,5,4]  R2104     -4.0312924981117249e-01
    z[6,5,4]  R2105     2.3207981884479523e-01
    z[6,5,4]  R2106     1.8537633121013641e-01
    z[6,5,4]  R2107     5.0928640365600586e-01
    z[6,5,4]  R2108     -1.3969862461090088e-01
    z[6,5,4]  R2109     3.4669709205627441e-01
    z[6,5,4]  R2110     -1.7271824181079865e-01
    z[6,5,4]  R2111     3.9200261235237122e-02
    z[6,5,4]  R2112     9.2002548277378082e-02
    z[6,5,4]  R2113     -1.8937504291534424e-01
    z[6,5,4]  R2114     -1.4360065758228302e-01
    z[6,5,4]  R2115     -2.8094735741615295e-01
    z[6,5,4]  R2116     -2.1369270980358124e-02
    z[6,5,4]  R2117     3.4329418092966080e-02
    z[6,5,4]  R2118     -6.6291856765747070e-01
    z[6,5,4]  R2119     -4.8803728818893433e-01
    z[6,5,4]  R2120     -1.5790884196758270e-01
    z[6,5,4]  R2121     -5.5078315734863281e-01
    z[6,5,4]  R2122     -8.3766520023345947e-02
    z[6,5,4]  R2123     -2.1506768465042114e-01
    z[6,5,4]  R2124     2.0711828768253326e-01
    z[6,5,4]  R2125     -3.0013337731361389e-02
    z[6,5,4]  R2126     2.7905574440956116e-01
    z[6,5,4]  R2127     -4.8334106802940369e-02
    z[6,5,4]  R2128     -3.0210144817829132e-02
    z[6,5,4]  R2129     5.2105122804641724e-01
    z[6,5,4]  R2130     -1.3227945193648338e-02
    z[6,5,4]  R2131     2.3158590495586395e-01
    z[6,5,4]  R2132     2.3669071495532990e-01
    z[6,5,4]  R2133     4.9811866134405136e-02
    z[6,5,4]  R2134     1.8622530996799469e-01
    z[6,5,4]  R2135     2.2148312628269196e-01
    z[6,5,4]  R2136     3.5426761955022812e-02
    z[6,5,4]  R2137     -2.9519531130790710e-01
    z[6,5,4]  R2138     4.0074518322944641e-01
    z[6,5,4]  R2139     -2.4200105667114258e-01
    z[6,5,4]  R2140     1.2927709519863129e-01
    z[6,5,4]  R2141     2.2059883177280426e-01
    z[6,5,4]  R2142     2.1980078890919685e-02
    z[6,5,4]  R2143     1.5698119997978210e-01
    z[6,5,4]  R2144     -7.6411046087741852e-02
    z[6,5,4]  R2145     -1.6664180159568787e-01
    z[6,5,4]  R2146     -3.8733837008476257e-01
    z[6,5,4]  R2147     -7.0992313325405121e-02
    z[6,5,4]  R2148     3.9768660068511963e-01
    z[6,5,4]  R2149     -1.9679825007915497e-01
    z[6,5,4]  R2150     -0.302804559469223
    z[6,5,4]  R2151     -3.0368554592132568e-01
    z[6,5,4]  R2152     1.0551684349775314e-01
    z[6,5,4]  R2153     -1.9355788826942444e-02
    z[6,5,4]  R2154     6.2445417046546936e-02
    z[6,5,4]  R2155     -1.5688581764698029e-01
    z[6,5,4]  R2156     -1.8737266957759857e-01
    z[6,5,4]  R2157     1.3259534537792206e-01
    z[6,5,4]  R2158     -1.9866687059402466e-01
    z[6,5,4]  R2159     -3.0559748411178589e-01
    z[6,5,4]  R2160     1.3698628544807434e-01
    z[6,5,4]  R2161     -5.0602819770574570e-02
    z[6,5,4]  R2162     -1.5582096576690674e-01
    z[6,5,4]  R2163     -4.6497333049774170e-01
    z[6,5,4]  R2164     6.6649354994297028e-02
    z[6,5,4]  R2165     1.2416181713342667e-01
    z[6,5,4]  R2166     3.8874413818120956e-02
    z[6,5,4]  R2167     1.6988384723663330e-01
    z[6,5,4]  R2168     -6.0564088821411133e-01
    z[6,5,4]  R2169     5.5132603645324707e-01
    z[6,5,4]  R2170     -6.8614810705184937e-02
    z[6,5,4]  R2171     -0.664197564125061
    z[6,5,4]  R2172     -4.2081409692764282e-01
    z[6,5,4]  R2173     -1.2498825043439865e-01
    z[6,5,4]  R2174     1.0058642923831940e-01
    z[6,5,4]  R2175     4.0197573602199554e-02
    z[6,5,4]  R2176     8.1931173801422119e-02
    z[6,5,4]  R2177     4.4640928506851196e-02
    z[6,5,4]  R2178     -1.0576204210519791e-01
    z[6,5,4]  R2179     6.1329182237386703e-02
    z[6,5,4]  R2180     6.8140506744384766e-02
    z[6,5,4]  R2181     1.2142547965049744e-01
    z[6,5,4]  R2182     -1.1520221084356308e-01
    z[6,5,4]  R2183     -1.8276037275791168e-01
    z[6,5,4]  R2184     2.3541533946990967e-01
    z[6,5,4]  R2185     2.3986333608627319e-01
    z[6,5,4]  R2186     -1.1049579083919525e-01
    z[6,5,4]  R2187     1.5271799638867378e-02
    z[6,5,4]  R2188     -2.7204152941703796e-01
    z[6,5,4]  R2189     1.8960656225681305e-01
    z[6,5,4]  R2190     2.0966078341007233e-01
    z[6,5,4]  R2191     -4.7962281107902527e-01
    z[6,5,4]  R2192     -1.6468434035778046e-01
    z[6,5,4]  R2193     7.1353238821029663e-01
    z[6,5,4]  R2194     3.5656622052192688e-01
    z[6,5,4]  R2195     2.0278191193938255e-02
    z[6,5,4]  R2196     -2.1379841864109039e-01
    z[6,5,4]  R2197     1.2891350686550140e-01
    z[6,5,4]  R2198     -5.8095979690551758e-01
    z[6,5,4]  R2199     3.6111617088317871e-01
    z[6,5,4]  R2200     -4.2486825585365295e-01
    z[6,5,4]  R2201     -1.2635989487171173e-01
    z[6,5,4]  R2202     2.6446551084518433e-01
    z[6,5,4]  R2203     1.8629802763462067e-01
    z[6,5,4]  R2204     8.6344647407531738e-01
    z[6,5,4]  R2205     5.4700754582881927e-02
    z[6,5,4]  R2206     4.2301544547080994e-01
    z[6,5,4]  R2207     -2.1201588213443756e-01
    z[6,5,4]  R2208     3.5059813410043716e-02
    z[6,5,4]  R2209     5.1355826854705811e-01
    z[6,5,4]  R2210     -6.5954226255416870e-01
    z[6,5,4]  R2211     -0.523227334022522
    z[6,5,4]  R2212     -6.3495433330535889e-01
    z[6,5,4]  R2213     -2.1799956262111664e-01
    z[6,5,4]  R2214     -2.0397461950778961e-01
    z[6,5,4]  R2215     3.1452763080596924e-01
    z[6,5,4]  R2216     9.4894334673881531e-02
    z[6,5,4]  R2217     6.2800779938697815e-02
    z[6,5,4]  R2218     4.9770158529281616e-01
    z[6,5,4]  R2219     -0.483572393655777
    z[6,5,4]  R2220     -2.8351143002510071e-01
    z[6,5,4]  R2221     -5.1582843065261841e-01
    z[6,5,4]  R2222     -0.463644415140152
    z[6,5,4]  R2223     -6.7330557107925415e-01
    z[6,5,4]  R2224     -0.00819708127528429
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2091     -1
    z[6,5,5]  R2092     1
    z[6,5,5]  R2095     5.0448134541511536e-02
    z[6,5,5]  R2096     3.5628405213356018e-01
    z[6,5,5]  R2097     4.9841940402984619e-01
    z[6,5,5]  R2098     2.3097988963127136e-01
    z[6,5,5]  R2099     3.3193412423133850e-01
    z[6,5,5]  R2100     -9.6335709095001221e-02
    z[6,5,5]  R2101     1.0548584163188934e-02
    z[6,5,5]  R2102     -4.0202800184488297e-02
    z[6,5,5]  R2103     0.355111688375473
    z[6,5,5]  R2104     -1.7216829583048820e-02
    z[6,5,5]  R2105     3.4412688016891479e-01
    z[6,5,5]  R2106     5.2093285322189331e-01
    z[6,5,5]  R2107     -1.3080455362796783e-01
    z[6,5,5]  R2108     -1.1704389750957489e-01
    z[6,5,5]  R2109     1.8582293391227722e-01
    z[6,5,5]  R2110     -1.4288491010665894e-01
    z[6,5,5]  R2111     1.0768998414278030e-01
    z[6,5,5]  R2112     -2.9755065217614174e-02
    z[6,5,5]  R2113     1.2650847434997559e-01
    z[6,5,5]  R2114     6.8607471883296967e-02
    z[6,5,5]  R2115     3.4096702933311462e-01
    z[6,5,5]  R2116     2.5523445010185242e-01
    z[6,5,5]  R2117     -2.1300630643963814e-02
    z[6,5,5]  R2118     4.8581507802009583e-01
    z[6,5,5]  R2119     5.2268964052200317e-01
    z[6,5,5]  R2120     -1.1703015118837357e-01
    z[6,5,5]  R2121     4.3361055850982666e-01
    z[6,5,5]  R2122     -4.6812698245048523e-01
    z[6,5,5]  R2123     1.3619804382324219e-01
    z[6,5,5]  R2124     -2.6303318142890930e-01
    z[6,5,5]  R2125     3.7050571292638779e-02
    z[6,5,5]  R2126     -1.2478940188884735e-01
    z[6,5,5]  R2127     8.6288809776306152e-02
    z[6,5,5]  R2128     -1.6528807580471039e-01
    z[6,5,5]  R2129     3.5488995909690857e-01
    z[6,5,5]  R2130     1.9388712942600250e-01
    z[6,5,5]  R2131     -9.8234914243221283e-02
    z[6,5,5]  R2132     6.5929156541824341e-01
    z[6,5,5]  R2133     -1.6213320195674896e-01
    z[6,5,5]  R2134     3.0738005042076111e-01
    z[6,5,5]  R2135     3.4320649504661560e-01
    z[6,5,5]  R2136     -1.9283334910869598e-01
    z[6,5,5]  R2137     6.1310482025146484e-01
    z[6,5,5]  R2138     2.9591289162635803e-01
    z[6,5,5]  R2139     -1.7603531479835510e-01
    z[6,5,5]  R2140     8.6186133325099945e-02
    z[6,5,5]  R2141     2.8385239839553833e-01
    z[6,5,5]  R2142     2.4412062764167786e-01
    z[6,5,5]  R2143     5.2332830429077148e-01
    z[6,5,5]  R2144     4.1580680012702942e-01
    z[6,5,5]  R2145     -1.2333630770444870e-01
    z[6,5,5]  R2146     -0.0711502805352211
    z[6,5,5]  R2147     4.6585026383399963e-01
    z[6,5,5]  R2148     3.6016803979873657e-01
    z[6,5,5]  R2149     3.2151695340871811e-02
    z[6,5,5]  R2150     -4.0721049904823303e-01
    z[6,5,5]  R2151     1.1348453909158707e-01
    z[6,5,5]  R2152     -3.0042484402656555e-01
    z[6,5,5]  R2153     -9.7968660295009613e-02
    z[6,5,5]  R2154     -2.2801715135574341e-01
    z[6,5,5]  R2155     3.3695498108863831e-01
    z[6,5,5]  R2156     -1.9032275676727295e-01
    z[6,5,5]  R2157     2.3500597476959229e-01
    z[6,5,5]  R2158     0.0966220423579216
    z[6,5,5]  R2159     6.5530523657798767e-02
    z[6,5,5]  R2160     4.1757243871688843e-01
    z[6,5,5]  R2161     3.0980497598648071e-01
    z[6,5,5]  R2162     3.6398828029632568e-01
    z[6,5,5]  R2163     3.1032985448837280e-01
    z[6,5,5]  R2164     4.4034352898597717e-01
    z[6,5,5]  R2165     2.8430068492889404e-01
    z[6,5,5]  R2166     2.5482922792434692e-01
    z[6,5,5]  R2167     -1.6160987317562103e-01
    z[6,5,5]  R2168     2.4246735870838165e-01
    z[6,5,5]  R2169     -1.6973756253719330e-01
    z[6,5,5]  R2170     3.9245158433914185e-01
    z[6,5,5]  R2171     -7.2402499616146088e-02
    z[6,5,5]  R2172     -2.5813108682632446e-01
    z[6,5,5]  R2173     -2.4999319016933441e-01
    z[6,5,5]  R2174     -1.6648904979228973e-01
    z[6,5,5]  R2175     -3.2943961024284363e-01
    z[6,5,5]  R2176     -3.5980053246021271e-02
    z[6,5,5]  R2177     -3.1049215793609619e-01
    z[6,5,5]  R2178     2.8177076578140259e-01
    z[6,5,5]  R2179     -1.1477879434823990e-01
    z[6,5,5]  R2180     2.0424258708953857e-01
    z[6,5,5]  R2181     6.9125302135944366e-02
    z[6,5,5]  R2182     -7.8146345913410187e-02
    z[6,5,5]  R2183     -3.4167268872261047e-01
    z[6,5,5]  R2184     -3.8538447022438049e-01
    z[6,5,5]  R2185     -0.0593063160777092
    z[6,5,5]  R2186     -1.0239279270172119e-01
    z[6,5,5]  R2187     1.3108867406845093e-01
    z[6,5,5]  R2188     -2.9137039557099342e-02
    z[6,5,5]  R2189     4.7710424661636353e-01
    z[6,5,5]  R2190     6.1132764816284180e-01
    z[6,5,5]  R2191     -2.5607712566852570e-02
    z[6,5,5]  R2192     -1.0598448663949966e-01
    z[6,5,5]  R2193     0.0591808557510376
    z[6,5,5]  R2194     -1.3488078117370605e-01
    z[6,5,5]  R2195     2.9261562228202820e-01
    z[6,5,5]  R2196     2.7521508932113647e-01
    z[6,5,5]  R2197     -6.4297604560852051e-01
    z[6,5,5]  R2198     2.6581525802612305e-01
    z[6,5,5]  R2199     -7.7289767563343048e-02
    z[6,5,5]  R2200     -0.688133716583252
    z[6,5,5]  R2201     -4.5649823546409607e-01
    z[6,5,5]  R2202     -3.7620106339454651e-01
    z[6,5,5]  R2203     -4.7036531567573547e-01
    z[6,5,5]  R2204     -2.5837129354476929e-01
    z[6,5,5]  R2205     1.5638881921768188e-01
    z[6,5,5]  R2206     7.5854189693927765e-02
    z[6,5,5]  R2207     -2.7757662534713745e-01
    z[6,5,5]  R2208     -4.5461425185203552e-01
    z[6,5,5]  R2209     -3.6846312880516052e-01
    z[6,5,5]  R2210     -4.2448961175978184e-03
    z[6,5,5]  R2211     4.9633193761110306e-02
    z[6,5,5]  R2212     -2.2574605047702789e-01
    z[6,5,5]  R2213     -6.1993849277496338e-01
    z[6,5,5]  R2214     -0.504638671875
    z[6,5,5]  R2215     2.2373767197132111e-01
    z[6,5,5]  R2216     2.8344575315713882e-02
    z[6,5,5]  R2217     -2.1390955150127411e-01
    z[6,5,5]  R2218     2.4122843146324158e-01
    z[6,5,5]  R2219     -0.284828782081604
    z[6,5,5]  R2220     -4.4182983040809631e-01
    z[6,5,5]  R2221     -1.4362284541130066e-01
    z[6,5,5]  R2222     -6.5854269266128540e-01
    z[6,5,5]  R2223     -3.1300477683544159e-02
    z[6,5,5]  R2224     3.6749291419982910e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2093     -1
    z[6,5,6]  R2094     1
    z[6,5,6]  R2095     -3.0224621295928955e-02
    z[6,5,6]  R2096     -3.0544428154826164e-02
    z[6,5,6]  R2097     -1.0236737877130508e-01
    z[6,5,6]  R2098     -1.8589726090431213e-01
    z[6,5,6]  R2099     2.1918751299381256e-03
    z[6,5,6]  R2100     0.079471655189991
    z[6,5,6]  R2101     1.1661176383495331e-01
    z[6,5,6]  R2102     -4.5812937617301941e-01
    z[6,5,6]  R2103     -9.5765674486756325e-03
    z[6,5,6]  R2104     1.1679705977439880e-01
    z[6,5,6]  R2105     -1.1486873030662537e-01
    z[6,5,6]  R2106     -4.6692779660224915e-01
    z[6,5,6]  R2107     1.4410948380827904e-02
    z[6,5,6]  R2108     -2.3125639557838440e-01
    z[6,5,6]  R2109     -2.1750238537788391e-01
    z[6,5,6]  R2110     3.6757946014404297e-01
    z[6,5,6]  R2111     1.0941742360591888e-01
    z[6,5,6]  R2112     2.4398863315582275e-02
    z[6,5,6]  R2113     0.0702752098441124
    z[6,5,6]  R2114     -2.9970180243253708e-02
    z[6,5,6]  R2115     1.3765922188758850e-01
    z[6,5,6]  R2116     -3.8214033842086792e-01
    z[6,5,6]  R2117     -2.1635919809341431e-01
    z[6,5,6]  R2118     1.9490335881710052e-01
    z[6,5,6]  R2119     -2.4053165316581726e-01
    z[6,5,6]  R2120     3.0572479963302612e-01
    z[6,5,6]  R2121     -1.2226716615259647e-02
    z[6,5,6]  R2122     -1.4560225419700146e-02
    z[6,5,6]  R2123     4.7664329409599304e-01
    z[6,5,6]  R2124     4.6030825376510620e-01
    z[6,5,6]  R2125     -2.3105631768703461e-01
    z[6,5,6]  R2126     -4.4470822811126709e-01
    z[6,5,6]  R2127     1.3618775643408298e-02
    z[6,5,6]  R2128     -0.049640953540802
    z[6,5,6]  R2129     -0.259581595659256
    z[6,5,6]  R2130     -3.6433029174804688e-01
    z[6,5,6]  R2131     2.9331985116004944e-01
    z[6,5,6]  R2132     1.3550363481044769e-01
    z[6,5,6]  R2133     1.5716609358787537e-01
    z[6,5,6]  R2134     0.46355140209198
    z[6,5,6]  R2135     2.0093612372875214e-02
    z[6,5,6]  R2136     1.1167913675308228e-02
    z[6,5,6]  R2137     6.5813146531581879e-02
    z[6,5,6]  R2138     1.8022309243679047e-01
    z[6,5,6]  R2139     9.1388203203678131e-02
    z[6,5,6]  R2140     5.4702490568161011e-01
    z[6,5,6]  R2141     1.7998608946800232e-01
    z[6,5,6]  R2142     5.0963789224624634e-01
    z[6,5,6]  R2143     1.6429116949439049e-02
    z[6,5,6]  R2144     -2.5223836302757263e-01
    z[6,5,6]  R2145     3.8169443607330322e-01
    z[6,5,6]  R2146     -8.0177947878837585e-02
    z[6,5,6]  R2147     0.0874348059296608
    z[6,5,6]  R2148     1.4457820355892181e-01
    z[6,5,6]  R2149     3.1224694848060608e-01
    z[6,5,6]  R2150     2.7112990617752075e-01
    z[6,5,6]  R2151     2.1874293684959412e-01
    z[6,5,6]  R2152     -2.8557786345481873e-01
    z[6,5,6]  R2153     -1.9834528863430023e-01
    z[6,5,6]  R2154     -5.3242433071136475e-01
    z[6,5,6]  R2155     3.0272516608238220e-01
    z[6,5,6]  R2156     -1.3332915306091309e-01
    z[6,5,6]  R2157     2.7723437547683716e-01
    z[6,5,6]  R2158     5.3015863895416260e-01
    z[6,5,6]  R2159     6.3868030905723572e-02
    z[6,5,6]  R2160     9.1345183551311493e-02
    z[6,5,6]  R2161     -6.0760229825973511e-01
    z[6,5,6]  R2162     -2.4147087242454290e-04
    z[6,5,6]  R2163     -5.2079045772552490e-01
    z[6,5,6]  R2164     -1.7207440733909607e-01
    z[6,5,6]  R2165     -5.1508295536041260e-01
    z[6,5,6]  R2166     3.1199935078620911e-01
    z[6,5,6]  R2167     3.9095902442932129e-01
    z[6,5,6]  R2168     -2.7082201838493347e-01
    z[6,5,6]  R2169     -2.7292063832283020e-01
    z[6,5,6]  R2170     -1.0957321152091026e-02
    z[6,5,6]  R2171     -2.5969070196151733e-01
    z[6,5,6]  R2172     -1.3700519502162933e-01
    z[6,5,6]  R2173     -4.0275490283966064e-01
    z[6,5,6]  R2174     -4.9255305528640747e-01
    z[6,5,6]  R2175     -2.0176558196544647e-01
    z[6,5,6]  R2176     -0.392668753862381
    z[6,5,6]  R2177     2.4300108850002289e-01
    z[6,5,6]  R2178     -0.00647188164293766
    z[6,5,6]  R2179     5.4791235923767090e-01
    z[6,5,6]  R2180     0.568831205368042
    z[6,5,6]  R2181     -2.7207210659980774e-01
    z[6,5,6]  R2182     4.0409117937088013e-01
    z[6,5,6]  R2183     -4.2171877622604370e-01
    z[6,5,6]  R2184     -1.4311835169792175e-02
    z[6,5,6]  R2185     -2.1957848966121674e-01
    z[6,5,6]  R2186     2.2452560067176819e-01
    z[6,5,6]  R2187     4.5085042715072632e-02
    z[6,5,6]  R2188     -2.5616922974586487e-01
    z[6,5,6]  R2189     -2.3681713640689850e-01
    z[6,5,6]  R2190     1.5807650983333588e-01
    z[6,5,6]  R2191     3.0263975262641907e-01
    z[6,5,6]  R2192     -8.2975822687149048e-01
    z[6,5,6]  R2193     3.3224666118621826e-01
    z[6,5,6]  R2194     3.8006670773029327e-02
    z[6,5,6]  R2195     -0.523121178150177
    z[6,5,6]  R2196     5.0070118159055710e-02
    z[6,5,6]  R2197     -2.8390547633171082e-01
    z[6,5,6]  R2198     -1.9579039886593819e-02
    z[6,5,6]  R2199     -3.3382558822631836e-01
    z[6,5,6]  R2200     3.9094928652048111e-02
    z[6,5,6]  R2201     -3.0160054564476013e-01
    z[6,5,6]  R2202     2.5230368971824646e-01
    z[6,5,6]  R2203     0.0304279662668705
    z[6,5,6]  R2204     1.5494583547115326e-01
    z[6,5,6]  R2205     -2.0397663116455078e-01
    z[6,5,6]  R2206     4.6544083952903748e-01
    z[6,5,6]  R2207     0.469174861907959
    z[6,5,6]  R2208     9.3000024557113647e-02
    z[6,5,6]  R2209     8.3460107445716858e-02
    z[6,5,6]  R2210     -4.2939484119415283e-01
    z[6,5,6]  R2211     -2.0302060246467590e-01
    z[6,5,6]  R2212     4.7779113054275513e-01
    z[6,5,6]  R2213     -3.1680914759635925e-01
    z[6,5,6]  R2214     2.6725429296493530e-01
    z[6,5,6]  R2215     2.8804758191108704e-01
    z[6,5,6]  R2216     1.3155448436737061e-01
    z[6,5,6]  R2217     3.9790770411491394e-01
    z[6,5,6]  R2218     4.2352247983217239e-02
    z[6,5,6]  R2219     4.9535080790519714e-01
    z[6,5,6]  R2220     -1.9908405840396881e-01
    z[6,5,6]  R2221     -4.7892707586288452e-01
    z[6,5,6]  R2222     -1.9740824401378632e-01
    z[6,5,6]  R2223     -3.8281716406345367e-02
    z[6,5,6]  R2224     -3.3507876098155975e-02
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2225     -1
    z[6,7,0]  R2226     1
    z[6,7,0]  R2239     -9.0638458728790283e-01
    z[6,7,0]  R2240     -8.2799595594406128e-01
    z[6,7,0]  R2241     -7.8493207693099976e-01
    z[6,7,0]  R2242     -7.0772647857666016e-01
    z[6,7,0]  R2243     -0.819678008556366
    z[6,7,0]  R2244     -6.6300272941589355e-01
    z[6,7,0]  R2245     -8.1264919042587280e-01
    z[6,7,0]  R2246     -6.8940824270248413e-01
    z[6,7,0]  R2247     -8.8037103414535522e-01
    z[6,7,0]  R2248     2.9375693202018738e-01
    z[6,7,0]  R2249     -3.8623297587037086e-04
    z[6,7,0]  R2250     4.9018543958663940e-01
    z[6,7,0]  R2251     4.9586838483810425e-01
    z[6,7,0]  R2252     4.3103596568107605e-01
    z[6,7,0]  R2253     2.0347057282924652e-01
    z[6,7,0]  R2254     3.9923486113548279e-01
    z[6,7,0]  R2255     0.421084463596344
    z[6,7,0]  R2256     2.6942405104637146e-01
    z[6,7,0]  R2257     3.8349777460098267e-01
    z[6,7,0]  R2258     3.8672599196434021e-01
    z[6,7,0]  R2259     0.599850058555603
    z[6,7,0]  R2260     3.9805805683135986e-01
    z[6,7,0]  R2261     9.7217820584774017e-02
    z[6,7,0]  R2262     3.7836232781410217e-01
    z[6,7,0]  R2263     2.1848320960998535e-01
    z[6,7,0]  R2264     4.0968227386474609e-01
    z[6,7,0]  R2265     5.7834142446517944e-01
    z[6,7,0]  R2266     -4.1519635915756226e-01
    z[6,7,0]  R2267     -2.0829349756240845e-01
    z[6,7,0]  R2268     1.6713143885135651e-01
    z[6,7,0]  R2269     0.291344553232193
    z[6,7,0]  R2270     2.0175081491470337e-01
    z[6,7,0]  R2271     -1.8293541669845581e-01
    z[6,7,0]  R2272     -1.5737058222293854e-01
    z[6,7,0]  R2273     -7.6309749856591225e-03
    z[6,7,0]  R2274     -3.4955191612243652e-01
    z[6,7,0]  R2275     -4.1043874621391296e-01
    z[6,7,0]  R2276     1.1732964962720871e-01
    z[6,7,0]  R2277     -4.1289508342742920e-01
    z[6,7,0]  R2278     6.7198120057582855e-02
    z[6,7,0]  R2279     1.4178267121315002e-01
    z[6,7,0]  R2280     -3.6966481804847717e-01
    z[6,7,0]  R2281     4.9518829584121704e-01
    z[6,7,0]  R2282     -2.0473115146160126e-01
    z[6,7,0]  R2283     -8.2797199487686157e-01
    z[6,7,0]  R2284     0.617081344127655
    z[6,7,0]  R2285     5.0851190090179443e-01
    z[6,7,0]  R2286     3.9375400543212891e-01
    z[6,7,0]  R2287     0.809958279132843
    z[6,7,0]  R2288     8.5605132579803467e-01
    z[6,7,0]  R2289     -2.9784919694066048e-02
    z[6,7,0]  R2290     -0.286978155374527
    z[6,7,0]  R2291     1.6640554368495941e-01
    z[6,7,0]  R2292     7.2376525402069092e-01
    z[6,7,0]  R2293     -1.7412005364894867e-01
    z[6,7,0]  R2294     8.0571383237838745e-02
    z[6,7,0]  R2295     8.3700728416442871e-01
    z[6,7,0]  R2296     1.3343612849712372e-01
    z[6,7,0]  R2297     -6.4536012709140778e-02
    z[6,7,0]  R2298     4.4132387638092041e-01
    z[6,7,0]  R2299     6.9306713342666626e-01
    z[6,7,0]  R2300     -2.6543736457824707e-01
    z[6,7,0]  R2301     4.8704367876052856e-01
    z[6,7,0]  R2302     3.5728746652603149e-01
    z[6,7,0]  R2303     2.4972066283226013e-01
    z[6,7,0]  R2304     2.2820445895195007e-01
    z[6,7,0]  R2305     4.4021755456924438e-01
    z[6,7,0]  R2306     8.7229609489440918e-01
    z[6,7,0]  R2307     1.6437853872776031e-01
    z[6,7,0]  R2308     4.1851267218589783e-01
    z[6,7,0]  R2309     -9.3097686767578125e-02
    z[6,7,0]  R2310     0.0915379747748375
    z[6,7,0]  R2311     -0.0588078498840332
    z[6,7,0]  R2312     4.6570891141891479e-01
    z[6,7,0]  R2313     -3.0314895510673523e-01
    z[6,7,0]  R2314     3.5545620322227478e-01
    z[6,7,0]  R2315     -2.0369479060173035e-01
    z[6,7,0]  R2316     -1.8442565202713013e-01
    z[6,7,0]  R2317     4.4914808869361877e-01
    z[6,7,0]  R2318     5.8731153607368469e-02
    z[6,7,0]  R2319     0.0049970424734056
    z[6,7,0]  R2320     -3.4934845566749573e-01
    z[6,7,0]  R2321     -7.5006228685379028e-01
    z[6,7,0]  R2322     4.0946078300476074e-01
    z[6,7,0]  R2323     -1.1233063042163849e-01
    z[6,7,0]  R2324     7.2808766365051270e-01
    z[6,7,0]  R2325     -2.4780279025435448e-02
    z[6,7,0]  R2326     -3.3136874437332153e-02
    z[6,7,0]  R2327     3.3650982379913330e-01
    z[6,7,0]  R2328     3.7405374646186829e-01
    z[6,7,0]  R2329     1.2360244244337082e-01
    z[6,7,0]  R2330     0.0306143369525671
    z[6,7,0]  R2331     5.4720234870910645e-01
    z[6,7,0]  R2332     -2.0705135166645050e-01
    z[6,7,0]  R2333     1.3450443744659424e-01
    z[6,7,0]  R2334     -0.511566698551178
    z[6,7,0]  R2335     1.0518323630094528e-01
    z[6,7,0]  R2336     -2.5864261388778687e-01
    z[6,7,0]  R2337     1.4801529049873352e-01
    z[6,7,0]  R2338     3.2486591488122940e-02
    z[6,7,0]  R2339     -3.0512461066246033e-01
    z[6,7,0]  R2340     7.9080504179000854e-01
    z[6,7,0]  R2341     1.4882269501686096e-01
    z[6,7,0]  R2342     -1.1800559610128403e-01
    z[6,7,0]  R2343     6.5329587459564209e-01
    z[6,7,0]  R2344     -3.3021083474159241e-01
    z[6,7,0]  R2345     7.9478567838668823e-01
    z[6,7,0]  R2346     5.5110937356948853e-01
    z[6,7,0]  R2347     4.3531551957130432e-01
    z[6,7,0]  R2348     3.7732085585594177e-01
    z[6,7,0]  R2349     -1.6677637398242950e-01
    z[6,7,0]  R2350     2.7080655097961426e-01
    z[6,7,0]  R2351     -0.333111971616745
    z[6,7,0]  R2352     -1.1851393431425095e-01
    z[6,7,0]  R2353     -4.5830646157264709e-01
    z[6,7,0]  R2354     4.4970255345106125e-02
    z[6,7,0]  R2355     -1.8352389335632324e-01
    z[6,7,0]  R2356     5.0772237777709961e-01
    z[6,7,0]  R2357     -6.1997871845960617e-02
    z[6,7,0]  R2358     -4.8145502805709839e-01
    z[6,7,0]  R2359     8.8104113936424255e-02
    z[6,7,0]  R2360     -4.3010520935058594e-01
    z[6,7,0]  R2361     4.6591836214065552e-01
    z[6,7,0]  R2362     6.7357790470123291e-01
    z[6,7,0]  R2363     -7.2544604539871216e-02
    z[6,7,0]  R2364     3.9823567867279053e-01
    z[6,7,0]  R2365     3.9311617612838745e-01
    z[6,7,0]  R2366     -2.2881540656089783e-01
    z[6,7,0]  R2367     -4.2141190171241760e-01
    z[6,7,0]  R2368     4.0351420640945435e-01
    z[6,7,0]  R2369     -8.3761967718601227e-02
    z[6,7,0]  R2370     -7.7193096280097961e-02
    z[6,7,0]  R2371     1.5632240474224091e-01
    z[6,7,0]  R2372     6.7632240056991577e-01
    z[6,7,0]  R2373     -4.5164099335670471e-01
    z[6,7,0]  R2374     -4.4391790032386780e-01
    z[6,7,0]  R2375     6.6559958457946777e-01
    z[6,7,0]  R2376     4.1964778304100037e-01
    z[6,7,0]  R2377     2.3575158417224884e-01
    z[6,7,0]  R2378     0.111433245241642
    z[6,7,0]  R2379     -4.4875025749206543e-01
    z[6,7,0]  R2380     -3.7401786446571350e-01
    z[6,7,0]  R2381     4.4309237599372864e-01
    z[6,7,0]  R2382     -5.9246625751256943e-02
    z[6,7,0]  R2383     7.8633022308349609e-01
    z[6,7,0]  R2384     -1.7872239649295807e-01
    z[6,7,0]  R2385     0.093810074031353
    z[6,7,0]  R2386     4.2910650372505188e-01
    z[6,7,0]  R2387     3.7557142972946167e-01
    z[6,7,0]  R2388     3.7017074227333069e-01
    z[6,7,0]  R2389     2.1927321329712868e-02
    z[6,7,0]  R2390     3.6122921854257584e-02
    z[6,7,0]  R2391     -4.5800682902336121e-01
    z[6,7,0]  R2392     5.4896444082260132e-01
    z[6,7,0]  R2393     7.0793789625167847e-01
    z[6,7,0]  R2394     0.505699872970581
    z[6,7,0]  R2395     3.4056031703948975e-01
    z[6,7,0]  R2396     2.2189356386661530e-01
    z[6,7,0]  R2397     2.6149040460586548e-01
    z[6,7,0]  R2398     1.1316373199224472e-01
    z[6,7,0]  R2399     -1.7203774303197861e-02
    z[6,7,0]  R2400     7.8943118453025818e-02
    z[6,7,0]  R2401     -3.1039005517959595e-01
    z[6,7,0]  R2402     2.4173296988010406e-02
    z[6,7,0]  R2403     -6.1115708202123642e-02
    z[6,7,0]  R2404     -4.9999356269836426e-01
    z[6,7,0]  R2405     -2.6486939191818237e-01
    z[6,7,0]  R2406     -5.6621241569519043e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2227     -1
    z[6,7,1]  R2228     1
    z[6,7,1]  R2239     2.3567005991935730e-01
    z[6,7,1]  R2240     -4.1897028684616089e-02
    z[6,7,1]  R2241     2.8792524710297585e-02
    z[6,7,1]  R2242     -1.2074025720357895e-01
    z[6,7,1]  R2243     -8.2762926816940308e-02
    z[6,7,1]  R2244     -1.4048515260219574e-01
    z[6,7,1]  R2245     4.6277213841676712e-02
    z[6,7,1]  R2246     -1.1682908982038498e-01
    z[6,7,1]  R2247     -1.0781950503587723e-01
    z[6,7,1]  R2248     -2.0093406736850739e-01
    z[6,7,1]  R2249     -8.9190477132797241e-01
    z[6,7,1]  R2250     -3.7189406156539917e-01
    z[6,7,1]  R2251     -4.8617777228355408e-01
    z[6,7,1]  R2252     -5.5693954229354858e-01
    z[6,7,1]  R2253     -6.9330793619155884e-01
    z[6,7,1]  R2254     -7.2400510311126709e-01
    z[6,7,1]  R2255     8.9146637916564941e-01
    z[6,7,1]  R2256     9.2655897140502930e-01
    z[6,7,1]  R2257     8.8261890411376953e-01
    z[6,7,1]  R2258     0.881799578666687
    z[6,7,1]  R2259     -5.0700485706329346e-01
    z[6,7,1]  R2260     -7.7167344093322754e-01
    z[6,7,1]  R2261     -8.0269873142242432e-01
    z[6,7,1]  R2262     -3.3003348112106323e-01
    z[6,7,1]  R2263     -3.3140763640403748e-01
    z[6,7,1]  R2264     -7.5931972265243530e-01
    z[6,7,1]  R2265     -1.2345468252897263e-01
    z[6,7,1]  R2266     -7.6918292045593262e-01
    z[6,7,1]  R2267     -0.752150297164917
    z[6,7,1]  R2268     -7.9434764385223389e-01
    z[6,7,1]  R2269     -9.1375911235809326e-01
    z[6,7,1]  R2270     -7.7818918228149414e-01
    z[6,7,1]  R2271     -9.4941031932830811e-01
    z[6,7,1]  R2272     -9.4771158695220947e-01
    z[6,7,1]  R2273     -6.0370171070098877e-01
    z[6,7,1]  R2274     -8.1486070156097412e-01
    z[6,7,1]  R2275     -7.2885221242904663e-01
    z[6,7,1]  R2276     -6.8084597587585449e-01
    z[6,7,1]  R2277     -7.7136713266372681e-01
    z[6,7,1]  R2278     -7.2400116920471191e-01
    z[6,7,1]  R2279     -0.770193874835968
    z[6,7,1]  R2280     -8.5195004940032959e-01
    z[6,7,1]  R2281     4.2647279798984528e-02
    z[6,7,1]  R2282     -8.0612915754318237e-01
    z[6,7,1]  R2283     -3.8849323987960815e-01
    z[6,7,1]  R2284     -3.4533193707466125e-01
    z[6,7,1]  R2285     -5.2539217472076416e-01
    z[6,7,1]  R2286     -3.1653749942779541e-01
    z[6,7,1]  R2287     -3.4983004443347454e-03
    z[6,7,1]  R2288     0.0690355971455574
    z[6,7,1]  R2289     -8.1956321001052856e-01
    z[6,7,1]  R2290     -5.9959208965301514e-01
    z[6,7,1]  R2291     -7.6063059270381927e-02
    z[6,7,1]  R2292     -2.0901305973529816e-01
    z[6,7,1]  R2293     -4.9557766318321228e-01
    z[6,7,1]  R2294     -5.0943940877914429e-01
    z[6,7,1]  R2295     -2.6115508750081062e-02
    z[6,7,1]  R2296     7.8820818662643433e-01
    z[6,7,1]  R2297     9.4797450304031372e-01
    z[6,7,1]  R2298     5.7311809062957764e-01
    z[6,7,1]  R2299     -9.0785082429647446e-03
    z[6,7,1]  R2300     -5.7964098453521729e-01
    z[6,7,1]  R2301     -4.8482900857925415e-01
    z[6,7,1]  R2302     -1.7932601273059845e-01
    z[6,7,1]  R2303     -3.6394849419593811e-01
    z[6,7,1]  R2304     -0.682121753692627
    z[6,7,1]  R2305     -7.4453867971897125e-02
    z[6,7,1]  R2306     6.0457970947027206e-02
    z[6,7,1]  R2307     -0.321254700422287
    z[6,7,1]  R2308     -1.4761339128017426e-01
    z[6,7,1]  R2309     -7.9079437255859375e-01
    z[6,7,1]  R2310     -8.0034458637237549e-01
    z[6,7,1]  R2311     -8.2423675060272217e-01
    z[6,7,1]  R2312     -5.2353560924530029e-02
    z[6,7,1]  R2313     -5.6139910221099854e-01
    z[6,7,1]  R2314     -1.7574384808540344e-01
    z[6,7,1]  R2315     -4.8669952154159546e-01
    z[6,7,1]  R2316     0.811751663684845
    z[6,7,1]  R2317     0.639335036277771
    z[6,7,1]  R2318     7.7055817842483521e-01
    z[6,7,1]  R2319     -9.2000114917755127e-01
    z[6,7,1]  R2320     -8.1789934635162354e-01
    z[6,7,1]  R2321     -5.2259933948516846e-01
    z[6,7,1]  R2322     -0.166182741522789
    z[6,7,1]  R2323     -0.468726247549057
    z[6,7,1]  R2324     -1.8806332349777222e-01
    z[6,7,1]  R2325     8.7126356363296509e-01
    z[6,7,1]  R2326     4.3835404515266418e-01
    z[6,7,1]  R2327     7.1538448333740234e-01
    z[6,7,1]  R2328     5.4896432161331177e-01
    z[6,7,1]  R2329     1.2836413085460663e-01
    z[6,7,1]  R2330     -7.6285108923912048e-02
    z[6,7,1]  R2331     -5.3504884243011475e-01
    z[6,7,1]  R2332     -2.1105191111564636e-01
    z[6,7,1]  R2333     5.5811733007431030e-01
    z[6,7,1]  R2334     -2.0206277072429657e-01
    z[6,7,1]  R2335     8.3387774229049683e-01
    z[6,7,1]  R2336     -8.2305364310741425e-02
    z[6,7,1]  R2337     7.9791676998138428e-01
    z[6,7,1]  R2338     0.586044430732727
    z[6,7,1]  R2339     -5.3130376338958740e-01
    z[6,7,1]  R2340     3.3108010888099670e-01
    z[6,7,1]  R2341     -7.8599143028259277e-01
    z[6,7,1]  R2342     -8.3646696805953979e-01
    z[6,7,1]  R2343     6.7285680770874023e-01
    z[6,7,1]  R2344     -7.8959834575653076e-01
    z[6,7,1]  R2345     2.3742099106311798e-01
    z[6,7,1]  R2346     2.6344174146652222e-01
    z[6,7,1]  R2347     -4.5459401607513428e-01
    z[6,7,1]  R2348     -4.6511086821556091e-01
    z[6,7,1]  R2349     -0.762222409248352
    z[6,7,1]  R2350     -1.6407574713230133e-01
    z[6,7,1]  R2351     -5.3735202550888062e-01
    z[6,7,1]  R2352     -4.3657287955284119e-01
    z[6,7,1]  R2353     -4.2445501685142517e-01
    z[6,7,1]  R2354     -8.2359558343887329e-01
    z[6,7,1]  R2355     -4.7783127427101135e-01
    z[6,7,1]  R2356     -4.5591521263122559e-01
    z[6,7,1]  R2357     -1.6740456223487854e-02
    z[6,7,1]  R2358     2.0488715171813965e-01
    z[6,7,1]  R2359     -2.7302113175392151e-01
    z[6,7,1]  R2360     -7.5260102748870850e-02
    z[6,7,1]  R2361     4.2384776473045349e-01
    z[6,7,1]  R2362     4.9414092302322388e-01
    z[6,7,1]  R2363     -4.0998184680938721e-01
    z[6,7,1]  R2364     6.5227466821670532e-01
    z[6,7,1]  R2365     3.4529119729995728e-01
    z[6,7,1]  R2366     -4.3794006109237671e-01
    z[6,7,1]  R2367     2.8829118609428406e-01
    z[6,7,1]  R2368     -4.0004888176918030e-01
    z[6,7,1]  R2369     -1.4097803831100464e-01
    z[6,7,1]  R2370     -7.5582391023635864e-01
    z[6,7,1]  R2371     -8.4233134984970093e-01
    z[6,7,1]  R2372     6.8047583103179932e-01
    z[6,7,1]  R2373     -0.270486056804657
    z[6,7,1]  R2374     -5.3289192914962769e-01
    z[6,7,1]  R2375     1.0219454765319824e-01
    z[6,7,1]  R2376     3.2792839407920837e-01
    z[6,7,1]  R2377     9.3890947103500366e-01
    z[6,7,1]  R2378     9.6040832996368408e-01
    z[6,7,1]  R2379     -4.1371452808380127e-01
    z[6,7,1]  R2380     6.7751012742519379e-02
    z[6,7,1]  R2381     -0.66004878282547
    z[6,7,1]  R2382     -5.4887789487838745e-01
    z[6,7,1]  R2383     -5.1548504829406738e-01
    z[6,7,1]  R2384     3.7859001755714417e-01
    z[6,7,1]  R2385     -3.9288067817687988e-01
    z[6,7,1]  R2386     -3.5894498229026794e-01
    z[6,7,1]  R2387     8.3690589666366577e-01
    z[6,7,1]  R2388     8.2600378990173340e-01
    z[6,7,1]  R2389     -3.0824273824691772e-01
    z[6,7,1]  R2390     4.1268173605203629e-02
    z[6,7,1]  R2391     -6.1525326967239380e-01
    z[6,7,1]  R2392     2.7501374483108521e-01
    z[6,7,1]  R2393     1.1398664861917496e-01
    z[6,7,1]  R2394     -4.1105547547340393e-01
    z[6,7,1]  R2395     9.1148459911346436e-01
    z[6,7,1]  R2396     9.2428731918334961e-01
    z[6,7,1]  R2397     9.2195343971252441e-01
    z[6,7,1]  R2398     9.0650641918182373e-01
    z[6,7,1]  R2399     -1.7797312140464783e-01
    z[6,7,1]  R2400     -0.44866743683815
    z[6,7,1]  R2401     9.2515224218368530e-01
    z[6,7,1]  R2402     6.3834863901138306e-01
    z[6,7,1]  R2403     5.8140450716018677e-01
    z[6,7,1]  R2404     7.2880762815475464e-01
    z[6,7,1]  R2405     5.9469151496887207e-01
    z[6,7,1]  R2406     0.667008638381958
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2229     -1
    z[6,7,2]  R2230     1
    z[6,7,2]  R2239     4.8219002783298492e-02
    z[6,7,2]  R2240     2.4617350101470947e-01
    z[6,7,2]  R2241     0.0839306190609932
    z[6,7,2]  R2242     2.1931204199790955e-01
    z[6,7,2]  R2243     -1.4509050548076630e-01
    z[6,7,2]  R2244     -1.1842354387044907e-01
    z[6,7,2]  R2245     -3.0637830495834351e-01
    z[6,7,2]  R2246     -2.6090177893638611e-01
    z[6,7,2]  R2247     -1.3556927442550659e-01
    z[6,7,2]  R2248     -1.7798444628715515e-01
    z[6,7,2]  R2249     -5.5900290608406067e-02
    z[6,7,2]  R2250     -2.9828870296478271e-01
    z[6,7,2]  R2251     -1.3427162542939186e-02
    z[6,7,2]  R2252     4.1312953829765320e-01
    z[6,7,2]  R2253     -3.4522205591201782e-01
    z[6,7,2]  R2254     0.289383202791214
    z[6,7,2]  R2255     1.4852622523903847e-02
    z[6,7,2]  R2256     2.1137434244155884e-01
    z[6,7,2]  R2257     6.5856881439685822e-02
    z[6,7,2]  R2258     2.1253588795661926e-01
    z[6,7,2]  R2259     1.0035727173089981e-01
    z[6,7,2]  R2260     1.6829672455787659e-01
    z[6,7,2]  R2261     -1.9416575133800507e-01
    z[6,7,2]  R2262     -1.8333847820758820e-01
    z[6,7,2]  R2263     -5.2161026000976562e-01
    z[6,7,2]  R2264     3.4443494677543640e-01
    z[6,7,2]  R2265     2.2141848504543304e-01
    z[6,7,2]  R2266     1.4933940954506397e-02
    z[6,7,2]  R2267     -1.5962953865528107e-01
    z[6,7,2]  R2268     3.8431543856859207e-02
    z[6,7,2]  R2269     0.095056913793087
    z[6,7,2]  R2270     -9.1186009347438812e-02
    z[6,7,2]  R2271     2.2850561141967773e-01
    z[6,7,2]  R2272     1.8350470066070557e-01
    z[6,7,2]  R2273     -1.0992185026407242e-01
    z[6,7,2]  R2274     -6.4968854188919067e-02
    z[6,7,2]  R2275     1.5266297757625580e-01
    z[6,7,2]  R2276     0.0628947913646698
    z[6,7,2]  R2277     -1.3236106932163239e-01
    z[6,7,2]  R2278     1.4494094066321850e-02
    z[6,7,2]  R2279     2.4858203530311584e-01
    z[6,7,2]  R2280     -9.9425628781318665e-02
    z[6,7,2]  R2281     -4.5960783958435059e-01
    z[6,7,2]  R2282     -1.3062451779842377e-01
    z[6,7,2]  R2283     2.0609753206372261e-02
    z[6,7,2]  R2284     -1.2111578881740570e-01
    z[6,7,2]  R2285     -5.5107390880584717e-01
    z[6,7,2]  R2286     -6.5184015035629272e-01
    z[6,7,2]  R2287     1.5165668725967407e-01
    z[6,7,2]  R2288     9.4467557966709137e-02
    z[6,7,2]  R2289     3.7212669849395752e-01
    z[6,7,2]  R2290     0.510319173336029
    z[6,7,2]  R2291     -7.9994976520538330e-01
    z[6,7,2]  R2292     -2.0820085704326630e-01
    z[6,7,2]  R2293     -2.5144013762474060e-01
    z[6,7,2]  R2294     -4.7872957587242126e-01
    z[6,7,2]  R2295     3.4862619638442993e-01
    z[6,7,2]  R2296     -4.0366011857986450e-01
    z[6,7,2]  R2297     -1.7312115430831909e-01
    z[6,7,2]  R2298     -3.5301384329795837e-01
    z[6,7,2]  R2299     -3.4765001386404037e-02
    z[6,7,2]  R2300     4.2130580544471741e-01
    z[6,7,2]  R2301     -5.7477647066116333e-01
    z[6,7,2]  R2302     -0.645080029964447
    z[6,7,2]  R2303     -5.4246175289154053e-01
    z[6,7,2]  R2304     -1.1096552014350891e-01
    z[6,7,2]  R2305     -2.7713960409164429e-01
    z[6,7,2]  R2306     1.6731685400009155e-01
    z[6,7,2]  R2307     -5.4264806210994720e-02
    z[6,7,2]  R2308     -2.9492408037185669e-01
    z[6,7,2]  R2309     -5.9931054711341858e-02
    z[6,7,2]  R2310     5.0907637923955917e-02
    z[6,7,2]  R2311     -5.9057138860225677e-02
    z[6,7,2]  R2312     1.0383627563714981e-01
    z[6,7,2]  R2313     -4.1855287551879883e-01
    z[6,7,2]  R2314     -2.0485353469848633e-01
    z[6,7,2]  R2315     1.7963831126689911e-01
    z[6,7,2]  R2316     -3.7469189614057541e-02
    z[6,7,2]  R2317     -2.6761874556541443e-01
    z[6,7,2]  R2318     -3.3364719152450562e-01
    z[6,7,2]  R2319     3.4020170569419861e-02
    z[6,7,2]  R2320     1.9581666216254234e-02
    z[6,7,2]  R2321     2.5441735982894897e-02
    z[6,7,2]  R2322     -0.199344664812088
    z[6,7,2]  R2323     4.2731454968452454e-01
    z[6,7,2]  R2324     2.1485167741775513e-01
    z[6,7,2]  R2325     -3.7014293670654297e-01
    z[6,7,2]  R2326     3.8449708372354507e-02
    z[6,7,2]  R2327     -2.8615200892090797e-02
    z[6,7,2]  R2328     -3.9972978830337524e-01
    z[6,7,2]  R2329     -3.6473503708839417e-01
    z[6,7,2]  R2330     -0.315572589635849
    z[6,7,2]  R2331     2.5939446687698364e-01
    z[6,7,2]  R2332     1.5178416669368744e-01
    z[6,7,2]  R2333     3.3390790224075317e-01
    z[6,7,2]  R2334     4.8268872499465942e-01
    z[6,7,2]  R2335     1.5913186967372894e-01
    z[6,7,2]  R2336     6.3994270563125610e-01
    z[6,7,2]  R2337     2.3718601465225220e-01
    z[6,7,2]  R2338     3.4481936693191528e-01
    z[6,7,2]  R2339     1.7182333767414093e-01
    z[6,7,2]  R2340     2.6018142700195312e-01
    z[6,7,2]  R2341     -4.2362990975379944e-01
    z[6,7,2]  R2342     -2.2558629512786865e-01
    z[6,7,2]  R2343     1.8069089949131012e-01
    z[6,7,2]  R2344     -1.9469912350177765e-01
    z[6,7,2]  R2345     5.2703386172652245e-03
    z[6,7,2]  R2346     -3.4479784965515137e-01
    z[6,7,2]  R2347     -8.1773988902568817e-02
    z[6,7,2]  R2348     2.2669050097465515e-01
    z[6,7,2]  R2349     2.6220592856407166e-01
    z[6,7,2]  R2350     -1.3925200700759888e-01
    z[6,7,2]  R2351     5.2966678142547607e-01
    z[6,7,2]  R2352     -3.4921181201934814e-01
    z[6,7,2]  R2353     1.3471728563308716e-01
    z[6,7,2]  R2354     -4.7267618775367737e-01
    z[6,7,2]  R2355     2.4360284209251404e-01
    z[6,7,2]  R2356     4.5246556401252747e-01
    z[6,7,2]  R2357     3.6115118861198425e-01
    z[6,7,2]  R2358     3.9397758245468140e-01
    z[6,7,2]  R2359     -2.2256558761000633e-02
    z[6,7,2]  R2360     0.428076833486557
    z[6,7,2]  R2361     2.8458023443818092e-03
    z[6,7,2]  R2362     2.1882055699825287e-01
    z[6,7,2]  R2363     1.9023905694484711e-01
    z[6,7,2]  R2364     1.5313657000660896e-02
    z[6,7,2]  R2365     -9.7747206687927246e-02
    z[6,7,2]  R2366     -3.2966170459985733e-02
    z[6,7,2]  R2367     3.1236311793327332e-01
    z[6,7,2]  R2368     -6.5187156200408936e-01
    z[6,7,2]  R2369     -5.4828889667987823e-02
    z[6,7,2]  R2370     1.0606251657009125e-01
    z[6,7,2]  R2371     -2.7343055605888367e-01
    z[6,7,2]  R2372     1.9612836185842752e-03
    z[6,7,2]  R2373     3.8312498945742846e-03
    z[6,7,2]  R2374     -1.1785271763801575e-01
    z[6,7,2]  R2375     -2.9135072231292725e-01
    z[6,7,2]  R2376     6.2200218439102173e-01
    z[6,7,2]  R2377     -1.9933420419692993e-01
    z[6,7,2]  R2378     -9.5623753964900970e-02
    z[6,7,2]  R2379     2.1981850266456604e-02
    z[6,7,2]  R2380     4.2391413450241089e-01
    z[6,7,2]  R2381     -9.2750638723373413e-02
    z[6,7,2]  R2382     1.4911958575248718e-01
    z[6,7,2]  R2383     2.6723194122314453e-01
    z[6,7,2]  R2384     1.3118797540664673e-01
    z[6,7,2]  R2385     -0.584646463394165
    z[6,7,2]  R2386     -5.7222151756286621e-01
    z[6,7,2]  R2387     -9.1069459915161133e-02
    z[6,7,2]  R2388     9.5958143472671509e-02
    z[6,7,2]  R2389     2.0737320184707642e-02
    z[6,7,2]  R2390     -1.0694067925214767e-01
    z[6,7,2]  R2391     1.4552344381809235e-01
    z[6,7,2]  R2392     1.8929733335971832e-01
    z[6,7,2]  R2393     -7.9540058970451355e-02
    z[6,7,2]  R2394     -6.1340779066085815e-01
    z[6,7,2]  R2395     4.8959512263536453e-02
    z[6,7,2]  R2396     -4.5501585118472576e-03
    z[6,7,2]  R2397     1.9258438050746918e-01
    z[6,7,2]  R2398     3.5356727242469788e-01
    z[6,7,2]  R2399     2.0872248709201813e-01
    z[6,7,2]  R2400     -3.4142377972602844e-01
    z[6,7,2]  R2401     1.2800908088684082e-01
    z[6,7,2]  R2402     -9.1829463839530945e-02
    z[6,7,2]  R2403     -2.1675500273704529e-01
    z[6,7,2]  R2404     -2.1271312609314919e-02
    z[6,7,2]  R2405     -1.1073148995637894e-01
    z[6,7,2]  R2406     -3.6913838982582092e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2231     -1
    z[6,7,3]  R2232     1
    z[6,7,3]  R2239     -3.3907768130302429e-01
    z[6,7,3]  R2240     -2.9924616217613220e-01
    z[6,7,3]  R2241     -3.3888214826583862e-01
    z[6,7,3]  R2242     -5.9020549058914185e-01
    z[6,7,3]  R2243     -2.7884083986282349e-01
    z[6,7,3]  R2244     -5.5373167991638184e-01
    z[6,7,3]  R2245     -1.9600987434387207e-01
    z[6,7,3]  R2246     -3.7111577391624451e-01
    z[6,7,3]  R2247     2.6010829210281372e-01
    z[6,7,3]  R2248     8.1559962034225464e-01
    z[6,7,3]  R2249     1.2610229849815369e-01
    z[6,7,3]  R2250     9.3165948987007141e-02
    z[6,7,3]  R2251     -4.9079051613807678e-01
    z[6,7,3]  R2252     -4.9664461612701416e-01
    z[6,7,3]  R2253     3.9586505293846130e-01
    z[6,7,3]  R2254     2.1753889322280884e-01
    z[6,7,3]  R2255     -5.1467999815940857e-02
    z[6,7,3]  R2256     1.1947729438543320e-01
    z[6,7,3]  R2257     1.1300613731145859e-01
    z[6,7,3]  R2258     -3.8399152457714081e-02
    z[6,7,3]  R2259     3.9864072203636169e-01
    z[6,7,3]  R2260     -0.0781896784901619
    z[6,7,3]  R2261     5.0997996330261230e-01
    z[6,7,3]  R2262     -0.0290201585739851
    z[6,7,3]  R2263     3.3412650227546692e-02
    z[6,7,3]  R2264     6.9710515439510345e-02
    z[6,7,3]  R2265     3.3124664425849915e-01
    z[6,7,3]  R2266     9.6823759377002716e-02
    z[6,7,3]  R2267     2.7094164490699768e-01
    z[6,7,3]  R2268     1.2503567337989807e-01
    z[6,7,3]  R2269     1.2436323612928391e-01
    z[6,7,3]  R2270     -2.3279446363449097e-01
    z[6,7,3]  R2271     -5.4520197212696075e-02
    z[6,7,3]  R2272     -1.1272186040878296e-01
    z[6,7,3]  R2273     -3.9822015166282654e-01
    z[6,7,3]  R2274     1.9771383702754974e-01
    z[6,7,3]  R2275     -3.5733717679977417e-01
    z[6,7,3]  R2276     9.8374977707862854e-02
    z[6,7,3]  R2277     4.0437778830528259e-01
    z[6,7,3]  R2278     3.5644698143005371e-01
    z[6,7,3]  R2279     -3.9706024527549744e-01
    z[6,7,3]  R2280     2.9846101999282837e-01
    z[6,7,3]  R2281     2.7269285917282104e-01
    z[6,7,3]  R2282     1.0264895856380463e-01
    z[6,7,3]  R2283     2.5535422563552856e-01
    z[6,7,3]  R2284     4.0238106250762939e-01
    z[6,7,3]  R2285     -8.0770663917064667e-03
    z[6,7,3]  R2286     7.5806421227753162e-03
    z[6,7,3]  R2287     -1.4889647066593170e-01
    z[6,7,3]  R2288     1.0548835247755051e-01
    z[6,7,3]  R2289     -1.6698397696018219e-02
    z[6,7,3]  R2290     -3.6903306841850281e-01
    z[6,7,3]  R2291     3.1129187345504761e-01
    z[6,7,3]  R2292     2.8346312046051025e-01
    z[6,7,3]  R2293     7.2360301017761230e-01
    z[6,7,3]  R2294     4.1686362028121948e-01
    z[6,7,3]  R2295     1.5570640563964844e-01
    z[6,7,3]  R2296     1.2262795865535736e-01
    z[6,7,3]  R2297     -1.3377287983894348e-01
    z[6,7,3]  R2298     1.1306324601173401e-01
    z[6,7,3]  R2299     5.3718948364257812e-01
    z[6,7,3]  R2300     -0.571797788143158
    z[6,7,3]  R2301     2.1838736534118652e-01
    z[6,7,3]  R2302     3.0689904093742371e-01
    z[6,7,3]  R2303     6.3965070247650146e-01
    z[6,7,3]  R2304     5.1850110292434692e-01
    z[6,7,3]  R2305     5.0610125064849854e-01
    z[6,7,3]  R2306     2.2512586414813995e-01
    z[6,7,3]  R2307     5.3207403421401978e-01
    z[6,7,3]  R2308     6.9865804910659790e-01
    z[6,7,3]  R2309     -2.8843320906162262e-02
    z[6,7,3]  R2310     4.2975005507469177e-01
    z[6,7,3]  R2311     3.2536211609840393e-01
    z[6,7,3]  R2312     5.2024662494659424e-01
    z[6,7,3]  R2313     -1.0241288691759109e-01
    z[6,7,3]  R2314     0.801220178604126
    z[6,7,3]  R2315     4.1895386576652527e-01
    z[6,7,3]  R2316     2.0774005353450775e-01
    z[6,7,3]  R2317     2.7850806713104248e-01
    z[6,7,3]  R2318     -1.0500277578830719e-01
    z[6,7,3]  R2319     -3.9494130760431290e-02
    z[6,7,3]  R2320     -2.1544608473777771e-01
    z[6,7,3]  R2321     -7.8749559819698334e-02
    z[6,7,3]  R2322     8.2119709253311157e-01
    z[6,7,3]  R2323     -5.1762568950653076e-01
    z[6,7,3]  R2324     1.3576522469520569e-01
    z[6,7,3]  R2325     0.0986611545085907
    z[6,7,3]  R2326     7.8905093669891357e-01
    z[6,7,3]  R2327     -2.1489325165748596e-01
    z[6,7,3]  R2328     -4.4135209918022156e-01
    z[6,7,3]  R2329     -2.9773136973381042e-01
    z[6,7,3]  R2330     -4.7056525945663452e-01
    z[6,7,3]  R2331     -5.1373803615570068e-01
    z[6,7,3]  R2332     -9.6666947007179260e-02
    z[6,7,3]  R2333     -5.6725364923477173e-01
    z[6,7,3]  R2334     5.3634798526763916e-01
    z[6,7,3]  R2335     -4.5542147755622864e-01
    z[6,7,3]  R2336     3.9375522732734680e-01
    z[6,7,3]  R2337     -3.3225673437118530e-01
    z[6,7,3]  R2338     -6.4335089921951294e-01
    z[6,7,3]  R2339     -6.6603964567184448e-01
    z[6,7,3]  R2340     -2.0372414588928223e-01
    z[6,7,3]  R2341     1.4815287292003632e-01
    z[6,7,3]  R2342     -1.4601313509047031e-02
    z[6,7,3]  R2343     2.0684491097927094e-01
    z[6,7,3]  R2344     -3.8015641272068024e-02
    z[6,7,3]  R2345     4.5650738477706909e-01
    z[6,7,3]  R2346     -2.1075144410133362e-01
    z[6,7,3]  R2347     -1.9165011122822762e-02
    z[6,7,3]  R2348     3.7987983226776123e-01
    z[6,7,3]  R2349     1.0237257182598114e-01
    z[6,7,3]  R2350     3.8853892683982849e-01
    z[6,7,3]  R2351     4.2647641897201538e-01
    z[6,7,3]  R2352     -1.4260447025299072e-01
    z[6,7,3]  R2353     2.6867750287055969e-01
    z[6,7,3]  R2354     -1.5323288738727570e-01
    z[6,7,3]  R2355     2.7281916141510010e-01
    z[6,7,3]  R2356     4.9727344512939453e-01
    z[6,7,3]  R2357     7.3696893453598022e-01
    z[6,7,3]  R2358     2.2377386689186096e-02
    z[6,7,3]  R2359     4.9843266606330872e-01
    z[6,7,3]  R2360     5.5681866407394409e-01
    z[6,7,3]  R2361     -6.0512870550155640e-01
    z[6,7,3]  R2362     0.0890241339802742
    z[6,7,3]  R2363     -4.6217706799507141e-01
    z[6,7,3]  R2364     -4.0138861536979675e-01
    z[6,7,3]  R2365     -6.1015748977661133e-01
    z[6,7,3]  R2366     2.2263512015342712e-01
    z[6,7,3]  R2367     2.0708565413951874e-01
    z[6,7,3]  R2368     -4.8841637372970581e-01
    z[6,7,3]  R2369     1.5461874008178711e-01
    z[6,7,3]  R2370     2.8776556253433228e-01
    z[6,7,3]  R2371     2.1502895653247833e-01
    z[6,7,3]  R2372     -2.0312415063381195e-01
    z[6,7,3]  R2373     -1.0942038893699646e-01
    z[6,7,3]  R2374     -5.6919389963150024e-01
    z[6,7,3]  R2375     -4.9499401450157166e-01
    z[6,7,3]  R2376     -4.2022615671157837e-01
    z[6,7,3]  R2377     1.2178914248943329e-01
    z[6,7,3]  R2378     2.4164592847228050e-02
    z[6,7,3]  R2379     -1.6868244856595993e-02
    z[6,7,3]  R2380     3.1191563606262207e-01
    z[6,7,3]  R2381     9.8548196256160736e-02
    z[6,7,3]  R2382     -2.2359421476721764e-02
    z[6,7,3]  R2383     -1.6333516687154770e-02
    z[6,7,3]  R2384     3.0073146335780621e-03
    z[6,7,3]  R2385     -5.5990648269653320e-01
    z[6,7,3]  R2386     3.5550169646739960e-02
    z[6,7,3]  R2387     8.1884294748306274e-02
    z[6,7,3]  R2388     1.6896691918373108e-01
    z[6,7,3]  R2389     5.1314628124237061e-01
    z[6,7,3]  R2390     1.3779959082603455e-01
    z[6,7,3]  R2391     -1.9642950594425201e-01
    z[6,7,3]  R2392     -5.2982360124588013e-01
    z[6,7,3]  R2393     -3.9600214362144470e-01
    z[6,7,3]  R2394     3.2492477446794510e-02
    z[6,7,3]  R2395     1.7291373014450073e-01
    z[6,7,3]  R2396     -0.0959969162940979
    z[6,7,3]  R2397     1.9805204123258591e-02
    z[6,7,3]  R2398     1.8201887607574463e-02
    z[6,7,3]  R2399     5.6374704837799072e-01
    z[6,7,3]  R2400     -6.0380709171295166e-01
    z[6,7,3]  R2401     1.7328624427318573e-01
    z[6,7,3]  R2402     7.2874200344085693e-01
    z[6,7,3]  R2403     7.1704608201980591e-01
    z[6,7,3]  R2404     -2.5790292024612427e-01
    z[6,7,3]  R2405     6.7493087053298950e-01
    z[6,7,3]  R2406     -1.8290762603282928e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2233     -1
    z[6,7,4]  R2234     1
    z[6,7,4]  R2239     -4.6573806554079056e-02
    z[6,7,4]  R2240     -1.8613596260547638e-01
    z[6,7,4]  R2241     4.7604110091924667e-02
    z[6,7,4]  R2242     -1.3970064930617809e-02
    z[6,7,4]  R2243     3.3509659767150879e-01
    z[6,7,4]  R2244     4.5216381549835205e-01
    z[6,7,4]  R2245     4.3756440281867981e-01
    z[6,7,4]  R2246     3.0622169375419617e-01
    z[6,7,4]  R2247     -3.3020820468664169e-02
    z[6,7,4]  R2248     -4.0312924981117249e-01
    z[6,7,4]  R2249     2.3207981884479523e-01
    z[6,7,4]  R2250     1.8537633121013641e-01
    z[6,7,4]  R2251     5.0928640365600586e-01
    z[6,7,4]  R2252     -1.3969862461090088e-01
    z[6,7,4]  R2253     3.4669709205627441e-01
    z[6,7,4]  R2254     -1.7271824181079865e-01
    z[6,7,4]  R2255     3.9200261235237122e-02
    z[6,7,4]  R2256     9.2002548277378082e-02
    z[6,7,4]  R2257     -1.8937504291534424e-01
    z[6,7,4]  R2258     -1.4360065758228302e-01
    z[6,7,4]  R2259     -2.8094735741615295e-01
    z[6,7,4]  R2260     -2.1369270980358124e-02
    z[6,7,4]  R2261     3.4329418092966080e-02
    z[6,7,4]  R2262     -6.6291856765747070e-01
    z[6,7,4]  R2263     -4.8803728818893433e-01
    z[6,7,4]  R2264     -1.5790884196758270e-01
    z[6,7,4]  R2265     -5.5078315734863281e-01
    z[6,7,4]  R2266     -8.3766520023345947e-02
    z[6,7,4]  R2267     -2.1506768465042114e-01
    z[6,7,4]  R2268     2.0711828768253326e-01
    z[6,7,4]  R2269     -3.0013337731361389e-02
    z[6,7,4]  R2270     2.7905574440956116e-01
    z[6,7,4]  R2271     -4.8334106802940369e-02
    z[6,7,4]  R2272     -3.0210144817829132e-02
    z[6,7,4]  R2273     5.2105122804641724e-01
    z[6,7,4]  R2274     -1.3227945193648338e-02
    z[6,7,4]  R2275     2.3158590495586395e-01
    z[6,7,4]  R2276     2.3669071495532990e-01
    z[6,7,4]  R2277     4.9811866134405136e-02
    z[6,7,4]  R2278     1.8622530996799469e-01
    z[6,7,4]  R2279     2.2148312628269196e-01
    z[6,7,4]  R2280     3.5426761955022812e-02
    z[6,7,4]  R2281     -2.9519531130790710e-01
    z[6,7,4]  R2282     4.0074518322944641e-01
    z[6,7,4]  R2283     -2.4200105667114258e-01
    z[6,7,4]  R2284     1.2927709519863129e-01
    z[6,7,4]  R2285     2.2059883177280426e-01
    z[6,7,4]  R2286     2.1980078890919685e-02
    z[6,7,4]  R2287     1.5698119997978210e-01
    z[6,7,4]  R2288     -7.6411046087741852e-02
    z[6,7,4]  R2289     -1.6664180159568787e-01
    z[6,7,4]  R2290     -3.8733837008476257e-01
    z[6,7,4]  R2291     -7.0992313325405121e-02
    z[6,7,4]  R2292     3.9768660068511963e-01
    z[6,7,4]  R2293     -1.9679825007915497e-01
    z[6,7,4]  R2294     -0.302804559469223
    z[6,7,4]  R2295     -3.0368554592132568e-01
    z[6,7,4]  R2296     1.0551684349775314e-01
    z[6,7,4]  R2297     -1.9355788826942444e-02
    z[6,7,4]  R2298     6.2445417046546936e-02
    z[6,7,4]  R2299     -1.5688581764698029e-01
    z[6,7,4]  R2300     -1.8737266957759857e-01
    z[6,7,4]  R2301     1.3259534537792206e-01
    z[6,7,4]  R2302     -1.9866687059402466e-01
    z[6,7,4]  R2303     -3.0559748411178589e-01
    z[6,7,4]  R2304     1.3698628544807434e-01
    z[6,7,4]  R2305     -5.0602819770574570e-02
    z[6,7,4]  R2306     -1.5582096576690674e-01
    z[6,7,4]  R2307     -4.6497333049774170e-01
    z[6,7,4]  R2308     6.6649354994297028e-02
    z[6,7,4]  R2309     1.2416181713342667e-01
    z[6,7,4]  R2310     3.8874413818120956e-02
    z[6,7,4]  R2311     1.6988384723663330e-01
    z[6,7,4]  R2312     -6.0564088821411133e-01
    z[6,7,4]  R2313     5.5132603645324707e-01
    z[6,7,4]  R2314     -6.8614810705184937e-02
    z[6,7,4]  R2315     -0.664197564125061
    z[6,7,4]  R2316     -4.2081409692764282e-01
    z[6,7,4]  R2317     -1.2498825043439865e-01
    z[6,7,4]  R2318     1.0058642923831940e-01
    z[6,7,4]  R2319     4.0197573602199554e-02
    z[6,7,4]  R2320     8.1931173801422119e-02
    z[6,7,4]  R2321     4.4640928506851196e-02
    z[6,7,4]  R2322     -1.0576204210519791e-01
    z[6,7,4]  R2323     6.1329182237386703e-02
    z[6,7,4]  R2324     6.8140506744384766e-02
    z[6,7,4]  R2325     1.2142547965049744e-01
    z[6,7,4]  R2326     -1.1520221084356308e-01
    z[6,7,4]  R2327     -1.8276037275791168e-01
    z[6,7,4]  R2328     2.3541533946990967e-01
    z[6,7,4]  R2329     -0.514081597328186
    z[6,7,4]  R2330     -1.2707982957363129e-01
    z[6,7,4]  R2331     -2.6603189110755920e-01
    z[6,7,4]  R2332     6.1554533243179321e-01
    z[6,7,4]  R2333     -4.0420621633529663e-01
    z[6,7,4]  R2334     1.7329661548137665e-01
    z[6,7,4]  R2335     1.4906750619411469e-01
    z[6,7,4]  R2336     2.7997341752052307e-01
    z[6,7,4]  R2337     1.4735132455825806e-02
    z[6,7,4]  R2338     1.0696996748447418e-01
    z[6,7,4]  R2339     -3.8329381495714188e-02
    z[6,7,4]  R2340     2.4498523771762848e-01
    z[6,7,4]  R2341     -3.0189722776412964e-01
    z[6,7,4]  R2342     -1.3840667903423309e-01
    z[6,7,4]  R2343     1.9698446616530418e-02
    z[6,7,4]  R2344     -4.2618361115455627e-01
    z[6,7,4]  R2345     9.0292975306510925e-02
    z[6,7,4]  R2346     4.4573080539703369e-01
    z[6,7,4]  R2347     7.0526683330535889e-01
    z[6,7,4]  R2348     2.2930772602558136e-01
    z[6,7,4]  R2349     2.5002929568290710e-01
    z[6,7,4]  R2350     -3.4208881855010986e-01
    z[6,7,4]  R2351     1.9140517711639404e-01
    z[6,7,4]  R2352     -8.0715966224670410e-01
    z[6,7,4]  R2353     -3.9832934737205505e-01
    z[6,7,4]  R2354     9.0377889573574066e-02
    z[6,7,4]  R2355     -5.5513745546340942e-01
    z[6,7,4]  R2356     1.2700709700584412e-01
    z[6,7,4]  R2357     -8.0024421215057373e-02
    z[6,7,4]  R2358     -3.8305470347404480e-01
    z[6,7,4]  R2359     2.8270408511161804e-01
    z[6,7,4]  R2360     -3.2083618640899658e-01
    z[6,7,4]  R2361     -3.7383839488029480e-01
    z[6,7,4]  R2362     -2.9608780145645142e-01
    z[6,7,4]  R2363     2.8118072077631950e-02
    z[6,7,4]  R2364     -2.6770675182342529e-01
    z[6,7,4]  R2365     2.5118380784988403e-01
    z[6,7,4]  R2366     -6.5479505062103271e-01
    z[6,7,4]  R2367     -4.5285901427268982e-01
    z[6,7,4]  R2368     0.0766245424747467
    z[6,7,4]  R2369     -3.6809706687927246e-01
    z[6,7,4]  R2370     4.2856097221374512e-02
    z[6,7,4]  R2371     1.2355703860521317e-01
    z[6,7,4]  R2372     -1.7000260949134827e-01
    z[6,7,4]  R2373     -1.7644479870796204e-02
    z[6,7,4]  R2374     -5.0424743443727493e-02
    z[6,7,4]  R2375     4.4696271419525146e-01
    z[6,7,4]  R2376     -0.0360000804066658
    z[6,7,4]  R2377     -7.9047113656997681e-02
    z[6,7,4]  R2378     -4.9157503992319107e-02
    z[6,7,4]  R2379     1.4077517390251160e-01
    z[6,7,4]  R2380     -2.8249008581042290e-02
    z[6,7,4]  R2381     -5.6559729576110840e-01
    z[6,7,4]  R2382     -6.1346596479415894e-01
    z[6,7,4]  R2383     1.0119650512933731e-02
    z[6,7,4]  R2384     1.6915602609515190e-02
    z[6,7,4]  R2385     -3.8995620608329773e-01
    z[6,7,4]  R2386     -2.7812096476554871e-01
    z[6,7,4]  R2387     2.9832589626312256e-01
    z[6,7,4]  R2388     -3.5633894801139832e-01
    z[6,7,4]  R2389     4.3829031288623810e-02
    z[6,7,4]  R2390     1.8756887875497341e-03
    z[6,7,4]  R2391     -3.6813512444496155e-01
    z[6,7,4]  R2392     1.4003157615661621e-01
    z[6,7,4]  R2393     3.8114407658576965e-01
    z[6,7,4]  R2394     -2.4910818040370941e-01
    z[6,7,4]  R2395     6.7822217941284180e-02
    z[6,7,4]  R2396     -1.9547192752361298e-01
    z[6,7,4]  R2397     -1.9871446490287781e-01
    z[6,7,4]  R2398     5.5680975317955017e-02
    z[6,7,4]  R2399     1.2122242152690887e-01
    z[6,7,4]  R2400     1.2970919907093048e-01
    z[6,7,4]  R2401     -3.7139644846320152e-03
    z[6,7,4]  R2402     -1.3720582425594330e-01
    z[6,7,4]  R2403     1.1584879830479622e-03
    z[6,7,4]  R2404     -3.3810895681381226e-01
    z[6,7,4]  R2405     2.6022934913635254e-01
    z[6,7,4]  R2406     1.8798503279685974e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2235     -1
    z[6,7,5]  R2236     1
    z[6,7,5]  R2239     5.0448134541511536e-02
    z[6,7,5]  R2240     3.5628405213356018e-01
    z[6,7,5]  R2241     4.9841940402984619e-01
    z[6,7,5]  R2242     2.3097988963127136e-01
    z[6,7,5]  R2243     3.3193412423133850e-01
    z[6,7,5]  R2244     -9.6335709095001221e-02
    z[6,7,5]  R2245     1.0548584163188934e-02
    z[6,7,5]  R2246     -4.0202800184488297e-02
    z[6,7,5]  R2247     0.355111688375473
    z[6,7,5]  R2248     -1.7216829583048820e-02
    z[6,7,5]  R2249     3.4412688016891479e-01
    z[6,7,5]  R2250     5.2093285322189331e-01
    z[6,7,5]  R2251     -1.3080455362796783e-01
    z[6,7,5]  R2252     -1.1704389750957489e-01
    z[6,7,5]  R2253     1.8582293391227722e-01
    z[6,7,5]  R2254     -1.4288491010665894e-01
    z[6,7,5]  R2255     1.0768998414278030e-01
    z[6,7,5]  R2256     -2.9755065217614174e-02
    z[6,7,5]  R2257     1.2650847434997559e-01
    z[6,7,5]  R2258     6.8607471883296967e-02
    z[6,7,5]  R2259     3.4096702933311462e-01
    z[6,7,5]  R2260     2.5523445010185242e-01
    z[6,7,5]  R2261     -2.1300630643963814e-02
    z[6,7,5]  R2262     4.8581507802009583e-01
    z[6,7,5]  R2263     5.2268964052200317e-01
    z[6,7,5]  R2264     -1.1703015118837357e-01
    z[6,7,5]  R2265     4.3361055850982666e-01
    z[6,7,5]  R2266     -4.6812698245048523e-01
    z[6,7,5]  R2267     1.3619804382324219e-01
    z[6,7,5]  R2268     -2.6303318142890930e-01
    z[6,7,5]  R2269     3.7050571292638779e-02
    z[6,7,5]  R2270     -1.2478940188884735e-01
    z[6,7,5]  R2271     8.6288809776306152e-02
    z[6,7,5]  R2272     -1.6528807580471039e-01
    z[6,7,5]  R2273     3.5488995909690857e-01
    z[6,7,5]  R2274     1.9388712942600250e-01
    z[6,7,5]  R2275     -9.8234914243221283e-02
    z[6,7,5]  R2276     6.5929156541824341e-01
    z[6,7,5]  R2277     -1.6213320195674896e-01
    z[6,7,5]  R2278     3.0738005042076111e-01
    z[6,7,5]  R2279     3.4320649504661560e-01
    z[6,7,5]  R2280     -1.9283334910869598e-01
    z[6,7,5]  R2281     6.1310482025146484e-01
    z[6,7,5]  R2282     2.9591289162635803e-01
    z[6,7,5]  R2283     -1.7603531479835510e-01
    z[6,7,5]  R2284     8.6186133325099945e-02
    z[6,7,5]  R2285     2.8385239839553833e-01
    z[6,7,5]  R2286     2.4412062764167786e-01
    z[6,7,5]  R2287     5.2332830429077148e-01
    z[6,7,5]  R2288     4.1580680012702942e-01
    z[6,7,5]  R2289     -1.2333630770444870e-01
    z[6,7,5]  R2290     -0.0711502805352211
    z[6,7,5]  R2291     4.6585026383399963e-01
    z[6,7,5]  R2292     3.6016803979873657e-01
    z[6,7,5]  R2293     3.2151695340871811e-02
    z[6,7,5]  R2294     -4.0721049904823303e-01
    z[6,7,5]  R2295     1.1348453909158707e-01
    z[6,7,5]  R2296     -3.0042484402656555e-01
    z[6,7,5]  R2297     -9.7968660295009613e-02
    z[6,7,5]  R2298     -2.2801715135574341e-01
    z[6,7,5]  R2299     3.3695498108863831e-01
    z[6,7,5]  R2300     -1.9032275676727295e-01
    z[6,7,5]  R2301     2.3500597476959229e-01
    z[6,7,5]  R2302     0.0966220423579216
    z[6,7,5]  R2303     6.5530523657798767e-02
    z[6,7,5]  R2304     4.1757243871688843e-01
    z[6,7,5]  R2305     3.0980497598648071e-01
    z[6,7,5]  R2306     3.6398828029632568e-01
    z[6,7,5]  R2307     3.1032985448837280e-01
    z[6,7,5]  R2308     4.4034352898597717e-01
    z[6,7,5]  R2309     2.8430068492889404e-01
    z[6,7,5]  R2310     2.5482922792434692e-01
    z[6,7,5]  R2311     -1.6160987317562103e-01
    z[6,7,5]  R2312     2.4246735870838165e-01
    z[6,7,5]  R2313     -1.6973756253719330e-01
    z[6,7,5]  R2314     3.9245158433914185e-01
    z[6,7,5]  R2315     -7.2402499616146088e-02
    z[6,7,5]  R2316     -2.5813108682632446e-01
    z[6,7,5]  R2317     -2.4999319016933441e-01
    z[6,7,5]  R2318     -1.6648904979228973e-01
    z[6,7,5]  R2319     -3.2943961024284363e-01
    z[6,7,5]  R2320     -3.5980053246021271e-02
    z[6,7,5]  R2321     -3.1049215793609619e-01
    z[6,7,5]  R2322     2.8177076578140259e-01
    z[6,7,5]  R2323     -1.1477879434823990e-01
    z[6,7,5]  R2324     2.0424258708953857e-01
    z[6,7,5]  R2325     6.9125302135944366e-02
    z[6,7,5]  R2326     -7.8146345913410187e-02
    z[6,7,5]  R2327     -3.4167268872261047e-01
    z[6,7,5]  R2328     -3.8538447022438049e-01
    z[6,7,5]  R2329     5.9163773059844971e-01
    z[6,7,5]  R2330     8.0719190835952759e-01
    z[6,7,5]  R2331     -4.1230313479900360e-02
    z[6,7,5]  R2332     0.662135660648346
    z[6,7,5]  R2333     2.0706829428672791e-01
    z[6,7,5]  R2334     3.3804544806480408e-01
    z[6,7,5]  R2335     9.5515400171279907e-02
    z[6,7,5]  R2336     0.505935549736023
    z[6,7,5]  R2337     1.1857295036315918e-01
    z[6,7,5]  R2338     2.4743312597274780e-01
    z[6,7,5]  R2339     -2.0205296576023102e-01
    z[6,7,5]  R2340     2.1121473610401154e-01
    z[6,7,5]  R2341     -2.5830811262130737e-01
    z[6,7,5]  R2342     -5.7815372943878174e-02
    z[6,7,5]  R2343     -1.8703229725360870e-01
    z[6,7,5]  R2344     1.1776927113533020e-01
    z[6,7,5]  R2345     -1.4460229873657227e-01
    z[6,7,5]  R2346     -2.6085074990987778e-02
    z[6,7,5]  R2347     -3.1523931026458740e-01
    z[6,7,5]  R2348     4.5445635914802551e-01
    z[6,7,5]  R2349     4.9852064251899719e-01
    z[6,7,5]  R2350     7.3102825880050659e-01
    z[6,7,5]  R2351     -0.29815673828125
    z[6,7,5]  R2352     5.6530215078964829e-04
    z[6,7,5]  R2353     6.0024946928024292e-01
    z[6,7,5]  R2354     0.0422833114862442
    z[6,7,5]  R2355     -4.9906989932060242e-01
    z[6,7,5]  R2356     -2.4751673638820648e-01
    z[6,7,5]  R2357     5.0589424371719360e-01
    z[6,7,5]  R2358     4.6643459796905518e-01
    z[6,7,5]  R2359     4.9176892638206482e-01
    z[6,7,5]  R2360     4.5104572176933289e-01
    z[6,7,5]  R2361     -2.8282532095909119e-01
    z[6,7,5]  R2362     9.0691685676574707e-02
    z[6,7,5]  R2363     9.3692235648632050e-02
    z[6,7,5]  R2364     8.2366280257701874e-02
    z[6,7,5]  R2365     -1.0965884663164616e-02
    z[6,7,5]  R2366     1.4352850615978241e-01
    z[6,7,5]  R2367     5.3257197141647339e-01
    z[6,7,5]  R2368     6.5734423696994781e-02
    z[6,7,5]  R2369     9.0009754896163940e-01
    z[6,7,5]  R2370     -5.0257092714309692e-01
    z[6,7,5]  R2371     -3.0434669926762581e-02
    z[6,7,5]  R2372     -5.0444877706468105e-03
    z[6,7,5]  R2373     6.1857527494430542e-01
    z[6,7,5]  R2374     5.2670907229185104e-02
    z[6,7,5]  R2375     -1.1368764191865921e-01
    z[6,7,5]  R2376     -1.4943751692771912e-01
    z[6,7,5]  R2377     3.6455500870943069e-02
    z[6,7,5]  R2378     -2.2192882001399994e-01
    z[6,7,5]  R2379     5.3731882572174072e-01
    z[6,7,5]  R2380     7.1017998456954956e-01
    z[6,7,5]  R2381     1.2367139756679535e-01
    z[6,7,5]  R2382     -1.6047137975692749e-01
    z[6,7,5]  R2383     2.0586515963077545e-01
    z[6,7,5]  R2384     5.5116474628448486e-01
    z[6,7,5]  R2385     -0.068540558218956
    z[6,7,5]  R2386     -0.0843089371919632
    z[6,7,5]  R2387     1.7187568545341492e-01
    z[6,7,5]  R2388     -1.1723558604717255e-01
    z[6,7,5]  R2389     7.7866941690444946e-01
    z[6,7,5]  R2390     6.6610980033874512e-01
    z[6,7,5]  R2391     -3.2666981220245361e-01
    z[6,7,5]  R2392     -3.5131010413169861e-01
    z[6,7,5]  R2393     1.1444703489542007e-01
    z[6,7,5]  R2394     -6.0068786144256592e-02
    z[6,7,5]  R2395     -1.2698693573474884e-01
    z[6,7,5]  R2396     -1.7714734375476837e-01
    z[6,7,5]  R2397     -2.4065764620900154e-02
    z[6,7,5]  R2398     -1.6155165433883667e-01
    z[6,7,5]  R2399     7.4525499343872070e-01
    z[6,7,5]  R2400     3.1178635358810425e-01
    z[6,7,5]  R2401     -1.3313570991158485e-02
    z[6,7,5]  R2402     -8.8597349822521210e-02
    z[6,7,5]  R2403     -1.8960566818714142e-01
    z[6,7,5]  R2404     -1.9285212457180023e-01
    z[6,7,5]  R2405     -1.8472701311111450e-01
    z[6,7,5]  R2406     5.1409624516963959e-02
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2237     -1
    z[6,7,6]  R2238     1
    z[6,7,6]  R2239     -3.0224621295928955e-02
    z[6,7,6]  R2240     -3.0544428154826164e-02
    z[6,7,6]  R2241     -1.0236737877130508e-01
    z[6,7,6]  R2242     -1.8589726090431213e-01
    z[6,7,6]  R2243     2.1918751299381256e-03
    z[6,7,6]  R2244     0.079471655189991
    z[6,7,6]  R2245     1.1661176383495331e-01
    z[6,7,6]  R2246     -4.5812937617301941e-01
    z[6,7,6]  R2247     -9.5765674486756325e-03
    z[6,7,6]  R2248     1.1679705977439880e-01
    z[6,7,6]  R2249     -1.1486873030662537e-01
    z[6,7,6]  R2250     -4.6692779660224915e-01
    z[6,7,6]  R2251     1.4410948380827904e-02
    z[6,7,6]  R2252     -2.3125639557838440e-01
    z[6,7,6]  R2253     -2.1750238537788391e-01
    z[6,7,6]  R2254     3.6757946014404297e-01
    z[6,7,6]  R2255     1.0941742360591888e-01
    z[6,7,6]  R2256     2.4398863315582275e-02
    z[6,7,6]  R2257     0.0702752098441124
    z[6,7,6]  R2258     -2.9970180243253708e-02
    z[6,7,6]  R2259     1.3765922188758850e-01
    z[6,7,6]  R2260     -3.8214033842086792e-01
    z[6,7,6]  R2261     -2.1635919809341431e-01
    z[6,7,6]  R2262     1.9490335881710052e-01
    z[6,7,6]  R2263     -2.4053165316581726e-01
    z[6,7,6]  R2264     3.0572479963302612e-01
    z[6,7,6]  R2265     -1.2226716615259647e-02
    z[6,7,6]  R2266     -1.4560225419700146e-02
    z[6,7,6]  R2267     4.7664329409599304e-01
    z[6,7,6]  R2268     4.6030825376510620e-01
    z[6,7,6]  R2269     -2.3105631768703461e-01
    z[6,7,6]  R2270     -4.4470822811126709e-01
    z[6,7,6]  R2271     1.3618775643408298e-02
    z[6,7,6]  R2272     -0.049640953540802
    z[6,7,6]  R2273     -0.259581595659256
    z[6,7,6]  R2274     -3.6433029174804688e-01
    z[6,7,6]  R2275     2.9331985116004944e-01
    z[6,7,6]  R2276     1.3550363481044769e-01
    z[6,7,6]  R2277     1.5716609358787537e-01
    z[6,7,6]  R2278     0.46355140209198
    z[6,7,6]  R2279     2.0093612372875214e-02
    z[6,7,6]  R2280     1.1167913675308228e-02
    z[6,7,6]  R2281     6.5813146531581879e-02
    z[6,7,6]  R2282     1.8022309243679047e-01
    z[6,7,6]  R2283     9.1388203203678131e-02
    z[6,7,6]  R2284     5.4702490568161011e-01
    z[6,7,6]  R2285     1.7998608946800232e-01
    z[6,7,6]  R2286     5.0963789224624634e-01
    z[6,7,6]  R2287     1.6429116949439049e-02
    z[6,7,6]  R2288     -2.5223836302757263e-01
    z[6,7,6]  R2289     3.8169443607330322e-01
    z[6,7,6]  R2290     -8.0177947878837585e-02
    z[6,7,6]  R2291     0.0874348059296608
    z[6,7,6]  R2292     1.4457820355892181e-01
    z[6,7,6]  R2293     3.1224694848060608e-01
    z[6,7,6]  R2294     2.7112990617752075e-01
    z[6,7,6]  R2295     2.1874293684959412e-01
    z[6,7,6]  R2296     -2.8557786345481873e-01
    z[6,7,6]  R2297     -1.9834528863430023e-01
    z[6,7,6]  R2298     -5.3242433071136475e-01
    z[6,7,6]  R2299     3.0272516608238220e-01
    z[6,7,6]  R2300     -1.3332915306091309e-01
    z[6,7,6]  R2301     2.7723437547683716e-01
    z[6,7,6]  R2302     5.3015863895416260e-01
    z[6,7,6]  R2303     6.3868030905723572e-02
    z[6,7,6]  R2304     9.1345183551311493e-02
    z[6,7,6]  R2305     -6.0760229825973511e-01
    z[6,7,6]  R2306     -2.4147087242454290e-04
    z[6,7,6]  R2307     -5.2079045772552490e-01
    z[6,7,6]  R2308     -1.7207440733909607e-01
    z[6,7,6]  R2309     -5.1508295536041260e-01
    z[6,7,6]  R2310     3.1199935078620911e-01
    z[6,7,6]  R2311     3.9095902442932129e-01
    z[6,7,6]  R2312     -2.7082201838493347e-01
    z[6,7,6]  R2313     -2.7292063832283020e-01
    z[6,7,6]  R2314     -1.0957321152091026e-02
    z[6,7,6]  R2315     -2.5969070196151733e-01
    z[6,7,6]  R2316     -1.3700519502162933e-01
    z[6,7,6]  R2317     -4.0275490283966064e-01
    z[6,7,6]  R2318     -4.9255305528640747e-01
    z[6,7,6]  R2319     -2.0176558196544647e-01
    z[6,7,6]  R2320     -0.392668753862381
    z[6,7,6]  R2321     2.4300108850002289e-01
    z[6,7,6]  R2322     -0.00647188164293766
    z[6,7,6]  R2323     5.4791235923767090e-01
    z[6,7,6]  R2324     0.568831205368042
    z[6,7,6]  R2325     -2.7207210659980774e-01
    z[6,7,6]  R2326     4.0409117937088013e-01
    z[6,7,6]  R2327     -4.2171877622604370e-01
    z[6,7,6]  R2328     -1.4311835169792175e-02
    z[6,7,6]  R2329     -3.6366802453994751e-01
    z[6,7,6]  R2330     6.7211896181106567e-02
    z[6,7,6]  R2331     1.0299152135848999e-01
    z[6,7,6]  R2332     2.5076711177825928e-01
    z[6,7,6]  R2333     1.7573399841785431e-01
    z[6,7,6]  R2334     -1.8029412627220154e-01
    z[6,7,6]  R2335     1.7178039252758026e-01
    z[6,7,6]  R2336     0.165541410446167
    z[6,7,6]  R2337     -4.0061435103416443e-01
    z[6,7,6]  R2338     -2.2367390990257263e-01
    z[6,7,6]  R2339     -0.330437034368515
    z[6,7,6]  R2340     -0.226243257522583
    z[6,7,6]  R2341     -0.0281552542001009
    z[6,7,6]  R2342     4.6129834651947021e-01
    z[6,7,6]  R2343     9.8311454057693481e-02
    z[6,7,6]  R2344     1.8066602945327759e-01
    z[6,7,6]  R2345     2.7286899089813232e-01
    z[6,7,6]  R2346     -5.1402223110198975e-01
    z[6,7,6]  R2347     -3.6391206085681915e-03
    z[6,7,6]  R2348     -4.3184596300125122e-01
    z[6,7,6]  R2349     -3.0547572299838066e-02
    z[6,7,6]  R2350     2.7921709418296814e-01
    z[6,7,6]  R2351     -1.1102665215730667e-01
    z[6,7,6]  R2352     -3.9580602198839188e-02
    z[6,7,6]  R2353     2.2164296358823776e-02
    z[6,7,6]  R2354     -2.5061666965484619e-01
    z[6,7,6]  R2355     2.1673756837844849e-01
    z[6,7,6]  R2356     7.0413582026958466e-02
    z[6,7,6]  R2357     2.4492797255516052e-01
    z[6,7,6]  R2358     4.5410472154617310e-01
    z[6,7,6]  R2359     -5.8907425403594971e-01
    z[6,7,6]  R2360     9.8338752985000610e-02
    z[6,7,6]  R2361     -1.3167785108089447e-01
    z[6,7,6]  R2362     3.8783612847328186e-01
    z[6,7,6]  R2363     7.5318306684494019e-01
    z[6,7,6]  R2364     4.1969934105873108e-01
    z[6,7,6]  R2365     5.3025788068771362e-01
    z[6,7,6]  R2366     -5.0580805540084839e-01
    z[6,7,6]  R2367     -0.331859827041626
    z[6,7,6]  R2368     -5.8802329003810883e-02
    z[6,7,6]  R2369     2.2911757230758667e-02
    z[6,7,6]  R2370     2.7257823944091797e-01
    z[6,7,6]  R2371     3.5895255208015442e-01
    z[6,7,6]  R2372     -0.0967012494802475
    z[6,7,6]  R2373     -5.7264614105224609e-01
    z[6,7,6]  R2374     4.1925567388534546e-01
    z[6,7,6]  R2375     0.0626790001988411
    z[6,7,6]  R2376     3.5951954126358032e-01
    z[6,7,6]  R2377     -2.6943216100335121e-02
    z[6,7,6]  R2378     6.1659656465053558e-02
    z[6,7,6]  R2379     -5.6406247615814209e-01
    z[6,7,6]  R2380     2.7087292075157166e-01
    z[6,7,6]  R2381     1.2039686739444733e-01
    z[6,7,6]  R2382     -5.1999503374099731e-01
    z[6,7,6]  R2383     4.2394686490297318e-02
    z[6,7,6]  R2384     -7.0953494310379028e-01
    z[6,7,6]  R2385     -1.5739767253398895e-01
    z[6,7,6]  R2386     -5.2332168817520142e-01
    z[6,7,6]  R2387     1.5810205042362213e-01
    z[6,7,6]  R2388     -4.7031126916408539e-02
    z[6,7,6]  R2389     -1.8030360341072083e-01
    z[6,7,6]  R2390     -7.2309148311614990e-01
    z[6,7,6]  R2391     3.3120226860046387e-01
    z[6,7,6]  R2392     4.0426653623580933e-01
    z[6,7,6]  R2393     4.0536105632781982e-01
    z[6,7,6]  R2394     -3.6374846100807190e-01
    z[6,7,6]  R2395     -1.3886626809835434e-02
    z[6,7,6]  R2396     -1.3277682662010193e-01
    z[6,7,6]  R2397     0.0638522282242775
    z[6,7,6]  R2398     1.0440131276845932e-01
    z[6,7,6]  R2399     0.191190704703331
    z[6,7,6]  R2400     4.4415897130966187e-01
    z[6,7,6]  R2401     3.3849492669105530e-02
    z[6,7,6]  R2402     -1.6048131883144379e-01
    z[6,7,6]  R2403     2.4727353453636169e-01
    z[6,7,6]  R2404     -1.9234076142311096e-02
    z[6,7,6]  R2405     8.0929987132549286e-02
    z[6,7,6]  R2406     1.6371706128120422e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2407     -1
    z[7,6,0]  R2408     1
    z[7,6,0]  R2421     1.2360244244337082e-01
    z[7,6,0]  R2422     0.0306143369525671
    z[7,6,0]  R2423     5.4720234870910645e-01
    z[7,6,0]  R2424     -2.0705135166645050e-01
    z[7,6,0]  R2425     1.3450443744659424e-01
    z[7,6,0]  R2426     -0.511566698551178
    z[7,6,0]  R2427     1.0518323630094528e-01
    z[7,6,0]  R2428     -2.5864261388778687e-01
    z[7,6,0]  R2429     1.4801529049873352e-01
    z[7,6,0]  R2430     3.2486591488122940e-02
    z[7,6,0]  R2431     -3.0512461066246033e-01
    z[7,6,0]  R2432     7.9080504179000854e-01
    z[7,6,0]  R2433     1.4882269501686096e-01
    z[7,6,0]  R2434     -1.1800559610128403e-01
    z[7,6,0]  R2435     6.5329587459564209e-01
    z[7,6,0]  R2436     -3.3021083474159241e-01
    z[7,6,0]  R2437     7.9478567838668823e-01
    z[7,6,0]  R2438     5.5110937356948853e-01
    z[7,6,0]  R2439     4.3531551957130432e-01
    z[7,6,0]  R2440     3.7732085585594177e-01
    z[7,6,0]  R2441     -1.6677637398242950e-01
    z[7,6,0]  R2442     2.7080655097961426e-01
    z[7,6,0]  R2443     -0.333111971616745
    z[7,6,0]  R2444     -1.1851393431425095e-01
    z[7,6,0]  R2445     -4.5830646157264709e-01
    z[7,6,0]  R2446     4.4970255345106125e-02
    z[7,6,0]  R2447     -1.8352389335632324e-01
    z[7,6,0]  R2448     5.0772237777709961e-01
    z[7,6,0]  R2449     -6.1997871845960617e-02
    z[7,6,0]  R2450     -4.8145502805709839e-01
    z[7,6,0]  R2451     8.8104113936424255e-02
    z[7,6,0]  R2452     -4.3010520935058594e-01
    z[7,6,0]  R2453     4.6591836214065552e-01
    z[7,6,0]  R2454     6.7357790470123291e-01
    z[7,6,0]  R2455     -7.2544604539871216e-02
    z[7,6,0]  R2456     3.9823567867279053e-01
    z[7,6,0]  R2457     3.9311617612838745e-01
    z[7,6,0]  R2458     -2.2881540656089783e-01
    z[7,6,0]  R2459     -4.2141190171241760e-01
    z[7,6,0]  R2460     4.0351420640945435e-01
    z[7,6,0]  R2461     -8.3761967718601227e-02
    z[7,6,0]  R2462     -7.7193096280097961e-02
    z[7,6,0]  R2463     1.5632240474224091e-01
    z[7,6,0]  R2464     6.7632240056991577e-01
    z[7,6,0]  R2465     -4.5164099335670471e-01
    z[7,6,0]  R2466     -4.4391790032386780e-01
    z[7,6,0]  R2467     6.6559958457946777e-01
    z[7,6,0]  R2468     4.1964778304100037e-01
    z[7,6,0]  R2469     2.3575158417224884e-01
    z[7,6,0]  R2470     0.111433245241642
    z[7,6,0]  R2471     -4.4875025749206543e-01
    z[7,6,0]  R2472     -3.7401786446571350e-01
    z[7,6,0]  R2473     4.4309237599372864e-01
    z[7,6,0]  R2474     -5.9246625751256943e-02
    z[7,6,0]  R2475     7.8633022308349609e-01
    z[7,6,0]  R2476     -1.7872239649295807e-01
    z[7,6,0]  R2477     0.093810074031353
    z[7,6,0]  R2478     4.2910650372505188e-01
    z[7,6,0]  R2479     3.7557142972946167e-01
    z[7,6,0]  R2480     3.7017074227333069e-01
    z[7,6,0]  R2481     2.1927321329712868e-02
    z[7,6,0]  R2482     3.6122921854257584e-02
    z[7,6,0]  R2483     -4.5800682902336121e-01
    z[7,6,0]  R2484     5.4896444082260132e-01
    z[7,6,0]  R2485     7.0793789625167847e-01
    z[7,6,0]  R2486     0.505699872970581
    z[7,6,0]  R2487     3.4056031703948975e-01
    z[7,6,0]  R2488     2.2189356386661530e-01
    z[7,6,0]  R2489     2.6149040460586548e-01
    z[7,6,0]  R2490     1.1316373199224472e-01
    z[7,6,0]  R2491     -1.7203774303197861e-02
    z[7,6,0]  R2492     7.8943118453025818e-02
    z[7,6,0]  R2493     -3.1039005517959595e-01
    z[7,6,0]  R2494     2.4173296988010406e-02
    z[7,6,0]  R2495     -6.1115708202123642e-02
    z[7,6,0]  R2496     -4.9999356269836426e-01
    z[7,6,0]  R2497     -2.6486939191818237e-01
    z[7,6,0]  R2498     -5.6621241569519043e-01
    z[7,6,0]  R2499     -9.0638458728790283e-01
    z[7,6,0]  R2500     -8.2799595594406128e-01
    z[7,6,0]  R2501     -7.8493207693099976e-01
    z[7,6,0]  R2502     -7.0772647857666016e-01
    z[7,6,0]  R2503     -0.819678008556366
    z[7,6,0]  R2504     -6.6300272941589355e-01
    z[7,6,0]  R2505     -8.1264919042587280e-01
    z[7,6,0]  R2506     -6.8940824270248413e-01
    z[7,6,0]  R2507     -8.8037103414535522e-01
    z[7,6,0]  R2508     2.9375693202018738e-01
    z[7,6,0]  R2509     -3.8623297587037086e-04
    z[7,6,0]  R2510     4.9018543958663940e-01
    z[7,6,0]  R2511     4.9586838483810425e-01
    z[7,6,0]  R2512     4.3103596568107605e-01
    z[7,6,0]  R2513     2.0347057282924652e-01
    z[7,6,0]  R2514     3.9923486113548279e-01
    z[7,6,0]  R2515     0.421084463596344
    z[7,6,0]  R2516     2.6942405104637146e-01
    z[7,6,0]  R2517     3.8349777460098267e-01
    z[7,6,0]  R2518     3.8672599196434021e-01
    z[7,6,0]  R2519     0.599850058555603
    z[7,6,0]  R2520     3.9805805683135986e-01
    z[7,6,0]  R2521     9.7217820584774017e-02
    z[7,6,0]  R2522     3.7836232781410217e-01
    z[7,6,0]  R2523     2.1848320960998535e-01
    z[7,6,0]  R2524     4.0968227386474609e-01
    z[7,6,0]  R2525     5.7834142446517944e-01
    z[7,6,0]  R2526     -4.1519635915756226e-01
    z[7,6,0]  R2527     -2.0829349756240845e-01
    z[7,6,0]  R2528     1.6713143885135651e-01
    z[7,6,0]  R2529     0.291344553232193
    z[7,6,0]  R2530     2.0175081491470337e-01
    z[7,6,0]  R2531     -1.8293541669845581e-01
    z[7,6,0]  R2532     -1.5737058222293854e-01
    z[7,6,0]  R2533     -7.6309749856591225e-03
    z[7,6,0]  R2534     -3.4955191612243652e-01
    z[7,6,0]  R2535     -4.1043874621391296e-01
    z[7,6,0]  R2536     1.1732964962720871e-01
    z[7,6,0]  R2537     -4.1289508342742920e-01
    z[7,6,0]  R2538     6.7198120057582855e-02
    z[7,6,0]  R2539     1.4178267121315002e-01
    z[7,6,0]  R2540     -3.6966481804847717e-01
    z[7,6,0]  R2541     4.9518829584121704e-01
    z[7,6,0]  R2542     -2.0473115146160126e-01
    z[7,6,0]  R2543     -8.2797199487686157e-01
    z[7,6,0]  R2544     0.617081344127655
    z[7,6,0]  R2545     5.0851190090179443e-01
    z[7,6,0]  R2546     3.9375400543212891e-01
    z[7,6,0]  R2547     0.809958279132843
    z[7,6,0]  R2548     8.5605132579803467e-01
    z[7,6,0]  R2549     -2.9784919694066048e-02
    z[7,6,0]  R2550     -0.286978155374527
    z[7,6,0]  R2551     1.6640554368495941e-01
    z[7,6,0]  R2552     7.2376525402069092e-01
    z[7,6,0]  R2553     -1.7412005364894867e-01
    z[7,6,0]  R2554     8.0571383237838745e-02
    z[7,6,0]  R2555     8.3700728416442871e-01
    z[7,6,0]  R2556     1.3343612849712372e-01
    z[7,6,0]  R2557     -6.4536012709140778e-02
    z[7,6,0]  R2558     4.4132387638092041e-01
    z[7,6,0]  R2559     6.9306713342666626e-01
    z[7,6,0]  R2560     -2.6543736457824707e-01
    z[7,6,0]  R2561     4.8704367876052856e-01
    z[7,6,0]  R2562     3.5728746652603149e-01
    z[7,6,0]  R2563     2.4972066283226013e-01
    z[7,6,0]  R2564     2.2820445895195007e-01
    z[7,6,0]  R2565     4.4021755456924438e-01
    z[7,6,0]  R2566     8.7229609489440918e-01
    z[7,6,0]  R2567     1.6437853872776031e-01
    z[7,6,0]  R2568     4.1851267218589783e-01
    z[7,6,0]  R2569     -9.3097686767578125e-02
    z[7,6,0]  R2570     0.0915379747748375
    z[7,6,0]  R2571     -0.0588078498840332
    z[7,6,0]  R2572     4.6570891141891479e-01
    z[7,6,0]  R2573     -3.0314895510673523e-01
    z[7,6,0]  R2574     3.5545620322227478e-01
    z[7,6,0]  R2575     -2.0369479060173035e-01
    z[7,6,0]  R2576     -1.8442565202713013e-01
    z[7,6,0]  R2577     4.4914808869361877e-01
    z[7,6,0]  R2578     5.8731153607368469e-02
    z[7,6,0]  R2579     0.0049970424734056
    z[7,6,0]  R2580     -3.4934845566749573e-01
    z[7,6,0]  R2581     -7.5006228685379028e-01
    z[7,6,0]  R2582     4.0946078300476074e-01
    z[7,6,0]  R2583     -1.1233063042163849e-01
    z[7,6,0]  R2584     7.2808766365051270e-01
    z[7,6,0]  R2585     -2.4780279025435448e-02
    z[7,6,0]  R2586     -3.3136874437332153e-02
    z[7,6,0]  R2587     3.3650982379913330e-01
    z[7,6,0]  R2588     3.7405374646186829e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2409     -1
    z[7,6,1]  R2410     1
    z[7,6,1]  R2421     1.2836413085460663e-01
    z[7,6,1]  R2422     -7.6285108923912048e-02
    z[7,6,1]  R2423     -5.3504884243011475e-01
    z[7,6,1]  R2424     -2.1105191111564636e-01
    z[7,6,1]  R2425     5.5811733007431030e-01
    z[7,6,1]  R2426     -2.0206277072429657e-01
    z[7,6,1]  R2427     8.3387774229049683e-01
    z[7,6,1]  R2428     -8.2305364310741425e-02
    z[7,6,1]  R2429     7.9791676998138428e-01
    z[7,6,1]  R2430     0.586044430732727
    z[7,6,1]  R2431     -5.3130376338958740e-01
    z[7,6,1]  R2432     3.3108010888099670e-01
    z[7,6,1]  R2433     -7.8599143028259277e-01
    z[7,6,1]  R2434     -8.3646696805953979e-01
    z[7,6,1]  R2435     6.7285680770874023e-01
    z[7,6,1]  R2436     -7.8959834575653076e-01
    z[7,6,1]  R2437     2.3742099106311798e-01
    z[7,6,1]  R2438     2.6344174146652222e-01
    z[7,6,1]  R2439     -4.5459401607513428e-01
    z[7,6,1]  R2440     -4.6511086821556091e-01
    z[7,6,1]  R2441     -0.762222409248352
    z[7,6,1]  R2442     -1.6407574713230133e-01
    z[7,6,1]  R2443     -5.3735202550888062e-01
    z[7,6,1]  R2444     -4.3657287955284119e-01
    z[7,6,1]  R2445     -4.2445501685142517e-01
    z[7,6,1]  R2446     -8.2359558343887329e-01
    z[7,6,1]  R2447     -4.7783127427101135e-01
    z[7,6,1]  R2448     -4.5591521263122559e-01
    z[7,6,1]  R2449     -1.6740456223487854e-02
    z[7,6,1]  R2450     2.0488715171813965e-01
    z[7,6,1]  R2451     -2.7302113175392151e-01
    z[7,6,1]  R2452     -7.5260102748870850e-02
    z[7,6,1]  R2453     4.2384776473045349e-01
    z[7,6,1]  R2454     4.9414092302322388e-01
    z[7,6,1]  R2455     -4.0998184680938721e-01
    z[7,6,1]  R2456     6.5227466821670532e-01
    z[7,6,1]  R2457     3.4529119729995728e-01
    z[7,6,1]  R2458     -4.3794006109237671e-01
    z[7,6,1]  R2459     2.8829118609428406e-01
    z[7,6,1]  R2460     -4.0004888176918030e-01
    z[7,6,1]  R2461     -1.4097803831100464e-01
    z[7,6,1]  R2462     -7.5582391023635864e-01
    z[7,6,1]  R2463     -8.4233134984970093e-01
    z[7,6,1]  R2464     6.8047583103179932e-01
    z[7,6,1]  R2465     -0.270486056804657
    z[7,6,1]  R2466     -5.3289192914962769e-01
    z[7,6,1]  R2467     1.0219454765319824e-01
    z[7,6,1]  R2468     3.2792839407920837e-01
    z[7,6,1]  R2469     9.3890947103500366e-01
    z[7,6,1]  R2470     9.6040832996368408e-01
    z[7,6,1]  R2471     -4.1371452808380127e-01
    z[7,6,1]  R2472     6.7751012742519379e-02
    z[7,6,1]  R2473     -0.66004878282547
    z[7,6,1]  R2474     -5.4887789487838745e-01
    z[7,6,1]  R2475     -5.1548504829406738e-01
    z[7,6,1]  R2476     3.7859001755714417e-01
    z[7,6,1]  R2477     -3.9288067817687988e-01
    z[7,6,1]  R2478     -3.5894498229026794e-01
    z[7,6,1]  R2479     8.3690589666366577e-01
    z[7,6,1]  R2480     8.2600378990173340e-01
    z[7,6,1]  R2481     -3.0824273824691772e-01
    z[7,6,1]  R2482     4.1268173605203629e-02
    z[7,6,1]  R2483     -6.1525326967239380e-01
    z[7,6,1]  R2484     2.7501374483108521e-01
    z[7,6,1]  R2485     1.1398664861917496e-01
    z[7,6,1]  R2486     -4.1105547547340393e-01
    z[7,6,1]  R2487     9.1148459911346436e-01
    z[7,6,1]  R2488     9.2428731918334961e-01
    z[7,6,1]  R2489     9.2195343971252441e-01
    z[7,6,1]  R2490     9.0650641918182373e-01
    z[7,6,1]  R2491     -1.7797312140464783e-01
    z[7,6,1]  R2492     -0.44866743683815
    z[7,6,1]  R2493     9.2515224218368530e-01
    z[7,6,1]  R2494     6.3834863901138306e-01
    z[7,6,1]  R2495     5.8140450716018677e-01
    z[7,6,1]  R2496     7.2880762815475464e-01
    z[7,6,1]  R2497     5.9469151496887207e-01
    z[7,6,1]  R2498     0.667008638381958
    z[7,6,1]  R2499     2.3567005991935730e-01
    z[7,6,1]  R2500     -4.1897028684616089e-02
    z[7,6,1]  R2501     2.8792524710297585e-02
    z[7,6,1]  R2502     -1.2074025720357895e-01
    z[7,6,1]  R2503     -8.2762926816940308e-02
    z[7,6,1]  R2504     -1.4048515260219574e-01
    z[7,6,1]  R2505     4.6277213841676712e-02
    z[7,6,1]  R2506     -1.1682908982038498e-01
    z[7,6,1]  R2507     -1.0781950503587723e-01
    z[7,6,1]  R2508     -2.0093406736850739e-01
    z[7,6,1]  R2509     -8.9190477132797241e-01
    z[7,6,1]  R2510     -3.7189406156539917e-01
    z[7,6,1]  R2511     -4.8617777228355408e-01
    z[7,6,1]  R2512     -5.5693954229354858e-01
    z[7,6,1]  R2513     -6.9330793619155884e-01
    z[7,6,1]  R2514     -7.2400510311126709e-01
    z[7,6,1]  R2515     8.9146637916564941e-01
    z[7,6,1]  R2516     9.2655897140502930e-01
    z[7,6,1]  R2517     8.8261890411376953e-01
    z[7,6,1]  R2518     0.881799578666687
    z[7,6,1]  R2519     -5.0700485706329346e-01
    z[7,6,1]  R2520     -7.7167344093322754e-01
    z[7,6,1]  R2521     -8.0269873142242432e-01
    z[7,6,1]  R2522     -3.3003348112106323e-01
    z[7,6,1]  R2523     -3.3140763640403748e-01
    z[7,6,1]  R2524     -7.5931972265243530e-01
    z[7,6,1]  R2525     -1.2345468252897263e-01
    z[7,6,1]  R2526     -7.6918292045593262e-01
    z[7,6,1]  R2527     -0.752150297164917
    z[7,6,1]  R2528     -7.9434764385223389e-01
    z[7,6,1]  R2529     -9.1375911235809326e-01
    z[7,6,1]  R2530     -7.7818918228149414e-01
    z[7,6,1]  R2531     -9.4941031932830811e-01
    z[7,6,1]  R2532     -9.4771158695220947e-01
    z[7,6,1]  R2533     -6.0370171070098877e-01
    z[7,6,1]  R2534     -8.1486070156097412e-01
    z[7,6,1]  R2535     -7.2885221242904663e-01
    z[7,6,1]  R2536     -6.8084597587585449e-01
    z[7,6,1]  R2537     -7.7136713266372681e-01
    z[7,6,1]  R2538     -7.2400116920471191e-01
    z[7,6,1]  R2539     -0.770193874835968
    z[7,6,1]  R2540     -8.5195004940032959e-01
    z[7,6,1]  R2541     4.2647279798984528e-02
    z[7,6,1]  R2542     -8.0612915754318237e-01
    z[7,6,1]  R2543     -3.8849323987960815e-01
    z[7,6,1]  R2544     -3.4533193707466125e-01
    z[7,6,1]  R2545     -5.2539217472076416e-01
    z[7,6,1]  R2546     -3.1653749942779541e-01
    z[7,6,1]  R2547     -3.4983004443347454e-03
    z[7,6,1]  R2548     0.0690355971455574
    z[7,6,1]  R2549     -8.1956321001052856e-01
    z[7,6,1]  R2550     -5.9959208965301514e-01
    z[7,6,1]  R2551     -7.6063059270381927e-02
    z[7,6,1]  R2552     -2.0901305973529816e-01
    z[7,6,1]  R2553     -4.9557766318321228e-01
    z[7,6,1]  R2554     -5.0943940877914429e-01
    z[7,6,1]  R2555     -2.6115508750081062e-02
    z[7,6,1]  R2556     7.8820818662643433e-01
    z[7,6,1]  R2557     9.4797450304031372e-01
    z[7,6,1]  R2558     5.7311809062957764e-01
    z[7,6,1]  R2559     -9.0785082429647446e-03
    z[7,6,1]  R2560     -5.7964098453521729e-01
    z[7,6,1]  R2561     -4.8482900857925415e-01
    z[7,6,1]  R2562     -1.7932601273059845e-01
    z[7,6,1]  R2563     -3.6394849419593811e-01
    z[7,6,1]  R2564     -0.682121753692627
    z[7,6,1]  R2565     -7.4453867971897125e-02
    z[7,6,1]  R2566     6.0457970947027206e-02
    z[7,6,1]  R2567     -0.321254700422287
    z[7,6,1]  R2568     -1.4761339128017426e-01
    z[7,6,1]  R2569     -7.9079437255859375e-01
    z[7,6,1]  R2570     -8.0034458637237549e-01
    z[7,6,1]  R2571     -8.2423675060272217e-01
    z[7,6,1]  R2572     -5.2353560924530029e-02
    z[7,6,1]  R2573     -5.6139910221099854e-01
    z[7,6,1]  R2574     -1.7574384808540344e-01
    z[7,6,1]  R2575     -4.8669952154159546e-01
    z[7,6,1]  R2576     0.811751663684845
    z[7,6,1]  R2577     0.639335036277771
    z[7,6,1]  R2578     7.7055817842483521e-01
    z[7,6,1]  R2579     -9.2000114917755127e-01
    z[7,6,1]  R2580     -8.1789934635162354e-01
    z[7,6,1]  R2581     -5.2259933948516846e-01
    z[7,6,1]  R2582     -0.166182741522789
    z[7,6,1]  R2583     -0.468726247549057
    z[7,6,1]  R2584     -1.8806332349777222e-01
    z[7,6,1]  R2585     8.7126356363296509e-01
    z[7,6,1]  R2586     4.3835404515266418e-01
    z[7,6,1]  R2587     7.1538448333740234e-01
    z[7,6,1]  R2588     5.4896432161331177e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2411     -1
    z[7,6,2]  R2412     1
    z[7,6,2]  R2421     -3.6473503708839417e-01
    z[7,6,2]  R2422     -0.315572589635849
    z[7,6,2]  R2423     2.5939446687698364e-01
    z[7,6,2]  R2424     1.5178416669368744e-01
    z[7,6,2]  R2425     3.3390790224075317e-01
    z[7,6,2]  R2426     4.8268872499465942e-01
    z[7,6,2]  R2427     1.5913186967372894e-01
    z[7,6,2]  R2428     6.3994270563125610e-01
    z[7,6,2]  R2429     2.3718601465225220e-01
    z[7,6,2]  R2430     3.4481936693191528e-01
    z[7,6,2]  R2431     1.7182333767414093e-01
    z[7,6,2]  R2432     2.6018142700195312e-01
    z[7,6,2]  R2433     -4.2362990975379944e-01
    z[7,6,2]  R2434     -2.2558629512786865e-01
    z[7,6,2]  R2435     1.8069089949131012e-01
    z[7,6,2]  R2436     -1.9469912350177765e-01
    z[7,6,2]  R2437     5.2703386172652245e-03
    z[7,6,2]  R2438     -3.4479784965515137e-01
    z[7,6,2]  R2439     -8.1773988902568817e-02
    z[7,6,2]  R2440     2.2669050097465515e-01
    z[7,6,2]  R2441     2.6220592856407166e-01
    z[7,6,2]  R2442     -1.3925200700759888e-01
    z[7,6,2]  R2443     5.2966678142547607e-01
    z[7,6,2]  R2444     -3.4921181201934814e-01
    z[7,6,2]  R2445     1.3471728563308716e-01
    z[7,6,2]  R2446     -4.7267618775367737e-01
    z[7,6,2]  R2447     2.4360284209251404e-01
    z[7,6,2]  R2448     4.5246556401252747e-01
    z[7,6,2]  R2449     3.6115118861198425e-01
    z[7,6,2]  R2450     3.9397758245468140e-01
    z[7,6,2]  R2451     -2.2256558761000633e-02
    z[7,6,2]  R2452     0.428076833486557
    z[7,6,2]  R2453     2.8458023443818092e-03
    z[7,6,2]  R2454     2.1882055699825287e-01
    z[7,6,2]  R2455     1.9023905694484711e-01
    z[7,6,2]  R2456     1.5313657000660896e-02
    z[7,6,2]  R2457     -9.7747206687927246e-02
    z[7,6,2]  R2458     -3.2966170459985733e-02
    z[7,6,2]  R2459     3.1236311793327332e-01
    z[7,6,2]  R2460     -6.5187156200408936e-01
    z[7,6,2]  R2461     -5.4828889667987823e-02
    z[7,6,2]  R2462     1.0606251657009125e-01
    z[7,6,2]  R2463     -2.7343055605888367e-01
    z[7,6,2]  R2464     1.9612836185842752e-03
    z[7,6,2]  R2465     3.8312498945742846e-03
    z[7,6,2]  R2466     -1.1785271763801575e-01
    z[7,6,2]  R2467     -2.9135072231292725e-01
    z[7,6,2]  R2468     6.2200218439102173e-01
    z[7,6,2]  R2469     -1.9933420419692993e-01
    z[7,6,2]  R2470     -9.5623753964900970e-02
    z[7,6,2]  R2471     2.1981850266456604e-02
    z[7,6,2]  R2472     4.2391413450241089e-01
    z[7,6,2]  R2473     -9.2750638723373413e-02
    z[7,6,2]  R2474     1.4911958575248718e-01
    z[7,6,2]  R2475     2.6723194122314453e-01
    z[7,6,2]  R2476     1.3118797540664673e-01
    z[7,6,2]  R2477     -0.584646463394165
    z[7,6,2]  R2478     -5.7222151756286621e-01
    z[7,6,2]  R2479     -9.1069459915161133e-02
    z[7,6,2]  R2480     9.5958143472671509e-02
    z[7,6,2]  R2481     2.0737320184707642e-02
    z[7,6,2]  R2482     -1.0694067925214767e-01
    z[7,6,2]  R2483     1.4552344381809235e-01
    z[7,6,2]  R2484     1.8929733335971832e-01
    z[7,6,2]  R2485     -7.9540058970451355e-02
    z[7,6,2]  R2486     -6.1340779066085815e-01
    z[7,6,2]  R2487     4.8959512263536453e-02
    z[7,6,2]  R2488     -4.5501585118472576e-03
    z[7,6,2]  R2489     1.9258438050746918e-01
    z[7,6,2]  R2490     3.5356727242469788e-01
    z[7,6,2]  R2491     2.0872248709201813e-01
    z[7,6,2]  R2492     -3.4142377972602844e-01
    z[7,6,2]  R2493     1.2800908088684082e-01
    z[7,6,2]  R2494     -9.1829463839530945e-02
    z[7,6,2]  R2495     -2.1675500273704529e-01
    z[7,6,2]  R2496     -2.1271312609314919e-02
    z[7,6,2]  R2497     -1.1073148995637894e-01
    z[7,6,2]  R2498     -3.6913838982582092e-01
    z[7,6,2]  R2499     4.8219002783298492e-02
    z[7,6,2]  R2500     2.4617350101470947e-01
    z[7,6,2]  R2501     0.0839306190609932
    z[7,6,2]  R2502     2.1931204199790955e-01
    z[7,6,2]  R2503     -1.4509050548076630e-01
    z[7,6,2]  R2504     -1.1842354387044907e-01
    z[7,6,2]  R2505     -3.0637830495834351e-01
    z[7,6,2]  R2506     -2.6090177893638611e-01
    z[7,6,2]  R2507     -1.3556927442550659e-01
    z[7,6,2]  R2508     -1.7798444628715515e-01
    z[7,6,2]  R2509     -5.5900290608406067e-02
    z[7,6,2]  R2510     -2.9828870296478271e-01
    z[7,6,2]  R2511     -1.3427162542939186e-02
    z[7,6,2]  R2512     4.1312953829765320e-01
    z[7,6,2]  R2513     -3.4522205591201782e-01
    z[7,6,2]  R2514     0.289383202791214
    z[7,6,2]  R2515     1.4852622523903847e-02
    z[7,6,2]  R2516     2.1137434244155884e-01
    z[7,6,2]  R2517     6.5856881439685822e-02
    z[7,6,2]  R2518     2.1253588795661926e-01
    z[7,6,2]  R2519     1.0035727173089981e-01
    z[7,6,2]  R2520     1.6829672455787659e-01
    z[7,6,2]  R2521     -1.9416575133800507e-01
    z[7,6,2]  R2522     -1.8333847820758820e-01
    z[7,6,2]  R2523     -5.2161026000976562e-01
    z[7,6,2]  R2524     3.4443494677543640e-01
    z[7,6,2]  R2525     2.2141848504543304e-01
    z[7,6,2]  R2526     1.4933940954506397e-02
    z[7,6,2]  R2527     -1.5962953865528107e-01
    z[7,6,2]  R2528     3.8431543856859207e-02
    z[7,6,2]  R2529     0.095056913793087
    z[7,6,2]  R2530     -9.1186009347438812e-02
    z[7,6,2]  R2531     2.2850561141967773e-01
    z[7,6,2]  R2532     1.8350470066070557e-01
    z[7,6,2]  R2533     -1.0992185026407242e-01
    z[7,6,2]  R2534     -6.4968854188919067e-02
    z[7,6,2]  R2535     1.5266297757625580e-01
    z[7,6,2]  R2536     0.0628947913646698
    z[7,6,2]  R2537     -1.3236106932163239e-01
    z[7,6,2]  R2538     1.4494094066321850e-02
    z[7,6,2]  R2539     2.4858203530311584e-01
    z[7,6,2]  R2540     -9.9425628781318665e-02
    z[7,6,2]  R2541     -4.5960783958435059e-01
    z[7,6,2]  R2542     -1.3062451779842377e-01
    z[7,6,2]  R2543     2.0609753206372261e-02
    z[7,6,2]  R2544     -1.2111578881740570e-01
    z[7,6,2]  R2545     -5.5107390880584717e-01
    z[7,6,2]  R2546     -6.5184015035629272e-01
    z[7,6,2]  R2547     1.5165668725967407e-01
    z[7,6,2]  R2548     9.4467557966709137e-02
    z[7,6,2]  R2549     3.7212669849395752e-01
    z[7,6,2]  R2550     0.510319173336029
    z[7,6,2]  R2551     -7.9994976520538330e-01
    z[7,6,2]  R2552     -2.0820085704326630e-01
    z[7,6,2]  R2553     -2.5144013762474060e-01
    z[7,6,2]  R2554     -4.7872957587242126e-01
    z[7,6,2]  R2555     3.4862619638442993e-01
    z[7,6,2]  R2556     -4.0366011857986450e-01
    z[7,6,2]  R2557     -1.7312115430831909e-01
    z[7,6,2]  R2558     -3.5301384329795837e-01
    z[7,6,2]  R2559     -3.4765001386404037e-02
    z[7,6,2]  R2560     4.2130580544471741e-01
    z[7,6,2]  R2561     -5.7477647066116333e-01
    z[7,6,2]  R2562     -0.645080029964447
    z[7,6,2]  R2563     -5.4246175289154053e-01
    z[7,6,2]  R2564     -1.1096552014350891e-01
    z[7,6,2]  R2565     -2.7713960409164429e-01
    z[7,6,2]  R2566     1.6731685400009155e-01
    z[7,6,2]  R2567     -5.4264806210994720e-02
    z[7,6,2]  R2568     -2.9492408037185669e-01
    z[7,6,2]  R2569     -5.9931054711341858e-02
    z[7,6,2]  R2570     5.0907637923955917e-02
    z[7,6,2]  R2571     -5.9057138860225677e-02
    z[7,6,2]  R2572     1.0383627563714981e-01
    z[7,6,2]  R2573     -4.1855287551879883e-01
    z[7,6,2]  R2574     -2.0485353469848633e-01
    z[7,6,2]  R2575     1.7963831126689911e-01
    z[7,6,2]  R2576     -3.7469189614057541e-02
    z[7,6,2]  R2577     -2.6761874556541443e-01
    z[7,6,2]  R2578     -3.3364719152450562e-01
    z[7,6,2]  R2579     3.4020170569419861e-02
    z[7,6,2]  R2580     1.9581666216254234e-02
    z[7,6,2]  R2581     2.5441735982894897e-02
    z[7,6,2]  R2582     -0.199344664812088
    z[7,6,2]  R2583     4.2731454968452454e-01
    z[7,6,2]  R2584     2.1485167741775513e-01
    z[7,6,2]  R2585     -3.7014293670654297e-01
    z[7,6,2]  R2586     3.8449708372354507e-02
    z[7,6,2]  R2587     -2.8615200892090797e-02
    z[7,6,2]  R2588     -3.9972978830337524e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2413     -1
    z[7,6,3]  R2414     1
    z[7,6,3]  R2421     -2.9773136973381042e-01
    z[7,6,3]  R2422     -4.7056525945663452e-01
    z[7,6,3]  R2423     -5.1373803615570068e-01
    z[7,6,3]  R2424     -9.6666947007179260e-02
    z[7,6,3]  R2425     -5.6725364923477173e-01
    z[7,6,3]  R2426     5.3634798526763916e-01
    z[7,6,3]  R2427     -4.5542147755622864e-01
    z[7,6,3]  R2428     3.9375522732734680e-01
    z[7,6,3]  R2429     -3.3225673437118530e-01
    z[7,6,3]  R2430     -6.4335089921951294e-01
    z[7,6,3]  R2431     -6.6603964567184448e-01
    z[7,6,3]  R2432     -2.0372414588928223e-01
    z[7,6,3]  R2433     1.4815287292003632e-01
    z[7,6,3]  R2434     -1.4601313509047031e-02
    z[7,6,3]  R2435     2.0684491097927094e-01
    z[7,6,3]  R2436     -3.8015641272068024e-02
    z[7,6,3]  R2437     4.5650738477706909e-01
    z[7,6,3]  R2438     -2.1075144410133362e-01
    z[7,6,3]  R2439     -1.9165011122822762e-02
    z[7,6,3]  R2440     3.7987983226776123e-01
    z[7,6,3]  R2441     1.0237257182598114e-01
    z[7,6,3]  R2442     3.8853892683982849e-01
    z[7,6,3]  R2443     4.2647641897201538e-01
    z[7,6,3]  R2444     -1.4260447025299072e-01
    z[7,6,3]  R2445     2.6867750287055969e-01
    z[7,6,3]  R2446     -1.5323288738727570e-01
    z[7,6,3]  R2447     2.7281916141510010e-01
    z[7,6,3]  R2448     4.9727344512939453e-01
    z[7,6,3]  R2449     7.3696893453598022e-01
    z[7,6,3]  R2450     2.2377386689186096e-02
    z[7,6,3]  R2451     4.9843266606330872e-01
    z[7,6,3]  R2452     5.5681866407394409e-01
    z[7,6,3]  R2453     -6.0512870550155640e-01
    z[7,6,3]  R2454     0.0890241339802742
    z[7,6,3]  R2455     -4.6217706799507141e-01
    z[7,6,3]  R2456     -4.0138861536979675e-01
    z[7,6,3]  R2457     -6.1015748977661133e-01
    z[7,6,3]  R2458     2.2263512015342712e-01
    z[7,6,3]  R2459     2.0708565413951874e-01
    z[7,6,3]  R2460     -4.8841637372970581e-01
    z[7,6,3]  R2461     1.5461874008178711e-01
    z[7,6,3]  R2462     2.8776556253433228e-01
    z[7,6,3]  R2463     2.1502895653247833e-01
    z[7,6,3]  R2464     -2.0312415063381195e-01
    z[7,6,3]  R2465     -1.0942038893699646e-01
    z[7,6,3]  R2466     -5.6919389963150024e-01
    z[7,6,3]  R2467     -4.9499401450157166e-01
    z[7,6,3]  R2468     -4.2022615671157837e-01
    z[7,6,3]  R2469     1.2178914248943329e-01
    z[7,6,3]  R2470     2.4164592847228050e-02
    z[7,6,3]  R2471     -1.6868244856595993e-02
    z[7,6,3]  R2472     3.1191563606262207e-01
    z[7,6,3]  R2473     9.8548196256160736e-02
    z[7,6,3]  R2474     -2.2359421476721764e-02
    z[7,6,3]  R2475     -1.6333516687154770e-02
    z[7,6,3]  R2476     3.0073146335780621e-03
    z[7,6,3]  R2477     -5.5990648269653320e-01
    z[7,6,3]  R2478     3.5550169646739960e-02
    z[7,6,3]  R2479     8.1884294748306274e-02
    z[7,6,3]  R2480     1.6896691918373108e-01
    z[7,6,3]  R2481     5.1314628124237061e-01
    z[7,6,3]  R2482     1.3779959082603455e-01
    z[7,6,3]  R2483     -1.9642950594425201e-01
    z[7,6,3]  R2484     -5.2982360124588013e-01
    z[7,6,3]  R2485     -3.9600214362144470e-01
    z[7,6,3]  R2486     3.2492477446794510e-02
    z[7,6,3]  R2487     1.7291373014450073e-01
    z[7,6,3]  R2488     -0.0959969162940979
    z[7,6,3]  R2489     1.9805204123258591e-02
    z[7,6,3]  R2490     1.8201887607574463e-02
    z[7,6,3]  R2491     5.6374704837799072e-01
    z[7,6,3]  R2492     -6.0380709171295166e-01
    z[7,6,3]  R2493     1.7328624427318573e-01
    z[7,6,3]  R2494     7.2874200344085693e-01
    z[7,6,3]  R2495     7.1704608201980591e-01
    z[7,6,3]  R2496     -2.5790292024612427e-01
    z[7,6,3]  R2497     6.7493087053298950e-01
    z[7,6,3]  R2498     -1.8290762603282928e-01
    z[7,6,3]  R2499     -3.3907768130302429e-01
    z[7,6,3]  R2500     -2.9924616217613220e-01
    z[7,6,3]  R2501     -3.3888214826583862e-01
    z[7,6,3]  R2502     -5.9020549058914185e-01
    z[7,6,3]  R2503     -2.7884083986282349e-01
    z[7,6,3]  R2504     -5.5373167991638184e-01
    z[7,6,3]  R2505     -1.9600987434387207e-01
    z[7,6,3]  R2506     -3.7111577391624451e-01
    z[7,6,3]  R2507     2.6010829210281372e-01
    z[7,6,3]  R2508     8.1559962034225464e-01
    z[7,6,3]  R2509     1.2610229849815369e-01
    z[7,6,3]  R2510     9.3165948987007141e-02
    z[7,6,3]  R2511     -4.9079051613807678e-01
    z[7,6,3]  R2512     -4.9664461612701416e-01
    z[7,6,3]  R2513     3.9586505293846130e-01
    z[7,6,3]  R2514     2.1753889322280884e-01
    z[7,6,3]  R2515     -5.1467999815940857e-02
    z[7,6,3]  R2516     1.1947729438543320e-01
    z[7,6,3]  R2517     1.1300613731145859e-01
    z[7,6,3]  R2518     -3.8399152457714081e-02
    z[7,6,3]  R2519     3.9864072203636169e-01
    z[7,6,3]  R2520     -0.0781896784901619
    z[7,6,3]  R2521     5.0997996330261230e-01
    z[7,6,3]  R2522     -0.0290201585739851
    z[7,6,3]  R2523     3.3412650227546692e-02
    z[7,6,3]  R2524     6.9710515439510345e-02
    z[7,6,3]  R2525     3.3124664425849915e-01
    z[7,6,3]  R2526     9.6823759377002716e-02
    z[7,6,3]  R2527     2.7094164490699768e-01
    z[7,6,3]  R2528     1.2503567337989807e-01
    z[7,6,3]  R2529     1.2436323612928391e-01
    z[7,6,3]  R2530     -2.3279446363449097e-01
    z[7,6,3]  R2531     -5.4520197212696075e-02
    z[7,6,3]  R2532     -1.1272186040878296e-01
    z[7,6,3]  R2533     -3.9822015166282654e-01
    z[7,6,3]  R2534     1.9771383702754974e-01
    z[7,6,3]  R2535     -3.5733717679977417e-01
    z[7,6,3]  R2536     9.8374977707862854e-02
    z[7,6,3]  R2537     4.0437778830528259e-01
    z[7,6,3]  R2538     3.5644698143005371e-01
    z[7,6,3]  R2539     -3.9706024527549744e-01
    z[7,6,3]  R2540     2.9846101999282837e-01
    z[7,6,3]  R2541     2.7269285917282104e-01
    z[7,6,3]  R2542     1.0264895856380463e-01
    z[7,6,3]  R2543     2.5535422563552856e-01
    z[7,6,3]  R2544     4.0238106250762939e-01
    z[7,6,3]  R2545     -8.0770663917064667e-03
    z[7,6,3]  R2546     7.5806421227753162e-03
    z[7,6,3]  R2547     -1.4889647066593170e-01
    z[7,6,3]  R2548     1.0548835247755051e-01
    z[7,6,3]  R2549     -1.6698397696018219e-02
    z[7,6,3]  R2550     -3.6903306841850281e-01
    z[7,6,3]  R2551     3.1129187345504761e-01
    z[7,6,3]  R2552     2.8346312046051025e-01
    z[7,6,3]  R2553     7.2360301017761230e-01
    z[7,6,3]  R2554     4.1686362028121948e-01
    z[7,6,3]  R2555     1.5570640563964844e-01
    z[7,6,3]  R2556     1.2262795865535736e-01
    z[7,6,3]  R2557     -1.3377287983894348e-01
    z[7,6,3]  R2558     1.1306324601173401e-01
    z[7,6,3]  R2559     5.3718948364257812e-01
    z[7,6,3]  R2560     -0.571797788143158
    z[7,6,3]  R2561     2.1838736534118652e-01
    z[7,6,3]  R2562     3.0689904093742371e-01
    z[7,6,3]  R2563     6.3965070247650146e-01
    z[7,6,3]  R2564     5.1850110292434692e-01
    z[7,6,3]  R2565     5.0610125064849854e-01
    z[7,6,3]  R2566     2.2512586414813995e-01
    z[7,6,3]  R2567     5.3207403421401978e-01
    z[7,6,3]  R2568     6.9865804910659790e-01
    z[7,6,3]  R2569     -2.8843320906162262e-02
    z[7,6,3]  R2570     4.2975005507469177e-01
    z[7,6,3]  R2571     3.2536211609840393e-01
    z[7,6,3]  R2572     5.2024662494659424e-01
    z[7,6,3]  R2573     -1.0241288691759109e-01
    z[7,6,3]  R2574     0.801220178604126
    z[7,6,3]  R2575     4.1895386576652527e-01
    z[7,6,3]  R2576     2.0774005353450775e-01
    z[7,6,3]  R2577     2.7850806713104248e-01
    z[7,6,3]  R2578     -1.0500277578830719e-01
    z[7,6,3]  R2579     -3.9494130760431290e-02
    z[7,6,3]  R2580     -2.1544608473777771e-01
    z[7,6,3]  R2581     -7.8749559819698334e-02
    z[7,6,3]  R2582     8.2119709253311157e-01
    z[7,6,3]  R2583     -5.1762568950653076e-01
    z[7,6,3]  R2584     1.3576522469520569e-01
    z[7,6,3]  R2585     0.0986611545085907
    z[7,6,3]  R2586     7.8905093669891357e-01
    z[7,6,3]  R2587     -2.1489325165748596e-01
    z[7,6,3]  R2588     -4.4135209918022156e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2415     -1
    z[7,6,4]  R2416     1
    z[7,6,4]  R2421     -0.514081597328186
    z[7,6,4]  R2422     -1.2707982957363129e-01
    z[7,6,4]  R2423     -2.6603189110755920e-01
    z[7,6,4]  R2424     6.1554533243179321e-01
    z[7,6,4]  R2425     -4.0420621633529663e-01
    z[7,6,4]  R2426     1.7329661548137665e-01
    z[7,6,4]  R2427     1.4906750619411469e-01
    z[7,6,4]  R2428     2.7997341752052307e-01
    z[7,6,4]  R2429     1.4735132455825806e-02
    z[7,6,4]  R2430     1.0696996748447418e-01
    z[7,6,4]  R2431     -3.8329381495714188e-02
    z[7,6,4]  R2432     2.4498523771762848e-01
    z[7,6,4]  R2433     -3.0189722776412964e-01
    z[7,6,4]  R2434     -1.3840667903423309e-01
    z[7,6,4]  R2435     1.9698446616530418e-02
    z[7,6,4]  R2436     -4.2618361115455627e-01
    z[7,6,4]  R2437     9.0292975306510925e-02
    z[7,6,4]  R2438     4.4573080539703369e-01
    z[7,6,4]  R2439     7.0526683330535889e-01
    z[7,6,4]  R2440     2.2930772602558136e-01
    z[7,6,4]  R2441     2.5002929568290710e-01
    z[7,6,4]  R2442     -3.4208881855010986e-01
    z[7,6,4]  R2443     1.9140517711639404e-01
    z[7,6,4]  R2444     -8.0715966224670410e-01
    z[7,6,4]  R2445     -3.9832934737205505e-01
    z[7,6,4]  R2446     9.0377889573574066e-02
    z[7,6,4]  R2447     -5.5513745546340942e-01
    z[7,6,4]  R2448     1.2700709700584412e-01
    z[7,6,4]  R2449     -8.0024421215057373e-02
    z[7,6,4]  R2450     -3.8305470347404480e-01
    z[7,6,4]  R2451     2.8270408511161804e-01
    z[7,6,4]  R2452     -3.2083618640899658e-01
    z[7,6,4]  R2453     -3.7383839488029480e-01
    z[7,6,4]  R2454     -2.9608780145645142e-01
    z[7,6,4]  R2455     2.8118072077631950e-02
    z[7,6,4]  R2456     -2.6770675182342529e-01
    z[7,6,4]  R2457     2.5118380784988403e-01
    z[7,6,4]  R2458     -6.5479505062103271e-01
    z[7,6,4]  R2459     -4.5285901427268982e-01
    z[7,6,4]  R2460     0.0766245424747467
    z[7,6,4]  R2461     -3.6809706687927246e-01
    z[7,6,4]  R2462     4.2856097221374512e-02
    z[7,6,4]  R2463     1.2355703860521317e-01
    z[7,6,4]  R2464     -1.7000260949134827e-01
    z[7,6,4]  R2465     -1.7644479870796204e-02
    z[7,6,4]  R2466     -5.0424743443727493e-02
    z[7,6,4]  R2467     4.4696271419525146e-01
    z[7,6,4]  R2468     -0.0360000804066658
    z[7,6,4]  R2469     -7.9047113656997681e-02
    z[7,6,4]  R2470     -4.9157503992319107e-02
    z[7,6,4]  R2471     1.4077517390251160e-01
    z[7,6,4]  R2472     -2.8249008581042290e-02
    z[7,6,4]  R2473     -5.6559729576110840e-01
    z[7,6,4]  R2474     -6.1346596479415894e-01
    z[7,6,4]  R2475     1.0119650512933731e-02
    z[7,6,4]  R2476     1.6915602609515190e-02
    z[7,6,4]  R2477     -3.8995620608329773e-01
    z[7,6,4]  R2478     -2.7812096476554871e-01
    z[7,6,4]  R2479     2.9832589626312256e-01
    z[7,6,4]  R2480     -3.5633894801139832e-01
    z[7,6,4]  R2481     4.3829031288623810e-02
    z[7,6,4]  R2482     1.8756887875497341e-03
    z[7,6,4]  R2483     -3.6813512444496155e-01
    z[7,6,4]  R2484     1.4003157615661621e-01
    z[7,6,4]  R2485     3.8114407658576965e-01
    z[7,6,4]  R2486     -2.4910818040370941e-01
    z[7,6,4]  R2487     6.7822217941284180e-02
    z[7,6,4]  R2488     -1.9547192752361298e-01
    z[7,6,4]  R2489     -1.9871446490287781e-01
    z[7,6,4]  R2490     5.5680975317955017e-02
    z[7,6,4]  R2491     1.2122242152690887e-01
    z[7,6,4]  R2492     1.2970919907093048e-01
    z[7,6,4]  R2493     -3.7139644846320152e-03
    z[7,6,4]  R2494     -1.3720582425594330e-01
    z[7,6,4]  R2495     1.1584879830479622e-03
    z[7,6,4]  R2496     -3.3810895681381226e-01
    z[7,6,4]  R2497     2.6022934913635254e-01
    z[7,6,4]  R2498     1.8798503279685974e-01
    z[7,6,4]  R2499     -4.6573806554079056e-02
    z[7,6,4]  R2500     -1.8613596260547638e-01
    z[7,6,4]  R2501     4.7604110091924667e-02
    z[7,6,4]  R2502     -1.3970064930617809e-02
    z[7,6,4]  R2503     3.3509659767150879e-01
    z[7,6,4]  R2504     4.5216381549835205e-01
    z[7,6,4]  R2505     4.3756440281867981e-01
    z[7,6,4]  R2506     3.0622169375419617e-01
    z[7,6,4]  R2507     -3.3020820468664169e-02
    z[7,6,4]  R2508     -4.0312924981117249e-01
    z[7,6,4]  R2509     2.3207981884479523e-01
    z[7,6,4]  R2510     1.8537633121013641e-01
    z[7,6,4]  R2511     5.0928640365600586e-01
    z[7,6,4]  R2512     -1.3969862461090088e-01
    z[7,6,4]  R2513     3.4669709205627441e-01
    z[7,6,4]  R2514     -1.7271824181079865e-01
    z[7,6,4]  R2515     3.9200261235237122e-02
    z[7,6,4]  R2516     9.2002548277378082e-02
    z[7,6,4]  R2517     -1.8937504291534424e-01
    z[7,6,4]  R2518     -1.4360065758228302e-01
    z[7,6,4]  R2519     -2.8094735741615295e-01
    z[7,6,4]  R2520     -2.1369270980358124e-02
    z[7,6,4]  R2521     3.4329418092966080e-02
    z[7,6,4]  R2522     -6.6291856765747070e-01
    z[7,6,4]  R2523     -4.8803728818893433e-01
    z[7,6,4]  R2524     -1.5790884196758270e-01
    z[7,6,4]  R2525     -5.5078315734863281e-01
    z[7,6,4]  R2526     -8.3766520023345947e-02
    z[7,6,4]  R2527     -2.1506768465042114e-01
    z[7,6,4]  R2528     2.0711828768253326e-01
    z[7,6,4]  R2529     -3.0013337731361389e-02
    z[7,6,4]  R2530     2.7905574440956116e-01
    z[7,6,4]  R2531     -4.8334106802940369e-02
    z[7,6,4]  R2532     -3.0210144817829132e-02
    z[7,6,4]  R2533     5.2105122804641724e-01
    z[7,6,4]  R2534     -1.3227945193648338e-02
    z[7,6,4]  R2535     2.3158590495586395e-01
    z[7,6,4]  R2536     2.3669071495532990e-01
    z[7,6,4]  R2537     4.9811866134405136e-02
    z[7,6,4]  R2538     1.8622530996799469e-01
    z[7,6,4]  R2539     2.2148312628269196e-01
    z[7,6,4]  R2540     3.5426761955022812e-02
    z[7,6,4]  R2541     -2.9519531130790710e-01
    z[7,6,4]  R2542     4.0074518322944641e-01
    z[7,6,4]  R2543     -2.4200105667114258e-01
    z[7,6,4]  R2544     1.2927709519863129e-01
    z[7,6,4]  R2545     2.2059883177280426e-01
    z[7,6,4]  R2546     2.1980078890919685e-02
    z[7,6,4]  R2547     1.5698119997978210e-01
    z[7,6,4]  R2548     -7.6411046087741852e-02
    z[7,6,4]  R2549     -1.6664180159568787e-01
    z[7,6,4]  R2550     -3.8733837008476257e-01
    z[7,6,4]  R2551     -7.0992313325405121e-02
    z[7,6,4]  R2552     3.9768660068511963e-01
    z[7,6,4]  R2553     -1.9679825007915497e-01
    z[7,6,4]  R2554     -0.302804559469223
    z[7,6,4]  R2555     -3.0368554592132568e-01
    z[7,6,4]  R2556     1.0551684349775314e-01
    z[7,6,4]  R2557     -1.9355788826942444e-02
    z[7,6,4]  R2558     6.2445417046546936e-02
    z[7,6,4]  R2559     -1.5688581764698029e-01
    z[7,6,4]  R2560     -1.8737266957759857e-01
    z[7,6,4]  R2561     1.3259534537792206e-01
    z[7,6,4]  R2562     -1.9866687059402466e-01
    z[7,6,4]  R2563     -3.0559748411178589e-01
    z[7,6,4]  R2564     1.3698628544807434e-01
    z[7,6,4]  R2565     -5.0602819770574570e-02
    z[7,6,4]  R2566     -1.5582096576690674e-01
    z[7,6,4]  R2567     -4.6497333049774170e-01
    z[7,6,4]  R2568     6.6649354994297028e-02
    z[7,6,4]  R2569     1.2416181713342667e-01
    z[7,6,4]  R2570     3.8874413818120956e-02
    z[7,6,4]  R2571     1.6988384723663330e-01
    z[7,6,4]  R2572     -6.0564088821411133e-01
    z[7,6,4]  R2573     5.5132603645324707e-01
    z[7,6,4]  R2574     -6.8614810705184937e-02
    z[7,6,4]  R2575     -0.664197564125061
    z[7,6,4]  R2576     -4.2081409692764282e-01
    z[7,6,4]  R2577     -1.2498825043439865e-01
    z[7,6,4]  R2578     1.0058642923831940e-01
    z[7,6,4]  R2579     4.0197573602199554e-02
    z[7,6,4]  R2580     8.1931173801422119e-02
    z[7,6,4]  R2581     4.4640928506851196e-02
    z[7,6,4]  R2582     -1.0576204210519791e-01
    z[7,6,4]  R2583     6.1329182237386703e-02
    z[7,6,4]  R2584     6.8140506744384766e-02
    z[7,6,4]  R2585     1.2142547965049744e-01
    z[7,6,4]  R2586     -1.1520221084356308e-01
    z[7,6,4]  R2587     -1.8276037275791168e-01
    z[7,6,4]  R2588     2.3541533946990967e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2417     -1
    z[7,6,5]  R2418     1
    z[7,6,5]  R2421     5.9163773059844971e-01
    z[7,6,5]  R2422     8.0719190835952759e-01
    z[7,6,5]  R2423     -4.1230313479900360e-02
    z[7,6,5]  R2424     0.662135660648346
    z[7,6,5]  R2425     2.0706829428672791e-01
    z[7,6,5]  R2426     3.3804544806480408e-01
    z[7,6,5]  R2427     9.5515400171279907e-02
    z[7,6,5]  R2428     0.505935549736023
    z[7,6,5]  R2429     1.1857295036315918e-01
    z[7,6,5]  R2430     2.4743312597274780e-01
    z[7,6,5]  R2431     -2.0205296576023102e-01
    z[7,6,5]  R2432     2.1121473610401154e-01
    z[7,6,5]  R2433     -2.5830811262130737e-01
    z[7,6,5]  R2434     -5.7815372943878174e-02
    z[7,6,5]  R2435     -1.8703229725360870e-01
    z[7,6,5]  R2436     1.1776927113533020e-01
    z[7,6,5]  R2437     -1.4460229873657227e-01
    z[7,6,5]  R2438     -2.6085074990987778e-02
    z[7,6,5]  R2439     -3.1523931026458740e-01
    z[7,6,5]  R2440     4.5445635914802551e-01
    z[7,6,5]  R2441     4.9852064251899719e-01
    z[7,6,5]  R2442     7.3102825880050659e-01
    z[7,6,5]  R2443     -0.29815673828125
    z[7,6,5]  R2444     5.6530215078964829e-04
    z[7,6,5]  R2445     6.0024946928024292e-01
    z[7,6,5]  R2446     0.0422833114862442
    z[7,6,5]  R2447     -4.9906989932060242e-01
    z[7,6,5]  R2448     -2.4751673638820648e-01
    z[7,6,5]  R2449     5.0589424371719360e-01
    z[7,6,5]  R2450     4.6643459796905518e-01
    z[7,6,5]  R2451     4.9176892638206482e-01
    z[7,6,5]  R2452     4.5104572176933289e-01
    z[7,6,5]  R2453     -2.8282532095909119e-01
    z[7,6,5]  R2454     9.0691685676574707e-02
    z[7,6,5]  R2455     9.3692235648632050e-02
    z[7,6,5]  R2456     8.2366280257701874e-02
    z[7,6,5]  R2457     -1.0965884663164616e-02
    z[7,6,5]  R2458     1.4352850615978241e-01
    z[7,6,5]  R2459     5.3257197141647339e-01
    z[7,6,5]  R2460     6.5734423696994781e-02
    z[7,6,5]  R2461     9.0009754896163940e-01
    z[7,6,5]  R2462     -5.0257092714309692e-01
    z[7,6,5]  R2463     -3.0434669926762581e-02
    z[7,6,5]  R2464     -5.0444877706468105e-03
    z[7,6,5]  R2465     6.1857527494430542e-01
    z[7,6,5]  R2466     5.2670907229185104e-02
    z[7,6,5]  R2467     -1.1368764191865921e-01
    z[7,6,5]  R2468     -1.4943751692771912e-01
    z[7,6,5]  R2469     3.6455500870943069e-02
    z[7,6,5]  R2470     -2.2192882001399994e-01
    z[7,6,5]  R2471     5.3731882572174072e-01
    z[7,6,5]  R2472     7.1017998456954956e-01
    z[7,6,5]  R2473     1.2367139756679535e-01
    z[7,6,5]  R2474     -1.6047137975692749e-01
    z[7,6,5]  R2475     2.0586515963077545e-01
    z[7,6,5]  R2476     5.5116474628448486e-01
    z[7,6,5]  R2477     -0.068540558218956
    z[7,6,5]  R2478     -0.0843089371919632
    z[7,6,5]  R2479     1.7187568545341492e-01
    z[7,6,5]  R2480     -1.1723558604717255e-01
    z[7,6,5]  R2481     7.7866941690444946e-01
    z[7,6,5]  R2482     6.6610980033874512e-01
    z[7,6,5]  R2483     -3.2666981220245361e-01
    z[7,6,5]  R2484     -3.5131010413169861e-01
    z[7,6,5]  R2485     1.1444703489542007e-01
    z[7,6,5]  R2486     -6.0068786144256592e-02
    z[7,6,5]  R2487     -1.2698693573474884e-01
    z[7,6,5]  R2488     -1.7714734375476837e-01
    z[7,6,5]  R2489     -2.4065764620900154e-02
    z[7,6,5]  R2490     -1.6155165433883667e-01
    z[7,6,5]  R2491     7.4525499343872070e-01
    z[7,6,5]  R2492     3.1178635358810425e-01
    z[7,6,5]  R2493     -1.3313570991158485e-02
    z[7,6,5]  R2494     -8.8597349822521210e-02
    z[7,6,5]  R2495     -1.8960566818714142e-01
    z[7,6,5]  R2496     -1.9285212457180023e-01
    z[7,6,5]  R2497     -1.8472701311111450e-01
    z[7,6,5]  R2498     5.1409624516963959e-02
    z[7,6,5]  R2499     5.0448134541511536e-02
    z[7,6,5]  R2500     3.5628405213356018e-01
    z[7,6,5]  R2501     4.9841940402984619e-01
    z[7,6,5]  R2502     2.3097988963127136e-01
    z[7,6,5]  R2503     3.3193412423133850e-01
    z[7,6,5]  R2504     -9.6335709095001221e-02
    z[7,6,5]  R2505     1.0548584163188934e-02
    z[7,6,5]  R2506     -4.0202800184488297e-02
    z[7,6,5]  R2507     0.355111688375473
    z[7,6,5]  R2508     -1.7216829583048820e-02
    z[7,6,5]  R2509     3.4412688016891479e-01
    z[7,6,5]  R2510     5.2093285322189331e-01
    z[7,6,5]  R2511     -1.3080455362796783e-01
    z[7,6,5]  R2512     -1.1704389750957489e-01
    z[7,6,5]  R2513     1.8582293391227722e-01
    z[7,6,5]  R2514     -1.4288491010665894e-01
    z[7,6,5]  R2515     1.0768998414278030e-01
    z[7,6,5]  R2516     -2.9755065217614174e-02
    z[7,6,5]  R2517     1.2650847434997559e-01
    z[7,6,5]  R2518     6.8607471883296967e-02
    z[7,6,5]  R2519     3.4096702933311462e-01
    z[7,6,5]  R2520     2.5523445010185242e-01
    z[7,6,5]  R2521     -2.1300630643963814e-02
    z[7,6,5]  R2522     4.8581507802009583e-01
    z[7,6,5]  R2523     5.2268964052200317e-01
    z[7,6,5]  R2524     -1.1703015118837357e-01
    z[7,6,5]  R2525     4.3361055850982666e-01
    z[7,6,5]  R2526     -4.6812698245048523e-01
    z[7,6,5]  R2527     1.3619804382324219e-01
    z[7,6,5]  R2528     -2.6303318142890930e-01
    z[7,6,5]  R2529     3.7050571292638779e-02
    z[7,6,5]  R2530     -1.2478940188884735e-01
    z[7,6,5]  R2531     8.6288809776306152e-02
    z[7,6,5]  R2532     -1.6528807580471039e-01
    z[7,6,5]  R2533     3.5488995909690857e-01
    z[7,6,5]  R2534     1.9388712942600250e-01
    z[7,6,5]  R2535     -9.8234914243221283e-02
    z[7,6,5]  R2536     6.5929156541824341e-01
    z[7,6,5]  R2537     -1.6213320195674896e-01
    z[7,6,5]  R2538     3.0738005042076111e-01
    z[7,6,5]  R2539     3.4320649504661560e-01
    z[7,6,5]  R2540     -1.9283334910869598e-01
    z[7,6,5]  R2541     6.1310482025146484e-01
    z[7,6,5]  R2542     2.9591289162635803e-01
    z[7,6,5]  R2543     -1.7603531479835510e-01
    z[7,6,5]  R2544     8.6186133325099945e-02
    z[7,6,5]  R2545     2.8385239839553833e-01
    z[7,6,5]  R2546     2.4412062764167786e-01
    z[7,6,5]  R2547     5.2332830429077148e-01
    z[7,6,5]  R2548     4.1580680012702942e-01
    z[7,6,5]  R2549     -1.2333630770444870e-01
    z[7,6,5]  R2550     -0.0711502805352211
    z[7,6,5]  R2551     4.6585026383399963e-01
    z[7,6,5]  R2552     3.6016803979873657e-01
    z[7,6,5]  R2553     3.2151695340871811e-02
    z[7,6,5]  R2554     -4.0721049904823303e-01
    z[7,6,5]  R2555     1.1348453909158707e-01
    z[7,6,5]  R2556     -3.0042484402656555e-01
    z[7,6,5]  R2557     -9.7968660295009613e-02
    z[7,6,5]  R2558     -2.2801715135574341e-01
    z[7,6,5]  R2559     3.3695498108863831e-01
    z[7,6,5]  R2560     -1.9032275676727295e-01
    z[7,6,5]  R2561     2.3500597476959229e-01
    z[7,6,5]  R2562     0.0966220423579216
    z[7,6,5]  R2563     6.5530523657798767e-02
    z[7,6,5]  R2564     4.1757243871688843e-01
    z[7,6,5]  R2565     3.0980497598648071e-01
    z[7,6,5]  R2566     3.6398828029632568e-01
    z[7,6,5]  R2567     3.1032985448837280e-01
    z[7,6,5]  R2568     4.4034352898597717e-01
    z[7,6,5]  R2569     2.8430068492889404e-01
    z[7,6,5]  R2570     2.5482922792434692e-01
    z[7,6,5]  R2571     -1.6160987317562103e-01
    z[7,6,5]  R2572     2.4246735870838165e-01
    z[7,6,5]  R2573     -1.6973756253719330e-01
    z[7,6,5]  R2574     3.9245158433914185e-01
    z[7,6,5]  R2575     -7.2402499616146088e-02
    z[7,6,5]  R2576     -2.5813108682632446e-01
    z[7,6,5]  R2577     -2.4999319016933441e-01
    z[7,6,5]  R2578     -1.6648904979228973e-01
    z[7,6,5]  R2579     -3.2943961024284363e-01
    z[7,6,5]  R2580     -3.5980053246021271e-02
    z[7,6,5]  R2581     -3.1049215793609619e-01
    z[7,6,5]  R2582     2.8177076578140259e-01
    z[7,6,5]  R2583     -1.1477879434823990e-01
    z[7,6,5]  R2584     2.0424258708953857e-01
    z[7,6,5]  R2585     6.9125302135944366e-02
    z[7,6,5]  R2586     -7.8146345913410187e-02
    z[7,6,5]  R2587     -3.4167268872261047e-01
    z[7,6,5]  R2588     -3.8538447022438049e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2419     -1
    z[7,6,6]  R2420     1
    z[7,6,6]  R2421     -3.6366802453994751e-01
    z[7,6,6]  R2422     6.7211896181106567e-02
    z[7,6,6]  R2423     1.0299152135848999e-01
    z[7,6,6]  R2424     2.5076711177825928e-01
    z[7,6,6]  R2425     1.7573399841785431e-01
    z[7,6,6]  R2426     -1.8029412627220154e-01
    z[7,6,6]  R2427     1.7178039252758026e-01
    z[7,6,6]  R2428     0.165541410446167
    z[7,6,6]  R2429     -4.0061435103416443e-01
    z[7,6,6]  R2430     -2.2367390990257263e-01
    z[7,6,6]  R2431     -0.330437034368515
    z[7,6,6]  R2432     -0.226243257522583
    z[7,6,6]  R2433     -0.0281552542001009
    z[7,6,6]  R2434     4.6129834651947021e-01
    z[7,6,6]  R2435     9.8311454057693481e-02
    z[7,6,6]  R2436     1.8066602945327759e-01
    z[7,6,6]  R2437     2.7286899089813232e-01
    z[7,6,6]  R2438     -5.1402223110198975e-01
    z[7,6,6]  R2439     -3.6391206085681915e-03
    z[7,6,6]  R2440     -4.3184596300125122e-01
    z[7,6,6]  R2441     -3.0547572299838066e-02
    z[7,6,6]  R2442     2.7921709418296814e-01
    z[7,6,6]  R2443     -1.1102665215730667e-01
    z[7,6,6]  R2444     -3.9580602198839188e-02
    z[7,6,6]  R2445     2.2164296358823776e-02
    z[7,6,6]  R2446     -2.5061666965484619e-01
    z[7,6,6]  R2447     2.1673756837844849e-01
    z[7,6,6]  R2448     7.0413582026958466e-02
    z[7,6,6]  R2449     2.4492797255516052e-01
    z[7,6,6]  R2450     4.5410472154617310e-01
    z[7,6,6]  R2451     -5.8907425403594971e-01
    z[7,6,6]  R2452     9.8338752985000610e-02
    z[7,6,6]  R2453     -1.3167785108089447e-01
    z[7,6,6]  R2454     3.8783612847328186e-01
    z[7,6,6]  R2455     7.5318306684494019e-01
    z[7,6,6]  R2456     4.1969934105873108e-01
    z[7,6,6]  R2457     5.3025788068771362e-01
    z[7,6,6]  R2458     -5.0580805540084839e-01
    z[7,6,6]  R2459     -0.331859827041626
    z[7,6,6]  R2460     -5.8802329003810883e-02
    z[7,6,6]  R2461     2.2911757230758667e-02
    z[7,6,6]  R2462     2.7257823944091797e-01
    z[7,6,6]  R2463     3.5895255208015442e-01
    z[7,6,6]  R2464     -0.0967012494802475
    z[7,6,6]  R2465     -5.7264614105224609e-01
    z[7,6,6]  R2466     4.1925567388534546e-01
    z[7,6,6]  R2467     0.0626790001988411
    z[7,6,6]  R2468     3.5951954126358032e-01
    z[7,6,6]  R2469     -2.6943216100335121e-02
    z[7,6,6]  R2470     6.1659656465053558e-02
    z[7,6,6]  R2471     -5.6406247615814209e-01
    z[7,6,6]  R2472     2.7087292075157166e-01
    z[7,6,6]  R2473     1.2039686739444733e-01
    z[7,6,6]  R2474     -5.1999503374099731e-01
    z[7,6,6]  R2475     4.2394686490297318e-02
    z[7,6,6]  R2476     -7.0953494310379028e-01
    z[7,6,6]  R2477     -1.5739767253398895e-01
    z[7,6,6]  R2478     -5.2332168817520142e-01
    z[7,6,6]  R2479     1.5810205042362213e-01
    z[7,6,6]  R2480     -4.7031126916408539e-02
    z[7,6,6]  R2481     -1.8030360341072083e-01
    z[7,6,6]  R2482     -7.2309148311614990e-01
    z[7,6,6]  R2483     3.3120226860046387e-01
    z[7,6,6]  R2484     4.0426653623580933e-01
    z[7,6,6]  R2485     4.0536105632781982e-01
    z[7,6,6]  R2486     -3.6374846100807190e-01
    z[7,6,6]  R2487     -1.3886626809835434e-02
    z[7,6,6]  R2488     -1.3277682662010193e-01
    z[7,6,6]  R2489     0.0638522282242775
    z[7,6,6]  R2490     1.0440131276845932e-01
    z[7,6,6]  R2491     0.191190704703331
    z[7,6,6]  R2492     4.4415897130966187e-01
    z[7,6,6]  R2493     3.3849492669105530e-02
    z[7,6,6]  R2494     -1.6048131883144379e-01
    z[7,6,6]  R2495     2.4727353453636169e-01
    z[7,6,6]  R2496     -1.9234076142311096e-02
    z[7,6,6]  R2497     8.0929987132549286e-02
    z[7,6,6]  R2498     1.6371706128120422e-01
    z[7,6,6]  R2499     -3.0224621295928955e-02
    z[7,6,6]  R2500     -3.0544428154826164e-02
    z[7,6,6]  R2501     -1.0236737877130508e-01
    z[7,6,6]  R2502     -1.8589726090431213e-01
    z[7,6,6]  R2503     2.1918751299381256e-03
    z[7,6,6]  R2504     0.079471655189991
    z[7,6,6]  R2505     1.1661176383495331e-01
    z[7,6,6]  R2506     -4.5812937617301941e-01
    z[7,6,6]  R2507     -9.5765674486756325e-03
    z[7,6,6]  R2508     1.1679705977439880e-01
    z[7,6,6]  R2509     -1.1486873030662537e-01
    z[7,6,6]  R2510     -4.6692779660224915e-01
    z[7,6,6]  R2511     1.4410948380827904e-02
    z[7,6,6]  R2512     -2.3125639557838440e-01
    z[7,6,6]  R2513     -2.1750238537788391e-01
    z[7,6,6]  R2514     3.6757946014404297e-01
    z[7,6,6]  R2515     1.0941742360591888e-01
    z[7,6,6]  R2516     2.4398863315582275e-02
    z[7,6,6]  R2517     0.0702752098441124
    z[7,6,6]  R2518     -2.9970180243253708e-02
    z[7,6,6]  R2519     1.3765922188758850e-01
    z[7,6,6]  R2520     -3.8214033842086792e-01
    z[7,6,6]  R2521     -2.1635919809341431e-01
    z[7,6,6]  R2522     1.9490335881710052e-01
    z[7,6,6]  R2523     -2.4053165316581726e-01
    z[7,6,6]  R2524     3.0572479963302612e-01
    z[7,6,6]  R2525     -1.2226716615259647e-02
    z[7,6,6]  R2526     -1.4560225419700146e-02
    z[7,6,6]  R2527     4.7664329409599304e-01
    z[7,6,6]  R2528     4.6030825376510620e-01
    z[7,6,6]  R2529     -2.3105631768703461e-01
    z[7,6,6]  R2530     -4.4470822811126709e-01
    z[7,6,6]  R2531     1.3618775643408298e-02
    z[7,6,6]  R2532     -0.049640953540802
    z[7,6,6]  R2533     -0.259581595659256
    z[7,6,6]  R2534     -3.6433029174804688e-01
    z[7,6,6]  R2535     2.9331985116004944e-01
    z[7,6,6]  R2536     1.3550363481044769e-01
    z[7,6,6]  R2537     1.5716609358787537e-01
    z[7,6,6]  R2538     0.46355140209198
    z[7,6,6]  R2539     2.0093612372875214e-02
    z[7,6,6]  R2540     1.1167913675308228e-02
    z[7,6,6]  R2541     6.5813146531581879e-02
    z[7,6,6]  R2542     1.8022309243679047e-01
    z[7,6,6]  R2543     9.1388203203678131e-02
    z[7,6,6]  R2544     5.4702490568161011e-01
    z[7,6,6]  R2545     1.7998608946800232e-01
    z[7,6,6]  R2546     5.0963789224624634e-01
    z[7,6,6]  R2547     1.6429116949439049e-02
    z[7,6,6]  R2548     -2.5223836302757263e-01
    z[7,6,6]  R2549     3.8169443607330322e-01
    z[7,6,6]  R2550     -8.0177947878837585e-02
    z[7,6,6]  R2551     0.0874348059296608
    z[7,6,6]  R2552     1.4457820355892181e-01
    z[7,6,6]  R2553     3.1224694848060608e-01
    z[7,6,6]  R2554     2.7112990617752075e-01
    z[7,6,6]  R2555     2.1874293684959412e-01
    z[7,6,6]  R2556     -2.8557786345481873e-01
    z[7,6,6]  R2557     -1.9834528863430023e-01
    z[7,6,6]  R2558     -5.3242433071136475e-01
    z[7,6,6]  R2559     3.0272516608238220e-01
    z[7,6,6]  R2560     -1.3332915306091309e-01
    z[7,6,6]  R2561     2.7723437547683716e-01
    z[7,6,6]  R2562     5.3015863895416260e-01
    z[7,6,6]  R2563     6.3868030905723572e-02
    z[7,6,6]  R2564     9.1345183551311493e-02
    z[7,6,6]  R2565     -6.0760229825973511e-01
    z[7,6,6]  R2566     -2.4147087242454290e-04
    z[7,6,6]  R2567     -5.2079045772552490e-01
    z[7,6,6]  R2568     -1.7207440733909607e-01
    z[7,6,6]  R2569     -5.1508295536041260e-01
    z[7,6,6]  R2570     3.1199935078620911e-01
    z[7,6,6]  R2571     3.9095902442932129e-01
    z[7,6,6]  R2572     -2.7082201838493347e-01
    z[7,6,6]  R2573     -2.7292063832283020e-01
    z[7,6,6]  R2574     -1.0957321152091026e-02
    z[7,6,6]  R2575     -2.5969070196151733e-01
    z[7,6,6]  R2576     -1.3700519502162933e-01
    z[7,6,6]  R2577     -4.0275490283966064e-01
    z[7,6,6]  R2578     -4.9255305528640747e-01
    z[7,6,6]  R2579     -2.0176558196544647e-01
    z[7,6,6]  R2580     -0.392668753862381
    z[7,6,6]  R2581     2.4300108850002289e-01
    z[7,6,6]  R2582     -0.00647188164293766
    z[7,6,6]  R2583     5.4791235923767090e-01
    z[7,6,6]  R2584     0.568831205368042
    z[7,6,6]  R2585     -2.7207210659980774e-01
    z[7,6,6]  R2586     4.0409117937088013e-01
    z[7,6,6]  R2587     -4.2171877622604370e-01
    z[7,6,6]  R2588     -1.4311835169792175e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[4,6]
 BV BND1      phi[6,4]
 BV BND1      phi[4,7]
 BV BND1      phi[7,4]
 BV BND1      phi[4,9]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[4,6,0]
 FR BND1      z[4,6,1]
 FR BND1      z[4,6,2]
 FR BND1      z[4,6,3]
 FR BND1      z[4,6,4]
 FR BND1      z[4,6,5]
 FR BND1      z[4,6,6]
 FR BND1      z[6,4,0]
 FR BND1      z[6,4,1]
 FR BND1      z[6,4,2]
 FR BND1      z[6,4,3]
 FR BND1      z[6,4,4]
 FR BND1      z[6,4,5]
 FR BND1      z[6,4,6]
 FR BND1      z[4,7,0]
 FR BND1      z[4,7,1]
 FR BND1      z[4,7,2]
 FR BND1      z[4,7,3]
 FR BND1      z[4,7,4]
 FR BND1      z[4,7,5]
 FR BND1      z[4,7,6]
 FR BND1      z[7,4,0]
 FR BND1      z[7,4,1]
 FR BND1      z[7,4,2]
 FR BND1      z[7,4,3]
 FR BND1      z[7,4,4]
 FR BND1      z[7,4,5]
 FR BND1      z[7,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
