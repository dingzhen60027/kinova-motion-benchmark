NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 E  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -3.0999999046325684e+00
    phi[0,1]  R58       -2.2400000095367432e+00
    phi[0,1]  R59       -2.2400000095367432e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       -3.0999999046325684e+00
    phi[0,1]  R62       -2.5699999332427979e+00
    phi[0,1]  R63       -2.5699999332427979e+00
    phi[0,1]  R64       -3.0999999046325684e+00
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -2.0899999141693115e+00
    phi[0,1]  R67       -2.0899999141693115e+00
    phi[0,1]  R68       -3.0999999046325684e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       2.4020302295684814e+00
    phi[0,1]  R71       1.8663100004196167e+00
    phi[0,1]  R72       1.2075568437576294e+00
    phi[0,1]  R73       2.2898702621459961e+00
    phi[0,1]  R74       1.8036298751831055e+00
    phi[0,1]  R75       1.2551194429397583e+00
    phi[0,1]  R76       1.0073455572128296e+00
    phi[0,1]  R77       1.1078791618347168e+00
    phi[0,1]  R78       1.7470195293426514e+00
    phi[0,1]  R79       7.1696835756301880e-01
    phi[0,1]  R80       2.1950934827327728e-01
    phi[0,1]  R81       -9.4267219305038452e-01
    phi[0,1]  R82       4.4595929980278015e-01
    phi[0,1]  R83       1.6984882354736328e+00
    phi[0,1]  R84       1.1040562391281128e+00
    phi[0,1]  R85       8.2908284664154053e-01
    phi[0,1]  R86       -3.1365036964416504e-01
    phi[0,1]  R87       -1.8160487413406372e+00
    phi[0,1]  R88       9.5543837547302246e-01
    phi[0,1]  R89       -1.7526619434356689e+00
    phi[0,1]  R90       -2.7599352598190308e-01
    phi[0,1]  R91       -1.4340424537658691e+00
    phi[0,1]  R92       -2.2718472480773926e+00
    phi[0,1]  R93       -2.1821796894073486e+00
    phi[0,1]  R94       -3.1638524532318115e+00
    phi[0,1]  R95       -1.3554502725601196e+00
    phi[0,1]  R96       -2.7849035263061523e+00
    phi[0,1]  R97       -2.2736985683441162e+00
    phi[0,1]  R98       -2.6930108070373535e+00
    phi[0,1]  R99       -1.9888743162155151e+00
    phi[0,1]  R100      0.902486264705658
    phi[0,1]  R101      -2.4700496196746826e+00
    phi[0,1]  R102      -2.7086882591247559e+00
    phi[0,1]  R103      -3.5717771053314209e+00
    phi[0,1]  R104      -3.5089459419250488e+00
    phi[0,1]  R105      -3.0083270072937012e+00
    phi[0,1]  R106      -2.8232848644256592e+00
    phi[0,1]  R107      -4.2250113487243652e+00
    phi[0,1]  R108      -3.4311056137084961e+00
    phi[0,1]  R109      -3.3525354862213135e+00
    phi[0,1]  R110      -3.7193138599395752e+00
    phi[0,1]  R111      1.2600928544998169e+00
    phi[0,1]  R112      -1.8261154890060425e+00
    phi[0,1]  R113      -1.3418973684310913e+00
    phi[0,1]  R114      -3.0345458984375
    phi[0,1]  R115      -2.6553251743316650e+00
    phi[0,1]  R116      -2.2005267143249512e+00
    phi[0,1]  R117      -2.9011611938476562e+00
    phi[0,1]  R118      -2.7295053005218506e+00
    phi[0,1]  R119      -2.6466102600097656e+00
    phi[0,1]  R120      -1.0402624607086182e+00
    phi[0,1]  R121      -2.9894556999206543e+00
    phi[0,1]  R122      -2.9558684825897217e+00
    phi[0,1]  R123      -2.5462157726287842e+00
    phi[0,1]  R124      -2.3930659294128418e+00
    phi[0,1]  R125      -2.4398307800292969e+00
    phi[0,1]  R126      -3.9447529315948486e+00
    phi[0,1]  R127      -1.7604873180389404e+00
    phi[0,1]  R128      -6.6679143905639648e-01
    phi[0,1]  R129      -3.6204478740692139e+00
    phi[0,1]  R130      7.6302284002304077e-01
    phi[0,1]  R131      -2.7694776058197021e+00
    phi[0,1]  R132      -3.0886254310607910e+00
    phi[0,1]  R133      -3.2080426216125488e+00
    phi[0,1]  R134      -2.6615791320800781e+00
    phi[0,1]  R135      -2.4802491664886475e+00
    phi[0,1]  R136      -2.5544779300689697e+00
    phi[0,1]  R137      -1.5109301805496216e+00
    phi[0,1]  R138      -2.7325532436370850e+00
    phi[0,1]  R139      -2.83115816116333
    phi[0,1]  R140      7.9692453145980835e-01
    phi[0,1]  R141      4.1498267650604248e-01
    phi[0,1]  R142      1.8695031404495239e+00
    phi[0,1]  R143      1.1766593903303146e-01
    phi[0,1]  R144      7.3792296648025513e-01
    phi[0,1]  R145      9.9899973720312119e-03
    phi[0,1]  R146      -2.9520574212074280e-01
    phi[0,1]  R147      -1.3779214620590210e+00
    phi[0,1]  R148      -7.8688043355941772e-01
    phi[0,1]  R149      -2.7813216671347618e-02
    phi[0,1]  R150      -2.9272326827049255e-01
    phi[0,1]  R151      2.1682879328727722e-01
    phi[0,1]  R152      -1.0573991537094116e+00
    phi[0,1]  R153      3.8142082095146179e-01
    phi[0,1]  R154      0.043534055352211
    phi[0,1]  R155      -0.550426721572876
    phi[0,1]  R156      -1.7479392290115356e+00
    phi[0,1]  R157      -3.8110303878784180e-01
    phi[0,1]  R158      -2.7909765243530273e+00
    phi[0,1]  R159      -1.9583910703659058e+00
    phi[0,1]  R160      -9.1214990615844727e-01
    phi[0,1]  R161      1.3661292195320129e-01
    phi[0,1]  R162      -5.9480178356170654e-01
    phi[0,1]  R163      5.3226560354232788e-02
    phi[0,1]  R164      -1.5302872657775879e-01
    phi[0,1]  R165      4.3125890195369720e-02
    phi[0,1]  R166      -2.1801650524139404e+00
    phi[0,1]  R167      -2.1650190353393555e+00
    phi[0,1]  R168      -2.8554084300994873e+00
    phi[0,1]  R169      -3.3533353805541992e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R170      -3.0999999046325684e+00
    phi[1,0]  R171      -3.0999999046325684e+00
    phi[1,0]  R172      -2.2400000095367432e+00
    phi[1,0]  R173      -2.2400000095367432e+00
    phi[1,0]  R174      -3.0999999046325684e+00
    phi[1,0]  R175      -3.0999999046325684e+00
    phi[1,0]  R176      -2.5699999332427979e+00
    phi[1,0]  R177      -2.5699999332427979e+00
    phi[1,0]  R178      -3.0999999046325684e+00
    phi[1,0]  R179      -3.0999999046325684e+00
    phi[1,0]  R180      -2.0899999141693115e+00
    phi[1,0]  R181      -2.0899999141693115e+00
    phi[1,0]  R182      -3.0999999046325684e+00
    phi[1,0]  R183      -3.0999999046325684e+00
    phi[1,0]  R184      7.9692453145980835e-01
    phi[1,0]  R185      4.1498267650604248e-01
    phi[1,0]  R186      1.8695031404495239e+00
    phi[1,0]  R187      1.1766593903303146e-01
    phi[1,0]  R188      7.3792296648025513e-01
    phi[1,0]  R189      9.9899973720312119e-03
    phi[1,0]  R190      -2.9520574212074280e-01
    phi[1,0]  R191      -1.3779214620590210e+00
    phi[1,0]  R192      -7.8688043355941772e-01
    phi[1,0]  R193      -2.7813216671347618e-02
    phi[1,0]  R194      -2.9272326827049255e-01
    phi[1,0]  R195      2.1682879328727722e-01
    phi[1,0]  R196      -1.0573991537094116e+00
    phi[1,0]  R197      3.8142082095146179e-01
    phi[1,0]  R198      0.043534055352211
    phi[1,0]  R199      -0.550426721572876
    phi[1,0]  R200      -1.7479392290115356e+00
    phi[1,0]  R201      -3.8110303878784180e-01
    phi[1,0]  R202      -2.7909765243530273e+00
    phi[1,0]  R203      -1.9583910703659058e+00
    phi[1,0]  R204      -9.1214990615844727e-01
    phi[1,0]  R205      1.3661292195320129e-01
    phi[1,0]  R206      -5.9480178356170654e-01
    phi[1,0]  R207      5.3226560354232788e-02
    phi[1,0]  R208      -1.5302872657775879e-01
    phi[1,0]  R209      4.3125890195369720e-02
    phi[1,0]  R210      -2.1801650524139404e+00
    phi[1,0]  R211      -2.1650190353393555e+00
    phi[1,0]  R212      -2.8554084300994873e+00
    phi[1,0]  R213      -3.3533353805541992e+00
    phi[1,0]  R214      2.4020302295684814e+00
    phi[1,0]  R215      1.8663100004196167e+00
    phi[1,0]  R216      1.2075568437576294e+00
    phi[1,0]  R217      2.2898702621459961e+00
    phi[1,0]  R218      1.8036298751831055e+00
    phi[1,0]  R219      1.2551194429397583e+00
    phi[1,0]  R220      1.0073455572128296e+00
    phi[1,0]  R221      1.1078791618347168e+00
    phi[1,0]  R222      1.7470195293426514e+00
    phi[1,0]  R223      7.1696835756301880e-01
    phi[1,0]  R224      2.1950934827327728e-01
    phi[1,0]  R225      -9.4267219305038452e-01
    phi[1,0]  R226      4.4595929980278015e-01
    phi[1,0]  R227      1.6984882354736328e+00
    phi[1,0]  R228      1.1040562391281128e+00
    phi[1,0]  R229      8.2908284664154053e-01
    phi[1,0]  R230      -3.1365036964416504e-01
    phi[1,0]  R231      -1.8160487413406372e+00
    phi[1,0]  R232      9.5543837547302246e-01
    phi[1,0]  R233      -1.7526619434356689e+00
    phi[1,0]  R234      -2.7599352598190308e-01
    phi[1,0]  R235      -1.4340424537658691e+00
    phi[1,0]  R236      -2.2718472480773926e+00
    phi[1,0]  R237      -2.1821796894073486e+00
    phi[1,0]  R238      -3.1638524532318115e+00
    phi[1,0]  R239      -1.3554502725601196e+00
    phi[1,0]  R240      -2.7849035263061523e+00
    phi[1,0]  R241      -2.2736985683441162e+00
    phi[1,0]  R242      -2.6930108070373535e+00
    phi[1,0]  R243      -1.9888743162155151e+00
    phi[1,0]  R244      0.902486264705658
    phi[1,0]  R245      -2.4700496196746826e+00
    phi[1,0]  R246      -2.7086882591247559e+00
    phi[1,0]  R247      -3.5717771053314209e+00
    phi[1,0]  R248      -3.5089459419250488e+00
    phi[1,0]  R249      -3.0083270072937012e+00
    phi[1,0]  R250      -2.8232848644256592e+00
    phi[1,0]  R251      -4.2250113487243652e+00
    phi[1,0]  R252      -3.4311056137084961e+00
    phi[1,0]  R253      -3.3525354862213135e+00
    phi[1,0]  R254      -3.7193138599395752e+00
    phi[1,0]  R255      1.2600928544998169e+00
    phi[1,0]  R256      -1.8261154890060425e+00
    phi[1,0]  R257      -1.3418973684310913e+00
    phi[1,0]  R258      -3.0345458984375
    phi[1,0]  R259      -2.6553251743316650e+00
    phi[1,0]  R260      -2.2005267143249512e+00
    phi[1,0]  R261      -2.9011611938476562e+00
    phi[1,0]  R262      -2.7295053005218506e+00
    phi[1,0]  R263      -2.6466102600097656e+00
    phi[1,0]  R264      -1.0402624607086182e+00
    phi[1,0]  R265      -2.9894556999206543e+00
    phi[1,0]  R266      -2.9558684825897217e+00
    phi[1,0]  R267      -2.5462157726287842e+00
    phi[1,0]  R268      -2.3930659294128418e+00
    phi[1,0]  R269      -2.4398307800292969e+00
    phi[1,0]  R270      -3.9447529315948486e+00
    phi[1,0]  R271      -1.7604873180389404e+00
    phi[1,0]  R272      -6.6679143905639648e-01
    phi[1,0]  R273      -3.6204478740692139e+00
    phi[1,0]  R274      7.6302284002304077e-01
    phi[1,0]  R275      -2.7694776058197021e+00
    phi[1,0]  R276      -3.0886254310607910e+00
    phi[1,0]  R277      -3.2080426216125488e+00
    phi[1,0]  R278      -2.6615791320800781e+00
    phi[1,0]  R279      -2.4802491664886475e+00
    phi[1,0]  R280      -2.5544779300689697e+00
    phi[1,0]  R281      -1.5109301805496216e+00
    phi[1,0]  R282      -2.7325532436370850e+00
    phi[1,0]  R283      -2.83115816116333
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R284      -3.0999999046325684e+00
    phi[0,3]  R285      -3.0999999046325684e+00
    phi[0,3]  R286      -2.2400000095367432e+00
    phi[0,3]  R287      -2.2400000095367432e+00
    phi[0,3]  R288      -3.0999999046325684e+00
    phi[0,3]  R289      -3.0999999046325684e+00
    phi[0,3]  R290      -2.5699999332427979e+00
    phi[0,3]  R291      -2.5699999332427979e+00
    phi[0,3]  R292      -3.0999999046325684e+00
    phi[0,3]  R293      -3.0999999046325684e+00
    phi[0,3]  R294      -2.0899999141693115e+00
    phi[0,3]  R295      -2.0899999141693115e+00
    phi[0,3]  R296      -3.0999999046325684e+00
    phi[0,3]  R297      -3.0999999046325684e+00
    phi[0,3]  R298      2.4020302295684814e+00
    phi[0,3]  R299      1.8663100004196167e+00
    phi[0,3]  R300      1.2075568437576294e+00
    phi[0,3]  R301      2.2898702621459961e+00
    phi[0,3]  R302      1.8036298751831055e+00
    phi[0,3]  R303      1.2551194429397583e+00
    phi[0,3]  R304      1.0073455572128296e+00
    phi[0,3]  R305      1.1078791618347168e+00
    phi[0,3]  R306      1.7470195293426514e+00
    phi[0,3]  R307      7.1696835756301880e-01
    phi[0,3]  R308      2.1950934827327728e-01
    phi[0,3]  R309      -9.4267219305038452e-01
    phi[0,3]  R310      4.4595929980278015e-01
    phi[0,3]  R311      1.6984882354736328e+00
    phi[0,3]  R312      1.1040562391281128e+00
    phi[0,3]  R313      8.2908284664154053e-01
    phi[0,3]  R314      -3.1365036964416504e-01
    phi[0,3]  R315      -1.8160487413406372e+00
    phi[0,3]  R316      9.5543837547302246e-01
    phi[0,3]  R317      -1.7526619434356689e+00
    phi[0,3]  R318      -2.7599352598190308e-01
    phi[0,3]  R319      -1.4340424537658691e+00
    phi[0,3]  R320      -2.2718472480773926e+00
    phi[0,3]  R321      -2.1821796894073486e+00
    phi[0,3]  R322      -3.1638524532318115e+00
    phi[0,3]  R323      -1.3554502725601196e+00
    phi[0,3]  R324      -2.7849035263061523e+00
    phi[0,3]  R325      -2.2736985683441162e+00
    phi[0,3]  R326      -2.6930108070373535e+00
    phi[0,3]  R327      -1.9888743162155151e+00
    phi[0,3]  R328      0.902486264705658
    phi[0,3]  R329      -2.4700496196746826e+00
    phi[0,3]  R330      -2.7086882591247559e+00
    phi[0,3]  R331      -3.5717771053314209e+00
    phi[0,3]  R332      -3.5089459419250488e+00
    phi[0,3]  R333      -3.0083270072937012e+00
    phi[0,3]  R334      -2.8232848644256592e+00
    phi[0,3]  R335      -4.2250113487243652e+00
    phi[0,3]  R336      -3.4311056137084961e+00
    phi[0,3]  R337      -3.3525354862213135e+00
    phi[0,3]  R338      -3.7193138599395752e+00
    phi[0,3]  R339      1.2600928544998169e+00
    phi[0,3]  R340      -1.8261154890060425e+00
    phi[0,3]  R341      -1.3418973684310913e+00
    phi[0,3]  R342      -3.0345458984375
    phi[0,3]  R343      -2.6553251743316650e+00
    phi[0,3]  R344      -2.2005267143249512e+00
    phi[0,3]  R345      -2.9011611938476562e+00
    phi[0,3]  R346      -2.7295053005218506e+00
    phi[0,3]  R347      -2.6466102600097656e+00
    phi[0,3]  R348      -1.0402624607086182e+00
    phi[0,3]  R349      -2.9894556999206543e+00
    phi[0,3]  R350      -2.9558684825897217e+00
    phi[0,3]  R351      -2.5462157726287842e+00
    phi[0,3]  R352      -2.3930659294128418e+00
    phi[0,3]  R353      -2.4398307800292969e+00
    phi[0,3]  R354      -3.9447529315948486e+00
    phi[0,3]  R355      -1.7604873180389404e+00
    phi[0,3]  R356      -6.6679143905639648e-01
    phi[0,3]  R357      -3.6204478740692139e+00
    phi[0,3]  R358      7.6302284002304077e-01
    phi[0,3]  R359      -2.7694776058197021e+00
    phi[0,3]  R360      -3.0886254310607910e+00
    phi[0,3]  R361      -3.2080426216125488e+00
    phi[0,3]  R362      -2.6615791320800781e+00
    phi[0,3]  R363      -2.4802491664886475e+00
    phi[0,3]  R364      -2.5544779300689697e+00
    phi[0,3]  R365      -1.5109301805496216e+00
    phi[0,3]  R366      -2.7325532436370850e+00
    phi[0,3]  R367      -2.83115816116333
    phi[0,3]  R368      1.7334573268890381e+00
    phi[0,3]  R369      2.2319107055664062e+00
    phi[0,3]  R370      2.9019949436187744e+00
    phi[0,3]  R371      -9.2549228668212891e-01
    phi[0,3]  R372      -1.41675865650177
    phi[0,3]  R373      6.8726092576980591e-01
    phi[0,3]  R374      8.9127159118652344e-01
    phi[0,3]  R375      -2.4688229560852051e+00
    phi[0,3]  R376      -5.5618780851364136e-01
    phi[0,3]  R377      -3.7060627341270447e-01
    phi[0,3]  R378      -1.1356040239334106e+00
    phi[0,3]  R379      -3.3154060840606689e+00
    phi[0,3]  R380      -3.1919665336608887e+00
    phi[0,3]  R381      3.3773060888051987e-02
    phi[0,3]  R382      -1.9388939440250397e-01
    phi[0,3]  R383      -1.4169896841049194e+00
    phi[0,3]  R384      6.2699353694915771e-01
    phi[0,3]  R385      -2.2138059139251709e+00
    phi[0,3]  R386      -4.3821075558662415e-01
    phi[0,3]  R387      -2.9005081653594971e+00
    phi[0,3]  R388      -3.4855628013610840e+00
    phi[0,3]  R389      -3.3849532604217529e+00
    phi[0,3]  R390      -2.5126025676727295e+00
    phi[0,3]  R391      -1.8423423767089844e+00
    phi[0,3]  R392      -2.3803708553314209e+00
    phi[0,3]  R393      -2.4286077022552490e+00
    phi[0,3]  R394      -1.7690980434417725e+00
    phi[0,3]  R395      -2.3383741378784180e+00
    phi[0,3]  R396      -1.5844079256057739e+00
    phi[0,3]  R397      -1.8416551351547241e+00
    phi[0,3]  R398      -1.5972393751144409e+00
    phi[0,3]  R399      -2.5029242038726807e+00
    phi[0,3]  R400      -3.3589406013488770e+00
    phi[0,3]  R401      -1.6291214227676392e+00
    phi[0,3]  R402      -2.2276577949523926e+00
    phi[0,3]  R403      -1.0473197698593140e+00
    phi[0,3]  R404      -2.9403550624847412e+00
    phi[0,3]  R405      -2.4909644126892090e+00
    phi[0,3]  R406      -3.5564205646514893e+00
    phi[0,3]  R407      -2.7329914569854736e+00
    phi[0,3]  R408      -3.5934164524078369e+00
    phi[0,3]  R409      -1.3461574912071228e-01
    phi[0,3]  R410      -6.1715304851531982e-02
    phi[0,3]  R411      -2.3127028942108154e+00
    phi[0,3]  R412      -1.7392649650573730e+00
    phi[0,3]  R413      -3.7199242115020752e+00
    phi[0,3]  R414      -2.0330641269683838e+00
    phi[0,3]  R415      -3.1576628684997559e+00
    phi[0,3]  R416      -3.7154734134674072e+00
    phi[0,3]  R417      -3.12541127204895
    phi[0,3]  R418      -8.8167816400527954e-01
    phi[0,3]  R419      -2.7073490619659424e+00
    phi[0,3]  R420      -1.4858646392822266e+00
    phi[0,3]  R421      -2.1805851459503174e+00
    phi[0,3]  R422      -2.01226806640625
    phi[0,3]  R423      -0.92231285572052
    phi[0,3]  R424      -1.8562942743301392e+00
    phi[0,3]  R425      -2.6092917919158936e+00
    phi[0,3]  R426      -2.0257587432861328e+00
    phi[0,3]  R427      -2.1004478931427
    phi[0,3]  R428      -1.4287390708923340e+00
    phi[0,3]  R429      7.8135251998901367e-01
    phi[0,3]  R430      -3.1438763141632080e+00
    phi[0,3]  R431      -2.4436395168304443e+00
    phi[0,3]  R432      -3.4440124034881592e+00
    phi[0,3]  R433      -2.5341069698333740e+00
    phi[0,3]  R434      -3.6094620227813721e+00
    phi[0,3]  R435      -3.1685857772827148e+00
    phi[0,3]  R436      -3.4119021892547607e+00
    phi[0,3]  R437      -2.6836543083190918e+00
    phi[0,3]  R438      -3.5992629528045654e+00
    phi[0,3]  R439      -1.4282816648483276e+00
    phi[0,3]  R440      -2.9186706542968750e+00
    phi[0,3]  R441      -2.9752295017242432e+00
    phi[0,3]  R442      -3.0119705200195312e+00
    phi[0,3]  R443      -2.72963547706604
    phi[0,3]  R444      -1.2211716175079346e+00
    phi[0,3]  R445      -2.7258551120758057e-01
    phi[0,3]  R446      5.0541174411773682e-01
    phi[0,3]  R447      4.7650763392448425e-01
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R448      -3.0999999046325684e+00
    phi[3,0]  R449      -3.0999999046325684e+00
    phi[3,0]  R450      -2.2400000095367432e+00
    phi[3,0]  R451      -2.2400000095367432e+00
    phi[3,0]  R452      -3.0999999046325684e+00
    phi[3,0]  R453      -3.0999999046325684e+00
    phi[3,0]  R454      -2.5699999332427979e+00
    phi[3,0]  R455      -2.5699999332427979e+00
    phi[3,0]  R456      -3.0999999046325684e+00
    phi[3,0]  R457      -3.0999999046325684e+00
    phi[3,0]  R458      -2.0899999141693115e+00
    phi[3,0]  R459      -2.0899999141693115e+00
    phi[3,0]  R460      -3.0999999046325684e+00
    phi[3,0]  R461      -3.0999999046325684e+00
    phi[3,0]  R462      1.7334573268890381e+00
    phi[3,0]  R463      2.2319107055664062e+00
    phi[3,0]  R464      2.9019949436187744e+00
    phi[3,0]  R465      -9.2549228668212891e-01
    phi[3,0]  R466      -1.41675865650177
    phi[3,0]  R467      6.8726092576980591e-01
    phi[3,0]  R468      8.9127159118652344e-01
    phi[3,0]  R469      -2.4688229560852051e+00
    phi[3,0]  R470      -5.5618780851364136e-01
    phi[3,0]  R471      -3.7060627341270447e-01
    phi[3,0]  R472      -1.1356040239334106e+00
    phi[3,0]  R473      -3.3154060840606689e+00
    phi[3,0]  R474      -3.1919665336608887e+00
    phi[3,0]  R475      3.3773060888051987e-02
    phi[3,0]  R476      -1.9388939440250397e-01
    phi[3,0]  R477      -1.4169896841049194e+00
    phi[3,0]  R478      6.2699353694915771e-01
    phi[3,0]  R479      -2.2138059139251709e+00
    phi[3,0]  R480      -4.3821075558662415e-01
    phi[3,0]  R481      -2.9005081653594971e+00
    phi[3,0]  R482      -3.4855628013610840e+00
    phi[3,0]  R483      -3.3849532604217529e+00
    phi[3,0]  R484      -2.5126025676727295e+00
    phi[3,0]  R485      -1.8423423767089844e+00
    phi[3,0]  R486      -2.3803708553314209e+00
    phi[3,0]  R487      -2.4286077022552490e+00
    phi[3,0]  R488      -1.7690980434417725e+00
    phi[3,0]  R489      -2.3383741378784180e+00
    phi[3,0]  R490      -1.5844079256057739e+00
    phi[3,0]  R491      -1.8416551351547241e+00
    phi[3,0]  R492      -1.5972393751144409e+00
    phi[3,0]  R493      -2.5029242038726807e+00
    phi[3,0]  R494      -3.3589406013488770e+00
    phi[3,0]  R495      -1.6291214227676392e+00
    phi[3,0]  R496      -2.2276577949523926e+00
    phi[3,0]  R497      -1.0473197698593140e+00
    phi[3,0]  R498      -2.9403550624847412e+00
    phi[3,0]  R499      -2.4909644126892090e+00
    phi[3,0]  R500      -3.5564205646514893e+00
    phi[3,0]  R501      -2.7329914569854736e+00
    phi[3,0]  R502      -3.5934164524078369e+00
    phi[3,0]  R503      -1.3461574912071228e-01
    phi[3,0]  R504      -6.1715304851531982e-02
    phi[3,0]  R505      -2.3127028942108154e+00
    phi[3,0]  R506      -1.7392649650573730e+00
    phi[3,0]  R507      -3.7199242115020752e+00
    phi[3,0]  R508      -2.0330641269683838e+00
    phi[3,0]  R509      -3.1576628684997559e+00
    phi[3,0]  R510      -3.7154734134674072e+00
    phi[3,0]  R511      -3.12541127204895
    phi[3,0]  R512      -8.8167816400527954e-01
    phi[3,0]  R513      -2.7073490619659424e+00
    phi[3,0]  R514      -1.4858646392822266e+00
    phi[3,0]  R515      -2.1805851459503174e+00
    phi[3,0]  R516      -2.01226806640625
    phi[3,0]  R517      -0.92231285572052
    phi[3,0]  R518      -1.8562942743301392e+00
    phi[3,0]  R519      -2.6092917919158936e+00
    phi[3,0]  R520      -2.0257587432861328e+00
    phi[3,0]  R521      -2.1004478931427
    phi[3,0]  R522      -1.4287390708923340e+00
    phi[3,0]  R523      7.8135251998901367e-01
    phi[3,0]  R524      -3.1438763141632080e+00
    phi[3,0]  R525      -2.4436395168304443e+00
    phi[3,0]  R526      -3.4440124034881592e+00
    phi[3,0]  R527      -2.5341069698333740e+00
    phi[3,0]  R528      -3.6094620227813721e+00
    phi[3,0]  R529      -3.1685857772827148e+00
    phi[3,0]  R530      -3.4119021892547607e+00
    phi[3,0]  R531      -2.6836543083190918e+00
    phi[3,0]  R532      -3.5992629528045654e+00
    phi[3,0]  R533      -1.4282816648483276e+00
    phi[3,0]  R534      -2.9186706542968750e+00
    phi[3,0]  R535      -2.9752295017242432e+00
    phi[3,0]  R536      -3.0119705200195312e+00
    phi[3,0]  R537      -2.72963547706604
    phi[3,0]  R538      -1.2211716175079346e+00
    phi[3,0]  R539      -2.7258551120758057e-01
    phi[3,0]  R540      5.0541174411773682e-01
    phi[3,0]  R541      4.7650763392448425e-01
    phi[3,0]  R542      2.4020302295684814e+00
    phi[3,0]  R543      1.8663100004196167e+00
    phi[3,0]  R544      1.2075568437576294e+00
    phi[3,0]  R545      2.2898702621459961e+00
    phi[3,0]  R546      1.8036298751831055e+00
    phi[3,0]  R547      1.2551194429397583e+00
    phi[3,0]  R548      1.0073455572128296e+00
    phi[3,0]  R549      1.1078791618347168e+00
    phi[3,0]  R550      1.7470195293426514e+00
    phi[3,0]  R551      7.1696835756301880e-01
    phi[3,0]  R552      2.1950934827327728e-01
    phi[3,0]  R553      -9.4267219305038452e-01
    phi[3,0]  R554      4.4595929980278015e-01
    phi[3,0]  R555      1.6984882354736328e+00
    phi[3,0]  R556      1.1040562391281128e+00
    phi[3,0]  R557      8.2908284664154053e-01
    phi[3,0]  R558      -3.1365036964416504e-01
    phi[3,0]  R559      -1.8160487413406372e+00
    phi[3,0]  R560      9.5543837547302246e-01
    phi[3,0]  R561      -1.7526619434356689e+00
    phi[3,0]  R562      -2.7599352598190308e-01
    phi[3,0]  R563      -1.4340424537658691e+00
    phi[3,0]  R564      -2.2718472480773926e+00
    phi[3,0]  R565      -2.1821796894073486e+00
    phi[3,0]  R566      -3.1638524532318115e+00
    phi[3,0]  R567      -1.3554502725601196e+00
    phi[3,0]  R568      -2.7849035263061523e+00
    phi[3,0]  R569      -2.2736985683441162e+00
    phi[3,0]  R570      -2.6930108070373535e+00
    phi[3,0]  R571      -1.9888743162155151e+00
    phi[3,0]  R572      0.902486264705658
    phi[3,0]  R573      -2.4700496196746826e+00
    phi[3,0]  R574      -2.7086882591247559e+00
    phi[3,0]  R575      -3.5717771053314209e+00
    phi[3,0]  R576      -3.5089459419250488e+00
    phi[3,0]  R577      -3.0083270072937012e+00
    phi[3,0]  R578      -2.8232848644256592e+00
    phi[3,0]  R579      -4.2250113487243652e+00
    phi[3,0]  R580      -3.4311056137084961e+00
    phi[3,0]  R581      -3.3525354862213135e+00
    phi[3,0]  R582      -3.7193138599395752e+00
    phi[3,0]  R583      1.2600928544998169e+00
    phi[3,0]  R584      -1.8261154890060425e+00
    phi[3,0]  R585      -1.3418973684310913e+00
    phi[3,0]  R586      -3.0345458984375
    phi[3,0]  R587      -2.6553251743316650e+00
    phi[3,0]  R588      -2.2005267143249512e+00
    phi[3,0]  R589      -2.9011611938476562e+00
    phi[3,0]  R590      -2.7295053005218506e+00
    phi[3,0]  R591      -2.6466102600097656e+00
    phi[3,0]  R592      -1.0402624607086182e+00
    phi[3,0]  R593      -2.9894556999206543e+00
    phi[3,0]  R594      -2.9558684825897217e+00
    phi[3,0]  R595      -2.5462157726287842e+00
    phi[3,0]  R596      -2.3930659294128418e+00
    phi[3,0]  R597      -2.4398307800292969e+00
    phi[3,0]  R598      -3.9447529315948486e+00
    phi[3,0]  R599      -1.7604873180389404e+00
    phi[3,0]  R600      -6.6679143905639648e-01
    phi[3,0]  R601      -3.6204478740692139e+00
    phi[3,0]  R602      7.6302284002304077e-01
    phi[3,0]  R603      -2.7694776058197021e+00
    phi[3,0]  R604      -3.0886254310607910e+00
    phi[3,0]  R605      -3.2080426216125488e+00
    phi[3,0]  R606      -2.6615791320800781e+00
    phi[3,0]  R607      -2.4802491664886475e+00
    phi[3,0]  R608      -2.5544779300689697e+00
    phi[3,0]  R609      -1.5109301805496216e+00
    phi[3,0]  R610      -2.7325532436370850e+00
    phi[3,0]  R611      -2.83115816116333
    phi[6,0]  R0        -1
    phi[6,0]  R2        1.9199915296395873e+00
    phi[6,0]  R3        0.904736486145258
    phi[6,0]  R4        2.5115367541391920e+00
    phi[6,0]  R5        -1.3686806963533209e+00
    phi[6,0]  R6        1.1017081568291229e+00
    phi[6,0]  R7        6.2561744647177431e-01
    phi[6,0]  R8        -1.4726251316690804e+00
    phi[6,0]  R54       1
    phi[6,0]  R612      -5.0199914342721552e+00
    phi[6,0]  R613      -1.1800083749929811e+00
    phi[6,0]  R614      -3.1447364956820012e+00
    phi[6,0]  R615      -1.3352635233914851e+00
    phi[6,0]  R616      -5.61153665877176
    phi[6,0]  R617      -5.8846315049337639e-01
    phi[6,0]  R618      -1.2013192368894769e+00
    phi[6,0]  R619      -3.9386806295961190e+00
    phi[6,0]  R620      -4.2017080614616908e+00
    phi[6,0]  R621      -1.9982917478034454e+00
    phi[6,0]  R622      -2.7156173606410858e+00
    phi[6,0]  R623      -1.4643824676975372e+00
    phi[6,0]  R624      -1.6273747729634880e+00
    phi[6,0]  R625      -4.5726250363016483e+00
    phi[6,0]  R626      -1.2344319304231091e+00
    phi[6,0]  R627      -8.5342565152926664e-01
    phi[6,0]  R628      -1.0088118349939563e+00
    phi[6,0]  R629      -1.1651055285600211e+00
    phi[6,0]  R630      -1.0072759538414213e+00
    phi[6,0]  R631      -1.8677975323232232e+00
    phi[6,0]  R632      -1.1609374591085087e+00
    phi[6,0]  R633      -1.6303106912288157e+00
    phi[6,0]  R634      -1.4193101761077314e+00
    phi[6,0]  R635      -1.1147759380193492e+00
    phi[6,0]  R636      -1.2201865249979893e-01
    phi[6,0]  R637      -1.4233727497037019e-01
    phi[6,0]  R638      -1.4300474798919083e-01
    phi[6,0]  R639      -1.5022880205003730e-01
    phi[6,0]  R640      -1.5269535218957975e-01
    phi[6,0]  R641      -1.6023307698024380e-01
    phi[6,0]  R642      -4.3043687505056571e-01
    phi[6,0]  R643      -4.5364909899399208e-01
    phi[6,0]  R644      -4.5911294854501294e-01
    phi[6,0]  R645      -4.8732916310213703e-01
    phi[6,0]  R646      -4.3862200009362395e-01
    phi[6,0]  R647      -6.3969467086204346e-01
    phi[6,0]  R648      -6.5950165288630913e-01
    phi[6,0]  R649      -6.6391513609558350e-01
    phi[6,0]  R650      -6.7256712592552326e-01
    phi[6,0]  R651      -6.9873581942381380e-01
    phi[6,0]  R652      -7.0377248885965349e-01
    phi[6,0]  R653      -7.2007630767843334e-01
    phi[6,0]  R654      -7.2487649285578248e-01
    phi[6,0]  R655      -7.3596261120256123e-01
    phi[6,0]  R656      -2.7247361019810334e-01
    phi[6,0]  R657      -5.2304748022041281e-01
    phi[6,0]  R658      -5.2550860741483874e-01
    phi[6,0]  R659      -5.5012912681557635e-01
    phi[6,0]  R660      -5.5899223998344150e-01
    phi[6,0]  R661      -5.6877741487004041e-01
    phi[6,0]  R662      -5.6878198589077522e-01
    phi[6,0]  R663      -5.7895950218109160e-01
    phi[6,0]  R664      -5.8295488626025316e-01
    phi[6,0]  R665      -6.0399139833534665e-01
    phi[6,0]  R666      -4.7247866952670181e-01
    phi[6,0]  R667      -5.9676804923576077e-01
    phi[6,0]  R668      -6.4572638130277382e-01
    phi[6,0]  R669      -6.4705965378678942e-01
    phi[6,0]  R670      -6.4955822249309048e-01
    phi[6,0]  R671      -6.5681544484118581e-01
    phi[6,0]  R672      -0.691113872649787
    phi[6,0]  R673      -6.9741172422668685e-01
    phi[6,0]  R674      -7.0470787867863471e-01
    phi[6,0]  R675      -7.0762499796072831e-01
    phi[6,0]  R676      -5.4239294431010776e-01
    phi[6,0]  R677      -5.7089971904762926e-01
    phi[6,0]  R678      -5.7515860507277417e-01
    phi[6,0]  R679      -6.2048942508399274e-01
    phi[6,0]  R680      -6.2257202287073676e-01
    phi[6,0]  R681      -6.9403343181298238e-01
    phi[6,0]  R682      -7.2258010952125984e-01
    phi[6,0]  R683      -7.7054483951236219e-01
    phi[6,0]  R684      -7.9010282848061353e-01
    phi[6,0]  R685      -1.0092545809128639e+00
    phi[6,0]  R686      -2.5085863749674875e-01
    phi[6,0]  R687      -4.7160116312527478e-01
    phi[6,0]  R688      -5.7004447973690153e-01
    phi[6,0]  R689      -0.608702847172236
    phi[6,0]  R690      -6.2497624582429623e-01
    phi[6,0]  R691      -0.626087796547316
    phi[6,0]  R692      -6.7316234171667544e-01
    phi[6,0]  R693      -7.7906811855836533e-01
    phi[6,0]  R694      -2.2595611723553524e+00
    phi[6,0]  R695      -1.0942512705598761e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R696      -3.0999999046325684e+00
    phi[1,2]  R697      -3.0999999046325684e+00
    phi[1,2]  R698      -2.2400000095367432e+00
    phi[1,2]  R699      -2.2400000095367432e+00
    phi[1,2]  R700      -3.0999999046325684e+00
    phi[1,2]  R701      -3.0999999046325684e+00
    phi[1,2]  R702      -2.5699999332427979e+00
    phi[1,2]  R703      -2.5699999332427979e+00
    phi[1,2]  R704      -3.0999999046325684e+00
    phi[1,2]  R705      -3.0999999046325684e+00
    phi[1,2]  R706      -2.0899999141693115e+00
    phi[1,2]  R707      -2.0899999141693115e+00
    phi[1,2]  R708      -3.0999999046325684e+00
    phi[1,2]  R709      -3.0999999046325684e+00
    phi[1,2]  R710      7.9692453145980835e-01
    phi[1,2]  R711      4.1498267650604248e-01
    phi[1,2]  R712      1.8695031404495239e+00
    phi[1,2]  R713      1.1766593903303146e-01
    phi[1,2]  R714      7.3792296648025513e-01
    phi[1,2]  R715      9.9899973720312119e-03
    phi[1,2]  R716      -2.9520574212074280e-01
    phi[1,2]  R717      -1.3779214620590210e+00
    phi[1,2]  R718      -7.8688043355941772e-01
    phi[1,2]  R719      -2.7813216671347618e-02
    phi[1,2]  R720      -2.9272326827049255e-01
    phi[1,2]  R721      2.1682879328727722e-01
    phi[1,2]  R722      -1.0573991537094116e+00
    phi[1,2]  R723      3.8142082095146179e-01
    phi[1,2]  R724      0.043534055352211
    phi[1,2]  R725      -0.550426721572876
    phi[1,2]  R726      -1.7479392290115356e+00
    phi[1,2]  R727      -3.8110303878784180e-01
    phi[1,2]  R728      -2.7909765243530273e+00
    phi[1,2]  R729      -1.9583910703659058e+00
    phi[1,2]  R730      -9.1214990615844727e-01
    phi[1,2]  R731      1.3661292195320129e-01
    phi[1,2]  R732      -5.9480178356170654e-01
    phi[1,2]  R733      5.3226560354232788e-02
    phi[1,2]  R734      -1.5302872657775879e-01
    phi[1,2]  R735      4.3125890195369720e-02
    phi[1,2]  R736      -2.1801650524139404e+00
    phi[1,2]  R737      -2.1650190353393555e+00
    phi[1,2]  R738      -2.8554084300994873e+00
    phi[1,2]  R739      -3.3533353805541992e+00
    phi[1,2]  R740      4.2386963963508606e-02
    phi[1,2]  R741      -9.9423122406005859e-01
    phi[1,2]  R742      -4.2186436057090759e-01
    phi[1,2]  R743      6.3430711627006531e-02
    phi[1,2]  R744      -2.1387554705142975e-01
    phi[1,2]  R745      -4.6012768149375916e-01
    phi[1,2]  R746      -3.8501704111695290e-03
    phi[1,2]  R747      -2.3238627240061760e-02
    phi[1,2]  R748      4.9454070627689362e-02
    phi[1,2]  R749      -6.1279177665710449e-01
    phi[1,2]  R750      -1.0159367322921753e+00
    phi[1,2]  R751      -1.4063947200775146e+00
    phi[1,2]  R752      -4.5384517312049866e-01
    phi[1,2]  R753      -1.1621637344360352e+00
    phi[1,2]  R754      -1.4494122266769409e+00
    phi[1,2]  R755      -1.9017596244812012e+00
    phi[1,2]  R756      -1.4456139802932739e+00
    phi[1,2]  R757      -1.0550187826156616e+00
    phi[1,2]  R758      -9.3245500326156616e-01
    phi[1,2]  R759      -1.1019502878189087e+00
    phi[1,2]  R760      -7.9229104518890381e-01
    phi[1,2]  R761      8.9914821088314056e-02
    phi[1,2]  R762      -2.2242160141468048e-01
    phi[1,2]  R763      4.8117554187774658e-01
    phi[1,2]  R764      -2.8104444965720177e-02
    phi[1,2]  R765      -9.4986081123352051e-01
    phi[1,2]  R766      0.292352557182312
    phi[1,2]  R767      -9.1885155439376831e-01
    phi[1,2]  R768      -6.7174535989761353e-01
    phi[1,2]  R769      -1.4303944110870361e+00
    phi[1,2]  R770      -3.4025445580482483e-01
    phi[1,2]  R771      -1.9758620858192444e-01
    phi[1,2]  R772      -2.3860505223274231e-01
    phi[1,2]  R773      6.0201418399810791e-01
    phi[1,2]  R774      -2.3126417398452759e-01
    phi[1,2]  R775      -3.0963113307952881e+00
    phi[1,2]  R776      5.2583521604537964e-01
    phi[1,2]  R777      -3.1415212154388428e-01
    phi[1,2]  R778      -0.292779803276062
    phi[1,2]  R779      2.4751776456832886e-01
    phi[1,2]  R780      -9.5011007785797119e-01
    phi[1,2]  R781      -1.9117995500564575e+00
    phi[1,2]  R782      -1.1041853427886963e+00
    phi[1,2]  R783      -9.4993555545806885e-01
    phi[1,2]  R784      -9.3022906780242920e-01
    phi[1,2]  R785      -1.1032702922821045e+00
    phi[1,2]  R786      -1.7146047353744507e+00
    phi[1,2]  R787      7.6810050010681152e-01
    phi[1,2]  R788      -1.5306453704833984e+00
    phi[1,2]  R789      -1.8092749118804932e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R790      -3.0999999046325684e+00
    phi[2,1]  R791      -3.0999999046325684e+00
    phi[2,1]  R792      -2.2400000095367432e+00
    phi[2,1]  R793      -2.2400000095367432e+00
    phi[2,1]  R794      -3.0999999046325684e+00
    phi[2,1]  R795      -3.0999999046325684e+00
    phi[2,1]  R796      -2.5699999332427979e+00
    phi[2,1]  R797      -2.5699999332427979e+00
    phi[2,1]  R798      -3.0999999046325684e+00
    phi[2,1]  R799      -3.0999999046325684e+00
    phi[2,1]  R800      -2.0899999141693115e+00
    phi[2,1]  R801      -2.0899999141693115e+00
    phi[2,1]  R802      -3.0999999046325684e+00
    phi[2,1]  R803      -3.0999999046325684e+00
    phi[2,1]  R804      4.2386963963508606e-02
    phi[2,1]  R805      -9.9423122406005859e-01
    phi[2,1]  R806      -4.2186436057090759e-01
    phi[2,1]  R807      6.3430711627006531e-02
    phi[2,1]  R808      -2.1387554705142975e-01
    phi[2,1]  R809      -4.6012768149375916e-01
    phi[2,1]  R810      -3.8501704111695290e-03
    phi[2,1]  R811      -2.3238627240061760e-02
    phi[2,1]  R812      4.9454070627689362e-02
    phi[2,1]  R813      -6.1279177665710449e-01
    phi[2,1]  R814      -1.0159367322921753e+00
    phi[2,1]  R815      -1.4063947200775146e+00
    phi[2,1]  R816      -4.5384517312049866e-01
    phi[2,1]  R817      -1.1621637344360352e+00
    phi[2,1]  R818      -1.4494122266769409e+00
    phi[2,1]  R819      -1.9017596244812012e+00
    phi[2,1]  R820      -1.4456139802932739e+00
    phi[2,1]  R821      -1.0550187826156616e+00
    phi[2,1]  R822      -9.3245500326156616e-01
    phi[2,1]  R823      -1.1019502878189087e+00
    phi[2,1]  R824      -7.9229104518890381e-01
    phi[2,1]  R825      8.9914821088314056e-02
    phi[2,1]  R826      -2.2242160141468048e-01
    phi[2,1]  R827      4.8117554187774658e-01
    phi[2,1]  R828      -2.8104444965720177e-02
    phi[2,1]  R829      -9.4986081123352051e-01
    phi[2,1]  R830      0.292352557182312
    phi[2,1]  R831      -9.1885155439376831e-01
    phi[2,1]  R832      -6.7174535989761353e-01
    phi[2,1]  R833      -1.4303944110870361e+00
    phi[2,1]  R834      -3.4025445580482483e-01
    phi[2,1]  R835      -1.9758620858192444e-01
    phi[2,1]  R836      -2.3860505223274231e-01
    phi[2,1]  R837      6.0201418399810791e-01
    phi[2,1]  R838      -2.3126417398452759e-01
    phi[2,1]  R839      -3.0963113307952881e+00
    phi[2,1]  R840      5.2583521604537964e-01
    phi[2,1]  R841      -3.1415212154388428e-01
    phi[2,1]  R842      -0.292779803276062
    phi[2,1]  R843      2.4751776456832886e-01
    phi[2,1]  R844      -9.5011007785797119e-01
    phi[2,1]  R845      -1.9117995500564575e+00
    phi[2,1]  R846      -1.1041853427886963e+00
    phi[2,1]  R847      -9.4993555545806885e-01
    phi[2,1]  R848      -9.3022906780242920e-01
    phi[2,1]  R849      -1.1032702922821045e+00
    phi[2,1]  R850      -1.7146047353744507e+00
    phi[2,1]  R851      7.6810050010681152e-01
    phi[2,1]  R852      -1.5306453704833984e+00
    phi[2,1]  R853      -1.8092749118804932e+00
    phi[2,1]  R854      7.9692453145980835e-01
    phi[2,1]  R855      4.1498267650604248e-01
    phi[2,1]  R856      1.8695031404495239e+00
    phi[2,1]  R857      1.1766593903303146e-01
    phi[2,1]  R858      7.3792296648025513e-01
    phi[2,1]  R859      9.9899973720312119e-03
    phi[2,1]  R860      -2.9520574212074280e-01
    phi[2,1]  R861      -1.3779214620590210e+00
    phi[2,1]  R862      -7.8688043355941772e-01
    phi[2,1]  R863      -2.7813216671347618e-02
    phi[2,1]  R864      -2.9272326827049255e-01
    phi[2,1]  R865      2.1682879328727722e-01
    phi[2,1]  R866      -1.0573991537094116e+00
    phi[2,1]  R867      3.8142082095146179e-01
    phi[2,1]  R868      0.043534055352211
    phi[2,1]  R869      -0.550426721572876
    phi[2,1]  R870      -1.7479392290115356e+00
    phi[2,1]  R871      -3.8110303878784180e-01
    phi[2,1]  R872      -2.7909765243530273e+00
    phi[2,1]  R873      -1.9583910703659058e+00
    phi[2,1]  R874      -9.1214990615844727e-01
    phi[2,1]  R875      1.3661292195320129e-01
    phi[2,1]  R876      -5.9480178356170654e-01
    phi[2,1]  R877      5.3226560354232788e-02
    phi[2,1]  R878      -1.5302872657775879e-01
    phi[2,1]  R879      4.3125890195369720e-02
    phi[2,1]  R880      -2.1801650524139404e+00
    phi[2,1]  R881      -2.1650190353393555e+00
    phi[2,1]  R882      -2.8554084300994873e+00
    phi[2,1]  R883      -3.3533353805541992e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R884      -3.0999999046325684e+00
    phi[1,3]  R885      -3.0999999046325684e+00
    phi[1,3]  R886      -2.2400000095367432e+00
    phi[1,3]  R887      -2.2400000095367432e+00
    phi[1,3]  R888      -3.0999999046325684e+00
    phi[1,3]  R889      -3.0999999046325684e+00
    phi[1,3]  R890      -2.5699999332427979e+00
    phi[1,3]  R891      -2.5699999332427979e+00
    phi[1,3]  R892      -3.0999999046325684e+00
    phi[1,3]  R893      -3.0999999046325684e+00
    phi[1,3]  R894      -2.0899999141693115e+00
    phi[1,3]  R895      -2.0899999141693115e+00
    phi[1,3]  R896      -3.0999999046325684e+00
    phi[1,3]  R897      -3.0999999046325684e+00
    phi[1,3]  R898      7.9692453145980835e-01
    phi[1,3]  R899      4.1498267650604248e-01
    phi[1,3]  R900      1.8695031404495239e+00
    phi[1,3]  R901      1.1766593903303146e-01
    phi[1,3]  R902      7.3792296648025513e-01
    phi[1,3]  R903      9.9899973720312119e-03
    phi[1,3]  R904      -2.9520574212074280e-01
    phi[1,3]  R905      -1.3779214620590210e+00
    phi[1,3]  R906      -7.8688043355941772e-01
    phi[1,3]  R907      -2.7813216671347618e-02
    phi[1,3]  R908      -2.9272326827049255e-01
    phi[1,3]  R909      2.1682879328727722e-01
    phi[1,3]  R910      -1.0573991537094116e+00
    phi[1,3]  R911      3.8142082095146179e-01
    phi[1,3]  R912      0.043534055352211
    phi[1,3]  R913      -0.550426721572876
    phi[1,3]  R914      -1.7479392290115356e+00
    phi[1,3]  R915      -3.8110303878784180e-01
    phi[1,3]  R916      -2.7909765243530273e+00
    phi[1,3]  R917      -1.9583910703659058e+00
    phi[1,3]  R918      -9.1214990615844727e-01
    phi[1,3]  R919      1.3661292195320129e-01
    phi[1,3]  R920      -5.9480178356170654e-01
    phi[1,3]  R921      5.3226560354232788e-02
    phi[1,3]  R922      -1.5302872657775879e-01
    phi[1,3]  R923      4.3125890195369720e-02
    phi[1,3]  R924      -2.1801650524139404e+00
    phi[1,3]  R925      -2.1650190353393555e+00
    phi[1,3]  R926      -2.8554084300994873e+00
    phi[1,3]  R927      -3.3533353805541992e+00
    phi[1,3]  R928      1.7334573268890381e+00
    phi[1,3]  R929      2.2319107055664062e+00
    phi[1,3]  R930      2.9019949436187744e+00
    phi[1,3]  R931      -9.2549228668212891e-01
    phi[1,3]  R932      -1.41675865650177
    phi[1,3]  R933      6.8726092576980591e-01
    phi[1,3]  R934      8.9127159118652344e-01
    phi[1,3]  R935      -2.4688229560852051e+00
    phi[1,3]  R936      -5.5618780851364136e-01
    phi[1,3]  R937      -3.7060627341270447e-01
    phi[1,3]  R938      -1.1356040239334106e+00
    phi[1,3]  R939      -3.3154060840606689e+00
    phi[1,3]  R940      -3.1919665336608887e+00
    phi[1,3]  R941      3.3773060888051987e-02
    phi[1,3]  R942      -1.9388939440250397e-01
    phi[1,3]  R943      -1.4169896841049194e+00
    phi[1,3]  R944      6.2699353694915771e-01
    phi[1,3]  R945      -2.2138059139251709e+00
    phi[1,3]  R946      -4.3821075558662415e-01
    phi[1,3]  R947      -2.9005081653594971e+00
    phi[1,3]  R948      -3.4855628013610840e+00
    phi[1,3]  R949      -3.3849532604217529e+00
    phi[1,3]  R950      -2.5126025676727295e+00
    phi[1,3]  R951      -1.8423423767089844e+00
    phi[1,3]  R952      -2.3803708553314209e+00
    phi[1,3]  R953      -2.4286077022552490e+00
    phi[1,3]  R954      -1.7690980434417725e+00
    phi[1,3]  R955      -2.3383741378784180e+00
    phi[1,3]  R956      -1.5844079256057739e+00
    phi[1,3]  R957      -1.8416551351547241e+00
    phi[1,3]  R958      -1.5972393751144409e+00
    phi[1,3]  R959      -2.5029242038726807e+00
    phi[1,3]  R960      -3.3589406013488770e+00
    phi[1,3]  R961      -1.6291214227676392e+00
    phi[1,3]  R962      -2.2276577949523926e+00
    phi[1,3]  R963      -1.0473197698593140e+00
    phi[1,3]  R964      -2.9403550624847412e+00
    phi[1,3]  R965      -2.4909644126892090e+00
    phi[1,3]  R966      -3.5564205646514893e+00
    phi[1,3]  R967      -2.7329914569854736e+00
    phi[1,3]  R968      -3.5934164524078369e+00
    phi[1,3]  R969      -1.3461574912071228e-01
    phi[1,3]  R970      -6.1715304851531982e-02
    phi[1,3]  R971      -2.3127028942108154e+00
    phi[1,3]  R972      -1.7392649650573730e+00
    phi[1,3]  R973      -3.7199242115020752e+00
    phi[1,3]  R974      -2.0330641269683838e+00
    phi[1,3]  R975      -3.1576628684997559e+00
    phi[1,3]  R976      -3.7154734134674072e+00
    phi[1,3]  R977      -3.12541127204895
    phi[1,3]  R978      -8.8167816400527954e-01
    phi[1,3]  R979      -2.7073490619659424e+00
    phi[1,3]  R980      -1.4858646392822266e+00
    phi[1,3]  R981      -2.1805851459503174e+00
    phi[1,3]  R982      -2.01226806640625
    phi[1,3]  R983      -0.92231285572052
    phi[1,3]  R984      -1.8562942743301392e+00
    phi[1,3]  R985      -2.6092917919158936e+00
    phi[1,3]  R986      -2.0257587432861328e+00
    phi[1,3]  R987      -2.1004478931427
    phi[1,3]  R988      -1.4287390708923340e+00
    phi[1,3]  R989      7.8135251998901367e-01
    phi[1,3]  R990      -3.1438763141632080e+00
    phi[1,3]  R991      -2.4436395168304443e+00
    phi[1,3]  R992      -3.4440124034881592e+00
    phi[1,3]  R993      -2.5341069698333740e+00
    phi[1,3]  R994      -3.6094620227813721e+00
    phi[1,3]  R995      -3.1685857772827148e+00
    phi[1,3]  R996      -3.4119021892547607e+00
    phi[1,3]  R997      -2.6836543083190918e+00
    phi[1,3]  R998      -3.5992629528045654e+00
    phi[1,3]  R999      -1.4282816648483276e+00
    phi[1,3]  R1000     -2.9186706542968750e+00
    phi[1,3]  R1001     -2.9752295017242432e+00
    phi[1,3]  R1002     -3.0119705200195312e+00
    phi[1,3]  R1003     -2.72963547706604
    phi[1,3]  R1004     -1.2211716175079346e+00
    phi[1,3]  R1005     -2.7258551120758057e-01
    phi[1,3]  R1006     5.0541174411773682e-01
    phi[1,3]  R1007     4.7650763392448425e-01
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R1008     -3.0999999046325684e+00
    phi[3,1]  R1009     -3.0999999046325684e+00
    phi[3,1]  R1010     -2.2400000095367432e+00
    phi[3,1]  R1011     -2.2400000095367432e+00
    phi[3,1]  R1012     -3.0999999046325684e+00
    phi[3,1]  R1013     -3.0999999046325684e+00
    phi[3,1]  R1014     -2.5699999332427979e+00
    phi[3,1]  R1015     -2.5699999332427979e+00
    phi[3,1]  R1016     -3.0999999046325684e+00
    phi[3,1]  R1017     -3.0999999046325684e+00
    phi[3,1]  R1018     -2.0899999141693115e+00
    phi[3,1]  R1019     -2.0899999141693115e+00
    phi[3,1]  R1020     -3.0999999046325684e+00
    phi[3,1]  R1021     -3.0999999046325684e+00
    phi[3,1]  R1022     1.7334573268890381e+00
    phi[3,1]  R1023     2.2319107055664062e+00
    phi[3,1]  R1024     2.9019949436187744e+00
    phi[3,1]  R1025     -9.2549228668212891e-01
    phi[3,1]  R1026     -1.41675865650177
    phi[3,1]  R1027     6.8726092576980591e-01
    phi[3,1]  R1028     8.9127159118652344e-01
    phi[3,1]  R1029     -2.4688229560852051e+00
    phi[3,1]  R1030     -5.5618780851364136e-01
    phi[3,1]  R1031     -3.7060627341270447e-01
    phi[3,1]  R1032     -1.1356040239334106e+00
    phi[3,1]  R1033     -3.3154060840606689e+00
    phi[3,1]  R1034     -3.1919665336608887e+00
    phi[3,1]  R1035     3.3773060888051987e-02
    phi[3,1]  R1036     -1.9388939440250397e-01
    phi[3,1]  R1037     -1.4169896841049194e+00
    phi[3,1]  R1038     6.2699353694915771e-01
    phi[3,1]  R1039     -2.2138059139251709e+00
    phi[3,1]  R1040     -4.3821075558662415e-01
    phi[3,1]  R1041     -2.9005081653594971e+00
    phi[3,1]  R1042     -3.4855628013610840e+00
    phi[3,1]  R1043     -3.3849532604217529e+00
    phi[3,1]  R1044     -2.5126025676727295e+00
    phi[3,1]  R1045     -1.8423423767089844e+00
    phi[3,1]  R1046     -2.3803708553314209e+00
    phi[3,1]  R1047     -2.4286077022552490e+00
    phi[3,1]  R1048     -1.7690980434417725e+00
    phi[3,1]  R1049     -2.3383741378784180e+00
    phi[3,1]  R1050     -1.5844079256057739e+00
    phi[3,1]  R1051     -1.8416551351547241e+00
    phi[3,1]  R1052     -1.5972393751144409e+00
    phi[3,1]  R1053     -2.5029242038726807e+00
    phi[3,1]  R1054     -3.3589406013488770e+00
    phi[3,1]  R1055     -1.6291214227676392e+00
    phi[3,1]  R1056     -2.2276577949523926e+00
    phi[3,1]  R1057     -1.0473197698593140e+00
    phi[3,1]  R1058     -2.9403550624847412e+00
    phi[3,1]  R1059     -2.4909644126892090e+00
    phi[3,1]  R1060     -3.5564205646514893e+00
    phi[3,1]  R1061     -2.7329914569854736e+00
    phi[3,1]  R1062     -3.5934164524078369e+00
    phi[3,1]  R1063     -1.3461574912071228e-01
    phi[3,1]  R1064     -6.1715304851531982e-02
    phi[3,1]  R1065     -2.3127028942108154e+00
    phi[3,1]  R1066     -1.7392649650573730e+00
    phi[3,1]  R1067     -3.7199242115020752e+00
    phi[3,1]  R1068     -2.0330641269683838e+00
    phi[3,1]  R1069     -3.1576628684997559e+00
    phi[3,1]  R1070     -3.7154734134674072e+00
    phi[3,1]  R1071     -3.12541127204895
    phi[3,1]  R1072     -8.8167816400527954e-01
    phi[3,1]  R1073     -2.7073490619659424e+00
    phi[3,1]  R1074     -1.4858646392822266e+00
    phi[3,1]  R1075     -2.1805851459503174e+00
    phi[3,1]  R1076     -2.01226806640625
    phi[3,1]  R1077     -0.92231285572052
    phi[3,1]  R1078     -1.8562942743301392e+00
    phi[3,1]  R1079     -2.6092917919158936e+00
    phi[3,1]  R1080     -2.0257587432861328e+00
    phi[3,1]  R1081     -2.1004478931427
    phi[3,1]  R1082     -1.4287390708923340e+00
    phi[3,1]  R1083     7.8135251998901367e-01
    phi[3,1]  R1084     -3.1438763141632080e+00
    phi[3,1]  R1085     -2.4436395168304443e+00
    phi[3,1]  R1086     -3.4440124034881592e+00
    phi[3,1]  R1087     -2.5341069698333740e+00
    phi[3,1]  R1088     -3.6094620227813721e+00
    phi[3,1]  R1089     -3.1685857772827148e+00
    phi[3,1]  R1090     -3.4119021892547607e+00
    phi[3,1]  R1091     -2.6836543083190918e+00
    phi[3,1]  R1092     -3.5992629528045654e+00
    phi[3,1]  R1093     -1.4282816648483276e+00
    phi[3,1]  R1094     -2.9186706542968750e+00
    phi[3,1]  R1095     -2.9752295017242432e+00
    phi[3,1]  R1096     -3.0119705200195312e+00
    phi[3,1]  R1097     -2.72963547706604
    phi[3,1]  R1098     -1.2211716175079346e+00
    phi[3,1]  R1099     -2.7258551120758057e-01
    phi[3,1]  R1100     5.0541174411773682e-01
    phi[3,1]  R1101     4.7650763392448425e-01
    phi[3,1]  R1102     7.9692453145980835e-01
    phi[3,1]  R1103     4.1498267650604248e-01
    phi[3,1]  R1104     1.8695031404495239e+00
    phi[3,1]  R1105     1.1766593903303146e-01
    phi[3,1]  R1106     7.3792296648025513e-01
    phi[3,1]  R1107     9.9899973720312119e-03
    phi[3,1]  R1108     -2.9520574212074280e-01
    phi[3,1]  R1109     -1.3779214620590210e+00
    phi[3,1]  R1110     -7.8688043355941772e-01
    phi[3,1]  R1111     -2.7813216671347618e-02
    phi[3,1]  R1112     -2.9272326827049255e-01
    phi[3,1]  R1113     2.1682879328727722e-01
    phi[3,1]  R1114     -1.0573991537094116e+00
    phi[3,1]  R1115     3.8142082095146179e-01
    phi[3,1]  R1116     0.043534055352211
    phi[3,1]  R1117     -0.550426721572876
    phi[3,1]  R1118     -1.7479392290115356e+00
    phi[3,1]  R1119     -3.8110303878784180e-01
    phi[3,1]  R1120     -2.7909765243530273e+00
    phi[3,1]  R1121     -1.9583910703659058e+00
    phi[3,1]  R1122     -9.1214990615844727e-01
    phi[3,1]  R1123     1.3661292195320129e-01
    phi[3,1]  R1124     -5.9480178356170654e-01
    phi[3,1]  R1125     5.3226560354232788e-02
    phi[3,1]  R1126     -1.5302872657775879e-01
    phi[3,1]  R1127     4.3125890195369720e-02
    phi[3,1]  R1128     -2.1801650524139404e+00
    phi[3,1]  R1129     -2.1650190353393555e+00
    phi[3,1]  R1130     -2.8554084300994873e+00
    phi[3,1]  R1131     -3.3533353805541992e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1132     -3.0999999046325684e+00
    phi[1,4]  R1133     -3.0999999046325684e+00
    phi[1,4]  R1134     -2.2400000095367432e+00
    phi[1,4]  R1135     -2.2400000095367432e+00
    phi[1,4]  R1136     -3.0999999046325684e+00
    phi[1,4]  R1137     -3.0999999046325684e+00
    phi[1,4]  R1138     -2.5699999332427979e+00
    phi[1,4]  R1139     -2.5699999332427979e+00
    phi[1,4]  R1140     -3.0999999046325684e+00
    phi[1,4]  R1141     -3.0999999046325684e+00
    phi[1,4]  R1142     -2.0899999141693115e+00
    phi[1,4]  R1143     -2.0899999141693115e+00
    phi[1,4]  R1144     -3.0999999046325684e+00
    phi[1,4]  R1145     -3.0999999046325684e+00
    phi[1,4]  R1146     7.9692453145980835e-01
    phi[1,4]  R1147     4.1498267650604248e-01
    phi[1,4]  R1148     1.8695031404495239e+00
    phi[1,4]  R1149     1.1766593903303146e-01
    phi[1,4]  R1150     7.3792296648025513e-01
    phi[1,4]  R1151     9.9899973720312119e-03
    phi[1,4]  R1152     -2.9520574212074280e-01
    phi[1,4]  R1153     -1.3779214620590210e+00
    phi[1,4]  R1154     -7.8688043355941772e-01
    phi[1,4]  R1155     -2.7813216671347618e-02
    phi[1,4]  R1156     -2.9272326827049255e-01
    phi[1,4]  R1157     2.1682879328727722e-01
    phi[1,4]  R1158     -1.0573991537094116e+00
    phi[1,4]  R1159     3.8142082095146179e-01
    phi[1,4]  R1160     0.043534055352211
    phi[1,4]  R1161     -0.550426721572876
    phi[1,4]  R1162     -1.7479392290115356e+00
    phi[1,4]  R1163     -3.8110303878784180e-01
    phi[1,4]  R1164     -2.7909765243530273e+00
    phi[1,4]  R1165     -1.9583910703659058e+00
    phi[1,4]  R1166     -9.1214990615844727e-01
    phi[1,4]  R1167     1.3661292195320129e-01
    phi[1,4]  R1168     -5.9480178356170654e-01
    phi[1,4]  R1169     5.3226560354232788e-02
    phi[1,4]  R1170     -1.5302872657775879e-01
    phi[1,4]  R1171     4.3125890195369720e-02
    phi[1,4]  R1172     -2.1801650524139404e+00
    phi[1,4]  R1173     -2.1650190353393555e+00
    phi[1,4]  R1174     -2.8554084300994873e+00
    phi[1,4]  R1175     -3.3533353805541992e+00
    phi[1,4]  R1176     8.1655305624008179e-01
    phi[1,4]  R1177     1.1620333194732666e+00
    phi[1,4]  R1178     -2.8205161914229393e-02
    phi[1,4]  R1179     -0.43563112616539
    phi[1,4]  R1180     5.8167535066604614e-01
    phi[1,4]  R1181     1.4057844877243042e+00
    phi[1,4]  R1182     9.6818111836910248e-02
    phi[1,4]  R1183     7.0932847261428833e-01
    phi[1,4]  R1184     5.7944321632385254e-01
    phi[1,4]  R1185     -1.5514412522315979e-01
    phi[1,4]  R1186     -1.0904399156570435e+00
    phi[1,4]  R1187     -5.9782242774963379e-01
    phi[1,4]  R1188     1.6199707984924316e-01
    phi[1,4]  R1189     -9.0435147285461426e-01
    phi[1,4]  R1190     -1.7013669013977051e-01
    phi[1,4]  R1191     -1.5011594295501709e+00
    phi[1,4]  R1192     -1.3497033119201660e+00
    phi[1,4]  R1193     -1.1549458503723145e+00
    phi[1,4]  R1194     5.7084769010543823e-01
    phi[1,4]  R1195     -1.7344825267791748e+00
    phi[1,4]  R1196     -1.0591309070587158e+00
    phi[1,4]  R1197     -1.8652031421661377e+00
    phi[1,4]  R1198     -0.281468003988266
    phi[1,4]  R1199     -1.0615569353103638e+00
    phi[1,4]  R1200     -2.05036997795105
    phi[1,4]  R1201     -5.2920693159103394e-01
    phi[1,4]  R1202     5.5447685718536377e-01
    phi[1,4]  R1203     -1.0072295367717743e-01
    phi[1,4]  R1204     -2.2217435836791992e+00
    phi[1,4]  R1205     2.5580215454101562e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1206     -3.0999999046325684e+00
    phi[4,1]  R1207     -3.0999999046325684e+00
    phi[4,1]  R1208     -2.2400000095367432e+00
    phi[4,1]  R1209     -2.2400000095367432e+00
    phi[4,1]  R1210     -3.0999999046325684e+00
    phi[4,1]  R1211     -3.0999999046325684e+00
    phi[4,1]  R1212     -2.5699999332427979e+00
    phi[4,1]  R1213     -2.5699999332427979e+00
    phi[4,1]  R1214     -3.0999999046325684e+00
    phi[4,1]  R1215     -3.0999999046325684e+00
    phi[4,1]  R1216     -2.0899999141693115e+00
    phi[4,1]  R1217     -2.0899999141693115e+00
    phi[4,1]  R1218     -3.0999999046325684e+00
    phi[4,1]  R1219     -3.0999999046325684e+00
    phi[4,1]  R1220     8.1655305624008179e-01
    phi[4,1]  R1221     1.1620333194732666e+00
    phi[4,1]  R1222     -2.8205161914229393e-02
    phi[4,1]  R1223     -0.43563112616539
    phi[4,1]  R1224     5.8167535066604614e-01
    phi[4,1]  R1225     1.4057844877243042e+00
    phi[4,1]  R1226     9.6818111836910248e-02
    phi[4,1]  R1227     7.0932847261428833e-01
    phi[4,1]  R1228     5.7944321632385254e-01
    phi[4,1]  R1229     -1.5514412522315979e-01
    phi[4,1]  R1230     -1.0904399156570435e+00
    phi[4,1]  R1231     -5.9782242774963379e-01
    phi[4,1]  R1232     1.6199707984924316e-01
    phi[4,1]  R1233     -9.0435147285461426e-01
    phi[4,1]  R1234     -1.7013669013977051e-01
    phi[4,1]  R1235     -1.5011594295501709e+00
    phi[4,1]  R1236     -1.3497033119201660e+00
    phi[4,1]  R1237     -1.1549458503723145e+00
    phi[4,1]  R1238     5.7084769010543823e-01
    phi[4,1]  R1239     -1.7344825267791748e+00
    phi[4,1]  R1240     -1.0591309070587158e+00
    phi[4,1]  R1241     -1.8652031421661377e+00
    phi[4,1]  R1242     -0.281468003988266
    phi[4,1]  R1243     -1.0615569353103638e+00
    phi[4,1]  R1244     -2.05036997795105
    phi[4,1]  R1245     -5.2920693159103394e-01
    phi[4,1]  R1246     5.5447685718536377e-01
    phi[4,1]  R1247     -1.0072295367717743e-01
    phi[4,1]  R1248     -2.2217435836791992e+00
    phi[4,1]  R1249     2.5580215454101562e-01
    phi[4,1]  R1250     7.9692453145980835e-01
    phi[4,1]  R1251     4.1498267650604248e-01
    phi[4,1]  R1252     1.8695031404495239e+00
    phi[4,1]  R1253     1.1766593903303146e-01
    phi[4,1]  R1254     7.3792296648025513e-01
    phi[4,1]  R1255     9.9899973720312119e-03
    phi[4,1]  R1256     -2.9520574212074280e-01
    phi[4,1]  R1257     -1.3779214620590210e+00
    phi[4,1]  R1258     -7.8688043355941772e-01
    phi[4,1]  R1259     -2.7813216671347618e-02
    phi[4,1]  R1260     -2.9272326827049255e-01
    phi[4,1]  R1261     2.1682879328727722e-01
    phi[4,1]  R1262     -1.0573991537094116e+00
    phi[4,1]  R1263     3.8142082095146179e-01
    phi[4,1]  R1264     0.043534055352211
    phi[4,1]  R1265     -0.550426721572876
    phi[4,1]  R1266     -1.7479392290115356e+00
    phi[4,1]  R1267     -3.8110303878784180e-01
    phi[4,1]  R1268     -2.7909765243530273e+00
    phi[4,1]  R1269     -1.9583910703659058e+00
    phi[4,1]  R1270     -9.1214990615844727e-01
    phi[4,1]  R1271     1.3661292195320129e-01
    phi[4,1]  R1272     -5.9480178356170654e-01
    phi[4,1]  R1273     5.3226560354232788e-02
    phi[4,1]  R1274     -1.5302872657775879e-01
    phi[4,1]  R1275     4.3125890195369720e-02
    phi[4,1]  R1276     -2.1801650524139404e+00
    phi[4,1]  R1277     -2.1650190353393555e+00
    phi[4,1]  R1278     -2.8554084300994873e+00
    phi[4,1]  R1279     -3.3533353805541992e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1280     -3.0999999046325684e+00
    phi[1,5]  R1281     -3.0999999046325684e+00
    phi[1,5]  R1282     -2.2400000095367432e+00
    phi[1,5]  R1283     -2.2400000095367432e+00
    phi[1,5]  R1284     -3.0999999046325684e+00
    phi[1,5]  R1285     -3.0999999046325684e+00
    phi[1,5]  R1286     -2.5699999332427979e+00
    phi[1,5]  R1287     -2.5699999332427979e+00
    phi[1,5]  R1288     -3.0999999046325684e+00
    phi[1,5]  R1289     -3.0999999046325684e+00
    phi[1,5]  R1290     -2.0899999141693115e+00
    phi[1,5]  R1291     -2.0899999141693115e+00
    phi[1,5]  R1292     -3.0999999046325684e+00
    phi[1,5]  R1293     -3.0999999046325684e+00
    phi[1,5]  R1294     7.9692453145980835e-01
    phi[1,5]  R1295     4.1498267650604248e-01
    phi[1,5]  R1296     1.8695031404495239e+00
    phi[1,5]  R1297     1.1766593903303146e-01
    phi[1,5]  R1298     7.3792296648025513e-01
    phi[1,5]  R1299     9.9899973720312119e-03
    phi[1,5]  R1300     -2.9520574212074280e-01
    phi[1,5]  R1301     -1.3779214620590210e+00
    phi[1,5]  R1302     -7.8688043355941772e-01
    phi[1,5]  R1303     -2.7813216671347618e-02
    phi[1,5]  R1304     -2.9272326827049255e-01
    phi[1,5]  R1305     2.1682879328727722e-01
    phi[1,5]  R1306     -1.0573991537094116e+00
    phi[1,5]  R1307     3.8142082095146179e-01
    phi[1,5]  R1308     0.043534055352211
    phi[1,5]  R1309     -0.550426721572876
    phi[1,5]  R1310     -1.7479392290115356e+00
    phi[1,5]  R1311     -3.8110303878784180e-01
    phi[1,5]  R1312     -2.7909765243530273e+00
    phi[1,5]  R1313     -1.9583910703659058e+00
    phi[1,5]  R1314     -9.1214990615844727e-01
    phi[1,5]  R1315     1.3661292195320129e-01
    phi[1,5]  R1316     -5.9480178356170654e-01
    phi[1,5]  R1317     5.3226560354232788e-02
    phi[1,5]  R1318     -1.5302872657775879e-01
    phi[1,5]  R1319     4.3125890195369720e-02
    phi[1,5]  R1320     -2.1801650524139404e+00
    phi[1,5]  R1321     -2.1650190353393555e+00
    phi[1,5]  R1322     -2.8554084300994873e+00
    phi[1,5]  R1323     -3.3533353805541992e+00
    phi[1,5]  R1324     -2.8846397995948792e-01
    phi[1,5]  R1325     1.4615159034729004e+00
    phi[1,5]  R1326     0.983528196811676
    phi[1,5]  R1327     -2.3301025852560997e-02
    phi[1,5]  R1328     2.6662519574165344e-01
    phi[1,5]  R1329     3.6829882860183716e-01
    phi[1,5]  R1330     4.6905797719955444e-01
    phi[1,5]  R1331     4.5205667614936829e-01
    phi[1,5]  R1332     9.5256060361862183e-01
    phi[1,5]  R1333     -6.6834056377410889e-01
    phi[1,5]  R1334     -1.6881691217422485e+00
    phi[1,5]  R1335     -1.0094193220138550e+00
    phi[1,5]  R1336     -5.7700490951538086e-01
    phi[1,5]  R1337     -6.4045554399490356e-01
    phi[1,5]  R1338     -1.3926999568939209e+00
    phi[1,5]  R1339     -1.9576880931854248e+00
    phi[1,5]  R1340     -1.6650320291519165e+00
    phi[1,5]  R1341     -0.529798150062561
    phi[1,5]  R1342     -2.4332444369792938e-01
    phi[1,5]  R1343     -2.4138660430908203e+00
    phi[1,5]  R1344     -9.0545341372489929e-02
    phi[1,5]  R1345     4.5779541134834290e-01
    phi[1,5]  R1346     -1.4954192936420441e-01
    phi[1,5]  R1347     9.2757618427276611e-01
    phi[1,5]  R1348     -4.4576722383499146e-01
    phi[1,5]  R1349     -3.1812247633934021e-01
    phi[1,5]  R1350     -1.0632225275039673e+00
    phi[1,5]  R1351     -1.6305726766586304e+00
    phi[1,5]  R1352     -5.6299334764480591e-01
    phi[1,5]  R1353     -3.3905154466629028e-01
    phi[1,5]  R1354     -9.9244117736816406e-01
    phi[1,5]  R1355     -1.8954734802246094e+00
    phi[1,5]  R1356     -6.2935304641723633e-01
    phi[1,5]  R1357     -1.5196196734905243e-01
    phi[1,5]  R1358     -5.2080713212490082e-02
    phi[1,5]  R1359     -1.5437867641448975e+00
    phi[1,5]  R1360     -2.24242901802063
    phi[1,5]  R1361     3.3327788114547729e-01
    phi[1,5]  R1362     7.9023164510726929e-01
    phi[1,5]  R1363     -4.4204935431480408e-01
    phi[1,5]  R1364     6.2672895193099976e-01
    phi[1,5]  R1365     -4.8952391743659973e-01
    phi[1,5]  R1366     2.6942148804664612e-01
    phi[1,5]  R1367     1.2509486675262451e+00
    phi[1,5]  R1368     -9.2550534009933472e-01
    phi[1,5]  R1369     7.0809596776962280e-01
    phi[1,5]  R1370     -5.6621938943862915e-01
    phi[1,5]  R1371     9.6870058774948120e-01
    phi[1,5]  R1372     3.5651507973670959e-01
    phi[1,5]  R1373     -2.4892117977142334e+00
    phi[1,5]  R1374     -7.9263502359390259e-01
    phi[1,5]  R1375     0.0931747555732727
    phi[1,5]  R1376     -1.3504660129547119e+00
    phi[1,5]  R1377     -3.4228610992431641e-01
    phi[1,5]  R1378     -9.6234247088432312e-02
    phi[1,5]  R1379     -1.0859930515289307e+00
    phi[1,5]  R1380     -1.6723790168762207e+00
    phi[1,5]  R1381     0.270022451877594
    phi[1,5]  R1382     -6.9997894763946533e-01
    phi[1,5]  R1383     -1.2201733589172363e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1384     -3.0999999046325684e+00
    phi[5,1]  R1385     -3.0999999046325684e+00
    phi[5,1]  R1386     -2.2400000095367432e+00
    phi[5,1]  R1387     -2.2400000095367432e+00
    phi[5,1]  R1388     -3.0999999046325684e+00
    phi[5,1]  R1389     -3.0999999046325684e+00
    phi[5,1]  R1390     -2.5699999332427979e+00
    phi[5,1]  R1391     -2.5699999332427979e+00
    phi[5,1]  R1392     -3.0999999046325684e+00
    phi[5,1]  R1393     -3.0999999046325684e+00
    phi[5,1]  R1394     -2.0899999141693115e+00
    phi[5,1]  R1395     -2.0899999141693115e+00
    phi[5,1]  R1396     -3.0999999046325684e+00
    phi[5,1]  R1397     -3.0999999046325684e+00
    phi[5,1]  R1398     -2.8846397995948792e-01
    phi[5,1]  R1399     1.4615159034729004e+00
    phi[5,1]  R1400     0.983528196811676
    phi[5,1]  R1401     -2.3301025852560997e-02
    phi[5,1]  R1402     2.6662519574165344e-01
    phi[5,1]  R1403     3.6829882860183716e-01
    phi[5,1]  R1404     4.6905797719955444e-01
    phi[5,1]  R1405     4.5205667614936829e-01
    phi[5,1]  R1406     9.5256060361862183e-01
    phi[5,1]  R1407     -6.6834056377410889e-01
    phi[5,1]  R1408     -1.6881691217422485e+00
    phi[5,1]  R1409     -1.0094193220138550e+00
    phi[5,1]  R1410     -5.7700490951538086e-01
    phi[5,1]  R1411     -6.4045554399490356e-01
    phi[5,1]  R1412     -1.3926999568939209e+00
    phi[5,1]  R1413     -1.9576880931854248e+00
    phi[5,1]  R1414     -1.6650320291519165e+00
    phi[5,1]  R1415     -0.529798150062561
    phi[5,1]  R1416     -2.4332444369792938e-01
    phi[5,1]  R1417     -2.4138660430908203e+00
    phi[5,1]  R1418     -9.0545341372489929e-02
    phi[5,1]  R1419     4.5779541134834290e-01
    phi[5,1]  R1420     -1.4954192936420441e-01
    phi[5,1]  R1421     9.2757618427276611e-01
    phi[5,1]  R1422     -4.4576722383499146e-01
    phi[5,1]  R1423     -3.1812247633934021e-01
    phi[5,1]  R1424     -1.0632225275039673e+00
    phi[5,1]  R1425     -1.6305726766586304e+00
    phi[5,1]  R1426     -5.6299334764480591e-01
    phi[5,1]  R1427     -3.3905154466629028e-01
    phi[5,1]  R1428     -9.9244117736816406e-01
    phi[5,1]  R1429     -1.8954734802246094e+00
    phi[5,1]  R1430     -6.2935304641723633e-01
    phi[5,1]  R1431     -1.5196196734905243e-01
    phi[5,1]  R1432     -5.2080713212490082e-02
    phi[5,1]  R1433     -1.5437867641448975e+00
    phi[5,1]  R1434     -2.24242901802063
    phi[5,1]  R1435     3.3327788114547729e-01
    phi[5,1]  R1436     7.9023164510726929e-01
    phi[5,1]  R1437     -4.4204935431480408e-01
    phi[5,1]  R1438     6.2672895193099976e-01
    phi[5,1]  R1439     -4.8952391743659973e-01
    phi[5,1]  R1440     2.6942148804664612e-01
    phi[5,1]  R1441     1.2509486675262451e+00
    phi[5,1]  R1442     -9.2550534009933472e-01
    phi[5,1]  R1443     7.0809596776962280e-01
    phi[5,1]  R1444     -5.6621938943862915e-01
    phi[5,1]  R1445     9.6870058774948120e-01
    phi[5,1]  R1446     3.5651507973670959e-01
    phi[5,1]  R1447     -2.4892117977142334e+00
    phi[5,1]  R1448     -7.9263502359390259e-01
    phi[5,1]  R1449     0.0931747555732727
    phi[5,1]  R1450     -1.3504660129547119e+00
    phi[5,1]  R1451     -3.4228610992431641e-01
    phi[5,1]  R1452     -9.6234247088432312e-02
    phi[5,1]  R1453     -1.0859930515289307e+00
    phi[5,1]  R1454     -1.6723790168762207e+00
    phi[5,1]  R1455     0.270022451877594
    phi[5,1]  R1456     -6.9997894763946533e-01
    phi[5,1]  R1457     -1.2201733589172363e+00
    phi[5,1]  R1458     7.9692453145980835e-01
    phi[5,1]  R1459     4.1498267650604248e-01
    phi[5,1]  R1460     1.8695031404495239e+00
    phi[5,1]  R1461     1.1766593903303146e-01
    phi[5,1]  R1462     7.3792296648025513e-01
    phi[5,1]  R1463     9.9899973720312119e-03
    phi[5,1]  R1464     -2.9520574212074280e-01
    phi[5,1]  R1465     -1.3779214620590210e+00
    phi[5,1]  R1466     -7.8688043355941772e-01
    phi[5,1]  R1467     -2.7813216671347618e-02
    phi[5,1]  R1468     -2.9272326827049255e-01
    phi[5,1]  R1469     2.1682879328727722e-01
    phi[5,1]  R1470     -1.0573991537094116e+00
    phi[5,1]  R1471     3.8142082095146179e-01
    phi[5,1]  R1472     0.043534055352211
    phi[5,1]  R1473     -0.550426721572876
    phi[5,1]  R1474     -1.7479392290115356e+00
    phi[5,1]  R1475     -3.8110303878784180e-01
    phi[5,1]  R1476     -2.7909765243530273e+00
    phi[5,1]  R1477     -1.9583910703659058e+00
    phi[5,1]  R1478     -9.1214990615844727e-01
    phi[5,1]  R1479     1.3661292195320129e-01
    phi[5,1]  R1480     -5.9480178356170654e-01
    phi[5,1]  R1481     5.3226560354232788e-02
    phi[5,1]  R1482     -1.5302872657775879e-01
    phi[5,1]  R1483     4.3125890195369720e-02
    phi[5,1]  R1484     -2.1801650524139404e+00
    phi[5,1]  R1485     -2.1650190353393555e+00
    phi[5,1]  R1486     -2.8554084300994873e+00
    phi[5,1]  R1487     -3.3533353805541992e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1488     -3.0999999046325684e+00
    phi[2,4]  R1489     -3.0999999046325684e+00
    phi[2,4]  R1490     -2.2400000095367432e+00
    phi[2,4]  R1491     -2.2400000095367432e+00
    phi[2,4]  R1492     -3.0999999046325684e+00
    phi[2,4]  R1493     -3.0999999046325684e+00
    phi[2,4]  R1494     -2.5699999332427979e+00
    phi[2,4]  R1495     -2.5699999332427979e+00
    phi[2,4]  R1496     -3.0999999046325684e+00
    phi[2,4]  R1497     -3.0999999046325684e+00
    phi[2,4]  R1498     -2.0899999141693115e+00
    phi[2,4]  R1499     -2.0899999141693115e+00
    phi[2,4]  R1500     -3.0999999046325684e+00
    phi[2,4]  R1501     -3.0999999046325684e+00
    phi[2,4]  R1502     4.2386963963508606e-02
    phi[2,4]  R1503     -9.9423122406005859e-01
    phi[2,4]  R1504     -4.2186436057090759e-01
    phi[2,4]  R1505     6.3430711627006531e-02
    phi[2,4]  R1506     -2.1387554705142975e-01
    phi[2,4]  R1507     -4.6012768149375916e-01
    phi[2,4]  R1508     -3.8501704111695290e-03
    phi[2,4]  R1509     -2.3238627240061760e-02
    phi[2,4]  R1510     4.9454070627689362e-02
    phi[2,4]  R1511     -6.1279177665710449e-01
    phi[2,4]  R1512     -1.0159367322921753e+00
    phi[2,4]  R1513     -1.4063947200775146e+00
    phi[2,4]  R1514     -4.5384517312049866e-01
    phi[2,4]  R1515     -1.1621637344360352e+00
    phi[2,4]  R1516     -1.4494122266769409e+00
    phi[2,4]  R1517     -1.9017596244812012e+00
    phi[2,4]  R1518     -1.4456139802932739e+00
    phi[2,4]  R1519     -1.0550187826156616e+00
    phi[2,4]  R1520     -9.3245500326156616e-01
    phi[2,4]  R1521     -1.1019502878189087e+00
    phi[2,4]  R1522     -7.9229104518890381e-01
    phi[2,4]  R1523     8.9914821088314056e-02
    phi[2,4]  R1524     -2.2242160141468048e-01
    phi[2,4]  R1525     4.8117554187774658e-01
    phi[2,4]  R1526     -2.8104444965720177e-02
    phi[2,4]  R1527     -9.4986081123352051e-01
    phi[2,4]  R1528     0.292352557182312
    phi[2,4]  R1529     -9.1885155439376831e-01
    phi[2,4]  R1530     -6.7174535989761353e-01
    phi[2,4]  R1531     -1.4303944110870361e+00
    phi[2,4]  R1532     -3.4025445580482483e-01
    phi[2,4]  R1533     -1.9758620858192444e-01
    phi[2,4]  R1534     -2.3860505223274231e-01
    phi[2,4]  R1535     6.0201418399810791e-01
    phi[2,4]  R1536     -2.3126417398452759e-01
    phi[2,4]  R1537     -3.0963113307952881e+00
    phi[2,4]  R1538     5.2583521604537964e-01
    phi[2,4]  R1539     -3.1415212154388428e-01
    phi[2,4]  R1540     -0.292779803276062
    phi[2,4]  R1541     2.4751776456832886e-01
    phi[2,4]  R1542     -9.5011007785797119e-01
    phi[2,4]  R1543     -1.9117995500564575e+00
    phi[2,4]  R1544     -1.1041853427886963e+00
    phi[2,4]  R1545     -9.4993555545806885e-01
    phi[2,4]  R1546     -9.3022906780242920e-01
    phi[2,4]  R1547     -1.1032702922821045e+00
    phi[2,4]  R1548     -1.7146047353744507e+00
    phi[2,4]  R1549     7.6810050010681152e-01
    phi[2,4]  R1550     -1.5306453704833984e+00
    phi[2,4]  R1551     -1.8092749118804932e+00
    phi[2,4]  R1552     8.1655305624008179e-01
    phi[2,4]  R1553     1.1620333194732666e+00
    phi[2,4]  R1554     -2.8205161914229393e-02
    phi[2,4]  R1555     -0.43563112616539
    phi[2,4]  R1556     5.8167535066604614e-01
    phi[2,4]  R1557     1.4057844877243042e+00
    phi[2,4]  R1558     9.6818111836910248e-02
    phi[2,4]  R1559     7.0932847261428833e-01
    phi[2,4]  R1560     5.7944321632385254e-01
    phi[2,4]  R1561     -1.5514412522315979e-01
    phi[2,4]  R1562     -1.0904399156570435e+00
    phi[2,4]  R1563     -5.9782242774963379e-01
    phi[2,4]  R1564     1.6199707984924316e-01
    phi[2,4]  R1565     -9.0435147285461426e-01
    phi[2,4]  R1566     -1.7013669013977051e-01
    phi[2,4]  R1567     -1.5011594295501709e+00
    phi[2,4]  R1568     -1.3497033119201660e+00
    phi[2,4]  R1569     -1.1549458503723145e+00
    phi[2,4]  R1570     5.7084769010543823e-01
    phi[2,4]  R1571     -1.7344825267791748e+00
    phi[2,4]  R1572     -1.0591309070587158e+00
    phi[2,4]  R1573     -1.8652031421661377e+00
    phi[2,4]  R1574     -0.281468003988266
    phi[2,4]  R1575     -1.0615569353103638e+00
    phi[2,4]  R1576     -2.05036997795105
    phi[2,4]  R1577     -5.2920693159103394e-01
    phi[2,4]  R1578     5.5447685718536377e-01
    phi[2,4]  R1579     -1.0072295367717743e-01
    phi[2,4]  R1580     -2.2217435836791992e+00
    phi[2,4]  R1581     2.5580215454101562e-01
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1582     -3.0999999046325684e+00
    phi[4,2]  R1583     -3.0999999046325684e+00
    phi[4,2]  R1584     -2.2400000095367432e+00
    phi[4,2]  R1585     -2.2400000095367432e+00
    phi[4,2]  R1586     -3.0999999046325684e+00
    phi[4,2]  R1587     -3.0999999046325684e+00
    phi[4,2]  R1588     -2.5699999332427979e+00
    phi[4,2]  R1589     -2.5699999332427979e+00
    phi[4,2]  R1590     -3.0999999046325684e+00
    phi[4,2]  R1591     -3.0999999046325684e+00
    phi[4,2]  R1592     -2.0899999141693115e+00
    phi[4,2]  R1593     -2.0899999141693115e+00
    phi[4,2]  R1594     -3.0999999046325684e+00
    phi[4,2]  R1595     -3.0999999046325684e+00
    phi[4,2]  R1596     8.1655305624008179e-01
    phi[4,2]  R1597     1.1620333194732666e+00
    phi[4,2]  R1598     -2.8205161914229393e-02
    phi[4,2]  R1599     -0.43563112616539
    phi[4,2]  R1600     5.8167535066604614e-01
    phi[4,2]  R1601     1.4057844877243042e+00
    phi[4,2]  R1602     9.6818111836910248e-02
    phi[4,2]  R1603     7.0932847261428833e-01
    phi[4,2]  R1604     5.7944321632385254e-01
    phi[4,2]  R1605     -1.5514412522315979e-01
    phi[4,2]  R1606     -1.0904399156570435e+00
    phi[4,2]  R1607     -5.9782242774963379e-01
    phi[4,2]  R1608     1.6199707984924316e-01
    phi[4,2]  R1609     -9.0435147285461426e-01
    phi[4,2]  R1610     -1.7013669013977051e-01
    phi[4,2]  R1611     -1.5011594295501709e+00
    phi[4,2]  R1612     -1.3497033119201660e+00
    phi[4,2]  R1613     -1.1549458503723145e+00
    phi[4,2]  R1614     5.7084769010543823e-01
    phi[4,2]  R1615     -1.7344825267791748e+00
    phi[4,2]  R1616     -1.0591309070587158e+00
    phi[4,2]  R1617     -1.8652031421661377e+00
    phi[4,2]  R1618     -0.281468003988266
    phi[4,2]  R1619     -1.0615569353103638e+00
    phi[4,2]  R1620     -2.05036997795105
    phi[4,2]  R1621     -5.2920693159103394e-01
    phi[4,2]  R1622     5.5447685718536377e-01
    phi[4,2]  R1623     -1.0072295367717743e-01
    phi[4,2]  R1624     -2.2217435836791992e+00
    phi[4,2]  R1625     2.5580215454101562e-01
    phi[4,2]  R1626     4.2386963963508606e-02
    phi[4,2]  R1627     -9.9423122406005859e-01
    phi[4,2]  R1628     -4.2186436057090759e-01
    phi[4,2]  R1629     6.3430711627006531e-02
    phi[4,2]  R1630     -2.1387554705142975e-01
    phi[4,2]  R1631     -4.6012768149375916e-01
    phi[4,2]  R1632     -3.8501704111695290e-03
    phi[4,2]  R1633     -2.3238627240061760e-02
    phi[4,2]  R1634     4.9454070627689362e-02
    phi[4,2]  R1635     -6.1279177665710449e-01
    phi[4,2]  R1636     -1.0159367322921753e+00
    phi[4,2]  R1637     -1.4063947200775146e+00
    phi[4,2]  R1638     -4.5384517312049866e-01
    phi[4,2]  R1639     -1.1621637344360352e+00
    phi[4,2]  R1640     -1.4494122266769409e+00
    phi[4,2]  R1641     -1.9017596244812012e+00
    phi[4,2]  R1642     -1.4456139802932739e+00
    phi[4,2]  R1643     -1.0550187826156616e+00
    phi[4,2]  R1644     -9.3245500326156616e-01
    phi[4,2]  R1645     -1.1019502878189087e+00
    phi[4,2]  R1646     -7.9229104518890381e-01
    phi[4,2]  R1647     8.9914821088314056e-02
    phi[4,2]  R1648     -2.2242160141468048e-01
    phi[4,2]  R1649     4.8117554187774658e-01
    phi[4,2]  R1650     -2.8104444965720177e-02
    phi[4,2]  R1651     -9.4986081123352051e-01
    phi[4,2]  R1652     0.292352557182312
    phi[4,2]  R1653     -9.1885155439376831e-01
    phi[4,2]  R1654     -6.7174535989761353e-01
    phi[4,2]  R1655     -1.4303944110870361e+00
    phi[4,2]  R1656     -3.4025445580482483e-01
    phi[4,2]  R1657     -1.9758620858192444e-01
    phi[4,2]  R1658     -2.3860505223274231e-01
    phi[4,2]  R1659     6.0201418399810791e-01
    phi[4,2]  R1660     -2.3126417398452759e-01
    phi[4,2]  R1661     -3.0963113307952881e+00
    phi[4,2]  R1662     5.2583521604537964e-01
    phi[4,2]  R1663     -3.1415212154388428e-01
    phi[4,2]  R1664     -0.292779803276062
    phi[4,2]  R1665     2.4751776456832886e-01
    phi[4,2]  R1666     -9.5011007785797119e-01
    phi[4,2]  R1667     -1.9117995500564575e+00
    phi[4,2]  R1668     -1.1041853427886963e+00
    phi[4,2]  R1669     -9.4993555545806885e-01
    phi[4,2]  R1670     -9.3022906780242920e-01
    phi[4,2]  R1671     -1.1032702922821045e+00
    phi[4,2]  R1672     -1.7146047353744507e+00
    phi[4,2]  R1673     7.6810050010681152e-01
    phi[4,2]  R1674     -1.5306453704833984e+00
    phi[4,2]  R1675     -1.8092749118804932e+00
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1676     -3.0999999046325684e+00
    phi[2,5]  R1677     -3.0999999046325684e+00
    phi[2,5]  R1678     -2.2400000095367432e+00
    phi[2,5]  R1679     -2.2400000095367432e+00
    phi[2,5]  R1680     -3.0999999046325684e+00
    phi[2,5]  R1681     -3.0999999046325684e+00
    phi[2,5]  R1682     -2.5699999332427979e+00
    phi[2,5]  R1683     -2.5699999332427979e+00
    phi[2,5]  R1684     -3.0999999046325684e+00
    phi[2,5]  R1685     -3.0999999046325684e+00
    phi[2,5]  R1686     -2.0899999141693115e+00
    phi[2,5]  R1687     -2.0899999141693115e+00
    phi[2,5]  R1688     -3.0999999046325684e+00
    phi[2,5]  R1689     -3.0999999046325684e+00
    phi[2,5]  R1690     4.2386963963508606e-02
    phi[2,5]  R1691     -9.9423122406005859e-01
    phi[2,5]  R1692     -4.2186436057090759e-01
    phi[2,5]  R1693     6.3430711627006531e-02
    phi[2,5]  R1694     -2.1387554705142975e-01
    phi[2,5]  R1695     -4.6012768149375916e-01
    phi[2,5]  R1696     -3.8501704111695290e-03
    phi[2,5]  R1697     -2.3238627240061760e-02
    phi[2,5]  R1698     4.9454070627689362e-02
    phi[2,5]  R1699     -6.1279177665710449e-01
    phi[2,5]  R1700     -1.0159367322921753e+00
    phi[2,5]  R1701     -1.4063947200775146e+00
    phi[2,5]  R1702     -4.5384517312049866e-01
    phi[2,5]  R1703     -1.1621637344360352e+00
    phi[2,5]  R1704     -1.4494122266769409e+00
    phi[2,5]  R1705     -1.9017596244812012e+00
    phi[2,5]  R1706     -1.4456139802932739e+00
    phi[2,5]  R1707     -1.0550187826156616e+00
    phi[2,5]  R1708     -9.3245500326156616e-01
    phi[2,5]  R1709     -1.1019502878189087e+00
    phi[2,5]  R1710     -7.9229104518890381e-01
    phi[2,5]  R1711     8.9914821088314056e-02
    phi[2,5]  R1712     -2.2242160141468048e-01
    phi[2,5]  R1713     4.8117554187774658e-01
    phi[2,5]  R1714     -2.8104444965720177e-02
    phi[2,5]  R1715     -9.4986081123352051e-01
    phi[2,5]  R1716     0.292352557182312
    phi[2,5]  R1717     -9.1885155439376831e-01
    phi[2,5]  R1718     -6.7174535989761353e-01
    phi[2,5]  R1719     -1.4303944110870361e+00
    phi[2,5]  R1720     -3.4025445580482483e-01
    phi[2,5]  R1721     -1.9758620858192444e-01
    phi[2,5]  R1722     -2.3860505223274231e-01
    phi[2,5]  R1723     6.0201418399810791e-01
    phi[2,5]  R1724     -2.3126417398452759e-01
    phi[2,5]  R1725     -3.0963113307952881e+00
    phi[2,5]  R1726     5.2583521604537964e-01
    phi[2,5]  R1727     -3.1415212154388428e-01
    phi[2,5]  R1728     -0.292779803276062
    phi[2,5]  R1729     2.4751776456832886e-01
    phi[2,5]  R1730     -9.5011007785797119e-01
    phi[2,5]  R1731     -1.9117995500564575e+00
    phi[2,5]  R1732     -1.1041853427886963e+00
    phi[2,5]  R1733     -9.4993555545806885e-01
    phi[2,5]  R1734     -9.3022906780242920e-01
    phi[2,5]  R1735     -1.1032702922821045e+00
    phi[2,5]  R1736     -1.7146047353744507e+00
    phi[2,5]  R1737     7.6810050010681152e-01
    phi[2,5]  R1738     -1.5306453704833984e+00
    phi[2,5]  R1739     -1.8092749118804932e+00
    phi[2,5]  R1740     -2.8846397995948792e-01
    phi[2,5]  R1741     1.4615159034729004e+00
    phi[2,5]  R1742     0.983528196811676
    phi[2,5]  R1743     -2.3301025852560997e-02
    phi[2,5]  R1744     2.6662519574165344e-01
    phi[2,5]  R1745     3.6829882860183716e-01
    phi[2,5]  R1746     4.6905797719955444e-01
    phi[2,5]  R1747     4.5205667614936829e-01
    phi[2,5]  R1748     9.5256060361862183e-01
    phi[2,5]  R1749     -6.6834056377410889e-01
    phi[2,5]  R1750     -1.6881691217422485e+00
    phi[2,5]  R1751     -1.0094193220138550e+00
    phi[2,5]  R1752     -5.7700490951538086e-01
    phi[2,5]  R1753     -6.4045554399490356e-01
    phi[2,5]  R1754     -1.3926999568939209e+00
    phi[2,5]  R1755     -1.9576880931854248e+00
    phi[2,5]  R1756     -1.6650320291519165e+00
    phi[2,5]  R1757     -0.529798150062561
    phi[2,5]  R1758     -2.4332444369792938e-01
    phi[2,5]  R1759     -2.4138660430908203e+00
    phi[2,5]  R1760     -9.0545341372489929e-02
    phi[2,5]  R1761     4.5779541134834290e-01
    phi[2,5]  R1762     -1.4954192936420441e-01
    phi[2,5]  R1763     9.2757618427276611e-01
    phi[2,5]  R1764     -4.4576722383499146e-01
    phi[2,5]  R1765     -3.1812247633934021e-01
    phi[2,5]  R1766     -1.0632225275039673e+00
    phi[2,5]  R1767     -1.6305726766586304e+00
    phi[2,5]  R1768     -5.6299334764480591e-01
    phi[2,5]  R1769     -3.3905154466629028e-01
    phi[2,5]  R1770     -9.9244117736816406e-01
    phi[2,5]  R1771     -1.8954734802246094e+00
    phi[2,5]  R1772     -6.2935304641723633e-01
    phi[2,5]  R1773     -1.5196196734905243e-01
    phi[2,5]  R1774     -5.2080713212490082e-02
    phi[2,5]  R1775     -1.5437867641448975e+00
    phi[2,5]  R1776     -2.24242901802063
    phi[2,5]  R1777     3.3327788114547729e-01
    phi[2,5]  R1778     7.9023164510726929e-01
    phi[2,5]  R1779     -4.4204935431480408e-01
    phi[2,5]  R1780     6.2672895193099976e-01
    phi[2,5]  R1781     -4.8952391743659973e-01
    phi[2,5]  R1782     2.6942148804664612e-01
    phi[2,5]  R1783     1.2509486675262451e+00
    phi[2,5]  R1784     -9.2550534009933472e-01
    phi[2,5]  R1785     7.0809596776962280e-01
    phi[2,5]  R1786     -5.6621938943862915e-01
    phi[2,5]  R1787     9.6870058774948120e-01
    phi[2,5]  R1788     3.5651507973670959e-01
    phi[2,5]  R1789     -2.4892117977142334e+00
    phi[2,5]  R1790     -7.9263502359390259e-01
    phi[2,5]  R1791     0.0931747555732727
    phi[2,5]  R1792     -1.3504660129547119e+00
    phi[2,5]  R1793     -3.4228610992431641e-01
    phi[2,5]  R1794     -9.6234247088432312e-02
    phi[2,5]  R1795     -1.0859930515289307e+00
    phi[2,5]  R1796     -1.6723790168762207e+00
    phi[2,5]  R1797     0.270022451877594
    phi[2,5]  R1798     -6.9997894763946533e-01
    phi[2,5]  R1799     -1.2201733589172363e+00
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1800     -3.0999999046325684e+00
    phi[5,2]  R1801     -3.0999999046325684e+00
    phi[5,2]  R1802     -2.2400000095367432e+00
    phi[5,2]  R1803     -2.2400000095367432e+00
    phi[5,2]  R1804     -3.0999999046325684e+00
    phi[5,2]  R1805     -3.0999999046325684e+00
    phi[5,2]  R1806     -2.5699999332427979e+00
    phi[5,2]  R1807     -2.5699999332427979e+00
    phi[5,2]  R1808     -3.0999999046325684e+00
    phi[5,2]  R1809     -3.0999999046325684e+00
    phi[5,2]  R1810     -2.0899999141693115e+00
    phi[5,2]  R1811     -2.0899999141693115e+00
    phi[5,2]  R1812     -3.0999999046325684e+00
    phi[5,2]  R1813     -3.0999999046325684e+00
    phi[5,2]  R1814     -2.8846397995948792e-01
    phi[5,2]  R1815     1.4615159034729004e+00
    phi[5,2]  R1816     0.983528196811676
    phi[5,2]  R1817     -2.3301025852560997e-02
    phi[5,2]  R1818     2.6662519574165344e-01
    phi[5,2]  R1819     3.6829882860183716e-01
    phi[5,2]  R1820     4.6905797719955444e-01
    phi[5,2]  R1821     4.5205667614936829e-01
    phi[5,2]  R1822     9.5256060361862183e-01
    phi[5,2]  R1823     -6.6834056377410889e-01
    phi[5,2]  R1824     -1.6881691217422485e+00
    phi[5,2]  R1825     -1.0094193220138550e+00
    phi[5,2]  R1826     -5.7700490951538086e-01
    phi[5,2]  R1827     -6.4045554399490356e-01
    phi[5,2]  R1828     -1.3926999568939209e+00
    phi[5,2]  R1829     -1.9576880931854248e+00
    phi[5,2]  R1830     -1.6650320291519165e+00
    phi[5,2]  R1831     -0.529798150062561
    phi[5,2]  R1832     -2.4332444369792938e-01
    phi[5,2]  R1833     -2.4138660430908203e+00
    phi[5,2]  R1834     -9.0545341372489929e-02
    phi[5,2]  R1835     4.5779541134834290e-01
    phi[5,2]  R1836     -1.4954192936420441e-01
    phi[5,2]  R1837     9.2757618427276611e-01
    phi[5,2]  R1838     -4.4576722383499146e-01
    phi[5,2]  R1839     -3.1812247633934021e-01
    phi[5,2]  R1840     -1.0632225275039673e+00
    phi[5,2]  R1841     -1.6305726766586304e+00
    phi[5,2]  R1842     -5.6299334764480591e-01
    phi[5,2]  R1843     -3.3905154466629028e-01
    phi[5,2]  R1844     -9.9244117736816406e-01
    phi[5,2]  R1845     -1.8954734802246094e+00
    phi[5,2]  R1846     -6.2935304641723633e-01
    phi[5,2]  R1847     -1.5196196734905243e-01
    phi[5,2]  R1848     -5.2080713212490082e-02
    phi[5,2]  R1849     -1.5437867641448975e+00
    phi[5,2]  R1850     -2.24242901802063
    phi[5,2]  R1851     3.3327788114547729e-01
    phi[5,2]  R1852     7.9023164510726929e-01
    phi[5,2]  R1853     -4.4204935431480408e-01
    phi[5,2]  R1854     6.2672895193099976e-01
    phi[5,2]  R1855     -4.8952391743659973e-01
    phi[5,2]  R1856     2.6942148804664612e-01
    phi[5,2]  R1857     1.2509486675262451e+00
    phi[5,2]  R1858     -9.2550534009933472e-01
    phi[5,2]  R1859     7.0809596776962280e-01
    phi[5,2]  R1860     -5.6621938943862915e-01
    phi[5,2]  R1861     9.6870058774948120e-01
    phi[5,2]  R1862     3.5651507973670959e-01
    phi[5,2]  R1863     -2.4892117977142334e+00
    phi[5,2]  R1864     -7.9263502359390259e-01
    phi[5,2]  R1865     0.0931747555732727
    phi[5,2]  R1866     -1.3504660129547119e+00
    phi[5,2]  R1867     -3.4228610992431641e-01
    phi[5,2]  R1868     -9.6234247088432312e-02
    phi[5,2]  R1869     -1.0859930515289307e+00
    phi[5,2]  R1870     -1.6723790168762207e+00
    phi[5,2]  R1871     0.270022451877594
    phi[5,2]  R1872     -6.9997894763946533e-01
    phi[5,2]  R1873     -1.2201733589172363e+00
    phi[5,2]  R1874     4.2386963963508606e-02
    phi[5,2]  R1875     -9.9423122406005859e-01
    phi[5,2]  R1876     -4.2186436057090759e-01
    phi[5,2]  R1877     6.3430711627006531e-02
    phi[5,2]  R1878     -2.1387554705142975e-01
    phi[5,2]  R1879     -4.6012768149375916e-01
    phi[5,2]  R1880     -3.8501704111695290e-03
    phi[5,2]  R1881     -2.3238627240061760e-02
    phi[5,2]  R1882     4.9454070627689362e-02
    phi[5,2]  R1883     -6.1279177665710449e-01
    phi[5,2]  R1884     -1.0159367322921753e+00
    phi[5,2]  R1885     -1.4063947200775146e+00
    phi[5,2]  R1886     -4.5384517312049866e-01
    phi[5,2]  R1887     -1.1621637344360352e+00
    phi[5,2]  R1888     -1.4494122266769409e+00
    phi[5,2]  R1889     -1.9017596244812012e+00
    phi[5,2]  R1890     -1.4456139802932739e+00
    phi[5,2]  R1891     -1.0550187826156616e+00
    phi[5,2]  R1892     -9.3245500326156616e-01
    phi[5,2]  R1893     -1.1019502878189087e+00
    phi[5,2]  R1894     -7.9229104518890381e-01
    phi[5,2]  R1895     8.9914821088314056e-02
    phi[5,2]  R1896     -2.2242160141468048e-01
    phi[5,2]  R1897     4.8117554187774658e-01
    phi[5,2]  R1898     -2.8104444965720177e-02
    phi[5,2]  R1899     -9.4986081123352051e-01
    phi[5,2]  R1900     0.292352557182312
    phi[5,2]  R1901     -9.1885155439376831e-01
    phi[5,2]  R1902     -6.7174535989761353e-01
    phi[5,2]  R1903     -1.4303944110870361e+00
    phi[5,2]  R1904     -3.4025445580482483e-01
    phi[5,2]  R1905     -1.9758620858192444e-01
    phi[5,2]  R1906     -2.3860505223274231e-01
    phi[5,2]  R1907     6.0201418399810791e-01
    phi[5,2]  R1908     -2.3126417398452759e-01
    phi[5,2]  R1909     -3.0963113307952881e+00
    phi[5,2]  R1910     5.2583521604537964e-01
    phi[5,2]  R1911     -3.1415212154388428e-01
    phi[5,2]  R1912     -0.292779803276062
    phi[5,2]  R1913     2.4751776456832886e-01
    phi[5,2]  R1914     -9.5011007785797119e-01
    phi[5,2]  R1915     -1.9117995500564575e+00
    phi[5,2]  R1916     -1.1041853427886963e+00
    phi[5,2]  R1917     -9.4993555545806885e-01
    phi[5,2]  R1918     -9.3022906780242920e-01
    phi[5,2]  R1919     -1.1032702922821045e+00
    phi[5,2]  R1920     -1.7146047353744507e+00
    phi[5,2]  R1921     7.6810050010681152e-01
    phi[5,2]  R1922     -1.5306453704833984e+00
    phi[5,2]  R1923     -1.8092749118804932e+00
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R20       2.9615627696593729e+00
    phi[2,7]  R21       6.4014715830305491e-02
    phi[2,7]  R22       -2.9099648328199064e+00
    phi[2,7]  R23       -5.9939080591060456e-02
    phi[2,7]  R24       1.3150820782356845e+00
    phi[2,7]  R25       -1.8623749448731539e+00
    phi[2,7]  R26       -1.6357310874122519e+00
    phi[2,7]  R55       -1
    phi[2,7]  R1924     -1.3843713497319543e-01
    phi[2,7]  R1925     -6.0615626742919417e+00
    phi[2,7]  R1926     -2.1759852937064377e+00
    phi[2,7]  R1927     -2.3040147253670487e+00
    phi[2,7]  R1928     -6.0099647374524743e+00
    phi[2,7]  R1929     -0.190035071812662
    phi[2,7]  R1930     -2.6299390138338583e+00
    phi[2,7]  R1931     -2.5100608526517374e+00
    phi[2,7]  R1932     -1.7849178263968839e+00
    phi[2,7]  R1933     -4.4150819828682533e+00
    phi[2,7]  R1934     -3.9523748590424654e+00
    phi[2,7]  R1935     -2.2762496929615761e-01
    phi[2,7]  R1936     -4.73573099204482
    phi[2,7]  R1937     -1.4642688172203164e+00
    phi[2,7]  R1938     -4.3503838106801462e-01
    phi[2,7]  R1939     -1.7136763709056169e+00
    phi[2,7]  R1940     -7.8414532011113214e-01
    phi[2,7]  R1941     -2.2086709727958271e+00
    phi[2,7]  R1942     -3.2489219537262306e+00
    phi[2,7]  R1943     -9.7520868377400260e-01
    phi[2,7]  R1944     -2.7649523054647656e+00
    phi[2,7]  R1945     -2.1692750008413757e+00
    phi[2,7]  R1946     -1.9961542942653092e+00
    phi[2,7]  R1947     -1.1899503967865077e+00
    phi[2,7]  R1948     -6.0978787067882767e-01
    phi[2,7]  R1949     -6.3648074112253972e-01
    phi[2,7]  R1950     -6.4993718508549136e-01
    phi[2,7]  R1951     -6.5173588224582923e-01
    phi[2,7]  R1952     -6.6709565961699679e-01
    phi[2,7]  R1953     -6.8005221522195525e-01
    phi[2,7]  R1954     -6.8074221343883967e-01
    phi[2,7]  R1955     -7.0078410307184447e-01
    phi[2,7]  R1956     -7.0452944162243081e-01
    phi[2,7]  R1957     -7.2878968757918328e-01
    phi[2,7]  R1958     -4.9680317141433422e-01
    phi[2,7]  R1959     -6.0745100476041058e-01
    phi[2,7]  R1960     -6.2163073621890941e-01
    phi[2,7]  R1961     -6.3378156324460866e-01
    phi[2,7]  R1962     -6.3497189290109257e-01
    phi[2,7]  R1963     -6.3779595967107117e-01
    phi[2,7]  R1964     -6.7705459655227884e-01
    phi[2,7]  R1965     -8.9065032799378241e-01
    phi[2,7]  R1966     -7.7060565903144873e-01
    phi[2,7]  R1967     -8.0936363374354658e-01
    phi[2,7]  R1968     -1.8434556426123672e+00
    phi[2,7]  R1969     -5.0279825903039044e-01
    phi[2,7]  R1970     -0.506641023834444
    phi[2,7]  R1971     -5.1952308343102116e-01
    phi[2,7]  R1972     -5.6866841246276245e-01
    phi[2,7]  R1973     -6.1385032552624086e-01
    phi[2,7]  R1974     -6.4966383244823955e-01
    phi[2,7]  R1975     -6.7604327071759629e-01
    phi[2,7]  R1976     -0.679565513724251
    phi[2,7]  R1977     -6.8660502536948687e-01
    phi[2,7]  R1978     -5.0371502943426594e-01
    phi[2,7]  R1979     -5.1214474769891516e-01
    phi[2,7]  R1980     -6.2744379516313631e-01
    phi[2,7]  R1981     -6.3687894931540578e-01
    phi[2,7]  R1982     -6.8828047370675527e-01
    phi[2,7]  R1983     -7.0682163111792917e-01
    phi[2,7]  R1984     -7.2716147931109787e-01
    phi[2,7]  R1985     -7.4475081502186180e-01
    phi[2,7]  R1986     -7.6463783488879922e-01
    phi[2,7]  R1987     -7.6467590343701342e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1988     -3.0999999046325684e+00
    phi[3,4]  R1989     -3.0999999046325684e+00
    phi[3,4]  R1990     -2.2400000095367432e+00
    phi[3,4]  R1991     -2.2400000095367432e+00
    phi[3,4]  R1992     -3.0999999046325684e+00
    phi[3,4]  R1993     -3.0999999046325684e+00
    phi[3,4]  R1994     -2.5699999332427979e+00
    phi[3,4]  R1995     -2.5699999332427979e+00
    phi[3,4]  R1996     -3.0999999046325684e+00
    phi[3,4]  R1997     -3.0999999046325684e+00
    phi[3,4]  R1998     -2.0899999141693115e+00
    phi[3,4]  R1999     -2.0899999141693115e+00
    phi[3,4]  R2000     -3.0999999046325684e+00
    phi[3,4]  R2001     -3.0999999046325684e+00
    phi[3,4]  R2002     1.7334573268890381e+00
    phi[3,4]  R2003     2.2319107055664062e+00
    phi[3,4]  R2004     2.9019949436187744e+00
    phi[3,4]  R2005     -9.2549228668212891e-01
    phi[3,4]  R2006     -1.41675865650177
    phi[3,4]  R2007     6.8726092576980591e-01
    phi[3,4]  R2008     8.9127159118652344e-01
    phi[3,4]  R2009     -2.4688229560852051e+00
    phi[3,4]  R2010     -5.5618780851364136e-01
    phi[3,4]  R2011     -3.7060627341270447e-01
    phi[3,4]  R2012     -1.1356040239334106e+00
    phi[3,4]  R2013     -3.3154060840606689e+00
    phi[3,4]  R2014     -3.1919665336608887e+00
    phi[3,4]  R2015     3.3773060888051987e-02
    phi[3,4]  R2016     -1.9388939440250397e-01
    phi[3,4]  R2017     -1.4169896841049194e+00
    phi[3,4]  R2018     6.2699353694915771e-01
    phi[3,4]  R2019     -2.2138059139251709e+00
    phi[3,4]  R2020     -4.3821075558662415e-01
    phi[3,4]  R2021     -2.9005081653594971e+00
    phi[3,4]  R2022     -3.4855628013610840e+00
    phi[3,4]  R2023     -3.3849532604217529e+00
    phi[3,4]  R2024     -2.5126025676727295e+00
    phi[3,4]  R2025     -1.8423423767089844e+00
    phi[3,4]  R2026     -2.3803708553314209e+00
    phi[3,4]  R2027     -2.4286077022552490e+00
    phi[3,4]  R2028     -1.7690980434417725e+00
    phi[3,4]  R2029     -2.3383741378784180e+00
    phi[3,4]  R2030     -1.5844079256057739e+00
    phi[3,4]  R2031     -1.8416551351547241e+00
    phi[3,4]  R2032     -1.5972393751144409e+00
    phi[3,4]  R2033     -2.5029242038726807e+00
    phi[3,4]  R2034     -3.3589406013488770e+00
    phi[3,4]  R2035     -1.6291214227676392e+00
    phi[3,4]  R2036     -2.2276577949523926e+00
    phi[3,4]  R2037     -1.0473197698593140e+00
    phi[3,4]  R2038     -2.9403550624847412e+00
    phi[3,4]  R2039     -2.4909644126892090e+00
    phi[3,4]  R2040     -3.5564205646514893e+00
    phi[3,4]  R2041     -2.7329914569854736e+00
    phi[3,4]  R2042     -3.5934164524078369e+00
    phi[3,4]  R2043     -1.3461574912071228e-01
    phi[3,4]  R2044     -6.1715304851531982e-02
    phi[3,4]  R2045     -2.3127028942108154e+00
    phi[3,4]  R2046     -1.7392649650573730e+00
    phi[3,4]  R2047     -3.7199242115020752e+00
    phi[3,4]  R2048     -2.0330641269683838e+00
    phi[3,4]  R2049     -3.1576628684997559e+00
    phi[3,4]  R2050     -3.7154734134674072e+00
    phi[3,4]  R2051     -3.12541127204895
    phi[3,4]  R2052     -8.8167816400527954e-01
    phi[3,4]  R2053     -2.7073490619659424e+00
    phi[3,4]  R2054     -1.4858646392822266e+00
    phi[3,4]  R2055     -2.1805851459503174e+00
    phi[3,4]  R2056     -2.01226806640625
    phi[3,4]  R2057     -0.92231285572052
    phi[3,4]  R2058     -1.8562942743301392e+00
    phi[3,4]  R2059     -2.6092917919158936e+00
    phi[3,4]  R2060     -2.0257587432861328e+00
    phi[3,4]  R2061     -2.1004478931427
    phi[3,4]  R2062     -1.4287390708923340e+00
    phi[3,4]  R2063     7.8135251998901367e-01
    phi[3,4]  R2064     -3.1438763141632080e+00
    phi[3,4]  R2065     -2.4436395168304443e+00
    phi[3,4]  R2066     -3.4440124034881592e+00
    phi[3,4]  R2067     -2.5341069698333740e+00
    phi[3,4]  R2068     -3.6094620227813721e+00
    phi[3,4]  R2069     -3.1685857772827148e+00
    phi[3,4]  R2070     -3.4119021892547607e+00
    phi[3,4]  R2071     -2.6836543083190918e+00
    phi[3,4]  R2072     -3.5992629528045654e+00
    phi[3,4]  R2073     -1.4282816648483276e+00
    phi[3,4]  R2074     -2.9186706542968750e+00
    phi[3,4]  R2075     -2.9752295017242432e+00
    phi[3,4]  R2076     -3.0119705200195312e+00
    phi[3,4]  R2077     -2.72963547706604
    phi[3,4]  R2078     -1.2211716175079346e+00
    phi[3,4]  R2079     -2.7258551120758057e-01
    phi[3,4]  R2080     5.0541174411773682e-01
    phi[3,4]  R2081     4.7650763392448425e-01
    phi[3,4]  R2082     8.1655305624008179e-01
    phi[3,4]  R2083     1.1620333194732666e+00
    phi[3,4]  R2084     -2.8205161914229393e-02
    phi[3,4]  R2085     -0.43563112616539
    phi[3,4]  R2086     5.8167535066604614e-01
    phi[3,4]  R2087     1.4057844877243042e+00
    phi[3,4]  R2088     9.6818111836910248e-02
    phi[3,4]  R2089     7.0932847261428833e-01
    phi[3,4]  R2090     5.7944321632385254e-01
    phi[3,4]  R2091     -1.5514412522315979e-01
    phi[3,4]  R2092     -1.0904399156570435e+00
    phi[3,4]  R2093     -5.9782242774963379e-01
    phi[3,4]  R2094     1.6199707984924316e-01
    phi[3,4]  R2095     -9.0435147285461426e-01
    phi[3,4]  R2096     -1.7013669013977051e-01
    phi[3,4]  R2097     -1.5011594295501709e+00
    phi[3,4]  R2098     -1.3497033119201660e+00
    phi[3,4]  R2099     -1.1549458503723145e+00
    phi[3,4]  R2100     5.7084769010543823e-01
    phi[3,4]  R2101     -1.7344825267791748e+00
    phi[3,4]  R2102     -1.0591309070587158e+00
    phi[3,4]  R2103     -1.8652031421661377e+00
    phi[3,4]  R2104     -0.281468003988266
    phi[3,4]  R2105     -1.0615569353103638e+00
    phi[3,4]  R2106     -2.05036997795105
    phi[3,4]  R2107     -5.2920693159103394e-01
    phi[3,4]  R2108     5.5447685718536377e-01
    phi[3,4]  R2109     -1.0072295367717743e-01
    phi[3,4]  R2110     -2.2217435836791992e+00
    phi[3,4]  R2111     2.5580215454101562e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2112     -3.0999999046325684e+00
    phi[4,3]  R2113     -3.0999999046325684e+00
    phi[4,3]  R2114     -2.2400000095367432e+00
    phi[4,3]  R2115     -2.2400000095367432e+00
    phi[4,3]  R2116     -3.0999999046325684e+00
    phi[4,3]  R2117     -3.0999999046325684e+00
    phi[4,3]  R2118     -2.5699999332427979e+00
    phi[4,3]  R2119     -2.5699999332427979e+00
    phi[4,3]  R2120     -3.0999999046325684e+00
    phi[4,3]  R2121     -3.0999999046325684e+00
    phi[4,3]  R2122     -2.0899999141693115e+00
    phi[4,3]  R2123     -2.0899999141693115e+00
    phi[4,3]  R2124     -3.0999999046325684e+00
    phi[4,3]  R2125     -3.0999999046325684e+00
    phi[4,3]  R2126     8.1655305624008179e-01
    phi[4,3]  R2127     1.1620333194732666e+00
    phi[4,3]  R2128     -2.8205161914229393e-02
    phi[4,3]  R2129     -0.43563112616539
    phi[4,3]  R2130     5.8167535066604614e-01
    phi[4,3]  R2131     1.4057844877243042e+00
    phi[4,3]  R2132     9.6818111836910248e-02
    phi[4,3]  R2133     7.0932847261428833e-01
    phi[4,3]  R2134     5.7944321632385254e-01
    phi[4,3]  R2135     -1.5514412522315979e-01
    phi[4,3]  R2136     -1.0904399156570435e+00
    phi[4,3]  R2137     -5.9782242774963379e-01
    phi[4,3]  R2138     1.6199707984924316e-01
    phi[4,3]  R2139     -9.0435147285461426e-01
    phi[4,3]  R2140     -1.7013669013977051e-01
    phi[4,3]  R2141     -1.5011594295501709e+00
    phi[4,3]  R2142     -1.3497033119201660e+00
    phi[4,3]  R2143     -1.1549458503723145e+00
    phi[4,3]  R2144     5.7084769010543823e-01
    phi[4,3]  R2145     -1.7344825267791748e+00
    phi[4,3]  R2146     -1.0591309070587158e+00
    phi[4,3]  R2147     -1.8652031421661377e+00
    phi[4,3]  R2148     -0.281468003988266
    phi[4,3]  R2149     -1.0615569353103638e+00
    phi[4,3]  R2150     -2.05036997795105
    phi[4,3]  R2151     -5.2920693159103394e-01
    phi[4,3]  R2152     5.5447685718536377e-01
    phi[4,3]  R2153     -1.0072295367717743e-01
    phi[4,3]  R2154     -2.2217435836791992e+00
    phi[4,3]  R2155     2.5580215454101562e-01
    phi[4,3]  R2156     1.7334573268890381e+00
    phi[4,3]  R2157     2.2319107055664062e+00
    phi[4,3]  R2158     2.9019949436187744e+00
    phi[4,3]  R2159     -9.2549228668212891e-01
    phi[4,3]  R2160     -1.41675865650177
    phi[4,3]  R2161     6.8726092576980591e-01
    phi[4,3]  R2162     8.9127159118652344e-01
    phi[4,3]  R2163     -2.4688229560852051e+00
    phi[4,3]  R2164     -5.5618780851364136e-01
    phi[4,3]  R2165     -3.7060627341270447e-01
    phi[4,3]  R2166     -1.1356040239334106e+00
    phi[4,3]  R2167     -3.3154060840606689e+00
    phi[4,3]  R2168     -3.1919665336608887e+00
    phi[4,3]  R2169     3.3773060888051987e-02
    phi[4,3]  R2170     -1.9388939440250397e-01
    phi[4,3]  R2171     -1.4169896841049194e+00
    phi[4,3]  R2172     6.2699353694915771e-01
    phi[4,3]  R2173     -2.2138059139251709e+00
    phi[4,3]  R2174     -4.3821075558662415e-01
    phi[4,3]  R2175     -2.9005081653594971e+00
    phi[4,3]  R2176     -3.4855628013610840e+00
    phi[4,3]  R2177     -3.3849532604217529e+00
    phi[4,3]  R2178     -2.5126025676727295e+00
    phi[4,3]  R2179     -1.8423423767089844e+00
    phi[4,3]  R2180     -2.3803708553314209e+00
    phi[4,3]  R2181     -2.4286077022552490e+00
    phi[4,3]  R2182     -1.7690980434417725e+00
    phi[4,3]  R2183     -2.3383741378784180e+00
    phi[4,3]  R2184     -1.5844079256057739e+00
    phi[4,3]  R2185     -1.8416551351547241e+00
    phi[4,3]  R2186     -1.5972393751144409e+00
    phi[4,3]  R2187     -2.5029242038726807e+00
    phi[4,3]  R2188     -3.3589406013488770e+00
    phi[4,3]  R2189     -1.6291214227676392e+00
    phi[4,3]  R2190     -2.2276577949523926e+00
    phi[4,3]  R2191     -1.0473197698593140e+00
    phi[4,3]  R2192     -2.9403550624847412e+00
    phi[4,3]  R2193     -2.4909644126892090e+00
    phi[4,3]  R2194     -3.5564205646514893e+00
    phi[4,3]  R2195     -2.7329914569854736e+00
    phi[4,3]  R2196     -3.5934164524078369e+00
    phi[4,3]  R2197     -1.3461574912071228e-01
    phi[4,3]  R2198     -6.1715304851531982e-02
    phi[4,3]  R2199     -2.3127028942108154e+00
    phi[4,3]  R2200     -1.7392649650573730e+00
    phi[4,3]  R2201     -3.7199242115020752e+00
    phi[4,3]  R2202     -2.0330641269683838e+00
    phi[4,3]  R2203     -3.1576628684997559e+00
    phi[4,3]  R2204     -3.7154734134674072e+00
    phi[4,3]  R2205     -3.12541127204895
    phi[4,3]  R2206     -8.8167816400527954e-01
    phi[4,3]  R2207     -2.7073490619659424e+00
    phi[4,3]  R2208     -1.4858646392822266e+00
    phi[4,3]  R2209     -2.1805851459503174e+00
    phi[4,3]  R2210     -2.01226806640625
    phi[4,3]  R2211     -0.92231285572052
    phi[4,3]  R2212     -1.8562942743301392e+00
    phi[4,3]  R2213     -2.6092917919158936e+00
    phi[4,3]  R2214     -2.0257587432861328e+00
    phi[4,3]  R2215     -2.1004478931427
    phi[4,3]  R2216     -1.4287390708923340e+00
    phi[4,3]  R2217     7.8135251998901367e-01
    phi[4,3]  R2218     -3.1438763141632080e+00
    phi[4,3]  R2219     -2.4436395168304443e+00
    phi[4,3]  R2220     -3.4440124034881592e+00
    phi[4,3]  R2221     -2.5341069698333740e+00
    phi[4,3]  R2222     -3.6094620227813721e+00
    phi[4,3]  R2223     -3.1685857772827148e+00
    phi[4,3]  R2224     -3.4119021892547607e+00
    phi[4,3]  R2225     -2.6836543083190918e+00
    phi[4,3]  R2226     -3.5992629528045654e+00
    phi[4,3]  R2227     -1.4282816648483276e+00
    phi[4,3]  R2228     -2.9186706542968750e+00
    phi[4,3]  R2229     -2.9752295017242432e+00
    phi[4,3]  R2230     -3.0119705200195312e+00
    phi[4,3]  R2231     -2.72963547706604
    phi[4,3]  R2232     -1.2211716175079346e+00
    phi[4,3]  R2233     -2.7258551120758057e-01
    phi[4,3]  R2234     5.0541174411773682e-01
    phi[4,3]  R2235     4.7650763392448425e-01
    phi[6,3]  R27       -1
    phi[6,3]  R29       1.9199915296395873e+00
    phi[6,3]  R30       0.904736486145258
    phi[6,3]  R31       2.5115367541391920e+00
    phi[6,3]  R32       -1.3686806963533209e+00
    phi[6,3]  R33       1.1017081568291229e+00
    phi[6,3]  R34       6.2561744647177431e-01
    phi[6,3]  R35       -1.4726251316690804e+00
    phi[6,3]  R54       1
    phi[6,3]  R2236     -5.0199914342721552e+00
    phi[6,3]  R2237     -1.1800083749929811e+00
    phi[6,3]  R2238     -3.1447364956820012e+00
    phi[6,3]  R2239     -1.3352635233914851e+00
    phi[6,3]  R2240     -5.61153665877176
    phi[6,3]  R2241     -5.8846315049337639e-01
    phi[6,3]  R2242     -1.2013192368894769e+00
    phi[6,3]  R2243     -3.9386806295961190e+00
    phi[6,3]  R2244     -4.2017080614616908e+00
    phi[6,3]  R2245     -1.9982917478034454e+00
    phi[6,3]  R2246     -2.7156173606410858e+00
    phi[6,3]  R2247     -1.4643824676975372e+00
    phi[6,3]  R2248     -1.6273747729634880e+00
    phi[6,3]  R2249     -4.5726250363016483e+00
    phi[6,3]  R2250     -1.1925193278230339e-01
    phi[6,3]  R2251     -1.4950258012997075e-01
    phi[6,3]  R2252     -1.6421162522075949e-01
    phi[6,3]  R2253     -2.8920159106397758e-01
    phi[6,3]  R2254     -5.2726347759280245e-01
    phi[6,3]  R2255     -5.3113498057382058e-01
    phi[6,3]  R2256     -5.3156243862719621e-01
    phi[6,3]  R2257     -5.8243149116789583e-01
    phi[6,3]  R2258     -5.8473552105454862e-01
    phi[6,3]  R2259     -0.657220267718911
    phi[6,3]  R2260     -2.7696865905037460e+00
    phi[6,3]  R2261     -5.6372615701858786e-01
    phi[6,3]  R2262     -5.7778958669882741e-01
    phi[6,3]  R2263     -2.0233159195801869e+00
    phi[6,3]  R2264     -2.4553491340206808e+00
    phi[6,3]  R2265     -2.3164215028369464e+00
    phi[6,3]  R2266     -1.4862214459171783e+00
    phi[6,3]  R2267     -6.1646228860845964e-01
    phi[6,3]  R2268     -1.3412029416886426e+00
    phi[6,3]  R2269     -2.8715301663807362e+00
    phi[6,3]  R2270     -4.7724641686110258e-01
    phi[6,3]  R2271     -5.0715695914852077e-01
    phi[6,3]  R2272     -5.3092773397061332e-01
    phi[6,3]  R2273     -0.531565398817003
    phi[6,3]  R2274     -0.546931198786234
    phi[6,3]  R2275     -5.5384365120701062e-01
    phi[6,3]  R2276     -6.1562627143905213e-01
    phi[6,3]  R2277     -6.2815532972558041e-01
    phi[6,3]  R2278     -6.2919412998843760e-01
    phi[6,3]  R2279     -6.3031373653393086e-01
    phi[6,3]  R2280     -4.5812110305127973e-01
    phi[6,3]  R2281     -4.7233089314560406e-01
    phi[6,3]  R2282     -4.8283440791899945e-01
    phi[6,3]  R2283     -4.8326272817060056e-01
    phi[6,3]  R2284     -5.1460130877635368e-01
    phi[6,3]  R2285     -5.3842166216160747e-01
    phi[6,3]  R2286     -5.4512608577013433e-01
    phi[6,3]  R2287     -5.5847036033099018e-01
    phi[6,3]  R2288     -5.7226536313670584e-01
    phi[6,3]  R2289     -5.8222391498528747e-01
    phi[6,3]  R2290     -4.8923594413328075e-01
    phi[6,3]  R2291     -4.9777116086593565e-01
    phi[6,3]  R2292     -5.2082933089275230e-01
    phi[6,3]  R2293     -5.4962738048920823e-01
    phi[6,3]  R2294     -2.2166387442681486e+00
    phi[6,3]  R2295     -6.2056462489715969e-01
    phi[6,3]  R2296     -6.4068272755351718e-01
    phi[6,3]  R2297     -6.8362381057295485e-01
    phi[6,3]  R2298     -7.1980563229373162e-01
    phi[6,3]  R2299     -7.2563824088970241e-01
    phi[6,3]  R2300     -3.8674722250207144e-01
    phi[6,3]  R2301     -4.2760355853306908e-01
    phi[6,3]  R2302     -4.5649400979740973e-01
    phi[6,3]  R2303     -5.1695240936943776e-01
    phi[6,3]  R2304     -5.5503009587128971e-01
    phi[6,3]  R2305     -5.6109124261580667e-01
    phi[6,3]  R2306     -0.58832207070202
    phi[6,3]  R2307     -7.1431284827541863e-01
    phi[6,3]  R2308     -7.4115053479469717e-01
    phi[6,3]  R2309     -0.751692512873551
    phi[6,3]  R2310     -3.5024066346758520e-01
    phi[6,3]  R2311     -3.5174574509483669e-01
    phi[6,3]  R2312     -4.6984031472273324e-01
    phi[6,3]  R2313     -5.2235351080617787e-01
    phi[6,3]  R2314     -6.1744500195110152e-01
    phi[6,3]  R2315     -6.7833095029812784e-01
    phi[6,3]  R2316     -7.7806223869833468e-01
    phi[6,3]  R2317     -7.8090322944723534e-01
    phi[6,3]  R2318     -7.8906176597517774e-01
    phi[6,3]  R2319     -7.9748651328554332e-01
    phi[6,3]  R2320     -4.3777386215354008e-01
    phi[6,3]  R2321     -5.4665131718607363e-01
    phi[6,3]  R2322     -0.609408297034796
    phi[6,3]  R2323     -7.0269066142499481e-01
    phi[6,3]  R2324     -7.4372043953124489e-01
    phi[6,3]  R2325     -7.5488871943958280e-01
    phi[6,3]  R2326     -9.5351965888008872e-01
    phi[6,3]  R2327     -1.1794893308429808e+00
    phi[6,3]  R2328     -1.2723807244035545e+00
    phi[6,3]  R2329     -1.2879172321609067e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2330     -3.0999999046325684e+00
    phi[4,5]  R2331     -3.0999999046325684e+00
    phi[4,5]  R2332     -2.2400000095367432e+00
    phi[4,5]  R2333     -2.2400000095367432e+00
    phi[4,5]  R2334     -3.0999999046325684e+00
    phi[4,5]  R2335     -3.0999999046325684e+00
    phi[4,5]  R2336     -2.5699999332427979e+00
    phi[4,5]  R2337     -2.5699999332427979e+00
    phi[4,5]  R2338     -3.0999999046325684e+00
    phi[4,5]  R2339     -3.0999999046325684e+00
    phi[4,5]  R2340     -2.0899999141693115e+00
    phi[4,5]  R2341     -2.0899999141693115e+00
    phi[4,5]  R2342     -3.0999999046325684e+00
    phi[4,5]  R2343     -3.0999999046325684e+00
    phi[4,5]  R2344     8.1655305624008179e-01
    phi[4,5]  R2345     1.1620333194732666e+00
    phi[4,5]  R2346     -2.8205161914229393e-02
    phi[4,5]  R2347     -0.43563112616539
    phi[4,5]  R2348     5.8167535066604614e-01
    phi[4,5]  R2349     1.4057844877243042e+00
    phi[4,5]  R2350     9.6818111836910248e-02
    phi[4,5]  R2351     7.0932847261428833e-01
    phi[4,5]  R2352     5.7944321632385254e-01
    phi[4,5]  R2353     -1.5514412522315979e-01
    phi[4,5]  R2354     -1.0904399156570435e+00
    phi[4,5]  R2355     -5.9782242774963379e-01
    phi[4,5]  R2356     1.6199707984924316e-01
    phi[4,5]  R2357     -9.0435147285461426e-01
    phi[4,5]  R2358     -1.7013669013977051e-01
    phi[4,5]  R2359     -1.5011594295501709e+00
    phi[4,5]  R2360     -1.3497033119201660e+00
    phi[4,5]  R2361     -1.1549458503723145e+00
    phi[4,5]  R2362     5.7084769010543823e-01
    phi[4,5]  R2363     -1.7344825267791748e+00
    phi[4,5]  R2364     -1.0591309070587158e+00
    phi[4,5]  R2365     -1.8652031421661377e+00
    phi[4,5]  R2366     -0.281468003988266
    phi[4,5]  R2367     -1.0615569353103638e+00
    phi[4,5]  R2368     -2.05036997795105
    phi[4,5]  R2369     -5.2920693159103394e-01
    phi[4,5]  R2370     5.5447685718536377e-01
    phi[4,5]  R2371     -1.0072295367717743e-01
    phi[4,5]  R2372     -2.2217435836791992e+00
    phi[4,5]  R2373     2.5580215454101562e-01
    phi[4,5]  R2374     -2.8846397995948792e-01
    phi[4,5]  R2375     1.4615159034729004e+00
    phi[4,5]  R2376     0.983528196811676
    phi[4,5]  R2377     -2.3301025852560997e-02
    phi[4,5]  R2378     2.6662519574165344e-01
    phi[4,5]  R2379     3.6829882860183716e-01
    phi[4,5]  R2380     4.6905797719955444e-01
    phi[4,5]  R2381     4.5205667614936829e-01
    phi[4,5]  R2382     9.5256060361862183e-01
    phi[4,5]  R2383     -6.6834056377410889e-01
    phi[4,5]  R2384     -1.6881691217422485e+00
    phi[4,5]  R2385     -1.0094193220138550e+00
    phi[4,5]  R2386     -5.7700490951538086e-01
    phi[4,5]  R2387     -6.4045554399490356e-01
    phi[4,5]  R2388     -1.3926999568939209e+00
    phi[4,5]  R2389     -1.9576880931854248e+00
    phi[4,5]  R2390     -1.6650320291519165e+00
    phi[4,5]  R2391     -0.529798150062561
    phi[4,5]  R2392     -2.4332444369792938e-01
    phi[4,5]  R2393     -2.4138660430908203e+00
    phi[4,5]  R2394     -9.0545341372489929e-02
    phi[4,5]  R2395     4.5779541134834290e-01
    phi[4,5]  R2396     -1.4954192936420441e-01
    phi[4,5]  R2397     9.2757618427276611e-01
    phi[4,5]  R2398     -4.4576722383499146e-01
    phi[4,5]  R2399     -3.1812247633934021e-01
    phi[4,5]  R2400     -1.0632225275039673e+00
    phi[4,5]  R2401     -1.6305726766586304e+00
    phi[4,5]  R2402     -5.6299334764480591e-01
    phi[4,5]  R2403     -3.3905154466629028e-01
    phi[4,5]  R2404     -9.9244117736816406e-01
    phi[4,5]  R2405     -1.8954734802246094e+00
    phi[4,5]  R2406     -6.2935304641723633e-01
    phi[4,5]  R2407     -1.5196196734905243e-01
    phi[4,5]  R2408     -5.2080713212490082e-02
    phi[4,5]  R2409     -1.5437867641448975e+00
    phi[4,5]  R2410     -2.24242901802063
    phi[4,5]  R2411     3.3327788114547729e-01
    phi[4,5]  R2412     7.9023164510726929e-01
    phi[4,5]  R2413     -4.4204935431480408e-01
    phi[4,5]  R2414     6.2672895193099976e-01
    phi[4,5]  R2415     -4.8952391743659973e-01
    phi[4,5]  R2416     2.6942148804664612e-01
    phi[4,5]  R2417     1.2509486675262451e+00
    phi[4,5]  R2418     -9.2550534009933472e-01
    phi[4,5]  R2419     7.0809596776962280e-01
    phi[4,5]  R2420     -5.6621938943862915e-01
    phi[4,5]  R2421     9.6870058774948120e-01
    phi[4,5]  R2422     3.5651507973670959e-01
    phi[4,5]  R2423     -2.4892117977142334e+00
    phi[4,5]  R2424     -7.9263502359390259e-01
    phi[4,5]  R2425     0.0931747555732727
    phi[4,5]  R2426     -1.3504660129547119e+00
    phi[4,5]  R2427     -3.4228610992431641e-01
    phi[4,5]  R2428     -9.6234247088432312e-02
    phi[4,5]  R2429     -1.0859930515289307e+00
    phi[4,5]  R2430     -1.6723790168762207e+00
    phi[4,5]  R2431     0.270022451877594
    phi[4,5]  R2432     -6.9997894763946533e-01
    phi[4,5]  R2433     -1.2201733589172363e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2434     -3.0999999046325684e+00
    phi[5,4]  R2435     -3.0999999046325684e+00
    phi[5,4]  R2436     -2.2400000095367432e+00
    phi[5,4]  R2437     -2.2400000095367432e+00
    phi[5,4]  R2438     -3.0999999046325684e+00
    phi[5,4]  R2439     -3.0999999046325684e+00
    phi[5,4]  R2440     -2.5699999332427979e+00
    phi[5,4]  R2441     -2.5699999332427979e+00
    phi[5,4]  R2442     -3.0999999046325684e+00
    phi[5,4]  R2443     -3.0999999046325684e+00
    phi[5,4]  R2444     -2.0899999141693115e+00
    phi[5,4]  R2445     -2.0899999141693115e+00
    phi[5,4]  R2446     -3.0999999046325684e+00
    phi[5,4]  R2447     -3.0999999046325684e+00
    phi[5,4]  R2448     -2.8846397995948792e-01
    phi[5,4]  R2449     1.4615159034729004e+00
    phi[5,4]  R2450     0.983528196811676
    phi[5,4]  R2451     -2.3301025852560997e-02
    phi[5,4]  R2452     2.6662519574165344e-01
    phi[5,4]  R2453     3.6829882860183716e-01
    phi[5,4]  R2454     4.6905797719955444e-01
    phi[5,4]  R2455     4.5205667614936829e-01
    phi[5,4]  R2456     9.5256060361862183e-01
    phi[5,4]  R2457     -6.6834056377410889e-01
    phi[5,4]  R2458     -1.6881691217422485e+00
    phi[5,4]  R2459     -1.0094193220138550e+00
    phi[5,4]  R2460     -5.7700490951538086e-01
    phi[5,4]  R2461     -6.4045554399490356e-01
    phi[5,4]  R2462     -1.3926999568939209e+00
    phi[5,4]  R2463     -1.9576880931854248e+00
    phi[5,4]  R2464     -1.6650320291519165e+00
    phi[5,4]  R2465     -0.529798150062561
    phi[5,4]  R2466     -2.4332444369792938e-01
    phi[5,4]  R2467     -2.4138660430908203e+00
    phi[5,4]  R2468     -9.0545341372489929e-02
    phi[5,4]  R2469     4.5779541134834290e-01
    phi[5,4]  R2470     -1.4954192936420441e-01
    phi[5,4]  R2471     9.2757618427276611e-01
    phi[5,4]  R2472     -4.4576722383499146e-01
    phi[5,4]  R2473     -3.1812247633934021e-01
    phi[5,4]  R2474     -1.0632225275039673e+00
    phi[5,4]  R2475     -1.6305726766586304e+00
    phi[5,4]  R2476     -5.6299334764480591e-01
    phi[5,4]  R2477     -3.3905154466629028e-01
    phi[5,4]  R2478     -9.9244117736816406e-01
    phi[5,4]  R2479     -1.8954734802246094e+00
    phi[5,4]  R2480     -6.2935304641723633e-01
    phi[5,4]  R2481     -1.5196196734905243e-01
    phi[5,4]  R2482     -5.2080713212490082e-02
    phi[5,4]  R2483     -1.5437867641448975e+00
    phi[5,4]  R2484     -2.24242901802063
    phi[5,4]  R2485     3.3327788114547729e-01
    phi[5,4]  R2486     7.9023164510726929e-01
    phi[5,4]  R2487     -4.4204935431480408e-01
    phi[5,4]  R2488     6.2672895193099976e-01
    phi[5,4]  R2489     -4.8952391743659973e-01
    phi[5,4]  R2490     2.6942148804664612e-01
    phi[5,4]  R2491     1.2509486675262451e+00
    phi[5,4]  R2492     -9.2550534009933472e-01
    phi[5,4]  R2493     7.0809596776962280e-01
    phi[5,4]  R2494     -5.6621938943862915e-01
    phi[5,4]  R2495     9.6870058774948120e-01
    phi[5,4]  R2496     3.5651507973670959e-01
    phi[5,4]  R2497     -2.4892117977142334e+00
    phi[5,4]  R2498     -7.9263502359390259e-01
    phi[5,4]  R2499     0.0931747555732727
    phi[5,4]  R2500     -1.3504660129547119e+00
    phi[5,4]  R2501     -3.4228610992431641e-01
    phi[5,4]  R2502     -9.6234247088432312e-02
    phi[5,4]  R2503     -1.0859930515289307e+00
    phi[5,4]  R2504     -1.6723790168762207e+00
    phi[5,4]  R2505     0.270022451877594
    phi[5,4]  R2506     -6.9997894763946533e-01
    phi[5,4]  R2507     -1.2201733589172363e+00
    phi[5,4]  R2508     8.1655305624008179e-01
    phi[5,4]  R2509     1.1620333194732666e+00
    phi[5,4]  R2510     -2.8205161914229393e-02
    phi[5,4]  R2511     -0.43563112616539
    phi[5,4]  R2512     5.8167535066604614e-01
    phi[5,4]  R2513     1.4057844877243042e+00
    phi[5,4]  R2514     9.6818111836910248e-02
    phi[5,4]  R2515     7.0932847261428833e-01
    phi[5,4]  R2516     5.7944321632385254e-01
    phi[5,4]  R2517     -1.5514412522315979e-01
    phi[5,4]  R2518     -1.0904399156570435e+00
    phi[5,4]  R2519     -5.9782242774963379e-01
    phi[5,4]  R2520     1.6199707984924316e-01
    phi[5,4]  R2521     -9.0435147285461426e-01
    phi[5,4]  R2522     -1.7013669013977051e-01
    phi[5,4]  R2523     -1.5011594295501709e+00
    phi[5,4]  R2524     -1.3497033119201660e+00
    phi[5,4]  R2525     -1.1549458503723145e+00
    phi[5,4]  R2526     5.7084769010543823e-01
    phi[5,4]  R2527     -1.7344825267791748e+00
    phi[5,4]  R2528     -1.0591309070587158e+00
    phi[5,4]  R2529     -1.8652031421661377e+00
    phi[5,4]  R2530     -0.281468003988266
    phi[5,4]  R2531     -1.0615569353103638e+00
    phi[5,4]  R2532     -2.05036997795105
    phi[5,4]  R2533     -5.2920693159103394e-01
    phi[5,4]  R2534     5.5447685718536377e-01
    phi[5,4]  R2535     -1.0072295367717743e-01
    phi[5,4]  R2536     -2.2217435836791992e+00
    phi[5,4]  R2537     2.5580215454101562e-01
    phi[5,7]  R45       1
    phi[5,7]  R46       1
    phi[5,7]  R47       2.9615627696593729e+00
    phi[5,7]  R48       6.4014715830305491e-02
    phi[5,7]  R49       -2.9099648328199064e+00
    phi[5,7]  R50       -5.9939080591060456e-02
    phi[5,7]  R51       1.3150820782356845e+00
    phi[5,7]  R52       -1.8623749448731539e+00
    phi[5,7]  R53       -1.6357310874122519e+00
    phi[5,7]  R55       -1
    phi[5,7]  R2538     -1.3843713497319543e-01
    phi[5,7]  R2539     -6.0615626742919417e+00
    phi[5,7]  R2540     -2.1759852937064377e+00
    phi[5,7]  R2541     -2.3040147253670487e+00
    phi[5,7]  R2542     -6.0099647374524743e+00
    phi[5,7]  R2543     -0.190035071812662
    phi[5,7]  R2544     -2.6299390138338583e+00
    phi[5,7]  R2545     -2.5100608526517374e+00
    phi[5,7]  R2546     -1.7849178263968839e+00
    phi[5,7]  R2547     -4.4150819828682533e+00
    phi[5,7]  R2548     -3.9523748590424654e+00
    phi[5,7]  R2549     -2.2762496929615761e-01
    phi[5,7]  R2550     -4.73573099204482
    phi[5,7]  R2551     -1.4642688172203164e+00
    phi[5,7]  R2552     -4.6929858817429149e-01
    phi[5,7]  R2553     -0.506251498639481
    phi[5,7]  R2554     -2.0211996211472343e+00
    phi[5,7]  R2555     -5.1815861810290820e-01
    phi[5,7]  R2556     -5.5055677841397077e-01
    phi[5,7]  R2557     -1.4649162082933855e+00
    phi[5,7]  R2558     -2.2689776419426462e+00
    phi[5,7]  R2559     -6.1414289908917707e-01
    phi[5,7]  R2560     -2.4137065280765664e+00
    phi[5,7]  R2561     -6.5170300226785083e-01
    phi[5,7]  R2562     -1.2664937195783479e+00
    phi[5,7]  R2563     -8.2448715965116770e-01
    phi[5,7]  R2564     -5.4085462891446567e-01
    phi[5,7]  R2565     -5.5160392836951988e-01
    phi[5,7]  R2566     -5.6645610245290690e-01
    phi[5,7]  R2567     -5.7988573601161031e-01
    phi[5,7]  R2568     -5.8066895344288150e-01
    phi[5,7]  R2569     -5.8687771246660758e-01
    phi[5,7]  R2570     -6.3558755590718752e-01
    phi[5,7]  R2571     -6.4475879441487427e-01
    phi[5,7]  R2572     -3.9865036912003687e-01
    phi[5,7]  R2573     -1.5059647031936445e+00
    phi[5,7]  R2574     -1.1338325706740044e+00
    phi[5,7]  R2575     -0.556421433353165
    phi[5,7]  R2576     -5.6638665562225976e-01
    phi[5,7]  R2577     -0.566741313397146
    phi[5,7]  R2578     -5.9312109707713179e-01
    phi[5,7]  R2579     -6.2163867840928755e-01
    phi[5,7]  R2580     -0.629548955694457
    phi[5,7]  R2581     -6.3080323388335713e-01
    phi[5,7]  R2582     -1.7632462888180687e+00
    phi[5,7]  R2583     -4.8694266025073452e-01
    phi[5,7]  R2584     -1.3714395951163059e+00
    phi[5,7]  R2585     -5.3046553151923947e-01
    phi[5,7]  R2586     -5.4227024637988719e-01
    phi[5,7]  R2587     -5.6991469375256143e-01
    phi[5,7]  R2588     -1.1378764970119091e+00
    phi[5,7]  R2589     -1.7964110287437238e+00
    phi[5,7]  R2590     -6.3372494908984489e-01
    phi[5,7]  R2591     -1.1560480363863244e+00
    phi[5,7]  R2592     -5.2109952855143371e-01
    phi[5,7]  R2593     -5.3237137752199182e-01
    phi[5,7]  R2594     -5.6061199144753671e-01
    phi[5,7]  R2595     -1.7545499158223210e+00
    phi[5,7]  R2596     -1.3793002301132244e+00
    phi[5,7]  R2597     -7.5713363463473771e-01
    phi[5,7]  R2598     -7.8973628718578426e-01
    phi[5,7]  R2599     -8.2482025921214919e-01
    phi[5,7]  R2600     -8.4309786534229070e-01
    phi[5,7]  R2601     -8.6995119069095894e-01
    phi[5,7]  R2602     -4.2841518415287155e-01
    phi[5,7]  R2603     -5.3105831409198789e-01
    phi[5,7]  R2604     -5.4031480172066726e-01
    phi[5,7]  R2605     -8.4156379287573846e-01
    phi[5,7]  R2606     -1.9546118042220977e+00
    phi[5,7]  R2607     -6.0846314723925976e-01
    phi[5,7]  R2608     -1.5071389231006096e+00
    phi[5,7]  R2609     -2.7999794071867563e+00
    phi[5,7]  R2610     -2.3287479647330924e+00
    phi[5,7]  R2611     -7.6390695705929490e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R56       -1
    z[0,1,0]  R57       1
    z[0,1,0]  R70       -4.5205074548721313e-01
    z[0,1,0]  R71       -5.8820670843124390e-01
    z[0,1,0]  R72       -4.5692503452301025e-01
    z[0,1,0]  R73       -0.575303316116333
    z[0,1,0]  R74       -6.6564100980758667e-01
    z[0,1,0]  R75       -4.7894108295440674e-01
    z[0,1,0]  R76       -3.1326249241828918e-01
    z[0,1,0]  R77       -7.2099554538726807e-01
    z[0,1,0]  R78       -4.6623095870018005e-01
    z[0,1,0]  R79       -6.5349000692367554e-01
    z[0,1,0]  R80       -0.733890950679779
    z[0,1,0]  R81       -0.615653395652771
    z[0,1,0]  R82       -6.5118718147277832e-01
    z[0,1,0]  R83       -4.8438054323196411e-01
    z[0,1,0]  R84       -5.7601153850555420e-01
    z[0,1,0]  R85       -4.7619366645812988e-01
    z[0,1,0]  R86       2.0817232131958008e-01
    z[0,1,0]  R87       2.8128352761268616e-01
    z[0,1,0]  R88       -4.5916289091110229e-03
    z[0,1,0]  R89       2.1172988414764404e-01
    z[0,1,0]  R90       -2.9712429642677307e-01
    z[0,1,0]  R91       7.1658569574356079e-01
    z[0,1,0]  R92       7.2071969509124756e-01
    z[0,1,0]  R93       7.4970632791519165e-01
    z[0,1,0]  R94       7.8108614683151245e-01
    z[0,1,0]  R95       7.1166193485260010e-01
    z[0,1,0]  R96       6.8975126743316650e-01
    z[0,1,0]  R97       6.5204966068267822e-01
    z[0,1,0]  R98       6.1901992559432983e-01
    z[0,1,0]  R99       6.2065553665161133e-01
    z[0,1,0]  R100      -4.4455844163894653e-01
    z[0,1,0]  R101      2.2149392962455750e-01
    z[0,1,0]  R102      3.6230584979057312e-01
    z[0,1,0]  R103      4.1651627421379089e-01
    z[0,1,0]  R104      7.0132118463516235e-01
    z[0,1,0]  R105      2.6808470487594604e-01
    z[0,1,0]  R106      3.4836953878402710e-01
    z[0,1,0]  R107      6.3359832763671875e-01
    z[0,1,0]  R108      3.8972038030624390e-01
    z[0,1,0]  R109      1.3161903619766235e-01
    z[0,1,0]  R110      4.5193210244178772e-01
    z[0,1,0]  R111      -3.4268078207969666e-01
    z[0,1,0]  R112      -9.8319277167320251e-02
    z[0,1,0]  R113      6.4859133958816528e-01
    z[0,1,0]  R114      8.6352986097335815e-01
    z[0,1,0]  R115      7.9342055320739746e-01
    z[0,1,0]  R116      9.4148766994476318e-01
    z[0,1,0]  R117      7.8157550096511841e-01
    z[0,1,0]  R118      6.8550151586532593e-01
    z[0,1,0]  R119      5.0662785768508911e-01
    z[0,1,0]  R120      2.2607669234275818e-01
    z[0,1,0]  R121      9.1934822499752045e-02
    z[0,1,0]  R122      1.1354370415210724e-01
    z[0,1,0]  R123      6.7248874902725220e-01
    z[0,1,0]  R124      7.4956321716308594e-01
    z[0,1,0]  R125      8.3836203813552856e-01
    z[0,1,0]  R126      7.7884489297866821e-01
    z[0,1,0]  R127      8.1881231069564819e-01
    z[0,1,0]  R128      -3.3339992165565491e-01
    z[0,1,0]  R129      4.8978051543235779e-01
    z[0,1,0]  R130      -3.8395929336547852e-01
    z[0,1,0]  R131      4.7120350599288940e-01
    z[0,1,0]  R132      0.426010400056839
    z[0,1,0]  R133      7.9224973917007446e-01
    z[0,1,0]  R134      7.0684427022933960e-01
    z[0,1,0]  R135      0.902255117893219
    z[0,1,0]  R136      7.2838443517684937e-01
    z[0,1,0]  R137      7.7335160970687866e-01
    z[0,1,0]  R138      -6.5417215228080750e-02
    z[0,1,0]  R139      5.6293249130249023e-01
    z[0,1,0]  R140      -4.9690928310155869e-02
    z[0,1,0]  R141      -5.8148401975631714e-01
    z[0,1,0]  R142      -1.1177226155996323e-01
    z[0,1,0]  R143      -6.1769241094589233e-01
    z[0,1,0]  R144      1.4331138134002686e-01
    z[0,1,0]  R145      6.5243035554885864e-01
    z[0,1,0]  R146      6.3770312070846558e-01
    z[0,1,0]  R147      2.9630595818161964e-02
    z[0,1,0]  R148      4.4086730480194092e-01
    z[0,1,0]  R149      2.9334232211112976e-01
    z[0,1,0]  R150      1.6809152066707611e-01
    z[0,1,0]  R151      -0.023863660171628
    z[0,1,0]  R152      -1.1202633380889893e-01
    z[0,1,0]  R153      1.9880126416683197e-01
    z[0,1,0]  R154      -1.3381104171276093e-01
    z[0,1,0]  R155      -7.3125801980495453e-02
    z[0,1,0]  R156      -1.5840733423829079e-02
    z[0,1,0]  R157      1.9686248898506165e-01
    z[0,1,0]  R158      2.2745615243911743e-01
    z[0,1,0]  R159      -6.1484247446060181e-01
    z[0,1,0]  R160      1.7498087882995605e-01
    z[0,1,0]  R161      8.2255318760871887e-02
    z[0,1,0]  R162      -2.1478015184402466e-01
    z[0,1,0]  R163      -1.9356778264045715e-01
    z[0,1,0]  R164      3.4069761633872986e-02
    z[0,1,0]  R165      1.0933275334537029e-02
    z[0,1,0]  R166      3.0830252170562744e-01
    z[0,1,0]  R167      4.4244241714477539e-01
    z[0,1,0]  R168      5.9359449893236160e-02
    z[0,1,0]  R169      6.1092221736907959e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R58       -1
    z[0,1,1]  R59       1
    z[0,1,1]  R70       -3.7097299098968506e-01
    z[0,1,1]  R71       -3.6693203449249268e-01
    z[0,1,1]  R72       -4.5138341188430786e-01
    z[0,1,1]  R73       -2.2190444171428680e-01
    z[0,1,1]  R74       -3.6051931977272034e-01
    z[0,1,1]  R75       -3.3479732275009155e-01
    z[0,1,1]  R76       -4.8547694087028503e-01
    z[0,1,1]  R77       -1.9949507713317871e-01
    z[0,1,1]  R78       -5.9826439619064331e-01
    z[0,1,1]  R79       -0.577897846698761
    z[0,1,1]  R80       5.0273150205612183e-01
    z[0,1,1]  R81       2.0162308216094971e-01
    z[0,1,1]  R82       2.5994935631752014e-01
    z[0,1,1]  R83       2.3967595398426056e-01
    z[0,1,1]  R84       1.2009112536907196e-01
    z[0,1,1]  R85       0.344561904668808
    z[0,1,1]  R86       -4.0684238076210022e-01
    z[0,1,1]  R87       5.9415864944458008e-01
    z[0,1,1]  R88       -0.535753607749939
    z[0,1,1]  R89       8.9932310581207275e-01
    z[0,1,1]  R90       -0.492990642786026
    z[0,1,1]  R91       1.3425578176975250e-01
    z[0,1,1]  R92       1.9090722501277924e-01
    z[0,1,1]  R93       2.0522850099951029e-03
    z[0,1,1]  R94       -6.2149807810783386e-02
    z[0,1,1]  R95       -2.7825522422790527e-01
    z[0,1,1]  R96       4.3220886588096619e-01
    z[0,1,1]  R97       -6.9961018860340118e-02
    z[0,1,1]  R98       6.4299218356609344e-02
    z[0,1,1]  R99       -1.0775623470544815e-01
    z[0,1,1]  R100      -5.7922917604446411e-01
    z[0,1,1]  R101      6.5210044384002686e-01
    z[0,1,1]  R102      6.1549621820449829e-01
    z[0,1,1]  R103      4.0255889296531677e-01
    z[0,1,1]  R104      4.0936276316642761e-01
    z[0,1,1]  R105      5.6163680553436279e-01
    z[0,1,1]  R106      7.4027538299560547e-01
    z[0,1,1]  R107      4.1407313942909241e-01
    z[0,1,1]  R108      6.1991912126541138e-01
    z[0,1,1]  R109      5.9269815683364868e-01
    z[0,1,1]  R110      6.5104746818542480e-01
    z[0,1,1]  R111      4.2700815945863724e-02
    z[0,1,1]  R112      3.9969280362129211e-01
    z[0,1,1]  R113      1.8041059374809265e-02
    z[0,1,1]  R114      -7.7699266374111176e-02
    z[0,1,1]  R115      -1.3859303295612335e-01
    z[0,1,1]  R116      -8.7431944906711578e-02
    z[0,1,1]  R117      -3.8322117924690247e-01
    z[0,1,1]  R118      -3.9155939221382141e-01
    z[0,1,1]  R119      -4.6986032975837588e-04
    z[0,1,1]  R120      6.9686084985733032e-01
    z[0,1,1]  R121      2.4475000798702240e-01
    z[0,1,1]  R122      2.9900339245796204e-01
    z[0,1,1]  R123      -9.8890945315361023e-02
    z[0,1,1]  R124      -4.0146824903786182e-03
    z[0,1,1]  R125      -1.4451023936271667e-01
    z[0,1,1]  R126      -1.0399951785802841e-01
    z[0,1,1]  R127      3.2765230536460876e-01
    z[0,1,1]  R128      3.7645879387855530e-01
    z[0,1,1]  R129      -4.8832911252975464e-01
    z[0,1,1]  R130      -5.9402313083410263e-02
    z[0,1,1]  R131      0.790256679058075
    z[0,1,1]  R132      2.7368307113647461e-01
    z[0,1,1]  R133      -3.3937498927116394e-02
    z[0,1,1]  R134      7.8817538917064667e-02
    z[0,1,1]  R135      -5.6102149188518524e-02
    z[0,1,1]  R136      2.4786278605461121e-01
    z[0,1,1]  R137      3.4703928232192993e-01
    z[0,1,1]  R138      -3.4403938055038452e-01
    z[0,1,1]  R139      -5.7602214813232422e-01
    z[0,1,1]  R140      -7.3943519592285156e-01
    z[0,1,1]  R141      -5.7814192771911621e-01
    z[0,1,1]  R142      -4.6810141205787659e-01
    z[0,1,1]  R143      -2.7959123253822327e-01
    z[0,1,1]  R144      -3.9454612135887146e-01
    z[0,1,1]  R145      5.4222857952117920e-01
    z[0,1,1]  R146      5.4430902004241943e-01
    z[0,1,1]  R147      8.7147343158721924e-01
    z[0,1,1]  R148      6.8491917848587036e-01
    z[0,1,1]  R149      5.4950064420700073e-01
    z[0,1,1]  R150      0.711979329586029
    z[0,1,1]  R151      7.1186983585357666e-01
    z[0,1,1]  R152      6.6931933164596558e-01
    z[0,1,1]  R153      7.8237426280975342e-01
    z[0,1,1]  R154      5.9923851490020752e-01
    z[0,1,1]  R155      5.4216337203979492e-01
    z[0,1,1]  R156      4.3436288833618164e-01
    z[0,1,1]  R157      3.3971610665321350e-01
    z[0,1,1]  R158      -8.9301742613315582e-02
    z[0,1,1]  R159      2.7429884672164917e-01
    z[0,1,1]  R160      8.6199837923049927e-01
    z[0,1,1]  R161      7.5430279970169067e-01
    z[0,1,1]  R162      7.6275277137756348e-01
    z[0,1,1]  R163      7.1205347776412964e-01
    z[0,1,1]  R164      7.1167606115341187e-01
    z[0,1,1]  R165      6.6217201948165894e-01
    z[0,1,1]  R166      1.9006147980690002e-01
    z[0,1,1]  R167      6.9651387631893158e-02
    z[0,1,1]  R168      1.0630601644515991e-01
    z[0,1,1]  R169      -3.3505043387413025e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R60       -1
    z[0,1,2]  R61       1
    z[0,1,2]  R70       -4.9483129382133484e-01
    z[0,1,2]  R71       -9.7330369055271149e-02
    z[0,1,2]  R72       -3.4899190068244934e-01
    z[0,1,2]  R73       -6.0960876941680908e-01
    z[0,1,2]  R74       -4.8680838942527771e-01
    z[0,1,2]  R75       -0.672831118106842
    z[0,1,2]  R76       -3.4733718633651733e-01
    z[0,1,2]  R77       -3.2131305336952209e-01
    z[0,1,2]  R78       -5.7243376970291138e-01
    z[0,1,2]  R79       -2.1037876605987549e-01
    z[0,1,2]  R80       6.6559992730617523e-02
    z[0,1,2]  R81       1.8649429082870483e-01
    z[0,1,2]  R82       6.2250006943941116e-02
    z[0,1,2]  R83       -4.5600169897079468e-01
    z[0,1,2]  R84       1.5084241330623627e-01
    z[0,1,2]  R85       -0.618038535118103
    z[0,1,2]  R86       -0.544635534286499
    z[0,1,2]  R87       2.3024339973926544e-01
    z[0,1,2]  R88       -2.0169420540332794e-01
    z[0,1,2]  R89       -2.8154075145721436e-02
    z[0,1,2]  R90       1.1645640432834625e-01
    z[0,1,2]  R91       2.3529249429702759e-01
    z[0,1,2]  R92       2.2056996822357178e-01
    z[0,1,2]  R93       2.7665516734123230e-01
    z[0,1,2]  R94       5.1817059516906738e-01
    z[0,1,2]  R95       2.8015345335006714e-01
    z[0,1,2]  R96       2.7484706044197083e-01
    z[0,1,2]  R97       3.5513857007026672e-01
    z[0,1,2]  R98       2.9373681545257568e-01
    z[0,1,2]  R99       2.0256657898426056e-01
    z[0,1,2]  R100      1.4184066094458103e-02
    z[0,1,2]  R101      2.0424166321754456e-01
    z[0,1,2]  R102      5.2230864763259888e-01
    z[0,1,2]  R103      6.2774562835693359e-01
    z[0,1,2]  R104      3.2502561807632446e-01
    z[0,1,2]  R105      6.0212141275405884e-01
    z[0,1,2]  R106      0.392896443605423
    z[0,1,2]  R107      4.9758854508399963e-01
    z[0,1,2]  R108      6.3677805662155151e-01
    z[0,1,2]  R109      4.9808567762374878e-01
    z[0,1,2]  R110      5.3835314512252808e-01
    z[0,1,2]  R111      -2.0831923186779022e-01
    z[0,1,2]  R112      7.1620625257492065e-01
    z[0,1,2]  R113      3.1755414605140686e-01
    z[0,1,2]  R114      2.6180100440979004e-01
    z[0,1,2]  R115      4.1566711664199829e-01
    z[0,1,2]  R116      8.9760743081569672e-02
    z[0,1,2]  R117      4.5086222887039185e-01
    z[0,1,2]  R118      5.5262410640716553e-01
    z[0,1,2]  R119      6.1279457807540894e-01
    z[0,1,2]  R120      2.8982168436050415e-01
    z[0,1,2]  R121      7.5420439243316650e-01
    z[0,1,2]  R122      0.323527067899704
    z[0,1,2]  R123      0.619373619556427
    z[0,1,2]  R124      3.5451135039329529e-01
    z[0,1,2]  R125      1.9256868958473206e-01
    z[0,1,2]  R126      5.0941830873489380e-01
    z[0,1,2]  R127      -1.9011670351028442e-01
    z[0,1,2]  R128      2.1972490847110748e-01
    z[0,1,2]  R129      3.6099809408187866e-01
    z[0,1,2]  R130      -0.243872731924057
    z[0,1,2]  R131      2.8777948021888733e-01
    z[0,1,2]  R132      6.9211721420288086e-01
    z[0,1,2]  R133      5.4562073945999146e-01
    z[0,1,2]  R134      5.4034155607223511e-01
    z[0,1,2]  R135      2.1261225640773773e-01
    z[0,1,2]  R136      1.9627201557159424e-01
    z[0,1,2]  R137      -2.2901043295860291e-01
    z[0,1,2]  R138      5.6032079458236694e-01
    z[0,1,2]  R139      4.3365949392318726e-01
    z[0,1,2]  R140      -1.9925607740879059e-01
    z[0,1,2]  R141      -3.2785028219223022e-01
    z[0,1,2]  R142      -7.2761642932891846e-01
    z[0,1,2]  R143      7.2494186460971832e-02
    z[0,1,2]  R144      9.0446047484874725e-02
    z[0,1,2]  R145      -3.4528259187936783e-02
    z[0,1,2]  R146      8.5024453699588776e-02
    z[0,1,2]  R147      2.3083847761154175e-01
    z[0,1,2]  R148      2.1506215631961823e-01
    z[0,1,2]  R149      -2.6834979653358459e-01
    z[0,1,2]  R150      -2.7630642056465149e-02
    z[0,1,2]  R151      -4.4226527214050293e-01
    z[0,1,2]  R152      1.0201875865459442e-01
    z[0,1,2]  R153      -0.326465904712677
    z[0,1,2]  R154      -6.1449509859085083e-01
    z[0,1,2]  R155      -3.5805395245552063e-01
    z[0,1,2]  R156      1.8681395053863525e-01
    z[0,1,2]  R157      -5.6713706254959106e-01
    z[0,1,2]  R158      7.0076537132263184e-01
    z[0,1,2]  R159      -8.1679157912731171e-02
    z[0,1,2]  R160      7.4630357325077057e-02
    z[0,1,2]  R161      -3.0827391147613525e-01
    z[0,1,2]  R162      -1.6502179205417633e-01
    z[0,1,2]  R163      -5.4879003763198853e-01
    z[0,1,2]  R164      -4.3301945924758911e-01
    z[0,1,2]  R165      -5.0865966081619263e-01
    z[0,1,2]  R166      6.4753150939941406e-01
    z[0,1,2]  R167      6.5141016244888306e-01
    z[0,1,2]  R168      9.0096151828765869e-01
    z[0,1,2]  R169      2.7205786108970642e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R62       -1
    z[0,1,3]  R63       1
    z[0,1,3]  R70       2.7465847134590149e-01
    z[0,1,3]  R71       2.1862241625785828e-01
    z[0,1,3]  R72       2.2339639067649841e-01
    z[0,1,3]  R73       2.8020879253745079e-02
    z[0,1,3]  R74       -4.3010301887989044e-02
    z[0,1,3]  R75       3.2868012785911560e-01
    z[0,1,3]  R76       7.9285115003585815e-02
    z[0,1,3]  R77       3.9583992958068848e-01
    z[0,1,3]  R78       -1.6228479146957397e-01
    z[0,1,3]  R79       -1.9534525275230408e-01
    z[0,1,3]  R80       -2.8189438581466675e-01
    z[0,1,3]  R81       -3.4203374385833740e-01
    z[0,1,3]  R82       -2.3261594772338867e-01
    z[0,1,3]  R83       -3.3128741383552551e-01
    z[0,1,3]  R84       -3.6564636230468750e-01
    z[0,1,3]  R85       -3.1601428985595703e-01
    z[0,1,3]  R86       -6.4556926488876343e-01
    z[0,1,3]  R87       -4.0185779333114624e-01
    z[0,1,3]  R88       -4.7184279561042786e-01
    z[0,1,3]  R89       -8.6596027016639709e-02
    z[0,1,3]  R90       -2.1008187532424927e-01
    z[0,1,3]  R91       0.591512143611908
    z[0,1,3]  R92       5.3625398874282837e-01
    z[0,1,3]  R93       3.1039351224899292e-01
    z[0,1,3]  R94       9.4767600297927856e-02
    z[0,1,3]  R95       3.9894381165504456e-01
    z[0,1,3]  R96       2.3887093365192413e-01
    z[0,1,3]  R97       3.5465556383132935e-01
    z[0,1,3]  R98       4.6932280063629150e-01
    z[0,1,3]  R99       4.8359695076942444e-01
    z[0,1,3]  R100      -2.9546749591827393e-01
    z[0,1,3]  R101      -9.2585608363151550e-02
    z[0,1,3]  R102      0.144478902220726
    z[0,1,3]  R103      4.9953363835811615e-02
    z[0,1,3]  R104      -4.1675353050231934e-01
    z[0,1,3]  R105      -1.9000534713268280e-01
    z[0,1,3]  R106      7.0265196263790131e-02
    z[0,1,3]  R107      -2.1355268359184265e-01
    z[0,1,3]  R108      1.0279149562120438e-01
    z[0,1,3]  R109      1.4658312499523163e-01
    z[0,1,3]  R110      -0.240363210439682
    z[0,1,3]  R111      4.0989495813846588e-02
    z[0,1,3]  R112      1.9411119818687439e-01
    z[0,1,3]  R113      4.3253910541534424e-01
    z[0,1,3]  R114      1.4697183668613434e-01
    z[0,1,3]  R115      -9.0161100029945374e-02
    z[0,1,3]  R116      1.9986793398857117e-01
    z[0,1,3]  R117      -2.5931049603968859e-03
    z[0,1,3]  R118      0.0225517675280571
    z[0,1,3]  R119      1.6422437503933907e-02
    z[0,1,3]  R120      2.7692386507987976e-01
    z[0,1,3]  R121      -1.9492456316947937e-01
    z[0,1,3]  R122      -6.0355597734451294e-01
    z[0,1,3]  R123      3.1957823038101196e-01
    z[0,1,3]  R124      4.3257674574851990e-01
    z[0,1,3]  R125      4.4370394945144653e-01
    z[0,1,3]  R126      -5.5770836770534515e-02
    z[0,1,3]  R127      0.400804340839386
    z[0,1,3]  R128      5.8853697776794434e-01
    z[0,1,3]  R129      -2.0160461962223053e-01
    z[0,1,3]  R130      -8.6898155510425568e-02
    z[0,1,3]  R131      1.8041260540485382e-02
    z[0,1,3]  R132      -6.3954539597034454e-02
    z[0,1,3]  R133      1.4463429339230061e-02
    z[0,1,3]  R134      1.4581283926963806e-01
    z[0,1,3]  R135      3.6226221919059753e-01
    z[0,1,3]  R136      3.2409176230430603e-01
    z[0,1,3]  R137      3.6512300372123718e-01
    z[0,1,3]  R138      0.624301016330719
    z[0,1,3]  R139      -1.1442262679338455e-01
    z[0,1,3]  R140      4.1571286320686340e-01
    z[0,1,3]  R141      5.2801431156694889e-03
    z[0,1,3]  R142      2.3760001361370087e-01
    z[0,1,3]  R143      4.4579803943634033e-01
    z[0,1,3]  R144      4.1010746359825134e-01
    z[0,1,3]  R145      0.0699441209435463
    z[0,1,3]  R146      -2.7111726999282837e-01
    z[0,1,3]  R147      3.5323426127433777e-03
    z[0,1,3]  R148      -1.5383604168891907e-01
    z[0,1,3]  R149      -4.1269126534461975e-01
    z[0,1,3]  R150      -7.1397058665752411e-02
    z[0,1,3]  R151      1.3254101388156414e-02
    z[0,1,3]  R152      -0.062924325466156
    z[0,1,3]  R153      2.9293122887611389e-01
    z[0,1,3]  R154      6.8340882658958435e-02
    z[0,1,3]  R155      -1.5282213687896729e-01
    z[0,1,3]  R156      -7.1344166994094849e-01
    z[0,1,3]  R157      -4.9946320056915283e-01
    z[0,1,3]  R158      -5.0770968198776245e-01
    z[0,1,3]  R159      -5.8048856258392334e-01
    z[0,1,3]  R160      -2.9847297072410583e-01
    z[0,1,3]  R161      5.1173716783523560e-01
    z[0,1,3]  R162      3.4743675589561462e-01
    z[0,1,3]  R163      -4.6729825437068939e-02
    z[0,1,3]  R164      -1.2129744887351990e-01
    z[0,1,3]  R165      1.2098416686058044e-01
    z[0,1,3]  R166      -6.5261560678482056e-01
    z[0,1,3]  R167      -3.6690777540206909e-01
    z[0,1,3]  R168      -1.4384835958480835e-01
    z[0,1,3]  R169      -3.5192090272903442e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R64       -1
    z[0,1,4]  R65       1
    z[0,1,4]  R70       -2.2320783138275146e-01
    z[0,1,4]  R71       -4.0431165695190430e-01
    z[0,1,4]  R72       -7.5694218277931213e-02
    z[0,1,4]  R73       -4.6823564171791077e-01
    z[0,1,4]  R74       -1.4151379466056824e-01
    z[0,1,4]  R75       -1.6214616596698761e-01
    z[0,1,4]  R76       -6.3354140520095825e-01
    z[0,1,4]  R77       -2.5628909468650818e-01
    z[0,1,4]  R78       -1.6630516946315765e-01
    z[0,1,4]  R79       -2.2820074856281281e-01
    z[0,1,4]  R80       8.4936410188674927e-02
    z[0,1,4]  R81       6.0803145170211792e-01
    z[0,1,4]  R82       0.535810649394989
    z[0,1,4]  R83       3.4923958778381348e-01
    z[0,1,4]  R84       -1.2607812881469727e-01
    z[0,1,4]  R85       3.3863863348960876e-01
    z[0,1,4]  R86       3.9063774049282074e-02
    z[0,1,4]  R87       -3.0383935570716858e-01
    z[0,1,4]  R88       -6.3019412755966187e-01
    z[0,1,4]  R89       0.182783842086792
    z[0,1,4]  R90       -4.4336962699890137e-01
    z[0,1,4]  R91       -1.5069375932216644e-01
    z[0,1,4]  R92       -1.6082622110843658e-01
    z[0,1,4]  R93       -4.6549633145332336e-01
    z[0,1,4]  R94       -5.2558548748493195e-02
    z[0,1,4]  R95       -1.7212267220020294e-01
    z[0,1,4]  R96       -3.5822349786758423e-01
    z[0,1,4]  R97       4.1479739546775818e-01
    z[0,1,4]  R98       2.3057612776756287e-01
    z[0,1,4]  R99       -7.6729096472263336e-02
    z[0,1,4]  R100      -2.5740219280123711e-02
    z[0,1,4]  R101      -0.147491917014122
    z[0,1,4]  R102      3.0154368281364441e-01
    z[0,1,4]  R103      3.6195525527000427e-01
    z[0,1,4]  R104      1.0208228230476379e-01
    z[0,1,4]  R105      -4.4310221076011658e-01
    z[0,1,4]  R106      -3.3230370283126831e-01
    z[0,1,4]  R107      1.6288186609745026e-01
    z[0,1,4]  R108      -1.5184590220451355e-01
    z[0,1,4]  R109      1.2072016298770905e-01
    z[0,1,4]  R110      1.2923154234886169e-01
    z[0,1,4]  R111      -0.817986011505127
    z[0,1,4]  R112      -3.2437807321548462e-01
    z[0,1,4]  R113      -3.3277797698974609e-01
    z[0,1,4]  R114      -3.0150877311825752e-02
    z[0,1,4]  R115      -3.8535857200622559e-01
    z[0,1,4]  R116      1.0299303382635117e-01
    z[0,1,4]  R117      -9.6264392137527466e-02
    z[0,1,4]  R118      -1.3803568668663502e-02
    z[0,1,4]  R119      -5.8436781167984009e-01
    z[0,1,4]  R120      -1.6579884290695190e-01
    z[0,1,4]  R121      -2.1202203631401062e-01
    z[0,1,4]  R122      -2.6820358633995056e-01
    z[0,1,4]  R123      -2.0164571702480316e-01
    z[0,1,4]  R124      1.5451878309249878e-01
    z[0,1,4]  R125      1.0063663125038147e-01
    z[0,1,4]  R126      3.4109887480735779e-01
    z[0,1,4]  R127      0.134738951921463
    z[0,1,4]  R128      4.4613420963287354e-02
    z[0,1,4]  R129      3.2112199068069458e-01
    z[0,1,4]  R130      -5.4176330566406250e-01
    z[0,1,4]  R131      6.5428592264652252e-02
    z[0,1,4]  R132      1.7017661035060883e-01
    z[0,1,4]  R133      -0.142030268907547
    z[0,1,4]  R134      -1.4919550158083439e-02
    z[0,1,4]  R135      1.5047530643641949e-02
    z[0,1,4]  R136      -2.5630483031272888e-01
    z[0,1,4]  R137      -2.0106402039527893e-01
    z[0,1,4]  R138      2.6019278168678284e-01
    z[0,1,4]  R139      1.7763257026672363e-01
    z[0,1,4]  R140      -1.9522084295749664e-01
    z[0,1,4]  R141      -5.5625919252634048e-02
    z[0,1,4]  R142      -1.1468805372714996e-01
    z[0,1,4]  R143      2.8277322649955750e-01
    z[0,1,4]  R144      -4.1842761635780334e-01
    z[0,1,4]  R145      -5.1813744008541107e-02
    z[0,1,4]  R146      1.5262334048748016e-01
    z[0,1,4]  R147      -3.9830081164836884e-02
    z[0,1,4]  R148      -3.4797763824462891e-01
    z[0,1,4]  R149      -1.8198819458484650e-01
    z[0,1,4]  R150      5.0782209634780884e-01
    z[0,1,4]  R151      5.0541943311691284e-01
    z[0,1,4]  R152      7.0441913604736328e-01
    z[0,1,4]  R153      1.5030542016029358e-01
    z[0,1,4]  R154      1.8428441882133484e-01
    z[0,1,4]  R155      0.532706618309021
    z[0,1,4]  R156      4.6939682960510254e-01
    z[0,1,4]  R157      -1.0630524903535843e-01
    z[0,1,4]  R158      -1.1071750521659851e-01
    z[0,1,4]  R159      -3.0283406376838684e-03
    z[0,1,4]  R160      1.0974252223968506e-01
    z[0,1,4]  R161      -1.2475372105836868e-01
    z[0,1,4]  R162      2.1234643459320068e-01
    z[0,1,4]  R163      1.4340290427207947e-01
    z[0,1,4]  R164      4.1452908515930176e-01
    z[0,1,4]  R165      -2.9557171463966370e-01
    z[0,1,4]  R166      1.0928661562502384e-02
    z[0,1,4]  R167      -3.0401936173439026e-01
    z[0,1,4]  R168      1.9716110825538635e-01
    z[0,1,4]  R169      4.9992737174034119e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R66       -1
    z[0,1,5]  R67       1
    z[0,1,5]  R70       -5.0905489921569824e-01
    z[0,1,5]  R71       -5.4433119297027588e-01
    z[0,1,5]  R72       -4.7511899471282959e-01
    z[0,1,5]  R73       -1.6559608280658722e-01
    z[0,1,5]  R74       -3.4410101175308228e-01
    z[0,1,5]  R75       4.9339506775140762e-02
    z[0,1,5]  R76       7.2693345136940479e-03
    z[0,1,5]  R77       -5.5108584463596344e-02
    z[0,1,5]  R78       -0.0675864890217781
    z[0,1,5]  R79       -2.6002112776041031e-02
    z[0,1,5]  R80       3.0668914318084717e-01
    z[0,1,5]  R81       2.4083366990089417e-01
    z[0,1,5]  R82       -9.9006086587905884e-02
    z[0,1,5]  R83       -2.1417747437953949e-01
    z[0,1,5]  R84       3.3189021050930023e-02
    z[0,1,5]  R85       0.00866305734962225
    z[0,1,5]  R86       2.6181730628013611e-01
    z[0,1,5]  R87       -4.9240300059318542e-01
    z[0,1,5]  R88       -1.0139561444520950e-01
    z[0,1,5]  R89       -3.2355183362960815e-01
    z[0,1,5]  R90       -2.1214015781879425e-01
    z[0,1,5]  R91       -1.0613843053579330e-01
    z[0,1,5]  R92       -1.3273153454065323e-02
    z[0,1,5]  R93       1.6257645189762115e-01
    z[0,1,5]  R94       2.8083750605583191e-01
    z[0,1,5]  R95       -0.361116498708725
    z[0,1,5]  R96       -1.5391005203127861e-02
    z[0,1,5]  R97       -3.2534605264663696e-01
    z[0,1,5]  R98       -3.1955784559249878e-01
    z[0,1,5]  R99       -3.7333497405052185e-01
    z[0,1,5]  R100      -6.0456240177154541e-01
    z[0,1,5]  R101      -4.5098894834518433e-01
    z[0,1,5]  R102      -9.0859957039356232e-02
    z[0,1,5]  R103      -3.5138934850692749e-01
    z[0,1,5]  R104      -2.0510452985763550e-01
    z[0,1,5]  R105      1.2821625173091888e-01
    z[0,1,5]  R106      6.5603062510490417e-02
    z[0,1,5]  R107      -1.5121465921401978e-01
    z[0,1,5]  R108      8.5558727383613586e-02
    z[0,1,5]  R109      -1.1811101436614990e-01
    z[0,1,5]  R110      0.0697358176112175
    z[0,1,5]  R111      -2.8930500149726868e-01
    z[0,1,5]  R112      -4.1346341371536255e-01
    z[0,1,5]  R113      -4.1267088055610657e-01
    z[0,1,5]  R114      -2.0328895747661591e-01
    z[0,1,5]  R115      -1.4351263642311096e-01
    z[0,1,5]  R116      4.5918479561805725e-02
    z[0,1,5]  R117      -1.5339544415473938e-01
    z[0,1,5]  R118      -2.5288888812065125e-01
    z[0,1,5]  R119      -1.1544585227966309e-01
    z[0,1,5]  R120      -4.1427844762802124e-01
    z[0,1,5]  R121      -0.461177259683609
    z[0,1,5]  R122      -0.315845251083374
    z[0,1,5]  R123      -4.4648941606283188e-02
    z[0,1,5]  R124      -3.1556600332260132e-01
    z[0,1,5]  R125      1.0550966858863831e-01
    z[0,1,5]  R126      4.2432162910699844e-02
    z[0,1,5]  R127      0.0781085416674614
    z[0,1,5]  R128      -4.0588015317916870e-01
    z[0,1,5]  R129      4.5679128170013428e-01
    z[0,1,5]  R130      -1.9397646188735962e-01
    z[0,1,5]  R131      -2.5300228595733643e-01
    z[0,1,5]  R132      -4.4067561626434326e-01
    z[0,1,5]  R133      -2.2717300057411194e-01
    z[0,1,5]  R134      -3.7334197759628296e-01
    z[0,1,5]  R135      4.4848173856735229e-03
    z[0,1,5]  R136      -1.7721937596797943e-01
    z[0,1,5]  R137      2.2761276364326477e-01
    z[0,1,5]  R138      3.1403505802154541e-01
    z[0,1,5]  R139      2.1357160806655884e-01
    z[0,1,5]  R140      4.5144062489271164e-02
    z[0,1,5]  R141      5.1510158926248550e-02
    z[0,1,5]  R142      -3.9596560597419739e-01
    z[0,1,5]  R143      -3.4057098627090454e-01
    z[0,1,5]  R144      -6.3107395172119141e-01
    z[0,1,5]  R145      -1.0247718542814255e-01
    z[0,1,5]  R146      -3.4925499558448792e-01
    z[0,1,5]  R147      4.0217429399490356e-01
    z[0,1,5]  R148      -1.4051049947738647e-01
    z[0,1,5]  R149      -2.4994817376136780e-01
    z[0,1,5]  R150      -4.4802263379096985e-01
    z[0,1,5]  R151      -2.0324413478374481e-01
    z[0,1,5]  R152      -1.0597249493002892e-02
    z[0,1,5]  R153      -3.6264079809188843e-01
    z[0,1,5]  R154      4.3007194995880127e-01
    z[0,1,5]  R155      3.4774327278137207e-01
    z[0,1,5]  R156      5.7146232575178146e-02
    z[0,1,5]  R157      5.0299829244613647e-01
    z[0,1,5]  R158      3.9705076813697815e-01
    z[0,1,5]  R159      -4.2692460119724274e-02
    z[0,1,5]  R160      -5.0250776112079620e-02
    z[0,1,5]  R161      1.9489030539989471e-01
    z[0,1,5]  R162      4.0899339318275452e-01
    z[0,1,5]  R163      1.7612640559673309e-01
    z[0,1,5]  R164      2.3359447717666626e-01
    z[0,1,5]  R165      4.1298249363899231e-01
    z[0,1,5]  R166      2.2846752777695656e-02
    z[0,1,5]  R167      2.2896414995193481e-01
    z[0,1,5]  R168      0.241278275847435
    z[0,1,5]  R169      2.1940311789512634e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R68       -1
    z[0,1,6]  R69       1
    z[0,1,6]  R70       1.6963279247283936e-01
    z[0,1,6]  R71       -4.8378005623817444e-02
    z[0,1,6]  R72       -4.2930582165718079e-01
    z[0,1,6]  R73       -2.6640886440873146e-02
    z[0,1,6]  R74       -2.2289891541004181e-01
    z[0,1,6]  R75       -2.6280790567398071e-01
    z[0,1,6]  R76       -3.7124386429786682e-01
    z[0,1,6]  R77       -3.3423757553100586e-01
    z[0,1,6]  R78       1.9612808525562286e-01
    z[0,1,6]  R79       -3.2220214605331421e-01
    z[0,1,6]  R80       1.5329061448574066e-01
    z[0,1,6]  R81       -2.9133863747119904e-02
    z[0,1,6]  R82       3.9179217815399170e-01
    z[0,1,6]  R83       4.7159501910209656e-01
    z[0,1,6]  R84       6.9306629896163940e-01
    z[0,1,6]  R85       -2.4068398773670197e-01
    z[0,1,6]  R86       -8.7645635008811951e-02
    z[0,1,6]  R87       1.3628785312175751e-01
    z[0,1,6]  R88       2.0543886721134186e-01
    z[0,1,6]  R89       1.0894315782934427e-03
    z[0,1,6]  R90       -6.0778349637985229e-01
    z[0,1,6]  R91       1.7104738950729370e-01
    z[0,1,6]  R92       -2.8610643744468689e-01
    z[0,1,6]  R93       -0.148108571767807
    z[0,1,6]  R94       1.6409799456596375e-01
    z[0,1,6]  R95       1.3578611612319946e-01
    z[0,1,6]  R96       -2.7618399262428284e-01
    z[0,1,6]  R97       2.0031447708606720e-01
    z[0,1,6]  R98       -3.8839691877365112e-01
    z[0,1,6]  R99       -4.2779636383056641e-01
    z[0,1,6]  R100      -1.1489473283290863e-01
    z[0,1,6]  R101      -5.0027370452880859e-01
    z[0,1,6]  R102      3.1150346994400024e-01
    z[0,1,6]  R103      -1.1582090705633163e-01
    z[0,1,6]  R104      9.3578919768333435e-02
    z[0,1,6]  R105      -3.5544827580451965e-02
    z[0,1,6]  R106      -2.3790046572685242e-01
    z[0,1,6]  R107      -2.9069057106971741e-01
    z[0,1,6]  R108      -1.3186487555503845e-01
    z[0,1,6]  R109      -5.7730913162231445e-01
    z[0,1,6]  R110      5.2270330488681793e-02
    z[0,1,6]  R111      -0.287873238325119
    z[0,1,6]  R112      -6.1442956328392029e-02
    z[0,1,6]  R113      1.0017297416925430e-01
    z[0,1,6]  R114      -3.4044528007507324e-01
    z[0,1,6]  R115      3.5643249750137329e-02
    z[0,1,6]  R116      2.1268843114376068e-01
    z[0,1,6]  R117      -7.8744582831859589e-02
    z[0,1,6]  R118      8.1997781991958618e-02
    z[0,1,6]  R119      -1.1281748116016388e-01
    z[0,1,6]  R120      0.321675181388855
    z[0,1,6]  R121      -2.5920584797859192e-01
    z[0,1,6]  R122      -5.0701463222503662e-01
    z[0,1,6]  R123      9.7830243408679962e-02
    z[0,1,6]  R124      -4.3358799070119858e-02
    z[0,1,6]  R125      -1.4508636295795441e-01
    z[0,1,6]  R126      -4.2642485350370407e-02
    z[0,1,6]  R127      3.3857926726341248e-02
    z[0,1,6]  R128      -4.3097484111785889e-01
    z[0,1,6]  R129      -1.9725072383880615e-01
    z[0,1,6]  R130      -6.7148125171661377e-01
    z[0,1,6]  R131      -4.5034587383270264e-02
    z[0,1,6]  R132      1.9323875010013580e-01
    z[0,1,6]  R133      -3.8692843168973923e-02
    z[0,1,6]  R134      2.0327742397785187e-01
    z[0,1,6]  R135      -7.8126393258571625e-02
    z[0,1,6]  R136      -4.0910041332244873e-01
    z[0,1,6]  R137      -5.9128899127244949e-02
    z[0,1,6]  R138      8.5603788495063782e-02
    z[0,1,6]  R139      2.7015948295593262e-01
    z[0,1,6]  R140      4.4508108496665955e-01
    z[0,1,6]  R141      -4.6299800276756287e-01
    z[0,1,6]  R142      -1.1209972202777863e-01
    z[0,1,6]  R143      -3.7462544441223145e-01
    z[0,1,6]  R144      -2.7219581604003906e-01
    z[0,1,6]  R145      5.1093274354934692e-01
    z[0,1,6]  R146      2.6656261086463928e-01
    z[0,1,6]  R147      -1.5174549818038940e-01
    z[0,1,6]  R148      -3.5464456677436829e-01
    z[0,1,6]  R149      -5.2352637052536011e-01
    z[0,1,6]  R150      -1.9029730930924416e-02
    z[0,1,6]  R151      1.1859763413667679e-02
    z[0,1,6]  R152      1.6963452100753784e-01
    z[0,1,6]  R153      -4.3357063084840775e-02
    z[0,1,6]  R154      1.4768348634243011e-01
    z[0,1,6]  R155      3.8006898760795593e-01
    z[0,1,6]  R156      -0.208759143948555
    z[0,1,6]  R157      1.0208845883607864e-01
    z[0,1,6]  R158      1.4676529169082642e-01
    z[0,1,6]  R159      4.4861856102943420e-01
    z[0,1,6]  R160      -3.4222227334976196e-01
    z[0,1,6]  R161      1.1750672757625580e-01
    z[0,1,6]  R162      1.0847406834363937e-01
    z[0,1,6]  R163      -3.1713131070137024e-01
    z[0,1,6]  R164      2.5246149301528931e-01
    z[0,1,6]  R165      -1.7355036735534668e-01
    z[0,1,6]  R166      -1.5159356594085693e-01
    z[0,1,6]  R167      3.0916744470596313e-01
    z[0,1,6]  R168      2.3593175411224365e-01
    z[0,1,6]  R169      -1.3633179664611816e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R170      -1
    z[1,0,0]  R171      1
    z[1,0,0]  R184      -4.9690928310155869e-02
    z[1,0,0]  R185      -5.8148401975631714e-01
    z[1,0,0]  R186      -1.1177226155996323e-01
    z[1,0,0]  R187      -6.1769241094589233e-01
    z[1,0,0]  R188      1.4331138134002686e-01
    z[1,0,0]  R189      6.5243035554885864e-01
    z[1,0,0]  R190      6.3770312070846558e-01
    z[1,0,0]  R191      2.9630595818161964e-02
    z[1,0,0]  R192      4.4086730480194092e-01
    z[1,0,0]  R193      2.9334232211112976e-01
    z[1,0,0]  R194      1.6809152066707611e-01
    z[1,0,0]  R195      -0.023863660171628
    z[1,0,0]  R196      -1.1202633380889893e-01
    z[1,0,0]  R197      1.9880126416683197e-01
    z[1,0,0]  R198      -1.3381104171276093e-01
    z[1,0,0]  R199      -7.3125801980495453e-02
    z[1,0,0]  R200      -1.5840733423829079e-02
    z[1,0,0]  R201      1.9686248898506165e-01
    z[1,0,0]  R202      2.2745615243911743e-01
    z[1,0,0]  R203      -6.1484247446060181e-01
    z[1,0,0]  R204      1.7498087882995605e-01
    z[1,0,0]  R205      8.2255318760871887e-02
    z[1,0,0]  R206      -2.1478015184402466e-01
    z[1,0,0]  R207      -1.9356778264045715e-01
    z[1,0,0]  R208      3.4069761633872986e-02
    z[1,0,0]  R209      1.0933275334537029e-02
    z[1,0,0]  R210      3.0830252170562744e-01
    z[1,0,0]  R211      4.4244241714477539e-01
    z[1,0,0]  R212      5.9359449893236160e-02
    z[1,0,0]  R213      6.1092221736907959e-01
    z[1,0,0]  R214      -4.5205074548721313e-01
    z[1,0,0]  R215      -5.8820670843124390e-01
    z[1,0,0]  R216      -4.5692503452301025e-01
    z[1,0,0]  R217      -0.575303316116333
    z[1,0,0]  R218      -6.6564100980758667e-01
    z[1,0,0]  R219      -4.7894108295440674e-01
    z[1,0,0]  R220      -3.1326249241828918e-01
    z[1,0,0]  R221      -7.2099554538726807e-01
    z[1,0,0]  R222      -4.6623095870018005e-01
    z[1,0,0]  R223      -6.5349000692367554e-01
    z[1,0,0]  R224      -0.733890950679779
    z[1,0,0]  R225      -0.615653395652771
    z[1,0,0]  R226      -6.5118718147277832e-01
    z[1,0,0]  R227      -4.8438054323196411e-01
    z[1,0,0]  R228      -5.7601153850555420e-01
    z[1,0,0]  R229      -4.7619366645812988e-01
    z[1,0,0]  R230      2.0817232131958008e-01
    z[1,0,0]  R231      2.8128352761268616e-01
    z[1,0,0]  R232      -4.5916289091110229e-03
    z[1,0,0]  R233      2.1172988414764404e-01
    z[1,0,0]  R234      -2.9712429642677307e-01
    z[1,0,0]  R235      7.1658569574356079e-01
    z[1,0,0]  R236      7.2071969509124756e-01
    z[1,0,0]  R237      7.4970632791519165e-01
    z[1,0,0]  R238      7.8108614683151245e-01
    z[1,0,0]  R239      7.1166193485260010e-01
    z[1,0,0]  R240      6.8975126743316650e-01
    z[1,0,0]  R241      6.5204966068267822e-01
    z[1,0,0]  R242      6.1901992559432983e-01
    z[1,0,0]  R243      6.2065553665161133e-01
    z[1,0,0]  R244      -4.4455844163894653e-01
    z[1,0,0]  R245      2.2149392962455750e-01
    z[1,0,0]  R246      3.6230584979057312e-01
    z[1,0,0]  R247      4.1651627421379089e-01
    z[1,0,0]  R248      7.0132118463516235e-01
    z[1,0,0]  R249      2.6808470487594604e-01
    z[1,0,0]  R250      3.4836953878402710e-01
    z[1,0,0]  R251      6.3359832763671875e-01
    z[1,0,0]  R252      3.8972038030624390e-01
    z[1,0,0]  R253      1.3161903619766235e-01
    z[1,0,0]  R254      4.5193210244178772e-01
    z[1,0,0]  R255      -3.4268078207969666e-01
    z[1,0,0]  R256      -9.8319277167320251e-02
    z[1,0,0]  R257      6.4859133958816528e-01
    z[1,0,0]  R258      8.6352986097335815e-01
    z[1,0,0]  R259      7.9342055320739746e-01
    z[1,0,0]  R260      9.4148766994476318e-01
    z[1,0,0]  R261      7.8157550096511841e-01
    z[1,0,0]  R262      6.8550151586532593e-01
    z[1,0,0]  R263      5.0662785768508911e-01
    z[1,0,0]  R264      2.2607669234275818e-01
    z[1,0,0]  R265      9.1934822499752045e-02
    z[1,0,0]  R266      1.1354370415210724e-01
    z[1,0,0]  R267      6.7248874902725220e-01
    z[1,0,0]  R268      7.4956321716308594e-01
    z[1,0,0]  R269      8.3836203813552856e-01
    z[1,0,0]  R270      7.7884489297866821e-01
    z[1,0,0]  R271      8.1881231069564819e-01
    z[1,0,0]  R272      -3.3339992165565491e-01
    z[1,0,0]  R273      4.8978051543235779e-01
    z[1,0,0]  R274      -3.8395929336547852e-01
    z[1,0,0]  R275      4.7120350599288940e-01
    z[1,0,0]  R276      0.426010400056839
    z[1,0,0]  R277      7.9224973917007446e-01
    z[1,0,0]  R278      7.0684427022933960e-01
    z[1,0,0]  R279      0.902255117893219
    z[1,0,0]  R280      7.2838443517684937e-01
    z[1,0,0]  R281      7.7335160970687866e-01
    z[1,0,0]  R282      -6.5417215228080750e-02
    z[1,0,0]  R283      5.6293249130249023e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R172      -1
    z[1,0,1]  R173      1
    z[1,0,1]  R184      -7.3943519592285156e-01
    z[1,0,1]  R185      -5.7814192771911621e-01
    z[1,0,1]  R186      -4.6810141205787659e-01
    z[1,0,1]  R187      -2.7959123253822327e-01
    z[1,0,1]  R188      -3.9454612135887146e-01
    z[1,0,1]  R189      5.4222857952117920e-01
    z[1,0,1]  R190      5.4430902004241943e-01
    z[1,0,1]  R191      8.7147343158721924e-01
    z[1,0,1]  R192      6.8491917848587036e-01
    z[1,0,1]  R193      5.4950064420700073e-01
    z[1,0,1]  R194      0.711979329586029
    z[1,0,1]  R195      7.1186983585357666e-01
    z[1,0,1]  R196      6.6931933164596558e-01
    z[1,0,1]  R197      7.8237426280975342e-01
    z[1,0,1]  R198      5.9923851490020752e-01
    z[1,0,1]  R199      5.4216337203979492e-01
    z[1,0,1]  R200      4.3436288833618164e-01
    z[1,0,1]  R201      3.3971610665321350e-01
    z[1,0,1]  R202      -8.9301742613315582e-02
    z[1,0,1]  R203      2.7429884672164917e-01
    z[1,0,1]  R204      8.6199837923049927e-01
    z[1,0,1]  R205      7.5430279970169067e-01
    z[1,0,1]  R206      7.6275277137756348e-01
    z[1,0,1]  R207      7.1205347776412964e-01
    z[1,0,1]  R208      7.1167606115341187e-01
    z[1,0,1]  R209      6.6217201948165894e-01
    z[1,0,1]  R210      1.9006147980690002e-01
    z[1,0,1]  R211      6.9651387631893158e-02
    z[1,0,1]  R212      1.0630601644515991e-01
    z[1,0,1]  R213      -3.3505043387413025e-01
    z[1,0,1]  R214      -3.7097299098968506e-01
    z[1,0,1]  R215      -3.6693203449249268e-01
    z[1,0,1]  R216      -4.5138341188430786e-01
    z[1,0,1]  R217      -2.2190444171428680e-01
    z[1,0,1]  R218      -3.6051931977272034e-01
    z[1,0,1]  R219      -3.3479732275009155e-01
    z[1,0,1]  R220      -4.8547694087028503e-01
    z[1,0,1]  R221      -1.9949507713317871e-01
    z[1,0,1]  R222      -5.9826439619064331e-01
    z[1,0,1]  R223      -0.577897846698761
    z[1,0,1]  R224      5.0273150205612183e-01
    z[1,0,1]  R225      2.0162308216094971e-01
    z[1,0,1]  R226      2.5994935631752014e-01
    z[1,0,1]  R227      2.3967595398426056e-01
    z[1,0,1]  R228      1.2009112536907196e-01
    z[1,0,1]  R229      0.344561904668808
    z[1,0,1]  R230      -4.0684238076210022e-01
    z[1,0,1]  R231      5.9415864944458008e-01
    z[1,0,1]  R232      -0.535753607749939
    z[1,0,1]  R233      8.9932310581207275e-01
    z[1,0,1]  R234      -0.492990642786026
    z[1,0,1]  R235      1.3425578176975250e-01
    z[1,0,1]  R236      1.9090722501277924e-01
    z[1,0,1]  R237      2.0522850099951029e-03
    z[1,0,1]  R238      -6.2149807810783386e-02
    z[1,0,1]  R239      -2.7825522422790527e-01
    z[1,0,1]  R240      4.3220886588096619e-01
    z[1,0,1]  R241      -6.9961018860340118e-02
    z[1,0,1]  R242      6.4299218356609344e-02
    z[1,0,1]  R243      -1.0775623470544815e-01
    z[1,0,1]  R244      -5.7922917604446411e-01
    z[1,0,1]  R245      6.5210044384002686e-01
    z[1,0,1]  R246      6.1549621820449829e-01
    z[1,0,1]  R247      4.0255889296531677e-01
    z[1,0,1]  R248      4.0936276316642761e-01
    z[1,0,1]  R249      5.6163680553436279e-01
    z[1,0,1]  R250      7.4027538299560547e-01
    z[1,0,1]  R251      4.1407313942909241e-01
    z[1,0,1]  R252      6.1991912126541138e-01
    z[1,0,1]  R253      5.9269815683364868e-01
    z[1,0,1]  R254      6.5104746818542480e-01
    z[1,0,1]  R255      4.2700815945863724e-02
    z[1,0,1]  R256      3.9969280362129211e-01
    z[1,0,1]  R257      1.8041059374809265e-02
    z[1,0,1]  R258      -7.7699266374111176e-02
    z[1,0,1]  R259      -1.3859303295612335e-01
    z[1,0,1]  R260      -8.7431944906711578e-02
    z[1,0,1]  R261      -3.8322117924690247e-01
    z[1,0,1]  R262      -3.9155939221382141e-01
    z[1,0,1]  R263      -4.6986032975837588e-04
    z[1,0,1]  R264      6.9686084985733032e-01
    z[1,0,1]  R265      2.4475000798702240e-01
    z[1,0,1]  R266      2.9900339245796204e-01
    z[1,0,1]  R267      -9.8890945315361023e-02
    z[1,0,1]  R268      -4.0146824903786182e-03
    z[1,0,1]  R269      -1.4451023936271667e-01
    z[1,0,1]  R270      -1.0399951785802841e-01
    z[1,0,1]  R271      3.2765230536460876e-01
    z[1,0,1]  R272      3.7645879387855530e-01
    z[1,0,1]  R273      -4.8832911252975464e-01
    z[1,0,1]  R274      -5.9402313083410263e-02
    z[1,0,1]  R275      0.790256679058075
    z[1,0,1]  R276      2.7368307113647461e-01
    z[1,0,1]  R277      -3.3937498927116394e-02
    z[1,0,1]  R278      7.8817538917064667e-02
    z[1,0,1]  R279      -5.6102149188518524e-02
    z[1,0,1]  R280      2.4786278605461121e-01
    z[1,0,1]  R281      3.4703928232192993e-01
    z[1,0,1]  R282      -3.4403938055038452e-01
    z[1,0,1]  R283      -5.7602214813232422e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R174      -1
    z[1,0,2]  R175      1
    z[1,0,2]  R184      -1.9925607740879059e-01
    z[1,0,2]  R185      -3.2785028219223022e-01
    z[1,0,2]  R186      -7.2761642932891846e-01
    z[1,0,2]  R187      7.2494186460971832e-02
    z[1,0,2]  R188      9.0446047484874725e-02
    z[1,0,2]  R189      -3.4528259187936783e-02
    z[1,0,2]  R190      8.5024453699588776e-02
    z[1,0,2]  R191      2.3083847761154175e-01
    z[1,0,2]  R192      2.1506215631961823e-01
    z[1,0,2]  R193      -2.6834979653358459e-01
    z[1,0,2]  R194      -2.7630642056465149e-02
    z[1,0,2]  R195      -4.4226527214050293e-01
    z[1,0,2]  R196      1.0201875865459442e-01
    z[1,0,2]  R197      -0.326465904712677
    z[1,0,2]  R198      -6.1449509859085083e-01
    z[1,0,2]  R199      -3.5805395245552063e-01
    z[1,0,2]  R200      1.8681395053863525e-01
    z[1,0,2]  R201      -5.6713706254959106e-01
    z[1,0,2]  R202      7.0076537132263184e-01
    z[1,0,2]  R203      -8.1679157912731171e-02
    z[1,0,2]  R204      7.4630357325077057e-02
    z[1,0,2]  R205      -3.0827391147613525e-01
    z[1,0,2]  R206      -1.6502179205417633e-01
    z[1,0,2]  R207      -5.4879003763198853e-01
    z[1,0,2]  R208      -4.3301945924758911e-01
    z[1,0,2]  R209      -5.0865966081619263e-01
    z[1,0,2]  R210      6.4753150939941406e-01
    z[1,0,2]  R211      6.5141016244888306e-01
    z[1,0,2]  R212      9.0096151828765869e-01
    z[1,0,2]  R213      2.7205786108970642e-01
    z[1,0,2]  R214      -4.9483129382133484e-01
    z[1,0,2]  R215      -9.7330369055271149e-02
    z[1,0,2]  R216      -3.4899190068244934e-01
    z[1,0,2]  R217      -6.0960876941680908e-01
    z[1,0,2]  R218      -4.8680838942527771e-01
    z[1,0,2]  R219      -0.672831118106842
    z[1,0,2]  R220      -3.4733718633651733e-01
    z[1,0,2]  R221      -3.2131305336952209e-01
    z[1,0,2]  R222      -5.7243376970291138e-01
    z[1,0,2]  R223      -2.1037876605987549e-01
    z[1,0,2]  R224      6.6559992730617523e-02
    z[1,0,2]  R225      1.8649429082870483e-01
    z[1,0,2]  R226      6.2250006943941116e-02
    z[1,0,2]  R227      -4.5600169897079468e-01
    z[1,0,2]  R228      1.5084241330623627e-01
    z[1,0,2]  R229      -0.618038535118103
    z[1,0,2]  R230      -0.544635534286499
    z[1,0,2]  R231      2.3024339973926544e-01
    z[1,0,2]  R232      -2.0169420540332794e-01
    z[1,0,2]  R233      -2.8154075145721436e-02
    z[1,0,2]  R234      1.1645640432834625e-01
    z[1,0,2]  R235      2.3529249429702759e-01
    z[1,0,2]  R236      2.2056996822357178e-01
    z[1,0,2]  R237      2.7665516734123230e-01
    z[1,0,2]  R238      5.1817059516906738e-01
    z[1,0,2]  R239      2.8015345335006714e-01
    z[1,0,2]  R240      2.7484706044197083e-01
    z[1,0,2]  R241      3.5513857007026672e-01
    z[1,0,2]  R242      2.9373681545257568e-01
    z[1,0,2]  R243      2.0256657898426056e-01
    z[1,0,2]  R244      1.4184066094458103e-02
    z[1,0,2]  R245      2.0424166321754456e-01
    z[1,0,2]  R246      5.2230864763259888e-01
    z[1,0,2]  R247      6.2774562835693359e-01
    z[1,0,2]  R248      3.2502561807632446e-01
    z[1,0,2]  R249      6.0212141275405884e-01
    z[1,0,2]  R250      0.392896443605423
    z[1,0,2]  R251      4.9758854508399963e-01
    z[1,0,2]  R252      6.3677805662155151e-01
    z[1,0,2]  R253      4.9808567762374878e-01
    z[1,0,2]  R254      5.3835314512252808e-01
    z[1,0,2]  R255      -2.0831923186779022e-01
    z[1,0,2]  R256      7.1620625257492065e-01
    z[1,0,2]  R257      3.1755414605140686e-01
    z[1,0,2]  R258      2.6180100440979004e-01
    z[1,0,2]  R259      4.1566711664199829e-01
    z[1,0,2]  R260      8.9760743081569672e-02
    z[1,0,2]  R261      4.5086222887039185e-01
    z[1,0,2]  R262      5.5262410640716553e-01
    z[1,0,2]  R263      6.1279457807540894e-01
    z[1,0,2]  R264      2.8982168436050415e-01
    z[1,0,2]  R265      7.5420439243316650e-01
    z[1,0,2]  R266      0.323527067899704
    z[1,0,2]  R267      0.619373619556427
    z[1,0,2]  R268      3.5451135039329529e-01
    z[1,0,2]  R269      1.9256868958473206e-01
    z[1,0,2]  R270      5.0941830873489380e-01
    z[1,0,2]  R271      -1.9011670351028442e-01
    z[1,0,2]  R272      2.1972490847110748e-01
    z[1,0,2]  R273      3.6099809408187866e-01
    z[1,0,2]  R274      -0.243872731924057
    z[1,0,2]  R275      2.8777948021888733e-01
    z[1,0,2]  R276      6.9211721420288086e-01
    z[1,0,2]  R277      5.4562073945999146e-01
    z[1,0,2]  R278      5.4034155607223511e-01
    z[1,0,2]  R279      2.1261225640773773e-01
    z[1,0,2]  R280      1.9627201557159424e-01
    z[1,0,2]  R281      -2.2901043295860291e-01
    z[1,0,2]  R282      5.6032079458236694e-01
    z[1,0,2]  R283      4.3365949392318726e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R176      -1
    z[1,0,3]  R177      1
    z[1,0,3]  R184      4.1571286320686340e-01
    z[1,0,3]  R185      5.2801431156694889e-03
    z[1,0,3]  R186      2.3760001361370087e-01
    z[1,0,3]  R187      4.4579803943634033e-01
    z[1,0,3]  R188      4.1010746359825134e-01
    z[1,0,3]  R189      0.0699441209435463
    z[1,0,3]  R190      -2.7111726999282837e-01
    z[1,0,3]  R191      3.5323426127433777e-03
    z[1,0,3]  R192      -1.5383604168891907e-01
    z[1,0,3]  R193      -4.1269126534461975e-01
    z[1,0,3]  R194      -7.1397058665752411e-02
    z[1,0,3]  R195      1.3254101388156414e-02
    z[1,0,3]  R196      -0.062924325466156
    z[1,0,3]  R197      2.9293122887611389e-01
    z[1,0,3]  R198      6.8340882658958435e-02
    z[1,0,3]  R199      -1.5282213687896729e-01
    z[1,0,3]  R200      -7.1344166994094849e-01
    z[1,0,3]  R201      -4.9946320056915283e-01
    z[1,0,3]  R202      -5.0770968198776245e-01
    z[1,0,3]  R203      -5.8048856258392334e-01
    z[1,0,3]  R204      -2.9847297072410583e-01
    z[1,0,3]  R205      5.1173716783523560e-01
    z[1,0,3]  R206      3.4743675589561462e-01
    z[1,0,3]  R207      -4.6729825437068939e-02
    z[1,0,3]  R208      -1.2129744887351990e-01
    z[1,0,3]  R209      1.2098416686058044e-01
    z[1,0,3]  R210      -6.5261560678482056e-01
    z[1,0,3]  R211      -3.6690777540206909e-01
    z[1,0,3]  R212      -1.4384835958480835e-01
    z[1,0,3]  R213      -3.5192090272903442e-01
    z[1,0,3]  R214      2.7465847134590149e-01
    z[1,0,3]  R215      2.1862241625785828e-01
    z[1,0,3]  R216      2.2339639067649841e-01
    z[1,0,3]  R217      2.8020879253745079e-02
    z[1,0,3]  R218      -4.3010301887989044e-02
    z[1,0,3]  R219      3.2868012785911560e-01
    z[1,0,3]  R220      7.9285115003585815e-02
    z[1,0,3]  R221      3.9583992958068848e-01
    z[1,0,3]  R222      -1.6228479146957397e-01
    z[1,0,3]  R223      -1.9534525275230408e-01
    z[1,0,3]  R224      -2.8189438581466675e-01
    z[1,0,3]  R225      -3.4203374385833740e-01
    z[1,0,3]  R226      -2.3261594772338867e-01
    z[1,0,3]  R227      -3.3128741383552551e-01
    z[1,0,3]  R228      -3.6564636230468750e-01
    z[1,0,3]  R229      -3.1601428985595703e-01
    z[1,0,3]  R230      -6.4556926488876343e-01
    z[1,0,3]  R231      -4.0185779333114624e-01
    z[1,0,3]  R232      -4.7184279561042786e-01
    z[1,0,3]  R233      -8.6596027016639709e-02
    z[1,0,3]  R234      -2.1008187532424927e-01
    z[1,0,3]  R235      0.591512143611908
    z[1,0,3]  R236      5.3625398874282837e-01
    z[1,0,3]  R237      3.1039351224899292e-01
    z[1,0,3]  R238      9.4767600297927856e-02
    z[1,0,3]  R239      3.9894381165504456e-01
    z[1,0,3]  R240      2.3887093365192413e-01
    z[1,0,3]  R241      3.5465556383132935e-01
    z[1,0,3]  R242      4.6932280063629150e-01
    z[1,0,3]  R243      4.8359695076942444e-01
    z[1,0,3]  R244      -2.9546749591827393e-01
    z[1,0,3]  R245      -9.2585608363151550e-02
    z[1,0,3]  R246      0.144478902220726
    z[1,0,3]  R247      4.9953363835811615e-02
    z[1,0,3]  R248      -4.1675353050231934e-01
    z[1,0,3]  R249      -1.9000534713268280e-01
    z[1,0,3]  R250      7.0265196263790131e-02
    z[1,0,3]  R251      -2.1355268359184265e-01
    z[1,0,3]  R252      1.0279149562120438e-01
    z[1,0,3]  R253      1.4658312499523163e-01
    z[1,0,3]  R254      -0.240363210439682
    z[1,0,3]  R255      4.0989495813846588e-02
    z[1,0,3]  R256      1.9411119818687439e-01
    z[1,0,3]  R257      4.3253910541534424e-01
    z[1,0,3]  R258      1.4697183668613434e-01
    z[1,0,3]  R259      -9.0161100029945374e-02
    z[1,0,3]  R260      1.9986793398857117e-01
    z[1,0,3]  R261      -2.5931049603968859e-03
    z[1,0,3]  R262      0.0225517675280571
    z[1,0,3]  R263      1.6422437503933907e-02
    z[1,0,3]  R264      2.7692386507987976e-01
    z[1,0,3]  R265      -1.9492456316947937e-01
    z[1,0,3]  R266      -6.0355597734451294e-01
    z[1,0,3]  R267      3.1957823038101196e-01
    z[1,0,3]  R268      4.3257674574851990e-01
    z[1,0,3]  R269      4.4370394945144653e-01
    z[1,0,3]  R270      -5.5770836770534515e-02
    z[1,0,3]  R271      0.400804340839386
    z[1,0,3]  R272      5.8853697776794434e-01
    z[1,0,3]  R273      -2.0160461962223053e-01
    z[1,0,3]  R274      -8.6898155510425568e-02
    z[1,0,3]  R275      1.8041260540485382e-02
    z[1,0,3]  R276      -6.3954539597034454e-02
    z[1,0,3]  R277      1.4463429339230061e-02
    z[1,0,3]  R278      1.4581283926963806e-01
    z[1,0,3]  R279      3.6226221919059753e-01
    z[1,0,3]  R280      3.2409176230430603e-01
    z[1,0,3]  R281      3.6512300372123718e-01
    z[1,0,3]  R282      0.624301016330719
    z[1,0,3]  R283      -1.1442262679338455e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R178      -1
    z[1,0,4]  R179      1
    z[1,0,4]  R184      -1.9522084295749664e-01
    z[1,0,4]  R185      -5.5625919252634048e-02
    z[1,0,4]  R186      -1.1468805372714996e-01
    z[1,0,4]  R187      2.8277322649955750e-01
    z[1,0,4]  R188      -4.1842761635780334e-01
    z[1,0,4]  R189      -5.1813744008541107e-02
    z[1,0,4]  R190      1.5262334048748016e-01
    z[1,0,4]  R191      -3.9830081164836884e-02
    z[1,0,4]  R192      -3.4797763824462891e-01
    z[1,0,4]  R193      -1.8198819458484650e-01
    z[1,0,4]  R194      5.0782209634780884e-01
    z[1,0,4]  R195      5.0541943311691284e-01
    z[1,0,4]  R196      7.0441913604736328e-01
    z[1,0,4]  R197      1.5030542016029358e-01
    z[1,0,4]  R198      1.8428441882133484e-01
    z[1,0,4]  R199      0.532706618309021
    z[1,0,4]  R200      4.6939682960510254e-01
    z[1,0,4]  R201      -1.0630524903535843e-01
    z[1,0,4]  R202      -1.1071750521659851e-01
    z[1,0,4]  R203      -3.0283406376838684e-03
    z[1,0,4]  R204      1.0974252223968506e-01
    z[1,0,4]  R205      -1.2475372105836868e-01
    z[1,0,4]  R206      2.1234643459320068e-01
    z[1,0,4]  R207      1.4340290427207947e-01
    z[1,0,4]  R208      4.1452908515930176e-01
    z[1,0,4]  R209      -2.9557171463966370e-01
    z[1,0,4]  R210      1.0928661562502384e-02
    z[1,0,4]  R211      -3.0401936173439026e-01
    z[1,0,4]  R212      1.9716110825538635e-01
    z[1,0,4]  R213      4.9992737174034119e-01
    z[1,0,4]  R214      -2.2320783138275146e-01
    z[1,0,4]  R215      -4.0431165695190430e-01
    z[1,0,4]  R216      -7.5694218277931213e-02
    z[1,0,4]  R217      -4.6823564171791077e-01
    z[1,0,4]  R218      -1.4151379466056824e-01
    z[1,0,4]  R219      -1.6214616596698761e-01
    z[1,0,4]  R220      -6.3354140520095825e-01
    z[1,0,4]  R221      -2.5628909468650818e-01
    z[1,0,4]  R222      -1.6630516946315765e-01
    z[1,0,4]  R223      -2.2820074856281281e-01
    z[1,0,4]  R224      8.4936410188674927e-02
    z[1,0,4]  R225      6.0803145170211792e-01
    z[1,0,4]  R226      0.535810649394989
    z[1,0,4]  R227      3.4923958778381348e-01
    z[1,0,4]  R228      -1.2607812881469727e-01
    z[1,0,4]  R229      3.3863863348960876e-01
    z[1,0,4]  R230      3.9063774049282074e-02
    z[1,0,4]  R231      -3.0383935570716858e-01
    z[1,0,4]  R232      -6.3019412755966187e-01
    z[1,0,4]  R233      0.182783842086792
    z[1,0,4]  R234      -4.4336962699890137e-01
    z[1,0,4]  R235      -1.5069375932216644e-01
    z[1,0,4]  R236      -1.6082622110843658e-01
    z[1,0,4]  R237      -4.6549633145332336e-01
    z[1,0,4]  R238      -5.2558548748493195e-02
    z[1,0,4]  R239      -1.7212267220020294e-01
    z[1,0,4]  R240      -3.5822349786758423e-01
    z[1,0,4]  R241      4.1479739546775818e-01
    z[1,0,4]  R242      2.3057612776756287e-01
    z[1,0,4]  R243      -7.6729096472263336e-02
    z[1,0,4]  R244      -2.5740219280123711e-02
    z[1,0,4]  R245      -0.147491917014122
    z[1,0,4]  R246      3.0154368281364441e-01
    z[1,0,4]  R247      3.6195525527000427e-01
    z[1,0,4]  R248      1.0208228230476379e-01
    z[1,0,4]  R249      -4.4310221076011658e-01
    z[1,0,4]  R250      -3.3230370283126831e-01
    z[1,0,4]  R251      1.6288186609745026e-01
    z[1,0,4]  R252      -1.5184590220451355e-01
    z[1,0,4]  R253      1.2072016298770905e-01
    z[1,0,4]  R254      1.2923154234886169e-01
    z[1,0,4]  R255      -0.817986011505127
    z[1,0,4]  R256      -3.2437807321548462e-01
    z[1,0,4]  R257      -3.3277797698974609e-01
    z[1,0,4]  R258      -3.0150877311825752e-02
    z[1,0,4]  R259      -3.8535857200622559e-01
    z[1,0,4]  R260      1.0299303382635117e-01
    z[1,0,4]  R261      -9.6264392137527466e-02
    z[1,0,4]  R262      -1.3803568668663502e-02
    z[1,0,4]  R263      -5.8436781167984009e-01
    z[1,0,4]  R264      -1.6579884290695190e-01
    z[1,0,4]  R265      -2.1202203631401062e-01
    z[1,0,4]  R266      -2.6820358633995056e-01
    z[1,0,4]  R267      -2.0164571702480316e-01
    z[1,0,4]  R268      1.5451878309249878e-01
    z[1,0,4]  R269      1.0063663125038147e-01
    z[1,0,4]  R270      3.4109887480735779e-01
    z[1,0,4]  R271      0.134738951921463
    z[1,0,4]  R272      4.4613420963287354e-02
    z[1,0,4]  R273      3.2112199068069458e-01
    z[1,0,4]  R274      -5.4176330566406250e-01
    z[1,0,4]  R275      6.5428592264652252e-02
    z[1,0,4]  R276      1.7017661035060883e-01
    z[1,0,4]  R277      -0.142030268907547
    z[1,0,4]  R278      -1.4919550158083439e-02
    z[1,0,4]  R279      1.5047530643641949e-02
    z[1,0,4]  R280      -2.5630483031272888e-01
    z[1,0,4]  R281      -2.0106402039527893e-01
    z[1,0,4]  R282      2.6019278168678284e-01
    z[1,0,4]  R283      1.7763257026672363e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R180      -1
    z[1,0,5]  R181      1
    z[1,0,5]  R184      4.5144062489271164e-02
    z[1,0,5]  R185      5.1510158926248550e-02
    z[1,0,5]  R186      -3.9596560597419739e-01
    z[1,0,5]  R187      -3.4057098627090454e-01
    z[1,0,5]  R188      -6.3107395172119141e-01
    z[1,0,5]  R189      -1.0247718542814255e-01
    z[1,0,5]  R190      -3.4925499558448792e-01
    z[1,0,5]  R191      4.0217429399490356e-01
    z[1,0,5]  R192      -1.4051049947738647e-01
    z[1,0,5]  R193      -2.4994817376136780e-01
    z[1,0,5]  R194      -4.4802263379096985e-01
    z[1,0,5]  R195      -2.0324413478374481e-01
    z[1,0,5]  R196      -1.0597249493002892e-02
    z[1,0,5]  R197      -3.6264079809188843e-01
    z[1,0,5]  R198      4.3007194995880127e-01
    z[1,0,5]  R199      3.4774327278137207e-01
    z[1,0,5]  R200      5.7146232575178146e-02
    z[1,0,5]  R201      5.0299829244613647e-01
    z[1,0,5]  R202      3.9705076813697815e-01
    z[1,0,5]  R203      -4.2692460119724274e-02
    z[1,0,5]  R204      -5.0250776112079620e-02
    z[1,0,5]  R205      1.9489030539989471e-01
    z[1,0,5]  R206      4.0899339318275452e-01
    z[1,0,5]  R207      1.7612640559673309e-01
    z[1,0,5]  R208      2.3359447717666626e-01
    z[1,0,5]  R209      4.1298249363899231e-01
    z[1,0,5]  R210      2.2846752777695656e-02
    z[1,0,5]  R211      2.2896414995193481e-01
    z[1,0,5]  R212      0.241278275847435
    z[1,0,5]  R213      2.1940311789512634e-01
    z[1,0,5]  R214      -5.0905489921569824e-01
    z[1,0,5]  R215      -5.4433119297027588e-01
    z[1,0,5]  R216      -4.7511899471282959e-01
    z[1,0,5]  R217      -1.6559608280658722e-01
    z[1,0,5]  R218      -3.4410101175308228e-01
    z[1,0,5]  R219      4.9339506775140762e-02
    z[1,0,5]  R220      7.2693345136940479e-03
    z[1,0,5]  R221      -5.5108584463596344e-02
    z[1,0,5]  R222      -0.0675864890217781
    z[1,0,5]  R223      -2.6002112776041031e-02
    z[1,0,5]  R224      3.0668914318084717e-01
    z[1,0,5]  R225      2.4083366990089417e-01
    z[1,0,5]  R226      -9.9006086587905884e-02
    z[1,0,5]  R227      -2.1417747437953949e-01
    z[1,0,5]  R228      3.3189021050930023e-02
    z[1,0,5]  R229      0.00866305734962225
    z[1,0,5]  R230      2.6181730628013611e-01
    z[1,0,5]  R231      -4.9240300059318542e-01
    z[1,0,5]  R232      -1.0139561444520950e-01
    z[1,0,5]  R233      -3.2355183362960815e-01
    z[1,0,5]  R234      -2.1214015781879425e-01
    z[1,0,5]  R235      -1.0613843053579330e-01
    z[1,0,5]  R236      -1.3273153454065323e-02
    z[1,0,5]  R237      1.6257645189762115e-01
    z[1,0,5]  R238      2.8083750605583191e-01
    z[1,0,5]  R239      -0.361116498708725
    z[1,0,5]  R240      -1.5391005203127861e-02
    z[1,0,5]  R241      -3.2534605264663696e-01
    z[1,0,5]  R242      -3.1955784559249878e-01
    z[1,0,5]  R243      -3.7333497405052185e-01
    z[1,0,5]  R244      -6.0456240177154541e-01
    z[1,0,5]  R245      -4.5098894834518433e-01
    z[1,0,5]  R246      -9.0859957039356232e-02
    z[1,0,5]  R247      -3.5138934850692749e-01
    z[1,0,5]  R248      -2.0510452985763550e-01
    z[1,0,5]  R249      1.2821625173091888e-01
    z[1,0,5]  R250      6.5603062510490417e-02
    z[1,0,5]  R251      -1.5121465921401978e-01
    z[1,0,5]  R252      8.5558727383613586e-02
    z[1,0,5]  R253      -1.1811101436614990e-01
    z[1,0,5]  R254      0.0697358176112175
    z[1,0,5]  R255      -2.8930500149726868e-01
    z[1,0,5]  R256      -4.1346341371536255e-01
    z[1,0,5]  R257      -4.1267088055610657e-01
    z[1,0,5]  R258      -2.0328895747661591e-01
    z[1,0,5]  R259      -1.4351263642311096e-01
    z[1,0,5]  R260      4.5918479561805725e-02
    z[1,0,5]  R261      -1.5339544415473938e-01
    z[1,0,5]  R262      -2.5288888812065125e-01
    z[1,0,5]  R263      -1.1544585227966309e-01
    z[1,0,5]  R264      -4.1427844762802124e-01
    z[1,0,5]  R265      -0.461177259683609
    z[1,0,5]  R266      -0.315845251083374
    z[1,0,5]  R267      -4.4648941606283188e-02
    z[1,0,5]  R268      -3.1556600332260132e-01
    z[1,0,5]  R269      1.0550966858863831e-01
    z[1,0,5]  R270      4.2432162910699844e-02
    z[1,0,5]  R271      0.0781085416674614
    z[1,0,5]  R272      -4.0588015317916870e-01
    z[1,0,5]  R273      4.5679128170013428e-01
    z[1,0,5]  R274      -1.9397646188735962e-01
    z[1,0,5]  R275      -2.5300228595733643e-01
    z[1,0,5]  R276      -4.4067561626434326e-01
    z[1,0,5]  R277      -2.2717300057411194e-01
    z[1,0,5]  R278      -3.7334197759628296e-01
    z[1,0,5]  R279      4.4848173856735229e-03
    z[1,0,5]  R280      -1.7721937596797943e-01
    z[1,0,5]  R281      2.2761276364326477e-01
    z[1,0,5]  R282      3.1403505802154541e-01
    z[1,0,5]  R283      2.1357160806655884e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R182      -1
    z[1,0,6]  R183      1
    z[1,0,6]  R184      4.4508108496665955e-01
    z[1,0,6]  R185      -4.6299800276756287e-01
    z[1,0,6]  R186      -1.1209972202777863e-01
    z[1,0,6]  R187      -3.7462544441223145e-01
    z[1,0,6]  R188      -2.7219581604003906e-01
    z[1,0,6]  R189      5.1093274354934692e-01
    z[1,0,6]  R190      2.6656261086463928e-01
    z[1,0,6]  R191      -1.5174549818038940e-01
    z[1,0,6]  R192      -3.5464456677436829e-01
    z[1,0,6]  R193      -5.2352637052536011e-01
    z[1,0,6]  R194      -1.9029730930924416e-02
    z[1,0,6]  R195      1.1859763413667679e-02
    z[1,0,6]  R196      1.6963452100753784e-01
    z[1,0,6]  R197      -4.3357063084840775e-02
    z[1,0,6]  R198      1.4768348634243011e-01
    z[1,0,6]  R199      3.8006898760795593e-01
    z[1,0,6]  R200      -0.208759143948555
    z[1,0,6]  R201      1.0208845883607864e-01
    z[1,0,6]  R202      1.4676529169082642e-01
    z[1,0,6]  R203      4.4861856102943420e-01
    z[1,0,6]  R204      -3.4222227334976196e-01
    z[1,0,6]  R205      1.1750672757625580e-01
    z[1,0,6]  R206      1.0847406834363937e-01
    z[1,0,6]  R207      -3.1713131070137024e-01
    z[1,0,6]  R208      2.5246149301528931e-01
    z[1,0,6]  R209      -1.7355036735534668e-01
    z[1,0,6]  R210      -1.5159356594085693e-01
    z[1,0,6]  R211      3.0916744470596313e-01
    z[1,0,6]  R212      2.3593175411224365e-01
    z[1,0,6]  R213      -1.3633179664611816e-01
    z[1,0,6]  R214      1.6963279247283936e-01
    z[1,0,6]  R215      -4.8378005623817444e-02
    z[1,0,6]  R216      -4.2930582165718079e-01
    z[1,0,6]  R217      -2.6640886440873146e-02
    z[1,0,6]  R218      -2.2289891541004181e-01
    z[1,0,6]  R219      -2.6280790567398071e-01
    z[1,0,6]  R220      -3.7124386429786682e-01
    z[1,0,6]  R221      -3.3423757553100586e-01
    z[1,0,6]  R222      1.9612808525562286e-01
    z[1,0,6]  R223      -3.2220214605331421e-01
    z[1,0,6]  R224      1.5329061448574066e-01
    z[1,0,6]  R225      -2.9133863747119904e-02
    z[1,0,6]  R226      3.9179217815399170e-01
    z[1,0,6]  R227      4.7159501910209656e-01
    z[1,0,6]  R228      6.9306629896163940e-01
    z[1,0,6]  R229      -2.4068398773670197e-01
    z[1,0,6]  R230      -8.7645635008811951e-02
    z[1,0,6]  R231      1.3628785312175751e-01
    z[1,0,6]  R232      2.0543886721134186e-01
    z[1,0,6]  R233      1.0894315782934427e-03
    z[1,0,6]  R234      -6.0778349637985229e-01
    z[1,0,6]  R235      1.7104738950729370e-01
    z[1,0,6]  R236      -2.8610643744468689e-01
    z[1,0,6]  R237      -0.148108571767807
    z[1,0,6]  R238      1.6409799456596375e-01
    z[1,0,6]  R239      1.3578611612319946e-01
    z[1,0,6]  R240      -2.7618399262428284e-01
    z[1,0,6]  R241      2.0031447708606720e-01
    z[1,0,6]  R242      -3.8839691877365112e-01
    z[1,0,6]  R243      -4.2779636383056641e-01
    z[1,0,6]  R244      -1.1489473283290863e-01
    z[1,0,6]  R245      -5.0027370452880859e-01
    z[1,0,6]  R246      3.1150346994400024e-01
    z[1,0,6]  R247      -1.1582090705633163e-01
    z[1,0,6]  R248      9.3578919768333435e-02
    z[1,0,6]  R249      -3.5544827580451965e-02
    z[1,0,6]  R250      -2.3790046572685242e-01
    z[1,0,6]  R251      -2.9069057106971741e-01
    z[1,0,6]  R252      -1.3186487555503845e-01
    z[1,0,6]  R253      -5.7730913162231445e-01
    z[1,0,6]  R254      5.2270330488681793e-02
    z[1,0,6]  R255      -0.287873238325119
    z[1,0,6]  R256      -6.1442956328392029e-02
    z[1,0,6]  R257      1.0017297416925430e-01
    z[1,0,6]  R258      -3.4044528007507324e-01
    z[1,0,6]  R259      3.5643249750137329e-02
    z[1,0,6]  R260      2.1268843114376068e-01
    z[1,0,6]  R261      -7.8744582831859589e-02
    z[1,0,6]  R262      8.1997781991958618e-02
    z[1,0,6]  R263      -1.1281748116016388e-01
    z[1,0,6]  R264      0.321675181388855
    z[1,0,6]  R265      -2.5920584797859192e-01
    z[1,0,6]  R266      -5.0701463222503662e-01
    z[1,0,6]  R267      9.7830243408679962e-02
    z[1,0,6]  R268      -4.3358799070119858e-02
    z[1,0,6]  R269      -1.4508636295795441e-01
    z[1,0,6]  R270      -4.2642485350370407e-02
    z[1,0,6]  R271      3.3857926726341248e-02
    z[1,0,6]  R272      -4.3097484111785889e-01
    z[1,0,6]  R273      -1.9725072383880615e-01
    z[1,0,6]  R274      -6.7148125171661377e-01
    z[1,0,6]  R275      -4.5034587383270264e-02
    z[1,0,6]  R276      1.9323875010013580e-01
    z[1,0,6]  R277      -3.8692843168973923e-02
    z[1,0,6]  R278      2.0327742397785187e-01
    z[1,0,6]  R279      -7.8126393258571625e-02
    z[1,0,6]  R280      -4.0910041332244873e-01
    z[1,0,6]  R281      -5.9128899127244949e-02
    z[1,0,6]  R282      8.5603788495063782e-02
    z[1,0,6]  R283      2.7015948295593262e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R284      -1
    z[0,3,0]  R285      1
    z[0,3,0]  R298      -4.5205074548721313e-01
    z[0,3,0]  R299      -5.8820670843124390e-01
    z[0,3,0]  R300      -4.5692503452301025e-01
    z[0,3,0]  R301      -0.575303316116333
    z[0,3,0]  R302      -6.6564100980758667e-01
    z[0,3,0]  R303      -4.7894108295440674e-01
    z[0,3,0]  R304      -3.1326249241828918e-01
    z[0,3,0]  R305      -7.2099554538726807e-01
    z[0,3,0]  R306      -4.6623095870018005e-01
    z[0,3,0]  R307      -6.5349000692367554e-01
    z[0,3,0]  R308      -0.733890950679779
    z[0,3,0]  R309      -0.615653395652771
    z[0,3,0]  R310      -6.5118718147277832e-01
    z[0,3,0]  R311      -4.8438054323196411e-01
    z[0,3,0]  R312      -5.7601153850555420e-01
    z[0,3,0]  R313      -4.7619366645812988e-01
    z[0,3,0]  R314      2.0817232131958008e-01
    z[0,3,0]  R315      2.8128352761268616e-01
    z[0,3,0]  R316      -4.5916289091110229e-03
    z[0,3,0]  R317      2.1172988414764404e-01
    z[0,3,0]  R318      -2.9712429642677307e-01
    z[0,3,0]  R319      7.1658569574356079e-01
    z[0,3,0]  R320      7.2071969509124756e-01
    z[0,3,0]  R321      7.4970632791519165e-01
    z[0,3,0]  R322      7.8108614683151245e-01
    z[0,3,0]  R323      7.1166193485260010e-01
    z[0,3,0]  R324      6.8975126743316650e-01
    z[0,3,0]  R325      6.5204966068267822e-01
    z[0,3,0]  R326      6.1901992559432983e-01
    z[0,3,0]  R327      6.2065553665161133e-01
    z[0,3,0]  R328      -4.4455844163894653e-01
    z[0,3,0]  R329      2.2149392962455750e-01
    z[0,3,0]  R330      3.6230584979057312e-01
    z[0,3,0]  R331      4.1651627421379089e-01
    z[0,3,0]  R332      7.0132118463516235e-01
    z[0,3,0]  R333      2.6808470487594604e-01
    z[0,3,0]  R334      3.4836953878402710e-01
    z[0,3,0]  R335      6.3359832763671875e-01
    z[0,3,0]  R336      3.8972038030624390e-01
    z[0,3,0]  R337      1.3161903619766235e-01
    z[0,3,0]  R338      4.5193210244178772e-01
    z[0,3,0]  R339      -3.4268078207969666e-01
    z[0,3,0]  R340      -9.8319277167320251e-02
    z[0,3,0]  R341      6.4859133958816528e-01
    z[0,3,0]  R342      8.6352986097335815e-01
    z[0,3,0]  R343      7.9342055320739746e-01
    z[0,3,0]  R344      9.4148766994476318e-01
    z[0,3,0]  R345      7.8157550096511841e-01
    z[0,3,0]  R346      6.8550151586532593e-01
    z[0,3,0]  R347      5.0662785768508911e-01
    z[0,3,0]  R348      2.2607669234275818e-01
    z[0,3,0]  R349      9.1934822499752045e-02
    z[0,3,0]  R350      1.1354370415210724e-01
    z[0,3,0]  R351      6.7248874902725220e-01
    z[0,3,0]  R352      7.4956321716308594e-01
    z[0,3,0]  R353      8.3836203813552856e-01
    z[0,3,0]  R354      7.7884489297866821e-01
    z[0,3,0]  R355      8.1881231069564819e-01
    z[0,3,0]  R356      -3.3339992165565491e-01
    z[0,3,0]  R357      4.8978051543235779e-01
    z[0,3,0]  R358      -3.8395929336547852e-01
    z[0,3,0]  R359      4.7120350599288940e-01
    z[0,3,0]  R360      0.426010400056839
    z[0,3,0]  R361      7.9224973917007446e-01
    z[0,3,0]  R362      7.0684427022933960e-01
    z[0,3,0]  R363      0.902255117893219
    z[0,3,0]  R364      7.2838443517684937e-01
    z[0,3,0]  R365      7.7335160970687866e-01
    z[0,3,0]  R366      -6.5417215228080750e-02
    z[0,3,0]  R367      5.6293249130249023e-01
    z[0,3,0]  R368      -9.0111321210861206e-01
    z[0,3,0]  R369      -6.0407590866088867e-01
    z[0,3,0]  R370      -6.1722850799560547e-01
    z[0,3,0]  R371      -3.1324347853660583e-01
    z[0,3,0]  R372      1.8402388691902161e-01
    z[0,3,0]  R373      3.5888195037841797e-01
    z[0,3,0]  R374      1.2001663446426392e-01
    z[0,3,0]  R375      3.3409410715103149e-01
    z[0,3,0]  R376      1.7947991192340851e-01
    z[0,3,0]  R377      6.3400840759277344e-01
    z[0,3,0]  R378      -1.9765214622020721e-01
    z[0,3,0]  R379      -1.7510922625660896e-02
    z[0,3,0]  R380      6.6964410245418549e-02
    z[0,3,0]  R381      -2.7715164422988892e-01
    z[0,3,0]  R382      -2.5218993425369263e-01
    z[0,3,0]  R383      -3.1260257959365845e-01
    z[0,3,0]  R384      -2.3082602024078369e-01
    z[0,3,0]  R385      2.8432890772819519e-01
    z[0,3,0]  R386      -2.3441386222839355e-01
    z[0,3,0]  R387      -2.9212430119514465e-01
    z[0,3,0]  R388      1.8149070441722870e-01
    z[0,3,0]  R389      1.8245698511600494e-01
    z[0,3,0]  R390      2.0640777051448822e-01
    z[0,3,0]  R391      6.3469523191452026e-01
    z[0,3,0]  R392      1.3563279062509537e-02
    z[0,3,0]  R393      -5.5913887917995453e-02
    z[0,3,0]  R394      8.2741332054138184e-01
    z[0,3,0]  R395      8.7075871229171753e-01
    z[0,3,0]  R396      7.9749417304992676e-01
    z[0,3,0]  R397      6.9988548755645752e-01
    z[0,3,0]  R398      3.3281859010457993e-02
    z[0,3,0]  R399      2.2290296852588654e-01
    z[0,3,0]  R400      2.5331950187683105e-01
    z[0,3,0]  R401      2.9828539490699768e-01
    z[0,3,0]  R402      -5.0881292670965195e-02
    z[0,3,0]  R403      1.5746654570102692e-01
    z[0,3,0]  R404      2.3393720388412476e-01
    z[0,3,0]  R405      2.9809838533401489e-01
    z[0,3,0]  R406      -0.00982271321117878
    z[0,3,0]  R407      5.6180328130722046e-01
    z[0,3,0]  R408      4.6654570102691650e-01
    z[0,3,0]  R409      1.6208623349666595e-01
    z[0,3,0]  R410      8.7015196681022644e-02
    z[0,3,0]  R411      3.2016941905021667e-01
    z[0,3,0]  R412      -4.7110697627067566e-01
    z[0,3,0]  R413      1.8492648005485535e-01
    z[0,3,0]  R414      6.8464279174804688e-01
    z[0,3,0]  R415      7.6983755826950073e-01
    z[0,3,0]  R416      0.762596070766449
    z[0,3,0]  R417      5.2648055553436279e-01
    z[0,3,0]  R418      1.5865485370159149e-01
    z[0,3,0]  R419      -1.2692667543888092e-01
    z[0,3,0]  R420      1.6466620564460754e-01
    z[0,3,0]  R421      2.2486260533332825e-01
    z[0,3,0]  R422      9.1835662722587585e-02
    z[0,3,0]  R423      5.8491063117980957e-01
    z[0,3,0]  R424      4.2816135287284851e-01
    z[0,3,0]  R425      1.3206787407398224e-01
    z[0,3,0]  R426      -2.5663343071937561e-01
    z[0,3,0]  R427      5.6501740217208862e-01
    z[0,3,0]  R428      -1.0809303820133209e-01
    z[0,3,0]  R429      6.1006840318441391e-02
    z[0,3,0]  R430      -1.6829517483711243e-01
    z[0,3,0]  R431      5.4270672798156738e-01
    z[0,3,0]  R432      2.4762864410877228e-01
    z[0,3,0]  R433      7.2049885988235474e-01
    z[0,3,0]  R434      7.4297547340393066e-01
    z[0,3,0]  R435      8.6693710088729858e-01
    z[0,3,0]  R436      5.6837695837020874e-01
    z[0,3,0]  R437      6.9224995374679565e-01
    z[0,3,0]  R438      9.9514469504356384e-02
    z[0,3,0]  R439      3.3170798420906067e-01
    z[0,3,0]  R440      0.807605504989624
    z[0,3,0]  R441      7.4419957399368286e-01
    z[0,3,0]  R442      8.3993387222290039e-01
    z[0,3,0]  R443      7.7641081809997559e-01
    z[0,3,0]  R444      6.3118547201156616e-01
    z[0,3,0]  R445      2.9213285446166992e-01
    z[0,3,0]  R446      3.0005431175231934e-01
    z[0,3,0]  R447      2.1501564979553223e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R286      -1
    z[0,3,1]  R287      1
    z[0,3,1]  R298      -3.7097299098968506e-01
    z[0,3,1]  R299      -3.6693203449249268e-01
    z[0,3,1]  R300      -4.5138341188430786e-01
    z[0,3,1]  R301      -2.2190444171428680e-01
    z[0,3,1]  R302      -3.6051931977272034e-01
    z[0,3,1]  R303      -3.3479732275009155e-01
    z[0,3,1]  R304      -4.8547694087028503e-01
    z[0,3,1]  R305      -1.9949507713317871e-01
    z[0,3,1]  R306      -5.9826439619064331e-01
    z[0,3,1]  R307      -0.577897846698761
    z[0,3,1]  R308      5.0273150205612183e-01
    z[0,3,1]  R309      2.0162308216094971e-01
    z[0,3,1]  R310      2.5994935631752014e-01
    z[0,3,1]  R311      2.3967595398426056e-01
    z[0,3,1]  R312      1.2009112536907196e-01
    z[0,3,1]  R313      0.344561904668808
    z[0,3,1]  R314      -4.0684238076210022e-01
    z[0,3,1]  R315      5.9415864944458008e-01
    z[0,3,1]  R316      -0.535753607749939
    z[0,3,1]  R317      8.9932310581207275e-01
    z[0,3,1]  R318      -0.492990642786026
    z[0,3,1]  R319      1.3425578176975250e-01
    z[0,3,1]  R320      1.9090722501277924e-01
    z[0,3,1]  R321      2.0522850099951029e-03
    z[0,3,1]  R322      -6.2149807810783386e-02
    z[0,3,1]  R323      -2.7825522422790527e-01
    z[0,3,1]  R324      4.3220886588096619e-01
    z[0,3,1]  R325      -6.9961018860340118e-02
    z[0,3,1]  R326      6.4299218356609344e-02
    z[0,3,1]  R327      -1.0775623470544815e-01
    z[0,3,1]  R328      -5.7922917604446411e-01
    z[0,3,1]  R329      6.5210044384002686e-01
    z[0,3,1]  R330      6.1549621820449829e-01
    z[0,3,1]  R331      4.0255889296531677e-01
    z[0,3,1]  R332      4.0936276316642761e-01
    z[0,3,1]  R333      5.6163680553436279e-01
    z[0,3,1]  R334      7.4027538299560547e-01
    z[0,3,1]  R335      4.1407313942909241e-01
    z[0,3,1]  R336      6.1991912126541138e-01
    z[0,3,1]  R337      5.9269815683364868e-01
    z[0,3,1]  R338      6.5104746818542480e-01
    z[0,3,1]  R339      4.2700815945863724e-02
    z[0,3,1]  R340      3.9969280362129211e-01
    z[0,3,1]  R341      1.8041059374809265e-02
    z[0,3,1]  R342      -7.7699266374111176e-02
    z[0,3,1]  R343      -1.3859303295612335e-01
    z[0,3,1]  R344      -8.7431944906711578e-02
    z[0,3,1]  R345      -3.8322117924690247e-01
    z[0,3,1]  R346      -3.9155939221382141e-01
    z[0,3,1]  R347      -4.6986032975837588e-04
    z[0,3,1]  R348      6.9686084985733032e-01
    z[0,3,1]  R349      2.4475000798702240e-01
    z[0,3,1]  R350      2.9900339245796204e-01
    z[0,3,1]  R351      -9.8890945315361023e-02
    z[0,3,1]  R352      -4.0146824903786182e-03
    z[0,3,1]  R353      -1.4451023936271667e-01
    z[0,3,1]  R354      -1.0399951785802841e-01
    z[0,3,1]  R355      3.2765230536460876e-01
    z[0,3,1]  R356      3.7645879387855530e-01
    z[0,3,1]  R357      -4.8832911252975464e-01
    z[0,3,1]  R358      -5.9402313083410263e-02
    z[0,3,1]  R359      0.790256679058075
    z[0,3,1]  R360      2.7368307113647461e-01
    z[0,3,1]  R361      -3.3937498927116394e-02
    z[0,3,1]  R362      7.8817538917064667e-02
    z[0,3,1]  R363      -5.6102149188518524e-02
    z[0,3,1]  R364      2.4786278605461121e-01
    z[0,3,1]  R365      3.4703928232192993e-01
    z[0,3,1]  R366      -3.4403938055038452e-01
    z[0,3,1]  R367      -5.7602214813232422e-01
    z[0,3,1]  R368      2.4428819119930267e-01
    z[0,3,1]  R369      3.5320740938186646e-01
    z[0,3,1]  R370      -1.2976975739002228e-01
    z[0,3,1]  R371      -4.0674397349357605e-01
    z[0,3,1]  R372      3.9426818490028381e-01
    z[0,3,1]  R373      -2.1566146612167358e-01
    z[0,3,1]  R374      -4.7013166546821594e-01
    z[0,3,1]  R375      6.7358978092670441e-02
    z[0,3,1]  R376      -2.8506958484649658e-01
    z[0,3,1]  R377      -4.1133868694305420e-01
    z[0,3,1]  R378      -5.8904796838760376e-01
    z[0,3,1]  R379      2.4392996728420258e-01
    z[0,3,1]  R380      5.4972273111343384e-01
    z[0,3,1]  R381      -3.5902017354965210e-01
    z[0,3,1]  R382      -3.7197881937026978e-01
    z[0,3,1]  R383      -4.5423364639282227e-01
    z[0,3,1]  R384      -3.7735033035278320e-01
    z[0,3,1]  R385      6.9945830106735229e-01
    z[0,3,1]  R386      -5.3554880619049072e-01
    z[0,3,1]  R387      -6.4004784822463989e-01
    z[0,3,1]  R388      6.9371879100799561e-01
    z[0,3,1]  R389      6.6736036539077759e-01
    z[0,3,1]  R390      8.4547966718673706e-01
    z[0,3,1]  R391      -3.8026013970375061e-01
    z[0,3,1]  R392      7.5764495134353638e-01
    z[0,3,1]  R393      7.7056729793548584e-01
    z[0,3,1]  R394      1.1965405195951462e-01
    z[0,3,1]  R395      -1.8582781776785851e-02
    z[0,3,1]  R396      1.0302767157554626e-01
    z[0,3,1]  R397      1.1012807488441467e-01
    z[0,3,1]  R398      5.0240254402160645e-01
    z[0,3,1]  R399      8.4660744667053223e-01
    z[0,3,1]  R400      7.1364217996597290e-01
    z[0,3,1]  R401      6.5825891494750977e-01
    z[0,3,1]  R402      5.7081985473632812e-01
    z[0,3,1]  R403      7.3875850439071655e-01
    z[0,3,1]  R404      2.4478116631507874e-01
    z[0,3,1]  R405      7.9243320226669312e-01
    z[0,3,1]  R406      2.5369012355804443e-01
    z[0,3,1]  R407      6.1081565916538239e-02
    z[0,3,1]  R408      4.7547537088394165e-01
    z[0,3,1]  R409      -1.3302671909332275e-01
    z[0,3,1]  R410      -3.9098069071769714e-01
    z[0,3,1]  R411      5.2504408359527588e-01
    z[0,3,1]  R412      -2.2248266637325287e-01
    z[0,3,1]  R413      4.5629009604454041e-01
    z[0,3,1]  R414      4.9592334777116776e-02
    z[0,3,1]  R415      -2.0216518640518188e-01
    z[0,3,1]  R416      -6.7359425127506256e-02
    z[0,3,1]  R417      -0.336232453584671
    z[0,3,1]  R418      -4.1369026899337769e-01
    z[0,3,1]  R419      4.6338456869125366e-01
    z[0,3,1]  R420      5.3795313835144043e-01
    z[0,3,1]  R421      -1.9572993740439415e-02
    z[0,3,1]  R422      5.3419023752212524e-01
    z[0,3,1]  R423      -9.6064776182174683e-02
    z[0,3,1]  R424      3.6720937490463257e-01
    z[0,3,1]  R425      3.1878709793090820e-01
    z[0,3,1]  R426      -1.5896326303482056e-01
    z[0,3,1]  R427      -3.8427191972732544e-01
    z[0,3,1]  R428      -2.2664600610733032e-01
    z[0,3,1]  R429      -5.3537720441818237e-01
    z[0,3,1]  R430      6.3431978225708008e-01
    z[0,3,1]  R431      5.9665668010711670e-01
    z[0,3,1]  R432      3.8126606494188309e-02
    z[0,3,1]  R433      -3.2695242762565613e-01
    z[0,3,1]  R434      -1.6189412772655487e-01
    z[0,3,1]  R435      1.2276873737573624e-01
    z[0,3,1]  R436      -3.9504233747720718e-02
    z[0,3,1]  R437      2.1815690398216248e-01
    z[0,3,1]  R438      5.5338263511657715e-01
    z[0,3,1]  R439      4.9680396914482117e-01
    z[0,3,1]  R440      -6.5467916429042816e-02
    z[0,3,1]  R441      -5.1626145839691162e-02
    z[0,3,1]  R442      7.7807330526411533e-03
    z[0,3,1]  R443      1.6626305878162384e-01
    z[0,3,1]  R444      4.6585938334465027e-01
    z[0,3,1]  R445      2.0342525839805603e-01
    z[0,3,1]  R446      1.8408547341823578e-01
    z[0,3,1]  R447      2.9277646541595459e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R288      -1
    z[0,3,2]  R289      1
    z[0,3,2]  R298      -4.9483129382133484e-01
    z[0,3,2]  R299      -9.7330369055271149e-02
    z[0,3,2]  R300      -3.4899190068244934e-01
    z[0,3,2]  R301      -6.0960876941680908e-01
    z[0,3,2]  R302      -4.8680838942527771e-01
    z[0,3,2]  R303      -0.672831118106842
    z[0,3,2]  R304      -3.4733718633651733e-01
    z[0,3,2]  R305      -3.2131305336952209e-01
    z[0,3,2]  R306      -5.7243376970291138e-01
    z[0,3,2]  R307      -2.1037876605987549e-01
    z[0,3,2]  R308      6.6559992730617523e-02
    z[0,3,2]  R309      1.8649429082870483e-01
    z[0,3,2]  R310      6.2250006943941116e-02
    z[0,3,2]  R311      -4.5600169897079468e-01
    z[0,3,2]  R312      1.5084241330623627e-01
    z[0,3,2]  R313      -0.618038535118103
    z[0,3,2]  R314      -0.544635534286499
    z[0,3,2]  R315      2.3024339973926544e-01
    z[0,3,2]  R316      -2.0169420540332794e-01
    z[0,3,2]  R317      -2.8154075145721436e-02
    z[0,3,2]  R318      1.1645640432834625e-01
    z[0,3,2]  R319      2.3529249429702759e-01
    z[0,3,2]  R320      2.2056996822357178e-01
    z[0,3,2]  R321      2.7665516734123230e-01
    z[0,3,2]  R322      5.1817059516906738e-01
    z[0,3,2]  R323      2.8015345335006714e-01
    z[0,3,2]  R324      2.7484706044197083e-01
    z[0,3,2]  R325      3.5513857007026672e-01
    z[0,3,2]  R326      2.9373681545257568e-01
    z[0,3,2]  R327      2.0256657898426056e-01
    z[0,3,2]  R328      1.4184066094458103e-02
    z[0,3,2]  R329      2.0424166321754456e-01
    z[0,3,2]  R330      5.2230864763259888e-01
    z[0,3,2]  R331      6.2774562835693359e-01
    z[0,3,2]  R332      3.2502561807632446e-01
    z[0,3,2]  R333      6.0212141275405884e-01
    z[0,3,2]  R334      0.392896443605423
    z[0,3,2]  R335      4.9758854508399963e-01
    z[0,3,2]  R336      6.3677805662155151e-01
    z[0,3,2]  R337      4.9808567762374878e-01
    z[0,3,2]  R338      5.3835314512252808e-01
    z[0,3,2]  R339      -2.0831923186779022e-01
    z[0,3,2]  R340      7.1620625257492065e-01
    z[0,3,2]  R341      3.1755414605140686e-01
    z[0,3,2]  R342      2.6180100440979004e-01
    z[0,3,2]  R343      4.1566711664199829e-01
    z[0,3,2]  R344      8.9760743081569672e-02
    z[0,3,2]  R345      4.5086222887039185e-01
    z[0,3,2]  R346      5.5262410640716553e-01
    z[0,3,2]  R347      6.1279457807540894e-01
    z[0,3,2]  R348      2.8982168436050415e-01
    z[0,3,2]  R349      7.5420439243316650e-01
    z[0,3,2]  R350      0.323527067899704
    z[0,3,2]  R351      0.619373619556427
    z[0,3,2]  R352      3.5451135039329529e-01
    z[0,3,2]  R353      1.9256868958473206e-01
    z[0,3,2]  R354      5.0941830873489380e-01
    z[0,3,2]  R355      -1.9011670351028442e-01
    z[0,3,2]  R356      2.1972490847110748e-01
    z[0,3,2]  R357      3.6099809408187866e-01
    z[0,3,2]  R358      -0.243872731924057
    z[0,3,2]  R359      2.8777948021888733e-01
    z[0,3,2]  R360      6.9211721420288086e-01
    z[0,3,2]  R361      5.4562073945999146e-01
    z[0,3,2]  R362      5.4034155607223511e-01
    z[0,3,2]  R363      2.1261225640773773e-01
    z[0,3,2]  R364      1.9627201557159424e-01
    z[0,3,2]  R365      -2.2901043295860291e-01
    z[0,3,2]  R366      5.6032079458236694e-01
    z[0,3,2]  R367      4.3365949392318726e-01
    z[0,3,2]  R368      -2.7679139375686646e-01
    z[0,3,2]  R369      -3.7863668799400330e-01
    z[0,3,2]  R370      -3.8496804237365723e-01
    z[0,3,2]  R371      2.0444500446319580e-01
    z[0,3,2]  R372      8.6876258254051208e-02
    z[0,3,2]  R373      -7.5554674863815308e-01
    z[0,3,2]  R374      -7.8910648822784424e-01
    z[0,3,2]  R375      -2.9234769940376282e-01
    z[0,3,2]  R376      -5.6696283817291260e-01
    z[0,3,2]  R377      -3.3386719226837158e-01
    z[0,3,2]  R378      5.8001782745122910e-02
    z[0,3,2]  R379      2.7561190724372864e-01
    z[0,3,2]  R380      4.6525120735168457e-01
    z[0,3,2]  R381      4.9158122390508652e-02
    z[0,3,2]  R382      -1.9451542198657990e-01
    z[0,3,2]  R383      0.456400066614151
    z[0,3,2]  R384      -1.8513631820678711e-01
    z[0,3,2]  R385      2.5300800800323486e-01
    z[0,3,2]  R386      1.6776071488857269e-01
    z[0,3,2]  R387      2.2591666877269745e-01
    z[0,3,2]  R388      4.1885474324226379e-01
    z[0,3,2]  R389      6.4915120601654053e-01
    z[0,3,2]  R390      3.0353426933288574e-01
    z[0,3,2]  R391      -0.142684206366539
    z[0,3,2]  R392      4.0329253673553467e-01
    z[0,3,2]  R393      5.1168125867843628e-01
    z[0,3,2]  R394      2.2234684228897095e-01
    z[0,3,2]  R395      2.4198077619075775e-01
    z[0,3,2]  R396      1.9835273921489716e-01
    z[0,3,2]  R397      2.9536345601081848e-01
    z[0,3,2]  R398      0.591578483581543
    z[0,3,2]  R399      4.2835199832916260e-01
    z[0,3,2]  R400      3.6957284808158875e-01
    z[0,3,2]  R401      3.5678908228874207e-01
    z[0,3,2]  R402      6.9865697622299194e-01
    z[0,3,2]  R403      -0.00870123878121376
    z[0,3,2]  R404      7.8830993175506592e-01
    z[0,3,2]  R405      0.0234073456376791
    z[0,3,2]  R406      0.83809494972229
    z[0,3,2]  R407      -2.3189926519989967e-02
    z[0,3,2]  R408      6.6558992862701416e-01
    z[0,3,2]  R409      -6.3357698917388916e-01
    z[0,3,2]  R410      -5.5956327915191650e-01
    z[0,3,2]  R411      3.6189684271812439e-01
    z[0,3,2]  R412      3.7515515089035034e-01
    z[0,3,2]  R413      4.3275609612464905e-01
    z[0,3,2]  R414      4.4035500288009644e-01
    z[0,3,2]  R415      0.510381281375885
    z[0,3,2]  R416      4.1040968894958496e-01
    z[0,3,2]  R417      6.4251035451889038e-01
    z[0,3,2]  R418      -4.5409896969795227e-01
    z[0,3,2]  R419      6.4309597015380859e-01
    z[0,3,2]  R420      1.8638938665390015e-01
    z[0,3,2]  R421      -1.3868586719036102e-01
    z[0,3,2]  R422      -1.0716875083744526e-02
    z[0,3,2]  R423      -4.7345027327537537e-01
    z[0,3,2]  R424      1.2176910787820816e-01
    z[0,3,2]  R425      1.8041385710239410e-01
    z[0,3,2]  R426      3.8921785354614258e-01
    z[0,3,2]  R427      5.0720632076263428e-01
    z[0,3,2]  R428      -4.7103241086006165e-02
    z[0,3,2]  R429      -6.8664395809173584e-01
    z[0,3,2]  R430      6.2752717733383179e-01
    z[0,3,2]  R431      2.5780880451202393e-01
    z[0,3,2]  R432      5.6103730201721191e-01
    z[0,3,2]  R433      4.3118435144424438e-01
    z[0,3,2]  R434      5.1037895679473877e-01
    z[0,3,2]  R435      2.1010838449001312e-02
    z[0,3,2]  R436      4.4596254825592041e-01
    z[0,3,2]  R437      1.1814925074577332e-01
    z[0,3,2]  R438      7.2799527645111084e-01
    z[0,3,2]  R439      1.6364777088165283e-01
    z[0,3,2]  R440      4.1928282380104065e-01
    z[0,3,2]  R441      3.5021528601646423e-01
    z[0,3,2]  R442      9.6968859434127808e-02
    z[0,3,2]  R443      1.0210317373275757e-01
    z[0,3,2]  R444      -4.1711616516113281e-01
    z[0,3,2]  R445      -3.4999263286590576e-01
    z[0,3,2]  R446      -5.9964990615844727e-01
    z[0,3,2]  R447      -0.438488632440567
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R290      -1
    z[0,3,3]  R291      1
    z[0,3,3]  R298      2.7465847134590149e-01
    z[0,3,3]  R299      2.1862241625785828e-01
    z[0,3,3]  R300      2.2339639067649841e-01
    z[0,3,3]  R301      2.8020879253745079e-02
    z[0,3,3]  R302      -4.3010301887989044e-02
    z[0,3,3]  R303      3.2868012785911560e-01
    z[0,3,3]  R304      7.9285115003585815e-02
    z[0,3,3]  R305      3.9583992958068848e-01
    z[0,3,3]  R306      -1.6228479146957397e-01
    z[0,3,3]  R307      -1.9534525275230408e-01
    z[0,3,3]  R308      -2.8189438581466675e-01
    z[0,3,3]  R309      -3.4203374385833740e-01
    z[0,3,3]  R310      -2.3261594772338867e-01
    z[0,3,3]  R311      -3.3128741383552551e-01
    z[0,3,3]  R312      -3.6564636230468750e-01
    z[0,3,3]  R313      -3.1601428985595703e-01
    z[0,3,3]  R314      -6.4556926488876343e-01
    z[0,3,3]  R315      -4.0185779333114624e-01
    z[0,3,3]  R316      -4.7184279561042786e-01
    z[0,3,3]  R317      -8.6596027016639709e-02
    z[0,3,3]  R318      -2.1008187532424927e-01
    z[0,3,3]  R319      0.591512143611908
    z[0,3,3]  R320      5.3625398874282837e-01
    z[0,3,3]  R321      3.1039351224899292e-01
    z[0,3,3]  R322      9.4767600297927856e-02
    z[0,3,3]  R323      3.9894381165504456e-01
    z[0,3,3]  R324      2.3887093365192413e-01
    z[0,3,3]  R325      3.5465556383132935e-01
    z[0,3,3]  R326      4.6932280063629150e-01
    z[0,3,3]  R327      4.8359695076942444e-01
    z[0,3,3]  R328      -2.9546749591827393e-01
    z[0,3,3]  R329      -9.2585608363151550e-02
    z[0,3,3]  R330      0.144478902220726
    z[0,3,3]  R331      4.9953363835811615e-02
    z[0,3,3]  R332      -4.1675353050231934e-01
    z[0,3,3]  R333      -1.9000534713268280e-01
    z[0,3,3]  R334      7.0265196263790131e-02
    z[0,3,3]  R335      -2.1355268359184265e-01
    z[0,3,3]  R336      1.0279149562120438e-01
    z[0,3,3]  R337      1.4658312499523163e-01
    z[0,3,3]  R338      -0.240363210439682
    z[0,3,3]  R339      4.0989495813846588e-02
    z[0,3,3]  R340      1.9411119818687439e-01
    z[0,3,3]  R341      4.3253910541534424e-01
    z[0,3,3]  R342      1.4697183668613434e-01
    z[0,3,3]  R343      -9.0161100029945374e-02
    z[0,3,3]  R344      1.9986793398857117e-01
    z[0,3,3]  R345      -2.5931049603968859e-03
    z[0,3,3]  R346      0.0225517675280571
    z[0,3,3]  R347      1.6422437503933907e-02
    z[0,3,3]  R348      2.7692386507987976e-01
    z[0,3,3]  R349      -1.9492456316947937e-01
    z[0,3,3]  R350      -6.0355597734451294e-01
    z[0,3,3]  R351      3.1957823038101196e-01
    z[0,3,3]  R352      4.3257674574851990e-01
    z[0,3,3]  R353      4.4370394945144653e-01
    z[0,3,3]  R354      -5.5770836770534515e-02
    z[0,3,3]  R355      0.400804340839386
    z[0,3,3]  R356      5.8853697776794434e-01
    z[0,3,3]  R357      -2.0160461962223053e-01
    z[0,3,3]  R358      -8.6898155510425568e-02
    z[0,3,3]  R359      1.8041260540485382e-02
    z[0,3,3]  R360      -6.3954539597034454e-02
    z[0,3,3]  R361      1.4463429339230061e-02
    z[0,3,3]  R362      1.4581283926963806e-01
    z[0,3,3]  R363      3.6226221919059753e-01
    z[0,3,3]  R364      3.2409176230430603e-01
    z[0,3,3]  R365      3.6512300372123718e-01
    z[0,3,3]  R366      0.624301016330719
    z[0,3,3]  R367      -1.1442262679338455e-01
    z[0,3,3]  R368      -1.8925718963146210e-01
    z[0,3,3]  R369      -2.4206961691379547e-01
    z[0,3,3]  R370      -0.221385195851326
    z[0,3,3]  R371      -7.9649955034255981e-01
    z[0,3,3]  R372      -3.4430682659149170e-01
    z[0,3,3]  R373      -3.9871323108673096e-01
    z[0,3,3]  R374      -2.5169461965560913e-01
    z[0,3,3]  R375      -4.0956640243530273e-01
    z[0,3,3]  R376      -6.7413115501403809e-01
    z[0,3,3]  R377      -3.4015771746635437e-01
    z[0,3,3]  R378      0.764613926410675
    z[0,3,3]  R379      -5.8764559030532837e-01
    z[0,3,3]  R380      -7.7875353395938873e-02
    z[0,3,3]  R381      8.4801214933395386e-01
    z[0,3,3]  R382      8.6049139499664307e-01
    z[0,3,3]  R383      5.7995426654815674e-01
    z[0,3,3]  R384      7.9041171073913574e-01
    z[0,3,3]  R385      -3.1717292964458466e-02
    z[0,3,3]  R386      6.2472563982009888e-01
    z[0,3,3]  R387      2.7844116091728210e-01
    z[0,3,3]  R388      -5.2439391613006592e-01
    z[0,3,3]  R389      1.4728824794292450e-01
    z[0,3,3]  R390      6.5796025097370148e-02
    z[0,3,3]  R391      -0.224580317735672
    z[0,3,3]  R392      3.2414516806602478e-01
    z[0,3,3]  R393      1.1617504805326462e-01
    z[0,3,3]  R394      4.1859525442123413e-01
    z[0,3,3]  R395      8.2857191562652588e-02
    z[0,3,3]  R396      2.9513800144195557e-01
    z[0,3,3]  R397      5.4498338699340820e-01
    z[0,3,3]  R398      -1.4877954125404358e-01
    z[0,3,3]  R399      -1.1835643090307713e-02
    z[0,3,3]  R400      -0.0822002962231636
    z[0,3,3]  R401      -1.2596678733825684e-01
    z[0,3,3]  R402      1.1937101930379868e-01
    z[0,3,3]  R403      -4.4053740799427032e-02
    z[0,3,3]  R404      -2.3050174117088318e-01
    z[0,3,3]  R405      -0.168934166431427
    z[0,3,3]  R406      -1.3055580854415894e-01
    z[0,3,3]  R407      -5.7930290699005127e-01
    z[0,3,3]  R408      -0.125800222158432
    z[0,3,3]  R409      -6.2831813097000122e-01
    z[0,3,3]  R410      -6.0615569353103638e-01
    z[0,3,3]  R411      4.1915714740753174e-02
    z[0,3,3]  R412      6.7114210128784180e-01
    z[0,3,3]  R413      -3.5161364078521729e-01
    z[0,3,3]  R414      4.2544767260551453e-01
    z[0,3,3]  R415      2.8327226638793945e-01
    z[0,3,3]  R416      1.6467611491680145e-01
    z[0,3,3]  R417      7.4989847838878632e-02
    z[0,3,3]  R418      -4.5076709985733032e-01
    z[0,3,3]  R419      -5.2277642488479614e-01
    z[0,3,3]  R420      -5.4149228334426880e-01
    z[0,3,3]  R421      -7.2312670946121216e-01
    z[0,3,3]  R422      -4.5369812846183777e-01
    z[0,3,3]  R423      -3.5828915238380432e-01
    z[0,3,3]  R424      -1.5464001893997192e-01
    z[0,3,3]  R425      -2.0803090929985046e-01
    z[0,3,3]  R426      -3.4947675466537476e-01
    z[0,3,3]  R427      -1.6266277059912682e-02
    z[0,3,3]  R428      -4.9394932389259338e-01
    z[0,3,3]  R429      -4.3957000970840454e-01
    z[0,3,3]  R430      -1.2109193205833435e-01
    z[0,3,3]  R431      -2.4200929701328278e-01
    z[0,3,3]  R432      -5.9272092580795288e-01
    z[0,3,3]  R433      2.7310448884963989e-01
    z[0,3,3]  R434      -2.6991853117942810e-01
    z[0,3,3]  R435      1.3952843844890594e-01
    z[0,3,3]  R436      1.7272329330444336e-01
    z[0,3,3]  R437      4.0151754021644592e-01
    z[0,3,3]  R438      -1.4502698183059692e-01
    z[0,3,3]  R439      -2.2398833185434341e-02
    z[0,3,3]  R440      1.6994623839855194e-01
    z[0,3,3]  R441      0.409463107585907
    z[0,3,3]  R442      3.1296434998512268e-01
    z[0,3,3]  R443      3.5010293126106262e-01
    z[0,3,3]  R444      0.400585800409317
    z[0,3,3]  R445      5.1017558574676514e-01
    z[0,3,3]  R446      6.4175719022750854e-01
    z[0,3,3]  R447      7.9267239570617676e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R292      -1
    z[0,3,4]  R293      1
    z[0,3,4]  R298      -2.2320783138275146e-01
    z[0,3,4]  R299      -4.0431165695190430e-01
    z[0,3,4]  R300      -7.5694218277931213e-02
    z[0,3,4]  R301      -4.6823564171791077e-01
    z[0,3,4]  R302      -1.4151379466056824e-01
    z[0,3,4]  R303      -1.6214616596698761e-01
    z[0,3,4]  R304      -6.3354140520095825e-01
    z[0,3,4]  R305      -2.5628909468650818e-01
    z[0,3,4]  R306      -1.6630516946315765e-01
    z[0,3,4]  R307      -2.2820074856281281e-01
    z[0,3,4]  R308      8.4936410188674927e-02
    z[0,3,4]  R309      6.0803145170211792e-01
    z[0,3,4]  R310      0.535810649394989
    z[0,3,4]  R311      3.4923958778381348e-01
    z[0,3,4]  R312      -1.2607812881469727e-01
    z[0,3,4]  R313      3.3863863348960876e-01
    z[0,3,4]  R314      3.9063774049282074e-02
    z[0,3,4]  R315      -3.0383935570716858e-01
    z[0,3,4]  R316      -6.3019412755966187e-01
    z[0,3,4]  R317      0.182783842086792
    z[0,3,4]  R318      -4.4336962699890137e-01
    z[0,3,4]  R319      -1.5069375932216644e-01
    z[0,3,4]  R320      -1.6082622110843658e-01
    z[0,3,4]  R321      -4.6549633145332336e-01
    z[0,3,4]  R322      -5.2558548748493195e-02
    z[0,3,4]  R323      -1.7212267220020294e-01
    z[0,3,4]  R324      -3.5822349786758423e-01
    z[0,3,4]  R325      4.1479739546775818e-01
    z[0,3,4]  R326      2.3057612776756287e-01
    z[0,3,4]  R327      -7.6729096472263336e-02
    z[0,3,4]  R328      -2.5740219280123711e-02
    z[0,3,4]  R329      -0.147491917014122
    z[0,3,4]  R330      3.0154368281364441e-01
    z[0,3,4]  R331      3.6195525527000427e-01
    z[0,3,4]  R332      1.0208228230476379e-01
    z[0,3,4]  R333      -4.4310221076011658e-01
    z[0,3,4]  R334      -3.3230370283126831e-01
    z[0,3,4]  R335      1.6288186609745026e-01
    z[0,3,4]  R336      -1.5184590220451355e-01
    z[0,3,4]  R337      1.2072016298770905e-01
    z[0,3,4]  R338      1.2923154234886169e-01
    z[0,3,4]  R339      -0.817986011505127
    z[0,3,4]  R340      -3.2437807321548462e-01
    z[0,3,4]  R341      -3.3277797698974609e-01
    z[0,3,4]  R342      -3.0150877311825752e-02
    z[0,3,4]  R343      -3.8535857200622559e-01
    z[0,3,4]  R344      1.0299303382635117e-01
    z[0,3,4]  R345      -9.6264392137527466e-02
    z[0,3,4]  R346      -1.3803568668663502e-02
    z[0,3,4]  R347      -5.8436781167984009e-01
    z[0,3,4]  R348      -1.6579884290695190e-01
    z[0,3,4]  R349      -2.1202203631401062e-01
    z[0,3,4]  R350      -2.6820358633995056e-01
    z[0,3,4]  R351      -2.0164571702480316e-01
    z[0,3,4]  R352      1.5451878309249878e-01
    z[0,3,4]  R353      1.0063663125038147e-01
    z[0,3,4]  R354      3.4109887480735779e-01
    z[0,3,4]  R355      0.134738951921463
    z[0,3,4]  R356      4.4613420963287354e-02
    z[0,3,4]  R357      3.2112199068069458e-01
    z[0,3,4]  R358      -5.4176330566406250e-01
    z[0,3,4]  R359      6.5428592264652252e-02
    z[0,3,4]  R360      1.7017661035060883e-01
    z[0,3,4]  R361      -0.142030268907547
    z[0,3,4]  R362      -1.4919550158083439e-02
    z[0,3,4]  R363      1.5047530643641949e-02
    z[0,3,4]  R364      -2.5630483031272888e-01
    z[0,3,4]  R365      -2.0106402039527893e-01
    z[0,3,4]  R366      2.6019278168678284e-01
    z[0,3,4]  R367      1.7763257026672363e-01
    z[0,3,4]  R368      -1.2922429479658604e-02
    z[0,3,4]  R369      -3.3408230543136597e-01
    z[0,3,4]  R370      -3.7047231197357178e-01
    z[0,3,4]  R371      1.0382376611232758e-01
    z[0,3,4]  R372      -5.7068582624197006e-02
    z[0,3,4]  R373      -4.5437198132276535e-02
    z[0,3,4]  R374      1.0979046672582626e-01
    z[0,3,4]  R375      6.2426459789276123e-01
    z[0,3,4]  R376      1.6458596289157867e-01
    z[0,3,4]  R377      -1.9093267619609833e-01
    z[0,3,4]  R378      1.5055269002914429e-01
    z[0,3,4]  R379      4.7900673747062683e-01
    z[0,3,4]  R380      6.8221485614776611e-01
    z[0,3,4]  R381      -2.4003732204437256e-01
    z[0,3,4]  R382      8.7532445788383484e-02
    z[0,3,4]  R383      1.3894857466220856e-01
    z[0,3,4]  R384      -2.3357519507408142e-01
    z[0,3,4]  R385      3.6047333478927612e-01
    z[0,3,4]  R386      -1.7176365852355957e-01
    z[0,3,4]  R387      3.8407412171363831e-01
    z[0,3,4]  R388      3.0290532857179642e-02
    z[0,3,4]  R389      1.6972228884696960e-01
    z[0,3,4]  R390      -2.6506516337394714e-01
    z[0,3,4]  R391      -6.5742902457714081e-02
    z[0,3,4]  R392      3.7353450059890747e-01
    z[0,3,4]  R393      -1.9902090728282928e-01
    z[0,3,4]  R394      -1.7694956064224243e-01
    z[0,3,4]  R395      -3.5701495409011841e-01
    z[0,3,4]  R396      -4.2548492550849915e-01
    z[0,3,4]  R397      -2.7885007858276367e-01
    z[0,3,4]  R398      -3.0204278230667114e-01
    z[0,3,4]  R399      -6.5034247934818268e-02
    z[0,3,4]  R400      1.4242146909236908e-01
    z[0,3,4]  R401      -3.8372558355331421e-01
    z[0,3,4]  R402      -2.7505305409431458e-01
    z[0,3,4]  R403      -3.5697260499000549e-01
    z[0,3,4]  R404      1.1379770934581757e-01
    z[0,3,4]  R405      4.8987287282943726e-01
    z[0,3,4]  R406      2.1615803241729736e-01
    z[0,3,4]  R407      3.1966876983642578e-01
    z[0,3,4]  R408      2.2724738717079163e-01
    z[0,3,4]  R409      3.7069374322891235e-01
    z[0,3,4]  R410      -4.7022711485624313e-02
    z[0,3,4]  R411      5.0512617826461792e-01
    z[0,3,4]  R412      9.9318593740463257e-02
    z[0,3,4]  R413      6.3165497779846191e-01
    z[0,3,4]  R414      0.0630766972899437
    z[0,3,4]  R415      0.0745469257235527
    z[0,3,4]  R416      4.1779968142509460e-01
    z[0,3,4]  R417      -8.4193728864192963e-02
    z[0,3,4]  R418      1.8353018164634705e-01
    z[0,3,4]  R419      1.4879144728183746e-01
    z[0,3,4]  R420      -1.8214456737041473e-01
    z[0,3,4]  R421      2.5692921876907349e-01
    z[0,3,4]  R422      5.9604948759078979e-01
    z[0,3,4]  R423      1.8044304102659225e-02
    z[0,3,4]  R424      3.6404874920845032e-01
    z[0,3,4]  R425      2.3396741598844528e-02
    z[0,3,4]  R426      -2.8300735354423523e-01
    z[0,3,4]  R427      -1.9731599092483521e-01
    z[0,3,4]  R428      -4.4487681239843369e-02
    z[0,3,4]  R429      3.2666184008121490e-02
    z[0,3,4]  R430      1.5206189453601837e-01
    z[0,3,4]  R431      9.2810891568660736e-02
    z[0,3,4]  R432      9.6238173544406891e-02
    z[0,3,4]  R433      -1.3673400878906250e-01
    z[0,3,4]  R434      -2.0141109824180603e-01
    z[0,3,4]  R435      2.3014084994792938e-01
    z[0,3,4]  R436      -2.4442131817340851e-01
    z[0,3,4]  R437      9.3896873295307159e-02
    z[0,3,4]  R438      2.7465993165969849e-01
    z[0,3,4]  R439      -1.7549371719360352e-01
    z[0,3,4]  R440      -2.2474156320095062e-01
    z[0,3,4]  R441      3.3653992414474487e-01
    z[0,3,4]  R442      2.3855890333652496e-01
    z[0,3,4]  R443      1.3736869394779205e-01
    z[0,3,4]  R444      7.3812989285215735e-04
    z[0,3,4]  R445      -5.2129936218261719e-01
    z[0,3,4]  R446      -2.2389587759971619e-01
    z[0,3,4]  R447      -2.0287160575389862e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R294      -1
    z[0,3,5]  R295      1
    z[0,3,5]  R298      -5.0905489921569824e-01
    z[0,3,5]  R299      -5.4433119297027588e-01
    z[0,3,5]  R300      -4.7511899471282959e-01
    z[0,3,5]  R301      -1.6559608280658722e-01
    z[0,3,5]  R302      -3.4410101175308228e-01
    z[0,3,5]  R303      4.9339506775140762e-02
    z[0,3,5]  R304      7.2693345136940479e-03
    z[0,3,5]  R305      -5.5108584463596344e-02
    z[0,3,5]  R306      -0.0675864890217781
    z[0,3,5]  R307      -2.6002112776041031e-02
    z[0,3,5]  R308      3.0668914318084717e-01
    z[0,3,5]  R309      2.4083366990089417e-01
    z[0,3,5]  R310      -9.9006086587905884e-02
    z[0,3,5]  R311      -2.1417747437953949e-01
    z[0,3,5]  R312      3.3189021050930023e-02
    z[0,3,5]  R313      0.00866305734962225
    z[0,3,5]  R314      2.6181730628013611e-01
    z[0,3,5]  R315      -4.9240300059318542e-01
    z[0,3,5]  R316      -1.0139561444520950e-01
    z[0,3,5]  R317      -3.2355183362960815e-01
    z[0,3,5]  R318      -2.1214015781879425e-01
    z[0,3,5]  R319      -1.0613843053579330e-01
    z[0,3,5]  R320      -1.3273153454065323e-02
    z[0,3,5]  R321      1.6257645189762115e-01
    z[0,3,5]  R322      2.8083750605583191e-01
    z[0,3,5]  R323      -0.361116498708725
    z[0,3,5]  R324      -1.5391005203127861e-02
    z[0,3,5]  R325      -3.2534605264663696e-01
    z[0,3,5]  R326      -3.1955784559249878e-01
    z[0,3,5]  R327      -3.7333497405052185e-01
    z[0,3,5]  R328      -6.0456240177154541e-01
    z[0,3,5]  R329      -4.5098894834518433e-01
    z[0,3,5]  R330      -9.0859957039356232e-02
    z[0,3,5]  R331      -3.5138934850692749e-01
    z[0,3,5]  R332      -2.0510452985763550e-01
    z[0,3,5]  R333      1.2821625173091888e-01
    z[0,3,5]  R334      6.5603062510490417e-02
    z[0,3,5]  R335      -1.5121465921401978e-01
    z[0,3,5]  R336      8.5558727383613586e-02
    z[0,3,5]  R337      -1.1811101436614990e-01
    z[0,3,5]  R338      0.0697358176112175
    z[0,3,5]  R339      -2.8930500149726868e-01
    z[0,3,5]  R340      -4.1346341371536255e-01
    z[0,3,5]  R341      -4.1267088055610657e-01
    z[0,3,5]  R342      -2.0328895747661591e-01
    z[0,3,5]  R343      -1.4351263642311096e-01
    z[0,3,5]  R344      4.5918479561805725e-02
    z[0,3,5]  R345      -1.5339544415473938e-01
    z[0,3,5]  R346      -2.5288888812065125e-01
    z[0,3,5]  R347      -1.1544585227966309e-01
    z[0,3,5]  R348      -4.1427844762802124e-01
    z[0,3,5]  R349      -0.461177259683609
    z[0,3,5]  R350      -0.315845251083374
    z[0,3,5]  R351      -4.4648941606283188e-02
    z[0,3,5]  R352      -3.1556600332260132e-01
    z[0,3,5]  R353      1.0550966858863831e-01
    z[0,3,5]  R354      4.2432162910699844e-02
    z[0,3,5]  R355      0.0781085416674614
    z[0,3,5]  R356      -4.0588015317916870e-01
    z[0,3,5]  R357      4.5679128170013428e-01
    z[0,3,5]  R358      -1.9397646188735962e-01
    z[0,3,5]  R359      -2.5300228595733643e-01
    z[0,3,5]  R360      -4.4067561626434326e-01
    z[0,3,5]  R361      -2.2717300057411194e-01
    z[0,3,5]  R362      -3.7334197759628296e-01
    z[0,3,5]  R363      4.4848173856735229e-03
    z[0,3,5]  R364      -1.7721937596797943e-01
    z[0,3,5]  R365      2.2761276364326477e-01
    z[0,3,5]  R366      3.1403505802154541e-01
    z[0,3,5]  R367      2.1357160806655884e-01
    z[0,3,5]  R368      -7.1594923734664917e-02
    z[0,3,5]  R369      1.2033394724130630e-01
    z[0,3,5]  R370      -4.3070587515830994e-01
    z[0,3,5]  R371      -2.2164934873580933e-01
    z[0,3,5]  R372      -0.824120044708252
    z[0,3,5]  R373      1.4033000171184540e-01
    z[0,3,5]  R374      -9.9121198058128357e-02
    z[0,3,5]  R375      3.9948695898056030e-01
    z[0,3,5]  R376      2.8855550289154053e-01
    z[0,3,5]  R377      0.0670010894536972
    z[0,3,5]  R378      5.5497944355010986e-02
    z[0,3,5]  R379      5.1751244068145752e-01
    z[0,3,5]  R380      -7.3180519044399261e-02
    z[0,3,5]  R381      1.2180896848440170e-01
    z[0,3,5]  R382      1.0028154402971268e-01
    z[0,3,5]  R383      -3.4219104051589966e-01
    z[0,3,5]  R384      7.0903427898883820e-02
    z[0,3,5]  R385      7.6070673763751984e-02
    z[0,3,5]  R386      -3.0782202258706093e-02
    z[0,3,5]  R387      4.3729510903358459e-01
    z[0,3,5]  R388      1.6473619639873505e-01
    z[0,3,5]  R389      -2.7248337864875793e-02
    z[0,3,5]  R390      9.6197031438350677e-02
    z[0,3,5]  R391      6.0163778066635132e-01
    z[0,3,5]  R392      -6.0983706265687943e-02
    z[0,3,5]  R393      2.5788676738739014e-01
    z[0,3,5]  R394      -0.0456160232424736
    z[0,3,5]  R395      -2.1228650212287903e-01
    z[0,3,5]  R396      -1.7278324067592621e-01
    z[0,3,5]  R397      -1.4928644895553589e-01
    z[0,3,5]  R398      -4.2609229683876038e-01
    z[0,3,5]  R399      1.2111280113458633e-01
    z[0,3,5]  R400      -2.1845720708370209e-01
    z[0,3,5]  R401      -2.6794201135635376e-01
    z[0,3,5]  R402      -2.8001922369003296e-01
    z[0,3,5]  R403      -0.5264852643013
    z[0,3,5]  R404      -2.5525093078613281e-01
    z[0,3,5]  R405      -2.4217948317527771e-02
    z[0,3,5]  R406      -2.8848379850387573e-01
    z[0,3,5]  R407      4.3418622016906738e-01
    z[0,3,5]  R408      -1.5303204953670502e-01
    z[0,3,5]  R409      -9.2712230980396271e-02
    z[0,3,5]  R410      3.8863378763198853e-01
    z[0,3,5]  R411      -3.1936866044998169e-01
    z[0,3,5]  R412      2.8483736515045166e-01
    z[0,3,5]  R413      2.1372631192207336e-01
    z[0,3,5]  R414      -2.8907996416091919e-01
    z[0,3,5]  R415      1.0884429514408112e-01
    z[0,3,5]  R416      0.0377860963344574
    z[0,3,5]  R417      -0.294871985912323
    z[0,3,5]  R418      0.430424302816391
    z[0,3,5]  R419      -1.1839371919631958e-01
    z[0,3,5]  R420      -4.5698404312133789e-01
    z[0,3,5]  R421      5.8323782682418823e-01
    z[0,3,5]  R422      -3.4498110413551331e-01
    z[0,3,5]  R423      5.0153142213821411e-01
    z[0,3,5]  R424      -6.6374707221984863e-01
    z[0,3,5]  R425      0.896765947341919
    z[0,3,5]  R426      7.0995688438415527e-01
    z[0,3,5]  R427      -4.7227197885513306e-01
    z[0,3,5]  R428      7.5401091575622559e-01
    z[0,3,5]  R429      2.3110548034310341e-02
    z[0,3,5]  R430      -4.5502327382564545e-02
    z[0,3,5]  R431      -1.5141440927982330e-01
    z[0,3,5]  R432      4.6859785914421082e-01
    z[0,3,5]  R433      -2.0513559877872467e-01
    z[0,3,5]  R434      2.1855992078781128e-01
    z[0,3,5]  R435      -1.1159786581993103e-01
    z[0,3,5]  R436      6.7691020667552948e-02
    z[0,3,5]  R437      5.2345430850982666e-01
    z[0,3,5]  R438      -1.7096638679504395e-01
    z[0,3,5]  R439      -7.6470810174942017e-01
    z[0,3,5]  R440      -1.7447984218597412e-01
    z[0,3,5]  R441      -0.0942888930439949
    z[0,3,5]  R442      8.8665008544921875e-02
    z[0,3,5]  R443      4.5969173312187195e-01
    z[0,3,5]  R444      -1.0222969204187393e-01
    z[0,3,5]  R445      4.4253578782081604e-01
    z[0,3,5]  R446      2.3229949176311493e-01
    z[0,3,5]  R447      6.2652014195919037e-02
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R296      -1
    z[0,3,6]  R297      1
    z[0,3,6]  R298      1.6963279247283936e-01
    z[0,3,6]  R299      -4.8378005623817444e-02
    z[0,3,6]  R300      -4.2930582165718079e-01
    z[0,3,6]  R301      -2.6640886440873146e-02
    z[0,3,6]  R302      -2.2289891541004181e-01
    z[0,3,6]  R303      -2.6280790567398071e-01
    z[0,3,6]  R304      -3.7124386429786682e-01
    z[0,3,6]  R305      -3.3423757553100586e-01
    z[0,3,6]  R306      1.9612808525562286e-01
    z[0,3,6]  R307      -3.2220214605331421e-01
    z[0,3,6]  R308      1.5329061448574066e-01
    z[0,3,6]  R309      -2.9133863747119904e-02
    z[0,3,6]  R310      3.9179217815399170e-01
    z[0,3,6]  R311      4.7159501910209656e-01
    z[0,3,6]  R312      6.9306629896163940e-01
    z[0,3,6]  R313      -2.4068398773670197e-01
    z[0,3,6]  R314      -8.7645635008811951e-02
    z[0,3,6]  R315      1.3628785312175751e-01
    z[0,3,6]  R316      2.0543886721134186e-01
    z[0,3,6]  R317      1.0894315782934427e-03
    z[0,3,6]  R318      -6.0778349637985229e-01
    z[0,3,6]  R319      1.7104738950729370e-01
    z[0,3,6]  R320      -2.8610643744468689e-01
    z[0,3,6]  R321      -0.148108571767807
    z[0,3,6]  R322      1.6409799456596375e-01
    z[0,3,6]  R323      1.3578611612319946e-01
    z[0,3,6]  R324      -2.7618399262428284e-01
    z[0,3,6]  R325      2.0031447708606720e-01
    z[0,3,6]  R326      -3.8839691877365112e-01
    z[0,3,6]  R327      -4.2779636383056641e-01
    z[0,3,6]  R328      -1.1489473283290863e-01
    z[0,3,6]  R329      -5.0027370452880859e-01
    z[0,3,6]  R330      3.1150346994400024e-01
    z[0,3,6]  R331      -1.1582090705633163e-01
    z[0,3,6]  R332      9.3578919768333435e-02
    z[0,3,6]  R333      -3.5544827580451965e-02
    z[0,3,6]  R334      -2.3790046572685242e-01
    z[0,3,6]  R335      -2.9069057106971741e-01
    z[0,3,6]  R336      -1.3186487555503845e-01
    z[0,3,6]  R337      -5.7730913162231445e-01
    z[0,3,6]  R338      5.2270330488681793e-02
    z[0,3,6]  R339      -0.287873238325119
    z[0,3,6]  R340      -6.1442956328392029e-02
    z[0,3,6]  R341      1.0017297416925430e-01
    z[0,3,6]  R342      -3.4044528007507324e-01
    z[0,3,6]  R343      3.5643249750137329e-02
    z[0,3,6]  R344      2.1268843114376068e-01
    z[0,3,6]  R345      -7.8744582831859589e-02
    z[0,3,6]  R346      8.1997781991958618e-02
    z[0,3,6]  R347      -1.1281748116016388e-01
    z[0,3,6]  R348      0.321675181388855
    z[0,3,6]  R349      -2.5920584797859192e-01
    z[0,3,6]  R350      -5.0701463222503662e-01
    z[0,3,6]  R351      9.7830243408679962e-02
    z[0,3,6]  R352      -4.3358799070119858e-02
    z[0,3,6]  R353      -1.4508636295795441e-01
    z[0,3,6]  R354      -4.2642485350370407e-02
    z[0,3,6]  R355      3.3857926726341248e-02
    z[0,3,6]  R356      -4.3097484111785889e-01
    z[0,3,6]  R357      -1.9725072383880615e-01
    z[0,3,6]  R358      -6.7148125171661377e-01
    z[0,3,6]  R359      -4.5034587383270264e-02
    z[0,3,6]  R360      1.9323875010013580e-01
    z[0,3,6]  R361      -3.8692843168973923e-02
    z[0,3,6]  R362      2.0327742397785187e-01
    z[0,3,6]  R363      -7.8126393258571625e-02
    z[0,3,6]  R364      -4.0910041332244873e-01
    z[0,3,6]  R365      -5.9128899127244949e-02
    z[0,3,6]  R366      8.5603788495063782e-02
    z[0,3,6]  R367      2.7015948295593262e-01
    z[0,3,6]  R368      -1.0292565822601318e-01
    z[0,3,6]  R369      4.2694514989852905e-01
    z[0,3,6]  R370      2.8673991560935974e-01
    z[0,3,6]  R371      -1.7907572910189629e-02
    z[0,3,6]  R372      -4.6501882374286652e-02
    z[0,3,6]  R373      2.7039566636085510e-01
    z[0,3,6]  R374      -2.3802092671394348e-01
    z[0,3,6]  R375      -2.8519439697265625e-01
    z[0,3,6]  R376      -1.6427727416157722e-02
    z[0,3,6]  R377      4.0089237689971924e-01
    z[0,3,6]  R378      1.4535829424858093e-02
    z[0,3,6]  R379      -1.4709062874317169e-01
    z[0,3,6]  R380      -4.9917469732463360e-03
    z[0,3,6]  R381      -1.7179638147354126e-02
    z[0,3,6]  R382      -4.5078076422214508e-02
    z[0,3,6]  R383      1.2207396328449249e-01
    z[0,3,6]  R384      -2.9277160763740540e-01
    z[0,3,6]  R385      4.7871533036231995e-01
    z[0,3,6]  R386      -4.5756044983863831e-01
    z[0,3,6]  R387      -1.9415043294429779e-01
    z[0,3,6]  R388      -8.5624635219573975e-02
    z[0,3,6]  R389      -2.2068157792091370e-01
    z[0,3,6]  R390      -2.5803956389427185e-01
    z[0,3,6]  R391      -1.2441388517618179e-01
    z[0,3,6]  R392      -1.2177091836929321e-01
    z[0,3,6]  R393      -1.4720830321311951e-01
    z[0,3,6]  R394      2.0740801095962524e-01
    z[0,3,6]  R395      -5.9064473956823349e-02
    z[0,3,6]  R396      1.2667530775070190e-01
    z[0,3,6]  R397      -1.1722601950168610e-01
    z[0,3,6]  R398      3.1874611973762512e-01
    z[0,3,6]  R399      1.7620076239109039e-01
    z[0,3,6]  R400      -4.6389183402061462e-01
    z[0,3,6]  R401      3.3987739682197571e-01
    z[0,3,6]  R402      -1.2304409593343735e-01
    z[0,3,6]  R403      -1.5102137625217438e-01
    z[0,3,6]  R404      3.6426514387130737e-01
    z[0,3,6]  R405      1.1635456979274750e-01
    z[0,3,6]  R406      -2.9351255297660828e-01
    z[0,3,6]  R407      2.3197162151336670e-01
    z[0,3,6]  R408      1.4954103529453278e-01
    z[0,3,6]  R409      1.1755497753620148e-01
    z[0,3,6]  R410      -7.6021656394004822e-02
    z[0,3,6]  R411      3.6324289441108704e-01
    z[0,3,6]  R412      -2.1538391709327698e-01
    z[0,3,6]  R413      4.4994466006755829e-02
    z[0,3,6]  R414      2.5756680965423584e-01
    z[0,3,6]  R415      -9.1338776051998138e-02
    z[0,3,6]  R416      -2.0584285259246826e-01
    z[0,3,6]  R417      -3.1190514564514160e-01
    z[0,3,6]  R418      -4.1874065995216370e-01
    z[0,3,6]  R419      2.1480417251586914e-01
    z[0,3,6]  R420      3.3693531155586243e-01
    z[0,3,6]  R421      2.6994548738002777e-02
    z[0,3,6]  R422      1.6113099455833435e-01
    z[0,3,6]  R423      2.1039338409900665e-01
    z[0,3,6]  R424      2.6457908749580383e-01
    z[0,3,6]  R425      -1.9243661314249039e-02
    z[0,3,6]  R426      -2.2608275711536407e-01
    z[0,3,6]  R427      1.1658965051174164e-01
    z[0,3,6]  R428      -3.4674385190010071e-01
    z[0,3,6]  R429      -2.0819826424121857e-01
    z[0,3,6]  R430      -3.6833170056343079e-01
    z[0,3,6]  R431      4.3919944763183594e-01
    z[0,3,6]  R432      2.0566870272159576e-01
    z[0,3,6]  R433      -2.2956621646881104e-01
    z[0,3,6]  R434      1.0010523721575737e-02
    z[0,3,6]  R435      -3.8473281264305115e-01
    z[0,3,6]  R436      -6.1834228038787842e-01
    z[0,3,6]  R437      -1.2329224497079849e-01
    z[0,3,6]  R438      -1.6788972914218903e-01
    z[0,3,6]  R439      -1.7228076234459877e-02
    z[0,3,6]  R440      -2.4053168296813965e-01
    z[0,3,6]  R441      -1.7618584632873535e-01
    z[0,3,6]  R442      -3.4975594282150269e-01
    z[0,3,6]  R443      -7.9743430018424988e-02
    z[0,3,6]  R444      -1.9918261468410492e-01
    z[0,3,6]  R445      -1.5136629343032837e-01
    z[0,3,6]  R446      2.3564919829368591e-02
    z[0,3,6]  R447      4.8643615096807480e-02
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R448      -1
    z[3,0,0]  R449      1
    z[3,0,0]  R462      -9.0111321210861206e-01
    z[3,0,0]  R463      -6.0407590866088867e-01
    z[3,0,0]  R464      -6.1722850799560547e-01
    z[3,0,0]  R465      -3.1324347853660583e-01
    z[3,0,0]  R466      1.8402388691902161e-01
    z[3,0,0]  R467      3.5888195037841797e-01
    z[3,0,0]  R468      1.2001663446426392e-01
    z[3,0,0]  R469      3.3409410715103149e-01
    z[3,0,0]  R470      1.7947991192340851e-01
    z[3,0,0]  R471      6.3400840759277344e-01
    z[3,0,0]  R472      -1.9765214622020721e-01
    z[3,0,0]  R473      -1.7510922625660896e-02
    z[3,0,0]  R474      6.6964410245418549e-02
    z[3,0,0]  R475      -2.7715164422988892e-01
    z[3,0,0]  R476      -2.5218993425369263e-01
    z[3,0,0]  R477      -3.1260257959365845e-01
    z[3,0,0]  R478      -2.3082602024078369e-01
    z[3,0,0]  R479      2.8432890772819519e-01
    z[3,0,0]  R480      -2.3441386222839355e-01
    z[3,0,0]  R481      -2.9212430119514465e-01
    z[3,0,0]  R482      1.8149070441722870e-01
    z[3,0,0]  R483      1.8245698511600494e-01
    z[3,0,0]  R484      2.0640777051448822e-01
    z[3,0,0]  R485      6.3469523191452026e-01
    z[3,0,0]  R486      1.3563279062509537e-02
    z[3,0,0]  R487      -5.5913887917995453e-02
    z[3,0,0]  R488      8.2741332054138184e-01
    z[3,0,0]  R489      8.7075871229171753e-01
    z[3,0,0]  R490      7.9749417304992676e-01
    z[3,0,0]  R491      6.9988548755645752e-01
    z[3,0,0]  R492      3.3281859010457993e-02
    z[3,0,0]  R493      2.2290296852588654e-01
    z[3,0,0]  R494      2.5331950187683105e-01
    z[3,0,0]  R495      2.9828539490699768e-01
    z[3,0,0]  R496      -5.0881292670965195e-02
    z[3,0,0]  R497      1.5746654570102692e-01
    z[3,0,0]  R498      2.3393720388412476e-01
    z[3,0,0]  R499      2.9809838533401489e-01
    z[3,0,0]  R500      -0.00982271321117878
    z[3,0,0]  R501      5.6180328130722046e-01
    z[3,0,0]  R502      4.6654570102691650e-01
    z[3,0,0]  R503      1.6208623349666595e-01
    z[3,0,0]  R504      8.7015196681022644e-02
    z[3,0,0]  R505      3.2016941905021667e-01
    z[3,0,0]  R506      -4.7110697627067566e-01
    z[3,0,0]  R507      1.8492648005485535e-01
    z[3,0,0]  R508      6.8464279174804688e-01
    z[3,0,0]  R509      7.6983755826950073e-01
    z[3,0,0]  R510      0.762596070766449
    z[3,0,0]  R511      5.2648055553436279e-01
    z[3,0,0]  R512      1.5865485370159149e-01
    z[3,0,0]  R513      -1.2692667543888092e-01
    z[3,0,0]  R514      1.6466620564460754e-01
    z[3,0,0]  R515      2.2486260533332825e-01
    z[3,0,0]  R516      9.1835662722587585e-02
    z[3,0,0]  R517      5.8491063117980957e-01
    z[3,0,0]  R518      4.2816135287284851e-01
    z[3,0,0]  R519      1.3206787407398224e-01
    z[3,0,0]  R520      -2.5663343071937561e-01
    z[3,0,0]  R521      5.6501740217208862e-01
    z[3,0,0]  R522      -1.0809303820133209e-01
    z[3,0,0]  R523      6.1006840318441391e-02
    z[3,0,0]  R524      -1.6829517483711243e-01
    z[3,0,0]  R525      5.4270672798156738e-01
    z[3,0,0]  R526      2.4762864410877228e-01
    z[3,0,0]  R527      7.2049885988235474e-01
    z[3,0,0]  R528      7.4297547340393066e-01
    z[3,0,0]  R529      8.6693710088729858e-01
    z[3,0,0]  R530      5.6837695837020874e-01
    z[3,0,0]  R531      6.9224995374679565e-01
    z[3,0,0]  R532      9.9514469504356384e-02
    z[3,0,0]  R533      3.3170798420906067e-01
    z[3,0,0]  R534      0.807605504989624
    z[3,0,0]  R535      7.4419957399368286e-01
    z[3,0,0]  R536      8.3993387222290039e-01
    z[3,0,0]  R537      7.7641081809997559e-01
    z[3,0,0]  R538      6.3118547201156616e-01
    z[3,0,0]  R539      2.9213285446166992e-01
    z[3,0,0]  R540      3.0005431175231934e-01
    z[3,0,0]  R541      2.1501564979553223e-01
    z[3,0,0]  R542      -4.5205074548721313e-01
    z[3,0,0]  R543      -5.8820670843124390e-01
    z[3,0,0]  R544      -4.5692503452301025e-01
    z[3,0,0]  R545      -0.575303316116333
    z[3,0,0]  R546      -6.6564100980758667e-01
    z[3,0,0]  R547      -4.7894108295440674e-01
    z[3,0,0]  R548      -3.1326249241828918e-01
    z[3,0,0]  R549      -7.2099554538726807e-01
    z[3,0,0]  R550      -4.6623095870018005e-01
    z[3,0,0]  R551      -6.5349000692367554e-01
    z[3,0,0]  R552      -0.733890950679779
    z[3,0,0]  R553      -0.615653395652771
    z[3,0,0]  R554      -6.5118718147277832e-01
    z[3,0,0]  R555      -4.8438054323196411e-01
    z[3,0,0]  R556      -5.7601153850555420e-01
    z[3,0,0]  R557      -4.7619366645812988e-01
    z[3,0,0]  R558      2.0817232131958008e-01
    z[3,0,0]  R559      2.8128352761268616e-01
    z[3,0,0]  R560      -4.5916289091110229e-03
    z[3,0,0]  R561      2.1172988414764404e-01
    z[3,0,0]  R562      -2.9712429642677307e-01
    z[3,0,0]  R563      7.1658569574356079e-01
    z[3,0,0]  R564      7.2071969509124756e-01
    z[3,0,0]  R565      7.4970632791519165e-01
    z[3,0,0]  R566      7.8108614683151245e-01
    z[3,0,0]  R567      7.1166193485260010e-01
    z[3,0,0]  R568      6.8975126743316650e-01
    z[3,0,0]  R569      6.5204966068267822e-01
    z[3,0,0]  R570      6.1901992559432983e-01
    z[3,0,0]  R571      6.2065553665161133e-01
    z[3,0,0]  R572      -4.4455844163894653e-01
    z[3,0,0]  R573      2.2149392962455750e-01
    z[3,0,0]  R574      3.6230584979057312e-01
    z[3,0,0]  R575      4.1651627421379089e-01
    z[3,0,0]  R576      7.0132118463516235e-01
    z[3,0,0]  R577      2.6808470487594604e-01
    z[3,0,0]  R578      3.4836953878402710e-01
    z[3,0,0]  R579      6.3359832763671875e-01
    z[3,0,0]  R580      3.8972038030624390e-01
    z[3,0,0]  R581      1.3161903619766235e-01
    z[3,0,0]  R582      4.5193210244178772e-01
    z[3,0,0]  R583      -3.4268078207969666e-01
    z[3,0,0]  R584      -9.8319277167320251e-02
    z[3,0,0]  R585      6.4859133958816528e-01
    z[3,0,0]  R586      8.6352986097335815e-01
    z[3,0,0]  R587      7.9342055320739746e-01
    z[3,0,0]  R588      9.4148766994476318e-01
    z[3,0,0]  R589      7.8157550096511841e-01
    z[3,0,0]  R590      6.8550151586532593e-01
    z[3,0,0]  R591      5.0662785768508911e-01
    z[3,0,0]  R592      2.2607669234275818e-01
    z[3,0,0]  R593      9.1934822499752045e-02
    z[3,0,0]  R594      1.1354370415210724e-01
    z[3,0,0]  R595      6.7248874902725220e-01
    z[3,0,0]  R596      7.4956321716308594e-01
    z[3,0,0]  R597      8.3836203813552856e-01
    z[3,0,0]  R598      7.7884489297866821e-01
    z[3,0,0]  R599      8.1881231069564819e-01
    z[3,0,0]  R600      -3.3339992165565491e-01
    z[3,0,0]  R601      4.8978051543235779e-01
    z[3,0,0]  R602      -3.8395929336547852e-01
    z[3,0,0]  R603      4.7120350599288940e-01
    z[3,0,0]  R604      0.426010400056839
    z[3,0,0]  R605      7.9224973917007446e-01
    z[3,0,0]  R606      7.0684427022933960e-01
    z[3,0,0]  R607      0.902255117893219
    z[3,0,0]  R608      7.2838443517684937e-01
    z[3,0,0]  R609      7.7335160970687866e-01
    z[3,0,0]  R610      -6.5417215228080750e-02
    z[3,0,0]  R611      5.6293249130249023e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R450      -1
    z[3,0,1]  R451      1
    z[3,0,1]  R462      2.4428819119930267e-01
    z[3,0,1]  R463      3.5320740938186646e-01
    z[3,0,1]  R464      -1.2976975739002228e-01
    z[3,0,1]  R465      -4.0674397349357605e-01
    z[3,0,1]  R466      3.9426818490028381e-01
    z[3,0,1]  R467      -2.1566146612167358e-01
    z[3,0,1]  R468      -4.7013166546821594e-01
    z[3,0,1]  R469      6.7358978092670441e-02
    z[3,0,1]  R470      -2.8506958484649658e-01
    z[3,0,1]  R471      -4.1133868694305420e-01
    z[3,0,1]  R472      -5.8904796838760376e-01
    z[3,0,1]  R473      2.4392996728420258e-01
    z[3,0,1]  R474      5.4972273111343384e-01
    z[3,0,1]  R475      -3.5902017354965210e-01
    z[3,0,1]  R476      -3.7197881937026978e-01
    z[3,0,1]  R477      -4.5423364639282227e-01
    z[3,0,1]  R478      -3.7735033035278320e-01
    z[3,0,1]  R479      6.9945830106735229e-01
    z[3,0,1]  R480      -5.3554880619049072e-01
    z[3,0,1]  R481      -6.4004784822463989e-01
    z[3,0,1]  R482      6.9371879100799561e-01
    z[3,0,1]  R483      6.6736036539077759e-01
    z[3,0,1]  R484      8.4547966718673706e-01
    z[3,0,1]  R485      -3.8026013970375061e-01
    z[3,0,1]  R486      7.5764495134353638e-01
    z[3,0,1]  R487      7.7056729793548584e-01
    z[3,0,1]  R488      1.1965405195951462e-01
    z[3,0,1]  R489      -1.8582781776785851e-02
    z[3,0,1]  R490      1.0302767157554626e-01
    z[3,0,1]  R491      1.1012807488441467e-01
    z[3,0,1]  R492      5.0240254402160645e-01
    z[3,0,1]  R493      8.4660744667053223e-01
    z[3,0,1]  R494      7.1364217996597290e-01
    z[3,0,1]  R495      6.5825891494750977e-01
    z[3,0,1]  R496      5.7081985473632812e-01
    z[3,0,1]  R497      7.3875850439071655e-01
    z[3,0,1]  R498      2.4478116631507874e-01
    z[3,0,1]  R499      7.9243320226669312e-01
    z[3,0,1]  R500      2.5369012355804443e-01
    z[3,0,1]  R501      6.1081565916538239e-02
    z[3,0,1]  R502      4.7547537088394165e-01
    z[3,0,1]  R503      -1.3302671909332275e-01
    z[3,0,1]  R504      -3.9098069071769714e-01
    z[3,0,1]  R505      5.2504408359527588e-01
    z[3,0,1]  R506      -2.2248266637325287e-01
    z[3,0,1]  R507      4.5629009604454041e-01
    z[3,0,1]  R508      4.9592334777116776e-02
    z[3,0,1]  R509      -2.0216518640518188e-01
    z[3,0,1]  R510      -6.7359425127506256e-02
    z[3,0,1]  R511      -0.336232453584671
    z[3,0,1]  R512      -4.1369026899337769e-01
    z[3,0,1]  R513      4.6338456869125366e-01
    z[3,0,1]  R514      5.3795313835144043e-01
    z[3,0,1]  R515      -1.9572993740439415e-02
    z[3,0,1]  R516      5.3419023752212524e-01
    z[3,0,1]  R517      -9.6064776182174683e-02
    z[3,0,1]  R518      3.6720937490463257e-01
    z[3,0,1]  R519      3.1878709793090820e-01
    z[3,0,1]  R520      -1.5896326303482056e-01
    z[3,0,1]  R521      -3.8427191972732544e-01
    z[3,0,1]  R522      -2.2664600610733032e-01
    z[3,0,1]  R523      -5.3537720441818237e-01
    z[3,0,1]  R524      6.3431978225708008e-01
    z[3,0,1]  R525      5.9665668010711670e-01
    z[3,0,1]  R526      3.8126606494188309e-02
    z[3,0,1]  R527      -3.2695242762565613e-01
    z[3,0,1]  R528      -1.6189412772655487e-01
    z[3,0,1]  R529      1.2276873737573624e-01
    z[3,0,1]  R530      -3.9504233747720718e-02
    z[3,0,1]  R531      2.1815690398216248e-01
    z[3,0,1]  R532      5.5338263511657715e-01
    z[3,0,1]  R533      4.9680396914482117e-01
    z[3,0,1]  R534      -6.5467916429042816e-02
    z[3,0,1]  R535      -5.1626145839691162e-02
    z[3,0,1]  R536      7.7807330526411533e-03
    z[3,0,1]  R537      1.6626305878162384e-01
    z[3,0,1]  R538      4.6585938334465027e-01
    z[3,0,1]  R539      2.0342525839805603e-01
    z[3,0,1]  R540      1.8408547341823578e-01
    z[3,0,1]  R541      2.9277646541595459e-01
    z[3,0,1]  R542      -3.7097299098968506e-01
    z[3,0,1]  R543      -3.6693203449249268e-01
    z[3,0,1]  R544      -4.5138341188430786e-01
    z[3,0,1]  R545      -2.2190444171428680e-01
    z[3,0,1]  R546      -3.6051931977272034e-01
    z[3,0,1]  R547      -3.3479732275009155e-01
    z[3,0,1]  R548      -4.8547694087028503e-01
    z[3,0,1]  R549      -1.9949507713317871e-01
    z[3,0,1]  R550      -5.9826439619064331e-01
    z[3,0,1]  R551      -0.577897846698761
    z[3,0,1]  R552      5.0273150205612183e-01
    z[3,0,1]  R553      2.0162308216094971e-01
    z[3,0,1]  R554      2.5994935631752014e-01
    z[3,0,1]  R555      2.3967595398426056e-01
    z[3,0,1]  R556      1.2009112536907196e-01
    z[3,0,1]  R557      0.344561904668808
    z[3,0,1]  R558      -4.0684238076210022e-01
    z[3,0,1]  R559      5.9415864944458008e-01
    z[3,0,1]  R560      -0.535753607749939
    z[3,0,1]  R561      8.9932310581207275e-01
    z[3,0,1]  R562      -0.492990642786026
    z[3,0,1]  R563      1.3425578176975250e-01
    z[3,0,1]  R564      1.9090722501277924e-01
    z[3,0,1]  R565      2.0522850099951029e-03
    z[3,0,1]  R566      -6.2149807810783386e-02
    z[3,0,1]  R567      -2.7825522422790527e-01
    z[3,0,1]  R568      4.3220886588096619e-01
    z[3,0,1]  R569      -6.9961018860340118e-02
    z[3,0,1]  R570      6.4299218356609344e-02
    z[3,0,1]  R571      -1.0775623470544815e-01
    z[3,0,1]  R572      -5.7922917604446411e-01
    z[3,0,1]  R573      6.5210044384002686e-01
    z[3,0,1]  R574      6.1549621820449829e-01
    z[3,0,1]  R575      4.0255889296531677e-01
    z[3,0,1]  R576      4.0936276316642761e-01
    z[3,0,1]  R577      5.6163680553436279e-01
    z[3,0,1]  R578      7.4027538299560547e-01
    z[3,0,1]  R579      4.1407313942909241e-01
    z[3,0,1]  R580      6.1991912126541138e-01
    z[3,0,1]  R581      5.9269815683364868e-01
    z[3,0,1]  R582      6.5104746818542480e-01
    z[3,0,1]  R583      4.2700815945863724e-02
    z[3,0,1]  R584      3.9969280362129211e-01
    z[3,0,1]  R585      1.8041059374809265e-02
    z[3,0,1]  R586      -7.7699266374111176e-02
    z[3,0,1]  R587      -1.3859303295612335e-01
    z[3,0,1]  R588      -8.7431944906711578e-02
    z[3,0,1]  R589      -3.8322117924690247e-01
    z[3,0,1]  R590      -3.9155939221382141e-01
    z[3,0,1]  R591      -4.6986032975837588e-04
    z[3,0,1]  R592      6.9686084985733032e-01
    z[3,0,1]  R593      2.4475000798702240e-01
    z[3,0,1]  R594      2.9900339245796204e-01
    z[3,0,1]  R595      -9.8890945315361023e-02
    z[3,0,1]  R596      -4.0146824903786182e-03
    z[3,0,1]  R597      -1.4451023936271667e-01
    z[3,0,1]  R598      -1.0399951785802841e-01
    z[3,0,1]  R599      3.2765230536460876e-01
    z[3,0,1]  R600      3.7645879387855530e-01
    z[3,0,1]  R601      -4.8832911252975464e-01
    z[3,0,1]  R602      -5.9402313083410263e-02
    z[3,0,1]  R603      0.790256679058075
    z[3,0,1]  R604      2.7368307113647461e-01
    z[3,0,1]  R605      -3.3937498927116394e-02
    z[3,0,1]  R606      7.8817538917064667e-02
    z[3,0,1]  R607      -5.6102149188518524e-02
    z[3,0,1]  R608      2.4786278605461121e-01
    z[3,0,1]  R609      3.4703928232192993e-01
    z[3,0,1]  R610      -3.4403938055038452e-01
    z[3,0,1]  R611      -5.7602214813232422e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R452      -1
    z[3,0,2]  R453      1
    z[3,0,2]  R462      -2.7679139375686646e-01
    z[3,0,2]  R463      -3.7863668799400330e-01
    z[3,0,2]  R464      -3.8496804237365723e-01
    z[3,0,2]  R465      2.0444500446319580e-01
    z[3,0,2]  R466      8.6876258254051208e-02
    z[3,0,2]  R467      -7.5554674863815308e-01
    z[3,0,2]  R468      -7.8910648822784424e-01
    z[3,0,2]  R469      -2.9234769940376282e-01
    z[3,0,2]  R470      -5.6696283817291260e-01
    z[3,0,2]  R471      -3.3386719226837158e-01
    z[3,0,2]  R472      5.8001782745122910e-02
    z[3,0,2]  R473      2.7561190724372864e-01
    z[3,0,2]  R474      4.6525120735168457e-01
    z[3,0,2]  R475      4.9158122390508652e-02
    z[3,0,2]  R476      -1.9451542198657990e-01
    z[3,0,2]  R477      0.456400066614151
    z[3,0,2]  R478      -1.8513631820678711e-01
    z[3,0,2]  R479      2.5300800800323486e-01
    z[3,0,2]  R480      1.6776071488857269e-01
    z[3,0,2]  R481      2.2591666877269745e-01
    z[3,0,2]  R482      4.1885474324226379e-01
    z[3,0,2]  R483      6.4915120601654053e-01
    z[3,0,2]  R484      3.0353426933288574e-01
    z[3,0,2]  R485      -0.142684206366539
    z[3,0,2]  R486      4.0329253673553467e-01
    z[3,0,2]  R487      5.1168125867843628e-01
    z[3,0,2]  R488      2.2234684228897095e-01
    z[3,0,2]  R489      2.4198077619075775e-01
    z[3,0,2]  R490      1.9835273921489716e-01
    z[3,0,2]  R491      2.9536345601081848e-01
    z[3,0,2]  R492      0.591578483581543
    z[3,0,2]  R493      4.2835199832916260e-01
    z[3,0,2]  R494      3.6957284808158875e-01
    z[3,0,2]  R495      3.5678908228874207e-01
    z[3,0,2]  R496      6.9865697622299194e-01
    z[3,0,2]  R497      -0.00870123878121376
    z[3,0,2]  R498      7.8830993175506592e-01
    z[3,0,2]  R499      0.0234073456376791
    z[3,0,2]  R500      0.83809494972229
    z[3,0,2]  R501      -2.3189926519989967e-02
    z[3,0,2]  R502      6.6558992862701416e-01
    z[3,0,2]  R503      -6.3357698917388916e-01
    z[3,0,2]  R504      -5.5956327915191650e-01
    z[3,0,2]  R505      3.6189684271812439e-01
    z[3,0,2]  R506      3.7515515089035034e-01
    z[3,0,2]  R507      4.3275609612464905e-01
    z[3,0,2]  R508      4.4035500288009644e-01
    z[3,0,2]  R509      0.510381281375885
    z[3,0,2]  R510      4.1040968894958496e-01
    z[3,0,2]  R511      6.4251035451889038e-01
    z[3,0,2]  R512      -4.5409896969795227e-01
    z[3,0,2]  R513      6.4309597015380859e-01
    z[3,0,2]  R514      1.8638938665390015e-01
    z[3,0,2]  R515      -1.3868586719036102e-01
    z[3,0,2]  R516      -1.0716875083744526e-02
    z[3,0,2]  R517      -4.7345027327537537e-01
    z[3,0,2]  R518      1.2176910787820816e-01
    z[3,0,2]  R519      1.8041385710239410e-01
    z[3,0,2]  R520      3.8921785354614258e-01
    z[3,0,2]  R521      5.0720632076263428e-01
    z[3,0,2]  R522      -4.7103241086006165e-02
    z[3,0,2]  R523      -6.8664395809173584e-01
    z[3,0,2]  R524      6.2752717733383179e-01
    z[3,0,2]  R525      2.5780880451202393e-01
    z[3,0,2]  R526      5.6103730201721191e-01
    z[3,0,2]  R527      4.3118435144424438e-01
    z[3,0,2]  R528      5.1037895679473877e-01
    z[3,0,2]  R529      2.1010838449001312e-02
    z[3,0,2]  R530      4.4596254825592041e-01
    z[3,0,2]  R531      1.1814925074577332e-01
    z[3,0,2]  R532      7.2799527645111084e-01
    z[3,0,2]  R533      1.6364777088165283e-01
    z[3,0,2]  R534      4.1928282380104065e-01
    z[3,0,2]  R535      3.5021528601646423e-01
    z[3,0,2]  R536      9.6968859434127808e-02
    z[3,0,2]  R537      1.0210317373275757e-01
    z[3,0,2]  R538      -4.1711616516113281e-01
    z[3,0,2]  R539      -3.4999263286590576e-01
    z[3,0,2]  R540      -5.9964990615844727e-01
    z[3,0,2]  R541      -0.438488632440567
    z[3,0,2]  R542      -4.9483129382133484e-01
    z[3,0,2]  R543      -9.7330369055271149e-02
    z[3,0,2]  R544      -3.4899190068244934e-01
    z[3,0,2]  R545      -6.0960876941680908e-01
    z[3,0,2]  R546      -4.8680838942527771e-01
    z[3,0,2]  R547      -0.672831118106842
    z[3,0,2]  R548      -3.4733718633651733e-01
    z[3,0,2]  R549      -3.2131305336952209e-01
    z[3,0,2]  R550      -5.7243376970291138e-01
    z[3,0,2]  R551      -2.1037876605987549e-01
    z[3,0,2]  R552      6.6559992730617523e-02
    z[3,0,2]  R553      1.8649429082870483e-01
    z[3,0,2]  R554      6.2250006943941116e-02
    z[3,0,2]  R555      -4.5600169897079468e-01
    z[3,0,2]  R556      1.5084241330623627e-01
    z[3,0,2]  R557      -0.618038535118103
    z[3,0,2]  R558      -0.544635534286499
    z[3,0,2]  R559      2.3024339973926544e-01
    z[3,0,2]  R560      -2.0169420540332794e-01
    z[3,0,2]  R561      -2.8154075145721436e-02
    z[3,0,2]  R562      1.1645640432834625e-01
    z[3,0,2]  R563      2.3529249429702759e-01
    z[3,0,2]  R564      2.2056996822357178e-01
    z[3,0,2]  R565      2.7665516734123230e-01
    z[3,0,2]  R566      5.1817059516906738e-01
    z[3,0,2]  R567      2.8015345335006714e-01
    z[3,0,2]  R568      2.7484706044197083e-01
    z[3,0,2]  R569      3.5513857007026672e-01
    z[3,0,2]  R570      2.9373681545257568e-01
    z[3,0,2]  R571      2.0256657898426056e-01
    z[3,0,2]  R572      1.4184066094458103e-02
    z[3,0,2]  R573      2.0424166321754456e-01
    z[3,0,2]  R574      5.2230864763259888e-01
    z[3,0,2]  R575      6.2774562835693359e-01
    z[3,0,2]  R576      3.2502561807632446e-01
    z[3,0,2]  R577      6.0212141275405884e-01
    z[3,0,2]  R578      0.392896443605423
    z[3,0,2]  R579      4.9758854508399963e-01
    z[3,0,2]  R580      6.3677805662155151e-01
    z[3,0,2]  R581      4.9808567762374878e-01
    z[3,0,2]  R582      5.3835314512252808e-01
    z[3,0,2]  R583      -2.0831923186779022e-01
    z[3,0,2]  R584      7.1620625257492065e-01
    z[3,0,2]  R585      3.1755414605140686e-01
    z[3,0,2]  R586      2.6180100440979004e-01
    z[3,0,2]  R587      4.1566711664199829e-01
    z[3,0,2]  R588      8.9760743081569672e-02
    z[3,0,2]  R589      4.5086222887039185e-01
    z[3,0,2]  R590      5.5262410640716553e-01
    z[3,0,2]  R591      6.1279457807540894e-01
    z[3,0,2]  R592      2.8982168436050415e-01
    z[3,0,2]  R593      7.5420439243316650e-01
    z[3,0,2]  R594      0.323527067899704
    z[3,0,2]  R595      0.619373619556427
    z[3,0,2]  R596      3.5451135039329529e-01
    z[3,0,2]  R597      1.9256868958473206e-01
    z[3,0,2]  R598      5.0941830873489380e-01
    z[3,0,2]  R599      -1.9011670351028442e-01
    z[3,0,2]  R600      2.1972490847110748e-01
    z[3,0,2]  R601      3.6099809408187866e-01
    z[3,0,2]  R602      -0.243872731924057
    z[3,0,2]  R603      2.8777948021888733e-01
    z[3,0,2]  R604      6.9211721420288086e-01
    z[3,0,2]  R605      5.4562073945999146e-01
    z[3,0,2]  R606      5.4034155607223511e-01
    z[3,0,2]  R607      2.1261225640773773e-01
    z[3,0,2]  R608      1.9627201557159424e-01
    z[3,0,2]  R609      -2.2901043295860291e-01
    z[3,0,2]  R610      5.6032079458236694e-01
    z[3,0,2]  R611      4.3365949392318726e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R454      -1
    z[3,0,3]  R455      1
    z[3,0,3]  R462      -1.8925718963146210e-01
    z[3,0,3]  R463      -2.4206961691379547e-01
    z[3,0,3]  R464      -0.221385195851326
    z[3,0,3]  R465      -7.9649955034255981e-01
    z[3,0,3]  R466      -3.4430682659149170e-01
    z[3,0,3]  R467      -3.9871323108673096e-01
    z[3,0,3]  R468      -2.5169461965560913e-01
    z[3,0,3]  R469      -4.0956640243530273e-01
    z[3,0,3]  R470      -6.7413115501403809e-01
    z[3,0,3]  R471      -3.4015771746635437e-01
    z[3,0,3]  R472      0.764613926410675
    z[3,0,3]  R473      -5.8764559030532837e-01
    z[3,0,3]  R474      -7.7875353395938873e-02
    z[3,0,3]  R475      8.4801214933395386e-01
    z[3,0,3]  R476      8.6049139499664307e-01
    z[3,0,3]  R477      5.7995426654815674e-01
    z[3,0,3]  R478      7.9041171073913574e-01
    z[3,0,3]  R479      -3.1717292964458466e-02
    z[3,0,3]  R480      6.2472563982009888e-01
    z[3,0,3]  R481      2.7844116091728210e-01
    z[3,0,3]  R482      -5.2439391613006592e-01
    z[3,0,3]  R483      1.4728824794292450e-01
    z[3,0,3]  R484      6.5796025097370148e-02
    z[3,0,3]  R485      -0.224580317735672
    z[3,0,3]  R486      3.2414516806602478e-01
    z[3,0,3]  R487      1.1617504805326462e-01
    z[3,0,3]  R488      4.1859525442123413e-01
    z[3,0,3]  R489      8.2857191562652588e-02
    z[3,0,3]  R490      2.9513800144195557e-01
    z[3,0,3]  R491      5.4498338699340820e-01
    z[3,0,3]  R492      -1.4877954125404358e-01
    z[3,0,3]  R493      -1.1835643090307713e-02
    z[3,0,3]  R494      -0.0822002962231636
    z[3,0,3]  R495      -1.2596678733825684e-01
    z[3,0,3]  R496      1.1937101930379868e-01
    z[3,0,3]  R497      -4.4053740799427032e-02
    z[3,0,3]  R498      -2.3050174117088318e-01
    z[3,0,3]  R499      -0.168934166431427
    z[3,0,3]  R500      -1.3055580854415894e-01
    z[3,0,3]  R501      -5.7930290699005127e-01
    z[3,0,3]  R502      -0.125800222158432
    z[3,0,3]  R503      -6.2831813097000122e-01
    z[3,0,3]  R504      -6.0615569353103638e-01
    z[3,0,3]  R505      4.1915714740753174e-02
    z[3,0,3]  R506      6.7114210128784180e-01
    z[3,0,3]  R507      -3.5161364078521729e-01
    z[3,0,3]  R508      4.2544767260551453e-01
    z[3,0,3]  R509      2.8327226638793945e-01
    z[3,0,3]  R510      1.6467611491680145e-01
    z[3,0,3]  R511      7.4989847838878632e-02
    z[3,0,3]  R512      -4.5076709985733032e-01
    z[3,0,3]  R513      -5.2277642488479614e-01
    z[3,0,3]  R514      -5.4149228334426880e-01
    z[3,0,3]  R515      -7.2312670946121216e-01
    z[3,0,3]  R516      -4.5369812846183777e-01
    z[3,0,3]  R517      -3.5828915238380432e-01
    z[3,0,3]  R518      -1.5464001893997192e-01
    z[3,0,3]  R519      -2.0803090929985046e-01
    z[3,0,3]  R520      -3.4947675466537476e-01
    z[3,0,3]  R521      -1.6266277059912682e-02
    z[3,0,3]  R522      -4.9394932389259338e-01
    z[3,0,3]  R523      -4.3957000970840454e-01
    z[3,0,3]  R524      -1.2109193205833435e-01
    z[3,0,3]  R525      -2.4200929701328278e-01
    z[3,0,3]  R526      -5.9272092580795288e-01
    z[3,0,3]  R527      2.7310448884963989e-01
    z[3,0,3]  R528      -2.6991853117942810e-01
    z[3,0,3]  R529      1.3952843844890594e-01
    z[3,0,3]  R530      1.7272329330444336e-01
    z[3,0,3]  R531      4.0151754021644592e-01
    z[3,0,3]  R532      -1.4502698183059692e-01
    z[3,0,3]  R533      -2.2398833185434341e-02
    z[3,0,3]  R534      1.6994623839855194e-01
    z[3,0,3]  R535      0.409463107585907
    z[3,0,3]  R536      3.1296434998512268e-01
    z[3,0,3]  R537      3.5010293126106262e-01
    z[3,0,3]  R538      0.400585800409317
    z[3,0,3]  R539      5.1017558574676514e-01
    z[3,0,3]  R540      6.4175719022750854e-01
    z[3,0,3]  R541      7.9267239570617676e-01
    z[3,0,3]  R542      2.7465847134590149e-01
    z[3,0,3]  R543      2.1862241625785828e-01
    z[3,0,3]  R544      2.2339639067649841e-01
    z[3,0,3]  R545      2.8020879253745079e-02
    z[3,0,3]  R546      -4.3010301887989044e-02
    z[3,0,3]  R547      3.2868012785911560e-01
    z[3,0,3]  R548      7.9285115003585815e-02
    z[3,0,3]  R549      3.9583992958068848e-01
    z[3,0,3]  R550      -1.6228479146957397e-01
    z[3,0,3]  R551      -1.9534525275230408e-01
    z[3,0,3]  R552      -2.8189438581466675e-01
    z[3,0,3]  R553      -3.4203374385833740e-01
    z[3,0,3]  R554      -2.3261594772338867e-01
    z[3,0,3]  R555      -3.3128741383552551e-01
    z[3,0,3]  R556      -3.6564636230468750e-01
    z[3,0,3]  R557      -3.1601428985595703e-01
    z[3,0,3]  R558      -6.4556926488876343e-01
    z[3,0,3]  R559      -4.0185779333114624e-01
    z[3,0,3]  R560      -4.7184279561042786e-01
    z[3,0,3]  R561      -8.6596027016639709e-02
    z[3,0,3]  R562      -2.1008187532424927e-01
    z[3,0,3]  R563      0.591512143611908
    z[3,0,3]  R564      5.3625398874282837e-01
    z[3,0,3]  R565      3.1039351224899292e-01
    z[3,0,3]  R566      9.4767600297927856e-02
    z[3,0,3]  R567      3.9894381165504456e-01
    z[3,0,3]  R568      2.3887093365192413e-01
    z[3,0,3]  R569      3.5465556383132935e-01
    z[3,0,3]  R570      4.6932280063629150e-01
    z[3,0,3]  R571      4.8359695076942444e-01
    z[3,0,3]  R572      -2.9546749591827393e-01
    z[3,0,3]  R573      -9.2585608363151550e-02
    z[3,0,3]  R574      0.144478902220726
    z[3,0,3]  R575      4.9953363835811615e-02
    z[3,0,3]  R576      -4.1675353050231934e-01
    z[3,0,3]  R577      -1.9000534713268280e-01
    z[3,0,3]  R578      7.0265196263790131e-02
    z[3,0,3]  R579      -2.1355268359184265e-01
    z[3,0,3]  R580      1.0279149562120438e-01
    z[3,0,3]  R581      1.4658312499523163e-01
    z[3,0,3]  R582      -0.240363210439682
    z[3,0,3]  R583      4.0989495813846588e-02
    z[3,0,3]  R584      1.9411119818687439e-01
    z[3,0,3]  R585      4.3253910541534424e-01
    z[3,0,3]  R586      1.4697183668613434e-01
    z[3,0,3]  R587      -9.0161100029945374e-02
    z[3,0,3]  R588      1.9986793398857117e-01
    z[3,0,3]  R589      -2.5931049603968859e-03
    z[3,0,3]  R590      0.0225517675280571
    z[3,0,3]  R591      1.6422437503933907e-02
    z[3,0,3]  R592      2.7692386507987976e-01
    z[3,0,3]  R593      -1.9492456316947937e-01
    z[3,0,3]  R594      -6.0355597734451294e-01
    z[3,0,3]  R595      3.1957823038101196e-01
    z[3,0,3]  R596      4.3257674574851990e-01
    z[3,0,3]  R597      4.4370394945144653e-01
    z[3,0,3]  R598      -5.5770836770534515e-02
    z[3,0,3]  R599      0.400804340839386
    z[3,0,3]  R600      5.8853697776794434e-01
    z[3,0,3]  R601      -2.0160461962223053e-01
    z[3,0,3]  R602      -8.6898155510425568e-02
    z[3,0,3]  R603      1.8041260540485382e-02
    z[3,0,3]  R604      -6.3954539597034454e-02
    z[3,0,3]  R605      1.4463429339230061e-02
    z[3,0,3]  R606      1.4581283926963806e-01
    z[3,0,3]  R607      3.6226221919059753e-01
    z[3,0,3]  R608      3.2409176230430603e-01
    z[3,0,3]  R609      3.6512300372123718e-01
    z[3,0,3]  R610      0.624301016330719
    z[3,0,3]  R611      -1.1442262679338455e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R456      -1
    z[3,0,4]  R457      1
    z[3,0,4]  R462      -1.2922429479658604e-02
    z[3,0,4]  R463      -3.3408230543136597e-01
    z[3,0,4]  R464      -3.7047231197357178e-01
    z[3,0,4]  R465      1.0382376611232758e-01
    z[3,0,4]  R466      -5.7068582624197006e-02
    z[3,0,4]  R467      -4.5437198132276535e-02
    z[3,0,4]  R468      1.0979046672582626e-01
    z[3,0,4]  R469      6.2426459789276123e-01
    z[3,0,4]  R470      1.6458596289157867e-01
    z[3,0,4]  R471      -1.9093267619609833e-01
    z[3,0,4]  R472      1.5055269002914429e-01
    z[3,0,4]  R473      4.7900673747062683e-01
    z[3,0,4]  R474      6.8221485614776611e-01
    z[3,0,4]  R475      -2.4003732204437256e-01
    z[3,0,4]  R476      8.7532445788383484e-02
    z[3,0,4]  R477      1.3894857466220856e-01
    z[3,0,4]  R478      -2.3357519507408142e-01
    z[3,0,4]  R479      3.6047333478927612e-01
    z[3,0,4]  R480      -1.7176365852355957e-01
    z[3,0,4]  R481      3.8407412171363831e-01
    z[3,0,4]  R482      3.0290532857179642e-02
    z[3,0,4]  R483      1.6972228884696960e-01
    z[3,0,4]  R484      -2.6506516337394714e-01
    z[3,0,4]  R485      -6.5742902457714081e-02
    z[3,0,4]  R486      3.7353450059890747e-01
    z[3,0,4]  R487      -1.9902090728282928e-01
    z[3,0,4]  R488      -1.7694956064224243e-01
    z[3,0,4]  R489      -3.5701495409011841e-01
    z[3,0,4]  R490      -4.2548492550849915e-01
    z[3,0,4]  R491      -2.7885007858276367e-01
    z[3,0,4]  R492      -3.0204278230667114e-01
    z[3,0,4]  R493      -6.5034247934818268e-02
    z[3,0,4]  R494      1.4242146909236908e-01
    z[3,0,4]  R495      -3.8372558355331421e-01
    z[3,0,4]  R496      -2.7505305409431458e-01
    z[3,0,4]  R497      -3.5697260499000549e-01
    z[3,0,4]  R498      1.1379770934581757e-01
    z[3,0,4]  R499      4.8987287282943726e-01
    z[3,0,4]  R500      2.1615803241729736e-01
    z[3,0,4]  R501      3.1966876983642578e-01
    z[3,0,4]  R502      2.2724738717079163e-01
    z[3,0,4]  R503      3.7069374322891235e-01
    z[3,0,4]  R504      -4.7022711485624313e-02
    z[3,0,4]  R505      5.0512617826461792e-01
    z[3,0,4]  R506      9.9318593740463257e-02
    z[3,0,4]  R507      6.3165497779846191e-01
    z[3,0,4]  R508      0.0630766972899437
    z[3,0,4]  R509      0.0745469257235527
    z[3,0,4]  R510      4.1779968142509460e-01
    z[3,0,4]  R511      -8.4193728864192963e-02
    z[3,0,4]  R512      1.8353018164634705e-01
    z[3,0,4]  R513      1.4879144728183746e-01
    z[3,0,4]  R514      -1.8214456737041473e-01
    z[3,0,4]  R515      2.5692921876907349e-01
    z[3,0,4]  R516      5.9604948759078979e-01
    z[3,0,4]  R517      1.8044304102659225e-02
    z[3,0,4]  R518      3.6404874920845032e-01
    z[3,0,4]  R519      2.3396741598844528e-02
    z[3,0,4]  R520      -2.8300735354423523e-01
    z[3,0,4]  R521      -1.9731599092483521e-01
    z[3,0,4]  R522      -4.4487681239843369e-02
    z[3,0,4]  R523      3.2666184008121490e-02
    z[3,0,4]  R524      1.5206189453601837e-01
    z[3,0,4]  R525      9.2810891568660736e-02
    z[3,0,4]  R526      9.6238173544406891e-02
    z[3,0,4]  R527      -1.3673400878906250e-01
    z[3,0,4]  R528      -2.0141109824180603e-01
    z[3,0,4]  R529      2.3014084994792938e-01
    z[3,0,4]  R530      -2.4442131817340851e-01
    z[3,0,4]  R531      9.3896873295307159e-02
    z[3,0,4]  R532      2.7465993165969849e-01
    z[3,0,4]  R533      -1.7549371719360352e-01
    z[3,0,4]  R534      -2.2474156320095062e-01
    z[3,0,4]  R535      3.3653992414474487e-01
    z[3,0,4]  R536      2.3855890333652496e-01
    z[3,0,4]  R537      1.3736869394779205e-01
    z[3,0,4]  R538      7.3812989285215735e-04
    z[3,0,4]  R539      -5.2129936218261719e-01
    z[3,0,4]  R540      -2.2389587759971619e-01
    z[3,0,4]  R541      -2.0287160575389862e-01
    z[3,0,4]  R542      -2.2320783138275146e-01
    z[3,0,4]  R543      -4.0431165695190430e-01
    z[3,0,4]  R544      -7.5694218277931213e-02
    z[3,0,4]  R545      -4.6823564171791077e-01
    z[3,0,4]  R546      -1.4151379466056824e-01
    z[3,0,4]  R547      -1.6214616596698761e-01
    z[3,0,4]  R548      -6.3354140520095825e-01
    z[3,0,4]  R549      -2.5628909468650818e-01
    z[3,0,4]  R550      -1.6630516946315765e-01
    z[3,0,4]  R551      -2.2820074856281281e-01
    z[3,0,4]  R552      8.4936410188674927e-02
    z[3,0,4]  R553      6.0803145170211792e-01
    z[3,0,4]  R554      0.535810649394989
    z[3,0,4]  R555      3.4923958778381348e-01
    z[3,0,4]  R556      -1.2607812881469727e-01
    z[3,0,4]  R557      3.3863863348960876e-01
    z[3,0,4]  R558      3.9063774049282074e-02
    z[3,0,4]  R559      -3.0383935570716858e-01
    z[3,0,4]  R560      -6.3019412755966187e-01
    z[3,0,4]  R561      0.182783842086792
    z[3,0,4]  R562      -4.4336962699890137e-01
    z[3,0,4]  R563      -1.5069375932216644e-01
    z[3,0,4]  R564      -1.6082622110843658e-01
    z[3,0,4]  R565      -4.6549633145332336e-01
    z[3,0,4]  R566      -5.2558548748493195e-02
    z[3,0,4]  R567      -1.7212267220020294e-01
    z[3,0,4]  R568      -3.5822349786758423e-01
    z[3,0,4]  R569      4.1479739546775818e-01
    z[3,0,4]  R570      2.3057612776756287e-01
    z[3,0,4]  R571      -7.6729096472263336e-02
    z[3,0,4]  R572      -2.5740219280123711e-02
    z[3,0,4]  R573      -0.147491917014122
    z[3,0,4]  R574      3.0154368281364441e-01
    z[3,0,4]  R575      3.6195525527000427e-01
    z[3,0,4]  R576      1.0208228230476379e-01
    z[3,0,4]  R577      -4.4310221076011658e-01
    z[3,0,4]  R578      -3.3230370283126831e-01
    z[3,0,4]  R579      1.6288186609745026e-01
    z[3,0,4]  R580      -1.5184590220451355e-01
    z[3,0,4]  R581      1.2072016298770905e-01
    z[3,0,4]  R582      1.2923154234886169e-01
    z[3,0,4]  R583      -0.817986011505127
    z[3,0,4]  R584      -3.2437807321548462e-01
    z[3,0,4]  R585      -3.3277797698974609e-01
    z[3,0,4]  R586      -3.0150877311825752e-02
    z[3,0,4]  R587      -3.8535857200622559e-01
    z[3,0,4]  R588      1.0299303382635117e-01
    z[3,0,4]  R589      -9.6264392137527466e-02
    z[3,0,4]  R590      -1.3803568668663502e-02
    z[3,0,4]  R591      -5.8436781167984009e-01
    z[3,0,4]  R592      -1.6579884290695190e-01
    z[3,0,4]  R593      -2.1202203631401062e-01
    z[3,0,4]  R594      -2.6820358633995056e-01
    z[3,0,4]  R595      -2.0164571702480316e-01
    z[3,0,4]  R596      1.5451878309249878e-01
    z[3,0,4]  R597      1.0063663125038147e-01
    z[3,0,4]  R598      3.4109887480735779e-01
    z[3,0,4]  R599      0.134738951921463
    z[3,0,4]  R600      4.4613420963287354e-02
    z[3,0,4]  R601      3.2112199068069458e-01
    z[3,0,4]  R602      -5.4176330566406250e-01
    z[3,0,4]  R603      6.5428592264652252e-02
    z[3,0,4]  R604      1.7017661035060883e-01
    z[3,0,4]  R605      -0.142030268907547
    z[3,0,4]  R606      -1.4919550158083439e-02
    z[3,0,4]  R607      1.5047530643641949e-02
    z[3,0,4]  R608      -2.5630483031272888e-01
    z[3,0,4]  R609      -2.0106402039527893e-01
    z[3,0,4]  R610      2.6019278168678284e-01
    z[3,0,4]  R611      1.7763257026672363e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R458      -1
    z[3,0,5]  R459      1
    z[3,0,5]  R462      -7.1594923734664917e-02
    z[3,0,5]  R463      1.2033394724130630e-01
    z[3,0,5]  R464      -4.3070587515830994e-01
    z[3,0,5]  R465      -2.2164934873580933e-01
    z[3,0,5]  R466      -0.824120044708252
    z[3,0,5]  R467      1.4033000171184540e-01
    z[3,0,5]  R468      -9.9121198058128357e-02
    z[3,0,5]  R469      3.9948695898056030e-01
    z[3,0,5]  R470      2.8855550289154053e-01
    z[3,0,5]  R471      0.0670010894536972
    z[3,0,5]  R472      5.5497944355010986e-02
    z[3,0,5]  R473      5.1751244068145752e-01
    z[3,0,5]  R474      -7.3180519044399261e-02
    z[3,0,5]  R475      1.2180896848440170e-01
    z[3,0,5]  R476      1.0028154402971268e-01
    z[3,0,5]  R477      -3.4219104051589966e-01
    z[3,0,5]  R478      7.0903427898883820e-02
    z[3,0,5]  R479      7.6070673763751984e-02
    z[3,0,5]  R480      -3.0782202258706093e-02
    z[3,0,5]  R481      4.3729510903358459e-01
    z[3,0,5]  R482      1.6473619639873505e-01
    z[3,0,5]  R483      -2.7248337864875793e-02
    z[3,0,5]  R484      9.6197031438350677e-02
    z[3,0,5]  R485      6.0163778066635132e-01
    z[3,0,5]  R486      -6.0983706265687943e-02
    z[3,0,5]  R487      2.5788676738739014e-01
    z[3,0,5]  R488      -0.0456160232424736
    z[3,0,5]  R489      -2.1228650212287903e-01
    z[3,0,5]  R490      -1.7278324067592621e-01
    z[3,0,5]  R491      -1.4928644895553589e-01
    z[3,0,5]  R492      -4.2609229683876038e-01
    z[3,0,5]  R493      1.2111280113458633e-01
    z[3,0,5]  R494      -2.1845720708370209e-01
    z[3,0,5]  R495      -2.6794201135635376e-01
    z[3,0,5]  R496      -2.8001922369003296e-01
    z[3,0,5]  R497      -0.5264852643013
    z[3,0,5]  R498      -2.5525093078613281e-01
    z[3,0,5]  R499      -2.4217948317527771e-02
    z[3,0,5]  R500      -2.8848379850387573e-01
    z[3,0,5]  R501      4.3418622016906738e-01
    z[3,0,5]  R502      -1.5303204953670502e-01
    z[3,0,5]  R503      -9.2712230980396271e-02
    z[3,0,5]  R504      3.8863378763198853e-01
    z[3,0,5]  R505      -3.1936866044998169e-01
    z[3,0,5]  R506      2.8483736515045166e-01
    z[3,0,5]  R507      2.1372631192207336e-01
    z[3,0,5]  R508      -2.8907996416091919e-01
    z[3,0,5]  R509      1.0884429514408112e-01
    z[3,0,5]  R510      0.0377860963344574
    z[3,0,5]  R511      -0.294871985912323
    z[3,0,5]  R512      0.430424302816391
    z[3,0,5]  R513      -1.1839371919631958e-01
    z[3,0,5]  R514      -4.5698404312133789e-01
    z[3,0,5]  R515      5.8323782682418823e-01
    z[3,0,5]  R516      -3.4498110413551331e-01
    z[3,0,5]  R517      5.0153142213821411e-01
    z[3,0,5]  R518      -6.6374707221984863e-01
    z[3,0,5]  R519      0.896765947341919
    z[3,0,5]  R520      7.0995688438415527e-01
    z[3,0,5]  R521      -4.7227197885513306e-01
    z[3,0,5]  R522      7.5401091575622559e-01
    z[3,0,5]  R523      2.3110548034310341e-02
    z[3,0,5]  R524      -4.5502327382564545e-02
    z[3,0,5]  R525      -1.5141440927982330e-01
    z[3,0,5]  R526      4.6859785914421082e-01
    z[3,0,5]  R527      -2.0513559877872467e-01
    z[3,0,5]  R528      2.1855992078781128e-01
    z[3,0,5]  R529      -1.1159786581993103e-01
    z[3,0,5]  R530      6.7691020667552948e-02
    z[3,0,5]  R531      5.2345430850982666e-01
    z[3,0,5]  R532      -1.7096638679504395e-01
    z[3,0,5]  R533      -7.6470810174942017e-01
    z[3,0,5]  R534      -1.7447984218597412e-01
    z[3,0,5]  R535      -0.0942888930439949
    z[3,0,5]  R536      8.8665008544921875e-02
    z[3,0,5]  R537      4.5969173312187195e-01
    z[3,0,5]  R538      -1.0222969204187393e-01
    z[3,0,5]  R539      4.4253578782081604e-01
    z[3,0,5]  R540      2.3229949176311493e-01
    z[3,0,5]  R541      6.2652014195919037e-02
    z[3,0,5]  R542      -5.0905489921569824e-01
    z[3,0,5]  R543      -5.4433119297027588e-01
    z[3,0,5]  R544      -4.7511899471282959e-01
    z[3,0,5]  R545      -1.6559608280658722e-01
    z[3,0,5]  R546      -3.4410101175308228e-01
    z[3,0,5]  R547      4.9339506775140762e-02
    z[3,0,5]  R548      7.2693345136940479e-03
    z[3,0,5]  R549      -5.5108584463596344e-02
    z[3,0,5]  R550      -0.0675864890217781
    z[3,0,5]  R551      -2.6002112776041031e-02
    z[3,0,5]  R552      3.0668914318084717e-01
    z[3,0,5]  R553      2.4083366990089417e-01
    z[3,0,5]  R554      -9.9006086587905884e-02
    z[3,0,5]  R555      -2.1417747437953949e-01
    z[3,0,5]  R556      3.3189021050930023e-02
    z[3,0,5]  R557      0.00866305734962225
    z[3,0,5]  R558      2.6181730628013611e-01
    z[3,0,5]  R559      -4.9240300059318542e-01
    z[3,0,5]  R560      -1.0139561444520950e-01
    z[3,0,5]  R561      -3.2355183362960815e-01
    z[3,0,5]  R562      -2.1214015781879425e-01
    z[3,0,5]  R563      -1.0613843053579330e-01
    z[3,0,5]  R564      -1.3273153454065323e-02
    z[3,0,5]  R565      1.6257645189762115e-01
    z[3,0,5]  R566      2.8083750605583191e-01
    z[3,0,5]  R567      -0.361116498708725
    z[3,0,5]  R568      -1.5391005203127861e-02
    z[3,0,5]  R569      -3.2534605264663696e-01
    z[3,0,5]  R570      -3.1955784559249878e-01
    z[3,0,5]  R571      -3.7333497405052185e-01
    z[3,0,5]  R572      -6.0456240177154541e-01
    z[3,0,5]  R573      -4.5098894834518433e-01
    z[3,0,5]  R574      -9.0859957039356232e-02
    z[3,0,5]  R575      -3.5138934850692749e-01
    z[3,0,5]  R576      -2.0510452985763550e-01
    z[3,0,5]  R577      1.2821625173091888e-01
    z[3,0,5]  R578      6.5603062510490417e-02
    z[3,0,5]  R579      -1.5121465921401978e-01
    z[3,0,5]  R580      8.5558727383613586e-02
    z[3,0,5]  R581      -1.1811101436614990e-01
    z[3,0,5]  R582      0.0697358176112175
    z[3,0,5]  R583      -2.8930500149726868e-01
    z[3,0,5]  R584      -4.1346341371536255e-01
    z[3,0,5]  R585      -4.1267088055610657e-01
    z[3,0,5]  R586      -2.0328895747661591e-01
    z[3,0,5]  R587      -1.4351263642311096e-01
    z[3,0,5]  R588      4.5918479561805725e-02
    z[3,0,5]  R589      -1.5339544415473938e-01
    z[3,0,5]  R590      -2.5288888812065125e-01
    z[3,0,5]  R591      -1.1544585227966309e-01
    z[3,0,5]  R592      -4.1427844762802124e-01
    z[3,0,5]  R593      -0.461177259683609
    z[3,0,5]  R594      -0.315845251083374
    z[3,0,5]  R595      -4.4648941606283188e-02
    z[3,0,5]  R596      -3.1556600332260132e-01
    z[3,0,5]  R597      1.0550966858863831e-01
    z[3,0,5]  R598      4.2432162910699844e-02
    z[3,0,5]  R599      0.0781085416674614
    z[3,0,5]  R600      -4.0588015317916870e-01
    z[3,0,5]  R601      4.5679128170013428e-01
    z[3,0,5]  R602      -1.9397646188735962e-01
    z[3,0,5]  R603      -2.5300228595733643e-01
    z[3,0,5]  R604      -4.4067561626434326e-01
    z[3,0,5]  R605      -2.2717300057411194e-01
    z[3,0,5]  R606      -3.7334197759628296e-01
    z[3,0,5]  R607      4.4848173856735229e-03
    z[3,0,5]  R608      -1.7721937596797943e-01
    z[3,0,5]  R609      2.2761276364326477e-01
    z[3,0,5]  R610      3.1403505802154541e-01
    z[3,0,5]  R611      2.1357160806655884e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R460      -1
    z[3,0,6]  R461      1
    z[3,0,6]  R462      -1.0292565822601318e-01
    z[3,0,6]  R463      4.2694514989852905e-01
    z[3,0,6]  R464      2.8673991560935974e-01
    z[3,0,6]  R465      -1.7907572910189629e-02
    z[3,0,6]  R466      -4.6501882374286652e-02
    z[3,0,6]  R467      2.7039566636085510e-01
    z[3,0,6]  R468      -2.3802092671394348e-01
    z[3,0,6]  R469      -2.8519439697265625e-01
    z[3,0,6]  R470      -1.6427727416157722e-02
    z[3,0,6]  R471      4.0089237689971924e-01
    z[3,0,6]  R472      1.4535829424858093e-02
    z[3,0,6]  R473      -1.4709062874317169e-01
    z[3,0,6]  R474      -4.9917469732463360e-03
    z[3,0,6]  R475      -1.7179638147354126e-02
    z[3,0,6]  R476      -4.5078076422214508e-02
    z[3,0,6]  R477      1.2207396328449249e-01
    z[3,0,6]  R478      -2.9277160763740540e-01
    z[3,0,6]  R479      4.7871533036231995e-01
    z[3,0,6]  R480      -4.5756044983863831e-01
    z[3,0,6]  R481      -1.9415043294429779e-01
    z[3,0,6]  R482      -8.5624635219573975e-02
    z[3,0,6]  R483      -2.2068157792091370e-01
    z[3,0,6]  R484      -2.5803956389427185e-01
    z[3,0,6]  R485      -1.2441388517618179e-01
    z[3,0,6]  R486      -1.2177091836929321e-01
    z[3,0,6]  R487      -1.4720830321311951e-01
    z[3,0,6]  R488      2.0740801095962524e-01
    z[3,0,6]  R489      -5.9064473956823349e-02
    z[3,0,6]  R490      1.2667530775070190e-01
    z[3,0,6]  R491      -1.1722601950168610e-01
    z[3,0,6]  R492      3.1874611973762512e-01
    z[3,0,6]  R493      1.7620076239109039e-01
    z[3,0,6]  R494      -4.6389183402061462e-01
    z[3,0,6]  R495      3.3987739682197571e-01
    z[3,0,6]  R496      -1.2304409593343735e-01
    z[3,0,6]  R497      -1.5102137625217438e-01
    z[3,0,6]  R498      3.6426514387130737e-01
    z[3,0,6]  R499      1.1635456979274750e-01
    z[3,0,6]  R500      -2.9351255297660828e-01
    z[3,0,6]  R501      2.3197162151336670e-01
    z[3,0,6]  R502      1.4954103529453278e-01
    z[3,0,6]  R503      1.1755497753620148e-01
    z[3,0,6]  R504      -7.6021656394004822e-02
    z[3,0,6]  R505      3.6324289441108704e-01
    z[3,0,6]  R506      -2.1538391709327698e-01
    z[3,0,6]  R507      4.4994466006755829e-02
    z[3,0,6]  R508      2.5756680965423584e-01
    z[3,0,6]  R509      -9.1338776051998138e-02
    z[3,0,6]  R510      -2.0584285259246826e-01
    z[3,0,6]  R511      -3.1190514564514160e-01
    z[3,0,6]  R512      -4.1874065995216370e-01
    z[3,0,6]  R513      2.1480417251586914e-01
    z[3,0,6]  R514      3.3693531155586243e-01
    z[3,0,6]  R515      2.6994548738002777e-02
    z[3,0,6]  R516      1.6113099455833435e-01
    z[3,0,6]  R517      2.1039338409900665e-01
    z[3,0,6]  R518      2.6457908749580383e-01
    z[3,0,6]  R519      -1.9243661314249039e-02
    z[3,0,6]  R520      -2.2608275711536407e-01
    z[3,0,6]  R521      1.1658965051174164e-01
    z[3,0,6]  R522      -3.4674385190010071e-01
    z[3,0,6]  R523      -2.0819826424121857e-01
    z[3,0,6]  R524      -3.6833170056343079e-01
    z[3,0,6]  R525      4.3919944763183594e-01
    z[3,0,6]  R526      2.0566870272159576e-01
    z[3,0,6]  R527      -2.2956621646881104e-01
    z[3,0,6]  R528      1.0010523721575737e-02
    z[3,0,6]  R529      -3.8473281264305115e-01
    z[3,0,6]  R530      -6.1834228038787842e-01
    z[3,0,6]  R531      -1.2329224497079849e-01
    z[3,0,6]  R532      -1.6788972914218903e-01
    z[3,0,6]  R533      -1.7228076234459877e-02
    z[3,0,6]  R534      -2.4053168296813965e-01
    z[3,0,6]  R535      -1.7618584632873535e-01
    z[3,0,6]  R536      -3.4975594282150269e-01
    z[3,0,6]  R537      -7.9743430018424988e-02
    z[3,0,6]  R538      -1.9918261468410492e-01
    z[3,0,6]  R539      -1.5136629343032837e-01
    z[3,0,6]  R540      2.3564919829368591e-02
    z[3,0,6]  R541      4.8643615096807480e-02
    z[3,0,6]  R542      1.6963279247283936e-01
    z[3,0,6]  R543      -4.8378005623817444e-02
    z[3,0,6]  R544      -4.2930582165718079e-01
    z[3,0,6]  R545      -2.6640886440873146e-02
    z[3,0,6]  R546      -2.2289891541004181e-01
    z[3,0,6]  R547      -2.6280790567398071e-01
    z[3,0,6]  R548      -3.7124386429786682e-01
    z[3,0,6]  R549      -3.3423757553100586e-01
    z[3,0,6]  R550      1.9612808525562286e-01
    z[3,0,6]  R551      -3.2220214605331421e-01
    z[3,0,6]  R552      1.5329061448574066e-01
    z[3,0,6]  R553      -2.9133863747119904e-02
    z[3,0,6]  R554      3.9179217815399170e-01
    z[3,0,6]  R555      4.7159501910209656e-01
    z[3,0,6]  R556      6.9306629896163940e-01
    z[3,0,6]  R557      -2.4068398773670197e-01
    z[3,0,6]  R558      -8.7645635008811951e-02
    z[3,0,6]  R559      1.3628785312175751e-01
    z[3,0,6]  R560      2.0543886721134186e-01
    z[3,0,6]  R561      1.0894315782934427e-03
    z[3,0,6]  R562      -6.0778349637985229e-01
    z[3,0,6]  R563      1.7104738950729370e-01
    z[3,0,6]  R564      -2.8610643744468689e-01
    z[3,0,6]  R565      -0.148108571767807
    z[3,0,6]  R566      1.6409799456596375e-01
    z[3,0,6]  R567      1.3578611612319946e-01
    z[3,0,6]  R568      -2.7618399262428284e-01
    z[3,0,6]  R569      2.0031447708606720e-01
    z[3,0,6]  R570      -3.8839691877365112e-01
    z[3,0,6]  R571      -4.2779636383056641e-01
    z[3,0,6]  R572      -1.1489473283290863e-01
    z[3,0,6]  R573      -5.0027370452880859e-01
    z[3,0,6]  R574      3.1150346994400024e-01
    z[3,0,6]  R575      -1.1582090705633163e-01
    z[3,0,6]  R576      9.3578919768333435e-02
    z[3,0,6]  R577      -3.5544827580451965e-02
    z[3,0,6]  R578      -2.3790046572685242e-01
    z[3,0,6]  R579      -2.9069057106971741e-01
    z[3,0,6]  R580      -1.3186487555503845e-01
    z[3,0,6]  R581      -5.7730913162231445e-01
    z[3,0,6]  R582      5.2270330488681793e-02
    z[3,0,6]  R583      -0.287873238325119
    z[3,0,6]  R584      -6.1442956328392029e-02
    z[3,0,6]  R585      1.0017297416925430e-01
    z[3,0,6]  R586      -3.4044528007507324e-01
    z[3,0,6]  R587      3.5643249750137329e-02
    z[3,0,6]  R588      2.1268843114376068e-01
    z[3,0,6]  R589      -7.8744582831859589e-02
    z[3,0,6]  R590      8.1997781991958618e-02
    z[3,0,6]  R591      -1.1281748116016388e-01
    z[3,0,6]  R592      0.321675181388855
    z[3,0,6]  R593      -2.5920584797859192e-01
    z[3,0,6]  R594      -5.0701463222503662e-01
    z[3,0,6]  R595      9.7830243408679962e-02
    z[3,0,6]  R596      -4.3358799070119858e-02
    z[3,0,6]  R597      -1.4508636295795441e-01
    z[3,0,6]  R598      -4.2642485350370407e-02
    z[3,0,6]  R599      3.3857926726341248e-02
    z[3,0,6]  R600      -4.3097484111785889e-01
    z[3,0,6]  R601      -1.9725072383880615e-01
    z[3,0,6]  R602      -6.7148125171661377e-01
    z[3,0,6]  R603      -4.5034587383270264e-02
    z[3,0,6]  R604      1.9323875010013580e-01
    z[3,0,6]  R605      -3.8692843168973923e-02
    z[3,0,6]  R606      2.0327742397785187e-01
    z[3,0,6]  R607      -7.8126393258571625e-02
    z[3,0,6]  R608      -4.0910041332244873e-01
    z[3,0,6]  R609      -5.9128899127244949e-02
    z[3,0,6]  R610      8.5603788495063782e-02
    z[3,0,6]  R611      2.7015948295593262e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R696      -1
    z[1,2,0]  R697      1
    z[1,2,0]  R710      -4.9690928310155869e-02
    z[1,2,0]  R711      -5.8148401975631714e-01
    z[1,2,0]  R712      -1.1177226155996323e-01
    z[1,2,0]  R713      -6.1769241094589233e-01
    z[1,2,0]  R714      1.4331138134002686e-01
    z[1,2,0]  R715      6.5243035554885864e-01
    z[1,2,0]  R716      6.3770312070846558e-01
    z[1,2,0]  R717      2.9630595818161964e-02
    z[1,2,0]  R718      4.4086730480194092e-01
    z[1,2,0]  R719      2.9334232211112976e-01
    z[1,2,0]  R720      1.6809152066707611e-01
    z[1,2,0]  R721      -0.023863660171628
    z[1,2,0]  R722      -1.1202633380889893e-01
    z[1,2,0]  R723      1.9880126416683197e-01
    z[1,2,0]  R724      -1.3381104171276093e-01
    z[1,2,0]  R725      -7.3125801980495453e-02
    z[1,2,0]  R726      -1.5840733423829079e-02
    z[1,2,0]  R727      1.9686248898506165e-01
    z[1,2,0]  R728      2.2745615243911743e-01
    z[1,2,0]  R729      -6.1484247446060181e-01
    z[1,2,0]  R730      1.7498087882995605e-01
    z[1,2,0]  R731      8.2255318760871887e-02
    z[1,2,0]  R732      -2.1478015184402466e-01
    z[1,2,0]  R733      -1.9356778264045715e-01
    z[1,2,0]  R734      3.4069761633872986e-02
    z[1,2,0]  R735      1.0933275334537029e-02
    z[1,2,0]  R736      3.0830252170562744e-01
    z[1,2,0]  R737      4.4244241714477539e-01
    z[1,2,0]  R738      5.9359449893236160e-02
    z[1,2,0]  R739      6.1092221736907959e-01
    z[1,2,0]  R740      2.0168526470661163e-01
    z[1,2,0]  R741      7.4236601591110229e-01
    z[1,2,0]  R742      6.3519030809402466e-01
    z[1,2,0]  R743      8.2694751024246216e-01
    z[1,2,0]  R744      0.732430636882782
    z[1,2,0]  R745      6.9434732198715210e-01
    z[1,2,0]  R746      5.0212305784225464e-01
    z[1,2,0]  R747      5.2095401287078857e-01
    z[1,2,0]  R748      5.2552109956741333e-01
    z[1,2,0]  R749      0.565981388092041
    z[1,2,0]  R750      -2.8693279623985291e-01
    z[1,2,0]  R751      -2.2875705361366272e-01
    z[1,2,0]  R752      -3.7252682447433472e-01
    z[1,2,0]  R753      -3.4144580364227295e-02
    z[1,2,0]  R754      -1.2130939960479736e-01
    z[1,2,0]  R755      -0.24737648665905
    z[1,2,0]  R756      -3.2693052291870117e-01
    z[1,2,0]  R757      -7.0166802406311035e-01
    z[1,2,0]  R758      -5.1734834909439087e-01
    z[1,2,0]  R759      -6.8399560451507568e-01
    z[1,2,0]  R760      2.5814792513847351e-01
    z[1,2,0]  R761      2.5163169950246811e-02
    z[1,2,0]  R762      -2.8755296953022480e-03
    z[1,2,0]  R763      -9.6380099654197693e-02
    z[1,2,0]  R764      5.5131424218416214e-02
    z[1,2,0]  R765      -3.4453833103179932e-01
    z[1,2,0]  R766      3.0919777229428291e-02
    z[1,2,0]  R767      4.4574152678251266e-02
    z[1,2,0]  R768      -2.1453756093978882e-01
    z[1,2,0]  R769      -4.7364017367362976e-01
    z[1,2,0]  R770      4.5386686921119690e-01
    z[1,2,0]  R771      5.7206705212593079e-02
    z[1,2,0]  R772      -2.5209262967109680e-01
    z[1,2,0]  R773      1.3466119766235352e-02
    z[1,2,0]  R774      -3.8344639539718628e-01
    z[1,2,0]  R775      -1.2124659866094589e-01
    z[1,2,0]  R776      -4.3595591187477112e-01
    z[1,2,0]  R777      -3.0036526918411255e-01
    z[1,2,0]  R778      1.9480532407760620e-01
    z[1,2,0]  R779      -1.3827045261859894e-01
    z[1,2,0]  R780      2.8657663613557816e-02
    z[1,2,0]  R781      2.7474978566169739e-01
    z[1,2,0]  R782      -5.2531582117080688e-01
    z[1,2,0]  R783      -4.8632583022117615e-01
    z[1,2,0]  R784      3.1036838889122009e-01
    z[1,2,0]  R785      -5.6225264072418213e-01
    z[1,2,0]  R786      9.9852740764617920e-02
    z[1,2,0]  R787      7.0530459284782410e-02
    z[1,2,0]  R788      -2.4579961597919464e-01
    z[1,2,0]  R789      -5.8534210920333862e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R698      -1
    z[1,2,1]  R699      1
    z[1,2,1]  R710      -7.3943519592285156e-01
    z[1,2,1]  R711      -5.7814192771911621e-01
    z[1,2,1]  R712      -4.6810141205787659e-01
    z[1,2,1]  R713      -2.7959123253822327e-01
    z[1,2,1]  R714      -3.9454612135887146e-01
    z[1,2,1]  R715      5.4222857952117920e-01
    z[1,2,1]  R716      5.4430902004241943e-01
    z[1,2,1]  R717      8.7147343158721924e-01
    z[1,2,1]  R718      6.8491917848587036e-01
    z[1,2,1]  R719      5.4950064420700073e-01
    z[1,2,1]  R720      0.711979329586029
    z[1,2,1]  R721      7.1186983585357666e-01
    z[1,2,1]  R722      6.6931933164596558e-01
    z[1,2,1]  R723      7.8237426280975342e-01
    z[1,2,1]  R724      5.9923851490020752e-01
    z[1,2,1]  R725      5.4216337203979492e-01
    z[1,2,1]  R726      4.3436288833618164e-01
    z[1,2,1]  R727      3.3971610665321350e-01
    z[1,2,1]  R728      -8.9301742613315582e-02
    z[1,2,1]  R729      2.7429884672164917e-01
    z[1,2,1]  R730      8.6199837923049927e-01
    z[1,2,1]  R731      7.5430279970169067e-01
    z[1,2,1]  R732      7.6275277137756348e-01
    z[1,2,1]  R733      7.1205347776412964e-01
    z[1,2,1]  R734      7.1167606115341187e-01
    z[1,2,1]  R735      6.6217201948165894e-01
    z[1,2,1]  R736      1.9006147980690002e-01
    z[1,2,1]  R737      6.9651387631893158e-02
    z[1,2,1]  R738      1.0630601644515991e-01
    z[1,2,1]  R739      -3.3505043387413025e-01
    z[1,2,1]  R740      -8.1922346353530884e-01
    z[1,2,1]  R741      4.4056215882301331e-01
    z[1,2,1]  R742      5.2807974815368652e-01
    z[1,2,1]  R743      4.5687785744667053e-01
    z[1,2,1]  R744      4.2076438665390015e-01
    z[1,2,1]  R745      4.7686314582824707e-01
    z[1,2,1]  R746      5.5727756023406982e-01
    z[1,2,1]  R747      0.628750741481781
    z[1,2,1]  R748      0.564632773399353
    z[1,2,1]  R749      5.0390481948852539e-01
    z[1,2,1]  R750      9.3186748027801514e-01
    z[1,2,1]  R751      8.1989574432373047e-01
    z[1,2,1]  R752      6.3152486085891724e-01
    z[1,2,1]  R753      0.871233344078064
    z[1,2,1]  R754      6.4237689971923828e-01
    z[1,2,1]  R755      5.5604827404022217e-01
    z[1,2,1]  R756      0.612606406211853
    z[1,2,1]  R757      2.4693058431148529e-01
    z[1,2,1]  R758      1.0127270966768265e-01
    z[1,2,1]  R759      4.4768798351287842e-01
    z[1,2,1]  R760      0.767442524433136
    z[1,2,1]  R761      -0.16782146692276
    z[1,2,1]  R762      -0.505316972732544
    z[1,2,1]  R763      -6.2347787618637085e-01
    z[1,2,1]  R764      -5.5880290269851685e-01
    z[1,2,1]  R765      -6.9875997304916382e-01
    z[1,2,1]  R766      -5.7810330390930176e-01
    z[1,2,1]  R767      6.2407189607620239e-01
    z[1,2,1]  R768      -0.574478030204773
    z[1,2,1]  R769      6.3457864522933960e-01
    z[1,2,1]  R770      8.3791959285736084e-01
    z[1,2,1]  R771      -7.3148196935653687e-01
    z[1,2,1]  R772      -8.3641594648361206e-01
    z[1,2,1]  R773      -5.9700292348861694e-01
    z[1,2,1]  R774      -7.0138669013977051e-01
    z[1,2,1]  R775      -0.52411288022995
    z[1,2,1]  R776      -5.8007371425628662e-01
    z[1,2,1]  R777      -5.7386624813079834e-01
    z[1,2,1]  R778      -7.1420305967330933e-01
    z[1,2,1]  R779      -0.469468891620636
    z[1,2,1]  R780      -6.7077857255935669e-01
    z[1,2,1]  R781      4.9553334712982178e-01
    z[1,2,1]  R782      6.4749163389205933e-01
    z[1,2,1]  R783      7.4309313297271729e-01
    z[1,2,1]  R784      -6.7778146266937256e-01
    z[1,2,1]  R785      -1.6208501160144806e-01
    z[1,2,1]  R786      3.5068961977958679e-01
    z[1,2,1]  R787      -4.7770828008651733e-01
    z[1,2,1]  R788      5.9483128786087036e-01
    z[1,2,1]  R789      4.7563686966896057e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R700      -1
    z[1,2,2]  R701      1
    z[1,2,2]  R710      -1.9925607740879059e-01
    z[1,2,2]  R711      -3.2785028219223022e-01
    z[1,2,2]  R712      -7.2761642932891846e-01
    z[1,2,2]  R713      7.2494186460971832e-02
    z[1,2,2]  R714      9.0446047484874725e-02
    z[1,2,2]  R715      -3.4528259187936783e-02
    z[1,2,2]  R716      8.5024453699588776e-02
    z[1,2,2]  R717      2.3083847761154175e-01
    z[1,2,2]  R718      2.1506215631961823e-01
    z[1,2,2]  R719      -2.6834979653358459e-01
    z[1,2,2]  R720      -2.7630642056465149e-02
    z[1,2,2]  R721      -4.4226527214050293e-01
    z[1,2,2]  R722      1.0201875865459442e-01
    z[1,2,2]  R723      -0.326465904712677
    z[1,2,2]  R724      -6.1449509859085083e-01
    z[1,2,2]  R725      -3.5805395245552063e-01
    z[1,2,2]  R726      1.8681395053863525e-01
    z[1,2,2]  R727      -5.6713706254959106e-01
    z[1,2,2]  R728      7.0076537132263184e-01
    z[1,2,2]  R729      -8.1679157912731171e-02
    z[1,2,2]  R730      7.4630357325077057e-02
    z[1,2,2]  R731      -3.0827391147613525e-01
    z[1,2,2]  R732      -1.6502179205417633e-01
    z[1,2,2]  R733      -5.4879003763198853e-01
    z[1,2,2]  R734      -4.3301945924758911e-01
    z[1,2,2]  R735      -5.0865966081619263e-01
    z[1,2,2]  R736      6.4753150939941406e-01
    z[1,2,2]  R737      6.5141016244888306e-01
    z[1,2,2]  R738      9.0096151828765869e-01
    z[1,2,2]  R739      2.7205786108970642e-01
    z[1,2,2]  R740      -7.8870102763175964e-02
    z[1,2,2]  R741      3.3070746064186096e-01
    z[1,2,2]  R742      1.0235553234815598e-01
    z[1,2,2]  R743      4.6049594879150391e-02
    z[1,2,2]  R744      1.6168086230754852e-01
    z[1,2,2]  R745      6.3644699752330780e-02
    z[1,2,2]  R746      5.4390218108892441e-02
    z[1,2,2]  R747      -1.9460545480251312e-01
    z[1,2,2]  R748      -8.8420659303665161e-02
    z[1,2,2]  R749      1.1523006111383438e-01
    z[1,2,2]  R750      -7.1286588907241821e-02
    z[1,2,2]  R751      5.5369723588228226e-02
    z[1,2,2]  R752      -4.8150178790092468e-01
    z[1,2,2]  R753      -6.6612720489501953e-02
    z[1,2,2]  R754      -6.5477684140205383e-02
    z[1,2,2]  R755      1.3341930508613586e-01
    z[1,2,2]  R756      -0.0082245459780097
    z[1,2,2]  R757      -2.3293124139308929e-01
    z[1,2,2]  R758      -2.2015622258186340e-01
    z[1,2,2]  R759      -1.5303435921669006e-01
    z[1,2,2]  R760      1.9586192071437836e-01
    z[1,2,2]  R761      7.5157051905989647e-03
    z[1,2,2]  R762      3.2421614974737167e-02
    z[1,2,2]  R763      -5.8069300651550293e-01
    z[1,2,2]  R764      -1.3434453867375851e-02
    z[1,2,2]  R765      5.5135834962129593e-02
    z[1,2,2]  R766      -1.0406474769115448e-01
    z[1,2,2]  R767      -2.2813172638416290e-01
    z[1,2,2]  R768      1.0440982878208160e-01
    z[1,2,2]  R769      3.7115357816219330e-02
    z[1,2,2]  R770      4.1516300290822983e-02
    z[1,2,2]  R771      2.5107404589653015e-01
    z[1,2,2]  R772      -1.9405621290206909e-01
    z[1,2,2]  R773      -5.8411568403244019e-01
    z[1,2,2]  R774      4.2978670448064804e-02
    z[1,2,2]  R775      9.5384582877159119e-02
    z[1,2,2]  R776      -5.3315126895904541e-01
    z[1,2,2]  R777      -0.0327596440911293
    z[1,2,2]  R778      -1.1553891003131866e-01
    z[1,2,2]  R779      -1.4035994186997414e-02
    z[1,2,2]  R780      -1.4211086928844452e-01
    z[1,2,2]  R781      0.749748706817627
    z[1,2,2]  R782      -2.3999287188053131e-01
    z[1,2,2]  R783      -2.7160859107971191e-01
    z[1,2,2]  R784      2.1083752810955048e-01
    z[1,2,2]  R785      -1.4375127851963043e-01
    z[1,2,2]  R786      7.2836279869079590e-01
    z[1,2,2]  R787      -7.1535813808441162e-01
    z[1,2,2]  R788      -9.4469018280506134e-02
    z[1,2,2]  R789      4.9765370786190033e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R702      -1
    z[1,2,3]  R703      1
    z[1,2,3]  R710      4.1571286320686340e-01
    z[1,2,3]  R711      5.2801431156694889e-03
    z[1,2,3]  R712      2.3760001361370087e-01
    z[1,2,3]  R713      4.4579803943634033e-01
    z[1,2,3]  R714      4.1010746359825134e-01
    z[1,2,3]  R715      0.0699441209435463
    z[1,2,3]  R716      -2.7111726999282837e-01
    z[1,2,3]  R717      3.5323426127433777e-03
    z[1,2,3]  R718      -1.5383604168891907e-01
    z[1,2,3]  R719      -4.1269126534461975e-01
    z[1,2,3]  R720      -7.1397058665752411e-02
    z[1,2,3]  R721      1.3254101388156414e-02
    z[1,2,3]  R722      -0.062924325466156
    z[1,2,3]  R723      2.9293122887611389e-01
    z[1,2,3]  R724      6.8340882658958435e-02
    z[1,2,3]  R725      -1.5282213687896729e-01
    z[1,2,3]  R726      -7.1344166994094849e-01
    z[1,2,3]  R727      -4.9946320056915283e-01
    z[1,2,3]  R728      -5.0770968198776245e-01
    z[1,2,3]  R729      -5.8048856258392334e-01
    z[1,2,3]  R730      -2.9847297072410583e-01
    z[1,2,3]  R731      5.1173716783523560e-01
    z[1,2,3]  R732      3.4743675589561462e-01
    z[1,2,3]  R733      -4.6729825437068939e-02
    z[1,2,3]  R734      -1.2129744887351990e-01
    z[1,2,3]  R735      1.2098416686058044e-01
    z[1,2,3]  R736      -6.5261560678482056e-01
    z[1,2,3]  R737      -3.6690777540206909e-01
    z[1,2,3]  R738      -1.4384835958480835e-01
    z[1,2,3]  R739      -3.5192090272903442e-01
    z[1,2,3]  R740      -3.8251541554927826e-02
    z[1,2,3]  R741      -3.0787003040313721e-01
    z[1,2,3]  R742      2.3503266274929047e-01
    z[1,2,3]  R743      2.3451916873455048e-01
    z[1,2,3]  R744      -1.1217866092920303e-01
    z[1,2,3]  R745      0.0248641986399889
    z[1,2,3]  R746      1.1310722678899765e-01
    z[1,2,3]  R747      -1.2516199052333832e-01
    z[1,2,3]  R748      7.1494663134217262e-03
    z[1,2,3]  R749      2.7653848752379417e-02
    z[1,2,3]  R750      -4.1430920362472534e-02
    z[1,2,3]  R751      -1.9567583501338959e-01
    z[1,2,3]  R752      -2.8022894263267517e-01
    z[1,2,3]  R753      -2.2264190018177032e-01
    z[1,2,3]  R754      -6.3048821687698364e-01
    z[1,2,3]  R755      -7.3469519615173340e-01
    z[1,2,3]  R756      -0.543587863445282
    z[1,2,3]  R757      -4.9522459506988525e-01
    z[1,2,3]  R758      -5.8769422769546509e-01
    z[1,2,3]  R759      -2.8840306401252747e-01
    z[1,2,3]  R760      4.0296044945716858e-01
    z[1,2,3]  R761      0.89235919713974
    z[1,2,3]  R762      5.9119653701782227e-01
    z[1,2,3]  R763      -4.9092669039964676e-02
    z[1,2,3]  R764      3.3295041322708130e-01
    z[1,2,3]  R765      -4.7149640321731567e-01
    z[1,2,3]  R766      6.3730108737945557e-01
    z[1,2,3]  R767      -4.3858282268047333e-02
    z[1,2,3]  R768      2.3298986256122589e-01
    z[1,2,3]  R769      4.6260673552751541e-02
    z[1,2,3]  R770      1.3171857595443726e-01
    z[1,2,3]  R771      1.4769986271858215e-01
    z[1,2,3]  R772      -3.4857848286628723e-01
    z[1,2,3]  R773      4.8908573389053345e-01
    z[1,2,3]  R774      1.0993672162294388e-01
    z[1,2,3]  R775      0.512146532535553
    z[1,2,3]  R776      8.0749049782752991e-02
    z[1,2,3]  R777      2.6764547824859619e-01
    z[1,2,3]  R778      0.00896703451871872
    z[1,2,3]  R779      7.1413886547088623e-01
    z[1,2,3]  R780      2.2266833484172821e-01
    z[1,2,3]  R781      1.3229785859584808e-01
    z[1,2,3]  R782      -4.2385622859001160e-01
    z[1,2,3]  R783      -1.5113075077533722e-01
    z[1,2,3]  R784      -1.3371877372264862e-01
    z[1,2,3]  R785      -0.685263454914093
    z[1,2,3]  R786      2.9402244091033936e-01
    z[1,2,3]  R787      -0.0520898774266243
    z[1,2,3]  R788      -0.322995126247406
    z[1,2,3]  R789      -4.4619762897491455e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R704      -1
    z[1,2,4]  R705      1
    z[1,2,4]  R710      -1.9522084295749664e-01
    z[1,2,4]  R711      -5.5625919252634048e-02
    z[1,2,4]  R712      -1.1468805372714996e-01
    z[1,2,4]  R713      2.8277322649955750e-01
    z[1,2,4]  R714      -4.1842761635780334e-01
    z[1,2,4]  R715      -5.1813744008541107e-02
    z[1,2,4]  R716      1.5262334048748016e-01
    z[1,2,4]  R717      -3.9830081164836884e-02
    z[1,2,4]  R718      -3.4797763824462891e-01
    z[1,2,4]  R719      -1.8198819458484650e-01
    z[1,2,4]  R720      5.0782209634780884e-01
    z[1,2,4]  R721      5.0541943311691284e-01
    z[1,2,4]  R722      7.0441913604736328e-01
    z[1,2,4]  R723      1.5030542016029358e-01
    z[1,2,4]  R724      1.8428441882133484e-01
    z[1,2,4]  R725      0.532706618309021
    z[1,2,4]  R726      4.6939682960510254e-01
    z[1,2,4]  R727      -1.0630524903535843e-01
    z[1,2,4]  R728      -1.1071750521659851e-01
    z[1,2,4]  R729      -3.0283406376838684e-03
    z[1,2,4]  R730      1.0974252223968506e-01
    z[1,2,4]  R731      -1.2475372105836868e-01
    z[1,2,4]  R732      2.1234643459320068e-01
    z[1,2,4]  R733      1.4340290427207947e-01
    z[1,2,4]  R734      4.1452908515930176e-01
    z[1,2,4]  R735      -2.9557171463966370e-01
    z[1,2,4]  R736      1.0928661562502384e-02
    z[1,2,4]  R737      -3.0401936173439026e-01
    z[1,2,4]  R738      1.9716110825538635e-01
    z[1,2,4]  R739      4.9992737174034119e-01
    z[1,2,4]  R740      7.3111318051815033e-02
    z[1,2,4]  R741      -1.1375582218170166e-01
    z[1,2,4]  R742      -8.2537800073623657e-02
    z[1,2,4]  R743      -1.7899218201637268e-01
    z[1,2,4]  R744      8.0192521214485168e-02
    z[1,2,4]  R745      -3.0449113249778748e-01
    z[1,2,4]  R746      -1.2869222462177277e-01
    z[1,2,4]  R747      -4.6238997578620911e-01
    z[1,2,4]  R748      -4.5858058333396912e-01
    z[1,2,4]  R749      0.305789053440094
    z[1,2,4]  R750      -0.0898180678486824
    z[1,2,4]  R751      -3.7596827745437622e-01
    z[1,2,4]  R752      -3.4587970376014709e-01
    z[1,2,4]  R753      -4.2784112691879272e-01
    z[1,2,4]  R754      -1.5457729995250702e-01
    z[1,2,4]  R755      -2.0413650572299957e-01
    z[1,2,4]  R756      -0.0776323527097702
    z[1,2,4]  R757      1.2053133547306061e-01
    z[1,2,4]  R758      -2.6265475153923035e-01
    z[1,2,4]  R759      2.7353662252426147e-01
    z[1,2,4]  R760      -2.8498631715774536e-01
    z[1,2,4]  R761      4.1087669134140015e-01
    z[1,2,4]  R762      -2.8536498546600342e-01
    z[1,2,4]  R763      -2.8570872545242310e-01
    z[1,2,4]  R764      -4.2396214604377747e-01
    z[1,2,4]  R765      -9.6188765019178391e-03
    z[1,2,4]  R766      3.5438543558120728e-01
    z[1,2,4]  R767      -2.7970872819423676e-02
    z[1,2,4]  R768      5.9508824348449707e-01
    z[1,2,4]  R769      5.2050441503524780e-01
    z[1,2,4]  R770      2.5748616456985474e-01
    z[1,2,4]  R771      -2.1077752113342285e-01
    z[1,2,4]  R772      2.1719934046268463e-01
    z[1,2,4]  R773      2.3210911080241203e-02
    z[1,2,4]  R774      2.5619903206825256e-01
    z[1,2,4]  R775      -2.3334741592407227e-01
    z[1,2,4]  R776      3.4386062622070312e-01
    z[1,2,4]  R777      2.8850868344306946e-01
    z[1,2,4]  R778      2.9008671641349792e-01
    z[1,2,4]  R779      2.1807883679866791e-01
    z[1,2,4]  R780      3.7299329042434692e-01
    z[1,2,4]  R781      3.3229142427444458e-02
    z[1,2,4]  R782      0.216078981757164
    z[1,2,4]  R783      2.6762318611145020e-01
    z[1,2,4]  R784      -1.2383381277322769e-01
    z[1,2,4]  R785      -7.6574023114517331e-04
    z[1,2,4]  R786      3.4473296999931335e-01
    z[1,2,4]  R787      -4.5324954390525818e-01
    z[1,2,4]  R788      -9.6704736351966858e-03
    z[1,2,4]  R789      1.6221849620342255e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R706      -1
    z[1,2,5]  R707      1
    z[1,2,5]  R710      4.5144062489271164e-02
    z[1,2,5]  R711      5.1510158926248550e-02
    z[1,2,5]  R712      -3.9596560597419739e-01
    z[1,2,5]  R713      -3.4057098627090454e-01
    z[1,2,5]  R714      -6.3107395172119141e-01
    z[1,2,5]  R715      -1.0247718542814255e-01
    z[1,2,5]  R716      -3.4925499558448792e-01
    z[1,2,5]  R717      4.0217429399490356e-01
    z[1,2,5]  R718      -1.4051049947738647e-01
    z[1,2,5]  R719      -2.4994817376136780e-01
    z[1,2,5]  R720      -4.4802263379096985e-01
    z[1,2,5]  R721      -2.0324413478374481e-01
    z[1,2,5]  R722      -1.0597249493002892e-02
    z[1,2,5]  R723      -3.6264079809188843e-01
    z[1,2,5]  R724      4.3007194995880127e-01
    z[1,2,5]  R725      3.4774327278137207e-01
    z[1,2,5]  R726      5.7146232575178146e-02
    z[1,2,5]  R727      5.0299829244613647e-01
    z[1,2,5]  R728      3.9705076813697815e-01
    z[1,2,5]  R729      -4.2692460119724274e-02
    z[1,2,5]  R730      -5.0250776112079620e-02
    z[1,2,5]  R731      1.9489030539989471e-01
    z[1,2,5]  R732      4.0899339318275452e-01
    z[1,2,5]  R733      1.7612640559673309e-01
    z[1,2,5]  R734      2.3359447717666626e-01
    z[1,2,5]  R735      4.1298249363899231e-01
    z[1,2,5]  R736      2.2846752777695656e-02
    z[1,2,5]  R737      2.2896414995193481e-01
    z[1,2,5]  R738      0.241278275847435
    z[1,2,5]  R739      2.1940311789512634e-01
    z[1,2,5]  R740      -2.0992338657379150e-01
    z[1,2,5]  R741      6.0002353042364120e-02
    z[1,2,5]  R742      2.1711468696594238e-01
    z[1,2,5]  R743      2.1944953128695488e-02
    z[1,2,5]  R744      -3.0375117063522339e-01
    z[1,2,5]  R745      0.174501433968544
    z[1,2,5]  R746      -4.4397312402725220e-01
    z[1,2,5]  R747      -1.2243715673685074e-01
    z[1,2,5]  R748      -4.3224963545799255e-01
    z[1,2,5]  R749      1.7003849148750305e-01
    z[1,2,5]  R750      -1.8312266469001770e-01
    z[1,2,5]  R751      -4.2208548984490335e-04
    z[1,2,5]  R752      -1.7857927083969116e-01
    z[1,2,5]  R753      1.4842978678643703e-02
    z[1,2,5]  R754      -6.8562075495719910e-02
    z[1,2,5]  R755      -1.3925287127494812e-01
    z[1,2,5]  R756      -3.6532059311866760e-01
    z[1,2,5]  R757      -3.4194344282150269e-01
    z[1,2,5]  R758      -5.0903332233428955e-01
    z[1,2,5]  R759      -3.8409563899040222e-01
    z[1,2,5]  R760      2.0312181115150452e-01
    z[1,2,5]  R761      -2.6462316513061523e-02
    z[1,2,5]  R762      -1.6600729897618294e-02
    z[1,2,5]  R763      2.4125227332115173e-01
    z[1,2,5]  R764      4.7427029348909855e-03
    z[1,2,5]  R765      -1.4630095660686493e-01
    z[1,2,5]  R766      1.6965536773204803e-01
    z[1,2,5]  R767      6.9013011455535889e-01
    z[1,2,5]  R768      1.9435566663742065e-01
    z[1,2,5]  R769      1.5157592296600342e-01
    z[1,2,5]  R770      7.7136784791946411e-02
    z[1,2,5]  R771      -5.7041305303573608e-01
    z[1,2,5]  R772      4.2971007525920868e-02
    z[1,2,5]  R773      2.3333853483200073e-01
    z[1,2,5]  R774      -4.1894045472145081e-01
    z[1,2,5]  R775      3.3118382096290588e-01
    z[1,2,5]  R776      -2.5302490592002869e-01
    z[1,2,5]  R777      1.1748849600553513e-01
    z[1,2,5]  R778      5.8008664846420288e-01
    z[1,2,5]  R779      -2.6482850313186646e-01
    z[1,2,5]  R780      3.0217874050140381e-01
    z[1,2,5]  R781      2.3517285287380219e-01
    z[1,2,5]  R782      -1.0395722091197968e-01
    z[1,2,5]  R783      0.1573476344347
    z[1,2,5]  R784      4.9449086189270020e-01
    z[1,2,5]  R785      -4.0731698274612427e-01
    z[1,2,5]  R786      -3.3146545290946960e-01
    z[1,2,5]  R787      -9.0212017297744751e-02
    z[1,2,5]  R788      5.5188196897506714e-01
    z[1,2,5]  R789      8.6244657635688782e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R708      -1
    z[1,2,6]  R709      1
    z[1,2,6]  R710      4.4508108496665955e-01
    z[1,2,6]  R711      -4.6299800276756287e-01
    z[1,2,6]  R712      -1.1209972202777863e-01
    z[1,2,6]  R713      -3.7462544441223145e-01
    z[1,2,6]  R714      -2.7219581604003906e-01
    z[1,2,6]  R715      5.1093274354934692e-01
    z[1,2,6]  R716      2.6656261086463928e-01
    z[1,2,6]  R717      -1.5174549818038940e-01
    z[1,2,6]  R718      -3.5464456677436829e-01
    z[1,2,6]  R719      -5.2352637052536011e-01
    z[1,2,6]  R720      -1.9029730930924416e-02
    z[1,2,6]  R721      1.1859763413667679e-02
    z[1,2,6]  R722      1.6963452100753784e-01
    z[1,2,6]  R723      -4.3357063084840775e-02
    z[1,2,6]  R724      1.4768348634243011e-01
    z[1,2,6]  R725      3.8006898760795593e-01
    z[1,2,6]  R726      -0.208759143948555
    z[1,2,6]  R727      1.0208845883607864e-01
    z[1,2,6]  R728      1.4676529169082642e-01
    z[1,2,6]  R729      4.4861856102943420e-01
    z[1,2,6]  R730      -3.4222227334976196e-01
    z[1,2,6]  R731      1.1750672757625580e-01
    z[1,2,6]  R732      1.0847406834363937e-01
    z[1,2,6]  R733      -3.1713131070137024e-01
    z[1,2,6]  R734      2.5246149301528931e-01
    z[1,2,6]  R735      -1.7355036735534668e-01
    z[1,2,6]  R736      -1.5159356594085693e-01
    z[1,2,6]  R737      3.0916744470596313e-01
    z[1,2,6]  R738      2.3593175411224365e-01
    z[1,2,6]  R739      -1.3633179664611816e-01
    z[1,2,6]  R740      4.8072773218154907e-01
    z[1,2,6]  R741      1.8467712402343750e-01
    z[1,2,6]  R742      4.4496819376945496e-01
    z[1,2,6]  R743      -1.3334497809410095e-01
    z[1,2,6]  R744      -3.8611200451850891e-01
    z[1,2,6]  R745      4.0329754352569580e-01
    z[1,2,6]  R746      -4.5594829320907593e-01
    z[1,2,6]  R747      -2.2571486234664917e-01
    z[1,2,6]  R748      3.4922768827527761e-03
    z[1,2,6]  R749      5.3784966468811035e-01
    z[1,2,6]  R750      2.9884090647101402e-02
    z[1,2,6]  R751      -3.0452278256416321e-01
    z[1,2,6]  R752      2.2463712841272354e-02
    z[1,2,6]  R753      5.0114914774894714e-02
    z[1,2,6]  R754      3.7714502215385437e-01
    z[1,2,6]  R755      1.0475924611091614e-01
    z[1,2,6]  R756      2.8772982954978943e-01
    z[1,2,6]  R757      -1.2541884183883667e-01
    z[1,2,6]  R758      -1.1786801740527153e-02
    z[1,2,6]  R759      -5.2705653011798859e-02
    z[1,2,6]  R760      -1.4552329480648041e-01
    z[1,2,6]  R761      -7.2948947548866272e-02
    z[1,2,6]  R762      -5.5890363454818726e-01
    z[1,2,6]  R763      -3.5005655884742737e-01
    z[1,2,6]  R764      -6.2761205434799194e-01
    z[1,2,6]  R765      -0.382338285446167
    z[1,2,6]  R766      -3.0575555562973022e-01
    z[1,2,6]  R767      -2.7842029929161072e-01
    z[1,2,6]  R768      -4.0848350524902344e-01
    z[1,2,6]  R769      -2.7487668395042419e-01
    z[1,2,6]  R770      -2.3937320336699486e-02
    z[1,2,6]  R771      -8.3725750446319580e-02
    z[1,2,6]  R772      -1.6932488977909088e-01
    z[1,2,6]  R773      8.9579321444034576e-02
    z[1,2,6]  R774      -3.2548922300338745e-01
    z[1,2,6]  R775      5.2447974681854248e-01
    z[1,2,6]  R776      -2.0602095872163773e-02
    z[1,2,6]  R777      -0.640866756439209
    z[1,2,6]  R778      -1.3373306393623352e-01
    z[1,2,6]  R779      -3.6413770914077759e-01
    z[1,2,6]  R780      4.9902126193046570e-01
    z[1,2,6]  R781      -2.0717842876911163e-01
    z[1,2,6]  R782      0.100248783826828
    z[1,2,6]  R783      -1.3530507683753967e-01
    z[1,2,6]  R784      -3.4942036867141724e-01
    z[1,2,6]  R785      -0.0379759818315506
    z[1,2,6]  R786      1.4620022475719452e-01
    z[1,2,6]  R787      1.9696770608425140e-01
    z[1,2,6]  R788      -4.0968382358551025e-01
    z[1,2,6]  R789      -4.4251814484596252e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R790      -1
    z[2,1,0]  R791      1
    z[2,1,0]  R804      2.0168526470661163e-01
    z[2,1,0]  R805      7.4236601591110229e-01
    z[2,1,0]  R806      6.3519030809402466e-01
    z[2,1,0]  R807      8.2694751024246216e-01
    z[2,1,0]  R808      0.732430636882782
    z[2,1,0]  R809      6.9434732198715210e-01
    z[2,1,0]  R810      5.0212305784225464e-01
    z[2,1,0]  R811      5.2095401287078857e-01
    z[2,1,0]  R812      5.2552109956741333e-01
    z[2,1,0]  R813      0.565981388092041
    z[2,1,0]  R814      -2.8693279623985291e-01
    z[2,1,0]  R815      -2.2875705361366272e-01
    z[2,1,0]  R816      -3.7252682447433472e-01
    z[2,1,0]  R817      -3.4144580364227295e-02
    z[2,1,0]  R818      -1.2130939960479736e-01
    z[2,1,0]  R819      -0.24737648665905
    z[2,1,0]  R820      -3.2693052291870117e-01
    z[2,1,0]  R821      -7.0166802406311035e-01
    z[2,1,0]  R822      -5.1734834909439087e-01
    z[2,1,0]  R823      -6.8399560451507568e-01
    z[2,1,0]  R824      2.5814792513847351e-01
    z[2,1,0]  R825      2.5163169950246811e-02
    z[2,1,0]  R826      -2.8755296953022480e-03
    z[2,1,0]  R827      -9.6380099654197693e-02
    z[2,1,0]  R828      5.5131424218416214e-02
    z[2,1,0]  R829      -3.4453833103179932e-01
    z[2,1,0]  R830      3.0919777229428291e-02
    z[2,1,0]  R831      4.4574152678251266e-02
    z[2,1,0]  R832      -2.1453756093978882e-01
    z[2,1,0]  R833      -4.7364017367362976e-01
    z[2,1,0]  R834      4.5386686921119690e-01
    z[2,1,0]  R835      5.7206705212593079e-02
    z[2,1,0]  R836      -2.5209262967109680e-01
    z[2,1,0]  R837      1.3466119766235352e-02
    z[2,1,0]  R838      -3.8344639539718628e-01
    z[2,1,0]  R839      -1.2124659866094589e-01
    z[2,1,0]  R840      -4.3595591187477112e-01
    z[2,1,0]  R841      -3.0036526918411255e-01
    z[2,1,0]  R842      1.9480532407760620e-01
    z[2,1,0]  R843      -1.3827045261859894e-01
    z[2,1,0]  R844      2.8657663613557816e-02
    z[2,1,0]  R845      2.7474978566169739e-01
    z[2,1,0]  R846      -5.2531582117080688e-01
    z[2,1,0]  R847      -4.8632583022117615e-01
    z[2,1,0]  R848      3.1036838889122009e-01
    z[2,1,0]  R849      -5.6225264072418213e-01
    z[2,1,0]  R850      9.9852740764617920e-02
    z[2,1,0]  R851      7.0530459284782410e-02
    z[2,1,0]  R852      -2.4579961597919464e-01
    z[2,1,0]  R853      -5.8534210920333862e-01
    z[2,1,0]  R854      -4.9690928310155869e-02
    z[2,1,0]  R855      -5.8148401975631714e-01
    z[2,1,0]  R856      -1.1177226155996323e-01
    z[2,1,0]  R857      -6.1769241094589233e-01
    z[2,1,0]  R858      1.4331138134002686e-01
    z[2,1,0]  R859      6.5243035554885864e-01
    z[2,1,0]  R860      6.3770312070846558e-01
    z[2,1,0]  R861      2.9630595818161964e-02
    z[2,1,0]  R862      4.4086730480194092e-01
    z[2,1,0]  R863      2.9334232211112976e-01
    z[2,1,0]  R864      1.6809152066707611e-01
    z[2,1,0]  R865      -0.023863660171628
    z[2,1,0]  R866      -1.1202633380889893e-01
    z[2,1,0]  R867      1.9880126416683197e-01
    z[2,1,0]  R868      -1.3381104171276093e-01
    z[2,1,0]  R869      -7.3125801980495453e-02
    z[2,1,0]  R870      -1.5840733423829079e-02
    z[2,1,0]  R871      1.9686248898506165e-01
    z[2,1,0]  R872      2.2745615243911743e-01
    z[2,1,0]  R873      -6.1484247446060181e-01
    z[2,1,0]  R874      1.7498087882995605e-01
    z[2,1,0]  R875      8.2255318760871887e-02
    z[2,1,0]  R876      -2.1478015184402466e-01
    z[2,1,0]  R877      -1.9356778264045715e-01
    z[2,1,0]  R878      3.4069761633872986e-02
    z[2,1,0]  R879      1.0933275334537029e-02
    z[2,1,0]  R880      3.0830252170562744e-01
    z[2,1,0]  R881      4.4244241714477539e-01
    z[2,1,0]  R882      5.9359449893236160e-02
    z[2,1,0]  R883      6.1092221736907959e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R792      -1
    z[2,1,1]  R793      1
    z[2,1,1]  R804      -8.1922346353530884e-01
    z[2,1,1]  R805      4.4056215882301331e-01
    z[2,1,1]  R806      5.2807974815368652e-01
    z[2,1,1]  R807      4.5687785744667053e-01
    z[2,1,1]  R808      4.2076438665390015e-01
    z[2,1,1]  R809      4.7686314582824707e-01
    z[2,1,1]  R810      5.5727756023406982e-01
    z[2,1,1]  R811      0.628750741481781
    z[2,1,1]  R812      0.564632773399353
    z[2,1,1]  R813      5.0390481948852539e-01
    z[2,1,1]  R814      9.3186748027801514e-01
    z[2,1,1]  R815      8.1989574432373047e-01
    z[2,1,1]  R816      6.3152486085891724e-01
    z[2,1,1]  R817      0.871233344078064
    z[2,1,1]  R818      6.4237689971923828e-01
    z[2,1,1]  R819      5.5604827404022217e-01
    z[2,1,1]  R820      0.612606406211853
    z[2,1,1]  R821      2.4693058431148529e-01
    z[2,1,1]  R822      1.0127270966768265e-01
    z[2,1,1]  R823      4.4768798351287842e-01
    z[2,1,1]  R824      0.767442524433136
    z[2,1,1]  R825      -0.16782146692276
    z[2,1,1]  R826      -0.505316972732544
    z[2,1,1]  R827      -6.2347787618637085e-01
    z[2,1,1]  R828      -5.5880290269851685e-01
    z[2,1,1]  R829      -6.9875997304916382e-01
    z[2,1,1]  R830      -5.7810330390930176e-01
    z[2,1,1]  R831      6.2407189607620239e-01
    z[2,1,1]  R832      -0.574478030204773
    z[2,1,1]  R833      6.3457864522933960e-01
    z[2,1,1]  R834      8.3791959285736084e-01
    z[2,1,1]  R835      -7.3148196935653687e-01
    z[2,1,1]  R836      -8.3641594648361206e-01
    z[2,1,1]  R837      -5.9700292348861694e-01
    z[2,1,1]  R838      -7.0138669013977051e-01
    z[2,1,1]  R839      -0.52411288022995
    z[2,1,1]  R840      -5.8007371425628662e-01
    z[2,1,1]  R841      -5.7386624813079834e-01
    z[2,1,1]  R842      -7.1420305967330933e-01
    z[2,1,1]  R843      -0.469468891620636
    z[2,1,1]  R844      -6.7077857255935669e-01
    z[2,1,1]  R845      4.9553334712982178e-01
    z[2,1,1]  R846      6.4749163389205933e-01
    z[2,1,1]  R847      7.4309313297271729e-01
    z[2,1,1]  R848      -6.7778146266937256e-01
    z[2,1,1]  R849      -1.6208501160144806e-01
    z[2,1,1]  R850      3.5068961977958679e-01
    z[2,1,1]  R851      -4.7770828008651733e-01
    z[2,1,1]  R852      5.9483128786087036e-01
    z[2,1,1]  R853      4.7563686966896057e-01
    z[2,1,1]  R854      -7.3943519592285156e-01
    z[2,1,1]  R855      -5.7814192771911621e-01
    z[2,1,1]  R856      -4.6810141205787659e-01
    z[2,1,1]  R857      -2.7959123253822327e-01
    z[2,1,1]  R858      -3.9454612135887146e-01
    z[2,1,1]  R859      5.4222857952117920e-01
    z[2,1,1]  R860      5.4430902004241943e-01
    z[2,1,1]  R861      8.7147343158721924e-01
    z[2,1,1]  R862      6.8491917848587036e-01
    z[2,1,1]  R863      5.4950064420700073e-01
    z[2,1,1]  R864      0.711979329586029
    z[2,1,1]  R865      7.1186983585357666e-01
    z[2,1,1]  R866      6.6931933164596558e-01
    z[2,1,1]  R867      7.8237426280975342e-01
    z[2,1,1]  R868      5.9923851490020752e-01
    z[2,1,1]  R869      5.4216337203979492e-01
    z[2,1,1]  R870      4.3436288833618164e-01
    z[2,1,1]  R871      3.3971610665321350e-01
    z[2,1,1]  R872      -8.9301742613315582e-02
    z[2,1,1]  R873      2.7429884672164917e-01
    z[2,1,1]  R874      8.6199837923049927e-01
    z[2,1,1]  R875      7.5430279970169067e-01
    z[2,1,1]  R876      7.6275277137756348e-01
    z[2,1,1]  R877      7.1205347776412964e-01
    z[2,1,1]  R878      7.1167606115341187e-01
    z[2,1,1]  R879      6.6217201948165894e-01
    z[2,1,1]  R880      1.9006147980690002e-01
    z[2,1,1]  R881      6.9651387631893158e-02
    z[2,1,1]  R882      1.0630601644515991e-01
    z[2,1,1]  R883      -3.3505043387413025e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R794      -1
    z[2,1,2]  R795      1
    z[2,1,2]  R804      -7.8870102763175964e-02
    z[2,1,2]  R805      3.3070746064186096e-01
    z[2,1,2]  R806      1.0235553234815598e-01
    z[2,1,2]  R807      4.6049594879150391e-02
    z[2,1,2]  R808      1.6168086230754852e-01
    z[2,1,2]  R809      6.3644699752330780e-02
    z[2,1,2]  R810      5.4390218108892441e-02
    z[2,1,2]  R811      -1.9460545480251312e-01
    z[2,1,2]  R812      -8.8420659303665161e-02
    z[2,1,2]  R813      1.1523006111383438e-01
    z[2,1,2]  R814      -7.1286588907241821e-02
    z[2,1,2]  R815      5.5369723588228226e-02
    z[2,1,2]  R816      -4.8150178790092468e-01
    z[2,1,2]  R817      -6.6612720489501953e-02
    z[2,1,2]  R818      -6.5477684140205383e-02
    z[2,1,2]  R819      1.3341930508613586e-01
    z[2,1,2]  R820      -0.0082245459780097
    z[2,1,2]  R821      -2.3293124139308929e-01
    z[2,1,2]  R822      -2.2015622258186340e-01
    z[2,1,2]  R823      -1.5303435921669006e-01
    z[2,1,2]  R824      1.9586192071437836e-01
    z[2,1,2]  R825      7.5157051905989647e-03
    z[2,1,2]  R826      3.2421614974737167e-02
    z[2,1,2]  R827      -5.8069300651550293e-01
    z[2,1,2]  R828      -1.3434453867375851e-02
    z[2,1,2]  R829      5.5135834962129593e-02
    z[2,1,2]  R830      -1.0406474769115448e-01
    z[2,1,2]  R831      -2.2813172638416290e-01
    z[2,1,2]  R832      1.0440982878208160e-01
    z[2,1,2]  R833      3.7115357816219330e-02
    z[2,1,2]  R834      4.1516300290822983e-02
    z[2,1,2]  R835      2.5107404589653015e-01
    z[2,1,2]  R836      -1.9405621290206909e-01
    z[2,1,2]  R837      -5.8411568403244019e-01
    z[2,1,2]  R838      4.2978670448064804e-02
    z[2,1,2]  R839      9.5384582877159119e-02
    z[2,1,2]  R840      -5.3315126895904541e-01
    z[2,1,2]  R841      -0.0327596440911293
    z[2,1,2]  R842      -1.1553891003131866e-01
    z[2,1,2]  R843      -1.4035994186997414e-02
    z[2,1,2]  R844      -1.4211086928844452e-01
    z[2,1,2]  R845      0.749748706817627
    z[2,1,2]  R846      -2.3999287188053131e-01
    z[2,1,2]  R847      -2.7160859107971191e-01
    z[2,1,2]  R848      2.1083752810955048e-01
    z[2,1,2]  R849      -1.4375127851963043e-01
    z[2,1,2]  R850      7.2836279869079590e-01
    z[2,1,2]  R851      -7.1535813808441162e-01
    z[2,1,2]  R852      -9.4469018280506134e-02
    z[2,1,2]  R853      4.9765370786190033e-02
    z[2,1,2]  R854      -1.9925607740879059e-01
    z[2,1,2]  R855      -3.2785028219223022e-01
    z[2,1,2]  R856      -7.2761642932891846e-01
    z[2,1,2]  R857      7.2494186460971832e-02
    z[2,1,2]  R858      9.0446047484874725e-02
    z[2,1,2]  R859      -3.4528259187936783e-02
    z[2,1,2]  R860      8.5024453699588776e-02
    z[2,1,2]  R861      2.3083847761154175e-01
    z[2,1,2]  R862      2.1506215631961823e-01
    z[2,1,2]  R863      -2.6834979653358459e-01
    z[2,1,2]  R864      -2.7630642056465149e-02
    z[2,1,2]  R865      -4.4226527214050293e-01
    z[2,1,2]  R866      1.0201875865459442e-01
    z[2,1,2]  R867      -0.326465904712677
    z[2,1,2]  R868      -6.1449509859085083e-01
    z[2,1,2]  R869      -3.5805395245552063e-01
    z[2,1,2]  R870      1.8681395053863525e-01
    z[2,1,2]  R871      -5.6713706254959106e-01
    z[2,1,2]  R872      7.0076537132263184e-01
    z[2,1,2]  R873      -8.1679157912731171e-02
    z[2,1,2]  R874      7.4630357325077057e-02
    z[2,1,2]  R875      -3.0827391147613525e-01
    z[2,1,2]  R876      -1.6502179205417633e-01
    z[2,1,2]  R877      -5.4879003763198853e-01
    z[2,1,2]  R878      -4.3301945924758911e-01
    z[2,1,2]  R879      -5.0865966081619263e-01
    z[2,1,2]  R880      6.4753150939941406e-01
    z[2,1,2]  R881      6.5141016244888306e-01
    z[2,1,2]  R882      9.0096151828765869e-01
    z[2,1,2]  R883      2.7205786108970642e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R796      -1
    z[2,1,3]  R797      1
    z[2,1,3]  R804      -3.8251541554927826e-02
    z[2,1,3]  R805      -3.0787003040313721e-01
    z[2,1,3]  R806      2.3503266274929047e-01
    z[2,1,3]  R807      2.3451916873455048e-01
    z[2,1,3]  R808      -1.1217866092920303e-01
    z[2,1,3]  R809      0.0248641986399889
    z[2,1,3]  R810      1.1310722678899765e-01
    z[2,1,3]  R811      -1.2516199052333832e-01
    z[2,1,3]  R812      7.1494663134217262e-03
    z[2,1,3]  R813      2.7653848752379417e-02
    z[2,1,3]  R814      -4.1430920362472534e-02
    z[2,1,3]  R815      -1.9567583501338959e-01
    z[2,1,3]  R816      -2.8022894263267517e-01
    z[2,1,3]  R817      -2.2264190018177032e-01
    z[2,1,3]  R818      -6.3048821687698364e-01
    z[2,1,3]  R819      -7.3469519615173340e-01
    z[2,1,3]  R820      -0.543587863445282
    z[2,1,3]  R821      -4.9522459506988525e-01
    z[2,1,3]  R822      -5.8769422769546509e-01
    z[2,1,3]  R823      -2.8840306401252747e-01
    z[2,1,3]  R824      4.0296044945716858e-01
    z[2,1,3]  R825      0.89235919713974
    z[2,1,3]  R826      5.9119653701782227e-01
    z[2,1,3]  R827      -4.9092669039964676e-02
    z[2,1,3]  R828      3.3295041322708130e-01
    z[2,1,3]  R829      -4.7149640321731567e-01
    z[2,1,3]  R830      6.3730108737945557e-01
    z[2,1,3]  R831      -4.3858282268047333e-02
    z[2,1,3]  R832      2.3298986256122589e-01
    z[2,1,3]  R833      4.6260673552751541e-02
    z[2,1,3]  R834      1.3171857595443726e-01
    z[2,1,3]  R835      1.4769986271858215e-01
    z[2,1,3]  R836      -3.4857848286628723e-01
    z[2,1,3]  R837      4.8908573389053345e-01
    z[2,1,3]  R838      1.0993672162294388e-01
    z[2,1,3]  R839      0.512146532535553
    z[2,1,3]  R840      8.0749049782752991e-02
    z[2,1,3]  R841      2.6764547824859619e-01
    z[2,1,3]  R842      0.00896703451871872
    z[2,1,3]  R843      7.1413886547088623e-01
    z[2,1,3]  R844      2.2266833484172821e-01
    z[2,1,3]  R845      1.3229785859584808e-01
    z[2,1,3]  R846      -4.2385622859001160e-01
    z[2,1,3]  R847      -1.5113075077533722e-01
    z[2,1,3]  R848      -1.3371877372264862e-01
    z[2,1,3]  R849      -0.685263454914093
    z[2,1,3]  R850      2.9402244091033936e-01
    z[2,1,3]  R851      -0.0520898774266243
    z[2,1,3]  R852      -0.322995126247406
    z[2,1,3]  R853      -4.4619762897491455e-01
    z[2,1,3]  R854      4.1571286320686340e-01
    z[2,1,3]  R855      5.2801431156694889e-03
    z[2,1,3]  R856      2.3760001361370087e-01
    z[2,1,3]  R857      4.4579803943634033e-01
    z[2,1,3]  R858      4.1010746359825134e-01
    z[2,1,3]  R859      0.0699441209435463
    z[2,1,3]  R860      -2.7111726999282837e-01
    z[2,1,3]  R861      3.5323426127433777e-03
    z[2,1,3]  R862      -1.5383604168891907e-01
    z[2,1,3]  R863      -4.1269126534461975e-01
    z[2,1,3]  R864      -7.1397058665752411e-02
    z[2,1,3]  R865      1.3254101388156414e-02
    z[2,1,3]  R866      -0.062924325466156
    z[2,1,3]  R867      2.9293122887611389e-01
    z[2,1,3]  R868      6.8340882658958435e-02
    z[2,1,3]  R869      -1.5282213687896729e-01
    z[2,1,3]  R870      -7.1344166994094849e-01
    z[2,1,3]  R871      -4.9946320056915283e-01
    z[2,1,3]  R872      -5.0770968198776245e-01
    z[2,1,3]  R873      -5.8048856258392334e-01
    z[2,1,3]  R874      -2.9847297072410583e-01
    z[2,1,3]  R875      5.1173716783523560e-01
    z[2,1,3]  R876      3.4743675589561462e-01
    z[2,1,3]  R877      -4.6729825437068939e-02
    z[2,1,3]  R878      -1.2129744887351990e-01
    z[2,1,3]  R879      1.2098416686058044e-01
    z[2,1,3]  R880      -6.5261560678482056e-01
    z[2,1,3]  R881      -3.6690777540206909e-01
    z[2,1,3]  R882      -1.4384835958480835e-01
    z[2,1,3]  R883      -3.5192090272903442e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R798      -1
    z[2,1,4]  R799      1
    z[2,1,4]  R804      7.3111318051815033e-02
    z[2,1,4]  R805      -1.1375582218170166e-01
    z[2,1,4]  R806      -8.2537800073623657e-02
    z[2,1,4]  R807      -1.7899218201637268e-01
    z[2,1,4]  R808      8.0192521214485168e-02
    z[2,1,4]  R809      -3.0449113249778748e-01
    z[2,1,4]  R810      -1.2869222462177277e-01
    z[2,1,4]  R811      -4.6238997578620911e-01
    z[2,1,4]  R812      -4.5858058333396912e-01
    z[2,1,4]  R813      0.305789053440094
    z[2,1,4]  R814      -0.0898180678486824
    z[2,1,4]  R815      -3.7596827745437622e-01
    z[2,1,4]  R816      -3.4587970376014709e-01
    z[2,1,4]  R817      -4.2784112691879272e-01
    z[2,1,4]  R818      -1.5457729995250702e-01
    z[2,1,4]  R819      -2.0413650572299957e-01
    z[2,1,4]  R820      -0.0776323527097702
    z[2,1,4]  R821      1.2053133547306061e-01
    z[2,1,4]  R822      -2.6265475153923035e-01
    z[2,1,4]  R823      2.7353662252426147e-01
    z[2,1,4]  R824      -2.8498631715774536e-01
    z[2,1,4]  R825      4.1087669134140015e-01
    z[2,1,4]  R826      -2.8536498546600342e-01
    z[2,1,4]  R827      -2.8570872545242310e-01
    z[2,1,4]  R828      -4.2396214604377747e-01
    z[2,1,4]  R829      -9.6188765019178391e-03
    z[2,1,4]  R830      3.5438543558120728e-01
    z[2,1,4]  R831      -2.7970872819423676e-02
    z[2,1,4]  R832      5.9508824348449707e-01
    z[2,1,4]  R833      5.2050441503524780e-01
    z[2,1,4]  R834      2.5748616456985474e-01
    z[2,1,4]  R835      -2.1077752113342285e-01
    z[2,1,4]  R836      2.1719934046268463e-01
    z[2,1,4]  R837      2.3210911080241203e-02
    z[2,1,4]  R838      2.5619903206825256e-01
    z[2,1,4]  R839      -2.3334741592407227e-01
    z[2,1,4]  R840      3.4386062622070312e-01
    z[2,1,4]  R841      2.8850868344306946e-01
    z[2,1,4]  R842      2.9008671641349792e-01
    z[2,1,4]  R843      2.1807883679866791e-01
    z[2,1,4]  R844      3.7299329042434692e-01
    z[2,1,4]  R845      3.3229142427444458e-02
    z[2,1,4]  R846      0.216078981757164
    z[2,1,4]  R847      2.6762318611145020e-01
    z[2,1,4]  R848      -1.2383381277322769e-01
    z[2,1,4]  R849      -7.6574023114517331e-04
    z[2,1,4]  R850      3.4473296999931335e-01
    z[2,1,4]  R851      -4.5324954390525818e-01
    z[2,1,4]  R852      -9.6704736351966858e-03
    z[2,1,4]  R853      1.6221849620342255e-01
    z[2,1,4]  R854      -1.9522084295749664e-01
    z[2,1,4]  R855      -5.5625919252634048e-02
    z[2,1,4]  R856      -1.1468805372714996e-01
    z[2,1,4]  R857      2.8277322649955750e-01
    z[2,1,4]  R858      -4.1842761635780334e-01
    z[2,1,4]  R859      -5.1813744008541107e-02
    z[2,1,4]  R860      1.5262334048748016e-01
    z[2,1,4]  R861      -3.9830081164836884e-02
    z[2,1,4]  R862      -3.4797763824462891e-01
    z[2,1,4]  R863      -1.8198819458484650e-01
    z[2,1,4]  R864      5.0782209634780884e-01
    z[2,1,4]  R865      5.0541943311691284e-01
    z[2,1,4]  R866      7.0441913604736328e-01
    z[2,1,4]  R867      1.5030542016029358e-01
    z[2,1,4]  R868      1.8428441882133484e-01
    z[2,1,4]  R869      0.532706618309021
    z[2,1,4]  R870      4.6939682960510254e-01
    z[2,1,4]  R871      -1.0630524903535843e-01
    z[2,1,4]  R872      -1.1071750521659851e-01
    z[2,1,4]  R873      -3.0283406376838684e-03
    z[2,1,4]  R874      1.0974252223968506e-01
    z[2,1,4]  R875      -1.2475372105836868e-01
    z[2,1,4]  R876      2.1234643459320068e-01
    z[2,1,4]  R877      1.4340290427207947e-01
    z[2,1,4]  R878      4.1452908515930176e-01
    z[2,1,4]  R879      -2.9557171463966370e-01
    z[2,1,4]  R880      1.0928661562502384e-02
    z[2,1,4]  R881      -3.0401936173439026e-01
    z[2,1,4]  R882      1.9716110825538635e-01
    z[2,1,4]  R883      4.9992737174034119e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R800      -1
    z[2,1,5]  R801      1
    z[2,1,5]  R804      -2.0992338657379150e-01
    z[2,1,5]  R805      6.0002353042364120e-02
    z[2,1,5]  R806      2.1711468696594238e-01
    z[2,1,5]  R807      2.1944953128695488e-02
    z[2,1,5]  R808      -3.0375117063522339e-01
    z[2,1,5]  R809      0.174501433968544
    z[2,1,5]  R810      -4.4397312402725220e-01
    z[2,1,5]  R811      -1.2243715673685074e-01
    z[2,1,5]  R812      -4.3224963545799255e-01
    z[2,1,5]  R813      1.7003849148750305e-01
    z[2,1,5]  R814      -1.8312266469001770e-01
    z[2,1,5]  R815      -4.2208548984490335e-04
    z[2,1,5]  R816      -1.7857927083969116e-01
    z[2,1,5]  R817      1.4842978678643703e-02
    z[2,1,5]  R818      -6.8562075495719910e-02
    z[2,1,5]  R819      -1.3925287127494812e-01
    z[2,1,5]  R820      -3.6532059311866760e-01
    z[2,1,5]  R821      -3.4194344282150269e-01
    z[2,1,5]  R822      -5.0903332233428955e-01
    z[2,1,5]  R823      -3.8409563899040222e-01
    z[2,1,5]  R824      2.0312181115150452e-01
    z[2,1,5]  R825      -2.6462316513061523e-02
    z[2,1,5]  R826      -1.6600729897618294e-02
    z[2,1,5]  R827      2.4125227332115173e-01
    z[2,1,5]  R828      4.7427029348909855e-03
    z[2,1,5]  R829      -1.4630095660686493e-01
    z[2,1,5]  R830      1.6965536773204803e-01
    z[2,1,5]  R831      6.9013011455535889e-01
    z[2,1,5]  R832      1.9435566663742065e-01
    z[2,1,5]  R833      1.5157592296600342e-01
    z[2,1,5]  R834      7.7136784791946411e-02
    z[2,1,5]  R835      -5.7041305303573608e-01
    z[2,1,5]  R836      4.2971007525920868e-02
    z[2,1,5]  R837      2.3333853483200073e-01
    z[2,1,5]  R838      -4.1894045472145081e-01
    z[2,1,5]  R839      3.3118382096290588e-01
    z[2,1,5]  R840      -2.5302490592002869e-01
    z[2,1,5]  R841      1.1748849600553513e-01
    z[2,1,5]  R842      5.8008664846420288e-01
    z[2,1,5]  R843      -2.6482850313186646e-01
    z[2,1,5]  R844      3.0217874050140381e-01
    z[2,1,5]  R845      2.3517285287380219e-01
    z[2,1,5]  R846      -1.0395722091197968e-01
    z[2,1,5]  R847      0.1573476344347
    z[2,1,5]  R848      4.9449086189270020e-01
    z[2,1,5]  R849      -4.0731698274612427e-01
    z[2,1,5]  R850      -3.3146545290946960e-01
    z[2,1,5]  R851      -9.0212017297744751e-02
    z[2,1,5]  R852      5.5188196897506714e-01
    z[2,1,5]  R853      8.6244657635688782e-02
    z[2,1,5]  R854      4.5144062489271164e-02
    z[2,1,5]  R855      5.1510158926248550e-02
    z[2,1,5]  R856      -3.9596560597419739e-01
    z[2,1,5]  R857      -3.4057098627090454e-01
    z[2,1,5]  R858      -6.3107395172119141e-01
    z[2,1,5]  R859      -1.0247718542814255e-01
    z[2,1,5]  R860      -3.4925499558448792e-01
    z[2,1,5]  R861      4.0217429399490356e-01
    z[2,1,5]  R862      -1.4051049947738647e-01
    z[2,1,5]  R863      -2.4994817376136780e-01
    z[2,1,5]  R864      -4.4802263379096985e-01
    z[2,1,5]  R865      -2.0324413478374481e-01
    z[2,1,5]  R866      -1.0597249493002892e-02
    z[2,1,5]  R867      -3.6264079809188843e-01
    z[2,1,5]  R868      4.3007194995880127e-01
    z[2,1,5]  R869      3.4774327278137207e-01
    z[2,1,5]  R870      5.7146232575178146e-02
    z[2,1,5]  R871      5.0299829244613647e-01
    z[2,1,5]  R872      3.9705076813697815e-01
    z[2,1,5]  R873      -4.2692460119724274e-02
    z[2,1,5]  R874      -5.0250776112079620e-02
    z[2,1,5]  R875      1.9489030539989471e-01
    z[2,1,5]  R876      4.0899339318275452e-01
    z[2,1,5]  R877      1.7612640559673309e-01
    z[2,1,5]  R878      2.3359447717666626e-01
    z[2,1,5]  R879      4.1298249363899231e-01
    z[2,1,5]  R880      2.2846752777695656e-02
    z[2,1,5]  R881      2.2896414995193481e-01
    z[2,1,5]  R882      0.241278275847435
    z[2,1,5]  R883      2.1940311789512634e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R802      -1
    z[2,1,6]  R803      1
    z[2,1,6]  R804      4.8072773218154907e-01
    z[2,1,6]  R805      1.8467712402343750e-01
    z[2,1,6]  R806      4.4496819376945496e-01
    z[2,1,6]  R807      -1.3334497809410095e-01
    z[2,1,6]  R808      -3.8611200451850891e-01
    z[2,1,6]  R809      4.0329754352569580e-01
    z[2,1,6]  R810      -4.5594829320907593e-01
    z[2,1,6]  R811      -2.2571486234664917e-01
    z[2,1,6]  R812      3.4922768827527761e-03
    z[2,1,6]  R813      5.3784966468811035e-01
    z[2,1,6]  R814      2.9884090647101402e-02
    z[2,1,6]  R815      -3.0452278256416321e-01
    z[2,1,6]  R816      2.2463712841272354e-02
    z[2,1,6]  R817      5.0114914774894714e-02
    z[2,1,6]  R818      3.7714502215385437e-01
    z[2,1,6]  R819      1.0475924611091614e-01
    z[2,1,6]  R820      2.8772982954978943e-01
    z[2,1,6]  R821      -1.2541884183883667e-01
    z[2,1,6]  R822      -1.1786801740527153e-02
    z[2,1,6]  R823      -5.2705653011798859e-02
    z[2,1,6]  R824      -1.4552329480648041e-01
    z[2,1,6]  R825      -7.2948947548866272e-02
    z[2,1,6]  R826      -5.5890363454818726e-01
    z[2,1,6]  R827      -3.5005655884742737e-01
    z[2,1,6]  R828      -6.2761205434799194e-01
    z[2,1,6]  R829      -0.382338285446167
    z[2,1,6]  R830      -3.0575555562973022e-01
    z[2,1,6]  R831      -2.7842029929161072e-01
    z[2,1,6]  R832      -4.0848350524902344e-01
    z[2,1,6]  R833      -2.7487668395042419e-01
    z[2,1,6]  R834      -2.3937320336699486e-02
    z[2,1,6]  R835      -8.3725750446319580e-02
    z[2,1,6]  R836      -1.6932488977909088e-01
    z[2,1,6]  R837      8.9579321444034576e-02
    z[2,1,6]  R838      -3.2548922300338745e-01
    z[2,1,6]  R839      5.2447974681854248e-01
    z[2,1,6]  R840      -2.0602095872163773e-02
    z[2,1,6]  R841      -0.640866756439209
    z[2,1,6]  R842      -1.3373306393623352e-01
    z[2,1,6]  R843      -3.6413770914077759e-01
    z[2,1,6]  R844      4.9902126193046570e-01
    z[2,1,6]  R845      -2.0717842876911163e-01
    z[2,1,6]  R846      0.100248783826828
    z[2,1,6]  R847      -1.3530507683753967e-01
    z[2,1,6]  R848      -3.4942036867141724e-01
    z[2,1,6]  R849      -0.0379759818315506
    z[2,1,6]  R850      1.4620022475719452e-01
    z[2,1,6]  R851      1.9696770608425140e-01
    z[2,1,6]  R852      -4.0968382358551025e-01
    z[2,1,6]  R853      -4.4251814484596252e-01
    z[2,1,6]  R854      4.4508108496665955e-01
    z[2,1,6]  R855      -4.6299800276756287e-01
    z[2,1,6]  R856      -1.1209972202777863e-01
    z[2,1,6]  R857      -3.7462544441223145e-01
    z[2,1,6]  R858      -2.7219581604003906e-01
    z[2,1,6]  R859      5.1093274354934692e-01
    z[2,1,6]  R860      2.6656261086463928e-01
    z[2,1,6]  R861      -1.5174549818038940e-01
    z[2,1,6]  R862      -3.5464456677436829e-01
    z[2,1,6]  R863      -5.2352637052536011e-01
    z[2,1,6]  R864      -1.9029730930924416e-02
    z[2,1,6]  R865      1.1859763413667679e-02
    z[2,1,6]  R866      1.6963452100753784e-01
    z[2,1,6]  R867      -4.3357063084840775e-02
    z[2,1,6]  R868      1.4768348634243011e-01
    z[2,1,6]  R869      3.8006898760795593e-01
    z[2,1,6]  R870      -0.208759143948555
    z[2,1,6]  R871      1.0208845883607864e-01
    z[2,1,6]  R872      1.4676529169082642e-01
    z[2,1,6]  R873      4.4861856102943420e-01
    z[2,1,6]  R874      -3.4222227334976196e-01
    z[2,1,6]  R875      1.1750672757625580e-01
    z[2,1,6]  R876      1.0847406834363937e-01
    z[2,1,6]  R877      -3.1713131070137024e-01
    z[2,1,6]  R878      2.5246149301528931e-01
    z[2,1,6]  R879      -1.7355036735534668e-01
    z[2,1,6]  R880      -1.5159356594085693e-01
    z[2,1,6]  R881      3.0916744470596313e-01
    z[2,1,6]  R882      2.3593175411224365e-01
    z[2,1,6]  R883      -1.3633179664611816e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R884      -1
    z[1,3,0]  R885      1
    z[1,3,0]  R898      -4.9690928310155869e-02
    z[1,3,0]  R899      -5.8148401975631714e-01
    z[1,3,0]  R900      -1.1177226155996323e-01
    z[1,3,0]  R901      -6.1769241094589233e-01
    z[1,3,0]  R902      1.4331138134002686e-01
    z[1,3,0]  R903      6.5243035554885864e-01
    z[1,3,0]  R904      6.3770312070846558e-01
    z[1,3,0]  R905      2.9630595818161964e-02
    z[1,3,0]  R906      4.4086730480194092e-01
    z[1,3,0]  R907      2.9334232211112976e-01
    z[1,3,0]  R908      1.6809152066707611e-01
    z[1,3,0]  R909      -0.023863660171628
    z[1,3,0]  R910      -1.1202633380889893e-01
    z[1,3,0]  R911      1.9880126416683197e-01
    z[1,3,0]  R912      -1.3381104171276093e-01
    z[1,3,0]  R913      -7.3125801980495453e-02
    z[1,3,0]  R914      -1.5840733423829079e-02
    z[1,3,0]  R915      1.9686248898506165e-01
    z[1,3,0]  R916      2.2745615243911743e-01
    z[1,3,0]  R917      -6.1484247446060181e-01
    z[1,3,0]  R918      1.7498087882995605e-01
    z[1,3,0]  R919      8.2255318760871887e-02
    z[1,3,0]  R920      -2.1478015184402466e-01
    z[1,3,0]  R921      -1.9356778264045715e-01
    z[1,3,0]  R922      3.4069761633872986e-02
    z[1,3,0]  R923      1.0933275334537029e-02
    z[1,3,0]  R924      3.0830252170562744e-01
    z[1,3,0]  R925      4.4244241714477539e-01
    z[1,3,0]  R926      5.9359449893236160e-02
    z[1,3,0]  R927      6.1092221736907959e-01
    z[1,3,0]  R928      -9.0111321210861206e-01
    z[1,3,0]  R929      -6.0407590866088867e-01
    z[1,3,0]  R930      -6.1722850799560547e-01
    z[1,3,0]  R931      -3.1324347853660583e-01
    z[1,3,0]  R932      1.8402388691902161e-01
    z[1,3,0]  R933      3.5888195037841797e-01
    z[1,3,0]  R934      1.2001663446426392e-01
    z[1,3,0]  R935      3.3409410715103149e-01
    z[1,3,0]  R936      1.7947991192340851e-01
    z[1,3,0]  R937      6.3400840759277344e-01
    z[1,3,0]  R938      -1.9765214622020721e-01
    z[1,3,0]  R939      -1.7510922625660896e-02
    z[1,3,0]  R940      6.6964410245418549e-02
    z[1,3,0]  R941      -2.7715164422988892e-01
    z[1,3,0]  R942      -2.5218993425369263e-01
    z[1,3,0]  R943      -3.1260257959365845e-01
    z[1,3,0]  R944      -2.3082602024078369e-01
    z[1,3,0]  R945      2.8432890772819519e-01
    z[1,3,0]  R946      -2.3441386222839355e-01
    z[1,3,0]  R947      -2.9212430119514465e-01
    z[1,3,0]  R948      1.8149070441722870e-01
    z[1,3,0]  R949      1.8245698511600494e-01
    z[1,3,0]  R950      2.0640777051448822e-01
    z[1,3,0]  R951      6.3469523191452026e-01
    z[1,3,0]  R952      1.3563279062509537e-02
    z[1,3,0]  R953      -5.5913887917995453e-02
    z[1,3,0]  R954      8.2741332054138184e-01
    z[1,3,0]  R955      8.7075871229171753e-01
    z[1,3,0]  R956      7.9749417304992676e-01
    z[1,3,0]  R957      6.9988548755645752e-01
    z[1,3,0]  R958      3.3281859010457993e-02
    z[1,3,0]  R959      2.2290296852588654e-01
    z[1,3,0]  R960      2.5331950187683105e-01
    z[1,3,0]  R961      2.9828539490699768e-01
    z[1,3,0]  R962      -5.0881292670965195e-02
    z[1,3,0]  R963      1.5746654570102692e-01
    z[1,3,0]  R964      2.3393720388412476e-01
    z[1,3,0]  R965      2.9809838533401489e-01
    z[1,3,0]  R966      -0.00982271321117878
    z[1,3,0]  R967      5.6180328130722046e-01
    z[1,3,0]  R968      4.6654570102691650e-01
    z[1,3,0]  R969      1.6208623349666595e-01
    z[1,3,0]  R970      8.7015196681022644e-02
    z[1,3,0]  R971      3.2016941905021667e-01
    z[1,3,0]  R972      -4.7110697627067566e-01
    z[1,3,0]  R973      1.8492648005485535e-01
    z[1,3,0]  R974      6.8464279174804688e-01
    z[1,3,0]  R975      7.6983755826950073e-01
    z[1,3,0]  R976      0.762596070766449
    z[1,3,0]  R977      5.2648055553436279e-01
    z[1,3,0]  R978      1.5865485370159149e-01
    z[1,3,0]  R979      -1.2692667543888092e-01
    z[1,3,0]  R980      1.6466620564460754e-01
    z[1,3,0]  R981      2.2486260533332825e-01
    z[1,3,0]  R982      9.1835662722587585e-02
    z[1,3,0]  R983      5.8491063117980957e-01
    z[1,3,0]  R984      4.2816135287284851e-01
    z[1,3,0]  R985      1.3206787407398224e-01
    z[1,3,0]  R986      -2.5663343071937561e-01
    z[1,3,0]  R987      5.6501740217208862e-01
    z[1,3,0]  R988      -1.0809303820133209e-01
    z[1,3,0]  R989      6.1006840318441391e-02
    z[1,3,0]  R990      -1.6829517483711243e-01
    z[1,3,0]  R991      5.4270672798156738e-01
    z[1,3,0]  R992      2.4762864410877228e-01
    z[1,3,0]  R993      7.2049885988235474e-01
    z[1,3,0]  R994      7.4297547340393066e-01
    z[1,3,0]  R995      8.6693710088729858e-01
    z[1,3,0]  R996      5.6837695837020874e-01
    z[1,3,0]  R997      6.9224995374679565e-01
    z[1,3,0]  R998      9.9514469504356384e-02
    z[1,3,0]  R999      3.3170798420906067e-01
    z[1,3,0]  R1000     0.807605504989624
    z[1,3,0]  R1001     7.4419957399368286e-01
    z[1,3,0]  R1002     8.3993387222290039e-01
    z[1,3,0]  R1003     7.7641081809997559e-01
    z[1,3,0]  R1004     6.3118547201156616e-01
    z[1,3,0]  R1005     2.9213285446166992e-01
    z[1,3,0]  R1006     3.0005431175231934e-01
    z[1,3,0]  R1007     2.1501564979553223e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R886      -1
    z[1,3,1]  R887      1
    z[1,3,1]  R898      -7.3943519592285156e-01
    z[1,3,1]  R899      -5.7814192771911621e-01
    z[1,3,1]  R900      -4.6810141205787659e-01
    z[1,3,1]  R901      -2.7959123253822327e-01
    z[1,3,1]  R902      -3.9454612135887146e-01
    z[1,3,1]  R903      5.4222857952117920e-01
    z[1,3,1]  R904      5.4430902004241943e-01
    z[1,3,1]  R905      8.7147343158721924e-01
    z[1,3,1]  R906      6.8491917848587036e-01
    z[1,3,1]  R907      5.4950064420700073e-01
    z[1,3,1]  R908      0.711979329586029
    z[1,3,1]  R909      7.1186983585357666e-01
    z[1,3,1]  R910      6.6931933164596558e-01
    z[1,3,1]  R911      7.8237426280975342e-01
    z[1,3,1]  R912      5.9923851490020752e-01
    z[1,3,1]  R913      5.4216337203979492e-01
    z[1,3,1]  R914      4.3436288833618164e-01
    z[1,3,1]  R915      3.3971610665321350e-01
    z[1,3,1]  R916      -8.9301742613315582e-02
    z[1,3,1]  R917      2.7429884672164917e-01
    z[1,3,1]  R918      8.6199837923049927e-01
    z[1,3,1]  R919      7.5430279970169067e-01
    z[1,3,1]  R920      7.6275277137756348e-01
    z[1,3,1]  R921      7.1205347776412964e-01
    z[1,3,1]  R922      7.1167606115341187e-01
    z[1,3,1]  R923      6.6217201948165894e-01
    z[1,3,1]  R924      1.9006147980690002e-01
    z[1,3,1]  R925      6.9651387631893158e-02
    z[1,3,1]  R926      1.0630601644515991e-01
    z[1,3,1]  R927      -3.3505043387413025e-01
    z[1,3,1]  R928      2.4428819119930267e-01
    z[1,3,1]  R929      3.5320740938186646e-01
    z[1,3,1]  R930      -1.2976975739002228e-01
    z[1,3,1]  R931      -4.0674397349357605e-01
    z[1,3,1]  R932      3.9426818490028381e-01
    z[1,3,1]  R933      -2.1566146612167358e-01
    z[1,3,1]  R934      -4.7013166546821594e-01
    z[1,3,1]  R935      6.7358978092670441e-02
    z[1,3,1]  R936      -2.8506958484649658e-01
    z[1,3,1]  R937      -4.1133868694305420e-01
    z[1,3,1]  R938      -5.8904796838760376e-01
    z[1,3,1]  R939      2.4392996728420258e-01
    z[1,3,1]  R940      5.4972273111343384e-01
    z[1,3,1]  R941      -3.5902017354965210e-01
    z[1,3,1]  R942      -3.7197881937026978e-01
    z[1,3,1]  R943      -4.5423364639282227e-01
    z[1,3,1]  R944      -3.7735033035278320e-01
    z[1,3,1]  R945      6.9945830106735229e-01
    z[1,3,1]  R946      -5.3554880619049072e-01
    z[1,3,1]  R947      -6.4004784822463989e-01
    z[1,3,1]  R948      6.9371879100799561e-01
    z[1,3,1]  R949      6.6736036539077759e-01
    z[1,3,1]  R950      8.4547966718673706e-01
    z[1,3,1]  R951      -3.8026013970375061e-01
    z[1,3,1]  R952      7.5764495134353638e-01
    z[1,3,1]  R953      7.7056729793548584e-01
    z[1,3,1]  R954      1.1965405195951462e-01
    z[1,3,1]  R955      -1.8582781776785851e-02
    z[1,3,1]  R956      1.0302767157554626e-01
    z[1,3,1]  R957      1.1012807488441467e-01
    z[1,3,1]  R958      5.0240254402160645e-01
    z[1,3,1]  R959      8.4660744667053223e-01
    z[1,3,1]  R960      7.1364217996597290e-01
    z[1,3,1]  R961      6.5825891494750977e-01
    z[1,3,1]  R962      5.7081985473632812e-01
    z[1,3,1]  R963      7.3875850439071655e-01
    z[1,3,1]  R964      2.4478116631507874e-01
    z[1,3,1]  R965      7.9243320226669312e-01
    z[1,3,1]  R966      2.5369012355804443e-01
    z[1,3,1]  R967      6.1081565916538239e-02
    z[1,3,1]  R968      4.7547537088394165e-01
    z[1,3,1]  R969      -1.3302671909332275e-01
    z[1,3,1]  R970      -3.9098069071769714e-01
    z[1,3,1]  R971      5.2504408359527588e-01
    z[1,3,1]  R972      -2.2248266637325287e-01
    z[1,3,1]  R973      4.5629009604454041e-01
    z[1,3,1]  R974      4.9592334777116776e-02
    z[1,3,1]  R975      -2.0216518640518188e-01
    z[1,3,1]  R976      -6.7359425127506256e-02
    z[1,3,1]  R977      -0.336232453584671
    z[1,3,1]  R978      -4.1369026899337769e-01
    z[1,3,1]  R979      4.6338456869125366e-01
    z[1,3,1]  R980      5.3795313835144043e-01
    z[1,3,1]  R981      -1.9572993740439415e-02
    z[1,3,1]  R982      5.3419023752212524e-01
    z[1,3,1]  R983      -9.6064776182174683e-02
    z[1,3,1]  R984      3.6720937490463257e-01
    z[1,3,1]  R985      3.1878709793090820e-01
    z[1,3,1]  R986      -1.5896326303482056e-01
    z[1,3,1]  R987      -3.8427191972732544e-01
    z[1,3,1]  R988      -2.2664600610733032e-01
    z[1,3,1]  R989      -5.3537720441818237e-01
    z[1,3,1]  R990      6.3431978225708008e-01
    z[1,3,1]  R991      5.9665668010711670e-01
    z[1,3,1]  R992      3.8126606494188309e-02
    z[1,3,1]  R993      -3.2695242762565613e-01
    z[1,3,1]  R994      -1.6189412772655487e-01
    z[1,3,1]  R995      1.2276873737573624e-01
    z[1,3,1]  R996      -3.9504233747720718e-02
    z[1,3,1]  R997      2.1815690398216248e-01
    z[1,3,1]  R998      5.5338263511657715e-01
    z[1,3,1]  R999      4.9680396914482117e-01
    z[1,3,1]  R1000     -6.5467916429042816e-02
    z[1,3,1]  R1001     -5.1626145839691162e-02
    z[1,3,1]  R1002     7.7807330526411533e-03
    z[1,3,1]  R1003     1.6626305878162384e-01
    z[1,3,1]  R1004     4.6585938334465027e-01
    z[1,3,1]  R1005     2.0342525839805603e-01
    z[1,3,1]  R1006     1.8408547341823578e-01
    z[1,3,1]  R1007     2.9277646541595459e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R888      -1
    z[1,3,2]  R889      1
    z[1,3,2]  R898      -1.9925607740879059e-01
    z[1,3,2]  R899      -3.2785028219223022e-01
    z[1,3,2]  R900      -7.2761642932891846e-01
    z[1,3,2]  R901      7.2494186460971832e-02
    z[1,3,2]  R902      9.0446047484874725e-02
    z[1,3,2]  R903      -3.4528259187936783e-02
    z[1,3,2]  R904      8.5024453699588776e-02
    z[1,3,2]  R905      2.3083847761154175e-01
    z[1,3,2]  R906      2.1506215631961823e-01
    z[1,3,2]  R907      -2.6834979653358459e-01
    z[1,3,2]  R908      -2.7630642056465149e-02
    z[1,3,2]  R909      -4.4226527214050293e-01
    z[1,3,2]  R910      1.0201875865459442e-01
    z[1,3,2]  R911      -0.326465904712677
    z[1,3,2]  R912      -6.1449509859085083e-01
    z[1,3,2]  R913      -3.5805395245552063e-01
    z[1,3,2]  R914      1.8681395053863525e-01
    z[1,3,2]  R915      -5.6713706254959106e-01
    z[1,3,2]  R916      7.0076537132263184e-01
    z[1,3,2]  R917      -8.1679157912731171e-02
    z[1,3,2]  R918      7.4630357325077057e-02
    z[1,3,2]  R919      -3.0827391147613525e-01
    z[1,3,2]  R920      -1.6502179205417633e-01
    z[1,3,2]  R921      -5.4879003763198853e-01
    z[1,3,2]  R922      -4.3301945924758911e-01
    z[1,3,2]  R923      -5.0865966081619263e-01
    z[1,3,2]  R924      6.4753150939941406e-01
    z[1,3,2]  R925      6.5141016244888306e-01
    z[1,3,2]  R926      9.0096151828765869e-01
    z[1,3,2]  R927      2.7205786108970642e-01
    z[1,3,2]  R928      -2.7679139375686646e-01
    z[1,3,2]  R929      -3.7863668799400330e-01
    z[1,3,2]  R930      -3.8496804237365723e-01
    z[1,3,2]  R931      2.0444500446319580e-01
    z[1,3,2]  R932      8.6876258254051208e-02
    z[1,3,2]  R933      -7.5554674863815308e-01
    z[1,3,2]  R934      -7.8910648822784424e-01
    z[1,3,2]  R935      -2.9234769940376282e-01
    z[1,3,2]  R936      -5.6696283817291260e-01
    z[1,3,2]  R937      -3.3386719226837158e-01
    z[1,3,2]  R938      5.8001782745122910e-02
    z[1,3,2]  R939      2.7561190724372864e-01
    z[1,3,2]  R940      4.6525120735168457e-01
    z[1,3,2]  R941      4.9158122390508652e-02
    z[1,3,2]  R942      -1.9451542198657990e-01
    z[1,3,2]  R943      0.456400066614151
    z[1,3,2]  R944      -1.8513631820678711e-01
    z[1,3,2]  R945      2.5300800800323486e-01
    z[1,3,2]  R946      1.6776071488857269e-01
    z[1,3,2]  R947      2.2591666877269745e-01
    z[1,3,2]  R948      4.1885474324226379e-01
    z[1,3,2]  R949      6.4915120601654053e-01
    z[1,3,2]  R950      3.0353426933288574e-01
    z[1,3,2]  R951      -0.142684206366539
    z[1,3,2]  R952      4.0329253673553467e-01
    z[1,3,2]  R953      5.1168125867843628e-01
    z[1,3,2]  R954      2.2234684228897095e-01
    z[1,3,2]  R955      2.4198077619075775e-01
    z[1,3,2]  R956      1.9835273921489716e-01
    z[1,3,2]  R957      2.9536345601081848e-01
    z[1,3,2]  R958      0.591578483581543
    z[1,3,2]  R959      4.2835199832916260e-01
    z[1,3,2]  R960      3.6957284808158875e-01
    z[1,3,2]  R961      3.5678908228874207e-01
    z[1,3,2]  R962      6.9865697622299194e-01
    z[1,3,2]  R963      -0.00870123878121376
    z[1,3,2]  R964      7.8830993175506592e-01
    z[1,3,2]  R965      0.0234073456376791
    z[1,3,2]  R966      0.83809494972229
    z[1,3,2]  R967      -2.3189926519989967e-02
    z[1,3,2]  R968      6.6558992862701416e-01
    z[1,3,2]  R969      -6.3357698917388916e-01
    z[1,3,2]  R970      -5.5956327915191650e-01
    z[1,3,2]  R971      3.6189684271812439e-01
    z[1,3,2]  R972      3.7515515089035034e-01
    z[1,3,2]  R973      4.3275609612464905e-01
    z[1,3,2]  R974      4.4035500288009644e-01
    z[1,3,2]  R975      0.510381281375885
    z[1,3,2]  R976      4.1040968894958496e-01
    z[1,3,2]  R977      6.4251035451889038e-01
    z[1,3,2]  R978      -4.5409896969795227e-01
    z[1,3,2]  R979      6.4309597015380859e-01
    z[1,3,2]  R980      1.8638938665390015e-01
    z[1,3,2]  R981      -1.3868586719036102e-01
    z[1,3,2]  R982      -1.0716875083744526e-02
    z[1,3,2]  R983      -4.7345027327537537e-01
    z[1,3,2]  R984      1.2176910787820816e-01
    z[1,3,2]  R985      1.8041385710239410e-01
    z[1,3,2]  R986      3.8921785354614258e-01
    z[1,3,2]  R987      5.0720632076263428e-01
    z[1,3,2]  R988      -4.7103241086006165e-02
    z[1,3,2]  R989      -6.8664395809173584e-01
    z[1,3,2]  R990      6.2752717733383179e-01
    z[1,3,2]  R991      2.5780880451202393e-01
    z[1,3,2]  R992      5.6103730201721191e-01
    z[1,3,2]  R993      4.3118435144424438e-01
    z[1,3,2]  R994      5.1037895679473877e-01
    z[1,3,2]  R995      2.1010838449001312e-02
    z[1,3,2]  R996      4.4596254825592041e-01
    z[1,3,2]  R997      1.1814925074577332e-01
    z[1,3,2]  R998      7.2799527645111084e-01
    z[1,3,2]  R999      1.6364777088165283e-01
    z[1,3,2]  R1000     4.1928282380104065e-01
    z[1,3,2]  R1001     3.5021528601646423e-01
    z[1,3,2]  R1002     9.6968859434127808e-02
    z[1,3,2]  R1003     1.0210317373275757e-01
    z[1,3,2]  R1004     -4.1711616516113281e-01
    z[1,3,2]  R1005     -3.4999263286590576e-01
    z[1,3,2]  R1006     -5.9964990615844727e-01
    z[1,3,2]  R1007     -0.438488632440567
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R890      -1
    z[1,3,3]  R891      1
    z[1,3,3]  R898      4.1571286320686340e-01
    z[1,3,3]  R899      5.2801431156694889e-03
    z[1,3,3]  R900      2.3760001361370087e-01
    z[1,3,3]  R901      4.4579803943634033e-01
    z[1,3,3]  R902      4.1010746359825134e-01
    z[1,3,3]  R903      0.0699441209435463
    z[1,3,3]  R904      -2.7111726999282837e-01
    z[1,3,3]  R905      3.5323426127433777e-03
    z[1,3,3]  R906      -1.5383604168891907e-01
    z[1,3,3]  R907      -4.1269126534461975e-01
    z[1,3,3]  R908      -7.1397058665752411e-02
    z[1,3,3]  R909      1.3254101388156414e-02
    z[1,3,3]  R910      -0.062924325466156
    z[1,3,3]  R911      2.9293122887611389e-01
    z[1,3,3]  R912      6.8340882658958435e-02
    z[1,3,3]  R913      -1.5282213687896729e-01
    z[1,3,3]  R914      -7.1344166994094849e-01
    z[1,3,3]  R915      -4.9946320056915283e-01
    z[1,3,3]  R916      -5.0770968198776245e-01
    z[1,3,3]  R917      -5.8048856258392334e-01
    z[1,3,3]  R918      -2.9847297072410583e-01
    z[1,3,3]  R919      5.1173716783523560e-01
    z[1,3,3]  R920      3.4743675589561462e-01
    z[1,3,3]  R921      -4.6729825437068939e-02
    z[1,3,3]  R922      -1.2129744887351990e-01
    z[1,3,3]  R923      1.2098416686058044e-01
    z[1,3,3]  R924      -6.5261560678482056e-01
    z[1,3,3]  R925      -3.6690777540206909e-01
    z[1,3,3]  R926      -1.4384835958480835e-01
    z[1,3,3]  R927      -3.5192090272903442e-01
    z[1,3,3]  R928      -1.8925718963146210e-01
    z[1,3,3]  R929      -2.4206961691379547e-01
    z[1,3,3]  R930      -0.221385195851326
    z[1,3,3]  R931      -7.9649955034255981e-01
    z[1,3,3]  R932      -3.4430682659149170e-01
    z[1,3,3]  R933      -3.9871323108673096e-01
    z[1,3,3]  R934      -2.5169461965560913e-01
    z[1,3,3]  R935      -4.0956640243530273e-01
    z[1,3,3]  R936      -6.7413115501403809e-01
    z[1,3,3]  R937      -3.4015771746635437e-01
    z[1,3,3]  R938      0.764613926410675
    z[1,3,3]  R939      -5.8764559030532837e-01
    z[1,3,3]  R940      -7.7875353395938873e-02
    z[1,3,3]  R941      8.4801214933395386e-01
    z[1,3,3]  R942      8.6049139499664307e-01
    z[1,3,3]  R943      5.7995426654815674e-01
    z[1,3,3]  R944      7.9041171073913574e-01
    z[1,3,3]  R945      -3.1717292964458466e-02
    z[1,3,3]  R946      6.2472563982009888e-01
    z[1,3,3]  R947      2.7844116091728210e-01
    z[1,3,3]  R948      -5.2439391613006592e-01
    z[1,3,3]  R949      1.4728824794292450e-01
    z[1,3,3]  R950      6.5796025097370148e-02
    z[1,3,3]  R951      -0.224580317735672
    z[1,3,3]  R952      3.2414516806602478e-01
    z[1,3,3]  R953      1.1617504805326462e-01
    z[1,3,3]  R954      4.1859525442123413e-01
    z[1,3,3]  R955      8.2857191562652588e-02
    z[1,3,3]  R956      2.9513800144195557e-01
    z[1,3,3]  R957      5.4498338699340820e-01
    z[1,3,3]  R958      -1.4877954125404358e-01
    z[1,3,3]  R959      -1.1835643090307713e-02
    z[1,3,3]  R960      -0.0822002962231636
    z[1,3,3]  R961      -1.2596678733825684e-01
    z[1,3,3]  R962      1.1937101930379868e-01
    z[1,3,3]  R963      -4.4053740799427032e-02
    z[1,3,3]  R964      -2.3050174117088318e-01
    z[1,3,3]  R965      -0.168934166431427
    z[1,3,3]  R966      -1.3055580854415894e-01
    z[1,3,3]  R967      -5.7930290699005127e-01
    z[1,3,3]  R968      -0.125800222158432
    z[1,3,3]  R969      -6.2831813097000122e-01
    z[1,3,3]  R970      -6.0615569353103638e-01
    z[1,3,3]  R971      4.1915714740753174e-02
    z[1,3,3]  R972      6.7114210128784180e-01
    z[1,3,3]  R973      -3.5161364078521729e-01
    z[1,3,3]  R974      4.2544767260551453e-01
    z[1,3,3]  R975      2.8327226638793945e-01
    z[1,3,3]  R976      1.6467611491680145e-01
    z[1,3,3]  R977      7.4989847838878632e-02
    z[1,3,3]  R978      -4.5076709985733032e-01
    z[1,3,3]  R979      -5.2277642488479614e-01
    z[1,3,3]  R980      -5.4149228334426880e-01
    z[1,3,3]  R981      -7.2312670946121216e-01
    z[1,3,3]  R982      -4.5369812846183777e-01
    z[1,3,3]  R983      -3.5828915238380432e-01
    z[1,3,3]  R984      -1.5464001893997192e-01
    z[1,3,3]  R985      -2.0803090929985046e-01
    z[1,3,3]  R986      -3.4947675466537476e-01
    z[1,3,3]  R987      -1.6266277059912682e-02
    z[1,3,3]  R988      -4.9394932389259338e-01
    z[1,3,3]  R989      -4.3957000970840454e-01
    z[1,3,3]  R990      -1.2109193205833435e-01
    z[1,3,3]  R991      -2.4200929701328278e-01
    z[1,3,3]  R992      -5.9272092580795288e-01
    z[1,3,3]  R993      2.7310448884963989e-01
    z[1,3,3]  R994      -2.6991853117942810e-01
    z[1,3,3]  R995      1.3952843844890594e-01
    z[1,3,3]  R996      1.7272329330444336e-01
    z[1,3,3]  R997      4.0151754021644592e-01
    z[1,3,3]  R998      -1.4502698183059692e-01
    z[1,3,3]  R999      -2.2398833185434341e-02
    z[1,3,3]  R1000     1.6994623839855194e-01
    z[1,3,3]  R1001     0.409463107585907
    z[1,3,3]  R1002     3.1296434998512268e-01
    z[1,3,3]  R1003     3.5010293126106262e-01
    z[1,3,3]  R1004     0.400585800409317
    z[1,3,3]  R1005     5.1017558574676514e-01
    z[1,3,3]  R1006     6.4175719022750854e-01
    z[1,3,3]  R1007     7.9267239570617676e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R892      -1
    z[1,3,4]  R893      1
    z[1,3,4]  R898      -1.9522084295749664e-01
    z[1,3,4]  R899      -5.5625919252634048e-02
    z[1,3,4]  R900      -1.1468805372714996e-01
    z[1,3,4]  R901      2.8277322649955750e-01
    z[1,3,4]  R902      -4.1842761635780334e-01
    z[1,3,4]  R903      -5.1813744008541107e-02
    z[1,3,4]  R904      1.5262334048748016e-01
    z[1,3,4]  R905      -3.9830081164836884e-02
    z[1,3,4]  R906      -3.4797763824462891e-01
    z[1,3,4]  R907      -1.8198819458484650e-01
    z[1,3,4]  R908      5.0782209634780884e-01
    z[1,3,4]  R909      5.0541943311691284e-01
    z[1,3,4]  R910      7.0441913604736328e-01
    z[1,3,4]  R911      1.5030542016029358e-01
    z[1,3,4]  R912      1.8428441882133484e-01
    z[1,3,4]  R913      0.532706618309021
    z[1,3,4]  R914      4.6939682960510254e-01
    z[1,3,4]  R915      -1.0630524903535843e-01
    z[1,3,4]  R916      -1.1071750521659851e-01
    z[1,3,4]  R917      -3.0283406376838684e-03
    z[1,3,4]  R918      1.0974252223968506e-01
    z[1,3,4]  R919      -1.2475372105836868e-01
    z[1,3,4]  R920      2.1234643459320068e-01
    z[1,3,4]  R921      1.4340290427207947e-01
    z[1,3,4]  R922      4.1452908515930176e-01
    z[1,3,4]  R923      -2.9557171463966370e-01
    z[1,3,4]  R924      1.0928661562502384e-02
    z[1,3,4]  R925      -3.0401936173439026e-01
    z[1,3,4]  R926      1.9716110825538635e-01
    z[1,3,4]  R927      4.9992737174034119e-01
    z[1,3,4]  R928      -1.2922429479658604e-02
    z[1,3,4]  R929      -3.3408230543136597e-01
    z[1,3,4]  R930      -3.7047231197357178e-01
    z[1,3,4]  R931      1.0382376611232758e-01
    z[1,3,4]  R932      -5.7068582624197006e-02
    z[1,3,4]  R933      -4.5437198132276535e-02
    z[1,3,4]  R934      1.0979046672582626e-01
    z[1,3,4]  R935      6.2426459789276123e-01
    z[1,3,4]  R936      1.6458596289157867e-01
    z[1,3,4]  R937      -1.9093267619609833e-01
    z[1,3,4]  R938      1.5055269002914429e-01
    z[1,3,4]  R939      4.7900673747062683e-01
    z[1,3,4]  R940      6.8221485614776611e-01
    z[1,3,4]  R941      -2.4003732204437256e-01
    z[1,3,4]  R942      8.7532445788383484e-02
    z[1,3,4]  R943      1.3894857466220856e-01
    z[1,3,4]  R944      -2.3357519507408142e-01
    z[1,3,4]  R945      3.6047333478927612e-01
    z[1,3,4]  R946      -1.7176365852355957e-01
    z[1,3,4]  R947      3.8407412171363831e-01
    z[1,3,4]  R948      3.0290532857179642e-02
    z[1,3,4]  R949      1.6972228884696960e-01
    z[1,3,4]  R950      -2.6506516337394714e-01
    z[1,3,4]  R951      -6.5742902457714081e-02
    z[1,3,4]  R952      3.7353450059890747e-01
    z[1,3,4]  R953      -1.9902090728282928e-01
    z[1,3,4]  R954      -1.7694956064224243e-01
    z[1,3,4]  R955      -3.5701495409011841e-01
    z[1,3,4]  R956      -4.2548492550849915e-01
    z[1,3,4]  R957      -2.7885007858276367e-01
    z[1,3,4]  R958      -3.0204278230667114e-01
    z[1,3,4]  R959      -6.5034247934818268e-02
    z[1,3,4]  R960      1.4242146909236908e-01
    z[1,3,4]  R961      -3.8372558355331421e-01
    z[1,3,4]  R962      -2.7505305409431458e-01
    z[1,3,4]  R963      -3.5697260499000549e-01
    z[1,3,4]  R964      1.1379770934581757e-01
    z[1,3,4]  R965      4.8987287282943726e-01
    z[1,3,4]  R966      2.1615803241729736e-01
    z[1,3,4]  R967      3.1966876983642578e-01
    z[1,3,4]  R968      2.2724738717079163e-01
    z[1,3,4]  R969      3.7069374322891235e-01
    z[1,3,4]  R970      -4.7022711485624313e-02
    z[1,3,4]  R971      5.0512617826461792e-01
    z[1,3,4]  R972      9.9318593740463257e-02
    z[1,3,4]  R973      6.3165497779846191e-01
    z[1,3,4]  R974      0.0630766972899437
    z[1,3,4]  R975      0.0745469257235527
    z[1,3,4]  R976      4.1779968142509460e-01
    z[1,3,4]  R977      -8.4193728864192963e-02
    z[1,3,4]  R978      1.8353018164634705e-01
    z[1,3,4]  R979      1.4879144728183746e-01
    z[1,3,4]  R980      -1.8214456737041473e-01
    z[1,3,4]  R981      2.5692921876907349e-01
    z[1,3,4]  R982      5.9604948759078979e-01
    z[1,3,4]  R983      1.8044304102659225e-02
    z[1,3,4]  R984      3.6404874920845032e-01
    z[1,3,4]  R985      2.3396741598844528e-02
    z[1,3,4]  R986      -2.8300735354423523e-01
    z[1,3,4]  R987      -1.9731599092483521e-01
    z[1,3,4]  R988      -4.4487681239843369e-02
    z[1,3,4]  R989      3.2666184008121490e-02
    z[1,3,4]  R990      1.5206189453601837e-01
    z[1,3,4]  R991      9.2810891568660736e-02
    z[1,3,4]  R992      9.6238173544406891e-02
    z[1,3,4]  R993      -1.3673400878906250e-01
    z[1,3,4]  R994      -2.0141109824180603e-01
    z[1,3,4]  R995      2.3014084994792938e-01
    z[1,3,4]  R996      -2.4442131817340851e-01
    z[1,3,4]  R997      9.3896873295307159e-02
    z[1,3,4]  R998      2.7465993165969849e-01
    z[1,3,4]  R999      -1.7549371719360352e-01
    z[1,3,4]  R1000     -2.2474156320095062e-01
    z[1,3,4]  R1001     3.3653992414474487e-01
    z[1,3,4]  R1002     2.3855890333652496e-01
    z[1,3,4]  R1003     1.3736869394779205e-01
    z[1,3,4]  R1004     7.3812989285215735e-04
    z[1,3,4]  R1005     -5.2129936218261719e-01
    z[1,3,4]  R1006     -2.2389587759971619e-01
    z[1,3,4]  R1007     -2.0287160575389862e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R894      -1
    z[1,3,5]  R895      1
    z[1,3,5]  R898      4.5144062489271164e-02
    z[1,3,5]  R899      5.1510158926248550e-02
    z[1,3,5]  R900      -3.9596560597419739e-01
    z[1,3,5]  R901      -3.4057098627090454e-01
    z[1,3,5]  R902      -6.3107395172119141e-01
    z[1,3,5]  R903      -1.0247718542814255e-01
    z[1,3,5]  R904      -3.4925499558448792e-01
    z[1,3,5]  R905      4.0217429399490356e-01
    z[1,3,5]  R906      -1.4051049947738647e-01
    z[1,3,5]  R907      -2.4994817376136780e-01
    z[1,3,5]  R908      -4.4802263379096985e-01
    z[1,3,5]  R909      -2.0324413478374481e-01
    z[1,3,5]  R910      -1.0597249493002892e-02
    z[1,3,5]  R911      -3.6264079809188843e-01
    z[1,3,5]  R912      4.3007194995880127e-01
    z[1,3,5]  R913      3.4774327278137207e-01
    z[1,3,5]  R914      5.7146232575178146e-02
    z[1,3,5]  R915      5.0299829244613647e-01
    z[1,3,5]  R916      3.9705076813697815e-01
    z[1,3,5]  R917      -4.2692460119724274e-02
    z[1,3,5]  R918      -5.0250776112079620e-02
    z[1,3,5]  R919      1.9489030539989471e-01
    z[1,3,5]  R920      4.0899339318275452e-01
    z[1,3,5]  R921      1.7612640559673309e-01
    z[1,3,5]  R922      2.3359447717666626e-01
    z[1,3,5]  R923      4.1298249363899231e-01
    z[1,3,5]  R924      2.2846752777695656e-02
    z[1,3,5]  R925      2.2896414995193481e-01
    z[1,3,5]  R926      0.241278275847435
    z[1,3,5]  R927      2.1940311789512634e-01
    z[1,3,5]  R928      -7.1594923734664917e-02
    z[1,3,5]  R929      1.2033394724130630e-01
    z[1,3,5]  R930      -4.3070587515830994e-01
    z[1,3,5]  R931      -2.2164934873580933e-01
    z[1,3,5]  R932      -0.824120044708252
    z[1,3,5]  R933      1.4033000171184540e-01
    z[1,3,5]  R934      -9.9121198058128357e-02
    z[1,3,5]  R935      3.9948695898056030e-01
    z[1,3,5]  R936      2.8855550289154053e-01
    z[1,3,5]  R937      0.0670010894536972
    z[1,3,5]  R938      5.5497944355010986e-02
    z[1,3,5]  R939      5.1751244068145752e-01
    z[1,3,5]  R940      -7.3180519044399261e-02
    z[1,3,5]  R941      1.2180896848440170e-01
    z[1,3,5]  R942      1.0028154402971268e-01
    z[1,3,5]  R943      -3.4219104051589966e-01
    z[1,3,5]  R944      7.0903427898883820e-02
    z[1,3,5]  R945      7.6070673763751984e-02
    z[1,3,5]  R946      -3.0782202258706093e-02
    z[1,3,5]  R947      4.3729510903358459e-01
    z[1,3,5]  R948      1.6473619639873505e-01
    z[1,3,5]  R949      -2.7248337864875793e-02
    z[1,3,5]  R950      9.6197031438350677e-02
    z[1,3,5]  R951      6.0163778066635132e-01
    z[1,3,5]  R952      -6.0983706265687943e-02
    z[1,3,5]  R953      2.5788676738739014e-01
    z[1,3,5]  R954      -0.0456160232424736
    z[1,3,5]  R955      -2.1228650212287903e-01
    z[1,3,5]  R956      -1.7278324067592621e-01
    z[1,3,5]  R957      -1.4928644895553589e-01
    z[1,3,5]  R958      -4.2609229683876038e-01
    z[1,3,5]  R959      1.2111280113458633e-01
    z[1,3,5]  R960      -2.1845720708370209e-01
    z[1,3,5]  R961      -2.6794201135635376e-01
    z[1,3,5]  R962      -2.8001922369003296e-01
    z[1,3,5]  R963      -0.5264852643013
    z[1,3,5]  R964      -2.5525093078613281e-01
    z[1,3,5]  R965      -2.4217948317527771e-02
    z[1,3,5]  R966      -2.8848379850387573e-01
    z[1,3,5]  R967      4.3418622016906738e-01
    z[1,3,5]  R968      -1.5303204953670502e-01
    z[1,3,5]  R969      -9.2712230980396271e-02
    z[1,3,5]  R970      3.8863378763198853e-01
    z[1,3,5]  R971      -3.1936866044998169e-01
    z[1,3,5]  R972      2.8483736515045166e-01
    z[1,3,5]  R973      2.1372631192207336e-01
    z[1,3,5]  R974      -2.8907996416091919e-01
    z[1,3,5]  R975      1.0884429514408112e-01
    z[1,3,5]  R976      0.0377860963344574
    z[1,3,5]  R977      -0.294871985912323
    z[1,3,5]  R978      0.430424302816391
    z[1,3,5]  R979      -1.1839371919631958e-01
    z[1,3,5]  R980      -4.5698404312133789e-01
    z[1,3,5]  R981      5.8323782682418823e-01
    z[1,3,5]  R982      -3.4498110413551331e-01
    z[1,3,5]  R983      5.0153142213821411e-01
    z[1,3,5]  R984      -6.6374707221984863e-01
    z[1,3,5]  R985      0.896765947341919
    z[1,3,5]  R986      7.0995688438415527e-01
    z[1,3,5]  R987      -4.7227197885513306e-01
    z[1,3,5]  R988      7.5401091575622559e-01
    z[1,3,5]  R989      2.3110548034310341e-02
    z[1,3,5]  R990      -4.5502327382564545e-02
    z[1,3,5]  R991      -1.5141440927982330e-01
    z[1,3,5]  R992      4.6859785914421082e-01
    z[1,3,5]  R993      -2.0513559877872467e-01
    z[1,3,5]  R994      2.1855992078781128e-01
    z[1,3,5]  R995      -1.1159786581993103e-01
    z[1,3,5]  R996      6.7691020667552948e-02
    z[1,3,5]  R997      5.2345430850982666e-01
    z[1,3,5]  R998      -1.7096638679504395e-01
    z[1,3,5]  R999      -7.6470810174942017e-01
    z[1,3,5]  R1000     -1.7447984218597412e-01
    z[1,3,5]  R1001     -0.0942888930439949
    z[1,3,5]  R1002     8.8665008544921875e-02
    z[1,3,5]  R1003     4.5969173312187195e-01
    z[1,3,5]  R1004     -1.0222969204187393e-01
    z[1,3,5]  R1005     4.4253578782081604e-01
    z[1,3,5]  R1006     2.3229949176311493e-01
    z[1,3,5]  R1007     6.2652014195919037e-02
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R896      -1
    z[1,3,6]  R897      1
    z[1,3,6]  R898      4.4508108496665955e-01
    z[1,3,6]  R899      -4.6299800276756287e-01
    z[1,3,6]  R900      -1.1209972202777863e-01
    z[1,3,6]  R901      -3.7462544441223145e-01
    z[1,3,6]  R902      -2.7219581604003906e-01
    z[1,3,6]  R903      5.1093274354934692e-01
    z[1,3,6]  R904      2.6656261086463928e-01
    z[1,3,6]  R905      -1.5174549818038940e-01
    z[1,3,6]  R906      -3.5464456677436829e-01
    z[1,3,6]  R907      -5.2352637052536011e-01
    z[1,3,6]  R908      -1.9029730930924416e-02
    z[1,3,6]  R909      1.1859763413667679e-02
    z[1,3,6]  R910      1.6963452100753784e-01
    z[1,3,6]  R911      -4.3357063084840775e-02
    z[1,3,6]  R912      1.4768348634243011e-01
    z[1,3,6]  R913      3.8006898760795593e-01
    z[1,3,6]  R914      -0.208759143948555
    z[1,3,6]  R915      1.0208845883607864e-01
    z[1,3,6]  R916      1.4676529169082642e-01
    z[1,3,6]  R917      4.4861856102943420e-01
    z[1,3,6]  R918      -3.4222227334976196e-01
    z[1,3,6]  R919      1.1750672757625580e-01
    z[1,3,6]  R920      1.0847406834363937e-01
    z[1,3,6]  R921      -3.1713131070137024e-01
    z[1,3,6]  R922      2.5246149301528931e-01
    z[1,3,6]  R923      -1.7355036735534668e-01
    z[1,3,6]  R924      -1.5159356594085693e-01
    z[1,3,6]  R925      3.0916744470596313e-01
    z[1,3,6]  R926      2.3593175411224365e-01
    z[1,3,6]  R927      -1.3633179664611816e-01
    z[1,3,6]  R928      -1.0292565822601318e-01
    z[1,3,6]  R929      4.2694514989852905e-01
    z[1,3,6]  R930      2.8673991560935974e-01
    z[1,3,6]  R931      -1.7907572910189629e-02
    z[1,3,6]  R932      -4.6501882374286652e-02
    z[1,3,6]  R933      2.7039566636085510e-01
    z[1,3,6]  R934      -2.3802092671394348e-01
    z[1,3,6]  R935      -2.8519439697265625e-01
    z[1,3,6]  R936      -1.6427727416157722e-02
    z[1,3,6]  R937      4.0089237689971924e-01
    z[1,3,6]  R938      1.4535829424858093e-02
    z[1,3,6]  R939      -1.4709062874317169e-01
    z[1,3,6]  R940      -4.9917469732463360e-03
    z[1,3,6]  R941      -1.7179638147354126e-02
    z[1,3,6]  R942      -4.5078076422214508e-02
    z[1,3,6]  R943      1.2207396328449249e-01
    z[1,3,6]  R944      -2.9277160763740540e-01
    z[1,3,6]  R945      4.7871533036231995e-01
    z[1,3,6]  R946      -4.5756044983863831e-01
    z[1,3,6]  R947      -1.9415043294429779e-01
    z[1,3,6]  R948      -8.5624635219573975e-02
    z[1,3,6]  R949      -2.2068157792091370e-01
    z[1,3,6]  R950      -2.5803956389427185e-01
    z[1,3,6]  R951      -1.2441388517618179e-01
    z[1,3,6]  R952      -1.2177091836929321e-01
    z[1,3,6]  R953      -1.4720830321311951e-01
    z[1,3,6]  R954      2.0740801095962524e-01
    z[1,3,6]  R955      -5.9064473956823349e-02
    z[1,3,6]  R956      1.2667530775070190e-01
    z[1,3,6]  R957      -1.1722601950168610e-01
    z[1,3,6]  R958      3.1874611973762512e-01
    z[1,3,6]  R959      1.7620076239109039e-01
    z[1,3,6]  R960      -4.6389183402061462e-01
    z[1,3,6]  R961      3.3987739682197571e-01
    z[1,3,6]  R962      -1.2304409593343735e-01
    z[1,3,6]  R963      -1.5102137625217438e-01
    z[1,3,6]  R964      3.6426514387130737e-01
    z[1,3,6]  R965      1.1635456979274750e-01
    z[1,3,6]  R966      -2.9351255297660828e-01
    z[1,3,6]  R967      2.3197162151336670e-01
    z[1,3,6]  R968      1.4954103529453278e-01
    z[1,3,6]  R969      1.1755497753620148e-01
    z[1,3,6]  R970      -7.6021656394004822e-02
    z[1,3,6]  R971      3.6324289441108704e-01
    z[1,3,6]  R972      -2.1538391709327698e-01
    z[1,3,6]  R973      4.4994466006755829e-02
    z[1,3,6]  R974      2.5756680965423584e-01
    z[1,3,6]  R975      -9.1338776051998138e-02
    z[1,3,6]  R976      -2.0584285259246826e-01
    z[1,3,6]  R977      -3.1190514564514160e-01
    z[1,3,6]  R978      -4.1874065995216370e-01
    z[1,3,6]  R979      2.1480417251586914e-01
    z[1,3,6]  R980      3.3693531155586243e-01
    z[1,3,6]  R981      2.6994548738002777e-02
    z[1,3,6]  R982      1.6113099455833435e-01
    z[1,3,6]  R983      2.1039338409900665e-01
    z[1,3,6]  R984      2.6457908749580383e-01
    z[1,3,6]  R985      -1.9243661314249039e-02
    z[1,3,6]  R986      -2.2608275711536407e-01
    z[1,3,6]  R987      1.1658965051174164e-01
    z[1,3,6]  R988      -3.4674385190010071e-01
    z[1,3,6]  R989      -2.0819826424121857e-01
    z[1,3,6]  R990      -3.6833170056343079e-01
    z[1,3,6]  R991      4.3919944763183594e-01
    z[1,3,6]  R992      2.0566870272159576e-01
    z[1,3,6]  R993      -2.2956621646881104e-01
    z[1,3,6]  R994      1.0010523721575737e-02
    z[1,3,6]  R995      -3.8473281264305115e-01
    z[1,3,6]  R996      -6.1834228038787842e-01
    z[1,3,6]  R997      -1.2329224497079849e-01
    z[1,3,6]  R998      -1.6788972914218903e-01
    z[1,3,6]  R999      -1.7228076234459877e-02
    z[1,3,6]  R1000     -2.4053168296813965e-01
    z[1,3,6]  R1001     -1.7618584632873535e-01
    z[1,3,6]  R1002     -3.4975594282150269e-01
    z[1,3,6]  R1003     -7.9743430018424988e-02
    z[1,3,6]  R1004     -1.9918261468410492e-01
    z[1,3,6]  R1005     -1.5136629343032837e-01
    z[1,3,6]  R1006     2.3564919829368591e-02
    z[1,3,6]  R1007     4.8643615096807480e-02
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R1008     -1
    z[3,1,0]  R1009     1
    z[3,1,0]  R1022     -9.0111321210861206e-01
    z[3,1,0]  R1023     -6.0407590866088867e-01
    z[3,1,0]  R1024     -6.1722850799560547e-01
    z[3,1,0]  R1025     -3.1324347853660583e-01
    z[3,1,0]  R1026     1.8402388691902161e-01
    z[3,1,0]  R1027     3.5888195037841797e-01
    z[3,1,0]  R1028     1.2001663446426392e-01
    z[3,1,0]  R1029     3.3409410715103149e-01
    z[3,1,0]  R1030     1.7947991192340851e-01
    z[3,1,0]  R1031     6.3400840759277344e-01
    z[3,1,0]  R1032     -1.9765214622020721e-01
    z[3,1,0]  R1033     -1.7510922625660896e-02
    z[3,1,0]  R1034     6.6964410245418549e-02
    z[3,1,0]  R1035     -2.7715164422988892e-01
    z[3,1,0]  R1036     -2.5218993425369263e-01
    z[3,1,0]  R1037     -3.1260257959365845e-01
    z[3,1,0]  R1038     -2.3082602024078369e-01
    z[3,1,0]  R1039     2.8432890772819519e-01
    z[3,1,0]  R1040     -2.3441386222839355e-01
    z[3,1,0]  R1041     -2.9212430119514465e-01
    z[3,1,0]  R1042     1.8149070441722870e-01
    z[3,1,0]  R1043     1.8245698511600494e-01
    z[3,1,0]  R1044     2.0640777051448822e-01
    z[3,1,0]  R1045     6.3469523191452026e-01
    z[3,1,0]  R1046     1.3563279062509537e-02
    z[3,1,0]  R1047     -5.5913887917995453e-02
    z[3,1,0]  R1048     8.2741332054138184e-01
    z[3,1,0]  R1049     8.7075871229171753e-01
    z[3,1,0]  R1050     7.9749417304992676e-01
    z[3,1,0]  R1051     6.9988548755645752e-01
    z[3,1,0]  R1052     3.3281859010457993e-02
    z[3,1,0]  R1053     2.2290296852588654e-01
    z[3,1,0]  R1054     2.5331950187683105e-01
    z[3,1,0]  R1055     2.9828539490699768e-01
    z[3,1,0]  R1056     -5.0881292670965195e-02
    z[3,1,0]  R1057     1.5746654570102692e-01
    z[3,1,0]  R1058     2.3393720388412476e-01
    z[3,1,0]  R1059     2.9809838533401489e-01
    z[3,1,0]  R1060     -0.00982271321117878
    z[3,1,0]  R1061     5.6180328130722046e-01
    z[3,1,0]  R1062     4.6654570102691650e-01
    z[3,1,0]  R1063     1.6208623349666595e-01
    z[3,1,0]  R1064     8.7015196681022644e-02
    z[3,1,0]  R1065     3.2016941905021667e-01
    z[3,1,0]  R1066     -4.7110697627067566e-01
    z[3,1,0]  R1067     1.8492648005485535e-01
    z[3,1,0]  R1068     6.8464279174804688e-01
    z[3,1,0]  R1069     7.6983755826950073e-01
    z[3,1,0]  R1070     0.762596070766449
    z[3,1,0]  R1071     5.2648055553436279e-01
    z[3,1,0]  R1072     1.5865485370159149e-01
    z[3,1,0]  R1073     -1.2692667543888092e-01
    z[3,1,0]  R1074     1.6466620564460754e-01
    z[3,1,0]  R1075     2.2486260533332825e-01
    z[3,1,0]  R1076     9.1835662722587585e-02
    z[3,1,0]  R1077     5.8491063117980957e-01
    z[3,1,0]  R1078     4.2816135287284851e-01
    z[3,1,0]  R1079     1.3206787407398224e-01
    z[3,1,0]  R1080     -2.5663343071937561e-01
    z[3,1,0]  R1081     5.6501740217208862e-01
    z[3,1,0]  R1082     -1.0809303820133209e-01
    z[3,1,0]  R1083     6.1006840318441391e-02
    z[3,1,0]  R1084     -1.6829517483711243e-01
    z[3,1,0]  R1085     5.4270672798156738e-01
    z[3,1,0]  R1086     2.4762864410877228e-01
    z[3,1,0]  R1087     7.2049885988235474e-01
    z[3,1,0]  R1088     7.4297547340393066e-01
    z[3,1,0]  R1089     8.6693710088729858e-01
    z[3,1,0]  R1090     5.6837695837020874e-01
    z[3,1,0]  R1091     6.9224995374679565e-01
    z[3,1,0]  R1092     9.9514469504356384e-02
    z[3,1,0]  R1093     3.3170798420906067e-01
    z[3,1,0]  R1094     0.807605504989624
    z[3,1,0]  R1095     7.4419957399368286e-01
    z[3,1,0]  R1096     8.3993387222290039e-01
    z[3,1,0]  R1097     7.7641081809997559e-01
    z[3,1,0]  R1098     6.3118547201156616e-01
    z[3,1,0]  R1099     2.9213285446166992e-01
    z[3,1,0]  R1100     3.0005431175231934e-01
    z[3,1,0]  R1101     2.1501564979553223e-01
    z[3,1,0]  R1102     -4.9690928310155869e-02
    z[3,1,0]  R1103     -5.8148401975631714e-01
    z[3,1,0]  R1104     -1.1177226155996323e-01
    z[3,1,0]  R1105     -6.1769241094589233e-01
    z[3,1,0]  R1106     1.4331138134002686e-01
    z[3,1,0]  R1107     6.5243035554885864e-01
    z[3,1,0]  R1108     6.3770312070846558e-01
    z[3,1,0]  R1109     2.9630595818161964e-02
    z[3,1,0]  R1110     4.4086730480194092e-01
    z[3,1,0]  R1111     2.9334232211112976e-01
    z[3,1,0]  R1112     1.6809152066707611e-01
    z[3,1,0]  R1113     -0.023863660171628
    z[3,1,0]  R1114     -1.1202633380889893e-01
    z[3,1,0]  R1115     1.9880126416683197e-01
    z[3,1,0]  R1116     -1.3381104171276093e-01
    z[3,1,0]  R1117     -7.3125801980495453e-02
    z[3,1,0]  R1118     -1.5840733423829079e-02
    z[3,1,0]  R1119     1.9686248898506165e-01
    z[3,1,0]  R1120     2.2745615243911743e-01
    z[3,1,0]  R1121     -6.1484247446060181e-01
    z[3,1,0]  R1122     1.7498087882995605e-01
    z[3,1,0]  R1123     8.2255318760871887e-02
    z[3,1,0]  R1124     -2.1478015184402466e-01
    z[3,1,0]  R1125     -1.9356778264045715e-01
    z[3,1,0]  R1126     3.4069761633872986e-02
    z[3,1,0]  R1127     1.0933275334537029e-02
    z[3,1,0]  R1128     3.0830252170562744e-01
    z[3,1,0]  R1129     4.4244241714477539e-01
    z[3,1,0]  R1130     5.9359449893236160e-02
    z[3,1,0]  R1131     6.1092221736907959e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R1010     -1
    z[3,1,1]  R1011     1
    z[3,1,1]  R1022     2.4428819119930267e-01
    z[3,1,1]  R1023     3.5320740938186646e-01
    z[3,1,1]  R1024     -1.2976975739002228e-01
    z[3,1,1]  R1025     -4.0674397349357605e-01
    z[3,1,1]  R1026     3.9426818490028381e-01
    z[3,1,1]  R1027     -2.1566146612167358e-01
    z[3,1,1]  R1028     -4.7013166546821594e-01
    z[3,1,1]  R1029     6.7358978092670441e-02
    z[3,1,1]  R1030     -2.8506958484649658e-01
    z[3,1,1]  R1031     -4.1133868694305420e-01
    z[3,1,1]  R1032     -5.8904796838760376e-01
    z[3,1,1]  R1033     2.4392996728420258e-01
    z[3,1,1]  R1034     5.4972273111343384e-01
    z[3,1,1]  R1035     -3.5902017354965210e-01
    z[3,1,1]  R1036     -3.7197881937026978e-01
    z[3,1,1]  R1037     -4.5423364639282227e-01
    z[3,1,1]  R1038     -3.7735033035278320e-01
    z[3,1,1]  R1039     6.9945830106735229e-01
    z[3,1,1]  R1040     -5.3554880619049072e-01
    z[3,1,1]  R1041     -6.4004784822463989e-01
    z[3,1,1]  R1042     6.9371879100799561e-01
    z[3,1,1]  R1043     6.6736036539077759e-01
    z[3,1,1]  R1044     8.4547966718673706e-01
    z[3,1,1]  R1045     -3.8026013970375061e-01
    z[3,1,1]  R1046     7.5764495134353638e-01
    z[3,1,1]  R1047     7.7056729793548584e-01
    z[3,1,1]  R1048     1.1965405195951462e-01
    z[3,1,1]  R1049     -1.8582781776785851e-02
    z[3,1,1]  R1050     1.0302767157554626e-01
    z[3,1,1]  R1051     1.1012807488441467e-01
    z[3,1,1]  R1052     5.0240254402160645e-01
    z[3,1,1]  R1053     8.4660744667053223e-01
    z[3,1,1]  R1054     7.1364217996597290e-01
    z[3,1,1]  R1055     6.5825891494750977e-01
    z[3,1,1]  R1056     5.7081985473632812e-01
    z[3,1,1]  R1057     7.3875850439071655e-01
    z[3,1,1]  R1058     2.4478116631507874e-01
    z[3,1,1]  R1059     7.9243320226669312e-01
    z[3,1,1]  R1060     2.5369012355804443e-01
    z[3,1,1]  R1061     6.1081565916538239e-02
    z[3,1,1]  R1062     4.7547537088394165e-01
    z[3,1,1]  R1063     -1.3302671909332275e-01
    z[3,1,1]  R1064     -3.9098069071769714e-01
    z[3,1,1]  R1065     5.2504408359527588e-01
    z[3,1,1]  R1066     -2.2248266637325287e-01
    z[3,1,1]  R1067     4.5629009604454041e-01
    z[3,1,1]  R1068     4.9592334777116776e-02
    z[3,1,1]  R1069     -2.0216518640518188e-01
    z[3,1,1]  R1070     -6.7359425127506256e-02
    z[3,1,1]  R1071     -0.336232453584671
    z[3,1,1]  R1072     -4.1369026899337769e-01
    z[3,1,1]  R1073     4.6338456869125366e-01
    z[3,1,1]  R1074     5.3795313835144043e-01
    z[3,1,1]  R1075     -1.9572993740439415e-02
    z[3,1,1]  R1076     5.3419023752212524e-01
    z[3,1,1]  R1077     -9.6064776182174683e-02
    z[3,1,1]  R1078     3.6720937490463257e-01
    z[3,1,1]  R1079     3.1878709793090820e-01
    z[3,1,1]  R1080     -1.5896326303482056e-01
    z[3,1,1]  R1081     -3.8427191972732544e-01
    z[3,1,1]  R1082     -2.2664600610733032e-01
    z[3,1,1]  R1083     -5.3537720441818237e-01
    z[3,1,1]  R1084     6.3431978225708008e-01
    z[3,1,1]  R1085     5.9665668010711670e-01
    z[3,1,1]  R1086     3.8126606494188309e-02
    z[3,1,1]  R1087     -3.2695242762565613e-01
    z[3,1,1]  R1088     -1.6189412772655487e-01
    z[3,1,1]  R1089     1.2276873737573624e-01
    z[3,1,1]  R1090     -3.9504233747720718e-02
    z[3,1,1]  R1091     2.1815690398216248e-01
    z[3,1,1]  R1092     5.5338263511657715e-01
    z[3,1,1]  R1093     4.9680396914482117e-01
    z[3,1,1]  R1094     -6.5467916429042816e-02
    z[3,1,1]  R1095     -5.1626145839691162e-02
    z[3,1,1]  R1096     7.7807330526411533e-03
    z[3,1,1]  R1097     1.6626305878162384e-01
    z[3,1,1]  R1098     4.6585938334465027e-01
    z[3,1,1]  R1099     2.0342525839805603e-01
    z[3,1,1]  R1100     1.8408547341823578e-01
    z[3,1,1]  R1101     2.9277646541595459e-01
    z[3,1,1]  R1102     -7.3943519592285156e-01
    z[3,1,1]  R1103     -5.7814192771911621e-01
    z[3,1,1]  R1104     -4.6810141205787659e-01
    z[3,1,1]  R1105     -2.7959123253822327e-01
    z[3,1,1]  R1106     -3.9454612135887146e-01
    z[3,1,1]  R1107     5.4222857952117920e-01
    z[3,1,1]  R1108     5.4430902004241943e-01
    z[3,1,1]  R1109     8.7147343158721924e-01
    z[3,1,1]  R1110     6.8491917848587036e-01
    z[3,1,1]  R1111     5.4950064420700073e-01
    z[3,1,1]  R1112     0.711979329586029
    z[3,1,1]  R1113     7.1186983585357666e-01
    z[3,1,1]  R1114     6.6931933164596558e-01
    z[3,1,1]  R1115     7.8237426280975342e-01
    z[3,1,1]  R1116     5.9923851490020752e-01
    z[3,1,1]  R1117     5.4216337203979492e-01
    z[3,1,1]  R1118     4.3436288833618164e-01
    z[3,1,1]  R1119     3.3971610665321350e-01
    z[3,1,1]  R1120     -8.9301742613315582e-02
    z[3,1,1]  R1121     2.7429884672164917e-01
    z[3,1,1]  R1122     8.6199837923049927e-01
    z[3,1,1]  R1123     7.5430279970169067e-01
    z[3,1,1]  R1124     7.6275277137756348e-01
    z[3,1,1]  R1125     7.1205347776412964e-01
    z[3,1,1]  R1126     7.1167606115341187e-01
    z[3,1,1]  R1127     6.6217201948165894e-01
    z[3,1,1]  R1128     1.9006147980690002e-01
    z[3,1,1]  R1129     6.9651387631893158e-02
    z[3,1,1]  R1130     1.0630601644515991e-01
    z[3,1,1]  R1131     -3.3505043387413025e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R1012     -1
    z[3,1,2]  R1013     1
    z[3,1,2]  R1022     -2.7679139375686646e-01
    z[3,1,2]  R1023     -3.7863668799400330e-01
    z[3,1,2]  R1024     -3.8496804237365723e-01
    z[3,1,2]  R1025     2.0444500446319580e-01
    z[3,1,2]  R1026     8.6876258254051208e-02
    z[3,1,2]  R1027     -7.5554674863815308e-01
    z[3,1,2]  R1028     -7.8910648822784424e-01
    z[3,1,2]  R1029     -2.9234769940376282e-01
    z[3,1,2]  R1030     -5.6696283817291260e-01
    z[3,1,2]  R1031     -3.3386719226837158e-01
    z[3,1,2]  R1032     5.8001782745122910e-02
    z[3,1,2]  R1033     2.7561190724372864e-01
    z[3,1,2]  R1034     4.6525120735168457e-01
    z[3,1,2]  R1035     4.9158122390508652e-02
    z[3,1,2]  R1036     -1.9451542198657990e-01
    z[3,1,2]  R1037     0.456400066614151
    z[3,1,2]  R1038     -1.8513631820678711e-01
    z[3,1,2]  R1039     2.5300800800323486e-01
    z[3,1,2]  R1040     1.6776071488857269e-01
    z[3,1,2]  R1041     2.2591666877269745e-01
    z[3,1,2]  R1042     4.1885474324226379e-01
    z[3,1,2]  R1043     6.4915120601654053e-01
    z[3,1,2]  R1044     3.0353426933288574e-01
    z[3,1,2]  R1045     -0.142684206366539
    z[3,1,2]  R1046     4.0329253673553467e-01
    z[3,1,2]  R1047     5.1168125867843628e-01
    z[3,1,2]  R1048     2.2234684228897095e-01
    z[3,1,2]  R1049     2.4198077619075775e-01
    z[3,1,2]  R1050     1.9835273921489716e-01
    z[3,1,2]  R1051     2.9536345601081848e-01
    z[3,1,2]  R1052     0.591578483581543
    z[3,1,2]  R1053     4.2835199832916260e-01
    z[3,1,2]  R1054     3.6957284808158875e-01
    z[3,1,2]  R1055     3.5678908228874207e-01
    z[3,1,2]  R1056     6.9865697622299194e-01
    z[3,1,2]  R1057     -0.00870123878121376
    z[3,1,2]  R1058     7.8830993175506592e-01
    z[3,1,2]  R1059     0.0234073456376791
    z[3,1,2]  R1060     0.83809494972229
    z[3,1,2]  R1061     -2.3189926519989967e-02
    z[3,1,2]  R1062     6.6558992862701416e-01
    z[3,1,2]  R1063     -6.3357698917388916e-01
    z[3,1,2]  R1064     -5.5956327915191650e-01
    z[3,1,2]  R1065     3.6189684271812439e-01
    z[3,1,2]  R1066     3.7515515089035034e-01
    z[3,1,2]  R1067     4.3275609612464905e-01
    z[3,1,2]  R1068     4.4035500288009644e-01
    z[3,1,2]  R1069     0.510381281375885
    z[3,1,2]  R1070     4.1040968894958496e-01
    z[3,1,2]  R1071     6.4251035451889038e-01
    z[3,1,2]  R1072     -4.5409896969795227e-01
    z[3,1,2]  R1073     6.4309597015380859e-01
    z[3,1,2]  R1074     1.8638938665390015e-01
    z[3,1,2]  R1075     -1.3868586719036102e-01
    z[3,1,2]  R1076     -1.0716875083744526e-02
    z[3,1,2]  R1077     -4.7345027327537537e-01
    z[3,1,2]  R1078     1.2176910787820816e-01
    z[3,1,2]  R1079     1.8041385710239410e-01
    z[3,1,2]  R1080     3.8921785354614258e-01
    z[3,1,2]  R1081     5.0720632076263428e-01
    z[3,1,2]  R1082     -4.7103241086006165e-02
    z[3,1,2]  R1083     -6.8664395809173584e-01
    z[3,1,2]  R1084     6.2752717733383179e-01
    z[3,1,2]  R1085     2.5780880451202393e-01
    z[3,1,2]  R1086     5.6103730201721191e-01
    z[3,1,2]  R1087     4.3118435144424438e-01
    z[3,1,2]  R1088     5.1037895679473877e-01
    z[3,1,2]  R1089     2.1010838449001312e-02
    z[3,1,2]  R1090     4.4596254825592041e-01
    z[3,1,2]  R1091     1.1814925074577332e-01
    z[3,1,2]  R1092     7.2799527645111084e-01
    z[3,1,2]  R1093     1.6364777088165283e-01
    z[3,1,2]  R1094     4.1928282380104065e-01
    z[3,1,2]  R1095     3.5021528601646423e-01
    z[3,1,2]  R1096     9.6968859434127808e-02
    z[3,1,2]  R1097     1.0210317373275757e-01
    z[3,1,2]  R1098     -4.1711616516113281e-01
    z[3,1,2]  R1099     -3.4999263286590576e-01
    z[3,1,2]  R1100     -5.9964990615844727e-01
    z[3,1,2]  R1101     -0.438488632440567
    z[3,1,2]  R1102     -1.9925607740879059e-01
    z[3,1,2]  R1103     -3.2785028219223022e-01
    z[3,1,2]  R1104     -7.2761642932891846e-01
    z[3,1,2]  R1105     7.2494186460971832e-02
    z[3,1,2]  R1106     9.0446047484874725e-02
    z[3,1,2]  R1107     -3.4528259187936783e-02
    z[3,1,2]  R1108     8.5024453699588776e-02
    z[3,1,2]  R1109     2.3083847761154175e-01
    z[3,1,2]  R1110     2.1506215631961823e-01
    z[3,1,2]  R1111     -2.6834979653358459e-01
    z[3,1,2]  R1112     -2.7630642056465149e-02
    z[3,1,2]  R1113     -4.4226527214050293e-01
    z[3,1,2]  R1114     1.0201875865459442e-01
    z[3,1,2]  R1115     -0.326465904712677
    z[3,1,2]  R1116     -6.1449509859085083e-01
    z[3,1,2]  R1117     -3.5805395245552063e-01
    z[3,1,2]  R1118     1.8681395053863525e-01
    z[3,1,2]  R1119     -5.6713706254959106e-01
    z[3,1,2]  R1120     7.0076537132263184e-01
    z[3,1,2]  R1121     -8.1679157912731171e-02
    z[3,1,2]  R1122     7.4630357325077057e-02
    z[3,1,2]  R1123     -3.0827391147613525e-01
    z[3,1,2]  R1124     -1.6502179205417633e-01
    z[3,1,2]  R1125     -5.4879003763198853e-01
    z[3,1,2]  R1126     -4.3301945924758911e-01
    z[3,1,2]  R1127     -5.0865966081619263e-01
    z[3,1,2]  R1128     6.4753150939941406e-01
    z[3,1,2]  R1129     6.5141016244888306e-01
    z[3,1,2]  R1130     9.0096151828765869e-01
    z[3,1,2]  R1131     2.7205786108970642e-01
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R1014     -1
    z[3,1,3]  R1015     1
    z[3,1,3]  R1022     -1.8925718963146210e-01
    z[3,1,3]  R1023     -2.4206961691379547e-01
    z[3,1,3]  R1024     -0.221385195851326
    z[3,1,3]  R1025     -7.9649955034255981e-01
    z[3,1,3]  R1026     -3.4430682659149170e-01
    z[3,1,3]  R1027     -3.9871323108673096e-01
    z[3,1,3]  R1028     -2.5169461965560913e-01
    z[3,1,3]  R1029     -4.0956640243530273e-01
    z[3,1,3]  R1030     -6.7413115501403809e-01
    z[3,1,3]  R1031     -3.4015771746635437e-01
    z[3,1,3]  R1032     0.764613926410675
    z[3,1,3]  R1033     -5.8764559030532837e-01
    z[3,1,3]  R1034     -7.7875353395938873e-02
    z[3,1,3]  R1035     8.4801214933395386e-01
    z[3,1,3]  R1036     8.6049139499664307e-01
    z[3,1,3]  R1037     5.7995426654815674e-01
    z[3,1,3]  R1038     7.9041171073913574e-01
    z[3,1,3]  R1039     -3.1717292964458466e-02
    z[3,1,3]  R1040     6.2472563982009888e-01
    z[3,1,3]  R1041     2.7844116091728210e-01
    z[3,1,3]  R1042     -5.2439391613006592e-01
    z[3,1,3]  R1043     1.4728824794292450e-01
    z[3,1,3]  R1044     6.5796025097370148e-02
    z[3,1,3]  R1045     -0.224580317735672
    z[3,1,3]  R1046     3.2414516806602478e-01
    z[3,1,3]  R1047     1.1617504805326462e-01
    z[3,1,3]  R1048     4.1859525442123413e-01
    z[3,1,3]  R1049     8.2857191562652588e-02
    z[3,1,3]  R1050     2.9513800144195557e-01
    z[3,1,3]  R1051     5.4498338699340820e-01
    z[3,1,3]  R1052     -1.4877954125404358e-01
    z[3,1,3]  R1053     -1.1835643090307713e-02
    z[3,1,3]  R1054     -0.0822002962231636
    z[3,1,3]  R1055     -1.2596678733825684e-01
    z[3,1,3]  R1056     1.1937101930379868e-01
    z[3,1,3]  R1057     -4.4053740799427032e-02
    z[3,1,3]  R1058     -2.3050174117088318e-01
    z[3,1,3]  R1059     -0.168934166431427
    z[3,1,3]  R1060     -1.3055580854415894e-01
    z[3,1,3]  R1061     -5.7930290699005127e-01
    z[3,1,3]  R1062     -0.125800222158432
    z[3,1,3]  R1063     -6.2831813097000122e-01
    z[3,1,3]  R1064     -6.0615569353103638e-01
    z[3,1,3]  R1065     4.1915714740753174e-02
    z[3,1,3]  R1066     6.7114210128784180e-01
    z[3,1,3]  R1067     -3.5161364078521729e-01
    z[3,1,3]  R1068     4.2544767260551453e-01
    z[3,1,3]  R1069     2.8327226638793945e-01
    z[3,1,3]  R1070     1.6467611491680145e-01
    z[3,1,3]  R1071     7.4989847838878632e-02
    z[3,1,3]  R1072     -4.5076709985733032e-01
    z[3,1,3]  R1073     -5.2277642488479614e-01
    z[3,1,3]  R1074     -5.4149228334426880e-01
    z[3,1,3]  R1075     -7.2312670946121216e-01
    z[3,1,3]  R1076     -4.5369812846183777e-01
    z[3,1,3]  R1077     -3.5828915238380432e-01
    z[3,1,3]  R1078     -1.5464001893997192e-01
    z[3,1,3]  R1079     -2.0803090929985046e-01
    z[3,1,3]  R1080     -3.4947675466537476e-01
    z[3,1,3]  R1081     -1.6266277059912682e-02
    z[3,1,3]  R1082     -4.9394932389259338e-01
    z[3,1,3]  R1083     -4.3957000970840454e-01
    z[3,1,3]  R1084     -1.2109193205833435e-01
    z[3,1,3]  R1085     -2.4200929701328278e-01
    z[3,1,3]  R1086     -5.9272092580795288e-01
    z[3,1,3]  R1087     2.7310448884963989e-01
    z[3,1,3]  R1088     -2.6991853117942810e-01
    z[3,1,3]  R1089     1.3952843844890594e-01
    z[3,1,3]  R1090     1.7272329330444336e-01
    z[3,1,3]  R1091     4.0151754021644592e-01
    z[3,1,3]  R1092     -1.4502698183059692e-01
    z[3,1,3]  R1093     -2.2398833185434341e-02
    z[3,1,3]  R1094     1.6994623839855194e-01
    z[3,1,3]  R1095     0.409463107585907
    z[3,1,3]  R1096     3.1296434998512268e-01
    z[3,1,3]  R1097     3.5010293126106262e-01
    z[3,1,3]  R1098     0.400585800409317
    z[3,1,3]  R1099     5.1017558574676514e-01
    z[3,1,3]  R1100     6.4175719022750854e-01
    z[3,1,3]  R1101     7.9267239570617676e-01
    z[3,1,3]  R1102     4.1571286320686340e-01
    z[3,1,3]  R1103     5.2801431156694889e-03
    z[3,1,3]  R1104     2.3760001361370087e-01
    z[3,1,3]  R1105     4.4579803943634033e-01
    z[3,1,3]  R1106     4.1010746359825134e-01
    z[3,1,3]  R1107     0.0699441209435463
    z[3,1,3]  R1108     -2.7111726999282837e-01
    z[3,1,3]  R1109     3.5323426127433777e-03
    z[3,1,3]  R1110     -1.5383604168891907e-01
    z[3,1,3]  R1111     -4.1269126534461975e-01
    z[3,1,3]  R1112     -7.1397058665752411e-02
    z[3,1,3]  R1113     1.3254101388156414e-02
    z[3,1,3]  R1114     -0.062924325466156
    z[3,1,3]  R1115     2.9293122887611389e-01
    z[3,1,3]  R1116     6.8340882658958435e-02
    z[3,1,3]  R1117     -1.5282213687896729e-01
    z[3,1,3]  R1118     -7.1344166994094849e-01
    z[3,1,3]  R1119     -4.9946320056915283e-01
    z[3,1,3]  R1120     -5.0770968198776245e-01
    z[3,1,3]  R1121     -5.8048856258392334e-01
    z[3,1,3]  R1122     -2.9847297072410583e-01
    z[3,1,3]  R1123     5.1173716783523560e-01
    z[3,1,3]  R1124     3.4743675589561462e-01
    z[3,1,3]  R1125     -4.6729825437068939e-02
    z[3,1,3]  R1126     -1.2129744887351990e-01
    z[3,1,3]  R1127     1.2098416686058044e-01
    z[3,1,3]  R1128     -6.5261560678482056e-01
    z[3,1,3]  R1129     -3.6690777540206909e-01
    z[3,1,3]  R1130     -1.4384835958480835e-01
    z[3,1,3]  R1131     -3.5192090272903442e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R1016     -1
    z[3,1,4]  R1017     1
    z[3,1,4]  R1022     -1.2922429479658604e-02
    z[3,1,4]  R1023     -3.3408230543136597e-01
    z[3,1,4]  R1024     -3.7047231197357178e-01
    z[3,1,4]  R1025     1.0382376611232758e-01
    z[3,1,4]  R1026     -5.7068582624197006e-02
    z[3,1,4]  R1027     -4.5437198132276535e-02
    z[3,1,4]  R1028     1.0979046672582626e-01
    z[3,1,4]  R1029     6.2426459789276123e-01
    z[3,1,4]  R1030     1.6458596289157867e-01
    z[3,1,4]  R1031     -1.9093267619609833e-01
    z[3,1,4]  R1032     1.5055269002914429e-01
    z[3,1,4]  R1033     4.7900673747062683e-01
    z[3,1,4]  R1034     6.8221485614776611e-01
    z[3,1,4]  R1035     -2.4003732204437256e-01
    z[3,1,4]  R1036     8.7532445788383484e-02
    z[3,1,4]  R1037     1.3894857466220856e-01
    z[3,1,4]  R1038     -2.3357519507408142e-01
    z[3,1,4]  R1039     3.6047333478927612e-01
    z[3,1,4]  R1040     -1.7176365852355957e-01
    z[3,1,4]  R1041     3.8407412171363831e-01
    z[3,1,4]  R1042     3.0290532857179642e-02
    z[3,1,4]  R1043     1.6972228884696960e-01
    z[3,1,4]  R1044     -2.6506516337394714e-01
    z[3,1,4]  R1045     -6.5742902457714081e-02
    z[3,1,4]  R1046     3.7353450059890747e-01
    z[3,1,4]  R1047     -1.9902090728282928e-01
    z[3,1,4]  R1048     -1.7694956064224243e-01
    z[3,1,4]  R1049     -3.5701495409011841e-01
    z[3,1,4]  R1050     -4.2548492550849915e-01
    z[3,1,4]  R1051     -2.7885007858276367e-01
    z[3,1,4]  R1052     -3.0204278230667114e-01
    z[3,1,4]  R1053     -6.5034247934818268e-02
    z[3,1,4]  R1054     1.4242146909236908e-01
    z[3,1,4]  R1055     -3.8372558355331421e-01
    z[3,1,4]  R1056     -2.7505305409431458e-01
    z[3,1,4]  R1057     -3.5697260499000549e-01
    z[3,1,4]  R1058     1.1379770934581757e-01
    z[3,1,4]  R1059     4.8987287282943726e-01
    z[3,1,4]  R1060     2.1615803241729736e-01
    z[3,1,4]  R1061     3.1966876983642578e-01
    z[3,1,4]  R1062     2.2724738717079163e-01
    z[3,1,4]  R1063     3.7069374322891235e-01
    z[3,1,4]  R1064     -4.7022711485624313e-02
    z[3,1,4]  R1065     5.0512617826461792e-01
    z[3,1,4]  R1066     9.9318593740463257e-02
    z[3,1,4]  R1067     6.3165497779846191e-01
    z[3,1,4]  R1068     0.0630766972899437
    z[3,1,4]  R1069     0.0745469257235527
    z[3,1,4]  R1070     4.1779968142509460e-01
    z[3,1,4]  R1071     -8.4193728864192963e-02
    z[3,1,4]  R1072     1.8353018164634705e-01
    z[3,1,4]  R1073     1.4879144728183746e-01
    z[3,1,4]  R1074     -1.8214456737041473e-01
    z[3,1,4]  R1075     2.5692921876907349e-01
    z[3,1,4]  R1076     5.9604948759078979e-01
    z[3,1,4]  R1077     1.8044304102659225e-02
    z[3,1,4]  R1078     3.6404874920845032e-01
    z[3,1,4]  R1079     2.3396741598844528e-02
    z[3,1,4]  R1080     -2.8300735354423523e-01
    z[3,1,4]  R1081     -1.9731599092483521e-01
    z[3,1,4]  R1082     -4.4487681239843369e-02
    z[3,1,4]  R1083     3.2666184008121490e-02
    z[3,1,4]  R1084     1.5206189453601837e-01
    z[3,1,4]  R1085     9.2810891568660736e-02
    z[3,1,4]  R1086     9.6238173544406891e-02
    z[3,1,4]  R1087     -1.3673400878906250e-01
    z[3,1,4]  R1088     -2.0141109824180603e-01
    z[3,1,4]  R1089     2.3014084994792938e-01
    z[3,1,4]  R1090     -2.4442131817340851e-01
    z[3,1,4]  R1091     9.3896873295307159e-02
    z[3,1,4]  R1092     2.7465993165969849e-01
    z[3,1,4]  R1093     -1.7549371719360352e-01
    z[3,1,4]  R1094     -2.2474156320095062e-01
    z[3,1,4]  R1095     3.3653992414474487e-01
    z[3,1,4]  R1096     2.3855890333652496e-01
    z[3,1,4]  R1097     1.3736869394779205e-01
    z[3,1,4]  R1098     7.3812989285215735e-04
    z[3,1,4]  R1099     -5.2129936218261719e-01
    z[3,1,4]  R1100     -2.2389587759971619e-01
    z[3,1,4]  R1101     -2.0287160575389862e-01
    z[3,1,4]  R1102     -1.9522084295749664e-01
    z[3,1,4]  R1103     -5.5625919252634048e-02
    z[3,1,4]  R1104     -1.1468805372714996e-01
    z[3,1,4]  R1105     2.8277322649955750e-01
    z[3,1,4]  R1106     -4.1842761635780334e-01
    z[3,1,4]  R1107     -5.1813744008541107e-02
    z[3,1,4]  R1108     1.5262334048748016e-01
    z[3,1,4]  R1109     -3.9830081164836884e-02
    z[3,1,4]  R1110     -3.4797763824462891e-01
    z[3,1,4]  R1111     -1.8198819458484650e-01
    z[3,1,4]  R1112     5.0782209634780884e-01
    z[3,1,4]  R1113     5.0541943311691284e-01
    z[3,1,4]  R1114     7.0441913604736328e-01
    z[3,1,4]  R1115     1.5030542016029358e-01
    z[3,1,4]  R1116     1.8428441882133484e-01
    z[3,1,4]  R1117     0.532706618309021
    z[3,1,4]  R1118     4.6939682960510254e-01
    z[3,1,4]  R1119     -1.0630524903535843e-01
    z[3,1,4]  R1120     -1.1071750521659851e-01
    z[3,1,4]  R1121     -3.0283406376838684e-03
    z[3,1,4]  R1122     1.0974252223968506e-01
    z[3,1,4]  R1123     -1.2475372105836868e-01
    z[3,1,4]  R1124     2.1234643459320068e-01
    z[3,1,4]  R1125     1.4340290427207947e-01
    z[3,1,4]  R1126     4.1452908515930176e-01
    z[3,1,4]  R1127     -2.9557171463966370e-01
    z[3,1,4]  R1128     1.0928661562502384e-02
    z[3,1,4]  R1129     -3.0401936173439026e-01
    z[3,1,4]  R1130     1.9716110825538635e-01
    z[3,1,4]  R1131     4.9992737174034119e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R1018     -1
    z[3,1,5]  R1019     1
    z[3,1,5]  R1022     -7.1594923734664917e-02
    z[3,1,5]  R1023     1.2033394724130630e-01
    z[3,1,5]  R1024     -4.3070587515830994e-01
    z[3,1,5]  R1025     -2.2164934873580933e-01
    z[3,1,5]  R1026     -0.824120044708252
    z[3,1,5]  R1027     1.4033000171184540e-01
    z[3,1,5]  R1028     -9.9121198058128357e-02
    z[3,1,5]  R1029     3.9948695898056030e-01
    z[3,1,5]  R1030     2.8855550289154053e-01
    z[3,1,5]  R1031     0.0670010894536972
    z[3,1,5]  R1032     5.5497944355010986e-02
    z[3,1,5]  R1033     5.1751244068145752e-01
    z[3,1,5]  R1034     -7.3180519044399261e-02
    z[3,1,5]  R1035     1.2180896848440170e-01
    z[3,1,5]  R1036     1.0028154402971268e-01
    z[3,1,5]  R1037     -3.4219104051589966e-01
    z[3,1,5]  R1038     7.0903427898883820e-02
    z[3,1,5]  R1039     7.6070673763751984e-02
    z[3,1,5]  R1040     -3.0782202258706093e-02
    z[3,1,5]  R1041     4.3729510903358459e-01
    z[3,1,5]  R1042     1.6473619639873505e-01
    z[3,1,5]  R1043     -2.7248337864875793e-02
    z[3,1,5]  R1044     9.6197031438350677e-02
    z[3,1,5]  R1045     6.0163778066635132e-01
    z[3,1,5]  R1046     -6.0983706265687943e-02
    z[3,1,5]  R1047     2.5788676738739014e-01
    z[3,1,5]  R1048     -0.0456160232424736
    z[3,1,5]  R1049     -2.1228650212287903e-01
    z[3,1,5]  R1050     -1.7278324067592621e-01
    z[3,1,5]  R1051     -1.4928644895553589e-01
    z[3,1,5]  R1052     -4.2609229683876038e-01
    z[3,1,5]  R1053     1.2111280113458633e-01
    z[3,1,5]  R1054     -2.1845720708370209e-01
    z[3,1,5]  R1055     -2.6794201135635376e-01
    z[3,1,5]  R1056     -2.8001922369003296e-01
    z[3,1,5]  R1057     -0.5264852643013
    z[3,1,5]  R1058     -2.5525093078613281e-01
    z[3,1,5]  R1059     -2.4217948317527771e-02
    z[3,1,5]  R1060     -2.8848379850387573e-01
    z[3,1,5]  R1061     4.3418622016906738e-01
    z[3,1,5]  R1062     -1.5303204953670502e-01
    z[3,1,5]  R1063     -9.2712230980396271e-02
    z[3,1,5]  R1064     3.8863378763198853e-01
    z[3,1,5]  R1065     -3.1936866044998169e-01
    z[3,1,5]  R1066     2.8483736515045166e-01
    z[3,1,5]  R1067     2.1372631192207336e-01
    z[3,1,5]  R1068     -2.8907996416091919e-01
    z[3,1,5]  R1069     1.0884429514408112e-01
    z[3,1,5]  R1070     0.0377860963344574
    z[3,1,5]  R1071     -0.294871985912323
    z[3,1,5]  R1072     0.430424302816391
    z[3,1,5]  R1073     -1.1839371919631958e-01
    z[3,1,5]  R1074     -4.5698404312133789e-01
    z[3,1,5]  R1075     5.8323782682418823e-01
    z[3,1,5]  R1076     -3.4498110413551331e-01
    z[3,1,5]  R1077     5.0153142213821411e-01
    z[3,1,5]  R1078     -6.6374707221984863e-01
    z[3,1,5]  R1079     0.896765947341919
    z[3,1,5]  R1080     7.0995688438415527e-01
    z[3,1,5]  R1081     -4.7227197885513306e-01
    z[3,1,5]  R1082     7.5401091575622559e-01
    z[3,1,5]  R1083     2.3110548034310341e-02
    z[3,1,5]  R1084     -4.5502327382564545e-02
    z[3,1,5]  R1085     -1.5141440927982330e-01
    z[3,1,5]  R1086     4.6859785914421082e-01
    z[3,1,5]  R1087     -2.0513559877872467e-01
    z[3,1,5]  R1088     2.1855992078781128e-01
    z[3,1,5]  R1089     -1.1159786581993103e-01
    z[3,1,5]  R1090     6.7691020667552948e-02
    z[3,1,5]  R1091     5.2345430850982666e-01
    z[3,1,5]  R1092     -1.7096638679504395e-01
    z[3,1,5]  R1093     -7.6470810174942017e-01
    z[3,1,5]  R1094     -1.7447984218597412e-01
    z[3,1,5]  R1095     -0.0942888930439949
    z[3,1,5]  R1096     8.8665008544921875e-02
    z[3,1,5]  R1097     4.5969173312187195e-01
    z[3,1,5]  R1098     -1.0222969204187393e-01
    z[3,1,5]  R1099     4.4253578782081604e-01
    z[3,1,5]  R1100     2.3229949176311493e-01
    z[3,1,5]  R1101     6.2652014195919037e-02
    z[3,1,5]  R1102     4.5144062489271164e-02
    z[3,1,5]  R1103     5.1510158926248550e-02
    z[3,1,5]  R1104     -3.9596560597419739e-01
    z[3,1,5]  R1105     -3.4057098627090454e-01
    z[3,1,5]  R1106     -6.3107395172119141e-01
    z[3,1,5]  R1107     -1.0247718542814255e-01
    z[3,1,5]  R1108     -3.4925499558448792e-01
    z[3,1,5]  R1109     4.0217429399490356e-01
    z[3,1,5]  R1110     -1.4051049947738647e-01
    z[3,1,5]  R1111     -2.4994817376136780e-01
    z[3,1,5]  R1112     -4.4802263379096985e-01
    z[3,1,5]  R1113     -2.0324413478374481e-01
    z[3,1,5]  R1114     -1.0597249493002892e-02
    z[3,1,5]  R1115     -3.6264079809188843e-01
    z[3,1,5]  R1116     4.3007194995880127e-01
    z[3,1,5]  R1117     3.4774327278137207e-01
    z[3,1,5]  R1118     5.7146232575178146e-02
    z[3,1,5]  R1119     5.0299829244613647e-01
    z[3,1,5]  R1120     3.9705076813697815e-01
    z[3,1,5]  R1121     -4.2692460119724274e-02
    z[3,1,5]  R1122     -5.0250776112079620e-02
    z[3,1,5]  R1123     1.9489030539989471e-01
    z[3,1,5]  R1124     4.0899339318275452e-01
    z[3,1,5]  R1125     1.7612640559673309e-01
    z[3,1,5]  R1126     2.3359447717666626e-01
    z[3,1,5]  R1127     4.1298249363899231e-01
    z[3,1,5]  R1128     2.2846752777695656e-02
    z[3,1,5]  R1129     2.2896414995193481e-01
    z[3,1,5]  R1130     0.241278275847435
    z[3,1,5]  R1131     2.1940311789512634e-01
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R1020     -1
    z[3,1,6]  R1021     1
    z[3,1,6]  R1022     -1.0292565822601318e-01
    z[3,1,6]  R1023     4.2694514989852905e-01
    z[3,1,6]  R1024     2.8673991560935974e-01
    z[3,1,6]  R1025     -1.7907572910189629e-02
    z[3,1,6]  R1026     -4.6501882374286652e-02
    z[3,1,6]  R1027     2.7039566636085510e-01
    z[3,1,6]  R1028     -2.3802092671394348e-01
    z[3,1,6]  R1029     -2.8519439697265625e-01
    z[3,1,6]  R1030     -1.6427727416157722e-02
    z[3,1,6]  R1031     4.0089237689971924e-01
    z[3,1,6]  R1032     1.4535829424858093e-02
    z[3,1,6]  R1033     -1.4709062874317169e-01
    z[3,1,6]  R1034     -4.9917469732463360e-03
    z[3,1,6]  R1035     -1.7179638147354126e-02
    z[3,1,6]  R1036     -4.5078076422214508e-02
    z[3,1,6]  R1037     1.2207396328449249e-01
    z[3,1,6]  R1038     -2.9277160763740540e-01
    z[3,1,6]  R1039     4.7871533036231995e-01
    z[3,1,6]  R1040     -4.5756044983863831e-01
    z[3,1,6]  R1041     -1.9415043294429779e-01
    z[3,1,6]  R1042     -8.5624635219573975e-02
    z[3,1,6]  R1043     -2.2068157792091370e-01
    z[3,1,6]  R1044     -2.5803956389427185e-01
    z[3,1,6]  R1045     -1.2441388517618179e-01
    z[3,1,6]  R1046     -1.2177091836929321e-01
    z[3,1,6]  R1047     -1.4720830321311951e-01
    z[3,1,6]  R1048     2.0740801095962524e-01
    z[3,1,6]  R1049     -5.9064473956823349e-02
    z[3,1,6]  R1050     1.2667530775070190e-01
    z[3,1,6]  R1051     -1.1722601950168610e-01
    z[3,1,6]  R1052     3.1874611973762512e-01
    z[3,1,6]  R1053     1.7620076239109039e-01
    z[3,1,6]  R1054     -4.6389183402061462e-01
    z[3,1,6]  R1055     3.3987739682197571e-01
    z[3,1,6]  R1056     -1.2304409593343735e-01
    z[3,1,6]  R1057     -1.5102137625217438e-01
    z[3,1,6]  R1058     3.6426514387130737e-01
    z[3,1,6]  R1059     1.1635456979274750e-01
    z[3,1,6]  R1060     -2.9351255297660828e-01
    z[3,1,6]  R1061     2.3197162151336670e-01
    z[3,1,6]  R1062     1.4954103529453278e-01
    z[3,1,6]  R1063     1.1755497753620148e-01
    z[3,1,6]  R1064     -7.6021656394004822e-02
    z[3,1,6]  R1065     3.6324289441108704e-01
    z[3,1,6]  R1066     -2.1538391709327698e-01
    z[3,1,6]  R1067     4.4994466006755829e-02
    z[3,1,6]  R1068     2.5756680965423584e-01
    z[3,1,6]  R1069     -9.1338776051998138e-02
    z[3,1,6]  R1070     -2.0584285259246826e-01
    z[3,1,6]  R1071     -3.1190514564514160e-01
    z[3,1,6]  R1072     -4.1874065995216370e-01
    z[3,1,6]  R1073     2.1480417251586914e-01
    z[3,1,6]  R1074     3.3693531155586243e-01
    z[3,1,6]  R1075     2.6994548738002777e-02
    z[3,1,6]  R1076     1.6113099455833435e-01
    z[3,1,6]  R1077     2.1039338409900665e-01
    z[3,1,6]  R1078     2.6457908749580383e-01
    z[3,1,6]  R1079     -1.9243661314249039e-02
    z[3,1,6]  R1080     -2.2608275711536407e-01
    z[3,1,6]  R1081     1.1658965051174164e-01
    z[3,1,6]  R1082     -3.4674385190010071e-01
    z[3,1,6]  R1083     -2.0819826424121857e-01
    z[3,1,6]  R1084     -3.6833170056343079e-01
    z[3,1,6]  R1085     4.3919944763183594e-01
    z[3,1,6]  R1086     2.0566870272159576e-01
    z[3,1,6]  R1087     -2.2956621646881104e-01
    z[3,1,6]  R1088     1.0010523721575737e-02
    z[3,1,6]  R1089     -3.8473281264305115e-01
    z[3,1,6]  R1090     -6.1834228038787842e-01
    z[3,1,6]  R1091     -1.2329224497079849e-01
    z[3,1,6]  R1092     -1.6788972914218903e-01
    z[3,1,6]  R1093     -1.7228076234459877e-02
    z[3,1,6]  R1094     -2.4053168296813965e-01
    z[3,1,6]  R1095     -1.7618584632873535e-01
    z[3,1,6]  R1096     -3.4975594282150269e-01
    z[3,1,6]  R1097     -7.9743430018424988e-02
    z[3,1,6]  R1098     -1.9918261468410492e-01
    z[3,1,6]  R1099     -1.5136629343032837e-01
    z[3,1,6]  R1100     2.3564919829368591e-02
    z[3,1,6]  R1101     4.8643615096807480e-02
    z[3,1,6]  R1102     4.4508108496665955e-01
    z[3,1,6]  R1103     -4.6299800276756287e-01
    z[3,1,6]  R1104     -1.1209972202777863e-01
    z[3,1,6]  R1105     -3.7462544441223145e-01
    z[3,1,6]  R1106     -2.7219581604003906e-01
    z[3,1,6]  R1107     5.1093274354934692e-01
    z[3,1,6]  R1108     2.6656261086463928e-01
    z[3,1,6]  R1109     -1.5174549818038940e-01
    z[3,1,6]  R1110     -3.5464456677436829e-01
    z[3,1,6]  R1111     -5.2352637052536011e-01
    z[3,1,6]  R1112     -1.9029730930924416e-02
    z[3,1,6]  R1113     1.1859763413667679e-02
    z[3,1,6]  R1114     1.6963452100753784e-01
    z[3,1,6]  R1115     -4.3357063084840775e-02
    z[3,1,6]  R1116     1.4768348634243011e-01
    z[3,1,6]  R1117     3.8006898760795593e-01
    z[3,1,6]  R1118     -0.208759143948555
    z[3,1,6]  R1119     1.0208845883607864e-01
    z[3,1,6]  R1120     1.4676529169082642e-01
    z[3,1,6]  R1121     4.4861856102943420e-01
    z[3,1,6]  R1122     -3.4222227334976196e-01
    z[3,1,6]  R1123     1.1750672757625580e-01
    z[3,1,6]  R1124     1.0847406834363937e-01
    z[3,1,6]  R1125     -3.1713131070137024e-01
    z[3,1,6]  R1126     2.5246149301528931e-01
    z[3,1,6]  R1127     -1.7355036735534668e-01
    z[3,1,6]  R1128     -1.5159356594085693e-01
    z[3,1,6]  R1129     3.0916744470596313e-01
    z[3,1,6]  R1130     2.3593175411224365e-01
    z[3,1,6]  R1131     -1.3633179664611816e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1132     -1
    z[1,4,0]  R1133     1
    z[1,4,0]  R1146     -4.9690928310155869e-02
    z[1,4,0]  R1147     -5.8148401975631714e-01
    z[1,4,0]  R1148     -1.1177226155996323e-01
    z[1,4,0]  R1149     -6.1769241094589233e-01
    z[1,4,0]  R1150     1.4331138134002686e-01
    z[1,4,0]  R1151     6.5243035554885864e-01
    z[1,4,0]  R1152     6.3770312070846558e-01
    z[1,4,0]  R1153     2.9630595818161964e-02
    z[1,4,0]  R1154     4.4086730480194092e-01
    z[1,4,0]  R1155     2.9334232211112976e-01
    z[1,4,0]  R1156     1.6809152066707611e-01
    z[1,4,0]  R1157     -0.023863660171628
    z[1,4,0]  R1158     -1.1202633380889893e-01
    z[1,4,0]  R1159     1.9880126416683197e-01
    z[1,4,0]  R1160     -1.3381104171276093e-01
    z[1,4,0]  R1161     -7.3125801980495453e-02
    z[1,4,0]  R1162     -1.5840733423829079e-02
    z[1,4,0]  R1163     1.9686248898506165e-01
    z[1,4,0]  R1164     2.2745615243911743e-01
    z[1,4,0]  R1165     -6.1484247446060181e-01
    z[1,4,0]  R1166     1.7498087882995605e-01
    z[1,4,0]  R1167     8.2255318760871887e-02
    z[1,4,0]  R1168     -2.1478015184402466e-01
    z[1,4,0]  R1169     -1.9356778264045715e-01
    z[1,4,0]  R1170     3.4069761633872986e-02
    z[1,4,0]  R1171     1.0933275334537029e-02
    z[1,4,0]  R1172     3.0830252170562744e-01
    z[1,4,0]  R1173     4.4244241714477539e-01
    z[1,4,0]  R1174     5.9359449893236160e-02
    z[1,4,0]  R1175     6.1092221736907959e-01
    z[1,4,0]  R1176     -8.4715768694877625e-02
    z[1,4,0]  R1177     3.7786862254142761e-01
    z[1,4,0]  R1178     -1.0474388301372528e-01
    z[1,4,0]  R1179     -4.3095737695693970e-01
    z[1,4,0]  R1180     -5.7242126204073429e-03
    z[1,4,0]  R1181     -1.0527808219194412e-01
    z[1,4,0]  R1182     -1.3672526180744171e-01
    z[1,4,0]  R1183     -2.7547001838684082e-01
    z[1,4,0]  R1184     5.8763694763183594e-01
    z[1,4,0]  R1185     4.1692918539047241e-01
    z[1,4,0]  R1186     3.1882929615676403e-03
    z[1,4,0]  R1187     0.350115031003952
    z[1,4,0]  R1188     1.0460475832223892e-01
    z[1,4,0]  R1189     4.6982610225677490e-01
    z[1,4,0]  R1190     -2.1524028852581978e-02
    z[1,4,0]  R1191     4.8068743199110031e-02
    z[1,4,0]  R1192     -1.2982851266860962e-01
    z[1,4,0]  R1193     -5.4572790861129761e-02
    z[1,4,0]  R1194     9.8200999200344086e-02
    z[1,4,0]  R1195     -7.6632252894341946e-03
    z[1,4,0]  R1196     2.2449608147144318e-01
    z[1,4,0]  R1197     1.2216307967901230e-01
    z[1,4,0]  R1198     2.6040667295455933e-01
    z[1,4,0]  R1199     4.6720737218856812e-01
    z[1,4,0]  R1200     4.2385819554328918e-01
    z[1,4,0]  R1201     4.0700322389602661e-01
    z[1,4,0]  R1202     1.1096493899822235e-01
    z[1,4,0]  R1203     5.0646132230758667e-01
    z[1,4,0]  R1204     0.467808336019516
    z[1,4,0]  R1205     4.6968027949333191e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1134     -1
    z[1,4,1]  R1135     1
    z[1,4,1]  R1146     -7.3943519592285156e-01
    z[1,4,1]  R1147     -5.7814192771911621e-01
    z[1,4,1]  R1148     -4.6810141205787659e-01
    z[1,4,1]  R1149     -2.7959123253822327e-01
    z[1,4,1]  R1150     -3.9454612135887146e-01
    z[1,4,1]  R1151     5.4222857952117920e-01
    z[1,4,1]  R1152     5.4430902004241943e-01
    z[1,4,1]  R1153     8.7147343158721924e-01
    z[1,4,1]  R1154     6.8491917848587036e-01
    z[1,4,1]  R1155     5.4950064420700073e-01
    z[1,4,1]  R1156     0.711979329586029
    z[1,4,1]  R1157     7.1186983585357666e-01
    z[1,4,1]  R1158     6.6931933164596558e-01
    z[1,4,1]  R1159     7.8237426280975342e-01
    z[1,4,1]  R1160     5.9923851490020752e-01
    z[1,4,1]  R1161     5.4216337203979492e-01
    z[1,4,1]  R1162     4.3436288833618164e-01
    z[1,4,1]  R1163     3.3971610665321350e-01
    z[1,4,1]  R1164     -8.9301742613315582e-02
    z[1,4,1]  R1165     2.7429884672164917e-01
    z[1,4,1]  R1166     8.6199837923049927e-01
    z[1,4,1]  R1167     7.5430279970169067e-01
    z[1,4,1]  R1168     7.6275277137756348e-01
    z[1,4,1]  R1169     7.1205347776412964e-01
    z[1,4,1]  R1170     7.1167606115341187e-01
    z[1,4,1]  R1171     6.6217201948165894e-01
    z[1,4,1]  R1172     1.9006147980690002e-01
    z[1,4,1]  R1173     6.9651387631893158e-02
    z[1,4,1]  R1174     1.0630601644515991e-01
    z[1,4,1]  R1175     -3.3505043387413025e-01
    z[1,4,1]  R1176     -7.2566747665405273e-01
    z[1,4,1]  R1177     -0.601925790309906
    z[1,4,1]  R1178     -4.3660253286361694e-01
    z[1,4,1]  R1179     -0.560893714427948
    z[1,4,1]  R1180     -7.1033054590225220e-01
    z[1,4,1]  R1181     -5.6445884704589844e-01
    z[1,4,1]  R1182     -5.5630582571029663e-01
    z[1,4,1]  R1183     -7.3707896471023560e-01
    z[1,4,1]  R1184     6.5864127874374390e-01
    z[1,4,1]  R1185     -6.6119700670242310e-02
    z[1,4,1]  R1186     8.3957237005233765e-01
    z[1,4,1]  R1187     7.5983101129531860e-01
    z[1,4,1]  R1188     8.9190721511840820e-01
    z[1,4,1]  R1189     0.68828946352005
    z[1,4,1]  R1190     8.4670531749725342e-01
    z[1,4,1]  R1191     8.4243708848953247e-01
    z[1,4,1]  R1192     7.9136216640472412e-01
    z[1,4,1]  R1193     7.4902480840682983e-01
    z[1,4,1]  R1194     8.6116957664489746e-01
    z[1,4,1]  R1195     8.7653368711471558e-01
    z[1,4,1]  R1196     8.3442175388336182e-01
    z[1,4,1]  R1197     8.3425015211105347e-01
    z[1,4,1]  R1198     8.9899486303329468e-01
    z[1,4,1]  R1199     5.9249097108840942e-01
    z[1,4,1]  R1200     5.9265911579132080e-01
    z[1,4,1]  R1201     -6.9072662154212594e-04
    z[1,4,1]  R1202     3.1029152870178223e-01
    z[1,4,1]  R1203     1.9548442959785461e-01
    z[1,4,1]  R1204     5.6558477878570557e-01
    z[1,4,1]  R1205     6.0634356737136841e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1136     -1
    z[1,4,2]  R1137     1
    z[1,4,2]  R1146     -1.9925607740879059e-01
    z[1,4,2]  R1147     -3.2785028219223022e-01
    z[1,4,2]  R1148     -7.2761642932891846e-01
    z[1,4,2]  R1149     7.2494186460971832e-02
    z[1,4,2]  R1150     9.0446047484874725e-02
    z[1,4,2]  R1151     -3.4528259187936783e-02
    z[1,4,2]  R1152     8.5024453699588776e-02
    z[1,4,2]  R1153     2.3083847761154175e-01
    z[1,4,2]  R1154     2.1506215631961823e-01
    z[1,4,2]  R1155     -2.6834979653358459e-01
    z[1,4,2]  R1156     -2.7630642056465149e-02
    z[1,4,2]  R1157     -4.4226527214050293e-01
    z[1,4,2]  R1158     1.0201875865459442e-01
    z[1,4,2]  R1159     -0.326465904712677
    z[1,4,2]  R1160     -6.1449509859085083e-01
    z[1,4,2]  R1161     -3.5805395245552063e-01
    z[1,4,2]  R1162     1.8681395053863525e-01
    z[1,4,2]  R1163     -5.6713706254959106e-01
    z[1,4,2]  R1164     7.0076537132263184e-01
    z[1,4,2]  R1165     -8.1679157912731171e-02
    z[1,4,2]  R1166     7.4630357325077057e-02
    z[1,4,2]  R1167     -3.0827391147613525e-01
    z[1,4,2]  R1168     -1.6502179205417633e-01
    z[1,4,2]  R1169     -5.4879003763198853e-01
    z[1,4,2]  R1170     -4.3301945924758911e-01
    z[1,4,2]  R1171     -5.0865966081619263e-01
    z[1,4,2]  R1172     6.4753150939941406e-01
    z[1,4,2]  R1173     6.5141016244888306e-01
    z[1,4,2]  R1174     9.0096151828765869e-01
    z[1,4,2]  R1175     2.7205786108970642e-01
    z[1,4,2]  R1176     -3.8860204815864563e-01
    z[1,4,2]  R1177     -3.0724689364433289e-01
    z[1,4,2]  R1178     -1.4385642111301422e-01
    z[1,4,2]  R1179     4.1887059807777405e-02
    z[1,4,2]  R1180     -9.1320149600505829e-02
    z[1,4,2]  R1181     -4.9124547839164734e-01
    z[1,4,2]  R1182     1.5303640067577362e-01
    z[1,4,2]  R1183     -1.8345442414283752e-01
    z[1,4,2]  R1184     -2.6607409119606018e-01
    z[1,4,2]  R1185     -1.6967274248600006e-01
    z[1,4,2]  R1186     2.1964015066623688e-01
    z[1,4,2]  R1187     -5.4684713482856750e-02
    z[1,4,2]  R1188     -3.1715580821037292e-01
    z[1,4,2]  R1189     1.5045984089374542e-01
    z[1,4,2]  R1190     -3.3043643832206726e-01
    z[1,4,2]  R1191     5.8519367128610611e-02
    z[1,4,2]  R1192     1.5012061595916748e-01
    z[1,4,2]  R1193     9.6426717936992645e-02
    z[1,4,2]  R1194     -3.5265842080116272e-01
    z[1,4,2]  R1195     2.7463451027870178e-01
    z[1,4,2]  R1196     2.7208182215690613e-01
    z[1,4,2]  R1197     4.5037293434143066e-01
    z[1,4,2]  R1198     -1.3624326884746552e-01
    z[1,4,2]  R1199     4.6888992190361023e-01
    z[1,4,2]  R1200     6.5142136812210083e-01
    z[1,4,2]  R1201     -6.4343822002410889e-01
    z[1,4,2]  R1202     -6.2557244300842285e-01
    z[1,4,2]  R1203     -6.9579696655273438e-01
    z[1,4,2]  R1204     0.331856369972229
    z[1,4,2]  R1205     -2.7549099922180176e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1138     -1
    z[1,4,3]  R1139     1
    z[1,4,3]  R1146     4.1571286320686340e-01
    z[1,4,3]  R1147     5.2801431156694889e-03
    z[1,4,3]  R1148     2.3760001361370087e-01
    z[1,4,3]  R1149     4.4579803943634033e-01
    z[1,4,3]  R1150     4.1010746359825134e-01
    z[1,4,3]  R1151     0.0699441209435463
    z[1,4,3]  R1152     -2.7111726999282837e-01
    z[1,4,3]  R1153     3.5323426127433777e-03
    z[1,4,3]  R1154     -1.5383604168891907e-01
    z[1,4,3]  R1155     -4.1269126534461975e-01
    z[1,4,3]  R1156     -7.1397058665752411e-02
    z[1,4,3]  R1157     1.3254101388156414e-02
    z[1,4,3]  R1158     -0.062924325466156
    z[1,4,3]  R1159     2.9293122887611389e-01
    z[1,4,3]  R1160     6.8340882658958435e-02
    z[1,4,3]  R1161     -1.5282213687896729e-01
    z[1,4,3]  R1162     -7.1344166994094849e-01
    z[1,4,3]  R1163     -4.9946320056915283e-01
    z[1,4,3]  R1164     -5.0770968198776245e-01
    z[1,4,3]  R1165     -5.8048856258392334e-01
    z[1,4,3]  R1166     -2.9847297072410583e-01
    z[1,4,3]  R1167     5.1173716783523560e-01
    z[1,4,3]  R1168     3.4743675589561462e-01
    z[1,4,3]  R1169     -4.6729825437068939e-02
    z[1,4,3]  R1170     -1.2129744887351990e-01
    z[1,4,3]  R1171     1.2098416686058044e-01
    z[1,4,3]  R1172     -6.5261560678482056e-01
    z[1,4,3]  R1173     -3.6690777540206909e-01
    z[1,4,3]  R1174     -1.4384835958480835e-01
    z[1,4,3]  R1175     -3.5192090272903442e-01
    z[1,4,3]  R1176     4.4498276710510254e-01
    z[1,4,3]  R1177     4.5564872026443481e-01
    z[1,4,3]  R1178     8.5733026266098022e-01
    z[1,4,3]  R1179     3.7388020753860474e-01
    z[1,4,3]  R1180     -7.4222773313522339e-02
    z[1,4,3]  R1181     -1.0788592696189880e-01
    z[1,4,3]  R1182     4.6664497256278992e-01
    z[1,4,3]  R1183     -5.1120144128799438e-01
    z[1,4,3]  R1184     -7.2239659726619720e-02
    z[1,4,3]  R1185     -7.7155923843383789e-01
    z[1,4,3]  R1186     -0.384640634059906
    z[1,4,3]  R1187     -4.2843019962310791e-01
    z[1,4,3]  R1188     1.0900925099849701e-01
    z[1,4,3]  R1189     -1.8710485100746155e-01
    z[1,4,3]  R1190     1.6624949872493744e-01
    z[1,4,3]  R1191     2.1511860191822052e-01
    z[1,4,3]  R1192     -4.8466023802757263e-01
    z[1,4,3]  R1193     -3.9303550124168396e-01
    z[1,4,3]  R1194     -1.1065232008695602e-01
    z[1,4,3]  R1195     1.2822882831096649e-01
    z[1,4,3]  R1196     -9.2328958213329315e-02
    z[1,4,3]  R1197     6.3312657177448273e-02
    z[1,4,3]  R1198     -2.7496090531349182e-01
    z[1,4,3]  R1199     -8.1231839954853058e-02
    z[1,4,3]  R1200     -1.8128865957260132e-01
    z[1,4,3]  R1201     -0.535149097442627
    z[1,4,3]  R1202     -6.9514250755310059e-01
    z[1,4,3]  R1203     -3.4890174865722656e-01
    z[1,4,3]  R1204     2.6794403791427612e-01
    z[1,4,3]  R1205     4.0192779898643494e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1140     -1
    z[1,4,4]  R1141     1
    z[1,4,4]  R1146     -1.9522084295749664e-01
    z[1,4,4]  R1147     -5.5625919252634048e-02
    z[1,4,4]  R1148     -1.1468805372714996e-01
    z[1,4,4]  R1149     2.8277322649955750e-01
    z[1,4,4]  R1150     -4.1842761635780334e-01
    z[1,4,4]  R1151     -5.1813744008541107e-02
    z[1,4,4]  R1152     1.5262334048748016e-01
    z[1,4,4]  R1153     -3.9830081164836884e-02
    z[1,4,4]  R1154     -3.4797763824462891e-01
    z[1,4,4]  R1155     -1.8198819458484650e-01
    z[1,4,4]  R1156     5.0782209634780884e-01
    z[1,4,4]  R1157     5.0541943311691284e-01
    z[1,4,4]  R1158     7.0441913604736328e-01
    z[1,4,4]  R1159     1.5030542016029358e-01
    z[1,4,4]  R1160     1.8428441882133484e-01
    z[1,4,4]  R1161     0.532706618309021
    z[1,4,4]  R1162     4.6939682960510254e-01
    z[1,4,4]  R1163     -1.0630524903535843e-01
    z[1,4,4]  R1164     -1.1071750521659851e-01
    z[1,4,4]  R1165     -3.0283406376838684e-03
    z[1,4,4]  R1166     1.0974252223968506e-01
    z[1,4,4]  R1167     -1.2475372105836868e-01
    z[1,4,4]  R1168     2.1234643459320068e-01
    z[1,4,4]  R1169     1.4340290427207947e-01
    z[1,4,4]  R1170     4.1452908515930176e-01
    z[1,4,4]  R1171     -2.9557171463966370e-01
    z[1,4,4]  R1172     1.0928661562502384e-02
    z[1,4,4]  R1173     -3.0401936173439026e-01
    z[1,4,4]  R1174     1.9716110825538635e-01
    z[1,4,4]  R1175     4.9992737174034119e-01
    z[1,4,4]  R1176     -1.1761056631803513e-01
    z[1,4,4]  R1177     -4.3422105908393860e-01
    z[1,4,4]  R1178     3.9987348020076752e-02
    z[1,4,4]  R1179     2.0577311515808105e-01
    z[1,4,4]  R1180     -2.2969231009483337e-01
    z[1,4,4]  R1181     -2.3001711070537567e-01
    z[1,4,4]  R1182     -0.0957801342010498
    z[1,4,4]  R1183     -1.7863722145557404e-01
    z[1,4,4]  R1184     -1.7013189196586609e-01
    z[1,4,4]  R1185     -3.6363226175308228e-01
    z[1,4,4]  R1186     1.7837880551815033e-01
    z[1,4,4]  R1187     -3.1958669424057007e-03
    z[1,4,4]  R1188     2.6500046253204346e-01
    z[1,4,4]  R1189     -1.3820233941078186e-01
    z[1,4,4]  R1190     3.3487355709075928e-01
    z[1,4,4]  R1191     3.1450507044792175e-01
    z[1,4,4]  R1192     3.0866429209709167e-01
    z[1,4,4]  R1193     2.1685311198234558e-01
    z[1,4,4]  R1194     1.8871790170669556e-01
    z[1,4,4]  R1195     3.6806982755661011e-01
    z[1,4,4]  R1196     1.0369108617305756e-01
    z[1,4,4]  R1197     2.3422354459762573e-01
    z[1,4,4]  R1198     8.7004482746124268e-02
    z[1,4,4]  R1199     -1.0074214637279510e-01
    z[1,4,4]  R1200     -9.0319961309432983e-02
    z[1,4,4]  R1201     2.9192152619361877e-01
    z[1,4,4]  R1202     1.2943156063556671e-01
    z[1,4,4]  R1203     1.4085660874843597e-01
    z[1,4,4]  R1204     -3.4676857292652130e-02
    z[1,4,4]  R1205     -8.8697835803031921e-02
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1142     -1
    z[1,4,5]  R1143     1
    z[1,4,5]  R1146     4.5144062489271164e-02
    z[1,4,5]  R1147     5.1510158926248550e-02
    z[1,4,5]  R1148     -3.9596560597419739e-01
    z[1,4,5]  R1149     -3.4057098627090454e-01
    z[1,4,5]  R1150     -6.3107395172119141e-01
    z[1,4,5]  R1151     -1.0247718542814255e-01
    z[1,4,5]  R1152     -3.4925499558448792e-01
    z[1,4,5]  R1153     4.0217429399490356e-01
    z[1,4,5]  R1154     -1.4051049947738647e-01
    z[1,4,5]  R1155     -2.4994817376136780e-01
    z[1,4,5]  R1156     -4.4802263379096985e-01
    z[1,4,5]  R1157     -2.0324413478374481e-01
    z[1,4,5]  R1158     -1.0597249493002892e-02
    z[1,4,5]  R1159     -3.6264079809188843e-01
    z[1,4,5]  R1160     4.3007194995880127e-01
    z[1,4,5]  R1161     3.4774327278137207e-01
    z[1,4,5]  R1162     5.7146232575178146e-02
    z[1,4,5]  R1163     5.0299829244613647e-01
    z[1,4,5]  R1164     3.9705076813697815e-01
    z[1,4,5]  R1165     -4.2692460119724274e-02
    z[1,4,5]  R1166     -5.0250776112079620e-02
    z[1,4,5]  R1167     1.9489030539989471e-01
    z[1,4,5]  R1168     4.0899339318275452e-01
    z[1,4,5]  R1169     1.7612640559673309e-01
    z[1,4,5]  R1170     2.3359447717666626e-01
    z[1,4,5]  R1171     4.1298249363899231e-01
    z[1,4,5]  R1172     2.2846752777695656e-02
    z[1,4,5]  R1173     2.2896414995193481e-01
    z[1,4,5]  R1174     0.241278275847435
    z[1,4,5]  R1175     2.1940311789512634e-01
    z[1,4,5]  R1176     5.6471548974514008e-02
    z[1,4,5]  R1177     -0.00575606245547533
    z[1,4,5]  R1178     1.4192521572113037e-01
    z[1,4,5]  R1179     -1.6009394824504852e-01
    z[1,4,5]  R1180     -2.8100606799125671e-01
    z[1,4,5]  R1181     9.9084721878170967e-03
    z[1,4,5]  R1182     -3.1752511858940125e-01
    z[1,4,5]  R1183     -2.3209697008132935e-01
    z[1,4,5]  R1184     -1.2765762209892273e-01
    z[1,4,5]  R1185     1.9370566308498383e-01
    z[1,4,5]  R1186     -1.9008180499076843e-01
    z[1,4,5]  R1187     1.2980645895004272e-01
    z[1,4,5]  R1188     -7.0155955851078033e-02
    z[1,4,5]  R1189     1.7229683697223663e-01
    z[1,4,5]  R1190     1.2577322125434875e-01
    z[1,4,5]  R1191     3.3563748002052307e-01
    z[1,4,5]  R1192     4.6237561851739883e-02
    z[1,4,5]  R1193     1.3555921614170074e-01
    z[1,4,5]  R1194     -2.0125040411949158e-01
    z[1,4,5]  R1195     4.8644743859767914e-02
    z[1,4,5]  R1196     -7.7171243727207184e-02
    z[1,4,5]  R1197     -4.4923387467861176e-03
    z[1,4,5]  R1198     6.1700176447629929e-02
    z[1,4,5]  R1199     -3.7547716498374939e-01
    z[1,4,5]  R1200     -0.0452738031744957
    z[1,4,5]  R1201     1.7261669039726257e-01
    z[1,4,5]  R1202     6.5440088510513306e-03
    z[1,4,5]  R1203     2.7864855527877808e-01
    z[1,4,5]  R1204     0.523865282535553
    z[1,4,5]  R1205     8.0336958169937134e-02
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1144     -1
    z[1,4,6]  R1145     1
    z[1,4,6]  R1146     4.4508108496665955e-01
    z[1,4,6]  R1147     -4.6299800276756287e-01
    z[1,4,6]  R1148     -1.1209972202777863e-01
    z[1,4,6]  R1149     -3.7462544441223145e-01
    z[1,4,6]  R1150     -2.7219581604003906e-01
    z[1,4,6]  R1151     5.1093274354934692e-01
    z[1,4,6]  R1152     2.6656261086463928e-01
    z[1,4,6]  R1153     -1.5174549818038940e-01
    z[1,4,6]  R1154     -3.5464456677436829e-01
    z[1,4,6]  R1155     -5.2352637052536011e-01
    z[1,4,6]  R1156     -1.9029730930924416e-02
    z[1,4,6]  R1157     1.1859763413667679e-02
    z[1,4,6]  R1158     1.6963452100753784e-01
    z[1,4,6]  R1159     -4.3357063084840775e-02
    z[1,4,6]  R1160     1.4768348634243011e-01
    z[1,4,6]  R1161     3.8006898760795593e-01
    z[1,4,6]  R1162     -0.208759143948555
    z[1,4,6]  R1163     1.0208845883607864e-01
    z[1,4,6]  R1164     1.4676529169082642e-01
    z[1,4,6]  R1165     4.4861856102943420e-01
    z[1,4,6]  R1166     -3.4222227334976196e-01
    z[1,4,6]  R1167     1.1750672757625580e-01
    z[1,4,6]  R1168     1.0847406834363937e-01
    z[1,4,6]  R1169     -3.1713131070137024e-01
    z[1,4,6]  R1170     2.5246149301528931e-01
    z[1,4,6]  R1171     -1.7355036735534668e-01
    z[1,4,6]  R1172     -1.5159356594085693e-01
    z[1,4,6]  R1173     3.0916744470596313e-01
    z[1,4,6]  R1174     2.3593175411224365e-01
    z[1,4,6]  R1175     -1.3633179664611816e-01
    z[1,4,6]  R1176     3.1652396917343140e-01
    z[1,4,6]  R1177     -6.5598316490650177e-02
    z[1,4,6]  R1178     -1.4475968480110168e-01
    z[1,4,6]  R1179     5.3866535425186157e-01
    z[1,4,6]  R1180     5.9146124124526978e-01
    z[1,4,6]  R1181     -0.60360187292099
    z[1,4,6]  R1182     -5.6626528501510620e-01
    z[1,4,6]  R1183     0.00824635848402977
    z[1,4,6]  R1184     3.1562498211860657e-01
    z[1,4,6]  R1185     1.6719865798950195e-01
    z[1,4,6]  R1186     1.7597745358943939e-01
    z[1,4,6]  R1187     3.1092354655265808e-01
    z[1,4,6]  R1188     7.7080823481082916e-02
    z[1,4,6]  R1189     -4.4619336724281311e-01
    z[1,4,6]  R1190     -1.3356833159923553e-01
    z[1,4,6]  R1191     -1.6347070038318634e-01
    z[1,4,6]  R1192     -4.5246567577123642e-02
    z[1,4,6]  R1193     -4.5476046204566956e-01
    z[1,4,6]  R1194     -1.8977752327919006e-01
    z[1,4,6]  R1195     4.3836481869220734e-02
    z[1,4,6]  R1196     -3.9253199100494385e-01
    z[1,4,6]  R1197     -1.6546231508255005e-01
    z[1,4,6]  R1198     -1.3584578037261963e-01
    z[1,4,6]  R1199     2.3039807379245758e-01
    z[1,4,6]  R1200     -4.0946129709482193e-02
    z[1,4,6]  R1201     1.3760775327682495e-01
    z[1,4,6]  R1202     -6.8311393260955811e-03
    z[1,4,6]  R1203     -4.3948139995336533e-02
    z[1,4,6]  R1204     6.0904525220394135e-02
    z[1,4,6]  R1205     -3.9998155832290649e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1206     -1
    z[4,1,0]  R1207     1
    z[4,1,0]  R1220     -8.4715768694877625e-02
    z[4,1,0]  R1221     3.7786862254142761e-01
    z[4,1,0]  R1222     -1.0474388301372528e-01
    z[4,1,0]  R1223     -4.3095737695693970e-01
    z[4,1,0]  R1224     -5.7242126204073429e-03
    z[4,1,0]  R1225     -1.0527808219194412e-01
    z[4,1,0]  R1226     -1.3672526180744171e-01
    z[4,1,0]  R1227     -2.7547001838684082e-01
    z[4,1,0]  R1228     5.8763694763183594e-01
    z[4,1,0]  R1229     4.1692918539047241e-01
    z[4,1,0]  R1230     3.1882929615676403e-03
    z[4,1,0]  R1231     0.350115031003952
    z[4,1,0]  R1232     1.0460475832223892e-01
    z[4,1,0]  R1233     4.6982610225677490e-01
    z[4,1,0]  R1234     -2.1524028852581978e-02
    z[4,1,0]  R1235     4.8068743199110031e-02
    z[4,1,0]  R1236     -1.2982851266860962e-01
    z[4,1,0]  R1237     -5.4572790861129761e-02
    z[4,1,0]  R1238     9.8200999200344086e-02
    z[4,1,0]  R1239     -7.6632252894341946e-03
    z[4,1,0]  R1240     2.2449608147144318e-01
    z[4,1,0]  R1241     1.2216307967901230e-01
    z[4,1,0]  R1242     2.6040667295455933e-01
    z[4,1,0]  R1243     4.6720737218856812e-01
    z[4,1,0]  R1244     4.2385819554328918e-01
    z[4,1,0]  R1245     4.0700322389602661e-01
    z[4,1,0]  R1246     1.1096493899822235e-01
    z[4,1,0]  R1247     5.0646132230758667e-01
    z[4,1,0]  R1248     0.467808336019516
    z[4,1,0]  R1249     4.6968027949333191e-01
    z[4,1,0]  R1250     -4.9690928310155869e-02
    z[4,1,0]  R1251     -5.8148401975631714e-01
    z[4,1,0]  R1252     -1.1177226155996323e-01
    z[4,1,0]  R1253     -6.1769241094589233e-01
    z[4,1,0]  R1254     1.4331138134002686e-01
    z[4,1,0]  R1255     6.5243035554885864e-01
    z[4,1,0]  R1256     6.3770312070846558e-01
    z[4,1,0]  R1257     2.9630595818161964e-02
    z[4,1,0]  R1258     4.4086730480194092e-01
    z[4,1,0]  R1259     2.9334232211112976e-01
    z[4,1,0]  R1260     1.6809152066707611e-01
    z[4,1,0]  R1261     -0.023863660171628
    z[4,1,0]  R1262     -1.1202633380889893e-01
    z[4,1,0]  R1263     1.9880126416683197e-01
    z[4,1,0]  R1264     -1.3381104171276093e-01
    z[4,1,0]  R1265     -7.3125801980495453e-02
    z[4,1,0]  R1266     -1.5840733423829079e-02
    z[4,1,0]  R1267     1.9686248898506165e-01
    z[4,1,0]  R1268     2.2745615243911743e-01
    z[4,1,0]  R1269     -6.1484247446060181e-01
    z[4,1,0]  R1270     1.7498087882995605e-01
    z[4,1,0]  R1271     8.2255318760871887e-02
    z[4,1,0]  R1272     -2.1478015184402466e-01
    z[4,1,0]  R1273     -1.9356778264045715e-01
    z[4,1,0]  R1274     3.4069761633872986e-02
    z[4,1,0]  R1275     1.0933275334537029e-02
    z[4,1,0]  R1276     3.0830252170562744e-01
    z[4,1,0]  R1277     4.4244241714477539e-01
    z[4,1,0]  R1278     5.9359449893236160e-02
    z[4,1,0]  R1279     6.1092221736907959e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1208     -1
    z[4,1,1]  R1209     1
    z[4,1,1]  R1220     -7.2566747665405273e-01
    z[4,1,1]  R1221     -0.601925790309906
    z[4,1,1]  R1222     -4.3660253286361694e-01
    z[4,1,1]  R1223     -0.560893714427948
    z[4,1,1]  R1224     -7.1033054590225220e-01
    z[4,1,1]  R1225     -5.6445884704589844e-01
    z[4,1,1]  R1226     -5.5630582571029663e-01
    z[4,1,1]  R1227     -7.3707896471023560e-01
    z[4,1,1]  R1228     6.5864127874374390e-01
    z[4,1,1]  R1229     -6.6119700670242310e-02
    z[4,1,1]  R1230     8.3957237005233765e-01
    z[4,1,1]  R1231     7.5983101129531860e-01
    z[4,1,1]  R1232     8.9190721511840820e-01
    z[4,1,1]  R1233     0.68828946352005
    z[4,1,1]  R1234     8.4670531749725342e-01
    z[4,1,1]  R1235     8.4243708848953247e-01
    z[4,1,1]  R1236     7.9136216640472412e-01
    z[4,1,1]  R1237     7.4902480840682983e-01
    z[4,1,1]  R1238     8.6116957664489746e-01
    z[4,1,1]  R1239     8.7653368711471558e-01
    z[4,1,1]  R1240     8.3442175388336182e-01
    z[4,1,1]  R1241     8.3425015211105347e-01
    z[4,1,1]  R1242     8.9899486303329468e-01
    z[4,1,1]  R1243     5.9249097108840942e-01
    z[4,1,1]  R1244     5.9265911579132080e-01
    z[4,1,1]  R1245     -6.9072662154212594e-04
    z[4,1,1]  R1246     3.1029152870178223e-01
    z[4,1,1]  R1247     1.9548442959785461e-01
    z[4,1,1]  R1248     5.6558477878570557e-01
    z[4,1,1]  R1249     6.0634356737136841e-01
    z[4,1,1]  R1250     -7.3943519592285156e-01
    z[4,1,1]  R1251     -5.7814192771911621e-01
    z[4,1,1]  R1252     -4.6810141205787659e-01
    z[4,1,1]  R1253     -2.7959123253822327e-01
    z[4,1,1]  R1254     -3.9454612135887146e-01
    z[4,1,1]  R1255     5.4222857952117920e-01
    z[4,1,1]  R1256     5.4430902004241943e-01
    z[4,1,1]  R1257     8.7147343158721924e-01
    z[4,1,1]  R1258     6.8491917848587036e-01
    z[4,1,1]  R1259     5.4950064420700073e-01
    z[4,1,1]  R1260     0.711979329586029
    z[4,1,1]  R1261     7.1186983585357666e-01
    z[4,1,1]  R1262     6.6931933164596558e-01
    z[4,1,1]  R1263     7.8237426280975342e-01
    z[4,1,1]  R1264     5.9923851490020752e-01
    z[4,1,1]  R1265     5.4216337203979492e-01
    z[4,1,1]  R1266     4.3436288833618164e-01
    z[4,1,1]  R1267     3.3971610665321350e-01
    z[4,1,1]  R1268     -8.9301742613315582e-02
    z[4,1,1]  R1269     2.7429884672164917e-01
    z[4,1,1]  R1270     8.6199837923049927e-01
    z[4,1,1]  R1271     7.5430279970169067e-01
    z[4,1,1]  R1272     7.6275277137756348e-01
    z[4,1,1]  R1273     7.1205347776412964e-01
    z[4,1,1]  R1274     7.1167606115341187e-01
    z[4,1,1]  R1275     6.6217201948165894e-01
    z[4,1,1]  R1276     1.9006147980690002e-01
    z[4,1,1]  R1277     6.9651387631893158e-02
    z[4,1,1]  R1278     1.0630601644515991e-01
    z[4,1,1]  R1279     -3.3505043387413025e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1210     -1
    z[4,1,2]  R1211     1
    z[4,1,2]  R1220     -3.8860204815864563e-01
    z[4,1,2]  R1221     -3.0724689364433289e-01
    z[4,1,2]  R1222     -1.4385642111301422e-01
    z[4,1,2]  R1223     4.1887059807777405e-02
    z[4,1,2]  R1224     -9.1320149600505829e-02
    z[4,1,2]  R1225     -4.9124547839164734e-01
    z[4,1,2]  R1226     1.5303640067577362e-01
    z[4,1,2]  R1227     -1.8345442414283752e-01
    z[4,1,2]  R1228     -2.6607409119606018e-01
    z[4,1,2]  R1229     -1.6967274248600006e-01
    z[4,1,2]  R1230     2.1964015066623688e-01
    z[4,1,2]  R1231     -5.4684713482856750e-02
    z[4,1,2]  R1232     -3.1715580821037292e-01
    z[4,1,2]  R1233     1.5045984089374542e-01
    z[4,1,2]  R1234     -3.3043643832206726e-01
    z[4,1,2]  R1235     5.8519367128610611e-02
    z[4,1,2]  R1236     1.5012061595916748e-01
    z[4,1,2]  R1237     9.6426717936992645e-02
    z[4,1,2]  R1238     -3.5265842080116272e-01
    z[4,1,2]  R1239     2.7463451027870178e-01
    z[4,1,2]  R1240     2.7208182215690613e-01
    z[4,1,2]  R1241     4.5037293434143066e-01
    z[4,1,2]  R1242     -1.3624326884746552e-01
    z[4,1,2]  R1243     4.6888992190361023e-01
    z[4,1,2]  R1244     6.5142136812210083e-01
    z[4,1,2]  R1245     -6.4343822002410889e-01
    z[4,1,2]  R1246     -6.2557244300842285e-01
    z[4,1,2]  R1247     -6.9579696655273438e-01
    z[4,1,2]  R1248     0.331856369972229
    z[4,1,2]  R1249     -2.7549099922180176e-01
    z[4,1,2]  R1250     -1.9925607740879059e-01
    z[4,1,2]  R1251     -3.2785028219223022e-01
    z[4,1,2]  R1252     -7.2761642932891846e-01
    z[4,1,2]  R1253     7.2494186460971832e-02
    z[4,1,2]  R1254     9.0446047484874725e-02
    z[4,1,2]  R1255     -3.4528259187936783e-02
    z[4,1,2]  R1256     8.5024453699588776e-02
    z[4,1,2]  R1257     2.3083847761154175e-01
    z[4,1,2]  R1258     2.1506215631961823e-01
    z[4,1,2]  R1259     -2.6834979653358459e-01
    z[4,1,2]  R1260     -2.7630642056465149e-02
    z[4,1,2]  R1261     -4.4226527214050293e-01
    z[4,1,2]  R1262     1.0201875865459442e-01
    z[4,1,2]  R1263     -0.326465904712677
    z[4,1,2]  R1264     -6.1449509859085083e-01
    z[4,1,2]  R1265     -3.5805395245552063e-01
    z[4,1,2]  R1266     1.8681395053863525e-01
    z[4,1,2]  R1267     -5.6713706254959106e-01
    z[4,1,2]  R1268     7.0076537132263184e-01
    z[4,1,2]  R1269     -8.1679157912731171e-02
    z[4,1,2]  R1270     7.4630357325077057e-02
    z[4,1,2]  R1271     -3.0827391147613525e-01
    z[4,1,2]  R1272     -1.6502179205417633e-01
    z[4,1,2]  R1273     -5.4879003763198853e-01
    z[4,1,2]  R1274     -4.3301945924758911e-01
    z[4,1,2]  R1275     -5.0865966081619263e-01
    z[4,1,2]  R1276     6.4753150939941406e-01
    z[4,1,2]  R1277     6.5141016244888306e-01
    z[4,1,2]  R1278     9.0096151828765869e-01
    z[4,1,2]  R1279     2.7205786108970642e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1212     -1
    z[4,1,3]  R1213     1
    z[4,1,3]  R1220     4.4498276710510254e-01
    z[4,1,3]  R1221     4.5564872026443481e-01
    z[4,1,3]  R1222     8.5733026266098022e-01
    z[4,1,3]  R1223     3.7388020753860474e-01
    z[4,1,3]  R1224     -7.4222773313522339e-02
    z[4,1,3]  R1225     -1.0788592696189880e-01
    z[4,1,3]  R1226     4.6664497256278992e-01
    z[4,1,3]  R1227     -5.1120144128799438e-01
    z[4,1,3]  R1228     -7.2239659726619720e-02
    z[4,1,3]  R1229     -7.7155923843383789e-01
    z[4,1,3]  R1230     -0.384640634059906
    z[4,1,3]  R1231     -4.2843019962310791e-01
    z[4,1,3]  R1232     1.0900925099849701e-01
    z[4,1,3]  R1233     -1.8710485100746155e-01
    z[4,1,3]  R1234     1.6624949872493744e-01
    z[4,1,3]  R1235     2.1511860191822052e-01
    z[4,1,3]  R1236     -4.8466023802757263e-01
    z[4,1,3]  R1237     -3.9303550124168396e-01
    z[4,1,3]  R1238     -1.1065232008695602e-01
    z[4,1,3]  R1239     1.2822882831096649e-01
    z[4,1,3]  R1240     -9.2328958213329315e-02
    z[4,1,3]  R1241     6.3312657177448273e-02
    z[4,1,3]  R1242     -2.7496090531349182e-01
    z[4,1,3]  R1243     -8.1231839954853058e-02
    z[4,1,3]  R1244     -1.8128865957260132e-01
    z[4,1,3]  R1245     -0.535149097442627
    z[4,1,3]  R1246     -6.9514250755310059e-01
    z[4,1,3]  R1247     -3.4890174865722656e-01
    z[4,1,3]  R1248     2.6794403791427612e-01
    z[4,1,3]  R1249     4.0192779898643494e-01
    z[4,1,3]  R1250     4.1571286320686340e-01
    z[4,1,3]  R1251     5.2801431156694889e-03
    z[4,1,3]  R1252     2.3760001361370087e-01
    z[4,1,3]  R1253     4.4579803943634033e-01
    z[4,1,3]  R1254     4.1010746359825134e-01
    z[4,1,3]  R1255     0.0699441209435463
    z[4,1,3]  R1256     -2.7111726999282837e-01
    z[4,1,3]  R1257     3.5323426127433777e-03
    z[4,1,3]  R1258     -1.5383604168891907e-01
    z[4,1,3]  R1259     -4.1269126534461975e-01
    z[4,1,3]  R1260     -7.1397058665752411e-02
    z[4,1,3]  R1261     1.3254101388156414e-02
    z[4,1,3]  R1262     -0.062924325466156
    z[4,1,3]  R1263     2.9293122887611389e-01
    z[4,1,3]  R1264     6.8340882658958435e-02
    z[4,1,3]  R1265     -1.5282213687896729e-01
    z[4,1,3]  R1266     -7.1344166994094849e-01
    z[4,1,3]  R1267     -4.9946320056915283e-01
    z[4,1,3]  R1268     -5.0770968198776245e-01
    z[4,1,3]  R1269     -5.8048856258392334e-01
    z[4,1,3]  R1270     -2.9847297072410583e-01
    z[4,1,3]  R1271     5.1173716783523560e-01
    z[4,1,3]  R1272     3.4743675589561462e-01
    z[4,1,3]  R1273     -4.6729825437068939e-02
    z[4,1,3]  R1274     -1.2129744887351990e-01
    z[4,1,3]  R1275     1.2098416686058044e-01
    z[4,1,3]  R1276     -6.5261560678482056e-01
    z[4,1,3]  R1277     -3.6690777540206909e-01
    z[4,1,3]  R1278     -1.4384835958480835e-01
    z[4,1,3]  R1279     -3.5192090272903442e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1214     -1
    z[4,1,4]  R1215     1
    z[4,1,4]  R1220     -1.1761056631803513e-01
    z[4,1,4]  R1221     -4.3422105908393860e-01
    z[4,1,4]  R1222     3.9987348020076752e-02
    z[4,1,4]  R1223     2.0577311515808105e-01
    z[4,1,4]  R1224     -2.2969231009483337e-01
    z[4,1,4]  R1225     -2.3001711070537567e-01
    z[4,1,4]  R1226     -0.0957801342010498
    z[4,1,4]  R1227     -1.7863722145557404e-01
    z[4,1,4]  R1228     -1.7013189196586609e-01
    z[4,1,4]  R1229     -3.6363226175308228e-01
    z[4,1,4]  R1230     1.7837880551815033e-01
    z[4,1,4]  R1231     -3.1958669424057007e-03
    z[4,1,4]  R1232     2.6500046253204346e-01
    z[4,1,4]  R1233     -1.3820233941078186e-01
    z[4,1,4]  R1234     3.3487355709075928e-01
    z[4,1,4]  R1235     3.1450507044792175e-01
    z[4,1,4]  R1236     3.0866429209709167e-01
    z[4,1,4]  R1237     2.1685311198234558e-01
    z[4,1,4]  R1238     1.8871790170669556e-01
    z[4,1,4]  R1239     3.6806982755661011e-01
    z[4,1,4]  R1240     1.0369108617305756e-01
    z[4,1,4]  R1241     2.3422354459762573e-01
    z[4,1,4]  R1242     8.7004482746124268e-02
    z[4,1,4]  R1243     -1.0074214637279510e-01
    z[4,1,4]  R1244     -9.0319961309432983e-02
    z[4,1,4]  R1245     2.9192152619361877e-01
    z[4,1,4]  R1246     1.2943156063556671e-01
    z[4,1,4]  R1247     1.4085660874843597e-01
    z[4,1,4]  R1248     -3.4676857292652130e-02
    z[4,1,4]  R1249     -8.8697835803031921e-02
    z[4,1,4]  R1250     -1.9522084295749664e-01
    z[4,1,4]  R1251     -5.5625919252634048e-02
    z[4,1,4]  R1252     -1.1468805372714996e-01
    z[4,1,4]  R1253     2.8277322649955750e-01
    z[4,1,4]  R1254     -4.1842761635780334e-01
    z[4,1,4]  R1255     -5.1813744008541107e-02
    z[4,1,4]  R1256     1.5262334048748016e-01
    z[4,1,4]  R1257     -3.9830081164836884e-02
    z[4,1,4]  R1258     -3.4797763824462891e-01
    z[4,1,4]  R1259     -1.8198819458484650e-01
    z[4,1,4]  R1260     5.0782209634780884e-01
    z[4,1,4]  R1261     5.0541943311691284e-01
    z[4,1,4]  R1262     7.0441913604736328e-01
    z[4,1,4]  R1263     1.5030542016029358e-01
    z[4,1,4]  R1264     1.8428441882133484e-01
    z[4,1,4]  R1265     0.532706618309021
    z[4,1,4]  R1266     4.6939682960510254e-01
    z[4,1,4]  R1267     -1.0630524903535843e-01
    z[4,1,4]  R1268     -1.1071750521659851e-01
    z[4,1,4]  R1269     -3.0283406376838684e-03
    z[4,1,4]  R1270     1.0974252223968506e-01
    z[4,1,4]  R1271     -1.2475372105836868e-01
    z[4,1,4]  R1272     2.1234643459320068e-01
    z[4,1,4]  R1273     1.4340290427207947e-01
    z[4,1,4]  R1274     4.1452908515930176e-01
    z[4,1,4]  R1275     -2.9557171463966370e-01
    z[4,1,4]  R1276     1.0928661562502384e-02
    z[4,1,4]  R1277     -3.0401936173439026e-01
    z[4,1,4]  R1278     1.9716110825538635e-01
    z[4,1,4]  R1279     4.9992737174034119e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1216     -1
    z[4,1,5]  R1217     1
    z[4,1,5]  R1220     5.6471548974514008e-02
    z[4,1,5]  R1221     -0.00575606245547533
    z[4,1,5]  R1222     1.4192521572113037e-01
    z[4,1,5]  R1223     -1.6009394824504852e-01
    z[4,1,5]  R1224     -2.8100606799125671e-01
    z[4,1,5]  R1225     9.9084721878170967e-03
    z[4,1,5]  R1226     -3.1752511858940125e-01
    z[4,1,5]  R1227     -2.3209697008132935e-01
    z[4,1,5]  R1228     -1.2765762209892273e-01
    z[4,1,5]  R1229     1.9370566308498383e-01
    z[4,1,5]  R1230     -1.9008180499076843e-01
    z[4,1,5]  R1231     1.2980645895004272e-01
    z[4,1,5]  R1232     -7.0155955851078033e-02
    z[4,1,5]  R1233     1.7229683697223663e-01
    z[4,1,5]  R1234     1.2577322125434875e-01
    z[4,1,5]  R1235     3.3563748002052307e-01
    z[4,1,5]  R1236     4.6237561851739883e-02
    z[4,1,5]  R1237     1.3555921614170074e-01
    z[4,1,5]  R1238     -2.0125040411949158e-01
    z[4,1,5]  R1239     4.8644743859767914e-02
    z[4,1,5]  R1240     -7.7171243727207184e-02
    z[4,1,5]  R1241     -4.4923387467861176e-03
    z[4,1,5]  R1242     6.1700176447629929e-02
    z[4,1,5]  R1243     -3.7547716498374939e-01
    z[4,1,5]  R1244     -0.0452738031744957
    z[4,1,5]  R1245     1.7261669039726257e-01
    z[4,1,5]  R1246     6.5440088510513306e-03
    z[4,1,5]  R1247     2.7864855527877808e-01
    z[4,1,5]  R1248     0.523865282535553
    z[4,1,5]  R1249     8.0336958169937134e-02
    z[4,1,5]  R1250     4.5144062489271164e-02
    z[4,1,5]  R1251     5.1510158926248550e-02
    z[4,1,5]  R1252     -3.9596560597419739e-01
    z[4,1,5]  R1253     -3.4057098627090454e-01
    z[4,1,5]  R1254     -6.3107395172119141e-01
    z[4,1,5]  R1255     -1.0247718542814255e-01
    z[4,1,5]  R1256     -3.4925499558448792e-01
    z[4,1,5]  R1257     4.0217429399490356e-01
    z[4,1,5]  R1258     -1.4051049947738647e-01
    z[4,1,5]  R1259     -2.4994817376136780e-01
    z[4,1,5]  R1260     -4.4802263379096985e-01
    z[4,1,5]  R1261     -2.0324413478374481e-01
    z[4,1,5]  R1262     -1.0597249493002892e-02
    z[4,1,5]  R1263     -3.6264079809188843e-01
    z[4,1,5]  R1264     4.3007194995880127e-01
    z[4,1,5]  R1265     3.4774327278137207e-01
    z[4,1,5]  R1266     5.7146232575178146e-02
    z[4,1,5]  R1267     5.0299829244613647e-01
    z[4,1,5]  R1268     3.9705076813697815e-01
    z[4,1,5]  R1269     -4.2692460119724274e-02
    z[4,1,5]  R1270     -5.0250776112079620e-02
    z[4,1,5]  R1271     1.9489030539989471e-01
    z[4,1,5]  R1272     4.0899339318275452e-01
    z[4,1,5]  R1273     1.7612640559673309e-01
    z[4,1,5]  R1274     2.3359447717666626e-01
    z[4,1,5]  R1275     4.1298249363899231e-01
    z[4,1,5]  R1276     2.2846752777695656e-02
    z[4,1,5]  R1277     2.2896414995193481e-01
    z[4,1,5]  R1278     0.241278275847435
    z[4,1,5]  R1279     2.1940311789512634e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1218     -1
    z[4,1,6]  R1219     1
    z[4,1,6]  R1220     3.1652396917343140e-01
    z[4,1,6]  R1221     -6.5598316490650177e-02
    z[4,1,6]  R1222     -1.4475968480110168e-01
    z[4,1,6]  R1223     5.3866535425186157e-01
    z[4,1,6]  R1224     5.9146124124526978e-01
    z[4,1,6]  R1225     -0.60360187292099
    z[4,1,6]  R1226     -5.6626528501510620e-01
    z[4,1,6]  R1227     0.00824635848402977
    z[4,1,6]  R1228     3.1562498211860657e-01
    z[4,1,6]  R1229     1.6719865798950195e-01
    z[4,1,6]  R1230     1.7597745358943939e-01
    z[4,1,6]  R1231     3.1092354655265808e-01
    z[4,1,6]  R1232     7.7080823481082916e-02
    z[4,1,6]  R1233     -4.4619336724281311e-01
    z[4,1,6]  R1234     -1.3356833159923553e-01
    z[4,1,6]  R1235     -1.6347070038318634e-01
    z[4,1,6]  R1236     -4.5246567577123642e-02
    z[4,1,6]  R1237     -4.5476046204566956e-01
    z[4,1,6]  R1238     -1.8977752327919006e-01
    z[4,1,6]  R1239     4.3836481869220734e-02
    z[4,1,6]  R1240     -3.9253199100494385e-01
    z[4,1,6]  R1241     -1.6546231508255005e-01
    z[4,1,6]  R1242     -1.3584578037261963e-01
    z[4,1,6]  R1243     2.3039807379245758e-01
    z[4,1,6]  R1244     -4.0946129709482193e-02
    z[4,1,6]  R1245     1.3760775327682495e-01
    z[4,1,6]  R1246     -6.8311393260955811e-03
    z[4,1,6]  R1247     -4.3948139995336533e-02
    z[4,1,6]  R1248     6.0904525220394135e-02
    z[4,1,6]  R1249     -3.9998155832290649e-01
    z[4,1,6]  R1250     4.4508108496665955e-01
    z[4,1,6]  R1251     -4.6299800276756287e-01
    z[4,1,6]  R1252     -1.1209972202777863e-01
    z[4,1,6]  R1253     -3.7462544441223145e-01
    z[4,1,6]  R1254     -2.7219581604003906e-01
    z[4,1,6]  R1255     5.1093274354934692e-01
    z[4,1,6]  R1256     2.6656261086463928e-01
    z[4,1,6]  R1257     -1.5174549818038940e-01
    z[4,1,6]  R1258     -3.5464456677436829e-01
    z[4,1,6]  R1259     -5.2352637052536011e-01
    z[4,1,6]  R1260     -1.9029730930924416e-02
    z[4,1,6]  R1261     1.1859763413667679e-02
    z[4,1,6]  R1262     1.6963452100753784e-01
    z[4,1,6]  R1263     -4.3357063084840775e-02
    z[4,1,6]  R1264     1.4768348634243011e-01
    z[4,1,6]  R1265     3.8006898760795593e-01
    z[4,1,6]  R1266     -0.208759143948555
    z[4,1,6]  R1267     1.0208845883607864e-01
    z[4,1,6]  R1268     1.4676529169082642e-01
    z[4,1,6]  R1269     4.4861856102943420e-01
    z[4,1,6]  R1270     -3.4222227334976196e-01
    z[4,1,6]  R1271     1.1750672757625580e-01
    z[4,1,6]  R1272     1.0847406834363937e-01
    z[4,1,6]  R1273     -3.1713131070137024e-01
    z[4,1,6]  R1274     2.5246149301528931e-01
    z[4,1,6]  R1275     -1.7355036735534668e-01
    z[4,1,6]  R1276     -1.5159356594085693e-01
    z[4,1,6]  R1277     3.0916744470596313e-01
    z[4,1,6]  R1278     2.3593175411224365e-01
    z[4,1,6]  R1279     -1.3633179664611816e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1280     -1
    z[1,5,0]  R1281     1
    z[1,5,0]  R1294     -4.9690928310155869e-02
    z[1,5,0]  R1295     -5.8148401975631714e-01
    z[1,5,0]  R1296     -1.1177226155996323e-01
    z[1,5,0]  R1297     -6.1769241094589233e-01
    z[1,5,0]  R1298     1.4331138134002686e-01
    z[1,5,0]  R1299     6.5243035554885864e-01
    z[1,5,0]  R1300     6.3770312070846558e-01
    z[1,5,0]  R1301     2.9630595818161964e-02
    z[1,5,0]  R1302     4.4086730480194092e-01
    z[1,5,0]  R1303     2.9334232211112976e-01
    z[1,5,0]  R1304     1.6809152066707611e-01
    z[1,5,0]  R1305     -0.023863660171628
    z[1,5,0]  R1306     -1.1202633380889893e-01
    z[1,5,0]  R1307     1.9880126416683197e-01
    z[1,5,0]  R1308     -1.3381104171276093e-01
    z[1,5,0]  R1309     -7.3125801980495453e-02
    z[1,5,0]  R1310     -1.5840733423829079e-02
    z[1,5,0]  R1311     1.9686248898506165e-01
    z[1,5,0]  R1312     2.2745615243911743e-01
    z[1,5,0]  R1313     -6.1484247446060181e-01
    z[1,5,0]  R1314     1.7498087882995605e-01
    z[1,5,0]  R1315     8.2255318760871887e-02
    z[1,5,0]  R1316     -2.1478015184402466e-01
    z[1,5,0]  R1317     -1.9356778264045715e-01
    z[1,5,0]  R1318     3.4069761633872986e-02
    z[1,5,0]  R1319     1.0933275334537029e-02
    z[1,5,0]  R1320     3.0830252170562744e-01
    z[1,5,0]  R1321     4.4244241714477539e-01
    z[1,5,0]  R1322     5.9359449893236160e-02
    z[1,5,0]  R1323     6.1092221736907959e-01
    z[1,5,0]  R1324     4.4905692338943481e-02
    z[1,5,0]  R1325     2.7488011121749878e-01
    z[1,5,0]  R1326     4.9197757244110107e-01
    z[1,5,0]  R1327     -1.0621292144060135e-01
    z[1,5,0]  R1328     3.2745444774627686e-01
    z[1,5,0]  R1329     3.9802014827728271e-01
    z[1,5,0]  R1330     3.4995537996292114e-01
    z[1,5,0]  R1331     -1.5063305199146271e-01
    z[1,5,0]  R1332     4.7343918681144714e-01
    z[1,5,0]  R1333     -2.1048258244991302e-01
    z[1,5,0]  R1334     3.3840200304985046e-01
    z[1,5,0]  R1335     4.9328714609146118e-02
    z[1,5,0]  R1336     1.6332606971263885e-01
    z[1,5,0]  R1337     0.0453437939286232
    z[1,5,0]  R1338     1.0652531683444977e-01
    z[1,5,0]  R1339     1.7694209516048431e-01
    z[1,5,0]  R1340     3.9981940388679504e-01
    z[1,5,0]  R1341     -3.0972000211477280e-02
    z[1,5,0]  R1342     1.7476992681622505e-02
    z[1,5,0]  R1343     -1.1291588842868805e-01
    z[1,5,0]  R1344     -1.9607307389378548e-02
    z[1,5,0]  R1345     4.8747184872627258e-01
    z[1,5,0]  R1346     1.8454360961914062e-01
    z[1,5,0]  R1347     8.6628451943397522e-02
    z[1,5,0]  R1348     -4.6332213096320629e-03
    z[1,5,0]  R1349     -0.133395716547966
    z[1,5,0]  R1350     -3.1193557381629944e-01
    z[1,5,0]  R1351     -2.5365066528320312e-01
    z[1,5,0]  R1352     -5.2966989576816559e-02
    z[1,5,0]  R1353     -1.6295957565307617e-01
    z[1,5,0]  R1354     4.2942172288894653e-01
    z[1,5,0]  R1355     -2.3111522197723389e-01
    z[1,5,0]  R1356     5.0620734691619873e-01
    z[1,5,0]  R1357     3.2991644740104675e-01
    z[1,5,0]  R1358     -8.9085623621940613e-02
    z[1,5,0]  R1359     -5.8000821620225906e-02
    z[1,5,0]  R1360     3.1568494439125061e-01
    z[1,5,0]  R1361     1.6023042798042297e-01
    z[1,5,0]  R1362     -2.2212259471416473e-01
    z[1,5,0]  R1363     3.0740559101104736e-01
    z[1,5,0]  R1364     -9.0094543993473053e-02
    z[1,5,0]  R1365     3.9716640114784241e-01
    z[1,5,0]  R1366     -2.3172914981842041e-01
    z[1,5,0]  R1367     1.7375090718269348e-01
    z[1,5,0]  R1368     2.0802558958530426e-01
    z[1,5,0]  R1369     -2.7975955605506897e-01
    z[1,5,0]  R1370     -0.29337078332901
    z[1,5,0]  R1371     -1.1495106155052781e-03
    z[1,5,0]  R1372     -1.6729475557804108e-01
    z[1,5,0]  R1373     -4.1556453704833984e-01
    z[1,5,0]  R1374     -1.5465673059225082e-02
    z[1,5,0]  R1375     1.2804825603961945e-01
    z[1,5,0]  R1376     1.2401670217514038e-01
    z[1,5,0]  R1377     1.9561153650283813e-01
    z[1,5,0]  R1378     3.1262066960334778e-01
    z[1,5,0]  R1379     1.5708579123020172e-01
    z[1,5,0]  R1380     1.5607194602489471e-01
    z[1,5,0]  R1381     4.3293327093124390e-01
    z[1,5,0]  R1382     1.9849990308284760e-01
    z[1,5,0]  R1383     2.9485905170440674e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1282     -1
    z[1,5,1]  R1283     1
    z[1,5,1]  R1294     -7.3943519592285156e-01
    z[1,5,1]  R1295     -5.7814192771911621e-01
    z[1,5,1]  R1296     -4.6810141205787659e-01
    z[1,5,1]  R1297     -2.7959123253822327e-01
    z[1,5,1]  R1298     -3.9454612135887146e-01
    z[1,5,1]  R1299     5.4222857952117920e-01
    z[1,5,1]  R1300     5.4430902004241943e-01
    z[1,5,1]  R1301     8.7147343158721924e-01
    z[1,5,1]  R1302     6.8491917848587036e-01
    z[1,5,1]  R1303     5.4950064420700073e-01
    z[1,5,1]  R1304     0.711979329586029
    z[1,5,1]  R1305     7.1186983585357666e-01
    z[1,5,1]  R1306     6.6931933164596558e-01
    z[1,5,1]  R1307     7.8237426280975342e-01
    z[1,5,1]  R1308     5.9923851490020752e-01
    z[1,5,1]  R1309     5.4216337203979492e-01
    z[1,5,1]  R1310     4.3436288833618164e-01
    z[1,5,1]  R1311     3.3971610665321350e-01
    z[1,5,1]  R1312     -8.9301742613315582e-02
    z[1,5,1]  R1313     2.7429884672164917e-01
    z[1,5,1]  R1314     8.6199837923049927e-01
    z[1,5,1]  R1315     7.5430279970169067e-01
    z[1,5,1]  R1316     7.6275277137756348e-01
    z[1,5,1]  R1317     7.1205347776412964e-01
    z[1,5,1]  R1318     7.1167606115341187e-01
    z[1,5,1]  R1319     6.6217201948165894e-01
    z[1,5,1]  R1320     1.9006147980690002e-01
    z[1,5,1]  R1321     6.9651387631893158e-02
    z[1,5,1]  R1322     1.0630601644515991e-01
    z[1,5,1]  R1323     -3.3505043387413025e-01
    z[1,5,1]  R1324     -6.8122547864913940e-01
    z[1,5,1]  R1325     -6.7748540639877319e-01
    z[1,5,1]  R1326     6.7459249496459961e-01
    z[1,5,1]  R1327     -8.1346917152404785e-01
    z[1,5,1]  R1328     -7.0029234886169434e-01
    z[1,5,1]  R1329     5.2877306938171387e-01
    z[1,5,1]  R1330     5.9612405300140381e-01
    z[1,5,1]  R1331     -1.8770109117031097e-01
    z[1,5,1]  R1332     5.2165532112121582e-01
    z[1,5,1]  R1333     8.9386940002441406e-01
    z[1,5,1]  R1334     8.1641274690628052e-01
    z[1,5,1]  R1335     8.4431940317153931e-01
    z[1,5,1]  R1336     -2.0611999928951263e-01
    z[1,5,1]  R1337     -6.5368312597274780e-01
    z[1,5,1]  R1338     -2.7324327826499939e-01
    z[1,5,1]  R1339     7.9011809825897217e-01
    z[1,5,1]  R1340     6.1137682199478149e-01
    z[1,5,1]  R1341     2.6357316970825195e-01
    z[1,5,1]  R1342     -4.6956473588943481e-01
    z[1,5,1]  R1343     1.1211547255516052e-01
    z[1,5,1]  R1344     -8.9405238628387451e-01
    z[1,5,1]  R1345     0.65756756067276
    z[1,5,1]  R1346     8.2068479061126709e-01
    z[1,5,1]  R1347     -0.741539478302002
    z[1,5,1]  R1348     0.904663622379303
    z[1,5,1]  R1349     -5.9420973062515259e-01
    z[1,5,1]  R1350     -0.470384418964386
    z[1,5,1]  R1351     -3.7736091017723083e-01
    z[1,5,1]  R1352     -8.1561100482940674e-01
    z[1,5,1]  R1353     -5.2647686004638672e-01
    z[1,5,1]  R1354     6.3006180524826050e-01
    z[1,5,1]  R1355     -4.2134487628936768e-01
    z[1,5,1]  R1356     0.691325306892395
    z[1,5,1]  R1357     -0.750025749206543
    z[1,5,1]  R1358     -6.0750845819711685e-02
    z[1,5,1]  R1359     1.1036308109760284e-01
    z[1,5,1]  R1360     0.545853316783905
    z[1,5,1]  R1361     7.5227451324462891e-01
    z[1,5,1]  R1362     -5.3734356164932251e-01
    z[1,5,1]  R1363     4.6872133016586304e-01
    z[1,5,1]  R1364     -7.4568390846252441e-01
    z[1,5,1]  R1365     -8.3605545759201050e-01
    z[1,5,1]  R1366     -6.1399626731872559e-01
    z[1,5,1]  R1367     6.9033062458038330e-01
    z[1,5,1]  R1368     6.4332503080368042e-01
    z[1,5,1]  R1369     5.5489885807037354e-01
    z[1,5,1]  R1370     6.9776940345764160e-01
    z[1,5,1]  R1371     4.6602910757064819e-01
    z[1,5,1]  R1372     5.1794224977493286e-01
    z[1,5,1]  R1373     7.5704419612884521e-01
    z[1,5,1]  R1374     -7.6356285810470581e-01
    z[1,5,1]  R1375     -2.0082026720046997e-01
    z[1,5,1]  R1376     -5.0230443477630615e-01
    z[1,5,1]  R1377     7.5273811817169189e-01
    z[1,5,1]  R1378     6.8352770805358887e-01
    z[1,5,1]  R1379     -6.8227595090866089e-01
    z[1,5,1]  R1380     5.6851136684417725e-01
    z[1,5,1]  R1381     5.7080060243606567e-01
    z[1,5,1]  R1382     5.5767953395843506e-01
    z[1,5,1]  R1383     -0.652384340763092
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1284     -1
    z[1,5,2]  R1285     1
    z[1,5,2]  R1294     -1.9925607740879059e-01
    z[1,5,2]  R1295     -3.2785028219223022e-01
    z[1,5,2]  R1296     -7.2761642932891846e-01
    z[1,5,2]  R1297     7.2494186460971832e-02
    z[1,5,2]  R1298     9.0446047484874725e-02
    z[1,5,2]  R1299     -3.4528259187936783e-02
    z[1,5,2]  R1300     8.5024453699588776e-02
    z[1,5,2]  R1301     2.3083847761154175e-01
    z[1,5,2]  R1302     2.1506215631961823e-01
    z[1,5,2]  R1303     -2.6834979653358459e-01
    z[1,5,2]  R1304     -2.7630642056465149e-02
    z[1,5,2]  R1305     -4.4226527214050293e-01
    z[1,5,2]  R1306     1.0201875865459442e-01
    z[1,5,2]  R1307     -0.326465904712677
    z[1,5,2]  R1308     -6.1449509859085083e-01
    z[1,5,2]  R1309     -3.5805395245552063e-01
    z[1,5,2]  R1310     1.8681395053863525e-01
    z[1,5,2]  R1311     -5.6713706254959106e-01
    z[1,5,2]  R1312     7.0076537132263184e-01
    z[1,5,2]  R1313     -8.1679157912731171e-02
    z[1,5,2]  R1314     7.4630357325077057e-02
    z[1,5,2]  R1315     -3.0827391147613525e-01
    z[1,5,2]  R1316     -1.6502179205417633e-01
    z[1,5,2]  R1317     -5.4879003763198853e-01
    z[1,5,2]  R1318     -4.3301945924758911e-01
    z[1,5,2]  R1319     -5.0865966081619263e-01
    z[1,5,2]  R1320     6.4753150939941406e-01
    z[1,5,2]  R1321     6.5141016244888306e-01
    z[1,5,2]  R1322     9.0096151828765869e-01
    z[1,5,2]  R1323     2.7205786108970642e-01
    z[1,5,2]  R1324     -2.5429481267929077e-01
    z[1,5,2]  R1325     -4.7350153326988220e-01
    z[1,5,2]  R1326     -1.6671952605247498e-01
    z[1,5,2]  R1327     -6.9923691451549530e-02
    z[1,5,2]  R1328     5.1851324737071991e-02
    z[1,5,2]  R1329     -6.2837436795234680e-02
    z[1,5,2]  R1330     -1.7073693871498108e-01
    z[1,5,2]  R1331     -4.8172447085380554e-01
    z[1,5,2]  R1332     -5.1995605230331421e-01
    z[1,5,2]  R1333     -5.7836681604385376e-02
    z[1,5,2]  R1334     2.4669414758682251e-01
    z[1,5,2]  R1335     -1.1313141882419586e-01
    z[1,5,2]  R1336     -1.0266650468111038e-01
    z[1,5,2]  R1337     2.6764890551567078e-01
    z[1,5,2]  R1338     1.7920050024986267e-01
    z[1,5,2]  R1339     3.4833726286888123e-01
    z[1,5,2]  R1340     3.7064486742019653e-01
    z[1,5,2]  R1341     -0.321865051984787
    z[1,5,2]  R1342     -2.4265077710151672e-01
    z[1,5,2]  R1343     3.4573718905448914e-01
    z[1,5,2]  R1344     -1.5769918262958527e-01
    z[1,5,2]  R1345     -4.5038771629333496e-01
    z[1,5,2]  R1346     -3.4964182972908020e-01
    z[1,5,2]  R1347     -4.9290037155151367e-01
    z[1,5,2]  R1348     -7.1905307471752167e-02
    z[1,5,2]  R1349     -1.6450406610965729e-01
    z[1,5,2]  R1350     9.9394604563713074e-02
    z[1,5,2]  R1351     1.7148096859455109e-01
    z[1,5,2]  R1352     1.2626454234123230e-01
    z[1,5,2]  R1353     -3.3183717727661133e-01
    z[1,5,2]  R1354     3.0751636624336243e-01
    z[1,5,2]  R1355     2.0369198918342590e-01
    z[1,5,2]  R1356     0.282680869102478
    z[1,5,2]  R1357     3.1261113286018372e-01
    z[1,5,2]  R1358     -5.2417612075805664e-01
    z[1,5,2]  R1359     1.0222312062978745e-01
    z[1,5,2]  R1360     3.1969651579856873e-01
    z[1,5,2]  R1361     -2.1627022325992584e-01
    z[1,5,2]  R1362     -3.8786804676055908e-01
    z[1,5,2]  R1363     4.1406969539821148e-03
    z[1,5,2]  R1364     3.2021556049585342e-02
    z[1,5,2]  R1365     1.3430744409561157e-01
    z[1,5,2]  R1366     -2.9622071981430054e-01
    z[1,5,2]  R1367     -6.7097288370132446e-01
    z[1,5,2]  R1368     2.2424674034118652e-01
    z[1,5,2]  R1369     -3.8256937265396118e-01
    z[1,5,2]  R1370     -4.1397172212600708e-01
    z[1,5,2]  R1371     -0.676310658454895
    z[1,5,2]  R1372     -6.0162127017974854e-01
    z[1,5,2]  R1373     2.3310698568820953e-01
    z[1,5,2]  R1374     -2.2924098372459412e-01
    z[1,5,2]  R1375     -4.4149917364120483e-01
    z[1,5,2]  R1376     2.4197886884212494e-01
    z[1,5,2]  R1377     -5.4202873259782791e-02
    z[1,5,2]  R1378     -4.5376177877187729e-02
    z[1,5,2]  R1379     3.4249746799468994e-01
    z[1,5,2]  R1380     3.1649532914161682e-01
    z[1,5,2]  R1381     -3.9023196697235107e-01
    z[1,5,2]  R1382     -2.1241942048072815e-01
    z[1,5,2]  R1383     1.6354057192802429e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1286     -1
    z[1,5,3]  R1287     1
    z[1,5,3]  R1294     4.1571286320686340e-01
    z[1,5,3]  R1295     5.2801431156694889e-03
    z[1,5,3]  R1296     2.3760001361370087e-01
    z[1,5,3]  R1297     4.4579803943634033e-01
    z[1,5,3]  R1298     4.1010746359825134e-01
    z[1,5,3]  R1299     0.0699441209435463
    z[1,5,3]  R1300     -2.7111726999282837e-01
    z[1,5,3]  R1301     3.5323426127433777e-03
    z[1,5,3]  R1302     -1.5383604168891907e-01
    z[1,5,3]  R1303     -4.1269126534461975e-01
    z[1,5,3]  R1304     -7.1397058665752411e-02
    z[1,5,3]  R1305     1.3254101388156414e-02
    z[1,5,3]  R1306     -0.062924325466156
    z[1,5,3]  R1307     2.9293122887611389e-01
    z[1,5,3]  R1308     6.8340882658958435e-02
    z[1,5,3]  R1309     -1.5282213687896729e-01
    z[1,5,3]  R1310     -7.1344166994094849e-01
    z[1,5,3]  R1311     -4.9946320056915283e-01
    z[1,5,3]  R1312     -5.0770968198776245e-01
    z[1,5,3]  R1313     -5.8048856258392334e-01
    z[1,5,3]  R1314     -2.9847297072410583e-01
    z[1,5,3]  R1315     5.1173716783523560e-01
    z[1,5,3]  R1316     3.4743675589561462e-01
    z[1,5,3]  R1317     -4.6729825437068939e-02
    z[1,5,3]  R1318     -1.2129744887351990e-01
    z[1,5,3]  R1319     1.2098416686058044e-01
    z[1,5,3]  R1320     -6.5261560678482056e-01
    z[1,5,3]  R1321     -3.6690777540206909e-01
    z[1,5,3]  R1322     -1.4384835958480835e-01
    z[1,5,3]  R1323     -3.5192090272903442e-01
    z[1,5,3]  R1324     5.3208708763122559e-01
    z[1,5,3]  R1325     -6.7700318992137909e-02
    z[1,5,3]  R1326     -1.8652331829071045e-01
    z[1,5,3]  R1327     -2.6899260282516479e-01
    z[1,5,3]  R1328     -1.1053077131509781e-01
    z[1,5,3]  R1329     -6.1051309108734131e-01
    z[1,5,3]  R1330     -4.5318952202796936e-01
    z[1,5,3]  R1331     8.3257085084915161e-01
    z[1,5,3]  R1332     -2.9941469430923462e-01
    z[1,5,3]  R1333     -3.3782172203063965e-01
    z[1,5,3]  R1334     1.8651817739009857e-01
    z[1,5,3]  R1335     -1.5265716612339020e-01
    z[1,5,3]  R1336     8.7237930297851562e-01
    z[1,5,3]  R1337     2.3032648861408234e-01
    z[1,5,3]  R1338     7.4780148267745972e-01
    z[1,5,3]  R1339     -1.2419898062944412e-01
    z[1,5,3]  R1340     -1.8971423804759979e-01
    z[1,5,3]  R1341     8.0624425411224365e-01
    z[1,5,3]  R1342     7.4304181337356567e-01
    z[1,5,3]  R1343     7.6708149909973145e-01
    z[1,5,3]  R1344     -3.8678354024887085e-01
    z[1,5,3]  R1345     -1.7900021374225616e-01
    z[1,5,3]  R1346     3.1066963076591492e-01
    z[1,5,3]  R1347     4.3569728732109070e-01
    z[1,5,3]  R1348     -2.8471006080508232e-02
    z[1,5,3]  R1349     4.4629785418510437e-01
    z[1,5,3]  R1350     5.9161442518234253e-01
    z[1,5,3]  R1351     4.7145324945449829e-01
    z[1,5,3]  R1352     3.5779750347137451e-01
    z[1,5,3]  R1353     3.3317390084266663e-01
    z[1,5,3]  R1354     -5.2699881792068481e-01
    z[1,5,3]  R1355     5.4240685701370239e-01
    z[1,5,3]  R1356     -2.0581322908401489e-01
    z[1,5,3]  R1357     1.1047840118408203e-02
    z[1,5,3]  R1358     7.0259046554565430e-01
    z[1,5,3]  R1359     9.2891907691955566e-01
    z[1,5,3]  R1360     -3.5196724534034729e-01
    z[1,5,3]  R1361     3.0686733126640320e-01
    z[1,5,3]  R1362     3.9088377356529236e-01
    z[1,5,3]  R1363     -3.0861553549766541e-01
    z[1,5,3]  R1364     -2.1929587423801422e-01
    z[1,5,3]  R1365     1.1554061621427536e-01
    z[1,5,3]  R1366     -1.4648194611072540e-01
    z[1,5,3]  R1367     5.5972304195165634e-02
    z[1,5,3]  R1368     4.1575622558593750e-01
    z[1,5,3]  R1369     -1.5586887300014496e-01
    z[1,5,3]  R1370     -3.8521891832351685e-01
    z[1,5,3]  R1371     -6.8435288965702057e-02
    z[1,5,3]  R1372     5.9285301715135574e-02
    z[1,5,3]  R1373     5.6945491582155228e-02
    z[1,5,3]  R1374     3.5616809129714966e-01
    z[1,5,3]  R1375     7.6187252998352051e-01
    z[1,5,3]  R1376     7.9293966293334961e-01
    z[1,5,3]  R1377     4.6142944693565369e-01
    z[1,5,3]  R1378     2.7731695771217346e-01
    z[1,5,3]  R1379     3.4239280223846436e-01
    z[1,5,3]  R1380     -2.7753153443336487e-01
    z[1,5,3]  R1381     4.9526520073413849e-02
    z[1,5,3]  R1382     -2.2915895283222198e-01
    z[1,5,3]  R1383     8.4319151937961578e-02
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1288     -1
    z[1,5,4]  R1289     1
    z[1,5,4]  R1294     -1.9522084295749664e-01
    z[1,5,4]  R1295     -5.5625919252634048e-02
    z[1,5,4]  R1296     -1.1468805372714996e-01
    z[1,5,4]  R1297     2.8277322649955750e-01
    z[1,5,4]  R1298     -4.1842761635780334e-01
    z[1,5,4]  R1299     -5.1813744008541107e-02
    z[1,5,4]  R1300     1.5262334048748016e-01
    z[1,5,4]  R1301     -3.9830081164836884e-02
    z[1,5,4]  R1302     -3.4797763824462891e-01
    z[1,5,4]  R1303     -1.8198819458484650e-01
    z[1,5,4]  R1304     5.0782209634780884e-01
    z[1,5,4]  R1305     5.0541943311691284e-01
    z[1,5,4]  R1306     7.0441913604736328e-01
    z[1,5,4]  R1307     1.5030542016029358e-01
    z[1,5,4]  R1308     1.8428441882133484e-01
    z[1,5,4]  R1309     0.532706618309021
    z[1,5,4]  R1310     4.6939682960510254e-01
    z[1,5,4]  R1311     -1.0630524903535843e-01
    z[1,5,4]  R1312     -1.1071750521659851e-01
    z[1,5,4]  R1313     -3.0283406376838684e-03
    z[1,5,4]  R1314     1.0974252223968506e-01
    z[1,5,4]  R1315     -1.2475372105836868e-01
    z[1,5,4]  R1316     2.1234643459320068e-01
    z[1,5,4]  R1317     1.4340290427207947e-01
    z[1,5,4]  R1318     4.1452908515930176e-01
    z[1,5,4]  R1319     -2.9557171463966370e-01
    z[1,5,4]  R1320     1.0928661562502384e-02
    z[1,5,4]  R1321     -3.0401936173439026e-01
    z[1,5,4]  R1322     1.9716110825538635e-01
    z[1,5,4]  R1323     4.9992737174034119e-01
    z[1,5,4]  R1324     -0.407550185918808
    z[1,5,4]  R1325     1.0992280393838882e-01
    z[1,5,4]  R1326     -6.1532676219940186e-02
    z[1,5,4]  R1327     -5.0204541534185410e-02
    z[1,5,4]  R1328     -4.9264460802078247e-01
    z[1,5,4]  R1329     -2.8671622276306152e-01
    z[1,5,4]  R1330     2.6149597018957138e-02
    z[1,5,4]  R1331     7.3123171925544739e-02
    z[1,5,4]  R1332     4.4613435864448547e-02
    z[1,5,4]  R1333     -0.0691533163189888
    z[1,5,4]  R1334     0.07137431204319
    z[1,5,4]  R1335     2.4950174987316132e-01
    z[1,5,4]  R1336     1.0654534399509430e-01
    z[1,5,4]  R1337     -4.5509532094001770e-01
    z[1,5,4]  R1338     -3.6515191197395325e-01
    z[1,5,4]  R1339     -0.416479229927063
    z[1,5,4]  R1340     -4.0927022695541382e-01
    z[1,5,4]  R1341     -1.9846189022064209e-01
    z[1,5,4]  R1342     -1.9453060626983643e-01
    z[1,5,4]  R1343     3.6199086904525757e-01
    z[1,5,4]  R1344     6.9938585162162781e-02
    z[1,5,4]  R1345     -1.3595966994762421e-01
    z[1,5,4]  R1346     -1.5079443156719208e-01
    z[1,5,4]  R1347     -4.1097655892372131e-02
    z[1,5,4]  R1348     2.1752344444394112e-02
    z[1,5,4]  R1349     -1.8148691952228546e-01
    z[1,5,4]  R1350     1.0181655734777451e-01
    z[1,5,4]  R1351     6.8882554769515991e-01
    z[1,5,4]  R1352     4.0979516506195068e-01
    z[1,5,4]  R1353     0.576056957244873
    z[1,5,4]  R1354     2.0964258909225464e-01
    z[1,5,4]  R1355     3.7249827384948730e-01
    z[1,5,4]  R1356     -1.2518243491649628e-01
    z[1,5,4]  R1357     -2.4802911281585693e-01
    z[1,5,4]  R1358     7.4077457189559937e-02
    z[1,5,4]  R1359     1.6445495188236237e-01
    z[1,5,4]  R1360     -1.8125905096530914e-01
    z[1,5,4]  R1361     4.0912351012229919e-01
    z[1,5,4]  R1362     5.2063208818435669e-01
    z[1,5,4]  R1363     3.7820154428482056e-01
    z[1,5,4]  R1364     4.0455322712659836e-02
    z[1,5,4]  R1365     -1.0657750535756350e-03
    z[1,5,4]  R1366     -4.4077765941619873e-01
    z[1,5,4]  R1367     1.6311611235141754e-01
    z[1,5,4]  R1368     -3.8399747014045715e-01
    z[1,5,4]  R1369     -2.7723035216331482e-01
    z[1,5,4]  R1370     1.5596590936183929e-01
    z[1,5,4]  R1371     -5.1666635274887085e-01
    z[1,5,4]  R1372     -4.1069126129150391e-01
    z[1,5,4]  R1373     3.2260903716087341e-01
    z[1,5,4]  R1374     4.1462130844593048e-02
    z[1,5,4]  R1375     -1.7017647624015808e-01
    z[1,5,4]  R1376     5.4746586829423904e-02
    z[1,5,4]  R1377     -3.8583523035049438e-01
    z[1,5,4]  R1378     -2.4354654550552368e-01
    z[1,5,4]  R1379     3.6474749445915222e-01
    z[1,5,4]  R1380     -2.8474736213684082e-01
    z[1,5,4]  R1381     4.2725983262062073e-01
    z[1,5,4]  R1382     5.4021787643432617e-01
    z[1,5,4]  R1383     -4.9213051795959473e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1290     -1
    z[1,5,5]  R1291     1
    z[1,5,5]  R1294     4.5144062489271164e-02
    z[1,5,5]  R1295     5.1510158926248550e-02
    z[1,5,5]  R1296     -3.9596560597419739e-01
    z[1,5,5]  R1297     -3.4057098627090454e-01
    z[1,5,5]  R1298     -6.3107395172119141e-01
    z[1,5,5]  R1299     -1.0247718542814255e-01
    z[1,5,5]  R1300     -3.4925499558448792e-01
    z[1,5,5]  R1301     4.0217429399490356e-01
    z[1,5,5]  R1302     -1.4051049947738647e-01
    z[1,5,5]  R1303     -2.4994817376136780e-01
    z[1,5,5]  R1304     -4.4802263379096985e-01
    z[1,5,5]  R1305     -2.0324413478374481e-01
    z[1,5,5]  R1306     -1.0597249493002892e-02
    z[1,5,5]  R1307     -3.6264079809188843e-01
    z[1,5,5]  R1308     4.3007194995880127e-01
    z[1,5,5]  R1309     3.4774327278137207e-01
    z[1,5,5]  R1310     5.7146232575178146e-02
    z[1,5,5]  R1311     5.0299829244613647e-01
    z[1,5,5]  R1312     3.9705076813697815e-01
    z[1,5,5]  R1313     -4.2692460119724274e-02
    z[1,5,5]  R1314     -5.0250776112079620e-02
    z[1,5,5]  R1315     1.9489030539989471e-01
    z[1,5,5]  R1316     4.0899339318275452e-01
    z[1,5,5]  R1317     1.7612640559673309e-01
    z[1,5,5]  R1318     2.3359447717666626e-01
    z[1,5,5]  R1319     4.1298249363899231e-01
    z[1,5,5]  R1320     2.2846752777695656e-02
    z[1,5,5]  R1321     2.2896414995193481e-01
    z[1,5,5]  R1322     0.241278275847435
    z[1,5,5]  R1323     2.1940311789512634e-01
    z[1,5,5]  R1324     -6.6448740661144257e-02
    z[1,5,5]  R1325     -2.0032858848571777e-01
    z[1,5,5]  R1326     -4.6768745779991150e-01
    z[1,5,5]  R1327     5.4006807506084442e-02
    z[1,5,5]  R1328     -3.8019725680351257e-01
    z[1,5,5]  R1329     -2.8030180931091309e-01
    z[1,5,5]  R1330     -0.13898965716362
    z[1,5,5]  R1331     4.4669758528470993e-02
    z[1,5,5]  R1332     1.2786471843719482e-01
    z[1,5,5]  R1333     -1.5990903973579407e-01
    z[1,5,5]  R1334     2.9171234369277954e-01
    z[1,5,5]  R1335     2.6608529686927795e-01
    z[1,5,5]  R1336     1.8212196230888367e-01
    z[1,5,5]  R1337     -3.5044002532958984e-01
    z[1,5,5]  R1338     3.0996114015579224e-01
    z[1,5,5]  R1339     1.8105560541152954e-01
    z[1,5,5]  R1340     7.2475492954254150e-02
    z[1,5,5]  R1341     3.5527545213699341e-01
    z[1,5,5]  R1342     2.4875281751155853e-01
    z[1,5,5]  R1343     3.3961758017539978e-01
    z[1,5,5]  R1344     1.3228674232959747e-01
    z[1,5,5]  R1345     2.4678136408329010e-01
    z[1,5,5]  R1346     2.2562603652477264e-01
    z[1,5,5]  R1347     7.9707249999046326e-02
    z[1,5,5]  R1348     -2.2326244413852692e-01
    z[1,5,5]  R1349     2.3951642215251923e-01
    z[1,5,5]  R1350     1.1684230715036392e-01
    z[1,5,5]  R1351     2.3714546859264374e-01
    z[1,5,5]  R1352     -1.2539631128311157e-01
    z[1,5,5]  R1353     3.4624379873275757e-01
    z[1,5,5]  R1354     -4.3736483901739120e-02
    z[1,5,5]  R1355     0.495735228061676
    z[1,5,5]  R1356     -2.8402847051620483e-01
    z[1,5,5]  R1357     -4.0881112217903137e-01
    z[1,5,5]  R1358     4.6252843737602234e-01
    z[1,5,5]  R1359     2.7142751216888428e-01
    z[1,5,5]  R1360     5.7872855663299561e-01
    z[1,5,5]  R1361     -3.0829516053199768e-01
    z[1,5,5]  R1362     -2.7387544512748718e-01
    z[1,5,5]  R1363     -1.7499661445617676e-01
    z[1,5,5]  R1364     -5.5390429496765137e-01
    z[1,5,5]  R1365     8.0321721732616425e-02
    z[1,5,5]  R1366     -3.3402532339096069e-01
    z[1,5,5]  R1367     -7.4996486306190491e-02
    z[1,5,5]  R1368     -2.1256893873214722e-01
    z[1,5,5]  R1369     -4.5390984416007996e-01
    z[1,5,5]  R1370     2.7678820490837097e-01
    z[1,5,5]  R1371     -5.7354439049959183e-02
    z[1,5,5]  R1372     1.0543572902679443e-01
    z[1,5,5]  R1373     2.4937982857227325e-01
    z[1,5,5]  R1374     1.0438472777605057e-01
    z[1,5,5]  R1375     3.7046140432357788e-01
    z[1,5,5]  R1376     1.9523890316486359e-01
    z[1,5,5]  R1377     -1.6952624917030334e-01
    z[1,5,5]  R1378     -1.2062735855579376e-01
    z[1,5,5]  R1379     -1.1992149800062180e-01
    z[1,5,5]  R1380     1.9417542219161987e-01
    z[1,5,5]  R1381     2.3745548725128174e-01
    z[1,5,5]  R1382     4.2656177282333374e-01
    z[1,5,5]  R1383     3.4880742430686951e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1292     -1
    z[1,5,6]  R1293     1
    z[1,5,6]  R1294     4.4508108496665955e-01
    z[1,5,6]  R1295     -4.6299800276756287e-01
    z[1,5,6]  R1296     -1.1209972202777863e-01
    z[1,5,6]  R1297     -3.7462544441223145e-01
    z[1,5,6]  R1298     -2.7219581604003906e-01
    z[1,5,6]  R1299     5.1093274354934692e-01
    z[1,5,6]  R1300     2.6656261086463928e-01
    z[1,5,6]  R1301     -1.5174549818038940e-01
    z[1,5,6]  R1302     -3.5464456677436829e-01
    z[1,5,6]  R1303     -5.2352637052536011e-01
    z[1,5,6]  R1304     -1.9029730930924416e-02
    z[1,5,6]  R1305     1.1859763413667679e-02
    z[1,5,6]  R1306     1.6963452100753784e-01
    z[1,5,6]  R1307     -4.3357063084840775e-02
    z[1,5,6]  R1308     1.4768348634243011e-01
    z[1,5,6]  R1309     3.8006898760795593e-01
    z[1,5,6]  R1310     -0.208759143948555
    z[1,5,6]  R1311     1.0208845883607864e-01
    z[1,5,6]  R1312     1.4676529169082642e-01
    z[1,5,6]  R1313     4.4861856102943420e-01
    z[1,5,6]  R1314     -3.4222227334976196e-01
    z[1,5,6]  R1315     1.1750672757625580e-01
    z[1,5,6]  R1316     1.0847406834363937e-01
    z[1,5,6]  R1317     -3.1713131070137024e-01
    z[1,5,6]  R1318     2.5246149301528931e-01
    z[1,5,6]  R1319     -1.7355036735534668e-01
    z[1,5,6]  R1320     -1.5159356594085693e-01
    z[1,5,6]  R1321     3.0916744470596313e-01
    z[1,5,6]  R1322     2.3593175411224365e-01
    z[1,5,6]  R1323     -1.3633179664611816e-01
    z[1,5,6]  R1324     1.2498059123754501e-01
    z[1,5,6]  R1325     4.2947977781295776e-01
    z[1,5,6]  R1326     -1.3333770632743835e-01
    z[1,5,6]  R1327     -4.9427023530006409e-01
    z[1,5,6]  R1328     1.4493362046778202e-02
    z[1,5,6]  R1329     -1.5661749243736267e-01
    z[1,5,6]  R1330     -5.1733326911926270e-01
    z[1,5,6]  R1331     -9.7482755780220032e-02
    z[1,5,6]  R1332     -3.5410153865814209e-01
    z[1,5,6]  R1333     -9.4195976853370667e-02
    z[1,5,6]  R1334     1.8198034167289734e-01
    z[1,5,6]  R1335     3.3990573883056641e-01
    z[1,5,6]  R1336     3.3872240781784058e-01
    z[1,5,6]  R1337     -3.4064075350761414e-01
    z[1,5,6]  R1338     -3.0538308620452881e-01
    z[1,5,6]  R1339     3.7478078156709671e-02
    z[1,5,6]  R1340     3.4675487875938416e-01
    z[1,5,6]  R1341     -1.0166209936141968e-01
    z[1,5,6]  R1342     -2.6171153783798218e-01
    z[1,5,6]  R1343     1.4266893267631531e-01
    z[1,5,6]  R1344     -5.8515619486570358e-02
    z[1,5,6]  R1345     1.2529952824115753e-01
    z[1,5,6]  R1346     -2.9958526138216257e-03
    z[1,5,6]  R1347     -4.2302541434764862e-02
    z[1,5,6]  R1348     3.5392352938652039e-01
    z[1,5,6]  R1349     -5.5908089876174927e-01
    z[1,5,6]  R1350     -5.4546225070953369e-01
    z[1,5,6]  R1351     1.0424774140119553e-01
    z[1,5,6]  R1352     6.5992519259452820e-02
    z[1,5,6]  R1353     1.5303359925746918e-01
    z[1,5,6]  R1354     2.1497702226042747e-02
    z[1,5,6]  R1355     -2.2102083265781403e-01
    z[1,5,6]  R1356     2.1728539466857910e-01
    z[1,5,6]  R1357     4.6085428446531296e-02
    z[1,5,6]  R1358     -2.3642720654606819e-02
    z[1,5,6]  R1359     1.0196760296821594e-01
    z[1,5,6]  R1360     -9.2297062277793884e-02
    z[1,5,6]  R1361     7.1000531315803528e-02
    z[1,5,6]  R1362     1.1236649006605148e-01
    z[1,5,6]  R1363     0.645663321018219
    z[1,5,6]  R1364     -2.7977797389030457e-01
    z[1,5,6]  R1365     3.2469874620437622e-01
    z[1,5,6]  R1366     -3.9274501800537109e-01
    z[1,5,6]  R1367     -8.7665893137454987e-02
    z[1,5,6]  R1368     -3.5648101568222046e-01
    z[1,5,6]  R1369     -4.0034556388854980e-01
    z[1,5,6]  R1370     -7.9675689339637756e-02
    z[1,5,6]  R1371     -2.2472733259201050e-01
    z[1,5,6]  R1372     -3.9812245965003967e-01
    z[1,5,6]  R1373     -1.7418856918811798e-01
    z[1,5,6]  R1374     4.7403600811958313e-01
    z[1,5,6]  R1375     4.1254632174968719e-02
    z[1,5,6]  R1376     6.2351156026124954e-02
    z[1,5,6]  R1377     4.0722902864217758e-02
    z[1,5,6]  R1378     -5.3125196695327759e-01
    z[1,5,6]  R1379     3.5758140683174133e-01
    z[1,5,6]  R1380     -5.9704118967056274e-01
    z[1,5,6]  R1381     -3.0509895086288452e-01
    z[1,5,6]  R1382     -2.7958011627197266e-01
    z[1,5,6]  R1383     -2.9956376552581787e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1384     -1
    z[5,1,0]  R1385     1
    z[5,1,0]  R1398     4.4905692338943481e-02
    z[5,1,0]  R1399     2.7488011121749878e-01
    z[5,1,0]  R1400     4.9197757244110107e-01
    z[5,1,0]  R1401     -1.0621292144060135e-01
    z[5,1,0]  R1402     3.2745444774627686e-01
    z[5,1,0]  R1403     3.9802014827728271e-01
    z[5,1,0]  R1404     3.4995537996292114e-01
    z[5,1,0]  R1405     -1.5063305199146271e-01
    z[5,1,0]  R1406     4.7343918681144714e-01
    z[5,1,0]  R1407     -2.1048258244991302e-01
    z[5,1,0]  R1408     3.3840200304985046e-01
    z[5,1,0]  R1409     4.9328714609146118e-02
    z[5,1,0]  R1410     1.6332606971263885e-01
    z[5,1,0]  R1411     0.0453437939286232
    z[5,1,0]  R1412     1.0652531683444977e-01
    z[5,1,0]  R1413     1.7694209516048431e-01
    z[5,1,0]  R1414     3.9981940388679504e-01
    z[5,1,0]  R1415     -3.0972000211477280e-02
    z[5,1,0]  R1416     1.7476992681622505e-02
    z[5,1,0]  R1417     -1.1291588842868805e-01
    z[5,1,0]  R1418     -1.9607307389378548e-02
    z[5,1,0]  R1419     4.8747184872627258e-01
    z[5,1,0]  R1420     1.8454360961914062e-01
    z[5,1,0]  R1421     8.6628451943397522e-02
    z[5,1,0]  R1422     -4.6332213096320629e-03
    z[5,1,0]  R1423     -0.133395716547966
    z[5,1,0]  R1424     -3.1193557381629944e-01
    z[5,1,0]  R1425     -2.5365066528320312e-01
    z[5,1,0]  R1426     -5.2966989576816559e-02
    z[5,1,0]  R1427     -1.6295957565307617e-01
    z[5,1,0]  R1428     4.2942172288894653e-01
    z[5,1,0]  R1429     -2.3111522197723389e-01
    z[5,1,0]  R1430     5.0620734691619873e-01
    z[5,1,0]  R1431     3.2991644740104675e-01
    z[5,1,0]  R1432     -8.9085623621940613e-02
    z[5,1,0]  R1433     -5.8000821620225906e-02
    z[5,1,0]  R1434     3.1568494439125061e-01
    z[5,1,0]  R1435     1.6023042798042297e-01
    z[5,1,0]  R1436     -2.2212259471416473e-01
    z[5,1,0]  R1437     3.0740559101104736e-01
    z[5,1,0]  R1438     -9.0094543993473053e-02
    z[5,1,0]  R1439     3.9716640114784241e-01
    z[5,1,0]  R1440     -2.3172914981842041e-01
    z[5,1,0]  R1441     1.7375090718269348e-01
    z[5,1,0]  R1442     2.0802558958530426e-01
    z[5,1,0]  R1443     -2.7975955605506897e-01
    z[5,1,0]  R1444     -0.29337078332901
    z[5,1,0]  R1445     -1.1495106155052781e-03
    z[5,1,0]  R1446     -1.6729475557804108e-01
    z[5,1,0]  R1447     -4.1556453704833984e-01
    z[5,1,0]  R1448     -1.5465673059225082e-02
    z[5,1,0]  R1449     1.2804825603961945e-01
    z[5,1,0]  R1450     1.2401670217514038e-01
    z[5,1,0]  R1451     1.9561153650283813e-01
    z[5,1,0]  R1452     3.1262066960334778e-01
    z[5,1,0]  R1453     1.5708579123020172e-01
    z[5,1,0]  R1454     1.5607194602489471e-01
    z[5,1,0]  R1455     4.3293327093124390e-01
    z[5,1,0]  R1456     1.9849990308284760e-01
    z[5,1,0]  R1457     2.9485905170440674e-01
    z[5,1,0]  R1458     -4.9690928310155869e-02
    z[5,1,0]  R1459     -5.8148401975631714e-01
    z[5,1,0]  R1460     -1.1177226155996323e-01
    z[5,1,0]  R1461     -6.1769241094589233e-01
    z[5,1,0]  R1462     1.4331138134002686e-01
    z[5,1,0]  R1463     6.5243035554885864e-01
    z[5,1,0]  R1464     6.3770312070846558e-01
    z[5,1,0]  R1465     2.9630595818161964e-02
    z[5,1,0]  R1466     4.4086730480194092e-01
    z[5,1,0]  R1467     2.9334232211112976e-01
    z[5,1,0]  R1468     1.6809152066707611e-01
    z[5,1,0]  R1469     -0.023863660171628
    z[5,1,0]  R1470     -1.1202633380889893e-01
    z[5,1,0]  R1471     1.9880126416683197e-01
    z[5,1,0]  R1472     -1.3381104171276093e-01
    z[5,1,0]  R1473     -7.3125801980495453e-02
    z[5,1,0]  R1474     -1.5840733423829079e-02
    z[5,1,0]  R1475     1.9686248898506165e-01
    z[5,1,0]  R1476     2.2745615243911743e-01
    z[5,1,0]  R1477     -6.1484247446060181e-01
    z[5,1,0]  R1478     1.7498087882995605e-01
    z[5,1,0]  R1479     8.2255318760871887e-02
    z[5,1,0]  R1480     -2.1478015184402466e-01
    z[5,1,0]  R1481     -1.9356778264045715e-01
    z[5,1,0]  R1482     3.4069761633872986e-02
    z[5,1,0]  R1483     1.0933275334537029e-02
    z[5,1,0]  R1484     3.0830252170562744e-01
    z[5,1,0]  R1485     4.4244241714477539e-01
    z[5,1,0]  R1486     5.9359449893236160e-02
    z[5,1,0]  R1487     6.1092221736907959e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1386     -1
    z[5,1,1]  R1387     1
    z[5,1,1]  R1398     -6.8122547864913940e-01
    z[5,1,1]  R1399     -6.7748540639877319e-01
    z[5,1,1]  R1400     6.7459249496459961e-01
    z[5,1,1]  R1401     -8.1346917152404785e-01
    z[5,1,1]  R1402     -7.0029234886169434e-01
    z[5,1,1]  R1403     5.2877306938171387e-01
    z[5,1,1]  R1404     5.9612405300140381e-01
    z[5,1,1]  R1405     -1.8770109117031097e-01
    z[5,1,1]  R1406     5.2165532112121582e-01
    z[5,1,1]  R1407     8.9386940002441406e-01
    z[5,1,1]  R1408     8.1641274690628052e-01
    z[5,1,1]  R1409     8.4431940317153931e-01
    z[5,1,1]  R1410     -2.0611999928951263e-01
    z[5,1,1]  R1411     -6.5368312597274780e-01
    z[5,1,1]  R1412     -2.7324327826499939e-01
    z[5,1,1]  R1413     7.9011809825897217e-01
    z[5,1,1]  R1414     6.1137682199478149e-01
    z[5,1,1]  R1415     2.6357316970825195e-01
    z[5,1,1]  R1416     -4.6956473588943481e-01
    z[5,1,1]  R1417     1.1211547255516052e-01
    z[5,1,1]  R1418     -8.9405238628387451e-01
    z[5,1,1]  R1419     0.65756756067276
    z[5,1,1]  R1420     8.2068479061126709e-01
    z[5,1,1]  R1421     -0.741539478302002
    z[5,1,1]  R1422     0.904663622379303
    z[5,1,1]  R1423     -5.9420973062515259e-01
    z[5,1,1]  R1424     -0.470384418964386
    z[5,1,1]  R1425     -3.7736091017723083e-01
    z[5,1,1]  R1426     -8.1561100482940674e-01
    z[5,1,1]  R1427     -5.2647686004638672e-01
    z[5,1,1]  R1428     6.3006180524826050e-01
    z[5,1,1]  R1429     -4.2134487628936768e-01
    z[5,1,1]  R1430     0.691325306892395
    z[5,1,1]  R1431     -0.750025749206543
    z[5,1,1]  R1432     -6.0750845819711685e-02
    z[5,1,1]  R1433     1.1036308109760284e-01
    z[5,1,1]  R1434     0.545853316783905
    z[5,1,1]  R1435     7.5227451324462891e-01
    z[5,1,1]  R1436     -5.3734356164932251e-01
    z[5,1,1]  R1437     4.6872133016586304e-01
    z[5,1,1]  R1438     -7.4568390846252441e-01
    z[5,1,1]  R1439     -8.3605545759201050e-01
    z[5,1,1]  R1440     -6.1399626731872559e-01
    z[5,1,1]  R1441     6.9033062458038330e-01
    z[5,1,1]  R1442     6.4332503080368042e-01
    z[5,1,1]  R1443     5.5489885807037354e-01
    z[5,1,1]  R1444     6.9776940345764160e-01
    z[5,1,1]  R1445     4.6602910757064819e-01
    z[5,1,1]  R1446     5.1794224977493286e-01
    z[5,1,1]  R1447     7.5704419612884521e-01
    z[5,1,1]  R1448     -7.6356285810470581e-01
    z[5,1,1]  R1449     -2.0082026720046997e-01
    z[5,1,1]  R1450     -5.0230443477630615e-01
    z[5,1,1]  R1451     7.5273811817169189e-01
    z[5,1,1]  R1452     6.8352770805358887e-01
    z[5,1,1]  R1453     -6.8227595090866089e-01
    z[5,1,1]  R1454     5.6851136684417725e-01
    z[5,1,1]  R1455     5.7080060243606567e-01
    z[5,1,1]  R1456     5.5767953395843506e-01
    z[5,1,1]  R1457     -0.652384340763092
    z[5,1,1]  R1458     -7.3943519592285156e-01
    z[5,1,1]  R1459     -5.7814192771911621e-01
    z[5,1,1]  R1460     -4.6810141205787659e-01
    z[5,1,1]  R1461     -2.7959123253822327e-01
    z[5,1,1]  R1462     -3.9454612135887146e-01
    z[5,1,1]  R1463     5.4222857952117920e-01
    z[5,1,1]  R1464     5.4430902004241943e-01
    z[5,1,1]  R1465     8.7147343158721924e-01
    z[5,1,1]  R1466     6.8491917848587036e-01
    z[5,1,1]  R1467     5.4950064420700073e-01
    z[5,1,1]  R1468     0.711979329586029
    z[5,1,1]  R1469     7.1186983585357666e-01
    z[5,1,1]  R1470     6.6931933164596558e-01
    z[5,1,1]  R1471     7.8237426280975342e-01
    z[5,1,1]  R1472     5.9923851490020752e-01
    z[5,1,1]  R1473     5.4216337203979492e-01
    z[5,1,1]  R1474     4.3436288833618164e-01
    z[5,1,1]  R1475     3.3971610665321350e-01
    z[5,1,1]  R1476     -8.9301742613315582e-02
    z[5,1,1]  R1477     2.7429884672164917e-01
    z[5,1,1]  R1478     8.6199837923049927e-01
    z[5,1,1]  R1479     7.5430279970169067e-01
    z[5,1,1]  R1480     7.6275277137756348e-01
    z[5,1,1]  R1481     7.1205347776412964e-01
    z[5,1,1]  R1482     7.1167606115341187e-01
    z[5,1,1]  R1483     6.6217201948165894e-01
    z[5,1,1]  R1484     1.9006147980690002e-01
    z[5,1,1]  R1485     6.9651387631893158e-02
    z[5,1,1]  R1486     1.0630601644515991e-01
    z[5,1,1]  R1487     -3.3505043387413025e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1388     -1
    z[5,1,2]  R1389     1
    z[5,1,2]  R1398     -2.5429481267929077e-01
    z[5,1,2]  R1399     -4.7350153326988220e-01
    z[5,1,2]  R1400     -1.6671952605247498e-01
    z[5,1,2]  R1401     -6.9923691451549530e-02
    z[5,1,2]  R1402     5.1851324737071991e-02
    z[5,1,2]  R1403     -6.2837436795234680e-02
    z[5,1,2]  R1404     -1.7073693871498108e-01
    z[5,1,2]  R1405     -4.8172447085380554e-01
    z[5,1,2]  R1406     -5.1995605230331421e-01
    z[5,1,2]  R1407     -5.7836681604385376e-02
    z[5,1,2]  R1408     2.4669414758682251e-01
    z[5,1,2]  R1409     -1.1313141882419586e-01
    z[5,1,2]  R1410     -1.0266650468111038e-01
    z[5,1,2]  R1411     2.6764890551567078e-01
    z[5,1,2]  R1412     1.7920050024986267e-01
    z[5,1,2]  R1413     3.4833726286888123e-01
    z[5,1,2]  R1414     3.7064486742019653e-01
    z[5,1,2]  R1415     -0.321865051984787
    z[5,1,2]  R1416     -2.4265077710151672e-01
    z[5,1,2]  R1417     3.4573718905448914e-01
    z[5,1,2]  R1418     -1.5769918262958527e-01
    z[5,1,2]  R1419     -4.5038771629333496e-01
    z[5,1,2]  R1420     -3.4964182972908020e-01
    z[5,1,2]  R1421     -4.9290037155151367e-01
    z[5,1,2]  R1422     -7.1905307471752167e-02
    z[5,1,2]  R1423     -1.6450406610965729e-01
    z[5,1,2]  R1424     9.9394604563713074e-02
    z[5,1,2]  R1425     1.7148096859455109e-01
    z[5,1,2]  R1426     1.2626454234123230e-01
    z[5,1,2]  R1427     -3.3183717727661133e-01
    z[5,1,2]  R1428     3.0751636624336243e-01
    z[5,1,2]  R1429     2.0369198918342590e-01
    z[5,1,2]  R1430     0.282680869102478
    z[5,1,2]  R1431     3.1261113286018372e-01
    z[5,1,2]  R1432     -5.2417612075805664e-01
    z[5,1,2]  R1433     1.0222312062978745e-01
    z[5,1,2]  R1434     3.1969651579856873e-01
    z[5,1,2]  R1435     -2.1627022325992584e-01
    z[5,1,2]  R1436     -3.8786804676055908e-01
    z[5,1,2]  R1437     4.1406969539821148e-03
    z[5,1,2]  R1438     3.2021556049585342e-02
    z[5,1,2]  R1439     1.3430744409561157e-01
    z[5,1,2]  R1440     -2.9622071981430054e-01
    z[5,1,2]  R1441     -6.7097288370132446e-01
    z[5,1,2]  R1442     2.2424674034118652e-01
    z[5,1,2]  R1443     -3.8256937265396118e-01
    z[5,1,2]  R1444     -4.1397172212600708e-01
    z[5,1,2]  R1445     -0.676310658454895
    z[5,1,2]  R1446     -6.0162127017974854e-01
    z[5,1,2]  R1447     2.3310698568820953e-01
    z[5,1,2]  R1448     -2.2924098372459412e-01
    z[5,1,2]  R1449     -4.4149917364120483e-01
    z[5,1,2]  R1450     2.4197886884212494e-01
    z[5,1,2]  R1451     -5.4202873259782791e-02
    z[5,1,2]  R1452     -4.5376177877187729e-02
    z[5,1,2]  R1453     3.4249746799468994e-01
    z[5,1,2]  R1454     3.1649532914161682e-01
    z[5,1,2]  R1455     -3.9023196697235107e-01
    z[5,1,2]  R1456     -2.1241942048072815e-01
    z[5,1,2]  R1457     1.6354057192802429e-01
    z[5,1,2]  R1458     -1.9925607740879059e-01
    z[5,1,2]  R1459     -3.2785028219223022e-01
    z[5,1,2]  R1460     -7.2761642932891846e-01
    z[5,1,2]  R1461     7.2494186460971832e-02
    z[5,1,2]  R1462     9.0446047484874725e-02
    z[5,1,2]  R1463     -3.4528259187936783e-02
    z[5,1,2]  R1464     8.5024453699588776e-02
    z[5,1,2]  R1465     2.3083847761154175e-01
    z[5,1,2]  R1466     2.1506215631961823e-01
    z[5,1,2]  R1467     -2.6834979653358459e-01
    z[5,1,2]  R1468     -2.7630642056465149e-02
    z[5,1,2]  R1469     -4.4226527214050293e-01
    z[5,1,2]  R1470     1.0201875865459442e-01
    z[5,1,2]  R1471     -0.326465904712677
    z[5,1,2]  R1472     -6.1449509859085083e-01
    z[5,1,2]  R1473     -3.5805395245552063e-01
    z[5,1,2]  R1474     1.8681395053863525e-01
    z[5,1,2]  R1475     -5.6713706254959106e-01
    z[5,1,2]  R1476     7.0076537132263184e-01
    z[5,1,2]  R1477     -8.1679157912731171e-02
    z[5,1,2]  R1478     7.4630357325077057e-02
    z[5,1,2]  R1479     -3.0827391147613525e-01
    z[5,1,2]  R1480     -1.6502179205417633e-01
    z[5,1,2]  R1481     -5.4879003763198853e-01
    z[5,1,2]  R1482     -4.3301945924758911e-01
    z[5,1,2]  R1483     -5.0865966081619263e-01
    z[5,1,2]  R1484     6.4753150939941406e-01
    z[5,1,2]  R1485     6.5141016244888306e-01
    z[5,1,2]  R1486     9.0096151828765869e-01
    z[5,1,2]  R1487     2.7205786108970642e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1390     -1
    z[5,1,3]  R1391     1
    z[5,1,3]  R1398     5.3208708763122559e-01
    z[5,1,3]  R1399     -6.7700318992137909e-02
    z[5,1,3]  R1400     -1.8652331829071045e-01
    z[5,1,3]  R1401     -2.6899260282516479e-01
    z[5,1,3]  R1402     -1.1053077131509781e-01
    z[5,1,3]  R1403     -6.1051309108734131e-01
    z[5,1,3]  R1404     -4.5318952202796936e-01
    z[5,1,3]  R1405     8.3257085084915161e-01
    z[5,1,3]  R1406     -2.9941469430923462e-01
    z[5,1,3]  R1407     -3.3782172203063965e-01
    z[5,1,3]  R1408     1.8651817739009857e-01
    z[5,1,3]  R1409     -1.5265716612339020e-01
    z[5,1,3]  R1410     8.7237930297851562e-01
    z[5,1,3]  R1411     2.3032648861408234e-01
    z[5,1,3]  R1412     7.4780148267745972e-01
    z[5,1,3]  R1413     -1.2419898062944412e-01
    z[5,1,3]  R1414     -1.8971423804759979e-01
    z[5,1,3]  R1415     8.0624425411224365e-01
    z[5,1,3]  R1416     7.4304181337356567e-01
    z[5,1,3]  R1417     7.6708149909973145e-01
    z[5,1,3]  R1418     -3.8678354024887085e-01
    z[5,1,3]  R1419     -1.7900021374225616e-01
    z[5,1,3]  R1420     3.1066963076591492e-01
    z[5,1,3]  R1421     4.3569728732109070e-01
    z[5,1,3]  R1422     -2.8471006080508232e-02
    z[5,1,3]  R1423     4.4629785418510437e-01
    z[5,1,3]  R1424     5.9161442518234253e-01
    z[5,1,3]  R1425     4.7145324945449829e-01
    z[5,1,3]  R1426     3.5779750347137451e-01
    z[5,1,3]  R1427     3.3317390084266663e-01
    z[5,1,3]  R1428     -5.2699881792068481e-01
    z[5,1,3]  R1429     5.4240685701370239e-01
    z[5,1,3]  R1430     -2.0581322908401489e-01
    z[5,1,3]  R1431     1.1047840118408203e-02
    z[5,1,3]  R1432     7.0259046554565430e-01
    z[5,1,3]  R1433     9.2891907691955566e-01
    z[5,1,3]  R1434     -3.5196724534034729e-01
    z[5,1,3]  R1435     3.0686733126640320e-01
    z[5,1,3]  R1436     3.9088377356529236e-01
    z[5,1,3]  R1437     -3.0861553549766541e-01
    z[5,1,3]  R1438     -2.1929587423801422e-01
    z[5,1,3]  R1439     1.1554061621427536e-01
    z[5,1,3]  R1440     -1.4648194611072540e-01
    z[5,1,3]  R1441     5.5972304195165634e-02
    z[5,1,3]  R1442     4.1575622558593750e-01
    z[5,1,3]  R1443     -1.5586887300014496e-01
    z[5,1,3]  R1444     -3.8521891832351685e-01
    z[5,1,3]  R1445     -6.8435288965702057e-02
    z[5,1,3]  R1446     5.9285301715135574e-02
    z[5,1,3]  R1447     5.6945491582155228e-02
    z[5,1,3]  R1448     3.5616809129714966e-01
    z[5,1,3]  R1449     7.6187252998352051e-01
    z[5,1,3]  R1450     7.9293966293334961e-01
    z[5,1,3]  R1451     4.6142944693565369e-01
    z[5,1,3]  R1452     2.7731695771217346e-01
    z[5,1,3]  R1453     3.4239280223846436e-01
    z[5,1,3]  R1454     -2.7753153443336487e-01
    z[5,1,3]  R1455     4.9526520073413849e-02
    z[5,1,3]  R1456     -2.2915895283222198e-01
    z[5,1,3]  R1457     8.4319151937961578e-02
    z[5,1,3]  R1458     4.1571286320686340e-01
    z[5,1,3]  R1459     5.2801431156694889e-03
    z[5,1,3]  R1460     2.3760001361370087e-01
    z[5,1,3]  R1461     4.4579803943634033e-01
    z[5,1,3]  R1462     4.1010746359825134e-01
    z[5,1,3]  R1463     0.0699441209435463
    z[5,1,3]  R1464     -2.7111726999282837e-01
    z[5,1,3]  R1465     3.5323426127433777e-03
    z[5,1,3]  R1466     -1.5383604168891907e-01
    z[5,1,3]  R1467     -4.1269126534461975e-01
    z[5,1,3]  R1468     -7.1397058665752411e-02
    z[5,1,3]  R1469     1.3254101388156414e-02
    z[5,1,3]  R1470     -0.062924325466156
    z[5,1,3]  R1471     2.9293122887611389e-01
    z[5,1,3]  R1472     6.8340882658958435e-02
    z[5,1,3]  R1473     -1.5282213687896729e-01
    z[5,1,3]  R1474     -7.1344166994094849e-01
    z[5,1,3]  R1475     -4.9946320056915283e-01
    z[5,1,3]  R1476     -5.0770968198776245e-01
    z[5,1,3]  R1477     -5.8048856258392334e-01
    z[5,1,3]  R1478     -2.9847297072410583e-01
    z[5,1,3]  R1479     5.1173716783523560e-01
    z[5,1,3]  R1480     3.4743675589561462e-01
    z[5,1,3]  R1481     -4.6729825437068939e-02
    z[5,1,3]  R1482     -1.2129744887351990e-01
    z[5,1,3]  R1483     1.2098416686058044e-01
    z[5,1,3]  R1484     -6.5261560678482056e-01
    z[5,1,3]  R1485     -3.6690777540206909e-01
    z[5,1,3]  R1486     -1.4384835958480835e-01
    z[5,1,3]  R1487     -3.5192090272903442e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1392     -1
    z[5,1,4]  R1393     1
    z[5,1,4]  R1398     -0.407550185918808
    z[5,1,4]  R1399     1.0992280393838882e-01
    z[5,1,4]  R1400     -6.1532676219940186e-02
    z[5,1,4]  R1401     -5.0204541534185410e-02
    z[5,1,4]  R1402     -4.9264460802078247e-01
    z[5,1,4]  R1403     -2.8671622276306152e-01
    z[5,1,4]  R1404     2.6149597018957138e-02
    z[5,1,4]  R1405     7.3123171925544739e-02
    z[5,1,4]  R1406     4.4613435864448547e-02
    z[5,1,4]  R1407     -0.0691533163189888
    z[5,1,4]  R1408     0.07137431204319
    z[5,1,4]  R1409     2.4950174987316132e-01
    z[5,1,4]  R1410     1.0654534399509430e-01
    z[5,1,4]  R1411     -4.5509532094001770e-01
    z[5,1,4]  R1412     -3.6515191197395325e-01
    z[5,1,4]  R1413     -0.416479229927063
    z[5,1,4]  R1414     -4.0927022695541382e-01
    z[5,1,4]  R1415     -1.9846189022064209e-01
    z[5,1,4]  R1416     -1.9453060626983643e-01
    z[5,1,4]  R1417     3.6199086904525757e-01
    z[5,1,4]  R1418     6.9938585162162781e-02
    z[5,1,4]  R1419     -1.3595966994762421e-01
    z[5,1,4]  R1420     -1.5079443156719208e-01
    z[5,1,4]  R1421     -4.1097655892372131e-02
    z[5,1,4]  R1422     2.1752344444394112e-02
    z[5,1,4]  R1423     -1.8148691952228546e-01
    z[5,1,4]  R1424     1.0181655734777451e-01
    z[5,1,4]  R1425     6.8882554769515991e-01
    z[5,1,4]  R1426     4.0979516506195068e-01
    z[5,1,4]  R1427     0.576056957244873
    z[5,1,4]  R1428     2.0964258909225464e-01
    z[5,1,4]  R1429     3.7249827384948730e-01
    z[5,1,4]  R1430     -1.2518243491649628e-01
    z[5,1,4]  R1431     -2.4802911281585693e-01
    z[5,1,4]  R1432     7.4077457189559937e-02
    z[5,1,4]  R1433     1.6445495188236237e-01
    z[5,1,4]  R1434     -1.8125905096530914e-01
    z[5,1,4]  R1435     4.0912351012229919e-01
    z[5,1,4]  R1436     5.2063208818435669e-01
    z[5,1,4]  R1437     3.7820154428482056e-01
    z[5,1,4]  R1438     4.0455322712659836e-02
    z[5,1,4]  R1439     -1.0657750535756350e-03
    z[5,1,4]  R1440     -4.4077765941619873e-01
    z[5,1,4]  R1441     1.6311611235141754e-01
    z[5,1,4]  R1442     -3.8399747014045715e-01
    z[5,1,4]  R1443     -2.7723035216331482e-01
    z[5,1,4]  R1444     1.5596590936183929e-01
    z[5,1,4]  R1445     -5.1666635274887085e-01
    z[5,1,4]  R1446     -4.1069126129150391e-01
    z[5,1,4]  R1447     3.2260903716087341e-01
    z[5,1,4]  R1448     4.1462130844593048e-02
    z[5,1,4]  R1449     -1.7017647624015808e-01
    z[5,1,4]  R1450     5.4746586829423904e-02
    z[5,1,4]  R1451     -3.8583523035049438e-01
    z[5,1,4]  R1452     -2.4354654550552368e-01
    z[5,1,4]  R1453     3.6474749445915222e-01
    z[5,1,4]  R1454     -2.8474736213684082e-01
    z[5,1,4]  R1455     4.2725983262062073e-01
    z[5,1,4]  R1456     5.4021787643432617e-01
    z[5,1,4]  R1457     -4.9213051795959473e-01
    z[5,1,4]  R1458     -1.9522084295749664e-01
    z[5,1,4]  R1459     -5.5625919252634048e-02
    z[5,1,4]  R1460     -1.1468805372714996e-01
    z[5,1,4]  R1461     2.8277322649955750e-01
    z[5,1,4]  R1462     -4.1842761635780334e-01
    z[5,1,4]  R1463     -5.1813744008541107e-02
    z[5,1,4]  R1464     1.5262334048748016e-01
    z[5,1,4]  R1465     -3.9830081164836884e-02
    z[5,1,4]  R1466     -3.4797763824462891e-01
    z[5,1,4]  R1467     -1.8198819458484650e-01
    z[5,1,4]  R1468     5.0782209634780884e-01
    z[5,1,4]  R1469     5.0541943311691284e-01
    z[5,1,4]  R1470     7.0441913604736328e-01
    z[5,1,4]  R1471     1.5030542016029358e-01
    z[5,1,4]  R1472     1.8428441882133484e-01
    z[5,1,4]  R1473     0.532706618309021
    z[5,1,4]  R1474     4.6939682960510254e-01
    z[5,1,4]  R1475     -1.0630524903535843e-01
    z[5,1,4]  R1476     -1.1071750521659851e-01
    z[5,1,4]  R1477     -3.0283406376838684e-03
    z[5,1,4]  R1478     1.0974252223968506e-01
    z[5,1,4]  R1479     -1.2475372105836868e-01
    z[5,1,4]  R1480     2.1234643459320068e-01
    z[5,1,4]  R1481     1.4340290427207947e-01
    z[5,1,4]  R1482     4.1452908515930176e-01
    z[5,1,4]  R1483     -2.9557171463966370e-01
    z[5,1,4]  R1484     1.0928661562502384e-02
    z[5,1,4]  R1485     -3.0401936173439026e-01
    z[5,1,4]  R1486     1.9716110825538635e-01
    z[5,1,4]  R1487     4.9992737174034119e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1394     -1
    z[5,1,5]  R1395     1
    z[5,1,5]  R1398     -6.6448740661144257e-02
    z[5,1,5]  R1399     -2.0032858848571777e-01
    z[5,1,5]  R1400     -4.6768745779991150e-01
    z[5,1,5]  R1401     5.4006807506084442e-02
    z[5,1,5]  R1402     -3.8019725680351257e-01
    z[5,1,5]  R1403     -2.8030180931091309e-01
    z[5,1,5]  R1404     -0.13898965716362
    z[5,1,5]  R1405     4.4669758528470993e-02
    z[5,1,5]  R1406     1.2786471843719482e-01
    z[5,1,5]  R1407     -1.5990903973579407e-01
    z[5,1,5]  R1408     2.9171234369277954e-01
    z[5,1,5]  R1409     2.6608529686927795e-01
    z[5,1,5]  R1410     1.8212196230888367e-01
    z[5,1,5]  R1411     -3.5044002532958984e-01
    z[5,1,5]  R1412     3.0996114015579224e-01
    z[5,1,5]  R1413     1.8105560541152954e-01
    z[5,1,5]  R1414     7.2475492954254150e-02
    z[5,1,5]  R1415     3.5527545213699341e-01
    z[5,1,5]  R1416     2.4875281751155853e-01
    z[5,1,5]  R1417     3.3961758017539978e-01
    z[5,1,5]  R1418     1.3228674232959747e-01
    z[5,1,5]  R1419     2.4678136408329010e-01
    z[5,1,5]  R1420     2.2562603652477264e-01
    z[5,1,5]  R1421     7.9707249999046326e-02
    z[5,1,5]  R1422     -2.2326244413852692e-01
    z[5,1,5]  R1423     2.3951642215251923e-01
    z[5,1,5]  R1424     1.1684230715036392e-01
    z[5,1,5]  R1425     2.3714546859264374e-01
    z[5,1,5]  R1426     -1.2539631128311157e-01
    z[5,1,5]  R1427     3.4624379873275757e-01
    z[5,1,5]  R1428     -4.3736483901739120e-02
    z[5,1,5]  R1429     0.495735228061676
    z[5,1,5]  R1430     -2.8402847051620483e-01
    z[5,1,5]  R1431     -4.0881112217903137e-01
    z[5,1,5]  R1432     4.6252843737602234e-01
    z[5,1,5]  R1433     2.7142751216888428e-01
    z[5,1,5]  R1434     5.7872855663299561e-01
    z[5,1,5]  R1435     -3.0829516053199768e-01
    z[5,1,5]  R1436     -2.7387544512748718e-01
    z[5,1,5]  R1437     -1.7499661445617676e-01
    z[5,1,5]  R1438     -5.5390429496765137e-01
    z[5,1,5]  R1439     8.0321721732616425e-02
    z[5,1,5]  R1440     -3.3402532339096069e-01
    z[5,1,5]  R1441     -7.4996486306190491e-02
    z[5,1,5]  R1442     -2.1256893873214722e-01
    z[5,1,5]  R1443     -4.5390984416007996e-01
    z[5,1,5]  R1444     2.7678820490837097e-01
    z[5,1,5]  R1445     -5.7354439049959183e-02
    z[5,1,5]  R1446     1.0543572902679443e-01
    z[5,1,5]  R1447     2.4937982857227325e-01
    z[5,1,5]  R1448     1.0438472777605057e-01
    z[5,1,5]  R1449     3.7046140432357788e-01
    z[5,1,5]  R1450     1.9523890316486359e-01
    z[5,1,5]  R1451     -1.6952624917030334e-01
    z[5,1,5]  R1452     -1.2062735855579376e-01
    z[5,1,5]  R1453     -1.1992149800062180e-01
    z[5,1,5]  R1454     1.9417542219161987e-01
    z[5,1,5]  R1455     2.3745548725128174e-01
    z[5,1,5]  R1456     4.2656177282333374e-01
    z[5,1,5]  R1457     3.4880742430686951e-01
    z[5,1,5]  R1458     4.5144062489271164e-02
    z[5,1,5]  R1459     5.1510158926248550e-02
    z[5,1,5]  R1460     -3.9596560597419739e-01
    z[5,1,5]  R1461     -3.4057098627090454e-01
    z[5,1,5]  R1462     -6.3107395172119141e-01
    z[5,1,5]  R1463     -1.0247718542814255e-01
    z[5,1,5]  R1464     -3.4925499558448792e-01
    z[5,1,5]  R1465     4.0217429399490356e-01
    z[5,1,5]  R1466     -1.4051049947738647e-01
    z[5,1,5]  R1467     -2.4994817376136780e-01
    z[5,1,5]  R1468     -4.4802263379096985e-01
    z[5,1,5]  R1469     -2.0324413478374481e-01
    z[5,1,5]  R1470     -1.0597249493002892e-02
    z[5,1,5]  R1471     -3.6264079809188843e-01
    z[5,1,5]  R1472     4.3007194995880127e-01
    z[5,1,5]  R1473     3.4774327278137207e-01
    z[5,1,5]  R1474     5.7146232575178146e-02
    z[5,1,5]  R1475     5.0299829244613647e-01
    z[5,1,5]  R1476     3.9705076813697815e-01
    z[5,1,5]  R1477     -4.2692460119724274e-02
    z[5,1,5]  R1478     -5.0250776112079620e-02
    z[5,1,5]  R1479     1.9489030539989471e-01
    z[5,1,5]  R1480     4.0899339318275452e-01
    z[5,1,5]  R1481     1.7612640559673309e-01
    z[5,1,5]  R1482     2.3359447717666626e-01
    z[5,1,5]  R1483     4.1298249363899231e-01
    z[5,1,5]  R1484     2.2846752777695656e-02
    z[5,1,5]  R1485     2.2896414995193481e-01
    z[5,1,5]  R1486     0.241278275847435
    z[5,1,5]  R1487     2.1940311789512634e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1396     -1
    z[5,1,6]  R1397     1
    z[5,1,6]  R1398     1.2498059123754501e-01
    z[5,1,6]  R1399     4.2947977781295776e-01
    z[5,1,6]  R1400     -1.3333770632743835e-01
    z[5,1,6]  R1401     -4.9427023530006409e-01
    z[5,1,6]  R1402     1.4493362046778202e-02
    z[5,1,6]  R1403     -1.5661749243736267e-01
    z[5,1,6]  R1404     -5.1733326911926270e-01
    z[5,1,6]  R1405     -9.7482755780220032e-02
    z[5,1,6]  R1406     -3.5410153865814209e-01
    z[5,1,6]  R1407     -9.4195976853370667e-02
    z[5,1,6]  R1408     1.8198034167289734e-01
    z[5,1,6]  R1409     3.3990573883056641e-01
    z[5,1,6]  R1410     3.3872240781784058e-01
    z[5,1,6]  R1411     -3.4064075350761414e-01
    z[5,1,6]  R1412     -3.0538308620452881e-01
    z[5,1,6]  R1413     3.7478078156709671e-02
    z[5,1,6]  R1414     3.4675487875938416e-01
    z[5,1,6]  R1415     -1.0166209936141968e-01
    z[5,1,6]  R1416     -2.6171153783798218e-01
    z[5,1,6]  R1417     1.4266893267631531e-01
    z[5,1,6]  R1418     -5.8515619486570358e-02
    z[5,1,6]  R1419     1.2529952824115753e-01
    z[5,1,6]  R1420     -2.9958526138216257e-03
    z[5,1,6]  R1421     -4.2302541434764862e-02
    z[5,1,6]  R1422     3.5392352938652039e-01
    z[5,1,6]  R1423     -5.5908089876174927e-01
    z[5,1,6]  R1424     -5.4546225070953369e-01
    z[5,1,6]  R1425     1.0424774140119553e-01
    z[5,1,6]  R1426     6.5992519259452820e-02
    z[5,1,6]  R1427     1.5303359925746918e-01
    z[5,1,6]  R1428     2.1497702226042747e-02
    z[5,1,6]  R1429     -2.2102083265781403e-01
    z[5,1,6]  R1430     2.1728539466857910e-01
    z[5,1,6]  R1431     4.6085428446531296e-02
    z[5,1,6]  R1432     -2.3642720654606819e-02
    z[5,1,6]  R1433     1.0196760296821594e-01
    z[5,1,6]  R1434     -9.2297062277793884e-02
    z[5,1,6]  R1435     7.1000531315803528e-02
    z[5,1,6]  R1436     1.1236649006605148e-01
    z[5,1,6]  R1437     0.645663321018219
    z[5,1,6]  R1438     -2.7977797389030457e-01
    z[5,1,6]  R1439     3.2469874620437622e-01
    z[5,1,6]  R1440     -3.9274501800537109e-01
    z[5,1,6]  R1441     -8.7665893137454987e-02
    z[5,1,6]  R1442     -3.5648101568222046e-01
    z[5,1,6]  R1443     -4.0034556388854980e-01
    z[5,1,6]  R1444     -7.9675689339637756e-02
    z[5,1,6]  R1445     -2.2472733259201050e-01
    z[5,1,6]  R1446     -3.9812245965003967e-01
    z[5,1,6]  R1447     -1.7418856918811798e-01
    z[5,1,6]  R1448     4.7403600811958313e-01
    z[5,1,6]  R1449     4.1254632174968719e-02
    z[5,1,6]  R1450     6.2351156026124954e-02
    z[5,1,6]  R1451     4.0722902864217758e-02
    z[5,1,6]  R1452     -5.3125196695327759e-01
    z[5,1,6]  R1453     3.5758140683174133e-01
    z[5,1,6]  R1454     -5.9704118967056274e-01
    z[5,1,6]  R1455     -3.0509895086288452e-01
    z[5,1,6]  R1456     -2.7958011627197266e-01
    z[5,1,6]  R1457     -2.9956376552581787e-01
    z[5,1,6]  R1458     4.4508108496665955e-01
    z[5,1,6]  R1459     -4.6299800276756287e-01
    z[5,1,6]  R1460     -1.1209972202777863e-01
    z[5,1,6]  R1461     -3.7462544441223145e-01
    z[5,1,6]  R1462     -2.7219581604003906e-01
    z[5,1,6]  R1463     5.1093274354934692e-01
    z[5,1,6]  R1464     2.6656261086463928e-01
    z[5,1,6]  R1465     -1.5174549818038940e-01
    z[5,1,6]  R1466     -3.5464456677436829e-01
    z[5,1,6]  R1467     -5.2352637052536011e-01
    z[5,1,6]  R1468     -1.9029730930924416e-02
    z[5,1,6]  R1469     1.1859763413667679e-02
    z[5,1,6]  R1470     1.6963452100753784e-01
    z[5,1,6]  R1471     -4.3357063084840775e-02
    z[5,1,6]  R1472     1.4768348634243011e-01
    z[5,1,6]  R1473     3.8006898760795593e-01
    z[5,1,6]  R1474     -0.208759143948555
    z[5,1,6]  R1475     1.0208845883607864e-01
    z[5,1,6]  R1476     1.4676529169082642e-01
    z[5,1,6]  R1477     4.4861856102943420e-01
    z[5,1,6]  R1478     -3.4222227334976196e-01
    z[5,1,6]  R1479     1.1750672757625580e-01
    z[5,1,6]  R1480     1.0847406834363937e-01
    z[5,1,6]  R1481     -3.1713131070137024e-01
    z[5,1,6]  R1482     2.5246149301528931e-01
    z[5,1,6]  R1483     -1.7355036735534668e-01
    z[5,1,6]  R1484     -1.5159356594085693e-01
    z[5,1,6]  R1485     3.0916744470596313e-01
    z[5,1,6]  R1486     2.3593175411224365e-01
    z[5,1,6]  R1487     -1.3633179664611816e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1488     -1
    z[2,4,0]  R1489     1
    z[2,4,0]  R1502     2.0168526470661163e-01
    z[2,4,0]  R1503     7.4236601591110229e-01
    z[2,4,0]  R1504     6.3519030809402466e-01
    z[2,4,0]  R1505     8.2694751024246216e-01
    z[2,4,0]  R1506     0.732430636882782
    z[2,4,0]  R1507     6.9434732198715210e-01
    z[2,4,0]  R1508     5.0212305784225464e-01
    z[2,4,0]  R1509     5.2095401287078857e-01
    z[2,4,0]  R1510     5.2552109956741333e-01
    z[2,4,0]  R1511     0.565981388092041
    z[2,4,0]  R1512     -2.8693279623985291e-01
    z[2,4,0]  R1513     -2.2875705361366272e-01
    z[2,4,0]  R1514     -3.7252682447433472e-01
    z[2,4,0]  R1515     -3.4144580364227295e-02
    z[2,4,0]  R1516     -1.2130939960479736e-01
    z[2,4,0]  R1517     -0.24737648665905
    z[2,4,0]  R1518     -3.2693052291870117e-01
    z[2,4,0]  R1519     -7.0166802406311035e-01
    z[2,4,0]  R1520     -5.1734834909439087e-01
    z[2,4,0]  R1521     -6.8399560451507568e-01
    z[2,4,0]  R1522     2.5814792513847351e-01
    z[2,4,0]  R1523     2.5163169950246811e-02
    z[2,4,0]  R1524     -2.8755296953022480e-03
    z[2,4,0]  R1525     -9.6380099654197693e-02
    z[2,4,0]  R1526     5.5131424218416214e-02
    z[2,4,0]  R1527     -3.4453833103179932e-01
    z[2,4,0]  R1528     3.0919777229428291e-02
    z[2,4,0]  R1529     4.4574152678251266e-02
    z[2,4,0]  R1530     -2.1453756093978882e-01
    z[2,4,0]  R1531     -4.7364017367362976e-01
    z[2,4,0]  R1532     4.5386686921119690e-01
    z[2,4,0]  R1533     5.7206705212593079e-02
    z[2,4,0]  R1534     -2.5209262967109680e-01
    z[2,4,0]  R1535     1.3466119766235352e-02
    z[2,4,0]  R1536     -3.8344639539718628e-01
    z[2,4,0]  R1537     -1.2124659866094589e-01
    z[2,4,0]  R1538     -4.3595591187477112e-01
    z[2,4,0]  R1539     -3.0036526918411255e-01
    z[2,4,0]  R1540     1.9480532407760620e-01
    z[2,4,0]  R1541     -1.3827045261859894e-01
    z[2,4,0]  R1542     2.8657663613557816e-02
    z[2,4,0]  R1543     2.7474978566169739e-01
    z[2,4,0]  R1544     -5.2531582117080688e-01
    z[2,4,0]  R1545     -4.8632583022117615e-01
    z[2,4,0]  R1546     3.1036838889122009e-01
    z[2,4,0]  R1547     -5.6225264072418213e-01
    z[2,4,0]  R1548     9.9852740764617920e-02
    z[2,4,0]  R1549     7.0530459284782410e-02
    z[2,4,0]  R1550     -2.4579961597919464e-01
    z[2,4,0]  R1551     -5.8534210920333862e-01
    z[2,4,0]  R1552     -8.4715768694877625e-02
    z[2,4,0]  R1553     3.7786862254142761e-01
    z[2,4,0]  R1554     -1.0474388301372528e-01
    z[2,4,0]  R1555     -4.3095737695693970e-01
    z[2,4,0]  R1556     -5.7242126204073429e-03
    z[2,4,0]  R1557     -1.0527808219194412e-01
    z[2,4,0]  R1558     -1.3672526180744171e-01
    z[2,4,0]  R1559     -2.7547001838684082e-01
    z[2,4,0]  R1560     5.8763694763183594e-01
    z[2,4,0]  R1561     4.1692918539047241e-01
    z[2,4,0]  R1562     3.1882929615676403e-03
    z[2,4,0]  R1563     0.350115031003952
    z[2,4,0]  R1564     1.0460475832223892e-01
    z[2,4,0]  R1565     4.6982610225677490e-01
    z[2,4,0]  R1566     -2.1524028852581978e-02
    z[2,4,0]  R1567     4.8068743199110031e-02
    z[2,4,0]  R1568     -1.2982851266860962e-01
    z[2,4,0]  R1569     -5.4572790861129761e-02
    z[2,4,0]  R1570     9.8200999200344086e-02
    z[2,4,0]  R1571     -7.6632252894341946e-03
    z[2,4,0]  R1572     2.2449608147144318e-01
    z[2,4,0]  R1573     1.2216307967901230e-01
    z[2,4,0]  R1574     2.6040667295455933e-01
    z[2,4,0]  R1575     4.6720737218856812e-01
    z[2,4,0]  R1576     4.2385819554328918e-01
    z[2,4,0]  R1577     4.0700322389602661e-01
    z[2,4,0]  R1578     1.1096493899822235e-01
    z[2,4,0]  R1579     5.0646132230758667e-01
    z[2,4,0]  R1580     0.467808336019516
    z[2,4,0]  R1581     4.6968027949333191e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1490     -1
    z[2,4,1]  R1491     1
    z[2,4,1]  R1502     -8.1922346353530884e-01
    z[2,4,1]  R1503     4.4056215882301331e-01
    z[2,4,1]  R1504     5.2807974815368652e-01
    z[2,4,1]  R1505     4.5687785744667053e-01
    z[2,4,1]  R1506     4.2076438665390015e-01
    z[2,4,1]  R1507     4.7686314582824707e-01
    z[2,4,1]  R1508     5.5727756023406982e-01
    z[2,4,1]  R1509     0.628750741481781
    z[2,4,1]  R1510     0.564632773399353
    z[2,4,1]  R1511     5.0390481948852539e-01
    z[2,4,1]  R1512     9.3186748027801514e-01
    z[2,4,1]  R1513     8.1989574432373047e-01
    z[2,4,1]  R1514     6.3152486085891724e-01
    z[2,4,1]  R1515     0.871233344078064
    z[2,4,1]  R1516     6.4237689971923828e-01
    z[2,4,1]  R1517     5.5604827404022217e-01
    z[2,4,1]  R1518     0.612606406211853
    z[2,4,1]  R1519     2.4693058431148529e-01
    z[2,4,1]  R1520     1.0127270966768265e-01
    z[2,4,1]  R1521     4.4768798351287842e-01
    z[2,4,1]  R1522     0.767442524433136
    z[2,4,1]  R1523     -0.16782146692276
    z[2,4,1]  R1524     -0.505316972732544
    z[2,4,1]  R1525     -6.2347787618637085e-01
    z[2,4,1]  R1526     -5.5880290269851685e-01
    z[2,4,1]  R1527     -6.9875997304916382e-01
    z[2,4,1]  R1528     -5.7810330390930176e-01
    z[2,4,1]  R1529     6.2407189607620239e-01
    z[2,4,1]  R1530     -0.574478030204773
    z[2,4,1]  R1531     6.3457864522933960e-01
    z[2,4,1]  R1532     8.3791959285736084e-01
    z[2,4,1]  R1533     -7.3148196935653687e-01
    z[2,4,1]  R1534     -8.3641594648361206e-01
    z[2,4,1]  R1535     -5.9700292348861694e-01
    z[2,4,1]  R1536     -7.0138669013977051e-01
    z[2,4,1]  R1537     -0.52411288022995
    z[2,4,1]  R1538     -5.8007371425628662e-01
    z[2,4,1]  R1539     -5.7386624813079834e-01
    z[2,4,1]  R1540     -7.1420305967330933e-01
    z[2,4,1]  R1541     -0.469468891620636
    z[2,4,1]  R1542     -6.7077857255935669e-01
    z[2,4,1]  R1543     4.9553334712982178e-01
    z[2,4,1]  R1544     6.4749163389205933e-01
    z[2,4,1]  R1545     7.4309313297271729e-01
    z[2,4,1]  R1546     -6.7778146266937256e-01
    z[2,4,1]  R1547     -1.6208501160144806e-01
    z[2,4,1]  R1548     3.5068961977958679e-01
    z[2,4,1]  R1549     -4.7770828008651733e-01
    z[2,4,1]  R1550     5.9483128786087036e-01
    z[2,4,1]  R1551     4.7563686966896057e-01
    z[2,4,1]  R1552     -7.2566747665405273e-01
    z[2,4,1]  R1553     -0.601925790309906
    z[2,4,1]  R1554     -4.3660253286361694e-01
    z[2,4,1]  R1555     -0.560893714427948
    z[2,4,1]  R1556     -7.1033054590225220e-01
    z[2,4,1]  R1557     -5.6445884704589844e-01
    z[2,4,1]  R1558     -5.5630582571029663e-01
    z[2,4,1]  R1559     -7.3707896471023560e-01
    z[2,4,1]  R1560     6.5864127874374390e-01
    z[2,4,1]  R1561     -6.6119700670242310e-02
    z[2,4,1]  R1562     8.3957237005233765e-01
    z[2,4,1]  R1563     7.5983101129531860e-01
    z[2,4,1]  R1564     8.9190721511840820e-01
    z[2,4,1]  R1565     0.68828946352005
    z[2,4,1]  R1566     8.4670531749725342e-01
    z[2,4,1]  R1567     8.4243708848953247e-01
    z[2,4,1]  R1568     7.9136216640472412e-01
    z[2,4,1]  R1569     7.4902480840682983e-01
    z[2,4,1]  R1570     8.6116957664489746e-01
    z[2,4,1]  R1571     8.7653368711471558e-01
    z[2,4,1]  R1572     8.3442175388336182e-01
    z[2,4,1]  R1573     8.3425015211105347e-01
    z[2,4,1]  R1574     8.9899486303329468e-01
    z[2,4,1]  R1575     5.9249097108840942e-01
    z[2,4,1]  R1576     5.9265911579132080e-01
    z[2,4,1]  R1577     -6.9072662154212594e-04
    z[2,4,1]  R1578     3.1029152870178223e-01
    z[2,4,1]  R1579     1.9548442959785461e-01
    z[2,4,1]  R1580     5.6558477878570557e-01
    z[2,4,1]  R1581     6.0634356737136841e-01
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1492     -1
    z[2,4,2]  R1493     1
    z[2,4,2]  R1502     -7.8870102763175964e-02
    z[2,4,2]  R1503     3.3070746064186096e-01
    z[2,4,2]  R1504     1.0235553234815598e-01
    z[2,4,2]  R1505     4.6049594879150391e-02
    z[2,4,2]  R1506     1.6168086230754852e-01
    z[2,4,2]  R1507     6.3644699752330780e-02
    z[2,4,2]  R1508     5.4390218108892441e-02
    z[2,4,2]  R1509     -1.9460545480251312e-01
    z[2,4,2]  R1510     -8.8420659303665161e-02
    z[2,4,2]  R1511     1.1523006111383438e-01
    z[2,4,2]  R1512     -7.1286588907241821e-02
    z[2,4,2]  R1513     5.5369723588228226e-02
    z[2,4,2]  R1514     -4.8150178790092468e-01
    z[2,4,2]  R1515     -6.6612720489501953e-02
    z[2,4,2]  R1516     -6.5477684140205383e-02
    z[2,4,2]  R1517     1.3341930508613586e-01
    z[2,4,2]  R1518     -0.0082245459780097
    z[2,4,2]  R1519     -2.3293124139308929e-01
    z[2,4,2]  R1520     -2.2015622258186340e-01
    z[2,4,2]  R1521     -1.5303435921669006e-01
    z[2,4,2]  R1522     1.9586192071437836e-01
    z[2,4,2]  R1523     7.5157051905989647e-03
    z[2,4,2]  R1524     3.2421614974737167e-02
    z[2,4,2]  R1525     -5.8069300651550293e-01
    z[2,4,2]  R1526     -1.3434453867375851e-02
    z[2,4,2]  R1527     5.5135834962129593e-02
    z[2,4,2]  R1528     -1.0406474769115448e-01
    z[2,4,2]  R1529     -2.2813172638416290e-01
    z[2,4,2]  R1530     1.0440982878208160e-01
    z[2,4,2]  R1531     3.7115357816219330e-02
    z[2,4,2]  R1532     4.1516300290822983e-02
    z[2,4,2]  R1533     2.5107404589653015e-01
    z[2,4,2]  R1534     -1.9405621290206909e-01
    z[2,4,2]  R1535     -5.8411568403244019e-01
    z[2,4,2]  R1536     4.2978670448064804e-02
    z[2,4,2]  R1537     9.5384582877159119e-02
    z[2,4,2]  R1538     -5.3315126895904541e-01
    z[2,4,2]  R1539     -0.0327596440911293
    z[2,4,2]  R1540     -1.1553891003131866e-01
    z[2,4,2]  R1541     -1.4035994186997414e-02
    z[2,4,2]  R1542     -1.4211086928844452e-01
    z[2,4,2]  R1543     0.749748706817627
    z[2,4,2]  R1544     -2.3999287188053131e-01
    z[2,4,2]  R1545     -2.7160859107971191e-01
    z[2,4,2]  R1546     2.1083752810955048e-01
    z[2,4,2]  R1547     -1.4375127851963043e-01
    z[2,4,2]  R1548     7.2836279869079590e-01
    z[2,4,2]  R1549     -7.1535813808441162e-01
    z[2,4,2]  R1550     -9.4469018280506134e-02
    z[2,4,2]  R1551     4.9765370786190033e-02
    z[2,4,2]  R1552     -3.8860204815864563e-01
    z[2,4,2]  R1553     -3.0724689364433289e-01
    z[2,4,2]  R1554     -1.4385642111301422e-01
    z[2,4,2]  R1555     4.1887059807777405e-02
    z[2,4,2]  R1556     -9.1320149600505829e-02
    z[2,4,2]  R1557     -4.9124547839164734e-01
    z[2,4,2]  R1558     1.5303640067577362e-01
    z[2,4,2]  R1559     -1.8345442414283752e-01
    z[2,4,2]  R1560     -2.6607409119606018e-01
    z[2,4,2]  R1561     -1.6967274248600006e-01
    z[2,4,2]  R1562     2.1964015066623688e-01
    z[2,4,2]  R1563     -5.4684713482856750e-02
    z[2,4,2]  R1564     -3.1715580821037292e-01
    z[2,4,2]  R1565     1.5045984089374542e-01
    z[2,4,2]  R1566     -3.3043643832206726e-01
    z[2,4,2]  R1567     5.8519367128610611e-02
    z[2,4,2]  R1568     1.5012061595916748e-01
    z[2,4,2]  R1569     9.6426717936992645e-02
    z[2,4,2]  R1570     -3.5265842080116272e-01
    z[2,4,2]  R1571     2.7463451027870178e-01
    z[2,4,2]  R1572     2.7208182215690613e-01
    z[2,4,2]  R1573     4.5037293434143066e-01
    z[2,4,2]  R1574     -1.3624326884746552e-01
    z[2,4,2]  R1575     4.6888992190361023e-01
    z[2,4,2]  R1576     6.5142136812210083e-01
    z[2,4,2]  R1577     -6.4343822002410889e-01
    z[2,4,2]  R1578     -6.2557244300842285e-01
    z[2,4,2]  R1579     -6.9579696655273438e-01
    z[2,4,2]  R1580     0.331856369972229
    z[2,4,2]  R1581     -2.7549099922180176e-01
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1494     -1
    z[2,4,3]  R1495     1
    z[2,4,3]  R1502     -3.8251541554927826e-02
    z[2,4,3]  R1503     -3.0787003040313721e-01
    z[2,4,3]  R1504     2.3503266274929047e-01
    z[2,4,3]  R1505     2.3451916873455048e-01
    z[2,4,3]  R1506     -1.1217866092920303e-01
    z[2,4,3]  R1507     0.0248641986399889
    z[2,4,3]  R1508     1.1310722678899765e-01
    z[2,4,3]  R1509     -1.2516199052333832e-01
    z[2,4,3]  R1510     7.1494663134217262e-03
    z[2,4,3]  R1511     2.7653848752379417e-02
    z[2,4,3]  R1512     -4.1430920362472534e-02
    z[2,4,3]  R1513     -1.9567583501338959e-01
    z[2,4,3]  R1514     -2.8022894263267517e-01
    z[2,4,3]  R1515     -2.2264190018177032e-01
    z[2,4,3]  R1516     -6.3048821687698364e-01
    z[2,4,3]  R1517     -7.3469519615173340e-01
    z[2,4,3]  R1518     -0.543587863445282
    z[2,4,3]  R1519     -4.9522459506988525e-01
    z[2,4,3]  R1520     -5.8769422769546509e-01
    z[2,4,3]  R1521     -2.8840306401252747e-01
    z[2,4,3]  R1522     4.0296044945716858e-01
    z[2,4,3]  R1523     0.89235919713974
    z[2,4,3]  R1524     5.9119653701782227e-01
    z[2,4,3]  R1525     -4.9092669039964676e-02
    z[2,4,3]  R1526     3.3295041322708130e-01
    z[2,4,3]  R1527     -4.7149640321731567e-01
    z[2,4,3]  R1528     6.3730108737945557e-01
    z[2,4,3]  R1529     -4.3858282268047333e-02
    z[2,4,3]  R1530     2.3298986256122589e-01
    z[2,4,3]  R1531     4.6260673552751541e-02
    z[2,4,3]  R1532     1.3171857595443726e-01
    z[2,4,3]  R1533     1.4769986271858215e-01
    z[2,4,3]  R1534     -3.4857848286628723e-01
    z[2,4,3]  R1535     4.8908573389053345e-01
    z[2,4,3]  R1536     1.0993672162294388e-01
    z[2,4,3]  R1537     0.512146532535553
    z[2,4,3]  R1538     8.0749049782752991e-02
    z[2,4,3]  R1539     2.6764547824859619e-01
    z[2,4,3]  R1540     0.00896703451871872
    z[2,4,3]  R1541     7.1413886547088623e-01
    z[2,4,3]  R1542     2.2266833484172821e-01
    z[2,4,3]  R1543     1.3229785859584808e-01
    z[2,4,3]  R1544     -4.2385622859001160e-01
    z[2,4,3]  R1545     -1.5113075077533722e-01
    z[2,4,3]  R1546     -1.3371877372264862e-01
    z[2,4,3]  R1547     -0.685263454914093
    z[2,4,3]  R1548     2.9402244091033936e-01
    z[2,4,3]  R1549     -0.0520898774266243
    z[2,4,3]  R1550     -0.322995126247406
    z[2,4,3]  R1551     -4.4619762897491455e-01
    z[2,4,3]  R1552     4.4498276710510254e-01
    z[2,4,3]  R1553     4.5564872026443481e-01
    z[2,4,3]  R1554     8.5733026266098022e-01
    z[2,4,3]  R1555     3.7388020753860474e-01
    z[2,4,3]  R1556     -7.4222773313522339e-02
    z[2,4,3]  R1557     -1.0788592696189880e-01
    z[2,4,3]  R1558     4.6664497256278992e-01
    z[2,4,3]  R1559     -5.1120144128799438e-01
    z[2,4,3]  R1560     -7.2239659726619720e-02
    z[2,4,3]  R1561     -7.7155923843383789e-01
    z[2,4,3]  R1562     -0.384640634059906
    z[2,4,3]  R1563     -4.2843019962310791e-01
    z[2,4,3]  R1564     1.0900925099849701e-01
    z[2,4,3]  R1565     -1.8710485100746155e-01
    z[2,4,3]  R1566     1.6624949872493744e-01
    z[2,4,3]  R1567     2.1511860191822052e-01
    z[2,4,3]  R1568     -4.8466023802757263e-01
    z[2,4,3]  R1569     -3.9303550124168396e-01
    z[2,4,3]  R1570     -1.1065232008695602e-01
    z[2,4,3]  R1571     1.2822882831096649e-01
    z[2,4,3]  R1572     -9.2328958213329315e-02
    z[2,4,3]  R1573     6.3312657177448273e-02
    z[2,4,3]  R1574     -2.7496090531349182e-01
    z[2,4,3]  R1575     -8.1231839954853058e-02
    z[2,4,3]  R1576     -1.8128865957260132e-01
    z[2,4,3]  R1577     -0.535149097442627
    z[2,4,3]  R1578     -6.9514250755310059e-01
    z[2,4,3]  R1579     -3.4890174865722656e-01
    z[2,4,3]  R1580     2.6794403791427612e-01
    z[2,4,3]  R1581     4.0192779898643494e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1496     -1
    z[2,4,4]  R1497     1
    z[2,4,4]  R1502     7.3111318051815033e-02
    z[2,4,4]  R1503     -1.1375582218170166e-01
    z[2,4,4]  R1504     -8.2537800073623657e-02
    z[2,4,4]  R1505     -1.7899218201637268e-01
    z[2,4,4]  R1506     8.0192521214485168e-02
    z[2,4,4]  R1507     -3.0449113249778748e-01
    z[2,4,4]  R1508     -1.2869222462177277e-01
    z[2,4,4]  R1509     -4.6238997578620911e-01
    z[2,4,4]  R1510     -4.5858058333396912e-01
    z[2,4,4]  R1511     0.305789053440094
    z[2,4,4]  R1512     -0.0898180678486824
    z[2,4,4]  R1513     -3.7596827745437622e-01
    z[2,4,4]  R1514     -3.4587970376014709e-01
    z[2,4,4]  R1515     -4.2784112691879272e-01
    z[2,4,4]  R1516     -1.5457729995250702e-01
    z[2,4,4]  R1517     -2.0413650572299957e-01
    z[2,4,4]  R1518     -0.0776323527097702
    z[2,4,4]  R1519     1.2053133547306061e-01
    z[2,4,4]  R1520     -2.6265475153923035e-01
    z[2,4,4]  R1521     2.7353662252426147e-01
    z[2,4,4]  R1522     -2.8498631715774536e-01
    z[2,4,4]  R1523     4.1087669134140015e-01
    z[2,4,4]  R1524     -2.8536498546600342e-01
    z[2,4,4]  R1525     -2.8570872545242310e-01
    z[2,4,4]  R1526     -4.2396214604377747e-01
    z[2,4,4]  R1527     -9.6188765019178391e-03
    z[2,4,4]  R1528     3.5438543558120728e-01
    z[2,4,4]  R1529     -2.7970872819423676e-02
    z[2,4,4]  R1530     5.9508824348449707e-01
    z[2,4,4]  R1531     5.2050441503524780e-01
    z[2,4,4]  R1532     2.5748616456985474e-01
    z[2,4,4]  R1533     -2.1077752113342285e-01
    z[2,4,4]  R1534     2.1719934046268463e-01
    z[2,4,4]  R1535     2.3210911080241203e-02
    z[2,4,4]  R1536     2.5619903206825256e-01
    z[2,4,4]  R1537     -2.3334741592407227e-01
    z[2,4,4]  R1538     3.4386062622070312e-01
    z[2,4,4]  R1539     2.8850868344306946e-01
    z[2,4,4]  R1540     2.9008671641349792e-01
    z[2,4,4]  R1541     2.1807883679866791e-01
    z[2,4,4]  R1542     3.7299329042434692e-01
    z[2,4,4]  R1543     3.3229142427444458e-02
    z[2,4,4]  R1544     0.216078981757164
    z[2,4,4]  R1545     2.6762318611145020e-01
    z[2,4,4]  R1546     -1.2383381277322769e-01
    z[2,4,4]  R1547     -7.6574023114517331e-04
    z[2,4,4]  R1548     3.4473296999931335e-01
    z[2,4,4]  R1549     -4.5324954390525818e-01
    z[2,4,4]  R1550     -9.6704736351966858e-03
    z[2,4,4]  R1551     1.6221849620342255e-01
    z[2,4,4]  R1552     -1.1761056631803513e-01
    z[2,4,4]  R1553     -4.3422105908393860e-01
    z[2,4,4]  R1554     3.9987348020076752e-02
    z[2,4,4]  R1555     2.0577311515808105e-01
    z[2,4,4]  R1556     -2.2969231009483337e-01
    z[2,4,4]  R1557     -2.3001711070537567e-01
    z[2,4,4]  R1558     -0.0957801342010498
    z[2,4,4]  R1559     -1.7863722145557404e-01
    z[2,4,4]  R1560     -1.7013189196586609e-01
    z[2,4,4]  R1561     -3.6363226175308228e-01
    z[2,4,4]  R1562     1.7837880551815033e-01
    z[2,4,4]  R1563     -3.1958669424057007e-03
    z[2,4,4]  R1564     2.6500046253204346e-01
    z[2,4,4]  R1565     -1.3820233941078186e-01
    z[2,4,4]  R1566     3.3487355709075928e-01
    z[2,4,4]  R1567     3.1450507044792175e-01
    z[2,4,4]  R1568     3.0866429209709167e-01
    z[2,4,4]  R1569     2.1685311198234558e-01
    z[2,4,4]  R1570     1.8871790170669556e-01
    z[2,4,4]  R1571     3.6806982755661011e-01
    z[2,4,4]  R1572     1.0369108617305756e-01
    z[2,4,4]  R1573     2.3422354459762573e-01
    z[2,4,4]  R1574     8.7004482746124268e-02
    z[2,4,4]  R1575     -1.0074214637279510e-01
    z[2,4,4]  R1576     -9.0319961309432983e-02
    z[2,4,4]  R1577     2.9192152619361877e-01
    z[2,4,4]  R1578     1.2943156063556671e-01
    z[2,4,4]  R1579     1.4085660874843597e-01
    z[2,4,4]  R1580     -3.4676857292652130e-02
    z[2,4,4]  R1581     -8.8697835803031921e-02
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1498     -1
    z[2,4,5]  R1499     1
    z[2,4,5]  R1502     -2.0992338657379150e-01
    z[2,4,5]  R1503     6.0002353042364120e-02
    z[2,4,5]  R1504     2.1711468696594238e-01
    z[2,4,5]  R1505     2.1944953128695488e-02
    z[2,4,5]  R1506     -3.0375117063522339e-01
    z[2,4,5]  R1507     0.174501433968544
    z[2,4,5]  R1508     -4.4397312402725220e-01
    z[2,4,5]  R1509     -1.2243715673685074e-01
    z[2,4,5]  R1510     -4.3224963545799255e-01
    z[2,4,5]  R1511     1.7003849148750305e-01
    z[2,4,5]  R1512     -1.8312266469001770e-01
    z[2,4,5]  R1513     -4.2208548984490335e-04
    z[2,4,5]  R1514     -1.7857927083969116e-01
    z[2,4,5]  R1515     1.4842978678643703e-02
    z[2,4,5]  R1516     -6.8562075495719910e-02
    z[2,4,5]  R1517     -1.3925287127494812e-01
    z[2,4,5]  R1518     -3.6532059311866760e-01
    z[2,4,5]  R1519     -3.4194344282150269e-01
    z[2,4,5]  R1520     -5.0903332233428955e-01
    z[2,4,5]  R1521     -3.8409563899040222e-01
    z[2,4,5]  R1522     2.0312181115150452e-01
    z[2,4,5]  R1523     -2.6462316513061523e-02
    z[2,4,5]  R1524     -1.6600729897618294e-02
    z[2,4,5]  R1525     2.4125227332115173e-01
    z[2,4,5]  R1526     4.7427029348909855e-03
    z[2,4,5]  R1527     -1.4630095660686493e-01
    z[2,4,5]  R1528     1.6965536773204803e-01
    z[2,4,5]  R1529     6.9013011455535889e-01
    z[2,4,5]  R1530     1.9435566663742065e-01
    z[2,4,5]  R1531     1.5157592296600342e-01
    z[2,4,5]  R1532     7.7136784791946411e-02
    z[2,4,5]  R1533     -5.7041305303573608e-01
    z[2,4,5]  R1534     4.2971007525920868e-02
    z[2,4,5]  R1535     2.3333853483200073e-01
    z[2,4,5]  R1536     -4.1894045472145081e-01
    z[2,4,5]  R1537     3.3118382096290588e-01
    z[2,4,5]  R1538     -2.5302490592002869e-01
    z[2,4,5]  R1539     1.1748849600553513e-01
    z[2,4,5]  R1540     5.8008664846420288e-01
    z[2,4,5]  R1541     -2.6482850313186646e-01
    z[2,4,5]  R1542     3.0217874050140381e-01
    z[2,4,5]  R1543     2.3517285287380219e-01
    z[2,4,5]  R1544     -1.0395722091197968e-01
    z[2,4,5]  R1545     0.1573476344347
    z[2,4,5]  R1546     4.9449086189270020e-01
    z[2,4,5]  R1547     -4.0731698274612427e-01
    z[2,4,5]  R1548     -3.3146545290946960e-01
    z[2,4,5]  R1549     -9.0212017297744751e-02
    z[2,4,5]  R1550     5.5188196897506714e-01
    z[2,4,5]  R1551     8.6244657635688782e-02
    z[2,4,5]  R1552     5.6471548974514008e-02
    z[2,4,5]  R1553     -0.00575606245547533
    z[2,4,5]  R1554     1.4192521572113037e-01
    z[2,4,5]  R1555     -1.6009394824504852e-01
    z[2,4,5]  R1556     -2.8100606799125671e-01
    z[2,4,5]  R1557     9.9084721878170967e-03
    z[2,4,5]  R1558     -3.1752511858940125e-01
    z[2,4,5]  R1559     -2.3209697008132935e-01
    z[2,4,5]  R1560     -1.2765762209892273e-01
    z[2,4,5]  R1561     1.9370566308498383e-01
    z[2,4,5]  R1562     -1.9008180499076843e-01
    z[2,4,5]  R1563     1.2980645895004272e-01
    z[2,4,5]  R1564     -7.0155955851078033e-02
    z[2,4,5]  R1565     1.7229683697223663e-01
    z[2,4,5]  R1566     1.2577322125434875e-01
    z[2,4,5]  R1567     3.3563748002052307e-01
    z[2,4,5]  R1568     4.6237561851739883e-02
    z[2,4,5]  R1569     1.3555921614170074e-01
    z[2,4,5]  R1570     -2.0125040411949158e-01
    z[2,4,5]  R1571     4.8644743859767914e-02
    z[2,4,5]  R1572     -7.7171243727207184e-02
    z[2,4,5]  R1573     -4.4923387467861176e-03
    z[2,4,5]  R1574     6.1700176447629929e-02
    z[2,4,5]  R1575     -3.7547716498374939e-01
    z[2,4,5]  R1576     -0.0452738031744957
    z[2,4,5]  R1577     1.7261669039726257e-01
    z[2,4,5]  R1578     6.5440088510513306e-03
    z[2,4,5]  R1579     2.7864855527877808e-01
    z[2,4,5]  R1580     0.523865282535553
    z[2,4,5]  R1581     8.0336958169937134e-02
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1500     -1
    z[2,4,6]  R1501     1
    z[2,4,6]  R1502     4.8072773218154907e-01
    z[2,4,6]  R1503     1.8467712402343750e-01
    z[2,4,6]  R1504     4.4496819376945496e-01
    z[2,4,6]  R1505     -1.3334497809410095e-01
    z[2,4,6]  R1506     -3.8611200451850891e-01
    z[2,4,6]  R1507     4.0329754352569580e-01
    z[2,4,6]  R1508     -4.5594829320907593e-01
    z[2,4,6]  R1509     -2.2571486234664917e-01
    z[2,4,6]  R1510     3.4922768827527761e-03
    z[2,4,6]  R1511     5.3784966468811035e-01
    z[2,4,6]  R1512     2.9884090647101402e-02
    z[2,4,6]  R1513     -3.0452278256416321e-01
    z[2,4,6]  R1514     2.2463712841272354e-02
    z[2,4,6]  R1515     5.0114914774894714e-02
    z[2,4,6]  R1516     3.7714502215385437e-01
    z[2,4,6]  R1517     1.0475924611091614e-01
    z[2,4,6]  R1518     2.8772982954978943e-01
    z[2,4,6]  R1519     -1.2541884183883667e-01
    z[2,4,6]  R1520     -1.1786801740527153e-02
    z[2,4,6]  R1521     -5.2705653011798859e-02
    z[2,4,6]  R1522     -1.4552329480648041e-01
    z[2,4,6]  R1523     -7.2948947548866272e-02
    z[2,4,6]  R1524     -5.5890363454818726e-01
    z[2,4,6]  R1525     -3.5005655884742737e-01
    z[2,4,6]  R1526     -6.2761205434799194e-01
    z[2,4,6]  R1527     -0.382338285446167
    z[2,4,6]  R1528     -3.0575555562973022e-01
    z[2,4,6]  R1529     -2.7842029929161072e-01
    z[2,4,6]  R1530     -4.0848350524902344e-01
    z[2,4,6]  R1531     -2.7487668395042419e-01
    z[2,4,6]  R1532     -2.3937320336699486e-02
    z[2,4,6]  R1533     -8.3725750446319580e-02
    z[2,4,6]  R1534     -1.6932488977909088e-01
    z[2,4,6]  R1535     8.9579321444034576e-02
    z[2,4,6]  R1536     -3.2548922300338745e-01
    z[2,4,6]  R1537     5.2447974681854248e-01
    z[2,4,6]  R1538     -2.0602095872163773e-02
    z[2,4,6]  R1539     -0.640866756439209
    z[2,4,6]  R1540     -1.3373306393623352e-01
    z[2,4,6]  R1541     -3.6413770914077759e-01
    z[2,4,6]  R1542     4.9902126193046570e-01
    z[2,4,6]  R1543     -2.0717842876911163e-01
    z[2,4,6]  R1544     0.100248783826828
    z[2,4,6]  R1545     -1.3530507683753967e-01
    z[2,4,6]  R1546     -3.4942036867141724e-01
    z[2,4,6]  R1547     -0.0379759818315506
    z[2,4,6]  R1548     1.4620022475719452e-01
    z[2,4,6]  R1549     1.9696770608425140e-01
    z[2,4,6]  R1550     -4.0968382358551025e-01
    z[2,4,6]  R1551     -4.4251814484596252e-01
    z[2,4,6]  R1552     3.1652396917343140e-01
    z[2,4,6]  R1553     -6.5598316490650177e-02
    z[2,4,6]  R1554     -1.4475968480110168e-01
    z[2,4,6]  R1555     5.3866535425186157e-01
    z[2,4,6]  R1556     5.9146124124526978e-01
    z[2,4,6]  R1557     -0.60360187292099
    z[2,4,6]  R1558     -5.6626528501510620e-01
    z[2,4,6]  R1559     0.00824635848402977
    z[2,4,6]  R1560     3.1562498211860657e-01
    z[2,4,6]  R1561     1.6719865798950195e-01
    z[2,4,6]  R1562     1.7597745358943939e-01
    z[2,4,6]  R1563     3.1092354655265808e-01
    z[2,4,6]  R1564     7.7080823481082916e-02
    z[2,4,6]  R1565     -4.4619336724281311e-01
    z[2,4,6]  R1566     -1.3356833159923553e-01
    z[2,4,6]  R1567     -1.6347070038318634e-01
    z[2,4,6]  R1568     -4.5246567577123642e-02
    z[2,4,6]  R1569     -4.5476046204566956e-01
    z[2,4,6]  R1570     -1.8977752327919006e-01
    z[2,4,6]  R1571     4.3836481869220734e-02
    z[2,4,6]  R1572     -3.9253199100494385e-01
    z[2,4,6]  R1573     -1.6546231508255005e-01
    z[2,4,6]  R1574     -1.3584578037261963e-01
    z[2,4,6]  R1575     2.3039807379245758e-01
    z[2,4,6]  R1576     -4.0946129709482193e-02
    z[2,4,6]  R1577     1.3760775327682495e-01
    z[2,4,6]  R1578     -6.8311393260955811e-03
    z[2,4,6]  R1579     -4.3948139995336533e-02
    z[2,4,6]  R1580     6.0904525220394135e-02
    z[2,4,6]  R1581     -3.9998155832290649e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1582     -1
    z[4,2,0]  R1583     1
    z[4,2,0]  R1596     -8.4715768694877625e-02
    z[4,2,0]  R1597     3.7786862254142761e-01
    z[4,2,0]  R1598     -1.0474388301372528e-01
    z[4,2,0]  R1599     -4.3095737695693970e-01
    z[4,2,0]  R1600     -5.7242126204073429e-03
    z[4,2,0]  R1601     -1.0527808219194412e-01
    z[4,2,0]  R1602     -1.3672526180744171e-01
    z[4,2,0]  R1603     -2.7547001838684082e-01
    z[4,2,0]  R1604     5.8763694763183594e-01
    z[4,2,0]  R1605     4.1692918539047241e-01
    z[4,2,0]  R1606     3.1882929615676403e-03
    z[4,2,0]  R1607     0.350115031003952
    z[4,2,0]  R1608     1.0460475832223892e-01
    z[4,2,0]  R1609     4.6982610225677490e-01
    z[4,2,0]  R1610     -2.1524028852581978e-02
    z[4,2,0]  R1611     4.8068743199110031e-02
    z[4,2,0]  R1612     -1.2982851266860962e-01
    z[4,2,0]  R1613     -5.4572790861129761e-02
    z[4,2,0]  R1614     9.8200999200344086e-02
    z[4,2,0]  R1615     -7.6632252894341946e-03
    z[4,2,0]  R1616     2.2449608147144318e-01
    z[4,2,0]  R1617     1.2216307967901230e-01
    z[4,2,0]  R1618     2.6040667295455933e-01
    z[4,2,0]  R1619     4.6720737218856812e-01
    z[4,2,0]  R1620     4.2385819554328918e-01
    z[4,2,0]  R1621     4.0700322389602661e-01
    z[4,2,0]  R1622     1.1096493899822235e-01
    z[4,2,0]  R1623     5.0646132230758667e-01
    z[4,2,0]  R1624     0.467808336019516
    z[4,2,0]  R1625     4.6968027949333191e-01
    z[4,2,0]  R1626     2.0168526470661163e-01
    z[4,2,0]  R1627     7.4236601591110229e-01
    z[4,2,0]  R1628     6.3519030809402466e-01
    z[4,2,0]  R1629     8.2694751024246216e-01
    z[4,2,0]  R1630     0.732430636882782
    z[4,2,0]  R1631     6.9434732198715210e-01
    z[4,2,0]  R1632     5.0212305784225464e-01
    z[4,2,0]  R1633     5.2095401287078857e-01
    z[4,2,0]  R1634     5.2552109956741333e-01
    z[4,2,0]  R1635     0.565981388092041
    z[4,2,0]  R1636     -2.8693279623985291e-01
    z[4,2,0]  R1637     -2.2875705361366272e-01
    z[4,2,0]  R1638     -3.7252682447433472e-01
    z[4,2,0]  R1639     -3.4144580364227295e-02
    z[4,2,0]  R1640     -1.2130939960479736e-01
    z[4,2,0]  R1641     -0.24737648665905
    z[4,2,0]  R1642     -3.2693052291870117e-01
    z[4,2,0]  R1643     -7.0166802406311035e-01
    z[4,2,0]  R1644     -5.1734834909439087e-01
    z[4,2,0]  R1645     -6.8399560451507568e-01
    z[4,2,0]  R1646     2.5814792513847351e-01
    z[4,2,0]  R1647     2.5163169950246811e-02
    z[4,2,0]  R1648     -2.8755296953022480e-03
    z[4,2,0]  R1649     -9.6380099654197693e-02
    z[4,2,0]  R1650     5.5131424218416214e-02
    z[4,2,0]  R1651     -3.4453833103179932e-01
    z[4,2,0]  R1652     3.0919777229428291e-02
    z[4,2,0]  R1653     4.4574152678251266e-02
    z[4,2,0]  R1654     -2.1453756093978882e-01
    z[4,2,0]  R1655     -4.7364017367362976e-01
    z[4,2,0]  R1656     4.5386686921119690e-01
    z[4,2,0]  R1657     5.7206705212593079e-02
    z[4,2,0]  R1658     -2.5209262967109680e-01
    z[4,2,0]  R1659     1.3466119766235352e-02
    z[4,2,0]  R1660     -3.8344639539718628e-01
    z[4,2,0]  R1661     -1.2124659866094589e-01
    z[4,2,0]  R1662     -4.3595591187477112e-01
    z[4,2,0]  R1663     -3.0036526918411255e-01
    z[4,2,0]  R1664     1.9480532407760620e-01
    z[4,2,0]  R1665     -1.3827045261859894e-01
    z[4,2,0]  R1666     2.8657663613557816e-02
    z[4,2,0]  R1667     2.7474978566169739e-01
    z[4,2,0]  R1668     -5.2531582117080688e-01
    z[4,2,0]  R1669     -4.8632583022117615e-01
    z[4,2,0]  R1670     3.1036838889122009e-01
    z[4,2,0]  R1671     -5.6225264072418213e-01
    z[4,2,0]  R1672     9.9852740764617920e-02
    z[4,2,0]  R1673     7.0530459284782410e-02
    z[4,2,0]  R1674     -2.4579961597919464e-01
    z[4,2,0]  R1675     -5.8534210920333862e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1584     -1
    z[4,2,1]  R1585     1
    z[4,2,1]  R1596     -7.2566747665405273e-01
    z[4,2,1]  R1597     -0.601925790309906
    z[4,2,1]  R1598     -4.3660253286361694e-01
    z[4,2,1]  R1599     -0.560893714427948
    z[4,2,1]  R1600     -7.1033054590225220e-01
    z[4,2,1]  R1601     -5.6445884704589844e-01
    z[4,2,1]  R1602     -5.5630582571029663e-01
    z[4,2,1]  R1603     -7.3707896471023560e-01
    z[4,2,1]  R1604     6.5864127874374390e-01
    z[4,2,1]  R1605     -6.6119700670242310e-02
    z[4,2,1]  R1606     8.3957237005233765e-01
    z[4,2,1]  R1607     7.5983101129531860e-01
    z[4,2,1]  R1608     8.9190721511840820e-01
    z[4,2,1]  R1609     0.68828946352005
    z[4,2,1]  R1610     8.4670531749725342e-01
    z[4,2,1]  R1611     8.4243708848953247e-01
    z[4,2,1]  R1612     7.9136216640472412e-01
    z[4,2,1]  R1613     7.4902480840682983e-01
    z[4,2,1]  R1614     8.6116957664489746e-01
    z[4,2,1]  R1615     8.7653368711471558e-01
    z[4,2,1]  R1616     8.3442175388336182e-01
    z[4,2,1]  R1617     8.3425015211105347e-01
    z[4,2,1]  R1618     8.9899486303329468e-01
    z[4,2,1]  R1619     5.9249097108840942e-01
    z[4,2,1]  R1620     5.9265911579132080e-01
    z[4,2,1]  R1621     -6.9072662154212594e-04
    z[4,2,1]  R1622     3.1029152870178223e-01
    z[4,2,1]  R1623     1.9548442959785461e-01
    z[4,2,1]  R1624     5.6558477878570557e-01
    z[4,2,1]  R1625     6.0634356737136841e-01
    z[4,2,1]  R1626     -8.1922346353530884e-01
    z[4,2,1]  R1627     4.4056215882301331e-01
    z[4,2,1]  R1628     5.2807974815368652e-01
    z[4,2,1]  R1629     4.5687785744667053e-01
    z[4,2,1]  R1630     4.2076438665390015e-01
    z[4,2,1]  R1631     4.7686314582824707e-01
    z[4,2,1]  R1632     5.5727756023406982e-01
    z[4,2,1]  R1633     0.628750741481781
    z[4,2,1]  R1634     0.564632773399353
    z[4,2,1]  R1635     5.0390481948852539e-01
    z[4,2,1]  R1636     9.3186748027801514e-01
    z[4,2,1]  R1637     8.1989574432373047e-01
    z[4,2,1]  R1638     6.3152486085891724e-01
    z[4,2,1]  R1639     0.871233344078064
    z[4,2,1]  R1640     6.4237689971923828e-01
    z[4,2,1]  R1641     5.5604827404022217e-01
    z[4,2,1]  R1642     0.612606406211853
    z[4,2,1]  R1643     2.4693058431148529e-01
    z[4,2,1]  R1644     1.0127270966768265e-01
    z[4,2,1]  R1645     4.4768798351287842e-01
    z[4,2,1]  R1646     0.767442524433136
    z[4,2,1]  R1647     -0.16782146692276
    z[4,2,1]  R1648     -0.505316972732544
    z[4,2,1]  R1649     -6.2347787618637085e-01
    z[4,2,1]  R1650     -5.5880290269851685e-01
    z[4,2,1]  R1651     -6.9875997304916382e-01
    z[4,2,1]  R1652     -5.7810330390930176e-01
    z[4,2,1]  R1653     6.2407189607620239e-01
    z[4,2,1]  R1654     -0.574478030204773
    z[4,2,1]  R1655     6.3457864522933960e-01
    z[4,2,1]  R1656     8.3791959285736084e-01
    z[4,2,1]  R1657     -7.3148196935653687e-01
    z[4,2,1]  R1658     -8.3641594648361206e-01
    z[4,2,1]  R1659     -5.9700292348861694e-01
    z[4,2,1]  R1660     -7.0138669013977051e-01
    z[4,2,1]  R1661     -0.52411288022995
    z[4,2,1]  R1662     -5.8007371425628662e-01
    z[4,2,1]  R1663     -5.7386624813079834e-01
    z[4,2,1]  R1664     -7.1420305967330933e-01
    z[4,2,1]  R1665     -0.469468891620636
    z[4,2,1]  R1666     -6.7077857255935669e-01
    z[4,2,1]  R1667     4.9553334712982178e-01
    z[4,2,1]  R1668     6.4749163389205933e-01
    z[4,2,1]  R1669     7.4309313297271729e-01
    z[4,2,1]  R1670     -6.7778146266937256e-01
    z[4,2,1]  R1671     -1.6208501160144806e-01
    z[4,2,1]  R1672     3.5068961977958679e-01
    z[4,2,1]  R1673     -4.7770828008651733e-01
    z[4,2,1]  R1674     5.9483128786087036e-01
    z[4,2,1]  R1675     4.7563686966896057e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1586     -1
    z[4,2,2]  R1587     1
    z[4,2,2]  R1596     -3.8860204815864563e-01
    z[4,2,2]  R1597     -3.0724689364433289e-01
    z[4,2,2]  R1598     -1.4385642111301422e-01
    z[4,2,2]  R1599     4.1887059807777405e-02
    z[4,2,2]  R1600     -9.1320149600505829e-02
    z[4,2,2]  R1601     -4.9124547839164734e-01
    z[4,2,2]  R1602     1.5303640067577362e-01
    z[4,2,2]  R1603     -1.8345442414283752e-01
    z[4,2,2]  R1604     -2.6607409119606018e-01
    z[4,2,2]  R1605     -1.6967274248600006e-01
    z[4,2,2]  R1606     2.1964015066623688e-01
    z[4,2,2]  R1607     -5.4684713482856750e-02
    z[4,2,2]  R1608     -3.1715580821037292e-01
    z[4,2,2]  R1609     1.5045984089374542e-01
    z[4,2,2]  R1610     -3.3043643832206726e-01
    z[4,2,2]  R1611     5.8519367128610611e-02
    z[4,2,2]  R1612     1.5012061595916748e-01
    z[4,2,2]  R1613     9.6426717936992645e-02
    z[4,2,2]  R1614     -3.5265842080116272e-01
    z[4,2,2]  R1615     2.7463451027870178e-01
    z[4,2,2]  R1616     2.7208182215690613e-01
    z[4,2,2]  R1617     4.5037293434143066e-01
    z[4,2,2]  R1618     -1.3624326884746552e-01
    z[4,2,2]  R1619     4.6888992190361023e-01
    z[4,2,2]  R1620     6.5142136812210083e-01
    z[4,2,2]  R1621     -6.4343822002410889e-01
    z[4,2,2]  R1622     -6.2557244300842285e-01
    z[4,2,2]  R1623     -6.9579696655273438e-01
    z[4,2,2]  R1624     0.331856369972229
    z[4,2,2]  R1625     -2.7549099922180176e-01
    z[4,2,2]  R1626     -7.8870102763175964e-02
    z[4,2,2]  R1627     3.3070746064186096e-01
    z[4,2,2]  R1628     1.0235553234815598e-01
    z[4,2,2]  R1629     4.6049594879150391e-02
    z[4,2,2]  R1630     1.6168086230754852e-01
    z[4,2,2]  R1631     6.3644699752330780e-02
    z[4,2,2]  R1632     5.4390218108892441e-02
    z[4,2,2]  R1633     -1.9460545480251312e-01
    z[4,2,2]  R1634     -8.8420659303665161e-02
    z[4,2,2]  R1635     1.1523006111383438e-01
    z[4,2,2]  R1636     -7.1286588907241821e-02
    z[4,2,2]  R1637     5.5369723588228226e-02
    z[4,2,2]  R1638     -4.8150178790092468e-01
    z[4,2,2]  R1639     -6.6612720489501953e-02
    z[4,2,2]  R1640     -6.5477684140205383e-02
    z[4,2,2]  R1641     1.3341930508613586e-01
    z[4,2,2]  R1642     -0.0082245459780097
    z[4,2,2]  R1643     -2.3293124139308929e-01
    z[4,2,2]  R1644     -2.2015622258186340e-01
    z[4,2,2]  R1645     -1.5303435921669006e-01
    z[4,2,2]  R1646     1.9586192071437836e-01
    z[4,2,2]  R1647     7.5157051905989647e-03
    z[4,2,2]  R1648     3.2421614974737167e-02
    z[4,2,2]  R1649     -5.8069300651550293e-01
    z[4,2,2]  R1650     -1.3434453867375851e-02
    z[4,2,2]  R1651     5.5135834962129593e-02
    z[4,2,2]  R1652     -1.0406474769115448e-01
    z[4,2,2]  R1653     -2.2813172638416290e-01
    z[4,2,2]  R1654     1.0440982878208160e-01
    z[4,2,2]  R1655     3.7115357816219330e-02
    z[4,2,2]  R1656     4.1516300290822983e-02
    z[4,2,2]  R1657     2.5107404589653015e-01
    z[4,2,2]  R1658     -1.9405621290206909e-01
    z[4,2,2]  R1659     -5.8411568403244019e-01
    z[4,2,2]  R1660     4.2978670448064804e-02
    z[4,2,2]  R1661     9.5384582877159119e-02
    z[4,2,2]  R1662     -5.3315126895904541e-01
    z[4,2,2]  R1663     -0.0327596440911293
    z[4,2,2]  R1664     -1.1553891003131866e-01
    z[4,2,2]  R1665     -1.4035994186997414e-02
    z[4,2,2]  R1666     -1.4211086928844452e-01
    z[4,2,2]  R1667     0.749748706817627
    z[4,2,2]  R1668     -2.3999287188053131e-01
    z[4,2,2]  R1669     -2.7160859107971191e-01
    z[4,2,2]  R1670     2.1083752810955048e-01
    z[4,2,2]  R1671     -1.4375127851963043e-01
    z[4,2,2]  R1672     7.2836279869079590e-01
    z[4,2,2]  R1673     -7.1535813808441162e-01
    z[4,2,2]  R1674     -9.4469018280506134e-02
    z[4,2,2]  R1675     4.9765370786190033e-02
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1588     -1
    z[4,2,3]  R1589     1
    z[4,2,3]  R1596     4.4498276710510254e-01
    z[4,2,3]  R1597     4.5564872026443481e-01
    z[4,2,3]  R1598     8.5733026266098022e-01
    z[4,2,3]  R1599     3.7388020753860474e-01
    z[4,2,3]  R1600     -7.4222773313522339e-02
    z[4,2,3]  R1601     -1.0788592696189880e-01
    z[4,2,3]  R1602     4.6664497256278992e-01
    z[4,2,3]  R1603     -5.1120144128799438e-01
    z[4,2,3]  R1604     -7.2239659726619720e-02
    z[4,2,3]  R1605     -7.7155923843383789e-01
    z[4,2,3]  R1606     -0.384640634059906
    z[4,2,3]  R1607     -4.2843019962310791e-01
    z[4,2,3]  R1608     1.0900925099849701e-01
    z[4,2,3]  R1609     -1.8710485100746155e-01
    z[4,2,3]  R1610     1.6624949872493744e-01
    z[4,2,3]  R1611     2.1511860191822052e-01
    z[4,2,3]  R1612     -4.8466023802757263e-01
    z[4,2,3]  R1613     -3.9303550124168396e-01
    z[4,2,3]  R1614     -1.1065232008695602e-01
    z[4,2,3]  R1615     1.2822882831096649e-01
    z[4,2,3]  R1616     -9.2328958213329315e-02
    z[4,2,3]  R1617     6.3312657177448273e-02
    z[4,2,3]  R1618     -2.7496090531349182e-01
    z[4,2,3]  R1619     -8.1231839954853058e-02
    z[4,2,3]  R1620     -1.8128865957260132e-01
    z[4,2,3]  R1621     -0.535149097442627
    z[4,2,3]  R1622     -6.9514250755310059e-01
    z[4,2,3]  R1623     -3.4890174865722656e-01
    z[4,2,3]  R1624     2.6794403791427612e-01
    z[4,2,3]  R1625     4.0192779898643494e-01
    z[4,2,3]  R1626     -3.8251541554927826e-02
    z[4,2,3]  R1627     -3.0787003040313721e-01
    z[4,2,3]  R1628     2.3503266274929047e-01
    z[4,2,3]  R1629     2.3451916873455048e-01
    z[4,2,3]  R1630     -1.1217866092920303e-01
    z[4,2,3]  R1631     0.0248641986399889
    z[4,2,3]  R1632     1.1310722678899765e-01
    z[4,2,3]  R1633     -1.2516199052333832e-01
    z[4,2,3]  R1634     7.1494663134217262e-03
    z[4,2,3]  R1635     2.7653848752379417e-02
    z[4,2,3]  R1636     -4.1430920362472534e-02
    z[4,2,3]  R1637     -1.9567583501338959e-01
    z[4,2,3]  R1638     -2.8022894263267517e-01
    z[4,2,3]  R1639     -2.2264190018177032e-01
    z[4,2,3]  R1640     -6.3048821687698364e-01
    z[4,2,3]  R1641     -7.3469519615173340e-01
    z[4,2,3]  R1642     -0.543587863445282
    z[4,2,3]  R1643     -4.9522459506988525e-01
    z[4,2,3]  R1644     -5.8769422769546509e-01
    z[4,2,3]  R1645     -2.8840306401252747e-01
    z[4,2,3]  R1646     4.0296044945716858e-01
    z[4,2,3]  R1647     0.89235919713974
    z[4,2,3]  R1648     5.9119653701782227e-01
    z[4,2,3]  R1649     -4.9092669039964676e-02
    z[4,2,3]  R1650     3.3295041322708130e-01
    z[4,2,3]  R1651     -4.7149640321731567e-01
    z[4,2,3]  R1652     6.3730108737945557e-01
    z[4,2,3]  R1653     -4.3858282268047333e-02
    z[4,2,3]  R1654     2.3298986256122589e-01
    z[4,2,3]  R1655     4.6260673552751541e-02
    z[4,2,3]  R1656     1.3171857595443726e-01
    z[4,2,3]  R1657     1.4769986271858215e-01
    z[4,2,3]  R1658     -3.4857848286628723e-01
    z[4,2,3]  R1659     4.8908573389053345e-01
    z[4,2,3]  R1660     1.0993672162294388e-01
    z[4,2,3]  R1661     0.512146532535553
    z[4,2,3]  R1662     8.0749049782752991e-02
    z[4,2,3]  R1663     2.6764547824859619e-01
    z[4,2,3]  R1664     0.00896703451871872
    z[4,2,3]  R1665     7.1413886547088623e-01
    z[4,2,3]  R1666     2.2266833484172821e-01
    z[4,2,3]  R1667     1.3229785859584808e-01
    z[4,2,3]  R1668     -4.2385622859001160e-01
    z[4,2,3]  R1669     -1.5113075077533722e-01
    z[4,2,3]  R1670     -1.3371877372264862e-01
    z[4,2,3]  R1671     -0.685263454914093
    z[4,2,3]  R1672     2.9402244091033936e-01
    z[4,2,3]  R1673     -0.0520898774266243
    z[4,2,3]  R1674     -0.322995126247406
    z[4,2,3]  R1675     -4.4619762897491455e-01
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1590     -1
    z[4,2,4]  R1591     1
    z[4,2,4]  R1596     -1.1761056631803513e-01
    z[4,2,4]  R1597     -4.3422105908393860e-01
    z[4,2,4]  R1598     3.9987348020076752e-02
    z[4,2,4]  R1599     2.0577311515808105e-01
    z[4,2,4]  R1600     -2.2969231009483337e-01
    z[4,2,4]  R1601     -2.3001711070537567e-01
    z[4,2,4]  R1602     -0.0957801342010498
    z[4,2,4]  R1603     -1.7863722145557404e-01
    z[4,2,4]  R1604     -1.7013189196586609e-01
    z[4,2,4]  R1605     -3.6363226175308228e-01
    z[4,2,4]  R1606     1.7837880551815033e-01
    z[4,2,4]  R1607     -3.1958669424057007e-03
    z[4,2,4]  R1608     2.6500046253204346e-01
    z[4,2,4]  R1609     -1.3820233941078186e-01
    z[4,2,4]  R1610     3.3487355709075928e-01
    z[4,2,4]  R1611     3.1450507044792175e-01
    z[4,2,4]  R1612     3.0866429209709167e-01
    z[4,2,4]  R1613     2.1685311198234558e-01
    z[4,2,4]  R1614     1.8871790170669556e-01
    z[4,2,4]  R1615     3.6806982755661011e-01
    z[4,2,4]  R1616     1.0369108617305756e-01
    z[4,2,4]  R1617     2.3422354459762573e-01
    z[4,2,4]  R1618     8.7004482746124268e-02
    z[4,2,4]  R1619     -1.0074214637279510e-01
    z[4,2,4]  R1620     -9.0319961309432983e-02
    z[4,2,4]  R1621     2.9192152619361877e-01
    z[4,2,4]  R1622     1.2943156063556671e-01
    z[4,2,4]  R1623     1.4085660874843597e-01
    z[4,2,4]  R1624     -3.4676857292652130e-02
    z[4,2,4]  R1625     -8.8697835803031921e-02
    z[4,2,4]  R1626     7.3111318051815033e-02
    z[4,2,4]  R1627     -1.1375582218170166e-01
    z[4,2,4]  R1628     -8.2537800073623657e-02
    z[4,2,4]  R1629     -1.7899218201637268e-01
    z[4,2,4]  R1630     8.0192521214485168e-02
    z[4,2,4]  R1631     -3.0449113249778748e-01
    z[4,2,4]  R1632     -1.2869222462177277e-01
    z[4,2,4]  R1633     -4.6238997578620911e-01
    z[4,2,4]  R1634     -4.5858058333396912e-01
    z[4,2,4]  R1635     0.305789053440094
    z[4,2,4]  R1636     -0.0898180678486824
    z[4,2,4]  R1637     -3.7596827745437622e-01
    z[4,2,4]  R1638     -3.4587970376014709e-01
    z[4,2,4]  R1639     -4.2784112691879272e-01
    z[4,2,4]  R1640     -1.5457729995250702e-01
    z[4,2,4]  R1641     -2.0413650572299957e-01
    z[4,2,4]  R1642     -0.0776323527097702
    z[4,2,4]  R1643     1.2053133547306061e-01
    z[4,2,4]  R1644     -2.6265475153923035e-01
    z[4,2,4]  R1645     2.7353662252426147e-01
    z[4,2,4]  R1646     -2.8498631715774536e-01
    z[4,2,4]  R1647     4.1087669134140015e-01
    z[4,2,4]  R1648     -2.8536498546600342e-01
    z[4,2,4]  R1649     -2.8570872545242310e-01
    z[4,2,4]  R1650     -4.2396214604377747e-01
    z[4,2,4]  R1651     -9.6188765019178391e-03
    z[4,2,4]  R1652     3.5438543558120728e-01
    z[4,2,4]  R1653     -2.7970872819423676e-02
    z[4,2,4]  R1654     5.9508824348449707e-01
    z[4,2,4]  R1655     5.2050441503524780e-01
    z[4,2,4]  R1656     2.5748616456985474e-01
    z[4,2,4]  R1657     -2.1077752113342285e-01
    z[4,2,4]  R1658     2.1719934046268463e-01
    z[4,2,4]  R1659     2.3210911080241203e-02
    z[4,2,4]  R1660     2.5619903206825256e-01
    z[4,2,4]  R1661     -2.3334741592407227e-01
    z[4,2,4]  R1662     3.4386062622070312e-01
    z[4,2,4]  R1663     2.8850868344306946e-01
    z[4,2,4]  R1664     2.9008671641349792e-01
    z[4,2,4]  R1665     2.1807883679866791e-01
    z[4,2,4]  R1666     3.7299329042434692e-01
    z[4,2,4]  R1667     3.3229142427444458e-02
    z[4,2,4]  R1668     0.216078981757164
    z[4,2,4]  R1669     2.6762318611145020e-01
    z[4,2,4]  R1670     -1.2383381277322769e-01
    z[4,2,4]  R1671     -7.6574023114517331e-04
    z[4,2,4]  R1672     3.4473296999931335e-01
    z[4,2,4]  R1673     -4.5324954390525818e-01
    z[4,2,4]  R1674     -9.6704736351966858e-03
    z[4,2,4]  R1675     1.6221849620342255e-01
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1592     -1
    z[4,2,5]  R1593     1
    z[4,2,5]  R1596     5.6471548974514008e-02
    z[4,2,5]  R1597     -0.00575606245547533
    z[4,2,5]  R1598     1.4192521572113037e-01
    z[4,2,5]  R1599     -1.6009394824504852e-01
    z[4,2,5]  R1600     -2.8100606799125671e-01
    z[4,2,5]  R1601     9.9084721878170967e-03
    z[4,2,5]  R1602     -3.1752511858940125e-01
    z[4,2,5]  R1603     -2.3209697008132935e-01
    z[4,2,5]  R1604     -1.2765762209892273e-01
    z[4,2,5]  R1605     1.9370566308498383e-01
    z[4,2,5]  R1606     -1.9008180499076843e-01
    z[4,2,5]  R1607     1.2980645895004272e-01
    z[4,2,5]  R1608     -7.0155955851078033e-02
    z[4,2,5]  R1609     1.7229683697223663e-01
    z[4,2,5]  R1610     1.2577322125434875e-01
    z[4,2,5]  R1611     3.3563748002052307e-01
    z[4,2,5]  R1612     4.6237561851739883e-02
    z[4,2,5]  R1613     1.3555921614170074e-01
    z[4,2,5]  R1614     -2.0125040411949158e-01
    z[4,2,5]  R1615     4.8644743859767914e-02
    z[4,2,5]  R1616     -7.7171243727207184e-02
    z[4,2,5]  R1617     -4.4923387467861176e-03
    z[4,2,5]  R1618     6.1700176447629929e-02
    z[4,2,5]  R1619     -3.7547716498374939e-01
    z[4,2,5]  R1620     -0.0452738031744957
    z[4,2,5]  R1621     1.7261669039726257e-01
    z[4,2,5]  R1622     6.5440088510513306e-03
    z[4,2,5]  R1623     2.7864855527877808e-01
    z[4,2,5]  R1624     0.523865282535553
    z[4,2,5]  R1625     8.0336958169937134e-02
    z[4,2,5]  R1626     -2.0992338657379150e-01
    z[4,2,5]  R1627     6.0002353042364120e-02
    z[4,2,5]  R1628     2.1711468696594238e-01
    z[4,2,5]  R1629     2.1944953128695488e-02
    z[4,2,5]  R1630     -3.0375117063522339e-01
    z[4,2,5]  R1631     0.174501433968544
    z[4,2,5]  R1632     -4.4397312402725220e-01
    z[4,2,5]  R1633     -1.2243715673685074e-01
    z[4,2,5]  R1634     -4.3224963545799255e-01
    z[4,2,5]  R1635     1.7003849148750305e-01
    z[4,2,5]  R1636     -1.8312266469001770e-01
    z[4,2,5]  R1637     -4.2208548984490335e-04
    z[4,2,5]  R1638     -1.7857927083969116e-01
    z[4,2,5]  R1639     1.4842978678643703e-02
    z[4,2,5]  R1640     -6.8562075495719910e-02
    z[4,2,5]  R1641     -1.3925287127494812e-01
    z[4,2,5]  R1642     -3.6532059311866760e-01
    z[4,2,5]  R1643     -3.4194344282150269e-01
    z[4,2,5]  R1644     -5.0903332233428955e-01
    z[4,2,5]  R1645     -3.8409563899040222e-01
    z[4,2,5]  R1646     2.0312181115150452e-01
    z[4,2,5]  R1647     -2.6462316513061523e-02
    z[4,2,5]  R1648     -1.6600729897618294e-02
    z[4,2,5]  R1649     2.4125227332115173e-01
    z[4,2,5]  R1650     4.7427029348909855e-03
    z[4,2,5]  R1651     -1.4630095660686493e-01
    z[4,2,5]  R1652     1.6965536773204803e-01
    z[4,2,5]  R1653     6.9013011455535889e-01
    z[4,2,5]  R1654     1.9435566663742065e-01
    z[4,2,5]  R1655     1.5157592296600342e-01
    z[4,2,5]  R1656     7.7136784791946411e-02
    z[4,2,5]  R1657     -5.7041305303573608e-01
    z[4,2,5]  R1658     4.2971007525920868e-02
    z[4,2,5]  R1659     2.3333853483200073e-01
    z[4,2,5]  R1660     -4.1894045472145081e-01
    z[4,2,5]  R1661     3.3118382096290588e-01
    z[4,2,5]  R1662     -2.5302490592002869e-01
    z[4,2,5]  R1663     1.1748849600553513e-01
    z[4,2,5]  R1664     5.8008664846420288e-01
    z[4,2,5]  R1665     -2.6482850313186646e-01
    z[4,2,5]  R1666     3.0217874050140381e-01
    z[4,2,5]  R1667     2.3517285287380219e-01
    z[4,2,5]  R1668     -1.0395722091197968e-01
    z[4,2,5]  R1669     0.1573476344347
    z[4,2,5]  R1670     4.9449086189270020e-01
    z[4,2,5]  R1671     -4.0731698274612427e-01
    z[4,2,5]  R1672     -3.3146545290946960e-01
    z[4,2,5]  R1673     -9.0212017297744751e-02
    z[4,2,5]  R1674     5.5188196897506714e-01
    z[4,2,5]  R1675     8.6244657635688782e-02
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1594     -1
    z[4,2,6]  R1595     1
    z[4,2,6]  R1596     3.1652396917343140e-01
    z[4,2,6]  R1597     -6.5598316490650177e-02
    z[4,2,6]  R1598     -1.4475968480110168e-01
    z[4,2,6]  R1599     5.3866535425186157e-01
    z[4,2,6]  R1600     5.9146124124526978e-01
    z[4,2,6]  R1601     -0.60360187292099
    z[4,2,6]  R1602     -5.6626528501510620e-01
    z[4,2,6]  R1603     0.00824635848402977
    z[4,2,6]  R1604     3.1562498211860657e-01
    z[4,2,6]  R1605     1.6719865798950195e-01
    z[4,2,6]  R1606     1.7597745358943939e-01
    z[4,2,6]  R1607     3.1092354655265808e-01
    z[4,2,6]  R1608     7.7080823481082916e-02
    z[4,2,6]  R1609     -4.4619336724281311e-01
    z[4,2,6]  R1610     -1.3356833159923553e-01
    z[4,2,6]  R1611     -1.6347070038318634e-01
    z[4,2,6]  R1612     -4.5246567577123642e-02
    z[4,2,6]  R1613     -4.5476046204566956e-01
    z[4,2,6]  R1614     -1.8977752327919006e-01
    z[4,2,6]  R1615     4.3836481869220734e-02
    z[4,2,6]  R1616     -3.9253199100494385e-01
    z[4,2,6]  R1617     -1.6546231508255005e-01
    z[4,2,6]  R1618     -1.3584578037261963e-01
    z[4,2,6]  R1619     2.3039807379245758e-01
    z[4,2,6]  R1620     -4.0946129709482193e-02
    z[4,2,6]  R1621     1.3760775327682495e-01
    z[4,2,6]  R1622     -6.8311393260955811e-03
    z[4,2,6]  R1623     -4.3948139995336533e-02
    z[4,2,6]  R1624     6.0904525220394135e-02
    z[4,2,6]  R1625     -3.9998155832290649e-01
    z[4,2,6]  R1626     4.8072773218154907e-01
    z[4,2,6]  R1627     1.8467712402343750e-01
    z[4,2,6]  R1628     4.4496819376945496e-01
    z[4,2,6]  R1629     -1.3334497809410095e-01
    z[4,2,6]  R1630     -3.8611200451850891e-01
    z[4,2,6]  R1631     4.0329754352569580e-01
    z[4,2,6]  R1632     -4.5594829320907593e-01
    z[4,2,6]  R1633     -2.2571486234664917e-01
    z[4,2,6]  R1634     3.4922768827527761e-03
    z[4,2,6]  R1635     5.3784966468811035e-01
    z[4,2,6]  R1636     2.9884090647101402e-02
    z[4,2,6]  R1637     -3.0452278256416321e-01
    z[4,2,6]  R1638     2.2463712841272354e-02
    z[4,2,6]  R1639     5.0114914774894714e-02
    z[4,2,6]  R1640     3.7714502215385437e-01
    z[4,2,6]  R1641     1.0475924611091614e-01
    z[4,2,6]  R1642     2.8772982954978943e-01
    z[4,2,6]  R1643     -1.2541884183883667e-01
    z[4,2,6]  R1644     -1.1786801740527153e-02
    z[4,2,6]  R1645     -5.2705653011798859e-02
    z[4,2,6]  R1646     -1.4552329480648041e-01
    z[4,2,6]  R1647     -7.2948947548866272e-02
    z[4,2,6]  R1648     -5.5890363454818726e-01
    z[4,2,6]  R1649     -3.5005655884742737e-01
    z[4,2,6]  R1650     -6.2761205434799194e-01
    z[4,2,6]  R1651     -0.382338285446167
    z[4,2,6]  R1652     -3.0575555562973022e-01
    z[4,2,6]  R1653     -2.7842029929161072e-01
    z[4,2,6]  R1654     -4.0848350524902344e-01
    z[4,2,6]  R1655     -2.7487668395042419e-01
    z[4,2,6]  R1656     -2.3937320336699486e-02
    z[4,2,6]  R1657     -8.3725750446319580e-02
    z[4,2,6]  R1658     -1.6932488977909088e-01
    z[4,2,6]  R1659     8.9579321444034576e-02
    z[4,2,6]  R1660     -3.2548922300338745e-01
    z[4,2,6]  R1661     5.2447974681854248e-01
    z[4,2,6]  R1662     -2.0602095872163773e-02
    z[4,2,6]  R1663     -0.640866756439209
    z[4,2,6]  R1664     -1.3373306393623352e-01
    z[4,2,6]  R1665     -3.6413770914077759e-01
    z[4,2,6]  R1666     4.9902126193046570e-01
    z[4,2,6]  R1667     -2.0717842876911163e-01
    z[4,2,6]  R1668     0.100248783826828
    z[4,2,6]  R1669     -1.3530507683753967e-01
    z[4,2,6]  R1670     -3.4942036867141724e-01
    z[4,2,6]  R1671     -0.0379759818315506
    z[4,2,6]  R1672     1.4620022475719452e-01
    z[4,2,6]  R1673     1.9696770608425140e-01
    z[4,2,6]  R1674     -4.0968382358551025e-01
    z[4,2,6]  R1675     -4.4251814484596252e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1676     -1
    z[2,5,0]  R1677     1
    z[2,5,0]  R1690     2.0168526470661163e-01
    z[2,5,0]  R1691     7.4236601591110229e-01
    z[2,5,0]  R1692     6.3519030809402466e-01
    z[2,5,0]  R1693     8.2694751024246216e-01
    z[2,5,0]  R1694     0.732430636882782
    z[2,5,0]  R1695     6.9434732198715210e-01
    z[2,5,0]  R1696     5.0212305784225464e-01
    z[2,5,0]  R1697     5.2095401287078857e-01
    z[2,5,0]  R1698     5.2552109956741333e-01
    z[2,5,0]  R1699     0.565981388092041
    z[2,5,0]  R1700     -2.8693279623985291e-01
    z[2,5,0]  R1701     -2.2875705361366272e-01
    z[2,5,0]  R1702     -3.7252682447433472e-01
    z[2,5,0]  R1703     -3.4144580364227295e-02
    z[2,5,0]  R1704     -1.2130939960479736e-01
    z[2,5,0]  R1705     -0.24737648665905
    z[2,5,0]  R1706     -3.2693052291870117e-01
    z[2,5,0]  R1707     -7.0166802406311035e-01
    z[2,5,0]  R1708     -5.1734834909439087e-01
    z[2,5,0]  R1709     -6.8399560451507568e-01
    z[2,5,0]  R1710     2.5814792513847351e-01
    z[2,5,0]  R1711     2.5163169950246811e-02
    z[2,5,0]  R1712     -2.8755296953022480e-03
    z[2,5,0]  R1713     -9.6380099654197693e-02
    z[2,5,0]  R1714     5.5131424218416214e-02
    z[2,5,0]  R1715     -3.4453833103179932e-01
    z[2,5,0]  R1716     3.0919777229428291e-02
    z[2,5,0]  R1717     4.4574152678251266e-02
    z[2,5,0]  R1718     -2.1453756093978882e-01
    z[2,5,0]  R1719     -4.7364017367362976e-01
    z[2,5,0]  R1720     4.5386686921119690e-01
    z[2,5,0]  R1721     5.7206705212593079e-02
    z[2,5,0]  R1722     -2.5209262967109680e-01
    z[2,5,0]  R1723     1.3466119766235352e-02
    z[2,5,0]  R1724     -3.8344639539718628e-01
    z[2,5,0]  R1725     -1.2124659866094589e-01
    z[2,5,0]  R1726     -4.3595591187477112e-01
    z[2,5,0]  R1727     -3.0036526918411255e-01
    z[2,5,0]  R1728     1.9480532407760620e-01
    z[2,5,0]  R1729     -1.3827045261859894e-01
    z[2,5,0]  R1730     2.8657663613557816e-02
    z[2,5,0]  R1731     2.7474978566169739e-01
    z[2,5,0]  R1732     -5.2531582117080688e-01
    z[2,5,0]  R1733     -4.8632583022117615e-01
    z[2,5,0]  R1734     3.1036838889122009e-01
    z[2,5,0]  R1735     -5.6225264072418213e-01
    z[2,5,0]  R1736     9.9852740764617920e-02
    z[2,5,0]  R1737     7.0530459284782410e-02
    z[2,5,0]  R1738     -2.4579961597919464e-01
    z[2,5,0]  R1739     -5.8534210920333862e-01
    z[2,5,0]  R1740     4.4905692338943481e-02
    z[2,5,0]  R1741     2.7488011121749878e-01
    z[2,5,0]  R1742     4.9197757244110107e-01
    z[2,5,0]  R1743     -1.0621292144060135e-01
    z[2,5,0]  R1744     3.2745444774627686e-01
    z[2,5,0]  R1745     3.9802014827728271e-01
    z[2,5,0]  R1746     3.4995537996292114e-01
    z[2,5,0]  R1747     -1.5063305199146271e-01
    z[2,5,0]  R1748     4.7343918681144714e-01
    z[2,5,0]  R1749     -2.1048258244991302e-01
    z[2,5,0]  R1750     3.3840200304985046e-01
    z[2,5,0]  R1751     4.9328714609146118e-02
    z[2,5,0]  R1752     1.6332606971263885e-01
    z[2,5,0]  R1753     0.0453437939286232
    z[2,5,0]  R1754     1.0652531683444977e-01
    z[2,5,0]  R1755     1.7694209516048431e-01
    z[2,5,0]  R1756     3.9981940388679504e-01
    z[2,5,0]  R1757     -3.0972000211477280e-02
    z[2,5,0]  R1758     1.7476992681622505e-02
    z[2,5,0]  R1759     -1.1291588842868805e-01
    z[2,5,0]  R1760     -1.9607307389378548e-02
    z[2,5,0]  R1761     4.8747184872627258e-01
    z[2,5,0]  R1762     1.8454360961914062e-01
    z[2,5,0]  R1763     8.6628451943397522e-02
    z[2,5,0]  R1764     -4.6332213096320629e-03
    z[2,5,0]  R1765     -0.133395716547966
    z[2,5,0]  R1766     -3.1193557381629944e-01
    z[2,5,0]  R1767     -2.5365066528320312e-01
    z[2,5,0]  R1768     -5.2966989576816559e-02
    z[2,5,0]  R1769     -1.6295957565307617e-01
    z[2,5,0]  R1770     4.2942172288894653e-01
    z[2,5,0]  R1771     -2.3111522197723389e-01
    z[2,5,0]  R1772     5.0620734691619873e-01
    z[2,5,0]  R1773     3.2991644740104675e-01
    z[2,5,0]  R1774     -8.9085623621940613e-02
    z[2,5,0]  R1775     -5.8000821620225906e-02
    z[2,5,0]  R1776     3.1568494439125061e-01
    z[2,5,0]  R1777     1.6023042798042297e-01
    z[2,5,0]  R1778     -2.2212259471416473e-01
    z[2,5,0]  R1779     3.0740559101104736e-01
    z[2,5,0]  R1780     -9.0094543993473053e-02
    z[2,5,0]  R1781     3.9716640114784241e-01
    z[2,5,0]  R1782     -2.3172914981842041e-01
    z[2,5,0]  R1783     1.7375090718269348e-01
    z[2,5,0]  R1784     2.0802558958530426e-01
    z[2,5,0]  R1785     -2.7975955605506897e-01
    z[2,5,0]  R1786     -0.29337078332901
    z[2,5,0]  R1787     -1.1495106155052781e-03
    z[2,5,0]  R1788     -1.6729475557804108e-01
    z[2,5,0]  R1789     -4.1556453704833984e-01
    z[2,5,0]  R1790     -1.5465673059225082e-02
    z[2,5,0]  R1791     1.2804825603961945e-01
    z[2,5,0]  R1792     1.2401670217514038e-01
    z[2,5,0]  R1793     1.9561153650283813e-01
    z[2,5,0]  R1794     3.1262066960334778e-01
    z[2,5,0]  R1795     1.5708579123020172e-01
    z[2,5,0]  R1796     1.5607194602489471e-01
    z[2,5,0]  R1797     4.3293327093124390e-01
    z[2,5,0]  R1798     1.9849990308284760e-01
    z[2,5,0]  R1799     2.9485905170440674e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1678     -1
    z[2,5,1]  R1679     1
    z[2,5,1]  R1690     -8.1922346353530884e-01
    z[2,5,1]  R1691     4.4056215882301331e-01
    z[2,5,1]  R1692     5.2807974815368652e-01
    z[2,5,1]  R1693     4.5687785744667053e-01
    z[2,5,1]  R1694     4.2076438665390015e-01
    z[2,5,1]  R1695     4.7686314582824707e-01
    z[2,5,1]  R1696     5.5727756023406982e-01
    z[2,5,1]  R1697     0.628750741481781
    z[2,5,1]  R1698     0.564632773399353
    z[2,5,1]  R1699     5.0390481948852539e-01
    z[2,5,1]  R1700     9.3186748027801514e-01
    z[2,5,1]  R1701     8.1989574432373047e-01
    z[2,5,1]  R1702     6.3152486085891724e-01
    z[2,5,1]  R1703     0.871233344078064
    z[2,5,1]  R1704     6.4237689971923828e-01
    z[2,5,1]  R1705     5.5604827404022217e-01
    z[2,5,1]  R1706     0.612606406211853
    z[2,5,1]  R1707     2.4693058431148529e-01
    z[2,5,1]  R1708     1.0127270966768265e-01
    z[2,5,1]  R1709     4.4768798351287842e-01
    z[2,5,1]  R1710     0.767442524433136
    z[2,5,1]  R1711     -0.16782146692276
    z[2,5,1]  R1712     -0.505316972732544
    z[2,5,1]  R1713     -6.2347787618637085e-01
    z[2,5,1]  R1714     -5.5880290269851685e-01
    z[2,5,1]  R1715     -6.9875997304916382e-01
    z[2,5,1]  R1716     -5.7810330390930176e-01
    z[2,5,1]  R1717     6.2407189607620239e-01
    z[2,5,1]  R1718     -0.574478030204773
    z[2,5,1]  R1719     6.3457864522933960e-01
    z[2,5,1]  R1720     8.3791959285736084e-01
    z[2,5,1]  R1721     -7.3148196935653687e-01
    z[2,5,1]  R1722     -8.3641594648361206e-01
    z[2,5,1]  R1723     -5.9700292348861694e-01
    z[2,5,1]  R1724     -7.0138669013977051e-01
    z[2,5,1]  R1725     -0.52411288022995
    z[2,5,1]  R1726     -5.8007371425628662e-01
    z[2,5,1]  R1727     -5.7386624813079834e-01
    z[2,5,1]  R1728     -7.1420305967330933e-01
    z[2,5,1]  R1729     -0.469468891620636
    z[2,5,1]  R1730     -6.7077857255935669e-01
    z[2,5,1]  R1731     4.9553334712982178e-01
    z[2,5,1]  R1732     6.4749163389205933e-01
    z[2,5,1]  R1733     7.4309313297271729e-01
    z[2,5,1]  R1734     -6.7778146266937256e-01
    z[2,5,1]  R1735     -1.6208501160144806e-01
    z[2,5,1]  R1736     3.5068961977958679e-01
    z[2,5,1]  R1737     -4.7770828008651733e-01
    z[2,5,1]  R1738     5.9483128786087036e-01
    z[2,5,1]  R1739     4.7563686966896057e-01
    z[2,5,1]  R1740     -6.8122547864913940e-01
    z[2,5,1]  R1741     -6.7748540639877319e-01
    z[2,5,1]  R1742     6.7459249496459961e-01
    z[2,5,1]  R1743     -8.1346917152404785e-01
    z[2,5,1]  R1744     -7.0029234886169434e-01
    z[2,5,1]  R1745     5.2877306938171387e-01
    z[2,5,1]  R1746     5.9612405300140381e-01
    z[2,5,1]  R1747     -1.8770109117031097e-01
    z[2,5,1]  R1748     5.2165532112121582e-01
    z[2,5,1]  R1749     8.9386940002441406e-01
    z[2,5,1]  R1750     8.1641274690628052e-01
    z[2,5,1]  R1751     8.4431940317153931e-01
    z[2,5,1]  R1752     -2.0611999928951263e-01
    z[2,5,1]  R1753     -6.5368312597274780e-01
    z[2,5,1]  R1754     -2.7324327826499939e-01
    z[2,5,1]  R1755     7.9011809825897217e-01
    z[2,5,1]  R1756     6.1137682199478149e-01
    z[2,5,1]  R1757     2.6357316970825195e-01
    z[2,5,1]  R1758     -4.6956473588943481e-01
    z[2,5,1]  R1759     1.1211547255516052e-01
    z[2,5,1]  R1760     -8.9405238628387451e-01
    z[2,5,1]  R1761     0.65756756067276
    z[2,5,1]  R1762     8.2068479061126709e-01
    z[2,5,1]  R1763     -0.741539478302002
    z[2,5,1]  R1764     0.904663622379303
    z[2,5,1]  R1765     -5.9420973062515259e-01
    z[2,5,1]  R1766     -0.470384418964386
    z[2,5,1]  R1767     -3.7736091017723083e-01
    z[2,5,1]  R1768     -8.1561100482940674e-01
    z[2,5,1]  R1769     -5.2647686004638672e-01
    z[2,5,1]  R1770     6.3006180524826050e-01
    z[2,5,1]  R1771     -4.2134487628936768e-01
    z[2,5,1]  R1772     0.691325306892395
    z[2,5,1]  R1773     -0.750025749206543
    z[2,5,1]  R1774     -6.0750845819711685e-02
    z[2,5,1]  R1775     1.1036308109760284e-01
    z[2,5,1]  R1776     0.545853316783905
    z[2,5,1]  R1777     7.5227451324462891e-01
    z[2,5,1]  R1778     -5.3734356164932251e-01
    z[2,5,1]  R1779     4.6872133016586304e-01
    z[2,5,1]  R1780     -7.4568390846252441e-01
    z[2,5,1]  R1781     -8.3605545759201050e-01
    z[2,5,1]  R1782     -6.1399626731872559e-01
    z[2,5,1]  R1783     6.9033062458038330e-01
    z[2,5,1]  R1784     6.4332503080368042e-01
    z[2,5,1]  R1785     5.5489885807037354e-01
    z[2,5,1]  R1786     6.9776940345764160e-01
    z[2,5,1]  R1787     4.6602910757064819e-01
    z[2,5,1]  R1788     5.1794224977493286e-01
    z[2,5,1]  R1789     7.5704419612884521e-01
    z[2,5,1]  R1790     -7.6356285810470581e-01
    z[2,5,1]  R1791     -2.0082026720046997e-01
    z[2,5,1]  R1792     -5.0230443477630615e-01
    z[2,5,1]  R1793     7.5273811817169189e-01
    z[2,5,1]  R1794     6.8352770805358887e-01
    z[2,5,1]  R1795     -6.8227595090866089e-01
    z[2,5,1]  R1796     5.6851136684417725e-01
    z[2,5,1]  R1797     5.7080060243606567e-01
    z[2,5,1]  R1798     5.5767953395843506e-01
    z[2,5,1]  R1799     -0.652384340763092
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1680     -1
    z[2,5,2]  R1681     1
    z[2,5,2]  R1690     -7.8870102763175964e-02
    z[2,5,2]  R1691     3.3070746064186096e-01
    z[2,5,2]  R1692     1.0235553234815598e-01
    z[2,5,2]  R1693     4.6049594879150391e-02
    z[2,5,2]  R1694     1.6168086230754852e-01
    z[2,5,2]  R1695     6.3644699752330780e-02
    z[2,5,2]  R1696     5.4390218108892441e-02
    z[2,5,2]  R1697     -1.9460545480251312e-01
    z[2,5,2]  R1698     -8.8420659303665161e-02
    z[2,5,2]  R1699     1.1523006111383438e-01
    z[2,5,2]  R1700     -7.1286588907241821e-02
    z[2,5,2]  R1701     5.5369723588228226e-02
    z[2,5,2]  R1702     -4.8150178790092468e-01
    z[2,5,2]  R1703     -6.6612720489501953e-02
    z[2,5,2]  R1704     -6.5477684140205383e-02
    z[2,5,2]  R1705     1.3341930508613586e-01
    z[2,5,2]  R1706     -0.0082245459780097
    z[2,5,2]  R1707     -2.3293124139308929e-01
    z[2,5,2]  R1708     -2.2015622258186340e-01
    z[2,5,2]  R1709     -1.5303435921669006e-01
    z[2,5,2]  R1710     1.9586192071437836e-01
    z[2,5,2]  R1711     7.5157051905989647e-03
    z[2,5,2]  R1712     3.2421614974737167e-02
    z[2,5,2]  R1713     -5.8069300651550293e-01
    z[2,5,2]  R1714     -1.3434453867375851e-02
    z[2,5,2]  R1715     5.5135834962129593e-02
    z[2,5,2]  R1716     -1.0406474769115448e-01
    z[2,5,2]  R1717     -2.2813172638416290e-01
    z[2,5,2]  R1718     1.0440982878208160e-01
    z[2,5,2]  R1719     3.7115357816219330e-02
    z[2,5,2]  R1720     4.1516300290822983e-02
    z[2,5,2]  R1721     2.5107404589653015e-01
    z[2,5,2]  R1722     -1.9405621290206909e-01
    z[2,5,2]  R1723     -5.8411568403244019e-01
    z[2,5,2]  R1724     4.2978670448064804e-02
    z[2,5,2]  R1725     9.5384582877159119e-02
    z[2,5,2]  R1726     -5.3315126895904541e-01
    z[2,5,2]  R1727     -0.0327596440911293
    z[2,5,2]  R1728     -1.1553891003131866e-01
    z[2,5,2]  R1729     -1.4035994186997414e-02
    z[2,5,2]  R1730     -1.4211086928844452e-01
    z[2,5,2]  R1731     0.749748706817627
    z[2,5,2]  R1732     -2.3999287188053131e-01
    z[2,5,2]  R1733     -2.7160859107971191e-01
    z[2,5,2]  R1734     2.1083752810955048e-01
    z[2,5,2]  R1735     -1.4375127851963043e-01
    z[2,5,2]  R1736     7.2836279869079590e-01
    z[2,5,2]  R1737     -7.1535813808441162e-01
    z[2,5,2]  R1738     -9.4469018280506134e-02
    z[2,5,2]  R1739     4.9765370786190033e-02
    z[2,5,2]  R1740     -2.5429481267929077e-01
    z[2,5,2]  R1741     -4.7350153326988220e-01
    z[2,5,2]  R1742     -1.6671952605247498e-01
    z[2,5,2]  R1743     -6.9923691451549530e-02
    z[2,5,2]  R1744     5.1851324737071991e-02
    z[2,5,2]  R1745     -6.2837436795234680e-02
    z[2,5,2]  R1746     -1.7073693871498108e-01
    z[2,5,2]  R1747     -4.8172447085380554e-01
    z[2,5,2]  R1748     -5.1995605230331421e-01
    z[2,5,2]  R1749     -5.7836681604385376e-02
    z[2,5,2]  R1750     2.4669414758682251e-01
    z[2,5,2]  R1751     -1.1313141882419586e-01
    z[2,5,2]  R1752     -1.0266650468111038e-01
    z[2,5,2]  R1753     2.6764890551567078e-01
    z[2,5,2]  R1754     1.7920050024986267e-01
    z[2,5,2]  R1755     3.4833726286888123e-01
    z[2,5,2]  R1756     3.7064486742019653e-01
    z[2,5,2]  R1757     -0.321865051984787
    z[2,5,2]  R1758     -2.4265077710151672e-01
    z[2,5,2]  R1759     3.4573718905448914e-01
    z[2,5,2]  R1760     -1.5769918262958527e-01
    z[2,5,2]  R1761     -4.5038771629333496e-01
    z[2,5,2]  R1762     -3.4964182972908020e-01
    z[2,5,2]  R1763     -4.9290037155151367e-01
    z[2,5,2]  R1764     -7.1905307471752167e-02
    z[2,5,2]  R1765     -1.6450406610965729e-01
    z[2,5,2]  R1766     9.9394604563713074e-02
    z[2,5,2]  R1767     1.7148096859455109e-01
    z[2,5,2]  R1768     1.2626454234123230e-01
    z[2,5,2]  R1769     -3.3183717727661133e-01
    z[2,5,2]  R1770     3.0751636624336243e-01
    z[2,5,2]  R1771     2.0369198918342590e-01
    z[2,5,2]  R1772     0.282680869102478
    z[2,5,2]  R1773     3.1261113286018372e-01
    z[2,5,2]  R1774     -5.2417612075805664e-01
    z[2,5,2]  R1775     1.0222312062978745e-01
    z[2,5,2]  R1776     3.1969651579856873e-01
    z[2,5,2]  R1777     -2.1627022325992584e-01
    z[2,5,2]  R1778     -3.8786804676055908e-01
    z[2,5,2]  R1779     4.1406969539821148e-03
    z[2,5,2]  R1780     3.2021556049585342e-02
    z[2,5,2]  R1781     1.3430744409561157e-01
    z[2,5,2]  R1782     -2.9622071981430054e-01
    z[2,5,2]  R1783     -6.7097288370132446e-01
    z[2,5,2]  R1784     2.2424674034118652e-01
    z[2,5,2]  R1785     -3.8256937265396118e-01
    z[2,5,2]  R1786     -4.1397172212600708e-01
    z[2,5,2]  R1787     -0.676310658454895
    z[2,5,2]  R1788     -6.0162127017974854e-01
    z[2,5,2]  R1789     2.3310698568820953e-01
    z[2,5,2]  R1790     -2.2924098372459412e-01
    z[2,5,2]  R1791     -4.4149917364120483e-01
    z[2,5,2]  R1792     2.4197886884212494e-01
    z[2,5,2]  R1793     -5.4202873259782791e-02
    z[2,5,2]  R1794     -4.5376177877187729e-02
    z[2,5,2]  R1795     3.4249746799468994e-01
    z[2,5,2]  R1796     3.1649532914161682e-01
    z[2,5,2]  R1797     -3.9023196697235107e-01
    z[2,5,2]  R1798     -2.1241942048072815e-01
    z[2,5,2]  R1799     1.6354057192802429e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1682     -1
    z[2,5,3]  R1683     1
    z[2,5,3]  R1690     -3.8251541554927826e-02
    z[2,5,3]  R1691     -3.0787003040313721e-01
    z[2,5,3]  R1692     2.3503266274929047e-01
    z[2,5,3]  R1693     2.3451916873455048e-01
    z[2,5,3]  R1694     -1.1217866092920303e-01
    z[2,5,3]  R1695     0.0248641986399889
    z[2,5,3]  R1696     1.1310722678899765e-01
    z[2,5,3]  R1697     -1.2516199052333832e-01
    z[2,5,3]  R1698     7.1494663134217262e-03
    z[2,5,3]  R1699     2.7653848752379417e-02
    z[2,5,3]  R1700     -4.1430920362472534e-02
    z[2,5,3]  R1701     -1.9567583501338959e-01
    z[2,5,3]  R1702     -2.8022894263267517e-01
    z[2,5,3]  R1703     -2.2264190018177032e-01
    z[2,5,3]  R1704     -6.3048821687698364e-01
    z[2,5,3]  R1705     -7.3469519615173340e-01
    z[2,5,3]  R1706     -0.543587863445282
    z[2,5,3]  R1707     -4.9522459506988525e-01
    z[2,5,3]  R1708     -5.8769422769546509e-01
    z[2,5,3]  R1709     -2.8840306401252747e-01
    z[2,5,3]  R1710     4.0296044945716858e-01
    z[2,5,3]  R1711     0.89235919713974
    z[2,5,3]  R1712     5.9119653701782227e-01
    z[2,5,3]  R1713     -4.9092669039964676e-02
    z[2,5,3]  R1714     3.3295041322708130e-01
    z[2,5,3]  R1715     -4.7149640321731567e-01
    z[2,5,3]  R1716     6.3730108737945557e-01
    z[2,5,3]  R1717     -4.3858282268047333e-02
    z[2,5,3]  R1718     2.3298986256122589e-01
    z[2,5,3]  R1719     4.6260673552751541e-02
    z[2,5,3]  R1720     1.3171857595443726e-01
    z[2,5,3]  R1721     1.4769986271858215e-01
    z[2,5,3]  R1722     -3.4857848286628723e-01
    z[2,5,3]  R1723     4.8908573389053345e-01
    z[2,5,3]  R1724     1.0993672162294388e-01
    z[2,5,3]  R1725     0.512146532535553
    z[2,5,3]  R1726     8.0749049782752991e-02
    z[2,5,3]  R1727     2.6764547824859619e-01
    z[2,5,3]  R1728     0.00896703451871872
    z[2,5,3]  R1729     7.1413886547088623e-01
    z[2,5,3]  R1730     2.2266833484172821e-01
    z[2,5,3]  R1731     1.3229785859584808e-01
    z[2,5,3]  R1732     -4.2385622859001160e-01
    z[2,5,3]  R1733     -1.5113075077533722e-01
    z[2,5,3]  R1734     -1.3371877372264862e-01
    z[2,5,3]  R1735     -0.685263454914093
    z[2,5,3]  R1736     2.9402244091033936e-01
    z[2,5,3]  R1737     -0.0520898774266243
    z[2,5,3]  R1738     -0.322995126247406
    z[2,5,3]  R1739     -4.4619762897491455e-01
    z[2,5,3]  R1740     5.3208708763122559e-01
    z[2,5,3]  R1741     -6.7700318992137909e-02
    z[2,5,3]  R1742     -1.8652331829071045e-01
    z[2,5,3]  R1743     -2.6899260282516479e-01
    z[2,5,3]  R1744     -1.1053077131509781e-01
    z[2,5,3]  R1745     -6.1051309108734131e-01
    z[2,5,3]  R1746     -4.5318952202796936e-01
    z[2,5,3]  R1747     8.3257085084915161e-01
    z[2,5,3]  R1748     -2.9941469430923462e-01
    z[2,5,3]  R1749     -3.3782172203063965e-01
    z[2,5,3]  R1750     1.8651817739009857e-01
    z[2,5,3]  R1751     -1.5265716612339020e-01
    z[2,5,3]  R1752     8.7237930297851562e-01
    z[2,5,3]  R1753     2.3032648861408234e-01
    z[2,5,3]  R1754     7.4780148267745972e-01
    z[2,5,3]  R1755     -1.2419898062944412e-01
    z[2,5,3]  R1756     -1.8971423804759979e-01
    z[2,5,3]  R1757     8.0624425411224365e-01
    z[2,5,3]  R1758     7.4304181337356567e-01
    z[2,5,3]  R1759     7.6708149909973145e-01
    z[2,5,3]  R1760     -3.8678354024887085e-01
    z[2,5,3]  R1761     -1.7900021374225616e-01
    z[2,5,3]  R1762     3.1066963076591492e-01
    z[2,5,3]  R1763     4.3569728732109070e-01
    z[2,5,3]  R1764     -2.8471006080508232e-02
    z[2,5,3]  R1765     4.4629785418510437e-01
    z[2,5,3]  R1766     5.9161442518234253e-01
    z[2,5,3]  R1767     4.7145324945449829e-01
    z[2,5,3]  R1768     3.5779750347137451e-01
    z[2,5,3]  R1769     3.3317390084266663e-01
    z[2,5,3]  R1770     -5.2699881792068481e-01
    z[2,5,3]  R1771     5.4240685701370239e-01
    z[2,5,3]  R1772     -2.0581322908401489e-01
    z[2,5,3]  R1773     1.1047840118408203e-02
    z[2,5,3]  R1774     7.0259046554565430e-01
    z[2,5,3]  R1775     9.2891907691955566e-01
    z[2,5,3]  R1776     -3.5196724534034729e-01
    z[2,5,3]  R1777     3.0686733126640320e-01
    z[2,5,3]  R1778     3.9088377356529236e-01
    z[2,5,3]  R1779     -3.0861553549766541e-01
    z[2,5,3]  R1780     -2.1929587423801422e-01
    z[2,5,3]  R1781     1.1554061621427536e-01
    z[2,5,3]  R1782     -1.4648194611072540e-01
    z[2,5,3]  R1783     5.5972304195165634e-02
    z[2,5,3]  R1784     4.1575622558593750e-01
    z[2,5,3]  R1785     -1.5586887300014496e-01
    z[2,5,3]  R1786     -3.8521891832351685e-01
    z[2,5,3]  R1787     -6.8435288965702057e-02
    z[2,5,3]  R1788     5.9285301715135574e-02
    z[2,5,3]  R1789     5.6945491582155228e-02
    z[2,5,3]  R1790     3.5616809129714966e-01
    z[2,5,3]  R1791     7.6187252998352051e-01
    z[2,5,3]  R1792     7.9293966293334961e-01
    z[2,5,3]  R1793     4.6142944693565369e-01
    z[2,5,3]  R1794     2.7731695771217346e-01
    z[2,5,3]  R1795     3.4239280223846436e-01
    z[2,5,3]  R1796     -2.7753153443336487e-01
    z[2,5,3]  R1797     4.9526520073413849e-02
    z[2,5,3]  R1798     -2.2915895283222198e-01
    z[2,5,3]  R1799     8.4319151937961578e-02
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1684     -1
    z[2,5,4]  R1685     1
    z[2,5,4]  R1690     7.3111318051815033e-02
    z[2,5,4]  R1691     -1.1375582218170166e-01
    z[2,5,4]  R1692     -8.2537800073623657e-02
    z[2,5,4]  R1693     -1.7899218201637268e-01
    z[2,5,4]  R1694     8.0192521214485168e-02
    z[2,5,4]  R1695     -3.0449113249778748e-01
    z[2,5,4]  R1696     -1.2869222462177277e-01
    z[2,5,4]  R1697     -4.6238997578620911e-01
    z[2,5,4]  R1698     -4.5858058333396912e-01
    z[2,5,4]  R1699     0.305789053440094
    z[2,5,4]  R1700     -0.0898180678486824
    z[2,5,4]  R1701     -3.7596827745437622e-01
    z[2,5,4]  R1702     -3.4587970376014709e-01
    z[2,5,4]  R1703     -4.2784112691879272e-01
    z[2,5,4]  R1704     -1.5457729995250702e-01
    z[2,5,4]  R1705     -2.0413650572299957e-01
    z[2,5,4]  R1706     -0.0776323527097702
    z[2,5,4]  R1707     1.2053133547306061e-01
    z[2,5,4]  R1708     -2.6265475153923035e-01
    z[2,5,4]  R1709     2.7353662252426147e-01
    z[2,5,4]  R1710     -2.8498631715774536e-01
    z[2,5,4]  R1711     4.1087669134140015e-01
    z[2,5,4]  R1712     -2.8536498546600342e-01
    z[2,5,4]  R1713     -2.8570872545242310e-01
    z[2,5,4]  R1714     -4.2396214604377747e-01
    z[2,5,4]  R1715     -9.6188765019178391e-03
    z[2,5,4]  R1716     3.5438543558120728e-01
    z[2,5,4]  R1717     -2.7970872819423676e-02
    z[2,5,4]  R1718     5.9508824348449707e-01
    z[2,5,4]  R1719     5.2050441503524780e-01
    z[2,5,4]  R1720     2.5748616456985474e-01
    z[2,5,4]  R1721     -2.1077752113342285e-01
    z[2,5,4]  R1722     2.1719934046268463e-01
    z[2,5,4]  R1723     2.3210911080241203e-02
    z[2,5,4]  R1724     2.5619903206825256e-01
    z[2,5,4]  R1725     -2.3334741592407227e-01
    z[2,5,4]  R1726     3.4386062622070312e-01
    z[2,5,4]  R1727     2.8850868344306946e-01
    z[2,5,4]  R1728     2.9008671641349792e-01
    z[2,5,4]  R1729     2.1807883679866791e-01
    z[2,5,4]  R1730     3.7299329042434692e-01
    z[2,5,4]  R1731     3.3229142427444458e-02
    z[2,5,4]  R1732     0.216078981757164
    z[2,5,4]  R1733     2.6762318611145020e-01
    z[2,5,4]  R1734     -1.2383381277322769e-01
    z[2,5,4]  R1735     -7.6574023114517331e-04
    z[2,5,4]  R1736     3.4473296999931335e-01
    z[2,5,4]  R1737     -4.5324954390525818e-01
    z[2,5,4]  R1738     -9.6704736351966858e-03
    z[2,5,4]  R1739     1.6221849620342255e-01
    z[2,5,4]  R1740     -0.407550185918808
    z[2,5,4]  R1741     1.0992280393838882e-01
    z[2,5,4]  R1742     -6.1532676219940186e-02
    z[2,5,4]  R1743     -5.0204541534185410e-02
    z[2,5,4]  R1744     -4.9264460802078247e-01
    z[2,5,4]  R1745     -2.8671622276306152e-01
    z[2,5,4]  R1746     2.6149597018957138e-02
    z[2,5,4]  R1747     7.3123171925544739e-02
    z[2,5,4]  R1748     4.4613435864448547e-02
    z[2,5,4]  R1749     -0.0691533163189888
    z[2,5,4]  R1750     0.07137431204319
    z[2,5,4]  R1751     2.4950174987316132e-01
    z[2,5,4]  R1752     1.0654534399509430e-01
    z[2,5,4]  R1753     -4.5509532094001770e-01
    z[2,5,4]  R1754     -3.6515191197395325e-01
    z[2,5,4]  R1755     -0.416479229927063
    z[2,5,4]  R1756     -4.0927022695541382e-01
    z[2,5,4]  R1757     -1.9846189022064209e-01
    z[2,5,4]  R1758     -1.9453060626983643e-01
    z[2,5,4]  R1759     3.6199086904525757e-01
    z[2,5,4]  R1760     6.9938585162162781e-02
    z[2,5,4]  R1761     -1.3595966994762421e-01
    z[2,5,4]  R1762     -1.5079443156719208e-01
    z[2,5,4]  R1763     -4.1097655892372131e-02
    z[2,5,4]  R1764     2.1752344444394112e-02
    z[2,5,4]  R1765     -1.8148691952228546e-01
    z[2,5,4]  R1766     1.0181655734777451e-01
    z[2,5,4]  R1767     6.8882554769515991e-01
    z[2,5,4]  R1768     4.0979516506195068e-01
    z[2,5,4]  R1769     0.576056957244873
    z[2,5,4]  R1770     2.0964258909225464e-01
    z[2,5,4]  R1771     3.7249827384948730e-01
    z[2,5,4]  R1772     -1.2518243491649628e-01
    z[2,5,4]  R1773     -2.4802911281585693e-01
    z[2,5,4]  R1774     7.4077457189559937e-02
    z[2,5,4]  R1775     1.6445495188236237e-01
    z[2,5,4]  R1776     -1.8125905096530914e-01
    z[2,5,4]  R1777     4.0912351012229919e-01
    z[2,5,4]  R1778     5.2063208818435669e-01
    z[2,5,4]  R1779     3.7820154428482056e-01
    z[2,5,4]  R1780     4.0455322712659836e-02
    z[2,5,4]  R1781     -1.0657750535756350e-03
    z[2,5,4]  R1782     -4.4077765941619873e-01
    z[2,5,4]  R1783     1.6311611235141754e-01
    z[2,5,4]  R1784     -3.8399747014045715e-01
    z[2,5,4]  R1785     -2.7723035216331482e-01
    z[2,5,4]  R1786     1.5596590936183929e-01
    z[2,5,4]  R1787     -5.1666635274887085e-01
    z[2,5,4]  R1788     -4.1069126129150391e-01
    z[2,5,4]  R1789     3.2260903716087341e-01
    z[2,5,4]  R1790     4.1462130844593048e-02
    z[2,5,4]  R1791     -1.7017647624015808e-01
    z[2,5,4]  R1792     5.4746586829423904e-02
    z[2,5,4]  R1793     -3.8583523035049438e-01
    z[2,5,4]  R1794     -2.4354654550552368e-01
    z[2,5,4]  R1795     3.6474749445915222e-01
    z[2,5,4]  R1796     -2.8474736213684082e-01
    z[2,5,4]  R1797     4.2725983262062073e-01
    z[2,5,4]  R1798     5.4021787643432617e-01
    z[2,5,4]  R1799     -4.9213051795959473e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1686     -1
    z[2,5,5]  R1687     1
    z[2,5,5]  R1690     -2.0992338657379150e-01
    z[2,5,5]  R1691     6.0002353042364120e-02
    z[2,5,5]  R1692     2.1711468696594238e-01
    z[2,5,5]  R1693     2.1944953128695488e-02
    z[2,5,5]  R1694     -3.0375117063522339e-01
    z[2,5,5]  R1695     0.174501433968544
    z[2,5,5]  R1696     -4.4397312402725220e-01
    z[2,5,5]  R1697     -1.2243715673685074e-01
    z[2,5,5]  R1698     -4.3224963545799255e-01
    z[2,5,5]  R1699     1.7003849148750305e-01
    z[2,5,5]  R1700     -1.8312266469001770e-01
    z[2,5,5]  R1701     -4.2208548984490335e-04
    z[2,5,5]  R1702     -1.7857927083969116e-01
    z[2,5,5]  R1703     1.4842978678643703e-02
    z[2,5,5]  R1704     -6.8562075495719910e-02
    z[2,5,5]  R1705     -1.3925287127494812e-01
    z[2,5,5]  R1706     -3.6532059311866760e-01
    z[2,5,5]  R1707     -3.4194344282150269e-01
    z[2,5,5]  R1708     -5.0903332233428955e-01
    z[2,5,5]  R1709     -3.8409563899040222e-01
    z[2,5,5]  R1710     2.0312181115150452e-01
    z[2,5,5]  R1711     -2.6462316513061523e-02
    z[2,5,5]  R1712     -1.6600729897618294e-02
    z[2,5,5]  R1713     2.4125227332115173e-01
    z[2,5,5]  R1714     4.7427029348909855e-03
    z[2,5,5]  R1715     -1.4630095660686493e-01
    z[2,5,5]  R1716     1.6965536773204803e-01
    z[2,5,5]  R1717     6.9013011455535889e-01
    z[2,5,5]  R1718     1.9435566663742065e-01
    z[2,5,5]  R1719     1.5157592296600342e-01
    z[2,5,5]  R1720     7.7136784791946411e-02
    z[2,5,5]  R1721     -5.7041305303573608e-01
    z[2,5,5]  R1722     4.2971007525920868e-02
    z[2,5,5]  R1723     2.3333853483200073e-01
    z[2,5,5]  R1724     -4.1894045472145081e-01
    z[2,5,5]  R1725     3.3118382096290588e-01
    z[2,5,5]  R1726     -2.5302490592002869e-01
    z[2,5,5]  R1727     1.1748849600553513e-01
    z[2,5,5]  R1728     5.8008664846420288e-01
    z[2,5,5]  R1729     -2.6482850313186646e-01
    z[2,5,5]  R1730     3.0217874050140381e-01
    z[2,5,5]  R1731     2.3517285287380219e-01
    z[2,5,5]  R1732     -1.0395722091197968e-01
    z[2,5,5]  R1733     0.1573476344347
    z[2,5,5]  R1734     4.9449086189270020e-01
    z[2,5,5]  R1735     -4.0731698274612427e-01
    z[2,5,5]  R1736     -3.3146545290946960e-01
    z[2,5,5]  R1737     -9.0212017297744751e-02
    z[2,5,5]  R1738     5.5188196897506714e-01
    z[2,5,5]  R1739     8.6244657635688782e-02
    z[2,5,5]  R1740     -6.6448740661144257e-02
    z[2,5,5]  R1741     -2.0032858848571777e-01
    z[2,5,5]  R1742     -4.6768745779991150e-01
    z[2,5,5]  R1743     5.4006807506084442e-02
    z[2,5,5]  R1744     -3.8019725680351257e-01
    z[2,5,5]  R1745     -2.8030180931091309e-01
    z[2,5,5]  R1746     -0.13898965716362
    z[2,5,5]  R1747     4.4669758528470993e-02
    z[2,5,5]  R1748     1.2786471843719482e-01
    z[2,5,5]  R1749     -1.5990903973579407e-01
    z[2,5,5]  R1750     2.9171234369277954e-01
    z[2,5,5]  R1751     2.6608529686927795e-01
    z[2,5,5]  R1752     1.8212196230888367e-01
    z[2,5,5]  R1753     -3.5044002532958984e-01
    z[2,5,5]  R1754     3.0996114015579224e-01
    z[2,5,5]  R1755     1.8105560541152954e-01
    z[2,5,5]  R1756     7.2475492954254150e-02
    z[2,5,5]  R1757     3.5527545213699341e-01
    z[2,5,5]  R1758     2.4875281751155853e-01
    z[2,5,5]  R1759     3.3961758017539978e-01
    z[2,5,5]  R1760     1.3228674232959747e-01
    z[2,5,5]  R1761     2.4678136408329010e-01
    z[2,5,5]  R1762     2.2562603652477264e-01
    z[2,5,5]  R1763     7.9707249999046326e-02
    z[2,5,5]  R1764     -2.2326244413852692e-01
    z[2,5,5]  R1765     2.3951642215251923e-01
    z[2,5,5]  R1766     1.1684230715036392e-01
    z[2,5,5]  R1767     2.3714546859264374e-01
    z[2,5,5]  R1768     -1.2539631128311157e-01
    z[2,5,5]  R1769     3.4624379873275757e-01
    z[2,5,5]  R1770     -4.3736483901739120e-02
    z[2,5,5]  R1771     0.495735228061676
    z[2,5,5]  R1772     -2.8402847051620483e-01
    z[2,5,5]  R1773     -4.0881112217903137e-01
    z[2,5,5]  R1774     4.6252843737602234e-01
    z[2,5,5]  R1775     2.7142751216888428e-01
    z[2,5,5]  R1776     5.7872855663299561e-01
    z[2,5,5]  R1777     -3.0829516053199768e-01
    z[2,5,5]  R1778     -2.7387544512748718e-01
    z[2,5,5]  R1779     -1.7499661445617676e-01
    z[2,5,5]  R1780     -5.5390429496765137e-01
    z[2,5,5]  R1781     8.0321721732616425e-02
    z[2,5,5]  R1782     -3.3402532339096069e-01
    z[2,5,5]  R1783     -7.4996486306190491e-02
    z[2,5,5]  R1784     -2.1256893873214722e-01
    z[2,5,5]  R1785     -4.5390984416007996e-01
    z[2,5,5]  R1786     2.7678820490837097e-01
    z[2,5,5]  R1787     -5.7354439049959183e-02
    z[2,5,5]  R1788     1.0543572902679443e-01
    z[2,5,5]  R1789     2.4937982857227325e-01
    z[2,5,5]  R1790     1.0438472777605057e-01
    z[2,5,5]  R1791     3.7046140432357788e-01
    z[2,5,5]  R1792     1.9523890316486359e-01
    z[2,5,5]  R1793     -1.6952624917030334e-01
    z[2,5,5]  R1794     -1.2062735855579376e-01
    z[2,5,5]  R1795     -1.1992149800062180e-01
    z[2,5,5]  R1796     1.9417542219161987e-01
    z[2,5,5]  R1797     2.3745548725128174e-01
    z[2,5,5]  R1798     4.2656177282333374e-01
    z[2,5,5]  R1799     3.4880742430686951e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1688     -1
    z[2,5,6]  R1689     1
    z[2,5,6]  R1690     4.8072773218154907e-01
    z[2,5,6]  R1691     1.8467712402343750e-01
    z[2,5,6]  R1692     4.4496819376945496e-01
    z[2,5,6]  R1693     -1.3334497809410095e-01
    z[2,5,6]  R1694     -3.8611200451850891e-01
    z[2,5,6]  R1695     4.0329754352569580e-01
    z[2,5,6]  R1696     -4.5594829320907593e-01
    z[2,5,6]  R1697     -2.2571486234664917e-01
    z[2,5,6]  R1698     3.4922768827527761e-03
    z[2,5,6]  R1699     5.3784966468811035e-01
    z[2,5,6]  R1700     2.9884090647101402e-02
    z[2,5,6]  R1701     -3.0452278256416321e-01
    z[2,5,6]  R1702     2.2463712841272354e-02
    z[2,5,6]  R1703     5.0114914774894714e-02
    z[2,5,6]  R1704     3.7714502215385437e-01
    z[2,5,6]  R1705     1.0475924611091614e-01
    z[2,5,6]  R1706     2.8772982954978943e-01
    z[2,5,6]  R1707     -1.2541884183883667e-01
    z[2,5,6]  R1708     -1.1786801740527153e-02
    z[2,5,6]  R1709     -5.2705653011798859e-02
    z[2,5,6]  R1710     -1.4552329480648041e-01
    z[2,5,6]  R1711     -7.2948947548866272e-02
    z[2,5,6]  R1712     -5.5890363454818726e-01
    z[2,5,6]  R1713     -3.5005655884742737e-01
    z[2,5,6]  R1714     -6.2761205434799194e-01
    z[2,5,6]  R1715     -0.382338285446167
    z[2,5,6]  R1716     -3.0575555562973022e-01
    z[2,5,6]  R1717     -2.7842029929161072e-01
    z[2,5,6]  R1718     -4.0848350524902344e-01
    z[2,5,6]  R1719     -2.7487668395042419e-01
    z[2,5,6]  R1720     -2.3937320336699486e-02
    z[2,5,6]  R1721     -8.3725750446319580e-02
    z[2,5,6]  R1722     -1.6932488977909088e-01
    z[2,5,6]  R1723     8.9579321444034576e-02
    z[2,5,6]  R1724     -3.2548922300338745e-01
    z[2,5,6]  R1725     5.2447974681854248e-01
    z[2,5,6]  R1726     -2.0602095872163773e-02
    z[2,5,6]  R1727     -0.640866756439209
    z[2,5,6]  R1728     -1.3373306393623352e-01
    z[2,5,6]  R1729     -3.6413770914077759e-01
    z[2,5,6]  R1730     4.9902126193046570e-01
    z[2,5,6]  R1731     -2.0717842876911163e-01
    z[2,5,6]  R1732     0.100248783826828
    z[2,5,6]  R1733     -1.3530507683753967e-01
    z[2,5,6]  R1734     -3.4942036867141724e-01
    z[2,5,6]  R1735     -0.0379759818315506
    z[2,5,6]  R1736     1.4620022475719452e-01
    z[2,5,6]  R1737     1.9696770608425140e-01
    z[2,5,6]  R1738     -4.0968382358551025e-01
    z[2,5,6]  R1739     -4.4251814484596252e-01
    z[2,5,6]  R1740     1.2498059123754501e-01
    z[2,5,6]  R1741     4.2947977781295776e-01
    z[2,5,6]  R1742     -1.3333770632743835e-01
    z[2,5,6]  R1743     -4.9427023530006409e-01
    z[2,5,6]  R1744     1.4493362046778202e-02
    z[2,5,6]  R1745     -1.5661749243736267e-01
    z[2,5,6]  R1746     -5.1733326911926270e-01
    z[2,5,6]  R1747     -9.7482755780220032e-02
    z[2,5,6]  R1748     -3.5410153865814209e-01
    z[2,5,6]  R1749     -9.4195976853370667e-02
    z[2,5,6]  R1750     1.8198034167289734e-01
    z[2,5,6]  R1751     3.3990573883056641e-01
    z[2,5,6]  R1752     3.3872240781784058e-01
    z[2,5,6]  R1753     -3.4064075350761414e-01
    z[2,5,6]  R1754     -3.0538308620452881e-01
    z[2,5,6]  R1755     3.7478078156709671e-02
    z[2,5,6]  R1756     3.4675487875938416e-01
    z[2,5,6]  R1757     -1.0166209936141968e-01
    z[2,5,6]  R1758     -2.6171153783798218e-01
    z[2,5,6]  R1759     1.4266893267631531e-01
    z[2,5,6]  R1760     -5.8515619486570358e-02
    z[2,5,6]  R1761     1.2529952824115753e-01
    z[2,5,6]  R1762     -2.9958526138216257e-03
    z[2,5,6]  R1763     -4.2302541434764862e-02
    z[2,5,6]  R1764     3.5392352938652039e-01
    z[2,5,6]  R1765     -5.5908089876174927e-01
    z[2,5,6]  R1766     -5.4546225070953369e-01
    z[2,5,6]  R1767     1.0424774140119553e-01
    z[2,5,6]  R1768     6.5992519259452820e-02
    z[2,5,6]  R1769     1.5303359925746918e-01
    z[2,5,6]  R1770     2.1497702226042747e-02
    z[2,5,6]  R1771     -2.2102083265781403e-01
    z[2,5,6]  R1772     2.1728539466857910e-01
    z[2,5,6]  R1773     4.6085428446531296e-02
    z[2,5,6]  R1774     -2.3642720654606819e-02
    z[2,5,6]  R1775     1.0196760296821594e-01
    z[2,5,6]  R1776     -9.2297062277793884e-02
    z[2,5,6]  R1777     7.1000531315803528e-02
    z[2,5,6]  R1778     1.1236649006605148e-01
    z[2,5,6]  R1779     0.645663321018219
    z[2,5,6]  R1780     -2.7977797389030457e-01
    z[2,5,6]  R1781     3.2469874620437622e-01
    z[2,5,6]  R1782     -3.9274501800537109e-01
    z[2,5,6]  R1783     -8.7665893137454987e-02
    z[2,5,6]  R1784     -3.5648101568222046e-01
    z[2,5,6]  R1785     -4.0034556388854980e-01
    z[2,5,6]  R1786     -7.9675689339637756e-02
    z[2,5,6]  R1787     -2.2472733259201050e-01
    z[2,5,6]  R1788     -3.9812245965003967e-01
    z[2,5,6]  R1789     -1.7418856918811798e-01
    z[2,5,6]  R1790     4.7403600811958313e-01
    z[2,5,6]  R1791     4.1254632174968719e-02
    z[2,5,6]  R1792     6.2351156026124954e-02
    z[2,5,6]  R1793     4.0722902864217758e-02
    z[2,5,6]  R1794     -5.3125196695327759e-01
    z[2,5,6]  R1795     3.5758140683174133e-01
    z[2,5,6]  R1796     -5.9704118967056274e-01
    z[2,5,6]  R1797     -3.0509895086288452e-01
    z[2,5,6]  R1798     -2.7958011627197266e-01
    z[2,5,6]  R1799     -2.9956376552581787e-01
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1800     -1
    z[5,2,0]  R1801     1
    z[5,2,0]  R1814     4.4905692338943481e-02
    z[5,2,0]  R1815     2.7488011121749878e-01
    z[5,2,0]  R1816     4.9197757244110107e-01
    z[5,2,0]  R1817     -1.0621292144060135e-01
    z[5,2,0]  R1818     3.2745444774627686e-01
    z[5,2,0]  R1819     3.9802014827728271e-01
    z[5,2,0]  R1820     3.4995537996292114e-01
    z[5,2,0]  R1821     -1.5063305199146271e-01
    z[5,2,0]  R1822     4.7343918681144714e-01
    z[5,2,0]  R1823     -2.1048258244991302e-01
    z[5,2,0]  R1824     3.3840200304985046e-01
    z[5,2,0]  R1825     4.9328714609146118e-02
    z[5,2,0]  R1826     1.6332606971263885e-01
    z[5,2,0]  R1827     0.0453437939286232
    z[5,2,0]  R1828     1.0652531683444977e-01
    z[5,2,0]  R1829     1.7694209516048431e-01
    z[5,2,0]  R1830     3.9981940388679504e-01
    z[5,2,0]  R1831     -3.0972000211477280e-02
    z[5,2,0]  R1832     1.7476992681622505e-02
    z[5,2,0]  R1833     -1.1291588842868805e-01
    z[5,2,0]  R1834     -1.9607307389378548e-02
    z[5,2,0]  R1835     4.8747184872627258e-01
    z[5,2,0]  R1836     1.8454360961914062e-01
    z[5,2,0]  R1837     8.6628451943397522e-02
    z[5,2,0]  R1838     -4.6332213096320629e-03
    z[5,2,0]  R1839     -0.133395716547966
    z[5,2,0]  R1840     -3.1193557381629944e-01
    z[5,2,0]  R1841     -2.5365066528320312e-01
    z[5,2,0]  R1842     -5.2966989576816559e-02
    z[5,2,0]  R1843     -1.6295957565307617e-01
    z[5,2,0]  R1844     4.2942172288894653e-01
    z[5,2,0]  R1845     -2.3111522197723389e-01
    z[5,2,0]  R1846     5.0620734691619873e-01
    z[5,2,0]  R1847     3.2991644740104675e-01
    z[5,2,0]  R1848     -8.9085623621940613e-02
    z[5,2,0]  R1849     -5.8000821620225906e-02
    z[5,2,0]  R1850     3.1568494439125061e-01
    z[5,2,0]  R1851     1.6023042798042297e-01
    z[5,2,0]  R1852     -2.2212259471416473e-01
    z[5,2,0]  R1853     3.0740559101104736e-01
    z[5,2,0]  R1854     -9.0094543993473053e-02
    z[5,2,0]  R1855     3.9716640114784241e-01
    z[5,2,0]  R1856     -2.3172914981842041e-01
    z[5,2,0]  R1857     1.7375090718269348e-01
    z[5,2,0]  R1858     2.0802558958530426e-01
    z[5,2,0]  R1859     -2.7975955605506897e-01
    z[5,2,0]  R1860     -0.29337078332901
    z[5,2,0]  R1861     -1.1495106155052781e-03
    z[5,2,0]  R1862     -1.6729475557804108e-01
    z[5,2,0]  R1863     -4.1556453704833984e-01
    z[5,2,0]  R1864     -1.5465673059225082e-02
    z[5,2,0]  R1865     1.2804825603961945e-01
    z[5,2,0]  R1866     1.2401670217514038e-01
    z[5,2,0]  R1867     1.9561153650283813e-01
    z[5,2,0]  R1868     3.1262066960334778e-01
    z[5,2,0]  R1869     1.5708579123020172e-01
    z[5,2,0]  R1870     1.5607194602489471e-01
    z[5,2,0]  R1871     4.3293327093124390e-01
    z[5,2,0]  R1872     1.9849990308284760e-01
    z[5,2,0]  R1873     2.9485905170440674e-01
    z[5,2,0]  R1874     2.0168526470661163e-01
    z[5,2,0]  R1875     7.4236601591110229e-01
    z[5,2,0]  R1876     6.3519030809402466e-01
    z[5,2,0]  R1877     8.2694751024246216e-01
    z[5,2,0]  R1878     0.732430636882782
    z[5,2,0]  R1879     6.9434732198715210e-01
    z[5,2,0]  R1880     5.0212305784225464e-01
    z[5,2,0]  R1881     5.2095401287078857e-01
    z[5,2,0]  R1882     5.2552109956741333e-01
    z[5,2,0]  R1883     0.565981388092041
    z[5,2,0]  R1884     -2.8693279623985291e-01
    z[5,2,0]  R1885     -2.2875705361366272e-01
    z[5,2,0]  R1886     -3.7252682447433472e-01
    z[5,2,0]  R1887     -3.4144580364227295e-02
    z[5,2,0]  R1888     -1.2130939960479736e-01
    z[5,2,0]  R1889     -0.24737648665905
    z[5,2,0]  R1890     -3.2693052291870117e-01
    z[5,2,0]  R1891     -7.0166802406311035e-01
    z[5,2,0]  R1892     -5.1734834909439087e-01
    z[5,2,0]  R1893     -6.8399560451507568e-01
    z[5,2,0]  R1894     2.5814792513847351e-01
    z[5,2,0]  R1895     2.5163169950246811e-02
    z[5,2,0]  R1896     -2.8755296953022480e-03
    z[5,2,0]  R1897     -9.6380099654197693e-02
    z[5,2,0]  R1898     5.5131424218416214e-02
    z[5,2,0]  R1899     -3.4453833103179932e-01
    z[5,2,0]  R1900     3.0919777229428291e-02
    z[5,2,0]  R1901     4.4574152678251266e-02
    z[5,2,0]  R1902     -2.1453756093978882e-01
    z[5,2,0]  R1903     -4.7364017367362976e-01
    z[5,2,0]  R1904     4.5386686921119690e-01
    z[5,2,0]  R1905     5.7206705212593079e-02
    z[5,2,0]  R1906     -2.5209262967109680e-01
    z[5,2,0]  R1907     1.3466119766235352e-02
    z[5,2,0]  R1908     -3.8344639539718628e-01
    z[5,2,0]  R1909     -1.2124659866094589e-01
    z[5,2,0]  R1910     -4.3595591187477112e-01
    z[5,2,0]  R1911     -3.0036526918411255e-01
    z[5,2,0]  R1912     1.9480532407760620e-01
    z[5,2,0]  R1913     -1.3827045261859894e-01
    z[5,2,0]  R1914     2.8657663613557816e-02
    z[5,2,0]  R1915     2.7474978566169739e-01
    z[5,2,0]  R1916     -5.2531582117080688e-01
    z[5,2,0]  R1917     -4.8632583022117615e-01
    z[5,2,0]  R1918     3.1036838889122009e-01
    z[5,2,0]  R1919     -5.6225264072418213e-01
    z[5,2,0]  R1920     9.9852740764617920e-02
    z[5,2,0]  R1921     7.0530459284782410e-02
    z[5,2,0]  R1922     -2.4579961597919464e-01
    z[5,2,0]  R1923     -5.8534210920333862e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1802     -1
    z[5,2,1]  R1803     1
    z[5,2,1]  R1814     -6.8122547864913940e-01
    z[5,2,1]  R1815     -6.7748540639877319e-01
    z[5,2,1]  R1816     6.7459249496459961e-01
    z[5,2,1]  R1817     -8.1346917152404785e-01
    z[5,2,1]  R1818     -7.0029234886169434e-01
    z[5,2,1]  R1819     5.2877306938171387e-01
    z[5,2,1]  R1820     5.9612405300140381e-01
    z[5,2,1]  R1821     -1.8770109117031097e-01
    z[5,2,1]  R1822     5.2165532112121582e-01
    z[5,2,1]  R1823     8.9386940002441406e-01
    z[5,2,1]  R1824     8.1641274690628052e-01
    z[5,2,1]  R1825     8.4431940317153931e-01
    z[5,2,1]  R1826     -2.0611999928951263e-01
    z[5,2,1]  R1827     -6.5368312597274780e-01
    z[5,2,1]  R1828     -2.7324327826499939e-01
    z[5,2,1]  R1829     7.9011809825897217e-01
    z[5,2,1]  R1830     6.1137682199478149e-01
    z[5,2,1]  R1831     2.6357316970825195e-01
    z[5,2,1]  R1832     -4.6956473588943481e-01
    z[5,2,1]  R1833     1.1211547255516052e-01
    z[5,2,1]  R1834     -8.9405238628387451e-01
    z[5,2,1]  R1835     0.65756756067276
    z[5,2,1]  R1836     8.2068479061126709e-01
    z[5,2,1]  R1837     -0.741539478302002
    z[5,2,1]  R1838     0.904663622379303
    z[5,2,1]  R1839     -5.9420973062515259e-01
    z[5,2,1]  R1840     -0.470384418964386
    z[5,2,1]  R1841     -3.7736091017723083e-01
    z[5,2,1]  R1842     -8.1561100482940674e-01
    z[5,2,1]  R1843     -5.2647686004638672e-01
    z[5,2,1]  R1844     6.3006180524826050e-01
    z[5,2,1]  R1845     -4.2134487628936768e-01
    z[5,2,1]  R1846     0.691325306892395
    z[5,2,1]  R1847     -0.750025749206543
    z[5,2,1]  R1848     -6.0750845819711685e-02
    z[5,2,1]  R1849     1.1036308109760284e-01
    z[5,2,1]  R1850     0.545853316783905
    z[5,2,1]  R1851     7.5227451324462891e-01
    z[5,2,1]  R1852     -5.3734356164932251e-01
    z[5,2,1]  R1853     4.6872133016586304e-01
    z[5,2,1]  R1854     -7.4568390846252441e-01
    z[5,2,1]  R1855     -8.3605545759201050e-01
    z[5,2,1]  R1856     -6.1399626731872559e-01
    z[5,2,1]  R1857     6.9033062458038330e-01
    z[5,2,1]  R1858     6.4332503080368042e-01
    z[5,2,1]  R1859     5.5489885807037354e-01
    z[5,2,1]  R1860     6.9776940345764160e-01
    z[5,2,1]  R1861     4.6602910757064819e-01
    z[5,2,1]  R1862     5.1794224977493286e-01
    z[5,2,1]  R1863     7.5704419612884521e-01
    z[5,2,1]  R1864     -7.6356285810470581e-01
    z[5,2,1]  R1865     -2.0082026720046997e-01
    z[5,2,1]  R1866     -5.0230443477630615e-01
    z[5,2,1]  R1867     7.5273811817169189e-01
    z[5,2,1]  R1868     6.8352770805358887e-01
    z[5,2,1]  R1869     -6.8227595090866089e-01
    z[5,2,1]  R1870     5.6851136684417725e-01
    z[5,2,1]  R1871     5.7080060243606567e-01
    z[5,2,1]  R1872     5.5767953395843506e-01
    z[5,2,1]  R1873     -0.652384340763092
    z[5,2,1]  R1874     -8.1922346353530884e-01
    z[5,2,1]  R1875     4.4056215882301331e-01
    z[5,2,1]  R1876     5.2807974815368652e-01
    z[5,2,1]  R1877     4.5687785744667053e-01
    z[5,2,1]  R1878     4.2076438665390015e-01
    z[5,2,1]  R1879     4.7686314582824707e-01
    z[5,2,1]  R1880     5.5727756023406982e-01
    z[5,2,1]  R1881     0.628750741481781
    z[5,2,1]  R1882     0.564632773399353
    z[5,2,1]  R1883     5.0390481948852539e-01
    z[5,2,1]  R1884     9.3186748027801514e-01
    z[5,2,1]  R1885     8.1989574432373047e-01
    z[5,2,1]  R1886     6.3152486085891724e-01
    z[5,2,1]  R1887     0.871233344078064
    z[5,2,1]  R1888     6.4237689971923828e-01
    z[5,2,1]  R1889     5.5604827404022217e-01
    z[5,2,1]  R1890     0.612606406211853
    z[5,2,1]  R1891     2.4693058431148529e-01
    z[5,2,1]  R1892     1.0127270966768265e-01
    z[5,2,1]  R1893     4.4768798351287842e-01
    z[5,2,1]  R1894     0.767442524433136
    z[5,2,1]  R1895     -0.16782146692276
    z[5,2,1]  R1896     -0.505316972732544
    z[5,2,1]  R1897     -6.2347787618637085e-01
    z[5,2,1]  R1898     -5.5880290269851685e-01
    z[5,2,1]  R1899     -6.9875997304916382e-01
    z[5,2,1]  R1900     -5.7810330390930176e-01
    z[5,2,1]  R1901     6.2407189607620239e-01
    z[5,2,1]  R1902     -0.574478030204773
    z[5,2,1]  R1903     6.3457864522933960e-01
    z[5,2,1]  R1904     8.3791959285736084e-01
    z[5,2,1]  R1905     -7.3148196935653687e-01
    z[5,2,1]  R1906     -8.3641594648361206e-01
    z[5,2,1]  R1907     -5.9700292348861694e-01
    z[5,2,1]  R1908     -7.0138669013977051e-01
    z[5,2,1]  R1909     -0.52411288022995
    z[5,2,1]  R1910     -5.8007371425628662e-01
    z[5,2,1]  R1911     -5.7386624813079834e-01
    z[5,2,1]  R1912     -7.1420305967330933e-01
    z[5,2,1]  R1913     -0.469468891620636
    z[5,2,1]  R1914     -6.7077857255935669e-01
    z[5,2,1]  R1915     4.9553334712982178e-01
    z[5,2,1]  R1916     6.4749163389205933e-01
    z[5,2,1]  R1917     7.4309313297271729e-01
    z[5,2,1]  R1918     -6.7778146266937256e-01
    z[5,2,1]  R1919     -1.6208501160144806e-01
    z[5,2,1]  R1920     3.5068961977958679e-01
    z[5,2,1]  R1921     -4.7770828008651733e-01
    z[5,2,1]  R1922     5.9483128786087036e-01
    z[5,2,1]  R1923     4.7563686966896057e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1804     -1
    z[5,2,2]  R1805     1
    z[5,2,2]  R1814     -2.5429481267929077e-01
    z[5,2,2]  R1815     -4.7350153326988220e-01
    z[5,2,2]  R1816     -1.6671952605247498e-01
    z[5,2,2]  R1817     -6.9923691451549530e-02
    z[5,2,2]  R1818     5.1851324737071991e-02
    z[5,2,2]  R1819     -6.2837436795234680e-02
    z[5,2,2]  R1820     -1.7073693871498108e-01
    z[5,2,2]  R1821     -4.8172447085380554e-01
    z[5,2,2]  R1822     -5.1995605230331421e-01
    z[5,2,2]  R1823     -5.7836681604385376e-02
    z[5,2,2]  R1824     2.4669414758682251e-01
    z[5,2,2]  R1825     -1.1313141882419586e-01
    z[5,2,2]  R1826     -1.0266650468111038e-01
    z[5,2,2]  R1827     2.6764890551567078e-01
    z[5,2,2]  R1828     1.7920050024986267e-01
    z[5,2,2]  R1829     3.4833726286888123e-01
    z[5,2,2]  R1830     3.7064486742019653e-01
    z[5,2,2]  R1831     -0.321865051984787
    z[5,2,2]  R1832     -2.4265077710151672e-01
    z[5,2,2]  R1833     3.4573718905448914e-01
    z[5,2,2]  R1834     -1.5769918262958527e-01
    z[5,2,2]  R1835     -4.5038771629333496e-01
    z[5,2,2]  R1836     -3.4964182972908020e-01
    z[5,2,2]  R1837     -4.9290037155151367e-01
    z[5,2,2]  R1838     -7.1905307471752167e-02
    z[5,2,2]  R1839     -1.6450406610965729e-01
    z[5,2,2]  R1840     9.9394604563713074e-02
    z[5,2,2]  R1841     1.7148096859455109e-01
    z[5,2,2]  R1842     1.2626454234123230e-01
    z[5,2,2]  R1843     -3.3183717727661133e-01
    z[5,2,2]  R1844     3.0751636624336243e-01
    z[5,2,2]  R1845     2.0369198918342590e-01
    z[5,2,2]  R1846     0.282680869102478
    z[5,2,2]  R1847     3.1261113286018372e-01
    z[5,2,2]  R1848     -5.2417612075805664e-01
    z[5,2,2]  R1849     1.0222312062978745e-01
    z[5,2,2]  R1850     3.1969651579856873e-01
    z[5,2,2]  R1851     -2.1627022325992584e-01
    z[5,2,2]  R1852     -3.8786804676055908e-01
    z[5,2,2]  R1853     4.1406969539821148e-03
    z[5,2,2]  R1854     3.2021556049585342e-02
    z[5,2,2]  R1855     1.3430744409561157e-01
    z[5,2,2]  R1856     -2.9622071981430054e-01
    z[5,2,2]  R1857     -6.7097288370132446e-01
    z[5,2,2]  R1858     2.2424674034118652e-01
    z[5,2,2]  R1859     -3.8256937265396118e-01
    z[5,2,2]  R1860     -4.1397172212600708e-01
    z[5,2,2]  R1861     -0.676310658454895
    z[5,2,2]  R1862     -6.0162127017974854e-01
    z[5,2,2]  R1863     2.3310698568820953e-01
    z[5,2,2]  R1864     -2.2924098372459412e-01
    z[5,2,2]  R1865     -4.4149917364120483e-01
    z[5,2,2]  R1866     2.4197886884212494e-01
    z[5,2,2]  R1867     -5.4202873259782791e-02
    z[5,2,2]  R1868     -4.5376177877187729e-02
    z[5,2,2]  R1869     3.4249746799468994e-01
    z[5,2,2]  R1870     3.1649532914161682e-01
    z[5,2,2]  R1871     -3.9023196697235107e-01
    z[5,2,2]  R1872     -2.1241942048072815e-01
    z[5,2,2]  R1873     1.6354057192802429e-01
    z[5,2,2]  R1874     -7.8870102763175964e-02
    z[5,2,2]  R1875     3.3070746064186096e-01
    z[5,2,2]  R1876     1.0235553234815598e-01
    z[5,2,2]  R1877     4.6049594879150391e-02
    z[5,2,2]  R1878     1.6168086230754852e-01
    z[5,2,2]  R1879     6.3644699752330780e-02
    z[5,2,2]  R1880     5.4390218108892441e-02
    z[5,2,2]  R1881     -1.9460545480251312e-01
    z[5,2,2]  R1882     -8.8420659303665161e-02
    z[5,2,2]  R1883     1.1523006111383438e-01
    z[5,2,2]  R1884     -7.1286588907241821e-02
    z[5,2,2]  R1885     5.5369723588228226e-02
    z[5,2,2]  R1886     -4.8150178790092468e-01
    z[5,2,2]  R1887     -6.6612720489501953e-02
    z[5,2,2]  R1888     -6.5477684140205383e-02
    z[5,2,2]  R1889     1.3341930508613586e-01
    z[5,2,2]  R1890     -0.0082245459780097
    z[5,2,2]  R1891     -2.3293124139308929e-01
    z[5,2,2]  R1892     -2.2015622258186340e-01
    z[5,2,2]  R1893     -1.5303435921669006e-01
    z[5,2,2]  R1894     1.9586192071437836e-01
    z[5,2,2]  R1895     7.5157051905989647e-03
    z[5,2,2]  R1896     3.2421614974737167e-02
    z[5,2,2]  R1897     -5.8069300651550293e-01
    z[5,2,2]  R1898     -1.3434453867375851e-02
    z[5,2,2]  R1899     5.5135834962129593e-02
    z[5,2,2]  R1900     -1.0406474769115448e-01
    z[5,2,2]  R1901     -2.2813172638416290e-01
    z[5,2,2]  R1902     1.0440982878208160e-01
    z[5,2,2]  R1903     3.7115357816219330e-02
    z[5,2,2]  R1904     4.1516300290822983e-02
    z[5,2,2]  R1905     2.5107404589653015e-01
    z[5,2,2]  R1906     -1.9405621290206909e-01
    z[5,2,2]  R1907     -5.8411568403244019e-01
    z[5,2,2]  R1908     4.2978670448064804e-02
    z[5,2,2]  R1909     9.5384582877159119e-02
    z[5,2,2]  R1910     -5.3315126895904541e-01
    z[5,2,2]  R1911     -0.0327596440911293
    z[5,2,2]  R1912     -1.1553891003131866e-01
    z[5,2,2]  R1913     -1.4035994186997414e-02
    z[5,2,2]  R1914     -1.4211086928844452e-01
    z[5,2,2]  R1915     0.749748706817627
    z[5,2,2]  R1916     -2.3999287188053131e-01
    z[5,2,2]  R1917     -2.7160859107971191e-01
    z[5,2,2]  R1918     2.1083752810955048e-01
    z[5,2,2]  R1919     -1.4375127851963043e-01
    z[5,2,2]  R1920     7.2836279869079590e-01
    z[5,2,2]  R1921     -7.1535813808441162e-01
    z[5,2,2]  R1922     -9.4469018280506134e-02
    z[5,2,2]  R1923     4.9765370786190033e-02
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1806     -1
    z[5,2,3]  R1807     1
    z[5,2,3]  R1814     5.3208708763122559e-01
    z[5,2,3]  R1815     -6.7700318992137909e-02
    z[5,2,3]  R1816     -1.8652331829071045e-01
    z[5,2,3]  R1817     -2.6899260282516479e-01
    z[5,2,3]  R1818     -1.1053077131509781e-01
    z[5,2,3]  R1819     -6.1051309108734131e-01
    z[5,2,3]  R1820     -4.5318952202796936e-01
    z[5,2,3]  R1821     8.3257085084915161e-01
    z[5,2,3]  R1822     -2.9941469430923462e-01
    z[5,2,3]  R1823     -3.3782172203063965e-01
    z[5,2,3]  R1824     1.8651817739009857e-01
    z[5,2,3]  R1825     -1.5265716612339020e-01
    z[5,2,3]  R1826     8.7237930297851562e-01
    z[5,2,3]  R1827     2.3032648861408234e-01
    z[5,2,3]  R1828     7.4780148267745972e-01
    z[5,2,3]  R1829     -1.2419898062944412e-01
    z[5,2,3]  R1830     -1.8971423804759979e-01
    z[5,2,3]  R1831     8.0624425411224365e-01
    z[5,2,3]  R1832     7.4304181337356567e-01
    z[5,2,3]  R1833     7.6708149909973145e-01
    z[5,2,3]  R1834     -3.8678354024887085e-01
    z[5,2,3]  R1835     -1.7900021374225616e-01
    z[5,2,3]  R1836     3.1066963076591492e-01
    z[5,2,3]  R1837     4.3569728732109070e-01
    z[5,2,3]  R1838     -2.8471006080508232e-02
    z[5,2,3]  R1839     4.4629785418510437e-01
    z[5,2,3]  R1840     5.9161442518234253e-01
    z[5,2,3]  R1841     4.7145324945449829e-01
    z[5,2,3]  R1842     3.5779750347137451e-01
    z[5,2,3]  R1843     3.3317390084266663e-01
    z[5,2,3]  R1844     -5.2699881792068481e-01
    z[5,2,3]  R1845     5.4240685701370239e-01
    z[5,2,3]  R1846     -2.0581322908401489e-01
    z[5,2,3]  R1847     1.1047840118408203e-02
    z[5,2,3]  R1848     7.0259046554565430e-01
    z[5,2,3]  R1849     9.2891907691955566e-01
    z[5,2,3]  R1850     -3.5196724534034729e-01
    z[5,2,3]  R1851     3.0686733126640320e-01
    z[5,2,3]  R1852     3.9088377356529236e-01
    z[5,2,3]  R1853     -3.0861553549766541e-01
    z[5,2,3]  R1854     -2.1929587423801422e-01
    z[5,2,3]  R1855     1.1554061621427536e-01
    z[5,2,3]  R1856     -1.4648194611072540e-01
    z[5,2,3]  R1857     5.5972304195165634e-02
    z[5,2,3]  R1858     4.1575622558593750e-01
    z[5,2,3]  R1859     -1.5586887300014496e-01
    z[5,2,3]  R1860     -3.8521891832351685e-01
    z[5,2,3]  R1861     -6.8435288965702057e-02
    z[5,2,3]  R1862     5.9285301715135574e-02
    z[5,2,3]  R1863     5.6945491582155228e-02
    z[5,2,3]  R1864     3.5616809129714966e-01
    z[5,2,3]  R1865     7.6187252998352051e-01
    z[5,2,3]  R1866     7.9293966293334961e-01
    z[5,2,3]  R1867     4.6142944693565369e-01
    z[5,2,3]  R1868     2.7731695771217346e-01
    z[5,2,3]  R1869     3.4239280223846436e-01
    z[5,2,3]  R1870     -2.7753153443336487e-01
    z[5,2,3]  R1871     4.9526520073413849e-02
    z[5,2,3]  R1872     -2.2915895283222198e-01
    z[5,2,3]  R1873     8.4319151937961578e-02
    z[5,2,3]  R1874     -3.8251541554927826e-02
    z[5,2,3]  R1875     -3.0787003040313721e-01
    z[5,2,3]  R1876     2.3503266274929047e-01
    z[5,2,3]  R1877     2.3451916873455048e-01
    z[5,2,3]  R1878     -1.1217866092920303e-01
    z[5,2,3]  R1879     0.0248641986399889
    z[5,2,3]  R1880     1.1310722678899765e-01
    z[5,2,3]  R1881     -1.2516199052333832e-01
    z[5,2,3]  R1882     7.1494663134217262e-03
    z[5,2,3]  R1883     2.7653848752379417e-02
    z[5,2,3]  R1884     -4.1430920362472534e-02
    z[5,2,3]  R1885     -1.9567583501338959e-01
    z[5,2,3]  R1886     -2.8022894263267517e-01
    z[5,2,3]  R1887     -2.2264190018177032e-01
    z[5,2,3]  R1888     -6.3048821687698364e-01
    z[5,2,3]  R1889     -7.3469519615173340e-01
    z[5,2,3]  R1890     -0.543587863445282
    z[5,2,3]  R1891     -4.9522459506988525e-01
    z[5,2,3]  R1892     -5.8769422769546509e-01
    z[5,2,3]  R1893     -2.8840306401252747e-01
    z[5,2,3]  R1894     4.0296044945716858e-01
    z[5,2,3]  R1895     0.89235919713974
    z[5,2,3]  R1896     5.9119653701782227e-01
    z[5,2,3]  R1897     -4.9092669039964676e-02
    z[5,2,3]  R1898     3.3295041322708130e-01
    z[5,2,3]  R1899     -4.7149640321731567e-01
    z[5,2,3]  R1900     6.3730108737945557e-01
    z[5,2,3]  R1901     -4.3858282268047333e-02
    z[5,2,3]  R1902     2.3298986256122589e-01
    z[5,2,3]  R1903     4.6260673552751541e-02
    z[5,2,3]  R1904     1.3171857595443726e-01
    z[5,2,3]  R1905     1.4769986271858215e-01
    z[5,2,3]  R1906     -3.4857848286628723e-01
    z[5,2,3]  R1907     4.8908573389053345e-01
    z[5,2,3]  R1908     1.0993672162294388e-01
    z[5,2,3]  R1909     0.512146532535553
    z[5,2,3]  R1910     8.0749049782752991e-02
    z[5,2,3]  R1911     2.6764547824859619e-01
    z[5,2,3]  R1912     0.00896703451871872
    z[5,2,3]  R1913     7.1413886547088623e-01
    z[5,2,3]  R1914     2.2266833484172821e-01
    z[5,2,3]  R1915     1.3229785859584808e-01
    z[5,2,3]  R1916     -4.2385622859001160e-01
    z[5,2,3]  R1917     -1.5113075077533722e-01
    z[5,2,3]  R1918     -1.3371877372264862e-01
    z[5,2,3]  R1919     -0.685263454914093
    z[5,2,3]  R1920     2.9402244091033936e-01
    z[5,2,3]  R1921     -0.0520898774266243
    z[5,2,3]  R1922     -0.322995126247406
    z[5,2,3]  R1923     -4.4619762897491455e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1808     -1
    z[5,2,4]  R1809     1
    z[5,2,4]  R1814     -0.407550185918808
    z[5,2,4]  R1815     1.0992280393838882e-01
    z[5,2,4]  R1816     -6.1532676219940186e-02
    z[5,2,4]  R1817     -5.0204541534185410e-02
    z[5,2,4]  R1818     -4.9264460802078247e-01
    z[5,2,4]  R1819     -2.8671622276306152e-01
    z[5,2,4]  R1820     2.6149597018957138e-02
    z[5,2,4]  R1821     7.3123171925544739e-02
    z[5,2,4]  R1822     4.4613435864448547e-02
    z[5,2,4]  R1823     -0.0691533163189888
    z[5,2,4]  R1824     0.07137431204319
    z[5,2,4]  R1825     2.4950174987316132e-01
    z[5,2,4]  R1826     1.0654534399509430e-01
    z[5,2,4]  R1827     -4.5509532094001770e-01
    z[5,2,4]  R1828     -3.6515191197395325e-01
    z[5,2,4]  R1829     -0.416479229927063
    z[5,2,4]  R1830     -4.0927022695541382e-01
    z[5,2,4]  R1831     -1.9846189022064209e-01
    z[5,2,4]  R1832     -1.9453060626983643e-01
    z[5,2,4]  R1833     3.6199086904525757e-01
    z[5,2,4]  R1834     6.9938585162162781e-02
    z[5,2,4]  R1835     -1.3595966994762421e-01
    z[5,2,4]  R1836     -1.5079443156719208e-01
    z[5,2,4]  R1837     -4.1097655892372131e-02
    z[5,2,4]  R1838     2.1752344444394112e-02
    z[5,2,4]  R1839     -1.8148691952228546e-01
    z[5,2,4]  R1840     1.0181655734777451e-01
    z[5,2,4]  R1841     6.8882554769515991e-01
    z[5,2,4]  R1842     4.0979516506195068e-01
    z[5,2,4]  R1843     0.576056957244873
    z[5,2,4]  R1844     2.0964258909225464e-01
    z[5,2,4]  R1845     3.7249827384948730e-01
    z[5,2,4]  R1846     -1.2518243491649628e-01
    z[5,2,4]  R1847     -2.4802911281585693e-01
    z[5,2,4]  R1848     7.4077457189559937e-02
    z[5,2,4]  R1849     1.6445495188236237e-01
    z[5,2,4]  R1850     -1.8125905096530914e-01
    z[5,2,4]  R1851     4.0912351012229919e-01
    z[5,2,4]  R1852     5.2063208818435669e-01
    z[5,2,4]  R1853     3.7820154428482056e-01
    z[5,2,4]  R1854     4.0455322712659836e-02
    z[5,2,4]  R1855     -1.0657750535756350e-03
    z[5,2,4]  R1856     -4.4077765941619873e-01
    z[5,2,4]  R1857     1.6311611235141754e-01
    z[5,2,4]  R1858     -3.8399747014045715e-01
    z[5,2,4]  R1859     -2.7723035216331482e-01
    z[5,2,4]  R1860     1.5596590936183929e-01
    z[5,2,4]  R1861     -5.1666635274887085e-01
    z[5,2,4]  R1862     -4.1069126129150391e-01
    z[5,2,4]  R1863     3.2260903716087341e-01
    z[5,2,4]  R1864     4.1462130844593048e-02
    z[5,2,4]  R1865     -1.7017647624015808e-01
    z[5,2,4]  R1866     5.4746586829423904e-02
    z[5,2,4]  R1867     -3.8583523035049438e-01
    z[5,2,4]  R1868     -2.4354654550552368e-01
    z[5,2,4]  R1869     3.6474749445915222e-01
    z[5,2,4]  R1870     -2.8474736213684082e-01
    z[5,2,4]  R1871     4.2725983262062073e-01
    z[5,2,4]  R1872     5.4021787643432617e-01
    z[5,2,4]  R1873     -4.9213051795959473e-01
    z[5,2,4]  R1874     7.3111318051815033e-02
    z[5,2,4]  R1875     -1.1375582218170166e-01
    z[5,2,4]  R1876     -8.2537800073623657e-02
    z[5,2,4]  R1877     -1.7899218201637268e-01
    z[5,2,4]  R1878     8.0192521214485168e-02
    z[5,2,4]  R1879     -3.0449113249778748e-01
    z[5,2,4]  R1880     -1.2869222462177277e-01
    z[5,2,4]  R1881     -4.6238997578620911e-01
    z[5,2,4]  R1882     -4.5858058333396912e-01
    z[5,2,4]  R1883     0.305789053440094
    z[5,2,4]  R1884     -0.0898180678486824
    z[5,2,4]  R1885     -3.7596827745437622e-01
    z[5,2,4]  R1886     -3.4587970376014709e-01
    z[5,2,4]  R1887     -4.2784112691879272e-01
    z[5,2,4]  R1888     -1.5457729995250702e-01
    z[5,2,4]  R1889     -2.0413650572299957e-01
    z[5,2,4]  R1890     -0.0776323527097702
    z[5,2,4]  R1891     1.2053133547306061e-01
    z[5,2,4]  R1892     -2.6265475153923035e-01
    z[5,2,4]  R1893     2.7353662252426147e-01
    z[5,2,4]  R1894     -2.8498631715774536e-01
    z[5,2,4]  R1895     4.1087669134140015e-01
    z[5,2,4]  R1896     -2.8536498546600342e-01
    z[5,2,4]  R1897     -2.8570872545242310e-01
    z[5,2,4]  R1898     -4.2396214604377747e-01
    z[5,2,4]  R1899     -9.6188765019178391e-03
    z[5,2,4]  R1900     3.5438543558120728e-01
    z[5,2,4]  R1901     -2.7970872819423676e-02
    z[5,2,4]  R1902     5.9508824348449707e-01
    z[5,2,4]  R1903     5.2050441503524780e-01
    z[5,2,4]  R1904     2.5748616456985474e-01
    z[5,2,4]  R1905     -2.1077752113342285e-01
    z[5,2,4]  R1906     2.1719934046268463e-01
    z[5,2,4]  R1907     2.3210911080241203e-02
    z[5,2,4]  R1908     2.5619903206825256e-01
    z[5,2,4]  R1909     -2.3334741592407227e-01
    z[5,2,4]  R1910     3.4386062622070312e-01
    z[5,2,4]  R1911     2.8850868344306946e-01
    z[5,2,4]  R1912     2.9008671641349792e-01
    z[5,2,4]  R1913     2.1807883679866791e-01
    z[5,2,4]  R1914     3.7299329042434692e-01
    z[5,2,4]  R1915     3.3229142427444458e-02
    z[5,2,4]  R1916     0.216078981757164
    z[5,2,4]  R1917     2.6762318611145020e-01
    z[5,2,4]  R1918     -1.2383381277322769e-01
    z[5,2,4]  R1919     -7.6574023114517331e-04
    z[5,2,4]  R1920     3.4473296999931335e-01
    z[5,2,4]  R1921     -4.5324954390525818e-01
    z[5,2,4]  R1922     -9.6704736351966858e-03
    z[5,2,4]  R1923     1.6221849620342255e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1810     -1
    z[5,2,5]  R1811     1
    z[5,2,5]  R1814     -6.6448740661144257e-02
    z[5,2,5]  R1815     -2.0032858848571777e-01
    z[5,2,5]  R1816     -4.6768745779991150e-01
    z[5,2,5]  R1817     5.4006807506084442e-02
    z[5,2,5]  R1818     -3.8019725680351257e-01
    z[5,2,5]  R1819     -2.8030180931091309e-01
    z[5,2,5]  R1820     -0.13898965716362
    z[5,2,5]  R1821     4.4669758528470993e-02
    z[5,2,5]  R1822     1.2786471843719482e-01
    z[5,2,5]  R1823     -1.5990903973579407e-01
    z[5,2,5]  R1824     2.9171234369277954e-01
    z[5,2,5]  R1825     2.6608529686927795e-01
    z[5,2,5]  R1826     1.8212196230888367e-01
    z[5,2,5]  R1827     -3.5044002532958984e-01
    z[5,2,5]  R1828     3.0996114015579224e-01
    z[5,2,5]  R1829     1.8105560541152954e-01
    z[5,2,5]  R1830     7.2475492954254150e-02
    z[5,2,5]  R1831     3.5527545213699341e-01
    z[5,2,5]  R1832     2.4875281751155853e-01
    z[5,2,5]  R1833     3.3961758017539978e-01
    z[5,2,5]  R1834     1.3228674232959747e-01
    z[5,2,5]  R1835     2.4678136408329010e-01
    z[5,2,5]  R1836     2.2562603652477264e-01
    z[5,2,5]  R1837     7.9707249999046326e-02
    z[5,2,5]  R1838     -2.2326244413852692e-01
    z[5,2,5]  R1839     2.3951642215251923e-01
    z[5,2,5]  R1840     1.1684230715036392e-01
    z[5,2,5]  R1841     2.3714546859264374e-01
    z[5,2,5]  R1842     -1.2539631128311157e-01
    z[5,2,5]  R1843     3.4624379873275757e-01
    z[5,2,5]  R1844     -4.3736483901739120e-02
    z[5,2,5]  R1845     0.495735228061676
    z[5,2,5]  R1846     -2.8402847051620483e-01
    z[5,2,5]  R1847     -4.0881112217903137e-01
    z[5,2,5]  R1848     4.6252843737602234e-01
    z[5,2,5]  R1849     2.7142751216888428e-01
    z[5,2,5]  R1850     5.7872855663299561e-01
    z[5,2,5]  R1851     -3.0829516053199768e-01
    z[5,2,5]  R1852     -2.7387544512748718e-01
    z[5,2,5]  R1853     -1.7499661445617676e-01
    z[5,2,5]  R1854     -5.5390429496765137e-01
    z[5,2,5]  R1855     8.0321721732616425e-02
    z[5,2,5]  R1856     -3.3402532339096069e-01
    z[5,2,5]  R1857     -7.4996486306190491e-02
    z[5,2,5]  R1858     -2.1256893873214722e-01
    z[5,2,5]  R1859     -4.5390984416007996e-01
    z[5,2,5]  R1860     2.7678820490837097e-01
    z[5,2,5]  R1861     -5.7354439049959183e-02
    z[5,2,5]  R1862     1.0543572902679443e-01
    z[5,2,5]  R1863     2.4937982857227325e-01
    z[5,2,5]  R1864     1.0438472777605057e-01
    z[5,2,5]  R1865     3.7046140432357788e-01
    z[5,2,5]  R1866     1.9523890316486359e-01
    z[5,2,5]  R1867     -1.6952624917030334e-01
    z[5,2,5]  R1868     -1.2062735855579376e-01
    z[5,2,5]  R1869     -1.1992149800062180e-01
    z[5,2,5]  R1870     1.9417542219161987e-01
    z[5,2,5]  R1871     2.3745548725128174e-01
    z[5,2,5]  R1872     4.2656177282333374e-01
    z[5,2,5]  R1873     3.4880742430686951e-01
    z[5,2,5]  R1874     -2.0992338657379150e-01
    z[5,2,5]  R1875     6.0002353042364120e-02
    z[5,2,5]  R1876     2.1711468696594238e-01
    z[5,2,5]  R1877     2.1944953128695488e-02
    z[5,2,5]  R1878     -3.0375117063522339e-01
    z[5,2,5]  R1879     0.174501433968544
    z[5,2,5]  R1880     -4.4397312402725220e-01
    z[5,2,5]  R1881     -1.2243715673685074e-01
    z[5,2,5]  R1882     -4.3224963545799255e-01
    z[5,2,5]  R1883     1.7003849148750305e-01
    z[5,2,5]  R1884     -1.8312266469001770e-01
    z[5,2,5]  R1885     -4.2208548984490335e-04
    z[5,2,5]  R1886     -1.7857927083969116e-01
    z[5,2,5]  R1887     1.4842978678643703e-02
    z[5,2,5]  R1888     -6.8562075495719910e-02
    z[5,2,5]  R1889     -1.3925287127494812e-01
    z[5,2,5]  R1890     -3.6532059311866760e-01
    z[5,2,5]  R1891     -3.4194344282150269e-01
    z[5,2,5]  R1892     -5.0903332233428955e-01
    z[5,2,5]  R1893     -3.8409563899040222e-01
    z[5,2,5]  R1894     2.0312181115150452e-01
    z[5,2,5]  R1895     -2.6462316513061523e-02
    z[5,2,5]  R1896     -1.6600729897618294e-02
    z[5,2,5]  R1897     2.4125227332115173e-01
    z[5,2,5]  R1898     4.7427029348909855e-03
    z[5,2,5]  R1899     -1.4630095660686493e-01
    z[5,2,5]  R1900     1.6965536773204803e-01
    z[5,2,5]  R1901     6.9013011455535889e-01
    z[5,2,5]  R1902     1.9435566663742065e-01
    z[5,2,5]  R1903     1.5157592296600342e-01
    z[5,2,5]  R1904     7.7136784791946411e-02
    z[5,2,5]  R1905     -5.7041305303573608e-01
    z[5,2,5]  R1906     4.2971007525920868e-02
    z[5,2,5]  R1907     2.3333853483200073e-01
    z[5,2,5]  R1908     -4.1894045472145081e-01
    z[5,2,5]  R1909     3.3118382096290588e-01
    z[5,2,5]  R1910     -2.5302490592002869e-01
    z[5,2,5]  R1911     1.1748849600553513e-01
    z[5,2,5]  R1912     5.8008664846420288e-01
    z[5,2,5]  R1913     -2.6482850313186646e-01
    z[5,2,5]  R1914     3.0217874050140381e-01
    z[5,2,5]  R1915     2.3517285287380219e-01
    z[5,2,5]  R1916     -1.0395722091197968e-01
    z[5,2,5]  R1917     0.1573476344347
    z[5,2,5]  R1918     4.9449086189270020e-01
    z[5,2,5]  R1919     -4.0731698274612427e-01
    z[5,2,5]  R1920     -3.3146545290946960e-01
    z[5,2,5]  R1921     -9.0212017297744751e-02
    z[5,2,5]  R1922     5.5188196897506714e-01
    z[5,2,5]  R1923     8.6244657635688782e-02
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1812     -1
    z[5,2,6]  R1813     1
    z[5,2,6]  R1814     1.2498059123754501e-01
    z[5,2,6]  R1815     4.2947977781295776e-01
    z[5,2,6]  R1816     -1.3333770632743835e-01
    z[5,2,6]  R1817     -4.9427023530006409e-01
    z[5,2,6]  R1818     1.4493362046778202e-02
    z[5,2,6]  R1819     -1.5661749243736267e-01
    z[5,2,6]  R1820     -5.1733326911926270e-01
    z[5,2,6]  R1821     -9.7482755780220032e-02
    z[5,2,6]  R1822     -3.5410153865814209e-01
    z[5,2,6]  R1823     -9.4195976853370667e-02
    z[5,2,6]  R1824     1.8198034167289734e-01
    z[5,2,6]  R1825     3.3990573883056641e-01
    z[5,2,6]  R1826     3.3872240781784058e-01
    z[5,2,6]  R1827     -3.4064075350761414e-01
    z[5,2,6]  R1828     -3.0538308620452881e-01
    z[5,2,6]  R1829     3.7478078156709671e-02
    z[5,2,6]  R1830     3.4675487875938416e-01
    z[5,2,6]  R1831     -1.0166209936141968e-01
    z[5,2,6]  R1832     -2.6171153783798218e-01
    z[5,2,6]  R1833     1.4266893267631531e-01
    z[5,2,6]  R1834     -5.8515619486570358e-02
    z[5,2,6]  R1835     1.2529952824115753e-01
    z[5,2,6]  R1836     -2.9958526138216257e-03
    z[5,2,6]  R1837     -4.2302541434764862e-02
    z[5,2,6]  R1838     3.5392352938652039e-01
    z[5,2,6]  R1839     -5.5908089876174927e-01
    z[5,2,6]  R1840     -5.4546225070953369e-01
    z[5,2,6]  R1841     1.0424774140119553e-01
    z[5,2,6]  R1842     6.5992519259452820e-02
    z[5,2,6]  R1843     1.5303359925746918e-01
    z[5,2,6]  R1844     2.1497702226042747e-02
    z[5,2,6]  R1845     -2.2102083265781403e-01
    z[5,2,6]  R1846     2.1728539466857910e-01
    z[5,2,6]  R1847     4.6085428446531296e-02
    z[5,2,6]  R1848     -2.3642720654606819e-02
    z[5,2,6]  R1849     1.0196760296821594e-01
    z[5,2,6]  R1850     -9.2297062277793884e-02
    z[5,2,6]  R1851     7.1000531315803528e-02
    z[5,2,6]  R1852     1.1236649006605148e-01
    z[5,2,6]  R1853     0.645663321018219
    z[5,2,6]  R1854     -2.7977797389030457e-01
    z[5,2,6]  R1855     3.2469874620437622e-01
    z[5,2,6]  R1856     -3.9274501800537109e-01
    z[5,2,6]  R1857     -8.7665893137454987e-02
    z[5,2,6]  R1858     -3.5648101568222046e-01
    z[5,2,6]  R1859     -4.0034556388854980e-01
    z[5,2,6]  R1860     -7.9675689339637756e-02
    z[5,2,6]  R1861     -2.2472733259201050e-01
    z[5,2,6]  R1862     -3.9812245965003967e-01
    z[5,2,6]  R1863     -1.7418856918811798e-01
    z[5,2,6]  R1864     4.7403600811958313e-01
    z[5,2,6]  R1865     4.1254632174968719e-02
    z[5,2,6]  R1866     6.2351156026124954e-02
    z[5,2,6]  R1867     4.0722902864217758e-02
    z[5,2,6]  R1868     -5.3125196695327759e-01
    z[5,2,6]  R1869     3.5758140683174133e-01
    z[5,2,6]  R1870     -5.9704118967056274e-01
    z[5,2,6]  R1871     -3.0509895086288452e-01
    z[5,2,6]  R1872     -2.7958011627197266e-01
    z[5,2,6]  R1873     -2.9956376552581787e-01
    z[5,2,6]  R1874     4.8072773218154907e-01
    z[5,2,6]  R1875     1.8467712402343750e-01
    z[5,2,6]  R1876     4.4496819376945496e-01
    z[5,2,6]  R1877     -1.3334497809410095e-01
    z[5,2,6]  R1878     -3.8611200451850891e-01
    z[5,2,6]  R1879     4.0329754352569580e-01
    z[5,2,6]  R1880     -4.5594829320907593e-01
    z[5,2,6]  R1881     -2.2571486234664917e-01
    z[5,2,6]  R1882     3.4922768827527761e-03
    z[5,2,6]  R1883     5.3784966468811035e-01
    z[5,2,6]  R1884     2.9884090647101402e-02
    z[5,2,6]  R1885     -3.0452278256416321e-01
    z[5,2,6]  R1886     2.2463712841272354e-02
    z[5,2,6]  R1887     5.0114914774894714e-02
    z[5,2,6]  R1888     3.7714502215385437e-01
    z[5,2,6]  R1889     1.0475924611091614e-01
    z[5,2,6]  R1890     2.8772982954978943e-01
    z[5,2,6]  R1891     -1.2541884183883667e-01
    z[5,2,6]  R1892     -1.1786801740527153e-02
    z[5,2,6]  R1893     -5.2705653011798859e-02
    z[5,2,6]  R1894     -1.4552329480648041e-01
    z[5,2,6]  R1895     -7.2948947548866272e-02
    z[5,2,6]  R1896     -5.5890363454818726e-01
    z[5,2,6]  R1897     -3.5005655884742737e-01
    z[5,2,6]  R1898     -6.2761205434799194e-01
    z[5,2,6]  R1899     -0.382338285446167
    z[5,2,6]  R1900     -3.0575555562973022e-01
    z[5,2,6]  R1901     -2.7842029929161072e-01
    z[5,2,6]  R1902     -4.0848350524902344e-01
    z[5,2,6]  R1903     -2.7487668395042419e-01
    z[5,2,6]  R1904     -2.3937320336699486e-02
    z[5,2,6]  R1905     -8.3725750446319580e-02
    z[5,2,6]  R1906     -1.6932488977909088e-01
    z[5,2,6]  R1907     8.9579321444034576e-02
    z[5,2,6]  R1908     -3.2548922300338745e-01
    z[5,2,6]  R1909     5.2447974681854248e-01
    z[5,2,6]  R1910     -2.0602095872163773e-02
    z[5,2,6]  R1911     -0.640866756439209
    z[5,2,6]  R1912     -1.3373306393623352e-01
    z[5,2,6]  R1913     -3.6413770914077759e-01
    z[5,2,6]  R1914     4.9902126193046570e-01
    z[5,2,6]  R1915     -2.0717842876911163e-01
    z[5,2,6]  R1916     0.100248783826828
    z[5,2,6]  R1917     -1.3530507683753967e-01
    z[5,2,6]  R1918     -3.4942036867141724e-01
    z[5,2,6]  R1919     -0.0379759818315506
    z[5,2,6]  R1920     1.4620022475719452e-01
    z[5,2,6]  R1921     1.9696770608425140e-01
    z[5,2,6]  R1922     -4.0968382358551025e-01
    z[5,2,6]  R1923     -4.4251814484596252e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1988     -1
    z[3,4,0]  R1989     1
    z[3,4,0]  R2002     -9.0111321210861206e-01
    z[3,4,0]  R2003     -6.0407590866088867e-01
    z[3,4,0]  R2004     -6.1722850799560547e-01
    z[3,4,0]  R2005     -3.1324347853660583e-01
    z[3,4,0]  R2006     1.8402388691902161e-01
    z[3,4,0]  R2007     3.5888195037841797e-01
    z[3,4,0]  R2008     1.2001663446426392e-01
    z[3,4,0]  R2009     3.3409410715103149e-01
    z[3,4,0]  R2010     1.7947991192340851e-01
    z[3,4,0]  R2011     6.3400840759277344e-01
    z[3,4,0]  R2012     -1.9765214622020721e-01
    z[3,4,0]  R2013     -1.7510922625660896e-02
    z[3,4,0]  R2014     6.6964410245418549e-02
    z[3,4,0]  R2015     -2.7715164422988892e-01
    z[3,4,0]  R2016     -2.5218993425369263e-01
    z[3,4,0]  R2017     -3.1260257959365845e-01
    z[3,4,0]  R2018     -2.3082602024078369e-01
    z[3,4,0]  R2019     2.8432890772819519e-01
    z[3,4,0]  R2020     -2.3441386222839355e-01
    z[3,4,0]  R2021     -2.9212430119514465e-01
    z[3,4,0]  R2022     1.8149070441722870e-01
    z[3,4,0]  R2023     1.8245698511600494e-01
    z[3,4,0]  R2024     2.0640777051448822e-01
    z[3,4,0]  R2025     6.3469523191452026e-01
    z[3,4,0]  R2026     1.3563279062509537e-02
    z[3,4,0]  R2027     -5.5913887917995453e-02
    z[3,4,0]  R2028     8.2741332054138184e-01
    z[3,4,0]  R2029     8.7075871229171753e-01
    z[3,4,0]  R2030     7.9749417304992676e-01
    z[3,4,0]  R2031     6.9988548755645752e-01
    z[3,4,0]  R2032     3.3281859010457993e-02
    z[3,4,0]  R2033     2.2290296852588654e-01
    z[3,4,0]  R2034     2.5331950187683105e-01
    z[3,4,0]  R2035     2.9828539490699768e-01
    z[3,4,0]  R2036     -5.0881292670965195e-02
    z[3,4,0]  R2037     1.5746654570102692e-01
    z[3,4,0]  R2038     2.3393720388412476e-01
    z[3,4,0]  R2039     2.9809838533401489e-01
    z[3,4,0]  R2040     -0.00982271321117878
    z[3,4,0]  R2041     5.6180328130722046e-01
    z[3,4,0]  R2042     4.6654570102691650e-01
    z[3,4,0]  R2043     1.6208623349666595e-01
    z[3,4,0]  R2044     8.7015196681022644e-02
    z[3,4,0]  R2045     3.2016941905021667e-01
    z[3,4,0]  R2046     -4.7110697627067566e-01
    z[3,4,0]  R2047     1.8492648005485535e-01
    z[3,4,0]  R2048     6.8464279174804688e-01
    z[3,4,0]  R2049     7.6983755826950073e-01
    z[3,4,0]  R2050     0.762596070766449
    z[3,4,0]  R2051     5.2648055553436279e-01
    z[3,4,0]  R2052     1.5865485370159149e-01
    z[3,4,0]  R2053     -1.2692667543888092e-01
    z[3,4,0]  R2054     1.6466620564460754e-01
    z[3,4,0]  R2055     2.2486260533332825e-01
    z[3,4,0]  R2056     9.1835662722587585e-02
    z[3,4,0]  R2057     5.8491063117980957e-01
    z[3,4,0]  R2058     4.2816135287284851e-01
    z[3,4,0]  R2059     1.3206787407398224e-01
    z[3,4,0]  R2060     -2.5663343071937561e-01
    z[3,4,0]  R2061     5.6501740217208862e-01
    z[3,4,0]  R2062     -1.0809303820133209e-01
    z[3,4,0]  R2063     6.1006840318441391e-02
    z[3,4,0]  R2064     -1.6829517483711243e-01
    z[3,4,0]  R2065     5.4270672798156738e-01
    z[3,4,0]  R2066     2.4762864410877228e-01
    z[3,4,0]  R2067     7.2049885988235474e-01
    z[3,4,0]  R2068     7.4297547340393066e-01
    z[3,4,0]  R2069     8.6693710088729858e-01
    z[3,4,0]  R2070     5.6837695837020874e-01
    z[3,4,0]  R2071     6.9224995374679565e-01
    z[3,4,0]  R2072     9.9514469504356384e-02
    z[3,4,0]  R2073     3.3170798420906067e-01
    z[3,4,0]  R2074     0.807605504989624
    z[3,4,0]  R2075     7.4419957399368286e-01
    z[3,4,0]  R2076     8.3993387222290039e-01
    z[3,4,0]  R2077     7.7641081809997559e-01
    z[3,4,0]  R2078     6.3118547201156616e-01
    z[3,4,0]  R2079     2.9213285446166992e-01
    z[3,4,0]  R2080     3.0005431175231934e-01
    z[3,4,0]  R2081     2.1501564979553223e-01
    z[3,4,0]  R2082     -8.4715768694877625e-02
    z[3,4,0]  R2083     3.7786862254142761e-01
    z[3,4,0]  R2084     -1.0474388301372528e-01
    z[3,4,0]  R2085     -4.3095737695693970e-01
    z[3,4,0]  R2086     -5.7242126204073429e-03
    z[3,4,0]  R2087     -1.0527808219194412e-01
    z[3,4,0]  R2088     -1.3672526180744171e-01
    z[3,4,0]  R2089     -2.7547001838684082e-01
    z[3,4,0]  R2090     5.8763694763183594e-01
    z[3,4,0]  R2091     4.1692918539047241e-01
    z[3,4,0]  R2092     3.1882929615676403e-03
    z[3,4,0]  R2093     0.350115031003952
    z[3,4,0]  R2094     1.0460475832223892e-01
    z[3,4,0]  R2095     4.6982610225677490e-01
    z[3,4,0]  R2096     -2.1524028852581978e-02
    z[3,4,0]  R2097     4.8068743199110031e-02
    z[3,4,0]  R2098     -1.2982851266860962e-01
    z[3,4,0]  R2099     -5.4572790861129761e-02
    z[3,4,0]  R2100     9.8200999200344086e-02
    z[3,4,0]  R2101     -7.6632252894341946e-03
    z[3,4,0]  R2102     2.2449608147144318e-01
    z[3,4,0]  R2103     1.2216307967901230e-01
    z[3,4,0]  R2104     2.6040667295455933e-01
    z[3,4,0]  R2105     4.6720737218856812e-01
    z[3,4,0]  R2106     4.2385819554328918e-01
    z[3,4,0]  R2107     4.0700322389602661e-01
    z[3,4,0]  R2108     1.1096493899822235e-01
    z[3,4,0]  R2109     5.0646132230758667e-01
    z[3,4,0]  R2110     0.467808336019516
    z[3,4,0]  R2111     4.6968027949333191e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1990     -1
    z[3,4,1]  R1991     1
    z[3,4,1]  R2002     2.4428819119930267e-01
    z[3,4,1]  R2003     3.5320740938186646e-01
    z[3,4,1]  R2004     -1.2976975739002228e-01
    z[3,4,1]  R2005     -4.0674397349357605e-01
    z[3,4,1]  R2006     3.9426818490028381e-01
    z[3,4,1]  R2007     -2.1566146612167358e-01
    z[3,4,1]  R2008     -4.7013166546821594e-01
    z[3,4,1]  R2009     6.7358978092670441e-02
    z[3,4,1]  R2010     -2.8506958484649658e-01
    z[3,4,1]  R2011     -4.1133868694305420e-01
    z[3,4,1]  R2012     -5.8904796838760376e-01
    z[3,4,1]  R2013     2.4392996728420258e-01
    z[3,4,1]  R2014     5.4972273111343384e-01
    z[3,4,1]  R2015     -3.5902017354965210e-01
    z[3,4,1]  R2016     -3.7197881937026978e-01
    z[3,4,1]  R2017     -4.5423364639282227e-01
    z[3,4,1]  R2018     -3.7735033035278320e-01
    z[3,4,1]  R2019     6.9945830106735229e-01
    z[3,4,1]  R2020     -5.3554880619049072e-01
    z[3,4,1]  R2021     -6.4004784822463989e-01
    z[3,4,1]  R2022     6.9371879100799561e-01
    z[3,4,1]  R2023     6.6736036539077759e-01
    z[3,4,1]  R2024     8.4547966718673706e-01
    z[3,4,1]  R2025     -3.8026013970375061e-01
    z[3,4,1]  R2026     7.5764495134353638e-01
    z[3,4,1]  R2027     7.7056729793548584e-01
    z[3,4,1]  R2028     1.1965405195951462e-01
    z[3,4,1]  R2029     -1.8582781776785851e-02
    z[3,4,1]  R2030     1.0302767157554626e-01
    z[3,4,1]  R2031     1.1012807488441467e-01
    z[3,4,1]  R2032     5.0240254402160645e-01
    z[3,4,1]  R2033     8.4660744667053223e-01
    z[3,4,1]  R2034     7.1364217996597290e-01
    z[3,4,1]  R2035     6.5825891494750977e-01
    z[3,4,1]  R2036     5.7081985473632812e-01
    z[3,4,1]  R2037     7.3875850439071655e-01
    z[3,4,1]  R2038     2.4478116631507874e-01
    z[3,4,1]  R2039     7.9243320226669312e-01
    z[3,4,1]  R2040     2.5369012355804443e-01
    z[3,4,1]  R2041     6.1081565916538239e-02
    z[3,4,1]  R2042     4.7547537088394165e-01
    z[3,4,1]  R2043     -1.3302671909332275e-01
    z[3,4,1]  R2044     -3.9098069071769714e-01
    z[3,4,1]  R2045     5.2504408359527588e-01
    z[3,4,1]  R2046     -2.2248266637325287e-01
    z[3,4,1]  R2047     4.5629009604454041e-01
    z[3,4,1]  R2048     4.9592334777116776e-02
    z[3,4,1]  R2049     -2.0216518640518188e-01
    z[3,4,1]  R2050     -6.7359425127506256e-02
    z[3,4,1]  R2051     -0.336232453584671
    z[3,4,1]  R2052     -4.1369026899337769e-01
    z[3,4,1]  R2053     4.6338456869125366e-01
    z[3,4,1]  R2054     5.3795313835144043e-01
    z[3,4,1]  R2055     -1.9572993740439415e-02
    z[3,4,1]  R2056     5.3419023752212524e-01
    z[3,4,1]  R2057     -9.6064776182174683e-02
    z[3,4,1]  R2058     3.6720937490463257e-01
    z[3,4,1]  R2059     3.1878709793090820e-01
    z[3,4,1]  R2060     -1.5896326303482056e-01
    z[3,4,1]  R2061     -3.8427191972732544e-01
    z[3,4,1]  R2062     -2.2664600610733032e-01
    z[3,4,1]  R2063     -5.3537720441818237e-01
    z[3,4,1]  R2064     6.3431978225708008e-01
    z[3,4,1]  R2065     5.9665668010711670e-01
    z[3,4,1]  R2066     3.8126606494188309e-02
    z[3,4,1]  R2067     -3.2695242762565613e-01
    z[3,4,1]  R2068     -1.6189412772655487e-01
    z[3,4,1]  R2069     1.2276873737573624e-01
    z[3,4,1]  R2070     -3.9504233747720718e-02
    z[3,4,1]  R2071     2.1815690398216248e-01
    z[3,4,1]  R2072     5.5338263511657715e-01
    z[3,4,1]  R2073     4.9680396914482117e-01
    z[3,4,1]  R2074     -6.5467916429042816e-02
    z[3,4,1]  R2075     -5.1626145839691162e-02
    z[3,4,1]  R2076     7.7807330526411533e-03
    z[3,4,1]  R2077     1.6626305878162384e-01
    z[3,4,1]  R2078     4.6585938334465027e-01
    z[3,4,1]  R2079     2.0342525839805603e-01
    z[3,4,1]  R2080     1.8408547341823578e-01
    z[3,4,1]  R2081     2.9277646541595459e-01
    z[3,4,1]  R2082     -7.2566747665405273e-01
    z[3,4,1]  R2083     -0.601925790309906
    z[3,4,1]  R2084     -4.3660253286361694e-01
    z[3,4,1]  R2085     -0.560893714427948
    z[3,4,1]  R2086     -7.1033054590225220e-01
    z[3,4,1]  R2087     -5.6445884704589844e-01
    z[3,4,1]  R2088     -5.5630582571029663e-01
    z[3,4,1]  R2089     -7.3707896471023560e-01
    z[3,4,1]  R2090     6.5864127874374390e-01
    z[3,4,1]  R2091     -6.6119700670242310e-02
    z[3,4,1]  R2092     8.3957237005233765e-01
    z[3,4,1]  R2093     7.5983101129531860e-01
    z[3,4,1]  R2094     8.9190721511840820e-01
    z[3,4,1]  R2095     0.68828946352005
    z[3,4,1]  R2096     8.4670531749725342e-01
    z[3,4,1]  R2097     8.4243708848953247e-01
    z[3,4,1]  R2098     7.9136216640472412e-01
    z[3,4,1]  R2099     7.4902480840682983e-01
    z[3,4,1]  R2100     8.6116957664489746e-01
    z[3,4,1]  R2101     8.7653368711471558e-01
    z[3,4,1]  R2102     8.3442175388336182e-01
    z[3,4,1]  R2103     8.3425015211105347e-01
    z[3,4,1]  R2104     8.9899486303329468e-01
    z[3,4,1]  R2105     5.9249097108840942e-01
    z[3,4,1]  R2106     5.9265911579132080e-01
    z[3,4,1]  R2107     -6.9072662154212594e-04
    z[3,4,1]  R2108     3.1029152870178223e-01
    z[3,4,1]  R2109     1.9548442959785461e-01
    z[3,4,1]  R2110     5.6558477878570557e-01
    z[3,4,1]  R2111     6.0634356737136841e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1992     -1
    z[3,4,2]  R1993     1
    z[3,4,2]  R2002     -2.7679139375686646e-01
    z[3,4,2]  R2003     -3.7863668799400330e-01
    z[3,4,2]  R2004     -3.8496804237365723e-01
    z[3,4,2]  R2005     2.0444500446319580e-01
    z[3,4,2]  R2006     8.6876258254051208e-02
    z[3,4,2]  R2007     -7.5554674863815308e-01
    z[3,4,2]  R2008     -7.8910648822784424e-01
    z[3,4,2]  R2009     -2.9234769940376282e-01
    z[3,4,2]  R2010     -5.6696283817291260e-01
    z[3,4,2]  R2011     -3.3386719226837158e-01
    z[3,4,2]  R2012     5.8001782745122910e-02
    z[3,4,2]  R2013     2.7561190724372864e-01
    z[3,4,2]  R2014     4.6525120735168457e-01
    z[3,4,2]  R2015     4.9158122390508652e-02
    z[3,4,2]  R2016     -1.9451542198657990e-01
    z[3,4,2]  R2017     0.456400066614151
    z[3,4,2]  R2018     -1.8513631820678711e-01
    z[3,4,2]  R2019     2.5300800800323486e-01
    z[3,4,2]  R2020     1.6776071488857269e-01
    z[3,4,2]  R2021     2.2591666877269745e-01
    z[3,4,2]  R2022     4.1885474324226379e-01
    z[3,4,2]  R2023     6.4915120601654053e-01
    z[3,4,2]  R2024     3.0353426933288574e-01
    z[3,4,2]  R2025     -0.142684206366539
    z[3,4,2]  R2026     4.0329253673553467e-01
    z[3,4,2]  R2027     5.1168125867843628e-01
    z[3,4,2]  R2028     2.2234684228897095e-01
    z[3,4,2]  R2029     2.4198077619075775e-01
    z[3,4,2]  R2030     1.9835273921489716e-01
    z[3,4,2]  R2031     2.9536345601081848e-01
    z[3,4,2]  R2032     0.591578483581543
    z[3,4,2]  R2033     4.2835199832916260e-01
    z[3,4,2]  R2034     3.6957284808158875e-01
    z[3,4,2]  R2035     3.5678908228874207e-01
    z[3,4,2]  R2036     6.9865697622299194e-01
    z[3,4,2]  R2037     -0.00870123878121376
    z[3,4,2]  R2038     7.8830993175506592e-01
    z[3,4,2]  R2039     0.0234073456376791
    z[3,4,2]  R2040     0.83809494972229
    z[3,4,2]  R2041     -2.3189926519989967e-02
    z[3,4,2]  R2042     6.6558992862701416e-01
    z[3,4,2]  R2043     -6.3357698917388916e-01
    z[3,4,2]  R2044     -5.5956327915191650e-01
    z[3,4,2]  R2045     3.6189684271812439e-01
    z[3,4,2]  R2046     3.7515515089035034e-01
    z[3,4,2]  R2047     4.3275609612464905e-01
    z[3,4,2]  R2048     4.4035500288009644e-01
    z[3,4,2]  R2049     0.510381281375885
    z[3,4,2]  R2050     4.1040968894958496e-01
    z[3,4,2]  R2051     6.4251035451889038e-01
    z[3,4,2]  R2052     -4.5409896969795227e-01
    z[3,4,2]  R2053     6.4309597015380859e-01
    z[3,4,2]  R2054     1.8638938665390015e-01
    z[3,4,2]  R2055     -1.3868586719036102e-01
    z[3,4,2]  R2056     -1.0716875083744526e-02
    z[3,4,2]  R2057     -4.7345027327537537e-01
    z[3,4,2]  R2058     1.2176910787820816e-01
    z[3,4,2]  R2059     1.8041385710239410e-01
    z[3,4,2]  R2060     3.8921785354614258e-01
    z[3,4,2]  R2061     5.0720632076263428e-01
    z[3,4,2]  R2062     -4.7103241086006165e-02
    z[3,4,2]  R2063     -6.8664395809173584e-01
    z[3,4,2]  R2064     6.2752717733383179e-01
    z[3,4,2]  R2065     2.5780880451202393e-01
    z[3,4,2]  R2066     5.6103730201721191e-01
    z[3,4,2]  R2067     4.3118435144424438e-01
    z[3,4,2]  R2068     5.1037895679473877e-01
    z[3,4,2]  R2069     2.1010838449001312e-02
    z[3,4,2]  R2070     4.4596254825592041e-01
    z[3,4,2]  R2071     1.1814925074577332e-01
    z[3,4,2]  R2072     7.2799527645111084e-01
    z[3,4,2]  R2073     1.6364777088165283e-01
    z[3,4,2]  R2074     4.1928282380104065e-01
    z[3,4,2]  R2075     3.5021528601646423e-01
    z[3,4,2]  R2076     9.6968859434127808e-02
    z[3,4,2]  R2077     1.0210317373275757e-01
    z[3,4,2]  R2078     -4.1711616516113281e-01
    z[3,4,2]  R2079     -3.4999263286590576e-01
    z[3,4,2]  R2080     -5.9964990615844727e-01
    z[3,4,2]  R2081     -0.438488632440567
    z[3,4,2]  R2082     -3.8860204815864563e-01
    z[3,4,2]  R2083     -3.0724689364433289e-01
    z[3,4,2]  R2084     -1.4385642111301422e-01
    z[3,4,2]  R2085     4.1887059807777405e-02
    z[3,4,2]  R2086     -9.1320149600505829e-02
    z[3,4,2]  R2087     -4.9124547839164734e-01
    z[3,4,2]  R2088     1.5303640067577362e-01
    z[3,4,2]  R2089     -1.8345442414283752e-01
    z[3,4,2]  R2090     -2.6607409119606018e-01
    z[3,4,2]  R2091     -1.6967274248600006e-01
    z[3,4,2]  R2092     2.1964015066623688e-01
    z[3,4,2]  R2093     -5.4684713482856750e-02
    z[3,4,2]  R2094     -3.1715580821037292e-01
    z[3,4,2]  R2095     1.5045984089374542e-01
    z[3,4,2]  R2096     -3.3043643832206726e-01
    z[3,4,2]  R2097     5.8519367128610611e-02
    z[3,4,2]  R2098     1.5012061595916748e-01
    z[3,4,2]  R2099     9.6426717936992645e-02
    z[3,4,2]  R2100     -3.5265842080116272e-01
    z[3,4,2]  R2101     2.7463451027870178e-01
    z[3,4,2]  R2102     2.7208182215690613e-01
    z[3,4,2]  R2103     4.5037293434143066e-01
    z[3,4,2]  R2104     -1.3624326884746552e-01
    z[3,4,2]  R2105     4.6888992190361023e-01
    z[3,4,2]  R2106     6.5142136812210083e-01
    z[3,4,2]  R2107     -6.4343822002410889e-01
    z[3,4,2]  R2108     -6.2557244300842285e-01
    z[3,4,2]  R2109     -6.9579696655273438e-01
    z[3,4,2]  R2110     0.331856369972229
    z[3,4,2]  R2111     -2.7549099922180176e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1994     -1
    z[3,4,3]  R1995     1
    z[3,4,3]  R2002     -1.8925718963146210e-01
    z[3,4,3]  R2003     -2.4206961691379547e-01
    z[3,4,3]  R2004     -0.221385195851326
    z[3,4,3]  R2005     -7.9649955034255981e-01
    z[3,4,3]  R2006     -3.4430682659149170e-01
    z[3,4,3]  R2007     -3.9871323108673096e-01
    z[3,4,3]  R2008     -2.5169461965560913e-01
    z[3,4,3]  R2009     -4.0956640243530273e-01
    z[3,4,3]  R2010     -6.7413115501403809e-01
    z[3,4,3]  R2011     -3.4015771746635437e-01
    z[3,4,3]  R2012     0.764613926410675
    z[3,4,3]  R2013     -5.8764559030532837e-01
    z[3,4,3]  R2014     -7.7875353395938873e-02
    z[3,4,3]  R2015     8.4801214933395386e-01
    z[3,4,3]  R2016     8.6049139499664307e-01
    z[3,4,3]  R2017     5.7995426654815674e-01
    z[3,4,3]  R2018     7.9041171073913574e-01
    z[3,4,3]  R2019     -3.1717292964458466e-02
    z[3,4,3]  R2020     6.2472563982009888e-01
    z[3,4,3]  R2021     2.7844116091728210e-01
    z[3,4,3]  R2022     -5.2439391613006592e-01
    z[3,4,3]  R2023     1.4728824794292450e-01
    z[3,4,3]  R2024     6.5796025097370148e-02
    z[3,4,3]  R2025     -0.224580317735672
    z[3,4,3]  R2026     3.2414516806602478e-01
    z[3,4,3]  R2027     1.1617504805326462e-01
    z[3,4,3]  R2028     4.1859525442123413e-01
    z[3,4,3]  R2029     8.2857191562652588e-02
    z[3,4,3]  R2030     2.9513800144195557e-01
    z[3,4,3]  R2031     5.4498338699340820e-01
    z[3,4,3]  R2032     -1.4877954125404358e-01
    z[3,4,3]  R2033     -1.1835643090307713e-02
    z[3,4,3]  R2034     -0.0822002962231636
    z[3,4,3]  R2035     -1.2596678733825684e-01
    z[3,4,3]  R2036     1.1937101930379868e-01
    z[3,4,3]  R2037     -4.4053740799427032e-02
    z[3,4,3]  R2038     -2.3050174117088318e-01
    z[3,4,3]  R2039     -0.168934166431427
    z[3,4,3]  R2040     -1.3055580854415894e-01
    z[3,4,3]  R2041     -5.7930290699005127e-01
    z[3,4,3]  R2042     -0.125800222158432
    z[3,4,3]  R2043     -6.2831813097000122e-01
    z[3,4,3]  R2044     -6.0615569353103638e-01
    z[3,4,3]  R2045     4.1915714740753174e-02
    z[3,4,3]  R2046     6.7114210128784180e-01
    z[3,4,3]  R2047     -3.5161364078521729e-01
    z[3,4,3]  R2048     4.2544767260551453e-01
    z[3,4,3]  R2049     2.8327226638793945e-01
    z[3,4,3]  R2050     1.6467611491680145e-01
    z[3,4,3]  R2051     7.4989847838878632e-02
    z[3,4,3]  R2052     -4.5076709985733032e-01
    z[3,4,3]  R2053     -5.2277642488479614e-01
    z[3,4,3]  R2054     -5.4149228334426880e-01
    z[3,4,3]  R2055     -7.2312670946121216e-01
    z[3,4,3]  R2056     -4.5369812846183777e-01
    z[3,4,3]  R2057     -3.5828915238380432e-01
    z[3,4,3]  R2058     -1.5464001893997192e-01
    z[3,4,3]  R2059     -2.0803090929985046e-01
    z[3,4,3]  R2060     -3.4947675466537476e-01
    z[3,4,3]  R2061     -1.6266277059912682e-02
    z[3,4,3]  R2062     -4.9394932389259338e-01
    z[3,4,3]  R2063     -4.3957000970840454e-01
    z[3,4,3]  R2064     -1.2109193205833435e-01
    z[3,4,3]  R2065     -2.4200929701328278e-01
    z[3,4,3]  R2066     -5.9272092580795288e-01
    z[3,4,3]  R2067     2.7310448884963989e-01
    z[3,4,3]  R2068     -2.6991853117942810e-01
    z[3,4,3]  R2069     1.3952843844890594e-01
    z[3,4,3]  R2070     1.7272329330444336e-01
    z[3,4,3]  R2071     4.0151754021644592e-01
    z[3,4,3]  R2072     -1.4502698183059692e-01
    z[3,4,3]  R2073     -2.2398833185434341e-02
    z[3,4,3]  R2074     1.6994623839855194e-01
    z[3,4,3]  R2075     0.409463107585907
    z[3,4,3]  R2076     3.1296434998512268e-01
    z[3,4,3]  R2077     3.5010293126106262e-01
    z[3,4,3]  R2078     0.400585800409317
    z[3,4,3]  R2079     5.1017558574676514e-01
    z[3,4,3]  R2080     6.4175719022750854e-01
    z[3,4,3]  R2081     7.9267239570617676e-01
    z[3,4,3]  R2082     4.4498276710510254e-01
    z[3,4,3]  R2083     4.5564872026443481e-01
    z[3,4,3]  R2084     8.5733026266098022e-01
    z[3,4,3]  R2085     3.7388020753860474e-01
    z[3,4,3]  R2086     -7.4222773313522339e-02
    z[3,4,3]  R2087     -1.0788592696189880e-01
    z[3,4,3]  R2088     4.6664497256278992e-01
    z[3,4,3]  R2089     -5.1120144128799438e-01
    z[3,4,3]  R2090     -7.2239659726619720e-02
    z[3,4,3]  R2091     -7.7155923843383789e-01
    z[3,4,3]  R2092     -0.384640634059906
    z[3,4,3]  R2093     -4.2843019962310791e-01
    z[3,4,3]  R2094     1.0900925099849701e-01
    z[3,4,3]  R2095     -1.8710485100746155e-01
    z[3,4,3]  R2096     1.6624949872493744e-01
    z[3,4,3]  R2097     2.1511860191822052e-01
    z[3,4,3]  R2098     -4.8466023802757263e-01
    z[3,4,3]  R2099     -3.9303550124168396e-01
    z[3,4,3]  R2100     -1.1065232008695602e-01
    z[3,4,3]  R2101     1.2822882831096649e-01
    z[3,4,3]  R2102     -9.2328958213329315e-02
    z[3,4,3]  R2103     6.3312657177448273e-02
    z[3,4,3]  R2104     -2.7496090531349182e-01
    z[3,4,3]  R2105     -8.1231839954853058e-02
    z[3,4,3]  R2106     -1.8128865957260132e-01
    z[3,4,3]  R2107     -0.535149097442627
    z[3,4,3]  R2108     -6.9514250755310059e-01
    z[3,4,3]  R2109     -3.4890174865722656e-01
    z[3,4,3]  R2110     2.6794403791427612e-01
    z[3,4,3]  R2111     4.0192779898643494e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1996     -1
    z[3,4,4]  R1997     1
    z[3,4,4]  R2002     -1.2922429479658604e-02
    z[3,4,4]  R2003     -3.3408230543136597e-01
    z[3,4,4]  R2004     -3.7047231197357178e-01
    z[3,4,4]  R2005     1.0382376611232758e-01
    z[3,4,4]  R2006     -5.7068582624197006e-02
    z[3,4,4]  R2007     -4.5437198132276535e-02
    z[3,4,4]  R2008     1.0979046672582626e-01
    z[3,4,4]  R2009     6.2426459789276123e-01
    z[3,4,4]  R2010     1.6458596289157867e-01
    z[3,4,4]  R2011     -1.9093267619609833e-01
    z[3,4,4]  R2012     1.5055269002914429e-01
    z[3,4,4]  R2013     4.7900673747062683e-01
    z[3,4,4]  R2014     6.8221485614776611e-01
    z[3,4,4]  R2015     -2.4003732204437256e-01
    z[3,4,4]  R2016     8.7532445788383484e-02
    z[3,4,4]  R2017     1.3894857466220856e-01
    z[3,4,4]  R2018     -2.3357519507408142e-01
    z[3,4,4]  R2019     3.6047333478927612e-01
    z[3,4,4]  R2020     -1.7176365852355957e-01
    z[3,4,4]  R2021     3.8407412171363831e-01
    z[3,4,4]  R2022     3.0290532857179642e-02
    z[3,4,4]  R2023     1.6972228884696960e-01
    z[3,4,4]  R2024     -2.6506516337394714e-01
    z[3,4,4]  R2025     -6.5742902457714081e-02
    z[3,4,4]  R2026     3.7353450059890747e-01
    z[3,4,4]  R2027     -1.9902090728282928e-01
    z[3,4,4]  R2028     -1.7694956064224243e-01
    z[3,4,4]  R2029     -3.5701495409011841e-01
    z[3,4,4]  R2030     -4.2548492550849915e-01
    z[3,4,4]  R2031     -2.7885007858276367e-01
    z[3,4,4]  R2032     -3.0204278230667114e-01
    z[3,4,4]  R2033     -6.5034247934818268e-02
    z[3,4,4]  R2034     1.4242146909236908e-01
    z[3,4,4]  R2035     -3.8372558355331421e-01
    z[3,4,4]  R2036     -2.7505305409431458e-01
    z[3,4,4]  R2037     -3.5697260499000549e-01
    z[3,4,4]  R2038     1.1379770934581757e-01
    z[3,4,4]  R2039     4.8987287282943726e-01
    z[3,4,4]  R2040     2.1615803241729736e-01
    z[3,4,4]  R2041     3.1966876983642578e-01
    z[3,4,4]  R2042     2.2724738717079163e-01
    z[3,4,4]  R2043     3.7069374322891235e-01
    z[3,4,4]  R2044     -4.7022711485624313e-02
    z[3,4,4]  R2045     5.0512617826461792e-01
    z[3,4,4]  R2046     9.9318593740463257e-02
    z[3,4,4]  R2047     6.3165497779846191e-01
    z[3,4,4]  R2048     0.0630766972899437
    z[3,4,4]  R2049     0.0745469257235527
    z[3,4,4]  R2050     4.1779968142509460e-01
    z[3,4,4]  R2051     -8.4193728864192963e-02
    z[3,4,4]  R2052     1.8353018164634705e-01
    z[3,4,4]  R2053     1.4879144728183746e-01
    z[3,4,4]  R2054     -1.8214456737041473e-01
    z[3,4,4]  R2055     2.5692921876907349e-01
    z[3,4,4]  R2056     5.9604948759078979e-01
    z[3,4,4]  R2057     1.8044304102659225e-02
    z[3,4,4]  R2058     3.6404874920845032e-01
    z[3,4,4]  R2059     2.3396741598844528e-02
    z[3,4,4]  R2060     -2.8300735354423523e-01
    z[3,4,4]  R2061     -1.9731599092483521e-01
    z[3,4,4]  R2062     -4.4487681239843369e-02
    z[3,4,4]  R2063     3.2666184008121490e-02
    z[3,4,4]  R2064     1.5206189453601837e-01
    z[3,4,4]  R2065     9.2810891568660736e-02
    z[3,4,4]  R2066     9.6238173544406891e-02
    z[3,4,4]  R2067     -1.3673400878906250e-01
    z[3,4,4]  R2068     -2.0141109824180603e-01
    z[3,4,4]  R2069     2.3014084994792938e-01
    z[3,4,4]  R2070     -2.4442131817340851e-01
    z[3,4,4]  R2071     9.3896873295307159e-02
    z[3,4,4]  R2072     2.7465993165969849e-01
    z[3,4,4]  R2073     -1.7549371719360352e-01
    z[3,4,4]  R2074     -2.2474156320095062e-01
    z[3,4,4]  R2075     3.3653992414474487e-01
    z[3,4,4]  R2076     2.3855890333652496e-01
    z[3,4,4]  R2077     1.3736869394779205e-01
    z[3,4,4]  R2078     7.3812989285215735e-04
    z[3,4,4]  R2079     -5.2129936218261719e-01
    z[3,4,4]  R2080     -2.2389587759971619e-01
    z[3,4,4]  R2081     -2.0287160575389862e-01
    z[3,4,4]  R2082     -1.1761056631803513e-01
    z[3,4,4]  R2083     -4.3422105908393860e-01
    z[3,4,4]  R2084     3.9987348020076752e-02
    z[3,4,4]  R2085     2.0577311515808105e-01
    z[3,4,4]  R2086     -2.2969231009483337e-01
    z[3,4,4]  R2087     -2.3001711070537567e-01
    z[3,4,4]  R2088     -0.0957801342010498
    z[3,4,4]  R2089     -1.7863722145557404e-01
    z[3,4,4]  R2090     -1.7013189196586609e-01
    z[3,4,4]  R2091     -3.6363226175308228e-01
    z[3,4,4]  R2092     1.7837880551815033e-01
    z[3,4,4]  R2093     -3.1958669424057007e-03
    z[3,4,4]  R2094     2.6500046253204346e-01
    z[3,4,4]  R2095     -1.3820233941078186e-01
    z[3,4,4]  R2096     3.3487355709075928e-01
    z[3,4,4]  R2097     3.1450507044792175e-01
    z[3,4,4]  R2098     3.0866429209709167e-01
    z[3,4,4]  R2099     2.1685311198234558e-01
    z[3,4,4]  R2100     1.8871790170669556e-01
    z[3,4,4]  R2101     3.6806982755661011e-01
    z[3,4,4]  R2102     1.0369108617305756e-01
    z[3,4,4]  R2103     2.3422354459762573e-01
    z[3,4,4]  R2104     8.7004482746124268e-02
    z[3,4,4]  R2105     -1.0074214637279510e-01
    z[3,4,4]  R2106     -9.0319961309432983e-02
    z[3,4,4]  R2107     2.9192152619361877e-01
    z[3,4,4]  R2108     1.2943156063556671e-01
    z[3,4,4]  R2109     1.4085660874843597e-01
    z[3,4,4]  R2110     -3.4676857292652130e-02
    z[3,4,4]  R2111     -8.8697835803031921e-02
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1998     -1
    z[3,4,5]  R1999     1
    z[3,4,5]  R2002     -7.1594923734664917e-02
    z[3,4,5]  R2003     1.2033394724130630e-01
    z[3,4,5]  R2004     -4.3070587515830994e-01
    z[3,4,5]  R2005     -2.2164934873580933e-01
    z[3,4,5]  R2006     -0.824120044708252
    z[3,4,5]  R2007     1.4033000171184540e-01
    z[3,4,5]  R2008     -9.9121198058128357e-02
    z[3,4,5]  R2009     3.9948695898056030e-01
    z[3,4,5]  R2010     2.8855550289154053e-01
    z[3,4,5]  R2011     0.0670010894536972
    z[3,4,5]  R2012     5.5497944355010986e-02
    z[3,4,5]  R2013     5.1751244068145752e-01
    z[3,4,5]  R2014     -7.3180519044399261e-02
    z[3,4,5]  R2015     1.2180896848440170e-01
    z[3,4,5]  R2016     1.0028154402971268e-01
    z[3,4,5]  R2017     -3.4219104051589966e-01
    z[3,4,5]  R2018     7.0903427898883820e-02
    z[3,4,5]  R2019     7.6070673763751984e-02
    z[3,4,5]  R2020     -3.0782202258706093e-02
    z[3,4,5]  R2021     4.3729510903358459e-01
    z[3,4,5]  R2022     1.6473619639873505e-01
    z[3,4,5]  R2023     -2.7248337864875793e-02
    z[3,4,5]  R2024     9.6197031438350677e-02
    z[3,4,5]  R2025     6.0163778066635132e-01
    z[3,4,5]  R2026     -6.0983706265687943e-02
    z[3,4,5]  R2027     2.5788676738739014e-01
    z[3,4,5]  R2028     -0.0456160232424736
    z[3,4,5]  R2029     -2.1228650212287903e-01
    z[3,4,5]  R2030     -1.7278324067592621e-01
    z[3,4,5]  R2031     -1.4928644895553589e-01
    z[3,4,5]  R2032     -4.2609229683876038e-01
    z[3,4,5]  R2033     1.2111280113458633e-01
    z[3,4,5]  R2034     -2.1845720708370209e-01
    z[3,4,5]  R2035     -2.6794201135635376e-01
    z[3,4,5]  R2036     -2.8001922369003296e-01
    z[3,4,5]  R2037     -0.5264852643013
    z[3,4,5]  R2038     -2.5525093078613281e-01
    z[3,4,5]  R2039     -2.4217948317527771e-02
    z[3,4,5]  R2040     -2.8848379850387573e-01
    z[3,4,5]  R2041     4.3418622016906738e-01
    z[3,4,5]  R2042     -1.5303204953670502e-01
    z[3,4,5]  R2043     -9.2712230980396271e-02
    z[3,4,5]  R2044     3.8863378763198853e-01
    z[3,4,5]  R2045     -3.1936866044998169e-01
    z[3,4,5]  R2046     2.8483736515045166e-01
    z[3,4,5]  R2047     2.1372631192207336e-01
    z[3,4,5]  R2048     -2.8907996416091919e-01
    z[3,4,5]  R2049     1.0884429514408112e-01
    z[3,4,5]  R2050     0.0377860963344574
    z[3,4,5]  R2051     -0.294871985912323
    z[3,4,5]  R2052     0.430424302816391
    z[3,4,5]  R2053     -1.1839371919631958e-01
    z[3,4,5]  R2054     -4.5698404312133789e-01
    z[3,4,5]  R2055     5.8323782682418823e-01
    z[3,4,5]  R2056     -3.4498110413551331e-01
    z[3,4,5]  R2057     5.0153142213821411e-01
    z[3,4,5]  R2058     -6.6374707221984863e-01
    z[3,4,5]  R2059     0.896765947341919
    z[3,4,5]  R2060     7.0995688438415527e-01
    z[3,4,5]  R2061     -4.7227197885513306e-01
    z[3,4,5]  R2062     7.5401091575622559e-01
    z[3,4,5]  R2063     2.3110548034310341e-02
    z[3,4,5]  R2064     -4.5502327382564545e-02
    z[3,4,5]  R2065     -1.5141440927982330e-01
    z[3,4,5]  R2066     4.6859785914421082e-01
    z[3,4,5]  R2067     -2.0513559877872467e-01
    z[3,4,5]  R2068     2.1855992078781128e-01
    z[3,4,5]  R2069     -1.1159786581993103e-01
    z[3,4,5]  R2070     6.7691020667552948e-02
    z[3,4,5]  R2071     5.2345430850982666e-01
    z[3,4,5]  R2072     -1.7096638679504395e-01
    z[3,4,5]  R2073     -7.6470810174942017e-01
    z[3,4,5]  R2074     -1.7447984218597412e-01
    z[3,4,5]  R2075     -0.0942888930439949
    z[3,4,5]  R2076     8.8665008544921875e-02
    z[3,4,5]  R2077     4.5969173312187195e-01
    z[3,4,5]  R2078     -1.0222969204187393e-01
    z[3,4,5]  R2079     4.4253578782081604e-01
    z[3,4,5]  R2080     2.3229949176311493e-01
    z[3,4,5]  R2081     6.2652014195919037e-02
    z[3,4,5]  R2082     5.6471548974514008e-02
    z[3,4,5]  R2083     -0.00575606245547533
    z[3,4,5]  R2084     1.4192521572113037e-01
    z[3,4,5]  R2085     -1.6009394824504852e-01
    z[3,4,5]  R2086     -2.8100606799125671e-01
    z[3,4,5]  R2087     9.9084721878170967e-03
    z[3,4,5]  R2088     -3.1752511858940125e-01
    z[3,4,5]  R2089     -2.3209697008132935e-01
    z[3,4,5]  R2090     -1.2765762209892273e-01
    z[3,4,5]  R2091     1.9370566308498383e-01
    z[3,4,5]  R2092     -1.9008180499076843e-01
    z[3,4,5]  R2093     1.2980645895004272e-01
    z[3,4,5]  R2094     -7.0155955851078033e-02
    z[3,4,5]  R2095     1.7229683697223663e-01
    z[3,4,5]  R2096     1.2577322125434875e-01
    z[3,4,5]  R2097     3.3563748002052307e-01
    z[3,4,5]  R2098     4.6237561851739883e-02
    z[3,4,5]  R2099     1.3555921614170074e-01
    z[3,4,5]  R2100     -2.0125040411949158e-01
    z[3,4,5]  R2101     4.8644743859767914e-02
    z[3,4,5]  R2102     -7.7171243727207184e-02
    z[3,4,5]  R2103     -4.4923387467861176e-03
    z[3,4,5]  R2104     6.1700176447629929e-02
    z[3,4,5]  R2105     -3.7547716498374939e-01
    z[3,4,5]  R2106     -0.0452738031744957
    z[3,4,5]  R2107     1.7261669039726257e-01
    z[3,4,5]  R2108     6.5440088510513306e-03
    z[3,4,5]  R2109     2.7864855527877808e-01
    z[3,4,5]  R2110     0.523865282535553
    z[3,4,5]  R2111     8.0336958169937134e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2000     -1
    z[3,4,6]  R2001     1
    z[3,4,6]  R2002     -1.0292565822601318e-01
    z[3,4,6]  R2003     4.2694514989852905e-01
    z[3,4,6]  R2004     2.8673991560935974e-01
    z[3,4,6]  R2005     -1.7907572910189629e-02
    z[3,4,6]  R2006     -4.6501882374286652e-02
    z[3,4,6]  R2007     2.7039566636085510e-01
    z[3,4,6]  R2008     -2.3802092671394348e-01
    z[3,4,6]  R2009     -2.8519439697265625e-01
    z[3,4,6]  R2010     -1.6427727416157722e-02
    z[3,4,6]  R2011     4.0089237689971924e-01
    z[3,4,6]  R2012     1.4535829424858093e-02
    z[3,4,6]  R2013     -1.4709062874317169e-01
    z[3,4,6]  R2014     -4.9917469732463360e-03
    z[3,4,6]  R2015     -1.7179638147354126e-02
    z[3,4,6]  R2016     -4.5078076422214508e-02
    z[3,4,6]  R2017     1.2207396328449249e-01
    z[3,4,6]  R2018     -2.9277160763740540e-01
    z[3,4,6]  R2019     4.7871533036231995e-01
    z[3,4,6]  R2020     -4.5756044983863831e-01
    z[3,4,6]  R2021     -1.9415043294429779e-01
    z[3,4,6]  R2022     -8.5624635219573975e-02
    z[3,4,6]  R2023     -2.2068157792091370e-01
    z[3,4,6]  R2024     -2.5803956389427185e-01
    z[3,4,6]  R2025     -1.2441388517618179e-01
    z[3,4,6]  R2026     -1.2177091836929321e-01
    z[3,4,6]  R2027     -1.4720830321311951e-01
    z[3,4,6]  R2028     2.0740801095962524e-01
    z[3,4,6]  R2029     -5.9064473956823349e-02
    z[3,4,6]  R2030     1.2667530775070190e-01
    z[3,4,6]  R2031     -1.1722601950168610e-01
    z[3,4,6]  R2032     3.1874611973762512e-01
    z[3,4,6]  R2033     1.7620076239109039e-01
    z[3,4,6]  R2034     -4.6389183402061462e-01
    z[3,4,6]  R2035     3.3987739682197571e-01
    z[3,4,6]  R2036     -1.2304409593343735e-01
    z[3,4,6]  R2037     -1.5102137625217438e-01
    z[3,4,6]  R2038     3.6426514387130737e-01
    z[3,4,6]  R2039     1.1635456979274750e-01
    z[3,4,6]  R2040     -2.9351255297660828e-01
    z[3,4,6]  R2041     2.3197162151336670e-01
    z[3,4,6]  R2042     1.4954103529453278e-01
    z[3,4,6]  R2043     1.1755497753620148e-01
    z[3,4,6]  R2044     -7.6021656394004822e-02
    z[3,4,6]  R2045     3.6324289441108704e-01
    z[3,4,6]  R2046     -2.1538391709327698e-01
    z[3,4,6]  R2047     4.4994466006755829e-02
    z[3,4,6]  R2048     2.5756680965423584e-01
    z[3,4,6]  R2049     -9.1338776051998138e-02
    z[3,4,6]  R2050     -2.0584285259246826e-01
    z[3,4,6]  R2051     -3.1190514564514160e-01
    z[3,4,6]  R2052     -4.1874065995216370e-01
    z[3,4,6]  R2053     2.1480417251586914e-01
    z[3,4,6]  R2054     3.3693531155586243e-01
    z[3,4,6]  R2055     2.6994548738002777e-02
    z[3,4,6]  R2056     1.6113099455833435e-01
    z[3,4,6]  R2057     2.1039338409900665e-01
    z[3,4,6]  R2058     2.6457908749580383e-01
    z[3,4,6]  R2059     -1.9243661314249039e-02
    z[3,4,6]  R2060     -2.2608275711536407e-01
    z[3,4,6]  R2061     1.1658965051174164e-01
    z[3,4,6]  R2062     -3.4674385190010071e-01
    z[3,4,6]  R2063     -2.0819826424121857e-01
    z[3,4,6]  R2064     -3.6833170056343079e-01
    z[3,4,6]  R2065     4.3919944763183594e-01
    z[3,4,6]  R2066     2.0566870272159576e-01
    z[3,4,6]  R2067     -2.2956621646881104e-01
    z[3,4,6]  R2068     1.0010523721575737e-02
    z[3,4,6]  R2069     -3.8473281264305115e-01
    z[3,4,6]  R2070     -6.1834228038787842e-01
    z[3,4,6]  R2071     -1.2329224497079849e-01
    z[3,4,6]  R2072     -1.6788972914218903e-01
    z[3,4,6]  R2073     -1.7228076234459877e-02
    z[3,4,6]  R2074     -2.4053168296813965e-01
    z[3,4,6]  R2075     -1.7618584632873535e-01
    z[3,4,6]  R2076     -3.4975594282150269e-01
    z[3,4,6]  R2077     -7.9743430018424988e-02
    z[3,4,6]  R2078     -1.9918261468410492e-01
    z[3,4,6]  R2079     -1.5136629343032837e-01
    z[3,4,6]  R2080     2.3564919829368591e-02
    z[3,4,6]  R2081     4.8643615096807480e-02
    z[3,4,6]  R2082     3.1652396917343140e-01
    z[3,4,6]  R2083     -6.5598316490650177e-02
    z[3,4,6]  R2084     -1.4475968480110168e-01
    z[3,4,6]  R2085     5.3866535425186157e-01
    z[3,4,6]  R2086     5.9146124124526978e-01
    z[3,4,6]  R2087     -0.60360187292099
    z[3,4,6]  R2088     -5.6626528501510620e-01
    z[3,4,6]  R2089     0.00824635848402977
    z[3,4,6]  R2090     3.1562498211860657e-01
    z[3,4,6]  R2091     1.6719865798950195e-01
    z[3,4,6]  R2092     1.7597745358943939e-01
    z[3,4,6]  R2093     3.1092354655265808e-01
    z[3,4,6]  R2094     7.7080823481082916e-02
    z[3,4,6]  R2095     -4.4619336724281311e-01
    z[3,4,6]  R2096     -1.3356833159923553e-01
    z[3,4,6]  R2097     -1.6347070038318634e-01
    z[3,4,6]  R2098     -4.5246567577123642e-02
    z[3,4,6]  R2099     -4.5476046204566956e-01
    z[3,4,6]  R2100     -1.8977752327919006e-01
    z[3,4,6]  R2101     4.3836481869220734e-02
    z[3,4,6]  R2102     -3.9253199100494385e-01
    z[3,4,6]  R2103     -1.6546231508255005e-01
    z[3,4,6]  R2104     -1.3584578037261963e-01
    z[3,4,6]  R2105     2.3039807379245758e-01
    z[3,4,6]  R2106     -4.0946129709482193e-02
    z[3,4,6]  R2107     1.3760775327682495e-01
    z[3,4,6]  R2108     -6.8311393260955811e-03
    z[3,4,6]  R2109     -4.3948139995336533e-02
    z[3,4,6]  R2110     6.0904525220394135e-02
    z[3,4,6]  R2111     -3.9998155832290649e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2112     -1
    z[4,3,0]  R2113     1
    z[4,3,0]  R2126     -8.4715768694877625e-02
    z[4,3,0]  R2127     3.7786862254142761e-01
    z[4,3,0]  R2128     -1.0474388301372528e-01
    z[4,3,0]  R2129     -4.3095737695693970e-01
    z[4,3,0]  R2130     -5.7242126204073429e-03
    z[4,3,0]  R2131     -1.0527808219194412e-01
    z[4,3,0]  R2132     -1.3672526180744171e-01
    z[4,3,0]  R2133     -2.7547001838684082e-01
    z[4,3,0]  R2134     5.8763694763183594e-01
    z[4,3,0]  R2135     4.1692918539047241e-01
    z[4,3,0]  R2136     3.1882929615676403e-03
    z[4,3,0]  R2137     0.350115031003952
    z[4,3,0]  R2138     1.0460475832223892e-01
    z[4,3,0]  R2139     4.6982610225677490e-01
    z[4,3,0]  R2140     -2.1524028852581978e-02
    z[4,3,0]  R2141     4.8068743199110031e-02
    z[4,3,0]  R2142     -1.2982851266860962e-01
    z[4,3,0]  R2143     -5.4572790861129761e-02
    z[4,3,0]  R2144     9.8200999200344086e-02
    z[4,3,0]  R2145     -7.6632252894341946e-03
    z[4,3,0]  R2146     2.2449608147144318e-01
    z[4,3,0]  R2147     1.2216307967901230e-01
    z[4,3,0]  R2148     2.6040667295455933e-01
    z[4,3,0]  R2149     4.6720737218856812e-01
    z[4,3,0]  R2150     4.2385819554328918e-01
    z[4,3,0]  R2151     4.0700322389602661e-01
    z[4,3,0]  R2152     1.1096493899822235e-01
    z[4,3,0]  R2153     5.0646132230758667e-01
    z[4,3,0]  R2154     0.467808336019516
    z[4,3,0]  R2155     4.6968027949333191e-01
    z[4,3,0]  R2156     -9.0111321210861206e-01
    z[4,3,0]  R2157     -6.0407590866088867e-01
    z[4,3,0]  R2158     -6.1722850799560547e-01
    z[4,3,0]  R2159     -3.1324347853660583e-01
    z[4,3,0]  R2160     1.8402388691902161e-01
    z[4,3,0]  R2161     3.5888195037841797e-01
    z[4,3,0]  R2162     1.2001663446426392e-01
    z[4,3,0]  R2163     3.3409410715103149e-01
    z[4,3,0]  R2164     1.7947991192340851e-01
    z[4,3,0]  R2165     6.3400840759277344e-01
    z[4,3,0]  R2166     -1.9765214622020721e-01
    z[4,3,0]  R2167     -1.7510922625660896e-02
    z[4,3,0]  R2168     6.6964410245418549e-02
    z[4,3,0]  R2169     -2.7715164422988892e-01
    z[4,3,0]  R2170     -2.5218993425369263e-01
    z[4,3,0]  R2171     -3.1260257959365845e-01
    z[4,3,0]  R2172     -2.3082602024078369e-01
    z[4,3,0]  R2173     2.8432890772819519e-01
    z[4,3,0]  R2174     -2.3441386222839355e-01
    z[4,3,0]  R2175     -2.9212430119514465e-01
    z[4,3,0]  R2176     1.8149070441722870e-01
    z[4,3,0]  R2177     1.8245698511600494e-01
    z[4,3,0]  R2178     2.0640777051448822e-01
    z[4,3,0]  R2179     6.3469523191452026e-01
    z[4,3,0]  R2180     1.3563279062509537e-02
    z[4,3,0]  R2181     -5.5913887917995453e-02
    z[4,3,0]  R2182     8.2741332054138184e-01
    z[4,3,0]  R2183     8.7075871229171753e-01
    z[4,3,0]  R2184     7.9749417304992676e-01
    z[4,3,0]  R2185     6.9988548755645752e-01
    z[4,3,0]  R2186     3.3281859010457993e-02
    z[4,3,0]  R2187     2.2290296852588654e-01
    z[4,3,0]  R2188     2.5331950187683105e-01
    z[4,3,0]  R2189     2.9828539490699768e-01
    z[4,3,0]  R2190     -5.0881292670965195e-02
    z[4,3,0]  R2191     1.5746654570102692e-01
    z[4,3,0]  R2192     2.3393720388412476e-01
    z[4,3,0]  R2193     2.9809838533401489e-01
    z[4,3,0]  R2194     -0.00982271321117878
    z[4,3,0]  R2195     5.6180328130722046e-01
    z[4,3,0]  R2196     4.6654570102691650e-01
    z[4,3,0]  R2197     1.6208623349666595e-01
    z[4,3,0]  R2198     8.7015196681022644e-02
    z[4,3,0]  R2199     3.2016941905021667e-01
    z[4,3,0]  R2200     -4.7110697627067566e-01
    z[4,3,0]  R2201     1.8492648005485535e-01
    z[4,3,0]  R2202     6.8464279174804688e-01
    z[4,3,0]  R2203     7.6983755826950073e-01
    z[4,3,0]  R2204     0.762596070766449
    z[4,3,0]  R2205     5.2648055553436279e-01
    z[4,3,0]  R2206     1.5865485370159149e-01
    z[4,3,0]  R2207     -1.2692667543888092e-01
    z[4,3,0]  R2208     1.6466620564460754e-01
    z[4,3,0]  R2209     2.2486260533332825e-01
    z[4,3,0]  R2210     9.1835662722587585e-02
    z[4,3,0]  R2211     5.8491063117980957e-01
    z[4,3,0]  R2212     4.2816135287284851e-01
    z[4,3,0]  R2213     1.3206787407398224e-01
    z[4,3,0]  R2214     -2.5663343071937561e-01
    z[4,3,0]  R2215     5.6501740217208862e-01
    z[4,3,0]  R2216     -1.0809303820133209e-01
    z[4,3,0]  R2217     6.1006840318441391e-02
    z[4,3,0]  R2218     -1.6829517483711243e-01
    z[4,3,0]  R2219     5.4270672798156738e-01
    z[4,3,0]  R2220     2.4762864410877228e-01
    z[4,3,0]  R2221     7.2049885988235474e-01
    z[4,3,0]  R2222     7.4297547340393066e-01
    z[4,3,0]  R2223     8.6693710088729858e-01
    z[4,3,0]  R2224     5.6837695837020874e-01
    z[4,3,0]  R2225     6.9224995374679565e-01
    z[4,3,0]  R2226     9.9514469504356384e-02
    z[4,3,0]  R2227     3.3170798420906067e-01
    z[4,3,0]  R2228     0.807605504989624
    z[4,3,0]  R2229     7.4419957399368286e-01
    z[4,3,0]  R2230     8.3993387222290039e-01
    z[4,3,0]  R2231     7.7641081809997559e-01
    z[4,3,0]  R2232     6.3118547201156616e-01
    z[4,3,0]  R2233     2.9213285446166992e-01
    z[4,3,0]  R2234     3.0005431175231934e-01
    z[4,3,0]  R2235     2.1501564979553223e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2114     -1
    z[4,3,1]  R2115     1
    z[4,3,1]  R2126     -7.2566747665405273e-01
    z[4,3,1]  R2127     -0.601925790309906
    z[4,3,1]  R2128     -4.3660253286361694e-01
    z[4,3,1]  R2129     -0.560893714427948
    z[4,3,1]  R2130     -7.1033054590225220e-01
    z[4,3,1]  R2131     -5.6445884704589844e-01
    z[4,3,1]  R2132     -5.5630582571029663e-01
    z[4,3,1]  R2133     -7.3707896471023560e-01
    z[4,3,1]  R2134     6.5864127874374390e-01
    z[4,3,1]  R2135     -6.6119700670242310e-02
    z[4,3,1]  R2136     8.3957237005233765e-01
    z[4,3,1]  R2137     7.5983101129531860e-01
    z[4,3,1]  R2138     8.9190721511840820e-01
    z[4,3,1]  R2139     0.68828946352005
    z[4,3,1]  R2140     8.4670531749725342e-01
    z[4,3,1]  R2141     8.4243708848953247e-01
    z[4,3,1]  R2142     7.9136216640472412e-01
    z[4,3,1]  R2143     7.4902480840682983e-01
    z[4,3,1]  R2144     8.6116957664489746e-01
    z[4,3,1]  R2145     8.7653368711471558e-01
    z[4,3,1]  R2146     8.3442175388336182e-01
    z[4,3,1]  R2147     8.3425015211105347e-01
    z[4,3,1]  R2148     8.9899486303329468e-01
    z[4,3,1]  R2149     5.9249097108840942e-01
    z[4,3,1]  R2150     5.9265911579132080e-01
    z[4,3,1]  R2151     -6.9072662154212594e-04
    z[4,3,1]  R2152     3.1029152870178223e-01
    z[4,3,1]  R2153     1.9548442959785461e-01
    z[4,3,1]  R2154     5.6558477878570557e-01
    z[4,3,1]  R2155     6.0634356737136841e-01
    z[4,3,1]  R2156     2.4428819119930267e-01
    z[4,3,1]  R2157     3.5320740938186646e-01
    z[4,3,1]  R2158     -1.2976975739002228e-01
    z[4,3,1]  R2159     -4.0674397349357605e-01
    z[4,3,1]  R2160     3.9426818490028381e-01
    z[4,3,1]  R2161     -2.1566146612167358e-01
    z[4,3,1]  R2162     -4.7013166546821594e-01
    z[4,3,1]  R2163     6.7358978092670441e-02
    z[4,3,1]  R2164     -2.8506958484649658e-01
    z[4,3,1]  R2165     -4.1133868694305420e-01
    z[4,3,1]  R2166     -5.8904796838760376e-01
    z[4,3,1]  R2167     2.4392996728420258e-01
    z[4,3,1]  R2168     5.4972273111343384e-01
    z[4,3,1]  R2169     -3.5902017354965210e-01
    z[4,3,1]  R2170     -3.7197881937026978e-01
    z[4,3,1]  R2171     -4.5423364639282227e-01
    z[4,3,1]  R2172     -3.7735033035278320e-01
    z[4,3,1]  R2173     6.9945830106735229e-01
    z[4,3,1]  R2174     -5.3554880619049072e-01
    z[4,3,1]  R2175     -6.4004784822463989e-01
    z[4,3,1]  R2176     6.9371879100799561e-01
    z[4,3,1]  R2177     6.6736036539077759e-01
    z[4,3,1]  R2178     8.4547966718673706e-01
    z[4,3,1]  R2179     -3.8026013970375061e-01
    z[4,3,1]  R2180     7.5764495134353638e-01
    z[4,3,1]  R2181     7.7056729793548584e-01
    z[4,3,1]  R2182     1.1965405195951462e-01
    z[4,3,1]  R2183     -1.8582781776785851e-02
    z[4,3,1]  R2184     1.0302767157554626e-01
    z[4,3,1]  R2185     1.1012807488441467e-01
    z[4,3,1]  R2186     5.0240254402160645e-01
    z[4,3,1]  R2187     8.4660744667053223e-01
    z[4,3,1]  R2188     7.1364217996597290e-01
    z[4,3,1]  R2189     6.5825891494750977e-01
    z[4,3,1]  R2190     5.7081985473632812e-01
    z[4,3,1]  R2191     7.3875850439071655e-01
    z[4,3,1]  R2192     2.4478116631507874e-01
    z[4,3,1]  R2193     7.9243320226669312e-01
    z[4,3,1]  R2194     2.5369012355804443e-01
    z[4,3,1]  R2195     6.1081565916538239e-02
    z[4,3,1]  R2196     4.7547537088394165e-01
    z[4,3,1]  R2197     -1.3302671909332275e-01
    z[4,3,1]  R2198     -3.9098069071769714e-01
    z[4,3,1]  R2199     5.2504408359527588e-01
    z[4,3,1]  R2200     -2.2248266637325287e-01
    z[4,3,1]  R2201     4.5629009604454041e-01
    z[4,3,1]  R2202     4.9592334777116776e-02
    z[4,3,1]  R2203     -2.0216518640518188e-01
    z[4,3,1]  R2204     -6.7359425127506256e-02
    z[4,3,1]  R2205     -0.336232453584671
    z[4,3,1]  R2206     -4.1369026899337769e-01
    z[4,3,1]  R2207     4.6338456869125366e-01
    z[4,3,1]  R2208     5.3795313835144043e-01
    z[4,3,1]  R2209     -1.9572993740439415e-02
    z[4,3,1]  R2210     5.3419023752212524e-01
    z[4,3,1]  R2211     -9.6064776182174683e-02
    z[4,3,1]  R2212     3.6720937490463257e-01
    z[4,3,1]  R2213     3.1878709793090820e-01
    z[4,3,1]  R2214     -1.5896326303482056e-01
    z[4,3,1]  R2215     -3.8427191972732544e-01
    z[4,3,1]  R2216     -2.2664600610733032e-01
    z[4,3,1]  R2217     -5.3537720441818237e-01
    z[4,3,1]  R2218     6.3431978225708008e-01
    z[4,3,1]  R2219     5.9665668010711670e-01
    z[4,3,1]  R2220     3.8126606494188309e-02
    z[4,3,1]  R2221     -3.2695242762565613e-01
    z[4,3,1]  R2222     -1.6189412772655487e-01
    z[4,3,1]  R2223     1.2276873737573624e-01
    z[4,3,1]  R2224     -3.9504233747720718e-02
    z[4,3,1]  R2225     2.1815690398216248e-01
    z[4,3,1]  R2226     5.5338263511657715e-01
    z[4,3,1]  R2227     4.9680396914482117e-01
    z[4,3,1]  R2228     -6.5467916429042816e-02
    z[4,3,1]  R2229     -5.1626145839691162e-02
    z[4,3,1]  R2230     7.7807330526411533e-03
    z[4,3,1]  R2231     1.6626305878162384e-01
    z[4,3,1]  R2232     4.6585938334465027e-01
    z[4,3,1]  R2233     2.0342525839805603e-01
    z[4,3,1]  R2234     1.8408547341823578e-01
    z[4,3,1]  R2235     2.9277646541595459e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2116     -1
    z[4,3,2]  R2117     1
    z[4,3,2]  R2126     -3.8860204815864563e-01
    z[4,3,2]  R2127     -3.0724689364433289e-01
    z[4,3,2]  R2128     -1.4385642111301422e-01
    z[4,3,2]  R2129     4.1887059807777405e-02
    z[4,3,2]  R2130     -9.1320149600505829e-02
    z[4,3,2]  R2131     -4.9124547839164734e-01
    z[4,3,2]  R2132     1.5303640067577362e-01
    z[4,3,2]  R2133     -1.8345442414283752e-01
    z[4,3,2]  R2134     -2.6607409119606018e-01
    z[4,3,2]  R2135     -1.6967274248600006e-01
    z[4,3,2]  R2136     2.1964015066623688e-01
    z[4,3,2]  R2137     -5.4684713482856750e-02
    z[4,3,2]  R2138     -3.1715580821037292e-01
    z[4,3,2]  R2139     1.5045984089374542e-01
    z[4,3,2]  R2140     -3.3043643832206726e-01
    z[4,3,2]  R2141     5.8519367128610611e-02
    z[4,3,2]  R2142     1.5012061595916748e-01
    z[4,3,2]  R2143     9.6426717936992645e-02
    z[4,3,2]  R2144     -3.5265842080116272e-01
    z[4,3,2]  R2145     2.7463451027870178e-01
    z[4,3,2]  R2146     2.7208182215690613e-01
    z[4,3,2]  R2147     4.5037293434143066e-01
    z[4,3,2]  R2148     -1.3624326884746552e-01
    z[4,3,2]  R2149     4.6888992190361023e-01
    z[4,3,2]  R2150     6.5142136812210083e-01
    z[4,3,2]  R2151     -6.4343822002410889e-01
    z[4,3,2]  R2152     -6.2557244300842285e-01
    z[4,3,2]  R2153     -6.9579696655273438e-01
    z[4,3,2]  R2154     0.331856369972229
    z[4,3,2]  R2155     -2.7549099922180176e-01
    z[4,3,2]  R2156     -2.7679139375686646e-01
    z[4,3,2]  R2157     -3.7863668799400330e-01
    z[4,3,2]  R2158     -3.8496804237365723e-01
    z[4,3,2]  R2159     2.0444500446319580e-01
    z[4,3,2]  R2160     8.6876258254051208e-02
    z[4,3,2]  R2161     -7.5554674863815308e-01
    z[4,3,2]  R2162     -7.8910648822784424e-01
    z[4,3,2]  R2163     -2.9234769940376282e-01
    z[4,3,2]  R2164     -5.6696283817291260e-01
    z[4,3,2]  R2165     -3.3386719226837158e-01
    z[4,3,2]  R2166     5.8001782745122910e-02
    z[4,3,2]  R2167     2.7561190724372864e-01
    z[4,3,2]  R2168     4.6525120735168457e-01
    z[4,3,2]  R2169     4.9158122390508652e-02
    z[4,3,2]  R2170     -1.9451542198657990e-01
    z[4,3,2]  R2171     0.456400066614151
    z[4,3,2]  R2172     -1.8513631820678711e-01
    z[4,3,2]  R2173     2.5300800800323486e-01
    z[4,3,2]  R2174     1.6776071488857269e-01
    z[4,3,2]  R2175     2.2591666877269745e-01
    z[4,3,2]  R2176     4.1885474324226379e-01
    z[4,3,2]  R2177     6.4915120601654053e-01
    z[4,3,2]  R2178     3.0353426933288574e-01
    z[4,3,2]  R2179     -0.142684206366539
    z[4,3,2]  R2180     4.0329253673553467e-01
    z[4,3,2]  R2181     5.1168125867843628e-01
    z[4,3,2]  R2182     2.2234684228897095e-01
    z[4,3,2]  R2183     2.4198077619075775e-01
    z[4,3,2]  R2184     1.9835273921489716e-01
    z[4,3,2]  R2185     2.9536345601081848e-01
    z[4,3,2]  R2186     0.591578483581543
    z[4,3,2]  R2187     4.2835199832916260e-01
    z[4,3,2]  R2188     3.6957284808158875e-01
    z[4,3,2]  R2189     3.5678908228874207e-01
    z[4,3,2]  R2190     6.9865697622299194e-01
    z[4,3,2]  R2191     -0.00870123878121376
    z[4,3,2]  R2192     7.8830993175506592e-01
    z[4,3,2]  R2193     0.0234073456376791
    z[4,3,2]  R2194     0.83809494972229
    z[4,3,2]  R2195     -2.3189926519989967e-02
    z[4,3,2]  R2196     6.6558992862701416e-01
    z[4,3,2]  R2197     -6.3357698917388916e-01
    z[4,3,2]  R2198     -5.5956327915191650e-01
    z[4,3,2]  R2199     3.6189684271812439e-01
    z[4,3,2]  R2200     3.7515515089035034e-01
    z[4,3,2]  R2201     4.3275609612464905e-01
    z[4,3,2]  R2202     4.4035500288009644e-01
    z[4,3,2]  R2203     0.510381281375885
    z[4,3,2]  R2204     4.1040968894958496e-01
    z[4,3,2]  R2205     6.4251035451889038e-01
    z[4,3,2]  R2206     -4.5409896969795227e-01
    z[4,3,2]  R2207     6.4309597015380859e-01
    z[4,3,2]  R2208     1.8638938665390015e-01
    z[4,3,2]  R2209     -1.3868586719036102e-01
    z[4,3,2]  R2210     -1.0716875083744526e-02
    z[4,3,2]  R2211     -4.7345027327537537e-01
    z[4,3,2]  R2212     1.2176910787820816e-01
    z[4,3,2]  R2213     1.8041385710239410e-01
    z[4,3,2]  R2214     3.8921785354614258e-01
    z[4,3,2]  R2215     5.0720632076263428e-01
    z[4,3,2]  R2216     -4.7103241086006165e-02
    z[4,3,2]  R2217     -6.8664395809173584e-01
    z[4,3,2]  R2218     6.2752717733383179e-01
    z[4,3,2]  R2219     2.5780880451202393e-01
    z[4,3,2]  R2220     5.6103730201721191e-01
    z[4,3,2]  R2221     4.3118435144424438e-01
    z[4,3,2]  R2222     5.1037895679473877e-01
    z[4,3,2]  R2223     2.1010838449001312e-02
    z[4,3,2]  R2224     4.4596254825592041e-01
    z[4,3,2]  R2225     1.1814925074577332e-01
    z[4,3,2]  R2226     7.2799527645111084e-01
    z[4,3,2]  R2227     1.6364777088165283e-01
    z[4,3,2]  R2228     4.1928282380104065e-01
    z[4,3,2]  R2229     3.5021528601646423e-01
    z[4,3,2]  R2230     9.6968859434127808e-02
    z[4,3,2]  R2231     1.0210317373275757e-01
    z[4,3,2]  R2232     -4.1711616516113281e-01
    z[4,3,2]  R2233     -3.4999263286590576e-01
    z[4,3,2]  R2234     -5.9964990615844727e-01
    z[4,3,2]  R2235     -0.438488632440567
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2118     -1
    z[4,3,3]  R2119     1
    z[4,3,3]  R2126     4.4498276710510254e-01
    z[4,3,3]  R2127     4.5564872026443481e-01
    z[4,3,3]  R2128     8.5733026266098022e-01
    z[4,3,3]  R2129     3.7388020753860474e-01
    z[4,3,3]  R2130     -7.4222773313522339e-02
    z[4,3,3]  R2131     -1.0788592696189880e-01
    z[4,3,3]  R2132     4.6664497256278992e-01
    z[4,3,3]  R2133     -5.1120144128799438e-01
    z[4,3,3]  R2134     -7.2239659726619720e-02
    z[4,3,3]  R2135     -7.7155923843383789e-01
    z[4,3,3]  R2136     -0.384640634059906
    z[4,3,3]  R2137     -4.2843019962310791e-01
    z[4,3,3]  R2138     1.0900925099849701e-01
    z[4,3,3]  R2139     -1.8710485100746155e-01
    z[4,3,3]  R2140     1.6624949872493744e-01
    z[4,3,3]  R2141     2.1511860191822052e-01
    z[4,3,3]  R2142     -4.8466023802757263e-01
    z[4,3,3]  R2143     -3.9303550124168396e-01
    z[4,3,3]  R2144     -1.1065232008695602e-01
    z[4,3,3]  R2145     1.2822882831096649e-01
    z[4,3,3]  R2146     -9.2328958213329315e-02
    z[4,3,3]  R2147     6.3312657177448273e-02
    z[4,3,3]  R2148     -2.7496090531349182e-01
    z[4,3,3]  R2149     -8.1231839954853058e-02
    z[4,3,3]  R2150     -1.8128865957260132e-01
    z[4,3,3]  R2151     -0.535149097442627
    z[4,3,3]  R2152     -6.9514250755310059e-01
    z[4,3,3]  R2153     -3.4890174865722656e-01
    z[4,3,3]  R2154     2.6794403791427612e-01
    z[4,3,3]  R2155     4.0192779898643494e-01
    z[4,3,3]  R2156     -1.8925718963146210e-01
    z[4,3,3]  R2157     -2.4206961691379547e-01
    z[4,3,3]  R2158     -0.221385195851326
    z[4,3,3]  R2159     -7.9649955034255981e-01
    z[4,3,3]  R2160     -3.4430682659149170e-01
    z[4,3,3]  R2161     -3.9871323108673096e-01
    z[4,3,3]  R2162     -2.5169461965560913e-01
    z[4,3,3]  R2163     -4.0956640243530273e-01
    z[4,3,3]  R2164     -6.7413115501403809e-01
    z[4,3,3]  R2165     -3.4015771746635437e-01
    z[4,3,3]  R2166     0.764613926410675
    z[4,3,3]  R2167     -5.8764559030532837e-01
    z[4,3,3]  R2168     -7.7875353395938873e-02
    z[4,3,3]  R2169     8.4801214933395386e-01
    z[4,3,3]  R2170     8.6049139499664307e-01
    z[4,3,3]  R2171     5.7995426654815674e-01
    z[4,3,3]  R2172     7.9041171073913574e-01
    z[4,3,3]  R2173     -3.1717292964458466e-02
    z[4,3,3]  R2174     6.2472563982009888e-01
    z[4,3,3]  R2175     2.7844116091728210e-01
    z[4,3,3]  R2176     -5.2439391613006592e-01
    z[4,3,3]  R2177     1.4728824794292450e-01
    z[4,3,3]  R2178     6.5796025097370148e-02
    z[4,3,3]  R2179     -0.224580317735672
    z[4,3,3]  R2180     3.2414516806602478e-01
    z[4,3,3]  R2181     1.1617504805326462e-01
    z[4,3,3]  R2182     4.1859525442123413e-01
    z[4,3,3]  R2183     8.2857191562652588e-02
    z[4,3,3]  R2184     2.9513800144195557e-01
    z[4,3,3]  R2185     5.4498338699340820e-01
    z[4,3,3]  R2186     -1.4877954125404358e-01
    z[4,3,3]  R2187     -1.1835643090307713e-02
    z[4,3,3]  R2188     -0.0822002962231636
    z[4,3,3]  R2189     -1.2596678733825684e-01
    z[4,3,3]  R2190     1.1937101930379868e-01
    z[4,3,3]  R2191     -4.4053740799427032e-02
    z[4,3,3]  R2192     -2.3050174117088318e-01
    z[4,3,3]  R2193     -0.168934166431427
    z[4,3,3]  R2194     -1.3055580854415894e-01
    z[4,3,3]  R2195     -5.7930290699005127e-01
    z[4,3,3]  R2196     -0.125800222158432
    z[4,3,3]  R2197     -6.2831813097000122e-01
    z[4,3,3]  R2198     -6.0615569353103638e-01
    z[4,3,3]  R2199     4.1915714740753174e-02
    z[4,3,3]  R2200     6.7114210128784180e-01
    z[4,3,3]  R2201     -3.5161364078521729e-01
    z[4,3,3]  R2202     4.2544767260551453e-01
    z[4,3,3]  R2203     2.8327226638793945e-01
    z[4,3,3]  R2204     1.6467611491680145e-01
    z[4,3,3]  R2205     7.4989847838878632e-02
    z[4,3,3]  R2206     -4.5076709985733032e-01
    z[4,3,3]  R2207     -5.2277642488479614e-01
    z[4,3,3]  R2208     -5.4149228334426880e-01
    z[4,3,3]  R2209     -7.2312670946121216e-01
    z[4,3,3]  R2210     -4.5369812846183777e-01
    z[4,3,3]  R2211     -3.5828915238380432e-01
    z[4,3,3]  R2212     -1.5464001893997192e-01
    z[4,3,3]  R2213     -2.0803090929985046e-01
    z[4,3,3]  R2214     -3.4947675466537476e-01
    z[4,3,3]  R2215     -1.6266277059912682e-02
    z[4,3,3]  R2216     -4.9394932389259338e-01
    z[4,3,3]  R2217     -4.3957000970840454e-01
    z[4,3,3]  R2218     -1.2109193205833435e-01
    z[4,3,3]  R2219     -2.4200929701328278e-01
    z[4,3,3]  R2220     -5.9272092580795288e-01
    z[4,3,3]  R2221     2.7310448884963989e-01
    z[4,3,3]  R2222     -2.6991853117942810e-01
    z[4,3,3]  R2223     1.3952843844890594e-01
    z[4,3,3]  R2224     1.7272329330444336e-01
    z[4,3,3]  R2225     4.0151754021644592e-01
    z[4,3,3]  R2226     -1.4502698183059692e-01
    z[4,3,3]  R2227     -2.2398833185434341e-02
    z[4,3,3]  R2228     1.6994623839855194e-01
    z[4,3,3]  R2229     0.409463107585907
    z[4,3,3]  R2230     3.1296434998512268e-01
    z[4,3,3]  R2231     3.5010293126106262e-01
    z[4,3,3]  R2232     0.400585800409317
    z[4,3,3]  R2233     5.1017558574676514e-01
    z[4,3,3]  R2234     6.4175719022750854e-01
    z[4,3,3]  R2235     7.9267239570617676e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2120     -1
    z[4,3,4]  R2121     1
    z[4,3,4]  R2126     -1.1761056631803513e-01
    z[4,3,4]  R2127     -4.3422105908393860e-01
    z[4,3,4]  R2128     3.9987348020076752e-02
    z[4,3,4]  R2129     2.0577311515808105e-01
    z[4,3,4]  R2130     -2.2969231009483337e-01
    z[4,3,4]  R2131     -2.3001711070537567e-01
    z[4,3,4]  R2132     -0.0957801342010498
    z[4,3,4]  R2133     -1.7863722145557404e-01
    z[4,3,4]  R2134     -1.7013189196586609e-01
    z[4,3,4]  R2135     -3.6363226175308228e-01
    z[4,3,4]  R2136     1.7837880551815033e-01
    z[4,3,4]  R2137     -3.1958669424057007e-03
    z[4,3,4]  R2138     2.6500046253204346e-01
    z[4,3,4]  R2139     -1.3820233941078186e-01
    z[4,3,4]  R2140     3.3487355709075928e-01
    z[4,3,4]  R2141     3.1450507044792175e-01
    z[4,3,4]  R2142     3.0866429209709167e-01
    z[4,3,4]  R2143     2.1685311198234558e-01
    z[4,3,4]  R2144     1.8871790170669556e-01
    z[4,3,4]  R2145     3.6806982755661011e-01
    z[4,3,4]  R2146     1.0369108617305756e-01
    z[4,3,4]  R2147     2.3422354459762573e-01
    z[4,3,4]  R2148     8.7004482746124268e-02
    z[4,3,4]  R2149     -1.0074214637279510e-01
    z[4,3,4]  R2150     -9.0319961309432983e-02
    z[4,3,4]  R2151     2.9192152619361877e-01
    z[4,3,4]  R2152     1.2943156063556671e-01
    z[4,3,4]  R2153     1.4085660874843597e-01
    z[4,3,4]  R2154     -3.4676857292652130e-02
    z[4,3,4]  R2155     -8.8697835803031921e-02
    z[4,3,4]  R2156     -1.2922429479658604e-02
    z[4,3,4]  R2157     -3.3408230543136597e-01
    z[4,3,4]  R2158     -3.7047231197357178e-01
    z[4,3,4]  R2159     1.0382376611232758e-01
    z[4,3,4]  R2160     -5.7068582624197006e-02
    z[4,3,4]  R2161     -4.5437198132276535e-02
    z[4,3,4]  R2162     1.0979046672582626e-01
    z[4,3,4]  R2163     6.2426459789276123e-01
    z[4,3,4]  R2164     1.6458596289157867e-01
    z[4,3,4]  R2165     -1.9093267619609833e-01
    z[4,3,4]  R2166     1.5055269002914429e-01
    z[4,3,4]  R2167     4.7900673747062683e-01
    z[4,3,4]  R2168     6.8221485614776611e-01
    z[4,3,4]  R2169     -2.4003732204437256e-01
    z[4,3,4]  R2170     8.7532445788383484e-02
    z[4,3,4]  R2171     1.3894857466220856e-01
    z[4,3,4]  R2172     -2.3357519507408142e-01
    z[4,3,4]  R2173     3.6047333478927612e-01
    z[4,3,4]  R2174     -1.7176365852355957e-01
    z[4,3,4]  R2175     3.8407412171363831e-01
    z[4,3,4]  R2176     3.0290532857179642e-02
    z[4,3,4]  R2177     1.6972228884696960e-01
    z[4,3,4]  R2178     -2.6506516337394714e-01
    z[4,3,4]  R2179     -6.5742902457714081e-02
    z[4,3,4]  R2180     3.7353450059890747e-01
    z[4,3,4]  R2181     -1.9902090728282928e-01
    z[4,3,4]  R2182     -1.7694956064224243e-01
    z[4,3,4]  R2183     -3.5701495409011841e-01
    z[4,3,4]  R2184     -4.2548492550849915e-01
    z[4,3,4]  R2185     -2.7885007858276367e-01
    z[4,3,4]  R2186     -3.0204278230667114e-01
    z[4,3,4]  R2187     -6.5034247934818268e-02
    z[4,3,4]  R2188     1.4242146909236908e-01
    z[4,3,4]  R2189     -3.8372558355331421e-01
    z[4,3,4]  R2190     -2.7505305409431458e-01
    z[4,3,4]  R2191     -3.5697260499000549e-01
    z[4,3,4]  R2192     1.1379770934581757e-01
    z[4,3,4]  R2193     4.8987287282943726e-01
    z[4,3,4]  R2194     2.1615803241729736e-01
    z[4,3,4]  R2195     3.1966876983642578e-01
    z[4,3,4]  R2196     2.2724738717079163e-01
    z[4,3,4]  R2197     3.7069374322891235e-01
    z[4,3,4]  R2198     -4.7022711485624313e-02
    z[4,3,4]  R2199     5.0512617826461792e-01
    z[4,3,4]  R2200     9.9318593740463257e-02
    z[4,3,4]  R2201     6.3165497779846191e-01
    z[4,3,4]  R2202     0.0630766972899437
    z[4,3,4]  R2203     0.0745469257235527
    z[4,3,4]  R2204     4.1779968142509460e-01
    z[4,3,4]  R2205     -8.4193728864192963e-02
    z[4,3,4]  R2206     1.8353018164634705e-01
    z[4,3,4]  R2207     1.4879144728183746e-01
    z[4,3,4]  R2208     -1.8214456737041473e-01
    z[4,3,4]  R2209     2.5692921876907349e-01
    z[4,3,4]  R2210     5.9604948759078979e-01
    z[4,3,4]  R2211     1.8044304102659225e-02
    z[4,3,4]  R2212     3.6404874920845032e-01
    z[4,3,4]  R2213     2.3396741598844528e-02
    z[4,3,4]  R2214     -2.8300735354423523e-01
    z[4,3,4]  R2215     -1.9731599092483521e-01
    z[4,3,4]  R2216     -4.4487681239843369e-02
    z[4,3,4]  R2217     3.2666184008121490e-02
    z[4,3,4]  R2218     1.5206189453601837e-01
    z[4,3,4]  R2219     9.2810891568660736e-02
    z[4,3,4]  R2220     9.6238173544406891e-02
    z[4,3,4]  R2221     -1.3673400878906250e-01
    z[4,3,4]  R2222     -2.0141109824180603e-01
    z[4,3,4]  R2223     2.3014084994792938e-01
    z[4,3,4]  R2224     -2.4442131817340851e-01
    z[4,3,4]  R2225     9.3896873295307159e-02
    z[4,3,4]  R2226     2.7465993165969849e-01
    z[4,3,4]  R2227     -1.7549371719360352e-01
    z[4,3,4]  R2228     -2.2474156320095062e-01
    z[4,3,4]  R2229     3.3653992414474487e-01
    z[4,3,4]  R2230     2.3855890333652496e-01
    z[4,3,4]  R2231     1.3736869394779205e-01
    z[4,3,4]  R2232     7.3812989285215735e-04
    z[4,3,4]  R2233     -5.2129936218261719e-01
    z[4,3,4]  R2234     -2.2389587759971619e-01
    z[4,3,4]  R2235     -2.0287160575389862e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2122     -1
    z[4,3,5]  R2123     1
    z[4,3,5]  R2126     5.6471548974514008e-02
    z[4,3,5]  R2127     -0.00575606245547533
    z[4,3,5]  R2128     1.4192521572113037e-01
    z[4,3,5]  R2129     -1.6009394824504852e-01
    z[4,3,5]  R2130     -2.8100606799125671e-01
    z[4,3,5]  R2131     9.9084721878170967e-03
    z[4,3,5]  R2132     -3.1752511858940125e-01
    z[4,3,5]  R2133     -2.3209697008132935e-01
    z[4,3,5]  R2134     -1.2765762209892273e-01
    z[4,3,5]  R2135     1.9370566308498383e-01
    z[4,3,5]  R2136     -1.9008180499076843e-01
    z[4,3,5]  R2137     1.2980645895004272e-01
    z[4,3,5]  R2138     -7.0155955851078033e-02
    z[4,3,5]  R2139     1.7229683697223663e-01
    z[4,3,5]  R2140     1.2577322125434875e-01
    z[4,3,5]  R2141     3.3563748002052307e-01
    z[4,3,5]  R2142     4.6237561851739883e-02
    z[4,3,5]  R2143     1.3555921614170074e-01
    z[4,3,5]  R2144     -2.0125040411949158e-01
    z[4,3,5]  R2145     4.8644743859767914e-02
    z[4,3,5]  R2146     -7.7171243727207184e-02
    z[4,3,5]  R2147     -4.4923387467861176e-03
    z[4,3,5]  R2148     6.1700176447629929e-02
    z[4,3,5]  R2149     -3.7547716498374939e-01
    z[4,3,5]  R2150     -0.0452738031744957
    z[4,3,5]  R2151     1.7261669039726257e-01
    z[4,3,5]  R2152     6.5440088510513306e-03
    z[4,3,5]  R2153     2.7864855527877808e-01
    z[4,3,5]  R2154     0.523865282535553
    z[4,3,5]  R2155     8.0336958169937134e-02
    z[4,3,5]  R2156     -7.1594923734664917e-02
    z[4,3,5]  R2157     1.2033394724130630e-01
    z[4,3,5]  R2158     -4.3070587515830994e-01
    z[4,3,5]  R2159     -2.2164934873580933e-01
    z[4,3,5]  R2160     -0.824120044708252
    z[4,3,5]  R2161     1.4033000171184540e-01
    z[4,3,5]  R2162     -9.9121198058128357e-02
    z[4,3,5]  R2163     3.9948695898056030e-01
    z[4,3,5]  R2164     2.8855550289154053e-01
    z[4,3,5]  R2165     0.0670010894536972
    z[4,3,5]  R2166     5.5497944355010986e-02
    z[4,3,5]  R2167     5.1751244068145752e-01
    z[4,3,5]  R2168     -7.3180519044399261e-02
    z[4,3,5]  R2169     1.2180896848440170e-01
    z[4,3,5]  R2170     1.0028154402971268e-01
    z[4,3,5]  R2171     -3.4219104051589966e-01
    z[4,3,5]  R2172     7.0903427898883820e-02
    z[4,3,5]  R2173     7.6070673763751984e-02
    z[4,3,5]  R2174     -3.0782202258706093e-02
    z[4,3,5]  R2175     4.3729510903358459e-01
    z[4,3,5]  R2176     1.6473619639873505e-01
    z[4,3,5]  R2177     -2.7248337864875793e-02
    z[4,3,5]  R2178     9.6197031438350677e-02
    z[4,3,5]  R2179     6.0163778066635132e-01
    z[4,3,5]  R2180     -6.0983706265687943e-02
    z[4,3,5]  R2181     2.5788676738739014e-01
    z[4,3,5]  R2182     -0.0456160232424736
    z[4,3,5]  R2183     -2.1228650212287903e-01
    z[4,3,5]  R2184     -1.7278324067592621e-01
    z[4,3,5]  R2185     -1.4928644895553589e-01
    z[4,3,5]  R2186     -4.2609229683876038e-01
    z[4,3,5]  R2187     1.2111280113458633e-01
    z[4,3,5]  R2188     -2.1845720708370209e-01
    z[4,3,5]  R2189     -2.6794201135635376e-01
    z[4,3,5]  R2190     -2.8001922369003296e-01
    z[4,3,5]  R2191     -0.5264852643013
    z[4,3,5]  R2192     -2.5525093078613281e-01
    z[4,3,5]  R2193     -2.4217948317527771e-02
    z[4,3,5]  R2194     -2.8848379850387573e-01
    z[4,3,5]  R2195     4.3418622016906738e-01
    z[4,3,5]  R2196     -1.5303204953670502e-01
    z[4,3,5]  R2197     -9.2712230980396271e-02
    z[4,3,5]  R2198     3.8863378763198853e-01
    z[4,3,5]  R2199     -3.1936866044998169e-01
    z[4,3,5]  R2200     2.8483736515045166e-01
    z[4,3,5]  R2201     2.1372631192207336e-01
    z[4,3,5]  R2202     -2.8907996416091919e-01
    z[4,3,5]  R2203     1.0884429514408112e-01
    z[4,3,5]  R2204     0.0377860963344574
    z[4,3,5]  R2205     -0.294871985912323
    z[4,3,5]  R2206     0.430424302816391
    z[4,3,5]  R2207     -1.1839371919631958e-01
    z[4,3,5]  R2208     -4.5698404312133789e-01
    z[4,3,5]  R2209     5.8323782682418823e-01
    z[4,3,5]  R2210     -3.4498110413551331e-01
    z[4,3,5]  R2211     5.0153142213821411e-01
    z[4,3,5]  R2212     -6.6374707221984863e-01
    z[4,3,5]  R2213     0.896765947341919
    z[4,3,5]  R2214     7.0995688438415527e-01
    z[4,3,5]  R2215     -4.7227197885513306e-01
    z[4,3,5]  R2216     7.5401091575622559e-01
    z[4,3,5]  R2217     2.3110548034310341e-02
    z[4,3,5]  R2218     -4.5502327382564545e-02
    z[4,3,5]  R2219     -1.5141440927982330e-01
    z[4,3,5]  R2220     4.6859785914421082e-01
    z[4,3,5]  R2221     -2.0513559877872467e-01
    z[4,3,5]  R2222     2.1855992078781128e-01
    z[4,3,5]  R2223     -1.1159786581993103e-01
    z[4,3,5]  R2224     6.7691020667552948e-02
    z[4,3,5]  R2225     5.2345430850982666e-01
    z[4,3,5]  R2226     -1.7096638679504395e-01
    z[4,3,5]  R2227     -7.6470810174942017e-01
    z[4,3,5]  R2228     -1.7447984218597412e-01
    z[4,3,5]  R2229     -0.0942888930439949
    z[4,3,5]  R2230     8.8665008544921875e-02
    z[4,3,5]  R2231     4.5969173312187195e-01
    z[4,3,5]  R2232     -1.0222969204187393e-01
    z[4,3,5]  R2233     4.4253578782081604e-01
    z[4,3,5]  R2234     2.3229949176311493e-01
    z[4,3,5]  R2235     6.2652014195919037e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2124     -1
    z[4,3,6]  R2125     1
    z[4,3,6]  R2126     3.1652396917343140e-01
    z[4,3,6]  R2127     -6.5598316490650177e-02
    z[4,3,6]  R2128     -1.4475968480110168e-01
    z[4,3,6]  R2129     5.3866535425186157e-01
    z[4,3,6]  R2130     5.9146124124526978e-01
    z[4,3,6]  R2131     -0.60360187292099
    z[4,3,6]  R2132     -5.6626528501510620e-01
    z[4,3,6]  R2133     0.00824635848402977
    z[4,3,6]  R2134     3.1562498211860657e-01
    z[4,3,6]  R2135     1.6719865798950195e-01
    z[4,3,6]  R2136     1.7597745358943939e-01
    z[4,3,6]  R2137     3.1092354655265808e-01
    z[4,3,6]  R2138     7.7080823481082916e-02
    z[4,3,6]  R2139     -4.4619336724281311e-01
    z[4,3,6]  R2140     -1.3356833159923553e-01
    z[4,3,6]  R2141     -1.6347070038318634e-01
    z[4,3,6]  R2142     -4.5246567577123642e-02
    z[4,3,6]  R2143     -4.5476046204566956e-01
    z[4,3,6]  R2144     -1.8977752327919006e-01
    z[4,3,6]  R2145     4.3836481869220734e-02
    z[4,3,6]  R2146     -3.9253199100494385e-01
    z[4,3,6]  R2147     -1.6546231508255005e-01
    z[4,3,6]  R2148     -1.3584578037261963e-01
    z[4,3,6]  R2149     2.3039807379245758e-01
    z[4,3,6]  R2150     -4.0946129709482193e-02
    z[4,3,6]  R2151     1.3760775327682495e-01
    z[4,3,6]  R2152     -6.8311393260955811e-03
    z[4,3,6]  R2153     -4.3948139995336533e-02
    z[4,3,6]  R2154     6.0904525220394135e-02
    z[4,3,6]  R2155     -3.9998155832290649e-01
    z[4,3,6]  R2156     -1.0292565822601318e-01
    z[4,3,6]  R2157     4.2694514989852905e-01
    z[4,3,6]  R2158     2.8673991560935974e-01
    z[4,3,6]  R2159     -1.7907572910189629e-02
    z[4,3,6]  R2160     -4.6501882374286652e-02
    z[4,3,6]  R2161     2.7039566636085510e-01
    z[4,3,6]  R2162     -2.3802092671394348e-01
    z[4,3,6]  R2163     -2.8519439697265625e-01
    z[4,3,6]  R2164     -1.6427727416157722e-02
    z[4,3,6]  R2165     4.0089237689971924e-01
    z[4,3,6]  R2166     1.4535829424858093e-02
    z[4,3,6]  R2167     -1.4709062874317169e-01
    z[4,3,6]  R2168     -4.9917469732463360e-03
    z[4,3,6]  R2169     -1.7179638147354126e-02
    z[4,3,6]  R2170     -4.5078076422214508e-02
    z[4,3,6]  R2171     1.2207396328449249e-01
    z[4,3,6]  R2172     -2.9277160763740540e-01
    z[4,3,6]  R2173     4.7871533036231995e-01
    z[4,3,6]  R2174     -4.5756044983863831e-01
    z[4,3,6]  R2175     -1.9415043294429779e-01
    z[4,3,6]  R2176     -8.5624635219573975e-02
    z[4,3,6]  R2177     -2.2068157792091370e-01
    z[4,3,6]  R2178     -2.5803956389427185e-01
    z[4,3,6]  R2179     -1.2441388517618179e-01
    z[4,3,6]  R2180     -1.2177091836929321e-01
    z[4,3,6]  R2181     -1.4720830321311951e-01
    z[4,3,6]  R2182     2.0740801095962524e-01
    z[4,3,6]  R2183     -5.9064473956823349e-02
    z[4,3,6]  R2184     1.2667530775070190e-01
    z[4,3,6]  R2185     -1.1722601950168610e-01
    z[4,3,6]  R2186     3.1874611973762512e-01
    z[4,3,6]  R2187     1.7620076239109039e-01
    z[4,3,6]  R2188     -4.6389183402061462e-01
    z[4,3,6]  R2189     3.3987739682197571e-01
    z[4,3,6]  R2190     -1.2304409593343735e-01
    z[4,3,6]  R2191     -1.5102137625217438e-01
    z[4,3,6]  R2192     3.6426514387130737e-01
    z[4,3,6]  R2193     1.1635456979274750e-01
    z[4,3,6]  R2194     -2.9351255297660828e-01
    z[4,3,6]  R2195     2.3197162151336670e-01
    z[4,3,6]  R2196     1.4954103529453278e-01
    z[4,3,6]  R2197     1.1755497753620148e-01
    z[4,3,6]  R2198     -7.6021656394004822e-02
    z[4,3,6]  R2199     3.6324289441108704e-01
    z[4,3,6]  R2200     -2.1538391709327698e-01
    z[4,3,6]  R2201     4.4994466006755829e-02
    z[4,3,6]  R2202     2.5756680965423584e-01
    z[4,3,6]  R2203     -9.1338776051998138e-02
    z[4,3,6]  R2204     -2.0584285259246826e-01
    z[4,3,6]  R2205     -3.1190514564514160e-01
    z[4,3,6]  R2206     -4.1874065995216370e-01
    z[4,3,6]  R2207     2.1480417251586914e-01
    z[4,3,6]  R2208     3.3693531155586243e-01
    z[4,3,6]  R2209     2.6994548738002777e-02
    z[4,3,6]  R2210     1.6113099455833435e-01
    z[4,3,6]  R2211     2.1039338409900665e-01
    z[4,3,6]  R2212     2.6457908749580383e-01
    z[4,3,6]  R2213     -1.9243661314249039e-02
    z[4,3,6]  R2214     -2.2608275711536407e-01
    z[4,3,6]  R2215     1.1658965051174164e-01
    z[4,3,6]  R2216     -3.4674385190010071e-01
    z[4,3,6]  R2217     -2.0819826424121857e-01
    z[4,3,6]  R2218     -3.6833170056343079e-01
    z[4,3,6]  R2219     4.3919944763183594e-01
    z[4,3,6]  R2220     2.0566870272159576e-01
    z[4,3,6]  R2221     -2.2956621646881104e-01
    z[4,3,6]  R2222     1.0010523721575737e-02
    z[4,3,6]  R2223     -3.8473281264305115e-01
    z[4,3,6]  R2224     -6.1834228038787842e-01
    z[4,3,6]  R2225     -1.2329224497079849e-01
    z[4,3,6]  R2226     -1.6788972914218903e-01
    z[4,3,6]  R2227     -1.7228076234459877e-02
    z[4,3,6]  R2228     -2.4053168296813965e-01
    z[4,3,6]  R2229     -1.7618584632873535e-01
    z[4,3,6]  R2230     -3.4975594282150269e-01
    z[4,3,6]  R2231     -7.9743430018424988e-02
    z[4,3,6]  R2232     -1.9918261468410492e-01
    z[4,3,6]  R2233     -1.5136629343032837e-01
    z[4,3,6]  R2234     2.3564919829368591e-02
    z[4,3,6]  R2235     4.8643615096807480e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2330     -1
    z[4,5,0]  R2331     1
    z[4,5,0]  R2344     -8.4715768694877625e-02
    z[4,5,0]  R2345     3.7786862254142761e-01
    z[4,5,0]  R2346     -1.0474388301372528e-01
    z[4,5,0]  R2347     -4.3095737695693970e-01
    z[4,5,0]  R2348     -5.7242126204073429e-03
    z[4,5,0]  R2349     -1.0527808219194412e-01
    z[4,5,0]  R2350     -1.3672526180744171e-01
    z[4,5,0]  R2351     -2.7547001838684082e-01
    z[4,5,0]  R2352     5.8763694763183594e-01
    z[4,5,0]  R2353     4.1692918539047241e-01
    z[4,5,0]  R2354     3.1882929615676403e-03
    z[4,5,0]  R2355     0.350115031003952
    z[4,5,0]  R2356     1.0460475832223892e-01
    z[4,5,0]  R2357     4.6982610225677490e-01
    z[4,5,0]  R2358     -2.1524028852581978e-02
    z[4,5,0]  R2359     4.8068743199110031e-02
    z[4,5,0]  R2360     -1.2982851266860962e-01
    z[4,5,0]  R2361     -5.4572790861129761e-02
    z[4,5,0]  R2362     9.8200999200344086e-02
    z[4,5,0]  R2363     -7.6632252894341946e-03
    z[4,5,0]  R2364     2.2449608147144318e-01
    z[4,5,0]  R2365     1.2216307967901230e-01
    z[4,5,0]  R2366     2.6040667295455933e-01
    z[4,5,0]  R2367     4.6720737218856812e-01
    z[4,5,0]  R2368     4.2385819554328918e-01
    z[4,5,0]  R2369     4.0700322389602661e-01
    z[4,5,0]  R2370     1.1096493899822235e-01
    z[4,5,0]  R2371     5.0646132230758667e-01
    z[4,5,0]  R2372     0.467808336019516
    z[4,5,0]  R2373     4.6968027949333191e-01
    z[4,5,0]  R2374     4.4905692338943481e-02
    z[4,5,0]  R2375     2.7488011121749878e-01
    z[4,5,0]  R2376     4.9197757244110107e-01
    z[4,5,0]  R2377     -1.0621292144060135e-01
    z[4,5,0]  R2378     3.2745444774627686e-01
    z[4,5,0]  R2379     3.9802014827728271e-01
    z[4,5,0]  R2380     3.4995537996292114e-01
    z[4,5,0]  R2381     -1.5063305199146271e-01
    z[4,5,0]  R2382     4.7343918681144714e-01
    z[4,5,0]  R2383     -2.1048258244991302e-01
    z[4,5,0]  R2384     3.3840200304985046e-01
    z[4,5,0]  R2385     4.9328714609146118e-02
    z[4,5,0]  R2386     1.6332606971263885e-01
    z[4,5,0]  R2387     0.0453437939286232
    z[4,5,0]  R2388     1.0652531683444977e-01
    z[4,5,0]  R2389     1.7694209516048431e-01
    z[4,5,0]  R2390     3.9981940388679504e-01
    z[4,5,0]  R2391     -3.0972000211477280e-02
    z[4,5,0]  R2392     1.7476992681622505e-02
    z[4,5,0]  R2393     -1.1291588842868805e-01
    z[4,5,0]  R2394     -1.9607307389378548e-02
    z[4,5,0]  R2395     4.8747184872627258e-01
    z[4,5,0]  R2396     1.8454360961914062e-01
    z[4,5,0]  R2397     8.6628451943397522e-02
    z[4,5,0]  R2398     -4.6332213096320629e-03
    z[4,5,0]  R2399     -0.133395716547966
    z[4,5,0]  R2400     -3.1193557381629944e-01
    z[4,5,0]  R2401     -2.5365066528320312e-01
    z[4,5,0]  R2402     -5.2966989576816559e-02
    z[4,5,0]  R2403     -1.6295957565307617e-01
    z[4,5,0]  R2404     4.2942172288894653e-01
    z[4,5,0]  R2405     -2.3111522197723389e-01
    z[4,5,0]  R2406     5.0620734691619873e-01
    z[4,5,0]  R2407     3.2991644740104675e-01
    z[4,5,0]  R2408     -8.9085623621940613e-02
    z[4,5,0]  R2409     -5.8000821620225906e-02
    z[4,5,0]  R2410     3.1568494439125061e-01
    z[4,5,0]  R2411     1.6023042798042297e-01
    z[4,5,0]  R2412     -2.2212259471416473e-01
    z[4,5,0]  R2413     3.0740559101104736e-01
    z[4,5,0]  R2414     -9.0094543993473053e-02
    z[4,5,0]  R2415     3.9716640114784241e-01
    z[4,5,0]  R2416     -2.3172914981842041e-01
    z[4,5,0]  R2417     1.7375090718269348e-01
    z[4,5,0]  R2418     2.0802558958530426e-01
    z[4,5,0]  R2419     -2.7975955605506897e-01
    z[4,5,0]  R2420     -0.29337078332901
    z[4,5,0]  R2421     -1.1495106155052781e-03
    z[4,5,0]  R2422     -1.6729475557804108e-01
    z[4,5,0]  R2423     -4.1556453704833984e-01
    z[4,5,0]  R2424     -1.5465673059225082e-02
    z[4,5,0]  R2425     1.2804825603961945e-01
    z[4,5,0]  R2426     1.2401670217514038e-01
    z[4,5,0]  R2427     1.9561153650283813e-01
    z[4,5,0]  R2428     3.1262066960334778e-01
    z[4,5,0]  R2429     1.5708579123020172e-01
    z[4,5,0]  R2430     1.5607194602489471e-01
    z[4,5,0]  R2431     4.3293327093124390e-01
    z[4,5,0]  R2432     1.9849990308284760e-01
    z[4,5,0]  R2433     2.9485905170440674e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2332     -1
    z[4,5,1]  R2333     1
    z[4,5,1]  R2344     -7.2566747665405273e-01
    z[4,5,1]  R2345     -0.601925790309906
    z[4,5,1]  R2346     -4.3660253286361694e-01
    z[4,5,1]  R2347     -0.560893714427948
    z[4,5,1]  R2348     -7.1033054590225220e-01
    z[4,5,1]  R2349     -5.6445884704589844e-01
    z[4,5,1]  R2350     -5.5630582571029663e-01
    z[4,5,1]  R2351     -7.3707896471023560e-01
    z[4,5,1]  R2352     6.5864127874374390e-01
    z[4,5,1]  R2353     -6.6119700670242310e-02
    z[4,5,1]  R2354     8.3957237005233765e-01
    z[4,5,1]  R2355     7.5983101129531860e-01
    z[4,5,1]  R2356     8.9190721511840820e-01
    z[4,5,1]  R2357     0.68828946352005
    z[4,5,1]  R2358     8.4670531749725342e-01
    z[4,5,1]  R2359     8.4243708848953247e-01
    z[4,5,1]  R2360     7.9136216640472412e-01
    z[4,5,1]  R2361     7.4902480840682983e-01
    z[4,5,1]  R2362     8.6116957664489746e-01
    z[4,5,1]  R2363     8.7653368711471558e-01
    z[4,5,1]  R2364     8.3442175388336182e-01
    z[4,5,1]  R2365     8.3425015211105347e-01
    z[4,5,1]  R2366     8.9899486303329468e-01
    z[4,5,1]  R2367     5.9249097108840942e-01
    z[4,5,1]  R2368     5.9265911579132080e-01
    z[4,5,1]  R2369     -6.9072662154212594e-04
    z[4,5,1]  R2370     3.1029152870178223e-01
    z[4,5,1]  R2371     1.9548442959785461e-01
    z[4,5,1]  R2372     5.6558477878570557e-01
    z[4,5,1]  R2373     6.0634356737136841e-01
    z[4,5,1]  R2374     -6.8122547864913940e-01
    z[4,5,1]  R2375     -6.7748540639877319e-01
    z[4,5,1]  R2376     6.7459249496459961e-01
    z[4,5,1]  R2377     -8.1346917152404785e-01
    z[4,5,1]  R2378     -7.0029234886169434e-01
    z[4,5,1]  R2379     5.2877306938171387e-01
    z[4,5,1]  R2380     5.9612405300140381e-01
    z[4,5,1]  R2381     -1.8770109117031097e-01
    z[4,5,1]  R2382     5.2165532112121582e-01
    z[4,5,1]  R2383     8.9386940002441406e-01
    z[4,5,1]  R2384     8.1641274690628052e-01
    z[4,5,1]  R2385     8.4431940317153931e-01
    z[4,5,1]  R2386     -2.0611999928951263e-01
    z[4,5,1]  R2387     -6.5368312597274780e-01
    z[4,5,1]  R2388     -2.7324327826499939e-01
    z[4,5,1]  R2389     7.9011809825897217e-01
    z[4,5,1]  R2390     6.1137682199478149e-01
    z[4,5,1]  R2391     2.6357316970825195e-01
    z[4,5,1]  R2392     -4.6956473588943481e-01
    z[4,5,1]  R2393     1.1211547255516052e-01
    z[4,5,1]  R2394     -8.9405238628387451e-01
    z[4,5,1]  R2395     0.65756756067276
    z[4,5,1]  R2396     8.2068479061126709e-01
    z[4,5,1]  R2397     -0.741539478302002
    z[4,5,1]  R2398     0.904663622379303
    z[4,5,1]  R2399     -5.9420973062515259e-01
    z[4,5,1]  R2400     -0.470384418964386
    z[4,5,1]  R2401     -3.7736091017723083e-01
    z[4,5,1]  R2402     -8.1561100482940674e-01
    z[4,5,1]  R2403     -5.2647686004638672e-01
    z[4,5,1]  R2404     6.3006180524826050e-01
    z[4,5,1]  R2405     -4.2134487628936768e-01
    z[4,5,1]  R2406     0.691325306892395
    z[4,5,1]  R2407     -0.750025749206543
    z[4,5,1]  R2408     -6.0750845819711685e-02
    z[4,5,1]  R2409     1.1036308109760284e-01
    z[4,5,1]  R2410     0.545853316783905
    z[4,5,1]  R2411     7.5227451324462891e-01
    z[4,5,1]  R2412     -5.3734356164932251e-01
    z[4,5,1]  R2413     4.6872133016586304e-01
    z[4,5,1]  R2414     -7.4568390846252441e-01
    z[4,5,1]  R2415     -8.3605545759201050e-01
    z[4,5,1]  R2416     -6.1399626731872559e-01
    z[4,5,1]  R2417     6.9033062458038330e-01
    z[4,5,1]  R2418     6.4332503080368042e-01
    z[4,5,1]  R2419     5.5489885807037354e-01
    z[4,5,1]  R2420     6.9776940345764160e-01
    z[4,5,1]  R2421     4.6602910757064819e-01
    z[4,5,1]  R2422     5.1794224977493286e-01
    z[4,5,1]  R2423     7.5704419612884521e-01
    z[4,5,1]  R2424     -7.6356285810470581e-01
    z[4,5,1]  R2425     -2.0082026720046997e-01
    z[4,5,1]  R2426     -5.0230443477630615e-01
    z[4,5,1]  R2427     7.5273811817169189e-01
    z[4,5,1]  R2428     6.8352770805358887e-01
    z[4,5,1]  R2429     -6.8227595090866089e-01
    z[4,5,1]  R2430     5.6851136684417725e-01
    z[4,5,1]  R2431     5.7080060243606567e-01
    z[4,5,1]  R2432     5.5767953395843506e-01
    z[4,5,1]  R2433     -0.652384340763092
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2334     -1
    z[4,5,2]  R2335     1
    z[4,5,2]  R2344     -3.8860204815864563e-01
    z[4,5,2]  R2345     -3.0724689364433289e-01
    z[4,5,2]  R2346     -1.4385642111301422e-01
    z[4,5,2]  R2347     4.1887059807777405e-02
    z[4,5,2]  R2348     -9.1320149600505829e-02
    z[4,5,2]  R2349     -4.9124547839164734e-01
    z[4,5,2]  R2350     1.5303640067577362e-01
    z[4,5,2]  R2351     -1.8345442414283752e-01
    z[4,5,2]  R2352     -2.6607409119606018e-01
    z[4,5,2]  R2353     -1.6967274248600006e-01
    z[4,5,2]  R2354     2.1964015066623688e-01
    z[4,5,2]  R2355     -5.4684713482856750e-02
    z[4,5,2]  R2356     -3.1715580821037292e-01
    z[4,5,2]  R2357     1.5045984089374542e-01
    z[4,5,2]  R2358     -3.3043643832206726e-01
    z[4,5,2]  R2359     5.8519367128610611e-02
    z[4,5,2]  R2360     1.5012061595916748e-01
    z[4,5,2]  R2361     9.6426717936992645e-02
    z[4,5,2]  R2362     -3.5265842080116272e-01
    z[4,5,2]  R2363     2.7463451027870178e-01
    z[4,5,2]  R2364     2.7208182215690613e-01
    z[4,5,2]  R2365     4.5037293434143066e-01
    z[4,5,2]  R2366     -1.3624326884746552e-01
    z[4,5,2]  R2367     4.6888992190361023e-01
    z[4,5,2]  R2368     6.5142136812210083e-01
    z[4,5,2]  R2369     -6.4343822002410889e-01
    z[4,5,2]  R2370     -6.2557244300842285e-01
    z[4,5,2]  R2371     -6.9579696655273438e-01
    z[4,5,2]  R2372     0.331856369972229
    z[4,5,2]  R2373     -2.7549099922180176e-01
    z[4,5,2]  R2374     -2.5429481267929077e-01
    z[4,5,2]  R2375     -4.7350153326988220e-01
    z[4,5,2]  R2376     -1.6671952605247498e-01
    z[4,5,2]  R2377     -6.9923691451549530e-02
    z[4,5,2]  R2378     5.1851324737071991e-02
    z[4,5,2]  R2379     -6.2837436795234680e-02
    z[4,5,2]  R2380     -1.7073693871498108e-01
    z[4,5,2]  R2381     -4.8172447085380554e-01
    z[4,5,2]  R2382     -5.1995605230331421e-01
    z[4,5,2]  R2383     -5.7836681604385376e-02
    z[4,5,2]  R2384     2.4669414758682251e-01
    z[4,5,2]  R2385     -1.1313141882419586e-01
    z[4,5,2]  R2386     -1.0266650468111038e-01
    z[4,5,2]  R2387     2.6764890551567078e-01
    z[4,5,2]  R2388     1.7920050024986267e-01
    z[4,5,2]  R2389     3.4833726286888123e-01
    z[4,5,2]  R2390     3.7064486742019653e-01
    z[4,5,2]  R2391     -0.321865051984787
    z[4,5,2]  R2392     -2.4265077710151672e-01
    z[4,5,2]  R2393     3.4573718905448914e-01
    z[4,5,2]  R2394     -1.5769918262958527e-01
    z[4,5,2]  R2395     -4.5038771629333496e-01
    z[4,5,2]  R2396     -3.4964182972908020e-01
    z[4,5,2]  R2397     -4.9290037155151367e-01
    z[4,5,2]  R2398     -7.1905307471752167e-02
    z[4,5,2]  R2399     -1.6450406610965729e-01
    z[4,5,2]  R2400     9.9394604563713074e-02
    z[4,5,2]  R2401     1.7148096859455109e-01
    z[4,5,2]  R2402     1.2626454234123230e-01
    z[4,5,2]  R2403     -3.3183717727661133e-01
    z[4,5,2]  R2404     3.0751636624336243e-01
    z[4,5,2]  R2405     2.0369198918342590e-01
    z[4,5,2]  R2406     0.282680869102478
    z[4,5,2]  R2407     3.1261113286018372e-01
    z[4,5,2]  R2408     -5.2417612075805664e-01
    z[4,5,2]  R2409     1.0222312062978745e-01
    z[4,5,2]  R2410     3.1969651579856873e-01
    z[4,5,2]  R2411     -2.1627022325992584e-01
    z[4,5,2]  R2412     -3.8786804676055908e-01
    z[4,5,2]  R2413     4.1406969539821148e-03
    z[4,5,2]  R2414     3.2021556049585342e-02
    z[4,5,2]  R2415     1.3430744409561157e-01
    z[4,5,2]  R2416     -2.9622071981430054e-01
    z[4,5,2]  R2417     -6.7097288370132446e-01
    z[4,5,2]  R2418     2.2424674034118652e-01
    z[4,5,2]  R2419     -3.8256937265396118e-01
    z[4,5,2]  R2420     -4.1397172212600708e-01
    z[4,5,2]  R2421     -0.676310658454895
    z[4,5,2]  R2422     -6.0162127017974854e-01
    z[4,5,2]  R2423     2.3310698568820953e-01
    z[4,5,2]  R2424     -2.2924098372459412e-01
    z[4,5,2]  R2425     -4.4149917364120483e-01
    z[4,5,2]  R2426     2.4197886884212494e-01
    z[4,5,2]  R2427     -5.4202873259782791e-02
    z[4,5,2]  R2428     -4.5376177877187729e-02
    z[4,5,2]  R2429     3.4249746799468994e-01
    z[4,5,2]  R2430     3.1649532914161682e-01
    z[4,5,2]  R2431     -3.9023196697235107e-01
    z[4,5,2]  R2432     -2.1241942048072815e-01
    z[4,5,2]  R2433     1.6354057192802429e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2336     -1
    z[4,5,3]  R2337     1
    z[4,5,3]  R2344     4.4498276710510254e-01
    z[4,5,3]  R2345     4.5564872026443481e-01
    z[4,5,3]  R2346     8.5733026266098022e-01
    z[4,5,3]  R2347     3.7388020753860474e-01
    z[4,5,3]  R2348     -7.4222773313522339e-02
    z[4,5,3]  R2349     -1.0788592696189880e-01
    z[4,5,3]  R2350     4.6664497256278992e-01
    z[4,5,3]  R2351     -5.1120144128799438e-01
    z[4,5,3]  R2352     -7.2239659726619720e-02
    z[4,5,3]  R2353     -7.7155923843383789e-01
    z[4,5,3]  R2354     -0.384640634059906
    z[4,5,3]  R2355     -4.2843019962310791e-01
    z[4,5,3]  R2356     1.0900925099849701e-01
    z[4,5,3]  R2357     -1.8710485100746155e-01
    z[4,5,3]  R2358     1.6624949872493744e-01
    z[4,5,3]  R2359     2.1511860191822052e-01
    z[4,5,3]  R2360     -4.8466023802757263e-01
    z[4,5,3]  R2361     -3.9303550124168396e-01
    z[4,5,3]  R2362     -1.1065232008695602e-01
    z[4,5,3]  R2363     1.2822882831096649e-01
    z[4,5,3]  R2364     -9.2328958213329315e-02
    z[4,5,3]  R2365     6.3312657177448273e-02
    z[4,5,3]  R2366     -2.7496090531349182e-01
    z[4,5,3]  R2367     -8.1231839954853058e-02
    z[4,5,3]  R2368     -1.8128865957260132e-01
    z[4,5,3]  R2369     -0.535149097442627
    z[4,5,3]  R2370     -6.9514250755310059e-01
    z[4,5,3]  R2371     -3.4890174865722656e-01
    z[4,5,3]  R2372     2.6794403791427612e-01
    z[4,5,3]  R2373     4.0192779898643494e-01
    z[4,5,3]  R2374     5.3208708763122559e-01
    z[4,5,3]  R2375     -6.7700318992137909e-02
    z[4,5,3]  R2376     -1.8652331829071045e-01
    z[4,5,3]  R2377     -2.6899260282516479e-01
    z[4,5,3]  R2378     -1.1053077131509781e-01
    z[4,5,3]  R2379     -6.1051309108734131e-01
    z[4,5,3]  R2380     -4.5318952202796936e-01
    z[4,5,3]  R2381     8.3257085084915161e-01
    z[4,5,3]  R2382     -2.9941469430923462e-01
    z[4,5,3]  R2383     -3.3782172203063965e-01
    z[4,5,3]  R2384     1.8651817739009857e-01
    z[4,5,3]  R2385     -1.5265716612339020e-01
    z[4,5,3]  R2386     8.7237930297851562e-01
    z[4,5,3]  R2387     2.3032648861408234e-01
    z[4,5,3]  R2388     7.4780148267745972e-01
    z[4,5,3]  R2389     -1.2419898062944412e-01
    z[4,5,3]  R2390     -1.8971423804759979e-01
    z[4,5,3]  R2391     8.0624425411224365e-01
    z[4,5,3]  R2392     7.4304181337356567e-01
    z[4,5,3]  R2393     7.6708149909973145e-01
    z[4,5,3]  R2394     -3.8678354024887085e-01
    z[4,5,3]  R2395     -1.7900021374225616e-01
    z[4,5,3]  R2396     3.1066963076591492e-01
    z[4,5,3]  R2397     4.3569728732109070e-01
    z[4,5,3]  R2398     -2.8471006080508232e-02
    z[4,5,3]  R2399     4.4629785418510437e-01
    z[4,5,3]  R2400     5.9161442518234253e-01
    z[4,5,3]  R2401     4.7145324945449829e-01
    z[4,5,3]  R2402     3.5779750347137451e-01
    z[4,5,3]  R2403     3.3317390084266663e-01
    z[4,5,3]  R2404     -5.2699881792068481e-01
    z[4,5,3]  R2405     5.4240685701370239e-01
    z[4,5,3]  R2406     -2.0581322908401489e-01
    z[4,5,3]  R2407     1.1047840118408203e-02
    z[4,5,3]  R2408     7.0259046554565430e-01
    z[4,5,3]  R2409     9.2891907691955566e-01
    z[4,5,3]  R2410     -3.5196724534034729e-01
    z[4,5,3]  R2411     3.0686733126640320e-01
    z[4,5,3]  R2412     3.9088377356529236e-01
    z[4,5,3]  R2413     -3.0861553549766541e-01
    z[4,5,3]  R2414     -2.1929587423801422e-01
    z[4,5,3]  R2415     1.1554061621427536e-01
    z[4,5,3]  R2416     -1.4648194611072540e-01
    z[4,5,3]  R2417     5.5972304195165634e-02
    z[4,5,3]  R2418     4.1575622558593750e-01
    z[4,5,3]  R2419     -1.5586887300014496e-01
    z[4,5,3]  R2420     -3.8521891832351685e-01
    z[4,5,3]  R2421     -6.8435288965702057e-02
    z[4,5,3]  R2422     5.9285301715135574e-02
    z[4,5,3]  R2423     5.6945491582155228e-02
    z[4,5,3]  R2424     3.5616809129714966e-01
    z[4,5,3]  R2425     7.6187252998352051e-01
    z[4,5,3]  R2426     7.9293966293334961e-01
    z[4,5,3]  R2427     4.6142944693565369e-01
    z[4,5,3]  R2428     2.7731695771217346e-01
    z[4,5,3]  R2429     3.4239280223846436e-01
    z[4,5,3]  R2430     -2.7753153443336487e-01
    z[4,5,3]  R2431     4.9526520073413849e-02
    z[4,5,3]  R2432     -2.2915895283222198e-01
    z[4,5,3]  R2433     8.4319151937961578e-02
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2338     -1
    z[4,5,4]  R2339     1
    z[4,5,4]  R2344     -1.1761056631803513e-01
    z[4,5,4]  R2345     -4.3422105908393860e-01
    z[4,5,4]  R2346     3.9987348020076752e-02
    z[4,5,4]  R2347     2.0577311515808105e-01
    z[4,5,4]  R2348     -2.2969231009483337e-01
    z[4,5,4]  R2349     -2.3001711070537567e-01
    z[4,5,4]  R2350     -0.0957801342010498
    z[4,5,4]  R2351     -1.7863722145557404e-01
    z[4,5,4]  R2352     -1.7013189196586609e-01
    z[4,5,4]  R2353     -3.6363226175308228e-01
    z[4,5,4]  R2354     1.7837880551815033e-01
    z[4,5,4]  R2355     -3.1958669424057007e-03
    z[4,5,4]  R2356     2.6500046253204346e-01
    z[4,5,4]  R2357     -1.3820233941078186e-01
    z[4,5,4]  R2358     3.3487355709075928e-01
    z[4,5,4]  R2359     3.1450507044792175e-01
    z[4,5,4]  R2360     3.0866429209709167e-01
    z[4,5,4]  R2361     2.1685311198234558e-01
    z[4,5,4]  R2362     1.8871790170669556e-01
    z[4,5,4]  R2363     3.6806982755661011e-01
    z[4,5,4]  R2364     1.0369108617305756e-01
    z[4,5,4]  R2365     2.3422354459762573e-01
    z[4,5,4]  R2366     8.7004482746124268e-02
    z[4,5,4]  R2367     -1.0074214637279510e-01
    z[4,5,4]  R2368     -9.0319961309432983e-02
    z[4,5,4]  R2369     2.9192152619361877e-01
    z[4,5,4]  R2370     1.2943156063556671e-01
    z[4,5,4]  R2371     1.4085660874843597e-01
    z[4,5,4]  R2372     -3.4676857292652130e-02
    z[4,5,4]  R2373     -8.8697835803031921e-02
    z[4,5,4]  R2374     -0.407550185918808
    z[4,5,4]  R2375     1.0992280393838882e-01
    z[4,5,4]  R2376     -6.1532676219940186e-02
    z[4,5,4]  R2377     -5.0204541534185410e-02
    z[4,5,4]  R2378     -4.9264460802078247e-01
    z[4,5,4]  R2379     -2.8671622276306152e-01
    z[4,5,4]  R2380     2.6149597018957138e-02
    z[4,5,4]  R2381     7.3123171925544739e-02
    z[4,5,4]  R2382     4.4613435864448547e-02
    z[4,5,4]  R2383     -0.0691533163189888
    z[4,5,4]  R2384     0.07137431204319
    z[4,5,4]  R2385     2.4950174987316132e-01
    z[4,5,4]  R2386     1.0654534399509430e-01
    z[4,5,4]  R2387     -4.5509532094001770e-01
    z[4,5,4]  R2388     -3.6515191197395325e-01
    z[4,5,4]  R2389     -0.416479229927063
    z[4,5,4]  R2390     -4.0927022695541382e-01
    z[4,5,4]  R2391     -1.9846189022064209e-01
    z[4,5,4]  R2392     -1.9453060626983643e-01
    z[4,5,4]  R2393     3.6199086904525757e-01
    z[4,5,4]  R2394     6.9938585162162781e-02
    z[4,5,4]  R2395     -1.3595966994762421e-01
    z[4,5,4]  R2396     -1.5079443156719208e-01
    z[4,5,4]  R2397     -4.1097655892372131e-02
    z[4,5,4]  R2398     2.1752344444394112e-02
    z[4,5,4]  R2399     -1.8148691952228546e-01
    z[4,5,4]  R2400     1.0181655734777451e-01
    z[4,5,4]  R2401     6.8882554769515991e-01
    z[4,5,4]  R2402     4.0979516506195068e-01
    z[4,5,4]  R2403     0.576056957244873
    z[4,5,4]  R2404     2.0964258909225464e-01
    z[4,5,4]  R2405     3.7249827384948730e-01
    z[4,5,4]  R2406     -1.2518243491649628e-01
    z[4,5,4]  R2407     -2.4802911281585693e-01
    z[4,5,4]  R2408     7.4077457189559937e-02
    z[4,5,4]  R2409     1.6445495188236237e-01
    z[4,5,4]  R2410     -1.8125905096530914e-01
    z[4,5,4]  R2411     4.0912351012229919e-01
    z[4,5,4]  R2412     5.2063208818435669e-01
    z[4,5,4]  R2413     3.7820154428482056e-01
    z[4,5,4]  R2414     4.0455322712659836e-02
    z[4,5,4]  R2415     -1.0657750535756350e-03
    z[4,5,4]  R2416     -4.4077765941619873e-01
    z[4,5,4]  R2417     1.6311611235141754e-01
    z[4,5,4]  R2418     -3.8399747014045715e-01
    z[4,5,4]  R2419     -2.7723035216331482e-01
    z[4,5,4]  R2420     1.5596590936183929e-01
    z[4,5,4]  R2421     -5.1666635274887085e-01
    z[4,5,4]  R2422     -4.1069126129150391e-01
    z[4,5,4]  R2423     3.2260903716087341e-01
    z[4,5,4]  R2424     4.1462130844593048e-02
    z[4,5,4]  R2425     -1.7017647624015808e-01
    z[4,5,4]  R2426     5.4746586829423904e-02
    z[4,5,4]  R2427     -3.8583523035049438e-01
    z[4,5,4]  R2428     -2.4354654550552368e-01
    z[4,5,4]  R2429     3.6474749445915222e-01
    z[4,5,4]  R2430     -2.8474736213684082e-01
    z[4,5,4]  R2431     4.2725983262062073e-01
    z[4,5,4]  R2432     5.4021787643432617e-01
    z[4,5,4]  R2433     -4.9213051795959473e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2340     -1
    z[4,5,5]  R2341     1
    z[4,5,5]  R2344     5.6471548974514008e-02
    z[4,5,5]  R2345     -0.00575606245547533
    z[4,5,5]  R2346     1.4192521572113037e-01
    z[4,5,5]  R2347     -1.6009394824504852e-01
    z[4,5,5]  R2348     -2.8100606799125671e-01
    z[4,5,5]  R2349     9.9084721878170967e-03
    z[4,5,5]  R2350     -3.1752511858940125e-01
    z[4,5,5]  R2351     -2.3209697008132935e-01
    z[4,5,5]  R2352     -1.2765762209892273e-01
    z[4,5,5]  R2353     1.9370566308498383e-01
    z[4,5,5]  R2354     -1.9008180499076843e-01
    z[4,5,5]  R2355     1.2980645895004272e-01
    z[4,5,5]  R2356     -7.0155955851078033e-02
    z[4,5,5]  R2357     1.7229683697223663e-01
    z[4,5,5]  R2358     1.2577322125434875e-01
    z[4,5,5]  R2359     3.3563748002052307e-01
    z[4,5,5]  R2360     4.6237561851739883e-02
    z[4,5,5]  R2361     1.3555921614170074e-01
    z[4,5,5]  R2362     -2.0125040411949158e-01
    z[4,5,5]  R2363     4.8644743859767914e-02
    z[4,5,5]  R2364     -7.7171243727207184e-02
    z[4,5,5]  R2365     -4.4923387467861176e-03
    z[4,5,5]  R2366     6.1700176447629929e-02
    z[4,5,5]  R2367     -3.7547716498374939e-01
    z[4,5,5]  R2368     -0.0452738031744957
    z[4,5,5]  R2369     1.7261669039726257e-01
    z[4,5,5]  R2370     6.5440088510513306e-03
    z[4,5,5]  R2371     2.7864855527877808e-01
    z[4,5,5]  R2372     0.523865282535553
    z[4,5,5]  R2373     8.0336958169937134e-02
    z[4,5,5]  R2374     -6.6448740661144257e-02
    z[4,5,5]  R2375     -2.0032858848571777e-01
    z[4,5,5]  R2376     -4.6768745779991150e-01
    z[4,5,5]  R2377     5.4006807506084442e-02
    z[4,5,5]  R2378     -3.8019725680351257e-01
    z[4,5,5]  R2379     -2.8030180931091309e-01
    z[4,5,5]  R2380     -0.13898965716362
    z[4,5,5]  R2381     4.4669758528470993e-02
    z[4,5,5]  R2382     1.2786471843719482e-01
    z[4,5,5]  R2383     -1.5990903973579407e-01
    z[4,5,5]  R2384     2.9171234369277954e-01
    z[4,5,5]  R2385     2.6608529686927795e-01
    z[4,5,5]  R2386     1.8212196230888367e-01
    z[4,5,5]  R2387     -3.5044002532958984e-01
    z[4,5,5]  R2388     3.0996114015579224e-01
    z[4,5,5]  R2389     1.8105560541152954e-01
    z[4,5,5]  R2390     7.2475492954254150e-02
    z[4,5,5]  R2391     3.5527545213699341e-01
    z[4,5,5]  R2392     2.4875281751155853e-01
    z[4,5,5]  R2393     3.3961758017539978e-01
    z[4,5,5]  R2394     1.3228674232959747e-01
    z[4,5,5]  R2395     2.4678136408329010e-01
    z[4,5,5]  R2396     2.2562603652477264e-01
    z[4,5,5]  R2397     7.9707249999046326e-02
    z[4,5,5]  R2398     -2.2326244413852692e-01
    z[4,5,5]  R2399     2.3951642215251923e-01
    z[4,5,5]  R2400     1.1684230715036392e-01
    z[4,5,5]  R2401     2.3714546859264374e-01
    z[4,5,5]  R2402     -1.2539631128311157e-01
    z[4,5,5]  R2403     3.4624379873275757e-01
    z[4,5,5]  R2404     -4.3736483901739120e-02
    z[4,5,5]  R2405     0.495735228061676
    z[4,5,5]  R2406     -2.8402847051620483e-01
    z[4,5,5]  R2407     -4.0881112217903137e-01
    z[4,5,5]  R2408     4.6252843737602234e-01
    z[4,5,5]  R2409     2.7142751216888428e-01
    z[4,5,5]  R2410     5.7872855663299561e-01
    z[4,5,5]  R2411     -3.0829516053199768e-01
    z[4,5,5]  R2412     -2.7387544512748718e-01
    z[4,5,5]  R2413     -1.7499661445617676e-01
    z[4,5,5]  R2414     -5.5390429496765137e-01
    z[4,5,5]  R2415     8.0321721732616425e-02
    z[4,5,5]  R2416     -3.3402532339096069e-01
    z[4,5,5]  R2417     -7.4996486306190491e-02
    z[4,5,5]  R2418     -2.1256893873214722e-01
    z[4,5,5]  R2419     -4.5390984416007996e-01
    z[4,5,5]  R2420     2.7678820490837097e-01
    z[4,5,5]  R2421     -5.7354439049959183e-02
    z[4,5,5]  R2422     1.0543572902679443e-01
    z[4,5,5]  R2423     2.4937982857227325e-01
    z[4,5,5]  R2424     1.0438472777605057e-01
    z[4,5,5]  R2425     3.7046140432357788e-01
    z[4,5,5]  R2426     1.9523890316486359e-01
    z[4,5,5]  R2427     -1.6952624917030334e-01
    z[4,5,5]  R2428     -1.2062735855579376e-01
    z[4,5,5]  R2429     -1.1992149800062180e-01
    z[4,5,5]  R2430     1.9417542219161987e-01
    z[4,5,5]  R2431     2.3745548725128174e-01
    z[4,5,5]  R2432     4.2656177282333374e-01
    z[4,5,5]  R2433     3.4880742430686951e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2342     -1
    z[4,5,6]  R2343     1
    z[4,5,6]  R2344     3.1652396917343140e-01
    z[4,5,6]  R2345     -6.5598316490650177e-02
    z[4,5,6]  R2346     -1.4475968480110168e-01
    z[4,5,6]  R2347     5.3866535425186157e-01
    z[4,5,6]  R2348     5.9146124124526978e-01
    z[4,5,6]  R2349     -0.60360187292099
    z[4,5,6]  R2350     -5.6626528501510620e-01
    z[4,5,6]  R2351     0.00824635848402977
    z[4,5,6]  R2352     3.1562498211860657e-01
    z[4,5,6]  R2353     1.6719865798950195e-01
    z[4,5,6]  R2354     1.7597745358943939e-01
    z[4,5,6]  R2355     3.1092354655265808e-01
    z[4,5,6]  R2356     7.7080823481082916e-02
    z[4,5,6]  R2357     -4.4619336724281311e-01
    z[4,5,6]  R2358     -1.3356833159923553e-01
    z[4,5,6]  R2359     -1.6347070038318634e-01
    z[4,5,6]  R2360     -4.5246567577123642e-02
    z[4,5,6]  R2361     -4.5476046204566956e-01
    z[4,5,6]  R2362     -1.8977752327919006e-01
    z[4,5,6]  R2363     4.3836481869220734e-02
    z[4,5,6]  R2364     -3.9253199100494385e-01
    z[4,5,6]  R2365     -1.6546231508255005e-01
    z[4,5,6]  R2366     -1.3584578037261963e-01
    z[4,5,6]  R2367     2.3039807379245758e-01
    z[4,5,6]  R2368     -4.0946129709482193e-02
    z[4,5,6]  R2369     1.3760775327682495e-01
    z[4,5,6]  R2370     -6.8311393260955811e-03
    z[4,5,6]  R2371     -4.3948139995336533e-02
    z[4,5,6]  R2372     6.0904525220394135e-02
    z[4,5,6]  R2373     -3.9998155832290649e-01
    z[4,5,6]  R2374     1.2498059123754501e-01
    z[4,5,6]  R2375     4.2947977781295776e-01
    z[4,5,6]  R2376     -1.3333770632743835e-01
    z[4,5,6]  R2377     -4.9427023530006409e-01
    z[4,5,6]  R2378     1.4493362046778202e-02
    z[4,5,6]  R2379     -1.5661749243736267e-01
    z[4,5,6]  R2380     -5.1733326911926270e-01
    z[4,5,6]  R2381     -9.7482755780220032e-02
    z[4,5,6]  R2382     -3.5410153865814209e-01
    z[4,5,6]  R2383     -9.4195976853370667e-02
    z[4,5,6]  R2384     1.8198034167289734e-01
    z[4,5,6]  R2385     3.3990573883056641e-01
    z[4,5,6]  R2386     3.3872240781784058e-01
    z[4,5,6]  R2387     -3.4064075350761414e-01
    z[4,5,6]  R2388     -3.0538308620452881e-01
    z[4,5,6]  R2389     3.7478078156709671e-02
    z[4,5,6]  R2390     3.4675487875938416e-01
    z[4,5,6]  R2391     -1.0166209936141968e-01
    z[4,5,6]  R2392     -2.6171153783798218e-01
    z[4,5,6]  R2393     1.4266893267631531e-01
    z[4,5,6]  R2394     -5.8515619486570358e-02
    z[4,5,6]  R2395     1.2529952824115753e-01
    z[4,5,6]  R2396     -2.9958526138216257e-03
    z[4,5,6]  R2397     -4.2302541434764862e-02
    z[4,5,6]  R2398     3.5392352938652039e-01
    z[4,5,6]  R2399     -5.5908089876174927e-01
    z[4,5,6]  R2400     -5.4546225070953369e-01
    z[4,5,6]  R2401     1.0424774140119553e-01
    z[4,5,6]  R2402     6.5992519259452820e-02
    z[4,5,6]  R2403     1.5303359925746918e-01
    z[4,5,6]  R2404     2.1497702226042747e-02
    z[4,5,6]  R2405     -2.2102083265781403e-01
    z[4,5,6]  R2406     2.1728539466857910e-01
    z[4,5,6]  R2407     4.6085428446531296e-02
    z[4,5,6]  R2408     -2.3642720654606819e-02
    z[4,5,6]  R2409     1.0196760296821594e-01
    z[4,5,6]  R2410     -9.2297062277793884e-02
    z[4,5,6]  R2411     7.1000531315803528e-02
    z[4,5,6]  R2412     1.1236649006605148e-01
    z[4,5,6]  R2413     0.645663321018219
    z[4,5,6]  R2414     -2.7977797389030457e-01
    z[4,5,6]  R2415     3.2469874620437622e-01
    z[4,5,6]  R2416     -3.9274501800537109e-01
    z[4,5,6]  R2417     -8.7665893137454987e-02
    z[4,5,6]  R2418     -3.5648101568222046e-01
    z[4,5,6]  R2419     -4.0034556388854980e-01
    z[4,5,6]  R2420     -7.9675689339637756e-02
    z[4,5,6]  R2421     -2.2472733259201050e-01
    z[4,5,6]  R2422     -3.9812245965003967e-01
    z[4,5,6]  R2423     -1.7418856918811798e-01
    z[4,5,6]  R2424     4.7403600811958313e-01
    z[4,5,6]  R2425     4.1254632174968719e-02
    z[4,5,6]  R2426     6.2351156026124954e-02
    z[4,5,6]  R2427     4.0722902864217758e-02
    z[4,5,6]  R2428     -5.3125196695327759e-01
    z[4,5,6]  R2429     3.5758140683174133e-01
    z[4,5,6]  R2430     -5.9704118967056274e-01
    z[4,5,6]  R2431     -3.0509895086288452e-01
    z[4,5,6]  R2432     -2.7958011627197266e-01
    z[4,5,6]  R2433     -2.9956376552581787e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2434     -1
    z[5,4,0]  R2435     1
    z[5,4,0]  R2448     4.4905692338943481e-02
    z[5,4,0]  R2449     2.7488011121749878e-01
    z[5,4,0]  R2450     4.9197757244110107e-01
    z[5,4,0]  R2451     -1.0621292144060135e-01
    z[5,4,0]  R2452     3.2745444774627686e-01
    z[5,4,0]  R2453     3.9802014827728271e-01
    z[5,4,0]  R2454     3.4995537996292114e-01
    z[5,4,0]  R2455     -1.5063305199146271e-01
    z[5,4,0]  R2456     4.7343918681144714e-01
    z[5,4,0]  R2457     -2.1048258244991302e-01
    z[5,4,0]  R2458     3.3840200304985046e-01
    z[5,4,0]  R2459     4.9328714609146118e-02
    z[5,4,0]  R2460     1.6332606971263885e-01
    z[5,4,0]  R2461     0.0453437939286232
    z[5,4,0]  R2462     1.0652531683444977e-01
    z[5,4,0]  R2463     1.7694209516048431e-01
    z[5,4,0]  R2464     3.9981940388679504e-01
    z[5,4,0]  R2465     -3.0972000211477280e-02
    z[5,4,0]  R2466     1.7476992681622505e-02
    z[5,4,0]  R2467     -1.1291588842868805e-01
    z[5,4,0]  R2468     -1.9607307389378548e-02
    z[5,4,0]  R2469     4.8747184872627258e-01
    z[5,4,0]  R2470     1.8454360961914062e-01
    z[5,4,0]  R2471     8.6628451943397522e-02
    z[5,4,0]  R2472     -4.6332213096320629e-03
    z[5,4,0]  R2473     -0.133395716547966
    z[5,4,0]  R2474     -3.1193557381629944e-01
    z[5,4,0]  R2475     -2.5365066528320312e-01
    z[5,4,0]  R2476     -5.2966989576816559e-02
    z[5,4,0]  R2477     -1.6295957565307617e-01
    z[5,4,0]  R2478     4.2942172288894653e-01
    z[5,4,0]  R2479     -2.3111522197723389e-01
    z[5,4,0]  R2480     5.0620734691619873e-01
    z[5,4,0]  R2481     3.2991644740104675e-01
    z[5,4,0]  R2482     -8.9085623621940613e-02
    z[5,4,0]  R2483     -5.8000821620225906e-02
    z[5,4,0]  R2484     3.1568494439125061e-01
    z[5,4,0]  R2485     1.6023042798042297e-01
    z[5,4,0]  R2486     -2.2212259471416473e-01
    z[5,4,0]  R2487     3.0740559101104736e-01
    z[5,4,0]  R2488     -9.0094543993473053e-02
    z[5,4,0]  R2489     3.9716640114784241e-01
    z[5,4,0]  R2490     -2.3172914981842041e-01
    z[5,4,0]  R2491     1.7375090718269348e-01
    z[5,4,0]  R2492     2.0802558958530426e-01
    z[5,4,0]  R2493     -2.7975955605506897e-01
    z[5,4,0]  R2494     -0.29337078332901
    z[5,4,0]  R2495     -1.1495106155052781e-03
    z[5,4,0]  R2496     -1.6729475557804108e-01
    z[5,4,0]  R2497     -4.1556453704833984e-01
    z[5,4,0]  R2498     -1.5465673059225082e-02
    z[5,4,0]  R2499     1.2804825603961945e-01
    z[5,4,0]  R2500     1.2401670217514038e-01
    z[5,4,0]  R2501     1.9561153650283813e-01
    z[5,4,0]  R2502     3.1262066960334778e-01
    z[5,4,0]  R2503     1.5708579123020172e-01
    z[5,4,0]  R2504     1.5607194602489471e-01
    z[5,4,0]  R2505     4.3293327093124390e-01
    z[5,4,0]  R2506     1.9849990308284760e-01
    z[5,4,0]  R2507     2.9485905170440674e-01
    z[5,4,0]  R2508     -8.4715768694877625e-02
    z[5,4,0]  R2509     3.7786862254142761e-01
    z[5,4,0]  R2510     -1.0474388301372528e-01
    z[5,4,0]  R2511     -4.3095737695693970e-01
    z[5,4,0]  R2512     -5.7242126204073429e-03
    z[5,4,0]  R2513     -1.0527808219194412e-01
    z[5,4,0]  R2514     -1.3672526180744171e-01
    z[5,4,0]  R2515     -2.7547001838684082e-01
    z[5,4,0]  R2516     5.8763694763183594e-01
    z[5,4,0]  R2517     4.1692918539047241e-01
    z[5,4,0]  R2518     3.1882929615676403e-03
    z[5,4,0]  R2519     0.350115031003952
    z[5,4,0]  R2520     1.0460475832223892e-01
    z[5,4,0]  R2521     4.6982610225677490e-01
    z[5,4,0]  R2522     -2.1524028852581978e-02
    z[5,4,0]  R2523     4.8068743199110031e-02
    z[5,4,0]  R2524     -1.2982851266860962e-01
    z[5,4,0]  R2525     -5.4572790861129761e-02
    z[5,4,0]  R2526     9.8200999200344086e-02
    z[5,4,0]  R2527     -7.6632252894341946e-03
    z[5,4,0]  R2528     2.2449608147144318e-01
    z[5,4,0]  R2529     1.2216307967901230e-01
    z[5,4,0]  R2530     2.6040667295455933e-01
    z[5,4,0]  R2531     4.6720737218856812e-01
    z[5,4,0]  R2532     4.2385819554328918e-01
    z[5,4,0]  R2533     4.0700322389602661e-01
    z[5,4,0]  R2534     1.1096493899822235e-01
    z[5,4,0]  R2535     5.0646132230758667e-01
    z[5,4,0]  R2536     0.467808336019516
    z[5,4,0]  R2537     4.6968027949333191e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2436     -1
    z[5,4,1]  R2437     1
    z[5,4,1]  R2448     -6.8122547864913940e-01
    z[5,4,1]  R2449     -6.7748540639877319e-01
    z[5,4,1]  R2450     6.7459249496459961e-01
    z[5,4,1]  R2451     -8.1346917152404785e-01
    z[5,4,1]  R2452     -7.0029234886169434e-01
    z[5,4,1]  R2453     5.2877306938171387e-01
    z[5,4,1]  R2454     5.9612405300140381e-01
    z[5,4,1]  R2455     -1.8770109117031097e-01
    z[5,4,1]  R2456     5.2165532112121582e-01
    z[5,4,1]  R2457     8.9386940002441406e-01
    z[5,4,1]  R2458     8.1641274690628052e-01
    z[5,4,1]  R2459     8.4431940317153931e-01
    z[5,4,1]  R2460     -2.0611999928951263e-01
    z[5,4,1]  R2461     -6.5368312597274780e-01
    z[5,4,1]  R2462     -2.7324327826499939e-01
    z[5,4,1]  R2463     7.9011809825897217e-01
    z[5,4,1]  R2464     6.1137682199478149e-01
    z[5,4,1]  R2465     2.6357316970825195e-01
    z[5,4,1]  R2466     -4.6956473588943481e-01
    z[5,4,1]  R2467     1.1211547255516052e-01
    z[5,4,1]  R2468     -8.9405238628387451e-01
    z[5,4,1]  R2469     0.65756756067276
    z[5,4,1]  R2470     8.2068479061126709e-01
    z[5,4,1]  R2471     -0.741539478302002
    z[5,4,1]  R2472     0.904663622379303
    z[5,4,1]  R2473     -5.9420973062515259e-01
    z[5,4,1]  R2474     -0.470384418964386
    z[5,4,1]  R2475     -3.7736091017723083e-01
    z[5,4,1]  R2476     -8.1561100482940674e-01
    z[5,4,1]  R2477     -5.2647686004638672e-01
    z[5,4,1]  R2478     6.3006180524826050e-01
    z[5,4,1]  R2479     -4.2134487628936768e-01
    z[5,4,1]  R2480     0.691325306892395
    z[5,4,1]  R2481     -0.750025749206543
    z[5,4,1]  R2482     -6.0750845819711685e-02
    z[5,4,1]  R2483     1.1036308109760284e-01
    z[5,4,1]  R2484     0.545853316783905
    z[5,4,1]  R2485     7.5227451324462891e-01
    z[5,4,1]  R2486     -5.3734356164932251e-01
    z[5,4,1]  R2487     4.6872133016586304e-01
    z[5,4,1]  R2488     -7.4568390846252441e-01
    z[5,4,1]  R2489     -8.3605545759201050e-01
    z[5,4,1]  R2490     -6.1399626731872559e-01
    z[5,4,1]  R2491     6.9033062458038330e-01
    z[5,4,1]  R2492     6.4332503080368042e-01
    z[5,4,1]  R2493     5.5489885807037354e-01
    z[5,4,1]  R2494     6.9776940345764160e-01
    z[5,4,1]  R2495     4.6602910757064819e-01
    z[5,4,1]  R2496     5.1794224977493286e-01
    z[5,4,1]  R2497     7.5704419612884521e-01
    z[5,4,1]  R2498     -7.6356285810470581e-01
    z[5,4,1]  R2499     -2.0082026720046997e-01
    z[5,4,1]  R2500     -5.0230443477630615e-01
    z[5,4,1]  R2501     7.5273811817169189e-01
    z[5,4,1]  R2502     6.8352770805358887e-01
    z[5,4,1]  R2503     -6.8227595090866089e-01
    z[5,4,1]  R2504     5.6851136684417725e-01
    z[5,4,1]  R2505     5.7080060243606567e-01
    z[5,4,1]  R2506     5.5767953395843506e-01
    z[5,4,1]  R2507     -0.652384340763092
    z[5,4,1]  R2508     -7.2566747665405273e-01
    z[5,4,1]  R2509     -0.601925790309906
    z[5,4,1]  R2510     -4.3660253286361694e-01
    z[5,4,1]  R2511     -0.560893714427948
    z[5,4,1]  R2512     -7.1033054590225220e-01
    z[5,4,1]  R2513     -5.6445884704589844e-01
    z[5,4,1]  R2514     -5.5630582571029663e-01
    z[5,4,1]  R2515     -7.3707896471023560e-01
    z[5,4,1]  R2516     6.5864127874374390e-01
    z[5,4,1]  R2517     -6.6119700670242310e-02
    z[5,4,1]  R2518     8.3957237005233765e-01
    z[5,4,1]  R2519     7.5983101129531860e-01
    z[5,4,1]  R2520     8.9190721511840820e-01
    z[5,4,1]  R2521     0.68828946352005
    z[5,4,1]  R2522     8.4670531749725342e-01
    z[5,4,1]  R2523     8.4243708848953247e-01
    z[5,4,1]  R2524     7.9136216640472412e-01
    z[5,4,1]  R2525     7.4902480840682983e-01
    z[5,4,1]  R2526     8.6116957664489746e-01
    z[5,4,1]  R2527     8.7653368711471558e-01
    z[5,4,1]  R2528     8.3442175388336182e-01
    z[5,4,1]  R2529     8.3425015211105347e-01
    z[5,4,1]  R2530     8.9899486303329468e-01
    z[5,4,1]  R2531     5.9249097108840942e-01
    z[5,4,1]  R2532     5.9265911579132080e-01
    z[5,4,1]  R2533     -6.9072662154212594e-04
    z[5,4,1]  R2534     3.1029152870178223e-01
    z[5,4,1]  R2535     1.9548442959785461e-01
    z[5,4,1]  R2536     5.6558477878570557e-01
    z[5,4,1]  R2537     6.0634356737136841e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2438     -1
    z[5,4,2]  R2439     1
    z[5,4,2]  R2448     -2.5429481267929077e-01
    z[5,4,2]  R2449     -4.7350153326988220e-01
    z[5,4,2]  R2450     -1.6671952605247498e-01
    z[5,4,2]  R2451     -6.9923691451549530e-02
    z[5,4,2]  R2452     5.1851324737071991e-02
    z[5,4,2]  R2453     -6.2837436795234680e-02
    z[5,4,2]  R2454     -1.7073693871498108e-01
    z[5,4,2]  R2455     -4.8172447085380554e-01
    z[5,4,2]  R2456     -5.1995605230331421e-01
    z[5,4,2]  R2457     -5.7836681604385376e-02
    z[5,4,2]  R2458     2.4669414758682251e-01
    z[5,4,2]  R2459     -1.1313141882419586e-01
    z[5,4,2]  R2460     -1.0266650468111038e-01
    z[5,4,2]  R2461     2.6764890551567078e-01
    z[5,4,2]  R2462     1.7920050024986267e-01
    z[5,4,2]  R2463     3.4833726286888123e-01
    z[5,4,2]  R2464     3.7064486742019653e-01
    z[5,4,2]  R2465     -0.321865051984787
    z[5,4,2]  R2466     -2.4265077710151672e-01
    z[5,4,2]  R2467     3.4573718905448914e-01
    z[5,4,2]  R2468     -1.5769918262958527e-01
    z[5,4,2]  R2469     -4.5038771629333496e-01
    z[5,4,2]  R2470     -3.4964182972908020e-01
    z[5,4,2]  R2471     -4.9290037155151367e-01
    z[5,4,2]  R2472     -7.1905307471752167e-02
    z[5,4,2]  R2473     -1.6450406610965729e-01
    z[5,4,2]  R2474     9.9394604563713074e-02
    z[5,4,2]  R2475     1.7148096859455109e-01
    z[5,4,2]  R2476     1.2626454234123230e-01
    z[5,4,2]  R2477     -3.3183717727661133e-01
    z[5,4,2]  R2478     3.0751636624336243e-01
    z[5,4,2]  R2479     2.0369198918342590e-01
    z[5,4,2]  R2480     0.282680869102478
    z[5,4,2]  R2481     3.1261113286018372e-01
    z[5,4,2]  R2482     -5.2417612075805664e-01
    z[5,4,2]  R2483     1.0222312062978745e-01
    z[5,4,2]  R2484     3.1969651579856873e-01
    z[5,4,2]  R2485     -2.1627022325992584e-01
    z[5,4,2]  R2486     -3.8786804676055908e-01
    z[5,4,2]  R2487     4.1406969539821148e-03
    z[5,4,2]  R2488     3.2021556049585342e-02
    z[5,4,2]  R2489     1.3430744409561157e-01
    z[5,4,2]  R2490     -2.9622071981430054e-01
    z[5,4,2]  R2491     -6.7097288370132446e-01
    z[5,4,2]  R2492     2.2424674034118652e-01
    z[5,4,2]  R2493     -3.8256937265396118e-01
    z[5,4,2]  R2494     -4.1397172212600708e-01
    z[5,4,2]  R2495     -0.676310658454895
    z[5,4,2]  R2496     -6.0162127017974854e-01
    z[5,4,2]  R2497     2.3310698568820953e-01
    z[5,4,2]  R2498     -2.2924098372459412e-01
    z[5,4,2]  R2499     -4.4149917364120483e-01
    z[5,4,2]  R2500     2.4197886884212494e-01
    z[5,4,2]  R2501     -5.4202873259782791e-02
    z[5,4,2]  R2502     -4.5376177877187729e-02
    z[5,4,2]  R2503     3.4249746799468994e-01
    z[5,4,2]  R2504     3.1649532914161682e-01
    z[5,4,2]  R2505     -3.9023196697235107e-01
    z[5,4,2]  R2506     -2.1241942048072815e-01
    z[5,4,2]  R2507     1.6354057192802429e-01
    z[5,4,2]  R2508     -3.8860204815864563e-01
    z[5,4,2]  R2509     -3.0724689364433289e-01
    z[5,4,2]  R2510     -1.4385642111301422e-01
    z[5,4,2]  R2511     4.1887059807777405e-02
    z[5,4,2]  R2512     -9.1320149600505829e-02
    z[5,4,2]  R2513     -4.9124547839164734e-01
    z[5,4,2]  R2514     1.5303640067577362e-01
    z[5,4,2]  R2515     -1.8345442414283752e-01
    z[5,4,2]  R2516     -2.6607409119606018e-01
    z[5,4,2]  R2517     -1.6967274248600006e-01
    z[5,4,2]  R2518     2.1964015066623688e-01
    z[5,4,2]  R2519     -5.4684713482856750e-02
    z[5,4,2]  R2520     -3.1715580821037292e-01
    z[5,4,2]  R2521     1.5045984089374542e-01
    z[5,4,2]  R2522     -3.3043643832206726e-01
    z[5,4,2]  R2523     5.8519367128610611e-02
    z[5,4,2]  R2524     1.5012061595916748e-01
    z[5,4,2]  R2525     9.6426717936992645e-02
    z[5,4,2]  R2526     -3.5265842080116272e-01
    z[5,4,2]  R2527     2.7463451027870178e-01
    z[5,4,2]  R2528     2.7208182215690613e-01
    z[5,4,2]  R2529     4.5037293434143066e-01
    z[5,4,2]  R2530     -1.3624326884746552e-01
    z[5,4,2]  R2531     4.6888992190361023e-01
    z[5,4,2]  R2532     6.5142136812210083e-01
    z[5,4,2]  R2533     -6.4343822002410889e-01
    z[5,4,2]  R2534     -6.2557244300842285e-01
    z[5,4,2]  R2535     -6.9579696655273438e-01
    z[5,4,2]  R2536     0.331856369972229
    z[5,4,2]  R2537     -2.7549099922180176e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2440     -1
    z[5,4,3]  R2441     1
    z[5,4,3]  R2448     5.3208708763122559e-01
    z[5,4,3]  R2449     -6.7700318992137909e-02
    z[5,4,3]  R2450     -1.8652331829071045e-01
    z[5,4,3]  R2451     -2.6899260282516479e-01
    z[5,4,3]  R2452     -1.1053077131509781e-01
    z[5,4,3]  R2453     -6.1051309108734131e-01
    z[5,4,3]  R2454     -4.5318952202796936e-01
    z[5,4,3]  R2455     8.3257085084915161e-01
    z[5,4,3]  R2456     -2.9941469430923462e-01
    z[5,4,3]  R2457     -3.3782172203063965e-01
    z[5,4,3]  R2458     1.8651817739009857e-01
    z[5,4,3]  R2459     -1.5265716612339020e-01
    z[5,4,3]  R2460     8.7237930297851562e-01
    z[5,4,3]  R2461     2.3032648861408234e-01
    z[5,4,3]  R2462     7.4780148267745972e-01
    z[5,4,3]  R2463     -1.2419898062944412e-01
    z[5,4,3]  R2464     -1.8971423804759979e-01
    z[5,4,3]  R2465     8.0624425411224365e-01
    z[5,4,3]  R2466     7.4304181337356567e-01
    z[5,4,3]  R2467     7.6708149909973145e-01
    z[5,4,3]  R2468     -3.8678354024887085e-01
    z[5,4,3]  R2469     -1.7900021374225616e-01
    z[5,4,3]  R2470     3.1066963076591492e-01
    z[5,4,3]  R2471     4.3569728732109070e-01
    z[5,4,3]  R2472     -2.8471006080508232e-02
    z[5,4,3]  R2473     4.4629785418510437e-01
    z[5,4,3]  R2474     5.9161442518234253e-01
    z[5,4,3]  R2475     4.7145324945449829e-01
    z[5,4,3]  R2476     3.5779750347137451e-01
    z[5,4,3]  R2477     3.3317390084266663e-01
    z[5,4,3]  R2478     -5.2699881792068481e-01
    z[5,4,3]  R2479     5.4240685701370239e-01
    z[5,4,3]  R2480     -2.0581322908401489e-01
    z[5,4,3]  R2481     1.1047840118408203e-02
    z[5,4,3]  R2482     7.0259046554565430e-01
    z[5,4,3]  R2483     9.2891907691955566e-01
    z[5,4,3]  R2484     -3.5196724534034729e-01
    z[5,4,3]  R2485     3.0686733126640320e-01
    z[5,4,3]  R2486     3.9088377356529236e-01
    z[5,4,3]  R2487     -3.0861553549766541e-01
    z[5,4,3]  R2488     -2.1929587423801422e-01
    z[5,4,3]  R2489     1.1554061621427536e-01
    z[5,4,3]  R2490     -1.4648194611072540e-01
    z[5,4,3]  R2491     5.5972304195165634e-02
    z[5,4,3]  R2492     4.1575622558593750e-01
    z[5,4,3]  R2493     -1.5586887300014496e-01
    z[5,4,3]  R2494     -3.8521891832351685e-01
    z[5,4,3]  R2495     -6.8435288965702057e-02
    z[5,4,3]  R2496     5.9285301715135574e-02
    z[5,4,3]  R2497     5.6945491582155228e-02
    z[5,4,3]  R2498     3.5616809129714966e-01
    z[5,4,3]  R2499     7.6187252998352051e-01
    z[5,4,3]  R2500     7.9293966293334961e-01
    z[5,4,3]  R2501     4.6142944693565369e-01
    z[5,4,3]  R2502     2.7731695771217346e-01
    z[5,4,3]  R2503     3.4239280223846436e-01
    z[5,4,3]  R2504     -2.7753153443336487e-01
    z[5,4,3]  R2505     4.9526520073413849e-02
    z[5,4,3]  R2506     -2.2915895283222198e-01
    z[5,4,3]  R2507     8.4319151937961578e-02
    z[5,4,3]  R2508     4.4498276710510254e-01
    z[5,4,3]  R2509     4.5564872026443481e-01
    z[5,4,3]  R2510     8.5733026266098022e-01
    z[5,4,3]  R2511     3.7388020753860474e-01
    z[5,4,3]  R2512     -7.4222773313522339e-02
    z[5,4,3]  R2513     -1.0788592696189880e-01
    z[5,4,3]  R2514     4.6664497256278992e-01
    z[5,4,3]  R2515     -5.1120144128799438e-01
    z[5,4,3]  R2516     -7.2239659726619720e-02
    z[5,4,3]  R2517     -7.7155923843383789e-01
    z[5,4,3]  R2518     -0.384640634059906
    z[5,4,3]  R2519     -4.2843019962310791e-01
    z[5,4,3]  R2520     1.0900925099849701e-01
    z[5,4,3]  R2521     -1.8710485100746155e-01
    z[5,4,3]  R2522     1.6624949872493744e-01
    z[5,4,3]  R2523     2.1511860191822052e-01
    z[5,4,3]  R2524     -4.8466023802757263e-01
    z[5,4,3]  R2525     -3.9303550124168396e-01
    z[5,4,3]  R2526     -1.1065232008695602e-01
    z[5,4,3]  R2527     1.2822882831096649e-01
    z[5,4,3]  R2528     -9.2328958213329315e-02
    z[5,4,3]  R2529     6.3312657177448273e-02
    z[5,4,3]  R2530     -2.7496090531349182e-01
    z[5,4,3]  R2531     -8.1231839954853058e-02
    z[5,4,3]  R2532     -1.8128865957260132e-01
    z[5,4,3]  R2533     -0.535149097442627
    z[5,4,3]  R2534     -6.9514250755310059e-01
    z[5,4,3]  R2535     -3.4890174865722656e-01
    z[5,4,3]  R2536     2.6794403791427612e-01
    z[5,4,3]  R2537     4.0192779898643494e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2442     -1
    z[5,4,4]  R2443     1
    z[5,4,4]  R2448     -0.407550185918808
    z[5,4,4]  R2449     1.0992280393838882e-01
    z[5,4,4]  R2450     -6.1532676219940186e-02
    z[5,4,4]  R2451     -5.0204541534185410e-02
    z[5,4,4]  R2452     -4.9264460802078247e-01
    z[5,4,4]  R2453     -2.8671622276306152e-01
    z[5,4,4]  R2454     2.6149597018957138e-02
    z[5,4,4]  R2455     7.3123171925544739e-02
    z[5,4,4]  R2456     4.4613435864448547e-02
    z[5,4,4]  R2457     -0.0691533163189888
    z[5,4,4]  R2458     0.07137431204319
    z[5,4,4]  R2459     2.4950174987316132e-01
    z[5,4,4]  R2460     1.0654534399509430e-01
    z[5,4,4]  R2461     -4.5509532094001770e-01
    z[5,4,4]  R2462     -3.6515191197395325e-01
    z[5,4,4]  R2463     -0.416479229927063
    z[5,4,4]  R2464     -4.0927022695541382e-01
    z[5,4,4]  R2465     -1.9846189022064209e-01
    z[5,4,4]  R2466     -1.9453060626983643e-01
    z[5,4,4]  R2467     3.6199086904525757e-01
    z[5,4,4]  R2468     6.9938585162162781e-02
    z[5,4,4]  R2469     -1.3595966994762421e-01
    z[5,4,4]  R2470     -1.5079443156719208e-01
    z[5,4,4]  R2471     -4.1097655892372131e-02
    z[5,4,4]  R2472     2.1752344444394112e-02
    z[5,4,4]  R2473     -1.8148691952228546e-01
    z[5,4,4]  R2474     1.0181655734777451e-01
    z[5,4,4]  R2475     6.8882554769515991e-01
    z[5,4,4]  R2476     4.0979516506195068e-01
    z[5,4,4]  R2477     0.576056957244873
    z[5,4,4]  R2478     2.0964258909225464e-01
    z[5,4,4]  R2479     3.7249827384948730e-01
    z[5,4,4]  R2480     -1.2518243491649628e-01
    z[5,4,4]  R2481     -2.4802911281585693e-01
    z[5,4,4]  R2482     7.4077457189559937e-02
    z[5,4,4]  R2483     1.6445495188236237e-01
    z[5,4,4]  R2484     -1.8125905096530914e-01
    z[5,4,4]  R2485     4.0912351012229919e-01
    z[5,4,4]  R2486     5.2063208818435669e-01
    z[5,4,4]  R2487     3.7820154428482056e-01
    z[5,4,4]  R2488     4.0455322712659836e-02
    z[5,4,4]  R2489     -1.0657750535756350e-03
    z[5,4,4]  R2490     -4.4077765941619873e-01
    z[5,4,4]  R2491     1.6311611235141754e-01
    z[5,4,4]  R2492     -3.8399747014045715e-01
    z[5,4,4]  R2493     -2.7723035216331482e-01
    z[5,4,4]  R2494     1.5596590936183929e-01
    z[5,4,4]  R2495     -5.1666635274887085e-01
    z[5,4,4]  R2496     -4.1069126129150391e-01
    z[5,4,4]  R2497     3.2260903716087341e-01
    z[5,4,4]  R2498     4.1462130844593048e-02
    z[5,4,4]  R2499     -1.7017647624015808e-01
    z[5,4,4]  R2500     5.4746586829423904e-02
    z[5,4,4]  R2501     -3.8583523035049438e-01
    z[5,4,4]  R2502     -2.4354654550552368e-01
    z[5,4,4]  R2503     3.6474749445915222e-01
    z[5,4,4]  R2504     -2.8474736213684082e-01
    z[5,4,4]  R2505     4.2725983262062073e-01
    z[5,4,4]  R2506     5.4021787643432617e-01
    z[5,4,4]  R2507     -4.9213051795959473e-01
    z[5,4,4]  R2508     -1.1761056631803513e-01
    z[5,4,4]  R2509     -4.3422105908393860e-01
    z[5,4,4]  R2510     3.9987348020076752e-02
    z[5,4,4]  R2511     2.0577311515808105e-01
    z[5,4,4]  R2512     -2.2969231009483337e-01
    z[5,4,4]  R2513     -2.3001711070537567e-01
    z[5,4,4]  R2514     -0.0957801342010498
    z[5,4,4]  R2515     -1.7863722145557404e-01
    z[5,4,4]  R2516     -1.7013189196586609e-01
    z[5,4,4]  R2517     -3.6363226175308228e-01
    z[5,4,4]  R2518     1.7837880551815033e-01
    z[5,4,4]  R2519     -3.1958669424057007e-03
    z[5,4,4]  R2520     2.6500046253204346e-01
    z[5,4,4]  R2521     -1.3820233941078186e-01
    z[5,4,4]  R2522     3.3487355709075928e-01
    z[5,4,4]  R2523     3.1450507044792175e-01
    z[5,4,4]  R2524     3.0866429209709167e-01
    z[5,4,4]  R2525     2.1685311198234558e-01
    z[5,4,4]  R2526     1.8871790170669556e-01
    z[5,4,4]  R2527     3.6806982755661011e-01
    z[5,4,4]  R2528     1.0369108617305756e-01
    z[5,4,4]  R2529     2.3422354459762573e-01
    z[5,4,4]  R2530     8.7004482746124268e-02
    z[5,4,4]  R2531     -1.0074214637279510e-01
    z[5,4,4]  R2532     -9.0319961309432983e-02
    z[5,4,4]  R2533     2.9192152619361877e-01
    z[5,4,4]  R2534     1.2943156063556671e-01
    z[5,4,4]  R2535     1.4085660874843597e-01
    z[5,4,4]  R2536     -3.4676857292652130e-02
    z[5,4,4]  R2537     -8.8697835803031921e-02
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2444     -1
    z[5,4,5]  R2445     1
    z[5,4,5]  R2448     -6.6448740661144257e-02
    z[5,4,5]  R2449     -2.0032858848571777e-01
    z[5,4,5]  R2450     -4.6768745779991150e-01
    z[5,4,5]  R2451     5.4006807506084442e-02
    z[5,4,5]  R2452     -3.8019725680351257e-01
    z[5,4,5]  R2453     -2.8030180931091309e-01
    z[5,4,5]  R2454     -0.13898965716362
    z[5,4,5]  R2455     4.4669758528470993e-02
    z[5,4,5]  R2456     1.2786471843719482e-01
    z[5,4,5]  R2457     -1.5990903973579407e-01
    z[5,4,5]  R2458     2.9171234369277954e-01
    z[5,4,5]  R2459     2.6608529686927795e-01
    z[5,4,5]  R2460     1.8212196230888367e-01
    z[5,4,5]  R2461     -3.5044002532958984e-01
    z[5,4,5]  R2462     3.0996114015579224e-01
    z[5,4,5]  R2463     1.8105560541152954e-01
    z[5,4,5]  R2464     7.2475492954254150e-02
    z[5,4,5]  R2465     3.5527545213699341e-01
    z[5,4,5]  R2466     2.4875281751155853e-01
    z[5,4,5]  R2467     3.3961758017539978e-01
    z[5,4,5]  R2468     1.3228674232959747e-01
    z[5,4,5]  R2469     2.4678136408329010e-01
    z[5,4,5]  R2470     2.2562603652477264e-01
    z[5,4,5]  R2471     7.9707249999046326e-02
    z[5,4,5]  R2472     -2.2326244413852692e-01
    z[5,4,5]  R2473     2.3951642215251923e-01
    z[5,4,5]  R2474     1.1684230715036392e-01
    z[5,4,5]  R2475     2.3714546859264374e-01
    z[5,4,5]  R2476     -1.2539631128311157e-01
    z[5,4,5]  R2477     3.4624379873275757e-01
    z[5,4,5]  R2478     -4.3736483901739120e-02
    z[5,4,5]  R2479     0.495735228061676
    z[5,4,5]  R2480     -2.8402847051620483e-01
    z[5,4,5]  R2481     -4.0881112217903137e-01
    z[5,4,5]  R2482     4.6252843737602234e-01
    z[5,4,5]  R2483     2.7142751216888428e-01
    z[5,4,5]  R2484     5.7872855663299561e-01
    z[5,4,5]  R2485     -3.0829516053199768e-01
    z[5,4,5]  R2486     -2.7387544512748718e-01
    z[5,4,5]  R2487     -1.7499661445617676e-01
    z[5,4,5]  R2488     -5.5390429496765137e-01
    z[5,4,5]  R2489     8.0321721732616425e-02
    z[5,4,5]  R2490     -3.3402532339096069e-01
    z[5,4,5]  R2491     -7.4996486306190491e-02
    z[5,4,5]  R2492     -2.1256893873214722e-01
    z[5,4,5]  R2493     -4.5390984416007996e-01
    z[5,4,5]  R2494     2.7678820490837097e-01
    z[5,4,5]  R2495     -5.7354439049959183e-02
    z[5,4,5]  R2496     1.0543572902679443e-01
    z[5,4,5]  R2497     2.4937982857227325e-01
    z[5,4,5]  R2498     1.0438472777605057e-01
    z[5,4,5]  R2499     3.7046140432357788e-01
    z[5,4,5]  R2500     1.9523890316486359e-01
    z[5,4,5]  R2501     -1.6952624917030334e-01
    z[5,4,5]  R2502     -1.2062735855579376e-01
    z[5,4,5]  R2503     -1.1992149800062180e-01
    z[5,4,5]  R2504     1.9417542219161987e-01
    z[5,4,5]  R2505     2.3745548725128174e-01
    z[5,4,5]  R2506     4.2656177282333374e-01
    z[5,4,5]  R2507     3.4880742430686951e-01
    z[5,4,5]  R2508     5.6471548974514008e-02
    z[5,4,5]  R2509     -0.00575606245547533
    z[5,4,5]  R2510     1.4192521572113037e-01
    z[5,4,5]  R2511     -1.6009394824504852e-01
    z[5,4,5]  R2512     -2.8100606799125671e-01
    z[5,4,5]  R2513     9.9084721878170967e-03
    z[5,4,5]  R2514     -3.1752511858940125e-01
    z[5,4,5]  R2515     -2.3209697008132935e-01
    z[5,4,5]  R2516     -1.2765762209892273e-01
    z[5,4,5]  R2517     1.9370566308498383e-01
    z[5,4,5]  R2518     -1.9008180499076843e-01
    z[5,4,5]  R2519     1.2980645895004272e-01
    z[5,4,5]  R2520     -7.0155955851078033e-02
    z[5,4,5]  R2521     1.7229683697223663e-01
    z[5,4,5]  R2522     1.2577322125434875e-01
    z[5,4,5]  R2523     3.3563748002052307e-01
    z[5,4,5]  R2524     4.6237561851739883e-02
    z[5,4,5]  R2525     1.3555921614170074e-01
    z[5,4,5]  R2526     -2.0125040411949158e-01
    z[5,4,5]  R2527     4.8644743859767914e-02
    z[5,4,5]  R2528     -7.7171243727207184e-02
    z[5,4,5]  R2529     -4.4923387467861176e-03
    z[5,4,5]  R2530     6.1700176447629929e-02
    z[5,4,5]  R2531     -3.7547716498374939e-01
    z[5,4,5]  R2532     -0.0452738031744957
    z[5,4,5]  R2533     1.7261669039726257e-01
    z[5,4,5]  R2534     6.5440088510513306e-03
    z[5,4,5]  R2535     2.7864855527877808e-01
    z[5,4,5]  R2536     0.523865282535553
    z[5,4,5]  R2537     8.0336958169937134e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2446     -1
    z[5,4,6]  R2447     1
    z[5,4,6]  R2448     1.2498059123754501e-01
    z[5,4,6]  R2449     4.2947977781295776e-01
    z[5,4,6]  R2450     -1.3333770632743835e-01
    z[5,4,6]  R2451     -4.9427023530006409e-01
    z[5,4,6]  R2452     1.4493362046778202e-02
    z[5,4,6]  R2453     -1.5661749243736267e-01
    z[5,4,6]  R2454     -5.1733326911926270e-01
    z[5,4,6]  R2455     -9.7482755780220032e-02
    z[5,4,6]  R2456     -3.5410153865814209e-01
    z[5,4,6]  R2457     -9.4195976853370667e-02
    z[5,4,6]  R2458     1.8198034167289734e-01
    z[5,4,6]  R2459     3.3990573883056641e-01
    z[5,4,6]  R2460     3.3872240781784058e-01
    z[5,4,6]  R2461     -3.4064075350761414e-01
    z[5,4,6]  R2462     -3.0538308620452881e-01
    z[5,4,6]  R2463     3.7478078156709671e-02
    z[5,4,6]  R2464     3.4675487875938416e-01
    z[5,4,6]  R2465     -1.0166209936141968e-01
    z[5,4,6]  R2466     -2.6171153783798218e-01
    z[5,4,6]  R2467     1.4266893267631531e-01
    z[5,4,6]  R2468     -5.8515619486570358e-02
    z[5,4,6]  R2469     1.2529952824115753e-01
    z[5,4,6]  R2470     -2.9958526138216257e-03
    z[5,4,6]  R2471     -4.2302541434764862e-02
    z[5,4,6]  R2472     3.5392352938652039e-01
    z[5,4,6]  R2473     -5.5908089876174927e-01
    z[5,4,6]  R2474     -5.4546225070953369e-01
    z[5,4,6]  R2475     1.0424774140119553e-01
    z[5,4,6]  R2476     6.5992519259452820e-02
    z[5,4,6]  R2477     1.5303359925746918e-01
    z[5,4,6]  R2478     2.1497702226042747e-02
    z[5,4,6]  R2479     -2.2102083265781403e-01
    z[5,4,6]  R2480     2.1728539466857910e-01
    z[5,4,6]  R2481     4.6085428446531296e-02
    z[5,4,6]  R2482     -2.3642720654606819e-02
    z[5,4,6]  R2483     1.0196760296821594e-01
    z[5,4,6]  R2484     -9.2297062277793884e-02
    z[5,4,6]  R2485     7.1000531315803528e-02
    z[5,4,6]  R2486     1.1236649006605148e-01
    z[5,4,6]  R2487     0.645663321018219
    z[5,4,6]  R2488     -2.7977797389030457e-01
    z[5,4,6]  R2489     3.2469874620437622e-01
    z[5,4,6]  R2490     -3.9274501800537109e-01
    z[5,4,6]  R2491     -8.7665893137454987e-02
    z[5,4,6]  R2492     -3.5648101568222046e-01
    z[5,4,6]  R2493     -4.0034556388854980e-01
    z[5,4,6]  R2494     -7.9675689339637756e-02
    z[5,4,6]  R2495     -2.2472733259201050e-01
    z[5,4,6]  R2496     -3.9812245965003967e-01
    z[5,4,6]  R2497     -1.7418856918811798e-01
    z[5,4,6]  R2498     4.7403600811958313e-01
    z[5,4,6]  R2499     4.1254632174968719e-02
    z[5,4,6]  R2500     6.2351156026124954e-02
    z[5,4,6]  R2501     4.0722902864217758e-02
    z[5,4,6]  R2502     -5.3125196695327759e-01
    z[5,4,6]  R2503     3.5758140683174133e-01
    z[5,4,6]  R2504     -5.9704118967056274e-01
    z[5,4,6]  R2505     -3.0509895086288452e-01
    z[5,4,6]  R2506     -2.7958011627197266e-01
    z[5,4,6]  R2507     -2.9956376552581787e-01
    z[5,4,6]  R2508     3.1652396917343140e-01
    z[5,4,6]  R2509     -6.5598316490650177e-02
    z[5,4,6]  R2510     -1.4475968480110168e-01
    z[5,4,6]  R2511     5.3866535425186157e-01
    z[5,4,6]  R2512     5.9146124124526978e-01
    z[5,4,6]  R2513     -0.60360187292099
    z[5,4,6]  R2514     -5.6626528501510620e-01
    z[5,4,6]  R2515     0.00824635848402977
    z[5,4,6]  R2516     3.1562498211860657e-01
    z[5,4,6]  R2517     1.6719865798950195e-01
    z[5,4,6]  R2518     1.7597745358943939e-01
    z[5,4,6]  R2519     3.1092354655265808e-01
    z[5,4,6]  R2520     7.7080823481082916e-02
    z[5,4,6]  R2521     -4.4619336724281311e-01
    z[5,4,6]  R2522     -1.3356833159923553e-01
    z[5,4,6]  R2523     -1.6347070038318634e-01
    z[5,4,6]  R2524     -4.5246567577123642e-02
    z[5,4,6]  R2525     -4.5476046204566956e-01
    z[5,4,6]  R2526     -1.8977752327919006e-01
    z[5,4,6]  R2527     4.3836481869220734e-02
    z[5,4,6]  R2528     -3.9253199100494385e-01
    z[5,4,6]  R2529     -1.6546231508255005e-01
    z[5,4,6]  R2530     -1.3584578037261963e-01
    z[5,4,6]  R2531     2.3039807379245758e-01
    z[5,4,6]  R2532     -4.0946129709482193e-02
    z[5,4,6]  R2533     1.3760775327682495e-01
    z[5,4,6]  R2534     -6.8311393260955811e-03
    z[5,4,6]  R2535     -4.3948139995336533e-02
    z[5,4,6]  R2536     6.0904525220394135e-02
    z[5,4,6]  R2537     -3.9998155832290649e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R54       1
    RHS1      R55       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[6,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,7]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[6,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,7]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
ENDATA
