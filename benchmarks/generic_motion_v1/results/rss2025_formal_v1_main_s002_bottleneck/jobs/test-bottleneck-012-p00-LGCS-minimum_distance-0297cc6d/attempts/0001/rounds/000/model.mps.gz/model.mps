NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       1.0159441232681274e+00
    phi[0,1]  R80       -1.7644056081771851e+00
    phi[0,1]  R81       1.3585032224655151e+00
    phi[0,1]  R82       6.7489433288574219e-01
    phi[0,1]  R83       -1.4402663707733154e+00
    phi[0,1]  R84       9.7799998521804810e-01
    phi[0,1]  R85       -8.5215216875076294e-01
    phi[0,1]  R86       -4.0429866313934326e-01
    phi[0,1]  R87       1.5475416183471680e+00
    phi[0,1]  R88       4.5995357632637024e-01
    phi[0,1]  R89       -1.5600122213363647e+00
    phi[0,1]  R90       -1.1357716321945190e+00
    phi[0,1]  R91       2.3367057740688324e-01
    phi[0,1]  R92       7.6276743412017822e-01
    phi[0,1]  R93       -4.5526188611984253e-01
    phi[0,1]  R94       -1.3133538961410522e+00
    phi[0,1]  R95       -5.0542634725570679e-01
    phi[0,1]  R96       -4.5216137170791626e-01
    phi[0,1]  R97       3.1844526529312134e-01
    phi[0,1]  R98       -1.8851895332336426e+00
    phi[0,1]  R99       -1.9064227342605591e+00
    phi[0,1]  R100      7.0418214797973633e-01
    phi[0,1]  R101      1.3871654272079468e+00
    phi[0,1]  R102      -0.654192328453064
    phi[0,1]  R103      -1.1916174888610840e+00
    phi[0,1]  R104      -3.1361129283905029e+00
    phi[0,1]  R105      -1.0057340860366821e+00
    phi[0,1]  R106      -1.6034573316574097e+00
    phi[0,1]  R107      9.6862721443176270e-01
    phi[0,1]  R108      3.9759826660156250e-01
    phi[0,1]  R109      -2.4812116622924805e+00
    phi[0,1]  R110      -9.2186444997787476e-01
    phi[0,1]  R111      7.0037804543972015e-02
    phi[0,1]  R112      -2.7156016826629639e+00
    phi[0,1]  R113      -7.2365587949752808e-01
    phi[0,1]  R114      -1.8438590764999390e+00
    phi[0,1]  R115      -1.5154618024826050e+00
    phi[0,1]  R116      -2.8446391224861145e-01
    phi[0,1]  R117      -2.4487946033477783e+00
    phi[0,1]  R118      2.3740790784358978e-01
    phi[0,1]  R119      -2.1623109281063080e-01
    phi[0,1]  R120      -2.0164904594421387e+00
    phi[0,1]  R121      -2.5707316398620605e+00
    phi[0,1]  R122      -2.7655419707298279e-01
    phi[0,1]  R123      -2.4459133148193359e+00
    phi[0,1]  R124      -2.3751244544982910e+00
    phi[0,1]  R125      -1.3578327894210815e+00
    phi[0,1]  R126      -3.3353748321533203e+00
    phi[0,1]  R127      -5.6035429239273071e-01
    phi[0,1]  R128      -6.7638039588928223e-01
    phi[0,1]  R129      -1.0752881318330765e-01
    phi[0,1]  R130      -1.9092181921005249e+00
    phi[0,1]  R131      -7.0795518159866333e-01
    phi[0,1]  R132      -1.1471420526504517e+00
    phi[0,1]  R133      8.1515640020370483e-01
    phi[0,1]  R134      6.6731333732604980e-01
    phi[0,1]  R135      8.3316695690155029e-01
    phi[0,1]  R136      -1.3243304491043091e+00
    phi[0,1]  R137      -5.9693181514739990e-01
    phi[0,1]  R138      -2.1045117378234863e+00
    phi[0,1]  R139      5.3236120939254761e-01
    phi[0,1]  R140      -0.520591676235199
    phi[0,1]  R141      -1.5252255201339722e+00
    phi[0,1]  R142      -7.9158818721771240e-01
    phi[0,1]  R143      1.1236859560012817e+00
    phi[0,1]  R144      -8.6140173673629761e-01
    phi[0,1]  R145      3.4324795007705688e-01
    phi[0,1]  R146      -1.4987088441848755e+00
    phi[0,1]  R147      -8.8396197557449341e-01
    phi[0,1]  R148      6.9692707061767578e-01
    phi[0,1]  R149      -6.6418743133544922e-01
    phi[0,1]  R150      -1.7003329992294312e+00
    phi[0,1]  R151      -0.839230477809906
    phi[0,1]  R152      -1.8556820154190063e+00
    phi[0,1]  R153      1.6497924923896790e-01
    phi[0,1]  R154      -2.7452120184898376e-01
    phi[0,1]  R155      -5.9398049116134644e-01
    phi[0,1]  R156      2.3519994318485260e-01
    phi[0,1]  R157      -2.6123933792114258e+00
    phi[0,1]  R158      -2.6558659076690674e+00
    phi[0,1]  R159      -1.49895441532135
    phi[0,1]  R160      -1.1664456874132156e-01
    phi[0,1]  R161      -2.2728567123413086e+00
    phi[0,1]  R162      -2.1760873794555664e+00
    phi[0,1]  R163      -1.1372323036193848e+00
    phi[0,1]  R164      1.5029935836791992e+00
    phi[0,1]  R165      -3.4244973659515381e+00
    phi[0,1]  R166      -6.0940670967102051e-01
    phi[0,1]  R167      -3.6810455322265625e+00
    phi[0,1]  R168      -2.4766411781311035e+00
    phi[0,1]  R169      1.3277325630187988e+00
    phi[0,1]  R170      3.3390073776245117e+00
    phi[0,1]  R171      2.8899092674255371e+00
    phi[0,1]  R172      2.2295787334442139e+00
    phi[0,1]  R173      2.0320281982421875e+00
    phi[0,1]  R174      3.4186420440673828e+00
    phi[0,1]  R175      2.0607035160064697e+00
    phi[0,1]  R176      1.2651383876800537e+00
    phi[0,1]  R177      1.29560387134552
    phi[0,1]  R178      1.3987675905227661e+00
    phi[0,1]  R179      -2.0207924842834473e+00
    phi[0,1]  R180      -1.1800280809402466e+00
    phi[0,1]  R181      -3.4738163948059082e+00
    phi[0,1]  R182      -5.8964967727661133e-01
    phi[0,1]  R183      -2.1053321361541748e+00
    phi[0,1]  R184      -2.8847529888153076e+00
    phi[0,1]  R185      -1.7543654441833496e+00
    phi[0,1]  R186      -1.5343227982521057e-01
    phi[0,1]  R187      -2.2961275577545166e+00
    phi[0,1]  R188      -4.1192550659179688e+00
    phi[0,1]  R189      -1.8347289562225342e+00
    phi[0,1]  R190      -3.6431140899658203e+00
    phi[0,1]  R191      -1.1444900035858154e+00
    phi[0,1]  R192      -2.1215839385986328e+00
    phi[0,1]  R193      1.3022191822528839e-01
    phi[0,1]  R194      -1.5792474746704102e+00
    phi[0,1]  R195      -3.1061894893646240e+00
    phi[0,1]  R196      -5.5709940195083618e-01
    phi[0,1]  R197      -4.9677640199661255e-01
    phi[0,1]  R198      -1.5125824213027954e+00
    phi[0,1]  R199      -2.8717732429504395e-01
    phi[0,1]  R200      -2.3300900459289551e+00
    phi[0,1]  R201      -1.9852199554443359e+00
    phi[0,1]  R202      -2.3390786647796631e+00
    phi[0,1]  R203      -5.2185070514678955e-01
    phi[0,1]  R204      5.6234854459762573e-01
    phi[0,1]  R205      -3.3225684165954590e+00
    phi[0,1]  R206      -3.3181829452514648e+00
    phi[0,1]  R207      -7.7915674448013306e-01
    phi[0,1]  R208      5.5050069093704224e-01
    phi[0,1]  R209      -1.0409848764538765e-02
    phi[0,1]  R210      -2.3876395225524902e+00
    phi[0,1]  R211      1.0809738636016846e+00
    phi[0,1]  R212      -1.0619608312845230e-01
    phi[0,1]  R213      -3.4079229831695557e+00
    phi[0,1]  R214      -1.9636331796646118e+00
    phi[0,1]  R215      -1.5169124305248260e-01
    phi[0,1]  R216      -1.1527181863784790e+00
    phi[0,1]  R217      -3.8200814723968506e+00
    phi[0,1]  R218      1.9556609392166138e+00
    phi[0,1]  R219      -1.6384848356246948e+00
    phi[0,1]  R220      0.0775298997759819
    phi[0,1]  R221      -2.69022798538208
    phi[0,1]  R222      -6.3064539432525635e-01
    phi[0,1]  R223      -3.8050425052642822e+00
    phi[0,1]  R224      -2.0436257123947144e-01
    phi[0,1]  R225      3.3565545082092285e-01
    phi[0,1]  R226      1.8710997104644775e+00
    phi[0,1]  R227      -5.3445369005203247e-01
    phi[0,1]  R228      -3.9159832000732422e+00
    phi[0,1]  R229      8.3469939231872559e-01
    phi[0,1]  R230      -1.1574065685272217e+00
    phi[0,1]  R231      -4.6086430549621582e+00
    phi[0,1]  R232      1.9872316718101501e-01
    phi[0,1]  R233      1.1579774618148804e+00
    phi[0,1]  R234      -0.199266254901886
    phi[0,1]  R235      -0.546949028968811
    phi[0,1]  R236      7.5467109680175781e-01
    phi[0,1]  R237      -1.2149610519409180e+00
    phi[0,1]  R238      -1.7360685765743256e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R239      -3.0999999046325684e+00
    phi[1,0]  R240      -3.0999999046325684e+00
    phi[1,0]  R241      -2.2400000095367432e+00
    phi[1,0]  R242      -2.2400000095367432e+00
    phi[1,0]  R243      -3.0999999046325684e+00
    phi[1,0]  R244      -3.0999999046325684e+00
    phi[1,0]  R245      -2.5699999332427979e+00
    phi[1,0]  R246      -2.5699999332427979e+00
    phi[1,0]  R247      -3.0999999046325684e+00
    phi[1,0]  R248      -3.0999999046325684e+00
    phi[1,0]  R249      -2.0899999141693115e+00
    phi[1,0]  R250      -2.0899999141693115e+00
    phi[1,0]  R251      -3.0999999046325684e+00
    phi[1,0]  R252      -3.0999999046325684e+00
    phi[1,0]  R253      1.3277325630187988e+00
    phi[1,0]  R254      3.3390073776245117e+00
    phi[1,0]  R255      2.8899092674255371e+00
    phi[1,0]  R256      2.2295787334442139e+00
    phi[1,0]  R257      2.0320281982421875e+00
    phi[1,0]  R258      3.4186420440673828e+00
    phi[1,0]  R259      2.0607035160064697e+00
    phi[1,0]  R260      1.2651383876800537e+00
    phi[1,0]  R261      1.29560387134552
    phi[1,0]  R262      1.3987675905227661e+00
    phi[1,0]  R263      -2.0207924842834473e+00
    phi[1,0]  R264      -1.1800280809402466e+00
    phi[1,0]  R265      -3.4738163948059082e+00
    phi[1,0]  R266      -5.8964967727661133e-01
    phi[1,0]  R267      -2.1053321361541748e+00
    phi[1,0]  R268      -2.8847529888153076e+00
    phi[1,0]  R269      -1.7543654441833496e+00
    phi[1,0]  R270      -1.5343227982521057e-01
    phi[1,0]  R271      -2.2961275577545166e+00
    phi[1,0]  R272      -4.1192550659179688e+00
    phi[1,0]  R273      -1.8347289562225342e+00
    phi[1,0]  R274      -3.6431140899658203e+00
    phi[1,0]  R275      -1.1444900035858154e+00
    phi[1,0]  R276      -2.1215839385986328e+00
    phi[1,0]  R277      1.3022191822528839e-01
    phi[1,0]  R278      -1.5792474746704102e+00
    phi[1,0]  R279      -3.1061894893646240e+00
    phi[1,0]  R280      -5.5709940195083618e-01
    phi[1,0]  R281      -4.9677640199661255e-01
    phi[1,0]  R282      -1.5125824213027954e+00
    phi[1,0]  R283      -2.8717732429504395e-01
    phi[1,0]  R284      -2.3300900459289551e+00
    phi[1,0]  R285      -1.9852199554443359e+00
    phi[1,0]  R286      -2.3390786647796631e+00
    phi[1,0]  R287      -5.2185070514678955e-01
    phi[1,0]  R288      5.6234854459762573e-01
    phi[1,0]  R289      -3.3225684165954590e+00
    phi[1,0]  R290      -3.3181829452514648e+00
    phi[1,0]  R291      -7.7915674448013306e-01
    phi[1,0]  R292      5.5050069093704224e-01
    phi[1,0]  R293      -1.0409848764538765e-02
    phi[1,0]  R294      -2.3876395225524902e+00
    phi[1,0]  R295      1.0809738636016846e+00
    phi[1,0]  R296      -1.0619608312845230e-01
    phi[1,0]  R297      -3.4079229831695557e+00
    phi[1,0]  R298      -1.9636331796646118e+00
    phi[1,0]  R299      -1.5169124305248260e-01
    phi[1,0]  R300      -1.1527181863784790e+00
    phi[1,0]  R301      -3.8200814723968506e+00
    phi[1,0]  R302      1.9556609392166138e+00
    phi[1,0]  R303      -1.6384848356246948e+00
    phi[1,0]  R304      0.0775298997759819
    phi[1,0]  R305      -2.69022798538208
    phi[1,0]  R306      -6.3064539432525635e-01
    phi[1,0]  R307      -3.8050425052642822e+00
    phi[1,0]  R308      -2.0436257123947144e-01
    phi[1,0]  R309      3.3565545082092285e-01
    phi[1,0]  R310      1.8710997104644775e+00
    phi[1,0]  R311      -5.3445369005203247e-01
    phi[1,0]  R312      -3.9159832000732422e+00
    phi[1,0]  R313      8.3469939231872559e-01
    phi[1,0]  R314      -1.1574065685272217e+00
    phi[1,0]  R315      -4.6086430549621582e+00
    phi[1,0]  R316      1.9872316718101501e-01
    phi[1,0]  R317      1.1579774618148804e+00
    phi[1,0]  R318      -0.199266254901886
    phi[1,0]  R319      -0.546949028968811
    phi[1,0]  R320      7.5467109680175781e-01
    phi[1,0]  R321      -1.2149610519409180e+00
    phi[1,0]  R322      -1.7360685765743256e-01
    phi[1,0]  R323      1.0159441232681274e+00
    phi[1,0]  R324      -1.7644056081771851e+00
    phi[1,0]  R325      1.3585032224655151e+00
    phi[1,0]  R326      6.7489433288574219e-01
    phi[1,0]  R327      -1.4402663707733154e+00
    phi[1,0]  R328      9.7799998521804810e-01
    phi[1,0]  R329      -8.5215216875076294e-01
    phi[1,0]  R330      -4.0429866313934326e-01
    phi[1,0]  R331      1.5475416183471680e+00
    phi[1,0]  R332      4.5995357632637024e-01
    phi[1,0]  R333      -1.5600122213363647e+00
    phi[1,0]  R334      -1.1357716321945190e+00
    phi[1,0]  R335      2.3367057740688324e-01
    phi[1,0]  R336      7.6276743412017822e-01
    phi[1,0]  R337      -4.5526188611984253e-01
    phi[1,0]  R338      -1.3133538961410522e+00
    phi[1,0]  R339      -5.0542634725570679e-01
    phi[1,0]  R340      -4.5216137170791626e-01
    phi[1,0]  R341      3.1844526529312134e-01
    phi[1,0]  R342      -1.8851895332336426e+00
    phi[1,0]  R343      -1.9064227342605591e+00
    phi[1,0]  R344      7.0418214797973633e-01
    phi[1,0]  R345      1.3871654272079468e+00
    phi[1,0]  R346      -0.654192328453064
    phi[1,0]  R347      -1.1916174888610840e+00
    phi[1,0]  R348      -3.1361129283905029e+00
    phi[1,0]  R349      -1.0057340860366821e+00
    phi[1,0]  R350      -1.6034573316574097e+00
    phi[1,0]  R351      9.6862721443176270e-01
    phi[1,0]  R352      3.9759826660156250e-01
    phi[1,0]  R353      -2.4812116622924805e+00
    phi[1,0]  R354      -9.2186444997787476e-01
    phi[1,0]  R355      7.0037804543972015e-02
    phi[1,0]  R356      -2.7156016826629639e+00
    phi[1,0]  R357      -7.2365587949752808e-01
    phi[1,0]  R358      -1.8438590764999390e+00
    phi[1,0]  R359      -1.5154618024826050e+00
    phi[1,0]  R360      -2.8446391224861145e-01
    phi[1,0]  R361      -2.4487946033477783e+00
    phi[1,0]  R362      2.3740790784358978e-01
    phi[1,0]  R363      -2.1623109281063080e-01
    phi[1,0]  R364      -2.0164904594421387e+00
    phi[1,0]  R365      -2.5707316398620605e+00
    phi[1,0]  R366      -2.7655419707298279e-01
    phi[1,0]  R367      -2.4459133148193359e+00
    phi[1,0]  R368      -2.3751244544982910e+00
    phi[1,0]  R369      -1.3578327894210815e+00
    phi[1,0]  R370      -3.3353748321533203e+00
    phi[1,0]  R371      -5.6035429239273071e-01
    phi[1,0]  R372      -6.7638039588928223e-01
    phi[1,0]  R373      -1.0752881318330765e-01
    phi[1,0]  R374      -1.9092181921005249e+00
    phi[1,0]  R375      -7.0795518159866333e-01
    phi[1,0]  R376      -1.1471420526504517e+00
    phi[1,0]  R377      8.1515640020370483e-01
    phi[1,0]  R378      6.6731333732604980e-01
    phi[1,0]  R379      8.3316695690155029e-01
    phi[1,0]  R380      -1.3243304491043091e+00
    phi[1,0]  R381      -5.9693181514739990e-01
    phi[1,0]  R382      -2.1045117378234863e+00
    phi[1,0]  R383      5.3236120939254761e-01
    phi[1,0]  R384      -0.520591676235199
    phi[1,0]  R385      -1.5252255201339722e+00
    phi[1,0]  R386      -7.9158818721771240e-01
    phi[1,0]  R387      1.1236859560012817e+00
    phi[1,0]  R388      -8.6140173673629761e-01
    phi[1,0]  R389      3.4324795007705688e-01
    phi[1,0]  R390      -1.4987088441848755e+00
    phi[1,0]  R391      -8.8396197557449341e-01
    phi[1,0]  R392      6.9692707061767578e-01
    phi[1,0]  R393      -6.6418743133544922e-01
    phi[1,0]  R394      -1.7003329992294312e+00
    phi[1,0]  R395      -0.839230477809906
    phi[1,0]  R396      -1.8556820154190063e+00
    phi[1,0]  R397      1.6497924923896790e-01
    phi[1,0]  R398      -2.7452120184898376e-01
    phi[1,0]  R399      -5.9398049116134644e-01
    phi[1,0]  R400      2.3519994318485260e-01
    phi[1,0]  R401      -2.6123933792114258e+00
    phi[1,0]  R402      -2.6558659076690674e+00
    phi[1,0]  R403      -1.49895441532135
    phi[1,0]  R404      -1.1664456874132156e-01
    phi[1,0]  R405      -2.2728567123413086e+00
    phi[1,0]  R406      -2.1760873794555664e+00
    phi[1,0]  R407      -1.1372323036193848e+00
    phi[1,0]  R408      1.5029935836791992e+00
    phi[1,0]  R409      -3.4244973659515381e+00
    phi[1,0]  R410      -6.0940670967102051e-01
    phi[1,0]  R411      -3.6810455322265625e+00
    phi[1,0]  R412      -2.4766411781311035e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R413      -3.0999999046325684e+00
    phi[0,3]  R414      -3.0999999046325684e+00
    phi[0,3]  R415      -2.2400000095367432e+00
    phi[0,3]  R416      -2.2400000095367432e+00
    phi[0,3]  R417      -3.0999999046325684e+00
    phi[0,3]  R418      -3.0999999046325684e+00
    phi[0,3]  R419      -2.5699999332427979e+00
    phi[0,3]  R420      -2.5699999332427979e+00
    phi[0,3]  R421      -3.0999999046325684e+00
    phi[0,3]  R422      -3.0999999046325684e+00
    phi[0,3]  R423      -2.0899999141693115e+00
    phi[0,3]  R424      -2.0899999141693115e+00
    phi[0,3]  R425      -3.0999999046325684e+00
    phi[0,3]  R426      -3.0999999046325684e+00
    phi[0,3]  R427      1.0159441232681274e+00
    phi[0,3]  R428      -1.7644056081771851e+00
    phi[0,3]  R429      1.3585032224655151e+00
    phi[0,3]  R430      6.7489433288574219e-01
    phi[0,3]  R431      -1.4402663707733154e+00
    phi[0,3]  R432      9.7799998521804810e-01
    phi[0,3]  R433      -8.5215216875076294e-01
    phi[0,3]  R434      -4.0429866313934326e-01
    phi[0,3]  R435      1.5475416183471680e+00
    phi[0,3]  R436      4.5995357632637024e-01
    phi[0,3]  R437      -1.5600122213363647e+00
    phi[0,3]  R438      -1.1357716321945190e+00
    phi[0,3]  R439      2.3367057740688324e-01
    phi[0,3]  R440      7.6276743412017822e-01
    phi[0,3]  R441      -4.5526188611984253e-01
    phi[0,3]  R442      -1.3133538961410522e+00
    phi[0,3]  R443      -5.0542634725570679e-01
    phi[0,3]  R444      -4.5216137170791626e-01
    phi[0,3]  R445      3.1844526529312134e-01
    phi[0,3]  R446      -1.8851895332336426e+00
    phi[0,3]  R447      -1.9064227342605591e+00
    phi[0,3]  R448      7.0418214797973633e-01
    phi[0,3]  R449      1.3871654272079468e+00
    phi[0,3]  R450      -0.654192328453064
    phi[0,3]  R451      -1.1916174888610840e+00
    phi[0,3]  R452      -3.1361129283905029e+00
    phi[0,3]  R453      -1.0057340860366821e+00
    phi[0,3]  R454      -1.6034573316574097e+00
    phi[0,3]  R455      9.6862721443176270e-01
    phi[0,3]  R456      3.9759826660156250e-01
    phi[0,3]  R457      -2.4812116622924805e+00
    phi[0,3]  R458      -9.2186444997787476e-01
    phi[0,3]  R459      7.0037804543972015e-02
    phi[0,3]  R460      -2.7156016826629639e+00
    phi[0,3]  R461      -7.2365587949752808e-01
    phi[0,3]  R462      -1.8438590764999390e+00
    phi[0,3]  R463      -1.5154618024826050e+00
    phi[0,3]  R464      -2.8446391224861145e-01
    phi[0,3]  R465      -2.4487946033477783e+00
    phi[0,3]  R466      2.3740790784358978e-01
    phi[0,3]  R467      -2.1623109281063080e-01
    phi[0,3]  R468      -2.0164904594421387e+00
    phi[0,3]  R469      -2.5707316398620605e+00
    phi[0,3]  R470      -2.7655419707298279e-01
    phi[0,3]  R471      -2.4459133148193359e+00
    phi[0,3]  R472      -2.3751244544982910e+00
    phi[0,3]  R473      -1.3578327894210815e+00
    phi[0,3]  R474      -3.3353748321533203e+00
    phi[0,3]  R475      -5.6035429239273071e-01
    phi[0,3]  R476      -6.7638039588928223e-01
    phi[0,3]  R477      -1.0752881318330765e-01
    phi[0,3]  R478      -1.9092181921005249e+00
    phi[0,3]  R479      -7.0795518159866333e-01
    phi[0,3]  R480      -1.1471420526504517e+00
    phi[0,3]  R481      8.1515640020370483e-01
    phi[0,3]  R482      6.6731333732604980e-01
    phi[0,3]  R483      8.3316695690155029e-01
    phi[0,3]  R484      -1.3243304491043091e+00
    phi[0,3]  R485      -5.9693181514739990e-01
    phi[0,3]  R486      -2.1045117378234863e+00
    phi[0,3]  R487      5.3236120939254761e-01
    phi[0,3]  R488      -0.520591676235199
    phi[0,3]  R489      -1.5252255201339722e+00
    phi[0,3]  R490      -7.9158818721771240e-01
    phi[0,3]  R491      1.1236859560012817e+00
    phi[0,3]  R492      -8.6140173673629761e-01
    phi[0,3]  R493      3.4324795007705688e-01
    phi[0,3]  R494      -1.4987088441848755e+00
    phi[0,3]  R495      -8.8396197557449341e-01
    phi[0,3]  R496      6.9692707061767578e-01
    phi[0,3]  R497      -6.6418743133544922e-01
    phi[0,3]  R498      -1.7003329992294312e+00
    phi[0,3]  R499      -0.839230477809906
    phi[0,3]  R500      -1.8556820154190063e+00
    phi[0,3]  R501      1.6497924923896790e-01
    phi[0,3]  R502      -2.7452120184898376e-01
    phi[0,3]  R503      -5.9398049116134644e-01
    phi[0,3]  R504      2.3519994318485260e-01
    phi[0,3]  R505      -2.6123933792114258e+00
    phi[0,3]  R506      -2.6558659076690674e+00
    phi[0,3]  R507      -1.49895441532135
    phi[0,3]  R508      -1.1664456874132156e-01
    phi[0,3]  R509      -2.2728567123413086e+00
    phi[0,3]  R510      -2.1760873794555664e+00
    phi[0,3]  R511      -1.1372323036193848e+00
    phi[0,3]  R512      1.5029935836791992e+00
    phi[0,3]  R513      -3.4244973659515381e+00
    phi[0,3]  R514      -6.0940670967102051e-01
    phi[0,3]  R515      -3.6810455322265625e+00
    phi[0,3]  R516      -2.4766411781311035e+00
    phi[0,3]  R517      4.5096531510353088e-02
    phi[0,3]  R518      1.8677181005477905e+00
    phi[0,3]  R519      3.4945321083068848e-01
    phi[0,3]  R520      9.7148710489273071e-01
    phi[0,3]  R521      2.2512047290802
    phi[0,3]  R522      1.1111259460449219e+00
    phi[0,3]  R523      -1.3897062540054321e+00
    phi[0,3]  R524      2.5951156616210938e+00
    phi[0,3]  R525      4.5361062884330750e-01
    phi[0,3]  R526      -3.4487705230712891e+00
    phi[0,3]  R527      1.1418876796960831e-01
    phi[0,3]  R528      -6.1531984806060791e-01
    phi[0,3]  R529      7.0120233297348022e-01
    phi[0,3]  R530      -6.5589410066604614e-01
    phi[0,3]  R531      -2.0468633174896240e+00
    phi[0,3]  R532      -2.5278043746948242e+00
    phi[0,3]  R533      -1.1658314466476440e+00
    phi[0,3]  R534      -1.4226363897323608e+00
    phi[0,3]  R535      -1.8599766492843628e+00
    phi[0,3]  R536      -4.6490821242332458e-01
    phi[0,3]  R537      -2.2472314834594727e+00
    phi[0,3]  R538      -4.3628865480422974e-01
    phi[0,3]  R539      -8.1092137098312378e-01
    phi[0,3]  R540      8.8767188787460327e-01
    phi[0,3]  R541      -6.6583949327468872e-01
    phi[0,3]  R542      -6.6912615299224854e-01
    phi[0,3]  R543      3.2262913882732391e-02
    phi[0,3]  R544      -1.6698111593723297e-01
    phi[0,3]  R545      -1.4931937456130981e+00
    phi[0,3]  R546      -5.3503584861755371e-01
    phi[0,3]  R547      -1.8259797990322113e-01
    phi[0,3]  R548      -0.234147846698761
    phi[0,3]  R549      -1.4616293907165527e+00
    phi[0,3]  R550      1.7572814226150513e-01
    phi[0,3]  R551      2.9534992575645447e-01
    phi[0,3]  R552      7.2278702259063721e-01
    phi[0,3]  R553      -6.7692697048187256e-01
    phi[0,3]  R554      -2.4364208802580833e-02
    phi[0,3]  R555      -1.8344134092330933e+00
    phi[0,3]  R556      6.5171188116073608e-01
    phi[0,3]  R557      5.0714202225208282e-02
    phi[0,3]  R558      -0.765410840511322
    phi[0,3]  R559      -0.573043704032898
    phi[0,3]  R560      -0.0806007832288742
    phi[0,3]  R561      7.3962211608886719e-01
    phi[0,3]  R562      9.2908978462219238e-02
    phi[0,3]  R563      -2.5569078922271729e+00
    phi[0,3]  R564      -0.0906447172164917
    phi[0,3]  R565      -0.861920952796936
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R566      -3.0999999046325684e+00
    phi[3,0]  R567      -3.0999999046325684e+00
    phi[3,0]  R568      -2.2400000095367432e+00
    phi[3,0]  R569      -2.2400000095367432e+00
    phi[3,0]  R570      -3.0999999046325684e+00
    phi[3,0]  R571      -3.0999999046325684e+00
    phi[3,0]  R572      -2.5699999332427979e+00
    phi[3,0]  R573      -2.5699999332427979e+00
    phi[3,0]  R574      -3.0999999046325684e+00
    phi[3,0]  R575      -3.0999999046325684e+00
    phi[3,0]  R576      -2.0899999141693115e+00
    phi[3,0]  R577      -2.0899999141693115e+00
    phi[3,0]  R578      -3.0999999046325684e+00
    phi[3,0]  R579      -3.0999999046325684e+00
    phi[3,0]  R580      4.5096531510353088e-02
    phi[3,0]  R581      1.8677181005477905e+00
    phi[3,0]  R582      3.4945321083068848e-01
    phi[3,0]  R583      9.7148710489273071e-01
    phi[3,0]  R584      2.2512047290802
    phi[3,0]  R585      1.1111259460449219e+00
    phi[3,0]  R586      -1.3897062540054321e+00
    phi[3,0]  R587      -8.5215216875076294e-01
    phi[3,0]  R588      2.5951156616210938e+00
    phi[3,0]  R589      4.5361062884330750e-01
    phi[3,0]  R590      -3.4487705230712891e+00
    phi[3,0]  R591      1.1418876796960831e-01
    phi[3,0]  R592      -6.1531984806060791e-01
    phi[3,0]  R593      7.0120233297348022e-01
    phi[3,0]  R594      -6.5589410066604614e-01
    phi[3,0]  R595      -2.0468633174896240e+00
    phi[3,0]  R596      -2.5278043746948242e+00
    phi[3,0]  R597      -1.1658314466476440e+00
    phi[3,0]  R598      -1.4226363897323608e+00
    phi[3,0]  R599      -1.8599766492843628e+00
    phi[3,0]  R600      -4.6490821242332458e-01
    phi[3,0]  R601      -2.2472314834594727e+00
    phi[3,0]  R602      -4.3628865480422974e-01
    phi[3,0]  R603      -8.1092137098312378e-01
    phi[3,0]  R604      8.8767188787460327e-01
    phi[3,0]  R605      -6.6583949327468872e-01
    phi[3,0]  R606      -6.6912615299224854e-01
    phi[3,0]  R607      3.2262913882732391e-02
    phi[3,0]  R608      -1.6698111593723297e-01
    phi[3,0]  R609      -1.4931937456130981e+00
    phi[3,0]  R610      -5.3503584861755371e-01
    phi[3,0]  R611      -1.8259797990322113e-01
    phi[3,0]  R612      -0.234147846698761
    phi[3,0]  R613      -1.4616293907165527e+00
    phi[3,0]  R614      1.7572814226150513e-01
    phi[3,0]  R615      2.9534992575645447e-01
    phi[3,0]  R616      7.2278702259063721e-01
    phi[3,0]  R617      -6.7692697048187256e-01
    phi[3,0]  R618      -2.4364208802580833e-02
    phi[3,0]  R619      -1.8344134092330933e+00
    phi[3,0]  R620      6.5171188116073608e-01
    phi[3,0]  R621      5.0714202225208282e-02
    phi[3,0]  R622      -0.765410840511322
    phi[3,0]  R623      -0.573043704032898
    phi[3,0]  R624      -0.0806007832288742
    phi[3,0]  R625      7.3962211608886719e-01
    phi[3,0]  R626      9.2908978462219238e-02
    phi[3,0]  R627      -2.5569078922271729e+00
    phi[3,0]  R628      -0.0906447172164917
    phi[3,0]  R629      -0.861920952796936
    phi[3,0]  R630      1.0159441232681274e+00
    phi[3,0]  R631      -1.7644056081771851e+00
    phi[3,0]  R632      1.3585032224655151e+00
    phi[3,0]  R633      6.7489433288574219e-01
    phi[3,0]  R634      -1.4402663707733154e+00
    phi[3,0]  R635      9.7799998521804810e-01
    phi[3,0]  R636      -4.0429866313934326e-01
    phi[3,0]  R637      1.5475416183471680e+00
    phi[3,0]  R638      4.5995357632637024e-01
    phi[3,0]  R639      -1.5600122213363647e+00
    phi[3,0]  R640      -1.1357716321945190e+00
    phi[3,0]  R641      2.3367057740688324e-01
    phi[3,0]  R642      7.6276743412017822e-01
    phi[3,0]  R643      -4.5526188611984253e-01
    phi[3,0]  R644      -1.3133538961410522e+00
    phi[3,0]  R645      -5.0542634725570679e-01
    phi[3,0]  R646      -4.5216137170791626e-01
    phi[3,0]  R647      3.1844526529312134e-01
    phi[3,0]  R648      -1.8851895332336426e+00
    phi[3,0]  R649      -1.9064227342605591e+00
    phi[3,0]  R650      7.0418214797973633e-01
    phi[3,0]  R651      1.3871654272079468e+00
    phi[3,0]  R652      -0.654192328453064
    phi[3,0]  R653      -1.1916174888610840e+00
    phi[3,0]  R654      -3.1361129283905029e+00
    phi[3,0]  R655      -1.0057340860366821e+00
    phi[3,0]  R656      -1.6034573316574097e+00
    phi[3,0]  R657      9.6862721443176270e-01
    phi[3,0]  R658      3.9759826660156250e-01
    phi[3,0]  R659      -2.4812116622924805e+00
    phi[3,0]  R660      -9.2186444997787476e-01
    phi[3,0]  R661      7.0037804543972015e-02
    phi[3,0]  R662      -2.7156016826629639e+00
    phi[3,0]  R663      -7.2365587949752808e-01
    phi[3,0]  R664      -1.8438590764999390e+00
    phi[3,0]  R665      -1.5154618024826050e+00
    phi[3,0]  R666      -2.8446391224861145e-01
    phi[3,0]  R667      -2.4487946033477783e+00
    phi[3,0]  R668      2.3740790784358978e-01
    phi[3,0]  R669      -2.1623109281063080e-01
    phi[3,0]  R670      -2.0164904594421387e+00
    phi[3,0]  R671      -2.5707316398620605e+00
    phi[3,0]  R672      -2.7655419707298279e-01
    phi[3,0]  R673      -2.4459133148193359e+00
    phi[3,0]  R674      -2.3751244544982910e+00
    phi[3,0]  R675      -1.3578327894210815e+00
    phi[3,0]  R676      -3.3353748321533203e+00
    phi[3,0]  R677      -5.6035429239273071e-01
    phi[3,0]  R678      -6.7638039588928223e-01
    phi[3,0]  R679      -1.0752881318330765e-01
    phi[3,0]  R680      -1.9092181921005249e+00
    phi[3,0]  R681      -7.0795518159866333e-01
    phi[3,0]  R682      -1.1471420526504517e+00
    phi[3,0]  R683      8.1515640020370483e-01
    phi[3,0]  R684      6.6731333732604980e-01
    phi[3,0]  R685      8.3316695690155029e-01
    phi[3,0]  R686      -1.3243304491043091e+00
    phi[3,0]  R687      -5.9693181514739990e-01
    phi[3,0]  R688      -2.1045117378234863e+00
    phi[3,0]  R689      5.3236120939254761e-01
    phi[3,0]  R690      -0.520591676235199
    phi[3,0]  R691      -1.5252255201339722e+00
    phi[3,0]  R692      -7.9158818721771240e-01
    phi[3,0]  R693      1.1236859560012817e+00
    phi[3,0]  R694      -8.6140173673629761e-01
    phi[3,0]  R695      3.4324795007705688e-01
    phi[3,0]  R696      -1.4987088441848755e+00
    phi[3,0]  R697      -8.8396197557449341e-01
    phi[3,0]  R698      6.9692707061767578e-01
    phi[3,0]  R699      -6.6418743133544922e-01
    phi[3,0]  R700      -1.7003329992294312e+00
    phi[3,0]  R701      -0.839230477809906
    phi[3,0]  R702      -1.8556820154190063e+00
    phi[3,0]  R703      1.6497924923896790e-01
    phi[3,0]  R704      -2.7452120184898376e-01
    phi[3,0]  R705      -5.9398049116134644e-01
    phi[3,0]  R706      2.3519994318485260e-01
    phi[3,0]  R707      -2.6123933792114258e+00
    phi[3,0]  R708      -2.6558659076690674e+00
    phi[3,0]  R709      -1.49895441532135
    phi[3,0]  R710      -1.1664456874132156e-01
    phi[3,0]  R711      -2.2728567123413086e+00
    phi[3,0]  R712      -2.1760873794555664e+00
    phi[3,0]  R713      -1.1372323036193848e+00
    phi[3,0]  R714      1.5029935836791992e+00
    phi[3,0]  R715      -3.4244973659515381e+00
    phi[3,0]  R716      -6.0940670967102051e-01
    phi[3,0]  R717      -3.6810455322265625e+00
    phi[3,0]  R718      -2.4766411781311035e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R719      -3.0999999046325684e+00
    phi[0,4]  R720      -3.0999999046325684e+00
    phi[0,4]  R721      -2.2400000095367432e+00
    phi[0,4]  R722      -2.2400000095367432e+00
    phi[0,4]  R723      -3.0999999046325684e+00
    phi[0,4]  R724      -3.0999999046325684e+00
    phi[0,4]  R725      -2.5699999332427979e+00
    phi[0,4]  R726      -2.5699999332427979e+00
    phi[0,4]  R727      -3.0999999046325684e+00
    phi[0,4]  R728      -3.0999999046325684e+00
    phi[0,4]  R729      -2.0899999141693115e+00
    phi[0,4]  R730      -2.0899999141693115e+00
    phi[0,4]  R731      -3.0999999046325684e+00
    phi[0,4]  R732      -3.0999999046325684e+00
    phi[0,4]  R733      1.0159441232681274e+00
    phi[0,4]  R734      -1.7644056081771851e+00
    phi[0,4]  R735      1.3585032224655151e+00
    phi[0,4]  R736      6.7489433288574219e-01
    phi[0,4]  R737      -1.4402663707733154e+00
    phi[0,4]  R738      9.7799998521804810e-01
    phi[0,4]  R739      -8.5215216875076294e-01
    phi[0,4]  R740      -4.0429866313934326e-01
    phi[0,4]  R741      1.5475416183471680e+00
    phi[0,4]  R742      4.5995357632637024e-01
    phi[0,4]  R743      -1.5600122213363647e+00
    phi[0,4]  R744      -1.1357716321945190e+00
    phi[0,4]  R745      2.3367057740688324e-01
    phi[0,4]  R746      7.6276743412017822e-01
    phi[0,4]  R747      -4.5526188611984253e-01
    phi[0,4]  R748      -1.3133538961410522e+00
    phi[0,4]  R749      -5.0542634725570679e-01
    phi[0,4]  R750      -4.5216137170791626e-01
    phi[0,4]  R751      3.1844526529312134e-01
    phi[0,4]  R752      -1.8851895332336426e+00
    phi[0,4]  R753      -1.9064227342605591e+00
    phi[0,4]  R754      7.0418214797973633e-01
    phi[0,4]  R755      1.3871654272079468e+00
    phi[0,4]  R756      -0.654192328453064
    phi[0,4]  R757      -1.1916174888610840e+00
    phi[0,4]  R758      -3.1361129283905029e+00
    phi[0,4]  R759      -1.0057340860366821e+00
    phi[0,4]  R760      -1.6034573316574097e+00
    phi[0,4]  R761      9.6862721443176270e-01
    phi[0,4]  R762      3.9759826660156250e-01
    phi[0,4]  R763      -2.4812116622924805e+00
    phi[0,4]  R764      -9.2186444997787476e-01
    phi[0,4]  R765      7.0037804543972015e-02
    phi[0,4]  R766      -2.7156016826629639e+00
    phi[0,4]  R767      -7.2365587949752808e-01
    phi[0,4]  R768      -1.8438590764999390e+00
    phi[0,4]  R769      -1.5154618024826050e+00
    phi[0,4]  R770      -2.8446391224861145e-01
    phi[0,4]  R771      -2.4487946033477783e+00
    phi[0,4]  R772      2.3740790784358978e-01
    phi[0,4]  R773      -2.1623109281063080e-01
    phi[0,4]  R774      -2.0164904594421387e+00
    phi[0,4]  R775      -2.5707316398620605e+00
    phi[0,4]  R776      -2.7655419707298279e-01
    phi[0,4]  R777      -2.4459133148193359e+00
    phi[0,4]  R778      -2.3751244544982910e+00
    phi[0,4]  R779      -1.3578327894210815e+00
    phi[0,4]  R780      -3.3353748321533203e+00
    phi[0,4]  R781      -5.6035429239273071e-01
    phi[0,4]  R782      -6.7638039588928223e-01
    phi[0,4]  R783      -1.0752881318330765e-01
    phi[0,4]  R784      -1.9092181921005249e+00
    phi[0,4]  R785      -7.0795518159866333e-01
    phi[0,4]  R786      -1.1471420526504517e+00
    phi[0,4]  R787      8.1515640020370483e-01
    phi[0,4]  R788      6.6731333732604980e-01
    phi[0,4]  R789      8.3316695690155029e-01
    phi[0,4]  R790      -1.3243304491043091e+00
    phi[0,4]  R791      -5.9693181514739990e-01
    phi[0,4]  R792      -2.1045117378234863e+00
    phi[0,4]  R793      5.3236120939254761e-01
    phi[0,4]  R794      -0.520591676235199
    phi[0,4]  R795      -1.5252255201339722e+00
    phi[0,4]  R796      -7.9158818721771240e-01
    phi[0,4]  R797      1.1236859560012817e+00
    phi[0,4]  R798      -8.6140173673629761e-01
    phi[0,4]  R799      3.4324795007705688e-01
    phi[0,4]  R800      -1.4987088441848755e+00
    phi[0,4]  R801      -8.8396197557449341e-01
    phi[0,4]  R802      6.9692707061767578e-01
    phi[0,4]  R803      -6.6418743133544922e-01
    phi[0,4]  R804      -1.7003329992294312e+00
    phi[0,4]  R805      -0.839230477809906
    phi[0,4]  R806      -1.8556820154190063e+00
    phi[0,4]  R807      1.6497924923896790e-01
    phi[0,4]  R808      -2.7452120184898376e-01
    phi[0,4]  R809      -5.9398049116134644e-01
    phi[0,4]  R810      2.3519994318485260e-01
    phi[0,4]  R811      -2.6123933792114258e+00
    phi[0,4]  R812      -2.6558659076690674e+00
    phi[0,4]  R813      -1.49895441532135
    phi[0,4]  R814      -1.1664456874132156e-01
    phi[0,4]  R815      -2.2728567123413086e+00
    phi[0,4]  R816      -2.1760873794555664e+00
    phi[0,4]  R817      -1.1372323036193848e+00
    phi[0,4]  R818      1.5029935836791992e+00
    phi[0,4]  R819      -3.4244973659515381e+00
    phi[0,4]  R820      -6.0940670967102051e-01
    phi[0,4]  R821      -3.6810455322265625e+00
    phi[0,4]  R822      -2.4766411781311035e+00
    phi[0,4]  R823      1.9625407457351685e+00
    phi[0,4]  R824      -1.1330999433994293e-02
    phi[0,4]  R825      2.2506809234619141e+00
    phi[0,4]  R826      1.4078931808471680e+00
    phi[0,4]  R827      -1.5558645129203796e-01
    phi[0,4]  R828      2.2328653335571289e+00
    phi[0,4]  R829      -3.8762614727020264e+00
    phi[0,4]  R830      -2.4869353771209717e+00
    phi[0,4]  R831      -3.4038228988647461e+00
    phi[0,4]  R832      -2.5603609085083008e+00
    phi[0,4]  R833      -2.3685986995697021e+00
    phi[0,4]  R834      0.773317277431488
    phi[0,4]  R835      1.5606095790863037e+00
    phi[0,4]  R836      -3.2540032267570496e-01
    phi[0,4]  R837      4.0054696798324585e-01
    phi[0,4]  R838      -1.9057852029800415e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R839      -3.0999999046325684e+00
    phi[4,0]  R840      -3.0999999046325684e+00
    phi[4,0]  R841      -2.2400000095367432e+00
    phi[4,0]  R842      -2.2400000095367432e+00
    phi[4,0]  R843      -3.0999999046325684e+00
    phi[4,0]  R844      -3.0999999046325684e+00
    phi[4,0]  R845      -2.5699999332427979e+00
    phi[4,0]  R846      -2.5699999332427979e+00
    phi[4,0]  R847      -3.0999999046325684e+00
    phi[4,0]  R848      -3.0999999046325684e+00
    phi[4,0]  R849      -2.0899999141693115e+00
    phi[4,0]  R850      -2.0899999141693115e+00
    phi[4,0]  R851      -3.0999999046325684e+00
    phi[4,0]  R852      -3.0999999046325684e+00
    phi[4,0]  R853      1.9625407457351685e+00
    phi[4,0]  R854      -1.1330999433994293e-02
    phi[4,0]  R855      2.2506809234619141e+00
    phi[4,0]  R856      1.4078931808471680e+00
    phi[4,0]  R857      -1.5558645129203796e-01
    phi[4,0]  R858      2.2328653335571289e+00
    phi[4,0]  R859      -3.8762614727020264e+00
    phi[4,0]  R860      -2.4869353771209717e+00
    phi[4,0]  R861      -3.4038228988647461e+00
    phi[4,0]  R862      -2.5603609085083008e+00
    phi[4,0]  R863      -2.3685986995697021e+00
    phi[4,0]  R864      0.773317277431488
    phi[4,0]  R865      1.5606095790863037e+00
    phi[4,0]  R866      -3.2540032267570496e-01
    phi[4,0]  R867      4.0054696798324585e-01
    phi[4,0]  R868      -1.9057852029800415e-01
    phi[4,0]  R869      1.0159441232681274e+00
    phi[4,0]  R870      -1.7644056081771851e+00
    phi[4,0]  R871      1.3585032224655151e+00
    phi[4,0]  R872      6.7489433288574219e-01
    phi[4,0]  R873      -1.4402663707733154e+00
    phi[4,0]  R874      9.7799998521804810e-01
    phi[4,0]  R875      -8.5215216875076294e-01
    phi[4,0]  R876      -4.0429866313934326e-01
    phi[4,0]  R877      1.5475416183471680e+00
    phi[4,0]  R878      4.5995357632637024e-01
    phi[4,0]  R879      -1.5600122213363647e+00
    phi[4,0]  R880      -1.1357716321945190e+00
    phi[4,0]  R881      2.3367057740688324e-01
    phi[4,0]  R882      7.6276743412017822e-01
    phi[4,0]  R883      -4.5526188611984253e-01
    phi[4,0]  R884      -1.3133538961410522e+00
    phi[4,0]  R885      -5.0542634725570679e-01
    phi[4,0]  R886      -4.5216137170791626e-01
    phi[4,0]  R887      3.1844526529312134e-01
    phi[4,0]  R888      -1.8851895332336426e+00
    phi[4,0]  R889      -1.9064227342605591e+00
    phi[4,0]  R890      7.0418214797973633e-01
    phi[4,0]  R891      1.3871654272079468e+00
    phi[4,0]  R892      -0.654192328453064
    phi[4,0]  R893      -1.1916174888610840e+00
    phi[4,0]  R894      -3.1361129283905029e+00
    phi[4,0]  R895      -1.0057340860366821e+00
    phi[4,0]  R896      -1.6034573316574097e+00
    phi[4,0]  R897      9.6862721443176270e-01
    phi[4,0]  R898      3.9759826660156250e-01
    phi[4,0]  R899      -2.4812116622924805e+00
    phi[4,0]  R900      -9.2186444997787476e-01
    phi[4,0]  R901      7.0037804543972015e-02
    phi[4,0]  R902      -2.7156016826629639e+00
    phi[4,0]  R903      -7.2365587949752808e-01
    phi[4,0]  R904      -1.8438590764999390e+00
    phi[4,0]  R905      -1.5154618024826050e+00
    phi[4,0]  R906      -2.8446391224861145e-01
    phi[4,0]  R907      -2.4487946033477783e+00
    phi[4,0]  R908      2.3740790784358978e-01
    phi[4,0]  R909      -2.1623109281063080e-01
    phi[4,0]  R910      -2.0164904594421387e+00
    phi[4,0]  R911      -2.5707316398620605e+00
    phi[4,0]  R912      -2.7655419707298279e-01
    phi[4,0]  R913      -2.4459133148193359e+00
    phi[4,0]  R914      -2.3751244544982910e+00
    phi[4,0]  R915      -1.3578327894210815e+00
    phi[4,0]  R916      -3.3353748321533203e+00
    phi[4,0]  R917      -5.6035429239273071e-01
    phi[4,0]  R918      -6.7638039588928223e-01
    phi[4,0]  R919      -1.0752881318330765e-01
    phi[4,0]  R920      -1.9092181921005249e+00
    phi[4,0]  R921      -7.0795518159866333e-01
    phi[4,0]  R922      -1.1471420526504517e+00
    phi[4,0]  R923      8.1515640020370483e-01
    phi[4,0]  R924      6.6731333732604980e-01
    phi[4,0]  R925      8.3316695690155029e-01
    phi[4,0]  R926      -1.3243304491043091e+00
    phi[4,0]  R927      -5.9693181514739990e-01
    phi[4,0]  R928      -2.1045117378234863e+00
    phi[4,0]  R929      5.3236120939254761e-01
    phi[4,0]  R930      -0.520591676235199
    phi[4,0]  R931      -1.5252255201339722e+00
    phi[4,0]  R932      -7.9158818721771240e-01
    phi[4,0]  R933      1.1236859560012817e+00
    phi[4,0]  R934      -8.6140173673629761e-01
    phi[4,0]  R935      3.4324795007705688e-01
    phi[4,0]  R936      -1.4987088441848755e+00
    phi[4,0]  R937      -8.8396197557449341e-01
    phi[4,0]  R938      6.9692707061767578e-01
    phi[4,0]  R939      -6.6418743133544922e-01
    phi[4,0]  R940      -1.7003329992294312e+00
    phi[4,0]  R941      -0.839230477809906
    phi[4,0]  R942      -1.8556820154190063e+00
    phi[4,0]  R943      1.6497924923896790e-01
    phi[4,0]  R944      -2.7452120184898376e-01
    phi[4,0]  R945      -5.9398049116134644e-01
    phi[4,0]  R946      2.3519994318485260e-01
    phi[4,0]  R947      -2.6123933792114258e+00
    phi[4,0]  R948      -2.6558659076690674e+00
    phi[4,0]  R949      -1.49895441532135
    phi[4,0]  R950      -1.1664456874132156e-01
    phi[4,0]  R951      -2.2728567123413086e+00
    phi[4,0]  R952      -2.1760873794555664e+00
    phi[4,0]  R953      -1.1372323036193848e+00
    phi[4,0]  R954      1.5029935836791992e+00
    phi[4,0]  R955      -3.4244973659515381e+00
    phi[4,0]  R956      -6.0940670967102051e-01
    phi[4,0]  R957      -3.6810455322265625e+00
    phi[4,0]  R958      -2.4766411781311035e+00
    phi[7,0]  R0        -1
    phi[7,0]  R2        1.3560046325126947e+00
    phi[7,0]  R3        -3.1583362838780427e-01
    phi[7,0]  R4        -2.9307371201075378e+00
    phi[7,0]  R5        1.5433476436668268e+00
    phi[7,0]  R6        1.0607724734688744e+00
    phi[7,0]  R7        7.3495253474880862e-01
    phi[7,0]  R8        -2.9130789163512225e+00
    phi[7,0]  R63       1
    phi[7,0]  R959      -4.4560045371452635e+00
    phi[7,0]  R960      -1.7439952721198737e+00
    phi[7,0]  R961      -1.9241663811489389e+00
    phi[7,0]  R962      -2.5558336379245477e+00
    phi[7,0]  R963      -1.6926278452503052e-01
    phi[7,0]  R964      -6.0307370247401062e+00
    phi[7,0]  R965      -4.1133475769096250e+00
    phi[7,0]  R966      -1.0266522895759711e+00
    phi[7,0]  R967      -4.1607723781014432e+00
    phi[7,0]  R968      -2.0392274311636940e+00
    phi[7,0]  R969      -2.82495244891812
    phi[7,0]  R970      -1.3550473794205029e+00
    phi[7,0]  R971      -1.8692098828134585e-01
    phi[7,0]  R972      -6.0130788209837913e+00
    phi[7,0]  R973      -5.8847112008299018e-01
    phi[7,0]  R974      -6.2802207713796454e-01
    phi[7,0]  R975      -7.3482231464138881e-01
    phi[7,0]  R976      -7.3487702572294622e-01
    phi[7,0]  R977      -7.4668947183482248e-01
    phi[7,0]  R978      -7.5141628464114008e-01
    phi[7,0]  R979      -7.6314192427935879e-01
    phi[7,0]  R980      -7.7381901849561752e-01
    phi[7,0]  R981      -7.7454444309761472e-01
    phi[7,0]  R982      -7.8693584682832030e-01
    phi[7,0]  R983      -5.6730840187135567e-01
    phi[7,0]  R984      -5.9917953500171306e-01
    phi[7,0]  R985      -6.0484316403656657e-01
    phi[7,0]  R986      -6.4650836838206360e-01
    phi[7,0]  R987      -6.6736758611110480e-01
    phi[7,0]  R988      -6.6854699797028416e-01
    phi[7,0]  R989      -6.7266730090765459e-01
    phi[7,0]  R990      -6.8283487451973612e-01
    phi[7,0]  R991      -6.8609524509224684e-01
    phi[7,0]  R992      -6.9046214750720925e-01
    phi[7,0]  R993      -5.8998495543004537e-01
    phi[7,0]  R994      -6.4265452525770939e-01
    phi[7,0]  R995      -6.4626477349477573e-01
    phi[7,0]  R996      -6.8461642727921257e-01
    phi[7,0]  R997      -7.0801188953917682e-01
    phi[7,0]  R998      -7.4144208860505412e-01
    phi[7,0]  R999      -7.4840533827050748e-01
    phi[7,0]  R1000     -0.749709471009166
    phi[7,0]  R1001     -7.5656040694489657e-01
    phi[7,0]  R1002     -7.6590928476245246e-01
    phi[7,0]  R1003     -5.9707484730143712e-01
    phi[7,0]  R1004     -6.7518147097482362e-01
    phi[7,0]  R1005     -6.8803545831206880e-01
    phi[7,0]  R1006     -0.696936281868326
    phi[7,0]  R1007     -7.0439319146214574e-01
    phi[7,0]  R1008     -7.1692843911472970e-01
    phi[7,0]  R1009     -7.1821038951989169e-01
    phi[7,0]  R1010     -7.2178469599311357e-01
    phi[7,0]  R1011     -7.2452522930153540e-01
    phi[7,0]  R1012     -7.3099623296420557e-01
    phi[7,0]  R1013     -5.9411413410962766e-01
    phi[7,0]  R1014     -0.595974778761361
    phi[7,0]  R1015     -0.620643337983823
    phi[7,0]  R1016     -6.2093331072746771e-01
    phi[7,0]  R1017     -6.3488690227137967e-01
    phi[7,0]  R1018     -6.3514893503770509e-01
    phi[7,0]  R1019     -6.5265296264589645e-01
    phi[7,0]  R1020     -6.5413376813632107e-01
    phi[7,0]  R1021     -7.1938518955491726e-01
    phi[7,0]  R1022     -0.735222782671271
    phi[7,0]  R1023     -6.0426727529732571e-01
    phi[7,0]  R1024     -6.5854760858354577e-01
    phi[7,0]  R1025     -6.8062649138691067e-01
    phi[7,0]  R1026     -7.1995890827104680e-01
    phi[7,0]  R1027     -7.3354280420700868e-01
    phi[7,0]  R1028     -7.3568171438447383e-01
    phi[7,0]  R1029     -7.4640385096136841e-01
    phi[7,0]  R1030     -7.5006268985082580e-01
    phi[7,0]  R1031     -7.5840543116728742e-01
    phi[7,0]  R1032     -7.6428744592605335e-01
    phi[7,0]  R1033     -5.7985580790897506e-01
    phi[7,0]  R1034     -5.8848391864512561e-01
    phi[7,0]  R1035     -5.9970503137788833e-01
    phi[7,0]  R1036     -6.0752349785220361e-01
    phi[7,0]  R1037     -6.0872054577326962e-01
    phi[7,0]  R1038     -6.1399790325255532e-01
    phi[7,0]  R1039     -7.1894682131409460e-01
    phi[7,0]  R1040     -7.4474678185097987e-01
    phi[7,0]  R1041     -8.5791535348522174e-01
    phi[7,0]  R1042     -8.6075878722905608e-01
    phi[7,0]  R1043     -5.5055597227917907e-01
    phi[7,0]  R1044     -6.0192656290430779e-01
    phi[7,0]  R1045     -6.2769900318445093e-01
    phi[7,0]  R1046     -6.3687614703760853e-01
    phi[7,0]  R1047     -6.6834115439352260e-01
    phi[7,0]  R1048     -6.7504826798621043e-01
    phi[7,0]  R1049     -7.1343439505054018e-01
    phi[7,0]  R1050     -7.2112663391744913e-01
    phi[7,0]  R1051     -7.4993800630588958e-01
    phi[7,0]  R1052     -7.5734731449778558e-01
    phi[7,0]  R1053     -5.6457464798957557e-01
    phi[7,0]  R1054     -5.7786544274619533e-01
    phi[7,0]  R1055     -6.0332896488609267e-01
    phi[7,0]  R1056     -6.6299123803078852e-01
    phi[7,0]  R1057     -7.4013398496221883e-01
    phi[7,0]  R1058     -7.7413734570238546e-01
    phi[7,0]  R1059     -1.8367116102408620e+00
    phi[7,0]  R1060     -8.6643508207297126e-01
    phi[7,0]  R1061     -2.5177784926485556e+00
    phi[7,0]  R1062     -8.9798370291840146e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R1063     -3.0999999046325684e+00
    phi[1,2]  R1064     -3.0999999046325684e+00
    phi[1,2]  R1065     -2.2400000095367432e+00
    phi[1,2]  R1066     -2.2400000095367432e+00
    phi[1,2]  R1067     -3.0999999046325684e+00
    phi[1,2]  R1068     -3.0999999046325684e+00
    phi[1,2]  R1069     -2.5699999332427979e+00
    phi[1,2]  R1070     -2.5699999332427979e+00
    phi[1,2]  R1071     -3.0999999046325684e+00
    phi[1,2]  R1072     -3.0999999046325684e+00
    phi[1,2]  R1073     -2.0899999141693115e+00
    phi[1,2]  R1074     -2.0899999141693115e+00
    phi[1,2]  R1075     -3.0999999046325684e+00
    phi[1,2]  R1076     -3.0999999046325684e+00
    phi[1,2]  R1077     1.3277325630187988e+00
    phi[1,2]  R1078     3.3390073776245117e+00
    phi[1,2]  R1079     2.8899092674255371e+00
    phi[1,2]  R1080     2.2295787334442139e+00
    phi[1,2]  R1081     2.0320281982421875e+00
    phi[1,2]  R1082     3.4186420440673828e+00
    phi[1,2]  R1083     2.0607035160064697e+00
    phi[1,2]  R1084     1.2651383876800537e+00
    phi[1,2]  R1085     1.29560387134552
    phi[1,2]  R1086     1.3987675905227661e+00
    phi[1,2]  R1087     -2.0207924842834473e+00
    phi[1,2]  R1088     -1.1800280809402466e+00
    phi[1,2]  R1089     -3.4738163948059082e+00
    phi[1,2]  R1090     -5.8964967727661133e-01
    phi[1,2]  R1091     -2.1053321361541748e+00
    phi[1,2]  R1092     -2.8847529888153076e+00
    phi[1,2]  R1093     -1.7543654441833496e+00
    phi[1,2]  R1094     -1.5343227982521057e-01
    phi[1,2]  R1095     -2.2961275577545166e+00
    phi[1,2]  R1096     -4.1192550659179688e+00
    phi[1,2]  R1097     -1.8347289562225342e+00
    phi[1,2]  R1098     -3.6431140899658203e+00
    phi[1,2]  R1099     -1.1444900035858154e+00
    phi[1,2]  R1100     -2.1215839385986328e+00
    phi[1,2]  R1101     1.3022191822528839e-01
    phi[1,2]  R1102     -1.5792474746704102e+00
    phi[1,2]  R1103     -3.1061894893646240e+00
    phi[1,2]  R1104     -5.5709940195083618e-01
    phi[1,2]  R1105     -4.9677640199661255e-01
    phi[1,2]  R1106     -1.5125824213027954e+00
    phi[1,2]  R1107     -2.8717732429504395e-01
    phi[1,2]  R1108     -2.3300900459289551e+00
    phi[1,2]  R1109     -1.9852199554443359e+00
    phi[1,2]  R1110     -2.3390786647796631e+00
    phi[1,2]  R1111     -5.2185070514678955e-01
    phi[1,2]  R1112     5.6234854459762573e-01
    phi[1,2]  R1113     -3.3225684165954590e+00
    phi[1,2]  R1114     -3.3181829452514648e+00
    phi[1,2]  R1115     -7.7915674448013306e-01
    phi[1,2]  R1116     5.5050069093704224e-01
    phi[1,2]  R1117     -1.0409848764538765e-02
    phi[1,2]  R1118     -2.3876395225524902e+00
    phi[1,2]  R1119     1.0809738636016846e+00
    phi[1,2]  R1120     -1.0619608312845230e-01
    phi[1,2]  R1121     -3.4079229831695557e+00
    phi[1,2]  R1122     -1.9636331796646118e+00
    phi[1,2]  R1123     -1.5169124305248260e-01
    phi[1,2]  R1124     -1.1527181863784790e+00
    phi[1,2]  R1125     -3.8200814723968506e+00
    phi[1,2]  R1126     1.9556609392166138e+00
    phi[1,2]  R1127     -1.6384848356246948e+00
    phi[1,2]  R1128     0.0775298997759819
    phi[1,2]  R1129     -2.69022798538208
    phi[1,2]  R1130     -6.3064539432525635e-01
    phi[1,2]  R1131     -3.8050425052642822e+00
    phi[1,2]  R1132     -2.0436257123947144e-01
    phi[1,2]  R1133     3.3565545082092285e-01
    phi[1,2]  R1134     1.8710997104644775e+00
    phi[1,2]  R1135     -5.3445369005203247e-01
    phi[1,2]  R1136     -3.9159832000732422e+00
    phi[1,2]  R1137     8.3469939231872559e-01
    phi[1,2]  R1138     -1.1574065685272217e+00
    phi[1,2]  R1139     -4.6086430549621582e+00
    phi[1,2]  R1140     1.9872316718101501e-01
    phi[1,2]  R1141     1.1579774618148804e+00
    phi[1,2]  R1142     -0.199266254901886
    phi[1,2]  R1143     -0.546949028968811
    phi[1,2]  R1144     7.5467109680175781e-01
    phi[1,2]  R1145     -1.2149610519409180e+00
    phi[1,2]  R1146     -1.7360685765743256e-01
    phi[1,2]  R1147     2.6246626377105713e+00
    phi[1,2]  R1148     3.1527636051177979e+00
    phi[1,2]  R1149     3.8595871925354004e+00
    phi[1,2]  R1150     3.0660238265991211e+00
    phi[1,2]  R1151     2.9737465381622314e+00
    phi[1,2]  R1152     2.4852428436279297e+00
    phi[1,2]  R1153     2.0612566471099854e+00
    phi[1,2]  R1154     2.4804785251617432e+00
    phi[1,2]  R1155     2.5087289810180664e+00
    phi[1,2]  R1156     -6.4332711696624756e-01
    phi[1,2]  R1157     -2.6867237091064453e+00
    phi[1,2]  R1158     -2.93402099609375
    phi[1,2]  R1159     -2.6068620681762695e+00
    phi[1,2]  R1160     -3.5787482261657715e+00
    phi[1,2]  R1161     -4.3233928680419922e+00
    phi[1,2]  R1162     -3.8236644268035889e+00
    phi[1,2]  R1163     -2.7094883918762207e+00
    phi[1,2]  R1164     -2.1869969367980957e+00
    phi[1,2]  R1165     -1.7537761926651
    phi[1,2]  R1166     -2.2096116542816162e+00
    phi[1,2]  R1167     -5.6705784797668457e-01
    phi[1,2]  R1168     9.3583784997463226e-02
    phi[1,2]  R1169     8.0489623546600342e-01
    phi[1,2]  R1170     0.745187520980835
    phi[1,2]  R1171     -2.7750933170318604e+00
    phi[1,2]  R1172     -0.694452702999115
    phi[1,2]  R1173     -1.7952477931976318e+00
    phi[1,2]  R1174     1.0682137310504913e-01
    phi[1,2]  R1175     2.2315252572298050e-02
    phi[1,2]  R1176     -1.7015128135681152e+00
    phi[1,2]  R1177     -2.6784806251525879e+00
    phi[1,2]  R1178     -0.701325535774231
    phi[1,2]  R1179     -1.0478279590606689e+00
    phi[1,2]  R1180     -3.5581524372100830e+00
    phi[1,2]  R1181     -3.3381526470184326e+00
    phi[1,2]  R1182     -1.4295353889465332e+00
    phi[1,2]  R1183     -1.1413087844848633e+00
    phi[1,2]  R1184     -2.4510116577148438e+00
    phi[1,2]  R1185     -1.0093451738357544e+00
    phi[1,2]  R1186     -3.3345932960510254e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R1187     -3.0999999046325684e+00
    phi[2,1]  R1188     -3.0999999046325684e+00
    phi[2,1]  R1189     -2.2400000095367432e+00
    phi[2,1]  R1190     -2.2400000095367432e+00
    phi[2,1]  R1191     -3.0999999046325684e+00
    phi[2,1]  R1192     -3.0999999046325684e+00
    phi[2,1]  R1193     -2.5699999332427979e+00
    phi[2,1]  R1194     -2.5699999332427979e+00
    phi[2,1]  R1195     -3.0999999046325684e+00
    phi[2,1]  R1196     -3.0999999046325684e+00
    phi[2,1]  R1197     -2.0899999141693115e+00
    phi[2,1]  R1198     -2.0899999141693115e+00
    phi[2,1]  R1199     -3.0999999046325684e+00
    phi[2,1]  R1200     -3.0999999046325684e+00
    phi[2,1]  R1201     2.6246626377105713e+00
    phi[2,1]  R1202     3.1527636051177979e+00
    phi[2,1]  R1203     3.8595871925354004e+00
    phi[2,1]  R1204     3.0660238265991211e+00
    phi[2,1]  R1205     2.9737465381622314e+00
    phi[2,1]  R1206     2.4852428436279297e+00
    phi[2,1]  R1207     2.0612566471099854e+00
    phi[2,1]  R1208     2.4804785251617432e+00
    phi[2,1]  R1209     2.5087289810180664e+00
    phi[2,1]  R1210     -6.4332711696624756e-01
    phi[2,1]  R1211     -2.6867237091064453e+00
    phi[2,1]  R1212     -2.93402099609375
    phi[2,1]  R1213     -2.6068620681762695e+00
    phi[2,1]  R1214     -3.5787482261657715e+00
    phi[2,1]  R1215     -4.3233928680419922e+00
    phi[2,1]  R1216     -3.8236644268035889e+00
    phi[2,1]  R1217     -2.7094883918762207e+00
    phi[2,1]  R1218     -2.1869969367980957e+00
    phi[2,1]  R1219     -1.7537761926651
    phi[2,1]  R1220     -2.2096116542816162e+00
    phi[2,1]  R1221     -5.6705784797668457e-01
    phi[2,1]  R1222     9.3583784997463226e-02
    phi[2,1]  R1223     8.0489623546600342e-01
    phi[2,1]  R1224     0.745187520980835
    phi[2,1]  R1225     -2.7750933170318604e+00
    phi[2,1]  R1226     -0.694452702999115
    phi[2,1]  R1227     -1.7952477931976318e+00
    phi[2,1]  R1228     1.0682137310504913e-01
    phi[2,1]  R1229     2.2315252572298050e-02
    phi[2,1]  R1230     -1.7015128135681152e+00
    phi[2,1]  R1231     -2.6784806251525879e+00
    phi[2,1]  R1232     -0.701325535774231
    phi[2,1]  R1233     -1.0478279590606689e+00
    phi[2,1]  R1234     -3.5581524372100830e+00
    phi[2,1]  R1235     -3.3381526470184326e+00
    phi[2,1]  R1236     -1.4295353889465332e+00
    phi[2,1]  R1237     -1.1413087844848633e+00
    phi[2,1]  R1238     -2.4510116577148438e+00
    phi[2,1]  R1239     -1.0093451738357544e+00
    phi[2,1]  R1240     -3.3345932960510254e+00
    phi[2,1]  R1241     1.3277325630187988e+00
    phi[2,1]  R1242     3.3390073776245117e+00
    phi[2,1]  R1243     2.8899092674255371e+00
    phi[2,1]  R1244     2.2295787334442139e+00
    phi[2,1]  R1245     2.0320281982421875e+00
    phi[2,1]  R1246     3.4186420440673828e+00
    phi[2,1]  R1247     2.0607035160064697e+00
    phi[2,1]  R1248     1.2651383876800537e+00
    phi[2,1]  R1249     1.29560387134552
    phi[2,1]  R1250     1.3987675905227661e+00
    phi[2,1]  R1251     -2.0207924842834473e+00
    phi[2,1]  R1252     -1.1800280809402466e+00
    phi[2,1]  R1253     -3.4738163948059082e+00
    phi[2,1]  R1254     -5.8964967727661133e-01
    phi[2,1]  R1255     -2.1053321361541748e+00
    phi[2,1]  R1256     -2.8847529888153076e+00
    phi[2,1]  R1257     -1.7543654441833496e+00
    phi[2,1]  R1258     -1.5343227982521057e-01
    phi[2,1]  R1259     -2.2961275577545166e+00
    phi[2,1]  R1260     -4.1192550659179688e+00
    phi[2,1]  R1261     -1.8347289562225342e+00
    phi[2,1]  R1262     -3.6431140899658203e+00
    phi[2,1]  R1263     -1.1444900035858154e+00
    phi[2,1]  R1264     -2.1215839385986328e+00
    phi[2,1]  R1265     1.3022191822528839e-01
    phi[2,1]  R1266     -1.5792474746704102e+00
    phi[2,1]  R1267     -3.1061894893646240e+00
    phi[2,1]  R1268     -5.5709940195083618e-01
    phi[2,1]  R1269     -4.9677640199661255e-01
    phi[2,1]  R1270     -1.5125824213027954e+00
    phi[2,1]  R1271     -2.8717732429504395e-01
    phi[2,1]  R1272     -2.3300900459289551e+00
    phi[2,1]  R1273     -1.9852199554443359e+00
    phi[2,1]  R1274     -2.3390786647796631e+00
    phi[2,1]  R1275     -5.2185070514678955e-01
    phi[2,1]  R1276     5.6234854459762573e-01
    phi[2,1]  R1277     -3.3225684165954590e+00
    phi[2,1]  R1278     -3.3181829452514648e+00
    phi[2,1]  R1279     -7.7915674448013306e-01
    phi[2,1]  R1280     5.5050069093704224e-01
    phi[2,1]  R1281     -1.0409848764538765e-02
    phi[2,1]  R1282     -2.3876395225524902e+00
    phi[2,1]  R1283     1.0809738636016846e+00
    phi[2,1]  R1284     -1.0619608312845230e-01
    phi[2,1]  R1285     -3.4079229831695557e+00
    phi[2,1]  R1286     -1.9636331796646118e+00
    phi[2,1]  R1287     -1.5169124305248260e-01
    phi[2,1]  R1288     -1.1527181863784790e+00
    phi[2,1]  R1289     -3.8200814723968506e+00
    phi[2,1]  R1290     1.9556609392166138e+00
    phi[2,1]  R1291     -1.6384848356246948e+00
    phi[2,1]  R1292     0.0775298997759819
    phi[2,1]  R1293     -2.69022798538208
    phi[2,1]  R1294     -6.3064539432525635e-01
    phi[2,1]  R1295     -3.8050425052642822e+00
    phi[2,1]  R1296     -2.0436257123947144e-01
    phi[2,1]  R1297     3.3565545082092285e-01
    phi[2,1]  R1298     1.8710997104644775e+00
    phi[2,1]  R1299     -5.3445369005203247e-01
    phi[2,1]  R1300     -3.9159832000732422e+00
    phi[2,1]  R1301     8.3469939231872559e-01
    phi[2,1]  R1302     -1.1574065685272217e+00
    phi[2,1]  R1303     -4.6086430549621582e+00
    phi[2,1]  R1304     1.9872316718101501e-01
    phi[2,1]  R1305     1.1579774618148804e+00
    phi[2,1]  R1306     -0.199266254901886
    phi[2,1]  R1307     -0.546949028968811
    phi[2,1]  R1308     7.5467109680175781e-01
    phi[2,1]  R1309     -1.2149610519409180e+00
    phi[2,1]  R1310     -1.7360685765743256e-01
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R1311     -3.0999999046325684e+00
    phi[1,3]  R1312     -3.0999999046325684e+00
    phi[1,3]  R1313     -2.2400000095367432e+00
    phi[1,3]  R1314     -2.2400000095367432e+00
    phi[1,3]  R1315     -3.0999999046325684e+00
    phi[1,3]  R1316     -3.0999999046325684e+00
    phi[1,3]  R1317     -2.5699999332427979e+00
    phi[1,3]  R1318     -2.5699999332427979e+00
    phi[1,3]  R1319     -3.0999999046325684e+00
    phi[1,3]  R1320     -3.0999999046325684e+00
    phi[1,3]  R1321     -2.0899999141693115e+00
    phi[1,3]  R1322     -2.0899999141693115e+00
    phi[1,3]  R1323     -3.0999999046325684e+00
    phi[1,3]  R1324     -3.0999999046325684e+00
    phi[1,3]  R1325     1.3277325630187988e+00
    phi[1,3]  R1326     3.3390073776245117e+00
    phi[1,3]  R1327     2.8899092674255371e+00
    phi[1,3]  R1328     2.2295787334442139e+00
    phi[1,3]  R1329     2.0320281982421875e+00
    phi[1,3]  R1330     3.4186420440673828e+00
    phi[1,3]  R1331     2.0607035160064697e+00
    phi[1,3]  R1332     1.2651383876800537e+00
    phi[1,3]  R1333     1.29560387134552
    phi[1,3]  R1334     1.3987675905227661e+00
    phi[1,3]  R1335     -2.0207924842834473e+00
    phi[1,3]  R1336     -1.1800280809402466e+00
    phi[1,3]  R1337     -3.4738163948059082e+00
    phi[1,3]  R1338     -5.8964967727661133e-01
    phi[1,3]  R1339     -2.1053321361541748e+00
    phi[1,3]  R1340     -2.8847529888153076e+00
    phi[1,3]  R1341     -1.7543654441833496e+00
    phi[1,3]  R1342     -1.5343227982521057e-01
    phi[1,3]  R1343     -2.2961275577545166e+00
    phi[1,3]  R1344     -4.1192550659179688e+00
    phi[1,3]  R1345     -1.8347289562225342e+00
    phi[1,3]  R1346     -3.6431140899658203e+00
    phi[1,3]  R1347     -1.1444900035858154e+00
    phi[1,3]  R1348     -2.1215839385986328e+00
    phi[1,3]  R1349     1.3022191822528839e-01
    phi[1,3]  R1350     -1.5792474746704102e+00
    phi[1,3]  R1351     -3.1061894893646240e+00
    phi[1,3]  R1352     -5.5709940195083618e-01
    phi[1,3]  R1353     -4.9677640199661255e-01
    phi[1,3]  R1354     -1.5125824213027954e+00
    phi[1,3]  R1355     -2.8717732429504395e-01
    phi[1,3]  R1356     -2.3300900459289551e+00
    phi[1,3]  R1357     -1.9852199554443359e+00
    phi[1,3]  R1358     -2.3390786647796631e+00
    phi[1,3]  R1359     -5.2185070514678955e-01
    phi[1,3]  R1360     5.6234854459762573e-01
    phi[1,3]  R1361     -3.3225684165954590e+00
    phi[1,3]  R1362     -3.3181829452514648e+00
    phi[1,3]  R1363     -7.7915674448013306e-01
    phi[1,3]  R1364     5.5050069093704224e-01
    phi[1,3]  R1365     -1.0409848764538765e-02
    phi[1,3]  R1366     -2.3876395225524902e+00
    phi[1,3]  R1367     1.0809738636016846e+00
    phi[1,3]  R1368     -1.0619608312845230e-01
    phi[1,3]  R1369     -3.4079229831695557e+00
    phi[1,3]  R1370     -1.9636331796646118e+00
    phi[1,3]  R1371     -1.5169124305248260e-01
    phi[1,3]  R1372     -1.1527181863784790e+00
    phi[1,3]  R1373     -3.8200814723968506e+00
    phi[1,3]  R1374     1.9556609392166138e+00
    phi[1,3]  R1375     -1.6384848356246948e+00
    phi[1,3]  R1376     0.0775298997759819
    phi[1,3]  R1377     -2.69022798538208
    phi[1,3]  R1378     -6.3064539432525635e-01
    phi[1,3]  R1379     -3.8050425052642822e+00
    phi[1,3]  R1380     -2.0436257123947144e-01
    phi[1,3]  R1381     3.3565545082092285e-01
    phi[1,3]  R1382     1.8710997104644775e+00
    phi[1,3]  R1383     -5.3445369005203247e-01
    phi[1,3]  R1384     -3.9159832000732422e+00
    phi[1,3]  R1385     8.3469939231872559e-01
    phi[1,3]  R1386     -1.1574065685272217e+00
    phi[1,3]  R1387     -4.6086430549621582e+00
    phi[1,3]  R1388     1.9872316718101501e-01
    phi[1,3]  R1389     1.1579774618148804e+00
    phi[1,3]  R1390     -0.199266254901886
    phi[1,3]  R1391     -0.546949028968811
    phi[1,3]  R1392     7.5467109680175781e-01
    phi[1,3]  R1393     -1.2149610519409180e+00
    phi[1,3]  R1394     -1.7360685765743256e-01
    phi[1,3]  R1395     4.5096531510353088e-02
    phi[1,3]  R1396     1.8677181005477905e+00
    phi[1,3]  R1397     3.4945321083068848e-01
    phi[1,3]  R1398     9.7148710489273071e-01
    phi[1,3]  R1399     2.2512047290802
    phi[1,3]  R1400     1.1111259460449219e+00
    phi[1,3]  R1401     -1.3897062540054321e+00
    phi[1,3]  R1402     -8.5215216875076294e-01
    phi[1,3]  R1403     2.5951156616210938e+00
    phi[1,3]  R1404     4.5361062884330750e-01
    phi[1,3]  R1405     -3.4487705230712891e+00
    phi[1,3]  R1406     1.1418876796960831e-01
    phi[1,3]  R1407     -6.1531984806060791e-01
    phi[1,3]  R1408     7.0120233297348022e-01
    phi[1,3]  R1409     -6.5589410066604614e-01
    phi[1,3]  R1410     -2.0468633174896240e+00
    phi[1,3]  R1411     -2.5278043746948242e+00
    phi[1,3]  R1412     -1.1658314466476440e+00
    phi[1,3]  R1413     -1.4226363897323608e+00
    phi[1,3]  R1414     -1.8599766492843628e+00
    phi[1,3]  R1415     -4.6490821242332458e-01
    phi[1,3]  R1416     -2.2472314834594727e+00
    phi[1,3]  R1417     -4.3628865480422974e-01
    phi[1,3]  R1418     -8.1092137098312378e-01
    phi[1,3]  R1419     8.8767188787460327e-01
    phi[1,3]  R1420     -6.6583949327468872e-01
    phi[1,3]  R1421     -6.6912615299224854e-01
    phi[1,3]  R1422     3.2262913882732391e-02
    phi[1,3]  R1423     -1.6698111593723297e-01
    phi[1,3]  R1424     -1.4931937456130981e+00
    phi[1,3]  R1425     -5.3503584861755371e-01
    phi[1,3]  R1426     -1.8259797990322113e-01
    phi[1,3]  R1427     -0.234147846698761
    phi[1,3]  R1428     -1.4616293907165527e+00
    phi[1,3]  R1429     1.7572814226150513e-01
    phi[1,3]  R1430     2.9534992575645447e-01
    phi[1,3]  R1431     7.2278702259063721e-01
    phi[1,3]  R1432     -6.7692697048187256e-01
    phi[1,3]  R1433     -2.4364208802580833e-02
    phi[1,3]  R1434     -1.8344134092330933e+00
    phi[1,3]  R1435     6.5171188116073608e-01
    phi[1,3]  R1436     5.0714202225208282e-02
    phi[1,3]  R1437     -0.765410840511322
    phi[1,3]  R1438     -0.573043704032898
    phi[1,3]  R1439     -0.0806007832288742
    phi[1,3]  R1440     7.3962211608886719e-01
    phi[1,3]  R1441     9.2908978462219238e-02
    phi[1,3]  R1442     -2.5569078922271729e+00
    phi[1,3]  R1443     -0.0906447172164917
    phi[1,3]  R1444     -0.861920952796936
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R1445     -3.0999999046325684e+00
    phi[3,1]  R1446     -3.0999999046325684e+00
    phi[3,1]  R1447     -2.2400000095367432e+00
    phi[3,1]  R1448     -2.2400000095367432e+00
    phi[3,1]  R1449     -3.0999999046325684e+00
    phi[3,1]  R1450     -3.0999999046325684e+00
    phi[3,1]  R1451     -2.5699999332427979e+00
    phi[3,1]  R1452     -2.5699999332427979e+00
    phi[3,1]  R1453     -3.0999999046325684e+00
    phi[3,1]  R1454     -3.0999999046325684e+00
    phi[3,1]  R1455     -2.0899999141693115e+00
    phi[3,1]  R1456     -2.0899999141693115e+00
    phi[3,1]  R1457     -3.0999999046325684e+00
    phi[3,1]  R1458     -3.0999999046325684e+00
    phi[3,1]  R1459     4.5096531510353088e-02
    phi[3,1]  R1460     1.8677181005477905e+00
    phi[3,1]  R1461     3.4945321083068848e-01
    phi[3,1]  R1462     9.7148710489273071e-01
    phi[3,1]  R1463     2.2512047290802
    phi[3,1]  R1464     1.1111259460449219e+00
    phi[3,1]  R1465     -1.3897062540054321e+00
    phi[3,1]  R1466     -8.5215216875076294e-01
    phi[3,1]  R1467     2.5951156616210938e+00
    phi[3,1]  R1468     4.5361062884330750e-01
    phi[3,1]  R1469     -3.4487705230712891e+00
    phi[3,1]  R1470     1.1418876796960831e-01
    phi[3,1]  R1471     -6.1531984806060791e-01
    phi[3,1]  R1472     7.0120233297348022e-01
    phi[3,1]  R1473     -6.5589410066604614e-01
    phi[3,1]  R1474     -2.0468633174896240e+00
    phi[3,1]  R1475     -2.5278043746948242e+00
    phi[3,1]  R1476     -1.1658314466476440e+00
    phi[3,1]  R1477     -1.4226363897323608e+00
    phi[3,1]  R1478     -1.8599766492843628e+00
    phi[3,1]  R1479     -4.6490821242332458e-01
    phi[3,1]  R1480     -2.2472314834594727e+00
    phi[3,1]  R1481     -4.3628865480422974e-01
    phi[3,1]  R1482     -8.1092137098312378e-01
    phi[3,1]  R1483     8.8767188787460327e-01
    phi[3,1]  R1484     -6.6583949327468872e-01
    phi[3,1]  R1485     -6.6912615299224854e-01
    phi[3,1]  R1486     3.2262913882732391e-02
    phi[3,1]  R1487     -1.6698111593723297e-01
    phi[3,1]  R1488     -1.4931937456130981e+00
    phi[3,1]  R1489     -5.3503584861755371e-01
    phi[3,1]  R1490     -1.8259797990322113e-01
    phi[3,1]  R1491     -0.234147846698761
    phi[3,1]  R1492     -1.4616293907165527e+00
    phi[3,1]  R1493     1.7572814226150513e-01
    phi[3,1]  R1494     2.9534992575645447e-01
    phi[3,1]  R1495     7.2278702259063721e-01
    phi[3,1]  R1496     -6.7692697048187256e-01
    phi[3,1]  R1497     -2.4364208802580833e-02
    phi[3,1]  R1498     -1.8344134092330933e+00
    phi[3,1]  R1499     6.5171188116073608e-01
    phi[3,1]  R1500     5.0714202225208282e-02
    phi[3,1]  R1501     -0.765410840511322
    phi[3,1]  R1502     -0.573043704032898
    phi[3,1]  R1503     -0.0806007832288742
    phi[3,1]  R1504     7.3962211608886719e-01
    phi[3,1]  R1505     9.2908978462219238e-02
    phi[3,1]  R1506     -2.5569078922271729e+00
    phi[3,1]  R1507     -0.0906447172164917
    phi[3,1]  R1508     -0.861920952796936
    phi[3,1]  R1509     1.3277325630187988e+00
    phi[3,1]  R1510     3.3390073776245117e+00
    phi[3,1]  R1511     2.8899092674255371e+00
    phi[3,1]  R1512     2.2295787334442139e+00
    phi[3,1]  R1513     2.0320281982421875e+00
    phi[3,1]  R1514     3.4186420440673828e+00
    phi[3,1]  R1515     2.0607035160064697e+00
    phi[3,1]  R1516     1.2651383876800537e+00
    phi[3,1]  R1517     1.29560387134552
    phi[3,1]  R1518     1.3987675905227661e+00
    phi[3,1]  R1519     -2.0207924842834473e+00
    phi[3,1]  R1520     -1.1800280809402466e+00
    phi[3,1]  R1521     -3.4738163948059082e+00
    phi[3,1]  R1522     -5.8964967727661133e-01
    phi[3,1]  R1523     -2.1053321361541748e+00
    phi[3,1]  R1524     -2.8847529888153076e+00
    phi[3,1]  R1525     -1.7543654441833496e+00
    phi[3,1]  R1526     -1.5343227982521057e-01
    phi[3,1]  R1527     -2.2961275577545166e+00
    phi[3,1]  R1528     -4.1192550659179688e+00
    phi[3,1]  R1529     -1.8347289562225342e+00
    phi[3,1]  R1530     -3.6431140899658203e+00
    phi[3,1]  R1531     -1.1444900035858154e+00
    phi[3,1]  R1532     -2.1215839385986328e+00
    phi[3,1]  R1533     1.3022191822528839e-01
    phi[3,1]  R1534     -1.5792474746704102e+00
    phi[3,1]  R1535     -3.1061894893646240e+00
    phi[3,1]  R1536     -5.5709940195083618e-01
    phi[3,1]  R1537     -4.9677640199661255e-01
    phi[3,1]  R1538     -1.5125824213027954e+00
    phi[3,1]  R1539     -2.8717732429504395e-01
    phi[3,1]  R1540     -2.3300900459289551e+00
    phi[3,1]  R1541     -1.9852199554443359e+00
    phi[3,1]  R1542     -2.3390786647796631e+00
    phi[3,1]  R1543     -5.2185070514678955e-01
    phi[3,1]  R1544     5.6234854459762573e-01
    phi[3,1]  R1545     -3.3225684165954590e+00
    phi[3,1]  R1546     -3.3181829452514648e+00
    phi[3,1]  R1547     -7.7915674448013306e-01
    phi[3,1]  R1548     5.5050069093704224e-01
    phi[3,1]  R1549     -1.0409848764538765e-02
    phi[3,1]  R1550     -2.3876395225524902e+00
    phi[3,1]  R1551     1.0809738636016846e+00
    phi[3,1]  R1552     -1.0619608312845230e-01
    phi[3,1]  R1553     -3.4079229831695557e+00
    phi[3,1]  R1554     -1.9636331796646118e+00
    phi[3,1]  R1555     -1.5169124305248260e-01
    phi[3,1]  R1556     -1.1527181863784790e+00
    phi[3,1]  R1557     -3.8200814723968506e+00
    phi[3,1]  R1558     1.9556609392166138e+00
    phi[3,1]  R1559     -1.6384848356246948e+00
    phi[3,1]  R1560     0.0775298997759819
    phi[3,1]  R1561     -2.69022798538208
    phi[3,1]  R1562     -6.3064539432525635e-01
    phi[3,1]  R1563     -3.8050425052642822e+00
    phi[3,1]  R1564     -2.0436257123947144e-01
    phi[3,1]  R1565     3.3565545082092285e-01
    phi[3,1]  R1566     1.8710997104644775e+00
    phi[3,1]  R1567     -5.3445369005203247e-01
    phi[3,1]  R1568     -3.9159832000732422e+00
    phi[3,1]  R1569     8.3469939231872559e-01
    phi[3,1]  R1570     -1.1574065685272217e+00
    phi[3,1]  R1571     -4.6086430549621582e+00
    phi[3,1]  R1572     1.9872316718101501e-01
    phi[3,1]  R1573     1.1579774618148804e+00
    phi[3,1]  R1574     -0.199266254901886
    phi[3,1]  R1575     -0.546949028968811
    phi[3,1]  R1576     7.5467109680175781e-01
    phi[3,1]  R1577     -1.2149610519409180e+00
    phi[3,1]  R1578     -1.7360685765743256e-01
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1579     -3.0999999046325684e+00
    phi[2,5]  R1580     -3.0999999046325684e+00
    phi[2,5]  R1581     -2.2400000095367432e+00
    phi[2,5]  R1582     -2.2400000095367432e+00
    phi[2,5]  R1583     -3.0999999046325684e+00
    phi[2,5]  R1584     -3.0999999046325684e+00
    phi[2,5]  R1585     -2.5699999332427979e+00
    phi[2,5]  R1586     -2.5699999332427979e+00
    phi[2,5]  R1587     -3.0999999046325684e+00
    phi[2,5]  R1588     -3.0999999046325684e+00
    phi[2,5]  R1589     -2.0899999141693115e+00
    phi[2,5]  R1590     -2.0899999141693115e+00
    phi[2,5]  R1591     -3.0999999046325684e+00
    phi[2,5]  R1592     -3.0999999046325684e+00
    phi[2,5]  R1593     2.6246626377105713e+00
    phi[2,5]  R1594     3.1527636051177979e+00
    phi[2,5]  R1595     3.8595871925354004e+00
    phi[2,5]  R1596     3.0660238265991211e+00
    phi[2,5]  R1597     2.9737465381622314e+00
    phi[2,5]  R1598     2.4852428436279297e+00
    phi[2,5]  R1599     2.0612566471099854e+00
    phi[2,5]  R1600     2.4804785251617432e+00
    phi[2,5]  R1601     2.5087289810180664e+00
    phi[2,5]  R1602     -6.4332711696624756e-01
    phi[2,5]  R1603     -2.6867237091064453e+00
    phi[2,5]  R1604     -2.93402099609375
    phi[2,5]  R1605     -2.6068620681762695e+00
    phi[2,5]  R1606     -3.5787482261657715e+00
    phi[2,5]  R1607     -4.3233928680419922e+00
    phi[2,5]  R1608     -3.8236644268035889e+00
    phi[2,5]  R1609     -2.7094883918762207e+00
    phi[2,5]  R1610     -2.1869969367980957e+00
    phi[2,5]  R1611     -1.7537761926651
    phi[2,5]  R1612     -2.2096116542816162e+00
    phi[2,5]  R1613     -5.6705784797668457e-01
    phi[2,5]  R1614     9.3583784997463226e-02
    phi[2,5]  R1615     8.0489623546600342e-01
    phi[2,5]  R1616     0.745187520980835
    phi[2,5]  R1617     -2.7750933170318604e+00
    phi[2,5]  R1618     -0.694452702999115
    phi[2,5]  R1619     -1.7952477931976318e+00
    phi[2,5]  R1620     1.0682137310504913e-01
    phi[2,5]  R1621     2.2315252572298050e-02
    phi[2,5]  R1622     -1.7015128135681152e+00
    phi[2,5]  R1623     -2.6784806251525879e+00
    phi[2,5]  R1624     -0.701325535774231
    phi[2,5]  R1625     -1.0478279590606689e+00
    phi[2,5]  R1626     -3.5581524372100830e+00
    phi[2,5]  R1627     -3.3381526470184326e+00
    phi[2,5]  R1628     -1.4295353889465332e+00
    phi[2,5]  R1629     -1.1413087844848633e+00
    phi[2,5]  R1630     -2.4510116577148438e+00
    phi[2,5]  R1631     -1.0093451738357544e+00
    phi[2,5]  R1632     -3.3345932960510254e+00
    phi[2,5]  R1633     1.4189051389694214e+00
    phi[2,5]  R1634     3.9445755481719971e+00
    phi[2,5]  R1635     2.8365285396575928e+00
    phi[2,5]  R1636     3.6204102039337158e+00
    phi[2,5]  R1637     -2.19073486328125
    phi[2,5]  R1638     -2.2446866035461426e+00
    phi[2,5]  R1639     -2.91790771484375
    phi[2,5]  R1640     -3.1762020587921143e+00
    phi[2,5]  R1641     -1.8193070888519287e+00
    phi[2,5]  R1642     -2.4082798957824707e+00
    phi[2,5]  R1643     -3.8682923316955566e+00
    phi[2,5]  R1644     -2.1126642227172852e+00
    phi[2,5]  R1645     -4.1215796470642090e+00
    phi[2,5]  R1646     -4.1172499656677246e+00
    phi[2,5]  R1647     -4.4133996963500977e-01
    phi[2,5]  R1648     -7.5416171550750732e-01
    phi[2,5]  R1649     -2.2141072750091553e+00
    phi[2,5]  R1650     -1.9028098583221436e+00
    phi[2,5]  R1651     -2.0899143218994141e+00
    phi[2,5]  R1652     -1.7430822849273682e+00
    phi[2,5]  R1653     -2.1898012161254883e+00
    phi[2,5]  R1654     -8.3410292863845825e-01
    phi[2,5]  R1655     -1.3922462463378906e+00
    phi[2,5]  R1656     -1.9488507509231567e+00
    phi[2,5]  R1657     -2.9138496518135071e-01
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1658     -3.0999999046325684e+00
    phi[5,2]  R1659     -3.0999999046325684e+00
    phi[5,2]  R1660     -2.2400000095367432e+00
    phi[5,2]  R1661     -2.2400000095367432e+00
    phi[5,2]  R1662     -3.0999999046325684e+00
    phi[5,2]  R1663     -3.0999999046325684e+00
    phi[5,2]  R1664     -2.5699999332427979e+00
    phi[5,2]  R1665     -2.5699999332427979e+00
    phi[5,2]  R1666     -3.0999999046325684e+00
    phi[5,2]  R1667     -3.0999999046325684e+00
    phi[5,2]  R1668     -2.0899999141693115e+00
    phi[5,2]  R1669     -2.0899999141693115e+00
    phi[5,2]  R1670     -3.0999999046325684e+00
    phi[5,2]  R1671     -3.0999999046325684e+00
    phi[5,2]  R1672     1.4189051389694214e+00
    phi[5,2]  R1673     3.9445755481719971e+00
    phi[5,2]  R1674     2.8365285396575928e+00
    phi[5,2]  R1675     3.6204102039337158e+00
    phi[5,2]  R1676     -2.19073486328125
    phi[5,2]  R1677     -2.2446866035461426e+00
    phi[5,2]  R1678     -2.91790771484375
    phi[5,2]  R1679     -3.1762020587921143e+00
    phi[5,2]  R1680     -1.8193070888519287e+00
    phi[5,2]  R1681     -2.4082798957824707e+00
    phi[5,2]  R1682     -3.8682923316955566e+00
    phi[5,2]  R1683     -2.1126642227172852e+00
    phi[5,2]  R1684     -4.1215796470642090e+00
    phi[5,2]  R1685     -4.1172499656677246e+00
    phi[5,2]  R1686     -4.4133996963500977e-01
    phi[5,2]  R1687     -7.5416171550750732e-01
    phi[5,2]  R1688     -2.2141072750091553e+00
    phi[5,2]  R1689     -1.9028098583221436e+00
    phi[5,2]  R1690     -2.0899143218994141e+00
    phi[5,2]  R1691     -1.7430822849273682e+00
    phi[5,2]  R1692     -2.1898012161254883e+00
    phi[5,2]  R1693     -8.3410292863845825e-01
    phi[5,2]  R1694     -1.3922462463378906e+00
    phi[5,2]  R1695     -1.9488507509231567e+00
    phi[5,2]  R1696     -2.9138496518135071e-01
    phi[5,2]  R1697     2.6246626377105713e+00
    phi[5,2]  R1698     3.1527636051177979e+00
    phi[5,2]  R1699     3.8595871925354004e+00
    phi[5,2]  R1700     3.0660238265991211e+00
    phi[5,2]  R1701     2.9737465381622314e+00
    phi[5,2]  R1702     2.4852428436279297e+00
    phi[5,2]  R1703     2.0612566471099854e+00
    phi[5,2]  R1704     2.4804785251617432e+00
    phi[5,2]  R1705     2.5087289810180664e+00
    phi[5,2]  R1706     -6.4332711696624756e-01
    phi[5,2]  R1707     -2.6867237091064453e+00
    phi[5,2]  R1708     -2.93402099609375
    phi[5,2]  R1709     -2.6068620681762695e+00
    phi[5,2]  R1710     -3.5787482261657715e+00
    phi[5,2]  R1711     -4.3233928680419922e+00
    phi[5,2]  R1712     -3.8236644268035889e+00
    phi[5,2]  R1713     -2.7094883918762207e+00
    phi[5,2]  R1714     -2.1869969367980957e+00
    phi[5,2]  R1715     -1.7537761926651
    phi[5,2]  R1716     -2.2096116542816162e+00
    phi[5,2]  R1717     -5.6705784797668457e-01
    phi[5,2]  R1718     9.3583784997463226e-02
    phi[5,2]  R1719     8.0489623546600342e-01
    phi[5,2]  R1720     0.745187520980835
    phi[5,2]  R1721     -2.7750933170318604e+00
    phi[5,2]  R1722     -0.694452702999115
    phi[5,2]  R1723     -1.7952477931976318e+00
    phi[5,2]  R1724     1.0682137310504913e-01
    phi[5,2]  R1725     2.2315252572298050e-02
    phi[5,2]  R1726     -1.7015128135681152e+00
    phi[5,2]  R1727     -2.6784806251525879e+00
    phi[5,2]  R1728     -0.701325535774231
    phi[5,2]  R1729     -1.0478279590606689e+00
    phi[5,2]  R1730     -3.5581524372100830e+00
    phi[5,2]  R1731     -3.3381526470184326e+00
    phi[5,2]  R1732     -1.4295353889465332e+00
    phi[5,2]  R1733     -1.1413087844848633e+00
    phi[5,2]  R1734     -2.4510116577148438e+00
    phi[5,2]  R1735     -1.0093451738357544e+00
    phi[5,2]  R1736     -3.3345932960510254e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1737     -3.0999999046325684e+00
    phi[2,6]  R1738     -3.0999999046325684e+00
    phi[2,6]  R1739     -2.2400000095367432e+00
    phi[2,6]  R1740     -2.2400000095367432e+00
    phi[2,6]  R1741     -3.0999999046325684e+00
    phi[2,6]  R1742     -3.0999999046325684e+00
    phi[2,6]  R1743     -2.5699999332427979e+00
    phi[2,6]  R1744     -2.5699999332427979e+00
    phi[2,6]  R1745     -3.0999999046325684e+00
    phi[2,6]  R1746     -3.0999999046325684e+00
    phi[2,6]  R1747     -2.0899999141693115e+00
    phi[2,6]  R1748     -2.0899999141693115e+00
    phi[2,6]  R1749     -3.0999999046325684e+00
    phi[2,6]  R1750     -3.0999999046325684e+00
    phi[2,6]  R1751     2.6246626377105713e+00
    phi[2,6]  R1752     3.1527636051177979e+00
    phi[2,6]  R1753     3.8595871925354004e+00
    phi[2,6]  R1754     3.0660238265991211e+00
    phi[2,6]  R1755     2.9737465381622314e+00
    phi[2,6]  R1756     2.4852428436279297e+00
    phi[2,6]  R1757     2.0612566471099854e+00
    phi[2,6]  R1758     2.4804785251617432e+00
    phi[2,6]  R1759     2.5087289810180664e+00
    phi[2,6]  R1760     -6.4332711696624756e-01
    phi[2,6]  R1761     -2.6867237091064453e+00
    phi[2,6]  R1762     -2.93402099609375
    phi[2,6]  R1763     -2.6068620681762695e+00
    phi[2,6]  R1764     -3.5787482261657715e+00
    phi[2,6]  R1765     -4.3233928680419922e+00
    phi[2,6]  R1766     -3.8236644268035889e+00
    phi[2,6]  R1767     -2.7094883918762207e+00
    phi[2,6]  R1768     -2.1869969367980957e+00
    phi[2,6]  R1769     -1.7537761926651
    phi[2,6]  R1770     -2.2096116542816162e+00
    phi[2,6]  R1771     -5.6705784797668457e-01
    phi[2,6]  R1772     9.3583784997463226e-02
    phi[2,6]  R1773     8.0489623546600342e-01
    phi[2,6]  R1774     0.745187520980835
    phi[2,6]  R1775     -2.7750933170318604e+00
    phi[2,6]  R1776     -0.694452702999115
    phi[2,6]  R1777     -1.7952477931976318e+00
    phi[2,6]  R1778     1.0682137310504913e-01
    phi[2,6]  R1779     2.2315252572298050e-02
    phi[2,6]  R1780     -1.7015128135681152e+00
    phi[2,6]  R1781     -2.6784806251525879e+00
    phi[2,6]  R1782     -0.701325535774231
    phi[2,6]  R1783     -1.0478279590606689e+00
    phi[2,6]  R1784     -3.5581524372100830e+00
    phi[2,6]  R1785     -3.3381526470184326e+00
    phi[2,6]  R1786     -1.4295353889465332e+00
    phi[2,6]  R1787     -1.1413087844848633e+00
    phi[2,6]  R1788     -2.4510116577148438e+00
    phi[2,6]  R1789     -1.0093451738357544e+00
    phi[2,6]  R1790     -3.3345932960510254e+00
    phi[2,6]  R1791     3.5343639850616455e+00
    phi[2,6]  R1792     3.2941327095031738e+00
    phi[2,6]  R1793     3.0066702365875244e+00
    phi[2,6]  R1794     1.3093345165252686e+00
    phi[2,6]  R1795     2.3188581466674805e+00
    phi[2,6]  R1796     2.5762231349945068e+00
    phi[2,6]  R1797     2.3789484500885010e+00
    phi[2,6]  R1798     4.0879559516906738e+00
    phi[2,6]  R1799     2.3514370918273926e+00
    phi[2,6]  R1800     0.832746684551239
    phi[2,6]  R1801     -2.6024842262268066e+00
    phi[2,6]  R1802     -2.3817086219787598e+00
    phi[2,6]  R1803     -2.6484797000885010e+00
    phi[2,6]  R1804     -2.7309966087341309e+00
    phi[2,6]  R1805     -1.4153331518173218e+00
    phi[2,6]  R1806     -3.9732394218444824e+00
    phi[2,6]  R1807     -3.0281052589416504e+00
    phi[2,6]  R1808     -3.2247850894927979e+00
    phi[2,6]  R1809     -4.8637989163398743e-01
    phi[2,6]  R1810     -4.3644208908081055e+00
    phi[2,6]  R1811     -8.2288718223571777e-01
    phi[2,6]  R1812     -3.4920200705528259e-02
    phi[2,6]  R1813     -3.1131780147552490e+00
    phi[2,6]  R1814     -1.5280317068099976e+00
    phi[2,6]  R1815     -1.0375083684921265e+00
    phi[2,6]  R1816     -8.8133639097213745e-01
    phi[2,6]  R1817     -1.5728323459625244e+00
    phi[2,6]  R1818     -4.5054227113723755e-01
    phi[2,6]  R1819     -1.7405079603195190e+00
    phi[2,6]  R1820     -3.2489511966705322e+00
    phi[2,6]  R1821     -1.9763885736465454e+00
    phi[2,6]  R1822     -1.3485018014907837e+00
    phi[2,6]  R1823     -2.6503975391387939e+00
    phi[2,6]  R1824     -2.2997202873229980e+00
    phi[2,6]  R1825     -3.05000638961792
    phi[2,6]  R1826     -3.5043540000915527e+00
    phi[2,6]  R1827     -3.3591065406799316e+00
    phi[2,6]  R1828     -2.3096714019775391e+00
    phi[2,6]  R1829     -2.0122547149658203e+00
    phi[2,6]  R1830     -2.1330206096172333e-01
    phi[2,6]  R1831     -3.2298605442047119e+00
    phi[2,6]  R1832     -3.0341475009918213e+00
    phi[2,6]  R1833     -2.1640899181365967e+00
    phi[2,6]  R1834     -3.8075904846191406e+00
    phi[2,6]  R1835     -3.1625540256500244e+00
    phi[2,6]  R1836     1.4084311723709106e+00
    phi[2,6]  R1837     -2.8674678802490234e+00
    phi[2,6]  R1838     -4.3117985725402832e+00
    phi[2,6]  R1839     -2.0439332723617554e-01
    phi[2,6]  R1840     -2.4868423938751221e+00
    phi[2,6]  R1841     -1.0813635587692261e+00
    phi[2,6]  R1842     -1.2819588184356689e+00
    phi[2,6]  R1843     -1.8470998108386993e-01
    phi[2,6]  R1844     -3.1211864948272705e+00
    phi[2,6]  R1845     -3.7686600685119629e+00
    phi[2,6]  R1846     -3.1866943836212158e-01
    phi[2,6]  R1847     1.3974586725234985e+00
    phi[2,6]  R1848     -1.4782835245132446e+00
    phi[2,6]  R1849     -8.2344424724578857e-01
    phi[2,6]  R1850     2.4011172354221344e-01
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1851     -3.0999999046325684e+00
    phi[6,2]  R1852     -3.0999999046325684e+00
    phi[6,2]  R1853     -2.2400000095367432e+00
    phi[6,2]  R1854     -2.2400000095367432e+00
    phi[6,2]  R1855     -3.0999999046325684e+00
    phi[6,2]  R1856     -3.0999999046325684e+00
    phi[6,2]  R1857     -2.5699999332427979e+00
    phi[6,2]  R1858     -2.5699999332427979e+00
    phi[6,2]  R1859     -3.0999999046325684e+00
    phi[6,2]  R1860     -3.0999999046325684e+00
    phi[6,2]  R1861     -2.0899999141693115e+00
    phi[6,2]  R1862     -2.0899999141693115e+00
    phi[6,2]  R1863     -3.0999999046325684e+00
    phi[6,2]  R1864     -3.0999999046325684e+00
    phi[6,2]  R1865     3.5343639850616455e+00
    phi[6,2]  R1866     3.2941327095031738e+00
    phi[6,2]  R1867     3.0066702365875244e+00
    phi[6,2]  R1868     1.3093345165252686e+00
    phi[6,2]  R1869     2.3188581466674805e+00
    phi[6,2]  R1870     2.5762231349945068e+00
    phi[6,2]  R1871     2.3789484500885010e+00
    phi[6,2]  R1872     4.0879559516906738e+00
    phi[6,2]  R1873     2.3514370918273926e+00
    phi[6,2]  R1874     0.832746684551239
    phi[6,2]  R1875     -2.6024842262268066e+00
    phi[6,2]  R1876     -2.3817086219787598e+00
    phi[6,2]  R1877     -2.6484797000885010e+00
    phi[6,2]  R1878     -2.7309966087341309e+00
    phi[6,2]  R1879     -1.4153331518173218e+00
    phi[6,2]  R1880     -3.9732394218444824e+00
    phi[6,2]  R1881     -3.0281052589416504e+00
    phi[6,2]  R1882     -3.2247850894927979e+00
    phi[6,2]  R1883     -4.8637989163398743e-01
    phi[6,2]  R1884     -4.3644208908081055e+00
    phi[6,2]  R1885     -8.2288718223571777e-01
    phi[6,2]  R1886     -3.4920200705528259e-02
    phi[6,2]  R1887     -3.1131780147552490e+00
    phi[6,2]  R1888     -1.5280317068099976e+00
    phi[6,2]  R1889     -1.0375083684921265e+00
    phi[6,2]  R1890     -8.8133639097213745e-01
    phi[6,2]  R1891     -1.5728323459625244e+00
    phi[6,2]  R1892     -4.5054227113723755e-01
    phi[6,2]  R1893     -1.7405079603195190e+00
    phi[6,2]  R1894     -3.2489511966705322e+00
    phi[6,2]  R1895     -1.9763885736465454e+00
    phi[6,2]  R1896     -1.3485018014907837e+00
    phi[6,2]  R1897     -2.6503975391387939e+00
    phi[6,2]  R1898     -2.2997202873229980e+00
    phi[6,2]  R1899     -3.05000638961792
    phi[6,2]  R1900     -3.5043540000915527e+00
    phi[6,2]  R1901     -3.3591065406799316e+00
    phi[6,2]  R1902     -2.3096714019775391e+00
    phi[6,2]  R1903     -2.0122547149658203e+00
    phi[6,2]  R1904     -2.1330206096172333e-01
    phi[6,2]  R1905     -3.2298605442047119e+00
    phi[6,2]  R1906     -3.0341475009918213e+00
    phi[6,2]  R1907     -2.1640899181365967e+00
    phi[6,2]  R1908     -3.8075904846191406e+00
    phi[6,2]  R1909     -3.1625540256500244e+00
    phi[6,2]  R1910     1.4084311723709106e+00
    phi[6,2]  R1911     -2.8674678802490234e+00
    phi[6,2]  R1912     -4.3117985725402832e+00
    phi[6,2]  R1913     -2.0439332723617554e-01
    phi[6,2]  R1914     -2.4868423938751221e+00
    phi[6,2]  R1915     -1.0813635587692261e+00
    phi[6,2]  R1916     -1.2819588184356689e+00
    phi[6,2]  R1917     -1.8470998108386993e-01
    phi[6,2]  R1918     -3.1211864948272705e+00
    phi[6,2]  R1919     -3.7686600685119629e+00
    phi[6,2]  R1920     -3.1866943836212158e-01
    phi[6,2]  R1921     1.3974586725234985e+00
    phi[6,2]  R1922     -1.4782835245132446e+00
    phi[6,2]  R1923     -8.2344424724578857e-01
    phi[6,2]  R1924     2.4011172354221344e-01
    phi[6,2]  R1925     2.6246626377105713e+00
    phi[6,2]  R1926     3.1527636051177979e+00
    phi[6,2]  R1927     3.8595871925354004e+00
    phi[6,2]  R1928     3.0660238265991211e+00
    phi[6,2]  R1929     2.9737465381622314e+00
    phi[6,2]  R1930     2.4852428436279297e+00
    phi[6,2]  R1931     2.0612566471099854e+00
    phi[6,2]  R1932     2.4804785251617432e+00
    phi[6,2]  R1933     2.5087289810180664e+00
    phi[6,2]  R1934     -6.4332711696624756e-01
    phi[6,2]  R1935     -2.6867237091064453e+00
    phi[6,2]  R1936     -2.93402099609375
    phi[6,2]  R1937     -2.6068620681762695e+00
    phi[6,2]  R1938     -3.5787482261657715e+00
    phi[6,2]  R1939     -4.3233928680419922e+00
    phi[6,2]  R1940     -3.8236644268035889e+00
    phi[6,2]  R1941     -2.7094883918762207e+00
    phi[6,2]  R1942     -2.1869969367980957e+00
    phi[6,2]  R1943     -1.7537761926651
    phi[6,2]  R1944     -2.2096116542816162e+00
    phi[6,2]  R1945     -5.6705784797668457e-01
    phi[6,2]  R1946     9.3583784997463226e-02
    phi[6,2]  R1947     8.0489623546600342e-01
    phi[6,2]  R1948     0.745187520980835
    phi[6,2]  R1949     -2.7750933170318604e+00
    phi[6,2]  R1950     -0.694452702999115
    phi[6,2]  R1951     -1.7952477931976318e+00
    phi[6,2]  R1952     1.0682137310504913e-01
    phi[6,2]  R1953     2.2315252572298050e-02
    phi[6,2]  R1954     -1.7015128135681152e+00
    phi[6,2]  R1955     -2.6784806251525879e+00
    phi[6,2]  R1956     -0.701325535774231
    phi[6,2]  R1957     -1.0478279590606689e+00
    phi[6,2]  R1958     -3.5581524372100830e+00
    phi[6,2]  R1959     -3.3381526470184326e+00
    phi[6,2]  R1960     -1.4295353889465332e+00
    phi[6,2]  R1961     -1.1413087844848633e+00
    phi[6,2]  R1962     -2.4510116577148438e+00
    phi[6,2]  R1963     -1.0093451738357544e+00
    phi[6,2]  R1964     -3.3345932960510254e+00
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R20       2.7686700408154041e+00
    phi[2,8]  R21       -5.8900599568985657e-01
    phi[2,8]  R22       1.6662417654996211e+00
    phi[2,8]  R23       -1.7930979069363491e+00
    phi[2,8]  R24       -1.6115538461601626e+00
    phi[2,8]  R25       2.2484998932238498e-01
    phi[2,8]  R26       2.5318213350604610e+00
    phi[2,8]  R64       -1
    phi[2,8]  R1965     -3.3132986381716423e-01
    phi[2,8]  R1966     -5.8686699454479729e+00
    phi[2,8]  R1967     -2.8290060052265997e+00
    phi[2,8]  R1968     -1.6509940138468866e+00
    phi[2,8]  R1969     -1.4337581391329473e+00
    phi[2,8]  R1970     -4.76624167013219
    phi[2,8]  R1971     -4.3630978401791474e+00
    phi[2,8]  R1972     -7.7690202630644878e-01
    phi[2,8]  R1973     -4.7115537507927314e+00
    phi[2,8]  R1974     -1.4884460584724057e+00
    phi[2,8]  R1975     -1.8651499248469265e+00
    phi[2,8]  R1976     -2.3148499034916963e+00
    phi[2,8]  R1977     -5.6817856957210733e-01
    phi[2,8]  R1978     -5.6318212396930294e+00
    phi[2,8]  R1979     -1.4959062261115097e-01
    phi[2,8]  R1980     -1.4962228198695637e-01
    phi[2,8]  R1981     -1.5127360645512944e-01
    phi[2,8]  R1982     -1.5573340134805314e-01
    phi[2,8]  R1983     -1.5949638329058624e-01
    phi[2,8]  R1984     -1.6025512092659255e-01
    phi[2,8]  R1985     -1.6118598536316764e-01
    phi[2,8]  R1986     -1.6442109234641133e-01
    phi[2,8]  R1987     -1.7683759220342532e-01
    phi[2,8]  R1988     -5.7354842271579876e-01
    phi[2,8]  R1989     -3.3709082482773889e-01
    phi[2,8]  R1990     -3.4131018839608851e-01
    phi[2,8]  R1991     -3.4801536453529991e-01
    phi[2,8]  R1992     -3.5116441507819651e-01
    phi[2,8]  R1993     -3.5766189960075190e-01
    phi[2,8]  R1994     -3.6120378263955466e-01
    phi[2,8]  R1995     -3.6734068990156077e-01
    phi[2,8]  R1996     -3.7252159317709133e-01
    phi[2,8]  R1997     -0.389023007477435
    phi[2,8]  R1998     -3.9048868873402021e-01
    phi[2,8]  R1999     -4.2066591267071007e-01
    phi[2,8]  R2000     -0.461154895130662
    phi[2,8]  R2001     -4.7252268784274332e-01
    phi[2,8]  R2002     -5.1593824530968790e-01
    phi[2,8]  R2003     -5.4587566421120481e-01
    phi[2,8]  R2004     -6.1998138665619473e-01
    phi[2,8]  R2005     -1.2992011009897975e+00
    phi[2,8]  R2006     -2.0499576340122219e+00
    phi[2,8]  R2007     -1.7054765790302084e+00
    phi[2,8]  R2008     -7.3739901469664593e-01
    phi[2,8]  R2009     -3.4970880887458833e-01
    phi[2,8]  R2010     -3.5649025858884142e-01
    phi[2,8]  R2011     -3.9036457913639755e-01
    phi[2,8]  R2012     -6.1229533081686327e-01
    phi[2,8]  R2013     -6.9625654805647885e-01
    phi[2,8]  R2014     -1.6040657119225950e+00
    phi[2,8]  R2015     -7.9939489525194973e-01
    phi[2,8]  R2016     -8.3549525890857068e-01
    phi[2,8]  R2017     -8.5554576182544317e-01
    phi[2,8]  R2018     -8.7024013076077678e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2019     -3.0999999046325684e+00
    phi[3,4]  R2020     -3.0999999046325684e+00
    phi[3,4]  R2021     -2.2400000095367432e+00
    phi[3,4]  R2022     -2.2400000095367432e+00
    phi[3,4]  R2023     -3.0999999046325684e+00
    phi[3,4]  R2024     -3.0999999046325684e+00
    phi[3,4]  R2025     -2.5699999332427979e+00
    phi[3,4]  R2026     -2.5699999332427979e+00
    phi[3,4]  R2027     -3.0999999046325684e+00
    phi[3,4]  R2028     -3.0999999046325684e+00
    phi[3,4]  R2029     -2.0899999141693115e+00
    phi[3,4]  R2030     -2.0899999141693115e+00
    phi[3,4]  R2031     -3.0999999046325684e+00
    phi[3,4]  R2032     -3.0999999046325684e+00
    phi[3,4]  R2033     4.5096531510353088e-02
    phi[3,4]  R2034     1.8677181005477905e+00
    phi[3,4]  R2035     3.4945321083068848e-01
    phi[3,4]  R2036     9.7148710489273071e-01
    phi[3,4]  R2037     2.2512047290802
    phi[3,4]  R2038     1.1111259460449219e+00
    phi[3,4]  R2039     -1.3897062540054321e+00
    phi[3,4]  R2040     -8.5215216875076294e-01
    phi[3,4]  R2041     2.5951156616210938e+00
    phi[3,4]  R2042     4.5361062884330750e-01
    phi[3,4]  R2043     -3.4487705230712891e+00
    phi[3,4]  R2044     1.1418876796960831e-01
    phi[3,4]  R2045     -6.1531984806060791e-01
    phi[3,4]  R2046     7.0120233297348022e-01
    phi[3,4]  R2047     -6.5589410066604614e-01
    phi[3,4]  R2048     -2.0468633174896240e+00
    phi[3,4]  R2049     -2.5278043746948242e+00
    phi[3,4]  R2050     -1.1658314466476440e+00
    phi[3,4]  R2051     -1.4226363897323608e+00
    phi[3,4]  R2052     -1.8599766492843628e+00
    phi[3,4]  R2053     -4.6490821242332458e-01
    phi[3,4]  R2054     -2.2472314834594727e+00
    phi[3,4]  R2055     -4.3628865480422974e-01
    phi[3,4]  R2056     -8.1092137098312378e-01
    phi[3,4]  R2057     8.8767188787460327e-01
    phi[3,4]  R2058     -6.6583949327468872e-01
    phi[3,4]  R2059     -6.6912615299224854e-01
    phi[3,4]  R2060     3.2262913882732391e-02
    phi[3,4]  R2061     -1.6698111593723297e-01
    phi[3,4]  R2062     -1.4931937456130981e+00
    phi[3,4]  R2063     -5.3503584861755371e-01
    phi[3,4]  R2064     -1.8259797990322113e-01
    phi[3,4]  R2065     -0.234147846698761
    phi[3,4]  R2066     -1.4616293907165527e+00
    phi[3,4]  R2067     1.7572814226150513e-01
    phi[3,4]  R2068     2.9534992575645447e-01
    phi[3,4]  R2069     7.2278702259063721e-01
    phi[3,4]  R2070     -6.7692697048187256e-01
    phi[3,4]  R2071     -2.4364208802580833e-02
    phi[3,4]  R2072     -1.8344134092330933e+00
    phi[3,4]  R2073     6.5171188116073608e-01
    phi[3,4]  R2074     5.0714202225208282e-02
    phi[3,4]  R2075     -0.765410840511322
    phi[3,4]  R2076     -0.573043704032898
    phi[3,4]  R2077     -0.0806007832288742
    phi[3,4]  R2078     7.3962211608886719e-01
    phi[3,4]  R2079     9.2908978462219238e-02
    phi[3,4]  R2080     -2.5569078922271729e+00
    phi[3,4]  R2081     -0.0906447172164917
    phi[3,4]  R2082     -0.861920952796936
    phi[3,4]  R2083     1.9625407457351685e+00
    phi[3,4]  R2084     -1.1330999433994293e-02
    phi[3,4]  R2085     2.2506809234619141e+00
    phi[3,4]  R2086     1.4078931808471680e+00
    phi[3,4]  R2087     -1.5558645129203796e-01
    phi[3,4]  R2088     2.2328653335571289e+00
    phi[3,4]  R2089     -3.8762614727020264e+00
    phi[3,4]  R2090     -2.4869353771209717e+00
    phi[3,4]  R2091     -3.4038228988647461e+00
    phi[3,4]  R2092     -2.5603609085083008e+00
    phi[3,4]  R2093     -2.3685986995697021e+00
    phi[3,4]  R2094     0.773317277431488
    phi[3,4]  R2095     1.5606095790863037e+00
    phi[3,4]  R2096     -3.2540032267570496e-01
    phi[3,4]  R2097     4.0054696798324585e-01
    phi[3,4]  R2098     -1.9057852029800415e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2099     -3.0999999046325684e+00
    phi[4,3]  R2100     -3.0999999046325684e+00
    phi[4,3]  R2101     -2.2400000095367432e+00
    phi[4,3]  R2102     -2.2400000095367432e+00
    phi[4,3]  R2103     -3.0999999046325684e+00
    phi[4,3]  R2104     -3.0999999046325684e+00
    phi[4,3]  R2105     -2.5699999332427979e+00
    phi[4,3]  R2106     -2.5699999332427979e+00
    phi[4,3]  R2107     -3.0999999046325684e+00
    phi[4,3]  R2108     -3.0999999046325684e+00
    phi[4,3]  R2109     -2.0899999141693115e+00
    phi[4,3]  R2110     -2.0899999141693115e+00
    phi[4,3]  R2111     -3.0999999046325684e+00
    phi[4,3]  R2112     -3.0999999046325684e+00
    phi[4,3]  R2113     1.9625407457351685e+00
    phi[4,3]  R2114     -1.1330999433994293e-02
    phi[4,3]  R2115     2.2506809234619141e+00
    phi[4,3]  R2116     1.4078931808471680e+00
    phi[4,3]  R2117     -1.5558645129203796e-01
    phi[4,3]  R2118     2.2328653335571289e+00
    phi[4,3]  R2119     -3.8762614727020264e+00
    phi[4,3]  R2120     -2.4869353771209717e+00
    phi[4,3]  R2121     -3.4038228988647461e+00
    phi[4,3]  R2122     -2.5603609085083008e+00
    phi[4,3]  R2123     -2.3685986995697021e+00
    phi[4,3]  R2124     0.773317277431488
    phi[4,3]  R2125     1.5606095790863037e+00
    phi[4,3]  R2126     -3.2540032267570496e-01
    phi[4,3]  R2127     4.0054696798324585e-01
    phi[4,3]  R2128     -1.9057852029800415e-01
    phi[4,3]  R2129     4.5096531510353088e-02
    phi[4,3]  R2130     1.8677181005477905e+00
    phi[4,3]  R2131     3.4945321083068848e-01
    phi[4,3]  R2132     9.7148710489273071e-01
    phi[4,3]  R2133     2.2512047290802
    phi[4,3]  R2134     1.1111259460449219e+00
    phi[4,3]  R2135     -1.3897062540054321e+00
    phi[4,3]  R2136     -8.5215216875076294e-01
    phi[4,3]  R2137     2.5951156616210938e+00
    phi[4,3]  R2138     4.5361062884330750e-01
    phi[4,3]  R2139     -3.4487705230712891e+00
    phi[4,3]  R2140     1.1418876796960831e-01
    phi[4,3]  R2141     -6.1531984806060791e-01
    phi[4,3]  R2142     7.0120233297348022e-01
    phi[4,3]  R2143     -6.5589410066604614e-01
    phi[4,3]  R2144     -2.0468633174896240e+00
    phi[4,3]  R2145     -2.5278043746948242e+00
    phi[4,3]  R2146     -1.1658314466476440e+00
    phi[4,3]  R2147     -1.4226363897323608e+00
    phi[4,3]  R2148     -1.8599766492843628e+00
    phi[4,3]  R2149     -4.6490821242332458e-01
    phi[4,3]  R2150     -2.2472314834594727e+00
    phi[4,3]  R2151     -4.3628865480422974e-01
    phi[4,3]  R2152     -8.1092137098312378e-01
    phi[4,3]  R2153     8.8767188787460327e-01
    phi[4,3]  R2154     -6.6583949327468872e-01
    phi[4,3]  R2155     -6.6912615299224854e-01
    phi[4,3]  R2156     3.2262913882732391e-02
    phi[4,3]  R2157     -1.6698111593723297e-01
    phi[4,3]  R2158     -1.4931937456130981e+00
    phi[4,3]  R2159     -5.3503584861755371e-01
    phi[4,3]  R2160     -1.8259797990322113e-01
    phi[4,3]  R2161     -0.234147846698761
    phi[4,3]  R2162     -1.4616293907165527e+00
    phi[4,3]  R2163     1.7572814226150513e-01
    phi[4,3]  R2164     2.9534992575645447e-01
    phi[4,3]  R2165     7.2278702259063721e-01
    phi[4,3]  R2166     -6.7692697048187256e-01
    phi[4,3]  R2167     -2.4364208802580833e-02
    phi[4,3]  R2168     -1.8344134092330933e+00
    phi[4,3]  R2169     6.5171188116073608e-01
    phi[4,3]  R2170     5.0714202225208282e-02
    phi[4,3]  R2171     -0.765410840511322
    phi[4,3]  R2172     -0.573043704032898
    phi[4,3]  R2173     -0.0806007832288742
    phi[4,3]  R2174     7.3962211608886719e-01
    phi[4,3]  R2175     9.2908978462219238e-02
    phi[4,3]  R2176     -2.5569078922271729e+00
    phi[4,3]  R2177     -0.0906447172164917
    phi[4,3]  R2178     -0.861920952796936
    phi[7,3]  R27       -1
    phi[7,3]  R29       1.3560046325126947e+00
    phi[7,3]  R30       -3.1583362838780427e-01
    phi[7,3]  R31       -2.9307371201075378e+00
    phi[7,3]  R32       1.5433476436668268e+00
    phi[7,3]  R33       1.0607724734688744e+00
    phi[7,3]  R34       7.3495253474880862e-01
    phi[7,3]  R35       -2.9130789163512225e+00
    phi[7,3]  R63       1
    phi[7,3]  R2179     -4.4560045371452635e+00
    phi[7,3]  R2180     -1.7439952721198737e+00
    phi[7,3]  R2181     -1.9241663811489389e+00
    phi[7,3]  R2182     -2.5558336379245477e+00
    phi[7,3]  R2183     -1.6926278452503052e-01
    phi[7,3]  R2184     -6.0307370247401062e+00
    phi[7,3]  R2185     -4.1133475769096250e+00
    phi[7,3]  R2186     -1.0266522895759711e+00
    phi[7,3]  R2187     -4.1607723781014432e+00
    phi[7,3]  R2188     -2.0392274311636940e+00
    phi[7,3]  R2189     -2.82495244891812
    phi[7,3]  R2190     -1.3550473794205029e+00
    phi[7,3]  R2191     -1.8692098828134585e-01
    phi[7,3]  R2192     -6.0130788209837913e+00
    phi[7,3]  R2193     -4.7099303195195008e-01
    phi[7,3]  R2194     -6.7126492060216769e-01
    phi[7,3]  R2195     -5.8113031335960541e-01
    phi[7,3]  R2196     -5.5382675040637008e-01
    phi[7,3]  R2197     -5.5744071378151983e-01
    phi[7,3]  R2198     -6.0959822108646211e-01
    phi[7,3]  R2199     -6.5003880339423792e-01
    phi[7,3]  R2200     -7.6314192427935879e-01
    phi[7,3]  R2201     -7.8303896620524327e-01
    phi[7,3]  R2202     -8.9613490057075063e-01
    phi[7,3]  R2203     -4.0999408392433034e-01
    phi[7,3]  R2204     -0.517402068563977
    phi[7,3]  R2205     -5.5163183624433509e-01
    phi[7,3]  R2206     -1.1334796904935698e+00
    phi[7,3]  R2207     -6.1460993350706827e-01
    phi[7,3]  R2208     -6.1814980531024633e-01
    phi[7,3]  R2209     -6.2514564802251815e-01
    phi[7,3]  R2210     -6.4878542540925532e-01
    phi[7,3]  R2211     -6.6340732833611971e-01
    phi[7,3]  R2212     -6.6669409462963736e-01
    phi[7,3]  R2213     -6.0414145875895686e-01
    phi[7,3]  R2214     -6.1127708412625692e-01
    phi[7,3]  R2215     -6.1968206972873774e-01
    phi[7,3]  R2216     -6.6675636407436856e-01
    phi[7,3]  R2217     -6.7344131948988006e-01
    phi[7,3]  R2218     -6.7648719887826769e-01
    phi[7,3]  R2219     -7.0418258315251592e-01
    phi[7,3]  R2220     -7.1655557109003554e-01
    phi[7,3]  R2221     -7.1798904050610690e-01
    phi[7,3]  R2222     -8.0785248832815881e-01
    phi[7,3]  R2223     -5.0174252130414088e-01
    phi[7,3]  R2224     -5.3163259577260691e-01
    phi[7,3]  R2225     -5.5269435357516139e-01
    phi[7,3]  R2226     -6.9179096122351891e-01
    phi[7,3]  R2227     -7.9747025169615693e-01
    phi[7,3]  R2228     -8.7135714124200492e-01
    phi[7,3]  R2229     -8.7352447564690716e-01
    phi[7,3]  R2230     -9.1919216873573717e-01
    phi[7,3]  R2231     -9.3037184495185321e-01
    phi[7,3]  R2232     -9.8430909176071713e-01
    phi[7,3]  R2233     -0.424801296625857
    phi[7,3]  R2234     -5.2683489154228913e-01
    phi[7,3]  R2235     -6.3213658378525961e-01
    phi[7,3]  R2236     -6.6461132002695855e-01
    phi[7,3]  R2237     -6.9737658591686758e-01
    phi[7,3]  R2238     -7.0666759530951717e-01
    phi[7,3]  R2239     -7.5157905164855232e-01
    phi[7,3]  R2240     -8.9720053891004636e-01
    phi[7,3]  R2241     -1.0941534108968611e+00
    phi[7,3]  R2242     -1.1010898265381488e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2243     -3.0999999046325684e+00
    phi[4,5]  R2244     -3.0999999046325684e+00
    phi[4,5]  R2245     -2.2400000095367432e+00
    phi[4,5]  R2246     -2.2400000095367432e+00
    phi[4,5]  R2247     -3.0999999046325684e+00
    phi[4,5]  R2248     -3.0999999046325684e+00
    phi[4,5]  R2249     -2.5699999332427979e+00
    phi[4,5]  R2250     -2.5699999332427979e+00
    phi[4,5]  R2251     -3.0999999046325684e+00
    phi[4,5]  R2252     -3.0999999046325684e+00
    phi[4,5]  R2253     -2.0899999141693115e+00
    phi[4,5]  R2254     -2.0899999141693115e+00
    phi[4,5]  R2255     -3.0999999046325684e+00
    phi[4,5]  R2256     -3.0999999046325684e+00
    phi[4,5]  R2257     1.9625407457351685e+00
    phi[4,5]  R2258     -1.1330999433994293e-02
    phi[4,5]  R2259     2.2506809234619141e+00
    phi[4,5]  R2260     1.4078931808471680e+00
    phi[4,5]  R2261     -1.5558645129203796e-01
    phi[4,5]  R2262     2.2328653335571289e+00
    phi[4,5]  R2263     -3.8762614727020264e+00
    phi[4,5]  R2264     -2.4869353771209717e+00
    phi[4,5]  R2265     -3.4038228988647461e+00
    phi[4,5]  R2266     -2.5603609085083008e+00
    phi[4,5]  R2267     -2.3685986995697021e+00
    phi[4,5]  R2268     0.773317277431488
    phi[4,5]  R2269     1.5606095790863037e+00
    phi[4,5]  R2270     -3.2540032267570496e-01
    phi[4,5]  R2271     4.0054696798324585e-01
    phi[4,5]  R2272     -1.9057852029800415e-01
    phi[4,5]  R2273     1.4189051389694214e+00
    phi[4,5]  R2274     3.9445755481719971e+00
    phi[4,5]  R2275     2.8365285396575928e+00
    phi[4,5]  R2276     3.6204102039337158e+00
    phi[4,5]  R2277     -2.19073486328125
    phi[4,5]  R2278     -2.2446866035461426e+00
    phi[4,5]  R2279     -2.91790771484375
    phi[4,5]  R2280     -3.1762020587921143e+00
    phi[4,5]  R2281     -1.8193070888519287e+00
    phi[4,5]  R2282     -2.4082798957824707e+00
    phi[4,5]  R2283     -3.8682923316955566e+00
    phi[4,5]  R2284     -2.1126642227172852e+00
    phi[4,5]  R2285     -4.1215796470642090e+00
    phi[4,5]  R2286     -4.1172499656677246e+00
    phi[4,5]  R2287     -4.4133996963500977e-01
    phi[4,5]  R2288     -7.5416171550750732e-01
    phi[4,5]  R2289     -2.2141072750091553e+00
    phi[4,5]  R2290     -1.9028098583221436e+00
    phi[4,5]  R2291     -2.0899143218994141e+00
    phi[4,5]  R2292     -1.7430822849273682e+00
    phi[4,5]  R2293     -2.1898012161254883e+00
    phi[4,5]  R2294     -8.3410292863845825e-01
    phi[4,5]  R2295     -1.3922462463378906e+00
    phi[4,5]  R2296     -1.9488507509231567e+00
    phi[4,5]  R2297     -2.9138496518135071e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2298     -3.0999999046325684e+00
    phi[5,4]  R2299     -3.0999999046325684e+00
    phi[5,4]  R2300     -2.2400000095367432e+00
    phi[5,4]  R2301     -2.2400000095367432e+00
    phi[5,4]  R2302     -3.0999999046325684e+00
    phi[5,4]  R2303     -3.0999999046325684e+00
    phi[5,4]  R2304     -2.5699999332427979e+00
    phi[5,4]  R2305     -2.5699999332427979e+00
    phi[5,4]  R2306     -3.0999999046325684e+00
    phi[5,4]  R2307     -3.0999999046325684e+00
    phi[5,4]  R2308     -2.0899999141693115e+00
    phi[5,4]  R2309     -2.0899999141693115e+00
    phi[5,4]  R2310     -3.0999999046325684e+00
    phi[5,4]  R2311     -3.0999999046325684e+00
    phi[5,4]  R2312     1.4189051389694214e+00
    phi[5,4]  R2313     3.9445755481719971e+00
    phi[5,4]  R2314     2.8365285396575928e+00
    phi[5,4]  R2315     3.6204102039337158e+00
    phi[5,4]  R2316     -2.19073486328125
    phi[5,4]  R2317     -2.2446866035461426e+00
    phi[5,4]  R2318     -2.91790771484375
    phi[5,4]  R2319     -3.1762020587921143e+00
    phi[5,4]  R2320     -1.8193070888519287e+00
    phi[5,4]  R2321     -2.4082798957824707e+00
    phi[5,4]  R2322     -3.8682923316955566e+00
    phi[5,4]  R2323     -2.1126642227172852e+00
    phi[5,4]  R2324     -4.1215796470642090e+00
    phi[5,4]  R2325     -4.1172499656677246e+00
    phi[5,4]  R2326     -4.4133996963500977e-01
    phi[5,4]  R2327     -7.5416171550750732e-01
    phi[5,4]  R2328     -2.2141072750091553e+00
    phi[5,4]  R2329     -1.9028098583221436e+00
    phi[5,4]  R2330     -2.0899143218994141e+00
    phi[5,4]  R2331     -1.7430822849273682e+00
    phi[5,4]  R2332     -2.1898012161254883e+00
    phi[5,4]  R2333     -8.3410292863845825e-01
    phi[5,4]  R2334     -1.3922462463378906e+00
    phi[5,4]  R2335     -1.9488507509231567e+00
    phi[5,4]  R2336     -2.9138496518135071e-01
    phi[5,4]  R2337     1.9625407457351685e+00
    phi[5,4]  R2338     -1.1330999433994293e-02
    phi[5,4]  R2339     2.2506809234619141e+00
    phi[5,4]  R2340     1.4078931808471680e+00
    phi[5,4]  R2341     -1.5558645129203796e-01
    phi[5,4]  R2342     2.2328653335571289e+00
    phi[5,4]  R2343     -3.8762614727020264e+00
    phi[5,4]  R2344     -2.4869353771209717e+00
    phi[5,4]  R2345     -3.4038228988647461e+00
    phi[5,4]  R2346     -2.5603609085083008e+00
    phi[5,4]  R2347     -2.3685986995697021e+00
    phi[5,4]  R2348     0.773317277431488
    phi[5,4]  R2349     1.5606095790863037e+00
    phi[5,4]  R2350     -3.2540032267570496e-01
    phi[5,4]  R2351     4.0054696798324585e-01
    phi[5,4]  R2352     -1.9057852029800415e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2353     -3.0999999046325684e+00
    phi[5,6]  R2354     -3.0999999046325684e+00
    phi[5,6]  R2355     -2.2400000095367432e+00
    phi[5,6]  R2356     -2.2400000095367432e+00
    phi[5,6]  R2357     -3.0999999046325684e+00
    phi[5,6]  R2358     -3.0999999046325684e+00
    phi[5,6]  R2359     -2.5699999332427979e+00
    phi[5,6]  R2360     -2.5699999332427979e+00
    phi[5,6]  R2361     -3.0999999046325684e+00
    phi[5,6]  R2362     -3.0999999046325684e+00
    phi[5,6]  R2363     -2.0899999141693115e+00
    phi[5,6]  R2364     -2.0899999141693115e+00
    phi[5,6]  R2365     -3.0999999046325684e+00
    phi[5,6]  R2366     -3.0999999046325684e+00
    phi[5,6]  R2367     1.4189051389694214e+00
    phi[5,6]  R2368     3.9445755481719971e+00
    phi[5,6]  R2369     2.8365285396575928e+00
    phi[5,6]  R2370     3.6204102039337158e+00
    phi[5,6]  R2371     -2.19073486328125
    phi[5,6]  R2372     -2.2446866035461426e+00
    phi[5,6]  R2373     -2.91790771484375
    phi[5,6]  R2374     -3.1762020587921143e+00
    phi[5,6]  R2375     -1.8193070888519287e+00
    phi[5,6]  R2376     -2.4082798957824707e+00
    phi[5,6]  R2377     -3.8682923316955566e+00
    phi[5,6]  R2378     -2.1126642227172852e+00
    phi[5,6]  R2379     -4.1215796470642090e+00
    phi[5,6]  R2380     -4.1172499656677246e+00
    phi[5,6]  R2381     -4.4133996963500977e-01
    phi[5,6]  R2382     -7.5416171550750732e-01
    phi[5,6]  R2383     -2.2141072750091553e+00
    phi[5,6]  R2384     -1.9028098583221436e+00
    phi[5,6]  R2385     -2.0899143218994141e+00
    phi[5,6]  R2386     -1.7430822849273682e+00
    phi[5,6]  R2387     -2.1898012161254883e+00
    phi[5,6]  R2388     -8.3410292863845825e-01
    phi[5,6]  R2389     -1.3922462463378906e+00
    phi[5,6]  R2390     -1.9488507509231567e+00
    phi[5,6]  R2391     -2.9138496518135071e-01
    phi[5,6]  R2392     3.5343639850616455e+00
    phi[5,6]  R2393     3.2941327095031738e+00
    phi[5,6]  R2394     3.0066702365875244e+00
    phi[5,6]  R2395     1.3093345165252686e+00
    phi[5,6]  R2396     2.3188581466674805e+00
    phi[5,6]  R2397     2.5762231349945068e+00
    phi[5,6]  R2398     2.3789484500885010e+00
    phi[5,6]  R2399     4.0879559516906738e+00
    phi[5,6]  R2400     2.3514370918273926e+00
    phi[5,6]  R2401     0.832746684551239
    phi[5,6]  R2402     -2.6024842262268066e+00
    phi[5,6]  R2403     -2.3817086219787598e+00
    phi[5,6]  R2404     -2.6484797000885010e+00
    phi[5,6]  R2405     -2.7309966087341309e+00
    phi[5,6]  R2406     -1.4153331518173218e+00
    phi[5,6]  R2407     -3.9732394218444824e+00
    phi[5,6]  R2408     -3.0281052589416504e+00
    phi[5,6]  R2409     -3.2247850894927979e+00
    phi[5,6]  R2410     -4.8637989163398743e-01
    phi[5,6]  R2411     -4.3644208908081055e+00
    phi[5,6]  R2412     -8.2288718223571777e-01
    phi[5,6]  R2413     -3.4920200705528259e-02
    phi[5,6]  R2414     -3.1131780147552490e+00
    phi[5,6]  R2415     -1.5280317068099976e+00
    phi[5,6]  R2416     -1.0375083684921265e+00
    phi[5,6]  R2417     -8.8133639097213745e-01
    phi[5,6]  R2418     -1.5728323459625244e+00
    phi[5,6]  R2419     -4.5054227113723755e-01
    phi[5,6]  R2420     -1.7405079603195190e+00
    phi[5,6]  R2421     -3.2489511966705322e+00
    phi[5,6]  R2422     -1.9763885736465454e+00
    phi[5,6]  R2423     -1.3485018014907837e+00
    phi[5,6]  R2424     -2.6503975391387939e+00
    phi[5,6]  R2425     -2.2997202873229980e+00
    phi[5,6]  R2426     -3.05000638961792
    phi[5,6]  R2427     -3.5043540000915527e+00
    phi[5,6]  R2428     -3.3591065406799316e+00
    phi[5,6]  R2429     -2.3096714019775391e+00
    phi[5,6]  R2430     -2.0122547149658203e+00
    phi[5,6]  R2431     -2.1330206096172333e-01
    phi[5,6]  R2432     -3.2298605442047119e+00
    phi[5,6]  R2433     -3.0341475009918213e+00
    phi[5,6]  R2434     -2.1640899181365967e+00
    phi[5,6]  R2435     -3.8075904846191406e+00
    phi[5,6]  R2436     -3.1625540256500244e+00
    phi[5,6]  R2437     1.4084311723709106e+00
    phi[5,6]  R2438     -2.8674678802490234e+00
    phi[5,6]  R2439     -4.3117985725402832e+00
    phi[5,6]  R2440     -2.0439332723617554e-01
    phi[5,6]  R2441     -2.4868423938751221e+00
    phi[5,6]  R2442     -1.0813635587692261e+00
    phi[5,6]  R2443     -1.2819588184356689e+00
    phi[5,6]  R2444     -1.8470998108386993e-01
    phi[5,6]  R2445     -3.1211864948272705e+00
    phi[5,6]  R2446     -3.7686600685119629e+00
    phi[5,6]  R2447     -3.1866943836212158e-01
    phi[5,6]  R2448     1.3974586725234985e+00
    phi[5,6]  R2449     -1.4782835245132446e+00
    phi[5,6]  R2450     -8.2344424724578857e-01
    phi[5,6]  R2451     2.4011172354221344e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2452     -3.0999999046325684e+00
    phi[6,5]  R2453     -3.0999999046325684e+00
    phi[6,5]  R2454     -2.2400000095367432e+00
    phi[6,5]  R2455     -2.2400000095367432e+00
    phi[6,5]  R2456     -3.0999999046325684e+00
    phi[6,5]  R2457     -3.0999999046325684e+00
    phi[6,5]  R2458     -2.5699999332427979e+00
    phi[6,5]  R2459     -2.5699999332427979e+00
    phi[6,5]  R2460     -3.0999999046325684e+00
    phi[6,5]  R2461     -3.0999999046325684e+00
    phi[6,5]  R2462     -2.0899999141693115e+00
    phi[6,5]  R2463     -2.0899999141693115e+00
    phi[6,5]  R2464     -3.0999999046325684e+00
    phi[6,5]  R2465     -3.0999999046325684e+00
    phi[6,5]  R2466     3.5343639850616455e+00
    phi[6,5]  R2467     3.2941327095031738e+00
    phi[6,5]  R2468     3.0066702365875244e+00
    phi[6,5]  R2469     1.3093345165252686e+00
    phi[6,5]  R2470     2.3188581466674805e+00
    phi[6,5]  R2471     2.5762231349945068e+00
    phi[6,5]  R2472     2.3789484500885010e+00
    phi[6,5]  R2473     4.0879559516906738e+00
    phi[6,5]  R2474     2.3514370918273926e+00
    phi[6,5]  R2475     0.832746684551239
    phi[6,5]  R2476     -2.6024842262268066e+00
    phi[6,5]  R2477     -2.3817086219787598e+00
    phi[6,5]  R2478     -2.6484797000885010e+00
    phi[6,5]  R2479     -2.7309966087341309e+00
    phi[6,5]  R2480     -1.4153331518173218e+00
    phi[6,5]  R2481     -3.9732394218444824e+00
    phi[6,5]  R2482     -3.0281052589416504e+00
    phi[6,5]  R2483     -3.2247850894927979e+00
    phi[6,5]  R2484     -4.8637989163398743e-01
    phi[6,5]  R2485     -4.3644208908081055e+00
    phi[6,5]  R2486     -8.2288718223571777e-01
    phi[6,5]  R2487     -3.4920200705528259e-02
    phi[6,5]  R2488     -3.1131780147552490e+00
    phi[6,5]  R2489     -1.5280317068099976e+00
    phi[6,5]  R2490     -1.0375083684921265e+00
    phi[6,5]  R2491     -8.8133639097213745e-01
    phi[6,5]  R2492     -1.5728323459625244e+00
    phi[6,5]  R2493     -4.5054227113723755e-01
    phi[6,5]  R2494     -1.7405079603195190e+00
    phi[6,5]  R2495     -3.2489511966705322e+00
    phi[6,5]  R2496     -1.9763885736465454e+00
    phi[6,5]  R2497     -1.3485018014907837e+00
    phi[6,5]  R2498     -2.6503975391387939e+00
    phi[6,5]  R2499     -2.2997202873229980e+00
    phi[6,5]  R2500     -3.05000638961792
    phi[6,5]  R2501     -3.5043540000915527e+00
    phi[6,5]  R2502     -3.3591065406799316e+00
    phi[6,5]  R2503     -2.3096714019775391e+00
    phi[6,5]  R2504     -2.0122547149658203e+00
    phi[6,5]  R2505     -2.1330206096172333e-01
    phi[6,5]  R2506     -3.2298605442047119e+00
    phi[6,5]  R2507     -3.0341475009918213e+00
    phi[6,5]  R2508     -2.1640899181365967e+00
    phi[6,5]  R2509     -3.8075904846191406e+00
    phi[6,5]  R2510     -3.1625540256500244e+00
    phi[6,5]  R2511     1.4084311723709106e+00
    phi[6,5]  R2512     -2.8674678802490234e+00
    phi[6,5]  R2513     -4.3117985725402832e+00
    phi[6,5]  R2514     -2.0439332723617554e-01
    phi[6,5]  R2515     -2.4868423938751221e+00
    phi[6,5]  R2516     -1.0813635587692261e+00
    phi[6,5]  R2517     -1.2819588184356689e+00
    phi[6,5]  R2518     -1.8470998108386993e-01
    phi[6,5]  R2519     -3.1211864948272705e+00
    phi[6,5]  R2520     -3.7686600685119629e+00
    phi[6,5]  R2521     -3.1866943836212158e-01
    phi[6,5]  R2522     1.3974586725234985e+00
    phi[6,5]  R2523     -1.4782835245132446e+00
    phi[6,5]  R2524     -8.2344424724578857e-01
    phi[6,5]  R2525     2.4011172354221344e-01
    phi[6,5]  R2526     1.4189051389694214e+00
    phi[6,5]  R2527     3.9445755481719971e+00
    phi[6,5]  R2528     2.8365285396575928e+00
    phi[6,5]  R2529     3.6204102039337158e+00
    phi[6,5]  R2530     -2.19073486328125
    phi[6,5]  R2531     -2.2446866035461426e+00
    phi[6,5]  R2532     -2.91790771484375
    phi[6,5]  R2533     -3.1762020587921143e+00
    phi[6,5]  R2534     -1.8193070888519287e+00
    phi[6,5]  R2535     -2.4082798957824707e+00
    phi[6,5]  R2536     -3.8682923316955566e+00
    phi[6,5]  R2537     -2.1126642227172852e+00
    phi[6,5]  R2538     -4.1215796470642090e+00
    phi[6,5]  R2539     -4.1172499656677246e+00
    phi[6,5]  R2540     -4.4133996963500977e-01
    phi[6,5]  R2541     -7.5416171550750732e-01
    phi[6,5]  R2542     -2.2141072750091553e+00
    phi[6,5]  R2543     -1.9028098583221436e+00
    phi[6,5]  R2544     -2.0899143218994141e+00
    phi[6,5]  R2545     -1.7430822849273682e+00
    phi[6,5]  R2546     -2.1898012161254883e+00
    phi[6,5]  R2547     -8.3410292863845825e-01
    phi[6,5]  R2548     -1.3922462463378906e+00
    phi[6,5]  R2549     -1.9488507509231567e+00
    phi[6,5]  R2550     -2.9138496518135071e-01
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       2.7686700408154041e+00
    phi[6,8]  R57       -5.8900599568985657e-01
    phi[6,8]  R58       1.6662417654996211e+00
    phi[6,8]  R59       -1.7930979069363491e+00
    phi[6,8]  R60       -1.6115538461601626e+00
    phi[6,8]  R61       2.2484998932238498e-01
    phi[6,8]  R62       2.5318213350604610e+00
    phi[6,8]  R64       -1
    phi[6,8]  R2551     -3.3132986381716423e-01
    phi[6,8]  R2552     -5.8686699454479729e+00
    phi[6,8]  R2553     -2.8290060052265997e+00
    phi[6,8]  R2554     -1.6509940138468866e+00
    phi[6,8]  R2555     -1.4337581391329473e+00
    phi[6,8]  R2556     -4.76624167013219
    phi[6,8]  R2557     -4.3630978401791474e+00
    phi[6,8]  R2558     -7.7690202630644878e-01
    phi[6,8]  R2559     -4.7115537507927314e+00
    phi[6,8]  R2560     -1.4884460584724057e+00
    phi[6,8]  R2561     -1.8651499248469265e+00
    phi[6,8]  R2562     -2.3148499034916963e+00
    phi[6,8]  R2563     -5.6817856957210733e-01
    phi[6,8]  R2564     -5.6318212396930294e+00
    phi[6,8]  R2565     -1.4211663926306217e-01
    phi[6,8]  R2566     -1.4535997814699719e-01
    phi[6,8]  R2567     -1.6500528588550534e-01
    phi[6,8]  R2568     -1.6546340172102747e-01
    phi[6,8]  R2569     -1.6818448237178707e-01
    phi[6,8]  R2570     -1.7228569339243993e-01
    phi[6,8]  R2571     -1.7681898098149507e-01
    phi[6,8]  R2572     -1.7845883196213208e-01
    phi[6,8]  R2573     -1.9812198234286038e-01
    phi[6,8]  R2574     -2.0256298522041938e-01
    phi[6,8]  R2575     -4.0884801134383242e-01
    phi[6,8]  R2576     -4.2417872295534953e-01
    phi[6,8]  R2577     -4.2513519428931712e-01
    phi[6,8]  R2578     -4.3802963056391908e-01
    phi[6,8]  R2579     -4.4223660236087592e-01
    phi[6,8]  R2580     -4.4767883283263021e-01
    phi[6,8]  R2581     -4.4967254854305994e-01
    phi[6,8]  R2582     -4.5329930853451383e-01
    phi[6,8]  R2583     -4.5987023302623448e-01
    phi[6,8]  R2584     -4.6202865080869149e-01
    phi[6,8]  R2585     -4.0626510005900651e-01
    phi[6,8]  R2586     -7.6846933275968476e-01
    phi[6,8]  R2587     -4.8088807481706031e-01
    phi[6,8]  R2588     -5.1085759510079143e-01
    phi[6,8]  R2589     -1.3454750698155016e+00
    phi[6,8]  R2590     -1.1677753677527283e+00
    phi[6,8]  R2591     -9.8975812258807361e-01
    phi[6,8]  R2592     -1.0111227358374957e+00
    phi[6,8]  R2593     -1.2990463376752386e+00
    phi[6,8]  R2594     -1.02244081803435
    phi[6,8]  R2595     -1.4248552783408759e+00
    phi[6,8]  R2596     -3.3988501557633422e-01
    phi[6,8]  R2597     -3.9852814954857463e-01
    phi[6,8]  R2598     -4.0624275064652249e-01
    phi[6,8]  R2599     -4.1715089752054269e-01
    phi[6,8]  R2600     -7.6108992126648589e-01
    phi[6,8]  R2601     -4.7809682644246188e-01
    phi[6,8]  R2602     -9.7855051827156614e-01
    phi[6,8]  R2603     -1.2091870172824424e+00
    phi[6,8]  R2604     -5.7947835928804559e-01
    phi[6,8]  R2605     -3.4662143371255283e-01
    phi[6,8]  R2606     -1.0142654574729928e+00
    phi[6,8]  R2607     -4.2117373925890123e-01
    phi[6,8]  R2608     -1.1465843058280920e+00
    phi[6,8]  R2609     -4.2636544843106883e-01
    phi[6,8]  R2610     -7.8200613783348594e-01
    phi[6,8]  R2611     -4.5327938163801118e-01
    phi[6,8]  R2612     -4.5600991388188516e-01
    phi[6,8]  R2613     -4.7839607670308887e-01
    phi[6,8]  R2614     -4.8984340265728465e-01
    phi[6,8]  R2615     -2.6410403977882690e-01
    phi[6,8]  R2616     -3.6654973794202506e-01
    phi[6,8]  R2617     -3.7434194002731480e-01
    phi[6,8]  R2618     -4.0674013004737253e-01
    phi[6,8]  R2619     -4.2029370229414820e-01
    phi[6,8]  R2620     -1.4347561735303267e+00
    phi[6,8]  R2621     -4.7295306205128296e-01
    phi[6,8]  R2622     -1.0215774750321511e+00
    phi[6,8]  R2623     -5.5938176257894989e-01
    phi[6,8]  R2624     -5.6920881145577862e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       5.2258968353271484e-01
    z[0,1,0]  R80       2.7141281962394714e-01
    z[0,1,0]  R81       -5.9181714057922363e-01
    z[0,1,0]  R82       -5.4779791831970215e-01
    z[0,1,0]  R83       6.4446645975112915e-01
    z[0,1,0]  R84       2.4215668439865112e-01
    z[0,1,0]  R85       2.7344632148742676e-01
    z[0,1,0]  R86       -0.502898633480072
    z[0,1,0]  R87       -5.9624433517456055e-01
    z[0,1,0]  R88       -0.508691668510437
    z[0,1,0]  R89       -2.1039625629782677e-02
    z[0,1,0]  R90       -6.3955950736999512e-01
    z[0,1,0]  R91       3.8346239924430847e-01
    z[0,1,0]  R92       -5.8709084987640381e-01
    z[0,1,0]  R93       -5.7609003782272339e-01
    z[0,1,0]  R94       -1.5098403394222260e-01
    z[0,1,0]  R95       3.4997817873954773e-01
    z[0,1,0]  R96       1.9455881416797638e-01
    z[0,1,0]  R97       -1.0306473821401596e-01
    z[0,1,0]  R98       7.2607177495956421e-01
    z[0,1,0]  R99       3.5984647274017334e-01
    z[0,1,0]  R100      4.0053266286849976e-01
    z[0,1,0]  R101      2.8451833128929138e-01
    z[0,1,0]  R102      -4.9256992340087891e-01
    z[0,1,0]  R103      5.8289057016372681e-01
    z[0,1,0]  R104      3.2223412394523621e-01
    z[0,1,0]  R105      5.2027565240859985e-01
    z[0,1,0]  R106      8.9749681949615479e-01
    z[0,1,0]  R107      7.7735997736454010e-02
    z[0,1,0]  R108      4.8377230763435364e-01
    z[0,1,0]  R109      3.3621346950531006e-01
    z[0,1,0]  R110      4.4479519128799438e-01
    z[0,1,0]  R111      6.3285452127456665e-01
    z[0,1,0]  R112      2.5843468308448792e-01
    z[0,1,0]  R113      4.4759970158338547e-02
    z[0,1,0]  R114      1.8317356705665588e-01
    z[0,1,0]  R115      -1.5814730897545815e-02
    z[0,1,0]  R116      7.2875326871871948e-01
    z[0,1,0]  R117      1.0331102460622787e-01
    z[0,1,0]  R118      -4.7458952665328979e-01
    z[0,1,0]  R119      5.9786039590835571e-01
    z[0,1,0]  R120      2.3851300776004791e-01
    z[0,1,0]  R121      2.6434731483459473e-01
    z[0,1,0]  R122      7.2767162322998047e-01
    z[0,1,0]  R123      5.7752884924411774e-02
    z[0,1,0]  R124      -0.486916184425354
    z[0,1,0]  R125      4.2904263734817505e-01
    z[0,1,0]  R126      1.7858929932117462e-01
    z[0,1,0]  R127      -1.9521364942193031e-02
    z[0,1,0]  R128      2.5948521494865417e-01
    z[0,1,0]  R129      6.5763312578201294e-01
    z[0,1,0]  R130      3.5264107584953308e-01
    z[0,1,0]  R131      5.9940475225448608e-01
    z[0,1,0]  R132      0.693200409412384
    z[0,1,0]  R133      -5.1868766546249390e-01
    z[0,1,0]  R134      -5.5990439653396606e-01
    z[0,1,0]  R135      1.3997834920883179e-01
    z[0,1,0]  R136      -6.3276566565036774e-02
    z[0,1,0]  R137      0.837135374546051
    z[0,1,0]  R138      9.2894226312637329e-01
    z[0,1,0]  R139      -6.2266051769256592e-01
    z[0,1,0]  R140      7.6999038457870483e-01
    z[0,1,0]  R141      -4.2529711127281189e-01
    z[0,1,0]  R142      -5.8424901962280273e-01
    z[0,1,0]  R143      5.6201267242431641e-01
    z[0,1,0]  R144      -1.1042773723602295e-01
    z[0,1,0]  R145      2.5928720831871033e-01
    z[0,1,0]  R146      -3.6640220880508423e-01
    z[0,1,0]  R147      5.1088446378707886e-01
    z[0,1,0]  R148      5.1166445016860962e-01
    z[0,1,0]  R149      3.0087643861770630e-01
    z[0,1,0]  R150      -3.6423809826374054e-02
    z[0,1,0]  R151      6.0400050878524780e-01
    z[0,1,0]  R152      5.4995787143707275e-01
    z[0,1,0]  R153      4.2954602837562561e-01
    z[0,1,0]  R154      -4.6089485287666321e-01
    z[0,1,0]  R155      -1.0036650300025940e-01
    z[0,1,0]  R156      1.5186357498168945e-01
    z[0,1,0]  R157      1.5081593394279480e-01
    z[0,1,0]  R158      4.9989837408065796e-01
    z[0,1,0]  R159      2.5372245907783508e-01
    z[0,1,0]  R160      7.4551028013229370e-01
    z[0,1,0]  R161      1.8130171298980713e-01
    z[0,1,0]  R162      -5.2088344097137451e-01
    z[0,1,0]  R163      5.0005221366882324e-01
    z[0,1,0]  R164      0.537525475025177
    z[0,1,0]  R165      -0.516525387763977
    z[0,1,0]  R166      -2.1711751818656921e-01
    z[0,1,0]  R167      -6.7841041088104248e-01
    z[0,1,0]  R168      6.5063852071762085e-01
    z[0,1,0]  R169      -2.7622032165527344e-01
    z[0,1,0]  R170      7.2170570492744446e-02
    z[0,1,0]  R171      -2.1570110321044922e-01
    z[0,1,0]  R172      -1.9471928477287292e-01
    z[0,1,0]  R173      1.9177286326885223e-01
    z[0,1,0]  R174      -9.2172406613826752e-02
    z[0,1,0]  R175      -2.2240076959133148e-01
    z[0,1,0]  R176      -1.5014803968369961e-02
    z[0,1,0]  R177      7.7013963460922241e-01
    z[0,1,0]  R178      3.6218479275703430e-01
    z[0,1,0]  R179      -9.2576093971729279e-02
    z[0,1,0]  R180      -6.1049032211303711e-01
    z[0,1,0]  R181      2.5484472513198853e-01
    z[0,1,0]  R182      5.2137277089059353e-03
    z[0,1,0]  R183      -0.604136049747467
    z[0,1,0]  R184      -8.2193642854690552e-01
    z[0,1,0]  R185      0.663940966129303
    z[0,1,0]  R186      4.0393376350402832e-01
    z[0,1,0]  R187      -2.0123668015003204e-01
    z[0,1,0]  R188      -3.8823267817497253e-01
    z[0,1,0]  R189      -2.7819445729255676e-01
    z[0,1,0]  R190      -1.8396872282028198e-01
    z[0,1,0]  R191      -0.406222403049469
    z[0,1,0]  R192      -1.1003332585096359e-01
    z[0,1,0]  R193      -9.8708763718605042e-02
    z[0,1,0]  R194      4.4714215397834778e-01
    z[0,1,0]  R195      -3.8053756952285767e-01
    z[0,1,0]  R196      2.1977389231324196e-02
    z[0,1,0]  R197      -1.4427816867828369e-01
    z[0,1,0]  R198      8.8784933090209961e-01
    z[0,1,0]  R199      -1.9358487427234650e-01
    z[0,1,0]  R200      -2.9861995577812195e-01
    z[0,1,0]  R201      -2.8213111683726311e-02
    z[0,1,0]  R202      1.6459727287292480e-01
    z[0,1,0]  R203      3.3137798309326172e-01
    z[0,1,0]  R204      2.3689137399196625e-01
    z[0,1,0]  R205      -2.9080209136009216e-01
    z[0,1,0]  R206      -5.5311852693557739e-01
    z[0,1,0]  R207      5.9021119959652424e-03
    z[0,1,0]  R208      5.5397635698318481e-01
    z[0,1,0]  R209      1.1108215898275375e-01
    z[0,1,0]  R210      -3.1310665607452393e-01
    z[0,1,0]  R211      0.181345596909523
    z[0,1,0]  R212      -9.9855475127696991e-02
    z[0,1,0]  R213      -4.7264367341995239e-01
    z[0,1,0]  R214      1.7552487552165985e-01
    z[0,1,0]  R215      1.1585873365402222e-01
    z[0,1,0]  R216      2.7301779389381409e-01
    z[0,1,0]  R217      3.6947306990623474e-01
    z[0,1,0]  R218      1.2942981719970703e-01
    z[0,1,0]  R219      1.4334422349929810e-01
    z[0,1,0]  R220      -2.0050154998898506e-03
    z[0,1,0]  R221      -3.4409871697425842e-01
    z[0,1,0]  R222      -0.0753057599067688
    z[0,1,0]  R223      -4.1856479644775391e-01
    z[0,1,0]  R224      -5.2887761592864990e-01
    z[0,1,0]  R225      3.8372308015823364e-01
    z[0,1,0]  R226      1.8392139673233032e-01
    z[0,1,0]  R227      0.756458580493927
    z[0,1,0]  R228      4.1215223073959351e-01
    z[0,1,0]  R229      -2.9381206259131432e-02
    z[0,1,0]  R230      -1.9953933358192444e-01
    z[0,1,0]  R231      0.0612550750374794
    z[0,1,0]  R232      -5.5652207136154175e-01
    z[0,1,0]  R233      2.4315534532070160e-01
    z[0,1,0]  R234      8.9159369468688965e-01
    z[0,1,0]  R235      8.5959982872009277e-01
    z[0,1,0]  R236      8.3808708190917969e-01
    z[0,1,0]  R237      8.2671457529067993e-01
    z[0,1,0]  R238      8.2864439487457275e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       3.6833387613296509e-01
    z[0,1,1]  R80       7.9607349634170532e-01
    z[0,1,1]  R81       -4.1194394230842590e-01
    z[0,1,1]  R82       -3.9958181977272034e-01
    z[0,1,1]  R83       4.9775320291519165e-01
    z[0,1,1]  R84       7.2175461053848267e-01
    z[0,1,1]  R85       -5.8704257011413574e-01
    z[0,1,1]  R86       -6.2557137012481689e-01
    z[0,1,1]  R87       -4.7308912873268127e-01
    z[0,1,1]  R88       -6.1057257652282715e-01
    z[0,1,1]  R89       -8.6844104528427124e-01
    z[0,1,1]  R90       -3.7819364666938782e-01
    z[0,1,1]  R91       7.8421306610107422e-01
    z[0,1,1]  R92       -4.6251523494720459e-01
    z[0,1,1]  R93       -6.7398720979690552e-01
    z[0,1,1]  R94       -0.629465639591217
    z[0,1,1]  R95       7.1435183286666870e-01
    z[0,1,1]  R96       7.6606941223144531e-01
    z[0,1,1]  R97       -0.630012571811676
    z[0,1,1]  R98       3.3499780297279358e-01
    z[0,1,1]  R99       8.1709533929824829e-01
    z[0,1,1]  R100      7.3661535978317261e-01
    z[0,1,1]  R101      7.3152804374694824e-01
    z[0,1,1]  R102      -3.0366113781929016e-01
    z[0,1,1]  R103      5.0897938013076782e-01
    z[0,1,1]  R104      6.3099247217178345e-01
    z[0,1,1]  R105      3.2106861472129822e-01
    z[0,1,1]  R106      -1.1713733896613121e-02
    z[0,1,1]  R107      0.736412763595581
    z[0,1,1]  R108      7.4944078922271729e-02
    z[0,1,1]  R109      8.3493673801422119e-01
    z[0,1,1]  R110      6.7021858692169189e-01
    z[0,1,1]  R111      1.0754422843456268e-01
    z[0,1,1]  R112      6.6958451271057129e-01
    z[0,1,1]  R113      7.9599660634994507e-01
    z[0,1,1]  R114      -2.4713924527168274e-01
    z[0,1,1]  R115      -0.864155650138855
    z[0,1,1]  R116      3.7200577557086945e-02
    z[0,1,1]  R117      0.793024480342865
    z[0,1,1]  R118      -5.6740152835845947e-01
    z[0,1,1]  R119      3.6730918288230896e-01
    z[0,1,1]  R120      8.8114857673645020e-01
    z[0,1,1]  R121      -7.8086805343627930e-01
    z[0,1,1]  R122      7.9446837306022644e-02
    z[0,1,1]  R123      -2.2397871315479279e-01
    z[0,1,1]  R124      -1.8734152615070343e-01
    z[0,1,1]  R125      -7.8264009952545166e-01
    z[0,1,1]  R126      -3.5057049989700317e-01
    z[0,1,1]  R127      -7.8658795356750488e-01
    z[0,1,1]  R128      -8.6471116542816162e-01
    z[0,1,1]  R129      3.4992757439613342e-01
    z[0,1,1]  R130      -6.2392234802246094e-01
    z[0,1,1]  R131      1.8919041380286217e-02
    z[0,1,1]  R132      -2.0074361562728882e-01
    z[0,1,1]  R133      3.8524657487869263e-02
    z[0,1,1]  R134      -3.3165480941534042e-02
    z[0,1,1]  R135      7.1194154024124146e-01
    z[0,1,1]  R136      -9.2100965976715088e-01
    z[0,1,1]  R137      -3.2712038606405258e-02
    z[0,1,1]  R138      2.0799531042575836e-01
    z[0,1,1]  R139      -1.7363831400871277e-01
    z[0,1,1]  R140      2.6390469074249268e-01
    z[0,1,1]  R141      -8.0534279346466064e-01
    z[0,1,1]  R142      -3.3154079318046570e-01
    z[0,1,1]  R143      3.5923457145690918e-01
    z[0,1,1]  R144      -0.895881712436676
    z[0,1,1]  R145      6.7885470390319824e-01
    z[0,1,1]  R146      -7.6817399263381958e-01
    z[0,1,1]  R147      -6.4891618490219116e-01
    z[0,1,1]  R148      -0.37047278881073
    z[0,1,1]  R149      9.1027367115020752e-01
    z[0,1,1]  R150      -2.2061090171337128e-01
    z[0,1,1]  R151      6.1865431070327759e-01
    z[0,1,1]  R152      6.5419411659240723e-01
    z[0,1,1]  R153      0.648796021938324
    z[0,1,1]  R154      -1.0930936038494110e-01
    z[0,1,1]  R155      -6.4319121837615967e-01
    z[0,1,1]  R156      7.4658292531967163e-01
    z[0,1,1]  R157      -1.6936777532100677e-01
    z[0,1,1]  R158      5.3226995468139648e-01
    z[0,1,1]  R159      8.5525131225585938e-01
    z[0,1,1]  R160      1.5650014579296112e-01
    z[0,1,1]  R161      2.2968946397304535e-01
    z[0,1,1]  R162      -8.4850661456584930e-02
    z[0,1,1]  R163      -3.3790320158004761e-02
    z[0,1,1]  R164      -2.8482902050018311e-01
    z[0,1,1]  R165      1.9975388050079346e-01
    z[0,1,1]  R166      -6.9128429889678955e-01
    z[0,1,1]  R167      -1.3931839168071747e-01
    z[0,1,1]  R168      -3.0566978454589844e-01
    z[0,1,1]  R169      5.7023260742425919e-02
    z[0,1,1]  R170      -4.0100085735321045e-01
    z[0,1,1]  R171      -4.0556874871253967e-01
    z[0,1,1]  R172      -4.6332615613937378e-01
    z[0,1,1]  R173      -2.3702657222747803e-01
    z[0,1,1]  R174      2.2285167872905731e-01
    z[0,1,1]  R175      2.9661893844604492e-01
    z[0,1,1]  R176      -3.8518407940864563e-01
    z[0,1,1]  R177      9.2216655611991882e-02
    z[0,1,1]  R178      -3.6164233088493347e-01
    z[0,1,1]  R179      -6.8206888437271118e-01
    z[0,1,1]  R180      -5.1864419132471085e-02
    z[0,1,1]  R181      -5.4454110562801361e-02
    z[0,1,1]  R182      0.0367298349738121
    z[0,1,1]  R183      -3.0298924073576927e-02
    z[0,1,1]  R184      6.8774081766605377e-02
    z[0,1,1]  R185      1.3289210200309753e-01
    z[0,1,1]  R186      -1.5048886835575104e-01
    z[0,1,1]  R187      -2.6078957319259644e-01
    z[0,1,1]  R188      3.0239865183830261e-01
    z[0,1,1]  R189      -3.2169643044471741e-01
    z[0,1,1]  R190      3.1752693653106689e-01
    z[0,1,1]  R191      -2.7491134405136108e-01
    z[0,1,1]  R192      -2.0878896117210388e-01
    z[0,1,1]  R193      -4.4018852710723877e-01
    z[0,1,1]  R194      -1.1904118955135345e-01
    z[0,1,1]  R195      3.8342788815498352e-01
    z[0,1,1]  R196      7.4422186613082886e-01
    z[0,1,1]  R197      -2.3468953371047974e-01
    z[0,1,1]  R198      0.400115966796875
    z[0,1,1]  R199      -1.1934275925159454e-01
    z[0,1,1]  R200      6.0335206799209118e-03
    z[0,1,1]  R201      2.9801445081830025e-02
    z[0,1,1]  R202      3.9609622955322266e-01
    z[0,1,1]  R203      0.460801899433136
    z[0,1,1]  R204      -4.2347031831741333e-01
    z[0,1,1]  R205      5.9909218549728394e-01
    z[0,1,1]  R206      -2.5118863582611084e-01
    z[0,1,1]  R207      -4.5285689830780029e-01
    z[0,1,1]  R208      2.9667595028877258e-01
    z[0,1,1]  R209      -4.4780600070953369e-01
    z[0,1,1]  R210      0.479547381401062
    z[0,1,1]  R211      -1.1395521461963654e-01
    z[0,1,1]  R212      5.7864004373550415e-01
    z[0,1,1]  R213      -2.3511280119419098e-01
    z[0,1,1]  R214      3.3842352032661438e-01
    z[0,1,1]  R215      -6.4883500337600708e-01
    z[0,1,1]  R216      -5.0559818744659424e-01
    z[0,1,1]  R217      0.500224769115448
    z[0,1,1]  R218      -1.5252690762281418e-02
    z[0,1,1]  R219      2.0094932615756989e-01
    z[0,1,1]  R220      -4.3286976218223572e-01
    z[0,1,1]  R221      3.8947391510009766e-01
    z[0,1,1]  R222      4.8887810111045837e-01
    z[0,1,1]  R223      -1.6817826032638550e-01
    z[0,1,1]  R224      -1.7984431982040405e-01
    z[0,1,1]  R225      1.6541364789009094e-01
    z[0,1,1]  R226      8.7534934282302856e-02
    z[0,1,1]  R227      1.3398897647857666e-01
    z[0,1,1]  R228      -3.3120420575141907e-01
    z[0,1,1]  R229      3.9884641766548157e-01
    z[0,1,1]  R230      4.5949053764343262e-01
    z[0,1,1]  R231      1.0078227519989014e-01
    z[0,1,1]  R232      2.0944228395819664e-02
    z[0,1,1]  R233      -4.8049259185791016e-01
    z[0,1,1]  R234      3.4001204371452332e-01
    z[0,1,1]  R235      2.5614374876022339e-01
    z[0,1,1]  R236      0.4011210501194
    z[0,1,1]  R237      3.2489171624183655e-01
    z[0,1,1]  R238      2.7052381634712219e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       7.5606632232666016e-01
    z[0,1,2]  R80       -1.2401672452688217e-01
    z[0,1,2]  R81       -3.7869594991207123e-02
    z[0,1,2]  R82       -0.0090639628469944
    z[0,1,2]  R83       2.5722339749336243e-01
    z[0,1,2]  R84       4.9583235383033752e-01
    z[0,1,2]  R85       -3.1884562224149704e-02
    z[0,1,2]  R86       -1.4853253960609436e-01
    z[0,1,2]  R87       -6.4209826290607452e-02
    z[0,1,2]  R88       -1.8338464200496674e-02
    z[0,1,2]  R89       -9.8827652633190155e-02
    z[0,1,2]  R90       -4.4583427906036377e-01
    z[0,1,2]  R91       -2.6195909827947617e-02
    z[0,1,2]  R92       -3.5094434022903442e-01
    z[0,1,2]  R93       -3.7738955020904541e-01
    z[0,1,2]  R94       -1.5090338885784149e-01
    z[0,1,2]  R95       1.1762766540050507e-01
    z[0,1,2]  R96       -1.6124796122312546e-02
    z[0,1,2]  R97       -1.8149559199810028e-01
    z[0,1,2]  R98       2.9928576946258545e-01
    z[0,1,2]  R99       -1.2259004870429635e-03
    z[0,1,2]  R100      3.9859589934349060e-01
    z[0,1,2]  R101      4.5946672558784485e-01
    z[0,1,2]  R102      -2.7820277214050293e-01
    z[0,1,2]  R103      4.1098093986511230e-01
    z[0,1,2]  R104      -5.0525808334350586e-01
    z[0,1,2]  R105      5.1737630367279053e-01
    z[0,1,2]  R106      1.2611895799636841e-01
    z[0,1,2]  R107      -6.1552878469228745e-02
    z[0,1,2]  R108      4.1487866640090942e-01
    z[0,1,2]  R109      -1.4426006376743317e-01
    z[0,1,2]  R110      2.4643549323081970e-01
    z[0,1,2]  R111      4.1255244612693787e-01
    z[0,1,2]  R112      -5.7148575782775879e-01
    z[0,1,2]  R113      -4.5504567027091980e-01
    z[0,1,2]  R114      1.2018267810344696e-01
    z[0,1,2]  R115      1.8982850015163422e-02
    z[0,1,2]  R116      4.3548887968063354e-01
    z[0,1,2]  R117      -5.8144873380661011e-01
    z[0,1,2]  R118      -1.5069223940372467e-01
    z[0,1,2]  R119      5.2009713649749756e-01
    z[0,1,2]  R120      -1.9687506556510925e-01
    z[0,1,2]  R121      0.0201080534607172
    z[0,1,2]  R122      5.2347022294998169e-01
    z[0,1,2]  R123      -1.1046304553747177e-01
    z[0,1,2]  R124      -6.4911562204360962e-01
    z[0,1,2]  R125      -4.1073363274335861e-02
    z[0,1,2]  R126      -1.6348633170127869e-01
    z[0,1,2]  R127      -1.5209870040416718e-01
    z[0,1,2]  R128      -1.8222853541374207e-01
    z[0,1,2]  R129      5.5721467733383179e-01
    z[0,1,2]  R130      -1.1913654953241348e-01
    z[0,1,2]  R131      4.4215241074562073e-01
    z[0,1,2]  R132      2.7167335152626038e-01
    z[0,1,2]  R133      -3.1831446290016174e-01
    z[0,1,2]  R134      -2.2658412158489227e-01
    z[0,1,2]  R135      -1.0902421921491623e-01
    z[0,1,2]  R136      -1.0851480066776276e-01
    z[0,1,2]  R137      1.1226566135883331e-01
    z[0,1,2]  R138      -5.3804680705070496e-02
    z[0,1,2]  R139      -4.2838653922080994e-01
    z[0,1,2]  R140      5.1253533363342285e-01
    z[0,1,2]  R141      -2.6043480634689331e-01
    z[0,1,2]  R142      -4.9675479531288147e-01
    z[0,1,2]  R143      6.2754553556442261e-01
    z[0,1,2]  R144      -1.7652894556522369e-01
    z[0,1,2]  R145      1.6643513739109039e-01
    z[0,1,2]  R146      -2.4202552437782288e-01
    z[0,1,2]  R147      2.7322193980216980e-01
    z[0,1,2]  R148      4.3216076493263245e-01
    z[0,1,2]  R149      4.0930751711130142e-02
    z[0,1,2]  R150      -3.2603389024734497e-01
    z[0,1,2]  R151      2.0815475285053253e-01
    z[0,1,2]  R152      -1.8299816176295280e-02
    z[0,1,2]  R153      1.6122369468212128e-01
    z[0,1,2]  R154      -3.9493107795715332e-01
    z[0,1,2]  R155      -1.2309246696531773e-02
    z[0,1,2]  R156      -7.8025050461292267e-02
    z[0,1,2]  R157      2.3661802709102631e-01
    z[0,1,2]  R158      -0.338933527469635
    z[0,1,2]  R159      -4.0052774548530579e-01
    z[0,1,2]  R160      5.3929162025451660e-01
    z[0,1,2]  R161      -2.8605839610099792e-01
    z[0,1,2]  R162      -7.1341377496719360e-01
    z[0,1,2]  R163      6.6442453861236572e-01
    z[0,1,2]  R164      5.2587682008743286e-01
    z[0,1,2]  R165      -2.2238335013389587e-01
    z[0,1,2]  R166      -2.7310755848884583e-01
    z[0,1,2]  R167      -2.7657121419906616e-01
    z[0,1,2]  R168      -1.7558740451931953e-02
    z[0,1,2]  R169      5.7882523536682129e-01
    z[0,1,2]  R170      4.1696330904960632e-01
    z[0,1,2]  R171      5.1958316564559937e-01
    z[0,1,2]  R172      5.7546877861022949e-01
    z[0,1,2]  R173      2.1274326741695404e-01
    z[0,1,2]  R174      7.5553268194198608e-01
    z[0,1,2]  R175      4.0897557139396667e-01
    z[0,1,2]  R176      9.6684433519840240e-03
    z[0,1,2]  R177      -3.0653487890958786e-02
    z[0,1,2]  R178      7.4481427669525146e-02
    z[0,1,2]  R179      -4.2489755153656006e-01
    z[0,1,2]  R180      -2.0523147657513618e-02
    z[0,1,2]  R181      -3.4373795986175537e-01
    z[0,1,2]  R182      9.5099993050098419e-02
    z[0,1,2]  R183      -2.2712003439664841e-02
    z[0,1,2]  R184      2.0225118845701218e-02
    z[0,1,2]  R185      -8.4506928920745850e-02
    z[0,1,2]  R186      -1.7085234820842743e-01
    z[0,1,2]  R187      -9.8722055554389954e-02
    z[0,1,2]  R188      -1.4519126713275909e-01
    z[0,1,2]  R189      -2.3931415379047394e-01
    z[0,1,2]  R190      -3.5749744623899460e-02
    z[0,1,2]  R191      4.3033313751220703e-01
    z[0,1,2]  R192      2.3229060694575310e-02
    z[0,1,2]  R193      -6.8220630288124084e-02
    z[0,1,2]  R194      -2.4715360999107361e-01
    z[0,1,2]  R195      3.8568194955587387e-02
    z[0,1,2]  R196      3.6008810997009277e-01
    z[0,1,2]  R197      1.1655066907405853e-01
    z[0,1,2]  R198      -1.4073415659368038e-02
    z[0,1,2]  R199      3.5025379620492458e-03
    z[0,1,2]  R200      2.5871858000755310e-01
    z[0,1,2]  R201      5.0503186881542206e-02
    z[0,1,2]  R202      -1.9696229696273804e-01
    z[0,1,2]  R203      1.0958162695169449e-01
    z[0,1,2]  R204      -3.6883754655718803e-03
    z[0,1,2]  R205      8.8690489530563354e-02
    z[0,1,2]  R206      9.6120364964008331e-02
    z[0,1,2]  R207      2.3620733618736267e-01
    z[0,1,2]  R208      -8.8324621319770813e-02
    z[0,1,2]  R209      -4.0031763911247253e-01
    z[0,1,2]  R210      1.7647184431552887e-01
    z[0,1,2]  R211      2.7075189352035522e-01
    z[0,1,2]  R212      5.7719075679779053e-01
    z[0,1,2]  R213      8.3714880049228668e-02
    z[0,1,2]  R214      -2.6952880620956421e-01
    z[0,1,2]  R215      1.6323316097259521e-01
    z[0,1,2]  R216      -2.3205693066120148e-01
    z[0,1,2]  R217      7.0322789251804352e-02
    z[0,1,2]  R218      6.2086915969848633e-01
    z[0,1,2]  R219      2.3653939366340637e-02
    z[0,1,2]  R220      -2.4569955468177795e-01
    z[0,1,2]  R221      3.2196617126464844e-01
    z[0,1,2]  R222      4.1821566224098206e-01
    z[0,1,2]  R223      3.5133041441440582e-02
    z[0,1,2]  R224      -1.4320272952318192e-02
    z[0,1,2]  R225      1.5297865867614746e-01
    z[0,1,2]  R226      6.3117647171020508e-01
    z[0,1,2]  R227      -1.8626330420374870e-02
    z[0,1,2]  R228      -3.0767264962196350e-01
    z[0,1,2]  R229      2.6093924045562744e-01
    z[0,1,2]  R230      3.9941665530204773e-01
    z[0,1,2]  R231      -2.3553118109703064e-01
    z[0,1,2]  R232      -6.9350576959550381e-03
    z[0,1,2]  R233      1.9941753149032593e-01
    z[0,1,2]  R234      2.5417020916938782e-01
    z[0,1,2]  R235      -2.1761699020862579e-01
    z[0,1,2]  R236      6.5196588635444641e-02
    z[0,1,2]  R237      -3.3122289180755615e-01
    z[0,1,2]  R238      -3.2163041830062866e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       0.00919360015541315
    z[0,1,3]  R80       2.7194846421480179e-02
    z[0,1,3]  R81       -3.4394222497940063e-01
    z[0,1,3]  R82       -2.9011097550392151e-01
    z[0,1,3]  R83       2.4903476238250732e-01
    z[0,1,3]  R84       -2.2532276809215546e-01
    z[0,1,3]  R85       0.312175452709198
    z[0,1,3]  R86       -3.8715666532516479e-01
    z[0,1,3]  R87       -2.5482279062271118e-01
    z[0,1,3]  R88       -5.9454911947250366e-01
    z[0,1,3]  R89       3.3574298024177551e-01
    z[0,1,3]  R90       -2.1461232006549835e-01
    z[0,1,3]  R91       -1.5855069458484650e-01
    z[0,1,3]  R92       -4.1359403729438782e-01
    z[0,1,3]  R93       -1.9654460251331329e-01
    z[0,1,3]  R94       6.0009920597076416e-01
    z[0,1,3]  R95       3.2986736297607422e-01
    z[0,1,3]  R96       -1.6660936176776886e-01
    z[0,1,3]  R97       2.6079794764518738e-01
    z[0,1,3]  R98       1.9063760340213776e-01
    z[0,1,3]  R99       -1.6288323700428009e-01
    z[0,1,3]  R100      -0.350488543510437
    z[0,1,3]  R101      5.7509769685566425e-03
    z[0,1,3]  R102      -6.6776730120182037e-02
    z[0,1,3]  R103      3.5175219178199768e-01
    z[0,1,3]  R104      -9.1895036399364471e-02
    z[0,1,3]  R105      -1.6132335364818573e-01
    z[0,1,3]  R106      -3.7675538659095764e-01
    z[0,1,3]  R107      5.1050532609224319e-02
    z[0,1,3]  R108      -3.3609023690223694e-01
    z[0,1,3]  R109      9.2560619115829468e-02
    z[0,1,3]  R110      4.1062968969345093e-01
    z[0,1,3]  R111      -4.9150732159614563e-01
    z[0,1,3]  R112      3.0427560210227966e-01
    z[0,1,3]  R113      -3.7423957139253616e-02
    z[0,1,3]  R114      7.6432478427886963e-01
    z[0,1,3]  R115      0.371351420879364
    z[0,1,3]  R116      -0.270082950592041
    z[0,1,3]  R117      -5.0245355814695358e-02
    z[0,1,3]  R118      -3.0831021070480347e-01
    z[0,1,3]  R119      -2.0431217551231384e-01
    z[0,1,3]  R120      -1.0609222948551178e-01
    z[0,1,3]  R121      0.522624135017395
    z[0,1,3]  R122      -2.4257950484752655e-01
    z[0,1,3]  R123      8.3517897129058838e-01
    z[0,1,3]  R124      -2.3713992536067963e-01
    z[0,1,3]  R125      1.7736728489398956e-01
    z[0,1,3]  R126      4.9250704050064087e-01
    z[0,1,3]  R127      3.4422501921653748e-02
    z[0,1,3]  R128      -2.3740322887897491e-01
    z[0,1,3]  R129      -1.6251015663146973e-01
    z[0,1,3]  R130      0.574330747127533
    z[0,1,3]  R131      2.0639950037002563e-01
    z[0,1,3]  R132      5.0674965605139732e-03
    z[0,1,3]  R133      -1.4749768376350403e-01
    z[0,1,3]  R134      -1.6726320981979370e-01
    z[0,1,3]  R135      -2.8104493021965027e-01
    z[0,1,3]  R136      -0.0925268605351448
    z[0,1,3]  R137      1.2001358903944492e-02
    z[0,1,3]  R138      -4.5203246176242828e-02
    z[0,1,3]  R139      -3.4919625520706177e-01
    z[0,1,3]  R140      -1.7929084599018097e-02
    z[0,1,3]  R141      2.7303194999694824e-01
    z[0,1,3]  R142      -3.5218429565429688e-01
    z[0,1,3]  R143      3.2124549150466919e-02
    z[0,1,3]  R144      -1.8332313047721982e-03
    z[0,1,3]  R145      -4.7861579060554504e-01
    z[0,1,3]  R146      -2.9377844929695129e-01
    z[0,1,3]  R147      -3.6752650141716003e-01
    z[0,1,3]  R148      -4.6634238958358765e-01
    z[0,1,3]  R149      -7.7418766915798187e-02
    z[0,1,3]  R150      8.1320095062255859e-01
    z[0,1,3]  R151      -3.8583735004067421e-03
    z[0,1,3]  R152      3.5540437698364258e-01
    z[0,1,3]  R153      3.0389702320098877e-01
    z[0,1,3]  R154      -0.0907410979270935
    z[0,1,3]  R155      6.5078479051589966e-01
    z[0,1,3]  R156      2.4905851483345032e-01
    z[0,1,3]  R157      6.0266852378845215e-01
    z[0,1,3]  R158      0.380577027797699
    z[0,1,3]  R159      -1.5043872594833374e-01
    z[0,1,3]  R160      -2.0054295659065247e-01
    z[0,1,3]  R161      5.1038622856140137e-01
    z[0,1,3]  R162      -3.4189623594284058e-01
    z[0,1,3]  R163      2.6827251911163330e-01
    z[0,1,3]  R164      -1.0436327010393143e-01
    z[0,1,3]  R165      3.3484068512916565e-01
    z[0,1,3]  R166      -2.3631818592548370e-01
    z[0,1,3]  R167      3.1567353010177612e-01
    z[0,1,3]  R168      -3.0971601605415344e-01
    z[0,1,3]  R169      -2.8136521577835083e-01
    z[0,1,3]  R170      -5.2662551403045654e-01
    z[0,1,3]  R171      -6.1233186721801758e-01
    z[0,1,3]  R172      -3.1960594654083252e-01
    z[0,1,3]  R173      -4.3368527293205261e-01
    z[0,1,3]  R174      -5.1076197624206543e-01
    z[0,1,3]  R175      -8.0525797605514526e-01
    z[0,1,3]  R176      -5.2254360914230347e-01
    z[0,1,3]  R177      -4.2296999692916870e-01
    z[0,1,3]  R178      4.8478193581104279e-02
    z[0,1,3]  R179      -1.8497726321220398e-01
    z[0,1,3]  R180      7.9207018017768860e-02
    z[0,1,3]  R181      3.8945192098617554e-01
    z[0,1,3]  R182      0.422821044921875
    z[0,1,3]  R183      -2.8210881352424622e-01
    z[0,1,3]  R184      -1.1807091534137726e-01
    z[0,1,3]  R185      3.5757082700729370e-01
    z[0,1,3]  R186      3.3467337489128113e-01
    z[0,1,3]  R187      2.5352901220321655e-01
    z[0,1,3]  R188      3.3100441098213196e-01
    z[0,1,3]  R189      -5.6162250041961670e-01
    z[0,1,3]  R190      5.2022719383239746e-01
    z[0,1,3]  R191      5.4889374971389771e-01
    z[0,1,3]  R192      4.7716978192329407e-01
    z[0,1,3]  R193      -3.4345608949661255e-01
    z[0,1,3]  R194      3.9964485168457031e-01
    z[0,1,3]  R195      3.8020107150077820e-01
    z[0,1,3]  R196      3.6080777645111084e-01
    z[0,1,3]  R197      3.6020430922508240e-01
    z[0,1,3]  R198      1.0170537978410721e-01
    z[0,1,3]  R199      -0.731119692325592
    z[0,1,3]  R200      5.0512790679931641e-01
    z[0,1,3]  R201      4.7510275244712830e-01
    z[0,1,3]  R202      4.7052279114723206e-01
    z[0,1,3]  R203      4.8424473404884338e-01
    z[0,1,3]  R204      4.5583185553550720e-01
    z[0,1,3]  R205      4.4839361310005188e-01
    z[0,1,3]  R206      4.3676459789276123e-01
    z[0,1,3]  R207      4.2668148875236511e-01
    z[0,1,3]  R208      4.2736229300498962e-01
    z[0,1,3]  R209      -7.1151775121688843e-01
    z[0,1,3]  R210      5.5927473306655884e-01
    z[0,1,3]  R211      5.3567820787429810e-01
    z[0,1,3]  R212      0.525505781173706
    z[0,1,3]  R213      4.9212706089019775e-01
    z[0,1,3]  R214      4.8334461450576782e-01
    z[0,1,3]  R215      4.8629650473594666e-01
    z[0,1,3]  R216      4.3330281972885132e-01
    z[0,1,3]  R217      4.1259589791297913e-01
    z[0,1,3]  R218      4.3963640928268433e-01
    z[0,1,3]  R219      0.805002748966217
    z[0,1,3]  R220      -7.4258393049240112e-01
    z[0,1,3]  R221      6.9236713647842407e-01
    z[0,1,3]  R222      6.2224221229553223e-01
    z[0,1,3]  R223      5.1679807901382446e-01
    z[0,1,3]  R224      -5.6394052505493164e-01
    z[0,1,3]  R225      0.447330117225647
    z[0,1,3]  R226      4.2527988553047180e-01
    z[0,1,3]  R227      4.0102961659431458e-01
    z[0,1,3]  R228      3.7532398104667664e-01
    z[0,1,3]  R229      -5.9658187627792358e-01
    z[0,1,3]  R230      6.4064908027648926e-01
    z[0,1,3]  R231      5.1169615983963013e-01
    z[0,1,3]  R232      -3.3814874291419983e-01
    z[0,1,3]  R233      5.0888514518737793e-01
    z[0,1,3]  R234      -5.9023287147283554e-02
    z[0,1,3]  R235      -2.7531739324331284e-02
    z[0,1,3]  R236      -2.9218414425849915e-01
    z[0,1,3]  R237      -2.6991435885429382e-01
    z[0,1,3]  R238      -9.8402373492717743e-02
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       1.2621775269508362e-01
    z[0,1,4]  R80       4.3071404099464417e-01
    z[0,1,4]  R81       3.2724443823099136e-02
    z[0,1,4]  R82       0.257503867149353
    z[0,1,4]  R83       3.4328451752662659e-01
    z[0,1,4]  R84       6.9391697645187378e-02
    z[0,1,4]  R85       -6.1629676818847656e-01
    z[0,1,4]  R86       3.7020224332809448e-01
    z[0,1,4]  R87       -3.1938779354095459e-01
    z[0,1,4]  R88       1.0658331215381622e-01
    z[0,1,4]  R89       7.4869275093078613e-02
    z[0,1,4]  R90       -1.6004875302314758e-01
    z[0,1,4]  R91       -2.3936209082603455e-01
    z[0,1,4]  R92       -0.0923909991979599
    z[0,1,4]  R93       -1.3523493707180023e-01
    z[0,1,4]  R94       -4.2124426364898682e-01
    z[0,1,4]  R95       -4.9312117695808411e-01
    z[0,1,4]  R96       -5.5431240797042847e-01
    z[0,1,4]  R97       -4.9785044789314270e-01
    z[0,1,4]  R98       3.2990675419569016e-02
    z[0,1,4]  R99       1.6835348308086395e-01
    z[0,1,4]  R100      8.0416696146130562e-03
    z[0,1,4]  R101      -1.0430266708135605e-01
    z[0,1,4]  R102      4.0577873587608337e-01
    z[0,1,4]  R103      -1.4028076827526093e-01
    z[0,1,4]  R104      3.4348881244659424e-01
    z[0,1,4]  R105      2.8809541463851929e-01
    z[0,1,4]  R106      1.9812004640698433e-02
    z[0,1,4]  R107      -2.5096428394317627e-01
    z[0,1,4]  R108      3.6399370431900024e-01
    z[0,1,4]  R109      2.0979216694831848e-01
    z[0,1,4]  R110      2.0947840809822083e-01
    z[0,1,4]  R111      1.3595707714557648e-01
    z[0,1,4]  R112      -1.9441372156143188e-01
    z[0,1,4]  R113      -7.6700314879417419e-02
    z[0,1,4]  R114      -5.0680446624755859e-01
    z[0,1,4]  R115      1.0740419477224350e-01
    z[0,1,4]  R116      -3.5317346453666687e-01
    z[0,1,4]  R117      -9.2873267829418182e-02
    z[0,1,4]  R118      4.1667231917381287e-01
    z[0,1,4]  R119      2.7484133839607239e-01
    z[0,1,4]  R120      -4.5726341195404530e-03
    z[0,1,4]  R121      5.4045025259256363e-02
    z[0,1,4]  R122      -1.1667429655790329e-01
    z[0,1,4]  R123      -4.5199674367904663e-01
    z[0,1,4]  R124      3.3902961015701294e-01
    z[0,1,4]  R125      -4.1172477602958679e-01
    z[0,1,4]  R126      7.5132292509078979e-01
    z[0,1,4]  R127      -3.4670770168304443e-01
    z[0,1,4]  R128      -2.2079072892665863e-01
    z[0,1,4]  R129      -1.1875396221876144e-01
    z[0,1,4]  R130      -3.1644481420516968e-01
    z[0,1,4]  R131      3.1604072451591492e-01
    z[0,1,4]  R132      4.8546192049980164e-01
    z[0,1,4]  R133      -0.128139927983284
    z[0,1,4]  R134      -0.0866321325302124
    z[0,1,4]  R135      2.3385412991046906e-01
    z[0,1,4]  R136      5.7850323617458344e-02
    z[0,1,4]  R137      0.257344514131546
    z[0,1,4]  R138      2.4556914344429970e-02
    z[0,1,4]  R139      -1.6494618356227875e-01
    z[0,1,4]  R140      -1.3364669680595398e-01
    z[0,1,4]  R141      -1.1719775199890137e-01
    z[0,1,4]  R142      2.2424438595771790e-01
    z[0,1,4]  R143      -0.00995875895023346
    z[0,1,4]  R144      -3.8880905508995056e-01
    z[0,1,4]  R145      4.3893387913703918e-01
    z[0,1,4]  R146      2.5893932580947876e-01
    z[0,1,4]  R147      2.4864292144775391e-01
    z[0,1,4]  R148      -5.9497680515050888e-02
    z[0,1,4]  R149      1.3169558346271515e-01
    z[0,1,4]  R150      -3.2660955190658569e-01
    z[0,1,4]  R151      2.6325416564941406e-01
    z[0,1,4]  R152      -1.8018412590026855e-01
    z[0,1,4]  R153      2.0091657340526581e-01
    z[0,1,4]  R154      3.4084555506706238e-01
    z[0,1,4]  R155      -7.8271649777889252e-02
    z[0,1,4]  R156      -2.3090025782585144e-01
    z[0,1,4]  R157      5.3224277496337891e-01
    z[0,1,4]  R158      2.5602266192436218e-01
    z[0,1,4]  R159      -3.1911402940750122e-02
    z[0,1,4]  R160      -3.4819513559341431e-02
    z[0,1,4]  R161      -6.8201929330825806e-01
    z[0,1,4]  R162      2.4720046669244766e-02
    z[0,1,4]  R163      0.348127543926239
    z[0,1,4]  R164      1.2218102067708969e-01
    z[0,1,4]  R165      4.8597112298011780e-01
    z[0,1,4]  R166      -3.2860539853572845e-02
    z[0,1,4]  R167      5.6821429729461670e-01
    z[0,1,4]  R168      5.9923237562179565e-01
    z[0,1,4]  R169      6.0072422027587891e-01
    z[0,1,4]  R170      2.4796561896800995e-01
    z[0,1,4]  R171      2.6029223203659058e-01
    z[0,1,4]  R172      3.1332916021347046e-01
    z[0,1,4]  R173      2.6376459002494812e-01
    z[0,1,4]  R174      -2.0386783778667450e-01
    z[0,1,4]  R175      3.7150572985410690e-02
    z[0,1,4]  R176      -7.5935405492782593e-01
    z[0,1,4]  R177      -0.399393767118454
    z[0,1,4]  R178      -7.1339696645736694e-01
    z[0,1,4]  R179      4.7217461466789246e-01
    z[0,1,4]  R180      -3.1844952702522278e-01
    z[0,1,4]  R181      8.1103682518005371e-01
    z[0,1,4]  R182      -7.1264576911926270e-01
    z[0,1,4]  R183      -4.0418615937232971e-01
    z[0,1,4]  R184      -1.7569592595100403e-01
    z[0,1,4]  R185      5.8281880617141724e-01
    z[0,1,4]  R186      -8.1347936391830444e-01
    z[0,1,4]  R187      -6.7264097929000854e-01
    z[0,1,4]  R188      0.714393138885498
    z[0,1,4]  R189      2.0473514497280121e-01
    z[0,1,4]  R190      7.4354684352874756e-01
    z[0,1,4]  R191      -3.6610189080238342e-01
    z[0,1,4]  R192      -6.7614614963531494e-01
    z[0,1,4]  R193      -6.5717041492462158e-01
    z[0,1,4]  R194      6.3501501083374023e-01
    z[0,1,4]  R195      -2.0388266444206238e-01
    z[0,1,4]  R196      -4.1412681341171265e-01
    z[0,1,4]  R197      -1.8338575959205627e-01
    z[0,1,4]  R198      0.08367870002985
    z[0,1,4]  R199      -3.0239738523960114e-02
    z[0,1,4]  R200      -4.8318862915039062e-01
    z[0,1,4]  R201      5.0756323337554932e-01
    z[0,1,4]  R202      -6.6026735305786133e-01
    z[0,1,4]  R203      -5.5032426118850708e-01
    z[0,1,4]  R204      -4.8070478439331055e-01
    z[0,1,4]  R205      -2.4454867839813232e-01
    z[0,1,4]  R206      5.6814938783645630e-01
    z[0,1,4]  R207      -3.5311231017112732e-01
    z[0,1,4]  R208      -2.4681656062602997e-01
    z[0,1,4]  R209      2.4790546298027039e-01
    z[0,1,4]  R210      -5.1099810749292374e-02
    z[0,1,4]  R211      -4.8351773619651794e-01
    z[0,1,4]  R212      -1.2792724370956421e-01
    z[0,1,4]  R213      6.3539731502532959e-01
    z[0,1,4]  R214      -5.8918994665145874e-01
    z[0,1,4]  R215      -3.1173002719879150e-01
    z[0,1,4]  R216      -5.7868313789367676e-01
    z[0,1,4]  R217      0.40912064909935
    z[0,1,4]  R218      -7.7711150050163269e-02
    z[0,1,4]  R219      -5.3043740987777710e-01
    z[0,1,4]  R220      2.0222522318363190e-01
    z[0,1,4]  R221      -1.1678715795278549e-01
    z[0,1,4]  R222      0.266841858625412
    z[0,1,4]  R223      6.5220171213150024e-01
    z[0,1,4]  R224      -4.9036750197410583e-01
    z[0,1,4]  R225      4.0584853291511536e-01
    z[0,1,4]  R226      -2.3033963143825531e-01
    z[0,1,4]  R227      3.1694963574409485e-01
    z[0,1,4]  R228      6.0401898622512817e-01
    z[0,1,4]  R229      2.3337426781654358e-01
    z[0,1,4]  R230      0.260204017162323
    z[0,1,4]  R231      6.2906432151794434e-01
    z[0,1,4]  R232      -5.1490652561187744e-01
    z[0,1,4]  R233      -4.7561657428741455e-01
    z[0,1,4]  R234      -5.8428540825843811e-02
    z[0,1,4]  R235      -0.365177184343338
    z[0,1,4]  R236      5.0869386643171310e-02
    z[0,1,4]  R237      -3.2056987285614014e-02
    z[0,1,4]  R238      -6.5538994967937469e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       -5.0898045301437378e-02
    z[0,1,5]  R80       -2.7517560124397278e-01
    z[0,1,5]  R81       -5.5973863601684570e-01
    z[0,1,5]  R82       -6.2088322639465332e-01
    z[0,1,5]  R83       0.290799081325531
    z[0,1,5]  R84       -3.4118351340293884e-01
    z[0,1,5]  R85       2.5200262665748596e-01
    z[0,1,5]  R86       -2.1571926772594452e-01
    z[0,1,5]  R87       -4.1396751999855042e-01
    z[0,1,5]  R88       -5.5196538567543030e-02
    z[0,1,5]  R89       -0.340366005897522
    z[0,1,5]  R90       -3.3916282653808594e-01
    z[0,1,5]  R91       2.5396227836608887e-01
    z[0,1,5]  R92       -2.0888239145278931e-01
    z[0,1,5]  R93       -8.8600821793079376e-02
    z[0,1,5]  R94       0.0864071249961853
    z[0,1,5]  R95       -3.5851109772920609e-02
    z[0,1,5]  R96       1.2585379183292389e-01
    z[0,1,5]  R97       -5.6693799793720245e-02
    z[0,1,5]  R98       4.4701176881790161e-01
    z[0,1,5]  R99       9.5144383609294891e-02
    z[0,1,5]  R100      1.2219092994928360e-01
    z[0,1,5]  R101      -3.6877259612083435e-01
    z[0,1,5]  R102      -6.4557117223739624e-01
    z[0,1,5]  R103      2.4793425202369690e-01
    z[0,1,5]  R104      3.3341971039772034e-01
    z[0,1,5]  R105      0.415558785200119
    z[0,1,5]  R106      1.5356499701738358e-02
    z[0,1,5]  R107      -4.3897899985313416e-01
    z[0,1,5]  R108      5.1259106397628784e-01
    z[0,1,5]  R109      -0.0826454684138298
    z[0,1,5]  R110      -2.8129890561103821e-01
    z[0,1,5]  R111      3.9669489860534668e-01
    z[0,1,5]  R112      1.5606077015399933e-01
    z[0,1,5]  R113      -2.8040561079978943e-01
    z[0,1,5]  R114      1.8205150961875916e-01
    z[0,1,5]  R115      3.0326387286186218e-01
    z[0,1,5]  R116      0.228912353515625
    z[0,1,5]  R117      -2.2774764802306890e-03
    z[0,1,5]  R118      -3.2953587174415588e-01
    z[0,1,5]  R119      3.3728504180908203e-01
    z[0,1,5]  R120      -3.2062929123640060e-02
    z[0,1,5]  R121      -6.0443345457315445e-02
    z[0,1,5]  R122      2.9518043994903564e-01
    z[0,1,5]  R123      5.5045560002326965e-03
    z[0,1,5]  R124      -2.9020276665687561e-01
    z[0,1,5]  R125      -8.4798950701951981e-03
    z[0,1,5]  R126      6.6874980926513672e-02
    z[0,1,5]  R127      3.9979156851768494e-01
    z[0,1,5]  R128      0.0141511932015419
    z[0,1,5]  R129      2.4028590321540833e-01
    z[0,1,5]  R130      1.4296466112136841e-01
    z[0,1,5]  R131      5.2013820409774780e-01
    z[0,1,5]  R132      0.362602174282074
    z[0,1,5]  R133      -7.0562714338302612e-01
    z[0,1,5]  R134      -7.6083153486251831e-01
    z[0,1,5]  R135      -2.5893664360046387e-01
    z[0,1,5]  R136      3.4961634874343872e-01
    z[0,1,5]  R137      9.2065773904323578e-02
    z[0,1,5]  R138      0.290505051612854
    z[0,1,5]  R139      -4.6628376841545105e-01
    z[0,1,5]  R140      1.5312932431697845e-01
    z[0,1,5]  R141      -0.0842769518494606
    z[0,1,5]  R142      -3.5723760724067688e-01
    z[0,1,5]  R143      2.9243400692939758e-01
    z[0,1,5]  R144      5.2723549306392670e-02
    z[0,1,5]  R145      -6.9054342806339264e-02
    z[0,1,5]  R146      2.2902987897396088e-01
    z[0,1,5]  R147      -1.7587022483348846e-01
    z[0,1,5]  R148      -4.3951058387756348e-01
    z[0,1,5]  R149      -2.1963946521282196e-01
    z[0,1,5]  R150      -1.4680349826812744e-01
    z[0,1,5]  R151      3.5559117794036865e-01
    z[0,1,5]  R152      3.3225327730178833e-01
    z[0,1,5]  R153      -2.2312594950199127e-01
    z[0,1,5]  R154      -6.6104239225387573e-01
    z[0,1,5]  R155      -1.3015256822109222e-01
    z[0,1,5]  R156      -4.3054780364036560e-01
    z[0,1,5]  R157      -3.3977288007736206e-01
    z[0,1,5]  R158      2.9494670033454895e-01
    z[0,1,5]  R159      1.3274885714054108e-01
    z[0,1,5]  R160      2.7714800834655762e-01
    z[0,1,5]  R161      3.0091580748558044e-01
    z[0,1,5]  R162      -1.7766192555427551e-01
    z[0,1,5]  R163      2.3864848911762238e-01
    z[0,1,5]  R164      1.3339985907077789e-01
    z[0,1,5]  R165      -4.2681032419204712e-01
    z[0,1,5]  R166      4.8897233605384827e-01
    z[0,1,5]  R167      1.4568093419075012e-01
    z[0,1,5]  R168      -6.9919861853122711e-02
    z[0,1,5]  R169      -3.8039609789848328e-01
    z[0,1,5]  R170      -5.0422906875610352e-01
    z[0,1,5]  R171      -0.164892315864563
    z[0,1,5]  R172      -4.6466124057769775e-01
    z[0,1,5]  R173      -7.6907074451446533e-01
    z[0,1,5]  R174      -1.9561339914798737e-01
    z[0,1,5]  R175      1.6903290152549744e-01
    z[0,1,5]  R176      -3.4611638635396957e-02
    z[0,1,5]  R177      -1.5801297500729561e-02
    z[0,1,5]  R178      4.4854953885078430e-02
    z[0,1,5]  R179      -1.0670714825391769e-01
    z[0,1,5]  R180      -7.1751600503921509e-01
    z[0,1,5]  R181      6.5067127346992493e-02
    z[0,1,5]  R182      4.9789077043533325e-01
    z[0,1,5]  R183      -1.0500293225049973e-01
    z[0,1,5]  R184      -1.1569120734930038e-01
    z[0,1,5]  R185      6.1202161014080048e-02
    z[0,1,5]  R186      1.8338931724429131e-02
    z[0,1,5]  R187      5.3137916326522827e-01
    z[0,1,5]  R188      3.3780816197395325e-01
    z[0,1,5]  R189      1.6777861863374710e-02
    z[0,1,5]  R190      1.9756369292736053e-01
    z[0,1,5]  R191      3.6830523610115051e-01
    z[0,1,5]  R192      1.3149045407772064e-01
    z[0,1,5]  R193      -2.9963439702987671e-01
    z[0,1,5]  R194      -3.2674390077590942e-01
    z[0,1,5]  R195      7.1859258413314819e-01
    z[0,1,5]  R196      9.6005834639072418e-02
    z[0,1,5]  R197      6.1905288696289062e-01
    z[0,1,5]  R198      2.3936746641993523e-02
    z[0,1,5]  R199      -1.3524423539638519e-01
    z[0,1,5]  R200      8.5094437003135681e-02
    z[0,1,5]  R201      5.3755539655685425e-01
    z[0,1,5]  R202      1.3397021591663361e-01
    z[0,1,5]  R203      -3.2710316777229309e-01
    z[0,1,5]  R204      1.9581331312656403e-01
    z[0,1,5]  R205      3.4025412797927856e-01
    z[0,1,5]  R206      3.0967232584953308e-01
    z[0,1,5]  R207      -4.6537414193153381e-01
    z[0,1,5]  R208      -2.0345541834831238e-01
    z[0,1,5]  R209      -1.7123125493526459e-01
    z[0,1,5]  R210      5.5556458234786987e-01
    z[0,1,5]  R211      1.4421881735324860e-01
    z[0,1,5]  R212      -4.2163927108049393e-02
    z[0,1,5]  R213      2.1139974892139435e-01
    z[0,1,5]  R214      4.3668356537818909e-01
    z[0,1,5]  R215      -4.2336869239807129e-01
    z[0,1,5]  R216      -1.9220508635044098e-01
    z[0,1,5]  R217      3.0547830462455750e-01
    z[0,1,5]  R218      -3.2927942276000977e-01
    z[0,1,5]  R219      6.5410439856350422e-03
    z[0,1,5]  R220      -2.1521820127964020e-01
    z[0,1,5]  R221      1.4981015026569366e-01
    z[0,1,5]  R222      -0.0714566707611084
    z[0,1,5]  R223      1.5993739664554596e-01
    z[0,1,5]  R224      -2.0263540744781494e-01
    z[0,1,5]  R225      -0.27133908867836
    z[0,1,5]  R226      -4.7249174118041992e-01
    z[0,1,5]  R227      -2.1879664063453674e-01
    z[0,1,5]  R228      2.1051040291786194e-01
    z[0,1,5]  R229      -4.7900292277336121e-01
    z[0,1,5]  R230      1.1892103403806686e-01
    z[0,1,5]  R231      -2.1886758506298065e-02
    z[0,1,5]  R232      -5.5067169666290283e-01
    z[0,1,5]  R233      -9.6480071544647217e-02
    z[0,1,5]  R234      7.9776518046855927e-02
    z[0,1,5]  R235      -0.0778428167104721
    z[0,1,5]  R236      -9.3156717717647552e-02
    z[0,1,5]  R237      1.4025831222534180e-01
    z[0,1,5]  R238      -3.3763861656188965e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       3.1428948044776917e-02
    z[0,1,6]  R80       -1.2347525358200073e-01
    z[0,1,6]  R81       2.1435044705867767e-01
    z[0,1,6]  R82       6.4815111458301544e-02
    z[0,1,6]  R83       7.9461887478828430e-02
    z[0,1,6]  R84       -5.0881922245025635e-02
    z[0,1,6]  R85       1.9700525701045990e-01
    z[0,1,6]  R86       -1.4722093008458614e-02
    z[0,1,6]  R87       2.7972161769866943e-01
    z[0,1,6]  R88       -1.4217411167919636e-02
    z[0,1,6]  R89       -3.7718974053859711e-02
    z[0,1,6]  R90       -2.4991898238658905e-01
    z[0,1,6]  R91       3.0058425664901733e-01
    z[0,1,6]  R92       3.0824345350265503e-01
    z[0,1,6]  R93       8.1671245396137238e-02
    z[0,1,6]  R94       1.1477380245923996e-01
    z[0,1,6]  R95       1.0683772154152393e-02
    z[0,1,6]  R96       -1.5544918179512024e-01
    z[0,1,6]  R97       4.9034300446510315e-01
    z[0,1,6]  R98       -1.8377602100372314e-01
    z[0,1,6]  R99       -0.37274369597435
    z[0,1,6]  R100      1.5977036207914352e-02
    z[0,1,6]  R101      1.6093797981739044e-01
    z[0,1,6]  R102      4.3478954583406448e-02
    z[0,1,6]  R103      -1.6550987958908081e-01
    z[0,1,6]  R104      -7.1623444557189941e-02
    z[0,1,6]  R105      -2.7719438076019287e-01
    z[0,1,6]  R106      -1.8942917883396149e-01
    z[0,1,6]  R107      0.43539959192276
    z[0,1,6]  R108      2.8288811445236206e-01
    z[0,1,6]  R109      -3.3108890056610107e-01
    z[0,1,6]  R110      2.4633076041936874e-02
    z[0,1,6]  R111      1.7295395955443382e-02
    z[0,1,6]  R112      5.9470415115356445e-02
    z[0,1,6]  R113      2.6722386479377747e-01
    z[0,1,6]  R114      -1.2938253581523895e-01
    z[0,1,6]  R115      1.0591533035039902e-01
    z[0,1,6]  R116      -1.6675411164760590e-01
    z[0,1,6]  R117      -1.0583539307117462e-01
    z[0,1,6]  R118      2.2988523542881012e-01
    z[0,1,6]  R119      -7.8124955296516418e-02
    z[0,1,6]  R120      -3.4003564715385437e-01
    z[0,1,6]  R121      -2.0062687993049622e-01
    z[0,1,6]  R122      -1.7484804987907410e-01
    z[0,1,6]  R123      -1.8011310696601868e-01
    z[0,1,6]  R124      -2.2598819434642792e-01
    z[0,1,6]  R125      2.5719873607158661e-02
    z[0,1,6]  R126      -8.3407811820507050e-02
    z[0,1,6]  R127      2.7665841579437256e-01
    z[0,1,6]  R128      2.1546630561351776e-01
    z[0,1,6]  R129      -1.9060879945755005e-01
    z[0,1,6]  R130      1.4744338393211365e-01
    z[0,1,6]  R131      1.7841245234012604e-01
    z[0,1,6]  R132      1.9542181491851807e-01
    z[0,1,6]  R133      3.0342981219291687e-01
    z[0,1,6]  R134      1.4042806625366211e-01
    z[0,1,6]  R135      5.1081973314285278e-01
    z[0,1,6]  R136      4.2690034955739975e-02
    z[0,1,6]  R137      4.5900359749794006e-01
    z[0,1,6]  R138      6.2206890434026718e-02
    z[0,1,6]  R139      1.7906057834625244e-01
    z[0,1,6]  R140      -1.8205833435058594e-01
    z[0,1,6]  R141      -8.5641875863075256e-02
    z[0,1,6]  R142      5.5052293464541435e-03
    z[0,1,6]  R143      2.7318498492240906e-01
    z[0,1,6]  R144      9.1474344953894615e-03
    z[0,1,6]  R145      1.3312149047851562e-01
    z[0,1,6]  R146      -1.0616851598024368e-01
    z[0,1,6]  R147      -1.2419880181550980e-01
    z[0,1,6]  R148      -1.3380878372117877e-03
    z[0,1,6]  R149      -8.7297163903713226e-02
    z[0,1,6]  R150      2.3277722299098969e-01
    z[0,1,6]  R151      1.1558146029710770e-01
    z[0,1,6]  R152      -0.0084022656083107
    z[0,1,6]  R153      4.3134069442749023e-01
    z[0,1,6]  R154      2.4139201641082764e-01
    z[0,1,6]  R155      3.5985150933265686e-01
    z[0,1,6]  R156      0.335778146982193
    z[0,1,6]  R157      -0.361446738243103
    z[0,1,6]  R158      2.3352560400962830e-01
    z[0,1,6]  R159      4.9750655889511108e-02
    z[0,1,6]  R160      -1.0317817330360413e-01
    z[0,1,6]  R161      -1.2786078453063965e-01
    z[0,1,6]  R162      -2.5190016627311707e-01
    z[0,1,6]  R163      -2.3922783136367798e-01
    z[0,1,6]  R164      5.5657601356506348e-01
    z[0,1,6]  R165      -3.3673766255378723e-01
    z[0,1,6]  R166      0.323076069355011
    z[0,1,6]  R167      -1.0856927372515202e-02
    z[0,1,6]  R168      -1.5177269279956818e-01
    z[0,1,6]  R169      2.5978598743677139e-02
    z[0,1,6]  R170      2.5896498560905457e-01
    z[0,1,6]  R171      2.2164984047412872e-01
    z[0,1,6]  R172      3.9759743958711624e-03
    z[0,1,6]  R173      -1.1250501126050949e-01
    z[0,1,6]  R174      1.7408958077430725e-01
    z[0,1,6]  R175      1.3000544905662537e-01
    z[0,1,6]  R176      -2.1116336807608604e-02
    z[0,1,6]  R177      2.4243091046810150e-01
    z[0,1,6]  R178      4.6817961335182190e-01
    z[0,1,6]  R179      -2.7770814299583435e-01
    z[0,1,6]  R180      -4.0957968682050705e-02
    z[0,1,6]  R181      1.5679925680160522e-02
    z[0,1,6]  R182      2.3461225628852844e-01
    z[0,1,6]  R183      -6.1612367630004883e-01
    z[0,1,6]  R184      -0.510966956615448
    z[0,1,6]  R185      2.5119778513908386e-01
    z[0,1,6]  R186      1.0444530844688416e-01
    z[0,1,6]  R187      -2.8750613331794739e-01
    z[0,1,6]  R188      -5.2096154540777206e-02
    z[0,1,6]  R189      -6.3579088449478149e-01
    z[0,1,6]  R190      -3.9047278463840485e-02
    z[0,1,6]  R191      -5.7067770510911942e-02
    z[0,1,6]  R192      -4.9153414368629456e-01
    z[0,1,6]  R193      -3.9015471935272217e-01
    z[0,1,6]  R194      2.3470519483089447e-01
    z[0,1,6]  R195      -6.4734026789665222e-02
    z[0,1,6]  R196      7.1323089301586151e-02
    z[0,1,6]  R197      0.603255033493042
    z[0,1,6]  R198      -1.8306757509708405e-01
    z[0,1,6]  R199      -6.2811499834060669e-01
    z[0,1,6]  R200      -5.8990508317947388e-01
    z[0,1,6]  R201      4.7271189093589783e-01
    z[0,1,6]  R202      -3.1926280260086060e-01
    z[0,1,6]  R203      -1.4661435782909393e-01
    z[0,1,6]  R204      5.3604024648666382e-01
    z[0,1,6]  R205      -4.1475647687911987e-01
    z[0,1,6]  R206      -1.1077469587326050e-01
    z[0,1,6]  R207      -4.6451419591903687e-01
    z[0,1,6]  R208      5.5887496471405029e-01
    z[0,1,6]  R209      -1.7274679243564606e-01
    z[0,1,6]  R210      1.2963366508483887e-01
    z[0,1,6]  R211      5.8247900009155273e-01
    z[0,1,6]  R212      1.6660098731517792e-01
    z[0,1,6]  R213      -1.5399083495140076e-01
    z[0,1,6]  R214      1.0274005681276321e-01
    z[0,1,6]  R215      -1.6138151288032532e-01
    z[0,1,6]  R216      -2.3751424252986908e-01
    z[0,1,6]  R217      -4.2117387056350708e-01
    z[0,1,6]  R218      5.3832399845123291e-01
    z[0,1,6]  R219      -9.5269419252872467e-02
    z[0,1,6]  R220      -0.337056040763855
    z[0,1,6]  R221      -3.3285051584243774e-01
    z[0,1,6]  R222      0.341945618391037
    z[0,1,6]  R223      -2.7795326709747314e-01
    z[0,1,6]  R224      -2.9696673154830933e-01
    z[0,1,6]  R225      6.0295134782791138e-01
    z[0,1,6]  R226      3.2087239623069763e-01
    z[0,1,6]  R227      3.1672829389572144e-01
    z[0,1,6]  R228      -2.7522730827331543e-01
    z[0,1,6]  R229      -3.6352673172950745e-01
    z[0,1,6]  R230      3.1183210015296936e-01
    z[0,1,6]  R231      -0.522093653678894
    z[0,1,6]  R232      8.4165006875991821e-02
    z[0,1,6]  R233      4.1922721266746521e-01
    z[0,1,6]  R234      -1.0764741152524948e-01
    z[0,1,6]  R235      -8.9159741997718811e-02
    z[0,1,6]  R236      1.8927218019962311e-01
    z[0,1,6]  R237      -0.0878983587026596
    z[0,1,6]  R238      9.3493327498435974e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R239      -1
    z[1,0,0]  R240      1
    z[1,0,0]  R253      -2.7622032165527344e-01
    z[1,0,0]  R254      7.2170570492744446e-02
    z[1,0,0]  R255      -2.1570110321044922e-01
    z[1,0,0]  R256      -1.9471928477287292e-01
    z[1,0,0]  R257      1.9177286326885223e-01
    z[1,0,0]  R258      -9.2172406613826752e-02
    z[1,0,0]  R259      -2.2240076959133148e-01
    z[1,0,0]  R260      -1.5014803968369961e-02
    z[1,0,0]  R261      7.7013963460922241e-01
    z[1,0,0]  R262      3.6218479275703430e-01
    z[1,0,0]  R263      -9.2576093971729279e-02
    z[1,0,0]  R264      -6.1049032211303711e-01
    z[1,0,0]  R265      2.5484472513198853e-01
    z[1,0,0]  R266      5.2137277089059353e-03
    z[1,0,0]  R267      -0.604136049747467
    z[1,0,0]  R268      -8.2193642854690552e-01
    z[1,0,0]  R269      0.663940966129303
    z[1,0,0]  R270      4.0393376350402832e-01
    z[1,0,0]  R271      -2.0123668015003204e-01
    z[1,0,0]  R272      -3.8823267817497253e-01
    z[1,0,0]  R273      -2.7819445729255676e-01
    z[1,0,0]  R274      -1.8396872282028198e-01
    z[1,0,0]  R275      -0.406222403049469
    z[1,0,0]  R276      -1.1003332585096359e-01
    z[1,0,0]  R277      -9.8708763718605042e-02
    z[1,0,0]  R278      4.4714215397834778e-01
    z[1,0,0]  R279      -3.8053756952285767e-01
    z[1,0,0]  R280      2.1977389231324196e-02
    z[1,0,0]  R281      -1.4427816867828369e-01
    z[1,0,0]  R282      8.8784933090209961e-01
    z[1,0,0]  R283      -1.9358487427234650e-01
    z[1,0,0]  R284      -2.9861995577812195e-01
    z[1,0,0]  R285      -2.8213111683726311e-02
    z[1,0,0]  R286      1.6459727287292480e-01
    z[1,0,0]  R287      3.3137798309326172e-01
    z[1,0,0]  R288      2.3689137399196625e-01
    z[1,0,0]  R289      -2.9080209136009216e-01
    z[1,0,0]  R290      -5.5311852693557739e-01
    z[1,0,0]  R291      5.9021119959652424e-03
    z[1,0,0]  R292      5.5397635698318481e-01
    z[1,0,0]  R293      1.1108215898275375e-01
    z[1,0,0]  R294      -3.1310665607452393e-01
    z[1,0,0]  R295      0.181345596909523
    z[1,0,0]  R296      -9.9855475127696991e-02
    z[1,0,0]  R297      -4.7264367341995239e-01
    z[1,0,0]  R298      1.7552487552165985e-01
    z[1,0,0]  R299      1.1585873365402222e-01
    z[1,0,0]  R300      2.7301779389381409e-01
    z[1,0,0]  R301      3.6947306990623474e-01
    z[1,0,0]  R302      1.2942981719970703e-01
    z[1,0,0]  R303      1.4334422349929810e-01
    z[1,0,0]  R304      -2.0050154998898506e-03
    z[1,0,0]  R305      -3.4409871697425842e-01
    z[1,0,0]  R306      -0.0753057599067688
    z[1,0,0]  R307      -4.1856479644775391e-01
    z[1,0,0]  R308      -5.2887761592864990e-01
    z[1,0,0]  R309      3.8372308015823364e-01
    z[1,0,0]  R310      1.8392139673233032e-01
    z[1,0,0]  R311      0.756458580493927
    z[1,0,0]  R312      4.1215223073959351e-01
    z[1,0,0]  R313      -2.9381206259131432e-02
    z[1,0,0]  R314      -1.9953933358192444e-01
    z[1,0,0]  R315      0.0612550750374794
    z[1,0,0]  R316      -5.5652207136154175e-01
    z[1,0,0]  R317      2.4315534532070160e-01
    z[1,0,0]  R318      8.9159369468688965e-01
    z[1,0,0]  R319      8.5959982872009277e-01
    z[1,0,0]  R320      8.3808708190917969e-01
    z[1,0,0]  R321      8.2671457529067993e-01
    z[1,0,0]  R322      8.2864439487457275e-01
    z[1,0,0]  R323      5.2258968353271484e-01
    z[1,0,0]  R324      2.7141281962394714e-01
    z[1,0,0]  R325      -5.9181714057922363e-01
    z[1,0,0]  R326      -5.4779791831970215e-01
    z[1,0,0]  R327      6.4446645975112915e-01
    z[1,0,0]  R328      2.4215668439865112e-01
    z[1,0,0]  R329      2.7344632148742676e-01
    z[1,0,0]  R330      -0.502898633480072
    z[1,0,0]  R331      -5.9624433517456055e-01
    z[1,0,0]  R332      -0.508691668510437
    z[1,0,0]  R333      -2.1039625629782677e-02
    z[1,0,0]  R334      -6.3955950736999512e-01
    z[1,0,0]  R335      3.8346239924430847e-01
    z[1,0,0]  R336      -5.8709084987640381e-01
    z[1,0,0]  R337      -5.7609003782272339e-01
    z[1,0,0]  R338      -1.5098403394222260e-01
    z[1,0,0]  R339      3.4997817873954773e-01
    z[1,0,0]  R340      1.9455881416797638e-01
    z[1,0,0]  R341      -1.0306473821401596e-01
    z[1,0,0]  R342      7.2607177495956421e-01
    z[1,0,0]  R343      3.5984647274017334e-01
    z[1,0,0]  R344      4.0053266286849976e-01
    z[1,0,0]  R345      2.8451833128929138e-01
    z[1,0,0]  R346      -4.9256992340087891e-01
    z[1,0,0]  R347      5.8289057016372681e-01
    z[1,0,0]  R348      3.2223412394523621e-01
    z[1,0,0]  R349      5.2027565240859985e-01
    z[1,0,0]  R350      8.9749681949615479e-01
    z[1,0,0]  R351      7.7735997736454010e-02
    z[1,0,0]  R352      4.8377230763435364e-01
    z[1,0,0]  R353      3.3621346950531006e-01
    z[1,0,0]  R354      4.4479519128799438e-01
    z[1,0,0]  R355      6.3285452127456665e-01
    z[1,0,0]  R356      2.5843468308448792e-01
    z[1,0,0]  R357      4.4759970158338547e-02
    z[1,0,0]  R358      1.8317356705665588e-01
    z[1,0,0]  R359      -1.5814730897545815e-02
    z[1,0,0]  R360      7.2875326871871948e-01
    z[1,0,0]  R361      1.0331102460622787e-01
    z[1,0,0]  R362      -4.7458952665328979e-01
    z[1,0,0]  R363      5.9786039590835571e-01
    z[1,0,0]  R364      2.3851300776004791e-01
    z[1,0,0]  R365      2.6434731483459473e-01
    z[1,0,0]  R366      7.2767162322998047e-01
    z[1,0,0]  R367      5.7752884924411774e-02
    z[1,0,0]  R368      -0.486916184425354
    z[1,0,0]  R369      4.2904263734817505e-01
    z[1,0,0]  R370      1.7858929932117462e-01
    z[1,0,0]  R371      -1.9521364942193031e-02
    z[1,0,0]  R372      2.5948521494865417e-01
    z[1,0,0]  R373      6.5763312578201294e-01
    z[1,0,0]  R374      3.5264107584953308e-01
    z[1,0,0]  R375      5.9940475225448608e-01
    z[1,0,0]  R376      0.693200409412384
    z[1,0,0]  R377      -5.1868766546249390e-01
    z[1,0,0]  R378      -5.5990439653396606e-01
    z[1,0,0]  R379      1.3997834920883179e-01
    z[1,0,0]  R380      -6.3276566565036774e-02
    z[1,0,0]  R381      0.837135374546051
    z[1,0,0]  R382      9.2894226312637329e-01
    z[1,0,0]  R383      -6.2266051769256592e-01
    z[1,0,0]  R384      7.6999038457870483e-01
    z[1,0,0]  R385      -4.2529711127281189e-01
    z[1,0,0]  R386      -5.8424901962280273e-01
    z[1,0,0]  R387      5.6201267242431641e-01
    z[1,0,0]  R388      -1.1042773723602295e-01
    z[1,0,0]  R389      2.5928720831871033e-01
    z[1,0,0]  R390      -3.6640220880508423e-01
    z[1,0,0]  R391      5.1088446378707886e-01
    z[1,0,0]  R392      5.1166445016860962e-01
    z[1,0,0]  R393      3.0087643861770630e-01
    z[1,0,0]  R394      -3.6423809826374054e-02
    z[1,0,0]  R395      6.0400050878524780e-01
    z[1,0,0]  R396      5.4995787143707275e-01
    z[1,0,0]  R397      4.2954602837562561e-01
    z[1,0,0]  R398      -4.6089485287666321e-01
    z[1,0,0]  R399      -1.0036650300025940e-01
    z[1,0,0]  R400      1.5186357498168945e-01
    z[1,0,0]  R401      1.5081593394279480e-01
    z[1,0,0]  R402      4.9989837408065796e-01
    z[1,0,0]  R403      2.5372245907783508e-01
    z[1,0,0]  R404      7.4551028013229370e-01
    z[1,0,0]  R405      1.8130171298980713e-01
    z[1,0,0]  R406      -5.2088344097137451e-01
    z[1,0,0]  R407      5.0005221366882324e-01
    z[1,0,0]  R408      0.537525475025177
    z[1,0,0]  R409      -0.516525387763977
    z[1,0,0]  R410      -2.1711751818656921e-01
    z[1,0,0]  R411      -6.7841041088104248e-01
    z[1,0,0]  R412      6.5063852071762085e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R241      -1
    z[1,0,1]  R242      1
    z[1,0,1]  R253      5.7023260742425919e-02
    z[1,0,1]  R254      -4.0100085735321045e-01
    z[1,0,1]  R255      -4.0556874871253967e-01
    z[1,0,1]  R256      -4.6332615613937378e-01
    z[1,0,1]  R257      -2.3702657222747803e-01
    z[1,0,1]  R258      2.2285167872905731e-01
    z[1,0,1]  R259      2.9661893844604492e-01
    z[1,0,1]  R260      -3.8518407940864563e-01
    z[1,0,1]  R261      9.2216655611991882e-02
    z[1,0,1]  R262      -3.6164233088493347e-01
    z[1,0,1]  R263      -6.8206888437271118e-01
    z[1,0,1]  R264      -5.1864419132471085e-02
    z[1,0,1]  R265      -5.4454110562801361e-02
    z[1,0,1]  R266      0.0367298349738121
    z[1,0,1]  R267      -3.0298924073576927e-02
    z[1,0,1]  R268      6.8774081766605377e-02
    z[1,0,1]  R269      1.3289210200309753e-01
    z[1,0,1]  R270      -1.5048886835575104e-01
    z[1,0,1]  R271      -2.6078957319259644e-01
    z[1,0,1]  R272      3.0239865183830261e-01
    z[1,0,1]  R273      -3.2169643044471741e-01
    z[1,0,1]  R274      3.1752693653106689e-01
    z[1,0,1]  R275      -2.7491134405136108e-01
    z[1,0,1]  R276      -2.0878896117210388e-01
    z[1,0,1]  R277      -4.4018852710723877e-01
    z[1,0,1]  R278      -1.1904118955135345e-01
    z[1,0,1]  R279      3.8342788815498352e-01
    z[1,0,1]  R280      7.4422186613082886e-01
    z[1,0,1]  R281      -2.3468953371047974e-01
    z[1,0,1]  R282      0.400115966796875
    z[1,0,1]  R283      -1.1934275925159454e-01
    z[1,0,1]  R284      6.0335206799209118e-03
    z[1,0,1]  R285      2.9801445081830025e-02
    z[1,0,1]  R286      3.9609622955322266e-01
    z[1,0,1]  R287      0.460801899433136
    z[1,0,1]  R288      -4.2347031831741333e-01
    z[1,0,1]  R289      5.9909218549728394e-01
    z[1,0,1]  R290      -2.5118863582611084e-01
    z[1,0,1]  R291      -4.5285689830780029e-01
    z[1,0,1]  R292      2.9667595028877258e-01
    z[1,0,1]  R293      -4.4780600070953369e-01
    z[1,0,1]  R294      0.479547381401062
    z[1,0,1]  R295      -1.1395521461963654e-01
    z[1,0,1]  R296      5.7864004373550415e-01
    z[1,0,1]  R297      -2.3511280119419098e-01
    z[1,0,1]  R298      3.3842352032661438e-01
    z[1,0,1]  R299      -6.4883500337600708e-01
    z[1,0,1]  R300      -5.0559818744659424e-01
    z[1,0,1]  R301      0.500224769115448
    z[1,0,1]  R302      -1.5252690762281418e-02
    z[1,0,1]  R303      2.0094932615756989e-01
    z[1,0,1]  R304      -4.3286976218223572e-01
    z[1,0,1]  R305      3.8947391510009766e-01
    z[1,0,1]  R306      4.8887810111045837e-01
    z[1,0,1]  R307      -1.6817826032638550e-01
    z[1,0,1]  R308      -1.7984431982040405e-01
    z[1,0,1]  R309      1.6541364789009094e-01
    z[1,0,1]  R310      8.7534934282302856e-02
    z[1,0,1]  R311      1.3398897647857666e-01
    z[1,0,1]  R312      -3.3120420575141907e-01
    z[1,0,1]  R313      3.9884641766548157e-01
    z[1,0,1]  R314      4.5949053764343262e-01
    z[1,0,1]  R315      1.0078227519989014e-01
    z[1,0,1]  R316      2.0944228395819664e-02
    z[1,0,1]  R317      -4.8049259185791016e-01
    z[1,0,1]  R318      3.4001204371452332e-01
    z[1,0,1]  R319      2.5614374876022339e-01
    z[1,0,1]  R320      0.4011210501194
    z[1,0,1]  R321      3.2489171624183655e-01
    z[1,0,1]  R322      2.7052381634712219e-01
    z[1,0,1]  R323      3.6833387613296509e-01
    z[1,0,1]  R324      7.9607349634170532e-01
    z[1,0,1]  R325      -4.1194394230842590e-01
    z[1,0,1]  R326      -3.9958181977272034e-01
    z[1,0,1]  R327      4.9775320291519165e-01
    z[1,0,1]  R328      7.2175461053848267e-01
    z[1,0,1]  R329      -5.8704257011413574e-01
    z[1,0,1]  R330      -6.2557137012481689e-01
    z[1,0,1]  R331      -4.7308912873268127e-01
    z[1,0,1]  R332      -6.1057257652282715e-01
    z[1,0,1]  R333      -8.6844104528427124e-01
    z[1,0,1]  R334      -3.7819364666938782e-01
    z[1,0,1]  R335      7.8421306610107422e-01
    z[1,0,1]  R336      -4.6251523494720459e-01
    z[1,0,1]  R337      -6.7398720979690552e-01
    z[1,0,1]  R338      -0.629465639591217
    z[1,0,1]  R339      7.1435183286666870e-01
    z[1,0,1]  R340      7.6606941223144531e-01
    z[1,0,1]  R341      -0.630012571811676
    z[1,0,1]  R342      3.3499780297279358e-01
    z[1,0,1]  R343      8.1709533929824829e-01
    z[1,0,1]  R344      7.3661535978317261e-01
    z[1,0,1]  R345      7.3152804374694824e-01
    z[1,0,1]  R346      -3.0366113781929016e-01
    z[1,0,1]  R347      5.0897938013076782e-01
    z[1,0,1]  R348      6.3099247217178345e-01
    z[1,0,1]  R349      3.2106861472129822e-01
    z[1,0,1]  R350      -1.1713733896613121e-02
    z[1,0,1]  R351      0.736412763595581
    z[1,0,1]  R352      7.4944078922271729e-02
    z[1,0,1]  R353      8.3493673801422119e-01
    z[1,0,1]  R354      6.7021858692169189e-01
    z[1,0,1]  R355      1.0754422843456268e-01
    z[1,0,1]  R356      6.6958451271057129e-01
    z[1,0,1]  R357      7.9599660634994507e-01
    z[1,0,1]  R358      -2.4713924527168274e-01
    z[1,0,1]  R359      -0.864155650138855
    z[1,0,1]  R360      3.7200577557086945e-02
    z[1,0,1]  R361      0.793024480342865
    z[1,0,1]  R362      -5.6740152835845947e-01
    z[1,0,1]  R363      3.6730918288230896e-01
    z[1,0,1]  R364      8.8114857673645020e-01
    z[1,0,1]  R365      -7.8086805343627930e-01
    z[1,0,1]  R366      7.9446837306022644e-02
    z[1,0,1]  R367      -2.2397871315479279e-01
    z[1,0,1]  R368      -1.8734152615070343e-01
    z[1,0,1]  R369      -7.8264009952545166e-01
    z[1,0,1]  R370      -3.5057049989700317e-01
    z[1,0,1]  R371      -7.8658795356750488e-01
    z[1,0,1]  R372      -8.6471116542816162e-01
    z[1,0,1]  R373      3.4992757439613342e-01
    z[1,0,1]  R374      -6.2392234802246094e-01
    z[1,0,1]  R375      1.8919041380286217e-02
    z[1,0,1]  R376      -2.0074361562728882e-01
    z[1,0,1]  R377      3.8524657487869263e-02
    z[1,0,1]  R378      -3.3165480941534042e-02
    z[1,0,1]  R379      7.1194154024124146e-01
    z[1,0,1]  R380      -9.2100965976715088e-01
    z[1,0,1]  R381      -3.2712038606405258e-02
    z[1,0,1]  R382      2.0799531042575836e-01
    z[1,0,1]  R383      -1.7363831400871277e-01
    z[1,0,1]  R384      2.6390469074249268e-01
    z[1,0,1]  R385      -8.0534279346466064e-01
    z[1,0,1]  R386      -3.3154079318046570e-01
    z[1,0,1]  R387      3.5923457145690918e-01
    z[1,0,1]  R388      -0.895881712436676
    z[1,0,1]  R389      6.7885470390319824e-01
    z[1,0,1]  R390      -7.6817399263381958e-01
    z[1,0,1]  R391      -6.4891618490219116e-01
    z[1,0,1]  R392      -0.37047278881073
    z[1,0,1]  R393      9.1027367115020752e-01
    z[1,0,1]  R394      -2.2061090171337128e-01
    z[1,0,1]  R395      6.1865431070327759e-01
    z[1,0,1]  R396      6.5419411659240723e-01
    z[1,0,1]  R397      0.648796021938324
    z[1,0,1]  R398      -1.0930936038494110e-01
    z[1,0,1]  R399      -6.4319121837615967e-01
    z[1,0,1]  R400      7.4658292531967163e-01
    z[1,0,1]  R401      -1.6936777532100677e-01
    z[1,0,1]  R402      5.3226995468139648e-01
    z[1,0,1]  R403      8.5525131225585938e-01
    z[1,0,1]  R404      1.5650014579296112e-01
    z[1,0,1]  R405      2.2968946397304535e-01
    z[1,0,1]  R406      -8.4850661456584930e-02
    z[1,0,1]  R407      -3.3790320158004761e-02
    z[1,0,1]  R408      -2.8482902050018311e-01
    z[1,0,1]  R409      1.9975388050079346e-01
    z[1,0,1]  R410      -6.9128429889678955e-01
    z[1,0,1]  R411      -1.3931839168071747e-01
    z[1,0,1]  R412      -3.0566978454589844e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R243      -1
    z[1,0,2]  R244      1
    z[1,0,2]  R253      5.7882523536682129e-01
    z[1,0,2]  R254      4.1696330904960632e-01
    z[1,0,2]  R255      5.1958316564559937e-01
    z[1,0,2]  R256      5.7546877861022949e-01
    z[1,0,2]  R257      2.1274326741695404e-01
    z[1,0,2]  R258      7.5553268194198608e-01
    z[1,0,2]  R259      4.0897557139396667e-01
    z[1,0,2]  R260      9.6684433519840240e-03
    z[1,0,2]  R261      -3.0653487890958786e-02
    z[1,0,2]  R262      7.4481427669525146e-02
    z[1,0,2]  R263      -4.2489755153656006e-01
    z[1,0,2]  R264      -2.0523147657513618e-02
    z[1,0,2]  R265      -3.4373795986175537e-01
    z[1,0,2]  R266      9.5099993050098419e-02
    z[1,0,2]  R267      -2.2712003439664841e-02
    z[1,0,2]  R268      2.0225118845701218e-02
    z[1,0,2]  R269      -8.4506928920745850e-02
    z[1,0,2]  R270      -1.7085234820842743e-01
    z[1,0,2]  R271      -9.8722055554389954e-02
    z[1,0,2]  R272      -1.4519126713275909e-01
    z[1,0,2]  R273      -2.3931415379047394e-01
    z[1,0,2]  R274      -3.5749744623899460e-02
    z[1,0,2]  R275      4.3033313751220703e-01
    z[1,0,2]  R276      2.3229060694575310e-02
    z[1,0,2]  R277      -6.8220630288124084e-02
    z[1,0,2]  R278      -2.4715360999107361e-01
    z[1,0,2]  R279      3.8568194955587387e-02
    z[1,0,2]  R280      3.6008810997009277e-01
    z[1,0,2]  R281      1.1655066907405853e-01
    z[1,0,2]  R282      -1.4073415659368038e-02
    z[1,0,2]  R283      3.5025379620492458e-03
    z[1,0,2]  R284      2.5871858000755310e-01
    z[1,0,2]  R285      5.0503186881542206e-02
    z[1,0,2]  R286      -1.9696229696273804e-01
    z[1,0,2]  R287      1.0958162695169449e-01
    z[1,0,2]  R288      -3.6883754655718803e-03
    z[1,0,2]  R289      8.8690489530563354e-02
    z[1,0,2]  R290      9.6120364964008331e-02
    z[1,0,2]  R291      2.3620733618736267e-01
    z[1,0,2]  R292      -8.8324621319770813e-02
    z[1,0,2]  R293      -4.0031763911247253e-01
    z[1,0,2]  R294      1.7647184431552887e-01
    z[1,0,2]  R295      2.7075189352035522e-01
    z[1,0,2]  R296      5.7719075679779053e-01
    z[1,0,2]  R297      8.3714880049228668e-02
    z[1,0,2]  R298      -2.6952880620956421e-01
    z[1,0,2]  R299      1.6323316097259521e-01
    z[1,0,2]  R300      -2.3205693066120148e-01
    z[1,0,2]  R301      7.0322789251804352e-02
    z[1,0,2]  R302      6.2086915969848633e-01
    z[1,0,2]  R303      2.3653939366340637e-02
    z[1,0,2]  R304      -2.4569955468177795e-01
    z[1,0,2]  R305      3.2196617126464844e-01
    z[1,0,2]  R306      4.1821566224098206e-01
    z[1,0,2]  R307      3.5133041441440582e-02
    z[1,0,2]  R308      -1.4320272952318192e-02
    z[1,0,2]  R309      1.5297865867614746e-01
    z[1,0,2]  R310      6.3117647171020508e-01
    z[1,0,2]  R311      -1.8626330420374870e-02
    z[1,0,2]  R312      -3.0767264962196350e-01
    z[1,0,2]  R313      2.6093924045562744e-01
    z[1,0,2]  R314      3.9941665530204773e-01
    z[1,0,2]  R315      -2.3553118109703064e-01
    z[1,0,2]  R316      -6.9350576959550381e-03
    z[1,0,2]  R317      1.9941753149032593e-01
    z[1,0,2]  R318      2.5417020916938782e-01
    z[1,0,2]  R319      -2.1761699020862579e-01
    z[1,0,2]  R320      6.5196588635444641e-02
    z[1,0,2]  R321      -3.3122289180755615e-01
    z[1,0,2]  R322      -3.2163041830062866e-01
    z[1,0,2]  R323      7.5606632232666016e-01
    z[1,0,2]  R324      -1.2401672452688217e-01
    z[1,0,2]  R325      -3.7869594991207123e-02
    z[1,0,2]  R326      -0.0090639628469944
    z[1,0,2]  R327      2.5722339749336243e-01
    z[1,0,2]  R328      4.9583235383033752e-01
    z[1,0,2]  R329      -3.1884562224149704e-02
    z[1,0,2]  R330      -1.4853253960609436e-01
    z[1,0,2]  R331      -6.4209826290607452e-02
    z[1,0,2]  R332      -1.8338464200496674e-02
    z[1,0,2]  R333      -9.8827652633190155e-02
    z[1,0,2]  R334      -4.4583427906036377e-01
    z[1,0,2]  R335      -2.6195909827947617e-02
    z[1,0,2]  R336      -3.5094434022903442e-01
    z[1,0,2]  R337      -3.7738955020904541e-01
    z[1,0,2]  R338      -1.5090338885784149e-01
    z[1,0,2]  R339      1.1762766540050507e-01
    z[1,0,2]  R340      -1.6124796122312546e-02
    z[1,0,2]  R341      -1.8149559199810028e-01
    z[1,0,2]  R342      2.9928576946258545e-01
    z[1,0,2]  R343      -1.2259004870429635e-03
    z[1,0,2]  R344      3.9859589934349060e-01
    z[1,0,2]  R345      4.5946672558784485e-01
    z[1,0,2]  R346      -2.7820277214050293e-01
    z[1,0,2]  R347      4.1098093986511230e-01
    z[1,0,2]  R348      -5.0525808334350586e-01
    z[1,0,2]  R349      5.1737630367279053e-01
    z[1,0,2]  R350      1.2611895799636841e-01
    z[1,0,2]  R351      -6.1552878469228745e-02
    z[1,0,2]  R352      4.1487866640090942e-01
    z[1,0,2]  R353      -1.4426006376743317e-01
    z[1,0,2]  R354      2.4643549323081970e-01
    z[1,0,2]  R355      4.1255244612693787e-01
    z[1,0,2]  R356      -5.7148575782775879e-01
    z[1,0,2]  R357      -4.5504567027091980e-01
    z[1,0,2]  R358      1.2018267810344696e-01
    z[1,0,2]  R359      1.8982850015163422e-02
    z[1,0,2]  R360      4.3548887968063354e-01
    z[1,0,2]  R361      -5.8144873380661011e-01
    z[1,0,2]  R362      -1.5069223940372467e-01
    z[1,0,2]  R363      5.2009713649749756e-01
    z[1,0,2]  R364      -1.9687506556510925e-01
    z[1,0,2]  R365      0.0201080534607172
    z[1,0,2]  R366      5.2347022294998169e-01
    z[1,0,2]  R367      -1.1046304553747177e-01
    z[1,0,2]  R368      -6.4911562204360962e-01
    z[1,0,2]  R369      -4.1073363274335861e-02
    z[1,0,2]  R370      -1.6348633170127869e-01
    z[1,0,2]  R371      -1.5209870040416718e-01
    z[1,0,2]  R372      -1.8222853541374207e-01
    z[1,0,2]  R373      5.5721467733383179e-01
    z[1,0,2]  R374      -1.1913654953241348e-01
    z[1,0,2]  R375      4.4215241074562073e-01
    z[1,0,2]  R376      2.7167335152626038e-01
    z[1,0,2]  R377      -3.1831446290016174e-01
    z[1,0,2]  R378      -2.2658412158489227e-01
    z[1,0,2]  R379      -1.0902421921491623e-01
    z[1,0,2]  R380      -1.0851480066776276e-01
    z[1,0,2]  R381      1.1226566135883331e-01
    z[1,0,2]  R382      -5.3804680705070496e-02
    z[1,0,2]  R383      -4.2838653922080994e-01
    z[1,0,2]  R384      5.1253533363342285e-01
    z[1,0,2]  R385      -2.6043480634689331e-01
    z[1,0,2]  R386      -4.9675479531288147e-01
    z[1,0,2]  R387      6.2754553556442261e-01
    z[1,0,2]  R388      -1.7652894556522369e-01
    z[1,0,2]  R389      1.6643513739109039e-01
    z[1,0,2]  R390      -2.4202552437782288e-01
    z[1,0,2]  R391      2.7322193980216980e-01
    z[1,0,2]  R392      4.3216076493263245e-01
    z[1,0,2]  R393      4.0930751711130142e-02
    z[1,0,2]  R394      -3.2603389024734497e-01
    z[1,0,2]  R395      2.0815475285053253e-01
    z[1,0,2]  R396      -1.8299816176295280e-02
    z[1,0,2]  R397      1.6122369468212128e-01
    z[1,0,2]  R398      -3.9493107795715332e-01
    z[1,0,2]  R399      -1.2309246696531773e-02
    z[1,0,2]  R400      -7.8025050461292267e-02
    z[1,0,2]  R401      2.3661802709102631e-01
    z[1,0,2]  R402      -0.338933527469635
    z[1,0,2]  R403      -4.0052774548530579e-01
    z[1,0,2]  R404      5.3929162025451660e-01
    z[1,0,2]  R405      -2.8605839610099792e-01
    z[1,0,2]  R406      -7.1341377496719360e-01
    z[1,0,2]  R407      6.6442453861236572e-01
    z[1,0,2]  R408      5.2587682008743286e-01
    z[1,0,2]  R409      -2.2238335013389587e-01
    z[1,0,2]  R410      -2.7310755848884583e-01
    z[1,0,2]  R411      -2.7657121419906616e-01
    z[1,0,2]  R412      -1.7558740451931953e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R245      -1
    z[1,0,3]  R246      1
    z[1,0,3]  R253      -2.8136521577835083e-01
    z[1,0,3]  R254      -5.2662551403045654e-01
    z[1,0,3]  R255      -6.1233186721801758e-01
    z[1,0,3]  R256      -3.1960594654083252e-01
    z[1,0,3]  R257      -4.3368527293205261e-01
    z[1,0,3]  R258      -5.1076197624206543e-01
    z[1,0,3]  R259      -8.0525797605514526e-01
    z[1,0,3]  R260      -5.2254360914230347e-01
    z[1,0,3]  R261      -4.2296999692916870e-01
    z[1,0,3]  R262      4.8478193581104279e-02
    z[1,0,3]  R263      -1.8497726321220398e-01
    z[1,0,3]  R264      7.9207018017768860e-02
    z[1,0,3]  R265      3.8945192098617554e-01
    z[1,0,3]  R266      0.422821044921875
    z[1,0,3]  R267      -2.8210881352424622e-01
    z[1,0,3]  R268      -1.1807091534137726e-01
    z[1,0,3]  R269      3.5757082700729370e-01
    z[1,0,3]  R270      3.3467337489128113e-01
    z[1,0,3]  R271      2.5352901220321655e-01
    z[1,0,3]  R272      3.3100441098213196e-01
    z[1,0,3]  R273      -5.6162250041961670e-01
    z[1,0,3]  R274      5.2022719383239746e-01
    z[1,0,3]  R275      5.4889374971389771e-01
    z[1,0,3]  R276      4.7716978192329407e-01
    z[1,0,3]  R277      -3.4345608949661255e-01
    z[1,0,3]  R278      3.9964485168457031e-01
    z[1,0,3]  R279      3.8020107150077820e-01
    z[1,0,3]  R280      3.6080777645111084e-01
    z[1,0,3]  R281      3.6020430922508240e-01
    z[1,0,3]  R282      1.0170537978410721e-01
    z[1,0,3]  R283      -0.731119692325592
    z[1,0,3]  R284      5.0512790679931641e-01
    z[1,0,3]  R285      4.7510275244712830e-01
    z[1,0,3]  R286      4.7052279114723206e-01
    z[1,0,3]  R287      4.8424473404884338e-01
    z[1,0,3]  R288      4.5583185553550720e-01
    z[1,0,3]  R289      4.4839361310005188e-01
    z[1,0,3]  R290      4.3676459789276123e-01
    z[1,0,3]  R291      4.2668148875236511e-01
    z[1,0,3]  R292      4.2736229300498962e-01
    z[1,0,3]  R293      -7.1151775121688843e-01
    z[1,0,3]  R294      5.5927473306655884e-01
    z[1,0,3]  R295      5.3567820787429810e-01
    z[1,0,3]  R296      0.525505781173706
    z[1,0,3]  R297      4.9212706089019775e-01
    z[1,0,3]  R298      4.8334461450576782e-01
    z[1,0,3]  R299      4.8629650473594666e-01
    z[1,0,3]  R300      4.3330281972885132e-01
    z[1,0,3]  R301      4.1259589791297913e-01
    z[1,0,3]  R302      4.3963640928268433e-01
    z[1,0,3]  R303      0.805002748966217
    z[1,0,3]  R304      -7.4258393049240112e-01
    z[1,0,3]  R305      6.9236713647842407e-01
    z[1,0,3]  R306      6.2224221229553223e-01
    z[1,0,3]  R307      5.1679807901382446e-01
    z[1,0,3]  R308      -5.6394052505493164e-01
    z[1,0,3]  R309      0.447330117225647
    z[1,0,3]  R310      4.2527988553047180e-01
    z[1,0,3]  R311      4.0102961659431458e-01
    z[1,0,3]  R312      3.7532398104667664e-01
    z[1,0,3]  R313      -5.9658187627792358e-01
    z[1,0,3]  R314      6.4064908027648926e-01
    z[1,0,3]  R315      5.1169615983963013e-01
    z[1,0,3]  R316      -3.3814874291419983e-01
    z[1,0,3]  R317      5.0888514518737793e-01
    z[1,0,3]  R318      -5.9023287147283554e-02
    z[1,0,3]  R319      -2.7531739324331284e-02
    z[1,0,3]  R320      -2.9218414425849915e-01
    z[1,0,3]  R321      -2.6991435885429382e-01
    z[1,0,3]  R322      -9.8402373492717743e-02
    z[1,0,3]  R323      0.00919360015541315
    z[1,0,3]  R324      2.7194846421480179e-02
    z[1,0,3]  R325      -3.4394222497940063e-01
    z[1,0,3]  R326      -2.9011097550392151e-01
    z[1,0,3]  R327      2.4903476238250732e-01
    z[1,0,3]  R328      -2.2532276809215546e-01
    z[1,0,3]  R329      0.312175452709198
    z[1,0,3]  R330      -3.8715666532516479e-01
    z[1,0,3]  R331      -2.5482279062271118e-01
    z[1,0,3]  R332      -5.9454911947250366e-01
    z[1,0,3]  R333      3.3574298024177551e-01
    z[1,0,3]  R334      -2.1461232006549835e-01
    z[1,0,3]  R335      -1.5855069458484650e-01
    z[1,0,3]  R336      -4.1359403729438782e-01
    z[1,0,3]  R337      -1.9654460251331329e-01
    z[1,0,3]  R338      6.0009920597076416e-01
    z[1,0,3]  R339      3.2986736297607422e-01
    z[1,0,3]  R340      -1.6660936176776886e-01
    z[1,0,3]  R341      2.6079794764518738e-01
    z[1,0,3]  R342      1.9063760340213776e-01
    z[1,0,3]  R343      -1.6288323700428009e-01
    z[1,0,3]  R344      -0.350488543510437
    z[1,0,3]  R345      5.7509769685566425e-03
    z[1,0,3]  R346      -6.6776730120182037e-02
    z[1,0,3]  R347      3.5175219178199768e-01
    z[1,0,3]  R348      -9.1895036399364471e-02
    z[1,0,3]  R349      -1.6132335364818573e-01
    z[1,0,3]  R350      -3.7675538659095764e-01
    z[1,0,3]  R351      5.1050532609224319e-02
    z[1,0,3]  R352      -3.3609023690223694e-01
    z[1,0,3]  R353      9.2560619115829468e-02
    z[1,0,3]  R354      4.1062968969345093e-01
    z[1,0,3]  R355      -4.9150732159614563e-01
    z[1,0,3]  R356      3.0427560210227966e-01
    z[1,0,3]  R357      -3.7423957139253616e-02
    z[1,0,3]  R358      7.6432478427886963e-01
    z[1,0,3]  R359      0.371351420879364
    z[1,0,3]  R360      -0.270082950592041
    z[1,0,3]  R361      -5.0245355814695358e-02
    z[1,0,3]  R362      -3.0831021070480347e-01
    z[1,0,3]  R363      -2.0431217551231384e-01
    z[1,0,3]  R364      -1.0609222948551178e-01
    z[1,0,3]  R365      0.522624135017395
    z[1,0,3]  R366      -2.4257950484752655e-01
    z[1,0,3]  R367      8.3517897129058838e-01
    z[1,0,3]  R368      -2.3713992536067963e-01
    z[1,0,3]  R369      1.7736728489398956e-01
    z[1,0,3]  R370      4.9250704050064087e-01
    z[1,0,3]  R371      3.4422501921653748e-02
    z[1,0,3]  R372      -2.3740322887897491e-01
    z[1,0,3]  R373      -1.6251015663146973e-01
    z[1,0,3]  R374      0.574330747127533
    z[1,0,3]  R375      2.0639950037002563e-01
    z[1,0,3]  R376      5.0674965605139732e-03
    z[1,0,3]  R377      -1.4749768376350403e-01
    z[1,0,3]  R378      -1.6726320981979370e-01
    z[1,0,3]  R379      -2.8104493021965027e-01
    z[1,0,3]  R380      -0.0925268605351448
    z[1,0,3]  R381      1.2001358903944492e-02
    z[1,0,3]  R382      -4.5203246176242828e-02
    z[1,0,3]  R383      -3.4919625520706177e-01
    z[1,0,3]  R384      -1.7929084599018097e-02
    z[1,0,3]  R385      2.7303194999694824e-01
    z[1,0,3]  R386      -3.5218429565429688e-01
    z[1,0,3]  R387      3.2124549150466919e-02
    z[1,0,3]  R388      -1.8332313047721982e-03
    z[1,0,3]  R389      -4.7861579060554504e-01
    z[1,0,3]  R390      -2.9377844929695129e-01
    z[1,0,3]  R391      -3.6752650141716003e-01
    z[1,0,3]  R392      -4.6634238958358765e-01
    z[1,0,3]  R393      -7.7418766915798187e-02
    z[1,0,3]  R394      8.1320095062255859e-01
    z[1,0,3]  R395      -3.8583735004067421e-03
    z[1,0,3]  R396      3.5540437698364258e-01
    z[1,0,3]  R397      3.0389702320098877e-01
    z[1,0,3]  R398      -0.0907410979270935
    z[1,0,3]  R399      6.5078479051589966e-01
    z[1,0,3]  R400      2.4905851483345032e-01
    z[1,0,3]  R401      6.0266852378845215e-01
    z[1,0,3]  R402      0.380577027797699
    z[1,0,3]  R403      -1.5043872594833374e-01
    z[1,0,3]  R404      -2.0054295659065247e-01
    z[1,0,3]  R405      5.1038622856140137e-01
    z[1,0,3]  R406      -3.4189623594284058e-01
    z[1,0,3]  R407      2.6827251911163330e-01
    z[1,0,3]  R408      -1.0436327010393143e-01
    z[1,0,3]  R409      3.3484068512916565e-01
    z[1,0,3]  R410      -2.3631818592548370e-01
    z[1,0,3]  R411      3.1567353010177612e-01
    z[1,0,3]  R412      -3.0971601605415344e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R247      -1
    z[1,0,4]  R248      1
    z[1,0,4]  R253      6.0072422027587891e-01
    z[1,0,4]  R254      2.4796561896800995e-01
    z[1,0,4]  R255      2.6029223203659058e-01
    z[1,0,4]  R256      3.1332916021347046e-01
    z[1,0,4]  R257      2.6376459002494812e-01
    z[1,0,4]  R258      -2.0386783778667450e-01
    z[1,0,4]  R259      3.7150572985410690e-02
    z[1,0,4]  R260      -7.5935405492782593e-01
    z[1,0,4]  R261      -0.399393767118454
    z[1,0,4]  R262      -7.1339696645736694e-01
    z[1,0,4]  R263      4.7217461466789246e-01
    z[1,0,4]  R264      -3.1844952702522278e-01
    z[1,0,4]  R265      8.1103682518005371e-01
    z[1,0,4]  R266      -7.1264576911926270e-01
    z[1,0,4]  R267      -4.0418615937232971e-01
    z[1,0,4]  R268      -1.7569592595100403e-01
    z[1,0,4]  R269      5.8281880617141724e-01
    z[1,0,4]  R270      -8.1347936391830444e-01
    z[1,0,4]  R271      -6.7264097929000854e-01
    z[1,0,4]  R272      0.714393138885498
    z[1,0,4]  R273      2.0473514497280121e-01
    z[1,0,4]  R274      7.4354684352874756e-01
    z[1,0,4]  R275      -3.6610189080238342e-01
    z[1,0,4]  R276      -6.7614614963531494e-01
    z[1,0,4]  R277      -6.5717041492462158e-01
    z[1,0,4]  R278      6.3501501083374023e-01
    z[1,0,4]  R279      -2.0388266444206238e-01
    z[1,0,4]  R280      -4.1412681341171265e-01
    z[1,0,4]  R281      -1.8338575959205627e-01
    z[1,0,4]  R282      0.08367870002985
    z[1,0,4]  R283      -3.0239738523960114e-02
    z[1,0,4]  R284      -4.8318862915039062e-01
    z[1,0,4]  R285      5.0756323337554932e-01
    z[1,0,4]  R286      -6.6026735305786133e-01
    z[1,0,4]  R287      -5.5032426118850708e-01
    z[1,0,4]  R288      -4.8070478439331055e-01
    z[1,0,4]  R289      -2.4454867839813232e-01
    z[1,0,4]  R290      5.6814938783645630e-01
    z[1,0,4]  R291      -3.5311231017112732e-01
    z[1,0,4]  R292      -2.4681656062602997e-01
    z[1,0,4]  R293      2.4790546298027039e-01
    z[1,0,4]  R294      -5.1099810749292374e-02
    z[1,0,4]  R295      -4.8351773619651794e-01
    z[1,0,4]  R296      -1.2792724370956421e-01
    z[1,0,4]  R297      6.3539731502532959e-01
    z[1,0,4]  R298      -5.8918994665145874e-01
    z[1,0,4]  R299      -3.1173002719879150e-01
    z[1,0,4]  R300      -5.7868313789367676e-01
    z[1,0,4]  R301      0.40912064909935
    z[1,0,4]  R302      -7.7711150050163269e-02
    z[1,0,4]  R303      -5.3043740987777710e-01
    z[1,0,4]  R304      2.0222522318363190e-01
    z[1,0,4]  R305      -1.1678715795278549e-01
    z[1,0,4]  R306      0.266841858625412
    z[1,0,4]  R307      6.5220171213150024e-01
    z[1,0,4]  R308      -4.9036750197410583e-01
    z[1,0,4]  R309      4.0584853291511536e-01
    z[1,0,4]  R310      -2.3033963143825531e-01
    z[1,0,4]  R311      3.1694963574409485e-01
    z[1,0,4]  R312      6.0401898622512817e-01
    z[1,0,4]  R313      2.3337426781654358e-01
    z[1,0,4]  R314      0.260204017162323
    z[1,0,4]  R315      6.2906432151794434e-01
    z[1,0,4]  R316      -5.1490652561187744e-01
    z[1,0,4]  R317      -4.7561657428741455e-01
    z[1,0,4]  R318      -5.8428540825843811e-02
    z[1,0,4]  R319      -0.365177184343338
    z[1,0,4]  R320      5.0869386643171310e-02
    z[1,0,4]  R321      -3.2056987285614014e-02
    z[1,0,4]  R322      -6.5538994967937469e-02
    z[1,0,4]  R323      1.2621775269508362e-01
    z[1,0,4]  R324      4.3071404099464417e-01
    z[1,0,4]  R325      3.2724443823099136e-02
    z[1,0,4]  R326      0.257503867149353
    z[1,0,4]  R327      3.4328451752662659e-01
    z[1,0,4]  R328      6.9391697645187378e-02
    z[1,0,4]  R329      -6.1629676818847656e-01
    z[1,0,4]  R330      3.7020224332809448e-01
    z[1,0,4]  R331      -3.1938779354095459e-01
    z[1,0,4]  R332      1.0658331215381622e-01
    z[1,0,4]  R333      7.4869275093078613e-02
    z[1,0,4]  R334      -1.6004875302314758e-01
    z[1,0,4]  R335      -2.3936209082603455e-01
    z[1,0,4]  R336      -0.0923909991979599
    z[1,0,4]  R337      -1.3523493707180023e-01
    z[1,0,4]  R338      -4.2124426364898682e-01
    z[1,0,4]  R339      -4.9312117695808411e-01
    z[1,0,4]  R340      -5.5431240797042847e-01
    z[1,0,4]  R341      -4.9785044789314270e-01
    z[1,0,4]  R342      3.2990675419569016e-02
    z[1,0,4]  R343      1.6835348308086395e-01
    z[1,0,4]  R344      8.0416696146130562e-03
    z[1,0,4]  R345      -1.0430266708135605e-01
    z[1,0,4]  R346      4.0577873587608337e-01
    z[1,0,4]  R347      -1.4028076827526093e-01
    z[1,0,4]  R348      3.4348881244659424e-01
    z[1,0,4]  R349      2.8809541463851929e-01
    z[1,0,4]  R350      1.9812004640698433e-02
    z[1,0,4]  R351      -2.5096428394317627e-01
    z[1,0,4]  R352      3.6399370431900024e-01
    z[1,0,4]  R353      2.0979216694831848e-01
    z[1,0,4]  R354      2.0947840809822083e-01
    z[1,0,4]  R355      1.3595707714557648e-01
    z[1,0,4]  R356      -1.9441372156143188e-01
    z[1,0,4]  R357      -7.6700314879417419e-02
    z[1,0,4]  R358      -5.0680446624755859e-01
    z[1,0,4]  R359      1.0740419477224350e-01
    z[1,0,4]  R360      -3.5317346453666687e-01
    z[1,0,4]  R361      -9.2873267829418182e-02
    z[1,0,4]  R362      4.1667231917381287e-01
    z[1,0,4]  R363      2.7484133839607239e-01
    z[1,0,4]  R364      -4.5726341195404530e-03
    z[1,0,4]  R365      5.4045025259256363e-02
    z[1,0,4]  R366      -1.1667429655790329e-01
    z[1,0,4]  R367      -4.5199674367904663e-01
    z[1,0,4]  R368      3.3902961015701294e-01
    z[1,0,4]  R369      -4.1172477602958679e-01
    z[1,0,4]  R370      7.5132292509078979e-01
    z[1,0,4]  R371      -3.4670770168304443e-01
    z[1,0,4]  R372      -2.2079072892665863e-01
    z[1,0,4]  R373      -1.1875396221876144e-01
    z[1,0,4]  R374      -3.1644481420516968e-01
    z[1,0,4]  R375      3.1604072451591492e-01
    z[1,0,4]  R376      4.8546192049980164e-01
    z[1,0,4]  R377      -0.128139927983284
    z[1,0,4]  R378      -0.0866321325302124
    z[1,0,4]  R379      2.3385412991046906e-01
    z[1,0,4]  R380      5.7850323617458344e-02
    z[1,0,4]  R381      0.257344514131546
    z[1,0,4]  R382      2.4556914344429970e-02
    z[1,0,4]  R383      -1.6494618356227875e-01
    z[1,0,4]  R384      -1.3364669680595398e-01
    z[1,0,4]  R385      -1.1719775199890137e-01
    z[1,0,4]  R386      2.2424438595771790e-01
    z[1,0,4]  R387      -0.00995875895023346
    z[1,0,4]  R388      -3.8880905508995056e-01
    z[1,0,4]  R389      4.3893387913703918e-01
    z[1,0,4]  R390      2.5893932580947876e-01
    z[1,0,4]  R391      2.4864292144775391e-01
    z[1,0,4]  R392      -5.9497680515050888e-02
    z[1,0,4]  R393      1.3169558346271515e-01
    z[1,0,4]  R394      -3.2660955190658569e-01
    z[1,0,4]  R395      2.6325416564941406e-01
    z[1,0,4]  R396      -1.8018412590026855e-01
    z[1,0,4]  R397      2.0091657340526581e-01
    z[1,0,4]  R398      3.4084555506706238e-01
    z[1,0,4]  R399      -7.8271649777889252e-02
    z[1,0,4]  R400      -2.3090025782585144e-01
    z[1,0,4]  R401      5.3224277496337891e-01
    z[1,0,4]  R402      2.5602266192436218e-01
    z[1,0,4]  R403      -3.1911402940750122e-02
    z[1,0,4]  R404      -3.4819513559341431e-02
    z[1,0,4]  R405      -6.8201929330825806e-01
    z[1,0,4]  R406      2.4720046669244766e-02
    z[1,0,4]  R407      0.348127543926239
    z[1,0,4]  R408      1.2218102067708969e-01
    z[1,0,4]  R409      4.8597112298011780e-01
    z[1,0,4]  R410      -3.2860539853572845e-02
    z[1,0,4]  R411      5.6821429729461670e-01
    z[1,0,4]  R412      5.9923237562179565e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R249      -1
    z[1,0,5]  R250      1
    z[1,0,5]  R253      -3.8039609789848328e-01
    z[1,0,5]  R254      -5.0422906875610352e-01
    z[1,0,5]  R255      -0.164892315864563
    z[1,0,5]  R256      -4.6466124057769775e-01
    z[1,0,5]  R257      -7.6907074451446533e-01
    z[1,0,5]  R258      -1.9561339914798737e-01
    z[1,0,5]  R259      1.6903290152549744e-01
    z[1,0,5]  R260      -3.4611638635396957e-02
    z[1,0,5]  R261      -1.5801297500729561e-02
    z[1,0,5]  R262      4.4854953885078430e-02
    z[1,0,5]  R263      -1.0670714825391769e-01
    z[1,0,5]  R264      -7.1751600503921509e-01
    z[1,0,5]  R265      6.5067127346992493e-02
    z[1,0,5]  R266      4.9789077043533325e-01
    z[1,0,5]  R267      -1.0500293225049973e-01
    z[1,0,5]  R268      -1.1569120734930038e-01
    z[1,0,5]  R269      6.1202161014080048e-02
    z[1,0,5]  R270      1.8338931724429131e-02
    z[1,0,5]  R271      5.3137916326522827e-01
    z[1,0,5]  R272      3.3780816197395325e-01
    z[1,0,5]  R273      1.6777861863374710e-02
    z[1,0,5]  R274      1.9756369292736053e-01
    z[1,0,5]  R275      3.6830523610115051e-01
    z[1,0,5]  R276      1.3149045407772064e-01
    z[1,0,5]  R277      -2.9963439702987671e-01
    z[1,0,5]  R278      -3.2674390077590942e-01
    z[1,0,5]  R279      7.1859258413314819e-01
    z[1,0,5]  R280      9.6005834639072418e-02
    z[1,0,5]  R281      6.1905288696289062e-01
    z[1,0,5]  R282      2.3936746641993523e-02
    z[1,0,5]  R283      -1.3524423539638519e-01
    z[1,0,5]  R284      8.5094437003135681e-02
    z[1,0,5]  R285      5.3755539655685425e-01
    z[1,0,5]  R286      1.3397021591663361e-01
    z[1,0,5]  R287      -3.2710316777229309e-01
    z[1,0,5]  R288      1.9581331312656403e-01
    z[1,0,5]  R289      3.4025412797927856e-01
    z[1,0,5]  R290      3.0967232584953308e-01
    z[1,0,5]  R291      -4.6537414193153381e-01
    z[1,0,5]  R292      -2.0345541834831238e-01
    z[1,0,5]  R293      -1.7123125493526459e-01
    z[1,0,5]  R294      5.5556458234786987e-01
    z[1,0,5]  R295      1.4421881735324860e-01
    z[1,0,5]  R296      -4.2163927108049393e-02
    z[1,0,5]  R297      2.1139974892139435e-01
    z[1,0,5]  R298      4.3668356537818909e-01
    z[1,0,5]  R299      -4.2336869239807129e-01
    z[1,0,5]  R300      -1.9220508635044098e-01
    z[1,0,5]  R301      3.0547830462455750e-01
    z[1,0,5]  R302      -3.2927942276000977e-01
    z[1,0,5]  R303      6.5410439856350422e-03
    z[1,0,5]  R304      -2.1521820127964020e-01
    z[1,0,5]  R305      1.4981015026569366e-01
    z[1,0,5]  R306      -0.0714566707611084
    z[1,0,5]  R307      1.5993739664554596e-01
    z[1,0,5]  R308      -2.0263540744781494e-01
    z[1,0,5]  R309      -0.27133908867836
    z[1,0,5]  R310      -4.7249174118041992e-01
    z[1,0,5]  R311      -2.1879664063453674e-01
    z[1,0,5]  R312      2.1051040291786194e-01
    z[1,0,5]  R313      -4.7900292277336121e-01
    z[1,0,5]  R314      1.1892103403806686e-01
    z[1,0,5]  R315      -2.1886758506298065e-02
    z[1,0,5]  R316      -5.5067169666290283e-01
    z[1,0,5]  R317      -9.6480071544647217e-02
    z[1,0,5]  R318      7.9776518046855927e-02
    z[1,0,5]  R319      -0.0778428167104721
    z[1,0,5]  R320      -9.3156717717647552e-02
    z[1,0,5]  R321      1.4025831222534180e-01
    z[1,0,5]  R322      -3.3763861656188965e-01
    z[1,0,5]  R323      -5.0898045301437378e-02
    z[1,0,5]  R324      -2.7517560124397278e-01
    z[1,0,5]  R325      -5.5973863601684570e-01
    z[1,0,5]  R326      -6.2088322639465332e-01
    z[1,0,5]  R327      0.290799081325531
    z[1,0,5]  R328      -3.4118351340293884e-01
    z[1,0,5]  R329      2.5200262665748596e-01
    z[1,0,5]  R330      -2.1571926772594452e-01
    z[1,0,5]  R331      -4.1396751999855042e-01
    z[1,0,5]  R332      -5.5196538567543030e-02
    z[1,0,5]  R333      -0.340366005897522
    z[1,0,5]  R334      -3.3916282653808594e-01
    z[1,0,5]  R335      2.5396227836608887e-01
    z[1,0,5]  R336      -2.0888239145278931e-01
    z[1,0,5]  R337      -8.8600821793079376e-02
    z[1,0,5]  R338      0.0864071249961853
    z[1,0,5]  R339      -3.5851109772920609e-02
    z[1,0,5]  R340      1.2585379183292389e-01
    z[1,0,5]  R341      -5.6693799793720245e-02
    z[1,0,5]  R342      4.4701176881790161e-01
    z[1,0,5]  R343      9.5144383609294891e-02
    z[1,0,5]  R344      1.2219092994928360e-01
    z[1,0,5]  R345      -3.6877259612083435e-01
    z[1,0,5]  R346      -6.4557117223739624e-01
    z[1,0,5]  R347      2.4793425202369690e-01
    z[1,0,5]  R348      3.3341971039772034e-01
    z[1,0,5]  R349      0.415558785200119
    z[1,0,5]  R350      1.5356499701738358e-02
    z[1,0,5]  R351      -4.3897899985313416e-01
    z[1,0,5]  R352      5.1259106397628784e-01
    z[1,0,5]  R353      -0.0826454684138298
    z[1,0,5]  R354      -2.8129890561103821e-01
    z[1,0,5]  R355      3.9669489860534668e-01
    z[1,0,5]  R356      1.5606077015399933e-01
    z[1,0,5]  R357      -2.8040561079978943e-01
    z[1,0,5]  R358      1.8205150961875916e-01
    z[1,0,5]  R359      3.0326387286186218e-01
    z[1,0,5]  R360      0.228912353515625
    z[1,0,5]  R361      -2.2774764802306890e-03
    z[1,0,5]  R362      -3.2953587174415588e-01
    z[1,0,5]  R363      3.3728504180908203e-01
    z[1,0,5]  R364      -3.2062929123640060e-02
    z[1,0,5]  R365      -6.0443345457315445e-02
    z[1,0,5]  R366      2.9518043994903564e-01
    z[1,0,5]  R367      5.5045560002326965e-03
    z[1,0,5]  R368      -2.9020276665687561e-01
    z[1,0,5]  R369      -8.4798950701951981e-03
    z[1,0,5]  R370      6.6874980926513672e-02
    z[1,0,5]  R371      3.9979156851768494e-01
    z[1,0,5]  R372      0.0141511932015419
    z[1,0,5]  R373      2.4028590321540833e-01
    z[1,0,5]  R374      1.4296466112136841e-01
    z[1,0,5]  R375      5.2013820409774780e-01
    z[1,0,5]  R376      0.362602174282074
    z[1,0,5]  R377      -7.0562714338302612e-01
    z[1,0,5]  R378      -7.6083153486251831e-01
    z[1,0,5]  R379      -2.5893664360046387e-01
    z[1,0,5]  R380      3.4961634874343872e-01
    z[1,0,5]  R381      9.2065773904323578e-02
    z[1,0,5]  R382      0.290505051612854
    z[1,0,5]  R383      -4.6628376841545105e-01
    z[1,0,5]  R384      1.5312932431697845e-01
    z[1,0,5]  R385      -0.0842769518494606
    z[1,0,5]  R386      -3.5723760724067688e-01
    z[1,0,5]  R387      2.9243400692939758e-01
    z[1,0,5]  R388      5.2723549306392670e-02
    z[1,0,5]  R389      -6.9054342806339264e-02
    z[1,0,5]  R390      2.2902987897396088e-01
    z[1,0,5]  R391      -1.7587022483348846e-01
    z[1,0,5]  R392      -4.3951058387756348e-01
    z[1,0,5]  R393      -2.1963946521282196e-01
    z[1,0,5]  R394      -1.4680349826812744e-01
    z[1,0,5]  R395      3.5559117794036865e-01
    z[1,0,5]  R396      3.3225327730178833e-01
    z[1,0,5]  R397      -2.2312594950199127e-01
    z[1,0,5]  R398      -6.6104239225387573e-01
    z[1,0,5]  R399      -1.3015256822109222e-01
    z[1,0,5]  R400      -4.3054780364036560e-01
    z[1,0,5]  R401      -3.3977288007736206e-01
    z[1,0,5]  R402      2.9494670033454895e-01
    z[1,0,5]  R403      1.3274885714054108e-01
    z[1,0,5]  R404      2.7714800834655762e-01
    z[1,0,5]  R405      3.0091580748558044e-01
    z[1,0,5]  R406      -1.7766192555427551e-01
    z[1,0,5]  R407      2.3864848911762238e-01
    z[1,0,5]  R408      1.3339985907077789e-01
    z[1,0,5]  R409      -4.2681032419204712e-01
    z[1,0,5]  R410      4.8897233605384827e-01
    z[1,0,5]  R411      1.4568093419075012e-01
    z[1,0,5]  R412      -6.9919861853122711e-02
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R251      -1
    z[1,0,6]  R252      1
    z[1,0,6]  R253      2.5978598743677139e-02
    z[1,0,6]  R254      2.5896498560905457e-01
    z[1,0,6]  R255      2.2164984047412872e-01
    z[1,0,6]  R256      3.9759743958711624e-03
    z[1,0,6]  R257      -1.1250501126050949e-01
    z[1,0,6]  R258      1.7408958077430725e-01
    z[1,0,6]  R259      1.3000544905662537e-01
    z[1,0,6]  R260      -2.1116336807608604e-02
    z[1,0,6]  R261      2.4243091046810150e-01
    z[1,0,6]  R262      4.6817961335182190e-01
    z[1,0,6]  R263      -2.7770814299583435e-01
    z[1,0,6]  R264      -4.0957968682050705e-02
    z[1,0,6]  R265      1.5679925680160522e-02
    z[1,0,6]  R266      2.3461225628852844e-01
    z[1,0,6]  R267      -6.1612367630004883e-01
    z[1,0,6]  R268      -0.510966956615448
    z[1,0,6]  R269      2.5119778513908386e-01
    z[1,0,6]  R270      1.0444530844688416e-01
    z[1,0,6]  R271      -2.8750613331794739e-01
    z[1,0,6]  R272      -5.2096154540777206e-02
    z[1,0,6]  R273      -6.3579088449478149e-01
    z[1,0,6]  R274      -3.9047278463840485e-02
    z[1,0,6]  R275      -5.7067770510911942e-02
    z[1,0,6]  R276      -4.9153414368629456e-01
    z[1,0,6]  R277      -3.9015471935272217e-01
    z[1,0,6]  R278      2.3470519483089447e-01
    z[1,0,6]  R279      -6.4734026789665222e-02
    z[1,0,6]  R280      7.1323089301586151e-02
    z[1,0,6]  R281      0.603255033493042
    z[1,0,6]  R282      -1.8306757509708405e-01
    z[1,0,6]  R283      -6.2811499834060669e-01
    z[1,0,6]  R284      -5.8990508317947388e-01
    z[1,0,6]  R285      4.7271189093589783e-01
    z[1,0,6]  R286      -3.1926280260086060e-01
    z[1,0,6]  R287      -1.4661435782909393e-01
    z[1,0,6]  R288      5.3604024648666382e-01
    z[1,0,6]  R289      -4.1475647687911987e-01
    z[1,0,6]  R290      -1.1077469587326050e-01
    z[1,0,6]  R291      -4.6451419591903687e-01
    z[1,0,6]  R292      5.5887496471405029e-01
    z[1,0,6]  R293      -1.7274679243564606e-01
    z[1,0,6]  R294      1.2963366508483887e-01
    z[1,0,6]  R295      5.8247900009155273e-01
    z[1,0,6]  R296      1.6660098731517792e-01
    z[1,0,6]  R297      -1.5399083495140076e-01
    z[1,0,6]  R298      1.0274005681276321e-01
    z[1,0,6]  R299      -1.6138151288032532e-01
    z[1,0,6]  R300      -2.3751424252986908e-01
    z[1,0,6]  R301      -4.2117387056350708e-01
    z[1,0,6]  R302      5.3832399845123291e-01
    z[1,0,6]  R303      -9.5269419252872467e-02
    z[1,0,6]  R304      -0.337056040763855
    z[1,0,6]  R305      -3.3285051584243774e-01
    z[1,0,6]  R306      0.341945618391037
    z[1,0,6]  R307      -2.7795326709747314e-01
    z[1,0,6]  R308      -2.9696673154830933e-01
    z[1,0,6]  R309      6.0295134782791138e-01
    z[1,0,6]  R310      3.2087239623069763e-01
    z[1,0,6]  R311      3.1672829389572144e-01
    z[1,0,6]  R312      -2.7522730827331543e-01
    z[1,0,6]  R313      -3.6352673172950745e-01
    z[1,0,6]  R314      3.1183210015296936e-01
    z[1,0,6]  R315      -0.522093653678894
    z[1,0,6]  R316      8.4165006875991821e-02
    z[1,0,6]  R317      4.1922721266746521e-01
    z[1,0,6]  R318      -1.0764741152524948e-01
    z[1,0,6]  R319      -8.9159741997718811e-02
    z[1,0,6]  R320      1.8927218019962311e-01
    z[1,0,6]  R321      -0.0878983587026596
    z[1,0,6]  R322      9.3493327498435974e-02
    z[1,0,6]  R323      3.1428948044776917e-02
    z[1,0,6]  R324      -1.2347525358200073e-01
    z[1,0,6]  R325      2.1435044705867767e-01
    z[1,0,6]  R326      6.4815111458301544e-02
    z[1,0,6]  R327      7.9461887478828430e-02
    z[1,0,6]  R328      -5.0881922245025635e-02
    z[1,0,6]  R329      1.9700525701045990e-01
    z[1,0,6]  R330      -1.4722093008458614e-02
    z[1,0,6]  R331      2.7972161769866943e-01
    z[1,0,6]  R332      -1.4217411167919636e-02
    z[1,0,6]  R333      -3.7718974053859711e-02
    z[1,0,6]  R334      -2.4991898238658905e-01
    z[1,0,6]  R335      3.0058425664901733e-01
    z[1,0,6]  R336      3.0824345350265503e-01
    z[1,0,6]  R337      8.1671245396137238e-02
    z[1,0,6]  R338      1.1477380245923996e-01
    z[1,0,6]  R339      1.0683772154152393e-02
    z[1,0,6]  R340      -1.5544918179512024e-01
    z[1,0,6]  R341      4.9034300446510315e-01
    z[1,0,6]  R342      -1.8377602100372314e-01
    z[1,0,6]  R343      -0.37274369597435
    z[1,0,6]  R344      1.5977036207914352e-02
    z[1,0,6]  R345      1.6093797981739044e-01
    z[1,0,6]  R346      4.3478954583406448e-02
    z[1,0,6]  R347      -1.6550987958908081e-01
    z[1,0,6]  R348      -7.1623444557189941e-02
    z[1,0,6]  R349      -2.7719438076019287e-01
    z[1,0,6]  R350      -1.8942917883396149e-01
    z[1,0,6]  R351      0.43539959192276
    z[1,0,6]  R352      2.8288811445236206e-01
    z[1,0,6]  R353      -3.3108890056610107e-01
    z[1,0,6]  R354      2.4633076041936874e-02
    z[1,0,6]  R355      1.7295395955443382e-02
    z[1,0,6]  R356      5.9470415115356445e-02
    z[1,0,6]  R357      2.6722386479377747e-01
    z[1,0,6]  R358      -1.2938253581523895e-01
    z[1,0,6]  R359      1.0591533035039902e-01
    z[1,0,6]  R360      -1.6675411164760590e-01
    z[1,0,6]  R361      -1.0583539307117462e-01
    z[1,0,6]  R362      2.2988523542881012e-01
    z[1,0,6]  R363      -7.8124955296516418e-02
    z[1,0,6]  R364      -3.4003564715385437e-01
    z[1,0,6]  R365      -2.0062687993049622e-01
    z[1,0,6]  R366      -1.7484804987907410e-01
    z[1,0,6]  R367      -1.8011310696601868e-01
    z[1,0,6]  R368      -2.2598819434642792e-01
    z[1,0,6]  R369      2.5719873607158661e-02
    z[1,0,6]  R370      -8.3407811820507050e-02
    z[1,0,6]  R371      2.7665841579437256e-01
    z[1,0,6]  R372      2.1546630561351776e-01
    z[1,0,6]  R373      -1.9060879945755005e-01
    z[1,0,6]  R374      1.4744338393211365e-01
    z[1,0,6]  R375      1.7841245234012604e-01
    z[1,0,6]  R376      1.9542181491851807e-01
    z[1,0,6]  R377      3.0342981219291687e-01
    z[1,0,6]  R378      1.4042806625366211e-01
    z[1,0,6]  R379      5.1081973314285278e-01
    z[1,0,6]  R380      4.2690034955739975e-02
    z[1,0,6]  R381      4.5900359749794006e-01
    z[1,0,6]  R382      6.2206890434026718e-02
    z[1,0,6]  R383      1.7906057834625244e-01
    z[1,0,6]  R384      -1.8205833435058594e-01
    z[1,0,6]  R385      -8.5641875863075256e-02
    z[1,0,6]  R386      5.5052293464541435e-03
    z[1,0,6]  R387      2.7318498492240906e-01
    z[1,0,6]  R388      9.1474344953894615e-03
    z[1,0,6]  R389      1.3312149047851562e-01
    z[1,0,6]  R390      -1.0616851598024368e-01
    z[1,0,6]  R391      -1.2419880181550980e-01
    z[1,0,6]  R392      -1.3380878372117877e-03
    z[1,0,6]  R393      -8.7297163903713226e-02
    z[1,0,6]  R394      2.3277722299098969e-01
    z[1,0,6]  R395      1.1558146029710770e-01
    z[1,0,6]  R396      -0.0084022656083107
    z[1,0,6]  R397      4.3134069442749023e-01
    z[1,0,6]  R398      2.4139201641082764e-01
    z[1,0,6]  R399      3.5985150933265686e-01
    z[1,0,6]  R400      0.335778146982193
    z[1,0,6]  R401      -0.361446738243103
    z[1,0,6]  R402      2.3352560400962830e-01
    z[1,0,6]  R403      4.9750655889511108e-02
    z[1,0,6]  R404      -1.0317817330360413e-01
    z[1,0,6]  R405      -1.2786078453063965e-01
    z[1,0,6]  R406      -2.5190016627311707e-01
    z[1,0,6]  R407      -2.3922783136367798e-01
    z[1,0,6]  R408      5.5657601356506348e-01
    z[1,0,6]  R409      -3.3673766255378723e-01
    z[1,0,6]  R410      0.323076069355011
    z[1,0,6]  R411      -1.0856927372515202e-02
    z[1,0,6]  R412      -1.5177269279956818e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R413      -1
    z[0,3,0]  R414      1
    z[0,3,0]  R427      5.2258968353271484e-01
    z[0,3,0]  R428      2.7141281962394714e-01
    z[0,3,0]  R429      -5.9181714057922363e-01
    z[0,3,0]  R430      -5.4779791831970215e-01
    z[0,3,0]  R431      6.4446645975112915e-01
    z[0,3,0]  R432      2.4215668439865112e-01
    z[0,3,0]  R433      2.7344632148742676e-01
    z[0,3,0]  R434      -0.502898633480072
    z[0,3,0]  R435      -5.9624433517456055e-01
    z[0,3,0]  R436      -0.508691668510437
    z[0,3,0]  R437      -2.1039625629782677e-02
    z[0,3,0]  R438      -6.3955950736999512e-01
    z[0,3,0]  R439      3.8346239924430847e-01
    z[0,3,0]  R440      -5.8709084987640381e-01
    z[0,3,0]  R441      -5.7609003782272339e-01
    z[0,3,0]  R442      -1.5098403394222260e-01
    z[0,3,0]  R443      3.4997817873954773e-01
    z[0,3,0]  R444      1.9455881416797638e-01
    z[0,3,0]  R445      -1.0306473821401596e-01
    z[0,3,0]  R446      7.2607177495956421e-01
    z[0,3,0]  R447      3.5984647274017334e-01
    z[0,3,0]  R448      4.0053266286849976e-01
    z[0,3,0]  R449      2.8451833128929138e-01
    z[0,3,0]  R450      -4.9256992340087891e-01
    z[0,3,0]  R451      5.8289057016372681e-01
    z[0,3,0]  R452      3.2223412394523621e-01
    z[0,3,0]  R453      5.2027565240859985e-01
    z[0,3,0]  R454      8.9749681949615479e-01
    z[0,3,0]  R455      7.7735997736454010e-02
    z[0,3,0]  R456      4.8377230763435364e-01
    z[0,3,0]  R457      3.3621346950531006e-01
    z[0,3,0]  R458      4.4479519128799438e-01
    z[0,3,0]  R459      6.3285452127456665e-01
    z[0,3,0]  R460      2.5843468308448792e-01
    z[0,3,0]  R461      4.4759970158338547e-02
    z[0,3,0]  R462      1.8317356705665588e-01
    z[0,3,0]  R463      -1.5814730897545815e-02
    z[0,3,0]  R464      7.2875326871871948e-01
    z[0,3,0]  R465      1.0331102460622787e-01
    z[0,3,0]  R466      -4.7458952665328979e-01
    z[0,3,0]  R467      5.9786039590835571e-01
    z[0,3,0]  R468      2.3851300776004791e-01
    z[0,3,0]  R469      2.6434731483459473e-01
    z[0,3,0]  R470      7.2767162322998047e-01
    z[0,3,0]  R471      5.7752884924411774e-02
    z[0,3,0]  R472      -0.486916184425354
    z[0,3,0]  R473      4.2904263734817505e-01
    z[0,3,0]  R474      1.7858929932117462e-01
    z[0,3,0]  R475      -1.9521364942193031e-02
    z[0,3,0]  R476      2.5948521494865417e-01
    z[0,3,0]  R477      6.5763312578201294e-01
    z[0,3,0]  R478      3.5264107584953308e-01
    z[0,3,0]  R479      5.9940475225448608e-01
    z[0,3,0]  R480      0.693200409412384
    z[0,3,0]  R481      -5.1868766546249390e-01
    z[0,3,0]  R482      -5.5990439653396606e-01
    z[0,3,0]  R483      1.3997834920883179e-01
    z[0,3,0]  R484      -6.3276566565036774e-02
    z[0,3,0]  R485      0.837135374546051
    z[0,3,0]  R486      9.2894226312637329e-01
    z[0,3,0]  R487      -6.2266051769256592e-01
    z[0,3,0]  R488      7.6999038457870483e-01
    z[0,3,0]  R489      -4.2529711127281189e-01
    z[0,3,0]  R490      -5.8424901962280273e-01
    z[0,3,0]  R491      5.6201267242431641e-01
    z[0,3,0]  R492      -1.1042773723602295e-01
    z[0,3,0]  R493      2.5928720831871033e-01
    z[0,3,0]  R494      -3.6640220880508423e-01
    z[0,3,0]  R495      5.1088446378707886e-01
    z[0,3,0]  R496      5.1166445016860962e-01
    z[0,3,0]  R497      3.0087643861770630e-01
    z[0,3,0]  R498      -3.6423809826374054e-02
    z[0,3,0]  R499      6.0400050878524780e-01
    z[0,3,0]  R500      5.4995787143707275e-01
    z[0,3,0]  R501      4.2954602837562561e-01
    z[0,3,0]  R502      -4.6089485287666321e-01
    z[0,3,0]  R503      -1.0036650300025940e-01
    z[0,3,0]  R504      1.5186357498168945e-01
    z[0,3,0]  R505      1.5081593394279480e-01
    z[0,3,0]  R506      4.9989837408065796e-01
    z[0,3,0]  R507      2.5372245907783508e-01
    z[0,3,0]  R508      7.4551028013229370e-01
    z[0,3,0]  R509      1.8130171298980713e-01
    z[0,3,0]  R510      -5.2088344097137451e-01
    z[0,3,0]  R511      5.0005221366882324e-01
    z[0,3,0]  R512      0.537525475025177
    z[0,3,0]  R513      -0.516525387763977
    z[0,3,0]  R514      -2.1711751818656921e-01
    z[0,3,0]  R515      -6.7841041088104248e-01
    z[0,3,0]  R516      6.5063852071762085e-01
    z[0,3,0]  R517      -6.0292345285415649e-01
    z[0,3,0]  R518      -5.9713470935821533e-01
    z[0,3,0]  R519      -7.9646384716033936e-01
    z[0,3,0]  R520      0.593394935131073
    z[0,3,0]  R521      -0.430400013923645
    z[0,3,0]  R522      3.6738941073417664e-01
    z[0,3,0]  R523      6.8841701745986938e-01
    z[0,3,0]  R524      3.5563737154006958e-01
    z[0,3,0]  R525      4.9206703901290894e-01
    z[0,3,0]  R526      -2.8547435998916626e-01
    z[0,3,0]  R527      -1.9855169579386711e-02
    z[0,3,0]  R528      -7.0916842669248581e-03
    z[0,3,0]  R529      -2.0397590473294258e-02
    z[0,3,0]  R530      -6.5713502466678619e-02
    z[0,3,0]  R531      3.0177175998687744e-01
    z[0,3,0]  R532      3.8811814785003662e-01
    z[0,3,0]  R533      -1.8501804769039154e-01
    z[0,3,0]  R534      0.167601078748703
    z[0,3,0]  R535      8.1268265843391418e-02
    z[0,3,0]  R536      5.1078337430953979e-01
    z[0,3,0]  R537      -2.2165615856647491e-01
    z[0,3,0]  R538      7.2538322210311890e-01
    z[0,3,0]  R539      8.0320823192596436e-01
    z[0,3,0]  R540      5.4646110534667969e-01
    z[0,3,0]  R541      4.4635590910911560e-01
    z[0,3,0]  R542      5.7215999811887741e-02
    z[0,3,0]  R543      6.9971328973770142e-01
    z[0,3,0]  R544      0.713864803314209
    z[0,3,0]  R545      7.7606225013732910e-01
    z[0,3,0]  R546      -0.397827684879303
    z[0,3,0]  R547      7.2482812404632568e-01
    z[0,3,0]  R548      -2.4095913767814636e-01
    z[0,3,0]  R549      0.813280463218689
    z[0,3,0]  R550      1.3921824283897877e-02
    z[0,3,0]  R551      6.2162774801254272e-01
    z[0,3,0]  R552      5.1198744773864746e-01
    z[0,3,0]  R553      6.4981174468994141e-01
    z[0,3,0]  R554      -4.9261572957038879e-01
    z[0,3,0]  R555      2.5793758034706116e-01
    z[0,3,0]  R556      6.9175004959106445e-02
    z[0,3,0]  R557      -3.7531760334968567e-01
    z[0,3,0]  R558      -4.9100264906883240e-02
    z[0,3,0]  R559      3.8662287592887878e-01
    z[0,3,0]  R560      7.8889721632003784e-01
    z[0,3,0]  R561      -3.9210504293441772e-01
    z[0,3,0]  R562      7.3289644718170166e-01
    z[0,3,0]  R563      1.8111538887023926e-01
    z[0,3,0]  R564      -3.0878129601478577e-01
    z[0,3,0]  R565      -3.5077667236328125e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R415      -1
    z[0,3,1]  R416      1
    z[0,3,1]  R427      3.6833387613296509e-01
    z[0,3,1]  R428      7.9607349634170532e-01
    z[0,3,1]  R429      -4.1194394230842590e-01
    z[0,3,1]  R430      -3.9958181977272034e-01
    z[0,3,1]  R431      4.9775320291519165e-01
    z[0,3,1]  R432      7.2175461053848267e-01
    z[0,3,1]  R433      -5.8704257011413574e-01
    z[0,3,1]  R434      -6.2557137012481689e-01
    z[0,3,1]  R435      -4.7308912873268127e-01
    z[0,3,1]  R436      -6.1057257652282715e-01
    z[0,3,1]  R437      -8.6844104528427124e-01
    z[0,3,1]  R438      -3.7819364666938782e-01
    z[0,3,1]  R439      7.8421306610107422e-01
    z[0,3,1]  R440      -4.6251523494720459e-01
    z[0,3,1]  R441      -6.7398720979690552e-01
    z[0,3,1]  R442      -0.629465639591217
    z[0,3,1]  R443      7.1435183286666870e-01
    z[0,3,1]  R444      7.6606941223144531e-01
    z[0,3,1]  R445      -0.630012571811676
    z[0,3,1]  R446      3.3499780297279358e-01
    z[0,3,1]  R447      8.1709533929824829e-01
    z[0,3,1]  R448      7.3661535978317261e-01
    z[0,3,1]  R449      7.3152804374694824e-01
    z[0,3,1]  R450      -3.0366113781929016e-01
    z[0,3,1]  R451      5.0897938013076782e-01
    z[0,3,1]  R452      6.3099247217178345e-01
    z[0,3,1]  R453      3.2106861472129822e-01
    z[0,3,1]  R454      -1.1713733896613121e-02
    z[0,3,1]  R455      0.736412763595581
    z[0,3,1]  R456      7.4944078922271729e-02
    z[0,3,1]  R457      8.3493673801422119e-01
    z[0,3,1]  R458      6.7021858692169189e-01
    z[0,3,1]  R459      1.0754422843456268e-01
    z[0,3,1]  R460      6.6958451271057129e-01
    z[0,3,1]  R461      7.9599660634994507e-01
    z[0,3,1]  R462      -2.4713924527168274e-01
    z[0,3,1]  R463      -0.864155650138855
    z[0,3,1]  R464      3.7200577557086945e-02
    z[0,3,1]  R465      0.793024480342865
    z[0,3,1]  R466      -5.6740152835845947e-01
    z[0,3,1]  R467      3.6730918288230896e-01
    z[0,3,1]  R468      8.8114857673645020e-01
    z[0,3,1]  R469      -7.8086805343627930e-01
    z[0,3,1]  R470      7.9446837306022644e-02
    z[0,3,1]  R471      -2.2397871315479279e-01
    z[0,3,1]  R472      -1.8734152615070343e-01
    z[0,3,1]  R473      -7.8264009952545166e-01
    z[0,3,1]  R474      -3.5057049989700317e-01
    z[0,3,1]  R475      -7.8658795356750488e-01
    z[0,3,1]  R476      -8.6471116542816162e-01
    z[0,3,1]  R477      3.4992757439613342e-01
    z[0,3,1]  R478      -6.2392234802246094e-01
    z[0,3,1]  R479      1.8919041380286217e-02
    z[0,3,1]  R480      -2.0074361562728882e-01
    z[0,3,1]  R481      3.8524657487869263e-02
    z[0,3,1]  R482      -3.3165480941534042e-02
    z[0,3,1]  R483      7.1194154024124146e-01
    z[0,3,1]  R484      -9.2100965976715088e-01
    z[0,3,1]  R485      -3.2712038606405258e-02
    z[0,3,1]  R486      2.0799531042575836e-01
    z[0,3,1]  R487      -1.7363831400871277e-01
    z[0,3,1]  R488      2.6390469074249268e-01
    z[0,3,1]  R489      -8.0534279346466064e-01
    z[0,3,1]  R490      -3.3154079318046570e-01
    z[0,3,1]  R491      3.5923457145690918e-01
    z[0,3,1]  R492      -0.895881712436676
    z[0,3,1]  R493      6.7885470390319824e-01
    z[0,3,1]  R494      -7.6817399263381958e-01
    z[0,3,1]  R495      -6.4891618490219116e-01
    z[0,3,1]  R496      -0.37047278881073
    z[0,3,1]  R497      9.1027367115020752e-01
    z[0,3,1]  R498      -2.2061090171337128e-01
    z[0,3,1]  R499      6.1865431070327759e-01
    z[0,3,1]  R500      6.5419411659240723e-01
    z[0,3,1]  R501      0.648796021938324
    z[0,3,1]  R502      -1.0930936038494110e-01
    z[0,3,1]  R503      -6.4319121837615967e-01
    z[0,3,1]  R504      7.4658292531967163e-01
    z[0,3,1]  R505      -1.6936777532100677e-01
    z[0,3,1]  R506      5.3226995468139648e-01
    z[0,3,1]  R507      8.5525131225585938e-01
    z[0,3,1]  R508      1.5650014579296112e-01
    z[0,3,1]  R509      2.2968946397304535e-01
    z[0,3,1]  R510      -8.4850661456584930e-02
    z[0,3,1]  R511      -3.3790320158004761e-02
    z[0,3,1]  R512      -2.8482902050018311e-01
    z[0,3,1]  R513      1.9975388050079346e-01
    z[0,3,1]  R514      -6.9128429889678955e-01
    z[0,3,1]  R515      -1.3931839168071747e-01
    z[0,3,1]  R516      -3.0566978454589844e-01
    z[0,3,1]  R517      -4.9979650974273682e-01
    z[0,3,1]  R518      -3.7981674075126648e-01
    z[0,3,1]  R519      -2.0791263878345490e-01
    z[0,3,1]  R520      3.7678810954093933e-01
    z[0,3,1]  R521      -4.3685835599899292e-01
    z[0,3,1]  R522      7.3186588287353516e-01
    z[0,3,1]  R523      5.6335467100143433e-01
    z[0,3,1]  R524      2.5529748201370239e-01
    z[0,3,1]  R525      -3.0720129609107971e-01
    z[0,3,1]  R526      -4.9055501818656921e-01
    z[0,3,1]  R527      -8.5490924119949341e-01
    z[0,3,1]  R528      -7.7586907148361206e-01
    z[0,3,1]  R529      -7.6240330934524536e-01
    z[0,3,1]  R530      -6.7092359066009521e-01
    z[0,3,1]  R531      -0.72418612241745
    z[0,3,1]  R532      -6.1174947023391724e-01
    z[0,3,1]  R533      -6.1788523197174072e-01
    z[0,3,1]  R534      -9.1981792449951172e-01
    z[0,3,1]  R535      -5.2808022499084473e-01
    z[0,3,1]  R536      5.4192101955413818e-01
    z[0,3,1]  R537      -8.2055938243865967e-01
    z[0,3,1]  R538      4.7175922989845276e-01
    z[0,3,1]  R539      1.1841738224029541e-01
    z[0,3,1]  R540      2.9551774263381958e-01
    z[0,3,1]  R541      0.809660017490387
    z[0,3,1]  R542      -2.1381278336048126e-01
    z[0,3,1]  R543      -1.8627347052097321e-01
    z[0,3,1]  R544      0.00829958077520132
    z[0,3,1]  R545      -3.7942326068878174e-01
    z[0,3,1]  R546      -4.5845040678977966e-01
    z[0,3,1]  R547      2.7378877997398376e-01
    z[0,3,1]  R548      -2.6002889871597290e-01
    z[0,3,1]  R549      -3.5557288210839033e-03
    z[0,3,1]  R550      -2.9835966229438782e-01
    z[0,3,1]  R551      -3.6772534251213074e-01
    z[0,3,1]  R552      -4.3924498558044434e-01
    z[0,3,1]  R553      -2.4902668595314026e-01
    z[0,3,1]  R554      1.4090338349342346e-01
    z[0,3,1]  R555      3.8887679576873779e-01
    z[0,3,1]  R556      -7.4931782484054565e-01
    z[0,3,1]  R557      -0.632306694984436
    z[0,3,1]  R558      -7.8275579214096069e-01
    z[0,3,1]  R559      -6.6907012462615967e-01
    z[0,3,1]  R560      -2.8633108735084534e-01
    z[0,3,1]  R561      -0.757557213306427
    z[0,3,1]  R562      -3.0009558796882629e-01
    z[0,3,1]  R563      3.3315002918243408e-01
    z[0,3,1]  R564      8.9879298210144043e-01
    z[0,3,1]  R565      8.9376252889633179e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R417      -1
    z[0,3,2]  R418      1
    z[0,3,2]  R427      7.5606632232666016e-01
    z[0,3,2]  R428      -1.2401672452688217e-01
    z[0,3,2]  R429      -3.7869594991207123e-02
    z[0,3,2]  R430      -0.0090639628469944
    z[0,3,2]  R431      2.5722339749336243e-01
    z[0,3,2]  R432      4.9583235383033752e-01
    z[0,3,2]  R433      -3.1884562224149704e-02
    z[0,3,2]  R434      -1.4853253960609436e-01
    z[0,3,2]  R435      -6.4209826290607452e-02
    z[0,3,2]  R436      -1.8338464200496674e-02
    z[0,3,2]  R437      -9.8827652633190155e-02
    z[0,3,2]  R438      -4.4583427906036377e-01
    z[0,3,2]  R439      -2.6195909827947617e-02
    z[0,3,2]  R440      -3.5094434022903442e-01
    z[0,3,2]  R441      -3.7738955020904541e-01
    z[0,3,2]  R442      -1.5090338885784149e-01
    z[0,3,2]  R443      1.1762766540050507e-01
    z[0,3,2]  R444      -1.6124796122312546e-02
    z[0,3,2]  R445      -1.8149559199810028e-01
    z[0,3,2]  R446      2.9928576946258545e-01
    z[0,3,2]  R447      -1.2259004870429635e-03
    z[0,3,2]  R448      3.9859589934349060e-01
    z[0,3,2]  R449      4.5946672558784485e-01
    z[0,3,2]  R450      -2.7820277214050293e-01
    z[0,3,2]  R451      4.1098093986511230e-01
    z[0,3,2]  R452      -5.0525808334350586e-01
    z[0,3,2]  R453      5.1737630367279053e-01
    z[0,3,2]  R454      1.2611895799636841e-01
    z[0,3,2]  R455      -6.1552878469228745e-02
    z[0,3,2]  R456      4.1487866640090942e-01
    z[0,3,2]  R457      -1.4426006376743317e-01
    z[0,3,2]  R458      2.4643549323081970e-01
    z[0,3,2]  R459      4.1255244612693787e-01
    z[0,3,2]  R460      -5.7148575782775879e-01
    z[0,3,2]  R461      -4.5504567027091980e-01
    z[0,3,2]  R462      1.2018267810344696e-01
    z[0,3,2]  R463      1.8982850015163422e-02
    z[0,3,2]  R464      4.3548887968063354e-01
    z[0,3,2]  R465      -5.8144873380661011e-01
    z[0,3,2]  R466      -1.5069223940372467e-01
    z[0,3,2]  R467      5.2009713649749756e-01
    z[0,3,2]  R468      -1.9687506556510925e-01
    z[0,3,2]  R469      0.0201080534607172
    z[0,3,2]  R470      5.2347022294998169e-01
    z[0,3,2]  R471      -1.1046304553747177e-01
    z[0,3,2]  R472      -6.4911562204360962e-01
    z[0,3,2]  R473      -4.1073363274335861e-02
    z[0,3,2]  R474      -1.6348633170127869e-01
    z[0,3,2]  R475      -1.5209870040416718e-01
    z[0,3,2]  R476      -1.8222853541374207e-01
    z[0,3,2]  R477      5.5721467733383179e-01
    z[0,3,2]  R478      -1.1913654953241348e-01
    z[0,3,2]  R479      4.4215241074562073e-01
    z[0,3,2]  R480      2.7167335152626038e-01
    z[0,3,2]  R481      -3.1831446290016174e-01
    z[0,3,2]  R482      -2.2658412158489227e-01
    z[0,3,2]  R483      -1.0902421921491623e-01
    z[0,3,2]  R484      -1.0851480066776276e-01
    z[0,3,2]  R485      1.1226566135883331e-01
    z[0,3,2]  R486      -5.3804680705070496e-02
    z[0,3,2]  R487      -4.2838653922080994e-01
    z[0,3,2]  R488      5.1253533363342285e-01
    z[0,3,2]  R489      -2.6043480634689331e-01
    z[0,3,2]  R490      -4.9675479531288147e-01
    z[0,3,2]  R491      6.2754553556442261e-01
    z[0,3,2]  R492      -1.7652894556522369e-01
    z[0,3,2]  R493      1.6643513739109039e-01
    z[0,3,2]  R494      -2.4202552437782288e-01
    z[0,3,2]  R495      2.7322193980216980e-01
    z[0,3,2]  R496      4.3216076493263245e-01
    z[0,3,2]  R497      4.0930751711130142e-02
    z[0,3,2]  R498      -3.2603389024734497e-01
    z[0,3,2]  R499      2.0815475285053253e-01
    z[0,3,2]  R500      -1.8299816176295280e-02
    z[0,3,2]  R501      1.6122369468212128e-01
    z[0,3,2]  R502      -3.9493107795715332e-01
    z[0,3,2]  R503      -1.2309246696531773e-02
    z[0,3,2]  R504      -7.8025050461292267e-02
    z[0,3,2]  R505      2.3661802709102631e-01
    z[0,3,2]  R506      -0.338933527469635
    z[0,3,2]  R507      -4.0052774548530579e-01
    z[0,3,2]  R508      5.3929162025451660e-01
    z[0,3,2]  R509      -2.8605839610099792e-01
    z[0,3,2]  R510      -7.1341377496719360e-01
    z[0,3,2]  R511      6.6442453861236572e-01
    z[0,3,2]  R512      5.2587682008743286e-01
    z[0,3,2]  R513      -2.2238335013389587e-01
    z[0,3,2]  R514      -2.7310755848884583e-01
    z[0,3,2]  R515      -2.7657121419906616e-01
    z[0,3,2]  R516      -1.7558740451931953e-02
    z[0,3,2]  R517      -3.4730517864227295e-01
    z[0,3,2]  R518      -1.4648345112800598e-01
    z[0,3,2]  R519      -4.0350863337516785e-01
    z[0,3,2]  R520      7.0236515998840332e-01
    z[0,3,2]  R521      -1.2193604372441769e-02
    z[0,3,2]  R522      5.3562176227569580e-01
    z[0,3,2]  R523      1.8169675767421722e-01
    z[0,3,2]  R524      5.2796679735183716e-01
    z[0,3,2]  R525      5.4261833429336548e-01
    z[0,3,2]  R526      -7.4606072902679443e-01
    z[0,3,2]  R527      1.7190891504287720e-01
    z[0,3,2]  R528      -3.0966898798942566e-01
    z[0,3,2]  R529      2.1271331608295441e-01
    z[0,3,2]  R530      2.2867359220981598e-02
    z[0,3,2]  R531      -1.0302006453275681e-01
    z[0,3,2]  R532      -1.3841852545738220e-01
    z[0,3,2]  R533      6.8635516799986362e-03
    z[0,3,2]  R534      1.3173352181911469e-01
    z[0,3,2]  R535      -1.1156410723924637e-01
    z[0,3,2]  R536      3.9218932390213013e-01
    z[0,3,2]  R537      -1.8157172203063965e-01
    z[0,3,2]  R538      3.2757565379142761e-01
    z[0,3,2]  R539      1.9680313766002655e-01
    z[0,3,2]  R540      4.5352223515510559e-01
    z[0,3,2]  R541      2.9588249325752258e-01
    z[0,3,2]  R542      -5.0353008508682251e-01
    z[0,3,2]  R543      3.9402994513511658e-01
    z[0,3,2]  R544      3.4777870774269104e-01
    z[0,3,2]  R545      3.1732836365699768e-01
    z[0,3,2]  R546      -5.5367767810821533e-01
    z[0,3,2]  R547      5.6241697072982788e-01
    z[0,3,2]  R548      -5.9100198745727539e-01
    z[0,3,2]  R549      3.3056426048278809e-01
    z[0,3,2]  R550      -2.4744980037212372e-01
    z[0,3,2]  R551      2.2165837883949280e-01
    z[0,3,2]  R552      1.9918750226497650e-01
    z[0,3,2]  R553      0.0682726576924324
    z[0,3,2]  R554      -1.8451346457004547e-01
    z[0,3,2]  R555      -1.3119451701641083e-01
    z[0,3,2]  R556      1.2991547584533691e-02
    z[0,3,2]  R557      -3.0424109101295471e-01
    z[0,3,2]  R558      1.2071663886308670e-01
    z[0,3,2]  R559      -3.4740817500278354e-04
    z[0,3,2]  R560      3.3287355303764343e-01
    z[0,3,2]  R561      1.1665407568216324e-01
    z[0,3,2]  R562      4.0914547443389893e-01
    z[0,3,2]  R563      -3.4522455930709839e-01
    z[0,3,2]  R564      -5.6712850928306580e-02
    z[0,3,2]  R565      -1.4610143005847931e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R419      -1
    z[0,3,3]  R420      1
    z[0,3,3]  R427      0.00919360015541315
    z[0,3,3]  R428      2.7194846421480179e-02
    z[0,3,3]  R429      -3.4394222497940063e-01
    z[0,3,3]  R430      -2.9011097550392151e-01
    z[0,3,3]  R431      2.4903476238250732e-01
    z[0,3,3]  R432      -2.2532276809215546e-01
    z[0,3,3]  R433      0.312175452709198
    z[0,3,3]  R434      -3.8715666532516479e-01
    z[0,3,3]  R435      -2.5482279062271118e-01
    z[0,3,3]  R436      -5.9454911947250366e-01
    z[0,3,3]  R437      3.3574298024177551e-01
    z[0,3,3]  R438      -2.1461232006549835e-01
    z[0,3,3]  R439      -1.5855069458484650e-01
    z[0,3,3]  R440      -4.1359403729438782e-01
    z[0,3,3]  R441      -1.9654460251331329e-01
    z[0,3,3]  R442      6.0009920597076416e-01
    z[0,3,3]  R443      3.2986736297607422e-01
    z[0,3,3]  R444      -1.6660936176776886e-01
    z[0,3,3]  R445      2.6079794764518738e-01
    z[0,3,3]  R446      1.9063760340213776e-01
    z[0,3,3]  R447      -1.6288323700428009e-01
    z[0,3,3]  R448      -0.350488543510437
    z[0,3,3]  R449      5.7509769685566425e-03
    z[0,3,3]  R450      -6.6776730120182037e-02
    z[0,3,3]  R451      3.5175219178199768e-01
    z[0,3,3]  R452      -9.1895036399364471e-02
    z[0,3,3]  R453      -1.6132335364818573e-01
    z[0,3,3]  R454      -3.7675538659095764e-01
    z[0,3,3]  R455      5.1050532609224319e-02
    z[0,3,3]  R456      -3.3609023690223694e-01
    z[0,3,3]  R457      9.2560619115829468e-02
    z[0,3,3]  R458      4.1062968969345093e-01
    z[0,3,3]  R459      -4.9150732159614563e-01
    z[0,3,3]  R460      3.0427560210227966e-01
    z[0,3,3]  R461      -3.7423957139253616e-02
    z[0,3,3]  R462      7.6432478427886963e-01
    z[0,3,3]  R463      0.371351420879364
    z[0,3,3]  R464      -0.270082950592041
    z[0,3,3]  R465      -5.0245355814695358e-02
    z[0,3,3]  R466      -3.0831021070480347e-01
    z[0,3,3]  R467      -2.0431217551231384e-01
    z[0,3,3]  R468      -1.0609222948551178e-01
    z[0,3,3]  R469      0.522624135017395
    z[0,3,3]  R470      -2.4257950484752655e-01
    z[0,3,3]  R471      8.3517897129058838e-01
    z[0,3,3]  R472      -2.3713992536067963e-01
    z[0,3,3]  R473      1.7736728489398956e-01
    z[0,3,3]  R474      4.9250704050064087e-01
    z[0,3,3]  R475      3.4422501921653748e-02
    z[0,3,3]  R476      -2.3740322887897491e-01
    z[0,3,3]  R477      -1.6251015663146973e-01
    z[0,3,3]  R478      0.574330747127533
    z[0,3,3]  R479      2.0639950037002563e-01
    z[0,3,3]  R480      5.0674965605139732e-03
    z[0,3,3]  R481      -1.4749768376350403e-01
    z[0,3,3]  R482      -1.6726320981979370e-01
    z[0,3,3]  R483      -2.8104493021965027e-01
    z[0,3,3]  R484      -0.0925268605351448
    z[0,3,3]  R485      1.2001358903944492e-02
    z[0,3,3]  R486      -4.5203246176242828e-02
    z[0,3,3]  R487      -3.4919625520706177e-01
    z[0,3,3]  R488      -1.7929084599018097e-02
    z[0,3,3]  R489      2.7303194999694824e-01
    z[0,3,3]  R490      -3.5218429565429688e-01
    z[0,3,3]  R491      3.2124549150466919e-02
    z[0,3,3]  R492      -1.8332313047721982e-03
    z[0,3,3]  R493      -4.7861579060554504e-01
    z[0,3,3]  R494      -2.9377844929695129e-01
    z[0,3,3]  R495      -3.6752650141716003e-01
    z[0,3,3]  R496      -4.6634238958358765e-01
    z[0,3,3]  R497      -7.7418766915798187e-02
    z[0,3,3]  R498      8.1320095062255859e-01
    z[0,3,3]  R499      -3.8583735004067421e-03
    z[0,3,3]  R500      3.5540437698364258e-01
    z[0,3,3]  R501      3.0389702320098877e-01
    z[0,3,3]  R502      -0.0907410979270935
    z[0,3,3]  R503      6.5078479051589966e-01
    z[0,3,3]  R504      2.4905851483345032e-01
    z[0,3,3]  R505      6.0266852378845215e-01
    z[0,3,3]  R506      0.380577027797699
    z[0,3,3]  R507      -1.5043872594833374e-01
    z[0,3,3]  R508      -2.0054295659065247e-01
    z[0,3,3]  R509      5.1038622856140137e-01
    z[0,3,3]  R510      -3.4189623594284058e-01
    z[0,3,3]  R511      2.6827251911163330e-01
    z[0,3,3]  R512      -1.0436327010393143e-01
    z[0,3,3]  R513      3.3484068512916565e-01
    z[0,3,3]  R514      -2.3631818592548370e-01
    z[0,3,3]  R515      3.1567353010177612e-01
    z[0,3,3]  R516      -3.0971601605415344e-01
    z[0,3,3]  R517      -4.2700907588005066e-01
    z[0,3,3]  R518      -1.3089103996753693e-01
    z[0,3,3]  R519      5.0435356795787811e-02
    z[0,3,3]  R520      -1.8006978556513786e-02
    z[0,3,3]  R521      -5.4041433334350586e-01
    z[0,3,3]  R522      -1.6749298572540283e-01
    z[0,3,3]  R523      2.4034446477890015e-01
    z[0,3,3]  R524      -1.5765495598316193e-01
    z[0,3,3]  R525      -4.5238324999809265e-01
    z[0,3,3]  R526      6.0132112354040146e-02
    z[0,3,3]  R527      -3.5726919770240784e-01
    z[0,3,3]  R528      1.7948009073734283e-01
    z[0,3,3]  R529      1.7335766926407814e-02
    z[0,3,3]  R530      0.554954469203949
    z[0,3,3]  R531      4.6995395421981812e-01
    z[0,3,3]  R532      6.5578943490982056e-01
    z[0,3,3]  R533      5.3399151563644409e-01
    z[0,3,3]  R534      1.7057047784328461e-01
    z[0,3,3]  R535      0.805041491985321
    z[0,3,3]  R536      1.4910751581192017e-01
    z[0,3,3]  R537      3.3688324689865112e-01
    z[0,3,3]  R538      1.6703270375728607e-01
    z[0,3,3]  R539      -1.6435244679450989e-01
    z[0,3,3]  R540      -2.5326707959175110e-01
    z[0,3,3]  R541      1.2513893842697144e-01
    z[0,3,3]  R542      -2.2047157585620880e-01
    z[0,3,3]  R543      -3.8990822434425354e-01
    z[0,3,3]  R544      -2.3397500813007355e-01
    z[0,3,3]  R545      4.9153860658407211e-02
    z[0,3,3]  R546      -9.9736951291561127e-02
    z[0,3,3]  R547      1.5958513319492340e-01
    z[0,3,3]  R548      -1.8974952399730682e-02
    z[0,3,3]  R549      -8.5029698908329010e-02
    z[0,3,3]  R550      -7.3701471090316772e-01
    z[0,3,3]  R551      -5.1005744934082031e-01
    z[0,3,3]  R552      -3.5362154245376587e-01
    z[0,3,3]  R553      -3.0872595310211182e-01
    z[0,3,3]  R554      9.6516653895378113e-02
    z[0,3,3]  R555      0.767477810382843
    z[0,3,3]  R556      -5.9185636043548584e-01
    z[0,3,3]  R557      -1.9000720977783203e-01
    z[0,3,3]  R558      3.6175560951232910e-01
    z[0,3,3]  R559      3.6101114749908447e-01
    z[0,3,3]  R560      -1.9300375878810883e-01
    z[0,3,3]  R561      2.0218791067600250e-01
    z[0,3,3]  R562      2.9652403667569160e-02
    z[0,3,3]  R563      7.5273603200912476e-01
    z[0,3,3]  R564      1.7682921886444092e-01
    z[0,3,3]  R565      -1.7934386432170868e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R421      -1
    z[0,3,4]  R422      1
    z[0,3,4]  R427      1.2621775269508362e-01
    z[0,3,4]  R428      4.3071404099464417e-01
    z[0,3,4]  R429      3.2724443823099136e-02
    z[0,3,4]  R430      0.257503867149353
    z[0,3,4]  R431      3.4328451752662659e-01
    z[0,3,4]  R432      6.9391697645187378e-02
    z[0,3,4]  R433      -6.1629676818847656e-01
    z[0,3,4]  R434      3.7020224332809448e-01
    z[0,3,4]  R435      -3.1938779354095459e-01
    z[0,3,4]  R436      1.0658331215381622e-01
    z[0,3,4]  R437      7.4869275093078613e-02
    z[0,3,4]  R438      -1.6004875302314758e-01
    z[0,3,4]  R439      -2.3936209082603455e-01
    z[0,3,4]  R440      -0.0923909991979599
    z[0,3,4]  R441      -1.3523493707180023e-01
    z[0,3,4]  R442      -4.2124426364898682e-01
    z[0,3,4]  R443      -4.9312117695808411e-01
    z[0,3,4]  R444      -5.5431240797042847e-01
    z[0,3,4]  R445      -4.9785044789314270e-01
    z[0,3,4]  R446      3.2990675419569016e-02
    z[0,3,4]  R447      1.6835348308086395e-01
    z[0,3,4]  R448      8.0416696146130562e-03
    z[0,3,4]  R449      -1.0430266708135605e-01
    z[0,3,4]  R450      4.0577873587608337e-01
    z[0,3,4]  R451      -1.4028076827526093e-01
    z[0,3,4]  R452      3.4348881244659424e-01
    z[0,3,4]  R453      2.8809541463851929e-01
    z[0,3,4]  R454      1.9812004640698433e-02
    z[0,3,4]  R455      -2.5096428394317627e-01
    z[0,3,4]  R456      3.6399370431900024e-01
    z[0,3,4]  R457      2.0979216694831848e-01
    z[0,3,4]  R458      2.0947840809822083e-01
    z[0,3,4]  R459      1.3595707714557648e-01
    z[0,3,4]  R460      -1.9441372156143188e-01
    z[0,3,4]  R461      -7.6700314879417419e-02
    z[0,3,4]  R462      -5.0680446624755859e-01
    z[0,3,4]  R463      1.0740419477224350e-01
    z[0,3,4]  R464      -3.5317346453666687e-01
    z[0,3,4]  R465      -9.2873267829418182e-02
    z[0,3,4]  R466      4.1667231917381287e-01
    z[0,3,4]  R467      2.7484133839607239e-01
    z[0,3,4]  R468      -4.5726341195404530e-03
    z[0,3,4]  R469      5.4045025259256363e-02
    z[0,3,4]  R470      -1.1667429655790329e-01
    z[0,3,4]  R471      -4.5199674367904663e-01
    z[0,3,4]  R472      3.3902961015701294e-01
    z[0,3,4]  R473      -4.1172477602958679e-01
    z[0,3,4]  R474      7.5132292509078979e-01
    z[0,3,4]  R475      -3.4670770168304443e-01
    z[0,3,4]  R476      -2.2079072892665863e-01
    z[0,3,4]  R477      -1.1875396221876144e-01
    z[0,3,4]  R478      -3.1644481420516968e-01
    z[0,3,4]  R479      3.1604072451591492e-01
    z[0,3,4]  R480      4.8546192049980164e-01
    z[0,3,4]  R481      -0.128139927983284
    z[0,3,4]  R482      -0.0866321325302124
    z[0,3,4]  R483      2.3385412991046906e-01
    z[0,3,4]  R484      5.7850323617458344e-02
    z[0,3,4]  R485      0.257344514131546
    z[0,3,4]  R486      2.4556914344429970e-02
    z[0,3,4]  R487      -1.6494618356227875e-01
    z[0,3,4]  R488      -1.3364669680595398e-01
    z[0,3,4]  R489      -1.1719775199890137e-01
    z[0,3,4]  R490      2.2424438595771790e-01
    z[0,3,4]  R491      -0.00995875895023346
    z[0,3,4]  R492      -3.8880905508995056e-01
    z[0,3,4]  R493      4.3893387913703918e-01
    z[0,3,4]  R494      2.5893932580947876e-01
    z[0,3,4]  R495      2.4864292144775391e-01
    z[0,3,4]  R496      -5.9497680515050888e-02
    z[0,3,4]  R497      1.3169558346271515e-01
    z[0,3,4]  R498      -3.2660955190658569e-01
    z[0,3,4]  R499      2.6325416564941406e-01
    z[0,3,4]  R500      -1.8018412590026855e-01
    z[0,3,4]  R501      2.0091657340526581e-01
    z[0,3,4]  R502      3.4084555506706238e-01
    z[0,3,4]  R503      -7.8271649777889252e-02
    z[0,3,4]  R504      -2.3090025782585144e-01
    z[0,3,4]  R505      5.3224277496337891e-01
    z[0,3,4]  R506      2.5602266192436218e-01
    z[0,3,4]  R507      -3.1911402940750122e-02
    z[0,3,4]  R508      -3.4819513559341431e-02
    z[0,3,4]  R509      -6.8201929330825806e-01
    z[0,3,4]  R510      2.4720046669244766e-02
    z[0,3,4]  R511      0.348127543926239
    z[0,3,4]  R512      1.2218102067708969e-01
    z[0,3,4]  R513      4.8597112298011780e-01
    z[0,3,4]  R514      -3.2860539853572845e-02
    z[0,3,4]  R515      5.6821429729461670e-01
    z[0,3,4]  R516      5.9923237562179565e-01
    z[0,3,4]  R517      4.5822650194168091e-02
    z[0,3,4]  R518      -7.5653657317161560e-02
    z[0,3,4]  R519      -2.1640536189079285e-01
    z[0,3,4]  R520      3.8729336112737656e-02
    z[0,3,4]  R521      1.9678421318531036e-02
    z[0,3,4]  R522      -5.0368376076221466e-02
    z[0,3,4]  R523      2.0661942660808563e-01
    z[0,3,4]  R524      -1.2086541950702667e-01
    z[0,3,4]  R525      -9.5076836645603180e-02
    z[0,3,4]  R526      2.3639410734176636e-01
    z[0,3,4]  R527      -2.0589524507522583e-01
    z[0,3,4]  R528      7.2629086673259735e-02
    z[0,3,4]  R529      -0.0833207443356514
    z[0,3,4]  R530      -1.6864295303821564e-01
    z[0,3,4]  R531      2.0364646613597870e-01
    z[0,3,4]  R532      -1.3364824652671814e-01
    z[0,3,4]  R533      -4.5083454251289368e-01
    z[0,3,4]  R534      4.9073547124862671e-02
    z[0,3,4]  R535      -5.7916458696126938e-02
    z[0,3,4]  R536      -1.6701254248619080e-01
    z[0,3,4]  R537      -2.2128391265869141e-01
    z[0,3,4]  R538      2.5124964118003845e-01
    z[0,3,4]  R539      3.5647621750831604e-01
    z[0,3,4]  R540      -0.0849151685833931
    z[0,3,4]  R541      1.7805512249469757e-01
    z[0,3,4]  R542      5.1432031393051147e-01
    z[0,3,4]  R543      1.7972512543201447e-01
    z[0,3,4]  R544      -2.0716971158981323e-01
    z[0,3,4]  R545      1.2676016986370087e-01
    z[0,3,4]  R546      -1.0556812584400177e-01
    z[0,3,4]  R547      -9.2531302943825722e-03
    z[0,3,4]  R548      2.2112432122230530e-01
    z[0,3,4]  R549      4.4771939516067505e-01
    z[0,3,4]  R550      2.1878848969936371e-01
    z[0,3,4]  R551      -7.0104807615280151e-02
    z[0,3,4]  R552      2.0469594001770020e-01
    z[0,3,4]  R553      0.0848376527428627
    z[0,3,4]  R554      1.6652733087539673e-01
    z[0,3,4]  R555      1.6612590849399567e-01
    z[0,3,4]  R556      1.8307650089263916e-01
    z[0,3,4]  R557      -2.4783807992935181e-01
    z[0,3,4]  R558      -1.2648294866085052e-01
    z[0,3,4]  R559      -3.7038561701774597e-01
    z[0,3,4]  R560      2.1535834670066833e-01
    z[0,3,4]  R561      -3.8356855511665344e-01
    z[0,3,4]  R562      2.7675956487655640e-01
    z[0,3,4]  R563      7.4886791408061981e-03
    z[0,3,4]  R564      -1.6296248137950897e-01
    z[0,3,4]  R565      -3.6126505583524704e-02
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R423      -1
    z[0,3,5]  R424      1
    z[0,3,5]  R427      -5.0898045301437378e-02
    z[0,3,5]  R428      -2.7517560124397278e-01
    z[0,3,5]  R429      -5.5973863601684570e-01
    z[0,3,5]  R430      -6.2088322639465332e-01
    z[0,3,5]  R431      0.290799081325531
    z[0,3,5]  R432      -3.4118351340293884e-01
    z[0,3,5]  R433      2.5200262665748596e-01
    z[0,3,5]  R434      -2.1571926772594452e-01
    z[0,3,5]  R435      -4.1396751999855042e-01
    z[0,3,5]  R436      -5.5196538567543030e-02
    z[0,3,5]  R437      -0.340366005897522
    z[0,3,5]  R438      -3.3916282653808594e-01
    z[0,3,5]  R439      2.5396227836608887e-01
    z[0,3,5]  R440      -2.0888239145278931e-01
    z[0,3,5]  R441      -8.8600821793079376e-02
    z[0,3,5]  R442      0.0864071249961853
    z[0,3,5]  R443      -3.5851109772920609e-02
    z[0,3,5]  R444      1.2585379183292389e-01
    z[0,3,5]  R445      -5.6693799793720245e-02
    z[0,3,5]  R446      4.4701176881790161e-01
    z[0,3,5]  R447      9.5144383609294891e-02
    z[0,3,5]  R448      1.2219092994928360e-01
    z[0,3,5]  R449      -3.6877259612083435e-01
    z[0,3,5]  R450      -6.4557117223739624e-01
    z[0,3,5]  R451      2.4793425202369690e-01
    z[0,3,5]  R452      3.3341971039772034e-01
    z[0,3,5]  R453      0.415558785200119
    z[0,3,5]  R454      1.5356499701738358e-02
    z[0,3,5]  R455      -4.3897899985313416e-01
    z[0,3,5]  R456      5.1259106397628784e-01
    z[0,3,5]  R457      -0.0826454684138298
    z[0,3,5]  R458      -2.8129890561103821e-01
    z[0,3,5]  R459      3.9669489860534668e-01
    z[0,3,5]  R460      1.5606077015399933e-01
    z[0,3,5]  R461      -2.8040561079978943e-01
    z[0,3,5]  R462      1.8205150961875916e-01
    z[0,3,5]  R463      3.0326387286186218e-01
    z[0,3,5]  R464      0.228912353515625
    z[0,3,5]  R465      -2.2774764802306890e-03
    z[0,3,5]  R466      -3.2953587174415588e-01
    z[0,3,5]  R467      3.3728504180908203e-01
    z[0,3,5]  R468      -3.2062929123640060e-02
    z[0,3,5]  R469      -6.0443345457315445e-02
    z[0,3,5]  R470      2.9518043994903564e-01
    z[0,3,5]  R471      5.5045560002326965e-03
    z[0,3,5]  R472      -2.9020276665687561e-01
    z[0,3,5]  R473      -8.4798950701951981e-03
    z[0,3,5]  R474      6.6874980926513672e-02
    z[0,3,5]  R475      3.9979156851768494e-01
    z[0,3,5]  R476      0.0141511932015419
    z[0,3,5]  R477      2.4028590321540833e-01
    z[0,3,5]  R478      1.4296466112136841e-01
    z[0,3,5]  R479      5.2013820409774780e-01
    z[0,3,5]  R480      0.362602174282074
    z[0,3,5]  R481      -7.0562714338302612e-01
    z[0,3,5]  R482      -7.6083153486251831e-01
    z[0,3,5]  R483      -2.5893664360046387e-01
    z[0,3,5]  R484      3.4961634874343872e-01
    z[0,3,5]  R485      9.2065773904323578e-02
    z[0,3,5]  R486      0.290505051612854
    z[0,3,5]  R487      -4.6628376841545105e-01
    z[0,3,5]  R488      1.5312932431697845e-01
    z[0,3,5]  R489      -0.0842769518494606
    z[0,3,5]  R490      -3.5723760724067688e-01
    z[0,3,5]  R491      2.9243400692939758e-01
    z[0,3,5]  R492      5.2723549306392670e-02
    z[0,3,5]  R493      -6.9054342806339264e-02
    z[0,3,5]  R494      2.2902987897396088e-01
    z[0,3,5]  R495      -1.7587022483348846e-01
    z[0,3,5]  R496      -4.3951058387756348e-01
    z[0,3,5]  R497      -2.1963946521282196e-01
    z[0,3,5]  R498      -1.4680349826812744e-01
    z[0,3,5]  R499      3.5559117794036865e-01
    z[0,3,5]  R500      3.3225327730178833e-01
    z[0,3,5]  R501      -2.2312594950199127e-01
    z[0,3,5]  R502      -6.6104239225387573e-01
    z[0,3,5]  R503      -1.3015256822109222e-01
    z[0,3,5]  R504      -4.3054780364036560e-01
    z[0,3,5]  R505      -3.3977288007736206e-01
    z[0,3,5]  R506      2.9494670033454895e-01
    z[0,3,5]  R507      1.3274885714054108e-01
    z[0,3,5]  R508      2.7714800834655762e-01
    z[0,3,5]  R509      3.0091580748558044e-01
    z[0,3,5]  R510      -1.7766192555427551e-01
    z[0,3,5]  R511      2.3864848911762238e-01
    z[0,3,5]  R512      1.3339985907077789e-01
    z[0,3,5]  R513      -4.2681032419204712e-01
    z[0,3,5]  R514      4.8897233605384827e-01
    z[0,3,5]  R515      1.4568093419075012e-01
    z[0,3,5]  R516      -6.9919861853122711e-02
    z[0,3,5]  R517      -2.8510031104087830e-01
    z[0,3,5]  R518      -2.7459102869033813e-01
    z[0,3,5]  R519      -1.7809697985649109e-01
    z[0,3,5]  R520      -9.8730325698852539e-02
    z[0,3,5]  R521      -3.5191348195075989e-01
    z[0,3,5]  R522      9.1518782079219818e-02
    z[0,3,5]  R523      2.5892412662506104e-01
    z[0,3,5]  R524      1.6486391425132751e-01
    z[0,3,5]  R525      3.9414229989051819e-01
    z[0,3,5]  R526      3.0530977994203568e-02
    z[0,3,5]  R527      2.5256010890007019e-01
    z[0,3,5]  R528      6.9754086434841156e-02
    z[0,3,5]  R529      2.7698242664337158e-01
    z[0,3,5]  R530      -0.438755065202713
    z[0,3,5]  R531      -3.2588756084442139e-01
    z[0,3,5]  R532      -8.9207157492637634e-02
    z[0,3,5]  R533      -2.6879742741584778e-01
    z[0,3,5]  R534      -2.2403210401535034e-01
    z[0,3,5]  R535      -1.5371562540531158e-01
    z[0,3,5]  R536      0.49073326587677
    z[0,3,5]  R537      5.6967481970787048e-02
    z[0,3,5]  R538      7.2781629860401154e-02
    z[0,3,5]  R539      3.0580663681030273e-01
    z[0,3,5]  R540      5.1552492380142212e-01
    z[0,3,5]  R541      -7.9626701772212982e-02
    z[0,3,5]  R542      -1.2868297100067139e-01
    z[0,3,5]  R543      3.3688607811927795e-01
    z[0,3,5]  R544      5.1151913404464722e-01
    z[0,3,5]  R545      3.6664155125617981e-01
    z[0,3,5]  R546      0.366933673620224
    z[0,3,5]  R547      2.4038605391979218e-01
    z[0,3,5]  R548      -2.6346214581280947e-03
    z[0,3,5]  R549      -8.3512723445892334e-02
    z[0,3,5]  R550      3.2308793067932129e-01
    z[0,3,5]  R551      -3.8913673162460327e-01
    z[0,3,5]  R552      -4.0350112318992615e-01
    z[0,3,5]  R553      -6.3718676567077637e-01
    z[0,3,5]  R554      -8.0009198188781738e-01
    z[0,3,5]  R555      -1.8298944830894470e-01
    z[0,3,5]  R556      1.9466073717921972e-04
    z[0,3,5]  R557      4.1467356681823730e-01
    z[0,3,5]  R558      -4.6634575724601746e-01
    z[0,3,5]  R559      -2.3785832524299622e-01
    z[0,3,5]  R560      1.3878895342350006e-01
    z[0,3,5]  R561      -1.7217348515987396e-01
    z[0,3,5]  R562      -7.0632971823215485e-02
    z[0,3,5]  R563      2.8447309136390686e-01
    z[0,3,5]  R564      -0.0577826164662838
    z[0,3,5]  R565      -3.6176130175590515e-02
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R425      -1
    z[0,3,6]  R426      1
    z[0,3,6]  R427      3.1428948044776917e-02
    z[0,3,6]  R428      -1.2347525358200073e-01
    z[0,3,6]  R429      2.1435044705867767e-01
    z[0,3,6]  R430      6.4815111458301544e-02
    z[0,3,6]  R431      7.9461887478828430e-02
    z[0,3,6]  R432      -5.0881922245025635e-02
    z[0,3,6]  R433      1.9700525701045990e-01
    z[0,3,6]  R434      -1.4722093008458614e-02
    z[0,3,6]  R435      2.7972161769866943e-01
    z[0,3,6]  R436      -1.4217411167919636e-02
    z[0,3,6]  R437      -3.7718974053859711e-02
    z[0,3,6]  R438      -2.4991898238658905e-01
    z[0,3,6]  R439      3.0058425664901733e-01
    z[0,3,6]  R440      3.0824345350265503e-01
    z[0,3,6]  R441      8.1671245396137238e-02
    z[0,3,6]  R442      1.1477380245923996e-01
    z[0,3,6]  R443      1.0683772154152393e-02
    z[0,3,6]  R444      -1.5544918179512024e-01
    z[0,3,6]  R445      4.9034300446510315e-01
    z[0,3,6]  R446      -1.8377602100372314e-01
    z[0,3,6]  R447      -0.37274369597435
    z[0,3,6]  R448      1.5977036207914352e-02
    z[0,3,6]  R449      1.6093797981739044e-01
    z[0,3,6]  R450      4.3478954583406448e-02
    z[0,3,6]  R451      -1.6550987958908081e-01
    z[0,3,6]  R452      -7.1623444557189941e-02
    z[0,3,6]  R453      -2.7719438076019287e-01
    z[0,3,6]  R454      -1.8942917883396149e-01
    z[0,3,6]  R455      0.43539959192276
    z[0,3,6]  R456      2.8288811445236206e-01
    z[0,3,6]  R457      -3.3108890056610107e-01
    z[0,3,6]  R458      2.4633076041936874e-02
    z[0,3,6]  R459      1.7295395955443382e-02
    z[0,3,6]  R460      5.9470415115356445e-02
    z[0,3,6]  R461      2.6722386479377747e-01
    z[0,3,6]  R462      -1.2938253581523895e-01
    z[0,3,6]  R463      1.0591533035039902e-01
    z[0,3,6]  R464      -1.6675411164760590e-01
    z[0,3,6]  R465      -1.0583539307117462e-01
    z[0,3,6]  R466      2.2988523542881012e-01
    z[0,3,6]  R467      -7.8124955296516418e-02
    z[0,3,6]  R468      -3.4003564715385437e-01
    z[0,3,6]  R469      -2.0062687993049622e-01
    z[0,3,6]  R470      -1.7484804987907410e-01
    z[0,3,6]  R471      -1.8011310696601868e-01
    z[0,3,6]  R472      -2.2598819434642792e-01
    z[0,3,6]  R473      2.5719873607158661e-02
    z[0,3,6]  R474      -8.3407811820507050e-02
    z[0,3,6]  R475      2.7665841579437256e-01
    z[0,3,6]  R476      2.1546630561351776e-01
    z[0,3,6]  R477      -1.9060879945755005e-01
    z[0,3,6]  R478      1.4744338393211365e-01
    z[0,3,6]  R479      1.7841245234012604e-01
    z[0,3,6]  R480      1.9542181491851807e-01
    z[0,3,6]  R481      3.0342981219291687e-01
    z[0,3,6]  R482      1.4042806625366211e-01
    z[0,3,6]  R483      5.1081973314285278e-01
    z[0,3,6]  R484      4.2690034955739975e-02
    z[0,3,6]  R485      4.5900359749794006e-01
    z[0,3,6]  R486      6.2206890434026718e-02
    z[0,3,6]  R487      1.7906057834625244e-01
    z[0,3,6]  R488      -1.8205833435058594e-01
    z[0,3,6]  R489      -8.5641875863075256e-02
    z[0,3,6]  R490      5.5052293464541435e-03
    z[0,3,6]  R491      2.7318498492240906e-01
    z[0,3,6]  R492      9.1474344953894615e-03
    z[0,3,6]  R493      1.3312149047851562e-01
    z[0,3,6]  R494      -1.0616851598024368e-01
    z[0,3,6]  R495      -1.2419880181550980e-01
    z[0,3,6]  R496      -1.3380878372117877e-03
    z[0,3,6]  R497      -8.7297163903713226e-02
    z[0,3,6]  R498      2.3277722299098969e-01
    z[0,3,6]  R499      1.1558146029710770e-01
    z[0,3,6]  R500      -0.0084022656083107
    z[0,3,6]  R501      4.3134069442749023e-01
    z[0,3,6]  R502      2.4139201641082764e-01
    z[0,3,6]  R503      3.5985150933265686e-01
    z[0,3,6]  R504      0.335778146982193
    z[0,3,6]  R505      -0.361446738243103
    z[0,3,6]  R506      2.3352560400962830e-01
    z[0,3,6]  R507      4.9750655889511108e-02
    z[0,3,6]  R508      -1.0317817330360413e-01
    z[0,3,6]  R509      -1.2786078453063965e-01
    z[0,3,6]  R510      -2.5190016627311707e-01
    z[0,3,6]  R511      -2.3922783136367798e-01
    z[0,3,6]  R512      5.5657601356506348e-01
    z[0,3,6]  R513      -3.3673766255378723e-01
    z[0,3,6]  R514      0.323076069355011
    z[0,3,6]  R515      -1.0856927372515202e-02
    z[0,3,6]  R516      -1.5177269279956818e-01
    z[0,3,6]  R517      1.8634596839547157e-02
    z[0,3,6]  R518      6.1599975824356079e-01
    z[0,3,6]  R519      2.8018739819526672e-01
    z[0,3,6]  R520      3.2007377594709396e-02
    z[0,3,6]  R521      4.5550405979156494e-01
    z[0,3,6]  R522      5.9498608112335205e-02
    z[0,3,6]  R523      9.0559042990207672e-02
    z[0,3,6]  R524      6.8040627241134644e-01
    z[0,3,6]  R525      4.9363193102180958e-03
    z[0,3,6]  R526      -2.4662408232688904e-01
    z[0,3,6]  R527      -7.3229223489761353e-02
    z[0,3,6]  R528      5.0963556766510010e-01
    z[0,3,6]  R529      5.3769510984420776e-01
    z[0,3,6]  R530      1.2688353657722473e-01
    z[0,3,6]  R531      7.3101505637168884e-02
    z[0,3,6]  R532      9.3675171956419945e-03
    z[0,3,6]  R533      -1.5260463953018188e-01
    z[0,3,6]  R534      -0.163701593875885
    z[0,3,6]  R535      1.6433374583721161e-01
    z[0,3,6]  R536      -2.5771612301468849e-02
    z[0,3,6]  R537      -2.8085660934448242e-01
    z[0,3,6]  R538      2.1825022995471954e-01
    z[0,3,6]  R539      2.3344756662845612e-01
    z[0,3,6]  R540      2.6692020893096924e-01
    z[0,3,6]  R541      -6.2983624637126923e-02
    z[0,3,6]  R542      6.0644489526748657e-01
    z[0,3,6]  R543      0.150406152009964
    z[0,3,6]  R544      1.0031318664550781e-01
    z[0,3,6]  R545      1.2571129016578197e-02
    z[0,3,6]  R546      4.1141849756240845e-01
    z[0,3,6]  R547      3.5320450551807880e-03
    z[0,3,6]  R548      6.8976622819900513e-01
    z[0,3,6]  R549      -1.2096484750509262e-01
    z[0,3,6]  R550      3.9257019758224487e-01
    z[0,3,6]  R551      1.1280041933059692e-01
    z[0,3,6]  R552      4.1892158985137939e-01
    z[0,3,6]  R553      5.0528898835182190e-02
    z[0,3,6]  R554      0.161977618932724
    z[0,3,6]  R555      3.3900722861289978e-01
    z[0,3,6]  R556      2.2306475043296814e-01
    z[0,3,6]  R557      3.1190004944801331e-01
    z[0,3,6]  R558      -7.7244572341442108e-02
    z[0,3,6]  R559      2.8067186474800110e-01
    z[0,3,6]  R560      2.8628465533256531e-01
    z[0,3,6]  R561      2.0274116098880768e-01
    z[0,3,6]  R562      3.5062986612319946e-01
    z[0,3,6]  R563      2.9905807971954346e-01
    z[0,3,6]  R564      1.8012440204620361e-01
    z[0,3,6]  R565      -1.4839315414428711e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R566      -1
    z[3,0,0]  R567      1
    z[3,0,0]  R580      -6.0292345285415649e-01
    z[3,0,0]  R581      -5.9713470935821533e-01
    z[3,0,0]  R582      -7.9646384716033936e-01
    z[3,0,0]  R583      0.593394935131073
    z[3,0,0]  R584      -0.430400013923645
    z[3,0,0]  R585      3.6738941073417664e-01
    z[3,0,0]  R586      6.8841701745986938e-01
    z[3,0,0]  R587      2.7344632148742676e-01
    z[3,0,0]  R588      3.5563737154006958e-01
    z[3,0,0]  R589      4.9206703901290894e-01
    z[3,0,0]  R590      -2.8547435998916626e-01
    z[3,0,0]  R591      -1.9855169579386711e-02
    z[3,0,0]  R592      -7.0916842669248581e-03
    z[3,0,0]  R593      -2.0397590473294258e-02
    z[3,0,0]  R594      -6.5713502466678619e-02
    z[3,0,0]  R595      3.0177175998687744e-01
    z[3,0,0]  R596      3.8811814785003662e-01
    z[3,0,0]  R597      -1.8501804769039154e-01
    z[3,0,0]  R598      0.167601078748703
    z[3,0,0]  R599      8.1268265843391418e-02
    z[3,0,0]  R600      5.1078337430953979e-01
    z[3,0,0]  R601      -2.2165615856647491e-01
    z[3,0,0]  R602      7.2538322210311890e-01
    z[3,0,0]  R603      8.0320823192596436e-01
    z[3,0,0]  R604      5.4646110534667969e-01
    z[3,0,0]  R605      4.4635590910911560e-01
    z[3,0,0]  R606      5.7215999811887741e-02
    z[3,0,0]  R607      6.9971328973770142e-01
    z[3,0,0]  R608      0.713864803314209
    z[3,0,0]  R609      7.7606225013732910e-01
    z[3,0,0]  R610      -0.397827684879303
    z[3,0,0]  R611      7.2482812404632568e-01
    z[3,0,0]  R612      -2.4095913767814636e-01
    z[3,0,0]  R613      0.813280463218689
    z[3,0,0]  R614      1.3921824283897877e-02
    z[3,0,0]  R615      6.2162774801254272e-01
    z[3,0,0]  R616      5.1198744773864746e-01
    z[3,0,0]  R617      6.4981174468994141e-01
    z[3,0,0]  R618      -4.9261572957038879e-01
    z[3,0,0]  R619      2.5793758034706116e-01
    z[3,0,0]  R620      6.9175004959106445e-02
    z[3,0,0]  R621      -3.7531760334968567e-01
    z[3,0,0]  R622      -4.9100264906883240e-02
    z[3,0,0]  R623      3.8662287592887878e-01
    z[3,0,0]  R624      7.8889721632003784e-01
    z[3,0,0]  R625      -3.9210504293441772e-01
    z[3,0,0]  R626      7.3289644718170166e-01
    z[3,0,0]  R627      1.8111538887023926e-01
    z[3,0,0]  R628      -3.0878129601478577e-01
    z[3,0,0]  R629      -3.5077667236328125e-01
    z[3,0,0]  R630      5.2258968353271484e-01
    z[3,0,0]  R631      2.7141281962394714e-01
    z[3,0,0]  R632      -5.9181714057922363e-01
    z[3,0,0]  R633      -5.4779791831970215e-01
    z[3,0,0]  R634      6.4446645975112915e-01
    z[3,0,0]  R635      2.4215668439865112e-01
    z[3,0,0]  R636      -0.502898633480072
    z[3,0,0]  R637      -5.9624433517456055e-01
    z[3,0,0]  R638      -0.508691668510437
    z[3,0,0]  R639      -2.1039625629782677e-02
    z[3,0,0]  R640      -6.3955950736999512e-01
    z[3,0,0]  R641      3.8346239924430847e-01
    z[3,0,0]  R642      -5.8709084987640381e-01
    z[3,0,0]  R643      -5.7609003782272339e-01
    z[3,0,0]  R644      -1.5098403394222260e-01
    z[3,0,0]  R645      3.4997817873954773e-01
    z[3,0,0]  R646      1.9455881416797638e-01
    z[3,0,0]  R647      -1.0306473821401596e-01
    z[3,0,0]  R648      7.2607177495956421e-01
    z[3,0,0]  R649      3.5984647274017334e-01
    z[3,0,0]  R650      4.0053266286849976e-01
    z[3,0,0]  R651      2.8451833128929138e-01
    z[3,0,0]  R652      -4.9256992340087891e-01
    z[3,0,0]  R653      5.8289057016372681e-01
    z[3,0,0]  R654      3.2223412394523621e-01
    z[3,0,0]  R655      5.2027565240859985e-01
    z[3,0,0]  R656      8.9749681949615479e-01
    z[3,0,0]  R657      7.7735997736454010e-02
    z[3,0,0]  R658      4.8377230763435364e-01
    z[3,0,0]  R659      3.3621346950531006e-01
    z[3,0,0]  R660      4.4479519128799438e-01
    z[3,0,0]  R661      6.3285452127456665e-01
    z[3,0,0]  R662      2.5843468308448792e-01
    z[3,0,0]  R663      4.4759970158338547e-02
    z[3,0,0]  R664      1.8317356705665588e-01
    z[3,0,0]  R665      -1.5814730897545815e-02
    z[3,0,0]  R666      7.2875326871871948e-01
    z[3,0,0]  R667      1.0331102460622787e-01
    z[3,0,0]  R668      -4.7458952665328979e-01
    z[3,0,0]  R669      5.9786039590835571e-01
    z[3,0,0]  R670      2.3851300776004791e-01
    z[3,0,0]  R671      2.6434731483459473e-01
    z[3,0,0]  R672      7.2767162322998047e-01
    z[3,0,0]  R673      5.7752884924411774e-02
    z[3,0,0]  R674      -0.486916184425354
    z[3,0,0]  R675      4.2904263734817505e-01
    z[3,0,0]  R676      1.7858929932117462e-01
    z[3,0,0]  R677      -1.9521364942193031e-02
    z[3,0,0]  R678      2.5948521494865417e-01
    z[3,0,0]  R679      6.5763312578201294e-01
    z[3,0,0]  R680      3.5264107584953308e-01
    z[3,0,0]  R681      5.9940475225448608e-01
    z[3,0,0]  R682      0.693200409412384
    z[3,0,0]  R683      -5.1868766546249390e-01
    z[3,0,0]  R684      -5.5990439653396606e-01
    z[3,0,0]  R685      1.3997834920883179e-01
    z[3,0,0]  R686      -6.3276566565036774e-02
    z[3,0,0]  R687      0.837135374546051
    z[3,0,0]  R688      9.2894226312637329e-01
    z[3,0,0]  R689      -6.2266051769256592e-01
    z[3,0,0]  R690      7.6999038457870483e-01
    z[3,0,0]  R691      -4.2529711127281189e-01
    z[3,0,0]  R692      -5.8424901962280273e-01
    z[3,0,0]  R693      5.6201267242431641e-01
    z[3,0,0]  R694      -1.1042773723602295e-01
    z[3,0,0]  R695      2.5928720831871033e-01
    z[3,0,0]  R696      -3.6640220880508423e-01
    z[3,0,0]  R697      5.1088446378707886e-01
    z[3,0,0]  R698      5.1166445016860962e-01
    z[3,0,0]  R699      3.0087643861770630e-01
    z[3,0,0]  R700      -3.6423809826374054e-02
    z[3,0,0]  R701      6.0400050878524780e-01
    z[3,0,0]  R702      5.4995787143707275e-01
    z[3,0,0]  R703      4.2954602837562561e-01
    z[3,0,0]  R704      -4.6089485287666321e-01
    z[3,0,0]  R705      -1.0036650300025940e-01
    z[3,0,0]  R706      1.5186357498168945e-01
    z[3,0,0]  R707      1.5081593394279480e-01
    z[3,0,0]  R708      4.9989837408065796e-01
    z[3,0,0]  R709      2.5372245907783508e-01
    z[3,0,0]  R710      7.4551028013229370e-01
    z[3,0,0]  R711      1.8130171298980713e-01
    z[3,0,0]  R712      -5.2088344097137451e-01
    z[3,0,0]  R713      5.0005221366882324e-01
    z[3,0,0]  R714      0.537525475025177
    z[3,0,0]  R715      -0.516525387763977
    z[3,0,0]  R716      -2.1711751818656921e-01
    z[3,0,0]  R717      -6.7841041088104248e-01
    z[3,0,0]  R718      6.5063852071762085e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R568      -1
    z[3,0,1]  R569      1
    z[3,0,1]  R580      -4.9979650974273682e-01
    z[3,0,1]  R581      -3.7981674075126648e-01
    z[3,0,1]  R582      -2.0791263878345490e-01
    z[3,0,1]  R583      3.7678810954093933e-01
    z[3,0,1]  R584      -4.3685835599899292e-01
    z[3,0,1]  R585      7.3186588287353516e-01
    z[3,0,1]  R586      5.6335467100143433e-01
    z[3,0,1]  R587      -5.8704257011413574e-01
    z[3,0,1]  R588      2.5529748201370239e-01
    z[3,0,1]  R589      -3.0720129609107971e-01
    z[3,0,1]  R590      -4.9055501818656921e-01
    z[3,0,1]  R591      -8.5490924119949341e-01
    z[3,0,1]  R592      -7.7586907148361206e-01
    z[3,0,1]  R593      -7.6240330934524536e-01
    z[3,0,1]  R594      -6.7092359066009521e-01
    z[3,0,1]  R595      -0.72418612241745
    z[3,0,1]  R596      -6.1174947023391724e-01
    z[3,0,1]  R597      -6.1788523197174072e-01
    z[3,0,1]  R598      -9.1981792449951172e-01
    z[3,0,1]  R599      -5.2808022499084473e-01
    z[3,0,1]  R600      5.4192101955413818e-01
    z[3,0,1]  R601      -8.2055938243865967e-01
    z[3,0,1]  R602      4.7175922989845276e-01
    z[3,0,1]  R603      1.1841738224029541e-01
    z[3,0,1]  R604      2.9551774263381958e-01
    z[3,0,1]  R605      0.809660017490387
    z[3,0,1]  R606      -2.1381278336048126e-01
    z[3,0,1]  R607      -1.8627347052097321e-01
    z[3,0,1]  R608      0.00829958077520132
    z[3,0,1]  R609      -3.7942326068878174e-01
    z[3,0,1]  R610      -4.5845040678977966e-01
    z[3,0,1]  R611      2.7378877997398376e-01
    z[3,0,1]  R612      -2.6002889871597290e-01
    z[3,0,1]  R613      -3.5557288210839033e-03
    z[3,0,1]  R614      -2.9835966229438782e-01
    z[3,0,1]  R615      -3.6772534251213074e-01
    z[3,0,1]  R616      -4.3924498558044434e-01
    z[3,0,1]  R617      -2.4902668595314026e-01
    z[3,0,1]  R618      1.4090338349342346e-01
    z[3,0,1]  R619      3.8887679576873779e-01
    z[3,0,1]  R620      -7.4931782484054565e-01
    z[3,0,1]  R621      -0.632306694984436
    z[3,0,1]  R622      -7.8275579214096069e-01
    z[3,0,1]  R623      -6.6907012462615967e-01
    z[3,0,1]  R624      -2.8633108735084534e-01
    z[3,0,1]  R625      -0.757557213306427
    z[3,0,1]  R626      -3.0009558796882629e-01
    z[3,0,1]  R627      3.3315002918243408e-01
    z[3,0,1]  R628      8.9879298210144043e-01
    z[3,0,1]  R629      8.9376252889633179e-01
    z[3,0,1]  R630      3.6833387613296509e-01
    z[3,0,1]  R631      7.9607349634170532e-01
    z[3,0,1]  R632      -4.1194394230842590e-01
    z[3,0,1]  R633      -3.9958181977272034e-01
    z[3,0,1]  R634      4.9775320291519165e-01
    z[3,0,1]  R635      7.2175461053848267e-01
    z[3,0,1]  R636      -6.2557137012481689e-01
    z[3,0,1]  R637      -4.7308912873268127e-01
    z[3,0,1]  R638      -6.1057257652282715e-01
    z[3,0,1]  R639      -8.6844104528427124e-01
    z[3,0,1]  R640      -3.7819364666938782e-01
    z[3,0,1]  R641      7.8421306610107422e-01
    z[3,0,1]  R642      -4.6251523494720459e-01
    z[3,0,1]  R643      -6.7398720979690552e-01
    z[3,0,1]  R644      -0.629465639591217
    z[3,0,1]  R645      7.1435183286666870e-01
    z[3,0,1]  R646      7.6606941223144531e-01
    z[3,0,1]  R647      -0.630012571811676
    z[3,0,1]  R648      3.3499780297279358e-01
    z[3,0,1]  R649      8.1709533929824829e-01
    z[3,0,1]  R650      7.3661535978317261e-01
    z[3,0,1]  R651      7.3152804374694824e-01
    z[3,0,1]  R652      -3.0366113781929016e-01
    z[3,0,1]  R653      5.0897938013076782e-01
    z[3,0,1]  R654      6.3099247217178345e-01
    z[3,0,1]  R655      3.2106861472129822e-01
    z[3,0,1]  R656      -1.1713733896613121e-02
    z[3,0,1]  R657      0.736412763595581
    z[3,0,1]  R658      7.4944078922271729e-02
    z[3,0,1]  R659      8.3493673801422119e-01
    z[3,0,1]  R660      6.7021858692169189e-01
    z[3,0,1]  R661      1.0754422843456268e-01
    z[3,0,1]  R662      6.6958451271057129e-01
    z[3,0,1]  R663      7.9599660634994507e-01
    z[3,0,1]  R664      -2.4713924527168274e-01
    z[3,0,1]  R665      -0.864155650138855
    z[3,0,1]  R666      3.7200577557086945e-02
    z[3,0,1]  R667      0.793024480342865
    z[3,0,1]  R668      -5.6740152835845947e-01
    z[3,0,1]  R669      3.6730918288230896e-01
    z[3,0,1]  R670      8.8114857673645020e-01
    z[3,0,1]  R671      -7.8086805343627930e-01
    z[3,0,1]  R672      7.9446837306022644e-02
    z[3,0,1]  R673      -2.2397871315479279e-01
    z[3,0,1]  R674      -1.8734152615070343e-01
    z[3,0,1]  R675      -7.8264009952545166e-01
    z[3,0,1]  R676      -3.5057049989700317e-01
    z[3,0,1]  R677      -7.8658795356750488e-01
    z[3,0,1]  R678      -8.6471116542816162e-01
    z[3,0,1]  R679      3.4992757439613342e-01
    z[3,0,1]  R680      -6.2392234802246094e-01
    z[3,0,1]  R681      1.8919041380286217e-02
    z[3,0,1]  R682      -2.0074361562728882e-01
    z[3,0,1]  R683      3.8524657487869263e-02
    z[3,0,1]  R684      -3.3165480941534042e-02
    z[3,0,1]  R685      7.1194154024124146e-01
    z[3,0,1]  R686      -9.2100965976715088e-01
    z[3,0,1]  R687      -3.2712038606405258e-02
    z[3,0,1]  R688      2.0799531042575836e-01
    z[3,0,1]  R689      -1.7363831400871277e-01
    z[3,0,1]  R690      2.6390469074249268e-01
    z[3,0,1]  R691      -8.0534279346466064e-01
    z[3,0,1]  R692      -3.3154079318046570e-01
    z[3,0,1]  R693      3.5923457145690918e-01
    z[3,0,1]  R694      -0.895881712436676
    z[3,0,1]  R695      6.7885470390319824e-01
    z[3,0,1]  R696      -7.6817399263381958e-01
    z[3,0,1]  R697      -6.4891618490219116e-01
    z[3,0,1]  R698      -0.37047278881073
    z[3,0,1]  R699      9.1027367115020752e-01
    z[3,0,1]  R700      -2.2061090171337128e-01
    z[3,0,1]  R701      6.1865431070327759e-01
    z[3,0,1]  R702      6.5419411659240723e-01
    z[3,0,1]  R703      0.648796021938324
    z[3,0,1]  R704      -1.0930936038494110e-01
    z[3,0,1]  R705      -6.4319121837615967e-01
    z[3,0,1]  R706      7.4658292531967163e-01
    z[3,0,1]  R707      -1.6936777532100677e-01
    z[3,0,1]  R708      5.3226995468139648e-01
    z[3,0,1]  R709      8.5525131225585938e-01
    z[3,0,1]  R710      1.5650014579296112e-01
    z[3,0,1]  R711      2.2968946397304535e-01
    z[3,0,1]  R712      -8.4850661456584930e-02
    z[3,0,1]  R713      -3.3790320158004761e-02
    z[3,0,1]  R714      -2.8482902050018311e-01
    z[3,0,1]  R715      1.9975388050079346e-01
    z[3,0,1]  R716      -6.9128429889678955e-01
    z[3,0,1]  R717      -1.3931839168071747e-01
    z[3,0,1]  R718      -3.0566978454589844e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R570      -1
    z[3,0,2]  R571      1
    z[3,0,2]  R580      -3.4730517864227295e-01
    z[3,0,2]  R581      -1.4648345112800598e-01
    z[3,0,2]  R582      -4.0350863337516785e-01
    z[3,0,2]  R583      7.0236515998840332e-01
    z[3,0,2]  R584      -1.2193604372441769e-02
    z[3,0,2]  R585      5.3562176227569580e-01
    z[3,0,2]  R586      1.8169675767421722e-01
    z[3,0,2]  R587      -3.1884562224149704e-02
    z[3,0,2]  R588      5.2796679735183716e-01
    z[3,0,2]  R589      5.4261833429336548e-01
    z[3,0,2]  R590      -7.4606072902679443e-01
    z[3,0,2]  R591      1.7190891504287720e-01
    z[3,0,2]  R592      -3.0966898798942566e-01
    z[3,0,2]  R593      2.1271331608295441e-01
    z[3,0,2]  R594      2.2867359220981598e-02
    z[3,0,2]  R595      -1.0302006453275681e-01
    z[3,0,2]  R596      -1.3841852545738220e-01
    z[3,0,2]  R597      6.8635516799986362e-03
    z[3,0,2]  R598      1.3173352181911469e-01
    z[3,0,2]  R599      -1.1156410723924637e-01
    z[3,0,2]  R600      3.9218932390213013e-01
    z[3,0,2]  R601      -1.8157172203063965e-01
    z[3,0,2]  R602      3.2757565379142761e-01
    z[3,0,2]  R603      1.9680313766002655e-01
    z[3,0,2]  R604      4.5352223515510559e-01
    z[3,0,2]  R605      2.9588249325752258e-01
    z[3,0,2]  R606      -5.0353008508682251e-01
    z[3,0,2]  R607      3.9402994513511658e-01
    z[3,0,2]  R608      3.4777870774269104e-01
    z[3,0,2]  R609      3.1732836365699768e-01
    z[3,0,2]  R610      -5.5367767810821533e-01
    z[3,0,2]  R611      5.6241697072982788e-01
    z[3,0,2]  R612      -5.9100198745727539e-01
    z[3,0,2]  R613      3.3056426048278809e-01
    z[3,0,2]  R614      -2.4744980037212372e-01
    z[3,0,2]  R615      2.2165837883949280e-01
    z[3,0,2]  R616      1.9918750226497650e-01
    z[3,0,2]  R617      0.0682726576924324
    z[3,0,2]  R618      -1.8451346457004547e-01
    z[3,0,2]  R619      -1.3119451701641083e-01
    z[3,0,2]  R620      1.2991547584533691e-02
    z[3,0,2]  R621      -3.0424109101295471e-01
    z[3,0,2]  R622      1.2071663886308670e-01
    z[3,0,2]  R623      -3.4740817500278354e-04
    z[3,0,2]  R624      3.3287355303764343e-01
    z[3,0,2]  R625      1.1665407568216324e-01
    z[3,0,2]  R626      4.0914547443389893e-01
    z[3,0,2]  R627      -3.4522455930709839e-01
    z[3,0,2]  R628      -5.6712850928306580e-02
    z[3,0,2]  R629      -1.4610143005847931e-01
    z[3,0,2]  R630      7.5606632232666016e-01
    z[3,0,2]  R631      -1.2401672452688217e-01
    z[3,0,2]  R632      -3.7869594991207123e-02
    z[3,0,2]  R633      -0.0090639628469944
    z[3,0,2]  R634      2.5722339749336243e-01
    z[3,0,2]  R635      4.9583235383033752e-01
    z[3,0,2]  R636      -1.4853253960609436e-01
    z[3,0,2]  R637      -6.4209826290607452e-02
    z[3,0,2]  R638      -1.8338464200496674e-02
    z[3,0,2]  R639      -9.8827652633190155e-02
    z[3,0,2]  R640      -4.4583427906036377e-01
    z[3,0,2]  R641      -2.6195909827947617e-02
    z[3,0,2]  R642      -3.5094434022903442e-01
    z[3,0,2]  R643      -3.7738955020904541e-01
    z[3,0,2]  R644      -1.5090338885784149e-01
    z[3,0,2]  R645      1.1762766540050507e-01
    z[3,0,2]  R646      -1.6124796122312546e-02
    z[3,0,2]  R647      -1.8149559199810028e-01
    z[3,0,2]  R648      2.9928576946258545e-01
    z[3,0,2]  R649      -1.2259004870429635e-03
    z[3,0,2]  R650      3.9859589934349060e-01
    z[3,0,2]  R651      4.5946672558784485e-01
    z[3,0,2]  R652      -2.7820277214050293e-01
    z[3,0,2]  R653      4.1098093986511230e-01
    z[3,0,2]  R654      -5.0525808334350586e-01
    z[3,0,2]  R655      5.1737630367279053e-01
    z[3,0,2]  R656      1.2611895799636841e-01
    z[3,0,2]  R657      -6.1552878469228745e-02
    z[3,0,2]  R658      4.1487866640090942e-01
    z[3,0,2]  R659      -1.4426006376743317e-01
    z[3,0,2]  R660      2.4643549323081970e-01
    z[3,0,2]  R661      4.1255244612693787e-01
    z[3,0,2]  R662      -5.7148575782775879e-01
    z[3,0,2]  R663      -4.5504567027091980e-01
    z[3,0,2]  R664      1.2018267810344696e-01
    z[3,0,2]  R665      1.8982850015163422e-02
    z[3,0,2]  R666      4.3548887968063354e-01
    z[3,0,2]  R667      -5.8144873380661011e-01
    z[3,0,2]  R668      -1.5069223940372467e-01
    z[3,0,2]  R669      5.2009713649749756e-01
    z[3,0,2]  R670      -1.9687506556510925e-01
    z[3,0,2]  R671      0.0201080534607172
    z[3,0,2]  R672      5.2347022294998169e-01
    z[3,0,2]  R673      -1.1046304553747177e-01
    z[3,0,2]  R674      -6.4911562204360962e-01
    z[3,0,2]  R675      -4.1073363274335861e-02
    z[3,0,2]  R676      -1.6348633170127869e-01
    z[3,0,2]  R677      -1.5209870040416718e-01
    z[3,0,2]  R678      -1.8222853541374207e-01
    z[3,0,2]  R679      5.5721467733383179e-01
    z[3,0,2]  R680      -1.1913654953241348e-01
    z[3,0,2]  R681      4.4215241074562073e-01
    z[3,0,2]  R682      2.7167335152626038e-01
    z[3,0,2]  R683      -3.1831446290016174e-01
    z[3,0,2]  R684      -2.2658412158489227e-01
    z[3,0,2]  R685      -1.0902421921491623e-01
    z[3,0,2]  R686      -1.0851480066776276e-01
    z[3,0,2]  R687      1.1226566135883331e-01
    z[3,0,2]  R688      -5.3804680705070496e-02
    z[3,0,2]  R689      -4.2838653922080994e-01
    z[3,0,2]  R690      5.1253533363342285e-01
    z[3,0,2]  R691      -2.6043480634689331e-01
    z[3,0,2]  R692      -4.9675479531288147e-01
    z[3,0,2]  R693      6.2754553556442261e-01
    z[3,0,2]  R694      -1.7652894556522369e-01
    z[3,0,2]  R695      1.6643513739109039e-01
    z[3,0,2]  R696      -2.4202552437782288e-01
    z[3,0,2]  R697      2.7322193980216980e-01
    z[3,0,2]  R698      4.3216076493263245e-01
    z[3,0,2]  R699      4.0930751711130142e-02
    z[3,0,2]  R700      -3.2603389024734497e-01
    z[3,0,2]  R701      2.0815475285053253e-01
    z[3,0,2]  R702      -1.8299816176295280e-02
    z[3,0,2]  R703      1.6122369468212128e-01
    z[3,0,2]  R704      -3.9493107795715332e-01
    z[3,0,2]  R705      -1.2309246696531773e-02
    z[3,0,2]  R706      -7.8025050461292267e-02
    z[3,0,2]  R707      2.3661802709102631e-01
    z[3,0,2]  R708      -0.338933527469635
    z[3,0,2]  R709      -4.0052774548530579e-01
    z[3,0,2]  R710      5.3929162025451660e-01
    z[3,0,2]  R711      -2.8605839610099792e-01
    z[3,0,2]  R712      -7.1341377496719360e-01
    z[3,0,2]  R713      6.6442453861236572e-01
    z[3,0,2]  R714      5.2587682008743286e-01
    z[3,0,2]  R715      -2.2238335013389587e-01
    z[3,0,2]  R716      -2.7310755848884583e-01
    z[3,0,2]  R717      -2.7657121419906616e-01
    z[3,0,2]  R718      -1.7558740451931953e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R572      -1
    z[3,0,3]  R573      1
    z[3,0,3]  R580      -4.2700907588005066e-01
    z[3,0,3]  R581      -1.3089103996753693e-01
    z[3,0,3]  R582      5.0435356795787811e-02
    z[3,0,3]  R583      -1.8006978556513786e-02
    z[3,0,3]  R584      -5.4041433334350586e-01
    z[3,0,3]  R585      -1.6749298572540283e-01
    z[3,0,3]  R586      2.4034446477890015e-01
    z[3,0,3]  R587      0.312175452709198
    z[3,0,3]  R588      -1.5765495598316193e-01
    z[3,0,3]  R589      -4.5238324999809265e-01
    z[3,0,3]  R590      6.0132112354040146e-02
    z[3,0,3]  R591      -3.5726919770240784e-01
    z[3,0,3]  R592      1.7948009073734283e-01
    z[3,0,3]  R593      1.7335766926407814e-02
    z[3,0,3]  R594      0.554954469203949
    z[3,0,3]  R595      4.6995395421981812e-01
    z[3,0,3]  R596      6.5578943490982056e-01
    z[3,0,3]  R597      5.3399151563644409e-01
    z[3,0,3]  R598      1.7057047784328461e-01
    z[3,0,3]  R599      0.805041491985321
    z[3,0,3]  R600      1.4910751581192017e-01
    z[3,0,3]  R601      3.3688324689865112e-01
    z[3,0,3]  R602      1.6703270375728607e-01
    z[3,0,3]  R603      -1.6435244679450989e-01
    z[3,0,3]  R604      -2.5326707959175110e-01
    z[3,0,3]  R605      1.2513893842697144e-01
    z[3,0,3]  R606      -2.2047157585620880e-01
    z[3,0,3]  R607      -3.8990822434425354e-01
    z[3,0,3]  R608      -2.3397500813007355e-01
    z[3,0,3]  R609      4.9153860658407211e-02
    z[3,0,3]  R610      -9.9736951291561127e-02
    z[3,0,3]  R611      1.5958513319492340e-01
    z[3,0,3]  R612      -1.8974952399730682e-02
    z[3,0,3]  R613      -8.5029698908329010e-02
    z[3,0,3]  R614      -7.3701471090316772e-01
    z[3,0,3]  R615      -5.1005744934082031e-01
    z[3,0,3]  R616      -3.5362154245376587e-01
    z[3,0,3]  R617      -3.0872595310211182e-01
    z[3,0,3]  R618      9.6516653895378113e-02
    z[3,0,3]  R619      0.767477810382843
    z[3,0,3]  R620      -5.9185636043548584e-01
    z[3,0,3]  R621      -1.9000720977783203e-01
    z[3,0,3]  R622      3.6175560951232910e-01
    z[3,0,3]  R623      3.6101114749908447e-01
    z[3,0,3]  R624      -1.9300375878810883e-01
    z[3,0,3]  R625      2.0218791067600250e-01
    z[3,0,3]  R626      2.9652403667569160e-02
    z[3,0,3]  R627      7.5273603200912476e-01
    z[3,0,3]  R628      1.7682921886444092e-01
    z[3,0,3]  R629      -1.7934386432170868e-01
    z[3,0,3]  R630      0.00919360015541315
    z[3,0,3]  R631      2.7194846421480179e-02
    z[3,0,3]  R632      -3.4394222497940063e-01
    z[3,0,3]  R633      -2.9011097550392151e-01
    z[3,0,3]  R634      2.4903476238250732e-01
    z[3,0,3]  R635      -2.2532276809215546e-01
    z[3,0,3]  R636      -3.8715666532516479e-01
    z[3,0,3]  R637      -2.5482279062271118e-01
    z[3,0,3]  R638      -5.9454911947250366e-01
    z[3,0,3]  R639      3.3574298024177551e-01
    z[3,0,3]  R640      -2.1461232006549835e-01
    z[3,0,3]  R641      -1.5855069458484650e-01
    z[3,0,3]  R642      -4.1359403729438782e-01
    z[3,0,3]  R643      -1.9654460251331329e-01
    z[3,0,3]  R644      6.0009920597076416e-01
    z[3,0,3]  R645      3.2986736297607422e-01
    z[3,0,3]  R646      -1.6660936176776886e-01
    z[3,0,3]  R647      2.6079794764518738e-01
    z[3,0,3]  R648      1.9063760340213776e-01
    z[3,0,3]  R649      -1.6288323700428009e-01
    z[3,0,3]  R650      -0.350488543510437
    z[3,0,3]  R651      5.7509769685566425e-03
    z[3,0,3]  R652      -6.6776730120182037e-02
    z[3,0,3]  R653      3.5175219178199768e-01
    z[3,0,3]  R654      -9.1895036399364471e-02
    z[3,0,3]  R655      -1.6132335364818573e-01
    z[3,0,3]  R656      -3.7675538659095764e-01
    z[3,0,3]  R657      5.1050532609224319e-02
    z[3,0,3]  R658      -3.3609023690223694e-01
    z[3,0,3]  R659      9.2560619115829468e-02
    z[3,0,3]  R660      4.1062968969345093e-01
    z[3,0,3]  R661      -4.9150732159614563e-01
    z[3,0,3]  R662      3.0427560210227966e-01
    z[3,0,3]  R663      -3.7423957139253616e-02
    z[3,0,3]  R664      7.6432478427886963e-01
    z[3,0,3]  R665      0.371351420879364
    z[3,0,3]  R666      -0.270082950592041
    z[3,0,3]  R667      -5.0245355814695358e-02
    z[3,0,3]  R668      -3.0831021070480347e-01
    z[3,0,3]  R669      -2.0431217551231384e-01
    z[3,0,3]  R670      -1.0609222948551178e-01
    z[3,0,3]  R671      0.522624135017395
    z[3,0,3]  R672      -2.4257950484752655e-01
    z[3,0,3]  R673      8.3517897129058838e-01
    z[3,0,3]  R674      -2.3713992536067963e-01
    z[3,0,3]  R675      1.7736728489398956e-01
    z[3,0,3]  R676      4.9250704050064087e-01
    z[3,0,3]  R677      3.4422501921653748e-02
    z[3,0,3]  R678      -2.3740322887897491e-01
    z[3,0,3]  R679      -1.6251015663146973e-01
    z[3,0,3]  R680      0.574330747127533
    z[3,0,3]  R681      2.0639950037002563e-01
    z[3,0,3]  R682      5.0674965605139732e-03
    z[3,0,3]  R683      -1.4749768376350403e-01
    z[3,0,3]  R684      -1.6726320981979370e-01
    z[3,0,3]  R685      -2.8104493021965027e-01
    z[3,0,3]  R686      -0.0925268605351448
    z[3,0,3]  R687      1.2001358903944492e-02
    z[3,0,3]  R688      -4.5203246176242828e-02
    z[3,0,3]  R689      -3.4919625520706177e-01
    z[3,0,3]  R690      -1.7929084599018097e-02
    z[3,0,3]  R691      2.7303194999694824e-01
    z[3,0,3]  R692      -3.5218429565429688e-01
    z[3,0,3]  R693      3.2124549150466919e-02
    z[3,0,3]  R694      -1.8332313047721982e-03
    z[3,0,3]  R695      -4.7861579060554504e-01
    z[3,0,3]  R696      -2.9377844929695129e-01
    z[3,0,3]  R697      -3.6752650141716003e-01
    z[3,0,3]  R698      -4.6634238958358765e-01
    z[3,0,3]  R699      -7.7418766915798187e-02
    z[3,0,3]  R700      8.1320095062255859e-01
    z[3,0,3]  R701      -3.8583735004067421e-03
    z[3,0,3]  R702      3.5540437698364258e-01
    z[3,0,3]  R703      3.0389702320098877e-01
    z[3,0,3]  R704      -0.0907410979270935
    z[3,0,3]  R705      6.5078479051589966e-01
    z[3,0,3]  R706      2.4905851483345032e-01
    z[3,0,3]  R707      6.0266852378845215e-01
    z[3,0,3]  R708      0.380577027797699
    z[3,0,3]  R709      -1.5043872594833374e-01
    z[3,0,3]  R710      -2.0054295659065247e-01
    z[3,0,3]  R711      5.1038622856140137e-01
    z[3,0,3]  R712      -3.4189623594284058e-01
    z[3,0,3]  R713      2.6827251911163330e-01
    z[3,0,3]  R714      -1.0436327010393143e-01
    z[3,0,3]  R715      3.3484068512916565e-01
    z[3,0,3]  R716      -2.3631818592548370e-01
    z[3,0,3]  R717      3.1567353010177612e-01
    z[3,0,3]  R718      -3.0971601605415344e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R574      -1
    z[3,0,4]  R575      1
    z[3,0,4]  R580      4.5822650194168091e-02
    z[3,0,4]  R581      -7.5653657317161560e-02
    z[3,0,4]  R582      -2.1640536189079285e-01
    z[3,0,4]  R583      3.8729336112737656e-02
    z[3,0,4]  R584      1.9678421318531036e-02
    z[3,0,4]  R585      -5.0368376076221466e-02
    z[3,0,4]  R586      2.0661942660808563e-01
    z[3,0,4]  R587      -6.1629676818847656e-01
    z[3,0,4]  R588      -1.2086541950702667e-01
    z[3,0,4]  R589      -9.5076836645603180e-02
    z[3,0,4]  R590      2.3639410734176636e-01
    z[3,0,4]  R591      -2.0589524507522583e-01
    z[3,0,4]  R592      7.2629086673259735e-02
    z[3,0,4]  R593      -0.0833207443356514
    z[3,0,4]  R594      -1.6864295303821564e-01
    z[3,0,4]  R595      2.0364646613597870e-01
    z[3,0,4]  R596      -1.3364824652671814e-01
    z[3,0,4]  R597      -4.5083454251289368e-01
    z[3,0,4]  R598      4.9073547124862671e-02
    z[3,0,4]  R599      -5.7916458696126938e-02
    z[3,0,4]  R600      -1.6701254248619080e-01
    z[3,0,4]  R601      -2.2128391265869141e-01
    z[3,0,4]  R602      2.5124964118003845e-01
    z[3,0,4]  R603      3.5647621750831604e-01
    z[3,0,4]  R604      -0.0849151685833931
    z[3,0,4]  R605      1.7805512249469757e-01
    z[3,0,4]  R606      5.1432031393051147e-01
    z[3,0,4]  R607      1.7972512543201447e-01
    z[3,0,4]  R608      -2.0716971158981323e-01
    z[3,0,4]  R609      1.2676016986370087e-01
    z[3,0,4]  R610      -1.0556812584400177e-01
    z[3,0,4]  R611      -9.2531302943825722e-03
    z[3,0,4]  R612      2.2112432122230530e-01
    z[3,0,4]  R613      4.4771939516067505e-01
    z[3,0,4]  R614      2.1878848969936371e-01
    z[3,0,4]  R615      -7.0104807615280151e-02
    z[3,0,4]  R616      2.0469594001770020e-01
    z[3,0,4]  R617      0.0848376527428627
    z[3,0,4]  R618      1.6652733087539673e-01
    z[3,0,4]  R619      1.6612590849399567e-01
    z[3,0,4]  R620      1.8307650089263916e-01
    z[3,0,4]  R621      -2.4783807992935181e-01
    z[3,0,4]  R622      -1.2648294866085052e-01
    z[3,0,4]  R623      -3.7038561701774597e-01
    z[3,0,4]  R624      2.1535834670066833e-01
    z[3,0,4]  R625      -3.8356855511665344e-01
    z[3,0,4]  R626      2.7675956487655640e-01
    z[3,0,4]  R627      7.4886791408061981e-03
    z[3,0,4]  R628      -1.6296248137950897e-01
    z[3,0,4]  R629      -3.6126505583524704e-02
    z[3,0,4]  R630      1.2621775269508362e-01
    z[3,0,4]  R631      4.3071404099464417e-01
    z[3,0,4]  R632      3.2724443823099136e-02
    z[3,0,4]  R633      0.257503867149353
    z[3,0,4]  R634      3.4328451752662659e-01
    z[3,0,4]  R635      6.9391697645187378e-02
    z[3,0,4]  R636      3.7020224332809448e-01
    z[3,0,4]  R637      -3.1938779354095459e-01
    z[3,0,4]  R638      1.0658331215381622e-01
    z[3,0,4]  R639      7.4869275093078613e-02
    z[3,0,4]  R640      -1.6004875302314758e-01
    z[3,0,4]  R641      -2.3936209082603455e-01
    z[3,0,4]  R642      -0.0923909991979599
    z[3,0,4]  R643      -1.3523493707180023e-01
    z[3,0,4]  R644      -4.2124426364898682e-01
    z[3,0,4]  R645      -4.9312117695808411e-01
    z[3,0,4]  R646      -5.5431240797042847e-01
    z[3,0,4]  R647      -4.9785044789314270e-01
    z[3,0,4]  R648      3.2990675419569016e-02
    z[3,0,4]  R649      1.6835348308086395e-01
    z[3,0,4]  R650      8.0416696146130562e-03
    z[3,0,4]  R651      -1.0430266708135605e-01
    z[3,0,4]  R652      4.0577873587608337e-01
    z[3,0,4]  R653      -1.4028076827526093e-01
    z[3,0,4]  R654      3.4348881244659424e-01
    z[3,0,4]  R655      2.8809541463851929e-01
    z[3,0,4]  R656      1.9812004640698433e-02
    z[3,0,4]  R657      -2.5096428394317627e-01
    z[3,0,4]  R658      3.6399370431900024e-01
    z[3,0,4]  R659      2.0979216694831848e-01
    z[3,0,4]  R660      2.0947840809822083e-01
    z[3,0,4]  R661      1.3595707714557648e-01
    z[3,0,4]  R662      -1.9441372156143188e-01
    z[3,0,4]  R663      -7.6700314879417419e-02
    z[3,0,4]  R664      -5.0680446624755859e-01
    z[3,0,4]  R665      1.0740419477224350e-01
    z[3,0,4]  R666      -3.5317346453666687e-01
    z[3,0,4]  R667      -9.2873267829418182e-02
    z[3,0,4]  R668      4.1667231917381287e-01
    z[3,0,4]  R669      2.7484133839607239e-01
    z[3,0,4]  R670      -4.5726341195404530e-03
    z[3,0,4]  R671      5.4045025259256363e-02
    z[3,0,4]  R672      -1.1667429655790329e-01
    z[3,0,4]  R673      -4.5199674367904663e-01
    z[3,0,4]  R674      3.3902961015701294e-01
    z[3,0,4]  R675      -4.1172477602958679e-01
    z[3,0,4]  R676      7.5132292509078979e-01
    z[3,0,4]  R677      -3.4670770168304443e-01
    z[3,0,4]  R678      -2.2079072892665863e-01
    z[3,0,4]  R679      -1.1875396221876144e-01
    z[3,0,4]  R680      -3.1644481420516968e-01
    z[3,0,4]  R681      3.1604072451591492e-01
    z[3,0,4]  R682      4.8546192049980164e-01
    z[3,0,4]  R683      -0.128139927983284
    z[3,0,4]  R684      -0.0866321325302124
    z[3,0,4]  R685      2.3385412991046906e-01
    z[3,0,4]  R686      5.7850323617458344e-02
    z[3,0,4]  R687      0.257344514131546
    z[3,0,4]  R688      2.4556914344429970e-02
    z[3,0,4]  R689      -1.6494618356227875e-01
    z[3,0,4]  R690      -1.3364669680595398e-01
    z[3,0,4]  R691      -1.1719775199890137e-01
    z[3,0,4]  R692      2.2424438595771790e-01
    z[3,0,4]  R693      -0.00995875895023346
    z[3,0,4]  R694      -3.8880905508995056e-01
    z[3,0,4]  R695      4.3893387913703918e-01
    z[3,0,4]  R696      2.5893932580947876e-01
    z[3,0,4]  R697      2.4864292144775391e-01
    z[3,0,4]  R698      -5.9497680515050888e-02
    z[3,0,4]  R699      1.3169558346271515e-01
    z[3,0,4]  R700      -3.2660955190658569e-01
    z[3,0,4]  R701      2.6325416564941406e-01
    z[3,0,4]  R702      -1.8018412590026855e-01
    z[3,0,4]  R703      2.0091657340526581e-01
    z[3,0,4]  R704      3.4084555506706238e-01
    z[3,0,4]  R705      -7.8271649777889252e-02
    z[3,0,4]  R706      -2.3090025782585144e-01
    z[3,0,4]  R707      5.3224277496337891e-01
    z[3,0,4]  R708      2.5602266192436218e-01
    z[3,0,4]  R709      -3.1911402940750122e-02
    z[3,0,4]  R710      -3.4819513559341431e-02
    z[3,0,4]  R711      -6.8201929330825806e-01
    z[3,0,4]  R712      2.4720046669244766e-02
    z[3,0,4]  R713      0.348127543926239
    z[3,0,4]  R714      1.2218102067708969e-01
    z[3,0,4]  R715      4.8597112298011780e-01
    z[3,0,4]  R716      -3.2860539853572845e-02
    z[3,0,4]  R717      5.6821429729461670e-01
    z[3,0,4]  R718      5.9923237562179565e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R576      -1
    z[3,0,5]  R577      1
    z[3,0,5]  R580      -2.8510031104087830e-01
    z[3,0,5]  R581      -2.7459102869033813e-01
    z[3,0,5]  R582      -1.7809697985649109e-01
    z[3,0,5]  R583      -9.8730325698852539e-02
    z[3,0,5]  R584      -3.5191348195075989e-01
    z[3,0,5]  R585      9.1518782079219818e-02
    z[3,0,5]  R586      2.5892412662506104e-01
    z[3,0,5]  R587      2.5200262665748596e-01
    z[3,0,5]  R588      1.6486391425132751e-01
    z[3,0,5]  R589      3.9414229989051819e-01
    z[3,0,5]  R590      3.0530977994203568e-02
    z[3,0,5]  R591      2.5256010890007019e-01
    z[3,0,5]  R592      6.9754086434841156e-02
    z[3,0,5]  R593      2.7698242664337158e-01
    z[3,0,5]  R594      -0.438755065202713
    z[3,0,5]  R595      -3.2588756084442139e-01
    z[3,0,5]  R596      -8.9207157492637634e-02
    z[3,0,5]  R597      -2.6879742741584778e-01
    z[3,0,5]  R598      -2.2403210401535034e-01
    z[3,0,5]  R599      -1.5371562540531158e-01
    z[3,0,5]  R600      0.49073326587677
    z[3,0,5]  R601      5.6967481970787048e-02
    z[3,0,5]  R602      7.2781629860401154e-02
    z[3,0,5]  R603      3.0580663681030273e-01
    z[3,0,5]  R604      5.1552492380142212e-01
    z[3,0,5]  R605      -7.9626701772212982e-02
    z[3,0,5]  R606      -1.2868297100067139e-01
    z[3,0,5]  R607      3.3688607811927795e-01
    z[3,0,5]  R608      5.1151913404464722e-01
    z[3,0,5]  R609      3.6664155125617981e-01
    z[3,0,5]  R610      0.366933673620224
    z[3,0,5]  R611      2.4038605391979218e-01
    z[3,0,5]  R612      -2.6346214581280947e-03
    z[3,0,5]  R613      -8.3512723445892334e-02
    z[3,0,5]  R614      3.2308793067932129e-01
    z[3,0,5]  R615      -3.8913673162460327e-01
    z[3,0,5]  R616      -4.0350112318992615e-01
    z[3,0,5]  R617      -6.3718676567077637e-01
    z[3,0,5]  R618      -8.0009198188781738e-01
    z[3,0,5]  R619      -1.8298944830894470e-01
    z[3,0,5]  R620      1.9466073717921972e-04
    z[3,0,5]  R621      4.1467356681823730e-01
    z[3,0,5]  R622      -4.6634575724601746e-01
    z[3,0,5]  R623      -2.3785832524299622e-01
    z[3,0,5]  R624      1.3878895342350006e-01
    z[3,0,5]  R625      -1.7217348515987396e-01
    z[3,0,5]  R626      -7.0632971823215485e-02
    z[3,0,5]  R627      2.8447309136390686e-01
    z[3,0,5]  R628      -0.0577826164662838
    z[3,0,5]  R629      -3.6176130175590515e-02
    z[3,0,5]  R630      -5.0898045301437378e-02
    z[3,0,5]  R631      -2.7517560124397278e-01
    z[3,0,5]  R632      -5.5973863601684570e-01
    z[3,0,5]  R633      -6.2088322639465332e-01
    z[3,0,5]  R634      0.290799081325531
    z[3,0,5]  R635      -3.4118351340293884e-01
    z[3,0,5]  R636      -2.1571926772594452e-01
    z[3,0,5]  R637      -4.1396751999855042e-01
    z[3,0,5]  R638      -5.5196538567543030e-02
    z[3,0,5]  R639      -0.340366005897522
    z[3,0,5]  R640      -3.3916282653808594e-01
    z[3,0,5]  R641      2.5396227836608887e-01
    z[3,0,5]  R642      -2.0888239145278931e-01
    z[3,0,5]  R643      -8.8600821793079376e-02
    z[3,0,5]  R644      0.0864071249961853
    z[3,0,5]  R645      -3.5851109772920609e-02
    z[3,0,5]  R646      1.2585379183292389e-01
    z[3,0,5]  R647      -5.6693799793720245e-02
    z[3,0,5]  R648      4.4701176881790161e-01
    z[3,0,5]  R649      9.5144383609294891e-02
    z[3,0,5]  R650      1.2219092994928360e-01
    z[3,0,5]  R651      -3.6877259612083435e-01
    z[3,0,5]  R652      -6.4557117223739624e-01
    z[3,0,5]  R653      2.4793425202369690e-01
    z[3,0,5]  R654      3.3341971039772034e-01
    z[3,0,5]  R655      0.415558785200119
    z[3,0,5]  R656      1.5356499701738358e-02
    z[3,0,5]  R657      -4.3897899985313416e-01
    z[3,0,5]  R658      5.1259106397628784e-01
    z[3,0,5]  R659      -0.0826454684138298
    z[3,0,5]  R660      -2.8129890561103821e-01
    z[3,0,5]  R661      3.9669489860534668e-01
    z[3,0,5]  R662      1.5606077015399933e-01
    z[3,0,5]  R663      -2.8040561079978943e-01
    z[3,0,5]  R664      1.8205150961875916e-01
    z[3,0,5]  R665      3.0326387286186218e-01
    z[3,0,5]  R666      0.228912353515625
    z[3,0,5]  R667      -2.2774764802306890e-03
    z[3,0,5]  R668      -3.2953587174415588e-01
    z[3,0,5]  R669      3.3728504180908203e-01
    z[3,0,5]  R670      -3.2062929123640060e-02
    z[3,0,5]  R671      -6.0443345457315445e-02
    z[3,0,5]  R672      2.9518043994903564e-01
    z[3,0,5]  R673      5.5045560002326965e-03
    z[3,0,5]  R674      -2.9020276665687561e-01
    z[3,0,5]  R675      -8.4798950701951981e-03
    z[3,0,5]  R676      6.6874980926513672e-02
    z[3,0,5]  R677      3.9979156851768494e-01
    z[3,0,5]  R678      0.0141511932015419
    z[3,0,5]  R679      2.4028590321540833e-01
    z[3,0,5]  R680      1.4296466112136841e-01
    z[3,0,5]  R681      5.2013820409774780e-01
    z[3,0,5]  R682      0.362602174282074
    z[3,0,5]  R683      -7.0562714338302612e-01
    z[3,0,5]  R684      -7.6083153486251831e-01
    z[3,0,5]  R685      -2.5893664360046387e-01
    z[3,0,5]  R686      3.4961634874343872e-01
    z[3,0,5]  R687      9.2065773904323578e-02
    z[3,0,5]  R688      0.290505051612854
    z[3,0,5]  R689      -4.6628376841545105e-01
    z[3,0,5]  R690      1.5312932431697845e-01
    z[3,0,5]  R691      -0.0842769518494606
    z[3,0,5]  R692      -3.5723760724067688e-01
    z[3,0,5]  R693      2.9243400692939758e-01
    z[3,0,5]  R694      5.2723549306392670e-02
    z[3,0,5]  R695      -6.9054342806339264e-02
    z[3,0,5]  R696      2.2902987897396088e-01
    z[3,0,5]  R697      -1.7587022483348846e-01
    z[3,0,5]  R698      -4.3951058387756348e-01
    z[3,0,5]  R699      -2.1963946521282196e-01
    z[3,0,5]  R700      -1.4680349826812744e-01
    z[3,0,5]  R701      3.5559117794036865e-01
    z[3,0,5]  R702      3.3225327730178833e-01
    z[3,0,5]  R703      -2.2312594950199127e-01
    z[3,0,5]  R704      -6.6104239225387573e-01
    z[3,0,5]  R705      -1.3015256822109222e-01
    z[3,0,5]  R706      -4.3054780364036560e-01
    z[3,0,5]  R707      -3.3977288007736206e-01
    z[3,0,5]  R708      2.9494670033454895e-01
    z[3,0,5]  R709      1.3274885714054108e-01
    z[3,0,5]  R710      2.7714800834655762e-01
    z[3,0,5]  R711      3.0091580748558044e-01
    z[3,0,5]  R712      -1.7766192555427551e-01
    z[3,0,5]  R713      2.3864848911762238e-01
    z[3,0,5]  R714      1.3339985907077789e-01
    z[3,0,5]  R715      -4.2681032419204712e-01
    z[3,0,5]  R716      4.8897233605384827e-01
    z[3,0,5]  R717      1.4568093419075012e-01
    z[3,0,5]  R718      -6.9919861853122711e-02
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R578      -1
    z[3,0,6]  R579      1
    z[3,0,6]  R580      1.8634596839547157e-02
    z[3,0,6]  R581      6.1599975824356079e-01
    z[3,0,6]  R582      2.8018739819526672e-01
    z[3,0,6]  R583      3.2007377594709396e-02
    z[3,0,6]  R584      4.5550405979156494e-01
    z[3,0,6]  R585      5.9498608112335205e-02
    z[3,0,6]  R586      9.0559042990207672e-02
    z[3,0,6]  R587      1.9700525701045990e-01
    z[3,0,6]  R588      6.8040627241134644e-01
    z[3,0,6]  R589      4.9363193102180958e-03
    z[3,0,6]  R590      -2.4662408232688904e-01
    z[3,0,6]  R591      -7.3229223489761353e-02
    z[3,0,6]  R592      5.0963556766510010e-01
    z[3,0,6]  R593      5.3769510984420776e-01
    z[3,0,6]  R594      1.2688353657722473e-01
    z[3,0,6]  R595      7.3101505637168884e-02
    z[3,0,6]  R596      9.3675171956419945e-03
    z[3,0,6]  R597      -1.5260463953018188e-01
    z[3,0,6]  R598      -0.163701593875885
    z[3,0,6]  R599      1.6433374583721161e-01
    z[3,0,6]  R600      -2.5771612301468849e-02
    z[3,0,6]  R601      -2.8085660934448242e-01
    z[3,0,6]  R602      2.1825022995471954e-01
    z[3,0,6]  R603      2.3344756662845612e-01
    z[3,0,6]  R604      2.6692020893096924e-01
    z[3,0,6]  R605      -6.2983624637126923e-02
    z[3,0,6]  R606      6.0644489526748657e-01
    z[3,0,6]  R607      0.150406152009964
    z[3,0,6]  R608      1.0031318664550781e-01
    z[3,0,6]  R609      1.2571129016578197e-02
    z[3,0,6]  R610      4.1141849756240845e-01
    z[3,0,6]  R611      3.5320450551807880e-03
    z[3,0,6]  R612      6.8976622819900513e-01
    z[3,0,6]  R613      -1.2096484750509262e-01
    z[3,0,6]  R614      3.9257019758224487e-01
    z[3,0,6]  R615      1.1280041933059692e-01
    z[3,0,6]  R616      4.1892158985137939e-01
    z[3,0,6]  R617      5.0528898835182190e-02
    z[3,0,6]  R618      0.161977618932724
    z[3,0,6]  R619      3.3900722861289978e-01
    z[3,0,6]  R620      2.2306475043296814e-01
    z[3,0,6]  R621      3.1190004944801331e-01
    z[3,0,6]  R622      -7.7244572341442108e-02
    z[3,0,6]  R623      2.8067186474800110e-01
    z[3,0,6]  R624      2.8628465533256531e-01
    z[3,0,6]  R625      2.0274116098880768e-01
    z[3,0,6]  R626      3.5062986612319946e-01
    z[3,0,6]  R627      2.9905807971954346e-01
    z[3,0,6]  R628      1.8012440204620361e-01
    z[3,0,6]  R629      -1.4839315414428711e-01
    z[3,0,6]  R630      3.1428948044776917e-02
    z[3,0,6]  R631      -1.2347525358200073e-01
    z[3,0,6]  R632      2.1435044705867767e-01
    z[3,0,6]  R633      6.4815111458301544e-02
    z[3,0,6]  R634      7.9461887478828430e-02
    z[3,0,6]  R635      -5.0881922245025635e-02
    z[3,0,6]  R636      -1.4722093008458614e-02
    z[3,0,6]  R637      2.7972161769866943e-01
    z[3,0,6]  R638      -1.4217411167919636e-02
    z[3,0,6]  R639      -3.7718974053859711e-02
    z[3,0,6]  R640      -2.4991898238658905e-01
    z[3,0,6]  R641      3.0058425664901733e-01
    z[3,0,6]  R642      3.0824345350265503e-01
    z[3,0,6]  R643      8.1671245396137238e-02
    z[3,0,6]  R644      1.1477380245923996e-01
    z[3,0,6]  R645      1.0683772154152393e-02
    z[3,0,6]  R646      -1.5544918179512024e-01
    z[3,0,6]  R647      4.9034300446510315e-01
    z[3,0,6]  R648      -1.8377602100372314e-01
    z[3,0,6]  R649      -0.37274369597435
    z[3,0,6]  R650      1.5977036207914352e-02
    z[3,0,6]  R651      1.6093797981739044e-01
    z[3,0,6]  R652      4.3478954583406448e-02
    z[3,0,6]  R653      -1.6550987958908081e-01
    z[3,0,6]  R654      -7.1623444557189941e-02
    z[3,0,6]  R655      -2.7719438076019287e-01
    z[3,0,6]  R656      -1.8942917883396149e-01
    z[3,0,6]  R657      0.43539959192276
    z[3,0,6]  R658      2.8288811445236206e-01
    z[3,0,6]  R659      -3.3108890056610107e-01
    z[3,0,6]  R660      2.4633076041936874e-02
    z[3,0,6]  R661      1.7295395955443382e-02
    z[3,0,6]  R662      5.9470415115356445e-02
    z[3,0,6]  R663      2.6722386479377747e-01
    z[3,0,6]  R664      -1.2938253581523895e-01
    z[3,0,6]  R665      1.0591533035039902e-01
    z[3,0,6]  R666      -1.6675411164760590e-01
    z[3,0,6]  R667      -1.0583539307117462e-01
    z[3,0,6]  R668      2.2988523542881012e-01
    z[3,0,6]  R669      -7.8124955296516418e-02
    z[3,0,6]  R670      -3.4003564715385437e-01
    z[3,0,6]  R671      -2.0062687993049622e-01
    z[3,0,6]  R672      -1.7484804987907410e-01
    z[3,0,6]  R673      -1.8011310696601868e-01
    z[3,0,6]  R674      -2.2598819434642792e-01
    z[3,0,6]  R675      2.5719873607158661e-02
    z[3,0,6]  R676      -8.3407811820507050e-02
    z[3,0,6]  R677      2.7665841579437256e-01
    z[3,0,6]  R678      2.1546630561351776e-01
    z[3,0,6]  R679      -1.9060879945755005e-01
    z[3,0,6]  R680      1.4744338393211365e-01
    z[3,0,6]  R681      1.7841245234012604e-01
    z[3,0,6]  R682      1.9542181491851807e-01
    z[3,0,6]  R683      3.0342981219291687e-01
    z[3,0,6]  R684      1.4042806625366211e-01
    z[3,0,6]  R685      5.1081973314285278e-01
    z[3,0,6]  R686      4.2690034955739975e-02
    z[3,0,6]  R687      4.5900359749794006e-01
    z[3,0,6]  R688      6.2206890434026718e-02
    z[3,0,6]  R689      1.7906057834625244e-01
    z[3,0,6]  R690      -1.8205833435058594e-01
    z[3,0,6]  R691      -8.5641875863075256e-02
    z[3,0,6]  R692      5.5052293464541435e-03
    z[3,0,6]  R693      2.7318498492240906e-01
    z[3,0,6]  R694      9.1474344953894615e-03
    z[3,0,6]  R695      1.3312149047851562e-01
    z[3,0,6]  R696      -1.0616851598024368e-01
    z[3,0,6]  R697      -1.2419880181550980e-01
    z[3,0,6]  R698      -1.3380878372117877e-03
    z[3,0,6]  R699      -8.7297163903713226e-02
    z[3,0,6]  R700      2.3277722299098969e-01
    z[3,0,6]  R701      1.1558146029710770e-01
    z[3,0,6]  R702      -0.0084022656083107
    z[3,0,6]  R703      4.3134069442749023e-01
    z[3,0,6]  R704      2.4139201641082764e-01
    z[3,0,6]  R705      3.5985150933265686e-01
    z[3,0,6]  R706      0.335778146982193
    z[3,0,6]  R707      -0.361446738243103
    z[3,0,6]  R708      2.3352560400962830e-01
    z[3,0,6]  R709      4.9750655889511108e-02
    z[3,0,6]  R710      -1.0317817330360413e-01
    z[3,0,6]  R711      -1.2786078453063965e-01
    z[3,0,6]  R712      -2.5190016627311707e-01
    z[3,0,6]  R713      -2.3922783136367798e-01
    z[3,0,6]  R714      5.5657601356506348e-01
    z[3,0,6]  R715      -3.3673766255378723e-01
    z[3,0,6]  R716      0.323076069355011
    z[3,0,6]  R717      -1.0856927372515202e-02
    z[3,0,6]  R718      -1.5177269279956818e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R719      -1
    z[0,4,0]  R720      1
    z[0,4,0]  R733      5.2258968353271484e-01
    z[0,4,0]  R734      2.7141281962394714e-01
    z[0,4,0]  R735      -5.9181714057922363e-01
    z[0,4,0]  R736      -5.4779791831970215e-01
    z[0,4,0]  R737      6.4446645975112915e-01
    z[0,4,0]  R738      2.4215668439865112e-01
    z[0,4,0]  R739      2.7344632148742676e-01
    z[0,4,0]  R740      -0.502898633480072
    z[0,4,0]  R741      -5.9624433517456055e-01
    z[0,4,0]  R742      -0.508691668510437
    z[0,4,0]  R743      -2.1039625629782677e-02
    z[0,4,0]  R744      -6.3955950736999512e-01
    z[0,4,0]  R745      3.8346239924430847e-01
    z[0,4,0]  R746      -5.8709084987640381e-01
    z[0,4,0]  R747      -5.7609003782272339e-01
    z[0,4,0]  R748      -1.5098403394222260e-01
    z[0,4,0]  R749      3.4997817873954773e-01
    z[0,4,0]  R750      1.9455881416797638e-01
    z[0,4,0]  R751      -1.0306473821401596e-01
    z[0,4,0]  R752      7.2607177495956421e-01
    z[0,4,0]  R753      3.5984647274017334e-01
    z[0,4,0]  R754      4.0053266286849976e-01
    z[0,4,0]  R755      2.8451833128929138e-01
    z[0,4,0]  R756      -4.9256992340087891e-01
    z[0,4,0]  R757      5.8289057016372681e-01
    z[0,4,0]  R758      3.2223412394523621e-01
    z[0,4,0]  R759      5.2027565240859985e-01
    z[0,4,0]  R760      8.9749681949615479e-01
    z[0,4,0]  R761      7.7735997736454010e-02
    z[0,4,0]  R762      4.8377230763435364e-01
    z[0,4,0]  R763      3.3621346950531006e-01
    z[0,4,0]  R764      4.4479519128799438e-01
    z[0,4,0]  R765      6.3285452127456665e-01
    z[0,4,0]  R766      2.5843468308448792e-01
    z[0,4,0]  R767      4.4759970158338547e-02
    z[0,4,0]  R768      1.8317356705665588e-01
    z[0,4,0]  R769      -1.5814730897545815e-02
    z[0,4,0]  R770      7.2875326871871948e-01
    z[0,4,0]  R771      1.0331102460622787e-01
    z[0,4,0]  R772      -4.7458952665328979e-01
    z[0,4,0]  R773      5.9786039590835571e-01
    z[0,4,0]  R774      2.3851300776004791e-01
    z[0,4,0]  R775      2.6434731483459473e-01
    z[0,4,0]  R776      7.2767162322998047e-01
    z[0,4,0]  R777      5.7752884924411774e-02
    z[0,4,0]  R778      -0.486916184425354
    z[0,4,0]  R779      4.2904263734817505e-01
    z[0,4,0]  R780      1.7858929932117462e-01
    z[0,4,0]  R781      -1.9521364942193031e-02
    z[0,4,0]  R782      2.5948521494865417e-01
    z[0,4,0]  R783      6.5763312578201294e-01
    z[0,4,0]  R784      3.5264107584953308e-01
    z[0,4,0]  R785      5.9940475225448608e-01
    z[0,4,0]  R786      0.693200409412384
    z[0,4,0]  R787      -5.1868766546249390e-01
    z[0,4,0]  R788      -5.5990439653396606e-01
    z[0,4,0]  R789      1.3997834920883179e-01
    z[0,4,0]  R790      -6.3276566565036774e-02
    z[0,4,0]  R791      0.837135374546051
    z[0,4,0]  R792      9.2894226312637329e-01
    z[0,4,0]  R793      -6.2266051769256592e-01
    z[0,4,0]  R794      7.6999038457870483e-01
    z[0,4,0]  R795      -4.2529711127281189e-01
    z[0,4,0]  R796      -5.8424901962280273e-01
    z[0,4,0]  R797      5.6201267242431641e-01
    z[0,4,0]  R798      -1.1042773723602295e-01
    z[0,4,0]  R799      2.5928720831871033e-01
    z[0,4,0]  R800      -3.6640220880508423e-01
    z[0,4,0]  R801      5.1088446378707886e-01
    z[0,4,0]  R802      5.1166445016860962e-01
    z[0,4,0]  R803      3.0087643861770630e-01
    z[0,4,0]  R804      -3.6423809826374054e-02
    z[0,4,0]  R805      6.0400050878524780e-01
    z[0,4,0]  R806      5.4995787143707275e-01
    z[0,4,0]  R807      4.2954602837562561e-01
    z[0,4,0]  R808      -4.6089485287666321e-01
    z[0,4,0]  R809      -1.0036650300025940e-01
    z[0,4,0]  R810      1.5186357498168945e-01
    z[0,4,0]  R811      1.5081593394279480e-01
    z[0,4,0]  R812      4.9989837408065796e-01
    z[0,4,0]  R813      2.5372245907783508e-01
    z[0,4,0]  R814      7.4551028013229370e-01
    z[0,4,0]  R815      1.8130171298980713e-01
    z[0,4,0]  R816      -5.2088344097137451e-01
    z[0,4,0]  R817      5.0005221366882324e-01
    z[0,4,0]  R818      0.537525475025177
    z[0,4,0]  R819      -0.516525387763977
    z[0,4,0]  R820      -2.1711751818656921e-01
    z[0,4,0]  R821      -6.7841041088104248e-01
    z[0,4,0]  R822      6.5063852071762085e-01
    z[0,4,0]  R823      1.6145157814025879e-01
    z[0,4,0]  R824      -6.0774767771363258e-03
    z[0,4,0]  R825      2.2393876314163208e-01
    z[0,4,0]  R826      -8.2619786262512207e-02
    z[0,4,0]  R827      -1.9507546722888947e-01
    z[0,4,0]  R828      -2.6520419120788574e-01
    z[0,4,0]  R829      -3.1409361958503723e-01
    z[0,4,0]  R830      2.3205070756375790e-03
    z[0,4,0]  R831      3.8971800357103348e-02
    z[0,4,0]  R832      1.1771667003631592e-01
    z[0,4,0]  R833      -2.2602401673793793e-01
    z[0,4,0]  R834      -7.5803823769092560e-02
    z[0,4,0]  R835      5.8438873291015625e-01
    z[0,4,0]  R836      -2.4338236451148987e-01
    z[0,4,0]  R837      -3.5414078831672668e-01
    z[0,4,0]  R838      -4.8526591062545776e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R721      -1
    z[0,4,1]  R722      1
    z[0,4,1]  R733      3.6833387613296509e-01
    z[0,4,1]  R734      7.9607349634170532e-01
    z[0,4,1]  R735      -4.1194394230842590e-01
    z[0,4,1]  R736      -3.9958181977272034e-01
    z[0,4,1]  R737      4.9775320291519165e-01
    z[0,4,1]  R738      7.2175461053848267e-01
    z[0,4,1]  R739      -5.8704257011413574e-01
    z[0,4,1]  R740      -6.2557137012481689e-01
    z[0,4,1]  R741      -4.7308912873268127e-01
    z[0,4,1]  R742      -6.1057257652282715e-01
    z[0,4,1]  R743      -8.6844104528427124e-01
    z[0,4,1]  R744      -3.7819364666938782e-01
    z[0,4,1]  R745      7.8421306610107422e-01
    z[0,4,1]  R746      -4.6251523494720459e-01
    z[0,4,1]  R747      -6.7398720979690552e-01
    z[0,4,1]  R748      -0.629465639591217
    z[0,4,1]  R749      7.1435183286666870e-01
    z[0,4,1]  R750      7.6606941223144531e-01
    z[0,4,1]  R751      -0.630012571811676
    z[0,4,1]  R752      3.3499780297279358e-01
    z[0,4,1]  R753      8.1709533929824829e-01
    z[0,4,1]  R754      7.3661535978317261e-01
    z[0,4,1]  R755      7.3152804374694824e-01
    z[0,4,1]  R756      -3.0366113781929016e-01
    z[0,4,1]  R757      5.0897938013076782e-01
    z[0,4,1]  R758      6.3099247217178345e-01
    z[0,4,1]  R759      3.2106861472129822e-01
    z[0,4,1]  R760      -1.1713733896613121e-02
    z[0,4,1]  R761      0.736412763595581
    z[0,4,1]  R762      7.4944078922271729e-02
    z[0,4,1]  R763      8.3493673801422119e-01
    z[0,4,1]  R764      6.7021858692169189e-01
    z[0,4,1]  R765      1.0754422843456268e-01
    z[0,4,1]  R766      6.6958451271057129e-01
    z[0,4,1]  R767      7.9599660634994507e-01
    z[0,4,1]  R768      -2.4713924527168274e-01
    z[0,4,1]  R769      -0.864155650138855
    z[0,4,1]  R770      3.7200577557086945e-02
    z[0,4,1]  R771      0.793024480342865
    z[0,4,1]  R772      -5.6740152835845947e-01
    z[0,4,1]  R773      3.6730918288230896e-01
    z[0,4,1]  R774      8.8114857673645020e-01
    z[0,4,1]  R775      -7.8086805343627930e-01
    z[0,4,1]  R776      7.9446837306022644e-02
    z[0,4,1]  R777      -2.2397871315479279e-01
    z[0,4,1]  R778      -1.8734152615070343e-01
    z[0,4,1]  R779      -7.8264009952545166e-01
    z[0,4,1]  R780      -3.5057049989700317e-01
    z[0,4,1]  R781      -7.8658795356750488e-01
    z[0,4,1]  R782      -8.6471116542816162e-01
    z[0,4,1]  R783      3.4992757439613342e-01
    z[0,4,1]  R784      -6.2392234802246094e-01
    z[0,4,1]  R785      1.8919041380286217e-02
    z[0,4,1]  R786      -2.0074361562728882e-01
    z[0,4,1]  R787      3.8524657487869263e-02
    z[0,4,1]  R788      -3.3165480941534042e-02
    z[0,4,1]  R789      7.1194154024124146e-01
    z[0,4,1]  R790      -9.2100965976715088e-01
    z[0,4,1]  R791      -3.2712038606405258e-02
    z[0,4,1]  R792      2.0799531042575836e-01
    z[0,4,1]  R793      -1.7363831400871277e-01
    z[0,4,1]  R794      2.6390469074249268e-01
    z[0,4,1]  R795      -8.0534279346466064e-01
    z[0,4,1]  R796      -3.3154079318046570e-01
    z[0,4,1]  R797      3.5923457145690918e-01
    z[0,4,1]  R798      -0.895881712436676
    z[0,4,1]  R799      6.7885470390319824e-01
    z[0,4,1]  R800      -7.6817399263381958e-01
    z[0,4,1]  R801      -6.4891618490219116e-01
    z[0,4,1]  R802      -0.37047278881073
    z[0,4,1]  R803      9.1027367115020752e-01
    z[0,4,1]  R804      -2.2061090171337128e-01
    z[0,4,1]  R805      6.1865431070327759e-01
    z[0,4,1]  R806      6.5419411659240723e-01
    z[0,4,1]  R807      0.648796021938324
    z[0,4,1]  R808      -1.0930936038494110e-01
    z[0,4,1]  R809      -6.4319121837615967e-01
    z[0,4,1]  R810      7.4658292531967163e-01
    z[0,4,1]  R811      -1.6936777532100677e-01
    z[0,4,1]  R812      5.3226995468139648e-01
    z[0,4,1]  R813      8.5525131225585938e-01
    z[0,4,1]  R814      1.5650014579296112e-01
    z[0,4,1]  R815      2.2968946397304535e-01
    z[0,4,1]  R816      -8.4850661456584930e-02
    z[0,4,1]  R817      -3.3790320158004761e-02
    z[0,4,1]  R818      -2.8482902050018311e-01
    z[0,4,1]  R819      1.9975388050079346e-01
    z[0,4,1]  R820      -6.9128429889678955e-01
    z[0,4,1]  R821      -1.3931839168071747e-01
    z[0,4,1]  R822      -3.0566978454589844e-01
    z[0,4,1]  R823      -4.3822664022445679e-01
    z[0,4,1]  R824      1.4301015995442867e-02
    z[0,4,1]  R825      -2.1769827604293823e-01
    z[0,4,1]  R826      7.4809336662292480e-01
    z[0,4,1]  R827      9.2499506473541260e-01
    z[0,4,1]  R828      4.7634577751159668e-01
    z[0,4,1]  R829      -5.9345757961273193e-01
    z[0,4,1]  R830      -0.64082932472229
    z[0,4,1]  R831      -1.9719904661178589e-01
    z[0,4,1]  R832      -1.3739171624183655e-01
    z[0,4,1]  R833      -5.8837819099426270e-01
    z[0,4,1]  R834      -4.8108461499214172e-01
    z[0,4,1]  R835      0.478423148393631
    z[0,4,1]  R836      -3.0948597192764282e-01
    z[0,4,1]  R837      -2.6688629388809204e-01
    z[0,4,1]  R838      -1.9983960315585136e-02
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R723      -1
    z[0,4,2]  R724      1
    z[0,4,2]  R733      7.5606632232666016e-01
    z[0,4,2]  R734      -1.2401672452688217e-01
    z[0,4,2]  R735      -3.7869594991207123e-02
    z[0,4,2]  R736      -0.0090639628469944
    z[0,4,2]  R737      2.5722339749336243e-01
    z[0,4,2]  R738      4.9583235383033752e-01
    z[0,4,2]  R739      -3.1884562224149704e-02
    z[0,4,2]  R740      -1.4853253960609436e-01
    z[0,4,2]  R741      -6.4209826290607452e-02
    z[0,4,2]  R742      -1.8338464200496674e-02
    z[0,4,2]  R743      -9.8827652633190155e-02
    z[0,4,2]  R744      -4.4583427906036377e-01
    z[0,4,2]  R745      -2.6195909827947617e-02
    z[0,4,2]  R746      -3.5094434022903442e-01
    z[0,4,2]  R747      -3.7738955020904541e-01
    z[0,4,2]  R748      -1.5090338885784149e-01
    z[0,4,2]  R749      1.1762766540050507e-01
    z[0,4,2]  R750      -1.6124796122312546e-02
    z[0,4,2]  R751      -1.8149559199810028e-01
    z[0,4,2]  R752      2.9928576946258545e-01
    z[0,4,2]  R753      -1.2259004870429635e-03
    z[0,4,2]  R754      3.9859589934349060e-01
    z[0,4,2]  R755      4.5946672558784485e-01
    z[0,4,2]  R756      -2.7820277214050293e-01
    z[0,4,2]  R757      4.1098093986511230e-01
    z[0,4,2]  R758      -5.0525808334350586e-01
    z[0,4,2]  R759      5.1737630367279053e-01
    z[0,4,2]  R760      1.2611895799636841e-01
    z[0,4,2]  R761      -6.1552878469228745e-02
    z[0,4,2]  R762      4.1487866640090942e-01
    z[0,4,2]  R763      -1.4426006376743317e-01
    z[0,4,2]  R764      2.4643549323081970e-01
    z[0,4,2]  R765      4.1255244612693787e-01
    z[0,4,2]  R766      -5.7148575782775879e-01
    z[0,4,2]  R767      -4.5504567027091980e-01
    z[0,4,2]  R768      1.2018267810344696e-01
    z[0,4,2]  R769      1.8982850015163422e-02
    z[0,4,2]  R770      4.3548887968063354e-01
    z[0,4,2]  R771      -5.8144873380661011e-01
    z[0,4,2]  R772      -1.5069223940372467e-01
    z[0,4,2]  R773      5.2009713649749756e-01
    z[0,4,2]  R774      -1.9687506556510925e-01
    z[0,4,2]  R775      0.0201080534607172
    z[0,4,2]  R776      5.2347022294998169e-01
    z[0,4,2]  R777      -1.1046304553747177e-01
    z[0,4,2]  R778      -6.4911562204360962e-01
    z[0,4,2]  R779      -4.1073363274335861e-02
    z[0,4,2]  R780      -1.6348633170127869e-01
    z[0,4,2]  R781      -1.5209870040416718e-01
    z[0,4,2]  R782      -1.8222853541374207e-01
    z[0,4,2]  R783      5.5721467733383179e-01
    z[0,4,2]  R784      -1.1913654953241348e-01
    z[0,4,2]  R785      4.4215241074562073e-01
    z[0,4,2]  R786      2.7167335152626038e-01
    z[0,4,2]  R787      -3.1831446290016174e-01
    z[0,4,2]  R788      -2.2658412158489227e-01
    z[0,4,2]  R789      -1.0902421921491623e-01
    z[0,4,2]  R790      -1.0851480066776276e-01
    z[0,4,2]  R791      1.1226566135883331e-01
    z[0,4,2]  R792      -5.3804680705070496e-02
    z[0,4,2]  R793      -4.2838653922080994e-01
    z[0,4,2]  R794      5.1253533363342285e-01
    z[0,4,2]  R795      -2.6043480634689331e-01
    z[0,4,2]  R796      -4.9675479531288147e-01
    z[0,4,2]  R797      6.2754553556442261e-01
    z[0,4,2]  R798      -1.7652894556522369e-01
    z[0,4,2]  R799      1.6643513739109039e-01
    z[0,4,2]  R800      -2.4202552437782288e-01
    z[0,4,2]  R801      2.7322193980216980e-01
    z[0,4,2]  R802      4.3216076493263245e-01
    z[0,4,2]  R803      4.0930751711130142e-02
    z[0,4,2]  R804      -3.2603389024734497e-01
    z[0,4,2]  R805      2.0815475285053253e-01
    z[0,4,2]  R806      -1.8299816176295280e-02
    z[0,4,2]  R807      1.6122369468212128e-01
    z[0,4,2]  R808      -3.9493107795715332e-01
    z[0,4,2]  R809      -1.2309246696531773e-02
    z[0,4,2]  R810      -7.8025050461292267e-02
    z[0,4,2]  R811      2.3661802709102631e-01
    z[0,4,2]  R812      -0.338933527469635
    z[0,4,2]  R813      -4.0052774548530579e-01
    z[0,4,2]  R814      5.3929162025451660e-01
    z[0,4,2]  R815      -2.8605839610099792e-01
    z[0,4,2]  R816      -7.1341377496719360e-01
    z[0,4,2]  R817      6.6442453861236572e-01
    z[0,4,2]  R818      5.2587682008743286e-01
    z[0,4,2]  R819      -2.2238335013389587e-01
    z[0,4,2]  R820      -2.7310755848884583e-01
    z[0,4,2]  R821      -2.7657121419906616e-01
    z[0,4,2]  R822      -1.7558740451931953e-02
    z[0,4,2]  R823      -6.9253191351890564e-02
    z[0,4,2]  R824      -3.0256372690200806e-01
    z[0,4,2]  R825      -2.5511956214904785e-01
    z[0,4,2]  R826      2.0857103168964386e-01
    z[0,4,2]  R827      1.8213124573230743e-01
    z[0,4,2]  R828      5.2006185054779053e-01
    z[0,4,2]  R829      -4.6254900097846985e-01
    z[0,4,2]  R830      -3.6887651681900024e-01
    z[0,4,2]  R831      -6.4441967010498047e-01
    z[0,4,2]  R832      -0.922522783279419
    z[0,4,2]  R833      2.0473857223987579e-01
    z[0,4,2]  R834      5.9967929124832153e-01
    z[0,4,2]  R835      5.0681042671203613e-01
    z[0,4,2]  R836      0.664128839969635
    z[0,4,2]  R837      2.5165876746177673e-01
    z[0,4,2]  R838      -4.6096905134618282e-03
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R725      -1
    z[0,4,3]  R726      1
    z[0,4,3]  R733      0.00919360015541315
    z[0,4,3]  R734      2.7194846421480179e-02
    z[0,4,3]  R735      -3.4394222497940063e-01
    z[0,4,3]  R736      -2.9011097550392151e-01
    z[0,4,3]  R737      2.4903476238250732e-01
    z[0,4,3]  R738      -2.2532276809215546e-01
    z[0,4,3]  R739      0.312175452709198
    z[0,4,3]  R740      -3.8715666532516479e-01
    z[0,4,3]  R741      -2.5482279062271118e-01
    z[0,4,3]  R742      -5.9454911947250366e-01
    z[0,4,3]  R743      3.3574298024177551e-01
    z[0,4,3]  R744      -2.1461232006549835e-01
    z[0,4,3]  R745      -1.5855069458484650e-01
    z[0,4,3]  R746      -4.1359403729438782e-01
    z[0,4,3]  R747      -1.9654460251331329e-01
    z[0,4,3]  R748      6.0009920597076416e-01
    z[0,4,3]  R749      3.2986736297607422e-01
    z[0,4,3]  R750      -1.6660936176776886e-01
    z[0,4,3]  R751      2.6079794764518738e-01
    z[0,4,3]  R752      1.9063760340213776e-01
    z[0,4,3]  R753      -1.6288323700428009e-01
    z[0,4,3]  R754      -0.350488543510437
    z[0,4,3]  R755      5.7509769685566425e-03
    z[0,4,3]  R756      -6.6776730120182037e-02
    z[0,4,3]  R757      3.5175219178199768e-01
    z[0,4,3]  R758      -9.1895036399364471e-02
    z[0,4,3]  R759      -1.6132335364818573e-01
    z[0,4,3]  R760      -3.7675538659095764e-01
    z[0,4,3]  R761      5.1050532609224319e-02
    z[0,4,3]  R762      -3.3609023690223694e-01
    z[0,4,3]  R763      9.2560619115829468e-02
    z[0,4,3]  R764      4.1062968969345093e-01
    z[0,4,3]  R765      -4.9150732159614563e-01
    z[0,4,3]  R766      3.0427560210227966e-01
    z[0,4,3]  R767      -3.7423957139253616e-02
    z[0,4,3]  R768      7.6432478427886963e-01
    z[0,4,3]  R769      0.371351420879364
    z[0,4,3]  R770      -0.270082950592041
    z[0,4,3]  R771      -5.0245355814695358e-02
    z[0,4,3]  R772      -3.0831021070480347e-01
    z[0,4,3]  R773      -2.0431217551231384e-01
    z[0,4,3]  R774      -1.0609222948551178e-01
    z[0,4,3]  R775      0.522624135017395
    z[0,4,3]  R776      -2.4257950484752655e-01
    z[0,4,3]  R777      8.3517897129058838e-01
    z[0,4,3]  R778      -2.3713992536067963e-01
    z[0,4,3]  R779      1.7736728489398956e-01
    z[0,4,3]  R780      4.9250704050064087e-01
    z[0,4,3]  R781      3.4422501921653748e-02
    z[0,4,3]  R782      -2.3740322887897491e-01
    z[0,4,3]  R783      -1.6251015663146973e-01
    z[0,4,3]  R784      0.574330747127533
    z[0,4,3]  R785      2.0639950037002563e-01
    z[0,4,3]  R786      5.0674965605139732e-03
    z[0,4,3]  R787      -1.4749768376350403e-01
    z[0,4,3]  R788      -1.6726320981979370e-01
    z[0,4,3]  R789      -2.8104493021965027e-01
    z[0,4,3]  R790      -0.0925268605351448
    z[0,4,3]  R791      1.2001358903944492e-02
    z[0,4,3]  R792      -4.5203246176242828e-02
    z[0,4,3]  R793      -3.4919625520706177e-01
    z[0,4,3]  R794      -1.7929084599018097e-02
    z[0,4,3]  R795      2.7303194999694824e-01
    z[0,4,3]  R796      -3.5218429565429688e-01
    z[0,4,3]  R797      3.2124549150466919e-02
    z[0,4,3]  R798      -1.8332313047721982e-03
    z[0,4,3]  R799      -4.7861579060554504e-01
    z[0,4,3]  R800      -2.9377844929695129e-01
    z[0,4,3]  R801      -3.6752650141716003e-01
    z[0,4,3]  R802      -4.6634238958358765e-01
    z[0,4,3]  R803      -7.7418766915798187e-02
    z[0,4,3]  R804      8.1320095062255859e-01
    z[0,4,3]  R805      -3.8583735004067421e-03
    z[0,4,3]  R806      3.5540437698364258e-01
    z[0,4,3]  R807      3.0389702320098877e-01
    z[0,4,3]  R808      -0.0907410979270935
    z[0,4,3]  R809      6.5078479051589966e-01
    z[0,4,3]  R810      2.4905851483345032e-01
    z[0,4,3]  R811      6.0266852378845215e-01
    z[0,4,3]  R812      0.380577027797699
    z[0,4,3]  R813      -1.5043872594833374e-01
    z[0,4,3]  R814      -2.0054295659065247e-01
    z[0,4,3]  R815      5.1038622856140137e-01
    z[0,4,3]  R816      -3.4189623594284058e-01
    z[0,4,3]  R817      2.6827251911163330e-01
    z[0,4,3]  R818      -1.0436327010393143e-01
    z[0,4,3]  R819      3.3484068512916565e-01
    z[0,4,3]  R820      -2.3631818592548370e-01
    z[0,4,3]  R821      3.1567353010177612e-01
    z[0,4,3]  R822      -3.0971601605415344e-01
    z[0,4,3]  R823      -2.4998681247234344e-01
    z[0,4,3]  R824      1.4707107841968536e-01
    z[0,4,3]  R825      -1.5856083482503891e-02
    z[0,4,3]  R826      -4.9564335495233536e-02
    z[0,4,3]  R827      1.7448128759860992e-01
    z[0,4,3]  R828      1.1912860721349716e-01
    z[0,4,3]  R829      1.2183716893196106e-01
    z[0,4,3]  R830      6.3129603862762451e-01
    z[0,4,3]  R831      2.3715730011463165e-01
    z[0,4,3]  R832      -5.4982539266347885e-02
    z[0,4,3]  R833      6.4663213491439819e-01
    z[0,4,3]  R834      -1.8719787895679474e-01
    z[0,4,3]  R835      7.6703488826751709e-02
    z[0,4,3]  R836      -5.4994624853134155e-01
    z[0,4,3]  R837      -7.2672683000564575e-01
    z[0,4,3]  R838      -8.0413794517517090e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R727      -1
    z[0,4,4]  R728      1
    z[0,4,4]  R733      1.2621775269508362e-01
    z[0,4,4]  R734      4.3071404099464417e-01
    z[0,4,4]  R735      3.2724443823099136e-02
    z[0,4,4]  R736      0.257503867149353
    z[0,4,4]  R737      3.4328451752662659e-01
    z[0,4,4]  R738      6.9391697645187378e-02
    z[0,4,4]  R739      -6.1629676818847656e-01
    z[0,4,4]  R740      3.7020224332809448e-01
    z[0,4,4]  R741      -3.1938779354095459e-01
    z[0,4,4]  R742      1.0658331215381622e-01
    z[0,4,4]  R743      7.4869275093078613e-02
    z[0,4,4]  R744      -1.6004875302314758e-01
    z[0,4,4]  R745      -2.3936209082603455e-01
    z[0,4,4]  R746      -0.0923909991979599
    z[0,4,4]  R747      -1.3523493707180023e-01
    z[0,4,4]  R748      -4.2124426364898682e-01
    z[0,4,4]  R749      -4.9312117695808411e-01
    z[0,4,4]  R750      -5.5431240797042847e-01
    z[0,4,4]  R751      -4.9785044789314270e-01
    z[0,4,4]  R752      3.2990675419569016e-02
    z[0,4,4]  R753      1.6835348308086395e-01
    z[0,4,4]  R754      8.0416696146130562e-03
    z[0,4,4]  R755      -1.0430266708135605e-01
    z[0,4,4]  R756      4.0577873587608337e-01
    z[0,4,4]  R757      -1.4028076827526093e-01
    z[0,4,4]  R758      3.4348881244659424e-01
    z[0,4,4]  R759      2.8809541463851929e-01
    z[0,4,4]  R760      1.9812004640698433e-02
    z[0,4,4]  R761      -2.5096428394317627e-01
    z[0,4,4]  R762      3.6399370431900024e-01
    z[0,4,4]  R763      2.0979216694831848e-01
    z[0,4,4]  R764      2.0947840809822083e-01
    z[0,4,4]  R765      1.3595707714557648e-01
    z[0,4,4]  R766      -1.9441372156143188e-01
    z[0,4,4]  R767      -7.6700314879417419e-02
    z[0,4,4]  R768      -5.0680446624755859e-01
    z[0,4,4]  R769      1.0740419477224350e-01
    z[0,4,4]  R770      -3.5317346453666687e-01
    z[0,4,4]  R771      -9.2873267829418182e-02
    z[0,4,4]  R772      4.1667231917381287e-01
    z[0,4,4]  R773      2.7484133839607239e-01
    z[0,4,4]  R774      -4.5726341195404530e-03
    z[0,4,4]  R775      5.4045025259256363e-02
    z[0,4,4]  R776      -1.1667429655790329e-01
    z[0,4,4]  R777      -4.5199674367904663e-01
    z[0,4,4]  R778      3.3902961015701294e-01
    z[0,4,4]  R779      -4.1172477602958679e-01
    z[0,4,4]  R780      7.5132292509078979e-01
    z[0,4,4]  R781      -3.4670770168304443e-01
    z[0,4,4]  R782      -2.2079072892665863e-01
    z[0,4,4]  R783      -1.1875396221876144e-01
    z[0,4,4]  R784      -3.1644481420516968e-01
    z[0,4,4]  R785      3.1604072451591492e-01
    z[0,4,4]  R786      4.8546192049980164e-01
    z[0,4,4]  R787      -0.128139927983284
    z[0,4,4]  R788      -0.0866321325302124
    z[0,4,4]  R789      2.3385412991046906e-01
    z[0,4,4]  R790      5.7850323617458344e-02
    z[0,4,4]  R791      0.257344514131546
    z[0,4,4]  R792      2.4556914344429970e-02
    z[0,4,4]  R793      -1.6494618356227875e-01
    z[0,4,4]  R794      -1.3364669680595398e-01
    z[0,4,4]  R795      -1.1719775199890137e-01
    z[0,4,4]  R796      2.2424438595771790e-01
    z[0,4,4]  R797      -0.00995875895023346
    z[0,4,4]  R798      -3.8880905508995056e-01
    z[0,4,4]  R799      4.3893387913703918e-01
    z[0,4,4]  R800      2.5893932580947876e-01
    z[0,4,4]  R801      2.4864292144775391e-01
    z[0,4,4]  R802      -5.9497680515050888e-02
    z[0,4,4]  R803      1.3169558346271515e-01
    z[0,4,4]  R804      -3.2660955190658569e-01
    z[0,4,4]  R805      2.6325416564941406e-01
    z[0,4,4]  R806      -1.8018412590026855e-01
    z[0,4,4]  R807      2.0091657340526581e-01
    z[0,4,4]  R808      3.4084555506706238e-01
    z[0,4,4]  R809      -7.8271649777889252e-02
    z[0,4,4]  R810      -2.3090025782585144e-01
    z[0,4,4]  R811      5.3224277496337891e-01
    z[0,4,4]  R812      2.5602266192436218e-01
    z[0,4,4]  R813      -3.1911402940750122e-02
    z[0,4,4]  R814      -3.4819513559341431e-02
    z[0,4,4]  R815      -6.8201929330825806e-01
    z[0,4,4]  R816      2.4720046669244766e-02
    z[0,4,4]  R817      0.348127543926239
    z[0,4,4]  R818      1.2218102067708969e-01
    z[0,4,4]  R819      4.8597112298011780e-01
    z[0,4,4]  R820      -3.2860539853572845e-02
    z[0,4,4]  R821      5.6821429729461670e-01
    z[0,4,4]  R822      5.9923237562179565e-01
    z[0,4,4]  R823      8.5565179586410522e-02
    z[0,4,4]  R824      1.0250149667263031e-01
    z[0,4,4]  R825      -7.1943426132202148e-01
    z[0,4,4]  R826      -5.2581459283828735e-01
    z[0,4,4]  R827      7.3818467557430267e-02
    z[0,4,4]  R828      -3.3409276604652405e-01
    z[0,4,4]  R829      2.5818532705307007e-01
    z[0,4,4]  R830      -1.0727589949965477e-02
    z[0,4,4]  R831      5.7517445087432861e-01
    z[0,4,4]  R832      1.7057368159294128e-01
    z[0,4,4]  R833      3.7018975615501404e-01
    z[0,4,4]  R834      -4.3188139796257019e-01
    z[0,4,4]  R835      -1.1991918087005615e-01
    z[0,4,4]  R836      1.2100233882665634e-01
    z[0,4,4]  R837      -1.7268361151218414e-01
    z[0,4,4]  R838      -1.9243207573890686e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R729      -1
    z[0,4,5]  R730      1
    z[0,4,5]  R733      -5.0898045301437378e-02
    z[0,4,5]  R734      -2.7517560124397278e-01
    z[0,4,5]  R735      -5.5973863601684570e-01
    z[0,4,5]  R736      -6.2088322639465332e-01
    z[0,4,5]  R737      0.290799081325531
    z[0,4,5]  R738      -3.4118351340293884e-01
    z[0,4,5]  R739      2.5200262665748596e-01
    z[0,4,5]  R740      -2.1571926772594452e-01
    z[0,4,5]  R741      -4.1396751999855042e-01
    z[0,4,5]  R742      -5.5196538567543030e-02
    z[0,4,5]  R743      -0.340366005897522
    z[0,4,5]  R744      -3.3916282653808594e-01
    z[0,4,5]  R745      2.5396227836608887e-01
    z[0,4,5]  R746      -2.0888239145278931e-01
    z[0,4,5]  R747      -8.8600821793079376e-02
    z[0,4,5]  R748      0.0864071249961853
    z[0,4,5]  R749      -3.5851109772920609e-02
    z[0,4,5]  R750      1.2585379183292389e-01
    z[0,4,5]  R751      -5.6693799793720245e-02
    z[0,4,5]  R752      4.4701176881790161e-01
    z[0,4,5]  R753      9.5144383609294891e-02
    z[0,4,5]  R754      1.2219092994928360e-01
    z[0,4,5]  R755      -3.6877259612083435e-01
    z[0,4,5]  R756      -6.4557117223739624e-01
    z[0,4,5]  R757      2.4793425202369690e-01
    z[0,4,5]  R758      3.3341971039772034e-01
    z[0,4,5]  R759      0.415558785200119
    z[0,4,5]  R760      1.5356499701738358e-02
    z[0,4,5]  R761      -4.3897899985313416e-01
    z[0,4,5]  R762      5.1259106397628784e-01
    z[0,4,5]  R763      -0.0826454684138298
    z[0,4,5]  R764      -2.8129890561103821e-01
    z[0,4,5]  R765      3.9669489860534668e-01
    z[0,4,5]  R766      1.5606077015399933e-01
    z[0,4,5]  R767      -2.8040561079978943e-01
    z[0,4,5]  R768      1.8205150961875916e-01
    z[0,4,5]  R769      3.0326387286186218e-01
    z[0,4,5]  R770      0.228912353515625
    z[0,4,5]  R771      -2.2774764802306890e-03
    z[0,4,5]  R772      -3.2953587174415588e-01
    z[0,4,5]  R773      3.3728504180908203e-01
    z[0,4,5]  R774      -3.2062929123640060e-02
    z[0,4,5]  R775      -6.0443345457315445e-02
    z[0,4,5]  R776      2.9518043994903564e-01
    z[0,4,5]  R777      5.5045560002326965e-03
    z[0,4,5]  R778      -2.9020276665687561e-01
    z[0,4,5]  R779      -8.4798950701951981e-03
    z[0,4,5]  R780      6.6874980926513672e-02
    z[0,4,5]  R781      3.9979156851768494e-01
    z[0,4,5]  R782      0.0141511932015419
    z[0,4,5]  R783      2.4028590321540833e-01
    z[0,4,5]  R784      1.4296466112136841e-01
    z[0,4,5]  R785      5.2013820409774780e-01
    z[0,4,5]  R786      0.362602174282074
    z[0,4,5]  R787      -7.0562714338302612e-01
    z[0,4,5]  R788      -7.6083153486251831e-01
    z[0,4,5]  R789      -2.5893664360046387e-01
    z[0,4,5]  R790      3.4961634874343872e-01
    z[0,4,5]  R791      9.2065773904323578e-02
    z[0,4,5]  R792      0.290505051612854
    z[0,4,5]  R793      -4.6628376841545105e-01
    z[0,4,5]  R794      1.5312932431697845e-01
    z[0,4,5]  R795      -0.0842769518494606
    z[0,4,5]  R796      -3.5723760724067688e-01
    z[0,4,5]  R797      2.9243400692939758e-01
    z[0,4,5]  R798      5.2723549306392670e-02
    z[0,4,5]  R799      -6.9054342806339264e-02
    z[0,4,5]  R800      2.2902987897396088e-01
    z[0,4,5]  R801      -1.7587022483348846e-01
    z[0,4,5]  R802      -4.3951058387756348e-01
    z[0,4,5]  R803      -2.1963946521282196e-01
    z[0,4,5]  R804      -1.4680349826812744e-01
    z[0,4,5]  R805      3.5559117794036865e-01
    z[0,4,5]  R806      3.3225327730178833e-01
    z[0,4,5]  R807      -2.2312594950199127e-01
    z[0,4,5]  R808      -6.6104239225387573e-01
    z[0,4,5]  R809      -1.3015256822109222e-01
    z[0,4,5]  R810      -4.3054780364036560e-01
    z[0,4,5]  R811      -3.3977288007736206e-01
    z[0,4,5]  R812      2.9494670033454895e-01
    z[0,4,5]  R813      1.3274885714054108e-01
    z[0,4,5]  R814      2.7714800834655762e-01
    z[0,4,5]  R815      3.0091580748558044e-01
    z[0,4,5]  R816      -1.7766192555427551e-01
    z[0,4,5]  R817      2.3864848911762238e-01
    z[0,4,5]  R818      1.3339985907077789e-01
    z[0,4,5]  R819      -4.2681032419204712e-01
    z[0,4,5]  R820      4.8897233605384827e-01
    z[0,4,5]  R821      1.4568093419075012e-01
    z[0,4,5]  R822      -6.9919861853122711e-02
    z[0,4,5]  R823      -8.2129734754562378e-01
    z[0,4,5]  R824      -9.1894274950027466e-01
    z[0,4,5]  R825      -5.4655605554580688e-01
    z[0,4,5]  R826      -1.7226213216781616e-01
    z[0,4,5]  R827      -1.9043882191181183e-01
    z[0,4,5]  R828      -2.8559145331382751e-01
    z[0,4,5]  R829      3.0790126323699951e-01
    z[0,4,5]  R830      2.2312806546688080e-01
    z[0,4,5]  R831      3.2654333114624023e-01
    z[0,4,5]  R832      2.8997638821601868e-01
    z[0,4,5]  R833      -5.0029352307319641e-02
    z[0,4,5]  R834      4.2158621549606323e-01
    z[0,4,5]  R835      -1.1760377138853073e-01
    z[0,4,5]  R836      2.8125956654548645e-01
    z[0,4,5]  R837      2.9197099804878235e-01
    z[0,4,5]  R838      2.0851273834705353e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R731      -1
    z[0,4,6]  R732      1
    z[0,4,6]  R733      3.1428948044776917e-02
    z[0,4,6]  R734      -1.2347525358200073e-01
    z[0,4,6]  R735      2.1435044705867767e-01
    z[0,4,6]  R736      6.4815111458301544e-02
    z[0,4,6]  R737      7.9461887478828430e-02
    z[0,4,6]  R738      -5.0881922245025635e-02
    z[0,4,6]  R739      1.9700525701045990e-01
    z[0,4,6]  R740      -1.4722093008458614e-02
    z[0,4,6]  R741      2.7972161769866943e-01
    z[0,4,6]  R742      -1.4217411167919636e-02
    z[0,4,6]  R743      -3.7718974053859711e-02
    z[0,4,6]  R744      -2.4991898238658905e-01
    z[0,4,6]  R745      3.0058425664901733e-01
    z[0,4,6]  R746      3.0824345350265503e-01
    z[0,4,6]  R747      8.1671245396137238e-02
    z[0,4,6]  R748      1.1477380245923996e-01
    z[0,4,6]  R749      1.0683772154152393e-02
    z[0,4,6]  R750      -1.5544918179512024e-01
    z[0,4,6]  R751      4.9034300446510315e-01
    z[0,4,6]  R752      -1.8377602100372314e-01
    z[0,4,6]  R753      -0.37274369597435
    z[0,4,6]  R754      1.5977036207914352e-02
    z[0,4,6]  R755      1.6093797981739044e-01
    z[0,4,6]  R756      4.3478954583406448e-02
    z[0,4,6]  R757      -1.6550987958908081e-01
    z[0,4,6]  R758      -7.1623444557189941e-02
    z[0,4,6]  R759      -2.7719438076019287e-01
    z[0,4,6]  R760      -1.8942917883396149e-01
    z[0,4,6]  R761      0.43539959192276
    z[0,4,6]  R762      2.8288811445236206e-01
    z[0,4,6]  R763      -3.3108890056610107e-01
    z[0,4,6]  R764      2.4633076041936874e-02
    z[0,4,6]  R765      1.7295395955443382e-02
    z[0,4,6]  R766      5.9470415115356445e-02
    z[0,4,6]  R767      2.6722386479377747e-01
    z[0,4,6]  R768      -1.2938253581523895e-01
    z[0,4,6]  R769      1.0591533035039902e-01
    z[0,4,6]  R770      -1.6675411164760590e-01
    z[0,4,6]  R771      -1.0583539307117462e-01
    z[0,4,6]  R772      2.2988523542881012e-01
    z[0,4,6]  R773      -7.8124955296516418e-02
    z[0,4,6]  R774      -3.4003564715385437e-01
    z[0,4,6]  R775      -2.0062687993049622e-01
    z[0,4,6]  R776      -1.7484804987907410e-01
    z[0,4,6]  R777      -1.8011310696601868e-01
    z[0,4,6]  R778      -2.2598819434642792e-01
    z[0,4,6]  R779      2.5719873607158661e-02
    z[0,4,6]  R780      -8.3407811820507050e-02
    z[0,4,6]  R781      2.7665841579437256e-01
    z[0,4,6]  R782      2.1546630561351776e-01
    z[0,4,6]  R783      -1.9060879945755005e-01
    z[0,4,6]  R784      1.4744338393211365e-01
    z[0,4,6]  R785      1.7841245234012604e-01
    z[0,4,6]  R786      1.9542181491851807e-01
    z[0,4,6]  R787      3.0342981219291687e-01
    z[0,4,6]  R788      1.4042806625366211e-01
    z[0,4,6]  R789      5.1081973314285278e-01
    z[0,4,6]  R790      4.2690034955739975e-02
    z[0,4,6]  R791      4.5900359749794006e-01
    z[0,4,6]  R792      6.2206890434026718e-02
    z[0,4,6]  R793      1.7906057834625244e-01
    z[0,4,6]  R794      -1.8205833435058594e-01
    z[0,4,6]  R795      -8.5641875863075256e-02
    z[0,4,6]  R796      5.5052293464541435e-03
    z[0,4,6]  R797      2.7318498492240906e-01
    z[0,4,6]  R798      9.1474344953894615e-03
    z[0,4,6]  R799      1.3312149047851562e-01
    z[0,4,6]  R800      -1.0616851598024368e-01
    z[0,4,6]  R801      -1.2419880181550980e-01
    z[0,4,6]  R802      -1.3380878372117877e-03
    z[0,4,6]  R803      -8.7297163903713226e-02
    z[0,4,6]  R804      2.3277722299098969e-01
    z[0,4,6]  R805      1.1558146029710770e-01
    z[0,4,6]  R806      -0.0084022656083107
    z[0,4,6]  R807      4.3134069442749023e-01
    z[0,4,6]  R808      2.4139201641082764e-01
    z[0,4,6]  R809      3.5985150933265686e-01
    z[0,4,6]  R810      0.335778146982193
    z[0,4,6]  R811      -0.361446738243103
    z[0,4,6]  R812      2.3352560400962830e-01
    z[0,4,6]  R813      4.9750655889511108e-02
    z[0,4,6]  R814      -1.0317817330360413e-01
    z[0,4,6]  R815      -1.2786078453063965e-01
    z[0,4,6]  R816      -2.5190016627311707e-01
    z[0,4,6]  R817      -2.3922783136367798e-01
    z[0,4,6]  R818      5.5657601356506348e-01
    z[0,4,6]  R819      -3.3673766255378723e-01
    z[0,4,6]  R820      0.323076069355011
    z[0,4,6]  R821      -1.0856927372515202e-02
    z[0,4,6]  R822      -1.5177269279956818e-01
    z[0,4,6]  R823      1.8097130954265594e-01
    z[0,4,6]  R824      -1.7782452702522278e-01
    z[0,4,6]  R825      -1.4426478743553162e-01
    z[0,4,6]  R826      -2.8533586859703064e-01
    z[0,4,6]  R827      3.1594879925251007e-02
    z[0,4,6]  R828      4.7426262497901917e-01
    z[0,4,6]  R829      -3.9861583709716797e-01
    z[0,4,6]  R830      6.9473057985305786e-02
    z[0,4,6]  R831      2.2498293220996857e-01
    z[0,4,6]  R832      -3.6225235089659691e-03
    z[0,4,6]  R833      5.5946122854948044e-02
    z[0,4,6]  R834      6.2424574047327042e-02
    z[0,4,6]  R835      3.7235689163208008e-01
    z[0,4,6]  R836      -0.0879029706120491
    z[0,4,6]  R837      0.311167448759079
    z[0,4,6]  R838      1.9222594797611237e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R839      -1
    z[4,0,0]  R840      1
    z[4,0,0]  R853      1.6145157814025879e-01
    z[4,0,0]  R854      -6.0774767771363258e-03
    z[4,0,0]  R855      2.2393876314163208e-01
    z[4,0,0]  R856      -8.2619786262512207e-02
    z[4,0,0]  R857      -1.9507546722888947e-01
    z[4,0,0]  R858      -2.6520419120788574e-01
    z[4,0,0]  R859      -3.1409361958503723e-01
    z[4,0,0]  R860      2.3205070756375790e-03
    z[4,0,0]  R861      3.8971800357103348e-02
    z[4,0,0]  R862      1.1771667003631592e-01
    z[4,0,0]  R863      -2.2602401673793793e-01
    z[4,0,0]  R864      -7.5803823769092560e-02
    z[4,0,0]  R865      5.8438873291015625e-01
    z[4,0,0]  R866      -2.4338236451148987e-01
    z[4,0,0]  R867      -3.5414078831672668e-01
    z[4,0,0]  R868      -4.8526591062545776e-01
    z[4,0,0]  R869      5.2258968353271484e-01
    z[4,0,0]  R870      2.7141281962394714e-01
    z[4,0,0]  R871      -5.9181714057922363e-01
    z[4,0,0]  R872      -5.4779791831970215e-01
    z[4,0,0]  R873      6.4446645975112915e-01
    z[4,0,0]  R874      2.4215668439865112e-01
    z[4,0,0]  R875      2.7344632148742676e-01
    z[4,0,0]  R876      -0.502898633480072
    z[4,0,0]  R877      -5.9624433517456055e-01
    z[4,0,0]  R878      -0.508691668510437
    z[4,0,0]  R879      -2.1039625629782677e-02
    z[4,0,0]  R880      -6.3955950736999512e-01
    z[4,0,0]  R881      3.8346239924430847e-01
    z[4,0,0]  R882      -5.8709084987640381e-01
    z[4,0,0]  R883      -5.7609003782272339e-01
    z[4,0,0]  R884      -1.5098403394222260e-01
    z[4,0,0]  R885      3.4997817873954773e-01
    z[4,0,0]  R886      1.9455881416797638e-01
    z[4,0,0]  R887      -1.0306473821401596e-01
    z[4,0,0]  R888      7.2607177495956421e-01
    z[4,0,0]  R889      3.5984647274017334e-01
    z[4,0,0]  R890      4.0053266286849976e-01
    z[4,0,0]  R891      2.8451833128929138e-01
    z[4,0,0]  R892      -4.9256992340087891e-01
    z[4,0,0]  R893      5.8289057016372681e-01
    z[4,0,0]  R894      3.2223412394523621e-01
    z[4,0,0]  R895      5.2027565240859985e-01
    z[4,0,0]  R896      8.9749681949615479e-01
    z[4,0,0]  R897      7.7735997736454010e-02
    z[4,0,0]  R898      4.8377230763435364e-01
    z[4,0,0]  R899      3.3621346950531006e-01
    z[4,0,0]  R900      4.4479519128799438e-01
    z[4,0,0]  R901      6.3285452127456665e-01
    z[4,0,0]  R902      2.5843468308448792e-01
    z[4,0,0]  R903      4.4759970158338547e-02
    z[4,0,0]  R904      1.8317356705665588e-01
    z[4,0,0]  R905      -1.5814730897545815e-02
    z[4,0,0]  R906      7.2875326871871948e-01
    z[4,0,0]  R907      1.0331102460622787e-01
    z[4,0,0]  R908      -4.7458952665328979e-01
    z[4,0,0]  R909      5.9786039590835571e-01
    z[4,0,0]  R910      2.3851300776004791e-01
    z[4,0,0]  R911      2.6434731483459473e-01
    z[4,0,0]  R912      7.2767162322998047e-01
    z[4,0,0]  R913      5.7752884924411774e-02
    z[4,0,0]  R914      -0.486916184425354
    z[4,0,0]  R915      4.2904263734817505e-01
    z[4,0,0]  R916      1.7858929932117462e-01
    z[4,0,0]  R917      -1.9521364942193031e-02
    z[4,0,0]  R918      2.5948521494865417e-01
    z[4,0,0]  R919      6.5763312578201294e-01
    z[4,0,0]  R920      3.5264107584953308e-01
    z[4,0,0]  R921      5.9940475225448608e-01
    z[4,0,0]  R922      0.693200409412384
    z[4,0,0]  R923      -5.1868766546249390e-01
    z[4,0,0]  R924      -5.5990439653396606e-01
    z[4,0,0]  R925      1.3997834920883179e-01
    z[4,0,0]  R926      -6.3276566565036774e-02
    z[4,0,0]  R927      0.837135374546051
    z[4,0,0]  R928      9.2894226312637329e-01
    z[4,0,0]  R929      -6.2266051769256592e-01
    z[4,0,0]  R930      7.6999038457870483e-01
    z[4,0,0]  R931      -4.2529711127281189e-01
    z[4,0,0]  R932      -5.8424901962280273e-01
    z[4,0,0]  R933      5.6201267242431641e-01
    z[4,0,0]  R934      -1.1042773723602295e-01
    z[4,0,0]  R935      2.5928720831871033e-01
    z[4,0,0]  R936      -3.6640220880508423e-01
    z[4,0,0]  R937      5.1088446378707886e-01
    z[4,0,0]  R938      5.1166445016860962e-01
    z[4,0,0]  R939      3.0087643861770630e-01
    z[4,0,0]  R940      -3.6423809826374054e-02
    z[4,0,0]  R941      6.0400050878524780e-01
    z[4,0,0]  R942      5.4995787143707275e-01
    z[4,0,0]  R943      4.2954602837562561e-01
    z[4,0,0]  R944      -4.6089485287666321e-01
    z[4,0,0]  R945      -1.0036650300025940e-01
    z[4,0,0]  R946      1.5186357498168945e-01
    z[4,0,0]  R947      1.5081593394279480e-01
    z[4,0,0]  R948      4.9989837408065796e-01
    z[4,0,0]  R949      2.5372245907783508e-01
    z[4,0,0]  R950      7.4551028013229370e-01
    z[4,0,0]  R951      1.8130171298980713e-01
    z[4,0,0]  R952      -5.2088344097137451e-01
    z[4,0,0]  R953      5.0005221366882324e-01
    z[4,0,0]  R954      0.537525475025177
    z[4,0,0]  R955      -0.516525387763977
    z[4,0,0]  R956      -2.1711751818656921e-01
    z[4,0,0]  R957      -6.7841041088104248e-01
    z[4,0,0]  R958      6.5063852071762085e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R841      -1
    z[4,0,1]  R842      1
    z[4,0,1]  R853      -4.3822664022445679e-01
    z[4,0,1]  R854      1.4301015995442867e-02
    z[4,0,1]  R855      -2.1769827604293823e-01
    z[4,0,1]  R856      7.4809336662292480e-01
    z[4,0,1]  R857      9.2499506473541260e-01
    z[4,0,1]  R858      4.7634577751159668e-01
    z[4,0,1]  R859      -5.9345757961273193e-01
    z[4,0,1]  R860      -0.64082932472229
    z[4,0,1]  R861      -1.9719904661178589e-01
    z[4,0,1]  R862      -1.3739171624183655e-01
    z[4,0,1]  R863      -5.8837819099426270e-01
    z[4,0,1]  R864      -4.8108461499214172e-01
    z[4,0,1]  R865      0.478423148393631
    z[4,0,1]  R866      -3.0948597192764282e-01
    z[4,0,1]  R867      -2.6688629388809204e-01
    z[4,0,1]  R868      -1.9983960315585136e-02
    z[4,0,1]  R869      3.6833387613296509e-01
    z[4,0,1]  R870      7.9607349634170532e-01
    z[4,0,1]  R871      -4.1194394230842590e-01
    z[4,0,1]  R872      -3.9958181977272034e-01
    z[4,0,1]  R873      4.9775320291519165e-01
    z[4,0,1]  R874      7.2175461053848267e-01
    z[4,0,1]  R875      -5.8704257011413574e-01
    z[4,0,1]  R876      -6.2557137012481689e-01
    z[4,0,1]  R877      -4.7308912873268127e-01
    z[4,0,1]  R878      -6.1057257652282715e-01
    z[4,0,1]  R879      -8.6844104528427124e-01
    z[4,0,1]  R880      -3.7819364666938782e-01
    z[4,0,1]  R881      7.8421306610107422e-01
    z[4,0,1]  R882      -4.6251523494720459e-01
    z[4,0,1]  R883      -6.7398720979690552e-01
    z[4,0,1]  R884      -0.629465639591217
    z[4,0,1]  R885      7.1435183286666870e-01
    z[4,0,1]  R886      7.6606941223144531e-01
    z[4,0,1]  R887      -0.630012571811676
    z[4,0,1]  R888      3.3499780297279358e-01
    z[4,0,1]  R889      8.1709533929824829e-01
    z[4,0,1]  R890      7.3661535978317261e-01
    z[4,0,1]  R891      7.3152804374694824e-01
    z[4,0,1]  R892      -3.0366113781929016e-01
    z[4,0,1]  R893      5.0897938013076782e-01
    z[4,0,1]  R894      6.3099247217178345e-01
    z[4,0,1]  R895      3.2106861472129822e-01
    z[4,0,1]  R896      -1.1713733896613121e-02
    z[4,0,1]  R897      0.736412763595581
    z[4,0,1]  R898      7.4944078922271729e-02
    z[4,0,1]  R899      8.3493673801422119e-01
    z[4,0,1]  R900      6.7021858692169189e-01
    z[4,0,1]  R901      1.0754422843456268e-01
    z[4,0,1]  R902      6.6958451271057129e-01
    z[4,0,1]  R903      7.9599660634994507e-01
    z[4,0,1]  R904      -2.4713924527168274e-01
    z[4,0,1]  R905      -0.864155650138855
    z[4,0,1]  R906      3.7200577557086945e-02
    z[4,0,1]  R907      0.793024480342865
    z[4,0,1]  R908      -5.6740152835845947e-01
    z[4,0,1]  R909      3.6730918288230896e-01
    z[4,0,1]  R910      8.8114857673645020e-01
    z[4,0,1]  R911      -7.8086805343627930e-01
    z[4,0,1]  R912      7.9446837306022644e-02
    z[4,0,1]  R913      -2.2397871315479279e-01
    z[4,0,1]  R914      -1.8734152615070343e-01
    z[4,0,1]  R915      -7.8264009952545166e-01
    z[4,0,1]  R916      -3.5057049989700317e-01
    z[4,0,1]  R917      -7.8658795356750488e-01
    z[4,0,1]  R918      -8.6471116542816162e-01
    z[4,0,1]  R919      3.4992757439613342e-01
    z[4,0,1]  R920      -6.2392234802246094e-01
    z[4,0,1]  R921      1.8919041380286217e-02
    z[4,0,1]  R922      -2.0074361562728882e-01
    z[4,0,1]  R923      3.8524657487869263e-02
    z[4,0,1]  R924      -3.3165480941534042e-02
    z[4,0,1]  R925      7.1194154024124146e-01
    z[4,0,1]  R926      -9.2100965976715088e-01
    z[4,0,1]  R927      -3.2712038606405258e-02
    z[4,0,1]  R928      2.0799531042575836e-01
    z[4,0,1]  R929      -1.7363831400871277e-01
    z[4,0,1]  R930      2.6390469074249268e-01
    z[4,0,1]  R931      -8.0534279346466064e-01
    z[4,0,1]  R932      -3.3154079318046570e-01
    z[4,0,1]  R933      3.5923457145690918e-01
    z[4,0,1]  R934      -0.895881712436676
    z[4,0,1]  R935      6.7885470390319824e-01
    z[4,0,1]  R936      -7.6817399263381958e-01
    z[4,0,1]  R937      -6.4891618490219116e-01
    z[4,0,1]  R938      -0.37047278881073
    z[4,0,1]  R939      9.1027367115020752e-01
    z[4,0,1]  R940      -2.2061090171337128e-01
    z[4,0,1]  R941      6.1865431070327759e-01
    z[4,0,1]  R942      6.5419411659240723e-01
    z[4,0,1]  R943      0.648796021938324
    z[4,0,1]  R944      -1.0930936038494110e-01
    z[4,0,1]  R945      -6.4319121837615967e-01
    z[4,0,1]  R946      7.4658292531967163e-01
    z[4,0,1]  R947      -1.6936777532100677e-01
    z[4,0,1]  R948      5.3226995468139648e-01
    z[4,0,1]  R949      8.5525131225585938e-01
    z[4,0,1]  R950      1.5650014579296112e-01
    z[4,0,1]  R951      2.2968946397304535e-01
    z[4,0,1]  R952      -8.4850661456584930e-02
    z[4,0,1]  R953      -3.3790320158004761e-02
    z[4,0,1]  R954      -2.8482902050018311e-01
    z[4,0,1]  R955      1.9975388050079346e-01
    z[4,0,1]  R956      -6.9128429889678955e-01
    z[4,0,1]  R957      -1.3931839168071747e-01
    z[4,0,1]  R958      -3.0566978454589844e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R843      -1
    z[4,0,2]  R844      1
    z[4,0,2]  R853      -6.9253191351890564e-02
    z[4,0,2]  R854      -3.0256372690200806e-01
    z[4,0,2]  R855      -2.5511956214904785e-01
    z[4,0,2]  R856      2.0857103168964386e-01
    z[4,0,2]  R857      1.8213124573230743e-01
    z[4,0,2]  R858      5.2006185054779053e-01
    z[4,0,2]  R859      -4.6254900097846985e-01
    z[4,0,2]  R860      -3.6887651681900024e-01
    z[4,0,2]  R861      -6.4441967010498047e-01
    z[4,0,2]  R862      -0.922522783279419
    z[4,0,2]  R863      2.0473857223987579e-01
    z[4,0,2]  R864      5.9967929124832153e-01
    z[4,0,2]  R865      5.0681042671203613e-01
    z[4,0,2]  R866      0.664128839969635
    z[4,0,2]  R867      2.5165876746177673e-01
    z[4,0,2]  R868      -4.6096905134618282e-03
    z[4,0,2]  R869      7.5606632232666016e-01
    z[4,0,2]  R870      -1.2401672452688217e-01
    z[4,0,2]  R871      -3.7869594991207123e-02
    z[4,0,2]  R872      -0.0090639628469944
    z[4,0,2]  R873      2.5722339749336243e-01
    z[4,0,2]  R874      4.9583235383033752e-01
    z[4,0,2]  R875      -3.1884562224149704e-02
    z[4,0,2]  R876      -1.4853253960609436e-01
    z[4,0,2]  R877      -6.4209826290607452e-02
    z[4,0,2]  R878      -1.8338464200496674e-02
    z[4,0,2]  R879      -9.8827652633190155e-02
    z[4,0,2]  R880      -4.4583427906036377e-01
    z[4,0,2]  R881      -2.6195909827947617e-02
    z[4,0,2]  R882      -3.5094434022903442e-01
    z[4,0,2]  R883      -3.7738955020904541e-01
    z[4,0,2]  R884      -1.5090338885784149e-01
    z[4,0,2]  R885      1.1762766540050507e-01
    z[4,0,2]  R886      -1.6124796122312546e-02
    z[4,0,2]  R887      -1.8149559199810028e-01
    z[4,0,2]  R888      2.9928576946258545e-01
    z[4,0,2]  R889      -1.2259004870429635e-03
    z[4,0,2]  R890      3.9859589934349060e-01
    z[4,0,2]  R891      4.5946672558784485e-01
    z[4,0,2]  R892      -2.7820277214050293e-01
    z[4,0,2]  R893      4.1098093986511230e-01
    z[4,0,2]  R894      -5.0525808334350586e-01
    z[4,0,2]  R895      5.1737630367279053e-01
    z[4,0,2]  R896      1.2611895799636841e-01
    z[4,0,2]  R897      -6.1552878469228745e-02
    z[4,0,2]  R898      4.1487866640090942e-01
    z[4,0,2]  R899      -1.4426006376743317e-01
    z[4,0,2]  R900      2.4643549323081970e-01
    z[4,0,2]  R901      4.1255244612693787e-01
    z[4,0,2]  R902      -5.7148575782775879e-01
    z[4,0,2]  R903      -4.5504567027091980e-01
    z[4,0,2]  R904      1.2018267810344696e-01
    z[4,0,2]  R905      1.8982850015163422e-02
    z[4,0,2]  R906      4.3548887968063354e-01
    z[4,0,2]  R907      -5.8144873380661011e-01
    z[4,0,2]  R908      -1.5069223940372467e-01
    z[4,0,2]  R909      5.2009713649749756e-01
    z[4,0,2]  R910      -1.9687506556510925e-01
    z[4,0,2]  R911      0.0201080534607172
    z[4,0,2]  R912      5.2347022294998169e-01
    z[4,0,2]  R913      -1.1046304553747177e-01
    z[4,0,2]  R914      -6.4911562204360962e-01
    z[4,0,2]  R915      -4.1073363274335861e-02
    z[4,0,2]  R916      -1.6348633170127869e-01
    z[4,0,2]  R917      -1.5209870040416718e-01
    z[4,0,2]  R918      -1.8222853541374207e-01
    z[4,0,2]  R919      5.5721467733383179e-01
    z[4,0,2]  R920      -1.1913654953241348e-01
    z[4,0,2]  R921      4.4215241074562073e-01
    z[4,0,2]  R922      2.7167335152626038e-01
    z[4,0,2]  R923      -3.1831446290016174e-01
    z[4,0,2]  R924      -2.2658412158489227e-01
    z[4,0,2]  R925      -1.0902421921491623e-01
    z[4,0,2]  R926      -1.0851480066776276e-01
    z[4,0,2]  R927      1.1226566135883331e-01
    z[4,0,2]  R928      -5.3804680705070496e-02
    z[4,0,2]  R929      -4.2838653922080994e-01
    z[4,0,2]  R930      5.1253533363342285e-01
    z[4,0,2]  R931      -2.6043480634689331e-01
    z[4,0,2]  R932      -4.9675479531288147e-01
    z[4,0,2]  R933      6.2754553556442261e-01
    z[4,0,2]  R934      -1.7652894556522369e-01
    z[4,0,2]  R935      1.6643513739109039e-01
    z[4,0,2]  R936      -2.4202552437782288e-01
    z[4,0,2]  R937      2.7322193980216980e-01
    z[4,0,2]  R938      4.3216076493263245e-01
    z[4,0,2]  R939      4.0930751711130142e-02
    z[4,0,2]  R940      -3.2603389024734497e-01
    z[4,0,2]  R941      2.0815475285053253e-01
    z[4,0,2]  R942      -1.8299816176295280e-02
    z[4,0,2]  R943      1.6122369468212128e-01
    z[4,0,2]  R944      -3.9493107795715332e-01
    z[4,0,2]  R945      -1.2309246696531773e-02
    z[4,0,2]  R946      -7.8025050461292267e-02
    z[4,0,2]  R947      2.3661802709102631e-01
    z[4,0,2]  R948      -0.338933527469635
    z[4,0,2]  R949      -4.0052774548530579e-01
    z[4,0,2]  R950      5.3929162025451660e-01
    z[4,0,2]  R951      -2.8605839610099792e-01
    z[4,0,2]  R952      -7.1341377496719360e-01
    z[4,0,2]  R953      6.6442453861236572e-01
    z[4,0,2]  R954      5.2587682008743286e-01
    z[4,0,2]  R955      -2.2238335013389587e-01
    z[4,0,2]  R956      -2.7310755848884583e-01
    z[4,0,2]  R957      -2.7657121419906616e-01
    z[4,0,2]  R958      -1.7558740451931953e-02
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R845      -1
    z[4,0,3]  R846      1
    z[4,0,3]  R853      -2.4998681247234344e-01
    z[4,0,3]  R854      1.4707107841968536e-01
    z[4,0,3]  R855      -1.5856083482503891e-02
    z[4,0,3]  R856      -4.9564335495233536e-02
    z[4,0,3]  R857      1.7448128759860992e-01
    z[4,0,3]  R858      1.1912860721349716e-01
    z[4,0,3]  R859      1.2183716893196106e-01
    z[4,0,3]  R860      6.3129603862762451e-01
    z[4,0,3]  R861      2.3715730011463165e-01
    z[4,0,3]  R862      -5.4982539266347885e-02
    z[4,0,3]  R863      6.4663213491439819e-01
    z[4,0,3]  R864      -1.8719787895679474e-01
    z[4,0,3]  R865      7.6703488826751709e-02
    z[4,0,3]  R866      -5.4994624853134155e-01
    z[4,0,3]  R867      -7.2672683000564575e-01
    z[4,0,3]  R868      -8.0413794517517090e-01
    z[4,0,3]  R869      0.00919360015541315
    z[4,0,3]  R870      2.7194846421480179e-02
    z[4,0,3]  R871      -3.4394222497940063e-01
    z[4,0,3]  R872      -2.9011097550392151e-01
    z[4,0,3]  R873      2.4903476238250732e-01
    z[4,0,3]  R874      -2.2532276809215546e-01
    z[4,0,3]  R875      0.312175452709198
    z[4,0,3]  R876      -3.8715666532516479e-01
    z[4,0,3]  R877      -2.5482279062271118e-01
    z[4,0,3]  R878      -5.9454911947250366e-01
    z[4,0,3]  R879      3.3574298024177551e-01
    z[4,0,3]  R880      -2.1461232006549835e-01
    z[4,0,3]  R881      -1.5855069458484650e-01
    z[4,0,3]  R882      -4.1359403729438782e-01
    z[4,0,3]  R883      -1.9654460251331329e-01
    z[4,0,3]  R884      6.0009920597076416e-01
    z[4,0,3]  R885      3.2986736297607422e-01
    z[4,0,3]  R886      -1.6660936176776886e-01
    z[4,0,3]  R887      2.6079794764518738e-01
    z[4,0,3]  R888      1.9063760340213776e-01
    z[4,0,3]  R889      -1.6288323700428009e-01
    z[4,0,3]  R890      -0.350488543510437
    z[4,0,3]  R891      5.7509769685566425e-03
    z[4,0,3]  R892      -6.6776730120182037e-02
    z[4,0,3]  R893      3.5175219178199768e-01
    z[4,0,3]  R894      -9.1895036399364471e-02
    z[4,0,3]  R895      -1.6132335364818573e-01
    z[4,0,3]  R896      -3.7675538659095764e-01
    z[4,0,3]  R897      5.1050532609224319e-02
    z[4,0,3]  R898      -3.3609023690223694e-01
    z[4,0,3]  R899      9.2560619115829468e-02
    z[4,0,3]  R900      4.1062968969345093e-01
    z[4,0,3]  R901      -4.9150732159614563e-01
    z[4,0,3]  R902      3.0427560210227966e-01
    z[4,0,3]  R903      -3.7423957139253616e-02
    z[4,0,3]  R904      7.6432478427886963e-01
    z[4,0,3]  R905      0.371351420879364
    z[4,0,3]  R906      -0.270082950592041
    z[4,0,3]  R907      -5.0245355814695358e-02
    z[4,0,3]  R908      -3.0831021070480347e-01
    z[4,0,3]  R909      -2.0431217551231384e-01
    z[4,0,3]  R910      -1.0609222948551178e-01
    z[4,0,3]  R911      0.522624135017395
    z[4,0,3]  R912      -2.4257950484752655e-01
    z[4,0,3]  R913      8.3517897129058838e-01
    z[4,0,3]  R914      -2.3713992536067963e-01
    z[4,0,3]  R915      1.7736728489398956e-01
    z[4,0,3]  R916      4.9250704050064087e-01
    z[4,0,3]  R917      3.4422501921653748e-02
    z[4,0,3]  R918      -2.3740322887897491e-01
    z[4,0,3]  R919      -1.6251015663146973e-01
    z[4,0,3]  R920      0.574330747127533
    z[4,0,3]  R921      2.0639950037002563e-01
    z[4,0,3]  R922      5.0674965605139732e-03
    z[4,0,3]  R923      -1.4749768376350403e-01
    z[4,0,3]  R924      -1.6726320981979370e-01
    z[4,0,3]  R925      -2.8104493021965027e-01
    z[4,0,3]  R926      -0.0925268605351448
    z[4,0,3]  R927      1.2001358903944492e-02
    z[4,0,3]  R928      -4.5203246176242828e-02
    z[4,0,3]  R929      -3.4919625520706177e-01
    z[4,0,3]  R930      -1.7929084599018097e-02
    z[4,0,3]  R931      2.7303194999694824e-01
    z[4,0,3]  R932      -3.5218429565429688e-01
    z[4,0,3]  R933      3.2124549150466919e-02
    z[4,0,3]  R934      -1.8332313047721982e-03
    z[4,0,3]  R935      -4.7861579060554504e-01
    z[4,0,3]  R936      -2.9377844929695129e-01
    z[4,0,3]  R937      -3.6752650141716003e-01
    z[4,0,3]  R938      -4.6634238958358765e-01
    z[4,0,3]  R939      -7.7418766915798187e-02
    z[4,0,3]  R940      8.1320095062255859e-01
    z[4,0,3]  R941      -3.8583735004067421e-03
    z[4,0,3]  R942      3.5540437698364258e-01
    z[4,0,3]  R943      3.0389702320098877e-01
    z[4,0,3]  R944      -0.0907410979270935
    z[4,0,3]  R945      6.5078479051589966e-01
    z[4,0,3]  R946      2.4905851483345032e-01
    z[4,0,3]  R947      6.0266852378845215e-01
    z[4,0,3]  R948      0.380577027797699
    z[4,0,3]  R949      -1.5043872594833374e-01
    z[4,0,3]  R950      -2.0054295659065247e-01
    z[4,0,3]  R951      5.1038622856140137e-01
    z[4,0,3]  R952      -3.4189623594284058e-01
    z[4,0,3]  R953      2.6827251911163330e-01
    z[4,0,3]  R954      -1.0436327010393143e-01
    z[4,0,3]  R955      3.3484068512916565e-01
    z[4,0,3]  R956      -2.3631818592548370e-01
    z[4,0,3]  R957      3.1567353010177612e-01
    z[4,0,3]  R958      -3.0971601605415344e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R847      -1
    z[4,0,4]  R848      1
    z[4,0,4]  R853      8.5565179586410522e-02
    z[4,0,4]  R854      1.0250149667263031e-01
    z[4,0,4]  R855      -7.1943426132202148e-01
    z[4,0,4]  R856      -5.2581459283828735e-01
    z[4,0,4]  R857      7.3818467557430267e-02
    z[4,0,4]  R858      -3.3409276604652405e-01
    z[4,0,4]  R859      2.5818532705307007e-01
    z[4,0,4]  R860      -1.0727589949965477e-02
    z[4,0,4]  R861      5.7517445087432861e-01
    z[4,0,4]  R862      1.7057368159294128e-01
    z[4,0,4]  R863      3.7018975615501404e-01
    z[4,0,4]  R864      -4.3188139796257019e-01
    z[4,0,4]  R865      -1.1991918087005615e-01
    z[4,0,4]  R866      1.2100233882665634e-01
    z[4,0,4]  R867      -1.7268361151218414e-01
    z[4,0,4]  R868      -1.9243207573890686e-01
    z[4,0,4]  R869      1.2621775269508362e-01
    z[4,0,4]  R870      4.3071404099464417e-01
    z[4,0,4]  R871      3.2724443823099136e-02
    z[4,0,4]  R872      0.257503867149353
    z[4,0,4]  R873      3.4328451752662659e-01
    z[4,0,4]  R874      6.9391697645187378e-02
    z[4,0,4]  R875      -6.1629676818847656e-01
    z[4,0,4]  R876      3.7020224332809448e-01
    z[4,0,4]  R877      -3.1938779354095459e-01
    z[4,0,4]  R878      1.0658331215381622e-01
    z[4,0,4]  R879      7.4869275093078613e-02
    z[4,0,4]  R880      -1.6004875302314758e-01
    z[4,0,4]  R881      -2.3936209082603455e-01
    z[4,0,4]  R882      -0.0923909991979599
    z[4,0,4]  R883      -1.3523493707180023e-01
    z[4,0,4]  R884      -4.2124426364898682e-01
    z[4,0,4]  R885      -4.9312117695808411e-01
    z[4,0,4]  R886      -5.5431240797042847e-01
    z[4,0,4]  R887      -4.9785044789314270e-01
    z[4,0,4]  R888      3.2990675419569016e-02
    z[4,0,4]  R889      1.6835348308086395e-01
    z[4,0,4]  R890      8.0416696146130562e-03
    z[4,0,4]  R891      -1.0430266708135605e-01
    z[4,0,4]  R892      4.0577873587608337e-01
    z[4,0,4]  R893      -1.4028076827526093e-01
    z[4,0,4]  R894      3.4348881244659424e-01
    z[4,0,4]  R895      2.8809541463851929e-01
    z[4,0,4]  R896      1.9812004640698433e-02
    z[4,0,4]  R897      -2.5096428394317627e-01
    z[4,0,4]  R898      3.6399370431900024e-01
    z[4,0,4]  R899      2.0979216694831848e-01
    z[4,0,4]  R900      2.0947840809822083e-01
    z[4,0,4]  R901      1.3595707714557648e-01
    z[4,0,4]  R902      -1.9441372156143188e-01
    z[4,0,4]  R903      -7.6700314879417419e-02
    z[4,0,4]  R904      -5.0680446624755859e-01
    z[4,0,4]  R905      1.0740419477224350e-01
    z[4,0,4]  R906      -3.5317346453666687e-01
    z[4,0,4]  R907      -9.2873267829418182e-02
    z[4,0,4]  R908      4.1667231917381287e-01
    z[4,0,4]  R909      2.7484133839607239e-01
    z[4,0,4]  R910      -4.5726341195404530e-03
    z[4,0,4]  R911      5.4045025259256363e-02
    z[4,0,4]  R912      -1.1667429655790329e-01
    z[4,0,4]  R913      -4.5199674367904663e-01
    z[4,0,4]  R914      3.3902961015701294e-01
    z[4,0,4]  R915      -4.1172477602958679e-01
    z[4,0,4]  R916      7.5132292509078979e-01
    z[4,0,4]  R917      -3.4670770168304443e-01
    z[4,0,4]  R918      -2.2079072892665863e-01
    z[4,0,4]  R919      -1.1875396221876144e-01
    z[4,0,4]  R920      -3.1644481420516968e-01
    z[4,0,4]  R921      3.1604072451591492e-01
    z[4,0,4]  R922      4.8546192049980164e-01
    z[4,0,4]  R923      -0.128139927983284
    z[4,0,4]  R924      -0.0866321325302124
    z[4,0,4]  R925      2.3385412991046906e-01
    z[4,0,4]  R926      5.7850323617458344e-02
    z[4,0,4]  R927      0.257344514131546
    z[4,0,4]  R928      2.4556914344429970e-02
    z[4,0,4]  R929      -1.6494618356227875e-01
    z[4,0,4]  R930      -1.3364669680595398e-01
    z[4,0,4]  R931      -1.1719775199890137e-01
    z[4,0,4]  R932      2.2424438595771790e-01
    z[4,0,4]  R933      -0.00995875895023346
    z[4,0,4]  R934      -3.8880905508995056e-01
    z[4,0,4]  R935      4.3893387913703918e-01
    z[4,0,4]  R936      2.5893932580947876e-01
    z[4,0,4]  R937      2.4864292144775391e-01
    z[4,0,4]  R938      -5.9497680515050888e-02
    z[4,0,4]  R939      1.3169558346271515e-01
    z[4,0,4]  R940      -3.2660955190658569e-01
    z[4,0,4]  R941      2.6325416564941406e-01
    z[4,0,4]  R942      -1.8018412590026855e-01
    z[4,0,4]  R943      2.0091657340526581e-01
    z[4,0,4]  R944      3.4084555506706238e-01
    z[4,0,4]  R945      -7.8271649777889252e-02
    z[4,0,4]  R946      -2.3090025782585144e-01
    z[4,0,4]  R947      5.3224277496337891e-01
    z[4,0,4]  R948      2.5602266192436218e-01
    z[4,0,4]  R949      -3.1911402940750122e-02
    z[4,0,4]  R950      -3.4819513559341431e-02
    z[4,0,4]  R951      -6.8201929330825806e-01
    z[4,0,4]  R952      2.4720046669244766e-02
    z[4,0,4]  R953      0.348127543926239
    z[4,0,4]  R954      1.2218102067708969e-01
    z[4,0,4]  R955      4.8597112298011780e-01
    z[4,0,4]  R956      -3.2860539853572845e-02
    z[4,0,4]  R957      5.6821429729461670e-01
    z[4,0,4]  R958      5.9923237562179565e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R849      -1
    z[4,0,5]  R850      1
    z[4,0,5]  R853      -8.2129734754562378e-01
    z[4,0,5]  R854      -9.1894274950027466e-01
    z[4,0,5]  R855      -5.4655605554580688e-01
    z[4,0,5]  R856      -1.7226213216781616e-01
    z[4,0,5]  R857      -1.9043882191181183e-01
    z[4,0,5]  R858      -2.8559145331382751e-01
    z[4,0,5]  R859      3.0790126323699951e-01
    z[4,0,5]  R860      2.2312806546688080e-01
    z[4,0,5]  R861      3.2654333114624023e-01
    z[4,0,5]  R862      2.8997638821601868e-01
    z[4,0,5]  R863      -5.0029352307319641e-02
    z[4,0,5]  R864      4.2158621549606323e-01
    z[4,0,5]  R865      -1.1760377138853073e-01
    z[4,0,5]  R866      2.8125956654548645e-01
    z[4,0,5]  R867      2.9197099804878235e-01
    z[4,0,5]  R868      2.0851273834705353e-01
    z[4,0,5]  R869      -5.0898045301437378e-02
    z[4,0,5]  R870      -2.7517560124397278e-01
    z[4,0,5]  R871      -5.5973863601684570e-01
    z[4,0,5]  R872      -6.2088322639465332e-01
    z[4,0,5]  R873      0.290799081325531
    z[4,0,5]  R874      -3.4118351340293884e-01
    z[4,0,5]  R875      2.5200262665748596e-01
    z[4,0,5]  R876      -2.1571926772594452e-01
    z[4,0,5]  R877      -4.1396751999855042e-01
    z[4,0,5]  R878      -5.5196538567543030e-02
    z[4,0,5]  R879      -0.340366005897522
    z[4,0,5]  R880      -3.3916282653808594e-01
    z[4,0,5]  R881      2.5396227836608887e-01
    z[4,0,5]  R882      -2.0888239145278931e-01
    z[4,0,5]  R883      -8.8600821793079376e-02
    z[4,0,5]  R884      0.0864071249961853
    z[4,0,5]  R885      -3.5851109772920609e-02
    z[4,0,5]  R886      1.2585379183292389e-01
    z[4,0,5]  R887      -5.6693799793720245e-02
    z[4,0,5]  R888      4.4701176881790161e-01
    z[4,0,5]  R889      9.5144383609294891e-02
    z[4,0,5]  R890      1.2219092994928360e-01
    z[4,0,5]  R891      -3.6877259612083435e-01
    z[4,0,5]  R892      -6.4557117223739624e-01
    z[4,0,5]  R893      2.4793425202369690e-01
    z[4,0,5]  R894      3.3341971039772034e-01
    z[4,0,5]  R895      0.415558785200119
    z[4,0,5]  R896      1.5356499701738358e-02
    z[4,0,5]  R897      -4.3897899985313416e-01
    z[4,0,5]  R898      5.1259106397628784e-01
    z[4,0,5]  R899      -0.0826454684138298
    z[4,0,5]  R900      -2.8129890561103821e-01
    z[4,0,5]  R901      3.9669489860534668e-01
    z[4,0,5]  R902      1.5606077015399933e-01
    z[4,0,5]  R903      -2.8040561079978943e-01
    z[4,0,5]  R904      1.8205150961875916e-01
    z[4,0,5]  R905      3.0326387286186218e-01
    z[4,0,5]  R906      0.228912353515625
    z[4,0,5]  R907      -2.2774764802306890e-03
    z[4,0,5]  R908      -3.2953587174415588e-01
    z[4,0,5]  R909      3.3728504180908203e-01
    z[4,0,5]  R910      -3.2062929123640060e-02
    z[4,0,5]  R911      -6.0443345457315445e-02
    z[4,0,5]  R912      2.9518043994903564e-01
    z[4,0,5]  R913      5.5045560002326965e-03
    z[4,0,5]  R914      -2.9020276665687561e-01
    z[4,0,5]  R915      -8.4798950701951981e-03
    z[4,0,5]  R916      6.6874980926513672e-02
    z[4,0,5]  R917      3.9979156851768494e-01
    z[4,0,5]  R918      0.0141511932015419
    z[4,0,5]  R919      2.4028590321540833e-01
    z[4,0,5]  R920      1.4296466112136841e-01
    z[4,0,5]  R921      5.2013820409774780e-01
    z[4,0,5]  R922      0.362602174282074
    z[4,0,5]  R923      -7.0562714338302612e-01
    z[4,0,5]  R924      -7.6083153486251831e-01
    z[4,0,5]  R925      -2.5893664360046387e-01
    z[4,0,5]  R926      3.4961634874343872e-01
    z[4,0,5]  R927      9.2065773904323578e-02
    z[4,0,5]  R928      0.290505051612854
    z[4,0,5]  R929      -4.6628376841545105e-01
    z[4,0,5]  R930      1.5312932431697845e-01
    z[4,0,5]  R931      -0.0842769518494606
    z[4,0,5]  R932      -3.5723760724067688e-01
    z[4,0,5]  R933      2.9243400692939758e-01
    z[4,0,5]  R934      5.2723549306392670e-02
    z[4,0,5]  R935      -6.9054342806339264e-02
    z[4,0,5]  R936      2.2902987897396088e-01
    z[4,0,5]  R937      -1.7587022483348846e-01
    z[4,0,5]  R938      -4.3951058387756348e-01
    z[4,0,5]  R939      -2.1963946521282196e-01
    z[4,0,5]  R940      -1.4680349826812744e-01
    z[4,0,5]  R941      3.5559117794036865e-01
    z[4,0,5]  R942      3.3225327730178833e-01
    z[4,0,5]  R943      -2.2312594950199127e-01
    z[4,0,5]  R944      -6.6104239225387573e-01
    z[4,0,5]  R945      -1.3015256822109222e-01
    z[4,0,5]  R946      -4.3054780364036560e-01
    z[4,0,5]  R947      -3.3977288007736206e-01
    z[4,0,5]  R948      2.9494670033454895e-01
    z[4,0,5]  R949      1.3274885714054108e-01
    z[4,0,5]  R950      2.7714800834655762e-01
    z[4,0,5]  R951      3.0091580748558044e-01
    z[4,0,5]  R952      -1.7766192555427551e-01
    z[4,0,5]  R953      2.3864848911762238e-01
    z[4,0,5]  R954      1.3339985907077789e-01
    z[4,0,5]  R955      -4.2681032419204712e-01
    z[4,0,5]  R956      4.8897233605384827e-01
    z[4,0,5]  R957      1.4568093419075012e-01
    z[4,0,5]  R958      -6.9919861853122711e-02
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R851      -1
    z[4,0,6]  R852      1
    z[4,0,6]  R853      1.8097130954265594e-01
    z[4,0,6]  R854      -1.7782452702522278e-01
    z[4,0,6]  R855      -1.4426478743553162e-01
    z[4,0,6]  R856      -2.8533586859703064e-01
    z[4,0,6]  R857      3.1594879925251007e-02
    z[4,0,6]  R858      4.7426262497901917e-01
    z[4,0,6]  R859      -3.9861583709716797e-01
    z[4,0,6]  R860      6.9473057985305786e-02
    z[4,0,6]  R861      2.2498293220996857e-01
    z[4,0,6]  R862      -3.6225235089659691e-03
    z[4,0,6]  R863      5.5946122854948044e-02
    z[4,0,6]  R864      6.2424574047327042e-02
    z[4,0,6]  R865      3.7235689163208008e-01
    z[4,0,6]  R866      -0.0879029706120491
    z[4,0,6]  R867      0.311167448759079
    z[4,0,6]  R868      1.9222594797611237e-01
    z[4,0,6]  R869      3.1428948044776917e-02
    z[4,0,6]  R870      -1.2347525358200073e-01
    z[4,0,6]  R871      2.1435044705867767e-01
    z[4,0,6]  R872      6.4815111458301544e-02
    z[4,0,6]  R873      7.9461887478828430e-02
    z[4,0,6]  R874      -5.0881922245025635e-02
    z[4,0,6]  R875      1.9700525701045990e-01
    z[4,0,6]  R876      -1.4722093008458614e-02
    z[4,0,6]  R877      2.7972161769866943e-01
    z[4,0,6]  R878      -1.4217411167919636e-02
    z[4,0,6]  R879      -3.7718974053859711e-02
    z[4,0,6]  R880      -2.4991898238658905e-01
    z[4,0,6]  R881      3.0058425664901733e-01
    z[4,0,6]  R882      3.0824345350265503e-01
    z[4,0,6]  R883      8.1671245396137238e-02
    z[4,0,6]  R884      1.1477380245923996e-01
    z[4,0,6]  R885      1.0683772154152393e-02
    z[4,0,6]  R886      -1.5544918179512024e-01
    z[4,0,6]  R887      4.9034300446510315e-01
    z[4,0,6]  R888      -1.8377602100372314e-01
    z[4,0,6]  R889      -0.37274369597435
    z[4,0,6]  R890      1.5977036207914352e-02
    z[4,0,6]  R891      1.6093797981739044e-01
    z[4,0,6]  R892      4.3478954583406448e-02
    z[4,0,6]  R893      -1.6550987958908081e-01
    z[4,0,6]  R894      -7.1623444557189941e-02
    z[4,0,6]  R895      -2.7719438076019287e-01
    z[4,0,6]  R896      -1.8942917883396149e-01
    z[4,0,6]  R897      0.43539959192276
    z[4,0,6]  R898      2.8288811445236206e-01
    z[4,0,6]  R899      -3.3108890056610107e-01
    z[4,0,6]  R900      2.4633076041936874e-02
    z[4,0,6]  R901      1.7295395955443382e-02
    z[4,0,6]  R902      5.9470415115356445e-02
    z[4,0,6]  R903      2.6722386479377747e-01
    z[4,0,6]  R904      -1.2938253581523895e-01
    z[4,0,6]  R905      1.0591533035039902e-01
    z[4,0,6]  R906      -1.6675411164760590e-01
    z[4,0,6]  R907      -1.0583539307117462e-01
    z[4,0,6]  R908      2.2988523542881012e-01
    z[4,0,6]  R909      -7.8124955296516418e-02
    z[4,0,6]  R910      -3.4003564715385437e-01
    z[4,0,6]  R911      -2.0062687993049622e-01
    z[4,0,6]  R912      -1.7484804987907410e-01
    z[4,0,6]  R913      -1.8011310696601868e-01
    z[4,0,6]  R914      -2.2598819434642792e-01
    z[4,0,6]  R915      2.5719873607158661e-02
    z[4,0,6]  R916      -8.3407811820507050e-02
    z[4,0,6]  R917      2.7665841579437256e-01
    z[4,0,6]  R918      2.1546630561351776e-01
    z[4,0,6]  R919      -1.9060879945755005e-01
    z[4,0,6]  R920      1.4744338393211365e-01
    z[4,0,6]  R921      1.7841245234012604e-01
    z[4,0,6]  R922      1.9542181491851807e-01
    z[4,0,6]  R923      3.0342981219291687e-01
    z[4,0,6]  R924      1.4042806625366211e-01
    z[4,0,6]  R925      5.1081973314285278e-01
    z[4,0,6]  R926      4.2690034955739975e-02
    z[4,0,6]  R927      4.5900359749794006e-01
    z[4,0,6]  R928      6.2206890434026718e-02
    z[4,0,6]  R929      1.7906057834625244e-01
    z[4,0,6]  R930      -1.8205833435058594e-01
    z[4,0,6]  R931      -8.5641875863075256e-02
    z[4,0,6]  R932      5.5052293464541435e-03
    z[4,0,6]  R933      2.7318498492240906e-01
    z[4,0,6]  R934      9.1474344953894615e-03
    z[4,0,6]  R935      1.3312149047851562e-01
    z[4,0,6]  R936      -1.0616851598024368e-01
    z[4,0,6]  R937      -1.2419880181550980e-01
    z[4,0,6]  R938      -1.3380878372117877e-03
    z[4,0,6]  R939      -8.7297163903713226e-02
    z[4,0,6]  R940      2.3277722299098969e-01
    z[4,0,6]  R941      1.1558146029710770e-01
    z[4,0,6]  R942      -0.0084022656083107
    z[4,0,6]  R943      4.3134069442749023e-01
    z[4,0,6]  R944      2.4139201641082764e-01
    z[4,0,6]  R945      3.5985150933265686e-01
    z[4,0,6]  R946      0.335778146982193
    z[4,0,6]  R947      -0.361446738243103
    z[4,0,6]  R948      2.3352560400962830e-01
    z[4,0,6]  R949      4.9750655889511108e-02
    z[4,0,6]  R950      -1.0317817330360413e-01
    z[4,0,6]  R951      -1.2786078453063965e-01
    z[4,0,6]  R952      -2.5190016627311707e-01
    z[4,0,6]  R953      -2.3922783136367798e-01
    z[4,0,6]  R954      5.5657601356506348e-01
    z[4,0,6]  R955      -3.3673766255378723e-01
    z[4,0,6]  R956      0.323076069355011
    z[4,0,6]  R957      -1.0856927372515202e-02
    z[4,0,6]  R958      -1.5177269279956818e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R1063     -1
    z[1,2,0]  R1064     1
    z[1,2,0]  R1077     -2.7622032165527344e-01
    z[1,2,0]  R1078     7.2170570492744446e-02
    z[1,2,0]  R1079     -2.1570110321044922e-01
    z[1,2,0]  R1080     -1.9471928477287292e-01
    z[1,2,0]  R1081     1.9177286326885223e-01
    z[1,2,0]  R1082     -9.2172406613826752e-02
    z[1,2,0]  R1083     -2.2240076959133148e-01
    z[1,2,0]  R1084     -1.5014803968369961e-02
    z[1,2,0]  R1085     7.7013963460922241e-01
    z[1,2,0]  R1086     3.6218479275703430e-01
    z[1,2,0]  R1087     -9.2576093971729279e-02
    z[1,2,0]  R1088     -6.1049032211303711e-01
    z[1,2,0]  R1089     2.5484472513198853e-01
    z[1,2,0]  R1090     5.2137277089059353e-03
    z[1,2,0]  R1091     -0.604136049747467
    z[1,2,0]  R1092     -8.2193642854690552e-01
    z[1,2,0]  R1093     0.663940966129303
    z[1,2,0]  R1094     4.0393376350402832e-01
    z[1,2,0]  R1095     -2.0123668015003204e-01
    z[1,2,0]  R1096     -3.8823267817497253e-01
    z[1,2,0]  R1097     -2.7819445729255676e-01
    z[1,2,0]  R1098     -1.8396872282028198e-01
    z[1,2,0]  R1099     -0.406222403049469
    z[1,2,0]  R1100     -1.1003332585096359e-01
    z[1,2,0]  R1101     -9.8708763718605042e-02
    z[1,2,0]  R1102     4.4714215397834778e-01
    z[1,2,0]  R1103     -3.8053756952285767e-01
    z[1,2,0]  R1104     2.1977389231324196e-02
    z[1,2,0]  R1105     -1.4427816867828369e-01
    z[1,2,0]  R1106     8.8784933090209961e-01
    z[1,2,0]  R1107     -1.9358487427234650e-01
    z[1,2,0]  R1108     -2.9861995577812195e-01
    z[1,2,0]  R1109     -2.8213111683726311e-02
    z[1,2,0]  R1110     1.6459727287292480e-01
    z[1,2,0]  R1111     3.3137798309326172e-01
    z[1,2,0]  R1112     2.3689137399196625e-01
    z[1,2,0]  R1113     -2.9080209136009216e-01
    z[1,2,0]  R1114     -5.5311852693557739e-01
    z[1,2,0]  R1115     5.9021119959652424e-03
    z[1,2,0]  R1116     5.5397635698318481e-01
    z[1,2,0]  R1117     1.1108215898275375e-01
    z[1,2,0]  R1118     -3.1310665607452393e-01
    z[1,2,0]  R1119     0.181345596909523
    z[1,2,0]  R1120     -9.9855475127696991e-02
    z[1,2,0]  R1121     -4.7264367341995239e-01
    z[1,2,0]  R1122     1.7552487552165985e-01
    z[1,2,0]  R1123     1.1585873365402222e-01
    z[1,2,0]  R1124     2.7301779389381409e-01
    z[1,2,0]  R1125     3.6947306990623474e-01
    z[1,2,0]  R1126     1.2942981719970703e-01
    z[1,2,0]  R1127     1.4334422349929810e-01
    z[1,2,0]  R1128     -2.0050154998898506e-03
    z[1,2,0]  R1129     -3.4409871697425842e-01
    z[1,2,0]  R1130     -0.0753057599067688
    z[1,2,0]  R1131     -4.1856479644775391e-01
    z[1,2,0]  R1132     -5.2887761592864990e-01
    z[1,2,0]  R1133     3.8372308015823364e-01
    z[1,2,0]  R1134     1.8392139673233032e-01
    z[1,2,0]  R1135     0.756458580493927
    z[1,2,0]  R1136     4.1215223073959351e-01
    z[1,2,0]  R1137     -2.9381206259131432e-02
    z[1,2,0]  R1138     -1.9953933358192444e-01
    z[1,2,0]  R1139     0.0612550750374794
    z[1,2,0]  R1140     -5.5652207136154175e-01
    z[1,2,0]  R1141     2.4315534532070160e-01
    z[1,2,0]  R1142     8.9159369468688965e-01
    z[1,2,0]  R1143     8.5959982872009277e-01
    z[1,2,0]  R1144     8.3808708190917969e-01
    z[1,2,0]  R1145     8.2671457529067993e-01
    z[1,2,0]  R1146     8.2864439487457275e-01
    z[1,2,0]  R1147     0.443828284740448
    z[1,2,0]  R1148     0.596022367477417
    z[1,2,0]  R1149     5.8625990152359009e-01
    z[1,2,0]  R1150     4.5706677436828613e-01
    z[1,2,0]  R1151     2.2589190304279327e-01
    z[1,2,0]  R1152     3.8704875111579895e-01
    z[1,2,0]  R1153     3.0130943655967712e-01
    z[1,2,0]  R1154     5.8022117614746094e-01
    z[1,2,0]  R1155     0.547103226184845
    z[1,2,0]  R1156     -1.9522064924240112e-01
    z[1,2,0]  R1157     -5.9889388084411621e-01
    z[1,2,0]  R1158     -5.5948734283447266e-01
    z[1,2,0]  R1159     -7.2994542121887207e-01
    z[1,2,0]  R1160     -4.2817932367324829e-01
    z[1,2,0]  R1161     -7.4910598993301392e-01
    z[1,2,0]  R1162     -4.0614092350006104e-01
    z[1,2,0]  R1163     -5.9933245182037354e-01
    z[1,2,0]  R1164     -3.8821491599082947e-01
    z[1,2,0]  R1165     -2.6076626777648926e-01
    z[1,2,0]  R1166     -4.7347363829612732e-01
    z[1,2,0]  R1167     -1.8241828307509422e-02
    z[1,2,0]  R1168     3.5420483350753784e-01
    z[1,2,0]  R1169     -3.4724938869476318e-01
    z[1,2,0]  R1170     -0.0746384710073471
    z[1,2,0]  R1171     2.0175845921039581e-01
    z[1,2,0]  R1172     -1.2036658078432083e-01
    z[1,2,0]  R1173     -1.1681912094354630e-01
    z[1,2,0]  R1174     2.6472198963165283e-01
    z[1,2,0]  R1175     -6.0214199125766754e-02
    z[1,2,0]  R1176     -1.1675311252474785e-02
    z[1,2,0]  R1177     -3.9184695482254028e-01
    z[1,2,0]  R1178     -0.439421683549881
    z[1,2,0]  R1179     -0.185368150472641
    z[1,2,0]  R1180     -1.0790064185857773e-01
    z[1,2,0]  R1181     -5.3795784711837769e-01
    z[1,2,0]  R1182     -3.2538771629333496e-01
    z[1,2,0]  R1183     8.3735115826129913e-02
    z[1,2,0]  R1184     -4.8598015308380127e-01
    z[1,2,0]  R1185     -4.9811840057373047e-01
    z[1,2,0]  R1186     -0.307282954454422
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R1065     -1
    z[1,2,1]  R1066     1
    z[1,2,1]  R1077     5.7023260742425919e-02
    z[1,2,1]  R1078     -4.0100085735321045e-01
    z[1,2,1]  R1079     -4.0556874871253967e-01
    z[1,2,1]  R1080     -4.6332615613937378e-01
    z[1,2,1]  R1081     -2.3702657222747803e-01
    z[1,2,1]  R1082     2.2285167872905731e-01
    z[1,2,1]  R1083     2.9661893844604492e-01
    z[1,2,1]  R1084     -3.8518407940864563e-01
    z[1,2,1]  R1085     9.2216655611991882e-02
    z[1,2,1]  R1086     -3.6164233088493347e-01
    z[1,2,1]  R1087     -6.8206888437271118e-01
    z[1,2,1]  R1088     -5.1864419132471085e-02
    z[1,2,1]  R1089     -5.4454110562801361e-02
    z[1,2,1]  R1090     0.0367298349738121
    z[1,2,1]  R1091     -3.0298924073576927e-02
    z[1,2,1]  R1092     6.8774081766605377e-02
    z[1,2,1]  R1093     1.3289210200309753e-01
    z[1,2,1]  R1094     -1.5048886835575104e-01
    z[1,2,1]  R1095     -2.6078957319259644e-01
    z[1,2,1]  R1096     3.0239865183830261e-01
    z[1,2,1]  R1097     -3.2169643044471741e-01
    z[1,2,1]  R1098     3.1752693653106689e-01
    z[1,2,1]  R1099     -2.7491134405136108e-01
    z[1,2,1]  R1100     -2.0878896117210388e-01
    z[1,2,1]  R1101     -4.4018852710723877e-01
    z[1,2,1]  R1102     -1.1904118955135345e-01
    z[1,2,1]  R1103     3.8342788815498352e-01
    z[1,2,1]  R1104     7.4422186613082886e-01
    z[1,2,1]  R1105     -2.3468953371047974e-01
    z[1,2,1]  R1106     0.400115966796875
    z[1,2,1]  R1107     -1.1934275925159454e-01
    z[1,2,1]  R1108     6.0335206799209118e-03
    z[1,2,1]  R1109     2.9801445081830025e-02
    z[1,2,1]  R1110     3.9609622955322266e-01
    z[1,2,1]  R1111     0.460801899433136
    z[1,2,1]  R1112     -4.2347031831741333e-01
    z[1,2,1]  R1113     5.9909218549728394e-01
    z[1,2,1]  R1114     -2.5118863582611084e-01
    z[1,2,1]  R1115     -4.5285689830780029e-01
    z[1,2,1]  R1116     2.9667595028877258e-01
    z[1,2,1]  R1117     -4.4780600070953369e-01
    z[1,2,1]  R1118     0.479547381401062
    z[1,2,1]  R1119     -1.1395521461963654e-01
    z[1,2,1]  R1120     5.7864004373550415e-01
    z[1,2,1]  R1121     -2.3511280119419098e-01
    z[1,2,1]  R1122     3.3842352032661438e-01
    z[1,2,1]  R1123     -6.4883500337600708e-01
    z[1,2,1]  R1124     -5.0559818744659424e-01
    z[1,2,1]  R1125     0.500224769115448
    z[1,2,1]  R1126     -1.5252690762281418e-02
    z[1,2,1]  R1127     2.0094932615756989e-01
    z[1,2,1]  R1128     -4.3286976218223572e-01
    z[1,2,1]  R1129     3.8947391510009766e-01
    z[1,2,1]  R1130     4.8887810111045837e-01
    z[1,2,1]  R1131     -1.6817826032638550e-01
    z[1,2,1]  R1132     -1.7984431982040405e-01
    z[1,2,1]  R1133     1.6541364789009094e-01
    z[1,2,1]  R1134     8.7534934282302856e-02
    z[1,2,1]  R1135     1.3398897647857666e-01
    z[1,2,1]  R1136     -3.3120420575141907e-01
    z[1,2,1]  R1137     3.9884641766548157e-01
    z[1,2,1]  R1138     4.5949053764343262e-01
    z[1,2,1]  R1139     1.0078227519989014e-01
    z[1,2,1]  R1140     2.0944228395819664e-02
    z[1,2,1]  R1141     -4.8049259185791016e-01
    z[1,2,1]  R1142     3.4001204371452332e-01
    z[1,2,1]  R1143     2.5614374876022339e-01
    z[1,2,1]  R1144     0.4011210501194
    z[1,2,1]  R1145     3.2489171624183655e-01
    z[1,2,1]  R1146     2.7052381634712219e-01
    z[1,2,1]  R1147     2.3911124467849731e-01
    z[1,2,1]  R1148     1.0747678577899933e-01
    z[1,2,1]  R1149     9.9074125289916992e-02
    z[1,2,1]  R1150     2.6177468895912170e-01
    z[1,2,1]  R1151     2.9460325837135315e-01
    z[1,2,1]  R1152     3.5361862182617188e-01
    z[1,2,1]  R1153     3.4898763895034790e-01
    z[1,2,1]  R1154     4.8065102100372314e-01
    z[1,2,1]  R1155     2.5980255007743835e-01
    z[1,2,1]  R1156     -8.5558688640594482e-01
    z[1,2,1]  R1157     -8.5406258702278137e-02
    z[1,2,1]  R1158     -4.2828482389450073e-01
    z[1,2,1]  R1159     -4.5273122191429138e-01
    z[1,2,1]  R1160     -1.1212576180696487e-01
    z[1,2,1]  R1161     -3.8804542273283005e-03
    z[1,2,1]  R1162     -3.9136001467704773e-01
    z[1,2,1]  R1163     1.3638220727443695e-01
    z[1,2,1]  R1164     -8.1791423261165619e-02
    z[1,2,1]  R1165     -9.3317642807960510e-02
    z[1,2,1]  R1166     1.5056781470775604e-01
    z[1,2,1]  R1167     -5.1217317581176758e-01
    z[1,2,1]  R1168     -1.7223972082138062e-01
    z[1,2,1]  R1169     -2.8673630952835083e-01
    z[1,2,1]  R1170     -0.224474236369133
    z[1,2,1]  R1171     -9.3072272837162018e-02
    z[1,2,1]  R1172     -1.6432899236679077e-01
    z[1,2,1]  R1173     1.0145115852355957e-01
    z[1,2,1]  R1174     -2.4835982918739319e-01
    z[1,2,1]  R1175     -5.6369885802268982e-02
    z[1,2,1]  R1176     5.9535884857177734e-01
    z[1,2,1]  R1177     4.0345042943954468e-02
    z[1,2,1]  R1178     -4.2288365960121155e-01
    z[1,2,1]  R1179     -5.5005472898483276e-01
    z[1,2,1]  R1180     2.0386627316474915e-01
    z[1,2,1]  R1181     4.4791221618652344e-02
    z[1,2,1]  R1182     3.4200098365545273e-02
    z[1,2,1]  R1183     6.9640129804611206e-01
    z[1,2,1]  R1184     8.0537945032119751e-01
    z[1,2,1]  R1185     -2.2044022381305695e-01
    z[1,2,1]  R1186     8.9695996046066284e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R1067     -1
    z[1,2,2]  R1068     1
    z[1,2,2]  R1077     5.7882523536682129e-01
    z[1,2,2]  R1078     4.1696330904960632e-01
    z[1,2,2]  R1079     5.1958316564559937e-01
    z[1,2,2]  R1080     5.7546877861022949e-01
    z[1,2,2]  R1081     2.1274326741695404e-01
    z[1,2,2]  R1082     7.5553268194198608e-01
    z[1,2,2]  R1083     4.0897557139396667e-01
    z[1,2,2]  R1084     9.6684433519840240e-03
    z[1,2,2]  R1085     -3.0653487890958786e-02
    z[1,2,2]  R1086     7.4481427669525146e-02
    z[1,2,2]  R1087     -4.2489755153656006e-01
    z[1,2,2]  R1088     -2.0523147657513618e-02
    z[1,2,2]  R1089     -3.4373795986175537e-01
    z[1,2,2]  R1090     9.5099993050098419e-02
    z[1,2,2]  R1091     -2.2712003439664841e-02
    z[1,2,2]  R1092     2.0225118845701218e-02
    z[1,2,2]  R1093     -8.4506928920745850e-02
    z[1,2,2]  R1094     -1.7085234820842743e-01
    z[1,2,2]  R1095     -9.8722055554389954e-02
    z[1,2,2]  R1096     -1.4519126713275909e-01
    z[1,2,2]  R1097     -2.3931415379047394e-01
    z[1,2,2]  R1098     -3.5749744623899460e-02
    z[1,2,2]  R1099     4.3033313751220703e-01
    z[1,2,2]  R1100     2.3229060694575310e-02
    z[1,2,2]  R1101     -6.8220630288124084e-02
    z[1,2,2]  R1102     -2.4715360999107361e-01
    z[1,2,2]  R1103     3.8568194955587387e-02
    z[1,2,2]  R1104     3.6008810997009277e-01
    z[1,2,2]  R1105     1.1655066907405853e-01
    z[1,2,2]  R1106     -1.4073415659368038e-02
    z[1,2,2]  R1107     3.5025379620492458e-03
    z[1,2,2]  R1108     2.5871858000755310e-01
    z[1,2,2]  R1109     5.0503186881542206e-02
    z[1,2,2]  R1110     -1.9696229696273804e-01
    z[1,2,2]  R1111     1.0958162695169449e-01
    z[1,2,2]  R1112     -3.6883754655718803e-03
    z[1,2,2]  R1113     8.8690489530563354e-02
    z[1,2,2]  R1114     9.6120364964008331e-02
    z[1,2,2]  R1115     2.3620733618736267e-01
    z[1,2,2]  R1116     -8.8324621319770813e-02
    z[1,2,2]  R1117     -4.0031763911247253e-01
    z[1,2,2]  R1118     1.7647184431552887e-01
    z[1,2,2]  R1119     2.7075189352035522e-01
    z[1,2,2]  R1120     5.7719075679779053e-01
    z[1,2,2]  R1121     8.3714880049228668e-02
    z[1,2,2]  R1122     -2.6952880620956421e-01
    z[1,2,2]  R1123     1.6323316097259521e-01
    z[1,2,2]  R1124     -2.3205693066120148e-01
    z[1,2,2]  R1125     7.0322789251804352e-02
    z[1,2,2]  R1126     6.2086915969848633e-01
    z[1,2,2]  R1127     2.3653939366340637e-02
    z[1,2,2]  R1128     -2.4569955468177795e-01
    z[1,2,2]  R1129     3.2196617126464844e-01
    z[1,2,2]  R1130     4.1821566224098206e-01
    z[1,2,2]  R1131     3.5133041441440582e-02
    z[1,2,2]  R1132     -1.4320272952318192e-02
    z[1,2,2]  R1133     1.5297865867614746e-01
    z[1,2,2]  R1134     6.3117647171020508e-01
    z[1,2,2]  R1135     -1.8626330420374870e-02
    z[1,2,2]  R1136     -3.0767264962196350e-01
    z[1,2,2]  R1137     2.6093924045562744e-01
    z[1,2,2]  R1138     3.9941665530204773e-01
    z[1,2,2]  R1139     -2.3553118109703064e-01
    z[1,2,2]  R1140     -6.9350576959550381e-03
    z[1,2,2]  R1141     1.9941753149032593e-01
    z[1,2,2]  R1142     2.5417020916938782e-01
    z[1,2,2]  R1143     -2.1761699020862579e-01
    z[1,2,2]  R1144     6.5196588635444641e-02
    z[1,2,2]  R1145     -3.3122289180755615e-01
    z[1,2,2]  R1146     -3.2163041830062866e-01
    z[1,2,2]  R1147     7.6214402914047241e-01
    z[1,2,2]  R1148     6.6670817136764526e-01
    z[1,2,2]  R1149     4.9157905578613281e-01
    z[1,2,2]  R1150     6.5431642532348633e-01
    z[1,2,2]  R1151     5.9676152467727661e-01
    z[1,2,2]  R1152     2.5834500789642334e-01
    z[1,2,2]  R1153     5.4126840829849243e-01
    z[1,2,2]  R1154     2.7784049510955811e-01
    z[1,2,2]  R1155     4.7331610321998596e-01
    z[1,2,2]  R1156     -2.9964751005172729e-01
    z[1,2,2]  R1157     -6.2315952777862549e-01
    z[1,2,2]  R1158     -4.5713719725608826e-01
    z[1,2,2]  R1159     -4.9130564928054810e-01
    z[1,2,2]  R1160     -5.4274529218673706e-01
    z[1,2,2]  R1161     -5.8590775728225708e-01
    z[1,2,2]  R1162     -6.0285305976867676e-01
    z[1,2,2]  R1163     -4.5472463965415955e-01
    z[1,2,2]  R1164     -4.4478836655616760e-01
    z[1,2,2]  R1165     -6.2860614061355591e-01
    z[1,2,2]  R1166     -4.3422549962997437e-01
    z[1,2,2]  R1167     -5.4368627071380615e-01
    z[1,2,2]  R1168     4.5820564031600952e-01
    z[1,2,2]  R1169     -2.3959949612617493e-01
    z[1,2,2]  R1170     -1.8490347266197205e-01
    z[1,2,2]  R1171     7.0345804095268250e-02
    z[1,2,2]  R1172     5.7068395614624023e-01
    z[1,2,2]  R1173     1.6660247743129730e-01
    z[1,2,2]  R1174     -4.9605220556259155e-02
    z[1,2,2]  R1175     1.3281117379665375e-01
    z[1,2,2]  R1176     1.6671356558799744e-01
    z[1,2,2]  R1177     -7.1254062652587891e-01
    z[1,2,2]  R1178     -4.4756001234054565e-01
    z[1,2,2]  R1179     -6.0772401094436646e-01
    z[1,2,2]  R1180     3.6574136465787888e-02
    z[1,2,2]  R1181     1.7348611354827881e-01
    z[1,2,2]  R1182     -3.8892120122909546e-02
    z[1,2,2]  R1183     8.6048319935798645e-02
    z[1,2,2]  R1184     5.2002891898155212e-02
    z[1,2,2]  R1185     2.6664009690284729e-01
    z[1,2,2]  R1186     -8.1974111497402191e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R1069     -1
    z[1,2,3]  R1070     1
    z[1,2,3]  R1077     -2.8136521577835083e-01
    z[1,2,3]  R1078     -5.2662551403045654e-01
    z[1,2,3]  R1079     -6.1233186721801758e-01
    z[1,2,3]  R1080     -3.1960594654083252e-01
    z[1,2,3]  R1081     -4.3368527293205261e-01
    z[1,2,3]  R1082     -5.1076197624206543e-01
    z[1,2,3]  R1083     -8.0525797605514526e-01
    z[1,2,3]  R1084     -5.2254360914230347e-01
    z[1,2,3]  R1085     -4.2296999692916870e-01
    z[1,2,3]  R1086     4.8478193581104279e-02
    z[1,2,3]  R1087     -1.8497726321220398e-01
    z[1,2,3]  R1088     7.9207018017768860e-02
    z[1,2,3]  R1089     3.8945192098617554e-01
    z[1,2,3]  R1090     0.422821044921875
    z[1,2,3]  R1091     -2.8210881352424622e-01
    z[1,2,3]  R1092     -1.1807091534137726e-01
    z[1,2,3]  R1093     3.5757082700729370e-01
    z[1,2,3]  R1094     3.3467337489128113e-01
    z[1,2,3]  R1095     2.5352901220321655e-01
    z[1,2,3]  R1096     3.3100441098213196e-01
    z[1,2,3]  R1097     -5.6162250041961670e-01
    z[1,2,3]  R1098     5.2022719383239746e-01
    z[1,2,3]  R1099     5.4889374971389771e-01
    z[1,2,3]  R1100     4.7716978192329407e-01
    z[1,2,3]  R1101     -3.4345608949661255e-01
    z[1,2,3]  R1102     3.9964485168457031e-01
    z[1,2,3]  R1103     3.8020107150077820e-01
    z[1,2,3]  R1104     3.6080777645111084e-01
    z[1,2,3]  R1105     3.6020430922508240e-01
    z[1,2,3]  R1106     1.0170537978410721e-01
    z[1,2,3]  R1107     -0.731119692325592
    z[1,2,3]  R1108     5.0512790679931641e-01
    z[1,2,3]  R1109     4.7510275244712830e-01
    z[1,2,3]  R1110     4.7052279114723206e-01
    z[1,2,3]  R1111     4.8424473404884338e-01
    z[1,2,3]  R1112     4.5583185553550720e-01
    z[1,2,3]  R1113     4.4839361310005188e-01
    z[1,2,3]  R1114     4.3676459789276123e-01
    z[1,2,3]  R1115     4.2668148875236511e-01
    z[1,2,3]  R1116     4.2736229300498962e-01
    z[1,2,3]  R1117     -7.1151775121688843e-01
    z[1,2,3]  R1118     5.5927473306655884e-01
    z[1,2,3]  R1119     5.3567820787429810e-01
    z[1,2,3]  R1120     0.525505781173706
    z[1,2,3]  R1121     4.9212706089019775e-01
    z[1,2,3]  R1122     4.8334461450576782e-01
    z[1,2,3]  R1123     4.8629650473594666e-01
    z[1,2,3]  R1124     4.3330281972885132e-01
    z[1,2,3]  R1125     4.1259589791297913e-01
    z[1,2,3]  R1126     4.3963640928268433e-01
    z[1,2,3]  R1127     0.805002748966217
    z[1,2,3]  R1128     -7.4258393049240112e-01
    z[1,2,3]  R1129     6.9236713647842407e-01
    z[1,2,3]  R1130     6.2224221229553223e-01
    z[1,2,3]  R1131     5.1679807901382446e-01
    z[1,2,3]  R1132     -5.6394052505493164e-01
    z[1,2,3]  R1133     0.447330117225647
    z[1,2,3]  R1134     4.2527988553047180e-01
    z[1,2,3]  R1135     4.0102961659431458e-01
    z[1,2,3]  R1136     3.7532398104667664e-01
    z[1,2,3]  R1137     -5.9658187627792358e-01
    z[1,2,3]  R1138     6.4064908027648926e-01
    z[1,2,3]  R1139     5.1169615983963013e-01
    z[1,2,3]  R1140     -3.3814874291419983e-01
    z[1,2,3]  R1141     5.0888514518737793e-01
    z[1,2,3]  R1142     -5.9023287147283554e-02
    z[1,2,3]  R1143     -2.7531739324331284e-02
    z[1,2,3]  R1144     -2.9218414425849915e-01
    z[1,2,3]  R1145     -2.6991435885429382e-01
    z[1,2,3]  R1146     -9.8402373492717743e-02
    z[1,2,3]  R1147     -1.3017807900905609e-01
    z[1,2,3]  R1148     -4.1541284322738647e-01
    z[1,2,3]  R1149     -5.3775084018707275e-01
    z[1,2,3]  R1150     -2.1474617719650269e-01
    z[1,2,3]  R1151     -6.2661296129226685e-01
    z[1,2,3]  R1152     -7.4903172254562378e-01
    z[1,2,3]  R1153     -6.2439376115798950e-01
    z[1,2,3]  R1154     -5.8437591791152954e-01
    z[1,2,3]  R1155     -1.6673199832439423e-01
    z[1,2,3]  R1156     -1.1684054881334305e-01
    z[1,2,3]  R1157     -1.6926182806491852e-01
    z[1,2,3]  R1158     3.2364353537559509e-01
    z[1,2,3]  R1159     -1.0207553952932358e-01
    z[1,2,3]  R1160     4.0911316871643066e-01
    z[1,2,3]  R1161     1.8863391876220703e-01
    z[1,2,3]  R1162     2.4182501435279846e-01
    z[1,2,3]  R1163     3.3136495947837830e-01
    z[1,2,3]  R1164     4.2438396811485291e-01
    z[1,2,3]  R1165     1.3828664086759090e-02
    z[1,2,3]  R1166     1.9436357915401459e-01
    z[1,2,3]  R1167     -1.8136920034885406e-01
    z[1,2,3]  R1168     7.9428905248641968e-01
    z[1,2,3]  R1169     -2.1760773658752441e-01
    z[1,2,3]  R1170     -1.7980632185935974e-01
    z[1,2,3]  R1171     8.1366300582885742e-01
    z[1,2,3]  R1172     5.4640734195709229e-01
    z[1,2,3]  R1173     4.6961575746536255e-01
    z[1,2,3]  R1174     4.2552584409713745e-01
    z[1,2,3]  R1175     3.7509584426879883e-01
    z[1,2,3]  R1176     6.2250560522079468e-01
    z[1,2,3]  R1177     -6.3955806195735931e-02
    z[1,2,3]  R1178     -1.2864026427268982e-01
    z[1,2,3]  R1179     -3.7321120500564575e-01
    z[1,2,3]  R1180     7.0065855979919434e-01
    z[1,2,3]  R1181     6.0737454891204834e-01
    z[1,2,3]  R1182     4.0486183762550354e-01
    z[1,2,3]  R1183     0.525330126285553
    z[1,2,3]  R1184     1.1478332430124283e-01
    z[1,2,3]  R1185     4.6427825093269348e-01
    z[1,2,3]  R1186     1.0086484998464584e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R1071     -1
    z[1,2,4]  R1072     1
    z[1,2,4]  R1077     6.0072422027587891e-01
    z[1,2,4]  R1078     2.4796561896800995e-01
    z[1,2,4]  R1079     2.6029223203659058e-01
    z[1,2,4]  R1080     3.1332916021347046e-01
    z[1,2,4]  R1081     2.6376459002494812e-01
    z[1,2,4]  R1082     -2.0386783778667450e-01
    z[1,2,4]  R1083     3.7150572985410690e-02
    z[1,2,4]  R1084     -7.5935405492782593e-01
    z[1,2,4]  R1085     -0.399393767118454
    z[1,2,4]  R1086     -7.1339696645736694e-01
    z[1,2,4]  R1087     4.7217461466789246e-01
    z[1,2,4]  R1088     -3.1844952702522278e-01
    z[1,2,4]  R1089     8.1103682518005371e-01
    z[1,2,4]  R1090     -7.1264576911926270e-01
    z[1,2,4]  R1091     -4.0418615937232971e-01
    z[1,2,4]  R1092     -1.7569592595100403e-01
    z[1,2,4]  R1093     5.8281880617141724e-01
    z[1,2,4]  R1094     -8.1347936391830444e-01
    z[1,2,4]  R1095     -6.7264097929000854e-01
    z[1,2,4]  R1096     0.714393138885498
    z[1,2,4]  R1097     2.0473514497280121e-01
    z[1,2,4]  R1098     7.4354684352874756e-01
    z[1,2,4]  R1099     -3.6610189080238342e-01
    z[1,2,4]  R1100     -6.7614614963531494e-01
    z[1,2,4]  R1101     -6.5717041492462158e-01
    z[1,2,4]  R1102     6.3501501083374023e-01
    z[1,2,4]  R1103     -2.0388266444206238e-01
    z[1,2,4]  R1104     -4.1412681341171265e-01
    z[1,2,4]  R1105     -1.8338575959205627e-01
    z[1,2,4]  R1106     0.08367870002985
    z[1,2,4]  R1107     -3.0239738523960114e-02
    z[1,2,4]  R1108     -4.8318862915039062e-01
    z[1,2,4]  R1109     5.0756323337554932e-01
    z[1,2,4]  R1110     -6.6026735305786133e-01
    z[1,2,4]  R1111     -5.5032426118850708e-01
    z[1,2,4]  R1112     -4.8070478439331055e-01
    z[1,2,4]  R1113     -2.4454867839813232e-01
    z[1,2,4]  R1114     5.6814938783645630e-01
    z[1,2,4]  R1115     -3.5311231017112732e-01
    z[1,2,4]  R1116     -2.4681656062602997e-01
    z[1,2,4]  R1117     2.4790546298027039e-01
    z[1,2,4]  R1118     -5.1099810749292374e-02
    z[1,2,4]  R1119     -4.8351773619651794e-01
    z[1,2,4]  R1120     -1.2792724370956421e-01
    z[1,2,4]  R1121     6.3539731502532959e-01
    z[1,2,4]  R1122     -5.8918994665145874e-01
    z[1,2,4]  R1123     -3.1173002719879150e-01
    z[1,2,4]  R1124     -5.7868313789367676e-01
    z[1,2,4]  R1125     0.40912064909935
    z[1,2,4]  R1126     -7.7711150050163269e-02
    z[1,2,4]  R1127     -5.3043740987777710e-01
    z[1,2,4]  R1128     2.0222522318363190e-01
    z[1,2,4]  R1129     -1.1678715795278549e-01
    z[1,2,4]  R1130     0.266841858625412
    z[1,2,4]  R1131     6.5220171213150024e-01
    z[1,2,4]  R1132     -4.9036750197410583e-01
    z[1,2,4]  R1133     4.0584853291511536e-01
    z[1,2,4]  R1134     -2.3033963143825531e-01
    z[1,2,4]  R1135     3.1694963574409485e-01
    z[1,2,4]  R1136     6.0401898622512817e-01
    z[1,2,4]  R1137     2.3337426781654358e-01
    z[1,2,4]  R1138     0.260204017162323
    z[1,2,4]  R1139     6.2906432151794434e-01
    z[1,2,4]  R1140     -5.1490652561187744e-01
    z[1,2,4]  R1141     -4.7561657428741455e-01
    z[1,2,4]  R1142     -5.8428540825843811e-02
    z[1,2,4]  R1143     -0.365177184343338
    z[1,2,4]  R1144     5.0869386643171310e-02
    z[1,2,4]  R1145     -3.2056987285614014e-02
    z[1,2,4]  R1146     -6.5538994967937469e-02
    z[1,2,4]  R1147     -0.0178383756428957
    z[1,2,4]  R1148     -4.6718839555978775e-02
    z[1,2,4]  R1149     -6.0257494449615479e-02
    z[1,2,4]  R1150     -4.5382639765739441e-01
    z[1,2,4]  R1151     -2.5469473004341125e-01
    z[1,2,4]  R1152     -1.0551095008850098e-01
    z[1,2,4]  R1153     2.9713329672813416e-01
    z[1,2,4]  R1154     3.7180770188570023e-02
    z[1,2,4]  R1155     4.0392377972602844e-01
    z[1,2,4]  R1156     2.4103714525699615e-01
    z[1,2,4]  R1157     -2.5213941931724548e-01
    z[1,2,4]  R1158     -2.4225538969039917e-01
    z[1,2,4]  R1159     -9.1686114668846130e-02
    z[1,2,4]  R1160     -1.3998466730117798e-01
    z[1,2,4]  R1161     9.2688970267772675e-02
    z[1,2,4]  R1162     5.2372928708791733e-02
    z[1,2,4]  R1163     -1.0429803282022476e-01
    z[1,2,4]  R1164     -1.0389237850904465e-01
    z[1,2,4]  R1165     1.7746625840663910e-01
    z[1,2,4]  R1166     -4.4248613715171814e-01
    z[1,2,4]  R1167     -1.3213990628719330e-01
    z[1,2,4]  R1168     -5.9071164578199387e-02
    z[1,2,4]  R1169     -4.3168950080871582e-01
    z[1,2,4]  R1170     -7.5712114572525024e-01
    z[1,2,4]  R1171     1.1694841831922531e-01
    z[1,2,4]  R1172     -9.3024484813213348e-02
    z[1,2,4]  R1173     -6.8430745601654053e-01
    z[1,2,4]  R1174     -6.5788125991821289e-01
    z[1,2,4]  R1175     -6.9979226589202881e-01
    z[1,2,4]  R1176     -3.6981284618377686e-01
    z[1,2,4]  R1177     1.1258546262979507e-01
    z[1,2,4]  R1178     -3.7390846014022827e-01
    z[1,2,4]  R1179     3.3302713185548782e-02
    z[1,2,4]  R1180     -1.9245386123657227e-01
    z[1,2,4]  R1181     -2.9392004013061523e-01
    z[1,2,4]  R1182     -7.5283324718475342e-01
    z[1,2,4]  R1183     -7.0575617253780365e-02
    z[1,2,4]  R1184     1.0091464221477509e-01
    z[1,2,4]  R1185     9.7659686580300331e-03
    z[1,2,4]  R1186     1.2039819359779358e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R1073     -1
    z[1,2,5]  R1074     1
    z[1,2,5]  R1077     -3.8039609789848328e-01
    z[1,2,5]  R1078     -5.0422906875610352e-01
    z[1,2,5]  R1079     -0.164892315864563
    z[1,2,5]  R1080     -4.6466124057769775e-01
    z[1,2,5]  R1081     -7.6907074451446533e-01
    z[1,2,5]  R1082     -1.9561339914798737e-01
    z[1,2,5]  R1083     1.6903290152549744e-01
    z[1,2,5]  R1084     -3.4611638635396957e-02
    z[1,2,5]  R1085     -1.5801297500729561e-02
    z[1,2,5]  R1086     4.4854953885078430e-02
    z[1,2,5]  R1087     -1.0670714825391769e-01
    z[1,2,5]  R1088     -7.1751600503921509e-01
    z[1,2,5]  R1089     6.5067127346992493e-02
    z[1,2,5]  R1090     4.9789077043533325e-01
    z[1,2,5]  R1091     -1.0500293225049973e-01
    z[1,2,5]  R1092     -1.1569120734930038e-01
    z[1,2,5]  R1093     6.1202161014080048e-02
    z[1,2,5]  R1094     1.8338931724429131e-02
    z[1,2,5]  R1095     5.3137916326522827e-01
    z[1,2,5]  R1096     3.3780816197395325e-01
    z[1,2,5]  R1097     1.6777861863374710e-02
    z[1,2,5]  R1098     1.9756369292736053e-01
    z[1,2,5]  R1099     3.6830523610115051e-01
    z[1,2,5]  R1100     1.3149045407772064e-01
    z[1,2,5]  R1101     -2.9963439702987671e-01
    z[1,2,5]  R1102     -3.2674390077590942e-01
    z[1,2,5]  R1103     7.1859258413314819e-01
    z[1,2,5]  R1104     9.6005834639072418e-02
    z[1,2,5]  R1105     6.1905288696289062e-01
    z[1,2,5]  R1106     2.3936746641993523e-02
    z[1,2,5]  R1107     -1.3524423539638519e-01
    z[1,2,5]  R1108     8.5094437003135681e-02
    z[1,2,5]  R1109     5.3755539655685425e-01
    z[1,2,5]  R1110     1.3397021591663361e-01
    z[1,2,5]  R1111     -3.2710316777229309e-01
    z[1,2,5]  R1112     1.9581331312656403e-01
    z[1,2,5]  R1113     3.4025412797927856e-01
    z[1,2,5]  R1114     3.0967232584953308e-01
    z[1,2,5]  R1115     -4.6537414193153381e-01
    z[1,2,5]  R1116     -2.0345541834831238e-01
    z[1,2,5]  R1117     -1.7123125493526459e-01
    z[1,2,5]  R1118     5.5556458234786987e-01
    z[1,2,5]  R1119     1.4421881735324860e-01
    z[1,2,5]  R1120     -4.2163927108049393e-02
    z[1,2,5]  R1121     2.1139974892139435e-01
    z[1,2,5]  R1122     4.3668356537818909e-01
    z[1,2,5]  R1123     -4.2336869239807129e-01
    z[1,2,5]  R1124     -1.9220508635044098e-01
    z[1,2,5]  R1125     3.0547830462455750e-01
    z[1,2,5]  R1126     -3.2927942276000977e-01
    z[1,2,5]  R1127     6.5410439856350422e-03
    z[1,2,5]  R1128     -2.1521820127964020e-01
    z[1,2,5]  R1129     1.4981015026569366e-01
    z[1,2,5]  R1130     -0.0714566707611084
    z[1,2,5]  R1131     1.5993739664554596e-01
    z[1,2,5]  R1132     -2.0263540744781494e-01
    z[1,2,5]  R1133     -0.27133908867836
    z[1,2,5]  R1134     -4.7249174118041992e-01
    z[1,2,5]  R1135     -2.1879664063453674e-01
    z[1,2,5]  R1136     2.1051040291786194e-01
    z[1,2,5]  R1137     -4.7900292277336121e-01
    z[1,2,5]  R1138     1.1892103403806686e-01
    z[1,2,5]  R1139     -2.1886758506298065e-02
    z[1,2,5]  R1140     -5.5067169666290283e-01
    z[1,2,5]  R1141     -9.6480071544647217e-02
    z[1,2,5]  R1142     7.9776518046855927e-02
    z[1,2,5]  R1143     -0.0778428167104721
    z[1,2,5]  R1144     -9.3156717717647552e-02
    z[1,2,5]  R1145     1.4025831222534180e-01
    z[1,2,5]  R1146     -3.3763861656188965e-01
    z[1,2,5]  R1147     3.8339686393737793e-01
    z[1,2,5]  R1148     7.4416443705558777e-02
    z[1,2,5]  R1149     2.6872122287750244e-01
    z[1,2,5]  R1150     1.9816392660140991e-01
    z[1,2,5]  R1151     2.1644225716590881e-01
    z[1,2,5]  R1152     2.7994787693023682e-01
    z[1,2,5]  R1153     1.2733405828475952e-01
    z[1,2,5]  R1154     -1.0238508880138397e-01
    z[1,2,5]  R1155     3.4010317921638489e-01
    z[1,2,5]  R1156     -3.9974547922611237e-02
    z[1,2,5]  R1157     -3.6941388249397278e-01
    z[1,2,5]  R1158     -3.4650653600692749e-01
    z[1,2,5]  R1159     -4.4726513326168060e-02
    z[1,2,5]  R1160     -0.519870400428772
    z[1,2,5]  R1161     -1.6513921320438385e-01
    z[1,2,5]  R1162     -3.3169832825660706e-01
    z[1,2,5]  R1163     -4.7022223472595215e-01
    z[1,2,5]  R1164     -6.1688584089279175e-01
    z[1,2,5]  R1165     -6.2938481569290161e-01
    z[1,2,5]  R1166     -5.7471239566802979e-01
    z[1,2,5]  R1167     -6.2409126758575439e-01
    z[1,2,5]  R1168     -1.6205992549657822e-02
    z[1,2,5]  R1169     -4.0821567177772522e-01
    z[1,2,5]  R1170     -5.4451203346252441e-01
    z[1,2,5]  R1171     -1.0340183973312378e-01
    z[1,2,5]  R1172     5.6958663463592529e-01
    z[1,2,5]  R1173     4.1589897871017456e-01
    z[1,2,5]  R1174     3.1338497996330261e-01
    z[1,2,5]  R1175     3.9741155505180359e-01
    z[1,2,5]  R1176     -2.8564637899398804e-01
    z[1,2,5]  R1177     -5.6243741512298584e-01
    z[1,2,5]  R1178     -4.5603013038635254e-01
    z[1,2,5]  R1179     -3.9154800772666931e-01
    z[1,2,5]  R1180     -4.0158487856388092e-02
    z[1,2,5]  R1181     3.2321658730506897e-01
    z[1,2,5]  R1182     3.2331734895706177e-01
    z[1,2,5]  R1183     -4.0162622928619385e-01
    z[1,2,5]  R1184     2.4523507058620453e-01
    z[1,2,5]  R1185     3.1295937299728394e-01
    z[1,2,5]  R1186     1.1620508134365082e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R1075     -1
    z[1,2,6]  R1076     1
    z[1,2,6]  R1077     2.5978598743677139e-02
    z[1,2,6]  R1078     2.5896498560905457e-01
    z[1,2,6]  R1079     2.2164984047412872e-01
    z[1,2,6]  R1080     3.9759743958711624e-03
    z[1,2,6]  R1081     -1.1250501126050949e-01
    z[1,2,6]  R1082     1.7408958077430725e-01
    z[1,2,6]  R1083     1.3000544905662537e-01
    z[1,2,6]  R1084     -2.1116336807608604e-02
    z[1,2,6]  R1085     2.4243091046810150e-01
    z[1,2,6]  R1086     4.6817961335182190e-01
    z[1,2,6]  R1087     -2.7770814299583435e-01
    z[1,2,6]  R1088     -4.0957968682050705e-02
    z[1,2,6]  R1089     1.5679925680160522e-02
    z[1,2,6]  R1090     2.3461225628852844e-01
    z[1,2,6]  R1091     -6.1612367630004883e-01
    z[1,2,6]  R1092     -0.510966956615448
    z[1,2,6]  R1093     2.5119778513908386e-01
    z[1,2,6]  R1094     1.0444530844688416e-01
    z[1,2,6]  R1095     -2.8750613331794739e-01
    z[1,2,6]  R1096     -5.2096154540777206e-02
    z[1,2,6]  R1097     -6.3579088449478149e-01
    z[1,2,6]  R1098     -3.9047278463840485e-02
    z[1,2,6]  R1099     -5.7067770510911942e-02
    z[1,2,6]  R1100     -4.9153414368629456e-01
    z[1,2,6]  R1101     -3.9015471935272217e-01
    z[1,2,6]  R1102     2.3470519483089447e-01
    z[1,2,6]  R1103     -6.4734026789665222e-02
    z[1,2,6]  R1104     7.1323089301586151e-02
    z[1,2,6]  R1105     0.603255033493042
    z[1,2,6]  R1106     -1.8306757509708405e-01
    z[1,2,6]  R1107     -6.2811499834060669e-01
    z[1,2,6]  R1108     -5.8990508317947388e-01
    z[1,2,6]  R1109     4.7271189093589783e-01
    z[1,2,6]  R1110     -3.1926280260086060e-01
    z[1,2,6]  R1111     -1.4661435782909393e-01
    z[1,2,6]  R1112     5.3604024648666382e-01
    z[1,2,6]  R1113     -4.1475647687911987e-01
    z[1,2,6]  R1114     -1.1077469587326050e-01
    z[1,2,6]  R1115     -4.6451419591903687e-01
    z[1,2,6]  R1116     5.5887496471405029e-01
    z[1,2,6]  R1117     -1.7274679243564606e-01
    z[1,2,6]  R1118     1.2963366508483887e-01
    z[1,2,6]  R1119     5.8247900009155273e-01
    z[1,2,6]  R1120     1.6660098731517792e-01
    z[1,2,6]  R1121     -1.5399083495140076e-01
    z[1,2,6]  R1122     1.0274005681276321e-01
    z[1,2,6]  R1123     -1.6138151288032532e-01
    z[1,2,6]  R1124     -2.3751424252986908e-01
    z[1,2,6]  R1125     -4.2117387056350708e-01
    z[1,2,6]  R1126     5.3832399845123291e-01
    z[1,2,6]  R1127     -9.5269419252872467e-02
    z[1,2,6]  R1128     -0.337056040763855
    z[1,2,6]  R1129     -3.3285051584243774e-01
    z[1,2,6]  R1130     0.341945618391037
    z[1,2,6]  R1131     -2.7795326709747314e-01
    z[1,2,6]  R1132     -2.9696673154830933e-01
    z[1,2,6]  R1133     6.0295134782791138e-01
    z[1,2,6]  R1134     3.2087239623069763e-01
    z[1,2,6]  R1135     3.1672829389572144e-01
    z[1,2,6]  R1136     -2.7522730827331543e-01
    z[1,2,6]  R1137     -3.6352673172950745e-01
    z[1,2,6]  R1138     3.1183210015296936e-01
    z[1,2,6]  R1139     -0.522093653678894
    z[1,2,6]  R1140     8.4165006875991821e-02
    z[1,2,6]  R1141     4.1922721266746521e-01
    z[1,2,6]  R1142     -1.0764741152524948e-01
    z[1,2,6]  R1143     -8.9159741997718811e-02
    z[1,2,6]  R1144     1.8927218019962311e-01
    z[1,2,6]  R1145     -0.0878983587026596
    z[1,2,6]  R1146     9.3493327498435974e-02
    z[1,2,6]  R1147     2.6852054521441460e-02
    z[1,2,6]  R1148     -9.1749869287014008e-02
    z[1,2,6]  R1149     1.9953864812850952e-01
    z[1,2,6]  R1150     -5.5594801902770996e-02
    z[1,2,6]  R1151     4.1194528341293335e-02
    z[1,2,6]  R1152     -8.8617682456970215e-02
    z[1,2,6]  R1153     8.8885044679045677e-03
    z[1,2,6]  R1154     -4.1980691254138947e-02
    z[1,2,6]  R1155     3.2020047307014465e-01
    z[1,2,6]  R1156     2.5830745697021484e-01
    z[1,2,6]  R1157     -1.3043585419654846e-01
    z[1,2,6]  R1158     -1.0522356629371643e-01
    z[1,2,6]  R1159     -2.6178336702287197e-03
    z[1,2,6]  R1160     -2.2865532338619232e-01
    z[1,2,6]  R1161     -1.5521687269210815e-01
    z[1,2,6]  R1162     -3.8367825746536255e-01
    z[1,2,6]  R1163     2.7135983109474182e-01
    z[1,2,6]  R1164     2.7077487111091614e-01
    z[1,2,6]  R1165     3.1675910949707031e-01
    z[1,2,6]  R1166     2.7105422690510750e-02
    z[1,2,6]  R1167     4.3651174753904343e-02
    z[1,2,6]  R1168     1.6516314819455147e-02
    z[1,2,6]  R1169     5.8261758089065552e-01
    z[1,2,6]  R1170     0.0882897898554802
    z[1,2,6]  R1171     -5.0918185710906982e-01
    z[1,2,6]  R1172     -3.4413103014230728e-02
    z[1,2,6]  R1173     -2.9413762688636780e-01
    z[1,2,6]  R1174     3.9203155040740967e-01
    z[1,2,6]  R1175     4.3268457055091858e-01
    z[1,2,6]  R1176     -1.0839474201202393e-01
    z[1,2,6]  R1177     6.3343368470668793e-02
    z[1,2,6]  R1178     0.25189009308815
    z[1,2,6]  R1179     6.6726314835250378e-03
    z[1,2,6]  R1180     -6.4489126205444336e-01
    z[1,2,6]  R1181     -3.4458079934120178e-01
    z[1,2,6]  R1182     2.3714034259319305e-01
    z[1,2,6]  R1183     2.4156366288661957e-01
    z[1,2,6]  R1184     1.7024591565132141e-01
    z[1,2,6]  R1185     5.6444126367568970e-01
    z[1,2,6]  R1186     -2.3695375025272369e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R1187     -1
    z[2,1,0]  R1188     1
    z[2,1,0]  R1201     0.443828284740448
    z[2,1,0]  R1202     0.596022367477417
    z[2,1,0]  R1203     5.8625990152359009e-01
    z[2,1,0]  R1204     4.5706677436828613e-01
    z[2,1,0]  R1205     2.2589190304279327e-01
    z[2,1,0]  R1206     3.8704875111579895e-01
    z[2,1,0]  R1207     3.0130943655967712e-01
    z[2,1,0]  R1208     5.8022117614746094e-01
    z[2,1,0]  R1209     0.547103226184845
    z[2,1,0]  R1210     -1.9522064924240112e-01
    z[2,1,0]  R1211     -5.9889388084411621e-01
    z[2,1,0]  R1212     -5.5948734283447266e-01
    z[2,1,0]  R1213     -7.2994542121887207e-01
    z[2,1,0]  R1214     -4.2817932367324829e-01
    z[2,1,0]  R1215     -7.4910598993301392e-01
    z[2,1,0]  R1216     -4.0614092350006104e-01
    z[2,1,0]  R1217     -5.9933245182037354e-01
    z[2,1,0]  R1218     -3.8821491599082947e-01
    z[2,1,0]  R1219     -2.6076626777648926e-01
    z[2,1,0]  R1220     -4.7347363829612732e-01
    z[2,1,0]  R1221     -1.8241828307509422e-02
    z[2,1,0]  R1222     3.5420483350753784e-01
    z[2,1,0]  R1223     -3.4724938869476318e-01
    z[2,1,0]  R1224     -0.0746384710073471
    z[2,1,0]  R1225     2.0175845921039581e-01
    z[2,1,0]  R1226     -1.2036658078432083e-01
    z[2,1,0]  R1227     -1.1681912094354630e-01
    z[2,1,0]  R1228     2.6472198963165283e-01
    z[2,1,0]  R1229     -6.0214199125766754e-02
    z[2,1,0]  R1230     -1.1675311252474785e-02
    z[2,1,0]  R1231     -3.9184695482254028e-01
    z[2,1,0]  R1232     -0.439421683549881
    z[2,1,0]  R1233     -0.185368150472641
    z[2,1,0]  R1234     -1.0790064185857773e-01
    z[2,1,0]  R1235     -5.3795784711837769e-01
    z[2,1,0]  R1236     -3.2538771629333496e-01
    z[2,1,0]  R1237     8.3735115826129913e-02
    z[2,1,0]  R1238     -4.8598015308380127e-01
    z[2,1,0]  R1239     -4.9811840057373047e-01
    z[2,1,0]  R1240     -0.307282954454422
    z[2,1,0]  R1241     -2.7622032165527344e-01
    z[2,1,0]  R1242     7.2170570492744446e-02
    z[2,1,0]  R1243     -2.1570110321044922e-01
    z[2,1,0]  R1244     -1.9471928477287292e-01
    z[2,1,0]  R1245     1.9177286326885223e-01
    z[2,1,0]  R1246     -9.2172406613826752e-02
    z[2,1,0]  R1247     -2.2240076959133148e-01
    z[2,1,0]  R1248     -1.5014803968369961e-02
    z[2,1,0]  R1249     7.7013963460922241e-01
    z[2,1,0]  R1250     3.6218479275703430e-01
    z[2,1,0]  R1251     -9.2576093971729279e-02
    z[2,1,0]  R1252     -6.1049032211303711e-01
    z[2,1,0]  R1253     2.5484472513198853e-01
    z[2,1,0]  R1254     5.2137277089059353e-03
    z[2,1,0]  R1255     -0.604136049747467
    z[2,1,0]  R1256     -8.2193642854690552e-01
    z[2,1,0]  R1257     0.663940966129303
    z[2,1,0]  R1258     4.0393376350402832e-01
    z[2,1,0]  R1259     -2.0123668015003204e-01
    z[2,1,0]  R1260     -3.8823267817497253e-01
    z[2,1,0]  R1261     -2.7819445729255676e-01
    z[2,1,0]  R1262     -1.8396872282028198e-01
    z[2,1,0]  R1263     -0.406222403049469
    z[2,1,0]  R1264     -1.1003332585096359e-01
    z[2,1,0]  R1265     -9.8708763718605042e-02
    z[2,1,0]  R1266     4.4714215397834778e-01
    z[2,1,0]  R1267     -3.8053756952285767e-01
    z[2,1,0]  R1268     2.1977389231324196e-02
    z[2,1,0]  R1269     -1.4427816867828369e-01
    z[2,1,0]  R1270     8.8784933090209961e-01
    z[2,1,0]  R1271     -1.9358487427234650e-01
    z[2,1,0]  R1272     -2.9861995577812195e-01
    z[2,1,0]  R1273     -2.8213111683726311e-02
    z[2,1,0]  R1274     1.6459727287292480e-01
    z[2,1,0]  R1275     3.3137798309326172e-01
    z[2,1,0]  R1276     2.3689137399196625e-01
    z[2,1,0]  R1277     -2.9080209136009216e-01
    z[2,1,0]  R1278     -5.5311852693557739e-01
    z[2,1,0]  R1279     5.9021119959652424e-03
    z[2,1,0]  R1280     5.5397635698318481e-01
    z[2,1,0]  R1281     1.1108215898275375e-01
    z[2,1,0]  R1282     -3.1310665607452393e-01
    z[2,1,0]  R1283     0.181345596909523
    z[2,1,0]  R1284     -9.9855475127696991e-02
    z[2,1,0]  R1285     -4.7264367341995239e-01
    z[2,1,0]  R1286     1.7552487552165985e-01
    z[2,1,0]  R1287     1.1585873365402222e-01
    z[2,1,0]  R1288     2.7301779389381409e-01
    z[2,1,0]  R1289     3.6947306990623474e-01
    z[2,1,0]  R1290     1.2942981719970703e-01
    z[2,1,0]  R1291     1.4334422349929810e-01
    z[2,1,0]  R1292     -2.0050154998898506e-03
    z[2,1,0]  R1293     -3.4409871697425842e-01
    z[2,1,0]  R1294     -0.0753057599067688
    z[2,1,0]  R1295     -4.1856479644775391e-01
    z[2,1,0]  R1296     -5.2887761592864990e-01
    z[2,1,0]  R1297     3.8372308015823364e-01
    z[2,1,0]  R1298     1.8392139673233032e-01
    z[2,1,0]  R1299     0.756458580493927
    z[2,1,0]  R1300     4.1215223073959351e-01
    z[2,1,0]  R1301     -2.9381206259131432e-02
    z[2,1,0]  R1302     -1.9953933358192444e-01
    z[2,1,0]  R1303     0.0612550750374794
    z[2,1,0]  R1304     -5.5652207136154175e-01
    z[2,1,0]  R1305     2.4315534532070160e-01
    z[2,1,0]  R1306     8.9159369468688965e-01
    z[2,1,0]  R1307     8.5959982872009277e-01
    z[2,1,0]  R1308     8.3808708190917969e-01
    z[2,1,0]  R1309     8.2671457529067993e-01
    z[2,1,0]  R1310     8.2864439487457275e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R1189     -1
    z[2,1,1]  R1190     1
    z[2,1,1]  R1201     2.3911124467849731e-01
    z[2,1,1]  R1202     1.0747678577899933e-01
    z[2,1,1]  R1203     9.9074125289916992e-02
    z[2,1,1]  R1204     2.6177468895912170e-01
    z[2,1,1]  R1205     2.9460325837135315e-01
    z[2,1,1]  R1206     3.5361862182617188e-01
    z[2,1,1]  R1207     3.4898763895034790e-01
    z[2,1,1]  R1208     4.8065102100372314e-01
    z[2,1,1]  R1209     2.5980255007743835e-01
    z[2,1,1]  R1210     -8.5558688640594482e-01
    z[2,1,1]  R1211     -8.5406258702278137e-02
    z[2,1,1]  R1212     -4.2828482389450073e-01
    z[2,1,1]  R1213     -4.5273122191429138e-01
    z[2,1,1]  R1214     -1.1212576180696487e-01
    z[2,1,1]  R1215     -3.8804542273283005e-03
    z[2,1,1]  R1216     -3.9136001467704773e-01
    z[2,1,1]  R1217     1.3638220727443695e-01
    z[2,1,1]  R1218     -8.1791423261165619e-02
    z[2,1,1]  R1219     -9.3317642807960510e-02
    z[2,1,1]  R1220     1.5056781470775604e-01
    z[2,1,1]  R1221     -5.1217317581176758e-01
    z[2,1,1]  R1222     -1.7223972082138062e-01
    z[2,1,1]  R1223     -2.8673630952835083e-01
    z[2,1,1]  R1224     -0.224474236369133
    z[2,1,1]  R1225     -9.3072272837162018e-02
    z[2,1,1]  R1226     -1.6432899236679077e-01
    z[2,1,1]  R1227     1.0145115852355957e-01
    z[2,1,1]  R1228     -2.4835982918739319e-01
    z[2,1,1]  R1229     -5.6369885802268982e-02
    z[2,1,1]  R1230     5.9535884857177734e-01
    z[2,1,1]  R1231     4.0345042943954468e-02
    z[2,1,1]  R1232     -4.2288365960121155e-01
    z[2,1,1]  R1233     -5.5005472898483276e-01
    z[2,1,1]  R1234     2.0386627316474915e-01
    z[2,1,1]  R1235     4.4791221618652344e-02
    z[2,1,1]  R1236     3.4200098365545273e-02
    z[2,1,1]  R1237     6.9640129804611206e-01
    z[2,1,1]  R1238     8.0537945032119751e-01
    z[2,1,1]  R1239     -2.2044022381305695e-01
    z[2,1,1]  R1240     8.9695996046066284e-01
    z[2,1,1]  R1241     5.7023260742425919e-02
    z[2,1,1]  R1242     -4.0100085735321045e-01
    z[2,1,1]  R1243     -4.0556874871253967e-01
    z[2,1,1]  R1244     -4.6332615613937378e-01
    z[2,1,1]  R1245     -2.3702657222747803e-01
    z[2,1,1]  R1246     2.2285167872905731e-01
    z[2,1,1]  R1247     2.9661893844604492e-01
    z[2,1,1]  R1248     -3.8518407940864563e-01
    z[2,1,1]  R1249     9.2216655611991882e-02
    z[2,1,1]  R1250     -3.6164233088493347e-01
    z[2,1,1]  R1251     -6.8206888437271118e-01
    z[2,1,1]  R1252     -5.1864419132471085e-02
    z[2,1,1]  R1253     -5.4454110562801361e-02
    z[2,1,1]  R1254     0.0367298349738121
    z[2,1,1]  R1255     -3.0298924073576927e-02
    z[2,1,1]  R1256     6.8774081766605377e-02
    z[2,1,1]  R1257     1.3289210200309753e-01
    z[2,1,1]  R1258     -1.5048886835575104e-01
    z[2,1,1]  R1259     -2.6078957319259644e-01
    z[2,1,1]  R1260     3.0239865183830261e-01
    z[2,1,1]  R1261     -3.2169643044471741e-01
    z[2,1,1]  R1262     3.1752693653106689e-01
    z[2,1,1]  R1263     -2.7491134405136108e-01
    z[2,1,1]  R1264     -2.0878896117210388e-01
    z[2,1,1]  R1265     -4.4018852710723877e-01
    z[2,1,1]  R1266     -1.1904118955135345e-01
    z[2,1,1]  R1267     3.8342788815498352e-01
    z[2,1,1]  R1268     7.4422186613082886e-01
    z[2,1,1]  R1269     -2.3468953371047974e-01
    z[2,1,1]  R1270     0.400115966796875
    z[2,1,1]  R1271     -1.1934275925159454e-01
    z[2,1,1]  R1272     6.0335206799209118e-03
    z[2,1,1]  R1273     2.9801445081830025e-02
    z[2,1,1]  R1274     3.9609622955322266e-01
    z[2,1,1]  R1275     0.460801899433136
    z[2,1,1]  R1276     -4.2347031831741333e-01
    z[2,1,1]  R1277     5.9909218549728394e-01
    z[2,1,1]  R1278     -2.5118863582611084e-01
    z[2,1,1]  R1279     -4.5285689830780029e-01
    z[2,1,1]  R1280     2.9667595028877258e-01
    z[2,1,1]  R1281     -4.4780600070953369e-01
    z[2,1,1]  R1282     0.479547381401062
    z[2,1,1]  R1283     -1.1395521461963654e-01
    z[2,1,1]  R1284     5.7864004373550415e-01
    z[2,1,1]  R1285     -2.3511280119419098e-01
    z[2,1,1]  R1286     3.3842352032661438e-01
    z[2,1,1]  R1287     -6.4883500337600708e-01
    z[2,1,1]  R1288     -5.0559818744659424e-01
    z[2,1,1]  R1289     0.500224769115448
    z[2,1,1]  R1290     -1.5252690762281418e-02
    z[2,1,1]  R1291     2.0094932615756989e-01
    z[2,1,1]  R1292     -4.3286976218223572e-01
    z[2,1,1]  R1293     3.8947391510009766e-01
    z[2,1,1]  R1294     4.8887810111045837e-01
    z[2,1,1]  R1295     -1.6817826032638550e-01
    z[2,1,1]  R1296     -1.7984431982040405e-01
    z[2,1,1]  R1297     1.6541364789009094e-01
    z[2,1,1]  R1298     8.7534934282302856e-02
    z[2,1,1]  R1299     1.3398897647857666e-01
    z[2,1,1]  R1300     -3.3120420575141907e-01
    z[2,1,1]  R1301     3.9884641766548157e-01
    z[2,1,1]  R1302     4.5949053764343262e-01
    z[2,1,1]  R1303     1.0078227519989014e-01
    z[2,1,1]  R1304     2.0944228395819664e-02
    z[2,1,1]  R1305     -4.8049259185791016e-01
    z[2,1,1]  R1306     3.4001204371452332e-01
    z[2,1,1]  R1307     2.5614374876022339e-01
    z[2,1,1]  R1308     0.4011210501194
    z[2,1,1]  R1309     3.2489171624183655e-01
    z[2,1,1]  R1310     2.7052381634712219e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R1191     -1
    z[2,1,2]  R1192     1
    z[2,1,2]  R1201     7.6214402914047241e-01
    z[2,1,2]  R1202     6.6670817136764526e-01
    z[2,1,2]  R1203     4.9157905578613281e-01
    z[2,1,2]  R1204     6.5431642532348633e-01
    z[2,1,2]  R1205     5.9676152467727661e-01
    z[2,1,2]  R1206     2.5834500789642334e-01
    z[2,1,2]  R1207     5.4126840829849243e-01
    z[2,1,2]  R1208     2.7784049510955811e-01
    z[2,1,2]  R1209     4.7331610321998596e-01
    z[2,1,2]  R1210     -2.9964751005172729e-01
    z[2,1,2]  R1211     -6.2315952777862549e-01
    z[2,1,2]  R1212     -4.5713719725608826e-01
    z[2,1,2]  R1213     -4.9130564928054810e-01
    z[2,1,2]  R1214     -5.4274529218673706e-01
    z[2,1,2]  R1215     -5.8590775728225708e-01
    z[2,1,2]  R1216     -6.0285305976867676e-01
    z[2,1,2]  R1217     -4.5472463965415955e-01
    z[2,1,2]  R1218     -4.4478836655616760e-01
    z[2,1,2]  R1219     -6.2860614061355591e-01
    z[2,1,2]  R1220     -4.3422549962997437e-01
    z[2,1,2]  R1221     -5.4368627071380615e-01
    z[2,1,2]  R1222     4.5820564031600952e-01
    z[2,1,2]  R1223     -2.3959949612617493e-01
    z[2,1,2]  R1224     -1.8490347266197205e-01
    z[2,1,2]  R1225     7.0345804095268250e-02
    z[2,1,2]  R1226     5.7068395614624023e-01
    z[2,1,2]  R1227     1.6660247743129730e-01
    z[2,1,2]  R1228     -4.9605220556259155e-02
    z[2,1,2]  R1229     1.3281117379665375e-01
    z[2,1,2]  R1230     1.6671356558799744e-01
    z[2,1,2]  R1231     -7.1254062652587891e-01
    z[2,1,2]  R1232     -4.4756001234054565e-01
    z[2,1,2]  R1233     -6.0772401094436646e-01
    z[2,1,2]  R1234     3.6574136465787888e-02
    z[2,1,2]  R1235     1.7348611354827881e-01
    z[2,1,2]  R1236     -3.8892120122909546e-02
    z[2,1,2]  R1237     8.6048319935798645e-02
    z[2,1,2]  R1238     5.2002891898155212e-02
    z[2,1,2]  R1239     2.6664009690284729e-01
    z[2,1,2]  R1240     -8.1974111497402191e-02
    z[2,1,2]  R1241     5.7882523536682129e-01
    z[2,1,2]  R1242     4.1696330904960632e-01
    z[2,1,2]  R1243     5.1958316564559937e-01
    z[2,1,2]  R1244     5.7546877861022949e-01
    z[2,1,2]  R1245     2.1274326741695404e-01
    z[2,1,2]  R1246     7.5553268194198608e-01
    z[2,1,2]  R1247     4.0897557139396667e-01
    z[2,1,2]  R1248     9.6684433519840240e-03
    z[2,1,2]  R1249     -3.0653487890958786e-02
    z[2,1,2]  R1250     7.4481427669525146e-02
    z[2,1,2]  R1251     -4.2489755153656006e-01
    z[2,1,2]  R1252     -2.0523147657513618e-02
    z[2,1,2]  R1253     -3.4373795986175537e-01
    z[2,1,2]  R1254     9.5099993050098419e-02
    z[2,1,2]  R1255     -2.2712003439664841e-02
    z[2,1,2]  R1256     2.0225118845701218e-02
    z[2,1,2]  R1257     -8.4506928920745850e-02
    z[2,1,2]  R1258     -1.7085234820842743e-01
    z[2,1,2]  R1259     -9.8722055554389954e-02
    z[2,1,2]  R1260     -1.4519126713275909e-01
    z[2,1,2]  R1261     -2.3931415379047394e-01
    z[2,1,2]  R1262     -3.5749744623899460e-02
    z[2,1,2]  R1263     4.3033313751220703e-01
    z[2,1,2]  R1264     2.3229060694575310e-02
    z[2,1,2]  R1265     -6.8220630288124084e-02
    z[2,1,2]  R1266     -2.4715360999107361e-01
    z[2,1,2]  R1267     3.8568194955587387e-02
    z[2,1,2]  R1268     3.6008810997009277e-01
    z[2,1,2]  R1269     1.1655066907405853e-01
    z[2,1,2]  R1270     -1.4073415659368038e-02
    z[2,1,2]  R1271     3.5025379620492458e-03
    z[2,1,2]  R1272     2.5871858000755310e-01
    z[2,1,2]  R1273     5.0503186881542206e-02
    z[2,1,2]  R1274     -1.9696229696273804e-01
    z[2,1,2]  R1275     1.0958162695169449e-01
    z[2,1,2]  R1276     -3.6883754655718803e-03
    z[2,1,2]  R1277     8.8690489530563354e-02
    z[2,1,2]  R1278     9.6120364964008331e-02
    z[2,1,2]  R1279     2.3620733618736267e-01
    z[2,1,2]  R1280     -8.8324621319770813e-02
    z[2,1,2]  R1281     -4.0031763911247253e-01
    z[2,1,2]  R1282     1.7647184431552887e-01
    z[2,1,2]  R1283     2.7075189352035522e-01
    z[2,1,2]  R1284     5.7719075679779053e-01
    z[2,1,2]  R1285     8.3714880049228668e-02
    z[2,1,2]  R1286     -2.6952880620956421e-01
    z[2,1,2]  R1287     1.6323316097259521e-01
    z[2,1,2]  R1288     -2.3205693066120148e-01
    z[2,1,2]  R1289     7.0322789251804352e-02
    z[2,1,2]  R1290     6.2086915969848633e-01
    z[2,1,2]  R1291     2.3653939366340637e-02
    z[2,1,2]  R1292     -2.4569955468177795e-01
    z[2,1,2]  R1293     3.2196617126464844e-01
    z[2,1,2]  R1294     4.1821566224098206e-01
    z[2,1,2]  R1295     3.5133041441440582e-02
    z[2,1,2]  R1296     -1.4320272952318192e-02
    z[2,1,2]  R1297     1.5297865867614746e-01
    z[2,1,2]  R1298     6.3117647171020508e-01
    z[2,1,2]  R1299     -1.8626330420374870e-02
    z[2,1,2]  R1300     -3.0767264962196350e-01
    z[2,1,2]  R1301     2.6093924045562744e-01
    z[2,1,2]  R1302     3.9941665530204773e-01
    z[2,1,2]  R1303     -2.3553118109703064e-01
    z[2,1,2]  R1304     -6.9350576959550381e-03
    z[2,1,2]  R1305     1.9941753149032593e-01
    z[2,1,2]  R1306     2.5417020916938782e-01
    z[2,1,2]  R1307     -2.1761699020862579e-01
    z[2,1,2]  R1308     6.5196588635444641e-02
    z[2,1,2]  R1309     -3.3122289180755615e-01
    z[2,1,2]  R1310     -3.2163041830062866e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R1193     -1
    z[2,1,3]  R1194     1
    z[2,1,3]  R1201     -1.3017807900905609e-01
    z[2,1,3]  R1202     -4.1541284322738647e-01
    z[2,1,3]  R1203     -5.3775084018707275e-01
    z[2,1,3]  R1204     -2.1474617719650269e-01
    z[2,1,3]  R1205     -6.2661296129226685e-01
    z[2,1,3]  R1206     -7.4903172254562378e-01
    z[2,1,3]  R1207     -6.2439376115798950e-01
    z[2,1,3]  R1208     -5.8437591791152954e-01
    z[2,1,3]  R1209     -1.6673199832439423e-01
    z[2,1,3]  R1210     -1.1684054881334305e-01
    z[2,1,3]  R1211     -1.6926182806491852e-01
    z[2,1,3]  R1212     3.2364353537559509e-01
    z[2,1,3]  R1213     -1.0207553952932358e-01
    z[2,1,3]  R1214     4.0911316871643066e-01
    z[2,1,3]  R1215     1.8863391876220703e-01
    z[2,1,3]  R1216     2.4182501435279846e-01
    z[2,1,3]  R1217     3.3136495947837830e-01
    z[2,1,3]  R1218     4.2438396811485291e-01
    z[2,1,3]  R1219     1.3828664086759090e-02
    z[2,1,3]  R1220     1.9436357915401459e-01
    z[2,1,3]  R1221     -1.8136920034885406e-01
    z[2,1,3]  R1222     7.9428905248641968e-01
    z[2,1,3]  R1223     -2.1760773658752441e-01
    z[2,1,3]  R1224     -1.7980632185935974e-01
    z[2,1,3]  R1225     8.1366300582885742e-01
    z[2,1,3]  R1226     5.4640734195709229e-01
    z[2,1,3]  R1227     4.6961575746536255e-01
    z[2,1,3]  R1228     4.2552584409713745e-01
    z[2,1,3]  R1229     3.7509584426879883e-01
    z[2,1,3]  R1230     6.2250560522079468e-01
    z[2,1,3]  R1231     -6.3955806195735931e-02
    z[2,1,3]  R1232     -1.2864026427268982e-01
    z[2,1,3]  R1233     -3.7321120500564575e-01
    z[2,1,3]  R1234     7.0065855979919434e-01
    z[2,1,3]  R1235     6.0737454891204834e-01
    z[2,1,3]  R1236     4.0486183762550354e-01
    z[2,1,3]  R1237     0.525330126285553
    z[2,1,3]  R1238     1.1478332430124283e-01
    z[2,1,3]  R1239     4.6427825093269348e-01
    z[2,1,3]  R1240     1.0086484998464584e-01
    z[2,1,3]  R1241     -2.8136521577835083e-01
    z[2,1,3]  R1242     -5.2662551403045654e-01
    z[2,1,3]  R1243     -6.1233186721801758e-01
    z[2,1,3]  R1244     -3.1960594654083252e-01
    z[2,1,3]  R1245     -4.3368527293205261e-01
    z[2,1,3]  R1246     -5.1076197624206543e-01
    z[2,1,3]  R1247     -8.0525797605514526e-01
    z[2,1,3]  R1248     -5.2254360914230347e-01
    z[2,1,3]  R1249     -4.2296999692916870e-01
    z[2,1,3]  R1250     4.8478193581104279e-02
    z[2,1,3]  R1251     -1.8497726321220398e-01
    z[2,1,3]  R1252     7.9207018017768860e-02
    z[2,1,3]  R1253     3.8945192098617554e-01
    z[2,1,3]  R1254     0.422821044921875
    z[2,1,3]  R1255     -2.8210881352424622e-01
    z[2,1,3]  R1256     -1.1807091534137726e-01
    z[2,1,3]  R1257     3.5757082700729370e-01
    z[2,1,3]  R1258     3.3467337489128113e-01
    z[2,1,3]  R1259     2.5352901220321655e-01
    z[2,1,3]  R1260     3.3100441098213196e-01
    z[2,1,3]  R1261     -5.6162250041961670e-01
    z[2,1,3]  R1262     5.2022719383239746e-01
    z[2,1,3]  R1263     5.4889374971389771e-01
    z[2,1,3]  R1264     4.7716978192329407e-01
    z[2,1,3]  R1265     -3.4345608949661255e-01
    z[2,1,3]  R1266     3.9964485168457031e-01
    z[2,1,3]  R1267     3.8020107150077820e-01
    z[2,1,3]  R1268     3.6080777645111084e-01
    z[2,1,3]  R1269     3.6020430922508240e-01
    z[2,1,3]  R1270     1.0170537978410721e-01
    z[2,1,3]  R1271     -0.731119692325592
    z[2,1,3]  R1272     5.0512790679931641e-01
    z[2,1,3]  R1273     4.7510275244712830e-01
    z[2,1,3]  R1274     4.7052279114723206e-01
    z[2,1,3]  R1275     4.8424473404884338e-01
    z[2,1,3]  R1276     4.5583185553550720e-01
    z[2,1,3]  R1277     4.4839361310005188e-01
    z[2,1,3]  R1278     4.3676459789276123e-01
    z[2,1,3]  R1279     4.2668148875236511e-01
    z[2,1,3]  R1280     4.2736229300498962e-01
    z[2,1,3]  R1281     -7.1151775121688843e-01
    z[2,1,3]  R1282     5.5927473306655884e-01
    z[2,1,3]  R1283     5.3567820787429810e-01
    z[2,1,3]  R1284     0.525505781173706
    z[2,1,3]  R1285     4.9212706089019775e-01
    z[2,1,3]  R1286     4.8334461450576782e-01
    z[2,1,3]  R1287     4.8629650473594666e-01
    z[2,1,3]  R1288     4.3330281972885132e-01
    z[2,1,3]  R1289     4.1259589791297913e-01
    z[2,1,3]  R1290     4.3963640928268433e-01
    z[2,1,3]  R1291     0.805002748966217
    z[2,1,3]  R1292     -7.4258393049240112e-01
    z[2,1,3]  R1293     6.9236713647842407e-01
    z[2,1,3]  R1294     6.2224221229553223e-01
    z[2,1,3]  R1295     5.1679807901382446e-01
    z[2,1,3]  R1296     -5.6394052505493164e-01
    z[2,1,3]  R1297     0.447330117225647
    z[2,1,3]  R1298     4.2527988553047180e-01
    z[2,1,3]  R1299     4.0102961659431458e-01
    z[2,1,3]  R1300     3.7532398104667664e-01
    z[2,1,3]  R1301     -5.9658187627792358e-01
    z[2,1,3]  R1302     6.4064908027648926e-01
    z[2,1,3]  R1303     5.1169615983963013e-01
    z[2,1,3]  R1304     -3.3814874291419983e-01
    z[2,1,3]  R1305     5.0888514518737793e-01
    z[2,1,3]  R1306     -5.9023287147283554e-02
    z[2,1,3]  R1307     -2.7531739324331284e-02
    z[2,1,3]  R1308     -2.9218414425849915e-01
    z[2,1,3]  R1309     -2.6991435885429382e-01
    z[2,1,3]  R1310     -9.8402373492717743e-02
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R1195     -1
    z[2,1,4]  R1196     1
    z[2,1,4]  R1201     -0.0178383756428957
    z[2,1,4]  R1202     -4.6718839555978775e-02
    z[2,1,4]  R1203     -6.0257494449615479e-02
    z[2,1,4]  R1204     -4.5382639765739441e-01
    z[2,1,4]  R1205     -2.5469473004341125e-01
    z[2,1,4]  R1206     -1.0551095008850098e-01
    z[2,1,4]  R1207     2.9713329672813416e-01
    z[2,1,4]  R1208     3.7180770188570023e-02
    z[2,1,4]  R1209     4.0392377972602844e-01
    z[2,1,4]  R1210     2.4103714525699615e-01
    z[2,1,4]  R1211     -2.5213941931724548e-01
    z[2,1,4]  R1212     -2.4225538969039917e-01
    z[2,1,4]  R1213     -9.1686114668846130e-02
    z[2,1,4]  R1214     -1.3998466730117798e-01
    z[2,1,4]  R1215     9.2688970267772675e-02
    z[2,1,4]  R1216     5.2372928708791733e-02
    z[2,1,4]  R1217     -1.0429803282022476e-01
    z[2,1,4]  R1218     -1.0389237850904465e-01
    z[2,1,4]  R1219     1.7746625840663910e-01
    z[2,1,4]  R1220     -4.4248613715171814e-01
    z[2,1,4]  R1221     -1.3213990628719330e-01
    z[2,1,4]  R1222     -5.9071164578199387e-02
    z[2,1,4]  R1223     -4.3168950080871582e-01
    z[2,1,4]  R1224     -7.5712114572525024e-01
    z[2,1,4]  R1225     1.1694841831922531e-01
    z[2,1,4]  R1226     -9.3024484813213348e-02
    z[2,1,4]  R1227     -6.8430745601654053e-01
    z[2,1,4]  R1228     -6.5788125991821289e-01
    z[2,1,4]  R1229     -6.9979226589202881e-01
    z[2,1,4]  R1230     -3.6981284618377686e-01
    z[2,1,4]  R1231     1.1258546262979507e-01
    z[2,1,4]  R1232     -3.7390846014022827e-01
    z[2,1,4]  R1233     3.3302713185548782e-02
    z[2,1,4]  R1234     -1.9245386123657227e-01
    z[2,1,4]  R1235     -2.9392004013061523e-01
    z[2,1,4]  R1236     -7.5283324718475342e-01
    z[2,1,4]  R1237     -7.0575617253780365e-02
    z[2,1,4]  R1238     1.0091464221477509e-01
    z[2,1,4]  R1239     9.7659686580300331e-03
    z[2,1,4]  R1240     1.2039819359779358e-01
    z[2,1,4]  R1241     6.0072422027587891e-01
    z[2,1,4]  R1242     2.4796561896800995e-01
    z[2,1,4]  R1243     2.6029223203659058e-01
    z[2,1,4]  R1244     3.1332916021347046e-01
    z[2,1,4]  R1245     2.6376459002494812e-01
    z[2,1,4]  R1246     -2.0386783778667450e-01
    z[2,1,4]  R1247     3.7150572985410690e-02
    z[2,1,4]  R1248     -7.5935405492782593e-01
    z[2,1,4]  R1249     -0.399393767118454
    z[2,1,4]  R1250     -7.1339696645736694e-01
    z[2,1,4]  R1251     4.7217461466789246e-01
    z[2,1,4]  R1252     -3.1844952702522278e-01
    z[2,1,4]  R1253     8.1103682518005371e-01
    z[2,1,4]  R1254     -7.1264576911926270e-01
    z[2,1,4]  R1255     -4.0418615937232971e-01
    z[2,1,4]  R1256     -1.7569592595100403e-01
    z[2,1,4]  R1257     5.8281880617141724e-01
    z[2,1,4]  R1258     -8.1347936391830444e-01
    z[2,1,4]  R1259     -6.7264097929000854e-01
    z[2,1,4]  R1260     0.714393138885498
    z[2,1,4]  R1261     2.0473514497280121e-01
    z[2,1,4]  R1262     7.4354684352874756e-01
    z[2,1,4]  R1263     -3.6610189080238342e-01
    z[2,1,4]  R1264     -6.7614614963531494e-01
    z[2,1,4]  R1265     -6.5717041492462158e-01
    z[2,1,4]  R1266     6.3501501083374023e-01
    z[2,1,4]  R1267     -2.0388266444206238e-01
    z[2,1,4]  R1268     -4.1412681341171265e-01
    z[2,1,4]  R1269     -1.8338575959205627e-01
    z[2,1,4]  R1270     0.08367870002985
    z[2,1,4]  R1271     -3.0239738523960114e-02
    z[2,1,4]  R1272     -4.8318862915039062e-01
    z[2,1,4]  R1273     5.0756323337554932e-01
    z[2,1,4]  R1274     -6.6026735305786133e-01
    z[2,1,4]  R1275     -5.5032426118850708e-01
    z[2,1,4]  R1276     -4.8070478439331055e-01
    z[2,1,4]  R1277     -2.4454867839813232e-01
    z[2,1,4]  R1278     5.6814938783645630e-01
    z[2,1,4]  R1279     -3.5311231017112732e-01
    z[2,1,4]  R1280     -2.4681656062602997e-01
    z[2,1,4]  R1281     2.4790546298027039e-01
    z[2,1,4]  R1282     -5.1099810749292374e-02
    z[2,1,4]  R1283     -4.8351773619651794e-01
    z[2,1,4]  R1284     -1.2792724370956421e-01
    z[2,1,4]  R1285     6.3539731502532959e-01
    z[2,1,4]  R1286     -5.8918994665145874e-01
    z[2,1,4]  R1287     -3.1173002719879150e-01
    z[2,1,4]  R1288     -5.7868313789367676e-01
    z[2,1,4]  R1289     0.40912064909935
    z[2,1,4]  R1290     -7.7711150050163269e-02
    z[2,1,4]  R1291     -5.3043740987777710e-01
    z[2,1,4]  R1292     2.0222522318363190e-01
    z[2,1,4]  R1293     -1.1678715795278549e-01
    z[2,1,4]  R1294     0.266841858625412
    z[2,1,4]  R1295     6.5220171213150024e-01
    z[2,1,4]  R1296     -4.9036750197410583e-01
    z[2,1,4]  R1297     4.0584853291511536e-01
    z[2,1,4]  R1298     -2.3033963143825531e-01
    z[2,1,4]  R1299     3.1694963574409485e-01
    z[2,1,4]  R1300     6.0401898622512817e-01
    z[2,1,4]  R1301     2.3337426781654358e-01
    z[2,1,4]  R1302     0.260204017162323
    z[2,1,4]  R1303     6.2906432151794434e-01
    z[2,1,4]  R1304     -5.1490652561187744e-01
    z[2,1,4]  R1305     -4.7561657428741455e-01
    z[2,1,4]  R1306     -5.8428540825843811e-02
    z[2,1,4]  R1307     -0.365177184343338
    z[2,1,4]  R1308     5.0869386643171310e-02
    z[2,1,4]  R1309     -3.2056987285614014e-02
    z[2,1,4]  R1310     -6.5538994967937469e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R1197     -1
    z[2,1,5]  R1198     1
    z[2,1,5]  R1201     3.8339686393737793e-01
    z[2,1,5]  R1202     7.4416443705558777e-02
    z[2,1,5]  R1203     2.6872122287750244e-01
    z[2,1,5]  R1204     1.9816392660140991e-01
    z[2,1,5]  R1205     2.1644225716590881e-01
    z[2,1,5]  R1206     2.7994787693023682e-01
    z[2,1,5]  R1207     1.2733405828475952e-01
    z[2,1,5]  R1208     -1.0238508880138397e-01
    z[2,1,5]  R1209     3.4010317921638489e-01
    z[2,1,5]  R1210     -3.9974547922611237e-02
    z[2,1,5]  R1211     -3.6941388249397278e-01
    z[2,1,5]  R1212     -3.4650653600692749e-01
    z[2,1,5]  R1213     -4.4726513326168060e-02
    z[2,1,5]  R1214     -0.519870400428772
    z[2,1,5]  R1215     -1.6513921320438385e-01
    z[2,1,5]  R1216     -3.3169832825660706e-01
    z[2,1,5]  R1217     -4.7022223472595215e-01
    z[2,1,5]  R1218     -6.1688584089279175e-01
    z[2,1,5]  R1219     -6.2938481569290161e-01
    z[2,1,5]  R1220     -5.7471239566802979e-01
    z[2,1,5]  R1221     -6.2409126758575439e-01
    z[2,1,5]  R1222     -1.6205992549657822e-02
    z[2,1,5]  R1223     -4.0821567177772522e-01
    z[2,1,5]  R1224     -5.4451203346252441e-01
    z[2,1,5]  R1225     -1.0340183973312378e-01
    z[2,1,5]  R1226     5.6958663463592529e-01
    z[2,1,5]  R1227     4.1589897871017456e-01
    z[2,1,5]  R1228     3.1338497996330261e-01
    z[2,1,5]  R1229     3.9741155505180359e-01
    z[2,1,5]  R1230     -2.8564637899398804e-01
    z[2,1,5]  R1231     -5.6243741512298584e-01
    z[2,1,5]  R1232     -4.5603013038635254e-01
    z[2,1,5]  R1233     -3.9154800772666931e-01
    z[2,1,5]  R1234     -4.0158487856388092e-02
    z[2,1,5]  R1235     3.2321658730506897e-01
    z[2,1,5]  R1236     3.2331734895706177e-01
    z[2,1,5]  R1237     -4.0162622928619385e-01
    z[2,1,5]  R1238     2.4523507058620453e-01
    z[2,1,5]  R1239     3.1295937299728394e-01
    z[2,1,5]  R1240     1.1620508134365082e-01
    z[2,1,5]  R1241     -3.8039609789848328e-01
    z[2,1,5]  R1242     -5.0422906875610352e-01
    z[2,1,5]  R1243     -0.164892315864563
    z[2,1,5]  R1244     -4.6466124057769775e-01
    z[2,1,5]  R1245     -7.6907074451446533e-01
    z[2,1,5]  R1246     -1.9561339914798737e-01
    z[2,1,5]  R1247     1.6903290152549744e-01
    z[2,1,5]  R1248     -3.4611638635396957e-02
    z[2,1,5]  R1249     -1.5801297500729561e-02
    z[2,1,5]  R1250     4.4854953885078430e-02
    z[2,1,5]  R1251     -1.0670714825391769e-01
    z[2,1,5]  R1252     -7.1751600503921509e-01
    z[2,1,5]  R1253     6.5067127346992493e-02
    z[2,1,5]  R1254     4.9789077043533325e-01
    z[2,1,5]  R1255     -1.0500293225049973e-01
    z[2,1,5]  R1256     -1.1569120734930038e-01
    z[2,1,5]  R1257     6.1202161014080048e-02
    z[2,1,5]  R1258     1.8338931724429131e-02
    z[2,1,5]  R1259     5.3137916326522827e-01
    z[2,1,5]  R1260     3.3780816197395325e-01
    z[2,1,5]  R1261     1.6777861863374710e-02
    z[2,1,5]  R1262     1.9756369292736053e-01
    z[2,1,5]  R1263     3.6830523610115051e-01
    z[2,1,5]  R1264     1.3149045407772064e-01
    z[2,1,5]  R1265     -2.9963439702987671e-01
    z[2,1,5]  R1266     -3.2674390077590942e-01
    z[2,1,5]  R1267     7.1859258413314819e-01
    z[2,1,5]  R1268     9.6005834639072418e-02
    z[2,1,5]  R1269     6.1905288696289062e-01
    z[2,1,5]  R1270     2.3936746641993523e-02
    z[2,1,5]  R1271     -1.3524423539638519e-01
    z[2,1,5]  R1272     8.5094437003135681e-02
    z[2,1,5]  R1273     5.3755539655685425e-01
    z[2,1,5]  R1274     1.3397021591663361e-01
    z[2,1,5]  R1275     -3.2710316777229309e-01
    z[2,1,5]  R1276     1.9581331312656403e-01
    z[2,1,5]  R1277     3.4025412797927856e-01
    z[2,1,5]  R1278     3.0967232584953308e-01
    z[2,1,5]  R1279     -4.6537414193153381e-01
    z[2,1,5]  R1280     -2.0345541834831238e-01
    z[2,1,5]  R1281     -1.7123125493526459e-01
    z[2,1,5]  R1282     5.5556458234786987e-01
    z[2,1,5]  R1283     1.4421881735324860e-01
    z[2,1,5]  R1284     -4.2163927108049393e-02
    z[2,1,5]  R1285     2.1139974892139435e-01
    z[2,1,5]  R1286     4.3668356537818909e-01
    z[2,1,5]  R1287     -4.2336869239807129e-01
    z[2,1,5]  R1288     -1.9220508635044098e-01
    z[2,1,5]  R1289     3.0547830462455750e-01
    z[2,1,5]  R1290     -3.2927942276000977e-01
    z[2,1,5]  R1291     6.5410439856350422e-03
    z[2,1,5]  R1292     -2.1521820127964020e-01
    z[2,1,5]  R1293     1.4981015026569366e-01
    z[2,1,5]  R1294     -0.0714566707611084
    z[2,1,5]  R1295     1.5993739664554596e-01
    z[2,1,5]  R1296     -2.0263540744781494e-01
    z[2,1,5]  R1297     -0.27133908867836
    z[2,1,5]  R1298     -4.7249174118041992e-01
    z[2,1,5]  R1299     -2.1879664063453674e-01
    z[2,1,5]  R1300     2.1051040291786194e-01
    z[2,1,5]  R1301     -4.7900292277336121e-01
    z[2,1,5]  R1302     1.1892103403806686e-01
    z[2,1,5]  R1303     -2.1886758506298065e-02
    z[2,1,5]  R1304     -5.5067169666290283e-01
    z[2,1,5]  R1305     -9.6480071544647217e-02
    z[2,1,5]  R1306     7.9776518046855927e-02
    z[2,1,5]  R1307     -0.0778428167104721
    z[2,1,5]  R1308     -9.3156717717647552e-02
    z[2,1,5]  R1309     1.4025831222534180e-01
    z[2,1,5]  R1310     -3.3763861656188965e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R1199     -1
    z[2,1,6]  R1200     1
    z[2,1,6]  R1201     2.6852054521441460e-02
    z[2,1,6]  R1202     -9.1749869287014008e-02
    z[2,1,6]  R1203     1.9953864812850952e-01
    z[2,1,6]  R1204     -5.5594801902770996e-02
    z[2,1,6]  R1205     4.1194528341293335e-02
    z[2,1,6]  R1206     -8.8617682456970215e-02
    z[2,1,6]  R1207     8.8885044679045677e-03
    z[2,1,6]  R1208     -4.1980691254138947e-02
    z[2,1,6]  R1209     3.2020047307014465e-01
    z[2,1,6]  R1210     2.5830745697021484e-01
    z[2,1,6]  R1211     -1.3043585419654846e-01
    z[2,1,6]  R1212     -1.0522356629371643e-01
    z[2,1,6]  R1213     -2.6178336702287197e-03
    z[2,1,6]  R1214     -2.2865532338619232e-01
    z[2,1,6]  R1215     -1.5521687269210815e-01
    z[2,1,6]  R1216     -3.8367825746536255e-01
    z[2,1,6]  R1217     2.7135983109474182e-01
    z[2,1,6]  R1218     2.7077487111091614e-01
    z[2,1,6]  R1219     3.1675910949707031e-01
    z[2,1,6]  R1220     2.7105422690510750e-02
    z[2,1,6]  R1221     4.3651174753904343e-02
    z[2,1,6]  R1222     1.6516314819455147e-02
    z[2,1,6]  R1223     5.8261758089065552e-01
    z[2,1,6]  R1224     0.0882897898554802
    z[2,1,6]  R1225     -5.0918185710906982e-01
    z[2,1,6]  R1226     -3.4413103014230728e-02
    z[2,1,6]  R1227     -2.9413762688636780e-01
    z[2,1,6]  R1228     3.9203155040740967e-01
    z[2,1,6]  R1229     4.3268457055091858e-01
    z[2,1,6]  R1230     -1.0839474201202393e-01
    z[2,1,6]  R1231     6.3343368470668793e-02
    z[2,1,6]  R1232     0.25189009308815
    z[2,1,6]  R1233     6.6726314835250378e-03
    z[2,1,6]  R1234     -6.4489126205444336e-01
    z[2,1,6]  R1235     -3.4458079934120178e-01
    z[2,1,6]  R1236     2.3714034259319305e-01
    z[2,1,6]  R1237     2.4156366288661957e-01
    z[2,1,6]  R1238     1.7024591565132141e-01
    z[2,1,6]  R1239     5.6444126367568970e-01
    z[2,1,6]  R1240     -2.3695375025272369e-01
    z[2,1,6]  R1241     2.5978598743677139e-02
    z[2,1,6]  R1242     2.5896498560905457e-01
    z[2,1,6]  R1243     2.2164984047412872e-01
    z[2,1,6]  R1244     3.9759743958711624e-03
    z[2,1,6]  R1245     -1.1250501126050949e-01
    z[2,1,6]  R1246     1.7408958077430725e-01
    z[2,1,6]  R1247     1.3000544905662537e-01
    z[2,1,6]  R1248     -2.1116336807608604e-02
    z[2,1,6]  R1249     2.4243091046810150e-01
    z[2,1,6]  R1250     4.6817961335182190e-01
    z[2,1,6]  R1251     -2.7770814299583435e-01
    z[2,1,6]  R1252     -4.0957968682050705e-02
    z[2,1,6]  R1253     1.5679925680160522e-02
    z[2,1,6]  R1254     2.3461225628852844e-01
    z[2,1,6]  R1255     -6.1612367630004883e-01
    z[2,1,6]  R1256     -0.510966956615448
    z[2,1,6]  R1257     2.5119778513908386e-01
    z[2,1,6]  R1258     1.0444530844688416e-01
    z[2,1,6]  R1259     -2.8750613331794739e-01
    z[2,1,6]  R1260     -5.2096154540777206e-02
    z[2,1,6]  R1261     -6.3579088449478149e-01
    z[2,1,6]  R1262     -3.9047278463840485e-02
    z[2,1,6]  R1263     -5.7067770510911942e-02
    z[2,1,6]  R1264     -4.9153414368629456e-01
    z[2,1,6]  R1265     -3.9015471935272217e-01
    z[2,1,6]  R1266     2.3470519483089447e-01
    z[2,1,6]  R1267     -6.4734026789665222e-02
    z[2,1,6]  R1268     7.1323089301586151e-02
    z[2,1,6]  R1269     0.603255033493042
    z[2,1,6]  R1270     -1.8306757509708405e-01
    z[2,1,6]  R1271     -6.2811499834060669e-01
    z[2,1,6]  R1272     -5.8990508317947388e-01
    z[2,1,6]  R1273     4.7271189093589783e-01
    z[2,1,6]  R1274     -3.1926280260086060e-01
    z[2,1,6]  R1275     -1.4661435782909393e-01
    z[2,1,6]  R1276     5.3604024648666382e-01
    z[2,1,6]  R1277     -4.1475647687911987e-01
    z[2,1,6]  R1278     -1.1077469587326050e-01
    z[2,1,6]  R1279     -4.6451419591903687e-01
    z[2,1,6]  R1280     5.5887496471405029e-01
    z[2,1,6]  R1281     -1.7274679243564606e-01
    z[2,1,6]  R1282     1.2963366508483887e-01
    z[2,1,6]  R1283     5.8247900009155273e-01
    z[2,1,6]  R1284     1.6660098731517792e-01
    z[2,1,6]  R1285     -1.5399083495140076e-01
    z[2,1,6]  R1286     1.0274005681276321e-01
    z[2,1,6]  R1287     -1.6138151288032532e-01
    z[2,1,6]  R1288     -2.3751424252986908e-01
    z[2,1,6]  R1289     -4.2117387056350708e-01
    z[2,1,6]  R1290     5.3832399845123291e-01
    z[2,1,6]  R1291     -9.5269419252872467e-02
    z[2,1,6]  R1292     -0.337056040763855
    z[2,1,6]  R1293     -3.3285051584243774e-01
    z[2,1,6]  R1294     0.341945618391037
    z[2,1,6]  R1295     -2.7795326709747314e-01
    z[2,1,6]  R1296     -2.9696673154830933e-01
    z[2,1,6]  R1297     6.0295134782791138e-01
    z[2,1,6]  R1298     3.2087239623069763e-01
    z[2,1,6]  R1299     3.1672829389572144e-01
    z[2,1,6]  R1300     -2.7522730827331543e-01
    z[2,1,6]  R1301     -3.6352673172950745e-01
    z[2,1,6]  R1302     3.1183210015296936e-01
    z[2,1,6]  R1303     -0.522093653678894
    z[2,1,6]  R1304     8.4165006875991821e-02
    z[2,1,6]  R1305     4.1922721266746521e-01
    z[2,1,6]  R1306     -1.0764741152524948e-01
    z[2,1,6]  R1307     -8.9159741997718811e-02
    z[2,1,6]  R1308     1.8927218019962311e-01
    z[2,1,6]  R1309     -0.0878983587026596
    z[2,1,6]  R1310     9.3493327498435974e-02
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R1311     -1
    z[1,3,0]  R1312     1
    z[1,3,0]  R1325     -2.7622032165527344e-01
    z[1,3,0]  R1326     7.2170570492744446e-02
    z[1,3,0]  R1327     -2.1570110321044922e-01
    z[1,3,0]  R1328     -1.9471928477287292e-01
    z[1,3,0]  R1329     1.9177286326885223e-01
    z[1,3,0]  R1330     -9.2172406613826752e-02
    z[1,3,0]  R1331     -2.2240076959133148e-01
    z[1,3,0]  R1332     -1.5014803968369961e-02
    z[1,3,0]  R1333     7.7013963460922241e-01
    z[1,3,0]  R1334     3.6218479275703430e-01
    z[1,3,0]  R1335     -9.2576093971729279e-02
    z[1,3,0]  R1336     -6.1049032211303711e-01
    z[1,3,0]  R1337     2.5484472513198853e-01
    z[1,3,0]  R1338     5.2137277089059353e-03
    z[1,3,0]  R1339     -0.604136049747467
    z[1,3,0]  R1340     -8.2193642854690552e-01
    z[1,3,0]  R1341     0.663940966129303
    z[1,3,0]  R1342     4.0393376350402832e-01
    z[1,3,0]  R1343     -2.0123668015003204e-01
    z[1,3,0]  R1344     -3.8823267817497253e-01
    z[1,3,0]  R1345     -2.7819445729255676e-01
    z[1,3,0]  R1346     -1.8396872282028198e-01
    z[1,3,0]  R1347     -0.406222403049469
    z[1,3,0]  R1348     -1.1003332585096359e-01
    z[1,3,0]  R1349     -9.8708763718605042e-02
    z[1,3,0]  R1350     4.4714215397834778e-01
    z[1,3,0]  R1351     -3.8053756952285767e-01
    z[1,3,0]  R1352     2.1977389231324196e-02
    z[1,3,0]  R1353     -1.4427816867828369e-01
    z[1,3,0]  R1354     8.8784933090209961e-01
    z[1,3,0]  R1355     -1.9358487427234650e-01
    z[1,3,0]  R1356     -2.9861995577812195e-01
    z[1,3,0]  R1357     -2.8213111683726311e-02
    z[1,3,0]  R1358     1.6459727287292480e-01
    z[1,3,0]  R1359     3.3137798309326172e-01
    z[1,3,0]  R1360     2.3689137399196625e-01
    z[1,3,0]  R1361     -2.9080209136009216e-01
    z[1,3,0]  R1362     -5.5311852693557739e-01
    z[1,3,0]  R1363     5.9021119959652424e-03
    z[1,3,0]  R1364     5.5397635698318481e-01
    z[1,3,0]  R1365     1.1108215898275375e-01
    z[1,3,0]  R1366     -3.1310665607452393e-01
    z[1,3,0]  R1367     0.181345596909523
    z[1,3,0]  R1368     -9.9855475127696991e-02
    z[1,3,0]  R1369     -4.7264367341995239e-01
    z[1,3,0]  R1370     1.7552487552165985e-01
    z[1,3,0]  R1371     1.1585873365402222e-01
    z[1,3,0]  R1372     2.7301779389381409e-01
    z[1,3,0]  R1373     3.6947306990623474e-01
    z[1,3,0]  R1374     1.2942981719970703e-01
    z[1,3,0]  R1375     1.4334422349929810e-01
    z[1,3,0]  R1376     -2.0050154998898506e-03
    z[1,3,0]  R1377     -3.4409871697425842e-01
    z[1,3,0]  R1378     -0.0753057599067688
    z[1,3,0]  R1379     -4.1856479644775391e-01
    z[1,3,0]  R1380     -5.2887761592864990e-01
    z[1,3,0]  R1381     3.8372308015823364e-01
    z[1,3,0]  R1382     1.8392139673233032e-01
    z[1,3,0]  R1383     0.756458580493927
    z[1,3,0]  R1384     4.1215223073959351e-01
    z[1,3,0]  R1385     -2.9381206259131432e-02
    z[1,3,0]  R1386     -1.9953933358192444e-01
    z[1,3,0]  R1387     0.0612550750374794
    z[1,3,0]  R1388     -5.5652207136154175e-01
    z[1,3,0]  R1389     2.4315534532070160e-01
    z[1,3,0]  R1390     8.9159369468688965e-01
    z[1,3,0]  R1391     8.5959982872009277e-01
    z[1,3,0]  R1392     8.3808708190917969e-01
    z[1,3,0]  R1393     8.2671457529067993e-01
    z[1,3,0]  R1394     8.2864439487457275e-01
    z[1,3,0]  R1395     -6.0292345285415649e-01
    z[1,3,0]  R1396     -5.9713470935821533e-01
    z[1,3,0]  R1397     -7.9646384716033936e-01
    z[1,3,0]  R1398     0.593394935131073
    z[1,3,0]  R1399     -0.430400013923645
    z[1,3,0]  R1400     3.6738941073417664e-01
    z[1,3,0]  R1401     6.8841701745986938e-01
    z[1,3,0]  R1402     2.7344632148742676e-01
    z[1,3,0]  R1403     3.5563737154006958e-01
    z[1,3,0]  R1404     4.9206703901290894e-01
    z[1,3,0]  R1405     -2.8547435998916626e-01
    z[1,3,0]  R1406     -1.9855169579386711e-02
    z[1,3,0]  R1407     -7.0916842669248581e-03
    z[1,3,0]  R1408     -2.0397590473294258e-02
    z[1,3,0]  R1409     -6.5713502466678619e-02
    z[1,3,0]  R1410     3.0177175998687744e-01
    z[1,3,0]  R1411     3.8811814785003662e-01
    z[1,3,0]  R1412     -1.8501804769039154e-01
    z[1,3,0]  R1413     0.167601078748703
    z[1,3,0]  R1414     8.1268265843391418e-02
    z[1,3,0]  R1415     5.1078337430953979e-01
    z[1,3,0]  R1416     -2.2165615856647491e-01
    z[1,3,0]  R1417     7.2538322210311890e-01
    z[1,3,0]  R1418     8.0320823192596436e-01
    z[1,3,0]  R1419     5.4646110534667969e-01
    z[1,3,0]  R1420     4.4635590910911560e-01
    z[1,3,0]  R1421     5.7215999811887741e-02
    z[1,3,0]  R1422     6.9971328973770142e-01
    z[1,3,0]  R1423     0.713864803314209
    z[1,3,0]  R1424     7.7606225013732910e-01
    z[1,3,0]  R1425     -0.397827684879303
    z[1,3,0]  R1426     7.2482812404632568e-01
    z[1,3,0]  R1427     -2.4095913767814636e-01
    z[1,3,0]  R1428     0.813280463218689
    z[1,3,0]  R1429     1.3921824283897877e-02
    z[1,3,0]  R1430     6.2162774801254272e-01
    z[1,3,0]  R1431     5.1198744773864746e-01
    z[1,3,0]  R1432     6.4981174468994141e-01
    z[1,3,0]  R1433     -4.9261572957038879e-01
    z[1,3,0]  R1434     2.5793758034706116e-01
    z[1,3,0]  R1435     6.9175004959106445e-02
    z[1,3,0]  R1436     -3.7531760334968567e-01
    z[1,3,0]  R1437     -4.9100264906883240e-02
    z[1,3,0]  R1438     3.8662287592887878e-01
    z[1,3,0]  R1439     7.8889721632003784e-01
    z[1,3,0]  R1440     -3.9210504293441772e-01
    z[1,3,0]  R1441     7.3289644718170166e-01
    z[1,3,0]  R1442     1.8111538887023926e-01
    z[1,3,0]  R1443     -3.0878129601478577e-01
    z[1,3,0]  R1444     -3.5077667236328125e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R1313     -1
    z[1,3,1]  R1314     1
    z[1,3,1]  R1325     5.7023260742425919e-02
    z[1,3,1]  R1326     -4.0100085735321045e-01
    z[1,3,1]  R1327     -4.0556874871253967e-01
    z[1,3,1]  R1328     -4.6332615613937378e-01
    z[1,3,1]  R1329     -2.3702657222747803e-01
    z[1,3,1]  R1330     2.2285167872905731e-01
    z[1,3,1]  R1331     2.9661893844604492e-01
    z[1,3,1]  R1332     -3.8518407940864563e-01
    z[1,3,1]  R1333     9.2216655611991882e-02
    z[1,3,1]  R1334     -3.6164233088493347e-01
    z[1,3,1]  R1335     -6.8206888437271118e-01
    z[1,3,1]  R1336     -5.1864419132471085e-02
    z[1,3,1]  R1337     -5.4454110562801361e-02
    z[1,3,1]  R1338     0.0367298349738121
    z[1,3,1]  R1339     -3.0298924073576927e-02
    z[1,3,1]  R1340     6.8774081766605377e-02
    z[1,3,1]  R1341     1.3289210200309753e-01
    z[1,3,1]  R1342     -1.5048886835575104e-01
    z[1,3,1]  R1343     -2.6078957319259644e-01
    z[1,3,1]  R1344     3.0239865183830261e-01
    z[1,3,1]  R1345     -3.2169643044471741e-01
    z[1,3,1]  R1346     3.1752693653106689e-01
    z[1,3,1]  R1347     -2.7491134405136108e-01
    z[1,3,1]  R1348     -2.0878896117210388e-01
    z[1,3,1]  R1349     -4.4018852710723877e-01
    z[1,3,1]  R1350     -1.1904118955135345e-01
    z[1,3,1]  R1351     3.8342788815498352e-01
    z[1,3,1]  R1352     7.4422186613082886e-01
    z[1,3,1]  R1353     -2.3468953371047974e-01
    z[1,3,1]  R1354     0.400115966796875
    z[1,3,1]  R1355     -1.1934275925159454e-01
    z[1,3,1]  R1356     6.0335206799209118e-03
    z[1,3,1]  R1357     2.9801445081830025e-02
    z[1,3,1]  R1358     3.9609622955322266e-01
    z[1,3,1]  R1359     0.460801899433136
    z[1,3,1]  R1360     -4.2347031831741333e-01
    z[1,3,1]  R1361     5.9909218549728394e-01
    z[1,3,1]  R1362     -2.5118863582611084e-01
    z[1,3,1]  R1363     -4.5285689830780029e-01
    z[1,3,1]  R1364     2.9667595028877258e-01
    z[1,3,1]  R1365     -4.4780600070953369e-01
    z[1,3,1]  R1366     0.479547381401062
    z[1,3,1]  R1367     -1.1395521461963654e-01
    z[1,3,1]  R1368     5.7864004373550415e-01
    z[1,3,1]  R1369     -2.3511280119419098e-01
    z[1,3,1]  R1370     3.3842352032661438e-01
    z[1,3,1]  R1371     -6.4883500337600708e-01
    z[1,3,1]  R1372     -5.0559818744659424e-01
    z[1,3,1]  R1373     0.500224769115448
    z[1,3,1]  R1374     -1.5252690762281418e-02
    z[1,3,1]  R1375     2.0094932615756989e-01
    z[1,3,1]  R1376     -4.3286976218223572e-01
    z[1,3,1]  R1377     3.8947391510009766e-01
    z[1,3,1]  R1378     4.8887810111045837e-01
    z[1,3,1]  R1379     -1.6817826032638550e-01
    z[1,3,1]  R1380     -1.7984431982040405e-01
    z[1,3,1]  R1381     1.6541364789009094e-01
    z[1,3,1]  R1382     8.7534934282302856e-02
    z[1,3,1]  R1383     1.3398897647857666e-01
    z[1,3,1]  R1384     -3.3120420575141907e-01
    z[1,3,1]  R1385     3.9884641766548157e-01
    z[1,3,1]  R1386     4.5949053764343262e-01
    z[1,3,1]  R1387     1.0078227519989014e-01
    z[1,3,1]  R1388     2.0944228395819664e-02
    z[1,3,1]  R1389     -4.8049259185791016e-01
    z[1,3,1]  R1390     3.4001204371452332e-01
    z[1,3,1]  R1391     2.5614374876022339e-01
    z[1,3,1]  R1392     0.4011210501194
    z[1,3,1]  R1393     3.2489171624183655e-01
    z[1,3,1]  R1394     2.7052381634712219e-01
    z[1,3,1]  R1395     -4.9979650974273682e-01
    z[1,3,1]  R1396     -3.7981674075126648e-01
    z[1,3,1]  R1397     -2.0791263878345490e-01
    z[1,3,1]  R1398     3.7678810954093933e-01
    z[1,3,1]  R1399     -4.3685835599899292e-01
    z[1,3,1]  R1400     7.3186588287353516e-01
    z[1,3,1]  R1401     5.6335467100143433e-01
    z[1,3,1]  R1402     -5.8704257011413574e-01
    z[1,3,1]  R1403     2.5529748201370239e-01
    z[1,3,1]  R1404     -3.0720129609107971e-01
    z[1,3,1]  R1405     -4.9055501818656921e-01
    z[1,3,1]  R1406     -8.5490924119949341e-01
    z[1,3,1]  R1407     -7.7586907148361206e-01
    z[1,3,1]  R1408     -7.6240330934524536e-01
    z[1,3,1]  R1409     -6.7092359066009521e-01
    z[1,3,1]  R1410     -0.72418612241745
    z[1,3,1]  R1411     -6.1174947023391724e-01
    z[1,3,1]  R1412     -6.1788523197174072e-01
    z[1,3,1]  R1413     -9.1981792449951172e-01
    z[1,3,1]  R1414     -5.2808022499084473e-01
    z[1,3,1]  R1415     5.4192101955413818e-01
    z[1,3,1]  R1416     -8.2055938243865967e-01
    z[1,3,1]  R1417     4.7175922989845276e-01
    z[1,3,1]  R1418     1.1841738224029541e-01
    z[1,3,1]  R1419     2.9551774263381958e-01
    z[1,3,1]  R1420     0.809660017490387
    z[1,3,1]  R1421     -2.1381278336048126e-01
    z[1,3,1]  R1422     -1.8627347052097321e-01
    z[1,3,1]  R1423     0.00829958077520132
    z[1,3,1]  R1424     -3.7942326068878174e-01
    z[1,3,1]  R1425     -4.5845040678977966e-01
    z[1,3,1]  R1426     2.7378877997398376e-01
    z[1,3,1]  R1427     -2.6002889871597290e-01
    z[1,3,1]  R1428     -3.5557288210839033e-03
    z[1,3,1]  R1429     -2.9835966229438782e-01
    z[1,3,1]  R1430     -3.6772534251213074e-01
    z[1,3,1]  R1431     -4.3924498558044434e-01
    z[1,3,1]  R1432     -2.4902668595314026e-01
    z[1,3,1]  R1433     1.4090338349342346e-01
    z[1,3,1]  R1434     3.8887679576873779e-01
    z[1,3,1]  R1435     -7.4931782484054565e-01
    z[1,3,1]  R1436     -0.632306694984436
    z[1,3,1]  R1437     -7.8275579214096069e-01
    z[1,3,1]  R1438     -6.6907012462615967e-01
    z[1,3,1]  R1439     -2.8633108735084534e-01
    z[1,3,1]  R1440     -0.757557213306427
    z[1,3,1]  R1441     -3.0009558796882629e-01
    z[1,3,1]  R1442     3.3315002918243408e-01
    z[1,3,1]  R1443     8.9879298210144043e-01
    z[1,3,1]  R1444     8.9376252889633179e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R1315     -1
    z[1,3,2]  R1316     1
    z[1,3,2]  R1325     5.7882523536682129e-01
    z[1,3,2]  R1326     4.1696330904960632e-01
    z[1,3,2]  R1327     5.1958316564559937e-01
    z[1,3,2]  R1328     5.7546877861022949e-01
    z[1,3,2]  R1329     2.1274326741695404e-01
    z[1,3,2]  R1330     7.5553268194198608e-01
    z[1,3,2]  R1331     4.0897557139396667e-01
    z[1,3,2]  R1332     9.6684433519840240e-03
    z[1,3,2]  R1333     -3.0653487890958786e-02
    z[1,3,2]  R1334     7.4481427669525146e-02
    z[1,3,2]  R1335     -4.2489755153656006e-01
    z[1,3,2]  R1336     -2.0523147657513618e-02
    z[1,3,2]  R1337     -3.4373795986175537e-01
    z[1,3,2]  R1338     9.5099993050098419e-02
    z[1,3,2]  R1339     -2.2712003439664841e-02
    z[1,3,2]  R1340     2.0225118845701218e-02
    z[1,3,2]  R1341     -8.4506928920745850e-02
    z[1,3,2]  R1342     -1.7085234820842743e-01
    z[1,3,2]  R1343     -9.8722055554389954e-02
    z[1,3,2]  R1344     -1.4519126713275909e-01
    z[1,3,2]  R1345     -2.3931415379047394e-01
    z[1,3,2]  R1346     -3.5749744623899460e-02
    z[1,3,2]  R1347     4.3033313751220703e-01
    z[1,3,2]  R1348     2.3229060694575310e-02
    z[1,3,2]  R1349     -6.8220630288124084e-02
    z[1,3,2]  R1350     -2.4715360999107361e-01
    z[1,3,2]  R1351     3.8568194955587387e-02
    z[1,3,2]  R1352     3.6008810997009277e-01
    z[1,3,2]  R1353     1.1655066907405853e-01
    z[1,3,2]  R1354     -1.4073415659368038e-02
    z[1,3,2]  R1355     3.5025379620492458e-03
    z[1,3,2]  R1356     2.5871858000755310e-01
    z[1,3,2]  R1357     5.0503186881542206e-02
    z[1,3,2]  R1358     -1.9696229696273804e-01
    z[1,3,2]  R1359     1.0958162695169449e-01
    z[1,3,2]  R1360     -3.6883754655718803e-03
    z[1,3,2]  R1361     8.8690489530563354e-02
    z[1,3,2]  R1362     9.6120364964008331e-02
    z[1,3,2]  R1363     2.3620733618736267e-01
    z[1,3,2]  R1364     -8.8324621319770813e-02
    z[1,3,2]  R1365     -4.0031763911247253e-01
    z[1,3,2]  R1366     1.7647184431552887e-01
    z[1,3,2]  R1367     2.7075189352035522e-01
    z[1,3,2]  R1368     5.7719075679779053e-01
    z[1,3,2]  R1369     8.3714880049228668e-02
    z[1,3,2]  R1370     -2.6952880620956421e-01
    z[1,3,2]  R1371     1.6323316097259521e-01
    z[1,3,2]  R1372     -2.3205693066120148e-01
    z[1,3,2]  R1373     7.0322789251804352e-02
    z[1,3,2]  R1374     6.2086915969848633e-01
    z[1,3,2]  R1375     2.3653939366340637e-02
    z[1,3,2]  R1376     -2.4569955468177795e-01
    z[1,3,2]  R1377     3.2196617126464844e-01
    z[1,3,2]  R1378     4.1821566224098206e-01
    z[1,3,2]  R1379     3.5133041441440582e-02
    z[1,3,2]  R1380     -1.4320272952318192e-02
    z[1,3,2]  R1381     1.5297865867614746e-01
    z[1,3,2]  R1382     6.3117647171020508e-01
    z[1,3,2]  R1383     -1.8626330420374870e-02
    z[1,3,2]  R1384     -3.0767264962196350e-01
    z[1,3,2]  R1385     2.6093924045562744e-01
    z[1,3,2]  R1386     3.9941665530204773e-01
    z[1,3,2]  R1387     -2.3553118109703064e-01
    z[1,3,2]  R1388     -6.9350576959550381e-03
    z[1,3,2]  R1389     1.9941753149032593e-01
    z[1,3,2]  R1390     2.5417020916938782e-01
    z[1,3,2]  R1391     -2.1761699020862579e-01
    z[1,3,2]  R1392     6.5196588635444641e-02
    z[1,3,2]  R1393     -3.3122289180755615e-01
    z[1,3,2]  R1394     -3.2163041830062866e-01
    z[1,3,2]  R1395     -3.4730517864227295e-01
    z[1,3,2]  R1396     -1.4648345112800598e-01
    z[1,3,2]  R1397     -4.0350863337516785e-01
    z[1,3,2]  R1398     7.0236515998840332e-01
    z[1,3,2]  R1399     -1.2193604372441769e-02
    z[1,3,2]  R1400     5.3562176227569580e-01
    z[1,3,2]  R1401     1.8169675767421722e-01
    z[1,3,2]  R1402     -3.1884562224149704e-02
    z[1,3,2]  R1403     5.2796679735183716e-01
    z[1,3,2]  R1404     5.4261833429336548e-01
    z[1,3,2]  R1405     -7.4606072902679443e-01
    z[1,3,2]  R1406     1.7190891504287720e-01
    z[1,3,2]  R1407     -3.0966898798942566e-01
    z[1,3,2]  R1408     2.1271331608295441e-01
    z[1,3,2]  R1409     2.2867359220981598e-02
    z[1,3,2]  R1410     -1.0302006453275681e-01
    z[1,3,2]  R1411     -1.3841852545738220e-01
    z[1,3,2]  R1412     6.8635516799986362e-03
    z[1,3,2]  R1413     1.3173352181911469e-01
    z[1,3,2]  R1414     -1.1156410723924637e-01
    z[1,3,2]  R1415     3.9218932390213013e-01
    z[1,3,2]  R1416     -1.8157172203063965e-01
    z[1,3,2]  R1417     3.2757565379142761e-01
    z[1,3,2]  R1418     1.9680313766002655e-01
    z[1,3,2]  R1419     4.5352223515510559e-01
    z[1,3,2]  R1420     2.9588249325752258e-01
    z[1,3,2]  R1421     -5.0353008508682251e-01
    z[1,3,2]  R1422     3.9402994513511658e-01
    z[1,3,2]  R1423     3.4777870774269104e-01
    z[1,3,2]  R1424     3.1732836365699768e-01
    z[1,3,2]  R1425     -5.5367767810821533e-01
    z[1,3,2]  R1426     5.6241697072982788e-01
    z[1,3,2]  R1427     -5.9100198745727539e-01
    z[1,3,2]  R1428     3.3056426048278809e-01
    z[1,3,2]  R1429     -2.4744980037212372e-01
    z[1,3,2]  R1430     2.2165837883949280e-01
    z[1,3,2]  R1431     1.9918750226497650e-01
    z[1,3,2]  R1432     0.0682726576924324
    z[1,3,2]  R1433     -1.8451346457004547e-01
    z[1,3,2]  R1434     -1.3119451701641083e-01
    z[1,3,2]  R1435     1.2991547584533691e-02
    z[1,3,2]  R1436     -3.0424109101295471e-01
    z[1,3,2]  R1437     1.2071663886308670e-01
    z[1,3,2]  R1438     -3.4740817500278354e-04
    z[1,3,2]  R1439     3.3287355303764343e-01
    z[1,3,2]  R1440     1.1665407568216324e-01
    z[1,3,2]  R1441     4.0914547443389893e-01
    z[1,3,2]  R1442     -3.4522455930709839e-01
    z[1,3,2]  R1443     -5.6712850928306580e-02
    z[1,3,2]  R1444     -1.4610143005847931e-01
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R1317     -1
    z[1,3,3]  R1318     1
    z[1,3,3]  R1325     -2.8136521577835083e-01
    z[1,3,3]  R1326     -5.2662551403045654e-01
    z[1,3,3]  R1327     -6.1233186721801758e-01
    z[1,3,3]  R1328     -3.1960594654083252e-01
    z[1,3,3]  R1329     -4.3368527293205261e-01
    z[1,3,3]  R1330     -5.1076197624206543e-01
    z[1,3,3]  R1331     -8.0525797605514526e-01
    z[1,3,3]  R1332     -5.2254360914230347e-01
    z[1,3,3]  R1333     -4.2296999692916870e-01
    z[1,3,3]  R1334     4.8478193581104279e-02
    z[1,3,3]  R1335     -1.8497726321220398e-01
    z[1,3,3]  R1336     7.9207018017768860e-02
    z[1,3,3]  R1337     3.8945192098617554e-01
    z[1,3,3]  R1338     0.422821044921875
    z[1,3,3]  R1339     -2.8210881352424622e-01
    z[1,3,3]  R1340     -1.1807091534137726e-01
    z[1,3,3]  R1341     3.5757082700729370e-01
    z[1,3,3]  R1342     3.3467337489128113e-01
    z[1,3,3]  R1343     2.5352901220321655e-01
    z[1,3,3]  R1344     3.3100441098213196e-01
    z[1,3,3]  R1345     -5.6162250041961670e-01
    z[1,3,3]  R1346     5.2022719383239746e-01
    z[1,3,3]  R1347     5.4889374971389771e-01
    z[1,3,3]  R1348     4.7716978192329407e-01
    z[1,3,3]  R1349     -3.4345608949661255e-01
    z[1,3,3]  R1350     3.9964485168457031e-01
    z[1,3,3]  R1351     3.8020107150077820e-01
    z[1,3,3]  R1352     3.6080777645111084e-01
    z[1,3,3]  R1353     3.6020430922508240e-01
    z[1,3,3]  R1354     1.0170537978410721e-01
    z[1,3,3]  R1355     -0.731119692325592
    z[1,3,3]  R1356     5.0512790679931641e-01
    z[1,3,3]  R1357     4.7510275244712830e-01
    z[1,3,3]  R1358     4.7052279114723206e-01
    z[1,3,3]  R1359     4.8424473404884338e-01
    z[1,3,3]  R1360     4.5583185553550720e-01
    z[1,3,3]  R1361     4.4839361310005188e-01
    z[1,3,3]  R1362     4.3676459789276123e-01
    z[1,3,3]  R1363     4.2668148875236511e-01
    z[1,3,3]  R1364     4.2736229300498962e-01
    z[1,3,3]  R1365     -7.1151775121688843e-01
    z[1,3,3]  R1366     5.5927473306655884e-01
    z[1,3,3]  R1367     5.3567820787429810e-01
    z[1,3,3]  R1368     0.525505781173706
    z[1,3,3]  R1369     4.9212706089019775e-01
    z[1,3,3]  R1370     4.8334461450576782e-01
    z[1,3,3]  R1371     4.8629650473594666e-01
    z[1,3,3]  R1372     4.3330281972885132e-01
    z[1,3,3]  R1373     4.1259589791297913e-01
    z[1,3,3]  R1374     4.3963640928268433e-01
    z[1,3,3]  R1375     0.805002748966217
    z[1,3,3]  R1376     -7.4258393049240112e-01
    z[1,3,3]  R1377     6.9236713647842407e-01
    z[1,3,3]  R1378     6.2224221229553223e-01
    z[1,3,3]  R1379     5.1679807901382446e-01
    z[1,3,3]  R1380     -5.6394052505493164e-01
    z[1,3,3]  R1381     0.447330117225647
    z[1,3,3]  R1382     4.2527988553047180e-01
    z[1,3,3]  R1383     4.0102961659431458e-01
    z[1,3,3]  R1384     3.7532398104667664e-01
    z[1,3,3]  R1385     -5.9658187627792358e-01
    z[1,3,3]  R1386     6.4064908027648926e-01
    z[1,3,3]  R1387     5.1169615983963013e-01
    z[1,3,3]  R1388     -3.3814874291419983e-01
    z[1,3,3]  R1389     5.0888514518737793e-01
    z[1,3,3]  R1390     -5.9023287147283554e-02
    z[1,3,3]  R1391     -2.7531739324331284e-02
    z[1,3,3]  R1392     -2.9218414425849915e-01
    z[1,3,3]  R1393     -2.6991435885429382e-01
    z[1,3,3]  R1394     -9.8402373492717743e-02
    z[1,3,3]  R1395     -4.2700907588005066e-01
    z[1,3,3]  R1396     -1.3089103996753693e-01
    z[1,3,3]  R1397     5.0435356795787811e-02
    z[1,3,3]  R1398     -1.8006978556513786e-02
    z[1,3,3]  R1399     -5.4041433334350586e-01
    z[1,3,3]  R1400     -1.6749298572540283e-01
    z[1,3,3]  R1401     2.4034446477890015e-01
    z[1,3,3]  R1402     0.312175452709198
    z[1,3,3]  R1403     -1.5765495598316193e-01
    z[1,3,3]  R1404     -4.5238324999809265e-01
    z[1,3,3]  R1405     6.0132112354040146e-02
    z[1,3,3]  R1406     -3.5726919770240784e-01
    z[1,3,3]  R1407     1.7948009073734283e-01
    z[1,3,3]  R1408     1.7335766926407814e-02
    z[1,3,3]  R1409     0.554954469203949
    z[1,3,3]  R1410     4.6995395421981812e-01
    z[1,3,3]  R1411     6.5578943490982056e-01
    z[1,3,3]  R1412     5.3399151563644409e-01
    z[1,3,3]  R1413     1.7057047784328461e-01
    z[1,3,3]  R1414     0.805041491985321
    z[1,3,3]  R1415     1.4910751581192017e-01
    z[1,3,3]  R1416     3.3688324689865112e-01
    z[1,3,3]  R1417     1.6703270375728607e-01
    z[1,3,3]  R1418     -1.6435244679450989e-01
    z[1,3,3]  R1419     -2.5326707959175110e-01
    z[1,3,3]  R1420     1.2513893842697144e-01
    z[1,3,3]  R1421     -2.2047157585620880e-01
    z[1,3,3]  R1422     -3.8990822434425354e-01
    z[1,3,3]  R1423     -2.3397500813007355e-01
    z[1,3,3]  R1424     4.9153860658407211e-02
    z[1,3,3]  R1425     -9.9736951291561127e-02
    z[1,3,3]  R1426     1.5958513319492340e-01
    z[1,3,3]  R1427     -1.8974952399730682e-02
    z[1,3,3]  R1428     -8.5029698908329010e-02
    z[1,3,3]  R1429     -7.3701471090316772e-01
    z[1,3,3]  R1430     -5.1005744934082031e-01
    z[1,3,3]  R1431     -3.5362154245376587e-01
    z[1,3,3]  R1432     -3.0872595310211182e-01
    z[1,3,3]  R1433     9.6516653895378113e-02
    z[1,3,3]  R1434     0.767477810382843
    z[1,3,3]  R1435     -5.9185636043548584e-01
    z[1,3,3]  R1436     -1.9000720977783203e-01
    z[1,3,3]  R1437     3.6175560951232910e-01
    z[1,3,3]  R1438     3.6101114749908447e-01
    z[1,3,3]  R1439     -1.9300375878810883e-01
    z[1,3,3]  R1440     2.0218791067600250e-01
    z[1,3,3]  R1441     2.9652403667569160e-02
    z[1,3,3]  R1442     7.5273603200912476e-01
    z[1,3,3]  R1443     1.7682921886444092e-01
    z[1,3,3]  R1444     -1.7934386432170868e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R1319     -1
    z[1,3,4]  R1320     1
    z[1,3,4]  R1325     6.0072422027587891e-01
    z[1,3,4]  R1326     2.4796561896800995e-01
    z[1,3,4]  R1327     2.6029223203659058e-01
    z[1,3,4]  R1328     3.1332916021347046e-01
    z[1,3,4]  R1329     2.6376459002494812e-01
    z[1,3,4]  R1330     -2.0386783778667450e-01
    z[1,3,4]  R1331     3.7150572985410690e-02
    z[1,3,4]  R1332     -7.5935405492782593e-01
    z[1,3,4]  R1333     -0.399393767118454
    z[1,3,4]  R1334     -7.1339696645736694e-01
    z[1,3,4]  R1335     4.7217461466789246e-01
    z[1,3,4]  R1336     -3.1844952702522278e-01
    z[1,3,4]  R1337     8.1103682518005371e-01
    z[1,3,4]  R1338     -7.1264576911926270e-01
    z[1,3,4]  R1339     -4.0418615937232971e-01
    z[1,3,4]  R1340     -1.7569592595100403e-01
    z[1,3,4]  R1341     5.8281880617141724e-01
    z[1,3,4]  R1342     -8.1347936391830444e-01
    z[1,3,4]  R1343     -6.7264097929000854e-01
    z[1,3,4]  R1344     0.714393138885498
    z[1,3,4]  R1345     2.0473514497280121e-01
    z[1,3,4]  R1346     7.4354684352874756e-01
    z[1,3,4]  R1347     -3.6610189080238342e-01
    z[1,3,4]  R1348     -6.7614614963531494e-01
    z[1,3,4]  R1349     -6.5717041492462158e-01
    z[1,3,4]  R1350     6.3501501083374023e-01
    z[1,3,4]  R1351     -2.0388266444206238e-01
    z[1,3,4]  R1352     -4.1412681341171265e-01
    z[1,3,4]  R1353     -1.8338575959205627e-01
    z[1,3,4]  R1354     0.08367870002985
    z[1,3,4]  R1355     -3.0239738523960114e-02
    z[1,3,4]  R1356     -4.8318862915039062e-01
    z[1,3,4]  R1357     5.0756323337554932e-01
    z[1,3,4]  R1358     -6.6026735305786133e-01
    z[1,3,4]  R1359     -5.5032426118850708e-01
    z[1,3,4]  R1360     -4.8070478439331055e-01
    z[1,3,4]  R1361     -2.4454867839813232e-01
    z[1,3,4]  R1362     5.6814938783645630e-01
    z[1,3,4]  R1363     -3.5311231017112732e-01
    z[1,3,4]  R1364     -2.4681656062602997e-01
    z[1,3,4]  R1365     2.4790546298027039e-01
    z[1,3,4]  R1366     -5.1099810749292374e-02
    z[1,3,4]  R1367     -4.8351773619651794e-01
    z[1,3,4]  R1368     -1.2792724370956421e-01
    z[1,3,4]  R1369     6.3539731502532959e-01
    z[1,3,4]  R1370     -5.8918994665145874e-01
    z[1,3,4]  R1371     -3.1173002719879150e-01
    z[1,3,4]  R1372     -5.7868313789367676e-01
    z[1,3,4]  R1373     0.40912064909935
    z[1,3,4]  R1374     -7.7711150050163269e-02
    z[1,3,4]  R1375     -5.3043740987777710e-01
    z[1,3,4]  R1376     2.0222522318363190e-01
    z[1,3,4]  R1377     -1.1678715795278549e-01
    z[1,3,4]  R1378     0.266841858625412
    z[1,3,4]  R1379     6.5220171213150024e-01
    z[1,3,4]  R1380     -4.9036750197410583e-01
    z[1,3,4]  R1381     4.0584853291511536e-01
    z[1,3,4]  R1382     -2.3033963143825531e-01
    z[1,3,4]  R1383     3.1694963574409485e-01
    z[1,3,4]  R1384     6.0401898622512817e-01
    z[1,3,4]  R1385     2.3337426781654358e-01
    z[1,3,4]  R1386     0.260204017162323
    z[1,3,4]  R1387     6.2906432151794434e-01
    z[1,3,4]  R1388     -5.1490652561187744e-01
    z[1,3,4]  R1389     -4.7561657428741455e-01
    z[1,3,4]  R1390     -5.8428540825843811e-02
    z[1,3,4]  R1391     -0.365177184343338
    z[1,3,4]  R1392     5.0869386643171310e-02
    z[1,3,4]  R1393     -3.2056987285614014e-02
    z[1,3,4]  R1394     -6.5538994967937469e-02
    z[1,3,4]  R1395     4.5822650194168091e-02
    z[1,3,4]  R1396     -7.5653657317161560e-02
    z[1,3,4]  R1397     -2.1640536189079285e-01
    z[1,3,4]  R1398     3.8729336112737656e-02
    z[1,3,4]  R1399     1.9678421318531036e-02
    z[1,3,4]  R1400     -5.0368376076221466e-02
    z[1,3,4]  R1401     2.0661942660808563e-01
    z[1,3,4]  R1402     -6.1629676818847656e-01
    z[1,3,4]  R1403     -1.2086541950702667e-01
    z[1,3,4]  R1404     -9.5076836645603180e-02
    z[1,3,4]  R1405     2.3639410734176636e-01
    z[1,3,4]  R1406     -2.0589524507522583e-01
    z[1,3,4]  R1407     7.2629086673259735e-02
    z[1,3,4]  R1408     -0.0833207443356514
    z[1,3,4]  R1409     -1.6864295303821564e-01
    z[1,3,4]  R1410     2.0364646613597870e-01
    z[1,3,4]  R1411     -1.3364824652671814e-01
    z[1,3,4]  R1412     -4.5083454251289368e-01
    z[1,3,4]  R1413     4.9073547124862671e-02
    z[1,3,4]  R1414     -5.7916458696126938e-02
    z[1,3,4]  R1415     -1.6701254248619080e-01
    z[1,3,4]  R1416     -2.2128391265869141e-01
    z[1,3,4]  R1417     2.5124964118003845e-01
    z[1,3,4]  R1418     3.5647621750831604e-01
    z[1,3,4]  R1419     -0.0849151685833931
    z[1,3,4]  R1420     1.7805512249469757e-01
    z[1,3,4]  R1421     5.1432031393051147e-01
    z[1,3,4]  R1422     1.7972512543201447e-01
    z[1,3,4]  R1423     -2.0716971158981323e-01
    z[1,3,4]  R1424     1.2676016986370087e-01
    z[1,3,4]  R1425     -1.0556812584400177e-01
    z[1,3,4]  R1426     -9.2531302943825722e-03
    z[1,3,4]  R1427     2.2112432122230530e-01
    z[1,3,4]  R1428     4.4771939516067505e-01
    z[1,3,4]  R1429     2.1878848969936371e-01
    z[1,3,4]  R1430     -7.0104807615280151e-02
    z[1,3,4]  R1431     2.0469594001770020e-01
    z[1,3,4]  R1432     0.0848376527428627
    z[1,3,4]  R1433     1.6652733087539673e-01
    z[1,3,4]  R1434     1.6612590849399567e-01
    z[1,3,4]  R1435     1.8307650089263916e-01
    z[1,3,4]  R1436     -2.4783807992935181e-01
    z[1,3,4]  R1437     -1.2648294866085052e-01
    z[1,3,4]  R1438     -3.7038561701774597e-01
    z[1,3,4]  R1439     2.1535834670066833e-01
    z[1,3,4]  R1440     -3.8356855511665344e-01
    z[1,3,4]  R1441     2.7675956487655640e-01
    z[1,3,4]  R1442     7.4886791408061981e-03
    z[1,3,4]  R1443     -1.6296248137950897e-01
    z[1,3,4]  R1444     -3.6126505583524704e-02
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R1321     -1
    z[1,3,5]  R1322     1
    z[1,3,5]  R1325     -3.8039609789848328e-01
    z[1,3,5]  R1326     -5.0422906875610352e-01
    z[1,3,5]  R1327     -0.164892315864563
    z[1,3,5]  R1328     -4.6466124057769775e-01
    z[1,3,5]  R1329     -7.6907074451446533e-01
    z[1,3,5]  R1330     -1.9561339914798737e-01
    z[1,3,5]  R1331     1.6903290152549744e-01
    z[1,3,5]  R1332     -3.4611638635396957e-02
    z[1,3,5]  R1333     -1.5801297500729561e-02
    z[1,3,5]  R1334     4.4854953885078430e-02
    z[1,3,5]  R1335     -1.0670714825391769e-01
    z[1,3,5]  R1336     -7.1751600503921509e-01
    z[1,3,5]  R1337     6.5067127346992493e-02
    z[1,3,5]  R1338     4.9789077043533325e-01
    z[1,3,5]  R1339     -1.0500293225049973e-01
    z[1,3,5]  R1340     -1.1569120734930038e-01
    z[1,3,5]  R1341     6.1202161014080048e-02
    z[1,3,5]  R1342     1.8338931724429131e-02
    z[1,3,5]  R1343     5.3137916326522827e-01
    z[1,3,5]  R1344     3.3780816197395325e-01
    z[1,3,5]  R1345     1.6777861863374710e-02
    z[1,3,5]  R1346     1.9756369292736053e-01
    z[1,3,5]  R1347     3.6830523610115051e-01
    z[1,3,5]  R1348     1.3149045407772064e-01
    z[1,3,5]  R1349     -2.9963439702987671e-01
    z[1,3,5]  R1350     -3.2674390077590942e-01
    z[1,3,5]  R1351     7.1859258413314819e-01
    z[1,3,5]  R1352     9.6005834639072418e-02
    z[1,3,5]  R1353     6.1905288696289062e-01
    z[1,3,5]  R1354     2.3936746641993523e-02
    z[1,3,5]  R1355     -1.3524423539638519e-01
    z[1,3,5]  R1356     8.5094437003135681e-02
    z[1,3,5]  R1357     5.3755539655685425e-01
    z[1,3,5]  R1358     1.3397021591663361e-01
    z[1,3,5]  R1359     -3.2710316777229309e-01
    z[1,3,5]  R1360     1.9581331312656403e-01
    z[1,3,5]  R1361     3.4025412797927856e-01
    z[1,3,5]  R1362     3.0967232584953308e-01
    z[1,3,5]  R1363     -4.6537414193153381e-01
    z[1,3,5]  R1364     -2.0345541834831238e-01
    z[1,3,5]  R1365     -1.7123125493526459e-01
    z[1,3,5]  R1366     5.5556458234786987e-01
    z[1,3,5]  R1367     1.4421881735324860e-01
    z[1,3,5]  R1368     -4.2163927108049393e-02
    z[1,3,5]  R1369     2.1139974892139435e-01
    z[1,3,5]  R1370     4.3668356537818909e-01
    z[1,3,5]  R1371     -4.2336869239807129e-01
    z[1,3,5]  R1372     -1.9220508635044098e-01
    z[1,3,5]  R1373     3.0547830462455750e-01
    z[1,3,5]  R1374     -3.2927942276000977e-01
    z[1,3,5]  R1375     6.5410439856350422e-03
    z[1,3,5]  R1376     -2.1521820127964020e-01
    z[1,3,5]  R1377     1.4981015026569366e-01
    z[1,3,5]  R1378     -0.0714566707611084
    z[1,3,5]  R1379     1.5993739664554596e-01
    z[1,3,5]  R1380     -2.0263540744781494e-01
    z[1,3,5]  R1381     -0.27133908867836
    z[1,3,5]  R1382     -4.7249174118041992e-01
    z[1,3,5]  R1383     -2.1879664063453674e-01
    z[1,3,5]  R1384     2.1051040291786194e-01
    z[1,3,5]  R1385     -4.7900292277336121e-01
    z[1,3,5]  R1386     1.1892103403806686e-01
    z[1,3,5]  R1387     -2.1886758506298065e-02
    z[1,3,5]  R1388     -5.5067169666290283e-01
    z[1,3,5]  R1389     -9.6480071544647217e-02
    z[1,3,5]  R1390     7.9776518046855927e-02
    z[1,3,5]  R1391     -0.0778428167104721
    z[1,3,5]  R1392     -9.3156717717647552e-02
    z[1,3,5]  R1393     1.4025831222534180e-01
    z[1,3,5]  R1394     -3.3763861656188965e-01
    z[1,3,5]  R1395     -2.8510031104087830e-01
    z[1,3,5]  R1396     -2.7459102869033813e-01
    z[1,3,5]  R1397     -1.7809697985649109e-01
    z[1,3,5]  R1398     -9.8730325698852539e-02
    z[1,3,5]  R1399     -3.5191348195075989e-01
    z[1,3,5]  R1400     9.1518782079219818e-02
    z[1,3,5]  R1401     2.5892412662506104e-01
    z[1,3,5]  R1402     2.5200262665748596e-01
    z[1,3,5]  R1403     1.6486391425132751e-01
    z[1,3,5]  R1404     3.9414229989051819e-01
    z[1,3,5]  R1405     3.0530977994203568e-02
    z[1,3,5]  R1406     2.5256010890007019e-01
    z[1,3,5]  R1407     6.9754086434841156e-02
    z[1,3,5]  R1408     2.7698242664337158e-01
    z[1,3,5]  R1409     -0.438755065202713
    z[1,3,5]  R1410     -3.2588756084442139e-01
    z[1,3,5]  R1411     -8.9207157492637634e-02
    z[1,3,5]  R1412     -2.6879742741584778e-01
    z[1,3,5]  R1413     -2.2403210401535034e-01
    z[1,3,5]  R1414     -1.5371562540531158e-01
    z[1,3,5]  R1415     0.49073326587677
    z[1,3,5]  R1416     5.6967481970787048e-02
    z[1,3,5]  R1417     7.2781629860401154e-02
    z[1,3,5]  R1418     3.0580663681030273e-01
    z[1,3,5]  R1419     5.1552492380142212e-01
    z[1,3,5]  R1420     -7.9626701772212982e-02
    z[1,3,5]  R1421     -1.2868297100067139e-01
    z[1,3,5]  R1422     3.3688607811927795e-01
    z[1,3,5]  R1423     5.1151913404464722e-01
    z[1,3,5]  R1424     3.6664155125617981e-01
    z[1,3,5]  R1425     0.366933673620224
    z[1,3,5]  R1426     2.4038605391979218e-01
    z[1,3,5]  R1427     -2.6346214581280947e-03
    z[1,3,5]  R1428     -8.3512723445892334e-02
    z[1,3,5]  R1429     3.2308793067932129e-01
    z[1,3,5]  R1430     -3.8913673162460327e-01
    z[1,3,5]  R1431     -4.0350112318992615e-01
    z[1,3,5]  R1432     -6.3718676567077637e-01
    z[1,3,5]  R1433     -8.0009198188781738e-01
    z[1,3,5]  R1434     -1.8298944830894470e-01
    z[1,3,5]  R1435     1.9466073717921972e-04
    z[1,3,5]  R1436     4.1467356681823730e-01
    z[1,3,5]  R1437     -4.6634575724601746e-01
    z[1,3,5]  R1438     -2.3785832524299622e-01
    z[1,3,5]  R1439     1.3878895342350006e-01
    z[1,3,5]  R1440     -1.7217348515987396e-01
    z[1,3,5]  R1441     -7.0632971823215485e-02
    z[1,3,5]  R1442     2.8447309136390686e-01
    z[1,3,5]  R1443     -0.0577826164662838
    z[1,3,5]  R1444     -3.6176130175590515e-02
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R1323     -1
    z[1,3,6]  R1324     1
    z[1,3,6]  R1325     2.5978598743677139e-02
    z[1,3,6]  R1326     2.5896498560905457e-01
    z[1,3,6]  R1327     2.2164984047412872e-01
    z[1,3,6]  R1328     3.9759743958711624e-03
    z[1,3,6]  R1329     -1.1250501126050949e-01
    z[1,3,6]  R1330     1.7408958077430725e-01
    z[1,3,6]  R1331     1.3000544905662537e-01
    z[1,3,6]  R1332     -2.1116336807608604e-02
    z[1,3,6]  R1333     2.4243091046810150e-01
    z[1,3,6]  R1334     4.6817961335182190e-01
    z[1,3,6]  R1335     -2.7770814299583435e-01
    z[1,3,6]  R1336     -4.0957968682050705e-02
    z[1,3,6]  R1337     1.5679925680160522e-02
    z[1,3,6]  R1338     2.3461225628852844e-01
    z[1,3,6]  R1339     -6.1612367630004883e-01
    z[1,3,6]  R1340     -0.510966956615448
    z[1,3,6]  R1341     2.5119778513908386e-01
    z[1,3,6]  R1342     1.0444530844688416e-01
    z[1,3,6]  R1343     -2.8750613331794739e-01
    z[1,3,6]  R1344     -5.2096154540777206e-02
    z[1,3,6]  R1345     -6.3579088449478149e-01
    z[1,3,6]  R1346     -3.9047278463840485e-02
    z[1,3,6]  R1347     -5.7067770510911942e-02
    z[1,3,6]  R1348     -4.9153414368629456e-01
    z[1,3,6]  R1349     -3.9015471935272217e-01
    z[1,3,6]  R1350     2.3470519483089447e-01
    z[1,3,6]  R1351     -6.4734026789665222e-02
    z[1,3,6]  R1352     7.1323089301586151e-02
    z[1,3,6]  R1353     0.603255033493042
    z[1,3,6]  R1354     -1.8306757509708405e-01
    z[1,3,6]  R1355     -6.2811499834060669e-01
    z[1,3,6]  R1356     -5.8990508317947388e-01
    z[1,3,6]  R1357     4.7271189093589783e-01
    z[1,3,6]  R1358     -3.1926280260086060e-01
    z[1,3,6]  R1359     -1.4661435782909393e-01
    z[1,3,6]  R1360     5.3604024648666382e-01
    z[1,3,6]  R1361     -4.1475647687911987e-01
    z[1,3,6]  R1362     -1.1077469587326050e-01
    z[1,3,6]  R1363     -4.6451419591903687e-01
    z[1,3,6]  R1364     5.5887496471405029e-01
    z[1,3,6]  R1365     -1.7274679243564606e-01
    z[1,3,6]  R1366     1.2963366508483887e-01
    z[1,3,6]  R1367     5.8247900009155273e-01
    z[1,3,6]  R1368     1.6660098731517792e-01
    z[1,3,6]  R1369     -1.5399083495140076e-01
    z[1,3,6]  R1370     1.0274005681276321e-01
    z[1,3,6]  R1371     -1.6138151288032532e-01
    z[1,3,6]  R1372     -2.3751424252986908e-01
    z[1,3,6]  R1373     -4.2117387056350708e-01
    z[1,3,6]  R1374     5.3832399845123291e-01
    z[1,3,6]  R1375     -9.5269419252872467e-02
    z[1,3,6]  R1376     -0.337056040763855
    z[1,3,6]  R1377     -3.3285051584243774e-01
    z[1,3,6]  R1378     0.341945618391037
    z[1,3,6]  R1379     -2.7795326709747314e-01
    z[1,3,6]  R1380     -2.9696673154830933e-01
    z[1,3,6]  R1381     6.0295134782791138e-01
    z[1,3,6]  R1382     3.2087239623069763e-01
    z[1,3,6]  R1383     3.1672829389572144e-01
    z[1,3,6]  R1384     -2.7522730827331543e-01
    z[1,3,6]  R1385     -3.6352673172950745e-01
    z[1,3,6]  R1386     3.1183210015296936e-01
    z[1,3,6]  R1387     -0.522093653678894
    z[1,3,6]  R1388     8.4165006875991821e-02
    z[1,3,6]  R1389     4.1922721266746521e-01
    z[1,3,6]  R1390     -1.0764741152524948e-01
    z[1,3,6]  R1391     -8.9159741997718811e-02
    z[1,3,6]  R1392     1.8927218019962311e-01
    z[1,3,6]  R1393     -0.0878983587026596
    z[1,3,6]  R1394     9.3493327498435974e-02
    z[1,3,6]  R1395     1.8634596839547157e-02
    z[1,3,6]  R1396     6.1599975824356079e-01
    z[1,3,6]  R1397     2.8018739819526672e-01
    z[1,3,6]  R1398     3.2007377594709396e-02
    z[1,3,6]  R1399     4.5550405979156494e-01
    z[1,3,6]  R1400     5.9498608112335205e-02
    z[1,3,6]  R1401     9.0559042990207672e-02
    z[1,3,6]  R1402     1.9700525701045990e-01
    z[1,3,6]  R1403     6.8040627241134644e-01
    z[1,3,6]  R1404     4.9363193102180958e-03
    z[1,3,6]  R1405     -2.4662408232688904e-01
    z[1,3,6]  R1406     -7.3229223489761353e-02
    z[1,3,6]  R1407     5.0963556766510010e-01
    z[1,3,6]  R1408     5.3769510984420776e-01
    z[1,3,6]  R1409     1.2688353657722473e-01
    z[1,3,6]  R1410     7.3101505637168884e-02
    z[1,3,6]  R1411     9.3675171956419945e-03
    z[1,3,6]  R1412     -1.5260463953018188e-01
    z[1,3,6]  R1413     -0.163701593875885
    z[1,3,6]  R1414     1.6433374583721161e-01
    z[1,3,6]  R1415     -2.5771612301468849e-02
    z[1,3,6]  R1416     -2.8085660934448242e-01
    z[1,3,6]  R1417     2.1825022995471954e-01
    z[1,3,6]  R1418     2.3344756662845612e-01
    z[1,3,6]  R1419     2.6692020893096924e-01
    z[1,3,6]  R1420     -6.2983624637126923e-02
    z[1,3,6]  R1421     6.0644489526748657e-01
    z[1,3,6]  R1422     0.150406152009964
    z[1,3,6]  R1423     1.0031318664550781e-01
    z[1,3,6]  R1424     1.2571129016578197e-02
    z[1,3,6]  R1425     4.1141849756240845e-01
    z[1,3,6]  R1426     3.5320450551807880e-03
    z[1,3,6]  R1427     6.8976622819900513e-01
    z[1,3,6]  R1428     -1.2096484750509262e-01
    z[1,3,6]  R1429     3.9257019758224487e-01
    z[1,3,6]  R1430     1.1280041933059692e-01
    z[1,3,6]  R1431     4.1892158985137939e-01
    z[1,3,6]  R1432     5.0528898835182190e-02
    z[1,3,6]  R1433     0.161977618932724
    z[1,3,6]  R1434     3.3900722861289978e-01
    z[1,3,6]  R1435     2.2306475043296814e-01
    z[1,3,6]  R1436     3.1190004944801331e-01
    z[1,3,6]  R1437     -7.7244572341442108e-02
    z[1,3,6]  R1438     2.8067186474800110e-01
    z[1,3,6]  R1439     2.8628465533256531e-01
    z[1,3,6]  R1440     2.0274116098880768e-01
    z[1,3,6]  R1441     3.5062986612319946e-01
    z[1,3,6]  R1442     2.9905807971954346e-01
    z[1,3,6]  R1443     1.8012440204620361e-01
    z[1,3,6]  R1444     -1.4839315414428711e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R1445     -1
    z[3,1,0]  R1446     1
    z[3,1,0]  R1459     -6.0292345285415649e-01
    z[3,1,0]  R1460     -5.9713470935821533e-01
    z[3,1,0]  R1461     -7.9646384716033936e-01
    z[3,1,0]  R1462     0.593394935131073
    z[3,1,0]  R1463     -0.430400013923645
    z[3,1,0]  R1464     3.6738941073417664e-01
    z[3,1,0]  R1465     6.8841701745986938e-01
    z[3,1,0]  R1466     2.7344632148742676e-01
    z[3,1,0]  R1467     3.5563737154006958e-01
    z[3,1,0]  R1468     4.9206703901290894e-01
    z[3,1,0]  R1469     -2.8547435998916626e-01
    z[3,1,0]  R1470     -1.9855169579386711e-02
    z[3,1,0]  R1471     -7.0916842669248581e-03
    z[3,1,0]  R1472     -2.0397590473294258e-02
    z[3,1,0]  R1473     -6.5713502466678619e-02
    z[3,1,0]  R1474     3.0177175998687744e-01
    z[3,1,0]  R1475     3.8811814785003662e-01
    z[3,1,0]  R1476     -1.8501804769039154e-01
    z[3,1,0]  R1477     0.167601078748703
    z[3,1,0]  R1478     8.1268265843391418e-02
    z[3,1,0]  R1479     5.1078337430953979e-01
    z[3,1,0]  R1480     -2.2165615856647491e-01
    z[3,1,0]  R1481     7.2538322210311890e-01
    z[3,1,0]  R1482     8.0320823192596436e-01
    z[3,1,0]  R1483     5.4646110534667969e-01
    z[3,1,0]  R1484     4.4635590910911560e-01
    z[3,1,0]  R1485     5.7215999811887741e-02
    z[3,1,0]  R1486     6.9971328973770142e-01
    z[3,1,0]  R1487     0.713864803314209
    z[3,1,0]  R1488     7.7606225013732910e-01
    z[3,1,0]  R1489     -0.397827684879303
    z[3,1,0]  R1490     7.2482812404632568e-01
    z[3,1,0]  R1491     -2.4095913767814636e-01
    z[3,1,0]  R1492     0.813280463218689
    z[3,1,0]  R1493     1.3921824283897877e-02
    z[3,1,0]  R1494     6.2162774801254272e-01
    z[3,1,0]  R1495     5.1198744773864746e-01
    z[3,1,0]  R1496     6.4981174468994141e-01
    z[3,1,0]  R1497     -4.9261572957038879e-01
    z[3,1,0]  R1498     2.5793758034706116e-01
    z[3,1,0]  R1499     6.9175004959106445e-02
    z[3,1,0]  R1500     -3.7531760334968567e-01
    z[3,1,0]  R1501     -4.9100264906883240e-02
    z[3,1,0]  R1502     3.8662287592887878e-01
    z[3,1,0]  R1503     7.8889721632003784e-01
    z[3,1,0]  R1504     -3.9210504293441772e-01
    z[3,1,0]  R1505     7.3289644718170166e-01
    z[3,1,0]  R1506     1.8111538887023926e-01
    z[3,1,0]  R1507     -3.0878129601478577e-01
    z[3,1,0]  R1508     -3.5077667236328125e-01
    z[3,1,0]  R1509     -2.7622032165527344e-01
    z[3,1,0]  R1510     7.2170570492744446e-02
    z[3,1,0]  R1511     -2.1570110321044922e-01
    z[3,1,0]  R1512     -1.9471928477287292e-01
    z[3,1,0]  R1513     1.9177286326885223e-01
    z[3,1,0]  R1514     -9.2172406613826752e-02
    z[3,1,0]  R1515     -2.2240076959133148e-01
    z[3,1,0]  R1516     -1.5014803968369961e-02
    z[3,1,0]  R1517     7.7013963460922241e-01
    z[3,1,0]  R1518     3.6218479275703430e-01
    z[3,1,0]  R1519     -9.2576093971729279e-02
    z[3,1,0]  R1520     -6.1049032211303711e-01
    z[3,1,0]  R1521     2.5484472513198853e-01
    z[3,1,0]  R1522     5.2137277089059353e-03
    z[3,1,0]  R1523     -0.604136049747467
    z[3,1,0]  R1524     -8.2193642854690552e-01
    z[3,1,0]  R1525     0.663940966129303
    z[3,1,0]  R1526     4.0393376350402832e-01
    z[3,1,0]  R1527     -2.0123668015003204e-01
    z[3,1,0]  R1528     -3.8823267817497253e-01
    z[3,1,0]  R1529     -2.7819445729255676e-01
    z[3,1,0]  R1530     -1.8396872282028198e-01
    z[3,1,0]  R1531     -0.406222403049469
    z[3,1,0]  R1532     -1.1003332585096359e-01
    z[3,1,0]  R1533     -9.8708763718605042e-02
    z[3,1,0]  R1534     4.4714215397834778e-01
    z[3,1,0]  R1535     -3.8053756952285767e-01
    z[3,1,0]  R1536     2.1977389231324196e-02
    z[3,1,0]  R1537     -1.4427816867828369e-01
    z[3,1,0]  R1538     8.8784933090209961e-01
    z[3,1,0]  R1539     -1.9358487427234650e-01
    z[3,1,0]  R1540     -2.9861995577812195e-01
    z[3,1,0]  R1541     -2.8213111683726311e-02
    z[3,1,0]  R1542     1.6459727287292480e-01
    z[3,1,0]  R1543     3.3137798309326172e-01
    z[3,1,0]  R1544     2.3689137399196625e-01
    z[3,1,0]  R1545     -2.9080209136009216e-01
    z[3,1,0]  R1546     -5.5311852693557739e-01
    z[3,1,0]  R1547     5.9021119959652424e-03
    z[3,1,0]  R1548     5.5397635698318481e-01
    z[3,1,0]  R1549     1.1108215898275375e-01
    z[3,1,0]  R1550     -3.1310665607452393e-01
    z[3,1,0]  R1551     0.181345596909523
    z[3,1,0]  R1552     -9.9855475127696991e-02
    z[3,1,0]  R1553     -4.7264367341995239e-01
    z[3,1,0]  R1554     1.7552487552165985e-01
    z[3,1,0]  R1555     1.1585873365402222e-01
    z[3,1,0]  R1556     2.7301779389381409e-01
    z[3,1,0]  R1557     3.6947306990623474e-01
    z[3,1,0]  R1558     1.2942981719970703e-01
    z[3,1,0]  R1559     1.4334422349929810e-01
    z[3,1,0]  R1560     -2.0050154998898506e-03
    z[3,1,0]  R1561     -3.4409871697425842e-01
    z[3,1,0]  R1562     -0.0753057599067688
    z[3,1,0]  R1563     -4.1856479644775391e-01
    z[3,1,0]  R1564     -5.2887761592864990e-01
    z[3,1,0]  R1565     3.8372308015823364e-01
    z[3,1,0]  R1566     1.8392139673233032e-01
    z[3,1,0]  R1567     0.756458580493927
    z[3,1,0]  R1568     4.1215223073959351e-01
    z[3,1,0]  R1569     -2.9381206259131432e-02
    z[3,1,0]  R1570     -1.9953933358192444e-01
    z[3,1,0]  R1571     0.0612550750374794
    z[3,1,0]  R1572     -5.5652207136154175e-01
    z[3,1,0]  R1573     2.4315534532070160e-01
    z[3,1,0]  R1574     8.9159369468688965e-01
    z[3,1,0]  R1575     8.5959982872009277e-01
    z[3,1,0]  R1576     8.3808708190917969e-01
    z[3,1,0]  R1577     8.2671457529067993e-01
    z[3,1,0]  R1578     8.2864439487457275e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R1447     -1
    z[3,1,1]  R1448     1
    z[3,1,1]  R1459     -4.9979650974273682e-01
    z[3,1,1]  R1460     -3.7981674075126648e-01
    z[3,1,1]  R1461     -2.0791263878345490e-01
    z[3,1,1]  R1462     3.7678810954093933e-01
    z[3,1,1]  R1463     -4.3685835599899292e-01
    z[3,1,1]  R1464     7.3186588287353516e-01
    z[3,1,1]  R1465     5.6335467100143433e-01
    z[3,1,1]  R1466     -5.8704257011413574e-01
    z[3,1,1]  R1467     2.5529748201370239e-01
    z[3,1,1]  R1468     -3.0720129609107971e-01
    z[3,1,1]  R1469     -4.9055501818656921e-01
    z[3,1,1]  R1470     -8.5490924119949341e-01
    z[3,1,1]  R1471     -7.7586907148361206e-01
    z[3,1,1]  R1472     -7.6240330934524536e-01
    z[3,1,1]  R1473     -6.7092359066009521e-01
    z[3,1,1]  R1474     -0.72418612241745
    z[3,1,1]  R1475     -6.1174947023391724e-01
    z[3,1,1]  R1476     -6.1788523197174072e-01
    z[3,1,1]  R1477     -9.1981792449951172e-01
    z[3,1,1]  R1478     -5.2808022499084473e-01
    z[3,1,1]  R1479     5.4192101955413818e-01
    z[3,1,1]  R1480     -8.2055938243865967e-01
    z[3,1,1]  R1481     4.7175922989845276e-01
    z[3,1,1]  R1482     1.1841738224029541e-01
    z[3,1,1]  R1483     2.9551774263381958e-01
    z[3,1,1]  R1484     0.809660017490387
    z[3,1,1]  R1485     -2.1381278336048126e-01
    z[3,1,1]  R1486     -1.8627347052097321e-01
    z[3,1,1]  R1487     0.00829958077520132
    z[3,1,1]  R1488     -3.7942326068878174e-01
    z[3,1,1]  R1489     -4.5845040678977966e-01
    z[3,1,1]  R1490     2.7378877997398376e-01
    z[3,1,1]  R1491     -2.6002889871597290e-01
    z[3,1,1]  R1492     -3.5557288210839033e-03
    z[3,1,1]  R1493     -2.9835966229438782e-01
    z[3,1,1]  R1494     -3.6772534251213074e-01
    z[3,1,1]  R1495     -4.3924498558044434e-01
    z[3,1,1]  R1496     -2.4902668595314026e-01
    z[3,1,1]  R1497     1.4090338349342346e-01
    z[3,1,1]  R1498     3.8887679576873779e-01
    z[3,1,1]  R1499     -7.4931782484054565e-01
    z[3,1,1]  R1500     -0.632306694984436
    z[3,1,1]  R1501     -7.8275579214096069e-01
    z[3,1,1]  R1502     -6.6907012462615967e-01
    z[3,1,1]  R1503     -2.8633108735084534e-01
    z[3,1,1]  R1504     -0.757557213306427
    z[3,1,1]  R1505     -3.0009558796882629e-01
    z[3,1,1]  R1506     3.3315002918243408e-01
    z[3,1,1]  R1507     8.9879298210144043e-01
    z[3,1,1]  R1508     8.9376252889633179e-01
    z[3,1,1]  R1509     5.7023260742425919e-02
    z[3,1,1]  R1510     -4.0100085735321045e-01
    z[3,1,1]  R1511     -4.0556874871253967e-01
    z[3,1,1]  R1512     -4.6332615613937378e-01
    z[3,1,1]  R1513     -2.3702657222747803e-01
    z[3,1,1]  R1514     2.2285167872905731e-01
    z[3,1,1]  R1515     2.9661893844604492e-01
    z[3,1,1]  R1516     -3.8518407940864563e-01
    z[3,1,1]  R1517     9.2216655611991882e-02
    z[3,1,1]  R1518     -3.6164233088493347e-01
    z[3,1,1]  R1519     -6.8206888437271118e-01
    z[3,1,1]  R1520     -5.1864419132471085e-02
    z[3,1,1]  R1521     -5.4454110562801361e-02
    z[3,1,1]  R1522     0.0367298349738121
    z[3,1,1]  R1523     -3.0298924073576927e-02
    z[3,1,1]  R1524     6.8774081766605377e-02
    z[3,1,1]  R1525     1.3289210200309753e-01
    z[3,1,1]  R1526     -1.5048886835575104e-01
    z[3,1,1]  R1527     -2.6078957319259644e-01
    z[3,1,1]  R1528     3.0239865183830261e-01
    z[3,1,1]  R1529     -3.2169643044471741e-01
    z[3,1,1]  R1530     3.1752693653106689e-01
    z[3,1,1]  R1531     -2.7491134405136108e-01
    z[3,1,1]  R1532     -2.0878896117210388e-01
    z[3,1,1]  R1533     -4.4018852710723877e-01
    z[3,1,1]  R1534     -1.1904118955135345e-01
    z[3,1,1]  R1535     3.8342788815498352e-01
    z[3,1,1]  R1536     7.4422186613082886e-01
    z[3,1,1]  R1537     -2.3468953371047974e-01
    z[3,1,1]  R1538     0.400115966796875
    z[3,1,1]  R1539     -1.1934275925159454e-01
    z[3,1,1]  R1540     6.0335206799209118e-03
    z[3,1,1]  R1541     2.9801445081830025e-02
    z[3,1,1]  R1542     3.9609622955322266e-01
    z[3,1,1]  R1543     0.460801899433136
    z[3,1,1]  R1544     -4.2347031831741333e-01
    z[3,1,1]  R1545     5.9909218549728394e-01
    z[3,1,1]  R1546     -2.5118863582611084e-01
    z[3,1,1]  R1547     -4.5285689830780029e-01
    z[3,1,1]  R1548     2.9667595028877258e-01
    z[3,1,1]  R1549     -4.4780600070953369e-01
    z[3,1,1]  R1550     0.479547381401062
    z[3,1,1]  R1551     -1.1395521461963654e-01
    z[3,1,1]  R1552     5.7864004373550415e-01
    z[3,1,1]  R1553     -2.3511280119419098e-01
    z[3,1,1]  R1554     3.3842352032661438e-01
    z[3,1,1]  R1555     -6.4883500337600708e-01
    z[3,1,1]  R1556     -5.0559818744659424e-01
    z[3,1,1]  R1557     0.500224769115448
    z[3,1,1]  R1558     -1.5252690762281418e-02
    z[3,1,1]  R1559     2.0094932615756989e-01
    z[3,1,1]  R1560     -4.3286976218223572e-01
    z[3,1,1]  R1561     3.8947391510009766e-01
    z[3,1,1]  R1562     4.8887810111045837e-01
    z[3,1,1]  R1563     -1.6817826032638550e-01
    z[3,1,1]  R1564     -1.7984431982040405e-01
    z[3,1,1]  R1565     1.6541364789009094e-01
    z[3,1,1]  R1566     8.7534934282302856e-02
    z[3,1,1]  R1567     1.3398897647857666e-01
    z[3,1,1]  R1568     -3.3120420575141907e-01
    z[3,1,1]  R1569     3.9884641766548157e-01
    z[3,1,1]  R1570     4.5949053764343262e-01
    z[3,1,1]  R1571     1.0078227519989014e-01
    z[3,1,1]  R1572     2.0944228395819664e-02
    z[3,1,1]  R1573     -4.8049259185791016e-01
    z[3,1,1]  R1574     3.4001204371452332e-01
    z[3,1,1]  R1575     2.5614374876022339e-01
    z[3,1,1]  R1576     0.4011210501194
    z[3,1,1]  R1577     3.2489171624183655e-01
    z[3,1,1]  R1578     2.7052381634712219e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R1449     -1
    z[3,1,2]  R1450     1
    z[3,1,2]  R1459     -3.4730517864227295e-01
    z[3,1,2]  R1460     -1.4648345112800598e-01
    z[3,1,2]  R1461     -4.0350863337516785e-01
    z[3,1,2]  R1462     7.0236515998840332e-01
    z[3,1,2]  R1463     -1.2193604372441769e-02
    z[3,1,2]  R1464     5.3562176227569580e-01
    z[3,1,2]  R1465     1.8169675767421722e-01
    z[3,1,2]  R1466     -3.1884562224149704e-02
    z[3,1,2]  R1467     5.2796679735183716e-01
    z[3,1,2]  R1468     5.4261833429336548e-01
    z[3,1,2]  R1469     -7.4606072902679443e-01
    z[3,1,2]  R1470     1.7190891504287720e-01
    z[3,1,2]  R1471     -3.0966898798942566e-01
    z[3,1,2]  R1472     2.1271331608295441e-01
    z[3,1,2]  R1473     2.2867359220981598e-02
    z[3,1,2]  R1474     -1.0302006453275681e-01
    z[3,1,2]  R1475     -1.3841852545738220e-01
    z[3,1,2]  R1476     6.8635516799986362e-03
    z[3,1,2]  R1477     1.3173352181911469e-01
    z[3,1,2]  R1478     -1.1156410723924637e-01
    z[3,1,2]  R1479     3.9218932390213013e-01
    z[3,1,2]  R1480     -1.8157172203063965e-01
    z[3,1,2]  R1481     3.2757565379142761e-01
    z[3,1,2]  R1482     1.9680313766002655e-01
    z[3,1,2]  R1483     4.5352223515510559e-01
    z[3,1,2]  R1484     2.9588249325752258e-01
    z[3,1,2]  R1485     -5.0353008508682251e-01
    z[3,1,2]  R1486     3.9402994513511658e-01
    z[3,1,2]  R1487     3.4777870774269104e-01
    z[3,1,2]  R1488     3.1732836365699768e-01
    z[3,1,2]  R1489     -5.5367767810821533e-01
    z[3,1,2]  R1490     5.6241697072982788e-01
    z[3,1,2]  R1491     -5.9100198745727539e-01
    z[3,1,2]  R1492     3.3056426048278809e-01
    z[3,1,2]  R1493     -2.4744980037212372e-01
    z[3,1,2]  R1494     2.2165837883949280e-01
    z[3,1,2]  R1495     1.9918750226497650e-01
    z[3,1,2]  R1496     0.0682726576924324
    z[3,1,2]  R1497     -1.8451346457004547e-01
    z[3,1,2]  R1498     -1.3119451701641083e-01
    z[3,1,2]  R1499     1.2991547584533691e-02
    z[3,1,2]  R1500     -3.0424109101295471e-01
    z[3,1,2]  R1501     1.2071663886308670e-01
    z[3,1,2]  R1502     -3.4740817500278354e-04
    z[3,1,2]  R1503     3.3287355303764343e-01
    z[3,1,2]  R1504     1.1665407568216324e-01
    z[3,1,2]  R1505     4.0914547443389893e-01
    z[3,1,2]  R1506     -3.4522455930709839e-01
    z[3,1,2]  R1507     -5.6712850928306580e-02
    z[3,1,2]  R1508     -1.4610143005847931e-01
    z[3,1,2]  R1509     5.7882523536682129e-01
    z[3,1,2]  R1510     4.1696330904960632e-01
    z[3,1,2]  R1511     5.1958316564559937e-01
    z[3,1,2]  R1512     5.7546877861022949e-01
    z[3,1,2]  R1513     2.1274326741695404e-01
    z[3,1,2]  R1514     7.5553268194198608e-01
    z[3,1,2]  R1515     4.0897557139396667e-01
    z[3,1,2]  R1516     9.6684433519840240e-03
    z[3,1,2]  R1517     -3.0653487890958786e-02
    z[3,1,2]  R1518     7.4481427669525146e-02
    z[3,1,2]  R1519     -4.2489755153656006e-01
    z[3,1,2]  R1520     -2.0523147657513618e-02
    z[3,1,2]  R1521     -3.4373795986175537e-01
    z[3,1,2]  R1522     9.5099993050098419e-02
    z[3,1,2]  R1523     -2.2712003439664841e-02
    z[3,1,2]  R1524     2.0225118845701218e-02
    z[3,1,2]  R1525     -8.4506928920745850e-02
    z[3,1,2]  R1526     -1.7085234820842743e-01
    z[3,1,2]  R1527     -9.8722055554389954e-02
    z[3,1,2]  R1528     -1.4519126713275909e-01
    z[3,1,2]  R1529     -2.3931415379047394e-01
    z[3,1,2]  R1530     -3.5749744623899460e-02
    z[3,1,2]  R1531     4.3033313751220703e-01
    z[3,1,2]  R1532     2.3229060694575310e-02
    z[3,1,2]  R1533     -6.8220630288124084e-02
    z[3,1,2]  R1534     -2.4715360999107361e-01
    z[3,1,2]  R1535     3.8568194955587387e-02
    z[3,1,2]  R1536     3.6008810997009277e-01
    z[3,1,2]  R1537     1.1655066907405853e-01
    z[3,1,2]  R1538     -1.4073415659368038e-02
    z[3,1,2]  R1539     3.5025379620492458e-03
    z[3,1,2]  R1540     2.5871858000755310e-01
    z[3,1,2]  R1541     5.0503186881542206e-02
    z[3,1,2]  R1542     -1.9696229696273804e-01
    z[3,1,2]  R1543     1.0958162695169449e-01
    z[3,1,2]  R1544     -3.6883754655718803e-03
    z[3,1,2]  R1545     8.8690489530563354e-02
    z[3,1,2]  R1546     9.6120364964008331e-02
    z[3,1,2]  R1547     2.3620733618736267e-01
    z[3,1,2]  R1548     -8.8324621319770813e-02
    z[3,1,2]  R1549     -4.0031763911247253e-01
    z[3,1,2]  R1550     1.7647184431552887e-01
    z[3,1,2]  R1551     2.7075189352035522e-01
    z[3,1,2]  R1552     5.7719075679779053e-01
    z[3,1,2]  R1553     8.3714880049228668e-02
    z[3,1,2]  R1554     -2.6952880620956421e-01
    z[3,1,2]  R1555     1.6323316097259521e-01
    z[3,1,2]  R1556     -2.3205693066120148e-01
    z[3,1,2]  R1557     7.0322789251804352e-02
    z[3,1,2]  R1558     6.2086915969848633e-01
    z[3,1,2]  R1559     2.3653939366340637e-02
    z[3,1,2]  R1560     -2.4569955468177795e-01
    z[3,1,2]  R1561     3.2196617126464844e-01
    z[3,1,2]  R1562     4.1821566224098206e-01
    z[3,1,2]  R1563     3.5133041441440582e-02
    z[3,1,2]  R1564     -1.4320272952318192e-02
    z[3,1,2]  R1565     1.5297865867614746e-01
    z[3,1,2]  R1566     6.3117647171020508e-01
    z[3,1,2]  R1567     -1.8626330420374870e-02
    z[3,1,2]  R1568     -3.0767264962196350e-01
    z[3,1,2]  R1569     2.6093924045562744e-01
    z[3,1,2]  R1570     3.9941665530204773e-01
    z[3,1,2]  R1571     -2.3553118109703064e-01
    z[3,1,2]  R1572     -6.9350576959550381e-03
    z[3,1,2]  R1573     1.9941753149032593e-01
    z[3,1,2]  R1574     2.5417020916938782e-01
    z[3,1,2]  R1575     -2.1761699020862579e-01
    z[3,1,2]  R1576     6.5196588635444641e-02
    z[3,1,2]  R1577     -3.3122289180755615e-01
    z[3,1,2]  R1578     -3.2163041830062866e-01
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R1451     -1
    z[3,1,3]  R1452     1
    z[3,1,3]  R1459     -4.2700907588005066e-01
    z[3,1,3]  R1460     -1.3089103996753693e-01
    z[3,1,3]  R1461     5.0435356795787811e-02
    z[3,1,3]  R1462     -1.8006978556513786e-02
    z[3,1,3]  R1463     -5.4041433334350586e-01
    z[3,1,3]  R1464     -1.6749298572540283e-01
    z[3,1,3]  R1465     2.4034446477890015e-01
    z[3,1,3]  R1466     0.312175452709198
    z[3,1,3]  R1467     -1.5765495598316193e-01
    z[3,1,3]  R1468     -4.5238324999809265e-01
    z[3,1,3]  R1469     6.0132112354040146e-02
    z[3,1,3]  R1470     -3.5726919770240784e-01
    z[3,1,3]  R1471     1.7948009073734283e-01
    z[3,1,3]  R1472     1.7335766926407814e-02
    z[3,1,3]  R1473     0.554954469203949
    z[3,1,3]  R1474     4.6995395421981812e-01
    z[3,1,3]  R1475     6.5578943490982056e-01
    z[3,1,3]  R1476     5.3399151563644409e-01
    z[3,1,3]  R1477     1.7057047784328461e-01
    z[3,1,3]  R1478     0.805041491985321
    z[3,1,3]  R1479     1.4910751581192017e-01
    z[3,1,3]  R1480     3.3688324689865112e-01
    z[3,1,3]  R1481     1.6703270375728607e-01
    z[3,1,3]  R1482     -1.6435244679450989e-01
    z[3,1,3]  R1483     -2.5326707959175110e-01
    z[3,1,3]  R1484     1.2513893842697144e-01
    z[3,1,3]  R1485     -2.2047157585620880e-01
    z[3,1,3]  R1486     -3.8990822434425354e-01
    z[3,1,3]  R1487     -2.3397500813007355e-01
    z[3,1,3]  R1488     4.9153860658407211e-02
    z[3,1,3]  R1489     -9.9736951291561127e-02
    z[3,1,3]  R1490     1.5958513319492340e-01
    z[3,1,3]  R1491     -1.8974952399730682e-02
    z[3,1,3]  R1492     -8.5029698908329010e-02
    z[3,1,3]  R1493     -7.3701471090316772e-01
    z[3,1,3]  R1494     -5.1005744934082031e-01
    z[3,1,3]  R1495     -3.5362154245376587e-01
    z[3,1,3]  R1496     -3.0872595310211182e-01
    z[3,1,3]  R1497     9.6516653895378113e-02
    z[3,1,3]  R1498     0.767477810382843
    z[3,1,3]  R1499     -5.9185636043548584e-01
    z[3,1,3]  R1500     -1.9000720977783203e-01
    z[3,1,3]  R1501     3.6175560951232910e-01
    z[3,1,3]  R1502     3.6101114749908447e-01
    z[3,1,3]  R1503     -1.9300375878810883e-01
    z[3,1,3]  R1504     2.0218791067600250e-01
    z[3,1,3]  R1505     2.9652403667569160e-02
    z[3,1,3]  R1506     7.5273603200912476e-01
    z[3,1,3]  R1507     1.7682921886444092e-01
    z[3,1,3]  R1508     -1.7934386432170868e-01
    z[3,1,3]  R1509     -2.8136521577835083e-01
    z[3,1,3]  R1510     -5.2662551403045654e-01
    z[3,1,3]  R1511     -6.1233186721801758e-01
    z[3,1,3]  R1512     -3.1960594654083252e-01
    z[3,1,3]  R1513     -4.3368527293205261e-01
    z[3,1,3]  R1514     -5.1076197624206543e-01
    z[3,1,3]  R1515     -8.0525797605514526e-01
    z[3,1,3]  R1516     -5.2254360914230347e-01
    z[3,1,3]  R1517     -4.2296999692916870e-01
    z[3,1,3]  R1518     4.8478193581104279e-02
    z[3,1,3]  R1519     -1.8497726321220398e-01
    z[3,1,3]  R1520     7.9207018017768860e-02
    z[3,1,3]  R1521     3.8945192098617554e-01
    z[3,1,3]  R1522     0.422821044921875
    z[3,1,3]  R1523     -2.8210881352424622e-01
    z[3,1,3]  R1524     -1.1807091534137726e-01
    z[3,1,3]  R1525     3.5757082700729370e-01
    z[3,1,3]  R1526     3.3467337489128113e-01
    z[3,1,3]  R1527     2.5352901220321655e-01
    z[3,1,3]  R1528     3.3100441098213196e-01
    z[3,1,3]  R1529     -5.6162250041961670e-01
    z[3,1,3]  R1530     5.2022719383239746e-01
    z[3,1,3]  R1531     5.4889374971389771e-01
    z[3,1,3]  R1532     4.7716978192329407e-01
    z[3,1,3]  R1533     -3.4345608949661255e-01
    z[3,1,3]  R1534     3.9964485168457031e-01
    z[3,1,3]  R1535     3.8020107150077820e-01
    z[3,1,3]  R1536     3.6080777645111084e-01
    z[3,1,3]  R1537     3.6020430922508240e-01
    z[3,1,3]  R1538     1.0170537978410721e-01
    z[3,1,3]  R1539     -0.731119692325592
    z[3,1,3]  R1540     5.0512790679931641e-01
    z[3,1,3]  R1541     4.7510275244712830e-01
    z[3,1,3]  R1542     4.7052279114723206e-01
    z[3,1,3]  R1543     4.8424473404884338e-01
    z[3,1,3]  R1544     4.5583185553550720e-01
    z[3,1,3]  R1545     4.4839361310005188e-01
    z[3,1,3]  R1546     4.3676459789276123e-01
    z[3,1,3]  R1547     4.2668148875236511e-01
    z[3,1,3]  R1548     4.2736229300498962e-01
    z[3,1,3]  R1549     -7.1151775121688843e-01
    z[3,1,3]  R1550     5.5927473306655884e-01
    z[3,1,3]  R1551     5.3567820787429810e-01
    z[3,1,3]  R1552     0.525505781173706
    z[3,1,3]  R1553     4.9212706089019775e-01
    z[3,1,3]  R1554     4.8334461450576782e-01
    z[3,1,3]  R1555     4.8629650473594666e-01
    z[3,1,3]  R1556     4.3330281972885132e-01
    z[3,1,3]  R1557     4.1259589791297913e-01
    z[3,1,3]  R1558     4.3963640928268433e-01
    z[3,1,3]  R1559     0.805002748966217
    z[3,1,3]  R1560     -7.4258393049240112e-01
    z[3,1,3]  R1561     6.9236713647842407e-01
    z[3,1,3]  R1562     6.2224221229553223e-01
    z[3,1,3]  R1563     5.1679807901382446e-01
    z[3,1,3]  R1564     -5.6394052505493164e-01
    z[3,1,3]  R1565     0.447330117225647
    z[3,1,3]  R1566     4.2527988553047180e-01
    z[3,1,3]  R1567     4.0102961659431458e-01
    z[3,1,3]  R1568     3.7532398104667664e-01
    z[3,1,3]  R1569     -5.9658187627792358e-01
    z[3,1,3]  R1570     6.4064908027648926e-01
    z[3,1,3]  R1571     5.1169615983963013e-01
    z[3,1,3]  R1572     -3.3814874291419983e-01
    z[3,1,3]  R1573     5.0888514518737793e-01
    z[3,1,3]  R1574     -5.9023287147283554e-02
    z[3,1,3]  R1575     -2.7531739324331284e-02
    z[3,1,3]  R1576     -2.9218414425849915e-01
    z[3,1,3]  R1577     -2.6991435885429382e-01
    z[3,1,3]  R1578     -9.8402373492717743e-02
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R1453     -1
    z[3,1,4]  R1454     1
    z[3,1,4]  R1459     4.5822650194168091e-02
    z[3,1,4]  R1460     -7.5653657317161560e-02
    z[3,1,4]  R1461     -2.1640536189079285e-01
    z[3,1,4]  R1462     3.8729336112737656e-02
    z[3,1,4]  R1463     1.9678421318531036e-02
    z[3,1,4]  R1464     -5.0368376076221466e-02
    z[3,1,4]  R1465     2.0661942660808563e-01
    z[3,1,4]  R1466     -6.1629676818847656e-01
    z[3,1,4]  R1467     -1.2086541950702667e-01
    z[3,1,4]  R1468     -9.5076836645603180e-02
    z[3,1,4]  R1469     2.3639410734176636e-01
    z[3,1,4]  R1470     -2.0589524507522583e-01
    z[3,1,4]  R1471     7.2629086673259735e-02
    z[3,1,4]  R1472     -0.0833207443356514
    z[3,1,4]  R1473     -1.6864295303821564e-01
    z[3,1,4]  R1474     2.0364646613597870e-01
    z[3,1,4]  R1475     -1.3364824652671814e-01
    z[3,1,4]  R1476     -4.5083454251289368e-01
    z[3,1,4]  R1477     4.9073547124862671e-02
    z[3,1,4]  R1478     -5.7916458696126938e-02
    z[3,1,4]  R1479     -1.6701254248619080e-01
    z[3,1,4]  R1480     -2.2128391265869141e-01
    z[3,1,4]  R1481     2.5124964118003845e-01
    z[3,1,4]  R1482     3.5647621750831604e-01
    z[3,1,4]  R1483     -0.0849151685833931
    z[3,1,4]  R1484     1.7805512249469757e-01
    z[3,1,4]  R1485     5.1432031393051147e-01
    z[3,1,4]  R1486     1.7972512543201447e-01
    z[3,1,4]  R1487     -2.0716971158981323e-01
    z[3,1,4]  R1488     1.2676016986370087e-01
    z[3,1,4]  R1489     -1.0556812584400177e-01
    z[3,1,4]  R1490     -9.2531302943825722e-03
    z[3,1,4]  R1491     2.2112432122230530e-01
    z[3,1,4]  R1492     4.4771939516067505e-01
    z[3,1,4]  R1493     2.1878848969936371e-01
    z[3,1,4]  R1494     -7.0104807615280151e-02
    z[3,1,4]  R1495     2.0469594001770020e-01
    z[3,1,4]  R1496     0.0848376527428627
    z[3,1,4]  R1497     1.6652733087539673e-01
    z[3,1,4]  R1498     1.6612590849399567e-01
    z[3,1,4]  R1499     1.8307650089263916e-01
    z[3,1,4]  R1500     -2.4783807992935181e-01
    z[3,1,4]  R1501     -1.2648294866085052e-01
    z[3,1,4]  R1502     -3.7038561701774597e-01
    z[3,1,4]  R1503     2.1535834670066833e-01
    z[3,1,4]  R1504     -3.8356855511665344e-01
    z[3,1,4]  R1505     2.7675956487655640e-01
    z[3,1,4]  R1506     7.4886791408061981e-03
    z[3,1,4]  R1507     -1.6296248137950897e-01
    z[3,1,4]  R1508     -3.6126505583524704e-02
    z[3,1,4]  R1509     6.0072422027587891e-01
    z[3,1,4]  R1510     2.4796561896800995e-01
    z[3,1,4]  R1511     2.6029223203659058e-01
    z[3,1,4]  R1512     3.1332916021347046e-01
    z[3,1,4]  R1513     2.6376459002494812e-01
    z[3,1,4]  R1514     -2.0386783778667450e-01
    z[3,1,4]  R1515     3.7150572985410690e-02
    z[3,1,4]  R1516     -7.5935405492782593e-01
    z[3,1,4]  R1517     -0.399393767118454
    z[3,1,4]  R1518     -7.1339696645736694e-01
    z[3,1,4]  R1519     4.7217461466789246e-01
    z[3,1,4]  R1520     -3.1844952702522278e-01
    z[3,1,4]  R1521     8.1103682518005371e-01
    z[3,1,4]  R1522     -7.1264576911926270e-01
    z[3,1,4]  R1523     -4.0418615937232971e-01
    z[3,1,4]  R1524     -1.7569592595100403e-01
    z[3,1,4]  R1525     5.8281880617141724e-01
    z[3,1,4]  R1526     -8.1347936391830444e-01
    z[3,1,4]  R1527     -6.7264097929000854e-01
    z[3,1,4]  R1528     0.714393138885498
    z[3,1,4]  R1529     2.0473514497280121e-01
    z[3,1,4]  R1530     7.4354684352874756e-01
    z[3,1,4]  R1531     -3.6610189080238342e-01
    z[3,1,4]  R1532     -6.7614614963531494e-01
    z[3,1,4]  R1533     -6.5717041492462158e-01
    z[3,1,4]  R1534     6.3501501083374023e-01
    z[3,1,4]  R1535     -2.0388266444206238e-01
    z[3,1,4]  R1536     -4.1412681341171265e-01
    z[3,1,4]  R1537     -1.8338575959205627e-01
    z[3,1,4]  R1538     0.08367870002985
    z[3,1,4]  R1539     -3.0239738523960114e-02
    z[3,1,4]  R1540     -4.8318862915039062e-01
    z[3,1,4]  R1541     5.0756323337554932e-01
    z[3,1,4]  R1542     -6.6026735305786133e-01
    z[3,1,4]  R1543     -5.5032426118850708e-01
    z[3,1,4]  R1544     -4.8070478439331055e-01
    z[3,1,4]  R1545     -2.4454867839813232e-01
    z[3,1,4]  R1546     5.6814938783645630e-01
    z[3,1,4]  R1547     -3.5311231017112732e-01
    z[3,1,4]  R1548     -2.4681656062602997e-01
    z[3,1,4]  R1549     2.4790546298027039e-01
    z[3,1,4]  R1550     -5.1099810749292374e-02
    z[3,1,4]  R1551     -4.8351773619651794e-01
    z[3,1,4]  R1552     -1.2792724370956421e-01
    z[3,1,4]  R1553     6.3539731502532959e-01
    z[3,1,4]  R1554     -5.8918994665145874e-01
    z[3,1,4]  R1555     -3.1173002719879150e-01
    z[3,1,4]  R1556     -5.7868313789367676e-01
    z[3,1,4]  R1557     0.40912064909935
    z[3,1,4]  R1558     -7.7711150050163269e-02
    z[3,1,4]  R1559     -5.3043740987777710e-01
    z[3,1,4]  R1560     2.0222522318363190e-01
    z[3,1,4]  R1561     -1.1678715795278549e-01
    z[3,1,4]  R1562     0.266841858625412
    z[3,1,4]  R1563     6.5220171213150024e-01
    z[3,1,4]  R1564     -4.9036750197410583e-01
    z[3,1,4]  R1565     4.0584853291511536e-01
    z[3,1,4]  R1566     -2.3033963143825531e-01
    z[3,1,4]  R1567     3.1694963574409485e-01
    z[3,1,4]  R1568     6.0401898622512817e-01
    z[3,1,4]  R1569     2.3337426781654358e-01
    z[3,1,4]  R1570     0.260204017162323
    z[3,1,4]  R1571     6.2906432151794434e-01
    z[3,1,4]  R1572     -5.1490652561187744e-01
    z[3,1,4]  R1573     -4.7561657428741455e-01
    z[3,1,4]  R1574     -5.8428540825843811e-02
    z[3,1,4]  R1575     -0.365177184343338
    z[3,1,4]  R1576     5.0869386643171310e-02
    z[3,1,4]  R1577     -3.2056987285614014e-02
    z[3,1,4]  R1578     -6.5538994967937469e-02
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R1455     -1
    z[3,1,5]  R1456     1
    z[3,1,5]  R1459     -2.8510031104087830e-01
    z[3,1,5]  R1460     -2.7459102869033813e-01
    z[3,1,5]  R1461     -1.7809697985649109e-01
    z[3,1,5]  R1462     -9.8730325698852539e-02
    z[3,1,5]  R1463     -3.5191348195075989e-01
    z[3,1,5]  R1464     9.1518782079219818e-02
    z[3,1,5]  R1465     2.5892412662506104e-01
    z[3,1,5]  R1466     2.5200262665748596e-01
    z[3,1,5]  R1467     1.6486391425132751e-01
    z[3,1,5]  R1468     3.9414229989051819e-01
    z[3,1,5]  R1469     3.0530977994203568e-02
    z[3,1,5]  R1470     2.5256010890007019e-01
    z[3,1,5]  R1471     6.9754086434841156e-02
    z[3,1,5]  R1472     2.7698242664337158e-01
    z[3,1,5]  R1473     -0.438755065202713
    z[3,1,5]  R1474     -3.2588756084442139e-01
    z[3,1,5]  R1475     -8.9207157492637634e-02
    z[3,1,5]  R1476     -2.6879742741584778e-01
    z[3,1,5]  R1477     -2.2403210401535034e-01
    z[3,1,5]  R1478     -1.5371562540531158e-01
    z[3,1,5]  R1479     0.49073326587677
    z[3,1,5]  R1480     5.6967481970787048e-02
    z[3,1,5]  R1481     7.2781629860401154e-02
    z[3,1,5]  R1482     3.0580663681030273e-01
    z[3,1,5]  R1483     5.1552492380142212e-01
    z[3,1,5]  R1484     -7.9626701772212982e-02
    z[3,1,5]  R1485     -1.2868297100067139e-01
    z[3,1,5]  R1486     3.3688607811927795e-01
    z[3,1,5]  R1487     5.1151913404464722e-01
    z[3,1,5]  R1488     3.6664155125617981e-01
    z[3,1,5]  R1489     0.366933673620224
    z[3,1,5]  R1490     2.4038605391979218e-01
    z[3,1,5]  R1491     -2.6346214581280947e-03
    z[3,1,5]  R1492     -8.3512723445892334e-02
    z[3,1,5]  R1493     3.2308793067932129e-01
    z[3,1,5]  R1494     -3.8913673162460327e-01
    z[3,1,5]  R1495     -4.0350112318992615e-01
    z[3,1,5]  R1496     -6.3718676567077637e-01
    z[3,1,5]  R1497     -8.0009198188781738e-01
    z[3,1,5]  R1498     -1.8298944830894470e-01
    z[3,1,5]  R1499     1.9466073717921972e-04
    z[3,1,5]  R1500     4.1467356681823730e-01
    z[3,1,5]  R1501     -4.6634575724601746e-01
    z[3,1,5]  R1502     -2.3785832524299622e-01
    z[3,1,5]  R1503     1.3878895342350006e-01
    z[3,1,5]  R1504     -1.7217348515987396e-01
    z[3,1,5]  R1505     -7.0632971823215485e-02
    z[3,1,5]  R1506     2.8447309136390686e-01
    z[3,1,5]  R1507     -0.0577826164662838
    z[3,1,5]  R1508     -3.6176130175590515e-02
    z[3,1,5]  R1509     -3.8039609789848328e-01
    z[3,1,5]  R1510     -5.0422906875610352e-01
    z[3,1,5]  R1511     -0.164892315864563
    z[3,1,5]  R1512     -4.6466124057769775e-01
    z[3,1,5]  R1513     -7.6907074451446533e-01
    z[3,1,5]  R1514     -1.9561339914798737e-01
    z[3,1,5]  R1515     1.6903290152549744e-01
    z[3,1,5]  R1516     -3.4611638635396957e-02
    z[3,1,5]  R1517     -1.5801297500729561e-02
    z[3,1,5]  R1518     4.4854953885078430e-02
    z[3,1,5]  R1519     -1.0670714825391769e-01
    z[3,1,5]  R1520     -7.1751600503921509e-01
    z[3,1,5]  R1521     6.5067127346992493e-02
    z[3,1,5]  R1522     4.9789077043533325e-01
    z[3,1,5]  R1523     -1.0500293225049973e-01
    z[3,1,5]  R1524     -1.1569120734930038e-01
    z[3,1,5]  R1525     6.1202161014080048e-02
    z[3,1,5]  R1526     1.8338931724429131e-02
    z[3,1,5]  R1527     5.3137916326522827e-01
    z[3,1,5]  R1528     3.3780816197395325e-01
    z[3,1,5]  R1529     1.6777861863374710e-02
    z[3,1,5]  R1530     1.9756369292736053e-01
    z[3,1,5]  R1531     3.6830523610115051e-01
    z[3,1,5]  R1532     1.3149045407772064e-01
    z[3,1,5]  R1533     -2.9963439702987671e-01
    z[3,1,5]  R1534     -3.2674390077590942e-01
    z[3,1,5]  R1535     7.1859258413314819e-01
    z[3,1,5]  R1536     9.6005834639072418e-02
    z[3,1,5]  R1537     6.1905288696289062e-01
    z[3,1,5]  R1538     2.3936746641993523e-02
    z[3,1,5]  R1539     -1.3524423539638519e-01
    z[3,1,5]  R1540     8.5094437003135681e-02
    z[3,1,5]  R1541     5.3755539655685425e-01
    z[3,1,5]  R1542     1.3397021591663361e-01
    z[3,1,5]  R1543     -3.2710316777229309e-01
    z[3,1,5]  R1544     1.9581331312656403e-01
    z[3,1,5]  R1545     3.4025412797927856e-01
    z[3,1,5]  R1546     3.0967232584953308e-01
    z[3,1,5]  R1547     -4.6537414193153381e-01
    z[3,1,5]  R1548     -2.0345541834831238e-01
    z[3,1,5]  R1549     -1.7123125493526459e-01
    z[3,1,5]  R1550     5.5556458234786987e-01
    z[3,1,5]  R1551     1.4421881735324860e-01
    z[3,1,5]  R1552     -4.2163927108049393e-02
    z[3,1,5]  R1553     2.1139974892139435e-01
    z[3,1,5]  R1554     4.3668356537818909e-01
    z[3,1,5]  R1555     -4.2336869239807129e-01
    z[3,1,5]  R1556     -1.9220508635044098e-01
    z[3,1,5]  R1557     3.0547830462455750e-01
    z[3,1,5]  R1558     -3.2927942276000977e-01
    z[3,1,5]  R1559     6.5410439856350422e-03
    z[3,1,5]  R1560     -2.1521820127964020e-01
    z[3,1,5]  R1561     1.4981015026569366e-01
    z[3,1,5]  R1562     -0.0714566707611084
    z[3,1,5]  R1563     1.5993739664554596e-01
    z[3,1,5]  R1564     -2.0263540744781494e-01
    z[3,1,5]  R1565     -0.27133908867836
    z[3,1,5]  R1566     -4.7249174118041992e-01
    z[3,1,5]  R1567     -2.1879664063453674e-01
    z[3,1,5]  R1568     2.1051040291786194e-01
    z[3,1,5]  R1569     -4.7900292277336121e-01
    z[3,1,5]  R1570     1.1892103403806686e-01
    z[3,1,5]  R1571     -2.1886758506298065e-02
    z[3,1,5]  R1572     -5.5067169666290283e-01
    z[3,1,5]  R1573     -9.6480071544647217e-02
    z[3,1,5]  R1574     7.9776518046855927e-02
    z[3,1,5]  R1575     -0.0778428167104721
    z[3,1,5]  R1576     -9.3156717717647552e-02
    z[3,1,5]  R1577     1.4025831222534180e-01
    z[3,1,5]  R1578     -3.3763861656188965e-01
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R1457     -1
    z[3,1,6]  R1458     1
    z[3,1,6]  R1459     1.8634596839547157e-02
    z[3,1,6]  R1460     6.1599975824356079e-01
    z[3,1,6]  R1461     2.8018739819526672e-01
    z[3,1,6]  R1462     3.2007377594709396e-02
    z[3,1,6]  R1463     4.5550405979156494e-01
    z[3,1,6]  R1464     5.9498608112335205e-02
    z[3,1,6]  R1465     9.0559042990207672e-02
    z[3,1,6]  R1466     1.9700525701045990e-01
    z[3,1,6]  R1467     6.8040627241134644e-01
    z[3,1,6]  R1468     4.9363193102180958e-03
    z[3,1,6]  R1469     -2.4662408232688904e-01
    z[3,1,6]  R1470     -7.3229223489761353e-02
    z[3,1,6]  R1471     5.0963556766510010e-01
    z[3,1,6]  R1472     5.3769510984420776e-01
    z[3,1,6]  R1473     1.2688353657722473e-01
    z[3,1,6]  R1474     7.3101505637168884e-02
    z[3,1,6]  R1475     9.3675171956419945e-03
    z[3,1,6]  R1476     -1.5260463953018188e-01
    z[3,1,6]  R1477     -0.163701593875885
    z[3,1,6]  R1478     1.6433374583721161e-01
    z[3,1,6]  R1479     -2.5771612301468849e-02
    z[3,1,6]  R1480     -2.8085660934448242e-01
    z[3,1,6]  R1481     2.1825022995471954e-01
    z[3,1,6]  R1482     2.3344756662845612e-01
    z[3,1,6]  R1483     2.6692020893096924e-01
    z[3,1,6]  R1484     -6.2983624637126923e-02
    z[3,1,6]  R1485     6.0644489526748657e-01
    z[3,1,6]  R1486     0.150406152009964
    z[3,1,6]  R1487     1.0031318664550781e-01
    z[3,1,6]  R1488     1.2571129016578197e-02
    z[3,1,6]  R1489     4.1141849756240845e-01
    z[3,1,6]  R1490     3.5320450551807880e-03
    z[3,1,6]  R1491     6.8976622819900513e-01
    z[3,1,6]  R1492     -1.2096484750509262e-01
    z[3,1,6]  R1493     3.9257019758224487e-01
    z[3,1,6]  R1494     1.1280041933059692e-01
    z[3,1,6]  R1495     4.1892158985137939e-01
    z[3,1,6]  R1496     5.0528898835182190e-02
    z[3,1,6]  R1497     0.161977618932724
    z[3,1,6]  R1498     3.3900722861289978e-01
    z[3,1,6]  R1499     2.2306475043296814e-01
    z[3,1,6]  R1500     3.1190004944801331e-01
    z[3,1,6]  R1501     -7.7244572341442108e-02
    z[3,1,6]  R1502     2.8067186474800110e-01
    z[3,1,6]  R1503     2.8628465533256531e-01
    z[3,1,6]  R1504     2.0274116098880768e-01
    z[3,1,6]  R1505     3.5062986612319946e-01
    z[3,1,6]  R1506     2.9905807971954346e-01
    z[3,1,6]  R1507     1.8012440204620361e-01
    z[3,1,6]  R1508     -1.4839315414428711e-01
    z[3,1,6]  R1509     2.5978598743677139e-02
    z[3,1,6]  R1510     2.5896498560905457e-01
    z[3,1,6]  R1511     2.2164984047412872e-01
    z[3,1,6]  R1512     3.9759743958711624e-03
    z[3,1,6]  R1513     -1.1250501126050949e-01
    z[3,1,6]  R1514     1.7408958077430725e-01
    z[3,1,6]  R1515     1.3000544905662537e-01
    z[3,1,6]  R1516     -2.1116336807608604e-02
    z[3,1,6]  R1517     2.4243091046810150e-01
    z[3,1,6]  R1518     4.6817961335182190e-01
    z[3,1,6]  R1519     -2.7770814299583435e-01
    z[3,1,6]  R1520     -4.0957968682050705e-02
    z[3,1,6]  R1521     1.5679925680160522e-02
    z[3,1,6]  R1522     2.3461225628852844e-01
    z[3,1,6]  R1523     -6.1612367630004883e-01
    z[3,1,6]  R1524     -0.510966956615448
    z[3,1,6]  R1525     2.5119778513908386e-01
    z[3,1,6]  R1526     1.0444530844688416e-01
    z[3,1,6]  R1527     -2.8750613331794739e-01
    z[3,1,6]  R1528     -5.2096154540777206e-02
    z[3,1,6]  R1529     -6.3579088449478149e-01
    z[3,1,6]  R1530     -3.9047278463840485e-02
    z[3,1,6]  R1531     -5.7067770510911942e-02
    z[3,1,6]  R1532     -4.9153414368629456e-01
    z[3,1,6]  R1533     -3.9015471935272217e-01
    z[3,1,6]  R1534     2.3470519483089447e-01
    z[3,1,6]  R1535     -6.4734026789665222e-02
    z[3,1,6]  R1536     7.1323089301586151e-02
    z[3,1,6]  R1537     0.603255033493042
    z[3,1,6]  R1538     -1.8306757509708405e-01
    z[3,1,6]  R1539     -6.2811499834060669e-01
    z[3,1,6]  R1540     -5.8990508317947388e-01
    z[3,1,6]  R1541     4.7271189093589783e-01
    z[3,1,6]  R1542     -3.1926280260086060e-01
    z[3,1,6]  R1543     -1.4661435782909393e-01
    z[3,1,6]  R1544     5.3604024648666382e-01
    z[3,1,6]  R1545     -4.1475647687911987e-01
    z[3,1,6]  R1546     -1.1077469587326050e-01
    z[3,1,6]  R1547     -4.6451419591903687e-01
    z[3,1,6]  R1548     5.5887496471405029e-01
    z[3,1,6]  R1549     -1.7274679243564606e-01
    z[3,1,6]  R1550     1.2963366508483887e-01
    z[3,1,6]  R1551     5.8247900009155273e-01
    z[3,1,6]  R1552     1.6660098731517792e-01
    z[3,1,6]  R1553     -1.5399083495140076e-01
    z[3,1,6]  R1554     1.0274005681276321e-01
    z[3,1,6]  R1555     -1.6138151288032532e-01
    z[3,1,6]  R1556     -2.3751424252986908e-01
    z[3,1,6]  R1557     -4.2117387056350708e-01
    z[3,1,6]  R1558     5.3832399845123291e-01
    z[3,1,6]  R1559     -9.5269419252872467e-02
    z[3,1,6]  R1560     -0.337056040763855
    z[3,1,6]  R1561     -3.3285051584243774e-01
    z[3,1,6]  R1562     0.341945618391037
    z[3,1,6]  R1563     -2.7795326709747314e-01
    z[3,1,6]  R1564     -2.9696673154830933e-01
    z[3,1,6]  R1565     6.0295134782791138e-01
    z[3,1,6]  R1566     3.2087239623069763e-01
    z[3,1,6]  R1567     3.1672829389572144e-01
    z[3,1,6]  R1568     -2.7522730827331543e-01
    z[3,1,6]  R1569     -3.6352673172950745e-01
    z[3,1,6]  R1570     3.1183210015296936e-01
    z[3,1,6]  R1571     -0.522093653678894
    z[3,1,6]  R1572     8.4165006875991821e-02
    z[3,1,6]  R1573     4.1922721266746521e-01
    z[3,1,6]  R1574     -1.0764741152524948e-01
    z[3,1,6]  R1575     -8.9159741997718811e-02
    z[3,1,6]  R1576     1.8927218019962311e-01
    z[3,1,6]  R1577     -0.0878983587026596
    z[3,1,6]  R1578     9.3493327498435974e-02
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1579     -1
    z[2,5,0]  R1580     1
    z[2,5,0]  R1593     0.443828284740448
    z[2,5,0]  R1594     0.596022367477417
    z[2,5,0]  R1595     5.8625990152359009e-01
    z[2,5,0]  R1596     4.5706677436828613e-01
    z[2,5,0]  R1597     2.2589190304279327e-01
    z[2,5,0]  R1598     3.8704875111579895e-01
    z[2,5,0]  R1599     3.0130943655967712e-01
    z[2,5,0]  R1600     5.8022117614746094e-01
    z[2,5,0]  R1601     0.547103226184845
    z[2,5,0]  R1602     -1.9522064924240112e-01
    z[2,5,0]  R1603     -5.9889388084411621e-01
    z[2,5,0]  R1604     -5.5948734283447266e-01
    z[2,5,0]  R1605     -7.2994542121887207e-01
    z[2,5,0]  R1606     -4.2817932367324829e-01
    z[2,5,0]  R1607     -7.4910598993301392e-01
    z[2,5,0]  R1608     -4.0614092350006104e-01
    z[2,5,0]  R1609     -5.9933245182037354e-01
    z[2,5,0]  R1610     -3.8821491599082947e-01
    z[2,5,0]  R1611     -2.6076626777648926e-01
    z[2,5,0]  R1612     -4.7347363829612732e-01
    z[2,5,0]  R1613     -1.8241828307509422e-02
    z[2,5,0]  R1614     3.5420483350753784e-01
    z[2,5,0]  R1615     -3.4724938869476318e-01
    z[2,5,0]  R1616     -0.0746384710073471
    z[2,5,0]  R1617     2.0175845921039581e-01
    z[2,5,0]  R1618     -1.2036658078432083e-01
    z[2,5,0]  R1619     -1.1681912094354630e-01
    z[2,5,0]  R1620     2.6472198963165283e-01
    z[2,5,0]  R1621     -6.0214199125766754e-02
    z[2,5,0]  R1622     -1.1675311252474785e-02
    z[2,5,0]  R1623     -3.9184695482254028e-01
    z[2,5,0]  R1624     -0.439421683549881
    z[2,5,0]  R1625     -0.185368150472641
    z[2,5,0]  R1626     -1.0790064185857773e-01
    z[2,5,0]  R1627     -5.3795784711837769e-01
    z[2,5,0]  R1628     -3.2538771629333496e-01
    z[2,5,0]  R1629     8.3735115826129913e-02
    z[2,5,0]  R1630     -4.8598015308380127e-01
    z[2,5,0]  R1631     -4.9811840057373047e-01
    z[2,5,0]  R1632     -0.307282954454422
    z[2,5,0]  R1633     3.0187436938285828e-01
    z[2,5,0]  R1634     1.7252075672149658e-01
    z[2,5,0]  R1635     5.6933969259262085e-01
    z[2,5,0]  R1636     4.8623824119567871e-01
    z[2,5,0]  R1637     7.0192024111747742e-02
    z[2,5,0]  R1638     -0.515808641910553
    z[2,5,0]  R1639     -7.7421814203262329e-01
    z[2,5,0]  R1640     -7.2666066884994507e-01
    z[2,5,0]  R1641     -6.8753719329833984e-01
    z[2,5,0]  R1642     -8.2020163536071777e-01
    z[2,5,0]  R1643     -7.3201900720596313e-01
    z[2,5,0]  R1644     -6.6962039470672607e-01
    z[2,5,0]  R1645     -7.2000789642333984e-01
    z[2,5,0]  R1646     -6.6059869527816772e-01
    z[2,5,0]  R1647     -6.0361480712890625e-01
    z[2,5,0]  R1648     5.0988274812698364e-01
    z[2,5,0]  R1649     -3.1249552965164185e-01
    z[2,5,0]  R1650     -3.3379566669464111e-01
    z[2,5,0]  R1651     -4.5933774113655090e-01
    z[2,5,0]  R1652     -5.1589739322662354e-01
    z[2,5,0]  R1653     -3.5599014163017273e-01
    z[2,5,0]  R1654     -2.8960227966308594e-01
    z[2,5,0]  R1655     -5.7515543699264526e-01
    z[2,5,0]  R1656     -4.1426292061805725e-01
    z[2,5,0]  R1657     -3.2901623845100403e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1581     -1
    z[2,5,1]  R1582     1
    z[2,5,1]  R1593     2.3911124467849731e-01
    z[2,5,1]  R1594     1.0747678577899933e-01
    z[2,5,1]  R1595     9.9074125289916992e-02
    z[2,5,1]  R1596     2.6177468895912170e-01
    z[2,5,1]  R1597     2.9460325837135315e-01
    z[2,5,1]  R1598     3.5361862182617188e-01
    z[2,5,1]  R1599     3.4898763895034790e-01
    z[2,5,1]  R1600     4.8065102100372314e-01
    z[2,5,1]  R1601     2.5980255007743835e-01
    z[2,5,1]  R1602     -8.5558688640594482e-01
    z[2,5,1]  R1603     -8.5406258702278137e-02
    z[2,5,1]  R1604     -4.2828482389450073e-01
    z[2,5,1]  R1605     -4.5273122191429138e-01
    z[2,5,1]  R1606     -1.1212576180696487e-01
    z[2,5,1]  R1607     -3.8804542273283005e-03
    z[2,5,1]  R1608     -3.9136001467704773e-01
    z[2,5,1]  R1609     1.3638220727443695e-01
    z[2,5,1]  R1610     -8.1791423261165619e-02
    z[2,5,1]  R1611     -9.3317642807960510e-02
    z[2,5,1]  R1612     1.5056781470775604e-01
    z[2,5,1]  R1613     -5.1217317581176758e-01
    z[2,5,1]  R1614     -1.7223972082138062e-01
    z[2,5,1]  R1615     -2.8673630952835083e-01
    z[2,5,1]  R1616     -0.224474236369133
    z[2,5,1]  R1617     -9.3072272837162018e-02
    z[2,5,1]  R1618     -1.6432899236679077e-01
    z[2,5,1]  R1619     1.0145115852355957e-01
    z[2,5,1]  R1620     -2.4835982918739319e-01
    z[2,5,1]  R1621     -5.6369885802268982e-02
    z[2,5,1]  R1622     5.9535884857177734e-01
    z[2,5,1]  R1623     4.0345042943954468e-02
    z[2,5,1]  R1624     -4.2288365960121155e-01
    z[2,5,1]  R1625     -5.5005472898483276e-01
    z[2,5,1]  R1626     2.0386627316474915e-01
    z[2,5,1]  R1627     4.4791221618652344e-02
    z[2,5,1]  R1628     3.4200098365545273e-02
    z[2,5,1]  R1629     6.9640129804611206e-01
    z[2,5,1]  R1630     8.0537945032119751e-01
    z[2,5,1]  R1631     -2.2044022381305695e-01
    z[2,5,1]  R1632     8.9695996046066284e-01
    z[2,5,1]  R1633     3.5130563378334045e-01
    z[2,5,1]  R1634     0.533920407295227
    z[2,5,1]  R1635     -2.9374182224273682e-01
    z[2,5,1]  R1636     -2.1514658629894257e-01
    z[2,5,1]  R1637     -8.2180780172348022e-01
    z[2,5,1]  R1638     5.8445432223379612e-03
    z[2,5,1]  R1639     1.4068324863910675e-01
    z[2,5,1]  R1640     7.3817779775708914e-04
    z[2,5,1]  R1641     1.3491672277450562e-01
    z[2,5,1]  R1642     -6.0320448130369186e-02
    z[2,5,1]  R1643     1.4563761651515961e-01
    z[2,5,1]  R1644     -1.0970515012741089e-01
    z[2,5,1]  R1645     -9.2762567102909088e-02
    z[2,5,1]  R1646     -1.0863159596920013e-01
    z[2,5,1]  R1647     -1.7153373360633850e-01
    z[2,5,1]  R1648     -0.0805494487285614
    z[2,5,1]  R1649     -9.0810102224349976e-01
    z[2,5,1]  R1650     -0.869015097618103
    z[2,5,1]  R1651     -8.6112791299819946e-01
    z[2,5,1]  R1652     -8.1934183835983276e-01
    z[2,5,1]  R1653     -8.2074803113937378e-01
    z[2,5,1]  R1654     -8.6880356073379517e-01
    z[2,5,1]  R1655     -0.808609127998352
    z[2,5,1]  R1656     -0.849862277507782
    z[2,5,1]  R1657     -8.1476384401321411e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1583     -1
    z[2,5,2]  R1584     1
    z[2,5,2]  R1593     7.6214402914047241e-01
    z[2,5,2]  R1594     6.6670817136764526e-01
    z[2,5,2]  R1595     4.9157905578613281e-01
    z[2,5,2]  R1596     6.5431642532348633e-01
    z[2,5,2]  R1597     5.9676152467727661e-01
    z[2,5,2]  R1598     2.5834500789642334e-01
    z[2,5,2]  R1599     5.4126840829849243e-01
    z[2,5,2]  R1600     2.7784049510955811e-01
    z[2,5,2]  R1601     4.7331610321998596e-01
    z[2,5,2]  R1602     -2.9964751005172729e-01
    z[2,5,2]  R1603     -6.2315952777862549e-01
    z[2,5,2]  R1604     -4.5713719725608826e-01
    z[2,5,2]  R1605     -4.9130564928054810e-01
    z[2,5,2]  R1606     -5.4274529218673706e-01
    z[2,5,2]  R1607     -5.8590775728225708e-01
    z[2,5,2]  R1608     -6.0285305976867676e-01
    z[2,5,2]  R1609     -4.5472463965415955e-01
    z[2,5,2]  R1610     -4.4478836655616760e-01
    z[2,5,2]  R1611     -6.2860614061355591e-01
    z[2,5,2]  R1612     -4.3422549962997437e-01
    z[2,5,2]  R1613     -5.4368627071380615e-01
    z[2,5,2]  R1614     4.5820564031600952e-01
    z[2,5,2]  R1615     -2.3959949612617493e-01
    z[2,5,2]  R1616     -1.8490347266197205e-01
    z[2,5,2]  R1617     7.0345804095268250e-02
    z[2,5,2]  R1618     5.7068395614624023e-01
    z[2,5,2]  R1619     1.6660247743129730e-01
    z[2,5,2]  R1620     -4.9605220556259155e-02
    z[2,5,2]  R1621     1.3281117379665375e-01
    z[2,5,2]  R1622     1.6671356558799744e-01
    z[2,5,2]  R1623     -7.1254062652587891e-01
    z[2,5,2]  R1624     -4.4756001234054565e-01
    z[2,5,2]  R1625     -6.0772401094436646e-01
    z[2,5,2]  R1626     3.6574136465787888e-02
    z[2,5,2]  R1627     1.7348611354827881e-01
    z[2,5,2]  R1628     -3.8892120122909546e-02
    z[2,5,2]  R1629     8.6048319935798645e-02
    z[2,5,2]  R1630     5.2002891898155212e-02
    z[2,5,2]  R1631     2.6664009690284729e-01
    z[2,5,2]  R1632     -8.1974111497402191e-02
    z[2,5,2]  R1633     7.0917874574661255e-01
    z[2,5,2]  R1634     2.5928530097007751e-01
    z[2,5,2]  R1635     3.1012037396430969e-01
    z[2,5,2]  R1636     -3.2536625862121582e-02
    z[2,5,2]  R1637     -3.9016953110694885e-01
    z[2,5,2]  R1638     -6.8645989894866943e-01
    z[2,5,2]  R1639     -4.4923231005668640e-01
    z[2,5,2]  R1640     -3.8668170571327209e-01
    z[2,5,2]  R1641     -5.1158332824707031e-01
    z[2,5,2]  R1642     -4.4767141342163086e-01
    z[2,5,2]  R1643     -4.2879101634025574e-01
    z[2,5,2]  R1644     -4.6130201220512390e-01
    z[2,5,2]  R1645     -5.1986885070800781e-01
    z[2,5,2]  R1646     -5.7390749454498291e-01
    z[2,5,2]  R1647     -3.1425091624259949e-01
    z[2,5,2]  R1648     1.3133190572261810e-02
    z[2,5,2]  R1649     5.4675798863172531e-02
    z[2,5,2]  R1650     1.2007483094930649e-01
    z[2,5,2]  R1651     7.4041627347469330e-02
    z[2,5,2]  R1652     8.9316859841346741e-02
    z[2,5,2]  R1653     0.255808025598526
    z[2,5,2]  R1654     2.0567758381366730e-01
    z[2,5,2]  R1655     2.1160072647035122e-03
    z[2,5,2]  R1656     -2.2815535962581635e-01
    z[2,5,2]  R1657     3.6205747723579407e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1585     -1
    z[2,5,3]  R1586     1
    z[2,5,3]  R1593     -1.3017807900905609e-01
    z[2,5,3]  R1594     -4.1541284322738647e-01
    z[2,5,3]  R1595     -5.3775084018707275e-01
    z[2,5,3]  R1596     -2.1474617719650269e-01
    z[2,5,3]  R1597     -6.2661296129226685e-01
    z[2,5,3]  R1598     -7.4903172254562378e-01
    z[2,5,3]  R1599     -6.2439376115798950e-01
    z[2,5,3]  R1600     -5.8437591791152954e-01
    z[2,5,3]  R1601     -1.6673199832439423e-01
    z[2,5,3]  R1602     -1.1684054881334305e-01
    z[2,5,3]  R1603     -1.6926182806491852e-01
    z[2,5,3]  R1604     3.2364353537559509e-01
    z[2,5,3]  R1605     -1.0207553952932358e-01
    z[2,5,3]  R1606     4.0911316871643066e-01
    z[2,5,3]  R1607     1.8863391876220703e-01
    z[2,5,3]  R1608     2.4182501435279846e-01
    z[2,5,3]  R1609     3.3136495947837830e-01
    z[2,5,3]  R1610     4.2438396811485291e-01
    z[2,5,3]  R1611     1.3828664086759090e-02
    z[2,5,3]  R1612     1.9436357915401459e-01
    z[2,5,3]  R1613     -1.8136920034885406e-01
    z[2,5,3]  R1614     7.9428905248641968e-01
    z[2,5,3]  R1615     -2.1760773658752441e-01
    z[2,5,3]  R1616     -1.7980632185935974e-01
    z[2,5,3]  R1617     8.1366300582885742e-01
    z[2,5,3]  R1618     5.4640734195709229e-01
    z[2,5,3]  R1619     4.6961575746536255e-01
    z[2,5,3]  R1620     4.2552584409713745e-01
    z[2,5,3]  R1621     3.7509584426879883e-01
    z[2,5,3]  R1622     6.2250560522079468e-01
    z[2,5,3]  R1623     -6.3955806195735931e-02
    z[2,5,3]  R1624     -1.2864026427268982e-01
    z[2,5,3]  R1625     -3.7321120500564575e-01
    z[2,5,3]  R1626     7.0065855979919434e-01
    z[2,5,3]  R1627     6.0737454891204834e-01
    z[2,5,3]  R1628     4.0486183762550354e-01
    z[2,5,3]  R1629     0.525330126285553
    z[2,5,3]  R1630     1.1478332430124283e-01
    z[2,5,3]  R1631     4.6427825093269348e-01
    z[2,5,3]  R1632     1.0086484998464584e-01
    z[2,5,3]  R1633     1.1797262728214264e-01
    z[2,5,3]  R1634     -1.8861134350299835e-01
    z[2,5,3]  R1635     -3.9001864194869995e-01
    z[2,5,3]  R1636     -1.2386147864162922e-02
    z[2,5,3]  R1637     9.1523475944995880e-02
    z[2,5,3]  R1638     -4.4778978824615479e-01
    z[2,5,3]  R1639     -2.2499673068523407e-01
    z[2,5,3]  R1640     -3.6721962690353394e-01
    z[2,5,3]  R1641     -3.1424438953399658e-01
    z[2,5,3]  R1642     -2.8693222999572754e-01
    z[2,5,3]  R1643     -2.1840566396713257e-01
    z[2,5,3]  R1644     -4.9941259622573853e-01
    z[2,5,3]  R1645     -1.5288800001144409e-01
    z[2,5,3]  R1646     -1.9498866796493530e-01
    z[2,5,3]  R1647     -6.9235080480575562e-01
    z[2,5,3]  R1648     3.9728403091430664e-01
    z[2,5,3]  R1649     1.4180057682096958e-02
    z[2,5,3]  R1650     2.6352667808532715e-01
    z[2,5,3]  R1651     1.4667358994483948e-01
    z[2,5,3]  R1652     -9.8329484462738037e-02
    z[2,5,3]  R1653     3.1888020038604736e-01
    z[2,5,3]  R1654     -9.0936720371246338e-02
    z[2,5,3]  R1655     -1.0214445739984512e-01
    z[2,5,3]  R1656     -7.7040627598762512e-02
    z[2,5,3]  R1657     -0.0776321142911911
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1587     -1
    z[2,5,4]  R1588     1
    z[2,5,4]  R1593     -0.0178383756428957
    z[2,5,4]  R1594     -4.6718839555978775e-02
    z[2,5,4]  R1595     -6.0257494449615479e-02
    z[2,5,4]  R1596     -4.5382639765739441e-01
    z[2,5,4]  R1597     -2.5469473004341125e-01
    z[2,5,4]  R1598     -1.0551095008850098e-01
    z[2,5,4]  R1599     2.9713329672813416e-01
    z[2,5,4]  R1600     3.7180770188570023e-02
    z[2,5,4]  R1601     4.0392377972602844e-01
    z[2,5,4]  R1602     2.4103714525699615e-01
    z[2,5,4]  R1603     -2.5213941931724548e-01
    z[2,5,4]  R1604     -2.4225538969039917e-01
    z[2,5,4]  R1605     -9.1686114668846130e-02
    z[2,5,4]  R1606     -1.3998466730117798e-01
    z[2,5,4]  R1607     9.2688970267772675e-02
    z[2,5,4]  R1608     5.2372928708791733e-02
    z[2,5,4]  R1609     -1.0429803282022476e-01
    z[2,5,4]  R1610     -1.0389237850904465e-01
    z[2,5,4]  R1611     1.7746625840663910e-01
    z[2,5,4]  R1612     -4.4248613715171814e-01
    z[2,5,4]  R1613     -1.3213990628719330e-01
    z[2,5,4]  R1614     -5.9071164578199387e-02
    z[2,5,4]  R1615     -4.3168950080871582e-01
    z[2,5,4]  R1616     -7.5712114572525024e-01
    z[2,5,4]  R1617     1.1694841831922531e-01
    z[2,5,4]  R1618     -9.3024484813213348e-02
    z[2,5,4]  R1619     -6.8430745601654053e-01
    z[2,5,4]  R1620     -6.5788125991821289e-01
    z[2,5,4]  R1621     -6.9979226589202881e-01
    z[2,5,4]  R1622     -3.6981284618377686e-01
    z[2,5,4]  R1623     1.1258546262979507e-01
    z[2,5,4]  R1624     -3.7390846014022827e-01
    z[2,5,4]  R1625     3.3302713185548782e-02
    z[2,5,4]  R1626     -1.9245386123657227e-01
    z[2,5,4]  R1627     -2.9392004013061523e-01
    z[2,5,4]  R1628     -7.5283324718475342e-01
    z[2,5,4]  R1629     -7.0575617253780365e-02
    z[2,5,4]  R1630     1.0091464221477509e-01
    z[2,5,4]  R1631     9.7659686580300331e-03
    z[2,5,4]  R1632     1.2039819359779358e-01
    z[2,5,4]  R1633     2.4496251344680786e-01
    z[2,5,4]  R1634     -6.2972551584243774e-01
    z[2,5,4]  R1635     0.0307974424213171
    z[2,5,4]  R1636     -4.2809373140335083e-01
    z[2,5,4]  R1637     -1.5423774719238281e-01
    z[2,5,4]  R1638     2.0271413028240204e-01
    z[2,5,4]  R1639     2.6255783438682556e-01
    z[2,5,4]  R1640     4.0326413512229919e-01
    z[2,5,4]  R1641     1.6242672502994537e-01
    z[2,5,4]  R1642     -2.8086664155125618e-02
    z[2,5,4]  R1643     3.9591252803802490e-01
    z[2,5,4]  R1644     1.4629776775836945e-01
    z[2,5,4]  R1645     1.8903563916683197e-01
    z[2,5,4]  R1646     1.3146454095840454e-01
    z[2,5,4]  R1647     -1.2828269600868225e-01
    z[2,5,4]  R1648     -3.3598041534423828e-01
    z[2,5,4]  R1649     1.7064245045185089e-01
    z[2,5,4]  R1650     1.7576907575130463e-01
    z[2,5,4]  R1651     -9.3462634831666946e-03
    z[2,5,4]  R1652     6.0886070132255554e-02
    z[2,5,4]  R1653     1.1964366585016251e-01
    z[2,5,4]  R1654     1.8079565837979317e-02
    z[2,5,4]  R1655     -5.3978666663169861e-02
    z[2,5,4]  R1656     -1.0950735211372375e-01
    z[2,5,4]  R1657     -1.6522422432899475e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1589     -1
    z[2,5,5]  R1590     1
    z[2,5,5]  R1593     3.8339686393737793e-01
    z[2,5,5]  R1594     7.4416443705558777e-02
    z[2,5,5]  R1595     2.6872122287750244e-01
    z[2,5,5]  R1596     1.9816392660140991e-01
    z[2,5,5]  R1597     2.1644225716590881e-01
    z[2,5,5]  R1598     2.7994787693023682e-01
    z[2,5,5]  R1599     1.2733405828475952e-01
    z[2,5,5]  R1600     -1.0238508880138397e-01
    z[2,5,5]  R1601     3.4010317921638489e-01
    z[2,5,5]  R1602     -3.9974547922611237e-02
    z[2,5,5]  R1603     -3.6941388249397278e-01
    z[2,5,5]  R1604     -3.4650653600692749e-01
    z[2,5,5]  R1605     -4.4726513326168060e-02
    z[2,5,5]  R1606     -0.519870400428772
    z[2,5,5]  R1607     -1.6513921320438385e-01
    z[2,5,5]  R1608     -3.3169832825660706e-01
    z[2,5,5]  R1609     -4.7022223472595215e-01
    z[2,5,5]  R1610     -6.1688584089279175e-01
    z[2,5,5]  R1611     -6.2938481569290161e-01
    z[2,5,5]  R1612     -5.7471239566802979e-01
    z[2,5,5]  R1613     -6.2409126758575439e-01
    z[2,5,5]  R1614     -1.6205992549657822e-02
    z[2,5,5]  R1615     -4.0821567177772522e-01
    z[2,5,5]  R1616     -5.4451203346252441e-01
    z[2,5,5]  R1617     -1.0340183973312378e-01
    z[2,5,5]  R1618     5.6958663463592529e-01
    z[2,5,5]  R1619     4.1589897871017456e-01
    z[2,5,5]  R1620     3.1338497996330261e-01
    z[2,5,5]  R1621     3.9741155505180359e-01
    z[2,5,5]  R1622     -2.8564637899398804e-01
    z[2,5,5]  R1623     -5.6243741512298584e-01
    z[2,5,5]  R1624     -4.5603013038635254e-01
    z[2,5,5]  R1625     -3.9154800772666931e-01
    z[2,5,5]  R1626     -4.0158487856388092e-02
    z[2,5,5]  R1627     3.2321658730506897e-01
    z[2,5,5]  R1628     3.2331734895706177e-01
    z[2,5,5]  R1629     -4.0162622928619385e-01
    z[2,5,5]  R1630     2.4523507058620453e-01
    z[2,5,5]  R1631     3.1295937299728394e-01
    z[2,5,5]  R1632     1.1620508134365082e-01
    z[2,5,5]  R1633     -3.9929196238517761e-01
    z[2,5,5]  R1634     -2.4968470633029938e-01
    z[2,5,5]  R1635     -5.5485677719116211e-01
    z[2,5,5]  R1636     -4.7112739086151123e-01
    z[2,5,5]  R1637     3.3411204814910889e-01
    z[2,5,5]  R1638     2.5637684389948845e-02
    z[2,5,5]  R1639     -2.4374802410602570e-01
    z[2,5,5]  R1640     1.5165130794048309e-01
    z[2,5,5]  R1641     -1.5895521640777588e-01
    z[2,5,5]  R1642     1.6387178003787994e-01
    z[2,5,5]  R1643     -3.0993044376373291e-02
    z[2,5,5]  R1644     -2.2050505876541138e-01
    z[2,5,5]  R1645     3.0824041366577148e-01
    z[2,5,5]  R1646     1.1866968125104904e-01
    z[2,5,5]  R1647     -1.0495049506425858e-01
    z[2,5,5]  R1648     5.2054870128631592e-01
    z[2,5,5]  R1649     0.147319495677948
    z[2,5,5]  R1650     2.0072488114237785e-02
    z[2,5,5]  R1651     1.0734124481678009e-01
    z[2,5,5]  R1652     1.9797259569168091e-01
    z[2,5,5]  R1653     7.8324370086193085e-02
    z[2,5,5]  R1654     2.6179236173629761e-01
    z[2,5,5]  R1655     -1.7094336450099945e-02
    z[2,5,5]  R1656     1.8547664582729340e-01
    z[2,5,5]  R1657     2.2930899262428284e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1591     -1
    z[2,5,6]  R1592     1
    z[2,5,6]  R1593     2.6852054521441460e-02
    z[2,5,6]  R1594     -9.1749869287014008e-02
    z[2,5,6]  R1595     1.9953864812850952e-01
    z[2,5,6]  R1596     -5.5594801902770996e-02
    z[2,5,6]  R1597     4.1194528341293335e-02
    z[2,5,6]  R1598     -8.8617682456970215e-02
    z[2,5,6]  R1599     8.8885044679045677e-03
    z[2,5,6]  R1600     -4.1980691254138947e-02
    z[2,5,6]  R1601     3.2020047307014465e-01
    z[2,5,6]  R1602     2.5830745697021484e-01
    z[2,5,6]  R1603     -1.3043585419654846e-01
    z[2,5,6]  R1604     -1.0522356629371643e-01
    z[2,5,6]  R1605     -2.6178336702287197e-03
    z[2,5,6]  R1606     -2.2865532338619232e-01
    z[2,5,6]  R1607     -1.5521687269210815e-01
    z[2,5,6]  R1608     -3.8367825746536255e-01
    z[2,5,6]  R1609     2.7135983109474182e-01
    z[2,5,6]  R1610     2.7077487111091614e-01
    z[2,5,6]  R1611     3.1675910949707031e-01
    z[2,5,6]  R1612     2.7105422690510750e-02
    z[2,5,6]  R1613     4.3651174753904343e-02
    z[2,5,6]  R1614     1.6516314819455147e-02
    z[2,5,6]  R1615     5.8261758089065552e-01
    z[2,5,6]  R1616     0.0882897898554802
    z[2,5,6]  R1617     -5.0918185710906982e-01
    z[2,5,6]  R1618     -3.4413103014230728e-02
    z[2,5,6]  R1619     -2.9413762688636780e-01
    z[2,5,6]  R1620     3.9203155040740967e-01
    z[2,5,6]  R1621     4.3268457055091858e-01
    z[2,5,6]  R1622     -1.0839474201202393e-01
    z[2,5,6]  R1623     6.3343368470668793e-02
    z[2,5,6]  R1624     0.25189009308815
    z[2,5,6]  R1625     6.6726314835250378e-03
    z[2,5,6]  R1626     -6.4489126205444336e-01
    z[2,5,6]  R1627     -3.4458079934120178e-01
    z[2,5,6]  R1628     2.3714034259319305e-01
    z[2,5,6]  R1629     2.4156366288661957e-01
    z[2,5,6]  R1630     1.7024591565132141e-01
    z[2,5,6]  R1631     5.6444126367568970e-01
    z[2,5,6]  R1632     -2.3695375025272369e-01
    z[2,5,6]  R1633     -2.2172866761684418e-01
    z[2,5,6]  R1634     3.5137692093849182e-01
    z[2,5,6]  R1635     -1.8017850816249847e-01
    z[2,5,6]  R1636     5.5753654241561890e-01
    z[2,5,6]  R1637     -1.5387046337127686e-01
    z[2,5,6]  R1638     1.4287789165973663e-01
    z[2,5,6]  R1639     3.4167438279837370e-03
    z[2,5,6]  R1640     -4.4392615556716919e-02
    z[2,5,6]  R1641     3.1140625476837158e-01
    z[2,5,6]  R1642     1.1510109901428223e-01
    z[2,5,6]  R1643     -2.3166318237781525e-01
    z[2,5,6]  R1644     -8.5646532475948334e-02
    z[2,5,6]  R1645     -2.2045131027698517e-01
    z[2,5,6]  R1646     -3.9121967554092407e-01
    z[2,5,6]  R1647     2.5514401495456696e-02
    z[2,5,6]  R1648     -4.3780177831649780e-01
    z[2,5,6]  R1649     -1.5390457212924957e-01
    z[2,5,6]  R1650     1.3502325117588043e-01
    z[2,5,6]  R1651     -9.4142660498619080e-02
    z[2,5,6]  R1652     4.4523306190967560e-02
    z[2,5,6]  R1653     -1.0987244546413422e-01
    z[2,5,6]  R1654     2.0463684201240540e-01
    z[2,5,6]  R1655     4.1273102164268494e-02
    z[2,5,6]  R1656     -4.1673827916383743e-02
    z[2,5,6]  R1657     1.0447089374065399e-01
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1658     -1
    z[5,2,0]  R1659     1
    z[5,2,0]  R1672     3.0187436938285828e-01
    z[5,2,0]  R1673     1.7252075672149658e-01
    z[5,2,0]  R1674     5.6933969259262085e-01
    z[5,2,0]  R1675     4.8623824119567871e-01
    z[5,2,0]  R1676     7.0192024111747742e-02
    z[5,2,0]  R1677     -0.515808641910553
    z[5,2,0]  R1678     -7.7421814203262329e-01
    z[5,2,0]  R1679     -7.2666066884994507e-01
    z[5,2,0]  R1680     -6.8753719329833984e-01
    z[5,2,0]  R1681     -8.2020163536071777e-01
    z[5,2,0]  R1682     -7.3201900720596313e-01
    z[5,2,0]  R1683     -6.6962039470672607e-01
    z[5,2,0]  R1684     -7.2000789642333984e-01
    z[5,2,0]  R1685     -6.6059869527816772e-01
    z[5,2,0]  R1686     -6.0361480712890625e-01
    z[5,2,0]  R1687     5.0988274812698364e-01
    z[5,2,0]  R1688     -3.1249552965164185e-01
    z[5,2,0]  R1689     -3.3379566669464111e-01
    z[5,2,0]  R1690     -4.5933774113655090e-01
    z[5,2,0]  R1691     -5.1589739322662354e-01
    z[5,2,0]  R1692     -3.5599014163017273e-01
    z[5,2,0]  R1693     -2.8960227966308594e-01
    z[5,2,0]  R1694     -5.7515543699264526e-01
    z[5,2,0]  R1695     -4.1426292061805725e-01
    z[5,2,0]  R1696     -3.2901623845100403e-01
    z[5,2,0]  R1697     0.443828284740448
    z[5,2,0]  R1698     0.596022367477417
    z[5,2,0]  R1699     5.8625990152359009e-01
    z[5,2,0]  R1700     4.5706677436828613e-01
    z[5,2,0]  R1701     2.2589190304279327e-01
    z[5,2,0]  R1702     3.8704875111579895e-01
    z[5,2,0]  R1703     3.0130943655967712e-01
    z[5,2,0]  R1704     5.8022117614746094e-01
    z[5,2,0]  R1705     0.547103226184845
    z[5,2,0]  R1706     -1.9522064924240112e-01
    z[5,2,0]  R1707     -5.9889388084411621e-01
    z[5,2,0]  R1708     -5.5948734283447266e-01
    z[5,2,0]  R1709     -7.2994542121887207e-01
    z[5,2,0]  R1710     -4.2817932367324829e-01
    z[5,2,0]  R1711     -7.4910598993301392e-01
    z[5,2,0]  R1712     -4.0614092350006104e-01
    z[5,2,0]  R1713     -5.9933245182037354e-01
    z[5,2,0]  R1714     -3.8821491599082947e-01
    z[5,2,0]  R1715     -2.6076626777648926e-01
    z[5,2,0]  R1716     -4.7347363829612732e-01
    z[5,2,0]  R1717     -1.8241828307509422e-02
    z[5,2,0]  R1718     3.5420483350753784e-01
    z[5,2,0]  R1719     -3.4724938869476318e-01
    z[5,2,0]  R1720     -0.0746384710073471
    z[5,2,0]  R1721     2.0175845921039581e-01
    z[5,2,0]  R1722     -1.2036658078432083e-01
    z[5,2,0]  R1723     -1.1681912094354630e-01
    z[5,2,0]  R1724     2.6472198963165283e-01
    z[5,2,0]  R1725     -6.0214199125766754e-02
    z[5,2,0]  R1726     -1.1675311252474785e-02
    z[5,2,0]  R1727     -3.9184695482254028e-01
    z[5,2,0]  R1728     -0.439421683549881
    z[5,2,0]  R1729     -0.185368150472641
    z[5,2,0]  R1730     -1.0790064185857773e-01
    z[5,2,0]  R1731     -5.3795784711837769e-01
    z[5,2,0]  R1732     -3.2538771629333496e-01
    z[5,2,0]  R1733     8.3735115826129913e-02
    z[5,2,0]  R1734     -4.8598015308380127e-01
    z[5,2,0]  R1735     -4.9811840057373047e-01
    z[5,2,0]  R1736     -0.307282954454422
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1660     -1
    z[5,2,1]  R1661     1
    z[5,2,1]  R1672     3.5130563378334045e-01
    z[5,2,1]  R1673     0.533920407295227
    z[5,2,1]  R1674     -2.9374182224273682e-01
    z[5,2,1]  R1675     -2.1514658629894257e-01
    z[5,2,1]  R1676     -8.2180780172348022e-01
    z[5,2,1]  R1677     5.8445432223379612e-03
    z[5,2,1]  R1678     1.4068324863910675e-01
    z[5,2,1]  R1679     7.3817779775708914e-04
    z[5,2,1]  R1680     1.3491672277450562e-01
    z[5,2,1]  R1681     -6.0320448130369186e-02
    z[5,2,1]  R1682     1.4563761651515961e-01
    z[5,2,1]  R1683     -1.0970515012741089e-01
    z[5,2,1]  R1684     -9.2762567102909088e-02
    z[5,2,1]  R1685     -1.0863159596920013e-01
    z[5,2,1]  R1686     -1.7153373360633850e-01
    z[5,2,1]  R1687     -0.0805494487285614
    z[5,2,1]  R1688     -9.0810102224349976e-01
    z[5,2,1]  R1689     -0.869015097618103
    z[5,2,1]  R1690     -8.6112791299819946e-01
    z[5,2,1]  R1691     -8.1934183835983276e-01
    z[5,2,1]  R1692     -8.2074803113937378e-01
    z[5,2,1]  R1693     -8.6880356073379517e-01
    z[5,2,1]  R1694     -0.808609127998352
    z[5,2,1]  R1695     -0.849862277507782
    z[5,2,1]  R1696     -8.1476384401321411e-01
    z[5,2,1]  R1697     2.3911124467849731e-01
    z[5,2,1]  R1698     1.0747678577899933e-01
    z[5,2,1]  R1699     9.9074125289916992e-02
    z[5,2,1]  R1700     2.6177468895912170e-01
    z[5,2,1]  R1701     2.9460325837135315e-01
    z[5,2,1]  R1702     3.5361862182617188e-01
    z[5,2,1]  R1703     3.4898763895034790e-01
    z[5,2,1]  R1704     4.8065102100372314e-01
    z[5,2,1]  R1705     2.5980255007743835e-01
    z[5,2,1]  R1706     -8.5558688640594482e-01
    z[5,2,1]  R1707     -8.5406258702278137e-02
    z[5,2,1]  R1708     -4.2828482389450073e-01
    z[5,2,1]  R1709     -4.5273122191429138e-01
    z[5,2,1]  R1710     -1.1212576180696487e-01
    z[5,2,1]  R1711     -3.8804542273283005e-03
    z[5,2,1]  R1712     -3.9136001467704773e-01
    z[5,2,1]  R1713     1.3638220727443695e-01
    z[5,2,1]  R1714     -8.1791423261165619e-02
    z[5,2,1]  R1715     -9.3317642807960510e-02
    z[5,2,1]  R1716     1.5056781470775604e-01
    z[5,2,1]  R1717     -5.1217317581176758e-01
    z[5,2,1]  R1718     -1.7223972082138062e-01
    z[5,2,1]  R1719     -2.8673630952835083e-01
    z[5,2,1]  R1720     -0.224474236369133
    z[5,2,1]  R1721     -9.3072272837162018e-02
    z[5,2,1]  R1722     -1.6432899236679077e-01
    z[5,2,1]  R1723     1.0145115852355957e-01
    z[5,2,1]  R1724     -2.4835982918739319e-01
    z[5,2,1]  R1725     -5.6369885802268982e-02
    z[5,2,1]  R1726     5.9535884857177734e-01
    z[5,2,1]  R1727     4.0345042943954468e-02
    z[5,2,1]  R1728     -4.2288365960121155e-01
    z[5,2,1]  R1729     -5.5005472898483276e-01
    z[5,2,1]  R1730     2.0386627316474915e-01
    z[5,2,1]  R1731     4.4791221618652344e-02
    z[5,2,1]  R1732     3.4200098365545273e-02
    z[5,2,1]  R1733     6.9640129804611206e-01
    z[5,2,1]  R1734     8.0537945032119751e-01
    z[5,2,1]  R1735     -2.2044022381305695e-01
    z[5,2,1]  R1736     8.9695996046066284e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1662     -1
    z[5,2,2]  R1663     1
    z[5,2,2]  R1672     7.0917874574661255e-01
    z[5,2,2]  R1673     2.5928530097007751e-01
    z[5,2,2]  R1674     3.1012037396430969e-01
    z[5,2,2]  R1675     -3.2536625862121582e-02
    z[5,2,2]  R1676     -3.9016953110694885e-01
    z[5,2,2]  R1677     -6.8645989894866943e-01
    z[5,2,2]  R1678     -4.4923231005668640e-01
    z[5,2,2]  R1679     -3.8668170571327209e-01
    z[5,2,2]  R1680     -5.1158332824707031e-01
    z[5,2,2]  R1681     -4.4767141342163086e-01
    z[5,2,2]  R1682     -4.2879101634025574e-01
    z[5,2,2]  R1683     -4.6130201220512390e-01
    z[5,2,2]  R1684     -5.1986885070800781e-01
    z[5,2,2]  R1685     -5.7390749454498291e-01
    z[5,2,2]  R1686     -3.1425091624259949e-01
    z[5,2,2]  R1687     1.3133190572261810e-02
    z[5,2,2]  R1688     5.4675798863172531e-02
    z[5,2,2]  R1689     1.2007483094930649e-01
    z[5,2,2]  R1690     7.4041627347469330e-02
    z[5,2,2]  R1691     8.9316859841346741e-02
    z[5,2,2]  R1692     0.255808025598526
    z[5,2,2]  R1693     2.0567758381366730e-01
    z[5,2,2]  R1694     2.1160072647035122e-03
    z[5,2,2]  R1695     -2.2815535962581635e-01
    z[5,2,2]  R1696     3.6205747723579407e-01
    z[5,2,2]  R1697     7.6214402914047241e-01
    z[5,2,2]  R1698     6.6670817136764526e-01
    z[5,2,2]  R1699     4.9157905578613281e-01
    z[5,2,2]  R1700     6.5431642532348633e-01
    z[5,2,2]  R1701     5.9676152467727661e-01
    z[5,2,2]  R1702     2.5834500789642334e-01
    z[5,2,2]  R1703     5.4126840829849243e-01
    z[5,2,2]  R1704     2.7784049510955811e-01
    z[5,2,2]  R1705     4.7331610321998596e-01
    z[5,2,2]  R1706     -2.9964751005172729e-01
    z[5,2,2]  R1707     -6.2315952777862549e-01
    z[5,2,2]  R1708     -4.5713719725608826e-01
    z[5,2,2]  R1709     -4.9130564928054810e-01
    z[5,2,2]  R1710     -5.4274529218673706e-01
    z[5,2,2]  R1711     -5.8590775728225708e-01
    z[5,2,2]  R1712     -6.0285305976867676e-01
    z[5,2,2]  R1713     -4.5472463965415955e-01
    z[5,2,2]  R1714     -4.4478836655616760e-01
    z[5,2,2]  R1715     -6.2860614061355591e-01
    z[5,2,2]  R1716     -4.3422549962997437e-01
    z[5,2,2]  R1717     -5.4368627071380615e-01
    z[5,2,2]  R1718     4.5820564031600952e-01
    z[5,2,2]  R1719     -2.3959949612617493e-01
    z[5,2,2]  R1720     -1.8490347266197205e-01
    z[5,2,2]  R1721     7.0345804095268250e-02
    z[5,2,2]  R1722     5.7068395614624023e-01
    z[5,2,2]  R1723     1.6660247743129730e-01
    z[5,2,2]  R1724     -4.9605220556259155e-02
    z[5,2,2]  R1725     1.3281117379665375e-01
    z[5,2,2]  R1726     1.6671356558799744e-01
    z[5,2,2]  R1727     -7.1254062652587891e-01
    z[5,2,2]  R1728     -4.4756001234054565e-01
    z[5,2,2]  R1729     -6.0772401094436646e-01
    z[5,2,2]  R1730     3.6574136465787888e-02
    z[5,2,2]  R1731     1.7348611354827881e-01
    z[5,2,2]  R1732     -3.8892120122909546e-02
    z[5,2,2]  R1733     8.6048319935798645e-02
    z[5,2,2]  R1734     5.2002891898155212e-02
    z[5,2,2]  R1735     2.6664009690284729e-01
    z[5,2,2]  R1736     -8.1974111497402191e-02
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1664     -1
    z[5,2,3]  R1665     1
    z[5,2,3]  R1672     1.1797262728214264e-01
    z[5,2,3]  R1673     -1.8861134350299835e-01
    z[5,2,3]  R1674     -3.9001864194869995e-01
    z[5,2,3]  R1675     -1.2386147864162922e-02
    z[5,2,3]  R1676     9.1523475944995880e-02
    z[5,2,3]  R1677     -4.4778978824615479e-01
    z[5,2,3]  R1678     -2.2499673068523407e-01
    z[5,2,3]  R1679     -3.6721962690353394e-01
    z[5,2,3]  R1680     -3.1424438953399658e-01
    z[5,2,3]  R1681     -2.8693222999572754e-01
    z[5,2,3]  R1682     -2.1840566396713257e-01
    z[5,2,3]  R1683     -4.9941259622573853e-01
    z[5,2,3]  R1684     -1.5288800001144409e-01
    z[5,2,3]  R1685     -1.9498866796493530e-01
    z[5,2,3]  R1686     -6.9235080480575562e-01
    z[5,2,3]  R1687     3.9728403091430664e-01
    z[5,2,3]  R1688     1.4180057682096958e-02
    z[5,2,3]  R1689     2.6352667808532715e-01
    z[5,2,3]  R1690     1.4667358994483948e-01
    z[5,2,3]  R1691     -9.8329484462738037e-02
    z[5,2,3]  R1692     3.1888020038604736e-01
    z[5,2,3]  R1693     -9.0936720371246338e-02
    z[5,2,3]  R1694     -1.0214445739984512e-01
    z[5,2,3]  R1695     -7.7040627598762512e-02
    z[5,2,3]  R1696     -0.0776321142911911
    z[5,2,3]  R1697     -1.3017807900905609e-01
    z[5,2,3]  R1698     -4.1541284322738647e-01
    z[5,2,3]  R1699     -5.3775084018707275e-01
    z[5,2,3]  R1700     -2.1474617719650269e-01
    z[5,2,3]  R1701     -6.2661296129226685e-01
    z[5,2,3]  R1702     -7.4903172254562378e-01
    z[5,2,3]  R1703     -6.2439376115798950e-01
    z[5,2,3]  R1704     -5.8437591791152954e-01
    z[5,2,3]  R1705     -1.6673199832439423e-01
    z[5,2,3]  R1706     -1.1684054881334305e-01
    z[5,2,3]  R1707     -1.6926182806491852e-01
    z[5,2,3]  R1708     3.2364353537559509e-01
    z[5,2,3]  R1709     -1.0207553952932358e-01
    z[5,2,3]  R1710     4.0911316871643066e-01
    z[5,2,3]  R1711     1.8863391876220703e-01
    z[5,2,3]  R1712     2.4182501435279846e-01
    z[5,2,3]  R1713     3.3136495947837830e-01
    z[5,2,3]  R1714     4.2438396811485291e-01
    z[5,2,3]  R1715     1.3828664086759090e-02
    z[5,2,3]  R1716     1.9436357915401459e-01
    z[5,2,3]  R1717     -1.8136920034885406e-01
    z[5,2,3]  R1718     7.9428905248641968e-01
    z[5,2,3]  R1719     -2.1760773658752441e-01
    z[5,2,3]  R1720     -1.7980632185935974e-01
    z[5,2,3]  R1721     8.1366300582885742e-01
    z[5,2,3]  R1722     5.4640734195709229e-01
    z[5,2,3]  R1723     4.6961575746536255e-01
    z[5,2,3]  R1724     4.2552584409713745e-01
    z[5,2,3]  R1725     3.7509584426879883e-01
    z[5,2,3]  R1726     6.2250560522079468e-01
    z[5,2,3]  R1727     -6.3955806195735931e-02
    z[5,2,3]  R1728     -1.2864026427268982e-01
    z[5,2,3]  R1729     -3.7321120500564575e-01
    z[5,2,3]  R1730     7.0065855979919434e-01
    z[5,2,3]  R1731     6.0737454891204834e-01
    z[5,2,3]  R1732     4.0486183762550354e-01
    z[5,2,3]  R1733     0.525330126285553
    z[5,2,3]  R1734     1.1478332430124283e-01
    z[5,2,3]  R1735     4.6427825093269348e-01
    z[5,2,3]  R1736     1.0086484998464584e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1666     -1
    z[5,2,4]  R1667     1
    z[5,2,4]  R1672     2.4496251344680786e-01
    z[5,2,4]  R1673     -6.2972551584243774e-01
    z[5,2,4]  R1674     0.0307974424213171
    z[5,2,4]  R1675     -4.2809373140335083e-01
    z[5,2,4]  R1676     -1.5423774719238281e-01
    z[5,2,4]  R1677     2.0271413028240204e-01
    z[5,2,4]  R1678     2.6255783438682556e-01
    z[5,2,4]  R1679     4.0326413512229919e-01
    z[5,2,4]  R1680     1.6242672502994537e-01
    z[5,2,4]  R1681     -2.8086664155125618e-02
    z[5,2,4]  R1682     3.9591252803802490e-01
    z[5,2,4]  R1683     1.4629776775836945e-01
    z[5,2,4]  R1684     1.8903563916683197e-01
    z[5,2,4]  R1685     1.3146454095840454e-01
    z[5,2,4]  R1686     -1.2828269600868225e-01
    z[5,2,4]  R1687     -3.3598041534423828e-01
    z[5,2,4]  R1688     1.7064245045185089e-01
    z[5,2,4]  R1689     1.7576907575130463e-01
    z[5,2,4]  R1690     -9.3462634831666946e-03
    z[5,2,4]  R1691     6.0886070132255554e-02
    z[5,2,4]  R1692     1.1964366585016251e-01
    z[5,2,4]  R1693     1.8079565837979317e-02
    z[5,2,4]  R1694     -5.3978666663169861e-02
    z[5,2,4]  R1695     -1.0950735211372375e-01
    z[5,2,4]  R1696     -1.6522422432899475e-01
    z[5,2,4]  R1697     -0.0178383756428957
    z[5,2,4]  R1698     -4.6718839555978775e-02
    z[5,2,4]  R1699     -6.0257494449615479e-02
    z[5,2,4]  R1700     -4.5382639765739441e-01
    z[5,2,4]  R1701     -2.5469473004341125e-01
    z[5,2,4]  R1702     -1.0551095008850098e-01
    z[5,2,4]  R1703     2.9713329672813416e-01
    z[5,2,4]  R1704     3.7180770188570023e-02
    z[5,2,4]  R1705     4.0392377972602844e-01
    z[5,2,4]  R1706     2.4103714525699615e-01
    z[5,2,4]  R1707     -2.5213941931724548e-01
    z[5,2,4]  R1708     -2.4225538969039917e-01
    z[5,2,4]  R1709     -9.1686114668846130e-02
    z[5,2,4]  R1710     -1.3998466730117798e-01
    z[5,2,4]  R1711     9.2688970267772675e-02
    z[5,2,4]  R1712     5.2372928708791733e-02
    z[5,2,4]  R1713     -1.0429803282022476e-01
    z[5,2,4]  R1714     -1.0389237850904465e-01
    z[5,2,4]  R1715     1.7746625840663910e-01
    z[5,2,4]  R1716     -4.4248613715171814e-01
    z[5,2,4]  R1717     -1.3213990628719330e-01
    z[5,2,4]  R1718     -5.9071164578199387e-02
    z[5,2,4]  R1719     -4.3168950080871582e-01
    z[5,2,4]  R1720     -7.5712114572525024e-01
    z[5,2,4]  R1721     1.1694841831922531e-01
    z[5,2,4]  R1722     -9.3024484813213348e-02
    z[5,2,4]  R1723     -6.8430745601654053e-01
    z[5,2,4]  R1724     -6.5788125991821289e-01
    z[5,2,4]  R1725     -6.9979226589202881e-01
    z[5,2,4]  R1726     -3.6981284618377686e-01
    z[5,2,4]  R1727     1.1258546262979507e-01
    z[5,2,4]  R1728     -3.7390846014022827e-01
    z[5,2,4]  R1729     3.3302713185548782e-02
    z[5,2,4]  R1730     -1.9245386123657227e-01
    z[5,2,4]  R1731     -2.9392004013061523e-01
    z[5,2,4]  R1732     -7.5283324718475342e-01
    z[5,2,4]  R1733     -7.0575617253780365e-02
    z[5,2,4]  R1734     1.0091464221477509e-01
    z[5,2,4]  R1735     9.7659686580300331e-03
    z[5,2,4]  R1736     1.2039819359779358e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1668     -1
    z[5,2,5]  R1669     1
    z[5,2,5]  R1672     -3.9929196238517761e-01
    z[5,2,5]  R1673     -2.4968470633029938e-01
    z[5,2,5]  R1674     -5.5485677719116211e-01
    z[5,2,5]  R1675     -4.7112739086151123e-01
    z[5,2,5]  R1676     3.3411204814910889e-01
    z[5,2,5]  R1677     2.5637684389948845e-02
    z[5,2,5]  R1678     -2.4374802410602570e-01
    z[5,2,5]  R1679     1.5165130794048309e-01
    z[5,2,5]  R1680     -1.5895521640777588e-01
    z[5,2,5]  R1681     1.6387178003787994e-01
    z[5,2,5]  R1682     -3.0993044376373291e-02
    z[5,2,5]  R1683     -2.2050505876541138e-01
    z[5,2,5]  R1684     3.0824041366577148e-01
    z[5,2,5]  R1685     1.1866968125104904e-01
    z[5,2,5]  R1686     -1.0495049506425858e-01
    z[5,2,5]  R1687     5.2054870128631592e-01
    z[5,2,5]  R1688     0.147319495677948
    z[5,2,5]  R1689     2.0072488114237785e-02
    z[5,2,5]  R1690     1.0734124481678009e-01
    z[5,2,5]  R1691     1.9797259569168091e-01
    z[5,2,5]  R1692     7.8324370086193085e-02
    z[5,2,5]  R1693     2.6179236173629761e-01
    z[5,2,5]  R1694     -1.7094336450099945e-02
    z[5,2,5]  R1695     1.8547664582729340e-01
    z[5,2,5]  R1696     2.2930899262428284e-01
    z[5,2,5]  R1697     3.8339686393737793e-01
    z[5,2,5]  R1698     7.4416443705558777e-02
    z[5,2,5]  R1699     2.6872122287750244e-01
    z[5,2,5]  R1700     1.9816392660140991e-01
    z[5,2,5]  R1701     2.1644225716590881e-01
    z[5,2,5]  R1702     2.7994787693023682e-01
    z[5,2,5]  R1703     1.2733405828475952e-01
    z[5,2,5]  R1704     -1.0238508880138397e-01
    z[5,2,5]  R1705     3.4010317921638489e-01
    z[5,2,5]  R1706     -3.9974547922611237e-02
    z[5,2,5]  R1707     -3.6941388249397278e-01
    z[5,2,5]  R1708     -3.4650653600692749e-01
    z[5,2,5]  R1709     -4.4726513326168060e-02
    z[5,2,5]  R1710     -0.519870400428772
    z[5,2,5]  R1711     -1.6513921320438385e-01
    z[5,2,5]  R1712     -3.3169832825660706e-01
    z[5,2,5]  R1713     -4.7022223472595215e-01
    z[5,2,5]  R1714     -6.1688584089279175e-01
    z[5,2,5]  R1715     -6.2938481569290161e-01
    z[5,2,5]  R1716     -5.7471239566802979e-01
    z[5,2,5]  R1717     -6.2409126758575439e-01
    z[5,2,5]  R1718     -1.6205992549657822e-02
    z[5,2,5]  R1719     -4.0821567177772522e-01
    z[5,2,5]  R1720     -5.4451203346252441e-01
    z[5,2,5]  R1721     -1.0340183973312378e-01
    z[5,2,5]  R1722     5.6958663463592529e-01
    z[5,2,5]  R1723     4.1589897871017456e-01
    z[5,2,5]  R1724     3.1338497996330261e-01
    z[5,2,5]  R1725     3.9741155505180359e-01
    z[5,2,5]  R1726     -2.8564637899398804e-01
    z[5,2,5]  R1727     -5.6243741512298584e-01
    z[5,2,5]  R1728     -4.5603013038635254e-01
    z[5,2,5]  R1729     -3.9154800772666931e-01
    z[5,2,5]  R1730     -4.0158487856388092e-02
    z[5,2,5]  R1731     3.2321658730506897e-01
    z[5,2,5]  R1732     3.2331734895706177e-01
    z[5,2,5]  R1733     -4.0162622928619385e-01
    z[5,2,5]  R1734     2.4523507058620453e-01
    z[5,2,5]  R1735     3.1295937299728394e-01
    z[5,2,5]  R1736     1.1620508134365082e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1670     -1
    z[5,2,6]  R1671     1
    z[5,2,6]  R1672     -2.2172866761684418e-01
    z[5,2,6]  R1673     3.5137692093849182e-01
    z[5,2,6]  R1674     -1.8017850816249847e-01
    z[5,2,6]  R1675     5.5753654241561890e-01
    z[5,2,6]  R1676     -1.5387046337127686e-01
    z[5,2,6]  R1677     1.4287789165973663e-01
    z[5,2,6]  R1678     3.4167438279837370e-03
    z[5,2,6]  R1679     -4.4392615556716919e-02
    z[5,2,6]  R1680     3.1140625476837158e-01
    z[5,2,6]  R1681     1.1510109901428223e-01
    z[5,2,6]  R1682     -2.3166318237781525e-01
    z[5,2,6]  R1683     -8.5646532475948334e-02
    z[5,2,6]  R1684     -2.2045131027698517e-01
    z[5,2,6]  R1685     -3.9121967554092407e-01
    z[5,2,6]  R1686     2.5514401495456696e-02
    z[5,2,6]  R1687     -4.3780177831649780e-01
    z[5,2,6]  R1688     -1.5390457212924957e-01
    z[5,2,6]  R1689     1.3502325117588043e-01
    z[5,2,6]  R1690     -9.4142660498619080e-02
    z[5,2,6]  R1691     4.4523306190967560e-02
    z[5,2,6]  R1692     -1.0987244546413422e-01
    z[5,2,6]  R1693     2.0463684201240540e-01
    z[5,2,6]  R1694     4.1273102164268494e-02
    z[5,2,6]  R1695     -4.1673827916383743e-02
    z[5,2,6]  R1696     1.0447089374065399e-01
    z[5,2,6]  R1697     2.6852054521441460e-02
    z[5,2,6]  R1698     -9.1749869287014008e-02
    z[5,2,6]  R1699     1.9953864812850952e-01
    z[5,2,6]  R1700     -5.5594801902770996e-02
    z[5,2,6]  R1701     4.1194528341293335e-02
    z[5,2,6]  R1702     -8.8617682456970215e-02
    z[5,2,6]  R1703     8.8885044679045677e-03
    z[5,2,6]  R1704     -4.1980691254138947e-02
    z[5,2,6]  R1705     3.2020047307014465e-01
    z[5,2,6]  R1706     2.5830745697021484e-01
    z[5,2,6]  R1707     -1.3043585419654846e-01
    z[5,2,6]  R1708     -1.0522356629371643e-01
    z[5,2,6]  R1709     -2.6178336702287197e-03
    z[5,2,6]  R1710     -2.2865532338619232e-01
    z[5,2,6]  R1711     -1.5521687269210815e-01
    z[5,2,6]  R1712     -3.8367825746536255e-01
    z[5,2,6]  R1713     2.7135983109474182e-01
    z[5,2,6]  R1714     2.7077487111091614e-01
    z[5,2,6]  R1715     3.1675910949707031e-01
    z[5,2,6]  R1716     2.7105422690510750e-02
    z[5,2,6]  R1717     4.3651174753904343e-02
    z[5,2,6]  R1718     1.6516314819455147e-02
    z[5,2,6]  R1719     5.8261758089065552e-01
    z[5,2,6]  R1720     0.0882897898554802
    z[5,2,6]  R1721     -5.0918185710906982e-01
    z[5,2,6]  R1722     -3.4413103014230728e-02
    z[5,2,6]  R1723     -2.9413762688636780e-01
    z[5,2,6]  R1724     3.9203155040740967e-01
    z[5,2,6]  R1725     4.3268457055091858e-01
    z[5,2,6]  R1726     -1.0839474201202393e-01
    z[5,2,6]  R1727     6.3343368470668793e-02
    z[5,2,6]  R1728     0.25189009308815
    z[5,2,6]  R1729     6.6726314835250378e-03
    z[5,2,6]  R1730     -6.4489126205444336e-01
    z[5,2,6]  R1731     -3.4458079934120178e-01
    z[5,2,6]  R1732     2.3714034259319305e-01
    z[5,2,6]  R1733     2.4156366288661957e-01
    z[5,2,6]  R1734     1.7024591565132141e-01
    z[5,2,6]  R1735     5.6444126367568970e-01
    z[5,2,6]  R1736     -2.3695375025272369e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1737     -1
    z[2,6,0]  R1738     1
    z[2,6,0]  R1751     0.443828284740448
    z[2,6,0]  R1752     0.596022367477417
    z[2,6,0]  R1753     5.8625990152359009e-01
    z[2,6,0]  R1754     4.5706677436828613e-01
    z[2,6,0]  R1755     2.2589190304279327e-01
    z[2,6,0]  R1756     3.8704875111579895e-01
    z[2,6,0]  R1757     3.0130943655967712e-01
    z[2,6,0]  R1758     5.8022117614746094e-01
    z[2,6,0]  R1759     0.547103226184845
    z[2,6,0]  R1760     -1.9522064924240112e-01
    z[2,6,0]  R1761     -5.9889388084411621e-01
    z[2,6,0]  R1762     -5.5948734283447266e-01
    z[2,6,0]  R1763     -7.2994542121887207e-01
    z[2,6,0]  R1764     -4.2817932367324829e-01
    z[2,6,0]  R1765     -7.4910598993301392e-01
    z[2,6,0]  R1766     -4.0614092350006104e-01
    z[2,6,0]  R1767     -5.9933245182037354e-01
    z[2,6,0]  R1768     -3.8821491599082947e-01
    z[2,6,0]  R1769     -2.6076626777648926e-01
    z[2,6,0]  R1770     -4.7347363829612732e-01
    z[2,6,0]  R1771     -1.8241828307509422e-02
    z[2,6,0]  R1772     3.5420483350753784e-01
    z[2,6,0]  R1773     -3.4724938869476318e-01
    z[2,6,0]  R1774     -0.0746384710073471
    z[2,6,0]  R1775     2.0175845921039581e-01
    z[2,6,0]  R1776     -1.2036658078432083e-01
    z[2,6,0]  R1777     -1.1681912094354630e-01
    z[2,6,0]  R1778     2.6472198963165283e-01
    z[2,6,0]  R1779     -6.0214199125766754e-02
    z[2,6,0]  R1780     -1.1675311252474785e-02
    z[2,6,0]  R1781     -3.9184695482254028e-01
    z[2,6,0]  R1782     -0.439421683549881
    z[2,6,0]  R1783     -0.185368150472641
    z[2,6,0]  R1784     -1.0790064185857773e-01
    z[2,6,0]  R1785     -5.3795784711837769e-01
    z[2,6,0]  R1786     -3.2538771629333496e-01
    z[2,6,0]  R1787     8.3735115826129913e-02
    z[2,6,0]  R1788     -4.8598015308380127e-01
    z[2,6,0]  R1789     -4.9811840057373047e-01
    z[2,6,0]  R1790     -0.307282954454422
    z[2,6,0]  R1791     0.709740936756134
    z[2,6,0]  R1792     3.6230233311653137e-01
    z[2,6,0]  R1793     0.629054069519043
    z[2,6,0]  R1794     0.233524888753891
    z[2,6,0]  R1795     4.6908289194107056e-01
    z[2,6,0]  R1796     2.6015964150428772e-01
    z[2,6,0]  R1797     4.1445079445838928e-01
    z[2,6,0]  R1798     5.7593095302581787e-01
    z[2,6,0]  R1799     1.5702585875988007e-01
    z[2,6,0]  R1800     5.3924626111984253e-01
    z[2,6,0]  R1801     -5.3836303949356079e-01
    z[2,6,0]  R1802     -4.3145808577537537e-01
    z[2,6,0]  R1803     -4.1351196169853210e-01
    z[2,6,0]  R1804     -7.4025779962539673e-01
    z[2,6,0]  R1805     -5.5635732412338257e-01
    z[2,6,0]  R1806     -4.5257467031478882e-01
    z[2,6,0]  R1807     -2.9112818837165833e-01
    z[2,6,0]  R1808     -2.8168797492980957e-01
    z[2,6,0]  R1809     -3.7196445465087891e-01
    z[2,6,0]  R1810     -6.0151129961013794e-01
    z[2,6,0]  R1811     -3.1354081630706787e-01
    z[2,6,0]  R1812     7.1117728948593140e-01
    z[2,6,0]  R1813     -6.5981775522232056e-01
    z[2,6,0]  R1814     -4.5274645090103149e-01
    z[2,6,0]  R1815     -1.5458774566650391e-01
    z[2,6,0]  R1816     -8.7819606065750122e-02
    z[2,6,0]  R1817     -3.6092811822891235e-01
    z[2,6,0]  R1818     -1.5699428319931030e-01
    z[2,6,0]  R1819     -1.6911458969116211e-01
    z[2,6,0]  R1820     -6.2999892234802246e-01
    z[2,6,0]  R1821     4.3794098496437073e-01
    z[2,6,0]  R1822     -1.1244311928749084e-01
    z[2,6,0]  R1823     -5.8221215009689331e-01
    z[2,6,0]  R1824     -6.3366800546646118e-01
    z[2,6,0]  R1825     1.2343308329582214e-01
    z[2,6,0]  R1826     -9.1407202184200287e-02
    z[2,6,0]  R1827     -7.1424573659896851e-01
    z[2,6,0]  R1828     -3.5588359832763672e-01
    z[2,6,0]  R1829     -1.1344072222709656e-01
    z[2,6,0]  R1830     3.8538837432861328e-01
    z[2,6,0]  R1831     -3.4258842468261719e-01
    z[2,6,0]  R1832     1.2562611699104309e-01
    z[2,6,0]  R1833     -6.0157239437103271e-02
    z[2,6,0]  R1834     -4.8489010334014893e-01
    z[2,6,0]  R1835     7.7022269368171692e-02
    z[2,6,0]  R1836     2.5774019956588745e-01
    z[2,6,0]  R1837     -7.8487378358840942e-01
    z[2,6,0]  R1838     -0.67607581615448
    z[2,6,0]  R1839     4.0135046839714050e-01
    z[2,6,0]  R1840     -5.2852904796600342e-01
    z[2,6,0]  R1841     -1.6651949286460876e-01
    z[2,6,0]  R1842     2.0789556205272675e-01
    z[2,6,0]  R1843     3.9218395948410034e-01
    z[2,6,0]  R1844     -6.7370146512985229e-01
    z[2,6,0]  R1845     -5.1515656709671021e-01
    z[2,6,0]  R1846     2.0023368299007416e-02
    z[2,6,0]  R1847     -8.0589786171913147e-02
    z[2,6,0]  R1848     -1.6670224070549011e-01
    z[2,6,0]  R1849     -3.6944296956062317e-01
    z[2,6,0]  R1850     -4.0090450644493103e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1739     -1
    z[2,6,1]  R1740     1
    z[2,6,1]  R1751     2.3911124467849731e-01
    z[2,6,1]  R1752     1.0747678577899933e-01
    z[2,6,1]  R1753     9.9074125289916992e-02
    z[2,6,1]  R1754     2.6177468895912170e-01
    z[2,6,1]  R1755     2.9460325837135315e-01
    z[2,6,1]  R1756     3.5361862182617188e-01
    z[2,6,1]  R1757     3.4898763895034790e-01
    z[2,6,1]  R1758     4.8065102100372314e-01
    z[2,6,1]  R1759     2.5980255007743835e-01
    z[2,6,1]  R1760     -8.5558688640594482e-01
    z[2,6,1]  R1761     -8.5406258702278137e-02
    z[2,6,1]  R1762     -4.2828482389450073e-01
    z[2,6,1]  R1763     -4.5273122191429138e-01
    z[2,6,1]  R1764     -1.1212576180696487e-01
    z[2,6,1]  R1765     -3.8804542273283005e-03
    z[2,6,1]  R1766     -3.9136001467704773e-01
    z[2,6,1]  R1767     1.3638220727443695e-01
    z[2,6,1]  R1768     -8.1791423261165619e-02
    z[2,6,1]  R1769     -9.3317642807960510e-02
    z[2,6,1]  R1770     1.5056781470775604e-01
    z[2,6,1]  R1771     -5.1217317581176758e-01
    z[2,6,1]  R1772     -1.7223972082138062e-01
    z[2,6,1]  R1773     -2.8673630952835083e-01
    z[2,6,1]  R1774     -0.224474236369133
    z[2,6,1]  R1775     -9.3072272837162018e-02
    z[2,6,1]  R1776     -1.6432899236679077e-01
    z[2,6,1]  R1777     1.0145115852355957e-01
    z[2,6,1]  R1778     -2.4835982918739319e-01
    z[2,6,1]  R1779     -5.6369885802268982e-02
    z[2,6,1]  R1780     5.9535884857177734e-01
    z[2,6,1]  R1781     4.0345042943954468e-02
    z[2,6,1]  R1782     -4.2288365960121155e-01
    z[2,6,1]  R1783     -5.5005472898483276e-01
    z[2,6,1]  R1784     2.0386627316474915e-01
    z[2,6,1]  R1785     4.4791221618652344e-02
    z[2,6,1]  R1786     3.4200098365545273e-02
    z[2,6,1]  R1787     6.9640129804611206e-01
    z[2,6,1]  R1788     8.0537945032119751e-01
    z[2,6,1]  R1789     -2.2044022381305695e-01
    z[2,6,1]  R1790     8.9695996046066284e-01
    z[2,6,1]  R1791     2.4190494418144226e-01
    z[2,6,1]  R1792     2.8154906630516052e-01
    z[2,6,1]  R1793     7.3732741177082062e-02
    z[2,6,1]  R1794     0.405757337808609
    z[2,6,1]  R1795     0.4198018014431
    z[2,6,1]  R1796     3.2296755909919739e-01
    z[2,6,1]  R1797     3.5791835188865662e-01
    z[2,6,1]  R1798     0.0816793143749237
    z[2,6,1]  R1799     2.1950738131999969e-01
    z[2,6,1]  R1800     5.2721697092056274e-01
    z[2,6,1]  R1801     -4.2514353990554810e-01
    z[2,6,1]  R1802     -3.7765043973922729e-01
    z[2,6,1]  R1803     -1.2175317108631134e-01
    z[2,6,1]  R1804     -1.5905758738517761e-01
    z[2,6,1]  R1805     -1.3026267290115356e-01
    z[2,6,1]  R1806     -0.288029283285141
    z[2,6,1]  R1807     -1.9473029673099518e-01
    z[2,6,1]  R1808     -2.6331162452697754e-01
    z[2,6,1]  R1809     -3.5283035039901733e-01
    z[2,6,1]  R1810     0.0972060039639473
    z[2,6,1]  R1811     3.4821841120719910e-01
    z[2,6,1]  R1812     1.6479054465889931e-02
    z[2,6,1]  R1813     -3.2278180122375488e-01
    z[2,6,1]  R1814     -2.9606339335441589e-01
    z[2,6,1]  R1815     -9.5858675241470337e-01
    z[2,6,1]  R1816     -9.7568619251251221e-01
    z[2,6,1]  R1817     -9.0082573890686035e-01
    z[2,6,1]  R1818     -9.6243840456008911e-01
    z[2,6,1]  R1819     -9.3594169616699219e-01
    z[2,6,1]  R1820     1.6161382198333740e-01
    z[2,6,1]  R1821     3.0210077762603760e-01
    z[2,6,1]  R1822     -2.1115374565124512e-01
    z[2,6,1]  R1823     -0.127500519156456
    z[2,6,1]  R1824     -2.0129573345184326e-01
    z[2,6,1]  R1825     -3.6651373375207186e-03
    z[2,6,1]  R1826     2.8281578421592712e-01
    z[2,6,1]  R1827     -0.115801140666008
    z[2,6,1]  R1828     -1.4698682725429535e-01
    z[2,6,1]  R1829     -9.1631585359573364e-01
    z[2,6,1]  R1830     -1.0541752912104130e-02
    z[2,6,1]  R1831     -9.8470970988273621e-03
    z[2,6,1]  R1832     -3.9768457412719727e-01
    z[2,6,1]  R1833     5.9079676866531372e-01
    z[2,6,1]  R1834     -5.5885225534439087e-01
    z[2,6,1]  R1835     3.4029465913772583e-01
    z[2,6,1]  R1836     4.1088182479143143e-02
    z[2,6,1]  R1837     -3.9760297536849976e-01
    z[2,6,1]  R1838     1.5373589098453522e-01
    z[2,6,1]  R1839     4.3040168285369873e-01
    z[2,6,1]  R1840     8.7787836790084839e-02
    z[2,6,1]  R1841     -1.6055350005626678e-01
    z[2,6,1]  R1842     6.0036581754684448e-01
    z[2,6,1]  R1843     4.1186764836311340e-01
    z[2,6,1]  R1844     -4.7440952062606812e-01
    z[2,6,1]  R1845     2.8013916686177254e-02
    z[2,6,1]  R1846     -6.3481992483139038e-01
    z[2,6,1]  R1847     1.7278394103050232e-01
    z[2,6,1]  R1848     -9.3897312879562378e-01
    z[2,6,1]  R1849     -8.7880575656890869e-01
    z[2,6,1]  R1850     -4.9423524737358093e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1741     -1
    z[2,6,2]  R1742     1
    z[2,6,2]  R1751     7.6214402914047241e-01
    z[2,6,2]  R1752     6.6670817136764526e-01
    z[2,6,2]  R1753     4.9157905578613281e-01
    z[2,6,2]  R1754     6.5431642532348633e-01
    z[2,6,2]  R1755     5.9676152467727661e-01
    z[2,6,2]  R1756     2.5834500789642334e-01
    z[2,6,2]  R1757     5.4126840829849243e-01
    z[2,6,2]  R1758     2.7784049510955811e-01
    z[2,6,2]  R1759     4.7331610321998596e-01
    z[2,6,2]  R1760     -2.9964751005172729e-01
    z[2,6,2]  R1761     -6.2315952777862549e-01
    z[2,6,2]  R1762     -4.5713719725608826e-01
    z[2,6,2]  R1763     -4.9130564928054810e-01
    z[2,6,2]  R1764     -5.4274529218673706e-01
    z[2,6,2]  R1765     -5.8590775728225708e-01
    z[2,6,2]  R1766     -6.0285305976867676e-01
    z[2,6,2]  R1767     -4.5472463965415955e-01
    z[2,6,2]  R1768     -4.4478836655616760e-01
    z[2,6,2]  R1769     -6.2860614061355591e-01
    z[2,6,2]  R1770     -4.3422549962997437e-01
    z[2,6,2]  R1771     -5.4368627071380615e-01
    z[2,6,2]  R1772     4.5820564031600952e-01
    z[2,6,2]  R1773     -2.3959949612617493e-01
    z[2,6,2]  R1774     -1.8490347266197205e-01
    z[2,6,2]  R1775     7.0345804095268250e-02
    z[2,6,2]  R1776     5.7068395614624023e-01
    z[2,6,2]  R1777     1.6660247743129730e-01
    z[2,6,2]  R1778     -4.9605220556259155e-02
    z[2,6,2]  R1779     1.3281117379665375e-01
    z[2,6,2]  R1780     1.6671356558799744e-01
    z[2,6,2]  R1781     -7.1254062652587891e-01
    z[2,6,2]  R1782     -4.4756001234054565e-01
    z[2,6,2]  R1783     -6.0772401094436646e-01
    z[2,6,2]  R1784     3.6574136465787888e-02
    z[2,6,2]  R1785     1.7348611354827881e-01
    z[2,6,2]  R1786     -3.8892120122909546e-02
    z[2,6,2]  R1787     8.6048319935798645e-02
    z[2,6,2]  R1788     5.2002891898155212e-02
    z[2,6,2]  R1789     2.6664009690284729e-01
    z[2,6,2]  R1790     -8.1974111497402191e-02
    z[2,6,2]  R1791     5.6336796283721924e-01
    z[2,6,2]  R1792     6.7519217729568481e-01
    z[2,6,2]  R1793     6.1206829547882080e-01
    z[2,6,2]  R1794     6.4096099138259888e-01
    z[2,6,2]  R1795     3.1652599573135376e-01
    z[2,6,2]  R1796     1.7577858269214630e-01
    z[2,6,2]  R1797     4.0142270922660828e-01
    z[2,6,2]  R1798     3.3581075072288513e-01
    z[2,6,2]  R1799     6.5711104869842529e-01
    z[2,6,2]  R1800     4.9704349040985107e-01
    z[2,6,2]  R1801     -5.7997167110443115e-01
    z[2,6,2]  R1802     -7.0147556066513062e-01
    z[2,6,2]  R1803     -8.3670020103454590e-01
    z[2,6,2]  R1804     -5.4131674766540527e-01
    z[2,6,2]  R1805     -5.9926450252532959e-01
    z[2,6,2]  R1806     -5.8745086193084717e-01
    z[2,6,2]  R1807     -7.3352301120758057e-01
    z[2,6,2]  R1808     -7.4747115373611450e-01
    z[2,6,2]  R1809     -5.9564578533172607e-01
    z[2,6,2]  R1810     -6.4919906854629517e-01
    z[2,6,2]  R1811     -2.6262274384498596e-01
    z[2,6,2]  R1812     -2.6430574059486389e-01
    z[2,6,2]  R1813     -4.1024681925773621e-01
    z[2,6,2]  R1814     -4.2218139767646790e-01
    z[2,6,2]  R1815     -4.4179830700159073e-02
    z[2,6,2]  R1816     1.2788753211498260e-01
    z[2,6,2]  R1817     5.6832566857337952e-02
    z[2,6,2]  R1818     2.1435181796550751e-01
    z[2,6,2]  R1819     0.0388757586479187
    z[2,6,2]  R1820     -0.364346981048584
    z[2,6,2]  R1821     -4.4366419315338135e-01
    z[2,6,2]  R1822     -3.7094447761774063e-02
    z[2,6,2]  R1823     -7.5271910429000854e-01
    z[2,6,2]  R1824     -6.3303023576736450e-01
    z[2,6,2]  R1825     -4.2210537195205688e-01
    z[2,6,2]  R1826     -2.1372132003307343e-01
    z[2,6,2]  R1827     -2.2710137069225311e-01
    z[2,6,2]  R1828     -4.7464501857757568e-01
    z[2,6,2]  R1829     -2.9173898696899414e-01
    z[2,6,2]  R1830     -3.8445648550987244e-01
    z[2,6,2]  R1831     -1.0208919644355774e-01
    z[2,6,2]  R1832     -2.8553920984268188e-01
    z[2,6,2]  R1833     -5.2424877882003784e-01
    z[2,6,2]  R1834     -2.2722736001014709e-01
    z[2,6,2]  R1835     -5.4143589735031128e-01
    z[2,6,2]  R1836     -1.4111521840095520e-01
    z[2,6,2]  R1837     -2.6037901639938354e-01
    z[2,6,2]  R1838     -5.5918926000595093e-01
    z[2,6,2]  R1839     -2.7532979846000671e-01
    z[2,6,2]  R1840     -3.9835530519485474e-01
    z[2,6,2]  R1841     -2.0550100505352020e-01
    z[2,6,2]  R1842     -1.8229983747005463e-01
    z[2,6,2]  R1843     -6.6258095204830170e-02
    z[2,6,2]  R1844     -4.8902264237403870e-01
    z[2,6,2]  R1845     -6.3858497142791748e-01
    z[2,6,2]  R1846     5.9425350278615952e-02
    z[2,6,2]  R1847     0.63775634765625
    z[2,6,2]  R1848     -1.0608106106519699e-01
    z[2,6,2]  R1849     2.5521349161863327e-02
    z[2,6,2]  R1850     -4.1280549019575119e-02
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1743     -1
    z[2,6,3]  R1744     1
    z[2,6,3]  R1751     -1.3017807900905609e-01
    z[2,6,3]  R1752     -4.1541284322738647e-01
    z[2,6,3]  R1753     -5.3775084018707275e-01
    z[2,6,3]  R1754     -2.1474617719650269e-01
    z[2,6,3]  R1755     -6.2661296129226685e-01
    z[2,6,3]  R1756     -7.4903172254562378e-01
    z[2,6,3]  R1757     -6.2439376115798950e-01
    z[2,6,3]  R1758     -5.8437591791152954e-01
    z[2,6,3]  R1759     -1.6673199832439423e-01
    z[2,6,3]  R1760     -1.1684054881334305e-01
    z[2,6,3]  R1761     -1.6926182806491852e-01
    z[2,6,3]  R1762     3.2364353537559509e-01
    z[2,6,3]  R1763     -1.0207553952932358e-01
    z[2,6,3]  R1764     4.0911316871643066e-01
    z[2,6,3]  R1765     1.8863391876220703e-01
    z[2,6,3]  R1766     2.4182501435279846e-01
    z[2,6,3]  R1767     3.3136495947837830e-01
    z[2,6,3]  R1768     4.2438396811485291e-01
    z[2,6,3]  R1769     1.3828664086759090e-02
    z[2,6,3]  R1770     1.9436357915401459e-01
    z[2,6,3]  R1771     -1.8136920034885406e-01
    z[2,6,3]  R1772     7.9428905248641968e-01
    z[2,6,3]  R1773     -2.1760773658752441e-01
    z[2,6,3]  R1774     -1.7980632185935974e-01
    z[2,6,3]  R1775     8.1366300582885742e-01
    z[2,6,3]  R1776     5.4640734195709229e-01
    z[2,6,3]  R1777     4.6961575746536255e-01
    z[2,6,3]  R1778     4.2552584409713745e-01
    z[2,6,3]  R1779     3.7509584426879883e-01
    z[2,6,3]  R1780     6.2250560522079468e-01
    z[2,6,3]  R1781     -6.3955806195735931e-02
    z[2,6,3]  R1782     -1.2864026427268982e-01
    z[2,6,3]  R1783     -3.7321120500564575e-01
    z[2,6,3]  R1784     7.0065855979919434e-01
    z[2,6,3]  R1785     6.0737454891204834e-01
    z[2,6,3]  R1786     4.0486183762550354e-01
    z[2,6,3]  R1787     0.525330126285553
    z[2,6,3]  R1788     1.1478332430124283e-01
    z[2,6,3]  R1789     4.6427825093269348e-01
    z[2,6,3]  R1790     1.0086484998464584e-01
    z[2,6,3]  R1791     -2.8510352969169617e-01
    z[2,6,3]  R1792     -0.350054532289505
    z[2,6,3]  R1793     -3.9437657594680786e-01
    z[2,6,3]  R1794     -4.1259208321571350e-01
    z[2,6,3]  R1795     -4.9987259507179260e-01
    z[2,6,3]  R1796     -7.4416071176528931e-01
    z[2,6,3]  R1797     -0.333583801984787
    z[2,6,3]  R1798     -0.61178058385849
    z[2,6,3]  R1799     -6.4532315731048584e-01
    z[2,6,3]  R1800     1.7141984775662422e-02
    z[2,6,3]  R1801     -2.8958681225776672e-01
    z[2,6,3]  R1802     -1.0979428887367249e-01
    z[2,6,3]  R1803     -2.3557485640048981e-01
    z[2,6,3]  R1804     -3.0106914043426514e-01
    z[2,6,3]  R1805     -5.2056002616882324e-01
    z[2,6,3]  R1806     -3.9136391133069992e-02
    z[2,6,3]  R1807     1.4334677159786224e-01
    z[2,6,3]  R1808     1.0982558876276016e-01
    z[2,6,3]  R1809     -5.4830479621887207e-01
    z[2,6,3]  R1810     -1.2247132509946823e-01
    z[2,6,3]  R1811     4.9489909410476685e-01
    z[2,6,3]  R1812     4.1878691315650940e-01
    z[2,6,3]  R1813     4.3676272034645081e-01
    z[2,6,3]  R1814     1.2569785118103027e-01
    z[2,6,3]  R1815     1.3759475946426392e-01
    z[2,6,3]  R1816     -3.5409703850746155e-02
    z[2,6,3]  R1817     2.1893191337585449e-01
    z[2,6,3]  R1818     2.5135273113846779e-02
    z[2,6,3]  R1819     1.0995906591415405e-01
    z[2,6,3]  R1820     -7.0078149437904358e-02
    z[2,6,3]  R1821     6.5950727462768555e-01
    z[2,6,3]  R1822     7.3568254709243774e-01
    z[2,6,3]  R1823     -2.3707455396652222e-01
    z[2,6,3]  R1824     6.3124515116214752e-02
    z[2,6,3]  R1825     0.578386127948761
    z[2,6,3]  R1826     4.2485916614532471e-01
    z[2,6,3]  R1827     4.4990864396095276e-01
    z[2,6,3]  R1828     -6.1239427328109741e-01
    z[2,6,3]  R1829     -3.4515447914600372e-02
    z[2,6,3]  R1830     4.6823480725288391e-01
    z[2,6,3]  R1831     6.1810213327407837e-01
    z[2,6,3]  R1832     5.1329600811004639e-01
    z[2,6,3]  R1833     4.9232026934623718e-01
    z[2,6,3]  R1834     4.5263597369194031e-01
    z[2,6,3]  R1835     5.3748887777328491e-01
    z[2,6,3]  R1836     4.4000127911567688e-01
    z[2,6,3]  R1837     -1.0103973001241684e-01
    z[2,6,3]  R1838     1.2310529127717018e-02
    z[2,6,3]  R1839     5.8581686019897461e-01
    z[2,6,3]  R1840     -3.9492005109786987e-01
    z[2,6,3]  R1841     7.0988953113555908e-01
    z[2,6,3]  R1842     6.3191086053848267e-01
    z[2,6,3]  R1843     7.2458791732788086e-01
    z[2,6,3]  R1844     1.0826722532510757e-01
    z[2,6,3]  R1845     -2.7075886726379395e-01
    z[2,6,3]  R1846     4.8253166675567627e-01
    z[2,6,3]  R1847     2.9851797223091125e-01
    z[2,6,3]  R1848     1.8411509692668915e-01
    z[2,6,3]  R1849     -1.6450254619121552e-01
    z[2,6,3]  R1850     -6.2767666578292847e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1745     -1
    z[2,6,4]  R1746     1
    z[2,6,4]  R1751     -0.0178383756428957
    z[2,6,4]  R1752     -4.6718839555978775e-02
    z[2,6,4]  R1753     -6.0257494449615479e-02
    z[2,6,4]  R1754     -4.5382639765739441e-01
    z[2,6,4]  R1755     -2.5469473004341125e-01
    z[2,6,4]  R1756     -1.0551095008850098e-01
    z[2,6,4]  R1757     2.9713329672813416e-01
    z[2,6,4]  R1758     3.7180770188570023e-02
    z[2,6,4]  R1759     4.0392377972602844e-01
    z[2,6,4]  R1760     2.4103714525699615e-01
    z[2,6,4]  R1761     -2.5213941931724548e-01
    z[2,6,4]  R1762     -2.4225538969039917e-01
    z[2,6,4]  R1763     -9.1686114668846130e-02
    z[2,6,4]  R1764     -1.3998466730117798e-01
    z[2,6,4]  R1765     9.2688970267772675e-02
    z[2,6,4]  R1766     5.2372928708791733e-02
    z[2,6,4]  R1767     -1.0429803282022476e-01
    z[2,6,4]  R1768     -1.0389237850904465e-01
    z[2,6,4]  R1769     1.7746625840663910e-01
    z[2,6,4]  R1770     -4.4248613715171814e-01
    z[2,6,4]  R1771     -1.3213990628719330e-01
    z[2,6,4]  R1772     -5.9071164578199387e-02
    z[2,6,4]  R1773     -4.3168950080871582e-01
    z[2,6,4]  R1774     -7.5712114572525024e-01
    z[2,6,4]  R1775     1.1694841831922531e-01
    z[2,6,4]  R1776     -9.3024484813213348e-02
    z[2,6,4]  R1777     -6.8430745601654053e-01
    z[2,6,4]  R1778     -6.5788125991821289e-01
    z[2,6,4]  R1779     -6.9979226589202881e-01
    z[2,6,4]  R1780     -3.6981284618377686e-01
    z[2,6,4]  R1781     1.1258546262979507e-01
    z[2,6,4]  R1782     -3.7390846014022827e-01
    z[2,6,4]  R1783     3.3302713185548782e-02
    z[2,6,4]  R1784     -1.9245386123657227e-01
    z[2,6,4]  R1785     -2.9392004013061523e-01
    z[2,6,4]  R1786     -7.5283324718475342e-01
    z[2,6,4]  R1787     -7.0575617253780365e-02
    z[2,6,4]  R1788     1.0091464221477509e-01
    z[2,6,4]  R1789     9.7659686580300331e-03
    z[2,6,4]  R1790     1.2039819359779358e-01
    z[2,6,4]  R1791     -1.0488862544298172e-01
    z[2,6,4]  R1792     -1.9606997072696686e-01
    z[2,6,4]  R1793     6.0652624815702438e-02
    z[2,6,4]  R1794     0.368369460105896
    z[2,6,4]  R1795     3.9720591902732849e-01
    z[2,6,4]  R1796     -1.9950459897518158e-01
    z[2,6,4]  R1797     -3.1402030587196350e-01
    z[2,6,4]  R1798     -1.2811496853828430e-01
    z[2,6,4]  R1799     9.1959655284881592e-02
    z[2,6,4]  R1800     3.5564652085304260e-01
    z[2,6,4]  R1801     1.8025381863117218e-01
    z[2,6,4]  R1802     -3.0721658468246460e-01
    z[2,6,4]  R1803     -9.9761180579662323e-02
    z[2,6,4]  R1804     -9.9405609071254730e-02
    z[2,6,4]  R1805     -7.6257757842540741e-02
    z[2,6,4]  R1806     2.9486769437789917e-01
    z[2,6,4]  R1807     1.4858794212341309e-01
    z[2,6,4]  R1808     -2.7082918211817741e-02
    z[2,6,4]  R1809     -2.0101411640644073e-01
    z[2,6,4]  R1810     2.5490963459014893e-01
    z[2,6,4]  R1811     -2.0636771619319916e-01
    z[2,6,4]  R1812     -3.5147297382354736e-01
    z[2,6,4]  R1813     -2.7333977818489075e-01
    z[2,6,4]  R1814     -2.7641248703002930e-01
    z[2,6,4]  R1815     -9.0551199391484261e-03
    z[2,6,4]  R1816     4.5610601082444191e-03
    z[2,6,4]  R1817     -2.5453658774495125e-02
    z[2,6,4]  R1818     1.8933297833427787e-03
    z[2,6,4]  R1819     2.8246089816093445e-01
    z[2,6,4]  R1820     4.6399328112602234e-01
    z[2,6,4]  R1821     2.2853070870041847e-02
    z[2,6,4]  R1822     -6.0383808612823486e-01
    z[2,6,4]  R1823     1.5979662537574768e-02
    z[2,6,4]  R1824     -8.3219580352306366e-02
    z[2,6,4]  R1825     -2.7004875242710114e-02
    z[2,6,4]  R1826     -2.6455727219581604e-01
    z[2,6,4]  R1827     -3.9190530776977539e-01
    z[2,6,4]  R1828     3.9881461858749390e-01
    z[2,6,4]  R1829     2.8546103276312351e-03
    z[2,6,4]  R1830     -1.5324451029300690e-01
    z[2,6,4]  R1831     -4.2493742704391479e-01
    z[2,6,4]  R1832     -2.5676766037940979e-01
    z[2,6,4]  R1833     7.0771694183349609e-02
    z[2,6,4]  R1834     -1.5333485603332520e-01
    z[2,6,4]  R1835     1.9122689962387085e-01
    z[2,6,4]  R1836     -0.550078272819519
    z[2,6,4]  R1837     3.3858400583267212e-01
    z[2,6,4]  R1838     4.3738394975662231e-01
    z[2,6,4]  R1839     -4.3129265308380127e-01
    z[2,6,4]  R1840     6.0318976640701294e-01
    z[2,6,4]  R1841     -5.9991395473480225e-01
    z[2,6,4]  R1842     -0.379001647233963
    z[2,6,4]  R1843     -3.0295750498771667e-01
    z[2,6,4]  R1844     -1.4633558690547943e-02
    z[2,6,4]  R1845     4.1551116108894348e-01
    z[2,6,4]  R1846     -3.4798362851142883e-01
    z[2,6,4]  R1847     -0.0678536519408226
    z[2,6,4]  R1848     -6.4541742205619812e-02
    z[2,6,4]  R1849     9.0936217457056046e-03
    z[2,6,4]  R1850     -3.0608716607093811e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1747     -1
    z[2,6,5]  R1748     1
    z[2,6,5]  R1751     3.8339686393737793e-01
    z[2,6,5]  R1752     7.4416443705558777e-02
    z[2,6,5]  R1753     2.6872122287750244e-01
    z[2,6,5]  R1754     1.9816392660140991e-01
    z[2,6,5]  R1755     2.1644225716590881e-01
    z[2,6,5]  R1756     2.7994787693023682e-01
    z[2,6,5]  R1757     1.2733405828475952e-01
    z[2,6,5]  R1758     -1.0238508880138397e-01
    z[2,6,5]  R1759     3.4010317921638489e-01
    z[2,6,5]  R1760     -3.9974547922611237e-02
    z[2,6,5]  R1761     -3.6941388249397278e-01
    z[2,6,5]  R1762     -3.4650653600692749e-01
    z[2,6,5]  R1763     -4.4726513326168060e-02
    z[2,6,5]  R1764     -0.519870400428772
    z[2,6,5]  R1765     -1.6513921320438385e-01
    z[2,6,5]  R1766     -3.3169832825660706e-01
    z[2,6,5]  R1767     -4.7022223472595215e-01
    z[2,6,5]  R1768     -6.1688584089279175e-01
    z[2,6,5]  R1769     -6.2938481569290161e-01
    z[2,6,5]  R1770     -5.7471239566802979e-01
    z[2,6,5]  R1771     -6.2409126758575439e-01
    z[2,6,5]  R1772     -1.6205992549657822e-02
    z[2,6,5]  R1773     -4.0821567177772522e-01
    z[2,6,5]  R1774     -5.4451203346252441e-01
    z[2,6,5]  R1775     -1.0340183973312378e-01
    z[2,6,5]  R1776     5.6958663463592529e-01
    z[2,6,5]  R1777     4.1589897871017456e-01
    z[2,6,5]  R1778     3.1338497996330261e-01
    z[2,6,5]  R1779     3.9741155505180359e-01
    z[2,6,5]  R1780     -2.8564637899398804e-01
    z[2,6,5]  R1781     -5.6243741512298584e-01
    z[2,6,5]  R1782     -4.5603013038635254e-01
    z[2,6,5]  R1783     -3.9154800772666931e-01
    z[2,6,5]  R1784     -4.0158487856388092e-02
    z[2,6,5]  R1785     3.2321658730506897e-01
    z[2,6,5]  R1786     3.2331734895706177e-01
    z[2,6,5]  R1787     -4.0162622928619385e-01
    z[2,6,5]  R1788     2.4523507058620453e-01
    z[2,6,5]  R1789     3.1295937299728394e-01
    z[2,6,5]  R1790     1.1620508134365082e-01
    z[2,6,5]  R1791     1.4739826321601868e-01
    z[2,6,5]  R1792     3.7568813562393188e-01
    z[2,6,5]  R1793     2.4111062288284302e-01
    z[2,6,5]  R1794     2.4034756422042847e-01
    z[2,6,5]  R1795     1.9551150500774384e-01
    z[2,6,5]  R1796     0.446159690618515
    z[2,6,5]  R1797     5.6286835670471191e-01
    z[2,6,5]  R1798     2.3995193839073181e-01
    z[2,6,5]  R1799     -2.5375589728355408e-01
    z[2,6,5]  R1800     1.7624123394489288e-01
    z[2,6,5]  R1801     -2.7007976174354553e-01
    z[2,6,5]  R1802     -1.9779351353645325e-01
    z[2,6,5]  R1803     -1.8678367137908936e-01
    z[2,6,5]  R1804     1.6880062222480774e-01
    z[2,6,5]  R1805     1.0740427672863007e-01
    z[2,6,5]  R1806     -3.6001911759376526e-01
    z[2,6,5]  R1807     -5.4434555768966675e-01
    z[2,6,5]  R1808     -4.6388161182403564e-01
    z[2,6,5]  R1809     -5.7261552661657333e-02
    z[2,6,5]  R1810     -2.7936546131968498e-02
    z[2,6,5]  R1811     2.1938018035143614e-03
    z[2,6,5]  R1812     -2.8313118219375610e-01
    z[2,6,5]  R1813     -1.6117073595523834e-01
    z[2,6,5]  R1814     -6.0378503799438477e-01
    z[2,6,5]  R1815     4.8354521393775940e-02
    z[2,6,5]  R1816     7.4749879539012909e-02
    z[2,6,5]  R1817     -0.0522022470831871
    z[2,6,5]  R1818     -1.2488479726016521e-02
    z[2,6,5]  R1819     -3.5223349928855896e-02
    z[2,6,5]  R1820     3.6601489782333374e-01
    z[2,6,5]  R1821     2.6328054070472717e-01
    z[2,6,5]  R1822     -1.0909955948591232e-01
    z[2,6,5]  R1823     -1.3134272396564484e-01
    z[2,6,5]  R1824     -2.0239748060703278e-01
    z[2,6,5]  R1825     -5.0938504934310913e-01
    z[2,6,5]  R1826     3.9223301410675049e-01
    z[2,6,5]  R1827     1.8908958137035370e-01
    z[2,6,5]  R1828     2.9697835445404053e-01
    z[2,6,5]  R1829     -0.094648078083992
    z[2,6,5]  R1830     -6.2566363811492920e-01
    z[2,6,5]  R1831     1.2184092402458191e-01
    z[2,6,5]  R1832     3.8845051079988480e-02
    z[2,6,5]  R1833     -2.2432367503643036e-01
    z[2,6,5]  R1834     2.8363940119743347e-01
    z[2,6,5]  R1835     -4.7483119368553162e-01
    z[2,6,5]  R1836     4.4464193284511566e-02
    z[2,6,5]  R1837     -1.1897812038660049e-01
    z[2,6,5]  R1838     -8.9154131710529327e-02
    z[2,6,5]  R1839     -1.9231611490249634e-01
    z[2,6,5]  R1840     -4.5176412910223007e-02
    z[2,6,5]  R1841     -1.7778746783733368e-01
    z[2,6,5]  R1842     6.0651585459709167e-02
    z[2,6,5]  R1843     -2.0021903514862061e-01
    z[2,6,5]  R1844     -2.6244255900382996e-01
    z[2,6,5]  R1845     -1.3724821805953979e-01
    z[2,6,5]  R1846     3.7022197246551514e-01
    z[2,6,5]  R1847     3.4839814901351929e-01
    z[2,6,5]  R1848     -1.9910946488380432e-01
    z[2,6,5]  R1849     -2.5163310766220093e-01
    z[2,6,5]  R1850     3.2501003146171570e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1749     -1
    z[2,6,6]  R1750     1
    z[2,6,6]  R1751     2.6852054521441460e-02
    z[2,6,6]  R1752     -9.1749869287014008e-02
    z[2,6,6]  R1753     1.9953864812850952e-01
    z[2,6,6]  R1754     -5.5594801902770996e-02
    z[2,6,6]  R1755     4.1194528341293335e-02
    z[2,6,6]  R1756     -8.8617682456970215e-02
    z[2,6,6]  R1757     8.8885044679045677e-03
    z[2,6,6]  R1758     -4.1980691254138947e-02
    z[2,6,6]  R1759     3.2020047307014465e-01
    z[2,6,6]  R1760     2.5830745697021484e-01
    z[2,6,6]  R1761     -1.3043585419654846e-01
    z[2,6,6]  R1762     -1.0522356629371643e-01
    z[2,6,6]  R1763     -2.6178336702287197e-03
    z[2,6,6]  R1764     -2.2865532338619232e-01
    z[2,6,6]  R1765     -1.5521687269210815e-01
    z[2,6,6]  R1766     -3.8367825746536255e-01
    z[2,6,6]  R1767     2.7135983109474182e-01
    z[2,6,6]  R1768     2.7077487111091614e-01
    z[2,6,6]  R1769     3.1675910949707031e-01
    z[2,6,6]  R1770     2.7105422690510750e-02
    z[2,6,6]  R1771     4.3651174753904343e-02
    z[2,6,6]  R1772     1.6516314819455147e-02
    z[2,6,6]  R1773     5.8261758089065552e-01
    z[2,6,6]  R1774     0.0882897898554802
    z[2,6,6]  R1775     -5.0918185710906982e-01
    z[2,6,6]  R1776     -3.4413103014230728e-02
    z[2,6,6]  R1777     -2.9413762688636780e-01
    z[2,6,6]  R1778     3.9203155040740967e-01
    z[2,6,6]  R1779     4.3268457055091858e-01
    z[2,6,6]  R1780     -1.0839474201202393e-01
    z[2,6,6]  R1781     6.3343368470668793e-02
    z[2,6,6]  R1782     0.25189009308815
    z[2,6,6]  R1783     6.6726314835250378e-03
    z[2,6,6]  R1784     -6.4489126205444336e-01
    z[2,6,6]  R1785     -3.4458079934120178e-01
    z[2,6,6]  R1786     2.3714034259319305e-01
    z[2,6,6]  R1787     2.4156366288661957e-01
    z[2,6,6]  R1788     1.7024591565132141e-01
    z[2,6,6]  R1789     5.6444126367568970e-01
    z[2,6,6]  R1790     -2.3695375025272369e-01
    z[2,6,6]  R1791     0.0797148197889328
    z[2,6,6]  R1792     1.7736832797527313e-01
    z[2,6,6]  R1793     -8.2950927317142487e-02
    z[2,6,6]  R1794     -7.9377971589565277e-02
    z[2,6,6]  R1795     2.4014383554458618e-01
    z[2,6,6]  R1796     6.6895879805088043e-02
    z[2,6,6]  R1797     -1.1080216616392136e-01
    z[2,6,6]  R1798     3.1717082858085632e-01
    z[2,6,6]  R1799     7.7935561537742615e-02
    z[2,6,6]  R1800     -1.6237047314643860e-01
    z[2,6,6]  R1801     -6.1286713927984238e-02
    z[2,6,6]  R1802     -1.8329469859600067e-01
    z[2,6,6]  R1803     -1.1739210784435272e-01
    z[2,6,6]  R1804     -6.8392440676689148e-02
    z[2,6,6]  R1805     1.6138932108879089e-01
    z[2,6,6]  R1806     -3.8603687286376953e-01
    z[2,6,6]  R1807     -1.8159691244363785e-02
    z[2,6,6]  R1808     -0.25421342253685
    z[2,6,6]  R1809     1.9502714276313782e-01
    z[2,6,6]  R1810     -3.5569229722023010e-01
    z[2,6,6]  R1811     6.5111279487609863e-01
    z[2,6,6]  R1812     -2.1217620372772217e-01
    z[2,6,6]  R1813     2.6413185521960258e-02
    z[2,6,6]  R1814     2.6901605725288391e-01
    z[2,6,6]  R1815     1.8414634466171265e-01
    z[2,6,6]  R1816     -1.3079290091991425e-01
    z[2,6,6]  R1817     6.0909580439329147e-02
    z[2,6,6]  R1818     4.8238448798656464e-02
    z[2,6,6]  R1819     2.8042057529091835e-02
    z[2,6,6]  R1820     3.0011010169982910e-01
    z[2,6,6]  R1821     1.2375874817371368e-01
    z[2,6,6]  R1822     -1.5376168489456177e-01
    z[2,6,6]  R1823     0.0669020339846611
    z[2,6,6]  R1824     3.2456547021865845e-01
    z[2,6,6]  R1825     -4.6026620268821716e-01
    z[2,6,6]  R1826     -6.7944127321243286e-01
    z[2,6,6]  R1827     -1.8194955587387085e-01
    z[2,6,6]  R1828     -6.4635932445526123e-02
    z[2,6,6]  R1829     -2.2853240370750427e-01
    z[2,6,6]  R1830     2.6339176297187805e-01
    z[2,6,6]  R1831     -5.4281371831893921e-01
    z[2,6,6]  R1832     -6.4313375949859619e-01
    z[2,6,6]  R1833     2.7348589897155762e-01
    z[2,6,6]  R1834     -3.0346539616584778e-01
    z[2,6,6]  R1835     -1.8489879369735718e-01
    z[2,6,6]  R1836     6.4327597618103027e-01
    z[2,6,6]  R1837     1.3814416527748108e-01
    z[2,6,6]  R1838     -8.4790289402008057e-02
    z[2,6,6]  R1839     1.0809958726167679e-01
    z[2,6,6]  R1840     1.8006315827369690e-01
    z[2,6,6]  R1841     9.3888416886329651e-02
    z[2,6,6]  R1842     -1.2835410237312317e-01
    z[2,6,6]  R1843     1.2356420606374741e-01
    z[2,6,6]  R1844     -3.3267840743064880e-02
    z[2,6,6]  R1845     -2.4746958911418915e-01
    z[2,6,6]  R1846     3.1949594616889954e-01
    z[2,6,6]  R1847     5.8465325832366943e-01
    z[2,6,6]  R1848     -3.9723575115203857e-02
    z[2,6,6]  R1849     -9.9051259458065033e-03
    z[2,6,6]  R1850     2.0256226416677237e-03
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1851     -1
    z[6,2,0]  R1852     1
    z[6,2,0]  R1865     0.709740936756134
    z[6,2,0]  R1866     3.6230233311653137e-01
    z[6,2,0]  R1867     0.629054069519043
    z[6,2,0]  R1868     0.233524888753891
    z[6,2,0]  R1869     4.6908289194107056e-01
    z[6,2,0]  R1870     2.6015964150428772e-01
    z[6,2,0]  R1871     4.1445079445838928e-01
    z[6,2,0]  R1872     5.7593095302581787e-01
    z[6,2,0]  R1873     1.5702585875988007e-01
    z[6,2,0]  R1874     5.3924626111984253e-01
    z[6,2,0]  R1875     -5.3836303949356079e-01
    z[6,2,0]  R1876     -4.3145808577537537e-01
    z[6,2,0]  R1877     -4.1351196169853210e-01
    z[6,2,0]  R1878     -7.4025779962539673e-01
    z[6,2,0]  R1879     -5.5635732412338257e-01
    z[6,2,0]  R1880     -4.5257467031478882e-01
    z[6,2,0]  R1881     -2.9112818837165833e-01
    z[6,2,0]  R1882     -2.8168797492980957e-01
    z[6,2,0]  R1883     -3.7196445465087891e-01
    z[6,2,0]  R1884     -6.0151129961013794e-01
    z[6,2,0]  R1885     -3.1354081630706787e-01
    z[6,2,0]  R1886     7.1117728948593140e-01
    z[6,2,0]  R1887     -6.5981775522232056e-01
    z[6,2,0]  R1888     -4.5274645090103149e-01
    z[6,2,0]  R1889     -1.5458774566650391e-01
    z[6,2,0]  R1890     -8.7819606065750122e-02
    z[6,2,0]  R1891     -3.6092811822891235e-01
    z[6,2,0]  R1892     -1.5699428319931030e-01
    z[6,2,0]  R1893     -1.6911458969116211e-01
    z[6,2,0]  R1894     -6.2999892234802246e-01
    z[6,2,0]  R1895     4.3794098496437073e-01
    z[6,2,0]  R1896     -1.1244311928749084e-01
    z[6,2,0]  R1897     -5.8221215009689331e-01
    z[6,2,0]  R1898     -6.3366800546646118e-01
    z[6,2,0]  R1899     1.2343308329582214e-01
    z[6,2,0]  R1900     -9.1407202184200287e-02
    z[6,2,0]  R1901     -7.1424573659896851e-01
    z[6,2,0]  R1902     -3.5588359832763672e-01
    z[6,2,0]  R1903     -1.1344072222709656e-01
    z[6,2,0]  R1904     3.8538837432861328e-01
    z[6,2,0]  R1905     -3.4258842468261719e-01
    z[6,2,0]  R1906     1.2562611699104309e-01
    z[6,2,0]  R1907     -6.0157239437103271e-02
    z[6,2,0]  R1908     -4.8489010334014893e-01
    z[6,2,0]  R1909     7.7022269368171692e-02
    z[6,2,0]  R1910     2.5774019956588745e-01
    z[6,2,0]  R1911     -7.8487378358840942e-01
    z[6,2,0]  R1912     -0.67607581615448
    z[6,2,0]  R1913     4.0135046839714050e-01
    z[6,2,0]  R1914     -5.2852904796600342e-01
    z[6,2,0]  R1915     -1.6651949286460876e-01
    z[6,2,0]  R1916     2.0789556205272675e-01
    z[6,2,0]  R1917     3.9218395948410034e-01
    z[6,2,0]  R1918     -6.7370146512985229e-01
    z[6,2,0]  R1919     -5.1515656709671021e-01
    z[6,2,0]  R1920     2.0023368299007416e-02
    z[6,2,0]  R1921     -8.0589786171913147e-02
    z[6,2,0]  R1922     -1.6670224070549011e-01
    z[6,2,0]  R1923     -3.6944296956062317e-01
    z[6,2,0]  R1924     -4.0090450644493103e-01
    z[6,2,0]  R1925     0.443828284740448
    z[6,2,0]  R1926     0.596022367477417
    z[6,2,0]  R1927     5.8625990152359009e-01
    z[6,2,0]  R1928     4.5706677436828613e-01
    z[6,2,0]  R1929     2.2589190304279327e-01
    z[6,2,0]  R1930     3.8704875111579895e-01
    z[6,2,0]  R1931     3.0130943655967712e-01
    z[6,2,0]  R1932     5.8022117614746094e-01
    z[6,2,0]  R1933     0.547103226184845
    z[6,2,0]  R1934     -1.9522064924240112e-01
    z[6,2,0]  R1935     -5.9889388084411621e-01
    z[6,2,0]  R1936     -5.5948734283447266e-01
    z[6,2,0]  R1937     -7.2994542121887207e-01
    z[6,2,0]  R1938     -4.2817932367324829e-01
    z[6,2,0]  R1939     -7.4910598993301392e-01
    z[6,2,0]  R1940     -4.0614092350006104e-01
    z[6,2,0]  R1941     -5.9933245182037354e-01
    z[6,2,0]  R1942     -3.8821491599082947e-01
    z[6,2,0]  R1943     -2.6076626777648926e-01
    z[6,2,0]  R1944     -4.7347363829612732e-01
    z[6,2,0]  R1945     -1.8241828307509422e-02
    z[6,2,0]  R1946     3.5420483350753784e-01
    z[6,2,0]  R1947     -3.4724938869476318e-01
    z[6,2,0]  R1948     -0.0746384710073471
    z[6,2,0]  R1949     2.0175845921039581e-01
    z[6,2,0]  R1950     -1.2036658078432083e-01
    z[6,2,0]  R1951     -1.1681912094354630e-01
    z[6,2,0]  R1952     2.6472198963165283e-01
    z[6,2,0]  R1953     -6.0214199125766754e-02
    z[6,2,0]  R1954     -1.1675311252474785e-02
    z[6,2,0]  R1955     -3.9184695482254028e-01
    z[6,2,0]  R1956     -0.439421683549881
    z[6,2,0]  R1957     -0.185368150472641
    z[6,2,0]  R1958     -1.0790064185857773e-01
    z[6,2,0]  R1959     -5.3795784711837769e-01
    z[6,2,0]  R1960     -3.2538771629333496e-01
    z[6,2,0]  R1961     8.3735115826129913e-02
    z[6,2,0]  R1962     -4.8598015308380127e-01
    z[6,2,0]  R1963     -4.9811840057373047e-01
    z[6,2,0]  R1964     -0.307282954454422
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1853     -1
    z[6,2,1]  R1854     1
    z[6,2,1]  R1865     2.4190494418144226e-01
    z[6,2,1]  R1866     2.8154906630516052e-01
    z[6,2,1]  R1867     7.3732741177082062e-02
    z[6,2,1]  R1868     0.405757337808609
    z[6,2,1]  R1869     0.4198018014431
    z[6,2,1]  R1870     3.2296755909919739e-01
    z[6,2,1]  R1871     3.5791835188865662e-01
    z[6,2,1]  R1872     0.0816793143749237
    z[6,2,1]  R1873     2.1950738131999969e-01
    z[6,2,1]  R1874     5.2721697092056274e-01
    z[6,2,1]  R1875     -4.2514353990554810e-01
    z[6,2,1]  R1876     -3.7765043973922729e-01
    z[6,2,1]  R1877     -1.2175317108631134e-01
    z[6,2,1]  R1878     -1.5905758738517761e-01
    z[6,2,1]  R1879     -1.3026267290115356e-01
    z[6,2,1]  R1880     -0.288029283285141
    z[6,2,1]  R1881     -1.9473029673099518e-01
    z[6,2,1]  R1882     -2.6331162452697754e-01
    z[6,2,1]  R1883     -3.5283035039901733e-01
    z[6,2,1]  R1884     0.0972060039639473
    z[6,2,1]  R1885     3.4821841120719910e-01
    z[6,2,1]  R1886     1.6479054465889931e-02
    z[6,2,1]  R1887     -3.2278180122375488e-01
    z[6,2,1]  R1888     -2.9606339335441589e-01
    z[6,2,1]  R1889     -9.5858675241470337e-01
    z[6,2,1]  R1890     -9.7568619251251221e-01
    z[6,2,1]  R1891     -9.0082573890686035e-01
    z[6,2,1]  R1892     -9.6243840456008911e-01
    z[6,2,1]  R1893     -9.3594169616699219e-01
    z[6,2,1]  R1894     1.6161382198333740e-01
    z[6,2,1]  R1895     3.0210077762603760e-01
    z[6,2,1]  R1896     -2.1115374565124512e-01
    z[6,2,1]  R1897     -0.127500519156456
    z[6,2,1]  R1898     -2.0129573345184326e-01
    z[6,2,1]  R1899     -3.6651373375207186e-03
    z[6,2,1]  R1900     2.8281578421592712e-01
    z[6,2,1]  R1901     -0.115801140666008
    z[6,2,1]  R1902     -1.4698682725429535e-01
    z[6,2,1]  R1903     -9.1631585359573364e-01
    z[6,2,1]  R1904     -1.0541752912104130e-02
    z[6,2,1]  R1905     -9.8470970988273621e-03
    z[6,2,1]  R1906     -3.9768457412719727e-01
    z[6,2,1]  R1907     5.9079676866531372e-01
    z[6,2,1]  R1908     -5.5885225534439087e-01
    z[6,2,1]  R1909     3.4029465913772583e-01
    z[6,2,1]  R1910     4.1088182479143143e-02
    z[6,2,1]  R1911     -3.9760297536849976e-01
    z[6,2,1]  R1912     1.5373589098453522e-01
    z[6,2,1]  R1913     4.3040168285369873e-01
    z[6,2,1]  R1914     8.7787836790084839e-02
    z[6,2,1]  R1915     -1.6055350005626678e-01
    z[6,2,1]  R1916     6.0036581754684448e-01
    z[6,2,1]  R1917     4.1186764836311340e-01
    z[6,2,1]  R1918     -4.7440952062606812e-01
    z[6,2,1]  R1919     2.8013916686177254e-02
    z[6,2,1]  R1920     -6.3481992483139038e-01
    z[6,2,1]  R1921     1.7278394103050232e-01
    z[6,2,1]  R1922     -9.3897312879562378e-01
    z[6,2,1]  R1923     -8.7880575656890869e-01
    z[6,2,1]  R1924     -4.9423524737358093e-01
    z[6,2,1]  R1925     2.3911124467849731e-01
    z[6,2,1]  R1926     1.0747678577899933e-01
    z[6,2,1]  R1927     9.9074125289916992e-02
    z[6,2,1]  R1928     2.6177468895912170e-01
    z[6,2,1]  R1929     2.9460325837135315e-01
    z[6,2,1]  R1930     3.5361862182617188e-01
    z[6,2,1]  R1931     3.4898763895034790e-01
    z[6,2,1]  R1932     4.8065102100372314e-01
    z[6,2,1]  R1933     2.5980255007743835e-01
    z[6,2,1]  R1934     -8.5558688640594482e-01
    z[6,2,1]  R1935     -8.5406258702278137e-02
    z[6,2,1]  R1936     -4.2828482389450073e-01
    z[6,2,1]  R1937     -4.5273122191429138e-01
    z[6,2,1]  R1938     -1.1212576180696487e-01
    z[6,2,1]  R1939     -3.8804542273283005e-03
    z[6,2,1]  R1940     -3.9136001467704773e-01
    z[6,2,1]  R1941     1.3638220727443695e-01
    z[6,2,1]  R1942     -8.1791423261165619e-02
    z[6,2,1]  R1943     -9.3317642807960510e-02
    z[6,2,1]  R1944     1.5056781470775604e-01
    z[6,2,1]  R1945     -5.1217317581176758e-01
    z[6,2,1]  R1946     -1.7223972082138062e-01
    z[6,2,1]  R1947     -2.8673630952835083e-01
    z[6,2,1]  R1948     -0.224474236369133
    z[6,2,1]  R1949     -9.3072272837162018e-02
    z[6,2,1]  R1950     -1.6432899236679077e-01
    z[6,2,1]  R1951     1.0145115852355957e-01
    z[6,2,1]  R1952     -2.4835982918739319e-01
    z[6,2,1]  R1953     -5.6369885802268982e-02
    z[6,2,1]  R1954     5.9535884857177734e-01
    z[6,2,1]  R1955     4.0345042943954468e-02
    z[6,2,1]  R1956     -4.2288365960121155e-01
    z[6,2,1]  R1957     -5.5005472898483276e-01
    z[6,2,1]  R1958     2.0386627316474915e-01
    z[6,2,1]  R1959     4.4791221618652344e-02
    z[6,2,1]  R1960     3.4200098365545273e-02
    z[6,2,1]  R1961     6.9640129804611206e-01
    z[6,2,1]  R1962     8.0537945032119751e-01
    z[6,2,1]  R1963     -2.2044022381305695e-01
    z[6,2,1]  R1964     8.9695996046066284e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1855     -1
    z[6,2,2]  R1856     1
    z[6,2,2]  R1865     5.6336796283721924e-01
    z[6,2,2]  R1866     6.7519217729568481e-01
    z[6,2,2]  R1867     6.1206829547882080e-01
    z[6,2,2]  R1868     6.4096099138259888e-01
    z[6,2,2]  R1869     3.1652599573135376e-01
    z[6,2,2]  R1870     1.7577858269214630e-01
    z[6,2,2]  R1871     4.0142270922660828e-01
    z[6,2,2]  R1872     3.3581075072288513e-01
    z[6,2,2]  R1873     6.5711104869842529e-01
    z[6,2,2]  R1874     4.9704349040985107e-01
    z[6,2,2]  R1875     -5.7997167110443115e-01
    z[6,2,2]  R1876     -7.0147556066513062e-01
    z[6,2,2]  R1877     -8.3670020103454590e-01
    z[6,2,2]  R1878     -5.4131674766540527e-01
    z[6,2,2]  R1879     -5.9926450252532959e-01
    z[6,2,2]  R1880     -5.8745086193084717e-01
    z[6,2,2]  R1881     -7.3352301120758057e-01
    z[6,2,2]  R1882     -7.4747115373611450e-01
    z[6,2,2]  R1883     -5.9564578533172607e-01
    z[6,2,2]  R1884     -6.4919906854629517e-01
    z[6,2,2]  R1885     -2.6262274384498596e-01
    z[6,2,2]  R1886     -2.6430574059486389e-01
    z[6,2,2]  R1887     -4.1024681925773621e-01
    z[6,2,2]  R1888     -4.2218139767646790e-01
    z[6,2,2]  R1889     -4.4179830700159073e-02
    z[6,2,2]  R1890     1.2788753211498260e-01
    z[6,2,2]  R1891     5.6832566857337952e-02
    z[6,2,2]  R1892     2.1435181796550751e-01
    z[6,2,2]  R1893     0.0388757586479187
    z[6,2,2]  R1894     -0.364346981048584
    z[6,2,2]  R1895     -4.4366419315338135e-01
    z[6,2,2]  R1896     -3.7094447761774063e-02
    z[6,2,2]  R1897     -7.5271910429000854e-01
    z[6,2,2]  R1898     -6.3303023576736450e-01
    z[6,2,2]  R1899     -4.2210537195205688e-01
    z[6,2,2]  R1900     -2.1372132003307343e-01
    z[6,2,2]  R1901     -2.2710137069225311e-01
    z[6,2,2]  R1902     -4.7464501857757568e-01
    z[6,2,2]  R1903     -2.9173898696899414e-01
    z[6,2,2]  R1904     -3.8445648550987244e-01
    z[6,2,2]  R1905     -1.0208919644355774e-01
    z[6,2,2]  R1906     -2.8553920984268188e-01
    z[6,2,2]  R1907     -5.2424877882003784e-01
    z[6,2,2]  R1908     -2.2722736001014709e-01
    z[6,2,2]  R1909     -5.4143589735031128e-01
    z[6,2,2]  R1910     -1.4111521840095520e-01
    z[6,2,2]  R1911     -2.6037901639938354e-01
    z[6,2,2]  R1912     -5.5918926000595093e-01
    z[6,2,2]  R1913     -2.7532979846000671e-01
    z[6,2,2]  R1914     -3.9835530519485474e-01
    z[6,2,2]  R1915     -2.0550100505352020e-01
    z[6,2,2]  R1916     -1.8229983747005463e-01
    z[6,2,2]  R1917     -6.6258095204830170e-02
    z[6,2,2]  R1918     -4.8902264237403870e-01
    z[6,2,2]  R1919     -6.3858497142791748e-01
    z[6,2,2]  R1920     5.9425350278615952e-02
    z[6,2,2]  R1921     0.63775634765625
    z[6,2,2]  R1922     -1.0608106106519699e-01
    z[6,2,2]  R1923     2.5521349161863327e-02
    z[6,2,2]  R1924     -4.1280549019575119e-02
    z[6,2,2]  R1925     7.6214402914047241e-01
    z[6,2,2]  R1926     6.6670817136764526e-01
    z[6,2,2]  R1927     4.9157905578613281e-01
    z[6,2,2]  R1928     6.5431642532348633e-01
    z[6,2,2]  R1929     5.9676152467727661e-01
    z[6,2,2]  R1930     2.5834500789642334e-01
    z[6,2,2]  R1931     5.4126840829849243e-01
    z[6,2,2]  R1932     2.7784049510955811e-01
    z[6,2,2]  R1933     4.7331610321998596e-01
    z[6,2,2]  R1934     -2.9964751005172729e-01
    z[6,2,2]  R1935     -6.2315952777862549e-01
    z[6,2,2]  R1936     -4.5713719725608826e-01
    z[6,2,2]  R1937     -4.9130564928054810e-01
    z[6,2,2]  R1938     -5.4274529218673706e-01
    z[6,2,2]  R1939     -5.8590775728225708e-01
    z[6,2,2]  R1940     -6.0285305976867676e-01
    z[6,2,2]  R1941     -4.5472463965415955e-01
    z[6,2,2]  R1942     -4.4478836655616760e-01
    z[6,2,2]  R1943     -6.2860614061355591e-01
    z[6,2,2]  R1944     -4.3422549962997437e-01
    z[6,2,2]  R1945     -5.4368627071380615e-01
    z[6,2,2]  R1946     4.5820564031600952e-01
    z[6,2,2]  R1947     -2.3959949612617493e-01
    z[6,2,2]  R1948     -1.8490347266197205e-01
    z[6,2,2]  R1949     7.0345804095268250e-02
    z[6,2,2]  R1950     5.7068395614624023e-01
    z[6,2,2]  R1951     1.6660247743129730e-01
    z[6,2,2]  R1952     -4.9605220556259155e-02
    z[6,2,2]  R1953     1.3281117379665375e-01
    z[6,2,2]  R1954     1.6671356558799744e-01
    z[6,2,2]  R1955     -7.1254062652587891e-01
    z[6,2,2]  R1956     -4.4756001234054565e-01
    z[6,2,2]  R1957     -6.0772401094436646e-01
    z[6,2,2]  R1958     3.6574136465787888e-02
    z[6,2,2]  R1959     1.7348611354827881e-01
    z[6,2,2]  R1960     -3.8892120122909546e-02
    z[6,2,2]  R1961     8.6048319935798645e-02
    z[6,2,2]  R1962     5.2002891898155212e-02
    z[6,2,2]  R1963     2.6664009690284729e-01
    z[6,2,2]  R1964     -8.1974111497402191e-02
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1857     -1
    z[6,2,3]  R1858     1
    z[6,2,3]  R1865     -2.8510352969169617e-01
    z[6,2,3]  R1866     -0.350054532289505
    z[6,2,3]  R1867     -3.9437657594680786e-01
    z[6,2,3]  R1868     -4.1259208321571350e-01
    z[6,2,3]  R1869     -4.9987259507179260e-01
    z[6,2,3]  R1870     -7.4416071176528931e-01
    z[6,2,3]  R1871     -0.333583801984787
    z[6,2,3]  R1872     -0.61178058385849
    z[6,2,3]  R1873     -6.4532315731048584e-01
    z[6,2,3]  R1874     1.7141984775662422e-02
    z[6,2,3]  R1875     -2.8958681225776672e-01
    z[6,2,3]  R1876     -1.0979428887367249e-01
    z[6,2,3]  R1877     -2.3557485640048981e-01
    z[6,2,3]  R1878     -3.0106914043426514e-01
    z[6,2,3]  R1879     -5.2056002616882324e-01
    z[6,2,3]  R1880     -3.9136391133069992e-02
    z[6,2,3]  R1881     1.4334677159786224e-01
    z[6,2,3]  R1882     1.0982558876276016e-01
    z[6,2,3]  R1883     -5.4830479621887207e-01
    z[6,2,3]  R1884     -1.2247132509946823e-01
    z[6,2,3]  R1885     4.9489909410476685e-01
    z[6,2,3]  R1886     4.1878691315650940e-01
    z[6,2,3]  R1887     4.3676272034645081e-01
    z[6,2,3]  R1888     1.2569785118103027e-01
    z[6,2,3]  R1889     1.3759475946426392e-01
    z[6,2,3]  R1890     -3.5409703850746155e-02
    z[6,2,3]  R1891     2.1893191337585449e-01
    z[6,2,3]  R1892     2.5135273113846779e-02
    z[6,2,3]  R1893     1.0995906591415405e-01
    z[6,2,3]  R1894     -7.0078149437904358e-02
    z[6,2,3]  R1895     6.5950727462768555e-01
    z[6,2,3]  R1896     7.3568254709243774e-01
    z[6,2,3]  R1897     -2.3707455396652222e-01
    z[6,2,3]  R1898     6.3124515116214752e-02
    z[6,2,3]  R1899     0.578386127948761
    z[6,2,3]  R1900     4.2485916614532471e-01
    z[6,2,3]  R1901     4.4990864396095276e-01
    z[6,2,3]  R1902     -6.1239427328109741e-01
    z[6,2,3]  R1903     -3.4515447914600372e-02
    z[6,2,3]  R1904     4.6823480725288391e-01
    z[6,2,3]  R1905     6.1810213327407837e-01
    z[6,2,3]  R1906     5.1329600811004639e-01
    z[6,2,3]  R1907     4.9232026934623718e-01
    z[6,2,3]  R1908     4.5263597369194031e-01
    z[6,2,3]  R1909     5.3748887777328491e-01
    z[6,2,3]  R1910     4.4000127911567688e-01
    z[6,2,3]  R1911     -1.0103973001241684e-01
    z[6,2,3]  R1912     1.2310529127717018e-02
    z[6,2,3]  R1913     5.8581686019897461e-01
    z[6,2,3]  R1914     -3.9492005109786987e-01
    z[6,2,3]  R1915     7.0988953113555908e-01
    z[6,2,3]  R1916     6.3191086053848267e-01
    z[6,2,3]  R1917     7.2458791732788086e-01
    z[6,2,3]  R1918     1.0826722532510757e-01
    z[6,2,3]  R1919     -2.7075886726379395e-01
    z[6,2,3]  R1920     4.8253166675567627e-01
    z[6,2,3]  R1921     2.9851797223091125e-01
    z[6,2,3]  R1922     1.8411509692668915e-01
    z[6,2,3]  R1923     -1.6450254619121552e-01
    z[6,2,3]  R1924     -6.2767666578292847e-01
    z[6,2,3]  R1925     -1.3017807900905609e-01
    z[6,2,3]  R1926     -4.1541284322738647e-01
    z[6,2,3]  R1927     -5.3775084018707275e-01
    z[6,2,3]  R1928     -2.1474617719650269e-01
    z[6,2,3]  R1929     -6.2661296129226685e-01
    z[6,2,3]  R1930     -7.4903172254562378e-01
    z[6,2,3]  R1931     -6.2439376115798950e-01
    z[6,2,3]  R1932     -5.8437591791152954e-01
    z[6,2,3]  R1933     -1.6673199832439423e-01
    z[6,2,3]  R1934     -1.1684054881334305e-01
    z[6,2,3]  R1935     -1.6926182806491852e-01
    z[6,2,3]  R1936     3.2364353537559509e-01
    z[6,2,3]  R1937     -1.0207553952932358e-01
    z[6,2,3]  R1938     4.0911316871643066e-01
    z[6,2,3]  R1939     1.8863391876220703e-01
    z[6,2,3]  R1940     2.4182501435279846e-01
    z[6,2,3]  R1941     3.3136495947837830e-01
    z[6,2,3]  R1942     4.2438396811485291e-01
    z[6,2,3]  R1943     1.3828664086759090e-02
    z[6,2,3]  R1944     1.9436357915401459e-01
    z[6,2,3]  R1945     -1.8136920034885406e-01
    z[6,2,3]  R1946     7.9428905248641968e-01
    z[6,2,3]  R1947     -2.1760773658752441e-01
    z[6,2,3]  R1948     -1.7980632185935974e-01
    z[6,2,3]  R1949     8.1366300582885742e-01
    z[6,2,3]  R1950     5.4640734195709229e-01
    z[6,2,3]  R1951     4.6961575746536255e-01
    z[6,2,3]  R1952     4.2552584409713745e-01
    z[6,2,3]  R1953     3.7509584426879883e-01
    z[6,2,3]  R1954     6.2250560522079468e-01
    z[6,2,3]  R1955     -6.3955806195735931e-02
    z[6,2,3]  R1956     -1.2864026427268982e-01
    z[6,2,3]  R1957     -3.7321120500564575e-01
    z[6,2,3]  R1958     7.0065855979919434e-01
    z[6,2,3]  R1959     6.0737454891204834e-01
    z[6,2,3]  R1960     4.0486183762550354e-01
    z[6,2,3]  R1961     0.525330126285553
    z[6,2,3]  R1962     1.1478332430124283e-01
    z[6,2,3]  R1963     4.6427825093269348e-01
    z[6,2,3]  R1964     1.0086484998464584e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1859     -1
    z[6,2,4]  R1860     1
    z[6,2,4]  R1865     -1.0488862544298172e-01
    z[6,2,4]  R1866     -1.9606997072696686e-01
    z[6,2,4]  R1867     6.0652624815702438e-02
    z[6,2,4]  R1868     0.368369460105896
    z[6,2,4]  R1869     3.9720591902732849e-01
    z[6,2,4]  R1870     -1.9950459897518158e-01
    z[6,2,4]  R1871     -3.1402030587196350e-01
    z[6,2,4]  R1872     -1.2811496853828430e-01
    z[6,2,4]  R1873     9.1959655284881592e-02
    z[6,2,4]  R1874     3.5564652085304260e-01
    z[6,2,4]  R1875     1.8025381863117218e-01
    z[6,2,4]  R1876     -3.0721658468246460e-01
    z[6,2,4]  R1877     -9.9761180579662323e-02
    z[6,2,4]  R1878     -9.9405609071254730e-02
    z[6,2,4]  R1879     -7.6257757842540741e-02
    z[6,2,4]  R1880     2.9486769437789917e-01
    z[6,2,4]  R1881     1.4858794212341309e-01
    z[6,2,4]  R1882     -2.7082918211817741e-02
    z[6,2,4]  R1883     -2.0101411640644073e-01
    z[6,2,4]  R1884     2.5490963459014893e-01
    z[6,2,4]  R1885     -2.0636771619319916e-01
    z[6,2,4]  R1886     -3.5147297382354736e-01
    z[6,2,4]  R1887     -2.7333977818489075e-01
    z[6,2,4]  R1888     -2.7641248703002930e-01
    z[6,2,4]  R1889     -9.0551199391484261e-03
    z[6,2,4]  R1890     4.5610601082444191e-03
    z[6,2,4]  R1891     -2.5453658774495125e-02
    z[6,2,4]  R1892     1.8933297833427787e-03
    z[6,2,4]  R1893     2.8246089816093445e-01
    z[6,2,4]  R1894     4.6399328112602234e-01
    z[6,2,4]  R1895     2.2853070870041847e-02
    z[6,2,4]  R1896     -6.0383808612823486e-01
    z[6,2,4]  R1897     1.5979662537574768e-02
    z[6,2,4]  R1898     -8.3219580352306366e-02
    z[6,2,4]  R1899     -2.7004875242710114e-02
    z[6,2,4]  R1900     -2.6455727219581604e-01
    z[6,2,4]  R1901     -3.9190530776977539e-01
    z[6,2,4]  R1902     3.9881461858749390e-01
    z[6,2,4]  R1903     2.8546103276312351e-03
    z[6,2,4]  R1904     -1.5324451029300690e-01
    z[6,2,4]  R1905     -4.2493742704391479e-01
    z[6,2,4]  R1906     -2.5676766037940979e-01
    z[6,2,4]  R1907     7.0771694183349609e-02
    z[6,2,4]  R1908     -1.5333485603332520e-01
    z[6,2,4]  R1909     1.9122689962387085e-01
    z[6,2,4]  R1910     -0.550078272819519
    z[6,2,4]  R1911     3.3858400583267212e-01
    z[6,2,4]  R1912     4.3738394975662231e-01
    z[6,2,4]  R1913     -4.3129265308380127e-01
    z[6,2,4]  R1914     6.0318976640701294e-01
    z[6,2,4]  R1915     -5.9991395473480225e-01
    z[6,2,4]  R1916     -0.379001647233963
    z[6,2,4]  R1917     -3.0295750498771667e-01
    z[6,2,4]  R1918     -1.4633558690547943e-02
    z[6,2,4]  R1919     4.1551116108894348e-01
    z[6,2,4]  R1920     -3.4798362851142883e-01
    z[6,2,4]  R1921     -0.0678536519408226
    z[6,2,4]  R1922     -6.4541742205619812e-02
    z[6,2,4]  R1923     9.0936217457056046e-03
    z[6,2,4]  R1924     -3.0608716607093811e-01
    z[6,2,4]  R1925     -0.0178383756428957
    z[6,2,4]  R1926     -4.6718839555978775e-02
    z[6,2,4]  R1927     -6.0257494449615479e-02
    z[6,2,4]  R1928     -4.5382639765739441e-01
    z[6,2,4]  R1929     -2.5469473004341125e-01
    z[6,2,4]  R1930     -1.0551095008850098e-01
    z[6,2,4]  R1931     2.9713329672813416e-01
    z[6,2,4]  R1932     3.7180770188570023e-02
    z[6,2,4]  R1933     4.0392377972602844e-01
    z[6,2,4]  R1934     2.4103714525699615e-01
    z[6,2,4]  R1935     -2.5213941931724548e-01
    z[6,2,4]  R1936     -2.4225538969039917e-01
    z[6,2,4]  R1937     -9.1686114668846130e-02
    z[6,2,4]  R1938     -1.3998466730117798e-01
    z[6,2,4]  R1939     9.2688970267772675e-02
    z[6,2,4]  R1940     5.2372928708791733e-02
    z[6,2,4]  R1941     -1.0429803282022476e-01
    z[6,2,4]  R1942     -1.0389237850904465e-01
    z[6,2,4]  R1943     1.7746625840663910e-01
    z[6,2,4]  R1944     -4.4248613715171814e-01
    z[6,2,4]  R1945     -1.3213990628719330e-01
    z[6,2,4]  R1946     -5.9071164578199387e-02
    z[6,2,4]  R1947     -4.3168950080871582e-01
    z[6,2,4]  R1948     -7.5712114572525024e-01
    z[6,2,4]  R1949     1.1694841831922531e-01
    z[6,2,4]  R1950     -9.3024484813213348e-02
    z[6,2,4]  R1951     -6.8430745601654053e-01
    z[6,2,4]  R1952     -6.5788125991821289e-01
    z[6,2,4]  R1953     -6.9979226589202881e-01
    z[6,2,4]  R1954     -3.6981284618377686e-01
    z[6,2,4]  R1955     1.1258546262979507e-01
    z[6,2,4]  R1956     -3.7390846014022827e-01
    z[6,2,4]  R1957     3.3302713185548782e-02
    z[6,2,4]  R1958     -1.9245386123657227e-01
    z[6,2,4]  R1959     -2.9392004013061523e-01
    z[6,2,4]  R1960     -7.5283324718475342e-01
    z[6,2,4]  R1961     -7.0575617253780365e-02
    z[6,2,4]  R1962     1.0091464221477509e-01
    z[6,2,4]  R1963     9.7659686580300331e-03
    z[6,2,4]  R1964     1.2039819359779358e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1861     -1
    z[6,2,5]  R1862     1
    z[6,2,5]  R1865     1.4739826321601868e-01
    z[6,2,5]  R1866     3.7568813562393188e-01
    z[6,2,5]  R1867     2.4111062288284302e-01
    z[6,2,5]  R1868     2.4034756422042847e-01
    z[6,2,5]  R1869     1.9551150500774384e-01
    z[6,2,5]  R1870     0.446159690618515
    z[6,2,5]  R1871     5.6286835670471191e-01
    z[6,2,5]  R1872     2.3995193839073181e-01
    z[6,2,5]  R1873     -2.5375589728355408e-01
    z[6,2,5]  R1874     1.7624123394489288e-01
    z[6,2,5]  R1875     -2.7007976174354553e-01
    z[6,2,5]  R1876     -1.9779351353645325e-01
    z[6,2,5]  R1877     -1.8678367137908936e-01
    z[6,2,5]  R1878     1.6880062222480774e-01
    z[6,2,5]  R1879     1.0740427672863007e-01
    z[6,2,5]  R1880     -3.6001911759376526e-01
    z[6,2,5]  R1881     -5.4434555768966675e-01
    z[6,2,5]  R1882     -4.6388161182403564e-01
    z[6,2,5]  R1883     -5.7261552661657333e-02
    z[6,2,5]  R1884     -2.7936546131968498e-02
    z[6,2,5]  R1885     2.1938018035143614e-03
    z[6,2,5]  R1886     -2.8313118219375610e-01
    z[6,2,5]  R1887     -1.6117073595523834e-01
    z[6,2,5]  R1888     -6.0378503799438477e-01
    z[6,2,5]  R1889     4.8354521393775940e-02
    z[6,2,5]  R1890     7.4749879539012909e-02
    z[6,2,5]  R1891     -0.0522022470831871
    z[6,2,5]  R1892     -1.2488479726016521e-02
    z[6,2,5]  R1893     -3.5223349928855896e-02
    z[6,2,5]  R1894     3.6601489782333374e-01
    z[6,2,5]  R1895     2.6328054070472717e-01
    z[6,2,5]  R1896     -1.0909955948591232e-01
    z[6,2,5]  R1897     -1.3134272396564484e-01
    z[6,2,5]  R1898     -2.0239748060703278e-01
    z[6,2,5]  R1899     -5.0938504934310913e-01
    z[6,2,5]  R1900     3.9223301410675049e-01
    z[6,2,5]  R1901     1.8908958137035370e-01
    z[6,2,5]  R1902     2.9697835445404053e-01
    z[6,2,5]  R1903     -0.094648078083992
    z[6,2,5]  R1904     -6.2566363811492920e-01
    z[6,2,5]  R1905     1.2184092402458191e-01
    z[6,2,5]  R1906     3.8845051079988480e-02
    z[6,2,5]  R1907     -2.2432367503643036e-01
    z[6,2,5]  R1908     2.8363940119743347e-01
    z[6,2,5]  R1909     -4.7483119368553162e-01
    z[6,2,5]  R1910     4.4464193284511566e-02
    z[6,2,5]  R1911     -1.1897812038660049e-01
    z[6,2,5]  R1912     -8.9154131710529327e-02
    z[6,2,5]  R1913     -1.9231611490249634e-01
    z[6,2,5]  R1914     -4.5176412910223007e-02
    z[6,2,5]  R1915     -1.7778746783733368e-01
    z[6,2,5]  R1916     6.0651585459709167e-02
    z[6,2,5]  R1917     -2.0021903514862061e-01
    z[6,2,5]  R1918     -2.6244255900382996e-01
    z[6,2,5]  R1919     -1.3724821805953979e-01
    z[6,2,5]  R1920     3.7022197246551514e-01
    z[6,2,5]  R1921     3.4839814901351929e-01
    z[6,2,5]  R1922     -1.9910946488380432e-01
    z[6,2,5]  R1923     -2.5163310766220093e-01
    z[6,2,5]  R1924     3.2501003146171570e-01
    z[6,2,5]  R1925     3.8339686393737793e-01
    z[6,2,5]  R1926     7.4416443705558777e-02
    z[6,2,5]  R1927     2.6872122287750244e-01
    z[6,2,5]  R1928     1.9816392660140991e-01
    z[6,2,5]  R1929     2.1644225716590881e-01
    z[6,2,5]  R1930     2.7994787693023682e-01
    z[6,2,5]  R1931     1.2733405828475952e-01
    z[6,2,5]  R1932     -1.0238508880138397e-01
    z[6,2,5]  R1933     3.4010317921638489e-01
    z[6,2,5]  R1934     -3.9974547922611237e-02
    z[6,2,5]  R1935     -3.6941388249397278e-01
    z[6,2,5]  R1936     -3.4650653600692749e-01
    z[6,2,5]  R1937     -4.4726513326168060e-02
    z[6,2,5]  R1938     -0.519870400428772
    z[6,2,5]  R1939     -1.6513921320438385e-01
    z[6,2,5]  R1940     -3.3169832825660706e-01
    z[6,2,5]  R1941     -4.7022223472595215e-01
    z[6,2,5]  R1942     -6.1688584089279175e-01
    z[6,2,5]  R1943     -6.2938481569290161e-01
    z[6,2,5]  R1944     -5.7471239566802979e-01
    z[6,2,5]  R1945     -6.2409126758575439e-01
    z[6,2,5]  R1946     -1.6205992549657822e-02
    z[6,2,5]  R1947     -4.0821567177772522e-01
    z[6,2,5]  R1948     -5.4451203346252441e-01
    z[6,2,5]  R1949     -1.0340183973312378e-01
    z[6,2,5]  R1950     5.6958663463592529e-01
    z[6,2,5]  R1951     4.1589897871017456e-01
    z[6,2,5]  R1952     3.1338497996330261e-01
    z[6,2,5]  R1953     3.9741155505180359e-01
    z[6,2,5]  R1954     -2.8564637899398804e-01
    z[6,2,5]  R1955     -5.6243741512298584e-01
    z[6,2,5]  R1956     -4.5603013038635254e-01
    z[6,2,5]  R1957     -3.9154800772666931e-01
    z[6,2,5]  R1958     -4.0158487856388092e-02
    z[6,2,5]  R1959     3.2321658730506897e-01
    z[6,2,5]  R1960     3.2331734895706177e-01
    z[6,2,5]  R1961     -4.0162622928619385e-01
    z[6,2,5]  R1962     2.4523507058620453e-01
    z[6,2,5]  R1963     3.1295937299728394e-01
    z[6,2,5]  R1964     1.1620508134365082e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1863     -1
    z[6,2,6]  R1864     1
    z[6,2,6]  R1865     0.0797148197889328
    z[6,2,6]  R1866     1.7736832797527313e-01
    z[6,2,6]  R1867     -8.2950927317142487e-02
    z[6,2,6]  R1868     -7.9377971589565277e-02
    z[6,2,6]  R1869     2.4014383554458618e-01
    z[6,2,6]  R1870     6.6895879805088043e-02
    z[6,2,6]  R1871     -1.1080216616392136e-01
    z[6,2,6]  R1872     3.1717082858085632e-01
    z[6,2,6]  R1873     7.7935561537742615e-02
    z[6,2,6]  R1874     -1.6237047314643860e-01
    z[6,2,6]  R1875     -6.1286713927984238e-02
    z[6,2,6]  R1876     -1.8329469859600067e-01
    z[6,2,6]  R1877     -1.1739210784435272e-01
    z[6,2,6]  R1878     -6.8392440676689148e-02
    z[6,2,6]  R1879     1.6138932108879089e-01
    z[6,2,6]  R1880     -3.8603687286376953e-01
    z[6,2,6]  R1881     -1.8159691244363785e-02
    z[6,2,6]  R1882     -0.25421342253685
    z[6,2,6]  R1883     1.9502714276313782e-01
    z[6,2,6]  R1884     -3.5569229722023010e-01
    z[6,2,6]  R1885     6.5111279487609863e-01
    z[6,2,6]  R1886     -2.1217620372772217e-01
    z[6,2,6]  R1887     2.6413185521960258e-02
    z[6,2,6]  R1888     2.6901605725288391e-01
    z[6,2,6]  R1889     1.8414634466171265e-01
    z[6,2,6]  R1890     -1.3079290091991425e-01
    z[6,2,6]  R1891     6.0909580439329147e-02
    z[6,2,6]  R1892     4.8238448798656464e-02
    z[6,2,6]  R1893     2.8042057529091835e-02
    z[6,2,6]  R1894     3.0011010169982910e-01
    z[6,2,6]  R1895     1.2375874817371368e-01
    z[6,2,6]  R1896     -1.5376168489456177e-01
    z[6,2,6]  R1897     0.0669020339846611
    z[6,2,6]  R1898     3.2456547021865845e-01
    z[6,2,6]  R1899     -4.6026620268821716e-01
    z[6,2,6]  R1900     -6.7944127321243286e-01
    z[6,2,6]  R1901     -1.8194955587387085e-01
    z[6,2,6]  R1902     -6.4635932445526123e-02
    z[6,2,6]  R1903     -2.2853240370750427e-01
    z[6,2,6]  R1904     2.6339176297187805e-01
    z[6,2,6]  R1905     -5.4281371831893921e-01
    z[6,2,6]  R1906     -6.4313375949859619e-01
    z[6,2,6]  R1907     2.7348589897155762e-01
    z[6,2,6]  R1908     -3.0346539616584778e-01
    z[6,2,6]  R1909     -1.8489879369735718e-01
    z[6,2,6]  R1910     6.4327597618103027e-01
    z[6,2,6]  R1911     1.3814416527748108e-01
    z[6,2,6]  R1912     -8.4790289402008057e-02
    z[6,2,6]  R1913     1.0809958726167679e-01
    z[6,2,6]  R1914     1.8006315827369690e-01
    z[6,2,6]  R1915     9.3888416886329651e-02
    z[6,2,6]  R1916     -1.2835410237312317e-01
    z[6,2,6]  R1917     1.2356420606374741e-01
    z[6,2,6]  R1918     -3.3267840743064880e-02
    z[6,2,6]  R1919     -2.4746958911418915e-01
    z[6,2,6]  R1920     3.1949594616889954e-01
    z[6,2,6]  R1921     5.8465325832366943e-01
    z[6,2,6]  R1922     -3.9723575115203857e-02
    z[6,2,6]  R1923     -9.9051259458065033e-03
    z[6,2,6]  R1924     2.0256226416677237e-03
    z[6,2,6]  R1925     2.6852054521441460e-02
    z[6,2,6]  R1926     -9.1749869287014008e-02
    z[6,2,6]  R1927     1.9953864812850952e-01
    z[6,2,6]  R1928     -5.5594801902770996e-02
    z[6,2,6]  R1929     4.1194528341293335e-02
    z[6,2,6]  R1930     -8.8617682456970215e-02
    z[6,2,6]  R1931     8.8885044679045677e-03
    z[6,2,6]  R1932     -4.1980691254138947e-02
    z[6,2,6]  R1933     3.2020047307014465e-01
    z[6,2,6]  R1934     2.5830745697021484e-01
    z[6,2,6]  R1935     -1.3043585419654846e-01
    z[6,2,6]  R1936     -1.0522356629371643e-01
    z[6,2,6]  R1937     -2.6178336702287197e-03
    z[6,2,6]  R1938     -2.2865532338619232e-01
    z[6,2,6]  R1939     -1.5521687269210815e-01
    z[6,2,6]  R1940     -3.8367825746536255e-01
    z[6,2,6]  R1941     2.7135983109474182e-01
    z[6,2,6]  R1942     2.7077487111091614e-01
    z[6,2,6]  R1943     3.1675910949707031e-01
    z[6,2,6]  R1944     2.7105422690510750e-02
    z[6,2,6]  R1945     4.3651174753904343e-02
    z[6,2,6]  R1946     1.6516314819455147e-02
    z[6,2,6]  R1947     5.8261758089065552e-01
    z[6,2,6]  R1948     0.0882897898554802
    z[6,2,6]  R1949     -5.0918185710906982e-01
    z[6,2,6]  R1950     -3.4413103014230728e-02
    z[6,2,6]  R1951     -2.9413762688636780e-01
    z[6,2,6]  R1952     3.9203155040740967e-01
    z[6,2,6]  R1953     4.3268457055091858e-01
    z[6,2,6]  R1954     -1.0839474201202393e-01
    z[6,2,6]  R1955     6.3343368470668793e-02
    z[6,2,6]  R1956     0.25189009308815
    z[6,2,6]  R1957     6.6726314835250378e-03
    z[6,2,6]  R1958     -6.4489126205444336e-01
    z[6,2,6]  R1959     -3.4458079934120178e-01
    z[6,2,6]  R1960     2.3714034259319305e-01
    z[6,2,6]  R1961     2.4156366288661957e-01
    z[6,2,6]  R1962     1.7024591565132141e-01
    z[6,2,6]  R1963     5.6444126367568970e-01
    z[6,2,6]  R1964     -2.3695375025272369e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2019     -1
    z[3,4,0]  R2020     1
    z[3,4,0]  R2033     -6.0292345285415649e-01
    z[3,4,0]  R2034     -5.9713470935821533e-01
    z[3,4,0]  R2035     -7.9646384716033936e-01
    z[3,4,0]  R2036     0.593394935131073
    z[3,4,0]  R2037     -0.430400013923645
    z[3,4,0]  R2038     3.6738941073417664e-01
    z[3,4,0]  R2039     6.8841701745986938e-01
    z[3,4,0]  R2040     2.7344632148742676e-01
    z[3,4,0]  R2041     3.5563737154006958e-01
    z[3,4,0]  R2042     4.9206703901290894e-01
    z[3,4,0]  R2043     -2.8547435998916626e-01
    z[3,4,0]  R2044     -1.9855169579386711e-02
    z[3,4,0]  R2045     -7.0916842669248581e-03
    z[3,4,0]  R2046     -2.0397590473294258e-02
    z[3,4,0]  R2047     -6.5713502466678619e-02
    z[3,4,0]  R2048     3.0177175998687744e-01
    z[3,4,0]  R2049     3.8811814785003662e-01
    z[3,4,0]  R2050     -1.8501804769039154e-01
    z[3,4,0]  R2051     0.167601078748703
    z[3,4,0]  R2052     8.1268265843391418e-02
    z[3,4,0]  R2053     5.1078337430953979e-01
    z[3,4,0]  R2054     -2.2165615856647491e-01
    z[3,4,0]  R2055     7.2538322210311890e-01
    z[3,4,0]  R2056     8.0320823192596436e-01
    z[3,4,0]  R2057     5.4646110534667969e-01
    z[3,4,0]  R2058     4.4635590910911560e-01
    z[3,4,0]  R2059     5.7215999811887741e-02
    z[3,4,0]  R2060     6.9971328973770142e-01
    z[3,4,0]  R2061     0.713864803314209
    z[3,4,0]  R2062     7.7606225013732910e-01
    z[3,4,0]  R2063     -0.397827684879303
    z[3,4,0]  R2064     7.2482812404632568e-01
    z[3,4,0]  R2065     -2.4095913767814636e-01
    z[3,4,0]  R2066     0.813280463218689
    z[3,4,0]  R2067     1.3921824283897877e-02
    z[3,4,0]  R2068     6.2162774801254272e-01
    z[3,4,0]  R2069     5.1198744773864746e-01
    z[3,4,0]  R2070     6.4981174468994141e-01
    z[3,4,0]  R2071     -4.9261572957038879e-01
    z[3,4,0]  R2072     2.5793758034706116e-01
    z[3,4,0]  R2073     6.9175004959106445e-02
    z[3,4,0]  R2074     -3.7531760334968567e-01
    z[3,4,0]  R2075     -4.9100264906883240e-02
    z[3,4,0]  R2076     3.8662287592887878e-01
    z[3,4,0]  R2077     7.8889721632003784e-01
    z[3,4,0]  R2078     -3.9210504293441772e-01
    z[3,4,0]  R2079     7.3289644718170166e-01
    z[3,4,0]  R2080     1.8111538887023926e-01
    z[3,4,0]  R2081     -3.0878129601478577e-01
    z[3,4,0]  R2082     -3.5077667236328125e-01
    z[3,4,0]  R2083     1.6145157814025879e-01
    z[3,4,0]  R2084     -6.0774767771363258e-03
    z[3,4,0]  R2085     2.2393876314163208e-01
    z[3,4,0]  R2086     -8.2619786262512207e-02
    z[3,4,0]  R2087     -1.9507546722888947e-01
    z[3,4,0]  R2088     -2.6520419120788574e-01
    z[3,4,0]  R2089     -3.1409361958503723e-01
    z[3,4,0]  R2090     2.3205070756375790e-03
    z[3,4,0]  R2091     3.8971800357103348e-02
    z[3,4,0]  R2092     1.1771667003631592e-01
    z[3,4,0]  R2093     -2.2602401673793793e-01
    z[3,4,0]  R2094     -7.5803823769092560e-02
    z[3,4,0]  R2095     5.8438873291015625e-01
    z[3,4,0]  R2096     -2.4338236451148987e-01
    z[3,4,0]  R2097     -3.5414078831672668e-01
    z[3,4,0]  R2098     -4.8526591062545776e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2021     -1
    z[3,4,1]  R2022     1
    z[3,4,1]  R2033     -4.9979650974273682e-01
    z[3,4,1]  R2034     -3.7981674075126648e-01
    z[3,4,1]  R2035     -2.0791263878345490e-01
    z[3,4,1]  R2036     3.7678810954093933e-01
    z[3,4,1]  R2037     -4.3685835599899292e-01
    z[3,4,1]  R2038     7.3186588287353516e-01
    z[3,4,1]  R2039     5.6335467100143433e-01
    z[3,4,1]  R2040     -5.8704257011413574e-01
    z[3,4,1]  R2041     2.5529748201370239e-01
    z[3,4,1]  R2042     -3.0720129609107971e-01
    z[3,4,1]  R2043     -4.9055501818656921e-01
    z[3,4,1]  R2044     -8.5490924119949341e-01
    z[3,4,1]  R2045     -7.7586907148361206e-01
    z[3,4,1]  R2046     -7.6240330934524536e-01
    z[3,4,1]  R2047     -6.7092359066009521e-01
    z[3,4,1]  R2048     -0.72418612241745
    z[3,4,1]  R2049     -6.1174947023391724e-01
    z[3,4,1]  R2050     -6.1788523197174072e-01
    z[3,4,1]  R2051     -9.1981792449951172e-01
    z[3,4,1]  R2052     -5.2808022499084473e-01
    z[3,4,1]  R2053     5.4192101955413818e-01
    z[3,4,1]  R2054     -8.2055938243865967e-01
    z[3,4,1]  R2055     4.7175922989845276e-01
    z[3,4,1]  R2056     1.1841738224029541e-01
    z[3,4,1]  R2057     2.9551774263381958e-01
    z[3,4,1]  R2058     0.809660017490387
    z[3,4,1]  R2059     -2.1381278336048126e-01
    z[3,4,1]  R2060     -1.8627347052097321e-01
    z[3,4,1]  R2061     0.00829958077520132
    z[3,4,1]  R2062     -3.7942326068878174e-01
    z[3,4,1]  R2063     -4.5845040678977966e-01
    z[3,4,1]  R2064     2.7378877997398376e-01
    z[3,4,1]  R2065     -2.6002889871597290e-01
    z[3,4,1]  R2066     -3.5557288210839033e-03
    z[3,4,1]  R2067     -2.9835966229438782e-01
    z[3,4,1]  R2068     -3.6772534251213074e-01
    z[3,4,1]  R2069     -4.3924498558044434e-01
    z[3,4,1]  R2070     -2.4902668595314026e-01
    z[3,4,1]  R2071     1.4090338349342346e-01
    z[3,4,1]  R2072     3.8887679576873779e-01
    z[3,4,1]  R2073     -7.4931782484054565e-01
    z[3,4,1]  R2074     -0.632306694984436
    z[3,4,1]  R2075     -7.8275579214096069e-01
    z[3,4,1]  R2076     -6.6907012462615967e-01
    z[3,4,1]  R2077     -2.8633108735084534e-01
    z[3,4,1]  R2078     -0.757557213306427
    z[3,4,1]  R2079     -3.0009558796882629e-01
    z[3,4,1]  R2080     3.3315002918243408e-01
    z[3,4,1]  R2081     8.9879298210144043e-01
    z[3,4,1]  R2082     8.9376252889633179e-01
    z[3,4,1]  R2083     -4.3822664022445679e-01
    z[3,4,1]  R2084     1.4301015995442867e-02
    z[3,4,1]  R2085     -2.1769827604293823e-01
    z[3,4,1]  R2086     7.4809336662292480e-01
    z[3,4,1]  R2087     9.2499506473541260e-01
    z[3,4,1]  R2088     4.7634577751159668e-01
    z[3,4,1]  R2089     -5.9345757961273193e-01
    z[3,4,1]  R2090     -0.64082932472229
    z[3,4,1]  R2091     -1.9719904661178589e-01
    z[3,4,1]  R2092     -1.3739171624183655e-01
    z[3,4,1]  R2093     -5.8837819099426270e-01
    z[3,4,1]  R2094     -4.8108461499214172e-01
    z[3,4,1]  R2095     0.478423148393631
    z[3,4,1]  R2096     -3.0948597192764282e-01
    z[3,4,1]  R2097     -2.6688629388809204e-01
    z[3,4,1]  R2098     -1.9983960315585136e-02
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2023     -1
    z[3,4,2]  R2024     1
    z[3,4,2]  R2033     -3.4730517864227295e-01
    z[3,4,2]  R2034     -1.4648345112800598e-01
    z[3,4,2]  R2035     -4.0350863337516785e-01
    z[3,4,2]  R2036     7.0236515998840332e-01
    z[3,4,2]  R2037     -1.2193604372441769e-02
    z[3,4,2]  R2038     5.3562176227569580e-01
    z[3,4,2]  R2039     1.8169675767421722e-01
    z[3,4,2]  R2040     -3.1884562224149704e-02
    z[3,4,2]  R2041     5.2796679735183716e-01
    z[3,4,2]  R2042     5.4261833429336548e-01
    z[3,4,2]  R2043     -7.4606072902679443e-01
    z[3,4,2]  R2044     1.7190891504287720e-01
    z[3,4,2]  R2045     -3.0966898798942566e-01
    z[3,4,2]  R2046     2.1271331608295441e-01
    z[3,4,2]  R2047     2.2867359220981598e-02
    z[3,4,2]  R2048     -1.0302006453275681e-01
    z[3,4,2]  R2049     -1.3841852545738220e-01
    z[3,4,2]  R2050     6.8635516799986362e-03
    z[3,4,2]  R2051     1.3173352181911469e-01
    z[3,4,2]  R2052     -1.1156410723924637e-01
    z[3,4,2]  R2053     3.9218932390213013e-01
    z[3,4,2]  R2054     -1.8157172203063965e-01
    z[3,4,2]  R2055     3.2757565379142761e-01
    z[3,4,2]  R2056     1.9680313766002655e-01
    z[3,4,2]  R2057     4.5352223515510559e-01
    z[3,4,2]  R2058     2.9588249325752258e-01
    z[3,4,2]  R2059     -5.0353008508682251e-01
    z[3,4,2]  R2060     3.9402994513511658e-01
    z[3,4,2]  R2061     3.4777870774269104e-01
    z[3,4,2]  R2062     3.1732836365699768e-01
    z[3,4,2]  R2063     -5.5367767810821533e-01
    z[3,4,2]  R2064     5.6241697072982788e-01
    z[3,4,2]  R2065     -5.9100198745727539e-01
    z[3,4,2]  R2066     3.3056426048278809e-01
    z[3,4,2]  R2067     -2.4744980037212372e-01
    z[3,4,2]  R2068     2.2165837883949280e-01
    z[3,4,2]  R2069     1.9918750226497650e-01
    z[3,4,2]  R2070     0.0682726576924324
    z[3,4,2]  R2071     -1.8451346457004547e-01
    z[3,4,2]  R2072     -1.3119451701641083e-01
    z[3,4,2]  R2073     1.2991547584533691e-02
    z[3,4,2]  R2074     -3.0424109101295471e-01
    z[3,4,2]  R2075     1.2071663886308670e-01
    z[3,4,2]  R2076     -3.4740817500278354e-04
    z[3,4,2]  R2077     3.3287355303764343e-01
    z[3,4,2]  R2078     1.1665407568216324e-01
    z[3,4,2]  R2079     4.0914547443389893e-01
    z[3,4,2]  R2080     -3.4522455930709839e-01
    z[3,4,2]  R2081     -5.6712850928306580e-02
    z[3,4,2]  R2082     -1.4610143005847931e-01
    z[3,4,2]  R2083     -6.9253191351890564e-02
    z[3,4,2]  R2084     -3.0256372690200806e-01
    z[3,4,2]  R2085     -2.5511956214904785e-01
    z[3,4,2]  R2086     2.0857103168964386e-01
    z[3,4,2]  R2087     1.8213124573230743e-01
    z[3,4,2]  R2088     5.2006185054779053e-01
    z[3,4,2]  R2089     -4.6254900097846985e-01
    z[3,4,2]  R2090     -3.6887651681900024e-01
    z[3,4,2]  R2091     -6.4441967010498047e-01
    z[3,4,2]  R2092     -0.922522783279419
    z[3,4,2]  R2093     2.0473857223987579e-01
    z[3,4,2]  R2094     5.9967929124832153e-01
    z[3,4,2]  R2095     5.0681042671203613e-01
    z[3,4,2]  R2096     0.664128839969635
    z[3,4,2]  R2097     2.5165876746177673e-01
    z[3,4,2]  R2098     -4.6096905134618282e-03
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2025     -1
    z[3,4,3]  R2026     1
    z[3,4,3]  R2033     -4.2700907588005066e-01
    z[3,4,3]  R2034     -1.3089103996753693e-01
    z[3,4,3]  R2035     5.0435356795787811e-02
    z[3,4,3]  R2036     -1.8006978556513786e-02
    z[3,4,3]  R2037     -5.4041433334350586e-01
    z[3,4,3]  R2038     -1.6749298572540283e-01
    z[3,4,3]  R2039     2.4034446477890015e-01
    z[3,4,3]  R2040     0.312175452709198
    z[3,4,3]  R2041     -1.5765495598316193e-01
    z[3,4,3]  R2042     -4.5238324999809265e-01
    z[3,4,3]  R2043     6.0132112354040146e-02
    z[3,4,3]  R2044     -3.5726919770240784e-01
    z[3,4,3]  R2045     1.7948009073734283e-01
    z[3,4,3]  R2046     1.7335766926407814e-02
    z[3,4,3]  R2047     0.554954469203949
    z[3,4,3]  R2048     4.6995395421981812e-01
    z[3,4,3]  R2049     6.5578943490982056e-01
    z[3,4,3]  R2050     5.3399151563644409e-01
    z[3,4,3]  R2051     1.7057047784328461e-01
    z[3,4,3]  R2052     0.805041491985321
    z[3,4,3]  R2053     1.4910751581192017e-01
    z[3,4,3]  R2054     3.3688324689865112e-01
    z[3,4,3]  R2055     1.6703270375728607e-01
    z[3,4,3]  R2056     -1.6435244679450989e-01
    z[3,4,3]  R2057     -2.5326707959175110e-01
    z[3,4,3]  R2058     1.2513893842697144e-01
    z[3,4,3]  R2059     -2.2047157585620880e-01
    z[3,4,3]  R2060     -3.8990822434425354e-01
    z[3,4,3]  R2061     -2.3397500813007355e-01
    z[3,4,3]  R2062     4.9153860658407211e-02
    z[3,4,3]  R2063     -9.9736951291561127e-02
    z[3,4,3]  R2064     1.5958513319492340e-01
    z[3,4,3]  R2065     -1.8974952399730682e-02
    z[3,4,3]  R2066     -8.5029698908329010e-02
    z[3,4,3]  R2067     -7.3701471090316772e-01
    z[3,4,3]  R2068     -5.1005744934082031e-01
    z[3,4,3]  R2069     -3.5362154245376587e-01
    z[3,4,3]  R2070     -3.0872595310211182e-01
    z[3,4,3]  R2071     9.6516653895378113e-02
    z[3,4,3]  R2072     0.767477810382843
    z[3,4,3]  R2073     -5.9185636043548584e-01
    z[3,4,3]  R2074     -1.9000720977783203e-01
    z[3,4,3]  R2075     3.6175560951232910e-01
    z[3,4,3]  R2076     3.6101114749908447e-01
    z[3,4,3]  R2077     -1.9300375878810883e-01
    z[3,4,3]  R2078     2.0218791067600250e-01
    z[3,4,3]  R2079     2.9652403667569160e-02
    z[3,4,3]  R2080     7.5273603200912476e-01
    z[3,4,3]  R2081     1.7682921886444092e-01
    z[3,4,3]  R2082     -1.7934386432170868e-01
    z[3,4,3]  R2083     -2.4998681247234344e-01
    z[3,4,3]  R2084     1.4707107841968536e-01
    z[3,4,3]  R2085     -1.5856083482503891e-02
    z[3,4,3]  R2086     -4.9564335495233536e-02
    z[3,4,3]  R2087     1.7448128759860992e-01
    z[3,4,3]  R2088     1.1912860721349716e-01
    z[3,4,3]  R2089     1.2183716893196106e-01
    z[3,4,3]  R2090     6.3129603862762451e-01
    z[3,4,3]  R2091     2.3715730011463165e-01
    z[3,4,3]  R2092     -5.4982539266347885e-02
    z[3,4,3]  R2093     6.4663213491439819e-01
    z[3,4,3]  R2094     -1.8719787895679474e-01
    z[3,4,3]  R2095     7.6703488826751709e-02
    z[3,4,3]  R2096     -5.4994624853134155e-01
    z[3,4,3]  R2097     -7.2672683000564575e-01
    z[3,4,3]  R2098     -8.0413794517517090e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2027     -1
    z[3,4,4]  R2028     1
    z[3,4,4]  R2033     4.5822650194168091e-02
    z[3,4,4]  R2034     -7.5653657317161560e-02
    z[3,4,4]  R2035     -2.1640536189079285e-01
    z[3,4,4]  R2036     3.8729336112737656e-02
    z[3,4,4]  R2037     1.9678421318531036e-02
    z[3,4,4]  R2038     -5.0368376076221466e-02
    z[3,4,4]  R2039     2.0661942660808563e-01
    z[3,4,4]  R2040     -6.1629676818847656e-01
    z[3,4,4]  R2041     -1.2086541950702667e-01
    z[3,4,4]  R2042     -9.5076836645603180e-02
    z[3,4,4]  R2043     2.3639410734176636e-01
    z[3,4,4]  R2044     -2.0589524507522583e-01
    z[3,4,4]  R2045     7.2629086673259735e-02
    z[3,4,4]  R2046     -0.0833207443356514
    z[3,4,4]  R2047     -1.6864295303821564e-01
    z[3,4,4]  R2048     2.0364646613597870e-01
    z[3,4,4]  R2049     -1.3364824652671814e-01
    z[3,4,4]  R2050     -4.5083454251289368e-01
    z[3,4,4]  R2051     4.9073547124862671e-02
    z[3,4,4]  R2052     -5.7916458696126938e-02
    z[3,4,4]  R2053     -1.6701254248619080e-01
    z[3,4,4]  R2054     -2.2128391265869141e-01
    z[3,4,4]  R2055     2.5124964118003845e-01
    z[3,4,4]  R2056     3.5647621750831604e-01
    z[3,4,4]  R2057     -0.0849151685833931
    z[3,4,4]  R2058     1.7805512249469757e-01
    z[3,4,4]  R2059     5.1432031393051147e-01
    z[3,4,4]  R2060     1.7972512543201447e-01
    z[3,4,4]  R2061     -2.0716971158981323e-01
    z[3,4,4]  R2062     1.2676016986370087e-01
    z[3,4,4]  R2063     -1.0556812584400177e-01
    z[3,4,4]  R2064     -9.2531302943825722e-03
    z[3,4,4]  R2065     2.2112432122230530e-01
    z[3,4,4]  R2066     4.4771939516067505e-01
    z[3,4,4]  R2067     2.1878848969936371e-01
    z[3,4,4]  R2068     -7.0104807615280151e-02
    z[3,4,4]  R2069     2.0469594001770020e-01
    z[3,4,4]  R2070     0.0848376527428627
    z[3,4,4]  R2071     1.6652733087539673e-01
    z[3,4,4]  R2072     1.6612590849399567e-01
    z[3,4,4]  R2073     1.8307650089263916e-01
    z[3,4,4]  R2074     -2.4783807992935181e-01
    z[3,4,4]  R2075     -1.2648294866085052e-01
    z[3,4,4]  R2076     -3.7038561701774597e-01
    z[3,4,4]  R2077     2.1535834670066833e-01
    z[3,4,4]  R2078     -3.8356855511665344e-01
    z[3,4,4]  R2079     2.7675956487655640e-01
    z[3,4,4]  R2080     7.4886791408061981e-03
    z[3,4,4]  R2081     -1.6296248137950897e-01
    z[3,4,4]  R2082     -3.6126505583524704e-02
    z[3,4,4]  R2083     8.5565179586410522e-02
    z[3,4,4]  R2084     1.0250149667263031e-01
    z[3,4,4]  R2085     -7.1943426132202148e-01
    z[3,4,4]  R2086     -5.2581459283828735e-01
    z[3,4,4]  R2087     7.3818467557430267e-02
    z[3,4,4]  R2088     -3.3409276604652405e-01
    z[3,4,4]  R2089     2.5818532705307007e-01
    z[3,4,4]  R2090     -1.0727589949965477e-02
    z[3,4,4]  R2091     5.7517445087432861e-01
    z[3,4,4]  R2092     1.7057368159294128e-01
    z[3,4,4]  R2093     3.7018975615501404e-01
    z[3,4,4]  R2094     -4.3188139796257019e-01
    z[3,4,4]  R2095     -1.1991918087005615e-01
    z[3,4,4]  R2096     1.2100233882665634e-01
    z[3,4,4]  R2097     -1.7268361151218414e-01
    z[3,4,4]  R2098     -1.9243207573890686e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2029     -1
    z[3,4,5]  R2030     1
    z[3,4,5]  R2033     -2.8510031104087830e-01
    z[3,4,5]  R2034     -2.7459102869033813e-01
    z[3,4,5]  R2035     -1.7809697985649109e-01
    z[3,4,5]  R2036     -9.8730325698852539e-02
    z[3,4,5]  R2037     -3.5191348195075989e-01
    z[3,4,5]  R2038     9.1518782079219818e-02
    z[3,4,5]  R2039     2.5892412662506104e-01
    z[3,4,5]  R2040     2.5200262665748596e-01
    z[3,4,5]  R2041     1.6486391425132751e-01
    z[3,4,5]  R2042     3.9414229989051819e-01
    z[3,4,5]  R2043     3.0530977994203568e-02
    z[3,4,5]  R2044     2.5256010890007019e-01
    z[3,4,5]  R2045     6.9754086434841156e-02
    z[3,4,5]  R2046     2.7698242664337158e-01
    z[3,4,5]  R2047     -0.438755065202713
    z[3,4,5]  R2048     -3.2588756084442139e-01
    z[3,4,5]  R2049     -8.9207157492637634e-02
    z[3,4,5]  R2050     -2.6879742741584778e-01
    z[3,4,5]  R2051     -2.2403210401535034e-01
    z[3,4,5]  R2052     -1.5371562540531158e-01
    z[3,4,5]  R2053     0.49073326587677
    z[3,4,5]  R2054     5.6967481970787048e-02
    z[3,4,5]  R2055     7.2781629860401154e-02
    z[3,4,5]  R2056     3.0580663681030273e-01
    z[3,4,5]  R2057     5.1552492380142212e-01
    z[3,4,5]  R2058     -7.9626701772212982e-02
    z[3,4,5]  R2059     -1.2868297100067139e-01
    z[3,4,5]  R2060     3.3688607811927795e-01
    z[3,4,5]  R2061     5.1151913404464722e-01
    z[3,4,5]  R2062     3.6664155125617981e-01
    z[3,4,5]  R2063     0.366933673620224
    z[3,4,5]  R2064     2.4038605391979218e-01
    z[3,4,5]  R2065     -2.6346214581280947e-03
    z[3,4,5]  R2066     -8.3512723445892334e-02
    z[3,4,5]  R2067     3.2308793067932129e-01
    z[3,4,5]  R2068     -3.8913673162460327e-01
    z[3,4,5]  R2069     -4.0350112318992615e-01
    z[3,4,5]  R2070     -6.3718676567077637e-01
    z[3,4,5]  R2071     -8.0009198188781738e-01
    z[3,4,5]  R2072     -1.8298944830894470e-01
    z[3,4,5]  R2073     1.9466073717921972e-04
    z[3,4,5]  R2074     4.1467356681823730e-01
    z[3,4,5]  R2075     -4.6634575724601746e-01
    z[3,4,5]  R2076     -2.3785832524299622e-01
    z[3,4,5]  R2077     1.3878895342350006e-01
    z[3,4,5]  R2078     -1.7217348515987396e-01
    z[3,4,5]  R2079     -7.0632971823215485e-02
    z[3,4,5]  R2080     2.8447309136390686e-01
    z[3,4,5]  R2081     -0.0577826164662838
    z[3,4,5]  R2082     -3.6176130175590515e-02
    z[3,4,5]  R2083     -8.2129734754562378e-01
    z[3,4,5]  R2084     -9.1894274950027466e-01
    z[3,4,5]  R2085     -5.4655605554580688e-01
    z[3,4,5]  R2086     -1.7226213216781616e-01
    z[3,4,5]  R2087     -1.9043882191181183e-01
    z[3,4,5]  R2088     -2.8559145331382751e-01
    z[3,4,5]  R2089     3.0790126323699951e-01
    z[3,4,5]  R2090     2.2312806546688080e-01
    z[3,4,5]  R2091     3.2654333114624023e-01
    z[3,4,5]  R2092     2.8997638821601868e-01
    z[3,4,5]  R2093     -5.0029352307319641e-02
    z[3,4,5]  R2094     4.2158621549606323e-01
    z[3,4,5]  R2095     -1.1760377138853073e-01
    z[3,4,5]  R2096     2.8125956654548645e-01
    z[3,4,5]  R2097     2.9197099804878235e-01
    z[3,4,5]  R2098     2.0851273834705353e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2031     -1
    z[3,4,6]  R2032     1
    z[3,4,6]  R2033     1.8634596839547157e-02
    z[3,4,6]  R2034     6.1599975824356079e-01
    z[3,4,6]  R2035     2.8018739819526672e-01
    z[3,4,6]  R2036     3.2007377594709396e-02
    z[3,4,6]  R2037     4.5550405979156494e-01
    z[3,4,6]  R2038     5.9498608112335205e-02
    z[3,4,6]  R2039     9.0559042990207672e-02
    z[3,4,6]  R2040     1.9700525701045990e-01
    z[3,4,6]  R2041     6.8040627241134644e-01
    z[3,4,6]  R2042     4.9363193102180958e-03
    z[3,4,6]  R2043     -2.4662408232688904e-01
    z[3,4,6]  R2044     -7.3229223489761353e-02
    z[3,4,6]  R2045     5.0963556766510010e-01
    z[3,4,6]  R2046     5.3769510984420776e-01
    z[3,4,6]  R2047     1.2688353657722473e-01
    z[3,4,6]  R2048     7.3101505637168884e-02
    z[3,4,6]  R2049     9.3675171956419945e-03
    z[3,4,6]  R2050     -1.5260463953018188e-01
    z[3,4,6]  R2051     -0.163701593875885
    z[3,4,6]  R2052     1.6433374583721161e-01
    z[3,4,6]  R2053     -2.5771612301468849e-02
    z[3,4,6]  R2054     -2.8085660934448242e-01
    z[3,4,6]  R2055     2.1825022995471954e-01
    z[3,4,6]  R2056     2.3344756662845612e-01
    z[3,4,6]  R2057     2.6692020893096924e-01
    z[3,4,6]  R2058     -6.2983624637126923e-02
    z[3,4,6]  R2059     6.0644489526748657e-01
    z[3,4,6]  R2060     0.150406152009964
    z[3,4,6]  R2061     1.0031318664550781e-01
    z[3,4,6]  R2062     1.2571129016578197e-02
    z[3,4,6]  R2063     4.1141849756240845e-01
    z[3,4,6]  R2064     3.5320450551807880e-03
    z[3,4,6]  R2065     6.8976622819900513e-01
    z[3,4,6]  R2066     -1.2096484750509262e-01
    z[3,4,6]  R2067     3.9257019758224487e-01
    z[3,4,6]  R2068     1.1280041933059692e-01
    z[3,4,6]  R2069     4.1892158985137939e-01
    z[3,4,6]  R2070     5.0528898835182190e-02
    z[3,4,6]  R2071     0.161977618932724
    z[3,4,6]  R2072     3.3900722861289978e-01
    z[3,4,6]  R2073     2.2306475043296814e-01
    z[3,4,6]  R2074     3.1190004944801331e-01
    z[3,4,6]  R2075     -7.7244572341442108e-02
    z[3,4,6]  R2076     2.8067186474800110e-01
    z[3,4,6]  R2077     2.8628465533256531e-01
    z[3,4,6]  R2078     2.0274116098880768e-01
    z[3,4,6]  R2079     3.5062986612319946e-01
    z[3,4,6]  R2080     2.9905807971954346e-01
    z[3,4,6]  R2081     1.8012440204620361e-01
    z[3,4,6]  R2082     -1.4839315414428711e-01
    z[3,4,6]  R2083     1.8097130954265594e-01
    z[3,4,6]  R2084     -1.7782452702522278e-01
    z[3,4,6]  R2085     -1.4426478743553162e-01
    z[3,4,6]  R2086     -2.8533586859703064e-01
    z[3,4,6]  R2087     3.1594879925251007e-02
    z[3,4,6]  R2088     4.7426262497901917e-01
    z[3,4,6]  R2089     -3.9861583709716797e-01
    z[3,4,6]  R2090     6.9473057985305786e-02
    z[3,4,6]  R2091     2.2498293220996857e-01
    z[3,4,6]  R2092     -3.6225235089659691e-03
    z[3,4,6]  R2093     5.5946122854948044e-02
    z[3,4,6]  R2094     6.2424574047327042e-02
    z[3,4,6]  R2095     3.7235689163208008e-01
    z[3,4,6]  R2096     -0.0879029706120491
    z[3,4,6]  R2097     0.311167448759079
    z[3,4,6]  R2098     1.9222594797611237e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2099     -1
    z[4,3,0]  R2100     1
    z[4,3,0]  R2113     1.6145157814025879e-01
    z[4,3,0]  R2114     -6.0774767771363258e-03
    z[4,3,0]  R2115     2.2393876314163208e-01
    z[4,3,0]  R2116     -8.2619786262512207e-02
    z[4,3,0]  R2117     -1.9507546722888947e-01
    z[4,3,0]  R2118     -2.6520419120788574e-01
    z[4,3,0]  R2119     -3.1409361958503723e-01
    z[4,3,0]  R2120     2.3205070756375790e-03
    z[4,3,0]  R2121     3.8971800357103348e-02
    z[4,3,0]  R2122     1.1771667003631592e-01
    z[4,3,0]  R2123     -2.2602401673793793e-01
    z[4,3,0]  R2124     -7.5803823769092560e-02
    z[4,3,0]  R2125     5.8438873291015625e-01
    z[4,3,0]  R2126     -2.4338236451148987e-01
    z[4,3,0]  R2127     -3.5414078831672668e-01
    z[4,3,0]  R2128     -4.8526591062545776e-01
    z[4,3,0]  R2129     -6.0292345285415649e-01
    z[4,3,0]  R2130     -5.9713470935821533e-01
    z[4,3,0]  R2131     -7.9646384716033936e-01
    z[4,3,0]  R2132     0.593394935131073
    z[4,3,0]  R2133     -0.430400013923645
    z[4,3,0]  R2134     3.6738941073417664e-01
    z[4,3,0]  R2135     6.8841701745986938e-01
    z[4,3,0]  R2136     2.7344632148742676e-01
    z[4,3,0]  R2137     3.5563737154006958e-01
    z[4,3,0]  R2138     4.9206703901290894e-01
    z[4,3,0]  R2139     -2.8547435998916626e-01
    z[4,3,0]  R2140     -1.9855169579386711e-02
    z[4,3,0]  R2141     -7.0916842669248581e-03
    z[4,3,0]  R2142     -2.0397590473294258e-02
    z[4,3,0]  R2143     -6.5713502466678619e-02
    z[4,3,0]  R2144     3.0177175998687744e-01
    z[4,3,0]  R2145     3.8811814785003662e-01
    z[4,3,0]  R2146     -1.8501804769039154e-01
    z[4,3,0]  R2147     0.167601078748703
    z[4,3,0]  R2148     8.1268265843391418e-02
    z[4,3,0]  R2149     5.1078337430953979e-01
    z[4,3,0]  R2150     -2.2165615856647491e-01
    z[4,3,0]  R2151     7.2538322210311890e-01
    z[4,3,0]  R2152     8.0320823192596436e-01
    z[4,3,0]  R2153     5.4646110534667969e-01
    z[4,3,0]  R2154     4.4635590910911560e-01
    z[4,3,0]  R2155     5.7215999811887741e-02
    z[4,3,0]  R2156     6.9971328973770142e-01
    z[4,3,0]  R2157     0.713864803314209
    z[4,3,0]  R2158     7.7606225013732910e-01
    z[4,3,0]  R2159     -0.397827684879303
    z[4,3,0]  R2160     7.2482812404632568e-01
    z[4,3,0]  R2161     -2.4095913767814636e-01
    z[4,3,0]  R2162     0.813280463218689
    z[4,3,0]  R2163     1.3921824283897877e-02
    z[4,3,0]  R2164     6.2162774801254272e-01
    z[4,3,0]  R2165     5.1198744773864746e-01
    z[4,3,0]  R2166     6.4981174468994141e-01
    z[4,3,0]  R2167     -4.9261572957038879e-01
    z[4,3,0]  R2168     2.5793758034706116e-01
    z[4,3,0]  R2169     6.9175004959106445e-02
    z[4,3,0]  R2170     -3.7531760334968567e-01
    z[4,3,0]  R2171     -4.9100264906883240e-02
    z[4,3,0]  R2172     3.8662287592887878e-01
    z[4,3,0]  R2173     7.8889721632003784e-01
    z[4,3,0]  R2174     -3.9210504293441772e-01
    z[4,3,0]  R2175     7.3289644718170166e-01
    z[4,3,0]  R2176     1.8111538887023926e-01
    z[4,3,0]  R2177     -3.0878129601478577e-01
    z[4,3,0]  R2178     -3.5077667236328125e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2101     -1
    z[4,3,1]  R2102     1
    z[4,3,1]  R2113     -4.3822664022445679e-01
    z[4,3,1]  R2114     1.4301015995442867e-02
    z[4,3,1]  R2115     -2.1769827604293823e-01
    z[4,3,1]  R2116     7.4809336662292480e-01
    z[4,3,1]  R2117     9.2499506473541260e-01
    z[4,3,1]  R2118     4.7634577751159668e-01
    z[4,3,1]  R2119     -5.9345757961273193e-01
    z[4,3,1]  R2120     -0.64082932472229
    z[4,3,1]  R2121     -1.9719904661178589e-01
    z[4,3,1]  R2122     -1.3739171624183655e-01
    z[4,3,1]  R2123     -5.8837819099426270e-01
    z[4,3,1]  R2124     -4.8108461499214172e-01
    z[4,3,1]  R2125     0.478423148393631
    z[4,3,1]  R2126     -3.0948597192764282e-01
    z[4,3,1]  R2127     -2.6688629388809204e-01
    z[4,3,1]  R2128     -1.9983960315585136e-02
    z[4,3,1]  R2129     -4.9979650974273682e-01
    z[4,3,1]  R2130     -3.7981674075126648e-01
    z[4,3,1]  R2131     -2.0791263878345490e-01
    z[4,3,1]  R2132     3.7678810954093933e-01
    z[4,3,1]  R2133     -4.3685835599899292e-01
    z[4,3,1]  R2134     7.3186588287353516e-01
    z[4,3,1]  R2135     5.6335467100143433e-01
    z[4,3,1]  R2136     -5.8704257011413574e-01
    z[4,3,1]  R2137     2.5529748201370239e-01
    z[4,3,1]  R2138     -3.0720129609107971e-01
    z[4,3,1]  R2139     -4.9055501818656921e-01
    z[4,3,1]  R2140     -8.5490924119949341e-01
    z[4,3,1]  R2141     -7.7586907148361206e-01
    z[4,3,1]  R2142     -7.6240330934524536e-01
    z[4,3,1]  R2143     -6.7092359066009521e-01
    z[4,3,1]  R2144     -0.72418612241745
    z[4,3,1]  R2145     -6.1174947023391724e-01
    z[4,3,1]  R2146     -6.1788523197174072e-01
    z[4,3,1]  R2147     -9.1981792449951172e-01
    z[4,3,1]  R2148     -5.2808022499084473e-01
    z[4,3,1]  R2149     5.4192101955413818e-01
    z[4,3,1]  R2150     -8.2055938243865967e-01
    z[4,3,1]  R2151     4.7175922989845276e-01
    z[4,3,1]  R2152     1.1841738224029541e-01
    z[4,3,1]  R2153     2.9551774263381958e-01
    z[4,3,1]  R2154     0.809660017490387
    z[4,3,1]  R2155     -2.1381278336048126e-01
    z[4,3,1]  R2156     -1.8627347052097321e-01
    z[4,3,1]  R2157     0.00829958077520132
    z[4,3,1]  R2158     -3.7942326068878174e-01
    z[4,3,1]  R2159     -4.5845040678977966e-01
    z[4,3,1]  R2160     2.7378877997398376e-01
    z[4,3,1]  R2161     -2.6002889871597290e-01
    z[4,3,1]  R2162     -3.5557288210839033e-03
    z[4,3,1]  R2163     -2.9835966229438782e-01
    z[4,3,1]  R2164     -3.6772534251213074e-01
    z[4,3,1]  R2165     -4.3924498558044434e-01
    z[4,3,1]  R2166     -2.4902668595314026e-01
    z[4,3,1]  R2167     1.4090338349342346e-01
    z[4,3,1]  R2168     3.8887679576873779e-01
    z[4,3,1]  R2169     -7.4931782484054565e-01
    z[4,3,1]  R2170     -0.632306694984436
    z[4,3,1]  R2171     -7.8275579214096069e-01
    z[4,3,1]  R2172     -6.6907012462615967e-01
    z[4,3,1]  R2173     -2.8633108735084534e-01
    z[4,3,1]  R2174     -0.757557213306427
    z[4,3,1]  R2175     -3.0009558796882629e-01
    z[4,3,1]  R2176     3.3315002918243408e-01
    z[4,3,1]  R2177     8.9879298210144043e-01
    z[4,3,1]  R2178     8.9376252889633179e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2103     -1
    z[4,3,2]  R2104     1
    z[4,3,2]  R2113     -6.9253191351890564e-02
    z[4,3,2]  R2114     -3.0256372690200806e-01
    z[4,3,2]  R2115     -2.5511956214904785e-01
    z[4,3,2]  R2116     2.0857103168964386e-01
    z[4,3,2]  R2117     1.8213124573230743e-01
    z[4,3,2]  R2118     5.2006185054779053e-01
    z[4,3,2]  R2119     -4.6254900097846985e-01
    z[4,3,2]  R2120     -3.6887651681900024e-01
    z[4,3,2]  R2121     -6.4441967010498047e-01
    z[4,3,2]  R2122     -0.922522783279419
    z[4,3,2]  R2123     2.0473857223987579e-01
    z[4,3,2]  R2124     5.9967929124832153e-01
    z[4,3,2]  R2125     5.0681042671203613e-01
    z[4,3,2]  R2126     0.664128839969635
    z[4,3,2]  R2127     2.5165876746177673e-01
    z[4,3,2]  R2128     -4.6096905134618282e-03
    z[4,3,2]  R2129     -3.4730517864227295e-01
    z[4,3,2]  R2130     -1.4648345112800598e-01
    z[4,3,2]  R2131     -4.0350863337516785e-01
    z[4,3,2]  R2132     7.0236515998840332e-01
    z[4,3,2]  R2133     -1.2193604372441769e-02
    z[4,3,2]  R2134     5.3562176227569580e-01
    z[4,3,2]  R2135     1.8169675767421722e-01
    z[4,3,2]  R2136     -3.1884562224149704e-02
    z[4,3,2]  R2137     5.2796679735183716e-01
    z[4,3,2]  R2138     5.4261833429336548e-01
    z[4,3,2]  R2139     -7.4606072902679443e-01
    z[4,3,2]  R2140     1.7190891504287720e-01
    z[4,3,2]  R2141     -3.0966898798942566e-01
    z[4,3,2]  R2142     2.1271331608295441e-01
    z[4,3,2]  R2143     2.2867359220981598e-02
    z[4,3,2]  R2144     -1.0302006453275681e-01
    z[4,3,2]  R2145     -1.3841852545738220e-01
    z[4,3,2]  R2146     6.8635516799986362e-03
    z[4,3,2]  R2147     1.3173352181911469e-01
    z[4,3,2]  R2148     -1.1156410723924637e-01
    z[4,3,2]  R2149     3.9218932390213013e-01
    z[4,3,2]  R2150     -1.8157172203063965e-01
    z[4,3,2]  R2151     3.2757565379142761e-01
    z[4,3,2]  R2152     1.9680313766002655e-01
    z[4,3,2]  R2153     4.5352223515510559e-01
    z[4,3,2]  R2154     2.9588249325752258e-01
    z[4,3,2]  R2155     -5.0353008508682251e-01
    z[4,3,2]  R2156     3.9402994513511658e-01
    z[4,3,2]  R2157     3.4777870774269104e-01
    z[4,3,2]  R2158     3.1732836365699768e-01
    z[4,3,2]  R2159     -5.5367767810821533e-01
    z[4,3,2]  R2160     5.6241697072982788e-01
    z[4,3,2]  R2161     -5.9100198745727539e-01
    z[4,3,2]  R2162     3.3056426048278809e-01
    z[4,3,2]  R2163     -2.4744980037212372e-01
    z[4,3,2]  R2164     2.2165837883949280e-01
    z[4,3,2]  R2165     1.9918750226497650e-01
    z[4,3,2]  R2166     0.0682726576924324
    z[4,3,2]  R2167     -1.8451346457004547e-01
    z[4,3,2]  R2168     -1.3119451701641083e-01
    z[4,3,2]  R2169     1.2991547584533691e-02
    z[4,3,2]  R2170     -3.0424109101295471e-01
    z[4,3,2]  R2171     1.2071663886308670e-01
    z[4,3,2]  R2172     -3.4740817500278354e-04
    z[4,3,2]  R2173     3.3287355303764343e-01
    z[4,3,2]  R2174     1.1665407568216324e-01
    z[4,3,2]  R2175     4.0914547443389893e-01
    z[4,3,2]  R2176     -3.4522455930709839e-01
    z[4,3,2]  R2177     -5.6712850928306580e-02
    z[4,3,2]  R2178     -1.4610143005847931e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2105     -1
    z[4,3,3]  R2106     1
    z[4,3,3]  R2113     -2.4998681247234344e-01
    z[4,3,3]  R2114     1.4707107841968536e-01
    z[4,3,3]  R2115     -1.5856083482503891e-02
    z[4,3,3]  R2116     -4.9564335495233536e-02
    z[4,3,3]  R2117     1.7448128759860992e-01
    z[4,3,3]  R2118     1.1912860721349716e-01
    z[4,3,3]  R2119     1.2183716893196106e-01
    z[4,3,3]  R2120     6.3129603862762451e-01
    z[4,3,3]  R2121     2.3715730011463165e-01
    z[4,3,3]  R2122     -5.4982539266347885e-02
    z[4,3,3]  R2123     6.4663213491439819e-01
    z[4,3,3]  R2124     -1.8719787895679474e-01
    z[4,3,3]  R2125     7.6703488826751709e-02
    z[4,3,3]  R2126     -5.4994624853134155e-01
    z[4,3,3]  R2127     -7.2672683000564575e-01
    z[4,3,3]  R2128     -8.0413794517517090e-01
    z[4,3,3]  R2129     -4.2700907588005066e-01
    z[4,3,3]  R2130     -1.3089103996753693e-01
    z[4,3,3]  R2131     5.0435356795787811e-02
    z[4,3,3]  R2132     -1.8006978556513786e-02
    z[4,3,3]  R2133     -5.4041433334350586e-01
    z[4,3,3]  R2134     -1.6749298572540283e-01
    z[4,3,3]  R2135     2.4034446477890015e-01
    z[4,3,3]  R2136     0.312175452709198
    z[4,3,3]  R2137     -1.5765495598316193e-01
    z[4,3,3]  R2138     -4.5238324999809265e-01
    z[4,3,3]  R2139     6.0132112354040146e-02
    z[4,3,3]  R2140     -3.5726919770240784e-01
    z[4,3,3]  R2141     1.7948009073734283e-01
    z[4,3,3]  R2142     1.7335766926407814e-02
    z[4,3,3]  R2143     0.554954469203949
    z[4,3,3]  R2144     4.6995395421981812e-01
    z[4,3,3]  R2145     6.5578943490982056e-01
    z[4,3,3]  R2146     5.3399151563644409e-01
    z[4,3,3]  R2147     1.7057047784328461e-01
    z[4,3,3]  R2148     0.805041491985321
    z[4,3,3]  R2149     1.4910751581192017e-01
    z[4,3,3]  R2150     3.3688324689865112e-01
    z[4,3,3]  R2151     1.6703270375728607e-01
    z[4,3,3]  R2152     -1.6435244679450989e-01
    z[4,3,3]  R2153     -2.5326707959175110e-01
    z[4,3,3]  R2154     1.2513893842697144e-01
    z[4,3,3]  R2155     -2.2047157585620880e-01
    z[4,3,3]  R2156     -3.8990822434425354e-01
    z[4,3,3]  R2157     -2.3397500813007355e-01
    z[4,3,3]  R2158     4.9153860658407211e-02
    z[4,3,3]  R2159     -9.9736951291561127e-02
    z[4,3,3]  R2160     1.5958513319492340e-01
    z[4,3,3]  R2161     -1.8974952399730682e-02
    z[4,3,3]  R2162     -8.5029698908329010e-02
    z[4,3,3]  R2163     -7.3701471090316772e-01
    z[4,3,3]  R2164     -5.1005744934082031e-01
    z[4,3,3]  R2165     -3.5362154245376587e-01
    z[4,3,3]  R2166     -3.0872595310211182e-01
    z[4,3,3]  R2167     9.6516653895378113e-02
    z[4,3,3]  R2168     0.767477810382843
    z[4,3,3]  R2169     -5.9185636043548584e-01
    z[4,3,3]  R2170     -1.9000720977783203e-01
    z[4,3,3]  R2171     3.6175560951232910e-01
    z[4,3,3]  R2172     3.6101114749908447e-01
    z[4,3,3]  R2173     -1.9300375878810883e-01
    z[4,3,3]  R2174     2.0218791067600250e-01
    z[4,3,3]  R2175     2.9652403667569160e-02
    z[4,3,3]  R2176     7.5273603200912476e-01
    z[4,3,3]  R2177     1.7682921886444092e-01
    z[4,3,3]  R2178     -1.7934386432170868e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2107     -1
    z[4,3,4]  R2108     1
    z[4,3,4]  R2113     8.5565179586410522e-02
    z[4,3,4]  R2114     1.0250149667263031e-01
    z[4,3,4]  R2115     -7.1943426132202148e-01
    z[4,3,4]  R2116     -5.2581459283828735e-01
    z[4,3,4]  R2117     7.3818467557430267e-02
    z[4,3,4]  R2118     -3.3409276604652405e-01
    z[4,3,4]  R2119     2.5818532705307007e-01
    z[4,3,4]  R2120     -1.0727589949965477e-02
    z[4,3,4]  R2121     5.7517445087432861e-01
    z[4,3,4]  R2122     1.7057368159294128e-01
    z[4,3,4]  R2123     3.7018975615501404e-01
    z[4,3,4]  R2124     -4.3188139796257019e-01
    z[4,3,4]  R2125     -1.1991918087005615e-01
    z[4,3,4]  R2126     1.2100233882665634e-01
    z[4,3,4]  R2127     -1.7268361151218414e-01
    z[4,3,4]  R2128     -1.9243207573890686e-01
    z[4,3,4]  R2129     4.5822650194168091e-02
    z[4,3,4]  R2130     -7.5653657317161560e-02
    z[4,3,4]  R2131     -2.1640536189079285e-01
    z[4,3,4]  R2132     3.8729336112737656e-02
    z[4,3,4]  R2133     1.9678421318531036e-02
    z[4,3,4]  R2134     -5.0368376076221466e-02
    z[4,3,4]  R2135     2.0661942660808563e-01
    z[4,3,4]  R2136     -6.1629676818847656e-01
    z[4,3,4]  R2137     -1.2086541950702667e-01
    z[4,3,4]  R2138     -9.5076836645603180e-02
    z[4,3,4]  R2139     2.3639410734176636e-01
    z[4,3,4]  R2140     -2.0589524507522583e-01
    z[4,3,4]  R2141     7.2629086673259735e-02
    z[4,3,4]  R2142     -0.0833207443356514
    z[4,3,4]  R2143     -1.6864295303821564e-01
    z[4,3,4]  R2144     2.0364646613597870e-01
    z[4,3,4]  R2145     -1.3364824652671814e-01
    z[4,3,4]  R2146     -4.5083454251289368e-01
    z[4,3,4]  R2147     4.9073547124862671e-02
    z[4,3,4]  R2148     -5.7916458696126938e-02
    z[4,3,4]  R2149     -1.6701254248619080e-01
    z[4,3,4]  R2150     -2.2128391265869141e-01
    z[4,3,4]  R2151     2.5124964118003845e-01
    z[4,3,4]  R2152     3.5647621750831604e-01
    z[4,3,4]  R2153     -0.0849151685833931
    z[4,3,4]  R2154     1.7805512249469757e-01
    z[4,3,4]  R2155     5.1432031393051147e-01
    z[4,3,4]  R2156     1.7972512543201447e-01
    z[4,3,4]  R2157     -2.0716971158981323e-01
    z[4,3,4]  R2158     1.2676016986370087e-01
    z[4,3,4]  R2159     -1.0556812584400177e-01
    z[4,3,4]  R2160     -9.2531302943825722e-03
    z[4,3,4]  R2161     2.2112432122230530e-01
    z[4,3,4]  R2162     4.4771939516067505e-01
    z[4,3,4]  R2163     2.1878848969936371e-01
    z[4,3,4]  R2164     -7.0104807615280151e-02
    z[4,3,4]  R2165     2.0469594001770020e-01
    z[4,3,4]  R2166     0.0848376527428627
    z[4,3,4]  R2167     1.6652733087539673e-01
    z[4,3,4]  R2168     1.6612590849399567e-01
    z[4,3,4]  R2169     1.8307650089263916e-01
    z[4,3,4]  R2170     -2.4783807992935181e-01
    z[4,3,4]  R2171     -1.2648294866085052e-01
    z[4,3,4]  R2172     -3.7038561701774597e-01
    z[4,3,4]  R2173     2.1535834670066833e-01
    z[4,3,4]  R2174     -3.8356855511665344e-01
    z[4,3,4]  R2175     2.7675956487655640e-01
    z[4,3,4]  R2176     7.4886791408061981e-03
    z[4,3,4]  R2177     -1.6296248137950897e-01
    z[4,3,4]  R2178     -3.6126505583524704e-02
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2109     -1
    z[4,3,5]  R2110     1
    z[4,3,5]  R2113     -8.2129734754562378e-01
    z[4,3,5]  R2114     -9.1894274950027466e-01
    z[4,3,5]  R2115     -5.4655605554580688e-01
    z[4,3,5]  R2116     -1.7226213216781616e-01
    z[4,3,5]  R2117     -1.9043882191181183e-01
    z[4,3,5]  R2118     -2.8559145331382751e-01
    z[4,3,5]  R2119     3.0790126323699951e-01
    z[4,3,5]  R2120     2.2312806546688080e-01
    z[4,3,5]  R2121     3.2654333114624023e-01
    z[4,3,5]  R2122     2.8997638821601868e-01
    z[4,3,5]  R2123     -5.0029352307319641e-02
    z[4,3,5]  R2124     4.2158621549606323e-01
    z[4,3,5]  R2125     -1.1760377138853073e-01
    z[4,3,5]  R2126     2.8125956654548645e-01
    z[4,3,5]  R2127     2.9197099804878235e-01
    z[4,3,5]  R2128     2.0851273834705353e-01
    z[4,3,5]  R2129     -2.8510031104087830e-01
    z[4,3,5]  R2130     -2.7459102869033813e-01
    z[4,3,5]  R2131     -1.7809697985649109e-01
    z[4,3,5]  R2132     -9.8730325698852539e-02
    z[4,3,5]  R2133     -3.5191348195075989e-01
    z[4,3,5]  R2134     9.1518782079219818e-02
    z[4,3,5]  R2135     2.5892412662506104e-01
    z[4,3,5]  R2136     2.5200262665748596e-01
    z[4,3,5]  R2137     1.6486391425132751e-01
    z[4,3,5]  R2138     3.9414229989051819e-01
    z[4,3,5]  R2139     3.0530977994203568e-02
    z[4,3,5]  R2140     2.5256010890007019e-01
    z[4,3,5]  R2141     6.9754086434841156e-02
    z[4,3,5]  R2142     2.7698242664337158e-01
    z[4,3,5]  R2143     -0.438755065202713
    z[4,3,5]  R2144     -3.2588756084442139e-01
    z[4,3,5]  R2145     -8.9207157492637634e-02
    z[4,3,5]  R2146     -2.6879742741584778e-01
    z[4,3,5]  R2147     -2.2403210401535034e-01
    z[4,3,5]  R2148     -1.5371562540531158e-01
    z[4,3,5]  R2149     0.49073326587677
    z[4,3,5]  R2150     5.6967481970787048e-02
    z[4,3,5]  R2151     7.2781629860401154e-02
    z[4,3,5]  R2152     3.0580663681030273e-01
    z[4,3,5]  R2153     5.1552492380142212e-01
    z[4,3,5]  R2154     -7.9626701772212982e-02
    z[4,3,5]  R2155     -1.2868297100067139e-01
    z[4,3,5]  R2156     3.3688607811927795e-01
    z[4,3,5]  R2157     5.1151913404464722e-01
    z[4,3,5]  R2158     3.6664155125617981e-01
    z[4,3,5]  R2159     0.366933673620224
    z[4,3,5]  R2160     2.4038605391979218e-01
    z[4,3,5]  R2161     -2.6346214581280947e-03
    z[4,3,5]  R2162     -8.3512723445892334e-02
    z[4,3,5]  R2163     3.2308793067932129e-01
    z[4,3,5]  R2164     -3.8913673162460327e-01
    z[4,3,5]  R2165     -4.0350112318992615e-01
    z[4,3,5]  R2166     -6.3718676567077637e-01
    z[4,3,5]  R2167     -8.0009198188781738e-01
    z[4,3,5]  R2168     -1.8298944830894470e-01
    z[4,3,5]  R2169     1.9466073717921972e-04
    z[4,3,5]  R2170     4.1467356681823730e-01
    z[4,3,5]  R2171     -4.6634575724601746e-01
    z[4,3,5]  R2172     -2.3785832524299622e-01
    z[4,3,5]  R2173     1.3878895342350006e-01
    z[4,3,5]  R2174     -1.7217348515987396e-01
    z[4,3,5]  R2175     -7.0632971823215485e-02
    z[4,3,5]  R2176     2.8447309136390686e-01
    z[4,3,5]  R2177     -0.0577826164662838
    z[4,3,5]  R2178     -3.6176130175590515e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2111     -1
    z[4,3,6]  R2112     1
    z[4,3,6]  R2113     1.8097130954265594e-01
    z[4,3,6]  R2114     -1.7782452702522278e-01
    z[4,3,6]  R2115     -1.4426478743553162e-01
    z[4,3,6]  R2116     -2.8533586859703064e-01
    z[4,3,6]  R2117     3.1594879925251007e-02
    z[4,3,6]  R2118     4.7426262497901917e-01
    z[4,3,6]  R2119     -3.9861583709716797e-01
    z[4,3,6]  R2120     6.9473057985305786e-02
    z[4,3,6]  R2121     2.2498293220996857e-01
    z[4,3,6]  R2122     -3.6225235089659691e-03
    z[4,3,6]  R2123     5.5946122854948044e-02
    z[4,3,6]  R2124     6.2424574047327042e-02
    z[4,3,6]  R2125     3.7235689163208008e-01
    z[4,3,6]  R2126     -0.0879029706120491
    z[4,3,6]  R2127     0.311167448759079
    z[4,3,6]  R2128     1.9222594797611237e-01
    z[4,3,6]  R2129     1.8634596839547157e-02
    z[4,3,6]  R2130     6.1599975824356079e-01
    z[4,3,6]  R2131     2.8018739819526672e-01
    z[4,3,6]  R2132     3.2007377594709396e-02
    z[4,3,6]  R2133     4.5550405979156494e-01
    z[4,3,6]  R2134     5.9498608112335205e-02
    z[4,3,6]  R2135     9.0559042990207672e-02
    z[4,3,6]  R2136     1.9700525701045990e-01
    z[4,3,6]  R2137     6.8040627241134644e-01
    z[4,3,6]  R2138     4.9363193102180958e-03
    z[4,3,6]  R2139     -2.4662408232688904e-01
    z[4,3,6]  R2140     -7.3229223489761353e-02
    z[4,3,6]  R2141     5.0963556766510010e-01
    z[4,3,6]  R2142     5.3769510984420776e-01
    z[4,3,6]  R2143     1.2688353657722473e-01
    z[4,3,6]  R2144     7.3101505637168884e-02
    z[4,3,6]  R2145     9.3675171956419945e-03
    z[4,3,6]  R2146     -1.5260463953018188e-01
    z[4,3,6]  R2147     -0.163701593875885
    z[4,3,6]  R2148     1.6433374583721161e-01
    z[4,3,6]  R2149     -2.5771612301468849e-02
    z[4,3,6]  R2150     -2.8085660934448242e-01
    z[4,3,6]  R2151     2.1825022995471954e-01
    z[4,3,6]  R2152     2.3344756662845612e-01
    z[4,3,6]  R2153     2.6692020893096924e-01
    z[4,3,6]  R2154     -6.2983624637126923e-02
    z[4,3,6]  R2155     6.0644489526748657e-01
    z[4,3,6]  R2156     0.150406152009964
    z[4,3,6]  R2157     1.0031318664550781e-01
    z[4,3,6]  R2158     1.2571129016578197e-02
    z[4,3,6]  R2159     4.1141849756240845e-01
    z[4,3,6]  R2160     3.5320450551807880e-03
    z[4,3,6]  R2161     6.8976622819900513e-01
    z[4,3,6]  R2162     -1.2096484750509262e-01
    z[4,3,6]  R2163     3.9257019758224487e-01
    z[4,3,6]  R2164     1.1280041933059692e-01
    z[4,3,6]  R2165     4.1892158985137939e-01
    z[4,3,6]  R2166     5.0528898835182190e-02
    z[4,3,6]  R2167     0.161977618932724
    z[4,3,6]  R2168     3.3900722861289978e-01
    z[4,3,6]  R2169     2.2306475043296814e-01
    z[4,3,6]  R2170     3.1190004944801331e-01
    z[4,3,6]  R2171     -7.7244572341442108e-02
    z[4,3,6]  R2172     2.8067186474800110e-01
    z[4,3,6]  R2173     2.8628465533256531e-01
    z[4,3,6]  R2174     2.0274116098880768e-01
    z[4,3,6]  R2175     3.5062986612319946e-01
    z[4,3,6]  R2176     2.9905807971954346e-01
    z[4,3,6]  R2177     1.8012440204620361e-01
    z[4,3,6]  R2178     -1.4839315414428711e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2243     -1
    z[4,5,0]  R2244     1
    z[4,5,0]  R2257     1.6145157814025879e-01
    z[4,5,0]  R2258     -6.0774767771363258e-03
    z[4,5,0]  R2259     2.2393876314163208e-01
    z[4,5,0]  R2260     -8.2619786262512207e-02
    z[4,5,0]  R2261     -1.9507546722888947e-01
    z[4,5,0]  R2262     -2.6520419120788574e-01
    z[4,5,0]  R2263     -3.1409361958503723e-01
    z[4,5,0]  R2264     2.3205070756375790e-03
    z[4,5,0]  R2265     3.8971800357103348e-02
    z[4,5,0]  R2266     1.1771667003631592e-01
    z[4,5,0]  R2267     -2.2602401673793793e-01
    z[4,5,0]  R2268     -7.5803823769092560e-02
    z[4,5,0]  R2269     5.8438873291015625e-01
    z[4,5,0]  R2270     -2.4338236451148987e-01
    z[4,5,0]  R2271     -3.5414078831672668e-01
    z[4,5,0]  R2272     -4.8526591062545776e-01
    z[4,5,0]  R2273     3.0187436938285828e-01
    z[4,5,0]  R2274     1.7252075672149658e-01
    z[4,5,0]  R2275     5.6933969259262085e-01
    z[4,5,0]  R2276     4.8623824119567871e-01
    z[4,5,0]  R2277     7.0192024111747742e-02
    z[4,5,0]  R2278     -0.515808641910553
    z[4,5,0]  R2279     -7.7421814203262329e-01
    z[4,5,0]  R2280     -7.2666066884994507e-01
    z[4,5,0]  R2281     -6.8753719329833984e-01
    z[4,5,0]  R2282     -8.2020163536071777e-01
    z[4,5,0]  R2283     -7.3201900720596313e-01
    z[4,5,0]  R2284     -6.6962039470672607e-01
    z[4,5,0]  R2285     -7.2000789642333984e-01
    z[4,5,0]  R2286     -6.6059869527816772e-01
    z[4,5,0]  R2287     -6.0361480712890625e-01
    z[4,5,0]  R2288     5.0988274812698364e-01
    z[4,5,0]  R2289     -3.1249552965164185e-01
    z[4,5,0]  R2290     -3.3379566669464111e-01
    z[4,5,0]  R2291     -4.5933774113655090e-01
    z[4,5,0]  R2292     -5.1589739322662354e-01
    z[4,5,0]  R2293     -3.5599014163017273e-01
    z[4,5,0]  R2294     -2.8960227966308594e-01
    z[4,5,0]  R2295     -5.7515543699264526e-01
    z[4,5,0]  R2296     -4.1426292061805725e-01
    z[4,5,0]  R2297     -3.2901623845100403e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2245     -1
    z[4,5,1]  R2246     1
    z[4,5,1]  R2257     -4.3822664022445679e-01
    z[4,5,1]  R2258     1.4301015995442867e-02
    z[4,5,1]  R2259     -2.1769827604293823e-01
    z[4,5,1]  R2260     7.4809336662292480e-01
    z[4,5,1]  R2261     9.2499506473541260e-01
    z[4,5,1]  R2262     4.7634577751159668e-01
    z[4,5,1]  R2263     -5.9345757961273193e-01
    z[4,5,1]  R2264     -0.64082932472229
    z[4,5,1]  R2265     -1.9719904661178589e-01
    z[4,5,1]  R2266     -1.3739171624183655e-01
    z[4,5,1]  R2267     -5.8837819099426270e-01
    z[4,5,1]  R2268     -4.8108461499214172e-01
    z[4,5,1]  R2269     0.478423148393631
    z[4,5,1]  R2270     -3.0948597192764282e-01
    z[4,5,1]  R2271     -2.6688629388809204e-01
    z[4,5,1]  R2272     -1.9983960315585136e-02
    z[4,5,1]  R2273     3.5130563378334045e-01
    z[4,5,1]  R2274     0.533920407295227
    z[4,5,1]  R2275     -2.9374182224273682e-01
    z[4,5,1]  R2276     -2.1514658629894257e-01
    z[4,5,1]  R2277     -8.2180780172348022e-01
    z[4,5,1]  R2278     5.8445432223379612e-03
    z[4,5,1]  R2279     1.4068324863910675e-01
    z[4,5,1]  R2280     7.3817779775708914e-04
    z[4,5,1]  R2281     1.3491672277450562e-01
    z[4,5,1]  R2282     -6.0320448130369186e-02
    z[4,5,1]  R2283     1.4563761651515961e-01
    z[4,5,1]  R2284     -1.0970515012741089e-01
    z[4,5,1]  R2285     -9.2762567102909088e-02
    z[4,5,1]  R2286     -1.0863159596920013e-01
    z[4,5,1]  R2287     -1.7153373360633850e-01
    z[4,5,1]  R2288     -0.0805494487285614
    z[4,5,1]  R2289     -9.0810102224349976e-01
    z[4,5,1]  R2290     -0.869015097618103
    z[4,5,1]  R2291     -8.6112791299819946e-01
    z[4,5,1]  R2292     -8.1934183835983276e-01
    z[4,5,1]  R2293     -8.2074803113937378e-01
    z[4,5,1]  R2294     -8.6880356073379517e-01
    z[4,5,1]  R2295     -0.808609127998352
    z[4,5,1]  R2296     -0.849862277507782
    z[4,5,1]  R2297     -8.1476384401321411e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2247     -1
    z[4,5,2]  R2248     1
    z[4,5,2]  R2257     -6.9253191351890564e-02
    z[4,5,2]  R2258     -3.0256372690200806e-01
    z[4,5,2]  R2259     -2.5511956214904785e-01
    z[4,5,2]  R2260     2.0857103168964386e-01
    z[4,5,2]  R2261     1.8213124573230743e-01
    z[4,5,2]  R2262     5.2006185054779053e-01
    z[4,5,2]  R2263     -4.6254900097846985e-01
    z[4,5,2]  R2264     -3.6887651681900024e-01
    z[4,5,2]  R2265     -6.4441967010498047e-01
    z[4,5,2]  R2266     -0.922522783279419
    z[4,5,2]  R2267     2.0473857223987579e-01
    z[4,5,2]  R2268     5.9967929124832153e-01
    z[4,5,2]  R2269     5.0681042671203613e-01
    z[4,5,2]  R2270     0.664128839969635
    z[4,5,2]  R2271     2.5165876746177673e-01
    z[4,5,2]  R2272     -4.6096905134618282e-03
    z[4,5,2]  R2273     7.0917874574661255e-01
    z[4,5,2]  R2274     2.5928530097007751e-01
    z[4,5,2]  R2275     3.1012037396430969e-01
    z[4,5,2]  R2276     -3.2536625862121582e-02
    z[4,5,2]  R2277     -3.9016953110694885e-01
    z[4,5,2]  R2278     -6.8645989894866943e-01
    z[4,5,2]  R2279     -4.4923231005668640e-01
    z[4,5,2]  R2280     -3.8668170571327209e-01
    z[4,5,2]  R2281     -5.1158332824707031e-01
    z[4,5,2]  R2282     -4.4767141342163086e-01
    z[4,5,2]  R2283     -4.2879101634025574e-01
    z[4,5,2]  R2284     -4.6130201220512390e-01
    z[4,5,2]  R2285     -5.1986885070800781e-01
    z[4,5,2]  R2286     -5.7390749454498291e-01
    z[4,5,2]  R2287     -3.1425091624259949e-01
    z[4,5,2]  R2288     1.3133190572261810e-02
    z[4,5,2]  R2289     5.4675798863172531e-02
    z[4,5,2]  R2290     1.2007483094930649e-01
    z[4,5,2]  R2291     7.4041627347469330e-02
    z[4,5,2]  R2292     8.9316859841346741e-02
    z[4,5,2]  R2293     0.255808025598526
    z[4,5,2]  R2294     2.0567758381366730e-01
    z[4,5,2]  R2295     2.1160072647035122e-03
    z[4,5,2]  R2296     -2.2815535962581635e-01
    z[4,5,2]  R2297     3.6205747723579407e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2249     -1
    z[4,5,3]  R2250     1
    z[4,5,3]  R2257     -2.4998681247234344e-01
    z[4,5,3]  R2258     1.4707107841968536e-01
    z[4,5,3]  R2259     -1.5856083482503891e-02
    z[4,5,3]  R2260     -4.9564335495233536e-02
    z[4,5,3]  R2261     1.7448128759860992e-01
    z[4,5,3]  R2262     1.1912860721349716e-01
    z[4,5,3]  R2263     1.2183716893196106e-01
    z[4,5,3]  R2264     6.3129603862762451e-01
    z[4,5,3]  R2265     2.3715730011463165e-01
    z[4,5,3]  R2266     -5.4982539266347885e-02
    z[4,5,3]  R2267     6.4663213491439819e-01
    z[4,5,3]  R2268     -1.8719787895679474e-01
    z[4,5,3]  R2269     7.6703488826751709e-02
    z[4,5,3]  R2270     -5.4994624853134155e-01
    z[4,5,3]  R2271     -7.2672683000564575e-01
    z[4,5,3]  R2272     -8.0413794517517090e-01
    z[4,5,3]  R2273     1.1797262728214264e-01
    z[4,5,3]  R2274     -1.8861134350299835e-01
    z[4,5,3]  R2275     -3.9001864194869995e-01
    z[4,5,3]  R2276     -1.2386147864162922e-02
    z[4,5,3]  R2277     9.1523475944995880e-02
    z[4,5,3]  R2278     -4.4778978824615479e-01
    z[4,5,3]  R2279     -2.2499673068523407e-01
    z[4,5,3]  R2280     -3.6721962690353394e-01
    z[4,5,3]  R2281     -3.1424438953399658e-01
    z[4,5,3]  R2282     -2.8693222999572754e-01
    z[4,5,3]  R2283     -2.1840566396713257e-01
    z[4,5,3]  R2284     -4.9941259622573853e-01
    z[4,5,3]  R2285     -1.5288800001144409e-01
    z[4,5,3]  R2286     -1.9498866796493530e-01
    z[4,5,3]  R2287     -6.9235080480575562e-01
    z[4,5,3]  R2288     3.9728403091430664e-01
    z[4,5,3]  R2289     1.4180057682096958e-02
    z[4,5,3]  R2290     2.6352667808532715e-01
    z[4,5,3]  R2291     1.4667358994483948e-01
    z[4,5,3]  R2292     -9.8329484462738037e-02
    z[4,5,3]  R2293     3.1888020038604736e-01
    z[4,5,3]  R2294     -9.0936720371246338e-02
    z[4,5,3]  R2295     -1.0214445739984512e-01
    z[4,5,3]  R2296     -7.7040627598762512e-02
    z[4,5,3]  R2297     -0.0776321142911911
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2251     -1
    z[4,5,4]  R2252     1
    z[4,5,4]  R2257     8.5565179586410522e-02
    z[4,5,4]  R2258     1.0250149667263031e-01
    z[4,5,4]  R2259     -7.1943426132202148e-01
    z[4,5,4]  R2260     -5.2581459283828735e-01
    z[4,5,4]  R2261     7.3818467557430267e-02
    z[4,5,4]  R2262     -3.3409276604652405e-01
    z[4,5,4]  R2263     2.5818532705307007e-01
    z[4,5,4]  R2264     -1.0727589949965477e-02
    z[4,5,4]  R2265     5.7517445087432861e-01
    z[4,5,4]  R2266     1.7057368159294128e-01
    z[4,5,4]  R2267     3.7018975615501404e-01
    z[4,5,4]  R2268     -4.3188139796257019e-01
    z[4,5,4]  R2269     -1.1991918087005615e-01
    z[4,5,4]  R2270     1.2100233882665634e-01
    z[4,5,4]  R2271     -1.7268361151218414e-01
    z[4,5,4]  R2272     -1.9243207573890686e-01
    z[4,5,4]  R2273     2.4496251344680786e-01
    z[4,5,4]  R2274     -6.2972551584243774e-01
    z[4,5,4]  R2275     0.0307974424213171
    z[4,5,4]  R2276     -4.2809373140335083e-01
    z[4,5,4]  R2277     -1.5423774719238281e-01
    z[4,5,4]  R2278     2.0271413028240204e-01
    z[4,5,4]  R2279     2.6255783438682556e-01
    z[4,5,4]  R2280     4.0326413512229919e-01
    z[4,5,4]  R2281     1.6242672502994537e-01
    z[4,5,4]  R2282     -2.8086664155125618e-02
    z[4,5,4]  R2283     3.9591252803802490e-01
    z[4,5,4]  R2284     1.4629776775836945e-01
    z[4,5,4]  R2285     1.8903563916683197e-01
    z[4,5,4]  R2286     1.3146454095840454e-01
    z[4,5,4]  R2287     -1.2828269600868225e-01
    z[4,5,4]  R2288     -3.3598041534423828e-01
    z[4,5,4]  R2289     1.7064245045185089e-01
    z[4,5,4]  R2290     1.7576907575130463e-01
    z[4,5,4]  R2291     -9.3462634831666946e-03
    z[4,5,4]  R2292     6.0886070132255554e-02
    z[4,5,4]  R2293     1.1964366585016251e-01
    z[4,5,4]  R2294     1.8079565837979317e-02
    z[4,5,4]  R2295     -5.3978666663169861e-02
    z[4,5,4]  R2296     -1.0950735211372375e-01
    z[4,5,4]  R2297     -1.6522422432899475e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2253     -1
    z[4,5,5]  R2254     1
    z[4,5,5]  R2257     -8.2129734754562378e-01
    z[4,5,5]  R2258     -9.1894274950027466e-01
    z[4,5,5]  R2259     -5.4655605554580688e-01
    z[4,5,5]  R2260     -1.7226213216781616e-01
    z[4,5,5]  R2261     -1.9043882191181183e-01
    z[4,5,5]  R2262     -2.8559145331382751e-01
    z[4,5,5]  R2263     3.0790126323699951e-01
    z[4,5,5]  R2264     2.2312806546688080e-01
    z[4,5,5]  R2265     3.2654333114624023e-01
    z[4,5,5]  R2266     2.8997638821601868e-01
    z[4,5,5]  R2267     -5.0029352307319641e-02
    z[4,5,5]  R2268     4.2158621549606323e-01
    z[4,5,5]  R2269     -1.1760377138853073e-01
    z[4,5,5]  R2270     2.8125956654548645e-01
    z[4,5,5]  R2271     2.9197099804878235e-01
    z[4,5,5]  R2272     2.0851273834705353e-01
    z[4,5,5]  R2273     -3.9929196238517761e-01
    z[4,5,5]  R2274     -2.4968470633029938e-01
    z[4,5,5]  R2275     -5.5485677719116211e-01
    z[4,5,5]  R2276     -4.7112739086151123e-01
    z[4,5,5]  R2277     3.3411204814910889e-01
    z[4,5,5]  R2278     2.5637684389948845e-02
    z[4,5,5]  R2279     -2.4374802410602570e-01
    z[4,5,5]  R2280     1.5165130794048309e-01
    z[4,5,5]  R2281     -1.5895521640777588e-01
    z[4,5,5]  R2282     1.6387178003787994e-01
    z[4,5,5]  R2283     -3.0993044376373291e-02
    z[4,5,5]  R2284     -2.2050505876541138e-01
    z[4,5,5]  R2285     3.0824041366577148e-01
    z[4,5,5]  R2286     1.1866968125104904e-01
    z[4,5,5]  R2287     -1.0495049506425858e-01
    z[4,5,5]  R2288     5.2054870128631592e-01
    z[4,5,5]  R2289     0.147319495677948
    z[4,5,5]  R2290     2.0072488114237785e-02
    z[4,5,5]  R2291     1.0734124481678009e-01
    z[4,5,5]  R2292     1.9797259569168091e-01
    z[4,5,5]  R2293     7.8324370086193085e-02
    z[4,5,5]  R2294     2.6179236173629761e-01
    z[4,5,5]  R2295     -1.7094336450099945e-02
    z[4,5,5]  R2296     1.8547664582729340e-01
    z[4,5,5]  R2297     2.2930899262428284e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2255     -1
    z[4,5,6]  R2256     1
    z[4,5,6]  R2257     1.8097130954265594e-01
    z[4,5,6]  R2258     -1.7782452702522278e-01
    z[4,5,6]  R2259     -1.4426478743553162e-01
    z[4,5,6]  R2260     -2.8533586859703064e-01
    z[4,5,6]  R2261     3.1594879925251007e-02
    z[4,5,6]  R2262     4.7426262497901917e-01
    z[4,5,6]  R2263     -3.9861583709716797e-01
    z[4,5,6]  R2264     6.9473057985305786e-02
    z[4,5,6]  R2265     2.2498293220996857e-01
    z[4,5,6]  R2266     -3.6225235089659691e-03
    z[4,5,6]  R2267     5.5946122854948044e-02
    z[4,5,6]  R2268     6.2424574047327042e-02
    z[4,5,6]  R2269     3.7235689163208008e-01
    z[4,5,6]  R2270     -0.0879029706120491
    z[4,5,6]  R2271     0.311167448759079
    z[4,5,6]  R2272     1.9222594797611237e-01
    z[4,5,6]  R2273     -2.2172866761684418e-01
    z[4,5,6]  R2274     3.5137692093849182e-01
    z[4,5,6]  R2275     -1.8017850816249847e-01
    z[4,5,6]  R2276     5.5753654241561890e-01
    z[4,5,6]  R2277     -1.5387046337127686e-01
    z[4,5,6]  R2278     1.4287789165973663e-01
    z[4,5,6]  R2279     3.4167438279837370e-03
    z[4,5,6]  R2280     -4.4392615556716919e-02
    z[4,5,6]  R2281     3.1140625476837158e-01
    z[4,5,6]  R2282     1.1510109901428223e-01
    z[4,5,6]  R2283     -2.3166318237781525e-01
    z[4,5,6]  R2284     -8.5646532475948334e-02
    z[4,5,6]  R2285     -2.2045131027698517e-01
    z[4,5,6]  R2286     -3.9121967554092407e-01
    z[4,5,6]  R2287     2.5514401495456696e-02
    z[4,5,6]  R2288     -4.3780177831649780e-01
    z[4,5,6]  R2289     -1.5390457212924957e-01
    z[4,5,6]  R2290     1.3502325117588043e-01
    z[4,5,6]  R2291     -9.4142660498619080e-02
    z[4,5,6]  R2292     4.4523306190967560e-02
    z[4,5,6]  R2293     -1.0987244546413422e-01
    z[4,5,6]  R2294     2.0463684201240540e-01
    z[4,5,6]  R2295     4.1273102164268494e-02
    z[4,5,6]  R2296     -4.1673827916383743e-02
    z[4,5,6]  R2297     1.0447089374065399e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2298     -1
    z[5,4,0]  R2299     1
    z[5,4,0]  R2312     3.0187436938285828e-01
    z[5,4,0]  R2313     1.7252075672149658e-01
    z[5,4,0]  R2314     5.6933969259262085e-01
    z[5,4,0]  R2315     4.8623824119567871e-01
    z[5,4,0]  R2316     7.0192024111747742e-02
    z[5,4,0]  R2317     -0.515808641910553
    z[5,4,0]  R2318     -7.7421814203262329e-01
    z[5,4,0]  R2319     -7.2666066884994507e-01
    z[5,4,0]  R2320     -6.8753719329833984e-01
    z[5,4,0]  R2321     -8.2020163536071777e-01
    z[5,4,0]  R2322     -7.3201900720596313e-01
    z[5,4,0]  R2323     -6.6962039470672607e-01
    z[5,4,0]  R2324     -7.2000789642333984e-01
    z[5,4,0]  R2325     -6.6059869527816772e-01
    z[5,4,0]  R2326     -6.0361480712890625e-01
    z[5,4,0]  R2327     5.0988274812698364e-01
    z[5,4,0]  R2328     -3.1249552965164185e-01
    z[5,4,0]  R2329     -3.3379566669464111e-01
    z[5,4,0]  R2330     -4.5933774113655090e-01
    z[5,4,0]  R2331     -5.1589739322662354e-01
    z[5,4,0]  R2332     -3.5599014163017273e-01
    z[5,4,0]  R2333     -2.8960227966308594e-01
    z[5,4,0]  R2334     -5.7515543699264526e-01
    z[5,4,0]  R2335     -4.1426292061805725e-01
    z[5,4,0]  R2336     -3.2901623845100403e-01
    z[5,4,0]  R2337     1.6145157814025879e-01
    z[5,4,0]  R2338     -6.0774767771363258e-03
    z[5,4,0]  R2339     2.2393876314163208e-01
    z[5,4,0]  R2340     -8.2619786262512207e-02
    z[5,4,0]  R2341     -1.9507546722888947e-01
    z[5,4,0]  R2342     -2.6520419120788574e-01
    z[5,4,0]  R2343     -3.1409361958503723e-01
    z[5,4,0]  R2344     2.3205070756375790e-03
    z[5,4,0]  R2345     3.8971800357103348e-02
    z[5,4,0]  R2346     1.1771667003631592e-01
    z[5,4,0]  R2347     -2.2602401673793793e-01
    z[5,4,0]  R2348     -7.5803823769092560e-02
    z[5,4,0]  R2349     5.8438873291015625e-01
    z[5,4,0]  R2350     -2.4338236451148987e-01
    z[5,4,0]  R2351     -3.5414078831672668e-01
    z[5,4,0]  R2352     -4.8526591062545776e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2300     -1
    z[5,4,1]  R2301     1
    z[5,4,1]  R2312     3.5130563378334045e-01
    z[5,4,1]  R2313     0.533920407295227
    z[5,4,1]  R2314     -2.9374182224273682e-01
    z[5,4,1]  R2315     -2.1514658629894257e-01
    z[5,4,1]  R2316     -8.2180780172348022e-01
    z[5,4,1]  R2317     5.8445432223379612e-03
    z[5,4,1]  R2318     1.4068324863910675e-01
    z[5,4,1]  R2319     7.3817779775708914e-04
    z[5,4,1]  R2320     1.3491672277450562e-01
    z[5,4,1]  R2321     -6.0320448130369186e-02
    z[5,4,1]  R2322     1.4563761651515961e-01
    z[5,4,1]  R2323     -1.0970515012741089e-01
    z[5,4,1]  R2324     -9.2762567102909088e-02
    z[5,4,1]  R2325     -1.0863159596920013e-01
    z[5,4,1]  R2326     -1.7153373360633850e-01
    z[5,4,1]  R2327     -0.0805494487285614
    z[5,4,1]  R2328     -9.0810102224349976e-01
    z[5,4,1]  R2329     -0.869015097618103
    z[5,4,1]  R2330     -8.6112791299819946e-01
    z[5,4,1]  R2331     -8.1934183835983276e-01
    z[5,4,1]  R2332     -8.2074803113937378e-01
    z[5,4,1]  R2333     -8.6880356073379517e-01
    z[5,4,1]  R2334     -0.808609127998352
    z[5,4,1]  R2335     -0.849862277507782
    z[5,4,1]  R2336     -8.1476384401321411e-01
    z[5,4,1]  R2337     -4.3822664022445679e-01
    z[5,4,1]  R2338     1.4301015995442867e-02
    z[5,4,1]  R2339     -2.1769827604293823e-01
    z[5,4,1]  R2340     7.4809336662292480e-01
    z[5,4,1]  R2341     9.2499506473541260e-01
    z[5,4,1]  R2342     4.7634577751159668e-01
    z[5,4,1]  R2343     -5.9345757961273193e-01
    z[5,4,1]  R2344     -0.64082932472229
    z[5,4,1]  R2345     -1.9719904661178589e-01
    z[5,4,1]  R2346     -1.3739171624183655e-01
    z[5,4,1]  R2347     -5.8837819099426270e-01
    z[5,4,1]  R2348     -4.8108461499214172e-01
    z[5,4,1]  R2349     0.478423148393631
    z[5,4,1]  R2350     -3.0948597192764282e-01
    z[5,4,1]  R2351     -2.6688629388809204e-01
    z[5,4,1]  R2352     -1.9983960315585136e-02
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2302     -1
    z[5,4,2]  R2303     1
    z[5,4,2]  R2312     7.0917874574661255e-01
    z[5,4,2]  R2313     2.5928530097007751e-01
    z[5,4,2]  R2314     3.1012037396430969e-01
    z[5,4,2]  R2315     -3.2536625862121582e-02
    z[5,4,2]  R2316     -3.9016953110694885e-01
    z[5,4,2]  R2317     -6.8645989894866943e-01
    z[5,4,2]  R2318     -4.4923231005668640e-01
    z[5,4,2]  R2319     -3.8668170571327209e-01
    z[5,4,2]  R2320     -5.1158332824707031e-01
    z[5,4,2]  R2321     -4.4767141342163086e-01
    z[5,4,2]  R2322     -4.2879101634025574e-01
    z[5,4,2]  R2323     -4.6130201220512390e-01
    z[5,4,2]  R2324     -5.1986885070800781e-01
    z[5,4,2]  R2325     -5.7390749454498291e-01
    z[5,4,2]  R2326     -3.1425091624259949e-01
    z[5,4,2]  R2327     1.3133190572261810e-02
    z[5,4,2]  R2328     5.4675798863172531e-02
    z[5,4,2]  R2329     1.2007483094930649e-01
    z[5,4,2]  R2330     7.4041627347469330e-02
    z[5,4,2]  R2331     8.9316859841346741e-02
    z[5,4,2]  R2332     0.255808025598526
    z[5,4,2]  R2333     2.0567758381366730e-01
    z[5,4,2]  R2334     2.1160072647035122e-03
    z[5,4,2]  R2335     -2.2815535962581635e-01
    z[5,4,2]  R2336     3.6205747723579407e-01
    z[5,4,2]  R2337     -6.9253191351890564e-02
    z[5,4,2]  R2338     -3.0256372690200806e-01
    z[5,4,2]  R2339     -2.5511956214904785e-01
    z[5,4,2]  R2340     2.0857103168964386e-01
    z[5,4,2]  R2341     1.8213124573230743e-01
    z[5,4,2]  R2342     5.2006185054779053e-01
    z[5,4,2]  R2343     -4.6254900097846985e-01
    z[5,4,2]  R2344     -3.6887651681900024e-01
    z[5,4,2]  R2345     -6.4441967010498047e-01
    z[5,4,2]  R2346     -0.922522783279419
    z[5,4,2]  R2347     2.0473857223987579e-01
    z[5,4,2]  R2348     5.9967929124832153e-01
    z[5,4,2]  R2349     5.0681042671203613e-01
    z[5,4,2]  R2350     0.664128839969635
    z[5,4,2]  R2351     2.5165876746177673e-01
    z[5,4,2]  R2352     -4.6096905134618282e-03
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2304     -1
    z[5,4,3]  R2305     1
    z[5,4,3]  R2312     1.1797262728214264e-01
    z[5,4,3]  R2313     -1.8861134350299835e-01
    z[5,4,3]  R2314     -3.9001864194869995e-01
    z[5,4,3]  R2315     -1.2386147864162922e-02
    z[5,4,3]  R2316     9.1523475944995880e-02
    z[5,4,3]  R2317     -4.4778978824615479e-01
    z[5,4,3]  R2318     -2.2499673068523407e-01
    z[5,4,3]  R2319     -3.6721962690353394e-01
    z[5,4,3]  R2320     -3.1424438953399658e-01
    z[5,4,3]  R2321     -2.8693222999572754e-01
    z[5,4,3]  R2322     -2.1840566396713257e-01
    z[5,4,3]  R2323     -4.9941259622573853e-01
    z[5,4,3]  R2324     -1.5288800001144409e-01
    z[5,4,3]  R2325     -1.9498866796493530e-01
    z[5,4,3]  R2326     -6.9235080480575562e-01
    z[5,4,3]  R2327     3.9728403091430664e-01
    z[5,4,3]  R2328     1.4180057682096958e-02
    z[5,4,3]  R2329     2.6352667808532715e-01
    z[5,4,3]  R2330     1.4667358994483948e-01
    z[5,4,3]  R2331     -9.8329484462738037e-02
    z[5,4,3]  R2332     3.1888020038604736e-01
    z[5,4,3]  R2333     -9.0936720371246338e-02
    z[5,4,3]  R2334     -1.0214445739984512e-01
    z[5,4,3]  R2335     -7.7040627598762512e-02
    z[5,4,3]  R2336     -0.0776321142911911
    z[5,4,3]  R2337     -2.4998681247234344e-01
    z[5,4,3]  R2338     1.4707107841968536e-01
    z[5,4,3]  R2339     -1.5856083482503891e-02
    z[5,4,3]  R2340     -4.9564335495233536e-02
    z[5,4,3]  R2341     1.7448128759860992e-01
    z[5,4,3]  R2342     1.1912860721349716e-01
    z[5,4,3]  R2343     1.2183716893196106e-01
    z[5,4,3]  R2344     6.3129603862762451e-01
    z[5,4,3]  R2345     2.3715730011463165e-01
    z[5,4,3]  R2346     -5.4982539266347885e-02
    z[5,4,3]  R2347     6.4663213491439819e-01
    z[5,4,3]  R2348     -1.8719787895679474e-01
    z[5,4,3]  R2349     7.6703488826751709e-02
    z[5,4,3]  R2350     -5.4994624853134155e-01
    z[5,4,3]  R2351     -7.2672683000564575e-01
    z[5,4,3]  R2352     -8.0413794517517090e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2306     -1
    z[5,4,4]  R2307     1
    z[5,4,4]  R2312     2.4496251344680786e-01
    z[5,4,4]  R2313     -6.2972551584243774e-01
    z[5,4,4]  R2314     0.0307974424213171
    z[5,4,4]  R2315     -4.2809373140335083e-01
    z[5,4,4]  R2316     -1.5423774719238281e-01
    z[5,4,4]  R2317     2.0271413028240204e-01
    z[5,4,4]  R2318     2.6255783438682556e-01
    z[5,4,4]  R2319     4.0326413512229919e-01
    z[5,4,4]  R2320     1.6242672502994537e-01
    z[5,4,4]  R2321     -2.8086664155125618e-02
    z[5,4,4]  R2322     3.9591252803802490e-01
    z[5,4,4]  R2323     1.4629776775836945e-01
    z[5,4,4]  R2324     1.8903563916683197e-01
    z[5,4,4]  R2325     1.3146454095840454e-01
    z[5,4,4]  R2326     -1.2828269600868225e-01
    z[5,4,4]  R2327     -3.3598041534423828e-01
    z[5,4,4]  R2328     1.7064245045185089e-01
    z[5,4,4]  R2329     1.7576907575130463e-01
    z[5,4,4]  R2330     -9.3462634831666946e-03
    z[5,4,4]  R2331     6.0886070132255554e-02
    z[5,4,4]  R2332     1.1964366585016251e-01
    z[5,4,4]  R2333     1.8079565837979317e-02
    z[5,4,4]  R2334     -5.3978666663169861e-02
    z[5,4,4]  R2335     -1.0950735211372375e-01
    z[5,4,4]  R2336     -1.6522422432899475e-01
    z[5,4,4]  R2337     8.5565179586410522e-02
    z[5,4,4]  R2338     1.0250149667263031e-01
    z[5,4,4]  R2339     -7.1943426132202148e-01
    z[5,4,4]  R2340     -5.2581459283828735e-01
    z[5,4,4]  R2341     7.3818467557430267e-02
    z[5,4,4]  R2342     -3.3409276604652405e-01
    z[5,4,4]  R2343     2.5818532705307007e-01
    z[5,4,4]  R2344     -1.0727589949965477e-02
    z[5,4,4]  R2345     5.7517445087432861e-01
    z[5,4,4]  R2346     1.7057368159294128e-01
    z[5,4,4]  R2347     3.7018975615501404e-01
    z[5,4,4]  R2348     -4.3188139796257019e-01
    z[5,4,4]  R2349     -1.1991918087005615e-01
    z[5,4,4]  R2350     1.2100233882665634e-01
    z[5,4,4]  R2351     -1.7268361151218414e-01
    z[5,4,4]  R2352     -1.9243207573890686e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2308     -1
    z[5,4,5]  R2309     1
    z[5,4,5]  R2312     -3.9929196238517761e-01
    z[5,4,5]  R2313     -2.4968470633029938e-01
    z[5,4,5]  R2314     -5.5485677719116211e-01
    z[5,4,5]  R2315     -4.7112739086151123e-01
    z[5,4,5]  R2316     3.3411204814910889e-01
    z[5,4,5]  R2317     2.5637684389948845e-02
    z[5,4,5]  R2318     -2.4374802410602570e-01
    z[5,4,5]  R2319     1.5165130794048309e-01
    z[5,4,5]  R2320     -1.5895521640777588e-01
    z[5,4,5]  R2321     1.6387178003787994e-01
    z[5,4,5]  R2322     -3.0993044376373291e-02
    z[5,4,5]  R2323     -2.2050505876541138e-01
    z[5,4,5]  R2324     3.0824041366577148e-01
    z[5,4,5]  R2325     1.1866968125104904e-01
    z[5,4,5]  R2326     -1.0495049506425858e-01
    z[5,4,5]  R2327     5.2054870128631592e-01
    z[5,4,5]  R2328     0.147319495677948
    z[5,4,5]  R2329     2.0072488114237785e-02
    z[5,4,5]  R2330     1.0734124481678009e-01
    z[5,4,5]  R2331     1.9797259569168091e-01
    z[5,4,5]  R2332     7.8324370086193085e-02
    z[5,4,5]  R2333     2.6179236173629761e-01
    z[5,4,5]  R2334     -1.7094336450099945e-02
    z[5,4,5]  R2335     1.8547664582729340e-01
    z[5,4,5]  R2336     2.2930899262428284e-01
    z[5,4,5]  R2337     -8.2129734754562378e-01
    z[5,4,5]  R2338     -9.1894274950027466e-01
    z[5,4,5]  R2339     -5.4655605554580688e-01
    z[5,4,5]  R2340     -1.7226213216781616e-01
    z[5,4,5]  R2341     -1.9043882191181183e-01
    z[5,4,5]  R2342     -2.8559145331382751e-01
    z[5,4,5]  R2343     3.0790126323699951e-01
    z[5,4,5]  R2344     2.2312806546688080e-01
    z[5,4,5]  R2345     3.2654333114624023e-01
    z[5,4,5]  R2346     2.8997638821601868e-01
    z[5,4,5]  R2347     -5.0029352307319641e-02
    z[5,4,5]  R2348     4.2158621549606323e-01
    z[5,4,5]  R2349     -1.1760377138853073e-01
    z[5,4,5]  R2350     2.8125956654548645e-01
    z[5,4,5]  R2351     2.9197099804878235e-01
    z[5,4,5]  R2352     2.0851273834705353e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2310     -1
    z[5,4,6]  R2311     1
    z[5,4,6]  R2312     -2.2172866761684418e-01
    z[5,4,6]  R2313     3.5137692093849182e-01
    z[5,4,6]  R2314     -1.8017850816249847e-01
    z[5,4,6]  R2315     5.5753654241561890e-01
    z[5,4,6]  R2316     -1.5387046337127686e-01
    z[5,4,6]  R2317     1.4287789165973663e-01
    z[5,4,6]  R2318     3.4167438279837370e-03
    z[5,4,6]  R2319     -4.4392615556716919e-02
    z[5,4,6]  R2320     3.1140625476837158e-01
    z[5,4,6]  R2321     1.1510109901428223e-01
    z[5,4,6]  R2322     -2.3166318237781525e-01
    z[5,4,6]  R2323     -8.5646532475948334e-02
    z[5,4,6]  R2324     -2.2045131027698517e-01
    z[5,4,6]  R2325     -3.9121967554092407e-01
    z[5,4,6]  R2326     2.5514401495456696e-02
    z[5,4,6]  R2327     -4.3780177831649780e-01
    z[5,4,6]  R2328     -1.5390457212924957e-01
    z[5,4,6]  R2329     1.3502325117588043e-01
    z[5,4,6]  R2330     -9.4142660498619080e-02
    z[5,4,6]  R2331     4.4523306190967560e-02
    z[5,4,6]  R2332     -1.0987244546413422e-01
    z[5,4,6]  R2333     2.0463684201240540e-01
    z[5,4,6]  R2334     4.1273102164268494e-02
    z[5,4,6]  R2335     -4.1673827916383743e-02
    z[5,4,6]  R2336     1.0447089374065399e-01
    z[5,4,6]  R2337     1.8097130954265594e-01
    z[5,4,6]  R2338     -1.7782452702522278e-01
    z[5,4,6]  R2339     -1.4426478743553162e-01
    z[5,4,6]  R2340     -2.8533586859703064e-01
    z[5,4,6]  R2341     3.1594879925251007e-02
    z[5,4,6]  R2342     4.7426262497901917e-01
    z[5,4,6]  R2343     -3.9861583709716797e-01
    z[5,4,6]  R2344     6.9473057985305786e-02
    z[5,4,6]  R2345     2.2498293220996857e-01
    z[5,4,6]  R2346     -3.6225235089659691e-03
    z[5,4,6]  R2347     5.5946122854948044e-02
    z[5,4,6]  R2348     6.2424574047327042e-02
    z[5,4,6]  R2349     3.7235689163208008e-01
    z[5,4,6]  R2350     -0.0879029706120491
    z[5,4,6]  R2351     0.311167448759079
    z[5,4,6]  R2352     1.9222594797611237e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2353     -1
    z[5,6,0]  R2354     1
    z[5,6,0]  R2367     3.0187436938285828e-01
    z[5,6,0]  R2368     1.7252075672149658e-01
    z[5,6,0]  R2369     5.6933969259262085e-01
    z[5,6,0]  R2370     4.8623824119567871e-01
    z[5,6,0]  R2371     7.0192024111747742e-02
    z[5,6,0]  R2372     -0.515808641910553
    z[5,6,0]  R2373     -7.7421814203262329e-01
    z[5,6,0]  R2374     -7.2666066884994507e-01
    z[5,6,0]  R2375     -6.8753719329833984e-01
    z[5,6,0]  R2376     -8.2020163536071777e-01
    z[5,6,0]  R2377     -7.3201900720596313e-01
    z[5,6,0]  R2378     -6.6962039470672607e-01
    z[5,6,0]  R2379     -7.2000789642333984e-01
    z[5,6,0]  R2380     -6.6059869527816772e-01
    z[5,6,0]  R2381     -6.0361480712890625e-01
    z[5,6,0]  R2382     5.0988274812698364e-01
    z[5,6,0]  R2383     -3.1249552965164185e-01
    z[5,6,0]  R2384     -3.3379566669464111e-01
    z[5,6,0]  R2385     -4.5933774113655090e-01
    z[5,6,0]  R2386     -5.1589739322662354e-01
    z[5,6,0]  R2387     -3.5599014163017273e-01
    z[5,6,0]  R2388     -2.8960227966308594e-01
    z[5,6,0]  R2389     -5.7515543699264526e-01
    z[5,6,0]  R2390     -4.1426292061805725e-01
    z[5,6,0]  R2391     -3.2901623845100403e-01
    z[5,6,0]  R2392     0.709740936756134
    z[5,6,0]  R2393     3.6230233311653137e-01
    z[5,6,0]  R2394     0.629054069519043
    z[5,6,0]  R2395     0.233524888753891
    z[5,6,0]  R2396     4.6908289194107056e-01
    z[5,6,0]  R2397     2.6015964150428772e-01
    z[5,6,0]  R2398     4.1445079445838928e-01
    z[5,6,0]  R2399     5.7593095302581787e-01
    z[5,6,0]  R2400     1.5702585875988007e-01
    z[5,6,0]  R2401     5.3924626111984253e-01
    z[5,6,0]  R2402     -5.3836303949356079e-01
    z[5,6,0]  R2403     -4.3145808577537537e-01
    z[5,6,0]  R2404     -4.1351196169853210e-01
    z[5,6,0]  R2405     -7.4025779962539673e-01
    z[5,6,0]  R2406     -5.5635732412338257e-01
    z[5,6,0]  R2407     -4.5257467031478882e-01
    z[5,6,0]  R2408     -2.9112818837165833e-01
    z[5,6,0]  R2409     -2.8168797492980957e-01
    z[5,6,0]  R2410     -3.7196445465087891e-01
    z[5,6,0]  R2411     -6.0151129961013794e-01
    z[5,6,0]  R2412     -3.1354081630706787e-01
    z[5,6,0]  R2413     7.1117728948593140e-01
    z[5,6,0]  R2414     -6.5981775522232056e-01
    z[5,6,0]  R2415     -4.5274645090103149e-01
    z[5,6,0]  R2416     -1.5458774566650391e-01
    z[5,6,0]  R2417     -8.7819606065750122e-02
    z[5,6,0]  R2418     -3.6092811822891235e-01
    z[5,6,0]  R2419     -1.5699428319931030e-01
    z[5,6,0]  R2420     -1.6911458969116211e-01
    z[5,6,0]  R2421     -6.2999892234802246e-01
    z[5,6,0]  R2422     4.3794098496437073e-01
    z[5,6,0]  R2423     -1.1244311928749084e-01
    z[5,6,0]  R2424     -5.8221215009689331e-01
    z[5,6,0]  R2425     -6.3366800546646118e-01
    z[5,6,0]  R2426     1.2343308329582214e-01
    z[5,6,0]  R2427     -9.1407202184200287e-02
    z[5,6,0]  R2428     -7.1424573659896851e-01
    z[5,6,0]  R2429     -3.5588359832763672e-01
    z[5,6,0]  R2430     -1.1344072222709656e-01
    z[5,6,0]  R2431     3.8538837432861328e-01
    z[5,6,0]  R2432     -3.4258842468261719e-01
    z[5,6,0]  R2433     1.2562611699104309e-01
    z[5,6,0]  R2434     -6.0157239437103271e-02
    z[5,6,0]  R2435     -4.8489010334014893e-01
    z[5,6,0]  R2436     7.7022269368171692e-02
    z[5,6,0]  R2437     2.5774019956588745e-01
    z[5,6,0]  R2438     -7.8487378358840942e-01
    z[5,6,0]  R2439     -0.67607581615448
    z[5,6,0]  R2440     4.0135046839714050e-01
    z[5,6,0]  R2441     -5.2852904796600342e-01
    z[5,6,0]  R2442     -1.6651949286460876e-01
    z[5,6,0]  R2443     2.0789556205272675e-01
    z[5,6,0]  R2444     3.9218395948410034e-01
    z[5,6,0]  R2445     -6.7370146512985229e-01
    z[5,6,0]  R2446     -5.1515656709671021e-01
    z[5,6,0]  R2447     2.0023368299007416e-02
    z[5,6,0]  R2448     -8.0589786171913147e-02
    z[5,6,0]  R2449     -1.6670224070549011e-01
    z[5,6,0]  R2450     -3.6944296956062317e-01
    z[5,6,0]  R2451     -4.0090450644493103e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2355     -1
    z[5,6,1]  R2356     1
    z[5,6,1]  R2367     3.5130563378334045e-01
    z[5,6,1]  R2368     0.533920407295227
    z[5,6,1]  R2369     -2.9374182224273682e-01
    z[5,6,1]  R2370     -2.1514658629894257e-01
    z[5,6,1]  R2371     -8.2180780172348022e-01
    z[5,6,1]  R2372     5.8445432223379612e-03
    z[5,6,1]  R2373     1.4068324863910675e-01
    z[5,6,1]  R2374     7.3817779775708914e-04
    z[5,6,1]  R2375     1.3491672277450562e-01
    z[5,6,1]  R2376     -6.0320448130369186e-02
    z[5,6,1]  R2377     1.4563761651515961e-01
    z[5,6,1]  R2378     -1.0970515012741089e-01
    z[5,6,1]  R2379     -9.2762567102909088e-02
    z[5,6,1]  R2380     -1.0863159596920013e-01
    z[5,6,1]  R2381     -1.7153373360633850e-01
    z[5,6,1]  R2382     -0.0805494487285614
    z[5,6,1]  R2383     -9.0810102224349976e-01
    z[5,6,1]  R2384     -0.869015097618103
    z[5,6,1]  R2385     -8.6112791299819946e-01
    z[5,6,1]  R2386     -8.1934183835983276e-01
    z[5,6,1]  R2387     -8.2074803113937378e-01
    z[5,6,1]  R2388     -8.6880356073379517e-01
    z[5,6,1]  R2389     -0.808609127998352
    z[5,6,1]  R2390     -0.849862277507782
    z[5,6,1]  R2391     -8.1476384401321411e-01
    z[5,6,1]  R2392     2.4190494418144226e-01
    z[5,6,1]  R2393     2.8154906630516052e-01
    z[5,6,1]  R2394     7.3732741177082062e-02
    z[5,6,1]  R2395     0.405757337808609
    z[5,6,1]  R2396     0.4198018014431
    z[5,6,1]  R2397     3.2296755909919739e-01
    z[5,6,1]  R2398     3.5791835188865662e-01
    z[5,6,1]  R2399     0.0816793143749237
    z[5,6,1]  R2400     2.1950738131999969e-01
    z[5,6,1]  R2401     5.2721697092056274e-01
    z[5,6,1]  R2402     -4.2514353990554810e-01
    z[5,6,1]  R2403     -3.7765043973922729e-01
    z[5,6,1]  R2404     -1.2175317108631134e-01
    z[5,6,1]  R2405     -1.5905758738517761e-01
    z[5,6,1]  R2406     -1.3026267290115356e-01
    z[5,6,1]  R2407     -0.288029283285141
    z[5,6,1]  R2408     -1.9473029673099518e-01
    z[5,6,1]  R2409     -2.6331162452697754e-01
    z[5,6,1]  R2410     -3.5283035039901733e-01
    z[5,6,1]  R2411     0.0972060039639473
    z[5,6,1]  R2412     3.4821841120719910e-01
    z[5,6,1]  R2413     1.6479054465889931e-02
    z[5,6,1]  R2414     -3.2278180122375488e-01
    z[5,6,1]  R2415     -2.9606339335441589e-01
    z[5,6,1]  R2416     -9.5858675241470337e-01
    z[5,6,1]  R2417     -9.7568619251251221e-01
    z[5,6,1]  R2418     -9.0082573890686035e-01
    z[5,6,1]  R2419     -9.6243840456008911e-01
    z[5,6,1]  R2420     -9.3594169616699219e-01
    z[5,6,1]  R2421     1.6161382198333740e-01
    z[5,6,1]  R2422     3.0210077762603760e-01
    z[5,6,1]  R2423     -2.1115374565124512e-01
    z[5,6,1]  R2424     -0.127500519156456
    z[5,6,1]  R2425     -2.0129573345184326e-01
    z[5,6,1]  R2426     -3.6651373375207186e-03
    z[5,6,1]  R2427     2.8281578421592712e-01
    z[5,6,1]  R2428     -0.115801140666008
    z[5,6,1]  R2429     -1.4698682725429535e-01
    z[5,6,1]  R2430     -9.1631585359573364e-01
    z[5,6,1]  R2431     -1.0541752912104130e-02
    z[5,6,1]  R2432     -9.8470970988273621e-03
    z[5,6,1]  R2433     -3.9768457412719727e-01
    z[5,6,1]  R2434     5.9079676866531372e-01
    z[5,6,1]  R2435     -5.5885225534439087e-01
    z[5,6,1]  R2436     3.4029465913772583e-01
    z[5,6,1]  R2437     4.1088182479143143e-02
    z[5,6,1]  R2438     -3.9760297536849976e-01
    z[5,6,1]  R2439     1.5373589098453522e-01
    z[5,6,1]  R2440     4.3040168285369873e-01
    z[5,6,1]  R2441     8.7787836790084839e-02
    z[5,6,1]  R2442     -1.6055350005626678e-01
    z[5,6,1]  R2443     6.0036581754684448e-01
    z[5,6,1]  R2444     4.1186764836311340e-01
    z[5,6,1]  R2445     -4.7440952062606812e-01
    z[5,6,1]  R2446     2.8013916686177254e-02
    z[5,6,1]  R2447     -6.3481992483139038e-01
    z[5,6,1]  R2448     1.7278394103050232e-01
    z[5,6,1]  R2449     -9.3897312879562378e-01
    z[5,6,1]  R2450     -8.7880575656890869e-01
    z[5,6,1]  R2451     -4.9423524737358093e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2357     -1
    z[5,6,2]  R2358     1
    z[5,6,2]  R2367     7.0917874574661255e-01
    z[5,6,2]  R2368     2.5928530097007751e-01
    z[5,6,2]  R2369     3.1012037396430969e-01
    z[5,6,2]  R2370     -3.2536625862121582e-02
    z[5,6,2]  R2371     -3.9016953110694885e-01
    z[5,6,2]  R2372     -6.8645989894866943e-01
    z[5,6,2]  R2373     -4.4923231005668640e-01
    z[5,6,2]  R2374     -3.8668170571327209e-01
    z[5,6,2]  R2375     -5.1158332824707031e-01
    z[5,6,2]  R2376     -4.4767141342163086e-01
    z[5,6,2]  R2377     -4.2879101634025574e-01
    z[5,6,2]  R2378     -4.6130201220512390e-01
    z[5,6,2]  R2379     -5.1986885070800781e-01
    z[5,6,2]  R2380     -5.7390749454498291e-01
    z[5,6,2]  R2381     -3.1425091624259949e-01
    z[5,6,2]  R2382     1.3133190572261810e-02
    z[5,6,2]  R2383     5.4675798863172531e-02
    z[5,6,2]  R2384     1.2007483094930649e-01
    z[5,6,2]  R2385     7.4041627347469330e-02
    z[5,6,2]  R2386     8.9316859841346741e-02
    z[5,6,2]  R2387     0.255808025598526
    z[5,6,2]  R2388     2.0567758381366730e-01
    z[5,6,2]  R2389     2.1160072647035122e-03
    z[5,6,2]  R2390     -2.2815535962581635e-01
    z[5,6,2]  R2391     3.6205747723579407e-01
    z[5,6,2]  R2392     5.6336796283721924e-01
    z[5,6,2]  R2393     6.7519217729568481e-01
    z[5,6,2]  R2394     6.1206829547882080e-01
    z[5,6,2]  R2395     6.4096099138259888e-01
    z[5,6,2]  R2396     3.1652599573135376e-01
    z[5,6,2]  R2397     1.7577858269214630e-01
    z[5,6,2]  R2398     4.0142270922660828e-01
    z[5,6,2]  R2399     3.3581075072288513e-01
    z[5,6,2]  R2400     6.5711104869842529e-01
    z[5,6,2]  R2401     4.9704349040985107e-01
    z[5,6,2]  R2402     -5.7997167110443115e-01
    z[5,6,2]  R2403     -7.0147556066513062e-01
    z[5,6,2]  R2404     -8.3670020103454590e-01
    z[5,6,2]  R2405     -5.4131674766540527e-01
    z[5,6,2]  R2406     -5.9926450252532959e-01
    z[5,6,2]  R2407     -5.8745086193084717e-01
    z[5,6,2]  R2408     -7.3352301120758057e-01
    z[5,6,2]  R2409     -7.4747115373611450e-01
    z[5,6,2]  R2410     -5.9564578533172607e-01
    z[5,6,2]  R2411     -6.4919906854629517e-01
    z[5,6,2]  R2412     -2.6262274384498596e-01
    z[5,6,2]  R2413     -2.6430574059486389e-01
    z[5,6,2]  R2414     -4.1024681925773621e-01
    z[5,6,2]  R2415     -4.2218139767646790e-01
    z[5,6,2]  R2416     -4.4179830700159073e-02
    z[5,6,2]  R2417     1.2788753211498260e-01
    z[5,6,2]  R2418     5.6832566857337952e-02
    z[5,6,2]  R2419     2.1435181796550751e-01
    z[5,6,2]  R2420     0.0388757586479187
    z[5,6,2]  R2421     -0.364346981048584
    z[5,6,2]  R2422     -4.4366419315338135e-01
    z[5,6,2]  R2423     -3.7094447761774063e-02
    z[5,6,2]  R2424     -7.5271910429000854e-01
    z[5,6,2]  R2425     -6.3303023576736450e-01
    z[5,6,2]  R2426     -4.2210537195205688e-01
    z[5,6,2]  R2427     -2.1372132003307343e-01
    z[5,6,2]  R2428     -2.2710137069225311e-01
    z[5,6,2]  R2429     -4.7464501857757568e-01
    z[5,6,2]  R2430     -2.9173898696899414e-01
    z[5,6,2]  R2431     -3.8445648550987244e-01
    z[5,6,2]  R2432     -1.0208919644355774e-01
    z[5,6,2]  R2433     -2.8553920984268188e-01
    z[5,6,2]  R2434     -5.2424877882003784e-01
    z[5,6,2]  R2435     -2.2722736001014709e-01
    z[5,6,2]  R2436     -5.4143589735031128e-01
    z[5,6,2]  R2437     -1.4111521840095520e-01
    z[5,6,2]  R2438     -2.6037901639938354e-01
    z[5,6,2]  R2439     -5.5918926000595093e-01
    z[5,6,2]  R2440     -2.7532979846000671e-01
    z[5,6,2]  R2441     -3.9835530519485474e-01
    z[5,6,2]  R2442     -2.0550100505352020e-01
    z[5,6,2]  R2443     -1.8229983747005463e-01
    z[5,6,2]  R2444     -6.6258095204830170e-02
    z[5,6,2]  R2445     -4.8902264237403870e-01
    z[5,6,2]  R2446     -6.3858497142791748e-01
    z[5,6,2]  R2447     5.9425350278615952e-02
    z[5,6,2]  R2448     0.63775634765625
    z[5,6,2]  R2449     -1.0608106106519699e-01
    z[5,6,2]  R2450     2.5521349161863327e-02
    z[5,6,2]  R2451     -4.1280549019575119e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2359     -1
    z[5,6,3]  R2360     1
    z[5,6,3]  R2367     1.1797262728214264e-01
    z[5,6,3]  R2368     -1.8861134350299835e-01
    z[5,6,3]  R2369     -3.9001864194869995e-01
    z[5,6,3]  R2370     -1.2386147864162922e-02
    z[5,6,3]  R2371     9.1523475944995880e-02
    z[5,6,3]  R2372     -4.4778978824615479e-01
    z[5,6,3]  R2373     -2.2499673068523407e-01
    z[5,6,3]  R2374     -3.6721962690353394e-01
    z[5,6,3]  R2375     -3.1424438953399658e-01
    z[5,6,3]  R2376     -2.8693222999572754e-01
    z[5,6,3]  R2377     -2.1840566396713257e-01
    z[5,6,3]  R2378     -4.9941259622573853e-01
    z[5,6,3]  R2379     -1.5288800001144409e-01
    z[5,6,3]  R2380     -1.9498866796493530e-01
    z[5,6,3]  R2381     -6.9235080480575562e-01
    z[5,6,3]  R2382     3.9728403091430664e-01
    z[5,6,3]  R2383     1.4180057682096958e-02
    z[5,6,3]  R2384     2.6352667808532715e-01
    z[5,6,3]  R2385     1.4667358994483948e-01
    z[5,6,3]  R2386     -9.8329484462738037e-02
    z[5,6,3]  R2387     3.1888020038604736e-01
    z[5,6,3]  R2388     -9.0936720371246338e-02
    z[5,6,3]  R2389     -1.0214445739984512e-01
    z[5,6,3]  R2390     -7.7040627598762512e-02
    z[5,6,3]  R2391     -0.0776321142911911
    z[5,6,3]  R2392     -2.8510352969169617e-01
    z[5,6,3]  R2393     -0.350054532289505
    z[5,6,3]  R2394     -3.9437657594680786e-01
    z[5,6,3]  R2395     -4.1259208321571350e-01
    z[5,6,3]  R2396     -4.9987259507179260e-01
    z[5,6,3]  R2397     -7.4416071176528931e-01
    z[5,6,3]  R2398     -0.333583801984787
    z[5,6,3]  R2399     -0.61178058385849
    z[5,6,3]  R2400     -6.4532315731048584e-01
    z[5,6,3]  R2401     1.7141984775662422e-02
    z[5,6,3]  R2402     -2.8958681225776672e-01
    z[5,6,3]  R2403     -1.0979428887367249e-01
    z[5,6,3]  R2404     -2.3557485640048981e-01
    z[5,6,3]  R2405     -3.0106914043426514e-01
    z[5,6,3]  R2406     -5.2056002616882324e-01
    z[5,6,3]  R2407     -3.9136391133069992e-02
    z[5,6,3]  R2408     1.4334677159786224e-01
    z[5,6,3]  R2409     1.0982558876276016e-01
    z[5,6,3]  R2410     -5.4830479621887207e-01
    z[5,6,3]  R2411     -1.2247132509946823e-01
    z[5,6,3]  R2412     4.9489909410476685e-01
    z[5,6,3]  R2413     4.1878691315650940e-01
    z[5,6,3]  R2414     4.3676272034645081e-01
    z[5,6,3]  R2415     1.2569785118103027e-01
    z[5,6,3]  R2416     1.3759475946426392e-01
    z[5,6,3]  R2417     -3.5409703850746155e-02
    z[5,6,3]  R2418     2.1893191337585449e-01
    z[5,6,3]  R2419     2.5135273113846779e-02
    z[5,6,3]  R2420     1.0995906591415405e-01
    z[5,6,3]  R2421     -7.0078149437904358e-02
    z[5,6,3]  R2422     6.5950727462768555e-01
    z[5,6,3]  R2423     7.3568254709243774e-01
    z[5,6,3]  R2424     -2.3707455396652222e-01
    z[5,6,3]  R2425     6.3124515116214752e-02
    z[5,6,3]  R2426     0.578386127948761
    z[5,6,3]  R2427     4.2485916614532471e-01
    z[5,6,3]  R2428     4.4990864396095276e-01
    z[5,6,3]  R2429     -6.1239427328109741e-01
    z[5,6,3]  R2430     -3.4515447914600372e-02
    z[5,6,3]  R2431     4.6823480725288391e-01
    z[5,6,3]  R2432     6.1810213327407837e-01
    z[5,6,3]  R2433     5.1329600811004639e-01
    z[5,6,3]  R2434     4.9232026934623718e-01
    z[5,6,3]  R2435     4.5263597369194031e-01
    z[5,6,3]  R2436     5.3748887777328491e-01
    z[5,6,3]  R2437     4.4000127911567688e-01
    z[5,6,3]  R2438     -1.0103973001241684e-01
    z[5,6,3]  R2439     1.2310529127717018e-02
    z[5,6,3]  R2440     5.8581686019897461e-01
    z[5,6,3]  R2441     -3.9492005109786987e-01
    z[5,6,3]  R2442     7.0988953113555908e-01
    z[5,6,3]  R2443     6.3191086053848267e-01
    z[5,6,3]  R2444     7.2458791732788086e-01
    z[5,6,3]  R2445     1.0826722532510757e-01
    z[5,6,3]  R2446     -2.7075886726379395e-01
    z[5,6,3]  R2447     4.8253166675567627e-01
    z[5,6,3]  R2448     2.9851797223091125e-01
    z[5,6,3]  R2449     1.8411509692668915e-01
    z[5,6,3]  R2450     -1.6450254619121552e-01
    z[5,6,3]  R2451     -6.2767666578292847e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2361     -1
    z[5,6,4]  R2362     1
    z[5,6,4]  R2367     2.4496251344680786e-01
    z[5,6,4]  R2368     -6.2972551584243774e-01
    z[5,6,4]  R2369     0.0307974424213171
    z[5,6,4]  R2370     -4.2809373140335083e-01
    z[5,6,4]  R2371     -1.5423774719238281e-01
    z[5,6,4]  R2372     2.0271413028240204e-01
    z[5,6,4]  R2373     2.6255783438682556e-01
    z[5,6,4]  R2374     4.0326413512229919e-01
    z[5,6,4]  R2375     1.6242672502994537e-01
    z[5,6,4]  R2376     -2.8086664155125618e-02
    z[5,6,4]  R2377     3.9591252803802490e-01
    z[5,6,4]  R2378     1.4629776775836945e-01
    z[5,6,4]  R2379     1.8903563916683197e-01
    z[5,6,4]  R2380     1.3146454095840454e-01
    z[5,6,4]  R2381     -1.2828269600868225e-01
    z[5,6,4]  R2382     -3.3598041534423828e-01
    z[5,6,4]  R2383     1.7064245045185089e-01
    z[5,6,4]  R2384     1.7576907575130463e-01
    z[5,6,4]  R2385     -9.3462634831666946e-03
    z[5,6,4]  R2386     6.0886070132255554e-02
    z[5,6,4]  R2387     1.1964366585016251e-01
    z[5,6,4]  R2388     1.8079565837979317e-02
    z[5,6,4]  R2389     -5.3978666663169861e-02
    z[5,6,4]  R2390     -1.0950735211372375e-01
    z[5,6,4]  R2391     -1.6522422432899475e-01
    z[5,6,4]  R2392     -1.0488862544298172e-01
    z[5,6,4]  R2393     -1.9606997072696686e-01
    z[5,6,4]  R2394     6.0652624815702438e-02
    z[5,6,4]  R2395     0.368369460105896
    z[5,6,4]  R2396     3.9720591902732849e-01
    z[5,6,4]  R2397     -1.9950459897518158e-01
    z[5,6,4]  R2398     -3.1402030587196350e-01
    z[5,6,4]  R2399     -1.2811496853828430e-01
    z[5,6,4]  R2400     9.1959655284881592e-02
    z[5,6,4]  R2401     3.5564652085304260e-01
    z[5,6,4]  R2402     1.8025381863117218e-01
    z[5,6,4]  R2403     -3.0721658468246460e-01
    z[5,6,4]  R2404     -9.9761180579662323e-02
    z[5,6,4]  R2405     -9.9405609071254730e-02
    z[5,6,4]  R2406     -7.6257757842540741e-02
    z[5,6,4]  R2407     2.9486769437789917e-01
    z[5,6,4]  R2408     1.4858794212341309e-01
    z[5,6,4]  R2409     -2.7082918211817741e-02
    z[5,6,4]  R2410     -2.0101411640644073e-01
    z[5,6,4]  R2411     2.5490963459014893e-01
    z[5,6,4]  R2412     -2.0636771619319916e-01
    z[5,6,4]  R2413     -3.5147297382354736e-01
    z[5,6,4]  R2414     -2.7333977818489075e-01
    z[5,6,4]  R2415     -2.7641248703002930e-01
    z[5,6,4]  R2416     -9.0551199391484261e-03
    z[5,6,4]  R2417     4.5610601082444191e-03
    z[5,6,4]  R2418     -2.5453658774495125e-02
    z[5,6,4]  R2419     1.8933297833427787e-03
    z[5,6,4]  R2420     2.8246089816093445e-01
    z[5,6,4]  R2421     4.6399328112602234e-01
    z[5,6,4]  R2422     2.2853070870041847e-02
    z[5,6,4]  R2423     -6.0383808612823486e-01
    z[5,6,4]  R2424     1.5979662537574768e-02
    z[5,6,4]  R2425     -8.3219580352306366e-02
    z[5,6,4]  R2426     -2.7004875242710114e-02
    z[5,6,4]  R2427     -2.6455727219581604e-01
    z[5,6,4]  R2428     -3.9190530776977539e-01
    z[5,6,4]  R2429     3.9881461858749390e-01
    z[5,6,4]  R2430     2.8546103276312351e-03
    z[5,6,4]  R2431     -1.5324451029300690e-01
    z[5,6,4]  R2432     -4.2493742704391479e-01
    z[5,6,4]  R2433     -2.5676766037940979e-01
    z[5,6,4]  R2434     7.0771694183349609e-02
    z[5,6,4]  R2435     -1.5333485603332520e-01
    z[5,6,4]  R2436     1.9122689962387085e-01
    z[5,6,4]  R2437     -0.550078272819519
    z[5,6,4]  R2438     3.3858400583267212e-01
    z[5,6,4]  R2439     4.3738394975662231e-01
    z[5,6,4]  R2440     -4.3129265308380127e-01
    z[5,6,4]  R2441     6.0318976640701294e-01
    z[5,6,4]  R2442     -5.9991395473480225e-01
    z[5,6,4]  R2443     -0.379001647233963
    z[5,6,4]  R2444     -3.0295750498771667e-01
    z[5,6,4]  R2445     -1.4633558690547943e-02
    z[5,6,4]  R2446     4.1551116108894348e-01
    z[5,6,4]  R2447     -3.4798362851142883e-01
    z[5,6,4]  R2448     -0.0678536519408226
    z[5,6,4]  R2449     -6.4541742205619812e-02
    z[5,6,4]  R2450     9.0936217457056046e-03
    z[5,6,4]  R2451     -3.0608716607093811e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2363     -1
    z[5,6,5]  R2364     1
    z[5,6,5]  R2367     -3.9929196238517761e-01
    z[5,6,5]  R2368     -2.4968470633029938e-01
    z[5,6,5]  R2369     -5.5485677719116211e-01
    z[5,6,5]  R2370     -4.7112739086151123e-01
    z[5,6,5]  R2371     3.3411204814910889e-01
    z[5,6,5]  R2372     2.5637684389948845e-02
    z[5,6,5]  R2373     -2.4374802410602570e-01
    z[5,6,5]  R2374     1.5165130794048309e-01
    z[5,6,5]  R2375     -1.5895521640777588e-01
    z[5,6,5]  R2376     1.6387178003787994e-01
    z[5,6,5]  R2377     -3.0993044376373291e-02
    z[5,6,5]  R2378     -2.2050505876541138e-01
    z[5,6,5]  R2379     3.0824041366577148e-01
    z[5,6,5]  R2380     1.1866968125104904e-01
    z[5,6,5]  R2381     -1.0495049506425858e-01
    z[5,6,5]  R2382     5.2054870128631592e-01
    z[5,6,5]  R2383     0.147319495677948
    z[5,6,5]  R2384     2.0072488114237785e-02
    z[5,6,5]  R2385     1.0734124481678009e-01
    z[5,6,5]  R2386     1.9797259569168091e-01
    z[5,6,5]  R2387     7.8324370086193085e-02
    z[5,6,5]  R2388     2.6179236173629761e-01
    z[5,6,5]  R2389     -1.7094336450099945e-02
    z[5,6,5]  R2390     1.8547664582729340e-01
    z[5,6,5]  R2391     2.2930899262428284e-01
    z[5,6,5]  R2392     1.4739826321601868e-01
    z[5,6,5]  R2393     3.7568813562393188e-01
    z[5,6,5]  R2394     2.4111062288284302e-01
    z[5,6,5]  R2395     2.4034756422042847e-01
    z[5,6,5]  R2396     1.9551150500774384e-01
    z[5,6,5]  R2397     0.446159690618515
    z[5,6,5]  R2398     5.6286835670471191e-01
    z[5,6,5]  R2399     2.3995193839073181e-01
    z[5,6,5]  R2400     -2.5375589728355408e-01
    z[5,6,5]  R2401     1.7624123394489288e-01
    z[5,6,5]  R2402     -2.7007976174354553e-01
    z[5,6,5]  R2403     -1.9779351353645325e-01
    z[5,6,5]  R2404     -1.8678367137908936e-01
    z[5,6,5]  R2405     1.6880062222480774e-01
    z[5,6,5]  R2406     1.0740427672863007e-01
    z[5,6,5]  R2407     -3.6001911759376526e-01
    z[5,6,5]  R2408     -5.4434555768966675e-01
    z[5,6,5]  R2409     -4.6388161182403564e-01
    z[5,6,5]  R2410     -5.7261552661657333e-02
    z[5,6,5]  R2411     -2.7936546131968498e-02
    z[5,6,5]  R2412     2.1938018035143614e-03
    z[5,6,5]  R2413     -2.8313118219375610e-01
    z[5,6,5]  R2414     -1.6117073595523834e-01
    z[5,6,5]  R2415     -6.0378503799438477e-01
    z[5,6,5]  R2416     4.8354521393775940e-02
    z[5,6,5]  R2417     7.4749879539012909e-02
    z[5,6,5]  R2418     -0.0522022470831871
    z[5,6,5]  R2419     -1.2488479726016521e-02
    z[5,6,5]  R2420     -3.5223349928855896e-02
    z[5,6,5]  R2421     3.6601489782333374e-01
    z[5,6,5]  R2422     2.6328054070472717e-01
    z[5,6,5]  R2423     -1.0909955948591232e-01
    z[5,6,5]  R2424     -1.3134272396564484e-01
    z[5,6,5]  R2425     -2.0239748060703278e-01
    z[5,6,5]  R2426     -5.0938504934310913e-01
    z[5,6,5]  R2427     3.9223301410675049e-01
    z[5,6,5]  R2428     1.8908958137035370e-01
    z[5,6,5]  R2429     2.9697835445404053e-01
    z[5,6,5]  R2430     -0.094648078083992
    z[5,6,5]  R2431     -6.2566363811492920e-01
    z[5,6,5]  R2432     1.2184092402458191e-01
    z[5,6,5]  R2433     3.8845051079988480e-02
    z[5,6,5]  R2434     -2.2432367503643036e-01
    z[5,6,5]  R2435     2.8363940119743347e-01
    z[5,6,5]  R2436     -4.7483119368553162e-01
    z[5,6,5]  R2437     4.4464193284511566e-02
    z[5,6,5]  R2438     -1.1897812038660049e-01
    z[5,6,5]  R2439     -8.9154131710529327e-02
    z[5,6,5]  R2440     -1.9231611490249634e-01
    z[5,6,5]  R2441     -4.5176412910223007e-02
    z[5,6,5]  R2442     -1.7778746783733368e-01
    z[5,6,5]  R2443     6.0651585459709167e-02
    z[5,6,5]  R2444     -2.0021903514862061e-01
    z[5,6,5]  R2445     -2.6244255900382996e-01
    z[5,6,5]  R2446     -1.3724821805953979e-01
    z[5,6,5]  R2447     3.7022197246551514e-01
    z[5,6,5]  R2448     3.4839814901351929e-01
    z[5,6,5]  R2449     -1.9910946488380432e-01
    z[5,6,5]  R2450     -2.5163310766220093e-01
    z[5,6,5]  R2451     3.2501003146171570e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2365     -1
    z[5,6,6]  R2366     1
    z[5,6,6]  R2367     -2.2172866761684418e-01
    z[5,6,6]  R2368     3.5137692093849182e-01
    z[5,6,6]  R2369     -1.8017850816249847e-01
    z[5,6,6]  R2370     5.5753654241561890e-01
    z[5,6,6]  R2371     -1.5387046337127686e-01
    z[5,6,6]  R2372     1.4287789165973663e-01
    z[5,6,6]  R2373     3.4167438279837370e-03
    z[5,6,6]  R2374     -4.4392615556716919e-02
    z[5,6,6]  R2375     3.1140625476837158e-01
    z[5,6,6]  R2376     1.1510109901428223e-01
    z[5,6,6]  R2377     -2.3166318237781525e-01
    z[5,6,6]  R2378     -8.5646532475948334e-02
    z[5,6,6]  R2379     -2.2045131027698517e-01
    z[5,6,6]  R2380     -3.9121967554092407e-01
    z[5,6,6]  R2381     2.5514401495456696e-02
    z[5,6,6]  R2382     -4.3780177831649780e-01
    z[5,6,6]  R2383     -1.5390457212924957e-01
    z[5,6,6]  R2384     1.3502325117588043e-01
    z[5,6,6]  R2385     -9.4142660498619080e-02
    z[5,6,6]  R2386     4.4523306190967560e-02
    z[5,6,6]  R2387     -1.0987244546413422e-01
    z[5,6,6]  R2388     2.0463684201240540e-01
    z[5,6,6]  R2389     4.1273102164268494e-02
    z[5,6,6]  R2390     -4.1673827916383743e-02
    z[5,6,6]  R2391     1.0447089374065399e-01
    z[5,6,6]  R2392     0.0797148197889328
    z[5,6,6]  R2393     1.7736832797527313e-01
    z[5,6,6]  R2394     -8.2950927317142487e-02
    z[5,6,6]  R2395     -7.9377971589565277e-02
    z[5,6,6]  R2396     2.4014383554458618e-01
    z[5,6,6]  R2397     6.6895879805088043e-02
    z[5,6,6]  R2398     -1.1080216616392136e-01
    z[5,6,6]  R2399     3.1717082858085632e-01
    z[5,6,6]  R2400     7.7935561537742615e-02
    z[5,6,6]  R2401     -1.6237047314643860e-01
    z[5,6,6]  R2402     -6.1286713927984238e-02
    z[5,6,6]  R2403     -1.8329469859600067e-01
    z[5,6,6]  R2404     -1.1739210784435272e-01
    z[5,6,6]  R2405     -6.8392440676689148e-02
    z[5,6,6]  R2406     1.6138932108879089e-01
    z[5,6,6]  R2407     -3.8603687286376953e-01
    z[5,6,6]  R2408     -1.8159691244363785e-02
    z[5,6,6]  R2409     -0.25421342253685
    z[5,6,6]  R2410     1.9502714276313782e-01
    z[5,6,6]  R2411     -3.5569229722023010e-01
    z[5,6,6]  R2412     6.5111279487609863e-01
    z[5,6,6]  R2413     -2.1217620372772217e-01
    z[5,6,6]  R2414     2.6413185521960258e-02
    z[5,6,6]  R2415     2.6901605725288391e-01
    z[5,6,6]  R2416     1.8414634466171265e-01
    z[5,6,6]  R2417     -1.3079290091991425e-01
    z[5,6,6]  R2418     6.0909580439329147e-02
    z[5,6,6]  R2419     4.8238448798656464e-02
    z[5,6,6]  R2420     2.8042057529091835e-02
    z[5,6,6]  R2421     3.0011010169982910e-01
    z[5,6,6]  R2422     1.2375874817371368e-01
    z[5,6,6]  R2423     -1.5376168489456177e-01
    z[5,6,6]  R2424     0.0669020339846611
    z[5,6,6]  R2425     3.2456547021865845e-01
    z[5,6,6]  R2426     -4.6026620268821716e-01
    z[5,6,6]  R2427     -6.7944127321243286e-01
    z[5,6,6]  R2428     -1.8194955587387085e-01
    z[5,6,6]  R2429     -6.4635932445526123e-02
    z[5,6,6]  R2430     -2.2853240370750427e-01
    z[5,6,6]  R2431     2.6339176297187805e-01
    z[5,6,6]  R2432     -5.4281371831893921e-01
    z[5,6,6]  R2433     -6.4313375949859619e-01
    z[5,6,6]  R2434     2.7348589897155762e-01
    z[5,6,6]  R2435     -3.0346539616584778e-01
    z[5,6,6]  R2436     -1.8489879369735718e-01
    z[5,6,6]  R2437     6.4327597618103027e-01
    z[5,6,6]  R2438     1.3814416527748108e-01
    z[5,6,6]  R2439     -8.4790289402008057e-02
    z[5,6,6]  R2440     1.0809958726167679e-01
    z[5,6,6]  R2441     1.8006315827369690e-01
    z[5,6,6]  R2442     9.3888416886329651e-02
    z[5,6,6]  R2443     -1.2835410237312317e-01
    z[5,6,6]  R2444     1.2356420606374741e-01
    z[5,6,6]  R2445     -3.3267840743064880e-02
    z[5,6,6]  R2446     -2.4746958911418915e-01
    z[5,6,6]  R2447     3.1949594616889954e-01
    z[5,6,6]  R2448     5.8465325832366943e-01
    z[5,6,6]  R2449     -3.9723575115203857e-02
    z[5,6,6]  R2450     -9.9051259458065033e-03
    z[5,6,6]  R2451     2.0256226416677237e-03
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2452     -1
    z[6,5,0]  R2453     1
    z[6,5,0]  R2466     0.709740936756134
    z[6,5,0]  R2467     3.6230233311653137e-01
    z[6,5,0]  R2468     0.629054069519043
    z[6,5,0]  R2469     0.233524888753891
    z[6,5,0]  R2470     4.6908289194107056e-01
    z[6,5,0]  R2471     2.6015964150428772e-01
    z[6,5,0]  R2472     4.1445079445838928e-01
    z[6,5,0]  R2473     5.7593095302581787e-01
    z[6,5,0]  R2474     1.5702585875988007e-01
    z[6,5,0]  R2475     5.3924626111984253e-01
    z[6,5,0]  R2476     -5.3836303949356079e-01
    z[6,5,0]  R2477     -4.3145808577537537e-01
    z[6,5,0]  R2478     -4.1351196169853210e-01
    z[6,5,0]  R2479     -7.4025779962539673e-01
    z[6,5,0]  R2480     -5.5635732412338257e-01
    z[6,5,0]  R2481     -4.5257467031478882e-01
    z[6,5,0]  R2482     -2.9112818837165833e-01
    z[6,5,0]  R2483     -2.8168797492980957e-01
    z[6,5,0]  R2484     -3.7196445465087891e-01
    z[6,5,0]  R2485     -6.0151129961013794e-01
    z[6,5,0]  R2486     -3.1354081630706787e-01
    z[6,5,0]  R2487     7.1117728948593140e-01
    z[6,5,0]  R2488     -6.5981775522232056e-01
    z[6,5,0]  R2489     -4.5274645090103149e-01
    z[6,5,0]  R2490     -1.5458774566650391e-01
    z[6,5,0]  R2491     -8.7819606065750122e-02
    z[6,5,0]  R2492     -3.6092811822891235e-01
    z[6,5,0]  R2493     -1.5699428319931030e-01
    z[6,5,0]  R2494     -1.6911458969116211e-01
    z[6,5,0]  R2495     -6.2999892234802246e-01
    z[6,5,0]  R2496     4.3794098496437073e-01
    z[6,5,0]  R2497     -1.1244311928749084e-01
    z[6,5,0]  R2498     -5.8221215009689331e-01
    z[6,5,0]  R2499     -6.3366800546646118e-01
    z[6,5,0]  R2500     1.2343308329582214e-01
    z[6,5,0]  R2501     -9.1407202184200287e-02
    z[6,5,0]  R2502     -7.1424573659896851e-01
    z[6,5,0]  R2503     -3.5588359832763672e-01
    z[6,5,0]  R2504     -1.1344072222709656e-01
    z[6,5,0]  R2505     3.8538837432861328e-01
    z[6,5,0]  R2506     -3.4258842468261719e-01
    z[6,5,0]  R2507     1.2562611699104309e-01
    z[6,5,0]  R2508     -6.0157239437103271e-02
    z[6,5,0]  R2509     -4.8489010334014893e-01
    z[6,5,0]  R2510     7.7022269368171692e-02
    z[6,5,0]  R2511     2.5774019956588745e-01
    z[6,5,0]  R2512     -7.8487378358840942e-01
    z[6,5,0]  R2513     -0.67607581615448
    z[6,5,0]  R2514     4.0135046839714050e-01
    z[6,5,0]  R2515     -5.2852904796600342e-01
    z[6,5,0]  R2516     -1.6651949286460876e-01
    z[6,5,0]  R2517     2.0789556205272675e-01
    z[6,5,0]  R2518     3.9218395948410034e-01
    z[6,5,0]  R2519     -6.7370146512985229e-01
    z[6,5,0]  R2520     -5.1515656709671021e-01
    z[6,5,0]  R2521     2.0023368299007416e-02
    z[6,5,0]  R2522     -8.0589786171913147e-02
    z[6,5,0]  R2523     -1.6670224070549011e-01
    z[6,5,0]  R2524     -3.6944296956062317e-01
    z[6,5,0]  R2525     -4.0090450644493103e-01
    z[6,5,0]  R2526     3.0187436938285828e-01
    z[6,5,0]  R2527     1.7252075672149658e-01
    z[6,5,0]  R2528     5.6933969259262085e-01
    z[6,5,0]  R2529     4.8623824119567871e-01
    z[6,5,0]  R2530     7.0192024111747742e-02
    z[6,5,0]  R2531     -0.515808641910553
    z[6,5,0]  R2532     -7.7421814203262329e-01
    z[6,5,0]  R2533     -7.2666066884994507e-01
    z[6,5,0]  R2534     -6.8753719329833984e-01
    z[6,5,0]  R2535     -8.2020163536071777e-01
    z[6,5,0]  R2536     -7.3201900720596313e-01
    z[6,5,0]  R2537     -6.6962039470672607e-01
    z[6,5,0]  R2538     -7.2000789642333984e-01
    z[6,5,0]  R2539     -6.6059869527816772e-01
    z[6,5,0]  R2540     -6.0361480712890625e-01
    z[6,5,0]  R2541     5.0988274812698364e-01
    z[6,5,0]  R2542     -3.1249552965164185e-01
    z[6,5,0]  R2543     -3.3379566669464111e-01
    z[6,5,0]  R2544     -4.5933774113655090e-01
    z[6,5,0]  R2545     -5.1589739322662354e-01
    z[6,5,0]  R2546     -3.5599014163017273e-01
    z[6,5,0]  R2547     -2.8960227966308594e-01
    z[6,5,0]  R2548     -5.7515543699264526e-01
    z[6,5,0]  R2549     -4.1426292061805725e-01
    z[6,5,0]  R2550     -3.2901623845100403e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2454     -1
    z[6,5,1]  R2455     1
    z[6,5,1]  R2466     2.4190494418144226e-01
    z[6,5,1]  R2467     2.8154906630516052e-01
    z[6,5,1]  R2468     7.3732741177082062e-02
    z[6,5,1]  R2469     0.405757337808609
    z[6,5,1]  R2470     0.4198018014431
    z[6,5,1]  R2471     3.2296755909919739e-01
    z[6,5,1]  R2472     3.5791835188865662e-01
    z[6,5,1]  R2473     0.0816793143749237
    z[6,5,1]  R2474     2.1950738131999969e-01
    z[6,5,1]  R2475     5.2721697092056274e-01
    z[6,5,1]  R2476     -4.2514353990554810e-01
    z[6,5,1]  R2477     -3.7765043973922729e-01
    z[6,5,1]  R2478     -1.2175317108631134e-01
    z[6,5,1]  R2479     -1.5905758738517761e-01
    z[6,5,1]  R2480     -1.3026267290115356e-01
    z[6,5,1]  R2481     -0.288029283285141
    z[6,5,1]  R2482     -1.9473029673099518e-01
    z[6,5,1]  R2483     -2.6331162452697754e-01
    z[6,5,1]  R2484     -3.5283035039901733e-01
    z[6,5,1]  R2485     0.0972060039639473
    z[6,5,1]  R2486     3.4821841120719910e-01
    z[6,5,1]  R2487     1.6479054465889931e-02
    z[6,5,1]  R2488     -3.2278180122375488e-01
    z[6,5,1]  R2489     -2.9606339335441589e-01
    z[6,5,1]  R2490     -9.5858675241470337e-01
    z[6,5,1]  R2491     -9.7568619251251221e-01
    z[6,5,1]  R2492     -9.0082573890686035e-01
    z[6,5,1]  R2493     -9.6243840456008911e-01
    z[6,5,1]  R2494     -9.3594169616699219e-01
    z[6,5,1]  R2495     1.6161382198333740e-01
    z[6,5,1]  R2496     3.0210077762603760e-01
    z[6,5,1]  R2497     -2.1115374565124512e-01
    z[6,5,1]  R2498     -0.127500519156456
    z[6,5,1]  R2499     -2.0129573345184326e-01
    z[6,5,1]  R2500     -3.6651373375207186e-03
    z[6,5,1]  R2501     2.8281578421592712e-01
    z[6,5,1]  R2502     -0.115801140666008
    z[6,5,1]  R2503     -1.4698682725429535e-01
    z[6,5,1]  R2504     -9.1631585359573364e-01
    z[6,5,1]  R2505     -1.0541752912104130e-02
    z[6,5,1]  R2506     -9.8470970988273621e-03
    z[6,5,1]  R2507     -3.9768457412719727e-01
    z[6,5,1]  R2508     5.9079676866531372e-01
    z[6,5,1]  R2509     -5.5885225534439087e-01
    z[6,5,1]  R2510     3.4029465913772583e-01
    z[6,5,1]  R2511     4.1088182479143143e-02
    z[6,5,1]  R2512     -3.9760297536849976e-01
    z[6,5,1]  R2513     1.5373589098453522e-01
    z[6,5,1]  R2514     4.3040168285369873e-01
    z[6,5,1]  R2515     8.7787836790084839e-02
    z[6,5,1]  R2516     -1.6055350005626678e-01
    z[6,5,1]  R2517     6.0036581754684448e-01
    z[6,5,1]  R2518     4.1186764836311340e-01
    z[6,5,1]  R2519     -4.7440952062606812e-01
    z[6,5,1]  R2520     2.8013916686177254e-02
    z[6,5,1]  R2521     -6.3481992483139038e-01
    z[6,5,1]  R2522     1.7278394103050232e-01
    z[6,5,1]  R2523     -9.3897312879562378e-01
    z[6,5,1]  R2524     -8.7880575656890869e-01
    z[6,5,1]  R2525     -4.9423524737358093e-01
    z[6,5,1]  R2526     3.5130563378334045e-01
    z[6,5,1]  R2527     0.533920407295227
    z[6,5,1]  R2528     -2.9374182224273682e-01
    z[6,5,1]  R2529     -2.1514658629894257e-01
    z[6,5,1]  R2530     -8.2180780172348022e-01
    z[6,5,1]  R2531     5.8445432223379612e-03
    z[6,5,1]  R2532     1.4068324863910675e-01
    z[6,5,1]  R2533     7.3817779775708914e-04
    z[6,5,1]  R2534     1.3491672277450562e-01
    z[6,5,1]  R2535     -6.0320448130369186e-02
    z[6,5,1]  R2536     1.4563761651515961e-01
    z[6,5,1]  R2537     -1.0970515012741089e-01
    z[6,5,1]  R2538     -9.2762567102909088e-02
    z[6,5,1]  R2539     -1.0863159596920013e-01
    z[6,5,1]  R2540     -1.7153373360633850e-01
    z[6,5,1]  R2541     -0.0805494487285614
    z[6,5,1]  R2542     -9.0810102224349976e-01
    z[6,5,1]  R2543     -0.869015097618103
    z[6,5,1]  R2544     -8.6112791299819946e-01
    z[6,5,1]  R2545     -8.1934183835983276e-01
    z[6,5,1]  R2546     -8.2074803113937378e-01
    z[6,5,1]  R2547     -8.6880356073379517e-01
    z[6,5,1]  R2548     -0.808609127998352
    z[6,5,1]  R2549     -0.849862277507782
    z[6,5,1]  R2550     -8.1476384401321411e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2456     -1
    z[6,5,2]  R2457     1
    z[6,5,2]  R2466     5.6336796283721924e-01
    z[6,5,2]  R2467     6.7519217729568481e-01
    z[6,5,2]  R2468     6.1206829547882080e-01
    z[6,5,2]  R2469     6.4096099138259888e-01
    z[6,5,2]  R2470     3.1652599573135376e-01
    z[6,5,2]  R2471     1.7577858269214630e-01
    z[6,5,2]  R2472     4.0142270922660828e-01
    z[6,5,2]  R2473     3.3581075072288513e-01
    z[6,5,2]  R2474     6.5711104869842529e-01
    z[6,5,2]  R2475     4.9704349040985107e-01
    z[6,5,2]  R2476     -5.7997167110443115e-01
    z[6,5,2]  R2477     -7.0147556066513062e-01
    z[6,5,2]  R2478     -8.3670020103454590e-01
    z[6,5,2]  R2479     -5.4131674766540527e-01
    z[6,5,2]  R2480     -5.9926450252532959e-01
    z[6,5,2]  R2481     -5.8745086193084717e-01
    z[6,5,2]  R2482     -7.3352301120758057e-01
    z[6,5,2]  R2483     -7.4747115373611450e-01
    z[6,5,2]  R2484     -5.9564578533172607e-01
    z[6,5,2]  R2485     -6.4919906854629517e-01
    z[6,5,2]  R2486     -2.6262274384498596e-01
    z[6,5,2]  R2487     -2.6430574059486389e-01
    z[6,5,2]  R2488     -4.1024681925773621e-01
    z[6,5,2]  R2489     -4.2218139767646790e-01
    z[6,5,2]  R2490     -4.4179830700159073e-02
    z[6,5,2]  R2491     1.2788753211498260e-01
    z[6,5,2]  R2492     5.6832566857337952e-02
    z[6,5,2]  R2493     2.1435181796550751e-01
    z[6,5,2]  R2494     0.0388757586479187
    z[6,5,2]  R2495     -0.364346981048584
    z[6,5,2]  R2496     -4.4366419315338135e-01
    z[6,5,2]  R2497     -3.7094447761774063e-02
    z[6,5,2]  R2498     -7.5271910429000854e-01
    z[6,5,2]  R2499     -6.3303023576736450e-01
    z[6,5,2]  R2500     -4.2210537195205688e-01
    z[6,5,2]  R2501     -2.1372132003307343e-01
    z[6,5,2]  R2502     -2.2710137069225311e-01
    z[6,5,2]  R2503     -4.7464501857757568e-01
    z[6,5,2]  R2504     -2.9173898696899414e-01
    z[6,5,2]  R2505     -3.8445648550987244e-01
    z[6,5,2]  R2506     -1.0208919644355774e-01
    z[6,5,2]  R2507     -2.8553920984268188e-01
    z[6,5,2]  R2508     -5.2424877882003784e-01
    z[6,5,2]  R2509     -2.2722736001014709e-01
    z[6,5,2]  R2510     -5.4143589735031128e-01
    z[6,5,2]  R2511     -1.4111521840095520e-01
    z[6,5,2]  R2512     -2.6037901639938354e-01
    z[6,5,2]  R2513     -5.5918926000595093e-01
    z[6,5,2]  R2514     -2.7532979846000671e-01
    z[6,5,2]  R2515     -3.9835530519485474e-01
    z[6,5,2]  R2516     -2.0550100505352020e-01
    z[6,5,2]  R2517     -1.8229983747005463e-01
    z[6,5,2]  R2518     -6.6258095204830170e-02
    z[6,5,2]  R2519     -4.8902264237403870e-01
    z[6,5,2]  R2520     -6.3858497142791748e-01
    z[6,5,2]  R2521     5.9425350278615952e-02
    z[6,5,2]  R2522     0.63775634765625
    z[6,5,2]  R2523     -1.0608106106519699e-01
    z[6,5,2]  R2524     2.5521349161863327e-02
    z[6,5,2]  R2525     -4.1280549019575119e-02
    z[6,5,2]  R2526     7.0917874574661255e-01
    z[6,5,2]  R2527     2.5928530097007751e-01
    z[6,5,2]  R2528     3.1012037396430969e-01
    z[6,5,2]  R2529     -3.2536625862121582e-02
    z[6,5,2]  R2530     -3.9016953110694885e-01
    z[6,5,2]  R2531     -6.8645989894866943e-01
    z[6,5,2]  R2532     -4.4923231005668640e-01
    z[6,5,2]  R2533     -3.8668170571327209e-01
    z[6,5,2]  R2534     -5.1158332824707031e-01
    z[6,5,2]  R2535     -4.4767141342163086e-01
    z[6,5,2]  R2536     -4.2879101634025574e-01
    z[6,5,2]  R2537     -4.6130201220512390e-01
    z[6,5,2]  R2538     -5.1986885070800781e-01
    z[6,5,2]  R2539     -5.7390749454498291e-01
    z[6,5,2]  R2540     -3.1425091624259949e-01
    z[6,5,2]  R2541     1.3133190572261810e-02
    z[6,5,2]  R2542     5.4675798863172531e-02
    z[6,5,2]  R2543     1.2007483094930649e-01
    z[6,5,2]  R2544     7.4041627347469330e-02
    z[6,5,2]  R2545     8.9316859841346741e-02
    z[6,5,2]  R2546     0.255808025598526
    z[6,5,2]  R2547     2.0567758381366730e-01
    z[6,5,2]  R2548     2.1160072647035122e-03
    z[6,5,2]  R2549     -2.2815535962581635e-01
    z[6,5,2]  R2550     3.6205747723579407e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2458     -1
    z[6,5,3]  R2459     1
    z[6,5,3]  R2466     -2.8510352969169617e-01
    z[6,5,3]  R2467     -0.350054532289505
    z[6,5,3]  R2468     -3.9437657594680786e-01
    z[6,5,3]  R2469     -4.1259208321571350e-01
    z[6,5,3]  R2470     -4.9987259507179260e-01
    z[6,5,3]  R2471     -7.4416071176528931e-01
    z[6,5,3]  R2472     -0.333583801984787
    z[6,5,3]  R2473     -0.61178058385849
    z[6,5,3]  R2474     -6.4532315731048584e-01
    z[6,5,3]  R2475     1.7141984775662422e-02
    z[6,5,3]  R2476     -2.8958681225776672e-01
    z[6,5,3]  R2477     -1.0979428887367249e-01
    z[6,5,3]  R2478     -2.3557485640048981e-01
    z[6,5,3]  R2479     -3.0106914043426514e-01
    z[6,5,3]  R2480     -5.2056002616882324e-01
    z[6,5,3]  R2481     -3.9136391133069992e-02
    z[6,5,3]  R2482     1.4334677159786224e-01
    z[6,5,3]  R2483     1.0982558876276016e-01
    z[6,5,3]  R2484     -5.4830479621887207e-01
    z[6,5,3]  R2485     -1.2247132509946823e-01
    z[6,5,3]  R2486     4.9489909410476685e-01
    z[6,5,3]  R2487     4.1878691315650940e-01
    z[6,5,3]  R2488     4.3676272034645081e-01
    z[6,5,3]  R2489     1.2569785118103027e-01
    z[6,5,3]  R2490     1.3759475946426392e-01
    z[6,5,3]  R2491     -3.5409703850746155e-02
    z[6,5,3]  R2492     2.1893191337585449e-01
    z[6,5,3]  R2493     2.5135273113846779e-02
    z[6,5,3]  R2494     1.0995906591415405e-01
    z[6,5,3]  R2495     -7.0078149437904358e-02
    z[6,5,3]  R2496     6.5950727462768555e-01
    z[6,5,3]  R2497     7.3568254709243774e-01
    z[6,5,3]  R2498     -2.3707455396652222e-01
    z[6,5,3]  R2499     6.3124515116214752e-02
    z[6,5,3]  R2500     0.578386127948761
    z[6,5,3]  R2501     4.2485916614532471e-01
    z[6,5,3]  R2502     4.4990864396095276e-01
    z[6,5,3]  R2503     -6.1239427328109741e-01
    z[6,5,3]  R2504     -3.4515447914600372e-02
    z[6,5,3]  R2505     4.6823480725288391e-01
    z[6,5,3]  R2506     6.1810213327407837e-01
    z[6,5,3]  R2507     5.1329600811004639e-01
    z[6,5,3]  R2508     4.9232026934623718e-01
    z[6,5,3]  R2509     4.5263597369194031e-01
    z[6,5,3]  R2510     5.3748887777328491e-01
    z[6,5,3]  R2511     4.4000127911567688e-01
    z[6,5,3]  R2512     -1.0103973001241684e-01
    z[6,5,3]  R2513     1.2310529127717018e-02
    z[6,5,3]  R2514     5.8581686019897461e-01
    z[6,5,3]  R2515     -3.9492005109786987e-01
    z[6,5,3]  R2516     7.0988953113555908e-01
    z[6,5,3]  R2517     6.3191086053848267e-01
    z[6,5,3]  R2518     7.2458791732788086e-01
    z[6,5,3]  R2519     1.0826722532510757e-01
    z[6,5,3]  R2520     -2.7075886726379395e-01
    z[6,5,3]  R2521     4.8253166675567627e-01
    z[6,5,3]  R2522     2.9851797223091125e-01
    z[6,5,3]  R2523     1.8411509692668915e-01
    z[6,5,3]  R2524     -1.6450254619121552e-01
    z[6,5,3]  R2525     -6.2767666578292847e-01
    z[6,5,3]  R2526     1.1797262728214264e-01
    z[6,5,3]  R2527     -1.8861134350299835e-01
    z[6,5,3]  R2528     -3.9001864194869995e-01
    z[6,5,3]  R2529     -1.2386147864162922e-02
    z[6,5,3]  R2530     9.1523475944995880e-02
    z[6,5,3]  R2531     -4.4778978824615479e-01
    z[6,5,3]  R2532     -2.2499673068523407e-01
    z[6,5,3]  R2533     -3.6721962690353394e-01
    z[6,5,3]  R2534     -3.1424438953399658e-01
    z[6,5,3]  R2535     -2.8693222999572754e-01
    z[6,5,3]  R2536     -2.1840566396713257e-01
    z[6,5,3]  R2537     -4.9941259622573853e-01
    z[6,5,3]  R2538     -1.5288800001144409e-01
    z[6,5,3]  R2539     -1.9498866796493530e-01
    z[6,5,3]  R2540     -6.9235080480575562e-01
    z[6,5,3]  R2541     3.9728403091430664e-01
    z[6,5,3]  R2542     1.4180057682096958e-02
    z[6,5,3]  R2543     2.6352667808532715e-01
    z[6,5,3]  R2544     1.4667358994483948e-01
    z[6,5,3]  R2545     -9.8329484462738037e-02
    z[6,5,3]  R2546     3.1888020038604736e-01
    z[6,5,3]  R2547     -9.0936720371246338e-02
    z[6,5,3]  R2548     -1.0214445739984512e-01
    z[6,5,3]  R2549     -7.7040627598762512e-02
    z[6,5,3]  R2550     -0.0776321142911911
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2460     -1
    z[6,5,4]  R2461     1
    z[6,5,4]  R2466     -1.0488862544298172e-01
    z[6,5,4]  R2467     -1.9606997072696686e-01
    z[6,5,4]  R2468     6.0652624815702438e-02
    z[6,5,4]  R2469     0.368369460105896
    z[6,5,4]  R2470     3.9720591902732849e-01
    z[6,5,4]  R2471     -1.9950459897518158e-01
    z[6,5,4]  R2472     -3.1402030587196350e-01
    z[6,5,4]  R2473     -1.2811496853828430e-01
    z[6,5,4]  R2474     9.1959655284881592e-02
    z[6,5,4]  R2475     3.5564652085304260e-01
    z[6,5,4]  R2476     1.8025381863117218e-01
    z[6,5,4]  R2477     -3.0721658468246460e-01
    z[6,5,4]  R2478     -9.9761180579662323e-02
    z[6,5,4]  R2479     -9.9405609071254730e-02
    z[6,5,4]  R2480     -7.6257757842540741e-02
    z[6,5,4]  R2481     2.9486769437789917e-01
    z[6,5,4]  R2482     1.4858794212341309e-01
    z[6,5,4]  R2483     -2.7082918211817741e-02
    z[6,5,4]  R2484     -2.0101411640644073e-01
    z[6,5,4]  R2485     2.5490963459014893e-01
    z[6,5,4]  R2486     -2.0636771619319916e-01
    z[6,5,4]  R2487     -3.5147297382354736e-01
    z[6,5,4]  R2488     -2.7333977818489075e-01
    z[6,5,4]  R2489     -2.7641248703002930e-01
    z[6,5,4]  R2490     -9.0551199391484261e-03
    z[6,5,4]  R2491     4.5610601082444191e-03
    z[6,5,4]  R2492     -2.5453658774495125e-02
    z[6,5,4]  R2493     1.8933297833427787e-03
    z[6,5,4]  R2494     2.8246089816093445e-01
    z[6,5,4]  R2495     4.6399328112602234e-01
    z[6,5,4]  R2496     2.2853070870041847e-02
    z[6,5,4]  R2497     -6.0383808612823486e-01
    z[6,5,4]  R2498     1.5979662537574768e-02
    z[6,5,4]  R2499     -8.3219580352306366e-02
    z[6,5,4]  R2500     -2.7004875242710114e-02
    z[6,5,4]  R2501     -2.6455727219581604e-01
    z[6,5,4]  R2502     -3.9190530776977539e-01
    z[6,5,4]  R2503     3.9881461858749390e-01
    z[6,5,4]  R2504     2.8546103276312351e-03
    z[6,5,4]  R2505     -1.5324451029300690e-01
    z[6,5,4]  R2506     -4.2493742704391479e-01
    z[6,5,4]  R2507     -2.5676766037940979e-01
    z[6,5,4]  R2508     7.0771694183349609e-02
    z[6,5,4]  R2509     -1.5333485603332520e-01
    z[6,5,4]  R2510     1.9122689962387085e-01
    z[6,5,4]  R2511     -0.550078272819519
    z[6,5,4]  R2512     3.3858400583267212e-01
    z[6,5,4]  R2513     4.3738394975662231e-01
    z[6,5,4]  R2514     -4.3129265308380127e-01
    z[6,5,4]  R2515     6.0318976640701294e-01
    z[6,5,4]  R2516     -5.9991395473480225e-01
    z[6,5,4]  R2517     -0.379001647233963
    z[6,5,4]  R2518     -3.0295750498771667e-01
    z[6,5,4]  R2519     -1.4633558690547943e-02
    z[6,5,4]  R2520     4.1551116108894348e-01
    z[6,5,4]  R2521     -3.4798362851142883e-01
    z[6,5,4]  R2522     -0.0678536519408226
    z[6,5,4]  R2523     -6.4541742205619812e-02
    z[6,5,4]  R2524     9.0936217457056046e-03
    z[6,5,4]  R2525     -3.0608716607093811e-01
    z[6,5,4]  R2526     2.4496251344680786e-01
    z[6,5,4]  R2527     -6.2972551584243774e-01
    z[6,5,4]  R2528     0.0307974424213171
    z[6,5,4]  R2529     -4.2809373140335083e-01
    z[6,5,4]  R2530     -1.5423774719238281e-01
    z[6,5,4]  R2531     2.0271413028240204e-01
    z[6,5,4]  R2532     2.6255783438682556e-01
    z[6,5,4]  R2533     4.0326413512229919e-01
    z[6,5,4]  R2534     1.6242672502994537e-01
    z[6,5,4]  R2535     -2.8086664155125618e-02
    z[6,5,4]  R2536     3.9591252803802490e-01
    z[6,5,4]  R2537     1.4629776775836945e-01
    z[6,5,4]  R2538     1.8903563916683197e-01
    z[6,5,4]  R2539     1.3146454095840454e-01
    z[6,5,4]  R2540     -1.2828269600868225e-01
    z[6,5,4]  R2541     -3.3598041534423828e-01
    z[6,5,4]  R2542     1.7064245045185089e-01
    z[6,5,4]  R2543     1.7576907575130463e-01
    z[6,5,4]  R2544     -9.3462634831666946e-03
    z[6,5,4]  R2545     6.0886070132255554e-02
    z[6,5,4]  R2546     1.1964366585016251e-01
    z[6,5,4]  R2547     1.8079565837979317e-02
    z[6,5,4]  R2548     -5.3978666663169861e-02
    z[6,5,4]  R2549     -1.0950735211372375e-01
    z[6,5,4]  R2550     -1.6522422432899475e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2462     -1
    z[6,5,5]  R2463     1
    z[6,5,5]  R2466     1.4739826321601868e-01
    z[6,5,5]  R2467     3.7568813562393188e-01
    z[6,5,5]  R2468     2.4111062288284302e-01
    z[6,5,5]  R2469     2.4034756422042847e-01
    z[6,5,5]  R2470     1.9551150500774384e-01
    z[6,5,5]  R2471     0.446159690618515
    z[6,5,5]  R2472     5.6286835670471191e-01
    z[6,5,5]  R2473     2.3995193839073181e-01
    z[6,5,5]  R2474     -2.5375589728355408e-01
    z[6,5,5]  R2475     1.7624123394489288e-01
    z[6,5,5]  R2476     -2.7007976174354553e-01
    z[6,5,5]  R2477     -1.9779351353645325e-01
    z[6,5,5]  R2478     -1.8678367137908936e-01
    z[6,5,5]  R2479     1.6880062222480774e-01
    z[6,5,5]  R2480     1.0740427672863007e-01
    z[6,5,5]  R2481     -3.6001911759376526e-01
    z[6,5,5]  R2482     -5.4434555768966675e-01
    z[6,5,5]  R2483     -4.6388161182403564e-01
    z[6,5,5]  R2484     -5.7261552661657333e-02
    z[6,5,5]  R2485     -2.7936546131968498e-02
    z[6,5,5]  R2486     2.1938018035143614e-03
    z[6,5,5]  R2487     -2.8313118219375610e-01
    z[6,5,5]  R2488     -1.6117073595523834e-01
    z[6,5,5]  R2489     -6.0378503799438477e-01
    z[6,5,5]  R2490     4.8354521393775940e-02
    z[6,5,5]  R2491     7.4749879539012909e-02
    z[6,5,5]  R2492     -0.0522022470831871
    z[6,5,5]  R2493     -1.2488479726016521e-02
    z[6,5,5]  R2494     -3.5223349928855896e-02
    z[6,5,5]  R2495     3.6601489782333374e-01
    z[6,5,5]  R2496     2.6328054070472717e-01
    z[6,5,5]  R2497     -1.0909955948591232e-01
    z[6,5,5]  R2498     -1.3134272396564484e-01
    z[6,5,5]  R2499     -2.0239748060703278e-01
    z[6,5,5]  R2500     -5.0938504934310913e-01
    z[6,5,5]  R2501     3.9223301410675049e-01
    z[6,5,5]  R2502     1.8908958137035370e-01
    z[6,5,5]  R2503     2.9697835445404053e-01
    z[6,5,5]  R2504     -0.094648078083992
    z[6,5,5]  R2505     -6.2566363811492920e-01
    z[6,5,5]  R2506     1.2184092402458191e-01
    z[6,5,5]  R2507     3.8845051079988480e-02
    z[6,5,5]  R2508     -2.2432367503643036e-01
    z[6,5,5]  R2509     2.8363940119743347e-01
    z[6,5,5]  R2510     -4.7483119368553162e-01
    z[6,5,5]  R2511     4.4464193284511566e-02
    z[6,5,5]  R2512     -1.1897812038660049e-01
    z[6,5,5]  R2513     -8.9154131710529327e-02
    z[6,5,5]  R2514     -1.9231611490249634e-01
    z[6,5,5]  R2515     -4.5176412910223007e-02
    z[6,5,5]  R2516     -1.7778746783733368e-01
    z[6,5,5]  R2517     6.0651585459709167e-02
    z[6,5,5]  R2518     -2.0021903514862061e-01
    z[6,5,5]  R2519     -2.6244255900382996e-01
    z[6,5,5]  R2520     -1.3724821805953979e-01
    z[6,5,5]  R2521     3.7022197246551514e-01
    z[6,5,5]  R2522     3.4839814901351929e-01
    z[6,5,5]  R2523     -1.9910946488380432e-01
    z[6,5,5]  R2524     -2.5163310766220093e-01
    z[6,5,5]  R2525     3.2501003146171570e-01
    z[6,5,5]  R2526     -3.9929196238517761e-01
    z[6,5,5]  R2527     -2.4968470633029938e-01
    z[6,5,5]  R2528     -5.5485677719116211e-01
    z[6,5,5]  R2529     -4.7112739086151123e-01
    z[6,5,5]  R2530     3.3411204814910889e-01
    z[6,5,5]  R2531     2.5637684389948845e-02
    z[6,5,5]  R2532     -2.4374802410602570e-01
    z[6,5,5]  R2533     1.5165130794048309e-01
    z[6,5,5]  R2534     -1.5895521640777588e-01
    z[6,5,5]  R2535     1.6387178003787994e-01
    z[6,5,5]  R2536     -3.0993044376373291e-02
    z[6,5,5]  R2537     -2.2050505876541138e-01
    z[6,5,5]  R2538     3.0824041366577148e-01
    z[6,5,5]  R2539     1.1866968125104904e-01
    z[6,5,5]  R2540     -1.0495049506425858e-01
    z[6,5,5]  R2541     5.2054870128631592e-01
    z[6,5,5]  R2542     0.147319495677948
    z[6,5,5]  R2543     2.0072488114237785e-02
    z[6,5,5]  R2544     1.0734124481678009e-01
    z[6,5,5]  R2545     1.9797259569168091e-01
    z[6,5,5]  R2546     7.8324370086193085e-02
    z[6,5,5]  R2547     2.6179236173629761e-01
    z[6,5,5]  R2548     -1.7094336450099945e-02
    z[6,5,5]  R2549     1.8547664582729340e-01
    z[6,5,5]  R2550     2.2930899262428284e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2464     -1
    z[6,5,6]  R2465     1
    z[6,5,6]  R2466     0.0797148197889328
    z[6,5,6]  R2467     1.7736832797527313e-01
    z[6,5,6]  R2468     -8.2950927317142487e-02
    z[6,5,6]  R2469     -7.9377971589565277e-02
    z[6,5,6]  R2470     2.4014383554458618e-01
    z[6,5,6]  R2471     6.6895879805088043e-02
    z[6,5,6]  R2472     -1.1080216616392136e-01
    z[6,5,6]  R2473     3.1717082858085632e-01
    z[6,5,6]  R2474     7.7935561537742615e-02
    z[6,5,6]  R2475     -1.6237047314643860e-01
    z[6,5,6]  R2476     -6.1286713927984238e-02
    z[6,5,6]  R2477     -1.8329469859600067e-01
    z[6,5,6]  R2478     -1.1739210784435272e-01
    z[6,5,6]  R2479     -6.8392440676689148e-02
    z[6,5,6]  R2480     1.6138932108879089e-01
    z[6,5,6]  R2481     -3.8603687286376953e-01
    z[6,5,6]  R2482     -1.8159691244363785e-02
    z[6,5,6]  R2483     -0.25421342253685
    z[6,5,6]  R2484     1.9502714276313782e-01
    z[6,5,6]  R2485     -3.5569229722023010e-01
    z[6,5,6]  R2486     6.5111279487609863e-01
    z[6,5,6]  R2487     -2.1217620372772217e-01
    z[6,5,6]  R2488     2.6413185521960258e-02
    z[6,5,6]  R2489     2.6901605725288391e-01
    z[6,5,6]  R2490     1.8414634466171265e-01
    z[6,5,6]  R2491     -1.3079290091991425e-01
    z[6,5,6]  R2492     6.0909580439329147e-02
    z[6,5,6]  R2493     4.8238448798656464e-02
    z[6,5,6]  R2494     2.8042057529091835e-02
    z[6,5,6]  R2495     3.0011010169982910e-01
    z[6,5,6]  R2496     1.2375874817371368e-01
    z[6,5,6]  R2497     -1.5376168489456177e-01
    z[6,5,6]  R2498     0.0669020339846611
    z[6,5,6]  R2499     3.2456547021865845e-01
    z[6,5,6]  R2500     -4.6026620268821716e-01
    z[6,5,6]  R2501     -6.7944127321243286e-01
    z[6,5,6]  R2502     -1.8194955587387085e-01
    z[6,5,6]  R2503     -6.4635932445526123e-02
    z[6,5,6]  R2504     -2.2853240370750427e-01
    z[6,5,6]  R2505     2.6339176297187805e-01
    z[6,5,6]  R2506     -5.4281371831893921e-01
    z[6,5,6]  R2507     -6.4313375949859619e-01
    z[6,5,6]  R2508     2.7348589897155762e-01
    z[6,5,6]  R2509     -3.0346539616584778e-01
    z[6,5,6]  R2510     -1.8489879369735718e-01
    z[6,5,6]  R2511     6.4327597618103027e-01
    z[6,5,6]  R2512     1.3814416527748108e-01
    z[6,5,6]  R2513     -8.4790289402008057e-02
    z[6,5,6]  R2514     1.0809958726167679e-01
    z[6,5,6]  R2515     1.8006315827369690e-01
    z[6,5,6]  R2516     9.3888416886329651e-02
    z[6,5,6]  R2517     -1.2835410237312317e-01
    z[6,5,6]  R2518     1.2356420606374741e-01
    z[6,5,6]  R2519     -3.3267840743064880e-02
    z[6,5,6]  R2520     -2.4746958911418915e-01
    z[6,5,6]  R2521     3.1949594616889954e-01
    z[6,5,6]  R2522     5.8465325832366943e-01
    z[6,5,6]  R2523     -3.9723575115203857e-02
    z[6,5,6]  R2524     -9.9051259458065033e-03
    z[6,5,6]  R2525     2.0256226416677237e-03
    z[6,5,6]  R2526     -2.2172866761684418e-01
    z[6,5,6]  R2527     3.5137692093849182e-01
    z[6,5,6]  R2528     -1.8017850816249847e-01
    z[6,5,6]  R2529     5.5753654241561890e-01
    z[6,5,6]  R2530     -1.5387046337127686e-01
    z[6,5,6]  R2531     1.4287789165973663e-01
    z[6,5,6]  R2532     3.4167438279837370e-03
    z[6,5,6]  R2533     -4.4392615556716919e-02
    z[6,5,6]  R2534     3.1140625476837158e-01
    z[6,5,6]  R2535     1.1510109901428223e-01
    z[6,5,6]  R2536     -2.3166318237781525e-01
    z[6,5,6]  R2537     -8.5646532475948334e-02
    z[6,5,6]  R2538     -2.2045131027698517e-01
    z[6,5,6]  R2539     -3.9121967554092407e-01
    z[6,5,6]  R2540     2.5514401495456696e-02
    z[6,5,6]  R2541     -4.3780177831649780e-01
    z[6,5,6]  R2542     -1.5390457212924957e-01
    z[6,5,6]  R2543     1.3502325117588043e-01
    z[6,5,6]  R2544     -9.4142660498619080e-02
    z[6,5,6]  R2545     4.4523306190967560e-02
    z[6,5,6]  R2546     -1.0987244546413422e-01
    z[6,5,6]  R2547     2.0463684201240540e-01
    z[6,5,6]  R2548     4.1273102164268494e-02
    z[6,5,6]  R2549     -4.1673827916383743e-02
    z[6,5,6]  R2550     1.0447089374065399e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,8]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[7,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
