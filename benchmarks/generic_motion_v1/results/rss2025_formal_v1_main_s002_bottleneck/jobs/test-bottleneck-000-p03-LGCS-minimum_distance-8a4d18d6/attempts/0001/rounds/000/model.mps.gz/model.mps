NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 E  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  R2949   
 L  R2950   
 L  R2951   
 L  R2952   
 L  R2953   
 L  R2954   
 L  R2955   
 L  R2956   
 L  R2957   
 L  R2958   
 L  R2959   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -3.0999999046325684e+00
    phi[0,1]  R58       -2.2400000095367432e+00
    phi[0,1]  R59       -2.2400000095367432e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       -3.0999999046325684e+00
    phi[0,1]  R62       -2.5699999332427979e+00
    phi[0,1]  R63       -2.5699999332427979e+00
    phi[0,1]  R64       -3.0999999046325684e+00
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -2.0899999141693115e+00
    phi[0,1]  R67       -2.0899999141693115e+00
    phi[0,1]  R68       -3.0999999046325684e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       1.3602677583694458e+00
    phi[0,1]  R71       2.7055171132087708e-01
    phi[0,1]  R72       2.4005296230316162e+00
    phi[0,1]  R73       1.3617920875549316e+00
    phi[0,1]  R74       1.6018239259719849e+00
    phi[0,1]  R75       1.3491890430450439e+00
    phi[0,1]  R76       2.5719521045684814e+00
    phi[0,1]  R77       1.8583847284317017e+00
    phi[0,1]  R78       1.8208051919937134e+00
    phi[0,1]  R79       0.589028000831604
    phi[0,1]  R80       2.9540500044822693e-01
    phi[0,1]  R81       1.2112158536911011e+00
    phi[0,1]  R82       7.3953866958618164e-01
    phi[0,1]  R83       1.0209403038024902e+00
    phi[0,1]  R84       1.6282215118408203e+00
    phi[0,1]  R85       1.2645679712295532e+00
    phi[0,1]  R86       1.6082936525344849e+00
    phi[0,1]  R87       -1.5375145673751831e+00
    phi[0,1]  R88       6.4828239381313324e-02
    phi[0,1]  R89       -5.1066613197326660e-01
    phi[0,1]  R90       -3.1196110248565674e+00
    phi[0,1]  R91       -2.6037940979003906e+00
    phi[0,1]  R92       -2.3985478878021240e+00
    phi[0,1]  R93       -2.1865534782409668e+00
    phi[0,1]  R94       -2.6935071945190430e+00
    phi[0,1]  R95       -2.8112204074859619e+00
    phi[0,1]  R96       -5.8996045589447021e-01
    phi[0,1]  R97       -7.2608333826065063e-01
    phi[0,1]  R98       -2.1133575439453125e+00
    phi[0,1]  R99       -1.1701444536447525e-01
    phi[0,1]  R100      -5.4809492826461792e-01
    phi[0,1]  R101      -2.9646465554833412e-02
    phi[0,1]  R102      -1.3311643600463867e+00
    phi[0,1]  R103      1.5019978284835815e+00
    phi[0,1]  R104      -1.8108361959457397e+00
    phi[0,1]  R105      3.6591702699661255e-01
    phi[0,1]  R106      1.4511874318122864e-01
    phi[0,1]  R107      -1.7963277101516724e+00
    phi[0,1]  R108      -5.7696402072906494e-01
    phi[0,1]  R109      -1.4379826784133911e+00
    phi[0,1]  R110      -1.0776628255844116e+00
    phi[0,1]  R111      -1.9423660039901733e+00
    phi[0,1]  R112      -1.5833895206451416e+00
    phi[0,1]  R113      -4.5447218418121338e-01
    phi[0,1]  R114      -1.7811095714569092e+00
    phi[0,1]  R115      8.7243437767028809e-01
    phi[0,1]  R116      9.9866008758544922e-01
    phi[0,1]  R117      1.8859788179397583e+00
    phi[0,1]  R118      2.3252339363098145e+00
    phi[0,1]  R119      8.9576977491378784e-01
    phi[0,1]  R120      2.3177416324615479e+00
    phi[0,1]  R121      1.0229849815368652e+00
    phi[0,1]  R122      1.8618718385696411e+00
    phi[0,1]  R123      1.5483042001724243e+00
    phi[0,1]  R124      1.0634642839431763e+00
    phi[0,1]  R125      5.9582251310348511e-01
    phi[0,1]  R126      1.5003855228424072e+00
    phi[0,1]  R127      1.4370466470718384e+00
    phi[0,1]  R128      1.14961576461792
    phi[0,1]  R129      -1.2506283521652222e+00
    phi[0,1]  R130      -2.6491055488586426e+00
    phi[0,1]  R131      -0.734790027141571
    phi[0,1]  R132      -1.3301668167114258e+00
    phi[0,1]  R133      -0.565537691116333
    phi[0,1]  R134      -1.0590000152587891e+00
    phi[0,1]  R135      -1.9945701956748962e-01
    phi[0,1]  R136      -5.7601881027221680e-01
    phi[0,1]  R137      -1.6719383001327515e+00
    phi[0,1]  R138      6.1011922359466553e-01
    phi[0,1]  R139      -1.9048795700073242e+00
    phi[0,1]  R140      -5.6648331880569458e-01
    phi[0,1]  R141      -1.3211433887481689e+00
    phi[0,1]  R142      -3.0567786097526550e-01
    phi[0,1]  R143      -2.2654335498809814e+00
    phi[0,1]  R144      7.4582028388977051e-01
    phi[0,1]  R145      5.2988183498382568e-01
    phi[0,1]  R146      -7.6020592451095581e-01
    phi[0,1]  R147      -1.1085723638534546e+00
    phi[0,1]  R148      -4.0235871076583862e-01
    phi[0,1]  R149      -2.3107893764972687e-01
    phi[0,1]  R150      -1.4806872606277466e-01
    phi[0,1]  R151      8.1394004821777344e-01
    phi[0,1]  R152      4.9786585569381714e-01
    phi[0,1]  R153      7.8848814964294434e-01
    phi[0,1]  R154      -1.8302508592605591e+00
    phi[0,1]  R155      -2.9642195701599121e+00
    phi[0,1]  R156      -2.9077537059783936e+00
    phi[0,1]  R157      -1.4600787162780762e+00
    phi[0,1]  R158      -2.87412166595459
    phi[0,1]  R159      -3.3667697906494141e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R160      -3.0999999046325684e+00
    phi[1,0]  R161      -3.0999999046325684e+00
    phi[1,0]  R162      -2.2400000095367432e+00
    phi[1,0]  R163      -2.2400000095367432e+00
    phi[1,0]  R164      -3.0999999046325684e+00
    phi[1,0]  R165      -3.0999999046325684e+00
    phi[1,0]  R166      -2.5699999332427979e+00
    phi[1,0]  R167      -2.5699999332427979e+00
    phi[1,0]  R168      -3.0999999046325684e+00
    phi[1,0]  R169      -3.0999999046325684e+00
    phi[1,0]  R170      -2.0899999141693115e+00
    phi[1,0]  R171      -2.0899999141693115e+00
    phi[1,0]  R172      -3.0999999046325684e+00
    phi[1,0]  R173      -3.0999999046325684e+00
    phi[1,0]  R174      2.3177416324615479e+00
    phi[1,0]  R175      1.0229849815368652e+00
    phi[1,0]  R176      1.8618718385696411e+00
    phi[1,0]  R177      1.5483042001724243e+00
    phi[1,0]  R178      1.0634642839431763e+00
    phi[1,0]  R179      5.9582251310348511e-01
    phi[1,0]  R180      1.5003855228424072e+00
    phi[1,0]  R181      1.4370466470718384e+00
    phi[1,0]  R182      1.14961576461792
    phi[1,0]  R183      -1.2506283521652222e+00
    phi[1,0]  R184      -2.6491055488586426e+00
    phi[1,0]  R185      -0.734790027141571
    phi[1,0]  R186      -1.3301668167114258e+00
    phi[1,0]  R187      -0.565537691116333
    phi[1,0]  R188      -1.0590000152587891e+00
    phi[1,0]  R189      -1.9945701956748962e-01
    phi[1,0]  R190      -5.7601881027221680e-01
    phi[1,0]  R191      -1.6719383001327515e+00
    phi[1,0]  R192      6.1011922359466553e-01
    phi[1,0]  R193      -1.9048795700073242e+00
    phi[1,0]  R194      -5.6648331880569458e-01
    phi[1,0]  R195      -1.3211433887481689e+00
    phi[1,0]  R196      -3.0567786097526550e-01
    phi[1,0]  R197      -2.2654335498809814e+00
    phi[1,0]  R198      7.4582028388977051e-01
    phi[1,0]  R199      5.2988183498382568e-01
    phi[1,0]  R200      -7.6020592451095581e-01
    phi[1,0]  R201      -1.1085723638534546e+00
    phi[1,0]  R202      -4.0235871076583862e-01
    phi[1,0]  R203      -2.3107893764972687e-01
    phi[1,0]  R204      -1.4806872606277466e-01
    phi[1,0]  R205      8.1394004821777344e-01
    phi[1,0]  R206      4.9786585569381714e-01
    phi[1,0]  R207      7.8848814964294434e-01
    phi[1,0]  R208      -1.8302508592605591e+00
    phi[1,0]  R209      -2.9642195701599121e+00
    phi[1,0]  R210      -2.9077537059783936e+00
    phi[1,0]  R211      -1.4600787162780762e+00
    phi[1,0]  R212      -2.87412166595459
    phi[1,0]  R213      -3.3667697906494141e+00
    phi[1,0]  R214      1.3602677583694458e+00
    phi[1,0]  R215      2.7055171132087708e-01
    phi[1,0]  R216      2.4005296230316162e+00
    phi[1,0]  R217      1.3617920875549316e+00
    phi[1,0]  R218      1.6018239259719849e+00
    phi[1,0]  R219      1.3491890430450439e+00
    phi[1,0]  R220      2.5719521045684814e+00
    phi[1,0]  R221      1.8583847284317017e+00
    phi[1,0]  R222      1.8208051919937134e+00
    phi[1,0]  R223      0.589028000831604
    phi[1,0]  R224      2.9540500044822693e-01
    phi[1,0]  R225      1.2112158536911011e+00
    phi[1,0]  R226      7.3953866958618164e-01
    phi[1,0]  R227      1.0209403038024902e+00
    phi[1,0]  R228      1.6282215118408203e+00
    phi[1,0]  R229      1.2645679712295532e+00
    phi[1,0]  R230      1.6082936525344849e+00
    phi[1,0]  R231      -1.5375145673751831e+00
    phi[1,0]  R232      6.4828239381313324e-02
    phi[1,0]  R233      -5.1066613197326660e-01
    phi[1,0]  R234      -3.1196110248565674e+00
    phi[1,0]  R235      -2.6037940979003906e+00
    phi[1,0]  R236      -2.3985478878021240e+00
    phi[1,0]  R237      -2.1865534782409668e+00
    phi[1,0]  R238      -2.6935071945190430e+00
    phi[1,0]  R239      -2.8112204074859619e+00
    phi[1,0]  R240      -5.8996045589447021e-01
    phi[1,0]  R241      -7.2608333826065063e-01
    phi[1,0]  R242      -2.1133575439453125e+00
    phi[1,0]  R243      -1.1701444536447525e-01
    phi[1,0]  R244      -5.4809492826461792e-01
    phi[1,0]  R245      -2.9646465554833412e-02
    phi[1,0]  R246      -1.3311643600463867e+00
    phi[1,0]  R247      1.5019978284835815e+00
    phi[1,0]  R248      -1.8108361959457397e+00
    phi[1,0]  R249      3.6591702699661255e-01
    phi[1,0]  R250      1.4511874318122864e-01
    phi[1,0]  R251      -1.7963277101516724e+00
    phi[1,0]  R252      -5.7696402072906494e-01
    phi[1,0]  R253      -1.4379826784133911e+00
    phi[1,0]  R254      -1.0776628255844116e+00
    phi[1,0]  R255      -1.9423660039901733e+00
    phi[1,0]  R256      -1.5833895206451416e+00
    phi[1,0]  R257      -4.5447218418121338e-01
    phi[1,0]  R258      -1.7811095714569092e+00
    phi[1,0]  R259      8.7243437767028809e-01
    phi[1,0]  R260      9.9866008758544922e-01
    phi[1,0]  R261      1.8859788179397583e+00
    phi[1,0]  R262      2.3252339363098145e+00
    phi[1,0]  R263      8.9576977491378784e-01
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R264      -3.0999999046325684e+00
    phi[0,3]  R265      -3.0999999046325684e+00
    phi[0,3]  R266      -2.2400000095367432e+00
    phi[0,3]  R267      -2.2400000095367432e+00
    phi[0,3]  R268      -3.0999999046325684e+00
    phi[0,3]  R269      -3.0999999046325684e+00
    phi[0,3]  R270      -2.5699999332427979e+00
    phi[0,3]  R271      -2.5699999332427979e+00
    phi[0,3]  R272      -3.0999999046325684e+00
    phi[0,3]  R273      -3.0999999046325684e+00
    phi[0,3]  R274      -2.0899999141693115e+00
    phi[0,3]  R275      -2.0899999141693115e+00
    phi[0,3]  R276      -3.0999999046325684e+00
    phi[0,3]  R277      -3.0999999046325684e+00
    phi[0,3]  R278      1.3602677583694458e+00
    phi[0,3]  R279      2.7055171132087708e-01
    phi[0,3]  R280      2.4005296230316162e+00
    phi[0,3]  R281      1.3617920875549316e+00
    phi[0,3]  R282      1.6018239259719849e+00
    phi[0,3]  R283      1.3491890430450439e+00
    phi[0,3]  R284      2.5719521045684814e+00
    phi[0,3]  R285      1.8583847284317017e+00
    phi[0,3]  R286      1.8208051919937134e+00
    phi[0,3]  R287      0.589028000831604
    phi[0,3]  R288      2.9540500044822693e-01
    phi[0,3]  R289      1.2112158536911011e+00
    phi[0,3]  R290      7.3953866958618164e-01
    phi[0,3]  R291      1.0209403038024902e+00
    phi[0,3]  R292      1.6282215118408203e+00
    phi[0,3]  R293      1.2645679712295532e+00
    phi[0,3]  R294      1.6082936525344849e+00
    phi[0,3]  R295      -1.5375145673751831e+00
    phi[0,3]  R296      6.4828239381313324e-02
    phi[0,3]  R297      -5.1066613197326660e-01
    phi[0,3]  R298      -3.1196110248565674e+00
    phi[0,3]  R299      -2.6037940979003906e+00
    phi[0,3]  R300      -2.3985478878021240e+00
    phi[0,3]  R301      -2.1865534782409668e+00
    phi[0,3]  R302      -2.6935071945190430e+00
    phi[0,3]  R303      -2.8112204074859619e+00
    phi[0,3]  R304      -5.8996045589447021e-01
    phi[0,3]  R305      -7.2608333826065063e-01
    phi[0,3]  R306      -2.1133575439453125e+00
    phi[0,3]  R307      -1.1701444536447525e-01
    phi[0,3]  R308      -5.4809492826461792e-01
    phi[0,3]  R309      -2.9646465554833412e-02
    phi[0,3]  R310      -1.3311643600463867e+00
    phi[0,3]  R311      1.5019978284835815e+00
    phi[0,3]  R312      -1.8108361959457397e+00
    phi[0,3]  R313      3.6591702699661255e-01
    phi[0,3]  R314      1.4511874318122864e-01
    phi[0,3]  R315      -1.7963277101516724e+00
    phi[0,3]  R316      -5.7696402072906494e-01
    phi[0,3]  R317      -1.4379826784133911e+00
    phi[0,3]  R318      -1.0776628255844116e+00
    phi[0,3]  R319      -1.9423660039901733e+00
    phi[0,3]  R320      -1.5833895206451416e+00
    phi[0,3]  R321      -4.5447218418121338e-01
    phi[0,3]  R322      -1.7811095714569092e+00
    phi[0,3]  R323      8.7243437767028809e-01
    phi[0,3]  R324      9.9866008758544922e-01
    phi[0,3]  R325      1.8859788179397583e+00
    phi[0,3]  R326      2.3252339363098145e+00
    phi[0,3]  R327      8.9576977491378784e-01
    phi[0,3]  R328      1.4070525169372559e+00
    phi[0,3]  R329      -1.8637837171554565e+00
    phi[0,3]  R330      1.9244442880153656e-01
    phi[0,3]  R331      1.3560693264007568e+00
    phi[0,3]  R332      1.4406063556671143e+00
    phi[0,3]  R333      1.7186269164085388e-01
    phi[0,3]  R334      -9.3275710940361023e-02
    phi[0,3]  R335      1.7816181182861328e+00
    phi[0,3]  R336      -6.4245003461837769e-01
    phi[0,3]  R337      2.9749801754951477e-01
    phi[0,3]  R338      -4.4891899824142456e-01
    phi[0,3]  R339      -3.1700937747955322e+00
    phi[0,3]  R340      -1.9243576526641846e+00
    phi[0,3]  R341      -1.5361006259918213e+00
    phi[0,3]  R342      -2.4537868499755859e+00
    phi[0,3]  R343      -3.2084760665893555e+00
    phi[0,3]  R344      -1.2035303115844727e+00
    phi[0,3]  R345      5.1626634597778320e-01
    phi[0,3]  R346      -2.7643303871154785e+00
    phi[0,3]  R347      -1.2511644363403320e+00
    phi[0,3]  R348      -5.4061406850814819e-01
    phi[0,3]  R349      -1.7634431123733521e+00
    phi[0,3]  R350      -2.9313471913337708e-01
    phi[0,3]  R351      -1.9044030904769897e+00
    phi[0,3]  R352      -1.1824598312377930e+00
    phi[0,3]  R353      1.4344557523727417e+00
    phi[0,3]  R354      1.2335806339979172e-01
    phi[0,3]  R355      -2.3884711265563965e+00
    phi[0,3]  R356      -9.5272518694400787e-02
    phi[0,3]  R357      -3.4296461939811707e-01
    phi[0,3]  R358      -6.0556423664093018e-01
    phi[0,3]  R359      -1.6014730930328369e+00
    phi[0,3]  R360      2.5656518340110779e-01
    phi[0,3]  R361      -4.1291669011116028e-02
    phi[0,3]  R362      -2.9346027374267578e+00
    phi[0,3]  R363      1.9327629357576370e-02
    phi[0,3]  R364      -1.6578621864318848e+00
    phi[0,3]  R365      -6.2594634294509888e-01
    phi[0,3]  R366      -1.3554449081420898e+00
    phi[0,3]  R367      -1.1527673006057739e+00
    phi[0,3]  R368      -2.4211235046386719e+00
    phi[0,3]  R369      -6.8074566125869751e-01
    phi[0,3]  R370      1.0860924720764160e+00
    phi[0,3]  R371      0.00563911022618413
    phi[0,3]  R372      7.8278881311416626e-01
    phi[0,3]  R373      -1.0468118190765381e+00
    phi[0,3]  R374      -2.9776937961578369e+00
    phi[0,3]  R375      -1.0210758447647095e+00
    phi[0,3]  R376      -2.3779196739196777e+00
    phi[0,3]  R377      -1.4153889417648315e+00
    phi[0,3]  R378      -9.5132905244827271e-01
    phi[0,3]  R379      1.9264270365238190e-01
    phi[0,3]  R380      1.0570249557495117e+00
    phi[0,3]  R381      -7.4598133563995361e-01
    phi[0,3]  R382      -2.8410035371780396e-01
    phi[0,3]  R383      -1.5174251794815063e+00
    phi[0,3]  R384      1.88840651512146
    phi[0,3]  R385      1.1256448030471802e+00
    phi[0,3]  R386      1.28672194480896
    phi[0,3]  R387      1.1664819717407227e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R388      -3.0999999046325684e+00
    phi[3,0]  R389      -3.0999999046325684e+00
    phi[3,0]  R390      -2.2400000095367432e+00
    phi[3,0]  R391      -2.2400000095367432e+00
    phi[3,0]  R392      -3.0999999046325684e+00
    phi[3,0]  R393      -3.0999999046325684e+00
    phi[3,0]  R394      -2.5699999332427979e+00
    phi[3,0]  R395      -2.5699999332427979e+00
    phi[3,0]  R396      -3.0999999046325684e+00
    phi[3,0]  R397      -3.0999999046325684e+00
    phi[3,0]  R398      -2.0899999141693115e+00
    phi[3,0]  R399      -2.0899999141693115e+00
    phi[3,0]  R400      -3.0999999046325684e+00
    phi[3,0]  R401      -3.0999999046325684e+00
    phi[3,0]  R402      1.4070525169372559e+00
    phi[3,0]  R403      -1.8637837171554565e+00
    phi[3,0]  R404      1.9244442880153656e-01
    phi[3,0]  R405      1.3560693264007568e+00
    phi[3,0]  R406      1.4406063556671143e+00
    phi[3,0]  R407      1.7186269164085388e-01
    phi[3,0]  R408      -9.3275710940361023e-02
    phi[3,0]  R409      1.7816181182861328e+00
    phi[3,0]  R410      -6.4245003461837769e-01
    phi[3,0]  R411      2.9749801754951477e-01
    phi[3,0]  R412      -4.4891899824142456e-01
    phi[3,0]  R413      -3.1700937747955322e+00
    phi[3,0]  R414      -1.9243576526641846e+00
    phi[3,0]  R415      -1.5361006259918213e+00
    phi[3,0]  R416      -2.4537868499755859e+00
    phi[3,0]  R417      -3.2084760665893555e+00
    phi[3,0]  R418      -1.2035303115844727e+00
    phi[3,0]  R419      5.1626634597778320e-01
    phi[3,0]  R420      -2.7643303871154785e+00
    phi[3,0]  R421      -1.2511644363403320e+00
    phi[3,0]  R422      -5.4061406850814819e-01
    phi[3,0]  R423      -1.7634431123733521e+00
    phi[3,0]  R424      -2.9313471913337708e-01
    phi[3,0]  R425      -1.9044030904769897e+00
    phi[3,0]  R426      -1.1824598312377930e+00
    phi[3,0]  R427      1.4344557523727417e+00
    phi[3,0]  R428      1.2335806339979172e-01
    phi[3,0]  R429      -2.3884711265563965e+00
    phi[3,0]  R430      -9.5272518694400787e-02
    phi[3,0]  R431      -3.4296461939811707e-01
    phi[3,0]  R432      -6.0556423664093018e-01
    phi[3,0]  R433      -1.6014730930328369e+00
    phi[3,0]  R434      2.5656518340110779e-01
    phi[3,0]  R435      -4.1291669011116028e-02
    phi[3,0]  R436      -2.9346027374267578e+00
    phi[3,0]  R437      1.9327629357576370e-02
    phi[3,0]  R438      -1.6578621864318848e+00
    phi[3,0]  R439      -6.2594634294509888e-01
    phi[3,0]  R440      -1.3554449081420898e+00
    phi[3,0]  R441      -1.1527673006057739e+00
    phi[3,0]  R442      -2.4211235046386719e+00
    phi[3,0]  R443      -6.8074566125869751e-01
    phi[3,0]  R444      1.0860924720764160e+00
    phi[3,0]  R445      0.00563911022618413
    phi[3,0]  R446      7.8278881311416626e-01
    phi[3,0]  R447      -1.0468118190765381e+00
    phi[3,0]  R448      -2.9776937961578369e+00
    phi[3,0]  R449      -1.0210758447647095e+00
    phi[3,0]  R450      -2.3779196739196777e+00
    phi[3,0]  R451      -1.4153889417648315e+00
    phi[3,0]  R452      -9.5132905244827271e-01
    phi[3,0]  R453      1.9264270365238190e-01
    phi[3,0]  R454      1.0570249557495117e+00
    phi[3,0]  R455      -7.4598133563995361e-01
    phi[3,0]  R456      -2.8410035371780396e-01
    phi[3,0]  R457      -1.5174251794815063e+00
    phi[3,0]  R458      1.88840651512146
    phi[3,0]  R459      1.1256448030471802e+00
    phi[3,0]  R460      1.28672194480896
    phi[3,0]  R461      1.1664819717407227e+00
    phi[3,0]  R462      1.3602677583694458e+00
    phi[3,0]  R463      2.7055171132087708e-01
    phi[3,0]  R464      2.4005296230316162e+00
    phi[3,0]  R465      1.3617920875549316e+00
    phi[3,0]  R466      1.6018239259719849e+00
    phi[3,0]  R467      1.3491890430450439e+00
    phi[3,0]  R468      2.5719521045684814e+00
    phi[3,0]  R469      1.8583847284317017e+00
    phi[3,0]  R470      1.8208051919937134e+00
    phi[3,0]  R471      0.589028000831604
    phi[3,0]  R472      2.9540500044822693e-01
    phi[3,0]  R473      1.2112158536911011e+00
    phi[3,0]  R474      7.3953866958618164e-01
    phi[3,0]  R475      1.0209403038024902e+00
    phi[3,0]  R476      1.6282215118408203e+00
    phi[3,0]  R477      1.2645679712295532e+00
    phi[3,0]  R478      1.6082936525344849e+00
    phi[3,0]  R479      -1.5375145673751831e+00
    phi[3,0]  R480      6.4828239381313324e-02
    phi[3,0]  R481      -5.1066613197326660e-01
    phi[3,0]  R482      -3.1196110248565674e+00
    phi[3,0]  R483      -2.6037940979003906e+00
    phi[3,0]  R484      -2.3985478878021240e+00
    phi[3,0]  R485      -2.1865534782409668e+00
    phi[3,0]  R486      -2.6935071945190430e+00
    phi[3,0]  R487      -2.8112204074859619e+00
    phi[3,0]  R488      -5.8996045589447021e-01
    phi[3,0]  R489      -7.2608333826065063e-01
    phi[3,0]  R490      -2.1133575439453125e+00
    phi[3,0]  R491      -1.1701444536447525e-01
    phi[3,0]  R492      -5.4809492826461792e-01
    phi[3,0]  R493      -2.9646465554833412e-02
    phi[3,0]  R494      -1.3311643600463867e+00
    phi[3,0]  R495      1.5019978284835815e+00
    phi[3,0]  R496      -1.8108361959457397e+00
    phi[3,0]  R497      3.6591702699661255e-01
    phi[3,0]  R498      1.4511874318122864e-01
    phi[3,0]  R499      -1.7963277101516724e+00
    phi[3,0]  R500      -5.7696402072906494e-01
    phi[3,0]  R501      -1.4379826784133911e+00
    phi[3,0]  R502      -1.0776628255844116e+00
    phi[3,0]  R503      -1.9423660039901733e+00
    phi[3,0]  R504      -1.5833895206451416e+00
    phi[3,0]  R505      -4.5447218418121338e-01
    phi[3,0]  R506      -1.7811095714569092e+00
    phi[3,0]  R507      8.7243437767028809e-01
    phi[3,0]  R508      9.9866008758544922e-01
    phi[3,0]  R509      1.8859788179397583e+00
    phi[3,0]  R510      2.3252339363098145e+00
    phi[3,0]  R511      8.9576977491378784e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R512      -3.0999999046325684e+00
    phi[0,4]  R513      -3.0999999046325684e+00
    phi[0,4]  R514      -2.2400000095367432e+00
    phi[0,4]  R515      -2.2400000095367432e+00
    phi[0,4]  R516      -3.0999999046325684e+00
    phi[0,4]  R517      -3.0999999046325684e+00
    phi[0,4]  R518      -2.5699999332427979e+00
    phi[0,4]  R519      -2.5699999332427979e+00
    phi[0,4]  R520      -3.0999999046325684e+00
    phi[0,4]  R521      -3.0999999046325684e+00
    phi[0,4]  R522      -2.0899999141693115e+00
    phi[0,4]  R523      -2.0899999141693115e+00
    phi[0,4]  R524      -3.0999999046325684e+00
    phi[0,4]  R525      -3.0999999046325684e+00
    phi[0,4]  R526      1.3602677583694458e+00
    phi[0,4]  R527      2.7055171132087708e-01
    phi[0,4]  R528      2.4005296230316162e+00
    phi[0,4]  R529      1.3617920875549316e+00
    phi[0,4]  R530      1.6018239259719849e+00
    phi[0,4]  R531      1.3491890430450439e+00
    phi[0,4]  R532      2.5719521045684814e+00
    phi[0,4]  R533      1.8583847284317017e+00
    phi[0,4]  R534      1.8208051919937134e+00
    phi[0,4]  R535      0.589028000831604
    phi[0,4]  R536      2.9540500044822693e-01
    phi[0,4]  R537      1.2112158536911011e+00
    phi[0,4]  R538      7.3953866958618164e-01
    phi[0,4]  R539      1.0209403038024902e+00
    phi[0,4]  R540      1.6282215118408203e+00
    phi[0,4]  R541      1.2645679712295532e+00
    phi[0,4]  R542      1.6082936525344849e+00
    phi[0,4]  R543      -1.5375145673751831e+00
    phi[0,4]  R544      6.4828239381313324e-02
    phi[0,4]  R545      -5.1066613197326660e-01
    phi[0,4]  R546      -3.1196110248565674e+00
    phi[0,4]  R547      -2.6037940979003906e+00
    phi[0,4]  R548      -2.3985478878021240e+00
    phi[0,4]  R549      -2.1865534782409668e+00
    phi[0,4]  R550      -2.6935071945190430e+00
    phi[0,4]  R551      -2.8112204074859619e+00
    phi[0,4]  R552      -5.8996045589447021e-01
    phi[0,4]  R553      -7.2608333826065063e-01
    phi[0,4]  R554      -2.1133575439453125e+00
    phi[0,4]  R555      -1.1701444536447525e-01
    phi[0,4]  R556      -5.4809492826461792e-01
    phi[0,4]  R557      -2.9646465554833412e-02
    phi[0,4]  R558      -1.3311643600463867e+00
    phi[0,4]  R559      1.5019978284835815e+00
    phi[0,4]  R560      -1.8108361959457397e+00
    phi[0,4]  R561      3.6591702699661255e-01
    phi[0,4]  R562      1.4511874318122864e-01
    phi[0,4]  R563      -1.7963277101516724e+00
    phi[0,4]  R564      -5.7696402072906494e-01
    phi[0,4]  R565      -1.4379826784133911e+00
    phi[0,4]  R566      -1.0776628255844116e+00
    phi[0,4]  R567      -1.9423660039901733e+00
    phi[0,4]  R568      -1.5833895206451416e+00
    phi[0,4]  R569      -4.5447218418121338e-01
    phi[0,4]  R570      -1.7811095714569092e+00
    phi[0,4]  R571      8.7243437767028809e-01
    phi[0,4]  R572      9.9866008758544922e-01
    phi[0,4]  R573      1.8859788179397583e+00
    phi[0,4]  R574      2.3252339363098145e+00
    phi[0,4]  R575      8.9576977491378784e-01
    phi[0,4]  R576      1.0069933533668518e-01
    phi[0,4]  R577      2.0685143470764160e+00
    phi[0,4]  R578      5.1308560371398926e-01
    phi[0,4]  R579      -7.2219479084014893e-01
    phi[0,4]  R580      2.1128454208374023e+00
    phi[0,4]  R581      1.6501094102859497e+00
    phi[0,4]  R582      -6.7144048213958740e-01
    phi[0,4]  R583      -3.6677727103233337e-01
    phi[0,4]  R584      3.4622645378112793e-01
    phi[0,4]  R585      1.3843475282192230e-01
    phi[0,4]  R586      -2.6625173091888428e+00
    phi[0,4]  R587      -3.0162916183471680e+00
    phi[0,4]  R588      -2.6542499065399170e+00
    phi[0,4]  R589      -2.5950672626495361e+00
    phi[0,4]  R590      -2.3996124267578125e+00
    phi[0,4]  R591      -1.5645024776458740e+00
    phi[0,4]  R592      -2.0111243724823
    phi[0,4]  R593      3.8759976625442505e-01
    phi[0,4]  R594      -2.3692221641540527e+00
    phi[0,4]  R595      -6.8068438768386841e-01
    phi[0,4]  R596      7.5522202253341675e-01
    phi[0,4]  R597      -1.9150774478912354e+00
    phi[0,4]  R598      -3.5453069210052490e+00
    phi[0,4]  R599      -2.3972954750061035e+00
    phi[0,4]  R600      -2.0419905185699463e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R601      -3.0999999046325684e+00
    phi[4,0]  R602      -3.0999999046325684e+00
    phi[4,0]  R603      -2.2400000095367432e+00
    phi[4,0]  R604      -2.2400000095367432e+00
    phi[4,0]  R605      -3.0999999046325684e+00
    phi[4,0]  R606      -3.0999999046325684e+00
    phi[4,0]  R607      -2.5699999332427979e+00
    phi[4,0]  R608      -2.5699999332427979e+00
    phi[4,0]  R609      -3.0999999046325684e+00
    phi[4,0]  R610      -3.0999999046325684e+00
    phi[4,0]  R611      -2.0899999141693115e+00
    phi[4,0]  R612      -2.0899999141693115e+00
    phi[4,0]  R613      -3.0999999046325684e+00
    phi[4,0]  R614      -3.0999999046325684e+00
    phi[4,0]  R615      1.0069933533668518e-01
    phi[4,0]  R616      2.0685143470764160e+00
    phi[4,0]  R617      5.1308560371398926e-01
    phi[4,0]  R618      -7.2219479084014893e-01
    phi[4,0]  R619      2.1128454208374023e+00
    phi[4,0]  R620      1.6501094102859497e+00
    phi[4,0]  R621      -6.7144048213958740e-01
    phi[4,0]  R622      -3.6677727103233337e-01
    phi[4,0]  R623      3.4622645378112793e-01
    phi[4,0]  R624      1.3843475282192230e-01
    phi[4,0]  R625      -2.6625173091888428e+00
    phi[4,0]  R626      -3.0162916183471680e+00
    phi[4,0]  R627      -2.6542499065399170e+00
    phi[4,0]  R628      -2.5950672626495361e+00
    phi[4,0]  R629      -2.3996124267578125e+00
    phi[4,0]  R630      -1.5645024776458740e+00
    phi[4,0]  R631      -2.0111243724823
    phi[4,0]  R632      3.8759976625442505e-01
    phi[4,0]  R633      -2.3692221641540527e+00
    phi[4,0]  R634      -6.8068438768386841e-01
    phi[4,0]  R635      7.5522202253341675e-01
    phi[4,0]  R636      -1.9150774478912354e+00
    phi[4,0]  R637      -3.5453069210052490e+00
    phi[4,0]  R638      -2.3972954750061035e+00
    phi[4,0]  R639      -2.0419905185699463e+00
    phi[4,0]  R640      1.3602677583694458e+00
    phi[4,0]  R641      2.7055171132087708e-01
    phi[4,0]  R642      2.4005296230316162e+00
    phi[4,0]  R643      1.3617920875549316e+00
    phi[4,0]  R644      1.6018239259719849e+00
    phi[4,0]  R645      1.3491890430450439e+00
    phi[4,0]  R646      2.5719521045684814e+00
    phi[4,0]  R647      1.8583847284317017e+00
    phi[4,0]  R648      1.8208051919937134e+00
    phi[4,0]  R649      0.589028000831604
    phi[4,0]  R650      2.9540500044822693e-01
    phi[4,0]  R651      1.2112158536911011e+00
    phi[4,0]  R652      7.3953866958618164e-01
    phi[4,0]  R653      1.0209403038024902e+00
    phi[4,0]  R654      1.6282215118408203e+00
    phi[4,0]  R655      1.2645679712295532e+00
    phi[4,0]  R656      1.6082936525344849e+00
    phi[4,0]  R657      -1.5375145673751831e+00
    phi[4,0]  R658      6.4828239381313324e-02
    phi[4,0]  R659      -5.1066613197326660e-01
    phi[4,0]  R660      -3.1196110248565674e+00
    phi[4,0]  R661      -2.6037940979003906e+00
    phi[4,0]  R662      -2.3985478878021240e+00
    phi[4,0]  R663      -2.1865534782409668e+00
    phi[4,0]  R664      -2.6935071945190430e+00
    phi[4,0]  R665      -2.8112204074859619e+00
    phi[4,0]  R666      -5.8996045589447021e-01
    phi[4,0]  R667      -7.2608333826065063e-01
    phi[4,0]  R668      -2.1133575439453125e+00
    phi[4,0]  R669      -1.1701444536447525e-01
    phi[4,0]  R670      -5.4809492826461792e-01
    phi[4,0]  R671      -2.9646465554833412e-02
    phi[4,0]  R672      -1.3311643600463867e+00
    phi[4,0]  R673      1.5019978284835815e+00
    phi[4,0]  R674      -1.8108361959457397e+00
    phi[4,0]  R675      3.6591702699661255e-01
    phi[4,0]  R676      1.4511874318122864e-01
    phi[4,0]  R677      -1.7963277101516724e+00
    phi[4,0]  R678      -5.7696402072906494e-01
    phi[4,0]  R679      -1.4379826784133911e+00
    phi[4,0]  R680      -1.0776628255844116e+00
    phi[4,0]  R681      -1.9423660039901733e+00
    phi[4,0]  R682      -1.5833895206451416e+00
    phi[4,0]  R683      -4.5447218418121338e-01
    phi[4,0]  R684      -1.7811095714569092e+00
    phi[4,0]  R685      8.7243437767028809e-01
    phi[4,0]  R686      9.9866008758544922e-01
    phi[4,0]  R687      1.8859788179397583e+00
    phi[4,0]  R688      2.3252339363098145e+00
    phi[4,0]  R689      8.9576977491378784e-01
    phi[6,0]  R0        -1
    phi[6,0]  R2        1.5411984777004251e+00
    phi[6,0]  R3        1.5937597124709546e-01
    phi[6,0]  R4        -2.6647210384887563e+00
    phi[6,0]  R5        -3.2643547112847582e-01
    phi[6,0]  R6        -3.0484873781582817e+00
    phi[6,0]  R7        -2.7189703437146306e-01
    phi[6,0]  R8        2.7239790076438788e+00
    phi[6,0]  R54       1
    phi[6,0]  R690      -4.6411983823329930e+00
    phi[6,0]  R691      -1.5588014269321433e+00
    phi[6,0]  R692      -2.3993759807838386e+00
    phi[6,0]  R693      -2.0806240382896477e+00
    phi[6,0]  R694      -4.3527886614381206e-01
    phi[6,0]  R695      -5.7647209431213247e+00
    phi[6,0]  R696      -2.2435644621143220e+00
    phi[6,0]  R697      -2.8964354043712737e+00
    phi[6,0]  R698      -5.1512526474286613e-02
    phi[6,0]  R699      -6.14848728279085
    phi[6,0]  R700      -1.8181028797978485e+00
    phi[6,0]  R701      -2.3618969485407746e+00
    phi[6,0]  R702      -5.8239789122764467e+00
    phi[6,0]  R703      -3.7602089698868957e-01
    phi[6,0]  R704      -9.7409814997061872e-01
    phi[6,0]  R705      -1.6873335559579983e-01
    phi[6,0]  R706      -1.8236891389199084e+00
    phi[6,0]  R707      -6.4808953551426329e-01
    phi[6,0]  R708      -3.9583532473832150e-01
    phi[6,0]  R709      -1.1844521952877249e+00
    phi[6,0]  R710      -1.6943500850326041e+00
    phi[6,0]  R711      -1.5568407719608279e+00
    phi[6,0]  R712      -9.7011442324542507e-01
    phi[6,0]  R713      -9.7927476694893345e-01
    phi[6,0]  R714      -3.7723233192441930e-01
    phi[6,0]  R715      -3.8690474928216889e-01
    phi[6,0]  R716      -3.9181673560004593e-01
    phi[6,0]  R717      -4.1692998895800981e-01
    phi[6,0]  R718      -4.2460837389719686e-01
    phi[6,0]  R719      -4.2801217351142440e-01
    phi[6,0]  R720      -4.6001251107364327e-01
    phi[6,0]  R721      -4.8146199476732310e-01
    phi[6,0]  R722      -4.8903639157186396e-01
    phi[6,0]  R723      -4.8913905462770568e-01
    phi[6,0]  R724      -3.2159074873591953e-01
    phi[6,0]  R725      -3.3658935619538033e-01
    phi[6,0]  R726      -4.5590288598070594e-01
    phi[6,0]  R727      -8.3437348276771028e-01
    phi[6,0]  R728      -3.7336195409427164e-01
    phi[6,0]  R729      -3.7692362329392548e-01
    phi[6,0]  R730      -6.8141071374272477e-01
    phi[6,0]  R731      -1.9054981753336973e+00
    phi[6,0]  R732      -0.650472597280136
    phi[6,0]  R733      -6.6565801476460906e-01
    phi[6,0]  R734      -5.7972005610000044e-01
    phi[6,0]  R735      -6.2529528497418418e-01
    phi[6,0]  R736      -6.4427512729455272e-01
    phi[6,0]  R737      -0.650193460793199
    phi[6,0]  R738      -6.6263781291800083e-01
    phi[6,0]  R739      -6.7771431040329477e-01
    phi[6,0]  R740      -6.8705276711943708e-01
    phi[6,0]  R741      -6.8843979883882933e-01
    phi[6,0]  R742      -6.9427745929119611e-01
    phi[6,0]  R743      -7.0108602838660117e-01
    phi[6,0]  R744      -5.4787189389895352e-01
    phi[6,0]  R745      -6.2166304580289911e-01
    phi[6,0]  R746      -7.1717278036993770e-01
    phi[6,0]  R747      -7.3271357146418281e-01
    phi[6,0]  R748      -7.5407733128476573e-01
    phi[6,0]  R749      -7.9325189960870079e-01
    phi[6,0]  R750      -9.0145889473231255e-01
    phi[6,0]  R751      -9.0565644861807515e-01
    phi[6,0]  R752      -9.3646051914967732e-01
    phi[6,0]  R753      -1.1024053534333618e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R754      -3.0999999046325684e+00
    phi[1,2]  R755      -3.0999999046325684e+00
    phi[1,2]  R756      -2.2400000095367432e+00
    phi[1,2]  R757      -2.2400000095367432e+00
    phi[1,2]  R758      -3.0999999046325684e+00
    phi[1,2]  R759      -3.0999999046325684e+00
    phi[1,2]  R760      -2.5699999332427979e+00
    phi[1,2]  R761      -2.5699999332427979e+00
    phi[1,2]  R762      -3.0999999046325684e+00
    phi[1,2]  R763      -3.0999999046325684e+00
    phi[1,2]  R764      -2.0899999141693115e+00
    phi[1,2]  R765      -2.0899999141693115e+00
    phi[1,2]  R766      -3.0999999046325684e+00
    phi[1,2]  R767      -3.0999999046325684e+00
    phi[1,2]  R768      2.3177416324615479e+00
    phi[1,2]  R769      1.0229849815368652e+00
    phi[1,2]  R770      1.8618718385696411e+00
    phi[1,2]  R771      1.5483042001724243e+00
    phi[1,2]  R772      1.0634642839431763e+00
    phi[1,2]  R773      5.9582251310348511e-01
    phi[1,2]  R774      1.5003855228424072e+00
    phi[1,2]  R775      1.4370466470718384e+00
    phi[1,2]  R776      1.14961576461792
    phi[1,2]  R777      -1.2506283521652222e+00
    phi[1,2]  R778      -2.6491055488586426e+00
    phi[1,2]  R779      -0.734790027141571
    phi[1,2]  R780      -1.3301668167114258e+00
    phi[1,2]  R781      -0.565537691116333
    phi[1,2]  R782      -1.0590000152587891e+00
    phi[1,2]  R783      -1.9945701956748962e-01
    phi[1,2]  R784      -5.7601881027221680e-01
    phi[1,2]  R785      -1.6719383001327515e+00
    phi[1,2]  R786      6.1011922359466553e-01
    phi[1,2]  R787      -1.9048795700073242e+00
    phi[1,2]  R788      -5.6648331880569458e-01
    phi[1,2]  R789      -1.3211433887481689e+00
    phi[1,2]  R790      -3.0567786097526550e-01
    phi[1,2]  R791      -2.2654335498809814e+00
    phi[1,2]  R792      7.4582028388977051e-01
    phi[1,2]  R793      5.2988183498382568e-01
    phi[1,2]  R794      -7.6020592451095581e-01
    phi[1,2]  R795      -1.1085723638534546e+00
    phi[1,2]  R796      -4.0235871076583862e-01
    phi[1,2]  R797      -2.3107893764972687e-01
    phi[1,2]  R798      -1.4806872606277466e-01
    phi[1,2]  R799      8.1394004821777344e-01
    phi[1,2]  R800      4.9786585569381714e-01
    phi[1,2]  R801      7.8848814964294434e-01
    phi[1,2]  R802      -1.8302508592605591e+00
    phi[1,2]  R803      -2.9642195701599121e+00
    phi[1,2]  R804      -2.9077537059783936e+00
    phi[1,2]  R805      -1.4600787162780762e+00
    phi[1,2]  R806      -2.87412166595459
    phi[1,2]  R807      -3.3667697906494141e+00
    phi[1,2]  R808      1.4758145809173584e+00
    phi[1,2]  R809      1.1983867883682251e+00
    phi[1,2]  R810      3.0512848496437073e-01
    phi[1,2]  R811      -8.8237613439559937e-01
    phi[1,2]  R812      5.7116919755935669e-01
    phi[1,2]  R813      2.1738813817501068e-01
    phi[1,2]  R814      1.1170113086700439e+00
    phi[1,2]  R815      1.5647424459457397e+00
    phi[1,2]  R816      1.2970077991485596e+00
    phi[1,2]  R817      1.6711130142211914e+00
    phi[1,2]  R818      4.8250547051429749e-01
    phi[1,2]  R819      1.5181962251663208e+00
    phi[1,2]  R820      2.1828649044036865e+00
    phi[1,2]  R821      8.3552199602127075e-01
    phi[1,2]  R822      6.6989642381668091e-01
    phi[1,2]  R823      2.2758930921554565e-01
    phi[1,2]  R824      8.2934144884347916e-03
    phi[1,2]  R825      -0.709333062171936
    phi[1,2]  R826      -1.4077971875667572e-01
    phi[1,2]  R827      1.2257226705551147e+00
    phi[1,2]  R828      -3.4705410003662109e+00
    phi[1,2]  R829      -2.7444334030151367e+00
    phi[1,2]  R830      -2.4569869041442871e+00
    phi[1,2]  R831      -7.7916479110717773e-01
    phi[1,2]  R832      -6.5530169010162354e-01
    phi[1,2]  R833      -1.6433355212211609e-01
    phi[1,2]  R834      -5.1836383342742920e-01
    phi[1,2]  R835      -2.4087445735931396e+00
    phi[1,2]  R836      -2.1686570644378662e+00
    phi[1,2]  R837      -3.6034054756164551e+00
    phi[1,2]  R838      -2.6684200763702393e+00
    phi[1,2]  R839      -3.0929505825042725e+00
    phi[1,2]  R840      -8.2597851753234863e-01
    phi[1,2]  R841      -3.6565167903900146e+00
    phi[1,2]  R842      2.2184243202209473e+00
    phi[1,2]  R843      -1.4401932954788208e+00
    phi[1,2]  R844      3.6682978272438049e-01
    phi[1,2]  R845      -3.3107354640960693e+00
    phi[1,2]  R846      0.544256865978241
    phi[1,2]  R847      8.2457375526428223e-01
    phi[1,2]  R848      1.0357154607772827e+00
    phi[1,2]  R849      7.2899937629699707e-01
    phi[1,2]  R850      -3.2006654739379883e+00
    phi[1,2]  R851      2.7064695954322815e-01
    phi[1,2]  R852      -3.6550498008728027e+00
    phi[1,2]  R853      -2.1136791706085205e+00
    phi[1,2]  R854      5.5781573057174683e-01
    phi[1,2]  R855      -1.9636831283569336e+00
    phi[1,2]  R856      -1.7818773984909058e+00
    phi[1,2]  R857      -2.3486313819885254e+00
    phi[1,2]  R858      -2.4102606773376465e+00
    phi[1,2]  R859      -2.9555904865264893e+00
    phi[1,2]  R860      -2.6832270622253418e+00
    phi[1,2]  R861      -2.1929731369018555e+00
    phi[1,2]  R862      -1.3810151815414429e+00
    phi[1,2]  R863      2.2508940696716309e+00
    phi[1,2]  R864      1.0346199274063110e+00
    phi[1,2]  R865      -1.1087638139724731e+00
    phi[1,2]  R866      -1.4026911258697510e+00
    phi[1,2]  R867      -5.6905913352966309e-01
    phi[1,2]  R868      -1.1053687334060669e+00
    phi[1,2]  R869      -2.6835184097290039e+00
    phi[1,2]  R870      -1.6300997734069824e+00
    phi[1,2]  R871      6.3460707664489746e-01
    phi[1,2]  R872      -5.3362709283828735e-01
    phi[1,2]  R873      -2.7510124444961548e-01
    phi[1,2]  R874      -3.6803104877471924e+00
    phi[1,2]  R875      -3.7334370613098145e+00
    phi[1,2]  R876      -1.4114958047866821e+00
    phi[1,2]  R877      -1.3174308538436890e+00
    phi[1,2]  R878      1.0269490480422974e+00
    phi[1,2]  R879      -5.1630270481109619e-01
    phi[1,2]  R880      -2.1462390422821045e+00
    phi[1,2]  R881      -1.6105408668518066e+00
    phi[1,2]  R882      7.4040405452251434e-02
    phi[1,2]  R883      -2.1647682189941406e+00
    phi[1,2]  R884      -1.3209075927734375e+00
    phi[1,2]  R885      1.2211597710847855e-01
    phi[1,2]  R886      -3.2136888504028320e+00
    phi[1,2]  R887      -3.9038136005401611e+00
    phi[1,2]  R888      -0.316184401512146
    phi[1,2]  R889      8.7105906009674072e-01
    phi[1,2]  R890      -1.2304085493087769e+00
    phi[1,2]  R891      -2.943359375
    phi[1,2]  R892      -3.4221322536468506e+00
    phi[1,2]  R893      -2.8777201175689697e+00
    phi[1,2]  R894      -3.1775608062744141e+00
    phi[1,2]  R895      -1.3716858625411987e+00
    phi[1,2]  R896      1.8159927427768707e-01
    phi[1,2]  R897      -1.2128859013319016e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R898      -3.0999999046325684e+00
    phi[2,1]  R899      -3.0999999046325684e+00
    phi[2,1]  R900      -2.2400000095367432e+00
    phi[2,1]  R901      -2.2400000095367432e+00
    phi[2,1]  R902      -3.0999999046325684e+00
    phi[2,1]  R903      -3.0999999046325684e+00
    phi[2,1]  R904      -2.5699999332427979e+00
    phi[2,1]  R905      -2.5699999332427979e+00
    phi[2,1]  R906      -3.0999999046325684e+00
    phi[2,1]  R907      -3.0999999046325684e+00
    phi[2,1]  R908      -2.0899999141693115e+00
    phi[2,1]  R909      -2.0899999141693115e+00
    phi[2,1]  R910      -3.0999999046325684e+00
    phi[2,1]  R911      -3.0999999046325684e+00
    phi[2,1]  R912      1.4758145809173584e+00
    phi[2,1]  R913      1.1983867883682251e+00
    phi[2,1]  R914      3.0512848496437073e-01
    phi[2,1]  R915      -8.8237613439559937e-01
    phi[2,1]  R916      5.7116919755935669e-01
    phi[2,1]  R917      2.1738813817501068e-01
    phi[2,1]  R918      1.1170113086700439e+00
    phi[2,1]  R919      1.5647424459457397e+00
    phi[2,1]  R920      1.2970077991485596e+00
    phi[2,1]  R921      1.6711130142211914e+00
    phi[2,1]  R922      4.8250547051429749e-01
    phi[2,1]  R923      1.5181962251663208e+00
    phi[2,1]  R924      2.1828649044036865e+00
    phi[2,1]  R925      8.3552199602127075e-01
    phi[2,1]  R926      6.6989642381668091e-01
    phi[2,1]  R927      2.2758930921554565e-01
    phi[2,1]  R928      8.2934144884347916e-03
    phi[2,1]  R929      -0.709333062171936
    phi[2,1]  R930      -1.4077971875667572e-01
    phi[2,1]  R931      1.2257226705551147e+00
    phi[2,1]  R932      -3.4705410003662109e+00
    phi[2,1]  R933      -2.7444334030151367e+00
    phi[2,1]  R934      -2.4569869041442871e+00
    phi[2,1]  R935      -7.7916479110717773e-01
    phi[2,1]  R936      -6.5530169010162354e-01
    phi[2,1]  R937      -1.6433355212211609e-01
    phi[2,1]  R938      -5.1836383342742920e-01
    phi[2,1]  R939      -2.4087445735931396e+00
    phi[2,1]  R940      -2.1686570644378662e+00
    phi[2,1]  R941      -3.6034054756164551e+00
    phi[2,1]  R942      -2.6684200763702393e+00
    phi[2,1]  R943      -3.0929505825042725e+00
    phi[2,1]  R944      -8.2597851753234863e-01
    phi[2,1]  R945      -3.6565167903900146e+00
    phi[2,1]  R946      2.2184243202209473e+00
    phi[2,1]  R947      -1.4401932954788208e+00
    phi[2,1]  R948      3.6682978272438049e-01
    phi[2,1]  R949      -3.3107354640960693e+00
    phi[2,1]  R950      0.544256865978241
    phi[2,1]  R951      8.2457375526428223e-01
    phi[2,1]  R952      1.0357154607772827e+00
    phi[2,1]  R953      7.2899937629699707e-01
    phi[2,1]  R954      -3.2006654739379883e+00
    phi[2,1]  R955      2.7064695954322815e-01
    phi[2,1]  R956      -3.6550498008728027e+00
    phi[2,1]  R957      -2.1136791706085205e+00
    phi[2,1]  R958      5.5781573057174683e-01
    phi[2,1]  R959      -1.9636831283569336e+00
    phi[2,1]  R960      -1.7818773984909058e+00
    phi[2,1]  R961      -2.3486313819885254e+00
    phi[2,1]  R962      -2.4102606773376465e+00
    phi[2,1]  R963      -2.9555904865264893e+00
    phi[2,1]  R964      -2.6832270622253418e+00
    phi[2,1]  R965      -2.1929731369018555e+00
    phi[2,1]  R966      -1.3810151815414429e+00
    phi[2,1]  R967      2.2508940696716309e+00
    phi[2,1]  R968      1.0346199274063110e+00
    phi[2,1]  R969      -1.1087638139724731e+00
    phi[2,1]  R970      -1.4026911258697510e+00
    phi[2,1]  R971      -5.6905913352966309e-01
    phi[2,1]  R972      -1.1053687334060669e+00
    phi[2,1]  R973      -2.6835184097290039e+00
    phi[2,1]  R974      -1.6300997734069824e+00
    phi[2,1]  R975      6.3460707664489746e-01
    phi[2,1]  R976      -5.3362709283828735e-01
    phi[2,1]  R977      -2.7510124444961548e-01
    phi[2,1]  R978      -3.6803104877471924e+00
    phi[2,1]  R979      -3.7334370613098145e+00
    phi[2,1]  R980      -1.4114958047866821e+00
    phi[2,1]  R981      -1.3174308538436890e+00
    phi[2,1]  R982      1.0269490480422974e+00
    phi[2,1]  R983      -5.1630270481109619e-01
    phi[2,1]  R984      -2.1462390422821045e+00
    phi[2,1]  R985      -1.6105408668518066e+00
    phi[2,1]  R986      7.4040405452251434e-02
    phi[2,1]  R987      -2.1647682189941406e+00
    phi[2,1]  R988      -1.3209075927734375e+00
    phi[2,1]  R989      1.2211597710847855e-01
    phi[2,1]  R990      -3.2136888504028320e+00
    phi[2,1]  R991      -3.9038136005401611e+00
    phi[2,1]  R992      -0.316184401512146
    phi[2,1]  R993      8.7105906009674072e-01
    phi[2,1]  R994      -1.2304085493087769e+00
    phi[2,1]  R995      -2.943359375
    phi[2,1]  R996      -3.4221322536468506e+00
    phi[2,1]  R997      -2.8777201175689697e+00
    phi[2,1]  R998      -3.1775608062744141e+00
    phi[2,1]  R999      -1.3716858625411987e+00
    phi[2,1]  R1000     1.8159927427768707e-01
    phi[2,1]  R1001     -1.2128859013319016e-01
    phi[2,1]  R1002     2.3177416324615479e+00
    phi[2,1]  R1003     1.0229849815368652e+00
    phi[2,1]  R1004     1.8618718385696411e+00
    phi[2,1]  R1005     1.5483042001724243e+00
    phi[2,1]  R1006     1.0634642839431763e+00
    phi[2,1]  R1007     5.9582251310348511e-01
    phi[2,1]  R1008     1.5003855228424072e+00
    phi[2,1]  R1009     1.4370466470718384e+00
    phi[2,1]  R1010     1.14961576461792
    phi[2,1]  R1011     -1.2506283521652222e+00
    phi[2,1]  R1012     -2.6491055488586426e+00
    phi[2,1]  R1013     -0.734790027141571
    phi[2,1]  R1014     -1.3301668167114258e+00
    phi[2,1]  R1015     -0.565537691116333
    phi[2,1]  R1016     -1.0590000152587891e+00
    phi[2,1]  R1017     -1.9945701956748962e-01
    phi[2,1]  R1018     -5.7601881027221680e-01
    phi[2,1]  R1019     -1.6719383001327515e+00
    phi[2,1]  R1020     6.1011922359466553e-01
    phi[2,1]  R1021     -1.9048795700073242e+00
    phi[2,1]  R1022     -5.6648331880569458e-01
    phi[2,1]  R1023     -1.3211433887481689e+00
    phi[2,1]  R1024     -3.0567786097526550e-01
    phi[2,1]  R1025     -2.2654335498809814e+00
    phi[2,1]  R1026     7.4582028388977051e-01
    phi[2,1]  R1027     5.2988183498382568e-01
    phi[2,1]  R1028     -7.6020592451095581e-01
    phi[2,1]  R1029     -1.1085723638534546e+00
    phi[2,1]  R1030     -4.0235871076583862e-01
    phi[2,1]  R1031     -2.3107893764972687e-01
    phi[2,1]  R1032     -1.4806872606277466e-01
    phi[2,1]  R1033     8.1394004821777344e-01
    phi[2,1]  R1034     4.9786585569381714e-01
    phi[2,1]  R1035     7.8848814964294434e-01
    phi[2,1]  R1036     -1.8302508592605591e+00
    phi[2,1]  R1037     -2.9642195701599121e+00
    phi[2,1]  R1038     -2.9077537059783936e+00
    phi[2,1]  R1039     -1.4600787162780762e+00
    phi[2,1]  R1040     -2.87412166595459
    phi[2,1]  R1041     -3.3667697906494141e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R1042     -3.0999999046325684e+00
    phi[1,3]  R1043     -3.0999999046325684e+00
    phi[1,3]  R1044     -2.2400000095367432e+00
    phi[1,3]  R1045     -2.2400000095367432e+00
    phi[1,3]  R1046     -3.0999999046325684e+00
    phi[1,3]  R1047     -3.0999999046325684e+00
    phi[1,3]  R1048     -2.5699999332427979e+00
    phi[1,3]  R1049     -2.5699999332427979e+00
    phi[1,3]  R1050     -3.0999999046325684e+00
    phi[1,3]  R1051     -3.0999999046325684e+00
    phi[1,3]  R1052     -2.0899999141693115e+00
    phi[1,3]  R1053     -2.0899999141693115e+00
    phi[1,3]  R1054     -3.0999999046325684e+00
    phi[1,3]  R1055     -3.0999999046325684e+00
    phi[1,3]  R1056     2.3177416324615479e+00
    phi[1,3]  R1057     1.0229849815368652e+00
    phi[1,3]  R1058     1.8618718385696411e+00
    phi[1,3]  R1059     1.5483042001724243e+00
    phi[1,3]  R1060     1.0634642839431763e+00
    phi[1,3]  R1061     5.9582251310348511e-01
    phi[1,3]  R1062     1.5003855228424072e+00
    phi[1,3]  R1063     1.4370466470718384e+00
    phi[1,3]  R1064     1.14961576461792
    phi[1,3]  R1065     -1.2506283521652222e+00
    phi[1,3]  R1066     -2.6491055488586426e+00
    phi[1,3]  R1067     -0.734790027141571
    phi[1,3]  R1068     -1.3301668167114258e+00
    phi[1,3]  R1069     -0.565537691116333
    phi[1,3]  R1070     -1.0590000152587891e+00
    phi[1,3]  R1071     -1.9945701956748962e-01
    phi[1,3]  R1072     -5.7601881027221680e-01
    phi[1,3]  R1073     -1.6719383001327515e+00
    phi[1,3]  R1074     6.1011922359466553e-01
    phi[1,3]  R1075     -1.9048795700073242e+00
    phi[1,3]  R1076     -5.6648331880569458e-01
    phi[1,3]  R1077     -1.3211433887481689e+00
    phi[1,3]  R1078     -3.0567786097526550e-01
    phi[1,3]  R1079     -2.2654335498809814e+00
    phi[1,3]  R1080     7.4582028388977051e-01
    phi[1,3]  R1081     5.2988183498382568e-01
    phi[1,3]  R1082     -7.6020592451095581e-01
    phi[1,3]  R1083     -1.1085723638534546e+00
    phi[1,3]  R1084     -4.0235871076583862e-01
    phi[1,3]  R1085     -2.3107893764972687e-01
    phi[1,3]  R1086     -1.4806872606277466e-01
    phi[1,3]  R1087     8.1394004821777344e-01
    phi[1,3]  R1088     4.9786585569381714e-01
    phi[1,3]  R1089     7.8848814964294434e-01
    phi[1,3]  R1090     -1.8302508592605591e+00
    phi[1,3]  R1091     -2.9642195701599121e+00
    phi[1,3]  R1092     -2.9077537059783936e+00
    phi[1,3]  R1093     -1.4600787162780762e+00
    phi[1,3]  R1094     -2.87412166595459
    phi[1,3]  R1095     -3.3667697906494141e+00
    phi[1,3]  R1096     1.4070525169372559e+00
    phi[1,3]  R1097     -1.8637837171554565e+00
    phi[1,3]  R1098     1.9244442880153656e-01
    phi[1,3]  R1099     1.3560693264007568e+00
    phi[1,3]  R1100     1.4406063556671143e+00
    phi[1,3]  R1101     1.7186269164085388e-01
    phi[1,3]  R1102     -9.3275710940361023e-02
    phi[1,3]  R1103     1.7816181182861328e+00
    phi[1,3]  R1104     -6.4245003461837769e-01
    phi[1,3]  R1105     2.9749801754951477e-01
    phi[1,3]  R1106     -4.4891899824142456e-01
    phi[1,3]  R1107     -3.1700937747955322e+00
    phi[1,3]  R1108     -1.9243576526641846e+00
    phi[1,3]  R1109     -1.5361006259918213e+00
    phi[1,3]  R1110     -2.4537868499755859e+00
    phi[1,3]  R1111     -3.2084760665893555e+00
    phi[1,3]  R1112     -1.2035303115844727e+00
    phi[1,3]  R1113     5.1626634597778320e-01
    phi[1,3]  R1114     -2.7643303871154785e+00
    phi[1,3]  R1115     -1.2511644363403320e+00
    phi[1,3]  R1116     -5.4061406850814819e-01
    phi[1,3]  R1117     -1.7634431123733521e+00
    phi[1,3]  R1118     -2.9313471913337708e-01
    phi[1,3]  R1119     -1.9044030904769897e+00
    phi[1,3]  R1120     -1.1824598312377930e+00
    phi[1,3]  R1121     1.4344557523727417e+00
    phi[1,3]  R1122     1.2335806339979172e-01
    phi[1,3]  R1123     -2.3884711265563965e+00
    phi[1,3]  R1124     -9.5272518694400787e-02
    phi[1,3]  R1125     -3.4296461939811707e-01
    phi[1,3]  R1126     -6.0556423664093018e-01
    phi[1,3]  R1127     -1.6014730930328369e+00
    phi[1,3]  R1128     2.5656518340110779e-01
    phi[1,3]  R1129     -4.1291669011116028e-02
    phi[1,3]  R1130     -2.9346027374267578e+00
    phi[1,3]  R1131     1.9327629357576370e-02
    phi[1,3]  R1132     -1.6578621864318848e+00
    phi[1,3]  R1133     -6.2594634294509888e-01
    phi[1,3]  R1134     -1.3554449081420898e+00
    phi[1,3]  R1135     -1.1527673006057739e+00
    phi[1,3]  R1136     -2.4211235046386719e+00
    phi[1,3]  R1137     -6.8074566125869751e-01
    phi[1,3]  R1138     1.0860924720764160e+00
    phi[1,3]  R1139     0.00563911022618413
    phi[1,3]  R1140     7.8278881311416626e-01
    phi[1,3]  R1141     -1.0468118190765381e+00
    phi[1,3]  R1142     -2.9776937961578369e+00
    phi[1,3]  R1143     -1.0210758447647095e+00
    phi[1,3]  R1144     -2.3779196739196777e+00
    phi[1,3]  R1145     -1.4153889417648315e+00
    phi[1,3]  R1146     -9.5132905244827271e-01
    phi[1,3]  R1147     1.9264270365238190e-01
    phi[1,3]  R1148     1.0570249557495117e+00
    phi[1,3]  R1149     -7.4598133563995361e-01
    phi[1,3]  R1150     -2.8410035371780396e-01
    phi[1,3]  R1151     -1.5174251794815063e+00
    phi[1,3]  R1152     1.88840651512146
    phi[1,3]  R1153     1.1256448030471802e+00
    phi[1,3]  R1154     1.28672194480896
    phi[1,3]  R1155     1.1664819717407227e+00
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R1156     -3.0999999046325684e+00
    phi[3,1]  R1157     -3.0999999046325684e+00
    phi[3,1]  R1158     -2.2400000095367432e+00
    phi[3,1]  R1159     -2.2400000095367432e+00
    phi[3,1]  R1160     -3.0999999046325684e+00
    phi[3,1]  R1161     -3.0999999046325684e+00
    phi[3,1]  R1162     -2.5699999332427979e+00
    phi[3,1]  R1163     -2.5699999332427979e+00
    phi[3,1]  R1164     -3.0999999046325684e+00
    phi[3,1]  R1165     -3.0999999046325684e+00
    phi[3,1]  R1166     -2.0899999141693115e+00
    phi[3,1]  R1167     -2.0899999141693115e+00
    phi[3,1]  R1168     -3.0999999046325684e+00
    phi[3,1]  R1169     -3.0999999046325684e+00
    phi[3,1]  R1170     1.4070525169372559e+00
    phi[3,1]  R1171     -1.8637837171554565e+00
    phi[3,1]  R1172     1.9244442880153656e-01
    phi[3,1]  R1173     1.3560693264007568e+00
    phi[3,1]  R1174     1.4406063556671143e+00
    phi[3,1]  R1175     1.7186269164085388e-01
    phi[3,1]  R1176     -9.3275710940361023e-02
    phi[3,1]  R1177     1.7816181182861328e+00
    phi[3,1]  R1178     -6.4245003461837769e-01
    phi[3,1]  R1179     2.9749801754951477e-01
    phi[3,1]  R1180     -4.4891899824142456e-01
    phi[3,1]  R1181     -3.1700937747955322e+00
    phi[3,1]  R1182     -1.9243576526641846e+00
    phi[3,1]  R1183     -1.5361006259918213e+00
    phi[3,1]  R1184     -2.4537868499755859e+00
    phi[3,1]  R1185     -3.2084760665893555e+00
    phi[3,1]  R1186     -1.2035303115844727e+00
    phi[3,1]  R1187     5.1626634597778320e-01
    phi[3,1]  R1188     -2.7643303871154785e+00
    phi[3,1]  R1189     -1.2511644363403320e+00
    phi[3,1]  R1190     -5.4061406850814819e-01
    phi[3,1]  R1191     -1.7634431123733521e+00
    phi[3,1]  R1192     -2.9313471913337708e-01
    phi[3,1]  R1193     -1.9044030904769897e+00
    phi[3,1]  R1194     -1.1824598312377930e+00
    phi[3,1]  R1195     1.4344557523727417e+00
    phi[3,1]  R1196     1.2335806339979172e-01
    phi[3,1]  R1197     -2.3884711265563965e+00
    phi[3,1]  R1198     -9.5272518694400787e-02
    phi[3,1]  R1199     -3.4296461939811707e-01
    phi[3,1]  R1200     -6.0556423664093018e-01
    phi[3,1]  R1201     -1.6014730930328369e+00
    phi[3,1]  R1202     2.5656518340110779e-01
    phi[3,1]  R1203     -4.1291669011116028e-02
    phi[3,1]  R1204     -2.9346027374267578e+00
    phi[3,1]  R1205     1.9327629357576370e-02
    phi[3,1]  R1206     -1.6578621864318848e+00
    phi[3,1]  R1207     -6.2594634294509888e-01
    phi[3,1]  R1208     -1.3554449081420898e+00
    phi[3,1]  R1209     -1.1527673006057739e+00
    phi[3,1]  R1210     -2.4211235046386719e+00
    phi[3,1]  R1211     -6.8074566125869751e-01
    phi[3,1]  R1212     1.0860924720764160e+00
    phi[3,1]  R1213     0.00563911022618413
    phi[3,1]  R1214     7.8278881311416626e-01
    phi[3,1]  R1215     -1.0468118190765381e+00
    phi[3,1]  R1216     -2.9776937961578369e+00
    phi[3,1]  R1217     -1.0210758447647095e+00
    phi[3,1]  R1218     -2.3779196739196777e+00
    phi[3,1]  R1219     -1.4153889417648315e+00
    phi[3,1]  R1220     -9.5132905244827271e-01
    phi[3,1]  R1221     1.9264270365238190e-01
    phi[3,1]  R1222     1.0570249557495117e+00
    phi[3,1]  R1223     -7.4598133563995361e-01
    phi[3,1]  R1224     -2.8410035371780396e-01
    phi[3,1]  R1225     -1.5174251794815063e+00
    phi[3,1]  R1226     1.88840651512146
    phi[3,1]  R1227     1.1256448030471802e+00
    phi[3,1]  R1228     1.28672194480896
    phi[3,1]  R1229     1.1664819717407227e+00
    phi[3,1]  R1230     2.3177416324615479e+00
    phi[3,1]  R1231     1.0229849815368652e+00
    phi[3,1]  R1232     1.8618718385696411e+00
    phi[3,1]  R1233     1.5483042001724243e+00
    phi[3,1]  R1234     1.0634642839431763e+00
    phi[3,1]  R1235     5.9582251310348511e-01
    phi[3,1]  R1236     1.5003855228424072e+00
    phi[3,1]  R1237     1.4370466470718384e+00
    phi[3,1]  R1238     1.14961576461792
    phi[3,1]  R1239     -1.2506283521652222e+00
    phi[3,1]  R1240     -2.6491055488586426e+00
    phi[3,1]  R1241     -0.734790027141571
    phi[3,1]  R1242     -1.3301668167114258e+00
    phi[3,1]  R1243     -0.565537691116333
    phi[3,1]  R1244     -1.0590000152587891e+00
    phi[3,1]  R1245     -1.9945701956748962e-01
    phi[3,1]  R1246     -5.7601881027221680e-01
    phi[3,1]  R1247     -1.6719383001327515e+00
    phi[3,1]  R1248     6.1011922359466553e-01
    phi[3,1]  R1249     -1.9048795700073242e+00
    phi[3,1]  R1250     -5.6648331880569458e-01
    phi[3,1]  R1251     -1.3211433887481689e+00
    phi[3,1]  R1252     -3.0567786097526550e-01
    phi[3,1]  R1253     -2.2654335498809814e+00
    phi[3,1]  R1254     7.4582028388977051e-01
    phi[3,1]  R1255     5.2988183498382568e-01
    phi[3,1]  R1256     -7.6020592451095581e-01
    phi[3,1]  R1257     -1.1085723638534546e+00
    phi[3,1]  R1258     -4.0235871076583862e-01
    phi[3,1]  R1259     -2.3107893764972687e-01
    phi[3,1]  R1260     -1.4806872606277466e-01
    phi[3,1]  R1261     8.1394004821777344e-01
    phi[3,1]  R1262     4.9786585569381714e-01
    phi[3,1]  R1263     7.8848814964294434e-01
    phi[3,1]  R1264     -1.8302508592605591e+00
    phi[3,1]  R1265     -2.9642195701599121e+00
    phi[3,1]  R1266     -2.9077537059783936e+00
    phi[3,1]  R1267     -1.4600787162780762e+00
    phi[3,1]  R1268     -2.87412166595459
    phi[3,1]  R1269     -3.3667697906494141e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1270     -3.0999999046325684e+00
    phi[1,4]  R1271     -3.0999999046325684e+00
    phi[1,4]  R1272     -2.2400000095367432e+00
    phi[1,4]  R1273     -2.2400000095367432e+00
    phi[1,4]  R1274     -3.0999999046325684e+00
    phi[1,4]  R1275     -3.0999999046325684e+00
    phi[1,4]  R1276     -2.5699999332427979e+00
    phi[1,4]  R1277     -2.5699999332427979e+00
    phi[1,4]  R1278     -3.0999999046325684e+00
    phi[1,4]  R1279     -3.0999999046325684e+00
    phi[1,4]  R1280     -2.0899999141693115e+00
    phi[1,4]  R1281     -2.0899999141693115e+00
    phi[1,4]  R1282     -3.0999999046325684e+00
    phi[1,4]  R1283     -3.0999999046325684e+00
    phi[1,4]  R1284     2.3177416324615479e+00
    phi[1,4]  R1285     1.0229849815368652e+00
    phi[1,4]  R1286     1.8618718385696411e+00
    phi[1,4]  R1287     1.5483042001724243e+00
    phi[1,4]  R1288     1.0634642839431763e+00
    phi[1,4]  R1289     5.9582251310348511e-01
    phi[1,4]  R1290     1.5003855228424072e+00
    phi[1,4]  R1291     1.4370466470718384e+00
    phi[1,4]  R1292     1.14961576461792
    phi[1,4]  R1293     -1.2506283521652222e+00
    phi[1,4]  R1294     -2.6491055488586426e+00
    phi[1,4]  R1295     -0.734790027141571
    phi[1,4]  R1296     -1.3301668167114258e+00
    phi[1,4]  R1297     -0.565537691116333
    phi[1,4]  R1298     -1.0590000152587891e+00
    phi[1,4]  R1299     -1.9945701956748962e-01
    phi[1,4]  R1300     -5.7601881027221680e-01
    phi[1,4]  R1301     -1.6719383001327515e+00
    phi[1,4]  R1302     6.1011922359466553e-01
    phi[1,4]  R1303     -1.9048795700073242e+00
    phi[1,4]  R1304     -5.6648331880569458e-01
    phi[1,4]  R1305     -1.3211433887481689e+00
    phi[1,4]  R1306     -3.0567786097526550e-01
    phi[1,4]  R1307     -2.2654335498809814e+00
    phi[1,4]  R1308     7.4582028388977051e-01
    phi[1,4]  R1309     5.2988183498382568e-01
    phi[1,4]  R1310     -7.6020592451095581e-01
    phi[1,4]  R1311     -1.1085723638534546e+00
    phi[1,4]  R1312     -4.0235871076583862e-01
    phi[1,4]  R1313     -2.3107893764972687e-01
    phi[1,4]  R1314     -1.4806872606277466e-01
    phi[1,4]  R1315     8.1394004821777344e-01
    phi[1,4]  R1316     4.9786585569381714e-01
    phi[1,4]  R1317     7.8848814964294434e-01
    phi[1,4]  R1318     -1.8302508592605591e+00
    phi[1,4]  R1319     -2.9642195701599121e+00
    phi[1,4]  R1320     -2.9077537059783936e+00
    phi[1,4]  R1321     -1.4600787162780762e+00
    phi[1,4]  R1322     -2.87412166595459
    phi[1,4]  R1323     -3.3667697906494141e+00
    phi[1,4]  R1324     1.0069933533668518e-01
    phi[1,4]  R1325     2.0685143470764160e+00
    phi[1,4]  R1326     5.1308560371398926e-01
    phi[1,4]  R1327     -7.2219479084014893e-01
    phi[1,4]  R1328     2.1128454208374023e+00
    phi[1,4]  R1329     1.6501094102859497e+00
    phi[1,4]  R1330     -6.7144048213958740e-01
    phi[1,4]  R1331     -3.6677727103233337e-01
    phi[1,4]  R1332     3.4622645378112793e-01
    phi[1,4]  R1333     1.3843475282192230e-01
    phi[1,4]  R1334     -2.6625173091888428e+00
    phi[1,4]  R1335     -3.0162916183471680e+00
    phi[1,4]  R1336     -2.6542499065399170e+00
    phi[1,4]  R1337     -2.5950672626495361e+00
    phi[1,4]  R1338     -2.3996124267578125e+00
    phi[1,4]  R1339     -1.5645024776458740e+00
    phi[1,4]  R1340     -2.0111243724823
    phi[1,4]  R1341     3.8759976625442505e-01
    phi[1,4]  R1342     -2.3692221641540527e+00
    phi[1,4]  R1343     -6.8068438768386841e-01
    phi[1,4]  R1344     7.5522202253341675e-01
    phi[1,4]  R1345     -1.9150774478912354e+00
    phi[1,4]  R1346     -3.5453069210052490e+00
    phi[1,4]  R1347     -2.3972954750061035e+00
    phi[1,4]  R1348     -2.0419905185699463e+00
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1349     -3.0999999046325684e+00
    phi[4,1]  R1350     -3.0999999046325684e+00
    phi[4,1]  R1351     -2.2400000095367432e+00
    phi[4,1]  R1352     -2.2400000095367432e+00
    phi[4,1]  R1353     -3.0999999046325684e+00
    phi[4,1]  R1354     -3.0999999046325684e+00
    phi[4,1]  R1355     -2.5699999332427979e+00
    phi[4,1]  R1356     -2.5699999332427979e+00
    phi[4,1]  R1357     -3.0999999046325684e+00
    phi[4,1]  R1358     -3.0999999046325684e+00
    phi[4,1]  R1359     -2.0899999141693115e+00
    phi[4,1]  R1360     -2.0899999141693115e+00
    phi[4,1]  R1361     -3.0999999046325684e+00
    phi[4,1]  R1362     -3.0999999046325684e+00
    phi[4,1]  R1363     1.0069933533668518e-01
    phi[4,1]  R1364     2.0685143470764160e+00
    phi[4,1]  R1365     5.1308560371398926e-01
    phi[4,1]  R1366     -7.2219479084014893e-01
    phi[4,1]  R1367     2.1128454208374023e+00
    phi[4,1]  R1368     1.6501094102859497e+00
    phi[4,1]  R1369     -6.7144048213958740e-01
    phi[4,1]  R1370     -3.6677727103233337e-01
    phi[4,1]  R1371     3.4622645378112793e-01
    phi[4,1]  R1372     1.3843475282192230e-01
    phi[4,1]  R1373     -2.6625173091888428e+00
    phi[4,1]  R1374     -3.0162916183471680e+00
    phi[4,1]  R1375     -2.6542499065399170e+00
    phi[4,1]  R1376     -2.5950672626495361e+00
    phi[4,1]  R1377     -2.3996124267578125e+00
    phi[4,1]  R1378     -1.5645024776458740e+00
    phi[4,1]  R1379     -2.0111243724823
    phi[4,1]  R1380     3.8759976625442505e-01
    phi[4,1]  R1381     -2.3692221641540527e+00
    phi[4,1]  R1382     -6.8068438768386841e-01
    phi[4,1]  R1383     7.5522202253341675e-01
    phi[4,1]  R1384     -1.9150774478912354e+00
    phi[4,1]  R1385     -3.5453069210052490e+00
    phi[4,1]  R1386     -2.3972954750061035e+00
    phi[4,1]  R1387     -2.0419905185699463e+00
    phi[4,1]  R1388     2.3177416324615479e+00
    phi[4,1]  R1389     1.0229849815368652e+00
    phi[4,1]  R1390     1.8618718385696411e+00
    phi[4,1]  R1391     1.5483042001724243e+00
    phi[4,1]  R1392     1.0634642839431763e+00
    phi[4,1]  R1393     5.9582251310348511e-01
    phi[4,1]  R1394     1.5003855228424072e+00
    phi[4,1]  R1395     1.4370466470718384e+00
    phi[4,1]  R1396     1.14961576461792
    phi[4,1]  R1397     -1.2506283521652222e+00
    phi[4,1]  R1398     -2.6491055488586426e+00
    phi[4,1]  R1399     -0.734790027141571
    phi[4,1]  R1400     -1.3301668167114258e+00
    phi[4,1]  R1401     -0.565537691116333
    phi[4,1]  R1402     -1.0590000152587891e+00
    phi[4,1]  R1403     -1.9945701956748962e-01
    phi[4,1]  R1404     -5.7601881027221680e-01
    phi[4,1]  R1405     -1.6719383001327515e+00
    phi[4,1]  R1406     6.1011922359466553e-01
    phi[4,1]  R1407     -1.9048795700073242e+00
    phi[4,1]  R1408     -5.6648331880569458e-01
    phi[4,1]  R1409     -1.3211433887481689e+00
    phi[4,1]  R1410     -3.0567786097526550e-01
    phi[4,1]  R1411     -2.2654335498809814e+00
    phi[4,1]  R1412     7.4582028388977051e-01
    phi[4,1]  R1413     5.2988183498382568e-01
    phi[4,1]  R1414     -7.6020592451095581e-01
    phi[4,1]  R1415     -1.1085723638534546e+00
    phi[4,1]  R1416     -4.0235871076583862e-01
    phi[4,1]  R1417     -2.3107893764972687e-01
    phi[4,1]  R1418     -1.4806872606277466e-01
    phi[4,1]  R1419     8.1394004821777344e-01
    phi[4,1]  R1420     4.9786585569381714e-01
    phi[4,1]  R1421     7.8848814964294434e-01
    phi[4,1]  R1422     -1.8302508592605591e+00
    phi[4,1]  R1423     -2.9642195701599121e+00
    phi[4,1]  R1424     -2.9077537059783936e+00
    phi[4,1]  R1425     -1.4600787162780762e+00
    phi[4,1]  R1426     -2.87412166595459
    phi[4,1]  R1427     -3.3667697906494141e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1428     -3.0999999046325684e+00
    phi[1,5]  R1429     -3.0999999046325684e+00
    phi[1,5]  R1430     -2.2400000095367432e+00
    phi[1,5]  R1431     -2.2400000095367432e+00
    phi[1,5]  R1432     -3.0999999046325684e+00
    phi[1,5]  R1433     -3.0999999046325684e+00
    phi[1,5]  R1434     -2.5699999332427979e+00
    phi[1,5]  R1435     -2.5699999332427979e+00
    phi[1,5]  R1436     -3.0999999046325684e+00
    phi[1,5]  R1437     -3.0999999046325684e+00
    phi[1,5]  R1438     -2.0899999141693115e+00
    phi[1,5]  R1439     -2.0899999141693115e+00
    phi[1,5]  R1440     -3.0999999046325684e+00
    phi[1,5]  R1441     -3.0999999046325684e+00
    phi[1,5]  R1442     2.3177416324615479e+00
    phi[1,5]  R1443     1.0229849815368652e+00
    phi[1,5]  R1444     1.8618718385696411e+00
    phi[1,5]  R1445     1.5483042001724243e+00
    phi[1,5]  R1446     1.0634642839431763e+00
    phi[1,5]  R1447     5.9582251310348511e-01
    phi[1,5]  R1448     1.5003855228424072e+00
    phi[1,5]  R1449     1.4370466470718384e+00
    phi[1,5]  R1450     1.14961576461792
    phi[1,5]  R1451     -1.2506283521652222e+00
    phi[1,5]  R1452     -2.6491055488586426e+00
    phi[1,5]  R1453     -0.734790027141571
    phi[1,5]  R1454     -1.3301668167114258e+00
    phi[1,5]  R1455     -0.565537691116333
    phi[1,5]  R1456     -1.0590000152587891e+00
    phi[1,5]  R1457     -1.9945701956748962e-01
    phi[1,5]  R1458     -5.7601881027221680e-01
    phi[1,5]  R1459     -1.6719383001327515e+00
    phi[1,5]  R1460     6.1011922359466553e-01
    phi[1,5]  R1461     -1.9048795700073242e+00
    phi[1,5]  R1462     -5.6648331880569458e-01
    phi[1,5]  R1463     -1.3211433887481689e+00
    phi[1,5]  R1464     -3.0567786097526550e-01
    phi[1,5]  R1465     -2.2654335498809814e+00
    phi[1,5]  R1466     7.4582028388977051e-01
    phi[1,5]  R1467     5.2988183498382568e-01
    phi[1,5]  R1468     -7.6020592451095581e-01
    phi[1,5]  R1469     -1.1085723638534546e+00
    phi[1,5]  R1470     -4.0235871076583862e-01
    phi[1,5]  R1471     -2.3107893764972687e-01
    phi[1,5]  R1472     -1.4806872606277466e-01
    phi[1,5]  R1473     8.1394004821777344e-01
    phi[1,5]  R1474     4.9786585569381714e-01
    phi[1,5]  R1475     7.8848814964294434e-01
    phi[1,5]  R1476     -1.8302508592605591e+00
    phi[1,5]  R1477     -2.9642195701599121e+00
    phi[1,5]  R1478     -2.9077537059783936e+00
    phi[1,5]  R1479     -1.4600787162780762e+00
    phi[1,5]  R1480     -2.87412166595459
    phi[1,5]  R1481     -3.3667697906494141e+00
    phi[1,5]  R1482     1.6159764528274536e+00
    phi[1,5]  R1483     7.3009330034255981e-01
    phi[1,5]  R1484     5.2580791711807251e-01
    phi[1,5]  R1485     8.1365460157394409e-01
    phi[1,5]  R1486     -7.8649681806564331e-01
    phi[1,5]  R1487     -1.0748572647571564e-01
    phi[1,5]  R1488     -2.2303009033203125e+00
    phi[1,5]  R1489     2.7489697933197021e+00
    phi[1,5]  R1490     2.1882367134094238e+00
    phi[1,5]  R1491     2.2065770626068115e+00
    phi[1,5]  R1492     -1.8265733718872070e+00
    phi[1,5]  R1493     -0.137929305434227
    phi[1,5]  R1494     -1.7446128129959106e+00
    phi[1,5]  R1495     -9.3039298057556152e-01
    phi[1,5]  R1496     -1.7700532674789429e+00
    phi[1,5]  R1497     -5.2321439981460571e-01
    phi[1,5]  R1498     -2.1908600330352783e+00
    phi[1,5]  R1499     -2.7775921821594238e+00
    phi[1,5]  R1500     -3.9528522491455078e+00
    phi[1,5]  R1501     -2.65352201461792
    phi[1,5]  R1502     -1.5018348395824432e-01
    phi[1,5]  R1503     -2.94931960105896
    phi[1,5]  R1504     -1.9365466833114624e+00
    phi[1,5]  R1505     -3.3338909149169922e+00
    phi[1,5]  R1506     -3.0957643985748291e+00
    phi[1,5]  R1507     -2.3715000152587891e+00
    phi[1,5]  R1508     -4.2080540657043457e+00
    phi[1,5]  R1509     -2.3986940383911133e+00
    phi[1,5]  R1510     -2.2275218963623047e+00
    phi[1,5]  R1511     -3.9052727222442627e+00
    phi[1,5]  R1512     -5.0226032733917236e-01
    phi[1,5]  R1513     -2.4277970790863037e+00
    phi[1,5]  R1514     -2.1121904850006104e+00
    phi[1,5]  R1515     -1.0808832645416260e+00
    phi[1,5]  R1516     -3.1597013473510742e+00
    phi[1,5]  R1517     -3.7193052768707275e+00
    phi[1,5]  R1518     -4.0714473724365234e+00
    phi[1,5]  R1519     -3.5343732833862305e+00
    phi[1,5]  R1520     -3.7382705211639404e+00
    phi[1,5]  R1521     -1.3741468191146851e+00
    phi[1,5]  R1522     -7.1413916349411011e-01
    phi[1,5]  R1523     -2.2223873138427734e+00
    phi[1,5]  R1524     -1.9274870157241821e+00
    phi[1,5]  R1525     -3.3390325307846069e-01
    phi[1,5]  R1526     -2.4610452651977539e+00
    phi[1,5]  R1527     -3.2039291858673096e+00
    phi[1,5]  R1528     -2.0271937847137451e+00
    phi[1,5]  R1529     -2.4007794857025146e+00
    phi[1,5]  R1530     -1.3676869869232178e+00
    phi[1,5]  R1531     -3.7167675495147705e+00
    phi[1,5]  R1532     -2.1951284408569336e+00
    phi[1,5]  R1533     -8.4660136699676514e-01
    phi[1,5]  R1534     -2.5907800197601318e+00
    phi[1,5]  R1535     -2.2088646888732910e+00
    phi[1,5]  R1536     -2.5556418895721436e+00
    phi[1,5]  R1537     -1.1774408817291260e+00
    phi[1,5]  R1538     -1.4089405536651611e+00
    phi[1,5]  R1539     -3.6982412338256836e+00
    phi[1,5]  R1540     -2.6501352787017822e+00
    phi[1,5]  R1541     4.7478699684143066e-01
    phi[1,5]  R1542     -2.4017119780182838e-02
    phi[1,5]  R1543     -1.7241708040237427e+00
    phi[1,5]  R1544     -1.1449874639511108e+00
    phi[1,5]  R1545     -9.5726456493139267e-03
    phi[1,5]  R1546     -3.5190050601959229e+00
    phi[1,5]  R1547     -3.7474122047424316e+00
    phi[1,5]  R1548     -3.7584192752838135e+00
    phi[1,5]  R1549     -2.6990950107574463e-01
    phi[1,5]  R1550     -2.6369037628173828e+00
    phi[1,5]  R1551     1.4033931493759155e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1552     -3.0999999046325684e+00
    phi[5,1]  R1553     -3.0999999046325684e+00
    phi[5,1]  R1554     -2.2400000095367432e+00
    phi[5,1]  R1555     -2.2400000095367432e+00
    phi[5,1]  R1556     -3.0999999046325684e+00
    phi[5,1]  R1557     -3.0999999046325684e+00
    phi[5,1]  R1558     -2.5699999332427979e+00
    phi[5,1]  R1559     -2.5699999332427979e+00
    phi[5,1]  R1560     -3.0999999046325684e+00
    phi[5,1]  R1561     -3.0999999046325684e+00
    phi[5,1]  R1562     -2.0899999141693115e+00
    phi[5,1]  R1563     -2.0899999141693115e+00
    phi[5,1]  R1564     -3.0999999046325684e+00
    phi[5,1]  R1565     -3.0999999046325684e+00
    phi[5,1]  R1566     1.6159764528274536e+00
    phi[5,1]  R1567     7.3009330034255981e-01
    phi[5,1]  R1568     5.2580791711807251e-01
    phi[5,1]  R1569     8.1365460157394409e-01
    phi[5,1]  R1570     -7.8649681806564331e-01
    phi[5,1]  R1571     -1.0748572647571564e-01
    phi[5,1]  R1572     -2.2303009033203125e+00
    phi[5,1]  R1573     2.7489697933197021e+00
    phi[5,1]  R1574     2.1882367134094238e+00
    phi[5,1]  R1575     2.2065770626068115e+00
    phi[5,1]  R1576     -1.8265733718872070e+00
    phi[5,1]  R1577     -0.137929305434227
    phi[5,1]  R1578     -1.7446128129959106e+00
    phi[5,1]  R1579     -9.3039298057556152e-01
    phi[5,1]  R1580     -1.7700532674789429e+00
    phi[5,1]  R1581     -5.2321439981460571e-01
    phi[5,1]  R1582     -2.1908600330352783e+00
    phi[5,1]  R1583     -2.7775921821594238e+00
    phi[5,1]  R1584     -3.9528522491455078e+00
    phi[5,1]  R1585     -2.65352201461792
    phi[5,1]  R1586     -1.5018348395824432e-01
    phi[5,1]  R1587     -2.94931960105896
    phi[5,1]  R1588     -1.9365466833114624e+00
    phi[5,1]  R1589     -3.3338909149169922e+00
    phi[5,1]  R1590     -3.0957643985748291e+00
    phi[5,1]  R1591     -2.3715000152587891e+00
    phi[5,1]  R1592     -4.2080540657043457e+00
    phi[5,1]  R1593     -2.3986940383911133e+00
    phi[5,1]  R1594     -2.2275218963623047e+00
    phi[5,1]  R1595     -3.9052727222442627e+00
    phi[5,1]  R1596     -5.0226032733917236e-01
    phi[5,1]  R1597     -2.4277970790863037e+00
    phi[5,1]  R1598     -2.1121904850006104e+00
    phi[5,1]  R1599     -1.0808832645416260e+00
    phi[5,1]  R1600     -3.1597013473510742e+00
    phi[5,1]  R1601     -3.7193052768707275e+00
    phi[5,1]  R1602     -4.0714473724365234e+00
    phi[5,1]  R1603     -3.5343732833862305e+00
    phi[5,1]  R1604     -3.7382705211639404e+00
    phi[5,1]  R1605     -1.3741468191146851e+00
    phi[5,1]  R1606     -7.1413916349411011e-01
    phi[5,1]  R1607     -2.2223873138427734e+00
    phi[5,1]  R1608     -1.9274870157241821e+00
    phi[5,1]  R1609     -3.3390325307846069e-01
    phi[5,1]  R1610     -2.4610452651977539e+00
    phi[5,1]  R1611     -3.2039291858673096e+00
    phi[5,1]  R1612     -2.0271937847137451e+00
    phi[5,1]  R1613     -2.4007794857025146e+00
    phi[5,1]  R1614     -1.3676869869232178e+00
    phi[5,1]  R1615     -3.7167675495147705e+00
    phi[5,1]  R1616     -2.1951284408569336e+00
    phi[5,1]  R1617     -8.4660136699676514e-01
    phi[5,1]  R1618     -2.5907800197601318e+00
    phi[5,1]  R1619     -2.2088646888732910e+00
    phi[5,1]  R1620     -2.5556418895721436e+00
    phi[5,1]  R1621     -1.1774408817291260e+00
    phi[5,1]  R1622     -1.4089405536651611e+00
    phi[5,1]  R1623     -3.6982412338256836e+00
    phi[5,1]  R1624     -2.6501352787017822e+00
    phi[5,1]  R1625     4.7478699684143066e-01
    phi[5,1]  R1626     -2.4017119780182838e-02
    phi[5,1]  R1627     -1.7241708040237427e+00
    phi[5,1]  R1628     -1.1449874639511108e+00
    phi[5,1]  R1629     -9.5726456493139267e-03
    phi[5,1]  R1630     -3.5190050601959229e+00
    phi[5,1]  R1631     -3.7474122047424316e+00
    phi[5,1]  R1632     -3.7584192752838135e+00
    phi[5,1]  R1633     -2.6990950107574463e-01
    phi[5,1]  R1634     -2.6369037628173828e+00
    phi[5,1]  R1635     1.4033931493759155e+00
    phi[5,1]  R1636     2.3177416324615479e+00
    phi[5,1]  R1637     1.0229849815368652e+00
    phi[5,1]  R1638     1.8618718385696411e+00
    phi[5,1]  R1639     1.5483042001724243e+00
    phi[5,1]  R1640     1.0634642839431763e+00
    phi[5,1]  R1641     5.9582251310348511e-01
    phi[5,1]  R1642     1.5003855228424072e+00
    phi[5,1]  R1643     1.4370466470718384e+00
    phi[5,1]  R1644     1.14961576461792
    phi[5,1]  R1645     -1.2506283521652222e+00
    phi[5,1]  R1646     -2.6491055488586426e+00
    phi[5,1]  R1647     -0.734790027141571
    phi[5,1]  R1648     -1.3301668167114258e+00
    phi[5,1]  R1649     -0.565537691116333
    phi[5,1]  R1650     -1.0590000152587891e+00
    phi[5,1]  R1651     -1.9945701956748962e-01
    phi[5,1]  R1652     -5.7601881027221680e-01
    phi[5,1]  R1653     -1.6719383001327515e+00
    phi[5,1]  R1654     6.1011922359466553e-01
    phi[5,1]  R1655     -1.9048795700073242e+00
    phi[5,1]  R1656     -5.6648331880569458e-01
    phi[5,1]  R1657     -1.3211433887481689e+00
    phi[5,1]  R1658     -3.0567786097526550e-01
    phi[5,1]  R1659     -2.2654335498809814e+00
    phi[5,1]  R1660     7.4582028388977051e-01
    phi[5,1]  R1661     5.2988183498382568e-01
    phi[5,1]  R1662     -7.6020592451095581e-01
    phi[5,1]  R1663     -1.1085723638534546e+00
    phi[5,1]  R1664     -4.0235871076583862e-01
    phi[5,1]  R1665     -2.3107893764972687e-01
    phi[5,1]  R1666     -1.4806872606277466e-01
    phi[5,1]  R1667     8.1394004821777344e-01
    phi[5,1]  R1668     4.9786585569381714e-01
    phi[5,1]  R1669     7.8848814964294434e-01
    phi[5,1]  R1670     -1.8302508592605591e+00
    phi[5,1]  R1671     -2.9642195701599121e+00
    phi[5,1]  R1672     -2.9077537059783936e+00
    phi[5,1]  R1673     -1.4600787162780762e+00
    phi[5,1]  R1674     -2.87412166595459
    phi[5,1]  R1675     -3.3667697906494141e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1676     -3.0999999046325684e+00
    phi[2,4]  R1677     -3.0999999046325684e+00
    phi[2,4]  R1678     -2.2400000095367432e+00
    phi[2,4]  R1679     -2.2400000095367432e+00
    phi[2,4]  R1680     -3.0999999046325684e+00
    phi[2,4]  R1681     -3.0999999046325684e+00
    phi[2,4]  R1682     -2.5699999332427979e+00
    phi[2,4]  R1683     -2.5699999332427979e+00
    phi[2,4]  R1684     -3.0999999046325684e+00
    phi[2,4]  R1685     -3.0999999046325684e+00
    phi[2,4]  R1686     -2.0899999141693115e+00
    phi[2,4]  R1687     -2.0899999141693115e+00
    phi[2,4]  R1688     -3.0999999046325684e+00
    phi[2,4]  R1689     -3.0999999046325684e+00
    phi[2,4]  R1690     1.4758145809173584e+00
    phi[2,4]  R1691     1.1983867883682251e+00
    phi[2,4]  R1692     3.0512848496437073e-01
    phi[2,4]  R1693     -8.8237613439559937e-01
    phi[2,4]  R1694     5.7116919755935669e-01
    phi[2,4]  R1695     2.1738813817501068e-01
    phi[2,4]  R1696     1.1170113086700439e+00
    phi[2,4]  R1697     1.5647424459457397e+00
    phi[2,4]  R1698     1.2970077991485596e+00
    phi[2,4]  R1699     1.6711130142211914e+00
    phi[2,4]  R1700     4.8250547051429749e-01
    phi[2,4]  R1701     1.5181962251663208e+00
    phi[2,4]  R1702     2.1828649044036865e+00
    phi[2,4]  R1703     8.3552199602127075e-01
    phi[2,4]  R1704     6.6989642381668091e-01
    phi[2,4]  R1705     2.2758930921554565e-01
    phi[2,4]  R1706     8.2934144884347916e-03
    phi[2,4]  R1707     -0.709333062171936
    phi[2,4]  R1708     -1.4077971875667572e-01
    phi[2,4]  R1709     1.2257226705551147e+00
    phi[2,4]  R1710     -3.4705410003662109e+00
    phi[2,4]  R1711     -2.7444334030151367e+00
    phi[2,4]  R1712     -2.4569869041442871e+00
    phi[2,4]  R1713     -7.7916479110717773e-01
    phi[2,4]  R1714     -6.5530169010162354e-01
    phi[2,4]  R1715     -1.6433355212211609e-01
    phi[2,4]  R1716     -5.1836383342742920e-01
    phi[2,4]  R1717     -2.4087445735931396e+00
    phi[2,4]  R1718     -2.1686570644378662e+00
    phi[2,4]  R1719     -3.6034054756164551e+00
    phi[2,4]  R1720     -2.6684200763702393e+00
    phi[2,4]  R1721     -3.0929505825042725e+00
    phi[2,4]  R1722     -8.2597851753234863e-01
    phi[2,4]  R1723     -3.6565167903900146e+00
    phi[2,4]  R1724     2.2184243202209473e+00
    phi[2,4]  R1725     -1.4401932954788208e+00
    phi[2,4]  R1726     3.6682978272438049e-01
    phi[2,4]  R1727     -3.3107354640960693e+00
    phi[2,4]  R1728     0.544256865978241
    phi[2,4]  R1729     8.2457375526428223e-01
    phi[2,4]  R1730     1.0357154607772827e+00
    phi[2,4]  R1731     7.2899937629699707e-01
    phi[2,4]  R1732     -3.2006654739379883e+00
    phi[2,4]  R1733     2.7064695954322815e-01
    phi[2,4]  R1734     -3.6550498008728027e+00
    phi[2,4]  R1735     -2.1136791706085205e+00
    phi[2,4]  R1736     5.5781573057174683e-01
    phi[2,4]  R1737     -1.9636831283569336e+00
    phi[2,4]  R1738     -1.7818773984909058e+00
    phi[2,4]  R1739     -2.3486313819885254e+00
    phi[2,4]  R1740     -2.4102606773376465e+00
    phi[2,4]  R1741     -2.9555904865264893e+00
    phi[2,4]  R1742     -2.6832270622253418e+00
    phi[2,4]  R1743     -2.1929731369018555e+00
    phi[2,4]  R1744     -1.3810151815414429e+00
    phi[2,4]  R1745     2.2508940696716309e+00
    phi[2,4]  R1746     1.0346199274063110e+00
    phi[2,4]  R1747     -1.1087638139724731e+00
    phi[2,4]  R1748     -1.4026911258697510e+00
    phi[2,4]  R1749     -5.6905913352966309e-01
    phi[2,4]  R1750     -1.1053687334060669e+00
    phi[2,4]  R1751     -2.6835184097290039e+00
    phi[2,4]  R1752     -1.6300997734069824e+00
    phi[2,4]  R1753     6.3460707664489746e-01
    phi[2,4]  R1754     -5.3362709283828735e-01
    phi[2,4]  R1755     -2.7510124444961548e-01
    phi[2,4]  R1756     -3.6803104877471924e+00
    phi[2,4]  R1757     -3.7334370613098145e+00
    phi[2,4]  R1758     -1.4114958047866821e+00
    phi[2,4]  R1759     -1.3174308538436890e+00
    phi[2,4]  R1760     1.0269490480422974e+00
    phi[2,4]  R1761     -5.1630270481109619e-01
    phi[2,4]  R1762     -2.1462390422821045e+00
    phi[2,4]  R1763     -1.6105408668518066e+00
    phi[2,4]  R1764     7.4040405452251434e-02
    phi[2,4]  R1765     -2.1647682189941406e+00
    phi[2,4]  R1766     -1.3209075927734375e+00
    phi[2,4]  R1767     1.2211597710847855e-01
    phi[2,4]  R1768     -3.2136888504028320e+00
    phi[2,4]  R1769     -3.9038136005401611e+00
    phi[2,4]  R1770     -0.316184401512146
    phi[2,4]  R1771     8.7105906009674072e-01
    phi[2,4]  R1772     -1.2304085493087769e+00
    phi[2,4]  R1773     -2.943359375
    phi[2,4]  R1774     -3.4221322536468506e+00
    phi[2,4]  R1775     -2.8777201175689697e+00
    phi[2,4]  R1776     -3.1775608062744141e+00
    phi[2,4]  R1777     -1.3716858625411987e+00
    phi[2,4]  R1778     1.8159927427768707e-01
    phi[2,4]  R1779     -1.2128859013319016e-01
    phi[2,4]  R1780     1.0069933533668518e-01
    phi[2,4]  R1781     2.0685143470764160e+00
    phi[2,4]  R1782     5.1308560371398926e-01
    phi[2,4]  R1783     -7.2219479084014893e-01
    phi[2,4]  R1784     2.1128454208374023e+00
    phi[2,4]  R1785     1.6501094102859497e+00
    phi[2,4]  R1786     -6.7144048213958740e-01
    phi[2,4]  R1787     -3.6677727103233337e-01
    phi[2,4]  R1788     3.4622645378112793e-01
    phi[2,4]  R1789     1.3843475282192230e-01
    phi[2,4]  R1790     -2.6625173091888428e+00
    phi[2,4]  R1791     -3.0162916183471680e+00
    phi[2,4]  R1792     -2.6542499065399170e+00
    phi[2,4]  R1793     -2.5950672626495361e+00
    phi[2,4]  R1794     -2.3996124267578125e+00
    phi[2,4]  R1795     -1.5645024776458740e+00
    phi[2,4]  R1796     -2.0111243724823
    phi[2,4]  R1797     3.8759976625442505e-01
    phi[2,4]  R1798     -2.3692221641540527e+00
    phi[2,4]  R1799     -6.8068438768386841e-01
    phi[2,4]  R1800     7.5522202253341675e-01
    phi[2,4]  R1801     -1.9150774478912354e+00
    phi[2,4]  R1802     -3.5453069210052490e+00
    phi[2,4]  R1803     -2.3972954750061035e+00
    phi[2,4]  R1804     -2.0419905185699463e+00
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1805     -3.0999999046325684e+00
    phi[4,2]  R1806     -3.0999999046325684e+00
    phi[4,2]  R1807     -2.2400000095367432e+00
    phi[4,2]  R1808     -2.2400000095367432e+00
    phi[4,2]  R1809     -3.0999999046325684e+00
    phi[4,2]  R1810     -3.0999999046325684e+00
    phi[4,2]  R1811     -2.5699999332427979e+00
    phi[4,2]  R1812     -2.5699999332427979e+00
    phi[4,2]  R1813     -3.0999999046325684e+00
    phi[4,2]  R1814     -3.0999999046325684e+00
    phi[4,2]  R1815     -2.0899999141693115e+00
    phi[4,2]  R1816     -2.0899999141693115e+00
    phi[4,2]  R1817     -3.0999999046325684e+00
    phi[4,2]  R1818     -3.0999999046325684e+00
    phi[4,2]  R1819     1.0069933533668518e-01
    phi[4,2]  R1820     2.0685143470764160e+00
    phi[4,2]  R1821     5.1308560371398926e-01
    phi[4,2]  R1822     -7.2219479084014893e-01
    phi[4,2]  R1823     2.1128454208374023e+00
    phi[4,2]  R1824     1.6501094102859497e+00
    phi[4,2]  R1825     -6.7144048213958740e-01
    phi[4,2]  R1826     -3.6677727103233337e-01
    phi[4,2]  R1827     3.4622645378112793e-01
    phi[4,2]  R1828     1.3843475282192230e-01
    phi[4,2]  R1829     -2.6625173091888428e+00
    phi[4,2]  R1830     -3.0162916183471680e+00
    phi[4,2]  R1831     -2.6542499065399170e+00
    phi[4,2]  R1832     -2.5950672626495361e+00
    phi[4,2]  R1833     -2.3996124267578125e+00
    phi[4,2]  R1834     -1.5645024776458740e+00
    phi[4,2]  R1835     -2.0111243724823
    phi[4,2]  R1836     3.8759976625442505e-01
    phi[4,2]  R1837     -2.3692221641540527e+00
    phi[4,2]  R1838     -6.8068438768386841e-01
    phi[4,2]  R1839     7.5522202253341675e-01
    phi[4,2]  R1840     -1.9150774478912354e+00
    phi[4,2]  R1841     -3.5453069210052490e+00
    phi[4,2]  R1842     -2.3972954750061035e+00
    phi[4,2]  R1843     -2.0419905185699463e+00
    phi[4,2]  R1844     1.4758145809173584e+00
    phi[4,2]  R1845     1.1983867883682251e+00
    phi[4,2]  R1846     3.0512848496437073e-01
    phi[4,2]  R1847     -8.8237613439559937e-01
    phi[4,2]  R1848     5.7116919755935669e-01
    phi[4,2]  R1849     2.1738813817501068e-01
    phi[4,2]  R1850     1.1170113086700439e+00
    phi[4,2]  R1851     1.5647424459457397e+00
    phi[4,2]  R1852     1.2970077991485596e+00
    phi[4,2]  R1853     1.6711130142211914e+00
    phi[4,2]  R1854     4.8250547051429749e-01
    phi[4,2]  R1855     1.5181962251663208e+00
    phi[4,2]  R1856     2.1828649044036865e+00
    phi[4,2]  R1857     8.3552199602127075e-01
    phi[4,2]  R1858     6.6989642381668091e-01
    phi[4,2]  R1859     2.2758930921554565e-01
    phi[4,2]  R1860     8.2934144884347916e-03
    phi[4,2]  R1861     -0.709333062171936
    phi[4,2]  R1862     -1.4077971875667572e-01
    phi[4,2]  R1863     1.2257226705551147e+00
    phi[4,2]  R1864     -3.4705410003662109e+00
    phi[4,2]  R1865     -2.7444334030151367e+00
    phi[4,2]  R1866     -2.4569869041442871e+00
    phi[4,2]  R1867     -7.7916479110717773e-01
    phi[4,2]  R1868     -6.5530169010162354e-01
    phi[4,2]  R1869     -1.6433355212211609e-01
    phi[4,2]  R1870     -5.1836383342742920e-01
    phi[4,2]  R1871     -2.4087445735931396e+00
    phi[4,2]  R1872     -2.1686570644378662e+00
    phi[4,2]  R1873     -3.6034054756164551e+00
    phi[4,2]  R1874     -2.6684200763702393e+00
    phi[4,2]  R1875     -3.0929505825042725e+00
    phi[4,2]  R1876     -8.2597851753234863e-01
    phi[4,2]  R1877     -3.6565167903900146e+00
    phi[4,2]  R1878     2.2184243202209473e+00
    phi[4,2]  R1879     -1.4401932954788208e+00
    phi[4,2]  R1880     3.6682978272438049e-01
    phi[4,2]  R1881     -3.3107354640960693e+00
    phi[4,2]  R1882     0.544256865978241
    phi[4,2]  R1883     8.2457375526428223e-01
    phi[4,2]  R1884     1.0357154607772827e+00
    phi[4,2]  R1885     7.2899937629699707e-01
    phi[4,2]  R1886     -3.2006654739379883e+00
    phi[4,2]  R1887     2.7064695954322815e-01
    phi[4,2]  R1888     -3.6550498008728027e+00
    phi[4,2]  R1889     -2.1136791706085205e+00
    phi[4,2]  R1890     5.5781573057174683e-01
    phi[4,2]  R1891     -1.9636831283569336e+00
    phi[4,2]  R1892     -1.7818773984909058e+00
    phi[4,2]  R1893     -2.3486313819885254e+00
    phi[4,2]  R1894     -2.4102606773376465e+00
    phi[4,2]  R1895     -2.9555904865264893e+00
    phi[4,2]  R1896     -2.6832270622253418e+00
    phi[4,2]  R1897     -2.1929731369018555e+00
    phi[4,2]  R1898     -1.3810151815414429e+00
    phi[4,2]  R1899     2.2508940696716309e+00
    phi[4,2]  R1900     1.0346199274063110e+00
    phi[4,2]  R1901     -1.1087638139724731e+00
    phi[4,2]  R1902     -1.4026911258697510e+00
    phi[4,2]  R1903     -5.6905913352966309e-01
    phi[4,2]  R1904     -1.1053687334060669e+00
    phi[4,2]  R1905     -2.6835184097290039e+00
    phi[4,2]  R1906     -1.6300997734069824e+00
    phi[4,2]  R1907     6.3460707664489746e-01
    phi[4,2]  R1908     -5.3362709283828735e-01
    phi[4,2]  R1909     -2.7510124444961548e-01
    phi[4,2]  R1910     -3.6803104877471924e+00
    phi[4,2]  R1911     -3.7334370613098145e+00
    phi[4,2]  R1912     -1.4114958047866821e+00
    phi[4,2]  R1913     -1.3174308538436890e+00
    phi[4,2]  R1914     1.0269490480422974e+00
    phi[4,2]  R1915     -5.1630270481109619e-01
    phi[4,2]  R1916     -2.1462390422821045e+00
    phi[4,2]  R1917     -1.6105408668518066e+00
    phi[4,2]  R1918     7.4040405452251434e-02
    phi[4,2]  R1919     -2.1647682189941406e+00
    phi[4,2]  R1920     -1.3209075927734375e+00
    phi[4,2]  R1921     1.2211597710847855e-01
    phi[4,2]  R1922     -3.2136888504028320e+00
    phi[4,2]  R1923     -3.9038136005401611e+00
    phi[4,2]  R1924     -0.316184401512146
    phi[4,2]  R1925     8.7105906009674072e-01
    phi[4,2]  R1926     -1.2304085493087769e+00
    phi[4,2]  R1927     -2.943359375
    phi[4,2]  R1928     -3.4221322536468506e+00
    phi[4,2]  R1929     -2.8777201175689697e+00
    phi[4,2]  R1930     -3.1775608062744141e+00
    phi[4,2]  R1931     -1.3716858625411987e+00
    phi[4,2]  R1932     1.8159927427768707e-01
    phi[4,2]  R1933     -1.2128859013319016e-01
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1934     -3.0999999046325684e+00
    phi[2,5]  R1935     -3.0999999046325684e+00
    phi[2,5]  R1936     -2.2400000095367432e+00
    phi[2,5]  R1937     -2.2400000095367432e+00
    phi[2,5]  R1938     -3.0999999046325684e+00
    phi[2,5]  R1939     -3.0999999046325684e+00
    phi[2,5]  R1940     -2.5699999332427979e+00
    phi[2,5]  R1941     -2.5699999332427979e+00
    phi[2,5]  R1942     -3.0999999046325684e+00
    phi[2,5]  R1943     -3.0999999046325684e+00
    phi[2,5]  R1944     -2.0899999141693115e+00
    phi[2,5]  R1945     -2.0899999141693115e+00
    phi[2,5]  R1946     -3.0999999046325684e+00
    phi[2,5]  R1947     -3.0999999046325684e+00
    phi[2,5]  R1948     1.4758145809173584e+00
    phi[2,5]  R1949     1.1983867883682251e+00
    phi[2,5]  R1950     3.0512848496437073e-01
    phi[2,5]  R1951     -8.8237613439559937e-01
    phi[2,5]  R1952     5.7116919755935669e-01
    phi[2,5]  R1953     2.1738813817501068e-01
    phi[2,5]  R1954     1.1170113086700439e+00
    phi[2,5]  R1955     1.5647424459457397e+00
    phi[2,5]  R1956     1.2970077991485596e+00
    phi[2,5]  R1957     1.6711130142211914e+00
    phi[2,5]  R1958     4.8250547051429749e-01
    phi[2,5]  R1959     1.5181962251663208e+00
    phi[2,5]  R1960     2.1828649044036865e+00
    phi[2,5]  R1961     8.3552199602127075e-01
    phi[2,5]  R1962     6.6989642381668091e-01
    phi[2,5]  R1963     2.2758930921554565e-01
    phi[2,5]  R1964     8.2934144884347916e-03
    phi[2,5]  R1965     -0.709333062171936
    phi[2,5]  R1966     -1.4077971875667572e-01
    phi[2,5]  R1967     1.2257226705551147e+00
    phi[2,5]  R1968     -3.4705410003662109e+00
    phi[2,5]  R1969     -2.7444334030151367e+00
    phi[2,5]  R1970     -2.4569869041442871e+00
    phi[2,5]  R1971     -7.7916479110717773e-01
    phi[2,5]  R1972     -6.5530169010162354e-01
    phi[2,5]  R1973     -1.6433355212211609e-01
    phi[2,5]  R1974     -5.1836383342742920e-01
    phi[2,5]  R1975     -2.4087445735931396e+00
    phi[2,5]  R1976     -2.1686570644378662e+00
    phi[2,5]  R1977     -3.6034054756164551e+00
    phi[2,5]  R1978     -2.6684200763702393e+00
    phi[2,5]  R1979     -3.0929505825042725e+00
    phi[2,5]  R1980     -8.2597851753234863e-01
    phi[2,5]  R1981     -3.6565167903900146e+00
    phi[2,5]  R1982     2.2184243202209473e+00
    phi[2,5]  R1983     -1.4401932954788208e+00
    phi[2,5]  R1984     3.6682978272438049e-01
    phi[2,5]  R1985     -3.3107354640960693e+00
    phi[2,5]  R1986     0.544256865978241
    phi[2,5]  R1987     8.2457375526428223e-01
    phi[2,5]  R1988     1.0357154607772827e+00
    phi[2,5]  R1989     7.2899937629699707e-01
    phi[2,5]  R1990     -3.2006654739379883e+00
    phi[2,5]  R1991     2.7064695954322815e-01
    phi[2,5]  R1992     -3.6550498008728027e+00
    phi[2,5]  R1993     -2.1136791706085205e+00
    phi[2,5]  R1994     5.5781573057174683e-01
    phi[2,5]  R1995     -1.9636831283569336e+00
    phi[2,5]  R1996     -1.7818773984909058e+00
    phi[2,5]  R1997     -2.3486313819885254e+00
    phi[2,5]  R1998     -2.4102606773376465e+00
    phi[2,5]  R1999     -2.9555904865264893e+00
    phi[2,5]  R2000     -2.6832270622253418e+00
    phi[2,5]  R2001     -2.1929731369018555e+00
    phi[2,5]  R2002     -1.3810151815414429e+00
    phi[2,5]  R2003     2.2508940696716309e+00
    phi[2,5]  R2004     1.0346199274063110e+00
    phi[2,5]  R2005     -1.1087638139724731e+00
    phi[2,5]  R2006     -1.4026911258697510e+00
    phi[2,5]  R2007     -5.6905913352966309e-01
    phi[2,5]  R2008     -1.1053687334060669e+00
    phi[2,5]  R2009     -2.6835184097290039e+00
    phi[2,5]  R2010     -1.6300997734069824e+00
    phi[2,5]  R2011     6.3460707664489746e-01
    phi[2,5]  R2012     -5.3362709283828735e-01
    phi[2,5]  R2013     -2.7510124444961548e-01
    phi[2,5]  R2014     -3.6803104877471924e+00
    phi[2,5]  R2015     -3.7334370613098145e+00
    phi[2,5]  R2016     -1.4114958047866821e+00
    phi[2,5]  R2017     -1.3174308538436890e+00
    phi[2,5]  R2018     1.0269490480422974e+00
    phi[2,5]  R2019     -5.1630270481109619e-01
    phi[2,5]  R2020     -2.1462390422821045e+00
    phi[2,5]  R2021     -1.6105408668518066e+00
    phi[2,5]  R2022     7.4040405452251434e-02
    phi[2,5]  R2023     -2.1647682189941406e+00
    phi[2,5]  R2024     -1.3209075927734375e+00
    phi[2,5]  R2025     1.2211597710847855e-01
    phi[2,5]  R2026     -3.2136888504028320e+00
    phi[2,5]  R2027     -3.9038136005401611e+00
    phi[2,5]  R2028     -0.316184401512146
    phi[2,5]  R2029     8.7105906009674072e-01
    phi[2,5]  R2030     -1.2304085493087769e+00
    phi[2,5]  R2031     -2.943359375
    phi[2,5]  R2032     -3.4221322536468506e+00
    phi[2,5]  R2033     -2.8777201175689697e+00
    phi[2,5]  R2034     -3.1775608062744141e+00
    phi[2,5]  R2035     -1.3716858625411987e+00
    phi[2,5]  R2036     1.8159927427768707e-01
    phi[2,5]  R2037     -1.2128859013319016e-01
    phi[2,5]  R2038     1.6159764528274536e+00
    phi[2,5]  R2039     7.3009330034255981e-01
    phi[2,5]  R2040     5.2580791711807251e-01
    phi[2,5]  R2041     8.1365460157394409e-01
    phi[2,5]  R2042     -7.8649681806564331e-01
    phi[2,5]  R2043     -1.0748572647571564e-01
    phi[2,5]  R2044     -2.2303009033203125e+00
    phi[2,5]  R2045     2.7489697933197021e+00
    phi[2,5]  R2046     2.1882367134094238e+00
    phi[2,5]  R2047     2.2065770626068115e+00
    phi[2,5]  R2048     -1.8265733718872070e+00
    phi[2,5]  R2049     -0.137929305434227
    phi[2,5]  R2050     -1.7446128129959106e+00
    phi[2,5]  R2051     -9.3039298057556152e-01
    phi[2,5]  R2052     -1.7700532674789429e+00
    phi[2,5]  R2053     -5.2321439981460571e-01
    phi[2,5]  R2054     -2.1908600330352783e+00
    phi[2,5]  R2055     -2.7775921821594238e+00
    phi[2,5]  R2056     -3.9528522491455078e+00
    phi[2,5]  R2057     -2.65352201461792
    phi[2,5]  R2058     -1.5018348395824432e-01
    phi[2,5]  R2059     -2.94931960105896
    phi[2,5]  R2060     -1.9365466833114624e+00
    phi[2,5]  R2061     -3.3338909149169922e+00
    phi[2,5]  R2062     -3.0957643985748291e+00
    phi[2,5]  R2063     -2.3715000152587891e+00
    phi[2,5]  R2064     -4.2080540657043457e+00
    phi[2,5]  R2065     -2.3986940383911133e+00
    phi[2,5]  R2066     -2.2275218963623047e+00
    phi[2,5]  R2067     -3.9052727222442627e+00
    phi[2,5]  R2068     -5.0226032733917236e-01
    phi[2,5]  R2069     -2.4277970790863037e+00
    phi[2,5]  R2070     -2.1121904850006104e+00
    phi[2,5]  R2071     -1.0808832645416260e+00
    phi[2,5]  R2072     -3.1597013473510742e+00
    phi[2,5]  R2073     -3.7193052768707275e+00
    phi[2,5]  R2074     -4.0714473724365234e+00
    phi[2,5]  R2075     -3.5343732833862305e+00
    phi[2,5]  R2076     -3.7382705211639404e+00
    phi[2,5]  R2077     -1.3741468191146851e+00
    phi[2,5]  R2078     -7.1413916349411011e-01
    phi[2,5]  R2079     -2.2223873138427734e+00
    phi[2,5]  R2080     -1.9274870157241821e+00
    phi[2,5]  R2081     -3.3390325307846069e-01
    phi[2,5]  R2082     -2.4610452651977539e+00
    phi[2,5]  R2083     -3.2039291858673096e+00
    phi[2,5]  R2084     -2.0271937847137451e+00
    phi[2,5]  R2085     -2.4007794857025146e+00
    phi[2,5]  R2086     -1.3676869869232178e+00
    phi[2,5]  R2087     -3.7167675495147705e+00
    phi[2,5]  R2088     -2.1951284408569336e+00
    phi[2,5]  R2089     -8.4660136699676514e-01
    phi[2,5]  R2090     -2.5907800197601318e+00
    phi[2,5]  R2091     -2.2088646888732910e+00
    phi[2,5]  R2092     -2.5556418895721436e+00
    phi[2,5]  R2093     -1.1774408817291260e+00
    phi[2,5]  R2094     -1.4089405536651611e+00
    phi[2,5]  R2095     -3.6982412338256836e+00
    phi[2,5]  R2096     -2.6501352787017822e+00
    phi[2,5]  R2097     4.7478699684143066e-01
    phi[2,5]  R2098     -2.4017119780182838e-02
    phi[2,5]  R2099     -1.7241708040237427e+00
    phi[2,5]  R2100     -1.1449874639511108e+00
    phi[2,5]  R2101     -9.5726456493139267e-03
    phi[2,5]  R2102     -3.5190050601959229e+00
    phi[2,5]  R2103     -3.7474122047424316e+00
    phi[2,5]  R2104     -3.7584192752838135e+00
    phi[2,5]  R2105     -2.6990950107574463e-01
    phi[2,5]  R2106     -2.6369037628173828e+00
    phi[2,5]  R2107     1.4033931493759155e+00
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R2108     -3.0999999046325684e+00
    phi[5,2]  R2109     -3.0999999046325684e+00
    phi[5,2]  R2110     -2.2400000095367432e+00
    phi[5,2]  R2111     -2.2400000095367432e+00
    phi[5,2]  R2112     -3.0999999046325684e+00
    phi[5,2]  R2113     -3.0999999046325684e+00
    phi[5,2]  R2114     -2.5699999332427979e+00
    phi[5,2]  R2115     -2.5699999332427979e+00
    phi[5,2]  R2116     -3.0999999046325684e+00
    phi[5,2]  R2117     -3.0999999046325684e+00
    phi[5,2]  R2118     -2.0899999141693115e+00
    phi[5,2]  R2119     -2.0899999141693115e+00
    phi[5,2]  R2120     -3.0999999046325684e+00
    phi[5,2]  R2121     -3.0999999046325684e+00
    phi[5,2]  R2122     1.6159764528274536e+00
    phi[5,2]  R2123     7.3009330034255981e-01
    phi[5,2]  R2124     5.2580791711807251e-01
    phi[5,2]  R2125     8.1365460157394409e-01
    phi[5,2]  R2126     -7.8649681806564331e-01
    phi[5,2]  R2127     -1.0748572647571564e-01
    phi[5,2]  R2128     -2.2303009033203125e+00
    phi[5,2]  R2129     2.7489697933197021e+00
    phi[5,2]  R2130     2.1882367134094238e+00
    phi[5,2]  R2131     2.2065770626068115e+00
    phi[5,2]  R2132     -1.8265733718872070e+00
    phi[5,2]  R2133     -0.137929305434227
    phi[5,2]  R2134     -1.7446128129959106e+00
    phi[5,2]  R2135     -9.3039298057556152e-01
    phi[5,2]  R2136     -1.7700532674789429e+00
    phi[5,2]  R2137     -5.2321439981460571e-01
    phi[5,2]  R2138     -2.1908600330352783e+00
    phi[5,2]  R2139     -2.7775921821594238e+00
    phi[5,2]  R2140     -3.9528522491455078e+00
    phi[5,2]  R2141     -2.65352201461792
    phi[5,2]  R2142     -1.5018348395824432e-01
    phi[5,2]  R2143     -2.94931960105896
    phi[5,2]  R2144     -1.9365466833114624e+00
    phi[5,2]  R2145     -3.3338909149169922e+00
    phi[5,2]  R2146     -3.0957643985748291e+00
    phi[5,2]  R2147     -2.3715000152587891e+00
    phi[5,2]  R2148     -4.2080540657043457e+00
    phi[5,2]  R2149     -2.3986940383911133e+00
    phi[5,2]  R2150     -2.2275218963623047e+00
    phi[5,2]  R2151     -3.9052727222442627e+00
    phi[5,2]  R2152     -5.0226032733917236e-01
    phi[5,2]  R2153     -2.4277970790863037e+00
    phi[5,2]  R2154     -2.1121904850006104e+00
    phi[5,2]  R2155     -1.0808832645416260e+00
    phi[5,2]  R2156     -3.1597013473510742e+00
    phi[5,2]  R2157     -3.7193052768707275e+00
    phi[5,2]  R2158     -4.0714473724365234e+00
    phi[5,2]  R2159     -3.5343732833862305e+00
    phi[5,2]  R2160     -3.7382705211639404e+00
    phi[5,2]  R2161     -1.3741468191146851e+00
    phi[5,2]  R2162     -7.1413916349411011e-01
    phi[5,2]  R2163     -2.2223873138427734e+00
    phi[5,2]  R2164     -1.9274870157241821e+00
    phi[5,2]  R2165     -3.3390325307846069e-01
    phi[5,2]  R2166     -2.4610452651977539e+00
    phi[5,2]  R2167     -3.2039291858673096e+00
    phi[5,2]  R2168     -2.0271937847137451e+00
    phi[5,2]  R2169     -2.4007794857025146e+00
    phi[5,2]  R2170     -1.3676869869232178e+00
    phi[5,2]  R2171     -3.7167675495147705e+00
    phi[5,2]  R2172     -2.1951284408569336e+00
    phi[5,2]  R2173     -8.4660136699676514e-01
    phi[5,2]  R2174     -2.5907800197601318e+00
    phi[5,2]  R2175     -2.2088646888732910e+00
    phi[5,2]  R2176     -2.5556418895721436e+00
    phi[5,2]  R2177     -1.1774408817291260e+00
    phi[5,2]  R2178     -1.4089405536651611e+00
    phi[5,2]  R2179     -3.6982412338256836e+00
    phi[5,2]  R2180     -2.6501352787017822e+00
    phi[5,2]  R2181     4.7478699684143066e-01
    phi[5,2]  R2182     -2.4017119780182838e-02
    phi[5,2]  R2183     -1.7241708040237427e+00
    phi[5,2]  R2184     -1.1449874639511108e+00
    phi[5,2]  R2185     -9.5726456493139267e-03
    phi[5,2]  R2186     -3.5190050601959229e+00
    phi[5,2]  R2187     -3.7474122047424316e+00
    phi[5,2]  R2188     -3.7584192752838135e+00
    phi[5,2]  R2189     -2.6990950107574463e-01
    phi[5,2]  R2190     -2.6369037628173828e+00
    phi[5,2]  R2191     1.4033931493759155e+00
    phi[5,2]  R2192     1.4758145809173584e+00
    phi[5,2]  R2193     1.1983867883682251e+00
    phi[5,2]  R2194     3.0512848496437073e-01
    phi[5,2]  R2195     -8.8237613439559937e-01
    phi[5,2]  R2196     5.7116919755935669e-01
    phi[5,2]  R2197     2.1738813817501068e-01
    phi[5,2]  R2198     1.1170113086700439e+00
    phi[5,2]  R2199     1.5647424459457397e+00
    phi[5,2]  R2200     1.2970077991485596e+00
    phi[5,2]  R2201     1.6711130142211914e+00
    phi[5,2]  R2202     4.8250547051429749e-01
    phi[5,2]  R2203     1.5181962251663208e+00
    phi[5,2]  R2204     2.1828649044036865e+00
    phi[5,2]  R2205     8.3552199602127075e-01
    phi[5,2]  R2206     6.6989642381668091e-01
    phi[5,2]  R2207     2.2758930921554565e-01
    phi[5,2]  R2208     8.2934144884347916e-03
    phi[5,2]  R2209     -0.709333062171936
    phi[5,2]  R2210     -1.4077971875667572e-01
    phi[5,2]  R2211     1.2257226705551147e+00
    phi[5,2]  R2212     -3.4705410003662109e+00
    phi[5,2]  R2213     -2.7444334030151367e+00
    phi[5,2]  R2214     -2.4569869041442871e+00
    phi[5,2]  R2215     -7.7916479110717773e-01
    phi[5,2]  R2216     -6.5530169010162354e-01
    phi[5,2]  R2217     -1.6433355212211609e-01
    phi[5,2]  R2218     -5.1836383342742920e-01
    phi[5,2]  R2219     -2.4087445735931396e+00
    phi[5,2]  R2220     -2.1686570644378662e+00
    phi[5,2]  R2221     -3.6034054756164551e+00
    phi[5,2]  R2222     -2.6684200763702393e+00
    phi[5,2]  R2223     -3.0929505825042725e+00
    phi[5,2]  R2224     -8.2597851753234863e-01
    phi[5,2]  R2225     -3.6565167903900146e+00
    phi[5,2]  R2226     2.2184243202209473e+00
    phi[5,2]  R2227     -1.4401932954788208e+00
    phi[5,2]  R2228     3.6682978272438049e-01
    phi[5,2]  R2229     -3.3107354640960693e+00
    phi[5,2]  R2230     0.544256865978241
    phi[5,2]  R2231     8.2457375526428223e-01
    phi[5,2]  R2232     1.0357154607772827e+00
    phi[5,2]  R2233     7.2899937629699707e-01
    phi[5,2]  R2234     -3.2006654739379883e+00
    phi[5,2]  R2235     2.7064695954322815e-01
    phi[5,2]  R2236     -3.6550498008728027e+00
    phi[5,2]  R2237     -2.1136791706085205e+00
    phi[5,2]  R2238     5.5781573057174683e-01
    phi[5,2]  R2239     -1.9636831283569336e+00
    phi[5,2]  R2240     -1.7818773984909058e+00
    phi[5,2]  R2241     -2.3486313819885254e+00
    phi[5,2]  R2242     -2.4102606773376465e+00
    phi[5,2]  R2243     -2.9555904865264893e+00
    phi[5,2]  R2244     -2.6832270622253418e+00
    phi[5,2]  R2245     -2.1929731369018555e+00
    phi[5,2]  R2246     -1.3810151815414429e+00
    phi[5,2]  R2247     2.2508940696716309e+00
    phi[5,2]  R2248     1.0346199274063110e+00
    phi[5,2]  R2249     -1.1087638139724731e+00
    phi[5,2]  R2250     -1.4026911258697510e+00
    phi[5,2]  R2251     -5.6905913352966309e-01
    phi[5,2]  R2252     -1.1053687334060669e+00
    phi[5,2]  R2253     -2.6835184097290039e+00
    phi[5,2]  R2254     -1.6300997734069824e+00
    phi[5,2]  R2255     6.3460707664489746e-01
    phi[5,2]  R2256     -5.3362709283828735e-01
    phi[5,2]  R2257     -2.7510124444961548e-01
    phi[5,2]  R2258     -3.6803104877471924e+00
    phi[5,2]  R2259     -3.7334370613098145e+00
    phi[5,2]  R2260     -1.4114958047866821e+00
    phi[5,2]  R2261     -1.3174308538436890e+00
    phi[5,2]  R2262     1.0269490480422974e+00
    phi[5,2]  R2263     -5.1630270481109619e-01
    phi[5,2]  R2264     -2.1462390422821045e+00
    phi[5,2]  R2265     -1.6105408668518066e+00
    phi[5,2]  R2266     7.4040405452251434e-02
    phi[5,2]  R2267     -2.1647682189941406e+00
    phi[5,2]  R2268     -1.3209075927734375e+00
    phi[5,2]  R2269     1.2211597710847855e-01
    phi[5,2]  R2270     -3.2136888504028320e+00
    phi[5,2]  R2271     -3.9038136005401611e+00
    phi[5,2]  R2272     -0.316184401512146
    phi[5,2]  R2273     8.7105906009674072e-01
    phi[5,2]  R2274     -1.2304085493087769e+00
    phi[5,2]  R2275     -2.943359375
    phi[5,2]  R2276     -3.4221322536468506e+00
    phi[5,2]  R2277     -2.8777201175689697e+00
    phi[5,2]  R2278     -3.1775608062744141e+00
    phi[5,2]  R2279     -1.3716858625411987e+00
    phi[5,2]  R2280     1.8159927427768707e-01
    phi[5,2]  R2281     -1.2128859013319016e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R20       -1.6814449973130228e+00
    phi[2,7]  R21       -1.3680260411050198e+00
    phi[2,7]  R22       9.3401107175153664e-01
    phi[2,7]  R23       1.6819717399199228e+00
    phi[2,7]  R24       2.5841971855592067e+00
    phi[2,7]  R25       -9.8022122966922254e-01
    phi[2,7]  R26       -4.6925242773029652e-01
    phi[2,7]  R55       -1
    phi[2,7]  R2282     -4.7814449019455907e+00
    phi[2,7]  R2283     -1.4185549073195456e+00
    phi[2,7]  R2284     -3.6080260506417630e+00
    phi[2,7]  R2285     -8.7197396843172337e-01
    phi[2,7]  R2286     -2.1659888328810317e+00
    phi[2,7]  R2287     -4.0340109763841046e+00
    phi[2,7]  R2288     -8.8802819332287508e-01
    phi[2,7]  R2289     -4.25197167316272
    phi[2,7]  R2290     -5.1580271907336162e-01
    phi[2,7]  R2291     -5.6841970901917751e+00
    phi[2,7]  R2292     -3.0702211438385341e+00
    phi[2,7]  R2293     -1.1097786845000890e+00
    phi[2,7]  R2294     -3.5692523323628649e+00
    phi[2,7]  R2295     -2.6307474769022718e+00
    phi[2,7]  R2296     -1.7530427228339929e-01
    phi[2,7]  R2297     -1.8225117216861331e-01
    phi[2,7]  R2298     -1.8708462210715171e-01
    phi[2,7]  R2299     -1.9039077901878754e-01
    phi[2,7]  R2300     -2.0508895773166858e-01
    phi[2,7]  R2301     -0.205750532955838
    phi[2,7]  R2302     -0.209634523366669
    phi[2,7]  R2303     -2.1486383926055308e-01
    phi[2,7]  R2304     -2.2658732010353688e-01
    phi[2,7]  R2305     -2.3489524938304629e-01
    phi[2,7]  R2306     -4.4268463970557625e-01
    phi[2,7]  R2307     -4.5576005724554358e-01
    phi[2,7]  R2308     -4.6371273299762628e-01
    phi[2,7]  R2309     -4.8822551427543259e-01
    phi[2,7]  R2310     -5.0915319862915642e-01
    phi[2,7]  R2311     -9.3506081147800169e-01
    phi[2,7]  R2312     -1.0437445199898376e+00
    phi[2,7]  R2313     -1.2659172477122707e+00
    phi[2,7]  R2314     -8.9817110479770079e-01
    phi[2,7]  R2315     -7.1621377403053121e-01
    phi[2,7]  R2316     -6.2671533053662776e-01
    phi[2,7]  R2317     -6.2681935713931392e-01
    phi[2,7]  R2318     -6.4283399498857330e-01
    phi[2,7]  R2319     -1.2541869414220714e+00
    phi[2,7]  R2320     -1.3057160704302604e+00
    phi[2,7]  R2321     -1.1132220668808093e+00
    phi[2,7]  R2322     -8.7862791751762148e-01
    phi[2,7]  R2323     -7.8463840280646435e-01
    phi[2,7]  R2324     -0.78918783033158
    phi[2,7]  R2325     -7.8945842452321680e-01
    phi[2,7]  R2326     -4.0265630273951780e-01
    phi[2,7]  R2327     -4.6947527315860205e-01
    phi[2,7]  R2328     -4.9095849040826173e-01
    phi[2,7]  R2329     -6.3387060244771121e-01
    phi[2,7]  R2330     -6.7719665012361041e-01
    phi[2,7]  R2331     -0.678630081393737
    phi[2,7]  R2332     -1.0809608702831448e+00
    phi[2,7]  R2333     -6.9455304008039320e-01
    phi[2,7]  R2334     -1.3868992279287118e+00
    phi[2,7]  R2335     -1.2995321125786665e+00
    phi[2,7]  R2336     -4.3143373885697112e-01
    phi[2,7]  R2337     -4.8197147036501309e-01
    phi[2,7]  R2338     -4.9250240095927955e-01
    phi[2,7]  R2339     -5.2721758751194392e-01
    phi[2,7]  R2340     -5.6276195868431955e-01
    phi[2,7]  R2341     -6.3357120077010087e-01
    phi[2,7]  R2342     -1.2236447841775084e+00
    phi[2,7]  R2343     -7.2761867389786961e-01
    phi[2,7]  R2344     -1.5359834030255481e+00
    phi[2,7]  R2345     -7.4048376517342174e-01
    phi[2,7]  R2346     -3.0080679705805968e-01
    phi[2,7]  R2347     -3.1147855164680527e-01
    phi[2,7]  R2348     -3.3127301808322773e-01
    phi[2,7]  R2349     -0.340439874696713
    phi[2,7]  R2350     -3.5604602583441691e-01
    phi[2,7]  R2351     -3.9497750491049644e-01
    phi[2,7]  R2352     -4.0530413698080281e-01
    phi[2,7]  R2353     -4.0984974227427862e-01
    phi[2,7]  R2354     -6.0724375993367075e-01
    phi[2,7]  R2355     -1.4076181006106161e+00
    phi[2,7]  R2356     -2.3109117094709564e-01
    phi[2,7]  R2357     -4.0435562431959449e-01
    phi[2,7]  R2358     -5.6162502624623722e-01
    phi[2,7]  R2359     -1.0251920538378705e+00
    phi[2,7]  R2360     -1.1556588843292532e+00
    phi[2,7]  R2361     -1.4330554118436190e+00
    phi[2,7]  R2362     -7.6833118456323435e-01
    phi[2,7]  R2363     -8.0653333053376430e-01
    phi[2,7]  R2364     -1.3722051735701961e+00
    phi[2,7]  R2365     -1.2420572662739906e+00
    phi[2,7]  R2366     -1.0962778255464238e+00
    phi[2,7]  R2367     -1.4833135750403552e+00
    phi[2,7]  R2368     -7.0583718605990331e-01
    phi[2,7]  R2369     -7.2572872635023189e-01
    phi[2,7]  R2370     -7.5054490197789991e-01
    phi[2,7]  R2371     -1.2573938434096525e+00
    phi[2,7]  R2372     -1.4510951419460667e+00
    phi[2,7]  R2373     -1.0282517300785583e+00
    phi[2,7]  R2374     -8.9450264546063307e-01
    phi[2,7]  R2375     -8.9545940268260660e-01
    phi[2,7]  R2376     -1.1706010548915837e+00
    phi[2,7]  R2377     -7.9333072836582863e-01
    phi[2,7]  R2378     -1.3142519420293497e+00
    phi[2,7]  R2379     -8.4820111008018717e-01
    phi[2,7]  R2380     -8.6210599370432961e-01
    phi[2,7]  R2381     -8.6273152841651868e-01
    phi[2,7]  R2382     -0.915902113265104
    phi[2,7]  R2383     -9.5218291651617593e-01
    phi[2,7]  R2384     -9.5814564509710687e-01
    phi[2,7]  R2385     -9.7250292634144508e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2386     -3.0999999046325684e+00
    phi[3,4]  R2387     -3.0999999046325684e+00
    phi[3,4]  R2388     -2.2400000095367432e+00
    phi[3,4]  R2389     -2.2400000095367432e+00
    phi[3,4]  R2390     -3.0999999046325684e+00
    phi[3,4]  R2391     -3.0999999046325684e+00
    phi[3,4]  R2392     -2.5699999332427979e+00
    phi[3,4]  R2393     -2.5699999332427979e+00
    phi[3,4]  R2394     -3.0999999046325684e+00
    phi[3,4]  R2395     -3.0999999046325684e+00
    phi[3,4]  R2396     -2.0899999141693115e+00
    phi[3,4]  R2397     -2.0899999141693115e+00
    phi[3,4]  R2398     -3.0999999046325684e+00
    phi[3,4]  R2399     -3.0999999046325684e+00
    phi[3,4]  R2400     1.4070525169372559e+00
    phi[3,4]  R2401     -1.8637837171554565e+00
    phi[3,4]  R2402     1.9244442880153656e-01
    phi[3,4]  R2403     1.3560693264007568e+00
    phi[3,4]  R2404     1.4406063556671143e+00
    phi[3,4]  R2405     1.7186269164085388e-01
    phi[3,4]  R2406     -9.3275710940361023e-02
    phi[3,4]  R2407     1.7816181182861328e+00
    phi[3,4]  R2408     -6.4245003461837769e-01
    phi[3,4]  R2409     2.9749801754951477e-01
    phi[3,4]  R2410     -4.4891899824142456e-01
    phi[3,4]  R2411     -3.1700937747955322e+00
    phi[3,4]  R2412     -1.9243576526641846e+00
    phi[3,4]  R2413     -1.5361006259918213e+00
    phi[3,4]  R2414     -2.4537868499755859e+00
    phi[3,4]  R2415     -3.2084760665893555e+00
    phi[3,4]  R2416     -1.2035303115844727e+00
    phi[3,4]  R2417     5.1626634597778320e-01
    phi[3,4]  R2418     -2.7643303871154785e+00
    phi[3,4]  R2419     -1.2511644363403320e+00
    phi[3,4]  R2420     -5.4061406850814819e-01
    phi[3,4]  R2421     -1.7634431123733521e+00
    phi[3,4]  R2422     -2.9313471913337708e-01
    phi[3,4]  R2423     -1.9044030904769897e+00
    phi[3,4]  R2424     -1.1824598312377930e+00
    phi[3,4]  R2425     1.4344557523727417e+00
    phi[3,4]  R2426     1.2335806339979172e-01
    phi[3,4]  R2427     -2.3884711265563965e+00
    phi[3,4]  R2428     -9.5272518694400787e-02
    phi[3,4]  R2429     -3.4296461939811707e-01
    phi[3,4]  R2430     -6.0556423664093018e-01
    phi[3,4]  R2431     -1.6014730930328369e+00
    phi[3,4]  R2432     2.5656518340110779e-01
    phi[3,4]  R2433     -4.1291669011116028e-02
    phi[3,4]  R2434     -2.9346027374267578e+00
    phi[3,4]  R2435     1.9327629357576370e-02
    phi[3,4]  R2436     -1.6578621864318848e+00
    phi[3,4]  R2437     -6.2594634294509888e-01
    phi[3,4]  R2438     -1.3554449081420898e+00
    phi[3,4]  R2439     -1.1527673006057739e+00
    phi[3,4]  R2440     -2.4211235046386719e+00
    phi[3,4]  R2441     -6.8074566125869751e-01
    phi[3,4]  R2442     1.0860924720764160e+00
    phi[3,4]  R2443     0.00563911022618413
    phi[3,4]  R2444     7.8278881311416626e-01
    phi[3,4]  R2445     -1.0468118190765381e+00
    phi[3,4]  R2446     -2.9776937961578369e+00
    phi[3,4]  R2447     -1.0210758447647095e+00
    phi[3,4]  R2448     -2.3779196739196777e+00
    phi[3,4]  R2449     -1.4153889417648315e+00
    phi[3,4]  R2450     -9.5132905244827271e-01
    phi[3,4]  R2451     1.9264270365238190e-01
    phi[3,4]  R2452     1.0570249557495117e+00
    phi[3,4]  R2453     -7.4598133563995361e-01
    phi[3,4]  R2454     -2.8410035371780396e-01
    phi[3,4]  R2455     -1.5174251794815063e+00
    phi[3,4]  R2456     1.88840651512146
    phi[3,4]  R2457     1.1256448030471802e+00
    phi[3,4]  R2458     1.28672194480896
    phi[3,4]  R2459     1.1664819717407227e+00
    phi[3,4]  R2460     1.0069933533668518e-01
    phi[3,4]  R2461     2.0685143470764160e+00
    phi[3,4]  R2462     5.1308560371398926e-01
    phi[3,4]  R2463     -7.2219479084014893e-01
    phi[3,4]  R2464     2.1128454208374023e+00
    phi[3,4]  R2465     1.6501094102859497e+00
    phi[3,4]  R2466     -6.7144048213958740e-01
    phi[3,4]  R2467     -3.6677727103233337e-01
    phi[3,4]  R2468     3.4622645378112793e-01
    phi[3,4]  R2469     1.3843475282192230e-01
    phi[3,4]  R2470     -2.6625173091888428e+00
    phi[3,4]  R2471     -3.0162916183471680e+00
    phi[3,4]  R2472     -2.6542499065399170e+00
    phi[3,4]  R2473     -2.5950672626495361e+00
    phi[3,4]  R2474     -2.3996124267578125e+00
    phi[3,4]  R2475     -1.5645024776458740e+00
    phi[3,4]  R2476     -2.0111243724823
    phi[3,4]  R2477     3.8759976625442505e-01
    phi[3,4]  R2478     -2.3692221641540527e+00
    phi[3,4]  R2479     -6.8068438768386841e-01
    phi[3,4]  R2480     7.5522202253341675e-01
    phi[3,4]  R2481     -1.9150774478912354e+00
    phi[3,4]  R2482     -3.5453069210052490e+00
    phi[3,4]  R2483     -2.3972954750061035e+00
    phi[3,4]  R2484     -2.0419905185699463e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2485     -3.0999999046325684e+00
    phi[4,3]  R2486     -3.0999999046325684e+00
    phi[4,3]  R2487     -2.2400000095367432e+00
    phi[4,3]  R2488     -2.2400000095367432e+00
    phi[4,3]  R2489     -3.0999999046325684e+00
    phi[4,3]  R2490     -3.0999999046325684e+00
    phi[4,3]  R2491     -2.5699999332427979e+00
    phi[4,3]  R2492     -2.5699999332427979e+00
    phi[4,3]  R2493     -3.0999999046325684e+00
    phi[4,3]  R2494     -3.0999999046325684e+00
    phi[4,3]  R2495     -2.0899999141693115e+00
    phi[4,3]  R2496     -2.0899999141693115e+00
    phi[4,3]  R2497     -3.0999999046325684e+00
    phi[4,3]  R2498     -3.0999999046325684e+00
    phi[4,3]  R2499     1.0069933533668518e-01
    phi[4,3]  R2500     2.0685143470764160e+00
    phi[4,3]  R2501     5.1308560371398926e-01
    phi[4,3]  R2502     -7.2219479084014893e-01
    phi[4,3]  R2503     2.1128454208374023e+00
    phi[4,3]  R2504     1.6501094102859497e+00
    phi[4,3]  R2505     -6.7144048213958740e-01
    phi[4,3]  R2506     -3.6677727103233337e-01
    phi[4,3]  R2507     3.4622645378112793e-01
    phi[4,3]  R2508     1.3843475282192230e-01
    phi[4,3]  R2509     -2.6625173091888428e+00
    phi[4,3]  R2510     -3.0162916183471680e+00
    phi[4,3]  R2511     -2.6542499065399170e+00
    phi[4,3]  R2512     -2.5950672626495361e+00
    phi[4,3]  R2513     -2.3996124267578125e+00
    phi[4,3]  R2514     -1.5645024776458740e+00
    phi[4,3]  R2515     -2.0111243724823
    phi[4,3]  R2516     3.8759976625442505e-01
    phi[4,3]  R2517     -2.3692221641540527e+00
    phi[4,3]  R2518     -6.8068438768386841e-01
    phi[4,3]  R2519     7.5522202253341675e-01
    phi[4,3]  R2520     -1.9150774478912354e+00
    phi[4,3]  R2521     -3.5453069210052490e+00
    phi[4,3]  R2522     -2.3972954750061035e+00
    phi[4,3]  R2523     -2.0419905185699463e+00
    phi[4,3]  R2524     1.4070525169372559e+00
    phi[4,3]  R2525     -1.8637837171554565e+00
    phi[4,3]  R2526     1.9244442880153656e-01
    phi[4,3]  R2527     1.3560693264007568e+00
    phi[4,3]  R2528     1.4406063556671143e+00
    phi[4,3]  R2529     1.7186269164085388e-01
    phi[4,3]  R2530     -9.3275710940361023e-02
    phi[4,3]  R2531     1.7816181182861328e+00
    phi[4,3]  R2532     -6.4245003461837769e-01
    phi[4,3]  R2533     2.9749801754951477e-01
    phi[4,3]  R2534     -4.4891899824142456e-01
    phi[4,3]  R2535     -3.1700937747955322e+00
    phi[4,3]  R2536     -1.9243576526641846e+00
    phi[4,3]  R2537     -1.5361006259918213e+00
    phi[4,3]  R2538     -2.4537868499755859e+00
    phi[4,3]  R2539     -3.2084760665893555e+00
    phi[4,3]  R2540     -1.2035303115844727e+00
    phi[4,3]  R2541     5.1626634597778320e-01
    phi[4,3]  R2542     -2.7643303871154785e+00
    phi[4,3]  R2543     -1.2511644363403320e+00
    phi[4,3]  R2544     -5.4061406850814819e-01
    phi[4,3]  R2545     -1.7634431123733521e+00
    phi[4,3]  R2546     -2.9313471913337708e-01
    phi[4,3]  R2547     -1.9044030904769897e+00
    phi[4,3]  R2548     -1.1824598312377930e+00
    phi[4,3]  R2549     1.4344557523727417e+00
    phi[4,3]  R2550     1.2335806339979172e-01
    phi[4,3]  R2551     -2.3884711265563965e+00
    phi[4,3]  R2552     -9.5272518694400787e-02
    phi[4,3]  R2553     -3.4296461939811707e-01
    phi[4,3]  R2554     -6.0556423664093018e-01
    phi[4,3]  R2555     -1.6014730930328369e+00
    phi[4,3]  R2556     2.5656518340110779e-01
    phi[4,3]  R2557     -4.1291669011116028e-02
    phi[4,3]  R2558     -2.9346027374267578e+00
    phi[4,3]  R2559     1.9327629357576370e-02
    phi[4,3]  R2560     -1.6578621864318848e+00
    phi[4,3]  R2561     -6.2594634294509888e-01
    phi[4,3]  R2562     -1.3554449081420898e+00
    phi[4,3]  R2563     -1.1527673006057739e+00
    phi[4,3]  R2564     -2.4211235046386719e+00
    phi[4,3]  R2565     -6.8074566125869751e-01
    phi[4,3]  R2566     1.0860924720764160e+00
    phi[4,3]  R2567     0.00563911022618413
    phi[4,3]  R2568     7.8278881311416626e-01
    phi[4,3]  R2569     -1.0468118190765381e+00
    phi[4,3]  R2570     -2.9776937961578369e+00
    phi[4,3]  R2571     -1.0210758447647095e+00
    phi[4,3]  R2572     -2.3779196739196777e+00
    phi[4,3]  R2573     -1.4153889417648315e+00
    phi[4,3]  R2574     -9.5132905244827271e-01
    phi[4,3]  R2575     1.9264270365238190e-01
    phi[4,3]  R2576     1.0570249557495117e+00
    phi[4,3]  R2577     -7.4598133563995361e-01
    phi[4,3]  R2578     -2.8410035371780396e-01
    phi[4,3]  R2579     -1.5174251794815063e+00
    phi[4,3]  R2580     1.88840651512146
    phi[4,3]  R2581     1.1256448030471802e+00
    phi[4,3]  R2582     1.28672194480896
    phi[4,3]  R2583     1.1664819717407227e+00
    phi[6,3]  R27       -1
    phi[6,3]  R29       1.5411984777004251e+00
    phi[6,3]  R30       1.5937597124709546e-01
    phi[6,3]  R31       -2.6647210384887563e+00
    phi[6,3]  R32       -3.2643547112847582e-01
    phi[6,3]  R33       -3.0484873781582817e+00
    phi[6,3]  R34       -2.7189703437146306e-01
    phi[6,3]  R35       2.7239790076438788e+00
    phi[6,3]  R54       1
    phi[6,3]  R2584     -4.6411983823329930e+00
    phi[6,3]  R2585     -1.5588014269321433e+00
    phi[6,3]  R2586     -2.3993759807838386e+00
    phi[6,3]  R2587     -2.0806240382896477e+00
    phi[6,3]  R2588     -4.3527886614381206e-01
    phi[6,3]  R2589     -5.7647209431213247e+00
    phi[6,3]  R2590     -2.2435644621143220e+00
    phi[6,3]  R2591     -2.8964354043712737e+00
    phi[6,3]  R2592     -5.1512526474286613e-02
    phi[6,3]  R2593     -6.14848728279085
    phi[6,3]  R2594     -1.8181028797978485e+00
    phi[6,3]  R2595     -2.3618969485407746e+00
    phi[6,3]  R2596     -5.8239789122764467e+00
    phi[6,3]  R2597     -3.7602089698868957e-01
    phi[6,3]  R2598     -1.3275811447157970e+00
    phi[6,3]  R2599     -5.1749528018862123e-01
    phi[6,3]  R2600     -2.7005004576690450e-01
    phi[6,3]  R2601     -3.8855137166900344e-01
    phi[6,3]  R2602     -1.2058371596725546e+00
    phi[6,3]  R2603     -6.9389679214224143e-01
    phi[6,3]  R2604     -1.8677559274692839e+00
    phi[6,3]  R2605     -4.8456802167510249e-01
    phi[6,3]  R2606     -4.9138617340227447e-01
    phi[6,3]  R2607     -5.0025988294942847e-01
    phi[6,3]  R2608     -2.0462340678721262e+00
    phi[6,3]  R2609     -2.8693397945277077e-01
    phi[6,3]  R2610     -1.1161209283578970e+00
    phi[6,3]  R2611     -7.9507522969334843e-01
    phi[6,3]  R2612     -1.3080675124593686e+00
    phi[6,3]  R2613     -1.3878839824283578e+00
    phi[6,3]  R2614     -6.0462762970822026e-01
    phi[6,3]  R2615     -6.1950666792326237e-01
    phi[6,3]  R2616     -6.2662404884306344e-01
    phi[6,3]  R2617     -6.3243913652935468e-01
    phi[6,3]  R2618     -4.8299003572133931e-01
    phi[6,3]  R2619     -4.8824184980506513e-01
    phi[6,3]  R2620     -5.2455247401967475e-01
    phi[6,3]  R2621     -5.3136913474472713e-01
    phi[6,3]  R2622     -5.5108825682219176e-01
    phi[6,3]  R2623     -5.6707893607693771e-01
    phi[6,3]  R2624     -5.8570264109392634e-01
    phi[6,3]  R2625     -0.605616228142076
    phi[6,3]  R2626     -6.1528914302228943e-01
    phi[6,3]  R2627     -6.1942677088224474e-01
    phi[6,3]  R2628     -2.5424813709914873e-01
    phi[6,3]  R2629     -3.0865274994907521e-01
    phi[6,3]  R2630     -4.3757889578106046e-01
    phi[6,3]  R2631     -4.6543118359993013e-01
    phi[6,3]  R2632     -5.0003298054211154e-01
    phi[6,3]  R2633     -5.2274731805411667e-01
    phi[6,3]  R2634     -5.6533119624386186e-01
    phi[6,3]  R2635     -7.1267991945170328e-01
    phi[6,3]  R2636     -7.3154055042825217e-01
    phi[6,3]  R2637     -7.4038862628930890e-01
    phi[6,3]  R2638     -0.452346838651293
    phi[6,3]  R2639     -4.6175139053404735e-01
    phi[6,3]  R2640     -4.8591771228775404e-01
    phi[6,3]  R2641     -5.1339136760851678e-01
    phi[6,3]  R2642     -0.524573174077962
    phi[6,3]  R2643     -5.5772336771561593e-01
    phi[6,3]  R2644     -6.5573305530328341e-01
    phi[6,3]  R2645     -6.7309395410292194e-01
    phi[6,3]  R2646     -0.728314245954339
    phi[6,3]  R2647     -7.7786547221616020e-01
    phi[6,3]  R2648     -3.9868882875901823e-01
    phi[6,3]  R2649     -4.0807825286719479e-01
    phi[6,3]  R2650     -4.7163492912934069e-01
    phi[6,3]  R2651     -5.6775626257606615e-01
    phi[6,3]  R2652     -5.7238082416502156e-01
    phi[6,3]  R2653     -6.4044870616176031e-01
    phi[6,3]  R2654     -1.0398231508050584e+00
    phi[6,3]  R2655     -1.0483317600229212e+00
    phi[6,3]  R2656     -1.0577553977607184e+00
    phi[6,3]  R2657     -1.0693293608231023e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2658     -3.0999999046325684e+00
    phi[4,5]  R2659     -3.0999999046325684e+00
    phi[4,5]  R2660     -2.2400000095367432e+00
    phi[4,5]  R2661     -2.2400000095367432e+00
    phi[4,5]  R2662     -3.0999999046325684e+00
    phi[4,5]  R2663     -3.0999999046325684e+00
    phi[4,5]  R2664     -2.5699999332427979e+00
    phi[4,5]  R2665     -2.5699999332427979e+00
    phi[4,5]  R2666     -3.0999999046325684e+00
    phi[4,5]  R2667     -3.0999999046325684e+00
    phi[4,5]  R2668     -2.0899999141693115e+00
    phi[4,5]  R2669     -2.0899999141693115e+00
    phi[4,5]  R2670     -3.0999999046325684e+00
    phi[4,5]  R2671     -3.0999999046325684e+00
    phi[4,5]  R2672     1.0069933533668518e-01
    phi[4,5]  R2673     2.0685143470764160e+00
    phi[4,5]  R2674     5.1308560371398926e-01
    phi[4,5]  R2675     -7.2219479084014893e-01
    phi[4,5]  R2676     2.1128454208374023e+00
    phi[4,5]  R2677     1.6501094102859497e+00
    phi[4,5]  R2678     -6.7144048213958740e-01
    phi[4,5]  R2679     -3.6677727103233337e-01
    phi[4,5]  R2680     3.4622645378112793e-01
    phi[4,5]  R2681     1.3843475282192230e-01
    phi[4,5]  R2682     -2.6625173091888428e+00
    phi[4,5]  R2683     -3.0162916183471680e+00
    phi[4,5]  R2684     -2.6542499065399170e+00
    phi[4,5]  R2685     -2.5950672626495361e+00
    phi[4,5]  R2686     -2.3996124267578125e+00
    phi[4,5]  R2687     -1.5645024776458740e+00
    phi[4,5]  R2688     -2.0111243724823
    phi[4,5]  R2689     3.8759976625442505e-01
    phi[4,5]  R2690     -2.3692221641540527e+00
    phi[4,5]  R2691     -6.8068438768386841e-01
    phi[4,5]  R2692     7.5522202253341675e-01
    phi[4,5]  R2693     -1.9150774478912354e+00
    phi[4,5]  R2694     -3.5453069210052490e+00
    phi[4,5]  R2695     -2.3972954750061035e+00
    phi[4,5]  R2696     -2.0419905185699463e+00
    phi[4,5]  R2697     1.6159764528274536e+00
    phi[4,5]  R2698     7.3009330034255981e-01
    phi[4,5]  R2699     5.2580791711807251e-01
    phi[4,5]  R2700     8.1365460157394409e-01
    phi[4,5]  R2701     -7.8649681806564331e-01
    phi[4,5]  R2702     -1.0748572647571564e-01
    phi[4,5]  R2703     -2.2303009033203125e+00
    phi[4,5]  R2704     2.7489697933197021e+00
    phi[4,5]  R2705     2.1882367134094238e+00
    phi[4,5]  R2706     2.2065770626068115e+00
    phi[4,5]  R2707     -1.8265733718872070e+00
    phi[4,5]  R2708     -0.137929305434227
    phi[4,5]  R2709     -1.7446128129959106e+00
    phi[4,5]  R2710     -9.3039298057556152e-01
    phi[4,5]  R2711     -1.7700532674789429e+00
    phi[4,5]  R2712     -5.2321439981460571e-01
    phi[4,5]  R2713     -2.1908600330352783e+00
    phi[4,5]  R2714     -2.7775921821594238e+00
    phi[4,5]  R2715     -3.9528522491455078e+00
    phi[4,5]  R2716     -2.65352201461792
    phi[4,5]  R2717     -1.5018348395824432e-01
    phi[4,5]  R2718     -2.94931960105896
    phi[4,5]  R2719     -1.9365466833114624e+00
    phi[4,5]  R2720     -3.3338909149169922e+00
    phi[4,5]  R2721     -3.0957643985748291e+00
    phi[4,5]  R2722     -2.3715000152587891e+00
    phi[4,5]  R2723     -4.2080540657043457e+00
    phi[4,5]  R2724     -2.3986940383911133e+00
    phi[4,5]  R2725     -2.2275218963623047e+00
    phi[4,5]  R2726     -3.9052727222442627e+00
    phi[4,5]  R2727     -5.0226032733917236e-01
    phi[4,5]  R2728     -2.4277970790863037e+00
    phi[4,5]  R2729     -2.1121904850006104e+00
    phi[4,5]  R2730     -1.0808832645416260e+00
    phi[4,5]  R2731     -3.1597013473510742e+00
    phi[4,5]  R2732     -3.7193052768707275e+00
    phi[4,5]  R2733     -4.0714473724365234e+00
    phi[4,5]  R2734     -3.5343732833862305e+00
    phi[4,5]  R2735     -3.7382705211639404e+00
    phi[4,5]  R2736     -1.3741468191146851e+00
    phi[4,5]  R2737     -7.1413916349411011e-01
    phi[4,5]  R2738     -2.2223873138427734e+00
    phi[4,5]  R2739     -1.9274870157241821e+00
    phi[4,5]  R2740     -3.3390325307846069e-01
    phi[4,5]  R2741     -2.4610452651977539e+00
    phi[4,5]  R2742     -3.2039291858673096e+00
    phi[4,5]  R2743     -2.0271937847137451e+00
    phi[4,5]  R2744     -2.4007794857025146e+00
    phi[4,5]  R2745     -1.3676869869232178e+00
    phi[4,5]  R2746     -3.7167675495147705e+00
    phi[4,5]  R2747     -2.1951284408569336e+00
    phi[4,5]  R2748     -8.4660136699676514e-01
    phi[4,5]  R2749     -2.5907800197601318e+00
    phi[4,5]  R2750     -2.2088646888732910e+00
    phi[4,5]  R2751     -2.5556418895721436e+00
    phi[4,5]  R2752     -1.1774408817291260e+00
    phi[4,5]  R2753     -1.4089405536651611e+00
    phi[4,5]  R2754     -3.6982412338256836e+00
    phi[4,5]  R2755     -2.6501352787017822e+00
    phi[4,5]  R2756     4.7478699684143066e-01
    phi[4,5]  R2757     -2.4017119780182838e-02
    phi[4,5]  R2758     -1.7241708040237427e+00
    phi[4,5]  R2759     -1.1449874639511108e+00
    phi[4,5]  R2760     -9.5726456493139267e-03
    phi[4,5]  R2761     -3.5190050601959229e+00
    phi[4,5]  R2762     -3.7474122047424316e+00
    phi[4,5]  R2763     -3.7584192752838135e+00
    phi[4,5]  R2764     -2.6990950107574463e-01
    phi[4,5]  R2765     -2.6369037628173828e+00
    phi[4,5]  R2766     1.4033931493759155e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2767     -3.0999999046325684e+00
    phi[5,4]  R2768     -3.0999999046325684e+00
    phi[5,4]  R2769     -2.2400000095367432e+00
    phi[5,4]  R2770     -2.2400000095367432e+00
    phi[5,4]  R2771     -3.0999999046325684e+00
    phi[5,4]  R2772     -3.0999999046325684e+00
    phi[5,4]  R2773     -2.5699999332427979e+00
    phi[5,4]  R2774     -2.5699999332427979e+00
    phi[5,4]  R2775     -3.0999999046325684e+00
    phi[5,4]  R2776     -3.0999999046325684e+00
    phi[5,4]  R2777     -2.0899999141693115e+00
    phi[5,4]  R2778     -2.0899999141693115e+00
    phi[5,4]  R2779     -3.0999999046325684e+00
    phi[5,4]  R2780     -3.0999999046325684e+00
    phi[5,4]  R2781     1.6159764528274536e+00
    phi[5,4]  R2782     7.3009330034255981e-01
    phi[5,4]  R2783     5.2580791711807251e-01
    phi[5,4]  R2784     8.1365460157394409e-01
    phi[5,4]  R2785     -7.8649681806564331e-01
    phi[5,4]  R2786     -1.0748572647571564e-01
    phi[5,4]  R2787     -2.2303009033203125e+00
    phi[5,4]  R2788     2.7489697933197021e+00
    phi[5,4]  R2789     2.1882367134094238e+00
    phi[5,4]  R2790     2.2065770626068115e+00
    phi[5,4]  R2791     -1.8265733718872070e+00
    phi[5,4]  R2792     -0.137929305434227
    phi[5,4]  R2793     -1.7446128129959106e+00
    phi[5,4]  R2794     -9.3039298057556152e-01
    phi[5,4]  R2795     -1.7700532674789429e+00
    phi[5,4]  R2796     -5.2321439981460571e-01
    phi[5,4]  R2797     -2.1908600330352783e+00
    phi[5,4]  R2798     -2.7775921821594238e+00
    phi[5,4]  R2799     -3.9528522491455078e+00
    phi[5,4]  R2800     -2.65352201461792
    phi[5,4]  R2801     -1.5018348395824432e-01
    phi[5,4]  R2802     -2.94931960105896
    phi[5,4]  R2803     -1.9365466833114624e+00
    phi[5,4]  R2804     -3.3338909149169922e+00
    phi[5,4]  R2805     -3.0957643985748291e+00
    phi[5,4]  R2806     -2.3715000152587891e+00
    phi[5,4]  R2807     -4.2080540657043457e+00
    phi[5,4]  R2808     -2.3986940383911133e+00
    phi[5,4]  R2809     -2.2275218963623047e+00
    phi[5,4]  R2810     -3.9052727222442627e+00
    phi[5,4]  R2811     -5.0226032733917236e-01
    phi[5,4]  R2812     -2.4277970790863037e+00
    phi[5,4]  R2813     -2.1121904850006104e+00
    phi[5,4]  R2814     -1.0808832645416260e+00
    phi[5,4]  R2815     -3.1597013473510742e+00
    phi[5,4]  R2816     -3.7193052768707275e+00
    phi[5,4]  R2817     -4.0714473724365234e+00
    phi[5,4]  R2818     -3.5343732833862305e+00
    phi[5,4]  R2819     -3.7382705211639404e+00
    phi[5,4]  R2820     -1.3741468191146851e+00
    phi[5,4]  R2821     -7.1413916349411011e-01
    phi[5,4]  R2822     -2.2223873138427734e+00
    phi[5,4]  R2823     -1.9274870157241821e+00
    phi[5,4]  R2824     -3.3390325307846069e-01
    phi[5,4]  R2825     -2.4610452651977539e+00
    phi[5,4]  R2826     -3.2039291858673096e+00
    phi[5,4]  R2827     -2.0271937847137451e+00
    phi[5,4]  R2828     -2.4007794857025146e+00
    phi[5,4]  R2829     -1.3676869869232178e+00
    phi[5,4]  R2830     -3.7167675495147705e+00
    phi[5,4]  R2831     -2.1951284408569336e+00
    phi[5,4]  R2832     -8.4660136699676514e-01
    phi[5,4]  R2833     -2.5907800197601318e+00
    phi[5,4]  R2834     -2.2088646888732910e+00
    phi[5,4]  R2835     -2.5556418895721436e+00
    phi[5,4]  R2836     -1.1774408817291260e+00
    phi[5,4]  R2837     -1.4089405536651611e+00
    phi[5,4]  R2838     -3.6982412338256836e+00
    phi[5,4]  R2839     -2.6501352787017822e+00
    phi[5,4]  R2840     4.7478699684143066e-01
    phi[5,4]  R2841     -2.4017119780182838e-02
    phi[5,4]  R2842     -1.7241708040237427e+00
    phi[5,4]  R2843     -1.1449874639511108e+00
    phi[5,4]  R2844     -9.5726456493139267e-03
    phi[5,4]  R2845     -3.5190050601959229e+00
    phi[5,4]  R2846     -3.7474122047424316e+00
    phi[5,4]  R2847     -3.7584192752838135e+00
    phi[5,4]  R2848     -2.6990950107574463e-01
    phi[5,4]  R2849     -2.6369037628173828e+00
    phi[5,4]  R2850     1.4033931493759155e+00
    phi[5,4]  R2851     1.0069933533668518e-01
    phi[5,4]  R2852     2.0685143470764160e+00
    phi[5,4]  R2853     5.1308560371398926e-01
    phi[5,4]  R2854     -7.2219479084014893e-01
    phi[5,4]  R2855     2.1128454208374023e+00
    phi[5,4]  R2856     1.6501094102859497e+00
    phi[5,4]  R2857     -6.7144048213958740e-01
    phi[5,4]  R2858     -3.6677727103233337e-01
    phi[5,4]  R2859     3.4622645378112793e-01
    phi[5,4]  R2860     1.3843475282192230e-01
    phi[5,4]  R2861     -2.6625173091888428e+00
    phi[5,4]  R2862     -3.0162916183471680e+00
    phi[5,4]  R2863     -2.6542499065399170e+00
    phi[5,4]  R2864     -2.5950672626495361e+00
    phi[5,4]  R2865     -2.3996124267578125e+00
    phi[5,4]  R2866     -1.5645024776458740e+00
    phi[5,4]  R2867     -2.0111243724823
    phi[5,4]  R2868     3.8759976625442505e-01
    phi[5,4]  R2869     -2.3692221641540527e+00
    phi[5,4]  R2870     -6.8068438768386841e-01
    phi[5,4]  R2871     7.5522202253341675e-01
    phi[5,4]  R2872     -1.9150774478912354e+00
    phi[5,4]  R2873     -3.5453069210052490e+00
    phi[5,4]  R2874     -2.3972954750061035e+00
    phi[5,4]  R2875     -2.0419905185699463e+00
    phi[5,7]  R45       1
    phi[5,7]  R46       1
    phi[5,7]  R47       -1.6814449973130228e+00
    phi[5,7]  R48       -1.3680260411050198e+00
    phi[5,7]  R49       9.3401107175153664e-01
    phi[5,7]  R50       1.6819717399199228e+00
    phi[5,7]  R51       2.5841971855592067e+00
    phi[5,7]  R52       -9.8022122966922254e-01
    phi[5,7]  R53       -4.6925242773029652e-01
    phi[5,7]  R55       -1
    phi[5,7]  R2876     -4.7814449019455907e+00
    phi[5,7]  R2877     -1.4185549073195456e+00
    phi[5,7]  R2878     -3.6080260506417630e+00
    phi[5,7]  R2879     -8.7197396843172337e-01
    phi[5,7]  R2880     -2.1659888328810317e+00
    phi[5,7]  R2881     -4.0340109763841046e+00
    phi[5,7]  R2882     -8.8802819332287508e-01
    phi[5,7]  R2883     -4.25197167316272
    phi[5,7]  R2884     -5.1580271907336162e-01
    phi[5,7]  R2885     -5.6841970901917751e+00
    phi[5,7]  R2886     -3.0702211438385341e+00
    phi[5,7]  R2887     -1.1097786845000890e+00
    phi[5,7]  R2888     -3.5692523323628649e+00
    phi[5,7]  R2889     -2.6307474769022718e+00
    phi[5,7]  R2890     -1.0449302355865697e-01
    phi[5,7]  R2891     -1.0953680043552572e-01
    phi[5,7]  R2892     -1.2489916668331669e-01
    phi[5,7]  R2893     -1.3858727383797864e-01
    phi[5,7]  R2894     -1.5015554358072691e-01
    phi[5,7]  R2895     -1.5591154066246310e-01
    phi[5,7]  R2896     -1.5867581426703481e-01
    phi[5,7]  R2897     -1.7018561696915491e-01
    phi[5,7]  R2898     -3.6509712143844641e-01
    phi[5,7]  R2899     -3.6541582984815868e-01
    phi[5,7]  R2900     -9.6635977688040509e-01
    phi[5,7]  R2901     -1.2711907599573269e+00
    phi[5,7]  R2902     -1.0294891285828447e+00
    phi[5,7]  R2903     -1.7669406844808146e+00
    phi[5,7]  R2904     -7.2776155714839907e-01
    phi[5,7]  R2905     -7.3911498734174841e-01
    phi[5,7]  R2906     -1.1569488282820708e+00
    phi[5,7]  R2907     -1.03033226839174
    phi[5,7]  R2908     -0.754024561830215
    phi[5,7]  R2909     -1.5425463902908039e+00
    phi[5,7]  R2910     -5.0920887464997566e-01
    phi[5,7]  R2911     -0.535847093094151
    phi[5,7]  R2912     -0.587351190579531
    phi[5,7]  R2913     -0.592177129360612
    phi[5,7]  R2914     -1.1751720266043040e+00
    phi[5,7]  R2915     -6.5876175331795439e-01
    phi[5,7]  R2916     -1.3636016891974081e+00
    phi[5,7]  R2917     -6.6627006455241355e-01
    phi[5,7]  R2918     -6.6740580820284245e-01
    phi[5,7]  R2919     -7.0693296507426906e-01
    phi[5,7]  R2920     -4.2187121206685174e-01
    phi[5,7]  R2921     -4.7670573937224625e-01
    phi[5,7]  R2922     -4.9304083011880961e-01
    phi[5,7]  R2923     -1.0850483225884544e+00
    phi[5,7]  R2924     -2.0259012537292174e+00
    phi[5,7]  R2925     -8.2279199183234164e-01
    phi[5,7]  R2926     -8.4448754402515158e-01
    phi[5,7]  R2927     -0.847707202830629
    phi[5,7]  R2928     -8.5300585760804060e-01
    phi[5,7]  R2929     -1.5203668486834361e+00
    phi[5,7]  R2930     -1.2853442352888238e+00
    phi[5,7]  R2931     -1.2507440850177192e+00
    phi[5,7]  R2932     -7.7074485781855029e-01
    phi[5,7]  R2933     -1.2399037801965764e+00
    phi[5,7]  R2934     -1.6993057886771425e+00
    phi[5,7]  R2935     -7.9169480158950289e-01
    phi[5,7]  R2936     -1.5314217461469524e+00
    phi[5,7]  R2937     -1.7366276116797588e+00
    phi[5,7]  R2938     -9.5802200006640437e-01
    phi[5,7]  R2939     -8.1479913333119747e-01
    phi[5,7]  R2940     -3.9480323824511254e-01
    phi[5,7]  R2941     -4.6238237502136709e-01
    phi[5,7]  R2942     -0.612899140879483
    phi[5,7]  R2943     -1.6117142726502427e+00
    phi[5,7]  R2944     -1.2248869362385795e+00
    phi[5,7]  R2945     -2.1599229001918707e+00
    phi[5,7]  R2946     -1.1305656898695657e+00
    phi[5,7]  R2947     -0.834088767382243
    phi[5,7]  R2948     -8.7994539524894244e-01
    phi[5,7]  R2949     -8.8212211646905891e-01
    phi[5,7]  R2950     -6.4397598119463884e-01
    phi[5,7]  R2951     -1.4620312730121738e+00
    phi[5,7]  R2952     -1.5519945882918691e+00
    phi[5,7]  R2953     -1.0245972207652381e+00
    phi[5,7]  R2954     -7.8847912352201455e-01
    phi[5,7]  R2955     -8.1337066008425163e-01
    phi[5,7]  R2956     -8.2783259559071753e-01
    phi[5,7]  R2957     -8.7332839418345820e-01
    phi[5,7]  R2958     -8.7804124539011053e-01
    phi[5,7]  R2959     -8.8362582122522682e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R56       -1
    z[0,1,0]  R57       1
    z[0,1,0]  R70       -2.6278007775545120e-02
    z[0,1,0]  R71       -4.2707573622465134e-02
    z[0,1,0]  R72       -0.0056025180965662
    z[0,1,0]  R73       1.6768096014857292e-02
    z[0,1,0]  R74       5.5906623601913452e-03
    z[0,1,0]  R75       -9.9510475993156433e-02
    z[0,1,0]  R76       -6.3157521188259125e-02
    z[0,1,0]  R77       -6.6990047693252563e-02
    z[0,1,0]  R78       -7.5816698372364044e-02
    z[0,1,0]  R79       -4.7269638627767563e-02
    z[0,1,0]  R80       -0.555316150188446
    z[0,1,0]  R81       -7.0947378873825073e-01
    z[0,1,0]  R82       -6.7712688446044922e-01
    z[0,1,0]  R83       -0.62241530418396
    z[0,1,0]  R84       -0.710087239742279
    z[0,1,0]  R85       -6.6775500774383545e-01
    z[0,1,0]  R86       -6.1131346225738525e-01
    z[0,1,0]  R87       3.5818746685981750e-01
    z[0,1,0]  R88       7.2382472455501556e-02
    z[0,1,0]  R89       5.6864868849515915e-02
    z[0,1,0]  R90       6.4676970243453979e-02
    z[0,1,0]  R91       1.6652202606201172e-01
    z[0,1,0]  R92       1.4591804705560207e-02
    z[0,1,0]  R93       -9.5617817714810371e-03
    z[0,1,0]  R94       3.4006796777248383e-02
    z[0,1,0]  R95       6.6367626190185547e-02
    z[0,1,0]  R96       5.7422742247581482e-02
    z[0,1,0]  R97       8.6606591939926147e-02
    z[0,1,0]  R98       2.1507395803928375e-01
    z[0,1,0]  R99       9.0440668165683746e-02
    z[0,1,0]  R100      2.0449422299861908e-01
    z[0,1,0]  R101      2.0686280727386475e-01
    z[0,1,0]  R102      2.2820815443992615e-01
    z[0,1,0]  R103      -2.2142000496387482e-01
    z[0,1,0]  R104      1.7293131351470947e-01
    z[0,1,0]  R105      -1.1373347789049149e-01
    z[0,1,0]  R106      -2.9333535581827164e-02
    z[0,1,0]  R107      2.8769636154174805e-01
    z[0,1,0]  R108      3.0418558046221733e-02
    z[0,1,0]  R109      1.0800819098949432e-01
    z[0,1,0]  R110      2.5768694281578064e-01
    z[0,1,0]  R111      -2.1849863231182098e-01
    z[0,1,0]  R112      2.1326501667499542e-01
    z[0,1,0]  R113      2.0236921310424805e-01
    z[0,1,0]  R114      -2.6784273982048035e-01
    z[0,1,0]  R115      -3.9492547512054443e-01
    z[0,1,0]  R116      -0.580073893070221
    z[0,1,0]  R117      -6.3610792160034180e-01
    z[0,1,0]  R118      -6.5275895595550537e-01
    z[0,1,0]  R119      -5.3577989339828491e-01
    z[0,1,0]  R120      -4.5251451432704926e-02
    z[0,1,0]  R121      -3.5671177506446838e-01
    z[0,1,0]  R122      -4.2242676019668579e-02
    z[0,1,0]  R123      -5.9709161520004272e-01
    z[0,1,0]  R124      -7.8293181955814362e-02
    z[0,1,0]  R125      -1.2750937603414059e-02
    z[0,1,0]  R126      -6.8526011705398560e-01
    z[0,1,0]  R127      -5.3374101407825947e-03
    z[0,1,0]  R128      -7.7924764156341553e-01
    z[0,1,0]  R129      -1.6494253277778625e-01
    z[0,1,0]  R130      1.0237602144479752e-01
    z[0,1,0]  R131      -9.1826446354389191e-02
    z[0,1,0]  R132      -1.0050944983959198e-01
    z[0,1,0]  R133      -6.5777927637100220e-02
    z[0,1,0]  R134      -2.2169025242328644e-01
    z[0,1,0]  R135      2.1646836772561073e-02
    z[0,1,0]  R136      5.4830335080623627e-02
    z[0,1,0]  R137      6.3755147159099579e-02
    z[0,1,0]  R138      -3.9741796255111694e-01
    z[0,1,0]  R139      1.9783353805541992e-01
    z[0,1,0]  R140      9.0975388884544373e-02
    z[0,1,0]  R141      7.3167368769645691e-02
    z[0,1,0]  R142      2.3548530042171478e-01
    z[0,1,0]  R143      2.6657110452651978e-01
    z[0,1,0]  R144      1.6141006350517273e-01
    z[0,1,0]  R145      -5.9019678831100464e-01
    z[0,1,0]  R146      2.3474588990211487e-01
    z[0,1,0]  R147      3.3537900447845459e-01
    z[0,1,0]  R148      2.8809833526611328e-01
    z[0,1,0]  R149      2.9013855382800102e-02
    z[0,1,0]  R150      1.7178709805011749e-01
    z[0,1,0]  R151      0.073527030646801
    z[0,1,0]  R152      3.7063896656036377e-01
    z[0,1,0]  R153      3.3976495265960693e-01
    z[0,1,0]  R154      3.7903591990470886e-01
    z[0,1,0]  R155      4.6893391013145447e-01
    z[0,1,0]  R156      2.6620736718177795e-01
    z[0,1,0]  R157      5.3020846843719482e-01
    z[0,1,0]  R158      8.5024207830429077e-01
    z[0,1,0]  R159      7.7913725376129150e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R58       -1
    z[0,1,1]  R59       1
    z[0,1,1]  R70       -3.9014759659767151e-01
    z[0,1,1]  R71       -5.9952753782272339e-01
    z[0,1,1]  R72       -4.1370350122451782e-01
    z[0,1,1]  R73       -2.5708726048469543e-01
    z[0,1,1]  R74       -3.6687496304512024e-01
    z[0,1,1]  R75       -7.6284235715866089e-01
    z[0,1,1]  R76       -4.1863659024238586e-01
    z[0,1,1]  R77       -3.6757844686508179e-01
    z[0,1,1]  R78       -2.4931827187538147e-01
    z[0,1,1]  R79       -1.5829999744892120e-01
    z[0,1,1]  R80       7.9764628410339355e-01
    z[0,1,1]  R81       6.5807652473449707e-01
    z[0,1,1]  R82       6.1631280183792114e-01
    z[0,1,1]  R83       6.3527208566665649e-01
    z[0,1,1]  R84       5.2518397569656372e-01
    z[0,1,1]  R85       6.4900523424148560e-01
    z[0,1,1]  R86       6.0841131210327148e-01
    z[0,1,1]  R87       6.5025252103805542e-01
    z[0,1,1]  R88       6.4068323373794556e-01
    z[0,1,1]  R89       5.7729250192642212e-01
    z[0,1,1]  R90       -6.0613876581192017e-01
    z[0,1,1]  R91       -6.8577939271926880e-01
    z[0,1,1]  R92       -5.5342102050781250e-01
    z[0,1,1]  R93       -5.1002883911132812e-01
    z[0,1,1]  R94       -5.4270356893539429e-01
    z[0,1,1]  R95       -5.3589272499084473e-01
    z[0,1,1]  R96       -4.9461242556571960e-01
    z[0,1,1]  R97       -2.9641568660736084e-01
    z[0,1,1]  R98       6.2931948900222778e-01
    z[0,1,1]  R99       8.3574044704437256e-01
    z[0,1,1]  R100      8.9154487848281860e-01
    z[0,1,1]  R101      7.2135615348815918e-01
    z[0,1,1]  R102      6.6799086332321167e-01
    z[0,1,1]  R103      7.7263295650482178e-01
    z[0,1,1]  R104      7.4710875749588013e-01
    z[0,1,1]  R105      6.6347837448120117e-01
    z[0,1,1]  R106      8.7388777732849121e-01
    z[0,1,1]  R107      7.2716957330703735e-01
    z[0,1,1]  R108      0.818784773349762
    z[0,1,1]  R109      6.1233907938003540e-01
    z[0,1,1]  R110      8.4183776378631592e-01
    z[0,1,1]  R111      2.5647976994514465e-01
    z[0,1,1]  R112      3.4914711117744446e-01
    z[0,1,1]  R113      7.8099715709686279e-01
    z[0,1,1]  R114      2.5958302617073059e-01
    z[0,1,1]  R115      4.4278222322463989e-01
    z[0,1,1]  R116      -4.0670629590749741e-02
    z[0,1,1]  R117      -1.3200253248214722e-01
    z[0,1,1]  R118      6.7387841641902924e-02
    z[0,1,1]  R119      -2.2673592902719975e-03
    z[0,1,1]  R120      -4.1153582930564880e-01
    z[0,1,1]  R121      0.573833703994751
    z[0,1,1]  R122      -0.366733580827713
    z[0,1,1]  R123      2.7760806679725647e-01
    z[0,1,1]  R124      -4.9850201606750488e-01
    z[0,1,1]  R125      -0.262656033039093
    z[0,1,1]  R126      3.9246013760566711e-01
    z[0,1,1]  R127      -2.8604340553283691e-01
    z[0,1,1]  R128      1.2124329805374146e-01
    z[0,1,1]  R129      5.4653489589691162e-01
    z[0,1,1]  R130      -7.8913533687591553e-01
    z[0,1,1]  R131      -7.8548103570938110e-01
    z[0,1,1]  R132      -7.8021126985549927e-01
    z[0,1,1]  R133      -7.6294887065887451e-01
    z[0,1,1]  R134      -7.4078255891799927e-01
    z[0,1,1]  R135      -7.4767166376113892e-01
    z[0,1,1]  R136      -6.2841165065765381e-01
    z[0,1,1]  R137      -7.1363770961761475e-01
    z[0,1,1]  R138      -6.6738867759704590e-01
    z[0,1,1]  R139      -5.4265409708023071e-01
    z[0,1,1]  R140      -8.6383581161499023e-01
    z[0,1,1]  R141      -4.6129563450813293e-01
    z[0,1,1]  R142      -5.1387935876846313e-01
    z[0,1,1]  R143      -4.2744708061218262e-01
    z[0,1,1]  R144      -0.583754301071167
    z[0,1,1]  R145      1.9236426055431366e-01
    z[0,1,1]  R146      -3.0478119850158691e-01
    z[0,1,1]  R147      -4.9917593598365784e-01
    z[0,1,1]  R148      -5.3909343481063843e-01
    z[0,1,1]  R149      5.0474762916564941e-01
    z[0,1,1]  R150      -5.4632717370986938e-01
    z[0,1,1]  R151      -5.4762643575668335e-01
    z[0,1,1]  R152      -1.4396350085735321e-01
    z[0,1,1]  R153      -2.5115618109703064e-01
    z[0,1,1]  R154      -4.8610472679138184e-01
    z[0,1,1]  R155      4.6591964364051819e-01
    z[0,1,1]  R156      5.2314704656600952e-01
    z[0,1,1]  R157      4.5538052916526794e-01
    z[0,1,1]  R158      3.7054851651191711e-01
    z[0,1,1]  R159      3.2702940702438354e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R60       -1
    z[0,1,2]  R61       1
    z[0,1,2]  R70       4.9154743552207947e-01
    z[0,1,2]  R71       -1.9268995523452759e-01
    z[0,1,2]  R72       5.1938217878341675e-01
    z[0,1,2]  R73       0.336774617433548
    z[0,1,2]  R74       -5.0238844007253647e-02
    z[0,1,2]  R75       1.9185375422239304e-02
    z[0,1,2]  R76       3.4803774952888489e-01
    z[0,1,2]  R77       7.6155656576156616e-01
    z[0,1,2]  R78       8.2272779941558838e-01
    z[0,1,2]  R79       9.4390004873275757e-01
    z[0,1,2]  R80       -1.6586931049823761e-01
    z[0,1,2]  R81       -3.7797506898641586e-02
    z[0,1,2]  R82       -1.0418660193681717e-01
    z[0,1,2]  R83       -1.2782895565032959e-01
    z[0,1,2]  R84       -5.8416366577148438e-02
    z[0,1,2]  R85       1.8231441080570221e-01
    z[0,1,2]  R86       2.6854345202445984e-01
    z[0,1,2]  R87       -6.6050738096237183e-02
    z[0,1,2]  R88       0.0798223614692688
    z[0,1,2]  R89       7.6353847980499268e-03
    z[0,1,2]  R90       -4.0066473186016083e-02
    z[0,1,2]  R91       -3.2913509011268616e-01
    z[0,1,2]  R92       -2.6121556758880615e-01
    z[0,1,2]  R93       -6.1069771647453308e-02
    z[0,1,2]  R94       -5.6354599073529243e-03
    z[0,1,2]  R95       -4.9367120862007141e-01
    z[0,1,2]  R96       2.0203870534896851e-01
    z[0,1,2]  R97       1.9628894329071045e-01
    z[0,1,2]  R98       9.7759254276752472e-02
    z[0,1,2]  R99       3.3839073032140732e-02
    z[0,1,2]  R100      -0.0911693274974823
    z[0,1,2]  R101      -3.0325099825859070e-01
    z[0,1,2]  R102      0.475361168384552
    z[0,1,2]  R103      -2.6377236936241388e-03
    z[0,1,2]  R104      -6.8879820406436920e-02
    z[0,1,2]  R105      -2.9904362559318542e-01
    z[0,1,2]  R106      1.5658490359783173e-01
    z[0,1,2]  R107      -1.3942076265811920e-01
    z[0,1,2]  R108      3.6822181940078735e-01
    z[0,1,2]  R109      4.2282842099666595e-02
    z[0,1,2]  R110      2.1224968135356903e-01
    z[0,1,2]  R111      -6.1825770139694214e-01
    z[0,1,2]  R112      2.4210287258028984e-02
    z[0,1,2]  R113      3.3962861634790897e-03
    z[0,1,2]  R114      -3.5538685321807861e-01
    z[0,1,2]  R115      1.2202516198158264e-01
    z[0,1,2]  R116      1.8493738770484924e-01
    z[0,1,2]  R117      3.4204912185668945e-01
    z[0,1,2]  R118      1.4449992775917053e-01
    z[0,1,2]  R119      5.1398748159408569e-01
    z[0,1,2]  R120      5.0443840026855469e-01
    z[0,1,2]  R121      -4.9243211746215820e-01
    z[0,1,2]  R122      1.2689022719860077e-01
    z[0,1,2]  R123      -0.626781165599823
    z[0,1,2]  R124      7.9153716564178467e-01
    z[0,1,2]  R125      7.2913813591003418e-01
    z[0,1,2]  R126      -4.3528309464454651e-01
    z[0,1,2]  R127      3.0553472042083740e-01
    z[0,1,2]  R128      -5.4495644569396973e-01
    z[0,1,2]  R129      -7.0033740997314453e-01
    z[0,1,2]  R130      -3.6397790908813477e-01
    z[0,1,2]  R131      -2.8767114877700806e-01
    z[0,1,2]  R132      -3.3676931262016296e-01
    z[0,1,2]  R133      -3.1985855102539062e-01
    z[0,1,2]  R134      -2.3950286209583282e-01
    z[0,1,2]  R135      -1.2533517181873322e-01
    z[0,1,2]  R136      1.7164391279220581e-01
    z[0,1,2]  R137      -2.3216864466667175e-01
    z[0,1,2]  R138      1.0192343033850193e-03
    z[0,1,2]  R139      9.2219136655330658e-02
    z[0,1,2]  R140      1.1176556348800659e-01
    z[0,1,2]  R141      3.0754688382148743e-01
    z[0,1,2]  R142      0.3104248046875
    z[0,1,2]  R143      4.3009561300277710e-01
    z[0,1,2]  R144      -1.9003529846668243e-01
    z[0,1,2]  R145      -3.1999304890632629e-01
    z[0,1,2]  R146      5.9365980327129364e-02
    z[0,1,2]  R147      5.3292375802993774e-01
    z[0,1,2]  R148      1.1547703295946121e-01
    z[0,1,2]  R149      3.5850954055786133e-01
    z[0,1,2]  R150      1.8182796239852905e-01
    z[0,1,2]  R151      5.6437408924102783e-01
    z[0,1,2]  R152      7.5032621622085571e-01
    z[0,1,2]  R153      1.2528024613857269e-01
    z[0,1,2]  R154      2.2773987054824829e-01
    z[0,1,2]  R155      2.6856359094381332e-02
    z[0,1,2]  R156      1.8239600956439972e-01
    z[0,1,2]  R157      2.3532277345657349e-01
    z[0,1,2]  R158      1.6897714138031006e-01
    z[0,1,2]  R159      6.8543985486030579e-02
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R62       -1
    z[0,1,3]  R63       1
    z[0,1,3]  R70       7.2889661788940430e-01
    z[0,1,3]  R71       5.6939494609832764e-01
    z[0,1,3]  R72       1.9592465460300446e-01
    z[0,1,3]  R73       7.1536588668823242e-01
    z[0,1,3]  R74       6.6275650262832642e-01
    z[0,1,3]  R75       1.9517024978995323e-02
    z[0,1,3]  R76       3.0077275633811951e-01
    z[0,1,3]  R77       3.3261362463235855e-02
    z[0,1,3]  R78       1.0025146603584290e-01
    z[0,1,3]  R79       1.5744503587484360e-02
    z[0,1,3]  R80       -1.9945492967963219e-02
    z[0,1,3]  R81       -6.9894500076770782e-02
    z[0,1,3]  R82       -3.5856020450592041e-01
    z[0,1,3]  R83       1.2311906367540359e-01
    z[0,1,3]  R84       -1.0057487338781357e-01
    z[0,1,3]  R85       2.4476251006126404e-01
    z[0,1,3]  R86       -1.0958953201770782e-01
    z[0,1,3]  R87       -5.7549077272415161e-01
    z[0,1,3]  R88       -6.4081823825836182e-01
    z[0,1,3]  R89       -7.8058832883834839e-01
    z[0,1,3]  R90       -3.7057012319564819e-01
    z[0,1,3]  R91       -2.5731462240219116e-01
    z[0,1,3]  R92       -4.3485969305038452e-01
    z[0,1,3]  R93       -1.6012582182884216e-01
    z[0,1,3]  R94       -4.9854028224945068e-01
    z[0,1,3]  R95       -7.9492524266242981e-02
    z[0,1,3]  R96       -5.0890535116195679e-01
    z[0,1,3]  R97       -8.8081145286560059e-01
    z[0,1,3]  R98       -4.2453691363334656e-01
    z[0,1,3]  R99       -3.2612148206681013e-03
    z[0,1,3]  R100      -1.2856748700141907e-01
    z[0,1,3]  R101      -2.2663326561450958e-01
    z[0,1,3]  R102      -3.1684669852256775e-01
    z[0,1,3]  R103      -2.4551613628864288e-01
    z[0,1,3]  R104      -4.2878651618957520e-01
    z[0,1,3]  R105      -3.5192716121673584e-01
    z[0,1,3]  R106      -1.5286463499069214e-01
    z[0,1,3]  R107      -2.3285862803459167e-01
    z[0,1,3]  R108      -2.9592958092689514e-01
    z[0,1,3]  R109      -5.1247978210449219e-01
    z[0,1,3]  R110      -2.8405699133872986e-01
    z[0,1,3]  R111      -6.4373493194580078e-01
    z[0,1,3]  R112      -5.1336103677749634e-01
    z[0,1,3]  R113      4.4087516143918037e-03
    z[0,1,3]  R114      -2.9839882254600525e-01
    z[0,1,3]  R115      -3.8450336456298828e-01
    z[0,1,3]  R116      -7.4159407615661621e-01
    z[0,1,3]  R117      -5.9216845035552979e-01
    z[0,1,3]  R118      -5.4077637195587158e-01
    z[0,1,3]  R119      -5.8719825744628906e-01
    z[0,1,3]  R120      5.3050768375396729e-01
    z[0,1,3]  R121      2.4304993450641632e-01
    z[0,1,3]  R122      0.799430251121521
    z[0,1,3]  R123      1.0718559473752975e-01
    z[0,1,3]  R124      1.0570231825113297e-01
    z[0,1,3]  R125      5.6906795501708984e-01
    z[0,1,3]  R126      1.5660229325294495e-01
    z[0,1,3]  R127      6.4447224140167236e-01
    z[0,1,3]  R128      2.4263779819011688e-01
    z[0,1,3]  R129      1.3728702068328857e-01
    z[0,1,3]  R130      0.174093097448349
    z[0,1,3]  R131      -2.9917600750923157e-01
    z[0,1,3]  R132      -3.9608660340309143e-01
    z[0,1,3]  R133      -4.9124431610107422e-01
    z[0,1,3]  R134      -4.4795447587966919e-01
    z[0,1,3]  R135      -4.1094160079956055e-01
    z[0,1,3]  R136      -4.0366217494010925e-01
    z[0,1,3]  R137      -4.2908832430839539e-01
    z[0,1,3]  R138      -1.9940476119518280e-01
    z[0,1,3]  R139      -5.6705063581466675e-01
    z[0,1,3]  R140      1.2812471017241478e-02
    z[0,1,3]  R141      3.9192914962768555e-01
    z[0,1,3]  R142      -1.0241139680147171e-01
    z[0,1,3]  R143      -2.2310981154441833e-01
    z[0,1,3]  R144      -5.0097241997718811e-02
    z[0,1,3]  R145      5.2560776472091675e-02
    z[0,1,3]  R146      2.0923748612403870e-01
    z[0,1,3]  R147      1.9200769066810608e-01
    z[0,1,3]  R148      8.4713473916053772e-02
    z[0,1,3]  R149      6.5258580446243286e-01
    z[0,1,3]  R150      7.9723989963531494e-01
    z[0,1,3]  R151      5.0779759883880615e-01
    z[0,1,3]  R152      1.6282172501087189e-01
    z[0,1,3]  R153      4.7349786758422852e-01
    z[0,1,3]  R154      8.6323969066143036e-02
    z[0,1,3]  R155      3.1835392117500305e-01
    z[0,1,3]  R156      -2.1111611276865005e-02
    z[0,1,3]  R157      6.1433070898056030e-01
    z[0,1,3]  R158      -1.2037465721368790e-01
    z[0,1,3]  R159      -4.6486461162567139e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R64       -1
    z[0,1,4]  R65       1
    z[0,1,4]  R70       2.0803251862525940e-01
    z[0,1,4]  R71       3.9895308017730713e-01
    z[0,1,4]  R72       6.8639880418777466e-01
    z[0,1,4]  R73       -1.8633824586868286e-01
    z[0,1,4]  R74       2.7008423209190369e-01
    z[0,1,4]  R75       5.9325951337814331e-01
    z[0,1,4]  R76       4.7902908921241760e-01
    z[0,1,4]  R77       -6.6358581185340881e-02
    z[0,1,4]  R78       -2.0199451595544815e-02
    z[0,1,4]  R79       -1.2824955582618713e-01
    z[0,1,4]  R80       1.6085259616374969e-01
    z[0,1,4]  R81       9.6290744841098785e-02
    z[0,1,4]  R82       8.1927612423896790e-02
    z[0,1,4]  R83       2.7232760563492775e-02
    z[0,1,4]  R84       0.0659303069114685
    z[0,1,4]  R85       8.7063927203416824e-03
    z[0,1,4]  R86       0.0533875934779644
    z[0,1,4]  R87       1.6697880346328020e-03
    z[0,1,4]  R88       1.6146497428417206e-01
    z[0,1,4]  R89       1.2368368357419968e-01
    z[0,1,4]  R90       -5.3862744569778442e-01
    z[0,1,4]  R91       -5.4176563024520874e-01
    z[0,1,4]  R92       -5.0976920127868652e-01
    z[0,1,4]  R93       -2.5783795118331909e-01
    z[0,1,4]  R94       -1.1714033037424088e-01
    z[0,1,4]  R95       -3.1877914071083069e-01
    z[0,1,4]  R96       -1.6955876350402832e-01
    z[0,1,4]  R97       1.3076600432395935e-01
    z[0,1,4]  R98       1.2937222421169281e-01
    z[0,1,4]  R99       4.5857262611389160e-01
    z[0,1,4]  R100      3.4120818972587585e-01
    z[0,1,4]  R101      0.211094930768013
    z[0,1,4]  R102      -4.1046679019927979e-01
    z[0,1,4]  R103      4.4615232944488525e-01
    z[0,1,4]  R104      -0.0840950757265091
    z[0,1,4]  R105      3.4334605932235718e-01
    z[0,1,4]  R106      3.3535476773977280e-02
    z[0,1,4]  R107      -3.0437481403350830e-01
    z[0,1,4]  R108      -1.1535321176052094e-01
    z[0,1,4]  R109      -3.9086338877677917e-01
    z[0,1,4]  R110      1.0599235445261002e-01
    z[0,1,4]  R111      2.1184180676937103e-01
    z[0,1,4]  R112      -5.6517404317855835e-01
    z[0,1,4]  R113      -2.3261284828186035e-01
    z[0,1,4]  R114      1.9529154896736145e-01
    z[0,1,4]  R115      5.4291152954101562e-01
    z[0,1,4]  R116      0.24967060983181
    z[0,1,4]  R117      2.8349167108535767e-01
    z[0,1,4]  R118      0.337802529335022
    z[0,1,4]  R119      -2.0766319334506989e-01
    z[0,1,4]  R120      2.6285862922668457e-01
    z[0,1,4]  R121      2.0473259687423706e-01
    z[0,1,4]  R122      2.8543433547019958e-01
    z[0,1,4]  R123      1.7861008644104004e-01
    z[0,1,4]  R124      3.9897285401821136e-02
    z[0,1,4]  R125      -1.0376599431037903e-01
    z[0,1,4]  R126      2.9115831851959229e-01
    z[0,1,4]  R127      5.5429106950759888e-01
    z[0,1,4]  R128      -1.4271882176399231e-01
    z[0,1,4]  R129      -1.6991877555847168e-01
    z[0,1,4]  R130      -3.5168644785881042e-01
    z[0,1,4]  R131      -2.1051105856895447e-01
    z[0,1,4]  R132      1.6175056993961334e-01
    z[0,1,4]  R133      1.5208730101585388e-01
    z[0,1,4]  R134      -1.2244738638401031e-01
    z[0,1,4]  R135      2.9136139154434204e-01
    z[0,1,4]  R136      8.3066321909427643e-02
    z[0,1,4]  R137      2.1944449841976166e-01
    z[0,1,4]  R138      2.4374271929264069e-01
    z[0,1,4]  R139      2.9229193925857544e-01
    z[0,1,4]  R140      3.7499007582664490e-01
    z[0,1,4]  R141      -5.2446460723876953e-01
    z[0,1,4]  R142      1.5510775148868561e-01
    z[0,1,4]  R143      -3.1334522366523743e-01
    z[0,1,4]  R144      0.34656822681427
    z[0,1,4]  R145      -2.3756182193756104e-01
    z[0,1,4]  R146      3.7706881761550903e-01
    z[0,1,4]  R147      -5.1656424999237061e-01
    z[0,1,4]  R148      -3.3346924185752869e-01
    z[0,1,4]  R149      2.6950253173708916e-02
    z[0,1,4]  R150      0.00511670857667923
    z[0,1,4]  R151      1.8650548160076141e-01
    z[0,1,4]  R152      4.6590843796730042e-01
    z[0,1,4]  R153      1.1250261217355728e-01
    z[0,1,4]  R154      -5.7950061559677124e-01
    z[0,1,4]  R155      -5.7460999488830566e-01
    z[0,1,4]  R156      -3.1709730625152588e-01
    z[0,1,4]  R157      -1.8819181621074677e-01
    z[0,1,4]  R158      2.0447519421577454e-01
    z[0,1,4]  R159      1.5613253414630890e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R66       -1
    z[0,1,5]  R67       1
    z[0,1,5]  R70       -1.7219580709934235e-01
    z[0,1,5]  R71       2.3822224140167236e-01
    z[0,1,5]  R72       1.9614651799201965e-02
    z[0,1,5]  R73       0.0641963854432106
    z[0,1,5]  R74       4.8918804526329041e-01
    z[0,1,5]  R75       2.0010976493358612e-01
    z[0,1,5]  R76       -1.1677581816911697e-01
    z[0,1,5]  R77       -3.5132844001054764e-02
    z[0,1,5]  R78       4.7865319252014160e-01
    z[0,1,5]  R79       5.9817917644977570e-02
    z[0,1,5]  R80       1.4256587252020836e-02
    z[0,1,5]  R81       1.6425536572933197e-01
    z[0,1,5]  R82       4.2075820267200470e-02
    z[0,1,5]  R83       -2.7283641695976257e-01
    z[0,1,5]  R84       -2.0761951804161072e-01
    z[0,1,5]  R85       -1.8142138421535492e-01
    z[0,1,5]  R86       -3.7135985493659973e-01
    z[0,1,5]  R87       3.3311226963996887e-01
    z[0,1,5]  R88       3.7047511339187622e-01
    z[0,1,5]  R89       1.9655074179172516e-01
    z[0,1,5]  R90       -3.2391062378883362e-01
    z[0,1,5]  R91       5.6745093315839767e-02
    z[0,1,5]  R92       -3.7993314862251282e-01
    z[0,1,5]  R93       -0.797989010810852
    z[0,1,5]  R94       -4.8231646418571472e-02
    z[0,1,5]  R95       -5.9691596031188965e-01
    z[0,1,5]  R96       6.5028136968612671e-01
    z[0,1,5]  R97       -1.1769316345453262e-01
    z[0,1,5]  R98       -2.3316852748394012e-01
    z[0,1,5]  R99       -1.7426036298274994e-01
    z[0,1,5]  R100      -1.2134513258934021e-01
    z[0,1,5]  R101      2.3063777387142181e-01
    z[0,1,5]  R102      5.9574604034423828e-02
    z[0,1,5]  R103      -1.6570739448070526e-01
    z[0,1,5]  R104      -4.6456447243690491e-01
    z[0,1,5]  R105      -3.1672635674476624e-01
    z[0,1,5]  R106      -3.7973642349243164e-01
    z[0,1,5]  R107      -3.3005043864250183e-01
    z[0,1,5]  R108      -2.9810637235641479e-01
    z[0,1,5]  R109      -3.1139656901359558e-01
    z[0,1,5]  R110      3.1805828213691711e-02
    z[0,1,5]  R111      -1.6592605412006378e-01
    z[0,1,5]  R112      1.3772073388099670e-01
    z[0,1,5]  R113      -1.1653266102075577e-01
    z[0,1,5]  R114      6.6004401445388794e-01
    z[0,1,5]  R115      -3.7099716067314148e-01
    z[0,1,5]  R116      -1.2369011342525482e-01
    z[0,1,5]  R117      1.6217152774333954e-01
    z[0,1,5]  R118      7.5873308815062046e-03
    z[0,1,5]  R119      -6.8098619580268860e-02
    z[0,1,5]  R120      -6.3787393271923065e-02
    z[0,1,5]  R121      -4.0692013502120972e-01
    z[0,1,5]  R122      1.3815888762474060e-01
    z[0,1,5]  R123      -2.3018175363540649e-01
    z[0,1,5]  R124      -3.1856033205986023e-01
    z[0,1,5]  R125      -1.9800245761871338e-01
    z[0,1,5]  R126      -1.3131687045097351e-01
    z[0,1,5]  R127      2.0805935561656952e-01
    z[0,1,5]  R128      -2.8782995417714119e-02
    z[0,1,5]  R129      1.7422935366630554e-01
    z[0,1,5]  R130      -1.3307310640811920e-01
    z[0,1,5]  R131      3.2203185558319092e-01
    z[0,1,5]  R132      6.9552063941955566e-02
    z[0,1,5]  R133      1.4325352013111115e-01
    z[0,1,5]  R134      2.9530632495880127e-01
    z[0,1,5]  R135      4.1212841868400574e-01
    z[0,1,5]  R136      5.8570575714111328e-01
    z[0,1,5]  R137      -4.3115538358688354e-01
    z[0,1,5]  R138      4.2247429490089417e-01
    z[0,1,5]  R139      -1.7058970034122467e-01
    z[0,1,5]  R140      -1.5608721971511841e-01
    z[0,1,5]  R141      -5.0835871696472168e-01
    z[0,1,5]  R142      6.9800531864166260e-01
    z[0,1,5]  R143      2.4462699890136719e-01
    z[0,1,5]  R144      4.6346226334571838e-01
    z[0,1,5]  R145      -6.4760148525238037e-01
    z[0,1,5]  R146      -8.1387633085250854e-01
    z[0,1,5]  R147      1.3412535190582275e-01
    z[0,1,5]  R148      2.1217954158782959e-01
    z[0,1,5]  R149      -1.9284363090991974e-01
    z[0,1,5]  R150      -5.1182083785533905e-02
    z[0,1,5]  R151      2.1714878082275391e-01
    z[0,1,5]  R152      -1.0764618217945099e-01
    z[0,1,5]  R153      6.0474467277526855e-01
    z[0,1,5]  R154      0.469120055437088
    z[0,1,5]  R155      -0.361625075340271
    z[0,1,5]  R156      -5.3766030073165894e-01
    z[0,1,5]  R157      -1.6545116901397705e-01
    z[0,1,5]  R158      1.3289323449134827e-01
    z[0,1,5]  R159      -9.6647344529628754e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R68       -1
    z[0,1,6]  R69       1
    z[0,1,6]  R70       -3.5443242639303207e-02
    z[0,1,6]  R71       2.4797075986862183e-01
    z[0,1,6]  R72       -2.2168788313865662e-01
    z[0,1,6]  R73       -5.1924586296081543e-01
    z[0,1,6]  R74       -3.3369296789169312e-01
    z[0,1,6]  R75       -1.2417459487915039e-01
    z[0,1,6]  R76       -6.0502439737319946e-01
    z[0,1,6]  R77       -5.2315002679824829e-01
    z[0,1,6]  R78       -1.2507562339305878e-01
    z[0,1,6]  R79       2.4796277284622192e-01
    z[0,1,6]  R80       3.7377856671810150e-02
    z[0,1,6]  R81       -1.4497044682502747e-01
    z[0,1,6]  R82       -1.1728186905384064e-01
    z[0,1,6]  R83       -3.1991973519325256e-01
    z[0,1,6]  R84       -3.9871972799301147e-01
    z[0,1,6]  R85       -8.2211859524250031e-02
    z[0,1,6]  R86       -1.7676997184753418e-01
    z[0,1,6]  R87       4.8522818833589554e-02
    z[0,1,6]  R88       -6.2796503305435181e-02
    z[0,1,6]  R89       1.3915172778069973e-02
    z[0,1,6]  R90       3.0732309818267822e-01
    z[0,1,6]  R91       -1.7523214221000671e-01
    z[0,1,6]  R92       -1.7877882719039917e-01
    z[0,1,6]  R93       8.4513023495674133e-02
    z[0,1,6]  R94       6.6309428215026855e-01
    z[0,1,6]  R95       -2.1336279809474945e-02
    z[0,1,6]  R96       -2.5314772501587868e-02
    z[0,1,6]  R97       -2.4357235431671143e-01
    z[0,1,6]  R98       5.4480004310607910e-01
    z[0,1,6]  R99       2.2703976929187775e-01
    z[0,1,6]  R100      8.5677430033683777e-02
    z[0,1,6]  R101      -4.4246405363082886e-01
    z[0,1,6]  R102      5.7593584060668945e-02
    z[0,1,6]  R103      -2.5925964117050171e-01
    z[0,1,6]  R104      2.0709633827209473e-02
    z[0,1,6]  R105      -3.3967521786689758e-01
    z[0,1,6]  R106      -2.0554545521736145e-01
    z[0,1,6]  R107      -3.3647686243057251e-01
    z[0,1,6]  R108      5.7713504880666733e-02
    z[0,1,6]  R109      -3.1497564911842346e-01
    z[0,1,6]  R110      0.294825941324234
    z[0,1,6]  R111      1.3202600181102753e-01
    z[0,1,6]  R112      -0.479687362909317
    z[0,1,6]  R113      -5.3044372797012329e-01
    z[0,1,6]  R114      0.414413183927536
    z[0,1,6]  R115      2.2989781200885773e-01
    z[0,1,6]  R116      -7.8625408932566643e-03
    z[0,1,6]  R117      -6.0115452855825424e-02
    z[0,1,6]  R118      -3.7666597962379456e-01
    z[0,1,6]  R119      -2.3704078793525696e-01
    z[0,1,6]  R120      -4.6854072809219360e-01
    z[0,1,6]  R121      -1.8549780547618866e-01
    z[0,1,6]  R122      -3.2859003543853760e-01
    z[0,1,6]  R123      -2.7782490849494934e-01
    z[0,1,6]  R124      -0.0677451640367508
    z[0,1,6]  R125      1.5936177968978882e-01
    z[0,1,6]  R126      2.4572479724884033e-01
    z[0,1,6]  R127      2.4274982511997223e-01
    z[0,1,6]  R128      3.2023850828409195e-02
    z[0,1,6]  R129      3.2487708330154419e-01
    z[0,1,6]  R130      2.5020885467529297e-01
    z[0,1,6]  R131      -2.3303854465484619e-01
    z[0,1,6]  R132      2.8261154890060425e-01
    z[0,1,6]  R133      -1.6217219829559326e-01
    z[0,1,6]  R134      2.0462350547313690e-01
    z[0,1,6]  R135      -3.4572128206491470e-02
    z[0,1,6]  R136      2.4441033601760864e-01
    z[0,1,6]  R137      1.2077458202838898e-01
    z[0,1,6]  R138      3.4495350718498230e-01
    z[0,1,6]  R139      0.470958948135376
    z[0,1,6]  R140      2.6052755117416382e-01
    z[0,1,6]  R141      -1.2949370779097080e-02
    z[0,1,6]  R142      2.4970626831054688e-01
    z[0,1,6]  R143      5.9450912475585938e-01
    z[0,1,6]  R144      -5.0955647230148315e-01
    z[0,1,6]  R145      -1.8352743983268738e-01
    z[0,1,6]  R146      -1.1067216284573078e-02
    z[0,1,6]  R147      -1.8066921830177307e-01
    z[0,1,6]  R148      -6.7055529356002808e-01
    z[0,1,6]  R149      3.8996872305870056e-01
    z[0,1,6]  R150      2.6779506355524063e-02
    z[0,1,6]  R151      1.9074784219264984e-01
    z[0,1,6]  R152      1.5408596396446228e-01
    z[0,1,6]  R153      -4.5079058408737183e-01
    z[0,1,6]  R154      -6.9441363215446472e-02
    z[0,1,6]  R155      -4.3850109796039760e-04
    z[0,1,6]  R156      4.8177537322044373e-01
    z[0,1,6]  R157      -0.126246377825737
    z[0,1,6]  R158      1.9304960966110229e-01
    z[0,1,6]  R159      1.7743013799190521e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R160      -1
    z[1,0,0]  R161      1
    z[1,0,0]  R174      -4.5251451432704926e-02
    z[1,0,0]  R175      -3.5671177506446838e-01
    z[1,0,0]  R176      -4.2242676019668579e-02
    z[1,0,0]  R177      -5.9709161520004272e-01
    z[1,0,0]  R178      -7.8293181955814362e-02
    z[1,0,0]  R179      -1.2750937603414059e-02
    z[1,0,0]  R180      -6.8526011705398560e-01
    z[1,0,0]  R181      -5.3374101407825947e-03
    z[1,0,0]  R182      -7.7924764156341553e-01
    z[1,0,0]  R183      -1.6494253277778625e-01
    z[1,0,0]  R184      1.0237602144479752e-01
    z[1,0,0]  R185      -9.1826446354389191e-02
    z[1,0,0]  R186      -1.0050944983959198e-01
    z[1,0,0]  R187      -6.5777927637100220e-02
    z[1,0,0]  R188      -2.2169025242328644e-01
    z[1,0,0]  R189      2.1646836772561073e-02
    z[1,0,0]  R190      5.4830335080623627e-02
    z[1,0,0]  R191      6.3755147159099579e-02
    z[1,0,0]  R192      -3.9741796255111694e-01
    z[1,0,0]  R193      1.9783353805541992e-01
    z[1,0,0]  R194      9.0975388884544373e-02
    z[1,0,0]  R195      7.3167368769645691e-02
    z[1,0,0]  R196      2.3548530042171478e-01
    z[1,0,0]  R197      2.6657110452651978e-01
    z[1,0,0]  R198      1.6141006350517273e-01
    z[1,0,0]  R199      -5.9019678831100464e-01
    z[1,0,0]  R200      2.3474588990211487e-01
    z[1,0,0]  R201      3.3537900447845459e-01
    z[1,0,0]  R202      2.8809833526611328e-01
    z[1,0,0]  R203      2.9013855382800102e-02
    z[1,0,0]  R204      1.7178709805011749e-01
    z[1,0,0]  R205      0.073527030646801
    z[1,0,0]  R206      3.7063896656036377e-01
    z[1,0,0]  R207      3.3976495265960693e-01
    z[1,0,0]  R208      3.7903591990470886e-01
    z[1,0,0]  R209      4.6893391013145447e-01
    z[1,0,0]  R210      2.6620736718177795e-01
    z[1,0,0]  R211      5.3020846843719482e-01
    z[1,0,0]  R212      8.5024207830429077e-01
    z[1,0,0]  R213      7.7913725376129150e-01
    z[1,0,0]  R214      -2.6278007775545120e-02
    z[1,0,0]  R215      -4.2707573622465134e-02
    z[1,0,0]  R216      -0.0056025180965662
    z[1,0,0]  R217      1.6768096014857292e-02
    z[1,0,0]  R218      5.5906623601913452e-03
    z[1,0,0]  R219      -9.9510475993156433e-02
    z[1,0,0]  R220      -6.3157521188259125e-02
    z[1,0,0]  R221      -6.6990047693252563e-02
    z[1,0,0]  R222      -7.5816698372364044e-02
    z[1,0,0]  R223      -4.7269638627767563e-02
    z[1,0,0]  R224      -0.555316150188446
    z[1,0,0]  R225      -7.0947378873825073e-01
    z[1,0,0]  R226      -6.7712688446044922e-01
    z[1,0,0]  R227      -0.62241530418396
    z[1,0,0]  R228      -0.710087239742279
    z[1,0,0]  R229      -6.6775500774383545e-01
    z[1,0,0]  R230      -6.1131346225738525e-01
    z[1,0,0]  R231      3.5818746685981750e-01
    z[1,0,0]  R232      7.2382472455501556e-02
    z[1,0,0]  R233      5.6864868849515915e-02
    z[1,0,0]  R234      6.4676970243453979e-02
    z[1,0,0]  R235      1.6652202606201172e-01
    z[1,0,0]  R236      1.4591804705560207e-02
    z[1,0,0]  R237      -9.5617817714810371e-03
    z[1,0,0]  R238      3.4006796777248383e-02
    z[1,0,0]  R239      6.6367626190185547e-02
    z[1,0,0]  R240      5.7422742247581482e-02
    z[1,0,0]  R241      8.6606591939926147e-02
    z[1,0,0]  R242      2.1507395803928375e-01
    z[1,0,0]  R243      9.0440668165683746e-02
    z[1,0,0]  R244      2.0449422299861908e-01
    z[1,0,0]  R245      2.0686280727386475e-01
    z[1,0,0]  R246      2.2820815443992615e-01
    z[1,0,0]  R247      -2.2142000496387482e-01
    z[1,0,0]  R248      1.7293131351470947e-01
    z[1,0,0]  R249      -1.1373347789049149e-01
    z[1,0,0]  R250      -2.9333535581827164e-02
    z[1,0,0]  R251      2.8769636154174805e-01
    z[1,0,0]  R252      3.0418558046221733e-02
    z[1,0,0]  R253      1.0800819098949432e-01
    z[1,0,0]  R254      2.5768694281578064e-01
    z[1,0,0]  R255      -2.1849863231182098e-01
    z[1,0,0]  R256      2.1326501667499542e-01
    z[1,0,0]  R257      2.0236921310424805e-01
    z[1,0,0]  R258      -2.6784273982048035e-01
    z[1,0,0]  R259      -3.9492547512054443e-01
    z[1,0,0]  R260      -0.580073893070221
    z[1,0,0]  R261      -6.3610792160034180e-01
    z[1,0,0]  R262      -6.5275895595550537e-01
    z[1,0,0]  R263      -5.3577989339828491e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R162      -1
    z[1,0,1]  R163      1
    z[1,0,1]  R174      -4.1153582930564880e-01
    z[1,0,1]  R175      0.573833703994751
    z[1,0,1]  R176      -0.366733580827713
    z[1,0,1]  R177      2.7760806679725647e-01
    z[1,0,1]  R178      -4.9850201606750488e-01
    z[1,0,1]  R179      -0.262656033039093
    z[1,0,1]  R180      3.9246013760566711e-01
    z[1,0,1]  R181      -2.8604340553283691e-01
    z[1,0,1]  R182      1.2124329805374146e-01
    z[1,0,1]  R183      5.4653489589691162e-01
    z[1,0,1]  R184      -7.8913533687591553e-01
    z[1,0,1]  R185      -7.8548103570938110e-01
    z[1,0,1]  R186      -7.8021126985549927e-01
    z[1,0,1]  R187      -7.6294887065887451e-01
    z[1,0,1]  R188      -7.4078255891799927e-01
    z[1,0,1]  R189      -7.4767166376113892e-01
    z[1,0,1]  R190      -6.2841165065765381e-01
    z[1,0,1]  R191      -7.1363770961761475e-01
    z[1,0,1]  R192      -6.6738867759704590e-01
    z[1,0,1]  R193      -5.4265409708023071e-01
    z[1,0,1]  R194      -8.6383581161499023e-01
    z[1,0,1]  R195      -4.6129563450813293e-01
    z[1,0,1]  R196      -5.1387935876846313e-01
    z[1,0,1]  R197      -4.2744708061218262e-01
    z[1,0,1]  R198      -0.583754301071167
    z[1,0,1]  R199      1.9236426055431366e-01
    z[1,0,1]  R200      -3.0478119850158691e-01
    z[1,0,1]  R201      -4.9917593598365784e-01
    z[1,0,1]  R202      -5.3909343481063843e-01
    z[1,0,1]  R203      5.0474762916564941e-01
    z[1,0,1]  R204      -5.4632717370986938e-01
    z[1,0,1]  R205      -5.4762643575668335e-01
    z[1,0,1]  R206      -1.4396350085735321e-01
    z[1,0,1]  R207      -2.5115618109703064e-01
    z[1,0,1]  R208      -4.8610472679138184e-01
    z[1,0,1]  R209      4.6591964364051819e-01
    z[1,0,1]  R210      5.2314704656600952e-01
    z[1,0,1]  R211      4.5538052916526794e-01
    z[1,0,1]  R212      3.7054851651191711e-01
    z[1,0,1]  R213      3.2702940702438354e-01
    z[1,0,1]  R214      -3.9014759659767151e-01
    z[1,0,1]  R215      -5.9952753782272339e-01
    z[1,0,1]  R216      -4.1370350122451782e-01
    z[1,0,1]  R217      -2.5708726048469543e-01
    z[1,0,1]  R218      -3.6687496304512024e-01
    z[1,0,1]  R219      -7.6284235715866089e-01
    z[1,0,1]  R220      -4.1863659024238586e-01
    z[1,0,1]  R221      -3.6757844686508179e-01
    z[1,0,1]  R222      -2.4931827187538147e-01
    z[1,0,1]  R223      -1.5829999744892120e-01
    z[1,0,1]  R224      7.9764628410339355e-01
    z[1,0,1]  R225      6.5807652473449707e-01
    z[1,0,1]  R226      6.1631280183792114e-01
    z[1,0,1]  R227      6.3527208566665649e-01
    z[1,0,1]  R228      5.2518397569656372e-01
    z[1,0,1]  R229      6.4900523424148560e-01
    z[1,0,1]  R230      6.0841131210327148e-01
    z[1,0,1]  R231      6.5025252103805542e-01
    z[1,0,1]  R232      6.4068323373794556e-01
    z[1,0,1]  R233      5.7729250192642212e-01
    z[1,0,1]  R234      -6.0613876581192017e-01
    z[1,0,1]  R235      -6.8577939271926880e-01
    z[1,0,1]  R236      -5.5342102050781250e-01
    z[1,0,1]  R237      -5.1002883911132812e-01
    z[1,0,1]  R238      -5.4270356893539429e-01
    z[1,0,1]  R239      -5.3589272499084473e-01
    z[1,0,1]  R240      -4.9461242556571960e-01
    z[1,0,1]  R241      -2.9641568660736084e-01
    z[1,0,1]  R242      6.2931948900222778e-01
    z[1,0,1]  R243      8.3574044704437256e-01
    z[1,0,1]  R244      8.9154487848281860e-01
    z[1,0,1]  R245      7.2135615348815918e-01
    z[1,0,1]  R246      6.6799086332321167e-01
    z[1,0,1]  R247      7.7263295650482178e-01
    z[1,0,1]  R248      7.4710875749588013e-01
    z[1,0,1]  R249      6.6347837448120117e-01
    z[1,0,1]  R250      8.7388777732849121e-01
    z[1,0,1]  R251      7.2716957330703735e-01
    z[1,0,1]  R252      0.818784773349762
    z[1,0,1]  R253      6.1233907938003540e-01
    z[1,0,1]  R254      8.4183776378631592e-01
    z[1,0,1]  R255      2.5647976994514465e-01
    z[1,0,1]  R256      3.4914711117744446e-01
    z[1,0,1]  R257      7.8099715709686279e-01
    z[1,0,1]  R258      2.5958302617073059e-01
    z[1,0,1]  R259      4.4278222322463989e-01
    z[1,0,1]  R260      -4.0670629590749741e-02
    z[1,0,1]  R261      -1.3200253248214722e-01
    z[1,0,1]  R262      6.7387841641902924e-02
    z[1,0,1]  R263      -2.2673592902719975e-03
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R164      -1
    z[1,0,2]  R165      1
    z[1,0,2]  R174      5.0443840026855469e-01
    z[1,0,2]  R175      -4.9243211746215820e-01
    z[1,0,2]  R176      1.2689022719860077e-01
    z[1,0,2]  R177      -0.626781165599823
    z[1,0,2]  R178      7.9153716564178467e-01
    z[1,0,2]  R179      7.2913813591003418e-01
    z[1,0,2]  R180      -4.3528309464454651e-01
    z[1,0,2]  R181      3.0553472042083740e-01
    z[1,0,2]  R182      -5.4495644569396973e-01
    z[1,0,2]  R183      -7.0033740997314453e-01
    z[1,0,2]  R184      -3.6397790908813477e-01
    z[1,0,2]  R185      -2.8767114877700806e-01
    z[1,0,2]  R186      -3.3676931262016296e-01
    z[1,0,2]  R187      -3.1985855102539062e-01
    z[1,0,2]  R188      -2.3950286209583282e-01
    z[1,0,2]  R189      -1.2533517181873322e-01
    z[1,0,2]  R190      1.7164391279220581e-01
    z[1,0,2]  R191      -2.3216864466667175e-01
    z[1,0,2]  R192      1.0192343033850193e-03
    z[1,0,2]  R193      9.2219136655330658e-02
    z[1,0,2]  R194      1.1176556348800659e-01
    z[1,0,2]  R195      3.0754688382148743e-01
    z[1,0,2]  R196      0.3104248046875
    z[1,0,2]  R197      4.3009561300277710e-01
    z[1,0,2]  R198      -1.9003529846668243e-01
    z[1,0,2]  R199      -3.1999304890632629e-01
    z[1,0,2]  R200      5.9365980327129364e-02
    z[1,0,2]  R201      5.3292375802993774e-01
    z[1,0,2]  R202      1.1547703295946121e-01
    z[1,0,2]  R203      3.5850954055786133e-01
    z[1,0,2]  R204      1.8182796239852905e-01
    z[1,0,2]  R205      5.6437408924102783e-01
    z[1,0,2]  R206      7.5032621622085571e-01
    z[1,0,2]  R207      1.2528024613857269e-01
    z[1,0,2]  R208      2.2773987054824829e-01
    z[1,0,2]  R209      2.6856359094381332e-02
    z[1,0,2]  R210      1.8239600956439972e-01
    z[1,0,2]  R211      2.3532277345657349e-01
    z[1,0,2]  R212      1.6897714138031006e-01
    z[1,0,2]  R213      6.8543985486030579e-02
    z[1,0,2]  R214      4.9154743552207947e-01
    z[1,0,2]  R215      -1.9268995523452759e-01
    z[1,0,2]  R216      5.1938217878341675e-01
    z[1,0,2]  R217      0.336774617433548
    z[1,0,2]  R218      -5.0238844007253647e-02
    z[1,0,2]  R219      1.9185375422239304e-02
    z[1,0,2]  R220      3.4803774952888489e-01
    z[1,0,2]  R221      7.6155656576156616e-01
    z[1,0,2]  R222      8.2272779941558838e-01
    z[1,0,2]  R223      9.4390004873275757e-01
    z[1,0,2]  R224      -1.6586931049823761e-01
    z[1,0,2]  R225      -3.7797506898641586e-02
    z[1,0,2]  R226      -1.0418660193681717e-01
    z[1,0,2]  R227      -1.2782895565032959e-01
    z[1,0,2]  R228      -5.8416366577148438e-02
    z[1,0,2]  R229      1.8231441080570221e-01
    z[1,0,2]  R230      2.6854345202445984e-01
    z[1,0,2]  R231      -6.6050738096237183e-02
    z[1,0,2]  R232      0.0798223614692688
    z[1,0,2]  R233      7.6353847980499268e-03
    z[1,0,2]  R234      -4.0066473186016083e-02
    z[1,0,2]  R235      -3.2913509011268616e-01
    z[1,0,2]  R236      -2.6121556758880615e-01
    z[1,0,2]  R237      -6.1069771647453308e-02
    z[1,0,2]  R238      -5.6354599073529243e-03
    z[1,0,2]  R239      -4.9367120862007141e-01
    z[1,0,2]  R240      2.0203870534896851e-01
    z[1,0,2]  R241      1.9628894329071045e-01
    z[1,0,2]  R242      9.7759254276752472e-02
    z[1,0,2]  R243      3.3839073032140732e-02
    z[1,0,2]  R244      -0.0911693274974823
    z[1,0,2]  R245      -3.0325099825859070e-01
    z[1,0,2]  R246      0.475361168384552
    z[1,0,2]  R247      -2.6377236936241388e-03
    z[1,0,2]  R248      -6.8879820406436920e-02
    z[1,0,2]  R249      -2.9904362559318542e-01
    z[1,0,2]  R250      1.5658490359783173e-01
    z[1,0,2]  R251      -1.3942076265811920e-01
    z[1,0,2]  R252      3.6822181940078735e-01
    z[1,0,2]  R253      4.2282842099666595e-02
    z[1,0,2]  R254      2.1224968135356903e-01
    z[1,0,2]  R255      -6.1825770139694214e-01
    z[1,0,2]  R256      2.4210287258028984e-02
    z[1,0,2]  R257      3.3962861634790897e-03
    z[1,0,2]  R258      -3.5538685321807861e-01
    z[1,0,2]  R259      1.2202516198158264e-01
    z[1,0,2]  R260      1.8493738770484924e-01
    z[1,0,2]  R261      3.4204912185668945e-01
    z[1,0,2]  R262      1.4449992775917053e-01
    z[1,0,2]  R263      5.1398748159408569e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R166      -1
    z[1,0,3]  R167      1
    z[1,0,3]  R174      5.3050768375396729e-01
    z[1,0,3]  R175      2.4304993450641632e-01
    z[1,0,3]  R176      0.799430251121521
    z[1,0,3]  R177      1.0718559473752975e-01
    z[1,0,3]  R178      1.0570231825113297e-01
    z[1,0,3]  R179      5.6906795501708984e-01
    z[1,0,3]  R180      1.5660229325294495e-01
    z[1,0,3]  R181      6.4447224140167236e-01
    z[1,0,3]  R182      2.4263779819011688e-01
    z[1,0,3]  R183      1.3728702068328857e-01
    z[1,0,3]  R184      0.174093097448349
    z[1,0,3]  R185      -2.9917600750923157e-01
    z[1,0,3]  R186      -3.9608660340309143e-01
    z[1,0,3]  R187      -4.9124431610107422e-01
    z[1,0,3]  R188      -4.4795447587966919e-01
    z[1,0,3]  R189      -4.1094160079956055e-01
    z[1,0,3]  R190      -4.0366217494010925e-01
    z[1,0,3]  R191      -4.2908832430839539e-01
    z[1,0,3]  R192      -1.9940476119518280e-01
    z[1,0,3]  R193      -5.6705063581466675e-01
    z[1,0,3]  R194      1.2812471017241478e-02
    z[1,0,3]  R195      3.9192914962768555e-01
    z[1,0,3]  R196      -1.0241139680147171e-01
    z[1,0,3]  R197      -2.2310981154441833e-01
    z[1,0,3]  R198      -5.0097241997718811e-02
    z[1,0,3]  R199      5.2560776472091675e-02
    z[1,0,3]  R200      2.0923748612403870e-01
    z[1,0,3]  R201      1.9200769066810608e-01
    z[1,0,3]  R202      8.4713473916053772e-02
    z[1,0,3]  R203      6.5258580446243286e-01
    z[1,0,3]  R204      7.9723989963531494e-01
    z[1,0,3]  R205      5.0779759883880615e-01
    z[1,0,3]  R206      1.6282172501087189e-01
    z[1,0,3]  R207      4.7349786758422852e-01
    z[1,0,3]  R208      8.6323969066143036e-02
    z[1,0,3]  R209      3.1835392117500305e-01
    z[1,0,3]  R210      -2.1111611276865005e-02
    z[1,0,3]  R211      6.1433070898056030e-01
    z[1,0,3]  R212      -1.2037465721368790e-01
    z[1,0,3]  R213      -4.6486461162567139e-01
    z[1,0,3]  R214      7.2889661788940430e-01
    z[1,0,3]  R215      5.6939494609832764e-01
    z[1,0,3]  R216      1.9592465460300446e-01
    z[1,0,3]  R217      7.1536588668823242e-01
    z[1,0,3]  R218      6.6275650262832642e-01
    z[1,0,3]  R219      1.9517024978995323e-02
    z[1,0,3]  R220      3.0077275633811951e-01
    z[1,0,3]  R221      3.3261362463235855e-02
    z[1,0,3]  R222      1.0025146603584290e-01
    z[1,0,3]  R223      1.5744503587484360e-02
    z[1,0,3]  R224      -1.9945492967963219e-02
    z[1,0,3]  R225      -6.9894500076770782e-02
    z[1,0,3]  R226      -3.5856020450592041e-01
    z[1,0,3]  R227      1.2311906367540359e-01
    z[1,0,3]  R228      -1.0057487338781357e-01
    z[1,0,3]  R229      2.4476251006126404e-01
    z[1,0,3]  R230      -1.0958953201770782e-01
    z[1,0,3]  R231      -5.7549077272415161e-01
    z[1,0,3]  R232      -6.4081823825836182e-01
    z[1,0,3]  R233      -7.8058832883834839e-01
    z[1,0,3]  R234      -3.7057012319564819e-01
    z[1,0,3]  R235      -2.5731462240219116e-01
    z[1,0,3]  R236      -4.3485969305038452e-01
    z[1,0,3]  R237      -1.6012582182884216e-01
    z[1,0,3]  R238      -4.9854028224945068e-01
    z[1,0,3]  R239      -7.9492524266242981e-02
    z[1,0,3]  R240      -5.0890535116195679e-01
    z[1,0,3]  R241      -8.8081145286560059e-01
    z[1,0,3]  R242      -4.2453691363334656e-01
    z[1,0,3]  R243      -3.2612148206681013e-03
    z[1,0,3]  R244      -1.2856748700141907e-01
    z[1,0,3]  R245      -2.2663326561450958e-01
    z[1,0,3]  R246      -3.1684669852256775e-01
    z[1,0,3]  R247      -2.4551613628864288e-01
    z[1,0,3]  R248      -4.2878651618957520e-01
    z[1,0,3]  R249      -3.5192716121673584e-01
    z[1,0,3]  R250      -1.5286463499069214e-01
    z[1,0,3]  R251      -2.3285862803459167e-01
    z[1,0,3]  R252      -2.9592958092689514e-01
    z[1,0,3]  R253      -5.1247978210449219e-01
    z[1,0,3]  R254      -2.8405699133872986e-01
    z[1,0,3]  R255      -6.4373493194580078e-01
    z[1,0,3]  R256      -5.1336103677749634e-01
    z[1,0,3]  R257      4.4087516143918037e-03
    z[1,0,3]  R258      -2.9839882254600525e-01
    z[1,0,3]  R259      -3.8450336456298828e-01
    z[1,0,3]  R260      -7.4159407615661621e-01
    z[1,0,3]  R261      -5.9216845035552979e-01
    z[1,0,3]  R262      -5.4077637195587158e-01
    z[1,0,3]  R263      -5.8719825744628906e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R168      -1
    z[1,0,4]  R169      1
    z[1,0,4]  R174      2.6285862922668457e-01
    z[1,0,4]  R175      2.0473259687423706e-01
    z[1,0,4]  R176      2.8543433547019958e-01
    z[1,0,4]  R177      1.7861008644104004e-01
    z[1,0,4]  R178      3.9897285401821136e-02
    z[1,0,4]  R179      -1.0376599431037903e-01
    z[1,0,4]  R180      2.9115831851959229e-01
    z[1,0,4]  R181      5.5429106950759888e-01
    z[1,0,4]  R182      -1.4271882176399231e-01
    z[1,0,4]  R183      -1.6991877555847168e-01
    z[1,0,4]  R184      -3.5168644785881042e-01
    z[1,0,4]  R185      -2.1051105856895447e-01
    z[1,0,4]  R186      1.6175056993961334e-01
    z[1,0,4]  R187      1.5208730101585388e-01
    z[1,0,4]  R188      -1.2244738638401031e-01
    z[1,0,4]  R189      2.9136139154434204e-01
    z[1,0,4]  R190      8.3066321909427643e-02
    z[1,0,4]  R191      2.1944449841976166e-01
    z[1,0,4]  R192      2.4374271929264069e-01
    z[1,0,4]  R193      2.9229193925857544e-01
    z[1,0,4]  R194      3.7499007582664490e-01
    z[1,0,4]  R195      -5.2446460723876953e-01
    z[1,0,4]  R196      1.5510775148868561e-01
    z[1,0,4]  R197      -3.1334522366523743e-01
    z[1,0,4]  R198      0.34656822681427
    z[1,0,4]  R199      -2.3756182193756104e-01
    z[1,0,4]  R200      3.7706881761550903e-01
    z[1,0,4]  R201      -5.1656424999237061e-01
    z[1,0,4]  R202      -3.3346924185752869e-01
    z[1,0,4]  R203      2.6950253173708916e-02
    z[1,0,4]  R204      0.00511670857667923
    z[1,0,4]  R205      1.8650548160076141e-01
    z[1,0,4]  R206      4.6590843796730042e-01
    z[1,0,4]  R207      1.1250261217355728e-01
    z[1,0,4]  R208      -5.7950061559677124e-01
    z[1,0,4]  R209      -5.7460999488830566e-01
    z[1,0,4]  R210      -3.1709730625152588e-01
    z[1,0,4]  R211      -1.8819181621074677e-01
    z[1,0,4]  R212      2.0447519421577454e-01
    z[1,0,4]  R213      1.5613253414630890e-01
    z[1,0,4]  R214      2.0803251862525940e-01
    z[1,0,4]  R215      3.9895308017730713e-01
    z[1,0,4]  R216      6.8639880418777466e-01
    z[1,0,4]  R217      -1.8633824586868286e-01
    z[1,0,4]  R218      2.7008423209190369e-01
    z[1,0,4]  R219      5.9325951337814331e-01
    z[1,0,4]  R220      4.7902908921241760e-01
    z[1,0,4]  R221      -6.6358581185340881e-02
    z[1,0,4]  R222      -2.0199451595544815e-02
    z[1,0,4]  R223      -1.2824955582618713e-01
    z[1,0,4]  R224      1.6085259616374969e-01
    z[1,0,4]  R225      9.6290744841098785e-02
    z[1,0,4]  R226      8.1927612423896790e-02
    z[1,0,4]  R227      2.7232760563492775e-02
    z[1,0,4]  R228      0.0659303069114685
    z[1,0,4]  R229      8.7063927203416824e-03
    z[1,0,4]  R230      0.0533875934779644
    z[1,0,4]  R231      1.6697880346328020e-03
    z[1,0,4]  R232      1.6146497428417206e-01
    z[1,0,4]  R233      1.2368368357419968e-01
    z[1,0,4]  R234      -5.3862744569778442e-01
    z[1,0,4]  R235      -5.4176563024520874e-01
    z[1,0,4]  R236      -5.0976920127868652e-01
    z[1,0,4]  R237      -2.5783795118331909e-01
    z[1,0,4]  R238      -1.1714033037424088e-01
    z[1,0,4]  R239      -3.1877914071083069e-01
    z[1,0,4]  R240      -1.6955876350402832e-01
    z[1,0,4]  R241      1.3076600432395935e-01
    z[1,0,4]  R242      1.2937222421169281e-01
    z[1,0,4]  R243      4.5857262611389160e-01
    z[1,0,4]  R244      3.4120818972587585e-01
    z[1,0,4]  R245      0.211094930768013
    z[1,0,4]  R246      -4.1046679019927979e-01
    z[1,0,4]  R247      4.4615232944488525e-01
    z[1,0,4]  R248      -0.0840950757265091
    z[1,0,4]  R249      3.4334605932235718e-01
    z[1,0,4]  R250      3.3535476773977280e-02
    z[1,0,4]  R251      -3.0437481403350830e-01
    z[1,0,4]  R252      -1.1535321176052094e-01
    z[1,0,4]  R253      -3.9086338877677917e-01
    z[1,0,4]  R254      1.0599235445261002e-01
    z[1,0,4]  R255      2.1184180676937103e-01
    z[1,0,4]  R256      -5.6517404317855835e-01
    z[1,0,4]  R257      -2.3261284828186035e-01
    z[1,0,4]  R258      1.9529154896736145e-01
    z[1,0,4]  R259      5.4291152954101562e-01
    z[1,0,4]  R260      0.24967060983181
    z[1,0,4]  R261      2.8349167108535767e-01
    z[1,0,4]  R262      0.337802529335022
    z[1,0,4]  R263      -2.0766319334506989e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R170      -1
    z[1,0,5]  R171      1
    z[1,0,5]  R174      -6.3787393271923065e-02
    z[1,0,5]  R175      -4.0692013502120972e-01
    z[1,0,5]  R176      1.3815888762474060e-01
    z[1,0,5]  R177      -2.3018175363540649e-01
    z[1,0,5]  R178      -3.1856033205986023e-01
    z[1,0,5]  R179      -1.9800245761871338e-01
    z[1,0,5]  R180      -1.3131687045097351e-01
    z[1,0,5]  R181      2.0805935561656952e-01
    z[1,0,5]  R182      -2.8782995417714119e-02
    z[1,0,5]  R183      1.7422935366630554e-01
    z[1,0,5]  R184      -1.3307310640811920e-01
    z[1,0,5]  R185      3.2203185558319092e-01
    z[1,0,5]  R186      6.9552063941955566e-02
    z[1,0,5]  R187      1.4325352013111115e-01
    z[1,0,5]  R188      2.9530632495880127e-01
    z[1,0,5]  R189      4.1212841868400574e-01
    z[1,0,5]  R190      5.8570575714111328e-01
    z[1,0,5]  R191      -4.3115538358688354e-01
    z[1,0,5]  R192      4.2247429490089417e-01
    z[1,0,5]  R193      -1.7058970034122467e-01
    z[1,0,5]  R194      -1.5608721971511841e-01
    z[1,0,5]  R195      -5.0835871696472168e-01
    z[1,0,5]  R196      6.9800531864166260e-01
    z[1,0,5]  R197      2.4462699890136719e-01
    z[1,0,5]  R198      4.6346226334571838e-01
    z[1,0,5]  R199      -6.4760148525238037e-01
    z[1,0,5]  R200      -8.1387633085250854e-01
    z[1,0,5]  R201      1.3412535190582275e-01
    z[1,0,5]  R202      2.1217954158782959e-01
    z[1,0,5]  R203      -1.9284363090991974e-01
    z[1,0,5]  R204      -5.1182083785533905e-02
    z[1,0,5]  R205      2.1714878082275391e-01
    z[1,0,5]  R206      -1.0764618217945099e-01
    z[1,0,5]  R207      6.0474467277526855e-01
    z[1,0,5]  R208      0.469120055437088
    z[1,0,5]  R209      -0.361625075340271
    z[1,0,5]  R210      -5.3766030073165894e-01
    z[1,0,5]  R211      -1.6545116901397705e-01
    z[1,0,5]  R212      1.3289323449134827e-01
    z[1,0,5]  R213      -9.6647344529628754e-02
    z[1,0,5]  R214      -1.7219580709934235e-01
    z[1,0,5]  R215      2.3822224140167236e-01
    z[1,0,5]  R216      1.9614651799201965e-02
    z[1,0,5]  R217      0.0641963854432106
    z[1,0,5]  R218      4.8918804526329041e-01
    z[1,0,5]  R219      2.0010976493358612e-01
    z[1,0,5]  R220      -1.1677581816911697e-01
    z[1,0,5]  R221      -3.5132844001054764e-02
    z[1,0,5]  R222      4.7865319252014160e-01
    z[1,0,5]  R223      5.9817917644977570e-02
    z[1,0,5]  R224      1.4256587252020836e-02
    z[1,0,5]  R225      1.6425536572933197e-01
    z[1,0,5]  R226      4.2075820267200470e-02
    z[1,0,5]  R227      -2.7283641695976257e-01
    z[1,0,5]  R228      -2.0761951804161072e-01
    z[1,0,5]  R229      -1.8142138421535492e-01
    z[1,0,5]  R230      -3.7135985493659973e-01
    z[1,0,5]  R231      3.3311226963996887e-01
    z[1,0,5]  R232      3.7047511339187622e-01
    z[1,0,5]  R233      1.9655074179172516e-01
    z[1,0,5]  R234      -3.2391062378883362e-01
    z[1,0,5]  R235      5.6745093315839767e-02
    z[1,0,5]  R236      -3.7993314862251282e-01
    z[1,0,5]  R237      -0.797989010810852
    z[1,0,5]  R238      -4.8231646418571472e-02
    z[1,0,5]  R239      -5.9691596031188965e-01
    z[1,0,5]  R240      6.5028136968612671e-01
    z[1,0,5]  R241      -1.1769316345453262e-01
    z[1,0,5]  R242      -2.3316852748394012e-01
    z[1,0,5]  R243      -1.7426036298274994e-01
    z[1,0,5]  R244      -1.2134513258934021e-01
    z[1,0,5]  R245      2.3063777387142181e-01
    z[1,0,5]  R246      5.9574604034423828e-02
    z[1,0,5]  R247      -1.6570739448070526e-01
    z[1,0,5]  R248      -4.6456447243690491e-01
    z[1,0,5]  R249      -3.1672635674476624e-01
    z[1,0,5]  R250      -3.7973642349243164e-01
    z[1,0,5]  R251      -3.3005043864250183e-01
    z[1,0,5]  R252      -2.9810637235641479e-01
    z[1,0,5]  R253      -3.1139656901359558e-01
    z[1,0,5]  R254      3.1805828213691711e-02
    z[1,0,5]  R255      -1.6592605412006378e-01
    z[1,0,5]  R256      1.3772073388099670e-01
    z[1,0,5]  R257      -1.1653266102075577e-01
    z[1,0,5]  R258      6.6004401445388794e-01
    z[1,0,5]  R259      -3.7099716067314148e-01
    z[1,0,5]  R260      -1.2369011342525482e-01
    z[1,0,5]  R261      1.6217152774333954e-01
    z[1,0,5]  R262      7.5873308815062046e-03
    z[1,0,5]  R263      -6.8098619580268860e-02
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R172      -1
    z[1,0,6]  R173      1
    z[1,0,6]  R174      -4.6854072809219360e-01
    z[1,0,6]  R175      -1.8549780547618866e-01
    z[1,0,6]  R176      -3.2859003543853760e-01
    z[1,0,6]  R177      -2.7782490849494934e-01
    z[1,0,6]  R178      -0.0677451640367508
    z[1,0,6]  R179      1.5936177968978882e-01
    z[1,0,6]  R180      2.4572479724884033e-01
    z[1,0,6]  R181      2.4274982511997223e-01
    z[1,0,6]  R182      3.2023850828409195e-02
    z[1,0,6]  R183      3.2487708330154419e-01
    z[1,0,6]  R184      2.5020885467529297e-01
    z[1,0,6]  R185      -2.3303854465484619e-01
    z[1,0,6]  R186      2.8261154890060425e-01
    z[1,0,6]  R187      -1.6217219829559326e-01
    z[1,0,6]  R188      2.0462350547313690e-01
    z[1,0,6]  R189      -3.4572128206491470e-02
    z[1,0,6]  R190      2.4441033601760864e-01
    z[1,0,6]  R191      1.2077458202838898e-01
    z[1,0,6]  R192      3.4495350718498230e-01
    z[1,0,6]  R193      0.470958948135376
    z[1,0,6]  R194      2.6052755117416382e-01
    z[1,0,6]  R195      -1.2949370779097080e-02
    z[1,0,6]  R196      2.4970626831054688e-01
    z[1,0,6]  R197      5.9450912475585938e-01
    z[1,0,6]  R198      -5.0955647230148315e-01
    z[1,0,6]  R199      -1.8352743983268738e-01
    z[1,0,6]  R200      -1.1067216284573078e-02
    z[1,0,6]  R201      -1.8066921830177307e-01
    z[1,0,6]  R202      -6.7055529356002808e-01
    z[1,0,6]  R203      3.8996872305870056e-01
    z[1,0,6]  R204      2.6779506355524063e-02
    z[1,0,6]  R205      1.9074784219264984e-01
    z[1,0,6]  R206      1.5408596396446228e-01
    z[1,0,6]  R207      -4.5079058408737183e-01
    z[1,0,6]  R208      -6.9441363215446472e-02
    z[1,0,6]  R209      -4.3850109796039760e-04
    z[1,0,6]  R210      4.8177537322044373e-01
    z[1,0,6]  R211      -0.126246377825737
    z[1,0,6]  R212      1.9304960966110229e-01
    z[1,0,6]  R213      1.7743013799190521e-01
    z[1,0,6]  R214      -3.5443242639303207e-02
    z[1,0,6]  R215      2.4797075986862183e-01
    z[1,0,6]  R216      -2.2168788313865662e-01
    z[1,0,6]  R217      -5.1924586296081543e-01
    z[1,0,6]  R218      -3.3369296789169312e-01
    z[1,0,6]  R219      -1.2417459487915039e-01
    z[1,0,6]  R220      -6.0502439737319946e-01
    z[1,0,6]  R221      -5.2315002679824829e-01
    z[1,0,6]  R222      -1.2507562339305878e-01
    z[1,0,6]  R223      2.4796277284622192e-01
    z[1,0,6]  R224      3.7377856671810150e-02
    z[1,0,6]  R225      -1.4497044682502747e-01
    z[1,0,6]  R226      -1.1728186905384064e-01
    z[1,0,6]  R227      -3.1991973519325256e-01
    z[1,0,6]  R228      -3.9871972799301147e-01
    z[1,0,6]  R229      -8.2211859524250031e-02
    z[1,0,6]  R230      -1.7676997184753418e-01
    z[1,0,6]  R231      4.8522818833589554e-02
    z[1,0,6]  R232      -6.2796503305435181e-02
    z[1,0,6]  R233      1.3915172778069973e-02
    z[1,0,6]  R234      3.0732309818267822e-01
    z[1,0,6]  R235      -1.7523214221000671e-01
    z[1,0,6]  R236      -1.7877882719039917e-01
    z[1,0,6]  R237      8.4513023495674133e-02
    z[1,0,6]  R238      6.6309428215026855e-01
    z[1,0,6]  R239      -2.1336279809474945e-02
    z[1,0,6]  R240      -2.5314772501587868e-02
    z[1,0,6]  R241      -2.4357235431671143e-01
    z[1,0,6]  R242      5.4480004310607910e-01
    z[1,0,6]  R243      2.2703976929187775e-01
    z[1,0,6]  R244      8.5677430033683777e-02
    z[1,0,6]  R245      -4.4246405363082886e-01
    z[1,0,6]  R246      5.7593584060668945e-02
    z[1,0,6]  R247      -2.5925964117050171e-01
    z[1,0,6]  R248      2.0709633827209473e-02
    z[1,0,6]  R249      -3.3967521786689758e-01
    z[1,0,6]  R250      -2.0554545521736145e-01
    z[1,0,6]  R251      -3.3647686243057251e-01
    z[1,0,6]  R252      5.7713504880666733e-02
    z[1,0,6]  R253      -3.1497564911842346e-01
    z[1,0,6]  R254      0.294825941324234
    z[1,0,6]  R255      1.3202600181102753e-01
    z[1,0,6]  R256      -0.479687362909317
    z[1,0,6]  R257      -5.3044372797012329e-01
    z[1,0,6]  R258      0.414413183927536
    z[1,0,6]  R259      2.2989781200885773e-01
    z[1,0,6]  R260      -7.8625408932566643e-03
    z[1,0,6]  R261      -6.0115452855825424e-02
    z[1,0,6]  R262      -3.7666597962379456e-01
    z[1,0,6]  R263      -2.3704078793525696e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R264      -1
    z[0,3,0]  R265      1
    z[0,3,0]  R278      -2.6278007775545120e-02
    z[0,3,0]  R279      -4.2707573622465134e-02
    z[0,3,0]  R280      -0.0056025180965662
    z[0,3,0]  R281      1.6768096014857292e-02
    z[0,3,0]  R282      5.5906623601913452e-03
    z[0,3,0]  R283      -9.9510475993156433e-02
    z[0,3,0]  R284      -6.3157521188259125e-02
    z[0,3,0]  R285      -6.6990047693252563e-02
    z[0,3,0]  R286      -7.5816698372364044e-02
    z[0,3,0]  R287      -4.7269638627767563e-02
    z[0,3,0]  R288      -0.555316150188446
    z[0,3,0]  R289      -7.0947378873825073e-01
    z[0,3,0]  R290      -6.7712688446044922e-01
    z[0,3,0]  R291      -0.62241530418396
    z[0,3,0]  R292      -0.710087239742279
    z[0,3,0]  R293      -6.6775500774383545e-01
    z[0,3,0]  R294      -6.1131346225738525e-01
    z[0,3,0]  R295      3.5818746685981750e-01
    z[0,3,0]  R296      7.2382472455501556e-02
    z[0,3,0]  R297      5.6864868849515915e-02
    z[0,3,0]  R298      6.4676970243453979e-02
    z[0,3,0]  R299      1.6652202606201172e-01
    z[0,3,0]  R300      1.4591804705560207e-02
    z[0,3,0]  R301      -9.5617817714810371e-03
    z[0,3,0]  R302      3.4006796777248383e-02
    z[0,3,0]  R303      6.6367626190185547e-02
    z[0,3,0]  R304      5.7422742247581482e-02
    z[0,3,0]  R305      8.6606591939926147e-02
    z[0,3,0]  R306      2.1507395803928375e-01
    z[0,3,0]  R307      9.0440668165683746e-02
    z[0,3,0]  R308      2.0449422299861908e-01
    z[0,3,0]  R309      2.0686280727386475e-01
    z[0,3,0]  R310      2.2820815443992615e-01
    z[0,3,0]  R311      -2.2142000496387482e-01
    z[0,3,0]  R312      1.7293131351470947e-01
    z[0,3,0]  R313      -1.1373347789049149e-01
    z[0,3,0]  R314      -2.9333535581827164e-02
    z[0,3,0]  R315      2.8769636154174805e-01
    z[0,3,0]  R316      3.0418558046221733e-02
    z[0,3,0]  R317      1.0800819098949432e-01
    z[0,3,0]  R318      2.5768694281578064e-01
    z[0,3,0]  R319      -2.1849863231182098e-01
    z[0,3,0]  R320      2.1326501667499542e-01
    z[0,3,0]  R321      2.0236921310424805e-01
    z[0,3,0]  R322      -2.6784273982048035e-01
    z[0,3,0]  R323      -3.9492547512054443e-01
    z[0,3,0]  R324      -0.580073893070221
    z[0,3,0]  R325      -6.3610792160034180e-01
    z[0,3,0]  R326      -6.5275895595550537e-01
    z[0,3,0]  R327      -5.3577989339828491e-01
    z[0,3,0]  R328      -3.6589086055755615e-02
    z[0,3,0]  R329      0.0693727433681488
    z[0,3,0]  R330      1.3377635739743710e-02
    z[0,3,0]  R331      -0.705590546131134
    z[0,3,0]  R332      2.9925478622317314e-02
    z[0,3,0]  R333      5.5139489471912384e-02
    z[0,3,0]  R334      6.8879328668117523e-02
    z[0,3,0]  R335      -3.4376001358032227e-01
    z[0,3,0]  R336      6.8608321249485016e-02
    z[0,3,0]  R337      -9.5315627753734589e-02
    z[0,3,0]  R338      4.1588321328163147e-01
    z[0,3,0]  R339      1.1865523457527161e-01
    z[0,3,0]  R340      1.0987310111522675e-01
    z[0,3,0]  R341      1.7032913863658905e-01
    z[0,3,0]  R342      7.7343232929706573e-02
    z[0,3,0]  R343      2.4044688045978546e-01
    z[0,3,0]  R344      4.9973991513252258e-01
    z[0,3,0]  R345      -2.0393800735473633e-01
    z[0,3,0]  R346      0.332888126373291
    z[0,3,0]  R347      -0.397519052028656
    z[0,3,0]  R348      1.4147533476352692e-01
    z[0,3,0]  R349      3.6231091618537903e-01
    z[0,3,0]  R350      -9.3511618673801422e-02
    z[0,3,0]  R351      1.5615861117839813e-01
    z[0,3,0]  R352      -1.8030744791030884e-01
    z[0,3,0]  R353      -2.3016983270645142e-01
    z[0,3,0]  R354      -2.6206314563751221e-01
    z[0,3,0]  R355      -3.4449473023414612e-01
    z[0,3,0]  R356      -2.2381576895713806e-01
    z[0,3,0]  R357      3.4233424067497253e-01
    z[0,3,0]  R358      1.2595053017139435e-01
    z[0,3,0]  R359      3.8731002807617188e-01
    z[0,3,0]  R360      -4.0880435705184937e-01
    z[0,3,0]  R361      1.0537336766719818e-01
    z[0,3,0]  R362      -3.6036467552185059e-01
    z[0,3,0]  R363      -1.4476144686341286e-02
    z[0,3,0]  R364      -2.9991042613983154e-01
    z[0,3,0]  R365      -5.9298592805862427e-01
    z[0,3,0]  R366      5.9217196702957153e-01
    z[0,3,0]  R367      5.6940101087093353e-02
    z[0,3,0]  R368      -5.6806594133377075e-01
    z[0,3,0]  R369      -4.8820680379867554e-01
    z[0,3,0]  R370      -1.0065668821334839e-01
    z[0,3,0]  R371      -6.6662663221359253e-01
    z[0,3,0]  R372      -5.2976123988628387e-02
    z[0,3,0]  R373      8.1685623154044151e-03
    z[0,3,0]  R374      1.7718593776226044e-01
    z[0,3,0]  R375      4.3916791677474976e-01
    z[0,3,0]  R376      3.4565997123718262e-01
    z[0,3,0]  R377      4.5147308707237244e-01
    z[0,3,0]  R378      -0.610199511051178
    z[0,3,0]  R379      -6.9077622890472412e-01
    z[0,3,0]  R380      -3.8901382684707642e-01
    z[0,3,0]  R381      -2.2505044937133789e-01
    z[0,3,0]  R382      -3.8937729597091675e-01
    z[0,3,0]  R383      2.6735246181488037e-01
    z[0,3,0]  R384      -6.1612665653228760e-01
    z[0,3,0]  R385      -0.665919303894043
    z[0,3,0]  R386      -5.9971648454666138e-01
    z[0,3,0]  R387      -5.4659348726272583e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R266      -1
    z[0,3,1]  R267      1
    z[0,3,1]  R278      -3.9014759659767151e-01
    z[0,3,1]  R279      -5.9952753782272339e-01
    z[0,3,1]  R280      -4.1370350122451782e-01
    z[0,3,1]  R281      -2.5708726048469543e-01
    z[0,3,1]  R282      -3.6687496304512024e-01
    z[0,3,1]  R283      -7.6284235715866089e-01
    z[0,3,1]  R284      -4.1863659024238586e-01
    z[0,3,1]  R285      -3.6757844686508179e-01
    z[0,3,1]  R286      -2.4931827187538147e-01
    z[0,3,1]  R287      -1.5829999744892120e-01
    z[0,3,1]  R288      7.9764628410339355e-01
    z[0,3,1]  R289      6.5807652473449707e-01
    z[0,3,1]  R290      6.1631280183792114e-01
    z[0,3,1]  R291      6.3527208566665649e-01
    z[0,3,1]  R292      5.2518397569656372e-01
    z[0,3,1]  R293      6.4900523424148560e-01
    z[0,3,1]  R294      6.0841131210327148e-01
    z[0,3,1]  R295      6.5025252103805542e-01
    z[0,3,1]  R296      6.4068323373794556e-01
    z[0,3,1]  R297      5.7729250192642212e-01
    z[0,3,1]  R298      -6.0613876581192017e-01
    z[0,3,1]  R299      -6.8577939271926880e-01
    z[0,3,1]  R300      -5.5342102050781250e-01
    z[0,3,1]  R301      -5.1002883911132812e-01
    z[0,3,1]  R302      -5.4270356893539429e-01
    z[0,3,1]  R303      -5.3589272499084473e-01
    z[0,3,1]  R304      -4.9461242556571960e-01
    z[0,3,1]  R305      -2.9641568660736084e-01
    z[0,3,1]  R306      6.2931948900222778e-01
    z[0,3,1]  R307      8.3574044704437256e-01
    z[0,3,1]  R308      8.9154487848281860e-01
    z[0,3,1]  R309      7.2135615348815918e-01
    z[0,3,1]  R310      6.6799086332321167e-01
    z[0,3,1]  R311      7.7263295650482178e-01
    z[0,3,1]  R312      7.4710875749588013e-01
    z[0,3,1]  R313      6.6347837448120117e-01
    z[0,3,1]  R314      8.7388777732849121e-01
    z[0,3,1]  R315      7.2716957330703735e-01
    z[0,3,1]  R316      0.818784773349762
    z[0,3,1]  R317      6.1233907938003540e-01
    z[0,3,1]  R318      8.4183776378631592e-01
    z[0,3,1]  R319      2.5647976994514465e-01
    z[0,3,1]  R320      3.4914711117744446e-01
    z[0,3,1]  R321      7.8099715709686279e-01
    z[0,3,1]  R322      2.5958302617073059e-01
    z[0,3,1]  R323      4.4278222322463989e-01
    z[0,3,1]  R324      -4.0670629590749741e-02
    z[0,3,1]  R325      -1.3200253248214722e-01
    z[0,3,1]  R326      6.7387841641902924e-02
    z[0,3,1]  R327      -2.2673592902719975e-03
    z[0,3,1]  R328      -7.8813350200653076e-01
    z[0,3,1]  R329      -6.3816928863525391e-01
    z[0,3,1]  R330      -5.9123784303665161e-01
    z[0,3,1]  R331      6.3668894767761230e-01
    z[0,3,1]  R332      -2.9680398106575012e-01
    z[0,3,1]  R333      -3.4536263346672058e-01
    z[0,3,1]  R334      -3.0272287130355835e-01
    z[0,3,1]  R335      6.2705171108245850e-01
    z[0,3,1]  R336      5.4102611541748047e-01
    z[0,3,1]  R337      7.6169586181640625e-01
    z[0,3,1]  R338      -4.5111289620399475e-01
    z[0,3,1]  R339      -0.439800888299942
    z[0,3,1]  R340      -3.8439545035362244e-01
    z[0,3,1]  R341      -3.6523753404617310e-01
    z[0,3,1]  R342      -4.0704101324081421e-01
    z[0,3,1]  R343      -2.5016698241233826e-01
    z[0,3,1]  R344      7.4719732999801636e-01
    z[0,3,1]  R345      6.8427371978759766e-01
    z[0,3,1]  R346      6.9754534959793091e-01
    z[0,3,1]  R347      1.9880345463752747e-01
    z[0,3,1]  R348      0.857233464717865
    z[0,3,1]  R349      7.9025137424468994e-01
    z[0,3,1]  R350      8.0379545688629150e-01
    z[0,3,1]  R351      6.9972038269042969e-01
    z[0,3,1]  R352      8.0500149726867676e-01
    z[0,3,1]  R353      7.3723131418228149e-01
    z[0,3,1]  R354      6.5980720520019531e-01
    z[0,3,1]  R355      5.4039853811264038e-01
    z[0,3,1]  R356      6.3432049751281738e-01
    z[0,3,1]  R357      3.8795873522758484e-01
    z[0,3,1]  R358      -6.5281128883361816e-01
    z[0,3,1]  R359      -4.6596240997314453e-01
    z[0,3,1]  R360      8.1147712469100952e-01
    z[0,3,1]  R361      7.8923958539962769e-01
    z[0,3,1]  R362      4.0587291121482849e-01
    z[0,3,1]  R363      7.8663498163223267e-01
    z[0,3,1]  R364      4.4646963477134705e-01
    z[0,3,1]  R365      1.2665164470672607e-01
    z[0,3,1]  R366      5.2032095193862915e-01
    z[0,3,1]  R367      2.4986878037452698e-01
    z[0,3,1]  R368      4.8440101742744446e-01
    z[0,3,1]  R369      6.6852509975433350e-01
    z[0,3,1]  R370      6.3663446903228760e-01
    z[0,3,1]  R371      4.4251322746276855e-01
    z[0,3,1]  R372      8.6939907073974609e-01
    z[0,3,1]  R373      6.1848264932632446e-01
    z[0,3,1]  R374      3.2343354821205139e-01
    z[0,3,1]  R375      5.4146373271942139e-01
    z[0,3,1]  R376      1.8972527980804443e-01
    z[0,3,1]  R377      4.1707709431648254e-01
    z[0,3,1]  R378      4.7122615575790405e-01
    z[0,3,1]  R379      6.4674860239028931e-01
    z[0,3,1]  R380      7.6113170385360718e-01
    z[0,3,1]  R381      4.8126682639122009e-01
    z[0,3,1]  R382      4.3018519878387451e-01
    z[0,3,1]  R383      2.5084331631660461e-01
    z[0,3,1]  R384      -3.1143131852149963e-01
    z[0,3,1]  R385      -1.7610348761081696e-01
    z[0,3,1]  R386      -2.7668842673301697e-01
    z[0,3,1]  R387      -3.7183105945587158e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R268      -1
    z[0,3,2]  R269      1
    z[0,3,2]  R278      4.9154743552207947e-01
    z[0,3,2]  R279      -1.9268995523452759e-01
    z[0,3,2]  R280      5.1938217878341675e-01
    z[0,3,2]  R281      0.336774617433548
    z[0,3,2]  R282      -5.0238844007253647e-02
    z[0,3,2]  R283      1.9185375422239304e-02
    z[0,3,2]  R284      3.4803774952888489e-01
    z[0,3,2]  R285      7.6155656576156616e-01
    z[0,3,2]  R286      8.2272779941558838e-01
    z[0,3,2]  R287      9.4390004873275757e-01
    z[0,3,2]  R288      -1.6586931049823761e-01
    z[0,3,2]  R289      -3.7797506898641586e-02
    z[0,3,2]  R290      -1.0418660193681717e-01
    z[0,3,2]  R291      -1.2782895565032959e-01
    z[0,3,2]  R292      -5.8416366577148438e-02
    z[0,3,2]  R293      1.8231441080570221e-01
    z[0,3,2]  R294      2.6854345202445984e-01
    z[0,3,2]  R295      -6.6050738096237183e-02
    z[0,3,2]  R296      0.0798223614692688
    z[0,3,2]  R297      7.6353847980499268e-03
    z[0,3,2]  R298      -4.0066473186016083e-02
    z[0,3,2]  R299      -3.2913509011268616e-01
    z[0,3,2]  R300      -2.6121556758880615e-01
    z[0,3,2]  R301      -6.1069771647453308e-02
    z[0,3,2]  R302      -5.6354599073529243e-03
    z[0,3,2]  R303      -4.9367120862007141e-01
    z[0,3,2]  R304      2.0203870534896851e-01
    z[0,3,2]  R305      1.9628894329071045e-01
    z[0,3,2]  R306      9.7759254276752472e-02
    z[0,3,2]  R307      3.3839073032140732e-02
    z[0,3,2]  R308      -0.0911693274974823
    z[0,3,2]  R309      -3.0325099825859070e-01
    z[0,3,2]  R310      0.475361168384552
    z[0,3,2]  R311      -2.6377236936241388e-03
    z[0,3,2]  R312      -6.8879820406436920e-02
    z[0,3,2]  R313      -2.9904362559318542e-01
    z[0,3,2]  R314      1.5658490359783173e-01
    z[0,3,2]  R315      -1.3942076265811920e-01
    z[0,3,2]  R316      3.6822181940078735e-01
    z[0,3,2]  R317      4.2282842099666595e-02
    z[0,3,2]  R318      2.1224968135356903e-01
    z[0,3,2]  R319      -6.1825770139694214e-01
    z[0,3,2]  R320      2.4210287258028984e-02
    z[0,3,2]  R321      3.3962861634790897e-03
    z[0,3,2]  R322      -3.5538685321807861e-01
    z[0,3,2]  R323      1.2202516198158264e-01
    z[0,3,2]  R324      1.8493738770484924e-01
    z[0,3,2]  R325      3.4204912185668945e-01
    z[0,3,2]  R326      1.4449992775917053e-01
    z[0,3,2]  R327      5.1398748159408569e-01
    z[0,3,2]  R328      2.9155045747756958e-01
    z[0,3,2]  R329      -4.2261886596679688e-01
    z[0,3,2]  R330      0.0226475540548563
    z[0,3,2]  R331      -7.3616698384284973e-02
    z[0,3,2]  R332      0.351779967546463
    z[0,3,2]  R333      -1.2747351825237274e-01
    z[0,3,2]  R334      -1.1474695056676865e-01
    z[0,3,2]  R335      3.4420590847730637e-02
    z[0,3,2]  R336      2.1619459986686707e-01
    z[0,3,2]  R337      2.0916143059730530e-01
    z[0,3,2]  R338      6.6711580753326416e-01
    z[0,3,2]  R339      1.9830379635095596e-02
    z[0,3,2]  R340      4.0915283560752869e-01
    z[0,3,2]  R341      5.5210381746292114e-02
    z[0,3,2]  R342      -1.1304409801959991e-01
    z[0,3,2]  R343      -6.1652410030364990e-01
    z[0,3,2]  R344      -1.5276296436786652e-01
    z[0,3,2]  R345      1.4430822432041168e-01
    z[0,3,2]  R346      -2.7639037370681763e-01
    z[0,3,2]  R347      -3.8856777548789978e-01
    z[0,3,2]  R348      2.6850545406341553e-01
    z[0,3,2]  R349      -1.3540776073932648e-01
    z[0,3,2]  R350      -1.0470170527696609e-01
    z[0,3,2]  R351      -3.6883455514907837e-01
    z[0,3,2]  R352      -1.7168706655502319e-01
    z[0,3,2]  R353      4.8716634511947632e-01
    z[0,3,2]  R354      1.8579114973545074e-01
    z[0,3,2]  R355      -4.8725920915603638e-01
    z[0,3,2]  R356      -2.5702643394470215e-01
    z[0,3,2]  R357      2.5466141104698181e-01
    z[0,3,2]  R358      -3.2065615057945251e-01
    z[0,3,2]  R359      3.8088664412498474e-01
    z[0,3,2]  R360      -5.6624421849846840e-03
    z[0,3,2]  R361      -2.9873631894588470e-02
    z[0,3,2]  R362      -6.1045056581497192e-01
    z[0,3,2]  R363      -2.4921372532844543e-01
    z[0,3,2]  R364      -4.9589291214942932e-01
    z[0,3,2]  R365      3.9476905949413776e-03
    z[0,3,2]  R366      3.8990476727485657e-01
    z[0,3,2]  R367      4.9159295856952667e-02
    z[0,3,2]  R368      -4.7137516736984253e-01
    z[0,3,2]  R369      7.6161310076713562e-02
    z[0,3,2]  R370      3.3059367537498474e-01
    z[0,3,2]  R371      -1.8056605011224747e-02
    z[0,3,2]  R372      8.5890352725982666e-02
    z[0,3,2]  R373      -1.1896006017923355e-01
    z[0,3,2]  R374      -3.1947073340415955e-01
    z[0,3,2]  R375      4.3478971719741821e-01
    z[0,3,2]  R376      -1.6211281716823578e-01
    z[0,3,2]  R377      1.5092931687831879e-01
    z[0,3,2]  R378      -4.5245864987373352e-01
    z[0,3,2]  R379      -1.4433425664901733e-01
    z[0,3,2]  R380      3.1044140458106995e-01
    z[0,3,2]  R381      -2.6153931021690369e-01
    z[0,3,2]  R382      -0.280733197927475
    z[0,3,2]  R383      -1.3410811126232147e-01
    z[0,3,2]  R384      5.7834321260452271e-01
    z[0,3,2]  R385      3.7822961807250977e-01
    z[0,3,2]  R386      4.3421438336372375e-01
    z[0,3,2]  R387      4.9262502789497375e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R270      -1
    z[0,3,3]  R271      1
    z[0,3,3]  R278      7.2889661788940430e-01
    z[0,3,3]  R279      5.6939494609832764e-01
    z[0,3,3]  R280      1.9592465460300446e-01
    z[0,3,3]  R281      7.1536588668823242e-01
    z[0,3,3]  R282      6.6275650262832642e-01
    z[0,3,3]  R283      1.9517024978995323e-02
    z[0,3,3]  R284      3.0077275633811951e-01
    z[0,3,3]  R285      3.3261362463235855e-02
    z[0,3,3]  R286      1.0025146603584290e-01
    z[0,3,3]  R287      1.5744503587484360e-02
    z[0,3,3]  R288      -1.9945492967963219e-02
    z[0,3,3]  R289      -6.9894500076770782e-02
    z[0,3,3]  R290      -3.5856020450592041e-01
    z[0,3,3]  R291      1.2311906367540359e-01
    z[0,3,3]  R292      -1.0057487338781357e-01
    z[0,3,3]  R293      2.4476251006126404e-01
    z[0,3,3]  R294      -1.0958953201770782e-01
    z[0,3,3]  R295      -5.7549077272415161e-01
    z[0,3,3]  R296      -6.4081823825836182e-01
    z[0,3,3]  R297      -7.8058832883834839e-01
    z[0,3,3]  R298      -3.7057012319564819e-01
    z[0,3,3]  R299      -2.5731462240219116e-01
    z[0,3,3]  R300      -4.3485969305038452e-01
    z[0,3,3]  R301      -1.6012582182884216e-01
    z[0,3,3]  R302      -4.9854028224945068e-01
    z[0,3,3]  R303      -7.9492524266242981e-02
    z[0,3,3]  R304      -5.0890535116195679e-01
    z[0,3,3]  R305      -8.8081145286560059e-01
    z[0,3,3]  R306      -4.2453691363334656e-01
    z[0,3,3]  R307      -3.2612148206681013e-03
    z[0,3,3]  R308      -1.2856748700141907e-01
    z[0,3,3]  R309      -2.2663326561450958e-01
    z[0,3,3]  R310      -3.1684669852256775e-01
    z[0,3,3]  R311      -2.4551613628864288e-01
    z[0,3,3]  R312      -4.2878651618957520e-01
    z[0,3,3]  R313      -3.5192716121673584e-01
    z[0,3,3]  R314      -1.5286463499069214e-01
    z[0,3,3]  R315      -2.3285862803459167e-01
    z[0,3,3]  R316      -2.9592958092689514e-01
    z[0,3,3]  R317      -5.1247978210449219e-01
    z[0,3,3]  R318      -2.8405699133872986e-01
    z[0,3,3]  R319      -6.4373493194580078e-01
    z[0,3,3]  R320      -5.1336103677749634e-01
    z[0,3,3]  R321      4.4087516143918037e-03
    z[0,3,3]  R322      -2.9839882254600525e-01
    z[0,3,3]  R323      -3.8450336456298828e-01
    z[0,3,3]  R324      -7.4159407615661621e-01
    z[0,3,3]  R325      -5.9216845035552979e-01
    z[0,3,3]  R326      -5.4077637195587158e-01
    z[0,3,3]  R327      -5.8719825744628906e-01
    z[0,3,3]  R328      1.1979837715625763e-01
    z[0,3,3]  R329      -5.2399146556854248e-01
    z[0,3,3]  R330      6.6634345054626465e-01
    z[0,3,3]  R331      -1.1344969272613525e-01
    z[0,3,3]  R332      -8.2266800105571747e-02
    z[0,3,3]  R333      -0.0785977765917778
    z[0,3,3]  R334      -4.3732246756553650e-01
    z[0,3,3]  R335      -4.9222588539123535e-01
    z[0,3,3]  R336      -0.789358377456665
    z[0,3,3]  R337      -5.1896160840988159e-01
    z[0,3,3]  R338      -1.4762806892395020e-01
    z[0,3,3]  R339      -7.1839645504951477e-02
    z[0,3,3]  R340      -5.1226228475570679e-01
    z[0,3,3]  R341      2.3346434533596039e-01
    z[0,3,3]  R342      -1.5381909906864166e-01
    z[0,3,3]  R343      -1.4028598368167877e-01
    z[0,3,3]  R344      -6.1548583209514618e-02
    z[0,3,3]  R345      -3.1095218658447266e-01
    z[0,3,3]  R346      -3.7301453948020935e-01
    z[0,3,3]  R347      -4.6497520804405212e-01
    z[0,3,3]  R348      -3.3105546236038208e-01
    z[0,3,3]  R349      -4.6913620829582214e-01
    z[0,3,3]  R350      -4.1991695761680603e-01
    z[0,3,3]  R351      -5.5058246850967407e-01
    z[0,3,3]  R352      5.0946021080017090e-01
    z[0,3,3]  R353      -6.6334336996078491e-02
    z[0,3,3]  R354      2.7412867546081543e-01
    z[0,3,3]  R355      4.4249475002288818e-01
    z[0,3,3]  R356      3.2248049974441528e-01
    z[0,3,3]  R357      -4.0056106448173523e-01
    z[0,3,3]  R358      4.4133597612380981e-01
    z[0,3,3]  R359      -0.0772356316447258
    z[0,3,3]  R360      2.7450013160705566e-01
    z[0,3,3]  R361      -5.1207160949707031e-01
    z[0,3,3]  R362      -3.5299211740493774e-01
    z[0,3,3]  R363      -5.8170523494482040e-02
    z[0,3,3]  R364      -0.651406466960907
    z[0,3,3]  R365      -5.9365576505661011e-01
    z[0,3,3]  R366      -0.0291308481246233
    z[0,3,3]  R367      -5.1408547163009644e-01
    z[0,3,3]  R368      -5.0025876611471176e-02
    z[0,3,3]  R369      5.7337163016200066e-03
    z[0,3,3]  R370      -5.2307796478271484e-01
    z[0,3,3]  R371      8.1351123750209808e-02
    z[0,3,3]  R372      -1.3375589251518250e-01
    z[0,3,3]  R373      -3.2607337832450867e-01
    z[0,3,3]  R374      -0.739935040473938
    z[0,3,3]  R375      -2.4455970525741577e-01
    z[0,3,3]  R376      -5.2082246541976929e-01
    z[0,3,3]  R377      -9.2234991490840912e-02
    z[0,3,3]  R378      -3.7684386968612671e-01
    z[0,3,3]  R379      2.8232610225677490e-01
    z[0,3,3]  R380      3.2263547182083130e-01
    z[0,3,3]  R381      -6.4435219764709473e-01
    z[0,3,3]  R382      -3.7938350439071655e-01
    z[0,3,3]  R383      -5.5153644084930420e-01
    z[0,3,3]  R384      -3.8196936249732971e-01
    z[0,3,3]  R385      -4.2192295193672180e-01
    z[0,3,3]  R386      -3.7358319759368896e-01
    z[0,3,3]  R387      -4.0055724978446960e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R272      -1
    z[0,3,4]  R273      1
    z[0,3,4]  R278      2.0803251862525940e-01
    z[0,3,4]  R279      3.9895308017730713e-01
    z[0,3,4]  R280      6.8639880418777466e-01
    z[0,3,4]  R281      -1.8633824586868286e-01
    z[0,3,4]  R282      2.7008423209190369e-01
    z[0,3,4]  R283      5.9325951337814331e-01
    z[0,3,4]  R284      4.7902908921241760e-01
    z[0,3,4]  R285      -6.6358581185340881e-02
    z[0,3,4]  R286      -2.0199451595544815e-02
    z[0,3,4]  R287      -1.2824955582618713e-01
    z[0,3,4]  R288      1.6085259616374969e-01
    z[0,3,4]  R289      9.6290744841098785e-02
    z[0,3,4]  R290      8.1927612423896790e-02
    z[0,3,4]  R291      2.7232760563492775e-02
    z[0,3,4]  R292      0.0659303069114685
    z[0,3,4]  R293      8.7063927203416824e-03
    z[0,3,4]  R294      0.0533875934779644
    z[0,3,4]  R295      1.6697880346328020e-03
    z[0,3,4]  R296      1.6146497428417206e-01
    z[0,3,4]  R297      1.2368368357419968e-01
    z[0,3,4]  R298      -5.3862744569778442e-01
    z[0,3,4]  R299      -5.4176563024520874e-01
    z[0,3,4]  R300      -5.0976920127868652e-01
    z[0,3,4]  R301      -2.5783795118331909e-01
    z[0,3,4]  R302      -1.1714033037424088e-01
    z[0,3,4]  R303      -3.1877914071083069e-01
    z[0,3,4]  R304      -1.6955876350402832e-01
    z[0,3,4]  R305      1.3076600432395935e-01
    z[0,3,4]  R306      1.2937222421169281e-01
    z[0,3,4]  R307      4.5857262611389160e-01
    z[0,3,4]  R308      3.4120818972587585e-01
    z[0,3,4]  R309      0.211094930768013
    z[0,3,4]  R310      -4.1046679019927979e-01
    z[0,3,4]  R311      4.4615232944488525e-01
    z[0,3,4]  R312      -0.0840950757265091
    z[0,3,4]  R313      3.4334605932235718e-01
    z[0,3,4]  R314      3.3535476773977280e-02
    z[0,3,4]  R315      -3.0437481403350830e-01
    z[0,3,4]  R316      -1.1535321176052094e-01
    z[0,3,4]  R317      -3.9086338877677917e-01
    z[0,3,4]  R318      1.0599235445261002e-01
    z[0,3,4]  R319      2.1184180676937103e-01
    z[0,3,4]  R320      -5.6517404317855835e-01
    z[0,3,4]  R321      -2.3261284828186035e-01
    z[0,3,4]  R322      1.9529154896736145e-01
    z[0,3,4]  R323      5.4291152954101562e-01
    z[0,3,4]  R324      0.24967060983181
    z[0,3,4]  R325      2.8349167108535767e-01
    z[0,3,4]  R326      0.337802529335022
    z[0,3,4]  R327      -2.0766319334506989e-01
    z[0,3,4]  R328      4.0810516476631165e-01
    z[0,3,4]  R329      -8.2651257514953613e-02
    z[0,3,4]  R330      2.2359290719032288e-01
    z[0,3,4]  R331      1.9921872019767761e-01
    z[0,3,4]  R332      -2.0305125415325165e-01
    z[0,3,4]  R333      -3.4954020380973816e-01
    z[0,3,4]  R334      7.8294515609741211e-02
    z[0,3,4]  R335      3.9334109425544739e-01
    z[0,3,4]  R336      -0.0928015261888504
    z[0,3,4]  R337      2.6882079243659973e-01
    z[0,3,4]  R338      6.7703694105148315e-02
    z[0,3,4]  R339      -0.374188095331192
    z[0,3,4]  R340      -1.1617810279130936e-01
    z[0,3,4]  R341      -4.3234923481941223e-01
    z[0,3,4]  R342      2.4462303519248962e-01
    z[0,3,4]  R343      2.2121407091617584e-01
    z[0,3,4]  R344      7.4796296656131744e-02
    z[0,3,4]  R345      -7.2107151150703430e-02
    z[0,3,4]  R346      -1.8771593272686005e-01
    z[0,3,4]  R347      1.6012816131114960e-01
    z[0,3,4]  R348      3.7444159388542175e-02
    z[0,3,4]  R349      -1.1119368486106396e-02
    z[0,3,4]  R350      1.2771655619144440e-01
    z[0,3,4]  R351      1.7380365170538425e-03
    z[0,3,4]  R352      -1.5074522234499454e-02
    z[0,3,4]  R353      1.9664084911346436e-01
    z[0,3,4]  R354      2.1345909684896469e-02
    z[0,3,4]  R355      -1.5040965750813484e-02
    z[0,3,4]  R356      5.8716509491205215e-02
    z[0,3,4]  R357      -1.1619853228330612e-01
    z[0,3,4]  R358      -2.2021043300628662e-01
    z[0,3,4]  R359      -6.2694478034973145e-01
    z[0,3,4]  R360      -1.0876150429248810e-01
    z[0,3,4]  R361      1.5709446370601654e-01
    z[0,3,4]  R362      -7.1048364043235779e-02
    z[0,3,4]  R363      5.4756116867065430e-01
    z[0,3,4]  R364      1.0645416378974915e-01
    z[0,3,4]  R365      2.1118494868278503e-01
    z[0,3,4]  R366      -1.6663597524166107e-01
    z[0,3,4]  R367      3.7277019023895264e-01
    z[0,3,4]  R368      -8.5882298648357391e-02
    z[0,3,4]  R369      7.4555687606334686e-02
    z[0,3,4]  R370      2.8460854291915894e-01
    z[0,3,4]  R371      1.0403080284595490e-01
    z[0,3,4]  R372      0.081064872443676
    z[0,3,4]  R373      4.7856429219245911e-01
    z[0,3,4]  R374      9.7546920180320740e-02
    z[0,3,4]  R375      -4.3939024209976196e-01
    z[0,3,4]  R376      1.4860205352306366e-01
    z[0,3,4]  R377      2.2053673863410950e-01
    z[0,3,4]  R378      -1.1096361279487610e-01
    z[0,3,4]  R379      -4.2400330305099487e-02
    z[0,3,4]  R380      1.3898704946041107e-01
    z[0,3,4]  R381      3.9633655548095703e-01
    z[0,3,4]  R382      4.7889527678489685e-01
    z[0,3,4]  R383      1.7635495960712433e-01
    z[0,3,4]  R384      7.3480255901813507e-02
    z[0,3,4]  R385      3.4458291530609131e-01
    z[0,3,4]  R386      3.3864155411720276e-01
    z[0,3,4]  R387      2.0493526756763458e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R274      -1
    z[0,3,5]  R275      1
    z[0,3,5]  R278      -1.7219580709934235e-01
    z[0,3,5]  R279      2.3822224140167236e-01
    z[0,3,5]  R280      1.9614651799201965e-02
    z[0,3,5]  R281      0.0641963854432106
    z[0,3,5]  R282      4.8918804526329041e-01
    z[0,3,5]  R283      2.0010976493358612e-01
    z[0,3,5]  R284      -1.1677581816911697e-01
    z[0,3,5]  R285      -3.5132844001054764e-02
    z[0,3,5]  R286      4.7865319252014160e-01
    z[0,3,5]  R287      5.9817917644977570e-02
    z[0,3,5]  R288      1.4256587252020836e-02
    z[0,3,5]  R289      1.6425536572933197e-01
    z[0,3,5]  R290      4.2075820267200470e-02
    z[0,3,5]  R291      -2.7283641695976257e-01
    z[0,3,5]  R292      -2.0761951804161072e-01
    z[0,3,5]  R293      -1.8142138421535492e-01
    z[0,3,5]  R294      -3.7135985493659973e-01
    z[0,3,5]  R295      3.3311226963996887e-01
    z[0,3,5]  R296      3.7047511339187622e-01
    z[0,3,5]  R297      1.9655074179172516e-01
    z[0,3,5]  R298      -3.2391062378883362e-01
    z[0,3,5]  R299      5.6745093315839767e-02
    z[0,3,5]  R300      -3.7993314862251282e-01
    z[0,3,5]  R301      -0.797989010810852
    z[0,3,5]  R302      -4.8231646418571472e-02
    z[0,3,5]  R303      -5.9691596031188965e-01
    z[0,3,5]  R304      6.5028136968612671e-01
    z[0,3,5]  R305      -1.1769316345453262e-01
    z[0,3,5]  R306      -2.3316852748394012e-01
    z[0,3,5]  R307      -1.7426036298274994e-01
    z[0,3,5]  R308      -1.2134513258934021e-01
    z[0,3,5]  R309      2.3063777387142181e-01
    z[0,3,5]  R310      5.9574604034423828e-02
    z[0,3,5]  R311      -1.6570739448070526e-01
    z[0,3,5]  R312      -4.6456447243690491e-01
    z[0,3,5]  R313      -3.1672635674476624e-01
    z[0,3,5]  R314      -3.7973642349243164e-01
    z[0,3,5]  R315      -3.3005043864250183e-01
    z[0,3,5]  R316      -2.9810637235641479e-01
    z[0,3,5]  R317      -3.1139656901359558e-01
    z[0,3,5]  R318      3.1805828213691711e-02
    z[0,3,5]  R319      -1.6592605412006378e-01
    z[0,3,5]  R320      1.3772073388099670e-01
    z[0,3,5]  R321      -1.1653266102075577e-01
    z[0,3,5]  R322      6.6004401445388794e-01
    z[0,3,5]  R323      -3.7099716067314148e-01
    z[0,3,5]  R324      -1.2369011342525482e-01
    z[0,3,5]  R325      1.6217152774333954e-01
    z[0,3,5]  R326      7.5873308815062046e-03
    z[0,3,5]  R327      -6.8098619580268860e-02
    z[0,3,5]  R328      2.9796305298805237e-01
    z[0,3,5]  R329      3.5531315207481384e-01
    z[0,3,5]  R330      3.1273981928825378e-01
    z[0,3,5]  R331      1.5132869780063629e-01
    z[0,3,5]  R332      8.2891270518302917e-02
    z[0,3,5]  R333      1.8760459125041962e-01
    z[0,3,5]  R334      -2.9356718063354492e-01
    z[0,3,5]  R335      1.7945627868175507e-01
    z[0,3,5]  R336      1.5480084717273712e-01
    z[0,3,5]  R337      -4.5567336492240429e-03
    z[0,3,5]  R338      -3.7057882547378540e-01
    z[0,3,5]  R339      -5.8638083934783936e-01
    z[0,3,5]  R340      -4.7048667073249817e-01
    z[0,3,5]  R341      -7.1876019239425659e-01
    z[0,3,5]  R342      -7.1208667755126953e-01
    z[0,3,5]  R343      -6.4713490009307861e-01
    z[0,3,5]  R344      3.7273174524307251e-01
    z[0,3,5]  R345      -4.8278215527534485e-01
    z[0,3,5]  R346      -3.8958466053009033e-01
    z[0,3,5]  R347      -6.2846875190734863e-01
    z[0,3,5]  R348      -2.0935179293155670e-01
    z[0,3,5]  R349      7.1825966238975525e-02
    z[0,3,5]  R350      -3.5511177778244019e-01
    z[0,3,5]  R351      -2.0457766950130463e-01
    z[0,3,5]  R352      -7.8436665236949921e-02
    z[0,3,5]  R353      -3.5082376003265381e-01
    z[0,3,5]  R354      -6.2063324451446533e-01
    z[0,3,5]  R355      -1.5862299501895905e-01
    z[0,3,5]  R356      -5.3206694126129150e-01
    z[0,3,5]  R357      6.7930233478546143e-01
    z[0,3,5]  R358      2.5022828578948975e-01
    z[0,3,5]  R359      2.9681313037872314e-01
    z[0,3,5]  R360      2.6027432084083557e-01
    z[0,3,5]  R361      2.3415267467498779e-01
    z[0,3,5]  R362      2.4350734055042267e-01
    z[0,3,5]  R363      3.1304490403272212e-04
    z[0,3,5]  R364      -1.4754687249660492e-01
    z[0,3,5]  R365      -1.8984548747539520e-01
    z[0,3,5]  R366      4.3392565846443176e-01
    z[0,3,5]  R367      4.6961772441864014e-01
    z[0,3,5]  R368      4.2950622737407684e-02
    z[0,3,5]  R369      2.3239459097385406e-01
    z[0,3,5]  R370      3.4280958771705627e-01
    z[0,3,5]  R371      -5.4389089345932007e-01
    z[0,3,5]  R372      -2.7062374353408813e-01
    z[0,3,5]  R373      -1.4795990660786629e-02
    z[0,3,5]  R374      6.6138349473476410e-02
    z[0,3,5]  R375      1.2924763560295105e-01
    z[0,3,5]  R376      6.0124790668487549e-01
    z[0,3,5]  R377      6.1871415376663208e-01
    z[0,3,5]  R378      2.0373660326004028e-01
    z[0,3,5]  R379      4.3375995010137558e-02
    z[0,3,5]  R380      1.8051321804523468e-01
    z[0,3,5]  R381      -7.3148764669895172e-02
    z[0,3,5]  R382      -3.7347188591957092e-01
    z[0,3,5]  R383      6.7983222007751465e-01
    z[0,3,5]  R384      1.7246770858764648e-01
    z[0,3,5]  R385      -1.8709598109126091e-02
    z[0,3,5]  R386      2.1293669939041138e-01
    z[0,3,5]  R387      2.7812838554382324e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R276      -1
    z[0,3,6]  R277      1
    z[0,3,6]  R278      -3.5443242639303207e-02
    z[0,3,6]  R279      2.4797075986862183e-01
    z[0,3,6]  R280      -2.2168788313865662e-01
    z[0,3,6]  R281      -5.1924586296081543e-01
    z[0,3,6]  R282      -3.3369296789169312e-01
    z[0,3,6]  R283      -1.2417459487915039e-01
    z[0,3,6]  R284      -6.0502439737319946e-01
    z[0,3,6]  R285      -5.2315002679824829e-01
    z[0,3,6]  R286      -1.2507562339305878e-01
    z[0,3,6]  R287      2.4796277284622192e-01
    z[0,3,6]  R288      3.7377856671810150e-02
    z[0,3,6]  R289      -1.4497044682502747e-01
    z[0,3,6]  R290      -1.1728186905384064e-01
    z[0,3,6]  R291      -3.1991973519325256e-01
    z[0,3,6]  R292      -3.9871972799301147e-01
    z[0,3,6]  R293      -8.2211859524250031e-02
    z[0,3,6]  R294      -1.7676997184753418e-01
    z[0,3,6]  R295      4.8522818833589554e-02
    z[0,3,6]  R296      -6.2796503305435181e-02
    z[0,3,6]  R297      1.3915172778069973e-02
    z[0,3,6]  R298      3.0732309818267822e-01
    z[0,3,6]  R299      -1.7523214221000671e-01
    z[0,3,6]  R300      -1.7877882719039917e-01
    z[0,3,6]  R301      8.4513023495674133e-02
    z[0,3,6]  R302      6.6309428215026855e-01
    z[0,3,6]  R303      -2.1336279809474945e-02
    z[0,3,6]  R304      -2.5314772501587868e-02
    z[0,3,6]  R305      -2.4357235431671143e-01
    z[0,3,6]  R306      5.4480004310607910e-01
    z[0,3,6]  R307      2.2703976929187775e-01
    z[0,3,6]  R308      8.5677430033683777e-02
    z[0,3,6]  R309      -4.4246405363082886e-01
    z[0,3,6]  R310      5.7593584060668945e-02
    z[0,3,6]  R311      -2.5925964117050171e-01
    z[0,3,6]  R312      2.0709633827209473e-02
    z[0,3,6]  R313      -3.3967521786689758e-01
    z[0,3,6]  R314      -2.0554545521736145e-01
    z[0,3,6]  R315      -3.3647686243057251e-01
    z[0,3,6]  R316      5.7713504880666733e-02
    z[0,3,6]  R317      -3.1497564911842346e-01
    z[0,3,6]  R318      0.294825941324234
    z[0,3,6]  R319      1.3202600181102753e-01
    z[0,3,6]  R320      -0.479687362909317
    z[0,3,6]  R321      -5.3044372797012329e-01
    z[0,3,6]  R322      0.414413183927536
    z[0,3,6]  R323      2.2989781200885773e-01
    z[0,3,6]  R324      -7.8625408932566643e-03
    z[0,3,6]  R325      -6.0115452855825424e-02
    z[0,3,6]  R326      -3.7666597962379456e-01
    z[0,3,6]  R327      -2.3704078793525696e-01
    z[0,3,6]  R328      -1.5106844902038574e-01
    z[0,3,6]  R329      -4.0926668792963028e-02
    z[0,3,6]  R330      2.4069119989871979e-01
    z[0,3,6]  R331      -1.2605784833431244e-01
    z[0,3,6]  R332      -0.855800211429596
    z[0,3,6]  R333      -8.3539414405822754e-01
    z[0,3,6]  R334      -7.7902823686599731e-01
    z[0,3,6]  R335      -2.4133461713790894e-01
    z[0,3,6]  R336      1.3475725427269936e-02
    z[0,3,6]  R337      1.5930871665477753e-01
    z[0,3,6]  R338      -1.2160740792751312e-01
    z[0,3,6]  R339      5.5052947998046875e-01
    z[0,3,6]  R340      4.1892027854919434e-01
    z[0,3,6]  R341      -2.7657487988471985e-01
    z[0,3,6]  R342      4.7432950139045715e-01
    z[0,3,6]  R343      1.1000140011310577e-01
    z[0,3,6]  R344      -1.4250591397285461e-01
    z[0,3,6]  R345      -3.6658516526222229e-01
    z[0,3,6]  R346      -8.4278509020805359e-03
    z[0,3,6]  R347      1.2105721980333328e-01
    z[0,3,6]  R348      1.3495326042175293e-01
    z[0,3,6]  R349      2.2954124957323074e-02
    z[0,3,6]  R350      -1.2433709204196930e-01
    z[0,3,6]  R351      -7.0504434406757355e-02
    z[0,3,6]  R352      1.5510024130344391e-01
    z[0,3,6]  R353      5.9778308495879173e-03
    z[0,3,6]  R354      2.5904938578605652e-02
    z[0,3,6]  R355      3.6149981617927551e-01
    z[0,3,6]  R356      -3.0157101154327393e-01
    z[0,3,6]  R357      -1.7899684607982635e-01
    z[0,3,6]  R358      -3.8635396957397461e-01
    z[0,3,6]  R359      -2.5926964357495308e-02
    z[0,3,6]  R360      -1.3939090073108673e-01
    z[0,3,6]  R361      -1.5291011333465576e-01
    z[0,3,6]  R362      3.7921956181526184e-01
    z[0,3,6]  R363      1.2522467970848083e-01
    z[0,3,6]  R364      0.085883229970932
    z[0,3,6]  R365      0.446367472410202
    z[0,3,6]  R366      9.8310850560665131e-02
    z[0,3,6]  R367      5.5508965253829956e-01
    z[0,3,6]  R368      4.5687967538833618e-01
    z[0,3,6]  R369      4.9932867288589478e-01
    z[0,3,6]  R370      0.0560506135225296
    z[0,3,6]  R371      2.1495828032493591e-01
    z[0,3,6]  R372      -3.6913719773292542e-01
    z[0,3,6]  R373      5.1739192008972168e-01
    z[0,3,6]  R374      0.447817862033844
    z[0,3,6]  R375      -0.235219344496727
    z[0,3,6]  R376      4.0423431992530823e-01
    z[0,3,6]  R377      3.9935973286628723e-01
    z[0,3,6]  R378      -7.1068987250328064e-02
    z[0,3,6]  R379      -1.8020041286945343e-02
    z[0,3,6]  R380      1.3029550015926361e-01
    z[0,3,6]  R381      2.6778453588485718e-01
    z[0,3,6]  R382      2.6788255572319031e-01
    z[0,3,6]  R383      2.2394201159477234e-01
    z[0,3,6]  R384      -8.8726624846458435e-02
    z[0,3,6]  R385      2.9218995571136475e-01
    z[0,3,6]  R386      2.7505829930305481e-01
    z[0,3,6]  R387      2.0124079287052155e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R388      -1
    z[3,0,0]  R389      1
    z[3,0,0]  R402      -3.6589086055755615e-02
    z[3,0,0]  R403      0.0693727433681488
    z[3,0,0]  R404      1.3377635739743710e-02
    z[3,0,0]  R405      -0.705590546131134
    z[3,0,0]  R406      2.9925478622317314e-02
    z[3,0,0]  R407      5.5139489471912384e-02
    z[3,0,0]  R408      6.8879328668117523e-02
    z[3,0,0]  R409      -3.4376001358032227e-01
    z[3,0,0]  R410      6.8608321249485016e-02
    z[3,0,0]  R411      -9.5315627753734589e-02
    z[3,0,0]  R412      4.1588321328163147e-01
    z[3,0,0]  R413      1.1865523457527161e-01
    z[3,0,0]  R414      1.0987310111522675e-01
    z[3,0,0]  R415      1.7032913863658905e-01
    z[3,0,0]  R416      7.7343232929706573e-02
    z[3,0,0]  R417      2.4044688045978546e-01
    z[3,0,0]  R418      4.9973991513252258e-01
    z[3,0,0]  R419      -2.0393800735473633e-01
    z[3,0,0]  R420      0.332888126373291
    z[3,0,0]  R421      -0.397519052028656
    z[3,0,0]  R422      1.4147533476352692e-01
    z[3,0,0]  R423      3.6231091618537903e-01
    z[3,0,0]  R424      -9.3511618673801422e-02
    z[3,0,0]  R425      1.5615861117839813e-01
    z[3,0,0]  R426      -1.8030744791030884e-01
    z[3,0,0]  R427      -2.3016983270645142e-01
    z[3,0,0]  R428      -2.6206314563751221e-01
    z[3,0,0]  R429      -3.4449473023414612e-01
    z[3,0,0]  R430      -2.2381576895713806e-01
    z[3,0,0]  R431      3.4233424067497253e-01
    z[3,0,0]  R432      1.2595053017139435e-01
    z[3,0,0]  R433      3.8731002807617188e-01
    z[3,0,0]  R434      -4.0880435705184937e-01
    z[3,0,0]  R435      1.0537336766719818e-01
    z[3,0,0]  R436      -3.6036467552185059e-01
    z[3,0,0]  R437      -1.4476144686341286e-02
    z[3,0,0]  R438      -2.9991042613983154e-01
    z[3,0,0]  R439      -5.9298592805862427e-01
    z[3,0,0]  R440      5.9217196702957153e-01
    z[3,0,0]  R441      5.6940101087093353e-02
    z[3,0,0]  R442      -5.6806594133377075e-01
    z[3,0,0]  R443      -4.8820680379867554e-01
    z[3,0,0]  R444      -1.0065668821334839e-01
    z[3,0,0]  R445      -6.6662663221359253e-01
    z[3,0,0]  R446      -5.2976123988628387e-02
    z[3,0,0]  R447      8.1685623154044151e-03
    z[3,0,0]  R448      1.7718593776226044e-01
    z[3,0,0]  R449      4.3916791677474976e-01
    z[3,0,0]  R450      3.4565997123718262e-01
    z[3,0,0]  R451      4.5147308707237244e-01
    z[3,0,0]  R452      -0.610199511051178
    z[3,0,0]  R453      -6.9077622890472412e-01
    z[3,0,0]  R454      -3.8901382684707642e-01
    z[3,0,0]  R455      -2.2505044937133789e-01
    z[3,0,0]  R456      -3.8937729597091675e-01
    z[3,0,0]  R457      2.6735246181488037e-01
    z[3,0,0]  R458      -6.1612665653228760e-01
    z[3,0,0]  R459      -0.665919303894043
    z[3,0,0]  R460      -5.9971648454666138e-01
    z[3,0,0]  R461      -5.4659348726272583e-01
    z[3,0,0]  R462      -2.6278007775545120e-02
    z[3,0,0]  R463      -4.2707573622465134e-02
    z[3,0,0]  R464      -0.0056025180965662
    z[3,0,0]  R465      1.6768096014857292e-02
    z[3,0,0]  R466      5.5906623601913452e-03
    z[3,0,0]  R467      -9.9510475993156433e-02
    z[3,0,0]  R468      -6.3157521188259125e-02
    z[3,0,0]  R469      -6.6990047693252563e-02
    z[3,0,0]  R470      -7.5816698372364044e-02
    z[3,0,0]  R471      -4.7269638627767563e-02
    z[3,0,0]  R472      -0.555316150188446
    z[3,0,0]  R473      -7.0947378873825073e-01
    z[3,0,0]  R474      -6.7712688446044922e-01
    z[3,0,0]  R475      -0.62241530418396
    z[3,0,0]  R476      -0.710087239742279
    z[3,0,0]  R477      -6.6775500774383545e-01
    z[3,0,0]  R478      -6.1131346225738525e-01
    z[3,0,0]  R479      3.5818746685981750e-01
    z[3,0,0]  R480      7.2382472455501556e-02
    z[3,0,0]  R481      5.6864868849515915e-02
    z[3,0,0]  R482      6.4676970243453979e-02
    z[3,0,0]  R483      1.6652202606201172e-01
    z[3,0,0]  R484      1.4591804705560207e-02
    z[3,0,0]  R485      -9.5617817714810371e-03
    z[3,0,0]  R486      3.4006796777248383e-02
    z[3,0,0]  R487      6.6367626190185547e-02
    z[3,0,0]  R488      5.7422742247581482e-02
    z[3,0,0]  R489      8.6606591939926147e-02
    z[3,0,0]  R490      2.1507395803928375e-01
    z[3,0,0]  R491      9.0440668165683746e-02
    z[3,0,0]  R492      2.0449422299861908e-01
    z[3,0,0]  R493      2.0686280727386475e-01
    z[3,0,0]  R494      2.2820815443992615e-01
    z[3,0,0]  R495      -2.2142000496387482e-01
    z[3,0,0]  R496      1.7293131351470947e-01
    z[3,0,0]  R497      -1.1373347789049149e-01
    z[3,0,0]  R498      -2.9333535581827164e-02
    z[3,0,0]  R499      2.8769636154174805e-01
    z[3,0,0]  R500      3.0418558046221733e-02
    z[3,0,0]  R501      1.0800819098949432e-01
    z[3,0,0]  R502      2.5768694281578064e-01
    z[3,0,0]  R503      -2.1849863231182098e-01
    z[3,0,0]  R504      2.1326501667499542e-01
    z[3,0,0]  R505      2.0236921310424805e-01
    z[3,0,0]  R506      -2.6784273982048035e-01
    z[3,0,0]  R507      -3.9492547512054443e-01
    z[3,0,0]  R508      -0.580073893070221
    z[3,0,0]  R509      -6.3610792160034180e-01
    z[3,0,0]  R510      -6.5275895595550537e-01
    z[3,0,0]  R511      -5.3577989339828491e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R390      -1
    z[3,0,1]  R391      1
    z[3,0,1]  R402      -7.8813350200653076e-01
    z[3,0,1]  R403      -6.3816928863525391e-01
    z[3,0,1]  R404      -5.9123784303665161e-01
    z[3,0,1]  R405      6.3668894767761230e-01
    z[3,0,1]  R406      -2.9680398106575012e-01
    z[3,0,1]  R407      -3.4536263346672058e-01
    z[3,0,1]  R408      -3.0272287130355835e-01
    z[3,0,1]  R409      6.2705171108245850e-01
    z[3,0,1]  R410      5.4102611541748047e-01
    z[3,0,1]  R411      7.6169586181640625e-01
    z[3,0,1]  R412      -4.5111289620399475e-01
    z[3,0,1]  R413      -0.439800888299942
    z[3,0,1]  R414      -3.8439545035362244e-01
    z[3,0,1]  R415      -3.6523753404617310e-01
    z[3,0,1]  R416      -4.0704101324081421e-01
    z[3,0,1]  R417      -2.5016698241233826e-01
    z[3,0,1]  R418      7.4719732999801636e-01
    z[3,0,1]  R419      6.8427371978759766e-01
    z[3,0,1]  R420      6.9754534959793091e-01
    z[3,0,1]  R421      1.9880345463752747e-01
    z[3,0,1]  R422      0.857233464717865
    z[3,0,1]  R423      7.9025137424468994e-01
    z[3,0,1]  R424      8.0379545688629150e-01
    z[3,0,1]  R425      6.9972038269042969e-01
    z[3,0,1]  R426      8.0500149726867676e-01
    z[3,0,1]  R427      7.3723131418228149e-01
    z[3,0,1]  R428      6.5980720520019531e-01
    z[3,0,1]  R429      5.4039853811264038e-01
    z[3,0,1]  R430      6.3432049751281738e-01
    z[3,0,1]  R431      3.8795873522758484e-01
    z[3,0,1]  R432      -6.5281128883361816e-01
    z[3,0,1]  R433      -4.6596240997314453e-01
    z[3,0,1]  R434      8.1147712469100952e-01
    z[3,0,1]  R435      7.8923958539962769e-01
    z[3,0,1]  R436      4.0587291121482849e-01
    z[3,0,1]  R437      7.8663498163223267e-01
    z[3,0,1]  R438      4.4646963477134705e-01
    z[3,0,1]  R439      1.2665164470672607e-01
    z[3,0,1]  R440      5.2032095193862915e-01
    z[3,0,1]  R441      2.4986878037452698e-01
    z[3,0,1]  R442      4.8440101742744446e-01
    z[3,0,1]  R443      6.6852509975433350e-01
    z[3,0,1]  R444      6.3663446903228760e-01
    z[3,0,1]  R445      4.4251322746276855e-01
    z[3,0,1]  R446      8.6939907073974609e-01
    z[3,0,1]  R447      6.1848264932632446e-01
    z[3,0,1]  R448      3.2343354821205139e-01
    z[3,0,1]  R449      5.4146373271942139e-01
    z[3,0,1]  R450      1.8972527980804443e-01
    z[3,0,1]  R451      4.1707709431648254e-01
    z[3,0,1]  R452      4.7122615575790405e-01
    z[3,0,1]  R453      6.4674860239028931e-01
    z[3,0,1]  R454      7.6113170385360718e-01
    z[3,0,1]  R455      4.8126682639122009e-01
    z[3,0,1]  R456      4.3018519878387451e-01
    z[3,0,1]  R457      2.5084331631660461e-01
    z[3,0,1]  R458      -3.1143131852149963e-01
    z[3,0,1]  R459      -1.7610348761081696e-01
    z[3,0,1]  R460      -2.7668842673301697e-01
    z[3,0,1]  R461      -3.7183105945587158e-01
    z[3,0,1]  R462      -3.9014759659767151e-01
    z[3,0,1]  R463      -5.9952753782272339e-01
    z[3,0,1]  R464      -4.1370350122451782e-01
    z[3,0,1]  R465      -2.5708726048469543e-01
    z[3,0,1]  R466      -3.6687496304512024e-01
    z[3,0,1]  R467      -7.6284235715866089e-01
    z[3,0,1]  R468      -4.1863659024238586e-01
    z[3,0,1]  R469      -3.6757844686508179e-01
    z[3,0,1]  R470      -2.4931827187538147e-01
    z[3,0,1]  R471      -1.5829999744892120e-01
    z[3,0,1]  R472      7.9764628410339355e-01
    z[3,0,1]  R473      6.5807652473449707e-01
    z[3,0,1]  R474      6.1631280183792114e-01
    z[3,0,1]  R475      6.3527208566665649e-01
    z[3,0,1]  R476      5.2518397569656372e-01
    z[3,0,1]  R477      6.4900523424148560e-01
    z[3,0,1]  R478      6.0841131210327148e-01
    z[3,0,1]  R479      6.5025252103805542e-01
    z[3,0,1]  R480      6.4068323373794556e-01
    z[3,0,1]  R481      5.7729250192642212e-01
    z[3,0,1]  R482      -6.0613876581192017e-01
    z[3,0,1]  R483      -6.8577939271926880e-01
    z[3,0,1]  R484      -5.5342102050781250e-01
    z[3,0,1]  R485      -5.1002883911132812e-01
    z[3,0,1]  R486      -5.4270356893539429e-01
    z[3,0,1]  R487      -5.3589272499084473e-01
    z[3,0,1]  R488      -4.9461242556571960e-01
    z[3,0,1]  R489      -2.9641568660736084e-01
    z[3,0,1]  R490      6.2931948900222778e-01
    z[3,0,1]  R491      8.3574044704437256e-01
    z[3,0,1]  R492      8.9154487848281860e-01
    z[3,0,1]  R493      7.2135615348815918e-01
    z[3,0,1]  R494      6.6799086332321167e-01
    z[3,0,1]  R495      7.7263295650482178e-01
    z[3,0,1]  R496      7.4710875749588013e-01
    z[3,0,1]  R497      6.6347837448120117e-01
    z[3,0,1]  R498      8.7388777732849121e-01
    z[3,0,1]  R499      7.2716957330703735e-01
    z[3,0,1]  R500      0.818784773349762
    z[3,0,1]  R501      6.1233907938003540e-01
    z[3,0,1]  R502      8.4183776378631592e-01
    z[3,0,1]  R503      2.5647976994514465e-01
    z[3,0,1]  R504      3.4914711117744446e-01
    z[3,0,1]  R505      7.8099715709686279e-01
    z[3,0,1]  R506      2.5958302617073059e-01
    z[3,0,1]  R507      4.4278222322463989e-01
    z[3,0,1]  R508      -4.0670629590749741e-02
    z[3,0,1]  R509      -1.3200253248214722e-01
    z[3,0,1]  R510      6.7387841641902924e-02
    z[3,0,1]  R511      -2.2673592902719975e-03
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R392      -1
    z[3,0,2]  R393      1
    z[3,0,2]  R402      2.9155045747756958e-01
    z[3,0,2]  R403      -4.2261886596679688e-01
    z[3,0,2]  R404      0.0226475540548563
    z[3,0,2]  R405      -7.3616698384284973e-02
    z[3,0,2]  R406      0.351779967546463
    z[3,0,2]  R407      -1.2747351825237274e-01
    z[3,0,2]  R408      -1.1474695056676865e-01
    z[3,0,2]  R409      3.4420590847730637e-02
    z[3,0,2]  R410      2.1619459986686707e-01
    z[3,0,2]  R411      2.0916143059730530e-01
    z[3,0,2]  R412      6.6711580753326416e-01
    z[3,0,2]  R413      1.9830379635095596e-02
    z[3,0,2]  R414      4.0915283560752869e-01
    z[3,0,2]  R415      5.5210381746292114e-02
    z[3,0,2]  R416      -1.1304409801959991e-01
    z[3,0,2]  R417      -6.1652410030364990e-01
    z[3,0,2]  R418      -1.5276296436786652e-01
    z[3,0,2]  R419      1.4430822432041168e-01
    z[3,0,2]  R420      -2.7639037370681763e-01
    z[3,0,2]  R421      -3.8856777548789978e-01
    z[3,0,2]  R422      2.6850545406341553e-01
    z[3,0,2]  R423      -1.3540776073932648e-01
    z[3,0,2]  R424      -1.0470170527696609e-01
    z[3,0,2]  R425      -3.6883455514907837e-01
    z[3,0,2]  R426      -1.7168706655502319e-01
    z[3,0,2]  R427      4.8716634511947632e-01
    z[3,0,2]  R428      1.8579114973545074e-01
    z[3,0,2]  R429      -4.8725920915603638e-01
    z[3,0,2]  R430      -2.5702643394470215e-01
    z[3,0,2]  R431      2.5466141104698181e-01
    z[3,0,2]  R432      -3.2065615057945251e-01
    z[3,0,2]  R433      3.8088664412498474e-01
    z[3,0,2]  R434      -5.6624421849846840e-03
    z[3,0,2]  R435      -2.9873631894588470e-02
    z[3,0,2]  R436      -6.1045056581497192e-01
    z[3,0,2]  R437      -2.4921372532844543e-01
    z[3,0,2]  R438      -4.9589291214942932e-01
    z[3,0,2]  R439      3.9476905949413776e-03
    z[3,0,2]  R440      3.8990476727485657e-01
    z[3,0,2]  R441      4.9159295856952667e-02
    z[3,0,2]  R442      -4.7137516736984253e-01
    z[3,0,2]  R443      7.6161310076713562e-02
    z[3,0,2]  R444      3.3059367537498474e-01
    z[3,0,2]  R445      -1.8056605011224747e-02
    z[3,0,2]  R446      8.5890352725982666e-02
    z[3,0,2]  R447      -1.1896006017923355e-01
    z[3,0,2]  R448      -3.1947073340415955e-01
    z[3,0,2]  R449      4.3478971719741821e-01
    z[3,0,2]  R450      -1.6211281716823578e-01
    z[3,0,2]  R451      1.5092931687831879e-01
    z[3,0,2]  R452      -4.5245864987373352e-01
    z[3,0,2]  R453      -1.4433425664901733e-01
    z[3,0,2]  R454      3.1044140458106995e-01
    z[3,0,2]  R455      -2.6153931021690369e-01
    z[3,0,2]  R456      -0.280733197927475
    z[3,0,2]  R457      -1.3410811126232147e-01
    z[3,0,2]  R458      5.7834321260452271e-01
    z[3,0,2]  R459      3.7822961807250977e-01
    z[3,0,2]  R460      4.3421438336372375e-01
    z[3,0,2]  R461      4.9262502789497375e-01
    z[3,0,2]  R462      4.9154743552207947e-01
    z[3,0,2]  R463      -1.9268995523452759e-01
    z[3,0,2]  R464      5.1938217878341675e-01
    z[3,0,2]  R465      0.336774617433548
    z[3,0,2]  R466      -5.0238844007253647e-02
    z[3,0,2]  R467      1.9185375422239304e-02
    z[3,0,2]  R468      3.4803774952888489e-01
    z[3,0,2]  R469      7.6155656576156616e-01
    z[3,0,2]  R470      8.2272779941558838e-01
    z[3,0,2]  R471      9.4390004873275757e-01
    z[3,0,2]  R472      -1.6586931049823761e-01
    z[3,0,2]  R473      -3.7797506898641586e-02
    z[3,0,2]  R474      -1.0418660193681717e-01
    z[3,0,2]  R475      -1.2782895565032959e-01
    z[3,0,2]  R476      -5.8416366577148438e-02
    z[3,0,2]  R477      1.8231441080570221e-01
    z[3,0,2]  R478      2.6854345202445984e-01
    z[3,0,2]  R479      -6.6050738096237183e-02
    z[3,0,2]  R480      0.0798223614692688
    z[3,0,2]  R481      7.6353847980499268e-03
    z[3,0,2]  R482      -4.0066473186016083e-02
    z[3,0,2]  R483      -3.2913509011268616e-01
    z[3,0,2]  R484      -2.6121556758880615e-01
    z[3,0,2]  R485      -6.1069771647453308e-02
    z[3,0,2]  R486      -5.6354599073529243e-03
    z[3,0,2]  R487      -4.9367120862007141e-01
    z[3,0,2]  R488      2.0203870534896851e-01
    z[3,0,2]  R489      1.9628894329071045e-01
    z[3,0,2]  R490      9.7759254276752472e-02
    z[3,0,2]  R491      3.3839073032140732e-02
    z[3,0,2]  R492      -0.0911693274974823
    z[3,0,2]  R493      -3.0325099825859070e-01
    z[3,0,2]  R494      0.475361168384552
    z[3,0,2]  R495      -2.6377236936241388e-03
    z[3,0,2]  R496      -6.8879820406436920e-02
    z[3,0,2]  R497      -2.9904362559318542e-01
    z[3,0,2]  R498      1.5658490359783173e-01
    z[3,0,2]  R499      -1.3942076265811920e-01
    z[3,0,2]  R500      3.6822181940078735e-01
    z[3,0,2]  R501      4.2282842099666595e-02
    z[3,0,2]  R502      2.1224968135356903e-01
    z[3,0,2]  R503      -6.1825770139694214e-01
    z[3,0,2]  R504      2.4210287258028984e-02
    z[3,0,2]  R505      3.3962861634790897e-03
    z[3,0,2]  R506      -3.5538685321807861e-01
    z[3,0,2]  R507      1.2202516198158264e-01
    z[3,0,2]  R508      1.8493738770484924e-01
    z[3,0,2]  R509      3.4204912185668945e-01
    z[3,0,2]  R510      1.4449992775917053e-01
    z[3,0,2]  R511      5.1398748159408569e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R394      -1
    z[3,0,3]  R395      1
    z[3,0,3]  R402      1.1979837715625763e-01
    z[3,0,3]  R403      -5.2399146556854248e-01
    z[3,0,3]  R404      6.6634345054626465e-01
    z[3,0,3]  R405      -1.1344969272613525e-01
    z[3,0,3]  R406      -8.2266800105571747e-02
    z[3,0,3]  R407      -0.0785977765917778
    z[3,0,3]  R408      -4.3732246756553650e-01
    z[3,0,3]  R409      -4.9222588539123535e-01
    z[3,0,3]  R410      -0.789358377456665
    z[3,0,3]  R411      -5.1896160840988159e-01
    z[3,0,3]  R412      -1.4762806892395020e-01
    z[3,0,3]  R413      -7.1839645504951477e-02
    z[3,0,3]  R414      -5.1226228475570679e-01
    z[3,0,3]  R415      2.3346434533596039e-01
    z[3,0,3]  R416      -1.5381909906864166e-01
    z[3,0,3]  R417      -1.4028598368167877e-01
    z[3,0,3]  R418      -6.1548583209514618e-02
    z[3,0,3]  R419      -3.1095218658447266e-01
    z[3,0,3]  R420      -3.7301453948020935e-01
    z[3,0,3]  R421      -4.6497520804405212e-01
    z[3,0,3]  R422      -3.3105546236038208e-01
    z[3,0,3]  R423      -4.6913620829582214e-01
    z[3,0,3]  R424      -4.1991695761680603e-01
    z[3,0,3]  R425      -5.5058246850967407e-01
    z[3,0,3]  R426      5.0946021080017090e-01
    z[3,0,3]  R427      -6.6334336996078491e-02
    z[3,0,3]  R428      2.7412867546081543e-01
    z[3,0,3]  R429      4.4249475002288818e-01
    z[3,0,3]  R430      3.2248049974441528e-01
    z[3,0,3]  R431      -4.0056106448173523e-01
    z[3,0,3]  R432      4.4133597612380981e-01
    z[3,0,3]  R433      -0.0772356316447258
    z[3,0,3]  R434      2.7450013160705566e-01
    z[3,0,3]  R435      -5.1207160949707031e-01
    z[3,0,3]  R436      -3.5299211740493774e-01
    z[3,0,3]  R437      -5.8170523494482040e-02
    z[3,0,3]  R438      -0.651406466960907
    z[3,0,3]  R439      -5.9365576505661011e-01
    z[3,0,3]  R440      -0.0291308481246233
    z[3,0,3]  R441      -5.1408547163009644e-01
    z[3,0,3]  R442      -5.0025876611471176e-02
    z[3,0,3]  R443      5.7337163016200066e-03
    z[3,0,3]  R444      -5.2307796478271484e-01
    z[3,0,3]  R445      8.1351123750209808e-02
    z[3,0,3]  R446      -1.3375589251518250e-01
    z[3,0,3]  R447      -3.2607337832450867e-01
    z[3,0,3]  R448      -0.739935040473938
    z[3,0,3]  R449      -2.4455970525741577e-01
    z[3,0,3]  R450      -5.2082246541976929e-01
    z[3,0,3]  R451      -9.2234991490840912e-02
    z[3,0,3]  R452      -3.7684386968612671e-01
    z[3,0,3]  R453      2.8232610225677490e-01
    z[3,0,3]  R454      3.2263547182083130e-01
    z[3,0,3]  R455      -6.4435219764709473e-01
    z[3,0,3]  R456      -3.7938350439071655e-01
    z[3,0,3]  R457      -5.5153644084930420e-01
    z[3,0,3]  R458      -3.8196936249732971e-01
    z[3,0,3]  R459      -4.2192295193672180e-01
    z[3,0,3]  R460      -3.7358319759368896e-01
    z[3,0,3]  R461      -4.0055724978446960e-01
    z[3,0,3]  R462      7.2889661788940430e-01
    z[3,0,3]  R463      5.6939494609832764e-01
    z[3,0,3]  R464      1.9592465460300446e-01
    z[3,0,3]  R465      7.1536588668823242e-01
    z[3,0,3]  R466      6.6275650262832642e-01
    z[3,0,3]  R467      1.9517024978995323e-02
    z[3,0,3]  R468      3.0077275633811951e-01
    z[3,0,3]  R469      3.3261362463235855e-02
    z[3,0,3]  R470      1.0025146603584290e-01
    z[3,0,3]  R471      1.5744503587484360e-02
    z[3,0,3]  R472      -1.9945492967963219e-02
    z[3,0,3]  R473      -6.9894500076770782e-02
    z[3,0,3]  R474      -3.5856020450592041e-01
    z[3,0,3]  R475      1.2311906367540359e-01
    z[3,0,3]  R476      -1.0057487338781357e-01
    z[3,0,3]  R477      2.4476251006126404e-01
    z[3,0,3]  R478      -1.0958953201770782e-01
    z[3,0,3]  R479      -5.7549077272415161e-01
    z[3,0,3]  R480      -6.4081823825836182e-01
    z[3,0,3]  R481      -7.8058832883834839e-01
    z[3,0,3]  R482      -3.7057012319564819e-01
    z[3,0,3]  R483      -2.5731462240219116e-01
    z[3,0,3]  R484      -4.3485969305038452e-01
    z[3,0,3]  R485      -1.6012582182884216e-01
    z[3,0,3]  R486      -4.9854028224945068e-01
    z[3,0,3]  R487      -7.9492524266242981e-02
    z[3,0,3]  R488      -5.0890535116195679e-01
    z[3,0,3]  R489      -8.8081145286560059e-01
    z[3,0,3]  R490      -4.2453691363334656e-01
    z[3,0,3]  R491      -3.2612148206681013e-03
    z[3,0,3]  R492      -1.2856748700141907e-01
    z[3,0,3]  R493      -2.2663326561450958e-01
    z[3,0,3]  R494      -3.1684669852256775e-01
    z[3,0,3]  R495      -2.4551613628864288e-01
    z[3,0,3]  R496      -4.2878651618957520e-01
    z[3,0,3]  R497      -3.5192716121673584e-01
    z[3,0,3]  R498      -1.5286463499069214e-01
    z[3,0,3]  R499      -2.3285862803459167e-01
    z[3,0,3]  R500      -2.9592958092689514e-01
    z[3,0,3]  R501      -5.1247978210449219e-01
    z[3,0,3]  R502      -2.8405699133872986e-01
    z[3,0,3]  R503      -6.4373493194580078e-01
    z[3,0,3]  R504      -5.1336103677749634e-01
    z[3,0,3]  R505      4.4087516143918037e-03
    z[3,0,3]  R506      -2.9839882254600525e-01
    z[3,0,3]  R507      -3.8450336456298828e-01
    z[3,0,3]  R508      -7.4159407615661621e-01
    z[3,0,3]  R509      -5.9216845035552979e-01
    z[3,0,3]  R510      -5.4077637195587158e-01
    z[3,0,3]  R511      -5.8719825744628906e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R396      -1
    z[3,0,4]  R397      1
    z[3,0,4]  R402      4.0810516476631165e-01
    z[3,0,4]  R403      -8.2651257514953613e-02
    z[3,0,4]  R404      2.2359290719032288e-01
    z[3,0,4]  R405      1.9921872019767761e-01
    z[3,0,4]  R406      -2.0305125415325165e-01
    z[3,0,4]  R407      -3.4954020380973816e-01
    z[3,0,4]  R408      7.8294515609741211e-02
    z[3,0,4]  R409      3.9334109425544739e-01
    z[3,0,4]  R410      -0.0928015261888504
    z[3,0,4]  R411      2.6882079243659973e-01
    z[3,0,4]  R412      6.7703694105148315e-02
    z[3,0,4]  R413      -0.374188095331192
    z[3,0,4]  R414      -1.1617810279130936e-01
    z[3,0,4]  R415      -4.3234923481941223e-01
    z[3,0,4]  R416      2.4462303519248962e-01
    z[3,0,4]  R417      2.2121407091617584e-01
    z[3,0,4]  R418      7.4796296656131744e-02
    z[3,0,4]  R419      -7.2107151150703430e-02
    z[3,0,4]  R420      -1.8771593272686005e-01
    z[3,0,4]  R421      1.6012816131114960e-01
    z[3,0,4]  R422      3.7444159388542175e-02
    z[3,0,4]  R423      -1.1119368486106396e-02
    z[3,0,4]  R424      1.2771655619144440e-01
    z[3,0,4]  R425      1.7380365170538425e-03
    z[3,0,4]  R426      -1.5074522234499454e-02
    z[3,0,4]  R427      1.9664084911346436e-01
    z[3,0,4]  R428      2.1345909684896469e-02
    z[3,0,4]  R429      -1.5040965750813484e-02
    z[3,0,4]  R430      5.8716509491205215e-02
    z[3,0,4]  R431      -1.1619853228330612e-01
    z[3,0,4]  R432      -2.2021043300628662e-01
    z[3,0,4]  R433      -6.2694478034973145e-01
    z[3,0,4]  R434      -1.0876150429248810e-01
    z[3,0,4]  R435      1.5709446370601654e-01
    z[3,0,4]  R436      -7.1048364043235779e-02
    z[3,0,4]  R437      5.4756116867065430e-01
    z[3,0,4]  R438      1.0645416378974915e-01
    z[3,0,4]  R439      2.1118494868278503e-01
    z[3,0,4]  R440      -1.6663597524166107e-01
    z[3,0,4]  R441      3.7277019023895264e-01
    z[3,0,4]  R442      -8.5882298648357391e-02
    z[3,0,4]  R443      7.4555687606334686e-02
    z[3,0,4]  R444      2.8460854291915894e-01
    z[3,0,4]  R445      1.0403080284595490e-01
    z[3,0,4]  R446      0.081064872443676
    z[3,0,4]  R447      4.7856429219245911e-01
    z[3,0,4]  R448      9.7546920180320740e-02
    z[3,0,4]  R449      -4.3939024209976196e-01
    z[3,0,4]  R450      1.4860205352306366e-01
    z[3,0,4]  R451      2.2053673863410950e-01
    z[3,0,4]  R452      -1.1096361279487610e-01
    z[3,0,4]  R453      -4.2400330305099487e-02
    z[3,0,4]  R454      1.3898704946041107e-01
    z[3,0,4]  R455      3.9633655548095703e-01
    z[3,0,4]  R456      4.7889527678489685e-01
    z[3,0,4]  R457      1.7635495960712433e-01
    z[3,0,4]  R458      7.3480255901813507e-02
    z[3,0,4]  R459      3.4458291530609131e-01
    z[3,0,4]  R460      3.3864155411720276e-01
    z[3,0,4]  R461      2.0493526756763458e-01
    z[3,0,4]  R462      2.0803251862525940e-01
    z[3,0,4]  R463      3.9895308017730713e-01
    z[3,0,4]  R464      6.8639880418777466e-01
    z[3,0,4]  R465      -1.8633824586868286e-01
    z[3,0,4]  R466      2.7008423209190369e-01
    z[3,0,4]  R467      5.9325951337814331e-01
    z[3,0,4]  R468      4.7902908921241760e-01
    z[3,0,4]  R469      -6.6358581185340881e-02
    z[3,0,4]  R470      -2.0199451595544815e-02
    z[3,0,4]  R471      -1.2824955582618713e-01
    z[3,0,4]  R472      1.6085259616374969e-01
    z[3,0,4]  R473      9.6290744841098785e-02
    z[3,0,4]  R474      8.1927612423896790e-02
    z[3,0,4]  R475      2.7232760563492775e-02
    z[3,0,4]  R476      0.0659303069114685
    z[3,0,4]  R477      8.7063927203416824e-03
    z[3,0,4]  R478      0.0533875934779644
    z[3,0,4]  R479      1.6697880346328020e-03
    z[3,0,4]  R480      1.6146497428417206e-01
    z[3,0,4]  R481      1.2368368357419968e-01
    z[3,0,4]  R482      -5.3862744569778442e-01
    z[3,0,4]  R483      -5.4176563024520874e-01
    z[3,0,4]  R484      -5.0976920127868652e-01
    z[3,0,4]  R485      -2.5783795118331909e-01
    z[3,0,4]  R486      -1.1714033037424088e-01
    z[3,0,4]  R487      -3.1877914071083069e-01
    z[3,0,4]  R488      -1.6955876350402832e-01
    z[3,0,4]  R489      1.3076600432395935e-01
    z[3,0,4]  R490      1.2937222421169281e-01
    z[3,0,4]  R491      4.5857262611389160e-01
    z[3,0,4]  R492      3.4120818972587585e-01
    z[3,0,4]  R493      0.211094930768013
    z[3,0,4]  R494      -4.1046679019927979e-01
    z[3,0,4]  R495      4.4615232944488525e-01
    z[3,0,4]  R496      -0.0840950757265091
    z[3,0,4]  R497      3.4334605932235718e-01
    z[3,0,4]  R498      3.3535476773977280e-02
    z[3,0,4]  R499      -3.0437481403350830e-01
    z[3,0,4]  R500      -1.1535321176052094e-01
    z[3,0,4]  R501      -3.9086338877677917e-01
    z[3,0,4]  R502      1.0599235445261002e-01
    z[3,0,4]  R503      2.1184180676937103e-01
    z[3,0,4]  R504      -5.6517404317855835e-01
    z[3,0,4]  R505      -2.3261284828186035e-01
    z[3,0,4]  R506      1.9529154896736145e-01
    z[3,0,4]  R507      5.4291152954101562e-01
    z[3,0,4]  R508      0.24967060983181
    z[3,0,4]  R509      2.8349167108535767e-01
    z[3,0,4]  R510      0.337802529335022
    z[3,0,4]  R511      -2.0766319334506989e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R398      -1
    z[3,0,5]  R399      1
    z[3,0,5]  R402      2.9796305298805237e-01
    z[3,0,5]  R403      3.5531315207481384e-01
    z[3,0,5]  R404      3.1273981928825378e-01
    z[3,0,5]  R405      1.5132869780063629e-01
    z[3,0,5]  R406      8.2891270518302917e-02
    z[3,0,5]  R407      1.8760459125041962e-01
    z[3,0,5]  R408      -2.9356718063354492e-01
    z[3,0,5]  R409      1.7945627868175507e-01
    z[3,0,5]  R410      1.5480084717273712e-01
    z[3,0,5]  R411      -4.5567336492240429e-03
    z[3,0,5]  R412      -3.7057882547378540e-01
    z[3,0,5]  R413      -5.8638083934783936e-01
    z[3,0,5]  R414      -4.7048667073249817e-01
    z[3,0,5]  R415      -7.1876019239425659e-01
    z[3,0,5]  R416      -7.1208667755126953e-01
    z[3,0,5]  R417      -6.4713490009307861e-01
    z[3,0,5]  R418      3.7273174524307251e-01
    z[3,0,5]  R419      -4.8278215527534485e-01
    z[3,0,5]  R420      -3.8958466053009033e-01
    z[3,0,5]  R421      -6.2846875190734863e-01
    z[3,0,5]  R422      -2.0935179293155670e-01
    z[3,0,5]  R423      7.1825966238975525e-02
    z[3,0,5]  R424      -3.5511177778244019e-01
    z[3,0,5]  R425      -2.0457766950130463e-01
    z[3,0,5]  R426      -7.8436665236949921e-02
    z[3,0,5]  R427      -3.5082376003265381e-01
    z[3,0,5]  R428      -6.2063324451446533e-01
    z[3,0,5]  R429      -1.5862299501895905e-01
    z[3,0,5]  R430      -5.3206694126129150e-01
    z[3,0,5]  R431      6.7930233478546143e-01
    z[3,0,5]  R432      2.5022828578948975e-01
    z[3,0,5]  R433      2.9681313037872314e-01
    z[3,0,5]  R434      2.6027432084083557e-01
    z[3,0,5]  R435      2.3415267467498779e-01
    z[3,0,5]  R436      2.4350734055042267e-01
    z[3,0,5]  R437      3.1304490403272212e-04
    z[3,0,5]  R438      -1.4754687249660492e-01
    z[3,0,5]  R439      -1.8984548747539520e-01
    z[3,0,5]  R440      4.3392565846443176e-01
    z[3,0,5]  R441      4.6961772441864014e-01
    z[3,0,5]  R442      4.2950622737407684e-02
    z[3,0,5]  R443      2.3239459097385406e-01
    z[3,0,5]  R444      3.4280958771705627e-01
    z[3,0,5]  R445      -5.4389089345932007e-01
    z[3,0,5]  R446      -2.7062374353408813e-01
    z[3,0,5]  R447      -1.4795990660786629e-02
    z[3,0,5]  R448      6.6138349473476410e-02
    z[3,0,5]  R449      1.2924763560295105e-01
    z[3,0,5]  R450      6.0124790668487549e-01
    z[3,0,5]  R451      6.1871415376663208e-01
    z[3,0,5]  R452      2.0373660326004028e-01
    z[3,0,5]  R453      4.3375995010137558e-02
    z[3,0,5]  R454      1.8051321804523468e-01
    z[3,0,5]  R455      -7.3148764669895172e-02
    z[3,0,5]  R456      -3.7347188591957092e-01
    z[3,0,5]  R457      6.7983222007751465e-01
    z[3,0,5]  R458      1.7246770858764648e-01
    z[3,0,5]  R459      -1.8709598109126091e-02
    z[3,0,5]  R460      2.1293669939041138e-01
    z[3,0,5]  R461      2.7812838554382324e-01
    z[3,0,5]  R462      -1.7219580709934235e-01
    z[3,0,5]  R463      2.3822224140167236e-01
    z[3,0,5]  R464      1.9614651799201965e-02
    z[3,0,5]  R465      0.0641963854432106
    z[3,0,5]  R466      4.8918804526329041e-01
    z[3,0,5]  R467      2.0010976493358612e-01
    z[3,0,5]  R468      -1.1677581816911697e-01
    z[3,0,5]  R469      -3.5132844001054764e-02
    z[3,0,5]  R470      4.7865319252014160e-01
    z[3,0,5]  R471      5.9817917644977570e-02
    z[3,0,5]  R472      1.4256587252020836e-02
    z[3,0,5]  R473      1.6425536572933197e-01
    z[3,0,5]  R474      4.2075820267200470e-02
    z[3,0,5]  R475      -2.7283641695976257e-01
    z[3,0,5]  R476      -2.0761951804161072e-01
    z[3,0,5]  R477      -1.8142138421535492e-01
    z[3,0,5]  R478      -3.7135985493659973e-01
    z[3,0,5]  R479      3.3311226963996887e-01
    z[3,0,5]  R480      3.7047511339187622e-01
    z[3,0,5]  R481      1.9655074179172516e-01
    z[3,0,5]  R482      -3.2391062378883362e-01
    z[3,0,5]  R483      5.6745093315839767e-02
    z[3,0,5]  R484      -3.7993314862251282e-01
    z[3,0,5]  R485      -0.797989010810852
    z[3,0,5]  R486      -4.8231646418571472e-02
    z[3,0,5]  R487      -5.9691596031188965e-01
    z[3,0,5]  R488      6.5028136968612671e-01
    z[3,0,5]  R489      -1.1769316345453262e-01
    z[3,0,5]  R490      -2.3316852748394012e-01
    z[3,0,5]  R491      -1.7426036298274994e-01
    z[3,0,5]  R492      -1.2134513258934021e-01
    z[3,0,5]  R493      2.3063777387142181e-01
    z[3,0,5]  R494      5.9574604034423828e-02
    z[3,0,5]  R495      -1.6570739448070526e-01
    z[3,0,5]  R496      -4.6456447243690491e-01
    z[3,0,5]  R497      -3.1672635674476624e-01
    z[3,0,5]  R498      -3.7973642349243164e-01
    z[3,0,5]  R499      -3.3005043864250183e-01
    z[3,0,5]  R500      -2.9810637235641479e-01
    z[3,0,5]  R501      -3.1139656901359558e-01
    z[3,0,5]  R502      3.1805828213691711e-02
    z[3,0,5]  R503      -1.6592605412006378e-01
    z[3,0,5]  R504      1.3772073388099670e-01
    z[3,0,5]  R505      -1.1653266102075577e-01
    z[3,0,5]  R506      6.6004401445388794e-01
    z[3,0,5]  R507      -3.7099716067314148e-01
    z[3,0,5]  R508      -1.2369011342525482e-01
    z[3,0,5]  R509      1.6217152774333954e-01
    z[3,0,5]  R510      7.5873308815062046e-03
    z[3,0,5]  R511      -6.8098619580268860e-02
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R400      -1
    z[3,0,6]  R401      1
    z[3,0,6]  R402      -1.5106844902038574e-01
    z[3,0,6]  R403      -4.0926668792963028e-02
    z[3,0,6]  R404      2.4069119989871979e-01
    z[3,0,6]  R405      -1.2605784833431244e-01
    z[3,0,6]  R406      -0.855800211429596
    z[3,0,6]  R407      -8.3539414405822754e-01
    z[3,0,6]  R408      -7.7902823686599731e-01
    z[3,0,6]  R409      -2.4133461713790894e-01
    z[3,0,6]  R410      1.3475725427269936e-02
    z[3,0,6]  R411      1.5930871665477753e-01
    z[3,0,6]  R412      -1.2160740792751312e-01
    z[3,0,6]  R413      5.5052947998046875e-01
    z[3,0,6]  R414      4.1892027854919434e-01
    z[3,0,6]  R415      -2.7657487988471985e-01
    z[3,0,6]  R416      4.7432950139045715e-01
    z[3,0,6]  R417      1.1000140011310577e-01
    z[3,0,6]  R418      -1.4250591397285461e-01
    z[3,0,6]  R419      -3.6658516526222229e-01
    z[3,0,6]  R420      -8.4278509020805359e-03
    z[3,0,6]  R421      1.2105721980333328e-01
    z[3,0,6]  R422      1.3495326042175293e-01
    z[3,0,6]  R423      2.2954124957323074e-02
    z[3,0,6]  R424      -1.2433709204196930e-01
    z[3,0,6]  R425      -7.0504434406757355e-02
    z[3,0,6]  R426      1.5510024130344391e-01
    z[3,0,6]  R427      5.9778308495879173e-03
    z[3,0,6]  R428      2.5904938578605652e-02
    z[3,0,6]  R429      3.6149981617927551e-01
    z[3,0,6]  R430      -3.0157101154327393e-01
    z[3,0,6]  R431      -1.7899684607982635e-01
    z[3,0,6]  R432      -3.8635396957397461e-01
    z[3,0,6]  R433      -2.5926964357495308e-02
    z[3,0,6]  R434      -1.3939090073108673e-01
    z[3,0,6]  R435      -1.5291011333465576e-01
    z[3,0,6]  R436      3.7921956181526184e-01
    z[3,0,6]  R437      1.2522467970848083e-01
    z[3,0,6]  R438      0.085883229970932
    z[3,0,6]  R439      0.446367472410202
    z[3,0,6]  R440      9.8310850560665131e-02
    z[3,0,6]  R441      5.5508965253829956e-01
    z[3,0,6]  R442      4.5687967538833618e-01
    z[3,0,6]  R443      4.9932867288589478e-01
    z[3,0,6]  R444      0.0560506135225296
    z[3,0,6]  R445      2.1495828032493591e-01
    z[3,0,6]  R446      -3.6913719773292542e-01
    z[3,0,6]  R447      5.1739192008972168e-01
    z[3,0,6]  R448      0.447817862033844
    z[3,0,6]  R449      -0.235219344496727
    z[3,0,6]  R450      4.0423431992530823e-01
    z[3,0,6]  R451      3.9935973286628723e-01
    z[3,0,6]  R452      -7.1068987250328064e-02
    z[3,0,6]  R453      -1.8020041286945343e-02
    z[3,0,6]  R454      1.3029550015926361e-01
    z[3,0,6]  R455      2.6778453588485718e-01
    z[3,0,6]  R456      2.6788255572319031e-01
    z[3,0,6]  R457      2.2394201159477234e-01
    z[3,0,6]  R458      -8.8726624846458435e-02
    z[3,0,6]  R459      2.9218995571136475e-01
    z[3,0,6]  R460      2.7505829930305481e-01
    z[3,0,6]  R461      2.0124079287052155e-01
    z[3,0,6]  R462      -3.5443242639303207e-02
    z[3,0,6]  R463      2.4797075986862183e-01
    z[3,0,6]  R464      -2.2168788313865662e-01
    z[3,0,6]  R465      -5.1924586296081543e-01
    z[3,0,6]  R466      -3.3369296789169312e-01
    z[3,0,6]  R467      -1.2417459487915039e-01
    z[3,0,6]  R468      -6.0502439737319946e-01
    z[3,0,6]  R469      -5.2315002679824829e-01
    z[3,0,6]  R470      -1.2507562339305878e-01
    z[3,0,6]  R471      2.4796277284622192e-01
    z[3,0,6]  R472      3.7377856671810150e-02
    z[3,0,6]  R473      -1.4497044682502747e-01
    z[3,0,6]  R474      -1.1728186905384064e-01
    z[3,0,6]  R475      -3.1991973519325256e-01
    z[3,0,6]  R476      -3.9871972799301147e-01
    z[3,0,6]  R477      -8.2211859524250031e-02
    z[3,0,6]  R478      -1.7676997184753418e-01
    z[3,0,6]  R479      4.8522818833589554e-02
    z[3,0,6]  R480      -6.2796503305435181e-02
    z[3,0,6]  R481      1.3915172778069973e-02
    z[3,0,6]  R482      3.0732309818267822e-01
    z[3,0,6]  R483      -1.7523214221000671e-01
    z[3,0,6]  R484      -1.7877882719039917e-01
    z[3,0,6]  R485      8.4513023495674133e-02
    z[3,0,6]  R486      6.6309428215026855e-01
    z[3,0,6]  R487      -2.1336279809474945e-02
    z[3,0,6]  R488      -2.5314772501587868e-02
    z[3,0,6]  R489      -2.4357235431671143e-01
    z[3,0,6]  R490      5.4480004310607910e-01
    z[3,0,6]  R491      2.2703976929187775e-01
    z[3,0,6]  R492      8.5677430033683777e-02
    z[3,0,6]  R493      -4.4246405363082886e-01
    z[3,0,6]  R494      5.7593584060668945e-02
    z[3,0,6]  R495      -2.5925964117050171e-01
    z[3,0,6]  R496      2.0709633827209473e-02
    z[3,0,6]  R497      -3.3967521786689758e-01
    z[3,0,6]  R498      -2.0554545521736145e-01
    z[3,0,6]  R499      -3.3647686243057251e-01
    z[3,0,6]  R500      5.7713504880666733e-02
    z[3,0,6]  R501      -3.1497564911842346e-01
    z[3,0,6]  R502      0.294825941324234
    z[3,0,6]  R503      1.3202600181102753e-01
    z[3,0,6]  R504      -0.479687362909317
    z[3,0,6]  R505      -5.3044372797012329e-01
    z[3,0,6]  R506      0.414413183927536
    z[3,0,6]  R507      2.2989781200885773e-01
    z[3,0,6]  R508      -7.8625408932566643e-03
    z[3,0,6]  R509      -6.0115452855825424e-02
    z[3,0,6]  R510      -3.7666597962379456e-01
    z[3,0,6]  R511      -2.3704078793525696e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R512      -1
    z[0,4,0]  R513      1
    z[0,4,0]  R526      -2.6278007775545120e-02
    z[0,4,0]  R527      -4.2707573622465134e-02
    z[0,4,0]  R528      -0.0056025180965662
    z[0,4,0]  R529      1.6768096014857292e-02
    z[0,4,0]  R530      5.5906623601913452e-03
    z[0,4,0]  R531      -9.9510475993156433e-02
    z[0,4,0]  R532      -6.3157521188259125e-02
    z[0,4,0]  R533      -6.6990047693252563e-02
    z[0,4,0]  R534      -7.5816698372364044e-02
    z[0,4,0]  R535      -4.7269638627767563e-02
    z[0,4,0]  R536      -0.555316150188446
    z[0,4,0]  R537      -7.0947378873825073e-01
    z[0,4,0]  R538      -6.7712688446044922e-01
    z[0,4,0]  R539      -0.62241530418396
    z[0,4,0]  R540      -0.710087239742279
    z[0,4,0]  R541      -6.6775500774383545e-01
    z[0,4,0]  R542      -6.1131346225738525e-01
    z[0,4,0]  R543      3.5818746685981750e-01
    z[0,4,0]  R544      7.2382472455501556e-02
    z[0,4,0]  R545      5.6864868849515915e-02
    z[0,4,0]  R546      6.4676970243453979e-02
    z[0,4,0]  R547      1.6652202606201172e-01
    z[0,4,0]  R548      1.4591804705560207e-02
    z[0,4,0]  R549      -9.5617817714810371e-03
    z[0,4,0]  R550      3.4006796777248383e-02
    z[0,4,0]  R551      6.6367626190185547e-02
    z[0,4,0]  R552      5.7422742247581482e-02
    z[0,4,0]  R553      8.6606591939926147e-02
    z[0,4,0]  R554      2.1507395803928375e-01
    z[0,4,0]  R555      9.0440668165683746e-02
    z[0,4,0]  R556      2.0449422299861908e-01
    z[0,4,0]  R557      2.0686280727386475e-01
    z[0,4,0]  R558      2.2820815443992615e-01
    z[0,4,0]  R559      -2.2142000496387482e-01
    z[0,4,0]  R560      1.7293131351470947e-01
    z[0,4,0]  R561      -1.1373347789049149e-01
    z[0,4,0]  R562      -2.9333535581827164e-02
    z[0,4,0]  R563      2.8769636154174805e-01
    z[0,4,0]  R564      3.0418558046221733e-02
    z[0,4,0]  R565      1.0800819098949432e-01
    z[0,4,0]  R566      2.5768694281578064e-01
    z[0,4,0]  R567      -2.1849863231182098e-01
    z[0,4,0]  R568      2.1326501667499542e-01
    z[0,4,0]  R569      2.0236921310424805e-01
    z[0,4,0]  R570      -2.6784273982048035e-01
    z[0,4,0]  R571      -3.9492547512054443e-01
    z[0,4,0]  R572      -0.580073893070221
    z[0,4,0]  R573      -6.3610792160034180e-01
    z[0,4,0]  R574      -6.5275895595550537e-01
    z[0,4,0]  R575      -5.3577989339828491e-01
    z[0,4,0]  R576      -4.4537249207496643e-01
    z[0,4,0]  R577      -5.1074630022048950e-01
    z[0,4,0]  R578      -5.2198320627212524e-01
    z[0,4,0]  R579      1.4921683818101883e-02
    z[0,4,0]  R580      -9.6592712402343750e-01
    z[0,4,0]  R581      8.0585852265357971e-02
    z[0,4,0]  R582      -1.7927173525094986e-02
    z[0,4,0]  R583      3.2609567046165466e-02
    z[0,4,0]  R584      -2.4398061633110046e-01
    z[0,4,0]  R585      -1.0867832228541374e-02
    z[0,4,0]  R586      0.331209659576416
    z[0,4,0]  R587      3.7573602795600891e-01
    z[0,4,0]  R588      4.9842461943626404e-01
    z[0,4,0]  R589      3.3839711546897888e-01
    z[0,4,0]  R590      3.7496492266654968e-01
    z[0,4,0]  R591      3.4600558876991272e-01
    z[0,4,0]  R592      2.5181302428245544e-01
    z[0,4,0]  R593      1.5387284755706787e-01
    z[0,4,0]  R594      3.2433813810348511e-01
    z[0,4,0]  R595      2.0987780392169952e-01
    z[0,4,0]  R596      2.4177080392837524e-01
    z[0,4,0]  R597      -1.7149411141872406e-01
    z[0,4,0]  R598      -1.1276394070591778e-04
    z[0,4,0]  R599      0.299360454082489
    z[0,4,0]  R600      1.8625383079051971e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R514      -1
    z[0,4,1]  R515      1
    z[0,4,1]  R526      -3.9014759659767151e-01
    z[0,4,1]  R527      -5.9952753782272339e-01
    z[0,4,1]  R528      -4.1370350122451782e-01
    z[0,4,1]  R529      -2.5708726048469543e-01
    z[0,4,1]  R530      -3.6687496304512024e-01
    z[0,4,1]  R531      -7.6284235715866089e-01
    z[0,4,1]  R532      -4.1863659024238586e-01
    z[0,4,1]  R533      -3.6757844686508179e-01
    z[0,4,1]  R534      -2.4931827187538147e-01
    z[0,4,1]  R535      -1.5829999744892120e-01
    z[0,4,1]  R536      7.9764628410339355e-01
    z[0,4,1]  R537      6.5807652473449707e-01
    z[0,4,1]  R538      6.1631280183792114e-01
    z[0,4,1]  R539      6.3527208566665649e-01
    z[0,4,1]  R540      5.2518397569656372e-01
    z[0,4,1]  R541      6.4900523424148560e-01
    z[0,4,1]  R542      6.0841131210327148e-01
    z[0,4,1]  R543      6.5025252103805542e-01
    z[0,4,1]  R544      6.4068323373794556e-01
    z[0,4,1]  R545      5.7729250192642212e-01
    z[0,4,1]  R546      -6.0613876581192017e-01
    z[0,4,1]  R547      -6.8577939271926880e-01
    z[0,4,1]  R548      -5.5342102050781250e-01
    z[0,4,1]  R549      -5.1002883911132812e-01
    z[0,4,1]  R550      -5.4270356893539429e-01
    z[0,4,1]  R551      -5.3589272499084473e-01
    z[0,4,1]  R552      -4.9461242556571960e-01
    z[0,4,1]  R553      -2.9641568660736084e-01
    z[0,4,1]  R554      6.2931948900222778e-01
    z[0,4,1]  R555      8.3574044704437256e-01
    z[0,4,1]  R556      8.9154487848281860e-01
    z[0,4,1]  R557      7.2135615348815918e-01
    z[0,4,1]  R558      6.6799086332321167e-01
    z[0,4,1]  R559      7.7263295650482178e-01
    z[0,4,1]  R560      7.4710875749588013e-01
    z[0,4,1]  R561      6.6347837448120117e-01
    z[0,4,1]  R562      8.7388777732849121e-01
    z[0,4,1]  R563      7.2716957330703735e-01
    z[0,4,1]  R564      0.818784773349762
    z[0,4,1]  R565      6.1233907938003540e-01
    z[0,4,1]  R566      8.4183776378631592e-01
    z[0,4,1]  R567      2.5647976994514465e-01
    z[0,4,1]  R568      3.4914711117744446e-01
    z[0,4,1]  R569      7.8099715709686279e-01
    z[0,4,1]  R570      2.5958302617073059e-01
    z[0,4,1]  R571      4.4278222322463989e-01
    z[0,4,1]  R572      -4.0670629590749741e-02
    z[0,4,1]  R573      -1.3200253248214722e-01
    z[0,4,1]  R574      6.7387841641902924e-02
    z[0,4,1]  R575      -2.2673592902719975e-03
    z[0,4,1]  R576      0.665277361869812
    z[0,4,1]  R577      5.7158994674682617e-01
    z[0,4,1]  R578      4.0337088704109192e-01
    z[0,4,1]  R579      7.5647455453872681e-01
    z[0,4,1]  R580      7.8719764947891235e-02
    z[0,4,1]  R581      -6.6353100538253784e-01
    z[0,4,1]  R582      -5.6738960742950439e-01
    z[0,4,1]  R583      -0.539656400680542
    z[0,4,1]  R584      -7.3659688234329224e-01
    z[0,4,1]  R585      2.8826889395713806e-01
    z[0,4,1]  R586      -7.7573865652084351e-01
    z[0,4,1]  R587      -7.6019245386123657e-01
    z[0,4,1]  R588      -6.0532516241073608e-01
    z[0,4,1]  R589      -7.0515912771224976e-01
    z[0,4,1]  R590      -6.2775951623916626e-01
    z[0,4,1]  R591      -6.5205973386764526e-01
    z[0,4,1]  R592      -7.5500094890594482e-01
    z[0,4,1]  R593      -0.685711681842804
    z[0,4,1]  R594      -5.7793557643890381e-01
    z[0,4,1]  R595      -6.6598445177078247e-01
    z[0,4,1]  R596      -6.6299033164978027e-01
    z[0,4,1]  R597      2.1881558932363987e-03
    z[0,4,1]  R598      1.9273987039923668e-02
    z[0,4,1]  R599      5.7013678550720215e-01
    z[0,4,1]  R600      6.1896014213562012e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R516      -1
    z[0,4,2]  R517      1
    z[0,4,2]  R526      4.9154743552207947e-01
    z[0,4,2]  R527      -1.9268995523452759e-01
    z[0,4,2]  R528      5.1938217878341675e-01
    z[0,4,2]  R529      0.336774617433548
    z[0,4,2]  R530      -5.0238844007253647e-02
    z[0,4,2]  R531      1.9185375422239304e-02
    z[0,4,2]  R532      3.4803774952888489e-01
    z[0,4,2]  R533      7.6155656576156616e-01
    z[0,4,2]  R534      8.2272779941558838e-01
    z[0,4,2]  R535      9.4390004873275757e-01
    z[0,4,2]  R536      -1.6586931049823761e-01
    z[0,4,2]  R537      -3.7797506898641586e-02
    z[0,4,2]  R538      -1.0418660193681717e-01
    z[0,4,2]  R539      -1.2782895565032959e-01
    z[0,4,2]  R540      -5.8416366577148438e-02
    z[0,4,2]  R541      1.8231441080570221e-01
    z[0,4,2]  R542      2.6854345202445984e-01
    z[0,4,2]  R543      -6.6050738096237183e-02
    z[0,4,2]  R544      0.0798223614692688
    z[0,4,2]  R545      7.6353847980499268e-03
    z[0,4,2]  R546      -4.0066473186016083e-02
    z[0,4,2]  R547      -3.2913509011268616e-01
    z[0,4,2]  R548      -2.6121556758880615e-01
    z[0,4,2]  R549      -6.1069771647453308e-02
    z[0,4,2]  R550      -5.6354599073529243e-03
    z[0,4,2]  R551      -4.9367120862007141e-01
    z[0,4,2]  R552      2.0203870534896851e-01
    z[0,4,2]  R553      1.9628894329071045e-01
    z[0,4,2]  R554      9.7759254276752472e-02
    z[0,4,2]  R555      3.3839073032140732e-02
    z[0,4,2]  R556      -0.0911693274974823
    z[0,4,2]  R557      -3.0325099825859070e-01
    z[0,4,2]  R558      0.475361168384552
    z[0,4,2]  R559      -2.6377236936241388e-03
    z[0,4,2]  R560      -6.8879820406436920e-02
    z[0,4,2]  R561      -2.9904362559318542e-01
    z[0,4,2]  R562      1.5658490359783173e-01
    z[0,4,2]  R563      -1.3942076265811920e-01
    z[0,4,2]  R564      3.6822181940078735e-01
    z[0,4,2]  R565      4.2282842099666595e-02
    z[0,4,2]  R566      2.1224968135356903e-01
    z[0,4,2]  R567      -6.1825770139694214e-01
    z[0,4,2]  R568      2.4210287258028984e-02
    z[0,4,2]  R569      3.3962861634790897e-03
    z[0,4,2]  R570      -3.5538685321807861e-01
    z[0,4,2]  R571      1.2202516198158264e-01
    z[0,4,2]  R572      1.8493738770484924e-01
    z[0,4,2]  R573      3.4204912185668945e-01
    z[0,4,2]  R574      1.4449992775917053e-01
    z[0,4,2]  R575      5.1398748159408569e-01
    z[0,4,2]  R576      -3.3246603608131409e-01
    z[0,4,2]  R577      -3.3024686574935913e-01
    z[0,4,2]  R578      -3.8213226199150085e-01
    z[0,4,2]  R579      -5.9999954700469971e-01
    z[0,4,2]  R580      -1.8448592722415924e-01
    z[0,4,2]  R581      4.5519477128982544e-01
    z[0,4,2]  R582      -1.3045579195022583e-01
    z[0,4,2]  R583      -2.9634529352188110e-01
    z[0,4,2]  R584      4.5163431763648987e-01
    z[0,4,2]  R585      0.0443992018699646
    z[0,4,2]  R586      4.3069524690508842e-03
    z[0,4,2]  R587      -2.0378093421459198e-01
    z[0,4,2]  R588      -2.0583665370941162e-01
    z[0,4,2]  R589      -0.601309597492218
    z[0,4,2]  R590      7.6408926397562027e-03
    z[0,4,2]  R591      -2.1865795552730560e-01
    z[0,4,2]  R592      -5.1944029331207275e-01
    z[0,4,2]  R593      2.9603847861289978e-01
    z[0,4,2]  R594      -1.8319685757160187e-01
    z[0,4,2]  R595      5.0144165754318237e-01
    z[0,4,2]  R596      3.1911796331405640e-01
    z[0,4,2]  R597      -5.3569239377975464e-01
    z[0,4,2]  R598      -5.2974373102188110e-01
    z[0,4,2]  R599      3.3966198563575745e-01
    z[0,4,2]  R600      6.2364935874938965e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R518      -1
    z[0,4,3]  R519      1
    z[0,4,3]  R526      7.2889661788940430e-01
    z[0,4,3]  R527      5.6939494609832764e-01
    z[0,4,3]  R528      1.9592465460300446e-01
    z[0,4,3]  R529      7.1536588668823242e-01
    z[0,4,3]  R530      6.6275650262832642e-01
    z[0,4,3]  R531      1.9517024978995323e-02
    z[0,4,3]  R532      3.0077275633811951e-01
    z[0,4,3]  R533      3.3261362463235855e-02
    z[0,4,3]  R534      1.0025146603584290e-01
    z[0,4,3]  R535      1.5744503587484360e-02
    z[0,4,3]  R536      -1.9945492967963219e-02
    z[0,4,3]  R537      -6.9894500076770782e-02
    z[0,4,3]  R538      -3.5856020450592041e-01
    z[0,4,3]  R539      1.2311906367540359e-01
    z[0,4,3]  R540      -1.0057487338781357e-01
    z[0,4,3]  R541      2.4476251006126404e-01
    z[0,4,3]  R542      -1.0958953201770782e-01
    z[0,4,3]  R543      -5.7549077272415161e-01
    z[0,4,3]  R544      -6.4081823825836182e-01
    z[0,4,3]  R545      -7.8058832883834839e-01
    z[0,4,3]  R546      -3.7057012319564819e-01
    z[0,4,3]  R547      -2.5731462240219116e-01
    z[0,4,3]  R548      -4.3485969305038452e-01
    z[0,4,3]  R549      -1.6012582182884216e-01
    z[0,4,3]  R550      -4.9854028224945068e-01
    z[0,4,3]  R551      -7.9492524266242981e-02
    z[0,4,3]  R552      -5.0890535116195679e-01
    z[0,4,3]  R553      -8.8081145286560059e-01
    z[0,4,3]  R554      -4.2453691363334656e-01
    z[0,4,3]  R555      -3.2612148206681013e-03
    z[0,4,3]  R556      -1.2856748700141907e-01
    z[0,4,3]  R557      -2.2663326561450958e-01
    z[0,4,3]  R558      -3.1684669852256775e-01
    z[0,4,3]  R559      -2.4551613628864288e-01
    z[0,4,3]  R560      -4.2878651618957520e-01
    z[0,4,3]  R561      -3.5192716121673584e-01
    z[0,4,3]  R562      -1.5286463499069214e-01
    z[0,4,3]  R563      -2.3285862803459167e-01
    z[0,4,3]  R564      -2.9592958092689514e-01
    z[0,4,3]  R565      -5.1247978210449219e-01
    z[0,4,3]  R566      -2.8405699133872986e-01
    z[0,4,3]  R567      -6.4373493194580078e-01
    z[0,4,3]  R568      -5.1336103677749634e-01
    z[0,4,3]  R569      4.4087516143918037e-03
    z[0,4,3]  R570      -2.9839882254600525e-01
    z[0,4,3]  R571      -3.8450336456298828e-01
    z[0,4,3]  R572      -7.4159407615661621e-01
    z[0,4,3]  R573      -5.9216845035552979e-01
    z[0,4,3]  R574      -5.4077637195587158e-01
    z[0,4,3]  R575      -5.8719825744628906e-01
    z[0,4,3]  R576      6.1623834073543549e-02
    z[0,4,3]  R577      1.2031611055135727e-01
    z[0,4,3]  R578      -1.0835071653127670e-01
    z[0,4,3]  R579      1.6698566079139709e-01
    z[0,4,3]  R580      -8.0087609589099884e-02
    z[0,4,3]  R581      5.4327648133039474e-02
    z[0,4,3]  R582      -5.7724362611770630e-01
    z[0,4,3]  R583      1.4700695872306824e-01
    z[0,4,3]  R584      1.0272392630577087e-01
    z[0,4,3]  R585      8.5961920022964478e-01
    z[0,4,3]  R586      -2.4001386761665344e-01
    z[0,4,3]  R587      1.8896806240081787e-01
    z[0,4,3]  R588      -0.388874351978302
    z[0,4,3]  R589      1.1385331302881241e-01
    z[0,4,3]  R590      3.0618848279118538e-02
    z[0,4,3]  R591      5.8276718854904175e-01
    z[0,4,3]  R592      -4.3951552361249924e-02
    z[0,4,3]  R593      3.5840559005737305e-01
    z[0,4,3]  R594      1.5175801515579224e-01
    z[0,4,3]  R595      1.3548615574836731e-01
    z[0,4,3]  R596      -7.3759861290454865e-02
    z[0,4,3]  R597      -6.4899915456771851e-01
    z[0,4,3]  R598      -3.1279709935188293e-01
    z[0,4,3]  R599      -6.1535632610321045e-01
    z[0,4,3]  R600      -2.5307220220565796e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R520      -1
    z[0,4,4]  R521      1
    z[0,4,4]  R526      2.0803251862525940e-01
    z[0,4,4]  R527      3.9895308017730713e-01
    z[0,4,4]  R528      6.8639880418777466e-01
    z[0,4,4]  R529      -1.8633824586868286e-01
    z[0,4,4]  R530      2.7008423209190369e-01
    z[0,4,4]  R531      5.9325951337814331e-01
    z[0,4,4]  R532      4.7902908921241760e-01
    z[0,4,4]  R533      -6.6358581185340881e-02
    z[0,4,4]  R534      -2.0199451595544815e-02
    z[0,4,4]  R535      -1.2824955582618713e-01
    z[0,4,4]  R536      1.6085259616374969e-01
    z[0,4,4]  R537      9.6290744841098785e-02
    z[0,4,4]  R538      8.1927612423896790e-02
    z[0,4,4]  R539      2.7232760563492775e-02
    z[0,4,4]  R540      0.0659303069114685
    z[0,4,4]  R541      8.7063927203416824e-03
    z[0,4,4]  R542      0.0533875934779644
    z[0,4,4]  R543      1.6697880346328020e-03
    z[0,4,4]  R544      1.6146497428417206e-01
    z[0,4,4]  R545      1.2368368357419968e-01
    z[0,4,4]  R546      -5.3862744569778442e-01
    z[0,4,4]  R547      -5.4176563024520874e-01
    z[0,4,4]  R548      -5.0976920127868652e-01
    z[0,4,4]  R549      -2.5783795118331909e-01
    z[0,4,4]  R550      -1.1714033037424088e-01
    z[0,4,4]  R551      -3.1877914071083069e-01
    z[0,4,4]  R552      -1.6955876350402832e-01
    z[0,4,4]  R553      1.3076600432395935e-01
    z[0,4,4]  R554      1.2937222421169281e-01
    z[0,4,4]  R555      4.5857262611389160e-01
    z[0,4,4]  R556      3.4120818972587585e-01
    z[0,4,4]  R557      0.211094930768013
    z[0,4,4]  R558      -4.1046679019927979e-01
    z[0,4,4]  R559      4.4615232944488525e-01
    z[0,4,4]  R560      -0.0840950757265091
    z[0,4,4]  R561      3.4334605932235718e-01
    z[0,4,4]  R562      3.3535476773977280e-02
    z[0,4,4]  R563      -3.0437481403350830e-01
    z[0,4,4]  R564      -1.1535321176052094e-01
    z[0,4,4]  R565      -3.9086338877677917e-01
    z[0,4,4]  R566      1.0599235445261002e-01
    z[0,4,4]  R567      2.1184180676937103e-01
    z[0,4,4]  R568      -5.6517404317855835e-01
    z[0,4,4]  R569      -2.3261284828186035e-01
    z[0,4,4]  R570      1.9529154896736145e-01
    z[0,4,4]  R571      5.4291152954101562e-01
    z[0,4,4]  R572      0.24967060983181
    z[0,4,4]  R573      2.8349167108535767e-01
    z[0,4,4]  R574      0.337802529335022
    z[0,4,4]  R575      -2.0766319334506989e-01
    z[0,4,4]  R576      9.6880055963993073e-02
    z[0,4,4]  R577      2.8017762303352356e-01
    z[0,4,4]  R578      -2.7349710464477539e-01
    z[0,4,4]  R579      1.7739698290824890e-01
    z[0,4,4]  R580      -2.9830446466803551e-02
    z[0,4,4]  R581      5.0163465738296509e-01
    z[0,4,4]  R582      -2.0905299112200737e-02
    z[0,4,4]  R583      9.0793631970882416e-02
    z[0,4,4]  R584      -4.2723834514617920e-01
    z[0,4,4]  R585      -3.7313145399093628e-01
    z[0,4,4]  R586      -2.1621921658515930e-01
    z[0,4,4]  R587      -9.6813194453716278e-02
    z[0,4,4]  R588      3.7031877040863037e-01
    z[0,4,4]  R589      6.5757364034652710e-02
    z[0,4,4]  R590      -2.7775904163718224e-02
    z[0,4,4]  R591      -1.0947525501251221e-01
    z[0,4,4]  R592      -1.0854104906320572e-01
    z[0,4,4]  R593      -2.5228586792945862e-01
    z[0,4,4]  R594      -6.6569441556930542e-01
    z[0,4,4]  R595      -1.9893574714660645e-01
    z[0,4,4]  R596      1.3082090020179749e-01
    z[0,4,4]  R597      3.8038212805986404e-02
    z[0,4,4]  R598      -6.0758739709854126e-01
    z[0,4,4]  R599      -1.3361072167754173e-02
    z[0,4,4]  R600      8.8092230260372162e-02
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R522      -1
    z[0,4,5]  R523      1
    z[0,4,5]  R526      -1.7219580709934235e-01
    z[0,4,5]  R527      2.3822224140167236e-01
    z[0,4,5]  R528      1.9614651799201965e-02
    z[0,4,5]  R529      0.0641963854432106
    z[0,4,5]  R530      4.8918804526329041e-01
    z[0,4,5]  R531      2.0010976493358612e-01
    z[0,4,5]  R532      -1.1677581816911697e-01
    z[0,4,5]  R533      -3.5132844001054764e-02
    z[0,4,5]  R534      4.7865319252014160e-01
    z[0,4,5]  R535      5.9817917644977570e-02
    z[0,4,5]  R536      1.4256587252020836e-02
    z[0,4,5]  R537      1.6425536572933197e-01
    z[0,4,5]  R538      4.2075820267200470e-02
    z[0,4,5]  R539      -2.7283641695976257e-01
    z[0,4,5]  R540      -2.0761951804161072e-01
    z[0,4,5]  R541      -1.8142138421535492e-01
    z[0,4,5]  R542      -3.7135985493659973e-01
    z[0,4,5]  R543      3.3311226963996887e-01
    z[0,4,5]  R544      3.7047511339187622e-01
    z[0,4,5]  R545      1.9655074179172516e-01
    z[0,4,5]  R546      -3.2391062378883362e-01
    z[0,4,5]  R547      5.6745093315839767e-02
    z[0,4,5]  R548      -3.7993314862251282e-01
    z[0,4,5]  R549      -0.797989010810852
    z[0,4,5]  R550      -4.8231646418571472e-02
    z[0,4,5]  R551      -5.9691596031188965e-01
    z[0,4,5]  R552      6.5028136968612671e-01
    z[0,4,5]  R553      -1.1769316345453262e-01
    z[0,4,5]  R554      -2.3316852748394012e-01
    z[0,4,5]  R555      -1.7426036298274994e-01
    z[0,4,5]  R556      -1.2134513258934021e-01
    z[0,4,5]  R557      2.3063777387142181e-01
    z[0,4,5]  R558      5.9574604034423828e-02
    z[0,4,5]  R559      -1.6570739448070526e-01
    z[0,4,5]  R560      -4.6456447243690491e-01
    z[0,4,5]  R561      -3.1672635674476624e-01
    z[0,4,5]  R562      -3.7973642349243164e-01
    z[0,4,5]  R563      -3.3005043864250183e-01
    z[0,4,5]  R564      -2.9810637235641479e-01
    z[0,4,5]  R565      -3.1139656901359558e-01
    z[0,4,5]  R566      3.1805828213691711e-02
    z[0,4,5]  R567      -1.6592605412006378e-01
    z[0,4,5]  R568      1.3772073388099670e-01
    z[0,4,5]  R569      -1.1653266102075577e-01
    z[0,4,5]  R570      6.6004401445388794e-01
    z[0,4,5]  R571      -3.7099716067314148e-01
    z[0,4,5]  R572      -1.2369011342525482e-01
    z[0,4,5]  R573      1.6217152774333954e-01
    z[0,4,5]  R574      7.5873308815062046e-03
    z[0,4,5]  R575      -6.8098619580268860e-02
    z[0,4,5]  R576      -3.8344261050224304e-01
    z[0,4,5]  R577      -2.4632996320724487e-01
    z[0,4,5]  R578      -4.6027606725692749e-01
    z[0,4,5]  R579      7.6073859818279743e-03
    z[0,4,5]  R580      -1.3433896005153656e-01
    z[0,4,5]  R581      1.5455786883831024e-01
    z[0,4,5]  R582      -2.7092182636260986e-01
    z[0,4,5]  R583      7.6671266555786133e-01
    z[0,4,5]  R584      2.8965758159756660e-02
    z[0,4,5]  R585      -1.5829353034496307e-01
    z[0,4,5]  R586      -4.2344415187835693e-01
    z[0,4,5]  R587      -3.0616271495819092e-01
    z[0,4,5]  R588      -5.2750091999769211e-02
    z[0,4,5]  R589      -8.3749219775199890e-02
    z[0,4,5]  R590      3.5495933890342712e-01
    z[0,4,5]  R591      2.2453854978084564e-01
    z[0,4,5]  R592      1.8640884757041931e-01
    z[0,4,5]  R593      -7.0749111473560333e-02
    z[0,4,5]  R594      2.3678185045719147e-01
    z[0,4,5]  R595      3.0017700791358948e-01
    z[0,4,5]  R596      4.8381257057189941e-01
    z[0,4,5]  R597      3.3239677548408508e-01
    z[0,4,5]  R598      1.4385271072387695e-01
    z[0,4,5]  R599      2.0954367518424988e-01
    z[0,4,5]  R600      2.6355904340744019e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R524      -1
    z[0,4,6]  R525      1
    z[0,4,6]  R526      -3.5443242639303207e-02
    z[0,4,6]  R527      2.4797075986862183e-01
    z[0,4,6]  R528      -2.2168788313865662e-01
    z[0,4,6]  R529      -5.1924586296081543e-01
    z[0,4,6]  R530      -3.3369296789169312e-01
    z[0,4,6]  R531      -1.2417459487915039e-01
    z[0,4,6]  R532      -6.0502439737319946e-01
    z[0,4,6]  R533      -5.2315002679824829e-01
    z[0,4,6]  R534      -1.2507562339305878e-01
    z[0,4,6]  R535      2.4796277284622192e-01
    z[0,4,6]  R536      3.7377856671810150e-02
    z[0,4,6]  R537      -1.4497044682502747e-01
    z[0,4,6]  R538      -1.1728186905384064e-01
    z[0,4,6]  R539      -3.1991973519325256e-01
    z[0,4,6]  R540      -3.9871972799301147e-01
    z[0,4,6]  R541      -8.2211859524250031e-02
    z[0,4,6]  R542      -1.7676997184753418e-01
    z[0,4,6]  R543      4.8522818833589554e-02
    z[0,4,6]  R544      -6.2796503305435181e-02
    z[0,4,6]  R545      1.3915172778069973e-02
    z[0,4,6]  R546      3.0732309818267822e-01
    z[0,4,6]  R547      -1.7523214221000671e-01
    z[0,4,6]  R548      -1.7877882719039917e-01
    z[0,4,6]  R549      8.4513023495674133e-02
    z[0,4,6]  R550      6.6309428215026855e-01
    z[0,4,6]  R551      -2.1336279809474945e-02
    z[0,4,6]  R552      -2.5314772501587868e-02
    z[0,4,6]  R553      -2.4357235431671143e-01
    z[0,4,6]  R554      5.4480004310607910e-01
    z[0,4,6]  R555      2.2703976929187775e-01
    z[0,4,6]  R556      8.5677430033683777e-02
    z[0,4,6]  R557      -4.4246405363082886e-01
    z[0,4,6]  R558      5.7593584060668945e-02
    z[0,4,6]  R559      -2.5925964117050171e-01
    z[0,4,6]  R560      2.0709633827209473e-02
    z[0,4,6]  R561      -3.3967521786689758e-01
    z[0,4,6]  R562      -2.0554545521736145e-01
    z[0,4,6]  R563      -3.3647686243057251e-01
    z[0,4,6]  R564      5.7713504880666733e-02
    z[0,4,6]  R565      -3.1497564911842346e-01
    z[0,4,6]  R566      0.294825941324234
    z[0,4,6]  R567      1.3202600181102753e-01
    z[0,4,6]  R568      -0.479687362909317
    z[0,4,6]  R569      -5.3044372797012329e-01
    z[0,4,6]  R570      0.414413183927536
    z[0,4,6]  R571      2.2989781200885773e-01
    z[0,4,6]  R572      -7.8625408932566643e-03
    z[0,4,6]  R573      -6.0115452855825424e-02
    z[0,4,6]  R574      -3.7666597962379456e-01
    z[0,4,6]  R575      -2.3704078793525696e-01
    z[0,4,6]  R576      2.9716029763221741e-01
    z[0,4,6]  R577      -3.8691893219947815e-01
    z[0,4,6]  R578      -3.4699544310569763e-01
    z[0,4,6]  R579      9.0068168938159943e-02
    z[0,4,6]  R580      -3.7443239241838455e-02
    z[0,4,6]  R581      -0.259909987449646
    z[0,4,6]  R582      -5.0366961956024170e-01
    z[0,4,6]  R583      4.6736735850572586e-02
    z[0,4,6]  R584      -1.0265648597851396e-03
    z[0,4,6]  R585      -1.0762225091457367e-01
    z[0,4,6]  R586      0.0696331113576889
    z[0,4,6]  R587      3.1715276837348938e-01
    z[0,4,6]  R588      2.2725264728069305e-01
    z[0,4,6]  R589      -4.8621557652950287e-02
    z[0,4,6]  R590      5.8099544048309326e-01
    z[0,4,6]  R591      7.2574146091938019e-02
    z[0,4,6]  R592      -2.1973720192909241e-01
    z[0,4,6]  R593      -4.7050568461418152e-01
    z[0,4,6]  R594      -7.0633783936500549e-02
    z[0,4,6]  R595      0.336056649684906
    z[0,4,6]  R596      -3.7884730100631714e-01
    z[0,4,6]  R597      3.8792282342910767e-01
    z[0,4,6]  R598      4.8093879222869873e-01
    z[0,4,6]  R599      -2.1727073192596436e-01
    z[0,4,6]  R600      2.2801366448402405e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R601      -1
    z[4,0,0]  R602      1
    z[4,0,0]  R615      -4.4537249207496643e-01
    z[4,0,0]  R616      -5.1074630022048950e-01
    z[4,0,0]  R617      -5.2198320627212524e-01
    z[4,0,0]  R618      1.4921683818101883e-02
    z[4,0,0]  R619      -9.6592712402343750e-01
    z[4,0,0]  R620      8.0585852265357971e-02
    z[4,0,0]  R621      -1.7927173525094986e-02
    z[4,0,0]  R622      3.2609567046165466e-02
    z[4,0,0]  R623      -2.4398061633110046e-01
    z[4,0,0]  R624      -1.0867832228541374e-02
    z[4,0,0]  R625      0.331209659576416
    z[4,0,0]  R626      3.7573602795600891e-01
    z[4,0,0]  R627      4.9842461943626404e-01
    z[4,0,0]  R628      3.3839711546897888e-01
    z[4,0,0]  R629      3.7496492266654968e-01
    z[4,0,0]  R630      3.4600558876991272e-01
    z[4,0,0]  R631      2.5181302428245544e-01
    z[4,0,0]  R632      1.5387284755706787e-01
    z[4,0,0]  R633      3.2433813810348511e-01
    z[4,0,0]  R634      2.0987780392169952e-01
    z[4,0,0]  R635      2.4177080392837524e-01
    z[4,0,0]  R636      -1.7149411141872406e-01
    z[4,0,0]  R637      -1.1276394070591778e-04
    z[4,0,0]  R638      0.299360454082489
    z[4,0,0]  R639      1.8625383079051971e-01
    z[4,0,0]  R640      -2.6278007775545120e-02
    z[4,0,0]  R641      -4.2707573622465134e-02
    z[4,0,0]  R642      -0.0056025180965662
    z[4,0,0]  R643      1.6768096014857292e-02
    z[4,0,0]  R644      5.5906623601913452e-03
    z[4,0,0]  R645      -9.9510475993156433e-02
    z[4,0,0]  R646      -6.3157521188259125e-02
    z[4,0,0]  R647      -6.6990047693252563e-02
    z[4,0,0]  R648      -7.5816698372364044e-02
    z[4,0,0]  R649      -4.7269638627767563e-02
    z[4,0,0]  R650      -0.555316150188446
    z[4,0,0]  R651      -7.0947378873825073e-01
    z[4,0,0]  R652      -6.7712688446044922e-01
    z[4,0,0]  R653      -0.62241530418396
    z[4,0,0]  R654      -0.710087239742279
    z[4,0,0]  R655      -6.6775500774383545e-01
    z[4,0,0]  R656      -6.1131346225738525e-01
    z[4,0,0]  R657      3.5818746685981750e-01
    z[4,0,0]  R658      7.2382472455501556e-02
    z[4,0,0]  R659      5.6864868849515915e-02
    z[4,0,0]  R660      6.4676970243453979e-02
    z[4,0,0]  R661      1.6652202606201172e-01
    z[4,0,0]  R662      1.4591804705560207e-02
    z[4,0,0]  R663      -9.5617817714810371e-03
    z[4,0,0]  R664      3.4006796777248383e-02
    z[4,0,0]  R665      6.6367626190185547e-02
    z[4,0,0]  R666      5.7422742247581482e-02
    z[4,0,0]  R667      8.6606591939926147e-02
    z[4,0,0]  R668      2.1507395803928375e-01
    z[4,0,0]  R669      9.0440668165683746e-02
    z[4,0,0]  R670      2.0449422299861908e-01
    z[4,0,0]  R671      2.0686280727386475e-01
    z[4,0,0]  R672      2.2820815443992615e-01
    z[4,0,0]  R673      -2.2142000496387482e-01
    z[4,0,0]  R674      1.7293131351470947e-01
    z[4,0,0]  R675      -1.1373347789049149e-01
    z[4,0,0]  R676      -2.9333535581827164e-02
    z[4,0,0]  R677      2.8769636154174805e-01
    z[4,0,0]  R678      3.0418558046221733e-02
    z[4,0,0]  R679      1.0800819098949432e-01
    z[4,0,0]  R680      2.5768694281578064e-01
    z[4,0,0]  R681      -2.1849863231182098e-01
    z[4,0,0]  R682      2.1326501667499542e-01
    z[4,0,0]  R683      2.0236921310424805e-01
    z[4,0,0]  R684      -2.6784273982048035e-01
    z[4,0,0]  R685      -3.9492547512054443e-01
    z[4,0,0]  R686      -0.580073893070221
    z[4,0,0]  R687      -6.3610792160034180e-01
    z[4,0,0]  R688      -6.5275895595550537e-01
    z[4,0,0]  R689      -5.3577989339828491e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R603      -1
    z[4,0,1]  R604      1
    z[4,0,1]  R615      0.665277361869812
    z[4,0,1]  R616      5.7158994674682617e-01
    z[4,0,1]  R617      4.0337088704109192e-01
    z[4,0,1]  R618      7.5647455453872681e-01
    z[4,0,1]  R619      7.8719764947891235e-02
    z[4,0,1]  R620      -6.6353100538253784e-01
    z[4,0,1]  R621      -5.6738960742950439e-01
    z[4,0,1]  R622      -0.539656400680542
    z[4,0,1]  R623      -7.3659688234329224e-01
    z[4,0,1]  R624      2.8826889395713806e-01
    z[4,0,1]  R625      -7.7573865652084351e-01
    z[4,0,1]  R626      -7.6019245386123657e-01
    z[4,0,1]  R627      -6.0532516241073608e-01
    z[4,0,1]  R628      -7.0515912771224976e-01
    z[4,0,1]  R629      -6.2775951623916626e-01
    z[4,0,1]  R630      -6.5205973386764526e-01
    z[4,0,1]  R631      -7.5500094890594482e-01
    z[4,0,1]  R632      -0.685711681842804
    z[4,0,1]  R633      -5.7793557643890381e-01
    z[4,0,1]  R634      -6.6598445177078247e-01
    z[4,0,1]  R635      -6.6299033164978027e-01
    z[4,0,1]  R636      2.1881558932363987e-03
    z[4,0,1]  R637      1.9273987039923668e-02
    z[4,0,1]  R638      5.7013678550720215e-01
    z[4,0,1]  R639      6.1896014213562012e-01
    z[4,0,1]  R640      -3.9014759659767151e-01
    z[4,0,1]  R641      -5.9952753782272339e-01
    z[4,0,1]  R642      -4.1370350122451782e-01
    z[4,0,1]  R643      -2.5708726048469543e-01
    z[4,0,1]  R644      -3.6687496304512024e-01
    z[4,0,1]  R645      -7.6284235715866089e-01
    z[4,0,1]  R646      -4.1863659024238586e-01
    z[4,0,1]  R647      -3.6757844686508179e-01
    z[4,0,1]  R648      -2.4931827187538147e-01
    z[4,0,1]  R649      -1.5829999744892120e-01
    z[4,0,1]  R650      7.9764628410339355e-01
    z[4,0,1]  R651      6.5807652473449707e-01
    z[4,0,1]  R652      6.1631280183792114e-01
    z[4,0,1]  R653      6.3527208566665649e-01
    z[4,0,1]  R654      5.2518397569656372e-01
    z[4,0,1]  R655      6.4900523424148560e-01
    z[4,0,1]  R656      6.0841131210327148e-01
    z[4,0,1]  R657      6.5025252103805542e-01
    z[4,0,1]  R658      6.4068323373794556e-01
    z[4,0,1]  R659      5.7729250192642212e-01
    z[4,0,1]  R660      -6.0613876581192017e-01
    z[4,0,1]  R661      -6.8577939271926880e-01
    z[4,0,1]  R662      -5.5342102050781250e-01
    z[4,0,1]  R663      -5.1002883911132812e-01
    z[4,0,1]  R664      -5.4270356893539429e-01
    z[4,0,1]  R665      -5.3589272499084473e-01
    z[4,0,1]  R666      -4.9461242556571960e-01
    z[4,0,1]  R667      -2.9641568660736084e-01
    z[4,0,1]  R668      6.2931948900222778e-01
    z[4,0,1]  R669      8.3574044704437256e-01
    z[4,0,1]  R670      8.9154487848281860e-01
    z[4,0,1]  R671      7.2135615348815918e-01
    z[4,0,1]  R672      6.6799086332321167e-01
    z[4,0,1]  R673      7.7263295650482178e-01
    z[4,0,1]  R674      7.4710875749588013e-01
    z[4,0,1]  R675      6.6347837448120117e-01
    z[4,0,1]  R676      8.7388777732849121e-01
    z[4,0,1]  R677      7.2716957330703735e-01
    z[4,0,1]  R678      0.818784773349762
    z[4,0,1]  R679      6.1233907938003540e-01
    z[4,0,1]  R680      8.4183776378631592e-01
    z[4,0,1]  R681      2.5647976994514465e-01
    z[4,0,1]  R682      3.4914711117744446e-01
    z[4,0,1]  R683      7.8099715709686279e-01
    z[4,0,1]  R684      2.5958302617073059e-01
    z[4,0,1]  R685      4.4278222322463989e-01
    z[4,0,1]  R686      -4.0670629590749741e-02
    z[4,0,1]  R687      -1.3200253248214722e-01
    z[4,0,1]  R688      6.7387841641902924e-02
    z[4,0,1]  R689      -2.2673592902719975e-03
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R605      -1
    z[4,0,2]  R606      1
    z[4,0,2]  R615      -3.3246603608131409e-01
    z[4,0,2]  R616      -3.3024686574935913e-01
    z[4,0,2]  R617      -3.8213226199150085e-01
    z[4,0,2]  R618      -5.9999954700469971e-01
    z[4,0,2]  R619      -1.8448592722415924e-01
    z[4,0,2]  R620      4.5519477128982544e-01
    z[4,0,2]  R621      -1.3045579195022583e-01
    z[4,0,2]  R622      -2.9634529352188110e-01
    z[4,0,2]  R623      4.5163431763648987e-01
    z[4,0,2]  R624      0.0443992018699646
    z[4,0,2]  R625      4.3069524690508842e-03
    z[4,0,2]  R626      -2.0378093421459198e-01
    z[4,0,2]  R627      -2.0583665370941162e-01
    z[4,0,2]  R628      -0.601309597492218
    z[4,0,2]  R629      7.6408926397562027e-03
    z[4,0,2]  R630      -2.1865795552730560e-01
    z[4,0,2]  R631      -5.1944029331207275e-01
    z[4,0,2]  R632      2.9603847861289978e-01
    z[4,0,2]  R633      -1.8319685757160187e-01
    z[4,0,2]  R634      5.0144165754318237e-01
    z[4,0,2]  R635      3.1911796331405640e-01
    z[4,0,2]  R636      -5.3569239377975464e-01
    z[4,0,2]  R637      -5.2974373102188110e-01
    z[4,0,2]  R638      3.3966198563575745e-01
    z[4,0,2]  R639      6.2364935874938965e-01
    z[4,0,2]  R640      4.9154743552207947e-01
    z[4,0,2]  R641      -1.9268995523452759e-01
    z[4,0,2]  R642      5.1938217878341675e-01
    z[4,0,2]  R643      0.336774617433548
    z[4,0,2]  R644      -5.0238844007253647e-02
    z[4,0,2]  R645      1.9185375422239304e-02
    z[4,0,2]  R646      3.4803774952888489e-01
    z[4,0,2]  R647      7.6155656576156616e-01
    z[4,0,2]  R648      8.2272779941558838e-01
    z[4,0,2]  R649      9.4390004873275757e-01
    z[4,0,2]  R650      -1.6586931049823761e-01
    z[4,0,2]  R651      -3.7797506898641586e-02
    z[4,0,2]  R652      -1.0418660193681717e-01
    z[4,0,2]  R653      -1.2782895565032959e-01
    z[4,0,2]  R654      -5.8416366577148438e-02
    z[4,0,2]  R655      1.8231441080570221e-01
    z[4,0,2]  R656      2.6854345202445984e-01
    z[4,0,2]  R657      -6.6050738096237183e-02
    z[4,0,2]  R658      0.0798223614692688
    z[4,0,2]  R659      7.6353847980499268e-03
    z[4,0,2]  R660      -4.0066473186016083e-02
    z[4,0,2]  R661      -3.2913509011268616e-01
    z[4,0,2]  R662      -2.6121556758880615e-01
    z[4,0,2]  R663      -6.1069771647453308e-02
    z[4,0,2]  R664      -5.6354599073529243e-03
    z[4,0,2]  R665      -4.9367120862007141e-01
    z[4,0,2]  R666      2.0203870534896851e-01
    z[4,0,2]  R667      1.9628894329071045e-01
    z[4,0,2]  R668      9.7759254276752472e-02
    z[4,0,2]  R669      3.3839073032140732e-02
    z[4,0,2]  R670      -0.0911693274974823
    z[4,0,2]  R671      -3.0325099825859070e-01
    z[4,0,2]  R672      0.475361168384552
    z[4,0,2]  R673      -2.6377236936241388e-03
    z[4,0,2]  R674      -6.8879820406436920e-02
    z[4,0,2]  R675      -2.9904362559318542e-01
    z[4,0,2]  R676      1.5658490359783173e-01
    z[4,0,2]  R677      -1.3942076265811920e-01
    z[4,0,2]  R678      3.6822181940078735e-01
    z[4,0,2]  R679      4.2282842099666595e-02
    z[4,0,2]  R680      2.1224968135356903e-01
    z[4,0,2]  R681      -6.1825770139694214e-01
    z[4,0,2]  R682      2.4210287258028984e-02
    z[4,0,2]  R683      3.3962861634790897e-03
    z[4,0,2]  R684      -3.5538685321807861e-01
    z[4,0,2]  R685      1.2202516198158264e-01
    z[4,0,2]  R686      1.8493738770484924e-01
    z[4,0,2]  R687      3.4204912185668945e-01
    z[4,0,2]  R688      1.4449992775917053e-01
    z[4,0,2]  R689      5.1398748159408569e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R607      -1
    z[4,0,3]  R608      1
    z[4,0,3]  R615      6.1623834073543549e-02
    z[4,0,3]  R616      1.2031611055135727e-01
    z[4,0,3]  R617      -1.0835071653127670e-01
    z[4,0,3]  R618      1.6698566079139709e-01
    z[4,0,3]  R619      -8.0087609589099884e-02
    z[4,0,3]  R620      5.4327648133039474e-02
    z[4,0,3]  R621      -5.7724362611770630e-01
    z[4,0,3]  R622      1.4700695872306824e-01
    z[4,0,3]  R623      1.0272392630577087e-01
    z[4,0,3]  R624      8.5961920022964478e-01
    z[4,0,3]  R625      -2.4001386761665344e-01
    z[4,0,3]  R626      1.8896806240081787e-01
    z[4,0,3]  R627      -0.388874351978302
    z[4,0,3]  R628      1.1385331302881241e-01
    z[4,0,3]  R629      3.0618848279118538e-02
    z[4,0,3]  R630      5.8276718854904175e-01
    z[4,0,3]  R631      -4.3951552361249924e-02
    z[4,0,3]  R632      3.5840559005737305e-01
    z[4,0,3]  R633      1.5175801515579224e-01
    z[4,0,3]  R634      1.3548615574836731e-01
    z[4,0,3]  R635      -7.3759861290454865e-02
    z[4,0,3]  R636      -6.4899915456771851e-01
    z[4,0,3]  R637      -3.1279709935188293e-01
    z[4,0,3]  R638      -6.1535632610321045e-01
    z[4,0,3]  R639      -2.5307220220565796e-01
    z[4,0,3]  R640      7.2889661788940430e-01
    z[4,0,3]  R641      5.6939494609832764e-01
    z[4,0,3]  R642      1.9592465460300446e-01
    z[4,0,3]  R643      7.1536588668823242e-01
    z[4,0,3]  R644      6.6275650262832642e-01
    z[4,0,3]  R645      1.9517024978995323e-02
    z[4,0,3]  R646      3.0077275633811951e-01
    z[4,0,3]  R647      3.3261362463235855e-02
    z[4,0,3]  R648      1.0025146603584290e-01
    z[4,0,3]  R649      1.5744503587484360e-02
    z[4,0,3]  R650      -1.9945492967963219e-02
    z[4,0,3]  R651      -6.9894500076770782e-02
    z[4,0,3]  R652      -3.5856020450592041e-01
    z[4,0,3]  R653      1.2311906367540359e-01
    z[4,0,3]  R654      -1.0057487338781357e-01
    z[4,0,3]  R655      2.4476251006126404e-01
    z[4,0,3]  R656      -1.0958953201770782e-01
    z[4,0,3]  R657      -5.7549077272415161e-01
    z[4,0,3]  R658      -6.4081823825836182e-01
    z[4,0,3]  R659      -7.8058832883834839e-01
    z[4,0,3]  R660      -3.7057012319564819e-01
    z[4,0,3]  R661      -2.5731462240219116e-01
    z[4,0,3]  R662      -4.3485969305038452e-01
    z[4,0,3]  R663      -1.6012582182884216e-01
    z[4,0,3]  R664      -4.9854028224945068e-01
    z[4,0,3]  R665      -7.9492524266242981e-02
    z[4,0,3]  R666      -5.0890535116195679e-01
    z[4,0,3]  R667      -8.8081145286560059e-01
    z[4,0,3]  R668      -4.2453691363334656e-01
    z[4,0,3]  R669      -3.2612148206681013e-03
    z[4,0,3]  R670      -1.2856748700141907e-01
    z[4,0,3]  R671      -2.2663326561450958e-01
    z[4,0,3]  R672      -3.1684669852256775e-01
    z[4,0,3]  R673      -2.4551613628864288e-01
    z[4,0,3]  R674      -4.2878651618957520e-01
    z[4,0,3]  R675      -3.5192716121673584e-01
    z[4,0,3]  R676      -1.5286463499069214e-01
    z[4,0,3]  R677      -2.3285862803459167e-01
    z[4,0,3]  R678      -2.9592958092689514e-01
    z[4,0,3]  R679      -5.1247978210449219e-01
    z[4,0,3]  R680      -2.8405699133872986e-01
    z[4,0,3]  R681      -6.4373493194580078e-01
    z[4,0,3]  R682      -5.1336103677749634e-01
    z[4,0,3]  R683      4.4087516143918037e-03
    z[4,0,3]  R684      -2.9839882254600525e-01
    z[4,0,3]  R685      -3.8450336456298828e-01
    z[4,0,3]  R686      -7.4159407615661621e-01
    z[4,0,3]  R687      -5.9216845035552979e-01
    z[4,0,3]  R688      -5.4077637195587158e-01
    z[4,0,3]  R689      -5.8719825744628906e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R609      -1
    z[4,0,4]  R610      1
    z[4,0,4]  R615      9.6880055963993073e-02
    z[4,0,4]  R616      2.8017762303352356e-01
    z[4,0,4]  R617      -2.7349710464477539e-01
    z[4,0,4]  R618      1.7739698290824890e-01
    z[4,0,4]  R619      -2.9830446466803551e-02
    z[4,0,4]  R620      5.0163465738296509e-01
    z[4,0,4]  R621      -2.0905299112200737e-02
    z[4,0,4]  R622      9.0793631970882416e-02
    z[4,0,4]  R623      -4.2723834514617920e-01
    z[4,0,4]  R624      -3.7313145399093628e-01
    z[4,0,4]  R625      -2.1621921658515930e-01
    z[4,0,4]  R626      -9.6813194453716278e-02
    z[4,0,4]  R627      3.7031877040863037e-01
    z[4,0,4]  R628      6.5757364034652710e-02
    z[4,0,4]  R629      -2.7775904163718224e-02
    z[4,0,4]  R630      -1.0947525501251221e-01
    z[4,0,4]  R631      -1.0854104906320572e-01
    z[4,0,4]  R632      -2.5228586792945862e-01
    z[4,0,4]  R633      -6.6569441556930542e-01
    z[4,0,4]  R634      -1.9893574714660645e-01
    z[4,0,4]  R635      1.3082090020179749e-01
    z[4,0,4]  R636      3.8038212805986404e-02
    z[4,0,4]  R637      -6.0758739709854126e-01
    z[4,0,4]  R638      -1.3361072167754173e-02
    z[4,0,4]  R639      8.8092230260372162e-02
    z[4,0,4]  R640      2.0803251862525940e-01
    z[4,0,4]  R641      3.9895308017730713e-01
    z[4,0,4]  R642      6.8639880418777466e-01
    z[4,0,4]  R643      -1.8633824586868286e-01
    z[4,0,4]  R644      2.7008423209190369e-01
    z[4,0,4]  R645      5.9325951337814331e-01
    z[4,0,4]  R646      4.7902908921241760e-01
    z[4,0,4]  R647      -6.6358581185340881e-02
    z[4,0,4]  R648      -2.0199451595544815e-02
    z[4,0,4]  R649      -1.2824955582618713e-01
    z[4,0,4]  R650      1.6085259616374969e-01
    z[4,0,4]  R651      9.6290744841098785e-02
    z[4,0,4]  R652      8.1927612423896790e-02
    z[4,0,4]  R653      2.7232760563492775e-02
    z[4,0,4]  R654      0.0659303069114685
    z[4,0,4]  R655      8.7063927203416824e-03
    z[4,0,4]  R656      0.0533875934779644
    z[4,0,4]  R657      1.6697880346328020e-03
    z[4,0,4]  R658      1.6146497428417206e-01
    z[4,0,4]  R659      1.2368368357419968e-01
    z[4,0,4]  R660      -5.3862744569778442e-01
    z[4,0,4]  R661      -5.4176563024520874e-01
    z[4,0,4]  R662      -5.0976920127868652e-01
    z[4,0,4]  R663      -2.5783795118331909e-01
    z[4,0,4]  R664      -1.1714033037424088e-01
    z[4,0,4]  R665      -3.1877914071083069e-01
    z[4,0,4]  R666      -1.6955876350402832e-01
    z[4,0,4]  R667      1.3076600432395935e-01
    z[4,0,4]  R668      1.2937222421169281e-01
    z[4,0,4]  R669      4.5857262611389160e-01
    z[4,0,4]  R670      3.4120818972587585e-01
    z[4,0,4]  R671      0.211094930768013
    z[4,0,4]  R672      -4.1046679019927979e-01
    z[4,0,4]  R673      4.4615232944488525e-01
    z[4,0,4]  R674      -0.0840950757265091
    z[4,0,4]  R675      3.4334605932235718e-01
    z[4,0,4]  R676      3.3535476773977280e-02
    z[4,0,4]  R677      -3.0437481403350830e-01
    z[4,0,4]  R678      -1.1535321176052094e-01
    z[4,0,4]  R679      -3.9086338877677917e-01
    z[4,0,4]  R680      1.0599235445261002e-01
    z[4,0,4]  R681      2.1184180676937103e-01
    z[4,0,4]  R682      -5.6517404317855835e-01
    z[4,0,4]  R683      -2.3261284828186035e-01
    z[4,0,4]  R684      1.9529154896736145e-01
    z[4,0,4]  R685      5.4291152954101562e-01
    z[4,0,4]  R686      0.24967060983181
    z[4,0,4]  R687      2.8349167108535767e-01
    z[4,0,4]  R688      0.337802529335022
    z[4,0,4]  R689      -2.0766319334506989e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R611      -1
    z[4,0,5]  R612      1
    z[4,0,5]  R615      -3.8344261050224304e-01
    z[4,0,5]  R616      -2.4632996320724487e-01
    z[4,0,5]  R617      -4.6027606725692749e-01
    z[4,0,5]  R618      7.6073859818279743e-03
    z[4,0,5]  R619      -1.3433896005153656e-01
    z[4,0,5]  R620      1.5455786883831024e-01
    z[4,0,5]  R621      -2.7092182636260986e-01
    z[4,0,5]  R622      7.6671266555786133e-01
    z[4,0,5]  R623      2.8965758159756660e-02
    z[4,0,5]  R624      -1.5829353034496307e-01
    z[4,0,5]  R625      -4.2344415187835693e-01
    z[4,0,5]  R626      -3.0616271495819092e-01
    z[4,0,5]  R627      -5.2750091999769211e-02
    z[4,0,5]  R628      -8.3749219775199890e-02
    z[4,0,5]  R629      3.5495933890342712e-01
    z[4,0,5]  R630      2.2453854978084564e-01
    z[4,0,5]  R631      1.8640884757041931e-01
    z[4,0,5]  R632      -7.0749111473560333e-02
    z[4,0,5]  R633      2.3678185045719147e-01
    z[4,0,5]  R634      3.0017700791358948e-01
    z[4,0,5]  R635      4.8381257057189941e-01
    z[4,0,5]  R636      3.3239677548408508e-01
    z[4,0,5]  R637      1.4385271072387695e-01
    z[4,0,5]  R638      2.0954367518424988e-01
    z[4,0,5]  R639      2.6355904340744019e-01
    z[4,0,5]  R640      -1.7219580709934235e-01
    z[4,0,5]  R641      2.3822224140167236e-01
    z[4,0,5]  R642      1.9614651799201965e-02
    z[4,0,5]  R643      0.0641963854432106
    z[4,0,5]  R644      4.8918804526329041e-01
    z[4,0,5]  R645      2.0010976493358612e-01
    z[4,0,5]  R646      -1.1677581816911697e-01
    z[4,0,5]  R647      -3.5132844001054764e-02
    z[4,0,5]  R648      4.7865319252014160e-01
    z[4,0,5]  R649      5.9817917644977570e-02
    z[4,0,5]  R650      1.4256587252020836e-02
    z[4,0,5]  R651      1.6425536572933197e-01
    z[4,0,5]  R652      4.2075820267200470e-02
    z[4,0,5]  R653      -2.7283641695976257e-01
    z[4,0,5]  R654      -2.0761951804161072e-01
    z[4,0,5]  R655      -1.8142138421535492e-01
    z[4,0,5]  R656      -3.7135985493659973e-01
    z[4,0,5]  R657      3.3311226963996887e-01
    z[4,0,5]  R658      3.7047511339187622e-01
    z[4,0,5]  R659      1.9655074179172516e-01
    z[4,0,5]  R660      -3.2391062378883362e-01
    z[4,0,5]  R661      5.6745093315839767e-02
    z[4,0,5]  R662      -3.7993314862251282e-01
    z[4,0,5]  R663      -0.797989010810852
    z[4,0,5]  R664      -4.8231646418571472e-02
    z[4,0,5]  R665      -5.9691596031188965e-01
    z[4,0,5]  R666      6.5028136968612671e-01
    z[4,0,5]  R667      -1.1769316345453262e-01
    z[4,0,5]  R668      -2.3316852748394012e-01
    z[4,0,5]  R669      -1.7426036298274994e-01
    z[4,0,5]  R670      -1.2134513258934021e-01
    z[4,0,5]  R671      2.3063777387142181e-01
    z[4,0,5]  R672      5.9574604034423828e-02
    z[4,0,5]  R673      -1.6570739448070526e-01
    z[4,0,5]  R674      -4.6456447243690491e-01
    z[4,0,5]  R675      -3.1672635674476624e-01
    z[4,0,5]  R676      -3.7973642349243164e-01
    z[4,0,5]  R677      -3.3005043864250183e-01
    z[4,0,5]  R678      -2.9810637235641479e-01
    z[4,0,5]  R679      -3.1139656901359558e-01
    z[4,0,5]  R680      3.1805828213691711e-02
    z[4,0,5]  R681      -1.6592605412006378e-01
    z[4,0,5]  R682      1.3772073388099670e-01
    z[4,0,5]  R683      -1.1653266102075577e-01
    z[4,0,5]  R684      6.6004401445388794e-01
    z[4,0,5]  R685      -3.7099716067314148e-01
    z[4,0,5]  R686      -1.2369011342525482e-01
    z[4,0,5]  R687      1.6217152774333954e-01
    z[4,0,5]  R688      7.5873308815062046e-03
    z[4,0,5]  R689      -6.8098619580268860e-02
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R613      -1
    z[4,0,6]  R614      1
    z[4,0,6]  R615      2.9716029763221741e-01
    z[4,0,6]  R616      -3.8691893219947815e-01
    z[4,0,6]  R617      -3.4699544310569763e-01
    z[4,0,6]  R618      9.0068168938159943e-02
    z[4,0,6]  R619      -3.7443239241838455e-02
    z[4,0,6]  R620      -0.259909987449646
    z[4,0,6]  R621      -5.0366961956024170e-01
    z[4,0,6]  R622      4.6736735850572586e-02
    z[4,0,6]  R623      -1.0265648597851396e-03
    z[4,0,6]  R624      -1.0762225091457367e-01
    z[4,0,6]  R625      0.0696331113576889
    z[4,0,6]  R626      3.1715276837348938e-01
    z[4,0,6]  R627      2.2725264728069305e-01
    z[4,0,6]  R628      -4.8621557652950287e-02
    z[4,0,6]  R629      5.8099544048309326e-01
    z[4,0,6]  R630      7.2574146091938019e-02
    z[4,0,6]  R631      -2.1973720192909241e-01
    z[4,0,6]  R632      -4.7050568461418152e-01
    z[4,0,6]  R633      -7.0633783936500549e-02
    z[4,0,6]  R634      0.336056649684906
    z[4,0,6]  R635      -3.7884730100631714e-01
    z[4,0,6]  R636      3.8792282342910767e-01
    z[4,0,6]  R637      4.8093879222869873e-01
    z[4,0,6]  R638      -2.1727073192596436e-01
    z[4,0,6]  R639      2.2801366448402405e-01
    z[4,0,6]  R640      -3.5443242639303207e-02
    z[4,0,6]  R641      2.4797075986862183e-01
    z[4,0,6]  R642      -2.2168788313865662e-01
    z[4,0,6]  R643      -5.1924586296081543e-01
    z[4,0,6]  R644      -3.3369296789169312e-01
    z[4,0,6]  R645      -1.2417459487915039e-01
    z[4,0,6]  R646      -6.0502439737319946e-01
    z[4,0,6]  R647      -5.2315002679824829e-01
    z[4,0,6]  R648      -1.2507562339305878e-01
    z[4,0,6]  R649      2.4796277284622192e-01
    z[4,0,6]  R650      3.7377856671810150e-02
    z[4,0,6]  R651      -1.4497044682502747e-01
    z[4,0,6]  R652      -1.1728186905384064e-01
    z[4,0,6]  R653      -3.1991973519325256e-01
    z[4,0,6]  R654      -3.9871972799301147e-01
    z[4,0,6]  R655      -8.2211859524250031e-02
    z[4,0,6]  R656      -1.7676997184753418e-01
    z[4,0,6]  R657      4.8522818833589554e-02
    z[4,0,6]  R658      -6.2796503305435181e-02
    z[4,0,6]  R659      1.3915172778069973e-02
    z[4,0,6]  R660      3.0732309818267822e-01
    z[4,0,6]  R661      -1.7523214221000671e-01
    z[4,0,6]  R662      -1.7877882719039917e-01
    z[4,0,6]  R663      8.4513023495674133e-02
    z[4,0,6]  R664      6.6309428215026855e-01
    z[4,0,6]  R665      -2.1336279809474945e-02
    z[4,0,6]  R666      -2.5314772501587868e-02
    z[4,0,6]  R667      -2.4357235431671143e-01
    z[4,0,6]  R668      5.4480004310607910e-01
    z[4,0,6]  R669      2.2703976929187775e-01
    z[4,0,6]  R670      8.5677430033683777e-02
    z[4,0,6]  R671      -4.4246405363082886e-01
    z[4,0,6]  R672      5.7593584060668945e-02
    z[4,0,6]  R673      -2.5925964117050171e-01
    z[4,0,6]  R674      2.0709633827209473e-02
    z[4,0,6]  R675      -3.3967521786689758e-01
    z[4,0,6]  R676      -2.0554545521736145e-01
    z[4,0,6]  R677      -3.3647686243057251e-01
    z[4,0,6]  R678      5.7713504880666733e-02
    z[4,0,6]  R679      -3.1497564911842346e-01
    z[4,0,6]  R680      0.294825941324234
    z[4,0,6]  R681      1.3202600181102753e-01
    z[4,0,6]  R682      -0.479687362909317
    z[4,0,6]  R683      -5.3044372797012329e-01
    z[4,0,6]  R684      0.414413183927536
    z[4,0,6]  R685      2.2989781200885773e-01
    z[4,0,6]  R686      -7.8625408932566643e-03
    z[4,0,6]  R687      -6.0115452855825424e-02
    z[4,0,6]  R688      -3.7666597962379456e-01
    z[4,0,6]  R689      -2.3704078793525696e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R754      -1
    z[1,2,0]  R755      1
    z[1,2,0]  R768      -4.5251451432704926e-02
    z[1,2,0]  R769      -3.5671177506446838e-01
    z[1,2,0]  R770      -4.2242676019668579e-02
    z[1,2,0]  R771      -5.9709161520004272e-01
    z[1,2,0]  R772      -7.8293181955814362e-02
    z[1,2,0]  R773      -1.2750937603414059e-02
    z[1,2,0]  R774      -6.8526011705398560e-01
    z[1,2,0]  R775      -5.3374101407825947e-03
    z[1,2,0]  R776      -7.7924764156341553e-01
    z[1,2,0]  R777      -1.6494253277778625e-01
    z[1,2,0]  R778      1.0237602144479752e-01
    z[1,2,0]  R779      -9.1826446354389191e-02
    z[1,2,0]  R780      -1.0050944983959198e-01
    z[1,2,0]  R781      -6.5777927637100220e-02
    z[1,2,0]  R782      -2.2169025242328644e-01
    z[1,2,0]  R783      2.1646836772561073e-02
    z[1,2,0]  R784      5.4830335080623627e-02
    z[1,2,0]  R785      6.3755147159099579e-02
    z[1,2,0]  R786      -3.9741796255111694e-01
    z[1,2,0]  R787      1.9783353805541992e-01
    z[1,2,0]  R788      9.0975388884544373e-02
    z[1,2,0]  R789      7.3167368769645691e-02
    z[1,2,0]  R790      2.3548530042171478e-01
    z[1,2,0]  R791      2.6657110452651978e-01
    z[1,2,0]  R792      1.6141006350517273e-01
    z[1,2,0]  R793      -5.9019678831100464e-01
    z[1,2,0]  R794      2.3474588990211487e-01
    z[1,2,0]  R795      3.3537900447845459e-01
    z[1,2,0]  R796      2.8809833526611328e-01
    z[1,2,0]  R797      2.9013855382800102e-02
    z[1,2,0]  R798      1.7178709805011749e-01
    z[1,2,0]  R799      0.073527030646801
    z[1,2,0]  R800      3.7063896656036377e-01
    z[1,2,0]  R801      3.3976495265960693e-01
    z[1,2,0]  R802      3.7903591990470886e-01
    z[1,2,0]  R803      4.6893391013145447e-01
    z[1,2,0]  R804      2.6620736718177795e-01
    z[1,2,0]  R805      5.3020846843719482e-01
    z[1,2,0]  R806      8.5024207830429077e-01
    z[1,2,0]  R807      7.7913725376129150e-01
    z[1,2,0]  R808      -2.6873114705085754e-01
    z[1,2,0]  R809      -3.2073151320219040e-02
    z[1,2,0]  R810      3.7537875771522522e-01
    z[1,2,0]  R811      3.6279532313346863e-01
    z[1,2,0]  R812      2.7410724759101868e-01
    z[1,2,0]  R813      3.4550437331199646e-01
    z[1,2,0]  R814      -3.4611618518829346e-01
    z[1,2,0]  R815      -1.3425517082214355e-01
    z[1,2,0]  R816      -3.1043639779090881e-01
    z[1,2,0]  R817      -2.7002862095832825e-01
    z[1,2,0]  R818      -6.6402232646942139e-01
    z[1,2,0]  R819      -9.0399205684661865e-01
    z[1,2,0]  R820      -0.804214358329773
    z[1,2,0]  R821      -7.4929600954055786e-01
    z[1,2,0]  R822      -5.9058940410614014e-01
    z[1,2,0]  R823      -1.7309513350483030e-04
    z[1,2,0]  R824      6.1451070010662079e-02
    z[1,2,0]  R825      2.2709189355373383e-01
    z[1,2,0]  R826      -1.8552179634571075e-01
    z[1,2,0]  R827      -3.4881201386451721e-01
    z[1,2,0]  R828      1.3089212775230408e-01
    z[1,2,0]  R829      -3.5005442332476377e-03
    z[1,2,0]  R830      5.3854632377624512e-01
    z[1,2,0]  R831      4.9122610688209534e-01
    z[1,2,0]  R832      4.4492509961128235e-01
    z[1,2,0]  R833      2.5517001748085022e-01
    z[1,2,0]  R834      5.1593577861785889e-01
    z[1,2,0]  R835      -2.5728667154908180e-02
    z[1,2,0]  R836      8.3634227514266968e-02
    z[1,2,0]  R837      3.6626616120338440e-01
    z[1,2,0]  R838      -8.9695248752832413e-03
    z[1,2,0]  R839      1.5972553193569183e-01
    z[1,2,0]  R840      -5.3645157814025879e-01
    z[1,2,0]  R841      6.3105231523513794e-01
    z[1,2,0]  R842      -4.2418235540390015e-01
    z[1,2,0]  R843      5.4071956872940063e-01
    z[1,2,0]  R844      2.4172581732273102e-01
    z[1,2,0]  R845      6.0971105098724365e-01
    z[1,2,0]  R846      1.7035140097141266e-01
    z[1,2,0]  R847      7.2460480034351349e-02
    z[1,2,0]  R848      -6.7582845687866211e-01
    z[1,2,0]  R849      -6.0512125492095947e-01
    z[1,2,0]  R850      1.4272104203701019e-01
    z[1,2,0]  R851      -7.2260481119155884e-01
    z[1,2,0]  R852      6.4754843711853027e-01
    z[1,2,0]  R853      7.0424085855484009e-01
    z[1,2,0]  R854      8.7252952158451080e-02
    z[1,2,0]  R855      1.3760389387607574e-01
    z[1,2,0]  R856      4.6381881833076477e-01
    z[1,2,0]  R857      -1.3176780939102173e-01
    z[1,2,0]  R858      2.5867810845375061e-01
    z[1,2,0]  R859      9.8589166998863220e-02
    z[1,2,0]  R860      -1.6886758804321289e-01
    z[1,2,0]  R861      -2.4934832006692886e-02
    z[1,2,0]  R862      -2.7765434980392456e-01
    z[1,2,0]  R863      -7.5552088022232056e-01
    z[1,2,0]  R864      -8.4898811578750610e-01
    z[1,2,0]  R865      3.0848824977874756e-01
    z[1,2,0]  R866      -4.2343363165855408e-01
    z[1,2,0]  R867      3.1179559230804443e-01
    z[1,2,0]  R868      3.2969641685485840e-01
    z[1,2,0]  R869      3.4860834479331970e-01
    z[1,2,0]  R870      -4.5325347781181335e-01
    z[1,2,0]  R871      -0.422927588224411
    z[1,2,0]  R872      -5.0999581813812256e-01
    z[1,2,0]  R873      -2.6431143283843994e-01
    z[1,2,0]  R874      4.9214616417884827e-02
    z[1,2,0]  R875      1.9649212062358856e-01
    z[1,2,0]  R876      0.422234445810318
    z[1,2,0]  R877      2.4938111007213593e-01
    z[1,2,0]  R878      8.8419675827026367e-02
    z[1,2,0]  R879      4.0276327729225159e-01
    z[1,2,0]  R880      0.631734311580658
    z[1,2,0]  R881      5.6486970186233521e-01
    z[1,2,0]  R882      5.7851821184158325e-01
    z[1,2,0]  R883      4.3736633658409119e-01
    z[1,2,0]  R884      2.5934025645256042e-01
    z[1,2,0]  R885      5.0061064958572388e-01
    z[1,2,0]  R886      1.2580172717571259e-01
    z[1,2,0]  R887      2.9341140389442444e-01
    z[1,2,0]  R888      4.2084982991218567e-01
    z[1,2,0]  R889      1.8046663701534271e-01
    z[1,2,0]  R890      3.0953222513198853e-01
    z[1,2,0]  R891      2.5165063142776489e-01
    z[1,2,0]  R892      1.2470825761556625e-01
    z[1,2,0]  R893      5.1459338515996933e-02
    z[1,2,0]  R894      2.2383508086204529e-01
    z[1,2,0]  R895      1.8951010704040527e-01
    z[1,2,0]  R896      -5.1455962657928467e-01
    z[1,2,0]  R897      -0.131059467792511
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R756      -1
    z[1,2,1]  R757      1
    z[1,2,1]  R768      -4.1153582930564880e-01
    z[1,2,1]  R769      0.573833703994751
    z[1,2,1]  R770      -0.366733580827713
    z[1,2,1]  R771      2.7760806679725647e-01
    z[1,2,1]  R772      -4.9850201606750488e-01
    z[1,2,1]  R773      -0.262656033039093
    z[1,2,1]  R774      3.9246013760566711e-01
    z[1,2,1]  R775      -2.8604340553283691e-01
    z[1,2,1]  R776      1.2124329805374146e-01
    z[1,2,1]  R777      5.4653489589691162e-01
    z[1,2,1]  R778      -7.8913533687591553e-01
    z[1,2,1]  R779      -7.8548103570938110e-01
    z[1,2,1]  R780      -7.8021126985549927e-01
    z[1,2,1]  R781      -7.6294887065887451e-01
    z[1,2,1]  R782      -7.4078255891799927e-01
    z[1,2,1]  R783      -7.4767166376113892e-01
    z[1,2,1]  R784      -6.2841165065765381e-01
    z[1,2,1]  R785      -7.1363770961761475e-01
    z[1,2,1]  R786      -6.6738867759704590e-01
    z[1,2,1]  R787      -5.4265409708023071e-01
    z[1,2,1]  R788      -8.6383581161499023e-01
    z[1,2,1]  R789      -4.6129563450813293e-01
    z[1,2,1]  R790      -5.1387935876846313e-01
    z[1,2,1]  R791      -4.2744708061218262e-01
    z[1,2,1]  R792      -0.583754301071167
    z[1,2,1]  R793      1.9236426055431366e-01
    z[1,2,1]  R794      -3.0478119850158691e-01
    z[1,2,1]  R795      -4.9917593598365784e-01
    z[1,2,1]  R796      -5.3909343481063843e-01
    z[1,2,1]  R797      5.0474762916564941e-01
    z[1,2,1]  R798      -5.4632717370986938e-01
    z[1,2,1]  R799      -5.4762643575668335e-01
    z[1,2,1]  R800      -1.4396350085735321e-01
    z[1,2,1]  R801      -2.5115618109703064e-01
    z[1,2,1]  R802      -4.8610472679138184e-01
    z[1,2,1]  R803      4.6591964364051819e-01
    z[1,2,1]  R804      5.2314704656600952e-01
    z[1,2,1]  R805      4.5538052916526794e-01
    z[1,2,1]  R806      3.7054851651191711e-01
    z[1,2,1]  R807      3.2702940702438354e-01
    z[1,2,1]  R808      -2.1588015556335449e-01
    z[1,2,1]  R809      1.7628110945224762e-01
    z[1,2,1]  R810      -2.3755583167076111e-01
    z[1,2,1]  R811      2.0479236543178558e-01
    z[1,2,1]  R812      -1.3154593110084534e-01
    z[1,2,1]  R813      1.9905219972133636e-01
    z[1,2,1]  R814      -4.1699981689453125e-01
    z[1,2,1]  R815      -3.0128517746925354e-01
    z[1,2,1]  R816      -7.6194740831851959e-02
    z[1,2,1]  R817      0.209869846701622
    z[1,2,1]  R818      -4.0960386395454407e-01
    z[1,2,1]  R819      -1.5778750181198120e-01
    z[1,2,1]  R820      -2.4455009400844574e-01
    z[1,2,1]  R821      -2.5556573271751404e-01
    z[1,2,1]  R822      -3.8000097870826721e-01
    z[1,2,1]  R823      1.2717936933040619e-01
    z[1,2,1]  R824      1.5552307665348053e-01
    z[1,2,1]  R825      3.5584294237196445e-03
    z[1,2,1]  R826      3.0309504270553589e-01
    z[1,2,1]  R827      0.143227681517601
    z[1,2,1]  R828      6.7356717586517334e-01
    z[1,2,1]  R829      8.2480198144912720e-01
    z[1,2,1]  R830      5.6491744518280029e-01
    z[1,2,1]  R831      -7.3912781476974487e-01
    z[1,2,1]  R832      -6.5501809120178223e-01
    z[1,2,1]  R833      -5.0831407308578491e-01
    z[1,2,1]  R834      -5.9823578596115112e-01
    z[1,2,1]  R835      8.8219058513641357e-01
    z[1,2,1]  R836      8.8769757747650146e-01
    z[1,2,1]  R837      4.5806637406349182e-01
    z[1,2,1]  R838      1.8596200644969940e-01
    z[1,2,1]  R839      7.1757632493972778e-01
    z[1,2,1]  R840      -3.8152185082435608e-01
    z[1,2,1]  R841      1.4021593332290649e-01
    z[1,2,1]  R842      -3.7752085924148560e-01
    z[1,2,1]  R843      0.69268798828125
    z[1,2,1]  R844      -6.1385488510131836e-01
    z[1,2,1]  R845      6.0728186368942261e-01
    z[1,2,1]  R846      -4.8250687122344971e-01
    z[1,2,1]  R847      -7.0133811235427856e-01
    z[1,2,1]  R848      -5.4359430074691772e-01
    z[1,2,1]  R849      -4.9089613556861877e-01
    z[1,2,1]  R850      2.6800769567489624e-01
    z[1,2,1]  R851      -4.0371596813201904e-01
    z[1,2,1]  R852      0.409095823764801
    z[1,2,1]  R853      6.2194281816482544e-01
    z[1,2,1]  R854      -3.8345479965209961e-01
    z[1,2,1]  R855      9.3600398302078247e-01
    z[1,2,1]  R856      -5.5373638868331909e-01
    z[1,2,1]  R857      9.1260397434234619e-01
    z[1,2,1]  R858      1.5924791991710663e-01
    z[1,2,1]  R859      3.9333915710449219e-01
    z[1,2,1]  R860      3.0031278729438782e-01
    z[1,2,1]  R861      6.2737494707107544e-01
    z[1,2,1]  R862      2.1992325782775879e-01
    z[1,2,1]  R863      -4.1509312391281128e-01
    z[1,2,1]  R864      -4.1287493705749512e-01
    z[1,2,1]  R865      8.0462110042572021e-01
    z[1,2,1]  R866      -3.6295115947723389e-01
    z[1,2,1]  R867      -6.9650501012802124e-01
    z[1,2,1]  R868      -6.7203216254711151e-02
    z[1,2,1]  R869      8.0494272708892822e-01
    z[1,2,1]  R870      -3.9140564203262329e-01
    z[1,2,1]  R871      4.6580326557159424e-01
    z[1,2,1]  R872      3.8096180558204651e-01
    z[1,2,1]  R873      1.5873104333877563e-01
    z[1,2,1]  R874      1.4601269364356995e-01
    z[1,2,1]  R875      2.3214745521545410e-01
    z[1,2,1]  R876      -5.8443200588226318e-01
    z[1,2,1]  R877      -4.8416009545326233e-01
    z[1,2,1]  R878      -4.8915907740592957e-01
    z[1,2,1]  R879      -5.4353523254394531e-01
    z[1,2,1]  R880      3.3106356859207153e-01
    z[1,2,1]  R881      0.0721365436911583
    z[1,2,1]  R882      2.4072538316249847e-01
    z[1,2,1]  R883      -4.7887992858886719e-01
    z[1,2,1]  R884      -3.7768241763114929e-01
    z[1,2,1]  R885      -3.6895516514778137e-01
    z[1,2,1]  R886      -3.3499330282211304e-01
    z[1,2,1]  R887      -2.3496727645397186e-01
    z[1,2,1]  R888      -0.631965160369873
    z[1,2,1]  R889      -5.7080310583114624e-01
    z[1,2,1]  R890      -4.0810176730155945e-01
    z[1,2,1]  R891      -2.2940079867839813e-01
    z[1,2,1]  R892      -2.9745447635650635e-01
    z[1,2,1]  R893      -1.1915975809097290e-01
    z[1,2,1]  R894      6.0840494930744171e-02
    z[1,2,1]  R895      -2.8783810138702393e-01
    z[1,2,1]  R896      6.6480404138565063e-01
    z[1,2,1]  R897      5.4802858829498291e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R758      -1
    z[1,2,2]  R759      1
    z[1,2,2]  R768      5.0443840026855469e-01
    z[1,2,2]  R769      -4.9243211746215820e-01
    z[1,2,2]  R770      1.2689022719860077e-01
    z[1,2,2]  R771      -0.626781165599823
    z[1,2,2]  R772      7.9153716564178467e-01
    z[1,2,2]  R773      7.2913813591003418e-01
    z[1,2,2]  R774      -4.3528309464454651e-01
    z[1,2,2]  R775      3.0553472042083740e-01
    z[1,2,2]  R776      -5.4495644569396973e-01
    z[1,2,2]  R777      -7.0033740997314453e-01
    z[1,2,2]  R778      -3.6397790908813477e-01
    z[1,2,2]  R779      -2.8767114877700806e-01
    z[1,2,2]  R780      -3.3676931262016296e-01
    z[1,2,2]  R781      -3.1985855102539062e-01
    z[1,2,2]  R782      -2.3950286209583282e-01
    z[1,2,2]  R783      -1.2533517181873322e-01
    z[1,2,2]  R784      1.7164391279220581e-01
    z[1,2,2]  R785      -2.3216864466667175e-01
    z[1,2,2]  R786      1.0192343033850193e-03
    z[1,2,2]  R787      9.2219136655330658e-02
    z[1,2,2]  R788      1.1176556348800659e-01
    z[1,2,2]  R789      3.0754688382148743e-01
    z[1,2,2]  R790      0.3104248046875
    z[1,2,2]  R791      4.3009561300277710e-01
    z[1,2,2]  R792      -1.9003529846668243e-01
    z[1,2,2]  R793      -3.1999304890632629e-01
    z[1,2,2]  R794      5.9365980327129364e-02
    z[1,2,2]  R795      5.3292375802993774e-01
    z[1,2,2]  R796      1.1547703295946121e-01
    z[1,2,2]  R797      3.5850954055786133e-01
    z[1,2,2]  R798      1.8182796239852905e-01
    z[1,2,2]  R799      5.6437408924102783e-01
    z[1,2,2]  R800      7.5032621622085571e-01
    z[1,2,2]  R801      1.2528024613857269e-01
    z[1,2,2]  R802      2.2773987054824829e-01
    z[1,2,2]  R803      2.6856359094381332e-02
    z[1,2,2]  R804      1.8239600956439972e-01
    z[1,2,2]  R805      2.3532277345657349e-01
    z[1,2,2]  R806      1.6897714138031006e-01
    z[1,2,2]  R807      6.8543985486030579e-02
    z[1,2,2]  R808      -3.9520934224128723e-01
    z[1,2,2]  R809      -6.5507078170776367e-01
    z[1,2,2]  R810      -6.7343634366989136e-01
    z[1,2,2]  R811      -7.1022748947143555e-01
    z[1,2,2]  R812      -3.5012489557266235e-01
    z[1,2,2]  R813      -2.4349214136600494e-01
    z[1,2,2]  R814      -7.4231493473052979e-01
    z[1,2,2]  R815      -5.1035708189010620e-01
    z[1,2,2]  R816      -4.5079621672630310e-01
    z[1,2,2]  R817      -3.3830073475837708e-01
    z[1,2,2]  R818      2.1875385940074921e-01
    z[1,2,2]  R819      3.3716621994972229e-01
    z[1,2,2]  R820      4.4088739156723022e-01
    z[1,2,2]  R821      2.2630555927753448e-01
    z[1,2,2]  R822      5.4999870061874390e-01
    z[1,2,2]  R823      8.7424147129058838e-01
    z[1,2,2]  R824      9.4849610328674316e-01
    z[1,2,2]  R825      9.5662963390350342e-01
    z[1,2,2]  R826      8.9228767156600952e-01
    z[1,2,2]  R827      8.1086415052413940e-01
    z[1,2,2]  R828      -4.1185855865478516e-01
    z[1,2,2]  R829      -1.9162485376000404e-02
    z[1,2,2]  R830      2.8008872270584106e-01
    z[1,2,2]  R831      4.0162590146064758e-01
    z[1,2,2]  R832      4.4733661413192749e-01
    z[1,2,2]  R833      0.568046510219574
    z[1,2,2]  R834      2.8434932231903076e-01
    z[1,2,2]  R835      3.1677380204200745e-01
    z[1,2,2]  R836      1.1546524614095688e-01
    z[1,2,2]  R837      -1.6543051600456238e-01
    z[1,2,2]  R838      -0.0796266719698906
    z[1,2,2]  R839      -2.9266723990440369e-01
    z[1,2,2]  R840      -2.8603881597518921e-01
    z[1,2,2]  R841      -3.5321470350027084e-02
    z[1,2,2]  R842      1.1452263593673706e-01
    z[1,2,2]  R843      1.4027774333953857e-02
    z[1,2,2]  R844      0.628491997718811
    z[1,2,2]  R845      3.4253127872943878e-02
    z[1,2,2]  R846      6.6206520795822144e-01
    z[1,2,2]  R847      6.2908381223678589e-01
    z[1,2,2]  R848      2.9503282904624939e-01
    z[1,2,2]  R849      -1.2889644131064415e-02
    z[1,2,2]  R850      -3.6238917708396912e-01
    z[1,2,2]  R851      -1.2910751998424530e-01
    z[1,2,2]  R852      2.9581716284155846e-02
    z[1,2,2]  R853      -5.8643147349357605e-02
    z[1,2,2]  R854      7.1621578931808472e-01
    z[1,2,2]  R855      1.7335261404514313e-01
    z[1,2,2]  R856      0.579522430896759
    z[1,2,2]  R857      -1.2586662545800209e-02
    z[1,2,2]  R858      -0.60338294506073
    z[1,2,2]  R859      -2.8439977765083313e-01
    z[1,2,2]  R860      -5.1153934001922607e-01
    z[1,2,2]  R861      -1.1169648915529251e-01
    z[1,2,2]  R862      -5.5183249711990356e-01
    z[1,2,2]  R863      -7.1597069501876831e-02
    z[1,2,2]  R864      7.9120278358459473e-02
    z[1,2,2]  R865      -3.7630371749401093e-02
    z[1,2,2]  R866      1.3049761950969696e-01
    z[1,2,2]  R867      6.2702363729476929e-01
    z[1,2,2]  R868      -7.2930544614791870e-01
    z[1,2,2]  R869      -3.3465901017189026e-01
    z[1,2,2]  R870      3.6644306033849716e-02
    z[1,2,2]  R871      7.0993721485137939e-01
    z[1,2,2]  R872      0.539761483669281
    z[1,2,2]  R873      0.705171525478363
    z[1,2,2]  R874      9.0713568031787872e-02
    z[1,2,2]  R875      -1.1441487073898315e-01
    z[1,2,2]  R876      3.7345755100250244e-01
    z[1,2,2]  R877      4.0972551703453064e-01
    z[1,2,2]  R878      7.2683101892471313e-01
    z[1,2,2]  R879      6.2340795993804932e-01
    z[1,2,2]  R880      1.4043259620666504e-01
    z[1,2,2]  R881      -1.3547022640705109e-01
    z[1,2,2]  R882      1.2957191467285156e-01
    z[1,2,2]  R883      4.8817488551139832e-01
    z[1,2,2]  R884      5.4580259323120117e-01
    z[1,2,2]  R885      4.9789234995841980e-01
    z[1,2,2]  R886      -2.2322230041027069e-01
    z[1,2,2]  R887      -2.6471281051635742e-01
    z[1,2,2]  R888      6.1506575345993042e-01
    z[1,2,2]  R889      4.2768985033035278e-01
    z[1,2,2]  R890      5.0138247013092041e-01
    z[1,2,2]  R891      -1.3325053453445435e-01
    z[1,2,2]  R892      -8.8966287672519684e-02
    z[1,2,2]  R893      1.1987017840147018e-01
    z[1,2,2]  R894      -2.1370720863342285e-01
    z[1,2,2]  R895      -1.6838872432708740e-01
    z[1,2,2]  R896      2.0024140179157257e-01
    z[1,2,2]  R897      4.3591436743736267e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R760      -1
    z[1,2,3]  R761      1
    z[1,2,3]  R768      5.3050768375396729e-01
    z[1,2,3]  R769      2.4304993450641632e-01
    z[1,2,3]  R770      0.799430251121521
    z[1,2,3]  R771      1.0718559473752975e-01
    z[1,2,3]  R772      1.0570231825113297e-01
    z[1,2,3]  R773      5.6906795501708984e-01
    z[1,2,3]  R774      1.5660229325294495e-01
    z[1,2,3]  R775      6.4447224140167236e-01
    z[1,2,3]  R776      2.4263779819011688e-01
    z[1,2,3]  R777      1.3728702068328857e-01
    z[1,2,3]  R778      0.174093097448349
    z[1,2,3]  R779      -2.9917600750923157e-01
    z[1,2,3]  R780      -3.9608660340309143e-01
    z[1,2,3]  R781      -4.9124431610107422e-01
    z[1,2,3]  R782      -4.4795447587966919e-01
    z[1,2,3]  R783      -4.1094160079956055e-01
    z[1,2,3]  R784      -4.0366217494010925e-01
    z[1,2,3]  R785      -4.2908832430839539e-01
    z[1,2,3]  R786      -1.9940476119518280e-01
    z[1,2,3]  R787      -5.6705063581466675e-01
    z[1,2,3]  R788      1.2812471017241478e-02
    z[1,2,3]  R789      3.9192914962768555e-01
    z[1,2,3]  R790      -1.0241139680147171e-01
    z[1,2,3]  R791      -2.2310981154441833e-01
    z[1,2,3]  R792      -5.0097241997718811e-02
    z[1,2,3]  R793      5.2560776472091675e-02
    z[1,2,3]  R794      2.0923748612403870e-01
    z[1,2,3]  R795      1.9200769066810608e-01
    z[1,2,3]  R796      8.4713473916053772e-02
    z[1,2,3]  R797      6.5258580446243286e-01
    z[1,2,3]  R798      7.9723989963531494e-01
    z[1,2,3]  R799      5.0779759883880615e-01
    z[1,2,3]  R800      1.6282172501087189e-01
    z[1,2,3]  R801      4.7349786758422852e-01
    z[1,2,3]  R802      8.6323969066143036e-02
    z[1,2,3]  R803      3.1835392117500305e-01
    z[1,2,3]  R804      -2.1111611276865005e-02
    z[1,2,3]  R805      6.1433070898056030e-01
    z[1,2,3]  R806      -1.2037465721368790e-01
    z[1,2,3]  R807      -4.6486461162567139e-01
    z[1,2,3]  R808      5.8361768722534180e-01
    z[1,2,3]  R809      4.6935808658599854e-01
    z[1,2,3]  R810      4.0347889065742493e-01
    z[1,2,3]  R811      5.5925935506820679e-01
    z[1,2,3]  R812      4.1561439633369446e-01
    z[1,2,3]  R813      8.5939311981201172e-01
    z[1,2,3]  R814      0.275499552488327
    z[1,2,3]  R815      7.4122303724288940e-01
    z[1,2,3]  R816      5.0755894184112549e-01
    z[1,2,3]  R817      1.4604271948337555e-01
    z[1,2,3]  R818      -4.8070603609085083e-01
    z[1,2,3]  R819      -0.170390784740448
    z[1,2,3]  R820      3.8864649832248688e-02
    z[1,2,3]  R821      -0.148195281624794
    z[1,2,3]  R822      -0.068141870200634
    z[1,2,3]  R823      0.0461047999560833
    z[1,2,3]  R824      7.8676626086235046e-02
    z[1,2,3]  R825      1.0513123869895935e-01
    z[1,2,3]  R826      0.0667092427611351
    z[1,2,3]  R827      2.0522156357765198e-01
    z[1,2,3]  R828      -2.3449407517910004e-01
    z[1,2,3]  R829      -1.1086897552013397e-01
    z[1,2,3]  R830      1.3058193027973175e-01
    z[1,2,3]  R831      -1.5165399014949799e-01
    z[1,2,3]  R832      -3.3748653531074524e-01
    z[1,2,3]  R833      -3.0212721228599548e-01
    z[1,2,3]  R834      -1.4454054832458496e-01
    z[1,2,3]  R835      -0.0949816182255745
    z[1,2,3]  R836      -0.00844635721296072
    z[1,2,3]  R837      -0.072464220225811
    z[1,2,3]  R838      2.6678740978240967e-01
    z[1,2,3]  R839      1.5070120804011822e-02
    z[1,2,3]  R840      -5.3139245510101318e-01
    z[1,2,3]  R841      -2.8727075085043907e-02
    z[1,2,3]  R842      -9.5711521804332733e-02
    z[1,2,3]  R843      -7.4008852243423462e-02
    z[1,2,3]  R844      9.4357088208198547e-02
    z[1,2,3]  R845      -5.3052004426717758e-02
    z[1,2,3]  R846      -2.3163458704948425e-01
    z[1,2,3]  R847      2.2300805151462555e-01
    z[1,2,3]  R848      1.6113524138927460e-01
    z[1,2,3]  R849      -2.3640665411949158e-01
    z[1,2,3]  R850      -3.4317496418952942e-01
    z[1,2,3]  R851      -3.7083217501640320e-01
    z[1,2,3]  R852      -9.3176349997520447e-02
    z[1,2,3]  R853      -7.2438023984432220e-02
    z[1,2,3]  R854      -3.0139824748039246e-01
    z[1,2,3]  R855      -1.7185065150260925e-01
    z[1,2,3]  R856      -1.4382113516330719e-01
    z[1,2,3]  R857      -1.5414026379585266e-01
    z[1,2,3]  R858      2.1110512316226959e-01
    z[1,2,3]  R859      -3.6252435296773911e-02
    z[1,2,3]  R860      -0.321154922246933
    z[1,2,3]  R861      1.9282083213329315e-01
    z[1,2,3]  R862      -1.6128194332122803e-01
    z[1,2,3]  R863      -1.8521138699725270e-03
    z[1,2,3]  R864      -1.4850957691669464e-01
    z[1,2,3]  R865      2.2216208279132843e-01
    z[1,2,3]  R866      -1.8443416059017181e-01
    z[1,2,3]  R867      -5.6029386818408966e-02
    z[1,2,3]  R868      1.2959238886833191e-01
    z[1,2,3]  R869      4.5644771307706833e-02
    z[1,2,3]  R870      -1.8064694106578827e-01
    z[1,2,3]  R871      8.3385735750198364e-02
    z[1,2,3]  R872      2.6409700512886047e-01
    z[1,2,3]  R873      3.6392763257026672e-01
    z[1,2,3]  R874      -0.806171178817749
    z[1,2,3]  R875      -8.5051637887954712e-01
    z[1,2,3]  R876      6.0818102210760117e-02
    z[1,2,3]  R877      -1.5635755658149719e-01
    z[1,2,3]  R878      -5.2543841302394867e-02
    z[1,2,3]  R879      -2.5762656331062317e-01
    z[1,2,3]  R880      5.9513457119464874e-02
    z[1,2,3]  R881      1.8277665600180626e-02
    z[1,2,3]  R882      1.0919960588216782e-01
    z[1,2,3]  R883      -4.5451596379280090e-01
    z[1,2,3]  R884      -4.6350872516632080e-01
    z[1,2,3]  R885      3.5328158736228943e-01
    z[1,2,3]  R886      -4.3283212184906006e-01
    z[1,2,3]  R887      -5.5757224559783936e-01
    z[1,2,3]  R888      -3.1490195542573929e-02
    z[1,2,3]  R889      -9.0821079909801483e-02
    z[1,2,3]  R890      -4.4099974632263184e-01
    z[1,2,3]  R891      -8.5201394557952881e-01
    z[1,2,3]  R892      -7.7582234144210815e-01
    z[1,2,3]  R893      -0.92115718126297
    z[1,2,3]  R894      -9.0703666210174561e-01
    z[1,2,3]  R895      -8.0508148670196533e-01
    z[1,2,3]  R896      1.9683811068534851e-01
    z[1,2,3]  R897      -1.1682634800672531e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R762      -1
    z[1,2,4]  R763      1
    z[1,2,4]  R768      2.6285862922668457e-01
    z[1,2,4]  R769      2.0473259687423706e-01
    z[1,2,4]  R770      2.8543433547019958e-01
    z[1,2,4]  R771      1.7861008644104004e-01
    z[1,2,4]  R772      3.9897285401821136e-02
    z[1,2,4]  R773      -1.0376599431037903e-01
    z[1,2,4]  R774      2.9115831851959229e-01
    z[1,2,4]  R775      5.5429106950759888e-01
    z[1,2,4]  R776      -1.4271882176399231e-01
    z[1,2,4]  R777      -1.6991877555847168e-01
    z[1,2,4]  R778      -3.5168644785881042e-01
    z[1,2,4]  R779      -2.1051105856895447e-01
    z[1,2,4]  R780      1.6175056993961334e-01
    z[1,2,4]  R781      1.5208730101585388e-01
    z[1,2,4]  R782      -1.2244738638401031e-01
    z[1,2,4]  R783      2.9136139154434204e-01
    z[1,2,4]  R784      8.3066321909427643e-02
    z[1,2,4]  R785      2.1944449841976166e-01
    z[1,2,4]  R786      2.4374271929264069e-01
    z[1,2,4]  R787      2.9229193925857544e-01
    z[1,2,4]  R788      3.7499007582664490e-01
    z[1,2,4]  R789      -5.2446460723876953e-01
    z[1,2,4]  R790      1.5510775148868561e-01
    z[1,2,4]  R791      -3.1334522366523743e-01
    z[1,2,4]  R792      0.34656822681427
    z[1,2,4]  R793      -2.3756182193756104e-01
    z[1,2,4]  R794      3.7706881761550903e-01
    z[1,2,4]  R795      -5.1656424999237061e-01
    z[1,2,4]  R796      -3.3346924185752869e-01
    z[1,2,4]  R797      2.6950253173708916e-02
    z[1,2,4]  R798      0.00511670857667923
    z[1,2,4]  R799      1.8650548160076141e-01
    z[1,2,4]  R800      4.6590843796730042e-01
    z[1,2,4]  R801      1.1250261217355728e-01
    z[1,2,4]  R802      -5.7950061559677124e-01
    z[1,2,4]  R803      -5.7460999488830566e-01
    z[1,2,4]  R804      -3.1709730625152588e-01
    z[1,2,4]  R805      -1.8819181621074677e-01
    z[1,2,4]  R806      2.0447519421577454e-01
    z[1,2,4]  R807      1.5613253414630890e-01
    z[1,2,4]  R808      -1.3866421580314636e-01
    z[1,2,4]  R809      0.4262675344944
    z[1,2,4]  R810      1.2889516353607178e-01
    z[1,2,4]  R811      -2.1842949092388153e-02
    z[1,2,4]  R812      -3.7414006888866425e-02
    z[1,2,4]  R813      -9.2173544690012932e-03
    z[1,2,4]  R814      9.3282364308834076e-02
    z[1,2,4]  R815      1.4299346506595612e-01
    z[1,2,4]  R816      1.1714073270559311e-01
    z[1,2,4]  R817      3.7614884972572327e-01
    z[1,2,4]  R818      0.0735994279384613
    z[1,2,4]  R819      6.7542046308517456e-02
    z[1,2,4]  R820      2.3088328540325165e-01
    z[1,2,4]  R821      -9.5550626516342163e-02
    z[1,2,4]  R822      -1.7954094707965851e-01
    z[1,2,4]  R823      3.1480357050895691e-01
    z[1,2,4]  R824      1.8796192109584808e-01
    z[1,2,4]  R825      8.3698770031332970e-03
    z[1,2,4]  R826      0.0705980509519577
    z[1,2,4]  R827      2.6583236455917358e-01
    z[1,2,4]  R828      -3.7515938282012939e-01
    z[1,2,4]  R829      -4.4282034039497375e-01
    z[1,2,4]  R830      -1.6256643831729889e-01
    z[1,2,4]  R831      1.1624976247549057e-01
    z[1,2,4]  R832      2.3277167975902557e-01
    z[1,2,4]  R833      1.8302576243877411e-01
    z[1,2,4]  R834      2.3575511574745178e-01
    z[1,2,4]  R835      -9.6358023583889008e-02
    z[1,2,4]  R836      1.0487534105777740e-01
    z[1,2,4]  R837      -2.3561987280845642e-01
    z[1,2,4]  R838      -9.4050276279449463e-01
    z[1,2,4]  R839      -5.3487664461135864e-01
    z[1,2,4]  R840      -5.0266232341527939e-02
    z[1,2,4]  R841      -3.7714448571205139e-01
    z[1,2,4]  R842      7.5331604480743408e-01
    z[1,2,4]  R843      4.3590095639228821e-01
    z[1,2,4]  R844      5.7433921843767166e-02
    z[1,2,4]  R845      -0.0620078481733799
    z[1,2,4]  R846      4.7839531302452087e-01
    z[1,2,4]  R847      1.7153675854206085e-01
    z[1,2,4]  R848      -2.6997578144073486e-01
    z[1,2,4]  R849      1.3102343678474426e-01
    z[1,2,4]  R850      -6.5804773569107056e-01
    z[1,2,4]  R851      -2.1013745665550232e-01
    z[1,2,4]  R852      -0.456379771232605
    z[1,2,4]  R853      2.5651317834854126e-01
    z[1,2,4]  R854      4.8555487394332886e-01
    z[1,2,4]  R855      0.181008979678154
    z[1,2,4]  R856      -2.8443282842636108e-01
    z[1,2,4]  R857      -6.0795680619776249e-03
    z[1,2,4]  R858      -5.2893245220184326e-01
    z[1,2,4]  R859      -7.8231376409530640e-01
    z[1,2,4]  R860      -5.5640321969985962e-01
    z[1,2,4]  R861      -6.1660176515579224e-01
    z[1,2,4]  R862      -3.5854494571685791e-01
    z[1,2,4]  R863      3.8253688812255859e-01
    z[1,2,4]  R864      -1.3372954726219177e-01
    z[1,2,4]  R865      4.8215255141258240e-02
    z[1,2,4]  R866      -7.5708419084548950e-01
    z[1,2,4]  R867      -8.2201175391674042e-02
    z[1,2,4]  R868      -1.6545540094375610e-01
    z[1,2,4]  R869      -1.9630345702171326e-01
    z[1,2,4]  R870      -0.774272620677948
    z[1,2,4]  R871      2.1603046357631683e-01
    z[1,2,4]  R872      -3.5607546567916870e-01
    z[1,2,4]  R873      -2.8958949446678162e-01
    z[1,2,4]  R874      -3.5417255759239197e-01
    z[1,2,4]  R875      -2.1766684949398041e-01
    z[1,2,4]  R876      -2.9416689649224281e-02
    z[1,2,4]  R877      9.9350109696388245e-02
    z[1,2,4]  R878      3.9517775177955627e-01
    z[1,2,4]  R879      0.206630676984787
    z[1,2,4]  R880      2.1284732222557068e-01
    z[1,2,4]  R881      3.7563538551330566e-01
    z[1,2,4]  R882      6.9434428215026855e-01
    z[1,2,4]  R883      -4.8193059861660004e-02
    z[1,2,4]  R884      2.4971835315227509e-01
    z[1,2,4]  R885      0.300087571144104
    z[1,2,4]  R886      -4.5681995153427124e-01
    z[1,2,4]  R887      -4.3525260686874390e-01
    z[1,2,4]  R888      1.1224637180566788e-01
    z[1,2,4]  R889      4.8872217535972595e-01
    z[1,2,4]  R890      2.8599053621292114e-01
    z[1,2,4]  R891      -1.3222269713878632e-01
    z[1,2,4]  R892      -4.7229605913162231e-01
    z[1,2,4]  R893      -1.6047553718090057e-01
    z[1,2,4]  R894      7.0403993129730225e-02
    z[1,2,4]  R895      4.3914973735809326e-01
    z[1,2,4]  R896      3.7198930978775024e-01
    z[1,2,4]  R897      5.9806394577026367e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R764      -1
    z[1,2,5]  R765      1
    z[1,2,5]  R768      -6.3787393271923065e-02
    z[1,2,5]  R769      -4.0692013502120972e-01
    z[1,2,5]  R770      1.3815888762474060e-01
    z[1,2,5]  R771      -2.3018175363540649e-01
    z[1,2,5]  R772      -3.1856033205986023e-01
    z[1,2,5]  R773      -1.9800245761871338e-01
    z[1,2,5]  R774      -1.3131687045097351e-01
    z[1,2,5]  R775      2.0805935561656952e-01
    z[1,2,5]  R776      -2.8782995417714119e-02
    z[1,2,5]  R777      1.7422935366630554e-01
    z[1,2,5]  R778      -1.3307310640811920e-01
    z[1,2,5]  R779      3.2203185558319092e-01
    z[1,2,5]  R780      6.9552063941955566e-02
    z[1,2,5]  R781      1.4325352013111115e-01
    z[1,2,5]  R782      2.9530632495880127e-01
    z[1,2,5]  R783      4.1212841868400574e-01
    z[1,2,5]  R784      5.8570575714111328e-01
    z[1,2,5]  R785      -4.3115538358688354e-01
    z[1,2,5]  R786      4.2247429490089417e-01
    z[1,2,5]  R787      -1.7058970034122467e-01
    z[1,2,5]  R788      -1.5608721971511841e-01
    z[1,2,5]  R789      -5.0835871696472168e-01
    z[1,2,5]  R790      6.9800531864166260e-01
    z[1,2,5]  R791      2.4462699890136719e-01
    z[1,2,5]  R792      4.6346226334571838e-01
    z[1,2,5]  R793      -6.4760148525238037e-01
    z[1,2,5]  R794      -8.1387633085250854e-01
    z[1,2,5]  R795      1.3412535190582275e-01
    z[1,2,5]  R796      2.1217954158782959e-01
    z[1,2,5]  R797      -1.9284363090991974e-01
    z[1,2,5]  R798      -5.1182083785533905e-02
    z[1,2,5]  R799      2.1714878082275391e-01
    z[1,2,5]  R800      -1.0764618217945099e-01
    z[1,2,5]  R801      6.0474467277526855e-01
    z[1,2,5]  R802      0.469120055437088
    z[1,2,5]  R803      -0.361625075340271
    z[1,2,5]  R804      -5.3766030073165894e-01
    z[1,2,5]  R805      -1.6545116901397705e-01
    z[1,2,5]  R806      1.3289323449134827e-01
    z[1,2,5]  R807      -9.6647344529628754e-02
    z[1,2,5]  R808      -5.7709765434265137e-01
    z[1,2,5]  R809      -3.5071596503257751e-01
    z[1,2,5]  R810      -0.278903067111969
    z[1,2,5]  R811      5.8221589773893356e-02
    z[1,2,5]  R812      -0.517057478427887
    z[1,2,5]  R813      -1.5165178477764130e-01
    z[1,2,5]  R814      -2.3012003302574158e-01
    z[1,2,5]  R815      -1.0831041634082794e-01
    z[1,2,5]  R816      -4.0791058540344238e-01
    z[1,2,5]  R817      -7.4242120981216431e-01
    z[1,2,5]  R818      3.2431101799011230e-01
    z[1,2,5]  R819      1.3020985759794712e-02
    z[1,2,5]  R820      1.7334592342376709e-01
    z[1,2,5]  R821      2.3370157182216644e-01
    z[1,2,5]  R822      3.6393117904663086e-01
    z[1,2,5]  R823      3.2534962892532349e-01
    z[1,2,5]  R824      0.166063129901886
    z[1,2,5]  R825      9.8060876131057739e-02
    z[1,2,5]  R826      2.5930896401405334e-01
    z[1,2,5]  R827      2.8347793221473694e-01
    z[1,2,5]  R828      -2.1221968531608582e-01
    z[1,2,5]  R829      -2.6262289285659790e-01
    z[1,2,5]  R830      3.7324330210685730e-01
    z[1,2,5]  R831      1.0355718433856964e-01
    z[1,2,5]  R832      -2.0006487146019936e-02
    z[1,2,5]  R833      3.7442959845066071e-02
    z[1,2,5]  R834      3.6605718731880188e-01
    z[1,2,5]  R835      2.8392788767814636e-01
    z[1,2,5]  R836      2.2410650551319122e-01
    z[1,2,5]  R837      3.9185580611228943e-01
    z[1,2,5]  R838      -4.6332050114870071e-02
    z[1,2,5]  R839      -2.9014545679092407e-01
    z[1,2,5]  R840      3.3672028779983521e-01
    z[1,2,5]  R841      5.5800926685333252e-01
    z[1,2,5]  R842      0.097394198179245
    z[1,2,5]  R843      3.9934930391609669e-03
    z[1,2,5]  R844      6.4718961715698242e-02
    z[1,2,5]  R845      4.3009036779403687e-01
    z[1,2,5]  R846      -1.2009969353675842e-01
    z[1,2,5]  R847      0.0447159968316555
    z[1,2,5]  R848      1.9053022563457489e-01
    z[1,2,5]  R849      1.5491028130054474e-01
    z[1,2,5]  R850      -4.1099965572357178e-01
    z[1,2,5]  R851      -3.3980360627174377e-01
    z[1,2,5]  R852      2.9551693797111511e-01
    z[1,2,5]  R853      2.8076082468032837e-02
    z[1,2,5]  R854      4.3349310755729675e-02
    z[1,2,5]  R855      0.0949019193649292
    z[1,2,5]  R856      -1.9856201112270355e-01
    z[1,2,5]  R857      3.4327441453933716e-01
    z[1,2,5]  R858      -0.295166552066803
    z[1,2,5]  R859      -3.4717667102813721e-01
    z[1,2,5]  R860      -3.6521118879318237e-01
    z[1,2,5]  R861      -1.5804505348205566e-01
    z[1,2,5]  R862      -6.1893957853317261e-01
    z[1,2,5]  R863      2.2514855861663818e-01
    z[1,2,5]  R864      -8.1602893769741058e-02
    z[1,2,5]  R865      -3.0847036838531494e-01
    z[1,2,5]  R866      -2.2324765101075172e-02
    z[1,2,5]  R867      -1.1252982169389725e-01
    z[1,2,5]  R868      -5.4488635063171387e-01
    z[1,2,5]  R869      -2.3003305494785309e-01
    z[1,2,5]  R870      8.4717579185962677e-02
    z[1,2,5]  R871      -2.1322610974311829e-01
    z[1,2,5]  R872      -3.1098678708076477e-01
    z[1,2,5]  R873      -4.3563401699066162e-01
    z[1,2,5]  R874      4.3798366189002991e-01
    z[1,2,5]  R875      2.8272947669029236e-01
    z[1,2,5]  R876      2.6798954606056213e-01
    z[1,2,5]  R877      4.4543093442916870e-01
    z[1,2,5]  R878      1.1807820200920105e-01
    z[1,2,5]  R879      -2.0969074964523315e-01
    z[1,2,5]  R880      0.584648609161377
    z[1,2,5]  R881      4.6253389120101929e-01
    z[1,2,5]  R882      1.1077541112899780e-01
    z[1,2,5]  R883      3.1556141376495361e-01
    z[1,2,5]  R884      1.1781197786331177e-01
    z[1,2,5]  R885      3.8323265314102173e-01
    z[1,2,5]  R886      5.9083163738250732e-01
    z[1,2,5]  R887      5.3693127632141113e-01
    z[1,2,5]  R888      1.5663637220859528e-01
    z[1,2,5]  R889      4.1953021287918091e-01
    z[1,2,5]  R890      2.4167820811271667e-01
    z[1,2,5]  R891      2.1930266916751862e-01
    z[1,2,5]  R892      2.1439573168754578e-01
    z[1,2,5]  R893      2.9126736521720886e-01
    z[1,2,5]  R894      1.5991058945655823e-01
    z[1,2,5]  R895      9.4435155391693115e-02
    z[1,2,5]  R896      2.6526299118995667e-01
    z[1,2,5]  R897      3.2946422696113586e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R766      -1
    z[1,2,6]  R767      1
    z[1,2,6]  R768      -4.6854072809219360e-01
    z[1,2,6]  R769      -1.8549780547618866e-01
    z[1,2,6]  R770      -3.2859003543853760e-01
    z[1,2,6]  R771      -2.7782490849494934e-01
    z[1,2,6]  R772      -0.0677451640367508
    z[1,2,6]  R773      1.5936177968978882e-01
    z[1,2,6]  R774      2.4572479724884033e-01
    z[1,2,6]  R775      2.4274982511997223e-01
    z[1,2,6]  R776      3.2023850828409195e-02
    z[1,2,6]  R777      3.2487708330154419e-01
    z[1,2,6]  R778      2.5020885467529297e-01
    z[1,2,6]  R779      -2.3303854465484619e-01
    z[1,2,6]  R780      2.8261154890060425e-01
    z[1,2,6]  R781      -1.6217219829559326e-01
    z[1,2,6]  R782      2.0462350547313690e-01
    z[1,2,6]  R783      -3.4572128206491470e-02
    z[1,2,6]  R784      2.4441033601760864e-01
    z[1,2,6]  R785      1.2077458202838898e-01
    z[1,2,6]  R786      3.4495350718498230e-01
    z[1,2,6]  R787      0.470958948135376
    z[1,2,6]  R788      2.6052755117416382e-01
    z[1,2,6]  R789      -1.2949370779097080e-02
    z[1,2,6]  R790      2.4970626831054688e-01
    z[1,2,6]  R791      5.9450912475585938e-01
    z[1,2,6]  R792      -5.0955647230148315e-01
    z[1,2,6]  R793      -1.8352743983268738e-01
    z[1,2,6]  R794      -1.1067216284573078e-02
    z[1,2,6]  R795      -1.8066921830177307e-01
    z[1,2,6]  R796      -6.7055529356002808e-01
    z[1,2,6]  R797      3.8996872305870056e-01
    z[1,2,6]  R798      2.6779506355524063e-02
    z[1,2,6]  R799      1.9074784219264984e-01
    z[1,2,6]  R800      1.5408596396446228e-01
    z[1,2,6]  R801      -4.5079058408737183e-01
    z[1,2,6]  R802      -6.9441363215446472e-02
    z[1,2,6]  R803      -4.3850109796039760e-04
    z[1,2,6]  R804      4.8177537322044373e-01
    z[1,2,6]  R805      -0.126246377825737
    z[1,2,6]  R806      1.9304960966110229e-01
    z[1,2,6]  R807      1.7743013799190521e-01
    z[1,2,6]  R808      -1.7919200658798218e-01
    z[1,2,6]  R809      1.1737052351236343e-01
    z[1,2,6]  R810      -3.0322477221488953e-01
    z[1,2,6]  R811      -7.3339521884918213e-02
    z[1,2,6]  R812      -0.586080014705658
    z[1,2,6]  R813      1.4169251918792725e-01
    z[1,2,6]  R814      1.3314105570316315e-01
    z[1,2,6]  R815      2.2169493138790131e-01
    z[1,2,6]  R816      0.506830632686615
    z[1,2,6]  R817      -2.3363646864891052e-01
    z[1,2,6]  R818      4.2107634246349335e-02
    z[1,2,6]  R819      -1.0225398838520050e-01
    z[1,2,6]  R820      -1.1910647153854370e-01
    z[1,2,6]  R821      -4.8612681031227112e-01
    z[1,2,6]  R822      -1.8703129887580872e-01
    z[1,2,6]  R823      1.1156961321830750e-01
    z[1,2,6]  R824      -5.7398449629545212e-02
    z[1,2,6]  R825      1.1197334527969360e-01
    z[1,2,6]  R826      2.9366193339228630e-02
    z[1,2,6]  R827      -8.4692798554897308e-02
    z[1,2,6]  R828      3.4464153647422791e-01
    z[1,2,6]  R829      -2.0486536622047424e-01
    z[1,2,6]  R830      -0.359995037317276
    z[1,2,6]  R831      6.2019795179367065e-02
    z[1,2,6]  R832      -6.6353239119052887e-02
    z[1,2,6]  R833      -4.7712358832359314e-01
    z[1,2,6]  R834      -2.9085966944694519e-01
    z[1,2,6]  R835      1.4768464863300323e-01
    z[1,2,6]  R836      0.361070841550827
    z[1,2,6]  R837      6.4369112253189087e-01
    z[1,2,6]  R838      3.3611815422773361e-02
    z[1,2,6]  R839      5.8424003422260284e-02
    z[1,2,6]  R840      2.9420611262321472e-01
    z[1,2,6]  R841      3.5556632280349731e-01
    z[1,2,6]  R842      2.7982246875762939e-01
    z[1,2,6]  R843      -1.7918157577514648e-01
    z[1,2,6]  R844      -3.9160954952239990e-01
    z[1,2,6]  R845      2.5816816091537476e-01
    z[1,2,6]  R846      5.3819339722394943e-02
    z[1,2,6]  R847      1.6115494072437286e-01
    z[1,2,6]  R848      1.5988571941852570e-01
    z[1,2,6]  R849      5.4371935129165649e-01
    z[1,2,6]  R850      -2.3824411630630493e-01
    z[1,2,6]  R851      0.0323464460670948
    z[1,2,6]  R852      -3.2886481285095215e-01
    z[1,2,6]  R853      -2.0483744144439697e-01
    z[1,2,6]  R854      -6.2456015497446060e-02
    z[1,2,6]  R855      -6.0060225427150726e-02
    z[1,2,6]  R856      -3.7260480225086212e-02
    z[1,2,6]  R857      -8.9438818395137787e-02
    z[1,2,6]  R858      3.6358860135078430e-01
    z[1,2,6]  R859      -1.4429277181625366e-01
    z[1,2,6]  R860      2.7114427089691162e-01
    z[1,2,6]  R861      -3.8851892948150635e-01
    z[1,2,6]  R862      1.7991696298122406e-01
    z[1,2,6]  R863      -2.3394417762756348e-01
    z[1,2,6]  R864      0.236423060297966
    z[1,2,6]  R865      -3.3040741086006165e-01
    z[1,2,6]  R866      -2.5347569584846497e-01
    z[1,2,6]  R867      -4.4116694480180740e-02
    z[1,2,6]  R868      1.1758720874786377e-01
    z[1,2,6]  R869      1.5814271569252014e-01
    z[1,2,6]  R870      2.6673685759305954e-02
    z[1,2,6]  R871      -3.2572884112596512e-02
    z[1,2,6]  R872      1.0089663416147232e-01
    z[1,2,6]  R873      3.9931874722242355e-02
    z[1,2,6]  R874      2.9144637286663055e-02
    z[1,2,6]  R875      -2.0908041298389435e-01
    z[1,2,6]  R876      5.1410514116287231e-01
    z[1,2,6]  R877      5.5026924610137939e-01
    z[1,2,6]  R878      -0.227493554353714
    z[1,2,6]  R879      -2.5993982329964638e-02
    z[1,2,6]  R880      2.8447759151458740e-01
    z[1,2,6]  R881      5.4953861236572266e-01
    z[1,2,6]  R882      -2.9029166698455811e-01
    z[1,2,6]  R883      1.8050950765609741e-01
    z[1,2,6]  R884      4.4846269488334656e-01
    z[1,2,6]  R885      -6.0303188860416412e-02
    z[1,2,6]  R886      -2.7751579880714417e-01
    z[1,2,6]  R887      0.000607263995334506
    z[1,2,6]  R888      -8.4105335175991058e-02
    z[1,2,6]  R889      -1.8866260349750519e-01
    z[1,2,6]  R890      3.8933104276657104e-01
    z[1,2,6]  R891      -2.7347257733345032e-01
    z[1,2,6]  R892      -1.3086025416851044e-01
    z[1,2,6]  R893      -9.8307356238365173e-02
    z[1,2,6]  R894      2.1744383871555328e-01
    z[1,2,6]  R895      5.4348301142454147e-02
    z[1,2,6]  R896      7.5376674532890320e-02
    z[1,2,6]  R897      1.1221068352460861e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R898      -1
    z[2,1,0]  R899      1
    z[2,1,0]  R912      -2.6873114705085754e-01
    z[2,1,0]  R913      -3.2073151320219040e-02
    z[2,1,0]  R914      3.7537875771522522e-01
    z[2,1,0]  R915      3.6279532313346863e-01
    z[2,1,0]  R916      2.7410724759101868e-01
    z[2,1,0]  R917      3.4550437331199646e-01
    z[2,1,0]  R918      -3.4611618518829346e-01
    z[2,1,0]  R919      -1.3425517082214355e-01
    z[2,1,0]  R920      -3.1043639779090881e-01
    z[2,1,0]  R921      -2.7002862095832825e-01
    z[2,1,0]  R922      -6.6402232646942139e-01
    z[2,1,0]  R923      -9.0399205684661865e-01
    z[2,1,0]  R924      -0.804214358329773
    z[2,1,0]  R925      -7.4929600954055786e-01
    z[2,1,0]  R926      -5.9058940410614014e-01
    z[2,1,0]  R927      -1.7309513350483030e-04
    z[2,1,0]  R928      6.1451070010662079e-02
    z[2,1,0]  R929      2.2709189355373383e-01
    z[2,1,0]  R930      -1.8552179634571075e-01
    z[2,1,0]  R931      -3.4881201386451721e-01
    z[2,1,0]  R932      1.3089212775230408e-01
    z[2,1,0]  R933      -3.5005442332476377e-03
    z[2,1,0]  R934      5.3854632377624512e-01
    z[2,1,0]  R935      4.9122610688209534e-01
    z[2,1,0]  R936      4.4492509961128235e-01
    z[2,1,0]  R937      2.5517001748085022e-01
    z[2,1,0]  R938      5.1593577861785889e-01
    z[2,1,0]  R939      -2.5728667154908180e-02
    z[2,1,0]  R940      8.3634227514266968e-02
    z[2,1,0]  R941      3.6626616120338440e-01
    z[2,1,0]  R942      -8.9695248752832413e-03
    z[2,1,0]  R943      1.5972553193569183e-01
    z[2,1,0]  R944      -5.3645157814025879e-01
    z[2,1,0]  R945      6.3105231523513794e-01
    z[2,1,0]  R946      -4.2418235540390015e-01
    z[2,1,0]  R947      5.4071956872940063e-01
    z[2,1,0]  R948      2.4172581732273102e-01
    z[2,1,0]  R949      6.0971105098724365e-01
    z[2,1,0]  R950      1.7035140097141266e-01
    z[2,1,0]  R951      7.2460480034351349e-02
    z[2,1,0]  R952      -6.7582845687866211e-01
    z[2,1,0]  R953      -6.0512125492095947e-01
    z[2,1,0]  R954      1.4272104203701019e-01
    z[2,1,0]  R955      -7.2260481119155884e-01
    z[2,1,0]  R956      6.4754843711853027e-01
    z[2,1,0]  R957      7.0424085855484009e-01
    z[2,1,0]  R958      8.7252952158451080e-02
    z[2,1,0]  R959      1.3760389387607574e-01
    z[2,1,0]  R960      4.6381881833076477e-01
    z[2,1,0]  R961      -1.3176780939102173e-01
    z[2,1,0]  R962      2.5867810845375061e-01
    z[2,1,0]  R963      9.8589166998863220e-02
    z[2,1,0]  R964      -1.6886758804321289e-01
    z[2,1,0]  R965      -2.4934832006692886e-02
    z[2,1,0]  R966      -2.7765434980392456e-01
    z[2,1,0]  R967      -7.5552088022232056e-01
    z[2,1,0]  R968      -8.4898811578750610e-01
    z[2,1,0]  R969      3.0848824977874756e-01
    z[2,1,0]  R970      -4.2343363165855408e-01
    z[2,1,0]  R971      3.1179559230804443e-01
    z[2,1,0]  R972      3.2969641685485840e-01
    z[2,1,0]  R973      3.4860834479331970e-01
    z[2,1,0]  R974      -4.5325347781181335e-01
    z[2,1,0]  R975      -0.422927588224411
    z[2,1,0]  R976      -5.0999581813812256e-01
    z[2,1,0]  R977      -2.6431143283843994e-01
    z[2,1,0]  R978      4.9214616417884827e-02
    z[2,1,0]  R979      1.9649212062358856e-01
    z[2,1,0]  R980      0.422234445810318
    z[2,1,0]  R981      2.4938111007213593e-01
    z[2,1,0]  R982      8.8419675827026367e-02
    z[2,1,0]  R983      4.0276327729225159e-01
    z[2,1,0]  R984      0.631734311580658
    z[2,1,0]  R985      5.6486970186233521e-01
    z[2,1,0]  R986      5.7851821184158325e-01
    z[2,1,0]  R987      4.3736633658409119e-01
    z[2,1,0]  R988      2.5934025645256042e-01
    z[2,1,0]  R989      5.0061064958572388e-01
    z[2,1,0]  R990      1.2580172717571259e-01
    z[2,1,0]  R991      2.9341140389442444e-01
    z[2,1,0]  R992      4.2084982991218567e-01
    z[2,1,0]  R993      1.8046663701534271e-01
    z[2,1,0]  R994      3.0953222513198853e-01
    z[2,1,0]  R995      2.5165063142776489e-01
    z[2,1,0]  R996      1.2470825761556625e-01
    z[2,1,0]  R997      5.1459338515996933e-02
    z[2,1,0]  R998      2.2383508086204529e-01
    z[2,1,0]  R999      1.8951010704040527e-01
    z[2,1,0]  R1000     -5.1455962657928467e-01
    z[2,1,0]  R1001     -0.131059467792511
    z[2,1,0]  R1002     -4.5251451432704926e-02
    z[2,1,0]  R1003     -3.5671177506446838e-01
    z[2,1,0]  R1004     -4.2242676019668579e-02
    z[2,1,0]  R1005     -5.9709161520004272e-01
    z[2,1,0]  R1006     -7.8293181955814362e-02
    z[2,1,0]  R1007     -1.2750937603414059e-02
    z[2,1,0]  R1008     -6.8526011705398560e-01
    z[2,1,0]  R1009     -5.3374101407825947e-03
    z[2,1,0]  R1010     -7.7924764156341553e-01
    z[2,1,0]  R1011     -1.6494253277778625e-01
    z[2,1,0]  R1012     1.0237602144479752e-01
    z[2,1,0]  R1013     -9.1826446354389191e-02
    z[2,1,0]  R1014     -1.0050944983959198e-01
    z[2,1,0]  R1015     -6.5777927637100220e-02
    z[2,1,0]  R1016     -2.2169025242328644e-01
    z[2,1,0]  R1017     2.1646836772561073e-02
    z[2,1,0]  R1018     5.4830335080623627e-02
    z[2,1,0]  R1019     6.3755147159099579e-02
    z[2,1,0]  R1020     -3.9741796255111694e-01
    z[2,1,0]  R1021     1.9783353805541992e-01
    z[2,1,0]  R1022     9.0975388884544373e-02
    z[2,1,0]  R1023     7.3167368769645691e-02
    z[2,1,0]  R1024     2.3548530042171478e-01
    z[2,1,0]  R1025     2.6657110452651978e-01
    z[2,1,0]  R1026     1.6141006350517273e-01
    z[2,1,0]  R1027     -5.9019678831100464e-01
    z[2,1,0]  R1028     2.3474588990211487e-01
    z[2,1,0]  R1029     3.3537900447845459e-01
    z[2,1,0]  R1030     2.8809833526611328e-01
    z[2,1,0]  R1031     2.9013855382800102e-02
    z[2,1,0]  R1032     1.7178709805011749e-01
    z[2,1,0]  R1033     0.073527030646801
    z[2,1,0]  R1034     3.7063896656036377e-01
    z[2,1,0]  R1035     3.3976495265960693e-01
    z[2,1,0]  R1036     3.7903591990470886e-01
    z[2,1,0]  R1037     4.6893391013145447e-01
    z[2,1,0]  R1038     2.6620736718177795e-01
    z[2,1,0]  R1039     5.3020846843719482e-01
    z[2,1,0]  R1040     8.5024207830429077e-01
    z[2,1,0]  R1041     7.7913725376129150e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R900      -1
    z[2,1,1]  R901      1
    z[2,1,1]  R912      -2.1588015556335449e-01
    z[2,1,1]  R913      1.7628110945224762e-01
    z[2,1,1]  R914      -2.3755583167076111e-01
    z[2,1,1]  R915      2.0479236543178558e-01
    z[2,1,1]  R916      -1.3154593110084534e-01
    z[2,1,1]  R917      1.9905219972133636e-01
    z[2,1,1]  R918      -4.1699981689453125e-01
    z[2,1,1]  R919      -3.0128517746925354e-01
    z[2,1,1]  R920      -7.6194740831851959e-02
    z[2,1,1]  R921      0.209869846701622
    z[2,1,1]  R922      -4.0960386395454407e-01
    z[2,1,1]  R923      -1.5778750181198120e-01
    z[2,1,1]  R924      -2.4455009400844574e-01
    z[2,1,1]  R925      -2.5556573271751404e-01
    z[2,1,1]  R926      -3.8000097870826721e-01
    z[2,1,1]  R927      1.2717936933040619e-01
    z[2,1,1]  R928      1.5552307665348053e-01
    z[2,1,1]  R929      3.5584294237196445e-03
    z[2,1,1]  R930      3.0309504270553589e-01
    z[2,1,1]  R931      0.143227681517601
    z[2,1,1]  R932      6.7356717586517334e-01
    z[2,1,1]  R933      8.2480198144912720e-01
    z[2,1,1]  R934      5.6491744518280029e-01
    z[2,1,1]  R935      -7.3912781476974487e-01
    z[2,1,1]  R936      -6.5501809120178223e-01
    z[2,1,1]  R937      -5.0831407308578491e-01
    z[2,1,1]  R938      -5.9823578596115112e-01
    z[2,1,1]  R939      8.8219058513641357e-01
    z[2,1,1]  R940      8.8769757747650146e-01
    z[2,1,1]  R941      4.5806637406349182e-01
    z[2,1,1]  R942      1.8596200644969940e-01
    z[2,1,1]  R943      7.1757632493972778e-01
    z[2,1,1]  R944      -3.8152185082435608e-01
    z[2,1,1]  R945      1.4021593332290649e-01
    z[2,1,1]  R946      -3.7752085924148560e-01
    z[2,1,1]  R947      0.69268798828125
    z[2,1,1]  R948      -6.1385488510131836e-01
    z[2,1,1]  R949      6.0728186368942261e-01
    z[2,1,1]  R950      -4.8250687122344971e-01
    z[2,1,1]  R951      -7.0133811235427856e-01
    z[2,1,1]  R952      -5.4359430074691772e-01
    z[2,1,1]  R953      -4.9089613556861877e-01
    z[2,1,1]  R954      2.6800769567489624e-01
    z[2,1,1]  R955      -4.0371596813201904e-01
    z[2,1,1]  R956      0.409095823764801
    z[2,1,1]  R957      6.2194281816482544e-01
    z[2,1,1]  R958      -3.8345479965209961e-01
    z[2,1,1]  R959      9.3600398302078247e-01
    z[2,1,1]  R960      -5.5373638868331909e-01
    z[2,1,1]  R961      9.1260397434234619e-01
    z[2,1,1]  R962      1.5924791991710663e-01
    z[2,1,1]  R963      3.9333915710449219e-01
    z[2,1,1]  R964      3.0031278729438782e-01
    z[2,1,1]  R965      6.2737494707107544e-01
    z[2,1,1]  R966      2.1992325782775879e-01
    z[2,1,1]  R967      -4.1509312391281128e-01
    z[2,1,1]  R968      -4.1287493705749512e-01
    z[2,1,1]  R969      8.0462110042572021e-01
    z[2,1,1]  R970      -3.6295115947723389e-01
    z[2,1,1]  R971      -6.9650501012802124e-01
    z[2,1,1]  R972      -6.7203216254711151e-02
    z[2,1,1]  R973      8.0494272708892822e-01
    z[2,1,1]  R974      -3.9140564203262329e-01
    z[2,1,1]  R975      4.6580326557159424e-01
    z[2,1,1]  R976      3.8096180558204651e-01
    z[2,1,1]  R977      1.5873104333877563e-01
    z[2,1,1]  R978      1.4601269364356995e-01
    z[2,1,1]  R979      2.3214745521545410e-01
    z[2,1,1]  R980      -5.8443200588226318e-01
    z[2,1,1]  R981      -4.8416009545326233e-01
    z[2,1,1]  R982      -4.8915907740592957e-01
    z[2,1,1]  R983      -5.4353523254394531e-01
    z[2,1,1]  R984      3.3106356859207153e-01
    z[2,1,1]  R985      0.0721365436911583
    z[2,1,1]  R986      2.4072538316249847e-01
    z[2,1,1]  R987      -4.7887992858886719e-01
    z[2,1,1]  R988      -3.7768241763114929e-01
    z[2,1,1]  R989      -3.6895516514778137e-01
    z[2,1,1]  R990      -3.3499330282211304e-01
    z[2,1,1]  R991      -2.3496727645397186e-01
    z[2,1,1]  R992      -0.631965160369873
    z[2,1,1]  R993      -5.7080310583114624e-01
    z[2,1,1]  R994      -4.0810176730155945e-01
    z[2,1,1]  R995      -2.2940079867839813e-01
    z[2,1,1]  R996      -2.9745447635650635e-01
    z[2,1,1]  R997      -1.1915975809097290e-01
    z[2,1,1]  R998      6.0840494930744171e-02
    z[2,1,1]  R999      -2.8783810138702393e-01
    z[2,1,1]  R1000     6.6480404138565063e-01
    z[2,1,1]  R1001     5.4802858829498291e-01
    z[2,1,1]  R1002     -4.1153582930564880e-01
    z[2,1,1]  R1003     0.573833703994751
    z[2,1,1]  R1004     -0.366733580827713
    z[2,1,1]  R1005     2.7760806679725647e-01
    z[2,1,1]  R1006     -4.9850201606750488e-01
    z[2,1,1]  R1007     -0.262656033039093
    z[2,1,1]  R1008     3.9246013760566711e-01
    z[2,1,1]  R1009     -2.8604340553283691e-01
    z[2,1,1]  R1010     1.2124329805374146e-01
    z[2,1,1]  R1011     5.4653489589691162e-01
    z[2,1,1]  R1012     -7.8913533687591553e-01
    z[2,1,1]  R1013     -7.8548103570938110e-01
    z[2,1,1]  R1014     -7.8021126985549927e-01
    z[2,1,1]  R1015     -7.6294887065887451e-01
    z[2,1,1]  R1016     -7.4078255891799927e-01
    z[2,1,1]  R1017     -7.4767166376113892e-01
    z[2,1,1]  R1018     -6.2841165065765381e-01
    z[2,1,1]  R1019     -7.1363770961761475e-01
    z[2,1,1]  R1020     -6.6738867759704590e-01
    z[2,1,1]  R1021     -5.4265409708023071e-01
    z[2,1,1]  R1022     -8.6383581161499023e-01
    z[2,1,1]  R1023     -4.6129563450813293e-01
    z[2,1,1]  R1024     -5.1387935876846313e-01
    z[2,1,1]  R1025     -4.2744708061218262e-01
    z[2,1,1]  R1026     -0.583754301071167
    z[2,1,1]  R1027     1.9236426055431366e-01
    z[2,1,1]  R1028     -3.0478119850158691e-01
    z[2,1,1]  R1029     -4.9917593598365784e-01
    z[2,1,1]  R1030     -5.3909343481063843e-01
    z[2,1,1]  R1031     5.0474762916564941e-01
    z[2,1,1]  R1032     -5.4632717370986938e-01
    z[2,1,1]  R1033     -5.4762643575668335e-01
    z[2,1,1]  R1034     -1.4396350085735321e-01
    z[2,1,1]  R1035     -2.5115618109703064e-01
    z[2,1,1]  R1036     -4.8610472679138184e-01
    z[2,1,1]  R1037     4.6591964364051819e-01
    z[2,1,1]  R1038     5.2314704656600952e-01
    z[2,1,1]  R1039     4.5538052916526794e-01
    z[2,1,1]  R1040     3.7054851651191711e-01
    z[2,1,1]  R1041     3.2702940702438354e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R902      -1
    z[2,1,2]  R903      1
    z[2,1,2]  R912      -3.9520934224128723e-01
    z[2,1,2]  R913      -6.5507078170776367e-01
    z[2,1,2]  R914      -6.7343634366989136e-01
    z[2,1,2]  R915      -7.1022748947143555e-01
    z[2,1,2]  R916      -3.5012489557266235e-01
    z[2,1,2]  R917      -2.4349214136600494e-01
    z[2,1,2]  R918      -7.4231493473052979e-01
    z[2,1,2]  R919      -5.1035708189010620e-01
    z[2,1,2]  R920      -4.5079621672630310e-01
    z[2,1,2]  R921      -3.3830073475837708e-01
    z[2,1,2]  R922      2.1875385940074921e-01
    z[2,1,2]  R923      3.3716621994972229e-01
    z[2,1,2]  R924      4.4088739156723022e-01
    z[2,1,2]  R925      2.2630555927753448e-01
    z[2,1,2]  R926      5.4999870061874390e-01
    z[2,1,2]  R927      8.7424147129058838e-01
    z[2,1,2]  R928      9.4849610328674316e-01
    z[2,1,2]  R929      9.5662963390350342e-01
    z[2,1,2]  R930      8.9228767156600952e-01
    z[2,1,2]  R931      8.1086415052413940e-01
    z[2,1,2]  R932      -4.1185855865478516e-01
    z[2,1,2]  R933      -1.9162485376000404e-02
    z[2,1,2]  R934      2.8008872270584106e-01
    z[2,1,2]  R935      4.0162590146064758e-01
    z[2,1,2]  R936      4.4733661413192749e-01
    z[2,1,2]  R937      0.568046510219574
    z[2,1,2]  R938      2.8434932231903076e-01
    z[2,1,2]  R939      3.1677380204200745e-01
    z[2,1,2]  R940      1.1546524614095688e-01
    z[2,1,2]  R941      -1.6543051600456238e-01
    z[2,1,2]  R942      -0.0796266719698906
    z[2,1,2]  R943      -2.9266723990440369e-01
    z[2,1,2]  R944      -2.8603881597518921e-01
    z[2,1,2]  R945      -3.5321470350027084e-02
    z[2,1,2]  R946      1.1452263593673706e-01
    z[2,1,2]  R947      1.4027774333953857e-02
    z[2,1,2]  R948      0.628491997718811
    z[2,1,2]  R949      3.4253127872943878e-02
    z[2,1,2]  R950      6.6206520795822144e-01
    z[2,1,2]  R951      6.2908381223678589e-01
    z[2,1,2]  R952      2.9503282904624939e-01
    z[2,1,2]  R953      -1.2889644131064415e-02
    z[2,1,2]  R954      -3.6238917708396912e-01
    z[2,1,2]  R955      -1.2910751998424530e-01
    z[2,1,2]  R956      2.9581716284155846e-02
    z[2,1,2]  R957      -5.8643147349357605e-02
    z[2,1,2]  R958      7.1621578931808472e-01
    z[2,1,2]  R959      1.7335261404514313e-01
    z[2,1,2]  R960      0.579522430896759
    z[2,1,2]  R961      -1.2586662545800209e-02
    z[2,1,2]  R962      -0.60338294506073
    z[2,1,2]  R963      -2.8439977765083313e-01
    z[2,1,2]  R964      -5.1153934001922607e-01
    z[2,1,2]  R965      -1.1169648915529251e-01
    z[2,1,2]  R966      -5.5183249711990356e-01
    z[2,1,2]  R967      -7.1597069501876831e-02
    z[2,1,2]  R968      7.9120278358459473e-02
    z[2,1,2]  R969      -3.7630371749401093e-02
    z[2,1,2]  R970      1.3049761950969696e-01
    z[2,1,2]  R971      6.2702363729476929e-01
    z[2,1,2]  R972      -7.2930544614791870e-01
    z[2,1,2]  R973      -3.3465901017189026e-01
    z[2,1,2]  R974      3.6644306033849716e-02
    z[2,1,2]  R975      7.0993721485137939e-01
    z[2,1,2]  R976      0.539761483669281
    z[2,1,2]  R977      0.705171525478363
    z[2,1,2]  R978      9.0713568031787872e-02
    z[2,1,2]  R979      -1.1441487073898315e-01
    z[2,1,2]  R980      3.7345755100250244e-01
    z[2,1,2]  R981      4.0972551703453064e-01
    z[2,1,2]  R982      7.2683101892471313e-01
    z[2,1,2]  R983      6.2340795993804932e-01
    z[2,1,2]  R984      1.4043259620666504e-01
    z[2,1,2]  R985      -1.3547022640705109e-01
    z[2,1,2]  R986      1.2957191467285156e-01
    z[2,1,2]  R987      4.8817488551139832e-01
    z[2,1,2]  R988      5.4580259323120117e-01
    z[2,1,2]  R989      4.9789234995841980e-01
    z[2,1,2]  R990      -2.2322230041027069e-01
    z[2,1,2]  R991      -2.6471281051635742e-01
    z[2,1,2]  R992      6.1506575345993042e-01
    z[2,1,2]  R993      4.2768985033035278e-01
    z[2,1,2]  R994      5.0138247013092041e-01
    z[2,1,2]  R995      -1.3325053453445435e-01
    z[2,1,2]  R996      -8.8966287672519684e-02
    z[2,1,2]  R997      1.1987017840147018e-01
    z[2,1,2]  R998      -2.1370720863342285e-01
    z[2,1,2]  R999      -1.6838872432708740e-01
    z[2,1,2]  R1000     2.0024140179157257e-01
    z[2,1,2]  R1001     4.3591436743736267e-01
    z[2,1,2]  R1002     5.0443840026855469e-01
    z[2,1,2]  R1003     -4.9243211746215820e-01
    z[2,1,2]  R1004     1.2689022719860077e-01
    z[2,1,2]  R1005     -0.626781165599823
    z[2,1,2]  R1006     7.9153716564178467e-01
    z[2,1,2]  R1007     7.2913813591003418e-01
    z[2,1,2]  R1008     -4.3528309464454651e-01
    z[2,1,2]  R1009     3.0553472042083740e-01
    z[2,1,2]  R1010     -5.4495644569396973e-01
    z[2,1,2]  R1011     -7.0033740997314453e-01
    z[2,1,2]  R1012     -3.6397790908813477e-01
    z[2,1,2]  R1013     -2.8767114877700806e-01
    z[2,1,2]  R1014     -3.3676931262016296e-01
    z[2,1,2]  R1015     -3.1985855102539062e-01
    z[2,1,2]  R1016     -2.3950286209583282e-01
    z[2,1,2]  R1017     -1.2533517181873322e-01
    z[2,1,2]  R1018     1.7164391279220581e-01
    z[2,1,2]  R1019     -2.3216864466667175e-01
    z[2,1,2]  R1020     1.0192343033850193e-03
    z[2,1,2]  R1021     9.2219136655330658e-02
    z[2,1,2]  R1022     1.1176556348800659e-01
    z[2,1,2]  R1023     3.0754688382148743e-01
    z[2,1,2]  R1024     0.3104248046875
    z[2,1,2]  R1025     4.3009561300277710e-01
    z[2,1,2]  R1026     -1.9003529846668243e-01
    z[2,1,2]  R1027     -3.1999304890632629e-01
    z[2,1,2]  R1028     5.9365980327129364e-02
    z[2,1,2]  R1029     5.3292375802993774e-01
    z[2,1,2]  R1030     1.1547703295946121e-01
    z[2,1,2]  R1031     3.5850954055786133e-01
    z[2,1,2]  R1032     1.8182796239852905e-01
    z[2,1,2]  R1033     5.6437408924102783e-01
    z[2,1,2]  R1034     7.5032621622085571e-01
    z[2,1,2]  R1035     1.2528024613857269e-01
    z[2,1,2]  R1036     2.2773987054824829e-01
    z[2,1,2]  R1037     2.6856359094381332e-02
    z[2,1,2]  R1038     1.8239600956439972e-01
    z[2,1,2]  R1039     2.3532277345657349e-01
    z[2,1,2]  R1040     1.6897714138031006e-01
    z[2,1,2]  R1041     6.8543985486030579e-02
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R904      -1
    z[2,1,3]  R905      1
    z[2,1,3]  R912      5.8361768722534180e-01
    z[2,1,3]  R913      4.6935808658599854e-01
    z[2,1,3]  R914      4.0347889065742493e-01
    z[2,1,3]  R915      5.5925935506820679e-01
    z[2,1,3]  R916      4.1561439633369446e-01
    z[2,1,3]  R917      8.5939311981201172e-01
    z[2,1,3]  R918      0.275499552488327
    z[2,1,3]  R919      7.4122303724288940e-01
    z[2,1,3]  R920      5.0755894184112549e-01
    z[2,1,3]  R921      1.4604271948337555e-01
    z[2,1,3]  R922      -4.8070603609085083e-01
    z[2,1,3]  R923      -0.170390784740448
    z[2,1,3]  R924      3.8864649832248688e-02
    z[2,1,3]  R925      -0.148195281624794
    z[2,1,3]  R926      -0.068141870200634
    z[2,1,3]  R927      0.0461047999560833
    z[2,1,3]  R928      7.8676626086235046e-02
    z[2,1,3]  R929      1.0513123869895935e-01
    z[2,1,3]  R930      0.0667092427611351
    z[2,1,3]  R931      2.0522156357765198e-01
    z[2,1,3]  R932      -2.3449407517910004e-01
    z[2,1,3]  R933      -1.1086897552013397e-01
    z[2,1,3]  R934      1.3058193027973175e-01
    z[2,1,3]  R935      -1.5165399014949799e-01
    z[2,1,3]  R936      -3.3748653531074524e-01
    z[2,1,3]  R937      -3.0212721228599548e-01
    z[2,1,3]  R938      -1.4454054832458496e-01
    z[2,1,3]  R939      -0.0949816182255745
    z[2,1,3]  R940      -0.00844635721296072
    z[2,1,3]  R941      -0.072464220225811
    z[2,1,3]  R942      2.6678740978240967e-01
    z[2,1,3]  R943      1.5070120804011822e-02
    z[2,1,3]  R944      -5.3139245510101318e-01
    z[2,1,3]  R945      -2.8727075085043907e-02
    z[2,1,3]  R946      -9.5711521804332733e-02
    z[2,1,3]  R947      -7.4008852243423462e-02
    z[2,1,3]  R948      9.4357088208198547e-02
    z[2,1,3]  R949      -5.3052004426717758e-02
    z[2,1,3]  R950      -2.3163458704948425e-01
    z[2,1,3]  R951      2.2300805151462555e-01
    z[2,1,3]  R952      1.6113524138927460e-01
    z[2,1,3]  R953      -2.3640665411949158e-01
    z[2,1,3]  R954      -3.4317496418952942e-01
    z[2,1,3]  R955      -3.7083217501640320e-01
    z[2,1,3]  R956      -9.3176349997520447e-02
    z[2,1,3]  R957      -7.2438023984432220e-02
    z[2,1,3]  R958      -3.0139824748039246e-01
    z[2,1,3]  R959      -1.7185065150260925e-01
    z[2,1,3]  R960      -1.4382113516330719e-01
    z[2,1,3]  R961      -1.5414026379585266e-01
    z[2,1,3]  R962      2.1110512316226959e-01
    z[2,1,3]  R963      -3.6252435296773911e-02
    z[2,1,3]  R964      -0.321154922246933
    z[2,1,3]  R965      1.9282083213329315e-01
    z[2,1,3]  R966      -1.6128194332122803e-01
    z[2,1,3]  R967      -1.8521138699725270e-03
    z[2,1,3]  R968      -1.4850957691669464e-01
    z[2,1,3]  R969      2.2216208279132843e-01
    z[2,1,3]  R970      -1.8443416059017181e-01
    z[2,1,3]  R971      -5.6029386818408966e-02
    z[2,1,3]  R972      1.2959238886833191e-01
    z[2,1,3]  R973      4.5644771307706833e-02
    z[2,1,3]  R974      -1.8064694106578827e-01
    z[2,1,3]  R975      8.3385735750198364e-02
    z[2,1,3]  R976      2.6409700512886047e-01
    z[2,1,3]  R977      3.6392763257026672e-01
    z[2,1,3]  R978      -0.806171178817749
    z[2,1,3]  R979      -8.5051637887954712e-01
    z[2,1,3]  R980      6.0818102210760117e-02
    z[2,1,3]  R981      -1.5635755658149719e-01
    z[2,1,3]  R982      -5.2543841302394867e-02
    z[2,1,3]  R983      -2.5762656331062317e-01
    z[2,1,3]  R984      5.9513457119464874e-02
    z[2,1,3]  R985      1.8277665600180626e-02
    z[2,1,3]  R986      1.0919960588216782e-01
    z[2,1,3]  R987      -4.5451596379280090e-01
    z[2,1,3]  R988      -4.6350872516632080e-01
    z[2,1,3]  R989      3.5328158736228943e-01
    z[2,1,3]  R990      -4.3283212184906006e-01
    z[2,1,3]  R991      -5.5757224559783936e-01
    z[2,1,3]  R992      -3.1490195542573929e-02
    z[2,1,3]  R993      -9.0821079909801483e-02
    z[2,1,3]  R994      -4.4099974632263184e-01
    z[2,1,3]  R995      -8.5201394557952881e-01
    z[2,1,3]  R996      -7.7582234144210815e-01
    z[2,1,3]  R997      -0.92115718126297
    z[2,1,3]  R998      -9.0703666210174561e-01
    z[2,1,3]  R999      -8.0508148670196533e-01
    z[2,1,3]  R1000     1.9683811068534851e-01
    z[2,1,3]  R1001     -1.1682634800672531e-01
    z[2,1,3]  R1002     5.3050768375396729e-01
    z[2,1,3]  R1003     2.4304993450641632e-01
    z[2,1,3]  R1004     0.799430251121521
    z[2,1,3]  R1005     1.0718559473752975e-01
    z[2,1,3]  R1006     1.0570231825113297e-01
    z[2,1,3]  R1007     5.6906795501708984e-01
    z[2,1,3]  R1008     1.5660229325294495e-01
    z[2,1,3]  R1009     6.4447224140167236e-01
    z[2,1,3]  R1010     2.4263779819011688e-01
    z[2,1,3]  R1011     1.3728702068328857e-01
    z[2,1,3]  R1012     0.174093097448349
    z[2,1,3]  R1013     -2.9917600750923157e-01
    z[2,1,3]  R1014     -3.9608660340309143e-01
    z[2,1,3]  R1015     -4.9124431610107422e-01
    z[2,1,3]  R1016     -4.4795447587966919e-01
    z[2,1,3]  R1017     -4.1094160079956055e-01
    z[2,1,3]  R1018     -4.0366217494010925e-01
    z[2,1,3]  R1019     -4.2908832430839539e-01
    z[2,1,3]  R1020     -1.9940476119518280e-01
    z[2,1,3]  R1021     -5.6705063581466675e-01
    z[2,1,3]  R1022     1.2812471017241478e-02
    z[2,1,3]  R1023     3.9192914962768555e-01
    z[2,1,3]  R1024     -1.0241139680147171e-01
    z[2,1,3]  R1025     -2.2310981154441833e-01
    z[2,1,3]  R1026     -5.0097241997718811e-02
    z[2,1,3]  R1027     5.2560776472091675e-02
    z[2,1,3]  R1028     2.0923748612403870e-01
    z[2,1,3]  R1029     1.9200769066810608e-01
    z[2,1,3]  R1030     8.4713473916053772e-02
    z[2,1,3]  R1031     6.5258580446243286e-01
    z[2,1,3]  R1032     7.9723989963531494e-01
    z[2,1,3]  R1033     5.0779759883880615e-01
    z[2,1,3]  R1034     1.6282172501087189e-01
    z[2,1,3]  R1035     4.7349786758422852e-01
    z[2,1,3]  R1036     8.6323969066143036e-02
    z[2,1,3]  R1037     3.1835392117500305e-01
    z[2,1,3]  R1038     -2.1111611276865005e-02
    z[2,1,3]  R1039     6.1433070898056030e-01
    z[2,1,3]  R1040     -1.2037465721368790e-01
    z[2,1,3]  R1041     -4.6486461162567139e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R906      -1
    z[2,1,4]  R907      1
    z[2,1,4]  R912      -1.3866421580314636e-01
    z[2,1,4]  R913      0.4262675344944
    z[2,1,4]  R914      1.2889516353607178e-01
    z[2,1,4]  R915      -2.1842949092388153e-02
    z[2,1,4]  R916      -3.7414006888866425e-02
    z[2,1,4]  R917      -9.2173544690012932e-03
    z[2,1,4]  R918      9.3282364308834076e-02
    z[2,1,4]  R919      1.4299346506595612e-01
    z[2,1,4]  R920      1.1714073270559311e-01
    z[2,1,4]  R921      3.7614884972572327e-01
    z[2,1,4]  R922      0.0735994279384613
    z[2,1,4]  R923      6.7542046308517456e-02
    z[2,1,4]  R924      2.3088328540325165e-01
    z[2,1,4]  R925      -9.5550626516342163e-02
    z[2,1,4]  R926      -1.7954094707965851e-01
    z[2,1,4]  R927      3.1480357050895691e-01
    z[2,1,4]  R928      1.8796192109584808e-01
    z[2,1,4]  R929      8.3698770031332970e-03
    z[2,1,4]  R930      0.0705980509519577
    z[2,1,4]  R931      2.6583236455917358e-01
    z[2,1,4]  R932      -3.7515938282012939e-01
    z[2,1,4]  R933      -4.4282034039497375e-01
    z[2,1,4]  R934      -1.6256643831729889e-01
    z[2,1,4]  R935      1.1624976247549057e-01
    z[2,1,4]  R936      2.3277167975902557e-01
    z[2,1,4]  R937      1.8302576243877411e-01
    z[2,1,4]  R938      2.3575511574745178e-01
    z[2,1,4]  R939      -9.6358023583889008e-02
    z[2,1,4]  R940      1.0487534105777740e-01
    z[2,1,4]  R941      -2.3561987280845642e-01
    z[2,1,4]  R942      -9.4050276279449463e-01
    z[2,1,4]  R943      -5.3487664461135864e-01
    z[2,1,4]  R944      -5.0266232341527939e-02
    z[2,1,4]  R945      -3.7714448571205139e-01
    z[2,1,4]  R946      7.5331604480743408e-01
    z[2,1,4]  R947      4.3590095639228821e-01
    z[2,1,4]  R948      5.7433921843767166e-02
    z[2,1,4]  R949      -0.0620078481733799
    z[2,1,4]  R950      4.7839531302452087e-01
    z[2,1,4]  R951      1.7153675854206085e-01
    z[2,1,4]  R952      -2.6997578144073486e-01
    z[2,1,4]  R953      1.3102343678474426e-01
    z[2,1,4]  R954      -6.5804773569107056e-01
    z[2,1,4]  R955      -2.1013745665550232e-01
    z[2,1,4]  R956      -0.456379771232605
    z[2,1,4]  R957      2.5651317834854126e-01
    z[2,1,4]  R958      4.8555487394332886e-01
    z[2,1,4]  R959      0.181008979678154
    z[2,1,4]  R960      -2.8443282842636108e-01
    z[2,1,4]  R961      -6.0795680619776249e-03
    z[2,1,4]  R962      -5.2893245220184326e-01
    z[2,1,4]  R963      -7.8231376409530640e-01
    z[2,1,4]  R964      -5.5640321969985962e-01
    z[2,1,4]  R965      -6.1660176515579224e-01
    z[2,1,4]  R966      -3.5854494571685791e-01
    z[2,1,4]  R967      3.8253688812255859e-01
    z[2,1,4]  R968      -1.3372954726219177e-01
    z[2,1,4]  R969      4.8215255141258240e-02
    z[2,1,4]  R970      -7.5708419084548950e-01
    z[2,1,4]  R971      -8.2201175391674042e-02
    z[2,1,4]  R972      -1.6545540094375610e-01
    z[2,1,4]  R973      -1.9630345702171326e-01
    z[2,1,4]  R974      -0.774272620677948
    z[2,1,4]  R975      2.1603046357631683e-01
    z[2,1,4]  R976      -3.5607546567916870e-01
    z[2,1,4]  R977      -2.8958949446678162e-01
    z[2,1,4]  R978      -3.5417255759239197e-01
    z[2,1,4]  R979      -2.1766684949398041e-01
    z[2,1,4]  R980      -2.9416689649224281e-02
    z[2,1,4]  R981      9.9350109696388245e-02
    z[2,1,4]  R982      3.9517775177955627e-01
    z[2,1,4]  R983      0.206630676984787
    z[2,1,4]  R984      2.1284732222557068e-01
    z[2,1,4]  R985      3.7563538551330566e-01
    z[2,1,4]  R986      6.9434428215026855e-01
    z[2,1,4]  R987      -4.8193059861660004e-02
    z[2,1,4]  R988      2.4971835315227509e-01
    z[2,1,4]  R989      0.300087571144104
    z[2,1,4]  R990      -4.5681995153427124e-01
    z[2,1,4]  R991      -4.3525260686874390e-01
    z[2,1,4]  R992      1.1224637180566788e-01
    z[2,1,4]  R993      4.8872217535972595e-01
    z[2,1,4]  R994      2.8599053621292114e-01
    z[2,1,4]  R995      -1.3222269713878632e-01
    z[2,1,4]  R996      -4.7229605913162231e-01
    z[2,1,4]  R997      -1.6047553718090057e-01
    z[2,1,4]  R998      7.0403993129730225e-02
    z[2,1,4]  R999      4.3914973735809326e-01
    z[2,1,4]  R1000     3.7198930978775024e-01
    z[2,1,4]  R1001     5.9806394577026367e-01
    z[2,1,4]  R1002     2.6285862922668457e-01
    z[2,1,4]  R1003     2.0473259687423706e-01
    z[2,1,4]  R1004     2.8543433547019958e-01
    z[2,1,4]  R1005     1.7861008644104004e-01
    z[2,1,4]  R1006     3.9897285401821136e-02
    z[2,1,4]  R1007     -1.0376599431037903e-01
    z[2,1,4]  R1008     2.9115831851959229e-01
    z[2,1,4]  R1009     5.5429106950759888e-01
    z[2,1,4]  R1010     -1.4271882176399231e-01
    z[2,1,4]  R1011     -1.6991877555847168e-01
    z[2,1,4]  R1012     -3.5168644785881042e-01
    z[2,1,4]  R1013     -2.1051105856895447e-01
    z[2,1,4]  R1014     1.6175056993961334e-01
    z[2,1,4]  R1015     1.5208730101585388e-01
    z[2,1,4]  R1016     -1.2244738638401031e-01
    z[2,1,4]  R1017     2.9136139154434204e-01
    z[2,1,4]  R1018     8.3066321909427643e-02
    z[2,1,4]  R1019     2.1944449841976166e-01
    z[2,1,4]  R1020     2.4374271929264069e-01
    z[2,1,4]  R1021     2.9229193925857544e-01
    z[2,1,4]  R1022     3.7499007582664490e-01
    z[2,1,4]  R1023     -5.2446460723876953e-01
    z[2,1,4]  R1024     1.5510775148868561e-01
    z[2,1,4]  R1025     -3.1334522366523743e-01
    z[2,1,4]  R1026     0.34656822681427
    z[2,1,4]  R1027     -2.3756182193756104e-01
    z[2,1,4]  R1028     3.7706881761550903e-01
    z[2,1,4]  R1029     -5.1656424999237061e-01
    z[2,1,4]  R1030     -3.3346924185752869e-01
    z[2,1,4]  R1031     2.6950253173708916e-02
    z[2,1,4]  R1032     0.00511670857667923
    z[2,1,4]  R1033     1.8650548160076141e-01
    z[2,1,4]  R1034     4.6590843796730042e-01
    z[2,1,4]  R1035     1.1250261217355728e-01
    z[2,1,4]  R1036     -5.7950061559677124e-01
    z[2,1,4]  R1037     -5.7460999488830566e-01
    z[2,1,4]  R1038     -3.1709730625152588e-01
    z[2,1,4]  R1039     -1.8819181621074677e-01
    z[2,1,4]  R1040     2.0447519421577454e-01
    z[2,1,4]  R1041     1.5613253414630890e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R908      -1
    z[2,1,5]  R909      1
    z[2,1,5]  R912      -5.7709765434265137e-01
    z[2,1,5]  R913      -3.5071596503257751e-01
    z[2,1,5]  R914      -0.278903067111969
    z[2,1,5]  R915      5.8221589773893356e-02
    z[2,1,5]  R916      -0.517057478427887
    z[2,1,5]  R917      -1.5165178477764130e-01
    z[2,1,5]  R918      -2.3012003302574158e-01
    z[2,1,5]  R919      -1.0831041634082794e-01
    z[2,1,5]  R920      -4.0791058540344238e-01
    z[2,1,5]  R921      -7.4242120981216431e-01
    z[2,1,5]  R922      3.2431101799011230e-01
    z[2,1,5]  R923      1.3020985759794712e-02
    z[2,1,5]  R924      1.7334592342376709e-01
    z[2,1,5]  R925      2.3370157182216644e-01
    z[2,1,5]  R926      3.6393117904663086e-01
    z[2,1,5]  R927      3.2534962892532349e-01
    z[2,1,5]  R928      0.166063129901886
    z[2,1,5]  R929      9.8060876131057739e-02
    z[2,1,5]  R930      2.5930896401405334e-01
    z[2,1,5]  R931      2.8347793221473694e-01
    z[2,1,5]  R932      -2.1221968531608582e-01
    z[2,1,5]  R933      -2.6262289285659790e-01
    z[2,1,5]  R934      3.7324330210685730e-01
    z[2,1,5]  R935      1.0355718433856964e-01
    z[2,1,5]  R936      -2.0006487146019936e-02
    z[2,1,5]  R937      3.7442959845066071e-02
    z[2,1,5]  R938      3.6605718731880188e-01
    z[2,1,5]  R939      2.8392788767814636e-01
    z[2,1,5]  R940      2.2410650551319122e-01
    z[2,1,5]  R941      3.9185580611228943e-01
    z[2,1,5]  R942      -4.6332050114870071e-02
    z[2,1,5]  R943      -2.9014545679092407e-01
    z[2,1,5]  R944      3.3672028779983521e-01
    z[2,1,5]  R945      5.5800926685333252e-01
    z[2,1,5]  R946      0.097394198179245
    z[2,1,5]  R947      3.9934930391609669e-03
    z[2,1,5]  R948      6.4718961715698242e-02
    z[2,1,5]  R949      4.3009036779403687e-01
    z[2,1,5]  R950      -1.2009969353675842e-01
    z[2,1,5]  R951      0.0447159968316555
    z[2,1,5]  R952      1.9053022563457489e-01
    z[2,1,5]  R953      1.5491028130054474e-01
    z[2,1,5]  R954      -4.1099965572357178e-01
    z[2,1,5]  R955      -3.3980360627174377e-01
    z[2,1,5]  R956      2.9551693797111511e-01
    z[2,1,5]  R957      2.8076082468032837e-02
    z[2,1,5]  R958      4.3349310755729675e-02
    z[2,1,5]  R959      0.0949019193649292
    z[2,1,5]  R960      -1.9856201112270355e-01
    z[2,1,5]  R961      3.4327441453933716e-01
    z[2,1,5]  R962      -0.295166552066803
    z[2,1,5]  R963      -3.4717667102813721e-01
    z[2,1,5]  R964      -3.6521118879318237e-01
    z[2,1,5]  R965      -1.5804505348205566e-01
    z[2,1,5]  R966      -6.1893957853317261e-01
    z[2,1,5]  R967      2.2514855861663818e-01
    z[2,1,5]  R968      -8.1602893769741058e-02
    z[2,1,5]  R969      -3.0847036838531494e-01
    z[2,1,5]  R970      -2.2324765101075172e-02
    z[2,1,5]  R971      -1.1252982169389725e-01
    z[2,1,5]  R972      -5.4488635063171387e-01
    z[2,1,5]  R973      -2.3003305494785309e-01
    z[2,1,5]  R974      8.4717579185962677e-02
    z[2,1,5]  R975      -2.1322610974311829e-01
    z[2,1,5]  R976      -3.1098678708076477e-01
    z[2,1,5]  R977      -4.3563401699066162e-01
    z[2,1,5]  R978      4.3798366189002991e-01
    z[2,1,5]  R979      2.8272947669029236e-01
    z[2,1,5]  R980      2.6798954606056213e-01
    z[2,1,5]  R981      4.4543093442916870e-01
    z[2,1,5]  R982      1.1807820200920105e-01
    z[2,1,5]  R983      -2.0969074964523315e-01
    z[2,1,5]  R984      0.584648609161377
    z[2,1,5]  R985      4.6253389120101929e-01
    z[2,1,5]  R986      1.1077541112899780e-01
    z[2,1,5]  R987      3.1556141376495361e-01
    z[2,1,5]  R988      1.1781197786331177e-01
    z[2,1,5]  R989      3.8323265314102173e-01
    z[2,1,5]  R990      5.9083163738250732e-01
    z[2,1,5]  R991      5.3693127632141113e-01
    z[2,1,5]  R992      1.5663637220859528e-01
    z[2,1,5]  R993      4.1953021287918091e-01
    z[2,1,5]  R994      2.4167820811271667e-01
    z[2,1,5]  R995      2.1930266916751862e-01
    z[2,1,5]  R996      2.1439573168754578e-01
    z[2,1,5]  R997      2.9126736521720886e-01
    z[2,1,5]  R998      1.5991058945655823e-01
    z[2,1,5]  R999      9.4435155391693115e-02
    z[2,1,5]  R1000     2.6526299118995667e-01
    z[2,1,5]  R1001     3.2946422696113586e-01
    z[2,1,5]  R1002     -6.3787393271923065e-02
    z[2,1,5]  R1003     -4.0692013502120972e-01
    z[2,1,5]  R1004     1.3815888762474060e-01
    z[2,1,5]  R1005     -2.3018175363540649e-01
    z[2,1,5]  R1006     -3.1856033205986023e-01
    z[2,1,5]  R1007     -1.9800245761871338e-01
    z[2,1,5]  R1008     -1.3131687045097351e-01
    z[2,1,5]  R1009     2.0805935561656952e-01
    z[2,1,5]  R1010     -2.8782995417714119e-02
    z[2,1,5]  R1011     1.7422935366630554e-01
    z[2,1,5]  R1012     -1.3307310640811920e-01
    z[2,1,5]  R1013     3.2203185558319092e-01
    z[2,1,5]  R1014     6.9552063941955566e-02
    z[2,1,5]  R1015     1.4325352013111115e-01
    z[2,1,5]  R1016     2.9530632495880127e-01
    z[2,1,5]  R1017     4.1212841868400574e-01
    z[2,1,5]  R1018     5.8570575714111328e-01
    z[2,1,5]  R1019     -4.3115538358688354e-01
    z[2,1,5]  R1020     4.2247429490089417e-01
    z[2,1,5]  R1021     -1.7058970034122467e-01
    z[2,1,5]  R1022     -1.5608721971511841e-01
    z[2,1,5]  R1023     -5.0835871696472168e-01
    z[2,1,5]  R1024     6.9800531864166260e-01
    z[2,1,5]  R1025     2.4462699890136719e-01
    z[2,1,5]  R1026     4.6346226334571838e-01
    z[2,1,5]  R1027     -6.4760148525238037e-01
    z[2,1,5]  R1028     -8.1387633085250854e-01
    z[2,1,5]  R1029     1.3412535190582275e-01
    z[2,1,5]  R1030     2.1217954158782959e-01
    z[2,1,5]  R1031     -1.9284363090991974e-01
    z[2,1,5]  R1032     -5.1182083785533905e-02
    z[2,1,5]  R1033     2.1714878082275391e-01
    z[2,1,5]  R1034     -1.0764618217945099e-01
    z[2,1,5]  R1035     6.0474467277526855e-01
    z[2,1,5]  R1036     0.469120055437088
    z[2,1,5]  R1037     -0.361625075340271
    z[2,1,5]  R1038     -5.3766030073165894e-01
    z[2,1,5]  R1039     -1.6545116901397705e-01
    z[2,1,5]  R1040     1.3289323449134827e-01
    z[2,1,5]  R1041     -9.6647344529628754e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R910      -1
    z[2,1,6]  R911      1
    z[2,1,6]  R912      -1.7919200658798218e-01
    z[2,1,6]  R913      1.1737052351236343e-01
    z[2,1,6]  R914      -3.0322477221488953e-01
    z[2,1,6]  R915      -7.3339521884918213e-02
    z[2,1,6]  R916      -0.586080014705658
    z[2,1,6]  R917      1.4169251918792725e-01
    z[2,1,6]  R918      1.3314105570316315e-01
    z[2,1,6]  R919      2.2169493138790131e-01
    z[2,1,6]  R920      0.506830632686615
    z[2,1,6]  R921      -2.3363646864891052e-01
    z[2,1,6]  R922      4.2107634246349335e-02
    z[2,1,6]  R923      -1.0225398838520050e-01
    z[2,1,6]  R924      -1.1910647153854370e-01
    z[2,1,6]  R925      -4.8612681031227112e-01
    z[2,1,6]  R926      -1.8703129887580872e-01
    z[2,1,6]  R927      1.1156961321830750e-01
    z[2,1,6]  R928      -5.7398449629545212e-02
    z[2,1,6]  R929      1.1197334527969360e-01
    z[2,1,6]  R930      2.9366193339228630e-02
    z[2,1,6]  R931      -8.4692798554897308e-02
    z[2,1,6]  R932      3.4464153647422791e-01
    z[2,1,6]  R933      -2.0486536622047424e-01
    z[2,1,6]  R934      -0.359995037317276
    z[2,1,6]  R935      6.2019795179367065e-02
    z[2,1,6]  R936      -6.6353239119052887e-02
    z[2,1,6]  R937      -4.7712358832359314e-01
    z[2,1,6]  R938      -2.9085966944694519e-01
    z[2,1,6]  R939      1.4768464863300323e-01
    z[2,1,6]  R940      0.361070841550827
    z[2,1,6]  R941      6.4369112253189087e-01
    z[2,1,6]  R942      3.3611815422773361e-02
    z[2,1,6]  R943      5.8424003422260284e-02
    z[2,1,6]  R944      2.9420611262321472e-01
    z[2,1,6]  R945      3.5556632280349731e-01
    z[2,1,6]  R946      2.7982246875762939e-01
    z[2,1,6]  R947      -1.7918157577514648e-01
    z[2,1,6]  R948      -3.9160954952239990e-01
    z[2,1,6]  R949      2.5816816091537476e-01
    z[2,1,6]  R950      5.3819339722394943e-02
    z[2,1,6]  R951      1.6115494072437286e-01
    z[2,1,6]  R952      1.5988571941852570e-01
    z[2,1,6]  R953      5.4371935129165649e-01
    z[2,1,6]  R954      -2.3824411630630493e-01
    z[2,1,6]  R955      0.0323464460670948
    z[2,1,6]  R956      -3.2886481285095215e-01
    z[2,1,6]  R957      -2.0483744144439697e-01
    z[2,1,6]  R958      -6.2456015497446060e-02
    z[2,1,6]  R959      -6.0060225427150726e-02
    z[2,1,6]  R960      -3.7260480225086212e-02
    z[2,1,6]  R961      -8.9438818395137787e-02
    z[2,1,6]  R962      3.6358860135078430e-01
    z[2,1,6]  R963      -1.4429277181625366e-01
    z[2,1,6]  R964      2.7114427089691162e-01
    z[2,1,6]  R965      -3.8851892948150635e-01
    z[2,1,6]  R966      1.7991696298122406e-01
    z[2,1,6]  R967      -2.3394417762756348e-01
    z[2,1,6]  R968      0.236423060297966
    z[2,1,6]  R969      -3.3040741086006165e-01
    z[2,1,6]  R970      -2.5347569584846497e-01
    z[2,1,6]  R971      -4.4116694480180740e-02
    z[2,1,6]  R972      1.1758720874786377e-01
    z[2,1,6]  R973      1.5814271569252014e-01
    z[2,1,6]  R974      2.6673685759305954e-02
    z[2,1,6]  R975      -3.2572884112596512e-02
    z[2,1,6]  R976      1.0089663416147232e-01
    z[2,1,6]  R977      3.9931874722242355e-02
    z[2,1,6]  R978      2.9144637286663055e-02
    z[2,1,6]  R979      -2.0908041298389435e-01
    z[2,1,6]  R980      5.1410514116287231e-01
    z[2,1,6]  R981      5.5026924610137939e-01
    z[2,1,6]  R982      -0.227493554353714
    z[2,1,6]  R983      -2.5993982329964638e-02
    z[2,1,6]  R984      2.8447759151458740e-01
    z[2,1,6]  R985      5.4953861236572266e-01
    z[2,1,6]  R986      -2.9029166698455811e-01
    z[2,1,6]  R987      1.8050950765609741e-01
    z[2,1,6]  R988      4.4846269488334656e-01
    z[2,1,6]  R989      -6.0303188860416412e-02
    z[2,1,6]  R990      -2.7751579880714417e-01
    z[2,1,6]  R991      0.000607263995334506
    z[2,1,6]  R992      -8.4105335175991058e-02
    z[2,1,6]  R993      -1.8866260349750519e-01
    z[2,1,6]  R994      3.8933104276657104e-01
    z[2,1,6]  R995      -2.7347257733345032e-01
    z[2,1,6]  R996      -1.3086025416851044e-01
    z[2,1,6]  R997      -9.8307356238365173e-02
    z[2,1,6]  R998      2.1744383871555328e-01
    z[2,1,6]  R999      5.4348301142454147e-02
    z[2,1,6]  R1000     7.5376674532890320e-02
    z[2,1,6]  R1001     1.1221068352460861e-01
    z[2,1,6]  R1002     -4.6854072809219360e-01
    z[2,1,6]  R1003     -1.8549780547618866e-01
    z[2,1,6]  R1004     -3.2859003543853760e-01
    z[2,1,6]  R1005     -2.7782490849494934e-01
    z[2,1,6]  R1006     -0.0677451640367508
    z[2,1,6]  R1007     1.5936177968978882e-01
    z[2,1,6]  R1008     2.4572479724884033e-01
    z[2,1,6]  R1009     2.4274982511997223e-01
    z[2,1,6]  R1010     3.2023850828409195e-02
    z[2,1,6]  R1011     3.2487708330154419e-01
    z[2,1,6]  R1012     2.5020885467529297e-01
    z[2,1,6]  R1013     -2.3303854465484619e-01
    z[2,1,6]  R1014     2.8261154890060425e-01
    z[2,1,6]  R1015     -1.6217219829559326e-01
    z[2,1,6]  R1016     2.0462350547313690e-01
    z[2,1,6]  R1017     -3.4572128206491470e-02
    z[2,1,6]  R1018     2.4441033601760864e-01
    z[2,1,6]  R1019     1.2077458202838898e-01
    z[2,1,6]  R1020     3.4495350718498230e-01
    z[2,1,6]  R1021     0.470958948135376
    z[2,1,6]  R1022     2.6052755117416382e-01
    z[2,1,6]  R1023     -1.2949370779097080e-02
    z[2,1,6]  R1024     2.4970626831054688e-01
    z[2,1,6]  R1025     5.9450912475585938e-01
    z[2,1,6]  R1026     -5.0955647230148315e-01
    z[2,1,6]  R1027     -1.8352743983268738e-01
    z[2,1,6]  R1028     -1.1067216284573078e-02
    z[2,1,6]  R1029     -1.8066921830177307e-01
    z[2,1,6]  R1030     -6.7055529356002808e-01
    z[2,1,6]  R1031     3.8996872305870056e-01
    z[2,1,6]  R1032     2.6779506355524063e-02
    z[2,1,6]  R1033     1.9074784219264984e-01
    z[2,1,6]  R1034     1.5408596396446228e-01
    z[2,1,6]  R1035     -4.5079058408737183e-01
    z[2,1,6]  R1036     -6.9441363215446472e-02
    z[2,1,6]  R1037     -4.3850109796039760e-04
    z[2,1,6]  R1038     4.8177537322044373e-01
    z[2,1,6]  R1039     -0.126246377825737
    z[2,1,6]  R1040     1.9304960966110229e-01
    z[2,1,6]  R1041     1.7743013799190521e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R1042     -1
    z[1,3,0]  R1043     1
    z[1,3,0]  R1056     -4.5251451432704926e-02
    z[1,3,0]  R1057     -3.5671177506446838e-01
    z[1,3,0]  R1058     -4.2242676019668579e-02
    z[1,3,0]  R1059     -5.9709161520004272e-01
    z[1,3,0]  R1060     -7.8293181955814362e-02
    z[1,3,0]  R1061     -1.2750937603414059e-02
    z[1,3,0]  R1062     -6.8526011705398560e-01
    z[1,3,0]  R1063     -5.3374101407825947e-03
    z[1,3,0]  R1064     -7.7924764156341553e-01
    z[1,3,0]  R1065     -1.6494253277778625e-01
    z[1,3,0]  R1066     1.0237602144479752e-01
    z[1,3,0]  R1067     -9.1826446354389191e-02
    z[1,3,0]  R1068     -1.0050944983959198e-01
    z[1,3,0]  R1069     -6.5777927637100220e-02
    z[1,3,0]  R1070     -2.2169025242328644e-01
    z[1,3,0]  R1071     2.1646836772561073e-02
    z[1,3,0]  R1072     5.4830335080623627e-02
    z[1,3,0]  R1073     6.3755147159099579e-02
    z[1,3,0]  R1074     -3.9741796255111694e-01
    z[1,3,0]  R1075     1.9783353805541992e-01
    z[1,3,0]  R1076     9.0975388884544373e-02
    z[1,3,0]  R1077     7.3167368769645691e-02
    z[1,3,0]  R1078     2.3548530042171478e-01
    z[1,3,0]  R1079     2.6657110452651978e-01
    z[1,3,0]  R1080     1.6141006350517273e-01
    z[1,3,0]  R1081     -5.9019678831100464e-01
    z[1,3,0]  R1082     2.3474588990211487e-01
    z[1,3,0]  R1083     3.3537900447845459e-01
    z[1,3,0]  R1084     2.8809833526611328e-01
    z[1,3,0]  R1085     2.9013855382800102e-02
    z[1,3,0]  R1086     1.7178709805011749e-01
    z[1,3,0]  R1087     0.073527030646801
    z[1,3,0]  R1088     3.7063896656036377e-01
    z[1,3,0]  R1089     3.3976495265960693e-01
    z[1,3,0]  R1090     3.7903591990470886e-01
    z[1,3,0]  R1091     4.6893391013145447e-01
    z[1,3,0]  R1092     2.6620736718177795e-01
    z[1,3,0]  R1093     5.3020846843719482e-01
    z[1,3,0]  R1094     8.5024207830429077e-01
    z[1,3,0]  R1095     7.7913725376129150e-01
    z[1,3,0]  R1096     -3.6589086055755615e-02
    z[1,3,0]  R1097     0.0693727433681488
    z[1,3,0]  R1098     1.3377635739743710e-02
    z[1,3,0]  R1099     -0.705590546131134
    z[1,3,0]  R1100     2.9925478622317314e-02
    z[1,3,0]  R1101     5.5139489471912384e-02
    z[1,3,0]  R1102     6.8879328668117523e-02
    z[1,3,0]  R1103     -3.4376001358032227e-01
    z[1,3,0]  R1104     6.8608321249485016e-02
    z[1,3,0]  R1105     -9.5315627753734589e-02
    z[1,3,0]  R1106     4.1588321328163147e-01
    z[1,3,0]  R1107     1.1865523457527161e-01
    z[1,3,0]  R1108     1.0987310111522675e-01
    z[1,3,0]  R1109     1.7032913863658905e-01
    z[1,3,0]  R1110     7.7343232929706573e-02
    z[1,3,0]  R1111     2.4044688045978546e-01
    z[1,3,0]  R1112     4.9973991513252258e-01
    z[1,3,0]  R1113     -2.0393800735473633e-01
    z[1,3,0]  R1114     0.332888126373291
    z[1,3,0]  R1115     -0.397519052028656
    z[1,3,0]  R1116     1.4147533476352692e-01
    z[1,3,0]  R1117     3.6231091618537903e-01
    z[1,3,0]  R1118     -9.3511618673801422e-02
    z[1,3,0]  R1119     1.5615861117839813e-01
    z[1,3,0]  R1120     -1.8030744791030884e-01
    z[1,3,0]  R1121     -2.3016983270645142e-01
    z[1,3,0]  R1122     -2.6206314563751221e-01
    z[1,3,0]  R1123     -3.4449473023414612e-01
    z[1,3,0]  R1124     -2.2381576895713806e-01
    z[1,3,0]  R1125     3.4233424067497253e-01
    z[1,3,0]  R1126     1.2595053017139435e-01
    z[1,3,0]  R1127     3.8731002807617188e-01
    z[1,3,0]  R1128     -4.0880435705184937e-01
    z[1,3,0]  R1129     1.0537336766719818e-01
    z[1,3,0]  R1130     -3.6036467552185059e-01
    z[1,3,0]  R1131     -1.4476144686341286e-02
    z[1,3,0]  R1132     -2.9991042613983154e-01
    z[1,3,0]  R1133     -5.9298592805862427e-01
    z[1,3,0]  R1134     5.9217196702957153e-01
    z[1,3,0]  R1135     5.6940101087093353e-02
    z[1,3,0]  R1136     -5.6806594133377075e-01
    z[1,3,0]  R1137     -4.8820680379867554e-01
    z[1,3,0]  R1138     -1.0065668821334839e-01
    z[1,3,0]  R1139     -6.6662663221359253e-01
    z[1,3,0]  R1140     -5.2976123988628387e-02
    z[1,3,0]  R1141     8.1685623154044151e-03
    z[1,3,0]  R1142     1.7718593776226044e-01
    z[1,3,0]  R1143     4.3916791677474976e-01
    z[1,3,0]  R1144     3.4565997123718262e-01
    z[1,3,0]  R1145     4.5147308707237244e-01
    z[1,3,0]  R1146     -0.610199511051178
    z[1,3,0]  R1147     -6.9077622890472412e-01
    z[1,3,0]  R1148     -3.8901382684707642e-01
    z[1,3,0]  R1149     -2.2505044937133789e-01
    z[1,3,0]  R1150     -3.8937729597091675e-01
    z[1,3,0]  R1151     2.6735246181488037e-01
    z[1,3,0]  R1152     -6.1612665653228760e-01
    z[1,3,0]  R1153     -0.665919303894043
    z[1,3,0]  R1154     -5.9971648454666138e-01
    z[1,3,0]  R1155     -5.4659348726272583e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R1044     -1
    z[1,3,1]  R1045     1
    z[1,3,1]  R1056     -4.1153582930564880e-01
    z[1,3,1]  R1057     0.573833703994751
    z[1,3,1]  R1058     -0.366733580827713
    z[1,3,1]  R1059     2.7760806679725647e-01
    z[1,3,1]  R1060     -4.9850201606750488e-01
    z[1,3,1]  R1061     -0.262656033039093
    z[1,3,1]  R1062     3.9246013760566711e-01
    z[1,3,1]  R1063     -2.8604340553283691e-01
    z[1,3,1]  R1064     1.2124329805374146e-01
    z[1,3,1]  R1065     5.4653489589691162e-01
    z[1,3,1]  R1066     -7.8913533687591553e-01
    z[1,3,1]  R1067     -7.8548103570938110e-01
    z[1,3,1]  R1068     -7.8021126985549927e-01
    z[1,3,1]  R1069     -7.6294887065887451e-01
    z[1,3,1]  R1070     -7.4078255891799927e-01
    z[1,3,1]  R1071     -7.4767166376113892e-01
    z[1,3,1]  R1072     -6.2841165065765381e-01
    z[1,3,1]  R1073     -7.1363770961761475e-01
    z[1,3,1]  R1074     -6.6738867759704590e-01
    z[1,3,1]  R1075     -5.4265409708023071e-01
    z[1,3,1]  R1076     -8.6383581161499023e-01
    z[1,3,1]  R1077     -4.6129563450813293e-01
    z[1,3,1]  R1078     -5.1387935876846313e-01
    z[1,3,1]  R1079     -4.2744708061218262e-01
    z[1,3,1]  R1080     -0.583754301071167
    z[1,3,1]  R1081     1.9236426055431366e-01
    z[1,3,1]  R1082     -3.0478119850158691e-01
    z[1,3,1]  R1083     -4.9917593598365784e-01
    z[1,3,1]  R1084     -5.3909343481063843e-01
    z[1,3,1]  R1085     5.0474762916564941e-01
    z[1,3,1]  R1086     -5.4632717370986938e-01
    z[1,3,1]  R1087     -5.4762643575668335e-01
    z[1,3,1]  R1088     -1.4396350085735321e-01
    z[1,3,1]  R1089     -2.5115618109703064e-01
    z[1,3,1]  R1090     -4.8610472679138184e-01
    z[1,3,1]  R1091     4.6591964364051819e-01
    z[1,3,1]  R1092     5.2314704656600952e-01
    z[1,3,1]  R1093     4.5538052916526794e-01
    z[1,3,1]  R1094     3.7054851651191711e-01
    z[1,3,1]  R1095     3.2702940702438354e-01
    z[1,3,1]  R1096     -7.8813350200653076e-01
    z[1,3,1]  R1097     -6.3816928863525391e-01
    z[1,3,1]  R1098     -5.9123784303665161e-01
    z[1,3,1]  R1099     6.3668894767761230e-01
    z[1,3,1]  R1100     -2.9680398106575012e-01
    z[1,3,1]  R1101     -3.4536263346672058e-01
    z[1,3,1]  R1102     -3.0272287130355835e-01
    z[1,3,1]  R1103     6.2705171108245850e-01
    z[1,3,1]  R1104     5.4102611541748047e-01
    z[1,3,1]  R1105     7.6169586181640625e-01
    z[1,3,1]  R1106     -4.5111289620399475e-01
    z[1,3,1]  R1107     -0.439800888299942
    z[1,3,1]  R1108     -3.8439545035362244e-01
    z[1,3,1]  R1109     -3.6523753404617310e-01
    z[1,3,1]  R1110     -4.0704101324081421e-01
    z[1,3,1]  R1111     -2.5016698241233826e-01
    z[1,3,1]  R1112     7.4719732999801636e-01
    z[1,3,1]  R1113     6.8427371978759766e-01
    z[1,3,1]  R1114     6.9754534959793091e-01
    z[1,3,1]  R1115     1.9880345463752747e-01
    z[1,3,1]  R1116     0.857233464717865
    z[1,3,1]  R1117     7.9025137424468994e-01
    z[1,3,1]  R1118     8.0379545688629150e-01
    z[1,3,1]  R1119     6.9972038269042969e-01
    z[1,3,1]  R1120     8.0500149726867676e-01
    z[1,3,1]  R1121     7.3723131418228149e-01
    z[1,3,1]  R1122     6.5980720520019531e-01
    z[1,3,1]  R1123     5.4039853811264038e-01
    z[1,3,1]  R1124     6.3432049751281738e-01
    z[1,3,1]  R1125     3.8795873522758484e-01
    z[1,3,1]  R1126     -6.5281128883361816e-01
    z[1,3,1]  R1127     -4.6596240997314453e-01
    z[1,3,1]  R1128     8.1147712469100952e-01
    z[1,3,1]  R1129     7.8923958539962769e-01
    z[1,3,1]  R1130     4.0587291121482849e-01
    z[1,3,1]  R1131     7.8663498163223267e-01
    z[1,3,1]  R1132     4.4646963477134705e-01
    z[1,3,1]  R1133     1.2665164470672607e-01
    z[1,3,1]  R1134     5.2032095193862915e-01
    z[1,3,1]  R1135     2.4986878037452698e-01
    z[1,3,1]  R1136     4.8440101742744446e-01
    z[1,3,1]  R1137     6.6852509975433350e-01
    z[1,3,1]  R1138     6.3663446903228760e-01
    z[1,3,1]  R1139     4.4251322746276855e-01
    z[1,3,1]  R1140     8.6939907073974609e-01
    z[1,3,1]  R1141     6.1848264932632446e-01
    z[1,3,1]  R1142     3.2343354821205139e-01
    z[1,3,1]  R1143     5.4146373271942139e-01
    z[1,3,1]  R1144     1.8972527980804443e-01
    z[1,3,1]  R1145     4.1707709431648254e-01
    z[1,3,1]  R1146     4.7122615575790405e-01
    z[1,3,1]  R1147     6.4674860239028931e-01
    z[1,3,1]  R1148     7.6113170385360718e-01
    z[1,3,1]  R1149     4.8126682639122009e-01
    z[1,3,1]  R1150     4.3018519878387451e-01
    z[1,3,1]  R1151     2.5084331631660461e-01
    z[1,3,1]  R1152     -3.1143131852149963e-01
    z[1,3,1]  R1153     -1.7610348761081696e-01
    z[1,3,1]  R1154     -2.7668842673301697e-01
    z[1,3,1]  R1155     -3.7183105945587158e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R1046     -1
    z[1,3,2]  R1047     1
    z[1,3,2]  R1056     5.0443840026855469e-01
    z[1,3,2]  R1057     -4.9243211746215820e-01
    z[1,3,2]  R1058     1.2689022719860077e-01
    z[1,3,2]  R1059     -0.626781165599823
    z[1,3,2]  R1060     7.9153716564178467e-01
    z[1,3,2]  R1061     7.2913813591003418e-01
    z[1,3,2]  R1062     -4.3528309464454651e-01
    z[1,3,2]  R1063     3.0553472042083740e-01
    z[1,3,2]  R1064     -5.4495644569396973e-01
    z[1,3,2]  R1065     -7.0033740997314453e-01
    z[1,3,2]  R1066     -3.6397790908813477e-01
    z[1,3,2]  R1067     -2.8767114877700806e-01
    z[1,3,2]  R1068     -3.3676931262016296e-01
    z[1,3,2]  R1069     -3.1985855102539062e-01
    z[1,3,2]  R1070     -2.3950286209583282e-01
    z[1,3,2]  R1071     -1.2533517181873322e-01
    z[1,3,2]  R1072     1.7164391279220581e-01
    z[1,3,2]  R1073     -2.3216864466667175e-01
    z[1,3,2]  R1074     1.0192343033850193e-03
    z[1,3,2]  R1075     9.2219136655330658e-02
    z[1,3,2]  R1076     1.1176556348800659e-01
    z[1,3,2]  R1077     3.0754688382148743e-01
    z[1,3,2]  R1078     0.3104248046875
    z[1,3,2]  R1079     4.3009561300277710e-01
    z[1,3,2]  R1080     -1.9003529846668243e-01
    z[1,3,2]  R1081     -3.1999304890632629e-01
    z[1,3,2]  R1082     5.9365980327129364e-02
    z[1,3,2]  R1083     5.3292375802993774e-01
    z[1,3,2]  R1084     1.1547703295946121e-01
    z[1,3,2]  R1085     3.5850954055786133e-01
    z[1,3,2]  R1086     1.8182796239852905e-01
    z[1,3,2]  R1087     5.6437408924102783e-01
    z[1,3,2]  R1088     7.5032621622085571e-01
    z[1,3,2]  R1089     1.2528024613857269e-01
    z[1,3,2]  R1090     2.2773987054824829e-01
    z[1,3,2]  R1091     2.6856359094381332e-02
    z[1,3,2]  R1092     1.8239600956439972e-01
    z[1,3,2]  R1093     2.3532277345657349e-01
    z[1,3,2]  R1094     1.6897714138031006e-01
    z[1,3,2]  R1095     6.8543985486030579e-02
    z[1,3,2]  R1096     2.9155045747756958e-01
    z[1,3,2]  R1097     -4.2261886596679688e-01
    z[1,3,2]  R1098     0.0226475540548563
    z[1,3,2]  R1099     -7.3616698384284973e-02
    z[1,3,2]  R1100     0.351779967546463
    z[1,3,2]  R1101     -1.2747351825237274e-01
    z[1,3,2]  R1102     -1.1474695056676865e-01
    z[1,3,2]  R1103     3.4420590847730637e-02
    z[1,3,2]  R1104     2.1619459986686707e-01
    z[1,3,2]  R1105     2.0916143059730530e-01
    z[1,3,2]  R1106     6.6711580753326416e-01
    z[1,3,2]  R1107     1.9830379635095596e-02
    z[1,3,2]  R1108     4.0915283560752869e-01
    z[1,3,2]  R1109     5.5210381746292114e-02
    z[1,3,2]  R1110     -1.1304409801959991e-01
    z[1,3,2]  R1111     -6.1652410030364990e-01
    z[1,3,2]  R1112     -1.5276296436786652e-01
    z[1,3,2]  R1113     1.4430822432041168e-01
    z[1,3,2]  R1114     -2.7639037370681763e-01
    z[1,3,2]  R1115     -3.8856777548789978e-01
    z[1,3,2]  R1116     2.6850545406341553e-01
    z[1,3,2]  R1117     -1.3540776073932648e-01
    z[1,3,2]  R1118     -1.0470170527696609e-01
    z[1,3,2]  R1119     -3.6883455514907837e-01
    z[1,3,2]  R1120     -1.7168706655502319e-01
    z[1,3,2]  R1121     4.8716634511947632e-01
    z[1,3,2]  R1122     1.8579114973545074e-01
    z[1,3,2]  R1123     -4.8725920915603638e-01
    z[1,3,2]  R1124     -2.5702643394470215e-01
    z[1,3,2]  R1125     2.5466141104698181e-01
    z[1,3,2]  R1126     -3.2065615057945251e-01
    z[1,3,2]  R1127     3.8088664412498474e-01
    z[1,3,2]  R1128     -5.6624421849846840e-03
    z[1,3,2]  R1129     -2.9873631894588470e-02
    z[1,3,2]  R1130     -6.1045056581497192e-01
    z[1,3,2]  R1131     -2.4921372532844543e-01
    z[1,3,2]  R1132     -4.9589291214942932e-01
    z[1,3,2]  R1133     3.9476905949413776e-03
    z[1,3,2]  R1134     3.8990476727485657e-01
    z[1,3,2]  R1135     4.9159295856952667e-02
    z[1,3,2]  R1136     -4.7137516736984253e-01
    z[1,3,2]  R1137     7.6161310076713562e-02
    z[1,3,2]  R1138     3.3059367537498474e-01
    z[1,3,2]  R1139     -1.8056605011224747e-02
    z[1,3,2]  R1140     8.5890352725982666e-02
    z[1,3,2]  R1141     -1.1896006017923355e-01
    z[1,3,2]  R1142     -3.1947073340415955e-01
    z[1,3,2]  R1143     4.3478971719741821e-01
    z[1,3,2]  R1144     -1.6211281716823578e-01
    z[1,3,2]  R1145     1.5092931687831879e-01
    z[1,3,2]  R1146     -4.5245864987373352e-01
    z[1,3,2]  R1147     -1.4433425664901733e-01
    z[1,3,2]  R1148     3.1044140458106995e-01
    z[1,3,2]  R1149     -2.6153931021690369e-01
    z[1,3,2]  R1150     -0.280733197927475
    z[1,3,2]  R1151     -1.3410811126232147e-01
    z[1,3,2]  R1152     5.7834321260452271e-01
    z[1,3,2]  R1153     3.7822961807250977e-01
    z[1,3,2]  R1154     4.3421438336372375e-01
    z[1,3,2]  R1155     4.9262502789497375e-01
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R1048     -1
    z[1,3,3]  R1049     1
    z[1,3,3]  R1056     5.3050768375396729e-01
    z[1,3,3]  R1057     2.4304993450641632e-01
    z[1,3,3]  R1058     0.799430251121521
    z[1,3,3]  R1059     1.0718559473752975e-01
    z[1,3,3]  R1060     1.0570231825113297e-01
    z[1,3,3]  R1061     5.6906795501708984e-01
    z[1,3,3]  R1062     1.5660229325294495e-01
    z[1,3,3]  R1063     6.4447224140167236e-01
    z[1,3,3]  R1064     2.4263779819011688e-01
    z[1,3,3]  R1065     1.3728702068328857e-01
    z[1,3,3]  R1066     0.174093097448349
    z[1,3,3]  R1067     -2.9917600750923157e-01
    z[1,3,3]  R1068     -3.9608660340309143e-01
    z[1,3,3]  R1069     -4.9124431610107422e-01
    z[1,3,3]  R1070     -4.4795447587966919e-01
    z[1,3,3]  R1071     -4.1094160079956055e-01
    z[1,3,3]  R1072     -4.0366217494010925e-01
    z[1,3,3]  R1073     -4.2908832430839539e-01
    z[1,3,3]  R1074     -1.9940476119518280e-01
    z[1,3,3]  R1075     -5.6705063581466675e-01
    z[1,3,3]  R1076     1.2812471017241478e-02
    z[1,3,3]  R1077     3.9192914962768555e-01
    z[1,3,3]  R1078     -1.0241139680147171e-01
    z[1,3,3]  R1079     -2.2310981154441833e-01
    z[1,3,3]  R1080     -5.0097241997718811e-02
    z[1,3,3]  R1081     5.2560776472091675e-02
    z[1,3,3]  R1082     2.0923748612403870e-01
    z[1,3,3]  R1083     1.9200769066810608e-01
    z[1,3,3]  R1084     8.4713473916053772e-02
    z[1,3,3]  R1085     6.5258580446243286e-01
    z[1,3,3]  R1086     7.9723989963531494e-01
    z[1,3,3]  R1087     5.0779759883880615e-01
    z[1,3,3]  R1088     1.6282172501087189e-01
    z[1,3,3]  R1089     4.7349786758422852e-01
    z[1,3,3]  R1090     8.6323969066143036e-02
    z[1,3,3]  R1091     3.1835392117500305e-01
    z[1,3,3]  R1092     -2.1111611276865005e-02
    z[1,3,3]  R1093     6.1433070898056030e-01
    z[1,3,3]  R1094     -1.2037465721368790e-01
    z[1,3,3]  R1095     -4.6486461162567139e-01
    z[1,3,3]  R1096     1.1979837715625763e-01
    z[1,3,3]  R1097     -5.2399146556854248e-01
    z[1,3,3]  R1098     6.6634345054626465e-01
    z[1,3,3]  R1099     -1.1344969272613525e-01
    z[1,3,3]  R1100     -8.2266800105571747e-02
    z[1,3,3]  R1101     -0.0785977765917778
    z[1,3,3]  R1102     -4.3732246756553650e-01
    z[1,3,3]  R1103     -4.9222588539123535e-01
    z[1,3,3]  R1104     -0.789358377456665
    z[1,3,3]  R1105     -5.1896160840988159e-01
    z[1,3,3]  R1106     -1.4762806892395020e-01
    z[1,3,3]  R1107     -7.1839645504951477e-02
    z[1,3,3]  R1108     -5.1226228475570679e-01
    z[1,3,3]  R1109     2.3346434533596039e-01
    z[1,3,3]  R1110     -1.5381909906864166e-01
    z[1,3,3]  R1111     -1.4028598368167877e-01
    z[1,3,3]  R1112     -6.1548583209514618e-02
    z[1,3,3]  R1113     -3.1095218658447266e-01
    z[1,3,3]  R1114     -3.7301453948020935e-01
    z[1,3,3]  R1115     -4.6497520804405212e-01
    z[1,3,3]  R1116     -3.3105546236038208e-01
    z[1,3,3]  R1117     -4.6913620829582214e-01
    z[1,3,3]  R1118     -4.1991695761680603e-01
    z[1,3,3]  R1119     -5.5058246850967407e-01
    z[1,3,3]  R1120     5.0946021080017090e-01
    z[1,3,3]  R1121     -6.6334336996078491e-02
    z[1,3,3]  R1122     2.7412867546081543e-01
    z[1,3,3]  R1123     4.4249475002288818e-01
    z[1,3,3]  R1124     3.2248049974441528e-01
    z[1,3,3]  R1125     -4.0056106448173523e-01
    z[1,3,3]  R1126     4.4133597612380981e-01
    z[1,3,3]  R1127     -0.0772356316447258
    z[1,3,3]  R1128     2.7450013160705566e-01
    z[1,3,3]  R1129     -5.1207160949707031e-01
    z[1,3,3]  R1130     -3.5299211740493774e-01
    z[1,3,3]  R1131     -5.8170523494482040e-02
    z[1,3,3]  R1132     -0.651406466960907
    z[1,3,3]  R1133     -5.9365576505661011e-01
    z[1,3,3]  R1134     -0.0291308481246233
    z[1,3,3]  R1135     -5.1408547163009644e-01
    z[1,3,3]  R1136     -5.0025876611471176e-02
    z[1,3,3]  R1137     5.7337163016200066e-03
    z[1,3,3]  R1138     -5.2307796478271484e-01
    z[1,3,3]  R1139     8.1351123750209808e-02
    z[1,3,3]  R1140     -1.3375589251518250e-01
    z[1,3,3]  R1141     -3.2607337832450867e-01
    z[1,3,3]  R1142     -0.739935040473938
    z[1,3,3]  R1143     -2.4455970525741577e-01
    z[1,3,3]  R1144     -5.2082246541976929e-01
    z[1,3,3]  R1145     -9.2234991490840912e-02
    z[1,3,3]  R1146     -3.7684386968612671e-01
    z[1,3,3]  R1147     2.8232610225677490e-01
    z[1,3,3]  R1148     3.2263547182083130e-01
    z[1,3,3]  R1149     -6.4435219764709473e-01
    z[1,3,3]  R1150     -3.7938350439071655e-01
    z[1,3,3]  R1151     -5.5153644084930420e-01
    z[1,3,3]  R1152     -3.8196936249732971e-01
    z[1,3,3]  R1153     -4.2192295193672180e-01
    z[1,3,3]  R1154     -3.7358319759368896e-01
    z[1,3,3]  R1155     -4.0055724978446960e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R1050     -1
    z[1,3,4]  R1051     1
    z[1,3,4]  R1056     2.6285862922668457e-01
    z[1,3,4]  R1057     2.0473259687423706e-01
    z[1,3,4]  R1058     2.8543433547019958e-01
    z[1,3,4]  R1059     1.7861008644104004e-01
    z[1,3,4]  R1060     3.9897285401821136e-02
    z[1,3,4]  R1061     -1.0376599431037903e-01
    z[1,3,4]  R1062     2.9115831851959229e-01
    z[1,3,4]  R1063     5.5429106950759888e-01
    z[1,3,4]  R1064     -1.4271882176399231e-01
    z[1,3,4]  R1065     -1.6991877555847168e-01
    z[1,3,4]  R1066     -3.5168644785881042e-01
    z[1,3,4]  R1067     -2.1051105856895447e-01
    z[1,3,4]  R1068     1.6175056993961334e-01
    z[1,3,4]  R1069     1.5208730101585388e-01
    z[1,3,4]  R1070     -1.2244738638401031e-01
    z[1,3,4]  R1071     2.9136139154434204e-01
    z[1,3,4]  R1072     8.3066321909427643e-02
    z[1,3,4]  R1073     2.1944449841976166e-01
    z[1,3,4]  R1074     2.4374271929264069e-01
    z[1,3,4]  R1075     2.9229193925857544e-01
    z[1,3,4]  R1076     3.7499007582664490e-01
    z[1,3,4]  R1077     -5.2446460723876953e-01
    z[1,3,4]  R1078     1.5510775148868561e-01
    z[1,3,4]  R1079     -3.1334522366523743e-01
    z[1,3,4]  R1080     0.34656822681427
    z[1,3,4]  R1081     -2.3756182193756104e-01
    z[1,3,4]  R1082     3.7706881761550903e-01
    z[1,3,4]  R1083     -5.1656424999237061e-01
    z[1,3,4]  R1084     -3.3346924185752869e-01
    z[1,3,4]  R1085     2.6950253173708916e-02
    z[1,3,4]  R1086     0.00511670857667923
    z[1,3,4]  R1087     1.8650548160076141e-01
    z[1,3,4]  R1088     4.6590843796730042e-01
    z[1,3,4]  R1089     1.1250261217355728e-01
    z[1,3,4]  R1090     -5.7950061559677124e-01
    z[1,3,4]  R1091     -5.7460999488830566e-01
    z[1,3,4]  R1092     -3.1709730625152588e-01
    z[1,3,4]  R1093     -1.8819181621074677e-01
    z[1,3,4]  R1094     2.0447519421577454e-01
    z[1,3,4]  R1095     1.5613253414630890e-01
    z[1,3,4]  R1096     4.0810516476631165e-01
    z[1,3,4]  R1097     -8.2651257514953613e-02
    z[1,3,4]  R1098     2.2359290719032288e-01
    z[1,3,4]  R1099     1.9921872019767761e-01
    z[1,3,4]  R1100     -2.0305125415325165e-01
    z[1,3,4]  R1101     -3.4954020380973816e-01
    z[1,3,4]  R1102     7.8294515609741211e-02
    z[1,3,4]  R1103     3.9334109425544739e-01
    z[1,3,4]  R1104     -0.0928015261888504
    z[1,3,4]  R1105     2.6882079243659973e-01
    z[1,3,4]  R1106     6.7703694105148315e-02
    z[1,3,4]  R1107     -0.374188095331192
    z[1,3,4]  R1108     -1.1617810279130936e-01
    z[1,3,4]  R1109     -4.3234923481941223e-01
    z[1,3,4]  R1110     2.4462303519248962e-01
    z[1,3,4]  R1111     2.2121407091617584e-01
    z[1,3,4]  R1112     7.4796296656131744e-02
    z[1,3,4]  R1113     -7.2107151150703430e-02
    z[1,3,4]  R1114     -1.8771593272686005e-01
    z[1,3,4]  R1115     1.6012816131114960e-01
    z[1,3,4]  R1116     3.7444159388542175e-02
    z[1,3,4]  R1117     -1.1119368486106396e-02
    z[1,3,4]  R1118     1.2771655619144440e-01
    z[1,3,4]  R1119     1.7380365170538425e-03
    z[1,3,4]  R1120     -1.5074522234499454e-02
    z[1,3,4]  R1121     1.9664084911346436e-01
    z[1,3,4]  R1122     2.1345909684896469e-02
    z[1,3,4]  R1123     -1.5040965750813484e-02
    z[1,3,4]  R1124     5.8716509491205215e-02
    z[1,3,4]  R1125     -1.1619853228330612e-01
    z[1,3,4]  R1126     -2.2021043300628662e-01
    z[1,3,4]  R1127     -6.2694478034973145e-01
    z[1,3,4]  R1128     -1.0876150429248810e-01
    z[1,3,4]  R1129     1.5709446370601654e-01
    z[1,3,4]  R1130     -7.1048364043235779e-02
    z[1,3,4]  R1131     5.4756116867065430e-01
    z[1,3,4]  R1132     1.0645416378974915e-01
    z[1,3,4]  R1133     2.1118494868278503e-01
    z[1,3,4]  R1134     -1.6663597524166107e-01
    z[1,3,4]  R1135     3.7277019023895264e-01
    z[1,3,4]  R1136     -8.5882298648357391e-02
    z[1,3,4]  R1137     7.4555687606334686e-02
    z[1,3,4]  R1138     2.8460854291915894e-01
    z[1,3,4]  R1139     1.0403080284595490e-01
    z[1,3,4]  R1140     0.081064872443676
    z[1,3,4]  R1141     4.7856429219245911e-01
    z[1,3,4]  R1142     9.7546920180320740e-02
    z[1,3,4]  R1143     -4.3939024209976196e-01
    z[1,3,4]  R1144     1.4860205352306366e-01
    z[1,3,4]  R1145     2.2053673863410950e-01
    z[1,3,4]  R1146     -1.1096361279487610e-01
    z[1,3,4]  R1147     -4.2400330305099487e-02
    z[1,3,4]  R1148     1.3898704946041107e-01
    z[1,3,4]  R1149     3.9633655548095703e-01
    z[1,3,4]  R1150     4.7889527678489685e-01
    z[1,3,4]  R1151     1.7635495960712433e-01
    z[1,3,4]  R1152     7.3480255901813507e-02
    z[1,3,4]  R1153     3.4458291530609131e-01
    z[1,3,4]  R1154     3.3864155411720276e-01
    z[1,3,4]  R1155     2.0493526756763458e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R1052     -1
    z[1,3,5]  R1053     1
    z[1,3,5]  R1056     -6.3787393271923065e-02
    z[1,3,5]  R1057     -4.0692013502120972e-01
    z[1,3,5]  R1058     1.3815888762474060e-01
    z[1,3,5]  R1059     -2.3018175363540649e-01
    z[1,3,5]  R1060     -3.1856033205986023e-01
    z[1,3,5]  R1061     -1.9800245761871338e-01
    z[1,3,5]  R1062     -1.3131687045097351e-01
    z[1,3,5]  R1063     2.0805935561656952e-01
    z[1,3,5]  R1064     -2.8782995417714119e-02
    z[1,3,5]  R1065     1.7422935366630554e-01
    z[1,3,5]  R1066     -1.3307310640811920e-01
    z[1,3,5]  R1067     3.2203185558319092e-01
    z[1,3,5]  R1068     6.9552063941955566e-02
    z[1,3,5]  R1069     1.4325352013111115e-01
    z[1,3,5]  R1070     2.9530632495880127e-01
    z[1,3,5]  R1071     4.1212841868400574e-01
    z[1,3,5]  R1072     5.8570575714111328e-01
    z[1,3,5]  R1073     -4.3115538358688354e-01
    z[1,3,5]  R1074     4.2247429490089417e-01
    z[1,3,5]  R1075     -1.7058970034122467e-01
    z[1,3,5]  R1076     -1.5608721971511841e-01
    z[1,3,5]  R1077     -5.0835871696472168e-01
    z[1,3,5]  R1078     6.9800531864166260e-01
    z[1,3,5]  R1079     2.4462699890136719e-01
    z[1,3,5]  R1080     4.6346226334571838e-01
    z[1,3,5]  R1081     -6.4760148525238037e-01
    z[1,3,5]  R1082     -8.1387633085250854e-01
    z[1,3,5]  R1083     1.3412535190582275e-01
    z[1,3,5]  R1084     2.1217954158782959e-01
    z[1,3,5]  R1085     -1.9284363090991974e-01
    z[1,3,5]  R1086     -5.1182083785533905e-02
    z[1,3,5]  R1087     2.1714878082275391e-01
    z[1,3,5]  R1088     -1.0764618217945099e-01
    z[1,3,5]  R1089     6.0474467277526855e-01
    z[1,3,5]  R1090     0.469120055437088
    z[1,3,5]  R1091     -0.361625075340271
    z[1,3,5]  R1092     -5.3766030073165894e-01
    z[1,3,5]  R1093     -1.6545116901397705e-01
    z[1,3,5]  R1094     1.3289323449134827e-01
    z[1,3,5]  R1095     -9.6647344529628754e-02
    z[1,3,5]  R1096     2.9796305298805237e-01
    z[1,3,5]  R1097     3.5531315207481384e-01
    z[1,3,5]  R1098     3.1273981928825378e-01
    z[1,3,5]  R1099     1.5132869780063629e-01
    z[1,3,5]  R1100     8.2891270518302917e-02
    z[1,3,5]  R1101     1.8760459125041962e-01
    z[1,3,5]  R1102     -2.9356718063354492e-01
    z[1,3,5]  R1103     1.7945627868175507e-01
    z[1,3,5]  R1104     1.5480084717273712e-01
    z[1,3,5]  R1105     -4.5567336492240429e-03
    z[1,3,5]  R1106     -3.7057882547378540e-01
    z[1,3,5]  R1107     -5.8638083934783936e-01
    z[1,3,5]  R1108     -4.7048667073249817e-01
    z[1,3,5]  R1109     -7.1876019239425659e-01
    z[1,3,5]  R1110     -7.1208667755126953e-01
    z[1,3,5]  R1111     -6.4713490009307861e-01
    z[1,3,5]  R1112     3.7273174524307251e-01
    z[1,3,5]  R1113     -4.8278215527534485e-01
    z[1,3,5]  R1114     -3.8958466053009033e-01
    z[1,3,5]  R1115     -6.2846875190734863e-01
    z[1,3,5]  R1116     -2.0935179293155670e-01
    z[1,3,5]  R1117     7.1825966238975525e-02
    z[1,3,5]  R1118     -3.5511177778244019e-01
    z[1,3,5]  R1119     -2.0457766950130463e-01
    z[1,3,5]  R1120     -7.8436665236949921e-02
    z[1,3,5]  R1121     -3.5082376003265381e-01
    z[1,3,5]  R1122     -6.2063324451446533e-01
    z[1,3,5]  R1123     -1.5862299501895905e-01
    z[1,3,5]  R1124     -5.3206694126129150e-01
    z[1,3,5]  R1125     6.7930233478546143e-01
    z[1,3,5]  R1126     2.5022828578948975e-01
    z[1,3,5]  R1127     2.9681313037872314e-01
    z[1,3,5]  R1128     2.6027432084083557e-01
    z[1,3,5]  R1129     2.3415267467498779e-01
    z[1,3,5]  R1130     2.4350734055042267e-01
    z[1,3,5]  R1131     3.1304490403272212e-04
    z[1,3,5]  R1132     -1.4754687249660492e-01
    z[1,3,5]  R1133     -1.8984548747539520e-01
    z[1,3,5]  R1134     4.3392565846443176e-01
    z[1,3,5]  R1135     4.6961772441864014e-01
    z[1,3,5]  R1136     4.2950622737407684e-02
    z[1,3,5]  R1137     2.3239459097385406e-01
    z[1,3,5]  R1138     3.4280958771705627e-01
    z[1,3,5]  R1139     -5.4389089345932007e-01
    z[1,3,5]  R1140     -2.7062374353408813e-01
    z[1,3,5]  R1141     -1.4795990660786629e-02
    z[1,3,5]  R1142     6.6138349473476410e-02
    z[1,3,5]  R1143     1.2924763560295105e-01
    z[1,3,5]  R1144     6.0124790668487549e-01
    z[1,3,5]  R1145     6.1871415376663208e-01
    z[1,3,5]  R1146     2.0373660326004028e-01
    z[1,3,5]  R1147     4.3375995010137558e-02
    z[1,3,5]  R1148     1.8051321804523468e-01
    z[1,3,5]  R1149     -7.3148764669895172e-02
    z[1,3,5]  R1150     -3.7347188591957092e-01
    z[1,3,5]  R1151     6.7983222007751465e-01
    z[1,3,5]  R1152     1.7246770858764648e-01
    z[1,3,5]  R1153     -1.8709598109126091e-02
    z[1,3,5]  R1154     2.1293669939041138e-01
    z[1,3,5]  R1155     2.7812838554382324e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R1054     -1
    z[1,3,6]  R1055     1
    z[1,3,6]  R1056     -4.6854072809219360e-01
    z[1,3,6]  R1057     -1.8549780547618866e-01
    z[1,3,6]  R1058     -3.2859003543853760e-01
    z[1,3,6]  R1059     -2.7782490849494934e-01
    z[1,3,6]  R1060     -0.0677451640367508
    z[1,3,6]  R1061     1.5936177968978882e-01
    z[1,3,6]  R1062     2.4572479724884033e-01
    z[1,3,6]  R1063     2.4274982511997223e-01
    z[1,3,6]  R1064     3.2023850828409195e-02
    z[1,3,6]  R1065     3.2487708330154419e-01
    z[1,3,6]  R1066     2.5020885467529297e-01
    z[1,3,6]  R1067     -2.3303854465484619e-01
    z[1,3,6]  R1068     2.8261154890060425e-01
    z[1,3,6]  R1069     -1.6217219829559326e-01
    z[1,3,6]  R1070     2.0462350547313690e-01
    z[1,3,6]  R1071     -3.4572128206491470e-02
    z[1,3,6]  R1072     2.4441033601760864e-01
    z[1,3,6]  R1073     1.2077458202838898e-01
    z[1,3,6]  R1074     3.4495350718498230e-01
    z[1,3,6]  R1075     0.470958948135376
    z[1,3,6]  R1076     2.6052755117416382e-01
    z[1,3,6]  R1077     -1.2949370779097080e-02
    z[1,3,6]  R1078     2.4970626831054688e-01
    z[1,3,6]  R1079     5.9450912475585938e-01
    z[1,3,6]  R1080     -5.0955647230148315e-01
    z[1,3,6]  R1081     -1.8352743983268738e-01
    z[1,3,6]  R1082     -1.1067216284573078e-02
    z[1,3,6]  R1083     -1.8066921830177307e-01
    z[1,3,6]  R1084     -6.7055529356002808e-01
    z[1,3,6]  R1085     3.8996872305870056e-01
    z[1,3,6]  R1086     2.6779506355524063e-02
    z[1,3,6]  R1087     1.9074784219264984e-01
    z[1,3,6]  R1088     1.5408596396446228e-01
    z[1,3,6]  R1089     -4.5079058408737183e-01
    z[1,3,6]  R1090     -6.9441363215446472e-02
    z[1,3,6]  R1091     -4.3850109796039760e-04
    z[1,3,6]  R1092     4.8177537322044373e-01
    z[1,3,6]  R1093     -0.126246377825737
    z[1,3,6]  R1094     1.9304960966110229e-01
    z[1,3,6]  R1095     1.7743013799190521e-01
    z[1,3,6]  R1096     -1.5106844902038574e-01
    z[1,3,6]  R1097     -4.0926668792963028e-02
    z[1,3,6]  R1098     2.4069119989871979e-01
    z[1,3,6]  R1099     -1.2605784833431244e-01
    z[1,3,6]  R1100     -0.855800211429596
    z[1,3,6]  R1101     -8.3539414405822754e-01
    z[1,3,6]  R1102     -7.7902823686599731e-01
    z[1,3,6]  R1103     -2.4133461713790894e-01
    z[1,3,6]  R1104     1.3475725427269936e-02
    z[1,3,6]  R1105     1.5930871665477753e-01
    z[1,3,6]  R1106     -1.2160740792751312e-01
    z[1,3,6]  R1107     5.5052947998046875e-01
    z[1,3,6]  R1108     4.1892027854919434e-01
    z[1,3,6]  R1109     -2.7657487988471985e-01
    z[1,3,6]  R1110     4.7432950139045715e-01
    z[1,3,6]  R1111     1.1000140011310577e-01
    z[1,3,6]  R1112     -1.4250591397285461e-01
    z[1,3,6]  R1113     -3.6658516526222229e-01
    z[1,3,6]  R1114     -8.4278509020805359e-03
    z[1,3,6]  R1115     1.2105721980333328e-01
    z[1,3,6]  R1116     1.3495326042175293e-01
    z[1,3,6]  R1117     2.2954124957323074e-02
    z[1,3,6]  R1118     -1.2433709204196930e-01
    z[1,3,6]  R1119     -7.0504434406757355e-02
    z[1,3,6]  R1120     1.5510024130344391e-01
    z[1,3,6]  R1121     5.9778308495879173e-03
    z[1,3,6]  R1122     2.5904938578605652e-02
    z[1,3,6]  R1123     3.6149981617927551e-01
    z[1,3,6]  R1124     -3.0157101154327393e-01
    z[1,3,6]  R1125     -1.7899684607982635e-01
    z[1,3,6]  R1126     -3.8635396957397461e-01
    z[1,3,6]  R1127     -2.5926964357495308e-02
    z[1,3,6]  R1128     -1.3939090073108673e-01
    z[1,3,6]  R1129     -1.5291011333465576e-01
    z[1,3,6]  R1130     3.7921956181526184e-01
    z[1,3,6]  R1131     1.2522467970848083e-01
    z[1,3,6]  R1132     0.085883229970932
    z[1,3,6]  R1133     0.446367472410202
    z[1,3,6]  R1134     9.8310850560665131e-02
    z[1,3,6]  R1135     5.5508965253829956e-01
    z[1,3,6]  R1136     4.5687967538833618e-01
    z[1,3,6]  R1137     4.9932867288589478e-01
    z[1,3,6]  R1138     0.0560506135225296
    z[1,3,6]  R1139     2.1495828032493591e-01
    z[1,3,6]  R1140     -3.6913719773292542e-01
    z[1,3,6]  R1141     5.1739192008972168e-01
    z[1,3,6]  R1142     0.447817862033844
    z[1,3,6]  R1143     -0.235219344496727
    z[1,3,6]  R1144     4.0423431992530823e-01
    z[1,3,6]  R1145     3.9935973286628723e-01
    z[1,3,6]  R1146     -7.1068987250328064e-02
    z[1,3,6]  R1147     -1.8020041286945343e-02
    z[1,3,6]  R1148     1.3029550015926361e-01
    z[1,3,6]  R1149     2.6778453588485718e-01
    z[1,3,6]  R1150     2.6788255572319031e-01
    z[1,3,6]  R1151     2.2394201159477234e-01
    z[1,3,6]  R1152     -8.8726624846458435e-02
    z[1,3,6]  R1153     2.9218995571136475e-01
    z[1,3,6]  R1154     2.7505829930305481e-01
    z[1,3,6]  R1155     2.0124079287052155e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R1156     -1
    z[3,1,0]  R1157     1
    z[3,1,0]  R1170     -3.6589086055755615e-02
    z[3,1,0]  R1171     0.0693727433681488
    z[3,1,0]  R1172     1.3377635739743710e-02
    z[3,1,0]  R1173     -0.705590546131134
    z[3,1,0]  R1174     2.9925478622317314e-02
    z[3,1,0]  R1175     5.5139489471912384e-02
    z[3,1,0]  R1176     6.8879328668117523e-02
    z[3,1,0]  R1177     -3.4376001358032227e-01
    z[3,1,0]  R1178     6.8608321249485016e-02
    z[3,1,0]  R1179     -9.5315627753734589e-02
    z[3,1,0]  R1180     4.1588321328163147e-01
    z[3,1,0]  R1181     1.1865523457527161e-01
    z[3,1,0]  R1182     1.0987310111522675e-01
    z[3,1,0]  R1183     1.7032913863658905e-01
    z[3,1,0]  R1184     7.7343232929706573e-02
    z[3,1,0]  R1185     2.4044688045978546e-01
    z[3,1,0]  R1186     4.9973991513252258e-01
    z[3,1,0]  R1187     -2.0393800735473633e-01
    z[3,1,0]  R1188     0.332888126373291
    z[3,1,0]  R1189     -0.397519052028656
    z[3,1,0]  R1190     1.4147533476352692e-01
    z[3,1,0]  R1191     3.6231091618537903e-01
    z[3,1,0]  R1192     -9.3511618673801422e-02
    z[3,1,0]  R1193     1.5615861117839813e-01
    z[3,1,0]  R1194     -1.8030744791030884e-01
    z[3,1,0]  R1195     -2.3016983270645142e-01
    z[3,1,0]  R1196     -2.6206314563751221e-01
    z[3,1,0]  R1197     -3.4449473023414612e-01
    z[3,1,0]  R1198     -2.2381576895713806e-01
    z[3,1,0]  R1199     3.4233424067497253e-01
    z[3,1,0]  R1200     1.2595053017139435e-01
    z[3,1,0]  R1201     3.8731002807617188e-01
    z[3,1,0]  R1202     -4.0880435705184937e-01
    z[3,1,0]  R1203     1.0537336766719818e-01
    z[3,1,0]  R1204     -3.6036467552185059e-01
    z[3,1,0]  R1205     -1.4476144686341286e-02
    z[3,1,0]  R1206     -2.9991042613983154e-01
    z[3,1,0]  R1207     -5.9298592805862427e-01
    z[3,1,0]  R1208     5.9217196702957153e-01
    z[3,1,0]  R1209     5.6940101087093353e-02
    z[3,1,0]  R1210     -5.6806594133377075e-01
    z[3,1,0]  R1211     -4.8820680379867554e-01
    z[3,1,0]  R1212     -1.0065668821334839e-01
    z[3,1,0]  R1213     -6.6662663221359253e-01
    z[3,1,0]  R1214     -5.2976123988628387e-02
    z[3,1,0]  R1215     8.1685623154044151e-03
    z[3,1,0]  R1216     1.7718593776226044e-01
    z[3,1,0]  R1217     4.3916791677474976e-01
    z[3,1,0]  R1218     3.4565997123718262e-01
    z[3,1,0]  R1219     4.5147308707237244e-01
    z[3,1,0]  R1220     -0.610199511051178
    z[3,1,0]  R1221     -6.9077622890472412e-01
    z[3,1,0]  R1222     -3.8901382684707642e-01
    z[3,1,0]  R1223     -2.2505044937133789e-01
    z[3,1,0]  R1224     -3.8937729597091675e-01
    z[3,1,0]  R1225     2.6735246181488037e-01
    z[3,1,0]  R1226     -6.1612665653228760e-01
    z[3,1,0]  R1227     -0.665919303894043
    z[3,1,0]  R1228     -5.9971648454666138e-01
    z[3,1,0]  R1229     -5.4659348726272583e-01
    z[3,1,0]  R1230     -4.5251451432704926e-02
    z[3,1,0]  R1231     -3.5671177506446838e-01
    z[3,1,0]  R1232     -4.2242676019668579e-02
    z[3,1,0]  R1233     -5.9709161520004272e-01
    z[3,1,0]  R1234     -7.8293181955814362e-02
    z[3,1,0]  R1235     -1.2750937603414059e-02
    z[3,1,0]  R1236     -6.8526011705398560e-01
    z[3,1,0]  R1237     -5.3374101407825947e-03
    z[3,1,0]  R1238     -7.7924764156341553e-01
    z[3,1,0]  R1239     -1.6494253277778625e-01
    z[3,1,0]  R1240     1.0237602144479752e-01
    z[3,1,0]  R1241     -9.1826446354389191e-02
    z[3,1,0]  R1242     -1.0050944983959198e-01
    z[3,1,0]  R1243     -6.5777927637100220e-02
    z[3,1,0]  R1244     -2.2169025242328644e-01
    z[3,1,0]  R1245     2.1646836772561073e-02
    z[3,1,0]  R1246     5.4830335080623627e-02
    z[3,1,0]  R1247     6.3755147159099579e-02
    z[3,1,0]  R1248     -3.9741796255111694e-01
    z[3,1,0]  R1249     1.9783353805541992e-01
    z[3,1,0]  R1250     9.0975388884544373e-02
    z[3,1,0]  R1251     7.3167368769645691e-02
    z[3,1,0]  R1252     2.3548530042171478e-01
    z[3,1,0]  R1253     2.6657110452651978e-01
    z[3,1,0]  R1254     1.6141006350517273e-01
    z[3,1,0]  R1255     -5.9019678831100464e-01
    z[3,1,0]  R1256     2.3474588990211487e-01
    z[3,1,0]  R1257     3.3537900447845459e-01
    z[3,1,0]  R1258     2.8809833526611328e-01
    z[3,1,0]  R1259     2.9013855382800102e-02
    z[3,1,0]  R1260     1.7178709805011749e-01
    z[3,1,0]  R1261     0.073527030646801
    z[3,1,0]  R1262     3.7063896656036377e-01
    z[3,1,0]  R1263     3.3976495265960693e-01
    z[3,1,0]  R1264     3.7903591990470886e-01
    z[3,1,0]  R1265     4.6893391013145447e-01
    z[3,1,0]  R1266     2.6620736718177795e-01
    z[3,1,0]  R1267     5.3020846843719482e-01
    z[3,1,0]  R1268     8.5024207830429077e-01
    z[3,1,0]  R1269     7.7913725376129150e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R1158     -1
    z[3,1,1]  R1159     1
    z[3,1,1]  R1170     -7.8813350200653076e-01
    z[3,1,1]  R1171     -6.3816928863525391e-01
    z[3,1,1]  R1172     -5.9123784303665161e-01
    z[3,1,1]  R1173     6.3668894767761230e-01
    z[3,1,1]  R1174     -2.9680398106575012e-01
    z[3,1,1]  R1175     -3.4536263346672058e-01
    z[3,1,1]  R1176     -3.0272287130355835e-01
    z[3,1,1]  R1177     6.2705171108245850e-01
    z[3,1,1]  R1178     5.4102611541748047e-01
    z[3,1,1]  R1179     7.6169586181640625e-01
    z[3,1,1]  R1180     -4.5111289620399475e-01
    z[3,1,1]  R1181     -0.439800888299942
    z[3,1,1]  R1182     -3.8439545035362244e-01
    z[3,1,1]  R1183     -3.6523753404617310e-01
    z[3,1,1]  R1184     -4.0704101324081421e-01
    z[3,1,1]  R1185     -2.5016698241233826e-01
    z[3,1,1]  R1186     7.4719732999801636e-01
    z[3,1,1]  R1187     6.8427371978759766e-01
    z[3,1,1]  R1188     6.9754534959793091e-01
    z[3,1,1]  R1189     1.9880345463752747e-01
    z[3,1,1]  R1190     0.857233464717865
    z[3,1,1]  R1191     7.9025137424468994e-01
    z[3,1,1]  R1192     8.0379545688629150e-01
    z[3,1,1]  R1193     6.9972038269042969e-01
    z[3,1,1]  R1194     8.0500149726867676e-01
    z[3,1,1]  R1195     7.3723131418228149e-01
    z[3,1,1]  R1196     6.5980720520019531e-01
    z[3,1,1]  R1197     5.4039853811264038e-01
    z[3,1,1]  R1198     6.3432049751281738e-01
    z[3,1,1]  R1199     3.8795873522758484e-01
    z[3,1,1]  R1200     -6.5281128883361816e-01
    z[3,1,1]  R1201     -4.6596240997314453e-01
    z[3,1,1]  R1202     8.1147712469100952e-01
    z[3,1,1]  R1203     7.8923958539962769e-01
    z[3,1,1]  R1204     4.0587291121482849e-01
    z[3,1,1]  R1205     7.8663498163223267e-01
    z[3,1,1]  R1206     4.4646963477134705e-01
    z[3,1,1]  R1207     1.2665164470672607e-01
    z[3,1,1]  R1208     5.2032095193862915e-01
    z[3,1,1]  R1209     2.4986878037452698e-01
    z[3,1,1]  R1210     4.8440101742744446e-01
    z[3,1,1]  R1211     6.6852509975433350e-01
    z[3,1,1]  R1212     6.3663446903228760e-01
    z[3,1,1]  R1213     4.4251322746276855e-01
    z[3,1,1]  R1214     8.6939907073974609e-01
    z[3,1,1]  R1215     6.1848264932632446e-01
    z[3,1,1]  R1216     3.2343354821205139e-01
    z[3,1,1]  R1217     5.4146373271942139e-01
    z[3,1,1]  R1218     1.8972527980804443e-01
    z[3,1,1]  R1219     4.1707709431648254e-01
    z[3,1,1]  R1220     4.7122615575790405e-01
    z[3,1,1]  R1221     6.4674860239028931e-01
    z[3,1,1]  R1222     7.6113170385360718e-01
    z[3,1,1]  R1223     4.8126682639122009e-01
    z[3,1,1]  R1224     4.3018519878387451e-01
    z[3,1,1]  R1225     2.5084331631660461e-01
    z[3,1,1]  R1226     -3.1143131852149963e-01
    z[3,1,1]  R1227     -1.7610348761081696e-01
    z[3,1,1]  R1228     -2.7668842673301697e-01
    z[3,1,1]  R1229     -3.7183105945587158e-01
    z[3,1,1]  R1230     -4.1153582930564880e-01
    z[3,1,1]  R1231     0.573833703994751
    z[3,1,1]  R1232     -0.366733580827713
    z[3,1,1]  R1233     2.7760806679725647e-01
    z[3,1,1]  R1234     -4.9850201606750488e-01
    z[3,1,1]  R1235     -0.262656033039093
    z[3,1,1]  R1236     3.9246013760566711e-01
    z[3,1,1]  R1237     -2.8604340553283691e-01
    z[3,1,1]  R1238     1.2124329805374146e-01
    z[3,1,1]  R1239     5.4653489589691162e-01
    z[3,1,1]  R1240     -7.8913533687591553e-01
    z[3,1,1]  R1241     -7.8548103570938110e-01
    z[3,1,1]  R1242     -7.8021126985549927e-01
    z[3,1,1]  R1243     -7.6294887065887451e-01
    z[3,1,1]  R1244     -7.4078255891799927e-01
    z[3,1,1]  R1245     -7.4767166376113892e-01
    z[3,1,1]  R1246     -6.2841165065765381e-01
    z[3,1,1]  R1247     -7.1363770961761475e-01
    z[3,1,1]  R1248     -6.6738867759704590e-01
    z[3,1,1]  R1249     -5.4265409708023071e-01
    z[3,1,1]  R1250     -8.6383581161499023e-01
    z[3,1,1]  R1251     -4.6129563450813293e-01
    z[3,1,1]  R1252     -5.1387935876846313e-01
    z[3,1,1]  R1253     -4.2744708061218262e-01
    z[3,1,1]  R1254     -0.583754301071167
    z[3,1,1]  R1255     1.9236426055431366e-01
    z[3,1,1]  R1256     -3.0478119850158691e-01
    z[3,1,1]  R1257     -4.9917593598365784e-01
    z[3,1,1]  R1258     -5.3909343481063843e-01
    z[3,1,1]  R1259     5.0474762916564941e-01
    z[3,1,1]  R1260     -5.4632717370986938e-01
    z[3,1,1]  R1261     -5.4762643575668335e-01
    z[3,1,1]  R1262     -1.4396350085735321e-01
    z[3,1,1]  R1263     -2.5115618109703064e-01
    z[3,1,1]  R1264     -4.8610472679138184e-01
    z[3,1,1]  R1265     4.6591964364051819e-01
    z[3,1,1]  R1266     5.2314704656600952e-01
    z[3,1,1]  R1267     4.5538052916526794e-01
    z[3,1,1]  R1268     3.7054851651191711e-01
    z[3,1,1]  R1269     3.2702940702438354e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R1160     -1
    z[3,1,2]  R1161     1
    z[3,1,2]  R1170     2.9155045747756958e-01
    z[3,1,2]  R1171     -4.2261886596679688e-01
    z[3,1,2]  R1172     0.0226475540548563
    z[3,1,2]  R1173     -7.3616698384284973e-02
    z[3,1,2]  R1174     0.351779967546463
    z[3,1,2]  R1175     -1.2747351825237274e-01
    z[3,1,2]  R1176     -1.1474695056676865e-01
    z[3,1,2]  R1177     3.4420590847730637e-02
    z[3,1,2]  R1178     2.1619459986686707e-01
    z[3,1,2]  R1179     2.0916143059730530e-01
    z[3,1,2]  R1180     6.6711580753326416e-01
    z[3,1,2]  R1181     1.9830379635095596e-02
    z[3,1,2]  R1182     4.0915283560752869e-01
    z[3,1,2]  R1183     5.5210381746292114e-02
    z[3,1,2]  R1184     -1.1304409801959991e-01
    z[3,1,2]  R1185     -6.1652410030364990e-01
    z[3,1,2]  R1186     -1.5276296436786652e-01
    z[3,1,2]  R1187     1.4430822432041168e-01
    z[3,1,2]  R1188     -2.7639037370681763e-01
    z[3,1,2]  R1189     -3.8856777548789978e-01
    z[3,1,2]  R1190     2.6850545406341553e-01
    z[3,1,2]  R1191     -1.3540776073932648e-01
    z[3,1,2]  R1192     -1.0470170527696609e-01
    z[3,1,2]  R1193     -3.6883455514907837e-01
    z[3,1,2]  R1194     -1.7168706655502319e-01
    z[3,1,2]  R1195     4.8716634511947632e-01
    z[3,1,2]  R1196     1.8579114973545074e-01
    z[3,1,2]  R1197     -4.8725920915603638e-01
    z[3,1,2]  R1198     -2.5702643394470215e-01
    z[3,1,2]  R1199     2.5466141104698181e-01
    z[3,1,2]  R1200     -3.2065615057945251e-01
    z[3,1,2]  R1201     3.8088664412498474e-01
    z[3,1,2]  R1202     -5.6624421849846840e-03
    z[3,1,2]  R1203     -2.9873631894588470e-02
    z[3,1,2]  R1204     -6.1045056581497192e-01
    z[3,1,2]  R1205     -2.4921372532844543e-01
    z[3,1,2]  R1206     -4.9589291214942932e-01
    z[3,1,2]  R1207     3.9476905949413776e-03
    z[3,1,2]  R1208     3.8990476727485657e-01
    z[3,1,2]  R1209     4.9159295856952667e-02
    z[3,1,2]  R1210     -4.7137516736984253e-01
    z[3,1,2]  R1211     7.6161310076713562e-02
    z[3,1,2]  R1212     3.3059367537498474e-01
    z[3,1,2]  R1213     -1.8056605011224747e-02
    z[3,1,2]  R1214     8.5890352725982666e-02
    z[3,1,2]  R1215     -1.1896006017923355e-01
    z[3,1,2]  R1216     -3.1947073340415955e-01
    z[3,1,2]  R1217     4.3478971719741821e-01
    z[3,1,2]  R1218     -1.6211281716823578e-01
    z[3,1,2]  R1219     1.5092931687831879e-01
    z[3,1,2]  R1220     -4.5245864987373352e-01
    z[3,1,2]  R1221     -1.4433425664901733e-01
    z[3,1,2]  R1222     3.1044140458106995e-01
    z[3,1,2]  R1223     -2.6153931021690369e-01
    z[3,1,2]  R1224     -0.280733197927475
    z[3,1,2]  R1225     -1.3410811126232147e-01
    z[3,1,2]  R1226     5.7834321260452271e-01
    z[3,1,2]  R1227     3.7822961807250977e-01
    z[3,1,2]  R1228     4.3421438336372375e-01
    z[3,1,2]  R1229     4.9262502789497375e-01
    z[3,1,2]  R1230     5.0443840026855469e-01
    z[3,1,2]  R1231     -4.9243211746215820e-01
    z[3,1,2]  R1232     1.2689022719860077e-01
    z[3,1,2]  R1233     -0.626781165599823
    z[3,1,2]  R1234     7.9153716564178467e-01
    z[3,1,2]  R1235     7.2913813591003418e-01
    z[3,1,2]  R1236     -4.3528309464454651e-01
    z[3,1,2]  R1237     3.0553472042083740e-01
    z[3,1,2]  R1238     -5.4495644569396973e-01
    z[3,1,2]  R1239     -7.0033740997314453e-01
    z[3,1,2]  R1240     -3.6397790908813477e-01
    z[3,1,2]  R1241     -2.8767114877700806e-01
    z[3,1,2]  R1242     -3.3676931262016296e-01
    z[3,1,2]  R1243     -3.1985855102539062e-01
    z[3,1,2]  R1244     -2.3950286209583282e-01
    z[3,1,2]  R1245     -1.2533517181873322e-01
    z[3,1,2]  R1246     1.7164391279220581e-01
    z[3,1,2]  R1247     -2.3216864466667175e-01
    z[3,1,2]  R1248     1.0192343033850193e-03
    z[3,1,2]  R1249     9.2219136655330658e-02
    z[3,1,2]  R1250     1.1176556348800659e-01
    z[3,1,2]  R1251     3.0754688382148743e-01
    z[3,1,2]  R1252     0.3104248046875
    z[3,1,2]  R1253     4.3009561300277710e-01
    z[3,1,2]  R1254     -1.9003529846668243e-01
    z[3,1,2]  R1255     -3.1999304890632629e-01
    z[3,1,2]  R1256     5.9365980327129364e-02
    z[3,1,2]  R1257     5.3292375802993774e-01
    z[3,1,2]  R1258     1.1547703295946121e-01
    z[3,1,2]  R1259     3.5850954055786133e-01
    z[3,1,2]  R1260     1.8182796239852905e-01
    z[3,1,2]  R1261     5.6437408924102783e-01
    z[3,1,2]  R1262     7.5032621622085571e-01
    z[3,1,2]  R1263     1.2528024613857269e-01
    z[3,1,2]  R1264     2.2773987054824829e-01
    z[3,1,2]  R1265     2.6856359094381332e-02
    z[3,1,2]  R1266     1.8239600956439972e-01
    z[3,1,2]  R1267     2.3532277345657349e-01
    z[3,1,2]  R1268     1.6897714138031006e-01
    z[3,1,2]  R1269     6.8543985486030579e-02
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R1162     -1
    z[3,1,3]  R1163     1
    z[3,1,3]  R1170     1.1979837715625763e-01
    z[3,1,3]  R1171     -5.2399146556854248e-01
    z[3,1,3]  R1172     6.6634345054626465e-01
    z[3,1,3]  R1173     -1.1344969272613525e-01
    z[3,1,3]  R1174     -8.2266800105571747e-02
    z[3,1,3]  R1175     -0.0785977765917778
    z[3,1,3]  R1176     -4.3732246756553650e-01
    z[3,1,3]  R1177     -4.9222588539123535e-01
    z[3,1,3]  R1178     -0.789358377456665
    z[3,1,3]  R1179     -5.1896160840988159e-01
    z[3,1,3]  R1180     -1.4762806892395020e-01
    z[3,1,3]  R1181     -7.1839645504951477e-02
    z[3,1,3]  R1182     -5.1226228475570679e-01
    z[3,1,3]  R1183     2.3346434533596039e-01
    z[3,1,3]  R1184     -1.5381909906864166e-01
    z[3,1,3]  R1185     -1.4028598368167877e-01
    z[3,1,3]  R1186     -6.1548583209514618e-02
    z[3,1,3]  R1187     -3.1095218658447266e-01
    z[3,1,3]  R1188     -3.7301453948020935e-01
    z[3,1,3]  R1189     -4.6497520804405212e-01
    z[3,1,3]  R1190     -3.3105546236038208e-01
    z[3,1,3]  R1191     -4.6913620829582214e-01
    z[3,1,3]  R1192     -4.1991695761680603e-01
    z[3,1,3]  R1193     -5.5058246850967407e-01
    z[3,1,3]  R1194     5.0946021080017090e-01
    z[3,1,3]  R1195     -6.6334336996078491e-02
    z[3,1,3]  R1196     2.7412867546081543e-01
    z[3,1,3]  R1197     4.4249475002288818e-01
    z[3,1,3]  R1198     3.2248049974441528e-01
    z[3,1,3]  R1199     -4.0056106448173523e-01
    z[3,1,3]  R1200     4.4133597612380981e-01
    z[3,1,3]  R1201     -0.0772356316447258
    z[3,1,3]  R1202     2.7450013160705566e-01
    z[3,1,3]  R1203     -5.1207160949707031e-01
    z[3,1,3]  R1204     -3.5299211740493774e-01
    z[3,1,3]  R1205     -5.8170523494482040e-02
    z[3,1,3]  R1206     -0.651406466960907
    z[3,1,3]  R1207     -5.9365576505661011e-01
    z[3,1,3]  R1208     -0.0291308481246233
    z[3,1,3]  R1209     -5.1408547163009644e-01
    z[3,1,3]  R1210     -5.0025876611471176e-02
    z[3,1,3]  R1211     5.7337163016200066e-03
    z[3,1,3]  R1212     -5.2307796478271484e-01
    z[3,1,3]  R1213     8.1351123750209808e-02
    z[3,1,3]  R1214     -1.3375589251518250e-01
    z[3,1,3]  R1215     -3.2607337832450867e-01
    z[3,1,3]  R1216     -0.739935040473938
    z[3,1,3]  R1217     -2.4455970525741577e-01
    z[3,1,3]  R1218     -5.2082246541976929e-01
    z[3,1,3]  R1219     -9.2234991490840912e-02
    z[3,1,3]  R1220     -3.7684386968612671e-01
    z[3,1,3]  R1221     2.8232610225677490e-01
    z[3,1,3]  R1222     3.2263547182083130e-01
    z[3,1,3]  R1223     -6.4435219764709473e-01
    z[3,1,3]  R1224     -3.7938350439071655e-01
    z[3,1,3]  R1225     -5.5153644084930420e-01
    z[3,1,3]  R1226     -3.8196936249732971e-01
    z[3,1,3]  R1227     -4.2192295193672180e-01
    z[3,1,3]  R1228     -3.7358319759368896e-01
    z[3,1,3]  R1229     -4.0055724978446960e-01
    z[3,1,3]  R1230     5.3050768375396729e-01
    z[3,1,3]  R1231     2.4304993450641632e-01
    z[3,1,3]  R1232     0.799430251121521
    z[3,1,3]  R1233     1.0718559473752975e-01
    z[3,1,3]  R1234     1.0570231825113297e-01
    z[3,1,3]  R1235     5.6906795501708984e-01
    z[3,1,3]  R1236     1.5660229325294495e-01
    z[3,1,3]  R1237     6.4447224140167236e-01
    z[3,1,3]  R1238     2.4263779819011688e-01
    z[3,1,3]  R1239     1.3728702068328857e-01
    z[3,1,3]  R1240     0.174093097448349
    z[3,1,3]  R1241     -2.9917600750923157e-01
    z[3,1,3]  R1242     -3.9608660340309143e-01
    z[3,1,3]  R1243     -4.9124431610107422e-01
    z[3,1,3]  R1244     -4.4795447587966919e-01
    z[3,1,3]  R1245     -4.1094160079956055e-01
    z[3,1,3]  R1246     -4.0366217494010925e-01
    z[3,1,3]  R1247     -4.2908832430839539e-01
    z[3,1,3]  R1248     -1.9940476119518280e-01
    z[3,1,3]  R1249     -5.6705063581466675e-01
    z[3,1,3]  R1250     1.2812471017241478e-02
    z[3,1,3]  R1251     3.9192914962768555e-01
    z[3,1,3]  R1252     -1.0241139680147171e-01
    z[3,1,3]  R1253     -2.2310981154441833e-01
    z[3,1,3]  R1254     -5.0097241997718811e-02
    z[3,1,3]  R1255     5.2560776472091675e-02
    z[3,1,3]  R1256     2.0923748612403870e-01
    z[3,1,3]  R1257     1.9200769066810608e-01
    z[3,1,3]  R1258     8.4713473916053772e-02
    z[3,1,3]  R1259     6.5258580446243286e-01
    z[3,1,3]  R1260     7.9723989963531494e-01
    z[3,1,3]  R1261     5.0779759883880615e-01
    z[3,1,3]  R1262     1.6282172501087189e-01
    z[3,1,3]  R1263     4.7349786758422852e-01
    z[3,1,3]  R1264     8.6323969066143036e-02
    z[3,1,3]  R1265     3.1835392117500305e-01
    z[3,1,3]  R1266     -2.1111611276865005e-02
    z[3,1,3]  R1267     6.1433070898056030e-01
    z[3,1,3]  R1268     -1.2037465721368790e-01
    z[3,1,3]  R1269     -4.6486461162567139e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R1164     -1
    z[3,1,4]  R1165     1
    z[3,1,4]  R1170     4.0810516476631165e-01
    z[3,1,4]  R1171     -8.2651257514953613e-02
    z[3,1,4]  R1172     2.2359290719032288e-01
    z[3,1,4]  R1173     1.9921872019767761e-01
    z[3,1,4]  R1174     -2.0305125415325165e-01
    z[3,1,4]  R1175     -3.4954020380973816e-01
    z[3,1,4]  R1176     7.8294515609741211e-02
    z[3,1,4]  R1177     3.9334109425544739e-01
    z[3,1,4]  R1178     -0.0928015261888504
    z[3,1,4]  R1179     2.6882079243659973e-01
    z[3,1,4]  R1180     6.7703694105148315e-02
    z[3,1,4]  R1181     -0.374188095331192
    z[3,1,4]  R1182     -1.1617810279130936e-01
    z[3,1,4]  R1183     -4.3234923481941223e-01
    z[3,1,4]  R1184     2.4462303519248962e-01
    z[3,1,4]  R1185     2.2121407091617584e-01
    z[3,1,4]  R1186     7.4796296656131744e-02
    z[3,1,4]  R1187     -7.2107151150703430e-02
    z[3,1,4]  R1188     -1.8771593272686005e-01
    z[3,1,4]  R1189     1.6012816131114960e-01
    z[3,1,4]  R1190     3.7444159388542175e-02
    z[3,1,4]  R1191     -1.1119368486106396e-02
    z[3,1,4]  R1192     1.2771655619144440e-01
    z[3,1,4]  R1193     1.7380365170538425e-03
    z[3,1,4]  R1194     -1.5074522234499454e-02
    z[3,1,4]  R1195     1.9664084911346436e-01
    z[3,1,4]  R1196     2.1345909684896469e-02
    z[3,1,4]  R1197     -1.5040965750813484e-02
    z[3,1,4]  R1198     5.8716509491205215e-02
    z[3,1,4]  R1199     -1.1619853228330612e-01
    z[3,1,4]  R1200     -2.2021043300628662e-01
    z[3,1,4]  R1201     -6.2694478034973145e-01
    z[3,1,4]  R1202     -1.0876150429248810e-01
    z[3,1,4]  R1203     1.5709446370601654e-01
    z[3,1,4]  R1204     -7.1048364043235779e-02
    z[3,1,4]  R1205     5.4756116867065430e-01
    z[3,1,4]  R1206     1.0645416378974915e-01
    z[3,1,4]  R1207     2.1118494868278503e-01
    z[3,1,4]  R1208     -1.6663597524166107e-01
    z[3,1,4]  R1209     3.7277019023895264e-01
    z[3,1,4]  R1210     -8.5882298648357391e-02
    z[3,1,4]  R1211     7.4555687606334686e-02
    z[3,1,4]  R1212     2.8460854291915894e-01
    z[3,1,4]  R1213     1.0403080284595490e-01
    z[3,1,4]  R1214     0.081064872443676
    z[3,1,4]  R1215     4.7856429219245911e-01
    z[3,1,4]  R1216     9.7546920180320740e-02
    z[3,1,4]  R1217     -4.3939024209976196e-01
    z[3,1,4]  R1218     1.4860205352306366e-01
    z[3,1,4]  R1219     2.2053673863410950e-01
    z[3,1,4]  R1220     -1.1096361279487610e-01
    z[3,1,4]  R1221     -4.2400330305099487e-02
    z[3,1,4]  R1222     1.3898704946041107e-01
    z[3,1,4]  R1223     3.9633655548095703e-01
    z[3,1,4]  R1224     4.7889527678489685e-01
    z[3,1,4]  R1225     1.7635495960712433e-01
    z[3,1,4]  R1226     7.3480255901813507e-02
    z[3,1,4]  R1227     3.4458291530609131e-01
    z[3,1,4]  R1228     3.3864155411720276e-01
    z[3,1,4]  R1229     2.0493526756763458e-01
    z[3,1,4]  R1230     2.6285862922668457e-01
    z[3,1,4]  R1231     2.0473259687423706e-01
    z[3,1,4]  R1232     2.8543433547019958e-01
    z[3,1,4]  R1233     1.7861008644104004e-01
    z[3,1,4]  R1234     3.9897285401821136e-02
    z[3,1,4]  R1235     -1.0376599431037903e-01
    z[3,1,4]  R1236     2.9115831851959229e-01
    z[3,1,4]  R1237     5.5429106950759888e-01
    z[3,1,4]  R1238     -1.4271882176399231e-01
    z[3,1,4]  R1239     -1.6991877555847168e-01
    z[3,1,4]  R1240     -3.5168644785881042e-01
    z[3,1,4]  R1241     -2.1051105856895447e-01
    z[3,1,4]  R1242     1.6175056993961334e-01
    z[3,1,4]  R1243     1.5208730101585388e-01
    z[3,1,4]  R1244     -1.2244738638401031e-01
    z[3,1,4]  R1245     2.9136139154434204e-01
    z[3,1,4]  R1246     8.3066321909427643e-02
    z[3,1,4]  R1247     2.1944449841976166e-01
    z[3,1,4]  R1248     2.4374271929264069e-01
    z[3,1,4]  R1249     2.9229193925857544e-01
    z[3,1,4]  R1250     3.7499007582664490e-01
    z[3,1,4]  R1251     -5.2446460723876953e-01
    z[3,1,4]  R1252     1.5510775148868561e-01
    z[3,1,4]  R1253     -3.1334522366523743e-01
    z[3,1,4]  R1254     0.34656822681427
    z[3,1,4]  R1255     -2.3756182193756104e-01
    z[3,1,4]  R1256     3.7706881761550903e-01
    z[3,1,4]  R1257     -5.1656424999237061e-01
    z[3,1,4]  R1258     -3.3346924185752869e-01
    z[3,1,4]  R1259     2.6950253173708916e-02
    z[3,1,4]  R1260     0.00511670857667923
    z[3,1,4]  R1261     1.8650548160076141e-01
    z[3,1,4]  R1262     4.6590843796730042e-01
    z[3,1,4]  R1263     1.1250261217355728e-01
    z[3,1,4]  R1264     -5.7950061559677124e-01
    z[3,1,4]  R1265     -5.7460999488830566e-01
    z[3,1,4]  R1266     -3.1709730625152588e-01
    z[3,1,4]  R1267     -1.8819181621074677e-01
    z[3,1,4]  R1268     2.0447519421577454e-01
    z[3,1,4]  R1269     1.5613253414630890e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R1166     -1
    z[3,1,5]  R1167     1
    z[3,1,5]  R1170     2.9796305298805237e-01
    z[3,1,5]  R1171     3.5531315207481384e-01
    z[3,1,5]  R1172     3.1273981928825378e-01
    z[3,1,5]  R1173     1.5132869780063629e-01
    z[3,1,5]  R1174     8.2891270518302917e-02
    z[3,1,5]  R1175     1.8760459125041962e-01
    z[3,1,5]  R1176     -2.9356718063354492e-01
    z[3,1,5]  R1177     1.7945627868175507e-01
    z[3,1,5]  R1178     1.5480084717273712e-01
    z[3,1,5]  R1179     -4.5567336492240429e-03
    z[3,1,5]  R1180     -3.7057882547378540e-01
    z[3,1,5]  R1181     -5.8638083934783936e-01
    z[3,1,5]  R1182     -4.7048667073249817e-01
    z[3,1,5]  R1183     -7.1876019239425659e-01
    z[3,1,5]  R1184     -7.1208667755126953e-01
    z[3,1,5]  R1185     -6.4713490009307861e-01
    z[3,1,5]  R1186     3.7273174524307251e-01
    z[3,1,5]  R1187     -4.8278215527534485e-01
    z[3,1,5]  R1188     -3.8958466053009033e-01
    z[3,1,5]  R1189     -6.2846875190734863e-01
    z[3,1,5]  R1190     -2.0935179293155670e-01
    z[3,1,5]  R1191     7.1825966238975525e-02
    z[3,1,5]  R1192     -3.5511177778244019e-01
    z[3,1,5]  R1193     -2.0457766950130463e-01
    z[3,1,5]  R1194     -7.8436665236949921e-02
    z[3,1,5]  R1195     -3.5082376003265381e-01
    z[3,1,5]  R1196     -6.2063324451446533e-01
    z[3,1,5]  R1197     -1.5862299501895905e-01
    z[3,1,5]  R1198     -5.3206694126129150e-01
    z[3,1,5]  R1199     6.7930233478546143e-01
    z[3,1,5]  R1200     2.5022828578948975e-01
    z[3,1,5]  R1201     2.9681313037872314e-01
    z[3,1,5]  R1202     2.6027432084083557e-01
    z[3,1,5]  R1203     2.3415267467498779e-01
    z[3,1,5]  R1204     2.4350734055042267e-01
    z[3,1,5]  R1205     3.1304490403272212e-04
    z[3,1,5]  R1206     -1.4754687249660492e-01
    z[3,1,5]  R1207     -1.8984548747539520e-01
    z[3,1,5]  R1208     4.3392565846443176e-01
    z[3,1,5]  R1209     4.6961772441864014e-01
    z[3,1,5]  R1210     4.2950622737407684e-02
    z[3,1,5]  R1211     2.3239459097385406e-01
    z[3,1,5]  R1212     3.4280958771705627e-01
    z[3,1,5]  R1213     -5.4389089345932007e-01
    z[3,1,5]  R1214     -2.7062374353408813e-01
    z[3,1,5]  R1215     -1.4795990660786629e-02
    z[3,1,5]  R1216     6.6138349473476410e-02
    z[3,1,5]  R1217     1.2924763560295105e-01
    z[3,1,5]  R1218     6.0124790668487549e-01
    z[3,1,5]  R1219     6.1871415376663208e-01
    z[3,1,5]  R1220     2.0373660326004028e-01
    z[3,1,5]  R1221     4.3375995010137558e-02
    z[3,1,5]  R1222     1.8051321804523468e-01
    z[3,1,5]  R1223     -7.3148764669895172e-02
    z[3,1,5]  R1224     -3.7347188591957092e-01
    z[3,1,5]  R1225     6.7983222007751465e-01
    z[3,1,5]  R1226     1.7246770858764648e-01
    z[3,1,5]  R1227     -1.8709598109126091e-02
    z[3,1,5]  R1228     2.1293669939041138e-01
    z[3,1,5]  R1229     2.7812838554382324e-01
    z[3,1,5]  R1230     -6.3787393271923065e-02
    z[3,1,5]  R1231     -4.0692013502120972e-01
    z[3,1,5]  R1232     1.3815888762474060e-01
    z[3,1,5]  R1233     -2.3018175363540649e-01
    z[3,1,5]  R1234     -3.1856033205986023e-01
    z[3,1,5]  R1235     -1.9800245761871338e-01
    z[3,1,5]  R1236     -1.3131687045097351e-01
    z[3,1,5]  R1237     2.0805935561656952e-01
    z[3,1,5]  R1238     -2.8782995417714119e-02
    z[3,1,5]  R1239     1.7422935366630554e-01
    z[3,1,5]  R1240     -1.3307310640811920e-01
    z[3,1,5]  R1241     3.2203185558319092e-01
    z[3,1,5]  R1242     6.9552063941955566e-02
    z[3,1,5]  R1243     1.4325352013111115e-01
    z[3,1,5]  R1244     2.9530632495880127e-01
    z[3,1,5]  R1245     4.1212841868400574e-01
    z[3,1,5]  R1246     5.8570575714111328e-01
    z[3,1,5]  R1247     -4.3115538358688354e-01
    z[3,1,5]  R1248     4.2247429490089417e-01
    z[3,1,5]  R1249     -1.7058970034122467e-01
    z[3,1,5]  R1250     -1.5608721971511841e-01
    z[3,1,5]  R1251     -5.0835871696472168e-01
    z[3,1,5]  R1252     6.9800531864166260e-01
    z[3,1,5]  R1253     2.4462699890136719e-01
    z[3,1,5]  R1254     4.6346226334571838e-01
    z[3,1,5]  R1255     -6.4760148525238037e-01
    z[3,1,5]  R1256     -8.1387633085250854e-01
    z[3,1,5]  R1257     1.3412535190582275e-01
    z[3,1,5]  R1258     2.1217954158782959e-01
    z[3,1,5]  R1259     -1.9284363090991974e-01
    z[3,1,5]  R1260     -5.1182083785533905e-02
    z[3,1,5]  R1261     2.1714878082275391e-01
    z[3,1,5]  R1262     -1.0764618217945099e-01
    z[3,1,5]  R1263     6.0474467277526855e-01
    z[3,1,5]  R1264     0.469120055437088
    z[3,1,5]  R1265     -0.361625075340271
    z[3,1,5]  R1266     -5.3766030073165894e-01
    z[3,1,5]  R1267     -1.6545116901397705e-01
    z[3,1,5]  R1268     1.3289323449134827e-01
    z[3,1,5]  R1269     -9.6647344529628754e-02
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R1168     -1
    z[3,1,6]  R1169     1
    z[3,1,6]  R1170     -1.5106844902038574e-01
    z[3,1,6]  R1171     -4.0926668792963028e-02
    z[3,1,6]  R1172     2.4069119989871979e-01
    z[3,1,6]  R1173     -1.2605784833431244e-01
    z[3,1,6]  R1174     -0.855800211429596
    z[3,1,6]  R1175     -8.3539414405822754e-01
    z[3,1,6]  R1176     -7.7902823686599731e-01
    z[3,1,6]  R1177     -2.4133461713790894e-01
    z[3,1,6]  R1178     1.3475725427269936e-02
    z[3,1,6]  R1179     1.5930871665477753e-01
    z[3,1,6]  R1180     -1.2160740792751312e-01
    z[3,1,6]  R1181     5.5052947998046875e-01
    z[3,1,6]  R1182     4.1892027854919434e-01
    z[3,1,6]  R1183     -2.7657487988471985e-01
    z[3,1,6]  R1184     4.7432950139045715e-01
    z[3,1,6]  R1185     1.1000140011310577e-01
    z[3,1,6]  R1186     -1.4250591397285461e-01
    z[3,1,6]  R1187     -3.6658516526222229e-01
    z[3,1,6]  R1188     -8.4278509020805359e-03
    z[3,1,6]  R1189     1.2105721980333328e-01
    z[3,1,6]  R1190     1.3495326042175293e-01
    z[3,1,6]  R1191     2.2954124957323074e-02
    z[3,1,6]  R1192     -1.2433709204196930e-01
    z[3,1,6]  R1193     -7.0504434406757355e-02
    z[3,1,6]  R1194     1.5510024130344391e-01
    z[3,1,6]  R1195     5.9778308495879173e-03
    z[3,1,6]  R1196     2.5904938578605652e-02
    z[3,1,6]  R1197     3.6149981617927551e-01
    z[3,1,6]  R1198     -3.0157101154327393e-01
    z[3,1,6]  R1199     -1.7899684607982635e-01
    z[3,1,6]  R1200     -3.8635396957397461e-01
    z[3,1,6]  R1201     -2.5926964357495308e-02
    z[3,1,6]  R1202     -1.3939090073108673e-01
    z[3,1,6]  R1203     -1.5291011333465576e-01
    z[3,1,6]  R1204     3.7921956181526184e-01
    z[3,1,6]  R1205     1.2522467970848083e-01
    z[3,1,6]  R1206     0.085883229970932
    z[3,1,6]  R1207     0.446367472410202
    z[3,1,6]  R1208     9.8310850560665131e-02
    z[3,1,6]  R1209     5.5508965253829956e-01
    z[3,1,6]  R1210     4.5687967538833618e-01
    z[3,1,6]  R1211     4.9932867288589478e-01
    z[3,1,6]  R1212     0.0560506135225296
    z[3,1,6]  R1213     2.1495828032493591e-01
    z[3,1,6]  R1214     -3.6913719773292542e-01
    z[3,1,6]  R1215     5.1739192008972168e-01
    z[3,1,6]  R1216     0.447817862033844
    z[3,1,6]  R1217     -0.235219344496727
    z[3,1,6]  R1218     4.0423431992530823e-01
    z[3,1,6]  R1219     3.9935973286628723e-01
    z[3,1,6]  R1220     -7.1068987250328064e-02
    z[3,1,6]  R1221     -1.8020041286945343e-02
    z[3,1,6]  R1222     1.3029550015926361e-01
    z[3,1,6]  R1223     2.6778453588485718e-01
    z[3,1,6]  R1224     2.6788255572319031e-01
    z[3,1,6]  R1225     2.2394201159477234e-01
    z[3,1,6]  R1226     -8.8726624846458435e-02
    z[3,1,6]  R1227     2.9218995571136475e-01
    z[3,1,6]  R1228     2.7505829930305481e-01
    z[3,1,6]  R1229     2.0124079287052155e-01
    z[3,1,6]  R1230     -4.6854072809219360e-01
    z[3,1,6]  R1231     -1.8549780547618866e-01
    z[3,1,6]  R1232     -3.2859003543853760e-01
    z[3,1,6]  R1233     -2.7782490849494934e-01
    z[3,1,6]  R1234     -0.0677451640367508
    z[3,1,6]  R1235     1.5936177968978882e-01
    z[3,1,6]  R1236     2.4572479724884033e-01
    z[3,1,6]  R1237     2.4274982511997223e-01
    z[3,1,6]  R1238     3.2023850828409195e-02
    z[3,1,6]  R1239     3.2487708330154419e-01
    z[3,1,6]  R1240     2.5020885467529297e-01
    z[3,1,6]  R1241     -2.3303854465484619e-01
    z[3,1,6]  R1242     2.8261154890060425e-01
    z[3,1,6]  R1243     -1.6217219829559326e-01
    z[3,1,6]  R1244     2.0462350547313690e-01
    z[3,1,6]  R1245     -3.4572128206491470e-02
    z[3,1,6]  R1246     2.4441033601760864e-01
    z[3,1,6]  R1247     1.2077458202838898e-01
    z[3,1,6]  R1248     3.4495350718498230e-01
    z[3,1,6]  R1249     0.470958948135376
    z[3,1,6]  R1250     2.6052755117416382e-01
    z[3,1,6]  R1251     -1.2949370779097080e-02
    z[3,1,6]  R1252     2.4970626831054688e-01
    z[3,1,6]  R1253     5.9450912475585938e-01
    z[3,1,6]  R1254     -5.0955647230148315e-01
    z[3,1,6]  R1255     -1.8352743983268738e-01
    z[3,1,6]  R1256     -1.1067216284573078e-02
    z[3,1,6]  R1257     -1.8066921830177307e-01
    z[3,1,6]  R1258     -6.7055529356002808e-01
    z[3,1,6]  R1259     3.8996872305870056e-01
    z[3,1,6]  R1260     2.6779506355524063e-02
    z[3,1,6]  R1261     1.9074784219264984e-01
    z[3,1,6]  R1262     1.5408596396446228e-01
    z[3,1,6]  R1263     -4.5079058408737183e-01
    z[3,1,6]  R1264     -6.9441363215446472e-02
    z[3,1,6]  R1265     -4.3850109796039760e-04
    z[3,1,6]  R1266     4.8177537322044373e-01
    z[3,1,6]  R1267     -0.126246377825737
    z[3,1,6]  R1268     1.9304960966110229e-01
    z[3,1,6]  R1269     1.7743013799190521e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1270     -1
    z[1,4,0]  R1271     1
    z[1,4,0]  R1284     -4.5251451432704926e-02
    z[1,4,0]  R1285     -3.5671177506446838e-01
    z[1,4,0]  R1286     -4.2242676019668579e-02
    z[1,4,0]  R1287     -5.9709161520004272e-01
    z[1,4,0]  R1288     -7.8293181955814362e-02
    z[1,4,0]  R1289     -1.2750937603414059e-02
    z[1,4,0]  R1290     -6.8526011705398560e-01
    z[1,4,0]  R1291     -5.3374101407825947e-03
    z[1,4,0]  R1292     -7.7924764156341553e-01
    z[1,4,0]  R1293     -1.6494253277778625e-01
    z[1,4,0]  R1294     1.0237602144479752e-01
    z[1,4,0]  R1295     -9.1826446354389191e-02
    z[1,4,0]  R1296     -1.0050944983959198e-01
    z[1,4,0]  R1297     -6.5777927637100220e-02
    z[1,4,0]  R1298     -2.2169025242328644e-01
    z[1,4,0]  R1299     2.1646836772561073e-02
    z[1,4,0]  R1300     5.4830335080623627e-02
    z[1,4,0]  R1301     6.3755147159099579e-02
    z[1,4,0]  R1302     -3.9741796255111694e-01
    z[1,4,0]  R1303     1.9783353805541992e-01
    z[1,4,0]  R1304     9.0975388884544373e-02
    z[1,4,0]  R1305     7.3167368769645691e-02
    z[1,4,0]  R1306     2.3548530042171478e-01
    z[1,4,0]  R1307     2.6657110452651978e-01
    z[1,4,0]  R1308     1.6141006350517273e-01
    z[1,4,0]  R1309     -5.9019678831100464e-01
    z[1,4,0]  R1310     2.3474588990211487e-01
    z[1,4,0]  R1311     3.3537900447845459e-01
    z[1,4,0]  R1312     2.8809833526611328e-01
    z[1,4,0]  R1313     2.9013855382800102e-02
    z[1,4,0]  R1314     1.7178709805011749e-01
    z[1,4,0]  R1315     0.073527030646801
    z[1,4,0]  R1316     3.7063896656036377e-01
    z[1,4,0]  R1317     3.3976495265960693e-01
    z[1,4,0]  R1318     3.7903591990470886e-01
    z[1,4,0]  R1319     4.6893391013145447e-01
    z[1,4,0]  R1320     2.6620736718177795e-01
    z[1,4,0]  R1321     5.3020846843719482e-01
    z[1,4,0]  R1322     8.5024207830429077e-01
    z[1,4,0]  R1323     7.7913725376129150e-01
    z[1,4,0]  R1324     -4.4537249207496643e-01
    z[1,4,0]  R1325     -5.1074630022048950e-01
    z[1,4,0]  R1326     -5.2198320627212524e-01
    z[1,4,0]  R1327     1.4921683818101883e-02
    z[1,4,0]  R1328     -9.6592712402343750e-01
    z[1,4,0]  R1329     8.0585852265357971e-02
    z[1,4,0]  R1330     -1.7927173525094986e-02
    z[1,4,0]  R1331     3.2609567046165466e-02
    z[1,4,0]  R1332     -2.4398061633110046e-01
    z[1,4,0]  R1333     -1.0867832228541374e-02
    z[1,4,0]  R1334     0.331209659576416
    z[1,4,0]  R1335     3.7573602795600891e-01
    z[1,4,0]  R1336     4.9842461943626404e-01
    z[1,4,0]  R1337     3.3839711546897888e-01
    z[1,4,0]  R1338     3.7496492266654968e-01
    z[1,4,0]  R1339     3.4600558876991272e-01
    z[1,4,0]  R1340     2.5181302428245544e-01
    z[1,4,0]  R1341     1.5387284755706787e-01
    z[1,4,0]  R1342     3.2433813810348511e-01
    z[1,4,0]  R1343     2.0987780392169952e-01
    z[1,4,0]  R1344     2.4177080392837524e-01
    z[1,4,0]  R1345     -1.7149411141872406e-01
    z[1,4,0]  R1346     -1.1276394070591778e-04
    z[1,4,0]  R1347     0.299360454082489
    z[1,4,0]  R1348     1.8625383079051971e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1272     -1
    z[1,4,1]  R1273     1
    z[1,4,1]  R1284     -4.1153582930564880e-01
    z[1,4,1]  R1285     0.573833703994751
    z[1,4,1]  R1286     -0.366733580827713
    z[1,4,1]  R1287     2.7760806679725647e-01
    z[1,4,1]  R1288     -4.9850201606750488e-01
    z[1,4,1]  R1289     -0.262656033039093
    z[1,4,1]  R1290     3.9246013760566711e-01
    z[1,4,1]  R1291     -2.8604340553283691e-01
    z[1,4,1]  R1292     1.2124329805374146e-01
    z[1,4,1]  R1293     5.4653489589691162e-01
    z[1,4,1]  R1294     -7.8913533687591553e-01
    z[1,4,1]  R1295     -7.8548103570938110e-01
    z[1,4,1]  R1296     -7.8021126985549927e-01
    z[1,4,1]  R1297     -7.6294887065887451e-01
    z[1,4,1]  R1298     -7.4078255891799927e-01
    z[1,4,1]  R1299     -7.4767166376113892e-01
    z[1,4,1]  R1300     -6.2841165065765381e-01
    z[1,4,1]  R1301     -7.1363770961761475e-01
    z[1,4,1]  R1302     -6.6738867759704590e-01
    z[1,4,1]  R1303     -5.4265409708023071e-01
    z[1,4,1]  R1304     -8.6383581161499023e-01
    z[1,4,1]  R1305     -4.6129563450813293e-01
    z[1,4,1]  R1306     -5.1387935876846313e-01
    z[1,4,1]  R1307     -4.2744708061218262e-01
    z[1,4,1]  R1308     -0.583754301071167
    z[1,4,1]  R1309     1.9236426055431366e-01
    z[1,4,1]  R1310     -3.0478119850158691e-01
    z[1,4,1]  R1311     -4.9917593598365784e-01
    z[1,4,1]  R1312     -5.3909343481063843e-01
    z[1,4,1]  R1313     5.0474762916564941e-01
    z[1,4,1]  R1314     -5.4632717370986938e-01
    z[1,4,1]  R1315     -5.4762643575668335e-01
    z[1,4,1]  R1316     -1.4396350085735321e-01
    z[1,4,1]  R1317     -2.5115618109703064e-01
    z[1,4,1]  R1318     -4.8610472679138184e-01
    z[1,4,1]  R1319     4.6591964364051819e-01
    z[1,4,1]  R1320     5.2314704656600952e-01
    z[1,4,1]  R1321     4.5538052916526794e-01
    z[1,4,1]  R1322     3.7054851651191711e-01
    z[1,4,1]  R1323     3.2702940702438354e-01
    z[1,4,1]  R1324     0.665277361869812
    z[1,4,1]  R1325     5.7158994674682617e-01
    z[1,4,1]  R1326     4.0337088704109192e-01
    z[1,4,1]  R1327     7.5647455453872681e-01
    z[1,4,1]  R1328     7.8719764947891235e-02
    z[1,4,1]  R1329     -6.6353100538253784e-01
    z[1,4,1]  R1330     -5.6738960742950439e-01
    z[1,4,1]  R1331     -0.539656400680542
    z[1,4,1]  R1332     -7.3659688234329224e-01
    z[1,4,1]  R1333     2.8826889395713806e-01
    z[1,4,1]  R1334     -7.7573865652084351e-01
    z[1,4,1]  R1335     -7.6019245386123657e-01
    z[1,4,1]  R1336     -6.0532516241073608e-01
    z[1,4,1]  R1337     -7.0515912771224976e-01
    z[1,4,1]  R1338     -6.2775951623916626e-01
    z[1,4,1]  R1339     -6.5205973386764526e-01
    z[1,4,1]  R1340     -7.5500094890594482e-01
    z[1,4,1]  R1341     -0.685711681842804
    z[1,4,1]  R1342     -5.7793557643890381e-01
    z[1,4,1]  R1343     -6.6598445177078247e-01
    z[1,4,1]  R1344     -6.6299033164978027e-01
    z[1,4,1]  R1345     2.1881558932363987e-03
    z[1,4,1]  R1346     1.9273987039923668e-02
    z[1,4,1]  R1347     5.7013678550720215e-01
    z[1,4,1]  R1348     6.1896014213562012e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1274     -1
    z[1,4,2]  R1275     1
    z[1,4,2]  R1284     5.0443840026855469e-01
    z[1,4,2]  R1285     -4.9243211746215820e-01
    z[1,4,2]  R1286     1.2689022719860077e-01
    z[1,4,2]  R1287     -0.626781165599823
    z[1,4,2]  R1288     7.9153716564178467e-01
    z[1,4,2]  R1289     7.2913813591003418e-01
    z[1,4,2]  R1290     -4.3528309464454651e-01
    z[1,4,2]  R1291     3.0553472042083740e-01
    z[1,4,2]  R1292     -5.4495644569396973e-01
    z[1,4,2]  R1293     -7.0033740997314453e-01
    z[1,4,2]  R1294     -3.6397790908813477e-01
    z[1,4,2]  R1295     -2.8767114877700806e-01
    z[1,4,2]  R1296     -3.3676931262016296e-01
    z[1,4,2]  R1297     -3.1985855102539062e-01
    z[1,4,2]  R1298     -2.3950286209583282e-01
    z[1,4,2]  R1299     -1.2533517181873322e-01
    z[1,4,2]  R1300     1.7164391279220581e-01
    z[1,4,2]  R1301     -2.3216864466667175e-01
    z[1,4,2]  R1302     1.0192343033850193e-03
    z[1,4,2]  R1303     9.2219136655330658e-02
    z[1,4,2]  R1304     1.1176556348800659e-01
    z[1,4,2]  R1305     3.0754688382148743e-01
    z[1,4,2]  R1306     0.3104248046875
    z[1,4,2]  R1307     4.3009561300277710e-01
    z[1,4,2]  R1308     -1.9003529846668243e-01
    z[1,4,2]  R1309     -3.1999304890632629e-01
    z[1,4,2]  R1310     5.9365980327129364e-02
    z[1,4,2]  R1311     5.3292375802993774e-01
    z[1,4,2]  R1312     1.1547703295946121e-01
    z[1,4,2]  R1313     3.5850954055786133e-01
    z[1,4,2]  R1314     1.8182796239852905e-01
    z[1,4,2]  R1315     5.6437408924102783e-01
    z[1,4,2]  R1316     7.5032621622085571e-01
    z[1,4,2]  R1317     1.2528024613857269e-01
    z[1,4,2]  R1318     2.2773987054824829e-01
    z[1,4,2]  R1319     2.6856359094381332e-02
    z[1,4,2]  R1320     1.8239600956439972e-01
    z[1,4,2]  R1321     2.3532277345657349e-01
    z[1,4,2]  R1322     1.6897714138031006e-01
    z[1,4,2]  R1323     6.8543985486030579e-02
    z[1,4,2]  R1324     -3.3246603608131409e-01
    z[1,4,2]  R1325     -3.3024686574935913e-01
    z[1,4,2]  R1326     -3.8213226199150085e-01
    z[1,4,2]  R1327     -5.9999954700469971e-01
    z[1,4,2]  R1328     -1.8448592722415924e-01
    z[1,4,2]  R1329     4.5519477128982544e-01
    z[1,4,2]  R1330     -1.3045579195022583e-01
    z[1,4,2]  R1331     -2.9634529352188110e-01
    z[1,4,2]  R1332     4.5163431763648987e-01
    z[1,4,2]  R1333     0.0443992018699646
    z[1,4,2]  R1334     4.3069524690508842e-03
    z[1,4,2]  R1335     -2.0378093421459198e-01
    z[1,4,2]  R1336     -2.0583665370941162e-01
    z[1,4,2]  R1337     -0.601309597492218
    z[1,4,2]  R1338     7.6408926397562027e-03
    z[1,4,2]  R1339     -2.1865795552730560e-01
    z[1,4,2]  R1340     -5.1944029331207275e-01
    z[1,4,2]  R1341     2.9603847861289978e-01
    z[1,4,2]  R1342     -1.8319685757160187e-01
    z[1,4,2]  R1343     5.0144165754318237e-01
    z[1,4,2]  R1344     3.1911796331405640e-01
    z[1,4,2]  R1345     -5.3569239377975464e-01
    z[1,4,2]  R1346     -5.2974373102188110e-01
    z[1,4,2]  R1347     3.3966198563575745e-01
    z[1,4,2]  R1348     6.2364935874938965e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1276     -1
    z[1,4,3]  R1277     1
    z[1,4,3]  R1284     5.3050768375396729e-01
    z[1,4,3]  R1285     2.4304993450641632e-01
    z[1,4,3]  R1286     0.799430251121521
    z[1,4,3]  R1287     1.0718559473752975e-01
    z[1,4,3]  R1288     1.0570231825113297e-01
    z[1,4,3]  R1289     5.6906795501708984e-01
    z[1,4,3]  R1290     1.5660229325294495e-01
    z[1,4,3]  R1291     6.4447224140167236e-01
    z[1,4,3]  R1292     2.4263779819011688e-01
    z[1,4,3]  R1293     1.3728702068328857e-01
    z[1,4,3]  R1294     0.174093097448349
    z[1,4,3]  R1295     -2.9917600750923157e-01
    z[1,4,3]  R1296     -3.9608660340309143e-01
    z[1,4,3]  R1297     -4.9124431610107422e-01
    z[1,4,3]  R1298     -4.4795447587966919e-01
    z[1,4,3]  R1299     -4.1094160079956055e-01
    z[1,4,3]  R1300     -4.0366217494010925e-01
    z[1,4,3]  R1301     -4.2908832430839539e-01
    z[1,4,3]  R1302     -1.9940476119518280e-01
    z[1,4,3]  R1303     -5.6705063581466675e-01
    z[1,4,3]  R1304     1.2812471017241478e-02
    z[1,4,3]  R1305     3.9192914962768555e-01
    z[1,4,3]  R1306     -1.0241139680147171e-01
    z[1,4,3]  R1307     -2.2310981154441833e-01
    z[1,4,3]  R1308     -5.0097241997718811e-02
    z[1,4,3]  R1309     5.2560776472091675e-02
    z[1,4,3]  R1310     2.0923748612403870e-01
    z[1,4,3]  R1311     1.9200769066810608e-01
    z[1,4,3]  R1312     8.4713473916053772e-02
    z[1,4,3]  R1313     6.5258580446243286e-01
    z[1,4,3]  R1314     7.9723989963531494e-01
    z[1,4,3]  R1315     5.0779759883880615e-01
    z[1,4,3]  R1316     1.6282172501087189e-01
    z[1,4,3]  R1317     4.7349786758422852e-01
    z[1,4,3]  R1318     8.6323969066143036e-02
    z[1,4,3]  R1319     3.1835392117500305e-01
    z[1,4,3]  R1320     -2.1111611276865005e-02
    z[1,4,3]  R1321     6.1433070898056030e-01
    z[1,4,3]  R1322     -1.2037465721368790e-01
    z[1,4,3]  R1323     -4.6486461162567139e-01
    z[1,4,3]  R1324     6.1623834073543549e-02
    z[1,4,3]  R1325     1.2031611055135727e-01
    z[1,4,3]  R1326     -1.0835071653127670e-01
    z[1,4,3]  R1327     1.6698566079139709e-01
    z[1,4,3]  R1328     -8.0087609589099884e-02
    z[1,4,3]  R1329     5.4327648133039474e-02
    z[1,4,3]  R1330     -5.7724362611770630e-01
    z[1,4,3]  R1331     1.4700695872306824e-01
    z[1,4,3]  R1332     1.0272392630577087e-01
    z[1,4,3]  R1333     8.5961920022964478e-01
    z[1,4,3]  R1334     -2.4001386761665344e-01
    z[1,4,3]  R1335     1.8896806240081787e-01
    z[1,4,3]  R1336     -0.388874351978302
    z[1,4,3]  R1337     1.1385331302881241e-01
    z[1,4,3]  R1338     3.0618848279118538e-02
    z[1,4,3]  R1339     5.8276718854904175e-01
    z[1,4,3]  R1340     -4.3951552361249924e-02
    z[1,4,3]  R1341     3.5840559005737305e-01
    z[1,4,3]  R1342     1.5175801515579224e-01
    z[1,4,3]  R1343     1.3548615574836731e-01
    z[1,4,3]  R1344     -7.3759861290454865e-02
    z[1,4,3]  R1345     -6.4899915456771851e-01
    z[1,4,3]  R1346     -3.1279709935188293e-01
    z[1,4,3]  R1347     -6.1535632610321045e-01
    z[1,4,3]  R1348     -2.5307220220565796e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1278     -1
    z[1,4,4]  R1279     1
    z[1,4,4]  R1284     2.6285862922668457e-01
    z[1,4,4]  R1285     2.0473259687423706e-01
    z[1,4,4]  R1286     2.8543433547019958e-01
    z[1,4,4]  R1287     1.7861008644104004e-01
    z[1,4,4]  R1288     3.9897285401821136e-02
    z[1,4,4]  R1289     -1.0376599431037903e-01
    z[1,4,4]  R1290     2.9115831851959229e-01
    z[1,4,4]  R1291     5.5429106950759888e-01
    z[1,4,4]  R1292     -1.4271882176399231e-01
    z[1,4,4]  R1293     -1.6991877555847168e-01
    z[1,4,4]  R1294     -3.5168644785881042e-01
    z[1,4,4]  R1295     -2.1051105856895447e-01
    z[1,4,4]  R1296     1.6175056993961334e-01
    z[1,4,4]  R1297     1.5208730101585388e-01
    z[1,4,4]  R1298     -1.2244738638401031e-01
    z[1,4,4]  R1299     2.9136139154434204e-01
    z[1,4,4]  R1300     8.3066321909427643e-02
    z[1,4,4]  R1301     2.1944449841976166e-01
    z[1,4,4]  R1302     2.4374271929264069e-01
    z[1,4,4]  R1303     2.9229193925857544e-01
    z[1,4,4]  R1304     3.7499007582664490e-01
    z[1,4,4]  R1305     -5.2446460723876953e-01
    z[1,4,4]  R1306     1.5510775148868561e-01
    z[1,4,4]  R1307     -3.1334522366523743e-01
    z[1,4,4]  R1308     0.34656822681427
    z[1,4,4]  R1309     -2.3756182193756104e-01
    z[1,4,4]  R1310     3.7706881761550903e-01
    z[1,4,4]  R1311     -5.1656424999237061e-01
    z[1,4,4]  R1312     -3.3346924185752869e-01
    z[1,4,4]  R1313     2.6950253173708916e-02
    z[1,4,4]  R1314     0.00511670857667923
    z[1,4,4]  R1315     1.8650548160076141e-01
    z[1,4,4]  R1316     4.6590843796730042e-01
    z[1,4,4]  R1317     1.1250261217355728e-01
    z[1,4,4]  R1318     -5.7950061559677124e-01
    z[1,4,4]  R1319     -5.7460999488830566e-01
    z[1,4,4]  R1320     -3.1709730625152588e-01
    z[1,4,4]  R1321     -1.8819181621074677e-01
    z[1,4,4]  R1322     2.0447519421577454e-01
    z[1,4,4]  R1323     1.5613253414630890e-01
    z[1,4,4]  R1324     9.6880055963993073e-02
    z[1,4,4]  R1325     2.8017762303352356e-01
    z[1,4,4]  R1326     -2.7349710464477539e-01
    z[1,4,4]  R1327     1.7739698290824890e-01
    z[1,4,4]  R1328     -2.9830446466803551e-02
    z[1,4,4]  R1329     5.0163465738296509e-01
    z[1,4,4]  R1330     -2.0905299112200737e-02
    z[1,4,4]  R1331     9.0793631970882416e-02
    z[1,4,4]  R1332     -4.2723834514617920e-01
    z[1,4,4]  R1333     -3.7313145399093628e-01
    z[1,4,4]  R1334     -2.1621921658515930e-01
    z[1,4,4]  R1335     -9.6813194453716278e-02
    z[1,4,4]  R1336     3.7031877040863037e-01
    z[1,4,4]  R1337     6.5757364034652710e-02
    z[1,4,4]  R1338     -2.7775904163718224e-02
    z[1,4,4]  R1339     -1.0947525501251221e-01
    z[1,4,4]  R1340     -1.0854104906320572e-01
    z[1,4,4]  R1341     -2.5228586792945862e-01
    z[1,4,4]  R1342     -6.6569441556930542e-01
    z[1,4,4]  R1343     -1.9893574714660645e-01
    z[1,4,4]  R1344     1.3082090020179749e-01
    z[1,4,4]  R1345     3.8038212805986404e-02
    z[1,4,4]  R1346     -6.0758739709854126e-01
    z[1,4,4]  R1347     -1.3361072167754173e-02
    z[1,4,4]  R1348     8.8092230260372162e-02
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1280     -1
    z[1,4,5]  R1281     1
    z[1,4,5]  R1284     -6.3787393271923065e-02
    z[1,4,5]  R1285     -4.0692013502120972e-01
    z[1,4,5]  R1286     1.3815888762474060e-01
    z[1,4,5]  R1287     -2.3018175363540649e-01
    z[1,4,5]  R1288     -3.1856033205986023e-01
    z[1,4,5]  R1289     -1.9800245761871338e-01
    z[1,4,5]  R1290     -1.3131687045097351e-01
    z[1,4,5]  R1291     2.0805935561656952e-01
    z[1,4,5]  R1292     -2.8782995417714119e-02
    z[1,4,5]  R1293     1.7422935366630554e-01
    z[1,4,5]  R1294     -1.3307310640811920e-01
    z[1,4,5]  R1295     3.2203185558319092e-01
    z[1,4,5]  R1296     6.9552063941955566e-02
    z[1,4,5]  R1297     1.4325352013111115e-01
    z[1,4,5]  R1298     2.9530632495880127e-01
    z[1,4,5]  R1299     4.1212841868400574e-01
    z[1,4,5]  R1300     5.8570575714111328e-01
    z[1,4,5]  R1301     -4.3115538358688354e-01
    z[1,4,5]  R1302     4.2247429490089417e-01
    z[1,4,5]  R1303     -1.7058970034122467e-01
    z[1,4,5]  R1304     -1.5608721971511841e-01
    z[1,4,5]  R1305     -5.0835871696472168e-01
    z[1,4,5]  R1306     6.9800531864166260e-01
    z[1,4,5]  R1307     2.4462699890136719e-01
    z[1,4,5]  R1308     4.6346226334571838e-01
    z[1,4,5]  R1309     -6.4760148525238037e-01
    z[1,4,5]  R1310     -8.1387633085250854e-01
    z[1,4,5]  R1311     1.3412535190582275e-01
    z[1,4,5]  R1312     2.1217954158782959e-01
    z[1,4,5]  R1313     -1.9284363090991974e-01
    z[1,4,5]  R1314     -5.1182083785533905e-02
    z[1,4,5]  R1315     2.1714878082275391e-01
    z[1,4,5]  R1316     -1.0764618217945099e-01
    z[1,4,5]  R1317     6.0474467277526855e-01
    z[1,4,5]  R1318     0.469120055437088
    z[1,4,5]  R1319     -0.361625075340271
    z[1,4,5]  R1320     -5.3766030073165894e-01
    z[1,4,5]  R1321     -1.6545116901397705e-01
    z[1,4,5]  R1322     1.3289323449134827e-01
    z[1,4,5]  R1323     -9.6647344529628754e-02
    z[1,4,5]  R1324     -3.8344261050224304e-01
    z[1,4,5]  R1325     -2.4632996320724487e-01
    z[1,4,5]  R1326     -4.6027606725692749e-01
    z[1,4,5]  R1327     7.6073859818279743e-03
    z[1,4,5]  R1328     -1.3433896005153656e-01
    z[1,4,5]  R1329     1.5455786883831024e-01
    z[1,4,5]  R1330     -2.7092182636260986e-01
    z[1,4,5]  R1331     7.6671266555786133e-01
    z[1,4,5]  R1332     2.8965758159756660e-02
    z[1,4,5]  R1333     -1.5829353034496307e-01
    z[1,4,5]  R1334     -4.2344415187835693e-01
    z[1,4,5]  R1335     -3.0616271495819092e-01
    z[1,4,5]  R1336     -5.2750091999769211e-02
    z[1,4,5]  R1337     -8.3749219775199890e-02
    z[1,4,5]  R1338     3.5495933890342712e-01
    z[1,4,5]  R1339     2.2453854978084564e-01
    z[1,4,5]  R1340     1.8640884757041931e-01
    z[1,4,5]  R1341     -7.0749111473560333e-02
    z[1,4,5]  R1342     2.3678185045719147e-01
    z[1,4,5]  R1343     3.0017700791358948e-01
    z[1,4,5]  R1344     4.8381257057189941e-01
    z[1,4,5]  R1345     3.3239677548408508e-01
    z[1,4,5]  R1346     1.4385271072387695e-01
    z[1,4,5]  R1347     2.0954367518424988e-01
    z[1,4,5]  R1348     2.6355904340744019e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1282     -1
    z[1,4,6]  R1283     1
    z[1,4,6]  R1284     -4.6854072809219360e-01
    z[1,4,6]  R1285     -1.8549780547618866e-01
    z[1,4,6]  R1286     -3.2859003543853760e-01
    z[1,4,6]  R1287     -2.7782490849494934e-01
    z[1,4,6]  R1288     -0.0677451640367508
    z[1,4,6]  R1289     1.5936177968978882e-01
    z[1,4,6]  R1290     2.4572479724884033e-01
    z[1,4,6]  R1291     2.4274982511997223e-01
    z[1,4,6]  R1292     3.2023850828409195e-02
    z[1,4,6]  R1293     3.2487708330154419e-01
    z[1,4,6]  R1294     2.5020885467529297e-01
    z[1,4,6]  R1295     -2.3303854465484619e-01
    z[1,4,6]  R1296     2.8261154890060425e-01
    z[1,4,6]  R1297     -1.6217219829559326e-01
    z[1,4,6]  R1298     2.0462350547313690e-01
    z[1,4,6]  R1299     -3.4572128206491470e-02
    z[1,4,6]  R1300     2.4441033601760864e-01
    z[1,4,6]  R1301     1.2077458202838898e-01
    z[1,4,6]  R1302     3.4495350718498230e-01
    z[1,4,6]  R1303     0.470958948135376
    z[1,4,6]  R1304     2.6052755117416382e-01
    z[1,4,6]  R1305     -1.2949370779097080e-02
    z[1,4,6]  R1306     2.4970626831054688e-01
    z[1,4,6]  R1307     5.9450912475585938e-01
    z[1,4,6]  R1308     -5.0955647230148315e-01
    z[1,4,6]  R1309     -1.8352743983268738e-01
    z[1,4,6]  R1310     -1.1067216284573078e-02
    z[1,4,6]  R1311     -1.8066921830177307e-01
    z[1,4,6]  R1312     -6.7055529356002808e-01
    z[1,4,6]  R1313     3.8996872305870056e-01
    z[1,4,6]  R1314     2.6779506355524063e-02
    z[1,4,6]  R1315     1.9074784219264984e-01
    z[1,4,6]  R1316     1.5408596396446228e-01
    z[1,4,6]  R1317     -4.5079058408737183e-01
    z[1,4,6]  R1318     -6.9441363215446472e-02
    z[1,4,6]  R1319     -4.3850109796039760e-04
    z[1,4,6]  R1320     4.8177537322044373e-01
    z[1,4,6]  R1321     -0.126246377825737
    z[1,4,6]  R1322     1.9304960966110229e-01
    z[1,4,6]  R1323     1.7743013799190521e-01
    z[1,4,6]  R1324     2.9716029763221741e-01
    z[1,4,6]  R1325     -3.8691893219947815e-01
    z[1,4,6]  R1326     -3.4699544310569763e-01
    z[1,4,6]  R1327     9.0068168938159943e-02
    z[1,4,6]  R1328     -3.7443239241838455e-02
    z[1,4,6]  R1329     -0.259909987449646
    z[1,4,6]  R1330     -5.0366961956024170e-01
    z[1,4,6]  R1331     4.6736735850572586e-02
    z[1,4,6]  R1332     -1.0265648597851396e-03
    z[1,4,6]  R1333     -1.0762225091457367e-01
    z[1,4,6]  R1334     0.0696331113576889
    z[1,4,6]  R1335     3.1715276837348938e-01
    z[1,4,6]  R1336     2.2725264728069305e-01
    z[1,4,6]  R1337     -4.8621557652950287e-02
    z[1,4,6]  R1338     5.8099544048309326e-01
    z[1,4,6]  R1339     7.2574146091938019e-02
    z[1,4,6]  R1340     -2.1973720192909241e-01
    z[1,4,6]  R1341     -4.7050568461418152e-01
    z[1,4,6]  R1342     -7.0633783936500549e-02
    z[1,4,6]  R1343     0.336056649684906
    z[1,4,6]  R1344     -3.7884730100631714e-01
    z[1,4,6]  R1345     3.8792282342910767e-01
    z[1,4,6]  R1346     4.8093879222869873e-01
    z[1,4,6]  R1347     -2.1727073192596436e-01
    z[1,4,6]  R1348     2.2801366448402405e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1349     -1
    z[4,1,0]  R1350     1
    z[4,1,0]  R1363     -4.4537249207496643e-01
    z[4,1,0]  R1364     -5.1074630022048950e-01
    z[4,1,0]  R1365     -5.2198320627212524e-01
    z[4,1,0]  R1366     1.4921683818101883e-02
    z[4,1,0]  R1367     -9.6592712402343750e-01
    z[4,1,0]  R1368     8.0585852265357971e-02
    z[4,1,0]  R1369     -1.7927173525094986e-02
    z[4,1,0]  R1370     3.2609567046165466e-02
    z[4,1,0]  R1371     -2.4398061633110046e-01
    z[4,1,0]  R1372     -1.0867832228541374e-02
    z[4,1,0]  R1373     0.331209659576416
    z[4,1,0]  R1374     3.7573602795600891e-01
    z[4,1,0]  R1375     4.9842461943626404e-01
    z[4,1,0]  R1376     3.3839711546897888e-01
    z[4,1,0]  R1377     3.7496492266654968e-01
    z[4,1,0]  R1378     3.4600558876991272e-01
    z[4,1,0]  R1379     2.5181302428245544e-01
    z[4,1,0]  R1380     1.5387284755706787e-01
    z[4,1,0]  R1381     3.2433813810348511e-01
    z[4,1,0]  R1382     2.0987780392169952e-01
    z[4,1,0]  R1383     2.4177080392837524e-01
    z[4,1,0]  R1384     -1.7149411141872406e-01
    z[4,1,0]  R1385     -1.1276394070591778e-04
    z[4,1,0]  R1386     0.299360454082489
    z[4,1,0]  R1387     1.8625383079051971e-01
    z[4,1,0]  R1388     -4.5251451432704926e-02
    z[4,1,0]  R1389     -3.5671177506446838e-01
    z[4,1,0]  R1390     -4.2242676019668579e-02
    z[4,1,0]  R1391     -5.9709161520004272e-01
    z[4,1,0]  R1392     -7.8293181955814362e-02
    z[4,1,0]  R1393     -1.2750937603414059e-02
    z[4,1,0]  R1394     -6.8526011705398560e-01
    z[4,1,0]  R1395     -5.3374101407825947e-03
    z[4,1,0]  R1396     -7.7924764156341553e-01
    z[4,1,0]  R1397     -1.6494253277778625e-01
    z[4,1,0]  R1398     1.0237602144479752e-01
    z[4,1,0]  R1399     -9.1826446354389191e-02
    z[4,1,0]  R1400     -1.0050944983959198e-01
    z[4,1,0]  R1401     -6.5777927637100220e-02
    z[4,1,0]  R1402     -2.2169025242328644e-01
    z[4,1,0]  R1403     2.1646836772561073e-02
    z[4,1,0]  R1404     5.4830335080623627e-02
    z[4,1,0]  R1405     6.3755147159099579e-02
    z[4,1,0]  R1406     -3.9741796255111694e-01
    z[4,1,0]  R1407     1.9783353805541992e-01
    z[4,1,0]  R1408     9.0975388884544373e-02
    z[4,1,0]  R1409     7.3167368769645691e-02
    z[4,1,0]  R1410     2.3548530042171478e-01
    z[4,1,0]  R1411     2.6657110452651978e-01
    z[4,1,0]  R1412     1.6141006350517273e-01
    z[4,1,0]  R1413     -5.9019678831100464e-01
    z[4,1,0]  R1414     2.3474588990211487e-01
    z[4,1,0]  R1415     3.3537900447845459e-01
    z[4,1,0]  R1416     2.8809833526611328e-01
    z[4,1,0]  R1417     2.9013855382800102e-02
    z[4,1,0]  R1418     1.7178709805011749e-01
    z[4,1,0]  R1419     0.073527030646801
    z[4,1,0]  R1420     3.7063896656036377e-01
    z[4,1,0]  R1421     3.3976495265960693e-01
    z[4,1,0]  R1422     3.7903591990470886e-01
    z[4,1,0]  R1423     4.6893391013145447e-01
    z[4,1,0]  R1424     2.6620736718177795e-01
    z[4,1,0]  R1425     5.3020846843719482e-01
    z[4,1,0]  R1426     8.5024207830429077e-01
    z[4,1,0]  R1427     7.7913725376129150e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1351     -1
    z[4,1,1]  R1352     1
    z[4,1,1]  R1363     0.665277361869812
    z[4,1,1]  R1364     5.7158994674682617e-01
    z[4,1,1]  R1365     4.0337088704109192e-01
    z[4,1,1]  R1366     7.5647455453872681e-01
    z[4,1,1]  R1367     7.8719764947891235e-02
    z[4,1,1]  R1368     -6.6353100538253784e-01
    z[4,1,1]  R1369     -5.6738960742950439e-01
    z[4,1,1]  R1370     -0.539656400680542
    z[4,1,1]  R1371     -7.3659688234329224e-01
    z[4,1,1]  R1372     2.8826889395713806e-01
    z[4,1,1]  R1373     -7.7573865652084351e-01
    z[4,1,1]  R1374     -7.6019245386123657e-01
    z[4,1,1]  R1375     -6.0532516241073608e-01
    z[4,1,1]  R1376     -7.0515912771224976e-01
    z[4,1,1]  R1377     -6.2775951623916626e-01
    z[4,1,1]  R1378     -6.5205973386764526e-01
    z[4,1,1]  R1379     -7.5500094890594482e-01
    z[4,1,1]  R1380     -0.685711681842804
    z[4,1,1]  R1381     -5.7793557643890381e-01
    z[4,1,1]  R1382     -6.6598445177078247e-01
    z[4,1,1]  R1383     -6.6299033164978027e-01
    z[4,1,1]  R1384     2.1881558932363987e-03
    z[4,1,1]  R1385     1.9273987039923668e-02
    z[4,1,1]  R1386     5.7013678550720215e-01
    z[4,1,1]  R1387     6.1896014213562012e-01
    z[4,1,1]  R1388     -4.1153582930564880e-01
    z[4,1,1]  R1389     0.573833703994751
    z[4,1,1]  R1390     -0.366733580827713
    z[4,1,1]  R1391     2.7760806679725647e-01
    z[4,1,1]  R1392     -4.9850201606750488e-01
    z[4,1,1]  R1393     -0.262656033039093
    z[4,1,1]  R1394     3.9246013760566711e-01
    z[4,1,1]  R1395     -2.8604340553283691e-01
    z[4,1,1]  R1396     1.2124329805374146e-01
    z[4,1,1]  R1397     5.4653489589691162e-01
    z[4,1,1]  R1398     -7.8913533687591553e-01
    z[4,1,1]  R1399     -7.8548103570938110e-01
    z[4,1,1]  R1400     -7.8021126985549927e-01
    z[4,1,1]  R1401     -7.6294887065887451e-01
    z[4,1,1]  R1402     -7.4078255891799927e-01
    z[4,1,1]  R1403     -7.4767166376113892e-01
    z[4,1,1]  R1404     -6.2841165065765381e-01
    z[4,1,1]  R1405     -7.1363770961761475e-01
    z[4,1,1]  R1406     -6.6738867759704590e-01
    z[4,1,1]  R1407     -5.4265409708023071e-01
    z[4,1,1]  R1408     -8.6383581161499023e-01
    z[4,1,1]  R1409     -4.6129563450813293e-01
    z[4,1,1]  R1410     -5.1387935876846313e-01
    z[4,1,1]  R1411     -4.2744708061218262e-01
    z[4,1,1]  R1412     -0.583754301071167
    z[4,1,1]  R1413     1.9236426055431366e-01
    z[4,1,1]  R1414     -3.0478119850158691e-01
    z[4,1,1]  R1415     -4.9917593598365784e-01
    z[4,1,1]  R1416     -5.3909343481063843e-01
    z[4,1,1]  R1417     5.0474762916564941e-01
    z[4,1,1]  R1418     -5.4632717370986938e-01
    z[4,1,1]  R1419     -5.4762643575668335e-01
    z[4,1,1]  R1420     -1.4396350085735321e-01
    z[4,1,1]  R1421     -2.5115618109703064e-01
    z[4,1,1]  R1422     -4.8610472679138184e-01
    z[4,1,1]  R1423     4.6591964364051819e-01
    z[4,1,1]  R1424     5.2314704656600952e-01
    z[4,1,1]  R1425     4.5538052916526794e-01
    z[4,1,1]  R1426     3.7054851651191711e-01
    z[4,1,1]  R1427     3.2702940702438354e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1353     -1
    z[4,1,2]  R1354     1
    z[4,1,2]  R1363     -3.3246603608131409e-01
    z[4,1,2]  R1364     -3.3024686574935913e-01
    z[4,1,2]  R1365     -3.8213226199150085e-01
    z[4,1,2]  R1366     -5.9999954700469971e-01
    z[4,1,2]  R1367     -1.8448592722415924e-01
    z[4,1,2]  R1368     4.5519477128982544e-01
    z[4,1,2]  R1369     -1.3045579195022583e-01
    z[4,1,2]  R1370     -2.9634529352188110e-01
    z[4,1,2]  R1371     4.5163431763648987e-01
    z[4,1,2]  R1372     0.0443992018699646
    z[4,1,2]  R1373     4.3069524690508842e-03
    z[4,1,2]  R1374     -2.0378093421459198e-01
    z[4,1,2]  R1375     -2.0583665370941162e-01
    z[4,1,2]  R1376     -0.601309597492218
    z[4,1,2]  R1377     7.6408926397562027e-03
    z[4,1,2]  R1378     -2.1865795552730560e-01
    z[4,1,2]  R1379     -5.1944029331207275e-01
    z[4,1,2]  R1380     2.9603847861289978e-01
    z[4,1,2]  R1381     -1.8319685757160187e-01
    z[4,1,2]  R1382     5.0144165754318237e-01
    z[4,1,2]  R1383     3.1911796331405640e-01
    z[4,1,2]  R1384     -5.3569239377975464e-01
    z[4,1,2]  R1385     -5.2974373102188110e-01
    z[4,1,2]  R1386     3.3966198563575745e-01
    z[4,1,2]  R1387     6.2364935874938965e-01
    z[4,1,2]  R1388     5.0443840026855469e-01
    z[4,1,2]  R1389     -4.9243211746215820e-01
    z[4,1,2]  R1390     1.2689022719860077e-01
    z[4,1,2]  R1391     -0.626781165599823
    z[4,1,2]  R1392     7.9153716564178467e-01
    z[4,1,2]  R1393     7.2913813591003418e-01
    z[4,1,2]  R1394     -4.3528309464454651e-01
    z[4,1,2]  R1395     3.0553472042083740e-01
    z[4,1,2]  R1396     -5.4495644569396973e-01
    z[4,1,2]  R1397     -7.0033740997314453e-01
    z[4,1,2]  R1398     -3.6397790908813477e-01
    z[4,1,2]  R1399     -2.8767114877700806e-01
    z[4,1,2]  R1400     -3.3676931262016296e-01
    z[4,1,2]  R1401     -3.1985855102539062e-01
    z[4,1,2]  R1402     -2.3950286209583282e-01
    z[4,1,2]  R1403     -1.2533517181873322e-01
    z[4,1,2]  R1404     1.7164391279220581e-01
    z[4,1,2]  R1405     -2.3216864466667175e-01
    z[4,1,2]  R1406     1.0192343033850193e-03
    z[4,1,2]  R1407     9.2219136655330658e-02
    z[4,1,2]  R1408     1.1176556348800659e-01
    z[4,1,2]  R1409     3.0754688382148743e-01
    z[4,1,2]  R1410     0.3104248046875
    z[4,1,2]  R1411     4.3009561300277710e-01
    z[4,1,2]  R1412     -1.9003529846668243e-01
    z[4,1,2]  R1413     -3.1999304890632629e-01
    z[4,1,2]  R1414     5.9365980327129364e-02
    z[4,1,2]  R1415     5.3292375802993774e-01
    z[4,1,2]  R1416     1.1547703295946121e-01
    z[4,1,2]  R1417     3.5850954055786133e-01
    z[4,1,2]  R1418     1.8182796239852905e-01
    z[4,1,2]  R1419     5.6437408924102783e-01
    z[4,1,2]  R1420     7.5032621622085571e-01
    z[4,1,2]  R1421     1.2528024613857269e-01
    z[4,1,2]  R1422     2.2773987054824829e-01
    z[4,1,2]  R1423     2.6856359094381332e-02
    z[4,1,2]  R1424     1.8239600956439972e-01
    z[4,1,2]  R1425     2.3532277345657349e-01
    z[4,1,2]  R1426     1.6897714138031006e-01
    z[4,1,2]  R1427     6.8543985486030579e-02
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1355     -1
    z[4,1,3]  R1356     1
    z[4,1,3]  R1363     6.1623834073543549e-02
    z[4,1,3]  R1364     1.2031611055135727e-01
    z[4,1,3]  R1365     -1.0835071653127670e-01
    z[4,1,3]  R1366     1.6698566079139709e-01
    z[4,1,3]  R1367     -8.0087609589099884e-02
    z[4,1,3]  R1368     5.4327648133039474e-02
    z[4,1,3]  R1369     -5.7724362611770630e-01
    z[4,1,3]  R1370     1.4700695872306824e-01
    z[4,1,3]  R1371     1.0272392630577087e-01
    z[4,1,3]  R1372     8.5961920022964478e-01
    z[4,1,3]  R1373     -2.4001386761665344e-01
    z[4,1,3]  R1374     1.8896806240081787e-01
    z[4,1,3]  R1375     -0.388874351978302
    z[4,1,3]  R1376     1.1385331302881241e-01
    z[4,1,3]  R1377     3.0618848279118538e-02
    z[4,1,3]  R1378     5.8276718854904175e-01
    z[4,1,3]  R1379     -4.3951552361249924e-02
    z[4,1,3]  R1380     3.5840559005737305e-01
    z[4,1,3]  R1381     1.5175801515579224e-01
    z[4,1,3]  R1382     1.3548615574836731e-01
    z[4,1,3]  R1383     -7.3759861290454865e-02
    z[4,1,3]  R1384     -6.4899915456771851e-01
    z[4,1,3]  R1385     -3.1279709935188293e-01
    z[4,1,3]  R1386     -6.1535632610321045e-01
    z[4,1,3]  R1387     -2.5307220220565796e-01
    z[4,1,3]  R1388     5.3050768375396729e-01
    z[4,1,3]  R1389     2.4304993450641632e-01
    z[4,1,3]  R1390     0.799430251121521
    z[4,1,3]  R1391     1.0718559473752975e-01
    z[4,1,3]  R1392     1.0570231825113297e-01
    z[4,1,3]  R1393     5.6906795501708984e-01
    z[4,1,3]  R1394     1.5660229325294495e-01
    z[4,1,3]  R1395     6.4447224140167236e-01
    z[4,1,3]  R1396     2.4263779819011688e-01
    z[4,1,3]  R1397     1.3728702068328857e-01
    z[4,1,3]  R1398     0.174093097448349
    z[4,1,3]  R1399     -2.9917600750923157e-01
    z[4,1,3]  R1400     -3.9608660340309143e-01
    z[4,1,3]  R1401     -4.9124431610107422e-01
    z[4,1,3]  R1402     -4.4795447587966919e-01
    z[4,1,3]  R1403     -4.1094160079956055e-01
    z[4,1,3]  R1404     -4.0366217494010925e-01
    z[4,1,3]  R1405     -4.2908832430839539e-01
    z[4,1,3]  R1406     -1.9940476119518280e-01
    z[4,1,3]  R1407     -5.6705063581466675e-01
    z[4,1,3]  R1408     1.2812471017241478e-02
    z[4,1,3]  R1409     3.9192914962768555e-01
    z[4,1,3]  R1410     -1.0241139680147171e-01
    z[4,1,3]  R1411     -2.2310981154441833e-01
    z[4,1,3]  R1412     -5.0097241997718811e-02
    z[4,1,3]  R1413     5.2560776472091675e-02
    z[4,1,3]  R1414     2.0923748612403870e-01
    z[4,1,3]  R1415     1.9200769066810608e-01
    z[4,1,3]  R1416     8.4713473916053772e-02
    z[4,1,3]  R1417     6.5258580446243286e-01
    z[4,1,3]  R1418     7.9723989963531494e-01
    z[4,1,3]  R1419     5.0779759883880615e-01
    z[4,1,3]  R1420     1.6282172501087189e-01
    z[4,1,3]  R1421     4.7349786758422852e-01
    z[4,1,3]  R1422     8.6323969066143036e-02
    z[4,1,3]  R1423     3.1835392117500305e-01
    z[4,1,3]  R1424     -2.1111611276865005e-02
    z[4,1,3]  R1425     6.1433070898056030e-01
    z[4,1,3]  R1426     -1.2037465721368790e-01
    z[4,1,3]  R1427     -4.6486461162567139e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1357     -1
    z[4,1,4]  R1358     1
    z[4,1,4]  R1363     9.6880055963993073e-02
    z[4,1,4]  R1364     2.8017762303352356e-01
    z[4,1,4]  R1365     -2.7349710464477539e-01
    z[4,1,4]  R1366     1.7739698290824890e-01
    z[4,1,4]  R1367     -2.9830446466803551e-02
    z[4,1,4]  R1368     5.0163465738296509e-01
    z[4,1,4]  R1369     -2.0905299112200737e-02
    z[4,1,4]  R1370     9.0793631970882416e-02
    z[4,1,4]  R1371     -4.2723834514617920e-01
    z[4,1,4]  R1372     -3.7313145399093628e-01
    z[4,1,4]  R1373     -2.1621921658515930e-01
    z[4,1,4]  R1374     -9.6813194453716278e-02
    z[4,1,4]  R1375     3.7031877040863037e-01
    z[4,1,4]  R1376     6.5757364034652710e-02
    z[4,1,4]  R1377     -2.7775904163718224e-02
    z[4,1,4]  R1378     -1.0947525501251221e-01
    z[4,1,4]  R1379     -1.0854104906320572e-01
    z[4,1,4]  R1380     -2.5228586792945862e-01
    z[4,1,4]  R1381     -6.6569441556930542e-01
    z[4,1,4]  R1382     -1.9893574714660645e-01
    z[4,1,4]  R1383     1.3082090020179749e-01
    z[4,1,4]  R1384     3.8038212805986404e-02
    z[4,1,4]  R1385     -6.0758739709854126e-01
    z[4,1,4]  R1386     -1.3361072167754173e-02
    z[4,1,4]  R1387     8.8092230260372162e-02
    z[4,1,4]  R1388     2.6285862922668457e-01
    z[4,1,4]  R1389     2.0473259687423706e-01
    z[4,1,4]  R1390     2.8543433547019958e-01
    z[4,1,4]  R1391     1.7861008644104004e-01
    z[4,1,4]  R1392     3.9897285401821136e-02
    z[4,1,4]  R1393     -1.0376599431037903e-01
    z[4,1,4]  R1394     2.9115831851959229e-01
    z[4,1,4]  R1395     5.5429106950759888e-01
    z[4,1,4]  R1396     -1.4271882176399231e-01
    z[4,1,4]  R1397     -1.6991877555847168e-01
    z[4,1,4]  R1398     -3.5168644785881042e-01
    z[4,1,4]  R1399     -2.1051105856895447e-01
    z[4,1,4]  R1400     1.6175056993961334e-01
    z[4,1,4]  R1401     1.5208730101585388e-01
    z[4,1,4]  R1402     -1.2244738638401031e-01
    z[4,1,4]  R1403     2.9136139154434204e-01
    z[4,1,4]  R1404     8.3066321909427643e-02
    z[4,1,4]  R1405     2.1944449841976166e-01
    z[4,1,4]  R1406     2.4374271929264069e-01
    z[4,1,4]  R1407     2.9229193925857544e-01
    z[4,1,4]  R1408     3.7499007582664490e-01
    z[4,1,4]  R1409     -5.2446460723876953e-01
    z[4,1,4]  R1410     1.5510775148868561e-01
    z[4,1,4]  R1411     -3.1334522366523743e-01
    z[4,1,4]  R1412     0.34656822681427
    z[4,1,4]  R1413     -2.3756182193756104e-01
    z[4,1,4]  R1414     3.7706881761550903e-01
    z[4,1,4]  R1415     -5.1656424999237061e-01
    z[4,1,4]  R1416     -3.3346924185752869e-01
    z[4,1,4]  R1417     2.6950253173708916e-02
    z[4,1,4]  R1418     0.00511670857667923
    z[4,1,4]  R1419     1.8650548160076141e-01
    z[4,1,4]  R1420     4.6590843796730042e-01
    z[4,1,4]  R1421     1.1250261217355728e-01
    z[4,1,4]  R1422     -5.7950061559677124e-01
    z[4,1,4]  R1423     -5.7460999488830566e-01
    z[4,1,4]  R1424     -3.1709730625152588e-01
    z[4,1,4]  R1425     -1.8819181621074677e-01
    z[4,1,4]  R1426     2.0447519421577454e-01
    z[4,1,4]  R1427     1.5613253414630890e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1359     -1
    z[4,1,5]  R1360     1
    z[4,1,5]  R1363     -3.8344261050224304e-01
    z[4,1,5]  R1364     -2.4632996320724487e-01
    z[4,1,5]  R1365     -4.6027606725692749e-01
    z[4,1,5]  R1366     7.6073859818279743e-03
    z[4,1,5]  R1367     -1.3433896005153656e-01
    z[4,1,5]  R1368     1.5455786883831024e-01
    z[4,1,5]  R1369     -2.7092182636260986e-01
    z[4,1,5]  R1370     7.6671266555786133e-01
    z[4,1,5]  R1371     2.8965758159756660e-02
    z[4,1,5]  R1372     -1.5829353034496307e-01
    z[4,1,5]  R1373     -4.2344415187835693e-01
    z[4,1,5]  R1374     -3.0616271495819092e-01
    z[4,1,5]  R1375     -5.2750091999769211e-02
    z[4,1,5]  R1376     -8.3749219775199890e-02
    z[4,1,5]  R1377     3.5495933890342712e-01
    z[4,1,5]  R1378     2.2453854978084564e-01
    z[4,1,5]  R1379     1.8640884757041931e-01
    z[4,1,5]  R1380     -7.0749111473560333e-02
    z[4,1,5]  R1381     2.3678185045719147e-01
    z[4,1,5]  R1382     3.0017700791358948e-01
    z[4,1,5]  R1383     4.8381257057189941e-01
    z[4,1,5]  R1384     3.3239677548408508e-01
    z[4,1,5]  R1385     1.4385271072387695e-01
    z[4,1,5]  R1386     2.0954367518424988e-01
    z[4,1,5]  R1387     2.6355904340744019e-01
    z[4,1,5]  R1388     -6.3787393271923065e-02
    z[4,1,5]  R1389     -4.0692013502120972e-01
    z[4,1,5]  R1390     1.3815888762474060e-01
    z[4,1,5]  R1391     -2.3018175363540649e-01
    z[4,1,5]  R1392     -3.1856033205986023e-01
    z[4,1,5]  R1393     -1.9800245761871338e-01
    z[4,1,5]  R1394     -1.3131687045097351e-01
    z[4,1,5]  R1395     2.0805935561656952e-01
    z[4,1,5]  R1396     -2.8782995417714119e-02
    z[4,1,5]  R1397     1.7422935366630554e-01
    z[4,1,5]  R1398     -1.3307310640811920e-01
    z[4,1,5]  R1399     3.2203185558319092e-01
    z[4,1,5]  R1400     6.9552063941955566e-02
    z[4,1,5]  R1401     1.4325352013111115e-01
    z[4,1,5]  R1402     2.9530632495880127e-01
    z[4,1,5]  R1403     4.1212841868400574e-01
    z[4,1,5]  R1404     5.8570575714111328e-01
    z[4,1,5]  R1405     -4.3115538358688354e-01
    z[4,1,5]  R1406     4.2247429490089417e-01
    z[4,1,5]  R1407     -1.7058970034122467e-01
    z[4,1,5]  R1408     -1.5608721971511841e-01
    z[4,1,5]  R1409     -5.0835871696472168e-01
    z[4,1,5]  R1410     6.9800531864166260e-01
    z[4,1,5]  R1411     2.4462699890136719e-01
    z[4,1,5]  R1412     4.6346226334571838e-01
    z[4,1,5]  R1413     -6.4760148525238037e-01
    z[4,1,5]  R1414     -8.1387633085250854e-01
    z[4,1,5]  R1415     1.3412535190582275e-01
    z[4,1,5]  R1416     2.1217954158782959e-01
    z[4,1,5]  R1417     -1.9284363090991974e-01
    z[4,1,5]  R1418     -5.1182083785533905e-02
    z[4,1,5]  R1419     2.1714878082275391e-01
    z[4,1,5]  R1420     -1.0764618217945099e-01
    z[4,1,5]  R1421     6.0474467277526855e-01
    z[4,1,5]  R1422     0.469120055437088
    z[4,1,5]  R1423     -0.361625075340271
    z[4,1,5]  R1424     -5.3766030073165894e-01
    z[4,1,5]  R1425     -1.6545116901397705e-01
    z[4,1,5]  R1426     1.3289323449134827e-01
    z[4,1,5]  R1427     -9.6647344529628754e-02
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1361     -1
    z[4,1,6]  R1362     1
    z[4,1,6]  R1363     2.9716029763221741e-01
    z[4,1,6]  R1364     -3.8691893219947815e-01
    z[4,1,6]  R1365     -3.4699544310569763e-01
    z[4,1,6]  R1366     9.0068168938159943e-02
    z[4,1,6]  R1367     -3.7443239241838455e-02
    z[4,1,6]  R1368     -0.259909987449646
    z[4,1,6]  R1369     -5.0366961956024170e-01
    z[4,1,6]  R1370     4.6736735850572586e-02
    z[4,1,6]  R1371     -1.0265648597851396e-03
    z[4,1,6]  R1372     -1.0762225091457367e-01
    z[4,1,6]  R1373     0.0696331113576889
    z[4,1,6]  R1374     3.1715276837348938e-01
    z[4,1,6]  R1375     2.2725264728069305e-01
    z[4,1,6]  R1376     -4.8621557652950287e-02
    z[4,1,6]  R1377     5.8099544048309326e-01
    z[4,1,6]  R1378     7.2574146091938019e-02
    z[4,1,6]  R1379     -2.1973720192909241e-01
    z[4,1,6]  R1380     -4.7050568461418152e-01
    z[4,1,6]  R1381     -7.0633783936500549e-02
    z[4,1,6]  R1382     0.336056649684906
    z[4,1,6]  R1383     -3.7884730100631714e-01
    z[4,1,6]  R1384     3.8792282342910767e-01
    z[4,1,6]  R1385     4.8093879222869873e-01
    z[4,1,6]  R1386     -2.1727073192596436e-01
    z[4,1,6]  R1387     2.2801366448402405e-01
    z[4,1,6]  R1388     -4.6854072809219360e-01
    z[4,1,6]  R1389     -1.8549780547618866e-01
    z[4,1,6]  R1390     -3.2859003543853760e-01
    z[4,1,6]  R1391     -2.7782490849494934e-01
    z[4,1,6]  R1392     -0.0677451640367508
    z[4,1,6]  R1393     1.5936177968978882e-01
    z[4,1,6]  R1394     2.4572479724884033e-01
    z[4,1,6]  R1395     2.4274982511997223e-01
    z[4,1,6]  R1396     3.2023850828409195e-02
    z[4,1,6]  R1397     3.2487708330154419e-01
    z[4,1,6]  R1398     2.5020885467529297e-01
    z[4,1,6]  R1399     -2.3303854465484619e-01
    z[4,1,6]  R1400     2.8261154890060425e-01
    z[4,1,6]  R1401     -1.6217219829559326e-01
    z[4,1,6]  R1402     2.0462350547313690e-01
    z[4,1,6]  R1403     -3.4572128206491470e-02
    z[4,1,6]  R1404     2.4441033601760864e-01
    z[4,1,6]  R1405     1.2077458202838898e-01
    z[4,1,6]  R1406     3.4495350718498230e-01
    z[4,1,6]  R1407     0.470958948135376
    z[4,1,6]  R1408     2.6052755117416382e-01
    z[4,1,6]  R1409     -1.2949370779097080e-02
    z[4,1,6]  R1410     2.4970626831054688e-01
    z[4,1,6]  R1411     5.9450912475585938e-01
    z[4,1,6]  R1412     -5.0955647230148315e-01
    z[4,1,6]  R1413     -1.8352743983268738e-01
    z[4,1,6]  R1414     -1.1067216284573078e-02
    z[4,1,6]  R1415     -1.8066921830177307e-01
    z[4,1,6]  R1416     -6.7055529356002808e-01
    z[4,1,6]  R1417     3.8996872305870056e-01
    z[4,1,6]  R1418     2.6779506355524063e-02
    z[4,1,6]  R1419     1.9074784219264984e-01
    z[4,1,6]  R1420     1.5408596396446228e-01
    z[4,1,6]  R1421     -4.5079058408737183e-01
    z[4,1,6]  R1422     -6.9441363215446472e-02
    z[4,1,6]  R1423     -4.3850109796039760e-04
    z[4,1,6]  R1424     4.8177537322044373e-01
    z[4,1,6]  R1425     -0.126246377825737
    z[4,1,6]  R1426     1.9304960966110229e-01
    z[4,1,6]  R1427     1.7743013799190521e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1428     -1
    z[1,5,0]  R1429     1
    z[1,5,0]  R1442     -4.5251451432704926e-02
    z[1,5,0]  R1443     -3.5671177506446838e-01
    z[1,5,0]  R1444     -4.2242676019668579e-02
    z[1,5,0]  R1445     -5.9709161520004272e-01
    z[1,5,0]  R1446     -7.8293181955814362e-02
    z[1,5,0]  R1447     -1.2750937603414059e-02
    z[1,5,0]  R1448     -6.8526011705398560e-01
    z[1,5,0]  R1449     -5.3374101407825947e-03
    z[1,5,0]  R1450     -7.7924764156341553e-01
    z[1,5,0]  R1451     -1.6494253277778625e-01
    z[1,5,0]  R1452     1.0237602144479752e-01
    z[1,5,0]  R1453     -9.1826446354389191e-02
    z[1,5,0]  R1454     -1.0050944983959198e-01
    z[1,5,0]  R1455     -6.5777927637100220e-02
    z[1,5,0]  R1456     -2.2169025242328644e-01
    z[1,5,0]  R1457     2.1646836772561073e-02
    z[1,5,0]  R1458     5.4830335080623627e-02
    z[1,5,0]  R1459     6.3755147159099579e-02
    z[1,5,0]  R1460     -3.9741796255111694e-01
    z[1,5,0]  R1461     1.9783353805541992e-01
    z[1,5,0]  R1462     9.0975388884544373e-02
    z[1,5,0]  R1463     7.3167368769645691e-02
    z[1,5,0]  R1464     2.3548530042171478e-01
    z[1,5,0]  R1465     2.6657110452651978e-01
    z[1,5,0]  R1466     1.6141006350517273e-01
    z[1,5,0]  R1467     -5.9019678831100464e-01
    z[1,5,0]  R1468     2.3474588990211487e-01
    z[1,5,0]  R1469     3.3537900447845459e-01
    z[1,5,0]  R1470     2.8809833526611328e-01
    z[1,5,0]  R1471     2.9013855382800102e-02
    z[1,5,0]  R1472     1.7178709805011749e-01
    z[1,5,0]  R1473     0.073527030646801
    z[1,5,0]  R1474     3.7063896656036377e-01
    z[1,5,0]  R1475     3.3976495265960693e-01
    z[1,5,0]  R1476     3.7903591990470886e-01
    z[1,5,0]  R1477     4.6893391013145447e-01
    z[1,5,0]  R1478     2.6620736718177795e-01
    z[1,5,0]  R1479     5.3020846843719482e-01
    z[1,5,0]  R1480     8.5024207830429077e-01
    z[1,5,0]  R1481     7.7913725376129150e-01
    z[1,5,0]  R1482     -4.1167184710502625e-01
    z[1,5,0]  R1483     5.2194584161043167e-02
    z[1,5,0]  R1484     -3.3740440011024475e-01
    z[1,5,0]  R1485     1.4051201939582825e-01
    z[1,5,0]  R1486     -1.3101556897163391e-01
    z[1,5,0]  R1487     2.3414593935012817e-01
    z[1,5,0]  R1488     2.6615265011787415e-01
    z[1,5,0]  R1489     -3.8141000270843506e-01
    z[1,5,0]  R1490     -7.2037017345428467e-01
    z[1,5,0]  R1491     -7.2790348529815674e-01
    z[1,5,0]  R1492     5.0193983316421509e-01
    z[1,5,0]  R1493     3.5697630047798157e-01
    z[1,5,0]  R1494     3.1045895814895630e-01
    z[1,5,0]  R1495     3.5617956519126892e-01
    z[1,5,0]  R1496     -0.0835917741060257
    z[1,5,0]  R1497     2.3714382946491241e-01
    z[1,5,0]  R1498     2.6713207364082336e-01
    z[1,5,0]  R1499     1.8173341453075409e-01
    z[1,5,0]  R1500     4.4621476531028748e-01
    z[1,5,0]  R1501     3.1219500303268433e-01
    z[1,5,0]  R1502     -5.0173097848892212e-01
    z[1,5,0]  R1503     6.3865667581558228e-01
    z[1,5,0]  R1504     6.5449148416519165e-02
    z[1,5,0]  R1505     5.2495366334915161e-01
    z[1,5,0]  R1506     3.5497203469276428e-01
    z[1,5,0]  R1507     4.4768762588500977e-01
    z[1,5,0]  R1508     4.9666678905487061e-01
    z[1,5,0]  R1509     6.2237411737442017e-01
    z[1,5,0]  R1510     4.7753170132637024e-01
    z[1,5,0]  R1511     3.4345629811286926e-01
    z[1,5,0]  R1512     -6.0553711652755737e-01
    z[1,5,0]  R1513     1.7541919648647308e-01
    z[1,5,0]  R1514     5.9707891941070557e-01
    z[1,5,0]  R1515     4.7816035151481628e-01
    z[1,5,0]  R1516     4.8107045888900757e-01
    z[1,5,0]  R1517     0.0420943982899189
    z[1,5,0]  R1518     2.2906219959259033e-01
    z[1,5,0]  R1519     3.0979016795754433e-02
    z[1,5,0]  R1520     -1.0578852146863937e-01
    z[1,5,0]  R1521     3.5713267326354980e-01
    z[1,5,0]  R1522     0.481503427028656
    z[1,5,0]  R1523     0.350081205368042
    z[1,5,0]  R1524     4.4970616698265076e-01
    z[1,5,0]  R1525     1.2914520502090454e-01
    z[1,5,0]  R1526     4.7862935066223145e-01
    z[1,5,0]  R1527     -0.0339871309697628
    z[1,5,0]  R1528     2.8752669692039490e-01
    z[1,5,0]  R1529     4.5326313376426697e-01
    z[1,5,0]  R1530     3.3613637089729309e-01
    z[1,5,0]  R1531     2.0278221368789673e-01
    z[1,5,0]  R1532     6.6347676515579224e-01
    z[1,5,0]  R1533     -2.4898461997509003e-01
    z[1,5,0]  R1534     4.6122840046882629e-01
    z[1,5,0]  R1535     4.9284663796424866e-01
    z[1,5,0]  R1536     4.1822734475135803e-01
    z[1,5,0]  R1537     4.8851454257965088e-01
    z[1,5,0]  R1538     3.4320834279060364e-01
    z[1,5,0]  R1539     1.8371088802814484e-01
    z[1,5,0]  R1540     3.1019492074847221e-02
    z[1,5,0]  R1541     7.1308411657810211e-02
    z[1,5,0]  R1542     -3.9650008082389832e-01
    z[1,5,0]  R1543     5.1104658842086792e-01
    z[1,5,0]  R1544     5.1345431804656982e-01
    z[1,5,0]  R1545     9.9075190722942352e-02
    z[1,5,0]  R1546     1.3918174803256989e-01
    z[1,5,0]  R1547     1.0309685766696930e-01
    z[1,5,0]  R1548     1.3891510665416718e-02
    z[1,5,0]  R1549     6.8562909960746765e-02
    z[1,5,0]  R1550     -6.5475896000862122e-02
    z[1,5,0]  R1551     -2.6827117800712585e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1430     -1
    z[1,5,1]  R1431     1
    z[1,5,1]  R1442     -4.1153582930564880e-01
    z[1,5,1]  R1443     0.573833703994751
    z[1,5,1]  R1444     -0.366733580827713
    z[1,5,1]  R1445     2.7760806679725647e-01
    z[1,5,1]  R1446     -4.9850201606750488e-01
    z[1,5,1]  R1447     -0.262656033039093
    z[1,5,1]  R1448     3.9246013760566711e-01
    z[1,5,1]  R1449     -2.8604340553283691e-01
    z[1,5,1]  R1450     1.2124329805374146e-01
    z[1,5,1]  R1451     5.4653489589691162e-01
    z[1,5,1]  R1452     -7.8913533687591553e-01
    z[1,5,1]  R1453     -7.8548103570938110e-01
    z[1,5,1]  R1454     -7.8021126985549927e-01
    z[1,5,1]  R1455     -7.6294887065887451e-01
    z[1,5,1]  R1456     -7.4078255891799927e-01
    z[1,5,1]  R1457     -7.4767166376113892e-01
    z[1,5,1]  R1458     -6.2841165065765381e-01
    z[1,5,1]  R1459     -7.1363770961761475e-01
    z[1,5,1]  R1460     -6.6738867759704590e-01
    z[1,5,1]  R1461     -5.4265409708023071e-01
    z[1,5,1]  R1462     -8.6383581161499023e-01
    z[1,5,1]  R1463     -4.6129563450813293e-01
    z[1,5,1]  R1464     -5.1387935876846313e-01
    z[1,5,1]  R1465     -4.2744708061218262e-01
    z[1,5,1]  R1466     -0.583754301071167
    z[1,5,1]  R1467     1.9236426055431366e-01
    z[1,5,1]  R1468     -3.0478119850158691e-01
    z[1,5,1]  R1469     -4.9917593598365784e-01
    z[1,5,1]  R1470     -5.3909343481063843e-01
    z[1,5,1]  R1471     5.0474762916564941e-01
    z[1,5,1]  R1472     -5.4632717370986938e-01
    z[1,5,1]  R1473     -5.4762643575668335e-01
    z[1,5,1]  R1474     -1.4396350085735321e-01
    z[1,5,1]  R1475     -2.5115618109703064e-01
    z[1,5,1]  R1476     -4.8610472679138184e-01
    z[1,5,1]  R1477     4.6591964364051819e-01
    z[1,5,1]  R1478     5.2314704656600952e-01
    z[1,5,1]  R1479     4.5538052916526794e-01
    z[1,5,1]  R1480     3.7054851651191711e-01
    z[1,5,1]  R1481     3.2702940702438354e-01
    z[1,5,1]  R1482     8.5575813427567482e-03
    z[1,5,1]  R1483     1.4072133600711823e-01
    z[1,5,1]  R1484     -2.6882013678550720e-01
    z[1,5,1]  R1485     -1.2652019038796425e-02
    z[1,5,1]  R1486     3.0407634377479553e-01
    z[1,5,1]  R1487     5.1733434200286865e-01
    z[1,5,1]  R1488     1.8734943866729736e-01
    z[1,5,1]  R1489     1.8706493079662323e-02
    z[1,5,1]  R1490     -6.2197268009185791e-01
    z[1,5,1]  R1491     -6.0173243284225464e-01
    z[1,5,1]  R1492     -0.541064977645874
    z[1,5,1]  R1493     -7.0541268587112427e-01
    z[1,5,1]  R1494     -0.561692476272583
    z[1,5,1]  R1495     -5.9705138206481934e-01
    z[1,5,1]  R1496     8.4480911493301392e-01
    z[1,5,1]  R1497     -2.9515042901039124e-01
    z[1,5,1]  R1498     -5.9425985813140869e-01
    z[1,5,1]  R1499     7.0331460237503052e-01
    z[1,5,1]  R1500     5.4043614864349365e-01
    z[1,5,1]  R1501     -4.5522215962409973e-01
    z[1,5,1]  R1502     -4.3140354752540588e-01
    z[1,5,1]  R1503     3.7732613086700439e-01
    z[1,5,1]  R1504     8.4820365905761719e-01
    z[1,5,1]  R1505     6.9910007715225220e-01
    z[1,5,1]  R1506     6.6943019628524780e-01
    z[1,5,1]  R1507     0.597454845905304
    z[1,5,1]  R1508     6.0251086950302124e-01
    z[1,5,1]  R1509     5.7777369022369385e-01
    z[1,5,1]  R1510     6.0641765594482422e-01
    z[1,5,1]  R1511     0.650162935256958
    z[1,5,1]  R1512     -5.0807815790176392e-01
    z[1,5,1]  R1513     5.8061248064041138e-01
    z[1,5,1]  R1514     -1.7243736982345581e-01
    z[1,5,1]  R1515     -5.6971997022628784e-01
    z[1,5,1]  R1516     -5.5164480209350586e-01
    z[1,5,1]  R1517     -4.0834445506334305e-02
    z[1,5,1]  R1518     1.3132227957248688e-01
    z[1,5,1]  R1519     -5.1098912954330444e-02
    z[1,5,1]  R1520     2.9433953762054443e-01
    z[1,5,1]  R1521     -2.1766616404056549e-01
    z[1,5,1]  R1522     -5.3306269645690918e-01
    z[1,5,1]  R1523     -3.5644170641899109e-01
    z[1,5,1]  R1524     -3.5504448413848877e-01
    z[1,5,1]  R1525     -5.8893674612045288e-01
    z[1,5,1]  R1526     -4.9673485755920410e-01
    z[1,5,1]  R1527     1.1629262566566467e-01
    z[1,5,1]  R1528     -4.4587850570678711e-01
    z[1,5,1]  R1529     -1.3600496947765350e-01
    z[1,5,1]  R1530     -5.9690237045288086e-01
    z[1,5,1]  R1531     7.1867331862449646e-02
    z[1,5,1]  R1532     2.4152347818017006e-02
    z[1,5,1]  R1533     8.4414738416671753e-01
    z[1,5,1]  R1534     0.718745231628418
    z[1,5,1]  R1535     -4.8123809695243835e-01
    z[1,5,1]  R1536     -3.2860276103019714e-01
    z[1,5,1]  R1537     -6.6047638654708862e-01
    z[1,5,1]  R1538     -1.4736685156822205e-01
    z[1,5,1]  R1539     2.6722899079322815e-01
    z[1,5,1]  R1540     -3.5031118988990784e-01
    z[1,5,1]  R1541     -0.500552237033844
    z[1,5,1]  R1542     -3.4786400198936462e-01
    z[1,5,1]  R1543     -5.2081096172332764e-01
    z[1,5,1]  R1544     -5.9718823432922363e-01
    z[1,5,1]  R1545     -5.9593987464904785e-01
    z[1,5,1]  R1546     -3.3485185354948044e-02
    z[1,5,1]  R1547     2.0150625705718994e-01
    z[1,5,1]  R1548     4.2572334408760071e-02
    z[1,5,1]  R1549     -0.365588903427124
    z[1,5,1]  R1550     1.8889233469963074e-02
    z[1,5,1]  R1551     1.7349785566329956e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1432     -1
    z[1,5,2]  R1433     1
    z[1,5,2]  R1442     5.0443840026855469e-01
    z[1,5,2]  R1443     -4.9243211746215820e-01
    z[1,5,2]  R1444     1.2689022719860077e-01
    z[1,5,2]  R1445     -0.626781165599823
    z[1,5,2]  R1446     7.9153716564178467e-01
    z[1,5,2]  R1447     7.2913813591003418e-01
    z[1,5,2]  R1448     -4.3528309464454651e-01
    z[1,5,2]  R1449     3.0553472042083740e-01
    z[1,5,2]  R1450     -5.4495644569396973e-01
    z[1,5,2]  R1451     -7.0033740997314453e-01
    z[1,5,2]  R1452     -3.6397790908813477e-01
    z[1,5,2]  R1453     -2.8767114877700806e-01
    z[1,5,2]  R1454     -3.3676931262016296e-01
    z[1,5,2]  R1455     -3.1985855102539062e-01
    z[1,5,2]  R1456     -2.3950286209583282e-01
    z[1,5,2]  R1457     -1.2533517181873322e-01
    z[1,5,2]  R1458     1.7164391279220581e-01
    z[1,5,2]  R1459     -2.3216864466667175e-01
    z[1,5,2]  R1460     1.0192343033850193e-03
    z[1,5,2]  R1461     9.2219136655330658e-02
    z[1,5,2]  R1462     1.1176556348800659e-01
    z[1,5,2]  R1463     3.0754688382148743e-01
    z[1,5,2]  R1464     0.3104248046875
    z[1,5,2]  R1465     4.3009561300277710e-01
    z[1,5,2]  R1466     -1.9003529846668243e-01
    z[1,5,2]  R1467     -3.1999304890632629e-01
    z[1,5,2]  R1468     5.9365980327129364e-02
    z[1,5,2]  R1469     5.3292375802993774e-01
    z[1,5,2]  R1470     1.1547703295946121e-01
    z[1,5,2]  R1471     3.5850954055786133e-01
    z[1,5,2]  R1472     1.8182796239852905e-01
    z[1,5,2]  R1473     5.6437408924102783e-01
    z[1,5,2]  R1474     7.5032621622085571e-01
    z[1,5,2]  R1475     1.2528024613857269e-01
    z[1,5,2]  R1476     2.2773987054824829e-01
    z[1,5,2]  R1477     2.6856359094381332e-02
    z[1,5,2]  R1478     1.8239600956439972e-01
    z[1,5,2]  R1479     2.3532277345657349e-01
    z[1,5,2]  R1480     1.6897714138031006e-01
    z[1,5,2]  R1481     6.8543985486030579e-02
    z[1,5,2]  R1482     -2.5082439184188843e-01
    z[1,5,2]  R1483     -4.9486222863197327e-01
    z[1,5,2]  R1484     -8.3715015649795532e-01
    z[1,5,2]  R1485     -6.9883072376251221e-01
    z[1,5,2]  R1486     -8.6587077379226685e-01
    z[1,5,2]  R1487     -4.6348148584365845e-01
    z[1,5,2]  R1488     -0.835545003414154
    z[1,5,2]  R1489     -3.9633882045745850e-01
    z[1,5,2]  R1490     1.9898726046085358e-01
    z[1,5,2]  R1491     3.1680113077163696e-01
    z[1,5,2]  R1492     4.7050195932388306e-01
    z[1,5,2]  R1493     5.2155035734176636e-01
    z[1,5,2]  R1494     4.4924122095108032e-01
    z[1,5,2]  R1495     5.2330291271209717e-01
    z[1,5,2]  R1496     2.3753516376018524e-01
    z[1,5,2]  R1497     0.685438334941864
    z[1,5,2]  R1498     4.8933586478233337e-01
    z[1,5,2]  R1499     3.0118945240974426e-01
    z[1,5,2]  R1500     3.3472895622253418e-01
    z[1,5,2]  R1501     0.550088107585907
    z[1,5,2]  R1502     -1.4015612006187439e-01
    z[1,5,2]  R1503     3.8528403639793396e-01
    z[1,5,2]  R1504     3.6292123794555664e-01
    z[1,5,2]  R1505     1.1737194657325745e-01
    z[1,5,2]  R1506     1.4842732250690460e-01
    z[1,5,2]  R1507     2.1074037998914719e-02
    z[1,5,2]  R1508     1.3993789255619049e-01
    z[1,5,2]  R1509     1.3967829942703247e-01
    z[1,5,2]  R1510     5.2091282606124878e-01
    z[1,5,2]  R1511     2.3172754049301147e-01
    z[1,5,2]  R1512     0.0881069228053093
    z[1,5,2]  R1513     3.4890773892402649e-01
    z[1,5,2]  R1514     9.3202881515026093e-02
    z[1,5,2]  R1515     2.4517005681991577e-01
    z[1,5,2]  R1516     3.7510260939598083e-01
    z[1,5,2]  R1517     -1.1677806824445724e-01
    z[1,5,2]  R1518     1.2375617772340775e-01
    z[1,5,2]  R1519     1.3580541312694550e-01
    z[1,5,2]  R1520     -4.8568150959908962e-03
    z[1,5,2]  R1521     4.2193382978439331e-01
    z[1,5,2]  R1522     5.0784224271774292e-01
    z[1,5,2]  R1523     6.4672106504440308e-01
    z[1,5,2]  R1524     4.5124414563179016e-01
    z[1,5,2]  R1525     7.5461500883102417e-01
    z[1,5,2]  R1526     4.1927462816238403e-01
    z[1,5,2]  R1527     -1.3850663602352142e-01
    z[1,5,2]  R1528     6.0157597064971924e-01
    z[1,5,2]  R1529     7.0908397436141968e-01
    z[1,5,2]  R1530     2.0411163568496704e-01
    z[1,5,2]  R1531     0.0621710866689682
    z[1,5,2]  R1532     1.0683589428663254e-01
    z[1,5,2]  R1533     2.4507471919059753e-01
    z[1,5,2]  R1534     -0.00966144260019064
    z[1,5,2]  R1535     5.8281403779983521e-01
    z[1,5,2]  R1536     5.8617675304412842e-01
    z[1,5,2]  R1537     4.8749116063117981e-01
    z[1,5,2]  R1538     8.3031928539276123e-01
    z[1,5,2]  R1539     6.2518283724784851e-02
    z[1,5,2]  R1540     -2.0371995866298676e-01
    z[1,5,2]  R1541     7.6282203197479248e-01
    z[1,5,2]  R1542     9.7577020525932312e-02
    z[1,5,2]  R1543     6.3724607229232788e-01
    z[1,5,2]  R1544     0.546921968460083
    z[1,5,2]  R1545     7.2423154115676880e-01
    z[1,5,2]  R1546     -2.3010337352752686e-01
    z[1,5,2]  R1547     2.2679027169942856e-02
    z[1,5,2]  R1548     1.8637599050998688e-01
    z[1,5,2]  R1549     8.1958460807800293e-01
    z[1,5,2]  R1550     3.5175395011901855e-01
    z[1,5,2]  R1551     0.812131404876709
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1434     -1
    z[1,5,3]  R1435     1
    z[1,5,3]  R1442     5.3050768375396729e-01
    z[1,5,3]  R1443     2.4304993450641632e-01
    z[1,5,3]  R1444     0.799430251121521
    z[1,5,3]  R1445     1.0718559473752975e-01
    z[1,5,3]  R1446     1.0570231825113297e-01
    z[1,5,3]  R1447     5.6906795501708984e-01
    z[1,5,3]  R1448     1.5660229325294495e-01
    z[1,5,3]  R1449     6.4447224140167236e-01
    z[1,5,3]  R1450     2.4263779819011688e-01
    z[1,5,3]  R1451     1.3728702068328857e-01
    z[1,5,3]  R1452     0.174093097448349
    z[1,5,3]  R1453     -2.9917600750923157e-01
    z[1,5,3]  R1454     -3.9608660340309143e-01
    z[1,5,3]  R1455     -4.9124431610107422e-01
    z[1,5,3]  R1456     -4.4795447587966919e-01
    z[1,5,3]  R1457     -4.1094160079956055e-01
    z[1,5,3]  R1458     -4.0366217494010925e-01
    z[1,5,3]  R1459     -4.2908832430839539e-01
    z[1,5,3]  R1460     -1.9940476119518280e-01
    z[1,5,3]  R1461     -5.6705063581466675e-01
    z[1,5,3]  R1462     1.2812471017241478e-02
    z[1,5,3]  R1463     3.9192914962768555e-01
    z[1,5,3]  R1464     -1.0241139680147171e-01
    z[1,5,3]  R1465     -2.2310981154441833e-01
    z[1,5,3]  R1466     -5.0097241997718811e-02
    z[1,5,3]  R1467     5.2560776472091675e-02
    z[1,5,3]  R1468     2.0923748612403870e-01
    z[1,5,3]  R1469     1.9200769066810608e-01
    z[1,5,3]  R1470     8.4713473916053772e-02
    z[1,5,3]  R1471     6.5258580446243286e-01
    z[1,5,3]  R1472     7.9723989963531494e-01
    z[1,5,3]  R1473     5.0779759883880615e-01
    z[1,5,3]  R1474     1.6282172501087189e-01
    z[1,5,3]  R1475     4.7349786758422852e-01
    z[1,5,3]  R1476     8.6323969066143036e-02
    z[1,5,3]  R1477     3.1835392117500305e-01
    z[1,5,3]  R1478     -2.1111611276865005e-02
    z[1,5,3]  R1479     6.1433070898056030e-01
    z[1,5,3]  R1480     -1.2037465721368790e-01
    z[1,5,3]  R1481     -4.6486461162567139e-01
    z[1,5,3]  R1482     5.9576869010925293e-01
    z[1,5,3]  R1483     3.9372414350509644e-01
    z[1,5,3]  R1484     1.3222867250442505e-01
    z[1,5,3]  R1485     6.4013522863388062e-01
    z[1,5,3]  R1486     1.5869811177253723e-01
    z[1,5,3]  R1487     6.4389592409133911e-01
    z[1,5,3]  R1488     2.3036353290081024e-01
    z[1,5,3]  R1489     4.4051659107208252e-01
    z[1,5,3]  R1490     1.5037453733384609e-02
    z[1,5,3]  R1491     7.1662895381450653e-02
    z[1,5,3]  R1492     -1.1776566505432129e-01
    z[1,5,3]  R1493     -1.3404813408851624e-01
    z[1,5,3]  R1494     -1.9995562732219696e-01
    z[1,5,3]  R1495     -4.2782168835401535e-02
    z[1,5,3]  R1496     -3.0475902557373047e-01
    z[1,5,3]  R1497     -4.1686594486236572e-01
    z[1,5,3]  R1498     -3.8454201817512512e-01
    z[1,5,3]  R1499     -5.1275640726089478e-01
    z[1,5,3]  R1500     -4.1546443104743958e-01
    z[1,5,3]  R1501     -3.2571017742156982e-01
    z[1,5,3]  R1502     -1.3579273223876953e-01
    z[1,5,3]  R1503     1.1743741482496262e-01
    z[1,5,3]  R1504     -9.0006791055202484e-02
    z[1,5,3]  R1505     -3.6825048923492432e-01
    z[1,5,3]  R1506     -5.0619250535964966e-01
    z[1,5,3]  R1507     -5.6021952629089355e-01
    z[1,5,3]  R1508     -3.8618949055671692e-01
    z[1,5,3]  R1509     -3.2842054963111877e-01
    z[1,5,3]  R1510     -3.1660124659538269e-01
    z[1,5,3]  R1511     -3.8760277628898621e-01
    z[1,5,3]  R1512     -2.8610104322433472e-01
    z[1,5,3]  R1513     3.0981364846229553e-01
    z[1,5,3]  R1514     4.0037342905998230e-01
    z[1,5,3]  R1515     -5.9528566896915436e-02
    z[1,5,3]  R1516     -3.6331480741500854e-01
    z[1,5,3]  R1517     -8.4577780961990356e-01
    z[1,5,3]  R1518     -7.9938125610351562e-01
    z[1,5,3]  R1519     -0.662041962146759
    z[1,5,3]  R1520     -0.797913670539856
    z[1,5,3]  R1521     -4.7221881151199341e-01
    z[1,5,3]  R1522     -6.7318767309188843e-02
    z[1,5,3]  R1523     -1.2998647987842560e-01
    z[1,5,3]  R1524     -4.8076048493385315e-01
    z[1,5,3]  R1525     9.2176847159862518e-02
    z[1,5,3]  R1526     -5.8152031898498535e-01
    z[1,5,3]  R1527     -8.3289182186126709e-01
    z[1,5,3]  R1528     -5.7208532094955444e-01
    z[1,5,3]  R1529     -3.0186501145362854e-01
    z[1,5,3]  R1530     -5.2364188432693481e-01
    z[1,5,3]  R1531     -8.4814244508743286e-01
    z[1,5,3]  R1532     4.1239511966705322e-01
    z[1,5,3]  R1533     -4.8379480838775635e-02
    z[1,5,3]  R1534     -4.6403801441192627e-01
    z[1,5,3]  R1535     -4.0619453787803650e-01
    z[1,5,3]  R1536     -4.2855963110923767e-01
    z[1,5,3]  R1537     5.4446242749691010e-02
    z[1,5,3]  R1538     -3.3980420231819153e-01
    z[1,5,3]  R1539     -0.851863443851471
    z[1,5,3]  R1540     -8.3771157264709473e-01
    z[1,5,3]  R1541     -9.4819359481334686e-02
    z[1,5,3]  R1542     -0.722500741481781
    z[1,5,3]  R1543     -2.0860888063907623e-01
    z[1,5,3]  R1544     -2.0605309307575226e-01
    z[1,5,3]  R1545     2.8400283306837082e-02
    z[1,5,3]  R1546     -0.847332775592804
    z[1,5,3]  R1547     -8.6517196893692017e-01
    z[1,5,3]  R1548     -6.3254356384277344e-01
    z[1,5,3]  R1549     -2.6408711075782776e-01
    z[1,5,3]  R1550     -7.7237951755523682e-01
    z[1,5,3]  R1551     3.1130319833755493e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1436     -1
    z[1,5,4]  R1437     1
    z[1,5,4]  R1442     2.6285862922668457e-01
    z[1,5,4]  R1443     2.0473259687423706e-01
    z[1,5,4]  R1444     2.8543433547019958e-01
    z[1,5,4]  R1445     1.7861008644104004e-01
    z[1,5,4]  R1446     3.9897285401821136e-02
    z[1,5,4]  R1447     -1.0376599431037903e-01
    z[1,5,4]  R1448     2.9115831851959229e-01
    z[1,5,4]  R1449     5.5429106950759888e-01
    z[1,5,4]  R1450     -1.4271882176399231e-01
    z[1,5,4]  R1451     -1.6991877555847168e-01
    z[1,5,4]  R1452     -3.5168644785881042e-01
    z[1,5,4]  R1453     -2.1051105856895447e-01
    z[1,5,4]  R1454     1.6175056993961334e-01
    z[1,5,4]  R1455     1.5208730101585388e-01
    z[1,5,4]  R1456     -1.2244738638401031e-01
    z[1,5,4]  R1457     2.9136139154434204e-01
    z[1,5,4]  R1458     8.3066321909427643e-02
    z[1,5,4]  R1459     2.1944449841976166e-01
    z[1,5,4]  R1460     2.4374271929264069e-01
    z[1,5,4]  R1461     2.9229193925857544e-01
    z[1,5,4]  R1462     3.7499007582664490e-01
    z[1,5,4]  R1463     -5.2446460723876953e-01
    z[1,5,4]  R1464     1.5510775148868561e-01
    z[1,5,4]  R1465     -3.1334522366523743e-01
    z[1,5,4]  R1466     0.34656822681427
    z[1,5,4]  R1467     -2.3756182193756104e-01
    z[1,5,4]  R1468     3.7706881761550903e-01
    z[1,5,4]  R1469     -5.1656424999237061e-01
    z[1,5,4]  R1470     -3.3346924185752869e-01
    z[1,5,4]  R1471     2.6950253173708916e-02
    z[1,5,4]  R1472     0.00511670857667923
    z[1,5,4]  R1473     1.8650548160076141e-01
    z[1,5,4]  R1474     4.6590843796730042e-01
    z[1,5,4]  R1475     1.1250261217355728e-01
    z[1,5,4]  R1476     -5.7950061559677124e-01
    z[1,5,4]  R1477     -5.7460999488830566e-01
    z[1,5,4]  R1478     -3.1709730625152588e-01
    z[1,5,4]  R1479     -1.8819181621074677e-01
    z[1,5,4]  R1480     2.0447519421577454e-01
    z[1,5,4]  R1481     1.5613253414630890e-01
    z[1,5,4]  R1482     -1.4564444124698639e-01
    z[1,5,4]  R1483     3.8416441529989243e-02
    z[1,5,4]  R1484     1.7567806644365191e-03
    z[1,5,4]  R1485     2.4478648602962494e-01
    z[1,5,4]  R1486     9.6992768347263336e-02
    z[1,5,4]  R1487     2.1350033581256866e-01
    z[1,5,4]  R1488     -2.7428719401359558e-01
    z[1,5,4]  R1489     6.8304139375686646e-01
    z[1,5,4]  R1490     1.2113102525472641e-01
    z[1,5,4]  R1491     2.5525709614157677e-02
    z[1,5,4]  R1492     -2.7946668863296509e-01
    z[1,5,4]  R1493     2.1172559261322021e-01
    z[1,5,4]  R1494     -1.7210589349269867e-01
    z[1,5,4]  R1495     2.4047857522964478e-01
    z[1,5,4]  R1496     1.0388135910034180e-02
    z[1,5,4]  R1497     2.1524070203304291e-01
    z[1,5,4]  R1498     -3.8811179995536804e-01
    z[1,5,4]  R1499     1.0021328926086426e-01
    z[1,5,4]  R1500     -4.2036247253417969e-01
    z[1,5,4]  R1501     -2.8724148869514465e-01
    z[1,5,4]  R1502     -9.4732575118541718e-02
    z[1,5,4]  R1503     -4.5010432600975037e-01
    z[1,5,4]  R1504     -2.0135407149791718e-01
    z[1,5,4]  R1505     -2.9905600473284721e-02
    z[1,5,4]  R1506     0.159097358584404
    z[1,5,4]  R1507     3.3481064438819885e-01
    z[1,5,4]  R1508     -2.0056806504726410e-01
    z[1,5,4]  R1509     8.6779326200485229e-02
    z[1,5,4]  R1510     1.1984530836343765e-02
    z[1,5,4]  R1511     -0.496004581451416
    z[1,5,4]  R1512     -0.531998336315155
    z[1,5,4]  R1513     -6.1312294006347656e-01
    z[1,5,4]  R1514     -5.4920804500579834e-01
    z[1,5,4]  R1515     1.8354912102222443e-01
    z[1,5,4]  R1516     -0.276263952255249
    z[1,5,4]  R1517     -4.0148639678955078e-01
    z[1,5,4]  R1518     -4.6598100662231445e-01
    z[1,5,4]  R1519     -4.0774139761924744e-01
    z[1,5,4]  R1520     -4.0382185578346252e-01
    z[1,5,4]  R1521     5.0118589401245117e-01
    z[1,5,4]  R1522     2.6180425286293030e-01
    z[1,5,4]  R1523     -0.282550573348999
    z[1,5,4]  R1524     -6.2645196914672852e-02
    z[1,5,4]  R1525     -1.2329094856977463e-01
    z[1,5,4]  R1526     -0.0234454907476902
    z[1,5,4]  R1527     -1.5201459825038910e-01
    z[1,5,4]  R1528     -1.1735180765390396e-01
    z[1,5,4]  R1529     5.4263092577457428e-02
    z[1,5,4]  R1530     1.4913311600685120e-01
    z[1,5,4]  R1531     -2.5151485204696655e-01
    z[1,5,4]  R1532     -5.0076740980148315e-01
    z[1,5,4]  R1533     3.4647189080715179e-02
    z[1,5,4]  R1534     1.5218664705753326e-01
    z[1,5,4]  R1535     -0.0744100883603096
    z[1,5,4]  R1536     -1.8353520333766937e-01
    z[1,5,4]  R1537     1.3839547336101532e-01
    z[1,5,4]  R1538     4.5360937714576721e-02
    z[1,5,4]  R1539     -2.7728980779647827e-01
    z[1,5,4]  R1540     -8.2025587558746338e-02
    z[1,5,4]  R1541     1.3995287939906120e-02
    z[1,5,4]  R1542     1.8421135842800140e-01
    z[1,5,4]  R1543     -1.1290358752012253e-01
    z[1,5,4]  R1544     1.5742288529872894e-01
    z[1,5,4]  R1545     -1.0554249398410320e-02
    z[1,5,4]  R1546     -1.9067689776420593e-01
    z[1,5,4]  R1547     -3.3969292044639587e-01
    z[1,5,4]  R1548     -5.9137541055679321e-01
    z[1,5,4]  R1549     -1.1788047850131989e-01
    z[1,5,4]  R1550     -2.7381590008735657e-01
    z[1,5,4]  R1551     3.5458293557167053e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1438     -1
    z[1,5,5]  R1439     1
    z[1,5,5]  R1442     -6.3787393271923065e-02
    z[1,5,5]  R1443     -4.0692013502120972e-01
    z[1,5,5]  R1444     1.3815888762474060e-01
    z[1,5,5]  R1445     -2.3018175363540649e-01
    z[1,5,5]  R1446     -3.1856033205986023e-01
    z[1,5,5]  R1447     -1.9800245761871338e-01
    z[1,5,5]  R1448     -1.3131687045097351e-01
    z[1,5,5]  R1449     2.0805935561656952e-01
    z[1,5,5]  R1450     -2.8782995417714119e-02
    z[1,5,5]  R1451     1.7422935366630554e-01
    z[1,5,5]  R1452     -1.3307310640811920e-01
    z[1,5,5]  R1453     3.2203185558319092e-01
    z[1,5,5]  R1454     6.9552063941955566e-02
    z[1,5,5]  R1455     1.4325352013111115e-01
    z[1,5,5]  R1456     2.9530632495880127e-01
    z[1,5,5]  R1457     4.1212841868400574e-01
    z[1,5,5]  R1458     5.8570575714111328e-01
    z[1,5,5]  R1459     -4.3115538358688354e-01
    z[1,5,5]  R1460     4.2247429490089417e-01
    z[1,5,5]  R1461     -1.7058970034122467e-01
    z[1,5,5]  R1462     -1.5608721971511841e-01
    z[1,5,5]  R1463     -5.0835871696472168e-01
    z[1,5,5]  R1464     6.9800531864166260e-01
    z[1,5,5]  R1465     2.4462699890136719e-01
    z[1,5,5]  R1466     4.6346226334571838e-01
    z[1,5,5]  R1467     -6.4760148525238037e-01
    z[1,5,5]  R1468     -8.1387633085250854e-01
    z[1,5,5]  R1469     1.3412535190582275e-01
    z[1,5,5]  R1470     2.1217954158782959e-01
    z[1,5,5]  R1471     -1.9284363090991974e-01
    z[1,5,5]  R1472     -5.1182083785533905e-02
    z[1,5,5]  R1473     2.1714878082275391e-01
    z[1,5,5]  R1474     -1.0764618217945099e-01
    z[1,5,5]  R1475     6.0474467277526855e-01
    z[1,5,5]  R1476     0.469120055437088
    z[1,5,5]  R1477     -0.361625075340271
    z[1,5,5]  R1478     -5.3766030073165894e-01
    z[1,5,5]  R1479     -1.6545116901397705e-01
    z[1,5,5]  R1480     1.3289323449134827e-01
    z[1,5,5]  R1481     -9.6647344529628754e-02
    z[1,5,5]  R1482     -6.1933767795562744e-01
    z[1,5,5]  R1483     -6.4784586429595947e-01
    z[1,5,5]  R1484     -3.0371937155723572e-01
    z[1,5,5]  R1485     -5.0053298473358154e-02
    z[1,5,5]  R1486     -3.3766743727028370e-03
    z[1,5,5]  R1487     0.0362824983894825
    z[1,5,5]  R1488     1.8293833732604980e-01
    z[1,5,5]  R1489     -1.8776687979698181e-01
    z[1,5,5]  R1490     -5.7682663202285767e-02
    z[1,5,5]  R1491     -0.0266642477363348
    z[1,5,5]  R1492     3.4906172752380371e-01
    z[1,5,5]  R1493     1.1849937587976456e-01
    z[1,5,5]  R1494     5.4500085115432739e-01
    z[1,5,5]  R1495     2.6853027939796448e-01
    z[1,5,5]  R1496     -3.2048285007476807e-01
    z[1,5,5]  R1497     3.7137782573699951e-01
    z[1,5,5]  R1498     1.8925306200981140e-01
    z[1,5,5]  R1499     2.7644780930131674e-03
    z[1,5,5]  R1500     1.9587117433547974e-01
    z[1,5,5]  R1501     2.6655626296997070e-01
    z[1,5,5]  R1502     6.3775390386581421e-01
    z[1,5,5]  R1503     2.7203616499900818e-01
    z[1,5,5]  R1504     -2.9853606224060059e-01
    z[1,5,5]  R1505     2.7603876590728760e-01
    z[1,5,5]  R1506     -5.6742765009403229e-02
    z[1,5,5]  R1507     1.1412044614553452e-01
    z[1,5,5]  R1508     -5.1465284079313278e-02
    z[1,5,5]  R1509     -1.3932244479656219e-01
    z[1,5,5]  R1510     -2.9125756118446589e-03
    z[1,5,5]  R1511     -2.9701529070734978e-02
    z[1,5,5]  R1512     -3.7494511343538761e-03
    z[1,5,5]  R1513     3.4458752721548080e-02
    z[1,5,5]  R1514     3.0400335788726807e-01
    z[1,5,5]  R1515     5.9104061126708984e-01
    z[1,5,5]  R1516     -0.0534505657851696
    z[1,5,5]  R1517     1.9277544319629669e-01
    z[1,5,5]  R1518     2.4191319942474365e-01
    z[1,5,5]  R1519     5.5073505640029907e-01
    z[1,5,5]  R1520     3.1129565834999084e-01
    z[1,5,5]  R1521     3.4153786301612854e-01
    z[1,5,5]  R1522     3.9113840460777283e-01
    z[1,5,5]  R1523     4.2109638452529907e-01
    z[1,5,5]  R1524     4.3957060575485229e-01
    z[1,5,5]  R1525     1.9891719520092010e-01
    z[1,5,5]  R1526     -5.1018454134464264e-02
    z[1,5,5]  R1527     4.7241061925888062e-01
    z[1,5,5]  R1528     -1.1062230169773102e-01
    z[1,5,5]  R1529     2.1643431484699249e-01
    z[1,5,5]  R1530     4.2171150445938110e-01
    z[1,5,5]  R1531     3.6347669363021851e-01
    z[1,5,5]  R1532     2.6701900362968445e-01
    z[1,5,5]  R1533     -2.6293733716011047e-01
    z[1,5,5]  R1534     -1.1496489495038986e-01
    z[1,5,5]  R1535     0.0418475866317749
    z[1,5,5]  R1536     3.5667872428894043e-01
    z[1,5,5]  R1537     -1.0689385980367661e-01
    z[1,5,5]  R1538     2.3131118714809418e-01
    z[1,5,5]  R1539     2.0413130521774292e-01
    z[1,5,5]  R1540     3.2589516043663025e-01
    z[1,5,5]  R1541     -1.9784484058618546e-02
    z[1,5,5]  R1542     5.9179648756980896e-02
    z[1,5,5]  R1543     7.2134897112846375e-02
    z[1,5,5]  R1544     1.1516427993774414e-01
    z[1,5,5]  R1545     3.3080011606216431e-01
    z[1,5,5]  R1546     4.1496536135673523e-01
    z[1,5,5]  R1547     2.4856556951999664e-01
    z[1,5,5]  R1548     4.6000748872756958e-01
    z[1,5,5]  R1549     -5.1871344447135925e-02
    z[1,5,5]  R1550     3.1858170032501221e-01
    z[1,5,5]  R1551     8.2440860569477081e-02
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1440     -1
    z[1,5,6]  R1441     1
    z[1,5,6]  R1442     -4.6854072809219360e-01
    z[1,5,6]  R1443     -1.8549780547618866e-01
    z[1,5,6]  R1444     -3.2859003543853760e-01
    z[1,5,6]  R1445     -2.7782490849494934e-01
    z[1,5,6]  R1446     -0.0677451640367508
    z[1,5,6]  R1447     1.5936177968978882e-01
    z[1,5,6]  R1448     2.4572479724884033e-01
    z[1,5,6]  R1449     2.4274982511997223e-01
    z[1,5,6]  R1450     3.2023850828409195e-02
    z[1,5,6]  R1451     3.2487708330154419e-01
    z[1,5,6]  R1452     2.5020885467529297e-01
    z[1,5,6]  R1453     -2.3303854465484619e-01
    z[1,5,6]  R1454     2.8261154890060425e-01
    z[1,5,6]  R1455     -1.6217219829559326e-01
    z[1,5,6]  R1456     2.0462350547313690e-01
    z[1,5,6]  R1457     -3.4572128206491470e-02
    z[1,5,6]  R1458     2.4441033601760864e-01
    z[1,5,6]  R1459     1.2077458202838898e-01
    z[1,5,6]  R1460     3.4495350718498230e-01
    z[1,5,6]  R1461     0.470958948135376
    z[1,5,6]  R1462     2.6052755117416382e-01
    z[1,5,6]  R1463     -1.2949370779097080e-02
    z[1,5,6]  R1464     2.4970626831054688e-01
    z[1,5,6]  R1465     5.9450912475585938e-01
    z[1,5,6]  R1466     -5.0955647230148315e-01
    z[1,5,6]  R1467     -1.8352743983268738e-01
    z[1,5,6]  R1468     -1.1067216284573078e-02
    z[1,5,6]  R1469     -1.8066921830177307e-01
    z[1,5,6]  R1470     -6.7055529356002808e-01
    z[1,5,6]  R1471     3.8996872305870056e-01
    z[1,5,6]  R1472     2.6779506355524063e-02
    z[1,5,6]  R1473     1.9074784219264984e-01
    z[1,5,6]  R1474     1.5408596396446228e-01
    z[1,5,6]  R1475     -4.5079058408737183e-01
    z[1,5,6]  R1476     -6.9441363215446472e-02
    z[1,5,6]  R1477     -4.3850109796039760e-04
    z[1,5,6]  R1478     4.8177537322044373e-01
    z[1,5,6]  R1479     -0.126246377825737
    z[1,5,6]  R1480     1.9304960966110229e-01
    z[1,5,6]  R1481     1.7743013799190521e-01
    z[1,5,6]  R1482     -8.8365182280540466e-02
    z[1,5,6]  R1483     -3.9545637369155884e-01
    z[1,5,6]  R1484     5.7798791676759720e-02
    z[1,5,6]  R1485     -1.3976109027862549e-01
    z[1,5,6]  R1486     3.2563191652297974e-01
    z[1,5,6]  R1487     3.4999959170818329e-02
    z[1,5,6]  R1488     1.8482497334480286e-01
    z[1,5,6]  R1489     3.5145051777362823e-02
    z[1,5,6]  R1490     1.9077347218990326e-01
    z[1,5,6]  R1491     -3.4835245460271835e-02
    z[1,5,6]  R1492     -1.4184023439884186e-01
    z[1,5,6]  R1493     -1.6157792508602142e-01
    z[1,5,6]  R1494     1.4025190472602844e-01
    z[1,5,6]  R1495     3.3324298262596130e-01
    z[1,5,6]  R1496     1.6489909589290619e-01
    z[1,5,6]  R1497     -1.6969369351863861e-01
    z[1,5,6]  R1498     4.1545432060956955e-02
    z[1,5,6]  R1499     3.2960101962089539e-01
    z[1,5,6]  R1500     9.5377013087272644e-02
    z[1,5,6]  R1501     3.6477804183959961e-01
    z[1,5,6]  R1502     -3.2919496297836304e-01
    z[1,5,6]  R1503     -1.0445023328065872e-01
    z[1,5,6]  R1504     8.2382082939147949e-02
    z[1,5,6]  R1505     9.5949888229370117e-02
    z[1,5,6]  R1506     3.4505769610404968e-01
    z[1,5,6]  R1507     -5.6673612445592880e-02
    z[1,5,6]  R1508     4.2273110151290894e-01
    z[1,5,6]  R1509     -3.5286897420883179e-01
    z[1,5,6]  R1510     -1.8022920191287994e-01
    z[1,5,6]  R1511     9.2139437794685364e-02
    z[1,5,6]  R1512     5.0284836441278458e-02
    z[1,5,6]  R1513     1.9310359656810760e-01
    z[1,5,6]  R1514     -2.2523060441017151e-01
    z[1,5,6]  R1515     -1.0507960803806782e-02
    z[1,5,6]  R1516     3.3523243665695190e-01
    z[1,5,6]  R1517     0.263115257024765
    z[1,5,6]  R1518     -0.0172833651304245
    z[1,5,6]  R1519     2.6480999588966370e-01
    z[1,5,6]  R1520     -0.0742039605975151
    z[1,5,6]  R1521     2.3711478710174561e-01
    z[1,5,6]  R1522     5.6914114393293858e-03
    z[1,5,6]  R1523     2.4102061986923218e-01
    z[1,5,6]  R1524     -1.9952252507209778e-01
    z[1,5,6]  R1525     6.1366468667984009e-02
    z[1,5,6]  R1526     8.4016129374504089e-02
    z[1,5,6]  R1527     -1.6170255839824677e-01
    z[1,5,6]  R1528     5.7765308767557144e-02
    z[1,5,6]  R1529     3.6379155516624451e-01
    z[1,5,6]  R1530     -1.2155794352293015e-01
    z[1,5,6]  R1531     1.8742622435092926e-01
    z[1,5,6]  R1532     -2.3593294620513916e-01
    z[1,5,6]  R1533     3.0443921685218811e-01
    z[1,5,6]  R1534     -1.3737358152866364e-01
    z[1,5,6]  R1535     1.1643828451633453e-01
    z[1,5,6]  R1536     1.7010244727134705e-01
    z[1,5,6]  R1537     0.232234388589859
    z[1,5,6]  R1538     -5.6208237074315548e-03
    z[1,5,6]  R1539     -2.1610192954540253e-01
    z[1,5,6]  R1540     1.4185032248497009e-01
    z[1,5,6]  R1541     -0.391007661819458
    z[1,5,6]  R1542     -3.9091381430625916e-01
    z[1,5,6]  R1543     -6.0242330655455589e-03
    z[1,5,6]  R1544     1.0224212892353535e-02
    z[1,5,6]  R1545     1.3477612286806107e-02
    z[1,5,6]  R1546     5.7424264959990978e-03
    z[1,5,6]  R1547     -1.5017724037170410e-01
    z[1,5,6]  R1548     -4.2608477175235748e-02
    z[1,5,6]  R1549     -3.2186403870582581e-01
    z[1,5,6]  R1550     -3.1398364901542664e-01
    z[1,5,6]  R1551     0.0945323258638382
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1552     -1
    z[5,1,0]  R1553     1
    z[5,1,0]  R1566     -4.1167184710502625e-01
    z[5,1,0]  R1567     5.2194584161043167e-02
    z[5,1,0]  R1568     -3.3740440011024475e-01
    z[5,1,0]  R1569     1.4051201939582825e-01
    z[5,1,0]  R1570     -1.3101556897163391e-01
    z[5,1,0]  R1571     2.3414593935012817e-01
    z[5,1,0]  R1572     2.6615265011787415e-01
    z[5,1,0]  R1573     -3.8141000270843506e-01
    z[5,1,0]  R1574     -7.2037017345428467e-01
    z[5,1,0]  R1575     -7.2790348529815674e-01
    z[5,1,0]  R1576     5.0193983316421509e-01
    z[5,1,0]  R1577     3.5697630047798157e-01
    z[5,1,0]  R1578     3.1045895814895630e-01
    z[5,1,0]  R1579     3.5617956519126892e-01
    z[5,1,0]  R1580     -0.0835917741060257
    z[5,1,0]  R1581     2.3714382946491241e-01
    z[5,1,0]  R1582     2.6713207364082336e-01
    z[5,1,0]  R1583     1.8173341453075409e-01
    z[5,1,0]  R1584     4.4621476531028748e-01
    z[5,1,0]  R1585     3.1219500303268433e-01
    z[5,1,0]  R1586     -5.0173097848892212e-01
    z[5,1,0]  R1587     6.3865667581558228e-01
    z[5,1,0]  R1588     6.5449148416519165e-02
    z[5,1,0]  R1589     5.2495366334915161e-01
    z[5,1,0]  R1590     3.5497203469276428e-01
    z[5,1,0]  R1591     4.4768762588500977e-01
    z[5,1,0]  R1592     4.9666678905487061e-01
    z[5,1,0]  R1593     6.2237411737442017e-01
    z[5,1,0]  R1594     4.7753170132637024e-01
    z[5,1,0]  R1595     3.4345629811286926e-01
    z[5,1,0]  R1596     -6.0553711652755737e-01
    z[5,1,0]  R1597     1.7541919648647308e-01
    z[5,1,0]  R1598     5.9707891941070557e-01
    z[5,1,0]  R1599     4.7816035151481628e-01
    z[5,1,0]  R1600     4.8107045888900757e-01
    z[5,1,0]  R1601     0.0420943982899189
    z[5,1,0]  R1602     2.2906219959259033e-01
    z[5,1,0]  R1603     3.0979016795754433e-02
    z[5,1,0]  R1604     -1.0578852146863937e-01
    z[5,1,0]  R1605     3.5713267326354980e-01
    z[5,1,0]  R1606     0.481503427028656
    z[5,1,0]  R1607     0.350081205368042
    z[5,1,0]  R1608     4.4970616698265076e-01
    z[5,1,0]  R1609     1.2914520502090454e-01
    z[5,1,0]  R1610     4.7862935066223145e-01
    z[5,1,0]  R1611     -0.0339871309697628
    z[5,1,0]  R1612     2.8752669692039490e-01
    z[5,1,0]  R1613     4.5326313376426697e-01
    z[5,1,0]  R1614     3.3613637089729309e-01
    z[5,1,0]  R1615     2.0278221368789673e-01
    z[5,1,0]  R1616     6.6347676515579224e-01
    z[5,1,0]  R1617     -2.4898461997509003e-01
    z[5,1,0]  R1618     4.6122840046882629e-01
    z[5,1,0]  R1619     4.9284663796424866e-01
    z[5,1,0]  R1620     4.1822734475135803e-01
    z[5,1,0]  R1621     4.8851454257965088e-01
    z[5,1,0]  R1622     3.4320834279060364e-01
    z[5,1,0]  R1623     1.8371088802814484e-01
    z[5,1,0]  R1624     3.1019492074847221e-02
    z[5,1,0]  R1625     7.1308411657810211e-02
    z[5,1,0]  R1626     -3.9650008082389832e-01
    z[5,1,0]  R1627     5.1104658842086792e-01
    z[5,1,0]  R1628     5.1345431804656982e-01
    z[5,1,0]  R1629     9.9075190722942352e-02
    z[5,1,0]  R1630     1.3918174803256989e-01
    z[5,1,0]  R1631     1.0309685766696930e-01
    z[5,1,0]  R1632     1.3891510665416718e-02
    z[5,1,0]  R1633     6.8562909960746765e-02
    z[5,1,0]  R1634     -6.5475896000862122e-02
    z[5,1,0]  R1635     -2.6827117800712585e-01
    z[5,1,0]  R1636     -4.5251451432704926e-02
    z[5,1,0]  R1637     -3.5671177506446838e-01
    z[5,1,0]  R1638     -4.2242676019668579e-02
    z[5,1,0]  R1639     -5.9709161520004272e-01
    z[5,1,0]  R1640     -7.8293181955814362e-02
    z[5,1,0]  R1641     -1.2750937603414059e-02
    z[5,1,0]  R1642     -6.8526011705398560e-01
    z[5,1,0]  R1643     -5.3374101407825947e-03
    z[5,1,0]  R1644     -7.7924764156341553e-01
    z[5,1,0]  R1645     -1.6494253277778625e-01
    z[5,1,0]  R1646     1.0237602144479752e-01
    z[5,1,0]  R1647     -9.1826446354389191e-02
    z[5,1,0]  R1648     -1.0050944983959198e-01
    z[5,1,0]  R1649     -6.5777927637100220e-02
    z[5,1,0]  R1650     -2.2169025242328644e-01
    z[5,1,0]  R1651     2.1646836772561073e-02
    z[5,1,0]  R1652     5.4830335080623627e-02
    z[5,1,0]  R1653     6.3755147159099579e-02
    z[5,1,0]  R1654     -3.9741796255111694e-01
    z[5,1,0]  R1655     1.9783353805541992e-01
    z[5,1,0]  R1656     9.0975388884544373e-02
    z[5,1,0]  R1657     7.3167368769645691e-02
    z[5,1,0]  R1658     2.3548530042171478e-01
    z[5,1,0]  R1659     2.6657110452651978e-01
    z[5,1,0]  R1660     1.6141006350517273e-01
    z[5,1,0]  R1661     -5.9019678831100464e-01
    z[5,1,0]  R1662     2.3474588990211487e-01
    z[5,1,0]  R1663     3.3537900447845459e-01
    z[5,1,0]  R1664     2.8809833526611328e-01
    z[5,1,0]  R1665     2.9013855382800102e-02
    z[5,1,0]  R1666     1.7178709805011749e-01
    z[5,1,0]  R1667     0.073527030646801
    z[5,1,0]  R1668     3.7063896656036377e-01
    z[5,1,0]  R1669     3.3976495265960693e-01
    z[5,1,0]  R1670     3.7903591990470886e-01
    z[5,1,0]  R1671     4.6893391013145447e-01
    z[5,1,0]  R1672     2.6620736718177795e-01
    z[5,1,0]  R1673     5.3020846843719482e-01
    z[5,1,0]  R1674     8.5024207830429077e-01
    z[5,1,0]  R1675     7.7913725376129150e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1554     -1
    z[5,1,1]  R1555     1
    z[5,1,1]  R1566     8.5575813427567482e-03
    z[5,1,1]  R1567     1.4072133600711823e-01
    z[5,1,1]  R1568     -2.6882013678550720e-01
    z[5,1,1]  R1569     -1.2652019038796425e-02
    z[5,1,1]  R1570     3.0407634377479553e-01
    z[5,1,1]  R1571     5.1733434200286865e-01
    z[5,1,1]  R1572     1.8734943866729736e-01
    z[5,1,1]  R1573     1.8706493079662323e-02
    z[5,1,1]  R1574     -6.2197268009185791e-01
    z[5,1,1]  R1575     -6.0173243284225464e-01
    z[5,1,1]  R1576     -0.541064977645874
    z[5,1,1]  R1577     -7.0541268587112427e-01
    z[5,1,1]  R1578     -0.561692476272583
    z[5,1,1]  R1579     -5.9705138206481934e-01
    z[5,1,1]  R1580     8.4480911493301392e-01
    z[5,1,1]  R1581     -2.9515042901039124e-01
    z[5,1,1]  R1582     -5.9425985813140869e-01
    z[5,1,1]  R1583     7.0331460237503052e-01
    z[5,1,1]  R1584     5.4043614864349365e-01
    z[5,1,1]  R1585     -4.5522215962409973e-01
    z[5,1,1]  R1586     -4.3140354752540588e-01
    z[5,1,1]  R1587     3.7732613086700439e-01
    z[5,1,1]  R1588     8.4820365905761719e-01
    z[5,1,1]  R1589     6.9910007715225220e-01
    z[5,1,1]  R1590     6.6943019628524780e-01
    z[5,1,1]  R1591     0.597454845905304
    z[5,1,1]  R1592     6.0251086950302124e-01
    z[5,1,1]  R1593     5.7777369022369385e-01
    z[5,1,1]  R1594     6.0641765594482422e-01
    z[5,1,1]  R1595     0.650162935256958
    z[5,1,1]  R1596     -5.0807815790176392e-01
    z[5,1,1]  R1597     5.8061248064041138e-01
    z[5,1,1]  R1598     -1.7243736982345581e-01
    z[5,1,1]  R1599     -5.6971997022628784e-01
    z[5,1,1]  R1600     -5.5164480209350586e-01
    z[5,1,1]  R1601     -4.0834445506334305e-02
    z[5,1,1]  R1602     1.3132227957248688e-01
    z[5,1,1]  R1603     -5.1098912954330444e-02
    z[5,1,1]  R1604     2.9433953762054443e-01
    z[5,1,1]  R1605     -2.1766616404056549e-01
    z[5,1,1]  R1606     -5.3306269645690918e-01
    z[5,1,1]  R1607     -3.5644170641899109e-01
    z[5,1,1]  R1608     -3.5504448413848877e-01
    z[5,1,1]  R1609     -5.8893674612045288e-01
    z[5,1,1]  R1610     -4.9673485755920410e-01
    z[5,1,1]  R1611     1.1629262566566467e-01
    z[5,1,1]  R1612     -4.4587850570678711e-01
    z[5,1,1]  R1613     -1.3600496947765350e-01
    z[5,1,1]  R1614     -5.9690237045288086e-01
    z[5,1,1]  R1615     7.1867331862449646e-02
    z[5,1,1]  R1616     2.4152347818017006e-02
    z[5,1,1]  R1617     8.4414738416671753e-01
    z[5,1,1]  R1618     0.718745231628418
    z[5,1,1]  R1619     -4.8123809695243835e-01
    z[5,1,1]  R1620     -3.2860276103019714e-01
    z[5,1,1]  R1621     -6.6047638654708862e-01
    z[5,1,1]  R1622     -1.4736685156822205e-01
    z[5,1,1]  R1623     2.6722899079322815e-01
    z[5,1,1]  R1624     -3.5031118988990784e-01
    z[5,1,1]  R1625     -0.500552237033844
    z[5,1,1]  R1626     -3.4786400198936462e-01
    z[5,1,1]  R1627     -5.2081096172332764e-01
    z[5,1,1]  R1628     -5.9718823432922363e-01
    z[5,1,1]  R1629     -5.9593987464904785e-01
    z[5,1,1]  R1630     -3.3485185354948044e-02
    z[5,1,1]  R1631     2.0150625705718994e-01
    z[5,1,1]  R1632     4.2572334408760071e-02
    z[5,1,1]  R1633     -0.365588903427124
    z[5,1,1]  R1634     1.8889233469963074e-02
    z[5,1,1]  R1635     1.7349785566329956e-01
    z[5,1,1]  R1636     -4.1153582930564880e-01
    z[5,1,1]  R1637     0.573833703994751
    z[5,1,1]  R1638     -0.366733580827713
    z[5,1,1]  R1639     2.7760806679725647e-01
    z[5,1,1]  R1640     -4.9850201606750488e-01
    z[5,1,1]  R1641     -0.262656033039093
    z[5,1,1]  R1642     3.9246013760566711e-01
    z[5,1,1]  R1643     -2.8604340553283691e-01
    z[5,1,1]  R1644     1.2124329805374146e-01
    z[5,1,1]  R1645     5.4653489589691162e-01
    z[5,1,1]  R1646     -7.8913533687591553e-01
    z[5,1,1]  R1647     -7.8548103570938110e-01
    z[5,1,1]  R1648     -7.8021126985549927e-01
    z[5,1,1]  R1649     -7.6294887065887451e-01
    z[5,1,1]  R1650     -7.4078255891799927e-01
    z[5,1,1]  R1651     -7.4767166376113892e-01
    z[5,1,1]  R1652     -6.2841165065765381e-01
    z[5,1,1]  R1653     -7.1363770961761475e-01
    z[5,1,1]  R1654     -6.6738867759704590e-01
    z[5,1,1]  R1655     -5.4265409708023071e-01
    z[5,1,1]  R1656     -8.6383581161499023e-01
    z[5,1,1]  R1657     -4.6129563450813293e-01
    z[5,1,1]  R1658     -5.1387935876846313e-01
    z[5,1,1]  R1659     -4.2744708061218262e-01
    z[5,1,1]  R1660     -0.583754301071167
    z[5,1,1]  R1661     1.9236426055431366e-01
    z[5,1,1]  R1662     -3.0478119850158691e-01
    z[5,1,1]  R1663     -4.9917593598365784e-01
    z[5,1,1]  R1664     -5.3909343481063843e-01
    z[5,1,1]  R1665     5.0474762916564941e-01
    z[5,1,1]  R1666     -5.4632717370986938e-01
    z[5,1,1]  R1667     -5.4762643575668335e-01
    z[5,1,1]  R1668     -1.4396350085735321e-01
    z[5,1,1]  R1669     -2.5115618109703064e-01
    z[5,1,1]  R1670     -4.8610472679138184e-01
    z[5,1,1]  R1671     4.6591964364051819e-01
    z[5,1,1]  R1672     5.2314704656600952e-01
    z[5,1,1]  R1673     4.5538052916526794e-01
    z[5,1,1]  R1674     3.7054851651191711e-01
    z[5,1,1]  R1675     3.2702940702438354e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1556     -1
    z[5,1,2]  R1557     1
    z[5,1,2]  R1566     -2.5082439184188843e-01
    z[5,1,2]  R1567     -4.9486222863197327e-01
    z[5,1,2]  R1568     -8.3715015649795532e-01
    z[5,1,2]  R1569     -6.9883072376251221e-01
    z[5,1,2]  R1570     -8.6587077379226685e-01
    z[5,1,2]  R1571     -4.6348148584365845e-01
    z[5,1,2]  R1572     -0.835545003414154
    z[5,1,2]  R1573     -3.9633882045745850e-01
    z[5,1,2]  R1574     1.9898726046085358e-01
    z[5,1,2]  R1575     3.1680113077163696e-01
    z[5,1,2]  R1576     4.7050195932388306e-01
    z[5,1,2]  R1577     5.2155035734176636e-01
    z[5,1,2]  R1578     4.4924122095108032e-01
    z[5,1,2]  R1579     5.2330291271209717e-01
    z[5,1,2]  R1580     2.3753516376018524e-01
    z[5,1,2]  R1581     0.685438334941864
    z[5,1,2]  R1582     4.8933586478233337e-01
    z[5,1,2]  R1583     3.0118945240974426e-01
    z[5,1,2]  R1584     3.3472895622253418e-01
    z[5,1,2]  R1585     0.550088107585907
    z[5,1,2]  R1586     -1.4015612006187439e-01
    z[5,1,2]  R1587     3.8528403639793396e-01
    z[5,1,2]  R1588     3.6292123794555664e-01
    z[5,1,2]  R1589     1.1737194657325745e-01
    z[5,1,2]  R1590     1.4842732250690460e-01
    z[5,1,2]  R1591     2.1074037998914719e-02
    z[5,1,2]  R1592     1.3993789255619049e-01
    z[5,1,2]  R1593     1.3967829942703247e-01
    z[5,1,2]  R1594     5.2091282606124878e-01
    z[5,1,2]  R1595     2.3172754049301147e-01
    z[5,1,2]  R1596     0.0881069228053093
    z[5,1,2]  R1597     3.4890773892402649e-01
    z[5,1,2]  R1598     9.3202881515026093e-02
    z[5,1,2]  R1599     2.4517005681991577e-01
    z[5,1,2]  R1600     3.7510260939598083e-01
    z[5,1,2]  R1601     -1.1677806824445724e-01
    z[5,1,2]  R1602     1.2375617772340775e-01
    z[5,1,2]  R1603     1.3580541312694550e-01
    z[5,1,2]  R1604     -4.8568150959908962e-03
    z[5,1,2]  R1605     4.2193382978439331e-01
    z[5,1,2]  R1606     5.0784224271774292e-01
    z[5,1,2]  R1607     6.4672106504440308e-01
    z[5,1,2]  R1608     4.5124414563179016e-01
    z[5,1,2]  R1609     7.5461500883102417e-01
    z[5,1,2]  R1610     4.1927462816238403e-01
    z[5,1,2]  R1611     -1.3850663602352142e-01
    z[5,1,2]  R1612     6.0157597064971924e-01
    z[5,1,2]  R1613     7.0908397436141968e-01
    z[5,1,2]  R1614     2.0411163568496704e-01
    z[5,1,2]  R1615     0.0621710866689682
    z[5,1,2]  R1616     1.0683589428663254e-01
    z[5,1,2]  R1617     2.4507471919059753e-01
    z[5,1,2]  R1618     -0.00966144260019064
    z[5,1,2]  R1619     5.8281403779983521e-01
    z[5,1,2]  R1620     5.8617675304412842e-01
    z[5,1,2]  R1621     4.8749116063117981e-01
    z[5,1,2]  R1622     8.3031928539276123e-01
    z[5,1,2]  R1623     6.2518283724784851e-02
    z[5,1,2]  R1624     -2.0371995866298676e-01
    z[5,1,2]  R1625     7.6282203197479248e-01
    z[5,1,2]  R1626     9.7577020525932312e-02
    z[5,1,2]  R1627     6.3724607229232788e-01
    z[5,1,2]  R1628     0.546921968460083
    z[5,1,2]  R1629     7.2423154115676880e-01
    z[5,1,2]  R1630     -2.3010337352752686e-01
    z[5,1,2]  R1631     2.2679027169942856e-02
    z[5,1,2]  R1632     1.8637599050998688e-01
    z[5,1,2]  R1633     8.1958460807800293e-01
    z[5,1,2]  R1634     3.5175395011901855e-01
    z[5,1,2]  R1635     0.812131404876709
    z[5,1,2]  R1636     5.0443840026855469e-01
    z[5,1,2]  R1637     -4.9243211746215820e-01
    z[5,1,2]  R1638     1.2689022719860077e-01
    z[5,1,2]  R1639     -0.626781165599823
    z[5,1,2]  R1640     7.9153716564178467e-01
    z[5,1,2]  R1641     7.2913813591003418e-01
    z[5,1,2]  R1642     -4.3528309464454651e-01
    z[5,1,2]  R1643     3.0553472042083740e-01
    z[5,1,2]  R1644     -5.4495644569396973e-01
    z[5,1,2]  R1645     -7.0033740997314453e-01
    z[5,1,2]  R1646     -3.6397790908813477e-01
    z[5,1,2]  R1647     -2.8767114877700806e-01
    z[5,1,2]  R1648     -3.3676931262016296e-01
    z[5,1,2]  R1649     -3.1985855102539062e-01
    z[5,1,2]  R1650     -2.3950286209583282e-01
    z[5,1,2]  R1651     -1.2533517181873322e-01
    z[5,1,2]  R1652     1.7164391279220581e-01
    z[5,1,2]  R1653     -2.3216864466667175e-01
    z[5,1,2]  R1654     1.0192343033850193e-03
    z[5,1,2]  R1655     9.2219136655330658e-02
    z[5,1,2]  R1656     1.1176556348800659e-01
    z[5,1,2]  R1657     3.0754688382148743e-01
    z[5,1,2]  R1658     0.3104248046875
    z[5,1,2]  R1659     4.3009561300277710e-01
    z[5,1,2]  R1660     -1.9003529846668243e-01
    z[5,1,2]  R1661     -3.1999304890632629e-01
    z[5,1,2]  R1662     5.9365980327129364e-02
    z[5,1,2]  R1663     5.3292375802993774e-01
    z[5,1,2]  R1664     1.1547703295946121e-01
    z[5,1,2]  R1665     3.5850954055786133e-01
    z[5,1,2]  R1666     1.8182796239852905e-01
    z[5,1,2]  R1667     5.6437408924102783e-01
    z[5,1,2]  R1668     7.5032621622085571e-01
    z[5,1,2]  R1669     1.2528024613857269e-01
    z[5,1,2]  R1670     2.2773987054824829e-01
    z[5,1,2]  R1671     2.6856359094381332e-02
    z[5,1,2]  R1672     1.8239600956439972e-01
    z[5,1,2]  R1673     2.3532277345657349e-01
    z[5,1,2]  R1674     1.6897714138031006e-01
    z[5,1,2]  R1675     6.8543985486030579e-02
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1558     -1
    z[5,1,3]  R1559     1
    z[5,1,3]  R1566     5.9576869010925293e-01
    z[5,1,3]  R1567     3.9372414350509644e-01
    z[5,1,3]  R1568     1.3222867250442505e-01
    z[5,1,3]  R1569     6.4013522863388062e-01
    z[5,1,3]  R1570     1.5869811177253723e-01
    z[5,1,3]  R1571     6.4389592409133911e-01
    z[5,1,3]  R1572     2.3036353290081024e-01
    z[5,1,3]  R1573     4.4051659107208252e-01
    z[5,1,3]  R1574     1.5037453733384609e-02
    z[5,1,3]  R1575     7.1662895381450653e-02
    z[5,1,3]  R1576     -1.1776566505432129e-01
    z[5,1,3]  R1577     -1.3404813408851624e-01
    z[5,1,3]  R1578     -1.9995562732219696e-01
    z[5,1,3]  R1579     -4.2782168835401535e-02
    z[5,1,3]  R1580     -3.0475902557373047e-01
    z[5,1,3]  R1581     -4.1686594486236572e-01
    z[5,1,3]  R1582     -3.8454201817512512e-01
    z[5,1,3]  R1583     -5.1275640726089478e-01
    z[5,1,3]  R1584     -4.1546443104743958e-01
    z[5,1,3]  R1585     -3.2571017742156982e-01
    z[5,1,3]  R1586     -1.3579273223876953e-01
    z[5,1,3]  R1587     1.1743741482496262e-01
    z[5,1,3]  R1588     -9.0006791055202484e-02
    z[5,1,3]  R1589     -3.6825048923492432e-01
    z[5,1,3]  R1590     -5.0619250535964966e-01
    z[5,1,3]  R1591     -5.6021952629089355e-01
    z[5,1,3]  R1592     -3.8618949055671692e-01
    z[5,1,3]  R1593     -3.2842054963111877e-01
    z[5,1,3]  R1594     -3.1660124659538269e-01
    z[5,1,3]  R1595     -3.8760277628898621e-01
    z[5,1,3]  R1596     -2.8610104322433472e-01
    z[5,1,3]  R1597     3.0981364846229553e-01
    z[5,1,3]  R1598     4.0037342905998230e-01
    z[5,1,3]  R1599     -5.9528566896915436e-02
    z[5,1,3]  R1600     -3.6331480741500854e-01
    z[5,1,3]  R1601     -8.4577780961990356e-01
    z[5,1,3]  R1602     -7.9938125610351562e-01
    z[5,1,3]  R1603     -0.662041962146759
    z[5,1,3]  R1604     -0.797913670539856
    z[5,1,3]  R1605     -4.7221881151199341e-01
    z[5,1,3]  R1606     -6.7318767309188843e-02
    z[5,1,3]  R1607     -1.2998647987842560e-01
    z[5,1,3]  R1608     -4.8076048493385315e-01
    z[5,1,3]  R1609     9.2176847159862518e-02
    z[5,1,3]  R1610     -5.8152031898498535e-01
    z[5,1,3]  R1611     -8.3289182186126709e-01
    z[5,1,3]  R1612     -5.7208532094955444e-01
    z[5,1,3]  R1613     -3.0186501145362854e-01
    z[5,1,3]  R1614     -5.2364188432693481e-01
    z[5,1,3]  R1615     -8.4814244508743286e-01
    z[5,1,3]  R1616     4.1239511966705322e-01
    z[5,1,3]  R1617     -4.8379480838775635e-02
    z[5,1,3]  R1618     -4.6403801441192627e-01
    z[5,1,3]  R1619     -4.0619453787803650e-01
    z[5,1,3]  R1620     -4.2855963110923767e-01
    z[5,1,3]  R1621     5.4446242749691010e-02
    z[5,1,3]  R1622     -3.3980420231819153e-01
    z[5,1,3]  R1623     -0.851863443851471
    z[5,1,3]  R1624     -8.3771157264709473e-01
    z[5,1,3]  R1625     -9.4819359481334686e-02
    z[5,1,3]  R1626     -0.722500741481781
    z[5,1,3]  R1627     -2.0860888063907623e-01
    z[5,1,3]  R1628     -2.0605309307575226e-01
    z[5,1,3]  R1629     2.8400283306837082e-02
    z[5,1,3]  R1630     -0.847332775592804
    z[5,1,3]  R1631     -8.6517196893692017e-01
    z[5,1,3]  R1632     -6.3254356384277344e-01
    z[5,1,3]  R1633     -2.6408711075782776e-01
    z[5,1,3]  R1634     -7.7237951755523682e-01
    z[5,1,3]  R1635     3.1130319833755493e-01
    z[5,1,3]  R1636     5.3050768375396729e-01
    z[5,1,3]  R1637     2.4304993450641632e-01
    z[5,1,3]  R1638     0.799430251121521
    z[5,1,3]  R1639     1.0718559473752975e-01
    z[5,1,3]  R1640     1.0570231825113297e-01
    z[5,1,3]  R1641     5.6906795501708984e-01
    z[5,1,3]  R1642     1.5660229325294495e-01
    z[5,1,3]  R1643     6.4447224140167236e-01
    z[5,1,3]  R1644     2.4263779819011688e-01
    z[5,1,3]  R1645     1.3728702068328857e-01
    z[5,1,3]  R1646     0.174093097448349
    z[5,1,3]  R1647     -2.9917600750923157e-01
    z[5,1,3]  R1648     -3.9608660340309143e-01
    z[5,1,3]  R1649     -4.9124431610107422e-01
    z[5,1,3]  R1650     -4.4795447587966919e-01
    z[5,1,3]  R1651     -4.1094160079956055e-01
    z[5,1,3]  R1652     -4.0366217494010925e-01
    z[5,1,3]  R1653     -4.2908832430839539e-01
    z[5,1,3]  R1654     -1.9940476119518280e-01
    z[5,1,3]  R1655     -5.6705063581466675e-01
    z[5,1,3]  R1656     1.2812471017241478e-02
    z[5,1,3]  R1657     3.9192914962768555e-01
    z[5,1,3]  R1658     -1.0241139680147171e-01
    z[5,1,3]  R1659     -2.2310981154441833e-01
    z[5,1,3]  R1660     -5.0097241997718811e-02
    z[5,1,3]  R1661     5.2560776472091675e-02
    z[5,1,3]  R1662     2.0923748612403870e-01
    z[5,1,3]  R1663     1.9200769066810608e-01
    z[5,1,3]  R1664     8.4713473916053772e-02
    z[5,1,3]  R1665     6.5258580446243286e-01
    z[5,1,3]  R1666     7.9723989963531494e-01
    z[5,1,3]  R1667     5.0779759883880615e-01
    z[5,1,3]  R1668     1.6282172501087189e-01
    z[5,1,3]  R1669     4.7349786758422852e-01
    z[5,1,3]  R1670     8.6323969066143036e-02
    z[5,1,3]  R1671     3.1835392117500305e-01
    z[5,1,3]  R1672     -2.1111611276865005e-02
    z[5,1,3]  R1673     6.1433070898056030e-01
    z[5,1,3]  R1674     -1.2037465721368790e-01
    z[5,1,3]  R1675     -4.6486461162567139e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1560     -1
    z[5,1,4]  R1561     1
    z[5,1,4]  R1566     -1.4564444124698639e-01
    z[5,1,4]  R1567     3.8416441529989243e-02
    z[5,1,4]  R1568     1.7567806644365191e-03
    z[5,1,4]  R1569     2.4478648602962494e-01
    z[5,1,4]  R1570     9.6992768347263336e-02
    z[5,1,4]  R1571     2.1350033581256866e-01
    z[5,1,4]  R1572     -2.7428719401359558e-01
    z[5,1,4]  R1573     6.8304139375686646e-01
    z[5,1,4]  R1574     1.2113102525472641e-01
    z[5,1,4]  R1575     2.5525709614157677e-02
    z[5,1,4]  R1576     -2.7946668863296509e-01
    z[5,1,4]  R1577     2.1172559261322021e-01
    z[5,1,4]  R1578     -1.7210589349269867e-01
    z[5,1,4]  R1579     2.4047857522964478e-01
    z[5,1,4]  R1580     1.0388135910034180e-02
    z[5,1,4]  R1581     2.1524070203304291e-01
    z[5,1,4]  R1582     -3.8811179995536804e-01
    z[5,1,4]  R1583     1.0021328926086426e-01
    z[5,1,4]  R1584     -4.2036247253417969e-01
    z[5,1,4]  R1585     -2.8724148869514465e-01
    z[5,1,4]  R1586     -9.4732575118541718e-02
    z[5,1,4]  R1587     -4.5010432600975037e-01
    z[5,1,4]  R1588     -2.0135407149791718e-01
    z[5,1,4]  R1589     -2.9905600473284721e-02
    z[5,1,4]  R1590     0.159097358584404
    z[5,1,4]  R1591     3.3481064438819885e-01
    z[5,1,4]  R1592     -2.0056806504726410e-01
    z[5,1,4]  R1593     8.6779326200485229e-02
    z[5,1,4]  R1594     1.1984530836343765e-02
    z[5,1,4]  R1595     -0.496004581451416
    z[5,1,4]  R1596     -0.531998336315155
    z[5,1,4]  R1597     -6.1312294006347656e-01
    z[5,1,4]  R1598     -5.4920804500579834e-01
    z[5,1,4]  R1599     1.8354912102222443e-01
    z[5,1,4]  R1600     -0.276263952255249
    z[5,1,4]  R1601     -4.0148639678955078e-01
    z[5,1,4]  R1602     -4.6598100662231445e-01
    z[5,1,4]  R1603     -4.0774139761924744e-01
    z[5,1,4]  R1604     -4.0382185578346252e-01
    z[5,1,4]  R1605     5.0118589401245117e-01
    z[5,1,4]  R1606     2.6180425286293030e-01
    z[5,1,4]  R1607     -0.282550573348999
    z[5,1,4]  R1608     -6.2645196914672852e-02
    z[5,1,4]  R1609     -1.2329094856977463e-01
    z[5,1,4]  R1610     -0.0234454907476902
    z[5,1,4]  R1611     -1.5201459825038910e-01
    z[5,1,4]  R1612     -1.1735180765390396e-01
    z[5,1,4]  R1613     5.4263092577457428e-02
    z[5,1,4]  R1614     1.4913311600685120e-01
    z[5,1,4]  R1615     -2.5151485204696655e-01
    z[5,1,4]  R1616     -5.0076740980148315e-01
    z[5,1,4]  R1617     3.4647189080715179e-02
    z[5,1,4]  R1618     1.5218664705753326e-01
    z[5,1,4]  R1619     -0.0744100883603096
    z[5,1,4]  R1620     -1.8353520333766937e-01
    z[5,1,4]  R1621     1.3839547336101532e-01
    z[5,1,4]  R1622     4.5360937714576721e-02
    z[5,1,4]  R1623     -2.7728980779647827e-01
    z[5,1,4]  R1624     -8.2025587558746338e-02
    z[5,1,4]  R1625     1.3995287939906120e-02
    z[5,1,4]  R1626     1.8421135842800140e-01
    z[5,1,4]  R1627     -1.1290358752012253e-01
    z[5,1,4]  R1628     1.5742288529872894e-01
    z[5,1,4]  R1629     -1.0554249398410320e-02
    z[5,1,4]  R1630     -1.9067689776420593e-01
    z[5,1,4]  R1631     -3.3969292044639587e-01
    z[5,1,4]  R1632     -5.9137541055679321e-01
    z[5,1,4]  R1633     -1.1788047850131989e-01
    z[5,1,4]  R1634     -2.7381590008735657e-01
    z[5,1,4]  R1635     3.5458293557167053e-01
    z[5,1,4]  R1636     2.6285862922668457e-01
    z[5,1,4]  R1637     2.0473259687423706e-01
    z[5,1,4]  R1638     2.8543433547019958e-01
    z[5,1,4]  R1639     1.7861008644104004e-01
    z[5,1,4]  R1640     3.9897285401821136e-02
    z[5,1,4]  R1641     -1.0376599431037903e-01
    z[5,1,4]  R1642     2.9115831851959229e-01
    z[5,1,4]  R1643     5.5429106950759888e-01
    z[5,1,4]  R1644     -1.4271882176399231e-01
    z[5,1,4]  R1645     -1.6991877555847168e-01
    z[5,1,4]  R1646     -3.5168644785881042e-01
    z[5,1,4]  R1647     -2.1051105856895447e-01
    z[5,1,4]  R1648     1.6175056993961334e-01
    z[5,1,4]  R1649     1.5208730101585388e-01
    z[5,1,4]  R1650     -1.2244738638401031e-01
    z[5,1,4]  R1651     2.9136139154434204e-01
    z[5,1,4]  R1652     8.3066321909427643e-02
    z[5,1,4]  R1653     2.1944449841976166e-01
    z[5,1,4]  R1654     2.4374271929264069e-01
    z[5,1,4]  R1655     2.9229193925857544e-01
    z[5,1,4]  R1656     3.7499007582664490e-01
    z[5,1,4]  R1657     -5.2446460723876953e-01
    z[5,1,4]  R1658     1.5510775148868561e-01
    z[5,1,4]  R1659     -3.1334522366523743e-01
    z[5,1,4]  R1660     0.34656822681427
    z[5,1,4]  R1661     -2.3756182193756104e-01
    z[5,1,4]  R1662     3.7706881761550903e-01
    z[5,1,4]  R1663     -5.1656424999237061e-01
    z[5,1,4]  R1664     -3.3346924185752869e-01
    z[5,1,4]  R1665     2.6950253173708916e-02
    z[5,1,4]  R1666     0.00511670857667923
    z[5,1,4]  R1667     1.8650548160076141e-01
    z[5,1,4]  R1668     4.6590843796730042e-01
    z[5,1,4]  R1669     1.1250261217355728e-01
    z[5,1,4]  R1670     -5.7950061559677124e-01
    z[5,1,4]  R1671     -5.7460999488830566e-01
    z[5,1,4]  R1672     -3.1709730625152588e-01
    z[5,1,4]  R1673     -1.8819181621074677e-01
    z[5,1,4]  R1674     2.0447519421577454e-01
    z[5,1,4]  R1675     1.5613253414630890e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1562     -1
    z[5,1,5]  R1563     1
    z[5,1,5]  R1566     -6.1933767795562744e-01
    z[5,1,5]  R1567     -6.4784586429595947e-01
    z[5,1,5]  R1568     -3.0371937155723572e-01
    z[5,1,5]  R1569     -5.0053298473358154e-02
    z[5,1,5]  R1570     -3.3766743727028370e-03
    z[5,1,5]  R1571     0.0362824983894825
    z[5,1,5]  R1572     1.8293833732604980e-01
    z[5,1,5]  R1573     -1.8776687979698181e-01
    z[5,1,5]  R1574     -5.7682663202285767e-02
    z[5,1,5]  R1575     -0.0266642477363348
    z[5,1,5]  R1576     3.4906172752380371e-01
    z[5,1,5]  R1577     1.1849937587976456e-01
    z[5,1,5]  R1578     5.4500085115432739e-01
    z[5,1,5]  R1579     2.6853027939796448e-01
    z[5,1,5]  R1580     -3.2048285007476807e-01
    z[5,1,5]  R1581     3.7137782573699951e-01
    z[5,1,5]  R1582     1.8925306200981140e-01
    z[5,1,5]  R1583     2.7644780930131674e-03
    z[5,1,5]  R1584     1.9587117433547974e-01
    z[5,1,5]  R1585     2.6655626296997070e-01
    z[5,1,5]  R1586     6.3775390386581421e-01
    z[5,1,5]  R1587     2.7203616499900818e-01
    z[5,1,5]  R1588     -2.9853606224060059e-01
    z[5,1,5]  R1589     2.7603876590728760e-01
    z[5,1,5]  R1590     -5.6742765009403229e-02
    z[5,1,5]  R1591     1.1412044614553452e-01
    z[5,1,5]  R1592     -5.1465284079313278e-02
    z[5,1,5]  R1593     -1.3932244479656219e-01
    z[5,1,5]  R1594     -2.9125756118446589e-03
    z[5,1,5]  R1595     -2.9701529070734978e-02
    z[5,1,5]  R1596     -3.7494511343538761e-03
    z[5,1,5]  R1597     3.4458752721548080e-02
    z[5,1,5]  R1598     3.0400335788726807e-01
    z[5,1,5]  R1599     5.9104061126708984e-01
    z[5,1,5]  R1600     -0.0534505657851696
    z[5,1,5]  R1601     1.9277544319629669e-01
    z[5,1,5]  R1602     2.4191319942474365e-01
    z[5,1,5]  R1603     5.5073505640029907e-01
    z[5,1,5]  R1604     3.1129565834999084e-01
    z[5,1,5]  R1605     3.4153786301612854e-01
    z[5,1,5]  R1606     3.9113840460777283e-01
    z[5,1,5]  R1607     4.2109638452529907e-01
    z[5,1,5]  R1608     4.3957060575485229e-01
    z[5,1,5]  R1609     1.9891719520092010e-01
    z[5,1,5]  R1610     -5.1018454134464264e-02
    z[5,1,5]  R1611     4.7241061925888062e-01
    z[5,1,5]  R1612     -1.1062230169773102e-01
    z[5,1,5]  R1613     2.1643431484699249e-01
    z[5,1,5]  R1614     4.2171150445938110e-01
    z[5,1,5]  R1615     3.6347669363021851e-01
    z[5,1,5]  R1616     2.6701900362968445e-01
    z[5,1,5]  R1617     -2.6293733716011047e-01
    z[5,1,5]  R1618     -1.1496489495038986e-01
    z[5,1,5]  R1619     0.0418475866317749
    z[5,1,5]  R1620     3.5667872428894043e-01
    z[5,1,5]  R1621     -1.0689385980367661e-01
    z[5,1,5]  R1622     2.3131118714809418e-01
    z[5,1,5]  R1623     2.0413130521774292e-01
    z[5,1,5]  R1624     3.2589516043663025e-01
    z[5,1,5]  R1625     -1.9784484058618546e-02
    z[5,1,5]  R1626     5.9179648756980896e-02
    z[5,1,5]  R1627     7.2134897112846375e-02
    z[5,1,5]  R1628     1.1516427993774414e-01
    z[5,1,5]  R1629     3.3080011606216431e-01
    z[5,1,5]  R1630     4.1496536135673523e-01
    z[5,1,5]  R1631     2.4856556951999664e-01
    z[5,1,5]  R1632     4.6000748872756958e-01
    z[5,1,5]  R1633     -5.1871344447135925e-02
    z[5,1,5]  R1634     3.1858170032501221e-01
    z[5,1,5]  R1635     8.2440860569477081e-02
    z[5,1,5]  R1636     -6.3787393271923065e-02
    z[5,1,5]  R1637     -4.0692013502120972e-01
    z[5,1,5]  R1638     1.3815888762474060e-01
    z[5,1,5]  R1639     -2.3018175363540649e-01
    z[5,1,5]  R1640     -3.1856033205986023e-01
    z[5,1,5]  R1641     -1.9800245761871338e-01
    z[5,1,5]  R1642     -1.3131687045097351e-01
    z[5,1,5]  R1643     2.0805935561656952e-01
    z[5,1,5]  R1644     -2.8782995417714119e-02
    z[5,1,5]  R1645     1.7422935366630554e-01
    z[5,1,5]  R1646     -1.3307310640811920e-01
    z[5,1,5]  R1647     3.2203185558319092e-01
    z[5,1,5]  R1648     6.9552063941955566e-02
    z[5,1,5]  R1649     1.4325352013111115e-01
    z[5,1,5]  R1650     2.9530632495880127e-01
    z[5,1,5]  R1651     4.1212841868400574e-01
    z[5,1,5]  R1652     5.8570575714111328e-01
    z[5,1,5]  R1653     -4.3115538358688354e-01
    z[5,1,5]  R1654     4.2247429490089417e-01
    z[5,1,5]  R1655     -1.7058970034122467e-01
    z[5,1,5]  R1656     -1.5608721971511841e-01
    z[5,1,5]  R1657     -5.0835871696472168e-01
    z[5,1,5]  R1658     6.9800531864166260e-01
    z[5,1,5]  R1659     2.4462699890136719e-01
    z[5,1,5]  R1660     4.6346226334571838e-01
    z[5,1,5]  R1661     -6.4760148525238037e-01
    z[5,1,5]  R1662     -8.1387633085250854e-01
    z[5,1,5]  R1663     1.3412535190582275e-01
    z[5,1,5]  R1664     2.1217954158782959e-01
    z[5,1,5]  R1665     -1.9284363090991974e-01
    z[5,1,5]  R1666     -5.1182083785533905e-02
    z[5,1,5]  R1667     2.1714878082275391e-01
    z[5,1,5]  R1668     -1.0764618217945099e-01
    z[5,1,5]  R1669     6.0474467277526855e-01
    z[5,1,5]  R1670     0.469120055437088
    z[5,1,5]  R1671     -0.361625075340271
    z[5,1,5]  R1672     -5.3766030073165894e-01
    z[5,1,5]  R1673     -1.6545116901397705e-01
    z[5,1,5]  R1674     1.3289323449134827e-01
    z[5,1,5]  R1675     -9.6647344529628754e-02
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1564     -1
    z[5,1,6]  R1565     1
    z[5,1,6]  R1566     -8.8365182280540466e-02
    z[5,1,6]  R1567     -3.9545637369155884e-01
    z[5,1,6]  R1568     5.7798791676759720e-02
    z[5,1,6]  R1569     -1.3976109027862549e-01
    z[5,1,6]  R1570     3.2563191652297974e-01
    z[5,1,6]  R1571     3.4999959170818329e-02
    z[5,1,6]  R1572     1.8482497334480286e-01
    z[5,1,6]  R1573     3.5145051777362823e-02
    z[5,1,6]  R1574     1.9077347218990326e-01
    z[5,1,6]  R1575     -3.4835245460271835e-02
    z[5,1,6]  R1576     -1.4184023439884186e-01
    z[5,1,6]  R1577     -1.6157792508602142e-01
    z[5,1,6]  R1578     1.4025190472602844e-01
    z[5,1,6]  R1579     3.3324298262596130e-01
    z[5,1,6]  R1580     1.6489909589290619e-01
    z[5,1,6]  R1581     -1.6969369351863861e-01
    z[5,1,6]  R1582     4.1545432060956955e-02
    z[5,1,6]  R1583     3.2960101962089539e-01
    z[5,1,6]  R1584     9.5377013087272644e-02
    z[5,1,6]  R1585     3.6477804183959961e-01
    z[5,1,6]  R1586     -3.2919496297836304e-01
    z[5,1,6]  R1587     -1.0445023328065872e-01
    z[5,1,6]  R1588     8.2382082939147949e-02
    z[5,1,6]  R1589     9.5949888229370117e-02
    z[5,1,6]  R1590     3.4505769610404968e-01
    z[5,1,6]  R1591     -5.6673612445592880e-02
    z[5,1,6]  R1592     4.2273110151290894e-01
    z[5,1,6]  R1593     -3.5286897420883179e-01
    z[5,1,6]  R1594     -1.8022920191287994e-01
    z[5,1,6]  R1595     9.2139437794685364e-02
    z[5,1,6]  R1596     5.0284836441278458e-02
    z[5,1,6]  R1597     1.9310359656810760e-01
    z[5,1,6]  R1598     -2.2523060441017151e-01
    z[5,1,6]  R1599     -1.0507960803806782e-02
    z[5,1,6]  R1600     3.3523243665695190e-01
    z[5,1,6]  R1601     0.263115257024765
    z[5,1,6]  R1602     -0.0172833651304245
    z[5,1,6]  R1603     2.6480999588966370e-01
    z[5,1,6]  R1604     -0.0742039605975151
    z[5,1,6]  R1605     2.3711478710174561e-01
    z[5,1,6]  R1606     5.6914114393293858e-03
    z[5,1,6]  R1607     2.4102061986923218e-01
    z[5,1,6]  R1608     -1.9952252507209778e-01
    z[5,1,6]  R1609     6.1366468667984009e-02
    z[5,1,6]  R1610     8.4016129374504089e-02
    z[5,1,6]  R1611     -1.6170255839824677e-01
    z[5,1,6]  R1612     5.7765308767557144e-02
    z[5,1,6]  R1613     3.6379155516624451e-01
    z[5,1,6]  R1614     -1.2155794352293015e-01
    z[5,1,6]  R1615     1.8742622435092926e-01
    z[5,1,6]  R1616     -2.3593294620513916e-01
    z[5,1,6]  R1617     3.0443921685218811e-01
    z[5,1,6]  R1618     -1.3737358152866364e-01
    z[5,1,6]  R1619     1.1643828451633453e-01
    z[5,1,6]  R1620     1.7010244727134705e-01
    z[5,1,6]  R1621     0.232234388589859
    z[5,1,6]  R1622     -5.6208237074315548e-03
    z[5,1,6]  R1623     -2.1610192954540253e-01
    z[5,1,6]  R1624     1.4185032248497009e-01
    z[5,1,6]  R1625     -0.391007661819458
    z[5,1,6]  R1626     -3.9091381430625916e-01
    z[5,1,6]  R1627     -6.0242330655455589e-03
    z[5,1,6]  R1628     1.0224212892353535e-02
    z[5,1,6]  R1629     1.3477612286806107e-02
    z[5,1,6]  R1630     5.7424264959990978e-03
    z[5,1,6]  R1631     -1.5017724037170410e-01
    z[5,1,6]  R1632     -4.2608477175235748e-02
    z[5,1,6]  R1633     -3.2186403870582581e-01
    z[5,1,6]  R1634     -3.1398364901542664e-01
    z[5,1,6]  R1635     0.0945323258638382
    z[5,1,6]  R1636     -4.6854072809219360e-01
    z[5,1,6]  R1637     -1.8549780547618866e-01
    z[5,1,6]  R1638     -3.2859003543853760e-01
    z[5,1,6]  R1639     -2.7782490849494934e-01
    z[5,1,6]  R1640     -0.0677451640367508
    z[5,1,6]  R1641     1.5936177968978882e-01
    z[5,1,6]  R1642     2.4572479724884033e-01
    z[5,1,6]  R1643     2.4274982511997223e-01
    z[5,1,6]  R1644     3.2023850828409195e-02
    z[5,1,6]  R1645     3.2487708330154419e-01
    z[5,1,6]  R1646     2.5020885467529297e-01
    z[5,1,6]  R1647     -2.3303854465484619e-01
    z[5,1,6]  R1648     2.8261154890060425e-01
    z[5,1,6]  R1649     -1.6217219829559326e-01
    z[5,1,6]  R1650     2.0462350547313690e-01
    z[5,1,6]  R1651     -3.4572128206491470e-02
    z[5,1,6]  R1652     2.4441033601760864e-01
    z[5,1,6]  R1653     1.2077458202838898e-01
    z[5,1,6]  R1654     3.4495350718498230e-01
    z[5,1,6]  R1655     0.470958948135376
    z[5,1,6]  R1656     2.6052755117416382e-01
    z[5,1,6]  R1657     -1.2949370779097080e-02
    z[5,1,6]  R1658     2.4970626831054688e-01
    z[5,1,6]  R1659     5.9450912475585938e-01
    z[5,1,6]  R1660     -5.0955647230148315e-01
    z[5,1,6]  R1661     -1.8352743983268738e-01
    z[5,1,6]  R1662     -1.1067216284573078e-02
    z[5,1,6]  R1663     -1.8066921830177307e-01
    z[5,1,6]  R1664     -6.7055529356002808e-01
    z[5,1,6]  R1665     3.8996872305870056e-01
    z[5,1,6]  R1666     2.6779506355524063e-02
    z[5,1,6]  R1667     1.9074784219264984e-01
    z[5,1,6]  R1668     1.5408596396446228e-01
    z[5,1,6]  R1669     -4.5079058408737183e-01
    z[5,1,6]  R1670     -6.9441363215446472e-02
    z[5,1,6]  R1671     -4.3850109796039760e-04
    z[5,1,6]  R1672     4.8177537322044373e-01
    z[5,1,6]  R1673     -0.126246377825737
    z[5,1,6]  R1674     1.9304960966110229e-01
    z[5,1,6]  R1675     1.7743013799190521e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1676     -1
    z[2,4,0]  R1677     1
    z[2,4,0]  R1690     -2.6873114705085754e-01
    z[2,4,0]  R1691     -3.2073151320219040e-02
    z[2,4,0]  R1692     3.7537875771522522e-01
    z[2,4,0]  R1693     3.6279532313346863e-01
    z[2,4,0]  R1694     2.7410724759101868e-01
    z[2,4,0]  R1695     3.4550437331199646e-01
    z[2,4,0]  R1696     -3.4611618518829346e-01
    z[2,4,0]  R1697     -1.3425517082214355e-01
    z[2,4,0]  R1698     -3.1043639779090881e-01
    z[2,4,0]  R1699     -2.7002862095832825e-01
    z[2,4,0]  R1700     -6.6402232646942139e-01
    z[2,4,0]  R1701     -9.0399205684661865e-01
    z[2,4,0]  R1702     -0.804214358329773
    z[2,4,0]  R1703     -7.4929600954055786e-01
    z[2,4,0]  R1704     -5.9058940410614014e-01
    z[2,4,0]  R1705     -1.7309513350483030e-04
    z[2,4,0]  R1706     6.1451070010662079e-02
    z[2,4,0]  R1707     2.2709189355373383e-01
    z[2,4,0]  R1708     -1.8552179634571075e-01
    z[2,4,0]  R1709     -3.4881201386451721e-01
    z[2,4,0]  R1710     1.3089212775230408e-01
    z[2,4,0]  R1711     -3.5005442332476377e-03
    z[2,4,0]  R1712     5.3854632377624512e-01
    z[2,4,0]  R1713     4.9122610688209534e-01
    z[2,4,0]  R1714     4.4492509961128235e-01
    z[2,4,0]  R1715     2.5517001748085022e-01
    z[2,4,0]  R1716     5.1593577861785889e-01
    z[2,4,0]  R1717     -2.5728667154908180e-02
    z[2,4,0]  R1718     8.3634227514266968e-02
    z[2,4,0]  R1719     3.6626616120338440e-01
    z[2,4,0]  R1720     -8.9695248752832413e-03
    z[2,4,0]  R1721     1.5972553193569183e-01
    z[2,4,0]  R1722     -5.3645157814025879e-01
    z[2,4,0]  R1723     6.3105231523513794e-01
    z[2,4,0]  R1724     -4.2418235540390015e-01
    z[2,4,0]  R1725     5.4071956872940063e-01
    z[2,4,0]  R1726     2.4172581732273102e-01
    z[2,4,0]  R1727     6.0971105098724365e-01
    z[2,4,0]  R1728     1.7035140097141266e-01
    z[2,4,0]  R1729     7.2460480034351349e-02
    z[2,4,0]  R1730     -6.7582845687866211e-01
    z[2,4,0]  R1731     -6.0512125492095947e-01
    z[2,4,0]  R1732     1.4272104203701019e-01
    z[2,4,0]  R1733     -7.2260481119155884e-01
    z[2,4,0]  R1734     6.4754843711853027e-01
    z[2,4,0]  R1735     7.0424085855484009e-01
    z[2,4,0]  R1736     8.7252952158451080e-02
    z[2,4,0]  R1737     1.3760389387607574e-01
    z[2,4,0]  R1738     4.6381881833076477e-01
    z[2,4,0]  R1739     -1.3176780939102173e-01
    z[2,4,0]  R1740     2.5867810845375061e-01
    z[2,4,0]  R1741     9.8589166998863220e-02
    z[2,4,0]  R1742     -1.6886758804321289e-01
    z[2,4,0]  R1743     -2.4934832006692886e-02
    z[2,4,0]  R1744     -2.7765434980392456e-01
    z[2,4,0]  R1745     -7.5552088022232056e-01
    z[2,4,0]  R1746     -8.4898811578750610e-01
    z[2,4,0]  R1747     3.0848824977874756e-01
    z[2,4,0]  R1748     -4.2343363165855408e-01
    z[2,4,0]  R1749     3.1179559230804443e-01
    z[2,4,0]  R1750     3.2969641685485840e-01
    z[2,4,0]  R1751     3.4860834479331970e-01
    z[2,4,0]  R1752     -4.5325347781181335e-01
    z[2,4,0]  R1753     -0.422927588224411
    z[2,4,0]  R1754     -5.0999581813812256e-01
    z[2,4,0]  R1755     -2.6431143283843994e-01
    z[2,4,0]  R1756     4.9214616417884827e-02
    z[2,4,0]  R1757     1.9649212062358856e-01
    z[2,4,0]  R1758     0.422234445810318
    z[2,4,0]  R1759     2.4938111007213593e-01
    z[2,4,0]  R1760     8.8419675827026367e-02
    z[2,4,0]  R1761     4.0276327729225159e-01
    z[2,4,0]  R1762     0.631734311580658
    z[2,4,0]  R1763     5.6486970186233521e-01
    z[2,4,0]  R1764     5.7851821184158325e-01
    z[2,4,0]  R1765     4.3736633658409119e-01
    z[2,4,0]  R1766     2.5934025645256042e-01
    z[2,4,0]  R1767     5.0061064958572388e-01
    z[2,4,0]  R1768     1.2580172717571259e-01
    z[2,4,0]  R1769     2.9341140389442444e-01
    z[2,4,0]  R1770     4.2084982991218567e-01
    z[2,4,0]  R1771     1.8046663701534271e-01
    z[2,4,0]  R1772     3.0953222513198853e-01
    z[2,4,0]  R1773     2.5165063142776489e-01
    z[2,4,0]  R1774     1.2470825761556625e-01
    z[2,4,0]  R1775     5.1459338515996933e-02
    z[2,4,0]  R1776     2.2383508086204529e-01
    z[2,4,0]  R1777     1.8951010704040527e-01
    z[2,4,0]  R1778     -5.1455962657928467e-01
    z[2,4,0]  R1779     -0.131059467792511
    z[2,4,0]  R1780     -4.4537249207496643e-01
    z[2,4,0]  R1781     -5.1074630022048950e-01
    z[2,4,0]  R1782     -5.2198320627212524e-01
    z[2,4,0]  R1783     1.4921683818101883e-02
    z[2,4,0]  R1784     -9.6592712402343750e-01
    z[2,4,0]  R1785     8.0585852265357971e-02
    z[2,4,0]  R1786     -1.7927173525094986e-02
    z[2,4,0]  R1787     3.2609567046165466e-02
    z[2,4,0]  R1788     -2.4398061633110046e-01
    z[2,4,0]  R1789     -1.0867832228541374e-02
    z[2,4,0]  R1790     0.331209659576416
    z[2,4,0]  R1791     3.7573602795600891e-01
    z[2,4,0]  R1792     4.9842461943626404e-01
    z[2,4,0]  R1793     3.3839711546897888e-01
    z[2,4,0]  R1794     3.7496492266654968e-01
    z[2,4,0]  R1795     3.4600558876991272e-01
    z[2,4,0]  R1796     2.5181302428245544e-01
    z[2,4,0]  R1797     1.5387284755706787e-01
    z[2,4,0]  R1798     3.2433813810348511e-01
    z[2,4,0]  R1799     2.0987780392169952e-01
    z[2,4,0]  R1800     2.4177080392837524e-01
    z[2,4,0]  R1801     -1.7149411141872406e-01
    z[2,4,0]  R1802     -1.1276394070591778e-04
    z[2,4,0]  R1803     0.299360454082489
    z[2,4,0]  R1804     1.8625383079051971e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1678     -1
    z[2,4,1]  R1679     1
    z[2,4,1]  R1690     -2.1588015556335449e-01
    z[2,4,1]  R1691     1.7628110945224762e-01
    z[2,4,1]  R1692     -2.3755583167076111e-01
    z[2,4,1]  R1693     2.0479236543178558e-01
    z[2,4,1]  R1694     -1.3154593110084534e-01
    z[2,4,1]  R1695     1.9905219972133636e-01
    z[2,4,1]  R1696     -4.1699981689453125e-01
    z[2,4,1]  R1697     -3.0128517746925354e-01
    z[2,4,1]  R1698     -7.6194740831851959e-02
    z[2,4,1]  R1699     0.209869846701622
    z[2,4,1]  R1700     -4.0960386395454407e-01
    z[2,4,1]  R1701     -1.5778750181198120e-01
    z[2,4,1]  R1702     -2.4455009400844574e-01
    z[2,4,1]  R1703     -2.5556573271751404e-01
    z[2,4,1]  R1704     -3.8000097870826721e-01
    z[2,4,1]  R1705     1.2717936933040619e-01
    z[2,4,1]  R1706     1.5552307665348053e-01
    z[2,4,1]  R1707     3.5584294237196445e-03
    z[2,4,1]  R1708     3.0309504270553589e-01
    z[2,4,1]  R1709     0.143227681517601
    z[2,4,1]  R1710     6.7356717586517334e-01
    z[2,4,1]  R1711     8.2480198144912720e-01
    z[2,4,1]  R1712     5.6491744518280029e-01
    z[2,4,1]  R1713     -7.3912781476974487e-01
    z[2,4,1]  R1714     -6.5501809120178223e-01
    z[2,4,1]  R1715     -5.0831407308578491e-01
    z[2,4,1]  R1716     -5.9823578596115112e-01
    z[2,4,1]  R1717     8.8219058513641357e-01
    z[2,4,1]  R1718     8.8769757747650146e-01
    z[2,4,1]  R1719     4.5806637406349182e-01
    z[2,4,1]  R1720     1.8596200644969940e-01
    z[2,4,1]  R1721     7.1757632493972778e-01
    z[2,4,1]  R1722     -3.8152185082435608e-01
    z[2,4,1]  R1723     1.4021593332290649e-01
    z[2,4,1]  R1724     -3.7752085924148560e-01
    z[2,4,1]  R1725     0.69268798828125
    z[2,4,1]  R1726     -6.1385488510131836e-01
    z[2,4,1]  R1727     6.0728186368942261e-01
    z[2,4,1]  R1728     -4.8250687122344971e-01
    z[2,4,1]  R1729     -7.0133811235427856e-01
    z[2,4,1]  R1730     -5.4359430074691772e-01
    z[2,4,1]  R1731     -4.9089613556861877e-01
    z[2,4,1]  R1732     2.6800769567489624e-01
    z[2,4,1]  R1733     -4.0371596813201904e-01
    z[2,4,1]  R1734     0.409095823764801
    z[2,4,1]  R1735     6.2194281816482544e-01
    z[2,4,1]  R1736     -3.8345479965209961e-01
    z[2,4,1]  R1737     9.3600398302078247e-01
    z[2,4,1]  R1738     -5.5373638868331909e-01
    z[2,4,1]  R1739     9.1260397434234619e-01
    z[2,4,1]  R1740     1.5924791991710663e-01
    z[2,4,1]  R1741     3.9333915710449219e-01
    z[2,4,1]  R1742     3.0031278729438782e-01
    z[2,4,1]  R1743     6.2737494707107544e-01
    z[2,4,1]  R1744     2.1992325782775879e-01
    z[2,4,1]  R1745     -4.1509312391281128e-01
    z[2,4,1]  R1746     -4.1287493705749512e-01
    z[2,4,1]  R1747     8.0462110042572021e-01
    z[2,4,1]  R1748     -3.6295115947723389e-01
    z[2,4,1]  R1749     -6.9650501012802124e-01
    z[2,4,1]  R1750     -6.7203216254711151e-02
    z[2,4,1]  R1751     8.0494272708892822e-01
    z[2,4,1]  R1752     -3.9140564203262329e-01
    z[2,4,1]  R1753     4.6580326557159424e-01
    z[2,4,1]  R1754     3.8096180558204651e-01
    z[2,4,1]  R1755     1.5873104333877563e-01
    z[2,4,1]  R1756     1.4601269364356995e-01
    z[2,4,1]  R1757     2.3214745521545410e-01
    z[2,4,1]  R1758     -5.8443200588226318e-01
    z[2,4,1]  R1759     -4.8416009545326233e-01
    z[2,4,1]  R1760     -4.8915907740592957e-01
    z[2,4,1]  R1761     -5.4353523254394531e-01
    z[2,4,1]  R1762     3.3106356859207153e-01
    z[2,4,1]  R1763     0.0721365436911583
    z[2,4,1]  R1764     2.4072538316249847e-01
    z[2,4,1]  R1765     -4.7887992858886719e-01
    z[2,4,1]  R1766     -3.7768241763114929e-01
    z[2,4,1]  R1767     -3.6895516514778137e-01
    z[2,4,1]  R1768     -3.3499330282211304e-01
    z[2,4,1]  R1769     -2.3496727645397186e-01
    z[2,4,1]  R1770     -0.631965160369873
    z[2,4,1]  R1771     -5.7080310583114624e-01
    z[2,4,1]  R1772     -4.0810176730155945e-01
    z[2,4,1]  R1773     -2.2940079867839813e-01
    z[2,4,1]  R1774     -2.9745447635650635e-01
    z[2,4,1]  R1775     -1.1915975809097290e-01
    z[2,4,1]  R1776     6.0840494930744171e-02
    z[2,4,1]  R1777     -2.8783810138702393e-01
    z[2,4,1]  R1778     6.6480404138565063e-01
    z[2,4,1]  R1779     5.4802858829498291e-01
    z[2,4,1]  R1780     0.665277361869812
    z[2,4,1]  R1781     5.7158994674682617e-01
    z[2,4,1]  R1782     4.0337088704109192e-01
    z[2,4,1]  R1783     7.5647455453872681e-01
    z[2,4,1]  R1784     7.8719764947891235e-02
    z[2,4,1]  R1785     -6.6353100538253784e-01
    z[2,4,1]  R1786     -5.6738960742950439e-01
    z[2,4,1]  R1787     -0.539656400680542
    z[2,4,1]  R1788     -7.3659688234329224e-01
    z[2,4,1]  R1789     2.8826889395713806e-01
    z[2,4,1]  R1790     -7.7573865652084351e-01
    z[2,4,1]  R1791     -7.6019245386123657e-01
    z[2,4,1]  R1792     -6.0532516241073608e-01
    z[2,4,1]  R1793     -7.0515912771224976e-01
    z[2,4,1]  R1794     -6.2775951623916626e-01
    z[2,4,1]  R1795     -6.5205973386764526e-01
    z[2,4,1]  R1796     -7.5500094890594482e-01
    z[2,4,1]  R1797     -0.685711681842804
    z[2,4,1]  R1798     -5.7793557643890381e-01
    z[2,4,1]  R1799     -6.6598445177078247e-01
    z[2,4,1]  R1800     -6.6299033164978027e-01
    z[2,4,1]  R1801     2.1881558932363987e-03
    z[2,4,1]  R1802     1.9273987039923668e-02
    z[2,4,1]  R1803     5.7013678550720215e-01
    z[2,4,1]  R1804     6.1896014213562012e-01
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1680     -1
    z[2,4,2]  R1681     1
    z[2,4,2]  R1690     -3.9520934224128723e-01
    z[2,4,2]  R1691     -6.5507078170776367e-01
    z[2,4,2]  R1692     -6.7343634366989136e-01
    z[2,4,2]  R1693     -7.1022748947143555e-01
    z[2,4,2]  R1694     -3.5012489557266235e-01
    z[2,4,2]  R1695     -2.4349214136600494e-01
    z[2,4,2]  R1696     -7.4231493473052979e-01
    z[2,4,2]  R1697     -5.1035708189010620e-01
    z[2,4,2]  R1698     -4.5079621672630310e-01
    z[2,4,2]  R1699     -3.3830073475837708e-01
    z[2,4,2]  R1700     2.1875385940074921e-01
    z[2,4,2]  R1701     3.3716621994972229e-01
    z[2,4,2]  R1702     4.4088739156723022e-01
    z[2,4,2]  R1703     2.2630555927753448e-01
    z[2,4,2]  R1704     5.4999870061874390e-01
    z[2,4,2]  R1705     8.7424147129058838e-01
    z[2,4,2]  R1706     9.4849610328674316e-01
    z[2,4,2]  R1707     9.5662963390350342e-01
    z[2,4,2]  R1708     8.9228767156600952e-01
    z[2,4,2]  R1709     8.1086415052413940e-01
    z[2,4,2]  R1710     -4.1185855865478516e-01
    z[2,4,2]  R1711     -1.9162485376000404e-02
    z[2,4,2]  R1712     2.8008872270584106e-01
    z[2,4,2]  R1713     4.0162590146064758e-01
    z[2,4,2]  R1714     4.4733661413192749e-01
    z[2,4,2]  R1715     0.568046510219574
    z[2,4,2]  R1716     2.8434932231903076e-01
    z[2,4,2]  R1717     3.1677380204200745e-01
    z[2,4,2]  R1718     1.1546524614095688e-01
    z[2,4,2]  R1719     -1.6543051600456238e-01
    z[2,4,2]  R1720     -0.0796266719698906
    z[2,4,2]  R1721     -2.9266723990440369e-01
    z[2,4,2]  R1722     -2.8603881597518921e-01
    z[2,4,2]  R1723     -3.5321470350027084e-02
    z[2,4,2]  R1724     1.1452263593673706e-01
    z[2,4,2]  R1725     1.4027774333953857e-02
    z[2,4,2]  R1726     0.628491997718811
    z[2,4,2]  R1727     3.4253127872943878e-02
    z[2,4,2]  R1728     6.6206520795822144e-01
    z[2,4,2]  R1729     6.2908381223678589e-01
    z[2,4,2]  R1730     2.9503282904624939e-01
    z[2,4,2]  R1731     -1.2889644131064415e-02
    z[2,4,2]  R1732     -3.6238917708396912e-01
    z[2,4,2]  R1733     -1.2910751998424530e-01
    z[2,4,2]  R1734     2.9581716284155846e-02
    z[2,4,2]  R1735     -5.8643147349357605e-02
    z[2,4,2]  R1736     7.1621578931808472e-01
    z[2,4,2]  R1737     1.7335261404514313e-01
    z[2,4,2]  R1738     0.579522430896759
    z[2,4,2]  R1739     -1.2586662545800209e-02
    z[2,4,2]  R1740     -0.60338294506073
    z[2,4,2]  R1741     -2.8439977765083313e-01
    z[2,4,2]  R1742     -5.1153934001922607e-01
    z[2,4,2]  R1743     -1.1169648915529251e-01
    z[2,4,2]  R1744     -5.5183249711990356e-01
    z[2,4,2]  R1745     -7.1597069501876831e-02
    z[2,4,2]  R1746     7.9120278358459473e-02
    z[2,4,2]  R1747     -3.7630371749401093e-02
    z[2,4,2]  R1748     1.3049761950969696e-01
    z[2,4,2]  R1749     6.2702363729476929e-01
    z[2,4,2]  R1750     -7.2930544614791870e-01
    z[2,4,2]  R1751     -3.3465901017189026e-01
    z[2,4,2]  R1752     3.6644306033849716e-02
    z[2,4,2]  R1753     7.0993721485137939e-01
    z[2,4,2]  R1754     0.539761483669281
    z[2,4,2]  R1755     0.705171525478363
    z[2,4,2]  R1756     9.0713568031787872e-02
    z[2,4,2]  R1757     -1.1441487073898315e-01
    z[2,4,2]  R1758     3.7345755100250244e-01
    z[2,4,2]  R1759     4.0972551703453064e-01
    z[2,4,2]  R1760     7.2683101892471313e-01
    z[2,4,2]  R1761     6.2340795993804932e-01
    z[2,4,2]  R1762     1.4043259620666504e-01
    z[2,4,2]  R1763     -1.3547022640705109e-01
    z[2,4,2]  R1764     1.2957191467285156e-01
    z[2,4,2]  R1765     4.8817488551139832e-01
    z[2,4,2]  R1766     5.4580259323120117e-01
    z[2,4,2]  R1767     4.9789234995841980e-01
    z[2,4,2]  R1768     -2.2322230041027069e-01
    z[2,4,2]  R1769     -2.6471281051635742e-01
    z[2,4,2]  R1770     6.1506575345993042e-01
    z[2,4,2]  R1771     4.2768985033035278e-01
    z[2,4,2]  R1772     5.0138247013092041e-01
    z[2,4,2]  R1773     -1.3325053453445435e-01
    z[2,4,2]  R1774     -8.8966287672519684e-02
    z[2,4,2]  R1775     1.1987017840147018e-01
    z[2,4,2]  R1776     -2.1370720863342285e-01
    z[2,4,2]  R1777     -1.6838872432708740e-01
    z[2,4,2]  R1778     2.0024140179157257e-01
    z[2,4,2]  R1779     4.3591436743736267e-01
    z[2,4,2]  R1780     -3.3246603608131409e-01
    z[2,4,2]  R1781     -3.3024686574935913e-01
    z[2,4,2]  R1782     -3.8213226199150085e-01
    z[2,4,2]  R1783     -5.9999954700469971e-01
    z[2,4,2]  R1784     -1.8448592722415924e-01
    z[2,4,2]  R1785     4.5519477128982544e-01
    z[2,4,2]  R1786     -1.3045579195022583e-01
    z[2,4,2]  R1787     -2.9634529352188110e-01
    z[2,4,2]  R1788     4.5163431763648987e-01
    z[2,4,2]  R1789     0.0443992018699646
    z[2,4,2]  R1790     4.3069524690508842e-03
    z[2,4,2]  R1791     -2.0378093421459198e-01
    z[2,4,2]  R1792     -2.0583665370941162e-01
    z[2,4,2]  R1793     -0.601309597492218
    z[2,4,2]  R1794     7.6408926397562027e-03
    z[2,4,2]  R1795     -2.1865795552730560e-01
    z[2,4,2]  R1796     -5.1944029331207275e-01
    z[2,4,2]  R1797     2.9603847861289978e-01
    z[2,4,2]  R1798     -1.8319685757160187e-01
    z[2,4,2]  R1799     5.0144165754318237e-01
    z[2,4,2]  R1800     3.1911796331405640e-01
    z[2,4,2]  R1801     -5.3569239377975464e-01
    z[2,4,2]  R1802     -5.2974373102188110e-01
    z[2,4,2]  R1803     3.3966198563575745e-01
    z[2,4,2]  R1804     6.2364935874938965e-01
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1682     -1
    z[2,4,3]  R1683     1
    z[2,4,3]  R1690     5.8361768722534180e-01
    z[2,4,3]  R1691     4.6935808658599854e-01
    z[2,4,3]  R1692     4.0347889065742493e-01
    z[2,4,3]  R1693     5.5925935506820679e-01
    z[2,4,3]  R1694     4.1561439633369446e-01
    z[2,4,3]  R1695     8.5939311981201172e-01
    z[2,4,3]  R1696     0.275499552488327
    z[2,4,3]  R1697     7.4122303724288940e-01
    z[2,4,3]  R1698     5.0755894184112549e-01
    z[2,4,3]  R1699     1.4604271948337555e-01
    z[2,4,3]  R1700     -4.8070603609085083e-01
    z[2,4,3]  R1701     -0.170390784740448
    z[2,4,3]  R1702     3.8864649832248688e-02
    z[2,4,3]  R1703     -0.148195281624794
    z[2,4,3]  R1704     -0.068141870200634
    z[2,4,3]  R1705     0.0461047999560833
    z[2,4,3]  R1706     7.8676626086235046e-02
    z[2,4,3]  R1707     1.0513123869895935e-01
    z[2,4,3]  R1708     0.0667092427611351
    z[2,4,3]  R1709     2.0522156357765198e-01
    z[2,4,3]  R1710     -2.3449407517910004e-01
    z[2,4,3]  R1711     -1.1086897552013397e-01
    z[2,4,3]  R1712     1.3058193027973175e-01
    z[2,4,3]  R1713     -1.5165399014949799e-01
    z[2,4,3]  R1714     -3.3748653531074524e-01
    z[2,4,3]  R1715     -3.0212721228599548e-01
    z[2,4,3]  R1716     -1.4454054832458496e-01
    z[2,4,3]  R1717     -0.0949816182255745
    z[2,4,3]  R1718     -0.00844635721296072
    z[2,4,3]  R1719     -0.072464220225811
    z[2,4,3]  R1720     2.6678740978240967e-01
    z[2,4,3]  R1721     1.5070120804011822e-02
    z[2,4,3]  R1722     -5.3139245510101318e-01
    z[2,4,3]  R1723     -2.8727075085043907e-02
    z[2,4,3]  R1724     -9.5711521804332733e-02
    z[2,4,3]  R1725     -7.4008852243423462e-02
    z[2,4,3]  R1726     9.4357088208198547e-02
    z[2,4,3]  R1727     -5.3052004426717758e-02
    z[2,4,3]  R1728     -2.3163458704948425e-01
    z[2,4,3]  R1729     2.2300805151462555e-01
    z[2,4,3]  R1730     1.6113524138927460e-01
    z[2,4,3]  R1731     -2.3640665411949158e-01
    z[2,4,3]  R1732     -3.4317496418952942e-01
    z[2,4,3]  R1733     -3.7083217501640320e-01
    z[2,4,3]  R1734     -9.3176349997520447e-02
    z[2,4,3]  R1735     -7.2438023984432220e-02
    z[2,4,3]  R1736     -3.0139824748039246e-01
    z[2,4,3]  R1737     -1.7185065150260925e-01
    z[2,4,3]  R1738     -1.4382113516330719e-01
    z[2,4,3]  R1739     -1.5414026379585266e-01
    z[2,4,3]  R1740     2.1110512316226959e-01
    z[2,4,3]  R1741     -3.6252435296773911e-02
    z[2,4,3]  R1742     -0.321154922246933
    z[2,4,3]  R1743     1.9282083213329315e-01
    z[2,4,3]  R1744     -1.6128194332122803e-01
    z[2,4,3]  R1745     -1.8521138699725270e-03
    z[2,4,3]  R1746     -1.4850957691669464e-01
    z[2,4,3]  R1747     2.2216208279132843e-01
    z[2,4,3]  R1748     -1.8443416059017181e-01
    z[2,4,3]  R1749     -5.6029386818408966e-02
    z[2,4,3]  R1750     1.2959238886833191e-01
    z[2,4,3]  R1751     4.5644771307706833e-02
    z[2,4,3]  R1752     -1.8064694106578827e-01
    z[2,4,3]  R1753     8.3385735750198364e-02
    z[2,4,3]  R1754     2.6409700512886047e-01
    z[2,4,3]  R1755     3.6392763257026672e-01
    z[2,4,3]  R1756     -0.806171178817749
    z[2,4,3]  R1757     -8.5051637887954712e-01
    z[2,4,3]  R1758     6.0818102210760117e-02
    z[2,4,3]  R1759     -1.5635755658149719e-01
    z[2,4,3]  R1760     -5.2543841302394867e-02
    z[2,4,3]  R1761     -2.5762656331062317e-01
    z[2,4,3]  R1762     5.9513457119464874e-02
    z[2,4,3]  R1763     1.8277665600180626e-02
    z[2,4,3]  R1764     1.0919960588216782e-01
    z[2,4,3]  R1765     -4.5451596379280090e-01
    z[2,4,3]  R1766     -4.6350872516632080e-01
    z[2,4,3]  R1767     3.5328158736228943e-01
    z[2,4,3]  R1768     -4.3283212184906006e-01
    z[2,4,3]  R1769     -5.5757224559783936e-01
    z[2,4,3]  R1770     -3.1490195542573929e-02
    z[2,4,3]  R1771     -9.0821079909801483e-02
    z[2,4,3]  R1772     -4.4099974632263184e-01
    z[2,4,3]  R1773     -8.5201394557952881e-01
    z[2,4,3]  R1774     -7.7582234144210815e-01
    z[2,4,3]  R1775     -0.92115718126297
    z[2,4,3]  R1776     -9.0703666210174561e-01
    z[2,4,3]  R1777     -8.0508148670196533e-01
    z[2,4,3]  R1778     1.9683811068534851e-01
    z[2,4,3]  R1779     -1.1682634800672531e-01
    z[2,4,3]  R1780     6.1623834073543549e-02
    z[2,4,3]  R1781     1.2031611055135727e-01
    z[2,4,3]  R1782     -1.0835071653127670e-01
    z[2,4,3]  R1783     1.6698566079139709e-01
    z[2,4,3]  R1784     -8.0087609589099884e-02
    z[2,4,3]  R1785     5.4327648133039474e-02
    z[2,4,3]  R1786     -5.7724362611770630e-01
    z[2,4,3]  R1787     1.4700695872306824e-01
    z[2,4,3]  R1788     1.0272392630577087e-01
    z[2,4,3]  R1789     8.5961920022964478e-01
    z[2,4,3]  R1790     -2.4001386761665344e-01
    z[2,4,3]  R1791     1.8896806240081787e-01
    z[2,4,3]  R1792     -0.388874351978302
    z[2,4,3]  R1793     1.1385331302881241e-01
    z[2,4,3]  R1794     3.0618848279118538e-02
    z[2,4,3]  R1795     5.8276718854904175e-01
    z[2,4,3]  R1796     -4.3951552361249924e-02
    z[2,4,3]  R1797     3.5840559005737305e-01
    z[2,4,3]  R1798     1.5175801515579224e-01
    z[2,4,3]  R1799     1.3548615574836731e-01
    z[2,4,3]  R1800     -7.3759861290454865e-02
    z[2,4,3]  R1801     -6.4899915456771851e-01
    z[2,4,3]  R1802     -3.1279709935188293e-01
    z[2,4,3]  R1803     -6.1535632610321045e-01
    z[2,4,3]  R1804     -2.5307220220565796e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1684     -1
    z[2,4,4]  R1685     1
    z[2,4,4]  R1690     -1.3866421580314636e-01
    z[2,4,4]  R1691     0.4262675344944
    z[2,4,4]  R1692     1.2889516353607178e-01
    z[2,4,4]  R1693     -2.1842949092388153e-02
    z[2,4,4]  R1694     -3.7414006888866425e-02
    z[2,4,4]  R1695     -9.2173544690012932e-03
    z[2,4,4]  R1696     9.3282364308834076e-02
    z[2,4,4]  R1697     1.4299346506595612e-01
    z[2,4,4]  R1698     1.1714073270559311e-01
    z[2,4,4]  R1699     3.7614884972572327e-01
    z[2,4,4]  R1700     0.0735994279384613
    z[2,4,4]  R1701     6.7542046308517456e-02
    z[2,4,4]  R1702     2.3088328540325165e-01
    z[2,4,4]  R1703     -9.5550626516342163e-02
    z[2,4,4]  R1704     -1.7954094707965851e-01
    z[2,4,4]  R1705     3.1480357050895691e-01
    z[2,4,4]  R1706     1.8796192109584808e-01
    z[2,4,4]  R1707     8.3698770031332970e-03
    z[2,4,4]  R1708     0.0705980509519577
    z[2,4,4]  R1709     2.6583236455917358e-01
    z[2,4,4]  R1710     -3.7515938282012939e-01
    z[2,4,4]  R1711     -4.4282034039497375e-01
    z[2,4,4]  R1712     -1.6256643831729889e-01
    z[2,4,4]  R1713     1.1624976247549057e-01
    z[2,4,4]  R1714     2.3277167975902557e-01
    z[2,4,4]  R1715     1.8302576243877411e-01
    z[2,4,4]  R1716     2.3575511574745178e-01
    z[2,4,4]  R1717     -9.6358023583889008e-02
    z[2,4,4]  R1718     1.0487534105777740e-01
    z[2,4,4]  R1719     -2.3561987280845642e-01
    z[2,4,4]  R1720     -9.4050276279449463e-01
    z[2,4,4]  R1721     -5.3487664461135864e-01
    z[2,4,4]  R1722     -5.0266232341527939e-02
    z[2,4,4]  R1723     -3.7714448571205139e-01
    z[2,4,4]  R1724     7.5331604480743408e-01
    z[2,4,4]  R1725     4.3590095639228821e-01
    z[2,4,4]  R1726     5.7433921843767166e-02
    z[2,4,4]  R1727     -0.0620078481733799
    z[2,4,4]  R1728     4.7839531302452087e-01
    z[2,4,4]  R1729     1.7153675854206085e-01
    z[2,4,4]  R1730     -2.6997578144073486e-01
    z[2,4,4]  R1731     1.3102343678474426e-01
    z[2,4,4]  R1732     -6.5804773569107056e-01
    z[2,4,4]  R1733     -2.1013745665550232e-01
    z[2,4,4]  R1734     -0.456379771232605
    z[2,4,4]  R1735     2.5651317834854126e-01
    z[2,4,4]  R1736     4.8555487394332886e-01
    z[2,4,4]  R1737     0.181008979678154
    z[2,4,4]  R1738     -2.8443282842636108e-01
    z[2,4,4]  R1739     -6.0795680619776249e-03
    z[2,4,4]  R1740     -5.2893245220184326e-01
    z[2,4,4]  R1741     -7.8231376409530640e-01
    z[2,4,4]  R1742     -5.5640321969985962e-01
    z[2,4,4]  R1743     -6.1660176515579224e-01
    z[2,4,4]  R1744     -3.5854494571685791e-01
    z[2,4,4]  R1745     3.8253688812255859e-01
    z[2,4,4]  R1746     -1.3372954726219177e-01
    z[2,4,4]  R1747     4.8215255141258240e-02
    z[2,4,4]  R1748     -7.5708419084548950e-01
    z[2,4,4]  R1749     -8.2201175391674042e-02
    z[2,4,4]  R1750     -1.6545540094375610e-01
    z[2,4,4]  R1751     -1.9630345702171326e-01
    z[2,4,4]  R1752     -0.774272620677948
    z[2,4,4]  R1753     2.1603046357631683e-01
    z[2,4,4]  R1754     -3.5607546567916870e-01
    z[2,4,4]  R1755     -2.8958949446678162e-01
    z[2,4,4]  R1756     -3.5417255759239197e-01
    z[2,4,4]  R1757     -2.1766684949398041e-01
    z[2,4,4]  R1758     -2.9416689649224281e-02
    z[2,4,4]  R1759     9.9350109696388245e-02
    z[2,4,4]  R1760     3.9517775177955627e-01
    z[2,4,4]  R1761     0.206630676984787
    z[2,4,4]  R1762     2.1284732222557068e-01
    z[2,4,4]  R1763     3.7563538551330566e-01
    z[2,4,4]  R1764     6.9434428215026855e-01
    z[2,4,4]  R1765     -4.8193059861660004e-02
    z[2,4,4]  R1766     2.4971835315227509e-01
    z[2,4,4]  R1767     0.300087571144104
    z[2,4,4]  R1768     -4.5681995153427124e-01
    z[2,4,4]  R1769     -4.3525260686874390e-01
    z[2,4,4]  R1770     1.1224637180566788e-01
    z[2,4,4]  R1771     4.8872217535972595e-01
    z[2,4,4]  R1772     2.8599053621292114e-01
    z[2,4,4]  R1773     -1.3222269713878632e-01
    z[2,4,4]  R1774     -4.7229605913162231e-01
    z[2,4,4]  R1775     -1.6047553718090057e-01
    z[2,4,4]  R1776     7.0403993129730225e-02
    z[2,4,4]  R1777     4.3914973735809326e-01
    z[2,4,4]  R1778     3.7198930978775024e-01
    z[2,4,4]  R1779     5.9806394577026367e-01
    z[2,4,4]  R1780     9.6880055963993073e-02
    z[2,4,4]  R1781     2.8017762303352356e-01
    z[2,4,4]  R1782     -2.7349710464477539e-01
    z[2,4,4]  R1783     1.7739698290824890e-01
    z[2,4,4]  R1784     -2.9830446466803551e-02
    z[2,4,4]  R1785     5.0163465738296509e-01
    z[2,4,4]  R1786     -2.0905299112200737e-02
    z[2,4,4]  R1787     9.0793631970882416e-02
    z[2,4,4]  R1788     -4.2723834514617920e-01
    z[2,4,4]  R1789     -3.7313145399093628e-01
    z[2,4,4]  R1790     -2.1621921658515930e-01
    z[2,4,4]  R1791     -9.6813194453716278e-02
    z[2,4,4]  R1792     3.7031877040863037e-01
    z[2,4,4]  R1793     6.5757364034652710e-02
    z[2,4,4]  R1794     -2.7775904163718224e-02
    z[2,4,4]  R1795     -1.0947525501251221e-01
    z[2,4,4]  R1796     -1.0854104906320572e-01
    z[2,4,4]  R1797     -2.5228586792945862e-01
    z[2,4,4]  R1798     -6.6569441556930542e-01
    z[2,4,4]  R1799     -1.9893574714660645e-01
    z[2,4,4]  R1800     1.3082090020179749e-01
    z[2,4,4]  R1801     3.8038212805986404e-02
    z[2,4,4]  R1802     -6.0758739709854126e-01
    z[2,4,4]  R1803     -1.3361072167754173e-02
    z[2,4,4]  R1804     8.8092230260372162e-02
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1686     -1
    z[2,4,5]  R1687     1
    z[2,4,5]  R1690     -5.7709765434265137e-01
    z[2,4,5]  R1691     -3.5071596503257751e-01
    z[2,4,5]  R1692     -0.278903067111969
    z[2,4,5]  R1693     5.8221589773893356e-02
    z[2,4,5]  R1694     -0.517057478427887
    z[2,4,5]  R1695     -1.5165178477764130e-01
    z[2,4,5]  R1696     -2.3012003302574158e-01
    z[2,4,5]  R1697     -1.0831041634082794e-01
    z[2,4,5]  R1698     -4.0791058540344238e-01
    z[2,4,5]  R1699     -7.4242120981216431e-01
    z[2,4,5]  R1700     3.2431101799011230e-01
    z[2,4,5]  R1701     1.3020985759794712e-02
    z[2,4,5]  R1702     1.7334592342376709e-01
    z[2,4,5]  R1703     2.3370157182216644e-01
    z[2,4,5]  R1704     3.6393117904663086e-01
    z[2,4,5]  R1705     3.2534962892532349e-01
    z[2,4,5]  R1706     0.166063129901886
    z[2,4,5]  R1707     9.8060876131057739e-02
    z[2,4,5]  R1708     2.5930896401405334e-01
    z[2,4,5]  R1709     2.8347793221473694e-01
    z[2,4,5]  R1710     -2.1221968531608582e-01
    z[2,4,5]  R1711     -2.6262289285659790e-01
    z[2,4,5]  R1712     3.7324330210685730e-01
    z[2,4,5]  R1713     1.0355718433856964e-01
    z[2,4,5]  R1714     -2.0006487146019936e-02
    z[2,4,5]  R1715     3.7442959845066071e-02
    z[2,4,5]  R1716     3.6605718731880188e-01
    z[2,4,5]  R1717     2.8392788767814636e-01
    z[2,4,5]  R1718     2.2410650551319122e-01
    z[2,4,5]  R1719     3.9185580611228943e-01
    z[2,4,5]  R1720     -4.6332050114870071e-02
    z[2,4,5]  R1721     -2.9014545679092407e-01
    z[2,4,5]  R1722     3.3672028779983521e-01
    z[2,4,5]  R1723     5.5800926685333252e-01
    z[2,4,5]  R1724     0.097394198179245
    z[2,4,5]  R1725     3.9934930391609669e-03
    z[2,4,5]  R1726     6.4718961715698242e-02
    z[2,4,5]  R1727     4.3009036779403687e-01
    z[2,4,5]  R1728     -1.2009969353675842e-01
    z[2,4,5]  R1729     0.0447159968316555
    z[2,4,5]  R1730     1.9053022563457489e-01
    z[2,4,5]  R1731     1.5491028130054474e-01
    z[2,4,5]  R1732     -4.1099965572357178e-01
    z[2,4,5]  R1733     -3.3980360627174377e-01
    z[2,4,5]  R1734     2.9551693797111511e-01
    z[2,4,5]  R1735     2.8076082468032837e-02
    z[2,4,5]  R1736     4.3349310755729675e-02
    z[2,4,5]  R1737     0.0949019193649292
    z[2,4,5]  R1738     -1.9856201112270355e-01
    z[2,4,5]  R1739     3.4327441453933716e-01
    z[2,4,5]  R1740     -0.295166552066803
    z[2,4,5]  R1741     -3.4717667102813721e-01
    z[2,4,5]  R1742     -3.6521118879318237e-01
    z[2,4,5]  R1743     -1.5804505348205566e-01
    z[2,4,5]  R1744     -6.1893957853317261e-01
    z[2,4,5]  R1745     2.2514855861663818e-01
    z[2,4,5]  R1746     -8.1602893769741058e-02
    z[2,4,5]  R1747     -3.0847036838531494e-01
    z[2,4,5]  R1748     -2.2324765101075172e-02
    z[2,4,5]  R1749     -1.1252982169389725e-01
    z[2,4,5]  R1750     -5.4488635063171387e-01
    z[2,4,5]  R1751     -2.3003305494785309e-01
    z[2,4,5]  R1752     8.4717579185962677e-02
    z[2,4,5]  R1753     -2.1322610974311829e-01
    z[2,4,5]  R1754     -3.1098678708076477e-01
    z[2,4,5]  R1755     -4.3563401699066162e-01
    z[2,4,5]  R1756     4.3798366189002991e-01
    z[2,4,5]  R1757     2.8272947669029236e-01
    z[2,4,5]  R1758     2.6798954606056213e-01
    z[2,4,5]  R1759     4.4543093442916870e-01
    z[2,4,5]  R1760     1.1807820200920105e-01
    z[2,4,5]  R1761     -2.0969074964523315e-01
    z[2,4,5]  R1762     0.584648609161377
    z[2,4,5]  R1763     4.6253389120101929e-01
    z[2,4,5]  R1764     1.1077541112899780e-01
    z[2,4,5]  R1765     3.1556141376495361e-01
    z[2,4,5]  R1766     1.1781197786331177e-01
    z[2,4,5]  R1767     3.8323265314102173e-01
    z[2,4,5]  R1768     5.9083163738250732e-01
    z[2,4,5]  R1769     5.3693127632141113e-01
    z[2,4,5]  R1770     1.5663637220859528e-01
    z[2,4,5]  R1771     4.1953021287918091e-01
    z[2,4,5]  R1772     2.4167820811271667e-01
    z[2,4,5]  R1773     2.1930266916751862e-01
    z[2,4,5]  R1774     2.1439573168754578e-01
    z[2,4,5]  R1775     2.9126736521720886e-01
    z[2,4,5]  R1776     1.5991058945655823e-01
    z[2,4,5]  R1777     9.4435155391693115e-02
    z[2,4,5]  R1778     2.6526299118995667e-01
    z[2,4,5]  R1779     3.2946422696113586e-01
    z[2,4,5]  R1780     -3.8344261050224304e-01
    z[2,4,5]  R1781     -2.4632996320724487e-01
    z[2,4,5]  R1782     -4.6027606725692749e-01
    z[2,4,5]  R1783     7.6073859818279743e-03
    z[2,4,5]  R1784     -1.3433896005153656e-01
    z[2,4,5]  R1785     1.5455786883831024e-01
    z[2,4,5]  R1786     -2.7092182636260986e-01
    z[2,4,5]  R1787     7.6671266555786133e-01
    z[2,4,5]  R1788     2.8965758159756660e-02
    z[2,4,5]  R1789     -1.5829353034496307e-01
    z[2,4,5]  R1790     -4.2344415187835693e-01
    z[2,4,5]  R1791     -3.0616271495819092e-01
    z[2,4,5]  R1792     -5.2750091999769211e-02
    z[2,4,5]  R1793     -8.3749219775199890e-02
    z[2,4,5]  R1794     3.5495933890342712e-01
    z[2,4,5]  R1795     2.2453854978084564e-01
    z[2,4,5]  R1796     1.8640884757041931e-01
    z[2,4,5]  R1797     -7.0749111473560333e-02
    z[2,4,5]  R1798     2.3678185045719147e-01
    z[2,4,5]  R1799     3.0017700791358948e-01
    z[2,4,5]  R1800     4.8381257057189941e-01
    z[2,4,5]  R1801     3.3239677548408508e-01
    z[2,4,5]  R1802     1.4385271072387695e-01
    z[2,4,5]  R1803     2.0954367518424988e-01
    z[2,4,5]  R1804     2.6355904340744019e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1688     -1
    z[2,4,6]  R1689     1
    z[2,4,6]  R1690     -1.7919200658798218e-01
    z[2,4,6]  R1691     1.1737052351236343e-01
    z[2,4,6]  R1692     -3.0322477221488953e-01
    z[2,4,6]  R1693     -7.3339521884918213e-02
    z[2,4,6]  R1694     -0.586080014705658
    z[2,4,6]  R1695     1.4169251918792725e-01
    z[2,4,6]  R1696     1.3314105570316315e-01
    z[2,4,6]  R1697     2.2169493138790131e-01
    z[2,4,6]  R1698     0.506830632686615
    z[2,4,6]  R1699     -2.3363646864891052e-01
    z[2,4,6]  R1700     4.2107634246349335e-02
    z[2,4,6]  R1701     -1.0225398838520050e-01
    z[2,4,6]  R1702     -1.1910647153854370e-01
    z[2,4,6]  R1703     -4.8612681031227112e-01
    z[2,4,6]  R1704     -1.8703129887580872e-01
    z[2,4,6]  R1705     1.1156961321830750e-01
    z[2,4,6]  R1706     -5.7398449629545212e-02
    z[2,4,6]  R1707     1.1197334527969360e-01
    z[2,4,6]  R1708     2.9366193339228630e-02
    z[2,4,6]  R1709     -8.4692798554897308e-02
    z[2,4,6]  R1710     3.4464153647422791e-01
    z[2,4,6]  R1711     -2.0486536622047424e-01
    z[2,4,6]  R1712     -0.359995037317276
    z[2,4,6]  R1713     6.2019795179367065e-02
    z[2,4,6]  R1714     -6.6353239119052887e-02
    z[2,4,6]  R1715     -4.7712358832359314e-01
    z[2,4,6]  R1716     -2.9085966944694519e-01
    z[2,4,6]  R1717     1.4768464863300323e-01
    z[2,4,6]  R1718     0.361070841550827
    z[2,4,6]  R1719     6.4369112253189087e-01
    z[2,4,6]  R1720     3.3611815422773361e-02
    z[2,4,6]  R1721     5.8424003422260284e-02
    z[2,4,6]  R1722     2.9420611262321472e-01
    z[2,4,6]  R1723     3.5556632280349731e-01
    z[2,4,6]  R1724     2.7982246875762939e-01
    z[2,4,6]  R1725     -1.7918157577514648e-01
    z[2,4,6]  R1726     -3.9160954952239990e-01
    z[2,4,6]  R1727     2.5816816091537476e-01
    z[2,4,6]  R1728     5.3819339722394943e-02
    z[2,4,6]  R1729     1.6115494072437286e-01
    z[2,4,6]  R1730     1.5988571941852570e-01
    z[2,4,6]  R1731     5.4371935129165649e-01
    z[2,4,6]  R1732     -2.3824411630630493e-01
    z[2,4,6]  R1733     0.0323464460670948
    z[2,4,6]  R1734     -3.2886481285095215e-01
    z[2,4,6]  R1735     -2.0483744144439697e-01
    z[2,4,6]  R1736     -6.2456015497446060e-02
    z[2,4,6]  R1737     -6.0060225427150726e-02
    z[2,4,6]  R1738     -3.7260480225086212e-02
    z[2,4,6]  R1739     -8.9438818395137787e-02
    z[2,4,6]  R1740     3.6358860135078430e-01
    z[2,4,6]  R1741     -1.4429277181625366e-01
    z[2,4,6]  R1742     2.7114427089691162e-01
    z[2,4,6]  R1743     -3.8851892948150635e-01
    z[2,4,6]  R1744     1.7991696298122406e-01
    z[2,4,6]  R1745     -2.3394417762756348e-01
    z[2,4,6]  R1746     0.236423060297966
    z[2,4,6]  R1747     -3.3040741086006165e-01
    z[2,4,6]  R1748     -2.5347569584846497e-01
    z[2,4,6]  R1749     -4.4116694480180740e-02
    z[2,4,6]  R1750     1.1758720874786377e-01
    z[2,4,6]  R1751     1.5814271569252014e-01
    z[2,4,6]  R1752     2.6673685759305954e-02
    z[2,4,6]  R1753     -3.2572884112596512e-02
    z[2,4,6]  R1754     1.0089663416147232e-01
    z[2,4,6]  R1755     3.9931874722242355e-02
    z[2,4,6]  R1756     2.9144637286663055e-02
    z[2,4,6]  R1757     -2.0908041298389435e-01
    z[2,4,6]  R1758     5.1410514116287231e-01
    z[2,4,6]  R1759     5.5026924610137939e-01
    z[2,4,6]  R1760     -0.227493554353714
    z[2,4,6]  R1761     -2.5993982329964638e-02
    z[2,4,6]  R1762     2.8447759151458740e-01
    z[2,4,6]  R1763     5.4953861236572266e-01
    z[2,4,6]  R1764     -2.9029166698455811e-01
    z[2,4,6]  R1765     1.8050950765609741e-01
    z[2,4,6]  R1766     4.4846269488334656e-01
    z[2,4,6]  R1767     -6.0303188860416412e-02
    z[2,4,6]  R1768     -2.7751579880714417e-01
    z[2,4,6]  R1769     0.000607263995334506
    z[2,4,6]  R1770     -8.4105335175991058e-02
    z[2,4,6]  R1771     -1.8866260349750519e-01
    z[2,4,6]  R1772     3.8933104276657104e-01
    z[2,4,6]  R1773     -2.7347257733345032e-01
    z[2,4,6]  R1774     -1.3086025416851044e-01
    z[2,4,6]  R1775     -9.8307356238365173e-02
    z[2,4,6]  R1776     2.1744383871555328e-01
    z[2,4,6]  R1777     5.4348301142454147e-02
    z[2,4,6]  R1778     7.5376674532890320e-02
    z[2,4,6]  R1779     1.1221068352460861e-01
    z[2,4,6]  R1780     2.9716029763221741e-01
    z[2,4,6]  R1781     -3.8691893219947815e-01
    z[2,4,6]  R1782     -3.4699544310569763e-01
    z[2,4,6]  R1783     9.0068168938159943e-02
    z[2,4,6]  R1784     -3.7443239241838455e-02
    z[2,4,6]  R1785     -0.259909987449646
    z[2,4,6]  R1786     -5.0366961956024170e-01
    z[2,4,6]  R1787     4.6736735850572586e-02
    z[2,4,6]  R1788     -1.0265648597851396e-03
    z[2,4,6]  R1789     -1.0762225091457367e-01
    z[2,4,6]  R1790     0.0696331113576889
    z[2,4,6]  R1791     3.1715276837348938e-01
    z[2,4,6]  R1792     2.2725264728069305e-01
    z[2,4,6]  R1793     -4.8621557652950287e-02
    z[2,4,6]  R1794     5.8099544048309326e-01
    z[2,4,6]  R1795     7.2574146091938019e-02
    z[2,4,6]  R1796     -2.1973720192909241e-01
    z[2,4,6]  R1797     -4.7050568461418152e-01
    z[2,4,6]  R1798     -7.0633783936500549e-02
    z[2,4,6]  R1799     0.336056649684906
    z[2,4,6]  R1800     -3.7884730100631714e-01
    z[2,4,6]  R1801     3.8792282342910767e-01
    z[2,4,6]  R1802     4.8093879222869873e-01
    z[2,4,6]  R1803     -2.1727073192596436e-01
    z[2,4,6]  R1804     2.2801366448402405e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1805     -1
    z[4,2,0]  R1806     1
    z[4,2,0]  R1819     -4.4537249207496643e-01
    z[4,2,0]  R1820     -5.1074630022048950e-01
    z[4,2,0]  R1821     -5.2198320627212524e-01
    z[4,2,0]  R1822     1.4921683818101883e-02
    z[4,2,0]  R1823     -9.6592712402343750e-01
    z[4,2,0]  R1824     8.0585852265357971e-02
    z[4,2,0]  R1825     -1.7927173525094986e-02
    z[4,2,0]  R1826     3.2609567046165466e-02
    z[4,2,0]  R1827     -2.4398061633110046e-01
    z[4,2,0]  R1828     -1.0867832228541374e-02
    z[4,2,0]  R1829     0.331209659576416
    z[4,2,0]  R1830     3.7573602795600891e-01
    z[4,2,0]  R1831     4.9842461943626404e-01
    z[4,2,0]  R1832     3.3839711546897888e-01
    z[4,2,0]  R1833     3.7496492266654968e-01
    z[4,2,0]  R1834     3.4600558876991272e-01
    z[4,2,0]  R1835     2.5181302428245544e-01
    z[4,2,0]  R1836     1.5387284755706787e-01
    z[4,2,0]  R1837     3.2433813810348511e-01
    z[4,2,0]  R1838     2.0987780392169952e-01
    z[4,2,0]  R1839     2.4177080392837524e-01
    z[4,2,0]  R1840     -1.7149411141872406e-01
    z[4,2,0]  R1841     -1.1276394070591778e-04
    z[4,2,0]  R1842     0.299360454082489
    z[4,2,0]  R1843     1.8625383079051971e-01
    z[4,2,0]  R1844     -2.6873114705085754e-01
    z[4,2,0]  R1845     -3.2073151320219040e-02
    z[4,2,0]  R1846     3.7537875771522522e-01
    z[4,2,0]  R1847     3.6279532313346863e-01
    z[4,2,0]  R1848     2.7410724759101868e-01
    z[4,2,0]  R1849     3.4550437331199646e-01
    z[4,2,0]  R1850     -3.4611618518829346e-01
    z[4,2,0]  R1851     -1.3425517082214355e-01
    z[4,2,0]  R1852     -3.1043639779090881e-01
    z[4,2,0]  R1853     -2.7002862095832825e-01
    z[4,2,0]  R1854     -6.6402232646942139e-01
    z[4,2,0]  R1855     -9.0399205684661865e-01
    z[4,2,0]  R1856     -0.804214358329773
    z[4,2,0]  R1857     -7.4929600954055786e-01
    z[4,2,0]  R1858     -5.9058940410614014e-01
    z[4,2,0]  R1859     -1.7309513350483030e-04
    z[4,2,0]  R1860     6.1451070010662079e-02
    z[4,2,0]  R1861     2.2709189355373383e-01
    z[4,2,0]  R1862     -1.8552179634571075e-01
    z[4,2,0]  R1863     -3.4881201386451721e-01
    z[4,2,0]  R1864     1.3089212775230408e-01
    z[4,2,0]  R1865     -3.5005442332476377e-03
    z[4,2,0]  R1866     5.3854632377624512e-01
    z[4,2,0]  R1867     4.9122610688209534e-01
    z[4,2,0]  R1868     4.4492509961128235e-01
    z[4,2,0]  R1869     2.5517001748085022e-01
    z[4,2,0]  R1870     5.1593577861785889e-01
    z[4,2,0]  R1871     -2.5728667154908180e-02
    z[4,2,0]  R1872     8.3634227514266968e-02
    z[4,2,0]  R1873     3.6626616120338440e-01
    z[4,2,0]  R1874     -8.9695248752832413e-03
    z[4,2,0]  R1875     1.5972553193569183e-01
    z[4,2,0]  R1876     -5.3645157814025879e-01
    z[4,2,0]  R1877     6.3105231523513794e-01
    z[4,2,0]  R1878     -4.2418235540390015e-01
    z[4,2,0]  R1879     5.4071956872940063e-01
    z[4,2,0]  R1880     2.4172581732273102e-01
    z[4,2,0]  R1881     6.0971105098724365e-01
    z[4,2,0]  R1882     1.7035140097141266e-01
    z[4,2,0]  R1883     7.2460480034351349e-02
    z[4,2,0]  R1884     -6.7582845687866211e-01
    z[4,2,0]  R1885     -6.0512125492095947e-01
    z[4,2,0]  R1886     1.4272104203701019e-01
    z[4,2,0]  R1887     -7.2260481119155884e-01
    z[4,2,0]  R1888     6.4754843711853027e-01
    z[4,2,0]  R1889     7.0424085855484009e-01
    z[4,2,0]  R1890     8.7252952158451080e-02
    z[4,2,0]  R1891     1.3760389387607574e-01
    z[4,2,0]  R1892     4.6381881833076477e-01
    z[4,2,0]  R1893     -1.3176780939102173e-01
    z[4,2,0]  R1894     2.5867810845375061e-01
    z[4,2,0]  R1895     9.8589166998863220e-02
    z[4,2,0]  R1896     -1.6886758804321289e-01
    z[4,2,0]  R1897     -2.4934832006692886e-02
    z[4,2,0]  R1898     -2.7765434980392456e-01
    z[4,2,0]  R1899     -7.5552088022232056e-01
    z[4,2,0]  R1900     -8.4898811578750610e-01
    z[4,2,0]  R1901     3.0848824977874756e-01
    z[4,2,0]  R1902     -4.2343363165855408e-01
    z[4,2,0]  R1903     3.1179559230804443e-01
    z[4,2,0]  R1904     3.2969641685485840e-01
    z[4,2,0]  R1905     3.4860834479331970e-01
    z[4,2,0]  R1906     -4.5325347781181335e-01
    z[4,2,0]  R1907     -0.422927588224411
    z[4,2,0]  R1908     -5.0999581813812256e-01
    z[4,2,0]  R1909     -2.6431143283843994e-01
    z[4,2,0]  R1910     4.9214616417884827e-02
    z[4,2,0]  R1911     1.9649212062358856e-01
    z[4,2,0]  R1912     0.422234445810318
    z[4,2,0]  R1913     2.4938111007213593e-01
    z[4,2,0]  R1914     8.8419675827026367e-02
    z[4,2,0]  R1915     4.0276327729225159e-01
    z[4,2,0]  R1916     0.631734311580658
    z[4,2,0]  R1917     5.6486970186233521e-01
    z[4,2,0]  R1918     5.7851821184158325e-01
    z[4,2,0]  R1919     4.3736633658409119e-01
    z[4,2,0]  R1920     2.5934025645256042e-01
    z[4,2,0]  R1921     5.0061064958572388e-01
    z[4,2,0]  R1922     1.2580172717571259e-01
    z[4,2,0]  R1923     2.9341140389442444e-01
    z[4,2,0]  R1924     4.2084982991218567e-01
    z[4,2,0]  R1925     1.8046663701534271e-01
    z[4,2,0]  R1926     3.0953222513198853e-01
    z[4,2,0]  R1927     2.5165063142776489e-01
    z[4,2,0]  R1928     1.2470825761556625e-01
    z[4,2,0]  R1929     5.1459338515996933e-02
    z[4,2,0]  R1930     2.2383508086204529e-01
    z[4,2,0]  R1931     1.8951010704040527e-01
    z[4,2,0]  R1932     -5.1455962657928467e-01
    z[4,2,0]  R1933     -0.131059467792511
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1807     -1
    z[4,2,1]  R1808     1
    z[4,2,1]  R1819     0.665277361869812
    z[4,2,1]  R1820     5.7158994674682617e-01
    z[4,2,1]  R1821     4.0337088704109192e-01
    z[4,2,1]  R1822     7.5647455453872681e-01
    z[4,2,1]  R1823     7.8719764947891235e-02
    z[4,2,1]  R1824     -6.6353100538253784e-01
    z[4,2,1]  R1825     -5.6738960742950439e-01
    z[4,2,1]  R1826     -0.539656400680542
    z[4,2,1]  R1827     -7.3659688234329224e-01
    z[4,2,1]  R1828     2.8826889395713806e-01
    z[4,2,1]  R1829     -7.7573865652084351e-01
    z[4,2,1]  R1830     -7.6019245386123657e-01
    z[4,2,1]  R1831     -6.0532516241073608e-01
    z[4,2,1]  R1832     -7.0515912771224976e-01
    z[4,2,1]  R1833     -6.2775951623916626e-01
    z[4,2,1]  R1834     -6.5205973386764526e-01
    z[4,2,1]  R1835     -7.5500094890594482e-01
    z[4,2,1]  R1836     -0.685711681842804
    z[4,2,1]  R1837     -5.7793557643890381e-01
    z[4,2,1]  R1838     -6.6598445177078247e-01
    z[4,2,1]  R1839     -6.6299033164978027e-01
    z[4,2,1]  R1840     2.1881558932363987e-03
    z[4,2,1]  R1841     1.9273987039923668e-02
    z[4,2,1]  R1842     5.7013678550720215e-01
    z[4,2,1]  R1843     6.1896014213562012e-01
    z[4,2,1]  R1844     -2.1588015556335449e-01
    z[4,2,1]  R1845     1.7628110945224762e-01
    z[4,2,1]  R1846     -2.3755583167076111e-01
    z[4,2,1]  R1847     2.0479236543178558e-01
    z[4,2,1]  R1848     -1.3154593110084534e-01
    z[4,2,1]  R1849     1.9905219972133636e-01
    z[4,2,1]  R1850     -4.1699981689453125e-01
    z[4,2,1]  R1851     -3.0128517746925354e-01
    z[4,2,1]  R1852     -7.6194740831851959e-02
    z[4,2,1]  R1853     0.209869846701622
    z[4,2,1]  R1854     -4.0960386395454407e-01
    z[4,2,1]  R1855     -1.5778750181198120e-01
    z[4,2,1]  R1856     -2.4455009400844574e-01
    z[4,2,1]  R1857     -2.5556573271751404e-01
    z[4,2,1]  R1858     -3.8000097870826721e-01
    z[4,2,1]  R1859     1.2717936933040619e-01
    z[4,2,1]  R1860     1.5552307665348053e-01
    z[4,2,1]  R1861     3.5584294237196445e-03
    z[4,2,1]  R1862     3.0309504270553589e-01
    z[4,2,1]  R1863     0.143227681517601
    z[4,2,1]  R1864     6.7356717586517334e-01
    z[4,2,1]  R1865     8.2480198144912720e-01
    z[4,2,1]  R1866     5.6491744518280029e-01
    z[4,2,1]  R1867     -7.3912781476974487e-01
    z[4,2,1]  R1868     -6.5501809120178223e-01
    z[4,2,1]  R1869     -5.0831407308578491e-01
    z[4,2,1]  R1870     -5.9823578596115112e-01
    z[4,2,1]  R1871     8.8219058513641357e-01
    z[4,2,1]  R1872     8.8769757747650146e-01
    z[4,2,1]  R1873     4.5806637406349182e-01
    z[4,2,1]  R1874     1.8596200644969940e-01
    z[4,2,1]  R1875     7.1757632493972778e-01
    z[4,2,1]  R1876     -3.8152185082435608e-01
    z[4,2,1]  R1877     1.4021593332290649e-01
    z[4,2,1]  R1878     -3.7752085924148560e-01
    z[4,2,1]  R1879     0.69268798828125
    z[4,2,1]  R1880     -6.1385488510131836e-01
    z[4,2,1]  R1881     6.0728186368942261e-01
    z[4,2,1]  R1882     -4.8250687122344971e-01
    z[4,2,1]  R1883     -7.0133811235427856e-01
    z[4,2,1]  R1884     -5.4359430074691772e-01
    z[4,2,1]  R1885     -4.9089613556861877e-01
    z[4,2,1]  R1886     2.6800769567489624e-01
    z[4,2,1]  R1887     -4.0371596813201904e-01
    z[4,2,1]  R1888     0.409095823764801
    z[4,2,1]  R1889     6.2194281816482544e-01
    z[4,2,1]  R1890     -3.8345479965209961e-01
    z[4,2,1]  R1891     9.3600398302078247e-01
    z[4,2,1]  R1892     -5.5373638868331909e-01
    z[4,2,1]  R1893     9.1260397434234619e-01
    z[4,2,1]  R1894     1.5924791991710663e-01
    z[4,2,1]  R1895     3.9333915710449219e-01
    z[4,2,1]  R1896     3.0031278729438782e-01
    z[4,2,1]  R1897     6.2737494707107544e-01
    z[4,2,1]  R1898     2.1992325782775879e-01
    z[4,2,1]  R1899     -4.1509312391281128e-01
    z[4,2,1]  R1900     -4.1287493705749512e-01
    z[4,2,1]  R1901     8.0462110042572021e-01
    z[4,2,1]  R1902     -3.6295115947723389e-01
    z[4,2,1]  R1903     -6.9650501012802124e-01
    z[4,2,1]  R1904     -6.7203216254711151e-02
    z[4,2,1]  R1905     8.0494272708892822e-01
    z[4,2,1]  R1906     -3.9140564203262329e-01
    z[4,2,1]  R1907     4.6580326557159424e-01
    z[4,2,1]  R1908     3.8096180558204651e-01
    z[4,2,1]  R1909     1.5873104333877563e-01
    z[4,2,1]  R1910     1.4601269364356995e-01
    z[4,2,1]  R1911     2.3214745521545410e-01
    z[4,2,1]  R1912     -5.8443200588226318e-01
    z[4,2,1]  R1913     -4.8416009545326233e-01
    z[4,2,1]  R1914     -4.8915907740592957e-01
    z[4,2,1]  R1915     -5.4353523254394531e-01
    z[4,2,1]  R1916     3.3106356859207153e-01
    z[4,2,1]  R1917     0.0721365436911583
    z[4,2,1]  R1918     2.4072538316249847e-01
    z[4,2,1]  R1919     -4.7887992858886719e-01
    z[4,2,1]  R1920     -3.7768241763114929e-01
    z[4,2,1]  R1921     -3.6895516514778137e-01
    z[4,2,1]  R1922     -3.3499330282211304e-01
    z[4,2,1]  R1923     -2.3496727645397186e-01
    z[4,2,1]  R1924     -0.631965160369873
    z[4,2,1]  R1925     -5.7080310583114624e-01
    z[4,2,1]  R1926     -4.0810176730155945e-01
    z[4,2,1]  R1927     -2.2940079867839813e-01
    z[4,2,1]  R1928     -2.9745447635650635e-01
    z[4,2,1]  R1929     -1.1915975809097290e-01
    z[4,2,1]  R1930     6.0840494930744171e-02
    z[4,2,1]  R1931     -2.8783810138702393e-01
    z[4,2,1]  R1932     6.6480404138565063e-01
    z[4,2,1]  R1933     5.4802858829498291e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1809     -1
    z[4,2,2]  R1810     1
    z[4,2,2]  R1819     -3.3246603608131409e-01
    z[4,2,2]  R1820     -3.3024686574935913e-01
    z[4,2,2]  R1821     -3.8213226199150085e-01
    z[4,2,2]  R1822     -5.9999954700469971e-01
    z[4,2,2]  R1823     -1.8448592722415924e-01
    z[4,2,2]  R1824     4.5519477128982544e-01
    z[4,2,2]  R1825     -1.3045579195022583e-01
    z[4,2,2]  R1826     -2.9634529352188110e-01
    z[4,2,2]  R1827     4.5163431763648987e-01
    z[4,2,2]  R1828     0.0443992018699646
    z[4,2,2]  R1829     4.3069524690508842e-03
    z[4,2,2]  R1830     -2.0378093421459198e-01
    z[4,2,2]  R1831     -2.0583665370941162e-01
    z[4,2,2]  R1832     -0.601309597492218
    z[4,2,2]  R1833     7.6408926397562027e-03
    z[4,2,2]  R1834     -2.1865795552730560e-01
    z[4,2,2]  R1835     -5.1944029331207275e-01
    z[4,2,2]  R1836     2.9603847861289978e-01
    z[4,2,2]  R1837     -1.8319685757160187e-01
    z[4,2,2]  R1838     5.0144165754318237e-01
    z[4,2,2]  R1839     3.1911796331405640e-01
    z[4,2,2]  R1840     -5.3569239377975464e-01
    z[4,2,2]  R1841     -5.2974373102188110e-01
    z[4,2,2]  R1842     3.3966198563575745e-01
    z[4,2,2]  R1843     6.2364935874938965e-01
    z[4,2,2]  R1844     -3.9520934224128723e-01
    z[4,2,2]  R1845     -6.5507078170776367e-01
    z[4,2,2]  R1846     -6.7343634366989136e-01
    z[4,2,2]  R1847     -7.1022748947143555e-01
    z[4,2,2]  R1848     -3.5012489557266235e-01
    z[4,2,2]  R1849     -2.4349214136600494e-01
    z[4,2,2]  R1850     -7.4231493473052979e-01
    z[4,2,2]  R1851     -5.1035708189010620e-01
    z[4,2,2]  R1852     -4.5079621672630310e-01
    z[4,2,2]  R1853     -3.3830073475837708e-01
    z[4,2,2]  R1854     2.1875385940074921e-01
    z[4,2,2]  R1855     3.3716621994972229e-01
    z[4,2,2]  R1856     4.4088739156723022e-01
    z[4,2,2]  R1857     2.2630555927753448e-01
    z[4,2,2]  R1858     5.4999870061874390e-01
    z[4,2,2]  R1859     8.7424147129058838e-01
    z[4,2,2]  R1860     9.4849610328674316e-01
    z[4,2,2]  R1861     9.5662963390350342e-01
    z[4,2,2]  R1862     8.9228767156600952e-01
    z[4,2,2]  R1863     8.1086415052413940e-01
    z[4,2,2]  R1864     -4.1185855865478516e-01
    z[4,2,2]  R1865     -1.9162485376000404e-02
    z[4,2,2]  R1866     2.8008872270584106e-01
    z[4,2,2]  R1867     4.0162590146064758e-01
    z[4,2,2]  R1868     4.4733661413192749e-01
    z[4,2,2]  R1869     0.568046510219574
    z[4,2,2]  R1870     2.8434932231903076e-01
    z[4,2,2]  R1871     3.1677380204200745e-01
    z[4,2,2]  R1872     1.1546524614095688e-01
    z[4,2,2]  R1873     -1.6543051600456238e-01
    z[4,2,2]  R1874     -0.0796266719698906
    z[4,2,2]  R1875     -2.9266723990440369e-01
    z[4,2,2]  R1876     -2.8603881597518921e-01
    z[4,2,2]  R1877     -3.5321470350027084e-02
    z[4,2,2]  R1878     1.1452263593673706e-01
    z[4,2,2]  R1879     1.4027774333953857e-02
    z[4,2,2]  R1880     0.628491997718811
    z[4,2,2]  R1881     3.4253127872943878e-02
    z[4,2,2]  R1882     6.6206520795822144e-01
    z[4,2,2]  R1883     6.2908381223678589e-01
    z[4,2,2]  R1884     2.9503282904624939e-01
    z[4,2,2]  R1885     -1.2889644131064415e-02
    z[4,2,2]  R1886     -3.6238917708396912e-01
    z[4,2,2]  R1887     -1.2910751998424530e-01
    z[4,2,2]  R1888     2.9581716284155846e-02
    z[4,2,2]  R1889     -5.8643147349357605e-02
    z[4,2,2]  R1890     7.1621578931808472e-01
    z[4,2,2]  R1891     1.7335261404514313e-01
    z[4,2,2]  R1892     0.579522430896759
    z[4,2,2]  R1893     -1.2586662545800209e-02
    z[4,2,2]  R1894     -0.60338294506073
    z[4,2,2]  R1895     -2.8439977765083313e-01
    z[4,2,2]  R1896     -5.1153934001922607e-01
    z[4,2,2]  R1897     -1.1169648915529251e-01
    z[4,2,2]  R1898     -5.5183249711990356e-01
    z[4,2,2]  R1899     -7.1597069501876831e-02
    z[4,2,2]  R1900     7.9120278358459473e-02
    z[4,2,2]  R1901     -3.7630371749401093e-02
    z[4,2,2]  R1902     1.3049761950969696e-01
    z[4,2,2]  R1903     6.2702363729476929e-01
    z[4,2,2]  R1904     -7.2930544614791870e-01
    z[4,2,2]  R1905     -3.3465901017189026e-01
    z[4,2,2]  R1906     3.6644306033849716e-02
    z[4,2,2]  R1907     7.0993721485137939e-01
    z[4,2,2]  R1908     0.539761483669281
    z[4,2,2]  R1909     0.705171525478363
    z[4,2,2]  R1910     9.0713568031787872e-02
    z[4,2,2]  R1911     -1.1441487073898315e-01
    z[4,2,2]  R1912     3.7345755100250244e-01
    z[4,2,2]  R1913     4.0972551703453064e-01
    z[4,2,2]  R1914     7.2683101892471313e-01
    z[4,2,2]  R1915     6.2340795993804932e-01
    z[4,2,2]  R1916     1.4043259620666504e-01
    z[4,2,2]  R1917     -1.3547022640705109e-01
    z[4,2,2]  R1918     1.2957191467285156e-01
    z[4,2,2]  R1919     4.8817488551139832e-01
    z[4,2,2]  R1920     5.4580259323120117e-01
    z[4,2,2]  R1921     4.9789234995841980e-01
    z[4,2,2]  R1922     -2.2322230041027069e-01
    z[4,2,2]  R1923     -2.6471281051635742e-01
    z[4,2,2]  R1924     6.1506575345993042e-01
    z[4,2,2]  R1925     4.2768985033035278e-01
    z[4,2,2]  R1926     5.0138247013092041e-01
    z[4,2,2]  R1927     -1.3325053453445435e-01
    z[4,2,2]  R1928     -8.8966287672519684e-02
    z[4,2,2]  R1929     1.1987017840147018e-01
    z[4,2,2]  R1930     -2.1370720863342285e-01
    z[4,2,2]  R1931     -1.6838872432708740e-01
    z[4,2,2]  R1932     2.0024140179157257e-01
    z[4,2,2]  R1933     4.3591436743736267e-01
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1811     -1
    z[4,2,3]  R1812     1
    z[4,2,3]  R1819     6.1623834073543549e-02
    z[4,2,3]  R1820     1.2031611055135727e-01
    z[4,2,3]  R1821     -1.0835071653127670e-01
    z[4,2,3]  R1822     1.6698566079139709e-01
    z[4,2,3]  R1823     -8.0087609589099884e-02
    z[4,2,3]  R1824     5.4327648133039474e-02
    z[4,2,3]  R1825     -5.7724362611770630e-01
    z[4,2,3]  R1826     1.4700695872306824e-01
    z[4,2,3]  R1827     1.0272392630577087e-01
    z[4,2,3]  R1828     8.5961920022964478e-01
    z[4,2,3]  R1829     -2.4001386761665344e-01
    z[4,2,3]  R1830     1.8896806240081787e-01
    z[4,2,3]  R1831     -0.388874351978302
    z[4,2,3]  R1832     1.1385331302881241e-01
    z[4,2,3]  R1833     3.0618848279118538e-02
    z[4,2,3]  R1834     5.8276718854904175e-01
    z[4,2,3]  R1835     -4.3951552361249924e-02
    z[4,2,3]  R1836     3.5840559005737305e-01
    z[4,2,3]  R1837     1.5175801515579224e-01
    z[4,2,3]  R1838     1.3548615574836731e-01
    z[4,2,3]  R1839     -7.3759861290454865e-02
    z[4,2,3]  R1840     -6.4899915456771851e-01
    z[4,2,3]  R1841     -3.1279709935188293e-01
    z[4,2,3]  R1842     -6.1535632610321045e-01
    z[4,2,3]  R1843     -2.5307220220565796e-01
    z[4,2,3]  R1844     5.8361768722534180e-01
    z[4,2,3]  R1845     4.6935808658599854e-01
    z[4,2,3]  R1846     4.0347889065742493e-01
    z[4,2,3]  R1847     5.5925935506820679e-01
    z[4,2,3]  R1848     4.1561439633369446e-01
    z[4,2,3]  R1849     8.5939311981201172e-01
    z[4,2,3]  R1850     0.275499552488327
    z[4,2,3]  R1851     7.4122303724288940e-01
    z[4,2,3]  R1852     5.0755894184112549e-01
    z[4,2,3]  R1853     1.4604271948337555e-01
    z[4,2,3]  R1854     -4.8070603609085083e-01
    z[4,2,3]  R1855     -0.170390784740448
    z[4,2,3]  R1856     3.8864649832248688e-02
    z[4,2,3]  R1857     -0.148195281624794
    z[4,2,3]  R1858     -0.068141870200634
    z[4,2,3]  R1859     0.0461047999560833
    z[4,2,3]  R1860     7.8676626086235046e-02
    z[4,2,3]  R1861     1.0513123869895935e-01
    z[4,2,3]  R1862     0.0667092427611351
    z[4,2,3]  R1863     2.0522156357765198e-01
    z[4,2,3]  R1864     -2.3449407517910004e-01
    z[4,2,3]  R1865     -1.1086897552013397e-01
    z[4,2,3]  R1866     1.3058193027973175e-01
    z[4,2,3]  R1867     -1.5165399014949799e-01
    z[4,2,3]  R1868     -3.3748653531074524e-01
    z[4,2,3]  R1869     -3.0212721228599548e-01
    z[4,2,3]  R1870     -1.4454054832458496e-01
    z[4,2,3]  R1871     -0.0949816182255745
    z[4,2,3]  R1872     -0.00844635721296072
    z[4,2,3]  R1873     -0.072464220225811
    z[4,2,3]  R1874     2.6678740978240967e-01
    z[4,2,3]  R1875     1.5070120804011822e-02
    z[4,2,3]  R1876     -5.3139245510101318e-01
    z[4,2,3]  R1877     -2.8727075085043907e-02
    z[4,2,3]  R1878     -9.5711521804332733e-02
    z[4,2,3]  R1879     -7.4008852243423462e-02
    z[4,2,3]  R1880     9.4357088208198547e-02
    z[4,2,3]  R1881     -5.3052004426717758e-02
    z[4,2,3]  R1882     -2.3163458704948425e-01
    z[4,2,3]  R1883     2.2300805151462555e-01
    z[4,2,3]  R1884     1.6113524138927460e-01
    z[4,2,3]  R1885     -2.3640665411949158e-01
    z[4,2,3]  R1886     -3.4317496418952942e-01
    z[4,2,3]  R1887     -3.7083217501640320e-01
    z[4,2,3]  R1888     -9.3176349997520447e-02
    z[4,2,3]  R1889     -7.2438023984432220e-02
    z[4,2,3]  R1890     -3.0139824748039246e-01
    z[4,2,3]  R1891     -1.7185065150260925e-01
    z[4,2,3]  R1892     -1.4382113516330719e-01
    z[4,2,3]  R1893     -1.5414026379585266e-01
    z[4,2,3]  R1894     2.1110512316226959e-01
    z[4,2,3]  R1895     -3.6252435296773911e-02
    z[4,2,3]  R1896     -0.321154922246933
    z[4,2,3]  R1897     1.9282083213329315e-01
    z[4,2,3]  R1898     -1.6128194332122803e-01
    z[4,2,3]  R1899     -1.8521138699725270e-03
    z[4,2,3]  R1900     -1.4850957691669464e-01
    z[4,2,3]  R1901     2.2216208279132843e-01
    z[4,2,3]  R1902     -1.8443416059017181e-01
    z[4,2,3]  R1903     -5.6029386818408966e-02
    z[4,2,3]  R1904     1.2959238886833191e-01
    z[4,2,3]  R1905     4.5644771307706833e-02
    z[4,2,3]  R1906     -1.8064694106578827e-01
    z[4,2,3]  R1907     8.3385735750198364e-02
    z[4,2,3]  R1908     2.6409700512886047e-01
    z[4,2,3]  R1909     3.6392763257026672e-01
    z[4,2,3]  R1910     -0.806171178817749
    z[4,2,3]  R1911     -8.5051637887954712e-01
    z[4,2,3]  R1912     6.0818102210760117e-02
    z[4,2,3]  R1913     -1.5635755658149719e-01
    z[4,2,3]  R1914     -5.2543841302394867e-02
    z[4,2,3]  R1915     -2.5762656331062317e-01
    z[4,2,3]  R1916     5.9513457119464874e-02
    z[4,2,3]  R1917     1.8277665600180626e-02
    z[4,2,3]  R1918     1.0919960588216782e-01
    z[4,2,3]  R1919     -4.5451596379280090e-01
    z[4,2,3]  R1920     -4.6350872516632080e-01
    z[4,2,3]  R1921     3.5328158736228943e-01
    z[4,2,3]  R1922     -4.3283212184906006e-01
    z[4,2,3]  R1923     -5.5757224559783936e-01
    z[4,2,3]  R1924     -3.1490195542573929e-02
    z[4,2,3]  R1925     -9.0821079909801483e-02
    z[4,2,3]  R1926     -4.4099974632263184e-01
    z[4,2,3]  R1927     -8.5201394557952881e-01
    z[4,2,3]  R1928     -7.7582234144210815e-01
    z[4,2,3]  R1929     -0.92115718126297
    z[4,2,3]  R1930     -9.0703666210174561e-01
    z[4,2,3]  R1931     -8.0508148670196533e-01
    z[4,2,3]  R1932     1.9683811068534851e-01
    z[4,2,3]  R1933     -1.1682634800672531e-01
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1813     -1
    z[4,2,4]  R1814     1
    z[4,2,4]  R1819     9.6880055963993073e-02
    z[4,2,4]  R1820     2.8017762303352356e-01
    z[4,2,4]  R1821     -2.7349710464477539e-01
    z[4,2,4]  R1822     1.7739698290824890e-01
    z[4,2,4]  R1823     -2.9830446466803551e-02
    z[4,2,4]  R1824     5.0163465738296509e-01
    z[4,2,4]  R1825     -2.0905299112200737e-02
    z[4,2,4]  R1826     9.0793631970882416e-02
    z[4,2,4]  R1827     -4.2723834514617920e-01
    z[4,2,4]  R1828     -3.7313145399093628e-01
    z[4,2,4]  R1829     -2.1621921658515930e-01
    z[4,2,4]  R1830     -9.6813194453716278e-02
    z[4,2,4]  R1831     3.7031877040863037e-01
    z[4,2,4]  R1832     6.5757364034652710e-02
    z[4,2,4]  R1833     -2.7775904163718224e-02
    z[4,2,4]  R1834     -1.0947525501251221e-01
    z[4,2,4]  R1835     -1.0854104906320572e-01
    z[4,2,4]  R1836     -2.5228586792945862e-01
    z[4,2,4]  R1837     -6.6569441556930542e-01
    z[4,2,4]  R1838     -1.9893574714660645e-01
    z[4,2,4]  R1839     1.3082090020179749e-01
    z[4,2,4]  R1840     3.8038212805986404e-02
    z[4,2,4]  R1841     -6.0758739709854126e-01
    z[4,2,4]  R1842     -1.3361072167754173e-02
    z[4,2,4]  R1843     8.8092230260372162e-02
    z[4,2,4]  R1844     -1.3866421580314636e-01
    z[4,2,4]  R1845     0.4262675344944
    z[4,2,4]  R1846     1.2889516353607178e-01
    z[4,2,4]  R1847     -2.1842949092388153e-02
    z[4,2,4]  R1848     -3.7414006888866425e-02
    z[4,2,4]  R1849     -9.2173544690012932e-03
    z[4,2,4]  R1850     9.3282364308834076e-02
    z[4,2,4]  R1851     1.4299346506595612e-01
    z[4,2,4]  R1852     1.1714073270559311e-01
    z[4,2,4]  R1853     3.7614884972572327e-01
    z[4,2,4]  R1854     0.0735994279384613
    z[4,2,4]  R1855     6.7542046308517456e-02
    z[4,2,4]  R1856     2.3088328540325165e-01
    z[4,2,4]  R1857     -9.5550626516342163e-02
    z[4,2,4]  R1858     -1.7954094707965851e-01
    z[4,2,4]  R1859     3.1480357050895691e-01
    z[4,2,4]  R1860     1.8796192109584808e-01
    z[4,2,4]  R1861     8.3698770031332970e-03
    z[4,2,4]  R1862     0.0705980509519577
    z[4,2,4]  R1863     2.6583236455917358e-01
    z[4,2,4]  R1864     -3.7515938282012939e-01
    z[4,2,4]  R1865     -4.4282034039497375e-01
    z[4,2,4]  R1866     -1.6256643831729889e-01
    z[4,2,4]  R1867     1.1624976247549057e-01
    z[4,2,4]  R1868     2.3277167975902557e-01
    z[4,2,4]  R1869     1.8302576243877411e-01
    z[4,2,4]  R1870     2.3575511574745178e-01
    z[4,2,4]  R1871     -9.6358023583889008e-02
    z[4,2,4]  R1872     1.0487534105777740e-01
    z[4,2,4]  R1873     -2.3561987280845642e-01
    z[4,2,4]  R1874     -9.4050276279449463e-01
    z[4,2,4]  R1875     -5.3487664461135864e-01
    z[4,2,4]  R1876     -5.0266232341527939e-02
    z[4,2,4]  R1877     -3.7714448571205139e-01
    z[4,2,4]  R1878     7.5331604480743408e-01
    z[4,2,4]  R1879     4.3590095639228821e-01
    z[4,2,4]  R1880     5.7433921843767166e-02
    z[4,2,4]  R1881     -0.0620078481733799
    z[4,2,4]  R1882     4.7839531302452087e-01
    z[4,2,4]  R1883     1.7153675854206085e-01
    z[4,2,4]  R1884     -2.6997578144073486e-01
    z[4,2,4]  R1885     1.3102343678474426e-01
    z[4,2,4]  R1886     -6.5804773569107056e-01
    z[4,2,4]  R1887     -2.1013745665550232e-01
    z[4,2,4]  R1888     -0.456379771232605
    z[4,2,4]  R1889     2.5651317834854126e-01
    z[4,2,4]  R1890     4.8555487394332886e-01
    z[4,2,4]  R1891     0.181008979678154
    z[4,2,4]  R1892     -2.8443282842636108e-01
    z[4,2,4]  R1893     -6.0795680619776249e-03
    z[4,2,4]  R1894     -5.2893245220184326e-01
    z[4,2,4]  R1895     -7.8231376409530640e-01
    z[4,2,4]  R1896     -5.5640321969985962e-01
    z[4,2,4]  R1897     -6.1660176515579224e-01
    z[4,2,4]  R1898     -3.5854494571685791e-01
    z[4,2,4]  R1899     3.8253688812255859e-01
    z[4,2,4]  R1900     -1.3372954726219177e-01
    z[4,2,4]  R1901     4.8215255141258240e-02
    z[4,2,4]  R1902     -7.5708419084548950e-01
    z[4,2,4]  R1903     -8.2201175391674042e-02
    z[4,2,4]  R1904     -1.6545540094375610e-01
    z[4,2,4]  R1905     -1.9630345702171326e-01
    z[4,2,4]  R1906     -0.774272620677948
    z[4,2,4]  R1907     2.1603046357631683e-01
    z[4,2,4]  R1908     -3.5607546567916870e-01
    z[4,2,4]  R1909     -2.8958949446678162e-01
    z[4,2,4]  R1910     -3.5417255759239197e-01
    z[4,2,4]  R1911     -2.1766684949398041e-01
    z[4,2,4]  R1912     -2.9416689649224281e-02
    z[4,2,4]  R1913     9.9350109696388245e-02
    z[4,2,4]  R1914     3.9517775177955627e-01
    z[4,2,4]  R1915     0.206630676984787
    z[4,2,4]  R1916     2.1284732222557068e-01
    z[4,2,4]  R1917     3.7563538551330566e-01
    z[4,2,4]  R1918     6.9434428215026855e-01
    z[4,2,4]  R1919     -4.8193059861660004e-02
    z[4,2,4]  R1920     2.4971835315227509e-01
    z[4,2,4]  R1921     0.300087571144104
    z[4,2,4]  R1922     -4.5681995153427124e-01
    z[4,2,4]  R1923     -4.3525260686874390e-01
    z[4,2,4]  R1924     1.1224637180566788e-01
    z[4,2,4]  R1925     4.8872217535972595e-01
    z[4,2,4]  R1926     2.8599053621292114e-01
    z[4,2,4]  R1927     -1.3222269713878632e-01
    z[4,2,4]  R1928     -4.7229605913162231e-01
    z[4,2,4]  R1929     -1.6047553718090057e-01
    z[4,2,4]  R1930     7.0403993129730225e-02
    z[4,2,4]  R1931     4.3914973735809326e-01
    z[4,2,4]  R1932     3.7198930978775024e-01
    z[4,2,4]  R1933     5.9806394577026367e-01
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1815     -1
    z[4,2,5]  R1816     1
    z[4,2,5]  R1819     -3.8344261050224304e-01
    z[4,2,5]  R1820     -2.4632996320724487e-01
    z[4,2,5]  R1821     -4.6027606725692749e-01
    z[4,2,5]  R1822     7.6073859818279743e-03
    z[4,2,5]  R1823     -1.3433896005153656e-01
    z[4,2,5]  R1824     1.5455786883831024e-01
    z[4,2,5]  R1825     -2.7092182636260986e-01
    z[4,2,5]  R1826     7.6671266555786133e-01
    z[4,2,5]  R1827     2.8965758159756660e-02
    z[4,2,5]  R1828     -1.5829353034496307e-01
    z[4,2,5]  R1829     -4.2344415187835693e-01
    z[4,2,5]  R1830     -3.0616271495819092e-01
    z[4,2,5]  R1831     -5.2750091999769211e-02
    z[4,2,5]  R1832     -8.3749219775199890e-02
    z[4,2,5]  R1833     3.5495933890342712e-01
    z[4,2,5]  R1834     2.2453854978084564e-01
    z[4,2,5]  R1835     1.8640884757041931e-01
    z[4,2,5]  R1836     -7.0749111473560333e-02
    z[4,2,5]  R1837     2.3678185045719147e-01
    z[4,2,5]  R1838     3.0017700791358948e-01
    z[4,2,5]  R1839     4.8381257057189941e-01
    z[4,2,5]  R1840     3.3239677548408508e-01
    z[4,2,5]  R1841     1.4385271072387695e-01
    z[4,2,5]  R1842     2.0954367518424988e-01
    z[4,2,5]  R1843     2.6355904340744019e-01
    z[4,2,5]  R1844     -5.7709765434265137e-01
    z[4,2,5]  R1845     -3.5071596503257751e-01
    z[4,2,5]  R1846     -0.278903067111969
    z[4,2,5]  R1847     5.8221589773893356e-02
    z[4,2,5]  R1848     -0.517057478427887
    z[4,2,5]  R1849     -1.5165178477764130e-01
    z[4,2,5]  R1850     -2.3012003302574158e-01
    z[4,2,5]  R1851     -1.0831041634082794e-01
    z[4,2,5]  R1852     -4.0791058540344238e-01
    z[4,2,5]  R1853     -7.4242120981216431e-01
    z[4,2,5]  R1854     3.2431101799011230e-01
    z[4,2,5]  R1855     1.3020985759794712e-02
    z[4,2,5]  R1856     1.7334592342376709e-01
    z[4,2,5]  R1857     2.3370157182216644e-01
    z[4,2,5]  R1858     3.6393117904663086e-01
    z[4,2,5]  R1859     3.2534962892532349e-01
    z[4,2,5]  R1860     0.166063129901886
    z[4,2,5]  R1861     9.8060876131057739e-02
    z[4,2,5]  R1862     2.5930896401405334e-01
    z[4,2,5]  R1863     2.8347793221473694e-01
    z[4,2,5]  R1864     -2.1221968531608582e-01
    z[4,2,5]  R1865     -2.6262289285659790e-01
    z[4,2,5]  R1866     3.7324330210685730e-01
    z[4,2,5]  R1867     1.0355718433856964e-01
    z[4,2,5]  R1868     -2.0006487146019936e-02
    z[4,2,5]  R1869     3.7442959845066071e-02
    z[4,2,5]  R1870     3.6605718731880188e-01
    z[4,2,5]  R1871     2.8392788767814636e-01
    z[4,2,5]  R1872     2.2410650551319122e-01
    z[4,2,5]  R1873     3.9185580611228943e-01
    z[4,2,5]  R1874     -4.6332050114870071e-02
    z[4,2,5]  R1875     -2.9014545679092407e-01
    z[4,2,5]  R1876     3.3672028779983521e-01
    z[4,2,5]  R1877     5.5800926685333252e-01
    z[4,2,5]  R1878     0.097394198179245
    z[4,2,5]  R1879     3.9934930391609669e-03
    z[4,2,5]  R1880     6.4718961715698242e-02
    z[4,2,5]  R1881     4.3009036779403687e-01
    z[4,2,5]  R1882     -1.2009969353675842e-01
    z[4,2,5]  R1883     0.0447159968316555
    z[4,2,5]  R1884     1.9053022563457489e-01
    z[4,2,5]  R1885     1.5491028130054474e-01
    z[4,2,5]  R1886     -4.1099965572357178e-01
    z[4,2,5]  R1887     -3.3980360627174377e-01
    z[4,2,5]  R1888     2.9551693797111511e-01
    z[4,2,5]  R1889     2.8076082468032837e-02
    z[4,2,5]  R1890     4.3349310755729675e-02
    z[4,2,5]  R1891     0.0949019193649292
    z[4,2,5]  R1892     -1.9856201112270355e-01
    z[4,2,5]  R1893     3.4327441453933716e-01
    z[4,2,5]  R1894     -0.295166552066803
    z[4,2,5]  R1895     -3.4717667102813721e-01
    z[4,2,5]  R1896     -3.6521118879318237e-01
    z[4,2,5]  R1897     -1.5804505348205566e-01
    z[4,2,5]  R1898     -6.1893957853317261e-01
    z[4,2,5]  R1899     2.2514855861663818e-01
    z[4,2,5]  R1900     -8.1602893769741058e-02
    z[4,2,5]  R1901     -3.0847036838531494e-01
    z[4,2,5]  R1902     -2.2324765101075172e-02
    z[4,2,5]  R1903     -1.1252982169389725e-01
    z[4,2,5]  R1904     -5.4488635063171387e-01
    z[4,2,5]  R1905     -2.3003305494785309e-01
    z[4,2,5]  R1906     8.4717579185962677e-02
    z[4,2,5]  R1907     -2.1322610974311829e-01
    z[4,2,5]  R1908     -3.1098678708076477e-01
    z[4,2,5]  R1909     -4.3563401699066162e-01
    z[4,2,5]  R1910     4.3798366189002991e-01
    z[4,2,5]  R1911     2.8272947669029236e-01
    z[4,2,5]  R1912     2.6798954606056213e-01
    z[4,2,5]  R1913     4.4543093442916870e-01
    z[4,2,5]  R1914     1.1807820200920105e-01
    z[4,2,5]  R1915     -2.0969074964523315e-01
    z[4,2,5]  R1916     0.584648609161377
    z[4,2,5]  R1917     4.6253389120101929e-01
    z[4,2,5]  R1918     1.1077541112899780e-01
    z[4,2,5]  R1919     3.1556141376495361e-01
    z[4,2,5]  R1920     1.1781197786331177e-01
    z[4,2,5]  R1921     3.8323265314102173e-01
    z[4,2,5]  R1922     5.9083163738250732e-01
    z[4,2,5]  R1923     5.3693127632141113e-01
    z[4,2,5]  R1924     1.5663637220859528e-01
    z[4,2,5]  R1925     4.1953021287918091e-01
    z[4,2,5]  R1926     2.4167820811271667e-01
    z[4,2,5]  R1927     2.1930266916751862e-01
    z[4,2,5]  R1928     2.1439573168754578e-01
    z[4,2,5]  R1929     2.9126736521720886e-01
    z[4,2,5]  R1930     1.5991058945655823e-01
    z[4,2,5]  R1931     9.4435155391693115e-02
    z[4,2,5]  R1932     2.6526299118995667e-01
    z[4,2,5]  R1933     3.2946422696113586e-01
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1817     -1
    z[4,2,6]  R1818     1
    z[4,2,6]  R1819     2.9716029763221741e-01
    z[4,2,6]  R1820     -3.8691893219947815e-01
    z[4,2,6]  R1821     -3.4699544310569763e-01
    z[4,2,6]  R1822     9.0068168938159943e-02
    z[4,2,6]  R1823     -3.7443239241838455e-02
    z[4,2,6]  R1824     -0.259909987449646
    z[4,2,6]  R1825     -5.0366961956024170e-01
    z[4,2,6]  R1826     4.6736735850572586e-02
    z[4,2,6]  R1827     -1.0265648597851396e-03
    z[4,2,6]  R1828     -1.0762225091457367e-01
    z[4,2,6]  R1829     0.0696331113576889
    z[4,2,6]  R1830     3.1715276837348938e-01
    z[4,2,6]  R1831     2.2725264728069305e-01
    z[4,2,6]  R1832     -4.8621557652950287e-02
    z[4,2,6]  R1833     5.8099544048309326e-01
    z[4,2,6]  R1834     7.2574146091938019e-02
    z[4,2,6]  R1835     -2.1973720192909241e-01
    z[4,2,6]  R1836     -4.7050568461418152e-01
    z[4,2,6]  R1837     -7.0633783936500549e-02
    z[4,2,6]  R1838     0.336056649684906
    z[4,2,6]  R1839     -3.7884730100631714e-01
    z[4,2,6]  R1840     3.8792282342910767e-01
    z[4,2,6]  R1841     4.8093879222869873e-01
    z[4,2,6]  R1842     -2.1727073192596436e-01
    z[4,2,6]  R1843     2.2801366448402405e-01
    z[4,2,6]  R1844     -1.7919200658798218e-01
    z[4,2,6]  R1845     1.1737052351236343e-01
    z[4,2,6]  R1846     -3.0322477221488953e-01
    z[4,2,6]  R1847     -7.3339521884918213e-02
    z[4,2,6]  R1848     -0.586080014705658
    z[4,2,6]  R1849     1.4169251918792725e-01
    z[4,2,6]  R1850     1.3314105570316315e-01
    z[4,2,6]  R1851     2.2169493138790131e-01
    z[4,2,6]  R1852     0.506830632686615
    z[4,2,6]  R1853     -2.3363646864891052e-01
    z[4,2,6]  R1854     4.2107634246349335e-02
    z[4,2,6]  R1855     -1.0225398838520050e-01
    z[4,2,6]  R1856     -1.1910647153854370e-01
    z[4,2,6]  R1857     -4.8612681031227112e-01
    z[4,2,6]  R1858     -1.8703129887580872e-01
    z[4,2,6]  R1859     1.1156961321830750e-01
    z[4,2,6]  R1860     -5.7398449629545212e-02
    z[4,2,6]  R1861     1.1197334527969360e-01
    z[4,2,6]  R1862     2.9366193339228630e-02
    z[4,2,6]  R1863     -8.4692798554897308e-02
    z[4,2,6]  R1864     3.4464153647422791e-01
    z[4,2,6]  R1865     -2.0486536622047424e-01
    z[4,2,6]  R1866     -0.359995037317276
    z[4,2,6]  R1867     6.2019795179367065e-02
    z[4,2,6]  R1868     -6.6353239119052887e-02
    z[4,2,6]  R1869     -4.7712358832359314e-01
    z[4,2,6]  R1870     -2.9085966944694519e-01
    z[4,2,6]  R1871     1.4768464863300323e-01
    z[4,2,6]  R1872     0.361070841550827
    z[4,2,6]  R1873     6.4369112253189087e-01
    z[4,2,6]  R1874     3.3611815422773361e-02
    z[4,2,6]  R1875     5.8424003422260284e-02
    z[4,2,6]  R1876     2.9420611262321472e-01
    z[4,2,6]  R1877     3.5556632280349731e-01
    z[4,2,6]  R1878     2.7982246875762939e-01
    z[4,2,6]  R1879     -1.7918157577514648e-01
    z[4,2,6]  R1880     -3.9160954952239990e-01
    z[4,2,6]  R1881     2.5816816091537476e-01
    z[4,2,6]  R1882     5.3819339722394943e-02
    z[4,2,6]  R1883     1.6115494072437286e-01
    z[4,2,6]  R1884     1.5988571941852570e-01
    z[4,2,6]  R1885     5.4371935129165649e-01
    z[4,2,6]  R1886     -2.3824411630630493e-01
    z[4,2,6]  R1887     0.0323464460670948
    z[4,2,6]  R1888     -3.2886481285095215e-01
    z[4,2,6]  R1889     -2.0483744144439697e-01
    z[4,2,6]  R1890     -6.2456015497446060e-02
    z[4,2,6]  R1891     -6.0060225427150726e-02
    z[4,2,6]  R1892     -3.7260480225086212e-02
    z[4,2,6]  R1893     -8.9438818395137787e-02
    z[4,2,6]  R1894     3.6358860135078430e-01
    z[4,2,6]  R1895     -1.4429277181625366e-01
    z[4,2,6]  R1896     2.7114427089691162e-01
    z[4,2,6]  R1897     -3.8851892948150635e-01
    z[4,2,6]  R1898     1.7991696298122406e-01
    z[4,2,6]  R1899     -2.3394417762756348e-01
    z[4,2,6]  R1900     0.236423060297966
    z[4,2,6]  R1901     -3.3040741086006165e-01
    z[4,2,6]  R1902     -2.5347569584846497e-01
    z[4,2,6]  R1903     -4.4116694480180740e-02
    z[4,2,6]  R1904     1.1758720874786377e-01
    z[4,2,6]  R1905     1.5814271569252014e-01
    z[4,2,6]  R1906     2.6673685759305954e-02
    z[4,2,6]  R1907     -3.2572884112596512e-02
    z[4,2,6]  R1908     1.0089663416147232e-01
    z[4,2,6]  R1909     3.9931874722242355e-02
    z[4,2,6]  R1910     2.9144637286663055e-02
    z[4,2,6]  R1911     -2.0908041298389435e-01
    z[4,2,6]  R1912     5.1410514116287231e-01
    z[4,2,6]  R1913     5.5026924610137939e-01
    z[4,2,6]  R1914     -0.227493554353714
    z[4,2,6]  R1915     -2.5993982329964638e-02
    z[4,2,6]  R1916     2.8447759151458740e-01
    z[4,2,6]  R1917     5.4953861236572266e-01
    z[4,2,6]  R1918     -2.9029166698455811e-01
    z[4,2,6]  R1919     1.8050950765609741e-01
    z[4,2,6]  R1920     4.4846269488334656e-01
    z[4,2,6]  R1921     -6.0303188860416412e-02
    z[4,2,6]  R1922     -2.7751579880714417e-01
    z[4,2,6]  R1923     0.000607263995334506
    z[4,2,6]  R1924     -8.4105335175991058e-02
    z[4,2,6]  R1925     -1.8866260349750519e-01
    z[4,2,6]  R1926     3.8933104276657104e-01
    z[4,2,6]  R1927     -2.7347257733345032e-01
    z[4,2,6]  R1928     -1.3086025416851044e-01
    z[4,2,6]  R1929     -9.8307356238365173e-02
    z[4,2,6]  R1930     2.1744383871555328e-01
    z[4,2,6]  R1931     5.4348301142454147e-02
    z[4,2,6]  R1932     7.5376674532890320e-02
    z[4,2,6]  R1933     1.1221068352460861e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1934     -1
    z[2,5,0]  R1935     1
    z[2,5,0]  R1948     -2.6873114705085754e-01
    z[2,5,0]  R1949     -3.2073151320219040e-02
    z[2,5,0]  R1950     3.7537875771522522e-01
    z[2,5,0]  R1951     3.6279532313346863e-01
    z[2,5,0]  R1952     2.7410724759101868e-01
    z[2,5,0]  R1953     3.4550437331199646e-01
    z[2,5,0]  R1954     -3.4611618518829346e-01
    z[2,5,0]  R1955     -1.3425517082214355e-01
    z[2,5,0]  R1956     -3.1043639779090881e-01
    z[2,5,0]  R1957     -2.7002862095832825e-01
    z[2,5,0]  R1958     -6.6402232646942139e-01
    z[2,5,0]  R1959     -9.0399205684661865e-01
    z[2,5,0]  R1960     -0.804214358329773
    z[2,5,0]  R1961     -7.4929600954055786e-01
    z[2,5,0]  R1962     -5.9058940410614014e-01
    z[2,5,0]  R1963     -1.7309513350483030e-04
    z[2,5,0]  R1964     6.1451070010662079e-02
    z[2,5,0]  R1965     2.2709189355373383e-01
    z[2,5,0]  R1966     -1.8552179634571075e-01
    z[2,5,0]  R1967     -3.4881201386451721e-01
    z[2,5,0]  R1968     1.3089212775230408e-01
    z[2,5,0]  R1969     -3.5005442332476377e-03
    z[2,5,0]  R1970     5.3854632377624512e-01
    z[2,5,0]  R1971     4.9122610688209534e-01
    z[2,5,0]  R1972     4.4492509961128235e-01
    z[2,5,0]  R1973     2.5517001748085022e-01
    z[2,5,0]  R1974     5.1593577861785889e-01
    z[2,5,0]  R1975     -2.5728667154908180e-02
    z[2,5,0]  R1976     8.3634227514266968e-02
    z[2,5,0]  R1977     3.6626616120338440e-01
    z[2,5,0]  R1978     -8.9695248752832413e-03
    z[2,5,0]  R1979     1.5972553193569183e-01
    z[2,5,0]  R1980     -5.3645157814025879e-01
    z[2,5,0]  R1981     6.3105231523513794e-01
    z[2,5,0]  R1982     -4.2418235540390015e-01
    z[2,5,0]  R1983     5.4071956872940063e-01
    z[2,5,0]  R1984     2.4172581732273102e-01
    z[2,5,0]  R1985     6.0971105098724365e-01
    z[2,5,0]  R1986     1.7035140097141266e-01
    z[2,5,0]  R1987     7.2460480034351349e-02
    z[2,5,0]  R1988     -6.7582845687866211e-01
    z[2,5,0]  R1989     -6.0512125492095947e-01
    z[2,5,0]  R1990     1.4272104203701019e-01
    z[2,5,0]  R1991     -7.2260481119155884e-01
    z[2,5,0]  R1992     6.4754843711853027e-01
    z[2,5,0]  R1993     7.0424085855484009e-01
    z[2,5,0]  R1994     8.7252952158451080e-02
    z[2,5,0]  R1995     1.3760389387607574e-01
    z[2,5,0]  R1996     4.6381881833076477e-01
    z[2,5,0]  R1997     -1.3176780939102173e-01
    z[2,5,0]  R1998     2.5867810845375061e-01
    z[2,5,0]  R1999     9.8589166998863220e-02
    z[2,5,0]  R2000     -1.6886758804321289e-01
    z[2,5,0]  R2001     -2.4934832006692886e-02
    z[2,5,0]  R2002     -2.7765434980392456e-01
    z[2,5,0]  R2003     -7.5552088022232056e-01
    z[2,5,0]  R2004     -8.4898811578750610e-01
    z[2,5,0]  R2005     3.0848824977874756e-01
    z[2,5,0]  R2006     -4.2343363165855408e-01
    z[2,5,0]  R2007     3.1179559230804443e-01
    z[2,5,0]  R2008     3.2969641685485840e-01
    z[2,5,0]  R2009     3.4860834479331970e-01
    z[2,5,0]  R2010     -4.5325347781181335e-01
    z[2,5,0]  R2011     -0.422927588224411
    z[2,5,0]  R2012     -5.0999581813812256e-01
    z[2,5,0]  R2013     -2.6431143283843994e-01
    z[2,5,0]  R2014     4.9214616417884827e-02
    z[2,5,0]  R2015     1.9649212062358856e-01
    z[2,5,0]  R2016     0.422234445810318
    z[2,5,0]  R2017     2.4938111007213593e-01
    z[2,5,0]  R2018     8.8419675827026367e-02
    z[2,5,0]  R2019     4.0276327729225159e-01
    z[2,5,0]  R2020     0.631734311580658
    z[2,5,0]  R2021     5.6486970186233521e-01
    z[2,5,0]  R2022     5.7851821184158325e-01
    z[2,5,0]  R2023     4.3736633658409119e-01
    z[2,5,0]  R2024     2.5934025645256042e-01
    z[2,5,0]  R2025     5.0061064958572388e-01
    z[2,5,0]  R2026     1.2580172717571259e-01
    z[2,5,0]  R2027     2.9341140389442444e-01
    z[2,5,0]  R2028     4.2084982991218567e-01
    z[2,5,0]  R2029     1.8046663701534271e-01
    z[2,5,0]  R2030     3.0953222513198853e-01
    z[2,5,0]  R2031     2.5165063142776489e-01
    z[2,5,0]  R2032     1.2470825761556625e-01
    z[2,5,0]  R2033     5.1459338515996933e-02
    z[2,5,0]  R2034     2.2383508086204529e-01
    z[2,5,0]  R2035     1.8951010704040527e-01
    z[2,5,0]  R2036     -5.1455962657928467e-01
    z[2,5,0]  R2037     -0.131059467792511
    z[2,5,0]  R2038     -4.1167184710502625e-01
    z[2,5,0]  R2039     5.2194584161043167e-02
    z[2,5,0]  R2040     -3.3740440011024475e-01
    z[2,5,0]  R2041     1.4051201939582825e-01
    z[2,5,0]  R2042     -1.3101556897163391e-01
    z[2,5,0]  R2043     2.3414593935012817e-01
    z[2,5,0]  R2044     2.6615265011787415e-01
    z[2,5,0]  R2045     -3.8141000270843506e-01
    z[2,5,0]  R2046     -7.2037017345428467e-01
    z[2,5,0]  R2047     -7.2790348529815674e-01
    z[2,5,0]  R2048     5.0193983316421509e-01
    z[2,5,0]  R2049     3.5697630047798157e-01
    z[2,5,0]  R2050     3.1045895814895630e-01
    z[2,5,0]  R2051     3.5617956519126892e-01
    z[2,5,0]  R2052     -0.0835917741060257
    z[2,5,0]  R2053     2.3714382946491241e-01
    z[2,5,0]  R2054     2.6713207364082336e-01
    z[2,5,0]  R2055     1.8173341453075409e-01
    z[2,5,0]  R2056     4.4621476531028748e-01
    z[2,5,0]  R2057     3.1219500303268433e-01
    z[2,5,0]  R2058     -5.0173097848892212e-01
    z[2,5,0]  R2059     6.3865667581558228e-01
    z[2,5,0]  R2060     6.5449148416519165e-02
    z[2,5,0]  R2061     5.2495366334915161e-01
    z[2,5,0]  R2062     3.5497203469276428e-01
    z[2,5,0]  R2063     4.4768762588500977e-01
    z[2,5,0]  R2064     4.9666678905487061e-01
    z[2,5,0]  R2065     6.2237411737442017e-01
    z[2,5,0]  R2066     4.7753170132637024e-01
    z[2,5,0]  R2067     3.4345629811286926e-01
    z[2,5,0]  R2068     -6.0553711652755737e-01
    z[2,5,0]  R2069     1.7541919648647308e-01
    z[2,5,0]  R2070     5.9707891941070557e-01
    z[2,5,0]  R2071     4.7816035151481628e-01
    z[2,5,0]  R2072     4.8107045888900757e-01
    z[2,5,0]  R2073     0.0420943982899189
    z[2,5,0]  R2074     2.2906219959259033e-01
    z[2,5,0]  R2075     3.0979016795754433e-02
    z[2,5,0]  R2076     -1.0578852146863937e-01
    z[2,5,0]  R2077     3.5713267326354980e-01
    z[2,5,0]  R2078     0.481503427028656
    z[2,5,0]  R2079     0.350081205368042
    z[2,5,0]  R2080     4.4970616698265076e-01
    z[2,5,0]  R2081     1.2914520502090454e-01
    z[2,5,0]  R2082     4.7862935066223145e-01
    z[2,5,0]  R2083     -0.0339871309697628
    z[2,5,0]  R2084     2.8752669692039490e-01
    z[2,5,0]  R2085     4.5326313376426697e-01
    z[2,5,0]  R2086     3.3613637089729309e-01
    z[2,5,0]  R2087     2.0278221368789673e-01
    z[2,5,0]  R2088     6.6347676515579224e-01
    z[2,5,0]  R2089     -2.4898461997509003e-01
    z[2,5,0]  R2090     4.6122840046882629e-01
    z[2,5,0]  R2091     4.9284663796424866e-01
    z[2,5,0]  R2092     4.1822734475135803e-01
    z[2,5,0]  R2093     4.8851454257965088e-01
    z[2,5,0]  R2094     3.4320834279060364e-01
    z[2,5,0]  R2095     1.8371088802814484e-01
    z[2,5,0]  R2096     3.1019492074847221e-02
    z[2,5,0]  R2097     7.1308411657810211e-02
    z[2,5,0]  R2098     -3.9650008082389832e-01
    z[2,5,0]  R2099     5.1104658842086792e-01
    z[2,5,0]  R2100     5.1345431804656982e-01
    z[2,5,0]  R2101     9.9075190722942352e-02
    z[2,5,0]  R2102     1.3918174803256989e-01
    z[2,5,0]  R2103     1.0309685766696930e-01
    z[2,5,0]  R2104     1.3891510665416718e-02
    z[2,5,0]  R2105     6.8562909960746765e-02
    z[2,5,0]  R2106     -6.5475896000862122e-02
    z[2,5,0]  R2107     -2.6827117800712585e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1936     -1
    z[2,5,1]  R1937     1
    z[2,5,1]  R1948     -2.1588015556335449e-01
    z[2,5,1]  R1949     1.7628110945224762e-01
    z[2,5,1]  R1950     -2.3755583167076111e-01
    z[2,5,1]  R1951     2.0479236543178558e-01
    z[2,5,1]  R1952     -1.3154593110084534e-01
    z[2,5,1]  R1953     1.9905219972133636e-01
    z[2,5,1]  R1954     -4.1699981689453125e-01
    z[2,5,1]  R1955     -3.0128517746925354e-01
    z[2,5,1]  R1956     -7.6194740831851959e-02
    z[2,5,1]  R1957     0.209869846701622
    z[2,5,1]  R1958     -4.0960386395454407e-01
    z[2,5,1]  R1959     -1.5778750181198120e-01
    z[2,5,1]  R1960     -2.4455009400844574e-01
    z[2,5,1]  R1961     -2.5556573271751404e-01
    z[2,5,1]  R1962     -3.8000097870826721e-01
    z[2,5,1]  R1963     1.2717936933040619e-01
    z[2,5,1]  R1964     1.5552307665348053e-01
    z[2,5,1]  R1965     3.5584294237196445e-03
    z[2,5,1]  R1966     3.0309504270553589e-01
    z[2,5,1]  R1967     0.143227681517601
    z[2,5,1]  R1968     6.7356717586517334e-01
    z[2,5,1]  R1969     8.2480198144912720e-01
    z[2,5,1]  R1970     5.6491744518280029e-01
    z[2,5,1]  R1971     -7.3912781476974487e-01
    z[2,5,1]  R1972     -6.5501809120178223e-01
    z[2,5,1]  R1973     -5.0831407308578491e-01
    z[2,5,1]  R1974     -5.9823578596115112e-01
    z[2,5,1]  R1975     8.8219058513641357e-01
    z[2,5,1]  R1976     8.8769757747650146e-01
    z[2,5,1]  R1977     4.5806637406349182e-01
    z[2,5,1]  R1978     1.8596200644969940e-01
    z[2,5,1]  R1979     7.1757632493972778e-01
    z[2,5,1]  R1980     -3.8152185082435608e-01
    z[2,5,1]  R1981     1.4021593332290649e-01
    z[2,5,1]  R1982     -3.7752085924148560e-01
    z[2,5,1]  R1983     0.69268798828125
    z[2,5,1]  R1984     -6.1385488510131836e-01
    z[2,5,1]  R1985     6.0728186368942261e-01
    z[2,5,1]  R1986     -4.8250687122344971e-01
    z[2,5,1]  R1987     -7.0133811235427856e-01
    z[2,5,1]  R1988     -5.4359430074691772e-01
    z[2,5,1]  R1989     -4.9089613556861877e-01
    z[2,5,1]  R1990     2.6800769567489624e-01
    z[2,5,1]  R1991     -4.0371596813201904e-01
    z[2,5,1]  R1992     0.409095823764801
    z[2,5,1]  R1993     6.2194281816482544e-01
    z[2,5,1]  R1994     -3.8345479965209961e-01
    z[2,5,1]  R1995     9.3600398302078247e-01
    z[2,5,1]  R1996     -5.5373638868331909e-01
    z[2,5,1]  R1997     9.1260397434234619e-01
    z[2,5,1]  R1998     1.5924791991710663e-01
    z[2,5,1]  R1999     3.9333915710449219e-01
    z[2,5,1]  R2000     3.0031278729438782e-01
    z[2,5,1]  R2001     6.2737494707107544e-01
    z[2,5,1]  R2002     2.1992325782775879e-01
    z[2,5,1]  R2003     -4.1509312391281128e-01
    z[2,5,1]  R2004     -4.1287493705749512e-01
    z[2,5,1]  R2005     8.0462110042572021e-01
    z[2,5,1]  R2006     -3.6295115947723389e-01
    z[2,5,1]  R2007     -6.9650501012802124e-01
    z[2,5,1]  R2008     -6.7203216254711151e-02
    z[2,5,1]  R2009     8.0494272708892822e-01
    z[2,5,1]  R2010     -3.9140564203262329e-01
    z[2,5,1]  R2011     4.6580326557159424e-01
    z[2,5,1]  R2012     3.8096180558204651e-01
    z[2,5,1]  R2013     1.5873104333877563e-01
    z[2,5,1]  R2014     1.4601269364356995e-01
    z[2,5,1]  R2015     2.3214745521545410e-01
    z[2,5,1]  R2016     -5.8443200588226318e-01
    z[2,5,1]  R2017     -4.8416009545326233e-01
    z[2,5,1]  R2018     -4.8915907740592957e-01
    z[2,5,1]  R2019     -5.4353523254394531e-01
    z[2,5,1]  R2020     3.3106356859207153e-01
    z[2,5,1]  R2021     0.0721365436911583
    z[2,5,1]  R2022     2.4072538316249847e-01
    z[2,5,1]  R2023     -4.7887992858886719e-01
    z[2,5,1]  R2024     -3.7768241763114929e-01
    z[2,5,1]  R2025     -3.6895516514778137e-01
    z[2,5,1]  R2026     -3.3499330282211304e-01
    z[2,5,1]  R2027     -2.3496727645397186e-01
    z[2,5,1]  R2028     -0.631965160369873
    z[2,5,1]  R2029     -5.7080310583114624e-01
    z[2,5,1]  R2030     -4.0810176730155945e-01
    z[2,5,1]  R2031     -2.2940079867839813e-01
    z[2,5,1]  R2032     -2.9745447635650635e-01
    z[2,5,1]  R2033     -1.1915975809097290e-01
    z[2,5,1]  R2034     6.0840494930744171e-02
    z[2,5,1]  R2035     -2.8783810138702393e-01
    z[2,5,1]  R2036     6.6480404138565063e-01
    z[2,5,1]  R2037     5.4802858829498291e-01
    z[2,5,1]  R2038     8.5575813427567482e-03
    z[2,5,1]  R2039     1.4072133600711823e-01
    z[2,5,1]  R2040     -2.6882013678550720e-01
    z[2,5,1]  R2041     -1.2652019038796425e-02
    z[2,5,1]  R2042     3.0407634377479553e-01
    z[2,5,1]  R2043     5.1733434200286865e-01
    z[2,5,1]  R2044     1.8734943866729736e-01
    z[2,5,1]  R2045     1.8706493079662323e-02
    z[2,5,1]  R2046     -6.2197268009185791e-01
    z[2,5,1]  R2047     -6.0173243284225464e-01
    z[2,5,1]  R2048     -0.541064977645874
    z[2,5,1]  R2049     -7.0541268587112427e-01
    z[2,5,1]  R2050     -0.561692476272583
    z[2,5,1]  R2051     -5.9705138206481934e-01
    z[2,5,1]  R2052     8.4480911493301392e-01
    z[2,5,1]  R2053     -2.9515042901039124e-01
    z[2,5,1]  R2054     -5.9425985813140869e-01
    z[2,5,1]  R2055     7.0331460237503052e-01
    z[2,5,1]  R2056     5.4043614864349365e-01
    z[2,5,1]  R2057     -4.5522215962409973e-01
    z[2,5,1]  R2058     -4.3140354752540588e-01
    z[2,5,1]  R2059     3.7732613086700439e-01
    z[2,5,1]  R2060     8.4820365905761719e-01
    z[2,5,1]  R2061     6.9910007715225220e-01
    z[2,5,1]  R2062     6.6943019628524780e-01
    z[2,5,1]  R2063     0.597454845905304
    z[2,5,1]  R2064     6.0251086950302124e-01
    z[2,5,1]  R2065     5.7777369022369385e-01
    z[2,5,1]  R2066     6.0641765594482422e-01
    z[2,5,1]  R2067     0.650162935256958
    z[2,5,1]  R2068     -5.0807815790176392e-01
    z[2,5,1]  R2069     5.8061248064041138e-01
    z[2,5,1]  R2070     -1.7243736982345581e-01
    z[2,5,1]  R2071     -5.6971997022628784e-01
    z[2,5,1]  R2072     -5.5164480209350586e-01
    z[2,5,1]  R2073     -4.0834445506334305e-02
    z[2,5,1]  R2074     1.3132227957248688e-01
    z[2,5,1]  R2075     -5.1098912954330444e-02
    z[2,5,1]  R2076     2.9433953762054443e-01
    z[2,5,1]  R2077     -2.1766616404056549e-01
    z[2,5,1]  R2078     -5.3306269645690918e-01
    z[2,5,1]  R2079     -3.5644170641899109e-01
    z[2,5,1]  R2080     -3.5504448413848877e-01
    z[2,5,1]  R2081     -5.8893674612045288e-01
    z[2,5,1]  R2082     -4.9673485755920410e-01
    z[2,5,1]  R2083     1.1629262566566467e-01
    z[2,5,1]  R2084     -4.4587850570678711e-01
    z[2,5,1]  R2085     -1.3600496947765350e-01
    z[2,5,1]  R2086     -5.9690237045288086e-01
    z[2,5,1]  R2087     7.1867331862449646e-02
    z[2,5,1]  R2088     2.4152347818017006e-02
    z[2,5,1]  R2089     8.4414738416671753e-01
    z[2,5,1]  R2090     0.718745231628418
    z[2,5,1]  R2091     -4.8123809695243835e-01
    z[2,5,1]  R2092     -3.2860276103019714e-01
    z[2,5,1]  R2093     -6.6047638654708862e-01
    z[2,5,1]  R2094     -1.4736685156822205e-01
    z[2,5,1]  R2095     2.6722899079322815e-01
    z[2,5,1]  R2096     -3.5031118988990784e-01
    z[2,5,1]  R2097     -0.500552237033844
    z[2,5,1]  R2098     -3.4786400198936462e-01
    z[2,5,1]  R2099     -5.2081096172332764e-01
    z[2,5,1]  R2100     -5.9718823432922363e-01
    z[2,5,1]  R2101     -5.9593987464904785e-01
    z[2,5,1]  R2102     -3.3485185354948044e-02
    z[2,5,1]  R2103     2.0150625705718994e-01
    z[2,5,1]  R2104     4.2572334408760071e-02
    z[2,5,1]  R2105     -0.365588903427124
    z[2,5,1]  R2106     1.8889233469963074e-02
    z[2,5,1]  R2107     1.7349785566329956e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1938     -1
    z[2,5,2]  R1939     1
    z[2,5,2]  R1948     -3.9520934224128723e-01
    z[2,5,2]  R1949     -6.5507078170776367e-01
    z[2,5,2]  R1950     -6.7343634366989136e-01
    z[2,5,2]  R1951     -7.1022748947143555e-01
    z[2,5,2]  R1952     -3.5012489557266235e-01
    z[2,5,2]  R1953     -2.4349214136600494e-01
    z[2,5,2]  R1954     -7.4231493473052979e-01
    z[2,5,2]  R1955     -5.1035708189010620e-01
    z[2,5,2]  R1956     -4.5079621672630310e-01
    z[2,5,2]  R1957     -3.3830073475837708e-01
    z[2,5,2]  R1958     2.1875385940074921e-01
    z[2,5,2]  R1959     3.3716621994972229e-01
    z[2,5,2]  R1960     4.4088739156723022e-01
    z[2,5,2]  R1961     2.2630555927753448e-01
    z[2,5,2]  R1962     5.4999870061874390e-01
    z[2,5,2]  R1963     8.7424147129058838e-01
    z[2,5,2]  R1964     9.4849610328674316e-01
    z[2,5,2]  R1965     9.5662963390350342e-01
    z[2,5,2]  R1966     8.9228767156600952e-01
    z[2,5,2]  R1967     8.1086415052413940e-01
    z[2,5,2]  R1968     -4.1185855865478516e-01
    z[2,5,2]  R1969     -1.9162485376000404e-02
    z[2,5,2]  R1970     2.8008872270584106e-01
    z[2,5,2]  R1971     4.0162590146064758e-01
    z[2,5,2]  R1972     4.4733661413192749e-01
    z[2,5,2]  R1973     0.568046510219574
    z[2,5,2]  R1974     2.8434932231903076e-01
    z[2,5,2]  R1975     3.1677380204200745e-01
    z[2,5,2]  R1976     1.1546524614095688e-01
    z[2,5,2]  R1977     -1.6543051600456238e-01
    z[2,5,2]  R1978     -0.0796266719698906
    z[2,5,2]  R1979     -2.9266723990440369e-01
    z[2,5,2]  R1980     -2.8603881597518921e-01
    z[2,5,2]  R1981     -3.5321470350027084e-02
    z[2,5,2]  R1982     1.1452263593673706e-01
    z[2,5,2]  R1983     1.4027774333953857e-02
    z[2,5,2]  R1984     0.628491997718811
    z[2,5,2]  R1985     3.4253127872943878e-02
    z[2,5,2]  R1986     6.6206520795822144e-01
    z[2,5,2]  R1987     6.2908381223678589e-01
    z[2,5,2]  R1988     2.9503282904624939e-01
    z[2,5,2]  R1989     -1.2889644131064415e-02
    z[2,5,2]  R1990     -3.6238917708396912e-01
    z[2,5,2]  R1991     -1.2910751998424530e-01
    z[2,5,2]  R1992     2.9581716284155846e-02
    z[2,5,2]  R1993     -5.8643147349357605e-02
    z[2,5,2]  R1994     7.1621578931808472e-01
    z[2,5,2]  R1995     1.7335261404514313e-01
    z[2,5,2]  R1996     0.579522430896759
    z[2,5,2]  R1997     -1.2586662545800209e-02
    z[2,5,2]  R1998     -0.60338294506073
    z[2,5,2]  R1999     -2.8439977765083313e-01
    z[2,5,2]  R2000     -5.1153934001922607e-01
    z[2,5,2]  R2001     -1.1169648915529251e-01
    z[2,5,2]  R2002     -5.5183249711990356e-01
    z[2,5,2]  R2003     -7.1597069501876831e-02
    z[2,5,2]  R2004     7.9120278358459473e-02
    z[2,5,2]  R2005     -3.7630371749401093e-02
    z[2,5,2]  R2006     1.3049761950969696e-01
    z[2,5,2]  R2007     6.2702363729476929e-01
    z[2,5,2]  R2008     -7.2930544614791870e-01
    z[2,5,2]  R2009     -3.3465901017189026e-01
    z[2,5,2]  R2010     3.6644306033849716e-02
    z[2,5,2]  R2011     7.0993721485137939e-01
    z[2,5,2]  R2012     0.539761483669281
    z[2,5,2]  R2013     0.705171525478363
    z[2,5,2]  R2014     9.0713568031787872e-02
    z[2,5,2]  R2015     -1.1441487073898315e-01
    z[2,5,2]  R2016     3.7345755100250244e-01
    z[2,5,2]  R2017     4.0972551703453064e-01
    z[2,5,2]  R2018     7.2683101892471313e-01
    z[2,5,2]  R2019     6.2340795993804932e-01
    z[2,5,2]  R2020     1.4043259620666504e-01
    z[2,5,2]  R2021     -1.3547022640705109e-01
    z[2,5,2]  R2022     1.2957191467285156e-01
    z[2,5,2]  R2023     4.8817488551139832e-01
    z[2,5,2]  R2024     5.4580259323120117e-01
    z[2,5,2]  R2025     4.9789234995841980e-01
    z[2,5,2]  R2026     -2.2322230041027069e-01
    z[2,5,2]  R2027     -2.6471281051635742e-01
    z[2,5,2]  R2028     6.1506575345993042e-01
    z[2,5,2]  R2029     4.2768985033035278e-01
    z[2,5,2]  R2030     5.0138247013092041e-01
    z[2,5,2]  R2031     -1.3325053453445435e-01
    z[2,5,2]  R2032     -8.8966287672519684e-02
    z[2,5,2]  R2033     1.1987017840147018e-01
    z[2,5,2]  R2034     -2.1370720863342285e-01
    z[2,5,2]  R2035     -1.6838872432708740e-01
    z[2,5,2]  R2036     2.0024140179157257e-01
    z[2,5,2]  R2037     4.3591436743736267e-01
    z[2,5,2]  R2038     -2.5082439184188843e-01
    z[2,5,2]  R2039     -4.9486222863197327e-01
    z[2,5,2]  R2040     -8.3715015649795532e-01
    z[2,5,2]  R2041     -6.9883072376251221e-01
    z[2,5,2]  R2042     -8.6587077379226685e-01
    z[2,5,2]  R2043     -4.6348148584365845e-01
    z[2,5,2]  R2044     -0.835545003414154
    z[2,5,2]  R2045     -3.9633882045745850e-01
    z[2,5,2]  R2046     1.9898726046085358e-01
    z[2,5,2]  R2047     3.1680113077163696e-01
    z[2,5,2]  R2048     4.7050195932388306e-01
    z[2,5,2]  R2049     5.2155035734176636e-01
    z[2,5,2]  R2050     4.4924122095108032e-01
    z[2,5,2]  R2051     5.2330291271209717e-01
    z[2,5,2]  R2052     2.3753516376018524e-01
    z[2,5,2]  R2053     0.685438334941864
    z[2,5,2]  R2054     4.8933586478233337e-01
    z[2,5,2]  R2055     3.0118945240974426e-01
    z[2,5,2]  R2056     3.3472895622253418e-01
    z[2,5,2]  R2057     0.550088107585907
    z[2,5,2]  R2058     -1.4015612006187439e-01
    z[2,5,2]  R2059     3.8528403639793396e-01
    z[2,5,2]  R2060     3.6292123794555664e-01
    z[2,5,2]  R2061     1.1737194657325745e-01
    z[2,5,2]  R2062     1.4842732250690460e-01
    z[2,5,2]  R2063     2.1074037998914719e-02
    z[2,5,2]  R2064     1.3993789255619049e-01
    z[2,5,2]  R2065     1.3967829942703247e-01
    z[2,5,2]  R2066     5.2091282606124878e-01
    z[2,5,2]  R2067     2.3172754049301147e-01
    z[2,5,2]  R2068     0.0881069228053093
    z[2,5,2]  R2069     3.4890773892402649e-01
    z[2,5,2]  R2070     9.3202881515026093e-02
    z[2,5,2]  R2071     2.4517005681991577e-01
    z[2,5,2]  R2072     3.7510260939598083e-01
    z[2,5,2]  R2073     -1.1677806824445724e-01
    z[2,5,2]  R2074     1.2375617772340775e-01
    z[2,5,2]  R2075     1.3580541312694550e-01
    z[2,5,2]  R2076     -4.8568150959908962e-03
    z[2,5,2]  R2077     4.2193382978439331e-01
    z[2,5,2]  R2078     5.0784224271774292e-01
    z[2,5,2]  R2079     6.4672106504440308e-01
    z[2,5,2]  R2080     4.5124414563179016e-01
    z[2,5,2]  R2081     7.5461500883102417e-01
    z[2,5,2]  R2082     4.1927462816238403e-01
    z[2,5,2]  R2083     -1.3850663602352142e-01
    z[2,5,2]  R2084     6.0157597064971924e-01
    z[2,5,2]  R2085     7.0908397436141968e-01
    z[2,5,2]  R2086     2.0411163568496704e-01
    z[2,5,2]  R2087     0.0621710866689682
    z[2,5,2]  R2088     1.0683589428663254e-01
    z[2,5,2]  R2089     2.4507471919059753e-01
    z[2,5,2]  R2090     -0.00966144260019064
    z[2,5,2]  R2091     5.8281403779983521e-01
    z[2,5,2]  R2092     5.8617675304412842e-01
    z[2,5,2]  R2093     4.8749116063117981e-01
    z[2,5,2]  R2094     8.3031928539276123e-01
    z[2,5,2]  R2095     6.2518283724784851e-02
    z[2,5,2]  R2096     -2.0371995866298676e-01
    z[2,5,2]  R2097     7.6282203197479248e-01
    z[2,5,2]  R2098     9.7577020525932312e-02
    z[2,5,2]  R2099     6.3724607229232788e-01
    z[2,5,2]  R2100     0.546921968460083
    z[2,5,2]  R2101     7.2423154115676880e-01
    z[2,5,2]  R2102     -2.3010337352752686e-01
    z[2,5,2]  R2103     2.2679027169942856e-02
    z[2,5,2]  R2104     1.8637599050998688e-01
    z[2,5,2]  R2105     8.1958460807800293e-01
    z[2,5,2]  R2106     3.5175395011901855e-01
    z[2,5,2]  R2107     0.812131404876709
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1940     -1
    z[2,5,3]  R1941     1
    z[2,5,3]  R1948     5.8361768722534180e-01
    z[2,5,3]  R1949     4.6935808658599854e-01
    z[2,5,3]  R1950     4.0347889065742493e-01
    z[2,5,3]  R1951     5.5925935506820679e-01
    z[2,5,3]  R1952     4.1561439633369446e-01
    z[2,5,3]  R1953     8.5939311981201172e-01
    z[2,5,3]  R1954     0.275499552488327
    z[2,5,3]  R1955     7.4122303724288940e-01
    z[2,5,3]  R1956     5.0755894184112549e-01
    z[2,5,3]  R1957     1.4604271948337555e-01
    z[2,5,3]  R1958     -4.8070603609085083e-01
    z[2,5,3]  R1959     -0.170390784740448
    z[2,5,3]  R1960     3.8864649832248688e-02
    z[2,5,3]  R1961     -0.148195281624794
    z[2,5,3]  R1962     -0.068141870200634
    z[2,5,3]  R1963     0.0461047999560833
    z[2,5,3]  R1964     7.8676626086235046e-02
    z[2,5,3]  R1965     1.0513123869895935e-01
    z[2,5,3]  R1966     0.0667092427611351
    z[2,5,3]  R1967     2.0522156357765198e-01
    z[2,5,3]  R1968     -2.3449407517910004e-01
    z[2,5,3]  R1969     -1.1086897552013397e-01
    z[2,5,3]  R1970     1.3058193027973175e-01
    z[2,5,3]  R1971     -1.5165399014949799e-01
    z[2,5,3]  R1972     -3.3748653531074524e-01
    z[2,5,3]  R1973     -3.0212721228599548e-01
    z[2,5,3]  R1974     -1.4454054832458496e-01
    z[2,5,3]  R1975     -0.0949816182255745
    z[2,5,3]  R1976     -0.00844635721296072
    z[2,5,3]  R1977     -0.072464220225811
    z[2,5,3]  R1978     2.6678740978240967e-01
    z[2,5,3]  R1979     1.5070120804011822e-02
    z[2,5,3]  R1980     -5.3139245510101318e-01
    z[2,5,3]  R1981     -2.8727075085043907e-02
    z[2,5,3]  R1982     -9.5711521804332733e-02
    z[2,5,3]  R1983     -7.4008852243423462e-02
    z[2,5,3]  R1984     9.4357088208198547e-02
    z[2,5,3]  R1985     -5.3052004426717758e-02
    z[2,5,3]  R1986     -2.3163458704948425e-01
    z[2,5,3]  R1987     2.2300805151462555e-01
    z[2,5,3]  R1988     1.6113524138927460e-01
    z[2,5,3]  R1989     -2.3640665411949158e-01
    z[2,5,3]  R1990     -3.4317496418952942e-01
    z[2,5,3]  R1991     -3.7083217501640320e-01
    z[2,5,3]  R1992     -9.3176349997520447e-02
    z[2,5,3]  R1993     -7.2438023984432220e-02
    z[2,5,3]  R1994     -3.0139824748039246e-01
    z[2,5,3]  R1995     -1.7185065150260925e-01
    z[2,5,3]  R1996     -1.4382113516330719e-01
    z[2,5,3]  R1997     -1.5414026379585266e-01
    z[2,5,3]  R1998     2.1110512316226959e-01
    z[2,5,3]  R1999     -3.6252435296773911e-02
    z[2,5,3]  R2000     -0.321154922246933
    z[2,5,3]  R2001     1.9282083213329315e-01
    z[2,5,3]  R2002     -1.6128194332122803e-01
    z[2,5,3]  R2003     -1.8521138699725270e-03
    z[2,5,3]  R2004     -1.4850957691669464e-01
    z[2,5,3]  R2005     2.2216208279132843e-01
    z[2,5,3]  R2006     -1.8443416059017181e-01
    z[2,5,3]  R2007     -5.6029386818408966e-02
    z[2,5,3]  R2008     1.2959238886833191e-01
    z[2,5,3]  R2009     4.5644771307706833e-02
    z[2,5,3]  R2010     -1.8064694106578827e-01
    z[2,5,3]  R2011     8.3385735750198364e-02
    z[2,5,3]  R2012     2.6409700512886047e-01
    z[2,5,3]  R2013     3.6392763257026672e-01
    z[2,5,3]  R2014     -0.806171178817749
    z[2,5,3]  R2015     -8.5051637887954712e-01
    z[2,5,3]  R2016     6.0818102210760117e-02
    z[2,5,3]  R2017     -1.5635755658149719e-01
    z[2,5,3]  R2018     -5.2543841302394867e-02
    z[2,5,3]  R2019     -2.5762656331062317e-01
    z[2,5,3]  R2020     5.9513457119464874e-02
    z[2,5,3]  R2021     1.8277665600180626e-02
    z[2,5,3]  R2022     1.0919960588216782e-01
    z[2,5,3]  R2023     -4.5451596379280090e-01
    z[2,5,3]  R2024     -4.6350872516632080e-01
    z[2,5,3]  R2025     3.5328158736228943e-01
    z[2,5,3]  R2026     -4.3283212184906006e-01
    z[2,5,3]  R2027     -5.5757224559783936e-01
    z[2,5,3]  R2028     -3.1490195542573929e-02
    z[2,5,3]  R2029     -9.0821079909801483e-02
    z[2,5,3]  R2030     -4.4099974632263184e-01
    z[2,5,3]  R2031     -8.5201394557952881e-01
    z[2,5,3]  R2032     -7.7582234144210815e-01
    z[2,5,3]  R2033     -0.92115718126297
    z[2,5,3]  R2034     -9.0703666210174561e-01
    z[2,5,3]  R2035     -8.0508148670196533e-01
    z[2,5,3]  R2036     1.9683811068534851e-01
    z[2,5,3]  R2037     -1.1682634800672531e-01
    z[2,5,3]  R2038     5.9576869010925293e-01
    z[2,5,3]  R2039     3.9372414350509644e-01
    z[2,5,3]  R2040     1.3222867250442505e-01
    z[2,5,3]  R2041     6.4013522863388062e-01
    z[2,5,3]  R2042     1.5869811177253723e-01
    z[2,5,3]  R2043     6.4389592409133911e-01
    z[2,5,3]  R2044     2.3036353290081024e-01
    z[2,5,3]  R2045     4.4051659107208252e-01
    z[2,5,3]  R2046     1.5037453733384609e-02
    z[2,5,3]  R2047     7.1662895381450653e-02
    z[2,5,3]  R2048     -1.1776566505432129e-01
    z[2,5,3]  R2049     -1.3404813408851624e-01
    z[2,5,3]  R2050     -1.9995562732219696e-01
    z[2,5,3]  R2051     -4.2782168835401535e-02
    z[2,5,3]  R2052     -3.0475902557373047e-01
    z[2,5,3]  R2053     -4.1686594486236572e-01
    z[2,5,3]  R2054     -3.8454201817512512e-01
    z[2,5,3]  R2055     -5.1275640726089478e-01
    z[2,5,3]  R2056     -4.1546443104743958e-01
    z[2,5,3]  R2057     -3.2571017742156982e-01
    z[2,5,3]  R2058     -1.3579273223876953e-01
    z[2,5,3]  R2059     1.1743741482496262e-01
    z[2,5,3]  R2060     -9.0006791055202484e-02
    z[2,5,3]  R2061     -3.6825048923492432e-01
    z[2,5,3]  R2062     -5.0619250535964966e-01
    z[2,5,3]  R2063     -5.6021952629089355e-01
    z[2,5,3]  R2064     -3.8618949055671692e-01
    z[2,5,3]  R2065     -3.2842054963111877e-01
    z[2,5,3]  R2066     -3.1660124659538269e-01
    z[2,5,3]  R2067     -3.8760277628898621e-01
    z[2,5,3]  R2068     -2.8610104322433472e-01
    z[2,5,3]  R2069     3.0981364846229553e-01
    z[2,5,3]  R2070     4.0037342905998230e-01
    z[2,5,3]  R2071     -5.9528566896915436e-02
    z[2,5,3]  R2072     -3.6331480741500854e-01
    z[2,5,3]  R2073     -8.4577780961990356e-01
    z[2,5,3]  R2074     -7.9938125610351562e-01
    z[2,5,3]  R2075     -0.662041962146759
    z[2,5,3]  R2076     -0.797913670539856
    z[2,5,3]  R2077     -4.7221881151199341e-01
    z[2,5,3]  R2078     -6.7318767309188843e-02
    z[2,5,3]  R2079     -1.2998647987842560e-01
    z[2,5,3]  R2080     -4.8076048493385315e-01
    z[2,5,3]  R2081     9.2176847159862518e-02
    z[2,5,3]  R2082     -5.8152031898498535e-01
    z[2,5,3]  R2083     -8.3289182186126709e-01
    z[2,5,3]  R2084     -5.7208532094955444e-01
    z[2,5,3]  R2085     -3.0186501145362854e-01
    z[2,5,3]  R2086     -5.2364188432693481e-01
    z[2,5,3]  R2087     -8.4814244508743286e-01
    z[2,5,3]  R2088     4.1239511966705322e-01
    z[2,5,3]  R2089     -4.8379480838775635e-02
    z[2,5,3]  R2090     -4.6403801441192627e-01
    z[2,5,3]  R2091     -4.0619453787803650e-01
    z[2,5,3]  R2092     -4.2855963110923767e-01
    z[2,5,3]  R2093     5.4446242749691010e-02
    z[2,5,3]  R2094     -3.3980420231819153e-01
    z[2,5,3]  R2095     -0.851863443851471
    z[2,5,3]  R2096     -8.3771157264709473e-01
    z[2,5,3]  R2097     -9.4819359481334686e-02
    z[2,5,3]  R2098     -0.722500741481781
    z[2,5,3]  R2099     -2.0860888063907623e-01
    z[2,5,3]  R2100     -2.0605309307575226e-01
    z[2,5,3]  R2101     2.8400283306837082e-02
    z[2,5,3]  R2102     -0.847332775592804
    z[2,5,3]  R2103     -8.6517196893692017e-01
    z[2,5,3]  R2104     -6.3254356384277344e-01
    z[2,5,3]  R2105     -2.6408711075782776e-01
    z[2,5,3]  R2106     -7.7237951755523682e-01
    z[2,5,3]  R2107     3.1130319833755493e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1942     -1
    z[2,5,4]  R1943     1
    z[2,5,4]  R1948     -1.3866421580314636e-01
    z[2,5,4]  R1949     0.4262675344944
    z[2,5,4]  R1950     1.2889516353607178e-01
    z[2,5,4]  R1951     -2.1842949092388153e-02
    z[2,5,4]  R1952     -3.7414006888866425e-02
    z[2,5,4]  R1953     -9.2173544690012932e-03
    z[2,5,4]  R1954     9.3282364308834076e-02
    z[2,5,4]  R1955     1.4299346506595612e-01
    z[2,5,4]  R1956     1.1714073270559311e-01
    z[2,5,4]  R1957     3.7614884972572327e-01
    z[2,5,4]  R1958     0.0735994279384613
    z[2,5,4]  R1959     6.7542046308517456e-02
    z[2,5,4]  R1960     2.3088328540325165e-01
    z[2,5,4]  R1961     -9.5550626516342163e-02
    z[2,5,4]  R1962     -1.7954094707965851e-01
    z[2,5,4]  R1963     3.1480357050895691e-01
    z[2,5,4]  R1964     1.8796192109584808e-01
    z[2,5,4]  R1965     8.3698770031332970e-03
    z[2,5,4]  R1966     0.0705980509519577
    z[2,5,4]  R1967     2.6583236455917358e-01
    z[2,5,4]  R1968     -3.7515938282012939e-01
    z[2,5,4]  R1969     -4.4282034039497375e-01
    z[2,5,4]  R1970     -1.6256643831729889e-01
    z[2,5,4]  R1971     1.1624976247549057e-01
    z[2,5,4]  R1972     2.3277167975902557e-01
    z[2,5,4]  R1973     1.8302576243877411e-01
    z[2,5,4]  R1974     2.3575511574745178e-01
    z[2,5,4]  R1975     -9.6358023583889008e-02
    z[2,5,4]  R1976     1.0487534105777740e-01
    z[2,5,4]  R1977     -2.3561987280845642e-01
    z[2,5,4]  R1978     -9.4050276279449463e-01
    z[2,5,4]  R1979     -5.3487664461135864e-01
    z[2,5,4]  R1980     -5.0266232341527939e-02
    z[2,5,4]  R1981     -3.7714448571205139e-01
    z[2,5,4]  R1982     7.5331604480743408e-01
    z[2,5,4]  R1983     4.3590095639228821e-01
    z[2,5,4]  R1984     5.7433921843767166e-02
    z[2,5,4]  R1985     -0.0620078481733799
    z[2,5,4]  R1986     4.7839531302452087e-01
    z[2,5,4]  R1987     1.7153675854206085e-01
    z[2,5,4]  R1988     -2.6997578144073486e-01
    z[2,5,4]  R1989     1.3102343678474426e-01
    z[2,5,4]  R1990     -6.5804773569107056e-01
    z[2,5,4]  R1991     -2.1013745665550232e-01
    z[2,5,4]  R1992     -0.456379771232605
    z[2,5,4]  R1993     2.5651317834854126e-01
    z[2,5,4]  R1994     4.8555487394332886e-01
    z[2,5,4]  R1995     0.181008979678154
    z[2,5,4]  R1996     -2.8443282842636108e-01
    z[2,5,4]  R1997     -6.0795680619776249e-03
    z[2,5,4]  R1998     -5.2893245220184326e-01
    z[2,5,4]  R1999     -7.8231376409530640e-01
    z[2,5,4]  R2000     -5.5640321969985962e-01
    z[2,5,4]  R2001     -6.1660176515579224e-01
    z[2,5,4]  R2002     -3.5854494571685791e-01
    z[2,5,4]  R2003     3.8253688812255859e-01
    z[2,5,4]  R2004     -1.3372954726219177e-01
    z[2,5,4]  R2005     4.8215255141258240e-02
    z[2,5,4]  R2006     -7.5708419084548950e-01
    z[2,5,4]  R2007     -8.2201175391674042e-02
    z[2,5,4]  R2008     -1.6545540094375610e-01
    z[2,5,4]  R2009     -1.9630345702171326e-01
    z[2,5,4]  R2010     -0.774272620677948
    z[2,5,4]  R2011     2.1603046357631683e-01
    z[2,5,4]  R2012     -3.5607546567916870e-01
    z[2,5,4]  R2013     -2.8958949446678162e-01
    z[2,5,4]  R2014     -3.5417255759239197e-01
    z[2,5,4]  R2015     -2.1766684949398041e-01
    z[2,5,4]  R2016     -2.9416689649224281e-02
    z[2,5,4]  R2017     9.9350109696388245e-02
    z[2,5,4]  R2018     3.9517775177955627e-01
    z[2,5,4]  R2019     0.206630676984787
    z[2,5,4]  R2020     2.1284732222557068e-01
    z[2,5,4]  R2021     3.7563538551330566e-01
    z[2,5,4]  R2022     6.9434428215026855e-01
    z[2,5,4]  R2023     -4.8193059861660004e-02
    z[2,5,4]  R2024     2.4971835315227509e-01
    z[2,5,4]  R2025     0.300087571144104
    z[2,5,4]  R2026     -4.5681995153427124e-01
    z[2,5,4]  R2027     -4.3525260686874390e-01
    z[2,5,4]  R2028     1.1224637180566788e-01
    z[2,5,4]  R2029     4.8872217535972595e-01
    z[2,5,4]  R2030     2.8599053621292114e-01
    z[2,5,4]  R2031     -1.3222269713878632e-01
    z[2,5,4]  R2032     -4.7229605913162231e-01
    z[2,5,4]  R2033     -1.6047553718090057e-01
    z[2,5,4]  R2034     7.0403993129730225e-02
    z[2,5,4]  R2035     4.3914973735809326e-01
    z[2,5,4]  R2036     3.7198930978775024e-01
    z[2,5,4]  R2037     5.9806394577026367e-01
    z[2,5,4]  R2038     -1.4564444124698639e-01
    z[2,5,4]  R2039     3.8416441529989243e-02
    z[2,5,4]  R2040     1.7567806644365191e-03
    z[2,5,4]  R2041     2.4478648602962494e-01
    z[2,5,4]  R2042     9.6992768347263336e-02
    z[2,5,4]  R2043     2.1350033581256866e-01
    z[2,5,4]  R2044     -2.7428719401359558e-01
    z[2,5,4]  R2045     6.8304139375686646e-01
    z[2,5,4]  R2046     1.2113102525472641e-01
    z[2,5,4]  R2047     2.5525709614157677e-02
    z[2,5,4]  R2048     -2.7946668863296509e-01
    z[2,5,4]  R2049     2.1172559261322021e-01
    z[2,5,4]  R2050     -1.7210589349269867e-01
    z[2,5,4]  R2051     2.4047857522964478e-01
    z[2,5,4]  R2052     1.0388135910034180e-02
    z[2,5,4]  R2053     2.1524070203304291e-01
    z[2,5,4]  R2054     -3.8811179995536804e-01
    z[2,5,4]  R2055     1.0021328926086426e-01
    z[2,5,4]  R2056     -4.2036247253417969e-01
    z[2,5,4]  R2057     -2.8724148869514465e-01
    z[2,5,4]  R2058     -9.4732575118541718e-02
    z[2,5,4]  R2059     -4.5010432600975037e-01
    z[2,5,4]  R2060     -2.0135407149791718e-01
    z[2,5,4]  R2061     -2.9905600473284721e-02
    z[2,5,4]  R2062     0.159097358584404
    z[2,5,4]  R2063     3.3481064438819885e-01
    z[2,5,4]  R2064     -2.0056806504726410e-01
    z[2,5,4]  R2065     8.6779326200485229e-02
    z[2,5,4]  R2066     1.1984530836343765e-02
    z[2,5,4]  R2067     -0.496004581451416
    z[2,5,4]  R2068     -0.531998336315155
    z[2,5,4]  R2069     -6.1312294006347656e-01
    z[2,5,4]  R2070     -5.4920804500579834e-01
    z[2,5,4]  R2071     1.8354912102222443e-01
    z[2,5,4]  R2072     -0.276263952255249
    z[2,5,4]  R2073     -4.0148639678955078e-01
    z[2,5,4]  R2074     -4.6598100662231445e-01
    z[2,5,4]  R2075     -4.0774139761924744e-01
    z[2,5,4]  R2076     -4.0382185578346252e-01
    z[2,5,4]  R2077     5.0118589401245117e-01
    z[2,5,4]  R2078     2.6180425286293030e-01
    z[2,5,4]  R2079     -0.282550573348999
    z[2,5,4]  R2080     -6.2645196914672852e-02
    z[2,5,4]  R2081     -1.2329094856977463e-01
    z[2,5,4]  R2082     -0.0234454907476902
    z[2,5,4]  R2083     -1.5201459825038910e-01
    z[2,5,4]  R2084     -1.1735180765390396e-01
    z[2,5,4]  R2085     5.4263092577457428e-02
    z[2,5,4]  R2086     1.4913311600685120e-01
    z[2,5,4]  R2087     -2.5151485204696655e-01
    z[2,5,4]  R2088     -5.0076740980148315e-01
    z[2,5,4]  R2089     3.4647189080715179e-02
    z[2,5,4]  R2090     1.5218664705753326e-01
    z[2,5,4]  R2091     -0.0744100883603096
    z[2,5,4]  R2092     -1.8353520333766937e-01
    z[2,5,4]  R2093     1.3839547336101532e-01
    z[2,5,4]  R2094     4.5360937714576721e-02
    z[2,5,4]  R2095     -2.7728980779647827e-01
    z[2,5,4]  R2096     -8.2025587558746338e-02
    z[2,5,4]  R2097     1.3995287939906120e-02
    z[2,5,4]  R2098     1.8421135842800140e-01
    z[2,5,4]  R2099     -1.1290358752012253e-01
    z[2,5,4]  R2100     1.5742288529872894e-01
    z[2,5,4]  R2101     -1.0554249398410320e-02
    z[2,5,4]  R2102     -1.9067689776420593e-01
    z[2,5,4]  R2103     -3.3969292044639587e-01
    z[2,5,4]  R2104     -5.9137541055679321e-01
    z[2,5,4]  R2105     -1.1788047850131989e-01
    z[2,5,4]  R2106     -2.7381590008735657e-01
    z[2,5,4]  R2107     3.5458293557167053e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1944     -1
    z[2,5,5]  R1945     1
    z[2,5,5]  R1948     -5.7709765434265137e-01
    z[2,5,5]  R1949     -3.5071596503257751e-01
    z[2,5,5]  R1950     -0.278903067111969
    z[2,5,5]  R1951     5.8221589773893356e-02
    z[2,5,5]  R1952     -0.517057478427887
    z[2,5,5]  R1953     -1.5165178477764130e-01
    z[2,5,5]  R1954     -2.3012003302574158e-01
    z[2,5,5]  R1955     -1.0831041634082794e-01
    z[2,5,5]  R1956     -4.0791058540344238e-01
    z[2,5,5]  R1957     -7.4242120981216431e-01
    z[2,5,5]  R1958     3.2431101799011230e-01
    z[2,5,5]  R1959     1.3020985759794712e-02
    z[2,5,5]  R1960     1.7334592342376709e-01
    z[2,5,5]  R1961     2.3370157182216644e-01
    z[2,5,5]  R1962     3.6393117904663086e-01
    z[2,5,5]  R1963     3.2534962892532349e-01
    z[2,5,5]  R1964     0.166063129901886
    z[2,5,5]  R1965     9.8060876131057739e-02
    z[2,5,5]  R1966     2.5930896401405334e-01
    z[2,5,5]  R1967     2.8347793221473694e-01
    z[2,5,5]  R1968     -2.1221968531608582e-01
    z[2,5,5]  R1969     -2.6262289285659790e-01
    z[2,5,5]  R1970     3.7324330210685730e-01
    z[2,5,5]  R1971     1.0355718433856964e-01
    z[2,5,5]  R1972     -2.0006487146019936e-02
    z[2,5,5]  R1973     3.7442959845066071e-02
    z[2,5,5]  R1974     3.6605718731880188e-01
    z[2,5,5]  R1975     2.8392788767814636e-01
    z[2,5,5]  R1976     2.2410650551319122e-01
    z[2,5,5]  R1977     3.9185580611228943e-01
    z[2,5,5]  R1978     -4.6332050114870071e-02
    z[2,5,5]  R1979     -2.9014545679092407e-01
    z[2,5,5]  R1980     3.3672028779983521e-01
    z[2,5,5]  R1981     5.5800926685333252e-01
    z[2,5,5]  R1982     0.097394198179245
    z[2,5,5]  R1983     3.9934930391609669e-03
    z[2,5,5]  R1984     6.4718961715698242e-02
    z[2,5,5]  R1985     4.3009036779403687e-01
    z[2,5,5]  R1986     -1.2009969353675842e-01
    z[2,5,5]  R1987     0.0447159968316555
    z[2,5,5]  R1988     1.9053022563457489e-01
    z[2,5,5]  R1989     1.5491028130054474e-01
    z[2,5,5]  R1990     -4.1099965572357178e-01
    z[2,5,5]  R1991     -3.3980360627174377e-01
    z[2,5,5]  R1992     2.9551693797111511e-01
    z[2,5,5]  R1993     2.8076082468032837e-02
    z[2,5,5]  R1994     4.3349310755729675e-02
    z[2,5,5]  R1995     0.0949019193649292
    z[2,5,5]  R1996     -1.9856201112270355e-01
    z[2,5,5]  R1997     3.4327441453933716e-01
    z[2,5,5]  R1998     -0.295166552066803
    z[2,5,5]  R1999     -3.4717667102813721e-01
    z[2,5,5]  R2000     -3.6521118879318237e-01
    z[2,5,5]  R2001     -1.5804505348205566e-01
    z[2,5,5]  R2002     -6.1893957853317261e-01
    z[2,5,5]  R2003     2.2514855861663818e-01
    z[2,5,5]  R2004     -8.1602893769741058e-02
    z[2,5,5]  R2005     -3.0847036838531494e-01
    z[2,5,5]  R2006     -2.2324765101075172e-02
    z[2,5,5]  R2007     -1.1252982169389725e-01
    z[2,5,5]  R2008     -5.4488635063171387e-01
    z[2,5,5]  R2009     -2.3003305494785309e-01
    z[2,5,5]  R2010     8.4717579185962677e-02
    z[2,5,5]  R2011     -2.1322610974311829e-01
    z[2,5,5]  R2012     -3.1098678708076477e-01
    z[2,5,5]  R2013     -4.3563401699066162e-01
    z[2,5,5]  R2014     4.3798366189002991e-01
    z[2,5,5]  R2015     2.8272947669029236e-01
    z[2,5,5]  R2016     2.6798954606056213e-01
    z[2,5,5]  R2017     4.4543093442916870e-01
    z[2,5,5]  R2018     1.1807820200920105e-01
    z[2,5,5]  R2019     -2.0969074964523315e-01
    z[2,5,5]  R2020     0.584648609161377
    z[2,5,5]  R2021     4.6253389120101929e-01
    z[2,5,5]  R2022     1.1077541112899780e-01
    z[2,5,5]  R2023     3.1556141376495361e-01
    z[2,5,5]  R2024     1.1781197786331177e-01
    z[2,5,5]  R2025     3.8323265314102173e-01
    z[2,5,5]  R2026     5.9083163738250732e-01
    z[2,5,5]  R2027     5.3693127632141113e-01
    z[2,5,5]  R2028     1.5663637220859528e-01
    z[2,5,5]  R2029     4.1953021287918091e-01
    z[2,5,5]  R2030     2.4167820811271667e-01
    z[2,5,5]  R2031     2.1930266916751862e-01
    z[2,5,5]  R2032     2.1439573168754578e-01
    z[2,5,5]  R2033     2.9126736521720886e-01
    z[2,5,5]  R2034     1.5991058945655823e-01
    z[2,5,5]  R2035     9.4435155391693115e-02
    z[2,5,5]  R2036     2.6526299118995667e-01
    z[2,5,5]  R2037     3.2946422696113586e-01
    z[2,5,5]  R2038     -6.1933767795562744e-01
    z[2,5,5]  R2039     -6.4784586429595947e-01
    z[2,5,5]  R2040     -3.0371937155723572e-01
    z[2,5,5]  R2041     -5.0053298473358154e-02
    z[2,5,5]  R2042     -3.3766743727028370e-03
    z[2,5,5]  R2043     0.0362824983894825
    z[2,5,5]  R2044     1.8293833732604980e-01
    z[2,5,5]  R2045     -1.8776687979698181e-01
    z[2,5,5]  R2046     -5.7682663202285767e-02
    z[2,5,5]  R2047     -0.0266642477363348
    z[2,5,5]  R2048     3.4906172752380371e-01
    z[2,5,5]  R2049     1.1849937587976456e-01
    z[2,5,5]  R2050     5.4500085115432739e-01
    z[2,5,5]  R2051     2.6853027939796448e-01
    z[2,5,5]  R2052     -3.2048285007476807e-01
    z[2,5,5]  R2053     3.7137782573699951e-01
    z[2,5,5]  R2054     1.8925306200981140e-01
    z[2,5,5]  R2055     2.7644780930131674e-03
    z[2,5,5]  R2056     1.9587117433547974e-01
    z[2,5,5]  R2057     2.6655626296997070e-01
    z[2,5,5]  R2058     6.3775390386581421e-01
    z[2,5,5]  R2059     2.7203616499900818e-01
    z[2,5,5]  R2060     -2.9853606224060059e-01
    z[2,5,5]  R2061     2.7603876590728760e-01
    z[2,5,5]  R2062     -5.6742765009403229e-02
    z[2,5,5]  R2063     1.1412044614553452e-01
    z[2,5,5]  R2064     -5.1465284079313278e-02
    z[2,5,5]  R2065     -1.3932244479656219e-01
    z[2,5,5]  R2066     -2.9125756118446589e-03
    z[2,5,5]  R2067     -2.9701529070734978e-02
    z[2,5,5]  R2068     -3.7494511343538761e-03
    z[2,5,5]  R2069     3.4458752721548080e-02
    z[2,5,5]  R2070     3.0400335788726807e-01
    z[2,5,5]  R2071     5.9104061126708984e-01
    z[2,5,5]  R2072     -0.0534505657851696
    z[2,5,5]  R2073     1.9277544319629669e-01
    z[2,5,5]  R2074     2.4191319942474365e-01
    z[2,5,5]  R2075     5.5073505640029907e-01
    z[2,5,5]  R2076     3.1129565834999084e-01
    z[2,5,5]  R2077     3.4153786301612854e-01
    z[2,5,5]  R2078     3.9113840460777283e-01
    z[2,5,5]  R2079     4.2109638452529907e-01
    z[2,5,5]  R2080     4.3957060575485229e-01
    z[2,5,5]  R2081     1.9891719520092010e-01
    z[2,5,5]  R2082     -5.1018454134464264e-02
    z[2,5,5]  R2083     4.7241061925888062e-01
    z[2,5,5]  R2084     -1.1062230169773102e-01
    z[2,5,5]  R2085     2.1643431484699249e-01
    z[2,5,5]  R2086     4.2171150445938110e-01
    z[2,5,5]  R2087     3.6347669363021851e-01
    z[2,5,5]  R2088     2.6701900362968445e-01
    z[2,5,5]  R2089     -2.6293733716011047e-01
    z[2,5,5]  R2090     -1.1496489495038986e-01
    z[2,5,5]  R2091     0.0418475866317749
    z[2,5,5]  R2092     3.5667872428894043e-01
    z[2,5,5]  R2093     -1.0689385980367661e-01
    z[2,5,5]  R2094     2.3131118714809418e-01
    z[2,5,5]  R2095     2.0413130521774292e-01
    z[2,5,5]  R2096     3.2589516043663025e-01
    z[2,5,5]  R2097     -1.9784484058618546e-02
    z[2,5,5]  R2098     5.9179648756980896e-02
    z[2,5,5]  R2099     7.2134897112846375e-02
    z[2,5,5]  R2100     1.1516427993774414e-01
    z[2,5,5]  R2101     3.3080011606216431e-01
    z[2,5,5]  R2102     4.1496536135673523e-01
    z[2,5,5]  R2103     2.4856556951999664e-01
    z[2,5,5]  R2104     4.6000748872756958e-01
    z[2,5,5]  R2105     -5.1871344447135925e-02
    z[2,5,5]  R2106     3.1858170032501221e-01
    z[2,5,5]  R2107     8.2440860569477081e-02
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1946     -1
    z[2,5,6]  R1947     1
    z[2,5,6]  R1948     -1.7919200658798218e-01
    z[2,5,6]  R1949     1.1737052351236343e-01
    z[2,5,6]  R1950     -3.0322477221488953e-01
    z[2,5,6]  R1951     -7.3339521884918213e-02
    z[2,5,6]  R1952     -0.586080014705658
    z[2,5,6]  R1953     1.4169251918792725e-01
    z[2,5,6]  R1954     1.3314105570316315e-01
    z[2,5,6]  R1955     2.2169493138790131e-01
    z[2,5,6]  R1956     0.506830632686615
    z[2,5,6]  R1957     -2.3363646864891052e-01
    z[2,5,6]  R1958     4.2107634246349335e-02
    z[2,5,6]  R1959     -1.0225398838520050e-01
    z[2,5,6]  R1960     -1.1910647153854370e-01
    z[2,5,6]  R1961     -4.8612681031227112e-01
    z[2,5,6]  R1962     -1.8703129887580872e-01
    z[2,5,6]  R1963     1.1156961321830750e-01
    z[2,5,6]  R1964     -5.7398449629545212e-02
    z[2,5,6]  R1965     1.1197334527969360e-01
    z[2,5,6]  R1966     2.9366193339228630e-02
    z[2,5,6]  R1967     -8.4692798554897308e-02
    z[2,5,6]  R1968     3.4464153647422791e-01
    z[2,5,6]  R1969     -2.0486536622047424e-01
    z[2,5,6]  R1970     -0.359995037317276
    z[2,5,6]  R1971     6.2019795179367065e-02
    z[2,5,6]  R1972     -6.6353239119052887e-02
    z[2,5,6]  R1973     -4.7712358832359314e-01
    z[2,5,6]  R1974     -2.9085966944694519e-01
    z[2,5,6]  R1975     1.4768464863300323e-01
    z[2,5,6]  R1976     0.361070841550827
    z[2,5,6]  R1977     6.4369112253189087e-01
    z[2,5,6]  R1978     3.3611815422773361e-02
    z[2,5,6]  R1979     5.8424003422260284e-02
    z[2,5,6]  R1980     2.9420611262321472e-01
    z[2,5,6]  R1981     3.5556632280349731e-01
    z[2,5,6]  R1982     2.7982246875762939e-01
    z[2,5,6]  R1983     -1.7918157577514648e-01
    z[2,5,6]  R1984     -3.9160954952239990e-01
    z[2,5,6]  R1985     2.5816816091537476e-01
    z[2,5,6]  R1986     5.3819339722394943e-02
    z[2,5,6]  R1987     1.6115494072437286e-01
    z[2,5,6]  R1988     1.5988571941852570e-01
    z[2,5,6]  R1989     5.4371935129165649e-01
    z[2,5,6]  R1990     -2.3824411630630493e-01
    z[2,5,6]  R1991     0.0323464460670948
    z[2,5,6]  R1992     -3.2886481285095215e-01
    z[2,5,6]  R1993     -2.0483744144439697e-01
    z[2,5,6]  R1994     -6.2456015497446060e-02
    z[2,5,6]  R1995     -6.0060225427150726e-02
    z[2,5,6]  R1996     -3.7260480225086212e-02
    z[2,5,6]  R1997     -8.9438818395137787e-02
    z[2,5,6]  R1998     3.6358860135078430e-01
    z[2,5,6]  R1999     -1.4429277181625366e-01
    z[2,5,6]  R2000     2.7114427089691162e-01
    z[2,5,6]  R2001     -3.8851892948150635e-01
    z[2,5,6]  R2002     1.7991696298122406e-01
    z[2,5,6]  R2003     -2.3394417762756348e-01
    z[2,5,6]  R2004     0.236423060297966
    z[2,5,6]  R2005     -3.3040741086006165e-01
    z[2,5,6]  R2006     -2.5347569584846497e-01
    z[2,5,6]  R2007     -4.4116694480180740e-02
    z[2,5,6]  R2008     1.1758720874786377e-01
    z[2,5,6]  R2009     1.5814271569252014e-01
    z[2,5,6]  R2010     2.6673685759305954e-02
    z[2,5,6]  R2011     -3.2572884112596512e-02
    z[2,5,6]  R2012     1.0089663416147232e-01
    z[2,5,6]  R2013     3.9931874722242355e-02
    z[2,5,6]  R2014     2.9144637286663055e-02
    z[2,5,6]  R2015     -2.0908041298389435e-01
    z[2,5,6]  R2016     5.1410514116287231e-01
    z[2,5,6]  R2017     5.5026924610137939e-01
    z[2,5,6]  R2018     -0.227493554353714
    z[2,5,6]  R2019     -2.5993982329964638e-02
    z[2,5,6]  R2020     2.8447759151458740e-01
    z[2,5,6]  R2021     5.4953861236572266e-01
    z[2,5,6]  R2022     -2.9029166698455811e-01
    z[2,5,6]  R2023     1.8050950765609741e-01
    z[2,5,6]  R2024     4.4846269488334656e-01
    z[2,5,6]  R2025     -6.0303188860416412e-02
    z[2,5,6]  R2026     -2.7751579880714417e-01
    z[2,5,6]  R2027     0.000607263995334506
    z[2,5,6]  R2028     -8.4105335175991058e-02
    z[2,5,6]  R2029     -1.8866260349750519e-01
    z[2,5,6]  R2030     3.8933104276657104e-01
    z[2,5,6]  R2031     -2.7347257733345032e-01
    z[2,5,6]  R2032     -1.3086025416851044e-01
    z[2,5,6]  R2033     -9.8307356238365173e-02
    z[2,5,6]  R2034     2.1744383871555328e-01
    z[2,5,6]  R2035     5.4348301142454147e-02
    z[2,5,6]  R2036     7.5376674532890320e-02
    z[2,5,6]  R2037     1.1221068352460861e-01
    z[2,5,6]  R2038     -8.8365182280540466e-02
    z[2,5,6]  R2039     -3.9545637369155884e-01
    z[2,5,6]  R2040     5.7798791676759720e-02
    z[2,5,6]  R2041     -1.3976109027862549e-01
    z[2,5,6]  R2042     3.2563191652297974e-01
    z[2,5,6]  R2043     3.4999959170818329e-02
    z[2,5,6]  R2044     1.8482497334480286e-01
    z[2,5,6]  R2045     3.5145051777362823e-02
    z[2,5,6]  R2046     1.9077347218990326e-01
    z[2,5,6]  R2047     -3.4835245460271835e-02
    z[2,5,6]  R2048     -1.4184023439884186e-01
    z[2,5,6]  R2049     -1.6157792508602142e-01
    z[2,5,6]  R2050     1.4025190472602844e-01
    z[2,5,6]  R2051     3.3324298262596130e-01
    z[2,5,6]  R2052     1.6489909589290619e-01
    z[2,5,6]  R2053     -1.6969369351863861e-01
    z[2,5,6]  R2054     4.1545432060956955e-02
    z[2,5,6]  R2055     3.2960101962089539e-01
    z[2,5,6]  R2056     9.5377013087272644e-02
    z[2,5,6]  R2057     3.6477804183959961e-01
    z[2,5,6]  R2058     -3.2919496297836304e-01
    z[2,5,6]  R2059     -1.0445023328065872e-01
    z[2,5,6]  R2060     8.2382082939147949e-02
    z[2,5,6]  R2061     9.5949888229370117e-02
    z[2,5,6]  R2062     3.4505769610404968e-01
    z[2,5,6]  R2063     -5.6673612445592880e-02
    z[2,5,6]  R2064     4.2273110151290894e-01
    z[2,5,6]  R2065     -3.5286897420883179e-01
    z[2,5,6]  R2066     -1.8022920191287994e-01
    z[2,5,6]  R2067     9.2139437794685364e-02
    z[2,5,6]  R2068     5.0284836441278458e-02
    z[2,5,6]  R2069     1.9310359656810760e-01
    z[2,5,6]  R2070     -2.2523060441017151e-01
    z[2,5,6]  R2071     -1.0507960803806782e-02
    z[2,5,6]  R2072     3.3523243665695190e-01
    z[2,5,6]  R2073     0.263115257024765
    z[2,5,6]  R2074     -0.0172833651304245
    z[2,5,6]  R2075     2.6480999588966370e-01
    z[2,5,6]  R2076     -0.0742039605975151
    z[2,5,6]  R2077     2.3711478710174561e-01
    z[2,5,6]  R2078     5.6914114393293858e-03
    z[2,5,6]  R2079     2.4102061986923218e-01
    z[2,5,6]  R2080     -1.9952252507209778e-01
    z[2,5,6]  R2081     6.1366468667984009e-02
    z[2,5,6]  R2082     8.4016129374504089e-02
    z[2,5,6]  R2083     -1.6170255839824677e-01
    z[2,5,6]  R2084     5.7765308767557144e-02
    z[2,5,6]  R2085     3.6379155516624451e-01
    z[2,5,6]  R2086     -1.2155794352293015e-01
    z[2,5,6]  R2087     1.8742622435092926e-01
    z[2,5,6]  R2088     -2.3593294620513916e-01
    z[2,5,6]  R2089     3.0443921685218811e-01
    z[2,5,6]  R2090     -1.3737358152866364e-01
    z[2,5,6]  R2091     1.1643828451633453e-01
    z[2,5,6]  R2092     1.7010244727134705e-01
    z[2,5,6]  R2093     0.232234388589859
    z[2,5,6]  R2094     -5.6208237074315548e-03
    z[2,5,6]  R2095     -2.1610192954540253e-01
    z[2,5,6]  R2096     1.4185032248497009e-01
    z[2,5,6]  R2097     -0.391007661819458
    z[2,5,6]  R2098     -3.9091381430625916e-01
    z[2,5,6]  R2099     -6.0242330655455589e-03
    z[2,5,6]  R2100     1.0224212892353535e-02
    z[2,5,6]  R2101     1.3477612286806107e-02
    z[2,5,6]  R2102     5.7424264959990978e-03
    z[2,5,6]  R2103     -1.5017724037170410e-01
    z[2,5,6]  R2104     -4.2608477175235748e-02
    z[2,5,6]  R2105     -3.2186403870582581e-01
    z[2,5,6]  R2106     -3.1398364901542664e-01
    z[2,5,6]  R2107     0.0945323258638382
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R2108     -1
    z[5,2,0]  R2109     1
    z[5,2,0]  R2122     -4.1167184710502625e-01
    z[5,2,0]  R2123     5.2194584161043167e-02
    z[5,2,0]  R2124     -3.3740440011024475e-01
    z[5,2,0]  R2125     1.4051201939582825e-01
    z[5,2,0]  R2126     -1.3101556897163391e-01
    z[5,2,0]  R2127     2.3414593935012817e-01
    z[5,2,0]  R2128     2.6615265011787415e-01
    z[5,2,0]  R2129     -3.8141000270843506e-01
    z[5,2,0]  R2130     -7.2037017345428467e-01
    z[5,2,0]  R2131     -7.2790348529815674e-01
    z[5,2,0]  R2132     5.0193983316421509e-01
    z[5,2,0]  R2133     3.5697630047798157e-01
    z[5,2,0]  R2134     3.1045895814895630e-01
    z[5,2,0]  R2135     3.5617956519126892e-01
    z[5,2,0]  R2136     -0.0835917741060257
    z[5,2,0]  R2137     2.3714382946491241e-01
    z[5,2,0]  R2138     2.6713207364082336e-01
    z[5,2,0]  R2139     1.8173341453075409e-01
    z[5,2,0]  R2140     4.4621476531028748e-01
    z[5,2,0]  R2141     3.1219500303268433e-01
    z[5,2,0]  R2142     -5.0173097848892212e-01
    z[5,2,0]  R2143     6.3865667581558228e-01
    z[5,2,0]  R2144     6.5449148416519165e-02
    z[5,2,0]  R2145     5.2495366334915161e-01
    z[5,2,0]  R2146     3.5497203469276428e-01
    z[5,2,0]  R2147     4.4768762588500977e-01
    z[5,2,0]  R2148     4.9666678905487061e-01
    z[5,2,0]  R2149     6.2237411737442017e-01
    z[5,2,0]  R2150     4.7753170132637024e-01
    z[5,2,0]  R2151     3.4345629811286926e-01
    z[5,2,0]  R2152     -6.0553711652755737e-01
    z[5,2,0]  R2153     1.7541919648647308e-01
    z[5,2,0]  R2154     5.9707891941070557e-01
    z[5,2,0]  R2155     4.7816035151481628e-01
    z[5,2,0]  R2156     4.8107045888900757e-01
    z[5,2,0]  R2157     0.0420943982899189
    z[5,2,0]  R2158     2.2906219959259033e-01
    z[5,2,0]  R2159     3.0979016795754433e-02
    z[5,2,0]  R2160     -1.0578852146863937e-01
    z[5,2,0]  R2161     3.5713267326354980e-01
    z[5,2,0]  R2162     0.481503427028656
    z[5,2,0]  R2163     0.350081205368042
    z[5,2,0]  R2164     4.4970616698265076e-01
    z[5,2,0]  R2165     1.2914520502090454e-01
    z[5,2,0]  R2166     4.7862935066223145e-01
    z[5,2,0]  R2167     -0.0339871309697628
    z[5,2,0]  R2168     2.8752669692039490e-01
    z[5,2,0]  R2169     4.5326313376426697e-01
    z[5,2,0]  R2170     3.3613637089729309e-01
    z[5,2,0]  R2171     2.0278221368789673e-01
    z[5,2,0]  R2172     6.6347676515579224e-01
    z[5,2,0]  R2173     -2.4898461997509003e-01
    z[5,2,0]  R2174     4.6122840046882629e-01
    z[5,2,0]  R2175     4.9284663796424866e-01
    z[5,2,0]  R2176     4.1822734475135803e-01
    z[5,2,0]  R2177     4.8851454257965088e-01
    z[5,2,0]  R2178     3.4320834279060364e-01
    z[5,2,0]  R2179     1.8371088802814484e-01
    z[5,2,0]  R2180     3.1019492074847221e-02
    z[5,2,0]  R2181     7.1308411657810211e-02
    z[5,2,0]  R2182     -3.9650008082389832e-01
    z[5,2,0]  R2183     5.1104658842086792e-01
    z[5,2,0]  R2184     5.1345431804656982e-01
    z[5,2,0]  R2185     9.9075190722942352e-02
    z[5,2,0]  R2186     1.3918174803256989e-01
    z[5,2,0]  R2187     1.0309685766696930e-01
    z[5,2,0]  R2188     1.3891510665416718e-02
    z[5,2,0]  R2189     6.8562909960746765e-02
    z[5,2,0]  R2190     -6.5475896000862122e-02
    z[5,2,0]  R2191     -2.6827117800712585e-01
    z[5,2,0]  R2192     -2.6873114705085754e-01
    z[5,2,0]  R2193     -3.2073151320219040e-02
    z[5,2,0]  R2194     3.7537875771522522e-01
    z[5,2,0]  R2195     3.6279532313346863e-01
    z[5,2,0]  R2196     2.7410724759101868e-01
    z[5,2,0]  R2197     3.4550437331199646e-01
    z[5,2,0]  R2198     -3.4611618518829346e-01
    z[5,2,0]  R2199     -1.3425517082214355e-01
    z[5,2,0]  R2200     -3.1043639779090881e-01
    z[5,2,0]  R2201     -2.7002862095832825e-01
    z[5,2,0]  R2202     -6.6402232646942139e-01
    z[5,2,0]  R2203     -9.0399205684661865e-01
    z[5,2,0]  R2204     -0.804214358329773
    z[5,2,0]  R2205     -7.4929600954055786e-01
    z[5,2,0]  R2206     -5.9058940410614014e-01
    z[5,2,0]  R2207     -1.7309513350483030e-04
    z[5,2,0]  R2208     6.1451070010662079e-02
    z[5,2,0]  R2209     2.2709189355373383e-01
    z[5,2,0]  R2210     -1.8552179634571075e-01
    z[5,2,0]  R2211     -3.4881201386451721e-01
    z[5,2,0]  R2212     1.3089212775230408e-01
    z[5,2,0]  R2213     -3.5005442332476377e-03
    z[5,2,0]  R2214     5.3854632377624512e-01
    z[5,2,0]  R2215     4.9122610688209534e-01
    z[5,2,0]  R2216     4.4492509961128235e-01
    z[5,2,0]  R2217     2.5517001748085022e-01
    z[5,2,0]  R2218     5.1593577861785889e-01
    z[5,2,0]  R2219     -2.5728667154908180e-02
    z[5,2,0]  R2220     8.3634227514266968e-02
    z[5,2,0]  R2221     3.6626616120338440e-01
    z[5,2,0]  R2222     -8.9695248752832413e-03
    z[5,2,0]  R2223     1.5972553193569183e-01
    z[5,2,0]  R2224     -5.3645157814025879e-01
    z[5,2,0]  R2225     6.3105231523513794e-01
    z[5,2,0]  R2226     -4.2418235540390015e-01
    z[5,2,0]  R2227     5.4071956872940063e-01
    z[5,2,0]  R2228     2.4172581732273102e-01
    z[5,2,0]  R2229     6.0971105098724365e-01
    z[5,2,0]  R2230     1.7035140097141266e-01
    z[5,2,0]  R2231     7.2460480034351349e-02
    z[5,2,0]  R2232     -6.7582845687866211e-01
    z[5,2,0]  R2233     -6.0512125492095947e-01
    z[5,2,0]  R2234     1.4272104203701019e-01
    z[5,2,0]  R2235     -7.2260481119155884e-01
    z[5,2,0]  R2236     6.4754843711853027e-01
    z[5,2,0]  R2237     7.0424085855484009e-01
    z[5,2,0]  R2238     8.7252952158451080e-02
    z[5,2,0]  R2239     1.3760389387607574e-01
    z[5,2,0]  R2240     4.6381881833076477e-01
    z[5,2,0]  R2241     -1.3176780939102173e-01
    z[5,2,0]  R2242     2.5867810845375061e-01
    z[5,2,0]  R2243     9.8589166998863220e-02
    z[5,2,0]  R2244     -1.6886758804321289e-01
    z[5,2,0]  R2245     -2.4934832006692886e-02
    z[5,2,0]  R2246     -2.7765434980392456e-01
    z[5,2,0]  R2247     -7.5552088022232056e-01
    z[5,2,0]  R2248     -8.4898811578750610e-01
    z[5,2,0]  R2249     3.0848824977874756e-01
    z[5,2,0]  R2250     -4.2343363165855408e-01
    z[5,2,0]  R2251     3.1179559230804443e-01
    z[5,2,0]  R2252     3.2969641685485840e-01
    z[5,2,0]  R2253     3.4860834479331970e-01
    z[5,2,0]  R2254     -4.5325347781181335e-01
    z[5,2,0]  R2255     -0.422927588224411
    z[5,2,0]  R2256     -5.0999581813812256e-01
    z[5,2,0]  R2257     -2.6431143283843994e-01
    z[5,2,0]  R2258     4.9214616417884827e-02
    z[5,2,0]  R2259     1.9649212062358856e-01
    z[5,2,0]  R2260     0.422234445810318
    z[5,2,0]  R2261     2.4938111007213593e-01
    z[5,2,0]  R2262     8.8419675827026367e-02
    z[5,2,0]  R2263     4.0276327729225159e-01
    z[5,2,0]  R2264     0.631734311580658
    z[5,2,0]  R2265     5.6486970186233521e-01
    z[5,2,0]  R2266     5.7851821184158325e-01
    z[5,2,0]  R2267     4.3736633658409119e-01
    z[5,2,0]  R2268     2.5934025645256042e-01
    z[5,2,0]  R2269     5.0061064958572388e-01
    z[5,2,0]  R2270     1.2580172717571259e-01
    z[5,2,0]  R2271     2.9341140389442444e-01
    z[5,2,0]  R2272     4.2084982991218567e-01
    z[5,2,0]  R2273     1.8046663701534271e-01
    z[5,2,0]  R2274     3.0953222513198853e-01
    z[5,2,0]  R2275     2.5165063142776489e-01
    z[5,2,0]  R2276     1.2470825761556625e-01
    z[5,2,0]  R2277     5.1459338515996933e-02
    z[5,2,0]  R2278     2.2383508086204529e-01
    z[5,2,0]  R2279     1.8951010704040527e-01
    z[5,2,0]  R2280     -5.1455962657928467e-01
    z[5,2,0]  R2281     -0.131059467792511
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R2110     -1
    z[5,2,1]  R2111     1
    z[5,2,1]  R2122     8.5575813427567482e-03
    z[5,2,1]  R2123     1.4072133600711823e-01
    z[5,2,1]  R2124     -2.6882013678550720e-01
    z[5,2,1]  R2125     -1.2652019038796425e-02
    z[5,2,1]  R2126     3.0407634377479553e-01
    z[5,2,1]  R2127     5.1733434200286865e-01
    z[5,2,1]  R2128     1.8734943866729736e-01
    z[5,2,1]  R2129     1.8706493079662323e-02
    z[5,2,1]  R2130     -6.2197268009185791e-01
    z[5,2,1]  R2131     -6.0173243284225464e-01
    z[5,2,1]  R2132     -0.541064977645874
    z[5,2,1]  R2133     -7.0541268587112427e-01
    z[5,2,1]  R2134     -0.561692476272583
    z[5,2,1]  R2135     -5.9705138206481934e-01
    z[5,2,1]  R2136     8.4480911493301392e-01
    z[5,2,1]  R2137     -2.9515042901039124e-01
    z[5,2,1]  R2138     -5.9425985813140869e-01
    z[5,2,1]  R2139     7.0331460237503052e-01
    z[5,2,1]  R2140     5.4043614864349365e-01
    z[5,2,1]  R2141     -4.5522215962409973e-01
    z[5,2,1]  R2142     -4.3140354752540588e-01
    z[5,2,1]  R2143     3.7732613086700439e-01
    z[5,2,1]  R2144     8.4820365905761719e-01
    z[5,2,1]  R2145     6.9910007715225220e-01
    z[5,2,1]  R2146     6.6943019628524780e-01
    z[5,2,1]  R2147     0.597454845905304
    z[5,2,1]  R2148     6.0251086950302124e-01
    z[5,2,1]  R2149     5.7777369022369385e-01
    z[5,2,1]  R2150     6.0641765594482422e-01
    z[5,2,1]  R2151     0.650162935256958
    z[5,2,1]  R2152     -5.0807815790176392e-01
    z[5,2,1]  R2153     5.8061248064041138e-01
    z[5,2,1]  R2154     -1.7243736982345581e-01
    z[5,2,1]  R2155     -5.6971997022628784e-01
    z[5,2,1]  R2156     -5.5164480209350586e-01
    z[5,2,1]  R2157     -4.0834445506334305e-02
    z[5,2,1]  R2158     1.3132227957248688e-01
    z[5,2,1]  R2159     -5.1098912954330444e-02
    z[5,2,1]  R2160     2.9433953762054443e-01
    z[5,2,1]  R2161     -2.1766616404056549e-01
    z[5,2,1]  R2162     -5.3306269645690918e-01
    z[5,2,1]  R2163     -3.5644170641899109e-01
    z[5,2,1]  R2164     -3.5504448413848877e-01
    z[5,2,1]  R2165     -5.8893674612045288e-01
    z[5,2,1]  R2166     -4.9673485755920410e-01
    z[5,2,1]  R2167     1.1629262566566467e-01
    z[5,2,1]  R2168     -4.4587850570678711e-01
    z[5,2,1]  R2169     -1.3600496947765350e-01
    z[5,2,1]  R2170     -5.9690237045288086e-01
    z[5,2,1]  R2171     7.1867331862449646e-02
    z[5,2,1]  R2172     2.4152347818017006e-02
    z[5,2,1]  R2173     8.4414738416671753e-01
    z[5,2,1]  R2174     0.718745231628418
    z[5,2,1]  R2175     -4.8123809695243835e-01
    z[5,2,1]  R2176     -3.2860276103019714e-01
    z[5,2,1]  R2177     -6.6047638654708862e-01
    z[5,2,1]  R2178     -1.4736685156822205e-01
    z[5,2,1]  R2179     2.6722899079322815e-01
    z[5,2,1]  R2180     -3.5031118988990784e-01
    z[5,2,1]  R2181     -0.500552237033844
    z[5,2,1]  R2182     -3.4786400198936462e-01
    z[5,2,1]  R2183     -5.2081096172332764e-01
    z[5,2,1]  R2184     -5.9718823432922363e-01
    z[5,2,1]  R2185     -5.9593987464904785e-01
    z[5,2,1]  R2186     -3.3485185354948044e-02
    z[5,2,1]  R2187     2.0150625705718994e-01
    z[5,2,1]  R2188     4.2572334408760071e-02
    z[5,2,1]  R2189     -0.365588903427124
    z[5,2,1]  R2190     1.8889233469963074e-02
    z[5,2,1]  R2191     1.7349785566329956e-01
    z[5,2,1]  R2192     -2.1588015556335449e-01
    z[5,2,1]  R2193     1.7628110945224762e-01
    z[5,2,1]  R2194     -2.3755583167076111e-01
    z[5,2,1]  R2195     2.0479236543178558e-01
    z[5,2,1]  R2196     -1.3154593110084534e-01
    z[5,2,1]  R2197     1.9905219972133636e-01
    z[5,2,1]  R2198     -4.1699981689453125e-01
    z[5,2,1]  R2199     -3.0128517746925354e-01
    z[5,2,1]  R2200     -7.6194740831851959e-02
    z[5,2,1]  R2201     0.209869846701622
    z[5,2,1]  R2202     -4.0960386395454407e-01
    z[5,2,1]  R2203     -1.5778750181198120e-01
    z[5,2,1]  R2204     -2.4455009400844574e-01
    z[5,2,1]  R2205     -2.5556573271751404e-01
    z[5,2,1]  R2206     -3.8000097870826721e-01
    z[5,2,1]  R2207     1.2717936933040619e-01
    z[5,2,1]  R2208     1.5552307665348053e-01
    z[5,2,1]  R2209     3.5584294237196445e-03
    z[5,2,1]  R2210     3.0309504270553589e-01
    z[5,2,1]  R2211     0.143227681517601
    z[5,2,1]  R2212     6.7356717586517334e-01
    z[5,2,1]  R2213     8.2480198144912720e-01
    z[5,2,1]  R2214     5.6491744518280029e-01
    z[5,2,1]  R2215     -7.3912781476974487e-01
    z[5,2,1]  R2216     -6.5501809120178223e-01
    z[5,2,1]  R2217     -5.0831407308578491e-01
    z[5,2,1]  R2218     -5.9823578596115112e-01
    z[5,2,1]  R2219     8.8219058513641357e-01
    z[5,2,1]  R2220     8.8769757747650146e-01
    z[5,2,1]  R2221     4.5806637406349182e-01
    z[5,2,1]  R2222     1.8596200644969940e-01
    z[5,2,1]  R2223     7.1757632493972778e-01
    z[5,2,1]  R2224     -3.8152185082435608e-01
    z[5,2,1]  R2225     1.4021593332290649e-01
    z[5,2,1]  R2226     -3.7752085924148560e-01
    z[5,2,1]  R2227     0.69268798828125
    z[5,2,1]  R2228     -6.1385488510131836e-01
    z[5,2,1]  R2229     6.0728186368942261e-01
    z[5,2,1]  R2230     -4.8250687122344971e-01
    z[5,2,1]  R2231     -7.0133811235427856e-01
    z[5,2,1]  R2232     -5.4359430074691772e-01
    z[5,2,1]  R2233     -4.9089613556861877e-01
    z[5,2,1]  R2234     2.6800769567489624e-01
    z[5,2,1]  R2235     -4.0371596813201904e-01
    z[5,2,1]  R2236     0.409095823764801
    z[5,2,1]  R2237     6.2194281816482544e-01
    z[5,2,1]  R2238     -3.8345479965209961e-01
    z[5,2,1]  R2239     9.3600398302078247e-01
    z[5,2,1]  R2240     -5.5373638868331909e-01
    z[5,2,1]  R2241     9.1260397434234619e-01
    z[5,2,1]  R2242     1.5924791991710663e-01
    z[5,2,1]  R2243     3.9333915710449219e-01
    z[5,2,1]  R2244     3.0031278729438782e-01
    z[5,2,1]  R2245     6.2737494707107544e-01
    z[5,2,1]  R2246     2.1992325782775879e-01
    z[5,2,1]  R2247     -4.1509312391281128e-01
    z[5,2,1]  R2248     -4.1287493705749512e-01
    z[5,2,1]  R2249     8.0462110042572021e-01
    z[5,2,1]  R2250     -3.6295115947723389e-01
    z[5,2,1]  R2251     -6.9650501012802124e-01
    z[5,2,1]  R2252     -6.7203216254711151e-02
    z[5,2,1]  R2253     8.0494272708892822e-01
    z[5,2,1]  R2254     -3.9140564203262329e-01
    z[5,2,1]  R2255     4.6580326557159424e-01
    z[5,2,1]  R2256     3.8096180558204651e-01
    z[5,2,1]  R2257     1.5873104333877563e-01
    z[5,2,1]  R2258     1.4601269364356995e-01
    z[5,2,1]  R2259     2.3214745521545410e-01
    z[5,2,1]  R2260     -5.8443200588226318e-01
    z[5,2,1]  R2261     -4.8416009545326233e-01
    z[5,2,1]  R2262     -4.8915907740592957e-01
    z[5,2,1]  R2263     -5.4353523254394531e-01
    z[5,2,1]  R2264     3.3106356859207153e-01
    z[5,2,1]  R2265     0.0721365436911583
    z[5,2,1]  R2266     2.4072538316249847e-01
    z[5,2,1]  R2267     -4.7887992858886719e-01
    z[5,2,1]  R2268     -3.7768241763114929e-01
    z[5,2,1]  R2269     -3.6895516514778137e-01
    z[5,2,1]  R2270     -3.3499330282211304e-01
    z[5,2,1]  R2271     -2.3496727645397186e-01
    z[5,2,1]  R2272     -0.631965160369873
    z[5,2,1]  R2273     -5.7080310583114624e-01
    z[5,2,1]  R2274     -4.0810176730155945e-01
    z[5,2,1]  R2275     -2.2940079867839813e-01
    z[5,2,1]  R2276     -2.9745447635650635e-01
    z[5,2,1]  R2277     -1.1915975809097290e-01
    z[5,2,1]  R2278     6.0840494930744171e-02
    z[5,2,1]  R2279     -2.8783810138702393e-01
    z[5,2,1]  R2280     6.6480404138565063e-01
    z[5,2,1]  R2281     5.4802858829498291e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R2112     -1
    z[5,2,2]  R2113     1
    z[5,2,2]  R2122     -2.5082439184188843e-01
    z[5,2,2]  R2123     -4.9486222863197327e-01
    z[5,2,2]  R2124     -8.3715015649795532e-01
    z[5,2,2]  R2125     -6.9883072376251221e-01
    z[5,2,2]  R2126     -8.6587077379226685e-01
    z[5,2,2]  R2127     -4.6348148584365845e-01
    z[5,2,2]  R2128     -0.835545003414154
    z[5,2,2]  R2129     -3.9633882045745850e-01
    z[5,2,2]  R2130     1.9898726046085358e-01
    z[5,2,2]  R2131     3.1680113077163696e-01
    z[5,2,2]  R2132     4.7050195932388306e-01
    z[5,2,2]  R2133     5.2155035734176636e-01
    z[5,2,2]  R2134     4.4924122095108032e-01
    z[5,2,2]  R2135     5.2330291271209717e-01
    z[5,2,2]  R2136     2.3753516376018524e-01
    z[5,2,2]  R2137     0.685438334941864
    z[5,2,2]  R2138     4.8933586478233337e-01
    z[5,2,2]  R2139     3.0118945240974426e-01
    z[5,2,2]  R2140     3.3472895622253418e-01
    z[5,2,2]  R2141     0.550088107585907
    z[5,2,2]  R2142     -1.4015612006187439e-01
    z[5,2,2]  R2143     3.8528403639793396e-01
    z[5,2,2]  R2144     3.6292123794555664e-01
    z[5,2,2]  R2145     1.1737194657325745e-01
    z[5,2,2]  R2146     1.4842732250690460e-01
    z[5,2,2]  R2147     2.1074037998914719e-02
    z[5,2,2]  R2148     1.3993789255619049e-01
    z[5,2,2]  R2149     1.3967829942703247e-01
    z[5,2,2]  R2150     5.2091282606124878e-01
    z[5,2,2]  R2151     2.3172754049301147e-01
    z[5,2,2]  R2152     0.0881069228053093
    z[5,2,2]  R2153     3.4890773892402649e-01
    z[5,2,2]  R2154     9.3202881515026093e-02
    z[5,2,2]  R2155     2.4517005681991577e-01
    z[5,2,2]  R2156     3.7510260939598083e-01
    z[5,2,2]  R2157     -1.1677806824445724e-01
    z[5,2,2]  R2158     1.2375617772340775e-01
    z[5,2,2]  R2159     1.3580541312694550e-01
    z[5,2,2]  R2160     -4.8568150959908962e-03
    z[5,2,2]  R2161     4.2193382978439331e-01
    z[5,2,2]  R2162     5.0784224271774292e-01
    z[5,2,2]  R2163     6.4672106504440308e-01
    z[5,2,2]  R2164     4.5124414563179016e-01
    z[5,2,2]  R2165     7.5461500883102417e-01
    z[5,2,2]  R2166     4.1927462816238403e-01
    z[5,2,2]  R2167     -1.3850663602352142e-01
    z[5,2,2]  R2168     6.0157597064971924e-01
    z[5,2,2]  R2169     7.0908397436141968e-01
    z[5,2,2]  R2170     2.0411163568496704e-01
    z[5,2,2]  R2171     0.0621710866689682
    z[5,2,2]  R2172     1.0683589428663254e-01
    z[5,2,2]  R2173     2.4507471919059753e-01
    z[5,2,2]  R2174     -0.00966144260019064
    z[5,2,2]  R2175     5.8281403779983521e-01
    z[5,2,2]  R2176     5.8617675304412842e-01
    z[5,2,2]  R2177     4.8749116063117981e-01
    z[5,2,2]  R2178     8.3031928539276123e-01
    z[5,2,2]  R2179     6.2518283724784851e-02
    z[5,2,2]  R2180     -2.0371995866298676e-01
    z[5,2,2]  R2181     7.6282203197479248e-01
    z[5,2,2]  R2182     9.7577020525932312e-02
    z[5,2,2]  R2183     6.3724607229232788e-01
    z[5,2,2]  R2184     0.546921968460083
    z[5,2,2]  R2185     7.2423154115676880e-01
    z[5,2,2]  R2186     -2.3010337352752686e-01
    z[5,2,2]  R2187     2.2679027169942856e-02
    z[5,2,2]  R2188     1.8637599050998688e-01
    z[5,2,2]  R2189     8.1958460807800293e-01
    z[5,2,2]  R2190     3.5175395011901855e-01
    z[5,2,2]  R2191     0.812131404876709
    z[5,2,2]  R2192     -3.9520934224128723e-01
    z[5,2,2]  R2193     -6.5507078170776367e-01
    z[5,2,2]  R2194     -6.7343634366989136e-01
    z[5,2,2]  R2195     -7.1022748947143555e-01
    z[5,2,2]  R2196     -3.5012489557266235e-01
    z[5,2,2]  R2197     -2.4349214136600494e-01
    z[5,2,2]  R2198     -7.4231493473052979e-01
    z[5,2,2]  R2199     -5.1035708189010620e-01
    z[5,2,2]  R2200     -4.5079621672630310e-01
    z[5,2,2]  R2201     -3.3830073475837708e-01
    z[5,2,2]  R2202     2.1875385940074921e-01
    z[5,2,2]  R2203     3.3716621994972229e-01
    z[5,2,2]  R2204     4.4088739156723022e-01
    z[5,2,2]  R2205     2.2630555927753448e-01
    z[5,2,2]  R2206     5.4999870061874390e-01
    z[5,2,2]  R2207     8.7424147129058838e-01
    z[5,2,2]  R2208     9.4849610328674316e-01
    z[5,2,2]  R2209     9.5662963390350342e-01
    z[5,2,2]  R2210     8.9228767156600952e-01
    z[5,2,2]  R2211     8.1086415052413940e-01
    z[5,2,2]  R2212     -4.1185855865478516e-01
    z[5,2,2]  R2213     -1.9162485376000404e-02
    z[5,2,2]  R2214     2.8008872270584106e-01
    z[5,2,2]  R2215     4.0162590146064758e-01
    z[5,2,2]  R2216     4.4733661413192749e-01
    z[5,2,2]  R2217     0.568046510219574
    z[5,2,2]  R2218     2.8434932231903076e-01
    z[5,2,2]  R2219     3.1677380204200745e-01
    z[5,2,2]  R2220     1.1546524614095688e-01
    z[5,2,2]  R2221     -1.6543051600456238e-01
    z[5,2,2]  R2222     -0.0796266719698906
    z[5,2,2]  R2223     -2.9266723990440369e-01
    z[5,2,2]  R2224     -2.8603881597518921e-01
    z[5,2,2]  R2225     -3.5321470350027084e-02
    z[5,2,2]  R2226     1.1452263593673706e-01
    z[5,2,2]  R2227     1.4027774333953857e-02
    z[5,2,2]  R2228     0.628491997718811
    z[5,2,2]  R2229     3.4253127872943878e-02
    z[5,2,2]  R2230     6.6206520795822144e-01
    z[5,2,2]  R2231     6.2908381223678589e-01
    z[5,2,2]  R2232     2.9503282904624939e-01
    z[5,2,2]  R2233     -1.2889644131064415e-02
    z[5,2,2]  R2234     -3.6238917708396912e-01
    z[5,2,2]  R2235     -1.2910751998424530e-01
    z[5,2,2]  R2236     2.9581716284155846e-02
    z[5,2,2]  R2237     -5.8643147349357605e-02
    z[5,2,2]  R2238     7.1621578931808472e-01
    z[5,2,2]  R2239     1.7335261404514313e-01
    z[5,2,2]  R2240     0.579522430896759
    z[5,2,2]  R2241     -1.2586662545800209e-02
    z[5,2,2]  R2242     -0.60338294506073
    z[5,2,2]  R2243     -2.8439977765083313e-01
    z[5,2,2]  R2244     -5.1153934001922607e-01
    z[5,2,2]  R2245     -1.1169648915529251e-01
    z[5,2,2]  R2246     -5.5183249711990356e-01
    z[5,2,2]  R2247     -7.1597069501876831e-02
    z[5,2,2]  R2248     7.9120278358459473e-02
    z[5,2,2]  R2249     -3.7630371749401093e-02
    z[5,2,2]  R2250     1.3049761950969696e-01
    z[5,2,2]  R2251     6.2702363729476929e-01
    z[5,2,2]  R2252     -7.2930544614791870e-01
    z[5,2,2]  R2253     -3.3465901017189026e-01
    z[5,2,2]  R2254     3.6644306033849716e-02
    z[5,2,2]  R2255     7.0993721485137939e-01
    z[5,2,2]  R2256     0.539761483669281
    z[5,2,2]  R2257     0.705171525478363
    z[5,2,2]  R2258     9.0713568031787872e-02
    z[5,2,2]  R2259     -1.1441487073898315e-01
    z[5,2,2]  R2260     3.7345755100250244e-01
    z[5,2,2]  R2261     4.0972551703453064e-01
    z[5,2,2]  R2262     7.2683101892471313e-01
    z[5,2,2]  R2263     6.2340795993804932e-01
    z[5,2,2]  R2264     1.4043259620666504e-01
    z[5,2,2]  R2265     -1.3547022640705109e-01
    z[5,2,2]  R2266     1.2957191467285156e-01
    z[5,2,2]  R2267     4.8817488551139832e-01
    z[5,2,2]  R2268     5.4580259323120117e-01
    z[5,2,2]  R2269     4.9789234995841980e-01
    z[5,2,2]  R2270     -2.2322230041027069e-01
    z[5,2,2]  R2271     -2.6471281051635742e-01
    z[5,2,2]  R2272     6.1506575345993042e-01
    z[5,2,2]  R2273     4.2768985033035278e-01
    z[5,2,2]  R2274     5.0138247013092041e-01
    z[5,2,2]  R2275     -1.3325053453445435e-01
    z[5,2,2]  R2276     -8.8966287672519684e-02
    z[5,2,2]  R2277     1.1987017840147018e-01
    z[5,2,2]  R2278     -2.1370720863342285e-01
    z[5,2,2]  R2279     -1.6838872432708740e-01
    z[5,2,2]  R2280     2.0024140179157257e-01
    z[5,2,2]  R2281     4.3591436743736267e-01
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R2114     -1
    z[5,2,3]  R2115     1
    z[5,2,3]  R2122     5.9576869010925293e-01
    z[5,2,3]  R2123     3.9372414350509644e-01
    z[5,2,3]  R2124     1.3222867250442505e-01
    z[5,2,3]  R2125     6.4013522863388062e-01
    z[5,2,3]  R2126     1.5869811177253723e-01
    z[5,2,3]  R2127     6.4389592409133911e-01
    z[5,2,3]  R2128     2.3036353290081024e-01
    z[5,2,3]  R2129     4.4051659107208252e-01
    z[5,2,3]  R2130     1.5037453733384609e-02
    z[5,2,3]  R2131     7.1662895381450653e-02
    z[5,2,3]  R2132     -1.1776566505432129e-01
    z[5,2,3]  R2133     -1.3404813408851624e-01
    z[5,2,3]  R2134     -1.9995562732219696e-01
    z[5,2,3]  R2135     -4.2782168835401535e-02
    z[5,2,3]  R2136     -3.0475902557373047e-01
    z[5,2,3]  R2137     -4.1686594486236572e-01
    z[5,2,3]  R2138     -3.8454201817512512e-01
    z[5,2,3]  R2139     -5.1275640726089478e-01
    z[5,2,3]  R2140     -4.1546443104743958e-01
    z[5,2,3]  R2141     -3.2571017742156982e-01
    z[5,2,3]  R2142     -1.3579273223876953e-01
    z[5,2,3]  R2143     1.1743741482496262e-01
    z[5,2,3]  R2144     -9.0006791055202484e-02
    z[5,2,3]  R2145     -3.6825048923492432e-01
    z[5,2,3]  R2146     -5.0619250535964966e-01
    z[5,2,3]  R2147     -5.6021952629089355e-01
    z[5,2,3]  R2148     -3.8618949055671692e-01
    z[5,2,3]  R2149     -3.2842054963111877e-01
    z[5,2,3]  R2150     -3.1660124659538269e-01
    z[5,2,3]  R2151     -3.8760277628898621e-01
    z[5,2,3]  R2152     -2.8610104322433472e-01
    z[5,2,3]  R2153     3.0981364846229553e-01
    z[5,2,3]  R2154     4.0037342905998230e-01
    z[5,2,3]  R2155     -5.9528566896915436e-02
    z[5,2,3]  R2156     -3.6331480741500854e-01
    z[5,2,3]  R2157     -8.4577780961990356e-01
    z[5,2,3]  R2158     -7.9938125610351562e-01
    z[5,2,3]  R2159     -0.662041962146759
    z[5,2,3]  R2160     -0.797913670539856
    z[5,2,3]  R2161     -4.7221881151199341e-01
    z[5,2,3]  R2162     -6.7318767309188843e-02
    z[5,2,3]  R2163     -1.2998647987842560e-01
    z[5,2,3]  R2164     -4.8076048493385315e-01
    z[5,2,3]  R2165     9.2176847159862518e-02
    z[5,2,3]  R2166     -5.8152031898498535e-01
    z[5,2,3]  R2167     -8.3289182186126709e-01
    z[5,2,3]  R2168     -5.7208532094955444e-01
    z[5,2,3]  R2169     -3.0186501145362854e-01
    z[5,2,3]  R2170     -5.2364188432693481e-01
    z[5,2,3]  R2171     -8.4814244508743286e-01
    z[5,2,3]  R2172     4.1239511966705322e-01
    z[5,2,3]  R2173     -4.8379480838775635e-02
    z[5,2,3]  R2174     -4.6403801441192627e-01
    z[5,2,3]  R2175     -4.0619453787803650e-01
    z[5,2,3]  R2176     -4.2855963110923767e-01
    z[5,2,3]  R2177     5.4446242749691010e-02
    z[5,2,3]  R2178     -3.3980420231819153e-01
    z[5,2,3]  R2179     -0.851863443851471
    z[5,2,3]  R2180     -8.3771157264709473e-01
    z[5,2,3]  R2181     -9.4819359481334686e-02
    z[5,2,3]  R2182     -0.722500741481781
    z[5,2,3]  R2183     -2.0860888063907623e-01
    z[5,2,3]  R2184     -2.0605309307575226e-01
    z[5,2,3]  R2185     2.8400283306837082e-02
    z[5,2,3]  R2186     -0.847332775592804
    z[5,2,3]  R2187     -8.6517196893692017e-01
    z[5,2,3]  R2188     -6.3254356384277344e-01
    z[5,2,3]  R2189     -2.6408711075782776e-01
    z[5,2,3]  R2190     -7.7237951755523682e-01
    z[5,2,3]  R2191     3.1130319833755493e-01
    z[5,2,3]  R2192     5.8361768722534180e-01
    z[5,2,3]  R2193     4.6935808658599854e-01
    z[5,2,3]  R2194     4.0347889065742493e-01
    z[5,2,3]  R2195     5.5925935506820679e-01
    z[5,2,3]  R2196     4.1561439633369446e-01
    z[5,2,3]  R2197     8.5939311981201172e-01
    z[5,2,3]  R2198     0.275499552488327
    z[5,2,3]  R2199     7.4122303724288940e-01
    z[5,2,3]  R2200     5.0755894184112549e-01
    z[5,2,3]  R2201     1.4604271948337555e-01
    z[5,2,3]  R2202     -4.8070603609085083e-01
    z[5,2,3]  R2203     -0.170390784740448
    z[5,2,3]  R2204     3.8864649832248688e-02
    z[5,2,3]  R2205     -0.148195281624794
    z[5,2,3]  R2206     -0.068141870200634
    z[5,2,3]  R2207     0.0461047999560833
    z[5,2,3]  R2208     7.8676626086235046e-02
    z[5,2,3]  R2209     1.0513123869895935e-01
    z[5,2,3]  R2210     0.0667092427611351
    z[5,2,3]  R2211     2.0522156357765198e-01
    z[5,2,3]  R2212     -2.3449407517910004e-01
    z[5,2,3]  R2213     -1.1086897552013397e-01
    z[5,2,3]  R2214     1.3058193027973175e-01
    z[5,2,3]  R2215     -1.5165399014949799e-01
    z[5,2,3]  R2216     -3.3748653531074524e-01
    z[5,2,3]  R2217     -3.0212721228599548e-01
    z[5,2,3]  R2218     -1.4454054832458496e-01
    z[5,2,3]  R2219     -0.0949816182255745
    z[5,2,3]  R2220     -0.00844635721296072
    z[5,2,3]  R2221     -0.072464220225811
    z[5,2,3]  R2222     2.6678740978240967e-01
    z[5,2,3]  R2223     1.5070120804011822e-02
    z[5,2,3]  R2224     -5.3139245510101318e-01
    z[5,2,3]  R2225     -2.8727075085043907e-02
    z[5,2,3]  R2226     -9.5711521804332733e-02
    z[5,2,3]  R2227     -7.4008852243423462e-02
    z[5,2,3]  R2228     9.4357088208198547e-02
    z[5,2,3]  R2229     -5.3052004426717758e-02
    z[5,2,3]  R2230     -2.3163458704948425e-01
    z[5,2,3]  R2231     2.2300805151462555e-01
    z[5,2,3]  R2232     1.6113524138927460e-01
    z[5,2,3]  R2233     -2.3640665411949158e-01
    z[5,2,3]  R2234     -3.4317496418952942e-01
    z[5,2,3]  R2235     -3.7083217501640320e-01
    z[5,2,3]  R2236     -9.3176349997520447e-02
    z[5,2,3]  R2237     -7.2438023984432220e-02
    z[5,2,3]  R2238     -3.0139824748039246e-01
    z[5,2,3]  R2239     -1.7185065150260925e-01
    z[5,2,3]  R2240     -1.4382113516330719e-01
    z[5,2,3]  R2241     -1.5414026379585266e-01
    z[5,2,3]  R2242     2.1110512316226959e-01
    z[5,2,3]  R2243     -3.6252435296773911e-02
    z[5,2,3]  R2244     -0.321154922246933
    z[5,2,3]  R2245     1.9282083213329315e-01
    z[5,2,3]  R2246     -1.6128194332122803e-01
    z[5,2,3]  R2247     -1.8521138699725270e-03
    z[5,2,3]  R2248     -1.4850957691669464e-01
    z[5,2,3]  R2249     2.2216208279132843e-01
    z[5,2,3]  R2250     -1.8443416059017181e-01
    z[5,2,3]  R2251     -5.6029386818408966e-02
    z[5,2,3]  R2252     1.2959238886833191e-01
    z[5,2,3]  R2253     4.5644771307706833e-02
    z[5,2,3]  R2254     -1.8064694106578827e-01
    z[5,2,3]  R2255     8.3385735750198364e-02
    z[5,2,3]  R2256     2.6409700512886047e-01
    z[5,2,3]  R2257     3.6392763257026672e-01
    z[5,2,3]  R2258     -0.806171178817749
    z[5,2,3]  R2259     -8.5051637887954712e-01
    z[5,2,3]  R2260     6.0818102210760117e-02
    z[5,2,3]  R2261     -1.5635755658149719e-01
    z[5,2,3]  R2262     -5.2543841302394867e-02
    z[5,2,3]  R2263     -2.5762656331062317e-01
    z[5,2,3]  R2264     5.9513457119464874e-02
    z[5,2,3]  R2265     1.8277665600180626e-02
    z[5,2,3]  R2266     1.0919960588216782e-01
    z[5,2,3]  R2267     -4.5451596379280090e-01
    z[5,2,3]  R2268     -4.6350872516632080e-01
    z[5,2,3]  R2269     3.5328158736228943e-01
    z[5,2,3]  R2270     -4.3283212184906006e-01
    z[5,2,3]  R2271     -5.5757224559783936e-01
    z[5,2,3]  R2272     -3.1490195542573929e-02
    z[5,2,3]  R2273     -9.0821079909801483e-02
    z[5,2,3]  R2274     -4.4099974632263184e-01
    z[5,2,3]  R2275     -8.5201394557952881e-01
    z[5,2,3]  R2276     -7.7582234144210815e-01
    z[5,2,3]  R2277     -0.92115718126297
    z[5,2,3]  R2278     -9.0703666210174561e-01
    z[5,2,3]  R2279     -8.0508148670196533e-01
    z[5,2,3]  R2280     1.9683811068534851e-01
    z[5,2,3]  R2281     -1.1682634800672531e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R2116     -1
    z[5,2,4]  R2117     1
    z[5,2,4]  R2122     -1.4564444124698639e-01
    z[5,2,4]  R2123     3.8416441529989243e-02
    z[5,2,4]  R2124     1.7567806644365191e-03
    z[5,2,4]  R2125     2.4478648602962494e-01
    z[5,2,4]  R2126     9.6992768347263336e-02
    z[5,2,4]  R2127     2.1350033581256866e-01
    z[5,2,4]  R2128     -2.7428719401359558e-01
    z[5,2,4]  R2129     6.8304139375686646e-01
    z[5,2,4]  R2130     1.2113102525472641e-01
    z[5,2,4]  R2131     2.5525709614157677e-02
    z[5,2,4]  R2132     -2.7946668863296509e-01
    z[5,2,4]  R2133     2.1172559261322021e-01
    z[5,2,4]  R2134     -1.7210589349269867e-01
    z[5,2,4]  R2135     2.4047857522964478e-01
    z[5,2,4]  R2136     1.0388135910034180e-02
    z[5,2,4]  R2137     2.1524070203304291e-01
    z[5,2,4]  R2138     -3.8811179995536804e-01
    z[5,2,4]  R2139     1.0021328926086426e-01
    z[5,2,4]  R2140     -4.2036247253417969e-01
    z[5,2,4]  R2141     -2.8724148869514465e-01
    z[5,2,4]  R2142     -9.4732575118541718e-02
    z[5,2,4]  R2143     -4.5010432600975037e-01
    z[5,2,4]  R2144     -2.0135407149791718e-01
    z[5,2,4]  R2145     -2.9905600473284721e-02
    z[5,2,4]  R2146     0.159097358584404
    z[5,2,4]  R2147     3.3481064438819885e-01
    z[5,2,4]  R2148     -2.0056806504726410e-01
    z[5,2,4]  R2149     8.6779326200485229e-02
    z[5,2,4]  R2150     1.1984530836343765e-02
    z[5,2,4]  R2151     -0.496004581451416
    z[5,2,4]  R2152     -0.531998336315155
    z[5,2,4]  R2153     -6.1312294006347656e-01
    z[5,2,4]  R2154     -5.4920804500579834e-01
    z[5,2,4]  R2155     1.8354912102222443e-01
    z[5,2,4]  R2156     -0.276263952255249
    z[5,2,4]  R2157     -4.0148639678955078e-01
    z[5,2,4]  R2158     -4.6598100662231445e-01
    z[5,2,4]  R2159     -4.0774139761924744e-01
    z[5,2,4]  R2160     -4.0382185578346252e-01
    z[5,2,4]  R2161     5.0118589401245117e-01
    z[5,2,4]  R2162     2.6180425286293030e-01
    z[5,2,4]  R2163     -0.282550573348999
    z[5,2,4]  R2164     -6.2645196914672852e-02
    z[5,2,4]  R2165     -1.2329094856977463e-01
    z[5,2,4]  R2166     -0.0234454907476902
    z[5,2,4]  R2167     -1.5201459825038910e-01
    z[5,2,4]  R2168     -1.1735180765390396e-01
    z[5,2,4]  R2169     5.4263092577457428e-02
    z[5,2,4]  R2170     1.4913311600685120e-01
    z[5,2,4]  R2171     -2.5151485204696655e-01
    z[5,2,4]  R2172     -5.0076740980148315e-01
    z[5,2,4]  R2173     3.4647189080715179e-02
    z[5,2,4]  R2174     1.5218664705753326e-01
    z[5,2,4]  R2175     -0.0744100883603096
    z[5,2,4]  R2176     -1.8353520333766937e-01
    z[5,2,4]  R2177     1.3839547336101532e-01
    z[5,2,4]  R2178     4.5360937714576721e-02
    z[5,2,4]  R2179     -2.7728980779647827e-01
    z[5,2,4]  R2180     -8.2025587558746338e-02
    z[5,2,4]  R2181     1.3995287939906120e-02
    z[5,2,4]  R2182     1.8421135842800140e-01
    z[5,2,4]  R2183     -1.1290358752012253e-01
    z[5,2,4]  R2184     1.5742288529872894e-01
    z[5,2,4]  R2185     -1.0554249398410320e-02
    z[5,2,4]  R2186     -1.9067689776420593e-01
    z[5,2,4]  R2187     -3.3969292044639587e-01
    z[5,2,4]  R2188     -5.9137541055679321e-01
    z[5,2,4]  R2189     -1.1788047850131989e-01
    z[5,2,4]  R2190     -2.7381590008735657e-01
    z[5,2,4]  R2191     3.5458293557167053e-01
    z[5,2,4]  R2192     -1.3866421580314636e-01
    z[5,2,4]  R2193     0.4262675344944
    z[5,2,4]  R2194     1.2889516353607178e-01
    z[5,2,4]  R2195     -2.1842949092388153e-02
    z[5,2,4]  R2196     -3.7414006888866425e-02
    z[5,2,4]  R2197     -9.2173544690012932e-03
    z[5,2,4]  R2198     9.3282364308834076e-02
    z[5,2,4]  R2199     1.4299346506595612e-01
    z[5,2,4]  R2200     1.1714073270559311e-01
    z[5,2,4]  R2201     3.7614884972572327e-01
    z[5,2,4]  R2202     0.0735994279384613
    z[5,2,4]  R2203     6.7542046308517456e-02
    z[5,2,4]  R2204     2.3088328540325165e-01
    z[5,2,4]  R2205     -9.5550626516342163e-02
    z[5,2,4]  R2206     -1.7954094707965851e-01
    z[5,2,4]  R2207     3.1480357050895691e-01
    z[5,2,4]  R2208     1.8796192109584808e-01
    z[5,2,4]  R2209     8.3698770031332970e-03
    z[5,2,4]  R2210     0.0705980509519577
    z[5,2,4]  R2211     2.6583236455917358e-01
    z[5,2,4]  R2212     -3.7515938282012939e-01
    z[5,2,4]  R2213     -4.4282034039497375e-01
    z[5,2,4]  R2214     -1.6256643831729889e-01
    z[5,2,4]  R2215     1.1624976247549057e-01
    z[5,2,4]  R2216     2.3277167975902557e-01
    z[5,2,4]  R2217     1.8302576243877411e-01
    z[5,2,4]  R2218     2.3575511574745178e-01
    z[5,2,4]  R2219     -9.6358023583889008e-02
    z[5,2,4]  R2220     1.0487534105777740e-01
    z[5,2,4]  R2221     -2.3561987280845642e-01
    z[5,2,4]  R2222     -9.4050276279449463e-01
    z[5,2,4]  R2223     -5.3487664461135864e-01
    z[5,2,4]  R2224     -5.0266232341527939e-02
    z[5,2,4]  R2225     -3.7714448571205139e-01
    z[5,2,4]  R2226     7.5331604480743408e-01
    z[5,2,4]  R2227     4.3590095639228821e-01
    z[5,2,4]  R2228     5.7433921843767166e-02
    z[5,2,4]  R2229     -0.0620078481733799
    z[5,2,4]  R2230     4.7839531302452087e-01
    z[5,2,4]  R2231     1.7153675854206085e-01
    z[5,2,4]  R2232     -2.6997578144073486e-01
    z[5,2,4]  R2233     1.3102343678474426e-01
    z[5,2,4]  R2234     -6.5804773569107056e-01
    z[5,2,4]  R2235     -2.1013745665550232e-01
    z[5,2,4]  R2236     -0.456379771232605
    z[5,2,4]  R2237     2.5651317834854126e-01
    z[5,2,4]  R2238     4.8555487394332886e-01
    z[5,2,4]  R2239     0.181008979678154
    z[5,2,4]  R2240     -2.8443282842636108e-01
    z[5,2,4]  R2241     -6.0795680619776249e-03
    z[5,2,4]  R2242     -5.2893245220184326e-01
    z[5,2,4]  R2243     -7.8231376409530640e-01
    z[5,2,4]  R2244     -5.5640321969985962e-01
    z[5,2,4]  R2245     -6.1660176515579224e-01
    z[5,2,4]  R2246     -3.5854494571685791e-01
    z[5,2,4]  R2247     3.8253688812255859e-01
    z[5,2,4]  R2248     -1.3372954726219177e-01
    z[5,2,4]  R2249     4.8215255141258240e-02
    z[5,2,4]  R2250     -7.5708419084548950e-01
    z[5,2,4]  R2251     -8.2201175391674042e-02
    z[5,2,4]  R2252     -1.6545540094375610e-01
    z[5,2,4]  R2253     -1.9630345702171326e-01
    z[5,2,4]  R2254     -0.774272620677948
    z[5,2,4]  R2255     2.1603046357631683e-01
    z[5,2,4]  R2256     -3.5607546567916870e-01
    z[5,2,4]  R2257     -2.8958949446678162e-01
    z[5,2,4]  R2258     -3.5417255759239197e-01
    z[5,2,4]  R2259     -2.1766684949398041e-01
    z[5,2,4]  R2260     -2.9416689649224281e-02
    z[5,2,4]  R2261     9.9350109696388245e-02
    z[5,2,4]  R2262     3.9517775177955627e-01
    z[5,2,4]  R2263     0.206630676984787
    z[5,2,4]  R2264     2.1284732222557068e-01
    z[5,2,4]  R2265     3.7563538551330566e-01
    z[5,2,4]  R2266     6.9434428215026855e-01
    z[5,2,4]  R2267     -4.8193059861660004e-02
    z[5,2,4]  R2268     2.4971835315227509e-01
    z[5,2,4]  R2269     0.300087571144104
    z[5,2,4]  R2270     -4.5681995153427124e-01
    z[5,2,4]  R2271     -4.3525260686874390e-01
    z[5,2,4]  R2272     1.1224637180566788e-01
    z[5,2,4]  R2273     4.8872217535972595e-01
    z[5,2,4]  R2274     2.8599053621292114e-01
    z[5,2,4]  R2275     -1.3222269713878632e-01
    z[5,2,4]  R2276     -4.7229605913162231e-01
    z[5,2,4]  R2277     -1.6047553718090057e-01
    z[5,2,4]  R2278     7.0403993129730225e-02
    z[5,2,4]  R2279     4.3914973735809326e-01
    z[5,2,4]  R2280     3.7198930978775024e-01
    z[5,2,4]  R2281     5.9806394577026367e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R2118     -1
    z[5,2,5]  R2119     1
    z[5,2,5]  R2122     -6.1933767795562744e-01
    z[5,2,5]  R2123     -6.4784586429595947e-01
    z[5,2,5]  R2124     -3.0371937155723572e-01
    z[5,2,5]  R2125     -5.0053298473358154e-02
    z[5,2,5]  R2126     -3.3766743727028370e-03
    z[5,2,5]  R2127     0.0362824983894825
    z[5,2,5]  R2128     1.8293833732604980e-01
    z[5,2,5]  R2129     -1.8776687979698181e-01
    z[5,2,5]  R2130     -5.7682663202285767e-02
    z[5,2,5]  R2131     -0.0266642477363348
    z[5,2,5]  R2132     3.4906172752380371e-01
    z[5,2,5]  R2133     1.1849937587976456e-01
    z[5,2,5]  R2134     5.4500085115432739e-01
    z[5,2,5]  R2135     2.6853027939796448e-01
    z[5,2,5]  R2136     -3.2048285007476807e-01
    z[5,2,5]  R2137     3.7137782573699951e-01
    z[5,2,5]  R2138     1.8925306200981140e-01
    z[5,2,5]  R2139     2.7644780930131674e-03
    z[5,2,5]  R2140     1.9587117433547974e-01
    z[5,2,5]  R2141     2.6655626296997070e-01
    z[5,2,5]  R2142     6.3775390386581421e-01
    z[5,2,5]  R2143     2.7203616499900818e-01
    z[5,2,5]  R2144     -2.9853606224060059e-01
    z[5,2,5]  R2145     2.7603876590728760e-01
    z[5,2,5]  R2146     -5.6742765009403229e-02
    z[5,2,5]  R2147     1.1412044614553452e-01
    z[5,2,5]  R2148     -5.1465284079313278e-02
    z[5,2,5]  R2149     -1.3932244479656219e-01
    z[5,2,5]  R2150     -2.9125756118446589e-03
    z[5,2,5]  R2151     -2.9701529070734978e-02
    z[5,2,5]  R2152     -3.7494511343538761e-03
    z[5,2,5]  R2153     3.4458752721548080e-02
    z[5,2,5]  R2154     3.0400335788726807e-01
    z[5,2,5]  R2155     5.9104061126708984e-01
    z[5,2,5]  R2156     -0.0534505657851696
    z[5,2,5]  R2157     1.9277544319629669e-01
    z[5,2,5]  R2158     2.4191319942474365e-01
    z[5,2,5]  R2159     5.5073505640029907e-01
    z[5,2,5]  R2160     3.1129565834999084e-01
    z[5,2,5]  R2161     3.4153786301612854e-01
    z[5,2,5]  R2162     3.9113840460777283e-01
    z[5,2,5]  R2163     4.2109638452529907e-01
    z[5,2,5]  R2164     4.3957060575485229e-01
    z[5,2,5]  R2165     1.9891719520092010e-01
    z[5,2,5]  R2166     -5.1018454134464264e-02
    z[5,2,5]  R2167     4.7241061925888062e-01
    z[5,2,5]  R2168     -1.1062230169773102e-01
    z[5,2,5]  R2169     2.1643431484699249e-01
    z[5,2,5]  R2170     4.2171150445938110e-01
    z[5,2,5]  R2171     3.6347669363021851e-01
    z[5,2,5]  R2172     2.6701900362968445e-01
    z[5,2,5]  R2173     -2.6293733716011047e-01
    z[5,2,5]  R2174     -1.1496489495038986e-01
    z[5,2,5]  R2175     0.0418475866317749
    z[5,2,5]  R2176     3.5667872428894043e-01
    z[5,2,5]  R2177     -1.0689385980367661e-01
    z[5,2,5]  R2178     2.3131118714809418e-01
    z[5,2,5]  R2179     2.0413130521774292e-01
    z[5,2,5]  R2180     3.2589516043663025e-01
    z[5,2,5]  R2181     -1.9784484058618546e-02
    z[5,2,5]  R2182     5.9179648756980896e-02
    z[5,2,5]  R2183     7.2134897112846375e-02
    z[5,2,5]  R2184     1.1516427993774414e-01
    z[5,2,5]  R2185     3.3080011606216431e-01
    z[5,2,5]  R2186     4.1496536135673523e-01
    z[5,2,5]  R2187     2.4856556951999664e-01
    z[5,2,5]  R2188     4.6000748872756958e-01
    z[5,2,5]  R2189     -5.1871344447135925e-02
    z[5,2,5]  R2190     3.1858170032501221e-01
    z[5,2,5]  R2191     8.2440860569477081e-02
    z[5,2,5]  R2192     -5.7709765434265137e-01
    z[5,2,5]  R2193     -3.5071596503257751e-01
    z[5,2,5]  R2194     -0.278903067111969
    z[5,2,5]  R2195     5.8221589773893356e-02
    z[5,2,5]  R2196     -0.517057478427887
    z[5,2,5]  R2197     -1.5165178477764130e-01
    z[5,2,5]  R2198     -2.3012003302574158e-01
    z[5,2,5]  R2199     -1.0831041634082794e-01
    z[5,2,5]  R2200     -4.0791058540344238e-01
    z[5,2,5]  R2201     -7.4242120981216431e-01
    z[5,2,5]  R2202     3.2431101799011230e-01
    z[5,2,5]  R2203     1.3020985759794712e-02
    z[5,2,5]  R2204     1.7334592342376709e-01
    z[5,2,5]  R2205     2.3370157182216644e-01
    z[5,2,5]  R2206     3.6393117904663086e-01
    z[5,2,5]  R2207     3.2534962892532349e-01
    z[5,2,5]  R2208     0.166063129901886
    z[5,2,5]  R2209     9.8060876131057739e-02
    z[5,2,5]  R2210     2.5930896401405334e-01
    z[5,2,5]  R2211     2.8347793221473694e-01
    z[5,2,5]  R2212     -2.1221968531608582e-01
    z[5,2,5]  R2213     -2.6262289285659790e-01
    z[5,2,5]  R2214     3.7324330210685730e-01
    z[5,2,5]  R2215     1.0355718433856964e-01
    z[5,2,5]  R2216     -2.0006487146019936e-02
    z[5,2,5]  R2217     3.7442959845066071e-02
    z[5,2,5]  R2218     3.6605718731880188e-01
    z[5,2,5]  R2219     2.8392788767814636e-01
    z[5,2,5]  R2220     2.2410650551319122e-01
    z[5,2,5]  R2221     3.9185580611228943e-01
    z[5,2,5]  R2222     -4.6332050114870071e-02
    z[5,2,5]  R2223     -2.9014545679092407e-01
    z[5,2,5]  R2224     3.3672028779983521e-01
    z[5,2,5]  R2225     5.5800926685333252e-01
    z[5,2,5]  R2226     0.097394198179245
    z[5,2,5]  R2227     3.9934930391609669e-03
    z[5,2,5]  R2228     6.4718961715698242e-02
    z[5,2,5]  R2229     4.3009036779403687e-01
    z[5,2,5]  R2230     -1.2009969353675842e-01
    z[5,2,5]  R2231     0.0447159968316555
    z[5,2,5]  R2232     1.9053022563457489e-01
    z[5,2,5]  R2233     1.5491028130054474e-01
    z[5,2,5]  R2234     -4.1099965572357178e-01
    z[5,2,5]  R2235     -3.3980360627174377e-01
    z[5,2,5]  R2236     2.9551693797111511e-01
    z[5,2,5]  R2237     2.8076082468032837e-02
    z[5,2,5]  R2238     4.3349310755729675e-02
    z[5,2,5]  R2239     0.0949019193649292
    z[5,2,5]  R2240     -1.9856201112270355e-01
    z[5,2,5]  R2241     3.4327441453933716e-01
    z[5,2,5]  R2242     -0.295166552066803
    z[5,2,5]  R2243     -3.4717667102813721e-01
    z[5,2,5]  R2244     -3.6521118879318237e-01
    z[5,2,5]  R2245     -1.5804505348205566e-01
    z[5,2,5]  R2246     -6.1893957853317261e-01
    z[5,2,5]  R2247     2.2514855861663818e-01
    z[5,2,5]  R2248     -8.1602893769741058e-02
    z[5,2,5]  R2249     -3.0847036838531494e-01
    z[5,2,5]  R2250     -2.2324765101075172e-02
    z[5,2,5]  R2251     -1.1252982169389725e-01
    z[5,2,5]  R2252     -5.4488635063171387e-01
    z[5,2,5]  R2253     -2.3003305494785309e-01
    z[5,2,5]  R2254     8.4717579185962677e-02
    z[5,2,5]  R2255     -2.1322610974311829e-01
    z[5,2,5]  R2256     -3.1098678708076477e-01
    z[5,2,5]  R2257     -4.3563401699066162e-01
    z[5,2,5]  R2258     4.3798366189002991e-01
    z[5,2,5]  R2259     2.8272947669029236e-01
    z[5,2,5]  R2260     2.6798954606056213e-01
    z[5,2,5]  R2261     4.4543093442916870e-01
    z[5,2,5]  R2262     1.1807820200920105e-01
    z[5,2,5]  R2263     -2.0969074964523315e-01
    z[5,2,5]  R2264     0.584648609161377
    z[5,2,5]  R2265     4.6253389120101929e-01
    z[5,2,5]  R2266     1.1077541112899780e-01
    z[5,2,5]  R2267     3.1556141376495361e-01
    z[5,2,5]  R2268     1.1781197786331177e-01
    z[5,2,5]  R2269     3.8323265314102173e-01
    z[5,2,5]  R2270     5.9083163738250732e-01
    z[5,2,5]  R2271     5.3693127632141113e-01
    z[5,2,5]  R2272     1.5663637220859528e-01
    z[5,2,5]  R2273     4.1953021287918091e-01
    z[5,2,5]  R2274     2.4167820811271667e-01
    z[5,2,5]  R2275     2.1930266916751862e-01
    z[5,2,5]  R2276     2.1439573168754578e-01
    z[5,2,5]  R2277     2.9126736521720886e-01
    z[5,2,5]  R2278     1.5991058945655823e-01
    z[5,2,5]  R2279     9.4435155391693115e-02
    z[5,2,5]  R2280     2.6526299118995667e-01
    z[5,2,5]  R2281     3.2946422696113586e-01
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R2120     -1
    z[5,2,6]  R2121     1
    z[5,2,6]  R2122     -8.8365182280540466e-02
    z[5,2,6]  R2123     -3.9545637369155884e-01
    z[5,2,6]  R2124     5.7798791676759720e-02
    z[5,2,6]  R2125     -1.3976109027862549e-01
    z[5,2,6]  R2126     3.2563191652297974e-01
    z[5,2,6]  R2127     3.4999959170818329e-02
    z[5,2,6]  R2128     1.8482497334480286e-01
    z[5,2,6]  R2129     3.5145051777362823e-02
    z[5,2,6]  R2130     1.9077347218990326e-01
    z[5,2,6]  R2131     -3.4835245460271835e-02
    z[5,2,6]  R2132     -1.4184023439884186e-01
    z[5,2,6]  R2133     -1.6157792508602142e-01
    z[5,2,6]  R2134     1.4025190472602844e-01
    z[5,2,6]  R2135     3.3324298262596130e-01
    z[5,2,6]  R2136     1.6489909589290619e-01
    z[5,2,6]  R2137     -1.6969369351863861e-01
    z[5,2,6]  R2138     4.1545432060956955e-02
    z[5,2,6]  R2139     3.2960101962089539e-01
    z[5,2,6]  R2140     9.5377013087272644e-02
    z[5,2,6]  R2141     3.6477804183959961e-01
    z[5,2,6]  R2142     -3.2919496297836304e-01
    z[5,2,6]  R2143     -1.0445023328065872e-01
    z[5,2,6]  R2144     8.2382082939147949e-02
    z[5,2,6]  R2145     9.5949888229370117e-02
    z[5,2,6]  R2146     3.4505769610404968e-01
    z[5,2,6]  R2147     -5.6673612445592880e-02
    z[5,2,6]  R2148     4.2273110151290894e-01
    z[5,2,6]  R2149     -3.5286897420883179e-01
    z[5,2,6]  R2150     -1.8022920191287994e-01
    z[5,2,6]  R2151     9.2139437794685364e-02
    z[5,2,6]  R2152     5.0284836441278458e-02
    z[5,2,6]  R2153     1.9310359656810760e-01
    z[5,2,6]  R2154     -2.2523060441017151e-01
    z[5,2,6]  R2155     -1.0507960803806782e-02
    z[5,2,6]  R2156     3.3523243665695190e-01
    z[5,2,6]  R2157     0.263115257024765
    z[5,2,6]  R2158     -0.0172833651304245
    z[5,2,6]  R2159     2.6480999588966370e-01
    z[5,2,6]  R2160     -0.0742039605975151
    z[5,2,6]  R2161     2.3711478710174561e-01
    z[5,2,6]  R2162     5.6914114393293858e-03
    z[5,2,6]  R2163     2.4102061986923218e-01
    z[5,2,6]  R2164     -1.9952252507209778e-01
    z[5,2,6]  R2165     6.1366468667984009e-02
    z[5,2,6]  R2166     8.4016129374504089e-02
    z[5,2,6]  R2167     -1.6170255839824677e-01
    z[5,2,6]  R2168     5.7765308767557144e-02
    z[5,2,6]  R2169     3.6379155516624451e-01
    z[5,2,6]  R2170     -1.2155794352293015e-01
    z[5,2,6]  R2171     1.8742622435092926e-01
    z[5,2,6]  R2172     -2.3593294620513916e-01
    z[5,2,6]  R2173     3.0443921685218811e-01
    z[5,2,6]  R2174     -1.3737358152866364e-01
    z[5,2,6]  R2175     1.1643828451633453e-01
    z[5,2,6]  R2176     1.7010244727134705e-01
    z[5,2,6]  R2177     0.232234388589859
    z[5,2,6]  R2178     -5.6208237074315548e-03
    z[5,2,6]  R2179     -2.1610192954540253e-01
    z[5,2,6]  R2180     1.4185032248497009e-01
    z[5,2,6]  R2181     -0.391007661819458
    z[5,2,6]  R2182     -3.9091381430625916e-01
    z[5,2,6]  R2183     -6.0242330655455589e-03
    z[5,2,6]  R2184     1.0224212892353535e-02
    z[5,2,6]  R2185     1.3477612286806107e-02
    z[5,2,6]  R2186     5.7424264959990978e-03
    z[5,2,6]  R2187     -1.5017724037170410e-01
    z[5,2,6]  R2188     -4.2608477175235748e-02
    z[5,2,6]  R2189     -3.2186403870582581e-01
    z[5,2,6]  R2190     -3.1398364901542664e-01
    z[5,2,6]  R2191     0.0945323258638382
    z[5,2,6]  R2192     -1.7919200658798218e-01
    z[5,2,6]  R2193     1.1737052351236343e-01
    z[5,2,6]  R2194     -3.0322477221488953e-01
    z[5,2,6]  R2195     -7.3339521884918213e-02
    z[5,2,6]  R2196     -0.586080014705658
    z[5,2,6]  R2197     1.4169251918792725e-01
    z[5,2,6]  R2198     1.3314105570316315e-01
    z[5,2,6]  R2199     2.2169493138790131e-01
    z[5,2,6]  R2200     0.506830632686615
    z[5,2,6]  R2201     -2.3363646864891052e-01
    z[5,2,6]  R2202     4.2107634246349335e-02
    z[5,2,6]  R2203     -1.0225398838520050e-01
    z[5,2,6]  R2204     -1.1910647153854370e-01
    z[5,2,6]  R2205     -4.8612681031227112e-01
    z[5,2,6]  R2206     -1.8703129887580872e-01
    z[5,2,6]  R2207     1.1156961321830750e-01
    z[5,2,6]  R2208     -5.7398449629545212e-02
    z[5,2,6]  R2209     1.1197334527969360e-01
    z[5,2,6]  R2210     2.9366193339228630e-02
    z[5,2,6]  R2211     -8.4692798554897308e-02
    z[5,2,6]  R2212     3.4464153647422791e-01
    z[5,2,6]  R2213     -2.0486536622047424e-01
    z[5,2,6]  R2214     -0.359995037317276
    z[5,2,6]  R2215     6.2019795179367065e-02
    z[5,2,6]  R2216     -6.6353239119052887e-02
    z[5,2,6]  R2217     -4.7712358832359314e-01
    z[5,2,6]  R2218     -2.9085966944694519e-01
    z[5,2,6]  R2219     1.4768464863300323e-01
    z[5,2,6]  R2220     0.361070841550827
    z[5,2,6]  R2221     6.4369112253189087e-01
    z[5,2,6]  R2222     3.3611815422773361e-02
    z[5,2,6]  R2223     5.8424003422260284e-02
    z[5,2,6]  R2224     2.9420611262321472e-01
    z[5,2,6]  R2225     3.5556632280349731e-01
    z[5,2,6]  R2226     2.7982246875762939e-01
    z[5,2,6]  R2227     -1.7918157577514648e-01
    z[5,2,6]  R2228     -3.9160954952239990e-01
    z[5,2,6]  R2229     2.5816816091537476e-01
    z[5,2,6]  R2230     5.3819339722394943e-02
    z[5,2,6]  R2231     1.6115494072437286e-01
    z[5,2,6]  R2232     1.5988571941852570e-01
    z[5,2,6]  R2233     5.4371935129165649e-01
    z[5,2,6]  R2234     -2.3824411630630493e-01
    z[5,2,6]  R2235     0.0323464460670948
    z[5,2,6]  R2236     -3.2886481285095215e-01
    z[5,2,6]  R2237     -2.0483744144439697e-01
    z[5,2,6]  R2238     -6.2456015497446060e-02
    z[5,2,6]  R2239     -6.0060225427150726e-02
    z[5,2,6]  R2240     -3.7260480225086212e-02
    z[5,2,6]  R2241     -8.9438818395137787e-02
    z[5,2,6]  R2242     3.6358860135078430e-01
    z[5,2,6]  R2243     -1.4429277181625366e-01
    z[5,2,6]  R2244     2.7114427089691162e-01
    z[5,2,6]  R2245     -3.8851892948150635e-01
    z[5,2,6]  R2246     1.7991696298122406e-01
    z[5,2,6]  R2247     -2.3394417762756348e-01
    z[5,2,6]  R2248     0.236423060297966
    z[5,2,6]  R2249     -3.3040741086006165e-01
    z[5,2,6]  R2250     -2.5347569584846497e-01
    z[5,2,6]  R2251     -4.4116694480180740e-02
    z[5,2,6]  R2252     1.1758720874786377e-01
    z[5,2,6]  R2253     1.5814271569252014e-01
    z[5,2,6]  R2254     2.6673685759305954e-02
    z[5,2,6]  R2255     -3.2572884112596512e-02
    z[5,2,6]  R2256     1.0089663416147232e-01
    z[5,2,6]  R2257     3.9931874722242355e-02
    z[5,2,6]  R2258     2.9144637286663055e-02
    z[5,2,6]  R2259     -2.0908041298389435e-01
    z[5,2,6]  R2260     5.1410514116287231e-01
    z[5,2,6]  R2261     5.5026924610137939e-01
    z[5,2,6]  R2262     -0.227493554353714
    z[5,2,6]  R2263     -2.5993982329964638e-02
    z[5,2,6]  R2264     2.8447759151458740e-01
    z[5,2,6]  R2265     5.4953861236572266e-01
    z[5,2,6]  R2266     -2.9029166698455811e-01
    z[5,2,6]  R2267     1.8050950765609741e-01
    z[5,2,6]  R2268     4.4846269488334656e-01
    z[5,2,6]  R2269     -6.0303188860416412e-02
    z[5,2,6]  R2270     -2.7751579880714417e-01
    z[5,2,6]  R2271     0.000607263995334506
    z[5,2,6]  R2272     -8.4105335175991058e-02
    z[5,2,6]  R2273     -1.8866260349750519e-01
    z[5,2,6]  R2274     3.8933104276657104e-01
    z[5,2,6]  R2275     -2.7347257733345032e-01
    z[5,2,6]  R2276     -1.3086025416851044e-01
    z[5,2,6]  R2277     -9.8307356238365173e-02
    z[5,2,6]  R2278     2.1744383871555328e-01
    z[5,2,6]  R2279     5.4348301142454147e-02
    z[5,2,6]  R2280     7.5376674532890320e-02
    z[5,2,6]  R2281     1.1221068352460861e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2386     -1
    z[3,4,0]  R2387     1
    z[3,4,0]  R2400     -3.6589086055755615e-02
    z[3,4,0]  R2401     0.0693727433681488
    z[3,4,0]  R2402     1.3377635739743710e-02
    z[3,4,0]  R2403     -0.705590546131134
    z[3,4,0]  R2404     2.9925478622317314e-02
    z[3,4,0]  R2405     5.5139489471912384e-02
    z[3,4,0]  R2406     6.8879328668117523e-02
    z[3,4,0]  R2407     -3.4376001358032227e-01
    z[3,4,0]  R2408     6.8608321249485016e-02
    z[3,4,0]  R2409     -9.5315627753734589e-02
    z[3,4,0]  R2410     4.1588321328163147e-01
    z[3,4,0]  R2411     1.1865523457527161e-01
    z[3,4,0]  R2412     1.0987310111522675e-01
    z[3,4,0]  R2413     1.7032913863658905e-01
    z[3,4,0]  R2414     7.7343232929706573e-02
    z[3,4,0]  R2415     2.4044688045978546e-01
    z[3,4,0]  R2416     4.9973991513252258e-01
    z[3,4,0]  R2417     -2.0393800735473633e-01
    z[3,4,0]  R2418     0.332888126373291
    z[3,4,0]  R2419     -0.397519052028656
    z[3,4,0]  R2420     1.4147533476352692e-01
    z[3,4,0]  R2421     3.6231091618537903e-01
    z[3,4,0]  R2422     -9.3511618673801422e-02
    z[3,4,0]  R2423     1.5615861117839813e-01
    z[3,4,0]  R2424     -1.8030744791030884e-01
    z[3,4,0]  R2425     -2.3016983270645142e-01
    z[3,4,0]  R2426     -2.6206314563751221e-01
    z[3,4,0]  R2427     -3.4449473023414612e-01
    z[3,4,0]  R2428     -2.2381576895713806e-01
    z[3,4,0]  R2429     3.4233424067497253e-01
    z[3,4,0]  R2430     1.2595053017139435e-01
    z[3,4,0]  R2431     3.8731002807617188e-01
    z[3,4,0]  R2432     -4.0880435705184937e-01
    z[3,4,0]  R2433     1.0537336766719818e-01
    z[3,4,0]  R2434     -3.6036467552185059e-01
    z[3,4,0]  R2435     -1.4476144686341286e-02
    z[3,4,0]  R2436     -2.9991042613983154e-01
    z[3,4,0]  R2437     -5.9298592805862427e-01
    z[3,4,0]  R2438     5.9217196702957153e-01
    z[3,4,0]  R2439     5.6940101087093353e-02
    z[3,4,0]  R2440     -5.6806594133377075e-01
    z[3,4,0]  R2441     -4.8820680379867554e-01
    z[3,4,0]  R2442     -1.0065668821334839e-01
    z[3,4,0]  R2443     -6.6662663221359253e-01
    z[3,4,0]  R2444     -5.2976123988628387e-02
    z[3,4,0]  R2445     8.1685623154044151e-03
    z[3,4,0]  R2446     1.7718593776226044e-01
    z[3,4,0]  R2447     4.3916791677474976e-01
    z[3,4,0]  R2448     3.4565997123718262e-01
    z[3,4,0]  R2449     4.5147308707237244e-01
    z[3,4,0]  R2450     -0.610199511051178
    z[3,4,0]  R2451     -6.9077622890472412e-01
    z[3,4,0]  R2452     -3.8901382684707642e-01
    z[3,4,0]  R2453     -2.2505044937133789e-01
    z[3,4,0]  R2454     -3.8937729597091675e-01
    z[3,4,0]  R2455     2.6735246181488037e-01
    z[3,4,0]  R2456     -6.1612665653228760e-01
    z[3,4,0]  R2457     -0.665919303894043
    z[3,4,0]  R2458     -5.9971648454666138e-01
    z[3,4,0]  R2459     -5.4659348726272583e-01
    z[3,4,0]  R2460     -4.4537249207496643e-01
    z[3,4,0]  R2461     -5.1074630022048950e-01
    z[3,4,0]  R2462     -5.2198320627212524e-01
    z[3,4,0]  R2463     1.4921683818101883e-02
    z[3,4,0]  R2464     -9.6592712402343750e-01
    z[3,4,0]  R2465     8.0585852265357971e-02
    z[3,4,0]  R2466     -1.7927173525094986e-02
    z[3,4,0]  R2467     3.2609567046165466e-02
    z[3,4,0]  R2468     -2.4398061633110046e-01
    z[3,4,0]  R2469     -1.0867832228541374e-02
    z[3,4,0]  R2470     0.331209659576416
    z[3,4,0]  R2471     3.7573602795600891e-01
    z[3,4,0]  R2472     4.9842461943626404e-01
    z[3,4,0]  R2473     3.3839711546897888e-01
    z[3,4,0]  R2474     3.7496492266654968e-01
    z[3,4,0]  R2475     3.4600558876991272e-01
    z[3,4,0]  R2476     2.5181302428245544e-01
    z[3,4,0]  R2477     1.5387284755706787e-01
    z[3,4,0]  R2478     3.2433813810348511e-01
    z[3,4,0]  R2479     2.0987780392169952e-01
    z[3,4,0]  R2480     2.4177080392837524e-01
    z[3,4,0]  R2481     -1.7149411141872406e-01
    z[3,4,0]  R2482     -1.1276394070591778e-04
    z[3,4,0]  R2483     0.299360454082489
    z[3,4,0]  R2484     1.8625383079051971e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2388     -1
    z[3,4,1]  R2389     1
    z[3,4,1]  R2400     -7.8813350200653076e-01
    z[3,4,1]  R2401     -6.3816928863525391e-01
    z[3,4,1]  R2402     -5.9123784303665161e-01
    z[3,4,1]  R2403     6.3668894767761230e-01
    z[3,4,1]  R2404     -2.9680398106575012e-01
    z[3,4,1]  R2405     -3.4536263346672058e-01
    z[3,4,1]  R2406     -3.0272287130355835e-01
    z[3,4,1]  R2407     6.2705171108245850e-01
    z[3,4,1]  R2408     5.4102611541748047e-01
    z[3,4,1]  R2409     7.6169586181640625e-01
    z[3,4,1]  R2410     -4.5111289620399475e-01
    z[3,4,1]  R2411     -0.439800888299942
    z[3,4,1]  R2412     -3.8439545035362244e-01
    z[3,4,1]  R2413     -3.6523753404617310e-01
    z[3,4,1]  R2414     -4.0704101324081421e-01
    z[3,4,1]  R2415     -2.5016698241233826e-01
    z[3,4,1]  R2416     7.4719732999801636e-01
    z[3,4,1]  R2417     6.8427371978759766e-01
    z[3,4,1]  R2418     6.9754534959793091e-01
    z[3,4,1]  R2419     1.9880345463752747e-01
    z[3,4,1]  R2420     0.857233464717865
    z[3,4,1]  R2421     7.9025137424468994e-01
    z[3,4,1]  R2422     8.0379545688629150e-01
    z[3,4,1]  R2423     6.9972038269042969e-01
    z[3,4,1]  R2424     8.0500149726867676e-01
    z[3,4,1]  R2425     7.3723131418228149e-01
    z[3,4,1]  R2426     6.5980720520019531e-01
    z[3,4,1]  R2427     5.4039853811264038e-01
    z[3,4,1]  R2428     6.3432049751281738e-01
    z[3,4,1]  R2429     3.8795873522758484e-01
    z[3,4,1]  R2430     -6.5281128883361816e-01
    z[3,4,1]  R2431     -4.6596240997314453e-01
    z[3,4,1]  R2432     8.1147712469100952e-01
    z[3,4,1]  R2433     7.8923958539962769e-01
    z[3,4,1]  R2434     4.0587291121482849e-01
    z[3,4,1]  R2435     7.8663498163223267e-01
    z[3,4,1]  R2436     4.4646963477134705e-01
    z[3,4,1]  R2437     1.2665164470672607e-01
    z[3,4,1]  R2438     5.2032095193862915e-01
    z[3,4,1]  R2439     2.4986878037452698e-01
    z[3,4,1]  R2440     4.8440101742744446e-01
    z[3,4,1]  R2441     6.6852509975433350e-01
    z[3,4,1]  R2442     6.3663446903228760e-01
    z[3,4,1]  R2443     4.4251322746276855e-01
    z[3,4,1]  R2444     8.6939907073974609e-01
    z[3,4,1]  R2445     6.1848264932632446e-01
    z[3,4,1]  R2446     3.2343354821205139e-01
    z[3,4,1]  R2447     5.4146373271942139e-01
    z[3,4,1]  R2448     1.8972527980804443e-01
    z[3,4,1]  R2449     4.1707709431648254e-01
    z[3,4,1]  R2450     4.7122615575790405e-01
    z[3,4,1]  R2451     6.4674860239028931e-01
    z[3,4,1]  R2452     7.6113170385360718e-01
    z[3,4,1]  R2453     4.8126682639122009e-01
    z[3,4,1]  R2454     4.3018519878387451e-01
    z[3,4,1]  R2455     2.5084331631660461e-01
    z[3,4,1]  R2456     -3.1143131852149963e-01
    z[3,4,1]  R2457     -1.7610348761081696e-01
    z[3,4,1]  R2458     -2.7668842673301697e-01
    z[3,4,1]  R2459     -3.7183105945587158e-01
    z[3,4,1]  R2460     0.665277361869812
    z[3,4,1]  R2461     5.7158994674682617e-01
    z[3,4,1]  R2462     4.0337088704109192e-01
    z[3,4,1]  R2463     7.5647455453872681e-01
    z[3,4,1]  R2464     7.8719764947891235e-02
    z[3,4,1]  R2465     -6.6353100538253784e-01
    z[3,4,1]  R2466     -5.6738960742950439e-01
    z[3,4,1]  R2467     -0.539656400680542
    z[3,4,1]  R2468     -7.3659688234329224e-01
    z[3,4,1]  R2469     2.8826889395713806e-01
    z[3,4,1]  R2470     -7.7573865652084351e-01
    z[3,4,1]  R2471     -7.6019245386123657e-01
    z[3,4,1]  R2472     -6.0532516241073608e-01
    z[3,4,1]  R2473     -7.0515912771224976e-01
    z[3,4,1]  R2474     -6.2775951623916626e-01
    z[3,4,1]  R2475     -6.5205973386764526e-01
    z[3,4,1]  R2476     -7.5500094890594482e-01
    z[3,4,1]  R2477     -0.685711681842804
    z[3,4,1]  R2478     -5.7793557643890381e-01
    z[3,4,1]  R2479     -6.6598445177078247e-01
    z[3,4,1]  R2480     -6.6299033164978027e-01
    z[3,4,1]  R2481     2.1881558932363987e-03
    z[3,4,1]  R2482     1.9273987039923668e-02
    z[3,4,1]  R2483     5.7013678550720215e-01
    z[3,4,1]  R2484     6.1896014213562012e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2390     -1
    z[3,4,2]  R2391     1
    z[3,4,2]  R2400     2.9155045747756958e-01
    z[3,4,2]  R2401     -4.2261886596679688e-01
    z[3,4,2]  R2402     0.0226475540548563
    z[3,4,2]  R2403     -7.3616698384284973e-02
    z[3,4,2]  R2404     0.351779967546463
    z[3,4,2]  R2405     -1.2747351825237274e-01
    z[3,4,2]  R2406     -1.1474695056676865e-01
    z[3,4,2]  R2407     3.4420590847730637e-02
    z[3,4,2]  R2408     2.1619459986686707e-01
    z[3,4,2]  R2409     2.0916143059730530e-01
    z[3,4,2]  R2410     6.6711580753326416e-01
    z[3,4,2]  R2411     1.9830379635095596e-02
    z[3,4,2]  R2412     4.0915283560752869e-01
    z[3,4,2]  R2413     5.5210381746292114e-02
    z[3,4,2]  R2414     -1.1304409801959991e-01
    z[3,4,2]  R2415     -6.1652410030364990e-01
    z[3,4,2]  R2416     -1.5276296436786652e-01
    z[3,4,2]  R2417     1.4430822432041168e-01
    z[3,4,2]  R2418     -2.7639037370681763e-01
    z[3,4,2]  R2419     -3.8856777548789978e-01
    z[3,4,2]  R2420     2.6850545406341553e-01
    z[3,4,2]  R2421     -1.3540776073932648e-01
    z[3,4,2]  R2422     -1.0470170527696609e-01
    z[3,4,2]  R2423     -3.6883455514907837e-01
    z[3,4,2]  R2424     -1.7168706655502319e-01
    z[3,4,2]  R2425     4.8716634511947632e-01
    z[3,4,2]  R2426     1.8579114973545074e-01
    z[3,4,2]  R2427     -4.8725920915603638e-01
    z[3,4,2]  R2428     -2.5702643394470215e-01
    z[3,4,2]  R2429     2.5466141104698181e-01
    z[3,4,2]  R2430     -3.2065615057945251e-01
    z[3,4,2]  R2431     3.8088664412498474e-01
    z[3,4,2]  R2432     -5.6624421849846840e-03
    z[3,4,2]  R2433     -2.9873631894588470e-02
    z[3,4,2]  R2434     -6.1045056581497192e-01
    z[3,4,2]  R2435     -2.4921372532844543e-01
    z[3,4,2]  R2436     -4.9589291214942932e-01
    z[3,4,2]  R2437     3.9476905949413776e-03
    z[3,4,2]  R2438     3.8990476727485657e-01
    z[3,4,2]  R2439     4.9159295856952667e-02
    z[3,4,2]  R2440     -4.7137516736984253e-01
    z[3,4,2]  R2441     7.6161310076713562e-02
    z[3,4,2]  R2442     3.3059367537498474e-01
    z[3,4,2]  R2443     -1.8056605011224747e-02
    z[3,4,2]  R2444     8.5890352725982666e-02
    z[3,4,2]  R2445     -1.1896006017923355e-01
    z[3,4,2]  R2446     -3.1947073340415955e-01
    z[3,4,2]  R2447     4.3478971719741821e-01
    z[3,4,2]  R2448     -1.6211281716823578e-01
    z[3,4,2]  R2449     1.5092931687831879e-01
    z[3,4,2]  R2450     -4.5245864987373352e-01
    z[3,4,2]  R2451     -1.4433425664901733e-01
    z[3,4,2]  R2452     3.1044140458106995e-01
    z[3,4,2]  R2453     -2.6153931021690369e-01
    z[3,4,2]  R2454     -0.280733197927475
    z[3,4,2]  R2455     -1.3410811126232147e-01
    z[3,4,2]  R2456     5.7834321260452271e-01
    z[3,4,2]  R2457     3.7822961807250977e-01
    z[3,4,2]  R2458     4.3421438336372375e-01
    z[3,4,2]  R2459     4.9262502789497375e-01
    z[3,4,2]  R2460     -3.3246603608131409e-01
    z[3,4,2]  R2461     -3.3024686574935913e-01
    z[3,4,2]  R2462     -3.8213226199150085e-01
    z[3,4,2]  R2463     -5.9999954700469971e-01
    z[3,4,2]  R2464     -1.8448592722415924e-01
    z[3,4,2]  R2465     4.5519477128982544e-01
    z[3,4,2]  R2466     -1.3045579195022583e-01
    z[3,4,2]  R2467     -2.9634529352188110e-01
    z[3,4,2]  R2468     4.5163431763648987e-01
    z[3,4,2]  R2469     0.0443992018699646
    z[3,4,2]  R2470     4.3069524690508842e-03
    z[3,4,2]  R2471     -2.0378093421459198e-01
    z[3,4,2]  R2472     -2.0583665370941162e-01
    z[3,4,2]  R2473     -0.601309597492218
    z[3,4,2]  R2474     7.6408926397562027e-03
    z[3,4,2]  R2475     -2.1865795552730560e-01
    z[3,4,2]  R2476     -5.1944029331207275e-01
    z[3,4,2]  R2477     2.9603847861289978e-01
    z[3,4,2]  R2478     -1.8319685757160187e-01
    z[3,4,2]  R2479     5.0144165754318237e-01
    z[3,4,2]  R2480     3.1911796331405640e-01
    z[3,4,2]  R2481     -5.3569239377975464e-01
    z[3,4,2]  R2482     -5.2974373102188110e-01
    z[3,4,2]  R2483     3.3966198563575745e-01
    z[3,4,2]  R2484     6.2364935874938965e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2392     -1
    z[3,4,3]  R2393     1
    z[3,4,3]  R2400     1.1979837715625763e-01
    z[3,4,3]  R2401     -5.2399146556854248e-01
    z[3,4,3]  R2402     6.6634345054626465e-01
    z[3,4,3]  R2403     -1.1344969272613525e-01
    z[3,4,3]  R2404     -8.2266800105571747e-02
    z[3,4,3]  R2405     -0.0785977765917778
    z[3,4,3]  R2406     -4.3732246756553650e-01
    z[3,4,3]  R2407     -4.9222588539123535e-01
    z[3,4,3]  R2408     -0.789358377456665
    z[3,4,3]  R2409     -5.1896160840988159e-01
    z[3,4,3]  R2410     -1.4762806892395020e-01
    z[3,4,3]  R2411     -7.1839645504951477e-02
    z[3,4,3]  R2412     -5.1226228475570679e-01
    z[3,4,3]  R2413     2.3346434533596039e-01
    z[3,4,3]  R2414     -1.5381909906864166e-01
    z[3,4,3]  R2415     -1.4028598368167877e-01
    z[3,4,3]  R2416     -6.1548583209514618e-02
    z[3,4,3]  R2417     -3.1095218658447266e-01
    z[3,4,3]  R2418     -3.7301453948020935e-01
    z[3,4,3]  R2419     -4.6497520804405212e-01
    z[3,4,3]  R2420     -3.3105546236038208e-01
    z[3,4,3]  R2421     -4.6913620829582214e-01
    z[3,4,3]  R2422     -4.1991695761680603e-01
    z[3,4,3]  R2423     -5.5058246850967407e-01
    z[3,4,3]  R2424     5.0946021080017090e-01
    z[3,4,3]  R2425     -6.6334336996078491e-02
    z[3,4,3]  R2426     2.7412867546081543e-01
    z[3,4,3]  R2427     4.4249475002288818e-01
    z[3,4,3]  R2428     3.2248049974441528e-01
    z[3,4,3]  R2429     -4.0056106448173523e-01
    z[3,4,3]  R2430     4.4133597612380981e-01
    z[3,4,3]  R2431     -0.0772356316447258
    z[3,4,3]  R2432     2.7450013160705566e-01
    z[3,4,3]  R2433     -5.1207160949707031e-01
    z[3,4,3]  R2434     -3.5299211740493774e-01
    z[3,4,3]  R2435     -5.8170523494482040e-02
    z[3,4,3]  R2436     -0.651406466960907
    z[3,4,3]  R2437     -5.9365576505661011e-01
    z[3,4,3]  R2438     -0.0291308481246233
    z[3,4,3]  R2439     -5.1408547163009644e-01
    z[3,4,3]  R2440     -5.0025876611471176e-02
    z[3,4,3]  R2441     5.7337163016200066e-03
    z[3,4,3]  R2442     -5.2307796478271484e-01
    z[3,4,3]  R2443     8.1351123750209808e-02
    z[3,4,3]  R2444     -1.3375589251518250e-01
    z[3,4,3]  R2445     -3.2607337832450867e-01
    z[3,4,3]  R2446     -0.739935040473938
    z[3,4,3]  R2447     -2.4455970525741577e-01
    z[3,4,3]  R2448     -5.2082246541976929e-01
    z[3,4,3]  R2449     -9.2234991490840912e-02
    z[3,4,3]  R2450     -3.7684386968612671e-01
    z[3,4,3]  R2451     2.8232610225677490e-01
    z[3,4,3]  R2452     3.2263547182083130e-01
    z[3,4,3]  R2453     -6.4435219764709473e-01
    z[3,4,3]  R2454     -3.7938350439071655e-01
    z[3,4,3]  R2455     -5.5153644084930420e-01
    z[3,4,3]  R2456     -3.8196936249732971e-01
    z[3,4,3]  R2457     -4.2192295193672180e-01
    z[3,4,3]  R2458     -3.7358319759368896e-01
    z[3,4,3]  R2459     -4.0055724978446960e-01
    z[3,4,3]  R2460     6.1623834073543549e-02
    z[3,4,3]  R2461     1.2031611055135727e-01
    z[3,4,3]  R2462     -1.0835071653127670e-01
    z[3,4,3]  R2463     1.6698566079139709e-01
    z[3,4,3]  R2464     -8.0087609589099884e-02
    z[3,4,3]  R2465     5.4327648133039474e-02
    z[3,4,3]  R2466     -5.7724362611770630e-01
    z[3,4,3]  R2467     1.4700695872306824e-01
    z[3,4,3]  R2468     1.0272392630577087e-01
    z[3,4,3]  R2469     8.5961920022964478e-01
    z[3,4,3]  R2470     -2.4001386761665344e-01
    z[3,4,3]  R2471     1.8896806240081787e-01
    z[3,4,3]  R2472     -0.388874351978302
    z[3,4,3]  R2473     1.1385331302881241e-01
    z[3,4,3]  R2474     3.0618848279118538e-02
    z[3,4,3]  R2475     5.8276718854904175e-01
    z[3,4,3]  R2476     -4.3951552361249924e-02
    z[3,4,3]  R2477     3.5840559005737305e-01
    z[3,4,3]  R2478     1.5175801515579224e-01
    z[3,4,3]  R2479     1.3548615574836731e-01
    z[3,4,3]  R2480     -7.3759861290454865e-02
    z[3,4,3]  R2481     -6.4899915456771851e-01
    z[3,4,3]  R2482     -3.1279709935188293e-01
    z[3,4,3]  R2483     -6.1535632610321045e-01
    z[3,4,3]  R2484     -2.5307220220565796e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2394     -1
    z[3,4,4]  R2395     1
    z[3,4,4]  R2400     4.0810516476631165e-01
    z[3,4,4]  R2401     -8.2651257514953613e-02
    z[3,4,4]  R2402     2.2359290719032288e-01
    z[3,4,4]  R2403     1.9921872019767761e-01
    z[3,4,4]  R2404     -2.0305125415325165e-01
    z[3,4,4]  R2405     -3.4954020380973816e-01
    z[3,4,4]  R2406     7.8294515609741211e-02
    z[3,4,4]  R2407     3.9334109425544739e-01
    z[3,4,4]  R2408     -0.0928015261888504
    z[3,4,4]  R2409     2.6882079243659973e-01
    z[3,4,4]  R2410     6.7703694105148315e-02
    z[3,4,4]  R2411     -0.374188095331192
    z[3,4,4]  R2412     -1.1617810279130936e-01
    z[3,4,4]  R2413     -4.3234923481941223e-01
    z[3,4,4]  R2414     2.4462303519248962e-01
    z[3,4,4]  R2415     2.2121407091617584e-01
    z[3,4,4]  R2416     7.4796296656131744e-02
    z[3,4,4]  R2417     -7.2107151150703430e-02
    z[3,4,4]  R2418     -1.8771593272686005e-01
    z[3,4,4]  R2419     1.6012816131114960e-01
    z[3,4,4]  R2420     3.7444159388542175e-02
    z[3,4,4]  R2421     -1.1119368486106396e-02
    z[3,4,4]  R2422     1.2771655619144440e-01
    z[3,4,4]  R2423     1.7380365170538425e-03
    z[3,4,4]  R2424     -1.5074522234499454e-02
    z[3,4,4]  R2425     1.9664084911346436e-01
    z[3,4,4]  R2426     2.1345909684896469e-02
    z[3,4,4]  R2427     -1.5040965750813484e-02
    z[3,4,4]  R2428     5.8716509491205215e-02
    z[3,4,4]  R2429     -1.1619853228330612e-01
    z[3,4,4]  R2430     -2.2021043300628662e-01
    z[3,4,4]  R2431     -6.2694478034973145e-01
    z[3,4,4]  R2432     -1.0876150429248810e-01
    z[3,4,4]  R2433     1.5709446370601654e-01
    z[3,4,4]  R2434     -7.1048364043235779e-02
    z[3,4,4]  R2435     5.4756116867065430e-01
    z[3,4,4]  R2436     1.0645416378974915e-01
    z[3,4,4]  R2437     2.1118494868278503e-01
    z[3,4,4]  R2438     -1.6663597524166107e-01
    z[3,4,4]  R2439     3.7277019023895264e-01
    z[3,4,4]  R2440     -8.5882298648357391e-02
    z[3,4,4]  R2441     7.4555687606334686e-02
    z[3,4,4]  R2442     2.8460854291915894e-01
    z[3,4,4]  R2443     1.0403080284595490e-01
    z[3,4,4]  R2444     0.081064872443676
    z[3,4,4]  R2445     4.7856429219245911e-01
    z[3,4,4]  R2446     9.7546920180320740e-02
    z[3,4,4]  R2447     -4.3939024209976196e-01
    z[3,4,4]  R2448     1.4860205352306366e-01
    z[3,4,4]  R2449     2.2053673863410950e-01
    z[3,4,4]  R2450     -1.1096361279487610e-01
    z[3,4,4]  R2451     -4.2400330305099487e-02
    z[3,4,4]  R2452     1.3898704946041107e-01
    z[3,4,4]  R2453     3.9633655548095703e-01
    z[3,4,4]  R2454     4.7889527678489685e-01
    z[3,4,4]  R2455     1.7635495960712433e-01
    z[3,4,4]  R2456     7.3480255901813507e-02
    z[3,4,4]  R2457     3.4458291530609131e-01
    z[3,4,4]  R2458     3.3864155411720276e-01
    z[3,4,4]  R2459     2.0493526756763458e-01
    z[3,4,4]  R2460     9.6880055963993073e-02
    z[3,4,4]  R2461     2.8017762303352356e-01
    z[3,4,4]  R2462     -2.7349710464477539e-01
    z[3,4,4]  R2463     1.7739698290824890e-01
    z[3,4,4]  R2464     -2.9830446466803551e-02
    z[3,4,4]  R2465     5.0163465738296509e-01
    z[3,4,4]  R2466     -2.0905299112200737e-02
    z[3,4,4]  R2467     9.0793631970882416e-02
    z[3,4,4]  R2468     -4.2723834514617920e-01
    z[3,4,4]  R2469     -3.7313145399093628e-01
    z[3,4,4]  R2470     -2.1621921658515930e-01
    z[3,4,4]  R2471     -9.6813194453716278e-02
    z[3,4,4]  R2472     3.7031877040863037e-01
    z[3,4,4]  R2473     6.5757364034652710e-02
    z[3,4,4]  R2474     -2.7775904163718224e-02
    z[3,4,4]  R2475     -1.0947525501251221e-01
    z[3,4,4]  R2476     -1.0854104906320572e-01
    z[3,4,4]  R2477     -2.5228586792945862e-01
    z[3,4,4]  R2478     -6.6569441556930542e-01
    z[3,4,4]  R2479     -1.9893574714660645e-01
    z[3,4,4]  R2480     1.3082090020179749e-01
    z[3,4,4]  R2481     3.8038212805986404e-02
    z[3,4,4]  R2482     -6.0758739709854126e-01
    z[3,4,4]  R2483     -1.3361072167754173e-02
    z[3,4,4]  R2484     8.8092230260372162e-02
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2396     -1
    z[3,4,5]  R2397     1
    z[3,4,5]  R2400     2.9796305298805237e-01
    z[3,4,5]  R2401     3.5531315207481384e-01
    z[3,4,5]  R2402     3.1273981928825378e-01
    z[3,4,5]  R2403     1.5132869780063629e-01
    z[3,4,5]  R2404     8.2891270518302917e-02
    z[3,4,5]  R2405     1.8760459125041962e-01
    z[3,4,5]  R2406     -2.9356718063354492e-01
    z[3,4,5]  R2407     1.7945627868175507e-01
    z[3,4,5]  R2408     1.5480084717273712e-01
    z[3,4,5]  R2409     -4.5567336492240429e-03
    z[3,4,5]  R2410     -3.7057882547378540e-01
    z[3,4,5]  R2411     -5.8638083934783936e-01
    z[3,4,5]  R2412     -4.7048667073249817e-01
    z[3,4,5]  R2413     -7.1876019239425659e-01
    z[3,4,5]  R2414     -7.1208667755126953e-01
    z[3,4,5]  R2415     -6.4713490009307861e-01
    z[3,4,5]  R2416     3.7273174524307251e-01
    z[3,4,5]  R2417     -4.8278215527534485e-01
    z[3,4,5]  R2418     -3.8958466053009033e-01
    z[3,4,5]  R2419     -6.2846875190734863e-01
    z[3,4,5]  R2420     -2.0935179293155670e-01
    z[3,4,5]  R2421     7.1825966238975525e-02
    z[3,4,5]  R2422     -3.5511177778244019e-01
    z[3,4,5]  R2423     -2.0457766950130463e-01
    z[3,4,5]  R2424     -7.8436665236949921e-02
    z[3,4,5]  R2425     -3.5082376003265381e-01
    z[3,4,5]  R2426     -6.2063324451446533e-01
    z[3,4,5]  R2427     -1.5862299501895905e-01
    z[3,4,5]  R2428     -5.3206694126129150e-01
    z[3,4,5]  R2429     6.7930233478546143e-01
    z[3,4,5]  R2430     2.5022828578948975e-01
    z[3,4,5]  R2431     2.9681313037872314e-01
    z[3,4,5]  R2432     2.6027432084083557e-01
    z[3,4,5]  R2433     2.3415267467498779e-01
    z[3,4,5]  R2434     2.4350734055042267e-01
    z[3,4,5]  R2435     3.1304490403272212e-04
    z[3,4,5]  R2436     -1.4754687249660492e-01
    z[3,4,5]  R2437     -1.8984548747539520e-01
    z[3,4,5]  R2438     4.3392565846443176e-01
    z[3,4,5]  R2439     4.6961772441864014e-01
    z[3,4,5]  R2440     4.2950622737407684e-02
    z[3,4,5]  R2441     2.3239459097385406e-01
    z[3,4,5]  R2442     3.4280958771705627e-01
    z[3,4,5]  R2443     -5.4389089345932007e-01
    z[3,4,5]  R2444     -2.7062374353408813e-01
    z[3,4,5]  R2445     -1.4795990660786629e-02
    z[3,4,5]  R2446     6.6138349473476410e-02
    z[3,4,5]  R2447     1.2924763560295105e-01
    z[3,4,5]  R2448     6.0124790668487549e-01
    z[3,4,5]  R2449     6.1871415376663208e-01
    z[3,4,5]  R2450     2.0373660326004028e-01
    z[3,4,5]  R2451     4.3375995010137558e-02
    z[3,4,5]  R2452     1.8051321804523468e-01
    z[3,4,5]  R2453     -7.3148764669895172e-02
    z[3,4,5]  R2454     -3.7347188591957092e-01
    z[3,4,5]  R2455     6.7983222007751465e-01
    z[3,4,5]  R2456     1.7246770858764648e-01
    z[3,4,5]  R2457     -1.8709598109126091e-02
    z[3,4,5]  R2458     2.1293669939041138e-01
    z[3,4,5]  R2459     2.7812838554382324e-01
    z[3,4,5]  R2460     -3.8344261050224304e-01
    z[3,4,5]  R2461     -2.4632996320724487e-01
    z[3,4,5]  R2462     -4.6027606725692749e-01
    z[3,4,5]  R2463     7.6073859818279743e-03
    z[3,4,5]  R2464     -1.3433896005153656e-01
    z[3,4,5]  R2465     1.5455786883831024e-01
    z[3,4,5]  R2466     -2.7092182636260986e-01
    z[3,4,5]  R2467     7.6671266555786133e-01
    z[3,4,5]  R2468     2.8965758159756660e-02
    z[3,4,5]  R2469     -1.5829353034496307e-01
    z[3,4,5]  R2470     -4.2344415187835693e-01
    z[3,4,5]  R2471     -3.0616271495819092e-01
    z[3,4,5]  R2472     -5.2750091999769211e-02
    z[3,4,5]  R2473     -8.3749219775199890e-02
    z[3,4,5]  R2474     3.5495933890342712e-01
    z[3,4,5]  R2475     2.2453854978084564e-01
    z[3,4,5]  R2476     1.8640884757041931e-01
    z[3,4,5]  R2477     -7.0749111473560333e-02
    z[3,4,5]  R2478     2.3678185045719147e-01
    z[3,4,5]  R2479     3.0017700791358948e-01
    z[3,4,5]  R2480     4.8381257057189941e-01
    z[3,4,5]  R2481     3.3239677548408508e-01
    z[3,4,5]  R2482     1.4385271072387695e-01
    z[3,4,5]  R2483     2.0954367518424988e-01
    z[3,4,5]  R2484     2.6355904340744019e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2398     -1
    z[3,4,6]  R2399     1
    z[3,4,6]  R2400     -1.5106844902038574e-01
    z[3,4,6]  R2401     -4.0926668792963028e-02
    z[3,4,6]  R2402     2.4069119989871979e-01
    z[3,4,6]  R2403     -1.2605784833431244e-01
    z[3,4,6]  R2404     -0.855800211429596
    z[3,4,6]  R2405     -8.3539414405822754e-01
    z[3,4,6]  R2406     -7.7902823686599731e-01
    z[3,4,6]  R2407     -2.4133461713790894e-01
    z[3,4,6]  R2408     1.3475725427269936e-02
    z[3,4,6]  R2409     1.5930871665477753e-01
    z[3,4,6]  R2410     -1.2160740792751312e-01
    z[3,4,6]  R2411     5.5052947998046875e-01
    z[3,4,6]  R2412     4.1892027854919434e-01
    z[3,4,6]  R2413     -2.7657487988471985e-01
    z[3,4,6]  R2414     4.7432950139045715e-01
    z[3,4,6]  R2415     1.1000140011310577e-01
    z[3,4,6]  R2416     -1.4250591397285461e-01
    z[3,4,6]  R2417     -3.6658516526222229e-01
    z[3,4,6]  R2418     -8.4278509020805359e-03
    z[3,4,6]  R2419     1.2105721980333328e-01
    z[3,4,6]  R2420     1.3495326042175293e-01
    z[3,4,6]  R2421     2.2954124957323074e-02
    z[3,4,6]  R2422     -1.2433709204196930e-01
    z[3,4,6]  R2423     -7.0504434406757355e-02
    z[3,4,6]  R2424     1.5510024130344391e-01
    z[3,4,6]  R2425     5.9778308495879173e-03
    z[3,4,6]  R2426     2.5904938578605652e-02
    z[3,4,6]  R2427     3.6149981617927551e-01
    z[3,4,6]  R2428     -3.0157101154327393e-01
    z[3,4,6]  R2429     -1.7899684607982635e-01
    z[3,4,6]  R2430     -3.8635396957397461e-01
    z[3,4,6]  R2431     -2.5926964357495308e-02
    z[3,4,6]  R2432     -1.3939090073108673e-01
    z[3,4,6]  R2433     -1.5291011333465576e-01
    z[3,4,6]  R2434     3.7921956181526184e-01
    z[3,4,6]  R2435     1.2522467970848083e-01
    z[3,4,6]  R2436     0.085883229970932
    z[3,4,6]  R2437     0.446367472410202
    z[3,4,6]  R2438     9.8310850560665131e-02
    z[3,4,6]  R2439     5.5508965253829956e-01
    z[3,4,6]  R2440     4.5687967538833618e-01
    z[3,4,6]  R2441     4.9932867288589478e-01
    z[3,4,6]  R2442     0.0560506135225296
    z[3,4,6]  R2443     2.1495828032493591e-01
    z[3,4,6]  R2444     -3.6913719773292542e-01
    z[3,4,6]  R2445     5.1739192008972168e-01
    z[3,4,6]  R2446     0.447817862033844
    z[3,4,6]  R2447     -0.235219344496727
    z[3,4,6]  R2448     4.0423431992530823e-01
    z[3,4,6]  R2449     3.9935973286628723e-01
    z[3,4,6]  R2450     -7.1068987250328064e-02
    z[3,4,6]  R2451     -1.8020041286945343e-02
    z[3,4,6]  R2452     1.3029550015926361e-01
    z[3,4,6]  R2453     2.6778453588485718e-01
    z[3,4,6]  R2454     2.6788255572319031e-01
    z[3,4,6]  R2455     2.2394201159477234e-01
    z[3,4,6]  R2456     -8.8726624846458435e-02
    z[3,4,6]  R2457     2.9218995571136475e-01
    z[3,4,6]  R2458     2.7505829930305481e-01
    z[3,4,6]  R2459     2.0124079287052155e-01
    z[3,4,6]  R2460     2.9716029763221741e-01
    z[3,4,6]  R2461     -3.8691893219947815e-01
    z[3,4,6]  R2462     -3.4699544310569763e-01
    z[3,4,6]  R2463     9.0068168938159943e-02
    z[3,4,6]  R2464     -3.7443239241838455e-02
    z[3,4,6]  R2465     -0.259909987449646
    z[3,4,6]  R2466     -5.0366961956024170e-01
    z[3,4,6]  R2467     4.6736735850572586e-02
    z[3,4,6]  R2468     -1.0265648597851396e-03
    z[3,4,6]  R2469     -1.0762225091457367e-01
    z[3,4,6]  R2470     0.0696331113576889
    z[3,4,6]  R2471     3.1715276837348938e-01
    z[3,4,6]  R2472     2.2725264728069305e-01
    z[3,4,6]  R2473     -4.8621557652950287e-02
    z[3,4,6]  R2474     5.8099544048309326e-01
    z[3,4,6]  R2475     7.2574146091938019e-02
    z[3,4,6]  R2476     -2.1973720192909241e-01
    z[3,4,6]  R2477     -4.7050568461418152e-01
    z[3,4,6]  R2478     -7.0633783936500549e-02
    z[3,4,6]  R2479     0.336056649684906
    z[3,4,6]  R2480     -3.7884730100631714e-01
    z[3,4,6]  R2481     3.8792282342910767e-01
    z[3,4,6]  R2482     4.8093879222869873e-01
    z[3,4,6]  R2483     -2.1727073192596436e-01
    z[3,4,6]  R2484     2.2801366448402405e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2485     -1
    z[4,3,0]  R2486     1
    z[4,3,0]  R2499     -4.4537249207496643e-01
    z[4,3,0]  R2500     -5.1074630022048950e-01
    z[4,3,0]  R2501     -5.2198320627212524e-01
    z[4,3,0]  R2502     1.4921683818101883e-02
    z[4,3,0]  R2503     -9.6592712402343750e-01
    z[4,3,0]  R2504     8.0585852265357971e-02
    z[4,3,0]  R2505     -1.7927173525094986e-02
    z[4,3,0]  R2506     3.2609567046165466e-02
    z[4,3,0]  R2507     -2.4398061633110046e-01
    z[4,3,0]  R2508     -1.0867832228541374e-02
    z[4,3,0]  R2509     0.331209659576416
    z[4,3,0]  R2510     3.7573602795600891e-01
    z[4,3,0]  R2511     4.9842461943626404e-01
    z[4,3,0]  R2512     3.3839711546897888e-01
    z[4,3,0]  R2513     3.7496492266654968e-01
    z[4,3,0]  R2514     3.4600558876991272e-01
    z[4,3,0]  R2515     2.5181302428245544e-01
    z[4,3,0]  R2516     1.5387284755706787e-01
    z[4,3,0]  R2517     3.2433813810348511e-01
    z[4,3,0]  R2518     2.0987780392169952e-01
    z[4,3,0]  R2519     2.4177080392837524e-01
    z[4,3,0]  R2520     -1.7149411141872406e-01
    z[4,3,0]  R2521     -1.1276394070591778e-04
    z[4,3,0]  R2522     0.299360454082489
    z[4,3,0]  R2523     1.8625383079051971e-01
    z[4,3,0]  R2524     -3.6589086055755615e-02
    z[4,3,0]  R2525     0.0693727433681488
    z[4,3,0]  R2526     1.3377635739743710e-02
    z[4,3,0]  R2527     -0.705590546131134
    z[4,3,0]  R2528     2.9925478622317314e-02
    z[4,3,0]  R2529     5.5139489471912384e-02
    z[4,3,0]  R2530     6.8879328668117523e-02
    z[4,3,0]  R2531     -3.4376001358032227e-01
    z[4,3,0]  R2532     6.8608321249485016e-02
    z[4,3,0]  R2533     -9.5315627753734589e-02
    z[4,3,0]  R2534     4.1588321328163147e-01
    z[4,3,0]  R2535     1.1865523457527161e-01
    z[4,3,0]  R2536     1.0987310111522675e-01
    z[4,3,0]  R2537     1.7032913863658905e-01
    z[4,3,0]  R2538     7.7343232929706573e-02
    z[4,3,0]  R2539     2.4044688045978546e-01
    z[4,3,0]  R2540     4.9973991513252258e-01
    z[4,3,0]  R2541     -2.0393800735473633e-01
    z[4,3,0]  R2542     0.332888126373291
    z[4,3,0]  R2543     -0.397519052028656
    z[4,3,0]  R2544     1.4147533476352692e-01
    z[4,3,0]  R2545     3.6231091618537903e-01
    z[4,3,0]  R2546     -9.3511618673801422e-02
    z[4,3,0]  R2547     1.5615861117839813e-01
    z[4,3,0]  R2548     -1.8030744791030884e-01
    z[4,3,0]  R2549     -2.3016983270645142e-01
    z[4,3,0]  R2550     -2.6206314563751221e-01
    z[4,3,0]  R2551     -3.4449473023414612e-01
    z[4,3,0]  R2552     -2.2381576895713806e-01
    z[4,3,0]  R2553     3.4233424067497253e-01
    z[4,3,0]  R2554     1.2595053017139435e-01
    z[4,3,0]  R2555     3.8731002807617188e-01
    z[4,3,0]  R2556     -4.0880435705184937e-01
    z[4,3,0]  R2557     1.0537336766719818e-01
    z[4,3,0]  R2558     -3.6036467552185059e-01
    z[4,3,0]  R2559     -1.4476144686341286e-02
    z[4,3,0]  R2560     -2.9991042613983154e-01
    z[4,3,0]  R2561     -5.9298592805862427e-01
    z[4,3,0]  R2562     5.9217196702957153e-01
    z[4,3,0]  R2563     5.6940101087093353e-02
    z[4,3,0]  R2564     -5.6806594133377075e-01
    z[4,3,0]  R2565     -4.8820680379867554e-01
    z[4,3,0]  R2566     -1.0065668821334839e-01
    z[4,3,0]  R2567     -6.6662663221359253e-01
    z[4,3,0]  R2568     -5.2976123988628387e-02
    z[4,3,0]  R2569     8.1685623154044151e-03
    z[4,3,0]  R2570     1.7718593776226044e-01
    z[4,3,0]  R2571     4.3916791677474976e-01
    z[4,3,0]  R2572     3.4565997123718262e-01
    z[4,3,0]  R2573     4.5147308707237244e-01
    z[4,3,0]  R2574     -0.610199511051178
    z[4,3,0]  R2575     -6.9077622890472412e-01
    z[4,3,0]  R2576     -3.8901382684707642e-01
    z[4,3,0]  R2577     -2.2505044937133789e-01
    z[4,3,0]  R2578     -3.8937729597091675e-01
    z[4,3,0]  R2579     2.6735246181488037e-01
    z[4,3,0]  R2580     -6.1612665653228760e-01
    z[4,3,0]  R2581     -0.665919303894043
    z[4,3,0]  R2582     -5.9971648454666138e-01
    z[4,3,0]  R2583     -5.4659348726272583e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2487     -1
    z[4,3,1]  R2488     1
    z[4,3,1]  R2499     0.665277361869812
    z[4,3,1]  R2500     5.7158994674682617e-01
    z[4,3,1]  R2501     4.0337088704109192e-01
    z[4,3,1]  R2502     7.5647455453872681e-01
    z[4,3,1]  R2503     7.8719764947891235e-02
    z[4,3,1]  R2504     -6.6353100538253784e-01
    z[4,3,1]  R2505     -5.6738960742950439e-01
    z[4,3,1]  R2506     -0.539656400680542
    z[4,3,1]  R2507     -7.3659688234329224e-01
    z[4,3,1]  R2508     2.8826889395713806e-01
    z[4,3,1]  R2509     -7.7573865652084351e-01
    z[4,3,1]  R2510     -7.6019245386123657e-01
    z[4,3,1]  R2511     -6.0532516241073608e-01
    z[4,3,1]  R2512     -7.0515912771224976e-01
    z[4,3,1]  R2513     -6.2775951623916626e-01
    z[4,3,1]  R2514     -6.5205973386764526e-01
    z[4,3,1]  R2515     -7.5500094890594482e-01
    z[4,3,1]  R2516     -0.685711681842804
    z[4,3,1]  R2517     -5.7793557643890381e-01
    z[4,3,1]  R2518     -6.6598445177078247e-01
    z[4,3,1]  R2519     -6.6299033164978027e-01
    z[4,3,1]  R2520     2.1881558932363987e-03
    z[4,3,1]  R2521     1.9273987039923668e-02
    z[4,3,1]  R2522     5.7013678550720215e-01
    z[4,3,1]  R2523     6.1896014213562012e-01
    z[4,3,1]  R2524     -7.8813350200653076e-01
    z[4,3,1]  R2525     -6.3816928863525391e-01
    z[4,3,1]  R2526     -5.9123784303665161e-01
    z[4,3,1]  R2527     6.3668894767761230e-01
    z[4,3,1]  R2528     -2.9680398106575012e-01
    z[4,3,1]  R2529     -3.4536263346672058e-01
    z[4,3,1]  R2530     -3.0272287130355835e-01
    z[4,3,1]  R2531     6.2705171108245850e-01
    z[4,3,1]  R2532     5.4102611541748047e-01
    z[4,3,1]  R2533     7.6169586181640625e-01
    z[4,3,1]  R2534     -4.5111289620399475e-01
    z[4,3,1]  R2535     -0.439800888299942
    z[4,3,1]  R2536     -3.8439545035362244e-01
    z[4,3,1]  R2537     -3.6523753404617310e-01
    z[4,3,1]  R2538     -4.0704101324081421e-01
    z[4,3,1]  R2539     -2.5016698241233826e-01
    z[4,3,1]  R2540     7.4719732999801636e-01
    z[4,3,1]  R2541     6.8427371978759766e-01
    z[4,3,1]  R2542     6.9754534959793091e-01
    z[4,3,1]  R2543     1.9880345463752747e-01
    z[4,3,1]  R2544     0.857233464717865
    z[4,3,1]  R2545     7.9025137424468994e-01
    z[4,3,1]  R2546     8.0379545688629150e-01
    z[4,3,1]  R2547     6.9972038269042969e-01
    z[4,3,1]  R2548     8.0500149726867676e-01
    z[4,3,1]  R2549     7.3723131418228149e-01
    z[4,3,1]  R2550     6.5980720520019531e-01
    z[4,3,1]  R2551     5.4039853811264038e-01
    z[4,3,1]  R2552     6.3432049751281738e-01
    z[4,3,1]  R2553     3.8795873522758484e-01
    z[4,3,1]  R2554     -6.5281128883361816e-01
    z[4,3,1]  R2555     -4.6596240997314453e-01
    z[4,3,1]  R2556     8.1147712469100952e-01
    z[4,3,1]  R2557     7.8923958539962769e-01
    z[4,3,1]  R2558     4.0587291121482849e-01
    z[4,3,1]  R2559     7.8663498163223267e-01
    z[4,3,1]  R2560     4.4646963477134705e-01
    z[4,3,1]  R2561     1.2665164470672607e-01
    z[4,3,1]  R2562     5.2032095193862915e-01
    z[4,3,1]  R2563     2.4986878037452698e-01
    z[4,3,1]  R2564     4.8440101742744446e-01
    z[4,3,1]  R2565     6.6852509975433350e-01
    z[4,3,1]  R2566     6.3663446903228760e-01
    z[4,3,1]  R2567     4.4251322746276855e-01
    z[4,3,1]  R2568     8.6939907073974609e-01
    z[4,3,1]  R2569     6.1848264932632446e-01
    z[4,3,1]  R2570     3.2343354821205139e-01
    z[4,3,1]  R2571     5.4146373271942139e-01
    z[4,3,1]  R2572     1.8972527980804443e-01
    z[4,3,1]  R2573     4.1707709431648254e-01
    z[4,3,1]  R2574     4.7122615575790405e-01
    z[4,3,1]  R2575     6.4674860239028931e-01
    z[4,3,1]  R2576     7.6113170385360718e-01
    z[4,3,1]  R2577     4.8126682639122009e-01
    z[4,3,1]  R2578     4.3018519878387451e-01
    z[4,3,1]  R2579     2.5084331631660461e-01
    z[4,3,1]  R2580     -3.1143131852149963e-01
    z[4,3,1]  R2581     -1.7610348761081696e-01
    z[4,3,1]  R2582     -2.7668842673301697e-01
    z[4,3,1]  R2583     -3.7183105945587158e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2489     -1
    z[4,3,2]  R2490     1
    z[4,3,2]  R2499     -3.3246603608131409e-01
    z[4,3,2]  R2500     -3.3024686574935913e-01
    z[4,3,2]  R2501     -3.8213226199150085e-01
    z[4,3,2]  R2502     -5.9999954700469971e-01
    z[4,3,2]  R2503     -1.8448592722415924e-01
    z[4,3,2]  R2504     4.5519477128982544e-01
    z[4,3,2]  R2505     -1.3045579195022583e-01
    z[4,3,2]  R2506     -2.9634529352188110e-01
    z[4,3,2]  R2507     4.5163431763648987e-01
    z[4,3,2]  R2508     0.0443992018699646
    z[4,3,2]  R2509     4.3069524690508842e-03
    z[4,3,2]  R2510     -2.0378093421459198e-01
    z[4,3,2]  R2511     -2.0583665370941162e-01
    z[4,3,2]  R2512     -0.601309597492218
    z[4,3,2]  R2513     7.6408926397562027e-03
    z[4,3,2]  R2514     -2.1865795552730560e-01
    z[4,3,2]  R2515     -5.1944029331207275e-01
    z[4,3,2]  R2516     2.9603847861289978e-01
    z[4,3,2]  R2517     -1.8319685757160187e-01
    z[4,3,2]  R2518     5.0144165754318237e-01
    z[4,3,2]  R2519     3.1911796331405640e-01
    z[4,3,2]  R2520     -5.3569239377975464e-01
    z[4,3,2]  R2521     -5.2974373102188110e-01
    z[4,3,2]  R2522     3.3966198563575745e-01
    z[4,3,2]  R2523     6.2364935874938965e-01
    z[4,3,2]  R2524     2.9155045747756958e-01
    z[4,3,2]  R2525     -4.2261886596679688e-01
    z[4,3,2]  R2526     0.0226475540548563
    z[4,3,2]  R2527     -7.3616698384284973e-02
    z[4,3,2]  R2528     0.351779967546463
    z[4,3,2]  R2529     -1.2747351825237274e-01
    z[4,3,2]  R2530     -1.1474695056676865e-01
    z[4,3,2]  R2531     3.4420590847730637e-02
    z[4,3,2]  R2532     2.1619459986686707e-01
    z[4,3,2]  R2533     2.0916143059730530e-01
    z[4,3,2]  R2534     6.6711580753326416e-01
    z[4,3,2]  R2535     1.9830379635095596e-02
    z[4,3,2]  R2536     4.0915283560752869e-01
    z[4,3,2]  R2537     5.5210381746292114e-02
    z[4,3,2]  R2538     -1.1304409801959991e-01
    z[4,3,2]  R2539     -6.1652410030364990e-01
    z[4,3,2]  R2540     -1.5276296436786652e-01
    z[4,3,2]  R2541     1.4430822432041168e-01
    z[4,3,2]  R2542     -2.7639037370681763e-01
    z[4,3,2]  R2543     -3.8856777548789978e-01
    z[4,3,2]  R2544     2.6850545406341553e-01
    z[4,3,2]  R2545     -1.3540776073932648e-01
    z[4,3,2]  R2546     -1.0470170527696609e-01
    z[4,3,2]  R2547     -3.6883455514907837e-01
    z[4,3,2]  R2548     -1.7168706655502319e-01
    z[4,3,2]  R2549     4.8716634511947632e-01
    z[4,3,2]  R2550     1.8579114973545074e-01
    z[4,3,2]  R2551     -4.8725920915603638e-01
    z[4,3,2]  R2552     -2.5702643394470215e-01
    z[4,3,2]  R2553     2.5466141104698181e-01
    z[4,3,2]  R2554     -3.2065615057945251e-01
    z[4,3,2]  R2555     3.8088664412498474e-01
    z[4,3,2]  R2556     -5.6624421849846840e-03
    z[4,3,2]  R2557     -2.9873631894588470e-02
    z[4,3,2]  R2558     -6.1045056581497192e-01
    z[4,3,2]  R2559     -2.4921372532844543e-01
    z[4,3,2]  R2560     -4.9589291214942932e-01
    z[4,3,2]  R2561     3.9476905949413776e-03
    z[4,3,2]  R2562     3.8990476727485657e-01
    z[4,3,2]  R2563     4.9159295856952667e-02
    z[4,3,2]  R2564     -4.7137516736984253e-01
    z[4,3,2]  R2565     7.6161310076713562e-02
    z[4,3,2]  R2566     3.3059367537498474e-01
    z[4,3,2]  R2567     -1.8056605011224747e-02
    z[4,3,2]  R2568     8.5890352725982666e-02
    z[4,3,2]  R2569     -1.1896006017923355e-01
    z[4,3,2]  R2570     -3.1947073340415955e-01
    z[4,3,2]  R2571     4.3478971719741821e-01
    z[4,3,2]  R2572     -1.6211281716823578e-01
    z[4,3,2]  R2573     1.5092931687831879e-01
    z[4,3,2]  R2574     -4.5245864987373352e-01
    z[4,3,2]  R2575     -1.4433425664901733e-01
    z[4,3,2]  R2576     3.1044140458106995e-01
    z[4,3,2]  R2577     -2.6153931021690369e-01
    z[4,3,2]  R2578     -0.280733197927475
    z[4,3,2]  R2579     -1.3410811126232147e-01
    z[4,3,2]  R2580     5.7834321260452271e-01
    z[4,3,2]  R2581     3.7822961807250977e-01
    z[4,3,2]  R2582     4.3421438336372375e-01
    z[4,3,2]  R2583     4.9262502789497375e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2491     -1
    z[4,3,3]  R2492     1
    z[4,3,3]  R2499     6.1623834073543549e-02
    z[4,3,3]  R2500     1.2031611055135727e-01
    z[4,3,3]  R2501     -1.0835071653127670e-01
    z[4,3,3]  R2502     1.6698566079139709e-01
    z[4,3,3]  R2503     -8.0087609589099884e-02
    z[4,3,3]  R2504     5.4327648133039474e-02
    z[4,3,3]  R2505     -5.7724362611770630e-01
    z[4,3,3]  R2506     1.4700695872306824e-01
    z[4,3,3]  R2507     1.0272392630577087e-01
    z[4,3,3]  R2508     8.5961920022964478e-01
    z[4,3,3]  R2509     -2.4001386761665344e-01
    z[4,3,3]  R2510     1.8896806240081787e-01
    z[4,3,3]  R2511     -0.388874351978302
    z[4,3,3]  R2512     1.1385331302881241e-01
    z[4,3,3]  R2513     3.0618848279118538e-02
    z[4,3,3]  R2514     5.8276718854904175e-01
    z[4,3,3]  R2515     -4.3951552361249924e-02
    z[4,3,3]  R2516     3.5840559005737305e-01
    z[4,3,3]  R2517     1.5175801515579224e-01
    z[4,3,3]  R2518     1.3548615574836731e-01
    z[4,3,3]  R2519     -7.3759861290454865e-02
    z[4,3,3]  R2520     -6.4899915456771851e-01
    z[4,3,3]  R2521     -3.1279709935188293e-01
    z[4,3,3]  R2522     -6.1535632610321045e-01
    z[4,3,3]  R2523     -2.5307220220565796e-01
    z[4,3,3]  R2524     1.1979837715625763e-01
    z[4,3,3]  R2525     -5.2399146556854248e-01
    z[4,3,3]  R2526     6.6634345054626465e-01
    z[4,3,3]  R2527     -1.1344969272613525e-01
    z[4,3,3]  R2528     -8.2266800105571747e-02
    z[4,3,3]  R2529     -0.0785977765917778
    z[4,3,3]  R2530     -4.3732246756553650e-01
    z[4,3,3]  R2531     -4.9222588539123535e-01
    z[4,3,3]  R2532     -0.789358377456665
    z[4,3,3]  R2533     -5.1896160840988159e-01
    z[4,3,3]  R2534     -1.4762806892395020e-01
    z[4,3,3]  R2535     -7.1839645504951477e-02
    z[4,3,3]  R2536     -5.1226228475570679e-01
    z[4,3,3]  R2537     2.3346434533596039e-01
    z[4,3,3]  R2538     -1.5381909906864166e-01
    z[4,3,3]  R2539     -1.4028598368167877e-01
    z[4,3,3]  R2540     -6.1548583209514618e-02
    z[4,3,3]  R2541     -3.1095218658447266e-01
    z[4,3,3]  R2542     -3.7301453948020935e-01
    z[4,3,3]  R2543     -4.6497520804405212e-01
    z[4,3,3]  R2544     -3.3105546236038208e-01
    z[4,3,3]  R2545     -4.6913620829582214e-01
    z[4,3,3]  R2546     -4.1991695761680603e-01
    z[4,3,3]  R2547     -5.5058246850967407e-01
    z[4,3,3]  R2548     5.0946021080017090e-01
    z[4,3,3]  R2549     -6.6334336996078491e-02
    z[4,3,3]  R2550     2.7412867546081543e-01
    z[4,3,3]  R2551     4.4249475002288818e-01
    z[4,3,3]  R2552     3.2248049974441528e-01
    z[4,3,3]  R2553     -4.0056106448173523e-01
    z[4,3,3]  R2554     4.4133597612380981e-01
    z[4,3,3]  R2555     -0.0772356316447258
    z[4,3,3]  R2556     2.7450013160705566e-01
    z[4,3,3]  R2557     -5.1207160949707031e-01
    z[4,3,3]  R2558     -3.5299211740493774e-01
    z[4,3,3]  R2559     -5.8170523494482040e-02
    z[4,3,3]  R2560     -0.651406466960907
    z[4,3,3]  R2561     -5.9365576505661011e-01
    z[4,3,3]  R2562     -0.0291308481246233
    z[4,3,3]  R2563     -5.1408547163009644e-01
    z[4,3,3]  R2564     -5.0025876611471176e-02
    z[4,3,3]  R2565     5.7337163016200066e-03
    z[4,3,3]  R2566     -5.2307796478271484e-01
    z[4,3,3]  R2567     8.1351123750209808e-02
    z[4,3,3]  R2568     -1.3375589251518250e-01
    z[4,3,3]  R2569     -3.2607337832450867e-01
    z[4,3,3]  R2570     -0.739935040473938
    z[4,3,3]  R2571     -2.4455970525741577e-01
    z[4,3,3]  R2572     -5.2082246541976929e-01
    z[4,3,3]  R2573     -9.2234991490840912e-02
    z[4,3,3]  R2574     -3.7684386968612671e-01
    z[4,3,3]  R2575     2.8232610225677490e-01
    z[4,3,3]  R2576     3.2263547182083130e-01
    z[4,3,3]  R2577     -6.4435219764709473e-01
    z[4,3,3]  R2578     -3.7938350439071655e-01
    z[4,3,3]  R2579     -5.5153644084930420e-01
    z[4,3,3]  R2580     -3.8196936249732971e-01
    z[4,3,3]  R2581     -4.2192295193672180e-01
    z[4,3,3]  R2582     -3.7358319759368896e-01
    z[4,3,3]  R2583     -4.0055724978446960e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2493     -1
    z[4,3,4]  R2494     1
    z[4,3,4]  R2499     9.6880055963993073e-02
    z[4,3,4]  R2500     2.8017762303352356e-01
    z[4,3,4]  R2501     -2.7349710464477539e-01
    z[4,3,4]  R2502     1.7739698290824890e-01
    z[4,3,4]  R2503     -2.9830446466803551e-02
    z[4,3,4]  R2504     5.0163465738296509e-01
    z[4,3,4]  R2505     -2.0905299112200737e-02
    z[4,3,4]  R2506     9.0793631970882416e-02
    z[4,3,4]  R2507     -4.2723834514617920e-01
    z[4,3,4]  R2508     -3.7313145399093628e-01
    z[4,3,4]  R2509     -2.1621921658515930e-01
    z[4,3,4]  R2510     -9.6813194453716278e-02
    z[4,3,4]  R2511     3.7031877040863037e-01
    z[4,3,4]  R2512     6.5757364034652710e-02
    z[4,3,4]  R2513     -2.7775904163718224e-02
    z[4,3,4]  R2514     -1.0947525501251221e-01
    z[4,3,4]  R2515     -1.0854104906320572e-01
    z[4,3,4]  R2516     -2.5228586792945862e-01
    z[4,3,4]  R2517     -6.6569441556930542e-01
    z[4,3,4]  R2518     -1.9893574714660645e-01
    z[4,3,4]  R2519     1.3082090020179749e-01
    z[4,3,4]  R2520     3.8038212805986404e-02
    z[4,3,4]  R2521     -6.0758739709854126e-01
    z[4,3,4]  R2522     -1.3361072167754173e-02
    z[4,3,4]  R2523     8.8092230260372162e-02
    z[4,3,4]  R2524     4.0810516476631165e-01
    z[4,3,4]  R2525     -8.2651257514953613e-02
    z[4,3,4]  R2526     2.2359290719032288e-01
    z[4,3,4]  R2527     1.9921872019767761e-01
    z[4,3,4]  R2528     -2.0305125415325165e-01
    z[4,3,4]  R2529     -3.4954020380973816e-01
    z[4,3,4]  R2530     7.8294515609741211e-02
    z[4,3,4]  R2531     3.9334109425544739e-01
    z[4,3,4]  R2532     -0.0928015261888504
    z[4,3,4]  R2533     2.6882079243659973e-01
    z[4,3,4]  R2534     6.7703694105148315e-02
    z[4,3,4]  R2535     -0.374188095331192
    z[4,3,4]  R2536     -1.1617810279130936e-01
    z[4,3,4]  R2537     -4.3234923481941223e-01
    z[4,3,4]  R2538     2.4462303519248962e-01
    z[4,3,4]  R2539     2.2121407091617584e-01
    z[4,3,4]  R2540     7.4796296656131744e-02
    z[4,3,4]  R2541     -7.2107151150703430e-02
    z[4,3,4]  R2542     -1.8771593272686005e-01
    z[4,3,4]  R2543     1.6012816131114960e-01
    z[4,3,4]  R2544     3.7444159388542175e-02
    z[4,3,4]  R2545     -1.1119368486106396e-02
    z[4,3,4]  R2546     1.2771655619144440e-01
    z[4,3,4]  R2547     1.7380365170538425e-03
    z[4,3,4]  R2548     -1.5074522234499454e-02
    z[4,3,4]  R2549     1.9664084911346436e-01
    z[4,3,4]  R2550     2.1345909684896469e-02
    z[4,3,4]  R2551     -1.5040965750813484e-02
    z[4,3,4]  R2552     5.8716509491205215e-02
    z[4,3,4]  R2553     -1.1619853228330612e-01
    z[4,3,4]  R2554     -2.2021043300628662e-01
    z[4,3,4]  R2555     -6.2694478034973145e-01
    z[4,3,4]  R2556     -1.0876150429248810e-01
    z[4,3,4]  R2557     1.5709446370601654e-01
    z[4,3,4]  R2558     -7.1048364043235779e-02
    z[4,3,4]  R2559     5.4756116867065430e-01
    z[4,3,4]  R2560     1.0645416378974915e-01
    z[4,3,4]  R2561     2.1118494868278503e-01
    z[4,3,4]  R2562     -1.6663597524166107e-01
    z[4,3,4]  R2563     3.7277019023895264e-01
    z[4,3,4]  R2564     -8.5882298648357391e-02
    z[4,3,4]  R2565     7.4555687606334686e-02
    z[4,3,4]  R2566     2.8460854291915894e-01
    z[4,3,4]  R2567     1.0403080284595490e-01
    z[4,3,4]  R2568     0.081064872443676
    z[4,3,4]  R2569     4.7856429219245911e-01
    z[4,3,4]  R2570     9.7546920180320740e-02
    z[4,3,4]  R2571     -4.3939024209976196e-01
    z[4,3,4]  R2572     1.4860205352306366e-01
    z[4,3,4]  R2573     2.2053673863410950e-01
    z[4,3,4]  R2574     -1.1096361279487610e-01
    z[4,3,4]  R2575     -4.2400330305099487e-02
    z[4,3,4]  R2576     1.3898704946041107e-01
    z[4,3,4]  R2577     3.9633655548095703e-01
    z[4,3,4]  R2578     4.7889527678489685e-01
    z[4,3,4]  R2579     1.7635495960712433e-01
    z[4,3,4]  R2580     7.3480255901813507e-02
    z[4,3,4]  R2581     3.4458291530609131e-01
    z[4,3,4]  R2582     3.3864155411720276e-01
    z[4,3,4]  R2583     2.0493526756763458e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2495     -1
    z[4,3,5]  R2496     1
    z[4,3,5]  R2499     -3.8344261050224304e-01
    z[4,3,5]  R2500     -2.4632996320724487e-01
    z[4,3,5]  R2501     -4.6027606725692749e-01
    z[4,3,5]  R2502     7.6073859818279743e-03
    z[4,3,5]  R2503     -1.3433896005153656e-01
    z[4,3,5]  R2504     1.5455786883831024e-01
    z[4,3,5]  R2505     -2.7092182636260986e-01
    z[4,3,5]  R2506     7.6671266555786133e-01
    z[4,3,5]  R2507     2.8965758159756660e-02
    z[4,3,5]  R2508     -1.5829353034496307e-01
    z[4,3,5]  R2509     -4.2344415187835693e-01
    z[4,3,5]  R2510     -3.0616271495819092e-01
    z[4,3,5]  R2511     -5.2750091999769211e-02
    z[4,3,5]  R2512     -8.3749219775199890e-02
    z[4,3,5]  R2513     3.5495933890342712e-01
    z[4,3,5]  R2514     2.2453854978084564e-01
    z[4,3,5]  R2515     1.8640884757041931e-01
    z[4,3,5]  R2516     -7.0749111473560333e-02
    z[4,3,5]  R2517     2.3678185045719147e-01
    z[4,3,5]  R2518     3.0017700791358948e-01
    z[4,3,5]  R2519     4.8381257057189941e-01
    z[4,3,5]  R2520     3.3239677548408508e-01
    z[4,3,5]  R2521     1.4385271072387695e-01
    z[4,3,5]  R2522     2.0954367518424988e-01
    z[4,3,5]  R2523     2.6355904340744019e-01
    z[4,3,5]  R2524     2.9796305298805237e-01
    z[4,3,5]  R2525     3.5531315207481384e-01
    z[4,3,5]  R2526     3.1273981928825378e-01
    z[4,3,5]  R2527     1.5132869780063629e-01
    z[4,3,5]  R2528     8.2891270518302917e-02
    z[4,3,5]  R2529     1.8760459125041962e-01
    z[4,3,5]  R2530     -2.9356718063354492e-01
    z[4,3,5]  R2531     1.7945627868175507e-01
    z[4,3,5]  R2532     1.5480084717273712e-01
    z[4,3,5]  R2533     -4.5567336492240429e-03
    z[4,3,5]  R2534     -3.7057882547378540e-01
    z[4,3,5]  R2535     -5.8638083934783936e-01
    z[4,3,5]  R2536     -4.7048667073249817e-01
    z[4,3,5]  R2537     -7.1876019239425659e-01
    z[4,3,5]  R2538     -7.1208667755126953e-01
    z[4,3,5]  R2539     -6.4713490009307861e-01
    z[4,3,5]  R2540     3.7273174524307251e-01
    z[4,3,5]  R2541     -4.8278215527534485e-01
    z[4,3,5]  R2542     -3.8958466053009033e-01
    z[4,3,5]  R2543     -6.2846875190734863e-01
    z[4,3,5]  R2544     -2.0935179293155670e-01
    z[4,3,5]  R2545     7.1825966238975525e-02
    z[4,3,5]  R2546     -3.5511177778244019e-01
    z[4,3,5]  R2547     -2.0457766950130463e-01
    z[4,3,5]  R2548     -7.8436665236949921e-02
    z[4,3,5]  R2549     -3.5082376003265381e-01
    z[4,3,5]  R2550     -6.2063324451446533e-01
    z[4,3,5]  R2551     -1.5862299501895905e-01
    z[4,3,5]  R2552     -5.3206694126129150e-01
    z[4,3,5]  R2553     6.7930233478546143e-01
    z[4,3,5]  R2554     2.5022828578948975e-01
    z[4,3,5]  R2555     2.9681313037872314e-01
    z[4,3,5]  R2556     2.6027432084083557e-01
    z[4,3,5]  R2557     2.3415267467498779e-01
    z[4,3,5]  R2558     2.4350734055042267e-01
    z[4,3,5]  R2559     3.1304490403272212e-04
    z[4,3,5]  R2560     -1.4754687249660492e-01
    z[4,3,5]  R2561     -1.8984548747539520e-01
    z[4,3,5]  R2562     4.3392565846443176e-01
    z[4,3,5]  R2563     4.6961772441864014e-01
    z[4,3,5]  R2564     4.2950622737407684e-02
    z[4,3,5]  R2565     2.3239459097385406e-01
    z[4,3,5]  R2566     3.4280958771705627e-01
    z[4,3,5]  R2567     -5.4389089345932007e-01
    z[4,3,5]  R2568     -2.7062374353408813e-01
    z[4,3,5]  R2569     -1.4795990660786629e-02
    z[4,3,5]  R2570     6.6138349473476410e-02
    z[4,3,5]  R2571     1.2924763560295105e-01
    z[4,3,5]  R2572     6.0124790668487549e-01
    z[4,3,5]  R2573     6.1871415376663208e-01
    z[4,3,5]  R2574     2.0373660326004028e-01
    z[4,3,5]  R2575     4.3375995010137558e-02
    z[4,3,5]  R2576     1.8051321804523468e-01
    z[4,3,5]  R2577     -7.3148764669895172e-02
    z[4,3,5]  R2578     -3.7347188591957092e-01
    z[4,3,5]  R2579     6.7983222007751465e-01
    z[4,3,5]  R2580     1.7246770858764648e-01
    z[4,3,5]  R2581     -1.8709598109126091e-02
    z[4,3,5]  R2582     2.1293669939041138e-01
    z[4,3,5]  R2583     2.7812838554382324e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2497     -1
    z[4,3,6]  R2498     1
    z[4,3,6]  R2499     2.9716029763221741e-01
    z[4,3,6]  R2500     -3.8691893219947815e-01
    z[4,3,6]  R2501     -3.4699544310569763e-01
    z[4,3,6]  R2502     9.0068168938159943e-02
    z[4,3,6]  R2503     -3.7443239241838455e-02
    z[4,3,6]  R2504     -0.259909987449646
    z[4,3,6]  R2505     -5.0366961956024170e-01
    z[4,3,6]  R2506     4.6736735850572586e-02
    z[4,3,6]  R2507     -1.0265648597851396e-03
    z[4,3,6]  R2508     -1.0762225091457367e-01
    z[4,3,6]  R2509     0.0696331113576889
    z[4,3,6]  R2510     3.1715276837348938e-01
    z[4,3,6]  R2511     2.2725264728069305e-01
    z[4,3,6]  R2512     -4.8621557652950287e-02
    z[4,3,6]  R2513     5.8099544048309326e-01
    z[4,3,6]  R2514     7.2574146091938019e-02
    z[4,3,6]  R2515     -2.1973720192909241e-01
    z[4,3,6]  R2516     -4.7050568461418152e-01
    z[4,3,6]  R2517     -7.0633783936500549e-02
    z[4,3,6]  R2518     0.336056649684906
    z[4,3,6]  R2519     -3.7884730100631714e-01
    z[4,3,6]  R2520     3.8792282342910767e-01
    z[4,3,6]  R2521     4.8093879222869873e-01
    z[4,3,6]  R2522     -2.1727073192596436e-01
    z[4,3,6]  R2523     2.2801366448402405e-01
    z[4,3,6]  R2524     -1.5106844902038574e-01
    z[4,3,6]  R2525     -4.0926668792963028e-02
    z[4,3,6]  R2526     2.4069119989871979e-01
    z[4,3,6]  R2527     -1.2605784833431244e-01
    z[4,3,6]  R2528     -0.855800211429596
    z[4,3,6]  R2529     -8.3539414405822754e-01
    z[4,3,6]  R2530     -7.7902823686599731e-01
    z[4,3,6]  R2531     -2.4133461713790894e-01
    z[4,3,6]  R2532     1.3475725427269936e-02
    z[4,3,6]  R2533     1.5930871665477753e-01
    z[4,3,6]  R2534     -1.2160740792751312e-01
    z[4,3,6]  R2535     5.5052947998046875e-01
    z[4,3,6]  R2536     4.1892027854919434e-01
    z[4,3,6]  R2537     -2.7657487988471985e-01
    z[4,3,6]  R2538     4.7432950139045715e-01
    z[4,3,6]  R2539     1.1000140011310577e-01
    z[4,3,6]  R2540     -1.4250591397285461e-01
    z[4,3,6]  R2541     -3.6658516526222229e-01
    z[4,3,6]  R2542     -8.4278509020805359e-03
    z[4,3,6]  R2543     1.2105721980333328e-01
    z[4,3,6]  R2544     1.3495326042175293e-01
    z[4,3,6]  R2545     2.2954124957323074e-02
    z[4,3,6]  R2546     -1.2433709204196930e-01
    z[4,3,6]  R2547     -7.0504434406757355e-02
    z[4,3,6]  R2548     1.5510024130344391e-01
    z[4,3,6]  R2549     5.9778308495879173e-03
    z[4,3,6]  R2550     2.5904938578605652e-02
    z[4,3,6]  R2551     3.6149981617927551e-01
    z[4,3,6]  R2552     -3.0157101154327393e-01
    z[4,3,6]  R2553     -1.7899684607982635e-01
    z[4,3,6]  R2554     -3.8635396957397461e-01
    z[4,3,6]  R2555     -2.5926964357495308e-02
    z[4,3,6]  R2556     -1.3939090073108673e-01
    z[4,3,6]  R2557     -1.5291011333465576e-01
    z[4,3,6]  R2558     3.7921956181526184e-01
    z[4,3,6]  R2559     1.2522467970848083e-01
    z[4,3,6]  R2560     0.085883229970932
    z[4,3,6]  R2561     0.446367472410202
    z[4,3,6]  R2562     9.8310850560665131e-02
    z[4,3,6]  R2563     5.5508965253829956e-01
    z[4,3,6]  R2564     4.5687967538833618e-01
    z[4,3,6]  R2565     4.9932867288589478e-01
    z[4,3,6]  R2566     0.0560506135225296
    z[4,3,6]  R2567     2.1495828032493591e-01
    z[4,3,6]  R2568     -3.6913719773292542e-01
    z[4,3,6]  R2569     5.1739192008972168e-01
    z[4,3,6]  R2570     0.447817862033844
    z[4,3,6]  R2571     -0.235219344496727
    z[4,3,6]  R2572     4.0423431992530823e-01
    z[4,3,6]  R2573     3.9935973286628723e-01
    z[4,3,6]  R2574     -7.1068987250328064e-02
    z[4,3,6]  R2575     -1.8020041286945343e-02
    z[4,3,6]  R2576     1.3029550015926361e-01
    z[4,3,6]  R2577     2.6778453588485718e-01
    z[4,3,6]  R2578     2.6788255572319031e-01
    z[4,3,6]  R2579     2.2394201159477234e-01
    z[4,3,6]  R2580     -8.8726624846458435e-02
    z[4,3,6]  R2581     2.9218995571136475e-01
    z[4,3,6]  R2582     2.7505829930305481e-01
    z[4,3,6]  R2583     2.0124079287052155e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2658     -1
    z[4,5,0]  R2659     1
    z[4,5,0]  R2672     -4.4537249207496643e-01
    z[4,5,0]  R2673     -5.1074630022048950e-01
    z[4,5,0]  R2674     -5.2198320627212524e-01
    z[4,5,0]  R2675     1.4921683818101883e-02
    z[4,5,0]  R2676     -9.6592712402343750e-01
    z[4,5,0]  R2677     8.0585852265357971e-02
    z[4,5,0]  R2678     -1.7927173525094986e-02
    z[4,5,0]  R2679     3.2609567046165466e-02
    z[4,5,0]  R2680     -2.4398061633110046e-01
    z[4,5,0]  R2681     -1.0867832228541374e-02
    z[4,5,0]  R2682     0.331209659576416
    z[4,5,0]  R2683     3.7573602795600891e-01
    z[4,5,0]  R2684     4.9842461943626404e-01
    z[4,5,0]  R2685     3.3839711546897888e-01
    z[4,5,0]  R2686     3.7496492266654968e-01
    z[4,5,0]  R2687     3.4600558876991272e-01
    z[4,5,0]  R2688     2.5181302428245544e-01
    z[4,5,0]  R2689     1.5387284755706787e-01
    z[4,5,0]  R2690     3.2433813810348511e-01
    z[4,5,0]  R2691     2.0987780392169952e-01
    z[4,5,0]  R2692     2.4177080392837524e-01
    z[4,5,0]  R2693     -1.7149411141872406e-01
    z[4,5,0]  R2694     -1.1276394070591778e-04
    z[4,5,0]  R2695     0.299360454082489
    z[4,5,0]  R2696     1.8625383079051971e-01
    z[4,5,0]  R2697     -4.1167184710502625e-01
    z[4,5,0]  R2698     5.2194584161043167e-02
    z[4,5,0]  R2699     -3.3740440011024475e-01
    z[4,5,0]  R2700     1.4051201939582825e-01
    z[4,5,0]  R2701     -1.3101556897163391e-01
    z[4,5,0]  R2702     2.3414593935012817e-01
    z[4,5,0]  R2703     2.6615265011787415e-01
    z[4,5,0]  R2704     -3.8141000270843506e-01
    z[4,5,0]  R2705     -7.2037017345428467e-01
    z[4,5,0]  R2706     -7.2790348529815674e-01
    z[4,5,0]  R2707     5.0193983316421509e-01
    z[4,5,0]  R2708     3.5697630047798157e-01
    z[4,5,0]  R2709     3.1045895814895630e-01
    z[4,5,0]  R2710     3.5617956519126892e-01
    z[4,5,0]  R2711     -0.0835917741060257
    z[4,5,0]  R2712     2.3714382946491241e-01
    z[4,5,0]  R2713     2.6713207364082336e-01
    z[4,5,0]  R2714     1.8173341453075409e-01
    z[4,5,0]  R2715     4.4621476531028748e-01
    z[4,5,0]  R2716     3.1219500303268433e-01
    z[4,5,0]  R2717     -5.0173097848892212e-01
    z[4,5,0]  R2718     6.3865667581558228e-01
    z[4,5,0]  R2719     6.5449148416519165e-02
    z[4,5,0]  R2720     5.2495366334915161e-01
    z[4,5,0]  R2721     3.5497203469276428e-01
    z[4,5,0]  R2722     4.4768762588500977e-01
    z[4,5,0]  R2723     4.9666678905487061e-01
    z[4,5,0]  R2724     6.2237411737442017e-01
    z[4,5,0]  R2725     4.7753170132637024e-01
    z[4,5,0]  R2726     3.4345629811286926e-01
    z[4,5,0]  R2727     -6.0553711652755737e-01
    z[4,5,0]  R2728     1.7541919648647308e-01
    z[4,5,0]  R2729     5.9707891941070557e-01
    z[4,5,0]  R2730     4.7816035151481628e-01
    z[4,5,0]  R2731     4.8107045888900757e-01
    z[4,5,0]  R2732     0.0420943982899189
    z[4,5,0]  R2733     2.2906219959259033e-01
    z[4,5,0]  R2734     3.0979016795754433e-02
    z[4,5,0]  R2735     -1.0578852146863937e-01
    z[4,5,0]  R2736     3.5713267326354980e-01
    z[4,5,0]  R2737     0.481503427028656
    z[4,5,0]  R2738     0.350081205368042
    z[4,5,0]  R2739     4.4970616698265076e-01
    z[4,5,0]  R2740     1.2914520502090454e-01
    z[4,5,0]  R2741     4.7862935066223145e-01
    z[4,5,0]  R2742     -0.0339871309697628
    z[4,5,0]  R2743     2.8752669692039490e-01
    z[4,5,0]  R2744     4.5326313376426697e-01
    z[4,5,0]  R2745     3.3613637089729309e-01
    z[4,5,0]  R2746     2.0278221368789673e-01
    z[4,5,0]  R2747     6.6347676515579224e-01
    z[4,5,0]  R2748     -2.4898461997509003e-01
    z[4,5,0]  R2749     4.6122840046882629e-01
    z[4,5,0]  R2750     4.9284663796424866e-01
    z[4,5,0]  R2751     4.1822734475135803e-01
    z[4,5,0]  R2752     4.8851454257965088e-01
    z[4,5,0]  R2753     3.4320834279060364e-01
    z[4,5,0]  R2754     1.8371088802814484e-01
    z[4,5,0]  R2755     3.1019492074847221e-02
    z[4,5,0]  R2756     7.1308411657810211e-02
    z[4,5,0]  R2757     -3.9650008082389832e-01
    z[4,5,0]  R2758     5.1104658842086792e-01
    z[4,5,0]  R2759     5.1345431804656982e-01
    z[4,5,0]  R2760     9.9075190722942352e-02
    z[4,5,0]  R2761     1.3918174803256989e-01
    z[4,5,0]  R2762     1.0309685766696930e-01
    z[4,5,0]  R2763     1.3891510665416718e-02
    z[4,5,0]  R2764     6.8562909960746765e-02
    z[4,5,0]  R2765     -6.5475896000862122e-02
    z[4,5,0]  R2766     -2.6827117800712585e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2660     -1
    z[4,5,1]  R2661     1
    z[4,5,1]  R2672     0.665277361869812
    z[4,5,1]  R2673     5.7158994674682617e-01
    z[4,5,1]  R2674     4.0337088704109192e-01
    z[4,5,1]  R2675     7.5647455453872681e-01
    z[4,5,1]  R2676     7.8719764947891235e-02
    z[4,5,1]  R2677     -6.6353100538253784e-01
    z[4,5,1]  R2678     -5.6738960742950439e-01
    z[4,5,1]  R2679     -0.539656400680542
    z[4,5,1]  R2680     -7.3659688234329224e-01
    z[4,5,1]  R2681     2.8826889395713806e-01
    z[4,5,1]  R2682     -7.7573865652084351e-01
    z[4,5,1]  R2683     -7.6019245386123657e-01
    z[4,5,1]  R2684     -6.0532516241073608e-01
    z[4,5,1]  R2685     -7.0515912771224976e-01
    z[4,5,1]  R2686     -6.2775951623916626e-01
    z[4,5,1]  R2687     -6.5205973386764526e-01
    z[4,5,1]  R2688     -7.5500094890594482e-01
    z[4,5,1]  R2689     -0.685711681842804
    z[4,5,1]  R2690     -5.7793557643890381e-01
    z[4,5,1]  R2691     -6.6598445177078247e-01
    z[4,5,1]  R2692     -6.6299033164978027e-01
    z[4,5,1]  R2693     2.1881558932363987e-03
    z[4,5,1]  R2694     1.9273987039923668e-02
    z[4,5,1]  R2695     5.7013678550720215e-01
    z[4,5,1]  R2696     6.1896014213562012e-01
    z[4,5,1]  R2697     8.5575813427567482e-03
    z[4,5,1]  R2698     1.4072133600711823e-01
    z[4,5,1]  R2699     -2.6882013678550720e-01
    z[4,5,1]  R2700     -1.2652019038796425e-02
    z[4,5,1]  R2701     3.0407634377479553e-01
    z[4,5,1]  R2702     5.1733434200286865e-01
    z[4,5,1]  R2703     1.8734943866729736e-01
    z[4,5,1]  R2704     1.8706493079662323e-02
    z[4,5,1]  R2705     -6.2197268009185791e-01
    z[4,5,1]  R2706     -6.0173243284225464e-01
    z[4,5,1]  R2707     -0.541064977645874
    z[4,5,1]  R2708     -7.0541268587112427e-01
    z[4,5,1]  R2709     -0.561692476272583
    z[4,5,1]  R2710     -5.9705138206481934e-01
    z[4,5,1]  R2711     8.4480911493301392e-01
    z[4,5,1]  R2712     -2.9515042901039124e-01
    z[4,5,1]  R2713     -5.9425985813140869e-01
    z[4,5,1]  R2714     7.0331460237503052e-01
    z[4,5,1]  R2715     5.4043614864349365e-01
    z[4,5,1]  R2716     -4.5522215962409973e-01
    z[4,5,1]  R2717     -4.3140354752540588e-01
    z[4,5,1]  R2718     3.7732613086700439e-01
    z[4,5,1]  R2719     8.4820365905761719e-01
    z[4,5,1]  R2720     6.9910007715225220e-01
    z[4,5,1]  R2721     6.6943019628524780e-01
    z[4,5,1]  R2722     0.597454845905304
    z[4,5,1]  R2723     6.0251086950302124e-01
    z[4,5,1]  R2724     5.7777369022369385e-01
    z[4,5,1]  R2725     6.0641765594482422e-01
    z[4,5,1]  R2726     0.650162935256958
    z[4,5,1]  R2727     -5.0807815790176392e-01
    z[4,5,1]  R2728     5.8061248064041138e-01
    z[4,5,1]  R2729     -1.7243736982345581e-01
    z[4,5,1]  R2730     -5.6971997022628784e-01
    z[4,5,1]  R2731     -5.5164480209350586e-01
    z[4,5,1]  R2732     -4.0834445506334305e-02
    z[4,5,1]  R2733     1.3132227957248688e-01
    z[4,5,1]  R2734     -5.1098912954330444e-02
    z[4,5,1]  R2735     2.9433953762054443e-01
    z[4,5,1]  R2736     -2.1766616404056549e-01
    z[4,5,1]  R2737     -5.3306269645690918e-01
    z[4,5,1]  R2738     -3.5644170641899109e-01
    z[4,5,1]  R2739     -3.5504448413848877e-01
    z[4,5,1]  R2740     -5.8893674612045288e-01
    z[4,5,1]  R2741     -4.9673485755920410e-01
    z[4,5,1]  R2742     1.1629262566566467e-01
    z[4,5,1]  R2743     -4.4587850570678711e-01
    z[4,5,1]  R2744     -1.3600496947765350e-01
    z[4,5,1]  R2745     -5.9690237045288086e-01
    z[4,5,1]  R2746     7.1867331862449646e-02
    z[4,5,1]  R2747     2.4152347818017006e-02
    z[4,5,1]  R2748     8.4414738416671753e-01
    z[4,5,1]  R2749     0.718745231628418
    z[4,5,1]  R2750     -4.8123809695243835e-01
    z[4,5,1]  R2751     -3.2860276103019714e-01
    z[4,5,1]  R2752     -6.6047638654708862e-01
    z[4,5,1]  R2753     -1.4736685156822205e-01
    z[4,5,1]  R2754     2.6722899079322815e-01
    z[4,5,1]  R2755     -3.5031118988990784e-01
    z[4,5,1]  R2756     -0.500552237033844
    z[4,5,1]  R2757     -3.4786400198936462e-01
    z[4,5,1]  R2758     -5.2081096172332764e-01
    z[4,5,1]  R2759     -5.9718823432922363e-01
    z[4,5,1]  R2760     -5.9593987464904785e-01
    z[4,5,1]  R2761     -3.3485185354948044e-02
    z[4,5,1]  R2762     2.0150625705718994e-01
    z[4,5,1]  R2763     4.2572334408760071e-02
    z[4,5,1]  R2764     -0.365588903427124
    z[4,5,1]  R2765     1.8889233469963074e-02
    z[4,5,1]  R2766     1.7349785566329956e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2662     -1
    z[4,5,2]  R2663     1
    z[4,5,2]  R2672     -3.3246603608131409e-01
    z[4,5,2]  R2673     -3.3024686574935913e-01
    z[4,5,2]  R2674     -3.8213226199150085e-01
    z[4,5,2]  R2675     -5.9999954700469971e-01
    z[4,5,2]  R2676     -1.8448592722415924e-01
    z[4,5,2]  R2677     4.5519477128982544e-01
    z[4,5,2]  R2678     -1.3045579195022583e-01
    z[4,5,2]  R2679     -2.9634529352188110e-01
    z[4,5,2]  R2680     4.5163431763648987e-01
    z[4,5,2]  R2681     0.0443992018699646
    z[4,5,2]  R2682     4.3069524690508842e-03
    z[4,5,2]  R2683     -2.0378093421459198e-01
    z[4,5,2]  R2684     -2.0583665370941162e-01
    z[4,5,2]  R2685     -0.601309597492218
    z[4,5,2]  R2686     7.6408926397562027e-03
    z[4,5,2]  R2687     -2.1865795552730560e-01
    z[4,5,2]  R2688     -5.1944029331207275e-01
    z[4,5,2]  R2689     2.9603847861289978e-01
    z[4,5,2]  R2690     -1.8319685757160187e-01
    z[4,5,2]  R2691     5.0144165754318237e-01
    z[4,5,2]  R2692     3.1911796331405640e-01
    z[4,5,2]  R2693     -5.3569239377975464e-01
    z[4,5,2]  R2694     -5.2974373102188110e-01
    z[4,5,2]  R2695     3.3966198563575745e-01
    z[4,5,2]  R2696     6.2364935874938965e-01
    z[4,5,2]  R2697     -2.5082439184188843e-01
    z[4,5,2]  R2698     -4.9486222863197327e-01
    z[4,5,2]  R2699     -8.3715015649795532e-01
    z[4,5,2]  R2700     -6.9883072376251221e-01
    z[4,5,2]  R2701     -8.6587077379226685e-01
    z[4,5,2]  R2702     -4.6348148584365845e-01
    z[4,5,2]  R2703     -0.835545003414154
    z[4,5,2]  R2704     -3.9633882045745850e-01
    z[4,5,2]  R2705     1.9898726046085358e-01
    z[4,5,2]  R2706     3.1680113077163696e-01
    z[4,5,2]  R2707     4.7050195932388306e-01
    z[4,5,2]  R2708     5.2155035734176636e-01
    z[4,5,2]  R2709     4.4924122095108032e-01
    z[4,5,2]  R2710     5.2330291271209717e-01
    z[4,5,2]  R2711     2.3753516376018524e-01
    z[4,5,2]  R2712     0.685438334941864
    z[4,5,2]  R2713     4.8933586478233337e-01
    z[4,5,2]  R2714     3.0118945240974426e-01
    z[4,5,2]  R2715     3.3472895622253418e-01
    z[4,5,2]  R2716     0.550088107585907
    z[4,5,2]  R2717     -1.4015612006187439e-01
    z[4,5,2]  R2718     3.8528403639793396e-01
    z[4,5,2]  R2719     3.6292123794555664e-01
    z[4,5,2]  R2720     1.1737194657325745e-01
    z[4,5,2]  R2721     1.4842732250690460e-01
    z[4,5,2]  R2722     2.1074037998914719e-02
    z[4,5,2]  R2723     1.3993789255619049e-01
    z[4,5,2]  R2724     1.3967829942703247e-01
    z[4,5,2]  R2725     5.2091282606124878e-01
    z[4,5,2]  R2726     2.3172754049301147e-01
    z[4,5,2]  R2727     0.0881069228053093
    z[4,5,2]  R2728     3.4890773892402649e-01
    z[4,5,2]  R2729     9.3202881515026093e-02
    z[4,5,2]  R2730     2.4517005681991577e-01
    z[4,5,2]  R2731     3.7510260939598083e-01
    z[4,5,2]  R2732     -1.1677806824445724e-01
    z[4,5,2]  R2733     1.2375617772340775e-01
    z[4,5,2]  R2734     1.3580541312694550e-01
    z[4,5,2]  R2735     -4.8568150959908962e-03
    z[4,5,2]  R2736     4.2193382978439331e-01
    z[4,5,2]  R2737     5.0784224271774292e-01
    z[4,5,2]  R2738     6.4672106504440308e-01
    z[4,5,2]  R2739     4.5124414563179016e-01
    z[4,5,2]  R2740     7.5461500883102417e-01
    z[4,5,2]  R2741     4.1927462816238403e-01
    z[4,5,2]  R2742     -1.3850663602352142e-01
    z[4,5,2]  R2743     6.0157597064971924e-01
    z[4,5,2]  R2744     7.0908397436141968e-01
    z[4,5,2]  R2745     2.0411163568496704e-01
    z[4,5,2]  R2746     0.0621710866689682
    z[4,5,2]  R2747     1.0683589428663254e-01
    z[4,5,2]  R2748     2.4507471919059753e-01
    z[4,5,2]  R2749     -0.00966144260019064
    z[4,5,2]  R2750     5.8281403779983521e-01
    z[4,5,2]  R2751     5.8617675304412842e-01
    z[4,5,2]  R2752     4.8749116063117981e-01
    z[4,5,2]  R2753     8.3031928539276123e-01
    z[4,5,2]  R2754     6.2518283724784851e-02
    z[4,5,2]  R2755     -2.0371995866298676e-01
    z[4,5,2]  R2756     7.6282203197479248e-01
    z[4,5,2]  R2757     9.7577020525932312e-02
    z[4,5,2]  R2758     6.3724607229232788e-01
    z[4,5,2]  R2759     0.546921968460083
    z[4,5,2]  R2760     7.2423154115676880e-01
    z[4,5,2]  R2761     -2.3010337352752686e-01
    z[4,5,2]  R2762     2.2679027169942856e-02
    z[4,5,2]  R2763     1.8637599050998688e-01
    z[4,5,2]  R2764     8.1958460807800293e-01
    z[4,5,2]  R2765     3.5175395011901855e-01
    z[4,5,2]  R2766     0.812131404876709
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2664     -1
    z[4,5,3]  R2665     1
    z[4,5,3]  R2672     6.1623834073543549e-02
    z[4,5,3]  R2673     1.2031611055135727e-01
    z[4,5,3]  R2674     -1.0835071653127670e-01
    z[4,5,3]  R2675     1.6698566079139709e-01
    z[4,5,3]  R2676     -8.0087609589099884e-02
    z[4,5,3]  R2677     5.4327648133039474e-02
    z[4,5,3]  R2678     -5.7724362611770630e-01
    z[4,5,3]  R2679     1.4700695872306824e-01
    z[4,5,3]  R2680     1.0272392630577087e-01
    z[4,5,3]  R2681     8.5961920022964478e-01
    z[4,5,3]  R2682     -2.4001386761665344e-01
    z[4,5,3]  R2683     1.8896806240081787e-01
    z[4,5,3]  R2684     -0.388874351978302
    z[4,5,3]  R2685     1.1385331302881241e-01
    z[4,5,3]  R2686     3.0618848279118538e-02
    z[4,5,3]  R2687     5.8276718854904175e-01
    z[4,5,3]  R2688     -4.3951552361249924e-02
    z[4,5,3]  R2689     3.5840559005737305e-01
    z[4,5,3]  R2690     1.5175801515579224e-01
    z[4,5,3]  R2691     1.3548615574836731e-01
    z[4,5,3]  R2692     -7.3759861290454865e-02
    z[4,5,3]  R2693     -6.4899915456771851e-01
    z[4,5,3]  R2694     -3.1279709935188293e-01
    z[4,5,3]  R2695     -6.1535632610321045e-01
    z[4,5,3]  R2696     -2.5307220220565796e-01
    z[4,5,3]  R2697     5.9576869010925293e-01
    z[4,5,3]  R2698     3.9372414350509644e-01
    z[4,5,3]  R2699     1.3222867250442505e-01
    z[4,5,3]  R2700     6.4013522863388062e-01
    z[4,5,3]  R2701     1.5869811177253723e-01
    z[4,5,3]  R2702     6.4389592409133911e-01
    z[4,5,3]  R2703     2.3036353290081024e-01
    z[4,5,3]  R2704     4.4051659107208252e-01
    z[4,5,3]  R2705     1.5037453733384609e-02
    z[4,5,3]  R2706     7.1662895381450653e-02
    z[4,5,3]  R2707     -1.1776566505432129e-01
    z[4,5,3]  R2708     -1.3404813408851624e-01
    z[4,5,3]  R2709     -1.9995562732219696e-01
    z[4,5,3]  R2710     -4.2782168835401535e-02
    z[4,5,3]  R2711     -3.0475902557373047e-01
    z[4,5,3]  R2712     -4.1686594486236572e-01
    z[4,5,3]  R2713     -3.8454201817512512e-01
    z[4,5,3]  R2714     -5.1275640726089478e-01
    z[4,5,3]  R2715     -4.1546443104743958e-01
    z[4,5,3]  R2716     -3.2571017742156982e-01
    z[4,5,3]  R2717     -1.3579273223876953e-01
    z[4,5,3]  R2718     1.1743741482496262e-01
    z[4,5,3]  R2719     -9.0006791055202484e-02
    z[4,5,3]  R2720     -3.6825048923492432e-01
    z[4,5,3]  R2721     -5.0619250535964966e-01
    z[4,5,3]  R2722     -5.6021952629089355e-01
    z[4,5,3]  R2723     -3.8618949055671692e-01
    z[4,5,3]  R2724     -3.2842054963111877e-01
    z[4,5,3]  R2725     -3.1660124659538269e-01
    z[4,5,3]  R2726     -3.8760277628898621e-01
    z[4,5,3]  R2727     -2.8610104322433472e-01
    z[4,5,3]  R2728     3.0981364846229553e-01
    z[4,5,3]  R2729     4.0037342905998230e-01
    z[4,5,3]  R2730     -5.9528566896915436e-02
    z[4,5,3]  R2731     -3.6331480741500854e-01
    z[4,5,3]  R2732     -8.4577780961990356e-01
    z[4,5,3]  R2733     -7.9938125610351562e-01
    z[4,5,3]  R2734     -0.662041962146759
    z[4,5,3]  R2735     -0.797913670539856
    z[4,5,3]  R2736     -4.7221881151199341e-01
    z[4,5,3]  R2737     -6.7318767309188843e-02
    z[4,5,3]  R2738     -1.2998647987842560e-01
    z[4,5,3]  R2739     -4.8076048493385315e-01
    z[4,5,3]  R2740     9.2176847159862518e-02
    z[4,5,3]  R2741     -5.8152031898498535e-01
    z[4,5,3]  R2742     -8.3289182186126709e-01
    z[4,5,3]  R2743     -5.7208532094955444e-01
    z[4,5,3]  R2744     -3.0186501145362854e-01
    z[4,5,3]  R2745     -5.2364188432693481e-01
    z[4,5,3]  R2746     -8.4814244508743286e-01
    z[4,5,3]  R2747     4.1239511966705322e-01
    z[4,5,3]  R2748     -4.8379480838775635e-02
    z[4,5,3]  R2749     -4.6403801441192627e-01
    z[4,5,3]  R2750     -4.0619453787803650e-01
    z[4,5,3]  R2751     -4.2855963110923767e-01
    z[4,5,3]  R2752     5.4446242749691010e-02
    z[4,5,3]  R2753     -3.3980420231819153e-01
    z[4,5,3]  R2754     -0.851863443851471
    z[4,5,3]  R2755     -8.3771157264709473e-01
    z[4,5,3]  R2756     -9.4819359481334686e-02
    z[4,5,3]  R2757     -0.722500741481781
    z[4,5,3]  R2758     -2.0860888063907623e-01
    z[4,5,3]  R2759     -2.0605309307575226e-01
    z[4,5,3]  R2760     2.8400283306837082e-02
    z[4,5,3]  R2761     -0.847332775592804
    z[4,5,3]  R2762     -8.6517196893692017e-01
    z[4,5,3]  R2763     -6.3254356384277344e-01
    z[4,5,3]  R2764     -2.6408711075782776e-01
    z[4,5,3]  R2765     -7.7237951755523682e-01
    z[4,5,3]  R2766     3.1130319833755493e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2666     -1
    z[4,5,4]  R2667     1
    z[4,5,4]  R2672     9.6880055963993073e-02
    z[4,5,4]  R2673     2.8017762303352356e-01
    z[4,5,4]  R2674     -2.7349710464477539e-01
    z[4,5,4]  R2675     1.7739698290824890e-01
    z[4,5,4]  R2676     -2.9830446466803551e-02
    z[4,5,4]  R2677     5.0163465738296509e-01
    z[4,5,4]  R2678     -2.0905299112200737e-02
    z[4,5,4]  R2679     9.0793631970882416e-02
    z[4,5,4]  R2680     -4.2723834514617920e-01
    z[4,5,4]  R2681     -3.7313145399093628e-01
    z[4,5,4]  R2682     -2.1621921658515930e-01
    z[4,5,4]  R2683     -9.6813194453716278e-02
    z[4,5,4]  R2684     3.7031877040863037e-01
    z[4,5,4]  R2685     6.5757364034652710e-02
    z[4,5,4]  R2686     -2.7775904163718224e-02
    z[4,5,4]  R2687     -1.0947525501251221e-01
    z[4,5,4]  R2688     -1.0854104906320572e-01
    z[4,5,4]  R2689     -2.5228586792945862e-01
    z[4,5,4]  R2690     -6.6569441556930542e-01
    z[4,5,4]  R2691     -1.9893574714660645e-01
    z[4,5,4]  R2692     1.3082090020179749e-01
    z[4,5,4]  R2693     3.8038212805986404e-02
    z[4,5,4]  R2694     -6.0758739709854126e-01
    z[4,5,4]  R2695     -1.3361072167754173e-02
    z[4,5,4]  R2696     8.8092230260372162e-02
    z[4,5,4]  R2697     -1.4564444124698639e-01
    z[4,5,4]  R2698     3.8416441529989243e-02
    z[4,5,4]  R2699     1.7567806644365191e-03
    z[4,5,4]  R2700     2.4478648602962494e-01
    z[4,5,4]  R2701     9.6992768347263336e-02
    z[4,5,4]  R2702     2.1350033581256866e-01
    z[4,5,4]  R2703     -2.7428719401359558e-01
    z[4,5,4]  R2704     6.8304139375686646e-01
    z[4,5,4]  R2705     1.2113102525472641e-01
    z[4,5,4]  R2706     2.5525709614157677e-02
    z[4,5,4]  R2707     -2.7946668863296509e-01
    z[4,5,4]  R2708     2.1172559261322021e-01
    z[4,5,4]  R2709     -1.7210589349269867e-01
    z[4,5,4]  R2710     2.4047857522964478e-01
    z[4,5,4]  R2711     1.0388135910034180e-02
    z[4,5,4]  R2712     2.1524070203304291e-01
    z[4,5,4]  R2713     -3.8811179995536804e-01
    z[4,5,4]  R2714     1.0021328926086426e-01
    z[4,5,4]  R2715     -4.2036247253417969e-01
    z[4,5,4]  R2716     -2.8724148869514465e-01
    z[4,5,4]  R2717     -9.4732575118541718e-02
    z[4,5,4]  R2718     -4.5010432600975037e-01
    z[4,5,4]  R2719     -2.0135407149791718e-01
    z[4,5,4]  R2720     -2.9905600473284721e-02
    z[4,5,4]  R2721     0.159097358584404
    z[4,5,4]  R2722     3.3481064438819885e-01
    z[4,5,4]  R2723     -2.0056806504726410e-01
    z[4,5,4]  R2724     8.6779326200485229e-02
    z[4,5,4]  R2725     1.1984530836343765e-02
    z[4,5,4]  R2726     -0.496004581451416
    z[4,5,4]  R2727     -0.531998336315155
    z[4,5,4]  R2728     -6.1312294006347656e-01
    z[4,5,4]  R2729     -5.4920804500579834e-01
    z[4,5,4]  R2730     1.8354912102222443e-01
    z[4,5,4]  R2731     -0.276263952255249
    z[4,5,4]  R2732     -4.0148639678955078e-01
    z[4,5,4]  R2733     -4.6598100662231445e-01
    z[4,5,4]  R2734     -4.0774139761924744e-01
    z[4,5,4]  R2735     -4.0382185578346252e-01
    z[4,5,4]  R2736     5.0118589401245117e-01
    z[4,5,4]  R2737     2.6180425286293030e-01
    z[4,5,4]  R2738     -0.282550573348999
    z[4,5,4]  R2739     -6.2645196914672852e-02
    z[4,5,4]  R2740     -1.2329094856977463e-01
    z[4,5,4]  R2741     -0.0234454907476902
    z[4,5,4]  R2742     -1.5201459825038910e-01
    z[4,5,4]  R2743     -1.1735180765390396e-01
    z[4,5,4]  R2744     5.4263092577457428e-02
    z[4,5,4]  R2745     1.4913311600685120e-01
    z[4,5,4]  R2746     -2.5151485204696655e-01
    z[4,5,4]  R2747     -5.0076740980148315e-01
    z[4,5,4]  R2748     3.4647189080715179e-02
    z[4,5,4]  R2749     1.5218664705753326e-01
    z[4,5,4]  R2750     -0.0744100883603096
    z[4,5,4]  R2751     -1.8353520333766937e-01
    z[4,5,4]  R2752     1.3839547336101532e-01
    z[4,5,4]  R2753     4.5360937714576721e-02
    z[4,5,4]  R2754     -2.7728980779647827e-01
    z[4,5,4]  R2755     -8.2025587558746338e-02
    z[4,5,4]  R2756     1.3995287939906120e-02
    z[4,5,4]  R2757     1.8421135842800140e-01
    z[4,5,4]  R2758     -1.1290358752012253e-01
    z[4,5,4]  R2759     1.5742288529872894e-01
    z[4,5,4]  R2760     -1.0554249398410320e-02
    z[4,5,4]  R2761     -1.9067689776420593e-01
    z[4,5,4]  R2762     -3.3969292044639587e-01
    z[4,5,4]  R2763     -5.9137541055679321e-01
    z[4,5,4]  R2764     -1.1788047850131989e-01
    z[4,5,4]  R2765     -2.7381590008735657e-01
    z[4,5,4]  R2766     3.5458293557167053e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2668     -1
    z[4,5,5]  R2669     1
    z[4,5,5]  R2672     -3.8344261050224304e-01
    z[4,5,5]  R2673     -2.4632996320724487e-01
    z[4,5,5]  R2674     -4.6027606725692749e-01
    z[4,5,5]  R2675     7.6073859818279743e-03
    z[4,5,5]  R2676     -1.3433896005153656e-01
    z[4,5,5]  R2677     1.5455786883831024e-01
    z[4,5,5]  R2678     -2.7092182636260986e-01
    z[4,5,5]  R2679     7.6671266555786133e-01
    z[4,5,5]  R2680     2.8965758159756660e-02
    z[4,5,5]  R2681     -1.5829353034496307e-01
    z[4,5,5]  R2682     -4.2344415187835693e-01
    z[4,5,5]  R2683     -3.0616271495819092e-01
    z[4,5,5]  R2684     -5.2750091999769211e-02
    z[4,5,5]  R2685     -8.3749219775199890e-02
    z[4,5,5]  R2686     3.5495933890342712e-01
    z[4,5,5]  R2687     2.2453854978084564e-01
    z[4,5,5]  R2688     1.8640884757041931e-01
    z[4,5,5]  R2689     -7.0749111473560333e-02
    z[4,5,5]  R2690     2.3678185045719147e-01
    z[4,5,5]  R2691     3.0017700791358948e-01
    z[4,5,5]  R2692     4.8381257057189941e-01
    z[4,5,5]  R2693     3.3239677548408508e-01
    z[4,5,5]  R2694     1.4385271072387695e-01
    z[4,5,5]  R2695     2.0954367518424988e-01
    z[4,5,5]  R2696     2.6355904340744019e-01
    z[4,5,5]  R2697     -6.1933767795562744e-01
    z[4,5,5]  R2698     -6.4784586429595947e-01
    z[4,5,5]  R2699     -3.0371937155723572e-01
    z[4,5,5]  R2700     -5.0053298473358154e-02
    z[4,5,5]  R2701     -3.3766743727028370e-03
    z[4,5,5]  R2702     0.0362824983894825
    z[4,5,5]  R2703     1.8293833732604980e-01
    z[4,5,5]  R2704     -1.8776687979698181e-01
    z[4,5,5]  R2705     -5.7682663202285767e-02
    z[4,5,5]  R2706     -0.0266642477363348
    z[4,5,5]  R2707     3.4906172752380371e-01
    z[4,5,5]  R2708     1.1849937587976456e-01
    z[4,5,5]  R2709     5.4500085115432739e-01
    z[4,5,5]  R2710     2.6853027939796448e-01
    z[4,5,5]  R2711     -3.2048285007476807e-01
    z[4,5,5]  R2712     3.7137782573699951e-01
    z[4,5,5]  R2713     1.8925306200981140e-01
    z[4,5,5]  R2714     2.7644780930131674e-03
    z[4,5,5]  R2715     1.9587117433547974e-01
    z[4,5,5]  R2716     2.6655626296997070e-01
    z[4,5,5]  R2717     6.3775390386581421e-01
    z[4,5,5]  R2718     2.7203616499900818e-01
    z[4,5,5]  R2719     -2.9853606224060059e-01
    z[4,5,5]  R2720     2.7603876590728760e-01
    z[4,5,5]  R2721     -5.6742765009403229e-02
    z[4,5,5]  R2722     1.1412044614553452e-01
    z[4,5,5]  R2723     -5.1465284079313278e-02
    z[4,5,5]  R2724     -1.3932244479656219e-01
    z[4,5,5]  R2725     -2.9125756118446589e-03
    z[4,5,5]  R2726     -2.9701529070734978e-02
    z[4,5,5]  R2727     -3.7494511343538761e-03
    z[4,5,5]  R2728     3.4458752721548080e-02
    z[4,5,5]  R2729     3.0400335788726807e-01
    z[4,5,5]  R2730     5.9104061126708984e-01
    z[4,5,5]  R2731     -0.0534505657851696
    z[4,5,5]  R2732     1.9277544319629669e-01
    z[4,5,5]  R2733     2.4191319942474365e-01
    z[4,5,5]  R2734     5.5073505640029907e-01
    z[4,5,5]  R2735     3.1129565834999084e-01
    z[4,5,5]  R2736     3.4153786301612854e-01
    z[4,5,5]  R2737     3.9113840460777283e-01
    z[4,5,5]  R2738     4.2109638452529907e-01
    z[4,5,5]  R2739     4.3957060575485229e-01
    z[4,5,5]  R2740     1.9891719520092010e-01
    z[4,5,5]  R2741     -5.1018454134464264e-02
    z[4,5,5]  R2742     4.7241061925888062e-01
    z[4,5,5]  R2743     -1.1062230169773102e-01
    z[4,5,5]  R2744     2.1643431484699249e-01
    z[4,5,5]  R2745     4.2171150445938110e-01
    z[4,5,5]  R2746     3.6347669363021851e-01
    z[4,5,5]  R2747     2.6701900362968445e-01
    z[4,5,5]  R2748     -2.6293733716011047e-01
    z[4,5,5]  R2749     -1.1496489495038986e-01
    z[4,5,5]  R2750     0.0418475866317749
    z[4,5,5]  R2751     3.5667872428894043e-01
    z[4,5,5]  R2752     -1.0689385980367661e-01
    z[4,5,5]  R2753     2.3131118714809418e-01
    z[4,5,5]  R2754     2.0413130521774292e-01
    z[4,5,5]  R2755     3.2589516043663025e-01
    z[4,5,5]  R2756     -1.9784484058618546e-02
    z[4,5,5]  R2757     5.9179648756980896e-02
    z[4,5,5]  R2758     7.2134897112846375e-02
    z[4,5,5]  R2759     1.1516427993774414e-01
    z[4,5,5]  R2760     3.3080011606216431e-01
    z[4,5,5]  R2761     4.1496536135673523e-01
    z[4,5,5]  R2762     2.4856556951999664e-01
    z[4,5,5]  R2763     4.6000748872756958e-01
    z[4,5,5]  R2764     -5.1871344447135925e-02
    z[4,5,5]  R2765     3.1858170032501221e-01
    z[4,5,5]  R2766     8.2440860569477081e-02
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2670     -1
    z[4,5,6]  R2671     1
    z[4,5,6]  R2672     2.9716029763221741e-01
    z[4,5,6]  R2673     -3.8691893219947815e-01
    z[4,5,6]  R2674     -3.4699544310569763e-01
    z[4,5,6]  R2675     9.0068168938159943e-02
    z[4,5,6]  R2676     -3.7443239241838455e-02
    z[4,5,6]  R2677     -0.259909987449646
    z[4,5,6]  R2678     -5.0366961956024170e-01
    z[4,5,6]  R2679     4.6736735850572586e-02
    z[4,5,6]  R2680     -1.0265648597851396e-03
    z[4,5,6]  R2681     -1.0762225091457367e-01
    z[4,5,6]  R2682     0.0696331113576889
    z[4,5,6]  R2683     3.1715276837348938e-01
    z[4,5,6]  R2684     2.2725264728069305e-01
    z[4,5,6]  R2685     -4.8621557652950287e-02
    z[4,5,6]  R2686     5.8099544048309326e-01
    z[4,5,6]  R2687     7.2574146091938019e-02
    z[4,5,6]  R2688     -2.1973720192909241e-01
    z[4,5,6]  R2689     -4.7050568461418152e-01
    z[4,5,6]  R2690     -7.0633783936500549e-02
    z[4,5,6]  R2691     0.336056649684906
    z[4,5,6]  R2692     -3.7884730100631714e-01
    z[4,5,6]  R2693     3.8792282342910767e-01
    z[4,5,6]  R2694     4.8093879222869873e-01
    z[4,5,6]  R2695     -2.1727073192596436e-01
    z[4,5,6]  R2696     2.2801366448402405e-01
    z[4,5,6]  R2697     -8.8365182280540466e-02
    z[4,5,6]  R2698     -3.9545637369155884e-01
    z[4,5,6]  R2699     5.7798791676759720e-02
    z[4,5,6]  R2700     -1.3976109027862549e-01
    z[4,5,6]  R2701     3.2563191652297974e-01
    z[4,5,6]  R2702     3.4999959170818329e-02
    z[4,5,6]  R2703     1.8482497334480286e-01
    z[4,5,6]  R2704     3.5145051777362823e-02
    z[4,5,6]  R2705     1.9077347218990326e-01
    z[4,5,6]  R2706     -3.4835245460271835e-02
    z[4,5,6]  R2707     -1.4184023439884186e-01
    z[4,5,6]  R2708     -1.6157792508602142e-01
    z[4,5,6]  R2709     1.4025190472602844e-01
    z[4,5,6]  R2710     3.3324298262596130e-01
    z[4,5,6]  R2711     1.6489909589290619e-01
    z[4,5,6]  R2712     -1.6969369351863861e-01
    z[4,5,6]  R2713     4.1545432060956955e-02
    z[4,5,6]  R2714     3.2960101962089539e-01
    z[4,5,6]  R2715     9.5377013087272644e-02
    z[4,5,6]  R2716     3.6477804183959961e-01
    z[4,5,6]  R2717     -3.2919496297836304e-01
    z[4,5,6]  R2718     -1.0445023328065872e-01
    z[4,5,6]  R2719     8.2382082939147949e-02
    z[4,5,6]  R2720     9.5949888229370117e-02
    z[4,5,6]  R2721     3.4505769610404968e-01
    z[4,5,6]  R2722     -5.6673612445592880e-02
    z[4,5,6]  R2723     4.2273110151290894e-01
    z[4,5,6]  R2724     -3.5286897420883179e-01
    z[4,5,6]  R2725     -1.8022920191287994e-01
    z[4,5,6]  R2726     9.2139437794685364e-02
    z[4,5,6]  R2727     5.0284836441278458e-02
    z[4,5,6]  R2728     1.9310359656810760e-01
    z[4,5,6]  R2729     -2.2523060441017151e-01
    z[4,5,6]  R2730     -1.0507960803806782e-02
    z[4,5,6]  R2731     3.3523243665695190e-01
    z[4,5,6]  R2732     0.263115257024765
    z[4,5,6]  R2733     -0.0172833651304245
    z[4,5,6]  R2734     2.6480999588966370e-01
    z[4,5,6]  R2735     -0.0742039605975151
    z[4,5,6]  R2736     2.3711478710174561e-01
    z[4,5,6]  R2737     5.6914114393293858e-03
    z[4,5,6]  R2738     2.4102061986923218e-01
    z[4,5,6]  R2739     -1.9952252507209778e-01
    z[4,5,6]  R2740     6.1366468667984009e-02
    z[4,5,6]  R2741     8.4016129374504089e-02
    z[4,5,6]  R2742     -1.6170255839824677e-01
    z[4,5,6]  R2743     5.7765308767557144e-02
    z[4,5,6]  R2744     3.6379155516624451e-01
    z[4,5,6]  R2745     -1.2155794352293015e-01
    z[4,5,6]  R2746     1.8742622435092926e-01
    z[4,5,6]  R2747     -2.3593294620513916e-01
    z[4,5,6]  R2748     3.0443921685218811e-01
    z[4,5,6]  R2749     -1.3737358152866364e-01
    z[4,5,6]  R2750     1.1643828451633453e-01
    z[4,5,6]  R2751     1.7010244727134705e-01
    z[4,5,6]  R2752     0.232234388589859
    z[4,5,6]  R2753     -5.6208237074315548e-03
    z[4,5,6]  R2754     -2.1610192954540253e-01
    z[4,5,6]  R2755     1.4185032248497009e-01
    z[4,5,6]  R2756     -0.391007661819458
    z[4,5,6]  R2757     -3.9091381430625916e-01
    z[4,5,6]  R2758     -6.0242330655455589e-03
    z[4,5,6]  R2759     1.0224212892353535e-02
    z[4,5,6]  R2760     1.3477612286806107e-02
    z[4,5,6]  R2761     5.7424264959990978e-03
    z[4,5,6]  R2762     -1.5017724037170410e-01
    z[4,5,6]  R2763     -4.2608477175235748e-02
    z[4,5,6]  R2764     -3.2186403870582581e-01
    z[4,5,6]  R2765     -3.1398364901542664e-01
    z[4,5,6]  R2766     0.0945323258638382
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2767     -1
    z[5,4,0]  R2768     1
    z[5,4,0]  R2781     -4.1167184710502625e-01
    z[5,4,0]  R2782     5.2194584161043167e-02
    z[5,4,0]  R2783     -3.3740440011024475e-01
    z[5,4,0]  R2784     1.4051201939582825e-01
    z[5,4,0]  R2785     -1.3101556897163391e-01
    z[5,4,0]  R2786     2.3414593935012817e-01
    z[5,4,0]  R2787     2.6615265011787415e-01
    z[5,4,0]  R2788     -3.8141000270843506e-01
    z[5,4,0]  R2789     -7.2037017345428467e-01
    z[5,4,0]  R2790     -7.2790348529815674e-01
    z[5,4,0]  R2791     5.0193983316421509e-01
    z[5,4,0]  R2792     3.5697630047798157e-01
    z[5,4,0]  R2793     3.1045895814895630e-01
    z[5,4,0]  R2794     3.5617956519126892e-01
    z[5,4,0]  R2795     -0.0835917741060257
    z[5,4,0]  R2796     2.3714382946491241e-01
    z[5,4,0]  R2797     2.6713207364082336e-01
    z[5,4,0]  R2798     1.8173341453075409e-01
    z[5,4,0]  R2799     4.4621476531028748e-01
    z[5,4,0]  R2800     3.1219500303268433e-01
    z[5,4,0]  R2801     -5.0173097848892212e-01
    z[5,4,0]  R2802     6.3865667581558228e-01
    z[5,4,0]  R2803     6.5449148416519165e-02
    z[5,4,0]  R2804     5.2495366334915161e-01
    z[5,4,0]  R2805     3.5497203469276428e-01
    z[5,4,0]  R2806     4.4768762588500977e-01
    z[5,4,0]  R2807     4.9666678905487061e-01
    z[5,4,0]  R2808     6.2237411737442017e-01
    z[5,4,0]  R2809     4.7753170132637024e-01
    z[5,4,0]  R2810     3.4345629811286926e-01
    z[5,4,0]  R2811     -6.0553711652755737e-01
    z[5,4,0]  R2812     1.7541919648647308e-01
    z[5,4,0]  R2813     5.9707891941070557e-01
    z[5,4,0]  R2814     4.7816035151481628e-01
    z[5,4,0]  R2815     4.8107045888900757e-01
    z[5,4,0]  R2816     0.0420943982899189
    z[5,4,0]  R2817     2.2906219959259033e-01
    z[5,4,0]  R2818     3.0979016795754433e-02
    z[5,4,0]  R2819     -1.0578852146863937e-01
    z[5,4,0]  R2820     3.5713267326354980e-01
    z[5,4,0]  R2821     0.481503427028656
    z[5,4,0]  R2822     0.350081205368042
    z[5,4,0]  R2823     4.4970616698265076e-01
    z[5,4,0]  R2824     1.2914520502090454e-01
    z[5,4,0]  R2825     4.7862935066223145e-01
    z[5,4,0]  R2826     -0.0339871309697628
    z[5,4,0]  R2827     2.8752669692039490e-01
    z[5,4,0]  R2828     4.5326313376426697e-01
    z[5,4,0]  R2829     3.3613637089729309e-01
    z[5,4,0]  R2830     2.0278221368789673e-01
    z[5,4,0]  R2831     6.6347676515579224e-01
    z[5,4,0]  R2832     -2.4898461997509003e-01
    z[5,4,0]  R2833     4.6122840046882629e-01
    z[5,4,0]  R2834     4.9284663796424866e-01
    z[5,4,0]  R2835     4.1822734475135803e-01
    z[5,4,0]  R2836     4.8851454257965088e-01
    z[5,4,0]  R2837     3.4320834279060364e-01
    z[5,4,0]  R2838     1.8371088802814484e-01
    z[5,4,0]  R2839     3.1019492074847221e-02
    z[5,4,0]  R2840     7.1308411657810211e-02
    z[5,4,0]  R2841     -3.9650008082389832e-01
    z[5,4,0]  R2842     5.1104658842086792e-01
    z[5,4,0]  R2843     5.1345431804656982e-01
    z[5,4,0]  R2844     9.9075190722942352e-02
    z[5,4,0]  R2845     1.3918174803256989e-01
    z[5,4,0]  R2846     1.0309685766696930e-01
    z[5,4,0]  R2847     1.3891510665416718e-02
    z[5,4,0]  R2848     6.8562909960746765e-02
    z[5,4,0]  R2849     -6.5475896000862122e-02
    z[5,4,0]  R2850     -2.6827117800712585e-01
    z[5,4,0]  R2851     -4.4537249207496643e-01
    z[5,4,0]  R2852     -5.1074630022048950e-01
    z[5,4,0]  R2853     -5.2198320627212524e-01
    z[5,4,0]  R2854     1.4921683818101883e-02
    z[5,4,0]  R2855     -9.6592712402343750e-01
    z[5,4,0]  R2856     8.0585852265357971e-02
    z[5,4,0]  R2857     -1.7927173525094986e-02
    z[5,4,0]  R2858     3.2609567046165466e-02
    z[5,4,0]  R2859     -2.4398061633110046e-01
    z[5,4,0]  R2860     -1.0867832228541374e-02
    z[5,4,0]  R2861     0.331209659576416
    z[5,4,0]  R2862     3.7573602795600891e-01
    z[5,4,0]  R2863     4.9842461943626404e-01
    z[5,4,0]  R2864     3.3839711546897888e-01
    z[5,4,0]  R2865     3.7496492266654968e-01
    z[5,4,0]  R2866     3.4600558876991272e-01
    z[5,4,0]  R2867     2.5181302428245544e-01
    z[5,4,0]  R2868     1.5387284755706787e-01
    z[5,4,0]  R2869     3.2433813810348511e-01
    z[5,4,0]  R2870     2.0987780392169952e-01
    z[5,4,0]  R2871     2.4177080392837524e-01
    z[5,4,0]  R2872     -1.7149411141872406e-01
    z[5,4,0]  R2873     -1.1276394070591778e-04
    z[5,4,0]  R2874     0.299360454082489
    z[5,4,0]  R2875     1.8625383079051971e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2769     -1
    z[5,4,1]  R2770     1
    z[5,4,1]  R2781     8.5575813427567482e-03
    z[5,4,1]  R2782     1.4072133600711823e-01
    z[5,4,1]  R2783     -2.6882013678550720e-01
    z[5,4,1]  R2784     -1.2652019038796425e-02
    z[5,4,1]  R2785     3.0407634377479553e-01
    z[5,4,1]  R2786     5.1733434200286865e-01
    z[5,4,1]  R2787     1.8734943866729736e-01
    z[5,4,1]  R2788     1.8706493079662323e-02
    z[5,4,1]  R2789     -6.2197268009185791e-01
    z[5,4,1]  R2790     -6.0173243284225464e-01
    z[5,4,1]  R2791     -0.541064977645874
    z[5,4,1]  R2792     -7.0541268587112427e-01
    z[5,4,1]  R2793     -0.561692476272583
    z[5,4,1]  R2794     -5.9705138206481934e-01
    z[5,4,1]  R2795     8.4480911493301392e-01
    z[5,4,1]  R2796     -2.9515042901039124e-01
    z[5,4,1]  R2797     -5.9425985813140869e-01
    z[5,4,1]  R2798     7.0331460237503052e-01
    z[5,4,1]  R2799     5.4043614864349365e-01
    z[5,4,1]  R2800     -4.5522215962409973e-01
    z[5,4,1]  R2801     -4.3140354752540588e-01
    z[5,4,1]  R2802     3.7732613086700439e-01
    z[5,4,1]  R2803     8.4820365905761719e-01
    z[5,4,1]  R2804     6.9910007715225220e-01
    z[5,4,1]  R2805     6.6943019628524780e-01
    z[5,4,1]  R2806     0.597454845905304
    z[5,4,1]  R2807     6.0251086950302124e-01
    z[5,4,1]  R2808     5.7777369022369385e-01
    z[5,4,1]  R2809     6.0641765594482422e-01
    z[5,4,1]  R2810     0.650162935256958
    z[5,4,1]  R2811     -5.0807815790176392e-01
    z[5,4,1]  R2812     5.8061248064041138e-01
    z[5,4,1]  R2813     -1.7243736982345581e-01
    z[5,4,1]  R2814     -5.6971997022628784e-01
    z[5,4,1]  R2815     -5.5164480209350586e-01
    z[5,4,1]  R2816     -4.0834445506334305e-02
    z[5,4,1]  R2817     1.3132227957248688e-01
    z[5,4,1]  R2818     -5.1098912954330444e-02
    z[5,4,1]  R2819     2.9433953762054443e-01
    z[5,4,1]  R2820     -2.1766616404056549e-01
    z[5,4,1]  R2821     -5.3306269645690918e-01
    z[5,4,1]  R2822     -3.5644170641899109e-01
    z[5,4,1]  R2823     -3.5504448413848877e-01
    z[5,4,1]  R2824     -5.8893674612045288e-01
    z[5,4,1]  R2825     -4.9673485755920410e-01
    z[5,4,1]  R2826     1.1629262566566467e-01
    z[5,4,1]  R2827     -4.4587850570678711e-01
    z[5,4,1]  R2828     -1.3600496947765350e-01
    z[5,4,1]  R2829     -5.9690237045288086e-01
    z[5,4,1]  R2830     7.1867331862449646e-02
    z[5,4,1]  R2831     2.4152347818017006e-02
    z[5,4,1]  R2832     8.4414738416671753e-01
    z[5,4,1]  R2833     0.718745231628418
    z[5,4,1]  R2834     -4.8123809695243835e-01
    z[5,4,1]  R2835     -3.2860276103019714e-01
    z[5,4,1]  R2836     -6.6047638654708862e-01
    z[5,4,1]  R2837     -1.4736685156822205e-01
    z[5,4,1]  R2838     2.6722899079322815e-01
    z[5,4,1]  R2839     -3.5031118988990784e-01
    z[5,4,1]  R2840     -0.500552237033844
    z[5,4,1]  R2841     -3.4786400198936462e-01
    z[5,4,1]  R2842     -5.2081096172332764e-01
    z[5,4,1]  R2843     -5.9718823432922363e-01
    z[5,4,1]  R2844     -5.9593987464904785e-01
    z[5,4,1]  R2845     -3.3485185354948044e-02
    z[5,4,1]  R2846     2.0150625705718994e-01
    z[5,4,1]  R2847     4.2572334408760071e-02
    z[5,4,1]  R2848     -0.365588903427124
    z[5,4,1]  R2849     1.8889233469963074e-02
    z[5,4,1]  R2850     1.7349785566329956e-01
    z[5,4,1]  R2851     0.665277361869812
    z[5,4,1]  R2852     5.7158994674682617e-01
    z[5,4,1]  R2853     4.0337088704109192e-01
    z[5,4,1]  R2854     7.5647455453872681e-01
    z[5,4,1]  R2855     7.8719764947891235e-02
    z[5,4,1]  R2856     -6.6353100538253784e-01
    z[5,4,1]  R2857     -5.6738960742950439e-01
    z[5,4,1]  R2858     -0.539656400680542
    z[5,4,1]  R2859     -7.3659688234329224e-01
    z[5,4,1]  R2860     2.8826889395713806e-01
    z[5,4,1]  R2861     -7.7573865652084351e-01
    z[5,4,1]  R2862     -7.6019245386123657e-01
    z[5,4,1]  R2863     -6.0532516241073608e-01
    z[5,4,1]  R2864     -7.0515912771224976e-01
    z[5,4,1]  R2865     -6.2775951623916626e-01
    z[5,4,1]  R2866     -6.5205973386764526e-01
    z[5,4,1]  R2867     -7.5500094890594482e-01
    z[5,4,1]  R2868     -0.685711681842804
    z[5,4,1]  R2869     -5.7793557643890381e-01
    z[5,4,1]  R2870     -6.6598445177078247e-01
    z[5,4,1]  R2871     -6.6299033164978027e-01
    z[5,4,1]  R2872     2.1881558932363987e-03
    z[5,4,1]  R2873     1.9273987039923668e-02
    z[5,4,1]  R2874     5.7013678550720215e-01
    z[5,4,1]  R2875     6.1896014213562012e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2771     -1
    z[5,4,2]  R2772     1
    z[5,4,2]  R2781     -2.5082439184188843e-01
    z[5,4,2]  R2782     -4.9486222863197327e-01
    z[5,4,2]  R2783     -8.3715015649795532e-01
    z[5,4,2]  R2784     -6.9883072376251221e-01
    z[5,4,2]  R2785     -8.6587077379226685e-01
    z[5,4,2]  R2786     -4.6348148584365845e-01
    z[5,4,2]  R2787     -0.835545003414154
    z[5,4,2]  R2788     -3.9633882045745850e-01
    z[5,4,2]  R2789     1.9898726046085358e-01
    z[5,4,2]  R2790     3.1680113077163696e-01
    z[5,4,2]  R2791     4.7050195932388306e-01
    z[5,4,2]  R2792     5.2155035734176636e-01
    z[5,4,2]  R2793     4.4924122095108032e-01
    z[5,4,2]  R2794     5.2330291271209717e-01
    z[5,4,2]  R2795     2.3753516376018524e-01
    z[5,4,2]  R2796     0.685438334941864
    z[5,4,2]  R2797     4.8933586478233337e-01
    z[5,4,2]  R2798     3.0118945240974426e-01
    z[5,4,2]  R2799     3.3472895622253418e-01
    z[5,4,2]  R2800     0.550088107585907
    z[5,4,2]  R2801     -1.4015612006187439e-01
    z[5,4,2]  R2802     3.8528403639793396e-01
    z[5,4,2]  R2803     3.6292123794555664e-01
    z[5,4,2]  R2804     1.1737194657325745e-01
    z[5,4,2]  R2805     1.4842732250690460e-01
    z[5,4,2]  R2806     2.1074037998914719e-02
    z[5,4,2]  R2807     1.3993789255619049e-01
    z[5,4,2]  R2808     1.3967829942703247e-01
    z[5,4,2]  R2809     5.2091282606124878e-01
    z[5,4,2]  R2810     2.3172754049301147e-01
    z[5,4,2]  R2811     0.0881069228053093
    z[5,4,2]  R2812     3.4890773892402649e-01
    z[5,4,2]  R2813     9.3202881515026093e-02
    z[5,4,2]  R2814     2.4517005681991577e-01
    z[5,4,2]  R2815     3.7510260939598083e-01
    z[5,4,2]  R2816     -1.1677806824445724e-01
    z[5,4,2]  R2817     1.2375617772340775e-01
    z[5,4,2]  R2818     1.3580541312694550e-01
    z[5,4,2]  R2819     -4.8568150959908962e-03
    z[5,4,2]  R2820     4.2193382978439331e-01
    z[5,4,2]  R2821     5.0784224271774292e-01
    z[5,4,2]  R2822     6.4672106504440308e-01
    z[5,4,2]  R2823     4.5124414563179016e-01
    z[5,4,2]  R2824     7.5461500883102417e-01
    z[5,4,2]  R2825     4.1927462816238403e-01
    z[5,4,2]  R2826     -1.3850663602352142e-01
    z[5,4,2]  R2827     6.0157597064971924e-01
    z[5,4,2]  R2828     7.0908397436141968e-01
    z[5,4,2]  R2829     2.0411163568496704e-01
    z[5,4,2]  R2830     0.0621710866689682
    z[5,4,2]  R2831     1.0683589428663254e-01
    z[5,4,2]  R2832     2.4507471919059753e-01
    z[5,4,2]  R2833     -0.00966144260019064
    z[5,4,2]  R2834     5.8281403779983521e-01
    z[5,4,2]  R2835     5.8617675304412842e-01
    z[5,4,2]  R2836     4.8749116063117981e-01
    z[5,4,2]  R2837     8.3031928539276123e-01
    z[5,4,2]  R2838     6.2518283724784851e-02
    z[5,4,2]  R2839     -2.0371995866298676e-01
    z[5,4,2]  R2840     7.6282203197479248e-01
    z[5,4,2]  R2841     9.7577020525932312e-02
    z[5,4,2]  R2842     6.3724607229232788e-01
    z[5,4,2]  R2843     0.546921968460083
    z[5,4,2]  R2844     7.2423154115676880e-01
    z[5,4,2]  R2845     -2.3010337352752686e-01
    z[5,4,2]  R2846     2.2679027169942856e-02
    z[5,4,2]  R2847     1.8637599050998688e-01
    z[5,4,2]  R2848     8.1958460807800293e-01
    z[5,4,2]  R2849     3.5175395011901855e-01
    z[5,4,2]  R2850     0.812131404876709
    z[5,4,2]  R2851     -3.3246603608131409e-01
    z[5,4,2]  R2852     -3.3024686574935913e-01
    z[5,4,2]  R2853     -3.8213226199150085e-01
    z[5,4,2]  R2854     -5.9999954700469971e-01
    z[5,4,2]  R2855     -1.8448592722415924e-01
    z[5,4,2]  R2856     4.5519477128982544e-01
    z[5,4,2]  R2857     -1.3045579195022583e-01
    z[5,4,2]  R2858     -2.9634529352188110e-01
    z[5,4,2]  R2859     4.5163431763648987e-01
    z[5,4,2]  R2860     0.0443992018699646
    z[5,4,2]  R2861     4.3069524690508842e-03
    z[5,4,2]  R2862     -2.0378093421459198e-01
    z[5,4,2]  R2863     -2.0583665370941162e-01
    z[5,4,2]  R2864     -0.601309597492218
    z[5,4,2]  R2865     7.6408926397562027e-03
    z[5,4,2]  R2866     -2.1865795552730560e-01
    z[5,4,2]  R2867     -5.1944029331207275e-01
    z[5,4,2]  R2868     2.9603847861289978e-01
    z[5,4,2]  R2869     -1.8319685757160187e-01
    z[5,4,2]  R2870     5.0144165754318237e-01
    z[5,4,2]  R2871     3.1911796331405640e-01
    z[5,4,2]  R2872     -5.3569239377975464e-01
    z[5,4,2]  R2873     -5.2974373102188110e-01
    z[5,4,2]  R2874     3.3966198563575745e-01
    z[5,4,2]  R2875     6.2364935874938965e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2773     -1
    z[5,4,3]  R2774     1
    z[5,4,3]  R2781     5.9576869010925293e-01
    z[5,4,3]  R2782     3.9372414350509644e-01
    z[5,4,3]  R2783     1.3222867250442505e-01
    z[5,4,3]  R2784     6.4013522863388062e-01
    z[5,4,3]  R2785     1.5869811177253723e-01
    z[5,4,3]  R2786     6.4389592409133911e-01
    z[5,4,3]  R2787     2.3036353290081024e-01
    z[5,4,3]  R2788     4.4051659107208252e-01
    z[5,4,3]  R2789     1.5037453733384609e-02
    z[5,4,3]  R2790     7.1662895381450653e-02
    z[5,4,3]  R2791     -1.1776566505432129e-01
    z[5,4,3]  R2792     -1.3404813408851624e-01
    z[5,4,3]  R2793     -1.9995562732219696e-01
    z[5,4,3]  R2794     -4.2782168835401535e-02
    z[5,4,3]  R2795     -3.0475902557373047e-01
    z[5,4,3]  R2796     -4.1686594486236572e-01
    z[5,4,3]  R2797     -3.8454201817512512e-01
    z[5,4,3]  R2798     -5.1275640726089478e-01
    z[5,4,3]  R2799     -4.1546443104743958e-01
    z[5,4,3]  R2800     -3.2571017742156982e-01
    z[5,4,3]  R2801     -1.3579273223876953e-01
    z[5,4,3]  R2802     1.1743741482496262e-01
    z[5,4,3]  R2803     -9.0006791055202484e-02
    z[5,4,3]  R2804     -3.6825048923492432e-01
    z[5,4,3]  R2805     -5.0619250535964966e-01
    z[5,4,3]  R2806     -5.6021952629089355e-01
    z[5,4,3]  R2807     -3.8618949055671692e-01
    z[5,4,3]  R2808     -3.2842054963111877e-01
    z[5,4,3]  R2809     -3.1660124659538269e-01
    z[5,4,3]  R2810     -3.8760277628898621e-01
    z[5,4,3]  R2811     -2.8610104322433472e-01
    z[5,4,3]  R2812     3.0981364846229553e-01
    z[5,4,3]  R2813     4.0037342905998230e-01
    z[5,4,3]  R2814     -5.9528566896915436e-02
    z[5,4,3]  R2815     -3.6331480741500854e-01
    z[5,4,3]  R2816     -8.4577780961990356e-01
    z[5,4,3]  R2817     -7.9938125610351562e-01
    z[5,4,3]  R2818     -0.662041962146759
    z[5,4,3]  R2819     -0.797913670539856
    z[5,4,3]  R2820     -4.7221881151199341e-01
    z[5,4,3]  R2821     -6.7318767309188843e-02
    z[5,4,3]  R2822     -1.2998647987842560e-01
    z[5,4,3]  R2823     -4.8076048493385315e-01
    z[5,4,3]  R2824     9.2176847159862518e-02
    z[5,4,3]  R2825     -5.8152031898498535e-01
    z[5,4,3]  R2826     -8.3289182186126709e-01
    z[5,4,3]  R2827     -5.7208532094955444e-01
    z[5,4,3]  R2828     -3.0186501145362854e-01
    z[5,4,3]  R2829     -5.2364188432693481e-01
    z[5,4,3]  R2830     -8.4814244508743286e-01
    z[5,4,3]  R2831     4.1239511966705322e-01
    z[5,4,3]  R2832     -4.8379480838775635e-02
    z[5,4,3]  R2833     -4.6403801441192627e-01
    z[5,4,3]  R2834     -4.0619453787803650e-01
    z[5,4,3]  R2835     -4.2855963110923767e-01
    z[5,4,3]  R2836     5.4446242749691010e-02
    z[5,4,3]  R2837     -3.3980420231819153e-01
    z[5,4,3]  R2838     -0.851863443851471
    z[5,4,3]  R2839     -8.3771157264709473e-01
    z[5,4,3]  R2840     -9.4819359481334686e-02
    z[5,4,3]  R2841     -0.722500741481781
    z[5,4,3]  R2842     -2.0860888063907623e-01
    z[5,4,3]  R2843     -2.0605309307575226e-01
    z[5,4,3]  R2844     2.8400283306837082e-02
    z[5,4,3]  R2845     -0.847332775592804
    z[5,4,3]  R2846     -8.6517196893692017e-01
    z[5,4,3]  R2847     -6.3254356384277344e-01
    z[5,4,3]  R2848     -2.6408711075782776e-01
    z[5,4,3]  R2849     -7.7237951755523682e-01
    z[5,4,3]  R2850     3.1130319833755493e-01
    z[5,4,3]  R2851     6.1623834073543549e-02
    z[5,4,3]  R2852     1.2031611055135727e-01
    z[5,4,3]  R2853     -1.0835071653127670e-01
    z[5,4,3]  R2854     1.6698566079139709e-01
    z[5,4,3]  R2855     -8.0087609589099884e-02
    z[5,4,3]  R2856     5.4327648133039474e-02
    z[5,4,3]  R2857     -5.7724362611770630e-01
    z[5,4,3]  R2858     1.4700695872306824e-01
    z[5,4,3]  R2859     1.0272392630577087e-01
    z[5,4,3]  R2860     8.5961920022964478e-01
    z[5,4,3]  R2861     -2.4001386761665344e-01
    z[5,4,3]  R2862     1.8896806240081787e-01
    z[5,4,3]  R2863     -0.388874351978302
    z[5,4,3]  R2864     1.1385331302881241e-01
    z[5,4,3]  R2865     3.0618848279118538e-02
    z[5,4,3]  R2866     5.8276718854904175e-01
    z[5,4,3]  R2867     -4.3951552361249924e-02
    z[5,4,3]  R2868     3.5840559005737305e-01
    z[5,4,3]  R2869     1.5175801515579224e-01
    z[5,4,3]  R2870     1.3548615574836731e-01
    z[5,4,3]  R2871     -7.3759861290454865e-02
    z[5,4,3]  R2872     -6.4899915456771851e-01
    z[5,4,3]  R2873     -3.1279709935188293e-01
    z[5,4,3]  R2874     -6.1535632610321045e-01
    z[5,4,3]  R2875     -2.5307220220565796e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2775     -1
    z[5,4,4]  R2776     1
    z[5,4,4]  R2781     -1.4564444124698639e-01
    z[5,4,4]  R2782     3.8416441529989243e-02
    z[5,4,4]  R2783     1.7567806644365191e-03
    z[5,4,4]  R2784     2.4478648602962494e-01
    z[5,4,4]  R2785     9.6992768347263336e-02
    z[5,4,4]  R2786     2.1350033581256866e-01
    z[5,4,4]  R2787     -2.7428719401359558e-01
    z[5,4,4]  R2788     6.8304139375686646e-01
    z[5,4,4]  R2789     1.2113102525472641e-01
    z[5,4,4]  R2790     2.5525709614157677e-02
    z[5,4,4]  R2791     -2.7946668863296509e-01
    z[5,4,4]  R2792     2.1172559261322021e-01
    z[5,4,4]  R2793     -1.7210589349269867e-01
    z[5,4,4]  R2794     2.4047857522964478e-01
    z[5,4,4]  R2795     1.0388135910034180e-02
    z[5,4,4]  R2796     2.1524070203304291e-01
    z[5,4,4]  R2797     -3.8811179995536804e-01
    z[5,4,4]  R2798     1.0021328926086426e-01
    z[5,4,4]  R2799     -4.2036247253417969e-01
    z[5,4,4]  R2800     -2.8724148869514465e-01
    z[5,4,4]  R2801     -9.4732575118541718e-02
    z[5,4,4]  R2802     -4.5010432600975037e-01
    z[5,4,4]  R2803     -2.0135407149791718e-01
    z[5,4,4]  R2804     -2.9905600473284721e-02
    z[5,4,4]  R2805     0.159097358584404
    z[5,4,4]  R2806     3.3481064438819885e-01
    z[5,4,4]  R2807     -2.0056806504726410e-01
    z[5,4,4]  R2808     8.6779326200485229e-02
    z[5,4,4]  R2809     1.1984530836343765e-02
    z[5,4,4]  R2810     -0.496004581451416
    z[5,4,4]  R2811     -0.531998336315155
    z[5,4,4]  R2812     -6.1312294006347656e-01
    z[5,4,4]  R2813     -5.4920804500579834e-01
    z[5,4,4]  R2814     1.8354912102222443e-01
    z[5,4,4]  R2815     -0.276263952255249
    z[5,4,4]  R2816     -4.0148639678955078e-01
    z[5,4,4]  R2817     -4.6598100662231445e-01
    z[5,4,4]  R2818     -4.0774139761924744e-01
    z[5,4,4]  R2819     -4.0382185578346252e-01
    z[5,4,4]  R2820     5.0118589401245117e-01
    z[5,4,4]  R2821     2.6180425286293030e-01
    z[5,4,4]  R2822     -0.282550573348999
    z[5,4,4]  R2823     -6.2645196914672852e-02
    z[5,4,4]  R2824     -1.2329094856977463e-01
    z[5,4,4]  R2825     -0.0234454907476902
    z[5,4,4]  R2826     -1.5201459825038910e-01
    z[5,4,4]  R2827     -1.1735180765390396e-01
    z[5,4,4]  R2828     5.4263092577457428e-02
    z[5,4,4]  R2829     1.4913311600685120e-01
    z[5,4,4]  R2830     -2.5151485204696655e-01
    z[5,4,4]  R2831     -5.0076740980148315e-01
    z[5,4,4]  R2832     3.4647189080715179e-02
    z[5,4,4]  R2833     1.5218664705753326e-01
    z[5,4,4]  R2834     -0.0744100883603096
    z[5,4,4]  R2835     -1.8353520333766937e-01
    z[5,4,4]  R2836     1.3839547336101532e-01
    z[5,4,4]  R2837     4.5360937714576721e-02
    z[5,4,4]  R2838     -2.7728980779647827e-01
    z[5,4,4]  R2839     -8.2025587558746338e-02
    z[5,4,4]  R2840     1.3995287939906120e-02
    z[5,4,4]  R2841     1.8421135842800140e-01
    z[5,4,4]  R2842     -1.1290358752012253e-01
    z[5,4,4]  R2843     1.5742288529872894e-01
    z[5,4,4]  R2844     -1.0554249398410320e-02
    z[5,4,4]  R2845     -1.9067689776420593e-01
    z[5,4,4]  R2846     -3.3969292044639587e-01
    z[5,4,4]  R2847     -5.9137541055679321e-01
    z[5,4,4]  R2848     -1.1788047850131989e-01
    z[5,4,4]  R2849     -2.7381590008735657e-01
    z[5,4,4]  R2850     3.5458293557167053e-01
    z[5,4,4]  R2851     9.6880055963993073e-02
    z[5,4,4]  R2852     2.8017762303352356e-01
    z[5,4,4]  R2853     -2.7349710464477539e-01
    z[5,4,4]  R2854     1.7739698290824890e-01
    z[5,4,4]  R2855     -2.9830446466803551e-02
    z[5,4,4]  R2856     5.0163465738296509e-01
    z[5,4,4]  R2857     -2.0905299112200737e-02
    z[5,4,4]  R2858     9.0793631970882416e-02
    z[5,4,4]  R2859     -4.2723834514617920e-01
    z[5,4,4]  R2860     -3.7313145399093628e-01
    z[5,4,4]  R2861     -2.1621921658515930e-01
    z[5,4,4]  R2862     -9.6813194453716278e-02
    z[5,4,4]  R2863     3.7031877040863037e-01
    z[5,4,4]  R2864     6.5757364034652710e-02
    z[5,4,4]  R2865     -2.7775904163718224e-02
    z[5,4,4]  R2866     -1.0947525501251221e-01
    z[5,4,4]  R2867     -1.0854104906320572e-01
    z[5,4,4]  R2868     -2.5228586792945862e-01
    z[5,4,4]  R2869     -6.6569441556930542e-01
    z[5,4,4]  R2870     -1.9893574714660645e-01
    z[5,4,4]  R2871     1.3082090020179749e-01
    z[5,4,4]  R2872     3.8038212805986404e-02
    z[5,4,4]  R2873     -6.0758739709854126e-01
    z[5,4,4]  R2874     -1.3361072167754173e-02
    z[5,4,4]  R2875     8.8092230260372162e-02
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2777     -1
    z[5,4,5]  R2778     1
    z[5,4,5]  R2781     -6.1933767795562744e-01
    z[5,4,5]  R2782     -6.4784586429595947e-01
    z[5,4,5]  R2783     -3.0371937155723572e-01
    z[5,4,5]  R2784     -5.0053298473358154e-02
    z[5,4,5]  R2785     -3.3766743727028370e-03
    z[5,4,5]  R2786     0.0362824983894825
    z[5,4,5]  R2787     1.8293833732604980e-01
    z[5,4,5]  R2788     -1.8776687979698181e-01
    z[5,4,5]  R2789     -5.7682663202285767e-02
    z[5,4,5]  R2790     -0.0266642477363348
    z[5,4,5]  R2791     3.4906172752380371e-01
    z[5,4,5]  R2792     1.1849937587976456e-01
    z[5,4,5]  R2793     5.4500085115432739e-01
    z[5,4,5]  R2794     2.6853027939796448e-01
    z[5,4,5]  R2795     -3.2048285007476807e-01
    z[5,4,5]  R2796     3.7137782573699951e-01
    z[5,4,5]  R2797     1.8925306200981140e-01
    z[5,4,5]  R2798     2.7644780930131674e-03
    z[5,4,5]  R2799     1.9587117433547974e-01
    z[5,4,5]  R2800     2.6655626296997070e-01
    z[5,4,5]  R2801     6.3775390386581421e-01
    z[5,4,5]  R2802     2.7203616499900818e-01
    z[5,4,5]  R2803     -2.9853606224060059e-01
    z[5,4,5]  R2804     2.7603876590728760e-01
    z[5,4,5]  R2805     -5.6742765009403229e-02
    z[5,4,5]  R2806     1.1412044614553452e-01
    z[5,4,5]  R2807     -5.1465284079313278e-02
    z[5,4,5]  R2808     -1.3932244479656219e-01
    z[5,4,5]  R2809     -2.9125756118446589e-03
    z[5,4,5]  R2810     -2.9701529070734978e-02
    z[5,4,5]  R2811     -3.7494511343538761e-03
    z[5,4,5]  R2812     3.4458752721548080e-02
    z[5,4,5]  R2813     3.0400335788726807e-01
    z[5,4,5]  R2814     5.9104061126708984e-01
    z[5,4,5]  R2815     -0.0534505657851696
    z[5,4,5]  R2816     1.9277544319629669e-01
    z[5,4,5]  R2817     2.4191319942474365e-01
    z[5,4,5]  R2818     5.5073505640029907e-01
    z[5,4,5]  R2819     3.1129565834999084e-01
    z[5,4,5]  R2820     3.4153786301612854e-01
    z[5,4,5]  R2821     3.9113840460777283e-01
    z[5,4,5]  R2822     4.2109638452529907e-01
    z[5,4,5]  R2823     4.3957060575485229e-01
    z[5,4,5]  R2824     1.9891719520092010e-01
    z[5,4,5]  R2825     -5.1018454134464264e-02
    z[5,4,5]  R2826     4.7241061925888062e-01
    z[5,4,5]  R2827     -1.1062230169773102e-01
    z[5,4,5]  R2828     2.1643431484699249e-01
    z[5,4,5]  R2829     4.2171150445938110e-01
    z[5,4,5]  R2830     3.6347669363021851e-01
    z[5,4,5]  R2831     2.6701900362968445e-01
    z[5,4,5]  R2832     -2.6293733716011047e-01
    z[5,4,5]  R2833     -1.1496489495038986e-01
    z[5,4,5]  R2834     0.0418475866317749
    z[5,4,5]  R2835     3.5667872428894043e-01
    z[5,4,5]  R2836     -1.0689385980367661e-01
    z[5,4,5]  R2837     2.3131118714809418e-01
    z[5,4,5]  R2838     2.0413130521774292e-01
    z[5,4,5]  R2839     3.2589516043663025e-01
    z[5,4,5]  R2840     -1.9784484058618546e-02
    z[5,4,5]  R2841     5.9179648756980896e-02
    z[5,4,5]  R2842     7.2134897112846375e-02
    z[5,4,5]  R2843     1.1516427993774414e-01
    z[5,4,5]  R2844     3.3080011606216431e-01
    z[5,4,5]  R2845     4.1496536135673523e-01
    z[5,4,5]  R2846     2.4856556951999664e-01
    z[5,4,5]  R2847     4.6000748872756958e-01
    z[5,4,5]  R2848     -5.1871344447135925e-02
    z[5,4,5]  R2849     3.1858170032501221e-01
    z[5,4,5]  R2850     8.2440860569477081e-02
    z[5,4,5]  R2851     -3.8344261050224304e-01
    z[5,4,5]  R2852     -2.4632996320724487e-01
    z[5,4,5]  R2853     -4.6027606725692749e-01
    z[5,4,5]  R2854     7.6073859818279743e-03
    z[5,4,5]  R2855     -1.3433896005153656e-01
    z[5,4,5]  R2856     1.5455786883831024e-01
    z[5,4,5]  R2857     -2.7092182636260986e-01
    z[5,4,5]  R2858     7.6671266555786133e-01
    z[5,4,5]  R2859     2.8965758159756660e-02
    z[5,4,5]  R2860     -1.5829353034496307e-01
    z[5,4,5]  R2861     -4.2344415187835693e-01
    z[5,4,5]  R2862     -3.0616271495819092e-01
    z[5,4,5]  R2863     -5.2750091999769211e-02
    z[5,4,5]  R2864     -8.3749219775199890e-02
    z[5,4,5]  R2865     3.5495933890342712e-01
    z[5,4,5]  R2866     2.2453854978084564e-01
    z[5,4,5]  R2867     1.8640884757041931e-01
    z[5,4,5]  R2868     -7.0749111473560333e-02
    z[5,4,5]  R2869     2.3678185045719147e-01
    z[5,4,5]  R2870     3.0017700791358948e-01
    z[5,4,5]  R2871     4.8381257057189941e-01
    z[5,4,5]  R2872     3.3239677548408508e-01
    z[5,4,5]  R2873     1.4385271072387695e-01
    z[5,4,5]  R2874     2.0954367518424988e-01
    z[5,4,5]  R2875     2.6355904340744019e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2779     -1
    z[5,4,6]  R2780     1
    z[5,4,6]  R2781     -8.8365182280540466e-02
    z[5,4,6]  R2782     -3.9545637369155884e-01
    z[5,4,6]  R2783     5.7798791676759720e-02
    z[5,4,6]  R2784     -1.3976109027862549e-01
    z[5,4,6]  R2785     3.2563191652297974e-01
    z[5,4,6]  R2786     3.4999959170818329e-02
    z[5,4,6]  R2787     1.8482497334480286e-01
    z[5,4,6]  R2788     3.5145051777362823e-02
    z[5,4,6]  R2789     1.9077347218990326e-01
    z[5,4,6]  R2790     -3.4835245460271835e-02
    z[5,4,6]  R2791     -1.4184023439884186e-01
    z[5,4,6]  R2792     -1.6157792508602142e-01
    z[5,4,6]  R2793     1.4025190472602844e-01
    z[5,4,6]  R2794     3.3324298262596130e-01
    z[5,4,6]  R2795     1.6489909589290619e-01
    z[5,4,6]  R2796     -1.6969369351863861e-01
    z[5,4,6]  R2797     4.1545432060956955e-02
    z[5,4,6]  R2798     3.2960101962089539e-01
    z[5,4,6]  R2799     9.5377013087272644e-02
    z[5,4,6]  R2800     3.6477804183959961e-01
    z[5,4,6]  R2801     -3.2919496297836304e-01
    z[5,4,6]  R2802     -1.0445023328065872e-01
    z[5,4,6]  R2803     8.2382082939147949e-02
    z[5,4,6]  R2804     9.5949888229370117e-02
    z[5,4,6]  R2805     3.4505769610404968e-01
    z[5,4,6]  R2806     -5.6673612445592880e-02
    z[5,4,6]  R2807     4.2273110151290894e-01
    z[5,4,6]  R2808     -3.5286897420883179e-01
    z[5,4,6]  R2809     -1.8022920191287994e-01
    z[5,4,6]  R2810     9.2139437794685364e-02
    z[5,4,6]  R2811     5.0284836441278458e-02
    z[5,4,6]  R2812     1.9310359656810760e-01
    z[5,4,6]  R2813     -2.2523060441017151e-01
    z[5,4,6]  R2814     -1.0507960803806782e-02
    z[5,4,6]  R2815     3.3523243665695190e-01
    z[5,4,6]  R2816     0.263115257024765
    z[5,4,6]  R2817     -0.0172833651304245
    z[5,4,6]  R2818     2.6480999588966370e-01
    z[5,4,6]  R2819     -0.0742039605975151
    z[5,4,6]  R2820     2.3711478710174561e-01
    z[5,4,6]  R2821     5.6914114393293858e-03
    z[5,4,6]  R2822     2.4102061986923218e-01
    z[5,4,6]  R2823     -1.9952252507209778e-01
    z[5,4,6]  R2824     6.1366468667984009e-02
    z[5,4,6]  R2825     8.4016129374504089e-02
    z[5,4,6]  R2826     -1.6170255839824677e-01
    z[5,4,6]  R2827     5.7765308767557144e-02
    z[5,4,6]  R2828     3.6379155516624451e-01
    z[5,4,6]  R2829     -1.2155794352293015e-01
    z[5,4,6]  R2830     1.8742622435092926e-01
    z[5,4,6]  R2831     -2.3593294620513916e-01
    z[5,4,6]  R2832     3.0443921685218811e-01
    z[5,4,6]  R2833     -1.3737358152866364e-01
    z[5,4,6]  R2834     1.1643828451633453e-01
    z[5,4,6]  R2835     1.7010244727134705e-01
    z[5,4,6]  R2836     0.232234388589859
    z[5,4,6]  R2837     -5.6208237074315548e-03
    z[5,4,6]  R2838     -2.1610192954540253e-01
    z[5,4,6]  R2839     1.4185032248497009e-01
    z[5,4,6]  R2840     -0.391007661819458
    z[5,4,6]  R2841     -3.9091381430625916e-01
    z[5,4,6]  R2842     -6.0242330655455589e-03
    z[5,4,6]  R2843     1.0224212892353535e-02
    z[5,4,6]  R2844     1.3477612286806107e-02
    z[5,4,6]  R2845     5.7424264959990978e-03
    z[5,4,6]  R2846     -1.5017724037170410e-01
    z[5,4,6]  R2847     -4.2608477175235748e-02
    z[5,4,6]  R2848     -3.2186403870582581e-01
    z[5,4,6]  R2849     -3.1398364901542664e-01
    z[5,4,6]  R2850     0.0945323258638382
    z[5,4,6]  R2851     2.9716029763221741e-01
    z[5,4,6]  R2852     -3.8691893219947815e-01
    z[5,4,6]  R2853     -3.4699544310569763e-01
    z[5,4,6]  R2854     9.0068168938159943e-02
    z[5,4,6]  R2855     -3.7443239241838455e-02
    z[5,4,6]  R2856     -0.259909987449646
    z[5,4,6]  R2857     -5.0366961956024170e-01
    z[5,4,6]  R2858     4.6736735850572586e-02
    z[5,4,6]  R2859     -1.0265648597851396e-03
    z[5,4,6]  R2860     -1.0762225091457367e-01
    z[5,4,6]  R2861     0.0696331113576889
    z[5,4,6]  R2862     3.1715276837348938e-01
    z[5,4,6]  R2863     2.2725264728069305e-01
    z[5,4,6]  R2864     -4.8621557652950287e-02
    z[5,4,6]  R2865     5.8099544048309326e-01
    z[5,4,6]  R2866     7.2574146091938019e-02
    z[5,4,6]  R2867     -2.1973720192909241e-01
    z[5,4,6]  R2868     -4.7050568461418152e-01
    z[5,4,6]  R2869     -7.0633783936500549e-02
    z[5,4,6]  R2870     0.336056649684906
    z[5,4,6]  R2871     -3.7884730100631714e-01
    z[5,4,6]  R2872     3.8792282342910767e-01
    z[5,4,6]  R2873     4.8093879222869873e-01
    z[5,4,6]  R2874     -2.1727073192596436e-01
    z[5,4,6]  R2875     2.2801366448402405e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R54       1
    RHS1      R55       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[6,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,7]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[6,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,7]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
ENDATA
