NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 E  R46     
 L  R47     
 L  R48     
 L  R49     
 L  R50     
 L  R51     
 L  R52     
 L  R53     
 L  R54     
 L  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R47       -3.0999999046325684e+00
    phi[0,1]  R48       -3.0999999046325684e+00
    phi[0,1]  R49       -2.2400000095367432e+00
    phi[0,1]  R50       -2.2400000095367432e+00
    phi[0,1]  R51       -3.0999999046325684e+00
    phi[0,1]  R52       -3.0999999046325684e+00
    phi[0,1]  R53       -2.5699999332427979e+00
    phi[0,1]  R54       -2.5699999332427979e+00
    phi[0,1]  R55       -3.0999999046325684e+00
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -2.0899999141693115e+00
    phi[0,1]  R58       -2.0899999141693115e+00
    phi[0,1]  R59       -3.0999999046325684e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       1.7217069864273071e+00
    phi[0,1]  R62       2.4837369918823242e+00
    phi[0,1]  R63       -6.3230171799659729e-02
    phi[0,1]  R64       5.3108870983123779e-02
    phi[0,1]  R65       -1.2640975415706635e-01
    phi[0,1]  R66       0.1800547093153
    phi[0,1]  R67       -1.4790292978286743e+00
    phi[0,1]  R68       -1.3889778852462769e+00
    phi[0,1]  R69       4.9859192967414856e-01
    phi[0,1]  R70       -5.2470070123672485e-01
    phi[0,1]  R71       -3.25763201713562
    phi[0,1]  R72       -2.0370728969573975e+00
    phi[0,1]  R73       -2.3425321578979492e+00
    phi[0,1]  R74       -2.0382966995239258e+00
    phi[0,1]  R75       -1.8933908939361572e+00
    phi[0,1]  R76       -2.3799602687358856e-01
    phi[0,1]  R77       -7.5855612754821777e-01
    phi[0,1]  R78       -2.7090206146240234e+00
    phi[0,1]  R79       -1.7129857540130615e+00
    phi[0,1]  R80       -5.3536188602447510e-01
    phi[0,1]  R81       -2.4505171775817871e+00
    phi[0,1]  R82       -2.0266897678375244e+00
    phi[0,1]  R83       -2.6343336105346680e+00
    phi[0,1]  R84       -1.5224976539611816e+00
    phi[0,1]  R85       -2.3214426040649414e+00
    phi[0,1]  R86       -2.9668672084808350e+00
    phi[0,1]  R87       -1.7434707880020142e+00
    phi[0,1]  R88       -2.2467339038848877e+00
    phi[0,1]  R89       6.7969597876071930e-02
    phi[0,1]  R90       -1.2781794071197510e+00
    phi[0,1]  R91       -3.5047614574432373e-01
    phi[0,1]  R92       -1.8984805345535278e+00
    phi[0,1]  R93       -1.9795103073120117e+00
    phi[0,1]  R94       -9.7499001026153564e-01
    phi[0,1]  R95       5.8916050195693970e-01
    phi[0,1]  R96       -1.2310644388198853e+00
    phi[0,1]  R97       2.5106295943260193e-01
    phi[0,1]  R98       -3.0356448888778687e-01
    phi[0,1]  R99       -1.0731621980667114e+00
    phi[0,1]  R100      -6.4202374219894409e-01
    phi[0,1]  R101      -1.3589484691619873e+00
    phi[0,1]  R102      4.0843862295150757e-01
    phi[0,1]  R103      5.0484120845794678e-01
    phi[0,1]  R104      -1.4120752811431885e+00
    phi[0,1]  R105      1.8062809109687805e-01
    phi[0,1]  R106      -1.2961052656173706e+00
    phi[0,1]  R107      -2.6631448268890381e+00
    phi[0,1]  R108      -1.1226503849029541e+00
    phi[0,1]  R109      -6.1788320541381836e-01
    phi[0,1]  R110      -1.1107274293899536e+00
    phi[0,1]  R111      -2.0329835414886475e+00
    phi[0,1]  R112      -1.6700476408004761e+00
    phi[0,1]  R113      -1.5306826829910278e+00
    phi[0,1]  R114      -1.4180340766906738e+00
    phi[0,1]  R115      3.3833165653049946e-03
    phi[0,1]  R116      -3.1373304128646851e-01
    phi[0,1]  R117      -1.3926001787185669e+00
    phi[0,1]  R118      -1.2464823722839355e+00
    phi[0,1]  R119      -2.9050370678305626e-02
    phi[0,1]  R120      -9.3789286911487579e-03
    phi[0,1]  R121      9.1855216026306152e-01
    phi[0,1]  R122      2.0229821205139160e+00
    phi[0,1]  R123      1.1362160444259644e+00
    phi[0,1]  R124      1.7421575784683228e+00
    phi[0,1]  R125      1.2180356979370117e+00
    phi[0,1]  R126      1.4911606311798096e+00
    phi[0,1]  R127      -1.1571743488311768e+00
    phi[0,1]  R128      4.1092571616172791e-01
    phi[0,1]  R129      2.7789559364318848e+00
    phi[0,1]  R130      8.9358985424041748e-01
    phi[0,1]  R131      -2.5442802906036377e-01
    phi[0,1]  R132      -1.0684536695480347e+00
    phi[0,1]  R133      -7.8112149238586426e-01
    phi[0,1]  R134      2.0280052721500397e-01
    phi[0,1]  R135      1.6316264867782593e-01
    phi[0,1]  R136      -8.6830848455429077e-01
    phi[0,1]  R137      -6.4931607246398926e-01
    phi[0,1]  R138      -2.1885073184967041e+00
    phi[0,1]  R139      3.3732259273529053e-01
    phi[0,1]  R140      3.5390856862068176e-01
    phi[0,1]  R141      -1.7167161703109741e+00
    phi[0,1]  R142      -3.3098659515380859e+00
    phi[0,1]  R143      -1.1761126518249512e+00
    phi[0,1]  R144      -3.8746683597564697e+00
    phi[0,1]  R145      -3.9582734107971191e+00
    phi[0,1]  R146      -3.8111178874969482e+00
    phi[0,1]  R147      -3.2247092723846436e+00
    phi[0,1]  R148      -4.4284863471984863e+00
    phi[0,1]  R149      -4.3337659835815430e+00
    phi[0,1]  R150      -1.1832810640335083e+00
    phi[0,1]  R151      -1.0195195674896240e+00
    phi[0,1]  R152      -1.0746871232986450e+00
    phi[0,1]  R153      -2.1516628563404083e-01
    phi[0,1]  R154      -3.1335551738739014e+00
    phi[0,1]  R155      -1.7886148691177368e+00
    phi[0,1]  R156      9.5990240573883057e-02
    phi[0,1]  R157      1.8971029669046402e-02
    phi[0,1]  R158      -3.6602160930633545e+00
    phi[0,1]  R159      -2.7257649898529053e+00
    phi[0,1]  R160      -2.1867661476135254e+00
    phi[0,1]  R161      -1.5625164508819580e+00
    phi[0,1]  R162      -2.2245893478393555e+00
    phi[0,1]  R163      -3.5115263462066650e+00
    phi[0,1]  R164      -3.1751241683959961e+00
    phi[0,1]  R165      4.4702652096748352e-01
    phi[0,1]  R166      -3.3355190753936768e+00
    phi[0,1]  R167      -3.1068332195281982e+00
    phi[0,1]  R168      -2.8701744079589844e+00
    phi[0,1]  R169      -2.9495816230773926e+00
    phi[0,1]  R170      -2.5194933414459229e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R171      -3.0999999046325684e+00
    phi[1,0]  R172      -3.0999999046325684e+00
    phi[1,0]  R173      -2.2400000095367432e+00
    phi[1,0]  R174      -2.2400000095367432e+00
    phi[1,0]  R175      -3.0999999046325684e+00
    phi[1,0]  R176      -3.0999999046325684e+00
    phi[1,0]  R177      -2.5699999332427979e+00
    phi[1,0]  R178      -2.5699999332427979e+00
    phi[1,0]  R179      -3.0999999046325684e+00
    phi[1,0]  R180      -3.0999999046325684e+00
    phi[1,0]  R181      -2.0899999141693115e+00
    phi[1,0]  R182      -2.0899999141693115e+00
    phi[1,0]  R183      -3.0999999046325684e+00
    phi[1,0]  R184      -3.0999999046325684e+00
    phi[1,0]  R185      9.1855216026306152e-01
    phi[1,0]  R186      2.0229821205139160e+00
    phi[1,0]  R187      1.1362160444259644e+00
    phi[1,0]  R188      1.7421575784683228e+00
    phi[1,0]  R189      1.2180356979370117e+00
    phi[1,0]  R190      1.4911606311798096e+00
    phi[1,0]  R191      -1.1571743488311768e+00
    phi[1,0]  R192      4.1092571616172791e-01
    phi[1,0]  R193      2.7789559364318848e+00
    phi[1,0]  R194      8.9358985424041748e-01
    phi[1,0]  R195      -2.5442802906036377e-01
    phi[1,0]  R196      -1.0684536695480347e+00
    phi[1,0]  R197      -7.8112149238586426e-01
    phi[1,0]  R198      2.0280052721500397e-01
    phi[1,0]  R199      1.6316264867782593e-01
    phi[1,0]  R200      -8.6830848455429077e-01
    phi[1,0]  R201      -6.4931607246398926e-01
    phi[1,0]  R202      -2.1885073184967041e+00
    phi[1,0]  R203      3.3732259273529053e-01
    phi[1,0]  R204      3.5390856862068176e-01
    phi[1,0]  R205      -1.7167161703109741e+00
    phi[1,0]  R206      -3.3098659515380859e+00
    phi[1,0]  R207      -1.1761126518249512e+00
    phi[1,0]  R208      -3.8746683597564697e+00
    phi[1,0]  R209      -3.9582734107971191e+00
    phi[1,0]  R210      -3.8111178874969482e+00
    phi[1,0]  R211      -3.2247092723846436e+00
    phi[1,0]  R212      -4.4284863471984863e+00
    phi[1,0]  R213      -4.3337659835815430e+00
    phi[1,0]  R214      -1.1832810640335083e+00
    phi[1,0]  R215      -1.0195195674896240e+00
    phi[1,0]  R216      -1.0746871232986450e+00
    phi[1,0]  R217      -2.1516628563404083e-01
    phi[1,0]  R218      -3.1335551738739014e+00
    phi[1,0]  R219      -1.7886148691177368e+00
    phi[1,0]  R220      9.5990240573883057e-02
    phi[1,0]  R221      1.8971029669046402e-02
    phi[1,0]  R222      -3.6602160930633545e+00
    phi[1,0]  R223      -2.7257649898529053e+00
    phi[1,0]  R224      -2.1867661476135254e+00
    phi[1,0]  R225      -1.5625164508819580e+00
    phi[1,0]  R226      -2.2245893478393555e+00
    phi[1,0]  R227      -3.5115263462066650e+00
    phi[1,0]  R228      -3.1751241683959961e+00
    phi[1,0]  R229      4.4702652096748352e-01
    phi[1,0]  R230      -3.3355190753936768e+00
    phi[1,0]  R231      -3.1068332195281982e+00
    phi[1,0]  R232      -2.8701744079589844e+00
    phi[1,0]  R233      -2.9495816230773926e+00
    phi[1,0]  R234      -2.5194933414459229e+00
    phi[1,0]  R235      1.7217069864273071e+00
    phi[1,0]  R236      2.4837369918823242e+00
    phi[1,0]  R237      -6.3230171799659729e-02
    phi[1,0]  R238      5.3108870983123779e-02
    phi[1,0]  R239      -1.2640975415706635e-01
    phi[1,0]  R240      0.1800547093153
    phi[1,0]  R241      -1.4790292978286743e+00
    phi[1,0]  R242      -1.3889778852462769e+00
    phi[1,0]  R243      4.9859192967414856e-01
    phi[1,0]  R244      -5.2470070123672485e-01
    phi[1,0]  R245      -3.25763201713562
    phi[1,0]  R246      -2.0370728969573975e+00
    phi[1,0]  R247      -2.3425321578979492e+00
    phi[1,0]  R248      -2.0382966995239258e+00
    phi[1,0]  R249      -1.8933908939361572e+00
    phi[1,0]  R250      -2.3799602687358856e-01
    phi[1,0]  R251      -7.5855612754821777e-01
    phi[1,0]  R252      -2.7090206146240234e+00
    phi[1,0]  R253      -1.7129857540130615e+00
    phi[1,0]  R254      -5.3536188602447510e-01
    phi[1,0]  R255      -2.4505171775817871e+00
    phi[1,0]  R256      -2.0266897678375244e+00
    phi[1,0]  R257      -2.6343336105346680e+00
    phi[1,0]  R258      -1.5224976539611816e+00
    phi[1,0]  R259      -2.3214426040649414e+00
    phi[1,0]  R260      -2.9668672084808350e+00
    phi[1,0]  R261      -1.7434707880020142e+00
    phi[1,0]  R262      -2.2467339038848877e+00
    phi[1,0]  R263      6.7969597876071930e-02
    phi[1,0]  R264      -1.2781794071197510e+00
    phi[1,0]  R265      -3.5047614574432373e-01
    phi[1,0]  R266      -1.8984805345535278e+00
    phi[1,0]  R267      -1.9795103073120117e+00
    phi[1,0]  R268      -9.7499001026153564e-01
    phi[1,0]  R269      5.8916050195693970e-01
    phi[1,0]  R270      -1.2310644388198853e+00
    phi[1,0]  R271      2.5106295943260193e-01
    phi[1,0]  R272      -3.0356448888778687e-01
    phi[1,0]  R273      -1.0731621980667114e+00
    phi[1,0]  R274      -6.4202374219894409e-01
    phi[1,0]  R275      -1.3589484691619873e+00
    phi[1,0]  R276      4.0843862295150757e-01
    phi[1,0]  R277      5.0484120845794678e-01
    phi[1,0]  R278      -1.4120752811431885e+00
    phi[1,0]  R279      1.8062809109687805e-01
    phi[1,0]  R280      -1.2961052656173706e+00
    phi[1,0]  R281      -2.6631448268890381e+00
    phi[1,0]  R282      -1.1226503849029541e+00
    phi[1,0]  R283      -6.1788320541381836e-01
    phi[1,0]  R284      -1.1107274293899536e+00
    phi[1,0]  R285      -2.0329835414886475e+00
    phi[1,0]  R286      -1.6700476408004761e+00
    phi[1,0]  R287      -1.5306826829910278e+00
    phi[1,0]  R288      -1.4180340766906738e+00
    phi[1,0]  R289      3.3833165653049946e-03
    phi[1,0]  R290      -3.1373304128646851e-01
    phi[1,0]  R291      -1.3926001787185669e+00
    phi[1,0]  R292      -1.2464823722839355e+00
    phi[1,0]  R293      -2.9050370678305626e-02
    phi[1,0]  R294      -9.3789286911487579e-03
    phi[0,2]  R0        1
    phi[0,2]  R1        1
    phi[0,2]  R18       -1
    phi[0,2]  R295      -3.0999999046325684e+00
    phi[0,2]  R296      -3.0999999046325684e+00
    phi[0,2]  R297      -2.2400000095367432e+00
    phi[0,2]  R298      -2.2400000095367432e+00
    phi[0,2]  R299      -3.0999999046325684e+00
    phi[0,2]  R300      -3.0999999046325684e+00
    phi[0,2]  R301      -2.5699999332427979e+00
    phi[0,2]  R302      -2.5699999332427979e+00
    phi[0,2]  R303      -3.0999999046325684e+00
    phi[0,2]  R304      -3.0999999046325684e+00
    phi[0,2]  R305      -2.0899999141693115e+00
    phi[0,2]  R306      -2.0899999141693115e+00
    phi[0,2]  R307      -3.0999999046325684e+00
    phi[0,2]  R308      -3.0999999046325684e+00
    phi[0,2]  R309      1.7217069864273071e+00
    phi[0,2]  R310      2.4837369918823242e+00
    phi[0,2]  R311      -6.3230171799659729e-02
    phi[0,2]  R312      5.3108870983123779e-02
    phi[0,2]  R313      -1.2640975415706635e-01
    phi[0,2]  R314      0.1800547093153
    phi[0,2]  R315      -1.4790292978286743e+00
    phi[0,2]  R316      -1.3889778852462769e+00
    phi[0,2]  R317      4.9859192967414856e-01
    phi[0,2]  R318      -5.2470070123672485e-01
    phi[0,2]  R319      -3.25763201713562
    phi[0,2]  R320      -2.0370728969573975e+00
    phi[0,2]  R321      -2.3425321578979492e+00
    phi[0,2]  R322      -2.0382966995239258e+00
    phi[0,2]  R323      -1.8933908939361572e+00
    phi[0,2]  R324      -2.3799602687358856e-01
    phi[0,2]  R325      -7.5855612754821777e-01
    phi[0,2]  R326      -2.7090206146240234e+00
    phi[0,2]  R327      -1.7129857540130615e+00
    phi[0,2]  R328      -5.3536188602447510e-01
    phi[0,2]  R329      -2.4505171775817871e+00
    phi[0,2]  R330      -2.0266897678375244e+00
    phi[0,2]  R331      -2.6343336105346680e+00
    phi[0,2]  R332      -1.5224976539611816e+00
    phi[0,2]  R333      -2.3214426040649414e+00
    phi[0,2]  R334      -2.9668672084808350e+00
    phi[0,2]  R335      -1.7434707880020142e+00
    phi[0,2]  R336      -2.2467339038848877e+00
    phi[0,2]  R337      6.7969597876071930e-02
    phi[0,2]  R338      -1.2781794071197510e+00
    phi[0,2]  R339      -3.5047614574432373e-01
    phi[0,2]  R340      -1.8984805345535278e+00
    phi[0,2]  R341      -1.9795103073120117e+00
    phi[0,2]  R342      -9.7499001026153564e-01
    phi[0,2]  R343      5.8916050195693970e-01
    phi[0,2]  R344      -1.2310644388198853e+00
    phi[0,2]  R345      2.5106295943260193e-01
    phi[0,2]  R346      -3.0356448888778687e-01
    phi[0,2]  R347      -1.0731621980667114e+00
    phi[0,2]  R348      -6.4202374219894409e-01
    phi[0,2]  R349      -1.3589484691619873e+00
    phi[0,2]  R350      4.0843862295150757e-01
    phi[0,2]  R351      5.0484120845794678e-01
    phi[0,2]  R352      -1.4120752811431885e+00
    phi[0,2]  R353      1.8062809109687805e-01
    phi[0,2]  R354      -1.2961052656173706e+00
    phi[0,2]  R355      -2.6631448268890381e+00
    phi[0,2]  R356      -1.1226503849029541e+00
    phi[0,2]  R357      -6.1788320541381836e-01
    phi[0,2]  R358      -1.1107274293899536e+00
    phi[0,2]  R359      -2.0329835414886475e+00
    phi[0,2]  R360      -1.6700476408004761e+00
    phi[0,2]  R361      -1.5306826829910278e+00
    phi[0,2]  R362      -1.4180340766906738e+00
    phi[0,2]  R363      3.3833165653049946e-03
    phi[0,2]  R364      -3.1373304128646851e-01
    phi[0,2]  R365      -1.3926001787185669e+00
    phi[0,2]  R366      -1.2464823722839355e+00
    phi[0,2]  R367      -2.9050370678305626e-02
    phi[0,2]  R368      -9.3789286911487579e-03
    phi[0,2]  R369      0.929864227771759
    phi[0,2]  R370      1.5453511476516724e+00
    phi[0,2]  R371      2.2167663574218750e+00
    phi[0,2]  R372      7.7329468727111816e-01
    phi[0,2]  R373      8.4786951541900635e-01
    phi[0,2]  R374      2.0617158412933350e+00
    phi[0,2]  R375      1.8311464786529541e+00
    phi[0,2]  R376      2.4245779514312744e+00
    phi[0,2]  R377      1.6866677999496460e+00
    phi[0,2]  R378      2.1075439453125
    phi[0,2]  R379      -1.9873582124710083e+00
    phi[0,2]  R380      -1.4581923484802246e+00
    phi[0,2]  R381      -8.7205237150192261e-01
    phi[0,2]  R382      -1.3715356588363647e+00
    phi[0,2]  R383      -7.9984259605407715e-01
    phi[0,2]  R384      -1.4912483692169189e+00
    phi[0,2]  R385      -3.3033929765224457e-02
    phi[0,2]  R386      -2.5775170326232910e+00
    phi[0,2]  R387      -2.5482490062713623e+00
    phi[0,2]  R388      -1.6744478940963745e+00
    phi[0,2]  R389      3.5166212916374207e-01
    phi[0,2]  R390      -7.8319799900054932e-01
    phi[0,2]  R391      1.1445455551147461e+00
    phi[0,2]  R392      -3.2257111072540283e+00
    phi[0,2]  R393      -3.2383475303649902e+00
    phi[0,2]  R394      -2.2900068759918213e+00
    phi[0,2]  R395      -2.6293735504150391e+00
    phi[0,2]  R396      -1.6479349136352539e+00
    phi[0,2]  R397      -3.5671951770782471e+00
    phi[0,2]  R398      -3.4320468902587891e+00
    phi[0,2]  R399      -3.9150032997131348e+00
    phi[0,2]  R400      9.2301227152347565e-02
    phi[0,2]  R401      -2.2195639610290527e+00
    phi[0,2]  R402      -1.2671731710433960e+00
    phi[0,2]  R403      -2.8452377319335938e+00
    phi[0,2]  R404      -3.9731376171112061e+00
    phi[0,2]  R405      -5.2245505154132843e-02
    phi[0,2]  R406      -1.6168293952941895e+00
    phi[0,2]  R407      -3.05655837059021
    phi[0,2]  R408      -2.9748830199241638e-01
    phi[0,2]  R409      -9.3699556589126587e-01
    phi[0,2]  R410      2.1009275317192078e-01
    phi[0,2]  R411      -7.0448386669158936e-01
    phi[0,2]  R412      -3.7879459857940674e+00
    phi[0,2]  R413      -3.8072686195373535e+00
    phi[0,2]  R414      -3.0422480106353760e+00
    phi[0,2]  R415      -3.5803813934326172e+00
    phi[0,2]  R416      -3.6997475624084473e+00
    phi[0,2]  R417      -3.9061946868896484e+00
    phi[0,2]  R418      -3.6559998989105225e+00
    phi[0,2]  R419      -5.0858810544013977e-02
    phi[0,2]  R420      -0.923875093460083
    phi[0,2]  R421      -1.4327594041824341e+00
    phi[0,2]  R422      -4.1447839736938477e+00
    phi[0,2]  R423      1.2919595241546631e+00
    phi[0,2]  R424      -3.0196237564086914e+00
    phi[0,2]  R425      -3.0316436290740967e+00
    phi[0,2]  R426      -3.4558148384094238e+00
    phi[0,2]  R427      -2.2922587394714355e+00
    phi[2,0]  R0        -1
    phi[2,0]  R18       1
    phi[2,0]  R19       1
    phi[2,0]  R428      -3.0999999046325684e+00
    phi[2,0]  R429      -3.0999999046325684e+00
    phi[2,0]  R430      -2.2400000095367432e+00
    phi[2,0]  R431      -2.2400000095367432e+00
    phi[2,0]  R432      -3.0999999046325684e+00
    phi[2,0]  R433      -3.0999999046325684e+00
    phi[2,0]  R434      -2.5699999332427979e+00
    phi[2,0]  R435      -2.5699999332427979e+00
    phi[2,0]  R436      -3.0999999046325684e+00
    phi[2,0]  R437      -3.0999999046325684e+00
    phi[2,0]  R438      -2.0899999141693115e+00
    phi[2,0]  R439      -2.0899999141693115e+00
    phi[2,0]  R440      -3.0999999046325684e+00
    phi[2,0]  R441      -3.0999999046325684e+00
    phi[2,0]  R442      0.929864227771759
    phi[2,0]  R443      1.5453511476516724e+00
    phi[2,0]  R444      2.2167663574218750e+00
    phi[2,0]  R445      7.7329468727111816e-01
    phi[2,0]  R446      8.4786951541900635e-01
    phi[2,0]  R447      2.0617158412933350e+00
    phi[2,0]  R448      1.8311464786529541e+00
    phi[2,0]  R449      2.4245779514312744e+00
    phi[2,0]  R450      1.6866677999496460e+00
    phi[2,0]  R451      2.1075439453125
    phi[2,0]  R452      -1.9873582124710083e+00
    phi[2,0]  R453      -1.4581923484802246e+00
    phi[2,0]  R454      -8.7205237150192261e-01
    phi[2,0]  R455      -1.3715356588363647e+00
    phi[2,0]  R456      -7.9984259605407715e-01
    phi[2,0]  R457      -1.4912483692169189e+00
    phi[2,0]  R458      -3.3033929765224457e-02
    phi[2,0]  R459      -2.5775170326232910e+00
    phi[2,0]  R460      -2.5482490062713623e+00
    phi[2,0]  R461      -1.6744478940963745e+00
    phi[2,0]  R462      3.5166212916374207e-01
    phi[2,0]  R463      -7.8319799900054932e-01
    phi[2,0]  R464      1.1445455551147461e+00
    phi[2,0]  R465      -3.2257111072540283e+00
    phi[2,0]  R466      -3.2383475303649902e+00
    phi[2,0]  R467      -2.2900068759918213e+00
    phi[2,0]  R468      -2.6293735504150391e+00
    phi[2,0]  R469      -1.6479349136352539e+00
    phi[2,0]  R470      -3.5671951770782471e+00
    phi[2,0]  R471      -3.4320468902587891e+00
    phi[2,0]  R472      -3.9150032997131348e+00
    phi[2,0]  R473      9.2301227152347565e-02
    phi[2,0]  R474      -2.2195639610290527e+00
    phi[2,0]  R475      -1.2671731710433960e+00
    phi[2,0]  R476      -2.8452377319335938e+00
    phi[2,0]  R477      -3.9731376171112061e+00
    phi[2,0]  R478      -5.2245505154132843e-02
    phi[2,0]  R479      -1.6168293952941895e+00
    phi[2,0]  R480      -3.05655837059021
    phi[2,0]  R481      -2.9748830199241638e-01
    phi[2,0]  R482      -9.3699556589126587e-01
    phi[2,0]  R483      2.1009275317192078e-01
    phi[2,0]  R484      -7.0448386669158936e-01
    phi[2,0]  R485      -3.7879459857940674e+00
    phi[2,0]  R486      -3.8072686195373535e+00
    phi[2,0]  R487      -3.0422480106353760e+00
    phi[2,0]  R488      -3.5803813934326172e+00
    phi[2,0]  R489      -3.6997475624084473e+00
    phi[2,0]  R490      -3.9061946868896484e+00
    phi[2,0]  R491      -3.6559998989105225e+00
    phi[2,0]  R492      -5.0858810544013977e-02
    phi[2,0]  R493      -0.923875093460083
    phi[2,0]  R494      -1.4327594041824341e+00
    phi[2,0]  R495      -4.1447839736938477e+00
    phi[2,0]  R496      1.2919595241546631e+00
    phi[2,0]  R497      -3.0196237564086914e+00
    phi[2,0]  R498      -3.0316436290740967e+00
    phi[2,0]  R499      -3.4558148384094238e+00
    phi[2,0]  R500      -2.2922587394714355e+00
    phi[2,0]  R501      1.7217069864273071e+00
    phi[2,0]  R502      2.4837369918823242e+00
    phi[2,0]  R503      -6.3230171799659729e-02
    phi[2,0]  R504      5.3108870983123779e-02
    phi[2,0]  R505      -1.2640975415706635e-01
    phi[2,0]  R506      0.1800547093153
    phi[2,0]  R507      -1.4790292978286743e+00
    phi[2,0]  R508      -1.3889778852462769e+00
    phi[2,0]  R509      4.9859192967414856e-01
    phi[2,0]  R510      -5.2470070123672485e-01
    phi[2,0]  R511      -3.25763201713562
    phi[2,0]  R512      -2.0370728969573975e+00
    phi[2,0]  R513      -2.3425321578979492e+00
    phi[2,0]  R514      -2.0382966995239258e+00
    phi[2,0]  R515      -1.8933908939361572e+00
    phi[2,0]  R516      -2.3799602687358856e-01
    phi[2,0]  R517      -7.5855612754821777e-01
    phi[2,0]  R518      -2.7090206146240234e+00
    phi[2,0]  R519      -1.7129857540130615e+00
    phi[2,0]  R520      -5.3536188602447510e-01
    phi[2,0]  R521      -2.4505171775817871e+00
    phi[2,0]  R522      -2.0266897678375244e+00
    phi[2,0]  R523      -2.6343336105346680e+00
    phi[2,0]  R524      -1.5224976539611816e+00
    phi[2,0]  R525      -2.3214426040649414e+00
    phi[2,0]  R526      -2.9668672084808350e+00
    phi[2,0]  R527      -1.7434707880020142e+00
    phi[2,0]  R528      -2.2467339038848877e+00
    phi[2,0]  R529      6.7969597876071930e-02
    phi[2,0]  R530      -1.2781794071197510e+00
    phi[2,0]  R531      -3.5047614574432373e-01
    phi[2,0]  R532      -1.8984805345535278e+00
    phi[2,0]  R533      -1.9795103073120117e+00
    phi[2,0]  R534      -9.7499001026153564e-01
    phi[2,0]  R535      5.8916050195693970e-01
    phi[2,0]  R536      -1.2310644388198853e+00
    phi[2,0]  R537      2.5106295943260193e-01
    phi[2,0]  R538      -3.0356448888778687e-01
    phi[2,0]  R539      -1.0731621980667114e+00
    phi[2,0]  R540      -6.4202374219894409e-01
    phi[2,0]  R541      -1.3589484691619873e+00
    phi[2,0]  R542      4.0843862295150757e-01
    phi[2,0]  R543      5.0484120845794678e-01
    phi[2,0]  R544      -1.4120752811431885e+00
    phi[2,0]  R545      1.8062809109687805e-01
    phi[2,0]  R546      -1.2961052656173706e+00
    phi[2,0]  R547      -2.6631448268890381e+00
    phi[2,0]  R548      -1.1226503849029541e+00
    phi[2,0]  R549      -6.1788320541381836e-01
    phi[2,0]  R550      -1.1107274293899536e+00
    phi[2,0]  R551      -2.0329835414886475e+00
    phi[2,0]  R552      -1.6700476408004761e+00
    phi[2,0]  R553      -1.5306826829910278e+00
    phi[2,0]  R554      -1.4180340766906738e+00
    phi[2,0]  R555      3.3833165653049946e-03
    phi[2,0]  R556      -3.1373304128646851e-01
    phi[2,0]  R557      -1.3926001787185669e+00
    phi[2,0]  R558      -1.2464823722839355e+00
    phi[2,0]  R559      -2.9050370678305626e-02
    phi[2,0]  R560      -9.3789286911487579e-03
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R561      -3.0999999046325684e+00
    phi[0,3]  R562      -3.0999999046325684e+00
    phi[0,3]  R563      -2.2400000095367432e+00
    phi[0,3]  R564      -2.2400000095367432e+00
    phi[0,3]  R565      -3.0999999046325684e+00
    phi[0,3]  R566      -3.0999999046325684e+00
    phi[0,3]  R567      -2.5699999332427979e+00
    phi[0,3]  R568      -2.5699999332427979e+00
    phi[0,3]  R569      -3.0999999046325684e+00
    phi[0,3]  R570      -3.0999999046325684e+00
    phi[0,3]  R571      -2.0899999141693115e+00
    phi[0,3]  R572      -2.0899999141693115e+00
    phi[0,3]  R573      -3.0999999046325684e+00
    phi[0,3]  R574      -3.0999999046325684e+00
    phi[0,3]  R575      1.7217069864273071e+00
    phi[0,3]  R576      2.4837369918823242e+00
    phi[0,3]  R577      -6.3230171799659729e-02
    phi[0,3]  R578      5.3108870983123779e-02
    phi[0,3]  R579      -1.2640975415706635e-01
    phi[0,3]  R580      0.1800547093153
    phi[0,3]  R581      -1.4790292978286743e+00
    phi[0,3]  R582      -1.3889778852462769e+00
    phi[0,3]  R583      4.9859192967414856e-01
    phi[0,3]  R584      -5.2470070123672485e-01
    phi[0,3]  R585      -3.25763201713562
    phi[0,3]  R586      -2.0370728969573975e+00
    phi[0,3]  R587      -2.3425321578979492e+00
    phi[0,3]  R588      -2.0382966995239258e+00
    phi[0,3]  R589      -1.8933908939361572e+00
    phi[0,3]  R590      -2.3799602687358856e-01
    phi[0,3]  R591      -7.5855612754821777e-01
    phi[0,3]  R592      -2.7090206146240234e+00
    phi[0,3]  R593      -1.7129857540130615e+00
    phi[0,3]  R594      -5.3536188602447510e-01
    phi[0,3]  R595      -2.4505171775817871e+00
    phi[0,3]  R596      -2.0266897678375244e+00
    phi[0,3]  R597      -2.6343336105346680e+00
    phi[0,3]  R598      -1.5224976539611816e+00
    phi[0,3]  R599      -2.3214426040649414e+00
    phi[0,3]  R600      -2.9668672084808350e+00
    phi[0,3]  R601      -1.7434707880020142e+00
    phi[0,3]  R602      -2.2467339038848877e+00
    phi[0,3]  R603      6.7969597876071930e-02
    phi[0,3]  R604      -1.2781794071197510e+00
    phi[0,3]  R605      -3.5047614574432373e-01
    phi[0,3]  R606      -1.8984805345535278e+00
    phi[0,3]  R607      -1.9795103073120117e+00
    phi[0,3]  R608      -9.7499001026153564e-01
    phi[0,3]  R609      5.8916050195693970e-01
    phi[0,3]  R610      -1.2310644388198853e+00
    phi[0,3]  R611      2.5106295943260193e-01
    phi[0,3]  R612      -3.0356448888778687e-01
    phi[0,3]  R613      -1.0731621980667114e+00
    phi[0,3]  R614      -6.4202374219894409e-01
    phi[0,3]  R615      -1.3589484691619873e+00
    phi[0,3]  R616      4.0843862295150757e-01
    phi[0,3]  R617      5.0484120845794678e-01
    phi[0,3]  R618      -1.4120752811431885e+00
    phi[0,3]  R619      1.8062809109687805e-01
    phi[0,3]  R620      -1.2961052656173706e+00
    phi[0,3]  R621      -2.6631448268890381e+00
    phi[0,3]  R622      -1.1226503849029541e+00
    phi[0,3]  R623      -6.1788320541381836e-01
    phi[0,3]  R624      -1.1107274293899536e+00
    phi[0,3]  R625      -2.0329835414886475e+00
    phi[0,3]  R626      -1.6700476408004761e+00
    phi[0,3]  R627      -1.5306826829910278e+00
    phi[0,3]  R628      -1.4180340766906738e+00
    phi[0,3]  R629      3.3833165653049946e-03
    phi[0,3]  R630      -3.1373304128646851e-01
    phi[0,3]  R631      -1.3926001787185669e+00
    phi[0,3]  R632      -1.2464823722839355e+00
    phi[0,3]  R633      -2.9050370678305626e-02
    phi[0,3]  R634      -9.3789286911487579e-03
    phi[0,3]  R635      -6.2218278646469116e-02
    phi[0,3]  R636      1.6193317249417305e-02
    phi[0,3]  R637      9.9294596910476685e-01
    phi[0,3]  R638      -5.4459863901138306e-01
    phi[0,3]  R639      1.1615632772445679e+00
    phi[0,3]  R640      1.6844284534454346e+00
    phi[0,3]  R641      1.3145222663879395e+00
    phi[0,3]  R642      5.0935935974121094e-01
    phi[0,3]  R643      6.8022483587265015e-01
    phi[0,3]  R644      1.0145140886306763e+00
    phi[0,3]  R645      -3.3789007663726807e+00
    phi[0,3]  R646      -8.1436145305633545e-01
    phi[0,3]  R647      -2.4853138625621796e-01
    phi[0,3]  R648      -6.5565979480743408e-01
    phi[0,3]  R649      -8.8782489299774170e-01
    phi[0,3]  R650      -5.6487703323364258e-01
    phi[0,3]  R651      -2.4411129951477051e+00
    phi[0,3]  R652      -9.6043968200683594e-01
    phi[0,3]  R653      -2.2532422542572021e+00
    phi[0,3]  R654      -1.0918543338775635e+00
    phi[0,3]  R655      -9.2643189430236816e-01
    phi[0,3]  R656      -0.514323890209198
    phi[0,3]  R657      -1.4910717010498047e+00
    phi[0,3]  R658      -1.4804013967514038e+00
    phi[0,3]  R659      -3.8691473007202148e+00
    phi[0,3]  R660      -3.0059163570404053e+00
    phi[0,3]  R661      1.0095201730728149e+00
    phi[0,3]  R662      4.2307850718498230e-01
    phi[0,3]  R663      2.0141877233982086e-01
    phi[0,3]  R664      1.2394497543573380e-01
    phi[0,3]  R665      -2.7115573883056641e+00
    phi[0,3]  R666      -1.5982079505920410e+00
    phi[0,3]  R667      4.6932065486907959e-01
    phi[0,3]  R668      -1.5131764411926270e+00
    phi[0,3]  R669      -2.2146458625793457e+00
    phi[0,3]  R670      -2.8437602519989014e+00
    phi[0,3]  R671      -1.9709444046020508e+00
    phi[0,3]  R672      -2.7090756893157959e+00
    phi[0,3]  R673      6.9363170862197876e-01
    phi[0,3]  R674      -3.5887582302093506e+00
    phi[0,3]  R675      -2.1472158432006836e+00
    phi[0,3]  R676      -1.1698952913284302e+00
    phi[0,3]  R677      -1.0071306228637695e+00
    phi[0,3]  R678      -3.1328707933425903e-01
    phi[0,3]  R679      -2.3223714828491211e+00
    phi[0,3]  R680      -5.4970771074295044e-01
    phi[0,3]  R681      -2.2064430713653564e+00
    phi[0,3]  R682      -1.7289621829986572e+00
    phi[0,3]  R683      6.3487333059310913e-01
    phi[0,3]  R684      -1.7122546434402466e+00
    phi[0,3]  R685      -2.6690256595611572e+00
    phi[0,3]  R686      -0.938790500164032
    phi[0,3]  R687      -4.2683696746826172e-01
    phi[0,3]  R688      5.2789485454559326e-01
    phi[0,3]  R689      -9.2152498662471771e-02
    phi[0,3]  R690      -7.9752969741821289e-01
    phi[0,3]  R691      -4.1551375389099121e-01
    phi[0,3]  R692      1.9322213530540466e-01
    phi[0,3]  R693      -3.6988839507102966e-01
    phi[0,3]  R694      -9.1805893182754517e-01
    phi[0,3]  R695      -1.6616492271423340e+00
    phi[0,3]  R696      -4.6592962741851807e-01
    phi[0,3]  R697      -4.1624480485916138e-01
    phi[0,3]  R698      -1.6522699594497681e+00
    phi[0,3]  R699      -2.9949298501014709e-01
    phi[0,3]  R700      -4.9342375993728638e-01
    phi[0,3]  R701      2.0489859580993652e-01
    phi[0,3]  R702      -2.3568347096443176e-01
    phi[0,3]  R703      4.9836745858192444e-01
    phi[0,3]  R704      -2.0114161074161530e-01
    phi[0,3]  R705      -1.4786535501480103e-01
    phi[0,3]  R706      -2.2979476451873779e+00
    phi[0,3]  R707      -2.4417271614074707e+00
    phi[0,3]  R708      -0.608791708946228
    phi[0,3]  R709      -7.5657713413238525e-01
    phi[0,3]  R710      -1.6928552091121674e-01
    phi[0,3]  R711      -4.2221364378929138e-01
    phi[0,3]  R712      -2.1813564300537109e+00
    phi[0,3]  R713      -1.6793943643569946e+00
    phi[0,3]  R714      -1.4341770410537720e+00
    phi[0,3]  R715      6.9603103399276733e-01
    phi[0,3]  R716      -2.4170310497283936e+00
    phi[0,3]  R717      -2.4902503490448
    phi[0,3]  R718      -3.1595468521118164e+00
    phi[0,3]  R719      -7.7070689201354980e-01
    phi[0,3]  R720      5.7555443048477173e-01
    phi[0,3]  R721      -1.0543503761291504e+00
    phi[0,3]  R722      -1.4689840078353882e+00
    phi[0,3]  R723      -1.8150148391723633e+00
    phi[0,3]  R724      -2.24212646484375
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R725      -3.0999999046325684e+00
    phi[3,0]  R726      -3.0999999046325684e+00
    phi[3,0]  R727      -2.2400000095367432e+00
    phi[3,0]  R728      -2.2400000095367432e+00
    phi[3,0]  R729      -3.0999999046325684e+00
    phi[3,0]  R730      -3.0999999046325684e+00
    phi[3,0]  R731      -2.5699999332427979e+00
    phi[3,0]  R732      -2.5699999332427979e+00
    phi[3,0]  R733      -3.0999999046325684e+00
    phi[3,0]  R734      -3.0999999046325684e+00
    phi[3,0]  R735      -2.0899999141693115e+00
    phi[3,0]  R736      -2.0899999141693115e+00
    phi[3,0]  R737      -3.0999999046325684e+00
    phi[3,0]  R738      -3.0999999046325684e+00
    phi[3,0]  R739      -6.2218278646469116e-02
    phi[3,0]  R740      1.6193317249417305e-02
    phi[3,0]  R741      9.9294596910476685e-01
    phi[3,0]  R742      -5.4459863901138306e-01
    phi[3,0]  R743      1.1615632772445679e+00
    phi[3,0]  R744      1.6844284534454346e+00
    phi[3,0]  R745      1.3145222663879395e+00
    phi[3,0]  R746      5.0935935974121094e-01
    phi[3,0]  R747      6.8022483587265015e-01
    phi[3,0]  R748      1.0145140886306763e+00
    phi[3,0]  R749      -3.3789007663726807e+00
    phi[3,0]  R750      -8.1436145305633545e-01
    phi[3,0]  R751      -2.4853138625621796e-01
    phi[3,0]  R752      -6.5565979480743408e-01
    phi[3,0]  R753      -8.8782489299774170e-01
    phi[3,0]  R754      -5.6487703323364258e-01
    phi[3,0]  R755      -2.4411129951477051e+00
    phi[3,0]  R756      -9.6043968200683594e-01
    phi[3,0]  R757      -2.2532422542572021e+00
    phi[3,0]  R758      -1.0918543338775635e+00
    phi[3,0]  R759      -9.2643189430236816e-01
    phi[3,0]  R760      -0.514323890209198
    phi[3,0]  R761      -1.4910717010498047e+00
    phi[3,0]  R762      -1.4804013967514038e+00
    phi[3,0]  R763      -3.8691473007202148e+00
    phi[3,0]  R764      -3.0059163570404053e+00
    phi[3,0]  R765      1.0095201730728149e+00
    phi[3,0]  R766      4.2307850718498230e-01
    phi[3,0]  R767      2.0141877233982086e-01
    phi[3,0]  R768      1.2394497543573380e-01
    phi[3,0]  R769      -2.7115573883056641e+00
    phi[3,0]  R770      -1.5982079505920410e+00
    phi[3,0]  R771      4.6932065486907959e-01
    phi[3,0]  R772      -1.5131764411926270e+00
    phi[3,0]  R773      -2.2146458625793457e+00
    phi[3,0]  R774      -2.8437602519989014e+00
    phi[3,0]  R775      -1.9709444046020508e+00
    phi[3,0]  R776      -2.7090756893157959e+00
    phi[3,0]  R777      6.9363170862197876e-01
    phi[3,0]  R778      -3.5887582302093506e+00
    phi[3,0]  R779      -2.1472158432006836e+00
    phi[3,0]  R780      -1.1698952913284302e+00
    phi[3,0]  R781      -1.0071306228637695e+00
    phi[3,0]  R782      -3.1328707933425903e-01
    phi[3,0]  R783      -2.3223714828491211e+00
    phi[3,0]  R784      -5.4970771074295044e-01
    phi[3,0]  R785      -2.2064430713653564e+00
    phi[3,0]  R786      -1.7289621829986572e+00
    phi[3,0]  R787      6.3487333059310913e-01
    phi[3,0]  R788      -1.7122546434402466e+00
    phi[3,0]  R789      -2.6690256595611572e+00
    phi[3,0]  R790      -0.938790500164032
    phi[3,0]  R791      -4.2683696746826172e-01
    phi[3,0]  R792      5.2789485454559326e-01
    phi[3,0]  R793      -9.2152498662471771e-02
    phi[3,0]  R794      -7.9752969741821289e-01
    phi[3,0]  R795      -4.1551375389099121e-01
    phi[3,0]  R796      1.9322213530540466e-01
    phi[3,0]  R797      -3.6988839507102966e-01
    phi[3,0]  R798      -9.1805893182754517e-01
    phi[3,0]  R799      -1.6616492271423340e+00
    phi[3,0]  R800      -4.6592962741851807e-01
    phi[3,0]  R801      -4.1624480485916138e-01
    phi[3,0]  R802      -1.6522699594497681e+00
    phi[3,0]  R803      -2.9949298501014709e-01
    phi[3,0]  R804      -4.9342375993728638e-01
    phi[3,0]  R805      2.0489859580993652e-01
    phi[3,0]  R806      -2.3568347096443176e-01
    phi[3,0]  R807      4.9836745858192444e-01
    phi[3,0]  R808      -2.0114161074161530e-01
    phi[3,0]  R809      -1.4786535501480103e-01
    phi[3,0]  R810      -2.2979476451873779e+00
    phi[3,0]  R811      -2.4417271614074707e+00
    phi[3,0]  R812      -0.608791708946228
    phi[3,0]  R813      -7.5657713413238525e-01
    phi[3,0]  R814      -1.6928552091121674e-01
    phi[3,0]  R815      -4.2221364378929138e-01
    phi[3,0]  R816      -2.1813564300537109e+00
    phi[3,0]  R817      -1.6793943643569946e+00
    phi[3,0]  R818      -1.4341770410537720e+00
    phi[3,0]  R819      6.9603103399276733e-01
    phi[3,0]  R820      -2.4170310497283936e+00
    phi[3,0]  R821      -2.4902503490448
    phi[3,0]  R822      -3.1595468521118164e+00
    phi[3,0]  R823      -7.7070689201354980e-01
    phi[3,0]  R824      5.7555443048477173e-01
    phi[3,0]  R825      -1.0543503761291504e+00
    phi[3,0]  R826      -1.4689840078353882e+00
    phi[3,0]  R827      -1.8150148391723633e+00
    phi[3,0]  R828      -2.24212646484375
    phi[3,0]  R829      1.7217069864273071e+00
    phi[3,0]  R830      2.4837369918823242e+00
    phi[3,0]  R831      -6.3230171799659729e-02
    phi[3,0]  R832      5.3108870983123779e-02
    phi[3,0]  R833      -1.2640975415706635e-01
    phi[3,0]  R834      0.1800547093153
    phi[3,0]  R835      -1.4790292978286743e+00
    phi[3,0]  R836      -1.3889778852462769e+00
    phi[3,0]  R837      4.9859192967414856e-01
    phi[3,0]  R838      -5.2470070123672485e-01
    phi[3,0]  R839      -3.25763201713562
    phi[3,0]  R840      -2.0370728969573975e+00
    phi[3,0]  R841      -2.3425321578979492e+00
    phi[3,0]  R842      -2.0382966995239258e+00
    phi[3,0]  R843      -1.8933908939361572e+00
    phi[3,0]  R844      -2.3799602687358856e-01
    phi[3,0]  R845      -7.5855612754821777e-01
    phi[3,0]  R846      -2.7090206146240234e+00
    phi[3,0]  R847      -1.7129857540130615e+00
    phi[3,0]  R848      -5.3536188602447510e-01
    phi[3,0]  R849      -2.4505171775817871e+00
    phi[3,0]  R850      -2.0266897678375244e+00
    phi[3,0]  R851      -2.6343336105346680e+00
    phi[3,0]  R852      -1.5224976539611816e+00
    phi[3,0]  R853      -2.3214426040649414e+00
    phi[3,0]  R854      -2.9668672084808350e+00
    phi[3,0]  R855      -1.7434707880020142e+00
    phi[3,0]  R856      -2.2467339038848877e+00
    phi[3,0]  R857      6.7969597876071930e-02
    phi[3,0]  R858      -1.2781794071197510e+00
    phi[3,0]  R859      -3.5047614574432373e-01
    phi[3,0]  R860      -1.8984805345535278e+00
    phi[3,0]  R861      -1.9795103073120117e+00
    phi[3,0]  R862      -9.7499001026153564e-01
    phi[3,0]  R863      5.8916050195693970e-01
    phi[3,0]  R864      -1.2310644388198853e+00
    phi[3,0]  R865      2.5106295943260193e-01
    phi[3,0]  R866      -3.0356448888778687e-01
    phi[3,0]  R867      -1.0731621980667114e+00
    phi[3,0]  R868      -6.4202374219894409e-01
    phi[3,0]  R869      -1.3589484691619873e+00
    phi[3,0]  R870      4.0843862295150757e-01
    phi[3,0]  R871      5.0484120845794678e-01
    phi[3,0]  R872      -1.4120752811431885e+00
    phi[3,0]  R873      1.8062809109687805e-01
    phi[3,0]  R874      -1.2961052656173706e+00
    phi[3,0]  R875      -2.6631448268890381e+00
    phi[3,0]  R876      -1.1226503849029541e+00
    phi[3,0]  R877      -6.1788320541381836e-01
    phi[3,0]  R878      -1.1107274293899536e+00
    phi[3,0]  R879      -2.0329835414886475e+00
    phi[3,0]  R880      -1.6700476408004761e+00
    phi[3,0]  R881      -1.5306826829910278e+00
    phi[3,0]  R882      -1.4180340766906738e+00
    phi[3,0]  R883      3.3833165653049946e-03
    phi[3,0]  R884      -3.1373304128646851e-01
    phi[3,0]  R885      -1.3926001787185669e+00
    phi[3,0]  R886      -1.2464823722839355e+00
    phi[3,0]  R887      -2.9050370678305626e-02
    phi[3,0]  R888      -9.3789286911487579e-03
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R889      -3.0999999046325684e+00
    phi[0,4]  R890      -3.0999999046325684e+00
    phi[0,4]  R891      -2.2400000095367432e+00
    phi[0,4]  R892      -2.2400000095367432e+00
    phi[0,4]  R893      -3.0999999046325684e+00
    phi[0,4]  R894      -3.0999999046325684e+00
    phi[0,4]  R895      -2.5699999332427979e+00
    phi[0,4]  R896      -2.5699999332427979e+00
    phi[0,4]  R897      -3.0999999046325684e+00
    phi[0,4]  R898      -3.0999999046325684e+00
    phi[0,4]  R899      -2.0899999141693115e+00
    phi[0,4]  R900      -2.0899999141693115e+00
    phi[0,4]  R901      -3.0999999046325684e+00
    phi[0,4]  R902      -3.0999999046325684e+00
    phi[0,4]  R903      1.7217069864273071e+00
    phi[0,4]  R904      2.4837369918823242e+00
    phi[0,4]  R905      -6.3230171799659729e-02
    phi[0,4]  R906      5.3108870983123779e-02
    phi[0,4]  R907      -1.2640975415706635e-01
    phi[0,4]  R908      0.1800547093153
    phi[0,4]  R909      -1.4790292978286743e+00
    phi[0,4]  R910      -1.3889778852462769e+00
    phi[0,4]  R911      4.9859192967414856e-01
    phi[0,4]  R912      -5.2470070123672485e-01
    phi[0,4]  R913      -3.25763201713562
    phi[0,4]  R914      -2.0370728969573975e+00
    phi[0,4]  R915      -2.3425321578979492e+00
    phi[0,4]  R916      -2.0382966995239258e+00
    phi[0,4]  R917      -1.8933908939361572e+00
    phi[0,4]  R918      -2.3799602687358856e-01
    phi[0,4]  R919      -7.5855612754821777e-01
    phi[0,4]  R920      -2.7090206146240234e+00
    phi[0,4]  R921      -1.7129857540130615e+00
    phi[0,4]  R922      -5.3536188602447510e-01
    phi[0,4]  R923      -2.4505171775817871e+00
    phi[0,4]  R924      -2.0266897678375244e+00
    phi[0,4]  R925      -2.6343336105346680e+00
    phi[0,4]  R926      -1.5224976539611816e+00
    phi[0,4]  R927      -2.3214426040649414e+00
    phi[0,4]  R928      -2.9668672084808350e+00
    phi[0,4]  R929      -1.7434707880020142e+00
    phi[0,4]  R930      -2.2467339038848877e+00
    phi[0,4]  R931      6.7969597876071930e-02
    phi[0,4]  R932      -1.2781794071197510e+00
    phi[0,4]  R933      -3.5047614574432373e-01
    phi[0,4]  R934      -1.8984805345535278e+00
    phi[0,4]  R935      -1.9795103073120117e+00
    phi[0,4]  R936      -9.7499001026153564e-01
    phi[0,4]  R937      5.8916050195693970e-01
    phi[0,4]  R938      -1.2310644388198853e+00
    phi[0,4]  R939      2.5106295943260193e-01
    phi[0,4]  R940      -3.0356448888778687e-01
    phi[0,4]  R941      -1.0731621980667114e+00
    phi[0,4]  R942      -6.4202374219894409e-01
    phi[0,4]  R943      -1.3589484691619873e+00
    phi[0,4]  R944      4.0843862295150757e-01
    phi[0,4]  R945      5.0484120845794678e-01
    phi[0,4]  R946      -1.4120752811431885e+00
    phi[0,4]  R947      1.8062809109687805e-01
    phi[0,4]  R948      -1.2961052656173706e+00
    phi[0,4]  R949      -2.6631448268890381e+00
    phi[0,4]  R950      -1.1226503849029541e+00
    phi[0,4]  R951      -6.1788320541381836e-01
    phi[0,4]  R952      -1.1107274293899536e+00
    phi[0,4]  R953      -2.0329835414886475e+00
    phi[0,4]  R954      -1.6700476408004761e+00
    phi[0,4]  R955      -1.5306826829910278e+00
    phi[0,4]  R956      -1.4180340766906738e+00
    phi[0,4]  R957      3.3833165653049946e-03
    phi[0,4]  R958      -3.1373304128646851e-01
    phi[0,4]  R959      -1.3926001787185669e+00
    phi[0,4]  R960      -1.2464823722839355e+00
    phi[0,4]  R961      -2.9050370678305626e-02
    phi[0,4]  R962      -9.3789286911487579e-03
    phi[0,4]  R963      2.1509380340576172e+00
    phi[0,4]  R964      2.4451081454753876e-01
    phi[0,4]  R965      1.8243471384048462e+00
    phi[0,4]  R966      1.2183016538619995e+00
    phi[0,4]  R967      7.0984214544296265e-01
    phi[0,4]  R968      -9.1263687610626221e-01
    phi[0,4]  R969      0.772459864616394
    phi[0,4]  R970      7.4859154224395752e-01
    phi[0,4]  R971      -2.8471606969833374e-01
    phi[0,4]  R972      1.5720822811126709e+00
    phi[0,4]  R973      -1.4759303331375122e+00
    phi[0,4]  R974      -2.0711195468902588e+00
    phi[0,4]  R975      -2.6037857532501221e+00
    phi[0,4]  R976      -2.7370514869689941e+00
    phi[0,4]  R977      -1.8810169696807861e+00
    phi[0,4]  R978      -1.6757023334503174e+00
    phi[0,4]  R979      -5.0212895870208740e-01
    phi[0,4]  R980      -1.3055902719497681e+00
    phi[0,4]  R981      -1.3431400060653687e+00
    phi[0,4]  R982      -1.6620051860809326e+00
    phi[0,4]  R983      -8.6805307865142822e-01
    phi[0,4]  R984      2.3669712245464325e-01
    phi[0,4]  R985      2.2730979323387146e-01
    phi[0,4]  R986      -7.5003856420516968e-01
    phi[0,4]  R987      -1.0988299846649170e+00
    phi[0,4]  R988      3.8742080330848694e-02
    phi[0,4]  R989      -4.6828466653823853e-01
    phi[0,4]  R990      -4.9756932258605957e-01
    phi[0,4]  R991      -2.4934850633144379e-01
    phi[0,4]  R992      4.8790228366851807e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R993      -3.0999999046325684e+00
    phi[4,0]  R994      -3.0999999046325684e+00
    phi[4,0]  R995      -2.2400000095367432e+00
    phi[4,0]  R996      -2.2400000095367432e+00
    phi[4,0]  R997      -3.0999999046325684e+00
    phi[4,0]  R998      -3.0999999046325684e+00
    phi[4,0]  R999      -2.5699999332427979e+00
    phi[4,0]  R1000     -2.5699999332427979e+00
    phi[4,0]  R1001     -3.0999999046325684e+00
    phi[4,0]  R1002     -3.0999999046325684e+00
    phi[4,0]  R1003     -2.0899999141693115e+00
    phi[4,0]  R1004     -2.0899999141693115e+00
    phi[4,0]  R1005     -3.0999999046325684e+00
    phi[4,0]  R1006     -3.0999999046325684e+00
    phi[4,0]  R1007     2.1509380340576172e+00
    phi[4,0]  R1008     2.4451081454753876e-01
    phi[4,0]  R1009     1.8243471384048462e+00
    phi[4,0]  R1010     1.2183016538619995e+00
    phi[4,0]  R1011     7.0984214544296265e-01
    phi[4,0]  R1012     -9.1263687610626221e-01
    phi[4,0]  R1013     0.772459864616394
    phi[4,0]  R1014     7.4859154224395752e-01
    phi[4,0]  R1015     -2.8471606969833374e-01
    phi[4,0]  R1016     1.5720822811126709e+00
    phi[4,0]  R1017     -1.4759303331375122e+00
    phi[4,0]  R1018     -2.0711195468902588e+00
    phi[4,0]  R1019     -2.6037857532501221e+00
    phi[4,0]  R1020     -2.7370514869689941e+00
    phi[4,0]  R1021     -1.8810169696807861e+00
    phi[4,0]  R1022     -1.6757023334503174e+00
    phi[4,0]  R1023     -5.0212895870208740e-01
    phi[4,0]  R1024     -1.3055902719497681e+00
    phi[4,0]  R1025     -1.3431400060653687e+00
    phi[4,0]  R1026     -1.6620051860809326e+00
    phi[4,0]  R1027     -8.6805307865142822e-01
    phi[4,0]  R1028     2.3669712245464325e-01
    phi[4,0]  R1029     2.2730979323387146e-01
    phi[4,0]  R1030     -7.5003856420516968e-01
    phi[4,0]  R1031     -1.0988299846649170e+00
    phi[4,0]  R1032     3.8742080330848694e-02
    phi[4,0]  R1033     -4.6828466653823853e-01
    phi[4,0]  R1034     -4.9756932258605957e-01
    phi[4,0]  R1035     -2.4934850633144379e-01
    phi[4,0]  R1036     4.8790228366851807e-01
    phi[4,0]  R1037     1.7217069864273071e+00
    phi[4,0]  R1038     2.4837369918823242e+00
    phi[4,0]  R1039     -6.3230171799659729e-02
    phi[4,0]  R1040     5.3108870983123779e-02
    phi[4,0]  R1041     -1.2640975415706635e-01
    phi[4,0]  R1042     0.1800547093153
    phi[4,0]  R1043     -1.4790292978286743e+00
    phi[4,0]  R1044     -1.3889778852462769e+00
    phi[4,0]  R1045     4.9859192967414856e-01
    phi[4,0]  R1046     -5.2470070123672485e-01
    phi[4,0]  R1047     -3.25763201713562
    phi[4,0]  R1048     -2.0370728969573975e+00
    phi[4,0]  R1049     -2.3425321578979492e+00
    phi[4,0]  R1050     -2.0382966995239258e+00
    phi[4,0]  R1051     -1.8933908939361572e+00
    phi[4,0]  R1052     -2.3799602687358856e-01
    phi[4,0]  R1053     -7.5855612754821777e-01
    phi[4,0]  R1054     -2.7090206146240234e+00
    phi[4,0]  R1055     -1.7129857540130615e+00
    phi[4,0]  R1056     -5.3536188602447510e-01
    phi[4,0]  R1057     -2.4505171775817871e+00
    phi[4,0]  R1058     -2.0266897678375244e+00
    phi[4,0]  R1059     -2.6343336105346680e+00
    phi[4,0]  R1060     -1.5224976539611816e+00
    phi[4,0]  R1061     -2.3214426040649414e+00
    phi[4,0]  R1062     -2.9668672084808350e+00
    phi[4,0]  R1063     -1.7434707880020142e+00
    phi[4,0]  R1064     -2.2467339038848877e+00
    phi[4,0]  R1065     6.7969597876071930e-02
    phi[4,0]  R1066     -1.2781794071197510e+00
    phi[4,0]  R1067     -3.5047614574432373e-01
    phi[4,0]  R1068     -1.8984805345535278e+00
    phi[4,0]  R1069     -1.9795103073120117e+00
    phi[4,0]  R1070     -9.7499001026153564e-01
    phi[4,0]  R1071     5.8916050195693970e-01
    phi[4,0]  R1072     -1.2310644388198853e+00
    phi[4,0]  R1073     2.5106295943260193e-01
    phi[4,0]  R1074     -3.0356448888778687e-01
    phi[4,0]  R1075     -1.0731621980667114e+00
    phi[4,0]  R1076     -6.4202374219894409e-01
    phi[4,0]  R1077     -1.3589484691619873e+00
    phi[4,0]  R1078     4.0843862295150757e-01
    phi[4,0]  R1079     5.0484120845794678e-01
    phi[4,0]  R1080     -1.4120752811431885e+00
    phi[4,0]  R1081     1.8062809109687805e-01
    phi[4,0]  R1082     -1.2961052656173706e+00
    phi[4,0]  R1083     -2.6631448268890381e+00
    phi[4,0]  R1084     -1.1226503849029541e+00
    phi[4,0]  R1085     -6.1788320541381836e-01
    phi[4,0]  R1086     -1.1107274293899536e+00
    phi[4,0]  R1087     -2.0329835414886475e+00
    phi[4,0]  R1088     -1.6700476408004761e+00
    phi[4,0]  R1089     -1.5306826829910278e+00
    phi[4,0]  R1090     -1.4180340766906738e+00
    phi[4,0]  R1091     3.3833165653049946e-03
    phi[4,0]  R1092     -3.1373304128646851e-01
    phi[4,0]  R1093     -1.3926001787185669e+00
    phi[4,0]  R1094     -1.2464823722839355e+00
    phi[4,0]  R1095     -2.9050370678305626e-02
    phi[4,0]  R1096     -9.3789286911487579e-03
    phi[5,0]  R0        -1
    phi[5,0]  R2        2.5751496212211351e+00
    phi[5,0]  R3        2.1461293892893973e-02
    phi[5,0]  R4        -2.1846339557291019e+00
    phi[5,0]  R5        -4.0334766786202625e-02
    phi[5,0]  R6        1.0862953931011057e+00
    phi[5,0]  R7        0.681411138239798
    phi[5,0]  R8        -1.6529561385600251e+00
    phi[5,0]  R45       1
    phi[5,0]  R1097     -5.6751495258537030e+00
    phi[5,0]  R1098     -5.2485028341143325e-01
    phi[5,0]  R1099     -2.2614613034296371e+00
    phi[5,0]  R1100     -2.2185387156438492e+00
    phi[5,0]  R1101     -9.1536594890346645e-01
    phi[5,0]  R1102     -5.28463386036167
    phi[5,0]  R1103     -2.5296651664565952e+00
    phi[5,0]  R1104     -2.6103347000290005e+00
    phi[5,0]  R1105     -4.1862952977336736e+00
    phi[5,0]  R1106     -2.0137045115314627e+00
    phi[5,0]  R1107     -2.7714110524091096e+00
    phi[5,0]  R1108     -1.4085887759295135e+00
    phi[5,0]  R1109     -1.4470437660725433e+00
    phi[5,0]  R1110     -4.7529560431925937e+00
    phi[5,0]  R1111     -6.2239058368970035e-02
    phi[5,0]  R1112     -7.1657187263200584e-02
    phi[5,0]  R1113     -0.0793519748308888
    phi[5,0]  R1114     -8.2846800872708459e-02
    phi[5,0]  R1115     -1.0087737949727738e-01
    phi[5,0]  R1116     -7.3998370953722770e-01
    phi[5,0]  R1117     -7.5058815629980080e-01
    phi[5,0]  R1118     -8.1141526897644078e-01
    phi[5,0]  R1119     -1.4682360629333588e+00
    phi[5,0]  R1120     -8.2650748051012013e-01
    phi[5,0]  R1121     -2.8951073868719135e-01
    phi[5,0]  R1122     -3.9826192431216212e-01
    phi[5,0]  R1123     -4.4539855874793655e-01
    phi[5,0]  R1124     -8.4184232530108094e-01
    phi[5,0]  R1125     -7.1403786990088558e-01
    phi[5,0]  R1126     -7.3797762849068360e-01
    phi[5,0]  R1127     -7.4570206704769959e-01
    phi[5,0]  R1128     -7.4971036798624624e-01
    phi[5,0]  R1129     -7.5887889950549736e-01
    phi[5,0]  R1130     -7.5988005139937576e-01
    phi[5,0]  R1131     -6.4144010839114141e-01
    phi[5,0]  R1132     -6.7475084291090881e-01
    phi[5,0]  R1133     -6.7830328046710320e-01
    phi[5,0]  R1134     -6.8137993198822733e-01
    phi[5,0]  R1135     -6.9073007782634277e-01
    phi[5,0]  R1136     -6.9088863534819556e-01
    phi[5,0]  R1137     -6.9252336473857157e-01
    phi[5,0]  R1138     -7.1178903469355492e-01
    phi[5,0]  R1139     -7.1303177734552514e-01
    phi[5,0]  R1140     -7.2170716751823671e-01
    phi[5,0]  R1141     -6.1834783914421787e-01
    phi[5,0]  R1142     -6.4815287229938723e-01
    phi[5,0]  R1143     -6.6613095017352641e-01
    phi[5,0]  R1144     -7.0159794863027636e-01
    phi[5,0]  R1145     -1.3311973711068430e+00
    phi[5,0]  R1146     -7.1848117513982768e-01
    phi[5,0]  R1147     -7.3970628856896581e-01
    phi[5,0]  R1148     -7.4861038502681465e-01
    phi[5,0]  R1149     -0.748740365918735
    phi[5,0]  R1150     -7.5582747919454774e-01
    phi[5,0]  R1151     -0.672305410573341
    phi[5,0]  R1152     -6.8130036659617121e-01
    phi[5,0]  R1153     -7.2091650176569955e-01
    phi[5,0]  R1154     -7.4773440957292281e-01
    phi[5,0]  R1155     -0.760958510308698
    phi[5,0]  R1156     -8.0683387209433421e-01
    phi[5,0]  R1157     -8.9919581542018534e-01
    phi[5,0]  R1158     -1.3981276600181292e+00
    phi[5,0]  R1159     -1.0852230106608522e+00
    phi[5,0]  R1160     -1.1481187881109551e+00
    phi[5,0]  R1161     -6.4722890812010414e-01
    phi[5,0]  R1162     -6.7328358089511464e-01
    phi[5,0]  R1163     -6.8018111410771553e-01
    phi[5,0]  R1164     -6.9337735655077914e-01
    phi[5,0]  R1165     -7.0370570610982353e-01
    phi[5,0]  R1166     -7.1175829126429790e-01
    phi[5,0]  R1167     -7.1600797261695459e-01
    phi[5,0]  R1168     -7.9095282996964622e-01
    phi[5,0]  R1169     -1.2554133271577663e+00
    phi[5,0]  R1170     -1.2642720215699836e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R1171     -3.0999999046325684e+00
    phi[1,2]  R1172     -3.0999999046325684e+00
    phi[1,2]  R1173     -2.2400000095367432e+00
    phi[1,2]  R1174     -2.2400000095367432e+00
    phi[1,2]  R1175     -3.0999999046325684e+00
    phi[1,2]  R1176     -3.0999999046325684e+00
    phi[1,2]  R1177     -2.5699999332427979e+00
    phi[1,2]  R1178     -2.5699999332427979e+00
    phi[1,2]  R1179     -3.0999999046325684e+00
    phi[1,2]  R1180     -3.0999999046325684e+00
    phi[1,2]  R1181     -2.0899999141693115e+00
    phi[1,2]  R1182     -2.0899999141693115e+00
    phi[1,2]  R1183     -3.0999999046325684e+00
    phi[1,2]  R1184     -3.0999999046325684e+00
    phi[1,2]  R1185     9.1855216026306152e-01
    phi[1,2]  R1186     2.0229821205139160e+00
    phi[1,2]  R1187     1.1362160444259644e+00
    phi[1,2]  R1188     1.7421575784683228e+00
    phi[1,2]  R1189     1.2180356979370117e+00
    phi[1,2]  R1190     1.4911606311798096e+00
    phi[1,2]  R1191     -1.1571743488311768e+00
    phi[1,2]  R1192     4.1092571616172791e-01
    phi[1,2]  R1193     2.7789559364318848e+00
    phi[1,2]  R1194     8.9358985424041748e-01
    phi[1,2]  R1195     -2.5442802906036377e-01
    phi[1,2]  R1196     -1.0684536695480347e+00
    phi[1,2]  R1197     -7.8112149238586426e-01
    phi[1,2]  R1198     2.0280052721500397e-01
    phi[1,2]  R1199     1.6316264867782593e-01
    phi[1,2]  R1200     -8.6830848455429077e-01
    phi[1,2]  R1201     -6.4931607246398926e-01
    phi[1,2]  R1202     -2.1885073184967041e+00
    phi[1,2]  R1203     3.3732259273529053e-01
    phi[1,2]  R1204     3.5390856862068176e-01
    phi[1,2]  R1205     -1.7167161703109741e+00
    phi[1,2]  R1206     -3.3098659515380859e+00
    phi[1,2]  R1207     -1.1761126518249512e+00
    phi[1,2]  R1208     -3.8746683597564697e+00
    phi[1,2]  R1209     -3.9582734107971191e+00
    phi[1,2]  R1210     -3.8111178874969482e+00
    phi[1,2]  R1211     -3.2247092723846436e+00
    phi[1,2]  R1212     -4.4284863471984863e+00
    phi[1,2]  R1213     -4.3337659835815430e+00
    phi[1,2]  R1214     -1.1832810640335083e+00
    phi[1,2]  R1215     -1.0195195674896240e+00
    phi[1,2]  R1216     -1.0746871232986450e+00
    phi[1,2]  R1217     -2.1516628563404083e-01
    phi[1,2]  R1218     -3.1335551738739014e+00
    phi[1,2]  R1219     -1.7886148691177368e+00
    phi[1,2]  R1220     9.5990240573883057e-02
    phi[1,2]  R1221     1.8971029669046402e-02
    phi[1,2]  R1222     -3.6602160930633545e+00
    phi[1,2]  R1223     -2.7257649898529053e+00
    phi[1,2]  R1224     -2.1867661476135254e+00
    phi[1,2]  R1225     -1.5625164508819580e+00
    phi[1,2]  R1226     -2.2245893478393555e+00
    phi[1,2]  R1227     -3.5115263462066650e+00
    phi[1,2]  R1228     -3.1751241683959961e+00
    phi[1,2]  R1229     4.4702652096748352e-01
    phi[1,2]  R1230     -3.3355190753936768e+00
    phi[1,2]  R1231     -3.1068332195281982e+00
    phi[1,2]  R1232     -2.8701744079589844e+00
    phi[1,2]  R1233     -2.9495816230773926e+00
    phi[1,2]  R1234     -2.5194933414459229e+00
    phi[1,2]  R1235     0.929864227771759
    phi[1,2]  R1236     1.5453511476516724e+00
    phi[1,2]  R1237     2.2167663574218750e+00
    phi[1,2]  R1238     7.7329468727111816e-01
    phi[1,2]  R1239     8.4786951541900635e-01
    phi[1,2]  R1240     2.0617158412933350e+00
    phi[1,2]  R1241     1.8311464786529541e+00
    phi[1,2]  R1242     2.4245779514312744e+00
    phi[1,2]  R1243     1.6866677999496460e+00
    phi[1,2]  R1244     2.1075439453125
    phi[1,2]  R1245     -1.9873582124710083e+00
    phi[1,2]  R1246     -1.4581923484802246e+00
    phi[1,2]  R1247     -8.7205237150192261e-01
    phi[1,2]  R1248     -1.3715356588363647e+00
    phi[1,2]  R1249     -7.9984259605407715e-01
    phi[1,2]  R1250     -1.4912483692169189e+00
    phi[1,2]  R1251     -3.3033929765224457e-02
    phi[1,2]  R1252     -2.5775170326232910e+00
    phi[1,2]  R1253     -2.5482490062713623e+00
    phi[1,2]  R1254     -1.6744478940963745e+00
    phi[1,2]  R1255     3.5166212916374207e-01
    phi[1,2]  R1256     -7.8319799900054932e-01
    phi[1,2]  R1257     1.1445455551147461e+00
    phi[1,2]  R1258     -3.2257111072540283e+00
    phi[1,2]  R1259     -3.2383475303649902e+00
    phi[1,2]  R1260     -2.2900068759918213e+00
    phi[1,2]  R1261     -2.6293735504150391e+00
    phi[1,2]  R1262     -1.6479349136352539e+00
    phi[1,2]  R1263     -3.5671951770782471e+00
    phi[1,2]  R1264     -3.4320468902587891e+00
    phi[1,2]  R1265     -3.9150032997131348e+00
    phi[1,2]  R1266     9.2301227152347565e-02
    phi[1,2]  R1267     -2.2195639610290527e+00
    phi[1,2]  R1268     -1.2671731710433960e+00
    phi[1,2]  R1269     -2.8452377319335938e+00
    phi[1,2]  R1270     -3.9731376171112061e+00
    phi[1,2]  R1271     -5.2245505154132843e-02
    phi[1,2]  R1272     -1.6168293952941895e+00
    phi[1,2]  R1273     -3.05655837059021
    phi[1,2]  R1274     -2.9748830199241638e-01
    phi[1,2]  R1275     -9.3699556589126587e-01
    phi[1,2]  R1276     2.1009275317192078e-01
    phi[1,2]  R1277     -7.0448386669158936e-01
    phi[1,2]  R1278     -3.7879459857940674e+00
    phi[1,2]  R1279     -3.8072686195373535e+00
    phi[1,2]  R1280     -3.0422480106353760e+00
    phi[1,2]  R1281     -3.5803813934326172e+00
    phi[1,2]  R1282     -3.6997475624084473e+00
    phi[1,2]  R1283     -3.9061946868896484e+00
    phi[1,2]  R1284     -3.6559998989105225e+00
    phi[1,2]  R1285     -5.0858810544013977e-02
    phi[1,2]  R1286     -0.923875093460083
    phi[1,2]  R1287     -1.4327594041824341e+00
    phi[1,2]  R1288     -4.1447839736938477e+00
    phi[1,2]  R1289     1.2919595241546631e+00
    phi[1,2]  R1290     -3.0196237564086914e+00
    phi[1,2]  R1291     -3.0316436290740967e+00
    phi[1,2]  R1292     -3.4558148384094238e+00
    phi[1,2]  R1293     -2.2922587394714355e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R1294     -3.0999999046325684e+00
    phi[2,1]  R1295     -3.0999999046325684e+00
    phi[2,1]  R1296     -2.2400000095367432e+00
    phi[2,1]  R1297     -2.2400000095367432e+00
    phi[2,1]  R1298     -3.0999999046325684e+00
    phi[2,1]  R1299     -3.0999999046325684e+00
    phi[2,1]  R1300     -2.5699999332427979e+00
    phi[2,1]  R1301     -2.5699999332427979e+00
    phi[2,1]  R1302     -3.0999999046325684e+00
    phi[2,1]  R1303     -3.0999999046325684e+00
    phi[2,1]  R1304     -2.0899999141693115e+00
    phi[2,1]  R1305     -2.0899999141693115e+00
    phi[2,1]  R1306     -3.0999999046325684e+00
    phi[2,1]  R1307     -3.0999999046325684e+00
    phi[2,1]  R1308     0.929864227771759
    phi[2,1]  R1309     1.5453511476516724e+00
    phi[2,1]  R1310     2.2167663574218750e+00
    phi[2,1]  R1311     7.7329468727111816e-01
    phi[2,1]  R1312     8.4786951541900635e-01
    phi[2,1]  R1313     2.0617158412933350e+00
    phi[2,1]  R1314     1.8311464786529541e+00
    phi[2,1]  R1315     2.4245779514312744e+00
    phi[2,1]  R1316     1.6866677999496460e+00
    phi[2,1]  R1317     2.1075439453125
    phi[2,1]  R1318     -1.9873582124710083e+00
    phi[2,1]  R1319     -1.4581923484802246e+00
    phi[2,1]  R1320     -8.7205237150192261e-01
    phi[2,1]  R1321     -1.3715356588363647e+00
    phi[2,1]  R1322     -7.9984259605407715e-01
    phi[2,1]  R1323     -1.4912483692169189e+00
    phi[2,1]  R1324     -3.3033929765224457e-02
    phi[2,1]  R1325     -2.5775170326232910e+00
    phi[2,1]  R1326     -2.5482490062713623e+00
    phi[2,1]  R1327     -1.6744478940963745e+00
    phi[2,1]  R1328     3.5166212916374207e-01
    phi[2,1]  R1329     -7.8319799900054932e-01
    phi[2,1]  R1330     1.1445455551147461e+00
    phi[2,1]  R1331     -3.2257111072540283e+00
    phi[2,1]  R1332     -3.2383475303649902e+00
    phi[2,1]  R1333     -2.2900068759918213e+00
    phi[2,1]  R1334     -2.6293735504150391e+00
    phi[2,1]  R1335     -1.6479349136352539e+00
    phi[2,1]  R1336     -3.5671951770782471e+00
    phi[2,1]  R1337     -3.4320468902587891e+00
    phi[2,1]  R1338     -3.9150032997131348e+00
    phi[2,1]  R1339     9.2301227152347565e-02
    phi[2,1]  R1340     -2.2195639610290527e+00
    phi[2,1]  R1341     -1.2671731710433960e+00
    phi[2,1]  R1342     -2.8452377319335938e+00
    phi[2,1]  R1343     -3.9731376171112061e+00
    phi[2,1]  R1344     -5.2245505154132843e-02
    phi[2,1]  R1345     -1.6168293952941895e+00
    phi[2,1]  R1346     -3.05655837059021
    phi[2,1]  R1347     -2.9748830199241638e-01
    phi[2,1]  R1348     -9.3699556589126587e-01
    phi[2,1]  R1349     2.1009275317192078e-01
    phi[2,1]  R1350     -7.0448386669158936e-01
    phi[2,1]  R1351     -3.7879459857940674e+00
    phi[2,1]  R1352     -3.8072686195373535e+00
    phi[2,1]  R1353     -3.0422480106353760e+00
    phi[2,1]  R1354     -3.5803813934326172e+00
    phi[2,1]  R1355     -3.6997475624084473e+00
    phi[2,1]  R1356     -3.9061946868896484e+00
    phi[2,1]  R1357     -3.6559998989105225e+00
    phi[2,1]  R1358     -5.0858810544013977e-02
    phi[2,1]  R1359     -0.923875093460083
    phi[2,1]  R1360     -1.4327594041824341e+00
    phi[2,1]  R1361     -4.1447839736938477e+00
    phi[2,1]  R1362     1.2919595241546631e+00
    phi[2,1]  R1363     -3.0196237564086914e+00
    phi[2,1]  R1364     -3.0316436290740967e+00
    phi[2,1]  R1365     -3.4558148384094238e+00
    phi[2,1]  R1366     -2.2922587394714355e+00
    phi[2,1]  R1367     9.1855216026306152e-01
    phi[2,1]  R1368     2.0229821205139160e+00
    phi[2,1]  R1369     1.1362160444259644e+00
    phi[2,1]  R1370     1.7421575784683228e+00
    phi[2,1]  R1371     1.2180356979370117e+00
    phi[2,1]  R1372     1.4911606311798096e+00
    phi[2,1]  R1373     -1.1571743488311768e+00
    phi[2,1]  R1374     4.1092571616172791e-01
    phi[2,1]  R1375     2.7789559364318848e+00
    phi[2,1]  R1376     8.9358985424041748e-01
    phi[2,1]  R1377     -2.5442802906036377e-01
    phi[2,1]  R1378     -1.0684536695480347e+00
    phi[2,1]  R1379     -7.8112149238586426e-01
    phi[2,1]  R1380     2.0280052721500397e-01
    phi[2,1]  R1381     1.6316264867782593e-01
    phi[2,1]  R1382     -8.6830848455429077e-01
    phi[2,1]  R1383     -6.4931607246398926e-01
    phi[2,1]  R1384     -2.1885073184967041e+00
    phi[2,1]  R1385     3.3732259273529053e-01
    phi[2,1]  R1386     3.5390856862068176e-01
    phi[2,1]  R1387     -1.7167161703109741e+00
    phi[2,1]  R1388     -3.3098659515380859e+00
    phi[2,1]  R1389     -1.1761126518249512e+00
    phi[2,1]  R1390     -3.8746683597564697e+00
    phi[2,1]  R1391     -3.9582734107971191e+00
    phi[2,1]  R1392     -3.8111178874969482e+00
    phi[2,1]  R1393     -3.2247092723846436e+00
    phi[2,1]  R1394     -4.4284863471984863e+00
    phi[2,1]  R1395     -4.3337659835815430e+00
    phi[2,1]  R1396     -1.1832810640335083e+00
    phi[2,1]  R1397     -1.0195195674896240e+00
    phi[2,1]  R1398     -1.0746871232986450e+00
    phi[2,1]  R1399     -2.1516628563404083e-01
    phi[2,1]  R1400     -3.1335551738739014e+00
    phi[2,1]  R1401     -1.7886148691177368e+00
    phi[2,1]  R1402     9.5990240573883057e-02
    phi[2,1]  R1403     1.8971029669046402e-02
    phi[2,1]  R1404     -3.6602160930633545e+00
    phi[2,1]  R1405     -2.7257649898529053e+00
    phi[2,1]  R1406     -2.1867661476135254e+00
    phi[2,1]  R1407     -1.5625164508819580e+00
    phi[2,1]  R1408     -2.2245893478393555e+00
    phi[2,1]  R1409     -3.5115263462066650e+00
    phi[2,1]  R1410     -3.1751241683959961e+00
    phi[2,1]  R1411     4.4702652096748352e-01
    phi[2,1]  R1412     -3.3355190753936768e+00
    phi[2,1]  R1413     -3.1068332195281982e+00
    phi[2,1]  R1414     -2.8701744079589844e+00
    phi[2,1]  R1415     -2.9495816230773926e+00
    phi[2,1]  R1416     -2.5194933414459229e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R1417     -3.0999999046325684e+00
    phi[1,3]  R1418     -3.0999999046325684e+00
    phi[1,3]  R1419     -2.2400000095367432e+00
    phi[1,3]  R1420     -2.2400000095367432e+00
    phi[1,3]  R1421     -3.0999999046325684e+00
    phi[1,3]  R1422     -3.0999999046325684e+00
    phi[1,3]  R1423     -2.5699999332427979e+00
    phi[1,3]  R1424     -2.5699999332427979e+00
    phi[1,3]  R1425     -3.0999999046325684e+00
    phi[1,3]  R1426     -3.0999999046325684e+00
    phi[1,3]  R1427     -2.0899999141693115e+00
    phi[1,3]  R1428     -2.0899999141693115e+00
    phi[1,3]  R1429     -3.0999999046325684e+00
    phi[1,3]  R1430     -3.0999999046325684e+00
    phi[1,3]  R1431     9.1855216026306152e-01
    phi[1,3]  R1432     2.0229821205139160e+00
    phi[1,3]  R1433     1.1362160444259644e+00
    phi[1,3]  R1434     1.7421575784683228e+00
    phi[1,3]  R1435     1.2180356979370117e+00
    phi[1,3]  R1436     1.4911606311798096e+00
    phi[1,3]  R1437     -1.1571743488311768e+00
    phi[1,3]  R1438     4.1092571616172791e-01
    phi[1,3]  R1439     2.7789559364318848e+00
    phi[1,3]  R1440     8.9358985424041748e-01
    phi[1,3]  R1441     -2.5442802906036377e-01
    phi[1,3]  R1442     -1.0684536695480347e+00
    phi[1,3]  R1443     -7.8112149238586426e-01
    phi[1,3]  R1444     2.0280052721500397e-01
    phi[1,3]  R1445     1.6316264867782593e-01
    phi[1,3]  R1446     -8.6830848455429077e-01
    phi[1,3]  R1447     -6.4931607246398926e-01
    phi[1,3]  R1448     -2.1885073184967041e+00
    phi[1,3]  R1449     3.3732259273529053e-01
    phi[1,3]  R1450     3.5390856862068176e-01
    phi[1,3]  R1451     -1.7167161703109741e+00
    phi[1,3]  R1452     -3.3098659515380859e+00
    phi[1,3]  R1453     -1.1761126518249512e+00
    phi[1,3]  R1454     -3.8746683597564697e+00
    phi[1,3]  R1455     -3.9582734107971191e+00
    phi[1,3]  R1456     -3.8111178874969482e+00
    phi[1,3]  R1457     -3.2247092723846436e+00
    phi[1,3]  R1458     -4.4284863471984863e+00
    phi[1,3]  R1459     -4.3337659835815430e+00
    phi[1,3]  R1460     -1.1832810640335083e+00
    phi[1,3]  R1461     -1.0195195674896240e+00
    phi[1,3]  R1462     -1.0746871232986450e+00
    phi[1,3]  R1463     -2.1516628563404083e-01
    phi[1,3]  R1464     -3.1335551738739014e+00
    phi[1,3]  R1465     -1.7886148691177368e+00
    phi[1,3]  R1466     9.5990240573883057e-02
    phi[1,3]  R1467     1.8971029669046402e-02
    phi[1,3]  R1468     -3.6602160930633545e+00
    phi[1,3]  R1469     -2.7257649898529053e+00
    phi[1,3]  R1470     -2.1867661476135254e+00
    phi[1,3]  R1471     -1.5625164508819580e+00
    phi[1,3]  R1472     -2.2245893478393555e+00
    phi[1,3]  R1473     -3.5115263462066650e+00
    phi[1,3]  R1474     -3.1751241683959961e+00
    phi[1,3]  R1475     4.4702652096748352e-01
    phi[1,3]  R1476     -3.3355190753936768e+00
    phi[1,3]  R1477     -3.1068332195281982e+00
    phi[1,3]  R1478     -2.8701744079589844e+00
    phi[1,3]  R1479     -2.9495816230773926e+00
    phi[1,3]  R1480     -2.5194933414459229e+00
    phi[1,3]  R1481     -6.2218278646469116e-02
    phi[1,3]  R1482     1.6193317249417305e-02
    phi[1,3]  R1483     9.9294596910476685e-01
    phi[1,3]  R1484     -5.4459863901138306e-01
    phi[1,3]  R1485     1.1615632772445679e+00
    phi[1,3]  R1486     1.6844284534454346e+00
    phi[1,3]  R1487     1.3145222663879395e+00
    phi[1,3]  R1488     5.0935935974121094e-01
    phi[1,3]  R1489     6.8022483587265015e-01
    phi[1,3]  R1490     1.0145140886306763e+00
    phi[1,3]  R1491     -3.3789007663726807e+00
    phi[1,3]  R1492     -8.1436145305633545e-01
    phi[1,3]  R1493     -2.4853138625621796e-01
    phi[1,3]  R1494     -6.5565979480743408e-01
    phi[1,3]  R1495     -8.8782489299774170e-01
    phi[1,3]  R1496     -5.6487703323364258e-01
    phi[1,3]  R1497     -2.4411129951477051e+00
    phi[1,3]  R1498     -9.6043968200683594e-01
    phi[1,3]  R1499     -2.2532422542572021e+00
    phi[1,3]  R1500     -1.0918543338775635e+00
    phi[1,3]  R1501     -9.2643189430236816e-01
    phi[1,3]  R1502     -0.514323890209198
    phi[1,3]  R1503     -1.4910717010498047e+00
    phi[1,3]  R1504     -1.4804013967514038e+00
    phi[1,3]  R1505     -3.8691473007202148e+00
    phi[1,3]  R1506     -3.0059163570404053e+00
    phi[1,3]  R1507     1.0095201730728149e+00
    phi[1,3]  R1508     4.2307850718498230e-01
    phi[1,3]  R1509     2.0141877233982086e-01
    phi[1,3]  R1510     1.2394497543573380e-01
    phi[1,3]  R1511     -2.7115573883056641e+00
    phi[1,3]  R1512     -1.5982079505920410e+00
    phi[1,3]  R1513     4.6932065486907959e-01
    phi[1,3]  R1514     -1.5131764411926270e+00
    phi[1,3]  R1515     -2.2146458625793457e+00
    phi[1,3]  R1516     -2.8437602519989014e+00
    phi[1,3]  R1517     -1.9709444046020508e+00
    phi[1,3]  R1518     -2.7090756893157959e+00
    phi[1,3]  R1519     6.9363170862197876e-01
    phi[1,3]  R1520     -3.5887582302093506e+00
    phi[1,3]  R1521     -2.1472158432006836e+00
    phi[1,3]  R1522     -1.1698952913284302e+00
    phi[1,3]  R1523     -1.0071306228637695e+00
    phi[1,3]  R1524     -3.1328707933425903e-01
    phi[1,3]  R1525     -2.3223714828491211e+00
    phi[1,3]  R1526     -5.4970771074295044e-01
    phi[1,3]  R1527     -2.2064430713653564e+00
    phi[1,3]  R1528     -1.7289621829986572e+00
    phi[1,3]  R1529     6.3487333059310913e-01
    phi[1,3]  R1530     -1.7122546434402466e+00
    phi[1,3]  R1531     -2.6690256595611572e+00
    phi[1,3]  R1532     -0.938790500164032
    phi[1,3]  R1533     -4.2683696746826172e-01
    phi[1,3]  R1534     5.2789485454559326e-01
    phi[1,3]  R1535     -9.2152498662471771e-02
    phi[1,3]  R1536     -7.9752969741821289e-01
    phi[1,3]  R1537     -4.1551375389099121e-01
    phi[1,3]  R1538     1.9322213530540466e-01
    phi[1,3]  R1539     -3.6988839507102966e-01
    phi[1,3]  R1540     -9.1805893182754517e-01
    phi[1,3]  R1541     -1.6616492271423340e+00
    phi[1,3]  R1542     -4.6592962741851807e-01
    phi[1,3]  R1543     -4.1624480485916138e-01
    phi[1,3]  R1544     -1.6522699594497681e+00
    phi[1,3]  R1545     -2.9949298501014709e-01
    phi[1,3]  R1546     -4.9342375993728638e-01
    phi[1,3]  R1547     2.0489859580993652e-01
    phi[1,3]  R1548     -2.3568347096443176e-01
    phi[1,3]  R1549     4.9836745858192444e-01
    phi[1,3]  R1550     -2.0114161074161530e-01
    phi[1,3]  R1551     -1.4786535501480103e-01
    phi[1,3]  R1552     -2.2979476451873779e+00
    phi[1,3]  R1553     -2.4417271614074707e+00
    phi[1,3]  R1554     -0.608791708946228
    phi[1,3]  R1555     -7.5657713413238525e-01
    phi[1,3]  R1556     -1.6928552091121674e-01
    phi[1,3]  R1557     -4.2221364378929138e-01
    phi[1,3]  R1558     -2.1813564300537109e+00
    phi[1,3]  R1559     -1.6793943643569946e+00
    phi[1,3]  R1560     -1.4341770410537720e+00
    phi[1,3]  R1561     6.9603103399276733e-01
    phi[1,3]  R1562     -2.4170310497283936e+00
    phi[1,3]  R1563     -2.4902503490448
    phi[1,3]  R1564     -3.1595468521118164e+00
    phi[1,3]  R1565     -7.7070689201354980e-01
    phi[1,3]  R1566     5.7555443048477173e-01
    phi[1,3]  R1567     -1.0543503761291504e+00
    phi[1,3]  R1568     -1.4689840078353882e+00
    phi[1,3]  R1569     -1.8150148391723633e+00
    phi[1,3]  R1570     -2.24212646484375
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R1571     -3.0999999046325684e+00
    phi[3,1]  R1572     -3.0999999046325684e+00
    phi[3,1]  R1573     -2.2400000095367432e+00
    phi[3,1]  R1574     -2.2400000095367432e+00
    phi[3,1]  R1575     -3.0999999046325684e+00
    phi[3,1]  R1576     -3.0999999046325684e+00
    phi[3,1]  R1577     -2.5699999332427979e+00
    phi[3,1]  R1578     -2.5699999332427979e+00
    phi[3,1]  R1579     -3.0999999046325684e+00
    phi[3,1]  R1580     -3.0999999046325684e+00
    phi[3,1]  R1581     -2.0899999141693115e+00
    phi[3,1]  R1582     -2.0899999141693115e+00
    phi[3,1]  R1583     -3.0999999046325684e+00
    phi[3,1]  R1584     -3.0999999046325684e+00
    phi[3,1]  R1585     -6.2218278646469116e-02
    phi[3,1]  R1586     1.6193317249417305e-02
    phi[3,1]  R1587     9.9294596910476685e-01
    phi[3,1]  R1588     -5.4459863901138306e-01
    phi[3,1]  R1589     1.1615632772445679e+00
    phi[3,1]  R1590     1.6844284534454346e+00
    phi[3,1]  R1591     1.3145222663879395e+00
    phi[3,1]  R1592     5.0935935974121094e-01
    phi[3,1]  R1593     6.8022483587265015e-01
    phi[3,1]  R1594     1.0145140886306763e+00
    phi[3,1]  R1595     -3.3789007663726807e+00
    phi[3,1]  R1596     -8.1436145305633545e-01
    phi[3,1]  R1597     -2.4853138625621796e-01
    phi[3,1]  R1598     -6.5565979480743408e-01
    phi[3,1]  R1599     -8.8782489299774170e-01
    phi[3,1]  R1600     -5.6487703323364258e-01
    phi[3,1]  R1601     -2.4411129951477051e+00
    phi[3,1]  R1602     -9.6043968200683594e-01
    phi[3,1]  R1603     -2.2532422542572021e+00
    phi[3,1]  R1604     -1.0918543338775635e+00
    phi[3,1]  R1605     -9.2643189430236816e-01
    phi[3,1]  R1606     -0.514323890209198
    phi[3,1]  R1607     -1.4910717010498047e+00
    phi[3,1]  R1608     -1.4804013967514038e+00
    phi[3,1]  R1609     -3.8691473007202148e+00
    phi[3,1]  R1610     -3.0059163570404053e+00
    phi[3,1]  R1611     1.0095201730728149e+00
    phi[3,1]  R1612     4.2307850718498230e-01
    phi[3,1]  R1613     2.0141877233982086e-01
    phi[3,1]  R1614     1.2394497543573380e-01
    phi[3,1]  R1615     -2.7115573883056641e+00
    phi[3,1]  R1616     -1.5982079505920410e+00
    phi[3,1]  R1617     4.6932065486907959e-01
    phi[3,1]  R1618     -1.5131764411926270e+00
    phi[3,1]  R1619     -2.2146458625793457e+00
    phi[3,1]  R1620     -2.8437602519989014e+00
    phi[3,1]  R1621     -1.9709444046020508e+00
    phi[3,1]  R1622     -2.7090756893157959e+00
    phi[3,1]  R1623     6.9363170862197876e-01
    phi[3,1]  R1624     -3.5887582302093506e+00
    phi[3,1]  R1625     -2.1472158432006836e+00
    phi[3,1]  R1626     -1.1698952913284302e+00
    phi[3,1]  R1627     -1.0071306228637695e+00
    phi[3,1]  R1628     -3.1328707933425903e-01
    phi[3,1]  R1629     -2.3223714828491211e+00
    phi[3,1]  R1630     -5.4970771074295044e-01
    phi[3,1]  R1631     -2.2064430713653564e+00
    phi[3,1]  R1632     -1.7289621829986572e+00
    phi[3,1]  R1633     6.3487333059310913e-01
    phi[3,1]  R1634     -1.7122546434402466e+00
    phi[3,1]  R1635     -2.6690256595611572e+00
    phi[3,1]  R1636     -0.938790500164032
    phi[3,1]  R1637     -4.2683696746826172e-01
    phi[3,1]  R1638     5.2789485454559326e-01
    phi[3,1]  R1639     -9.2152498662471771e-02
    phi[3,1]  R1640     -7.9752969741821289e-01
    phi[3,1]  R1641     -4.1551375389099121e-01
    phi[3,1]  R1642     1.9322213530540466e-01
    phi[3,1]  R1643     -3.6988839507102966e-01
    phi[3,1]  R1644     -9.1805893182754517e-01
    phi[3,1]  R1645     -1.6616492271423340e+00
    phi[3,1]  R1646     -4.6592962741851807e-01
    phi[3,1]  R1647     -4.1624480485916138e-01
    phi[3,1]  R1648     -1.6522699594497681e+00
    phi[3,1]  R1649     -2.9949298501014709e-01
    phi[3,1]  R1650     -4.9342375993728638e-01
    phi[3,1]  R1651     2.0489859580993652e-01
    phi[3,1]  R1652     -2.3568347096443176e-01
    phi[3,1]  R1653     4.9836745858192444e-01
    phi[3,1]  R1654     -2.0114161074161530e-01
    phi[3,1]  R1655     -1.4786535501480103e-01
    phi[3,1]  R1656     -2.2979476451873779e+00
    phi[3,1]  R1657     -2.4417271614074707e+00
    phi[3,1]  R1658     -0.608791708946228
    phi[3,1]  R1659     -7.5657713413238525e-01
    phi[3,1]  R1660     -1.6928552091121674e-01
    phi[3,1]  R1661     -4.2221364378929138e-01
    phi[3,1]  R1662     -2.1813564300537109e+00
    phi[3,1]  R1663     -1.6793943643569946e+00
    phi[3,1]  R1664     -1.4341770410537720e+00
    phi[3,1]  R1665     6.9603103399276733e-01
    phi[3,1]  R1666     -2.4170310497283936e+00
    phi[3,1]  R1667     -2.4902503490448
    phi[3,1]  R1668     -3.1595468521118164e+00
    phi[3,1]  R1669     -7.7070689201354980e-01
    phi[3,1]  R1670     5.7555443048477173e-01
    phi[3,1]  R1671     -1.0543503761291504e+00
    phi[3,1]  R1672     -1.4689840078353882e+00
    phi[3,1]  R1673     -1.8150148391723633e+00
    phi[3,1]  R1674     -2.24212646484375
    phi[3,1]  R1675     9.1855216026306152e-01
    phi[3,1]  R1676     2.0229821205139160e+00
    phi[3,1]  R1677     1.1362160444259644e+00
    phi[3,1]  R1678     1.7421575784683228e+00
    phi[3,1]  R1679     1.2180356979370117e+00
    phi[3,1]  R1680     1.4911606311798096e+00
    phi[3,1]  R1681     -1.1571743488311768e+00
    phi[3,1]  R1682     4.1092571616172791e-01
    phi[3,1]  R1683     2.7789559364318848e+00
    phi[3,1]  R1684     8.9358985424041748e-01
    phi[3,1]  R1685     -2.5442802906036377e-01
    phi[3,1]  R1686     -1.0684536695480347e+00
    phi[3,1]  R1687     -7.8112149238586426e-01
    phi[3,1]  R1688     2.0280052721500397e-01
    phi[3,1]  R1689     1.6316264867782593e-01
    phi[3,1]  R1690     -8.6830848455429077e-01
    phi[3,1]  R1691     -6.4931607246398926e-01
    phi[3,1]  R1692     -2.1885073184967041e+00
    phi[3,1]  R1693     3.3732259273529053e-01
    phi[3,1]  R1694     3.5390856862068176e-01
    phi[3,1]  R1695     -1.7167161703109741e+00
    phi[3,1]  R1696     -3.3098659515380859e+00
    phi[3,1]  R1697     -1.1761126518249512e+00
    phi[3,1]  R1698     -3.8746683597564697e+00
    phi[3,1]  R1699     -3.9582734107971191e+00
    phi[3,1]  R1700     -3.8111178874969482e+00
    phi[3,1]  R1701     -3.2247092723846436e+00
    phi[3,1]  R1702     -4.4284863471984863e+00
    phi[3,1]  R1703     -4.3337659835815430e+00
    phi[3,1]  R1704     -1.1832810640335083e+00
    phi[3,1]  R1705     -1.0195195674896240e+00
    phi[3,1]  R1706     -1.0746871232986450e+00
    phi[3,1]  R1707     -2.1516628563404083e-01
    phi[3,1]  R1708     -3.1335551738739014e+00
    phi[3,1]  R1709     -1.7886148691177368e+00
    phi[3,1]  R1710     9.5990240573883057e-02
    phi[3,1]  R1711     1.8971029669046402e-02
    phi[3,1]  R1712     -3.6602160930633545e+00
    phi[3,1]  R1713     -2.7257649898529053e+00
    phi[3,1]  R1714     -2.1867661476135254e+00
    phi[3,1]  R1715     -1.5625164508819580e+00
    phi[3,1]  R1716     -2.2245893478393555e+00
    phi[3,1]  R1717     -3.5115263462066650e+00
    phi[3,1]  R1718     -3.1751241683959961e+00
    phi[3,1]  R1719     4.4702652096748352e-01
    phi[3,1]  R1720     -3.3355190753936768e+00
    phi[3,1]  R1721     -3.1068332195281982e+00
    phi[3,1]  R1722     -2.8701744079589844e+00
    phi[3,1]  R1723     -2.9495816230773926e+00
    phi[3,1]  R1724     -2.5194933414459229e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R1725     -3.0999999046325684e+00
    phi[1,4]  R1726     -3.0999999046325684e+00
    phi[1,4]  R1727     -2.2400000095367432e+00
    phi[1,4]  R1728     -2.2400000095367432e+00
    phi[1,4]  R1729     -3.0999999046325684e+00
    phi[1,4]  R1730     -3.0999999046325684e+00
    phi[1,4]  R1731     -2.5699999332427979e+00
    phi[1,4]  R1732     -2.5699999332427979e+00
    phi[1,4]  R1733     -3.0999999046325684e+00
    phi[1,4]  R1734     -3.0999999046325684e+00
    phi[1,4]  R1735     -2.0899999141693115e+00
    phi[1,4]  R1736     -2.0899999141693115e+00
    phi[1,4]  R1737     -3.0999999046325684e+00
    phi[1,4]  R1738     -3.0999999046325684e+00
    phi[1,4]  R1739     9.1855216026306152e-01
    phi[1,4]  R1740     2.0229821205139160e+00
    phi[1,4]  R1741     1.1362160444259644e+00
    phi[1,4]  R1742     1.7421575784683228e+00
    phi[1,4]  R1743     1.2180356979370117e+00
    phi[1,4]  R1744     1.4911606311798096e+00
    phi[1,4]  R1745     -1.1571743488311768e+00
    phi[1,4]  R1746     4.1092571616172791e-01
    phi[1,4]  R1747     2.7789559364318848e+00
    phi[1,4]  R1748     8.9358985424041748e-01
    phi[1,4]  R1749     -2.5442802906036377e-01
    phi[1,4]  R1750     -1.0684536695480347e+00
    phi[1,4]  R1751     -7.8112149238586426e-01
    phi[1,4]  R1752     2.0280052721500397e-01
    phi[1,4]  R1753     1.6316264867782593e-01
    phi[1,4]  R1754     -8.6830848455429077e-01
    phi[1,4]  R1755     -6.4931607246398926e-01
    phi[1,4]  R1756     -2.1885073184967041e+00
    phi[1,4]  R1757     3.3732259273529053e-01
    phi[1,4]  R1758     3.5390856862068176e-01
    phi[1,4]  R1759     -1.7167161703109741e+00
    phi[1,4]  R1760     -3.3098659515380859e+00
    phi[1,4]  R1761     -1.1761126518249512e+00
    phi[1,4]  R1762     -3.8746683597564697e+00
    phi[1,4]  R1763     -3.9582734107971191e+00
    phi[1,4]  R1764     -3.8111178874969482e+00
    phi[1,4]  R1765     -3.2247092723846436e+00
    phi[1,4]  R1766     -4.4284863471984863e+00
    phi[1,4]  R1767     -4.3337659835815430e+00
    phi[1,4]  R1768     -1.1832810640335083e+00
    phi[1,4]  R1769     -1.0195195674896240e+00
    phi[1,4]  R1770     -1.0746871232986450e+00
    phi[1,4]  R1771     -2.1516628563404083e-01
    phi[1,4]  R1772     -3.1335551738739014e+00
    phi[1,4]  R1773     -1.7886148691177368e+00
    phi[1,4]  R1774     9.5990240573883057e-02
    phi[1,4]  R1775     1.8971029669046402e-02
    phi[1,4]  R1776     -3.6602160930633545e+00
    phi[1,4]  R1777     -2.7257649898529053e+00
    phi[1,4]  R1778     -2.1867661476135254e+00
    phi[1,4]  R1779     -1.5625164508819580e+00
    phi[1,4]  R1780     -2.2245893478393555e+00
    phi[1,4]  R1781     -3.5115263462066650e+00
    phi[1,4]  R1782     -3.1751241683959961e+00
    phi[1,4]  R1783     4.4702652096748352e-01
    phi[1,4]  R1784     -3.3355190753936768e+00
    phi[1,4]  R1785     -3.1068332195281982e+00
    phi[1,4]  R1786     -2.8701744079589844e+00
    phi[1,4]  R1787     -2.9495816230773926e+00
    phi[1,4]  R1788     -2.5194933414459229e+00
    phi[1,4]  R1789     2.1509380340576172e+00
    phi[1,4]  R1790     2.4451081454753876e-01
    phi[1,4]  R1791     1.8243471384048462e+00
    phi[1,4]  R1792     1.2183016538619995e+00
    phi[1,4]  R1793     7.0984214544296265e-01
    phi[1,4]  R1794     -9.1263687610626221e-01
    phi[1,4]  R1795     0.772459864616394
    phi[1,4]  R1796     7.4859154224395752e-01
    phi[1,4]  R1797     -2.8471606969833374e-01
    phi[1,4]  R1798     1.5720822811126709e+00
    phi[1,4]  R1799     -1.4759303331375122e+00
    phi[1,4]  R1800     -2.0711195468902588e+00
    phi[1,4]  R1801     -2.6037857532501221e+00
    phi[1,4]  R1802     -2.7370514869689941e+00
    phi[1,4]  R1803     -1.8810169696807861e+00
    phi[1,4]  R1804     -1.6757023334503174e+00
    phi[1,4]  R1805     -5.0212895870208740e-01
    phi[1,4]  R1806     -1.3055902719497681e+00
    phi[1,4]  R1807     -1.3431400060653687e+00
    phi[1,4]  R1808     -1.6620051860809326e+00
    phi[1,4]  R1809     -8.6805307865142822e-01
    phi[1,4]  R1810     2.3669712245464325e-01
    phi[1,4]  R1811     2.2730979323387146e-01
    phi[1,4]  R1812     -7.5003856420516968e-01
    phi[1,4]  R1813     -1.0988299846649170e+00
    phi[1,4]  R1814     3.8742080330848694e-02
    phi[1,4]  R1815     -4.6828466653823853e-01
    phi[1,4]  R1816     -4.9756932258605957e-01
    phi[1,4]  R1817     -2.4934850633144379e-01
    phi[1,4]  R1818     4.8790228366851807e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1819     -3.0999999046325684e+00
    phi[4,1]  R1820     -3.0999999046325684e+00
    phi[4,1]  R1821     -2.2400000095367432e+00
    phi[4,1]  R1822     -2.2400000095367432e+00
    phi[4,1]  R1823     -3.0999999046325684e+00
    phi[4,1]  R1824     -3.0999999046325684e+00
    phi[4,1]  R1825     -2.5699999332427979e+00
    phi[4,1]  R1826     -2.5699999332427979e+00
    phi[4,1]  R1827     -3.0999999046325684e+00
    phi[4,1]  R1828     -3.0999999046325684e+00
    phi[4,1]  R1829     -2.0899999141693115e+00
    phi[4,1]  R1830     -2.0899999141693115e+00
    phi[4,1]  R1831     -3.0999999046325684e+00
    phi[4,1]  R1832     -3.0999999046325684e+00
    phi[4,1]  R1833     2.1509380340576172e+00
    phi[4,1]  R1834     2.4451081454753876e-01
    phi[4,1]  R1835     1.8243471384048462e+00
    phi[4,1]  R1836     1.2183016538619995e+00
    phi[4,1]  R1837     7.0984214544296265e-01
    phi[4,1]  R1838     -9.1263687610626221e-01
    phi[4,1]  R1839     0.772459864616394
    phi[4,1]  R1840     7.4859154224395752e-01
    phi[4,1]  R1841     -2.8471606969833374e-01
    phi[4,1]  R1842     1.5720822811126709e+00
    phi[4,1]  R1843     -1.4759303331375122e+00
    phi[4,1]  R1844     -2.0711195468902588e+00
    phi[4,1]  R1845     -2.6037857532501221e+00
    phi[4,1]  R1846     -2.7370514869689941e+00
    phi[4,1]  R1847     -1.8810169696807861e+00
    phi[4,1]  R1848     -1.6757023334503174e+00
    phi[4,1]  R1849     -5.0212895870208740e-01
    phi[4,1]  R1850     -1.3055902719497681e+00
    phi[4,1]  R1851     -1.3431400060653687e+00
    phi[4,1]  R1852     -1.6620051860809326e+00
    phi[4,1]  R1853     -8.6805307865142822e-01
    phi[4,1]  R1854     2.3669712245464325e-01
    phi[4,1]  R1855     2.2730979323387146e-01
    phi[4,1]  R1856     -7.5003856420516968e-01
    phi[4,1]  R1857     -1.0988299846649170e+00
    phi[4,1]  R1858     3.8742080330848694e-02
    phi[4,1]  R1859     -4.6828466653823853e-01
    phi[4,1]  R1860     -4.9756932258605957e-01
    phi[4,1]  R1861     -2.4934850633144379e-01
    phi[4,1]  R1862     4.8790228366851807e-01
    phi[4,1]  R1863     9.1855216026306152e-01
    phi[4,1]  R1864     2.0229821205139160e+00
    phi[4,1]  R1865     1.1362160444259644e+00
    phi[4,1]  R1866     1.7421575784683228e+00
    phi[4,1]  R1867     1.2180356979370117e+00
    phi[4,1]  R1868     1.4911606311798096e+00
    phi[4,1]  R1869     -1.1571743488311768e+00
    phi[4,1]  R1870     4.1092571616172791e-01
    phi[4,1]  R1871     2.7789559364318848e+00
    phi[4,1]  R1872     8.9358985424041748e-01
    phi[4,1]  R1873     -2.5442802906036377e-01
    phi[4,1]  R1874     -1.0684536695480347e+00
    phi[4,1]  R1875     -7.8112149238586426e-01
    phi[4,1]  R1876     2.0280052721500397e-01
    phi[4,1]  R1877     1.6316264867782593e-01
    phi[4,1]  R1878     -8.6830848455429077e-01
    phi[4,1]  R1879     -6.4931607246398926e-01
    phi[4,1]  R1880     -2.1885073184967041e+00
    phi[4,1]  R1881     3.3732259273529053e-01
    phi[4,1]  R1882     3.5390856862068176e-01
    phi[4,1]  R1883     -1.7167161703109741e+00
    phi[4,1]  R1884     -3.3098659515380859e+00
    phi[4,1]  R1885     -1.1761126518249512e+00
    phi[4,1]  R1886     -3.8746683597564697e+00
    phi[4,1]  R1887     -3.9582734107971191e+00
    phi[4,1]  R1888     -3.8111178874969482e+00
    phi[4,1]  R1889     -3.2247092723846436e+00
    phi[4,1]  R1890     -4.4284863471984863e+00
    phi[4,1]  R1891     -4.3337659835815430e+00
    phi[4,1]  R1892     -1.1832810640335083e+00
    phi[4,1]  R1893     -1.0195195674896240e+00
    phi[4,1]  R1894     -1.0746871232986450e+00
    phi[4,1]  R1895     -2.1516628563404083e-01
    phi[4,1]  R1896     -3.1335551738739014e+00
    phi[4,1]  R1897     -1.7886148691177368e+00
    phi[4,1]  R1898     9.5990240573883057e-02
    phi[4,1]  R1899     1.8971029669046402e-02
    phi[4,1]  R1900     -3.6602160930633545e+00
    phi[4,1]  R1901     -2.7257649898529053e+00
    phi[4,1]  R1902     -2.1867661476135254e+00
    phi[4,1]  R1903     -1.5625164508819580e+00
    phi[4,1]  R1904     -2.2245893478393555e+00
    phi[4,1]  R1905     -3.5115263462066650e+00
    phi[4,1]  R1906     -3.1751241683959961e+00
    phi[4,1]  R1907     4.4702652096748352e-01
    phi[4,1]  R1908     -3.3355190753936768e+00
    phi[4,1]  R1909     -3.1068332195281982e+00
    phi[4,1]  R1910     -2.8701744079589844e+00
    phi[4,1]  R1911     -2.9495816230773926e+00
    phi[4,1]  R1912     -2.5194933414459229e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1913     -3.0999999046325684e+00
    phi[2,4]  R1914     -3.0999999046325684e+00
    phi[2,4]  R1915     -2.2400000095367432e+00
    phi[2,4]  R1916     -2.2400000095367432e+00
    phi[2,4]  R1917     -3.0999999046325684e+00
    phi[2,4]  R1918     -3.0999999046325684e+00
    phi[2,4]  R1919     -2.5699999332427979e+00
    phi[2,4]  R1920     -2.5699999332427979e+00
    phi[2,4]  R1921     -3.0999999046325684e+00
    phi[2,4]  R1922     -3.0999999046325684e+00
    phi[2,4]  R1923     -2.0899999141693115e+00
    phi[2,4]  R1924     -2.0899999141693115e+00
    phi[2,4]  R1925     -3.0999999046325684e+00
    phi[2,4]  R1926     -3.0999999046325684e+00
    phi[2,4]  R1927     0.929864227771759
    phi[2,4]  R1928     1.5453511476516724e+00
    phi[2,4]  R1929     2.2167663574218750e+00
    phi[2,4]  R1930     7.7329468727111816e-01
    phi[2,4]  R1931     8.4786951541900635e-01
    phi[2,4]  R1932     2.0617158412933350e+00
    phi[2,4]  R1933     1.8311464786529541e+00
    phi[2,4]  R1934     2.4245779514312744e+00
    phi[2,4]  R1935     1.6866677999496460e+00
    phi[2,4]  R1936     2.1075439453125
    phi[2,4]  R1937     -1.9873582124710083e+00
    phi[2,4]  R1938     -1.4581923484802246e+00
    phi[2,4]  R1939     -8.7205237150192261e-01
    phi[2,4]  R1940     -1.3715356588363647e+00
    phi[2,4]  R1941     -7.9984259605407715e-01
    phi[2,4]  R1942     -1.4912483692169189e+00
    phi[2,4]  R1943     -3.3033929765224457e-02
    phi[2,4]  R1944     -2.5775170326232910e+00
    phi[2,4]  R1945     -2.5482490062713623e+00
    phi[2,4]  R1946     -1.6744478940963745e+00
    phi[2,4]  R1947     3.5166212916374207e-01
    phi[2,4]  R1948     -7.8319799900054932e-01
    phi[2,4]  R1949     1.1445455551147461e+00
    phi[2,4]  R1950     -3.2257111072540283e+00
    phi[2,4]  R1951     -3.2383475303649902e+00
    phi[2,4]  R1952     -2.2900068759918213e+00
    phi[2,4]  R1953     -2.6293735504150391e+00
    phi[2,4]  R1954     -1.6479349136352539e+00
    phi[2,4]  R1955     -3.5671951770782471e+00
    phi[2,4]  R1956     -3.4320468902587891e+00
    phi[2,4]  R1957     -3.9150032997131348e+00
    phi[2,4]  R1958     9.2301227152347565e-02
    phi[2,4]  R1959     -2.2195639610290527e+00
    phi[2,4]  R1960     -1.2671731710433960e+00
    phi[2,4]  R1961     -2.8452377319335938e+00
    phi[2,4]  R1962     -3.9731376171112061e+00
    phi[2,4]  R1963     -5.2245505154132843e-02
    phi[2,4]  R1964     -1.6168293952941895e+00
    phi[2,4]  R1965     -3.05655837059021
    phi[2,4]  R1966     -2.9748830199241638e-01
    phi[2,4]  R1967     -9.3699556589126587e-01
    phi[2,4]  R1968     2.1009275317192078e-01
    phi[2,4]  R1969     -7.0448386669158936e-01
    phi[2,4]  R1970     -3.7879459857940674e+00
    phi[2,4]  R1971     -3.8072686195373535e+00
    phi[2,4]  R1972     -3.0422480106353760e+00
    phi[2,4]  R1973     -3.5803813934326172e+00
    phi[2,4]  R1974     -3.6997475624084473e+00
    phi[2,4]  R1975     -3.9061946868896484e+00
    phi[2,4]  R1976     -3.6559998989105225e+00
    phi[2,4]  R1977     -5.0858810544013977e-02
    phi[2,4]  R1978     -0.923875093460083
    phi[2,4]  R1979     -1.4327594041824341e+00
    phi[2,4]  R1980     -4.1447839736938477e+00
    phi[2,4]  R1981     1.2919595241546631e+00
    phi[2,4]  R1982     -3.0196237564086914e+00
    phi[2,4]  R1983     -3.0316436290740967e+00
    phi[2,4]  R1984     -3.4558148384094238e+00
    phi[2,4]  R1985     -2.2922587394714355e+00
    phi[2,4]  R1986     2.1509380340576172e+00
    phi[2,4]  R1987     2.4451081454753876e-01
    phi[2,4]  R1988     1.8243471384048462e+00
    phi[2,4]  R1989     1.2183016538619995e+00
    phi[2,4]  R1990     7.0984214544296265e-01
    phi[2,4]  R1991     -9.1263687610626221e-01
    phi[2,4]  R1992     0.772459864616394
    phi[2,4]  R1993     7.4859154224395752e-01
    phi[2,4]  R1994     -2.8471606969833374e-01
    phi[2,4]  R1995     1.5720822811126709e+00
    phi[2,4]  R1996     -1.4759303331375122e+00
    phi[2,4]  R1997     -2.0711195468902588e+00
    phi[2,4]  R1998     -2.6037857532501221e+00
    phi[2,4]  R1999     -2.7370514869689941e+00
    phi[2,4]  R2000     -1.8810169696807861e+00
    phi[2,4]  R2001     -1.6757023334503174e+00
    phi[2,4]  R2002     -5.0212895870208740e-01
    phi[2,4]  R2003     -1.3055902719497681e+00
    phi[2,4]  R2004     -1.3431400060653687e+00
    phi[2,4]  R2005     -1.6620051860809326e+00
    phi[2,4]  R2006     -8.6805307865142822e-01
    phi[2,4]  R2007     2.3669712245464325e-01
    phi[2,4]  R2008     2.2730979323387146e-01
    phi[2,4]  R2009     -7.5003856420516968e-01
    phi[2,4]  R2010     -1.0988299846649170e+00
    phi[2,4]  R2011     3.8742080330848694e-02
    phi[2,4]  R2012     -4.6828466653823853e-01
    phi[2,4]  R2013     -4.9756932258605957e-01
    phi[2,4]  R2014     -2.4934850633144379e-01
    phi[2,4]  R2015     4.8790228366851807e-01
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R2016     -3.0999999046325684e+00
    phi[4,2]  R2017     -3.0999999046325684e+00
    phi[4,2]  R2018     -2.2400000095367432e+00
    phi[4,2]  R2019     -2.2400000095367432e+00
    phi[4,2]  R2020     -3.0999999046325684e+00
    phi[4,2]  R2021     -3.0999999046325684e+00
    phi[4,2]  R2022     -2.5699999332427979e+00
    phi[4,2]  R2023     -2.5699999332427979e+00
    phi[4,2]  R2024     -3.0999999046325684e+00
    phi[4,2]  R2025     -3.0999999046325684e+00
    phi[4,2]  R2026     -2.0899999141693115e+00
    phi[4,2]  R2027     -2.0899999141693115e+00
    phi[4,2]  R2028     -3.0999999046325684e+00
    phi[4,2]  R2029     -3.0999999046325684e+00
    phi[4,2]  R2030     2.1509380340576172e+00
    phi[4,2]  R2031     2.4451081454753876e-01
    phi[4,2]  R2032     1.8243471384048462e+00
    phi[4,2]  R2033     1.2183016538619995e+00
    phi[4,2]  R2034     7.0984214544296265e-01
    phi[4,2]  R2035     -9.1263687610626221e-01
    phi[4,2]  R2036     0.772459864616394
    phi[4,2]  R2037     7.4859154224395752e-01
    phi[4,2]  R2038     -2.8471606969833374e-01
    phi[4,2]  R2039     1.5720822811126709e+00
    phi[4,2]  R2040     -1.4759303331375122e+00
    phi[4,2]  R2041     -2.0711195468902588e+00
    phi[4,2]  R2042     -2.6037857532501221e+00
    phi[4,2]  R2043     -2.7370514869689941e+00
    phi[4,2]  R2044     -1.8810169696807861e+00
    phi[4,2]  R2045     -1.6757023334503174e+00
    phi[4,2]  R2046     -5.0212895870208740e-01
    phi[4,2]  R2047     -1.3055902719497681e+00
    phi[4,2]  R2048     -1.3431400060653687e+00
    phi[4,2]  R2049     -1.6620051860809326e+00
    phi[4,2]  R2050     -8.6805307865142822e-01
    phi[4,2]  R2051     2.3669712245464325e-01
    phi[4,2]  R2052     2.2730979323387146e-01
    phi[4,2]  R2053     -7.5003856420516968e-01
    phi[4,2]  R2054     -1.0988299846649170e+00
    phi[4,2]  R2055     3.8742080330848694e-02
    phi[4,2]  R2056     -4.6828466653823853e-01
    phi[4,2]  R2057     -4.9756932258605957e-01
    phi[4,2]  R2058     -2.4934850633144379e-01
    phi[4,2]  R2059     4.8790228366851807e-01
    phi[4,2]  R2060     0.929864227771759
    phi[4,2]  R2061     1.5453511476516724e+00
    phi[4,2]  R2062     2.2167663574218750e+00
    phi[4,2]  R2063     7.7329468727111816e-01
    phi[4,2]  R2064     8.4786951541900635e-01
    phi[4,2]  R2065     2.0617158412933350e+00
    phi[4,2]  R2066     1.8311464786529541e+00
    phi[4,2]  R2067     2.4245779514312744e+00
    phi[4,2]  R2068     1.6866677999496460e+00
    phi[4,2]  R2069     2.1075439453125
    phi[4,2]  R2070     -1.9873582124710083e+00
    phi[4,2]  R2071     -1.4581923484802246e+00
    phi[4,2]  R2072     -8.7205237150192261e-01
    phi[4,2]  R2073     -1.3715356588363647e+00
    phi[4,2]  R2074     -7.9984259605407715e-01
    phi[4,2]  R2075     -1.4912483692169189e+00
    phi[4,2]  R2076     -3.3033929765224457e-02
    phi[4,2]  R2077     -2.5775170326232910e+00
    phi[4,2]  R2078     -2.5482490062713623e+00
    phi[4,2]  R2079     -1.6744478940963745e+00
    phi[4,2]  R2080     3.5166212916374207e-01
    phi[4,2]  R2081     -7.8319799900054932e-01
    phi[4,2]  R2082     1.1445455551147461e+00
    phi[4,2]  R2083     -3.2257111072540283e+00
    phi[4,2]  R2084     -3.2383475303649902e+00
    phi[4,2]  R2085     -2.2900068759918213e+00
    phi[4,2]  R2086     -2.6293735504150391e+00
    phi[4,2]  R2087     -1.6479349136352539e+00
    phi[4,2]  R2088     -3.5671951770782471e+00
    phi[4,2]  R2089     -3.4320468902587891e+00
    phi[4,2]  R2090     -3.9150032997131348e+00
    phi[4,2]  R2091     9.2301227152347565e-02
    phi[4,2]  R2092     -2.2195639610290527e+00
    phi[4,2]  R2093     -1.2671731710433960e+00
    phi[4,2]  R2094     -2.8452377319335938e+00
    phi[4,2]  R2095     -3.9731376171112061e+00
    phi[4,2]  R2096     -5.2245505154132843e-02
    phi[4,2]  R2097     -1.6168293952941895e+00
    phi[4,2]  R2098     -3.05655837059021
    phi[4,2]  R2099     -2.9748830199241638e-01
    phi[4,2]  R2100     -9.3699556589126587e-01
    phi[4,2]  R2101     2.1009275317192078e-01
    phi[4,2]  R2102     -7.0448386669158936e-01
    phi[4,2]  R2103     -3.7879459857940674e+00
    phi[4,2]  R2104     -3.8072686195373535e+00
    phi[4,2]  R2105     -3.0422480106353760e+00
    phi[4,2]  R2106     -3.5803813934326172e+00
    phi[4,2]  R2107     -3.6997475624084473e+00
    phi[4,2]  R2108     -3.9061946868896484e+00
    phi[4,2]  R2109     -3.6559998989105225e+00
    phi[4,2]  R2110     -5.0858810544013977e-02
    phi[4,2]  R2111     -0.923875093460083
    phi[4,2]  R2112     -1.4327594041824341e+00
    phi[4,2]  R2113     -4.1447839736938477e+00
    phi[4,2]  R2114     1.2919595241546631e+00
    phi[4,2]  R2115     -3.0196237564086914e+00
    phi[4,2]  R2116     -3.0316436290740967e+00
    phi[4,2]  R2117     -3.4558148384094238e+00
    phi[4,2]  R2118     -2.2922587394714355e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R20       -1.1495412485338625e+00
    phi[2,6]  R21       -1.8815827920630617e+00
    phi[2,6]  R22       -2.7540048332707734e-01
    phi[2,6]  R23       1.74163336569475
    phi[2,6]  R24       -2.4002680925836386e+00
    phi[2,6]  R25       -1.5872193152635510e+00
    phi[2,6]  R26       -4.1923211215387557e-01
    phi[2,6]  R46       -1
    phi[2,6]  R2119     -4.2495411531664313e+00
    phi[2,6]  R2120     -1.9504586560987058e+00
    phi[2,6]  R2121     -4.1215828015998053e+00
    phi[2,6]  R2122     -3.5841721747368149e-01
    phi[2,6]  R2123     -3.3754003879596457e+00
    phi[2,6]  R2124     -2.8245994213054910e+00
    phi[2,6]  R2125     -8.2836656754804783e-01
    phi[2,6]  R2126     -4.3116332989375481e+00
    phi[2,6]  R2127     -5.5002679972162074e+00
    phi[2,6]  R2128     -6.9973181204892976e-01
    phi[2,6]  R2129     -3.6772192294328625e+00
    phi[2,6]  R2130     -5.0278059890576055e-01
    phi[2,6]  R2131     -3.5192320167864439e+00
    phi[2,6]  R2132     -2.6807677924786928e+00
    phi[2,6]  R2133     -5.2146693950617662e-02
    phi[2,6]  R2134     -5.3459703776673084e-02
    phi[2,6]  R2135     -0.0566863807702247
    phi[2,6]  R2136     -6.1011123634291842e-02
    phi[2,6]  R2137     -1.1064635087834895e-01
    phi[2,6]  R2138     -2.8698707408704127e-01
    phi[2,6]  R2139     -3.0911379811352679e-01
    phi[2,6]  R2140     -3.2859500429603461e-01
    phi[2,6]  R2141     -3.4030235251239738e-01
    phi[2,6]  R2142     -3.4100581451202672e-01
    phi[2,6]  R2143     -2.8972634602667657e-01
    phi[2,6]  R2144     -6.7437983909471533e-01
    phi[2,6]  R2145     -2.9067455388769869e-01
    phi[2,6]  R2146     -3.0405266891638272e-01
    phi[2,6]  R2147     -4.3563260084697641e-01
    phi[2,6]  R2148     -4.5652935354469348e-01
    phi[2,6]  R2149     -4.6229573691803355e-01
    phi[2,6]  R2150     -4.9225790739977882e-01
    phi[2,6]  R2151     -4.9272878187420766e-01
    phi[2,6]  R2152     -5.0912948419075255e-01
    phi[2,6]  R2153     -4.1364045022652551e-01
    phi[2,6]  R2154     -4.3332626731400237e-01
    phi[2,6]  R2155     -4.6059687016619844e-01
    phi[2,6]  R2156     -5.5605977866475875e-01
    phi[2,6]  R2157     -5.5737617916218563e-01
    phi[2,6]  R2158     -6.0234671698463349e-01
    phi[2,6]  R2159     -6.1044038580728621e-01
    phi[2,6]  R2160     -6.1244444854922042e-01
    phi[2,6]  R2161     -6.1607122959320160e-01
    phi[2,6]  R2162     -6.6854085848343336e-01
    phi[2,6]  R2163     -3.4709898679698981e-01
    phi[2,6]  R2164     -3.6762297893343571e-01
    phi[2,6]  R2165     -3.7709423234950279e-01
    phi[2,6]  R2166     -3.8478043536154882e-01
    phi[2,6]  R2167     -4.0508708062555288e-01
    phi[2,6]  R2168     -4.1196192662868913e-01
    phi[2,6]  R2169     -4.1907318205731781e-01
    phi[2,6]  R2170     -4.3857127526929052e-01
    phi[2,6]  R2171     -4.7622768564008533e-01
    phi[2,6]  R2172     -4.8191616532525960e-01
    phi[2,6]  R2173     -2.8988193630386039e-01
    phi[2,6]  R2174     -4.4634326752580467e-01
    phi[2,6]  R2175     -4.8639002047137847e-01
    phi[2,6]  R2176     -5.9664710293590639e-01
    phi[2,6]  R2177     -5.9965217136991589e-01
    phi[2,6]  R2178     -6.1385063524375427e-01
    phi[2,6]  R2179     -6.4561471824714323e-01
    phi[2,6]  R2180     -6.7893497800671376e-01
    phi[2,6]  R2181     -7.3316494058146464e-01
    phi[2,6]  R2182     -1.0401675555037646e+00
    phi[2,6]  R2183     -0.380904382683375
    phi[2,6]  R2184     -4.0948440855549362e-01
    phi[2,6]  R2185     -4.3773206067599624e-01
    phi[2,6]  R2186     -4.9965288650236728e-01
    phi[2,6]  R2187     -5.0617316140919977e-01
    phi[2,6]  R2188     -7.0458534758384728e-01
    phi[2,6]  R2189     -6.0932727563726408e-01
    phi[2,6]  R2190     -6.2306488055811826e-01
    phi[2,6]  R2191     -3.1241376772754381e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2192     -3.0999999046325684e+00
    phi[3,4]  R2193     -3.0999999046325684e+00
    phi[3,4]  R2194     -2.2400000095367432e+00
    phi[3,4]  R2195     -2.2400000095367432e+00
    phi[3,4]  R2196     -3.0999999046325684e+00
    phi[3,4]  R2197     -3.0999999046325684e+00
    phi[3,4]  R2198     -2.5699999332427979e+00
    phi[3,4]  R2199     -2.5699999332427979e+00
    phi[3,4]  R2200     -3.0999999046325684e+00
    phi[3,4]  R2201     -3.0999999046325684e+00
    phi[3,4]  R2202     -2.0899999141693115e+00
    phi[3,4]  R2203     -2.0899999141693115e+00
    phi[3,4]  R2204     -3.0999999046325684e+00
    phi[3,4]  R2205     -3.0999999046325684e+00
    phi[3,4]  R2206     -6.2218278646469116e-02
    phi[3,4]  R2207     1.6193317249417305e-02
    phi[3,4]  R2208     9.9294596910476685e-01
    phi[3,4]  R2209     -5.4459863901138306e-01
    phi[3,4]  R2210     1.1615632772445679e+00
    phi[3,4]  R2211     1.6844284534454346e+00
    phi[3,4]  R2212     1.3145222663879395e+00
    phi[3,4]  R2213     5.0935935974121094e-01
    phi[3,4]  R2214     6.8022483587265015e-01
    phi[3,4]  R2215     1.0145140886306763e+00
    phi[3,4]  R2216     -3.3789007663726807e+00
    phi[3,4]  R2217     -8.1436145305633545e-01
    phi[3,4]  R2218     -2.4853138625621796e-01
    phi[3,4]  R2219     -6.5565979480743408e-01
    phi[3,4]  R2220     -8.8782489299774170e-01
    phi[3,4]  R2221     -5.6487703323364258e-01
    phi[3,4]  R2222     -2.4411129951477051e+00
    phi[3,4]  R2223     -9.6043968200683594e-01
    phi[3,4]  R2224     -2.2532422542572021e+00
    phi[3,4]  R2225     -1.0918543338775635e+00
    phi[3,4]  R2226     -9.2643189430236816e-01
    phi[3,4]  R2227     -0.514323890209198
    phi[3,4]  R2228     -1.4910717010498047e+00
    phi[3,4]  R2229     -1.4804013967514038e+00
    phi[3,4]  R2230     -3.8691473007202148e+00
    phi[3,4]  R2231     -3.0059163570404053e+00
    phi[3,4]  R2232     1.0095201730728149e+00
    phi[3,4]  R2233     4.2307850718498230e-01
    phi[3,4]  R2234     2.0141877233982086e-01
    phi[3,4]  R2235     1.2394497543573380e-01
    phi[3,4]  R2236     -2.7115573883056641e+00
    phi[3,4]  R2237     -1.5982079505920410e+00
    phi[3,4]  R2238     4.6932065486907959e-01
    phi[3,4]  R2239     -1.5131764411926270e+00
    phi[3,4]  R2240     -2.2146458625793457e+00
    phi[3,4]  R2241     -2.8437602519989014e+00
    phi[3,4]  R2242     -1.9709444046020508e+00
    phi[3,4]  R2243     -2.7090756893157959e+00
    phi[3,4]  R2244     6.9363170862197876e-01
    phi[3,4]  R2245     -3.5887582302093506e+00
    phi[3,4]  R2246     -2.1472158432006836e+00
    phi[3,4]  R2247     -1.1698952913284302e+00
    phi[3,4]  R2248     -1.0071306228637695e+00
    phi[3,4]  R2249     -3.1328707933425903e-01
    phi[3,4]  R2250     -2.3223714828491211e+00
    phi[3,4]  R2251     -5.4970771074295044e-01
    phi[3,4]  R2252     -2.2064430713653564e+00
    phi[3,4]  R2253     -1.7289621829986572e+00
    phi[3,4]  R2254     6.3487333059310913e-01
    phi[3,4]  R2255     -1.7122546434402466e+00
    phi[3,4]  R2256     -2.6690256595611572e+00
    phi[3,4]  R2257     -0.938790500164032
    phi[3,4]  R2258     -4.2683696746826172e-01
    phi[3,4]  R2259     5.2789485454559326e-01
    phi[3,4]  R2260     -9.2152498662471771e-02
    phi[3,4]  R2261     -7.9752969741821289e-01
    phi[3,4]  R2262     -4.1551375389099121e-01
    phi[3,4]  R2263     1.9322213530540466e-01
    phi[3,4]  R2264     -3.6988839507102966e-01
    phi[3,4]  R2265     -9.1805893182754517e-01
    phi[3,4]  R2266     -1.6616492271423340e+00
    phi[3,4]  R2267     -4.6592962741851807e-01
    phi[3,4]  R2268     -4.1624480485916138e-01
    phi[3,4]  R2269     -1.6522699594497681e+00
    phi[3,4]  R2270     -2.9949298501014709e-01
    phi[3,4]  R2271     -4.9342375993728638e-01
    phi[3,4]  R2272     2.0489859580993652e-01
    phi[3,4]  R2273     -2.3568347096443176e-01
    phi[3,4]  R2274     4.9836745858192444e-01
    phi[3,4]  R2275     -2.0114161074161530e-01
    phi[3,4]  R2276     -1.4786535501480103e-01
    phi[3,4]  R2277     -2.2979476451873779e+00
    phi[3,4]  R2278     -2.4417271614074707e+00
    phi[3,4]  R2279     -0.608791708946228
    phi[3,4]  R2280     -7.5657713413238525e-01
    phi[3,4]  R2281     -1.6928552091121674e-01
    phi[3,4]  R2282     -4.2221364378929138e-01
    phi[3,4]  R2283     -2.1813564300537109e+00
    phi[3,4]  R2284     -1.6793943643569946e+00
    phi[3,4]  R2285     -1.4341770410537720e+00
    phi[3,4]  R2286     6.9603103399276733e-01
    phi[3,4]  R2287     -2.4170310497283936e+00
    phi[3,4]  R2288     -2.4902503490448
    phi[3,4]  R2289     -3.1595468521118164e+00
    phi[3,4]  R2290     -7.7070689201354980e-01
    phi[3,4]  R2291     5.7555443048477173e-01
    phi[3,4]  R2292     -1.0543503761291504e+00
    phi[3,4]  R2293     -1.4689840078353882e+00
    phi[3,4]  R2294     -1.8150148391723633e+00
    phi[3,4]  R2295     -2.24212646484375
    phi[3,4]  R2296     2.1509380340576172e+00
    phi[3,4]  R2297     2.4451081454753876e-01
    phi[3,4]  R2298     1.8243471384048462e+00
    phi[3,4]  R2299     1.2183016538619995e+00
    phi[3,4]  R2300     7.0984214544296265e-01
    phi[3,4]  R2301     -9.1263687610626221e-01
    phi[3,4]  R2302     0.772459864616394
    phi[3,4]  R2303     7.4859154224395752e-01
    phi[3,4]  R2304     -2.8471606969833374e-01
    phi[3,4]  R2305     1.5720822811126709e+00
    phi[3,4]  R2306     -1.4759303331375122e+00
    phi[3,4]  R2307     -2.0711195468902588e+00
    phi[3,4]  R2308     -2.6037857532501221e+00
    phi[3,4]  R2309     -2.7370514869689941e+00
    phi[3,4]  R2310     -1.8810169696807861e+00
    phi[3,4]  R2311     -1.6757023334503174e+00
    phi[3,4]  R2312     -5.0212895870208740e-01
    phi[3,4]  R2313     -1.3055902719497681e+00
    phi[3,4]  R2314     -1.3431400060653687e+00
    phi[3,4]  R2315     -1.6620051860809326e+00
    phi[3,4]  R2316     -8.6805307865142822e-01
    phi[3,4]  R2317     2.3669712245464325e-01
    phi[3,4]  R2318     2.2730979323387146e-01
    phi[3,4]  R2319     -7.5003856420516968e-01
    phi[3,4]  R2320     -1.0988299846649170e+00
    phi[3,4]  R2321     3.8742080330848694e-02
    phi[3,4]  R2322     -4.6828466653823853e-01
    phi[3,4]  R2323     -4.9756932258605957e-01
    phi[3,4]  R2324     -2.4934850633144379e-01
    phi[3,4]  R2325     4.8790228366851807e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2326     -3.0999999046325684e+00
    phi[4,3]  R2327     -3.0999999046325684e+00
    phi[4,3]  R2328     -2.2400000095367432e+00
    phi[4,3]  R2329     -2.2400000095367432e+00
    phi[4,3]  R2330     -3.0999999046325684e+00
    phi[4,3]  R2331     -3.0999999046325684e+00
    phi[4,3]  R2332     -2.5699999332427979e+00
    phi[4,3]  R2333     -2.5699999332427979e+00
    phi[4,3]  R2334     -3.0999999046325684e+00
    phi[4,3]  R2335     -3.0999999046325684e+00
    phi[4,3]  R2336     -2.0899999141693115e+00
    phi[4,3]  R2337     -2.0899999141693115e+00
    phi[4,3]  R2338     -3.0999999046325684e+00
    phi[4,3]  R2339     -3.0999999046325684e+00
    phi[4,3]  R2340     2.1509380340576172e+00
    phi[4,3]  R2341     2.4451081454753876e-01
    phi[4,3]  R2342     1.8243471384048462e+00
    phi[4,3]  R2343     1.2183016538619995e+00
    phi[4,3]  R2344     7.0984214544296265e-01
    phi[4,3]  R2345     -9.1263687610626221e-01
    phi[4,3]  R2346     0.772459864616394
    phi[4,3]  R2347     7.4859154224395752e-01
    phi[4,3]  R2348     -2.8471606969833374e-01
    phi[4,3]  R2349     1.5720822811126709e+00
    phi[4,3]  R2350     -1.4759303331375122e+00
    phi[4,3]  R2351     -2.0711195468902588e+00
    phi[4,3]  R2352     -2.6037857532501221e+00
    phi[4,3]  R2353     -2.7370514869689941e+00
    phi[4,3]  R2354     -1.8810169696807861e+00
    phi[4,3]  R2355     -1.6757023334503174e+00
    phi[4,3]  R2356     -5.0212895870208740e-01
    phi[4,3]  R2357     -1.3055902719497681e+00
    phi[4,3]  R2358     -1.3431400060653687e+00
    phi[4,3]  R2359     -1.6620051860809326e+00
    phi[4,3]  R2360     -8.6805307865142822e-01
    phi[4,3]  R2361     2.3669712245464325e-01
    phi[4,3]  R2362     2.2730979323387146e-01
    phi[4,3]  R2363     -7.5003856420516968e-01
    phi[4,3]  R2364     -1.0988299846649170e+00
    phi[4,3]  R2365     3.8742080330848694e-02
    phi[4,3]  R2366     -4.6828466653823853e-01
    phi[4,3]  R2367     -4.9756932258605957e-01
    phi[4,3]  R2368     -2.4934850633144379e-01
    phi[4,3]  R2369     4.8790228366851807e-01
    phi[4,3]  R2370     -6.2218278646469116e-02
    phi[4,3]  R2371     1.6193317249417305e-02
    phi[4,3]  R2372     9.9294596910476685e-01
    phi[4,3]  R2373     -5.4459863901138306e-01
    phi[4,3]  R2374     1.1615632772445679e+00
    phi[4,3]  R2375     1.6844284534454346e+00
    phi[4,3]  R2376     1.3145222663879395e+00
    phi[4,3]  R2377     5.0935935974121094e-01
    phi[4,3]  R2378     6.8022483587265015e-01
    phi[4,3]  R2379     1.0145140886306763e+00
    phi[4,3]  R2380     -3.3789007663726807e+00
    phi[4,3]  R2381     -8.1436145305633545e-01
    phi[4,3]  R2382     -2.4853138625621796e-01
    phi[4,3]  R2383     -6.5565979480743408e-01
    phi[4,3]  R2384     -8.8782489299774170e-01
    phi[4,3]  R2385     -5.6487703323364258e-01
    phi[4,3]  R2386     -2.4411129951477051e+00
    phi[4,3]  R2387     -9.6043968200683594e-01
    phi[4,3]  R2388     -2.2532422542572021e+00
    phi[4,3]  R2389     -1.0918543338775635e+00
    phi[4,3]  R2390     -9.2643189430236816e-01
    phi[4,3]  R2391     -0.514323890209198
    phi[4,3]  R2392     -1.4910717010498047e+00
    phi[4,3]  R2393     -1.4804013967514038e+00
    phi[4,3]  R2394     -3.8691473007202148e+00
    phi[4,3]  R2395     -3.0059163570404053e+00
    phi[4,3]  R2396     1.0095201730728149e+00
    phi[4,3]  R2397     4.2307850718498230e-01
    phi[4,3]  R2398     2.0141877233982086e-01
    phi[4,3]  R2399     1.2394497543573380e-01
    phi[4,3]  R2400     -2.7115573883056641e+00
    phi[4,3]  R2401     -1.5982079505920410e+00
    phi[4,3]  R2402     4.6932065486907959e-01
    phi[4,3]  R2403     -1.5131764411926270e+00
    phi[4,3]  R2404     -2.2146458625793457e+00
    phi[4,3]  R2405     -2.8437602519989014e+00
    phi[4,3]  R2406     -1.9709444046020508e+00
    phi[4,3]  R2407     -2.7090756893157959e+00
    phi[4,3]  R2408     6.9363170862197876e-01
    phi[4,3]  R2409     -3.5887582302093506e+00
    phi[4,3]  R2410     -2.1472158432006836e+00
    phi[4,3]  R2411     -1.1698952913284302e+00
    phi[4,3]  R2412     -1.0071306228637695e+00
    phi[4,3]  R2413     -3.1328707933425903e-01
    phi[4,3]  R2414     -2.3223714828491211e+00
    phi[4,3]  R2415     -5.4970771074295044e-01
    phi[4,3]  R2416     -2.2064430713653564e+00
    phi[4,3]  R2417     -1.7289621829986572e+00
    phi[4,3]  R2418     6.3487333059310913e-01
    phi[4,3]  R2419     -1.7122546434402466e+00
    phi[4,3]  R2420     -2.6690256595611572e+00
    phi[4,3]  R2421     -0.938790500164032
    phi[4,3]  R2422     -4.2683696746826172e-01
    phi[4,3]  R2423     5.2789485454559326e-01
    phi[4,3]  R2424     -9.2152498662471771e-02
    phi[4,3]  R2425     -7.9752969741821289e-01
    phi[4,3]  R2426     -4.1551375389099121e-01
    phi[4,3]  R2427     1.9322213530540466e-01
    phi[4,3]  R2428     -3.6988839507102966e-01
    phi[4,3]  R2429     -9.1805893182754517e-01
    phi[4,3]  R2430     -1.6616492271423340e+00
    phi[4,3]  R2431     -4.6592962741851807e-01
    phi[4,3]  R2432     -4.1624480485916138e-01
    phi[4,3]  R2433     -1.6522699594497681e+00
    phi[4,3]  R2434     -2.9949298501014709e-01
    phi[4,3]  R2435     -4.9342375993728638e-01
    phi[4,3]  R2436     2.0489859580993652e-01
    phi[4,3]  R2437     -2.3568347096443176e-01
    phi[4,3]  R2438     4.9836745858192444e-01
    phi[4,3]  R2439     -2.0114161074161530e-01
    phi[4,3]  R2440     -1.4786535501480103e-01
    phi[4,3]  R2441     -2.2979476451873779e+00
    phi[4,3]  R2442     -2.4417271614074707e+00
    phi[4,3]  R2443     -0.608791708946228
    phi[4,3]  R2444     -7.5657713413238525e-01
    phi[4,3]  R2445     -1.6928552091121674e-01
    phi[4,3]  R2446     -4.2221364378929138e-01
    phi[4,3]  R2447     -2.1813564300537109e+00
    phi[4,3]  R2448     -1.6793943643569946e+00
    phi[4,3]  R2449     -1.4341770410537720e+00
    phi[4,3]  R2450     6.9603103399276733e-01
    phi[4,3]  R2451     -2.4170310497283936e+00
    phi[4,3]  R2452     -2.4902503490448
    phi[4,3]  R2453     -3.1595468521118164e+00
    phi[4,3]  R2454     -7.7070689201354980e-01
    phi[4,3]  R2455     5.7555443048477173e-01
    phi[4,3]  R2456     -1.0543503761291504e+00
    phi[4,3]  R2457     -1.4689840078353882e+00
    phi[4,3]  R2458     -1.8150148391723633e+00
    phi[4,3]  R2459     -2.24212646484375
    phi[5,3]  R27       -1
    phi[5,3]  R29       2.5751496212211351e+00
    phi[5,3]  R30       2.1461293892893973e-02
    phi[5,3]  R31       -2.1846339557291019e+00
    phi[5,3]  R32       -4.0334766786202625e-02
    phi[5,3]  R33       1.0862953931011057e+00
    phi[5,3]  R34       0.681411138239798
    phi[5,3]  R35       -1.6529561385600251e+00
    phi[5,3]  R45       1
    phi[5,3]  R2460     -5.6751495258537030e+00
    phi[5,3]  R2461     -5.2485028341143325e-01
    phi[5,3]  R2462     -2.2614613034296371e+00
    phi[5,3]  R2463     -2.2185387156438492e+00
    phi[5,3]  R2464     -9.1536594890346645e-01
    phi[5,3]  R2465     -5.28463386036167
    phi[5,3]  R2466     -2.5296651664565952e+00
    phi[5,3]  R2467     -2.6103347000290005e+00
    phi[5,3]  R2468     -4.1862952977336736e+00
    phi[5,3]  R2469     -2.0137045115314627e+00
    phi[5,3]  R2470     -2.7714110524091096e+00
    phi[5,3]  R2471     -1.4085887759295135e+00
    phi[5,3]  R2472     -1.4470437660725433e+00
    phi[5,3]  R2473     -4.7529560431925937e+00
    phi[5,3]  R2474     -2.7271291427340838e-01
    phi[5,3]  R2475     -1.8917429717074965e+00
    phi[5,3]  R2476     -1.8078389198199947e+00
    phi[5,3]  R2477     -3.5272783603331948e-01
    phi[5,3]  R2478     -1.4758756521557839e+00
    phi[5,3]  R2479     -1.1375830249002821e+00
    phi[5,3]  R2480     -1.5973573688346030e+00
    phi[5,3]  R2481     -1.3984970595213446e+00
    phi[5,3]  R2482     -1.7102161303975376e+00
    phi[5,3]  R2483     -1.5975117148292806e+00
    phi[5,3]  R2484     -4.2156155929972305e-01
    phi[5,3]  R2485     -7.2422895114011909e-01
    phi[5,3]  R2486     -5.9669677356252637e-01
    phi[5,3]  R2487     -6.1418653416830360e-01
    phi[5,3]  R2488     -6.3215199596453975e-01
    phi[5,3]  R2489     -6.4252523344647750e-01
    phi[5,3]  R2490     -6.5334577357969081e-01
    phi[5,3]  R2491     -6.7374661523489210e-01
    phi[5,3]  R2492     -7.0598155138166607e-01
    phi[5,3]  R2493     -7.2450394803863039e-01
    phi[5,3]  R2494     -4.0838582348480790e-01
    phi[5,3]  R2495     -4.1418389098894781e-01
    phi[5,3]  R2496     -4.3909334714875192e-01
    phi[5,3]  R2497     -5.0217126438830673e-01
    phi[5,3]  R2498     -5.2070190868084376e-01
    phi[5,3]  R2499     -5.4318583277559185e-01
    phi[5,3]  R2500     -7.1604519196895078e-01
    phi[5,3]  R2501     -0.740472314913077
    phi[5,3]  R2502     -7.4998447915908684e-01
    phi[5,3]  R2503     -7.5028197648584816e-01
    phi[5,3]  R2504     -2.9381512436567947e-01
    phi[5,3]  R2505     -3.8274154962632068e-01
    phi[5,3]  R2506     -6.9647245560379467e-01
    phi[5,3]  R2507     -5.7772430366391681e-01
    phi[5,3]  R2508     -6.5979590269888022e-01
    phi[5,3]  R2509     -6.9637747816670714e-01
    phi[5,3]  R2510     -0.70341443348537
    phi[5,3]  R2511     -7.3868564170171913e-01
    phi[5,3]  R2512     -7.5327866890344652e-01
    phi[5,3]  R2513     -7.7081171965005213e-01
    phi[5,3]  R2514     -3.1652468678688295e-01
    phi[5,3]  R2515     -1.1556863343720016e+00
    phi[5,3]  R2516     -3.7374462909652673e-01
    phi[5,3]  R2517     -4.4035425566521935e-01
    phi[5,3]  R2518     -4.5670710355361566e-01
    phi[5,3]  R2519     -2.0828738415090529e+00
    phi[5,3]  R2520     -6.3606733660194048e-01
    phi[5,3]  R2521     -0.667067610622514
    phi[5,3]  R2522     -7.6080073393185677e-01
    phi[5,3]  R2523     -0.780891441607475
    phi[5,3]  R2524     -2.5952979376024210e-01
    phi[5,3]  R2525     -2.1192973260654542e+00
    phi[5,3]  R2526     -4.3603909764447635e-01
    phi[5,3]  R2527     -0.472987368709896
    phi[5,3]  R2528     -4.8805879328155133e-01
    phi[5,3]  R2529     -7.5982574486542342e-01
    phi[5,3]  R2530     -7.7795423778304063e-01
    phi[5,3]  R2531     -8.0291753260745868e-01
    phi[5,3]  R2532     -8.3229233765258770e-01
    phi[5,3]  R2533     -8.6095460968632342e-01
    phi[5,3]  R2534     -2.8740127335275290e-01
    phi[5,3]  R2535     -8.8378875759876141e-01
    phi[5,3]  R2536     -3.8688676700473684e-01
    phi[5,3]  R2537     -7.6434455968740145e-01
    phi[5,3]  R2538     -7.6516956938181324e-01
    phi[5,3]  R2539     -7.9040285470656446e-01
    phi[5,3]  R2540     -7.9419470561536831e-01
    phi[5,3]  R2541     -8.1423483984840628e-01
    phi[5,3]  R2542     -8.1872573373956992e-01
    phi[5,3]  R2543     -8.3035934681648571e-01
    phi[5,3]  R2544     -4.3238232460488490e-01
    phi[5,3]  R2545     -0.666923774231966
    phi[5,3]  R2546     -7.4353405879028056e-01
    phi[5,3]  R2547     -7.8524710795421737e-01
    phi[5,3]  R2548     -7.9744004532709345e-01
    phi[5,3]  R2549     -8.0650354910333222e-01
    phi[5,3]  R2550     -0.861148542586937
    phi[5,3]  R2551     -8.7194776093771154e-01
    phi[5,3]  R2552     -0.900330889966631
    phi[5,3]  R2553     -9.2059858287296836e-01
    phi[5,3]  R2554     -3.5748554993333603e-01
    phi[5,3]  R2555     -1.5524492910646288e+00
    phi[5,3]  R2556     -6.6498616410659839e-01
    phi[5,3]  R2557     -0.708603458378704
    phi[5,3]  R2558     -7.2317058880680585e-01
    phi[5,3]  R2559     -7.6897211669355969e-01
    phi[5,3]  R2560     -8.9021779683443780e-01
    phi[5,3]  R2561     -8.9361716406705793e-01
    phi[5,3]  R2562     -9.3862640223956528e-01
    phi[5,3]  R2563     -9.4599116036888620e-01
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R38       -1.1495412485338625e+00
    phi[4,6]  R39       -1.8815827920630617e+00
    phi[4,6]  R40       -2.7540048332707734e-01
    phi[4,6]  R41       1.74163336569475
    phi[4,6]  R42       -2.4002680925836386e+00
    phi[4,6]  R43       -1.5872193152635510e+00
    phi[4,6]  R44       -4.1923211215387557e-01
    phi[4,6]  R46       -1
    phi[4,6]  R2564     -4.2495411531664313e+00
    phi[4,6]  R2565     -1.9504586560987058e+00
    phi[4,6]  R2566     -4.1215828015998053e+00
    phi[4,6]  R2567     -3.5841721747368149e-01
    phi[4,6]  R2568     -3.3754003879596457e+00
    phi[4,6]  R2569     -2.8245994213054910e+00
    phi[4,6]  R2570     -8.2836656754804783e-01
    phi[4,6]  R2571     -4.3116332989375481e+00
    phi[4,6]  R2572     -5.5002679972162074e+00
    phi[4,6]  R2573     -6.9973181204892976e-01
    phi[4,6]  R2574     -3.6772192294328625e+00
    phi[4,6]  R2575     -5.0278059890576055e-01
    phi[4,6]  R2576     -3.5192320167864439e+00
    phi[4,6]  R2577     -2.6807677924786928e+00
    phi[4,6]  R2578     -0.0492131062703951
    phi[4,6]  R2579     -5.4199989573508134e-02
    phi[4,6]  R2580     -5.5744903352477504e-02
    phi[4,6]  R2581     -6.6669580891334013e-02
    phi[4,6]  R2582     -3.1741893124311704e-01
    phi[4,6]  R2583     -3.2016923454633472e-01
    phi[4,6]  R2584     -3.3933422561044435e-01
    phi[4,6]  R2585     -3.4109131699898732e-01
    phi[4,6]  R2586     -8.9181673684775487e-01
    phi[4,6]  R2587     -3.7894873649636551e-01
    phi[4,6]  R2588     -1.7904828828644792e-01
    phi[4,6]  R2589     -1.8887992181940683e-01
    phi[4,6]  R2590     -1.8993303802054795e-01
    phi[4,6]  R2591     -1.9415302022600489e-01
    phi[4,6]  R2592     -1.9738434606564481e-01
    phi[4,6]  R2593     -1.9874554679787249e-01
    phi[4,6]  R2594     -2.3682592730876784e-01
    phi[4,6]  R2595     -3.1973841692978733e-01
    phi[4,6]  R2596     -3.3436736494361718e-01
    phi[4,6]  R2597     -3.4321662400132014e-01
    phi[4,6]  R2598     -3.1045376278887971e-01
    phi[4,6]  R2599     -3.2612290139187239e-01
    phi[4,6]  R2600     -4.5476822703797726e-01
    phi[4,6]  R2601     -4.8835015902554796e-01
    phi[4,6]  R2602     -5.4222002834041061e-01
    phi[4,6]  R2603     -5.9775907945115025e-01
    phi[4,6]  R2604     -5.9986749845341336e-01
    phi[4,6]  R2605     -2.92007976805055
    phi[4,6]  R2606     -1.8963200598954777e+00
    phi[4,6]  R2607     -2.5961647109178174e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R47       -1
    z[0,1,0]  R48       1
    z[0,1,0]  R61       1.3831178843975067e-01
    z[0,1,0]  R62       -2.4963927268981934e-01
    z[0,1,0]  R63       1.5677075088024139e-01
    z[0,1,0]  R64       2.0215308666229248e-01
    z[0,1,0]  R65       3.3621060848236084e-01
    z[0,1,0]  R66       -3.6002430319786072e-01
    z[0,1,0]  R67       2.8251945972442627e-01
    z[0,1,0]  R68       5.3606323897838593e-02
    z[0,1,0]  R69       -2.0865032076835632e-01
    z[0,1,0]  R70       0.0792015790939331
    z[0,1,0]  R71       6.9700604677200317e-01
    z[0,1,0]  R72       4.9385523796081543e-01
    z[0,1,0]  R73       2.7884298563003540e-01
    z[0,1,0]  R74       -6.2758654356002808e-02
    z[0,1,0]  R75       4.4140231609344482e-01
    z[0,1,0]  R76       2.9204022884368896e-01
    z[0,1,0]  R77       0.0990278422832489
    z[0,1,0]  R78       5.6584876775741577e-01
    z[0,1,0]  R79       0.438368558883667
    z[0,1,0]  R80       1.2508645653724670e-01
    z[0,1,0]  R81       4.1417360305786133e-01
    z[0,1,0]  R82       4.1959103941917419e-01
    z[0,1,0]  R83       5.5644816160202026e-01
    z[0,1,0]  R84       6.3575762510299683e-01
    z[0,1,0]  R85       4.1316190361976624e-01
    z[0,1,0]  R86       3.8598445057868958e-01
    z[0,1,0]  R87       2.8113448619842529e-01
    z[0,1,0]  R88       2.4223934113979340e-01
    z[0,1,0]  R89       -3.3876141905784607e-01
    z[0,1,0]  R90       1.6936412453651428e-01
    z[0,1,0]  R91       -2.2780045866966248e-01
    z[0,1,0]  R92       5.2210664749145508e-01
    z[0,1,0]  R93       4.7280839085578918e-01
    z[0,1,0]  R94       3.7545260787010193e-01
    z[0,1,0]  R95       -4.0232321619987488e-01
    z[0,1,0]  R96       4.7286859154701233e-01
    z[0,1,0]  R97       -1.9411759078502655e-01
    z[0,1,0]  R98       9.3059904873371124e-02
    z[0,1,0]  R99       4.1530004143714905e-01
    z[0,1,0]  R100      2.9094433784484863e-01
    z[0,1,0]  R101      4.4050028920173645e-01
    z[0,1,0]  R102      -3.1407541036605835e-01
    z[0,1,0]  R103      -2.5384524837136269e-02
    z[0,1,0]  R104      1.2459943443536758e-01
    z[0,1,0]  R105      -2.3517280817031860e-01
    z[0,1,0]  R106      -5.2083592861890793e-02
    z[0,1,0]  R107      1.4811287820339203e-01
    z[0,1,0]  R108      -6.3537520170211792e-01
    z[0,1,0]  R109      -6.4471709728240967e-01
    z[0,1,0]  R110      -6.5766119956970215e-01
    z[0,1,0]  R111      1.2397421896457672e-01
    z[0,1,0]  R112      6.3077318668365479e-01
    z[0,1,0]  R113      5.0213652849197388e-01
    z[0,1,0]  R114      2.0148406922817230e-01
    z[0,1,0]  R115      -4.1290480643510818e-02
    z[0,1,0]  R116      9.4691142439842224e-02
    z[0,1,0]  R117      -2.8340309858322144e-02
    z[0,1,0]  R118      -2.4740856885910034e-01
    z[0,1,0]  R119      -3.0452784895896912e-01
    z[0,1,0]  R120      -3.8870215415954590e-01
    z[0,1,0]  R121      3.3207225799560547e-01
    z[0,1,0]  R122      2.2497600317001343e-01
    z[0,1,0]  R123      4.0429782867431641e-01
    z[0,1,0]  R124      1.1020505428314209e-01
    z[0,1,0]  R125      3.3701881766319275e-01
    z[0,1,0]  R126      0.297879159450531
    z[0,1,0]  R127      3.9452165365219116e-01
    z[0,1,0]  R128      2.0356547832489014e-01
    z[0,1,0]  R129      -2.6331812143325806e-01
    z[0,1,0]  R130      3.1959950923919678e-01
    z[0,1,0]  R131      5.9074461460113525e-01
    z[0,1,0]  R132      -4.1275955736637115e-02
    z[0,1,0]  R133      -3.7504187226295471e-01
    z[0,1,0]  R134      -5.7928526401519775e-01
    z[0,1,0]  R135      -4.9910187721252441e-01
    z[0,1,0]  R136      -6.3219177722930908e-01
    z[0,1,0]  R137      -3.9742922782897949e-01
    z[0,1,0]  R138      2.3084011673927307e-01
    z[0,1,0]  R139      -9.3423920869827271e-01
    z[0,1,0]  R140      -9.2440533638000488e-01
    z[0,1,0]  R141      2.1656617522239685e-01
    z[0,1,0]  R142      1.9144825637340546e-02
    z[0,1,0]  R143      -5.2586293220520020e-01
    z[0,1,0]  R144      3.0178827047348022e-01
    z[0,1,0]  R145      2.0443785190582275e-01
    z[0,1,0]  R146      -1.7751251161098480e-01
    z[0,1,0]  R147      5.6899610906839371e-02
    z[0,1,0]  R148      1.6422684490680695e-01
    z[0,1,0]  R149      2.9473572969436646e-01
    z[0,1,0]  R150      -6.5723603963851929e-01
    z[0,1,0]  R151      9.5317848026752472e-02
    z[0,1,0]  R152      -5.1086451858282089e-02
    z[0,1,0]  R153      -2.1587809920310974e-01
    z[0,1,0]  R154      7.7477765083312988e-01
    z[0,1,0]  R155      7.0630115270614624e-01
    z[0,1,0]  R156      5.0864154100418091e-01
    z[0,1,0]  R157      5.3289115428924561e-01
    z[0,1,0]  R158      3.1803345680236816e-01
    z[0,1,0]  R159      -4.4739622622728348e-02
    z[0,1,0]  R160      -5.8397495746612549e-01
    z[0,1,0]  R161      -5.5687215179204941e-02
    z[0,1,0]  R162      8.9335137605667114e-01
    z[0,1,0]  R163      -1.7038933932781219e-01
    z[0,1,0]  R164      -3.7038710713386536e-01
    z[0,1,0]  R165      -6.0038655996322632e-01
    z[0,1,0]  R166      4.6409547328948975e-01
    z[0,1,0]  R167      4.3099871277809143e-01
    z[0,1,0]  R168      4.7354349493980408e-01
    z[0,1,0]  R169      4.6459159255027771e-01
    z[0,1,0]  R170      4.6672913432121277e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R49       -1
    z[0,1,1]  R50       1
    z[0,1,1]  R61       5.4261481761932373e-01
    z[0,1,1]  R62       1.8471740186214447e-01
    z[0,1,1]  R63       4.8204636573791504e-01
    z[0,1,1]  R64       6.2353205680847168e-01
    z[0,1,1]  R65       3.3489429950714111e-01
    z[0,1,1]  R66       -8.1334710121154785e-01
    z[0,1,1]  R67       -6.8163412809371948e-01
    z[0,1,1]  R68       -7.3793184757232666e-01
    z[0,1,1]  R69       -6.2932431697845459e-01
    z[0,1,1]  R70       -4.5561450719833374e-01
    z[0,1,1]  R71       2.6548174023628235e-01
    z[0,1,1]  R72       1.7883922159671783e-01
    z[0,1,1]  R73       2.4211584031581879e-01
    z[0,1,1]  R74       -3.7438550591468811e-01
    z[0,1,1]  R75       -6.9548559188842773e-01
    z[0,1,1]  R76       -8.1426960229873657e-01
    z[0,1,1]  R77       -8.8026142120361328e-01
    z[0,1,1]  R78       -5.5686980485916138e-01
    z[0,1,1]  R79       -6.1559689044952393e-01
    z[0,1,1]  R80       -8.6519724130630493e-01
    z[0,1,1]  R81       -7.8430545330047607e-01
    z[0,1,1]  R82       -8.8759505748748779e-01
    z[0,1,1]  R83       -7.8066098690032959e-01
    z[0,1,1]  R84       -7.2174870967864990e-01
    z[0,1,1]  R85       -0.579284131526947
    z[0,1,1]  R86       -0.739266574382782
    z[0,1,1]  R87       -7.4926763772964478e-01
    z[0,1,1]  R88       -0.616884171962738
    z[0,1,1]  R89       -8.8023918867111206e-01
    z[0,1,1]  R90       -8.8934975862503052e-01
    z[0,1,1]  R91       -6.0995358228683472e-01
    z[0,1,1]  R92       -6.6779989004135132e-01
    z[0,1,1]  R93       -5.9846210479736328e-01
    z[0,1,1]  R94       -8.5873937606811523e-01
    z[0,1,1]  R95       -4.8705798387527466e-01
    z[0,1,1]  R96       -5.8593922853469849e-01
    z[0,1,1]  R97       -8.4706974029541016e-01
    z[0,1,1]  R98       -8.3782196044921875e-01
    z[0,1,1]  R99       -7.2321790456771851e-01
    z[0,1,1]  R100      -6.1781018972396851e-01
    z[0,1,1]  R101      -8.2881647348403931e-01
    z[0,1,1]  R102      -9.0422928333282471e-01
    z[0,1,1]  R103      -9.0046817064285278e-01
    z[0,1,1]  R104      -9.6193933486938477e-01
    z[0,1,1]  R105      -0.798782229423523
    z[0,1,1]  R106      -7.6137822866439819e-01
    z[0,1,1]  R107      -4.1610002517700195e-01
    z[0,1,1]  R108      7.1338564157485962e-02
    z[0,1,1]  R109      9.2577107250690460e-02
    z[0,1,1]  R110      7.7672697603702545e-02
    z[0,1,1]  R111      -5.9112477302551270e-01
    z[0,1,1]  R112      -0.6157186627388
    z[0,1,1]  R113      -6.7031729221343994e-01
    z[0,1,1]  R114      -9.1305035352706909e-01
    z[0,1,1]  R115      -9.5023977756500244e-01
    z[0,1,1]  R116      -8.8946694135665894e-01
    z[0,1,1]  R117      -8.7520343065261841e-01
    z[0,1,1]  R118      -7.9479080438613892e-01
    z[0,1,1]  R119      0.0364716611802578
    z[0,1,1]  R120      1.9382598996162415e-01
    z[0,1,1]  R121      -8.4220498800277710e-02
    z[0,1,1]  R122      0.361508309841156
    z[0,1,1]  R123      4.8457989096641541e-01
    z[0,1,1]  R124      -3.2911914587020874e-01
    z[0,1,1]  R125      3.3398628234863281e-01
    z[0,1,1]  R126      -4.8228830099105835e-01
    z[0,1,1]  R127      -1.9169540703296661e-01
    z[0,1,1]  R128      2.1775195002555847e-01
    z[0,1,1]  R129      -2.4984495341777802e-01
    z[0,1,1]  R130      2.1840962767601013e-01
    z[0,1,1]  R131      3.6695379018783569e-01
    z[0,1,1]  R132      6.5316796302795410e-01
    z[0,1,1]  R133      0.657727062702179
    z[0,1,1]  R134      6.4585006237030029e-01
    z[0,1,1]  R135      7.4338763952255249e-01
    z[0,1,1]  R136      7.0508313179016113e-01
    z[0,1,1]  R137      7.9247128963470459e-01
    z[0,1,1]  R138      8.2078307867050171e-01
    z[0,1,1]  R139      3.3597180247306824e-01
    z[0,1,1]  R140      3.2437753677368164e-01
    z[0,1,1]  R141      8.7639510631561279e-01
    z[0,1,1]  R142      0.31130251288414
    z[0,1,1]  R143      -4.1803106665611267e-01
    z[0,1,1]  R144      1.0529877245426178e-01
    z[0,1,1]  R145      1.0849340260028839e-01
    z[0,1,1]  R146      2.3467201739549637e-02
    z[0,1,1]  R147      -2.1112029254436493e-01
    z[0,1,1]  R148      1.6639775037765503e-01
    z[0,1,1]  R149      -6.7488527856767178e-03
    z[0,1,1]  R150      -6.3168264925479889e-02
    z[0,1,1]  R151      0.547184944152832
    z[0,1,1]  R152      1.0742236673831940e-01
    z[0,1,1]  R153      0.407914936542511
    z[0,1,1]  R154      4.4724959135055542e-01
    z[0,1,1]  R155      3.4217163920402527e-01
    z[0,1,1]  R156      1.4415302872657776e-01
    z[0,1,1]  R157      3.5020154714584351e-01
    z[0,1,1]  R158      3.6574858427047729e-01
    z[0,1,1]  R159      -4.1784530878067017e-01
    z[0,1,1]  R160      -3.3625042438507080e-01
    z[0,1,1]  R161      8.6969435214996338e-01
    z[0,1,1]  R162      8.6631134152412415e-02
    z[0,1,1]  R163      1.4700804650783539e-01
    z[0,1,1]  R164      -3.5427924990653992e-01
    z[0,1,1]  R165      -6.7064750194549561e-01
    z[0,1,1]  R166      -7.4182587862014771e-01
    z[0,1,1]  R167      -7.4127340316772461e-01
    z[0,1,1]  R168      -7.2319769859313965e-01
    z[0,1,1]  R169      -7.1683096885681152e-01
    z[0,1,1]  R170      -6.9388502836227417e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R51       -1
    z[0,1,2]  R52       1
    z[0,1,2]  R61       4.3849232792854309e-01
    z[0,1,2]  R62       3.3853515982627869e-01
    z[0,1,2]  R63       9.4243094325065613e-02
    z[0,1,2]  R64       0.582205593585968
    z[0,1,2]  R65       3.9551305770874023e-01
    z[0,1,2]  R66       5.2726618014276028e-03
    z[0,1,2]  R67       -3.3160638064146042e-02
    z[0,1,2]  R68       1.5954692661762238e-01
    z[0,1,2]  R69       7.1214497089385986e-01
    z[0,1,2]  R70       2.3050554096698761e-01
    z[0,1,2]  R71       -3.3334669470787048e-01
    z[0,1,2]  R72       5.5639997124671936e-02
    z[0,1,2]  R73       -2.0356020331382751e-01
    z[0,1,2]  R74       -2.3002997040748596e-01
    z[0,1,2]  R75       -2.8369075059890747e-01
    z[0,1,2]  R76       3.8147693872451782e-01
    z[0,1,2]  R77       2.3826966062188148e-02
    z[0,1,2]  R78       -2.9808353632688522e-02
    z[0,1,2]  R79       -2.7991554141044617e-01
    z[0,1,2]  R80       -1.5095798298716545e-02
    z[0,1,2]  R81       -3.7754490971565247e-01
    z[0,1,2]  R82       -1.0950003750622272e-02
    z[0,1,2]  R83       2.4025326129049063e-03
    z[0,1,2]  R84       1.3460588455200195e-01
    z[0,1,2]  R85       -2.1773955225944519e-01
    z[0,1,2]  R86       -2.7437901496887207e-01
    z[0,1,2]  R87       -9.9309816956520081e-02
    z[0,1,2]  R88       -4.0018233656883240e-01
    z[0,1,2]  R89       -1.9711470603942871e-01
    z[0,1,2]  R90       -1.2846191413700581e-02
    z[0,1,2]  R91       2.4511611461639404e-01
    z[0,1,2]  R92       6.2628291547298431e-02
    z[0,1,2]  R93       1.0547447949647903e-01
    z[0,1,2]  R94       3.3033019304275513e-01
    z[0,1,2]  R95       6.6327786445617676e-01
    z[0,1,2]  R96       8.1514120101928711e-02
    z[0,1,2]  R97       -1.3852171599864960e-01
    z[0,1,2]  R98       4.2326194047927856e-01
    z[0,1,2]  R99       -4.6761423349380493e-02
    z[0,1,2]  R100      3.7887477874755859e-01
    z[0,1,2]  R101      -9.9935494363307953e-02
    z[0,1,2]  R102      1.0055445134639740e-01
    z[0,1,2]  R103      2.0335851609706879e-01
    z[0,1,2]  R104      -1.0601404309272766e-01
    z[0,1,2]  R105      -1.2080924212932587e-01
    z[0,1,2]  R106      -3.1700644642114639e-02
    z[0,1,2]  R107      -3.3466815948486328e-01
    z[0,1,2]  R108      -0.687119722366333
    z[0,1,2]  R109      -6.4685958623886108e-01
    z[0,1,2]  R110      -6.0850036144256592e-01
    z[0,1,2]  R111      2.5499412789940834e-02
    z[0,1,2]  R112      5.7227391749620438e-02
    z[0,1,2]  R113      2.2832669317722321e-01
    z[0,1,2]  R114      -1.0725231468677521e-01
    z[0,1,2]  R115      1.5175219625234604e-02
    z[0,1,2]  R116      2.7799534797668457e-01
    z[0,1,2]  R117      -1.1042208969593048e-01
    z[0,1,2]  R118      -4.4454595446586609e-01
    z[0,1,2]  R119      5.8498613536357880e-02
    z[0,1,2]  R120      -3.2437656074762344e-02
    z[0,1,2]  R121      7.9628866910934448e-01
    z[0,1,2]  R122      6.2952286005020142e-01
    z[0,1,2]  R123      2.3803453147411346e-01
    z[0,1,2]  R124      3.5012251138687134e-01
    z[0,1,2]  R125      1.6661569476127625e-01
    z[0,1,2]  R126      3.0057954788208008e-01
    z[0,1,2]  R127      -7.2683282196521759e-02
    z[0,1,2]  R128      -2.0050784945487976e-01
    z[0,1,2]  R129      5.0285577774047852e-01
    z[0,1,2]  R130      0.00567758409306407
    z[0,1,2]  R131      -2.1179307997226715e-01
    z[0,1,2]  R132      -5.8393353223800659e-01
    z[0,1,2]  R133      -4.0201231837272644e-01
    z[0,1,2]  R134      -3.8458973169326782e-01
    z[0,1,2]  R135      4.2064037173986435e-02
    z[0,1,2]  R136      -2.8824952244758606e-01
    z[0,1,2]  R137      -2.4844953417778015e-01
    z[0,1,2]  R138      -1.5014594793319702e-01
    z[0,1,2]  R139      -3.6241721361875534e-02
    z[0,1,2]  R140      1.1564271897077560e-01
    z[0,1,2]  R141      1.7821869254112244e-01
    z[0,1,2]  R142      -2.7339941263198853e-01
    z[0,1,2]  R143      -6.2284684181213379e-01
    z[0,1,2]  R144      9.8502419888973236e-02
    z[0,1,2]  R145      -8.4907189011573792e-02
    z[0,1,2]  R146      -3.7734252214431763e-01
    z[0,1,2]  R147      1.1531513929367065e-01
    z[0,1,2]  R148      -3.3423385024070740e-01
    z[0,1,2]  R149      6.3833691179752350e-02
    z[0,1,2]  R150      -3.4744244813919067e-01
    z[0,1,2]  R151      -3.5237598419189453e-01
    z[0,1,2]  R152      1.0244900733232498e-01
    z[0,1,2]  R153      -7.7153556048870087e-02
    z[0,1,2]  R154      -1.8872264027595520e-01
    z[0,1,2]  R155      -5.5572193115949631e-02
    z[0,1,2]  R156      7.1593075990676880e-02
    z[0,1,2]  R157      1.0369773954153061e-02
    z[0,1,2]  R158      -8.3991587162017822e-02
    z[0,1,2]  R159      9.6030756831169128e-03
    z[0,1,2]  R160      -3.5265704989433289e-01
    z[0,1,2]  R161      -2.3279662430286407e-01
    z[0,1,2]  R162      2.2210830822587013e-02
    z[0,1,2]  R163      1.0618493705987930e-01
    z[0,1,2]  R164      -1.7527283728122711e-01
    z[0,1,2]  R165      3.4023147821426392e-01
    z[0,1,2]  R166      -3.2223331928253174e-01
    z[0,1,2]  R167      -1.6301706433296204e-01
    z[0,1,2]  R168      -1.1810306459665298e-01
    z[0,1,2]  R169      -2.4931703507900238e-01
    z[0,1,2]  R170      -0.291786253452301
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R53       -1
    z[0,1,3]  R54       1
    z[0,1,3]  R61       -2.7918061614036560e-01
    z[0,1,3]  R62       -1.5112577378749847e-01
    z[0,1,3]  R63       -3.8952809572219849e-01
    z[0,1,3]  R64       -2.6958325877785683e-02
    z[0,1,3]  R65       -0.576545238494873
    z[0,1,3]  R66       4.2964771389961243e-01
    z[0,1,3]  R67       3.6707094311714172e-01
    z[0,1,3]  R68       4.9446511268615723e-01
    z[0,1,3]  R69       -8.6714506149291992e-02
    z[0,1,3]  R70       8.4276819229125977e-01
    z[0,1,3]  R71       -1.5110825002193451e-01
    z[0,1,3]  R72       4.4408398866653442e-01
    z[0,1,3]  R73       4.9077352881431580e-01
    z[0,1,3]  R74       3.7115055322647095e-01
    z[0,1,3]  R75       1.4902465045452118e-01
    z[0,1,3]  R76       5.3401932120323181e-02
    z[0,1,3]  R77       -2.3090282082557678e-01
    z[0,1,3]  R78       2.8796160221099854e-01
    z[0,1,3]  R79       2.4158558249473572e-01
    z[0,1,3]  R80       -3.7723553180694580e-01
    z[0,1,3]  R81       1.8693108856678009e-01
    z[0,1,3]  R82       4.9490388482809067e-03
    z[0,1,3]  R83       -1.4407569542527199e-02
    z[0,1,3]  R84       -0.00487411767244339
    z[0,1,3]  R85       6.2143850326538086e-01
    z[0,1,3]  R86       1.7748048901557922e-01
    z[0,1,3]  R87       3.9502236247062683e-01
    z[0,1,3]  R88       5.5404853820800781e-01
    z[0,1,3]  R89       -1.6640393063426018e-02
    z[0,1,3]  R90       2.5008162856101990e-01
    z[0,1,3]  R91       0.254672646522522
    z[0,1,3]  R92       4.5510622859001160e-01
    z[0,1,3]  R93       5.9680455923080444e-01
    z[0,1,3]  R94       2.9364828020334244e-02
    z[0,1,3]  R95       2.8551253676414490e-01
    z[0,1,3]  R96       4.4502565264701843e-01
    z[0,1,3]  R97       6.2376689165830612e-02
    z[0,1,3]  R98       2.4847450852394104e-01
    z[0,1,3]  R99       7.0948116481304169e-02
    z[0,1,3]  R100      5.4908853769302368e-01
    z[0,1,3]  R101      1.2764946557581425e-02
    z[0,1,3]  R102      2.4747721850872040e-01
    z[0,1,3]  R103      6.0122460126876831e-02
    z[0,1,3]  R104      -7.7999327331781387e-03
    z[0,1,3]  R105      2.8803277015686035e-01
    z[0,1,3]  R106      2.4187400937080383e-01
    z[0,1,3]  R107      6.3066351413726807e-01
    z[0,1,3]  R108      -1.0523796826601028e-01
    z[0,1,3]  R109      2.9216054081916809e-01
    z[0,1,3]  R110      1.7974372208118439e-01
    z[0,1,3]  R111      -3.1478229910135269e-02
    z[0,1,3]  R112      3.1292641162872314e-01
    z[0,1,3]  R113      3.5052257776260376e-01
    z[0,1,3]  R114      7.7737748622894287e-02
    z[0,1,3]  R115      -1.4659301936626434e-01
    z[0,1,3]  R116      -1.6012732684612274e-01
    z[0,1,3]  R117      1.8675832450389862e-01
    z[0,1,3]  R118      3.9999779313802719e-02
    z[0,1,3]  R119      5.6568211317062378e-01
    z[0,1,3]  R120      6.6492003202438354e-01
    z[0,1,3]  R121      -1.0823883116245270e-01
    z[0,1,3]  R122      0.356587290763855
    z[0,1,3]  R123      6.0027605295181274e-01
    z[0,1,3]  R124      5.1075166463851929e-01
    z[0,1,3]  R125      5.3740882873535156e-01
    z[0,1,3]  R126      1.0916360467672348e-01
    z[0,1,3]  R127      4.9610521644353867e-02
    z[0,1,3]  R128      2.6247090101242065e-01
    z[0,1,3]  R129      3.9771571755409241e-01
    z[0,1,3]  R130      4.4433519244194031e-01
    z[0,1,3]  R131      2.9319867491722107e-01
    z[0,1,3]  R132      -1.5360046923160553e-01
    z[0,1,3]  R133      -2.7590749785304070e-02
    z[0,1,3]  R134      2.2711518406867981e-01
    z[0,1,3]  R135      -1.6082301735877991e-01
    z[0,1,3]  R136      -6.8718180060386658e-02
    z[0,1,3]  R137      3.1026366353034973e-01
    z[0,1,3]  R138      -5.8440599590539932e-02
    z[0,1,3]  R139      -4.1871690191328526e-03
    z[0,1,3]  R140      -4.1127860546112061e-02
    z[0,1,3]  R141      -3.3243077993392944e-01
    z[0,1,3]  R142      -6.8526461720466614e-02
    z[0,1,3]  R143      -8.7724313139915466e-02
    z[0,1,3]  R144      -3.5257175564765930e-01
    z[0,1,3]  R145      -2.9554140567779541e-01
    z[0,1,3]  R146      -2.9453948140144348e-01
    z[0,1,3]  R147      -3.3523476123809814e-01
    z[0,1,3]  R148      -3.7054210901260376e-01
    z[0,1,3]  R149      -4.7129637002944946e-01
    z[0,1,3]  R150      -3.0005259439349174e-02
    z[0,1,3]  R151      -3.7874984741210938e-01
    z[0,1,3]  R152      9.7439870238304138e-02
    z[0,1,3]  R153      -3.0197608470916748e-01
    z[0,1,3]  R154      -2.0218986272811890e-01
    z[0,1,3]  R155      -1.5474145114421844e-01
    z[0,1,3]  R156      -4.0473595261573792e-02
    z[0,1,3]  R157      9.7739197313785553e-02
    z[0,1,3]  R158      -2.5048962235450745e-01
    z[0,1,3]  R159      -3.2698279619216919e-01
    z[0,1,3]  R160      -2.5443577766418457e-01
    z[0,1,3]  R161      -1.5198162198066711e-01
    z[0,1,3]  R162      -3.0203291773796082e-01
    z[0,1,3]  R163      -3.0847027897834778e-01
    z[0,1,3]  R164      -3.9656361937522888e-01
    z[0,1,3]  R165      -9.1805262491106987e-03
    z[0,1,3]  R166      -1.6141927242279053e-01
    z[0,1,3]  R167      -2.9566857218742371e-01
    z[0,1,3]  R168      -1.8786433339118958e-01
    z[0,1,3]  R169      -3.1983304023742676e-01
    z[0,1,3]  R170      1.8618069589138031e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R55       -1
    z[0,1,4]  R56       1
    z[0,1,4]  R61       -5.1024895161390305e-02
    z[0,1,4]  R62       1.3013137876987457e-01
    z[0,1,4]  R63       2.8744551539421082e-01
    z[0,1,4]  R64       -1.6588295996189117e-01
    z[0,1,4]  R65       -1.7806215584278107e-01
    z[0,1,4]  R66       -2.8135115280747414e-02
    z[0,1,4]  R67       -2.8193125128746033e-01
    z[0,1,4]  R68       3.4507939219474792e-01
    z[0,1,4]  R69       -1.3545063138008118e-01
    z[0,1,4]  R70       1.1985806375741959e-01
    z[0,1,4]  R71       1.3993303477764130e-01
    z[0,1,4]  R72       4.9991786479949951e-01
    z[0,1,4]  R73       7.4206370115280151e-01
    z[0,1,4]  R74       7.5349074602127075e-01
    z[0,1,4]  R75       -1.2462893128395081e-01
    z[0,1,4]  R76       -0.0282792616635561
    z[0,1,4]  R77       -3.6938312649726868e-01
    z[0,1,4]  R78       -2.8143274784088135e-01
    z[0,1,4]  R79       -5.2599930763244629e-01
    z[0,1,4]  R80       -2.1209090948104858e-01
    z[0,1,4]  R81       -9.3808978796005249e-02
    z[0,1,4]  R82       -2.3968910798430443e-02
    z[0,1,4]  R83       1.0132896155118942e-01
    z[0,1,4]  R84       -1.6049362719058990e-01
    z[0,1,4]  R85       1.0189700871706009e-01
    z[0,1,4]  R86       3.9138558506965637e-01
    z[0,1,4]  R87       4.0224725008010864e-01
    z[0,1,4]  R88       2.0485168695449829e-01
    z[0,1,4]  R89       -2.6626411080360413e-01
    z[0,1,4]  R90       3.0490845441818237e-01
    z[0,1,4]  R91       1.0915137827396393e-01
    z[0,1,4]  R92       7.1642078459262848e-02
    z[0,1,4]  R93       2.0457884669303894e-01
    z[0,1,4]  R94       5.7132825255393982e-02
    z[0,1,4]  R95       1.3246698677539825e-01
    z[0,1,4]  R96       -3.7669813632965088e-01
    z[0,1,4]  R97       -1.6978222131729126e-01
    z[0,1,4]  R98       -6.1717376112937927e-02
    z[0,1,4]  R99       -4.7624397277832031e-01
    z[0,1,4]  R100      -1.4507827162742615e-01
    z[0,1,4]  R101      -1.7002993822097778e-01
    z[0,1,4]  R102      -4.2550783604383469e-02
    z[0,1,4]  R103      -9.4564616680145264e-02
    z[0,1,4]  R104      1.6484777629375458e-01
    z[0,1,4]  R105      1.1954781413078308e-01
    z[0,1,4]  R106      -2.3453450202941895e-01
    z[0,1,4]  R107      -1.9616085290908813e-01
    z[0,1,4]  R108      -1.7899875342845917e-01
    z[0,1,4]  R109      -6.4933754503726959e-02
    z[0,1,4]  R110      -2.2044228017330170e-01
    z[0,1,4]  R111      3.1556585431098938e-01
    z[0,1,4]  R112      1.0745245218276978e-01
    z[0,1,4]  R113      -7.7980393543839455e-03
    z[0,1,4]  R114      -2.1471410989761353e-02
    z[0,1,4]  R115      -1.3983753323554993e-01
    z[0,1,4]  R116      -2.3936058580875397e-01
    z[0,1,4]  R117      -1.2669727206230164e-01
    z[0,1,4]  R118      1.7202737927436829e-01
    z[0,1,4]  R119      -4.1657772660255432e-01
    z[0,1,4]  R120      -2.6984393596649170e-01
    z[0,1,4]  R121      1.4760370831936598e-03
    z[0,1,4]  R122      4.1524812579154968e-02
    z[0,1,4]  R123      -2.6050312444567680e-02
    z[0,1,4]  R124      5.8437857776880264e-02
    z[0,1,4]  R125      -1.7981484532356262e-01
    z[0,1,4]  R126      -7.4437371222302318e-04
    z[0,1,4]  R127      2.3300166428089142e-01
    z[0,1,4]  R128      2.0796832442283630e-01
    z[0,1,4]  R129      1.1065878719091415e-01
    z[0,1,4]  R130      2.0427180826663971e-01
    z[0,1,4]  R131      1.6974899172782898e-01
    z[0,1,4]  R132      -4.4538193941116333e-01
    z[0,1,4]  R133      -3.1974750757217407e-01
    z[0,1,4]  R134      -1.9922609627246857e-01
    z[0,1,4]  R135      -2.7087783813476562e-01
    z[0,1,4]  R136      2.0275993272662163e-02
    z[0,1,4]  R137      1.0352526605129242e-01
    z[0,1,4]  R138      -1.5411649644374847e-01
    z[0,1,4]  R139      -9.2224171385169029e-03
    z[0,1,4]  R140      1.1496607959270477e-01
    z[0,1,4]  R141      1.1724268645048141e-01
    z[0,1,4]  R142      8.7437534332275391e-01
    z[0,1,4]  R143      -1.4307887852191925e-01
    z[0,1,4]  R144      8.4778529405593872e-01
    z[0,1,4]  R145      5.1797825098037720e-01
    z[0,1,4]  R146      7.7364194393157959e-01
    z[0,1,4]  R147      8.4896445274353027e-01
    z[0,1,4]  R148      0.667140781879425
    z[0,1,4]  R149      6.5066725015640259e-01
    z[0,1,4]  R150      -2.4185539782047272e-01
    z[0,1,4]  R151      -8.3446763455867767e-02
    z[0,1,4]  R152      8.9992147684097290e-01
    z[0,1,4]  R153      -2.5832799077033997e-01
    z[0,1,4]  R154      1.7638940364122391e-02
    z[0,1,4]  R155      -4.6297335624694824e-01
    z[0,1,4]  R156      -7.9953235387802124e-01
    z[0,1,4]  R157      -7.4610334634780884e-01
    z[0,1,4]  R158      7.0542466640472412e-01
    z[0,1,4]  R159      6.1648392677307129e-01
    z[0,1,4]  R160      1.2818135321140289e-01
    z[0,1,4]  R161      2.1970003843307495e-01
    z[0,1,4]  R162      -2.5865370035171509e-01
    z[0,1,4]  R163      6.4369821548461914e-01
    z[0,1,4]  R164      5.0892108678817749e-01
    z[0,1,4]  R165      -1.2675713002681732e-01
    z[0,1,4]  R166      9.5251753926277161e-02
    z[0,1,4]  R167      -7.3320806026458740e-02
    z[0,1,4]  R168      -5.4239153861999512e-02
    z[0,1,4]  R169      -1.0252785682678223e-01
    z[0,1,4]  R170      2.8734045103192329e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R57       -1
    z[0,1,5]  R58       1
    z[0,1,5]  R61       -2.5622516870498657e-01
    z[0,1,5]  R62       -6.9626617431640625e-01
    z[0,1,5]  R63       -7.0565515756607056e-01
    z[0,1,5]  R64       6.4109876751899719e-02
    z[0,1,5]  R65       -4.1626104712486267e-01
    z[0,1,5]  R66       1.5259596705436707e-01
    z[0,1,5]  R67       -3.7575110793113708e-01
    z[0,1,5]  R68       7.5319744646549225e-02
    z[0,1,5]  R69       1.0449462383985519e-01
    z[0,1,5]  R70       5.2294008433818817e-02
    z[0,1,5]  R71       5.3625613451004028e-01
    z[0,1,5]  R72       4.7479662299156189e-01
    z[0,1,5]  R73       1.4701986312866211e-01
    z[0,1,5]  R74       -2.7418610453605652e-01
    z[0,1,5]  R75       2.6580700278282166e-01
    z[0,1,5]  R76       1.4808274805545807e-01
    z[0,1,5]  R77       0.138405442237854
    z[0,1,5]  R78       2.3203523829579353e-02
    z[0,1,5]  R79       -9.9081307649612427e-02
    z[0,1,5]  R80       -0.170019268989563
    z[0,1,5]  R81       -1.4094074070453644e-01
    z[0,1,5]  R82       1.4805573225021362e-01
    z[0,1,5]  R83       -0.00614133570343256
    z[0,1,5]  R84       -4.6561844646930695e-02
    z[0,1,5]  R85       -2.0218789577484131e-01
    z[0,1,5]  R86       -0.070730060338974
    z[0,1,5]  R87       -0.125872403383255
    z[0,1,5]  R88       1.6337139904499054e-01
    z[0,1,5]  R89       -1.4813865534961224e-02
    z[0,1,5]  R90       5.1943007856607437e-02
    z[0,1,5]  R91       -3.0868789553642273e-01
    z[0,1,5]  R92       -2.3672723770141602e-01
    z[0,1,5]  R93       -1.9990043714642525e-02
    z[0,1,5]  R94       8.1158012151718140e-02
    z[0,1,5]  R95       7.2173632681369781e-02
    z[0,1,5]  R96       2.4948580563068390e-01
    z[0,1,5]  R97       1.4346297085285187e-01
    z[0,1,5]  R98       1.6191197931766510e-01
    z[0,1,5]  R99       1.1874933540821075e-01
    z[0,1,5]  R100      2.5968101620674133e-01
    z[0,1,5]  R101      6.2717609107494354e-03
    z[0,1,5]  R102      -9.1657042503356934e-02
    z[0,1,5]  R103      2.0332394167780876e-02
    z[0,1,5]  R104      -1.4069218933582306e-01
    z[0,1,5]  R105      3.7906490266323090e-02
    z[0,1,5]  R106      4.4746950268745422e-01
    z[0,1,5]  R107      2.4970276653766632e-01
    z[0,1,5]  R108      2.6387146115303040e-01
    z[0,1,5]  R109      1.9971735775470734e-01
    z[0,1,5]  R110      2.0439951121807098e-01
    z[0,1,5]  R111      -3.6918017268180847e-01
    z[0,1,5]  R112      -1.3579083979129791e-01
    z[0,1,5]  R113      3.4114348888397217e-01
    z[0,1,5]  R114      3.0706393718719482e-01
    z[0,1,5]  R115      -1.4180496335029602e-01
    z[0,1,5]  R116      -0.0861627534031868
    z[0,1,5]  R117      2.9993566870689392e-01
    z[0,1,5]  R118      -2.6750189065933228e-01
    z[0,1,5]  R119      6.1956298351287842e-01
    z[0,1,5]  R120      5.0050729513168335e-01
    z[0,1,5]  R121      -4.6309524774551392e-01
    z[0,1,5]  R122      -4.9777108430862427e-01
    z[0,1,5]  R123      -4.2009532451629639e-01
    z[0,1,5]  R124      -7.0185315608978271e-01
    z[0,1,5]  R125      -6.2715178728103638e-01
    z[0,1,5]  R126      -0.702717125415802
    z[0,1,5]  R127      -7.4101728200912476e-01
    z[0,1,5]  R128      -8.6752545833587646e-01
    z[0,1,5]  R129      -3.7044957280158997e-01
    z[0,1,5]  R130      -1.9174227118492126e-01
    z[0,1,5]  R131      -4.8559173941612244e-01
    z[0,1,5]  R132      -1.7354622483253479e-02
    z[0,1,5]  R133      -7.6631464064121246e-02
    z[0,1,5]  R134      5.7139031589031219e-02
    z[0,1,5]  R135      1.1248541623353958e-01
    z[0,1,5]  R136      1.1797171086072922e-01
    z[0,1,5]  R137      2.0577445626258850e-01
    z[0,1,5]  R138      4.0649777650833130e-01
    z[0,1,5]  R139      -1.2953018769621849e-02
    z[0,1,5]  R140      7.9326741397380829e-02
    z[0,1,5]  R141      -1.7031390964984894e-01
    z[0,1,5]  R142      0.214023619890213
    z[0,1,5]  R143      3.6025542020797729e-01
    z[0,1,5]  R144      1.0420871526002884e-01
    z[0,1,5]  R145      7.6388245820999146e-01
    z[0,1,5]  R146      -2.0823728293180466e-02
    z[0,1,5]  R147      3.0105376243591309e-01
    z[0,1,5]  R148      -2.1040309220552444e-02
    z[0,1,5]  R149      4.6810010075569153e-01
    z[0,1,5]  R150      5.6569927930831909e-01
    z[0,1,5]  R151      -5.4583930969238281e-01
    z[0,1,5]  R152      -2.8972637653350830e-01
    z[0,1,5]  R153      -7.1383011341094971e-01
    z[0,1,5]  R154      1.3720458745956421e-01
    z[0,1,5]  R155      1.3389253616333008e-01
    z[0,1,5]  R156      -0.0657874047756195
    z[0,1,5]  R157      5.4046556353569031e-02
    z[0,1,5]  R158      -1.2181343883275986e-01
    z[0,1,5]  R159      5.0305038690567017e-01
    z[0,1,5]  R160      5.5670654773712158e-01
    z[0,1,5]  R161      -3.3804804086685181e-01
    z[0,1,5]  R162      1.0120960325002670e-01
    z[0,1,5]  R163      5.6893342733383179e-01
    z[0,1,5]  R164      5.1979804039001465e-01
    z[0,1,5]  R165      7.6164029538631439e-02
    z[0,1,5]  R166      2.9966291785240173e-01
    z[0,1,5]  R167      2.8683552145957947e-01
    z[0,1,5]  R168      4.4693747162818909e-01
    z[0,1,5]  R169      3.0494108796119690e-01
    z[0,1,5]  R170      3.9764198660850525e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R59       -1
    z[0,1,6]  R60       1
    z[0,1,6]  R61       5.8988708257675171e-01
    z[0,1,6]  R62       5.1419258117675781e-01
    z[0,1,6]  R63       4.3201144784688950e-02
    z[0,1,6]  R64       -4.4612166285514832e-01
    z[0,1,6]  R65       -0.28459432721138
    z[0,1,6]  R66       1.2120986357331276e-02
    z[0,1,6]  R67       -3.1471100449562073e-01
    z[0,1,6]  R68       -2.4058060348033905e-01
    z[0,1,6]  R69       -0.128374844789505
    z[0,1,6]  R70       0.0751722976565361
    z[0,1,6]  R71       5.0954829901456833e-02
    z[0,1,6]  R72       2.2015309333801270e-01
    z[0,1,6]  R73       9.5172263681888580e-02
    z[0,1,6]  R74       -1.4934517443180084e-01
    z[0,1,6]  R75       3.6412796378135681e-01
    z[0,1,6]  R76       2.8385373950004578e-01
    z[0,1,6]  R77       -7.6482407748699188e-02
    z[0,1,6]  R78       -4.5404630899429321e-01
    z[0,1,6]  R79       7.5264692306518555e-02
    z[0,1,6]  R80       1.3915333151817322e-01
    z[0,1,6]  R81       -0.0847182348370552
    z[0,1,6]  R82       -1.1609897762537003e-01
    z[0,1,6]  R83       -2.6535862684249878e-01
    z[0,1,6]  R84       1.6977122426033020e-01
    z[0,1,6]  R85       -9.4169579446315765e-02
    z[0,1,6]  R86       -1.9882759451866150e-01
    z[0,1,6]  R87       1.2652884423732758e-01
    z[0,1,6]  R88       1.5812614560127258e-01
    z[0,1,6]  R89       1.3132725842297077e-02
    z[0,1,6]  R90       1.4832308888435364e-01
    z[0,1,6]  R91       -5.8644801378250122e-01
    z[0,1,6]  R92       -9.6080824732780457e-02
    z[0,1,6]  R93       -0.0935017317533493
    z[0,1,6]  R94       4.2079180479049683e-02
    z[0,1,6]  R95       -2.3811565339565277e-01
    z[0,1,6]  R96       1.5567111968994141e-01
    z[0,1,6]  R97       4.1509577631950378e-01
    z[0,1,6]  R98       -0.135938823223114
    z[0,1,6]  R99       2.3738507926464081e-01
    z[0,1,6]  R100      1.1658837087452412e-02
    z[0,1,6]  R101      2.8270691633224487e-01
    z[0,1,6]  R102      -4.6458322554826736e-02
    z[0,1,6]  R103      3.6631596088409424e-01
    z[0,1,6]  R104      -2.9645375907421112e-02
    z[0,1,6]  R105      4.3972063064575195e-01
    z[0,1,6]  R106      -3.2069772481918335e-01
    z[0,1,6]  R107      -4.4085553288459778e-01
    z[0,1,6]  R108      7.9573400318622589e-02
    z[0,1,6]  R109      1.6697552800178528e-01
    z[0,1,6]  R110      -0.261714369058609
    z[0,1,6]  R111      -6.3062274456024170e-01
    z[0,1,6]  R112      3.0303898453712463e-01
    z[0,1,6]  R113      8.4230154752731323e-02
    z[0,1,6]  R114      1.1596415936946869e-01
    z[0,1,6]  R115      1.8427266180515289e-01
    z[0,1,6]  R116      -1.7956189811229706e-01
    z[0,1,6]  R117      -2.8307339549064636e-01
    z[0,1,6]  R118      -8.2004763185977936e-02
    z[0,1,6]  R119      1.5848989784717560e-01
    z[0,1,6]  R120      2.1177372336387634e-01
    z[0,1,6]  R121      -1.4961341023445129e-01
    z[0,1,6]  R122      2.1387757360935211e-01
    z[0,1,6]  R123      0.087035171687603
    z[0,1,6]  R124      -8.3404621109366417e-03
    z[0,1,6]  R125      -1.8069240450859070e-01
    z[0,1,6]  R126      0.287383496761322
    z[0,1,6]  R127      -4.4324392080307007e-01
    z[0,1,6]  R128      7.8737497329711914e-02
    z[0,1,6]  R129      5.5472618341445923e-01
    z[0,1,6]  R130      7.5775671005249023e-01
    z[0,1,6]  R131      3.4774962067604065e-01
    z[0,1,6]  R132      9.1815330088138580e-02
    z[0,1,6]  R133      -3.9528802037239075e-01
    z[0,1,6]  R134      0.0697116032242775
    z[0,1,6]  R135      2.9087954759597778e-01
    z[0,1,6]  R136      3.2448939979076385e-02
    z[0,1,6]  R137      -5.4661218076944351e-02
    z[0,1,6]  R138      -2.4099057912826538e-01
    z[0,1,6]  R139      -1.1285389959812164e-01
    z[0,1,6]  R140      7.5361780822277069e-02
    z[0,1,6]  R141      -2.4202053900808096e-03
    z[0,1,6]  R142      1.1376570910215378e-01
    z[0,1,6]  R143      5.3188685327768326e-02
    z[0,1,6]  R144      -1.8500572443008423e-01
    z[0,1,6]  R145      -7.9107824712991714e-03
    z[0,1,6]  R146      -3.7395489215850830e-01
    z[0,1,6]  R147      0.123031385242939
    z[0,1,6]  R148      -5.0080728530883789e-01
    z[0,1,6]  R149      -2.1072435379028320e-01
    z[0,1,6]  R150      -2.5283247232437134e-01
    z[0,1,6]  R151      3.4493315219879150e-01
    z[0,1,6]  R152      2.6844039559364319e-01
    z[0,1,6]  R153      -3.3700618147850037e-01
    z[0,1,6]  R154      -3.2257422804832458e-01
    z[0,1,6]  R155      -3.5320317745208740e-01
    z[0,1,6]  R156      -2.6487755775451660e-01
    z[0,1,6]  R157      -1.5535186231136322e-01
    z[0,1,6]  R158      -4.2757540941238403e-01
    z[0,1,6]  R159      2.8858572244644165e-01
    z[0,1,6]  R160      -1.7450398206710815e-01
    z[0,1,6]  R161      -2.6332248002290726e-02
    z[0,1,6]  R162      -0.159862220287323
    z[0,1,6]  R163      -3.2387372851371765e-01
    z[0,1,6]  R164      -1.4186498522758484e-01
    z[0,1,6]  R165      -2.2816176712512970e-01
    z[0,1,6]  R166      -0.0744878277182579
    z[0,1,6]  R167      -2.5121471285820007e-01
    z[0,1,6]  R168      -2.8377154842019081e-02
    z[0,1,6]  R169      -4.8527400940656662e-02
    z[0,1,6]  R170      1.4812238514423370e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R171      -1
    z[1,0,0]  R172      1
    z[1,0,0]  R185      3.3207225799560547e-01
    z[1,0,0]  R186      2.2497600317001343e-01
    z[1,0,0]  R187      4.0429782867431641e-01
    z[1,0,0]  R188      1.1020505428314209e-01
    z[1,0,0]  R189      3.3701881766319275e-01
    z[1,0,0]  R190      0.297879159450531
    z[1,0,0]  R191      3.9452165365219116e-01
    z[1,0,0]  R192      2.0356547832489014e-01
    z[1,0,0]  R193      -2.6331812143325806e-01
    z[1,0,0]  R194      3.1959950923919678e-01
    z[1,0,0]  R195      5.9074461460113525e-01
    z[1,0,0]  R196      -4.1275955736637115e-02
    z[1,0,0]  R197      -3.7504187226295471e-01
    z[1,0,0]  R198      -5.7928526401519775e-01
    z[1,0,0]  R199      -4.9910187721252441e-01
    z[1,0,0]  R200      -6.3219177722930908e-01
    z[1,0,0]  R201      -3.9742922782897949e-01
    z[1,0,0]  R202      2.3084011673927307e-01
    z[1,0,0]  R203      -9.3423920869827271e-01
    z[1,0,0]  R204      -9.2440533638000488e-01
    z[1,0,0]  R205      2.1656617522239685e-01
    z[1,0,0]  R206      1.9144825637340546e-02
    z[1,0,0]  R207      -5.2586293220520020e-01
    z[1,0,0]  R208      3.0178827047348022e-01
    z[1,0,0]  R209      2.0443785190582275e-01
    z[1,0,0]  R210      -1.7751251161098480e-01
    z[1,0,0]  R211      5.6899610906839371e-02
    z[1,0,0]  R212      1.6422684490680695e-01
    z[1,0,0]  R213      2.9473572969436646e-01
    z[1,0,0]  R214      -6.5723603963851929e-01
    z[1,0,0]  R215      9.5317848026752472e-02
    z[1,0,0]  R216      -5.1086451858282089e-02
    z[1,0,0]  R217      -2.1587809920310974e-01
    z[1,0,0]  R218      7.7477765083312988e-01
    z[1,0,0]  R219      7.0630115270614624e-01
    z[1,0,0]  R220      5.0864154100418091e-01
    z[1,0,0]  R221      5.3289115428924561e-01
    z[1,0,0]  R222      3.1803345680236816e-01
    z[1,0,0]  R223      -4.4739622622728348e-02
    z[1,0,0]  R224      -5.8397495746612549e-01
    z[1,0,0]  R225      -5.5687215179204941e-02
    z[1,0,0]  R226      8.9335137605667114e-01
    z[1,0,0]  R227      -1.7038933932781219e-01
    z[1,0,0]  R228      -3.7038710713386536e-01
    z[1,0,0]  R229      -6.0038655996322632e-01
    z[1,0,0]  R230      4.6409547328948975e-01
    z[1,0,0]  R231      4.3099871277809143e-01
    z[1,0,0]  R232      4.7354349493980408e-01
    z[1,0,0]  R233      4.6459159255027771e-01
    z[1,0,0]  R234      4.6672913432121277e-01
    z[1,0,0]  R235      1.3831178843975067e-01
    z[1,0,0]  R236      -2.4963927268981934e-01
    z[1,0,0]  R237      1.5677075088024139e-01
    z[1,0,0]  R238      2.0215308666229248e-01
    z[1,0,0]  R239      3.3621060848236084e-01
    z[1,0,0]  R240      -3.6002430319786072e-01
    z[1,0,0]  R241      2.8251945972442627e-01
    z[1,0,0]  R242      5.3606323897838593e-02
    z[1,0,0]  R243      -2.0865032076835632e-01
    z[1,0,0]  R244      0.0792015790939331
    z[1,0,0]  R245      6.9700604677200317e-01
    z[1,0,0]  R246      4.9385523796081543e-01
    z[1,0,0]  R247      2.7884298563003540e-01
    z[1,0,0]  R248      -6.2758654356002808e-02
    z[1,0,0]  R249      4.4140231609344482e-01
    z[1,0,0]  R250      2.9204022884368896e-01
    z[1,0,0]  R251      0.0990278422832489
    z[1,0,0]  R252      5.6584876775741577e-01
    z[1,0,0]  R253      0.438368558883667
    z[1,0,0]  R254      1.2508645653724670e-01
    z[1,0,0]  R255      4.1417360305786133e-01
    z[1,0,0]  R256      4.1959103941917419e-01
    z[1,0,0]  R257      5.5644816160202026e-01
    z[1,0,0]  R258      6.3575762510299683e-01
    z[1,0,0]  R259      4.1316190361976624e-01
    z[1,0,0]  R260      3.8598445057868958e-01
    z[1,0,0]  R261      2.8113448619842529e-01
    z[1,0,0]  R262      2.4223934113979340e-01
    z[1,0,0]  R263      -3.3876141905784607e-01
    z[1,0,0]  R264      1.6936412453651428e-01
    z[1,0,0]  R265      -2.2780045866966248e-01
    z[1,0,0]  R266      5.2210664749145508e-01
    z[1,0,0]  R267      4.7280839085578918e-01
    z[1,0,0]  R268      3.7545260787010193e-01
    z[1,0,0]  R269      -4.0232321619987488e-01
    z[1,0,0]  R270      4.7286859154701233e-01
    z[1,0,0]  R271      -1.9411759078502655e-01
    z[1,0,0]  R272      9.3059904873371124e-02
    z[1,0,0]  R273      4.1530004143714905e-01
    z[1,0,0]  R274      2.9094433784484863e-01
    z[1,0,0]  R275      4.4050028920173645e-01
    z[1,0,0]  R276      -3.1407541036605835e-01
    z[1,0,0]  R277      -2.5384524837136269e-02
    z[1,0,0]  R278      1.2459943443536758e-01
    z[1,0,0]  R279      -2.3517280817031860e-01
    z[1,0,0]  R280      -5.2083592861890793e-02
    z[1,0,0]  R281      1.4811287820339203e-01
    z[1,0,0]  R282      -6.3537520170211792e-01
    z[1,0,0]  R283      -6.4471709728240967e-01
    z[1,0,0]  R284      -6.5766119956970215e-01
    z[1,0,0]  R285      1.2397421896457672e-01
    z[1,0,0]  R286      6.3077318668365479e-01
    z[1,0,0]  R287      5.0213652849197388e-01
    z[1,0,0]  R288      2.0148406922817230e-01
    z[1,0,0]  R289      -4.1290480643510818e-02
    z[1,0,0]  R290      9.4691142439842224e-02
    z[1,0,0]  R291      -2.8340309858322144e-02
    z[1,0,0]  R292      -2.4740856885910034e-01
    z[1,0,0]  R293      -3.0452784895896912e-01
    z[1,0,0]  R294      -3.8870215415954590e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R173      -1
    z[1,0,1]  R174      1
    z[1,0,1]  R185      -8.4220498800277710e-02
    z[1,0,1]  R186      0.361508309841156
    z[1,0,1]  R187      4.8457989096641541e-01
    z[1,0,1]  R188      -3.2911914587020874e-01
    z[1,0,1]  R189      3.3398628234863281e-01
    z[1,0,1]  R190      -4.8228830099105835e-01
    z[1,0,1]  R191      -1.9169540703296661e-01
    z[1,0,1]  R192      2.1775195002555847e-01
    z[1,0,1]  R193      -2.4984495341777802e-01
    z[1,0,1]  R194      2.1840962767601013e-01
    z[1,0,1]  R195      3.6695379018783569e-01
    z[1,0,1]  R196      6.5316796302795410e-01
    z[1,0,1]  R197      0.657727062702179
    z[1,0,1]  R198      6.4585006237030029e-01
    z[1,0,1]  R199      7.4338763952255249e-01
    z[1,0,1]  R200      7.0508313179016113e-01
    z[1,0,1]  R201      7.9247128963470459e-01
    z[1,0,1]  R202      8.2078307867050171e-01
    z[1,0,1]  R203      3.3597180247306824e-01
    z[1,0,1]  R204      3.2437753677368164e-01
    z[1,0,1]  R205      8.7639510631561279e-01
    z[1,0,1]  R206      0.31130251288414
    z[1,0,1]  R207      -4.1803106665611267e-01
    z[1,0,1]  R208      1.0529877245426178e-01
    z[1,0,1]  R209      1.0849340260028839e-01
    z[1,0,1]  R210      2.3467201739549637e-02
    z[1,0,1]  R211      -2.1112029254436493e-01
    z[1,0,1]  R212      1.6639775037765503e-01
    z[1,0,1]  R213      -6.7488527856767178e-03
    z[1,0,1]  R214      -6.3168264925479889e-02
    z[1,0,1]  R215      0.547184944152832
    z[1,0,1]  R216      1.0742236673831940e-01
    z[1,0,1]  R217      0.407914936542511
    z[1,0,1]  R218      4.4724959135055542e-01
    z[1,0,1]  R219      3.4217163920402527e-01
    z[1,0,1]  R220      1.4415302872657776e-01
    z[1,0,1]  R221      3.5020154714584351e-01
    z[1,0,1]  R222      3.6574858427047729e-01
    z[1,0,1]  R223      -4.1784530878067017e-01
    z[1,0,1]  R224      -3.3625042438507080e-01
    z[1,0,1]  R225      8.6969435214996338e-01
    z[1,0,1]  R226      8.6631134152412415e-02
    z[1,0,1]  R227      1.4700804650783539e-01
    z[1,0,1]  R228      -3.5427924990653992e-01
    z[1,0,1]  R229      -6.7064750194549561e-01
    z[1,0,1]  R230      -7.4182587862014771e-01
    z[1,0,1]  R231      -7.4127340316772461e-01
    z[1,0,1]  R232      -7.2319769859313965e-01
    z[1,0,1]  R233      -7.1683096885681152e-01
    z[1,0,1]  R234      -6.9388502836227417e-01
    z[1,0,1]  R235      5.4261481761932373e-01
    z[1,0,1]  R236      1.8471740186214447e-01
    z[1,0,1]  R237      4.8204636573791504e-01
    z[1,0,1]  R238      6.2353205680847168e-01
    z[1,0,1]  R239      3.3489429950714111e-01
    z[1,0,1]  R240      -8.1334710121154785e-01
    z[1,0,1]  R241      -6.8163412809371948e-01
    z[1,0,1]  R242      -7.3793184757232666e-01
    z[1,0,1]  R243      -6.2932431697845459e-01
    z[1,0,1]  R244      -4.5561450719833374e-01
    z[1,0,1]  R245      2.6548174023628235e-01
    z[1,0,1]  R246      1.7883922159671783e-01
    z[1,0,1]  R247      2.4211584031581879e-01
    z[1,0,1]  R248      -3.7438550591468811e-01
    z[1,0,1]  R249      -6.9548559188842773e-01
    z[1,0,1]  R250      -8.1426960229873657e-01
    z[1,0,1]  R251      -8.8026142120361328e-01
    z[1,0,1]  R252      -5.5686980485916138e-01
    z[1,0,1]  R253      -6.1559689044952393e-01
    z[1,0,1]  R254      -8.6519724130630493e-01
    z[1,0,1]  R255      -7.8430545330047607e-01
    z[1,0,1]  R256      -8.8759505748748779e-01
    z[1,0,1]  R257      -7.8066098690032959e-01
    z[1,0,1]  R258      -7.2174870967864990e-01
    z[1,0,1]  R259      -0.579284131526947
    z[1,0,1]  R260      -0.739266574382782
    z[1,0,1]  R261      -7.4926763772964478e-01
    z[1,0,1]  R262      -0.616884171962738
    z[1,0,1]  R263      -8.8023918867111206e-01
    z[1,0,1]  R264      -8.8934975862503052e-01
    z[1,0,1]  R265      -6.0995358228683472e-01
    z[1,0,1]  R266      -6.6779989004135132e-01
    z[1,0,1]  R267      -5.9846210479736328e-01
    z[1,0,1]  R268      -8.5873937606811523e-01
    z[1,0,1]  R269      -4.8705798387527466e-01
    z[1,0,1]  R270      -5.8593922853469849e-01
    z[1,0,1]  R271      -8.4706974029541016e-01
    z[1,0,1]  R272      -8.3782196044921875e-01
    z[1,0,1]  R273      -7.2321790456771851e-01
    z[1,0,1]  R274      -6.1781018972396851e-01
    z[1,0,1]  R275      -8.2881647348403931e-01
    z[1,0,1]  R276      -9.0422928333282471e-01
    z[1,0,1]  R277      -9.0046817064285278e-01
    z[1,0,1]  R278      -9.6193933486938477e-01
    z[1,0,1]  R279      -0.798782229423523
    z[1,0,1]  R280      -7.6137822866439819e-01
    z[1,0,1]  R281      -4.1610002517700195e-01
    z[1,0,1]  R282      7.1338564157485962e-02
    z[1,0,1]  R283      9.2577107250690460e-02
    z[1,0,1]  R284      7.7672697603702545e-02
    z[1,0,1]  R285      -5.9112477302551270e-01
    z[1,0,1]  R286      -0.6157186627388
    z[1,0,1]  R287      -6.7031729221343994e-01
    z[1,0,1]  R288      -9.1305035352706909e-01
    z[1,0,1]  R289      -9.5023977756500244e-01
    z[1,0,1]  R290      -8.8946694135665894e-01
    z[1,0,1]  R291      -8.7520343065261841e-01
    z[1,0,1]  R292      -7.9479080438613892e-01
    z[1,0,1]  R293      0.0364716611802578
    z[1,0,1]  R294      1.9382598996162415e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R175      -1
    z[1,0,2]  R176      1
    z[1,0,2]  R185      7.9628866910934448e-01
    z[1,0,2]  R186      6.2952286005020142e-01
    z[1,0,2]  R187      2.3803453147411346e-01
    z[1,0,2]  R188      3.5012251138687134e-01
    z[1,0,2]  R189      1.6661569476127625e-01
    z[1,0,2]  R190      3.0057954788208008e-01
    z[1,0,2]  R191      -7.2683282196521759e-02
    z[1,0,2]  R192      -2.0050784945487976e-01
    z[1,0,2]  R193      5.0285577774047852e-01
    z[1,0,2]  R194      0.00567758409306407
    z[1,0,2]  R195      -2.1179307997226715e-01
    z[1,0,2]  R196      -5.8393353223800659e-01
    z[1,0,2]  R197      -4.0201231837272644e-01
    z[1,0,2]  R198      -3.8458973169326782e-01
    z[1,0,2]  R199      4.2064037173986435e-02
    z[1,0,2]  R200      -2.8824952244758606e-01
    z[1,0,2]  R201      -2.4844953417778015e-01
    z[1,0,2]  R202      -1.5014594793319702e-01
    z[1,0,2]  R203      -3.6241721361875534e-02
    z[1,0,2]  R204      1.1564271897077560e-01
    z[1,0,2]  R205      1.7821869254112244e-01
    z[1,0,2]  R206      -2.7339941263198853e-01
    z[1,0,2]  R207      -6.2284684181213379e-01
    z[1,0,2]  R208      9.8502419888973236e-02
    z[1,0,2]  R209      -8.4907189011573792e-02
    z[1,0,2]  R210      -3.7734252214431763e-01
    z[1,0,2]  R211      1.1531513929367065e-01
    z[1,0,2]  R212      -3.3423385024070740e-01
    z[1,0,2]  R213      6.3833691179752350e-02
    z[1,0,2]  R214      -3.4744244813919067e-01
    z[1,0,2]  R215      -3.5237598419189453e-01
    z[1,0,2]  R216      1.0244900733232498e-01
    z[1,0,2]  R217      -7.7153556048870087e-02
    z[1,0,2]  R218      -1.8872264027595520e-01
    z[1,0,2]  R219      -5.5572193115949631e-02
    z[1,0,2]  R220      7.1593075990676880e-02
    z[1,0,2]  R221      1.0369773954153061e-02
    z[1,0,2]  R222      -8.3991587162017822e-02
    z[1,0,2]  R223      9.6030756831169128e-03
    z[1,0,2]  R224      -3.5265704989433289e-01
    z[1,0,2]  R225      -2.3279662430286407e-01
    z[1,0,2]  R226      2.2210830822587013e-02
    z[1,0,2]  R227      1.0618493705987930e-01
    z[1,0,2]  R228      -1.7527283728122711e-01
    z[1,0,2]  R229      3.4023147821426392e-01
    z[1,0,2]  R230      -3.2223331928253174e-01
    z[1,0,2]  R231      -1.6301706433296204e-01
    z[1,0,2]  R232      -1.1810306459665298e-01
    z[1,0,2]  R233      -2.4931703507900238e-01
    z[1,0,2]  R234      -0.291786253452301
    z[1,0,2]  R235      4.3849232792854309e-01
    z[1,0,2]  R236      3.3853515982627869e-01
    z[1,0,2]  R237      9.4243094325065613e-02
    z[1,0,2]  R238      0.582205593585968
    z[1,0,2]  R239      3.9551305770874023e-01
    z[1,0,2]  R240      5.2726618014276028e-03
    z[1,0,2]  R241      -3.3160638064146042e-02
    z[1,0,2]  R242      1.5954692661762238e-01
    z[1,0,2]  R243      7.1214497089385986e-01
    z[1,0,2]  R244      2.3050554096698761e-01
    z[1,0,2]  R245      -3.3334669470787048e-01
    z[1,0,2]  R246      5.5639997124671936e-02
    z[1,0,2]  R247      -2.0356020331382751e-01
    z[1,0,2]  R248      -2.3002997040748596e-01
    z[1,0,2]  R249      -2.8369075059890747e-01
    z[1,0,2]  R250      3.8147693872451782e-01
    z[1,0,2]  R251      2.3826966062188148e-02
    z[1,0,2]  R252      -2.9808353632688522e-02
    z[1,0,2]  R253      -2.7991554141044617e-01
    z[1,0,2]  R254      -1.5095798298716545e-02
    z[1,0,2]  R255      -3.7754490971565247e-01
    z[1,0,2]  R256      -1.0950003750622272e-02
    z[1,0,2]  R257      2.4025326129049063e-03
    z[1,0,2]  R258      1.3460588455200195e-01
    z[1,0,2]  R259      -2.1773955225944519e-01
    z[1,0,2]  R260      -2.7437901496887207e-01
    z[1,0,2]  R261      -9.9309816956520081e-02
    z[1,0,2]  R262      -4.0018233656883240e-01
    z[1,0,2]  R263      -1.9711470603942871e-01
    z[1,0,2]  R264      -1.2846191413700581e-02
    z[1,0,2]  R265      2.4511611461639404e-01
    z[1,0,2]  R266      6.2628291547298431e-02
    z[1,0,2]  R267      1.0547447949647903e-01
    z[1,0,2]  R268      3.3033019304275513e-01
    z[1,0,2]  R269      6.6327786445617676e-01
    z[1,0,2]  R270      8.1514120101928711e-02
    z[1,0,2]  R271      -1.3852171599864960e-01
    z[1,0,2]  R272      4.2326194047927856e-01
    z[1,0,2]  R273      -4.6761423349380493e-02
    z[1,0,2]  R274      3.7887477874755859e-01
    z[1,0,2]  R275      -9.9935494363307953e-02
    z[1,0,2]  R276      1.0055445134639740e-01
    z[1,0,2]  R277      2.0335851609706879e-01
    z[1,0,2]  R278      -1.0601404309272766e-01
    z[1,0,2]  R279      -1.2080924212932587e-01
    z[1,0,2]  R280      -3.1700644642114639e-02
    z[1,0,2]  R281      -3.3466815948486328e-01
    z[1,0,2]  R282      -0.687119722366333
    z[1,0,2]  R283      -6.4685958623886108e-01
    z[1,0,2]  R284      -6.0850036144256592e-01
    z[1,0,2]  R285      2.5499412789940834e-02
    z[1,0,2]  R286      5.7227391749620438e-02
    z[1,0,2]  R287      2.2832669317722321e-01
    z[1,0,2]  R288      -1.0725231468677521e-01
    z[1,0,2]  R289      1.5175219625234604e-02
    z[1,0,2]  R290      2.7799534797668457e-01
    z[1,0,2]  R291      -1.1042208969593048e-01
    z[1,0,2]  R292      -4.4454595446586609e-01
    z[1,0,2]  R293      5.8498613536357880e-02
    z[1,0,2]  R294      -3.2437656074762344e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R177      -1
    z[1,0,3]  R178      1
    z[1,0,3]  R185      -1.0823883116245270e-01
    z[1,0,3]  R186      0.356587290763855
    z[1,0,3]  R187      6.0027605295181274e-01
    z[1,0,3]  R188      5.1075166463851929e-01
    z[1,0,3]  R189      5.3740882873535156e-01
    z[1,0,3]  R190      1.0916360467672348e-01
    z[1,0,3]  R191      4.9610521644353867e-02
    z[1,0,3]  R192      2.6247090101242065e-01
    z[1,0,3]  R193      3.9771571755409241e-01
    z[1,0,3]  R194      4.4433519244194031e-01
    z[1,0,3]  R195      2.9319867491722107e-01
    z[1,0,3]  R196      -1.5360046923160553e-01
    z[1,0,3]  R197      -2.7590749785304070e-02
    z[1,0,3]  R198      2.2711518406867981e-01
    z[1,0,3]  R199      -1.6082301735877991e-01
    z[1,0,3]  R200      -6.8718180060386658e-02
    z[1,0,3]  R201      3.1026366353034973e-01
    z[1,0,3]  R202      -5.8440599590539932e-02
    z[1,0,3]  R203      -4.1871690191328526e-03
    z[1,0,3]  R204      -4.1127860546112061e-02
    z[1,0,3]  R205      -3.3243077993392944e-01
    z[1,0,3]  R206      -6.8526461720466614e-02
    z[1,0,3]  R207      -8.7724313139915466e-02
    z[1,0,3]  R208      -3.5257175564765930e-01
    z[1,0,3]  R209      -2.9554140567779541e-01
    z[1,0,3]  R210      -2.9453948140144348e-01
    z[1,0,3]  R211      -3.3523476123809814e-01
    z[1,0,3]  R212      -3.7054210901260376e-01
    z[1,0,3]  R213      -4.7129637002944946e-01
    z[1,0,3]  R214      -3.0005259439349174e-02
    z[1,0,3]  R215      -3.7874984741210938e-01
    z[1,0,3]  R216      9.7439870238304138e-02
    z[1,0,3]  R217      -3.0197608470916748e-01
    z[1,0,3]  R218      -2.0218986272811890e-01
    z[1,0,3]  R219      -1.5474145114421844e-01
    z[1,0,3]  R220      -4.0473595261573792e-02
    z[1,0,3]  R221      9.7739197313785553e-02
    z[1,0,3]  R222      -2.5048962235450745e-01
    z[1,0,3]  R223      -3.2698279619216919e-01
    z[1,0,3]  R224      -2.5443577766418457e-01
    z[1,0,3]  R225      -1.5198162198066711e-01
    z[1,0,3]  R226      -3.0203291773796082e-01
    z[1,0,3]  R227      -3.0847027897834778e-01
    z[1,0,3]  R228      -3.9656361937522888e-01
    z[1,0,3]  R229      -9.1805262491106987e-03
    z[1,0,3]  R230      -1.6141927242279053e-01
    z[1,0,3]  R231      -2.9566857218742371e-01
    z[1,0,3]  R232      -1.8786433339118958e-01
    z[1,0,3]  R233      -3.1983304023742676e-01
    z[1,0,3]  R234      1.8618069589138031e-01
    z[1,0,3]  R235      -2.7918061614036560e-01
    z[1,0,3]  R236      -1.5112577378749847e-01
    z[1,0,3]  R237      -3.8952809572219849e-01
    z[1,0,3]  R238      -2.6958325877785683e-02
    z[1,0,3]  R239      -0.576545238494873
    z[1,0,3]  R240      4.2964771389961243e-01
    z[1,0,3]  R241      3.6707094311714172e-01
    z[1,0,3]  R242      4.9446511268615723e-01
    z[1,0,3]  R243      -8.6714506149291992e-02
    z[1,0,3]  R244      8.4276819229125977e-01
    z[1,0,3]  R245      -1.5110825002193451e-01
    z[1,0,3]  R246      4.4408398866653442e-01
    z[1,0,3]  R247      4.9077352881431580e-01
    z[1,0,3]  R248      3.7115055322647095e-01
    z[1,0,3]  R249      1.4902465045452118e-01
    z[1,0,3]  R250      5.3401932120323181e-02
    z[1,0,3]  R251      -2.3090282082557678e-01
    z[1,0,3]  R252      2.8796160221099854e-01
    z[1,0,3]  R253      2.4158558249473572e-01
    z[1,0,3]  R254      -3.7723553180694580e-01
    z[1,0,3]  R255      1.8693108856678009e-01
    z[1,0,3]  R256      4.9490388482809067e-03
    z[1,0,3]  R257      -1.4407569542527199e-02
    z[1,0,3]  R258      -0.00487411767244339
    z[1,0,3]  R259      6.2143850326538086e-01
    z[1,0,3]  R260      1.7748048901557922e-01
    z[1,0,3]  R261      3.9502236247062683e-01
    z[1,0,3]  R262      5.5404853820800781e-01
    z[1,0,3]  R263      -1.6640393063426018e-02
    z[1,0,3]  R264      2.5008162856101990e-01
    z[1,0,3]  R265      0.254672646522522
    z[1,0,3]  R266      4.5510622859001160e-01
    z[1,0,3]  R267      5.9680455923080444e-01
    z[1,0,3]  R268      2.9364828020334244e-02
    z[1,0,3]  R269      2.8551253676414490e-01
    z[1,0,3]  R270      4.4502565264701843e-01
    z[1,0,3]  R271      6.2376689165830612e-02
    z[1,0,3]  R272      2.4847450852394104e-01
    z[1,0,3]  R273      7.0948116481304169e-02
    z[1,0,3]  R274      5.4908853769302368e-01
    z[1,0,3]  R275      1.2764946557581425e-02
    z[1,0,3]  R276      2.4747721850872040e-01
    z[1,0,3]  R277      6.0122460126876831e-02
    z[1,0,3]  R278      -7.7999327331781387e-03
    z[1,0,3]  R279      2.8803277015686035e-01
    z[1,0,3]  R280      2.4187400937080383e-01
    z[1,0,3]  R281      6.3066351413726807e-01
    z[1,0,3]  R282      -1.0523796826601028e-01
    z[1,0,3]  R283      2.9216054081916809e-01
    z[1,0,3]  R284      1.7974372208118439e-01
    z[1,0,3]  R285      -3.1478229910135269e-02
    z[1,0,3]  R286      3.1292641162872314e-01
    z[1,0,3]  R287      3.5052257776260376e-01
    z[1,0,3]  R288      7.7737748622894287e-02
    z[1,0,3]  R289      -1.4659301936626434e-01
    z[1,0,3]  R290      -1.6012732684612274e-01
    z[1,0,3]  R291      1.8675832450389862e-01
    z[1,0,3]  R292      3.9999779313802719e-02
    z[1,0,3]  R293      5.6568211317062378e-01
    z[1,0,3]  R294      6.6492003202438354e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R179      -1
    z[1,0,4]  R180      1
    z[1,0,4]  R185      1.4760370831936598e-03
    z[1,0,4]  R186      4.1524812579154968e-02
    z[1,0,4]  R187      -2.6050312444567680e-02
    z[1,0,4]  R188      5.8437857776880264e-02
    z[1,0,4]  R189      -1.7981484532356262e-01
    z[1,0,4]  R190      -7.4437371222302318e-04
    z[1,0,4]  R191      2.3300166428089142e-01
    z[1,0,4]  R192      2.0796832442283630e-01
    z[1,0,4]  R193      1.1065878719091415e-01
    z[1,0,4]  R194      2.0427180826663971e-01
    z[1,0,4]  R195      1.6974899172782898e-01
    z[1,0,4]  R196      -4.4538193941116333e-01
    z[1,0,4]  R197      -3.1974750757217407e-01
    z[1,0,4]  R198      -1.9922609627246857e-01
    z[1,0,4]  R199      -2.7087783813476562e-01
    z[1,0,4]  R200      2.0275993272662163e-02
    z[1,0,4]  R201      1.0352526605129242e-01
    z[1,0,4]  R202      -1.5411649644374847e-01
    z[1,0,4]  R203      -9.2224171385169029e-03
    z[1,0,4]  R204      1.1496607959270477e-01
    z[1,0,4]  R205      1.1724268645048141e-01
    z[1,0,4]  R206      8.7437534332275391e-01
    z[1,0,4]  R207      -1.4307887852191925e-01
    z[1,0,4]  R208      8.4778529405593872e-01
    z[1,0,4]  R209      5.1797825098037720e-01
    z[1,0,4]  R210      7.7364194393157959e-01
    z[1,0,4]  R211      8.4896445274353027e-01
    z[1,0,4]  R212      0.667140781879425
    z[1,0,4]  R213      6.5066725015640259e-01
    z[1,0,4]  R214      -2.4185539782047272e-01
    z[1,0,4]  R215      -8.3446763455867767e-02
    z[1,0,4]  R216      8.9992147684097290e-01
    z[1,0,4]  R217      -2.5832799077033997e-01
    z[1,0,4]  R218      1.7638940364122391e-02
    z[1,0,4]  R219      -4.6297335624694824e-01
    z[1,0,4]  R220      -7.9953235387802124e-01
    z[1,0,4]  R221      -7.4610334634780884e-01
    z[1,0,4]  R222      7.0542466640472412e-01
    z[1,0,4]  R223      6.1648392677307129e-01
    z[1,0,4]  R224      1.2818135321140289e-01
    z[1,0,4]  R225      2.1970003843307495e-01
    z[1,0,4]  R226      -2.5865370035171509e-01
    z[1,0,4]  R227      6.4369821548461914e-01
    z[1,0,4]  R228      5.0892108678817749e-01
    z[1,0,4]  R229      -1.2675713002681732e-01
    z[1,0,4]  R230      9.5251753926277161e-02
    z[1,0,4]  R231      -7.3320806026458740e-02
    z[1,0,4]  R232      -5.4239153861999512e-02
    z[1,0,4]  R233      -1.0252785682678223e-01
    z[1,0,4]  R234      2.8734045103192329e-02
    z[1,0,4]  R235      -5.1024895161390305e-02
    z[1,0,4]  R236      1.3013137876987457e-01
    z[1,0,4]  R237      2.8744551539421082e-01
    z[1,0,4]  R238      -1.6588295996189117e-01
    z[1,0,4]  R239      -1.7806215584278107e-01
    z[1,0,4]  R240      -2.8135115280747414e-02
    z[1,0,4]  R241      -2.8193125128746033e-01
    z[1,0,4]  R242      3.4507939219474792e-01
    z[1,0,4]  R243      -1.3545063138008118e-01
    z[1,0,4]  R244      1.1985806375741959e-01
    z[1,0,4]  R245      1.3993303477764130e-01
    z[1,0,4]  R246      4.9991786479949951e-01
    z[1,0,4]  R247      7.4206370115280151e-01
    z[1,0,4]  R248      7.5349074602127075e-01
    z[1,0,4]  R249      -1.2462893128395081e-01
    z[1,0,4]  R250      -0.0282792616635561
    z[1,0,4]  R251      -3.6938312649726868e-01
    z[1,0,4]  R252      -2.8143274784088135e-01
    z[1,0,4]  R253      -5.2599930763244629e-01
    z[1,0,4]  R254      -2.1209090948104858e-01
    z[1,0,4]  R255      -9.3808978796005249e-02
    z[1,0,4]  R256      -2.3968910798430443e-02
    z[1,0,4]  R257      1.0132896155118942e-01
    z[1,0,4]  R258      -1.6049362719058990e-01
    z[1,0,4]  R259      1.0189700871706009e-01
    z[1,0,4]  R260      3.9138558506965637e-01
    z[1,0,4]  R261      4.0224725008010864e-01
    z[1,0,4]  R262      2.0485168695449829e-01
    z[1,0,4]  R263      -2.6626411080360413e-01
    z[1,0,4]  R264      3.0490845441818237e-01
    z[1,0,4]  R265      1.0915137827396393e-01
    z[1,0,4]  R266      7.1642078459262848e-02
    z[1,0,4]  R267      2.0457884669303894e-01
    z[1,0,4]  R268      5.7132825255393982e-02
    z[1,0,4]  R269      1.3246698677539825e-01
    z[1,0,4]  R270      -3.7669813632965088e-01
    z[1,0,4]  R271      -1.6978222131729126e-01
    z[1,0,4]  R272      -6.1717376112937927e-02
    z[1,0,4]  R273      -4.7624397277832031e-01
    z[1,0,4]  R274      -1.4507827162742615e-01
    z[1,0,4]  R275      -1.7002993822097778e-01
    z[1,0,4]  R276      -4.2550783604383469e-02
    z[1,0,4]  R277      -9.4564616680145264e-02
    z[1,0,4]  R278      1.6484777629375458e-01
    z[1,0,4]  R279      1.1954781413078308e-01
    z[1,0,4]  R280      -2.3453450202941895e-01
    z[1,0,4]  R281      -1.9616085290908813e-01
    z[1,0,4]  R282      -1.7899875342845917e-01
    z[1,0,4]  R283      -6.4933754503726959e-02
    z[1,0,4]  R284      -2.2044228017330170e-01
    z[1,0,4]  R285      3.1556585431098938e-01
    z[1,0,4]  R286      1.0745245218276978e-01
    z[1,0,4]  R287      -7.7980393543839455e-03
    z[1,0,4]  R288      -2.1471410989761353e-02
    z[1,0,4]  R289      -1.3983753323554993e-01
    z[1,0,4]  R290      -2.3936058580875397e-01
    z[1,0,4]  R291      -1.2669727206230164e-01
    z[1,0,4]  R292      1.7202737927436829e-01
    z[1,0,4]  R293      -4.1657772660255432e-01
    z[1,0,4]  R294      -2.6984393596649170e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R181      -1
    z[1,0,5]  R182      1
    z[1,0,5]  R185      -4.6309524774551392e-01
    z[1,0,5]  R186      -4.9777108430862427e-01
    z[1,0,5]  R187      -4.2009532451629639e-01
    z[1,0,5]  R188      -7.0185315608978271e-01
    z[1,0,5]  R189      -6.2715178728103638e-01
    z[1,0,5]  R190      -0.702717125415802
    z[1,0,5]  R191      -7.4101728200912476e-01
    z[1,0,5]  R192      -8.6752545833587646e-01
    z[1,0,5]  R193      -3.7044957280158997e-01
    z[1,0,5]  R194      -1.9174227118492126e-01
    z[1,0,5]  R195      -4.8559173941612244e-01
    z[1,0,5]  R196      -1.7354622483253479e-02
    z[1,0,5]  R197      -7.6631464064121246e-02
    z[1,0,5]  R198      5.7139031589031219e-02
    z[1,0,5]  R199      1.1248541623353958e-01
    z[1,0,5]  R200      1.1797171086072922e-01
    z[1,0,5]  R201      2.0577445626258850e-01
    z[1,0,5]  R202      4.0649777650833130e-01
    z[1,0,5]  R203      -1.2953018769621849e-02
    z[1,0,5]  R204      7.9326741397380829e-02
    z[1,0,5]  R205      -1.7031390964984894e-01
    z[1,0,5]  R206      0.214023619890213
    z[1,0,5]  R207      3.6025542020797729e-01
    z[1,0,5]  R208      1.0420871526002884e-01
    z[1,0,5]  R209      7.6388245820999146e-01
    z[1,0,5]  R210      -2.0823728293180466e-02
    z[1,0,5]  R211      3.0105376243591309e-01
    z[1,0,5]  R212      -2.1040309220552444e-02
    z[1,0,5]  R213      4.6810010075569153e-01
    z[1,0,5]  R214      5.6569927930831909e-01
    z[1,0,5]  R215      -5.4583930969238281e-01
    z[1,0,5]  R216      -2.8972637653350830e-01
    z[1,0,5]  R217      -7.1383011341094971e-01
    z[1,0,5]  R218      1.3720458745956421e-01
    z[1,0,5]  R219      1.3389253616333008e-01
    z[1,0,5]  R220      -0.0657874047756195
    z[1,0,5]  R221      5.4046556353569031e-02
    z[1,0,5]  R222      -1.2181343883275986e-01
    z[1,0,5]  R223      5.0305038690567017e-01
    z[1,0,5]  R224      5.5670654773712158e-01
    z[1,0,5]  R225      -3.3804804086685181e-01
    z[1,0,5]  R226      1.0120960325002670e-01
    z[1,0,5]  R227      5.6893342733383179e-01
    z[1,0,5]  R228      5.1979804039001465e-01
    z[1,0,5]  R229      7.6164029538631439e-02
    z[1,0,5]  R230      2.9966291785240173e-01
    z[1,0,5]  R231      2.8683552145957947e-01
    z[1,0,5]  R232      4.4693747162818909e-01
    z[1,0,5]  R233      3.0494108796119690e-01
    z[1,0,5]  R234      3.9764198660850525e-01
    z[1,0,5]  R235      -2.5622516870498657e-01
    z[1,0,5]  R236      -6.9626617431640625e-01
    z[1,0,5]  R237      -7.0565515756607056e-01
    z[1,0,5]  R238      6.4109876751899719e-02
    z[1,0,5]  R239      -4.1626104712486267e-01
    z[1,0,5]  R240      1.5259596705436707e-01
    z[1,0,5]  R241      -3.7575110793113708e-01
    z[1,0,5]  R242      7.5319744646549225e-02
    z[1,0,5]  R243      1.0449462383985519e-01
    z[1,0,5]  R244      5.2294008433818817e-02
    z[1,0,5]  R245      5.3625613451004028e-01
    z[1,0,5]  R246      4.7479662299156189e-01
    z[1,0,5]  R247      1.4701986312866211e-01
    z[1,0,5]  R248      -2.7418610453605652e-01
    z[1,0,5]  R249      2.6580700278282166e-01
    z[1,0,5]  R250      1.4808274805545807e-01
    z[1,0,5]  R251      0.138405442237854
    z[1,0,5]  R252      2.3203523829579353e-02
    z[1,0,5]  R253      -9.9081307649612427e-02
    z[1,0,5]  R254      -0.170019268989563
    z[1,0,5]  R255      -1.4094074070453644e-01
    z[1,0,5]  R256      1.4805573225021362e-01
    z[1,0,5]  R257      -0.00614133570343256
    z[1,0,5]  R258      -4.6561844646930695e-02
    z[1,0,5]  R259      -2.0218789577484131e-01
    z[1,0,5]  R260      -0.070730060338974
    z[1,0,5]  R261      -0.125872403383255
    z[1,0,5]  R262      1.6337139904499054e-01
    z[1,0,5]  R263      -1.4813865534961224e-02
    z[1,0,5]  R264      5.1943007856607437e-02
    z[1,0,5]  R265      -3.0868789553642273e-01
    z[1,0,5]  R266      -2.3672723770141602e-01
    z[1,0,5]  R267      -1.9990043714642525e-02
    z[1,0,5]  R268      8.1158012151718140e-02
    z[1,0,5]  R269      7.2173632681369781e-02
    z[1,0,5]  R270      2.4948580563068390e-01
    z[1,0,5]  R271      1.4346297085285187e-01
    z[1,0,5]  R272      1.6191197931766510e-01
    z[1,0,5]  R273      1.1874933540821075e-01
    z[1,0,5]  R274      2.5968101620674133e-01
    z[1,0,5]  R275      6.2717609107494354e-03
    z[1,0,5]  R276      -9.1657042503356934e-02
    z[1,0,5]  R277      2.0332394167780876e-02
    z[1,0,5]  R278      -1.4069218933582306e-01
    z[1,0,5]  R279      3.7906490266323090e-02
    z[1,0,5]  R280      4.4746950268745422e-01
    z[1,0,5]  R281      2.4970276653766632e-01
    z[1,0,5]  R282      2.6387146115303040e-01
    z[1,0,5]  R283      1.9971735775470734e-01
    z[1,0,5]  R284      2.0439951121807098e-01
    z[1,0,5]  R285      -3.6918017268180847e-01
    z[1,0,5]  R286      -1.3579083979129791e-01
    z[1,0,5]  R287      3.4114348888397217e-01
    z[1,0,5]  R288      3.0706393718719482e-01
    z[1,0,5]  R289      -1.4180496335029602e-01
    z[1,0,5]  R290      -0.0861627534031868
    z[1,0,5]  R291      2.9993566870689392e-01
    z[1,0,5]  R292      -2.6750189065933228e-01
    z[1,0,5]  R293      6.1956298351287842e-01
    z[1,0,5]  R294      5.0050729513168335e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R183      -1
    z[1,0,6]  R184      1
    z[1,0,6]  R185      -1.4961341023445129e-01
    z[1,0,6]  R186      2.1387757360935211e-01
    z[1,0,6]  R187      0.087035171687603
    z[1,0,6]  R188      -8.3404621109366417e-03
    z[1,0,6]  R189      -1.8069240450859070e-01
    z[1,0,6]  R190      0.287383496761322
    z[1,0,6]  R191      -4.4324392080307007e-01
    z[1,0,6]  R192      7.8737497329711914e-02
    z[1,0,6]  R193      5.5472618341445923e-01
    z[1,0,6]  R194      7.5775671005249023e-01
    z[1,0,6]  R195      3.4774962067604065e-01
    z[1,0,6]  R196      9.1815330088138580e-02
    z[1,0,6]  R197      -3.9528802037239075e-01
    z[1,0,6]  R198      0.0697116032242775
    z[1,0,6]  R199      2.9087954759597778e-01
    z[1,0,6]  R200      3.2448939979076385e-02
    z[1,0,6]  R201      -5.4661218076944351e-02
    z[1,0,6]  R202      -2.4099057912826538e-01
    z[1,0,6]  R203      -1.1285389959812164e-01
    z[1,0,6]  R204      7.5361780822277069e-02
    z[1,0,6]  R205      -2.4202053900808096e-03
    z[1,0,6]  R206      1.1376570910215378e-01
    z[1,0,6]  R207      5.3188685327768326e-02
    z[1,0,6]  R208      -1.8500572443008423e-01
    z[1,0,6]  R209      -7.9107824712991714e-03
    z[1,0,6]  R210      -3.7395489215850830e-01
    z[1,0,6]  R211      0.123031385242939
    z[1,0,6]  R212      -5.0080728530883789e-01
    z[1,0,6]  R213      -2.1072435379028320e-01
    z[1,0,6]  R214      -2.5283247232437134e-01
    z[1,0,6]  R215      3.4493315219879150e-01
    z[1,0,6]  R216      2.6844039559364319e-01
    z[1,0,6]  R217      -3.3700618147850037e-01
    z[1,0,6]  R218      -3.2257422804832458e-01
    z[1,0,6]  R219      -3.5320317745208740e-01
    z[1,0,6]  R220      -2.6487755775451660e-01
    z[1,0,6]  R221      -1.5535186231136322e-01
    z[1,0,6]  R222      -4.2757540941238403e-01
    z[1,0,6]  R223      2.8858572244644165e-01
    z[1,0,6]  R224      -1.7450398206710815e-01
    z[1,0,6]  R225      -2.6332248002290726e-02
    z[1,0,6]  R226      -0.159862220287323
    z[1,0,6]  R227      -3.2387372851371765e-01
    z[1,0,6]  R228      -1.4186498522758484e-01
    z[1,0,6]  R229      -2.2816176712512970e-01
    z[1,0,6]  R230      -0.0744878277182579
    z[1,0,6]  R231      -2.5121471285820007e-01
    z[1,0,6]  R232      -2.8377154842019081e-02
    z[1,0,6]  R233      -4.8527400940656662e-02
    z[1,0,6]  R234      1.4812238514423370e-01
    z[1,0,6]  R235      5.8988708257675171e-01
    z[1,0,6]  R236      5.1419258117675781e-01
    z[1,0,6]  R237      4.3201144784688950e-02
    z[1,0,6]  R238      -4.4612166285514832e-01
    z[1,0,6]  R239      -0.28459432721138
    z[1,0,6]  R240      1.2120986357331276e-02
    z[1,0,6]  R241      -3.1471100449562073e-01
    z[1,0,6]  R242      -2.4058060348033905e-01
    z[1,0,6]  R243      -0.128374844789505
    z[1,0,6]  R244      0.0751722976565361
    z[1,0,6]  R245      5.0954829901456833e-02
    z[1,0,6]  R246      2.2015309333801270e-01
    z[1,0,6]  R247      9.5172263681888580e-02
    z[1,0,6]  R248      -1.4934517443180084e-01
    z[1,0,6]  R249      3.6412796378135681e-01
    z[1,0,6]  R250      2.8385373950004578e-01
    z[1,0,6]  R251      -7.6482407748699188e-02
    z[1,0,6]  R252      -4.5404630899429321e-01
    z[1,0,6]  R253      7.5264692306518555e-02
    z[1,0,6]  R254      1.3915333151817322e-01
    z[1,0,6]  R255      -0.0847182348370552
    z[1,0,6]  R256      -1.1609897762537003e-01
    z[1,0,6]  R257      -2.6535862684249878e-01
    z[1,0,6]  R258      1.6977122426033020e-01
    z[1,0,6]  R259      -9.4169579446315765e-02
    z[1,0,6]  R260      -1.9882759451866150e-01
    z[1,0,6]  R261      1.2652884423732758e-01
    z[1,0,6]  R262      1.5812614560127258e-01
    z[1,0,6]  R263      1.3132725842297077e-02
    z[1,0,6]  R264      1.4832308888435364e-01
    z[1,0,6]  R265      -5.8644801378250122e-01
    z[1,0,6]  R266      -9.6080824732780457e-02
    z[1,0,6]  R267      -0.0935017317533493
    z[1,0,6]  R268      4.2079180479049683e-02
    z[1,0,6]  R269      -2.3811565339565277e-01
    z[1,0,6]  R270      1.5567111968994141e-01
    z[1,0,6]  R271      4.1509577631950378e-01
    z[1,0,6]  R272      -0.135938823223114
    z[1,0,6]  R273      2.3738507926464081e-01
    z[1,0,6]  R274      1.1658837087452412e-02
    z[1,0,6]  R275      2.8270691633224487e-01
    z[1,0,6]  R276      -4.6458322554826736e-02
    z[1,0,6]  R277      3.6631596088409424e-01
    z[1,0,6]  R278      -2.9645375907421112e-02
    z[1,0,6]  R279      4.3972063064575195e-01
    z[1,0,6]  R280      -3.2069772481918335e-01
    z[1,0,6]  R281      -4.4085553288459778e-01
    z[1,0,6]  R282      7.9573400318622589e-02
    z[1,0,6]  R283      1.6697552800178528e-01
    z[1,0,6]  R284      -0.261714369058609
    z[1,0,6]  R285      -6.3062274456024170e-01
    z[1,0,6]  R286      3.0303898453712463e-01
    z[1,0,6]  R287      8.4230154752731323e-02
    z[1,0,6]  R288      1.1596415936946869e-01
    z[1,0,6]  R289      1.8427266180515289e-01
    z[1,0,6]  R290      -1.7956189811229706e-01
    z[1,0,6]  R291      -2.8307339549064636e-01
    z[1,0,6]  R292      -8.2004763185977936e-02
    z[1,0,6]  R293      1.5848989784717560e-01
    z[1,0,6]  R294      2.1177372336387634e-01
    z[0,2,0]  R2        -1
    z[0,2,0]  R20       1
    z[0,2,0]  R295      -1
    z[0,2,0]  R296      1
    z[0,2,0]  R309      1.3831178843975067e-01
    z[0,2,0]  R310      -2.4963927268981934e-01
    z[0,2,0]  R311      1.5677075088024139e-01
    z[0,2,0]  R312      2.0215308666229248e-01
    z[0,2,0]  R313      3.3621060848236084e-01
    z[0,2,0]  R314      -3.6002430319786072e-01
    z[0,2,0]  R315      2.8251945972442627e-01
    z[0,2,0]  R316      5.3606323897838593e-02
    z[0,2,0]  R317      -2.0865032076835632e-01
    z[0,2,0]  R318      0.0792015790939331
    z[0,2,0]  R319      6.9700604677200317e-01
    z[0,2,0]  R320      4.9385523796081543e-01
    z[0,2,0]  R321      2.7884298563003540e-01
    z[0,2,0]  R322      -6.2758654356002808e-02
    z[0,2,0]  R323      4.4140231609344482e-01
    z[0,2,0]  R324      2.9204022884368896e-01
    z[0,2,0]  R325      0.0990278422832489
    z[0,2,0]  R326      5.6584876775741577e-01
    z[0,2,0]  R327      0.438368558883667
    z[0,2,0]  R328      1.2508645653724670e-01
    z[0,2,0]  R329      4.1417360305786133e-01
    z[0,2,0]  R330      4.1959103941917419e-01
    z[0,2,0]  R331      5.5644816160202026e-01
    z[0,2,0]  R332      6.3575762510299683e-01
    z[0,2,0]  R333      4.1316190361976624e-01
    z[0,2,0]  R334      3.8598445057868958e-01
    z[0,2,0]  R335      2.8113448619842529e-01
    z[0,2,0]  R336      2.4223934113979340e-01
    z[0,2,0]  R337      -3.3876141905784607e-01
    z[0,2,0]  R338      1.6936412453651428e-01
    z[0,2,0]  R339      -2.2780045866966248e-01
    z[0,2,0]  R340      5.2210664749145508e-01
    z[0,2,0]  R341      4.7280839085578918e-01
    z[0,2,0]  R342      3.7545260787010193e-01
    z[0,2,0]  R343      -4.0232321619987488e-01
    z[0,2,0]  R344      4.7286859154701233e-01
    z[0,2,0]  R345      -1.9411759078502655e-01
    z[0,2,0]  R346      9.3059904873371124e-02
    z[0,2,0]  R347      4.1530004143714905e-01
    z[0,2,0]  R348      2.9094433784484863e-01
    z[0,2,0]  R349      4.4050028920173645e-01
    z[0,2,0]  R350      -3.1407541036605835e-01
    z[0,2,0]  R351      -2.5384524837136269e-02
    z[0,2,0]  R352      1.2459943443536758e-01
    z[0,2,0]  R353      -2.3517280817031860e-01
    z[0,2,0]  R354      -5.2083592861890793e-02
    z[0,2,0]  R355      1.4811287820339203e-01
    z[0,2,0]  R356      -6.3537520170211792e-01
    z[0,2,0]  R357      -6.4471709728240967e-01
    z[0,2,0]  R358      -6.5766119956970215e-01
    z[0,2,0]  R359      1.2397421896457672e-01
    z[0,2,0]  R360      6.3077318668365479e-01
    z[0,2,0]  R361      5.0213652849197388e-01
    z[0,2,0]  R362      2.0148406922817230e-01
    z[0,2,0]  R363      -4.1290480643510818e-02
    z[0,2,0]  R364      9.4691142439842224e-02
    z[0,2,0]  R365      -2.8340309858322144e-02
    z[0,2,0]  R366      -2.4740856885910034e-01
    z[0,2,0]  R367      -3.0452784895896912e-01
    z[0,2,0]  R368      -3.8870215415954590e-01
    z[0,2,0]  R369      -7.4349719285964966e-01
    z[0,2,0]  R370      -9.0440279245376587e-01
    z[0,2,0]  R371      -6.5755015611648560e-01
    z[0,2,0]  R372      -3.6882689595222473e-01
    z[0,2,0]  R373      -1.4272942207753658e-02
    z[0,2,0]  R374      4.3630054593086243e-01
    z[0,2,0]  R375      3.0258023738861084e-01
    z[0,2,0]  R376      1.9868750870227814e-01
    z[0,2,0]  R377      3.1030893325805664e-01
    z[0,2,0]  R378      2.8834110498428345e-01
    z[0,2,0]  R379      2.7444690465927124e-01
    z[0,2,0]  R380      -0.0762915164232254
    z[0,2,0]  R381      -2.3704680800437927e-01
    z[0,2,0]  R382      -0.0945655107498169
    z[0,2,0]  R383      -6.8223255872726440e-01
    z[0,2,0]  R384      -6.3873386383056641e-01
    z[0,2,0]  R385      -6.0326629877090454e-01
    z[0,2,0]  R386      -6.0984796285629272e-01
    z[0,2,0]  R387      5.6926918029785156e-01
    z[0,2,0]  R388      -5.7782799005508423e-02
    z[0,2,0]  R389      -6.3951557874679565e-01
    z[0,2,0]  R390      -6.9014227390289307e-01
    z[0,2,0]  R391      4.5249709486961365e-01
    z[0,2,0]  R392      -6.7513942718505859e-02
    z[0,2,0]  R393      -1.5221396088600159e-01
    z[0,2,0]  R394      -3.7763002514839172e-01
    z[0,2,0]  R395      -3.0197069048881531e-01
    z[0,2,0]  R396      5.5052733421325684e-01
    z[0,2,0]  R397      0.402831107378006
    z[0,2,0]  R398      0.676831066608429
    z[0,2,0]  R399      1.1956851184368134e-01
    z[0,2,0]  R400      -7.8148734569549561e-01
    z[0,2,0]  R401      6.5265917778015137e-01
    z[0,2,0]  R402      -7.2481507062911987e-01
    z[0,2,0]  R403      3.8184890151023865e-01
    z[0,2,0]  R404      4.3753212690353394e-01
    z[0,2,0]  R405      -7.1952289342880249e-01
    z[0,2,0]  R406      4.2336440086364746e-01
    z[0,2,0]  R407      -1.8188993632793427e-01
    z[0,2,0]  R408      0.668256938457489
    z[0,2,0]  R409      4.7530296444892883e-01
    z[0,2,0]  R410      7.9442560672760010e-01
    z[0,2,0]  R411      0.531466007232666
    z[0,2,0]  R412      5.7659108191728592e-02
    z[0,2,0]  R413      3.7302851676940918e-01
    z[0,2,0]  R414      1.3967619836330414e-01
    z[0,2,0]  R415      9.8253987729549408e-02
    z[0,2,0]  R416      -1.2154962867498398e-02
    z[0,2,0]  R417      3.6504435539245605e-01
    z[0,2,0]  R418      2.6145428419113159e-01
    z[0,2,0]  R419      1.4792186021804810e-01
    z[0,2,0]  R420      1.0102129727602005e-01
    z[0,2,0]  R421      -7.0512253046035767e-01
    z[0,2,0]  R422      3.8878908753395081e-01
    z[0,2,0]  R423      3.1997001171112061e-01
    z[0,2,0]  R424      2.2307321429252625e-01
    z[0,2,0]  R425      2.2730773314833641e-02
    z[0,2,0]  R426      5.2008849382400513e-01
    z[0,2,0]  R427      -2.0841567218303680e-01
    z[0,2,1]  R3        -1
    z[0,2,1]  R21       1
    z[0,2,1]  R297      -1
    z[0,2,1]  R298      1
    z[0,2,1]  R309      5.4261481761932373e-01
    z[0,2,1]  R310      1.8471740186214447e-01
    z[0,2,1]  R311      4.8204636573791504e-01
    z[0,2,1]  R312      6.2353205680847168e-01
    z[0,2,1]  R313      3.3489429950714111e-01
    z[0,2,1]  R314      -8.1334710121154785e-01
    z[0,2,1]  R315      -6.8163412809371948e-01
    z[0,2,1]  R316      -7.3793184757232666e-01
    z[0,2,1]  R317      -6.2932431697845459e-01
    z[0,2,1]  R318      -4.5561450719833374e-01
    z[0,2,1]  R319      2.6548174023628235e-01
    z[0,2,1]  R320      1.7883922159671783e-01
    z[0,2,1]  R321      2.4211584031581879e-01
    z[0,2,1]  R322      -3.7438550591468811e-01
    z[0,2,1]  R323      -6.9548559188842773e-01
    z[0,2,1]  R324      -8.1426960229873657e-01
    z[0,2,1]  R325      -8.8026142120361328e-01
    z[0,2,1]  R326      -5.5686980485916138e-01
    z[0,2,1]  R327      -6.1559689044952393e-01
    z[0,2,1]  R328      -8.6519724130630493e-01
    z[0,2,1]  R329      -7.8430545330047607e-01
    z[0,2,1]  R330      -8.8759505748748779e-01
    z[0,2,1]  R331      -7.8066098690032959e-01
    z[0,2,1]  R332      -7.2174870967864990e-01
    z[0,2,1]  R333      -0.579284131526947
    z[0,2,1]  R334      -0.739266574382782
    z[0,2,1]  R335      -7.4926763772964478e-01
    z[0,2,1]  R336      -0.616884171962738
    z[0,2,1]  R337      -8.8023918867111206e-01
    z[0,2,1]  R338      -8.8934975862503052e-01
    z[0,2,1]  R339      -6.0995358228683472e-01
    z[0,2,1]  R340      -6.6779989004135132e-01
    z[0,2,1]  R341      -5.9846210479736328e-01
    z[0,2,1]  R342      -8.5873937606811523e-01
    z[0,2,1]  R343      -4.8705798387527466e-01
    z[0,2,1]  R344      -5.8593922853469849e-01
    z[0,2,1]  R345      -8.4706974029541016e-01
    z[0,2,1]  R346      -8.3782196044921875e-01
    z[0,2,1]  R347      -7.2321790456771851e-01
    z[0,2,1]  R348      -6.1781018972396851e-01
    z[0,2,1]  R349      -8.2881647348403931e-01
    z[0,2,1]  R350      -9.0422928333282471e-01
    z[0,2,1]  R351      -9.0046817064285278e-01
    z[0,2,1]  R352      -9.6193933486938477e-01
    z[0,2,1]  R353      -0.798782229423523
    z[0,2,1]  R354      -7.6137822866439819e-01
    z[0,2,1]  R355      -4.1610002517700195e-01
    z[0,2,1]  R356      7.1338564157485962e-02
    z[0,2,1]  R357      9.2577107250690460e-02
    z[0,2,1]  R358      7.7672697603702545e-02
    z[0,2,1]  R359      -5.9112477302551270e-01
    z[0,2,1]  R360      -0.6157186627388
    z[0,2,1]  R361      -6.7031729221343994e-01
    z[0,2,1]  R362      -9.1305035352706909e-01
    z[0,2,1]  R363      -9.5023977756500244e-01
    z[0,2,1]  R364      -8.8946694135665894e-01
    z[0,2,1]  R365      -8.7520343065261841e-01
    z[0,2,1]  R366      -7.9479080438613892e-01
    z[0,2,1]  R367      0.0364716611802578
    z[0,2,1]  R368      1.9382598996162415e-01
    z[0,2,1]  R369      -1.6133917868137360e-01
    z[0,2,1]  R370      -1.8875263631343842e-01
    z[0,2,1]  R371      -1.4964066445827484e-01
    z[0,2,1]  R372      -6.5964251756668091e-01
    z[0,2,1]  R373      7.8889004886150360e-02
    z[0,2,1]  R374      1.8604267388582230e-02
    z[0,2,1]  R375      -1.1806106194853783e-02
    z[0,2,1]  R376      5.4581854492425919e-02
    z[0,2,1]  R377      -1.2077865749597549e-01
    z[0,2,1]  R378      5.2824807353317738e-03
    z[0,2,1]  R379      8.4847694635391235e-01
    z[0,2,1]  R380      8.0799955129623413e-01
    z[0,2,1]  R381      7.9552549123764038e-01
    z[0,2,1]  R382      8.1549555063247681e-01
    z[0,2,1]  R383      3.7019926309585571e-01
    z[0,2,1]  R384      2.2374063730239868e-01
    z[0,2,1]  R385      8.6924374103546143e-02
    z[0,2,1]  R386      3.7069177627563477e-01
    z[0,2,1]  R387      3.9249441027641296e-01
    z[0,2,1]  R388      6.4467805624008179e-01
    z[0,2,1]  R389      -1.0548141598701477e-01
    z[0,2,1]  R390      -1.2155154347419739e-01
    z[0,2,1]  R391      -5.4345929622650146e-01
    z[0,2,1]  R392      2.1160256862640381e-01
    z[0,2,1]  R393      8.4358178079128265e-02
    z[0,2,1]  R394      -4.2696982622146606e-02
    z[0,2,1]  R395      -1.6924735158681870e-02
    z[0,2,1]  R396      3.2430076599121094e-01
    z[0,2,1]  R397      3.4691080451011658e-02
    z[0,2,1]  R398      8.5422113537788391e-02
    z[0,2,1]  R399      5.7380330562591553e-01
    z[0,2,1]  R400      -1.3982464373111725e-01
    z[0,2,1]  R401      5.3358948230743408e-01
    z[0,2,1]  R402      -9.4836302101612091e-02
    z[0,2,1]  R403      0.49685138463974
    z[0,2,1]  R404      4.8165795207023621e-01
    z[0,2,1]  R405      -1.6482116281986237e-01
    z[0,2,1]  R406      4.7156643867492676e-01
    z[0,2,1]  R407      2.8162896633148193e-01
    z[0,2,1]  R408      1.7092798650264740e-01
    z[0,2,1]  R409      7.1815800666809082e-01
    z[0,2,1]  R410      -1.8876178562641144e-01
    z[0,2,1]  R411      1.4198282361030579e-01
    z[0,2,1]  R412      3.8490608334541321e-01
    z[0,2,1]  R413      4.1333901882171631e-01
    z[0,2,1]  R414      3.3508679270744324e-01
    z[0,2,1]  R415      -1.2112998217344284e-01
    z[0,2,1]  R416      -1.4878851175308228e-01
    z[0,2,1]  R417      -4.0528278797864914e-02
    z[0,2,1]  R418      -2.2516460716724396e-01
    z[0,2,1]  R419      4.0738192200660706e-01
    z[0,2,1]  R420      3.3872112631797791e-01
    z[0,2,1]  R421      2.9937621951103210e-01
    z[0,2,1]  R422      3.7586104869842529e-01
    z[0,2,1]  R423      -5.2003145217895508e-01
    z[0,2,1]  R424      2.3173166811466217e-01
    z[0,2,1]  R425      -3.7086048722267151e-01
    z[0,2,1]  R426      -5.2467468194663525e-03
    z[0,2,1]  R427      -4.5383399724960327e-01
    z[0,2,2]  R4        -1
    z[0,2,2]  R22       1
    z[0,2,2]  R299      -1
    z[0,2,2]  R300      1
    z[0,2,2]  R309      4.3849232792854309e-01
    z[0,2,2]  R310      3.3853515982627869e-01
    z[0,2,2]  R311      9.4243094325065613e-02
    z[0,2,2]  R312      0.582205593585968
    z[0,2,2]  R313      3.9551305770874023e-01
    z[0,2,2]  R314      5.2726618014276028e-03
    z[0,2,2]  R315      -3.3160638064146042e-02
    z[0,2,2]  R316      1.5954692661762238e-01
    z[0,2,2]  R317      7.1214497089385986e-01
    z[0,2,2]  R318      2.3050554096698761e-01
    z[0,2,2]  R319      -3.3334669470787048e-01
    z[0,2,2]  R320      5.5639997124671936e-02
    z[0,2,2]  R321      -2.0356020331382751e-01
    z[0,2,2]  R322      -2.3002997040748596e-01
    z[0,2,2]  R323      -2.8369075059890747e-01
    z[0,2,2]  R324      3.8147693872451782e-01
    z[0,2,2]  R325      2.3826966062188148e-02
    z[0,2,2]  R326      -2.9808353632688522e-02
    z[0,2,2]  R327      -2.7991554141044617e-01
    z[0,2,2]  R328      -1.5095798298716545e-02
    z[0,2,2]  R329      -3.7754490971565247e-01
    z[0,2,2]  R330      -1.0950003750622272e-02
    z[0,2,2]  R331      2.4025326129049063e-03
    z[0,2,2]  R332      1.3460588455200195e-01
    z[0,2,2]  R333      -2.1773955225944519e-01
    z[0,2,2]  R334      -2.7437901496887207e-01
    z[0,2,2]  R335      -9.9309816956520081e-02
    z[0,2,2]  R336      -4.0018233656883240e-01
    z[0,2,2]  R337      -1.9711470603942871e-01
    z[0,2,2]  R338      -1.2846191413700581e-02
    z[0,2,2]  R339      2.4511611461639404e-01
    z[0,2,2]  R340      6.2628291547298431e-02
    z[0,2,2]  R341      1.0547447949647903e-01
    z[0,2,2]  R342      3.3033019304275513e-01
    z[0,2,2]  R343      6.6327786445617676e-01
    z[0,2,2]  R344      8.1514120101928711e-02
    z[0,2,2]  R345      -1.3852171599864960e-01
    z[0,2,2]  R346      4.2326194047927856e-01
    z[0,2,2]  R347      -4.6761423349380493e-02
    z[0,2,2]  R348      3.7887477874755859e-01
    z[0,2,2]  R349      -9.9935494363307953e-02
    z[0,2,2]  R350      1.0055445134639740e-01
    z[0,2,2]  R351      2.0335851609706879e-01
    z[0,2,2]  R352      -1.0601404309272766e-01
    z[0,2,2]  R353      -1.2080924212932587e-01
    z[0,2,2]  R354      -3.1700644642114639e-02
    z[0,2,2]  R355      -3.3466815948486328e-01
    z[0,2,2]  R356      -0.687119722366333
    z[0,2,2]  R357      -6.4685958623886108e-01
    z[0,2,2]  R358      -6.0850036144256592e-01
    z[0,2,2]  R359      2.5499412789940834e-02
    z[0,2,2]  R360      5.7227391749620438e-02
    z[0,2,2]  R361      2.2832669317722321e-01
    z[0,2,2]  R362      -1.0725231468677521e-01
    z[0,2,2]  R363      1.5175219625234604e-02
    z[0,2,2]  R364      2.7799534797668457e-01
    z[0,2,2]  R365      -1.1042208969593048e-01
    z[0,2,2]  R366      -4.4454595446586609e-01
    z[0,2,2]  R367      5.8498613536357880e-02
    z[0,2,2]  R368      -3.2437656074762344e-02
    z[0,2,2]  R369      5.5405408143997192e-01
    z[0,2,2]  R370      3.0208969116210938e-01
    z[0,2,2]  R371      4.4547548890113831e-01
    z[0,2,2]  R372      4.7857272624969482e-01
    z[0,2,2]  R373      6.4202749729156494e-01
    z[0,2,2]  R374      8.1291161477565765e-02
    z[0,2,2]  R375      4.4162884354591370e-02
    z[0,2,2]  R376      -1.8790006870403886e-03
    z[0,2,2]  R377      -2.3436856269836426e-01
    z[0,2,2]  R378      -2.3957021534442902e-01
    z[0,2,2]  R379      -4.2595416307449341e-01
    z[0,2,2]  R380      -5.2947640419006348e-01
    z[0,2,2]  R381      -0.502391517162323
    z[0,2,2]  R382      -4.5143491029739380e-01
    z[0,2,2]  R383      -0.36711585521698
    z[0,2,2]  R384      -4.1537192463874817e-01
    z[0,2,2]  R385      -4.2701101303100586e-01
    z[0,2,2]  R386      -1.5642069280147552e-01
    z[0,2,2]  R387      4.9039289355278015e-01
    z[0,2,2]  R388      -6.6163659095764160e-02
    z[0,2,2]  R389      -2.6565429568290710e-01
    z[0,2,2]  R390      -3.1715756654739380e-01
    z[0,2,2]  R391      -5.7490535080432892e-02
    z[0,2,2]  R392      -3.7725567817687988e-01
    z[0,2,2]  R393      -1.4679531753063202e-01
    z[0,2,2]  R394      3.9403751492500305e-02
    z[0,2,2]  R395      2.0407268404960632e-01
    z[0,2,2]  R396      2.6282489299774170e-01
    z[0,2,2]  R397      -4.7353811562061310e-02
    z[0,2,2]  R398      -1.6353714466094971e-01
    z[0,2,2]  R399      2.9847669601440430e-01
    z[0,2,2]  R400      -1.3640609383583069e-01
    z[0,2,2]  R401      2.2130960226058960e-01
    z[0,2,2]  R402      -8.3762980997562408e-02
    z[0,2,2]  R403      2.1198947727680206e-01
    z[0,2,2]  R404      3.2118758559226990e-01
    z[0,2,2]  R405      -3.8719365000724792e-01
    z[0,2,2]  R406      2.0314460992813110e-01
    z[0,2,2]  R407      -3.0454638600349426e-01
    z[0,2,2]  R408      -4.2584415525197983e-02
    z[0,2,2]  R409      -9.1633729636669159e-02
    z[0,2,2]  R410      -3.4959834069013596e-02
    z[0,2,2]  R411      -3.4006664156913757e-01
    z[0,2,2]  R412      6.0803387314081192e-02
    z[0,2,2]  R413      6.2868803739547729e-02
    z[0,2,2]  R414      2.2307692468166351e-01
    z[0,2,2]  R415      1.4269936084747314e-01
    z[0,2,2]  R416      -1.7905475571751595e-02
    z[0,2,2]  R417      1.4066404104232788e-01
    z[0,2,2]  R418      -3.2815438508987427e-01
    z[0,2,2]  R419      -1.9858621060848236e-01
    z[0,2,2]  R420      -4.4785720109939575e-01
    z[0,2,2]  R421      -3.6400568485260010e-01
    z[0,2,2]  R422      -7.2100780904293060e-02
    z[0,2,2]  R423      -1.2152507901191711e-01
    z[0,2,2]  R424      4.7754812985658646e-02
    z[0,2,2]  R425      7.7282279729843140e-02
    z[0,2,2]  R426      -2.3688524961471558e-01
    z[0,2,2]  R427      -0.737982451915741
    z[0,2,3]  R5        -1
    z[0,2,3]  R23       1
    z[0,2,3]  R301      -1
    z[0,2,3]  R302      1
    z[0,2,3]  R309      -2.7918061614036560e-01
    z[0,2,3]  R310      -1.5112577378749847e-01
    z[0,2,3]  R311      -3.8952809572219849e-01
    z[0,2,3]  R312      -2.6958325877785683e-02
    z[0,2,3]  R313      -0.576545238494873
    z[0,2,3]  R314      4.2964771389961243e-01
    z[0,2,3]  R315      3.6707094311714172e-01
    z[0,2,3]  R316      4.9446511268615723e-01
    z[0,2,3]  R317      -8.6714506149291992e-02
    z[0,2,3]  R318      8.4276819229125977e-01
    z[0,2,3]  R319      -1.5110825002193451e-01
    z[0,2,3]  R320      4.4408398866653442e-01
    z[0,2,3]  R321      4.9077352881431580e-01
    z[0,2,3]  R322      3.7115055322647095e-01
    z[0,2,3]  R323      1.4902465045452118e-01
    z[0,2,3]  R324      5.3401932120323181e-02
    z[0,2,3]  R325      -2.3090282082557678e-01
    z[0,2,3]  R326      2.8796160221099854e-01
    z[0,2,3]  R327      2.4158558249473572e-01
    z[0,2,3]  R328      -3.7723553180694580e-01
    z[0,2,3]  R329      1.8693108856678009e-01
    z[0,2,3]  R330      4.9490388482809067e-03
    z[0,2,3]  R331      -1.4407569542527199e-02
    z[0,2,3]  R332      -0.00487411767244339
    z[0,2,3]  R333      6.2143850326538086e-01
    z[0,2,3]  R334      1.7748048901557922e-01
    z[0,2,3]  R335      3.9502236247062683e-01
    z[0,2,3]  R336      5.5404853820800781e-01
    z[0,2,3]  R337      -1.6640393063426018e-02
    z[0,2,3]  R338      2.5008162856101990e-01
    z[0,2,3]  R339      0.254672646522522
    z[0,2,3]  R340      4.5510622859001160e-01
    z[0,2,3]  R341      5.9680455923080444e-01
    z[0,2,3]  R342      2.9364828020334244e-02
    z[0,2,3]  R343      2.8551253676414490e-01
    z[0,2,3]  R344      4.4502565264701843e-01
    z[0,2,3]  R345      6.2376689165830612e-02
    z[0,2,3]  R346      2.4847450852394104e-01
    z[0,2,3]  R347      7.0948116481304169e-02
    z[0,2,3]  R348      5.4908853769302368e-01
    z[0,2,3]  R349      1.2764946557581425e-02
    z[0,2,3]  R350      2.4747721850872040e-01
    z[0,2,3]  R351      6.0122460126876831e-02
    z[0,2,3]  R352      -7.7999327331781387e-03
    z[0,2,3]  R353      2.8803277015686035e-01
    z[0,2,3]  R354      2.4187400937080383e-01
    z[0,2,3]  R355      6.3066351413726807e-01
    z[0,2,3]  R356      -1.0523796826601028e-01
    z[0,2,3]  R357      2.9216054081916809e-01
    z[0,2,3]  R358      1.7974372208118439e-01
    z[0,2,3]  R359      -3.1478229910135269e-02
    z[0,2,3]  R360      3.1292641162872314e-01
    z[0,2,3]  R361      3.5052257776260376e-01
    z[0,2,3]  R362      7.7737748622894287e-02
    z[0,2,3]  R363      -1.4659301936626434e-01
    z[0,2,3]  R364      -1.6012732684612274e-01
    z[0,2,3]  R365      1.8675832450389862e-01
    z[0,2,3]  R366      3.9999779313802719e-02
    z[0,2,3]  R367      5.6568211317062378e-01
    z[0,2,3]  R368      6.6492003202438354e-01
    z[0,2,3]  R369      1.9688328728079796e-02
    z[0,2,3]  R370      2.5863319635391235e-02
    z[0,2,3]  R371      -5.6284625083208084e-02
    z[0,2,3]  R372      -1.7577295005321503e-01
    z[0,2,3]  R373      -2.0616275072097778e-01
    z[0,2,3]  R374      5.9721589088439941e-01
    z[0,2,3]  R375      3.6833903193473816e-01
    z[0,2,3]  R376      3.0313912034034729e-01
    z[0,2,3]  R377      4.2844411730766296e-01
    z[0,2,3]  R378      5.3503030538558960e-01
    z[0,2,3]  R379      -1.0913491994142532e-01
    z[0,2,3]  R380      -7.2018451988697052e-02
    z[0,2,3]  R381      -2.4380747228860855e-02
    z[0,2,3]  R382      2.8135562315583229e-02
    z[0,2,3]  R383      2.9551374912261963e-01
    z[0,2,3]  R384      -2.6950290799140930e-01
    z[0,2,3]  R385      0.536393404006958
    z[0,2,3]  R386      -4.9610573053359985e-01
    z[0,2,3]  R387      3.1855475902557373e-01
    z[0,2,3]  R388      2.5723496079444885e-01
    z[0,2,3]  R389      -7.3913954198360443e-02
    z[0,2,3]  R390      -0.0710030347108841
    z[0,2,3]  R391      2.6913684606552124e-01
    z[0,2,3]  R392      -4.8549634218215942e-01
    z[0,2,3]  R393      -2.1894189715385437e-01
    z[0,2,3]  R394      -3.2744863629341125e-01
    z[0,2,3]  R395      -4.1578125953674316e-01
    z[0,2,3]  R396      -9.1020818799734116e-03
    z[0,2,3]  R397      -1.1704139411449432e-01
    z[0,2,3]  R398      -2.7253192663192749e-01
    z[0,2,3]  R399      -4.1588541865348816e-01
    z[0,2,3]  R400      1.8047462403774261e-01
    z[0,2,3]  R401      1.8411104381084442e-01
    z[0,2,3]  R402      -2.1536672487854958e-02
    z[0,2,3]  R403      2.3278267681598663e-01
    z[0,2,3]  R404      -4.0269672870635986e-01
    z[0,2,3]  R405      8.3176698535680771e-03
    z[0,2,3]  R406      1.4700825512409210e-01
    z[0,2,3]  R407      -4.5856767892837524e-01
    z[0,2,3]  R408      -4.3998207896947861e-02
    z[0,2,3]  R409      1.2758034281432629e-02
    z[0,2,3]  R410      0.0983872041106224
    z[0,2,3]  R411      6.8053025007247925e-01
    z[0,2,3]  R412      -5.4386472702026367e-01
    z[0,2,3]  R413      -3.4815445542335510e-01
    z[0,2,3]  R414      -2.9917529225349426e-01
    z[0,2,3]  R415      -3.3609643578529358e-01
    z[0,2,3]  R416      -6.1731004714965820e-01
    z[0,2,3]  R417      -6.9499629735946655e-01
    z[0,2,3]  R418      -2.3235796391963959e-01
    z[0,2,3]  R419      -3.8140979409217834e-01
    z[0,2,3]  R420      -4.0274840593338013e-01
    z[0,2,3]  R421      -4.0840244293212891e-01
    z[0,2,3]  R422      -5.4294604063034058e-01
    z[0,2,3]  R423      7.1361762285232544e-01
    z[0,2,3]  R424      -2.2852474451065063e-01
    z[0,2,3]  R425      -3.5795214772224426e-01
    z[0,2,3]  R426      -2.6905605196952820e-01
    z[0,2,3]  R427      5.6580636650323868e-02
    z[0,2,4]  R6        -1
    z[0,2,4]  R24       1
    z[0,2,4]  R303      -1
    z[0,2,4]  R304      1
    z[0,2,4]  R309      -5.1024895161390305e-02
    z[0,2,4]  R310      1.3013137876987457e-01
    z[0,2,4]  R311      2.8744551539421082e-01
    z[0,2,4]  R312      -1.6588295996189117e-01
    z[0,2,4]  R313      -1.7806215584278107e-01
    z[0,2,4]  R314      -2.8135115280747414e-02
    z[0,2,4]  R315      -2.8193125128746033e-01
    z[0,2,4]  R316      3.4507939219474792e-01
    z[0,2,4]  R317      -1.3545063138008118e-01
    z[0,2,4]  R318      1.1985806375741959e-01
    z[0,2,4]  R319      1.3993303477764130e-01
    z[0,2,4]  R320      4.9991786479949951e-01
    z[0,2,4]  R321      7.4206370115280151e-01
    z[0,2,4]  R322      7.5349074602127075e-01
    z[0,2,4]  R323      -1.2462893128395081e-01
    z[0,2,4]  R324      -0.0282792616635561
    z[0,2,4]  R325      -3.6938312649726868e-01
    z[0,2,4]  R326      -2.8143274784088135e-01
    z[0,2,4]  R327      -5.2599930763244629e-01
    z[0,2,4]  R328      -2.1209090948104858e-01
    z[0,2,4]  R329      -9.3808978796005249e-02
    z[0,2,4]  R330      -2.3968910798430443e-02
    z[0,2,4]  R331      1.0132896155118942e-01
    z[0,2,4]  R332      -1.6049362719058990e-01
    z[0,2,4]  R333      1.0189700871706009e-01
    z[0,2,4]  R334      3.9138558506965637e-01
    z[0,2,4]  R335      4.0224725008010864e-01
    z[0,2,4]  R336      2.0485168695449829e-01
    z[0,2,4]  R337      -2.6626411080360413e-01
    z[0,2,4]  R338      3.0490845441818237e-01
    z[0,2,4]  R339      1.0915137827396393e-01
    z[0,2,4]  R340      7.1642078459262848e-02
    z[0,2,4]  R341      2.0457884669303894e-01
    z[0,2,4]  R342      5.7132825255393982e-02
    z[0,2,4]  R343      1.3246698677539825e-01
    z[0,2,4]  R344      -3.7669813632965088e-01
    z[0,2,4]  R345      -1.6978222131729126e-01
    z[0,2,4]  R346      -6.1717376112937927e-02
    z[0,2,4]  R347      -4.7624397277832031e-01
    z[0,2,4]  R348      -1.4507827162742615e-01
    z[0,2,4]  R349      -1.7002993822097778e-01
    z[0,2,4]  R350      -4.2550783604383469e-02
    z[0,2,4]  R351      -9.4564616680145264e-02
    z[0,2,4]  R352      1.6484777629375458e-01
    z[0,2,4]  R353      1.1954781413078308e-01
    z[0,2,4]  R354      -2.3453450202941895e-01
    z[0,2,4]  R355      -1.9616085290908813e-01
    z[0,2,4]  R356      -1.7899875342845917e-01
    z[0,2,4]  R357      -6.4933754503726959e-02
    z[0,2,4]  R358      -2.2044228017330170e-01
    z[0,2,4]  R359      3.1556585431098938e-01
    z[0,2,4]  R360      1.0745245218276978e-01
    z[0,2,4]  R361      -7.7980393543839455e-03
    z[0,2,4]  R362      -2.1471410989761353e-02
    z[0,2,4]  R363      -1.3983753323554993e-01
    z[0,2,4]  R364      -2.3936058580875397e-01
    z[0,2,4]  R365      -1.2669727206230164e-01
    z[0,2,4]  R366      1.7202737927436829e-01
    z[0,2,4]  R367      -4.1657772660255432e-01
    z[0,2,4]  R368      -2.6984393596649170e-01
    z[0,2,4]  R369      1.6780348122119904e-01
    z[0,2,4]  R370      -9.5293030142784119e-02
    z[0,2,4]  R371      -5.0396603345870972e-01
    z[0,2,4]  R372      1.4677263796329498e-01
    z[0,2,4]  R373      -3.6618176102638245e-01
    z[0,2,4]  R374      -4.2743611335754395e-01
    z[0,2,4]  R375      -2.1006008982658386e-01
    z[0,2,4]  R376      -7.2236508131027222e-01
    z[0,2,4]  R377      -0.205518439412117
    z[0,2,4]  R378      -5.8308511972427368e-01
    z[0,2,4]  R379      -5.9225648641586304e-02
    z[0,2,4]  R380      -1.6364024579524994e-01
    z[0,2,4]  R381      -2.3171067237854004e-01
    z[0,2,4]  R382      1.4094124734401703e-01
    z[0,2,4]  R383      3.2538506388664246e-01
    z[0,2,4]  R384      0.0657089427113533
    z[0,2,4]  R385      3.0613413453102112e-01
    z[0,2,4]  R386      3.8916683197021484e-01
    z[0,2,4]  R387      2.6407399773597717e-01
    z[0,2,4]  R388      1.0766576230525970e-01
    z[0,2,4]  R389      3.0829259753227234e-01
    z[0,2,4]  R390      0.542674720287323
    z[0,2,4]  R391      -3.5133257508277893e-01
    z[0,2,4]  R392      6.7589128017425537e-01
    z[0,2,4]  R393      9.3958681821823120e-01
    z[0,2,4]  R394      8.3078670501708984e-01
    z[0,2,4]  R395      7.6595938205718994e-01
    z[0,2,4]  R396      -3.4655591845512390e-01
    z[0,2,4]  R397      8.8376337289810181e-01
    z[0,2,4]  R398      6.3066780567169189e-01
    z[0,2,4]  R399      3.0546778440475464e-01
    z[0,2,4]  R400      0.541685938835144
    z[0,2,4]  R401      2.6552131772041321e-01
    z[0,2,4]  R402      5.4971385002136230e-01
    z[0,2,4]  R403      1.4752371609210968e-01
    z[0,2,4]  R404      3.7905752658843994e-01
    z[0,2,4]  R405      1.2931534647941589e-01
    z[0,2,4]  R406      -2.2250978276133537e-02
    z[0,2,4]  R407      0.729640543460846
    z[0,2,4]  R408      -6.8487298488616943e-01
    z[0,2,4]  R409      -4.5553824305534363e-01
    z[0,2,4]  R410      -4.0139034390449524e-01
    z[0,2,4]  R411      3.2666096091270447e-01
    z[0,2,4]  R412      6.5018379688262939e-01
    z[0,2,4]  R413      0.615688145160675
    z[0,2,4]  R414      6.1329811811447144e-01
    z[0,2,4]  R415      6.6873502731323242e-01
    z[0,2,4]  R416      6.3954770565032959e-01
    z[0,2,4]  R417      3.2765284180641174e-01
    z[0,2,4]  R418      6.7813855409622192e-01
    z[0,2,4]  R419      -5.0727075338363647e-01
    z[0,2,4]  R420      -3.3661961555480957e-01
    z[0,2,4]  R421      9.8570518195629120e-02
    z[0,2,4]  R422      6.1248999834060669e-01
    z[0,2,4]  R423      -3.7129085510969162e-02
    z[0,2,4]  R424      7.7158856391906738e-01
    z[0,2,4]  R425      7.6849943399429321e-01
    z[0,2,4]  R426      0.732159435749054
    z[0,2,4]  R427      5.8081064373254776e-02
    z[0,2,5]  R7        -1
    z[0,2,5]  R25       1
    z[0,2,5]  R305      -1
    z[0,2,5]  R306      1
    z[0,2,5]  R309      -2.5622516870498657e-01
    z[0,2,5]  R310      -6.9626617431640625e-01
    z[0,2,5]  R311      -7.0565515756607056e-01
    z[0,2,5]  R312      6.4109876751899719e-02
    z[0,2,5]  R313      -4.1626104712486267e-01
    z[0,2,5]  R314      1.5259596705436707e-01
    z[0,2,5]  R315      -3.7575110793113708e-01
    z[0,2,5]  R316      7.5319744646549225e-02
    z[0,2,5]  R317      1.0449462383985519e-01
    z[0,2,5]  R318      5.2294008433818817e-02
    z[0,2,5]  R319      5.3625613451004028e-01
    z[0,2,5]  R320      4.7479662299156189e-01
    z[0,2,5]  R321      1.4701986312866211e-01
    z[0,2,5]  R322      -2.7418610453605652e-01
    z[0,2,5]  R323      2.6580700278282166e-01
    z[0,2,5]  R324      1.4808274805545807e-01
    z[0,2,5]  R325      0.138405442237854
    z[0,2,5]  R326      2.3203523829579353e-02
    z[0,2,5]  R327      -9.9081307649612427e-02
    z[0,2,5]  R328      -0.170019268989563
    z[0,2,5]  R329      -1.4094074070453644e-01
    z[0,2,5]  R330      1.4805573225021362e-01
    z[0,2,5]  R331      -0.00614133570343256
    z[0,2,5]  R332      -4.6561844646930695e-02
    z[0,2,5]  R333      -2.0218789577484131e-01
    z[0,2,5]  R334      -0.070730060338974
    z[0,2,5]  R335      -0.125872403383255
    z[0,2,5]  R336      1.6337139904499054e-01
    z[0,2,5]  R337      -1.4813865534961224e-02
    z[0,2,5]  R338      5.1943007856607437e-02
    z[0,2,5]  R339      -3.0868789553642273e-01
    z[0,2,5]  R340      -2.3672723770141602e-01
    z[0,2,5]  R341      -1.9990043714642525e-02
    z[0,2,5]  R342      8.1158012151718140e-02
    z[0,2,5]  R343      7.2173632681369781e-02
    z[0,2,5]  R344      2.4948580563068390e-01
    z[0,2,5]  R345      1.4346297085285187e-01
    z[0,2,5]  R346      1.6191197931766510e-01
    z[0,2,5]  R347      1.1874933540821075e-01
    z[0,2,5]  R348      2.5968101620674133e-01
    z[0,2,5]  R349      6.2717609107494354e-03
    z[0,2,5]  R350      -9.1657042503356934e-02
    z[0,2,5]  R351      2.0332394167780876e-02
    z[0,2,5]  R352      -1.4069218933582306e-01
    z[0,2,5]  R353      3.7906490266323090e-02
    z[0,2,5]  R354      4.4746950268745422e-01
    z[0,2,5]  R355      2.4970276653766632e-01
    z[0,2,5]  R356      2.6387146115303040e-01
    z[0,2,5]  R357      1.9971735775470734e-01
    z[0,2,5]  R358      2.0439951121807098e-01
    z[0,2,5]  R359      -3.6918017268180847e-01
    z[0,2,5]  R360      -1.3579083979129791e-01
    z[0,2,5]  R361      3.4114348888397217e-01
    z[0,2,5]  R362      3.0706393718719482e-01
    z[0,2,5]  R363      -1.4180496335029602e-01
    z[0,2,5]  R364      -0.0861627534031868
    z[0,2,5]  R365      2.9993566870689392e-01
    z[0,2,5]  R366      -2.6750189065933228e-01
    z[0,2,5]  R367      6.1956298351287842e-01
    z[0,2,5]  R368      5.0050729513168335e-01
    z[0,2,5]  R369      -1.5103656053543091e-01
    z[0,2,5]  R370      -6.2295131385326385e-02
    z[0,2,5]  R371      -0.0794144868850708
    z[0,2,5]  R372      -7.3905050754547119e-02
    z[0,2,5]  R373      -0.553706169128418
    z[0,2,5]  R374      -0.50154048204422
    z[0,2,5]  R375      -8.5121077299118042e-01
    z[0,2,5]  R376      -5.6201732158660889e-01
    z[0,2,5]  R377      -6.5065312385559082e-01
    z[0,2,5]  R378      -0.338346391916275
    z[0,2,5]  R379      -8.2619205117225647e-02
    z[0,2,5]  R380      -1.1536671966314316e-01
    z[0,2,5]  R381      -1.1266986839473248e-02
    z[0,2,5]  R382      -3.0776521563529968e-01
    z[0,2,5]  R383      2.1929222345352173e-01
    z[0,2,5]  R384      4.4513073563575745e-01
    z[0,2,5]  R385      2.4503825604915619e-01
    z[0,2,5]  R386      2.3875932395458221e-01
    z[0,2,5]  R387      2.1600700914859772e-01
    z[0,2,5]  R388      3.1031739711761475e-01
    z[0,2,5]  R389      -5.0032925605773926e-01
    z[0,2,5]  R390      -6.4615093171596527e-02
    z[0,2,5]  R391      -3.0091321095824242e-03
    z[0,2,5]  R392      -9.5629818737506866e-02
    z[0,2,5]  R393      0.0893244668841362
    z[0,2,5]  R394      -2.0185333490371704e-01
    z[0,2,5]  R395      -5.3852040320634842e-02
    z[0,2,5]  R396      4.5460018515586853e-01
    z[0,2,5]  R397      1.1297465115785599e-01
    z[0,2,5]  R398      -1.1456539481878281e-01
    z[0,2,5]  R399      5.3864598274230957e-01
    z[0,2,5]  R400      -1.5818008780479431e-01
    z[0,2,5]  R401      -2.5313705205917358e-01
    z[0,2,5]  R402      3.8068592548370361e-01
    z[0,2,5]  R403      6.9146496057510376e-01
    z[0,2,5]  R404      1.8906120955944061e-01
    z[0,2,5]  R405      2.3913174867630005e-01
    z[0,2,5]  R406      2.2060884535312653e-01
    z[0,2,5]  R407      -1.7037029564380646e-01
    z[0,2,5]  R408      1.4622513949871063e-01
    z[0,2,5]  R409      -1.1423914879560471e-01
    z[0,2,5]  R410      -1.4322666823863983e-01
    z[0,2,5]  R411      -1.0807734727859497e-01
    z[0,2,5]  R412      1.5783878043293953e-02
    z[0,2,5]  R413      4.9813590943813324e-02
    z[0,2,5]  R414      -1.0862774401903152e-01
    z[0,2,5]  R415      5.8036959171295166e-01
    z[0,2,5]  R416      4.1192063689231873e-01
    z[0,2,5]  R417      5.0464153289794922e-01
    z[0,2,5]  R418      4.2999365925788879e-01
    z[0,2,5]  R419      -5.0462526082992554e-01
    z[0,2,5]  R420      -1.6671015322208405e-01
    z[0,2,5]  R421      1.7743869125843048e-01
    z[0,2,5]  R422      9.9554657936096191e-02
    z[0,2,5]  R423      2.8193006291985512e-02
    z[0,2,5]  R424      -2.9880398511886597e-01
    z[0,2,5]  R425      3.6627429723739624e-01
    z[0,2,5]  R426      -1.4255641959607601e-02
    z[0,2,5]  R427      3.4274047613143921e-01
    z[0,2,6]  R8        -1
    z[0,2,6]  R26       1
    z[0,2,6]  R307      -1
    z[0,2,6]  R308      1
    z[0,2,6]  R309      5.8988708257675171e-01
    z[0,2,6]  R310      5.1419258117675781e-01
    z[0,2,6]  R311      4.3201144784688950e-02
    z[0,2,6]  R312      -4.4612166285514832e-01
    z[0,2,6]  R313      -0.28459432721138
    z[0,2,6]  R314      1.2120986357331276e-02
    z[0,2,6]  R315      -3.1471100449562073e-01
    z[0,2,6]  R316      -2.4058060348033905e-01
    z[0,2,6]  R317      -0.128374844789505
    z[0,2,6]  R318      0.0751722976565361
    z[0,2,6]  R319      5.0954829901456833e-02
    z[0,2,6]  R320      2.2015309333801270e-01
    z[0,2,6]  R321      9.5172263681888580e-02
    z[0,2,6]  R322      -1.4934517443180084e-01
    z[0,2,6]  R323      3.6412796378135681e-01
    z[0,2,6]  R324      2.8385373950004578e-01
    z[0,2,6]  R325      -7.6482407748699188e-02
    z[0,2,6]  R326      -4.5404630899429321e-01
    z[0,2,6]  R327      7.5264692306518555e-02
    z[0,2,6]  R328      1.3915333151817322e-01
    z[0,2,6]  R329      -0.0847182348370552
    z[0,2,6]  R330      -1.1609897762537003e-01
    z[0,2,6]  R331      -2.6535862684249878e-01
    z[0,2,6]  R332      1.6977122426033020e-01
    z[0,2,6]  R333      -9.4169579446315765e-02
    z[0,2,6]  R334      -1.9882759451866150e-01
    z[0,2,6]  R335      1.2652884423732758e-01
    z[0,2,6]  R336      1.5812614560127258e-01
    z[0,2,6]  R337      1.3132725842297077e-02
    z[0,2,6]  R338      1.4832308888435364e-01
    z[0,2,6]  R339      -5.8644801378250122e-01
    z[0,2,6]  R340      -9.6080824732780457e-02
    z[0,2,6]  R341      -0.0935017317533493
    z[0,2,6]  R342      4.2079180479049683e-02
    z[0,2,6]  R343      -2.3811565339565277e-01
    z[0,2,6]  R344      1.5567111968994141e-01
    z[0,2,6]  R345      4.1509577631950378e-01
    z[0,2,6]  R346      -0.135938823223114
    z[0,2,6]  R347      2.3738507926464081e-01
    z[0,2,6]  R348      1.1658837087452412e-02
    z[0,2,6]  R349      2.8270691633224487e-01
    z[0,2,6]  R350      -4.6458322554826736e-02
    z[0,2,6]  R351      3.6631596088409424e-01
    z[0,2,6]  R352      -2.9645375907421112e-02
    z[0,2,6]  R353      4.3972063064575195e-01
    z[0,2,6]  R354      -3.2069772481918335e-01
    z[0,2,6]  R355      -4.4085553288459778e-01
    z[0,2,6]  R356      7.9573400318622589e-02
    z[0,2,6]  R357      1.6697552800178528e-01
    z[0,2,6]  R358      -0.261714369058609
    z[0,2,6]  R359      -6.3062274456024170e-01
    z[0,2,6]  R360      3.0303898453712463e-01
    z[0,2,6]  R361      8.4230154752731323e-02
    z[0,2,6]  R362      1.1596415936946869e-01
    z[0,2,6]  R363      1.8427266180515289e-01
    z[0,2,6]  R364      -1.7956189811229706e-01
    z[0,2,6]  R365      -2.8307339549064636e-01
    z[0,2,6]  R366      -8.2004763185977936e-02
    z[0,2,6]  R367      1.5848989784717560e-01
    z[0,2,6]  R368      2.1177372336387634e-01
    z[0,2,6]  R369      -2.5069481134414673e-01
    z[0,2,6]  R370      2.0381264388561249e-01
    z[0,2,6]  R371      -2.8867053985595703e-01
    z[0,2,6]  R372      3.7670439481735229e-01
    z[0,2,6]  R373      3.1335431337356567e-01
    z[0,2,6]  R374      -1.0851830244064331e-01
    z[0,2,6]  R375      4.4684566557407379e-02
    z[0,2,6]  R376      1.6724999248981476e-01
    z[0,2,6]  R377      4.3016341328620911e-01
    z[0,2,6]  R378      3.4454837441444397e-01
    z[0,2,6]  R379      -3.2937828451395035e-02
    z[0,2,6]  R380      -1.2528675794601440e-01
    z[0,2,6]  R381      6.4339734613895416e-02
    z[0,2,6]  R382      -8.2796871662139893e-02
    z[0,2,6]  R383      -1.4643880724906921e-01
    z[0,2,6]  R384      3.0713915824890137e-01
    z[0,2,6]  R385      6.8526528775691986e-02
    z[0,2,6]  R386      -1.0783251374959946e-01
    z[0,2,6]  R387      2.5204023718833923e-01
    z[0,2,6]  R388      -6.3451957702636719e-01
    z[0,2,6]  R389      3.9810085296630859e-01
    z[0,2,6]  R390      3.2346194982528687e-01
    z[0,2,6]  R391      5.4837477207183838e-01
    z[0,2,6]  R392      3.2659384608268738e-01
    z[0,2,6]  R393      -9.7096830606460571e-02
    z[0,2,6]  R394      -1.2588070333003998e-01
    z[0,2,6]  R395      -3.2313096523284912e-01
    z[0,2,6]  R396      -4.4252294301986694e-01
    z[0,2,6]  R397      -1.6365081071853638e-01
    z[0,2,6]  R398      1.5072350203990936e-01
    z[0,2,6]  R399      -1.0466154664754868e-01
    z[0,2,6]  R400      1.0212297551333904e-02
    z[0,2,6]  R401      2.6807376742362976e-01
    z[0,2,6]  R402      -1.0517653077840805e-01
    z[0,2,6]  R403      -9.1191403567790985e-02
    z[0,2,6]  R404      3.6306518316268921e-01
    z[0,2,6]  R405      4.8085975646972656e-01
    z[0,2,6]  R406      -6.9738447666168213e-01
    z[0,2,6]  R407      1.5220688283443451e-01
    z[0,2,6]  R408      1.7330373823642731e-01
    z[0,2,6]  R409      1.7091201245784760e-01
    z[0,2,6]  R410      3.7513554096221924e-01
    z[0,2,6]  R411      1.5162459574639797e-02
    z[0,2,6]  R412      -3.5503348708152771e-01
    z[0,2,6]  R413      -0.428116112947464
    z[0,2,6]  R414      -5.8395510911941528e-01
    z[0,2,6]  R415      -2.4148355424404144e-01
    z[0,2,6]  R416      1.3274788856506348e-01
    z[0,2,6]  R417      -1.6567483544349670e-02
    z[0,2,6]  R418      2.7294814586639404e-01
    z[0,2,6]  R419      3.3952745795249939e-01
    z[0,2,6]  R420      6.0924154520034790e-01
    z[0,2,6]  R421      2.6959735155105591e-01
    z[0,2,6]  R422      -1.5009182691574097e-01
    z[0,2,6]  R423      3.1779631972312927e-01
    z[0,2,6]  R424      -3.9673903584480286e-01
    z[0,2,6]  R425      5.5634602904319763e-02
    z[0,2,6]  R426      2.5438934564590454e-01
    z[0,2,6]  R427      -2.8624063730239868e-01
    z[2,0,0]  R2        1
    z[2,0,0]  R20       -1
    z[2,0,0]  R428      -1
    z[2,0,0]  R429      1
    z[2,0,0]  R442      -7.4349719285964966e-01
    z[2,0,0]  R443      -9.0440279245376587e-01
    z[2,0,0]  R444      -6.5755015611648560e-01
    z[2,0,0]  R445      -3.6882689595222473e-01
    z[2,0,0]  R446      -1.4272942207753658e-02
    z[2,0,0]  R447      4.3630054593086243e-01
    z[2,0,0]  R448      3.0258023738861084e-01
    z[2,0,0]  R449      1.9868750870227814e-01
    z[2,0,0]  R450      3.1030893325805664e-01
    z[2,0,0]  R451      2.8834110498428345e-01
    z[2,0,0]  R452      2.7444690465927124e-01
    z[2,0,0]  R453      -0.0762915164232254
    z[2,0,0]  R454      -2.3704680800437927e-01
    z[2,0,0]  R455      -0.0945655107498169
    z[2,0,0]  R456      -6.8223255872726440e-01
    z[2,0,0]  R457      -6.3873386383056641e-01
    z[2,0,0]  R458      -6.0326629877090454e-01
    z[2,0,0]  R459      -6.0984796285629272e-01
    z[2,0,0]  R460      5.6926918029785156e-01
    z[2,0,0]  R461      -5.7782799005508423e-02
    z[2,0,0]  R462      -6.3951557874679565e-01
    z[2,0,0]  R463      -6.9014227390289307e-01
    z[2,0,0]  R464      4.5249709486961365e-01
    z[2,0,0]  R465      -6.7513942718505859e-02
    z[2,0,0]  R466      -1.5221396088600159e-01
    z[2,0,0]  R467      -3.7763002514839172e-01
    z[2,0,0]  R468      -3.0197069048881531e-01
    z[2,0,0]  R469      5.5052733421325684e-01
    z[2,0,0]  R470      0.402831107378006
    z[2,0,0]  R471      0.676831066608429
    z[2,0,0]  R472      1.1956851184368134e-01
    z[2,0,0]  R473      -7.8148734569549561e-01
    z[2,0,0]  R474      6.5265917778015137e-01
    z[2,0,0]  R475      -7.2481507062911987e-01
    z[2,0,0]  R476      3.8184890151023865e-01
    z[2,0,0]  R477      4.3753212690353394e-01
    z[2,0,0]  R478      -7.1952289342880249e-01
    z[2,0,0]  R479      4.2336440086364746e-01
    z[2,0,0]  R480      -1.8188993632793427e-01
    z[2,0,0]  R481      0.668256938457489
    z[2,0,0]  R482      4.7530296444892883e-01
    z[2,0,0]  R483      7.9442560672760010e-01
    z[2,0,0]  R484      0.531466007232666
    z[2,0,0]  R485      5.7659108191728592e-02
    z[2,0,0]  R486      3.7302851676940918e-01
    z[2,0,0]  R487      1.3967619836330414e-01
    z[2,0,0]  R488      9.8253987729549408e-02
    z[2,0,0]  R489      -1.2154962867498398e-02
    z[2,0,0]  R490      3.6504435539245605e-01
    z[2,0,0]  R491      2.6145428419113159e-01
    z[2,0,0]  R492      1.4792186021804810e-01
    z[2,0,0]  R493      1.0102129727602005e-01
    z[2,0,0]  R494      -7.0512253046035767e-01
    z[2,0,0]  R495      3.8878908753395081e-01
    z[2,0,0]  R496      3.1997001171112061e-01
    z[2,0,0]  R497      2.2307321429252625e-01
    z[2,0,0]  R498      2.2730773314833641e-02
    z[2,0,0]  R499      5.2008849382400513e-01
    z[2,0,0]  R500      -2.0841567218303680e-01
    z[2,0,0]  R501      1.3831178843975067e-01
    z[2,0,0]  R502      -2.4963927268981934e-01
    z[2,0,0]  R503      1.5677075088024139e-01
    z[2,0,0]  R504      2.0215308666229248e-01
    z[2,0,0]  R505      3.3621060848236084e-01
    z[2,0,0]  R506      -3.6002430319786072e-01
    z[2,0,0]  R507      2.8251945972442627e-01
    z[2,0,0]  R508      5.3606323897838593e-02
    z[2,0,0]  R509      -2.0865032076835632e-01
    z[2,0,0]  R510      0.0792015790939331
    z[2,0,0]  R511      6.9700604677200317e-01
    z[2,0,0]  R512      4.9385523796081543e-01
    z[2,0,0]  R513      2.7884298563003540e-01
    z[2,0,0]  R514      -6.2758654356002808e-02
    z[2,0,0]  R515      4.4140231609344482e-01
    z[2,0,0]  R516      2.9204022884368896e-01
    z[2,0,0]  R517      0.0990278422832489
    z[2,0,0]  R518      5.6584876775741577e-01
    z[2,0,0]  R519      0.438368558883667
    z[2,0,0]  R520      1.2508645653724670e-01
    z[2,0,0]  R521      4.1417360305786133e-01
    z[2,0,0]  R522      4.1959103941917419e-01
    z[2,0,0]  R523      5.5644816160202026e-01
    z[2,0,0]  R524      6.3575762510299683e-01
    z[2,0,0]  R525      4.1316190361976624e-01
    z[2,0,0]  R526      3.8598445057868958e-01
    z[2,0,0]  R527      2.8113448619842529e-01
    z[2,0,0]  R528      2.4223934113979340e-01
    z[2,0,0]  R529      -3.3876141905784607e-01
    z[2,0,0]  R530      1.6936412453651428e-01
    z[2,0,0]  R531      -2.2780045866966248e-01
    z[2,0,0]  R532      5.2210664749145508e-01
    z[2,0,0]  R533      4.7280839085578918e-01
    z[2,0,0]  R534      3.7545260787010193e-01
    z[2,0,0]  R535      -4.0232321619987488e-01
    z[2,0,0]  R536      4.7286859154701233e-01
    z[2,0,0]  R537      -1.9411759078502655e-01
    z[2,0,0]  R538      9.3059904873371124e-02
    z[2,0,0]  R539      4.1530004143714905e-01
    z[2,0,0]  R540      2.9094433784484863e-01
    z[2,0,0]  R541      4.4050028920173645e-01
    z[2,0,0]  R542      -3.1407541036605835e-01
    z[2,0,0]  R543      -2.5384524837136269e-02
    z[2,0,0]  R544      1.2459943443536758e-01
    z[2,0,0]  R545      -2.3517280817031860e-01
    z[2,0,0]  R546      -5.2083592861890793e-02
    z[2,0,0]  R547      1.4811287820339203e-01
    z[2,0,0]  R548      -6.3537520170211792e-01
    z[2,0,0]  R549      -6.4471709728240967e-01
    z[2,0,0]  R550      -6.5766119956970215e-01
    z[2,0,0]  R551      1.2397421896457672e-01
    z[2,0,0]  R552      6.3077318668365479e-01
    z[2,0,0]  R553      5.0213652849197388e-01
    z[2,0,0]  R554      2.0148406922817230e-01
    z[2,0,0]  R555      -4.1290480643510818e-02
    z[2,0,0]  R556      9.4691142439842224e-02
    z[2,0,0]  R557      -2.8340309858322144e-02
    z[2,0,0]  R558      -2.4740856885910034e-01
    z[2,0,0]  R559      -3.0452784895896912e-01
    z[2,0,0]  R560      -3.8870215415954590e-01
    z[2,0,1]  R3        1
    z[2,0,1]  R21       -1
    z[2,0,1]  R430      -1
    z[2,0,1]  R431      1
    z[2,0,1]  R442      -1.6133917868137360e-01
    z[2,0,1]  R443      -1.8875263631343842e-01
    z[2,0,1]  R444      -1.4964066445827484e-01
    z[2,0,1]  R445      -6.5964251756668091e-01
    z[2,0,1]  R446      7.8889004886150360e-02
    z[2,0,1]  R447      1.8604267388582230e-02
    z[2,0,1]  R448      -1.1806106194853783e-02
    z[2,0,1]  R449      5.4581854492425919e-02
    z[2,0,1]  R450      -1.2077865749597549e-01
    z[2,0,1]  R451      5.2824807353317738e-03
    z[2,0,1]  R452      8.4847694635391235e-01
    z[2,0,1]  R453      8.0799955129623413e-01
    z[2,0,1]  R454      7.9552549123764038e-01
    z[2,0,1]  R455      8.1549555063247681e-01
    z[2,0,1]  R456      3.7019926309585571e-01
    z[2,0,1]  R457      2.2374063730239868e-01
    z[2,0,1]  R458      8.6924374103546143e-02
    z[2,0,1]  R459      3.7069177627563477e-01
    z[2,0,1]  R460      3.9249441027641296e-01
    z[2,0,1]  R461      6.4467805624008179e-01
    z[2,0,1]  R462      -1.0548141598701477e-01
    z[2,0,1]  R463      -1.2155154347419739e-01
    z[2,0,1]  R464      -5.4345929622650146e-01
    z[2,0,1]  R465      2.1160256862640381e-01
    z[2,0,1]  R466      8.4358178079128265e-02
    z[2,0,1]  R467      -4.2696982622146606e-02
    z[2,0,1]  R468      -1.6924735158681870e-02
    z[2,0,1]  R469      3.2430076599121094e-01
    z[2,0,1]  R470      3.4691080451011658e-02
    z[2,0,1]  R471      8.5422113537788391e-02
    z[2,0,1]  R472      5.7380330562591553e-01
    z[2,0,1]  R473      -1.3982464373111725e-01
    z[2,0,1]  R474      5.3358948230743408e-01
    z[2,0,1]  R475      -9.4836302101612091e-02
    z[2,0,1]  R476      0.49685138463974
    z[2,0,1]  R477      4.8165795207023621e-01
    z[2,0,1]  R478      -1.6482116281986237e-01
    z[2,0,1]  R479      4.7156643867492676e-01
    z[2,0,1]  R480      2.8162896633148193e-01
    z[2,0,1]  R481      1.7092798650264740e-01
    z[2,0,1]  R482      7.1815800666809082e-01
    z[2,0,1]  R483      -1.8876178562641144e-01
    z[2,0,1]  R484      1.4198282361030579e-01
    z[2,0,1]  R485      3.8490608334541321e-01
    z[2,0,1]  R486      4.1333901882171631e-01
    z[2,0,1]  R487      3.3508679270744324e-01
    z[2,0,1]  R488      -1.2112998217344284e-01
    z[2,0,1]  R489      -1.4878851175308228e-01
    z[2,0,1]  R490      -4.0528278797864914e-02
    z[2,0,1]  R491      -2.2516460716724396e-01
    z[2,0,1]  R492      4.0738192200660706e-01
    z[2,0,1]  R493      3.3872112631797791e-01
    z[2,0,1]  R494      2.9937621951103210e-01
    z[2,0,1]  R495      3.7586104869842529e-01
    z[2,0,1]  R496      -5.2003145217895508e-01
    z[2,0,1]  R497      2.3173166811466217e-01
    z[2,0,1]  R498      -3.7086048722267151e-01
    z[2,0,1]  R499      -5.2467468194663525e-03
    z[2,0,1]  R500      -4.5383399724960327e-01
    z[2,0,1]  R501      5.4261481761932373e-01
    z[2,0,1]  R502      1.8471740186214447e-01
    z[2,0,1]  R503      4.8204636573791504e-01
    z[2,0,1]  R504      6.2353205680847168e-01
    z[2,0,1]  R505      3.3489429950714111e-01
    z[2,0,1]  R506      -8.1334710121154785e-01
    z[2,0,1]  R507      -6.8163412809371948e-01
    z[2,0,1]  R508      -7.3793184757232666e-01
    z[2,0,1]  R509      -6.2932431697845459e-01
    z[2,0,1]  R510      -4.5561450719833374e-01
    z[2,0,1]  R511      2.6548174023628235e-01
    z[2,0,1]  R512      1.7883922159671783e-01
    z[2,0,1]  R513      2.4211584031581879e-01
    z[2,0,1]  R514      -3.7438550591468811e-01
    z[2,0,1]  R515      -6.9548559188842773e-01
    z[2,0,1]  R516      -8.1426960229873657e-01
    z[2,0,1]  R517      -8.8026142120361328e-01
    z[2,0,1]  R518      -5.5686980485916138e-01
    z[2,0,1]  R519      -6.1559689044952393e-01
    z[2,0,1]  R520      -8.6519724130630493e-01
    z[2,0,1]  R521      -7.8430545330047607e-01
    z[2,0,1]  R522      -8.8759505748748779e-01
    z[2,0,1]  R523      -7.8066098690032959e-01
    z[2,0,1]  R524      -7.2174870967864990e-01
    z[2,0,1]  R525      -0.579284131526947
    z[2,0,1]  R526      -0.739266574382782
    z[2,0,1]  R527      -7.4926763772964478e-01
    z[2,0,1]  R528      -0.616884171962738
    z[2,0,1]  R529      -8.8023918867111206e-01
    z[2,0,1]  R530      -8.8934975862503052e-01
    z[2,0,1]  R531      -6.0995358228683472e-01
    z[2,0,1]  R532      -6.6779989004135132e-01
    z[2,0,1]  R533      -5.9846210479736328e-01
    z[2,0,1]  R534      -8.5873937606811523e-01
    z[2,0,1]  R535      -4.8705798387527466e-01
    z[2,0,1]  R536      -5.8593922853469849e-01
    z[2,0,1]  R537      -8.4706974029541016e-01
    z[2,0,1]  R538      -8.3782196044921875e-01
    z[2,0,1]  R539      -7.2321790456771851e-01
    z[2,0,1]  R540      -6.1781018972396851e-01
    z[2,0,1]  R541      -8.2881647348403931e-01
    z[2,0,1]  R542      -9.0422928333282471e-01
    z[2,0,1]  R543      -9.0046817064285278e-01
    z[2,0,1]  R544      -9.6193933486938477e-01
    z[2,0,1]  R545      -0.798782229423523
    z[2,0,1]  R546      -7.6137822866439819e-01
    z[2,0,1]  R547      -4.1610002517700195e-01
    z[2,0,1]  R548      7.1338564157485962e-02
    z[2,0,1]  R549      9.2577107250690460e-02
    z[2,0,1]  R550      7.7672697603702545e-02
    z[2,0,1]  R551      -5.9112477302551270e-01
    z[2,0,1]  R552      -0.6157186627388
    z[2,0,1]  R553      -6.7031729221343994e-01
    z[2,0,1]  R554      -9.1305035352706909e-01
    z[2,0,1]  R555      -9.5023977756500244e-01
    z[2,0,1]  R556      -8.8946694135665894e-01
    z[2,0,1]  R557      -8.7520343065261841e-01
    z[2,0,1]  R558      -7.9479080438613892e-01
    z[2,0,1]  R559      0.0364716611802578
    z[2,0,1]  R560      1.9382598996162415e-01
    z[2,0,2]  R4        1
    z[2,0,2]  R22       -1
    z[2,0,2]  R432      -1
    z[2,0,2]  R433      1
    z[2,0,2]  R442      5.5405408143997192e-01
    z[2,0,2]  R443      3.0208969116210938e-01
    z[2,0,2]  R444      4.4547548890113831e-01
    z[2,0,2]  R445      4.7857272624969482e-01
    z[2,0,2]  R446      6.4202749729156494e-01
    z[2,0,2]  R447      8.1291161477565765e-02
    z[2,0,2]  R448      4.4162884354591370e-02
    z[2,0,2]  R449      -1.8790006870403886e-03
    z[2,0,2]  R450      -2.3436856269836426e-01
    z[2,0,2]  R451      -2.3957021534442902e-01
    z[2,0,2]  R452      -4.2595416307449341e-01
    z[2,0,2]  R453      -5.2947640419006348e-01
    z[2,0,2]  R454      -0.502391517162323
    z[2,0,2]  R455      -4.5143491029739380e-01
    z[2,0,2]  R456      -0.36711585521698
    z[2,0,2]  R457      -4.1537192463874817e-01
    z[2,0,2]  R458      -4.2701101303100586e-01
    z[2,0,2]  R459      -1.5642069280147552e-01
    z[2,0,2]  R460      4.9039289355278015e-01
    z[2,0,2]  R461      -6.6163659095764160e-02
    z[2,0,2]  R462      -2.6565429568290710e-01
    z[2,0,2]  R463      -3.1715756654739380e-01
    z[2,0,2]  R464      -5.7490535080432892e-02
    z[2,0,2]  R465      -3.7725567817687988e-01
    z[2,0,2]  R466      -1.4679531753063202e-01
    z[2,0,2]  R467      3.9403751492500305e-02
    z[2,0,2]  R468      2.0407268404960632e-01
    z[2,0,2]  R469      2.6282489299774170e-01
    z[2,0,2]  R470      -4.7353811562061310e-02
    z[2,0,2]  R471      -1.6353714466094971e-01
    z[2,0,2]  R472      2.9847669601440430e-01
    z[2,0,2]  R473      -1.3640609383583069e-01
    z[2,0,2]  R474      2.2130960226058960e-01
    z[2,0,2]  R475      -8.3762980997562408e-02
    z[2,0,2]  R476      2.1198947727680206e-01
    z[2,0,2]  R477      3.2118758559226990e-01
    z[2,0,2]  R478      -3.8719365000724792e-01
    z[2,0,2]  R479      2.0314460992813110e-01
    z[2,0,2]  R480      -3.0454638600349426e-01
    z[2,0,2]  R481      -4.2584415525197983e-02
    z[2,0,2]  R482      -9.1633729636669159e-02
    z[2,0,2]  R483      -3.4959834069013596e-02
    z[2,0,2]  R484      -3.4006664156913757e-01
    z[2,0,2]  R485      6.0803387314081192e-02
    z[2,0,2]  R486      6.2868803739547729e-02
    z[2,0,2]  R487      2.2307692468166351e-01
    z[2,0,2]  R488      1.4269936084747314e-01
    z[2,0,2]  R489      -1.7905475571751595e-02
    z[2,0,2]  R490      1.4066404104232788e-01
    z[2,0,2]  R491      -3.2815438508987427e-01
    z[2,0,2]  R492      -1.9858621060848236e-01
    z[2,0,2]  R493      -4.4785720109939575e-01
    z[2,0,2]  R494      -3.6400568485260010e-01
    z[2,0,2]  R495      -7.2100780904293060e-02
    z[2,0,2]  R496      -1.2152507901191711e-01
    z[2,0,2]  R497      4.7754812985658646e-02
    z[2,0,2]  R498      7.7282279729843140e-02
    z[2,0,2]  R499      -2.3688524961471558e-01
    z[2,0,2]  R500      -0.737982451915741
    z[2,0,2]  R501      4.3849232792854309e-01
    z[2,0,2]  R502      3.3853515982627869e-01
    z[2,0,2]  R503      9.4243094325065613e-02
    z[2,0,2]  R504      0.582205593585968
    z[2,0,2]  R505      3.9551305770874023e-01
    z[2,0,2]  R506      5.2726618014276028e-03
    z[2,0,2]  R507      -3.3160638064146042e-02
    z[2,0,2]  R508      1.5954692661762238e-01
    z[2,0,2]  R509      7.1214497089385986e-01
    z[2,0,2]  R510      2.3050554096698761e-01
    z[2,0,2]  R511      -3.3334669470787048e-01
    z[2,0,2]  R512      5.5639997124671936e-02
    z[2,0,2]  R513      -2.0356020331382751e-01
    z[2,0,2]  R514      -2.3002997040748596e-01
    z[2,0,2]  R515      -2.8369075059890747e-01
    z[2,0,2]  R516      3.8147693872451782e-01
    z[2,0,2]  R517      2.3826966062188148e-02
    z[2,0,2]  R518      -2.9808353632688522e-02
    z[2,0,2]  R519      -2.7991554141044617e-01
    z[2,0,2]  R520      -1.5095798298716545e-02
    z[2,0,2]  R521      -3.7754490971565247e-01
    z[2,0,2]  R522      -1.0950003750622272e-02
    z[2,0,2]  R523      2.4025326129049063e-03
    z[2,0,2]  R524      1.3460588455200195e-01
    z[2,0,2]  R525      -2.1773955225944519e-01
    z[2,0,2]  R526      -2.7437901496887207e-01
    z[2,0,2]  R527      -9.9309816956520081e-02
    z[2,0,2]  R528      -4.0018233656883240e-01
    z[2,0,2]  R529      -1.9711470603942871e-01
    z[2,0,2]  R530      -1.2846191413700581e-02
    z[2,0,2]  R531      2.4511611461639404e-01
    z[2,0,2]  R532      6.2628291547298431e-02
    z[2,0,2]  R533      1.0547447949647903e-01
    z[2,0,2]  R534      3.3033019304275513e-01
    z[2,0,2]  R535      6.6327786445617676e-01
    z[2,0,2]  R536      8.1514120101928711e-02
    z[2,0,2]  R537      -1.3852171599864960e-01
    z[2,0,2]  R538      4.2326194047927856e-01
    z[2,0,2]  R539      -4.6761423349380493e-02
    z[2,0,2]  R540      3.7887477874755859e-01
    z[2,0,2]  R541      -9.9935494363307953e-02
    z[2,0,2]  R542      1.0055445134639740e-01
    z[2,0,2]  R543      2.0335851609706879e-01
    z[2,0,2]  R544      -1.0601404309272766e-01
    z[2,0,2]  R545      -1.2080924212932587e-01
    z[2,0,2]  R546      -3.1700644642114639e-02
    z[2,0,2]  R547      -3.3466815948486328e-01
    z[2,0,2]  R548      -0.687119722366333
    z[2,0,2]  R549      -6.4685958623886108e-01
    z[2,0,2]  R550      -6.0850036144256592e-01
    z[2,0,2]  R551      2.5499412789940834e-02
    z[2,0,2]  R552      5.7227391749620438e-02
    z[2,0,2]  R553      2.2832669317722321e-01
    z[2,0,2]  R554      -1.0725231468677521e-01
    z[2,0,2]  R555      1.5175219625234604e-02
    z[2,0,2]  R556      2.7799534797668457e-01
    z[2,0,2]  R557      -1.1042208969593048e-01
    z[2,0,2]  R558      -4.4454595446586609e-01
    z[2,0,2]  R559      5.8498613536357880e-02
    z[2,0,2]  R560      -3.2437656074762344e-02
    z[2,0,3]  R5        1
    z[2,0,3]  R23       -1
    z[2,0,3]  R434      -1
    z[2,0,3]  R435      1
    z[2,0,3]  R442      1.9688328728079796e-02
    z[2,0,3]  R443      2.5863319635391235e-02
    z[2,0,3]  R444      -5.6284625083208084e-02
    z[2,0,3]  R445      -1.7577295005321503e-01
    z[2,0,3]  R446      -2.0616275072097778e-01
    z[2,0,3]  R447      5.9721589088439941e-01
    z[2,0,3]  R448      3.6833903193473816e-01
    z[2,0,3]  R449      3.0313912034034729e-01
    z[2,0,3]  R450      4.2844411730766296e-01
    z[2,0,3]  R451      5.3503030538558960e-01
    z[2,0,3]  R452      -1.0913491994142532e-01
    z[2,0,3]  R453      -7.2018451988697052e-02
    z[2,0,3]  R454      -2.4380747228860855e-02
    z[2,0,3]  R455      2.8135562315583229e-02
    z[2,0,3]  R456      2.9551374912261963e-01
    z[2,0,3]  R457      -2.6950290799140930e-01
    z[2,0,3]  R458      0.536393404006958
    z[2,0,3]  R459      -4.9610573053359985e-01
    z[2,0,3]  R460      3.1855475902557373e-01
    z[2,0,3]  R461      2.5723496079444885e-01
    z[2,0,3]  R462      -7.3913954198360443e-02
    z[2,0,3]  R463      -0.0710030347108841
    z[2,0,3]  R464      2.6913684606552124e-01
    z[2,0,3]  R465      -4.8549634218215942e-01
    z[2,0,3]  R466      -2.1894189715385437e-01
    z[2,0,3]  R467      -3.2744863629341125e-01
    z[2,0,3]  R468      -4.1578125953674316e-01
    z[2,0,3]  R469      -9.1020818799734116e-03
    z[2,0,3]  R470      -1.1704139411449432e-01
    z[2,0,3]  R471      -2.7253192663192749e-01
    z[2,0,3]  R472      -4.1588541865348816e-01
    z[2,0,3]  R473      1.8047462403774261e-01
    z[2,0,3]  R474      1.8411104381084442e-01
    z[2,0,3]  R475      -2.1536672487854958e-02
    z[2,0,3]  R476      2.3278267681598663e-01
    z[2,0,3]  R477      -4.0269672870635986e-01
    z[2,0,3]  R478      8.3176698535680771e-03
    z[2,0,3]  R479      1.4700825512409210e-01
    z[2,0,3]  R480      -4.5856767892837524e-01
    z[2,0,3]  R481      -4.3998207896947861e-02
    z[2,0,3]  R482      1.2758034281432629e-02
    z[2,0,3]  R483      0.0983872041106224
    z[2,0,3]  R484      6.8053025007247925e-01
    z[2,0,3]  R485      -5.4386472702026367e-01
    z[2,0,3]  R486      -3.4815445542335510e-01
    z[2,0,3]  R487      -2.9917529225349426e-01
    z[2,0,3]  R488      -3.3609643578529358e-01
    z[2,0,3]  R489      -6.1731004714965820e-01
    z[2,0,3]  R490      -6.9499629735946655e-01
    z[2,0,3]  R491      -2.3235796391963959e-01
    z[2,0,3]  R492      -3.8140979409217834e-01
    z[2,0,3]  R493      -4.0274840593338013e-01
    z[2,0,3]  R494      -4.0840244293212891e-01
    z[2,0,3]  R495      -5.4294604063034058e-01
    z[2,0,3]  R496      7.1361762285232544e-01
    z[2,0,3]  R497      -2.2852474451065063e-01
    z[2,0,3]  R498      -3.5795214772224426e-01
    z[2,0,3]  R499      -2.6905605196952820e-01
    z[2,0,3]  R500      5.6580636650323868e-02
    z[2,0,3]  R501      -2.7918061614036560e-01
    z[2,0,3]  R502      -1.5112577378749847e-01
    z[2,0,3]  R503      -3.8952809572219849e-01
    z[2,0,3]  R504      -2.6958325877785683e-02
    z[2,0,3]  R505      -0.576545238494873
    z[2,0,3]  R506      4.2964771389961243e-01
    z[2,0,3]  R507      3.6707094311714172e-01
    z[2,0,3]  R508      4.9446511268615723e-01
    z[2,0,3]  R509      -8.6714506149291992e-02
    z[2,0,3]  R510      8.4276819229125977e-01
    z[2,0,3]  R511      -1.5110825002193451e-01
    z[2,0,3]  R512      4.4408398866653442e-01
    z[2,0,3]  R513      4.9077352881431580e-01
    z[2,0,3]  R514      3.7115055322647095e-01
    z[2,0,3]  R515      1.4902465045452118e-01
    z[2,0,3]  R516      5.3401932120323181e-02
    z[2,0,3]  R517      -2.3090282082557678e-01
    z[2,0,3]  R518      2.8796160221099854e-01
    z[2,0,3]  R519      2.4158558249473572e-01
    z[2,0,3]  R520      -3.7723553180694580e-01
    z[2,0,3]  R521      1.8693108856678009e-01
    z[2,0,3]  R522      4.9490388482809067e-03
    z[2,0,3]  R523      -1.4407569542527199e-02
    z[2,0,3]  R524      -0.00487411767244339
    z[2,0,3]  R525      6.2143850326538086e-01
    z[2,0,3]  R526      1.7748048901557922e-01
    z[2,0,3]  R527      3.9502236247062683e-01
    z[2,0,3]  R528      5.5404853820800781e-01
    z[2,0,3]  R529      -1.6640393063426018e-02
    z[2,0,3]  R530      2.5008162856101990e-01
    z[2,0,3]  R531      0.254672646522522
    z[2,0,3]  R532      4.5510622859001160e-01
    z[2,0,3]  R533      5.9680455923080444e-01
    z[2,0,3]  R534      2.9364828020334244e-02
    z[2,0,3]  R535      2.8551253676414490e-01
    z[2,0,3]  R536      4.4502565264701843e-01
    z[2,0,3]  R537      6.2376689165830612e-02
    z[2,0,3]  R538      2.4847450852394104e-01
    z[2,0,3]  R539      7.0948116481304169e-02
    z[2,0,3]  R540      5.4908853769302368e-01
    z[2,0,3]  R541      1.2764946557581425e-02
    z[2,0,3]  R542      2.4747721850872040e-01
    z[2,0,3]  R543      6.0122460126876831e-02
    z[2,0,3]  R544      -7.7999327331781387e-03
    z[2,0,3]  R545      2.8803277015686035e-01
    z[2,0,3]  R546      2.4187400937080383e-01
    z[2,0,3]  R547      6.3066351413726807e-01
    z[2,0,3]  R548      -1.0523796826601028e-01
    z[2,0,3]  R549      2.9216054081916809e-01
    z[2,0,3]  R550      1.7974372208118439e-01
    z[2,0,3]  R551      -3.1478229910135269e-02
    z[2,0,3]  R552      3.1292641162872314e-01
    z[2,0,3]  R553      3.5052257776260376e-01
    z[2,0,3]  R554      7.7737748622894287e-02
    z[2,0,3]  R555      -1.4659301936626434e-01
    z[2,0,3]  R556      -1.6012732684612274e-01
    z[2,0,3]  R557      1.8675832450389862e-01
    z[2,0,3]  R558      3.9999779313802719e-02
    z[2,0,3]  R559      5.6568211317062378e-01
    z[2,0,3]  R560      6.6492003202438354e-01
    z[2,0,4]  R6        1
    z[2,0,4]  R24       -1
    z[2,0,4]  R436      -1
    z[2,0,4]  R437      1
    z[2,0,4]  R442      1.6780348122119904e-01
    z[2,0,4]  R443      -9.5293030142784119e-02
    z[2,0,4]  R444      -5.0396603345870972e-01
    z[2,0,4]  R445      1.4677263796329498e-01
    z[2,0,4]  R446      -3.6618176102638245e-01
    z[2,0,4]  R447      -4.2743611335754395e-01
    z[2,0,4]  R448      -2.1006008982658386e-01
    z[2,0,4]  R449      -7.2236508131027222e-01
    z[2,0,4]  R450      -0.205518439412117
    z[2,0,4]  R451      -5.8308511972427368e-01
    z[2,0,4]  R452      -5.9225648641586304e-02
    z[2,0,4]  R453      -1.6364024579524994e-01
    z[2,0,4]  R454      -2.3171067237854004e-01
    z[2,0,4]  R455      1.4094124734401703e-01
    z[2,0,4]  R456      3.2538506388664246e-01
    z[2,0,4]  R457      0.0657089427113533
    z[2,0,4]  R458      3.0613413453102112e-01
    z[2,0,4]  R459      3.8916683197021484e-01
    z[2,0,4]  R460      2.6407399773597717e-01
    z[2,0,4]  R461      1.0766576230525970e-01
    z[2,0,4]  R462      3.0829259753227234e-01
    z[2,0,4]  R463      0.542674720287323
    z[2,0,4]  R464      -3.5133257508277893e-01
    z[2,0,4]  R465      6.7589128017425537e-01
    z[2,0,4]  R466      9.3958681821823120e-01
    z[2,0,4]  R467      8.3078670501708984e-01
    z[2,0,4]  R468      7.6595938205718994e-01
    z[2,0,4]  R469      -3.4655591845512390e-01
    z[2,0,4]  R470      8.8376337289810181e-01
    z[2,0,4]  R471      6.3066780567169189e-01
    z[2,0,4]  R472      3.0546778440475464e-01
    z[2,0,4]  R473      0.541685938835144
    z[2,0,4]  R474      2.6552131772041321e-01
    z[2,0,4]  R475      5.4971385002136230e-01
    z[2,0,4]  R476      1.4752371609210968e-01
    z[2,0,4]  R477      3.7905752658843994e-01
    z[2,0,4]  R478      1.2931534647941589e-01
    z[2,0,4]  R479      -2.2250978276133537e-02
    z[2,0,4]  R480      0.729640543460846
    z[2,0,4]  R481      -6.8487298488616943e-01
    z[2,0,4]  R482      -4.5553824305534363e-01
    z[2,0,4]  R483      -4.0139034390449524e-01
    z[2,0,4]  R484      3.2666096091270447e-01
    z[2,0,4]  R485      6.5018379688262939e-01
    z[2,0,4]  R486      0.615688145160675
    z[2,0,4]  R487      6.1329811811447144e-01
    z[2,0,4]  R488      6.6873502731323242e-01
    z[2,0,4]  R489      6.3954770565032959e-01
    z[2,0,4]  R490      3.2765284180641174e-01
    z[2,0,4]  R491      6.7813855409622192e-01
    z[2,0,4]  R492      -5.0727075338363647e-01
    z[2,0,4]  R493      -3.3661961555480957e-01
    z[2,0,4]  R494      9.8570518195629120e-02
    z[2,0,4]  R495      6.1248999834060669e-01
    z[2,0,4]  R496      -3.7129085510969162e-02
    z[2,0,4]  R497      7.7158856391906738e-01
    z[2,0,4]  R498      7.6849943399429321e-01
    z[2,0,4]  R499      0.732159435749054
    z[2,0,4]  R500      5.8081064373254776e-02
    z[2,0,4]  R501      -5.1024895161390305e-02
    z[2,0,4]  R502      1.3013137876987457e-01
    z[2,0,4]  R503      2.8744551539421082e-01
    z[2,0,4]  R504      -1.6588295996189117e-01
    z[2,0,4]  R505      -1.7806215584278107e-01
    z[2,0,4]  R506      -2.8135115280747414e-02
    z[2,0,4]  R507      -2.8193125128746033e-01
    z[2,0,4]  R508      3.4507939219474792e-01
    z[2,0,4]  R509      -1.3545063138008118e-01
    z[2,0,4]  R510      1.1985806375741959e-01
    z[2,0,4]  R511      1.3993303477764130e-01
    z[2,0,4]  R512      4.9991786479949951e-01
    z[2,0,4]  R513      7.4206370115280151e-01
    z[2,0,4]  R514      7.5349074602127075e-01
    z[2,0,4]  R515      -1.2462893128395081e-01
    z[2,0,4]  R516      -0.0282792616635561
    z[2,0,4]  R517      -3.6938312649726868e-01
    z[2,0,4]  R518      -2.8143274784088135e-01
    z[2,0,4]  R519      -5.2599930763244629e-01
    z[2,0,4]  R520      -2.1209090948104858e-01
    z[2,0,4]  R521      -9.3808978796005249e-02
    z[2,0,4]  R522      -2.3968910798430443e-02
    z[2,0,4]  R523      1.0132896155118942e-01
    z[2,0,4]  R524      -1.6049362719058990e-01
    z[2,0,4]  R525      1.0189700871706009e-01
    z[2,0,4]  R526      3.9138558506965637e-01
    z[2,0,4]  R527      4.0224725008010864e-01
    z[2,0,4]  R528      2.0485168695449829e-01
    z[2,0,4]  R529      -2.6626411080360413e-01
    z[2,0,4]  R530      3.0490845441818237e-01
    z[2,0,4]  R531      1.0915137827396393e-01
    z[2,0,4]  R532      7.1642078459262848e-02
    z[2,0,4]  R533      2.0457884669303894e-01
    z[2,0,4]  R534      5.7132825255393982e-02
    z[2,0,4]  R535      1.3246698677539825e-01
    z[2,0,4]  R536      -3.7669813632965088e-01
    z[2,0,4]  R537      -1.6978222131729126e-01
    z[2,0,4]  R538      -6.1717376112937927e-02
    z[2,0,4]  R539      -4.7624397277832031e-01
    z[2,0,4]  R540      -1.4507827162742615e-01
    z[2,0,4]  R541      -1.7002993822097778e-01
    z[2,0,4]  R542      -4.2550783604383469e-02
    z[2,0,4]  R543      -9.4564616680145264e-02
    z[2,0,4]  R544      1.6484777629375458e-01
    z[2,0,4]  R545      1.1954781413078308e-01
    z[2,0,4]  R546      -2.3453450202941895e-01
    z[2,0,4]  R547      -1.9616085290908813e-01
    z[2,0,4]  R548      -1.7899875342845917e-01
    z[2,0,4]  R549      -6.4933754503726959e-02
    z[2,0,4]  R550      -2.2044228017330170e-01
    z[2,0,4]  R551      3.1556585431098938e-01
    z[2,0,4]  R552      1.0745245218276978e-01
    z[2,0,4]  R553      -7.7980393543839455e-03
    z[2,0,4]  R554      -2.1471410989761353e-02
    z[2,0,4]  R555      -1.3983753323554993e-01
    z[2,0,4]  R556      -2.3936058580875397e-01
    z[2,0,4]  R557      -1.2669727206230164e-01
    z[2,0,4]  R558      1.7202737927436829e-01
    z[2,0,4]  R559      -4.1657772660255432e-01
    z[2,0,4]  R560      -2.6984393596649170e-01
    z[2,0,5]  R7        1
    z[2,0,5]  R25       -1
    z[2,0,5]  R438      -1
    z[2,0,5]  R439      1
    z[2,0,5]  R442      -1.5103656053543091e-01
    z[2,0,5]  R443      -6.2295131385326385e-02
    z[2,0,5]  R444      -0.0794144868850708
    z[2,0,5]  R445      -7.3905050754547119e-02
    z[2,0,5]  R446      -0.553706169128418
    z[2,0,5]  R447      -0.50154048204422
    z[2,0,5]  R448      -8.5121077299118042e-01
    z[2,0,5]  R449      -5.6201732158660889e-01
    z[2,0,5]  R450      -6.5065312385559082e-01
    z[2,0,5]  R451      -0.338346391916275
    z[2,0,5]  R452      -8.2619205117225647e-02
    z[2,0,5]  R453      -1.1536671966314316e-01
    z[2,0,5]  R454      -1.1266986839473248e-02
    z[2,0,5]  R455      -3.0776521563529968e-01
    z[2,0,5]  R456      2.1929222345352173e-01
    z[2,0,5]  R457      4.4513073563575745e-01
    z[2,0,5]  R458      2.4503825604915619e-01
    z[2,0,5]  R459      2.3875932395458221e-01
    z[2,0,5]  R460      2.1600700914859772e-01
    z[2,0,5]  R461      3.1031739711761475e-01
    z[2,0,5]  R462      -5.0032925605773926e-01
    z[2,0,5]  R463      -6.4615093171596527e-02
    z[2,0,5]  R464      -3.0091321095824242e-03
    z[2,0,5]  R465      -9.5629818737506866e-02
    z[2,0,5]  R466      0.0893244668841362
    z[2,0,5]  R467      -2.0185333490371704e-01
    z[2,0,5]  R468      -5.3852040320634842e-02
    z[2,0,5]  R469      4.5460018515586853e-01
    z[2,0,5]  R470      1.1297465115785599e-01
    z[2,0,5]  R471      -1.1456539481878281e-01
    z[2,0,5]  R472      5.3864598274230957e-01
    z[2,0,5]  R473      -1.5818008780479431e-01
    z[2,0,5]  R474      -2.5313705205917358e-01
    z[2,0,5]  R475      3.8068592548370361e-01
    z[2,0,5]  R476      6.9146496057510376e-01
    z[2,0,5]  R477      1.8906120955944061e-01
    z[2,0,5]  R478      2.3913174867630005e-01
    z[2,0,5]  R479      2.2060884535312653e-01
    z[2,0,5]  R480      -1.7037029564380646e-01
    z[2,0,5]  R481      1.4622513949871063e-01
    z[2,0,5]  R482      -1.1423914879560471e-01
    z[2,0,5]  R483      -1.4322666823863983e-01
    z[2,0,5]  R484      -1.0807734727859497e-01
    z[2,0,5]  R485      1.5783878043293953e-02
    z[2,0,5]  R486      4.9813590943813324e-02
    z[2,0,5]  R487      -1.0862774401903152e-01
    z[2,0,5]  R488      5.8036959171295166e-01
    z[2,0,5]  R489      4.1192063689231873e-01
    z[2,0,5]  R490      5.0464153289794922e-01
    z[2,0,5]  R491      4.2999365925788879e-01
    z[2,0,5]  R492      -5.0462526082992554e-01
    z[2,0,5]  R493      -1.6671015322208405e-01
    z[2,0,5]  R494      1.7743869125843048e-01
    z[2,0,5]  R495      9.9554657936096191e-02
    z[2,0,5]  R496      2.8193006291985512e-02
    z[2,0,5]  R497      -2.9880398511886597e-01
    z[2,0,5]  R498      3.6627429723739624e-01
    z[2,0,5]  R499      -1.4255641959607601e-02
    z[2,0,5]  R500      3.4274047613143921e-01
    z[2,0,5]  R501      -2.5622516870498657e-01
    z[2,0,5]  R502      -6.9626617431640625e-01
    z[2,0,5]  R503      -7.0565515756607056e-01
    z[2,0,5]  R504      6.4109876751899719e-02
    z[2,0,5]  R505      -4.1626104712486267e-01
    z[2,0,5]  R506      1.5259596705436707e-01
    z[2,0,5]  R507      -3.7575110793113708e-01
    z[2,0,5]  R508      7.5319744646549225e-02
    z[2,0,5]  R509      1.0449462383985519e-01
    z[2,0,5]  R510      5.2294008433818817e-02
    z[2,0,5]  R511      5.3625613451004028e-01
    z[2,0,5]  R512      4.7479662299156189e-01
    z[2,0,5]  R513      1.4701986312866211e-01
    z[2,0,5]  R514      -2.7418610453605652e-01
    z[2,0,5]  R515      2.6580700278282166e-01
    z[2,0,5]  R516      1.4808274805545807e-01
    z[2,0,5]  R517      0.138405442237854
    z[2,0,5]  R518      2.3203523829579353e-02
    z[2,0,5]  R519      -9.9081307649612427e-02
    z[2,0,5]  R520      -0.170019268989563
    z[2,0,5]  R521      -1.4094074070453644e-01
    z[2,0,5]  R522      1.4805573225021362e-01
    z[2,0,5]  R523      -0.00614133570343256
    z[2,0,5]  R524      -4.6561844646930695e-02
    z[2,0,5]  R525      -2.0218789577484131e-01
    z[2,0,5]  R526      -0.070730060338974
    z[2,0,5]  R527      -0.125872403383255
    z[2,0,5]  R528      1.6337139904499054e-01
    z[2,0,5]  R529      -1.4813865534961224e-02
    z[2,0,5]  R530      5.1943007856607437e-02
    z[2,0,5]  R531      -3.0868789553642273e-01
    z[2,0,5]  R532      -2.3672723770141602e-01
    z[2,0,5]  R533      -1.9990043714642525e-02
    z[2,0,5]  R534      8.1158012151718140e-02
    z[2,0,5]  R535      7.2173632681369781e-02
    z[2,0,5]  R536      2.4948580563068390e-01
    z[2,0,5]  R537      1.4346297085285187e-01
    z[2,0,5]  R538      1.6191197931766510e-01
    z[2,0,5]  R539      1.1874933540821075e-01
    z[2,0,5]  R540      2.5968101620674133e-01
    z[2,0,5]  R541      6.2717609107494354e-03
    z[2,0,5]  R542      -9.1657042503356934e-02
    z[2,0,5]  R543      2.0332394167780876e-02
    z[2,0,5]  R544      -1.4069218933582306e-01
    z[2,0,5]  R545      3.7906490266323090e-02
    z[2,0,5]  R546      4.4746950268745422e-01
    z[2,0,5]  R547      2.4970276653766632e-01
    z[2,0,5]  R548      2.6387146115303040e-01
    z[2,0,5]  R549      1.9971735775470734e-01
    z[2,0,5]  R550      2.0439951121807098e-01
    z[2,0,5]  R551      -3.6918017268180847e-01
    z[2,0,5]  R552      -1.3579083979129791e-01
    z[2,0,5]  R553      3.4114348888397217e-01
    z[2,0,5]  R554      3.0706393718719482e-01
    z[2,0,5]  R555      -1.4180496335029602e-01
    z[2,0,5]  R556      -0.0861627534031868
    z[2,0,5]  R557      2.9993566870689392e-01
    z[2,0,5]  R558      -2.6750189065933228e-01
    z[2,0,5]  R559      6.1956298351287842e-01
    z[2,0,5]  R560      5.0050729513168335e-01
    z[2,0,6]  R8        1
    z[2,0,6]  R26       -1
    z[2,0,6]  R440      -1
    z[2,0,6]  R441      1
    z[2,0,6]  R442      -2.5069481134414673e-01
    z[2,0,6]  R443      2.0381264388561249e-01
    z[2,0,6]  R444      -2.8867053985595703e-01
    z[2,0,6]  R445      3.7670439481735229e-01
    z[2,0,6]  R446      3.1335431337356567e-01
    z[2,0,6]  R447      -1.0851830244064331e-01
    z[2,0,6]  R448      4.4684566557407379e-02
    z[2,0,6]  R449      1.6724999248981476e-01
    z[2,0,6]  R450      4.3016341328620911e-01
    z[2,0,6]  R451      3.4454837441444397e-01
    z[2,0,6]  R452      -3.2937828451395035e-02
    z[2,0,6]  R453      -1.2528675794601440e-01
    z[2,0,6]  R454      6.4339734613895416e-02
    z[2,0,6]  R455      -8.2796871662139893e-02
    z[2,0,6]  R456      -1.4643880724906921e-01
    z[2,0,6]  R457      3.0713915824890137e-01
    z[2,0,6]  R458      6.8526528775691986e-02
    z[2,0,6]  R459      -1.0783251374959946e-01
    z[2,0,6]  R460      2.5204023718833923e-01
    z[2,0,6]  R461      -6.3451957702636719e-01
    z[2,0,6]  R462      3.9810085296630859e-01
    z[2,0,6]  R463      3.2346194982528687e-01
    z[2,0,6]  R464      5.4837477207183838e-01
    z[2,0,6]  R465      3.2659384608268738e-01
    z[2,0,6]  R466      -9.7096830606460571e-02
    z[2,0,6]  R467      -1.2588070333003998e-01
    z[2,0,6]  R468      -3.2313096523284912e-01
    z[2,0,6]  R469      -4.4252294301986694e-01
    z[2,0,6]  R470      -1.6365081071853638e-01
    z[2,0,6]  R471      1.5072350203990936e-01
    z[2,0,6]  R472      -1.0466154664754868e-01
    z[2,0,6]  R473      1.0212297551333904e-02
    z[2,0,6]  R474      2.6807376742362976e-01
    z[2,0,6]  R475      -1.0517653077840805e-01
    z[2,0,6]  R476      -9.1191403567790985e-02
    z[2,0,6]  R477      3.6306518316268921e-01
    z[2,0,6]  R478      4.8085975646972656e-01
    z[2,0,6]  R479      -6.9738447666168213e-01
    z[2,0,6]  R480      1.5220688283443451e-01
    z[2,0,6]  R481      1.7330373823642731e-01
    z[2,0,6]  R482      1.7091201245784760e-01
    z[2,0,6]  R483      3.7513554096221924e-01
    z[2,0,6]  R484      1.5162459574639797e-02
    z[2,0,6]  R485      -3.5503348708152771e-01
    z[2,0,6]  R486      -0.428116112947464
    z[2,0,6]  R487      -5.8395510911941528e-01
    z[2,0,6]  R488      -2.4148355424404144e-01
    z[2,0,6]  R489      1.3274788856506348e-01
    z[2,0,6]  R490      -1.6567483544349670e-02
    z[2,0,6]  R491      2.7294814586639404e-01
    z[2,0,6]  R492      3.3952745795249939e-01
    z[2,0,6]  R493      6.0924154520034790e-01
    z[2,0,6]  R494      2.6959735155105591e-01
    z[2,0,6]  R495      -1.5009182691574097e-01
    z[2,0,6]  R496      3.1779631972312927e-01
    z[2,0,6]  R497      -3.9673903584480286e-01
    z[2,0,6]  R498      5.5634602904319763e-02
    z[2,0,6]  R499      2.5438934564590454e-01
    z[2,0,6]  R500      -2.8624063730239868e-01
    z[2,0,6]  R501      5.8988708257675171e-01
    z[2,0,6]  R502      5.1419258117675781e-01
    z[2,0,6]  R503      4.3201144784688950e-02
    z[2,0,6]  R504      -4.4612166285514832e-01
    z[2,0,6]  R505      -0.28459432721138
    z[2,0,6]  R506      1.2120986357331276e-02
    z[2,0,6]  R507      -3.1471100449562073e-01
    z[2,0,6]  R508      -2.4058060348033905e-01
    z[2,0,6]  R509      -0.128374844789505
    z[2,0,6]  R510      0.0751722976565361
    z[2,0,6]  R511      5.0954829901456833e-02
    z[2,0,6]  R512      2.2015309333801270e-01
    z[2,0,6]  R513      9.5172263681888580e-02
    z[2,0,6]  R514      -1.4934517443180084e-01
    z[2,0,6]  R515      3.6412796378135681e-01
    z[2,0,6]  R516      2.8385373950004578e-01
    z[2,0,6]  R517      -7.6482407748699188e-02
    z[2,0,6]  R518      -4.5404630899429321e-01
    z[2,0,6]  R519      7.5264692306518555e-02
    z[2,0,6]  R520      1.3915333151817322e-01
    z[2,0,6]  R521      -0.0847182348370552
    z[2,0,6]  R522      -1.1609897762537003e-01
    z[2,0,6]  R523      -2.6535862684249878e-01
    z[2,0,6]  R524      1.6977122426033020e-01
    z[2,0,6]  R525      -9.4169579446315765e-02
    z[2,0,6]  R526      -1.9882759451866150e-01
    z[2,0,6]  R527      1.2652884423732758e-01
    z[2,0,6]  R528      1.5812614560127258e-01
    z[2,0,6]  R529      1.3132725842297077e-02
    z[2,0,6]  R530      1.4832308888435364e-01
    z[2,0,6]  R531      -5.8644801378250122e-01
    z[2,0,6]  R532      -9.6080824732780457e-02
    z[2,0,6]  R533      -0.0935017317533493
    z[2,0,6]  R534      4.2079180479049683e-02
    z[2,0,6]  R535      -2.3811565339565277e-01
    z[2,0,6]  R536      1.5567111968994141e-01
    z[2,0,6]  R537      4.1509577631950378e-01
    z[2,0,6]  R538      -0.135938823223114
    z[2,0,6]  R539      2.3738507926464081e-01
    z[2,0,6]  R540      1.1658837087452412e-02
    z[2,0,6]  R541      2.8270691633224487e-01
    z[2,0,6]  R542      -4.6458322554826736e-02
    z[2,0,6]  R543      3.6631596088409424e-01
    z[2,0,6]  R544      -2.9645375907421112e-02
    z[2,0,6]  R545      4.3972063064575195e-01
    z[2,0,6]  R546      -3.2069772481918335e-01
    z[2,0,6]  R547      -4.4085553288459778e-01
    z[2,0,6]  R548      7.9573400318622589e-02
    z[2,0,6]  R549      1.6697552800178528e-01
    z[2,0,6]  R550      -0.261714369058609
    z[2,0,6]  R551      -6.3062274456024170e-01
    z[2,0,6]  R552      3.0303898453712463e-01
    z[2,0,6]  R553      8.4230154752731323e-02
    z[2,0,6]  R554      1.1596415936946869e-01
    z[2,0,6]  R555      1.8427266180515289e-01
    z[2,0,6]  R556      -1.7956189811229706e-01
    z[2,0,6]  R557      -2.8307339549064636e-01
    z[2,0,6]  R558      -8.2004763185977936e-02
    z[2,0,6]  R559      1.5848989784717560e-01
    z[2,0,6]  R560      2.1177372336387634e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R561      -1
    z[0,3,0]  R562      1
    z[0,3,0]  R575      1.3831178843975067e-01
    z[0,3,0]  R576      -2.4963927268981934e-01
    z[0,3,0]  R577      1.5677075088024139e-01
    z[0,3,0]  R578      2.0215308666229248e-01
    z[0,3,0]  R579      3.3621060848236084e-01
    z[0,3,0]  R580      -3.6002430319786072e-01
    z[0,3,0]  R581      2.8251945972442627e-01
    z[0,3,0]  R582      5.3606323897838593e-02
    z[0,3,0]  R583      -2.0865032076835632e-01
    z[0,3,0]  R584      0.0792015790939331
    z[0,3,0]  R585      6.9700604677200317e-01
    z[0,3,0]  R586      4.9385523796081543e-01
    z[0,3,0]  R587      2.7884298563003540e-01
    z[0,3,0]  R588      -6.2758654356002808e-02
    z[0,3,0]  R589      4.4140231609344482e-01
    z[0,3,0]  R590      2.9204022884368896e-01
    z[0,3,0]  R591      0.0990278422832489
    z[0,3,0]  R592      5.6584876775741577e-01
    z[0,3,0]  R593      0.438368558883667
    z[0,3,0]  R594      1.2508645653724670e-01
    z[0,3,0]  R595      4.1417360305786133e-01
    z[0,3,0]  R596      4.1959103941917419e-01
    z[0,3,0]  R597      5.5644816160202026e-01
    z[0,3,0]  R598      6.3575762510299683e-01
    z[0,3,0]  R599      4.1316190361976624e-01
    z[0,3,0]  R600      3.8598445057868958e-01
    z[0,3,0]  R601      2.8113448619842529e-01
    z[0,3,0]  R602      2.4223934113979340e-01
    z[0,3,0]  R603      -3.3876141905784607e-01
    z[0,3,0]  R604      1.6936412453651428e-01
    z[0,3,0]  R605      -2.2780045866966248e-01
    z[0,3,0]  R606      5.2210664749145508e-01
    z[0,3,0]  R607      4.7280839085578918e-01
    z[0,3,0]  R608      3.7545260787010193e-01
    z[0,3,0]  R609      -4.0232321619987488e-01
    z[0,3,0]  R610      4.7286859154701233e-01
    z[0,3,0]  R611      -1.9411759078502655e-01
    z[0,3,0]  R612      9.3059904873371124e-02
    z[0,3,0]  R613      4.1530004143714905e-01
    z[0,3,0]  R614      2.9094433784484863e-01
    z[0,3,0]  R615      4.4050028920173645e-01
    z[0,3,0]  R616      -3.1407541036605835e-01
    z[0,3,0]  R617      -2.5384524837136269e-02
    z[0,3,0]  R618      1.2459943443536758e-01
    z[0,3,0]  R619      -2.3517280817031860e-01
    z[0,3,0]  R620      -5.2083592861890793e-02
    z[0,3,0]  R621      1.4811287820339203e-01
    z[0,3,0]  R622      -6.3537520170211792e-01
    z[0,3,0]  R623      -6.4471709728240967e-01
    z[0,3,0]  R624      -6.5766119956970215e-01
    z[0,3,0]  R625      1.2397421896457672e-01
    z[0,3,0]  R626      6.3077318668365479e-01
    z[0,3,0]  R627      5.0213652849197388e-01
    z[0,3,0]  R628      2.0148406922817230e-01
    z[0,3,0]  R629      -4.1290480643510818e-02
    z[0,3,0]  R630      9.4691142439842224e-02
    z[0,3,0]  R631      -2.8340309858322144e-02
    z[0,3,0]  R632      -2.4740856885910034e-01
    z[0,3,0]  R633      -3.0452784895896912e-01
    z[0,3,0]  R634      -3.8870215415954590e-01
    z[0,3,0]  R635      2.5813335180282593e-01
    z[0,3,0]  R636      -9.3980008363723755e-01
    z[0,3,0]  R637      -9.2294001579284668e-01
    z[0,3,0]  R638      5.8017861843109131e-01
    z[0,3,0]  R639      -8.6002784967422485e-01
    z[0,3,0]  R640      -0.892230212688446
    z[0,3,0]  R641      -9.4262242317199707e-01
    z[0,3,0]  R642      -9.1773474216461182e-01
    z[0,3,0]  R643      -8.9749175310134888e-01
    z[0,3,0]  R644      -0.83182692527771
    z[0,3,0]  R645      5.5075997114181519e-01
    z[0,3,0]  R646      4.8558406531810760e-02
    z[0,3,0]  R647      2.1610417962074280e-01
    z[0,3,0]  R648      5.7938706874847412e-01
    z[0,3,0]  R649      1.8145748972892761e-01
    z[0,3,0]  R650      3.6470952630043030e-01
    z[0,3,0]  R651      3.6930146813392639e-01
    z[0,3,0]  R652      3.9038211107254028e-01
    z[0,3,0]  R653      2.6583820581436157e-01
    z[0,3,0]  R654      2.2130346298217773e-01
    z[0,3,0]  R655      4.6522235870361328e-01
    z[0,3,0]  R656      6.5786594152450562e-01
    z[0,3,0]  R657      4.9325266480445862e-01
    z[0,3,0]  R658      3.5619714856147766e-01
    z[0,3,0]  R659      5.5103158950805664e-01
    z[0,3,0]  R660      2.9873868823051453e-01
    z[0,3,0]  R661      -3.5717669129371643e-01
    z[0,3,0]  R662      -2.7027529478073120e-01
    z[0,3,0]  R663      -0.3973388671875
    z[0,3,0]  R664      -2.8489735722541809e-01
    z[0,3,0]  R665      6.8873858451843262e-01
    z[0,3,0]  R666      0.576435387134552
    z[0,3,0]  R667      -1.0018469393253326e-01
    z[0,3,0]  R668      6.7038416862487793e-02
    z[0,3,0]  R669      3.8674166798591614e-01
    z[0,3,0]  R670      3.9960426092147827e-01
    z[0,3,0]  R671      3.9525407552719116e-01
    z[0,3,0]  R672      3.9926269650459290e-01
    z[0,3,0]  R673      -3.9417085051536560e-01
    z[0,3,0]  R674      5.6480592489242554e-01
    z[0,3,0]  R675      5.3114473819732666e-01
    z[0,3,0]  R676      -5.3321599960327148e-02
    z[0,3,0]  R677      3.0768087506294250e-01
    z[0,3,0]  R678      1.9263944029808044e-01
    z[0,3,0]  R679      1.9228491187095642e-01
    z[0,3,0]  R680      -3.8100141286849976e-01
    z[0,3,0]  R681      5.4885959625244141e-01
    z[0,3,0]  R682      6.0691988468170166e-01
    z[0,3,0]  R683      -4.7804492712020874e-01
    z[0,3,0]  R684      3.6181899905204773e-01
    z[0,3,0]  R685      5.7915753126144409e-01
    z[0,3,0]  R686      -1.7139646410942078e-01
    z[0,3,0]  R687      2.4324850738048553e-01
    z[0,3,0]  R688      2.1458587050437927e-01
    z[0,3,0]  R689      3.3688443899154663e-01
    z[0,3,0]  R690      -1.5396653115749359e-01
    z[0,3,0]  R691      -3.9778491854667664e-01
    z[0,3,0]  R692      -5.5805152654647827e-01
    z[0,3,0]  R693      2.9693955183029175e-01
    z[0,3,0]  R694      -3.9586779475212097e-01
    z[0,3,0]  R695      3.9001861214637756e-01
    z[0,3,0]  R696      -1.1424923688173294e-01
    z[0,3,0]  R697      1.1477511376142502e-01
    z[0,3,0]  R698      3.7824258208274841e-01
    z[0,3,0]  R699      4.2572364211082458e-01
    z[0,3,0]  R700      -3.0046832561492920e-01
    z[0,3,0]  R701      -4.1631302237510681e-01
    z[0,3,0]  R702      -2.2245289757847786e-02
    z[0,3,0]  R703      -1.5044157207012177e-01
    z[0,3,0]  R704      -2.3720417916774750e-01
    z[0,3,0]  R705      -6.7189380526542664e-02
    z[0,3,0]  R706      3.3011120557785034e-01
    z[0,3,0]  R707      2.8113198280334473e-01
    z[0,3,0]  R708      -2.5362789630889893e-01
    z[0,3,0]  R709      -4.4777533411979675e-01
    z[0,3,0]  R710      2.2559408843517303e-01
    z[0,3,0]  R711      1.6263779997825623e-01
    z[0,3,0]  R712      -3.0208915472030640e-01
    z[0,3,0]  R713      -2.7314043045043945e-01
    z[0,3,0]  R714      -3.9606195688247681e-01
    z[0,3,0]  R715      3.0516144633293152e-01
    z[0,3,0]  R716      -1.5908235311508179e-01
    z[0,3,0]  R717      3.5983249545097351e-01
    z[0,3,0]  R718      4.0131369233131409e-01
    z[0,3,0]  R719      -3.1321954727172852e-01
    z[0,3,0]  R720      -2.8356176614761353e-01
    z[0,3,0]  R721      -3.0964380502700806e-01
    z[0,3,0]  R722      -3.9614996314048767e-01
    z[0,3,0]  R723      -1.2843808531761169e-01
    z[0,3,0]  R724      -2.2057932615280151e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R563      -1
    z[0,3,1]  R564      1
    z[0,3,1]  R575      5.4261481761932373e-01
    z[0,3,1]  R576      1.8471740186214447e-01
    z[0,3,1]  R577      4.8204636573791504e-01
    z[0,3,1]  R578      6.2353205680847168e-01
    z[0,3,1]  R579      3.3489429950714111e-01
    z[0,3,1]  R580      -8.1334710121154785e-01
    z[0,3,1]  R581      -6.8163412809371948e-01
    z[0,3,1]  R582      -7.3793184757232666e-01
    z[0,3,1]  R583      -6.2932431697845459e-01
    z[0,3,1]  R584      -4.5561450719833374e-01
    z[0,3,1]  R585      2.6548174023628235e-01
    z[0,3,1]  R586      1.7883922159671783e-01
    z[0,3,1]  R587      2.4211584031581879e-01
    z[0,3,1]  R588      -3.7438550591468811e-01
    z[0,3,1]  R589      -6.9548559188842773e-01
    z[0,3,1]  R590      -8.1426960229873657e-01
    z[0,3,1]  R591      -8.8026142120361328e-01
    z[0,3,1]  R592      -5.5686980485916138e-01
    z[0,3,1]  R593      -6.1559689044952393e-01
    z[0,3,1]  R594      -8.6519724130630493e-01
    z[0,3,1]  R595      -7.8430545330047607e-01
    z[0,3,1]  R596      -8.8759505748748779e-01
    z[0,3,1]  R597      -7.8066098690032959e-01
    z[0,3,1]  R598      -7.2174870967864990e-01
    z[0,3,1]  R599      -0.579284131526947
    z[0,3,1]  R600      -0.739266574382782
    z[0,3,1]  R601      -7.4926763772964478e-01
    z[0,3,1]  R602      -0.616884171962738
    z[0,3,1]  R603      -8.8023918867111206e-01
    z[0,3,1]  R604      -8.8934975862503052e-01
    z[0,3,1]  R605      -6.0995358228683472e-01
    z[0,3,1]  R606      -6.6779989004135132e-01
    z[0,3,1]  R607      -5.9846210479736328e-01
    z[0,3,1]  R608      -8.5873937606811523e-01
    z[0,3,1]  R609      -4.8705798387527466e-01
    z[0,3,1]  R610      -5.8593922853469849e-01
    z[0,3,1]  R611      -8.4706974029541016e-01
    z[0,3,1]  R612      -8.3782196044921875e-01
    z[0,3,1]  R613      -7.2321790456771851e-01
    z[0,3,1]  R614      -6.1781018972396851e-01
    z[0,3,1]  R615      -8.2881647348403931e-01
    z[0,3,1]  R616      -9.0422928333282471e-01
    z[0,3,1]  R617      -9.0046817064285278e-01
    z[0,3,1]  R618      -9.6193933486938477e-01
    z[0,3,1]  R619      -0.798782229423523
    z[0,3,1]  R620      -7.6137822866439819e-01
    z[0,3,1]  R621      -4.1610002517700195e-01
    z[0,3,1]  R622      7.1338564157485962e-02
    z[0,3,1]  R623      9.2577107250690460e-02
    z[0,3,1]  R624      7.7672697603702545e-02
    z[0,3,1]  R625      -5.9112477302551270e-01
    z[0,3,1]  R626      -0.6157186627388
    z[0,3,1]  R627      -6.7031729221343994e-01
    z[0,3,1]  R628      -9.1305035352706909e-01
    z[0,3,1]  R629      -9.5023977756500244e-01
    z[0,3,1]  R630      -8.8946694135665894e-01
    z[0,3,1]  R631      -8.7520343065261841e-01
    z[0,3,1]  R632      -7.9479080438613892e-01
    z[0,3,1]  R633      0.0364716611802578
    z[0,3,1]  R634      1.9382598996162415e-01
    z[0,3,1]  R635      4.5794308185577393e-01
    z[0,3,1]  R636      1.5471121668815613e-01
    z[0,3,1]  R637      1.6253520548343658e-01
    z[0,3,1]  R638      5.4190081357955933e-01
    z[0,3,1]  R639      1.8640153110027313e-01
    z[0,3,1]  R640      0.0975256860256195
    z[0,3,1]  R641      -9.9438624456524849e-03
    z[0,3,1]  R642      2.0124214887619019e-01
    z[0,3,1]  R643      2.0787183940410614e-01
    z[0,3,1]  R644      2.8012225031852722e-01
    z[0,3,1]  R645      4.9174398183822632e-01
    z[0,3,1]  R646      5.9860908985137939e-01
    z[0,3,1]  R647      5.6498810648918152e-02
    z[0,3,1]  R648      1.5831539034843445e-01
    z[0,3,1]  R649      2.6287177205085754e-01
    z[0,3,1]  R650      1.3917708396911621e-01
    z[0,3,1]  R651      -3.7313610315322876e-02
    z[0,3,1]  R652      -6.4909934997558594e-01
    z[0,3,1]  R653      -6.3023924827575684e-01
    z[0,3,1]  R654      -0.601081371307373
    z[0,3,1]  R655      4.8583567142486572e-01
    z[0,3,1]  R656      1.6910223662853241e-01
    z[0,3,1]  R657      3.8512364029884338e-01
    z[0,3,1]  R658      -2.4250841140747070e-01
    z[0,3,1]  R659      2.0148472487926483e-01
    z[0,3,1]  R660      5.6375807523727417e-01
    z[0,3,1]  R661      -8.8710987567901611e-01
    z[0,3,1]  R662      -8.7936633825302124e-01
    z[0,3,1]  R663      -8.4518057107925415e-01
    z[0,3,1]  R664      -8.9767938852310181e-01
    z[0,3,1]  R665      3.1527695059776306e-01
    z[0,3,1]  R666      1.0131421685218811e-01
    z[0,3,1]  R667      6.2148368358612061e-01
    z[0,3,1]  R668      6.3854932785034180e-01
    z[0,3,1]  R669      -7.8269565105438232e-01
    z[0,3,1]  R670      -7.5086838006973267e-01
    z[0,3,1]  R671      -7.9141962528228760e-01
    z[0,3,1]  R672      -8.3746296167373657e-01
    z[0,3,1]  R673      -5.1557046175003052e-01
    z[0,3,1]  R674      -6.1647754907608032e-01
    z[0,3,1]  R675      3.2905480265617371e-01
    z[0,3,1]  R676      9.5572900772094727e-01
    z[0,3,1]  R677      3.0548056960105896e-01
    z[0,3,1]  R678      1.9497880339622498e-01
    z[0,3,1]  R679      5.1851749420166016e-01
    z[0,3,1]  R680      6.3300591707229614e-01
    z[0,3,1]  R681      -0.712550163269043
    z[0,3,1]  R682      -7.5988835096359253e-01
    z[0,3,1]  R683      -7.4890685081481934e-01
    z[0,3,1]  R684      -6.0639894008636475e-01
    z[0,3,1]  R685      6.6063940525054932e-01
    z[0,3,1]  R686      7.8202486038208008e-01
    z[0,3,1]  R687      1.7261256277561188e-01
    z[0,3,1]  R688      -2.3551419377326965e-01
    z[0,3,1]  R689      -2.0627915859222412e-01
    z[0,3,1]  R690      -9.0729838609695435e-01
    z[0,3,1]  R691      -8.2229351997375488e-01
    z[0,3,1]  R692      -7.3243695497512817e-01
    z[0,3,1]  R693      -5.0932437181472778e-01
    z[0,3,1]  R694      -5.9857684373855591e-01
    z[0,3,1]  R695      -1.8179433420300484e-02
    z[0,3,1]  R696      8.6025208234786987e-01
    z[0,3,1]  R697      4.1180285811424255e-01
    z[0,3,1]  R698      -6.7911714315414429e-01
    z[0,3,1]  R699      -6.1638671159744263e-01
    z[0,3,1]  R700      -8.4821528196334839e-01
    z[0,3,1]  R701      -6.9856476783752441e-01
    z[0,3,1]  R702      -8.9396846294403076e-01
    z[0,3,1]  R703      -8.1388109922409058e-01
    z[0,3,1]  R704      -8.0397886037826538e-01
    z[0,3,1]  R705      1.1819742619991302e-02
    z[0,3,1]  R706      -7.3750841617584229e-01
    z[0,3,1]  R707      -5.9825807809829712e-01
    z[0,3,1]  R708      -0.844097912311554
    z[0,3,1]  R709      -5.0424879789352417e-01
    z[0,3,1]  R710      -6.4740163087844849e-01
    z[0,3,1]  R711      -4.7776961326599121e-01
    z[0,3,1]  R712      -5.2313446998596191e-01
    z[0,3,1]  R713      -7.1146863698959351e-01
    z[0,3,1]  R714      -0.487781286239624
    z[0,3,1]  R715      1.2014646083116531e-02
    z[0,3,1]  R716      6.5612250566482544e-01
    z[0,3,1]  R717      -6.7768466472625732e-01
    z[0,3,1]  R718      -7.2295677661895752e-01
    z[0,3,1]  R719      -8.6170834302902222e-01
    z[0,3,1]  R720      -0.867425799369812
    z[0,3,1]  R721      -4.6951338648796082e-01
    z[0,3,1]  R722      -4.7382223606109619e-01
    z[0,3,1]  R723      -9.8977647721767426e-02
    z[0,3,1]  R724      -2.1678347885608673e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R565      -1
    z[0,3,2]  R566      1
    z[0,3,2]  R575      4.3849232792854309e-01
    z[0,3,2]  R576      3.3853515982627869e-01
    z[0,3,2]  R577      9.4243094325065613e-02
    z[0,3,2]  R578      0.582205593585968
    z[0,3,2]  R579      3.9551305770874023e-01
    z[0,3,2]  R580      5.2726618014276028e-03
    z[0,3,2]  R581      -3.3160638064146042e-02
    z[0,3,2]  R582      1.5954692661762238e-01
    z[0,3,2]  R583      7.1214497089385986e-01
    z[0,3,2]  R584      2.3050554096698761e-01
    z[0,3,2]  R585      -3.3334669470787048e-01
    z[0,3,2]  R586      5.5639997124671936e-02
    z[0,3,2]  R587      -2.0356020331382751e-01
    z[0,3,2]  R588      -2.3002997040748596e-01
    z[0,3,2]  R589      -2.8369075059890747e-01
    z[0,3,2]  R590      3.8147693872451782e-01
    z[0,3,2]  R591      2.3826966062188148e-02
    z[0,3,2]  R592      -2.9808353632688522e-02
    z[0,3,2]  R593      -2.7991554141044617e-01
    z[0,3,2]  R594      -1.5095798298716545e-02
    z[0,3,2]  R595      -3.7754490971565247e-01
    z[0,3,2]  R596      -1.0950003750622272e-02
    z[0,3,2]  R597      2.4025326129049063e-03
    z[0,3,2]  R598      1.3460588455200195e-01
    z[0,3,2]  R599      -2.1773955225944519e-01
    z[0,3,2]  R600      -2.7437901496887207e-01
    z[0,3,2]  R601      -9.9309816956520081e-02
    z[0,3,2]  R602      -4.0018233656883240e-01
    z[0,3,2]  R603      -1.9711470603942871e-01
    z[0,3,2]  R604      -1.2846191413700581e-02
    z[0,3,2]  R605      2.4511611461639404e-01
    z[0,3,2]  R606      6.2628291547298431e-02
    z[0,3,2]  R607      1.0547447949647903e-01
    z[0,3,2]  R608      3.3033019304275513e-01
    z[0,3,2]  R609      6.6327786445617676e-01
    z[0,3,2]  R610      8.1514120101928711e-02
    z[0,3,2]  R611      -1.3852171599864960e-01
    z[0,3,2]  R612      4.2326194047927856e-01
    z[0,3,2]  R613      -4.6761423349380493e-02
    z[0,3,2]  R614      3.7887477874755859e-01
    z[0,3,2]  R615      -9.9935494363307953e-02
    z[0,3,2]  R616      1.0055445134639740e-01
    z[0,3,2]  R617      2.0335851609706879e-01
    z[0,3,2]  R618      -1.0601404309272766e-01
    z[0,3,2]  R619      -1.2080924212932587e-01
    z[0,3,2]  R620      -3.1700644642114639e-02
    z[0,3,2]  R621      -3.3466815948486328e-01
    z[0,3,2]  R622      -0.687119722366333
    z[0,3,2]  R623      -6.4685958623886108e-01
    z[0,3,2]  R624      -6.0850036144256592e-01
    z[0,3,2]  R625      2.5499412789940834e-02
    z[0,3,2]  R626      5.7227391749620438e-02
    z[0,3,2]  R627      2.2832669317722321e-01
    z[0,3,2]  R628      -1.0725231468677521e-01
    z[0,3,2]  R629      1.5175219625234604e-02
    z[0,3,2]  R630      2.7799534797668457e-01
    z[0,3,2]  R631      -1.1042208969593048e-01
    z[0,3,2]  R632      -4.4454595446586609e-01
    z[0,3,2]  R633      5.8498613536357880e-02
    z[0,3,2]  R634      -3.2437656074762344e-02
    z[0,3,2]  R635      4.7317445278167725e-01
    z[0,3,2]  R636      -7.1036987006664276e-02
    z[0,3,2]  R637      3.9349254220724106e-03
    z[0,3,2]  R638      6.0475575923919678e-01
    z[0,3,2]  R639      -1.0655601322650909e-01
    z[0,3,2]  R640      1.0289722681045532e-01
    z[0,3,2]  R641      -1.4623812399804592e-02
    z[0,3,2]  R642      -1.1547831445932388e-01
    z[0,3,2]  R643      2.7077925205230713e-01
    z[0,3,2]  R644      3.0057525634765625e-01
    z[0,3,2]  R645      -6.0011076927185059e-01
    z[0,3,2]  R646      -2.8771796822547913e-01
    z[0,3,2]  R647      -0.17482890188694
    z[0,3,2]  R648      5.7021718472242355e-02
    z[0,3,2]  R649      -2.6236066222190857e-01
    z[0,3,2]  R650      -2.7732434868812561e-01
    z[0,3,2]  R651      -5.6132465600967407e-02
    z[0,3,2]  R652      2.5654694437980652e-01
    z[0,3,2]  R653      -2.4898232519626617e-01
    z[0,3,2]  R654      -4.8615369945764542e-02
    z[0,3,2]  R655      -2.3697596788406372e-01
    z[0,3,2]  R656      0.478730708360672
    z[0,3,2]  R657      1.1790613085031509e-01
    z[0,3,2]  R658      1.5007908223196864e-03
    z[0,3,2]  R659      -3.0414253473281860e-01
    z[0,3,2]  R660      -4.6622648835182190e-01
    z[0,3,2]  R661      1.2217401713132858e-01
    z[0,3,2]  R662      -7.3766350746154785e-02
    z[0,3,2]  R663      8.6302056908607483e-02
    z[0,3,2]  R664      7.0185407996177673e-02
    z[0,3,2]  R665      -1.1465033888816833e-01
    z[0,3,2]  R666      -1.8005770444869995e-01
    z[0,3,2]  R667      2.2961066663265228e-01
    z[0,3,2]  R668      -5.6701207160949707e-01
    z[0,3,2]  R669      -7.0753586478531361e-03
    z[0,3,2]  R670      -4.2569848895072937e-01
    z[0,3,2]  R671      3.8507454097270966e-02
    z[0,3,2]  R672      -2.1936345100402832e-01
    z[0,3,2]  R673      -4.4113822281360626e-02
    z[0,3,2]  R674      -2.9070353507995605e-01
    z[0,3,2]  R675      3.1474274396896362e-01
    z[0,3,2]  R676      -1.3277991116046906e-01
    z[0,3,2]  R677      -2.0039129257202148e-01
    z[0,3,2]  R678      3.3667656779289246e-01
    z[0,3,2]  R679      9.5063023269176483e-02
    z[0,3,2]  R680      1.8678675591945648e-01
    z[0,3,2]  R681      -1.5000531077384949e-01
    z[0,3,2]  R682      1.4589686691761017e-01
    z[0,3,2]  R683      -1.3811717927455902e-01
    z[0,3,2]  R684      -3.2649955153465271e-01
    z[0,3,2]  R685      -7.7538035809993744e-02
    z[0,3,2]  R686      2.7904254198074341e-01
    z[0,3,2]  R687      4.6756044030189514e-01
    z[0,3,2]  R688      5.8996933698654175e-01
    z[0,3,2]  R689      3.0695015192031860e-01
    z[0,3,2]  R690      -8.3865828812122345e-02
    z[0,3,2]  R691      -0.201654851436615
    z[0,3,2]  R692      2.3760262876749039e-02
    z[0,3,2]  R693      1.9889634847640991e-01
    z[0,3,2]  R694      -4.1506299376487732e-01
    z[0,3,2]  R695      1.5373519062995911e-01
    z[0,3,2]  R696      6.0239702463150024e-02
    z[0,3,2]  R697      -2.5170063972473145e-01
    z[0,3,2]  R698      -3.9540448784828186e-01
    z[0,3,2]  R699      1.8756791949272156e-01
    z[0,3,2]  R700      -1.8159843981266022e-01
    z[0,3,2]  R701      -1.4692538976669312e-01
    z[0,3,2]  R702      2.8810954093933105e-01
    z[0,3,2]  R703      0.518994152545929
    z[0,3,2]  R704      -7.1790322661399841e-02
    z[0,3,2]  R705      2.0671610534191132e-01
    z[0,3,2]  R706      -2.9173594713211060e-01
    z[0,3,2]  R707      -2.5543960928916931e-01
    z[0,3,2]  R708      -2.7297517657279968e-01
    z[0,3,2]  R709      -4.6042707562446594e-01
    z[0,3,2]  R710      1.2205547094345093e-01
    z[0,3,2]  R711      -1.7233356833457947e-01
    z[0,3,2]  R712      -0.463856041431427
    z[0,3,2]  R713      -0.343553364276886
    z[0,3,2]  R714      -5.5767357349395752e-01
    z[0,3,2]  R715      2.7804297208786011e-01
    z[0,3,2]  R716      -6.2095586210489273e-02
    z[0,3,2]  R717      -2.0334620773792267e-01
    z[0,3,2]  R718      -4.3719375133514404e-01
    z[0,3,2]  R719      -3.4538358449935913e-01
    z[0,3,2]  R720      2.2523038089275360e-01
    z[0,3,2]  R721      -1.1186144500970840e-01
    z[0,3,2]  R722      -2.3457500338554382e-01
    z[0,3,2]  R723      -3.6460712552070618e-01
    z[0,3,2]  R724      -7.4643462896347046e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R567      -1
    z[0,3,3]  R568      1
    z[0,3,3]  R575      -2.7918061614036560e-01
    z[0,3,3]  R576      -1.5112577378749847e-01
    z[0,3,3]  R577      -3.8952809572219849e-01
    z[0,3,3]  R578      -2.6958325877785683e-02
    z[0,3,3]  R579      -0.576545238494873
    z[0,3,3]  R580      4.2964771389961243e-01
    z[0,3,3]  R581      3.6707094311714172e-01
    z[0,3,3]  R582      4.9446511268615723e-01
    z[0,3,3]  R583      -8.6714506149291992e-02
    z[0,3,3]  R584      8.4276819229125977e-01
    z[0,3,3]  R585      -1.5110825002193451e-01
    z[0,3,3]  R586      4.4408398866653442e-01
    z[0,3,3]  R587      4.9077352881431580e-01
    z[0,3,3]  R588      3.7115055322647095e-01
    z[0,3,3]  R589      1.4902465045452118e-01
    z[0,3,3]  R590      5.3401932120323181e-02
    z[0,3,3]  R591      -2.3090282082557678e-01
    z[0,3,3]  R592      2.8796160221099854e-01
    z[0,3,3]  R593      2.4158558249473572e-01
    z[0,3,3]  R594      -3.7723553180694580e-01
    z[0,3,3]  R595      1.8693108856678009e-01
    z[0,3,3]  R596      4.9490388482809067e-03
    z[0,3,3]  R597      -1.4407569542527199e-02
    z[0,3,3]  R598      -0.00487411767244339
    z[0,3,3]  R599      6.2143850326538086e-01
    z[0,3,3]  R600      1.7748048901557922e-01
    z[0,3,3]  R601      3.9502236247062683e-01
    z[0,3,3]  R602      5.5404853820800781e-01
    z[0,3,3]  R603      -1.6640393063426018e-02
    z[0,3,3]  R604      2.5008162856101990e-01
    z[0,3,3]  R605      0.254672646522522
    z[0,3,3]  R606      4.5510622859001160e-01
    z[0,3,3]  R607      5.9680455923080444e-01
    z[0,3,3]  R608      2.9364828020334244e-02
    z[0,3,3]  R609      2.8551253676414490e-01
    z[0,3,3]  R610      4.4502565264701843e-01
    z[0,3,3]  R611      6.2376689165830612e-02
    z[0,3,3]  R612      2.4847450852394104e-01
    z[0,3,3]  R613      7.0948116481304169e-02
    z[0,3,3]  R614      5.4908853769302368e-01
    z[0,3,3]  R615      1.2764946557581425e-02
    z[0,3,3]  R616      2.4747721850872040e-01
    z[0,3,3]  R617      6.0122460126876831e-02
    z[0,3,3]  R618      -7.7999327331781387e-03
    z[0,3,3]  R619      2.8803277015686035e-01
    z[0,3,3]  R620      2.4187400937080383e-01
    z[0,3,3]  R621      6.3066351413726807e-01
    z[0,3,3]  R622      -1.0523796826601028e-01
    z[0,3,3]  R623      2.9216054081916809e-01
    z[0,3,3]  R624      1.7974372208118439e-01
    z[0,3,3]  R625      -3.1478229910135269e-02
    z[0,3,3]  R626      3.1292641162872314e-01
    z[0,3,3]  R627      3.5052257776260376e-01
    z[0,3,3]  R628      7.7737748622894287e-02
    z[0,3,3]  R629      -1.4659301936626434e-01
    z[0,3,3]  R630      -1.6012732684612274e-01
    z[0,3,3]  R631      1.8675832450389862e-01
    z[0,3,3]  R632      3.9999779313802719e-02
    z[0,3,3]  R633      5.6568211317062378e-01
    z[0,3,3]  R634      6.6492003202438354e-01
    z[0,3,3]  R635      -3.7363407015800476e-01
    z[0,3,3]  R636      -2.3972152173519135e-01
    z[0,3,3]  R637      -1.9779071211814880e-01
    z[0,3,3]  R638      -7.7056130394339561e-03
    z[0,3,3]  R639      -2.0588600635528564e-01
    z[0,3,3]  R640      3.0438458546996117e-02
    z[0,3,3]  R641      -8.3044849336147308e-02
    z[0,3,3]  R642      2.4156817793846130e-01
    z[0,3,3]  R643      9.3204446136951447e-02
    z[0,3,3]  R644      -1.8220625817775726e-01
    z[0,3,3]  R645      -2.1709744632244110e-01
    z[0,3,3]  R646      4.2003658413887024e-01
    z[0,3,3]  R647      -6.1917316913604736e-01
    z[0,3,3]  R648      -2.4185305833816528e-01
    z[0,3,3]  R649      -4.7418147325515747e-01
    z[0,3,3]  R650      -3.5897254943847656e-01
    z[0,3,3]  R651      -6.7649924755096436e-01
    z[0,3,3]  R652      5.8192396163940430e-01
    z[0,3,3]  R653      5.5674391984939575e-01
    z[0,3,3]  R654      6.7789024114608765e-01
    z[0,3,3]  R655      -1.2351523339748383e-01
    z[0,3,3]  R656      -3.7697765231132507e-01
    z[0,3,3]  R657      -3.9568236470222473e-01
    z[0,3,3]  R658      -4.5480468869209290e-01
    z[0,3,3]  R659      -1.4198586344718933e-01
    z[0,3,3]  R660      -3.2391302287578583e-02
    z[0,3,3]  R661      -7.1297824382781982e-02
    z[0,3,3]  R662      -1.7052255570888519e-01
    z[0,3,3]  R663      -1.3055598735809326e-01
    z[0,3,3]  R664      1.0369133204221725e-01
    z[0,3,3]  R665      -5.6572878360748291e-01
    z[0,3,3]  R666      -6.1591309309005737e-01
    z[0,3,3]  R667      6.7653483152389526e-01
    z[0,3,3]  R668      -1.1923617124557495e-01
    z[0,3,3]  R669      3.2390314340591431e-01
    z[0,3,3]  R670      3.9310574531555176e-02
    z[0,3,3]  R671      1.3593333959579468e-01
    z[0,3,3]  R672      -1.6196319460868835e-01
    z[0,3,3]  R673      5.8970528841018677e-01
    z[0,3,3]  R674      3.8669671863317490e-02
    z[0,3,3]  R675      -1.9893029239028692e-03
    z[0,3,3]  R676      1.4506794512271881e-01
    z[0,3,3]  R677      -2.7058762311935425e-01
    z[0,3,3]  R678      -5.8655035495758057e-01
    z[0,3,3]  R679      -4.3224066495895386e-02
    z[0,3,3]  R680      3.6754816770553589e-01
    z[0,3,3]  R681      3.5326120257377625e-01
    z[0,3,3]  R682      2.2708898410201073e-02
    z[0,3,3]  R683      2.7809518575668335e-01
    z[0,3,3]  R684      2.4823831021785736e-01
    z[0,3,3]  R685      -2.7817955613136292e-01
    z[0,3,3]  R686      -3.7966978549957275e-01
    z[0,3,3]  R687      -5.1656246185302734e-01
    z[0,3,3]  R688      -7.2383642196655273e-01
    z[0,3,3]  R689      -4.3253010511398315e-01
    z[0,3,3]  R690      -3.0411076545715332e-01
    z[0,3,3]  R691      -5.1381520926952362e-02
    z[0,3,3]  R692      2.3650184273719788e-01
    z[0,3,3]  R693      5.2529340982437134e-01
    z[0,3,3]  R694      2.6098170876502991e-01
    z[0,3,3]  R695      -7.0872771739959717e-01
    z[0,3,3]  R696      2.3492148146033287e-02
    z[0,3,3]  R697      -5.7568907737731934e-01
    z[0,3,3]  R698      2.0097626373171806e-02
    z[0,3,3]  R699      3.1200775504112244e-01
    z[0,3,3]  R700      -3.1716406345367432e-01
    z[0,3,3]  R701      0.325791597366333
    z[0,3,3]  R702      -1.7388641834259033e-01
    z[0,3,3]  R703      -3.3776730298995972e-02
    z[0,3,3]  R704      -9.5977261662483215e-02
    z[0,3,3]  R705      -7.8665858507156372e-01
    z[0,3,3]  R706      3.5539820790290833e-01
    z[0,3,3]  R707      5.0124150514602661e-01
    z[0,3,3]  R708      -1.1464725248515606e-02
    z[0,3,3]  R709      4.6107214689254761e-01
    z[0,3,3]  R710      4.3256533145904541e-01
    z[0,3,3]  R711      6.0782027244567871e-01
    z[0,3,3]  R712      1.7142720520496368e-01
    z[0,3,3]  R713      3.2900744676589966e-01
    z[0,3,3]  R714      -7.7450558543205261e-02
    z[0,3,3]  R715      -6.4688611030578613e-01
    z[0,3,3]  R716      3.6693942546844482e-01
    z[0,3,3]  R717      0.519483745098114
    z[0,3,3]  R718      5.1869828253984451e-02
    z[0,3,3]  R719      1.3376979529857635e-01
    z[0,3,3]  R720      1.4833371341228485e-01
    z[0,3,3]  R721      4.6653857827186584e-01
    z[0,3,3]  R722      1.1839896440505981e-01
    z[0,3,3]  R723      6.3796001672744751e-01
    z[0,3,3]  R724      2.9312953352928162e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R569      -1
    z[0,3,4]  R570      1
    z[0,3,4]  R575      -5.1024895161390305e-02
    z[0,3,4]  R576      1.3013137876987457e-01
    z[0,3,4]  R577      2.8744551539421082e-01
    z[0,3,4]  R578      -1.6588295996189117e-01
    z[0,3,4]  R579      -1.7806215584278107e-01
    z[0,3,4]  R580      -2.8135115280747414e-02
    z[0,3,4]  R581      -2.8193125128746033e-01
    z[0,3,4]  R582      3.4507939219474792e-01
    z[0,3,4]  R583      -1.3545063138008118e-01
    z[0,3,4]  R584      1.1985806375741959e-01
    z[0,3,4]  R585      1.3993303477764130e-01
    z[0,3,4]  R586      4.9991786479949951e-01
    z[0,3,4]  R587      7.4206370115280151e-01
    z[0,3,4]  R588      7.5349074602127075e-01
    z[0,3,4]  R589      -1.2462893128395081e-01
    z[0,3,4]  R590      -0.0282792616635561
    z[0,3,4]  R591      -3.6938312649726868e-01
    z[0,3,4]  R592      -2.8143274784088135e-01
    z[0,3,4]  R593      -5.2599930763244629e-01
    z[0,3,4]  R594      -2.1209090948104858e-01
    z[0,3,4]  R595      -9.3808978796005249e-02
    z[0,3,4]  R596      -2.3968910798430443e-02
    z[0,3,4]  R597      1.0132896155118942e-01
    z[0,3,4]  R598      -1.6049362719058990e-01
    z[0,3,4]  R599      1.0189700871706009e-01
    z[0,3,4]  R600      3.9138558506965637e-01
    z[0,3,4]  R601      4.0224725008010864e-01
    z[0,3,4]  R602      2.0485168695449829e-01
    z[0,3,4]  R603      -2.6626411080360413e-01
    z[0,3,4]  R604      3.0490845441818237e-01
    z[0,3,4]  R605      1.0915137827396393e-01
    z[0,3,4]  R606      7.1642078459262848e-02
    z[0,3,4]  R607      2.0457884669303894e-01
    z[0,3,4]  R608      5.7132825255393982e-02
    z[0,3,4]  R609      1.3246698677539825e-01
    z[0,3,4]  R610      -3.7669813632965088e-01
    z[0,3,4]  R611      -1.6978222131729126e-01
    z[0,3,4]  R612      -6.1717376112937927e-02
    z[0,3,4]  R613      -4.7624397277832031e-01
    z[0,3,4]  R614      -1.4507827162742615e-01
    z[0,3,4]  R615      -1.7002993822097778e-01
    z[0,3,4]  R616      -4.2550783604383469e-02
    z[0,3,4]  R617      -9.4564616680145264e-02
    z[0,3,4]  R618      1.6484777629375458e-01
    z[0,3,4]  R619      1.1954781413078308e-01
    z[0,3,4]  R620      -2.3453450202941895e-01
    z[0,3,4]  R621      -1.9616085290908813e-01
    z[0,3,4]  R622      -1.7899875342845917e-01
    z[0,3,4]  R623      -6.4933754503726959e-02
    z[0,3,4]  R624      -2.2044228017330170e-01
    z[0,3,4]  R625      3.1556585431098938e-01
    z[0,3,4]  R626      1.0745245218276978e-01
    z[0,3,4]  R627      -7.7980393543839455e-03
    z[0,3,4]  R628      -2.1471410989761353e-02
    z[0,3,4]  R629      -1.3983753323554993e-01
    z[0,3,4]  R630      -2.3936058580875397e-01
    z[0,3,4]  R631      -1.2669727206230164e-01
    z[0,3,4]  R632      1.7202737927436829e-01
    z[0,3,4]  R633      -4.1657772660255432e-01
    z[0,3,4]  R634      -2.6984393596649170e-01
    z[0,3,4]  R635      3.4899908304214478e-01
    z[0,3,4]  R636      1.3045790791511536e-01
    z[0,3,4]  R637      6.4899399876594543e-02
    z[0,3,4]  R638      5.2281104028224945e-02
    z[0,3,4]  R639      -2.7794393897056580e-01
    z[0,3,4]  R640      -4.3862383812665939e-02
    z[0,3,4]  R641      -3.0529299378395081e-01
    z[0,3,4]  R642      -0.0504038967192173
    z[0,3,4]  R643      1.9112777709960938e-01
    z[0,3,4]  R644      -4.1402861475944519e-02
    z[0,3,4]  R645      -3.5263508558273315e-02
    z[0,3,4]  R646      2.8810936212539673e-01
    z[0,3,4]  R647      -6.4258921146392822e-01
    z[0,3,4]  R648      -5.0122499465942383e-01
    z[0,3,4]  R649      -7.5447636842727661e-01
    z[0,3,4]  R650      -4.3736043572425842e-01
    z[0,3,4]  R651      -2.8554555773735046e-01
    z[0,3,4]  R652      -1.3387228548526764e-01
    z[0,3,4]  R653      3.9674103260040283e-01
    z[0,3,4]  R654      -1.8834735453128815e-01
    z[0,3,4]  R655      1.6314629465341568e-02
    z[0,3,4]  R656      3.4935045987367630e-02
    z[0,3,4]  R657      -5.6127011775970459e-01
    z[0,3,4]  R658      6.2418907880783081e-01
    z[0,3,4]  R659      0.508728563785553
    z[0,3,4]  R660      5.9628438949584961e-01
    z[0,3,4]  R661      -9.6647582948207855e-02
    z[0,3,4]  R662      -2.8975948691368103e-01
    z[0,3,4]  R663      -1.2747314572334290e-01
    z[0,3,4]  R664      2.3188865184783936e-01
    z[0,3,4]  R665      -6.5716892480850220e-02
    z[0,3,4]  R666      8.0855533480644226e-02
    z[0,3,4]  R667      -3.2234955579042435e-02
    z[0,3,4]  R668      -2.5378465652465820e-01
    z[0,3,4]  R669      2.8136804699897766e-01
    z[0,3,4]  R670      -1.0198257118463516e-01
    z[0,3,4]  R671      -1.1463674902915955e-01
    z[0,3,4]  R672      1.7112898826599121e-01
    z[0,3,4]  R673      -2.5380682945251465e-01
    z[0,3,4]  R674      9.4268575310707092e-02
    z[0,3,4]  R675      6.5625023841857910e-01
    z[0,3,4]  R676      -1.6640214622020721e-01
    z[0,3,4]  R677      5.1289498805999756e-01
    z[0,3,4]  R678      -4.8925641179084778e-01
    z[0,3,4]  R679      2.7319782972335815e-01
    z[0,3,4]  R680      2.0046363770961761e-01
    z[0,3,4]  R681      -1.7939563095569611e-01
    z[0,3,4]  R682      7.3708340525627136e-02
    z[0,3,4]  R683      -2.0611342787742615e-01
    z[0,3,4]  R684      1.1279787868261337e-01
    z[0,3,4]  R685      2.5928923487663269e-01
    z[0,3,4]  R686      1.6672702133655548e-01
    z[0,3,4]  R687      -4.0130406618118286e-01
    z[0,3,4]  R688      -5.1522977650165558e-02
    z[0,3,4]  R689      4.1288143396377563e-01
    z[0,3,4]  R690      -8.2583807408809662e-02
    z[0,3,4]  R691      8.4618858993053436e-02
    z[0,3,4]  R692      1.7774626612663269e-01
    z[0,3,4]  R693      2.6971861720085144e-02
    z[0,3,4]  R694      3.5232746601104736e-01
    z[0,3,4]  R695      5.6551039218902588e-01
    z[0,3,4]  R696      1.7291894555091858e-01
    z[0,3,4]  R697      -3.7263345718383789e-01
    z[0,3,4]  R698      -1.6487531363964081e-01
    z[0,3,4]  R699      -3.3342546224594116e-01
    z[0,3,4]  R700      2.2124059498310089e-01
    z[0,3,4]  R701      1.4005471765995026e-01
    z[0,3,4]  R702      2.7248656749725342e-01
    z[0,3,4]  R703      -3.3528175204992294e-02
    z[0,3,4]  R704      1.4610594511032104e-01
    z[0,3,4]  R705      -1.8471702933311462e-02
    z[0,3,4]  R706      -7.2325021028518677e-02
    z[0,3,4]  R707      -2.2511104121804237e-02
    z[0,3,4]  R708      1.9403712451457977e-01
    z[0,3,4]  R709      1.2670768797397614e-01
    z[0,3,4]  R710      -0.0792994499206543
    z[0,3,4]  R711      -2.1422253549098969e-01
    z[0,3,4]  R712      2.0323148369789124e-01
    z[0,3,4]  R713      1.4503178000450134e-01
    z[0,3,4]  R714      -3.4546792507171631e-01
    z[0,3,4]  R715      -1.3877657055854797e-01
    z[0,3,4]  R716      4.0217930078506470e-01
    z[0,3,4]  R717      -3.1700424849987030e-02
    z[0,3,4]  R718      2.9526901245117188e-01
    z[0,3,4]  R719      -5.3333666175603867e-02
    z[0,3,4]  R720      1.0146160423755646e-01
    z[0,3,4]  R721      -1.7991612851619720e-01
    z[0,3,4]  R722      -1.6010677814483643e-01
    z[0,3,4]  R723      -3.0307593941688538e-01
    z[0,3,4]  R724      -2.7151322364807129e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R571      -1
    z[0,3,5]  R572      1
    z[0,3,5]  R575      -2.5622516870498657e-01
    z[0,3,5]  R576      -6.9626617431640625e-01
    z[0,3,5]  R577      -7.0565515756607056e-01
    z[0,3,5]  R578      6.4109876751899719e-02
    z[0,3,5]  R579      -4.1626104712486267e-01
    z[0,3,5]  R580      1.5259596705436707e-01
    z[0,3,5]  R581      -3.7575110793113708e-01
    z[0,3,5]  R582      7.5319744646549225e-02
    z[0,3,5]  R583      1.0449462383985519e-01
    z[0,3,5]  R584      5.2294008433818817e-02
    z[0,3,5]  R585      5.3625613451004028e-01
    z[0,3,5]  R586      4.7479662299156189e-01
    z[0,3,5]  R587      1.4701986312866211e-01
    z[0,3,5]  R588      -2.7418610453605652e-01
    z[0,3,5]  R589      2.6580700278282166e-01
    z[0,3,5]  R590      1.4808274805545807e-01
    z[0,3,5]  R591      0.138405442237854
    z[0,3,5]  R592      2.3203523829579353e-02
    z[0,3,5]  R593      -9.9081307649612427e-02
    z[0,3,5]  R594      -0.170019268989563
    z[0,3,5]  R595      -1.4094074070453644e-01
    z[0,3,5]  R596      1.4805573225021362e-01
    z[0,3,5]  R597      -0.00614133570343256
    z[0,3,5]  R598      -4.6561844646930695e-02
    z[0,3,5]  R599      -2.0218789577484131e-01
    z[0,3,5]  R600      -0.070730060338974
    z[0,3,5]  R601      -0.125872403383255
    z[0,3,5]  R602      1.6337139904499054e-01
    z[0,3,5]  R603      -1.4813865534961224e-02
    z[0,3,5]  R604      5.1943007856607437e-02
    z[0,3,5]  R605      -3.0868789553642273e-01
    z[0,3,5]  R606      -2.3672723770141602e-01
    z[0,3,5]  R607      -1.9990043714642525e-02
    z[0,3,5]  R608      8.1158012151718140e-02
    z[0,3,5]  R609      7.2173632681369781e-02
    z[0,3,5]  R610      2.4948580563068390e-01
    z[0,3,5]  R611      1.4346297085285187e-01
    z[0,3,5]  R612      1.6191197931766510e-01
    z[0,3,5]  R613      1.1874933540821075e-01
    z[0,3,5]  R614      2.5968101620674133e-01
    z[0,3,5]  R615      6.2717609107494354e-03
    z[0,3,5]  R616      -9.1657042503356934e-02
    z[0,3,5]  R617      2.0332394167780876e-02
    z[0,3,5]  R618      -1.4069218933582306e-01
    z[0,3,5]  R619      3.7906490266323090e-02
    z[0,3,5]  R620      4.4746950268745422e-01
    z[0,3,5]  R621      2.4970276653766632e-01
    z[0,3,5]  R622      2.6387146115303040e-01
    z[0,3,5]  R623      1.9971735775470734e-01
    z[0,3,5]  R624      2.0439951121807098e-01
    z[0,3,5]  R625      -3.6918017268180847e-01
    z[0,3,5]  R626      -1.3579083979129791e-01
    z[0,3,5]  R627      3.4114348888397217e-01
    z[0,3,5]  R628      3.0706393718719482e-01
    z[0,3,5]  R629      -1.4180496335029602e-01
    z[0,3,5]  R630      -0.0861627534031868
    z[0,3,5]  R631      2.9993566870689392e-01
    z[0,3,5]  R632      -2.6750189065933228e-01
    z[0,3,5]  R633      6.1956298351287842e-01
    z[0,3,5]  R634      5.0050729513168335e-01
    z[0,3,5]  R635      -4.8548573255538940e-01
    z[0,3,5]  R636      6.3925251364707947e-02
    z[0,3,5]  R637      -1.3533490896224976e-01
    z[0,3,5]  R638      -2.9999520629644394e-02
    z[0,3,5]  R639      -2.9029190540313721e-01
    z[0,3,5]  R640      -4.2483350634574890e-01
    z[0,3,5]  R641      -4.1109815239906311e-02
    z[0,3,5]  R642      -0.0789119228720665
    z[0,3,5]  R643      0.00739058293402195
    z[0,3,5]  R644      -2.2993431985378265e-01
    z[0,3,5]  R645      2.0528608560562134e-01
    z[0,3,5]  R646      -2.4083724617958069e-01
    z[0,3,5]  R647      -1.9655372202396393e-01
    z[0,3,5]  R648      1.6232709586620331e-01
    z[0,3,5]  R649      -1.7088063061237335e-01
    z[0,3,5]  R650      -0.0994378998875618
    z[0,3,5]  R651      2.9747176170349121e-01
    z[0,3,5]  R652      -5.1031500101089478e-02
    z[0,3,5]  R653      -4.4756412506103516e-02
    z[0,3,5]  R654      2.6538664102554321e-01
    z[0,3,5]  R655      -2.2161072492599487e-01
    z[0,3,5]  R656      8.1138901412487030e-02
    z[0,3,5]  R657      1.0783676803112030e-01
    z[0,3,5]  R658      1.5114578604698181e-01
    z[0,3,5]  R659      4.8304149508476257e-01
    z[0,3,5]  R660      -1.2417440861463547e-01
    z[0,3,5]  R661      -5.2974302321672440e-02
    z[0,3,5]  R662      1.1111255735158920e-02
    z[0,3,5]  R663      -8.2784526050090790e-02
    z[0,3,5]  R664      1.1146222800016403e-01
    z[0,3,5]  R665      0.251359224319458
    z[0,3,5]  R666      4.1499685496091843e-02
    z[0,3,5]  R667      -2.8766372799873352e-01
    z[0,3,5]  R668      -4.3079584836959839e-01
    z[0,3,5]  R669      2.2054976224899292e-01
    z[0,3,5]  R670      -1.4317522943019867e-01
    z[0,3,5]  R671      4.1190677881240845e-01
    z[0,3,5]  R672      1.5191332995891571e-01
    z[0,3,5]  R673      3.1151914596557617e-01
    z[0,3,5]  R674      3.9414763450622559e-01
    z[0,3,5]  R675      2.2859179973602295e-01
    z[0,3,5]  R676      -1.1515405774116516e-01
    z[0,3,5]  R677      -3.2339328527450562e-01
    z[0,3,5]  R678      -1.7447908222675323e-01
    z[0,3,5]  R679      -2.9478749260306358e-02
    z[0,3,5]  R680      0.340032160282135
    z[0,3,5]  R681      1.0683614015579224e-01
    z[0,3,5]  R682      -1.3590057194232941e-01
    z[0,3,5]  R683      -2.6704284548759460e-01
    z[0,3,5]  R684      1.3821706175804138e-01
    z[0,3,5]  R685      -2.4591540917754173e-02
    z[0,3,5]  R686      1.7587290704250336e-01
    z[0,3,5]  R687      -6.7038662731647491e-02
    z[0,3,5]  R688      -1.2629090249538422e-01
    z[0,3,5]  R689      -2.9961558058857918e-02
    z[0,3,5]  R690      1.6140486299991608e-01
    z[0,3,5]  R691      3.3552536368370056e-01
    z[0,3,5]  R692      2.3200479149818420e-01
    z[0,3,5]  R693      1.7891988158226013e-01
    z[0,3,5]  R694      2.6513275504112244e-01
    z[0,3,5]  R695      -8.6372224614024162e-03
    z[0,3,5]  R696      -4.5620220899581909e-01
    z[0,3,5]  R697      -5.3024077415466309e-01
    z[0,3,5]  R698      7.6076802797615528e-03
    z[0,3,5]  R699      -2.6597169041633606e-01
    z[0,3,5]  R700      -1.9071632996201515e-02
    z[0,3,5]  R701      2.7643588185310364e-01
    z[0,3,5]  R702      1.4667242765426636e-02
    z[0,3,5]  R703      1.9412128627300262e-01
    z[0,3,5]  R704      -0.51123046875
    z[0,3,5]  R705      -4.3620994687080383e-01
    z[0,3,5]  R706      3.6117190122604370e-01
    z[0,3,5]  R707      -2.8672000765800476e-01
    z[0,3,5]  R708      -3.2860684394836426e-01
    z[0,3,5]  R709      2.9860296845436096e-01
    z[0,3,5]  R710      1.2046633660793304e-01
    z[0,3,5]  R711      -2.8808993101119995e-01
    z[0,3,5]  R712      4.9473512172698975e-01
    z[0,3,5]  R713      -9.4497554004192352e-02
    z[0,3,5]  R714      2.6760599017143250e-01
    z[0,3,5]  R715      -3.1865677237510681e-01
    z[0,3,5]  R716      4.2646953463554382e-01
    z[0,3,5]  R717      2.1734078228473663e-01
    z[0,3,5]  R718      -1.1890596896409988e-01
    z[0,3,5]  R719      1.2651601433753967e-01
    z[0,3,5]  R720      -2.9000097513198853e-01
    z[0,3,5]  R721      5.5134242773056030e-01
    z[0,3,5]  R722      3.9442360401153564e-01
    z[0,3,5]  R723      5.3061836957931519e-01
    z[0,3,5]  R724      4.0059766173362732e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R573      -1
    z[0,3,6]  R574      1
    z[0,3,6]  R575      5.8988708257675171e-01
    z[0,3,6]  R576      5.1419258117675781e-01
    z[0,3,6]  R577      4.3201144784688950e-02
    z[0,3,6]  R578      -4.4612166285514832e-01
    z[0,3,6]  R579      -0.28459432721138
    z[0,3,6]  R580      1.2120986357331276e-02
    z[0,3,6]  R581      -3.1471100449562073e-01
    z[0,3,6]  R582      -2.4058060348033905e-01
    z[0,3,6]  R583      -0.128374844789505
    z[0,3,6]  R584      0.0751722976565361
    z[0,3,6]  R585      5.0954829901456833e-02
    z[0,3,6]  R586      2.2015309333801270e-01
    z[0,3,6]  R587      9.5172263681888580e-02
    z[0,3,6]  R588      -1.4934517443180084e-01
    z[0,3,6]  R589      3.6412796378135681e-01
    z[0,3,6]  R590      2.8385373950004578e-01
    z[0,3,6]  R591      -7.6482407748699188e-02
    z[0,3,6]  R592      -4.5404630899429321e-01
    z[0,3,6]  R593      7.5264692306518555e-02
    z[0,3,6]  R594      1.3915333151817322e-01
    z[0,3,6]  R595      -0.0847182348370552
    z[0,3,6]  R596      -1.1609897762537003e-01
    z[0,3,6]  R597      -2.6535862684249878e-01
    z[0,3,6]  R598      1.6977122426033020e-01
    z[0,3,6]  R599      -9.4169579446315765e-02
    z[0,3,6]  R600      -1.9882759451866150e-01
    z[0,3,6]  R601      1.2652884423732758e-01
    z[0,3,6]  R602      1.5812614560127258e-01
    z[0,3,6]  R603      1.3132725842297077e-02
    z[0,3,6]  R604      1.4832308888435364e-01
    z[0,3,6]  R605      -5.8644801378250122e-01
    z[0,3,6]  R606      -9.6080824732780457e-02
    z[0,3,6]  R607      -0.0935017317533493
    z[0,3,6]  R608      4.2079180479049683e-02
    z[0,3,6]  R609      -2.3811565339565277e-01
    z[0,3,6]  R610      1.5567111968994141e-01
    z[0,3,6]  R611      4.1509577631950378e-01
    z[0,3,6]  R612      -0.135938823223114
    z[0,3,6]  R613      2.3738507926464081e-01
    z[0,3,6]  R614      1.1658837087452412e-02
    z[0,3,6]  R615      2.8270691633224487e-01
    z[0,3,6]  R616      -4.6458322554826736e-02
    z[0,3,6]  R617      3.6631596088409424e-01
    z[0,3,6]  R618      -2.9645375907421112e-02
    z[0,3,6]  R619      4.3972063064575195e-01
    z[0,3,6]  R620      -3.2069772481918335e-01
    z[0,3,6]  R621      -4.4085553288459778e-01
    z[0,3,6]  R622      7.9573400318622589e-02
    z[0,3,6]  R623      1.6697552800178528e-01
    z[0,3,6]  R624      -0.261714369058609
    z[0,3,6]  R625      -6.3062274456024170e-01
    z[0,3,6]  R626      3.0303898453712463e-01
    z[0,3,6]  R627      8.4230154752731323e-02
    z[0,3,6]  R628      1.1596415936946869e-01
    z[0,3,6]  R629      1.8427266180515289e-01
    z[0,3,6]  R630      -1.7956189811229706e-01
    z[0,3,6]  R631      -2.8307339549064636e-01
    z[0,3,6]  R632      -8.2004763185977936e-02
    z[0,3,6]  R633      1.5848989784717560e-01
    z[0,3,6]  R634      2.1177372336387634e-01
    z[0,3,6]  R635      -5.1596730947494507e-02
    z[0,3,6]  R636      -9.6031047403812408e-02
    z[0,3,6]  R637      2.4515299499034882e-01
    z[0,3,6]  R638      1.7724240198731422e-02
    z[0,3,6]  R639      1.0169165581464767e-01
    z[0,3,6]  R640      -2.2188175469636917e-02
    z[0,3,6]  R641      9.6747070550918579e-02
    z[0,3,6]  R642      -1.9185002148151398e-01
    z[0,3,6]  R643      -1.8084512650966644e-01
    z[0,3,6]  R644      -2.2686289250850677e-01
    z[0,3,6]  R645      -6.4817108213901520e-02
    z[0,3,6]  R646      4.8896557092666626e-01
    z[0,3,6]  R647      2.9088145494461060e-01
    z[0,3,6]  R648      5.4765480756759644e-01
    z[0,3,6]  R649      -0.0765218734741211
    z[0,3,6]  R650      6.6383326053619385e-01
    z[0,3,6]  R651      -4.8103660345077515e-01
    z[0,3,6]  R652      -3.5973396152257919e-02
    z[0,3,6]  R653      2.7675414457917213e-02
    z[0,3,6]  R654      1.4806197583675385e-01
    z[0,3,6]  R655      6.5325385332107544e-01
    z[0,3,6]  R656      3.9939659833908081e-01
    z[0,3,6]  R657      -3.3355975151062012e-01
    z[0,3,6]  R658      4.4159561395645142e-01
    z[0,3,6]  R659      -2.2576887905597687e-01
    z[0,3,6]  R660      -5.9509657323360443e-02
    z[0,3,6]  R661      2.3087641596794128e-01
    z[0,3,6]  R662      1.8725031614303589e-01
    z[0,3,6]  R663      -2.8318881988525391e-01
    z[0,3,6]  R664      1.7644004523754120e-01
    z[0,3,6]  R665      -1.5983033180236816e-01
    z[0,3,6]  R666      4.8726612329483032e-01
    z[0,3,6]  R667      0.0975242406129837
    z[0,3,6]  R668      -4.5267440378665924e-02
    z[0,3,6]  R669      -7.1026429533958435e-02
    z[0,3,6]  R670      -2.5069704651832581e-01
    z[0,3,6]  R671      -1.2107732892036438e-01
    z[0,3,6]  R672      -1.1193778365850449e-01
    z[0,3,6]  R673      2.6010793447494507e-01
    z[0,3,6]  R674      -2.2518199682235718e-01
    z[0,3,6]  R675      -1.6620095074176788e-01
    z[0,3,6]  R676      -6.4135879278182983e-02
    z[0,3,6]  R677      5.7532179355621338e-01
    z[0,3,6]  R678      -4.4459655880928040e-01
    z[0,3,6]  R679      -7.7958631515502930e-01
    z[0,3,6]  R680      3.5826382040977478e-01
    z[0,3,6]  R681      1.1560061015188694e-02
    z[0,3,6]  R682      9.2273719608783722e-02
    z[0,3,6]  R683      2.0095439627766609e-02
    z[0,3,6]  R684      5.4892235994338989e-01
    z[0,3,6]  R685      -2.7730929851531982e-01
    z[0,3,6]  R686      2.7985206246376038e-01
    z[0,3,6]  R687      -5.0994741916656494e-01
    z[0,3,6]  R688      8.8763415813446045e-02
    z[0,3,6]  R689      0.625530481338501
    z[0,3,6]  R690      -1.4392854273319244e-01
    z[0,3,6]  R691      5.0578240305185318e-02
    z[0,3,6]  R692      -1.0098070651292801e-01
    z[0,3,6]  R693      5.5152767896652222e-01
    z[0,3,6]  R694      2.2399918735027313e-01
    z[0,3,6]  R695      -4.1818860918283463e-02
    z[0,3,6]  R696      -6.8638898432254791e-02
    z[0,3,6]  R697      4.9629233777523041e-02
    z[0,3,6]  R698      4.6015450358390808e-01
    z[0,3,6]  R699      3.5267940163612366e-01
    z[0,3,6]  R700      8.5834264755249023e-02
    z[0,3,6]  R701      3.3901542425155640e-01
    z[0,3,6]  R702      1.1232954263687134e-01
    z[0,3,6]  R703      -7.5245961546897888e-02
    z[0,3,6]  R704      -1.6824442893266678e-02
    z[0,3,6]  R705      -3.7836784124374390e-01
    z[0,3,6]  R706      -3.7656403146684170e-03
    z[0,3,6]  R707      -4.0477716922760010e-01
    z[0,3,6]  R708      0.0537756085395813
    z[0,3,6]  R709      1.2422189861536026e-01
    z[0,3,6]  R710      5.5422705411911011e-01
    z[0,3,6]  R711      4.6610483527183533e-01
    z[0,3,6]  R712      -3.2319790124893188e-01
    z[0,3,6]  R713      -4.0369275212287903e-01
    z[0,3,6]  R714      -3.1184107065200806e-01
    z[0,3,6]  R715      5.3866648674011230e-01
    z[0,3,6]  R716      -2.4914094805717468e-01
    z[0,3,6]  R717      -2.2761613130569458e-01
    z[0,3,6]  R718      -1.4536048471927643e-01
    z[0,3,6]  R719      -5.7595260441303253e-02
    z[0,3,6]  R720      0.00621609203517437
    z[0,3,6]  R721      -3.4228414297103882e-01
    z[0,3,6]  R722      -6.0688531398773193e-01
    z[0,3,6]  R723      -2.4569284915924072e-01
    z[0,3,6]  R724      -1.6450603306293488e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R725      -1
    z[3,0,0]  R726      1
    z[3,0,0]  R739      2.5813335180282593e-01
    z[3,0,0]  R740      -9.3980008363723755e-01
    z[3,0,0]  R741      -9.2294001579284668e-01
    z[3,0,0]  R742      5.8017861843109131e-01
    z[3,0,0]  R743      -8.6002784967422485e-01
    z[3,0,0]  R744      -0.892230212688446
    z[3,0,0]  R745      -9.4262242317199707e-01
    z[3,0,0]  R746      -9.1773474216461182e-01
    z[3,0,0]  R747      -8.9749175310134888e-01
    z[3,0,0]  R748      -0.83182692527771
    z[3,0,0]  R749      5.5075997114181519e-01
    z[3,0,0]  R750      4.8558406531810760e-02
    z[3,0,0]  R751      2.1610417962074280e-01
    z[3,0,0]  R752      5.7938706874847412e-01
    z[3,0,0]  R753      1.8145748972892761e-01
    z[3,0,0]  R754      3.6470952630043030e-01
    z[3,0,0]  R755      3.6930146813392639e-01
    z[3,0,0]  R756      3.9038211107254028e-01
    z[3,0,0]  R757      2.6583820581436157e-01
    z[3,0,0]  R758      2.2130346298217773e-01
    z[3,0,0]  R759      4.6522235870361328e-01
    z[3,0,0]  R760      6.5786594152450562e-01
    z[3,0,0]  R761      4.9325266480445862e-01
    z[3,0,0]  R762      3.5619714856147766e-01
    z[3,0,0]  R763      5.5103158950805664e-01
    z[3,0,0]  R764      2.9873868823051453e-01
    z[3,0,0]  R765      -3.5717669129371643e-01
    z[3,0,0]  R766      -2.7027529478073120e-01
    z[3,0,0]  R767      -0.3973388671875
    z[3,0,0]  R768      -2.8489735722541809e-01
    z[3,0,0]  R769      6.8873858451843262e-01
    z[3,0,0]  R770      0.576435387134552
    z[3,0,0]  R771      -1.0018469393253326e-01
    z[3,0,0]  R772      6.7038416862487793e-02
    z[3,0,0]  R773      3.8674166798591614e-01
    z[3,0,0]  R774      3.9960426092147827e-01
    z[3,0,0]  R775      3.9525407552719116e-01
    z[3,0,0]  R776      3.9926269650459290e-01
    z[3,0,0]  R777      -3.9417085051536560e-01
    z[3,0,0]  R778      5.6480592489242554e-01
    z[3,0,0]  R779      5.3114473819732666e-01
    z[3,0,0]  R780      -5.3321599960327148e-02
    z[3,0,0]  R781      3.0768087506294250e-01
    z[3,0,0]  R782      1.9263944029808044e-01
    z[3,0,0]  R783      1.9228491187095642e-01
    z[3,0,0]  R784      -3.8100141286849976e-01
    z[3,0,0]  R785      5.4885959625244141e-01
    z[3,0,0]  R786      6.0691988468170166e-01
    z[3,0,0]  R787      -4.7804492712020874e-01
    z[3,0,0]  R788      3.6181899905204773e-01
    z[3,0,0]  R789      5.7915753126144409e-01
    z[3,0,0]  R790      -1.7139646410942078e-01
    z[3,0,0]  R791      2.4324850738048553e-01
    z[3,0,0]  R792      2.1458587050437927e-01
    z[3,0,0]  R793      3.3688443899154663e-01
    z[3,0,0]  R794      -1.5396653115749359e-01
    z[3,0,0]  R795      -3.9778491854667664e-01
    z[3,0,0]  R796      -5.5805152654647827e-01
    z[3,0,0]  R797      2.9693955183029175e-01
    z[3,0,0]  R798      -3.9586779475212097e-01
    z[3,0,0]  R799      3.9001861214637756e-01
    z[3,0,0]  R800      -1.1424923688173294e-01
    z[3,0,0]  R801      1.1477511376142502e-01
    z[3,0,0]  R802      3.7824258208274841e-01
    z[3,0,0]  R803      4.2572364211082458e-01
    z[3,0,0]  R804      -3.0046832561492920e-01
    z[3,0,0]  R805      -4.1631302237510681e-01
    z[3,0,0]  R806      -2.2245289757847786e-02
    z[3,0,0]  R807      -1.5044157207012177e-01
    z[3,0,0]  R808      -2.3720417916774750e-01
    z[3,0,0]  R809      -6.7189380526542664e-02
    z[3,0,0]  R810      3.3011120557785034e-01
    z[3,0,0]  R811      2.8113198280334473e-01
    z[3,0,0]  R812      -2.5362789630889893e-01
    z[3,0,0]  R813      -4.4777533411979675e-01
    z[3,0,0]  R814      2.2559408843517303e-01
    z[3,0,0]  R815      1.6263779997825623e-01
    z[3,0,0]  R816      -3.0208915472030640e-01
    z[3,0,0]  R817      -2.7314043045043945e-01
    z[3,0,0]  R818      -3.9606195688247681e-01
    z[3,0,0]  R819      3.0516144633293152e-01
    z[3,0,0]  R820      -1.5908235311508179e-01
    z[3,0,0]  R821      3.5983249545097351e-01
    z[3,0,0]  R822      4.0131369233131409e-01
    z[3,0,0]  R823      -3.1321954727172852e-01
    z[3,0,0]  R824      -2.8356176614761353e-01
    z[3,0,0]  R825      -3.0964380502700806e-01
    z[3,0,0]  R826      -3.9614996314048767e-01
    z[3,0,0]  R827      -1.2843808531761169e-01
    z[3,0,0]  R828      -2.2057932615280151e-01
    z[3,0,0]  R829      1.3831178843975067e-01
    z[3,0,0]  R830      -2.4963927268981934e-01
    z[3,0,0]  R831      1.5677075088024139e-01
    z[3,0,0]  R832      2.0215308666229248e-01
    z[3,0,0]  R833      3.3621060848236084e-01
    z[3,0,0]  R834      -3.6002430319786072e-01
    z[3,0,0]  R835      2.8251945972442627e-01
    z[3,0,0]  R836      5.3606323897838593e-02
    z[3,0,0]  R837      -2.0865032076835632e-01
    z[3,0,0]  R838      0.0792015790939331
    z[3,0,0]  R839      6.9700604677200317e-01
    z[3,0,0]  R840      4.9385523796081543e-01
    z[3,0,0]  R841      2.7884298563003540e-01
    z[3,0,0]  R842      -6.2758654356002808e-02
    z[3,0,0]  R843      4.4140231609344482e-01
    z[3,0,0]  R844      2.9204022884368896e-01
    z[3,0,0]  R845      0.0990278422832489
    z[3,0,0]  R846      5.6584876775741577e-01
    z[3,0,0]  R847      0.438368558883667
    z[3,0,0]  R848      1.2508645653724670e-01
    z[3,0,0]  R849      4.1417360305786133e-01
    z[3,0,0]  R850      4.1959103941917419e-01
    z[3,0,0]  R851      5.5644816160202026e-01
    z[3,0,0]  R852      6.3575762510299683e-01
    z[3,0,0]  R853      4.1316190361976624e-01
    z[3,0,0]  R854      3.8598445057868958e-01
    z[3,0,0]  R855      2.8113448619842529e-01
    z[3,0,0]  R856      2.4223934113979340e-01
    z[3,0,0]  R857      -3.3876141905784607e-01
    z[3,0,0]  R858      1.6936412453651428e-01
    z[3,0,0]  R859      -2.2780045866966248e-01
    z[3,0,0]  R860      5.2210664749145508e-01
    z[3,0,0]  R861      4.7280839085578918e-01
    z[3,0,0]  R862      3.7545260787010193e-01
    z[3,0,0]  R863      -4.0232321619987488e-01
    z[3,0,0]  R864      4.7286859154701233e-01
    z[3,0,0]  R865      -1.9411759078502655e-01
    z[3,0,0]  R866      9.3059904873371124e-02
    z[3,0,0]  R867      4.1530004143714905e-01
    z[3,0,0]  R868      2.9094433784484863e-01
    z[3,0,0]  R869      4.4050028920173645e-01
    z[3,0,0]  R870      -3.1407541036605835e-01
    z[3,0,0]  R871      -2.5384524837136269e-02
    z[3,0,0]  R872      1.2459943443536758e-01
    z[3,0,0]  R873      -2.3517280817031860e-01
    z[3,0,0]  R874      -5.2083592861890793e-02
    z[3,0,0]  R875      1.4811287820339203e-01
    z[3,0,0]  R876      -6.3537520170211792e-01
    z[3,0,0]  R877      -6.4471709728240967e-01
    z[3,0,0]  R878      -6.5766119956970215e-01
    z[3,0,0]  R879      1.2397421896457672e-01
    z[3,0,0]  R880      6.3077318668365479e-01
    z[3,0,0]  R881      5.0213652849197388e-01
    z[3,0,0]  R882      2.0148406922817230e-01
    z[3,0,0]  R883      -4.1290480643510818e-02
    z[3,0,0]  R884      9.4691142439842224e-02
    z[3,0,0]  R885      -2.8340309858322144e-02
    z[3,0,0]  R886      -2.4740856885910034e-01
    z[3,0,0]  R887      -3.0452784895896912e-01
    z[3,0,0]  R888      -3.8870215415954590e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R727      -1
    z[3,0,1]  R728      1
    z[3,0,1]  R739      4.5794308185577393e-01
    z[3,0,1]  R740      1.5471121668815613e-01
    z[3,0,1]  R741      1.6253520548343658e-01
    z[3,0,1]  R742      5.4190081357955933e-01
    z[3,0,1]  R743      1.8640153110027313e-01
    z[3,0,1]  R744      0.0975256860256195
    z[3,0,1]  R745      -9.9438624456524849e-03
    z[3,0,1]  R746      2.0124214887619019e-01
    z[3,0,1]  R747      2.0787183940410614e-01
    z[3,0,1]  R748      2.8012225031852722e-01
    z[3,0,1]  R749      4.9174398183822632e-01
    z[3,0,1]  R750      5.9860908985137939e-01
    z[3,0,1]  R751      5.6498810648918152e-02
    z[3,0,1]  R752      1.5831539034843445e-01
    z[3,0,1]  R753      2.6287177205085754e-01
    z[3,0,1]  R754      1.3917708396911621e-01
    z[3,0,1]  R755      -3.7313610315322876e-02
    z[3,0,1]  R756      -6.4909934997558594e-01
    z[3,0,1]  R757      -6.3023924827575684e-01
    z[3,0,1]  R758      -0.601081371307373
    z[3,0,1]  R759      4.8583567142486572e-01
    z[3,0,1]  R760      1.6910223662853241e-01
    z[3,0,1]  R761      3.8512364029884338e-01
    z[3,0,1]  R762      -2.4250841140747070e-01
    z[3,0,1]  R763      2.0148472487926483e-01
    z[3,0,1]  R764      5.6375807523727417e-01
    z[3,0,1]  R765      -8.8710987567901611e-01
    z[3,0,1]  R766      -8.7936633825302124e-01
    z[3,0,1]  R767      -8.4518057107925415e-01
    z[3,0,1]  R768      -8.9767938852310181e-01
    z[3,0,1]  R769      3.1527695059776306e-01
    z[3,0,1]  R770      1.0131421685218811e-01
    z[3,0,1]  R771      6.2148368358612061e-01
    z[3,0,1]  R772      6.3854932785034180e-01
    z[3,0,1]  R773      -7.8269565105438232e-01
    z[3,0,1]  R774      -7.5086838006973267e-01
    z[3,0,1]  R775      -7.9141962528228760e-01
    z[3,0,1]  R776      -8.3746296167373657e-01
    z[3,0,1]  R777      -5.1557046175003052e-01
    z[3,0,1]  R778      -6.1647754907608032e-01
    z[3,0,1]  R779      3.2905480265617371e-01
    z[3,0,1]  R780      9.5572900772094727e-01
    z[3,0,1]  R781      3.0548056960105896e-01
    z[3,0,1]  R782      1.9497880339622498e-01
    z[3,0,1]  R783      5.1851749420166016e-01
    z[3,0,1]  R784      6.3300591707229614e-01
    z[3,0,1]  R785      -0.712550163269043
    z[3,0,1]  R786      -7.5988835096359253e-01
    z[3,0,1]  R787      -7.4890685081481934e-01
    z[3,0,1]  R788      -6.0639894008636475e-01
    z[3,0,1]  R789      6.6063940525054932e-01
    z[3,0,1]  R790      7.8202486038208008e-01
    z[3,0,1]  R791      1.7261256277561188e-01
    z[3,0,1]  R792      -2.3551419377326965e-01
    z[3,0,1]  R793      -2.0627915859222412e-01
    z[3,0,1]  R794      -9.0729838609695435e-01
    z[3,0,1]  R795      -8.2229351997375488e-01
    z[3,0,1]  R796      -7.3243695497512817e-01
    z[3,0,1]  R797      -5.0932437181472778e-01
    z[3,0,1]  R798      -5.9857684373855591e-01
    z[3,0,1]  R799      -1.8179433420300484e-02
    z[3,0,1]  R800      8.6025208234786987e-01
    z[3,0,1]  R801      4.1180285811424255e-01
    z[3,0,1]  R802      -6.7911714315414429e-01
    z[3,0,1]  R803      -6.1638671159744263e-01
    z[3,0,1]  R804      -8.4821528196334839e-01
    z[3,0,1]  R805      -6.9856476783752441e-01
    z[3,0,1]  R806      -8.9396846294403076e-01
    z[3,0,1]  R807      -8.1388109922409058e-01
    z[3,0,1]  R808      -8.0397886037826538e-01
    z[3,0,1]  R809      1.1819742619991302e-02
    z[3,0,1]  R810      -7.3750841617584229e-01
    z[3,0,1]  R811      -5.9825807809829712e-01
    z[3,0,1]  R812      -0.844097912311554
    z[3,0,1]  R813      -5.0424879789352417e-01
    z[3,0,1]  R814      -6.4740163087844849e-01
    z[3,0,1]  R815      -4.7776961326599121e-01
    z[3,0,1]  R816      -5.2313446998596191e-01
    z[3,0,1]  R817      -7.1146863698959351e-01
    z[3,0,1]  R818      -0.487781286239624
    z[3,0,1]  R819      1.2014646083116531e-02
    z[3,0,1]  R820      6.5612250566482544e-01
    z[3,0,1]  R821      -6.7768466472625732e-01
    z[3,0,1]  R822      -7.2295677661895752e-01
    z[3,0,1]  R823      -8.6170834302902222e-01
    z[3,0,1]  R824      -0.867425799369812
    z[3,0,1]  R825      -4.6951338648796082e-01
    z[3,0,1]  R826      -4.7382223606109619e-01
    z[3,0,1]  R827      -9.8977647721767426e-02
    z[3,0,1]  R828      -2.1678347885608673e-01
    z[3,0,1]  R829      5.4261481761932373e-01
    z[3,0,1]  R830      1.8471740186214447e-01
    z[3,0,1]  R831      4.8204636573791504e-01
    z[3,0,1]  R832      6.2353205680847168e-01
    z[3,0,1]  R833      3.3489429950714111e-01
    z[3,0,1]  R834      -8.1334710121154785e-01
    z[3,0,1]  R835      -6.8163412809371948e-01
    z[3,0,1]  R836      -7.3793184757232666e-01
    z[3,0,1]  R837      -6.2932431697845459e-01
    z[3,0,1]  R838      -4.5561450719833374e-01
    z[3,0,1]  R839      2.6548174023628235e-01
    z[3,0,1]  R840      1.7883922159671783e-01
    z[3,0,1]  R841      2.4211584031581879e-01
    z[3,0,1]  R842      -3.7438550591468811e-01
    z[3,0,1]  R843      -6.9548559188842773e-01
    z[3,0,1]  R844      -8.1426960229873657e-01
    z[3,0,1]  R845      -8.8026142120361328e-01
    z[3,0,1]  R846      -5.5686980485916138e-01
    z[3,0,1]  R847      -6.1559689044952393e-01
    z[3,0,1]  R848      -8.6519724130630493e-01
    z[3,0,1]  R849      -7.8430545330047607e-01
    z[3,0,1]  R850      -8.8759505748748779e-01
    z[3,0,1]  R851      -7.8066098690032959e-01
    z[3,0,1]  R852      -7.2174870967864990e-01
    z[3,0,1]  R853      -0.579284131526947
    z[3,0,1]  R854      -0.739266574382782
    z[3,0,1]  R855      -7.4926763772964478e-01
    z[3,0,1]  R856      -0.616884171962738
    z[3,0,1]  R857      -8.8023918867111206e-01
    z[3,0,1]  R858      -8.8934975862503052e-01
    z[3,0,1]  R859      -6.0995358228683472e-01
    z[3,0,1]  R860      -6.6779989004135132e-01
    z[3,0,1]  R861      -5.9846210479736328e-01
    z[3,0,1]  R862      -8.5873937606811523e-01
    z[3,0,1]  R863      -4.8705798387527466e-01
    z[3,0,1]  R864      -5.8593922853469849e-01
    z[3,0,1]  R865      -8.4706974029541016e-01
    z[3,0,1]  R866      -8.3782196044921875e-01
    z[3,0,1]  R867      -7.2321790456771851e-01
    z[3,0,1]  R868      -6.1781018972396851e-01
    z[3,0,1]  R869      -8.2881647348403931e-01
    z[3,0,1]  R870      -9.0422928333282471e-01
    z[3,0,1]  R871      -9.0046817064285278e-01
    z[3,0,1]  R872      -9.6193933486938477e-01
    z[3,0,1]  R873      -0.798782229423523
    z[3,0,1]  R874      -7.6137822866439819e-01
    z[3,0,1]  R875      -4.1610002517700195e-01
    z[3,0,1]  R876      7.1338564157485962e-02
    z[3,0,1]  R877      9.2577107250690460e-02
    z[3,0,1]  R878      7.7672697603702545e-02
    z[3,0,1]  R879      -5.9112477302551270e-01
    z[3,0,1]  R880      -0.6157186627388
    z[3,0,1]  R881      -6.7031729221343994e-01
    z[3,0,1]  R882      -9.1305035352706909e-01
    z[3,0,1]  R883      -9.5023977756500244e-01
    z[3,0,1]  R884      -8.8946694135665894e-01
    z[3,0,1]  R885      -8.7520343065261841e-01
    z[3,0,1]  R886      -7.9479080438613892e-01
    z[3,0,1]  R887      0.0364716611802578
    z[3,0,1]  R888      1.9382598996162415e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R729      -1
    z[3,0,2]  R730      1
    z[3,0,2]  R739      4.7317445278167725e-01
    z[3,0,2]  R740      -7.1036987006664276e-02
    z[3,0,2]  R741      3.9349254220724106e-03
    z[3,0,2]  R742      6.0475575923919678e-01
    z[3,0,2]  R743      -1.0655601322650909e-01
    z[3,0,2]  R744      1.0289722681045532e-01
    z[3,0,2]  R745      -1.4623812399804592e-02
    z[3,0,2]  R746      -1.1547831445932388e-01
    z[3,0,2]  R747      2.7077925205230713e-01
    z[3,0,2]  R748      3.0057525634765625e-01
    z[3,0,2]  R749      -6.0011076927185059e-01
    z[3,0,2]  R750      -2.8771796822547913e-01
    z[3,0,2]  R751      -0.17482890188694
    z[3,0,2]  R752      5.7021718472242355e-02
    z[3,0,2]  R753      -2.6236066222190857e-01
    z[3,0,2]  R754      -2.7732434868812561e-01
    z[3,0,2]  R755      -5.6132465600967407e-02
    z[3,0,2]  R756      2.5654694437980652e-01
    z[3,0,2]  R757      -2.4898232519626617e-01
    z[3,0,2]  R758      -4.8615369945764542e-02
    z[3,0,2]  R759      -2.3697596788406372e-01
    z[3,0,2]  R760      0.478730708360672
    z[3,0,2]  R761      1.1790613085031509e-01
    z[3,0,2]  R762      1.5007908223196864e-03
    z[3,0,2]  R763      -3.0414253473281860e-01
    z[3,0,2]  R764      -4.6622648835182190e-01
    z[3,0,2]  R765      1.2217401713132858e-01
    z[3,0,2]  R766      -7.3766350746154785e-02
    z[3,0,2]  R767      8.6302056908607483e-02
    z[3,0,2]  R768      7.0185407996177673e-02
    z[3,0,2]  R769      -1.1465033888816833e-01
    z[3,0,2]  R770      -1.8005770444869995e-01
    z[3,0,2]  R771      2.2961066663265228e-01
    z[3,0,2]  R772      -5.6701207160949707e-01
    z[3,0,2]  R773      -7.0753586478531361e-03
    z[3,0,2]  R774      -4.2569848895072937e-01
    z[3,0,2]  R775      3.8507454097270966e-02
    z[3,0,2]  R776      -2.1936345100402832e-01
    z[3,0,2]  R777      -4.4113822281360626e-02
    z[3,0,2]  R778      -2.9070353507995605e-01
    z[3,0,2]  R779      3.1474274396896362e-01
    z[3,0,2]  R780      -1.3277991116046906e-01
    z[3,0,2]  R781      -2.0039129257202148e-01
    z[3,0,2]  R782      3.3667656779289246e-01
    z[3,0,2]  R783      9.5063023269176483e-02
    z[3,0,2]  R784      1.8678675591945648e-01
    z[3,0,2]  R785      -1.5000531077384949e-01
    z[3,0,2]  R786      1.4589686691761017e-01
    z[3,0,2]  R787      -1.3811717927455902e-01
    z[3,0,2]  R788      -3.2649955153465271e-01
    z[3,0,2]  R789      -7.7538035809993744e-02
    z[3,0,2]  R790      2.7904254198074341e-01
    z[3,0,2]  R791      4.6756044030189514e-01
    z[3,0,2]  R792      5.8996933698654175e-01
    z[3,0,2]  R793      3.0695015192031860e-01
    z[3,0,2]  R794      -8.3865828812122345e-02
    z[3,0,2]  R795      -0.201654851436615
    z[3,0,2]  R796      2.3760262876749039e-02
    z[3,0,2]  R797      1.9889634847640991e-01
    z[3,0,2]  R798      -4.1506299376487732e-01
    z[3,0,2]  R799      1.5373519062995911e-01
    z[3,0,2]  R800      6.0239702463150024e-02
    z[3,0,2]  R801      -2.5170063972473145e-01
    z[3,0,2]  R802      -3.9540448784828186e-01
    z[3,0,2]  R803      1.8756791949272156e-01
    z[3,0,2]  R804      -1.8159843981266022e-01
    z[3,0,2]  R805      -1.4692538976669312e-01
    z[3,0,2]  R806      2.8810954093933105e-01
    z[3,0,2]  R807      0.518994152545929
    z[3,0,2]  R808      -7.1790322661399841e-02
    z[3,0,2]  R809      2.0671610534191132e-01
    z[3,0,2]  R810      -2.9173594713211060e-01
    z[3,0,2]  R811      -2.5543960928916931e-01
    z[3,0,2]  R812      -2.7297517657279968e-01
    z[3,0,2]  R813      -4.6042707562446594e-01
    z[3,0,2]  R814      1.2205547094345093e-01
    z[3,0,2]  R815      -1.7233356833457947e-01
    z[3,0,2]  R816      -0.463856041431427
    z[3,0,2]  R817      -0.343553364276886
    z[3,0,2]  R818      -5.5767357349395752e-01
    z[3,0,2]  R819      2.7804297208786011e-01
    z[3,0,2]  R820      -6.2095586210489273e-02
    z[3,0,2]  R821      -2.0334620773792267e-01
    z[3,0,2]  R822      -4.3719375133514404e-01
    z[3,0,2]  R823      -3.4538358449935913e-01
    z[3,0,2]  R824      2.2523038089275360e-01
    z[3,0,2]  R825      -1.1186144500970840e-01
    z[3,0,2]  R826      -2.3457500338554382e-01
    z[3,0,2]  R827      -3.6460712552070618e-01
    z[3,0,2]  R828      -7.4643462896347046e-01
    z[3,0,2]  R829      4.3849232792854309e-01
    z[3,0,2]  R830      3.3853515982627869e-01
    z[3,0,2]  R831      9.4243094325065613e-02
    z[3,0,2]  R832      0.582205593585968
    z[3,0,2]  R833      3.9551305770874023e-01
    z[3,0,2]  R834      5.2726618014276028e-03
    z[3,0,2]  R835      -3.3160638064146042e-02
    z[3,0,2]  R836      1.5954692661762238e-01
    z[3,0,2]  R837      7.1214497089385986e-01
    z[3,0,2]  R838      2.3050554096698761e-01
    z[3,0,2]  R839      -3.3334669470787048e-01
    z[3,0,2]  R840      5.5639997124671936e-02
    z[3,0,2]  R841      -2.0356020331382751e-01
    z[3,0,2]  R842      -2.3002997040748596e-01
    z[3,0,2]  R843      -2.8369075059890747e-01
    z[3,0,2]  R844      3.8147693872451782e-01
    z[3,0,2]  R845      2.3826966062188148e-02
    z[3,0,2]  R846      -2.9808353632688522e-02
    z[3,0,2]  R847      -2.7991554141044617e-01
    z[3,0,2]  R848      -1.5095798298716545e-02
    z[3,0,2]  R849      -3.7754490971565247e-01
    z[3,0,2]  R850      -1.0950003750622272e-02
    z[3,0,2]  R851      2.4025326129049063e-03
    z[3,0,2]  R852      1.3460588455200195e-01
    z[3,0,2]  R853      -2.1773955225944519e-01
    z[3,0,2]  R854      -2.7437901496887207e-01
    z[3,0,2]  R855      -9.9309816956520081e-02
    z[3,0,2]  R856      -4.0018233656883240e-01
    z[3,0,2]  R857      -1.9711470603942871e-01
    z[3,0,2]  R858      -1.2846191413700581e-02
    z[3,0,2]  R859      2.4511611461639404e-01
    z[3,0,2]  R860      6.2628291547298431e-02
    z[3,0,2]  R861      1.0547447949647903e-01
    z[3,0,2]  R862      3.3033019304275513e-01
    z[3,0,2]  R863      6.6327786445617676e-01
    z[3,0,2]  R864      8.1514120101928711e-02
    z[3,0,2]  R865      -1.3852171599864960e-01
    z[3,0,2]  R866      4.2326194047927856e-01
    z[3,0,2]  R867      -4.6761423349380493e-02
    z[3,0,2]  R868      3.7887477874755859e-01
    z[3,0,2]  R869      -9.9935494363307953e-02
    z[3,0,2]  R870      1.0055445134639740e-01
    z[3,0,2]  R871      2.0335851609706879e-01
    z[3,0,2]  R872      -1.0601404309272766e-01
    z[3,0,2]  R873      -1.2080924212932587e-01
    z[3,0,2]  R874      -3.1700644642114639e-02
    z[3,0,2]  R875      -3.3466815948486328e-01
    z[3,0,2]  R876      -0.687119722366333
    z[3,0,2]  R877      -6.4685958623886108e-01
    z[3,0,2]  R878      -6.0850036144256592e-01
    z[3,0,2]  R879      2.5499412789940834e-02
    z[3,0,2]  R880      5.7227391749620438e-02
    z[3,0,2]  R881      2.2832669317722321e-01
    z[3,0,2]  R882      -1.0725231468677521e-01
    z[3,0,2]  R883      1.5175219625234604e-02
    z[3,0,2]  R884      2.7799534797668457e-01
    z[3,0,2]  R885      -1.1042208969593048e-01
    z[3,0,2]  R886      -4.4454595446586609e-01
    z[3,0,2]  R887      5.8498613536357880e-02
    z[3,0,2]  R888      -3.2437656074762344e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R731      -1
    z[3,0,3]  R732      1
    z[3,0,3]  R739      -3.7363407015800476e-01
    z[3,0,3]  R740      -2.3972152173519135e-01
    z[3,0,3]  R741      -1.9779071211814880e-01
    z[3,0,3]  R742      -7.7056130394339561e-03
    z[3,0,3]  R743      -2.0588600635528564e-01
    z[3,0,3]  R744      3.0438458546996117e-02
    z[3,0,3]  R745      -8.3044849336147308e-02
    z[3,0,3]  R746      2.4156817793846130e-01
    z[3,0,3]  R747      9.3204446136951447e-02
    z[3,0,3]  R748      -1.8220625817775726e-01
    z[3,0,3]  R749      -2.1709744632244110e-01
    z[3,0,3]  R750      4.2003658413887024e-01
    z[3,0,3]  R751      -6.1917316913604736e-01
    z[3,0,3]  R752      -2.4185305833816528e-01
    z[3,0,3]  R753      -4.7418147325515747e-01
    z[3,0,3]  R754      -3.5897254943847656e-01
    z[3,0,3]  R755      -6.7649924755096436e-01
    z[3,0,3]  R756      5.8192396163940430e-01
    z[3,0,3]  R757      5.5674391984939575e-01
    z[3,0,3]  R758      6.7789024114608765e-01
    z[3,0,3]  R759      -1.2351523339748383e-01
    z[3,0,3]  R760      -3.7697765231132507e-01
    z[3,0,3]  R761      -3.9568236470222473e-01
    z[3,0,3]  R762      -4.5480468869209290e-01
    z[3,0,3]  R763      -1.4198586344718933e-01
    z[3,0,3]  R764      -3.2391302287578583e-02
    z[3,0,3]  R765      -7.1297824382781982e-02
    z[3,0,3]  R766      -1.7052255570888519e-01
    z[3,0,3]  R767      -1.3055598735809326e-01
    z[3,0,3]  R768      1.0369133204221725e-01
    z[3,0,3]  R769      -5.6572878360748291e-01
    z[3,0,3]  R770      -6.1591309309005737e-01
    z[3,0,3]  R771      6.7653483152389526e-01
    z[3,0,3]  R772      -1.1923617124557495e-01
    z[3,0,3]  R773      3.2390314340591431e-01
    z[3,0,3]  R774      3.9310574531555176e-02
    z[3,0,3]  R775      1.3593333959579468e-01
    z[3,0,3]  R776      -1.6196319460868835e-01
    z[3,0,3]  R777      5.8970528841018677e-01
    z[3,0,3]  R778      3.8669671863317490e-02
    z[3,0,3]  R779      -1.9893029239028692e-03
    z[3,0,3]  R780      1.4506794512271881e-01
    z[3,0,3]  R781      -2.7058762311935425e-01
    z[3,0,3]  R782      -5.8655035495758057e-01
    z[3,0,3]  R783      -4.3224066495895386e-02
    z[3,0,3]  R784      3.6754816770553589e-01
    z[3,0,3]  R785      3.5326120257377625e-01
    z[3,0,3]  R786      2.2708898410201073e-02
    z[3,0,3]  R787      2.7809518575668335e-01
    z[3,0,3]  R788      2.4823831021785736e-01
    z[3,0,3]  R789      -2.7817955613136292e-01
    z[3,0,3]  R790      -3.7966978549957275e-01
    z[3,0,3]  R791      -5.1656246185302734e-01
    z[3,0,3]  R792      -7.2383642196655273e-01
    z[3,0,3]  R793      -4.3253010511398315e-01
    z[3,0,3]  R794      -3.0411076545715332e-01
    z[3,0,3]  R795      -5.1381520926952362e-02
    z[3,0,3]  R796      2.3650184273719788e-01
    z[3,0,3]  R797      5.2529340982437134e-01
    z[3,0,3]  R798      2.6098170876502991e-01
    z[3,0,3]  R799      -7.0872771739959717e-01
    z[3,0,3]  R800      2.3492148146033287e-02
    z[3,0,3]  R801      -5.7568907737731934e-01
    z[3,0,3]  R802      2.0097626373171806e-02
    z[3,0,3]  R803      3.1200775504112244e-01
    z[3,0,3]  R804      -3.1716406345367432e-01
    z[3,0,3]  R805      0.325791597366333
    z[3,0,3]  R806      -1.7388641834259033e-01
    z[3,0,3]  R807      -3.3776730298995972e-02
    z[3,0,3]  R808      -9.5977261662483215e-02
    z[3,0,3]  R809      -7.8665858507156372e-01
    z[3,0,3]  R810      3.5539820790290833e-01
    z[3,0,3]  R811      5.0124150514602661e-01
    z[3,0,3]  R812      -1.1464725248515606e-02
    z[3,0,3]  R813      4.6107214689254761e-01
    z[3,0,3]  R814      4.3256533145904541e-01
    z[3,0,3]  R815      6.0782027244567871e-01
    z[3,0,3]  R816      1.7142720520496368e-01
    z[3,0,3]  R817      3.2900744676589966e-01
    z[3,0,3]  R818      -7.7450558543205261e-02
    z[3,0,3]  R819      -6.4688611030578613e-01
    z[3,0,3]  R820      3.6693942546844482e-01
    z[3,0,3]  R821      0.519483745098114
    z[3,0,3]  R822      5.1869828253984451e-02
    z[3,0,3]  R823      1.3376979529857635e-01
    z[3,0,3]  R824      1.4833371341228485e-01
    z[3,0,3]  R825      4.6653857827186584e-01
    z[3,0,3]  R826      1.1839896440505981e-01
    z[3,0,3]  R827      6.3796001672744751e-01
    z[3,0,3]  R828      2.9312953352928162e-01
    z[3,0,3]  R829      -2.7918061614036560e-01
    z[3,0,3]  R830      -1.5112577378749847e-01
    z[3,0,3]  R831      -3.8952809572219849e-01
    z[3,0,3]  R832      -2.6958325877785683e-02
    z[3,0,3]  R833      -0.576545238494873
    z[3,0,3]  R834      4.2964771389961243e-01
    z[3,0,3]  R835      3.6707094311714172e-01
    z[3,0,3]  R836      4.9446511268615723e-01
    z[3,0,3]  R837      -8.6714506149291992e-02
    z[3,0,3]  R838      8.4276819229125977e-01
    z[3,0,3]  R839      -1.5110825002193451e-01
    z[3,0,3]  R840      4.4408398866653442e-01
    z[3,0,3]  R841      4.9077352881431580e-01
    z[3,0,3]  R842      3.7115055322647095e-01
    z[3,0,3]  R843      1.4902465045452118e-01
    z[3,0,3]  R844      5.3401932120323181e-02
    z[3,0,3]  R845      -2.3090282082557678e-01
    z[3,0,3]  R846      2.8796160221099854e-01
    z[3,0,3]  R847      2.4158558249473572e-01
    z[3,0,3]  R848      -3.7723553180694580e-01
    z[3,0,3]  R849      1.8693108856678009e-01
    z[3,0,3]  R850      4.9490388482809067e-03
    z[3,0,3]  R851      -1.4407569542527199e-02
    z[3,0,3]  R852      -0.00487411767244339
    z[3,0,3]  R853      6.2143850326538086e-01
    z[3,0,3]  R854      1.7748048901557922e-01
    z[3,0,3]  R855      3.9502236247062683e-01
    z[3,0,3]  R856      5.5404853820800781e-01
    z[3,0,3]  R857      -1.6640393063426018e-02
    z[3,0,3]  R858      2.5008162856101990e-01
    z[3,0,3]  R859      0.254672646522522
    z[3,0,3]  R860      4.5510622859001160e-01
    z[3,0,3]  R861      5.9680455923080444e-01
    z[3,0,3]  R862      2.9364828020334244e-02
    z[3,0,3]  R863      2.8551253676414490e-01
    z[3,0,3]  R864      4.4502565264701843e-01
    z[3,0,3]  R865      6.2376689165830612e-02
    z[3,0,3]  R866      2.4847450852394104e-01
    z[3,0,3]  R867      7.0948116481304169e-02
    z[3,0,3]  R868      5.4908853769302368e-01
    z[3,0,3]  R869      1.2764946557581425e-02
    z[3,0,3]  R870      2.4747721850872040e-01
    z[3,0,3]  R871      6.0122460126876831e-02
    z[3,0,3]  R872      -7.7999327331781387e-03
    z[3,0,3]  R873      2.8803277015686035e-01
    z[3,0,3]  R874      2.4187400937080383e-01
    z[3,0,3]  R875      6.3066351413726807e-01
    z[3,0,3]  R876      -1.0523796826601028e-01
    z[3,0,3]  R877      2.9216054081916809e-01
    z[3,0,3]  R878      1.7974372208118439e-01
    z[3,0,3]  R879      -3.1478229910135269e-02
    z[3,0,3]  R880      3.1292641162872314e-01
    z[3,0,3]  R881      3.5052257776260376e-01
    z[3,0,3]  R882      7.7737748622894287e-02
    z[3,0,3]  R883      -1.4659301936626434e-01
    z[3,0,3]  R884      -1.6012732684612274e-01
    z[3,0,3]  R885      1.8675832450389862e-01
    z[3,0,3]  R886      3.9999779313802719e-02
    z[3,0,3]  R887      5.6568211317062378e-01
    z[3,0,3]  R888      6.6492003202438354e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R733      -1
    z[3,0,4]  R734      1
    z[3,0,4]  R739      3.4899908304214478e-01
    z[3,0,4]  R740      1.3045790791511536e-01
    z[3,0,4]  R741      6.4899399876594543e-02
    z[3,0,4]  R742      5.2281104028224945e-02
    z[3,0,4]  R743      -2.7794393897056580e-01
    z[3,0,4]  R744      -4.3862383812665939e-02
    z[3,0,4]  R745      -3.0529299378395081e-01
    z[3,0,4]  R746      -0.0504038967192173
    z[3,0,4]  R747      1.9112777709960938e-01
    z[3,0,4]  R748      -4.1402861475944519e-02
    z[3,0,4]  R749      -3.5263508558273315e-02
    z[3,0,4]  R750      2.8810936212539673e-01
    z[3,0,4]  R751      -6.4258921146392822e-01
    z[3,0,4]  R752      -5.0122499465942383e-01
    z[3,0,4]  R753      -7.5447636842727661e-01
    z[3,0,4]  R754      -4.3736043572425842e-01
    z[3,0,4]  R755      -2.8554555773735046e-01
    z[3,0,4]  R756      -1.3387228548526764e-01
    z[3,0,4]  R757      3.9674103260040283e-01
    z[3,0,4]  R758      -1.8834735453128815e-01
    z[3,0,4]  R759      1.6314629465341568e-02
    z[3,0,4]  R760      3.4935045987367630e-02
    z[3,0,4]  R761      -5.6127011775970459e-01
    z[3,0,4]  R762      6.2418907880783081e-01
    z[3,0,4]  R763      0.508728563785553
    z[3,0,4]  R764      5.9628438949584961e-01
    z[3,0,4]  R765      -9.6647582948207855e-02
    z[3,0,4]  R766      -2.8975948691368103e-01
    z[3,0,4]  R767      -1.2747314572334290e-01
    z[3,0,4]  R768      2.3188865184783936e-01
    z[3,0,4]  R769      -6.5716892480850220e-02
    z[3,0,4]  R770      8.0855533480644226e-02
    z[3,0,4]  R771      -3.2234955579042435e-02
    z[3,0,4]  R772      -2.5378465652465820e-01
    z[3,0,4]  R773      2.8136804699897766e-01
    z[3,0,4]  R774      -1.0198257118463516e-01
    z[3,0,4]  R775      -1.1463674902915955e-01
    z[3,0,4]  R776      1.7112898826599121e-01
    z[3,0,4]  R777      -2.5380682945251465e-01
    z[3,0,4]  R778      9.4268575310707092e-02
    z[3,0,4]  R779      6.5625023841857910e-01
    z[3,0,4]  R780      -1.6640214622020721e-01
    z[3,0,4]  R781      5.1289498805999756e-01
    z[3,0,4]  R782      -4.8925641179084778e-01
    z[3,0,4]  R783      2.7319782972335815e-01
    z[3,0,4]  R784      2.0046363770961761e-01
    z[3,0,4]  R785      -1.7939563095569611e-01
    z[3,0,4]  R786      7.3708340525627136e-02
    z[3,0,4]  R787      -2.0611342787742615e-01
    z[3,0,4]  R788      1.1279787868261337e-01
    z[3,0,4]  R789      2.5928923487663269e-01
    z[3,0,4]  R790      1.6672702133655548e-01
    z[3,0,4]  R791      -4.0130406618118286e-01
    z[3,0,4]  R792      -5.1522977650165558e-02
    z[3,0,4]  R793      4.1288143396377563e-01
    z[3,0,4]  R794      -8.2583807408809662e-02
    z[3,0,4]  R795      8.4618858993053436e-02
    z[3,0,4]  R796      1.7774626612663269e-01
    z[3,0,4]  R797      2.6971861720085144e-02
    z[3,0,4]  R798      3.5232746601104736e-01
    z[3,0,4]  R799      5.6551039218902588e-01
    z[3,0,4]  R800      1.7291894555091858e-01
    z[3,0,4]  R801      -3.7263345718383789e-01
    z[3,0,4]  R802      -1.6487531363964081e-01
    z[3,0,4]  R803      -3.3342546224594116e-01
    z[3,0,4]  R804      2.2124059498310089e-01
    z[3,0,4]  R805      1.4005471765995026e-01
    z[3,0,4]  R806      2.7248656749725342e-01
    z[3,0,4]  R807      -3.3528175204992294e-02
    z[3,0,4]  R808      1.4610594511032104e-01
    z[3,0,4]  R809      -1.8471702933311462e-02
    z[3,0,4]  R810      -7.2325021028518677e-02
    z[3,0,4]  R811      -2.2511104121804237e-02
    z[3,0,4]  R812      1.9403712451457977e-01
    z[3,0,4]  R813      1.2670768797397614e-01
    z[3,0,4]  R814      -0.0792994499206543
    z[3,0,4]  R815      -2.1422253549098969e-01
    z[3,0,4]  R816      2.0323148369789124e-01
    z[3,0,4]  R817      1.4503178000450134e-01
    z[3,0,4]  R818      -3.4546792507171631e-01
    z[3,0,4]  R819      -1.3877657055854797e-01
    z[3,0,4]  R820      4.0217930078506470e-01
    z[3,0,4]  R821      -3.1700424849987030e-02
    z[3,0,4]  R822      2.9526901245117188e-01
    z[3,0,4]  R823      -5.3333666175603867e-02
    z[3,0,4]  R824      1.0146160423755646e-01
    z[3,0,4]  R825      -1.7991612851619720e-01
    z[3,0,4]  R826      -1.6010677814483643e-01
    z[3,0,4]  R827      -3.0307593941688538e-01
    z[3,0,4]  R828      -2.7151322364807129e-01
    z[3,0,4]  R829      -5.1024895161390305e-02
    z[3,0,4]  R830      1.3013137876987457e-01
    z[3,0,4]  R831      2.8744551539421082e-01
    z[3,0,4]  R832      -1.6588295996189117e-01
    z[3,0,4]  R833      -1.7806215584278107e-01
    z[3,0,4]  R834      -2.8135115280747414e-02
    z[3,0,4]  R835      -2.8193125128746033e-01
    z[3,0,4]  R836      3.4507939219474792e-01
    z[3,0,4]  R837      -1.3545063138008118e-01
    z[3,0,4]  R838      1.1985806375741959e-01
    z[3,0,4]  R839      1.3993303477764130e-01
    z[3,0,4]  R840      4.9991786479949951e-01
    z[3,0,4]  R841      7.4206370115280151e-01
    z[3,0,4]  R842      7.5349074602127075e-01
    z[3,0,4]  R843      -1.2462893128395081e-01
    z[3,0,4]  R844      -0.0282792616635561
    z[3,0,4]  R845      -3.6938312649726868e-01
    z[3,0,4]  R846      -2.8143274784088135e-01
    z[3,0,4]  R847      -5.2599930763244629e-01
    z[3,0,4]  R848      -2.1209090948104858e-01
    z[3,0,4]  R849      -9.3808978796005249e-02
    z[3,0,4]  R850      -2.3968910798430443e-02
    z[3,0,4]  R851      1.0132896155118942e-01
    z[3,0,4]  R852      -1.6049362719058990e-01
    z[3,0,4]  R853      1.0189700871706009e-01
    z[3,0,4]  R854      3.9138558506965637e-01
    z[3,0,4]  R855      4.0224725008010864e-01
    z[3,0,4]  R856      2.0485168695449829e-01
    z[3,0,4]  R857      -2.6626411080360413e-01
    z[3,0,4]  R858      3.0490845441818237e-01
    z[3,0,4]  R859      1.0915137827396393e-01
    z[3,0,4]  R860      7.1642078459262848e-02
    z[3,0,4]  R861      2.0457884669303894e-01
    z[3,0,4]  R862      5.7132825255393982e-02
    z[3,0,4]  R863      1.3246698677539825e-01
    z[3,0,4]  R864      -3.7669813632965088e-01
    z[3,0,4]  R865      -1.6978222131729126e-01
    z[3,0,4]  R866      -6.1717376112937927e-02
    z[3,0,4]  R867      -4.7624397277832031e-01
    z[3,0,4]  R868      -1.4507827162742615e-01
    z[3,0,4]  R869      -1.7002993822097778e-01
    z[3,0,4]  R870      -4.2550783604383469e-02
    z[3,0,4]  R871      -9.4564616680145264e-02
    z[3,0,4]  R872      1.6484777629375458e-01
    z[3,0,4]  R873      1.1954781413078308e-01
    z[3,0,4]  R874      -2.3453450202941895e-01
    z[3,0,4]  R875      -1.9616085290908813e-01
    z[3,0,4]  R876      -1.7899875342845917e-01
    z[3,0,4]  R877      -6.4933754503726959e-02
    z[3,0,4]  R878      -2.2044228017330170e-01
    z[3,0,4]  R879      3.1556585431098938e-01
    z[3,0,4]  R880      1.0745245218276978e-01
    z[3,0,4]  R881      -7.7980393543839455e-03
    z[3,0,4]  R882      -2.1471410989761353e-02
    z[3,0,4]  R883      -1.3983753323554993e-01
    z[3,0,4]  R884      -2.3936058580875397e-01
    z[3,0,4]  R885      -1.2669727206230164e-01
    z[3,0,4]  R886      1.7202737927436829e-01
    z[3,0,4]  R887      -4.1657772660255432e-01
    z[3,0,4]  R888      -2.6984393596649170e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R735      -1
    z[3,0,5]  R736      1
    z[3,0,5]  R739      -4.8548573255538940e-01
    z[3,0,5]  R740      6.3925251364707947e-02
    z[3,0,5]  R741      -1.3533490896224976e-01
    z[3,0,5]  R742      -2.9999520629644394e-02
    z[3,0,5]  R743      -2.9029190540313721e-01
    z[3,0,5]  R744      -4.2483350634574890e-01
    z[3,0,5]  R745      -4.1109815239906311e-02
    z[3,0,5]  R746      -0.0789119228720665
    z[3,0,5]  R747      0.00739058293402195
    z[3,0,5]  R748      -2.2993431985378265e-01
    z[3,0,5]  R749      2.0528608560562134e-01
    z[3,0,5]  R750      -2.4083724617958069e-01
    z[3,0,5]  R751      -1.9655372202396393e-01
    z[3,0,5]  R752      1.6232709586620331e-01
    z[3,0,5]  R753      -1.7088063061237335e-01
    z[3,0,5]  R754      -0.0994378998875618
    z[3,0,5]  R755      2.9747176170349121e-01
    z[3,0,5]  R756      -5.1031500101089478e-02
    z[3,0,5]  R757      -4.4756412506103516e-02
    z[3,0,5]  R758      2.6538664102554321e-01
    z[3,0,5]  R759      -2.2161072492599487e-01
    z[3,0,5]  R760      8.1138901412487030e-02
    z[3,0,5]  R761      1.0783676803112030e-01
    z[3,0,5]  R762      1.5114578604698181e-01
    z[3,0,5]  R763      4.8304149508476257e-01
    z[3,0,5]  R764      -1.2417440861463547e-01
    z[3,0,5]  R765      -5.2974302321672440e-02
    z[3,0,5]  R766      1.1111255735158920e-02
    z[3,0,5]  R767      -8.2784526050090790e-02
    z[3,0,5]  R768      1.1146222800016403e-01
    z[3,0,5]  R769      0.251359224319458
    z[3,0,5]  R770      4.1499685496091843e-02
    z[3,0,5]  R771      -2.8766372799873352e-01
    z[3,0,5]  R772      -4.3079584836959839e-01
    z[3,0,5]  R773      2.2054976224899292e-01
    z[3,0,5]  R774      -1.4317522943019867e-01
    z[3,0,5]  R775      4.1190677881240845e-01
    z[3,0,5]  R776      1.5191332995891571e-01
    z[3,0,5]  R777      3.1151914596557617e-01
    z[3,0,5]  R778      3.9414763450622559e-01
    z[3,0,5]  R779      2.2859179973602295e-01
    z[3,0,5]  R780      -1.1515405774116516e-01
    z[3,0,5]  R781      -3.2339328527450562e-01
    z[3,0,5]  R782      -1.7447908222675323e-01
    z[3,0,5]  R783      -2.9478749260306358e-02
    z[3,0,5]  R784      0.340032160282135
    z[3,0,5]  R785      1.0683614015579224e-01
    z[3,0,5]  R786      -1.3590057194232941e-01
    z[3,0,5]  R787      -2.6704284548759460e-01
    z[3,0,5]  R788      1.3821706175804138e-01
    z[3,0,5]  R789      -2.4591540917754173e-02
    z[3,0,5]  R790      1.7587290704250336e-01
    z[3,0,5]  R791      -6.7038662731647491e-02
    z[3,0,5]  R792      -1.2629090249538422e-01
    z[3,0,5]  R793      -2.9961558058857918e-02
    z[3,0,5]  R794      1.6140486299991608e-01
    z[3,0,5]  R795      3.3552536368370056e-01
    z[3,0,5]  R796      2.3200479149818420e-01
    z[3,0,5]  R797      1.7891988158226013e-01
    z[3,0,5]  R798      2.6513275504112244e-01
    z[3,0,5]  R799      -8.6372224614024162e-03
    z[3,0,5]  R800      -4.5620220899581909e-01
    z[3,0,5]  R801      -5.3024077415466309e-01
    z[3,0,5]  R802      7.6076802797615528e-03
    z[3,0,5]  R803      -2.6597169041633606e-01
    z[3,0,5]  R804      -1.9071632996201515e-02
    z[3,0,5]  R805      2.7643588185310364e-01
    z[3,0,5]  R806      1.4667242765426636e-02
    z[3,0,5]  R807      1.9412128627300262e-01
    z[3,0,5]  R808      -0.51123046875
    z[3,0,5]  R809      -4.3620994687080383e-01
    z[3,0,5]  R810      3.6117190122604370e-01
    z[3,0,5]  R811      -2.8672000765800476e-01
    z[3,0,5]  R812      -3.2860684394836426e-01
    z[3,0,5]  R813      2.9860296845436096e-01
    z[3,0,5]  R814      1.2046633660793304e-01
    z[3,0,5]  R815      -2.8808993101119995e-01
    z[3,0,5]  R816      4.9473512172698975e-01
    z[3,0,5]  R817      -9.4497554004192352e-02
    z[3,0,5]  R818      2.6760599017143250e-01
    z[3,0,5]  R819      -3.1865677237510681e-01
    z[3,0,5]  R820      4.2646953463554382e-01
    z[3,0,5]  R821      2.1734078228473663e-01
    z[3,0,5]  R822      -1.1890596896409988e-01
    z[3,0,5]  R823      1.2651601433753967e-01
    z[3,0,5]  R824      -2.9000097513198853e-01
    z[3,0,5]  R825      5.5134242773056030e-01
    z[3,0,5]  R826      3.9442360401153564e-01
    z[3,0,5]  R827      5.3061836957931519e-01
    z[3,0,5]  R828      4.0059766173362732e-01
    z[3,0,5]  R829      -2.5622516870498657e-01
    z[3,0,5]  R830      -6.9626617431640625e-01
    z[3,0,5]  R831      -7.0565515756607056e-01
    z[3,0,5]  R832      6.4109876751899719e-02
    z[3,0,5]  R833      -4.1626104712486267e-01
    z[3,0,5]  R834      1.5259596705436707e-01
    z[3,0,5]  R835      -3.7575110793113708e-01
    z[3,0,5]  R836      7.5319744646549225e-02
    z[3,0,5]  R837      1.0449462383985519e-01
    z[3,0,5]  R838      5.2294008433818817e-02
    z[3,0,5]  R839      5.3625613451004028e-01
    z[3,0,5]  R840      4.7479662299156189e-01
    z[3,0,5]  R841      1.4701986312866211e-01
    z[3,0,5]  R842      -2.7418610453605652e-01
    z[3,0,5]  R843      2.6580700278282166e-01
    z[3,0,5]  R844      1.4808274805545807e-01
    z[3,0,5]  R845      0.138405442237854
    z[3,0,5]  R846      2.3203523829579353e-02
    z[3,0,5]  R847      -9.9081307649612427e-02
    z[3,0,5]  R848      -0.170019268989563
    z[3,0,5]  R849      -1.4094074070453644e-01
    z[3,0,5]  R850      1.4805573225021362e-01
    z[3,0,5]  R851      -0.00614133570343256
    z[3,0,5]  R852      -4.6561844646930695e-02
    z[3,0,5]  R853      -2.0218789577484131e-01
    z[3,0,5]  R854      -0.070730060338974
    z[3,0,5]  R855      -0.125872403383255
    z[3,0,5]  R856      1.6337139904499054e-01
    z[3,0,5]  R857      -1.4813865534961224e-02
    z[3,0,5]  R858      5.1943007856607437e-02
    z[3,0,5]  R859      -3.0868789553642273e-01
    z[3,0,5]  R860      -2.3672723770141602e-01
    z[3,0,5]  R861      -1.9990043714642525e-02
    z[3,0,5]  R862      8.1158012151718140e-02
    z[3,0,5]  R863      7.2173632681369781e-02
    z[3,0,5]  R864      2.4948580563068390e-01
    z[3,0,5]  R865      1.4346297085285187e-01
    z[3,0,5]  R866      1.6191197931766510e-01
    z[3,0,5]  R867      1.1874933540821075e-01
    z[3,0,5]  R868      2.5968101620674133e-01
    z[3,0,5]  R869      6.2717609107494354e-03
    z[3,0,5]  R870      -9.1657042503356934e-02
    z[3,0,5]  R871      2.0332394167780876e-02
    z[3,0,5]  R872      -1.4069218933582306e-01
    z[3,0,5]  R873      3.7906490266323090e-02
    z[3,0,5]  R874      4.4746950268745422e-01
    z[3,0,5]  R875      2.4970276653766632e-01
    z[3,0,5]  R876      2.6387146115303040e-01
    z[3,0,5]  R877      1.9971735775470734e-01
    z[3,0,5]  R878      2.0439951121807098e-01
    z[3,0,5]  R879      -3.6918017268180847e-01
    z[3,0,5]  R880      -1.3579083979129791e-01
    z[3,0,5]  R881      3.4114348888397217e-01
    z[3,0,5]  R882      3.0706393718719482e-01
    z[3,0,5]  R883      -1.4180496335029602e-01
    z[3,0,5]  R884      -0.0861627534031868
    z[3,0,5]  R885      2.9993566870689392e-01
    z[3,0,5]  R886      -2.6750189065933228e-01
    z[3,0,5]  R887      6.1956298351287842e-01
    z[3,0,5]  R888      5.0050729513168335e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R737      -1
    z[3,0,6]  R738      1
    z[3,0,6]  R739      -5.1596730947494507e-02
    z[3,0,6]  R740      -9.6031047403812408e-02
    z[3,0,6]  R741      2.4515299499034882e-01
    z[3,0,6]  R742      1.7724240198731422e-02
    z[3,0,6]  R743      1.0169165581464767e-01
    z[3,0,6]  R744      -2.2188175469636917e-02
    z[3,0,6]  R745      9.6747070550918579e-02
    z[3,0,6]  R746      -1.9185002148151398e-01
    z[3,0,6]  R747      -1.8084512650966644e-01
    z[3,0,6]  R748      -2.2686289250850677e-01
    z[3,0,6]  R749      -6.4817108213901520e-02
    z[3,0,6]  R750      4.8896557092666626e-01
    z[3,0,6]  R751      2.9088145494461060e-01
    z[3,0,6]  R752      5.4765480756759644e-01
    z[3,0,6]  R753      -0.0765218734741211
    z[3,0,6]  R754      6.6383326053619385e-01
    z[3,0,6]  R755      -4.8103660345077515e-01
    z[3,0,6]  R756      -3.5973396152257919e-02
    z[3,0,6]  R757      2.7675414457917213e-02
    z[3,0,6]  R758      1.4806197583675385e-01
    z[3,0,6]  R759      6.5325385332107544e-01
    z[3,0,6]  R760      3.9939659833908081e-01
    z[3,0,6]  R761      -3.3355975151062012e-01
    z[3,0,6]  R762      4.4159561395645142e-01
    z[3,0,6]  R763      -2.2576887905597687e-01
    z[3,0,6]  R764      -5.9509657323360443e-02
    z[3,0,6]  R765      2.3087641596794128e-01
    z[3,0,6]  R766      1.8725031614303589e-01
    z[3,0,6]  R767      -2.8318881988525391e-01
    z[3,0,6]  R768      1.7644004523754120e-01
    z[3,0,6]  R769      -1.5983033180236816e-01
    z[3,0,6]  R770      4.8726612329483032e-01
    z[3,0,6]  R771      0.0975242406129837
    z[3,0,6]  R772      -4.5267440378665924e-02
    z[3,0,6]  R773      -7.1026429533958435e-02
    z[3,0,6]  R774      -2.5069704651832581e-01
    z[3,0,6]  R775      -1.2107732892036438e-01
    z[3,0,6]  R776      -1.1193778365850449e-01
    z[3,0,6]  R777      2.6010793447494507e-01
    z[3,0,6]  R778      -2.2518199682235718e-01
    z[3,0,6]  R779      -1.6620095074176788e-01
    z[3,0,6]  R780      -6.4135879278182983e-02
    z[3,0,6]  R781      5.7532179355621338e-01
    z[3,0,6]  R782      -4.4459655880928040e-01
    z[3,0,6]  R783      -7.7958631515502930e-01
    z[3,0,6]  R784      3.5826382040977478e-01
    z[3,0,6]  R785      1.1560061015188694e-02
    z[3,0,6]  R786      9.2273719608783722e-02
    z[3,0,6]  R787      2.0095439627766609e-02
    z[3,0,6]  R788      5.4892235994338989e-01
    z[3,0,6]  R789      -2.7730929851531982e-01
    z[3,0,6]  R790      2.7985206246376038e-01
    z[3,0,6]  R791      -5.0994741916656494e-01
    z[3,0,6]  R792      8.8763415813446045e-02
    z[3,0,6]  R793      0.625530481338501
    z[3,0,6]  R794      -1.4392854273319244e-01
    z[3,0,6]  R795      5.0578240305185318e-02
    z[3,0,6]  R796      -1.0098070651292801e-01
    z[3,0,6]  R797      5.5152767896652222e-01
    z[3,0,6]  R798      2.2399918735027313e-01
    z[3,0,6]  R799      -4.1818860918283463e-02
    z[3,0,6]  R800      -6.8638898432254791e-02
    z[3,0,6]  R801      4.9629233777523041e-02
    z[3,0,6]  R802      4.6015450358390808e-01
    z[3,0,6]  R803      3.5267940163612366e-01
    z[3,0,6]  R804      8.5834264755249023e-02
    z[3,0,6]  R805      3.3901542425155640e-01
    z[3,0,6]  R806      1.1232954263687134e-01
    z[3,0,6]  R807      -7.5245961546897888e-02
    z[3,0,6]  R808      -1.6824442893266678e-02
    z[3,0,6]  R809      -3.7836784124374390e-01
    z[3,0,6]  R810      -3.7656403146684170e-03
    z[3,0,6]  R811      -4.0477716922760010e-01
    z[3,0,6]  R812      0.0537756085395813
    z[3,0,6]  R813      1.2422189861536026e-01
    z[3,0,6]  R814      5.5422705411911011e-01
    z[3,0,6]  R815      4.6610483527183533e-01
    z[3,0,6]  R816      -3.2319790124893188e-01
    z[3,0,6]  R817      -4.0369275212287903e-01
    z[3,0,6]  R818      -3.1184107065200806e-01
    z[3,0,6]  R819      5.3866648674011230e-01
    z[3,0,6]  R820      -2.4914094805717468e-01
    z[3,0,6]  R821      -2.2761613130569458e-01
    z[3,0,6]  R822      -1.4536048471927643e-01
    z[3,0,6]  R823      -5.7595260441303253e-02
    z[3,0,6]  R824      0.00621609203517437
    z[3,0,6]  R825      -3.4228414297103882e-01
    z[3,0,6]  R826      -6.0688531398773193e-01
    z[3,0,6]  R827      -2.4569284915924072e-01
    z[3,0,6]  R828      -1.6450603306293488e-01
    z[3,0,6]  R829      5.8988708257675171e-01
    z[3,0,6]  R830      5.1419258117675781e-01
    z[3,0,6]  R831      4.3201144784688950e-02
    z[3,0,6]  R832      -4.4612166285514832e-01
    z[3,0,6]  R833      -0.28459432721138
    z[3,0,6]  R834      1.2120986357331276e-02
    z[3,0,6]  R835      -3.1471100449562073e-01
    z[3,0,6]  R836      -2.4058060348033905e-01
    z[3,0,6]  R837      -0.128374844789505
    z[3,0,6]  R838      0.0751722976565361
    z[3,0,6]  R839      5.0954829901456833e-02
    z[3,0,6]  R840      2.2015309333801270e-01
    z[3,0,6]  R841      9.5172263681888580e-02
    z[3,0,6]  R842      -1.4934517443180084e-01
    z[3,0,6]  R843      3.6412796378135681e-01
    z[3,0,6]  R844      2.8385373950004578e-01
    z[3,0,6]  R845      -7.6482407748699188e-02
    z[3,0,6]  R846      -4.5404630899429321e-01
    z[3,0,6]  R847      7.5264692306518555e-02
    z[3,0,6]  R848      1.3915333151817322e-01
    z[3,0,6]  R849      -0.0847182348370552
    z[3,0,6]  R850      -1.1609897762537003e-01
    z[3,0,6]  R851      -2.6535862684249878e-01
    z[3,0,6]  R852      1.6977122426033020e-01
    z[3,0,6]  R853      -9.4169579446315765e-02
    z[3,0,6]  R854      -1.9882759451866150e-01
    z[3,0,6]  R855      1.2652884423732758e-01
    z[3,0,6]  R856      1.5812614560127258e-01
    z[3,0,6]  R857      1.3132725842297077e-02
    z[3,0,6]  R858      1.4832308888435364e-01
    z[3,0,6]  R859      -5.8644801378250122e-01
    z[3,0,6]  R860      -9.6080824732780457e-02
    z[3,0,6]  R861      -0.0935017317533493
    z[3,0,6]  R862      4.2079180479049683e-02
    z[3,0,6]  R863      -2.3811565339565277e-01
    z[3,0,6]  R864      1.5567111968994141e-01
    z[3,0,6]  R865      4.1509577631950378e-01
    z[3,0,6]  R866      -0.135938823223114
    z[3,0,6]  R867      2.3738507926464081e-01
    z[3,0,6]  R868      1.1658837087452412e-02
    z[3,0,6]  R869      2.8270691633224487e-01
    z[3,0,6]  R870      -4.6458322554826736e-02
    z[3,0,6]  R871      3.6631596088409424e-01
    z[3,0,6]  R872      -2.9645375907421112e-02
    z[3,0,6]  R873      4.3972063064575195e-01
    z[3,0,6]  R874      -3.2069772481918335e-01
    z[3,0,6]  R875      -4.4085553288459778e-01
    z[3,0,6]  R876      7.9573400318622589e-02
    z[3,0,6]  R877      1.6697552800178528e-01
    z[3,0,6]  R878      -0.261714369058609
    z[3,0,6]  R879      -6.3062274456024170e-01
    z[3,0,6]  R880      3.0303898453712463e-01
    z[3,0,6]  R881      8.4230154752731323e-02
    z[3,0,6]  R882      1.1596415936946869e-01
    z[3,0,6]  R883      1.8427266180515289e-01
    z[3,0,6]  R884      -1.7956189811229706e-01
    z[3,0,6]  R885      -2.8307339549064636e-01
    z[3,0,6]  R886      -8.2004763185977936e-02
    z[3,0,6]  R887      1.5848989784717560e-01
    z[3,0,6]  R888      2.1177372336387634e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R889      -1
    z[0,4,0]  R890      1
    z[0,4,0]  R903      1.3831178843975067e-01
    z[0,4,0]  R904      -2.4963927268981934e-01
    z[0,4,0]  R905      1.5677075088024139e-01
    z[0,4,0]  R906      2.0215308666229248e-01
    z[0,4,0]  R907      3.3621060848236084e-01
    z[0,4,0]  R908      -3.6002430319786072e-01
    z[0,4,0]  R909      2.8251945972442627e-01
    z[0,4,0]  R910      5.3606323897838593e-02
    z[0,4,0]  R911      -2.0865032076835632e-01
    z[0,4,0]  R912      0.0792015790939331
    z[0,4,0]  R913      6.9700604677200317e-01
    z[0,4,0]  R914      4.9385523796081543e-01
    z[0,4,0]  R915      2.7884298563003540e-01
    z[0,4,0]  R916      -6.2758654356002808e-02
    z[0,4,0]  R917      4.4140231609344482e-01
    z[0,4,0]  R918      2.9204022884368896e-01
    z[0,4,0]  R919      0.0990278422832489
    z[0,4,0]  R920      5.6584876775741577e-01
    z[0,4,0]  R921      0.438368558883667
    z[0,4,0]  R922      1.2508645653724670e-01
    z[0,4,0]  R923      4.1417360305786133e-01
    z[0,4,0]  R924      4.1959103941917419e-01
    z[0,4,0]  R925      5.5644816160202026e-01
    z[0,4,0]  R926      6.3575762510299683e-01
    z[0,4,0]  R927      4.1316190361976624e-01
    z[0,4,0]  R928      3.8598445057868958e-01
    z[0,4,0]  R929      2.8113448619842529e-01
    z[0,4,0]  R930      2.4223934113979340e-01
    z[0,4,0]  R931      -3.3876141905784607e-01
    z[0,4,0]  R932      1.6936412453651428e-01
    z[0,4,0]  R933      -2.2780045866966248e-01
    z[0,4,0]  R934      5.2210664749145508e-01
    z[0,4,0]  R935      4.7280839085578918e-01
    z[0,4,0]  R936      3.7545260787010193e-01
    z[0,4,0]  R937      -4.0232321619987488e-01
    z[0,4,0]  R938      4.7286859154701233e-01
    z[0,4,0]  R939      -1.9411759078502655e-01
    z[0,4,0]  R940      9.3059904873371124e-02
    z[0,4,0]  R941      4.1530004143714905e-01
    z[0,4,0]  R942      2.9094433784484863e-01
    z[0,4,0]  R943      4.4050028920173645e-01
    z[0,4,0]  R944      -3.1407541036605835e-01
    z[0,4,0]  R945      -2.5384524837136269e-02
    z[0,4,0]  R946      1.2459943443536758e-01
    z[0,4,0]  R947      -2.3517280817031860e-01
    z[0,4,0]  R948      -5.2083592861890793e-02
    z[0,4,0]  R949      1.4811287820339203e-01
    z[0,4,0]  R950      -6.3537520170211792e-01
    z[0,4,0]  R951      -6.4471709728240967e-01
    z[0,4,0]  R952      -6.5766119956970215e-01
    z[0,4,0]  R953      1.2397421896457672e-01
    z[0,4,0]  R954      6.3077318668365479e-01
    z[0,4,0]  R955      5.0213652849197388e-01
    z[0,4,0]  R956      2.0148406922817230e-01
    z[0,4,0]  R957      -4.1290480643510818e-02
    z[0,4,0]  R958      9.4691142439842224e-02
    z[0,4,0]  R959      -2.8340309858322144e-02
    z[0,4,0]  R960      -2.4740856885910034e-01
    z[0,4,0]  R961      -3.0452784895896912e-01
    z[0,4,0]  R962      -3.8870215415954590e-01
    z[0,4,0]  R963      -0.626301646232605
    z[0,4,0]  R964      -8.4204000234603882e-01
    z[0,4,0]  R965      -5.6200635433197021e-01
    z[0,4,0]  R966      -5.3218764066696167e-01
    z[0,4,0]  R967      -0.939971387386322
    z[0,4,0]  R968      6.5989071130752563e-01
    z[0,4,0]  R969      -9.3661779165267944e-01
    z[0,4,0]  R970      5.6124496459960938e-01
    z[0,4,0]  R971      -8.1057894229888916e-01
    z[0,4,0]  R972      -8.1453180313110352e-01
    z[0,4,0]  R973      -1.3804477453231812e-01
    z[0,4,0]  R974      -1.4331266283988953e-01
    z[0,4,0]  R975      1.3529990613460541e-01
    z[0,4,0]  R976      1.8741910159587860e-01
    z[0,4,0]  R977      1.1734388023614883e-01
    z[0,4,0]  R978      -1.5084441751241684e-02
    z[0,4,0]  R979      -4.1426301002502441e-01
    z[0,4,0]  R980      8.9693886041641235e-01
    z[0,4,0]  R981      7.0947146415710449e-01
    z[0,4,0]  R982      0.85356205701828
    z[0,4,0]  R983      6.7912268638610840e-01
    z[0,4,0]  R984      4.6549555659294128e-01
    z[0,4,0]  R985      -7.0993238687515259e-01
    z[0,4,0]  R986      7.1068447828292847e-01
    z[0,4,0]  R987      4.5530465245246887e-01
    z[0,4,0]  R988      0.552579402923584
    z[0,4,0]  R989      5.8852738142013550e-01
    z[0,4,0]  R990      -3.5320860147476196e-01
    z[0,4,0]  R991      -0.319614976644516
    z[0,4,0]  R992      -2.3107655346393585e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R891      -1
    z[0,4,1]  R892      1
    z[0,4,1]  R903      5.4261481761932373e-01
    z[0,4,1]  R904      1.8471740186214447e-01
    z[0,4,1]  R905      4.8204636573791504e-01
    z[0,4,1]  R906      6.2353205680847168e-01
    z[0,4,1]  R907      3.3489429950714111e-01
    z[0,4,1]  R908      -8.1334710121154785e-01
    z[0,4,1]  R909      -6.8163412809371948e-01
    z[0,4,1]  R910      -7.3793184757232666e-01
    z[0,4,1]  R911      -6.2932431697845459e-01
    z[0,4,1]  R912      -4.5561450719833374e-01
    z[0,4,1]  R913      2.6548174023628235e-01
    z[0,4,1]  R914      1.7883922159671783e-01
    z[0,4,1]  R915      2.4211584031581879e-01
    z[0,4,1]  R916      -3.7438550591468811e-01
    z[0,4,1]  R917      -6.9548559188842773e-01
    z[0,4,1]  R918      -8.1426960229873657e-01
    z[0,4,1]  R919      -8.8026142120361328e-01
    z[0,4,1]  R920      -5.5686980485916138e-01
    z[0,4,1]  R921      -6.1559689044952393e-01
    z[0,4,1]  R922      -8.6519724130630493e-01
    z[0,4,1]  R923      -7.8430545330047607e-01
    z[0,4,1]  R924      -8.8759505748748779e-01
    z[0,4,1]  R925      -7.8066098690032959e-01
    z[0,4,1]  R926      -7.2174870967864990e-01
    z[0,4,1]  R927      -0.579284131526947
    z[0,4,1]  R928      -0.739266574382782
    z[0,4,1]  R929      -7.4926763772964478e-01
    z[0,4,1]  R930      -0.616884171962738
    z[0,4,1]  R931      -8.8023918867111206e-01
    z[0,4,1]  R932      -8.8934975862503052e-01
    z[0,4,1]  R933      -6.0995358228683472e-01
    z[0,4,1]  R934      -6.6779989004135132e-01
    z[0,4,1]  R935      -5.9846210479736328e-01
    z[0,4,1]  R936      -8.5873937606811523e-01
    z[0,4,1]  R937      -4.8705798387527466e-01
    z[0,4,1]  R938      -5.8593922853469849e-01
    z[0,4,1]  R939      -8.4706974029541016e-01
    z[0,4,1]  R940      -8.3782196044921875e-01
    z[0,4,1]  R941      -7.2321790456771851e-01
    z[0,4,1]  R942      -6.1781018972396851e-01
    z[0,4,1]  R943      -8.2881647348403931e-01
    z[0,4,1]  R944      -9.0422928333282471e-01
    z[0,4,1]  R945      -9.0046817064285278e-01
    z[0,4,1]  R946      -9.6193933486938477e-01
    z[0,4,1]  R947      -0.798782229423523
    z[0,4,1]  R948      -7.6137822866439819e-01
    z[0,4,1]  R949      -4.1610002517700195e-01
    z[0,4,1]  R950      7.1338564157485962e-02
    z[0,4,1]  R951      9.2577107250690460e-02
    z[0,4,1]  R952      7.7672697603702545e-02
    z[0,4,1]  R953      -5.9112477302551270e-01
    z[0,4,1]  R954      -0.6157186627388
    z[0,4,1]  R955      -6.7031729221343994e-01
    z[0,4,1]  R956      -9.1305035352706909e-01
    z[0,4,1]  R957      -9.5023977756500244e-01
    z[0,4,1]  R958      -8.8946694135665894e-01
    z[0,4,1]  R959      -8.7520343065261841e-01
    z[0,4,1]  R960      -7.9479080438613892e-01
    z[0,4,1]  R961      0.0364716611802578
    z[0,4,1]  R962      1.9382598996162415e-01
    z[0,4,1]  R963      -0.575942873954773
    z[0,4,1]  R964      -8.1678695976734161e-02
    z[0,4,1]  R965      -1.9468982517719269e-01
    z[0,4,1]  R966      -8.7245449423789978e-02
    z[0,4,1]  R967      -1.4296740293502808e-01
    z[0,4,1]  R968      1.5793354809284210e-01
    z[0,4,1]  R969      6.2615498900413513e-02
    z[0,4,1]  R970      -8.5508622229099274e-02
    z[0,4,1]  R971      2.1103753149509430e-01
    z[0,4,1]  R972      0.0857396051287651
    z[0,4,1]  R973      8.7869238853454590e-01
    z[0,4,1]  R974      7.4564278125762939e-01
    z[0,4,1]  R975      0.814132571220398
    z[0,4,1]  R976      8.3106732368469238e-01
    z[0,4,1]  R977      0.913650393486023
    z[0,4,1]  R978      9.2196524143218994e-01
    z[0,4,1]  R979      6.8651187419891357e-01
    z[0,4,1]  R980      -3.4975543618202209e-01
    z[0,4,1]  R981      -2.1639437973499298e-01
    z[0,4,1]  R982      3.3483337610960007e-02
    z[0,4,1]  R983      -5.4730284214019775e-01
    z[0,4,1]  R984      -1.0956397652626038e-01
    z[0,4,1]  R985      0.00622505834326148
    z[0,4,1]  R986      5.1804497838020325e-02
    z[0,4,1]  R987      -2.2204600274562836e-01
    z[0,4,1]  R988      -2.3661231622099876e-02
    z[0,4,1]  R989      2.3132576048374176e-01
    z[0,4,1]  R990      -6.3067066669464111e-01
    z[0,4,1]  R991      -8.3851498365402222e-01
    z[0,4,1]  R992      -6.7305499315261841e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R893      -1
    z[0,4,2]  R894      1
    z[0,4,2]  R903      4.3849232792854309e-01
    z[0,4,2]  R904      3.3853515982627869e-01
    z[0,4,2]  R905      9.4243094325065613e-02
    z[0,4,2]  R906      0.582205593585968
    z[0,4,2]  R907      3.9551305770874023e-01
    z[0,4,2]  R908      5.2726618014276028e-03
    z[0,4,2]  R909      -3.3160638064146042e-02
    z[0,4,2]  R910      1.5954692661762238e-01
    z[0,4,2]  R911      7.1214497089385986e-01
    z[0,4,2]  R912      2.3050554096698761e-01
    z[0,4,2]  R913      -3.3334669470787048e-01
    z[0,4,2]  R914      5.5639997124671936e-02
    z[0,4,2]  R915      -2.0356020331382751e-01
    z[0,4,2]  R916      -2.3002997040748596e-01
    z[0,4,2]  R917      -2.8369075059890747e-01
    z[0,4,2]  R918      3.8147693872451782e-01
    z[0,4,2]  R919      2.3826966062188148e-02
    z[0,4,2]  R920      -2.9808353632688522e-02
    z[0,4,2]  R921      -2.7991554141044617e-01
    z[0,4,2]  R922      -1.5095798298716545e-02
    z[0,4,2]  R923      -3.7754490971565247e-01
    z[0,4,2]  R924      -1.0950003750622272e-02
    z[0,4,2]  R925      2.4025326129049063e-03
    z[0,4,2]  R926      1.3460588455200195e-01
    z[0,4,2]  R927      -2.1773955225944519e-01
    z[0,4,2]  R928      -2.7437901496887207e-01
    z[0,4,2]  R929      -9.9309816956520081e-02
    z[0,4,2]  R930      -4.0018233656883240e-01
    z[0,4,2]  R931      -1.9711470603942871e-01
    z[0,4,2]  R932      -1.2846191413700581e-02
    z[0,4,2]  R933      2.4511611461639404e-01
    z[0,4,2]  R934      6.2628291547298431e-02
    z[0,4,2]  R935      1.0547447949647903e-01
    z[0,4,2]  R936      3.3033019304275513e-01
    z[0,4,2]  R937      6.6327786445617676e-01
    z[0,4,2]  R938      8.1514120101928711e-02
    z[0,4,2]  R939      -1.3852171599864960e-01
    z[0,4,2]  R940      4.2326194047927856e-01
    z[0,4,2]  R941      -4.6761423349380493e-02
    z[0,4,2]  R942      3.7887477874755859e-01
    z[0,4,2]  R943      -9.9935494363307953e-02
    z[0,4,2]  R944      1.0055445134639740e-01
    z[0,4,2]  R945      2.0335851609706879e-01
    z[0,4,2]  R946      -1.0601404309272766e-01
    z[0,4,2]  R947      -1.2080924212932587e-01
    z[0,4,2]  R948      -3.1700644642114639e-02
    z[0,4,2]  R949      -3.3466815948486328e-01
    z[0,4,2]  R950      -0.687119722366333
    z[0,4,2]  R951      -6.4685958623886108e-01
    z[0,4,2]  R952      -6.0850036144256592e-01
    z[0,4,2]  R953      2.5499412789940834e-02
    z[0,4,2]  R954      5.7227391749620438e-02
    z[0,4,2]  R955      2.2832669317722321e-01
    z[0,4,2]  R956      -1.0725231468677521e-01
    z[0,4,2]  R957      1.5175219625234604e-02
    z[0,4,2]  R958      2.7799534797668457e-01
    z[0,4,2]  R959      -1.1042208969593048e-01
    z[0,4,2]  R960      -4.4454595446586609e-01
    z[0,4,2]  R961      5.8498613536357880e-02
    z[0,4,2]  R962      -3.2437656074762344e-02
    z[0,4,2]  R963      3.8755902647972107e-01
    z[0,4,2]  R964      4.8647314310073853e-01
    z[0,4,2]  R965      6.0824459791183472e-01
    z[0,4,2]  R966      4.3417137861251831e-01
    z[0,4,2]  R967      -1.4967535436153412e-01
    z[0,4,2]  R968      -4.1559547185897827e-01
    z[0,4,2]  R969      -1.9692401587963104e-01
    z[0,4,2]  R970      -1.1192564666271210e-01
    z[0,4,2]  R971      -1.9925747811794281e-01
    z[0,4,2]  R972      4.4076152145862579e-02
    z[0,4,2]  R973      -0.348624587059021
    z[0,4,2]  R974      -5.3115451335906982e-01
    z[0,4,2]  R975      -3.2606229186058044e-01
    z[0,4,2]  R976      -2.7933281660079956e-01
    z[0,4,2]  R977      -0.0719640925526619
    z[0,4,2]  R978      -0.0854223445057869
    z[0,4,2]  R979      -3.4509435296058655e-01
    z[0,4,2]  R980      1.6582074761390686e-01
    z[0,4,2]  R981      2.6561295986175537e-01
    z[0,4,2]  R982      3.1241217255592346e-01
    z[0,4,2]  R983      3.5691785160452127e-03
    z[0,4,2]  R984      -2.1841278672218323e-01
    z[0,4,2]  R985      3.8633834570646286e-02
    z[0,4,2]  R986      1.4892983436584473e-01
    z[0,4,2]  R987      -1.7980413138866425e-01
    z[0,4,2]  R988      0.190543994307518
    z[0,4,2]  R989      1.6353680193424225e-01
    z[0,4,2]  R990      -0.352943480014801
    z[0,4,2]  R991      -8.0922663211822510e-02
    z[0,4,2]  R992      -1.6812250018119812e-02
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R895      -1
    z[0,4,3]  R896      1
    z[0,4,3]  R903      -2.7918061614036560e-01
    z[0,4,3]  R904      -1.5112577378749847e-01
    z[0,4,3]  R905      -3.8952809572219849e-01
    z[0,4,3]  R906      -2.6958325877785683e-02
    z[0,4,3]  R907      -0.576545238494873
    z[0,4,3]  R908      4.2964771389961243e-01
    z[0,4,3]  R909      3.6707094311714172e-01
    z[0,4,3]  R910      4.9446511268615723e-01
    z[0,4,3]  R911      -8.6714506149291992e-02
    z[0,4,3]  R912      8.4276819229125977e-01
    z[0,4,3]  R913      -1.5110825002193451e-01
    z[0,4,3]  R914      4.4408398866653442e-01
    z[0,4,3]  R915      4.9077352881431580e-01
    z[0,4,3]  R916      3.7115055322647095e-01
    z[0,4,3]  R917      1.4902465045452118e-01
    z[0,4,3]  R918      5.3401932120323181e-02
    z[0,4,3]  R919      -2.3090282082557678e-01
    z[0,4,3]  R920      2.8796160221099854e-01
    z[0,4,3]  R921      2.4158558249473572e-01
    z[0,4,3]  R922      -3.7723553180694580e-01
    z[0,4,3]  R923      1.8693108856678009e-01
    z[0,4,3]  R924      4.9490388482809067e-03
    z[0,4,3]  R925      -1.4407569542527199e-02
    z[0,4,3]  R926      -0.00487411767244339
    z[0,4,3]  R927      6.2143850326538086e-01
    z[0,4,3]  R928      1.7748048901557922e-01
    z[0,4,3]  R929      3.9502236247062683e-01
    z[0,4,3]  R930      5.5404853820800781e-01
    z[0,4,3]  R931      -1.6640393063426018e-02
    z[0,4,3]  R932      2.5008162856101990e-01
    z[0,4,3]  R933      0.254672646522522
    z[0,4,3]  R934      4.5510622859001160e-01
    z[0,4,3]  R935      5.9680455923080444e-01
    z[0,4,3]  R936      2.9364828020334244e-02
    z[0,4,3]  R937      2.8551253676414490e-01
    z[0,4,3]  R938      4.4502565264701843e-01
    z[0,4,3]  R939      6.2376689165830612e-02
    z[0,4,3]  R940      2.4847450852394104e-01
    z[0,4,3]  R941      7.0948116481304169e-02
    z[0,4,3]  R942      5.4908853769302368e-01
    z[0,4,3]  R943      1.2764946557581425e-02
    z[0,4,3]  R944      2.4747721850872040e-01
    z[0,4,3]  R945      6.0122460126876831e-02
    z[0,4,3]  R946      -7.7999327331781387e-03
    z[0,4,3]  R947      2.8803277015686035e-01
    z[0,4,3]  R948      2.4187400937080383e-01
    z[0,4,3]  R949      6.3066351413726807e-01
    z[0,4,3]  R950      -1.0523796826601028e-01
    z[0,4,3]  R951      2.9216054081916809e-01
    z[0,4,3]  R952      1.7974372208118439e-01
    z[0,4,3]  R953      -3.1478229910135269e-02
    z[0,4,3]  R954      3.1292641162872314e-01
    z[0,4,3]  R955      3.5052257776260376e-01
    z[0,4,3]  R956      7.7737748622894287e-02
    z[0,4,3]  R957      -1.4659301936626434e-01
    z[0,4,3]  R958      -1.6012732684612274e-01
    z[0,4,3]  R959      1.8675832450389862e-01
    z[0,4,3]  R960      3.9999779313802719e-02
    z[0,4,3]  R961      5.6568211317062378e-01
    z[0,4,3]  R962      6.6492003202438354e-01
    z[0,4,3]  R963      -1.1291564255952835e-01
    z[0,4,3]  R964      -4.3126974254846573e-02
    z[0,4,3]  R965      -8.4073126316070557e-02
    z[0,4,3]  R966      -1.1861911416053772e-01
    z[0,4,3]  R967      -2.1147488057613373e-01
    z[0,4,3]  R968      1.1938295327126980e-02
    z[0,4,3]  R969      -3.3003918826580048e-02
    z[0,4,3]  R970      -7.1461528539657593e-02
    z[0,4,3]  R971      -3.5813751816749573e-01
    z[0,4,3]  R972      3.7784200906753540e-01
    z[0,4,3]  R973      2.3530612885951996e-01
    z[0,4,3]  R974      -1.9758237898349762e-01
    z[0,4,3]  R975      3.5624884068965912e-02
    z[0,4,3]  R976      -0.330709308385849
    z[0,4,3]  R977      1.2008894234895706e-01
    z[0,4,3]  R978      -4.6502269804477692e-02
    z[0,4,3]  R979      -2.7664867043495178e-01
    z[0,4,3]  R980      -7.3545746505260468e-02
    z[0,4,3]  R981      -1.3987350463867188e-01
    z[0,4,3]  R982      7.3284611105918884e-02
    z[0,4,3]  R983      -1.9933162629604340e-01
    z[0,4,3]  R984      -1.5276260673999786e-01
    z[0,4,3]  R985      5.7509493827819824e-01
    z[0,4,3]  R986      -4.4765692949295044e-01
    z[0,4,3]  R987      -7.7382522821426392e-01
    z[0,4,3]  R988      7.6344740390777588e-01
    z[0,4,3]  R989      5.8561843633651733e-01
    z[0,4,3]  R990      4.7341939806938171e-01
    z[0,4,3]  R991      2.2318008542060852e-01
    z[0,4,3]  R992      3.6834666132926941e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R897      -1
    z[0,4,4]  R898      1
    z[0,4,4]  R903      -5.1024895161390305e-02
    z[0,4,4]  R904      1.3013137876987457e-01
    z[0,4,4]  R905      2.8744551539421082e-01
    z[0,4,4]  R906      -1.6588295996189117e-01
    z[0,4,4]  R907      -1.7806215584278107e-01
    z[0,4,4]  R908      -2.8135115280747414e-02
    z[0,4,4]  R909      -2.8193125128746033e-01
    z[0,4,4]  R910      3.4507939219474792e-01
    z[0,4,4]  R911      -1.3545063138008118e-01
    z[0,4,4]  R912      1.1985806375741959e-01
    z[0,4,4]  R913      1.3993303477764130e-01
    z[0,4,4]  R914      4.9991786479949951e-01
    z[0,4,4]  R915      7.4206370115280151e-01
    z[0,4,4]  R916      7.5349074602127075e-01
    z[0,4,4]  R917      -1.2462893128395081e-01
    z[0,4,4]  R918      -0.0282792616635561
    z[0,4,4]  R919      -3.6938312649726868e-01
    z[0,4,4]  R920      -2.8143274784088135e-01
    z[0,4,4]  R921      -5.2599930763244629e-01
    z[0,4,4]  R922      -2.1209090948104858e-01
    z[0,4,4]  R923      -9.3808978796005249e-02
    z[0,4,4]  R924      -2.3968910798430443e-02
    z[0,4,4]  R925      1.0132896155118942e-01
    z[0,4,4]  R926      -1.6049362719058990e-01
    z[0,4,4]  R927      1.0189700871706009e-01
    z[0,4,4]  R928      3.9138558506965637e-01
    z[0,4,4]  R929      4.0224725008010864e-01
    z[0,4,4]  R930      2.0485168695449829e-01
    z[0,4,4]  R931      -2.6626411080360413e-01
    z[0,4,4]  R932      3.0490845441818237e-01
    z[0,4,4]  R933      1.0915137827396393e-01
    z[0,4,4]  R934      7.1642078459262848e-02
    z[0,4,4]  R935      2.0457884669303894e-01
    z[0,4,4]  R936      5.7132825255393982e-02
    z[0,4,4]  R937      1.3246698677539825e-01
    z[0,4,4]  R938      -3.7669813632965088e-01
    z[0,4,4]  R939      -1.6978222131729126e-01
    z[0,4,4]  R940      -6.1717376112937927e-02
    z[0,4,4]  R941      -4.7624397277832031e-01
    z[0,4,4]  R942      -1.4507827162742615e-01
    z[0,4,4]  R943      -1.7002993822097778e-01
    z[0,4,4]  R944      -4.2550783604383469e-02
    z[0,4,4]  R945      -9.4564616680145264e-02
    z[0,4,4]  R946      1.6484777629375458e-01
    z[0,4,4]  R947      1.1954781413078308e-01
    z[0,4,4]  R948      -2.3453450202941895e-01
    z[0,4,4]  R949      -1.9616085290908813e-01
    z[0,4,4]  R950      -1.7899875342845917e-01
    z[0,4,4]  R951      -6.4933754503726959e-02
    z[0,4,4]  R952      -2.2044228017330170e-01
    z[0,4,4]  R953      3.1556585431098938e-01
    z[0,4,4]  R954      1.0745245218276978e-01
    z[0,4,4]  R955      -7.7980393543839455e-03
    z[0,4,4]  R956      -2.1471410989761353e-02
    z[0,4,4]  R957      -1.3983753323554993e-01
    z[0,4,4]  R958      -2.3936058580875397e-01
    z[0,4,4]  R959      -1.2669727206230164e-01
    z[0,4,4]  R960      1.7202737927436829e-01
    z[0,4,4]  R961      -4.1657772660255432e-01
    z[0,4,4]  R962      -2.6984393596649170e-01
    z[0,4,4]  R963      -1.3108095526695251e-01
    z[0,4,4]  R964      1.7517803609371185e-01
    z[0,4,4]  R965      -5.0521481037139893e-01
    z[0,4,4]  R966      -3.7098596803843975e-03
    z[0,4,4]  R967      -7.8253731131553650e-02
    z[0,4,4]  R968      1.8952155485749245e-02
    z[0,4,4]  R969      1.0351741313934326e-01
    z[0,4,4]  R970      -3.0360710620880127e-01
    z[0,4,4]  R971      -2.0744135975837708e-01
    z[0,4,4]  R972      -2.9577660560607910e-01
    z[0,4,4]  R973      6.2534660100936890e-02
    z[0,4,4]  R974      2.8456097841262817e-01
    z[0,4,4]  R975      4.0337464213371277e-01
    z[0,4,4]  R976      7.7082134783267975e-02
    z[0,4,4]  R977      1.1331208795309067e-01
    z[0,4,4]  R978      -2.6226335763931274e-01
    z[0,4,4]  R979      -3.4285095334053040e-01
    z[0,4,4]  R980      8.8250853121280670e-02
    z[0,4,4]  R981      2.7964314818382263e-01
    z[0,4,4]  R982      8.8019356131553650e-02
    z[0,4,4]  R983      3.6297035217285156e-01
    z[0,4,4]  R984      6.8603962659835815e-02
    z[0,4,4]  R985      2.4468223750591278e-01
    z[0,4,4]  R986      -4.6644932031631470e-01
    z[0,4,4]  R987      -3.0253347754478455e-01
    z[0,4,4]  R988      3.5661216825246811e-02
    z[0,4,4]  R989      -2.8646424412727356e-01
    z[0,4,4]  R990      -1.2093091756105423e-01
    z[0,4,4]  R991      8.1553466618061066e-02
    z[0,4,4]  R992      -5.2477353811264038e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R899      -1
    z[0,4,5]  R900      1
    z[0,4,5]  R903      -2.5622516870498657e-01
    z[0,4,5]  R904      -6.9626617431640625e-01
    z[0,4,5]  R905      -7.0565515756607056e-01
    z[0,4,5]  R906      6.4109876751899719e-02
    z[0,4,5]  R907      -4.1626104712486267e-01
    z[0,4,5]  R908      1.5259596705436707e-01
    z[0,4,5]  R909      -3.7575110793113708e-01
    z[0,4,5]  R910      7.5319744646549225e-02
    z[0,4,5]  R911      1.0449462383985519e-01
    z[0,4,5]  R912      5.2294008433818817e-02
    z[0,4,5]  R913      5.3625613451004028e-01
    z[0,4,5]  R914      4.7479662299156189e-01
    z[0,4,5]  R915      1.4701986312866211e-01
    z[0,4,5]  R916      -2.7418610453605652e-01
    z[0,4,5]  R917      2.6580700278282166e-01
    z[0,4,5]  R918      1.4808274805545807e-01
    z[0,4,5]  R919      0.138405442237854
    z[0,4,5]  R920      2.3203523829579353e-02
    z[0,4,5]  R921      -9.9081307649612427e-02
    z[0,4,5]  R922      -0.170019268989563
    z[0,4,5]  R923      -1.4094074070453644e-01
    z[0,4,5]  R924      1.4805573225021362e-01
    z[0,4,5]  R925      -0.00614133570343256
    z[0,4,5]  R926      -4.6561844646930695e-02
    z[0,4,5]  R927      -2.0218789577484131e-01
    z[0,4,5]  R928      -0.070730060338974
    z[0,4,5]  R929      -0.125872403383255
    z[0,4,5]  R930      1.6337139904499054e-01
    z[0,4,5]  R931      -1.4813865534961224e-02
    z[0,4,5]  R932      5.1943007856607437e-02
    z[0,4,5]  R933      -3.0868789553642273e-01
    z[0,4,5]  R934      -2.3672723770141602e-01
    z[0,4,5]  R935      -1.9990043714642525e-02
    z[0,4,5]  R936      8.1158012151718140e-02
    z[0,4,5]  R937      7.2173632681369781e-02
    z[0,4,5]  R938      2.4948580563068390e-01
    z[0,4,5]  R939      1.4346297085285187e-01
    z[0,4,5]  R940      1.6191197931766510e-01
    z[0,4,5]  R941      1.1874933540821075e-01
    z[0,4,5]  R942      2.5968101620674133e-01
    z[0,4,5]  R943      6.2717609107494354e-03
    z[0,4,5]  R944      -9.1657042503356934e-02
    z[0,4,5]  R945      2.0332394167780876e-02
    z[0,4,5]  R946      -1.4069218933582306e-01
    z[0,4,5]  R947      3.7906490266323090e-02
    z[0,4,5]  R948      4.4746950268745422e-01
    z[0,4,5]  R949      2.4970276653766632e-01
    z[0,4,5]  R950      2.6387146115303040e-01
    z[0,4,5]  R951      1.9971735775470734e-01
    z[0,4,5]  R952      2.0439951121807098e-01
    z[0,4,5]  R953      -3.6918017268180847e-01
    z[0,4,5]  R954      -1.3579083979129791e-01
    z[0,4,5]  R955      3.4114348888397217e-01
    z[0,4,5]  R956      3.0706393718719482e-01
    z[0,4,5]  R957      -1.4180496335029602e-01
    z[0,4,5]  R958      -0.0861627534031868
    z[0,4,5]  R959      2.9993566870689392e-01
    z[0,4,5]  R960      -2.6750189065933228e-01
    z[0,4,5]  R961      6.1956298351287842e-01
    z[0,4,5]  R962      5.0050729513168335e-01
    z[0,4,5]  R963      -2.7850124239921570e-01
    z[0,4,5]  R964      1.2280213832855225e-01
    z[0,4,5]  R965      4.8055514693260193e-02
    z[0,4,5]  R966      -3.5813519358634949e-01
    z[0,4,5]  R967      8.1823609769344330e-02
    z[0,4,5]  R968      -3.6321735382080078e-01
    z[0,4,5]  R969      -2.6041004061698914e-01
    z[0,4,5]  R970      -6.7825573682785034e-01
    z[0,4,5]  R971      -1.2281390838325024e-02
    z[0,4,5]  R972      3.1469874083995819e-02
    z[0,4,5]  R973      5.8050606399774551e-02
    z[0,4,5]  R974      -1.4533384144306183e-01
    z[0,4,5]  R975      1.5770610189065337e-03
    z[0,4,5]  R976      1.1847331374883652e-01
    z[0,4,5]  R977      -4.4052530080080032e-02
    z[0,4,5]  R978      2.4003873765468597e-01
    z[0,4,5]  R979      -1.1766491085290909e-01
    z[0,4,5]  R980      1.6332441568374634e-01
    z[0,4,5]  R981      -1.0694076865911484e-01
    z[0,4,5]  R982      1.6248992085456848e-01
    z[0,4,5]  R983      -2.2576166689395905e-01
    z[0,4,5]  R984      -8.2591855525970459e-01
    z[0,4,5]  R985      3.0087551474571228e-01
    z[0,4,5]  R986      -1.8919488787651062e-01
    z[0,4,5]  R987      -1.0286095738410950e-01
    z[0,4,5]  R988      -9.0068064630031586e-02
    z[0,4,5]  R989      1.7317394912242889e-01
    z[0,4,5]  R990      2.8762108087539673e-01
    z[0,4,5]  R991      3.4940522909164429e-01
    z[0,4,5]  R992      2.5666022300720215e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R901      -1
    z[0,4,6]  R902      1
    z[0,4,6]  R903      5.8988708257675171e-01
    z[0,4,6]  R904      5.1419258117675781e-01
    z[0,4,6]  R905      4.3201144784688950e-02
    z[0,4,6]  R906      -4.4612166285514832e-01
    z[0,4,6]  R907      -0.28459432721138
    z[0,4,6]  R908      1.2120986357331276e-02
    z[0,4,6]  R909      -3.1471100449562073e-01
    z[0,4,6]  R910      -2.4058060348033905e-01
    z[0,4,6]  R911      -0.128374844789505
    z[0,4,6]  R912      0.0751722976565361
    z[0,4,6]  R913      5.0954829901456833e-02
    z[0,4,6]  R914      2.2015309333801270e-01
    z[0,4,6]  R915      9.5172263681888580e-02
    z[0,4,6]  R916      -1.4934517443180084e-01
    z[0,4,6]  R917      3.6412796378135681e-01
    z[0,4,6]  R918      2.8385373950004578e-01
    z[0,4,6]  R919      -7.6482407748699188e-02
    z[0,4,6]  R920      -4.5404630899429321e-01
    z[0,4,6]  R921      7.5264692306518555e-02
    z[0,4,6]  R922      1.3915333151817322e-01
    z[0,4,6]  R923      -0.0847182348370552
    z[0,4,6]  R924      -1.1609897762537003e-01
    z[0,4,6]  R925      -2.6535862684249878e-01
    z[0,4,6]  R926      1.6977122426033020e-01
    z[0,4,6]  R927      -9.4169579446315765e-02
    z[0,4,6]  R928      -1.9882759451866150e-01
    z[0,4,6]  R929      1.2652884423732758e-01
    z[0,4,6]  R930      1.5812614560127258e-01
    z[0,4,6]  R931      1.3132725842297077e-02
    z[0,4,6]  R932      1.4832308888435364e-01
    z[0,4,6]  R933      -5.8644801378250122e-01
    z[0,4,6]  R934      -9.6080824732780457e-02
    z[0,4,6]  R935      -0.0935017317533493
    z[0,4,6]  R936      4.2079180479049683e-02
    z[0,4,6]  R937      -2.3811565339565277e-01
    z[0,4,6]  R938      1.5567111968994141e-01
    z[0,4,6]  R939      4.1509577631950378e-01
    z[0,4,6]  R940      -0.135938823223114
    z[0,4,6]  R941      2.3738507926464081e-01
    z[0,4,6]  R942      1.1658837087452412e-02
    z[0,4,6]  R943      2.8270691633224487e-01
    z[0,4,6]  R944      -4.6458322554826736e-02
    z[0,4,6]  R945      3.6631596088409424e-01
    z[0,4,6]  R946      -2.9645375907421112e-02
    z[0,4,6]  R947      4.3972063064575195e-01
    z[0,4,6]  R948      -3.2069772481918335e-01
    z[0,4,6]  R949      -4.4085553288459778e-01
    z[0,4,6]  R950      7.9573400318622589e-02
    z[0,4,6]  R951      1.6697552800178528e-01
    z[0,4,6]  R952      -0.261714369058609
    z[0,4,6]  R953      -6.3062274456024170e-01
    z[0,4,6]  R954      3.0303898453712463e-01
    z[0,4,6]  R955      8.4230154752731323e-02
    z[0,4,6]  R956      1.1596415936946869e-01
    z[0,4,6]  R957      1.8427266180515289e-01
    z[0,4,6]  R958      -1.7956189811229706e-01
    z[0,4,6]  R959      -2.8307339549064636e-01
    z[0,4,6]  R960      -8.2004763185977936e-02
    z[0,4,6]  R961      1.5848989784717560e-01
    z[0,4,6]  R962      2.1177372336387634e-01
    z[0,4,6]  R963      1.3542146980762482e-01
    z[0,4,6]  R964      -0.00367422285489738
    z[0,4,6]  R965      -1.0799888521432877e-01
    z[0,4,6]  R966      -6.1507290601730347e-01
    z[0,4,6]  R967      1.2677150964736938e-01
    z[0,4,6]  R968      4.8420354723930359e-01
    z[0,4,6]  R969      2.0706895738840103e-02
    z[0,4,6]  R970      3.2840543985366821e-01
    z[0,4,6]  R971      -2.9542544484138489e-01
    z[0,4,6]  R972      3.0984729528427124e-01
    z[0,4,6]  R973      1.5701831877231598e-01
    z[0,4,6]  R974      -1.4757920987904072e-02
    z[0,4,6]  R975      -2.2041529417037964e-01
    z[0,4,6]  R976      -2.5851166248321533e-01
    z[0,4,6]  R977      -3.4218841791152954e-01
    z[0,4,6]  R978      -1.1786611378192902e-01
    z[0,4,6]  R979      1.7341071367263794e-01
    z[0,4,6]  R980      -7.6179198920726776e-02
    z[0,4,6]  R981      -5.1968467235565186e-01
    z[0,4,6]  R982      -3.6494970321655273e-01
    z[0,4,6]  R983      -1.2957751750946045e-01
    z[0,4,6]  R984      1.1584952473640442e-01
    z[0,4,6]  R985      1.1547765135765076e-01
    z[0,4,6]  R986      -1.2766093015670776e-01
    z[0,4,6]  R987      1.0075343400239944e-01
    z[0,4,6]  R988      2.5603345036506653e-01
    z[0,4,6]  R989      3.4406366944313049e-01
    z[0,4,6]  R990      -1.7734996974468231e-01
    z[0,4,6]  R991      -0.0982140377163887
    z[0,4,6]  R992      -1.2797258794307709e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R993      -1
    z[4,0,0]  R994      1
    z[4,0,0]  R1007     -0.626301646232605
    z[4,0,0]  R1008     -8.4204000234603882e-01
    z[4,0,0]  R1009     -5.6200635433197021e-01
    z[4,0,0]  R1010     -5.3218764066696167e-01
    z[4,0,0]  R1011     -0.939971387386322
    z[4,0,0]  R1012     6.5989071130752563e-01
    z[4,0,0]  R1013     -9.3661779165267944e-01
    z[4,0,0]  R1014     5.6124496459960938e-01
    z[4,0,0]  R1015     -8.1057894229888916e-01
    z[4,0,0]  R1016     -8.1453180313110352e-01
    z[4,0,0]  R1017     -1.3804477453231812e-01
    z[4,0,0]  R1018     -1.4331266283988953e-01
    z[4,0,0]  R1019     1.3529990613460541e-01
    z[4,0,0]  R1020     1.8741910159587860e-01
    z[4,0,0]  R1021     1.1734388023614883e-01
    z[4,0,0]  R1022     -1.5084441751241684e-02
    z[4,0,0]  R1023     -4.1426301002502441e-01
    z[4,0,0]  R1024     8.9693886041641235e-01
    z[4,0,0]  R1025     7.0947146415710449e-01
    z[4,0,0]  R1026     0.85356205701828
    z[4,0,0]  R1027     6.7912268638610840e-01
    z[4,0,0]  R1028     4.6549555659294128e-01
    z[4,0,0]  R1029     -7.0993238687515259e-01
    z[4,0,0]  R1030     7.1068447828292847e-01
    z[4,0,0]  R1031     4.5530465245246887e-01
    z[4,0,0]  R1032     0.552579402923584
    z[4,0,0]  R1033     5.8852738142013550e-01
    z[4,0,0]  R1034     -3.5320860147476196e-01
    z[4,0,0]  R1035     -0.319614976644516
    z[4,0,0]  R1036     -2.3107655346393585e-01
    z[4,0,0]  R1037     1.3831178843975067e-01
    z[4,0,0]  R1038     -2.4963927268981934e-01
    z[4,0,0]  R1039     1.5677075088024139e-01
    z[4,0,0]  R1040     2.0215308666229248e-01
    z[4,0,0]  R1041     3.3621060848236084e-01
    z[4,0,0]  R1042     -3.6002430319786072e-01
    z[4,0,0]  R1043     2.8251945972442627e-01
    z[4,0,0]  R1044     5.3606323897838593e-02
    z[4,0,0]  R1045     -2.0865032076835632e-01
    z[4,0,0]  R1046     0.0792015790939331
    z[4,0,0]  R1047     6.9700604677200317e-01
    z[4,0,0]  R1048     4.9385523796081543e-01
    z[4,0,0]  R1049     2.7884298563003540e-01
    z[4,0,0]  R1050     -6.2758654356002808e-02
    z[4,0,0]  R1051     4.4140231609344482e-01
    z[4,0,0]  R1052     2.9204022884368896e-01
    z[4,0,0]  R1053     0.0990278422832489
    z[4,0,0]  R1054     5.6584876775741577e-01
    z[4,0,0]  R1055     0.438368558883667
    z[4,0,0]  R1056     1.2508645653724670e-01
    z[4,0,0]  R1057     4.1417360305786133e-01
    z[4,0,0]  R1058     4.1959103941917419e-01
    z[4,0,0]  R1059     5.5644816160202026e-01
    z[4,0,0]  R1060     6.3575762510299683e-01
    z[4,0,0]  R1061     4.1316190361976624e-01
    z[4,0,0]  R1062     3.8598445057868958e-01
    z[4,0,0]  R1063     2.8113448619842529e-01
    z[4,0,0]  R1064     2.4223934113979340e-01
    z[4,0,0]  R1065     -3.3876141905784607e-01
    z[4,0,0]  R1066     1.6936412453651428e-01
    z[4,0,0]  R1067     -2.2780045866966248e-01
    z[4,0,0]  R1068     5.2210664749145508e-01
    z[4,0,0]  R1069     4.7280839085578918e-01
    z[4,0,0]  R1070     3.7545260787010193e-01
    z[4,0,0]  R1071     -4.0232321619987488e-01
    z[4,0,0]  R1072     4.7286859154701233e-01
    z[4,0,0]  R1073     -1.9411759078502655e-01
    z[4,0,0]  R1074     9.3059904873371124e-02
    z[4,0,0]  R1075     4.1530004143714905e-01
    z[4,0,0]  R1076     2.9094433784484863e-01
    z[4,0,0]  R1077     4.4050028920173645e-01
    z[4,0,0]  R1078     -3.1407541036605835e-01
    z[4,0,0]  R1079     -2.5384524837136269e-02
    z[4,0,0]  R1080     1.2459943443536758e-01
    z[4,0,0]  R1081     -2.3517280817031860e-01
    z[4,0,0]  R1082     -5.2083592861890793e-02
    z[4,0,0]  R1083     1.4811287820339203e-01
    z[4,0,0]  R1084     -6.3537520170211792e-01
    z[4,0,0]  R1085     -6.4471709728240967e-01
    z[4,0,0]  R1086     -6.5766119956970215e-01
    z[4,0,0]  R1087     1.2397421896457672e-01
    z[4,0,0]  R1088     6.3077318668365479e-01
    z[4,0,0]  R1089     5.0213652849197388e-01
    z[4,0,0]  R1090     2.0148406922817230e-01
    z[4,0,0]  R1091     -4.1290480643510818e-02
    z[4,0,0]  R1092     9.4691142439842224e-02
    z[4,0,0]  R1093     -2.8340309858322144e-02
    z[4,0,0]  R1094     -2.4740856885910034e-01
    z[4,0,0]  R1095     -3.0452784895896912e-01
    z[4,0,0]  R1096     -3.8870215415954590e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R995      -1
    z[4,0,1]  R996      1
    z[4,0,1]  R1007     -0.575942873954773
    z[4,0,1]  R1008     -8.1678695976734161e-02
    z[4,0,1]  R1009     -1.9468982517719269e-01
    z[4,0,1]  R1010     -8.7245449423789978e-02
    z[4,0,1]  R1011     -1.4296740293502808e-01
    z[4,0,1]  R1012     1.5793354809284210e-01
    z[4,0,1]  R1013     6.2615498900413513e-02
    z[4,0,1]  R1014     -8.5508622229099274e-02
    z[4,0,1]  R1015     2.1103753149509430e-01
    z[4,0,1]  R1016     0.0857396051287651
    z[4,0,1]  R1017     8.7869238853454590e-01
    z[4,0,1]  R1018     7.4564278125762939e-01
    z[4,0,1]  R1019     0.814132571220398
    z[4,0,1]  R1020     8.3106732368469238e-01
    z[4,0,1]  R1021     0.913650393486023
    z[4,0,1]  R1022     9.2196524143218994e-01
    z[4,0,1]  R1023     6.8651187419891357e-01
    z[4,0,1]  R1024     -3.4975543618202209e-01
    z[4,0,1]  R1025     -2.1639437973499298e-01
    z[4,0,1]  R1026     3.3483337610960007e-02
    z[4,0,1]  R1027     -5.4730284214019775e-01
    z[4,0,1]  R1028     -1.0956397652626038e-01
    z[4,0,1]  R1029     0.00622505834326148
    z[4,0,1]  R1030     5.1804497838020325e-02
    z[4,0,1]  R1031     -2.2204600274562836e-01
    z[4,0,1]  R1032     -2.3661231622099876e-02
    z[4,0,1]  R1033     2.3132576048374176e-01
    z[4,0,1]  R1034     -6.3067066669464111e-01
    z[4,0,1]  R1035     -8.3851498365402222e-01
    z[4,0,1]  R1036     -6.7305499315261841e-01
    z[4,0,1]  R1037     5.4261481761932373e-01
    z[4,0,1]  R1038     1.8471740186214447e-01
    z[4,0,1]  R1039     4.8204636573791504e-01
    z[4,0,1]  R1040     6.2353205680847168e-01
    z[4,0,1]  R1041     3.3489429950714111e-01
    z[4,0,1]  R1042     -8.1334710121154785e-01
    z[4,0,1]  R1043     -6.8163412809371948e-01
    z[4,0,1]  R1044     -7.3793184757232666e-01
    z[4,0,1]  R1045     -6.2932431697845459e-01
    z[4,0,1]  R1046     -4.5561450719833374e-01
    z[4,0,1]  R1047     2.6548174023628235e-01
    z[4,0,1]  R1048     1.7883922159671783e-01
    z[4,0,1]  R1049     2.4211584031581879e-01
    z[4,0,1]  R1050     -3.7438550591468811e-01
    z[4,0,1]  R1051     -6.9548559188842773e-01
    z[4,0,1]  R1052     -8.1426960229873657e-01
    z[4,0,1]  R1053     -8.8026142120361328e-01
    z[4,0,1]  R1054     -5.5686980485916138e-01
    z[4,0,1]  R1055     -6.1559689044952393e-01
    z[4,0,1]  R1056     -8.6519724130630493e-01
    z[4,0,1]  R1057     -7.8430545330047607e-01
    z[4,0,1]  R1058     -8.8759505748748779e-01
    z[4,0,1]  R1059     -7.8066098690032959e-01
    z[4,0,1]  R1060     -7.2174870967864990e-01
    z[4,0,1]  R1061     -0.579284131526947
    z[4,0,1]  R1062     -0.739266574382782
    z[4,0,1]  R1063     -7.4926763772964478e-01
    z[4,0,1]  R1064     -0.616884171962738
    z[4,0,1]  R1065     -8.8023918867111206e-01
    z[4,0,1]  R1066     -8.8934975862503052e-01
    z[4,0,1]  R1067     -6.0995358228683472e-01
    z[4,0,1]  R1068     -6.6779989004135132e-01
    z[4,0,1]  R1069     -5.9846210479736328e-01
    z[4,0,1]  R1070     -8.5873937606811523e-01
    z[4,0,1]  R1071     -4.8705798387527466e-01
    z[4,0,1]  R1072     -5.8593922853469849e-01
    z[4,0,1]  R1073     -8.4706974029541016e-01
    z[4,0,1]  R1074     -8.3782196044921875e-01
    z[4,0,1]  R1075     -7.2321790456771851e-01
    z[4,0,1]  R1076     -6.1781018972396851e-01
    z[4,0,1]  R1077     -8.2881647348403931e-01
    z[4,0,1]  R1078     -9.0422928333282471e-01
    z[4,0,1]  R1079     -9.0046817064285278e-01
    z[4,0,1]  R1080     -9.6193933486938477e-01
    z[4,0,1]  R1081     -0.798782229423523
    z[4,0,1]  R1082     -7.6137822866439819e-01
    z[4,0,1]  R1083     -4.1610002517700195e-01
    z[4,0,1]  R1084     7.1338564157485962e-02
    z[4,0,1]  R1085     9.2577107250690460e-02
    z[4,0,1]  R1086     7.7672697603702545e-02
    z[4,0,1]  R1087     -5.9112477302551270e-01
    z[4,0,1]  R1088     -0.6157186627388
    z[4,0,1]  R1089     -6.7031729221343994e-01
    z[4,0,1]  R1090     -9.1305035352706909e-01
    z[4,0,1]  R1091     -9.5023977756500244e-01
    z[4,0,1]  R1092     -8.8946694135665894e-01
    z[4,0,1]  R1093     -8.7520343065261841e-01
    z[4,0,1]  R1094     -7.9479080438613892e-01
    z[4,0,1]  R1095     0.0364716611802578
    z[4,0,1]  R1096     1.9382598996162415e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R997      -1
    z[4,0,2]  R998      1
    z[4,0,2]  R1007     3.8755902647972107e-01
    z[4,0,2]  R1008     4.8647314310073853e-01
    z[4,0,2]  R1009     6.0824459791183472e-01
    z[4,0,2]  R1010     4.3417137861251831e-01
    z[4,0,2]  R1011     -1.4967535436153412e-01
    z[4,0,2]  R1012     -4.1559547185897827e-01
    z[4,0,2]  R1013     -1.9692401587963104e-01
    z[4,0,2]  R1014     -1.1192564666271210e-01
    z[4,0,2]  R1015     -1.9925747811794281e-01
    z[4,0,2]  R1016     4.4076152145862579e-02
    z[4,0,2]  R1017     -0.348624587059021
    z[4,0,2]  R1018     -5.3115451335906982e-01
    z[4,0,2]  R1019     -3.2606229186058044e-01
    z[4,0,2]  R1020     -2.7933281660079956e-01
    z[4,0,2]  R1021     -0.0719640925526619
    z[4,0,2]  R1022     -0.0854223445057869
    z[4,0,2]  R1023     -3.4509435296058655e-01
    z[4,0,2]  R1024     1.6582074761390686e-01
    z[4,0,2]  R1025     2.6561295986175537e-01
    z[4,0,2]  R1026     3.1241217255592346e-01
    z[4,0,2]  R1027     3.5691785160452127e-03
    z[4,0,2]  R1028     -2.1841278672218323e-01
    z[4,0,2]  R1029     3.8633834570646286e-02
    z[4,0,2]  R1030     1.4892983436584473e-01
    z[4,0,2]  R1031     -1.7980413138866425e-01
    z[4,0,2]  R1032     0.190543994307518
    z[4,0,2]  R1033     1.6353680193424225e-01
    z[4,0,2]  R1034     -0.352943480014801
    z[4,0,2]  R1035     -8.0922663211822510e-02
    z[4,0,2]  R1036     -1.6812250018119812e-02
    z[4,0,2]  R1037     4.3849232792854309e-01
    z[4,0,2]  R1038     3.3853515982627869e-01
    z[4,0,2]  R1039     9.4243094325065613e-02
    z[4,0,2]  R1040     0.582205593585968
    z[4,0,2]  R1041     3.9551305770874023e-01
    z[4,0,2]  R1042     5.2726618014276028e-03
    z[4,0,2]  R1043     -3.3160638064146042e-02
    z[4,0,2]  R1044     1.5954692661762238e-01
    z[4,0,2]  R1045     7.1214497089385986e-01
    z[4,0,2]  R1046     2.3050554096698761e-01
    z[4,0,2]  R1047     -3.3334669470787048e-01
    z[4,0,2]  R1048     5.5639997124671936e-02
    z[4,0,2]  R1049     -2.0356020331382751e-01
    z[4,0,2]  R1050     -2.3002997040748596e-01
    z[4,0,2]  R1051     -2.8369075059890747e-01
    z[4,0,2]  R1052     3.8147693872451782e-01
    z[4,0,2]  R1053     2.3826966062188148e-02
    z[4,0,2]  R1054     -2.9808353632688522e-02
    z[4,0,2]  R1055     -2.7991554141044617e-01
    z[4,0,2]  R1056     -1.5095798298716545e-02
    z[4,0,2]  R1057     -3.7754490971565247e-01
    z[4,0,2]  R1058     -1.0950003750622272e-02
    z[4,0,2]  R1059     2.4025326129049063e-03
    z[4,0,2]  R1060     1.3460588455200195e-01
    z[4,0,2]  R1061     -2.1773955225944519e-01
    z[4,0,2]  R1062     -2.7437901496887207e-01
    z[4,0,2]  R1063     -9.9309816956520081e-02
    z[4,0,2]  R1064     -4.0018233656883240e-01
    z[4,0,2]  R1065     -1.9711470603942871e-01
    z[4,0,2]  R1066     -1.2846191413700581e-02
    z[4,0,2]  R1067     2.4511611461639404e-01
    z[4,0,2]  R1068     6.2628291547298431e-02
    z[4,0,2]  R1069     1.0547447949647903e-01
    z[4,0,2]  R1070     3.3033019304275513e-01
    z[4,0,2]  R1071     6.6327786445617676e-01
    z[4,0,2]  R1072     8.1514120101928711e-02
    z[4,0,2]  R1073     -1.3852171599864960e-01
    z[4,0,2]  R1074     4.2326194047927856e-01
    z[4,0,2]  R1075     -4.6761423349380493e-02
    z[4,0,2]  R1076     3.7887477874755859e-01
    z[4,0,2]  R1077     -9.9935494363307953e-02
    z[4,0,2]  R1078     1.0055445134639740e-01
    z[4,0,2]  R1079     2.0335851609706879e-01
    z[4,0,2]  R1080     -1.0601404309272766e-01
    z[4,0,2]  R1081     -1.2080924212932587e-01
    z[4,0,2]  R1082     -3.1700644642114639e-02
    z[4,0,2]  R1083     -3.3466815948486328e-01
    z[4,0,2]  R1084     -0.687119722366333
    z[4,0,2]  R1085     -6.4685958623886108e-01
    z[4,0,2]  R1086     -6.0850036144256592e-01
    z[4,0,2]  R1087     2.5499412789940834e-02
    z[4,0,2]  R1088     5.7227391749620438e-02
    z[4,0,2]  R1089     2.2832669317722321e-01
    z[4,0,2]  R1090     -1.0725231468677521e-01
    z[4,0,2]  R1091     1.5175219625234604e-02
    z[4,0,2]  R1092     2.7799534797668457e-01
    z[4,0,2]  R1093     -1.1042208969593048e-01
    z[4,0,2]  R1094     -4.4454595446586609e-01
    z[4,0,2]  R1095     5.8498613536357880e-02
    z[4,0,2]  R1096     -3.2437656074762344e-02
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R999      -1
    z[4,0,3]  R1000     1
    z[4,0,3]  R1007     -1.1291564255952835e-01
    z[4,0,3]  R1008     -4.3126974254846573e-02
    z[4,0,3]  R1009     -8.4073126316070557e-02
    z[4,0,3]  R1010     -1.1861911416053772e-01
    z[4,0,3]  R1011     -2.1147488057613373e-01
    z[4,0,3]  R1012     1.1938295327126980e-02
    z[4,0,3]  R1013     -3.3003918826580048e-02
    z[4,0,3]  R1014     -7.1461528539657593e-02
    z[4,0,3]  R1015     -3.5813751816749573e-01
    z[4,0,3]  R1016     3.7784200906753540e-01
    z[4,0,3]  R1017     2.3530612885951996e-01
    z[4,0,3]  R1018     -1.9758237898349762e-01
    z[4,0,3]  R1019     3.5624884068965912e-02
    z[4,0,3]  R1020     -0.330709308385849
    z[4,0,3]  R1021     1.2008894234895706e-01
    z[4,0,3]  R1022     -4.6502269804477692e-02
    z[4,0,3]  R1023     -2.7664867043495178e-01
    z[4,0,3]  R1024     -7.3545746505260468e-02
    z[4,0,3]  R1025     -1.3987350463867188e-01
    z[4,0,3]  R1026     7.3284611105918884e-02
    z[4,0,3]  R1027     -1.9933162629604340e-01
    z[4,0,3]  R1028     -1.5276260673999786e-01
    z[4,0,3]  R1029     5.7509493827819824e-01
    z[4,0,3]  R1030     -4.4765692949295044e-01
    z[4,0,3]  R1031     -7.7382522821426392e-01
    z[4,0,3]  R1032     7.6344740390777588e-01
    z[4,0,3]  R1033     5.8561843633651733e-01
    z[4,0,3]  R1034     4.7341939806938171e-01
    z[4,0,3]  R1035     2.2318008542060852e-01
    z[4,0,3]  R1036     3.6834666132926941e-01
    z[4,0,3]  R1037     -2.7918061614036560e-01
    z[4,0,3]  R1038     -1.5112577378749847e-01
    z[4,0,3]  R1039     -3.8952809572219849e-01
    z[4,0,3]  R1040     -2.6958325877785683e-02
    z[4,0,3]  R1041     -0.576545238494873
    z[4,0,3]  R1042     4.2964771389961243e-01
    z[4,0,3]  R1043     3.6707094311714172e-01
    z[4,0,3]  R1044     4.9446511268615723e-01
    z[4,0,3]  R1045     -8.6714506149291992e-02
    z[4,0,3]  R1046     8.4276819229125977e-01
    z[4,0,3]  R1047     -1.5110825002193451e-01
    z[4,0,3]  R1048     4.4408398866653442e-01
    z[4,0,3]  R1049     4.9077352881431580e-01
    z[4,0,3]  R1050     3.7115055322647095e-01
    z[4,0,3]  R1051     1.4902465045452118e-01
    z[4,0,3]  R1052     5.3401932120323181e-02
    z[4,0,3]  R1053     -2.3090282082557678e-01
    z[4,0,3]  R1054     2.8796160221099854e-01
    z[4,0,3]  R1055     2.4158558249473572e-01
    z[4,0,3]  R1056     -3.7723553180694580e-01
    z[4,0,3]  R1057     1.8693108856678009e-01
    z[4,0,3]  R1058     4.9490388482809067e-03
    z[4,0,3]  R1059     -1.4407569542527199e-02
    z[4,0,3]  R1060     -0.00487411767244339
    z[4,0,3]  R1061     6.2143850326538086e-01
    z[4,0,3]  R1062     1.7748048901557922e-01
    z[4,0,3]  R1063     3.9502236247062683e-01
    z[4,0,3]  R1064     5.5404853820800781e-01
    z[4,0,3]  R1065     -1.6640393063426018e-02
    z[4,0,3]  R1066     2.5008162856101990e-01
    z[4,0,3]  R1067     0.254672646522522
    z[4,0,3]  R1068     4.5510622859001160e-01
    z[4,0,3]  R1069     5.9680455923080444e-01
    z[4,0,3]  R1070     2.9364828020334244e-02
    z[4,0,3]  R1071     2.8551253676414490e-01
    z[4,0,3]  R1072     4.4502565264701843e-01
    z[4,0,3]  R1073     6.2376689165830612e-02
    z[4,0,3]  R1074     2.4847450852394104e-01
    z[4,0,3]  R1075     7.0948116481304169e-02
    z[4,0,3]  R1076     5.4908853769302368e-01
    z[4,0,3]  R1077     1.2764946557581425e-02
    z[4,0,3]  R1078     2.4747721850872040e-01
    z[4,0,3]  R1079     6.0122460126876831e-02
    z[4,0,3]  R1080     -7.7999327331781387e-03
    z[4,0,3]  R1081     2.8803277015686035e-01
    z[4,0,3]  R1082     2.4187400937080383e-01
    z[4,0,3]  R1083     6.3066351413726807e-01
    z[4,0,3]  R1084     -1.0523796826601028e-01
    z[4,0,3]  R1085     2.9216054081916809e-01
    z[4,0,3]  R1086     1.7974372208118439e-01
    z[4,0,3]  R1087     -3.1478229910135269e-02
    z[4,0,3]  R1088     3.1292641162872314e-01
    z[4,0,3]  R1089     3.5052257776260376e-01
    z[4,0,3]  R1090     7.7737748622894287e-02
    z[4,0,3]  R1091     -1.4659301936626434e-01
    z[4,0,3]  R1092     -1.6012732684612274e-01
    z[4,0,3]  R1093     1.8675832450389862e-01
    z[4,0,3]  R1094     3.9999779313802719e-02
    z[4,0,3]  R1095     5.6568211317062378e-01
    z[4,0,3]  R1096     6.6492003202438354e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R1001     -1
    z[4,0,4]  R1002     1
    z[4,0,4]  R1007     -1.3108095526695251e-01
    z[4,0,4]  R1008     1.7517803609371185e-01
    z[4,0,4]  R1009     -5.0521481037139893e-01
    z[4,0,4]  R1010     -3.7098596803843975e-03
    z[4,0,4]  R1011     -7.8253731131553650e-02
    z[4,0,4]  R1012     1.8952155485749245e-02
    z[4,0,4]  R1013     1.0351741313934326e-01
    z[4,0,4]  R1014     -3.0360710620880127e-01
    z[4,0,4]  R1015     -2.0744135975837708e-01
    z[4,0,4]  R1016     -2.9577660560607910e-01
    z[4,0,4]  R1017     6.2534660100936890e-02
    z[4,0,4]  R1018     2.8456097841262817e-01
    z[4,0,4]  R1019     4.0337464213371277e-01
    z[4,0,4]  R1020     7.7082134783267975e-02
    z[4,0,4]  R1021     1.1331208795309067e-01
    z[4,0,4]  R1022     -2.6226335763931274e-01
    z[4,0,4]  R1023     -3.4285095334053040e-01
    z[4,0,4]  R1024     8.8250853121280670e-02
    z[4,0,4]  R1025     2.7964314818382263e-01
    z[4,0,4]  R1026     8.8019356131553650e-02
    z[4,0,4]  R1027     3.6297035217285156e-01
    z[4,0,4]  R1028     6.8603962659835815e-02
    z[4,0,4]  R1029     2.4468223750591278e-01
    z[4,0,4]  R1030     -4.6644932031631470e-01
    z[4,0,4]  R1031     -3.0253347754478455e-01
    z[4,0,4]  R1032     3.5661216825246811e-02
    z[4,0,4]  R1033     -2.8646424412727356e-01
    z[4,0,4]  R1034     -1.2093091756105423e-01
    z[4,0,4]  R1035     8.1553466618061066e-02
    z[4,0,4]  R1036     -5.2477353811264038e-01
    z[4,0,4]  R1037     -5.1024895161390305e-02
    z[4,0,4]  R1038     1.3013137876987457e-01
    z[4,0,4]  R1039     2.8744551539421082e-01
    z[4,0,4]  R1040     -1.6588295996189117e-01
    z[4,0,4]  R1041     -1.7806215584278107e-01
    z[4,0,4]  R1042     -2.8135115280747414e-02
    z[4,0,4]  R1043     -2.8193125128746033e-01
    z[4,0,4]  R1044     3.4507939219474792e-01
    z[4,0,4]  R1045     -1.3545063138008118e-01
    z[4,0,4]  R1046     1.1985806375741959e-01
    z[4,0,4]  R1047     1.3993303477764130e-01
    z[4,0,4]  R1048     4.9991786479949951e-01
    z[4,0,4]  R1049     7.4206370115280151e-01
    z[4,0,4]  R1050     7.5349074602127075e-01
    z[4,0,4]  R1051     -1.2462893128395081e-01
    z[4,0,4]  R1052     -0.0282792616635561
    z[4,0,4]  R1053     -3.6938312649726868e-01
    z[4,0,4]  R1054     -2.8143274784088135e-01
    z[4,0,4]  R1055     -5.2599930763244629e-01
    z[4,0,4]  R1056     -2.1209090948104858e-01
    z[4,0,4]  R1057     -9.3808978796005249e-02
    z[4,0,4]  R1058     -2.3968910798430443e-02
    z[4,0,4]  R1059     1.0132896155118942e-01
    z[4,0,4]  R1060     -1.6049362719058990e-01
    z[4,0,4]  R1061     1.0189700871706009e-01
    z[4,0,4]  R1062     3.9138558506965637e-01
    z[4,0,4]  R1063     4.0224725008010864e-01
    z[4,0,4]  R1064     2.0485168695449829e-01
    z[4,0,4]  R1065     -2.6626411080360413e-01
    z[4,0,4]  R1066     3.0490845441818237e-01
    z[4,0,4]  R1067     1.0915137827396393e-01
    z[4,0,4]  R1068     7.1642078459262848e-02
    z[4,0,4]  R1069     2.0457884669303894e-01
    z[4,0,4]  R1070     5.7132825255393982e-02
    z[4,0,4]  R1071     1.3246698677539825e-01
    z[4,0,4]  R1072     -3.7669813632965088e-01
    z[4,0,4]  R1073     -1.6978222131729126e-01
    z[4,0,4]  R1074     -6.1717376112937927e-02
    z[4,0,4]  R1075     -4.7624397277832031e-01
    z[4,0,4]  R1076     -1.4507827162742615e-01
    z[4,0,4]  R1077     -1.7002993822097778e-01
    z[4,0,4]  R1078     -4.2550783604383469e-02
    z[4,0,4]  R1079     -9.4564616680145264e-02
    z[4,0,4]  R1080     1.6484777629375458e-01
    z[4,0,4]  R1081     1.1954781413078308e-01
    z[4,0,4]  R1082     -2.3453450202941895e-01
    z[4,0,4]  R1083     -1.9616085290908813e-01
    z[4,0,4]  R1084     -1.7899875342845917e-01
    z[4,0,4]  R1085     -6.4933754503726959e-02
    z[4,0,4]  R1086     -2.2044228017330170e-01
    z[4,0,4]  R1087     3.1556585431098938e-01
    z[4,0,4]  R1088     1.0745245218276978e-01
    z[4,0,4]  R1089     -7.7980393543839455e-03
    z[4,0,4]  R1090     -2.1471410989761353e-02
    z[4,0,4]  R1091     -1.3983753323554993e-01
    z[4,0,4]  R1092     -2.3936058580875397e-01
    z[4,0,4]  R1093     -1.2669727206230164e-01
    z[4,0,4]  R1094     1.7202737927436829e-01
    z[4,0,4]  R1095     -4.1657772660255432e-01
    z[4,0,4]  R1096     -2.6984393596649170e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R1003     -1
    z[4,0,5]  R1004     1
    z[4,0,5]  R1007     -2.7850124239921570e-01
    z[4,0,5]  R1008     1.2280213832855225e-01
    z[4,0,5]  R1009     4.8055514693260193e-02
    z[4,0,5]  R1010     -3.5813519358634949e-01
    z[4,0,5]  R1011     8.1823609769344330e-02
    z[4,0,5]  R1012     -3.6321735382080078e-01
    z[4,0,5]  R1013     -2.6041004061698914e-01
    z[4,0,5]  R1014     -6.7825573682785034e-01
    z[4,0,5]  R1015     -1.2281390838325024e-02
    z[4,0,5]  R1016     3.1469874083995819e-02
    z[4,0,5]  R1017     5.8050606399774551e-02
    z[4,0,5]  R1018     -1.4533384144306183e-01
    z[4,0,5]  R1019     1.5770610189065337e-03
    z[4,0,5]  R1020     1.1847331374883652e-01
    z[4,0,5]  R1021     -4.4052530080080032e-02
    z[4,0,5]  R1022     2.4003873765468597e-01
    z[4,0,5]  R1023     -1.1766491085290909e-01
    z[4,0,5]  R1024     1.6332441568374634e-01
    z[4,0,5]  R1025     -1.0694076865911484e-01
    z[4,0,5]  R1026     1.6248992085456848e-01
    z[4,0,5]  R1027     -2.2576166689395905e-01
    z[4,0,5]  R1028     -8.2591855525970459e-01
    z[4,0,5]  R1029     3.0087551474571228e-01
    z[4,0,5]  R1030     -1.8919488787651062e-01
    z[4,0,5]  R1031     -1.0286095738410950e-01
    z[4,0,5]  R1032     -9.0068064630031586e-02
    z[4,0,5]  R1033     1.7317394912242889e-01
    z[4,0,5]  R1034     2.8762108087539673e-01
    z[4,0,5]  R1035     3.4940522909164429e-01
    z[4,0,5]  R1036     2.5666022300720215e-01
    z[4,0,5]  R1037     -2.5622516870498657e-01
    z[4,0,5]  R1038     -6.9626617431640625e-01
    z[4,0,5]  R1039     -7.0565515756607056e-01
    z[4,0,5]  R1040     6.4109876751899719e-02
    z[4,0,5]  R1041     -4.1626104712486267e-01
    z[4,0,5]  R1042     1.5259596705436707e-01
    z[4,0,5]  R1043     -3.7575110793113708e-01
    z[4,0,5]  R1044     7.5319744646549225e-02
    z[4,0,5]  R1045     1.0449462383985519e-01
    z[4,0,5]  R1046     5.2294008433818817e-02
    z[4,0,5]  R1047     5.3625613451004028e-01
    z[4,0,5]  R1048     4.7479662299156189e-01
    z[4,0,5]  R1049     1.4701986312866211e-01
    z[4,0,5]  R1050     -2.7418610453605652e-01
    z[4,0,5]  R1051     2.6580700278282166e-01
    z[4,0,5]  R1052     1.4808274805545807e-01
    z[4,0,5]  R1053     0.138405442237854
    z[4,0,5]  R1054     2.3203523829579353e-02
    z[4,0,5]  R1055     -9.9081307649612427e-02
    z[4,0,5]  R1056     -0.170019268989563
    z[4,0,5]  R1057     -1.4094074070453644e-01
    z[4,0,5]  R1058     1.4805573225021362e-01
    z[4,0,5]  R1059     -0.00614133570343256
    z[4,0,5]  R1060     -4.6561844646930695e-02
    z[4,0,5]  R1061     -2.0218789577484131e-01
    z[4,0,5]  R1062     -0.070730060338974
    z[4,0,5]  R1063     -0.125872403383255
    z[4,0,5]  R1064     1.6337139904499054e-01
    z[4,0,5]  R1065     -1.4813865534961224e-02
    z[4,0,5]  R1066     5.1943007856607437e-02
    z[4,0,5]  R1067     -3.0868789553642273e-01
    z[4,0,5]  R1068     -2.3672723770141602e-01
    z[4,0,5]  R1069     -1.9990043714642525e-02
    z[4,0,5]  R1070     8.1158012151718140e-02
    z[4,0,5]  R1071     7.2173632681369781e-02
    z[4,0,5]  R1072     2.4948580563068390e-01
    z[4,0,5]  R1073     1.4346297085285187e-01
    z[4,0,5]  R1074     1.6191197931766510e-01
    z[4,0,5]  R1075     1.1874933540821075e-01
    z[4,0,5]  R1076     2.5968101620674133e-01
    z[4,0,5]  R1077     6.2717609107494354e-03
    z[4,0,5]  R1078     -9.1657042503356934e-02
    z[4,0,5]  R1079     2.0332394167780876e-02
    z[4,0,5]  R1080     -1.4069218933582306e-01
    z[4,0,5]  R1081     3.7906490266323090e-02
    z[4,0,5]  R1082     4.4746950268745422e-01
    z[4,0,5]  R1083     2.4970276653766632e-01
    z[4,0,5]  R1084     2.6387146115303040e-01
    z[4,0,5]  R1085     1.9971735775470734e-01
    z[4,0,5]  R1086     2.0439951121807098e-01
    z[4,0,5]  R1087     -3.6918017268180847e-01
    z[4,0,5]  R1088     -1.3579083979129791e-01
    z[4,0,5]  R1089     3.4114348888397217e-01
    z[4,0,5]  R1090     3.0706393718719482e-01
    z[4,0,5]  R1091     -1.4180496335029602e-01
    z[4,0,5]  R1092     -0.0861627534031868
    z[4,0,5]  R1093     2.9993566870689392e-01
    z[4,0,5]  R1094     -2.6750189065933228e-01
    z[4,0,5]  R1095     6.1956298351287842e-01
    z[4,0,5]  R1096     5.0050729513168335e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R1005     -1
    z[4,0,6]  R1006     1
    z[4,0,6]  R1007     1.3542146980762482e-01
    z[4,0,6]  R1008     -0.00367422285489738
    z[4,0,6]  R1009     -1.0799888521432877e-01
    z[4,0,6]  R1010     -6.1507290601730347e-01
    z[4,0,6]  R1011     1.2677150964736938e-01
    z[4,0,6]  R1012     4.8420354723930359e-01
    z[4,0,6]  R1013     2.0706895738840103e-02
    z[4,0,6]  R1014     3.2840543985366821e-01
    z[4,0,6]  R1015     -2.9542544484138489e-01
    z[4,0,6]  R1016     3.0984729528427124e-01
    z[4,0,6]  R1017     1.5701831877231598e-01
    z[4,0,6]  R1018     -1.4757920987904072e-02
    z[4,0,6]  R1019     -2.2041529417037964e-01
    z[4,0,6]  R1020     -2.5851166248321533e-01
    z[4,0,6]  R1021     -3.4218841791152954e-01
    z[4,0,6]  R1022     -1.1786611378192902e-01
    z[4,0,6]  R1023     1.7341071367263794e-01
    z[4,0,6]  R1024     -7.6179198920726776e-02
    z[4,0,6]  R1025     -5.1968467235565186e-01
    z[4,0,6]  R1026     -3.6494970321655273e-01
    z[4,0,6]  R1027     -1.2957751750946045e-01
    z[4,0,6]  R1028     1.1584952473640442e-01
    z[4,0,6]  R1029     1.1547765135765076e-01
    z[4,0,6]  R1030     -1.2766093015670776e-01
    z[4,0,6]  R1031     1.0075343400239944e-01
    z[4,0,6]  R1032     2.5603345036506653e-01
    z[4,0,6]  R1033     3.4406366944313049e-01
    z[4,0,6]  R1034     -1.7734996974468231e-01
    z[4,0,6]  R1035     -0.0982140377163887
    z[4,0,6]  R1036     -1.2797258794307709e-01
    z[4,0,6]  R1037     5.8988708257675171e-01
    z[4,0,6]  R1038     5.1419258117675781e-01
    z[4,0,6]  R1039     4.3201144784688950e-02
    z[4,0,6]  R1040     -4.4612166285514832e-01
    z[4,0,6]  R1041     -0.28459432721138
    z[4,0,6]  R1042     1.2120986357331276e-02
    z[4,0,6]  R1043     -3.1471100449562073e-01
    z[4,0,6]  R1044     -2.4058060348033905e-01
    z[4,0,6]  R1045     -0.128374844789505
    z[4,0,6]  R1046     0.0751722976565361
    z[4,0,6]  R1047     5.0954829901456833e-02
    z[4,0,6]  R1048     2.2015309333801270e-01
    z[4,0,6]  R1049     9.5172263681888580e-02
    z[4,0,6]  R1050     -1.4934517443180084e-01
    z[4,0,6]  R1051     3.6412796378135681e-01
    z[4,0,6]  R1052     2.8385373950004578e-01
    z[4,0,6]  R1053     -7.6482407748699188e-02
    z[4,0,6]  R1054     -4.5404630899429321e-01
    z[4,0,6]  R1055     7.5264692306518555e-02
    z[4,0,6]  R1056     1.3915333151817322e-01
    z[4,0,6]  R1057     -0.0847182348370552
    z[4,0,6]  R1058     -1.1609897762537003e-01
    z[4,0,6]  R1059     -2.6535862684249878e-01
    z[4,0,6]  R1060     1.6977122426033020e-01
    z[4,0,6]  R1061     -9.4169579446315765e-02
    z[4,0,6]  R1062     -1.9882759451866150e-01
    z[4,0,6]  R1063     1.2652884423732758e-01
    z[4,0,6]  R1064     1.5812614560127258e-01
    z[4,0,6]  R1065     1.3132725842297077e-02
    z[4,0,6]  R1066     1.4832308888435364e-01
    z[4,0,6]  R1067     -5.8644801378250122e-01
    z[4,0,6]  R1068     -9.6080824732780457e-02
    z[4,0,6]  R1069     -0.0935017317533493
    z[4,0,6]  R1070     4.2079180479049683e-02
    z[4,0,6]  R1071     -2.3811565339565277e-01
    z[4,0,6]  R1072     1.5567111968994141e-01
    z[4,0,6]  R1073     4.1509577631950378e-01
    z[4,0,6]  R1074     -0.135938823223114
    z[4,0,6]  R1075     2.3738507926464081e-01
    z[4,0,6]  R1076     1.1658837087452412e-02
    z[4,0,6]  R1077     2.8270691633224487e-01
    z[4,0,6]  R1078     -4.6458322554826736e-02
    z[4,0,6]  R1079     3.6631596088409424e-01
    z[4,0,6]  R1080     -2.9645375907421112e-02
    z[4,0,6]  R1081     4.3972063064575195e-01
    z[4,0,6]  R1082     -3.2069772481918335e-01
    z[4,0,6]  R1083     -4.4085553288459778e-01
    z[4,0,6]  R1084     7.9573400318622589e-02
    z[4,0,6]  R1085     1.6697552800178528e-01
    z[4,0,6]  R1086     -0.261714369058609
    z[4,0,6]  R1087     -6.3062274456024170e-01
    z[4,0,6]  R1088     3.0303898453712463e-01
    z[4,0,6]  R1089     8.4230154752731323e-02
    z[4,0,6]  R1090     1.1596415936946869e-01
    z[4,0,6]  R1091     1.8427266180515289e-01
    z[4,0,6]  R1092     -1.7956189811229706e-01
    z[4,0,6]  R1093     -2.8307339549064636e-01
    z[4,0,6]  R1094     -8.2004763185977936e-02
    z[4,0,6]  R1095     1.5848989784717560e-01
    z[4,0,6]  R1096     2.1177372336387634e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R1171     -1
    z[1,2,0]  R1172     1
    z[1,2,0]  R1185     3.3207225799560547e-01
    z[1,2,0]  R1186     2.2497600317001343e-01
    z[1,2,0]  R1187     4.0429782867431641e-01
    z[1,2,0]  R1188     1.1020505428314209e-01
    z[1,2,0]  R1189     3.3701881766319275e-01
    z[1,2,0]  R1190     0.297879159450531
    z[1,2,0]  R1191     3.9452165365219116e-01
    z[1,2,0]  R1192     2.0356547832489014e-01
    z[1,2,0]  R1193     -2.6331812143325806e-01
    z[1,2,0]  R1194     3.1959950923919678e-01
    z[1,2,0]  R1195     5.9074461460113525e-01
    z[1,2,0]  R1196     -4.1275955736637115e-02
    z[1,2,0]  R1197     -3.7504187226295471e-01
    z[1,2,0]  R1198     -5.7928526401519775e-01
    z[1,2,0]  R1199     -4.9910187721252441e-01
    z[1,2,0]  R1200     -6.3219177722930908e-01
    z[1,2,0]  R1201     -3.9742922782897949e-01
    z[1,2,0]  R1202     2.3084011673927307e-01
    z[1,2,0]  R1203     -9.3423920869827271e-01
    z[1,2,0]  R1204     -9.2440533638000488e-01
    z[1,2,0]  R1205     2.1656617522239685e-01
    z[1,2,0]  R1206     1.9144825637340546e-02
    z[1,2,0]  R1207     -5.2586293220520020e-01
    z[1,2,0]  R1208     3.0178827047348022e-01
    z[1,2,0]  R1209     2.0443785190582275e-01
    z[1,2,0]  R1210     -1.7751251161098480e-01
    z[1,2,0]  R1211     5.6899610906839371e-02
    z[1,2,0]  R1212     1.6422684490680695e-01
    z[1,2,0]  R1213     2.9473572969436646e-01
    z[1,2,0]  R1214     -6.5723603963851929e-01
    z[1,2,0]  R1215     9.5317848026752472e-02
    z[1,2,0]  R1216     -5.1086451858282089e-02
    z[1,2,0]  R1217     -2.1587809920310974e-01
    z[1,2,0]  R1218     7.7477765083312988e-01
    z[1,2,0]  R1219     7.0630115270614624e-01
    z[1,2,0]  R1220     5.0864154100418091e-01
    z[1,2,0]  R1221     5.3289115428924561e-01
    z[1,2,0]  R1222     3.1803345680236816e-01
    z[1,2,0]  R1223     -4.4739622622728348e-02
    z[1,2,0]  R1224     -5.8397495746612549e-01
    z[1,2,0]  R1225     -5.5687215179204941e-02
    z[1,2,0]  R1226     8.9335137605667114e-01
    z[1,2,0]  R1227     -1.7038933932781219e-01
    z[1,2,0]  R1228     -3.7038710713386536e-01
    z[1,2,0]  R1229     -6.0038655996322632e-01
    z[1,2,0]  R1230     4.6409547328948975e-01
    z[1,2,0]  R1231     4.3099871277809143e-01
    z[1,2,0]  R1232     4.7354349493980408e-01
    z[1,2,0]  R1233     4.6459159255027771e-01
    z[1,2,0]  R1234     4.6672913432121277e-01
    z[1,2,0]  R1235     -7.4349719285964966e-01
    z[1,2,0]  R1236     -9.0440279245376587e-01
    z[1,2,0]  R1237     -6.5755015611648560e-01
    z[1,2,0]  R1238     -3.6882689595222473e-01
    z[1,2,0]  R1239     -1.4272942207753658e-02
    z[1,2,0]  R1240     4.3630054593086243e-01
    z[1,2,0]  R1241     3.0258023738861084e-01
    z[1,2,0]  R1242     1.9868750870227814e-01
    z[1,2,0]  R1243     3.1030893325805664e-01
    z[1,2,0]  R1244     2.8834110498428345e-01
    z[1,2,0]  R1245     2.7444690465927124e-01
    z[1,2,0]  R1246     -0.0762915164232254
    z[1,2,0]  R1247     -2.3704680800437927e-01
    z[1,2,0]  R1248     -0.0945655107498169
    z[1,2,0]  R1249     -6.8223255872726440e-01
    z[1,2,0]  R1250     -6.3873386383056641e-01
    z[1,2,0]  R1251     -6.0326629877090454e-01
    z[1,2,0]  R1252     -6.0984796285629272e-01
    z[1,2,0]  R1253     5.6926918029785156e-01
    z[1,2,0]  R1254     -5.7782799005508423e-02
    z[1,2,0]  R1255     -6.3951557874679565e-01
    z[1,2,0]  R1256     -6.9014227390289307e-01
    z[1,2,0]  R1257     4.5249709486961365e-01
    z[1,2,0]  R1258     -6.7513942718505859e-02
    z[1,2,0]  R1259     -1.5221396088600159e-01
    z[1,2,0]  R1260     -3.7763002514839172e-01
    z[1,2,0]  R1261     -3.0197069048881531e-01
    z[1,2,0]  R1262     5.5052733421325684e-01
    z[1,2,0]  R1263     0.402831107378006
    z[1,2,0]  R1264     0.676831066608429
    z[1,2,0]  R1265     1.1956851184368134e-01
    z[1,2,0]  R1266     -7.8148734569549561e-01
    z[1,2,0]  R1267     6.5265917778015137e-01
    z[1,2,0]  R1268     -7.2481507062911987e-01
    z[1,2,0]  R1269     3.8184890151023865e-01
    z[1,2,0]  R1270     4.3753212690353394e-01
    z[1,2,0]  R1271     -7.1952289342880249e-01
    z[1,2,0]  R1272     4.2336440086364746e-01
    z[1,2,0]  R1273     -1.8188993632793427e-01
    z[1,2,0]  R1274     0.668256938457489
    z[1,2,0]  R1275     4.7530296444892883e-01
    z[1,2,0]  R1276     7.9442560672760010e-01
    z[1,2,0]  R1277     0.531466007232666
    z[1,2,0]  R1278     5.7659108191728592e-02
    z[1,2,0]  R1279     3.7302851676940918e-01
    z[1,2,0]  R1280     1.3967619836330414e-01
    z[1,2,0]  R1281     9.8253987729549408e-02
    z[1,2,0]  R1282     -1.2154962867498398e-02
    z[1,2,0]  R1283     3.6504435539245605e-01
    z[1,2,0]  R1284     2.6145428419113159e-01
    z[1,2,0]  R1285     1.4792186021804810e-01
    z[1,2,0]  R1286     1.0102129727602005e-01
    z[1,2,0]  R1287     -7.0512253046035767e-01
    z[1,2,0]  R1288     3.8878908753395081e-01
    z[1,2,0]  R1289     3.1997001171112061e-01
    z[1,2,0]  R1290     2.2307321429252625e-01
    z[1,2,0]  R1291     2.2730773314833641e-02
    z[1,2,0]  R1292     5.2008849382400513e-01
    z[1,2,0]  R1293     -2.0841567218303680e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R1173     -1
    z[1,2,1]  R1174     1
    z[1,2,1]  R1185     -8.4220498800277710e-02
    z[1,2,1]  R1186     0.361508309841156
    z[1,2,1]  R1187     4.8457989096641541e-01
    z[1,2,1]  R1188     -3.2911914587020874e-01
    z[1,2,1]  R1189     3.3398628234863281e-01
    z[1,2,1]  R1190     -4.8228830099105835e-01
    z[1,2,1]  R1191     -1.9169540703296661e-01
    z[1,2,1]  R1192     2.1775195002555847e-01
    z[1,2,1]  R1193     -2.4984495341777802e-01
    z[1,2,1]  R1194     2.1840962767601013e-01
    z[1,2,1]  R1195     3.6695379018783569e-01
    z[1,2,1]  R1196     6.5316796302795410e-01
    z[1,2,1]  R1197     0.657727062702179
    z[1,2,1]  R1198     6.4585006237030029e-01
    z[1,2,1]  R1199     7.4338763952255249e-01
    z[1,2,1]  R1200     7.0508313179016113e-01
    z[1,2,1]  R1201     7.9247128963470459e-01
    z[1,2,1]  R1202     8.2078307867050171e-01
    z[1,2,1]  R1203     3.3597180247306824e-01
    z[1,2,1]  R1204     3.2437753677368164e-01
    z[1,2,1]  R1205     8.7639510631561279e-01
    z[1,2,1]  R1206     0.31130251288414
    z[1,2,1]  R1207     -4.1803106665611267e-01
    z[1,2,1]  R1208     1.0529877245426178e-01
    z[1,2,1]  R1209     1.0849340260028839e-01
    z[1,2,1]  R1210     2.3467201739549637e-02
    z[1,2,1]  R1211     -2.1112029254436493e-01
    z[1,2,1]  R1212     1.6639775037765503e-01
    z[1,2,1]  R1213     -6.7488527856767178e-03
    z[1,2,1]  R1214     -6.3168264925479889e-02
    z[1,2,1]  R1215     0.547184944152832
    z[1,2,1]  R1216     1.0742236673831940e-01
    z[1,2,1]  R1217     0.407914936542511
    z[1,2,1]  R1218     4.4724959135055542e-01
    z[1,2,1]  R1219     3.4217163920402527e-01
    z[1,2,1]  R1220     1.4415302872657776e-01
    z[1,2,1]  R1221     3.5020154714584351e-01
    z[1,2,1]  R1222     3.6574858427047729e-01
    z[1,2,1]  R1223     -4.1784530878067017e-01
    z[1,2,1]  R1224     -3.3625042438507080e-01
    z[1,2,1]  R1225     8.6969435214996338e-01
    z[1,2,1]  R1226     8.6631134152412415e-02
    z[1,2,1]  R1227     1.4700804650783539e-01
    z[1,2,1]  R1228     -3.5427924990653992e-01
    z[1,2,1]  R1229     -6.7064750194549561e-01
    z[1,2,1]  R1230     -7.4182587862014771e-01
    z[1,2,1]  R1231     -7.4127340316772461e-01
    z[1,2,1]  R1232     -7.2319769859313965e-01
    z[1,2,1]  R1233     -7.1683096885681152e-01
    z[1,2,1]  R1234     -6.9388502836227417e-01
    z[1,2,1]  R1235     -1.6133917868137360e-01
    z[1,2,1]  R1236     -1.8875263631343842e-01
    z[1,2,1]  R1237     -1.4964066445827484e-01
    z[1,2,1]  R1238     -6.5964251756668091e-01
    z[1,2,1]  R1239     7.8889004886150360e-02
    z[1,2,1]  R1240     1.8604267388582230e-02
    z[1,2,1]  R1241     -1.1806106194853783e-02
    z[1,2,1]  R1242     5.4581854492425919e-02
    z[1,2,1]  R1243     -1.2077865749597549e-01
    z[1,2,1]  R1244     5.2824807353317738e-03
    z[1,2,1]  R1245     8.4847694635391235e-01
    z[1,2,1]  R1246     8.0799955129623413e-01
    z[1,2,1]  R1247     7.9552549123764038e-01
    z[1,2,1]  R1248     8.1549555063247681e-01
    z[1,2,1]  R1249     3.7019926309585571e-01
    z[1,2,1]  R1250     2.2374063730239868e-01
    z[1,2,1]  R1251     8.6924374103546143e-02
    z[1,2,1]  R1252     3.7069177627563477e-01
    z[1,2,1]  R1253     3.9249441027641296e-01
    z[1,2,1]  R1254     6.4467805624008179e-01
    z[1,2,1]  R1255     -1.0548141598701477e-01
    z[1,2,1]  R1256     -1.2155154347419739e-01
    z[1,2,1]  R1257     -5.4345929622650146e-01
    z[1,2,1]  R1258     2.1160256862640381e-01
    z[1,2,1]  R1259     8.4358178079128265e-02
    z[1,2,1]  R1260     -4.2696982622146606e-02
    z[1,2,1]  R1261     -1.6924735158681870e-02
    z[1,2,1]  R1262     3.2430076599121094e-01
    z[1,2,1]  R1263     3.4691080451011658e-02
    z[1,2,1]  R1264     8.5422113537788391e-02
    z[1,2,1]  R1265     5.7380330562591553e-01
    z[1,2,1]  R1266     -1.3982464373111725e-01
    z[1,2,1]  R1267     5.3358948230743408e-01
    z[1,2,1]  R1268     -9.4836302101612091e-02
    z[1,2,1]  R1269     0.49685138463974
    z[1,2,1]  R1270     4.8165795207023621e-01
    z[1,2,1]  R1271     -1.6482116281986237e-01
    z[1,2,1]  R1272     4.7156643867492676e-01
    z[1,2,1]  R1273     2.8162896633148193e-01
    z[1,2,1]  R1274     1.7092798650264740e-01
    z[1,2,1]  R1275     7.1815800666809082e-01
    z[1,2,1]  R1276     -1.8876178562641144e-01
    z[1,2,1]  R1277     1.4198282361030579e-01
    z[1,2,1]  R1278     3.8490608334541321e-01
    z[1,2,1]  R1279     4.1333901882171631e-01
    z[1,2,1]  R1280     3.3508679270744324e-01
    z[1,2,1]  R1281     -1.2112998217344284e-01
    z[1,2,1]  R1282     -1.4878851175308228e-01
    z[1,2,1]  R1283     -4.0528278797864914e-02
    z[1,2,1]  R1284     -2.2516460716724396e-01
    z[1,2,1]  R1285     4.0738192200660706e-01
    z[1,2,1]  R1286     3.3872112631797791e-01
    z[1,2,1]  R1287     2.9937621951103210e-01
    z[1,2,1]  R1288     3.7586104869842529e-01
    z[1,2,1]  R1289     -5.2003145217895508e-01
    z[1,2,1]  R1290     2.3173166811466217e-01
    z[1,2,1]  R1291     -3.7086048722267151e-01
    z[1,2,1]  R1292     -5.2467468194663525e-03
    z[1,2,1]  R1293     -4.5383399724960327e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R1175     -1
    z[1,2,2]  R1176     1
    z[1,2,2]  R1185     7.9628866910934448e-01
    z[1,2,2]  R1186     6.2952286005020142e-01
    z[1,2,2]  R1187     2.3803453147411346e-01
    z[1,2,2]  R1188     3.5012251138687134e-01
    z[1,2,2]  R1189     1.6661569476127625e-01
    z[1,2,2]  R1190     3.0057954788208008e-01
    z[1,2,2]  R1191     -7.2683282196521759e-02
    z[1,2,2]  R1192     -2.0050784945487976e-01
    z[1,2,2]  R1193     5.0285577774047852e-01
    z[1,2,2]  R1194     0.00567758409306407
    z[1,2,2]  R1195     -2.1179307997226715e-01
    z[1,2,2]  R1196     -5.8393353223800659e-01
    z[1,2,2]  R1197     -4.0201231837272644e-01
    z[1,2,2]  R1198     -3.8458973169326782e-01
    z[1,2,2]  R1199     4.2064037173986435e-02
    z[1,2,2]  R1200     -2.8824952244758606e-01
    z[1,2,2]  R1201     -2.4844953417778015e-01
    z[1,2,2]  R1202     -1.5014594793319702e-01
    z[1,2,2]  R1203     -3.6241721361875534e-02
    z[1,2,2]  R1204     1.1564271897077560e-01
    z[1,2,2]  R1205     1.7821869254112244e-01
    z[1,2,2]  R1206     -2.7339941263198853e-01
    z[1,2,2]  R1207     -6.2284684181213379e-01
    z[1,2,2]  R1208     9.8502419888973236e-02
    z[1,2,2]  R1209     -8.4907189011573792e-02
    z[1,2,2]  R1210     -3.7734252214431763e-01
    z[1,2,2]  R1211     1.1531513929367065e-01
    z[1,2,2]  R1212     -3.3423385024070740e-01
    z[1,2,2]  R1213     6.3833691179752350e-02
    z[1,2,2]  R1214     -3.4744244813919067e-01
    z[1,2,2]  R1215     -3.5237598419189453e-01
    z[1,2,2]  R1216     1.0244900733232498e-01
    z[1,2,2]  R1217     -7.7153556048870087e-02
    z[1,2,2]  R1218     -1.8872264027595520e-01
    z[1,2,2]  R1219     -5.5572193115949631e-02
    z[1,2,2]  R1220     7.1593075990676880e-02
    z[1,2,2]  R1221     1.0369773954153061e-02
    z[1,2,2]  R1222     -8.3991587162017822e-02
    z[1,2,2]  R1223     9.6030756831169128e-03
    z[1,2,2]  R1224     -3.5265704989433289e-01
    z[1,2,2]  R1225     -2.3279662430286407e-01
    z[1,2,2]  R1226     2.2210830822587013e-02
    z[1,2,2]  R1227     1.0618493705987930e-01
    z[1,2,2]  R1228     -1.7527283728122711e-01
    z[1,2,2]  R1229     3.4023147821426392e-01
    z[1,2,2]  R1230     -3.2223331928253174e-01
    z[1,2,2]  R1231     -1.6301706433296204e-01
    z[1,2,2]  R1232     -1.1810306459665298e-01
    z[1,2,2]  R1233     -2.4931703507900238e-01
    z[1,2,2]  R1234     -0.291786253452301
    z[1,2,2]  R1235     5.5405408143997192e-01
    z[1,2,2]  R1236     3.0208969116210938e-01
    z[1,2,2]  R1237     4.4547548890113831e-01
    z[1,2,2]  R1238     4.7857272624969482e-01
    z[1,2,2]  R1239     6.4202749729156494e-01
    z[1,2,2]  R1240     8.1291161477565765e-02
    z[1,2,2]  R1241     4.4162884354591370e-02
    z[1,2,2]  R1242     -1.8790006870403886e-03
    z[1,2,2]  R1243     -2.3436856269836426e-01
    z[1,2,2]  R1244     -2.3957021534442902e-01
    z[1,2,2]  R1245     -4.2595416307449341e-01
    z[1,2,2]  R1246     -5.2947640419006348e-01
    z[1,2,2]  R1247     -0.502391517162323
    z[1,2,2]  R1248     -4.5143491029739380e-01
    z[1,2,2]  R1249     -0.36711585521698
    z[1,2,2]  R1250     -4.1537192463874817e-01
    z[1,2,2]  R1251     -4.2701101303100586e-01
    z[1,2,2]  R1252     -1.5642069280147552e-01
    z[1,2,2]  R1253     4.9039289355278015e-01
    z[1,2,2]  R1254     -6.6163659095764160e-02
    z[1,2,2]  R1255     -2.6565429568290710e-01
    z[1,2,2]  R1256     -3.1715756654739380e-01
    z[1,2,2]  R1257     -5.7490535080432892e-02
    z[1,2,2]  R1258     -3.7725567817687988e-01
    z[1,2,2]  R1259     -1.4679531753063202e-01
    z[1,2,2]  R1260     3.9403751492500305e-02
    z[1,2,2]  R1261     2.0407268404960632e-01
    z[1,2,2]  R1262     2.6282489299774170e-01
    z[1,2,2]  R1263     -4.7353811562061310e-02
    z[1,2,2]  R1264     -1.6353714466094971e-01
    z[1,2,2]  R1265     2.9847669601440430e-01
    z[1,2,2]  R1266     -1.3640609383583069e-01
    z[1,2,2]  R1267     2.2130960226058960e-01
    z[1,2,2]  R1268     -8.3762980997562408e-02
    z[1,2,2]  R1269     2.1198947727680206e-01
    z[1,2,2]  R1270     3.2118758559226990e-01
    z[1,2,2]  R1271     -3.8719365000724792e-01
    z[1,2,2]  R1272     2.0314460992813110e-01
    z[1,2,2]  R1273     -3.0454638600349426e-01
    z[1,2,2]  R1274     -4.2584415525197983e-02
    z[1,2,2]  R1275     -9.1633729636669159e-02
    z[1,2,2]  R1276     -3.4959834069013596e-02
    z[1,2,2]  R1277     -3.4006664156913757e-01
    z[1,2,2]  R1278     6.0803387314081192e-02
    z[1,2,2]  R1279     6.2868803739547729e-02
    z[1,2,2]  R1280     2.2307692468166351e-01
    z[1,2,2]  R1281     1.4269936084747314e-01
    z[1,2,2]  R1282     -1.7905475571751595e-02
    z[1,2,2]  R1283     1.4066404104232788e-01
    z[1,2,2]  R1284     -3.2815438508987427e-01
    z[1,2,2]  R1285     -1.9858621060848236e-01
    z[1,2,2]  R1286     -4.4785720109939575e-01
    z[1,2,2]  R1287     -3.6400568485260010e-01
    z[1,2,2]  R1288     -7.2100780904293060e-02
    z[1,2,2]  R1289     -1.2152507901191711e-01
    z[1,2,2]  R1290     4.7754812985658646e-02
    z[1,2,2]  R1291     7.7282279729843140e-02
    z[1,2,2]  R1292     -2.3688524961471558e-01
    z[1,2,2]  R1293     -0.737982451915741
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R1177     -1
    z[1,2,3]  R1178     1
    z[1,2,3]  R1185     -1.0823883116245270e-01
    z[1,2,3]  R1186     0.356587290763855
    z[1,2,3]  R1187     6.0027605295181274e-01
    z[1,2,3]  R1188     5.1075166463851929e-01
    z[1,2,3]  R1189     5.3740882873535156e-01
    z[1,2,3]  R1190     1.0916360467672348e-01
    z[1,2,3]  R1191     4.9610521644353867e-02
    z[1,2,3]  R1192     2.6247090101242065e-01
    z[1,2,3]  R1193     3.9771571755409241e-01
    z[1,2,3]  R1194     4.4433519244194031e-01
    z[1,2,3]  R1195     2.9319867491722107e-01
    z[1,2,3]  R1196     -1.5360046923160553e-01
    z[1,2,3]  R1197     -2.7590749785304070e-02
    z[1,2,3]  R1198     2.2711518406867981e-01
    z[1,2,3]  R1199     -1.6082301735877991e-01
    z[1,2,3]  R1200     -6.8718180060386658e-02
    z[1,2,3]  R1201     3.1026366353034973e-01
    z[1,2,3]  R1202     -5.8440599590539932e-02
    z[1,2,3]  R1203     -4.1871690191328526e-03
    z[1,2,3]  R1204     -4.1127860546112061e-02
    z[1,2,3]  R1205     -3.3243077993392944e-01
    z[1,2,3]  R1206     -6.8526461720466614e-02
    z[1,2,3]  R1207     -8.7724313139915466e-02
    z[1,2,3]  R1208     -3.5257175564765930e-01
    z[1,2,3]  R1209     -2.9554140567779541e-01
    z[1,2,3]  R1210     -2.9453948140144348e-01
    z[1,2,3]  R1211     -3.3523476123809814e-01
    z[1,2,3]  R1212     -3.7054210901260376e-01
    z[1,2,3]  R1213     -4.7129637002944946e-01
    z[1,2,3]  R1214     -3.0005259439349174e-02
    z[1,2,3]  R1215     -3.7874984741210938e-01
    z[1,2,3]  R1216     9.7439870238304138e-02
    z[1,2,3]  R1217     -3.0197608470916748e-01
    z[1,2,3]  R1218     -2.0218986272811890e-01
    z[1,2,3]  R1219     -1.5474145114421844e-01
    z[1,2,3]  R1220     -4.0473595261573792e-02
    z[1,2,3]  R1221     9.7739197313785553e-02
    z[1,2,3]  R1222     -2.5048962235450745e-01
    z[1,2,3]  R1223     -3.2698279619216919e-01
    z[1,2,3]  R1224     -2.5443577766418457e-01
    z[1,2,3]  R1225     -1.5198162198066711e-01
    z[1,2,3]  R1226     -3.0203291773796082e-01
    z[1,2,3]  R1227     -3.0847027897834778e-01
    z[1,2,3]  R1228     -3.9656361937522888e-01
    z[1,2,3]  R1229     -9.1805262491106987e-03
    z[1,2,3]  R1230     -1.6141927242279053e-01
    z[1,2,3]  R1231     -2.9566857218742371e-01
    z[1,2,3]  R1232     -1.8786433339118958e-01
    z[1,2,3]  R1233     -3.1983304023742676e-01
    z[1,2,3]  R1234     1.8618069589138031e-01
    z[1,2,3]  R1235     1.9688328728079796e-02
    z[1,2,3]  R1236     2.5863319635391235e-02
    z[1,2,3]  R1237     -5.6284625083208084e-02
    z[1,2,3]  R1238     -1.7577295005321503e-01
    z[1,2,3]  R1239     -2.0616275072097778e-01
    z[1,2,3]  R1240     5.9721589088439941e-01
    z[1,2,3]  R1241     3.6833903193473816e-01
    z[1,2,3]  R1242     3.0313912034034729e-01
    z[1,2,3]  R1243     4.2844411730766296e-01
    z[1,2,3]  R1244     5.3503030538558960e-01
    z[1,2,3]  R1245     -1.0913491994142532e-01
    z[1,2,3]  R1246     -7.2018451988697052e-02
    z[1,2,3]  R1247     -2.4380747228860855e-02
    z[1,2,3]  R1248     2.8135562315583229e-02
    z[1,2,3]  R1249     2.9551374912261963e-01
    z[1,2,3]  R1250     -2.6950290799140930e-01
    z[1,2,3]  R1251     0.536393404006958
    z[1,2,3]  R1252     -4.9610573053359985e-01
    z[1,2,3]  R1253     3.1855475902557373e-01
    z[1,2,3]  R1254     2.5723496079444885e-01
    z[1,2,3]  R1255     -7.3913954198360443e-02
    z[1,2,3]  R1256     -0.0710030347108841
    z[1,2,3]  R1257     2.6913684606552124e-01
    z[1,2,3]  R1258     -4.8549634218215942e-01
    z[1,2,3]  R1259     -2.1894189715385437e-01
    z[1,2,3]  R1260     -3.2744863629341125e-01
    z[1,2,3]  R1261     -4.1578125953674316e-01
    z[1,2,3]  R1262     -9.1020818799734116e-03
    z[1,2,3]  R1263     -1.1704139411449432e-01
    z[1,2,3]  R1264     -2.7253192663192749e-01
    z[1,2,3]  R1265     -4.1588541865348816e-01
    z[1,2,3]  R1266     1.8047462403774261e-01
    z[1,2,3]  R1267     1.8411104381084442e-01
    z[1,2,3]  R1268     -2.1536672487854958e-02
    z[1,2,3]  R1269     2.3278267681598663e-01
    z[1,2,3]  R1270     -4.0269672870635986e-01
    z[1,2,3]  R1271     8.3176698535680771e-03
    z[1,2,3]  R1272     1.4700825512409210e-01
    z[1,2,3]  R1273     -4.5856767892837524e-01
    z[1,2,3]  R1274     -4.3998207896947861e-02
    z[1,2,3]  R1275     1.2758034281432629e-02
    z[1,2,3]  R1276     0.0983872041106224
    z[1,2,3]  R1277     6.8053025007247925e-01
    z[1,2,3]  R1278     -5.4386472702026367e-01
    z[1,2,3]  R1279     -3.4815445542335510e-01
    z[1,2,3]  R1280     -2.9917529225349426e-01
    z[1,2,3]  R1281     -3.3609643578529358e-01
    z[1,2,3]  R1282     -6.1731004714965820e-01
    z[1,2,3]  R1283     -6.9499629735946655e-01
    z[1,2,3]  R1284     -2.3235796391963959e-01
    z[1,2,3]  R1285     -3.8140979409217834e-01
    z[1,2,3]  R1286     -4.0274840593338013e-01
    z[1,2,3]  R1287     -4.0840244293212891e-01
    z[1,2,3]  R1288     -5.4294604063034058e-01
    z[1,2,3]  R1289     7.1361762285232544e-01
    z[1,2,3]  R1290     -2.2852474451065063e-01
    z[1,2,3]  R1291     -3.5795214772224426e-01
    z[1,2,3]  R1292     -2.6905605196952820e-01
    z[1,2,3]  R1293     5.6580636650323868e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R1179     -1
    z[1,2,4]  R1180     1
    z[1,2,4]  R1185     1.4760370831936598e-03
    z[1,2,4]  R1186     4.1524812579154968e-02
    z[1,2,4]  R1187     -2.6050312444567680e-02
    z[1,2,4]  R1188     5.8437857776880264e-02
    z[1,2,4]  R1189     -1.7981484532356262e-01
    z[1,2,4]  R1190     -7.4437371222302318e-04
    z[1,2,4]  R1191     2.3300166428089142e-01
    z[1,2,4]  R1192     2.0796832442283630e-01
    z[1,2,4]  R1193     1.1065878719091415e-01
    z[1,2,4]  R1194     2.0427180826663971e-01
    z[1,2,4]  R1195     1.6974899172782898e-01
    z[1,2,4]  R1196     -4.4538193941116333e-01
    z[1,2,4]  R1197     -3.1974750757217407e-01
    z[1,2,4]  R1198     -1.9922609627246857e-01
    z[1,2,4]  R1199     -2.7087783813476562e-01
    z[1,2,4]  R1200     2.0275993272662163e-02
    z[1,2,4]  R1201     1.0352526605129242e-01
    z[1,2,4]  R1202     -1.5411649644374847e-01
    z[1,2,4]  R1203     -9.2224171385169029e-03
    z[1,2,4]  R1204     1.1496607959270477e-01
    z[1,2,4]  R1205     1.1724268645048141e-01
    z[1,2,4]  R1206     8.7437534332275391e-01
    z[1,2,4]  R1207     -1.4307887852191925e-01
    z[1,2,4]  R1208     8.4778529405593872e-01
    z[1,2,4]  R1209     5.1797825098037720e-01
    z[1,2,4]  R1210     7.7364194393157959e-01
    z[1,2,4]  R1211     8.4896445274353027e-01
    z[1,2,4]  R1212     0.667140781879425
    z[1,2,4]  R1213     6.5066725015640259e-01
    z[1,2,4]  R1214     -2.4185539782047272e-01
    z[1,2,4]  R1215     -8.3446763455867767e-02
    z[1,2,4]  R1216     8.9992147684097290e-01
    z[1,2,4]  R1217     -2.5832799077033997e-01
    z[1,2,4]  R1218     1.7638940364122391e-02
    z[1,2,4]  R1219     -4.6297335624694824e-01
    z[1,2,4]  R1220     -7.9953235387802124e-01
    z[1,2,4]  R1221     -7.4610334634780884e-01
    z[1,2,4]  R1222     7.0542466640472412e-01
    z[1,2,4]  R1223     6.1648392677307129e-01
    z[1,2,4]  R1224     1.2818135321140289e-01
    z[1,2,4]  R1225     2.1970003843307495e-01
    z[1,2,4]  R1226     -2.5865370035171509e-01
    z[1,2,4]  R1227     6.4369821548461914e-01
    z[1,2,4]  R1228     5.0892108678817749e-01
    z[1,2,4]  R1229     -1.2675713002681732e-01
    z[1,2,4]  R1230     9.5251753926277161e-02
    z[1,2,4]  R1231     -7.3320806026458740e-02
    z[1,2,4]  R1232     -5.4239153861999512e-02
    z[1,2,4]  R1233     -1.0252785682678223e-01
    z[1,2,4]  R1234     2.8734045103192329e-02
    z[1,2,4]  R1235     1.6780348122119904e-01
    z[1,2,4]  R1236     -9.5293030142784119e-02
    z[1,2,4]  R1237     -5.0396603345870972e-01
    z[1,2,4]  R1238     1.4677263796329498e-01
    z[1,2,4]  R1239     -3.6618176102638245e-01
    z[1,2,4]  R1240     -4.2743611335754395e-01
    z[1,2,4]  R1241     -2.1006008982658386e-01
    z[1,2,4]  R1242     -7.2236508131027222e-01
    z[1,2,4]  R1243     -0.205518439412117
    z[1,2,4]  R1244     -5.8308511972427368e-01
    z[1,2,4]  R1245     -5.9225648641586304e-02
    z[1,2,4]  R1246     -1.6364024579524994e-01
    z[1,2,4]  R1247     -2.3171067237854004e-01
    z[1,2,4]  R1248     1.4094124734401703e-01
    z[1,2,4]  R1249     3.2538506388664246e-01
    z[1,2,4]  R1250     0.0657089427113533
    z[1,2,4]  R1251     3.0613413453102112e-01
    z[1,2,4]  R1252     3.8916683197021484e-01
    z[1,2,4]  R1253     2.6407399773597717e-01
    z[1,2,4]  R1254     1.0766576230525970e-01
    z[1,2,4]  R1255     3.0829259753227234e-01
    z[1,2,4]  R1256     0.542674720287323
    z[1,2,4]  R1257     -3.5133257508277893e-01
    z[1,2,4]  R1258     6.7589128017425537e-01
    z[1,2,4]  R1259     9.3958681821823120e-01
    z[1,2,4]  R1260     8.3078670501708984e-01
    z[1,2,4]  R1261     7.6595938205718994e-01
    z[1,2,4]  R1262     -3.4655591845512390e-01
    z[1,2,4]  R1263     8.8376337289810181e-01
    z[1,2,4]  R1264     6.3066780567169189e-01
    z[1,2,4]  R1265     3.0546778440475464e-01
    z[1,2,4]  R1266     0.541685938835144
    z[1,2,4]  R1267     2.6552131772041321e-01
    z[1,2,4]  R1268     5.4971385002136230e-01
    z[1,2,4]  R1269     1.4752371609210968e-01
    z[1,2,4]  R1270     3.7905752658843994e-01
    z[1,2,4]  R1271     1.2931534647941589e-01
    z[1,2,4]  R1272     -2.2250978276133537e-02
    z[1,2,4]  R1273     0.729640543460846
    z[1,2,4]  R1274     -6.8487298488616943e-01
    z[1,2,4]  R1275     -4.5553824305534363e-01
    z[1,2,4]  R1276     -4.0139034390449524e-01
    z[1,2,4]  R1277     3.2666096091270447e-01
    z[1,2,4]  R1278     6.5018379688262939e-01
    z[1,2,4]  R1279     0.615688145160675
    z[1,2,4]  R1280     6.1329811811447144e-01
    z[1,2,4]  R1281     6.6873502731323242e-01
    z[1,2,4]  R1282     6.3954770565032959e-01
    z[1,2,4]  R1283     3.2765284180641174e-01
    z[1,2,4]  R1284     6.7813855409622192e-01
    z[1,2,4]  R1285     -5.0727075338363647e-01
    z[1,2,4]  R1286     -3.3661961555480957e-01
    z[1,2,4]  R1287     9.8570518195629120e-02
    z[1,2,4]  R1288     6.1248999834060669e-01
    z[1,2,4]  R1289     -3.7129085510969162e-02
    z[1,2,4]  R1290     7.7158856391906738e-01
    z[1,2,4]  R1291     7.6849943399429321e-01
    z[1,2,4]  R1292     0.732159435749054
    z[1,2,4]  R1293     5.8081064373254776e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R1181     -1
    z[1,2,5]  R1182     1
    z[1,2,5]  R1185     -4.6309524774551392e-01
    z[1,2,5]  R1186     -4.9777108430862427e-01
    z[1,2,5]  R1187     -4.2009532451629639e-01
    z[1,2,5]  R1188     -7.0185315608978271e-01
    z[1,2,5]  R1189     -6.2715178728103638e-01
    z[1,2,5]  R1190     -0.702717125415802
    z[1,2,5]  R1191     -7.4101728200912476e-01
    z[1,2,5]  R1192     -8.6752545833587646e-01
    z[1,2,5]  R1193     -3.7044957280158997e-01
    z[1,2,5]  R1194     -1.9174227118492126e-01
    z[1,2,5]  R1195     -4.8559173941612244e-01
    z[1,2,5]  R1196     -1.7354622483253479e-02
    z[1,2,5]  R1197     -7.6631464064121246e-02
    z[1,2,5]  R1198     5.7139031589031219e-02
    z[1,2,5]  R1199     1.1248541623353958e-01
    z[1,2,5]  R1200     1.1797171086072922e-01
    z[1,2,5]  R1201     2.0577445626258850e-01
    z[1,2,5]  R1202     4.0649777650833130e-01
    z[1,2,5]  R1203     -1.2953018769621849e-02
    z[1,2,5]  R1204     7.9326741397380829e-02
    z[1,2,5]  R1205     -1.7031390964984894e-01
    z[1,2,5]  R1206     0.214023619890213
    z[1,2,5]  R1207     3.6025542020797729e-01
    z[1,2,5]  R1208     1.0420871526002884e-01
    z[1,2,5]  R1209     7.6388245820999146e-01
    z[1,2,5]  R1210     -2.0823728293180466e-02
    z[1,2,5]  R1211     3.0105376243591309e-01
    z[1,2,5]  R1212     -2.1040309220552444e-02
    z[1,2,5]  R1213     4.6810010075569153e-01
    z[1,2,5]  R1214     5.6569927930831909e-01
    z[1,2,5]  R1215     -5.4583930969238281e-01
    z[1,2,5]  R1216     -2.8972637653350830e-01
    z[1,2,5]  R1217     -7.1383011341094971e-01
    z[1,2,5]  R1218     1.3720458745956421e-01
    z[1,2,5]  R1219     1.3389253616333008e-01
    z[1,2,5]  R1220     -0.0657874047756195
    z[1,2,5]  R1221     5.4046556353569031e-02
    z[1,2,5]  R1222     -1.2181343883275986e-01
    z[1,2,5]  R1223     5.0305038690567017e-01
    z[1,2,5]  R1224     5.5670654773712158e-01
    z[1,2,5]  R1225     -3.3804804086685181e-01
    z[1,2,5]  R1226     1.0120960325002670e-01
    z[1,2,5]  R1227     5.6893342733383179e-01
    z[1,2,5]  R1228     5.1979804039001465e-01
    z[1,2,5]  R1229     7.6164029538631439e-02
    z[1,2,5]  R1230     2.9966291785240173e-01
    z[1,2,5]  R1231     2.8683552145957947e-01
    z[1,2,5]  R1232     4.4693747162818909e-01
    z[1,2,5]  R1233     3.0494108796119690e-01
    z[1,2,5]  R1234     3.9764198660850525e-01
    z[1,2,5]  R1235     -1.5103656053543091e-01
    z[1,2,5]  R1236     -6.2295131385326385e-02
    z[1,2,5]  R1237     -0.0794144868850708
    z[1,2,5]  R1238     -7.3905050754547119e-02
    z[1,2,5]  R1239     -0.553706169128418
    z[1,2,5]  R1240     -0.50154048204422
    z[1,2,5]  R1241     -8.5121077299118042e-01
    z[1,2,5]  R1242     -5.6201732158660889e-01
    z[1,2,5]  R1243     -6.5065312385559082e-01
    z[1,2,5]  R1244     -0.338346391916275
    z[1,2,5]  R1245     -8.2619205117225647e-02
    z[1,2,5]  R1246     -1.1536671966314316e-01
    z[1,2,5]  R1247     -1.1266986839473248e-02
    z[1,2,5]  R1248     -3.0776521563529968e-01
    z[1,2,5]  R1249     2.1929222345352173e-01
    z[1,2,5]  R1250     4.4513073563575745e-01
    z[1,2,5]  R1251     2.4503825604915619e-01
    z[1,2,5]  R1252     2.3875932395458221e-01
    z[1,2,5]  R1253     2.1600700914859772e-01
    z[1,2,5]  R1254     3.1031739711761475e-01
    z[1,2,5]  R1255     -5.0032925605773926e-01
    z[1,2,5]  R1256     -6.4615093171596527e-02
    z[1,2,5]  R1257     -3.0091321095824242e-03
    z[1,2,5]  R1258     -9.5629818737506866e-02
    z[1,2,5]  R1259     0.0893244668841362
    z[1,2,5]  R1260     -2.0185333490371704e-01
    z[1,2,5]  R1261     -5.3852040320634842e-02
    z[1,2,5]  R1262     4.5460018515586853e-01
    z[1,2,5]  R1263     1.1297465115785599e-01
    z[1,2,5]  R1264     -1.1456539481878281e-01
    z[1,2,5]  R1265     5.3864598274230957e-01
    z[1,2,5]  R1266     -1.5818008780479431e-01
    z[1,2,5]  R1267     -2.5313705205917358e-01
    z[1,2,5]  R1268     3.8068592548370361e-01
    z[1,2,5]  R1269     6.9146496057510376e-01
    z[1,2,5]  R1270     1.8906120955944061e-01
    z[1,2,5]  R1271     2.3913174867630005e-01
    z[1,2,5]  R1272     2.2060884535312653e-01
    z[1,2,5]  R1273     -1.7037029564380646e-01
    z[1,2,5]  R1274     1.4622513949871063e-01
    z[1,2,5]  R1275     -1.1423914879560471e-01
    z[1,2,5]  R1276     -1.4322666823863983e-01
    z[1,2,5]  R1277     -1.0807734727859497e-01
    z[1,2,5]  R1278     1.5783878043293953e-02
    z[1,2,5]  R1279     4.9813590943813324e-02
    z[1,2,5]  R1280     -1.0862774401903152e-01
    z[1,2,5]  R1281     5.8036959171295166e-01
    z[1,2,5]  R1282     4.1192063689231873e-01
    z[1,2,5]  R1283     5.0464153289794922e-01
    z[1,2,5]  R1284     4.2999365925788879e-01
    z[1,2,5]  R1285     -5.0462526082992554e-01
    z[1,2,5]  R1286     -1.6671015322208405e-01
    z[1,2,5]  R1287     1.7743869125843048e-01
    z[1,2,5]  R1288     9.9554657936096191e-02
    z[1,2,5]  R1289     2.8193006291985512e-02
    z[1,2,5]  R1290     -2.9880398511886597e-01
    z[1,2,5]  R1291     3.6627429723739624e-01
    z[1,2,5]  R1292     -1.4255641959607601e-02
    z[1,2,5]  R1293     3.4274047613143921e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R1183     -1
    z[1,2,6]  R1184     1
    z[1,2,6]  R1185     -1.4961341023445129e-01
    z[1,2,6]  R1186     2.1387757360935211e-01
    z[1,2,6]  R1187     0.087035171687603
    z[1,2,6]  R1188     -8.3404621109366417e-03
    z[1,2,6]  R1189     -1.8069240450859070e-01
    z[1,2,6]  R1190     0.287383496761322
    z[1,2,6]  R1191     -4.4324392080307007e-01
    z[1,2,6]  R1192     7.8737497329711914e-02
    z[1,2,6]  R1193     5.5472618341445923e-01
    z[1,2,6]  R1194     7.5775671005249023e-01
    z[1,2,6]  R1195     3.4774962067604065e-01
    z[1,2,6]  R1196     9.1815330088138580e-02
    z[1,2,6]  R1197     -3.9528802037239075e-01
    z[1,2,6]  R1198     0.0697116032242775
    z[1,2,6]  R1199     2.9087954759597778e-01
    z[1,2,6]  R1200     3.2448939979076385e-02
    z[1,2,6]  R1201     -5.4661218076944351e-02
    z[1,2,6]  R1202     -2.4099057912826538e-01
    z[1,2,6]  R1203     -1.1285389959812164e-01
    z[1,2,6]  R1204     7.5361780822277069e-02
    z[1,2,6]  R1205     -2.4202053900808096e-03
    z[1,2,6]  R1206     1.1376570910215378e-01
    z[1,2,6]  R1207     5.3188685327768326e-02
    z[1,2,6]  R1208     -1.8500572443008423e-01
    z[1,2,6]  R1209     -7.9107824712991714e-03
    z[1,2,6]  R1210     -3.7395489215850830e-01
    z[1,2,6]  R1211     0.123031385242939
    z[1,2,6]  R1212     -5.0080728530883789e-01
    z[1,2,6]  R1213     -2.1072435379028320e-01
    z[1,2,6]  R1214     -2.5283247232437134e-01
    z[1,2,6]  R1215     3.4493315219879150e-01
    z[1,2,6]  R1216     2.6844039559364319e-01
    z[1,2,6]  R1217     -3.3700618147850037e-01
    z[1,2,6]  R1218     -3.2257422804832458e-01
    z[1,2,6]  R1219     -3.5320317745208740e-01
    z[1,2,6]  R1220     -2.6487755775451660e-01
    z[1,2,6]  R1221     -1.5535186231136322e-01
    z[1,2,6]  R1222     -4.2757540941238403e-01
    z[1,2,6]  R1223     2.8858572244644165e-01
    z[1,2,6]  R1224     -1.7450398206710815e-01
    z[1,2,6]  R1225     -2.6332248002290726e-02
    z[1,2,6]  R1226     -0.159862220287323
    z[1,2,6]  R1227     -3.2387372851371765e-01
    z[1,2,6]  R1228     -1.4186498522758484e-01
    z[1,2,6]  R1229     -2.2816176712512970e-01
    z[1,2,6]  R1230     -0.0744878277182579
    z[1,2,6]  R1231     -2.5121471285820007e-01
    z[1,2,6]  R1232     -2.8377154842019081e-02
    z[1,2,6]  R1233     -4.8527400940656662e-02
    z[1,2,6]  R1234     1.4812238514423370e-01
    z[1,2,6]  R1235     -2.5069481134414673e-01
    z[1,2,6]  R1236     2.0381264388561249e-01
    z[1,2,6]  R1237     -2.8867053985595703e-01
    z[1,2,6]  R1238     3.7670439481735229e-01
    z[1,2,6]  R1239     3.1335431337356567e-01
    z[1,2,6]  R1240     -1.0851830244064331e-01
    z[1,2,6]  R1241     4.4684566557407379e-02
    z[1,2,6]  R1242     1.6724999248981476e-01
    z[1,2,6]  R1243     4.3016341328620911e-01
    z[1,2,6]  R1244     3.4454837441444397e-01
    z[1,2,6]  R1245     -3.2937828451395035e-02
    z[1,2,6]  R1246     -1.2528675794601440e-01
    z[1,2,6]  R1247     6.4339734613895416e-02
    z[1,2,6]  R1248     -8.2796871662139893e-02
    z[1,2,6]  R1249     -1.4643880724906921e-01
    z[1,2,6]  R1250     3.0713915824890137e-01
    z[1,2,6]  R1251     6.8526528775691986e-02
    z[1,2,6]  R1252     -1.0783251374959946e-01
    z[1,2,6]  R1253     2.5204023718833923e-01
    z[1,2,6]  R1254     -6.3451957702636719e-01
    z[1,2,6]  R1255     3.9810085296630859e-01
    z[1,2,6]  R1256     3.2346194982528687e-01
    z[1,2,6]  R1257     5.4837477207183838e-01
    z[1,2,6]  R1258     3.2659384608268738e-01
    z[1,2,6]  R1259     -9.7096830606460571e-02
    z[1,2,6]  R1260     -1.2588070333003998e-01
    z[1,2,6]  R1261     -3.2313096523284912e-01
    z[1,2,6]  R1262     -4.4252294301986694e-01
    z[1,2,6]  R1263     -1.6365081071853638e-01
    z[1,2,6]  R1264     1.5072350203990936e-01
    z[1,2,6]  R1265     -1.0466154664754868e-01
    z[1,2,6]  R1266     1.0212297551333904e-02
    z[1,2,6]  R1267     2.6807376742362976e-01
    z[1,2,6]  R1268     -1.0517653077840805e-01
    z[1,2,6]  R1269     -9.1191403567790985e-02
    z[1,2,6]  R1270     3.6306518316268921e-01
    z[1,2,6]  R1271     4.8085975646972656e-01
    z[1,2,6]  R1272     -6.9738447666168213e-01
    z[1,2,6]  R1273     1.5220688283443451e-01
    z[1,2,6]  R1274     1.7330373823642731e-01
    z[1,2,6]  R1275     1.7091201245784760e-01
    z[1,2,6]  R1276     3.7513554096221924e-01
    z[1,2,6]  R1277     1.5162459574639797e-02
    z[1,2,6]  R1278     -3.5503348708152771e-01
    z[1,2,6]  R1279     -0.428116112947464
    z[1,2,6]  R1280     -5.8395510911941528e-01
    z[1,2,6]  R1281     -2.4148355424404144e-01
    z[1,2,6]  R1282     1.3274788856506348e-01
    z[1,2,6]  R1283     -1.6567483544349670e-02
    z[1,2,6]  R1284     2.7294814586639404e-01
    z[1,2,6]  R1285     3.3952745795249939e-01
    z[1,2,6]  R1286     6.0924154520034790e-01
    z[1,2,6]  R1287     2.6959735155105591e-01
    z[1,2,6]  R1288     -1.5009182691574097e-01
    z[1,2,6]  R1289     3.1779631972312927e-01
    z[1,2,6]  R1290     -3.9673903584480286e-01
    z[1,2,6]  R1291     5.5634602904319763e-02
    z[1,2,6]  R1292     2.5438934564590454e-01
    z[1,2,6]  R1293     -2.8624063730239868e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R1294     -1
    z[2,1,0]  R1295     1
    z[2,1,0]  R1308     -7.4349719285964966e-01
    z[2,1,0]  R1309     -9.0440279245376587e-01
    z[2,1,0]  R1310     -6.5755015611648560e-01
    z[2,1,0]  R1311     -3.6882689595222473e-01
    z[2,1,0]  R1312     -1.4272942207753658e-02
    z[2,1,0]  R1313     4.3630054593086243e-01
    z[2,1,0]  R1314     3.0258023738861084e-01
    z[2,1,0]  R1315     1.9868750870227814e-01
    z[2,1,0]  R1316     3.1030893325805664e-01
    z[2,1,0]  R1317     2.8834110498428345e-01
    z[2,1,0]  R1318     2.7444690465927124e-01
    z[2,1,0]  R1319     -0.0762915164232254
    z[2,1,0]  R1320     -2.3704680800437927e-01
    z[2,1,0]  R1321     -0.0945655107498169
    z[2,1,0]  R1322     -6.8223255872726440e-01
    z[2,1,0]  R1323     -6.3873386383056641e-01
    z[2,1,0]  R1324     -6.0326629877090454e-01
    z[2,1,0]  R1325     -6.0984796285629272e-01
    z[2,1,0]  R1326     5.6926918029785156e-01
    z[2,1,0]  R1327     -5.7782799005508423e-02
    z[2,1,0]  R1328     -6.3951557874679565e-01
    z[2,1,0]  R1329     -6.9014227390289307e-01
    z[2,1,0]  R1330     4.5249709486961365e-01
    z[2,1,0]  R1331     -6.7513942718505859e-02
    z[2,1,0]  R1332     -1.5221396088600159e-01
    z[2,1,0]  R1333     -3.7763002514839172e-01
    z[2,1,0]  R1334     -3.0197069048881531e-01
    z[2,1,0]  R1335     5.5052733421325684e-01
    z[2,1,0]  R1336     0.402831107378006
    z[2,1,0]  R1337     0.676831066608429
    z[2,1,0]  R1338     1.1956851184368134e-01
    z[2,1,0]  R1339     -7.8148734569549561e-01
    z[2,1,0]  R1340     6.5265917778015137e-01
    z[2,1,0]  R1341     -7.2481507062911987e-01
    z[2,1,0]  R1342     3.8184890151023865e-01
    z[2,1,0]  R1343     4.3753212690353394e-01
    z[2,1,0]  R1344     -7.1952289342880249e-01
    z[2,1,0]  R1345     4.2336440086364746e-01
    z[2,1,0]  R1346     -1.8188993632793427e-01
    z[2,1,0]  R1347     0.668256938457489
    z[2,1,0]  R1348     4.7530296444892883e-01
    z[2,1,0]  R1349     7.9442560672760010e-01
    z[2,1,0]  R1350     0.531466007232666
    z[2,1,0]  R1351     5.7659108191728592e-02
    z[2,1,0]  R1352     3.7302851676940918e-01
    z[2,1,0]  R1353     1.3967619836330414e-01
    z[2,1,0]  R1354     9.8253987729549408e-02
    z[2,1,0]  R1355     -1.2154962867498398e-02
    z[2,1,0]  R1356     3.6504435539245605e-01
    z[2,1,0]  R1357     2.6145428419113159e-01
    z[2,1,0]  R1358     1.4792186021804810e-01
    z[2,1,0]  R1359     1.0102129727602005e-01
    z[2,1,0]  R1360     -7.0512253046035767e-01
    z[2,1,0]  R1361     3.8878908753395081e-01
    z[2,1,0]  R1362     3.1997001171112061e-01
    z[2,1,0]  R1363     2.2307321429252625e-01
    z[2,1,0]  R1364     2.2730773314833641e-02
    z[2,1,0]  R1365     5.2008849382400513e-01
    z[2,1,0]  R1366     -2.0841567218303680e-01
    z[2,1,0]  R1367     3.3207225799560547e-01
    z[2,1,0]  R1368     2.2497600317001343e-01
    z[2,1,0]  R1369     4.0429782867431641e-01
    z[2,1,0]  R1370     1.1020505428314209e-01
    z[2,1,0]  R1371     3.3701881766319275e-01
    z[2,1,0]  R1372     0.297879159450531
    z[2,1,0]  R1373     3.9452165365219116e-01
    z[2,1,0]  R1374     2.0356547832489014e-01
    z[2,1,0]  R1375     -2.6331812143325806e-01
    z[2,1,0]  R1376     3.1959950923919678e-01
    z[2,1,0]  R1377     5.9074461460113525e-01
    z[2,1,0]  R1378     -4.1275955736637115e-02
    z[2,1,0]  R1379     -3.7504187226295471e-01
    z[2,1,0]  R1380     -5.7928526401519775e-01
    z[2,1,0]  R1381     -4.9910187721252441e-01
    z[2,1,0]  R1382     -6.3219177722930908e-01
    z[2,1,0]  R1383     -3.9742922782897949e-01
    z[2,1,0]  R1384     2.3084011673927307e-01
    z[2,1,0]  R1385     -9.3423920869827271e-01
    z[2,1,0]  R1386     -9.2440533638000488e-01
    z[2,1,0]  R1387     2.1656617522239685e-01
    z[2,1,0]  R1388     1.9144825637340546e-02
    z[2,1,0]  R1389     -5.2586293220520020e-01
    z[2,1,0]  R1390     3.0178827047348022e-01
    z[2,1,0]  R1391     2.0443785190582275e-01
    z[2,1,0]  R1392     -1.7751251161098480e-01
    z[2,1,0]  R1393     5.6899610906839371e-02
    z[2,1,0]  R1394     1.6422684490680695e-01
    z[2,1,0]  R1395     2.9473572969436646e-01
    z[2,1,0]  R1396     -6.5723603963851929e-01
    z[2,1,0]  R1397     9.5317848026752472e-02
    z[2,1,0]  R1398     -5.1086451858282089e-02
    z[2,1,0]  R1399     -2.1587809920310974e-01
    z[2,1,0]  R1400     7.7477765083312988e-01
    z[2,1,0]  R1401     7.0630115270614624e-01
    z[2,1,0]  R1402     5.0864154100418091e-01
    z[2,1,0]  R1403     5.3289115428924561e-01
    z[2,1,0]  R1404     3.1803345680236816e-01
    z[2,1,0]  R1405     -4.4739622622728348e-02
    z[2,1,0]  R1406     -5.8397495746612549e-01
    z[2,1,0]  R1407     -5.5687215179204941e-02
    z[2,1,0]  R1408     8.9335137605667114e-01
    z[2,1,0]  R1409     -1.7038933932781219e-01
    z[2,1,0]  R1410     -3.7038710713386536e-01
    z[2,1,0]  R1411     -6.0038655996322632e-01
    z[2,1,0]  R1412     4.6409547328948975e-01
    z[2,1,0]  R1413     4.3099871277809143e-01
    z[2,1,0]  R1414     4.7354349493980408e-01
    z[2,1,0]  R1415     4.6459159255027771e-01
    z[2,1,0]  R1416     4.6672913432121277e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R1296     -1
    z[2,1,1]  R1297     1
    z[2,1,1]  R1308     -1.6133917868137360e-01
    z[2,1,1]  R1309     -1.8875263631343842e-01
    z[2,1,1]  R1310     -1.4964066445827484e-01
    z[2,1,1]  R1311     -6.5964251756668091e-01
    z[2,1,1]  R1312     7.8889004886150360e-02
    z[2,1,1]  R1313     1.8604267388582230e-02
    z[2,1,1]  R1314     -1.1806106194853783e-02
    z[2,1,1]  R1315     5.4581854492425919e-02
    z[2,1,1]  R1316     -1.2077865749597549e-01
    z[2,1,1]  R1317     5.2824807353317738e-03
    z[2,1,1]  R1318     8.4847694635391235e-01
    z[2,1,1]  R1319     8.0799955129623413e-01
    z[2,1,1]  R1320     7.9552549123764038e-01
    z[2,1,1]  R1321     8.1549555063247681e-01
    z[2,1,1]  R1322     3.7019926309585571e-01
    z[2,1,1]  R1323     2.2374063730239868e-01
    z[2,1,1]  R1324     8.6924374103546143e-02
    z[2,1,1]  R1325     3.7069177627563477e-01
    z[2,1,1]  R1326     3.9249441027641296e-01
    z[2,1,1]  R1327     6.4467805624008179e-01
    z[2,1,1]  R1328     -1.0548141598701477e-01
    z[2,1,1]  R1329     -1.2155154347419739e-01
    z[2,1,1]  R1330     -5.4345929622650146e-01
    z[2,1,1]  R1331     2.1160256862640381e-01
    z[2,1,1]  R1332     8.4358178079128265e-02
    z[2,1,1]  R1333     -4.2696982622146606e-02
    z[2,1,1]  R1334     -1.6924735158681870e-02
    z[2,1,1]  R1335     3.2430076599121094e-01
    z[2,1,1]  R1336     3.4691080451011658e-02
    z[2,1,1]  R1337     8.5422113537788391e-02
    z[2,1,1]  R1338     5.7380330562591553e-01
    z[2,1,1]  R1339     -1.3982464373111725e-01
    z[2,1,1]  R1340     5.3358948230743408e-01
    z[2,1,1]  R1341     -9.4836302101612091e-02
    z[2,1,1]  R1342     0.49685138463974
    z[2,1,1]  R1343     4.8165795207023621e-01
    z[2,1,1]  R1344     -1.6482116281986237e-01
    z[2,1,1]  R1345     4.7156643867492676e-01
    z[2,1,1]  R1346     2.8162896633148193e-01
    z[2,1,1]  R1347     1.7092798650264740e-01
    z[2,1,1]  R1348     7.1815800666809082e-01
    z[2,1,1]  R1349     -1.8876178562641144e-01
    z[2,1,1]  R1350     1.4198282361030579e-01
    z[2,1,1]  R1351     3.8490608334541321e-01
    z[2,1,1]  R1352     4.1333901882171631e-01
    z[2,1,1]  R1353     3.3508679270744324e-01
    z[2,1,1]  R1354     -1.2112998217344284e-01
    z[2,1,1]  R1355     -1.4878851175308228e-01
    z[2,1,1]  R1356     -4.0528278797864914e-02
    z[2,1,1]  R1357     -2.2516460716724396e-01
    z[2,1,1]  R1358     4.0738192200660706e-01
    z[2,1,1]  R1359     3.3872112631797791e-01
    z[2,1,1]  R1360     2.9937621951103210e-01
    z[2,1,1]  R1361     3.7586104869842529e-01
    z[2,1,1]  R1362     -5.2003145217895508e-01
    z[2,1,1]  R1363     2.3173166811466217e-01
    z[2,1,1]  R1364     -3.7086048722267151e-01
    z[2,1,1]  R1365     -5.2467468194663525e-03
    z[2,1,1]  R1366     -4.5383399724960327e-01
    z[2,1,1]  R1367     -8.4220498800277710e-02
    z[2,1,1]  R1368     0.361508309841156
    z[2,1,1]  R1369     4.8457989096641541e-01
    z[2,1,1]  R1370     -3.2911914587020874e-01
    z[2,1,1]  R1371     3.3398628234863281e-01
    z[2,1,1]  R1372     -4.8228830099105835e-01
    z[2,1,1]  R1373     -1.9169540703296661e-01
    z[2,1,1]  R1374     2.1775195002555847e-01
    z[2,1,1]  R1375     -2.4984495341777802e-01
    z[2,1,1]  R1376     2.1840962767601013e-01
    z[2,1,1]  R1377     3.6695379018783569e-01
    z[2,1,1]  R1378     6.5316796302795410e-01
    z[2,1,1]  R1379     0.657727062702179
    z[2,1,1]  R1380     6.4585006237030029e-01
    z[2,1,1]  R1381     7.4338763952255249e-01
    z[2,1,1]  R1382     7.0508313179016113e-01
    z[2,1,1]  R1383     7.9247128963470459e-01
    z[2,1,1]  R1384     8.2078307867050171e-01
    z[2,1,1]  R1385     3.3597180247306824e-01
    z[2,1,1]  R1386     3.2437753677368164e-01
    z[2,1,1]  R1387     8.7639510631561279e-01
    z[2,1,1]  R1388     0.31130251288414
    z[2,1,1]  R1389     -4.1803106665611267e-01
    z[2,1,1]  R1390     1.0529877245426178e-01
    z[2,1,1]  R1391     1.0849340260028839e-01
    z[2,1,1]  R1392     2.3467201739549637e-02
    z[2,1,1]  R1393     -2.1112029254436493e-01
    z[2,1,1]  R1394     1.6639775037765503e-01
    z[2,1,1]  R1395     -6.7488527856767178e-03
    z[2,1,1]  R1396     -6.3168264925479889e-02
    z[2,1,1]  R1397     0.547184944152832
    z[2,1,1]  R1398     1.0742236673831940e-01
    z[2,1,1]  R1399     0.407914936542511
    z[2,1,1]  R1400     4.4724959135055542e-01
    z[2,1,1]  R1401     3.4217163920402527e-01
    z[2,1,1]  R1402     1.4415302872657776e-01
    z[2,1,1]  R1403     3.5020154714584351e-01
    z[2,1,1]  R1404     3.6574858427047729e-01
    z[2,1,1]  R1405     -4.1784530878067017e-01
    z[2,1,1]  R1406     -3.3625042438507080e-01
    z[2,1,1]  R1407     8.6969435214996338e-01
    z[2,1,1]  R1408     8.6631134152412415e-02
    z[2,1,1]  R1409     1.4700804650783539e-01
    z[2,1,1]  R1410     -3.5427924990653992e-01
    z[2,1,1]  R1411     -6.7064750194549561e-01
    z[2,1,1]  R1412     -7.4182587862014771e-01
    z[2,1,1]  R1413     -7.4127340316772461e-01
    z[2,1,1]  R1414     -7.2319769859313965e-01
    z[2,1,1]  R1415     -7.1683096885681152e-01
    z[2,1,1]  R1416     -6.9388502836227417e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R1298     -1
    z[2,1,2]  R1299     1
    z[2,1,2]  R1308     5.5405408143997192e-01
    z[2,1,2]  R1309     3.0208969116210938e-01
    z[2,1,2]  R1310     4.4547548890113831e-01
    z[2,1,2]  R1311     4.7857272624969482e-01
    z[2,1,2]  R1312     6.4202749729156494e-01
    z[2,1,2]  R1313     8.1291161477565765e-02
    z[2,1,2]  R1314     4.4162884354591370e-02
    z[2,1,2]  R1315     -1.8790006870403886e-03
    z[2,1,2]  R1316     -2.3436856269836426e-01
    z[2,1,2]  R1317     -2.3957021534442902e-01
    z[2,1,2]  R1318     -4.2595416307449341e-01
    z[2,1,2]  R1319     -5.2947640419006348e-01
    z[2,1,2]  R1320     -0.502391517162323
    z[2,1,2]  R1321     -4.5143491029739380e-01
    z[2,1,2]  R1322     -0.36711585521698
    z[2,1,2]  R1323     -4.1537192463874817e-01
    z[2,1,2]  R1324     -4.2701101303100586e-01
    z[2,1,2]  R1325     -1.5642069280147552e-01
    z[2,1,2]  R1326     4.9039289355278015e-01
    z[2,1,2]  R1327     -6.6163659095764160e-02
    z[2,1,2]  R1328     -2.6565429568290710e-01
    z[2,1,2]  R1329     -3.1715756654739380e-01
    z[2,1,2]  R1330     -5.7490535080432892e-02
    z[2,1,2]  R1331     -3.7725567817687988e-01
    z[2,1,2]  R1332     -1.4679531753063202e-01
    z[2,1,2]  R1333     3.9403751492500305e-02
    z[2,1,2]  R1334     2.0407268404960632e-01
    z[2,1,2]  R1335     2.6282489299774170e-01
    z[2,1,2]  R1336     -4.7353811562061310e-02
    z[2,1,2]  R1337     -1.6353714466094971e-01
    z[2,1,2]  R1338     2.9847669601440430e-01
    z[2,1,2]  R1339     -1.3640609383583069e-01
    z[2,1,2]  R1340     2.2130960226058960e-01
    z[2,1,2]  R1341     -8.3762980997562408e-02
    z[2,1,2]  R1342     2.1198947727680206e-01
    z[2,1,2]  R1343     3.2118758559226990e-01
    z[2,1,2]  R1344     -3.8719365000724792e-01
    z[2,1,2]  R1345     2.0314460992813110e-01
    z[2,1,2]  R1346     -3.0454638600349426e-01
    z[2,1,2]  R1347     -4.2584415525197983e-02
    z[2,1,2]  R1348     -9.1633729636669159e-02
    z[2,1,2]  R1349     -3.4959834069013596e-02
    z[2,1,2]  R1350     -3.4006664156913757e-01
    z[2,1,2]  R1351     6.0803387314081192e-02
    z[2,1,2]  R1352     6.2868803739547729e-02
    z[2,1,2]  R1353     2.2307692468166351e-01
    z[2,1,2]  R1354     1.4269936084747314e-01
    z[2,1,2]  R1355     -1.7905475571751595e-02
    z[2,1,2]  R1356     1.4066404104232788e-01
    z[2,1,2]  R1357     -3.2815438508987427e-01
    z[2,1,2]  R1358     -1.9858621060848236e-01
    z[2,1,2]  R1359     -4.4785720109939575e-01
    z[2,1,2]  R1360     -3.6400568485260010e-01
    z[2,1,2]  R1361     -7.2100780904293060e-02
    z[2,1,2]  R1362     -1.2152507901191711e-01
    z[2,1,2]  R1363     4.7754812985658646e-02
    z[2,1,2]  R1364     7.7282279729843140e-02
    z[2,1,2]  R1365     -2.3688524961471558e-01
    z[2,1,2]  R1366     -0.737982451915741
    z[2,1,2]  R1367     7.9628866910934448e-01
    z[2,1,2]  R1368     6.2952286005020142e-01
    z[2,1,2]  R1369     2.3803453147411346e-01
    z[2,1,2]  R1370     3.5012251138687134e-01
    z[2,1,2]  R1371     1.6661569476127625e-01
    z[2,1,2]  R1372     3.0057954788208008e-01
    z[2,1,2]  R1373     -7.2683282196521759e-02
    z[2,1,2]  R1374     -2.0050784945487976e-01
    z[2,1,2]  R1375     5.0285577774047852e-01
    z[2,1,2]  R1376     0.00567758409306407
    z[2,1,2]  R1377     -2.1179307997226715e-01
    z[2,1,2]  R1378     -5.8393353223800659e-01
    z[2,1,2]  R1379     -4.0201231837272644e-01
    z[2,1,2]  R1380     -3.8458973169326782e-01
    z[2,1,2]  R1381     4.2064037173986435e-02
    z[2,1,2]  R1382     -2.8824952244758606e-01
    z[2,1,2]  R1383     -2.4844953417778015e-01
    z[2,1,2]  R1384     -1.5014594793319702e-01
    z[2,1,2]  R1385     -3.6241721361875534e-02
    z[2,1,2]  R1386     1.1564271897077560e-01
    z[2,1,2]  R1387     1.7821869254112244e-01
    z[2,1,2]  R1388     -2.7339941263198853e-01
    z[2,1,2]  R1389     -6.2284684181213379e-01
    z[2,1,2]  R1390     9.8502419888973236e-02
    z[2,1,2]  R1391     -8.4907189011573792e-02
    z[2,1,2]  R1392     -3.7734252214431763e-01
    z[2,1,2]  R1393     1.1531513929367065e-01
    z[2,1,2]  R1394     -3.3423385024070740e-01
    z[2,1,2]  R1395     6.3833691179752350e-02
    z[2,1,2]  R1396     -3.4744244813919067e-01
    z[2,1,2]  R1397     -3.5237598419189453e-01
    z[2,1,2]  R1398     1.0244900733232498e-01
    z[2,1,2]  R1399     -7.7153556048870087e-02
    z[2,1,2]  R1400     -1.8872264027595520e-01
    z[2,1,2]  R1401     -5.5572193115949631e-02
    z[2,1,2]  R1402     7.1593075990676880e-02
    z[2,1,2]  R1403     1.0369773954153061e-02
    z[2,1,2]  R1404     -8.3991587162017822e-02
    z[2,1,2]  R1405     9.6030756831169128e-03
    z[2,1,2]  R1406     -3.5265704989433289e-01
    z[2,1,2]  R1407     -2.3279662430286407e-01
    z[2,1,2]  R1408     2.2210830822587013e-02
    z[2,1,2]  R1409     1.0618493705987930e-01
    z[2,1,2]  R1410     -1.7527283728122711e-01
    z[2,1,2]  R1411     3.4023147821426392e-01
    z[2,1,2]  R1412     -3.2223331928253174e-01
    z[2,1,2]  R1413     -1.6301706433296204e-01
    z[2,1,2]  R1414     -1.1810306459665298e-01
    z[2,1,2]  R1415     -2.4931703507900238e-01
    z[2,1,2]  R1416     -0.291786253452301
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R1300     -1
    z[2,1,3]  R1301     1
    z[2,1,3]  R1308     1.9688328728079796e-02
    z[2,1,3]  R1309     2.5863319635391235e-02
    z[2,1,3]  R1310     -5.6284625083208084e-02
    z[2,1,3]  R1311     -1.7577295005321503e-01
    z[2,1,3]  R1312     -2.0616275072097778e-01
    z[2,1,3]  R1313     5.9721589088439941e-01
    z[2,1,3]  R1314     3.6833903193473816e-01
    z[2,1,3]  R1315     3.0313912034034729e-01
    z[2,1,3]  R1316     4.2844411730766296e-01
    z[2,1,3]  R1317     5.3503030538558960e-01
    z[2,1,3]  R1318     -1.0913491994142532e-01
    z[2,1,3]  R1319     -7.2018451988697052e-02
    z[2,1,3]  R1320     -2.4380747228860855e-02
    z[2,1,3]  R1321     2.8135562315583229e-02
    z[2,1,3]  R1322     2.9551374912261963e-01
    z[2,1,3]  R1323     -2.6950290799140930e-01
    z[2,1,3]  R1324     0.536393404006958
    z[2,1,3]  R1325     -4.9610573053359985e-01
    z[2,1,3]  R1326     3.1855475902557373e-01
    z[2,1,3]  R1327     2.5723496079444885e-01
    z[2,1,3]  R1328     -7.3913954198360443e-02
    z[2,1,3]  R1329     -0.0710030347108841
    z[2,1,3]  R1330     2.6913684606552124e-01
    z[2,1,3]  R1331     -4.8549634218215942e-01
    z[2,1,3]  R1332     -2.1894189715385437e-01
    z[2,1,3]  R1333     -3.2744863629341125e-01
    z[2,1,3]  R1334     -4.1578125953674316e-01
    z[2,1,3]  R1335     -9.1020818799734116e-03
    z[2,1,3]  R1336     -1.1704139411449432e-01
    z[2,1,3]  R1337     -2.7253192663192749e-01
    z[2,1,3]  R1338     -4.1588541865348816e-01
    z[2,1,3]  R1339     1.8047462403774261e-01
    z[2,1,3]  R1340     1.8411104381084442e-01
    z[2,1,3]  R1341     -2.1536672487854958e-02
    z[2,1,3]  R1342     2.3278267681598663e-01
    z[2,1,3]  R1343     -4.0269672870635986e-01
    z[2,1,3]  R1344     8.3176698535680771e-03
    z[2,1,3]  R1345     1.4700825512409210e-01
    z[2,1,3]  R1346     -4.5856767892837524e-01
    z[2,1,3]  R1347     -4.3998207896947861e-02
    z[2,1,3]  R1348     1.2758034281432629e-02
    z[2,1,3]  R1349     0.0983872041106224
    z[2,1,3]  R1350     6.8053025007247925e-01
    z[2,1,3]  R1351     -5.4386472702026367e-01
    z[2,1,3]  R1352     -3.4815445542335510e-01
    z[2,1,3]  R1353     -2.9917529225349426e-01
    z[2,1,3]  R1354     -3.3609643578529358e-01
    z[2,1,3]  R1355     -6.1731004714965820e-01
    z[2,1,3]  R1356     -6.9499629735946655e-01
    z[2,1,3]  R1357     -2.3235796391963959e-01
    z[2,1,3]  R1358     -3.8140979409217834e-01
    z[2,1,3]  R1359     -4.0274840593338013e-01
    z[2,1,3]  R1360     -4.0840244293212891e-01
    z[2,1,3]  R1361     -5.4294604063034058e-01
    z[2,1,3]  R1362     7.1361762285232544e-01
    z[2,1,3]  R1363     -2.2852474451065063e-01
    z[2,1,3]  R1364     -3.5795214772224426e-01
    z[2,1,3]  R1365     -2.6905605196952820e-01
    z[2,1,3]  R1366     5.6580636650323868e-02
    z[2,1,3]  R1367     -1.0823883116245270e-01
    z[2,1,3]  R1368     0.356587290763855
    z[2,1,3]  R1369     6.0027605295181274e-01
    z[2,1,3]  R1370     5.1075166463851929e-01
    z[2,1,3]  R1371     5.3740882873535156e-01
    z[2,1,3]  R1372     1.0916360467672348e-01
    z[2,1,3]  R1373     4.9610521644353867e-02
    z[2,1,3]  R1374     2.6247090101242065e-01
    z[2,1,3]  R1375     3.9771571755409241e-01
    z[2,1,3]  R1376     4.4433519244194031e-01
    z[2,1,3]  R1377     2.9319867491722107e-01
    z[2,1,3]  R1378     -1.5360046923160553e-01
    z[2,1,3]  R1379     -2.7590749785304070e-02
    z[2,1,3]  R1380     2.2711518406867981e-01
    z[2,1,3]  R1381     -1.6082301735877991e-01
    z[2,1,3]  R1382     -6.8718180060386658e-02
    z[2,1,3]  R1383     3.1026366353034973e-01
    z[2,1,3]  R1384     -5.8440599590539932e-02
    z[2,1,3]  R1385     -4.1871690191328526e-03
    z[2,1,3]  R1386     -4.1127860546112061e-02
    z[2,1,3]  R1387     -3.3243077993392944e-01
    z[2,1,3]  R1388     -6.8526461720466614e-02
    z[2,1,3]  R1389     -8.7724313139915466e-02
    z[2,1,3]  R1390     -3.5257175564765930e-01
    z[2,1,3]  R1391     -2.9554140567779541e-01
    z[2,1,3]  R1392     -2.9453948140144348e-01
    z[2,1,3]  R1393     -3.3523476123809814e-01
    z[2,1,3]  R1394     -3.7054210901260376e-01
    z[2,1,3]  R1395     -4.7129637002944946e-01
    z[2,1,3]  R1396     -3.0005259439349174e-02
    z[2,1,3]  R1397     -3.7874984741210938e-01
    z[2,1,3]  R1398     9.7439870238304138e-02
    z[2,1,3]  R1399     -3.0197608470916748e-01
    z[2,1,3]  R1400     -2.0218986272811890e-01
    z[2,1,3]  R1401     -1.5474145114421844e-01
    z[2,1,3]  R1402     -4.0473595261573792e-02
    z[2,1,3]  R1403     9.7739197313785553e-02
    z[2,1,3]  R1404     -2.5048962235450745e-01
    z[2,1,3]  R1405     -3.2698279619216919e-01
    z[2,1,3]  R1406     -2.5443577766418457e-01
    z[2,1,3]  R1407     -1.5198162198066711e-01
    z[2,1,3]  R1408     -3.0203291773796082e-01
    z[2,1,3]  R1409     -3.0847027897834778e-01
    z[2,1,3]  R1410     -3.9656361937522888e-01
    z[2,1,3]  R1411     -9.1805262491106987e-03
    z[2,1,3]  R1412     -1.6141927242279053e-01
    z[2,1,3]  R1413     -2.9566857218742371e-01
    z[2,1,3]  R1414     -1.8786433339118958e-01
    z[2,1,3]  R1415     -3.1983304023742676e-01
    z[2,1,3]  R1416     1.8618069589138031e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R1302     -1
    z[2,1,4]  R1303     1
    z[2,1,4]  R1308     1.6780348122119904e-01
    z[2,1,4]  R1309     -9.5293030142784119e-02
    z[2,1,4]  R1310     -5.0396603345870972e-01
    z[2,1,4]  R1311     1.4677263796329498e-01
    z[2,1,4]  R1312     -3.6618176102638245e-01
    z[2,1,4]  R1313     -4.2743611335754395e-01
    z[2,1,4]  R1314     -2.1006008982658386e-01
    z[2,1,4]  R1315     -7.2236508131027222e-01
    z[2,1,4]  R1316     -0.205518439412117
    z[2,1,4]  R1317     -5.8308511972427368e-01
    z[2,1,4]  R1318     -5.9225648641586304e-02
    z[2,1,4]  R1319     -1.6364024579524994e-01
    z[2,1,4]  R1320     -2.3171067237854004e-01
    z[2,1,4]  R1321     1.4094124734401703e-01
    z[2,1,4]  R1322     3.2538506388664246e-01
    z[2,1,4]  R1323     0.0657089427113533
    z[2,1,4]  R1324     3.0613413453102112e-01
    z[2,1,4]  R1325     3.8916683197021484e-01
    z[2,1,4]  R1326     2.6407399773597717e-01
    z[2,1,4]  R1327     1.0766576230525970e-01
    z[2,1,4]  R1328     3.0829259753227234e-01
    z[2,1,4]  R1329     0.542674720287323
    z[2,1,4]  R1330     -3.5133257508277893e-01
    z[2,1,4]  R1331     6.7589128017425537e-01
    z[2,1,4]  R1332     9.3958681821823120e-01
    z[2,1,4]  R1333     8.3078670501708984e-01
    z[2,1,4]  R1334     7.6595938205718994e-01
    z[2,1,4]  R1335     -3.4655591845512390e-01
    z[2,1,4]  R1336     8.8376337289810181e-01
    z[2,1,4]  R1337     6.3066780567169189e-01
    z[2,1,4]  R1338     3.0546778440475464e-01
    z[2,1,4]  R1339     0.541685938835144
    z[2,1,4]  R1340     2.6552131772041321e-01
    z[2,1,4]  R1341     5.4971385002136230e-01
    z[2,1,4]  R1342     1.4752371609210968e-01
    z[2,1,4]  R1343     3.7905752658843994e-01
    z[2,1,4]  R1344     1.2931534647941589e-01
    z[2,1,4]  R1345     -2.2250978276133537e-02
    z[2,1,4]  R1346     0.729640543460846
    z[2,1,4]  R1347     -6.8487298488616943e-01
    z[2,1,4]  R1348     -4.5553824305534363e-01
    z[2,1,4]  R1349     -4.0139034390449524e-01
    z[2,1,4]  R1350     3.2666096091270447e-01
    z[2,1,4]  R1351     6.5018379688262939e-01
    z[2,1,4]  R1352     0.615688145160675
    z[2,1,4]  R1353     6.1329811811447144e-01
    z[2,1,4]  R1354     6.6873502731323242e-01
    z[2,1,4]  R1355     6.3954770565032959e-01
    z[2,1,4]  R1356     3.2765284180641174e-01
    z[2,1,4]  R1357     6.7813855409622192e-01
    z[2,1,4]  R1358     -5.0727075338363647e-01
    z[2,1,4]  R1359     -3.3661961555480957e-01
    z[2,1,4]  R1360     9.8570518195629120e-02
    z[2,1,4]  R1361     6.1248999834060669e-01
    z[2,1,4]  R1362     -3.7129085510969162e-02
    z[2,1,4]  R1363     7.7158856391906738e-01
    z[2,1,4]  R1364     7.6849943399429321e-01
    z[2,1,4]  R1365     0.732159435749054
    z[2,1,4]  R1366     5.8081064373254776e-02
    z[2,1,4]  R1367     1.4760370831936598e-03
    z[2,1,4]  R1368     4.1524812579154968e-02
    z[2,1,4]  R1369     -2.6050312444567680e-02
    z[2,1,4]  R1370     5.8437857776880264e-02
    z[2,1,4]  R1371     -1.7981484532356262e-01
    z[2,1,4]  R1372     -7.4437371222302318e-04
    z[2,1,4]  R1373     2.3300166428089142e-01
    z[2,1,4]  R1374     2.0796832442283630e-01
    z[2,1,4]  R1375     1.1065878719091415e-01
    z[2,1,4]  R1376     2.0427180826663971e-01
    z[2,1,4]  R1377     1.6974899172782898e-01
    z[2,1,4]  R1378     -4.4538193941116333e-01
    z[2,1,4]  R1379     -3.1974750757217407e-01
    z[2,1,4]  R1380     -1.9922609627246857e-01
    z[2,1,4]  R1381     -2.7087783813476562e-01
    z[2,1,4]  R1382     2.0275993272662163e-02
    z[2,1,4]  R1383     1.0352526605129242e-01
    z[2,1,4]  R1384     -1.5411649644374847e-01
    z[2,1,4]  R1385     -9.2224171385169029e-03
    z[2,1,4]  R1386     1.1496607959270477e-01
    z[2,1,4]  R1387     1.1724268645048141e-01
    z[2,1,4]  R1388     8.7437534332275391e-01
    z[2,1,4]  R1389     -1.4307887852191925e-01
    z[2,1,4]  R1390     8.4778529405593872e-01
    z[2,1,4]  R1391     5.1797825098037720e-01
    z[2,1,4]  R1392     7.7364194393157959e-01
    z[2,1,4]  R1393     8.4896445274353027e-01
    z[2,1,4]  R1394     0.667140781879425
    z[2,1,4]  R1395     6.5066725015640259e-01
    z[2,1,4]  R1396     -2.4185539782047272e-01
    z[2,1,4]  R1397     -8.3446763455867767e-02
    z[2,1,4]  R1398     8.9992147684097290e-01
    z[2,1,4]  R1399     -2.5832799077033997e-01
    z[2,1,4]  R1400     1.7638940364122391e-02
    z[2,1,4]  R1401     -4.6297335624694824e-01
    z[2,1,4]  R1402     -7.9953235387802124e-01
    z[2,1,4]  R1403     -7.4610334634780884e-01
    z[2,1,4]  R1404     7.0542466640472412e-01
    z[2,1,4]  R1405     6.1648392677307129e-01
    z[2,1,4]  R1406     1.2818135321140289e-01
    z[2,1,4]  R1407     2.1970003843307495e-01
    z[2,1,4]  R1408     -2.5865370035171509e-01
    z[2,1,4]  R1409     6.4369821548461914e-01
    z[2,1,4]  R1410     5.0892108678817749e-01
    z[2,1,4]  R1411     -1.2675713002681732e-01
    z[2,1,4]  R1412     9.5251753926277161e-02
    z[2,1,4]  R1413     -7.3320806026458740e-02
    z[2,1,4]  R1414     -5.4239153861999512e-02
    z[2,1,4]  R1415     -1.0252785682678223e-01
    z[2,1,4]  R1416     2.8734045103192329e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R1304     -1
    z[2,1,5]  R1305     1
    z[2,1,5]  R1308     -1.5103656053543091e-01
    z[2,1,5]  R1309     -6.2295131385326385e-02
    z[2,1,5]  R1310     -0.0794144868850708
    z[2,1,5]  R1311     -7.3905050754547119e-02
    z[2,1,5]  R1312     -0.553706169128418
    z[2,1,5]  R1313     -0.50154048204422
    z[2,1,5]  R1314     -8.5121077299118042e-01
    z[2,1,5]  R1315     -5.6201732158660889e-01
    z[2,1,5]  R1316     -6.5065312385559082e-01
    z[2,1,5]  R1317     -0.338346391916275
    z[2,1,5]  R1318     -8.2619205117225647e-02
    z[2,1,5]  R1319     -1.1536671966314316e-01
    z[2,1,5]  R1320     -1.1266986839473248e-02
    z[2,1,5]  R1321     -3.0776521563529968e-01
    z[2,1,5]  R1322     2.1929222345352173e-01
    z[2,1,5]  R1323     4.4513073563575745e-01
    z[2,1,5]  R1324     2.4503825604915619e-01
    z[2,1,5]  R1325     2.3875932395458221e-01
    z[2,1,5]  R1326     2.1600700914859772e-01
    z[2,1,5]  R1327     3.1031739711761475e-01
    z[2,1,5]  R1328     -5.0032925605773926e-01
    z[2,1,5]  R1329     -6.4615093171596527e-02
    z[2,1,5]  R1330     -3.0091321095824242e-03
    z[2,1,5]  R1331     -9.5629818737506866e-02
    z[2,1,5]  R1332     0.0893244668841362
    z[2,1,5]  R1333     -2.0185333490371704e-01
    z[2,1,5]  R1334     -5.3852040320634842e-02
    z[2,1,5]  R1335     4.5460018515586853e-01
    z[2,1,5]  R1336     1.1297465115785599e-01
    z[2,1,5]  R1337     -1.1456539481878281e-01
    z[2,1,5]  R1338     5.3864598274230957e-01
    z[2,1,5]  R1339     -1.5818008780479431e-01
    z[2,1,5]  R1340     -2.5313705205917358e-01
    z[2,1,5]  R1341     3.8068592548370361e-01
    z[2,1,5]  R1342     6.9146496057510376e-01
    z[2,1,5]  R1343     1.8906120955944061e-01
    z[2,1,5]  R1344     2.3913174867630005e-01
    z[2,1,5]  R1345     2.2060884535312653e-01
    z[2,1,5]  R1346     -1.7037029564380646e-01
    z[2,1,5]  R1347     1.4622513949871063e-01
    z[2,1,5]  R1348     -1.1423914879560471e-01
    z[2,1,5]  R1349     -1.4322666823863983e-01
    z[2,1,5]  R1350     -1.0807734727859497e-01
    z[2,1,5]  R1351     1.5783878043293953e-02
    z[2,1,5]  R1352     4.9813590943813324e-02
    z[2,1,5]  R1353     -1.0862774401903152e-01
    z[2,1,5]  R1354     5.8036959171295166e-01
    z[2,1,5]  R1355     4.1192063689231873e-01
    z[2,1,5]  R1356     5.0464153289794922e-01
    z[2,1,5]  R1357     4.2999365925788879e-01
    z[2,1,5]  R1358     -5.0462526082992554e-01
    z[2,1,5]  R1359     -1.6671015322208405e-01
    z[2,1,5]  R1360     1.7743869125843048e-01
    z[2,1,5]  R1361     9.9554657936096191e-02
    z[2,1,5]  R1362     2.8193006291985512e-02
    z[2,1,5]  R1363     -2.9880398511886597e-01
    z[2,1,5]  R1364     3.6627429723739624e-01
    z[2,1,5]  R1365     -1.4255641959607601e-02
    z[2,1,5]  R1366     3.4274047613143921e-01
    z[2,1,5]  R1367     -4.6309524774551392e-01
    z[2,1,5]  R1368     -4.9777108430862427e-01
    z[2,1,5]  R1369     -4.2009532451629639e-01
    z[2,1,5]  R1370     -7.0185315608978271e-01
    z[2,1,5]  R1371     -6.2715178728103638e-01
    z[2,1,5]  R1372     -0.702717125415802
    z[2,1,5]  R1373     -7.4101728200912476e-01
    z[2,1,5]  R1374     -8.6752545833587646e-01
    z[2,1,5]  R1375     -3.7044957280158997e-01
    z[2,1,5]  R1376     -1.9174227118492126e-01
    z[2,1,5]  R1377     -4.8559173941612244e-01
    z[2,1,5]  R1378     -1.7354622483253479e-02
    z[2,1,5]  R1379     -7.6631464064121246e-02
    z[2,1,5]  R1380     5.7139031589031219e-02
    z[2,1,5]  R1381     1.1248541623353958e-01
    z[2,1,5]  R1382     1.1797171086072922e-01
    z[2,1,5]  R1383     2.0577445626258850e-01
    z[2,1,5]  R1384     4.0649777650833130e-01
    z[2,1,5]  R1385     -1.2953018769621849e-02
    z[2,1,5]  R1386     7.9326741397380829e-02
    z[2,1,5]  R1387     -1.7031390964984894e-01
    z[2,1,5]  R1388     0.214023619890213
    z[2,1,5]  R1389     3.6025542020797729e-01
    z[2,1,5]  R1390     1.0420871526002884e-01
    z[2,1,5]  R1391     7.6388245820999146e-01
    z[2,1,5]  R1392     -2.0823728293180466e-02
    z[2,1,5]  R1393     3.0105376243591309e-01
    z[2,1,5]  R1394     -2.1040309220552444e-02
    z[2,1,5]  R1395     4.6810010075569153e-01
    z[2,1,5]  R1396     5.6569927930831909e-01
    z[2,1,5]  R1397     -5.4583930969238281e-01
    z[2,1,5]  R1398     -2.8972637653350830e-01
    z[2,1,5]  R1399     -7.1383011341094971e-01
    z[2,1,5]  R1400     1.3720458745956421e-01
    z[2,1,5]  R1401     1.3389253616333008e-01
    z[2,1,5]  R1402     -0.0657874047756195
    z[2,1,5]  R1403     5.4046556353569031e-02
    z[2,1,5]  R1404     -1.2181343883275986e-01
    z[2,1,5]  R1405     5.0305038690567017e-01
    z[2,1,5]  R1406     5.5670654773712158e-01
    z[2,1,5]  R1407     -3.3804804086685181e-01
    z[2,1,5]  R1408     1.0120960325002670e-01
    z[2,1,5]  R1409     5.6893342733383179e-01
    z[2,1,5]  R1410     5.1979804039001465e-01
    z[2,1,5]  R1411     7.6164029538631439e-02
    z[2,1,5]  R1412     2.9966291785240173e-01
    z[2,1,5]  R1413     2.8683552145957947e-01
    z[2,1,5]  R1414     4.4693747162818909e-01
    z[2,1,5]  R1415     3.0494108796119690e-01
    z[2,1,5]  R1416     3.9764198660850525e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R1306     -1
    z[2,1,6]  R1307     1
    z[2,1,6]  R1308     -2.5069481134414673e-01
    z[2,1,6]  R1309     2.0381264388561249e-01
    z[2,1,6]  R1310     -2.8867053985595703e-01
    z[2,1,6]  R1311     3.7670439481735229e-01
    z[2,1,6]  R1312     3.1335431337356567e-01
    z[2,1,6]  R1313     -1.0851830244064331e-01
    z[2,1,6]  R1314     4.4684566557407379e-02
    z[2,1,6]  R1315     1.6724999248981476e-01
    z[2,1,6]  R1316     4.3016341328620911e-01
    z[2,1,6]  R1317     3.4454837441444397e-01
    z[2,1,6]  R1318     -3.2937828451395035e-02
    z[2,1,6]  R1319     -1.2528675794601440e-01
    z[2,1,6]  R1320     6.4339734613895416e-02
    z[2,1,6]  R1321     -8.2796871662139893e-02
    z[2,1,6]  R1322     -1.4643880724906921e-01
    z[2,1,6]  R1323     3.0713915824890137e-01
    z[2,1,6]  R1324     6.8526528775691986e-02
    z[2,1,6]  R1325     -1.0783251374959946e-01
    z[2,1,6]  R1326     2.5204023718833923e-01
    z[2,1,6]  R1327     -6.3451957702636719e-01
    z[2,1,6]  R1328     3.9810085296630859e-01
    z[2,1,6]  R1329     3.2346194982528687e-01
    z[2,1,6]  R1330     5.4837477207183838e-01
    z[2,1,6]  R1331     3.2659384608268738e-01
    z[2,1,6]  R1332     -9.7096830606460571e-02
    z[2,1,6]  R1333     -1.2588070333003998e-01
    z[2,1,6]  R1334     -3.2313096523284912e-01
    z[2,1,6]  R1335     -4.4252294301986694e-01
    z[2,1,6]  R1336     -1.6365081071853638e-01
    z[2,1,6]  R1337     1.5072350203990936e-01
    z[2,1,6]  R1338     -1.0466154664754868e-01
    z[2,1,6]  R1339     1.0212297551333904e-02
    z[2,1,6]  R1340     2.6807376742362976e-01
    z[2,1,6]  R1341     -1.0517653077840805e-01
    z[2,1,6]  R1342     -9.1191403567790985e-02
    z[2,1,6]  R1343     3.6306518316268921e-01
    z[2,1,6]  R1344     4.8085975646972656e-01
    z[2,1,6]  R1345     -6.9738447666168213e-01
    z[2,1,6]  R1346     1.5220688283443451e-01
    z[2,1,6]  R1347     1.7330373823642731e-01
    z[2,1,6]  R1348     1.7091201245784760e-01
    z[2,1,6]  R1349     3.7513554096221924e-01
    z[2,1,6]  R1350     1.5162459574639797e-02
    z[2,1,6]  R1351     -3.5503348708152771e-01
    z[2,1,6]  R1352     -0.428116112947464
    z[2,1,6]  R1353     -5.8395510911941528e-01
    z[2,1,6]  R1354     -2.4148355424404144e-01
    z[2,1,6]  R1355     1.3274788856506348e-01
    z[2,1,6]  R1356     -1.6567483544349670e-02
    z[2,1,6]  R1357     2.7294814586639404e-01
    z[2,1,6]  R1358     3.3952745795249939e-01
    z[2,1,6]  R1359     6.0924154520034790e-01
    z[2,1,6]  R1360     2.6959735155105591e-01
    z[2,1,6]  R1361     -1.5009182691574097e-01
    z[2,1,6]  R1362     3.1779631972312927e-01
    z[2,1,6]  R1363     -3.9673903584480286e-01
    z[2,1,6]  R1364     5.5634602904319763e-02
    z[2,1,6]  R1365     2.5438934564590454e-01
    z[2,1,6]  R1366     -2.8624063730239868e-01
    z[2,1,6]  R1367     -1.4961341023445129e-01
    z[2,1,6]  R1368     2.1387757360935211e-01
    z[2,1,6]  R1369     0.087035171687603
    z[2,1,6]  R1370     -8.3404621109366417e-03
    z[2,1,6]  R1371     -1.8069240450859070e-01
    z[2,1,6]  R1372     0.287383496761322
    z[2,1,6]  R1373     -4.4324392080307007e-01
    z[2,1,6]  R1374     7.8737497329711914e-02
    z[2,1,6]  R1375     5.5472618341445923e-01
    z[2,1,6]  R1376     7.5775671005249023e-01
    z[2,1,6]  R1377     3.4774962067604065e-01
    z[2,1,6]  R1378     9.1815330088138580e-02
    z[2,1,6]  R1379     -3.9528802037239075e-01
    z[2,1,6]  R1380     0.0697116032242775
    z[2,1,6]  R1381     2.9087954759597778e-01
    z[2,1,6]  R1382     3.2448939979076385e-02
    z[2,1,6]  R1383     -5.4661218076944351e-02
    z[2,1,6]  R1384     -2.4099057912826538e-01
    z[2,1,6]  R1385     -1.1285389959812164e-01
    z[2,1,6]  R1386     7.5361780822277069e-02
    z[2,1,6]  R1387     -2.4202053900808096e-03
    z[2,1,6]  R1388     1.1376570910215378e-01
    z[2,1,6]  R1389     5.3188685327768326e-02
    z[2,1,6]  R1390     -1.8500572443008423e-01
    z[2,1,6]  R1391     -7.9107824712991714e-03
    z[2,1,6]  R1392     -3.7395489215850830e-01
    z[2,1,6]  R1393     0.123031385242939
    z[2,1,6]  R1394     -5.0080728530883789e-01
    z[2,1,6]  R1395     -2.1072435379028320e-01
    z[2,1,6]  R1396     -2.5283247232437134e-01
    z[2,1,6]  R1397     3.4493315219879150e-01
    z[2,1,6]  R1398     2.6844039559364319e-01
    z[2,1,6]  R1399     -3.3700618147850037e-01
    z[2,1,6]  R1400     -3.2257422804832458e-01
    z[2,1,6]  R1401     -3.5320317745208740e-01
    z[2,1,6]  R1402     -2.6487755775451660e-01
    z[2,1,6]  R1403     -1.5535186231136322e-01
    z[2,1,6]  R1404     -4.2757540941238403e-01
    z[2,1,6]  R1405     2.8858572244644165e-01
    z[2,1,6]  R1406     -1.7450398206710815e-01
    z[2,1,6]  R1407     -2.6332248002290726e-02
    z[2,1,6]  R1408     -0.159862220287323
    z[2,1,6]  R1409     -3.2387372851371765e-01
    z[2,1,6]  R1410     -1.4186498522758484e-01
    z[2,1,6]  R1411     -2.2816176712512970e-01
    z[2,1,6]  R1412     -0.0744878277182579
    z[2,1,6]  R1413     -2.5121471285820007e-01
    z[2,1,6]  R1414     -2.8377154842019081e-02
    z[2,1,6]  R1415     -4.8527400940656662e-02
    z[2,1,6]  R1416     1.4812238514423370e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R1417     -1
    z[1,3,0]  R1418     1
    z[1,3,0]  R1431     3.3207225799560547e-01
    z[1,3,0]  R1432     2.2497600317001343e-01
    z[1,3,0]  R1433     4.0429782867431641e-01
    z[1,3,0]  R1434     1.1020505428314209e-01
    z[1,3,0]  R1435     3.3701881766319275e-01
    z[1,3,0]  R1436     0.297879159450531
    z[1,3,0]  R1437     3.9452165365219116e-01
    z[1,3,0]  R1438     2.0356547832489014e-01
    z[1,3,0]  R1439     -2.6331812143325806e-01
    z[1,3,0]  R1440     3.1959950923919678e-01
    z[1,3,0]  R1441     5.9074461460113525e-01
    z[1,3,0]  R1442     -4.1275955736637115e-02
    z[1,3,0]  R1443     -3.7504187226295471e-01
    z[1,3,0]  R1444     -5.7928526401519775e-01
    z[1,3,0]  R1445     -4.9910187721252441e-01
    z[1,3,0]  R1446     -6.3219177722930908e-01
    z[1,3,0]  R1447     -3.9742922782897949e-01
    z[1,3,0]  R1448     2.3084011673927307e-01
    z[1,3,0]  R1449     -9.3423920869827271e-01
    z[1,3,0]  R1450     -9.2440533638000488e-01
    z[1,3,0]  R1451     2.1656617522239685e-01
    z[1,3,0]  R1452     1.9144825637340546e-02
    z[1,3,0]  R1453     -5.2586293220520020e-01
    z[1,3,0]  R1454     3.0178827047348022e-01
    z[1,3,0]  R1455     2.0443785190582275e-01
    z[1,3,0]  R1456     -1.7751251161098480e-01
    z[1,3,0]  R1457     5.6899610906839371e-02
    z[1,3,0]  R1458     1.6422684490680695e-01
    z[1,3,0]  R1459     2.9473572969436646e-01
    z[1,3,0]  R1460     -6.5723603963851929e-01
    z[1,3,0]  R1461     9.5317848026752472e-02
    z[1,3,0]  R1462     -5.1086451858282089e-02
    z[1,3,0]  R1463     -2.1587809920310974e-01
    z[1,3,0]  R1464     7.7477765083312988e-01
    z[1,3,0]  R1465     7.0630115270614624e-01
    z[1,3,0]  R1466     5.0864154100418091e-01
    z[1,3,0]  R1467     5.3289115428924561e-01
    z[1,3,0]  R1468     3.1803345680236816e-01
    z[1,3,0]  R1469     -4.4739622622728348e-02
    z[1,3,0]  R1470     -5.8397495746612549e-01
    z[1,3,0]  R1471     -5.5687215179204941e-02
    z[1,3,0]  R1472     8.9335137605667114e-01
    z[1,3,0]  R1473     -1.7038933932781219e-01
    z[1,3,0]  R1474     -3.7038710713386536e-01
    z[1,3,0]  R1475     -6.0038655996322632e-01
    z[1,3,0]  R1476     4.6409547328948975e-01
    z[1,3,0]  R1477     4.3099871277809143e-01
    z[1,3,0]  R1478     4.7354349493980408e-01
    z[1,3,0]  R1479     4.6459159255027771e-01
    z[1,3,0]  R1480     4.6672913432121277e-01
    z[1,3,0]  R1481     2.5813335180282593e-01
    z[1,3,0]  R1482     -9.3980008363723755e-01
    z[1,3,0]  R1483     -9.2294001579284668e-01
    z[1,3,0]  R1484     5.8017861843109131e-01
    z[1,3,0]  R1485     -8.6002784967422485e-01
    z[1,3,0]  R1486     -0.892230212688446
    z[1,3,0]  R1487     -9.4262242317199707e-01
    z[1,3,0]  R1488     -9.1773474216461182e-01
    z[1,3,0]  R1489     -8.9749175310134888e-01
    z[1,3,0]  R1490     -0.83182692527771
    z[1,3,0]  R1491     5.5075997114181519e-01
    z[1,3,0]  R1492     4.8558406531810760e-02
    z[1,3,0]  R1493     2.1610417962074280e-01
    z[1,3,0]  R1494     5.7938706874847412e-01
    z[1,3,0]  R1495     1.8145748972892761e-01
    z[1,3,0]  R1496     3.6470952630043030e-01
    z[1,3,0]  R1497     3.6930146813392639e-01
    z[1,3,0]  R1498     3.9038211107254028e-01
    z[1,3,0]  R1499     2.6583820581436157e-01
    z[1,3,0]  R1500     2.2130346298217773e-01
    z[1,3,0]  R1501     4.6522235870361328e-01
    z[1,3,0]  R1502     6.5786594152450562e-01
    z[1,3,0]  R1503     4.9325266480445862e-01
    z[1,3,0]  R1504     3.5619714856147766e-01
    z[1,3,0]  R1505     5.5103158950805664e-01
    z[1,3,0]  R1506     2.9873868823051453e-01
    z[1,3,0]  R1507     -3.5717669129371643e-01
    z[1,3,0]  R1508     -2.7027529478073120e-01
    z[1,3,0]  R1509     -0.3973388671875
    z[1,3,0]  R1510     -2.8489735722541809e-01
    z[1,3,0]  R1511     6.8873858451843262e-01
    z[1,3,0]  R1512     0.576435387134552
    z[1,3,0]  R1513     -1.0018469393253326e-01
    z[1,3,0]  R1514     6.7038416862487793e-02
    z[1,3,0]  R1515     3.8674166798591614e-01
    z[1,3,0]  R1516     3.9960426092147827e-01
    z[1,3,0]  R1517     3.9525407552719116e-01
    z[1,3,0]  R1518     3.9926269650459290e-01
    z[1,3,0]  R1519     -3.9417085051536560e-01
    z[1,3,0]  R1520     5.6480592489242554e-01
    z[1,3,0]  R1521     5.3114473819732666e-01
    z[1,3,0]  R1522     -5.3321599960327148e-02
    z[1,3,0]  R1523     3.0768087506294250e-01
    z[1,3,0]  R1524     1.9263944029808044e-01
    z[1,3,0]  R1525     1.9228491187095642e-01
    z[1,3,0]  R1526     -3.8100141286849976e-01
    z[1,3,0]  R1527     5.4885959625244141e-01
    z[1,3,0]  R1528     6.0691988468170166e-01
    z[1,3,0]  R1529     -4.7804492712020874e-01
    z[1,3,0]  R1530     3.6181899905204773e-01
    z[1,3,0]  R1531     5.7915753126144409e-01
    z[1,3,0]  R1532     -1.7139646410942078e-01
    z[1,3,0]  R1533     2.4324850738048553e-01
    z[1,3,0]  R1534     2.1458587050437927e-01
    z[1,3,0]  R1535     3.3688443899154663e-01
    z[1,3,0]  R1536     -1.5396653115749359e-01
    z[1,3,0]  R1537     -3.9778491854667664e-01
    z[1,3,0]  R1538     -5.5805152654647827e-01
    z[1,3,0]  R1539     2.9693955183029175e-01
    z[1,3,0]  R1540     -3.9586779475212097e-01
    z[1,3,0]  R1541     3.9001861214637756e-01
    z[1,3,0]  R1542     -1.1424923688173294e-01
    z[1,3,0]  R1543     1.1477511376142502e-01
    z[1,3,0]  R1544     3.7824258208274841e-01
    z[1,3,0]  R1545     4.2572364211082458e-01
    z[1,3,0]  R1546     -3.0046832561492920e-01
    z[1,3,0]  R1547     -4.1631302237510681e-01
    z[1,3,0]  R1548     -2.2245289757847786e-02
    z[1,3,0]  R1549     -1.5044157207012177e-01
    z[1,3,0]  R1550     -2.3720417916774750e-01
    z[1,3,0]  R1551     -6.7189380526542664e-02
    z[1,3,0]  R1552     3.3011120557785034e-01
    z[1,3,0]  R1553     2.8113198280334473e-01
    z[1,3,0]  R1554     -2.5362789630889893e-01
    z[1,3,0]  R1555     -4.4777533411979675e-01
    z[1,3,0]  R1556     2.2559408843517303e-01
    z[1,3,0]  R1557     1.6263779997825623e-01
    z[1,3,0]  R1558     -3.0208915472030640e-01
    z[1,3,0]  R1559     -2.7314043045043945e-01
    z[1,3,0]  R1560     -3.9606195688247681e-01
    z[1,3,0]  R1561     3.0516144633293152e-01
    z[1,3,0]  R1562     -1.5908235311508179e-01
    z[1,3,0]  R1563     3.5983249545097351e-01
    z[1,3,0]  R1564     4.0131369233131409e-01
    z[1,3,0]  R1565     -3.1321954727172852e-01
    z[1,3,0]  R1566     -2.8356176614761353e-01
    z[1,3,0]  R1567     -3.0964380502700806e-01
    z[1,3,0]  R1568     -3.9614996314048767e-01
    z[1,3,0]  R1569     -1.2843808531761169e-01
    z[1,3,0]  R1570     -2.2057932615280151e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R1419     -1
    z[1,3,1]  R1420     1
    z[1,3,1]  R1431     -8.4220498800277710e-02
    z[1,3,1]  R1432     0.361508309841156
    z[1,3,1]  R1433     4.8457989096641541e-01
    z[1,3,1]  R1434     -3.2911914587020874e-01
    z[1,3,1]  R1435     3.3398628234863281e-01
    z[1,3,1]  R1436     -4.8228830099105835e-01
    z[1,3,1]  R1437     -1.9169540703296661e-01
    z[1,3,1]  R1438     2.1775195002555847e-01
    z[1,3,1]  R1439     -2.4984495341777802e-01
    z[1,3,1]  R1440     2.1840962767601013e-01
    z[1,3,1]  R1441     3.6695379018783569e-01
    z[1,3,1]  R1442     6.5316796302795410e-01
    z[1,3,1]  R1443     0.657727062702179
    z[1,3,1]  R1444     6.4585006237030029e-01
    z[1,3,1]  R1445     7.4338763952255249e-01
    z[1,3,1]  R1446     7.0508313179016113e-01
    z[1,3,1]  R1447     7.9247128963470459e-01
    z[1,3,1]  R1448     8.2078307867050171e-01
    z[1,3,1]  R1449     3.3597180247306824e-01
    z[1,3,1]  R1450     3.2437753677368164e-01
    z[1,3,1]  R1451     8.7639510631561279e-01
    z[1,3,1]  R1452     0.31130251288414
    z[1,3,1]  R1453     -4.1803106665611267e-01
    z[1,3,1]  R1454     1.0529877245426178e-01
    z[1,3,1]  R1455     1.0849340260028839e-01
    z[1,3,1]  R1456     2.3467201739549637e-02
    z[1,3,1]  R1457     -2.1112029254436493e-01
    z[1,3,1]  R1458     1.6639775037765503e-01
    z[1,3,1]  R1459     -6.7488527856767178e-03
    z[1,3,1]  R1460     -6.3168264925479889e-02
    z[1,3,1]  R1461     0.547184944152832
    z[1,3,1]  R1462     1.0742236673831940e-01
    z[1,3,1]  R1463     0.407914936542511
    z[1,3,1]  R1464     4.4724959135055542e-01
    z[1,3,1]  R1465     3.4217163920402527e-01
    z[1,3,1]  R1466     1.4415302872657776e-01
    z[1,3,1]  R1467     3.5020154714584351e-01
    z[1,3,1]  R1468     3.6574858427047729e-01
    z[1,3,1]  R1469     -4.1784530878067017e-01
    z[1,3,1]  R1470     -3.3625042438507080e-01
    z[1,3,1]  R1471     8.6969435214996338e-01
    z[1,3,1]  R1472     8.6631134152412415e-02
    z[1,3,1]  R1473     1.4700804650783539e-01
    z[1,3,1]  R1474     -3.5427924990653992e-01
    z[1,3,1]  R1475     -6.7064750194549561e-01
    z[1,3,1]  R1476     -7.4182587862014771e-01
    z[1,3,1]  R1477     -7.4127340316772461e-01
    z[1,3,1]  R1478     -7.2319769859313965e-01
    z[1,3,1]  R1479     -7.1683096885681152e-01
    z[1,3,1]  R1480     -6.9388502836227417e-01
    z[1,3,1]  R1481     4.5794308185577393e-01
    z[1,3,1]  R1482     1.5471121668815613e-01
    z[1,3,1]  R1483     1.6253520548343658e-01
    z[1,3,1]  R1484     5.4190081357955933e-01
    z[1,3,1]  R1485     1.8640153110027313e-01
    z[1,3,1]  R1486     0.0975256860256195
    z[1,3,1]  R1487     -9.9438624456524849e-03
    z[1,3,1]  R1488     2.0124214887619019e-01
    z[1,3,1]  R1489     2.0787183940410614e-01
    z[1,3,1]  R1490     2.8012225031852722e-01
    z[1,3,1]  R1491     4.9174398183822632e-01
    z[1,3,1]  R1492     5.9860908985137939e-01
    z[1,3,1]  R1493     5.6498810648918152e-02
    z[1,3,1]  R1494     1.5831539034843445e-01
    z[1,3,1]  R1495     2.6287177205085754e-01
    z[1,3,1]  R1496     1.3917708396911621e-01
    z[1,3,1]  R1497     -3.7313610315322876e-02
    z[1,3,1]  R1498     -6.4909934997558594e-01
    z[1,3,1]  R1499     -6.3023924827575684e-01
    z[1,3,1]  R1500     -0.601081371307373
    z[1,3,1]  R1501     4.8583567142486572e-01
    z[1,3,1]  R1502     1.6910223662853241e-01
    z[1,3,1]  R1503     3.8512364029884338e-01
    z[1,3,1]  R1504     -2.4250841140747070e-01
    z[1,3,1]  R1505     2.0148472487926483e-01
    z[1,3,1]  R1506     5.6375807523727417e-01
    z[1,3,1]  R1507     -8.8710987567901611e-01
    z[1,3,1]  R1508     -8.7936633825302124e-01
    z[1,3,1]  R1509     -8.4518057107925415e-01
    z[1,3,1]  R1510     -8.9767938852310181e-01
    z[1,3,1]  R1511     3.1527695059776306e-01
    z[1,3,1]  R1512     1.0131421685218811e-01
    z[1,3,1]  R1513     6.2148368358612061e-01
    z[1,3,1]  R1514     6.3854932785034180e-01
    z[1,3,1]  R1515     -7.8269565105438232e-01
    z[1,3,1]  R1516     -7.5086838006973267e-01
    z[1,3,1]  R1517     -7.9141962528228760e-01
    z[1,3,1]  R1518     -8.3746296167373657e-01
    z[1,3,1]  R1519     -5.1557046175003052e-01
    z[1,3,1]  R1520     -6.1647754907608032e-01
    z[1,3,1]  R1521     3.2905480265617371e-01
    z[1,3,1]  R1522     9.5572900772094727e-01
    z[1,3,1]  R1523     3.0548056960105896e-01
    z[1,3,1]  R1524     1.9497880339622498e-01
    z[1,3,1]  R1525     5.1851749420166016e-01
    z[1,3,1]  R1526     6.3300591707229614e-01
    z[1,3,1]  R1527     -0.712550163269043
    z[1,3,1]  R1528     -7.5988835096359253e-01
    z[1,3,1]  R1529     -7.4890685081481934e-01
    z[1,3,1]  R1530     -6.0639894008636475e-01
    z[1,3,1]  R1531     6.6063940525054932e-01
    z[1,3,1]  R1532     7.8202486038208008e-01
    z[1,3,1]  R1533     1.7261256277561188e-01
    z[1,3,1]  R1534     -2.3551419377326965e-01
    z[1,3,1]  R1535     -2.0627915859222412e-01
    z[1,3,1]  R1536     -9.0729838609695435e-01
    z[1,3,1]  R1537     -8.2229351997375488e-01
    z[1,3,1]  R1538     -7.3243695497512817e-01
    z[1,3,1]  R1539     -5.0932437181472778e-01
    z[1,3,1]  R1540     -5.9857684373855591e-01
    z[1,3,1]  R1541     -1.8179433420300484e-02
    z[1,3,1]  R1542     8.6025208234786987e-01
    z[1,3,1]  R1543     4.1180285811424255e-01
    z[1,3,1]  R1544     -6.7911714315414429e-01
    z[1,3,1]  R1545     -6.1638671159744263e-01
    z[1,3,1]  R1546     -8.4821528196334839e-01
    z[1,3,1]  R1547     -6.9856476783752441e-01
    z[1,3,1]  R1548     -8.9396846294403076e-01
    z[1,3,1]  R1549     -8.1388109922409058e-01
    z[1,3,1]  R1550     -8.0397886037826538e-01
    z[1,3,1]  R1551     1.1819742619991302e-02
    z[1,3,1]  R1552     -7.3750841617584229e-01
    z[1,3,1]  R1553     -5.9825807809829712e-01
    z[1,3,1]  R1554     -0.844097912311554
    z[1,3,1]  R1555     -5.0424879789352417e-01
    z[1,3,1]  R1556     -6.4740163087844849e-01
    z[1,3,1]  R1557     -4.7776961326599121e-01
    z[1,3,1]  R1558     -5.2313446998596191e-01
    z[1,3,1]  R1559     -7.1146863698959351e-01
    z[1,3,1]  R1560     -0.487781286239624
    z[1,3,1]  R1561     1.2014646083116531e-02
    z[1,3,1]  R1562     6.5612250566482544e-01
    z[1,3,1]  R1563     -6.7768466472625732e-01
    z[1,3,1]  R1564     -7.2295677661895752e-01
    z[1,3,1]  R1565     -8.6170834302902222e-01
    z[1,3,1]  R1566     -0.867425799369812
    z[1,3,1]  R1567     -4.6951338648796082e-01
    z[1,3,1]  R1568     -4.7382223606109619e-01
    z[1,3,1]  R1569     -9.8977647721767426e-02
    z[1,3,1]  R1570     -2.1678347885608673e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R1421     -1
    z[1,3,2]  R1422     1
    z[1,3,2]  R1431     7.9628866910934448e-01
    z[1,3,2]  R1432     6.2952286005020142e-01
    z[1,3,2]  R1433     2.3803453147411346e-01
    z[1,3,2]  R1434     3.5012251138687134e-01
    z[1,3,2]  R1435     1.6661569476127625e-01
    z[1,3,2]  R1436     3.0057954788208008e-01
    z[1,3,2]  R1437     -7.2683282196521759e-02
    z[1,3,2]  R1438     -2.0050784945487976e-01
    z[1,3,2]  R1439     5.0285577774047852e-01
    z[1,3,2]  R1440     0.00567758409306407
    z[1,3,2]  R1441     -2.1179307997226715e-01
    z[1,3,2]  R1442     -5.8393353223800659e-01
    z[1,3,2]  R1443     -4.0201231837272644e-01
    z[1,3,2]  R1444     -3.8458973169326782e-01
    z[1,3,2]  R1445     4.2064037173986435e-02
    z[1,3,2]  R1446     -2.8824952244758606e-01
    z[1,3,2]  R1447     -2.4844953417778015e-01
    z[1,3,2]  R1448     -1.5014594793319702e-01
    z[1,3,2]  R1449     -3.6241721361875534e-02
    z[1,3,2]  R1450     1.1564271897077560e-01
    z[1,3,2]  R1451     1.7821869254112244e-01
    z[1,3,2]  R1452     -2.7339941263198853e-01
    z[1,3,2]  R1453     -6.2284684181213379e-01
    z[1,3,2]  R1454     9.8502419888973236e-02
    z[1,3,2]  R1455     -8.4907189011573792e-02
    z[1,3,2]  R1456     -3.7734252214431763e-01
    z[1,3,2]  R1457     1.1531513929367065e-01
    z[1,3,2]  R1458     -3.3423385024070740e-01
    z[1,3,2]  R1459     6.3833691179752350e-02
    z[1,3,2]  R1460     -3.4744244813919067e-01
    z[1,3,2]  R1461     -3.5237598419189453e-01
    z[1,3,2]  R1462     1.0244900733232498e-01
    z[1,3,2]  R1463     -7.7153556048870087e-02
    z[1,3,2]  R1464     -1.8872264027595520e-01
    z[1,3,2]  R1465     -5.5572193115949631e-02
    z[1,3,2]  R1466     7.1593075990676880e-02
    z[1,3,2]  R1467     1.0369773954153061e-02
    z[1,3,2]  R1468     -8.3991587162017822e-02
    z[1,3,2]  R1469     9.6030756831169128e-03
    z[1,3,2]  R1470     -3.5265704989433289e-01
    z[1,3,2]  R1471     -2.3279662430286407e-01
    z[1,3,2]  R1472     2.2210830822587013e-02
    z[1,3,2]  R1473     1.0618493705987930e-01
    z[1,3,2]  R1474     -1.7527283728122711e-01
    z[1,3,2]  R1475     3.4023147821426392e-01
    z[1,3,2]  R1476     -3.2223331928253174e-01
    z[1,3,2]  R1477     -1.6301706433296204e-01
    z[1,3,2]  R1478     -1.1810306459665298e-01
    z[1,3,2]  R1479     -2.4931703507900238e-01
    z[1,3,2]  R1480     -0.291786253452301
    z[1,3,2]  R1481     4.7317445278167725e-01
    z[1,3,2]  R1482     -7.1036987006664276e-02
    z[1,3,2]  R1483     3.9349254220724106e-03
    z[1,3,2]  R1484     6.0475575923919678e-01
    z[1,3,2]  R1485     -1.0655601322650909e-01
    z[1,3,2]  R1486     1.0289722681045532e-01
    z[1,3,2]  R1487     -1.4623812399804592e-02
    z[1,3,2]  R1488     -1.1547831445932388e-01
    z[1,3,2]  R1489     2.7077925205230713e-01
    z[1,3,2]  R1490     3.0057525634765625e-01
    z[1,3,2]  R1491     -6.0011076927185059e-01
    z[1,3,2]  R1492     -2.8771796822547913e-01
    z[1,3,2]  R1493     -0.17482890188694
    z[1,3,2]  R1494     5.7021718472242355e-02
    z[1,3,2]  R1495     -2.6236066222190857e-01
    z[1,3,2]  R1496     -2.7732434868812561e-01
    z[1,3,2]  R1497     -5.6132465600967407e-02
    z[1,3,2]  R1498     2.5654694437980652e-01
    z[1,3,2]  R1499     -2.4898232519626617e-01
    z[1,3,2]  R1500     -4.8615369945764542e-02
    z[1,3,2]  R1501     -2.3697596788406372e-01
    z[1,3,2]  R1502     0.478730708360672
    z[1,3,2]  R1503     1.1790613085031509e-01
    z[1,3,2]  R1504     1.5007908223196864e-03
    z[1,3,2]  R1505     -3.0414253473281860e-01
    z[1,3,2]  R1506     -4.6622648835182190e-01
    z[1,3,2]  R1507     1.2217401713132858e-01
    z[1,3,2]  R1508     -7.3766350746154785e-02
    z[1,3,2]  R1509     8.6302056908607483e-02
    z[1,3,2]  R1510     7.0185407996177673e-02
    z[1,3,2]  R1511     -1.1465033888816833e-01
    z[1,3,2]  R1512     -1.8005770444869995e-01
    z[1,3,2]  R1513     2.2961066663265228e-01
    z[1,3,2]  R1514     -5.6701207160949707e-01
    z[1,3,2]  R1515     -7.0753586478531361e-03
    z[1,3,2]  R1516     -4.2569848895072937e-01
    z[1,3,2]  R1517     3.8507454097270966e-02
    z[1,3,2]  R1518     -2.1936345100402832e-01
    z[1,3,2]  R1519     -4.4113822281360626e-02
    z[1,3,2]  R1520     -2.9070353507995605e-01
    z[1,3,2]  R1521     3.1474274396896362e-01
    z[1,3,2]  R1522     -1.3277991116046906e-01
    z[1,3,2]  R1523     -2.0039129257202148e-01
    z[1,3,2]  R1524     3.3667656779289246e-01
    z[1,3,2]  R1525     9.5063023269176483e-02
    z[1,3,2]  R1526     1.8678675591945648e-01
    z[1,3,2]  R1527     -1.5000531077384949e-01
    z[1,3,2]  R1528     1.4589686691761017e-01
    z[1,3,2]  R1529     -1.3811717927455902e-01
    z[1,3,2]  R1530     -3.2649955153465271e-01
    z[1,3,2]  R1531     -7.7538035809993744e-02
    z[1,3,2]  R1532     2.7904254198074341e-01
    z[1,3,2]  R1533     4.6756044030189514e-01
    z[1,3,2]  R1534     5.8996933698654175e-01
    z[1,3,2]  R1535     3.0695015192031860e-01
    z[1,3,2]  R1536     -8.3865828812122345e-02
    z[1,3,2]  R1537     -0.201654851436615
    z[1,3,2]  R1538     2.3760262876749039e-02
    z[1,3,2]  R1539     1.9889634847640991e-01
    z[1,3,2]  R1540     -4.1506299376487732e-01
    z[1,3,2]  R1541     1.5373519062995911e-01
    z[1,3,2]  R1542     6.0239702463150024e-02
    z[1,3,2]  R1543     -2.5170063972473145e-01
    z[1,3,2]  R1544     -3.9540448784828186e-01
    z[1,3,2]  R1545     1.8756791949272156e-01
    z[1,3,2]  R1546     -1.8159843981266022e-01
    z[1,3,2]  R1547     -1.4692538976669312e-01
    z[1,3,2]  R1548     2.8810954093933105e-01
    z[1,3,2]  R1549     0.518994152545929
    z[1,3,2]  R1550     -7.1790322661399841e-02
    z[1,3,2]  R1551     2.0671610534191132e-01
    z[1,3,2]  R1552     -2.9173594713211060e-01
    z[1,3,2]  R1553     -2.5543960928916931e-01
    z[1,3,2]  R1554     -2.7297517657279968e-01
    z[1,3,2]  R1555     -4.6042707562446594e-01
    z[1,3,2]  R1556     1.2205547094345093e-01
    z[1,3,2]  R1557     -1.7233356833457947e-01
    z[1,3,2]  R1558     -0.463856041431427
    z[1,3,2]  R1559     -0.343553364276886
    z[1,3,2]  R1560     -5.5767357349395752e-01
    z[1,3,2]  R1561     2.7804297208786011e-01
    z[1,3,2]  R1562     -6.2095586210489273e-02
    z[1,3,2]  R1563     -2.0334620773792267e-01
    z[1,3,2]  R1564     -4.3719375133514404e-01
    z[1,3,2]  R1565     -3.4538358449935913e-01
    z[1,3,2]  R1566     2.2523038089275360e-01
    z[1,3,2]  R1567     -1.1186144500970840e-01
    z[1,3,2]  R1568     -2.3457500338554382e-01
    z[1,3,2]  R1569     -3.6460712552070618e-01
    z[1,3,2]  R1570     -7.4643462896347046e-01
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R1423     -1
    z[1,3,3]  R1424     1
    z[1,3,3]  R1431     -1.0823883116245270e-01
    z[1,3,3]  R1432     0.356587290763855
    z[1,3,3]  R1433     6.0027605295181274e-01
    z[1,3,3]  R1434     5.1075166463851929e-01
    z[1,3,3]  R1435     5.3740882873535156e-01
    z[1,3,3]  R1436     1.0916360467672348e-01
    z[1,3,3]  R1437     4.9610521644353867e-02
    z[1,3,3]  R1438     2.6247090101242065e-01
    z[1,3,3]  R1439     3.9771571755409241e-01
    z[1,3,3]  R1440     4.4433519244194031e-01
    z[1,3,3]  R1441     2.9319867491722107e-01
    z[1,3,3]  R1442     -1.5360046923160553e-01
    z[1,3,3]  R1443     -2.7590749785304070e-02
    z[1,3,3]  R1444     2.2711518406867981e-01
    z[1,3,3]  R1445     -1.6082301735877991e-01
    z[1,3,3]  R1446     -6.8718180060386658e-02
    z[1,3,3]  R1447     3.1026366353034973e-01
    z[1,3,3]  R1448     -5.8440599590539932e-02
    z[1,3,3]  R1449     -4.1871690191328526e-03
    z[1,3,3]  R1450     -4.1127860546112061e-02
    z[1,3,3]  R1451     -3.3243077993392944e-01
    z[1,3,3]  R1452     -6.8526461720466614e-02
    z[1,3,3]  R1453     -8.7724313139915466e-02
    z[1,3,3]  R1454     -3.5257175564765930e-01
    z[1,3,3]  R1455     -2.9554140567779541e-01
    z[1,3,3]  R1456     -2.9453948140144348e-01
    z[1,3,3]  R1457     -3.3523476123809814e-01
    z[1,3,3]  R1458     -3.7054210901260376e-01
    z[1,3,3]  R1459     -4.7129637002944946e-01
    z[1,3,3]  R1460     -3.0005259439349174e-02
    z[1,3,3]  R1461     -3.7874984741210938e-01
    z[1,3,3]  R1462     9.7439870238304138e-02
    z[1,3,3]  R1463     -3.0197608470916748e-01
    z[1,3,3]  R1464     -2.0218986272811890e-01
    z[1,3,3]  R1465     -1.5474145114421844e-01
    z[1,3,3]  R1466     -4.0473595261573792e-02
    z[1,3,3]  R1467     9.7739197313785553e-02
    z[1,3,3]  R1468     -2.5048962235450745e-01
    z[1,3,3]  R1469     -3.2698279619216919e-01
    z[1,3,3]  R1470     -2.5443577766418457e-01
    z[1,3,3]  R1471     -1.5198162198066711e-01
    z[1,3,3]  R1472     -3.0203291773796082e-01
    z[1,3,3]  R1473     -3.0847027897834778e-01
    z[1,3,3]  R1474     -3.9656361937522888e-01
    z[1,3,3]  R1475     -9.1805262491106987e-03
    z[1,3,3]  R1476     -1.6141927242279053e-01
    z[1,3,3]  R1477     -2.9566857218742371e-01
    z[1,3,3]  R1478     -1.8786433339118958e-01
    z[1,3,3]  R1479     -3.1983304023742676e-01
    z[1,3,3]  R1480     1.8618069589138031e-01
    z[1,3,3]  R1481     -3.7363407015800476e-01
    z[1,3,3]  R1482     -2.3972152173519135e-01
    z[1,3,3]  R1483     -1.9779071211814880e-01
    z[1,3,3]  R1484     -7.7056130394339561e-03
    z[1,3,3]  R1485     -2.0588600635528564e-01
    z[1,3,3]  R1486     3.0438458546996117e-02
    z[1,3,3]  R1487     -8.3044849336147308e-02
    z[1,3,3]  R1488     2.4156817793846130e-01
    z[1,3,3]  R1489     9.3204446136951447e-02
    z[1,3,3]  R1490     -1.8220625817775726e-01
    z[1,3,3]  R1491     -2.1709744632244110e-01
    z[1,3,3]  R1492     4.2003658413887024e-01
    z[1,3,3]  R1493     -6.1917316913604736e-01
    z[1,3,3]  R1494     -2.4185305833816528e-01
    z[1,3,3]  R1495     -4.7418147325515747e-01
    z[1,3,3]  R1496     -3.5897254943847656e-01
    z[1,3,3]  R1497     -6.7649924755096436e-01
    z[1,3,3]  R1498     5.8192396163940430e-01
    z[1,3,3]  R1499     5.5674391984939575e-01
    z[1,3,3]  R1500     6.7789024114608765e-01
    z[1,3,3]  R1501     -1.2351523339748383e-01
    z[1,3,3]  R1502     -3.7697765231132507e-01
    z[1,3,3]  R1503     -3.9568236470222473e-01
    z[1,3,3]  R1504     -4.5480468869209290e-01
    z[1,3,3]  R1505     -1.4198586344718933e-01
    z[1,3,3]  R1506     -3.2391302287578583e-02
    z[1,3,3]  R1507     -7.1297824382781982e-02
    z[1,3,3]  R1508     -1.7052255570888519e-01
    z[1,3,3]  R1509     -1.3055598735809326e-01
    z[1,3,3]  R1510     1.0369133204221725e-01
    z[1,3,3]  R1511     -5.6572878360748291e-01
    z[1,3,3]  R1512     -6.1591309309005737e-01
    z[1,3,3]  R1513     6.7653483152389526e-01
    z[1,3,3]  R1514     -1.1923617124557495e-01
    z[1,3,3]  R1515     3.2390314340591431e-01
    z[1,3,3]  R1516     3.9310574531555176e-02
    z[1,3,3]  R1517     1.3593333959579468e-01
    z[1,3,3]  R1518     -1.6196319460868835e-01
    z[1,3,3]  R1519     5.8970528841018677e-01
    z[1,3,3]  R1520     3.8669671863317490e-02
    z[1,3,3]  R1521     -1.9893029239028692e-03
    z[1,3,3]  R1522     1.4506794512271881e-01
    z[1,3,3]  R1523     -2.7058762311935425e-01
    z[1,3,3]  R1524     -5.8655035495758057e-01
    z[1,3,3]  R1525     -4.3224066495895386e-02
    z[1,3,3]  R1526     3.6754816770553589e-01
    z[1,3,3]  R1527     3.5326120257377625e-01
    z[1,3,3]  R1528     2.2708898410201073e-02
    z[1,3,3]  R1529     2.7809518575668335e-01
    z[1,3,3]  R1530     2.4823831021785736e-01
    z[1,3,3]  R1531     -2.7817955613136292e-01
    z[1,3,3]  R1532     -3.7966978549957275e-01
    z[1,3,3]  R1533     -5.1656246185302734e-01
    z[1,3,3]  R1534     -7.2383642196655273e-01
    z[1,3,3]  R1535     -4.3253010511398315e-01
    z[1,3,3]  R1536     -3.0411076545715332e-01
    z[1,3,3]  R1537     -5.1381520926952362e-02
    z[1,3,3]  R1538     2.3650184273719788e-01
    z[1,3,3]  R1539     5.2529340982437134e-01
    z[1,3,3]  R1540     2.6098170876502991e-01
    z[1,3,3]  R1541     -7.0872771739959717e-01
    z[1,3,3]  R1542     2.3492148146033287e-02
    z[1,3,3]  R1543     -5.7568907737731934e-01
    z[1,3,3]  R1544     2.0097626373171806e-02
    z[1,3,3]  R1545     3.1200775504112244e-01
    z[1,3,3]  R1546     -3.1716406345367432e-01
    z[1,3,3]  R1547     0.325791597366333
    z[1,3,3]  R1548     -1.7388641834259033e-01
    z[1,3,3]  R1549     -3.3776730298995972e-02
    z[1,3,3]  R1550     -9.5977261662483215e-02
    z[1,3,3]  R1551     -7.8665858507156372e-01
    z[1,3,3]  R1552     3.5539820790290833e-01
    z[1,3,3]  R1553     5.0124150514602661e-01
    z[1,3,3]  R1554     -1.1464725248515606e-02
    z[1,3,3]  R1555     4.6107214689254761e-01
    z[1,3,3]  R1556     4.3256533145904541e-01
    z[1,3,3]  R1557     6.0782027244567871e-01
    z[1,3,3]  R1558     1.7142720520496368e-01
    z[1,3,3]  R1559     3.2900744676589966e-01
    z[1,3,3]  R1560     -7.7450558543205261e-02
    z[1,3,3]  R1561     -6.4688611030578613e-01
    z[1,3,3]  R1562     3.6693942546844482e-01
    z[1,3,3]  R1563     0.519483745098114
    z[1,3,3]  R1564     5.1869828253984451e-02
    z[1,3,3]  R1565     1.3376979529857635e-01
    z[1,3,3]  R1566     1.4833371341228485e-01
    z[1,3,3]  R1567     4.6653857827186584e-01
    z[1,3,3]  R1568     1.1839896440505981e-01
    z[1,3,3]  R1569     6.3796001672744751e-01
    z[1,3,3]  R1570     2.9312953352928162e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R1425     -1
    z[1,3,4]  R1426     1
    z[1,3,4]  R1431     1.4760370831936598e-03
    z[1,3,4]  R1432     4.1524812579154968e-02
    z[1,3,4]  R1433     -2.6050312444567680e-02
    z[1,3,4]  R1434     5.8437857776880264e-02
    z[1,3,4]  R1435     -1.7981484532356262e-01
    z[1,3,4]  R1436     -7.4437371222302318e-04
    z[1,3,4]  R1437     2.3300166428089142e-01
    z[1,3,4]  R1438     2.0796832442283630e-01
    z[1,3,4]  R1439     1.1065878719091415e-01
    z[1,3,4]  R1440     2.0427180826663971e-01
    z[1,3,4]  R1441     1.6974899172782898e-01
    z[1,3,4]  R1442     -4.4538193941116333e-01
    z[1,3,4]  R1443     -3.1974750757217407e-01
    z[1,3,4]  R1444     -1.9922609627246857e-01
    z[1,3,4]  R1445     -2.7087783813476562e-01
    z[1,3,4]  R1446     2.0275993272662163e-02
    z[1,3,4]  R1447     1.0352526605129242e-01
    z[1,3,4]  R1448     -1.5411649644374847e-01
    z[1,3,4]  R1449     -9.2224171385169029e-03
    z[1,3,4]  R1450     1.1496607959270477e-01
    z[1,3,4]  R1451     1.1724268645048141e-01
    z[1,3,4]  R1452     8.7437534332275391e-01
    z[1,3,4]  R1453     -1.4307887852191925e-01
    z[1,3,4]  R1454     8.4778529405593872e-01
    z[1,3,4]  R1455     5.1797825098037720e-01
    z[1,3,4]  R1456     7.7364194393157959e-01
    z[1,3,4]  R1457     8.4896445274353027e-01
    z[1,3,4]  R1458     0.667140781879425
    z[1,3,4]  R1459     6.5066725015640259e-01
    z[1,3,4]  R1460     -2.4185539782047272e-01
    z[1,3,4]  R1461     -8.3446763455867767e-02
    z[1,3,4]  R1462     8.9992147684097290e-01
    z[1,3,4]  R1463     -2.5832799077033997e-01
    z[1,3,4]  R1464     1.7638940364122391e-02
    z[1,3,4]  R1465     -4.6297335624694824e-01
    z[1,3,4]  R1466     -7.9953235387802124e-01
    z[1,3,4]  R1467     -7.4610334634780884e-01
    z[1,3,4]  R1468     7.0542466640472412e-01
    z[1,3,4]  R1469     6.1648392677307129e-01
    z[1,3,4]  R1470     1.2818135321140289e-01
    z[1,3,4]  R1471     2.1970003843307495e-01
    z[1,3,4]  R1472     -2.5865370035171509e-01
    z[1,3,4]  R1473     6.4369821548461914e-01
    z[1,3,4]  R1474     5.0892108678817749e-01
    z[1,3,4]  R1475     -1.2675713002681732e-01
    z[1,3,4]  R1476     9.5251753926277161e-02
    z[1,3,4]  R1477     -7.3320806026458740e-02
    z[1,3,4]  R1478     -5.4239153861999512e-02
    z[1,3,4]  R1479     -1.0252785682678223e-01
    z[1,3,4]  R1480     2.8734045103192329e-02
    z[1,3,4]  R1481     3.4899908304214478e-01
    z[1,3,4]  R1482     1.3045790791511536e-01
    z[1,3,4]  R1483     6.4899399876594543e-02
    z[1,3,4]  R1484     5.2281104028224945e-02
    z[1,3,4]  R1485     -2.7794393897056580e-01
    z[1,3,4]  R1486     -4.3862383812665939e-02
    z[1,3,4]  R1487     -3.0529299378395081e-01
    z[1,3,4]  R1488     -0.0504038967192173
    z[1,3,4]  R1489     1.9112777709960938e-01
    z[1,3,4]  R1490     -4.1402861475944519e-02
    z[1,3,4]  R1491     -3.5263508558273315e-02
    z[1,3,4]  R1492     2.8810936212539673e-01
    z[1,3,4]  R1493     -6.4258921146392822e-01
    z[1,3,4]  R1494     -5.0122499465942383e-01
    z[1,3,4]  R1495     -7.5447636842727661e-01
    z[1,3,4]  R1496     -4.3736043572425842e-01
    z[1,3,4]  R1497     -2.8554555773735046e-01
    z[1,3,4]  R1498     -1.3387228548526764e-01
    z[1,3,4]  R1499     3.9674103260040283e-01
    z[1,3,4]  R1500     -1.8834735453128815e-01
    z[1,3,4]  R1501     1.6314629465341568e-02
    z[1,3,4]  R1502     3.4935045987367630e-02
    z[1,3,4]  R1503     -5.6127011775970459e-01
    z[1,3,4]  R1504     6.2418907880783081e-01
    z[1,3,4]  R1505     0.508728563785553
    z[1,3,4]  R1506     5.9628438949584961e-01
    z[1,3,4]  R1507     -9.6647582948207855e-02
    z[1,3,4]  R1508     -2.8975948691368103e-01
    z[1,3,4]  R1509     -1.2747314572334290e-01
    z[1,3,4]  R1510     2.3188865184783936e-01
    z[1,3,4]  R1511     -6.5716892480850220e-02
    z[1,3,4]  R1512     8.0855533480644226e-02
    z[1,3,4]  R1513     -3.2234955579042435e-02
    z[1,3,4]  R1514     -2.5378465652465820e-01
    z[1,3,4]  R1515     2.8136804699897766e-01
    z[1,3,4]  R1516     -1.0198257118463516e-01
    z[1,3,4]  R1517     -1.1463674902915955e-01
    z[1,3,4]  R1518     1.7112898826599121e-01
    z[1,3,4]  R1519     -2.5380682945251465e-01
    z[1,3,4]  R1520     9.4268575310707092e-02
    z[1,3,4]  R1521     6.5625023841857910e-01
    z[1,3,4]  R1522     -1.6640214622020721e-01
    z[1,3,4]  R1523     5.1289498805999756e-01
    z[1,3,4]  R1524     -4.8925641179084778e-01
    z[1,3,4]  R1525     2.7319782972335815e-01
    z[1,3,4]  R1526     2.0046363770961761e-01
    z[1,3,4]  R1527     -1.7939563095569611e-01
    z[1,3,4]  R1528     7.3708340525627136e-02
    z[1,3,4]  R1529     -2.0611342787742615e-01
    z[1,3,4]  R1530     1.1279787868261337e-01
    z[1,3,4]  R1531     2.5928923487663269e-01
    z[1,3,4]  R1532     1.6672702133655548e-01
    z[1,3,4]  R1533     -4.0130406618118286e-01
    z[1,3,4]  R1534     -5.1522977650165558e-02
    z[1,3,4]  R1535     4.1288143396377563e-01
    z[1,3,4]  R1536     -8.2583807408809662e-02
    z[1,3,4]  R1537     8.4618858993053436e-02
    z[1,3,4]  R1538     1.7774626612663269e-01
    z[1,3,4]  R1539     2.6971861720085144e-02
    z[1,3,4]  R1540     3.5232746601104736e-01
    z[1,3,4]  R1541     5.6551039218902588e-01
    z[1,3,4]  R1542     1.7291894555091858e-01
    z[1,3,4]  R1543     -3.7263345718383789e-01
    z[1,3,4]  R1544     -1.6487531363964081e-01
    z[1,3,4]  R1545     -3.3342546224594116e-01
    z[1,3,4]  R1546     2.2124059498310089e-01
    z[1,3,4]  R1547     1.4005471765995026e-01
    z[1,3,4]  R1548     2.7248656749725342e-01
    z[1,3,4]  R1549     -3.3528175204992294e-02
    z[1,3,4]  R1550     1.4610594511032104e-01
    z[1,3,4]  R1551     -1.8471702933311462e-02
    z[1,3,4]  R1552     -7.2325021028518677e-02
    z[1,3,4]  R1553     -2.2511104121804237e-02
    z[1,3,4]  R1554     1.9403712451457977e-01
    z[1,3,4]  R1555     1.2670768797397614e-01
    z[1,3,4]  R1556     -0.0792994499206543
    z[1,3,4]  R1557     -2.1422253549098969e-01
    z[1,3,4]  R1558     2.0323148369789124e-01
    z[1,3,4]  R1559     1.4503178000450134e-01
    z[1,3,4]  R1560     -3.4546792507171631e-01
    z[1,3,4]  R1561     -1.3877657055854797e-01
    z[1,3,4]  R1562     4.0217930078506470e-01
    z[1,3,4]  R1563     -3.1700424849987030e-02
    z[1,3,4]  R1564     2.9526901245117188e-01
    z[1,3,4]  R1565     -5.3333666175603867e-02
    z[1,3,4]  R1566     1.0146160423755646e-01
    z[1,3,4]  R1567     -1.7991612851619720e-01
    z[1,3,4]  R1568     -1.6010677814483643e-01
    z[1,3,4]  R1569     -3.0307593941688538e-01
    z[1,3,4]  R1570     -2.7151322364807129e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R1427     -1
    z[1,3,5]  R1428     1
    z[1,3,5]  R1431     -4.6309524774551392e-01
    z[1,3,5]  R1432     -4.9777108430862427e-01
    z[1,3,5]  R1433     -4.2009532451629639e-01
    z[1,3,5]  R1434     -7.0185315608978271e-01
    z[1,3,5]  R1435     -6.2715178728103638e-01
    z[1,3,5]  R1436     -0.702717125415802
    z[1,3,5]  R1437     -7.4101728200912476e-01
    z[1,3,5]  R1438     -8.6752545833587646e-01
    z[1,3,5]  R1439     -3.7044957280158997e-01
    z[1,3,5]  R1440     -1.9174227118492126e-01
    z[1,3,5]  R1441     -4.8559173941612244e-01
    z[1,3,5]  R1442     -1.7354622483253479e-02
    z[1,3,5]  R1443     -7.6631464064121246e-02
    z[1,3,5]  R1444     5.7139031589031219e-02
    z[1,3,5]  R1445     1.1248541623353958e-01
    z[1,3,5]  R1446     1.1797171086072922e-01
    z[1,3,5]  R1447     2.0577445626258850e-01
    z[1,3,5]  R1448     4.0649777650833130e-01
    z[1,3,5]  R1449     -1.2953018769621849e-02
    z[1,3,5]  R1450     7.9326741397380829e-02
    z[1,3,5]  R1451     -1.7031390964984894e-01
    z[1,3,5]  R1452     0.214023619890213
    z[1,3,5]  R1453     3.6025542020797729e-01
    z[1,3,5]  R1454     1.0420871526002884e-01
    z[1,3,5]  R1455     7.6388245820999146e-01
    z[1,3,5]  R1456     -2.0823728293180466e-02
    z[1,3,5]  R1457     3.0105376243591309e-01
    z[1,3,5]  R1458     -2.1040309220552444e-02
    z[1,3,5]  R1459     4.6810010075569153e-01
    z[1,3,5]  R1460     5.6569927930831909e-01
    z[1,3,5]  R1461     -5.4583930969238281e-01
    z[1,3,5]  R1462     -2.8972637653350830e-01
    z[1,3,5]  R1463     -7.1383011341094971e-01
    z[1,3,5]  R1464     1.3720458745956421e-01
    z[1,3,5]  R1465     1.3389253616333008e-01
    z[1,3,5]  R1466     -0.0657874047756195
    z[1,3,5]  R1467     5.4046556353569031e-02
    z[1,3,5]  R1468     -1.2181343883275986e-01
    z[1,3,5]  R1469     5.0305038690567017e-01
    z[1,3,5]  R1470     5.5670654773712158e-01
    z[1,3,5]  R1471     -3.3804804086685181e-01
    z[1,3,5]  R1472     1.0120960325002670e-01
    z[1,3,5]  R1473     5.6893342733383179e-01
    z[1,3,5]  R1474     5.1979804039001465e-01
    z[1,3,5]  R1475     7.6164029538631439e-02
    z[1,3,5]  R1476     2.9966291785240173e-01
    z[1,3,5]  R1477     2.8683552145957947e-01
    z[1,3,5]  R1478     4.4693747162818909e-01
    z[1,3,5]  R1479     3.0494108796119690e-01
    z[1,3,5]  R1480     3.9764198660850525e-01
    z[1,3,5]  R1481     -4.8548573255538940e-01
    z[1,3,5]  R1482     6.3925251364707947e-02
    z[1,3,5]  R1483     -1.3533490896224976e-01
    z[1,3,5]  R1484     -2.9999520629644394e-02
    z[1,3,5]  R1485     -2.9029190540313721e-01
    z[1,3,5]  R1486     -4.2483350634574890e-01
    z[1,3,5]  R1487     -4.1109815239906311e-02
    z[1,3,5]  R1488     -0.0789119228720665
    z[1,3,5]  R1489     0.00739058293402195
    z[1,3,5]  R1490     -2.2993431985378265e-01
    z[1,3,5]  R1491     2.0528608560562134e-01
    z[1,3,5]  R1492     -2.4083724617958069e-01
    z[1,3,5]  R1493     -1.9655372202396393e-01
    z[1,3,5]  R1494     1.6232709586620331e-01
    z[1,3,5]  R1495     -1.7088063061237335e-01
    z[1,3,5]  R1496     -0.0994378998875618
    z[1,3,5]  R1497     2.9747176170349121e-01
    z[1,3,5]  R1498     -5.1031500101089478e-02
    z[1,3,5]  R1499     -4.4756412506103516e-02
    z[1,3,5]  R1500     2.6538664102554321e-01
    z[1,3,5]  R1501     -2.2161072492599487e-01
    z[1,3,5]  R1502     8.1138901412487030e-02
    z[1,3,5]  R1503     1.0783676803112030e-01
    z[1,3,5]  R1504     1.5114578604698181e-01
    z[1,3,5]  R1505     4.8304149508476257e-01
    z[1,3,5]  R1506     -1.2417440861463547e-01
    z[1,3,5]  R1507     -5.2974302321672440e-02
    z[1,3,5]  R1508     1.1111255735158920e-02
    z[1,3,5]  R1509     -8.2784526050090790e-02
    z[1,3,5]  R1510     1.1146222800016403e-01
    z[1,3,5]  R1511     0.251359224319458
    z[1,3,5]  R1512     4.1499685496091843e-02
    z[1,3,5]  R1513     -2.8766372799873352e-01
    z[1,3,5]  R1514     -4.3079584836959839e-01
    z[1,3,5]  R1515     2.2054976224899292e-01
    z[1,3,5]  R1516     -1.4317522943019867e-01
    z[1,3,5]  R1517     4.1190677881240845e-01
    z[1,3,5]  R1518     1.5191332995891571e-01
    z[1,3,5]  R1519     3.1151914596557617e-01
    z[1,3,5]  R1520     3.9414763450622559e-01
    z[1,3,5]  R1521     2.2859179973602295e-01
    z[1,3,5]  R1522     -1.1515405774116516e-01
    z[1,3,5]  R1523     -3.2339328527450562e-01
    z[1,3,5]  R1524     -1.7447908222675323e-01
    z[1,3,5]  R1525     -2.9478749260306358e-02
    z[1,3,5]  R1526     0.340032160282135
    z[1,3,5]  R1527     1.0683614015579224e-01
    z[1,3,5]  R1528     -1.3590057194232941e-01
    z[1,3,5]  R1529     -2.6704284548759460e-01
    z[1,3,5]  R1530     1.3821706175804138e-01
    z[1,3,5]  R1531     -2.4591540917754173e-02
    z[1,3,5]  R1532     1.7587290704250336e-01
    z[1,3,5]  R1533     -6.7038662731647491e-02
    z[1,3,5]  R1534     -1.2629090249538422e-01
    z[1,3,5]  R1535     -2.9961558058857918e-02
    z[1,3,5]  R1536     1.6140486299991608e-01
    z[1,3,5]  R1537     3.3552536368370056e-01
    z[1,3,5]  R1538     2.3200479149818420e-01
    z[1,3,5]  R1539     1.7891988158226013e-01
    z[1,3,5]  R1540     2.6513275504112244e-01
    z[1,3,5]  R1541     -8.6372224614024162e-03
    z[1,3,5]  R1542     -4.5620220899581909e-01
    z[1,3,5]  R1543     -5.3024077415466309e-01
    z[1,3,5]  R1544     7.6076802797615528e-03
    z[1,3,5]  R1545     -2.6597169041633606e-01
    z[1,3,5]  R1546     -1.9071632996201515e-02
    z[1,3,5]  R1547     2.7643588185310364e-01
    z[1,3,5]  R1548     1.4667242765426636e-02
    z[1,3,5]  R1549     1.9412128627300262e-01
    z[1,3,5]  R1550     -0.51123046875
    z[1,3,5]  R1551     -4.3620994687080383e-01
    z[1,3,5]  R1552     3.6117190122604370e-01
    z[1,3,5]  R1553     -2.8672000765800476e-01
    z[1,3,5]  R1554     -3.2860684394836426e-01
    z[1,3,5]  R1555     2.9860296845436096e-01
    z[1,3,5]  R1556     1.2046633660793304e-01
    z[1,3,5]  R1557     -2.8808993101119995e-01
    z[1,3,5]  R1558     4.9473512172698975e-01
    z[1,3,5]  R1559     -9.4497554004192352e-02
    z[1,3,5]  R1560     2.6760599017143250e-01
    z[1,3,5]  R1561     -3.1865677237510681e-01
    z[1,3,5]  R1562     4.2646953463554382e-01
    z[1,3,5]  R1563     2.1734078228473663e-01
    z[1,3,5]  R1564     -1.1890596896409988e-01
    z[1,3,5]  R1565     1.2651601433753967e-01
    z[1,3,5]  R1566     -2.9000097513198853e-01
    z[1,3,5]  R1567     5.5134242773056030e-01
    z[1,3,5]  R1568     3.9442360401153564e-01
    z[1,3,5]  R1569     5.3061836957931519e-01
    z[1,3,5]  R1570     4.0059766173362732e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R1429     -1
    z[1,3,6]  R1430     1
    z[1,3,6]  R1431     -1.4961341023445129e-01
    z[1,3,6]  R1432     2.1387757360935211e-01
    z[1,3,6]  R1433     0.087035171687603
    z[1,3,6]  R1434     -8.3404621109366417e-03
    z[1,3,6]  R1435     -1.8069240450859070e-01
    z[1,3,6]  R1436     0.287383496761322
    z[1,3,6]  R1437     -4.4324392080307007e-01
    z[1,3,6]  R1438     7.8737497329711914e-02
    z[1,3,6]  R1439     5.5472618341445923e-01
    z[1,3,6]  R1440     7.5775671005249023e-01
    z[1,3,6]  R1441     3.4774962067604065e-01
    z[1,3,6]  R1442     9.1815330088138580e-02
    z[1,3,6]  R1443     -3.9528802037239075e-01
    z[1,3,6]  R1444     0.0697116032242775
    z[1,3,6]  R1445     2.9087954759597778e-01
    z[1,3,6]  R1446     3.2448939979076385e-02
    z[1,3,6]  R1447     -5.4661218076944351e-02
    z[1,3,6]  R1448     -2.4099057912826538e-01
    z[1,3,6]  R1449     -1.1285389959812164e-01
    z[1,3,6]  R1450     7.5361780822277069e-02
    z[1,3,6]  R1451     -2.4202053900808096e-03
    z[1,3,6]  R1452     1.1376570910215378e-01
    z[1,3,6]  R1453     5.3188685327768326e-02
    z[1,3,6]  R1454     -1.8500572443008423e-01
    z[1,3,6]  R1455     -7.9107824712991714e-03
    z[1,3,6]  R1456     -3.7395489215850830e-01
    z[1,3,6]  R1457     0.123031385242939
    z[1,3,6]  R1458     -5.0080728530883789e-01
    z[1,3,6]  R1459     -2.1072435379028320e-01
    z[1,3,6]  R1460     -2.5283247232437134e-01
    z[1,3,6]  R1461     3.4493315219879150e-01
    z[1,3,6]  R1462     2.6844039559364319e-01
    z[1,3,6]  R1463     -3.3700618147850037e-01
    z[1,3,6]  R1464     -3.2257422804832458e-01
    z[1,3,6]  R1465     -3.5320317745208740e-01
    z[1,3,6]  R1466     -2.6487755775451660e-01
    z[1,3,6]  R1467     -1.5535186231136322e-01
    z[1,3,6]  R1468     -4.2757540941238403e-01
    z[1,3,6]  R1469     2.8858572244644165e-01
    z[1,3,6]  R1470     -1.7450398206710815e-01
    z[1,3,6]  R1471     -2.6332248002290726e-02
    z[1,3,6]  R1472     -0.159862220287323
    z[1,3,6]  R1473     -3.2387372851371765e-01
    z[1,3,6]  R1474     -1.4186498522758484e-01
    z[1,3,6]  R1475     -2.2816176712512970e-01
    z[1,3,6]  R1476     -0.0744878277182579
    z[1,3,6]  R1477     -2.5121471285820007e-01
    z[1,3,6]  R1478     -2.8377154842019081e-02
    z[1,3,6]  R1479     -4.8527400940656662e-02
    z[1,3,6]  R1480     1.4812238514423370e-01
    z[1,3,6]  R1481     -5.1596730947494507e-02
    z[1,3,6]  R1482     -9.6031047403812408e-02
    z[1,3,6]  R1483     2.4515299499034882e-01
    z[1,3,6]  R1484     1.7724240198731422e-02
    z[1,3,6]  R1485     1.0169165581464767e-01
    z[1,3,6]  R1486     -2.2188175469636917e-02
    z[1,3,6]  R1487     9.6747070550918579e-02
    z[1,3,6]  R1488     -1.9185002148151398e-01
    z[1,3,6]  R1489     -1.8084512650966644e-01
    z[1,3,6]  R1490     -2.2686289250850677e-01
    z[1,3,6]  R1491     -6.4817108213901520e-02
    z[1,3,6]  R1492     4.8896557092666626e-01
    z[1,3,6]  R1493     2.9088145494461060e-01
    z[1,3,6]  R1494     5.4765480756759644e-01
    z[1,3,6]  R1495     -0.0765218734741211
    z[1,3,6]  R1496     6.6383326053619385e-01
    z[1,3,6]  R1497     -4.8103660345077515e-01
    z[1,3,6]  R1498     -3.5973396152257919e-02
    z[1,3,6]  R1499     2.7675414457917213e-02
    z[1,3,6]  R1500     1.4806197583675385e-01
    z[1,3,6]  R1501     6.5325385332107544e-01
    z[1,3,6]  R1502     3.9939659833908081e-01
    z[1,3,6]  R1503     -3.3355975151062012e-01
    z[1,3,6]  R1504     4.4159561395645142e-01
    z[1,3,6]  R1505     -2.2576887905597687e-01
    z[1,3,6]  R1506     -5.9509657323360443e-02
    z[1,3,6]  R1507     2.3087641596794128e-01
    z[1,3,6]  R1508     1.8725031614303589e-01
    z[1,3,6]  R1509     -2.8318881988525391e-01
    z[1,3,6]  R1510     1.7644004523754120e-01
    z[1,3,6]  R1511     -1.5983033180236816e-01
    z[1,3,6]  R1512     4.8726612329483032e-01
    z[1,3,6]  R1513     0.0975242406129837
    z[1,3,6]  R1514     -4.5267440378665924e-02
    z[1,3,6]  R1515     -7.1026429533958435e-02
    z[1,3,6]  R1516     -2.5069704651832581e-01
    z[1,3,6]  R1517     -1.2107732892036438e-01
    z[1,3,6]  R1518     -1.1193778365850449e-01
    z[1,3,6]  R1519     2.6010793447494507e-01
    z[1,3,6]  R1520     -2.2518199682235718e-01
    z[1,3,6]  R1521     -1.6620095074176788e-01
    z[1,3,6]  R1522     -6.4135879278182983e-02
    z[1,3,6]  R1523     5.7532179355621338e-01
    z[1,3,6]  R1524     -4.4459655880928040e-01
    z[1,3,6]  R1525     -7.7958631515502930e-01
    z[1,3,6]  R1526     3.5826382040977478e-01
    z[1,3,6]  R1527     1.1560061015188694e-02
    z[1,3,6]  R1528     9.2273719608783722e-02
    z[1,3,6]  R1529     2.0095439627766609e-02
    z[1,3,6]  R1530     5.4892235994338989e-01
    z[1,3,6]  R1531     -2.7730929851531982e-01
    z[1,3,6]  R1532     2.7985206246376038e-01
    z[1,3,6]  R1533     -5.0994741916656494e-01
    z[1,3,6]  R1534     8.8763415813446045e-02
    z[1,3,6]  R1535     0.625530481338501
    z[1,3,6]  R1536     -1.4392854273319244e-01
    z[1,3,6]  R1537     5.0578240305185318e-02
    z[1,3,6]  R1538     -1.0098070651292801e-01
    z[1,3,6]  R1539     5.5152767896652222e-01
    z[1,3,6]  R1540     2.2399918735027313e-01
    z[1,3,6]  R1541     -4.1818860918283463e-02
    z[1,3,6]  R1542     -6.8638898432254791e-02
    z[1,3,6]  R1543     4.9629233777523041e-02
    z[1,3,6]  R1544     4.6015450358390808e-01
    z[1,3,6]  R1545     3.5267940163612366e-01
    z[1,3,6]  R1546     8.5834264755249023e-02
    z[1,3,6]  R1547     3.3901542425155640e-01
    z[1,3,6]  R1548     1.1232954263687134e-01
    z[1,3,6]  R1549     -7.5245961546897888e-02
    z[1,3,6]  R1550     -1.6824442893266678e-02
    z[1,3,6]  R1551     -3.7836784124374390e-01
    z[1,3,6]  R1552     -3.7656403146684170e-03
    z[1,3,6]  R1553     -4.0477716922760010e-01
    z[1,3,6]  R1554     0.0537756085395813
    z[1,3,6]  R1555     1.2422189861536026e-01
    z[1,3,6]  R1556     5.5422705411911011e-01
    z[1,3,6]  R1557     4.6610483527183533e-01
    z[1,3,6]  R1558     -3.2319790124893188e-01
    z[1,3,6]  R1559     -4.0369275212287903e-01
    z[1,3,6]  R1560     -3.1184107065200806e-01
    z[1,3,6]  R1561     5.3866648674011230e-01
    z[1,3,6]  R1562     -2.4914094805717468e-01
    z[1,3,6]  R1563     -2.2761613130569458e-01
    z[1,3,6]  R1564     -1.4536048471927643e-01
    z[1,3,6]  R1565     -5.7595260441303253e-02
    z[1,3,6]  R1566     0.00621609203517437
    z[1,3,6]  R1567     -3.4228414297103882e-01
    z[1,3,6]  R1568     -6.0688531398773193e-01
    z[1,3,6]  R1569     -2.4569284915924072e-01
    z[1,3,6]  R1570     -1.6450603306293488e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R1571     -1
    z[3,1,0]  R1572     1
    z[3,1,0]  R1585     2.5813335180282593e-01
    z[3,1,0]  R1586     -9.3980008363723755e-01
    z[3,1,0]  R1587     -9.2294001579284668e-01
    z[3,1,0]  R1588     5.8017861843109131e-01
    z[3,1,0]  R1589     -8.6002784967422485e-01
    z[3,1,0]  R1590     -0.892230212688446
    z[3,1,0]  R1591     -9.4262242317199707e-01
    z[3,1,0]  R1592     -9.1773474216461182e-01
    z[3,1,0]  R1593     -8.9749175310134888e-01
    z[3,1,0]  R1594     -0.83182692527771
    z[3,1,0]  R1595     5.5075997114181519e-01
    z[3,1,0]  R1596     4.8558406531810760e-02
    z[3,1,0]  R1597     2.1610417962074280e-01
    z[3,1,0]  R1598     5.7938706874847412e-01
    z[3,1,0]  R1599     1.8145748972892761e-01
    z[3,1,0]  R1600     3.6470952630043030e-01
    z[3,1,0]  R1601     3.6930146813392639e-01
    z[3,1,0]  R1602     3.9038211107254028e-01
    z[3,1,0]  R1603     2.6583820581436157e-01
    z[3,1,0]  R1604     2.2130346298217773e-01
    z[3,1,0]  R1605     4.6522235870361328e-01
    z[3,1,0]  R1606     6.5786594152450562e-01
    z[3,1,0]  R1607     4.9325266480445862e-01
    z[3,1,0]  R1608     3.5619714856147766e-01
    z[3,1,0]  R1609     5.5103158950805664e-01
    z[3,1,0]  R1610     2.9873868823051453e-01
    z[3,1,0]  R1611     -3.5717669129371643e-01
    z[3,1,0]  R1612     -2.7027529478073120e-01
    z[3,1,0]  R1613     -0.3973388671875
    z[3,1,0]  R1614     -2.8489735722541809e-01
    z[3,1,0]  R1615     6.8873858451843262e-01
    z[3,1,0]  R1616     0.576435387134552
    z[3,1,0]  R1617     -1.0018469393253326e-01
    z[3,1,0]  R1618     6.7038416862487793e-02
    z[3,1,0]  R1619     3.8674166798591614e-01
    z[3,1,0]  R1620     3.9960426092147827e-01
    z[3,1,0]  R1621     3.9525407552719116e-01
    z[3,1,0]  R1622     3.9926269650459290e-01
    z[3,1,0]  R1623     -3.9417085051536560e-01
    z[3,1,0]  R1624     5.6480592489242554e-01
    z[3,1,0]  R1625     5.3114473819732666e-01
    z[3,1,0]  R1626     -5.3321599960327148e-02
    z[3,1,0]  R1627     3.0768087506294250e-01
    z[3,1,0]  R1628     1.9263944029808044e-01
    z[3,1,0]  R1629     1.9228491187095642e-01
    z[3,1,0]  R1630     -3.8100141286849976e-01
    z[3,1,0]  R1631     5.4885959625244141e-01
    z[3,1,0]  R1632     6.0691988468170166e-01
    z[3,1,0]  R1633     -4.7804492712020874e-01
    z[3,1,0]  R1634     3.6181899905204773e-01
    z[3,1,0]  R1635     5.7915753126144409e-01
    z[3,1,0]  R1636     -1.7139646410942078e-01
    z[3,1,0]  R1637     2.4324850738048553e-01
    z[3,1,0]  R1638     2.1458587050437927e-01
    z[3,1,0]  R1639     3.3688443899154663e-01
    z[3,1,0]  R1640     -1.5396653115749359e-01
    z[3,1,0]  R1641     -3.9778491854667664e-01
    z[3,1,0]  R1642     -5.5805152654647827e-01
    z[3,1,0]  R1643     2.9693955183029175e-01
    z[3,1,0]  R1644     -3.9586779475212097e-01
    z[3,1,0]  R1645     3.9001861214637756e-01
    z[3,1,0]  R1646     -1.1424923688173294e-01
    z[3,1,0]  R1647     1.1477511376142502e-01
    z[3,1,0]  R1648     3.7824258208274841e-01
    z[3,1,0]  R1649     4.2572364211082458e-01
    z[3,1,0]  R1650     -3.0046832561492920e-01
    z[3,1,0]  R1651     -4.1631302237510681e-01
    z[3,1,0]  R1652     -2.2245289757847786e-02
    z[3,1,0]  R1653     -1.5044157207012177e-01
    z[3,1,0]  R1654     -2.3720417916774750e-01
    z[3,1,0]  R1655     -6.7189380526542664e-02
    z[3,1,0]  R1656     3.3011120557785034e-01
    z[3,1,0]  R1657     2.8113198280334473e-01
    z[3,1,0]  R1658     -2.5362789630889893e-01
    z[3,1,0]  R1659     -4.4777533411979675e-01
    z[3,1,0]  R1660     2.2559408843517303e-01
    z[3,1,0]  R1661     1.6263779997825623e-01
    z[3,1,0]  R1662     -3.0208915472030640e-01
    z[3,1,0]  R1663     -2.7314043045043945e-01
    z[3,1,0]  R1664     -3.9606195688247681e-01
    z[3,1,0]  R1665     3.0516144633293152e-01
    z[3,1,0]  R1666     -1.5908235311508179e-01
    z[3,1,0]  R1667     3.5983249545097351e-01
    z[3,1,0]  R1668     4.0131369233131409e-01
    z[3,1,0]  R1669     -3.1321954727172852e-01
    z[3,1,0]  R1670     -2.8356176614761353e-01
    z[3,1,0]  R1671     -3.0964380502700806e-01
    z[3,1,0]  R1672     -3.9614996314048767e-01
    z[3,1,0]  R1673     -1.2843808531761169e-01
    z[3,1,0]  R1674     -2.2057932615280151e-01
    z[3,1,0]  R1675     3.3207225799560547e-01
    z[3,1,0]  R1676     2.2497600317001343e-01
    z[3,1,0]  R1677     4.0429782867431641e-01
    z[3,1,0]  R1678     1.1020505428314209e-01
    z[3,1,0]  R1679     3.3701881766319275e-01
    z[3,1,0]  R1680     0.297879159450531
    z[3,1,0]  R1681     3.9452165365219116e-01
    z[3,1,0]  R1682     2.0356547832489014e-01
    z[3,1,0]  R1683     -2.6331812143325806e-01
    z[3,1,0]  R1684     3.1959950923919678e-01
    z[3,1,0]  R1685     5.9074461460113525e-01
    z[3,1,0]  R1686     -4.1275955736637115e-02
    z[3,1,0]  R1687     -3.7504187226295471e-01
    z[3,1,0]  R1688     -5.7928526401519775e-01
    z[3,1,0]  R1689     -4.9910187721252441e-01
    z[3,1,0]  R1690     -6.3219177722930908e-01
    z[3,1,0]  R1691     -3.9742922782897949e-01
    z[3,1,0]  R1692     2.3084011673927307e-01
    z[3,1,0]  R1693     -9.3423920869827271e-01
    z[3,1,0]  R1694     -9.2440533638000488e-01
    z[3,1,0]  R1695     2.1656617522239685e-01
    z[3,1,0]  R1696     1.9144825637340546e-02
    z[3,1,0]  R1697     -5.2586293220520020e-01
    z[3,1,0]  R1698     3.0178827047348022e-01
    z[3,1,0]  R1699     2.0443785190582275e-01
    z[3,1,0]  R1700     -1.7751251161098480e-01
    z[3,1,0]  R1701     5.6899610906839371e-02
    z[3,1,0]  R1702     1.6422684490680695e-01
    z[3,1,0]  R1703     2.9473572969436646e-01
    z[3,1,0]  R1704     -6.5723603963851929e-01
    z[3,1,0]  R1705     9.5317848026752472e-02
    z[3,1,0]  R1706     -5.1086451858282089e-02
    z[3,1,0]  R1707     -2.1587809920310974e-01
    z[3,1,0]  R1708     7.7477765083312988e-01
    z[3,1,0]  R1709     7.0630115270614624e-01
    z[3,1,0]  R1710     5.0864154100418091e-01
    z[3,1,0]  R1711     5.3289115428924561e-01
    z[3,1,0]  R1712     3.1803345680236816e-01
    z[3,1,0]  R1713     -4.4739622622728348e-02
    z[3,1,0]  R1714     -5.8397495746612549e-01
    z[3,1,0]  R1715     -5.5687215179204941e-02
    z[3,1,0]  R1716     8.9335137605667114e-01
    z[3,1,0]  R1717     -1.7038933932781219e-01
    z[3,1,0]  R1718     -3.7038710713386536e-01
    z[3,1,0]  R1719     -6.0038655996322632e-01
    z[3,1,0]  R1720     4.6409547328948975e-01
    z[3,1,0]  R1721     4.3099871277809143e-01
    z[3,1,0]  R1722     4.7354349493980408e-01
    z[3,1,0]  R1723     4.6459159255027771e-01
    z[3,1,0]  R1724     4.6672913432121277e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R1573     -1
    z[3,1,1]  R1574     1
    z[3,1,1]  R1585     4.5794308185577393e-01
    z[3,1,1]  R1586     1.5471121668815613e-01
    z[3,1,1]  R1587     1.6253520548343658e-01
    z[3,1,1]  R1588     5.4190081357955933e-01
    z[3,1,1]  R1589     1.8640153110027313e-01
    z[3,1,1]  R1590     0.0975256860256195
    z[3,1,1]  R1591     -9.9438624456524849e-03
    z[3,1,1]  R1592     2.0124214887619019e-01
    z[3,1,1]  R1593     2.0787183940410614e-01
    z[3,1,1]  R1594     2.8012225031852722e-01
    z[3,1,1]  R1595     4.9174398183822632e-01
    z[3,1,1]  R1596     5.9860908985137939e-01
    z[3,1,1]  R1597     5.6498810648918152e-02
    z[3,1,1]  R1598     1.5831539034843445e-01
    z[3,1,1]  R1599     2.6287177205085754e-01
    z[3,1,1]  R1600     1.3917708396911621e-01
    z[3,1,1]  R1601     -3.7313610315322876e-02
    z[3,1,1]  R1602     -6.4909934997558594e-01
    z[3,1,1]  R1603     -6.3023924827575684e-01
    z[3,1,1]  R1604     -0.601081371307373
    z[3,1,1]  R1605     4.8583567142486572e-01
    z[3,1,1]  R1606     1.6910223662853241e-01
    z[3,1,1]  R1607     3.8512364029884338e-01
    z[3,1,1]  R1608     -2.4250841140747070e-01
    z[3,1,1]  R1609     2.0148472487926483e-01
    z[3,1,1]  R1610     5.6375807523727417e-01
    z[3,1,1]  R1611     -8.8710987567901611e-01
    z[3,1,1]  R1612     -8.7936633825302124e-01
    z[3,1,1]  R1613     -8.4518057107925415e-01
    z[3,1,1]  R1614     -8.9767938852310181e-01
    z[3,1,1]  R1615     3.1527695059776306e-01
    z[3,1,1]  R1616     1.0131421685218811e-01
    z[3,1,1]  R1617     6.2148368358612061e-01
    z[3,1,1]  R1618     6.3854932785034180e-01
    z[3,1,1]  R1619     -7.8269565105438232e-01
    z[3,1,1]  R1620     -7.5086838006973267e-01
    z[3,1,1]  R1621     -7.9141962528228760e-01
    z[3,1,1]  R1622     -8.3746296167373657e-01
    z[3,1,1]  R1623     -5.1557046175003052e-01
    z[3,1,1]  R1624     -6.1647754907608032e-01
    z[3,1,1]  R1625     3.2905480265617371e-01
    z[3,1,1]  R1626     9.5572900772094727e-01
    z[3,1,1]  R1627     3.0548056960105896e-01
    z[3,1,1]  R1628     1.9497880339622498e-01
    z[3,1,1]  R1629     5.1851749420166016e-01
    z[3,1,1]  R1630     6.3300591707229614e-01
    z[3,1,1]  R1631     -0.712550163269043
    z[3,1,1]  R1632     -7.5988835096359253e-01
    z[3,1,1]  R1633     -7.4890685081481934e-01
    z[3,1,1]  R1634     -6.0639894008636475e-01
    z[3,1,1]  R1635     6.6063940525054932e-01
    z[3,1,1]  R1636     7.8202486038208008e-01
    z[3,1,1]  R1637     1.7261256277561188e-01
    z[3,1,1]  R1638     -2.3551419377326965e-01
    z[3,1,1]  R1639     -2.0627915859222412e-01
    z[3,1,1]  R1640     -9.0729838609695435e-01
    z[3,1,1]  R1641     -8.2229351997375488e-01
    z[3,1,1]  R1642     -7.3243695497512817e-01
    z[3,1,1]  R1643     -5.0932437181472778e-01
    z[3,1,1]  R1644     -5.9857684373855591e-01
    z[3,1,1]  R1645     -1.8179433420300484e-02
    z[3,1,1]  R1646     8.6025208234786987e-01
    z[3,1,1]  R1647     4.1180285811424255e-01
    z[3,1,1]  R1648     -6.7911714315414429e-01
    z[3,1,1]  R1649     -6.1638671159744263e-01
    z[3,1,1]  R1650     -8.4821528196334839e-01
    z[3,1,1]  R1651     -6.9856476783752441e-01
    z[3,1,1]  R1652     -8.9396846294403076e-01
    z[3,1,1]  R1653     -8.1388109922409058e-01
    z[3,1,1]  R1654     -8.0397886037826538e-01
    z[3,1,1]  R1655     1.1819742619991302e-02
    z[3,1,1]  R1656     -7.3750841617584229e-01
    z[3,1,1]  R1657     -5.9825807809829712e-01
    z[3,1,1]  R1658     -0.844097912311554
    z[3,1,1]  R1659     -5.0424879789352417e-01
    z[3,1,1]  R1660     -6.4740163087844849e-01
    z[3,1,1]  R1661     -4.7776961326599121e-01
    z[3,1,1]  R1662     -5.2313446998596191e-01
    z[3,1,1]  R1663     -7.1146863698959351e-01
    z[3,1,1]  R1664     -0.487781286239624
    z[3,1,1]  R1665     1.2014646083116531e-02
    z[3,1,1]  R1666     6.5612250566482544e-01
    z[3,1,1]  R1667     -6.7768466472625732e-01
    z[3,1,1]  R1668     -7.2295677661895752e-01
    z[3,1,1]  R1669     -8.6170834302902222e-01
    z[3,1,1]  R1670     -0.867425799369812
    z[3,1,1]  R1671     -4.6951338648796082e-01
    z[3,1,1]  R1672     -4.7382223606109619e-01
    z[3,1,1]  R1673     -9.8977647721767426e-02
    z[3,1,1]  R1674     -2.1678347885608673e-01
    z[3,1,1]  R1675     -8.4220498800277710e-02
    z[3,1,1]  R1676     0.361508309841156
    z[3,1,1]  R1677     4.8457989096641541e-01
    z[3,1,1]  R1678     -3.2911914587020874e-01
    z[3,1,1]  R1679     3.3398628234863281e-01
    z[3,1,1]  R1680     -4.8228830099105835e-01
    z[3,1,1]  R1681     -1.9169540703296661e-01
    z[3,1,1]  R1682     2.1775195002555847e-01
    z[3,1,1]  R1683     -2.4984495341777802e-01
    z[3,1,1]  R1684     2.1840962767601013e-01
    z[3,1,1]  R1685     3.6695379018783569e-01
    z[3,1,1]  R1686     6.5316796302795410e-01
    z[3,1,1]  R1687     0.657727062702179
    z[3,1,1]  R1688     6.4585006237030029e-01
    z[3,1,1]  R1689     7.4338763952255249e-01
    z[3,1,1]  R1690     7.0508313179016113e-01
    z[3,1,1]  R1691     7.9247128963470459e-01
    z[3,1,1]  R1692     8.2078307867050171e-01
    z[3,1,1]  R1693     3.3597180247306824e-01
    z[3,1,1]  R1694     3.2437753677368164e-01
    z[3,1,1]  R1695     8.7639510631561279e-01
    z[3,1,1]  R1696     0.31130251288414
    z[3,1,1]  R1697     -4.1803106665611267e-01
    z[3,1,1]  R1698     1.0529877245426178e-01
    z[3,1,1]  R1699     1.0849340260028839e-01
    z[3,1,1]  R1700     2.3467201739549637e-02
    z[3,1,1]  R1701     -2.1112029254436493e-01
    z[3,1,1]  R1702     1.6639775037765503e-01
    z[3,1,1]  R1703     -6.7488527856767178e-03
    z[3,1,1]  R1704     -6.3168264925479889e-02
    z[3,1,1]  R1705     0.547184944152832
    z[3,1,1]  R1706     1.0742236673831940e-01
    z[3,1,1]  R1707     0.407914936542511
    z[3,1,1]  R1708     4.4724959135055542e-01
    z[3,1,1]  R1709     3.4217163920402527e-01
    z[3,1,1]  R1710     1.4415302872657776e-01
    z[3,1,1]  R1711     3.5020154714584351e-01
    z[3,1,1]  R1712     3.6574858427047729e-01
    z[3,1,1]  R1713     -4.1784530878067017e-01
    z[3,1,1]  R1714     -3.3625042438507080e-01
    z[3,1,1]  R1715     8.6969435214996338e-01
    z[3,1,1]  R1716     8.6631134152412415e-02
    z[3,1,1]  R1717     1.4700804650783539e-01
    z[3,1,1]  R1718     -3.5427924990653992e-01
    z[3,1,1]  R1719     -6.7064750194549561e-01
    z[3,1,1]  R1720     -7.4182587862014771e-01
    z[3,1,1]  R1721     -7.4127340316772461e-01
    z[3,1,1]  R1722     -7.2319769859313965e-01
    z[3,1,1]  R1723     -7.1683096885681152e-01
    z[3,1,1]  R1724     -6.9388502836227417e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R1575     -1
    z[3,1,2]  R1576     1
    z[3,1,2]  R1585     4.7317445278167725e-01
    z[3,1,2]  R1586     -7.1036987006664276e-02
    z[3,1,2]  R1587     3.9349254220724106e-03
    z[3,1,2]  R1588     6.0475575923919678e-01
    z[3,1,2]  R1589     -1.0655601322650909e-01
    z[3,1,2]  R1590     1.0289722681045532e-01
    z[3,1,2]  R1591     -1.4623812399804592e-02
    z[3,1,2]  R1592     -1.1547831445932388e-01
    z[3,1,2]  R1593     2.7077925205230713e-01
    z[3,1,2]  R1594     3.0057525634765625e-01
    z[3,1,2]  R1595     -6.0011076927185059e-01
    z[3,1,2]  R1596     -2.8771796822547913e-01
    z[3,1,2]  R1597     -0.17482890188694
    z[3,1,2]  R1598     5.7021718472242355e-02
    z[3,1,2]  R1599     -2.6236066222190857e-01
    z[3,1,2]  R1600     -2.7732434868812561e-01
    z[3,1,2]  R1601     -5.6132465600967407e-02
    z[3,1,2]  R1602     2.5654694437980652e-01
    z[3,1,2]  R1603     -2.4898232519626617e-01
    z[3,1,2]  R1604     -4.8615369945764542e-02
    z[3,1,2]  R1605     -2.3697596788406372e-01
    z[3,1,2]  R1606     0.478730708360672
    z[3,1,2]  R1607     1.1790613085031509e-01
    z[3,1,2]  R1608     1.5007908223196864e-03
    z[3,1,2]  R1609     -3.0414253473281860e-01
    z[3,1,2]  R1610     -4.6622648835182190e-01
    z[3,1,2]  R1611     1.2217401713132858e-01
    z[3,1,2]  R1612     -7.3766350746154785e-02
    z[3,1,2]  R1613     8.6302056908607483e-02
    z[3,1,2]  R1614     7.0185407996177673e-02
    z[3,1,2]  R1615     -1.1465033888816833e-01
    z[3,1,2]  R1616     -1.8005770444869995e-01
    z[3,1,2]  R1617     2.2961066663265228e-01
    z[3,1,2]  R1618     -5.6701207160949707e-01
    z[3,1,2]  R1619     -7.0753586478531361e-03
    z[3,1,2]  R1620     -4.2569848895072937e-01
    z[3,1,2]  R1621     3.8507454097270966e-02
    z[3,1,2]  R1622     -2.1936345100402832e-01
    z[3,1,2]  R1623     -4.4113822281360626e-02
    z[3,1,2]  R1624     -2.9070353507995605e-01
    z[3,1,2]  R1625     3.1474274396896362e-01
    z[3,1,2]  R1626     -1.3277991116046906e-01
    z[3,1,2]  R1627     -2.0039129257202148e-01
    z[3,1,2]  R1628     3.3667656779289246e-01
    z[3,1,2]  R1629     9.5063023269176483e-02
    z[3,1,2]  R1630     1.8678675591945648e-01
    z[3,1,2]  R1631     -1.5000531077384949e-01
    z[3,1,2]  R1632     1.4589686691761017e-01
    z[3,1,2]  R1633     -1.3811717927455902e-01
    z[3,1,2]  R1634     -3.2649955153465271e-01
    z[3,1,2]  R1635     -7.7538035809993744e-02
    z[3,1,2]  R1636     2.7904254198074341e-01
    z[3,1,2]  R1637     4.6756044030189514e-01
    z[3,1,2]  R1638     5.8996933698654175e-01
    z[3,1,2]  R1639     3.0695015192031860e-01
    z[3,1,2]  R1640     -8.3865828812122345e-02
    z[3,1,2]  R1641     -0.201654851436615
    z[3,1,2]  R1642     2.3760262876749039e-02
    z[3,1,2]  R1643     1.9889634847640991e-01
    z[3,1,2]  R1644     -4.1506299376487732e-01
    z[3,1,2]  R1645     1.5373519062995911e-01
    z[3,1,2]  R1646     6.0239702463150024e-02
    z[3,1,2]  R1647     -2.5170063972473145e-01
    z[3,1,2]  R1648     -3.9540448784828186e-01
    z[3,1,2]  R1649     1.8756791949272156e-01
    z[3,1,2]  R1650     -1.8159843981266022e-01
    z[3,1,2]  R1651     -1.4692538976669312e-01
    z[3,1,2]  R1652     2.8810954093933105e-01
    z[3,1,2]  R1653     0.518994152545929
    z[3,1,2]  R1654     -7.1790322661399841e-02
    z[3,1,2]  R1655     2.0671610534191132e-01
    z[3,1,2]  R1656     -2.9173594713211060e-01
    z[3,1,2]  R1657     -2.5543960928916931e-01
    z[3,1,2]  R1658     -2.7297517657279968e-01
    z[3,1,2]  R1659     -4.6042707562446594e-01
    z[3,1,2]  R1660     1.2205547094345093e-01
    z[3,1,2]  R1661     -1.7233356833457947e-01
    z[3,1,2]  R1662     -0.463856041431427
    z[3,1,2]  R1663     -0.343553364276886
    z[3,1,2]  R1664     -5.5767357349395752e-01
    z[3,1,2]  R1665     2.7804297208786011e-01
    z[3,1,2]  R1666     -6.2095586210489273e-02
    z[3,1,2]  R1667     -2.0334620773792267e-01
    z[3,1,2]  R1668     -4.3719375133514404e-01
    z[3,1,2]  R1669     -3.4538358449935913e-01
    z[3,1,2]  R1670     2.2523038089275360e-01
    z[3,1,2]  R1671     -1.1186144500970840e-01
    z[3,1,2]  R1672     -2.3457500338554382e-01
    z[3,1,2]  R1673     -3.6460712552070618e-01
    z[3,1,2]  R1674     -7.4643462896347046e-01
    z[3,1,2]  R1675     7.9628866910934448e-01
    z[3,1,2]  R1676     6.2952286005020142e-01
    z[3,1,2]  R1677     2.3803453147411346e-01
    z[3,1,2]  R1678     3.5012251138687134e-01
    z[3,1,2]  R1679     1.6661569476127625e-01
    z[3,1,2]  R1680     3.0057954788208008e-01
    z[3,1,2]  R1681     -7.2683282196521759e-02
    z[3,1,2]  R1682     -2.0050784945487976e-01
    z[3,1,2]  R1683     5.0285577774047852e-01
    z[3,1,2]  R1684     0.00567758409306407
    z[3,1,2]  R1685     -2.1179307997226715e-01
    z[3,1,2]  R1686     -5.8393353223800659e-01
    z[3,1,2]  R1687     -4.0201231837272644e-01
    z[3,1,2]  R1688     -3.8458973169326782e-01
    z[3,1,2]  R1689     4.2064037173986435e-02
    z[3,1,2]  R1690     -2.8824952244758606e-01
    z[3,1,2]  R1691     -2.4844953417778015e-01
    z[3,1,2]  R1692     -1.5014594793319702e-01
    z[3,1,2]  R1693     -3.6241721361875534e-02
    z[3,1,2]  R1694     1.1564271897077560e-01
    z[3,1,2]  R1695     1.7821869254112244e-01
    z[3,1,2]  R1696     -2.7339941263198853e-01
    z[3,1,2]  R1697     -6.2284684181213379e-01
    z[3,1,2]  R1698     9.8502419888973236e-02
    z[3,1,2]  R1699     -8.4907189011573792e-02
    z[3,1,2]  R1700     -3.7734252214431763e-01
    z[3,1,2]  R1701     1.1531513929367065e-01
    z[3,1,2]  R1702     -3.3423385024070740e-01
    z[3,1,2]  R1703     6.3833691179752350e-02
    z[3,1,2]  R1704     -3.4744244813919067e-01
    z[3,1,2]  R1705     -3.5237598419189453e-01
    z[3,1,2]  R1706     1.0244900733232498e-01
    z[3,1,2]  R1707     -7.7153556048870087e-02
    z[3,1,2]  R1708     -1.8872264027595520e-01
    z[3,1,2]  R1709     -5.5572193115949631e-02
    z[3,1,2]  R1710     7.1593075990676880e-02
    z[3,1,2]  R1711     1.0369773954153061e-02
    z[3,1,2]  R1712     -8.3991587162017822e-02
    z[3,1,2]  R1713     9.6030756831169128e-03
    z[3,1,2]  R1714     -3.5265704989433289e-01
    z[3,1,2]  R1715     -2.3279662430286407e-01
    z[3,1,2]  R1716     2.2210830822587013e-02
    z[3,1,2]  R1717     1.0618493705987930e-01
    z[3,1,2]  R1718     -1.7527283728122711e-01
    z[3,1,2]  R1719     3.4023147821426392e-01
    z[3,1,2]  R1720     -3.2223331928253174e-01
    z[3,1,2]  R1721     -1.6301706433296204e-01
    z[3,1,2]  R1722     -1.1810306459665298e-01
    z[3,1,2]  R1723     -2.4931703507900238e-01
    z[3,1,2]  R1724     -0.291786253452301
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R1577     -1
    z[3,1,3]  R1578     1
    z[3,1,3]  R1585     -3.7363407015800476e-01
    z[3,1,3]  R1586     -2.3972152173519135e-01
    z[3,1,3]  R1587     -1.9779071211814880e-01
    z[3,1,3]  R1588     -7.7056130394339561e-03
    z[3,1,3]  R1589     -2.0588600635528564e-01
    z[3,1,3]  R1590     3.0438458546996117e-02
    z[3,1,3]  R1591     -8.3044849336147308e-02
    z[3,1,3]  R1592     2.4156817793846130e-01
    z[3,1,3]  R1593     9.3204446136951447e-02
    z[3,1,3]  R1594     -1.8220625817775726e-01
    z[3,1,3]  R1595     -2.1709744632244110e-01
    z[3,1,3]  R1596     4.2003658413887024e-01
    z[3,1,3]  R1597     -6.1917316913604736e-01
    z[3,1,3]  R1598     -2.4185305833816528e-01
    z[3,1,3]  R1599     -4.7418147325515747e-01
    z[3,1,3]  R1600     -3.5897254943847656e-01
    z[3,1,3]  R1601     -6.7649924755096436e-01
    z[3,1,3]  R1602     5.8192396163940430e-01
    z[3,1,3]  R1603     5.5674391984939575e-01
    z[3,1,3]  R1604     6.7789024114608765e-01
    z[3,1,3]  R1605     -1.2351523339748383e-01
    z[3,1,3]  R1606     -3.7697765231132507e-01
    z[3,1,3]  R1607     -3.9568236470222473e-01
    z[3,1,3]  R1608     -4.5480468869209290e-01
    z[3,1,3]  R1609     -1.4198586344718933e-01
    z[3,1,3]  R1610     -3.2391302287578583e-02
    z[3,1,3]  R1611     -7.1297824382781982e-02
    z[3,1,3]  R1612     -1.7052255570888519e-01
    z[3,1,3]  R1613     -1.3055598735809326e-01
    z[3,1,3]  R1614     1.0369133204221725e-01
    z[3,1,3]  R1615     -5.6572878360748291e-01
    z[3,1,3]  R1616     -6.1591309309005737e-01
    z[3,1,3]  R1617     6.7653483152389526e-01
    z[3,1,3]  R1618     -1.1923617124557495e-01
    z[3,1,3]  R1619     3.2390314340591431e-01
    z[3,1,3]  R1620     3.9310574531555176e-02
    z[3,1,3]  R1621     1.3593333959579468e-01
    z[3,1,3]  R1622     -1.6196319460868835e-01
    z[3,1,3]  R1623     5.8970528841018677e-01
    z[3,1,3]  R1624     3.8669671863317490e-02
    z[3,1,3]  R1625     -1.9893029239028692e-03
    z[3,1,3]  R1626     1.4506794512271881e-01
    z[3,1,3]  R1627     -2.7058762311935425e-01
    z[3,1,3]  R1628     -5.8655035495758057e-01
    z[3,1,3]  R1629     -4.3224066495895386e-02
    z[3,1,3]  R1630     3.6754816770553589e-01
    z[3,1,3]  R1631     3.5326120257377625e-01
    z[3,1,3]  R1632     2.2708898410201073e-02
    z[3,1,3]  R1633     2.7809518575668335e-01
    z[3,1,3]  R1634     2.4823831021785736e-01
    z[3,1,3]  R1635     -2.7817955613136292e-01
    z[3,1,3]  R1636     -3.7966978549957275e-01
    z[3,1,3]  R1637     -5.1656246185302734e-01
    z[3,1,3]  R1638     -7.2383642196655273e-01
    z[3,1,3]  R1639     -4.3253010511398315e-01
    z[3,1,3]  R1640     -3.0411076545715332e-01
    z[3,1,3]  R1641     -5.1381520926952362e-02
    z[3,1,3]  R1642     2.3650184273719788e-01
    z[3,1,3]  R1643     5.2529340982437134e-01
    z[3,1,3]  R1644     2.6098170876502991e-01
    z[3,1,3]  R1645     -7.0872771739959717e-01
    z[3,1,3]  R1646     2.3492148146033287e-02
    z[3,1,3]  R1647     -5.7568907737731934e-01
    z[3,1,3]  R1648     2.0097626373171806e-02
    z[3,1,3]  R1649     3.1200775504112244e-01
    z[3,1,3]  R1650     -3.1716406345367432e-01
    z[3,1,3]  R1651     0.325791597366333
    z[3,1,3]  R1652     -1.7388641834259033e-01
    z[3,1,3]  R1653     -3.3776730298995972e-02
    z[3,1,3]  R1654     -9.5977261662483215e-02
    z[3,1,3]  R1655     -7.8665858507156372e-01
    z[3,1,3]  R1656     3.5539820790290833e-01
    z[3,1,3]  R1657     5.0124150514602661e-01
    z[3,1,3]  R1658     -1.1464725248515606e-02
    z[3,1,3]  R1659     4.6107214689254761e-01
    z[3,1,3]  R1660     4.3256533145904541e-01
    z[3,1,3]  R1661     6.0782027244567871e-01
    z[3,1,3]  R1662     1.7142720520496368e-01
    z[3,1,3]  R1663     3.2900744676589966e-01
    z[3,1,3]  R1664     -7.7450558543205261e-02
    z[3,1,3]  R1665     -6.4688611030578613e-01
    z[3,1,3]  R1666     3.6693942546844482e-01
    z[3,1,3]  R1667     0.519483745098114
    z[3,1,3]  R1668     5.1869828253984451e-02
    z[3,1,3]  R1669     1.3376979529857635e-01
    z[3,1,3]  R1670     1.4833371341228485e-01
    z[3,1,3]  R1671     4.6653857827186584e-01
    z[3,1,3]  R1672     1.1839896440505981e-01
    z[3,1,3]  R1673     6.3796001672744751e-01
    z[3,1,3]  R1674     2.9312953352928162e-01
    z[3,1,3]  R1675     -1.0823883116245270e-01
    z[3,1,3]  R1676     0.356587290763855
    z[3,1,3]  R1677     6.0027605295181274e-01
    z[3,1,3]  R1678     5.1075166463851929e-01
    z[3,1,3]  R1679     5.3740882873535156e-01
    z[3,1,3]  R1680     1.0916360467672348e-01
    z[3,1,3]  R1681     4.9610521644353867e-02
    z[3,1,3]  R1682     2.6247090101242065e-01
    z[3,1,3]  R1683     3.9771571755409241e-01
    z[3,1,3]  R1684     4.4433519244194031e-01
    z[3,1,3]  R1685     2.9319867491722107e-01
    z[3,1,3]  R1686     -1.5360046923160553e-01
    z[3,1,3]  R1687     -2.7590749785304070e-02
    z[3,1,3]  R1688     2.2711518406867981e-01
    z[3,1,3]  R1689     -1.6082301735877991e-01
    z[3,1,3]  R1690     -6.8718180060386658e-02
    z[3,1,3]  R1691     3.1026366353034973e-01
    z[3,1,3]  R1692     -5.8440599590539932e-02
    z[3,1,3]  R1693     -4.1871690191328526e-03
    z[3,1,3]  R1694     -4.1127860546112061e-02
    z[3,1,3]  R1695     -3.3243077993392944e-01
    z[3,1,3]  R1696     -6.8526461720466614e-02
    z[3,1,3]  R1697     -8.7724313139915466e-02
    z[3,1,3]  R1698     -3.5257175564765930e-01
    z[3,1,3]  R1699     -2.9554140567779541e-01
    z[3,1,3]  R1700     -2.9453948140144348e-01
    z[3,1,3]  R1701     -3.3523476123809814e-01
    z[3,1,3]  R1702     -3.7054210901260376e-01
    z[3,1,3]  R1703     -4.7129637002944946e-01
    z[3,1,3]  R1704     -3.0005259439349174e-02
    z[3,1,3]  R1705     -3.7874984741210938e-01
    z[3,1,3]  R1706     9.7439870238304138e-02
    z[3,1,3]  R1707     -3.0197608470916748e-01
    z[3,1,3]  R1708     -2.0218986272811890e-01
    z[3,1,3]  R1709     -1.5474145114421844e-01
    z[3,1,3]  R1710     -4.0473595261573792e-02
    z[3,1,3]  R1711     9.7739197313785553e-02
    z[3,1,3]  R1712     -2.5048962235450745e-01
    z[3,1,3]  R1713     -3.2698279619216919e-01
    z[3,1,3]  R1714     -2.5443577766418457e-01
    z[3,1,3]  R1715     -1.5198162198066711e-01
    z[3,1,3]  R1716     -3.0203291773796082e-01
    z[3,1,3]  R1717     -3.0847027897834778e-01
    z[3,1,3]  R1718     -3.9656361937522888e-01
    z[3,1,3]  R1719     -9.1805262491106987e-03
    z[3,1,3]  R1720     -1.6141927242279053e-01
    z[3,1,3]  R1721     -2.9566857218742371e-01
    z[3,1,3]  R1722     -1.8786433339118958e-01
    z[3,1,3]  R1723     -3.1983304023742676e-01
    z[3,1,3]  R1724     1.8618069589138031e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R1579     -1
    z[3,1,4]  R1580     1
    z[3,1,4]  R1585     3.4899908304214478e-01
    z[3,1,4]  R1586     1.3045790791511536e-01
    z[3,1,4]  R1587     6.4899399876594543e-02
    z[3,1,4]  R1588     5.2281104028224945e-02
    z[3,1,4]  R1589     -2.7794393897056580e-01
    z[3,1,4]  R1590     -4.3862383812665939e-02
    z[3,1,4]  R1591     -3.0529299378395081e-01
    z[3,1,4]  R1592     -0.0504038967192173
    z[3,1,4]  R1593     1.9112777709960938e-01
    z[3,1,4]  R1594     -4.1402861475944519e-02
    z[3,1,4]  R1595     -3.5263508558273315e-02
    z[3,1,4]  R1596     2.8810936212539673e-01
    z[3,1,4]  R1597     -6.4258921146392822e-01
    z[3,1,4]  R1598     -5.0122499465942383e-01
    z[3,1,4]  R1599     -7.5447636842727661e-01
    z[3,1,4]  R1600     -4.3736043572425842e-01
    z[3,1,4]  R1601     -2.8554555773735046e-01
    z[3,1,4]  R1602     -1.3387228548526764e-01
    z[3,1,4]  R1603     3.9674103260040283e-01
    z[3,1,4]  R1604     -1.8834735453128815e-01
    z[3,1,4]  R1605     1.6314629465341568e-02
    z[3,1,4]  R1606     3.4935045987367630e-02
    z[3,1,4]  R1607     -5.6127011775970459e-01
    z[3,1,4]  R1608     6.2418907880783081e-01
    z[3,1,4]  R1609     0.508728563785553
    z[3,1,4]  R1610     5.9628438949584961e-01
    z[3,1,4]  R1611     -9.6647582948207855e-02
    z[3,1,4]  R1612     -2.8975948691368103e-01
    z[3,1,4]  R1613     -1.2747314572334290e-01
    z[3,1,4]  R1614     2.3188865184783936e-01
    z[3,1,4]  R1615     -6.5716892480850220e-02
    z[3,1,4]  R1616     8.0855533480644226e-02
    z[3,1,4]  R1617     -3.2234955579042435e-02
    z[3,1,4]  R1618     -2.5378465652465820e-01
    z[3,1,4]  R1619     2.8136804699897766e-01
    z[3,1,4]  R1620     -1.0198257118463516e-01
    z[3,1,4]  R1621     -1.1463674902915955e-01
    z[3,1,4]  R1622     1.7112898826599121e-01
    z[3,1,4]  R1623     -2.5380682945251465e-01
    z[3,1,4]  R1624     9.4268575310707092e-02
    z[3,1,4]  R1625     6.5625023841857910e-01
    z[3,1,4]  R1626     -1.6640214622020721e-01
    z[3,1,4]  R1627     5.1289498805999756e-01
    z[3,1,4]  R1628     -4.8925641179084778e-01
    z[3,1,4]  R1629     2.7319782972335815e-01
    z[3,1,4]  R1630     2.0046363770961761e-01
    z[3,1,4]  R1631     -1.7939563095569611e-01
    z[3,1,4]  R1632     7.3708340525627136e-02
    z[3,1,4]  R1633     -2.0611342787742615e-01
    z[3,1,4]  R1634     1.1279787868261337e-01
    z[3,1,4]  R1635     2.5928923487663269e-01
    z[3,1,4]  R1636     1.6672702133655548e-01
    z[3,1,4]  R1637     -4.0130406618118286e-01
    z[3,1,4]  R1638     -5.1522977650165558e-02
    z[3,1,4]  R1639     4.1288143396377563e-01
    z[3,1,4]  R1640     -8.2583807408809662e-02
    z[3,1,4]  R1641     8.4618858993053436e-02
    z[3,1,4]  R1642     1.7774626612663269e-01
    z[3,1,4]  R1643     2.6971861720085144e-02
    z[3,1,4]  R1644     3.5232746601104736e-01
    z[3,1,4]  R1645     5.6551039218902588e-01
    z[3,1,4]  R1646     1.7291894555091858e-01
    z[3,1,4]  R1647     -3.7263345718383789e-01
    z[3,1,4]  R1648     -1.6487531363964081e-01
    z[3,1,4]  R1649     -3.3342546224594116e-01
    z[3,1,4]  R1650     2.2124059498310089e-01
    z[3,1,4]  R1651     1.4005471765995026e-01
    z[3,1,4]  R1652     2.7248656749725342e-01
    z[3,1,4]  R1653     -3.3528175204992294e-02
    z[3,1,4]  R1654     1.4610594511032104e-01
    z[3,1,4]  R1655     -1.8471702933311462e-02
    z[3,1,4]  R1656     -7.2325021028518677e-02
    z[3,1,4]  R1657     -2.2511104121804237e-02
    z[3,1,4]  R1658     1.9403712451457977e-01
    z[3,1,4]  R1659     1.2670768797397614e-01
    z[3,1,4]  R1660     -0.0792994499206543
    z[3,1,4]  R1661     -2.1422253549098969e-01
    z[3,1,4]  R1662     2.0323148369789124e-01
    z[3,1,4]  R1663     1.4503178000450134e-01
    z[3,1,4]  R1664     -3.4546792507171631e-01
    z[3,1,4]  R1665     -1.3877657055854797e-01
    z[3,1,4]  R1666     4.0217930078506470e-01
    z[3,1,4]  R1667     -3.1700424849987030e-02
    z[3,1,4]  R1668     2.9526901245117188e-01
    z[3,1,4]  R1669     -5.3333666175603867e-02
    z[3,1,4]  R1670     1.0146160423755646e-01
    z[3,1,4]  R1671     -1.7991612851619720e-01
    z[3,1,4]  R1672     -1.6010677814483643e-01
    z[3,1,4]  R1673     -3.0307593941688538e-01
    z[3,1,4]  R1674     -2.7151322364807129e-01
    z[3,1,4]  R1675     1.4760370831936598e-03
    z[3,1,4]  R1676     4.1524812579154968e-02
    z[3,1,4]  R1677     -2.6050312444567680e-02
    z[3,1,4]  R1678     5.8437857776880264e-02
    z[3,1,4]  R1679     -1.7981484532356262e-01
    z[3,1,4]  R1680     -7.4437371222302318e-04
    z[3,1,4]  R1681     2.3300166428089142e-01
    z[3,1,4]  R1682     2.0796832442283630e-01
    z[3,1,4]  R1683     1.1065878719091415e-01
    z[3,1,4]  R1684     2.0427180826663971e-01
    z[3,1,4]  R1685     1.6974899172782898e-01
    z[3,1,4]  R1686     -4.4538193941116333e-01
    z[3,1,4]  R1687     -3.1974750757217407e-01
    z[3,1,4]  R1688     -1.9922609627246857e-01
    z[3,1,4]  R1689     -2.7087783813476562e-01
    z[3,1,4]  R1690     2.0275993272662163e-02
    z[3,1,4]  R1691     1.0352526605129242e-01
    z[3,1,4]  R1692     -1.5411649644374847e-01
    z[3,1,4]  R1693     -9.2224171385169029e-03
    z[3,1,4]  R1694     1.1496607959270477e-01
    z[3,1,4]  R1695     1.1724268645048141e-01
    z[3,1,4]  R1696     8.7437534332275391e-01
    z[3,1,4]  R1697     -1.4307887852191925e-01
    z[3,1,4]  R1698     8.4778529405593872e-01
    z[3,1,4]  R1699     5.1797825098037720e-01
    z[3,1,4]  R1700     7.7364194393157959e-01
    z[3,1,4]  R1701     8.4896445274353027e-01
    z[3,1,4]  R1702     0.667140781879425
    z[3,1,4]  R1703     6.5066725015640259e-01
    z[3,1,4]  R1704     -2.4185539782047272e-01
    z[3,1,4]  R1705     -8.3446763455867767e-02
    z[3,1,4]  R1706     8.9992147684097290e-01
    z[3,1,4]  R1707     -2.5832799077033997e-01
    z[3,1,4]  R1708     1.7638940364122391e-02
    z[3,1,4]  R1709     -4.6297335624694824e-01
    z[3,1,4]  R1710     -7.9953235387802124e-01
    z[3,1,4]  R1711     -7.4610334634780884e-01
    z[3,1,4]  R1712     7.0542466640472412e-01
    z[3,1,4]  R1713     6.1648392677307129e-01
    z[3,1,4]  R1714     1.2818135321140289e-01
    z[3,1,4]  R1715     2.1970003843307495e-01
    z[3,1,4]  R1716     -2.5865370035171509e-01
    z[3,1,4]  R1717     6.4369821548461914e-01
    z[3,1,4]  R1718     5.0892108678817749e-01
    z[3,1,4]  R1719     -1.2675713002681732e-01
    z[3,1,4]  R1720     9.5251753926277161e-02
    z[3,1,4]  R1721     -7.3320806026458740e-02
    z[3,1,4]  R1722     -5.4239153861999512e-02
    z[3,1,4]  R1723     -1.0252785682678223e-01
    z[3,1,4]  R1724     2.8734045103192329e-02
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R1581     -1
    z[3,1,5]  R1582     1
    z[3,1,5]  R1585     -4.8548573255538940e-01
    z[3,1,5]  R1586     6.3925251364707947e-02
    z[3,1,5]  R1587     -1.3533490896224976e-01
    z[3,1,5]  R1588     -2.9999520629644394e-02
    z[3,1,5]  R1589     -2.9029190540313721e-01
    z[3,1,5]  R1590     -4.2483350634574890e-01
    z[3,1,5]  R1591     -4.1109815239906311e-02
    z[3,1,5]  R1592     -0.0789119228720665
    z[3,1,5]  R1593     0.00739058293402195
    z[3,1,5]  R1594     -2.2993431985378265e-01
    z[3,1,5]  R1595     2.0528608560562134e-01
    z[3,1,5]  R1596     -2.4083724617958069e-01
    z[3,1,5]  R1597     -1.9655372202396393e-01
    z[3,1,5]  R1598     1.6232709586620331e-01
    z[3,1,5]  R1599     -1.7088063061237335e-01
    z[3,1,5]  R1600     -0.0994378998875618
    z[3,1,5]  R1601     2.9747176170349121e-01
    z[3,1,5]  R1602     -5.1031500101089478e-02
    z[3,1,5]  R1603     -4.4756412506103516e-02
    z[3,1,5]  R1604     2.6538664102554321e-01
    z[3,1,5]  R1605     -2.2161072492599487e-01
    z[3,1,5]  R1606     8.1138901412487030e-02
    z[3,1,5]  R1607     1.0783676803112030e-01
    z[3,1,5]  R1608     1.5114578604698181e-01
    z[3,1,5]  R1609     4.8304149508476257e-01
    z[3,1,5]  R1610     -1.2417440861463547e-01
    z[3,1,5]  R1611     -5.2974302321672440e-02
    z[3,1,5]  R1612     1.1111255735158920e-02
    z[3,1,5]  R1613     -8.2784526050090790e-02
    z[3,1,5]  R1614     1.1146222800016403e-01
    z[3,1,5]  R1615     0.251359224319458
    z[3,1,5]  R1616     4.1499685496091843e-02
    z[3,1,5]  R1617     -2.8766372799873352e-01
    z[3,1,5]  R1618     -4.3079584836959839e-01
    z[3,1,5]  R1619     2.2054976224899292e-01
    z[3,1,5]  R1620     -1.4317522943019867e-01
    z[3,1,5]  R1621     4.1190677881240845e-01
    z[3,1,5]  R1622     1.5191332995891571e-01
    z[3,1,5]  R1623     3.1151914596557617e-01
    z[3,1,5]  R1624     3.9414763450622559e-01
    z[3,1,5]  R1625     2.2859179973602295e-01
    z[3,1,5]  R1626     -1.1515405774116516e-01
    z[3,1,5]  R1627     -3.2339328527450562e-01
    z[3,1,5]  R1628     -1.7447908222675323e-01
    z[3,1,5]  R1629     -2.9478749260306358e-02
    z[3,1,5]  R1630     0.340032160282135
    z[3,1,5]  R1631     1.0683614015579224e-01
    z[3,1,5]  R1632     -1.3590057194232941e-01
    z[3,1,5]  R1633     -2.6704284548759460e-01
    z[3,1,5]  R1634     1.3821706175804138e-01
    z[3,1,5]  R1635     -2.4591540917754173e-02
    z[3,1,5]  R1636     1.7587290704250336e-01
    z[3,1,5]  R1637     -6.7038662731647491e-02
    z[3,1,5]  R1638     -1.2629090249538422e-01
    z[3,1,5]  R1639     -2.9961558058857918e-02
    z[3,1,5]  R1640     1.6140486299991608e-01
    z[3,1,5]  R1641     3.3552536368370056e-01
    z[3,1,5]  R1642     2.3200479149818420e-01
    z[3,1,5]  R1643     1.7891988158226013e-01
    z[3,1,5]  R1644     2.6513275504112244e-01
    z[3,1,5]  R1645     -8.6372224614024162e-03
    z[3,1,5]  R1646     -4.5620220899581909e-01
    z[3,1,5]  R1647     -5.3024077415466309e-01
    z[3,1,5]  R1648     7.6076802797615528e-03
    z[3,1,5]  R1649     -2.6597169041633606e-01
    z[3,1,5]  R1650     -1.9071632996201515e-02
    z[3,1,5]  R1651     2.7643588185310364e-01
    z[3,1,5]  R1652     1.4667242765426636e-02
    z[3,1,5]  R1653     1.9412128627300262e-01
    z[3,1,5]  R1654     -0.51123046875
    z[3,1,5]  R1655     -4.3620994687080383e-01
    z[3,1,5]  R1656     3.6117190122604370e-01
    z[3,1,5]  R1657     -2.8672000765800476e-01
    z[3,1,5]  R1658     -3.2860684394836426e-01
    z[3,1,5]  R1659     2.9860296845436096e-01
    z[3,1,5]  R1660     1.2046633660793304e-01
    z[3,1,5]  R1661     -2.8808993101119995e-01
    z[3,1,5]  R1662     4.9473512172698975e-01
    z[3,1,5]  R1663     -9.4497554004192352e-02
    z[3,1,5]  R1664     2.6760599017143250e-01
    z[3,1,5]  R1665     -3.1865677237510681e-01
    z[3,1,5]  R1666     4.2646953463554382e-01
    z[3,1,5]  R1667     2.1734078228473663e-01
    z[3,1,5]  R1668     -1.1890596896409988e-01
    z[3,1,5]  R1669     1.2651601433753967e-01
    z[3,1,5]  R1670     -2.9000097513198853e-01
    z[3,1,5]  R1671     5.5134242773056030e-01
    z[3,1,5]  R1672     3.9442360401153564e-01
    z[3,1,5]  R1673     5.3061836957931519e-01
    z[3,1,5]  R1674     4.0059766173362732e-01
    z[3,1,5]  R1675     -4.6309524774551392e-01
    z[3,1,5]  R1676     -4.9777108430862427e-01
    z[3,1,5]  R1677     -4.2009532451629639e-01
    z[3,1,5]  R1678     -7.0185315608978271e-01
    z[3,1,5]  R1679     -6.2715178728103638e-01
    z[3,1,5]  R1680     -0.702717125415802
    z[3,1,5]  R1681     -7.4101728200912476e-01
    z[3,1,5]  R1682     -8.6752545833587646e-01
    z[3,1,5]  R1683     -3.7044957280158997e-01
    z[3,1,5]  R1684     -1.9174227118492126e-01
    z[3,1,5]  R1685     -4.8559173941612244e-01
    z[3,1,5]  R1686     -1.7354622483253479e-02
    z[3,1,5]  R1687     -7.6631464064121246e-02
    z[3,1,5]  R1688     5.7139031589031219e-02
    z[3,1,5]  R1689     1.1248541623353958e-01
    z[3,1,5]  R1690     1.1797171086072922e-01
    z[3,1,5]  R1691     2.0577445626258850e-01
    z[3,1,5]  R1692     4.0649777650833130e-01
    z[3,1,5]  R1693     -1.2953018769621849e-02
    z[3,1,5]  R1694     7.9326741397380829e-02
    z[3,1,5]  R1695     -1.7031390964984894e-01
    z[3,1,5]  R1696     0.214023619890213
    z[3,1,5]  R1697     3.6025542020797729e-01
    z[3,1,5]  R1698     1.0420871526002884e-01
    z[3,1,5]  R1699     7.6388245820999146e-01
    z[3,1,5]  R1700     -2.0823728293180466e-02
    z[3,1,5]  R1701     3.0105376243591309e-01
    z[3,1,5]  R1702     -2.1040309220552444e-02
    z[3,1,5]  R1703     4.6810010075569153e-01
    z[3,1,5]  R1704     5.6569927930831909e-01
    z[3,1,5]  R1705     -5.4583930969238281e-01
    z[3,1,5]  R1706     -2.8972637653350830e-01
    z[3,1,5]  R1707     -7.1383011341094971e-01
    z[3,1,5]  R1708     1.3720458745956421e-01
    z[3,1,5]  R1709     1.3389253616333008e-01
    z[3,1,5]  R1710     -0.0657874047756195
    z[3,1,5]  R1711     5.4046556353569031e-02
    z[3,1,5]  R1712     -1.2181343883275986e-01
    z[3,1,5]  R1713     5.0305038690567017e-01
    z[3,1,5]  R1714     5.5670654773712158e-01
    z[3,1,5]  R1715     -3.3804804086685181e-01
    z[3,1,5]  R1716     1.0120960325002670e-01
    z[3,1,5]  R1717     5.6893342733383179e-01
    z[3,1,5]  R1718     5.1979804039001465e-01
    z[3,1,5]  R1719     7.6164029538631439e-02
    z[3,1,5]  R1720     2.9966291785240173e-01
    z[3,1,5]  R1721     2.8683552145957947e-01
    z[3,1,5]  R1722     4.4693747162818909e-01
    z[3,1,5]  R1723     3.0494108796119690e-01
    z[3,1,5]  R1724     3.9764198660850525e-01
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R1583     -1
    z[3,1,6]  R1584     1
    z[3,1,6]  R1585     -5.1596730947494507e-02
    z[3,1,6]  R1586     -9.6031047403812408e-02
    z[3,1,6]  R1587     2.4515299499034882e-01
    z[3,1,6]  R1588     1.7724240198731422e-02
    z[3,1,6]  R1589     1.0169165581464767e-01
    z[3,1,6]  R1590     -2.2188175469636917e-02
    z[3,1,6]  R1591     9.6747070550918579e-02
    z[3,1,6]  R1592     -1.9185002148151398e-01
    z[3,1,6]  R1593     -1.8084512650966644e-01
    z[3,1,6]  R1594     -2.2686289250850677e-01
    z[3,1,6]  R1595     -6.4817108213901520e-02
    z[3,1,6]  R1596     4.8896557092666626e-01
    z[3,1,6]  R1597     2.9088145494461060e-01
    z[3,1,6]  R1598     5.4765480756759644e-01
    z[3,1,6]  R1599     -0.0765218734741211
    z[3,1,6]  R1600     6.6383326053619385e-01
    z[3,1,6]  R1601     -4.8103660345077515e-01
    z[3,1,6]  R1602     -3.5973396152257919e-02
    z[3,1,6]  R1603     2.7675414457917213e-02
    z[3,1,6]  R1604     1.4806197583675385e-01
    z[3,1,6]  R1605     6.5325385332107544e-01
    z[3,1,6]  R1606     3.9939659833908081e-01
    z[3,1,6]  R1607     -3.3355975151062012e-01
    z[3,1,6]  R1608     4.4159561395645142e-01
    z[3,1,6]  R1609     -2.2576887905597687e-01
    z[3,1,6]  R1610     -5.9509657323360443e-02
    z[3,1,6]  R1611     2.3087641596794128e-01
    z[3,1,6]  R1612     1.8725031614303589e-01
    z[3,1,6]  R1613     -2.8318881988525391e-01
    z[3,1,6]  R1614     1.7644004523754120e-01
    z[3,1,6]  R1615     -1.5983033180236816e-01
    z[3,1,6]  R1616     4.8726612329483032e-01
    z[3,1,6]  R1617     0.0975242406129837
    z[3,1,6]  R1618     -4.5267440378665924e-02
    z[3,1,6]  R1619     -7.1026429533958435e-02
    z[3,1,6]  R1620     -2.5069704651832581e-01
    z[3,1,6]  R1621     -1.2107732892036438e-01
    z[3,1,6]  R1622     -1.1193778365850449e-01
    z[3,1,6]  R1623     2.6010793447494507e-01
    z[3,1,6]  R1624     -2.2518199682235718e-01
    z[3,1,6]  R1625     -1.6620095074176788e-01
    z[3,1,6]  R1626     -6.4135879278182983e-02
    z[3,1,6]  R1627     5.7532179355621338e-01
    z[3,1,6]  R1628     -4.4459655880928040e-01
    z[3,1,6]  R1629     -7.7958631515502930e-01
    z[3,1,6]  R1630     3.5826382040977478e-01
    z[3,1,6]  R1631     1.1560061015188694e-02
    z[3,1,6]  R1632     9.2273719608783722e-02
    z[3,1,6]  R1633     2.0095439627766609e-02
    z[3,1,6]  R1634     5.4892235994338989e-01
    z[3,1,6]  R1635     -2.7730929851531982e-01
    z[3,1,6]  R1636     2.7985206246376038e-01
    z[3,1,6]  R1637     -5.0994741916656494e-01
    z[3,1,6]  R1638     8.8763415813446045e-02
    z[3,1,6]  R1639     0.625530481338501
    z[3,1,6]  R1640     -1.4392854273319244e-01
    z[3,1,6]  R1641     5.0578240305185318e-02
    z[3,1,6]  R1642     -1.0098070651292801e-01
    z[3,1,6]  R1643     5.5152767896652222e-01
    z[3,1,6]  R1644     2.2399918735027313e-01
    z[3,1,6]  R1645     -4.1818860918283463e-02
    z[3,1,6]  R1646     -6.8638898432254791e-02
    z[3,1,6]  R1647     4.9629233777523041e-02
    z[3,1,6]  R1648     4.6015450358390808e-01
    z[3,1,6]  R1649     3.5267940163612366e-01
    z[3,1,6]  R1650     8.5834264755249023e-02
    z[3,1,6]  R1651     3.3901542425155640e-01
    z[3,1,6]  R1652     1.1232954263687134e-01
    z[3,1,6]  R1653     -7.5245961546897888e-02
    z[3,1,6]  R1654     -1.6824442893266678e-02
    z[3,1,6]  R1655     -3.7836784124374390e-01
    z[3,1,6]  R1656     -3.7656403146684170e-03
    z[3,1,6]  R1657     -4.0477716922760010e-01
    z[3,1,6]  R1658     0.0537756085395813
    z[3,1,6]  R1659     1.2422189861536026e-01
    z[3,1,6]  R1660     5.5422705411911011e-01
    z[3,1,6]  R1661     4.6610483527183533e-01
    z[3,1,6]  R1662     -3.2319790124893188e-01
    z[3,1,6]  R1663     -4.0369275212287903e-01
    z[3,1,6]  R1664     -3.1184107065200806e-01
    z[3,1,6]  R1665     5.3866648674011230e-01
    z[3,1,6]  R1666     -2.4914094805717468e-01
    z[3,1,6]  R1667     -2.2761613130569458e-01
    z[3,1,6]  R1668     -1.4536048471927643e-01
    z[3,1,6]  R1669     -5.7595260441303253e-02
    z[3,1,6]  R1670     0.00621609203517437
    z[3,1,6]  R1671     -3.4228414297103882e-01
    z[3,1,6]  R1672     -6.0688531398773193e-01
    z[3,1,6]  R1673     -2.4569284915924072e-01
    z[3,1,6]  R1674     -1.6450603306293488e-01
    z[3,1,6]  R1675     -1.4961341023445129e-01
    z[3,1,6]  R1676     2.1387757360935211e-01
    z[3,1,6]  R1677     0.087035171687603
    z[3,1,6]  R1678     -8.3404621109366417e-03
    z[3,1,6]  R1679     -1.8069240450859070e-01
    z[3,1,6]  R1680     0.287383496761322
    z[3,1,6]  R1681     -4.4324392080307007e-01
    z[3,1,6]  R1682     7.8737497329711914e-02
    z[3,1,6]  R1683     5.5472618341445923e-01
    z[3,1,6]  R1684     7.5775671005249023e-01
    z[3,1,6]  R1685     3.4774962067604065e-01
    z[3,1,6]  R1686     9.1815330088138580e-02
    z[3,1,6]  R1687     -3.9528802037239075e-01
    z[3,1,6]  R1688     0.0697116032242775
    z[3,1,6]  R1689     2.9087954759597778e-01
    z[3,1,6]  R1690     3.2448939979076385e-02
    z[3,1,6]  R1691     -5.4661218076944351e-02
    z[3,1,6]  R1692     -2.4099057912826538e-01
    z[3,1,6]  R1693     -1.1285389959812164e-01
    z[3,1,6]  R1694     7.5361780822277069e-02
    z[3,1,6]  R1695     -2.4202053900808096e-03
    z[3,1,6]  R1696     1.1376570910215378e-01
    z[3,1,6]  R1697     5.3188685327768326e-02
    z[3,1,6]  R1698     -1.8500572443008423e-01
    z[3,1,6]  R1699     -7.9107824712991714e-03
    z[3,1,6]  R1700     -3.7395489215850830e-01
    z[3,1,6]  R1701     0.123031385242939
    z[3,1,6]  R1702     -5.0080728530883789e-01
    z[3,1,6]  R1703     -2.1072435379028320e-01
    z[3,1,6]  R1704     -2.5283247232437134e-01
    z[3,1,6]  R1705     3.4493315219879150e-01
    z[3,1,6]  R1706     2.6844039559364319e-01
    z[3,1,6]  R1707     -3.3700618147850037e-01
    z[3,1,6]  R1708     -3.2257422804832458e-01
    z[3,1,6]  R1709     -3.5320317745208740e-01
    z[3,1,6]  R1710     -2.6487755775451660e-01
    z[3,1,6]  R1711     -1.5535186231136322e-01
    z[3,1,6]  R1712     -4.2757540941238403e-01
    z[3,1,6]  R1713     2.8858572244644165e-01
    z[3,1,6]  R1714     -1.7450398206710815e-01
    z[3,1,6]  R1715     -2.6332248002290726e-02
    z[3,1,6]  R1716     -0.159862220287323
    z[3,1,6]  R1717     -3.2387372851371765e-01
    z[3,1,6]  R1718     -1.4186498522758484e-01
    z[3,1,6]  R1719     -2.2816176712512970e-01
    z[3,1,6]  R1720     -0.0744878277182579
    z[3,1,6]  R1721     -2.5121471285820007e-01
    z[3,1,6]  R1722     -2.8377154842019081e-02
    z[3,1,6]  R1723     -4.8527400940656662e-02
    z[3,1,6]  R1724     1.4812238514423370e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R1725     -1
    z[1,4,0]  R1726     1
    z[1,4,0]  R1739     3.3207225799560547e-01
    z[1,4,0]  R1740     2.2497600317001343e-01
    z[1,4,0]  R1741     4.0429782867431641e-01
    z[1,4,0]  R1742     1.1020505428314209e-01
    z[1,4,0]  R1743     3.3701881766319275e-01
    z[1,4,0]  R1744     0.297879159450531
    z[1,4,0]  R1745     3.9452165365219116e-01
    z[1,4,0]  R1746     2.0356547832489014e-01
    z[1,4,0]  R1747     -2.6331812143325806e-01
    z[1,4,0]  R1748     3.1959950923919678e-01
    z[1,4,0]  R1749     5.9074461460113525e-01
    z[1,4,0]  R1750     -4.1275955736637115e-02
    z[1,4,0]  R1751     -3.7504187226295471e-01
    z[1,4,0]  R1752     -5.7928526401519775e-01
    z[1,4,0]  R1753     -4.9910187721252441e-01
    z[1,4,0]  R1754     -6.3219177722930908e-01
    z[1,4,0]  R1755     -3.9742922782897949e-01
    z[1,4,0]  R1756     2.3084011673927307e-01
    z[1,4,0]  R1757     -9.3423920869827271e-01
    z[1,4,0]  R1758     -9.2440533638000488e-01
    z[1,4,0]  R1759     2.1656617522239685e-01
    z[1,4,0]  R1760     1.9144825637340546e-02
    z[1,4,0]  R1761     -5.2586293220520020e-01
    z[1,4,0]  R1762     3.0178827047348022e-01
    z[1,4,0]  R1763     2.0443785190582275e-01
    z[1,4,0]  R1764     -1.7751251161098480e-01
    z[1,4,0]  R1765     5.6899610906839371e-02
    z[1,4,0]  R1766     1.6422684490680695e-01
    z[1,4,0]  R1767     2.9473572969436646e-01
    z[1,4,0]  R1768     -6.5723603963851929e-01
    z[1,4,0]  R1769     9.5317848026752472e-02
    z[1,4,0]  R1770     -5.1086451858282089e-02
    z[1,4,0]  R1771     -2.1587809920310974e-01
    z[1,4,0]  R1772     7.7477765083312988e-01
    z[1,4,0]  R1773     7.0630115270614624e-01
    z[1,4,0]  R1774     5.0864154100418091e-01
    z[1,4,0]  R1775     5.3289115428924561e-01
    z[1,4,0]  R1776     3.1803345680236816e-01
    z[1,4,0]  R1777     -4.4739622622728348e-02
    z[1,4,0]  R1778     -5.8397495746612549e-01
    z[1,4,0]  R1779     -5.5687215179204941e-02
    z[1,4,0]  R1780     8.9335137605667114e-01
    z[1,4,0]  R1781     -1.7038933932781219e-01
    z[1,4,0]  R1782     -3.7038710713386536e-01
    z[1,4,0]  R1783     -6.0038655996322632e-01
    z[1,4,0]  R1784     4.6409547328948975e-01
    z[1,4,0]  R1785     4.3099871277809143e-01
    z[1,4,0]  R1786     4.7354349493980408e-01
    z[1,4,0]  R1787     4.6459159255027771e-01
    z[1,4,0]  R1788     4.6672913432121277e-01
    z[1,4,0]  R1789     -0.626301646232605
    z[1,4,0]  R1790     -8.4204000234603882e-01
    z[1,4,0]  R1791     -5.6200635433197021e-01
    z[1,4,0]  R1792     -5.3218764066696167e-01
    z[1,4,0]  R1793     -0.939971387386322
    z[1,4,0]  R1794     6.5989071130752563e-01
    z[1,4,0]  R1795     -9.3661779165267944e-01
    z[1,4,0]  R1796     5.6124496459960938e-01
    z[1,4,0]  R1797     -8.1057894229888916e-01
    z[1,4,0]  R1798     -8.1453180313110352e-01
    z[1,4,0]  R1799     -1.3804477453231812e-01
    z[1,4,0]  R1800     -1.4331266283988953e-01
    z[1,4,0]  R1801     1.3529990613460541e-01
    z[1,4,0]  R1802     1.8741910159587860e-01
    z[1,4,0]  R1803     1.1734388023614883e-01
    z[1,4,0]  R1804     -1.5084441751241684e-02
    z[1,4,0]  R1805     -4.1426301002502441e-01
    z[1,4,0]  R1806     8.9693886041641235e-01
    z[1,4,0]  R1807     7.0947146415710449e-01
    z[1,4,0]  R1808     0.85356205701828
    z[1,4,0]  R1809     6.7912268638610840e-01
    z[1,4,0]  R1810     4.6549555659294128e-01
    z[1,4,0]  R1811     -7.0993238687515259e-01
    z[1,4,0]  R1812     7.1068447828292847e-01
    z[1,4,0]  R1813     4.5530465245246887e-01
    z[1,4,0]  R1814     0.552579402923584
    z[1,4,0]  R1815     5.8852738142013550e-01
    z[1,4,0]  R1816     -3.5320860147476196e-01
    z[1,4,0]  R1817     -0.319614976644516
    z[1,4,0]  R1818     -2.3107655346393585e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R1727     -1
    z[1,4,1]  R1728     1
    z[1,4,1]  R1739     -8.4220498800277710e-02
    z[1,4,1]  R1740     0.361508309841156
    z[1,4,1]  R1741     4.8457989096641541e-01
    z[1,4,1]  R1742     -3.2911914587020874e-01
    z[1,4,1]  R1743     3.3398628234863281e-01
    z[1,4,1]  R1744     -4.8228830099105835e-01
    z[1,4,1]  R1745     -1.9169540703296661e-01
    z[1,4,1]  R1746     2.1775195002555847e-01
    z[1,4,1]  R1747     -2.4984495341777802e-01
    z[1,4,1]  R1748     2.1840962767601013e-01
    z[1,4,1]  R1749     3.6695379018783569e-01
    z[1,4,1]  R1750     6.5316796302795410e-01
    z[1,4,1]  R1751     0.657727062702179
    z[1,4,1]  R1752     6.4585006237030029e-01
    z[1,4,1]  R1753     7.4338763952255249e-01
    z[1,4,1]  R1754     7.0508313179016113e-01
    z[1,4,1]  R1755     7.9247128963470459e-01
    z[1,4,1]  R1756     8.2078307867050171e-01
    z[1,4,1]  R1757     3.3597180247306824e-01
    z[1,4,1]  R1758     3.2437753677368164e-01
    z[1,4,1]  R1759     8.7639510631561279e-01
    z[1,4,1]  R1760     0.31130251288414
    z[1,4,1]  R1761     -4.1803106665611267e-01
    z[1,4,1]  R1762     1.0529877245426178e-01
    z[1,4,1]  R1763     1.0849340260028839e-01
    z[1,4,1]  R1764     2.3467201739549637e-02
    z[1,4,1]  R1765     -2.1112029254436493e-01
    z[1,4,1]  R1766     1.6639775037765503e-01
    z[1,4,1]  R1767     -6.7488527856767178e-03
    z[1,4,1]  R1768     -6.3168264925479889e-02
    z[1,4,1]  R1769     0.547184944152832
    z[1,4,1]  R1770     1.0742236673831940e-01
    z[1,4,1]  R1771     0.407914936542511
    z[1,4,1]  R1772     4.4724959135055542e-01
    z[1,4,1]  R1773     3.4217163920402527e-01
    z[1,4,1]  R1774     1.4415302872657776e-01
    z[1,4,1]  R1775     3.5020154714584351e-01
    z[1,4,1]  R1776     3.6574858427047729e-01
    z[1,4,1]  R1777     -4.1784530878067017e-01
    z[1,4,1]  R1778     -3.3625042438507080e-01
    z[1,4,1]  R1779     8.6969435214996338e-01
    z[1,4,1]  R1780     8.6631134152412415e-02
    z[1,4,1]  R1781     1.4700804650783539e-01
    z[1,4,1]  R1782     -3.5427924990653992e-01
    z[1,4,1]  R1783     -6.7064750194549561e-01
    z[1,4,1]  R1784     -7.4182587862014771e-01
    z[1,4,1]  R1785     -7.4127340316772461e-01
    z[1,4,1]  R1786     -7.2319769859313965e-01
    z[1,4,1]  R1787     -7.1683096885681152e-01
    z[1,4,1]  R1788     -6.9388502836227417e-01
    z[1,4,1]  R1789     -0.575942873954773
    z[1,4,1]  R1790     -8.1678695976734161e-02
    z[1,4,1]  R1791     -1.9468982517719269e-01
    z[1,4,1]  R1792     -8.7245449423789978e-02
    z[1,4,1]  R1793     -1.4296740293502808e-01
    z[1,4,1]  R1794     1.5793354809284210e-01
    z[1,4,1]  R1795     6.2615498900413513e-02
    z[1,4,1]  R1796     -8.5508622229099274e-02
    z[1,4,1]  R1797     2.1103753149509430e-01
    z[1,4,1]  R1798     0.0857396051287651
    z[1,4,1]  R1799     8.7869238853454590e-01
    z[1,4,1]  R1800     7.4564278125762939e-01
    z[1,4,1]  R1801     0.814132571220398
    z[1,4,1]  R1802     8.3106732368469238e-01
    z[1,4,1]  R1803     0.913650393486023
    z[1,4,1]  R1804     9.2196524143218994e-01
    z[1,4,1]  R1805     6.8651187419891357e-01
    z[1,4,1]  R1806     -3.4975543618202209e-01
    z[1,4,1]  R1807     -2.1639437973499298e-01
    z[1,4,1]  R1808     3.3483337610960007e-02
    z[1,4,1]  R1809     -5.4730284214019775e-01
    z[1,4,1]  R1810     -1.0956397652626038e-01
    z[1,4,1]  R1811     0.00622505834326148
    z[1,4,1]  R1812     5.1804497838020325e-02
    z[1,4,1]  R1813     -2.2204600274562836e-01
    z[1,4,1]  R1814     -2.3661231622099876e-02
    z[1,4,1]  R1815     2.3132576048374176e-01
    z[1,4,1]  R1816     -6.3067066669464111e-01
    z[1,4,1]  R1817     -8.3851498365402222e-01
    z[1,4,1]  R1818     -6.7305499315261841e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R1729     -1
    z[1,4,2]  R1730     1
    z[1,4,2]  R1739     7.9628866910934448e-01
    z[1,4,2]  R1740     6.2952286005020142e-01
    z[1,4,2]  R1741     2.3803453147411346e-01
    z[1,4,2]  R1742     3.5012251138687134e-01
    z[1,4,2]  R1743     1.6661569476127625e-01
    z[1,4,2]  R1744     3.0057954788208008e-01
    z[1,4,2]  R1745     -7.2683282196521759e-02
    z[1,4,2]  R1746     -2.0050784945487976e-01
    z[1,4,2]  R1747     5.0285577774047852e-01
    z[1,4,2]  R1748     0.00567758409306407
    z[1,4,2]  R1749     -2.1179307997226715e-01
    z[1,4,2]  R1750     -5.8393353223800659e-01
    z[1,4,2]  R1751     -4.0201231837272644e-01
    z[1,4,2]  R1752     -3.8458973169326782e-01
    z[1,4,2]  R1753     4.2064037173986435e-02
    z[1,4,2]  R1754     -2.8824952244758606e-01
    z[1,4,2]  R1755     -2.4844953417778015e-01
    z[1,4,2]  R1756     -1.5014594793319702e-01
    z[1,4,2]  R1757     -3.6241721361875534e-02
    z[1,4,2]  R1758     1.1564271897077560e-01
    z[1,4,2]  R1759     1.7821869254112244e-01
    z[1,4,2]  R1760     -2.7339941263198853e-01
    z[1,4,2]  R1761     -6.2284684181213379e-01
    z[1,4,2]  R1762     9.8502419888973236e-02
    z[1,4,2]  R1763     -8.4907189011573792e-02
    z[1,4,2]  R1764     -3.7734252214431763e-01
    z[1,4,2]  R1765     1.1531513929367065e-01
    z[1,4,2]  R1766     -3.3423385024070740e-01
    z[1,4,2]  R1767     6.3833691179752350e-02
    z[1,4,2]  R1768     -3.4744244813919067e-01
    z[1,4,2]  R1769     -3.5237598419189453e-01
    z[1,4,2]  R1770     1.0244900733232498e-01
    z[1,4,2]  R1771     -7.7153556048870087e-02
    z[1,4,2]  R1772     -1.8872264027595520e-01
    z[1,4,2]  R1773     -5.5572193115949631e-02
    z[1,4,2]  R1774     7.1593075990676880e-02
    z[1,4,2]  R1775     1.0369773954153061e-02
    z[1,4,2]  R1776     -8.3991587162017822e-02
    z[1,4,2]  R1777     9.6030756831169128e-03
    z[1,4,2]  R1778     -3.5265704989433289e-01
    z[1,4,2]  R1779     -2.3279662430286407e-01
    z[1,4,2]  R1780     2.2210830822587013e-02
    z[1,4,2]  R1781     1.0618493705987930e-01
    z[1,4,2]  R1782     -1.7527283728122711e-01
    z[1,4,2]  R1783     3.4023147821426392e-01
    z[1,4,2]  R1784     -3.2223331928253174e-01
    z[1,4,2]  R1785     -1.6301706433296204e-01
    z[1,4,2]  R1786     -1.1810306459665298e-01
    z[1,4,2]  R1787     -2.4931703507900238e-01
    z[1,4,2]  R1788     -0.291786253452301
    z[1,4,2]  R1789     3.8755902647972107e-01
    z[1,4,2]  R1790     4.8647314310073853e-01
    z[1,4,2]  R1791     6.0824459791183472e-01
    z[1,4,2]  R1792     4.3417137861251831e-01
    z[1,4,2]  R1793     -1.4967535436153412e-01
    z[1,4,2]  R1794     -4.1559547185897827e-01
    z[1,4,2]  R1795     -1.9692401587963104e-01
    z[1,4,2]  R1796     -1.1192564666271210e-01
    z[1,4,2]  R1797     -1.9925747811794281e-01
    z[1,4,2]  R1798     4.4076152145862579e-02
    z[1,4,2]  R1799     -0.348624587059021
    z[1,4,2]  R1800     -5.3115451335906982e-01
    z[1,4,2]  R1801     -3.2606229186058044e-01
    z[1,4,2]  R1802     -2.7933281660079956e-01
    z[1,4,2]  R1803     -0.0719640925526619
    z[1,4,2]  R1804     -0.0854223445057869
    z[1,4,2]  R1805     -3.4509435296058655e-01
    z[1,4,2]  R1806     1.6582074761390686e-01
    z[1,4,2]  R1807     2.6561295986175537e-01
    z[1,4,2]  R1808     3.1241217255592346e-01
    z[1,4,2]  R1809     3.5691785160452127e-03
    z[1,4,2]  R1810     -2.1841278672218323e-01
    z[1,4,2]  R1811     3.8633834570646286e-02
    z[1,4,2]  R1812     1.4892983436584473e-01
    z[1,4,2]  R1813     -1.7980413138866425e-01
    z[1,4,2]  R1814     0.190543994307518
    z[1,4,2]  R1815     1.6353680193424225e-01
    z[1,4,2]  R1816     -0.352943480014801
    z[1,4,2]  R1817     -8.0922663211822510e-02
    z[1,4,2]  R1818     -1.6812250018119812e-02
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R1731     -1
    z[1,4,3]  R1732     1
    z[1,4,3]  R1739     -1.0823883116245270e-01
    z[1,4,3]  R1740     0.356587290763855
    z[1,4,3]  R1741     6.0027605295181274e-01
    z[1,4,3]  R1742     5.1075166463851929e-01
    z[1,4,3]  R1743     5.3740882873535156e-01
    z[1,4,3]  R1744     1.0916360467672348e-01
    z[1,4,3]  R1745     4.9610521644353867e-02
    z[1,4,3]  R1746     2.6247090101242065e-01
    z[1,4,3]  R1747     3.9771571755409241e-01
    z[1,4,3]  R1748     4.4433519244194031e-01
    z[1,4,3]  R1749     2.9319867491722107e-01
    z[1,4,3]  R1750     -1.5360046923160553e-01
    z[1,4,3]  R1751     -2.7590749785304070e-02
    z[1,4,3]  R1752     2.2711518406867981e-01
    z[1,4,3]  R1753     -1.6082301735877991e-01
    z[1,4,3]  R1754     -6.8718180060386658e-02
    z[1,4,3]  R1755     3.1026366353034973e-01
    z[1,4,3]  R1756     -5.8440599590539932e-02
    z[1,4,3]  R1757     -4.1871690191328526e-03
    z[1,4,3]  R1758     -4.1127860546112061e-02
    z[1,4,3]  R1759     -3.3243077993392944e-01
    z[1,4,3]  R1760     -6.8526461720466614e-02
    z[1,4,3]  R1761     -8.7724313139915466e-02
    z[1,4,3]  R1762     -3.5257175564765930e-01
    z[1,4,3]  R1763     -2.9554140567779541e-01
    z[1,4,3]  R1764     -2.9453948140144348e-01
    z[1,4,3]  R1765     -3.3523476123809814e-01
    z[1,4,3]  R1766     -3.7054210901260376e-01
    z[1,4,3]  R1767     -4.7129637002944946e-01
    z[1,4,3]  R1768     -3.0005259439349174e-02
    z[1,4,3]  R1769     -3.7874984741210938e-01
    z[1,4,3]  R1770     9.7439870238304138e-02
    z[1,4,3]  R1771     -3.0197608470916748e-01
    z[1,4,3]  R1772     -2.0218986272811890e-01
    z[1,4,3]  R1773     -1.5474145114421844e-01
    z[1,4,3]  R1774     -4.0473595261573792e-02
    z[1,4,3]  R1775     9.7739197313785553e-02
    z[1,4,3]  R1776     -2.5048962235450745e-01
    z[1,4,3]  R1777     -3.2698279619216919e-01
    z[1,4,3]  R1778     -2.5443577766418457e-01
    z[1,4,3]  R1779     -1.5198162198066711e-01
    z[1,4,3]  R1780     -3.0203291773796082e-01
    z[1,4,3]  R1781     -3.0847027897834778e-01
    z[1,4,3]  R1782     -3.9656361937522888e-01
    z[1,4,3]  R1783     -9.1805262491106987e-03
    z[1,4,3]  R1784     -1.6141927242279053e-01
    z[1,4,3]  R1785     -2.9566857218742371e-01
    z[1,4,3]  R1786     -1.8786433339118958e-01
    z[1,4,3]  R1787     -3.1983304023742676e-01
    z[1,4,3]  R1788     1.8618069589138031e-01
    z[1,4,3]  R1789     -1.1291564255952835e-01
    z[1,4,3]  R1790     -4.3126974254846573e-02
    z[1,4,3]  R1791     -8.4073126316070557e-02
    z[1,4,3]  R1792     -1.1861911416053772e-01
    z[1,4,3]  R1793     -2.1147488057613373e-01
    z[1,4,3]  R1794     1.1938295327126980e-02
    z[1,4,3]  R1795     -3.3003918826580048e-02
    z[1,4,3]  R1796     -7.1461528539657593e-02
    z[1,4,3]  R1797     -3.5813751816749573e-01
    z[1,4,3]  R1798     3.7784200906753540e-01
    z[1,4,3]  R1799     2.3530612885951996e-01
    z[1,4,3]  R1800     -1.9758237898349762e-01
    z[1,4,3]  R1801     3.5624884068965912e-02
    z[1,4,3]  R1802     -0.330709308385849
    z[1,4,3]  R1803     1.2008894234895706e-01
    z[1,4,3]  R1804     -4.6502269804477692e-02
    z[1,4,3]  R1805     -2.7664867043495178e-01
    z[1,4,3]  R1806     -7.3545746505260468e-02
    z[1,4,3]  R1807     -1.3987350463867188e-01
    z[1,4,3]  R1808     7.3284611105918884e-02
    z[1,4,3]  R1809     -1.9933162629604340e-01
    z[1,4,3]  R1810     -1.5276260673999786e-01
    z[1,4,3]  R1811     5.7509493827819824e-01
    z[1,4,3]  R1812     -4.4765692949295044e-01
    z[1,4,3]  R1813     -7.7382522821426392e-01
    z[1,4,3]  R1814     7.6344740390777588e-01
    z[1,4,3]  R1815     5.8561843633651733e-01
    z[1,4,3]  R1816     4.7341939806938171e-01
    z[1,4,3]  R1817     2.2318008542060852e-01
    z[1,4,3]  R1818     3.6834666132926941e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R1733     -1
    z[1,4,4]  R1734     1
    z[1,4,4]  R1739     1.4760370831936598e-03
    z[1,4,4]  R1740     4.1524812579154968e-02
    z[1,4,4]  R1741     -2.6050312444567680e-02
    z[1,4,4]  R1742     5.8437857776880264e-02
    z[1,4,4]  R1743     -1.7981484532356262e-01
    z[1,4,4]  R1744     -7.4437371222302318e-04
    z[1,4,4]  R1745     2.3300166428089142e-01
    z[1,4,4]  R1746     2.0796832442283630e-01
    z[1,4,4]  R1747     1.1065878719091415e-01
    z[1,4,4]  R1748     2.0427180826663971e-01
    z[1,4,4]  R1749     1.6974899172782898e-01
    z[1,4,4]  R1750     -4.4538193941116333e-01
    z[1,4,4]  R1751     -3.1974750757217407e-01
    z[1,4,4]  R1752     -1.9922609627246857e-01
    z[1,4,4]  R1753     -2.7087783813476562e-01
    z[1,4,4]  R1754     2.0275993272662163e-02
    z[1,4,4]  R1755     1.0352526605129242e-01
    z[1,4,4]  R1756     -1.5411649644374847e-01
    z[1,4,4]  R1757     -9.2224171385169029e-03
    z[1,4,4]  R1758     1.1496607959270477e-01
    z[1,4,4]  R1759     1.1724268645048141e-01
    z[1,4,4]  R1760     8.7437534332275391e-01
    z[1,4,4]  R1761     -1.4307887852191925e-01
    z[1,4,4]  R1762     8.4778529405593872e-01
    z[1,4,4]  R1763     5.1797825098037720e-01
    z[1,4,4]  R1764     7.7364194393157959e-01
    z[1,4,4]  R1765     8.4896445274353027e-01
    z[1,4,4]  R1766     0.667140781879425
    z[1,4,4]  R1767     6.5066725015640259e-01
    z[1,4,4]  R1768     -2.4185539782047272e-01
    z[1,4,4]  R1769     -8.3446763455867767e-02
    z[1,4,4]  R1770     8.9992147684097290e-01
    z[1,4,4]  R1771     -2.5832799077033997e-01
    z[1,4,4]  R1772     1.7638940364122391e-02
    z[1,4,4]  R1773     -4.6297335624694824e-01
    z[1,4,4]  R1774     -7.9953235387802124e-01
    z[1,4,4]  R1775     -7.4610334634780884e-01
    z[1,4,4]  R1776     7.0542466640472412e-01
    z[1,4,4]  R1777     6.1648392677307129e-01
    z[1,4,4]  R1778     1.2818135321140289e-01
    z[1,4,4]  R1779     2.1970003843307495e-01
    z[1,4,4]  R1780     -2.5865370035171509e-01
    z[1,4,4]  R1781     6.4369821548461914e-01
    z[1,4,4]  R1782     5.0892108678817749e-01
    z[1,4,4]  R1783     -1.2675713002681732e-01
    z[1,4,4]  R1784     9.5251753926277161e-02
    z[1,4,4]  R1785     -7.3320806026458740e-02
    z[1,4,4]  R1786     -5.4239153861999512e-02
    z[1,4,4]  R1787     -1.0252785682678223e-01
    z[1,4,4]  R1788     2.8734045103192329e-02
    z[1,4,4]  R1789     -1.3108095526695251e-01
    z[1,4,4]  R1790     1.7517803609371185e-01
    z[1,4,4]  R1791     -5.0521481037139893e-01
    z[1,4,4]  R1792     -3.7098596803843975e-03
    z[1,4,4]  R1793     -7.8253731131553650e-02
    z[1,4,4]  R1794     1.8952155485749245e-02
    z[1,4,4]  R1795     1.0351741313934326e-01
    z[1,4,4]  R1796     -3.0360710620880127e-01
    z[1,4,4]  R1797     -2.0744135975837708e-01
    z[1,4,4]  R1798     -2.9577660560607910e-01
    z[1,4,4]  R1799     6.2534660100936890e-02
    z[1,4,4]  R1800     2.8456097841262817e-01
    z[1,4,4]  R1801     4.0337464213371277e-01
    z[1,4,4]  R1802     7.7082134783267975e-02
    z[1,4,4]  R1803     1.1331208795309067e-01
    z[1,4,4]  R1804     -2.6226335763931274e-01
    z[1,4,4]  R1805     -3.4285095334053040e-01
    z[1,4,4]  R1806     8.8250853121280670e-02
    z[1,4,4]  R1807     2.7964314818382263e-01
    z[1,4,4]  R1808     8.8019356131553650e-02
    z[1,4,4]  R1809     3.6297035217285156e-01
    z[1,4,4]  R1810     6.8603962659835815e-02
    z[1,4,4]  R1811     2.4468223750591278e-01
    z[1,4,4]  R1812     -4.6644932031631470e-01
    z[1,4,4]  R1813     -3.0253347754478455e-01
    z[1,4,4]  R1814     3.5661216825246811e-02
    z[1,4,4]  R1815     -2.8646424412727356e-01
    z[1,4,4]  R1816     -1.2093091756105423e-01
    z[1,4,4]  R1817     8.1553466618061066e-02
    z[1,4,4]  R1818     -5.2477353811264038e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R1735     -1
    z[1,4,5]  R1736     1
    z[1,4,5]  R1739     -4.6309524774551392e-01
    z[1,4,5]  R1740     -4.9777108430862427e-01
    z[1,4,5]  R1741     -4.2009532451629639e-01
    z[1,4,5]  R1742     -7.0185315608978271e-01
    z[1,4,5]  R1743     -6.2715178728103638e-01
    z[1,4,5]  R1744     -0.702717125415802
    z[1,4,5]  R1745     -7.4101728200912476e-01
    z[1,4,5]  R1746     -8.6752545833587646e-01
    z[1,4,5]  R1747     -3.7044957280158997e-01
    z[1,4,5]  R1748     -1.9174227118492126e-01
    z[1,4,5]  R1749     -4.8559173941612244e-01
    z[1,4,5]  R1750     -1.7354622483253479e-02
    z[1,4,5]  R1751     -7.6631464064121246e-02
    z[1,4,5]  R1752     5.7139031589031219e-02
    z[1,4,5]  R1753     1.1248541623353958e-01
    z[1,4,5]  R1754     1.1797171086072922e-01
    z[1,4,5]  R1755     2.0577445626258850e-01
    z[1,4,5]  R1756     4.0649777650833130e-01
    z[1,4,5]  R1757     -1.2953018769621849e-02
    z[1,4,5]  R1758     7.9326741397380829e-02
    z[1,4,5]  R1759     -1.7031390964984894e-01
    z[1,4,5]  R1760     0.214023619890213
    z[1,4,5]  R1761     3.6025542020797729e-01
    z[1,4,5]  R1762     1.0420871526002884e-01
    z[1,4,5]  R1763     7.6388245820999146e-01
    z[1,4,5]  R1764     -2.0823728293180466e-02
    z[1,4,5]  R1765     3.0105376243591309e-01
    z[1,4,5]  R1766     -2.1040309220552444e-02
    z[1,4,5]  R1767     4.6810010075569153e-01
    z[1,4,5]  R1768     5.6569927930831909e-01
    z[1,4,5]  R1769     -5.4583930969238281e-01
    z[1,4,5]  R1770     -2.8972637653350830e-01
    z[1,4,5]  R1771     -7.1383011341094971e-01
    z[1,4,5]  R1772     1.3720458745956421e-01
    z[1,4,5]  R1773     1.3389253616333008e-01
    z[1,4,5]  R1774     -0.0657874047756195
    z[1,4,5]  R1775     5.4046556353569031e-02
    z[1,4,5]  R1776     -1.2181343883275986e-01
    z[1,4,5]  R1777     5.0305038690567017e-01
    z[1,4,5]  R1778     5.5670654773712158e-01
    z[1,4,5]  R1779     -3.3804804086685181e-01
    z[1,4,5]  R1780     1.0120960325002670e-01
    z[1,4,5]  R1781     5.6893342733383179e-01
    z[1,4,5]  R1782     5.1979804039001465e-01
    z[1,4,5]  R1783     7.6164029538631439e-02
    z[1,4,5]  R1784     2.9966291785240173e-01
    z[1,4,5]  R1785     2.8683552145957947e-01
    z[1,4,5]  R1786     4.4693747162818909e-01
    z[1,4,5]  R1787     3.0494108796119690e-01
    z[1,4,5]  R1788     3.9764198660850525e-01
    z[1,4,5]  R1789     -2.7850124239921570e-01
    z[1,4,5]  R1790     1.2280213832855225e-01
    z[1,4,5]  R1791     4.8055514693260193e-02
    z[1,4,5]  R1792     -3.5813519358634949e-01
    z[1,4,5]  R1793     8.1823609769344330e-02
    z[1,4,5]  R1794     -3.6321735382080078e-01
    z[1,4,5]  R1795     -2.6041004061698914e-01
    z[1,4,5]  R1796     -6.7825573682785034e-01
    z[1,4,5]  R1797     -1.2281390838325024e-02
    z[1,4,5]  R1798     3.1469874083995819e-02
    z[1,4,5]  R1799     5.8050606399774551e-02
    z[1,4,5]  R1800     -1.4533384144306183e-01
    z[1,4,5]  R1801     1.5770610189065337e-03
    z[1,4,5]  R1802     1.1847331374883652e-01
    z[1,4,5]  R1803     -4.4052530080080032e-02
    z[1,4,5]  R1804     2.4003873765468597e-01
    z[1,4,5]  R1805     -1.1766491085290909e-01
    z[1,4,5]  R1806     1.6332441568374634e-01
    z[1,4,5]  R1807     -1.0694076865911484e-01
    z[1,4,5]  R1808     1.6248992085456848e-01
    z[1,4,5]  R1809     -2.2576166689395905e-01
    z[1,4,5]  R1810     -8.2591855525970459e-01
    z[1,4,5]  R1811     3.0087551474571228e-01
    z[1,4,5]  R1812     -1.8919488787651062e-01
    z[1,4,5]  R1813     -1.0286095738410950e-01
    z[1,4,5]  R1814     -9.0068064630031586e-02
    z[1,4,5]  R1815     1.7317394912242889e-01
    z[1,4,5]  R1816     2.8762108087539673e-01
    z[1,4,5]  R1817     3.4940522909164429e-01
    z[1,4,5]  R1818     2.5666022300720215e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R1737     -1
    z[1,4,6]  R1738     1
    z[1,4,6]  R1739     -1.4961341023445129e-01
    z[1,4,6]  R1740     2.1387757360935211e-01
    z[1,4,6]  R1741     0.087035171687603
    z[1,4,6]  R1742     -8.3404621109366417e-03
    z[1,4,6]  R1743     -1.8069240450859070e-01
    z[1,4,6]  R1744     0.287383496761322
    z[1,4,6]  R1745     -4.4324392080307007e-01
    z[1,4,6]  R1746     7.8737497329711914e-02
    z[1,4,6]  R1747     5.5472618341445923e-01
    z[1,4,6]  R1748     7.5775671005249023e-01
    z[1,4,6]  R1749     3.4774962067604065e-01
    z[1,4,6]  R1750     9.1815330088138580e-02
    z[1,4,6]  R1751     -3.9528802037239075e-01
    z[1,4,6]  R1752     0.0697116032242775
    z[1,4,6]  R1753     2.9087954759597778e-01
    z[1,4,6]  R1754     3.2448939979076385e-02
    z[1,4,6]  R1755     -5.4661218076944351e-02
    z[1,4,6]  R1756     -2.4099057912826538e-01
    z[1,4,6]  R1757     -1.1285389959812164e-01
    z[1,4,6]  R1758     7.5361780822277069e-02
    z[1,4,6]  R1759     -2.4202053900808096e-03
    z[1,4,6]  R1760     1.1376570910215378e-01
    z[1,4,6]  R1761     5.3188685327768326e-02
    z[1,4,6]  R1762     -1.8500572443008423e-01
    z[1,4,6]  R1763     -7.9107824712991714e-03
    z[1,4,6]  R1764     -3.7395489215850830e-01
    z[1,4,6]  R1765     0.123031385242939
    z[1,4,6]  R1766     -5.0080728530883789e-01
    z[1,4,6]  R1767     -2.1072435379028320e-01
    z[1,4,6]  R1768     -2.5283247232437134e-01
    z[1,4,6]  R1769     3.4493315219879150e-01
    z[1,4,6]  R1770     2.6844039559364319e-01
    z[1,4,6]  R1771     -3.3700618147850037e-01
    z[1,4,6]  R1772     -3.2257422804832458e-01
    z[1,4,6]  R1773     -3.5320317745208740e-01
    z[1,4,6]  R1774     -2.6487755775451660e-01
    z[1,4,6]  R1775     -1.5535186231136322e-01
    z[1,4,6]  R1776     -4.2757540941238403e-01
    z[1,4,6]  R1777     2.8858572244644165e-01
    z[1,4,6]  R1778     -1.7450398206710815e-01
    z[1,4,6]  R1779     -2.6332248002290726e-02
    z[1,4,6]  R1780     -0.159862220287323
    z[1,4,6]  R1781     -3.2387372851371765e-01
    z[1,4,6]  R1782     -1.4186498522758484e-01
    z[1,4,6]  R1783     -2.2816176712512970e-01
    z[1,4,6]  R1784     -0.0744878277182579
    z[1,4,6]  R1785     -2.5121471285820007e-01
    z[1,4,6]  R1786     -2.8377154842019081e-02
    z[1,4,6]  R1787     -4.8527400940656662e-02
    z[1,4,6]  R1788     1.4812238514423370e-01
    z[1,4,6]  R1789     1.3542146980762482e-01
    z[1,4,6]  R1790     -0.00367422285489738
    z[1,4,6]  R1791     -1.0799888521432877e-01
    z[1,4,6]  R1792     -6.1507290601730347e-01
    z[1,4,6]  R1793     1.2677150964736938e-01
    z[1,4,6]  R1794     4.8420354723930359e-01
    z[1,4,6]  R1795     2.0706895738840103e-02
    z[1,4,6]  R1796     3.2840543985366821e-01
    z[1,4,6]  R1797     -2.9542544484138489e-01
    z[1,4,6]  R1798     3.0984729528427124e-01
    z[1,4,6]  R1799     1.5701831877231598e-01
    z[1,4,6]  R1800     -1.4757920987904072e-02
    z[1,4,6]  R1801     -2.2041529417037964e-01
    z[1,4,6]  R1802     -2.5851166248321533e-01
    z[1,4,6]  R1803     -3.4218841791152954e-01
    z[1,4,6]  R1804     -1.1786611378192902e-01
    z[1,4,6]  R1805     1.7341071367263794e-01
    z[1,4,6]  R1806     -7.6179198920726776e-02
    z[1,4,6]  R1807     -5.1968467235565186e-01
    z[1,4,6]  R1808     -3.6494970321655273e-01
    z[1,4,6]  R1809     -1.2957751750946045e-01
    z[1,4,6]  R1810     1.1584952473640442e-01
    z[1,4,6]  R1811     1.1547765135765076e-01
    z[1,4,6]  R1812     -1.2766093015670776e-01
    z[1,4,6]  R1813     1.0075343400239944e-01
    z[1,4,6]  R1814     2.5603345036506653e-01
    z[1,4,6]  R1815     3.4406366944313049e-01
    z[1,4,6]  R1816     -1.7734996974468231e-01
    z[1,4,6]  R1817     -0.0982140377163887
    z[1,4,6]  R1818     -1.2797258794307709e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1819     -1
    z[4,1,0]  R1820     1
    z[4,1,0]  R1833     -0.626301646232605
    z[4,1,0]  R1834     -8.4204000234603882e-01
    z[4,1,0]  R1835     -5.6200635433197021e-01
    z[4,1,0]  R1836     -5.3218764066696167e-01
    z[4,1,0]  R1837     -0.939971387386322
    z[4,1,0]  R1838     6.5989071130752563e-01
    z[4,1,0]  R1839     -9.3661779165267944e-01
    z[4,1,0]  R1840     5.6124496459960938e-01
    z[4,1,0]  R1841     -8.1057894229888916e-01
    z[4,1,0]  R1842     -8.1453180313110352e-01
    z[4,1,0]  R1843     -1.3804477453231812e-01
    z[4,1,0]  R1844     -1.4331266283988953e-01
    z[4,1,0]  R1845     1.3529990613460541e-01
    z[4,1,0]  R1846     1.8741910159587860e-01
    z[4,1,0]  R1847     1.1734388023614883e-01
    z[4,1,0]  R1848     -1.5084441751241684e-02
    z[4,1,0]  R1849     -4.1426301002502441e-01
    z[4,1,0]  R1850     8.9693886041641235e-01
    z[4,1,0]  R1851     7.0947146415710449e-01
    z[4,1,0]  R1852     0.85356205701828
    z[4,1,0]  R1853     6.7912268638610840e-01
    z[4,1,0]  R1854     4.6549555659294128e-01
    z[4,1,0]  R1855     -7.0993238687515259e-01
    z[4,1,0]  R1856     7.1068447828292847e-01
    z[4,1,0]  R1857     4.5530465245246887e-01
    z[4,1,0]  R1858     0.552579402923584
    z[4,1,0]  R1859     5.8852738142013550e-01
    z[4,1,0]  R1860     -3.5320860147476196e-01
    z[4,1,0]  R1861     -0.319614976644516
    z[4,1,0]  R1862     -2.3107655346393585e-01
    z[4,1,0]  R1863     3.3207225799560547e-01
    z[4,1,0]  R1864     2.2497600317001343e-01
    z[4,1,0]  R1865     4.0429782867431641e-01
    z[4,1,0]  R1866     1.1020505428314209e-01
    z[4,1,0]  R1867     3.3701881766319275e-01
    z[4,1,0]  R1868     0.297879159450531
    z[4,1,0]  R1869     3.9452165365219116e-01
    z[4,1,0]  R1870     2.0356547832489014e-01
    z[4,1,0]  R1871     -2.6331812143325806e-01
    z[4,1,0]  R1872     3.1959950923919678e-01
    z[4,1,0]  R1873     5.9074461460113525e-01
    z[4,1,0]  R1874     -4.1275955736637115e-02
    z[4,1,0]  R1875     -3.7504187226295471e-01
    z[4,1,0]  R1876     -5.7928526401519775e-01
    z[4,1,0]  R1877     -4.9910187721252441e-01
    z[4,1,0]  R1878     -6.3219177722930908e-01
    z[4,1,0]  R1879     -3.9742922782897949e-01
    z[4,1,0]  R1880     2.3084011673927307e-01
    z[4,1,0]  R1881     -9.3423920869827271e-01
    z[4,1,0]  R1882     -9.2440533638000488e-01
    z[4,1,0]  R1883     2.1656617522239685e-01
    z[4,1,0]  R1884     1.9144825637340546e-02
    z[4,1,0]  R1885     -5.2586293220520020e-01
    z[4,1,0]  R1886     3.0178827047348022e-01
    z[4,1,0]  R1887     2.0443785190582275e-01
    z[4,1,0]  R1888     -1.7751251161098480e-01
    z[4,1,0]  R1889     5.6899610906839371e-02
    z[4,1,0]  R1890     1.6422684490680695e-01
    z[4,1,0]  R1891     2.9473572969436646e-01
    z[4,1,0]  R1892     -6.5723603963851929e-01
    z[4,1,0]  R1893     9.5317848026752472e-02
    z[4,1,0]  R1894     -5.1086451858282089e-02
    z[4,1,0]  R1895     -2.1587809920310974e-01
    z[4,1,0]  R1896     7.7477765083312988e-01
    z[4,1,0]  R1897     7.0630115270614624e-01
    z[4,1,0]  R1898     5.0864154100418091e-01
    z[4,1,0]  R1899     5.3289115428924561e-01
    z[4,1,0]  R1900     3.1803345680236816e-01
    z[4,1,0]  R1901     -4.4739622622728348e-02
    z[4,1,0]  R1902     -5.8397495746612549e-01
    z[4,1,0]  R1903     -5.5687215179204941e-02
    z[4,1,0]  R1904     8.9335137605667114e-01
    z[4,1,0]  R1905     -1.7038933932781219e-01
    z[4,1,0]  R1906     -3.7038710713386536e-01
    z[4,1,0]  R1907     -6.0038655996322632e-01
    z[4,1,0]  R1908     4.6409547328948975e-01
    z[4,1,0]  R1909     4.3099871277809143e-01
    z[4,1,0]  R1910     4.7354349493980408e-01
    z[4,1,0]  R1911     4.6459159255027771e-01
    z[4,1,0]  R1912     4.6672913432121277e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1821     -1
    z[4,1,1]  R1822     1
    z[4,1,1]  R1833     -0.575942873954773
    z[4,1,1]  R1834     -8.1678695976734161e-02
    z[4,1,1]  R1835     -1.9468982517719269e-01
    z[4,1,1]  R1836     -8.7245449423789978e-02
    z[4,1,1]  R1837     -1.4296740293502808e-01
    z[4,1,1]  R1838     1.5793354809284210e-01
    z[4,1,1]  R1839     6.2615498900413513e-02
    z[4,1,1]  R1840     -8.5508622229099274e-02
    z[4,1,1]  R1841     2.1103753149509430e-01
    z[4,1,1]  R1842     0.0857396051287651
    z[4,1,1]  R1843     8.7869238853454590e-01
    z[4,1,1]  R1844     7.4564278125762939e-01
    z[4,1,1]  R1845     0.814132571220398
    z[4,1,1]  R1846     8.3106732368469238e-01
    z[4,1,1]  R1847     0.913650393486023
    z[4,1,1]  R1848     9.2196524143218994e-01
    z[4,1,1]  R1849     6.8651187419891357e-01
    z[4,1,1]  R1850     -3.4975543618202209e-01
    z[4,1,1]  R1851     -2.1639437973499298e-01
    z[4,1,1]  R1852     3.3483337610960007e-02
    z[4,1,1]  R1853     -5.4730284214019775e-01
    z[4,1,1]  R1854     -1.0956397652626038e-01
    z[4,1,1]  R1855     0.00622505834326148
    z[4,1,1]  R1856     5.1804497838020325e-02
    z[4,1,1]  R1857     -2.2204600274562836e-01
    z[4,1,1]  R1858     -2.3661231622099876e-02
    z[4,1,1]  R1859     2.3132576048374176e-01
    z[4,1,1]  R1860     -6.3067066669464111e-01
    z[4,1,1]  R1861     -8.3851498365402222e-01
    z[4,1,1]  R1862     -6.7305499315261841e-01
    z[4,1,1]  R1863     -8.4220498800277710e-02
    z[4,1,1]  R1864     0.361508309841156
    z[4,1,1]  R1865     4.8457989096641541e-01
    z[4,1,1]  R1866     -3.2911914587020874e-01
    z[4,1,1]  R1867     3.3398628234863281e-01
    z[4,1,1]  R1868     -4.8228830099105835e-01
    z[4,1,1]  R1869     -1.9169540703296661e-01
    z[4,1,1]  R1870     2.1775195002555847e-01
    z[4,1,1]  R1871     -2.4984495341777802e-01
    z[4,1,1]  R1872     2.1840962767601013e-01
    z[4,1,1]  R1873     3.6695379018783569e-01
    z[4,1,1]  R1874     6.5316796302795410e-01
    z[4,1,1]  R1875     0.657727062702179
    z[4,1,1]  R1876     6.4585006237030029e-01
    z[4,1,1]  R1877     7.4338763952255249e-01
    z[4,1,1]  R1878     7.0508313179016113e-01
    z[4,1,1]  R1879     7.9247128963470459e-01
    z[4,1,1]  R1880     8.2078307867050171e-01
    z[4,1,1]  R1881     3.3597180247306824e-01
    z[4,1,1]  R1882     3.2437753677368164e-01
    z[4,1,1]  R1883     8.7639510631561279e-01
    z[4,1,1]  R1884     0.31130251288414
    z[4,1,1]  R1885     -4.1803106665611267e-01
    z[4,1,1]  R1886     1.0529877245426178e-01
    z[4,1,1]  R1887     1.0849340260028839e-01
    z[4,1,1]  R1888     2.3467201739549637e-02
    z[4,1,1]  R1889     -2.1112029254436493e-01
    z[4,1,1]  R1890     1.6639775037765503e-01
    z[4,1,1]  R1891     -6.7488527856767178e-03
    z[4,1,1]  R1892     -6.3168264925479889e-02
    z[4,1,1]  R1893     0.547184944152832
    z[4,1,1]  R1894     1.0742236673831940e-01
    z[4,1,1]  R1895     0.407914936542511
    z[4,1,1]  R1896     4.4724959135055542e-01
    z[4,1,1]  R1897     3.4217163920402527e-01
    z[4,1,1]  R1898     1.4415302872657776e-01
    z[4,1,1]  R1899     3.5020154714584351e-01
    z[4,1,1]  R1900     3.6574858427047729e-01
    z[4,1,1]  R1901     -4.1784530878067017e-01
    z[4,1,1]  R1902     -3.3625042438507080e-01
    z[4,1,1]  R1903     8.6969435214996338e-01
    z[4,1,1]  R1904     8.6631134152412415e-02
    z[4,1,1]  R1905     1.4700804650783539e-01
    z[4,1,1]  R1906     -3.5427924990653992e-01
    z[4,1,1]  R1907     -6.7064750194549561e-01
    z[4,1,1]  R1908     -7.4182587862014771e-01
    z[4,1,1]  R1909     -7.4127340316772461e-01
    z[4,1,1]  R1910     -7.2319769859313965e-01
    z[4,1,1]  R1911     -7.1683096885681152e-01
    z[4,1,1]  R1912     -6.9388502836227417e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1823     -1
    z[4,1,2]  R1824     1
    z[4,1,2]  R1833     3.8755902647972107e-01
    z[4,1,2]  R1834     4.8647314310073853e-01
    z[4,1,2]  R1835     6.0824459791183472e-01
    z[4,1,2]  R1836     4.3417137861251831e-01
    z[4,1,2]  R1837     -1.4967535436153412e-01
    z[4,1,2]  R1838     -4.1559547185897827e-01
    z[4,1,2]  R1839     -1.9692401587963104e-01
    z[4,1,2]  R1840     -1.1192564666271210e-01
    z[4,1,2]  R1841     -1.9925747811794281e-01
    z[4,1,2]  R1842     4.4076152145862579e-02
    z[4,1,2]  R1843     -0.348624587059021
    z[4,1,2]  R1844     -5.3115451335906982e-01
    z[4,1,2]  R1845     -3.2606229186058044e-01
    z[4,1,2]  R1846     -2.7933281660079956e-01
    z[4,1,2]  R1847     -0.0719640925526619
    z[4,1,2]  R1848     -0.0854223445057869
    z[4,1,2]  R1849     -3.4509435296058655e-01
    z[4,1,2]  R1850     1.6582074761390686e-01
    z[4,1,2]  R1851     2.6561295986175537e-01
    z[4,1,2]  R1852     3.1241217255592346e-01
    z[4,1,2]  R1853     3.5691785160452127e-03
    z[4,1,2]  R1854     -2.1841278672218323e-01
    z[4,1,2]  R1855     3.8633834570646286e-02
    z[4,1,2]  R1856     1.4892983436584473e-01
    z[4,1,2]  R1857     -1.7980413138866425e-01
    z[4,1,2]  R1858     0.190543994307518
    z[4,1,2]  R1859     1.6353680193424225e-01
    z[4,1,2]  R1860     -0.352943480014801
    z[4,1,2]  R1861     -8.0922663211822510e-02
    z[4,1,2]  R1862     -1.6812250018119812e-02
    z[4,1,2]  R1863     7.9628866910934448e-01
    z[4,1,2]  R1864     6.2952286005020142e-01
    z[4,1,2]  R1865     2.3803453147411346e-01
    z[4,1,2]  R1866     3.5012251138687134e-01
    z[4,1,2]  R1867     1.6661569476127625e-01
    z[4,1,2]  R1868     3.0057954788208008e-01
    z[4,1,2]  R1869     -7.2683282196521759e-02
    z[4,1,2]  R1870     -2.0050784945487976e-01
    z[4,1,2]  R1871     5.0285577774047852e-01
    z[4,1,2]  R1872     0.00567758409306407
    z[4,1,2]  R1873     -2.1179307997226715e-01
    z[4,1,2]  R1874     -5.8393353223800659e-01
    z[4,1,2]  R1875     -4.0201231837272644e-01
    z[4,1,2]  R1876     -3.8458973169326782e-01
    z[4,1,2]  R1877     4.2064037173986435e-02
    z[4,1,2]  R1878     -2.8824952244758606e-01
    z[4,1,2]  R1879     -2.4844953417778015e-01
    z[4,1,2]  R1880     -1.5014594793319702e-01
    z[4,1,2]  R1881     -3.6241721361875534e-02
    z[4,1,2]  R1882     1.1564271897077560e-01
    z[4,1,2]  R1883     1.7821869254112244e-01
    z[4,1,2]  R1884     -2.7339941263198853e-01
    z[4,1,2]  R1885     -6.2284684181213379e-01
    z[4,1,2]  R1886     9.8502419888973236e-02
    z[4,1,2]  R1887     -8.4907189011573792e-02
    z[4,1,2]  R1888     -3.7734252214431763e-01
    z[4,1,2]  R1889     1.1531513929367065e-01
    z[4,1,2]  R1890     -3.3423385024070740e-01
    z[4,1,2]  R1891     6.3833691179752350e-02
    z[4,1,2]  R1892     -3.4744244813919067e-01
    z[4,1,2]  R1893     -3.5237598419189453e-01
    z[4,1,2]  R1894     1.0244900733232498e-01
    z[4,1,2]  R1895     -7.7153556048870087e-02
    z[4,1,2]  R1896     -1.8872264027595520e-01
    z[4,1,2]  R1897     -5.5572193115949631e-02
    z[4,1,2]  R1898     7.1593075990676880e-02
    z[4,1,2]  R1899     1.0369773954153061e-02
    z[4,1,2]  R1900     -8.3991587162017822e-02
    z[4,1,2]  R1901     9.6030756831169128e-03
    z[4,1,2]  R1902     -3.5265704989433289e-01
    z[4,1,2]  R1903     -2.3279662430286407e-01
    z[4,1,2]  R1904     2.2210830822587013e-02
    z[4,1,2]  R1905     1.0618493705987930e-01
    z[4,1,2]  R1906     -1.7527283728122711e-01
    z[4,1,2]  R1907     3.4023147821426392e-01
    z[4,1,2]  R1908     -3.2223331928253174e-01
    z[4,1,2]  R1909     -1.6301706433296204e-01
    z[4,1,2]  R1910     -1.1810306459665298e-01
    z[4,1,2]  R1911     -2.4931703507900238e-01
    z[4,1,2]  R1912     -0.291786253452301
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1825     -1
    z[4,1,3]  R1826     1
    z[4,1,3]  R1833     -1.1291564255952835e-01
    z[4,1,3]  R1834     -4.3126974254846573e-02
    z[4,1,3]  R1835     -8.4073126316070557e-02
    z[4,1,3]  R1836     -1.1861911416053772e-01
    z[4,1,3]  R1837     -2.1147488057613373e-01
    z[4,1,3]  R1838     1.1938295327126980e-02
    z[4,1,3]  R1839     -3.3003918826580048e-02
    z[4,1,3]  R1840     -7.1461528539657593e-02
    z[4,1,3]  R1841     -3.5813751816749573e-01
    z[4,1,3]  R1842     3.7784200906753540e-01
    z[4,1,3]  R1843     2.3530612885951996e-01
    z[4,1,3]  R1844     -1.9758237898349762e-01
    z[4,1,3]  R1845     3.5624884068965912e-02
    z[4,1,3]  R1846     -0.330709308385849
    z[4,1,3]  R1847     1.2008894234895706e-01
    z[4,1,3]  R1848     -4.6502269804477692e-02
    z[4,1,3]  R1849     -2.7664867043495178e-01
    z[4,1,3]  R1850     -7.3545746505260468e-02
    z[4,1,3]  R1851     -1.3987350463867188e-01
    z[4,1,3]  R1852     7.3284611105918884e-02
    z[4,1,3]  R1853     -1.9933162629604340e-01
    z[4,1,3]  R1854     -1.5276260673999786e-01
    z[4,1,3]  R1855     5.7509493827819824e-01
    z[4,1,3]  R1856     -4.4765692949295044e-01
    z[4,1,3]  R1857     -7.7382522821426392e-01
    z[4,1,3]  R1858     7.6344740390777588e-01
    z[4,1,3]  R1859     5.8561843633651733e-01
    z[4,1,3]  R1860     4.7341939806938171e-01
    z[4,1,3]  R1861     2.2318008542060852e-01
    z[4,1,3]  R1862     3.6834666132926941e-01
    z[4,1,3]  R1863     -1.0823883116245270e-01
    z[4,1,3]  R1864     0.356587290763855
    z[4,1,3]  R1865     6.0027605295181274e-01
    z[4,1,3]  R1866     5.1075166463851929e-01
    z[4,1,3]  R1867     5.3740882873535156e-01
    z[4,1,3]  R1868     1.0916360467672348e-01
    z[4,1,3]  R1869     4.9610521644353867e-02
    z[4,1,3]  R1870     2.6247090101242065e-01
    z[4,1,3]  R1871     3.9771571755409241e-01
    z[4,1,3]  R1872     4.4433519244194031e-01
    z[4,1,3]  R1873     2.9319867491722107e-01
    z[4,1,3]  R1874     -1.5360046923160553e-01
    z[4,1,3]  R1875     -2.7590749785304070e-02
    z[4,1,3]  R1876     2.2711518406867981e-01
    z[4,1,3]  R1877     -1.6082301735877991e-01
    z[4,1,3]  R1878     -6.8718180060386658e-02
    z[4,1,3]  R1879     3.1026366353034973e-01
    z[4,1,3]  R1880     -5.8440599590539932e-02
    z[4,1,3]  R1881     -4.1871690191328526e-03
    z[4,1,3]  R1882     -4.1127860546112061e-02
    z[4,1,3]  R1883     -3.3243077993392944e-01
    z[4,1,3]  R1884     -6.8526461720466614e-02
    z[4,1,3]  R1885     -8.7724313139915466e-02
    z[4,1,3]  R1886     -3.5257175564765930e-01
    z[4,1,3]  R1887     -2.9554140567779541e-01
    z[4,1,3]  R1888     -2.9453948140144348e-01
    z[4,1,3]  R1889     -3.3523476123809814e-01
    z[4,1,3]  R1890     -3.7054210901260376e-01
    z[4,1,3]  R1891     -4.7129637002944946e-01
    z[4,1,3]  R1892     -3.0005259439349174e-02
    z[4,1,3]  R1893     -3.7874984741210938e-01
    z[4,1,3]  R1894     9.7439870238304138e-02
    z[4,1,3]  R1895     -3.0197608470916748e-01
    z[4,1,3]  R1896     -2.0218986272811890e-01
    z[4,1,3]  R1897     -1.5474145114421844e-01
    z[4,1,3]  R1898     -4.0473595261573792e-02
    z[4,1,3]  R1899     9.7739197313785553e-02
    z[4,1,3]  R1900     -2.5048962235450745e-01
    z[4,1,3]  R1901     -3.2698279619216919e-01
    z[4,1,3]  R1902     -2.5443577766418457e-01
    z[4,1,3]  R1903     -1.5198162198066711e-01
    z[4,1,3]  R1904     -3.0203291773796082e-01
    z[4,1,3]  R1905     -3.0847027897834778e-01
    z[4,1,3]  R1906     -3.9656361937522888e-01
    z[4,1,3]  R1907     -9.1805262491106987e-03
    z[4,1,3]  R1908     -1.6141927242279053e-01
    z[4,1,3]  R1909     -2.9566857218742371e-01
    z[4,1,3]  R1910     -1.8786433339118958e-01
    z[4,1,3]  R1911     -3.1983304023742676e-01
    z[4,1,3]  R1912     1.8618069589138031e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1827     -1
    z[4,1,4]  R1828     1
    z[4,1,4]  R1833     -1.3108095526695251e-01
    z[4,1,4]  R1834     1.7517803609371185e-01
    z[4,1,4]  R1835     -5.0521481037139893e-01
    z[4,1,4]  R1836     -3.7098596803843975e-03
    z[4,1,4]  R1837     -7.8253731131553650e-02
    z[4,1,4]  R1838     1.8952155485749245e-02
    z[4,1,4]  R1839     1.0351741313934326e-01
    z[4,1,4]  R1840     -3.0360710620880127e-01
    z[4,1,4]  R1841     -2.0744135975837708e-01
    z[4,1,4]  R1842     -2.9577660560607910e-01
    z[4,1,4]  R1843     6.2534660100936890e-02
    z[4,1,4]  R1844     2.8456097841262817e-01
    z[4,1,4]  R1845     4.0337464213371277e-01
    z[4,1,4]  R1846     7.7082134783267975e-02
    z[4,1,4]  R1847     1.1331208795309067e-01
    z[4,1,4]  R1848     -2.6226335763931274e-01
    z[4,1,4]  R1849     -3.4285095334053040e-01
    z[4,1,4]  R1850     8.8250853121280670e-02
    z[4,1,4]  R1851     2.7964314818382263e-01
    z[4,1,4]  R1852     8.8019356131553650e-02
    z[4,1,4]  R1853     3.6297035217285156e-01
    z[4,1,4]  R1854     6.8603962659835815e-02
    z[4,1,4]  R1855     2.4468223750591278e-01
    z[4,1,4]  R1856     -4.6644932031631470e-01
    z[4,1,4]  R1857     -3.0253347754478455e-01
    z[4,1,4]  R1858     3.5661216825246811e-02
    z[4,1,4]  R1859     -2.8646424412727356e-01
    z[4,1,4]  R1860     -1.2093091756105423e-01
    z[4,1,4]  R1861     8.1553466618061066e-02
    z[4,1,4]  R1862     -5.2477353811264038e-01
    z[4,1,4]  R1863     1.4760370831936598e-03
    z[4,1,4]  R1864     4.1524812579154968e-02
    z[4,1,4]  R1865     -2.6050312444567680e-02
    z[4,1,4]  R1866     5.8437857776880264e-02
    z[4,1,4]  R1867     -1.7981484532356262e-01
    z[4,1,4]  R1868     -7.4437371222302318e-04
    z[4,1,4]  R1869     2.3300166428089142e-01
    z[4,1,4]  R1870     2.0796832442283630e-01
    z[4,1,4]  R1871     1.1065878719091415e-01
    z[4,1,4]  R1872     2.0427180826663971e-01
    z[4,1,4]  R1873     1.6974899172782898e-01
    z[4,1,4]  R1874     -4.4538193941116333e-01
    z[4,1,4]  R1875     -3.1974750757217407e-01
    z[4,1,4]  R1876     -1.9922609627246857e-01
    z[4,1,4]  R1877     -2.7087783813476562e-01
    z[4,1,4]  R1878     2.0275993272662163e-02
    z[4,1,4]  R1879     1.0352526605129242e-01
    z[4,1,4]  R1880     -1.5411649644374847e-01
    z[4,1,4]  R1881     -9.2224171385169029e-03
    z[4,1,4]  R1882     1.1496607959270477e-01
    z[4,1,4]  R1883     1.1724268645048141e-01
    z[4,1,4]  R1884     8.7437534332275391e-01
    z[4,1,4]  R1885     -1.4307887852191925e-01
    z[4,1,4]  R1886     8.4778529405593872e-01
    z[4,1,4]  R1887     5.1797825098037720e-01
    z[4,1,4]  R1888     7.7364194393157959e-01
    z[4,1,4]  R1889     8.4896445274353027e-01
    z[4,1,4]  R1890     0.667140781879425
    z[4,1,4]  R1891     6.5066725015640259e-01
    z[4,1,4]  R1892     -2.4185539782047272e-01
    z[4,1,4]  R1893     -8.3446763455867767e-02
    z[4,1,4]  R1894     8.9992147684097290e-01
    z[4,1,4]  R1895     -2.5832799077033997e-01
    z[4,1,4]  R1896     1.7638940364122391e-02
    z[4,1,4]  R1897     -4.6297335624694824e-01
    z[4,1,4]  R1898     -7.9953235387802124e-01
    z[4,1,4]  R1899     -7.4610334634780884e-01
    z[4,1,4]  R1900     7.0542466640472412e-01
    z[4,1,4]  R1901     6.1648392677307129e-01
    z[4,1,4]  R1902     1.2818135321140289e-01
    z[4,1,4]  R1903     2.1970003843307495e-01
    z[4,1,4]  R1904     -2.5865370035171509e-01
    z[4,1,4]  R1905     6.4369821548461914e-01
    z[4,1,4]  R1906     5.0892108678817749e-01
    z[4,1,4]  R1907     -1.2675713002681732e-01
    z[4,1,4]  R1908     9.5251753926277161e-02
    z[4,1,4]  R1909     -7.3320806026458740e-02
    z[4,1,4]  R1910     -5.4239153861999512e-02
    z[4,1,4]  R1911     -1.0252785682678223e-01
    z[4,1,4]  R1912     2.8734045103192329e-02
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1829     -1
    z[4,1,5]  R1830     1
    z[4,1,5]  R1833     -2.7850124239921570e-01
    z[4,1,5]  R1834     1.2280213832855225e-01
    z[4,1,5]  R1835     4.8055514693260193e-02
    z[4,1,5]  R1836     -3.5813519358634949e-01
    z[4,1,5]  R1837     8.1823609769344330e-02
    z[4,1,5]  R1838     -3.6321735382080078e-01
    z[4,1,5]  R1839     -2.6041004061698914e-01
    z[4,1,5]  R1840     -6.7825573682785034e-01
    z[4,1,5]  R1841     -1.2281390838325024e-02
    z[4,1,5]  R1842     3.1469874083995819e-02
    z[4,1,5]  R1843     5.8050606399774551e-02
    z[4,1,5]  R1844     -1.4533384144306183e-01
    z[4,1,5]  R1845     1.5770610189065337e-03
    z[4,1,5]  R1846     1.1847331374883652e-01
    z[4,1,5]  R1847     -4.4052530080080032e-02
    z[4,1,5]  R1848     2.4003873765468597e-01
    z[4,1,5]  R1849     -1.1766491085290909e-01
    z[4,1,5]  R1850     1.6332441568374634e-01
    z[4,1,5]  R1851     -1.0694076865911484e-01
    z[4,1,5]  R1852     1.6248992085456848e-01
    z[4,1,5]  R1853     -2.2576166689395905e-01
    z[4,1,5]  R1854     -8.2591855525970459e-01
    z[4,1,5]  R1855     3.0087551474571228e-01
    z[4,1,5]  R1856     -1.8919488787651062e-01
    z[4,1,5]  R1857     -1.0286095738410950e-01
    z[4,1,5]  R1858     -9.0068064630031586e-02
    z[4,1,5]  R1859     1.7317394912242889e-01
    z[4,1,5]  R1860     2.8762108087539673e-01
    z[4,1,5]  R1861     3.4940522909164429e-01
    z[4,1,5]  R1862     2.5666022300720215e-01
    z[4,1,5]  R1863     -4.6309524774551392e-01
    z[4,1,5]  R1864     -4.9777108430862427e-01
    z[4,1,5]  R1865     -4.2009532451629639e-01
    z[4,1,5]  R1866     -7.0185315608978271e-01
    z[4,1,5]  R1867     -6.2715178728103638e-01
    z[4,1,5]  R1868     -0.702717125415802
    z[4,1,5]  R1869     -7.4101728200912476e-01
    z[4,1,5]  R1870     -8.6752545833587646e-01
    z[4,1,5]  R1871     -3.7044957280158997e-01
    z[4,1,5]  R1872     -1.9174227118492126e-01
    z[4,1,5]  R1873     -4.8559173941612244e-01
    z[4,1,5]  R1874     -1.7354622483253479e-02
    z[4,1,5]  R1875     -7.6631464064121246e-02
    z[4,1,5]  R1876     5.7139031589031219e-02
    z[4,1,5]  R1877     1.1248541623353958e-01
    z[4,1,5]  R1878     1.1797171086072922e-01
    z[4,1,5]  R1879     2.0577445626258850e-01
    z[4,1,5]  R1880     4.0649777650833130e-01
    z[4,1,5]  R1881     -1.2953018769621849e-02
    z[4,1,5]  R1882     7.9326741397380829e-02
    z[4,1,5]  R1883     -1.7031390964984894e-01
    z[4,1,5]  R1884     0.214023619890213
    z[4,1,5]  R1885     3.6025542020797729e-01
    z[4,1,5]  R1886     1.0420871526002884e-01
    z[4,1,5]  R1887     7.6388245820999146e-01
    z[4,1,5]  R1888     -2.0823728293180466e-02
    z[4,1,5]  R1889     3.0105376243591309e-01
    z[4,1,5]  R1890     -2.1040309220552444e-02
    z[4,1,5]  R1891     4.6810010075569153e-01
    z[4,1,5]  R1892     5.6569927930831909e-01
    z[4,1,5]  R1893     -5.4583930969238281e-01
    z[4,1,5]  R1894     -2.8972637653350830e-01
    z[4,1,5]  R1895     -7.1383011341094971e-01
    z[4,1,5]  R1896     1.3720458745956421e-01
    z[4,1,5]  R1897     1.3389253616333008e-01
    z[4,1,5]  R1898     -0.0657874047756195
    z[4,1,5]  R1899     5.4046556353569031e-02
    z[4,1,5]  R1900     -1.2181343883275986e-01
    z[4,1,5]  R1901     5.0305038690567017e-01
    z[4,1,5]  R1902     5.5670654773712158e-01
    z[4,1,5]  R1903     -3.3804804086685181e-01
    z[4,1,5]  R1904     1.0120960325002670e-01
    z[4,1,5]  R1905     5.6893342733383179e-01
    z[4,1,5]  R1906     5.1979804039001465e-01
    z[4,1,5]  R1907     7.6164029538631439e-02
    z[4,1,5]  R1908     2.9966291785240173e-01
    z[4,1,5]  R1909     2.8683552145957947e-01
    z[4,1,5]  R1910     4.4693747162818909e-01
    z[4,1,5]  R1911     3.0494108796119690e-01
    z[4,1,5]  R1912     3.9764198660850525e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1831     -1
    z[4,1,6]  R1832     1
    z[4,1,6]  R1833     1.3542146980762482e-01
    z[4,1,6]  R1834     -0.00367422285489738
    z[4,1,6]  R1835     -1.0799888521432877e-01
    z[4,1,6]  R1836     -6.1507290601730347e-01
    z[4,1,6]  R1837     1.2677150964736938e-01
    z[4,1,6]  R1838     4.8420354723930359e-01
    z[4,1,6]  R1839     2.0706895738840103e-02
    z[4,1,6]  R1840     3.2840543985366821e-01
    z[4,1,6]  R1841     -2.9542544484138489e-01
    z[4,1,6]  R1842     3.0984729528427124e-01
    z[4,1,6]  R1843     1.5701831877231598e-01
    z[4,1,6]  R1844     -1.4757920987904072e-02
    z[4,1,6]  R1845     -2.2041529417037964e-01
    z[4,1,6]  R1846     -2.5851166248321533e-01
    z[4,1,6]  R1847     -3.4218841791152954e-01
    z[4,1,6]  R1848     -1.1786611378192902e-01
    z[4,1,6]  R1849     1.7341071367263794e-01
    z[4,1,6]  R1850     -7.6179198920726776e-02
    z[4,1,6]  R1851     -5.1968467235565186e-01
    z[4,1,6]  R1852     -3.6494970321655273e-01
    z[4,1,6]  R1853     -1.2957751750946045e-01
    z[4,1,6]  R1854     1.1584952473640442e-01
    z[4,1,6]  R1855     1.1547765135765076e-01
    z[4,1,6]  R1856     -1.2766093015670776e-01
    z[4,1,6]  R1857     1.0075343400239944e-01
    z[4,1,6]  R1858     2.5603345036506653e-01
    z[4,1,6]  R1859     3.4406366944313049e-01
    z[4,1,6]  R1860     -1.7734996974468231e-01
    z[4,1,6]  R1861     -0.0982140377163887
    z[4,1,6]  R1862     -1.2797258794307709e-01
    z[4,1,6]  R1863     -1.4961341023445129e-01
    z[4,1,6]  R1864     2.1387757360935211e-01
    z[4,1,6]  R1865     0.087035171687603
    z[4,1,6]  R1866     -8.3404621109366417e-03
    z[4,1,6]  R1867     -1.8069240450859070e-01
    z[4,1,6]  R1868     0.287383496761322
    z[4,1,6]  R1869     -4.4324392080307007e-01
    z[4,1,6]  R1870     7.8737497329711914e-02
    z[4,1,6]  R1871     5.5472618341445923e-01
    z[4,1,6]  R1872     7.5775671005249023e-01
    z[4,1,6]  R1873     3.4774962067604065e-01
    z[4,1,6]  R1874     9.1815330088138580e-02
    z[4,1,6]  R1875     -3.9528802037239075e-01
    z[4,1,6]  R1876     0.0697116032242775
    z[4,1,6]  R1877     2.9087954759597778e-01
    z[4,1,6]  R1878     3.2448939979076385e-02
    z[4,1,6]  R1879     -5.4661218076944351e-02
    z[4,1,6]  R1880     -2.4099057912826538e-01
    z[4,1,6]  R1881     -1.1285389959812164e-01
    z[4,1,6]  R1882     7.5361780822277069e-02
    z[4,1,6]  R1883     -2.4202053900808096e-03
    z[4,1,6]  R1884     1.1376570910215378e-01
    z[4,1,6]  R1885     5.3188685327768326e-02
    z[4,1,6]  R1886     -1.8500572443008423e-01
    z[4,1,6]  R1887     -7.9107824712991714e-03
    z[4,1,6]  R1888     -3.7395489215850830e-01
    z[4,1,6]  R1889     0.123031385242939
    z[4,1,6]  R1890     -5.0080728530883789e-01
    z[4,1,6]  R1891     -2.1072435379028320e-01
    z[4,1,6]  R1892     -2.5283247232437134e-01
    z[4,1,6]  R1893     3.4493315219879150e-01
    z[4,1,6]  R1894     2.6844039559364319e-01
    z[4,1,6]  R1895     -3.3700618147850037e-01
    z[4,1,6]  R1896     -3.2257422804832458e-01
    z[4,1,6]  R1897     -3.5320317745208740e-01
    z[4,1,6]  R1898     -2.6487755775451660e-01
    z[4,1,6]  R1899     -1.5535186231136322e-01
    z[4,1,6]  R1900     -4.2757540941238403e-01
    z[4,1,6]  R1901     2.8858572244644165e-01
    z[4,1,6]  R1902     -1.7450398206710815e-01
    z[4,1,6]  R1903     -2.6332248002290726e-02
    z[4,1,6]  R1904     -0.159862220287323
    z[4,1,6]  R1905     -3.2387372851371765e-01
    z[4,1,6]  R1906     -1.4186498522758484e-01
    z[4,1,6]  R1907     -2.2816176712512970e-01
    z[4,1,6]  R1908     -0.0744878277182579
    z[4,1,6]  R1909     -2.5121471285820007e-01
    z[4,1,6]  R1910     -2.8377154842019081e-02
    z[4,1,6]  R1911     -4.8527400940656662e-02
    z[4,1,6]  R1912     1.4812238514423370e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1913     -1
    z[2,4,0]  R1914     1
    z[2,4,0]  R1927     -7.4349719285964966e-01
    z[2,4,0]  R1928     -9.0440279245376587e-01
    z[2,4,0]  R1929     -6.5755015611648560e-01
    z[2,4,0]  R1930     -3.6882689595222473e-01
    z[2,4,0]  R1931     -1.4272942207753658e-02
    z[2,4,0]  R1932     4.3630054593086243e-01
    z[2,4,0]  R1933     3.0258023738861084e-01
    z[2,4,0]  R1934     1.9868750870227814e-01
    z[2,4,0]  R1935     3.1030893325805664e-01
    z[2,4,0]  R1936     2.8834110498428345e-01
    z[2,4,0]  R1937     2.7444690465927124e-01
    z[2,4,0]  R1938     -0.0762915164232254
    z[2,4,0]  R1939     -2.3704680800437927e-01
    z[2,4,0]  R1940     -0.0945655107498169
    z[2,4,0]  R1941     -6.8223255872726440e-01
    z[2,4,0]  R1942     -6.3873386383056641e-01
    z[2,4,0]  R1943     -6.0326629877090454e-01
    z[2,4,0]  R1944     -6.0984796285629272e-01
    z[2,4,0]  R1945     5.6926918029785156e-01
    z[2,4,0]  R1946     -5.7782799005508423e-02
    z[2,4,0]  R1947     -6.3951557874679565e-01
    z[2,4,0]  R1948     -6.9014227390289307e-01
    z[2,4,0]  R1949     4.5249709486961365e-01
    z[2,4,0]  R1950     -6.7513942718505859e-02
    z[2,4,0]  R1951     -1.5221396088600159e-01
    z[2,4,0]  R1952     -3.7763002514839172e-01
    z[2,4,0]  R1953     -3.0197069048881531e-01
    z[2,4,0]  R1954     5.5052733421325684e-01
    z[2,4,0]  R1955     0.402831107378006
    z[2,4,0]  R1956     0.676831066608429
    z[2,4,0]  R1957     1.1956851184368134e-01
    z[2,4,0]  R1958     -7.8148734569549561e-01
    z[2,4,0]  R1959     6.5265917778015137e-01
    z[2,4,0]  R1960     -7.2481507062911987e-01
    z[2,4,0]  R1961     3.8184890151023865e-01
    z[2,4,0]  R1962     4.3753212690353394e-01
    z[2,4,0]  R1963     -7.1952289342880249e-01
    z[2,4,0]  R1964     4.2336440086364746e-01
    z[2,4,0]  R1965     -1.8188993632793427e-01
    z[2,4,0]  R1966     0.668256938457489
    z[2,4,0]  R1967     4.7530296444892883e-01
    z[2,4,0]  R1968     7.9442560672760010e-01
    z[2,4,0]  R1969     0.531466007232666
    z[2,4,0]  R1970     5.7659108191728592e-02
    z[2,4,0]  R1971     3.7302851676940918e-01
    z[2,4,0]  R1972     1.3967619836330414e-01
    z[2,4,0]  R1973     9.8253987729549408e-02
    z[2,4,0]  R1974     -1.2154962867498398e-02
    z[2,4,0]  R1975     3.6504435539245605e-01
    z[2,4,0]  R1976     2.6145428419113159e-01
    z[2,4,0]  R1977     1.4792186021804810e-01
    z[2,4,0]  R1978     1.0102129727602005e-01
    z[2,4,0]  R1979     -7.0512253046035767e-01
    z[2,4,0]  R1980     3.8878908753395081e-01
    z[2,4,0]  R1981     3.1997001171112061e-01
    z[2,4,0]  R1982     2.2307321429252625e-01
    z[2,4,0]  R1983     2.2730773314833641e-02
    z[2,4,0]  R1984     5.2008849382400513e-01
    z[2,4,0]  R1985     -2.0841567218303680e-01
    z[2,4,0]  R1986     -0.626301646232605
    z[2,4,0]  R1987     -8.4204000234603882e-01
    z[2,4,0]  R1988     -5.6200635433197021e-01
    z[2,4,0]  R1989     -5.3218764066696167e-01
    z[2,4,0]  R1990     -0.939971387386322
    z[2,4,0]  R1991     6.5989071130752563e-01
    z[2,4,0]  R1992     -9.3661779165267944e-01
    z[2,4,0]  R1993     5.6124496459960938e-01
    z[2,4,0]  R1994     -8.1057894229888916e-01
    z[2,4,0]  R1995     -8.1453180313110352e-01
    z[2,4,0]  R1996     -1.3804477453231812e-01
    z[2,4,0]  R1997     -1.4331266283988953e-01
    z[2,4,0]  R1998     1.3529990613460541e-01
    z[2,4,0]  R1999     1.8741910159587860e-01
    z[2,4,0]  R2000     1.1734388023614883e-01
    z[2,4,0]  R2001     -1.5084441751241684e-02
    z[2,4,0]  R2002     -4.1426301002502441e-01
    z[2,4,0]  R2003     8.9693886041641235e-01
    z[2,4,0]  R2004     7.0947146415710449e-01
    z[2,4,0]  R2005     0.85356205701828
    z[2,4,0]  R2006     6.7912268638610840e-01
    z[2,4,0]  R2007     4.6549555659294128e-01
    z[2,4,0]  R2008     -7.0993238687515259e-01
    z[2,4,0]  R2009     7.1068447828292847e-01
    z[2,4,0]  R2010     4.5530465245246887e-01
    z[2,4,0]  R2011     0.552579402923584
    z[2,4,0]  R2012     5.8852738142013550e-01
    z[2,4,0]  R2013     -3.5320860147476196e-01
    z[2,4,0]  R2014     -0.319614976644516
    z[2,4,0]  R2015     -2.3107655346393585e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1915     -1
    z[2,4,1]  R1916     1
    z[2,4,1]  R1927     -1.6133917868137360e-01
    z[2,4,1]  R1928     -1.8875263631343842e-01
    z[2,4,1]  R1929     -1.4964066445827484e-01
    z[2,4,1]  R1930     -6.5964251756668091e-01
    z[2,4,1]  R1931     7.8889004886150360e-02
    z[2,4,1]  R1932     1.8604267388582230e-02
    z[2,4,1]  R1933     -1.1806106194853783e-02
    z[2,4,1]  R1934     5.4581854492425919e-02
    z[2,4,1]  R1935     -1.2077865749597549e-01
    z[2,4,1]  R1936     5.2824807353317738e-03
    z[2,4,1]  R1937     8.4847694635391235e-01
    z[2,4,1]  R1938     8.0799955129623413e-01
    z[2,4,1]  R1939     7.9552549123764038e-01
    z[2,4,1]  R1940     8.1549555063247681e-01
    z[2,4,1]  R1941     3.7019926309585571e-01
    z[2,4,1]  R1942     2.2374063730239868e-01
    z[2,4,1]  R1943     8.6924374103546143e-02
    z[2,4,1]  R1944     3.7069177627563477e-01
    z[2,4,1]  R1945     3.9249441027641296e-01
    z[2,4,1]  R1946     6.4467805624008179e-01
    z[2,4,1]  R1947     -1.0548141598701477e-01
    z[2,4,1]  R1948     -1.2155154347419739e-01
    z[2,4,1]  R1949     -5.4345929622650146e-01
    z[2,4,1]  R1950     2.1160256862640381e-01
    z[2,4,1]  R1951     8.4358178079128265e-02
    z[2,4,1]  R1952     -4.2696982622146606e-02
    z[2,4,1]  R1953     -1.6924735158681870e-02
    z[2,4,1]  R1954     3.2430076599121094e-01
    z[2,4,1]  R1955     3.4691080451011658e-02
    z[2,4,1]  R1956     8.5422113537788391e-02
    z[2,4,1]  R1957     5.7380330562591553e-01
    z[2,4,1]  R1958     -1.3982464373111725e-01
    z[2,4,1]  R1959     5.3358948230743408e-01
    z[2,4,1]  R1960     -9.4836302101612091e-02
    z[2,4,1]  R1961     0.49685138463974
    z[2,4,1]  R1962     4.8165795207023621e-01
    z[2,4,1]  R1963     -1.6482116281986237e-01
    z[2,4,1]  R1964     4.7156643867492676e-01
    z[2,4,1]  R1965     2.8162896633148193e-01
    z[2,4,1]  R1966     1.7092798650264740e-01
    z[2,4,1]  R1967     7.1815800666809082e-01
    z[2,4,1]  R1968     -1.8876178562641144e-01
    z[2,4,1]  R1969     1.4198282361030579e-01
    z[2,4,1]  R1970     3.8490608334541321e-01
    z[2,4,1]  R1971     4.1333901882171631e-01
    z[2,4,1]  R1972     3.3508679270744324e-01
    z[2,4,1]  R1973     -1.2112998217344284e-01
    z[2,4,1]  R1974     -1.4878851175308228e-01
    z[2,4,1]  R1975     -4.0528278797864914e-02
    z[2,4,1]  R1976     -2.2516460716724396e-01
    z[2,4,1]  R1977     4.0738192200660706e-01
    z[2,4,1]  R1978     3.3872112631797791e-01
    z[2,4,1]  R1979     2.9937621951103210e-01
    z[2,4,1]  R1980     3.7586104869842529e-01
    z[2,4,1]  R1981     -5.2003145217895508e-01
    z[2,4,1]  R1982     2.3173166811466217e-01
    z[2,4,1]  R1983     -3.7086048722267151e-01
    z[2,4,1]  R1984     -5.2467468194663525e-03
    z[2,4,1]  R1985     -4.5383399724960327e-01
    z[2,4,1]  R1986     -0.575942873954773
    z[2,4,1]  R1987     -8.1678695976734161e-02
    z[2,4,1]  R1988     -1.9468982517719269e-01
    z[2,4,1]  R1989     -8.7245449423789978e-02
    z[2,4,1]  R1990     -1.4296740293502808e-01
    z[2,4,1]  R1991     1.5793354809284210e-01
    z[2,4,1]  R1992     6.2615498900413513e-02
    z[2,4,1]  R1993     -8.5508622229099274e-02
    z[2,4,1]  R1994     2.1103753149509430e-01
    z[2,4,1]  R1995     0.0857396051287651
    z[2,4,1]  R1996     8.7869238853454590e-01
    z[2,4,1]  R1997     7.4564278125762939e-01
    z[2,4,1]  R1998     0.814132571220398
    z[2,4,1]  R1999     8.3106732368469238e-01
    z[2,4,1]  R2000     0.913650393486023
    z[2,4,1]  R2001     9.2196524143218994e-01
    z[2,4,1]  R2002     6.8651187419891357e-01
    z[2,4,1]  R2003     -3.4975543618202209e-01
    z[2,4,1]  R2004     -2.1639437973499298e-01
    z[2,4,1]  R2005     3.3483337610960007e-02
    z[2,4,1]  R2006     -5.4730284214019775e-01
    z[2,4,1]  R2007     -1.0956397652626038e-01
    z[2,4,1]  R2008     0.00622505834326148
    z[2,4,1]  R2009     5.1804497838020325e-02
    z[2,4,1]  R2010     -2.2204600274562836e-01
    z[2,4,1]  R2011     -2.3661231622099876e-02
    z[2,4,1]  R2012     2.3132576048374176e-01
    z[2,4,1]  R2013     -6.3067066669464111e-01
    z[2,4,1]  R2014     -8.3851498365402222e-01
    z[2,4,1]  R2015     -6.7305499315261841e-01
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1917     -1
    z[2,4,2]  R1918     1
    z[2,4,2]  R1927     5.5405408143997192e-01
    z[2,4,2]  R1928     3.0208969116210938e-01
    z[2,4,2]  R1929     4.4547548890113831e-01
    z[2,4,2]  R1930     4.7857272624969482e-01
    z[2,4,2]  R1931     6.4202749729156494e-01
    z[2,4,2]  R1932     8.1291161477565765e-02
    z[2,4,2]  R1933     4.4162884354591370e-02
    z[2,4,2]  R1934     -1.8790006870403886e-03
    z[2,4,2]  R1935     -2.3436856269836426e-01
    z[2,4,2]  R1936     -2.3957021534442902e-01
    z[2,4,2]  R1937     -4.2595416307449341e-01
    z[2,4,2]  R1938     -5.2947640419006348e-01
    z[2,4,2]  R1939     -0.502391517162323
    z[2,4,2]  R1940     -4.5143491029739380e-01
    z[2,4,2]  R1941     -0.36711585521698
    z[2,4,2]  R1942     -4.1537192463874817e-01
    z[2,4,2]  R1943     -4.2701101303100586e-01
    z[2,4,2]  R1944     -1.5642069280147552e-01
    z[2,4,2]  R1945     4.9039289355278015e-01
    z[2,4,2]  R1946     -6.6163659095764160e-02
    z[2,4,2]  R1947     -2.6565429568290710e-01
    z[2,4,2]  R1948     -3.1715756654739380e-01
    z[2,4,2]  R1949     -5.7490535080432892e-02
    z[2,4,2]  R1950     -3.7725567817687988e-01
    z[2,4,2]  R1951     -1.4679531753063202e-01
    z[2,4,2]  R1952     3.9403751492500305e-02
    z[2,4,2]  R1953     2.0407268404960632e-01
    z[2,4,2]  R1954     2.6282489299774170e-01
    z[2,4,2]  R1955     -4.7353811562061310e-02
    z[2,4,2]  R1956     -1.6353714466094971e-01
    z[2,4,2]  R1957     2.9847669601440430e-01
    z[2,4,2]  R1958     -1.3640609383583069e-01
    z[2,4,2]  R1959     2.2130960226058960e-01
    z[2,4,2]  R1960     -8.3762980997562408e-02
    z[2,4,2]  R1961     2.1198947727680206e-01
    z[2,4,2]  R1962     3.2118758559226990e-01
    z[2,4,2]  R1963     -3.8719365000724792e-01
    z[2,4,2]  R1964     2.0314460992813110e-01
    z[2,4,2]  R1965     -3.0454638600349426e-01
    z[2,4,2]  R1966     -4.2584415525197983e-02
    z[2,4,2]  R1967     -9.1633729636669159e-02
    z[2,4,2]  R1968     -3.4959834069013596e-02
    z[2,4,2]  R1969     -3.4006664156913757e-01
    z[2,4,2]  R1970     6.0803387314081192e-02
    z[2,4,2]  R1971     6.2868803739547729e-02
    z[2,4,2]  R1972     2.2307692468166351e-01
    z[2,4,2]  R1973     1.4269936084747314e-01
    z[2,4,2]  R1974     -1.7905475571751595e-02
    z[2,4,2]  R1975     1.4066404104232788e-01
    z[2,4,2]  R1976     -3.2815438508987427e-01
    z[2,4,2]  R1977     -1.9858621060848236e-01
    z[2,4,2]  R1978     -4.4785720109939575e-01
    z[2,4,2]  R1979     -3.6400568485260010e-01
    z[2,4,2]  R1980     -7.2100780904293060e-02
    z[2,4,2]  R1981     -1.2152507901191711e-01
    z[2,4,2]  R1982     4.7754812985658646e-02
    z[2,4,2]  R1983     7.7282279729843140e-02
    z[2,4,2]  R1984     -2.3688524961471558e-01
    z[2,4,2]  R1985     -0.737982451915741
    z[2,4,2]  R1986     3.8755902647972107e-01
    z[2,4,2]  R1987     4.8647314310073853e-01
    z[2,4,2]  R1988     6.0824459791183472e-01
    z[2,4,2]  R1989     4.3417137861251831e-01
    z[2,4,2]  R1990     -1.4967535436153412e-01
    z[2,4,2]  R1991     -4.1559547185897827e-01
    z[2,4,2]  R1992     -1.9692401587963104e-01
    z[2,4,2]  R1993     -1.1192564666271210e-01
    z[2,4,2]  R1994     -1.9925747811794281e-01
    z[2,4,2]  R1995     4.4076152145862579e-02
    z[2,4,2]  R1996     -0.348624587059021
    z[2,4,2]  R1997     -5.3115451335906982e-01
    z[2,4,2]  R1998     -3.2606229186058044e-01
    z[2,4,2]  R1999     -2.7933281660079956e-01
    z[2,4,2]  R2000     -0.0719640925526619
    z[2,4,2]  R2001     -0.0854223445057869
    z[2,4,2]  R2002     -3.4509435296058655e-01
    z[2,4,2]  R2003     1.6582074761390686e-01
    z[2,4,2]  R2004     2.6561295986175537e-01
    z[2,4,2]  R2005     3.1241217255592346e-01
    z[2,4,2]  R2006     3.5691785160452127e-03
    z[2,4,2]  R2007     -2.1841278672218323e-01
    z[2,4,2]  R2008     3.8633834570646286e-02
    z[2,4,2]  R2009     1.4892983436584473e-01
    z[2,4,2]  R2010     -1.7980413138866425e-01
    z[2,4,2]  R2011     0.190543994307518
    z[2,4,2]  R2012     1.6353680193424225e-01
    z[2,4,2]  R2013     -0.352943480014801
    z[2,4,2]  R2014     -8.0922663211822510e-02
    z[2,4,2]  R2015     -1.6812250018119812e-02
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1919     -1
    z[2,4,3]  R1920     1
    z[2,4,3]  R1927     1.9688328728079796e-02
    z[2,4,3]  R1928     2.5863319635391235e-02
    z[2,4,3]  R1929     -5.6284625083208084e-02
    z[2,4,3]  R1930     -1.7577295005321503e-01
    z[2,4,3]  R1931     -2.0616275072097778e-01
    z[2,4,3]  R1932     5.9721589088439941e-01
    z[2,4,3]  R1933     3.6833903193473816e-01
    z[2,4,3]  R1934     3.0313912034034729e-01
    z[2,4,3]  R1935     4.2844411730766296e-01
    z[2,4,3]  R1936     5.3503030538558960e-01
    z[2,4,3]  R1937     -1.0913491994142532e-01
    z[2,4,3]  R1938     -7.2018451988697052e-02
    z[2,4,3]  R1939     -2.4380747228860855e-02
    z[2,4,3]  R1940     2.8135562315583229e-02
    z[2,4,3]  R1941     2.9551374912261963e-01
    z[2,4,3]  R1942     -2.6950290799140930e-01
    z[2,4,3]  R1943     0.536393404006958
    z[2,4,3]  R1944     -4.9610573053359985e-01
    z[2,4,3]  R1945     3.1855475902557373e-01
    z[2,4,3]  R1946     2.5723496079444885e-01
    z[2,4,3]  R1947     -7.3913954198360443e-02
    z[2,4,3]  R1948     -0.0710030347108841
    z[2,4,3]  R1949     2.6913684606552124e-01
    z[2,4,3]  R1950     -4.8549634218215942e-01
    z[2,4,3]  R1951     -2.1894189715385437e-01
    z[2,4,3]  R1952     -3.2744863629341125e-01
    z[2,4,3]  R1953     -4.1578125953674316e-01
    z[2,4,3]  R1954     -9.1020818799734116e-03
    z[2,4,3]  R1955     -1.1704139411449432e-01
    z[2,4,3]  R1956     -2.7253192663192749e-01
    z[2,4,3]  R1957     -4.1588541865348816e-01
    z[2,4,3]  R1958     1.8047462403774261e-01
    z[2,4,3]  R1959     1.8411104381084442e-01
    z[2,4,3]  R1960     -2.1536672487854958e-02
    z[2,4,3]  R1961     2.3278267681598663e-01
    z[2,4,3]  R1962     -4.0269672870635986e-01
    z[2,4,3]  R1963     8.3176698535680771e-03
    z[2,4,3]  R1964     1.4700825512409210e-01
    z[2,4,3]  R1965     -4.5856767892837524e-01
    z[2,4,3]  R1966     -4.3998207896947861e-02
    z[2,4,3]  R1967     1.2758034281432629e-02
    z[2,4,3]  R1968     0.0983872041106224
    z[2,4,3]  R1969     6.8053025007247925e-01
    z[2,4,3]  R1970     -5.4386472702026367e-01
    z[2,4,3]  R1971     -3.4815445542335510e-01
    z[2,4,3]  R1972     -2.9917529225349426e-01
    z[2,4,3]  R1973     -3.3609643578529358e-01
    z[2,4,3]  R1974     -6.1731004714965820e-01
    z[2,4,3]  R1975     -6.9499629735946655e-01
    z[2,4,3]  R1976     -2.3235796391963959e-01
    z[2,4,3]  R1977     -3.8140979409217834e-01
    z[2,4,3]  R1978     -4.0274840593338013e-01
    z[2,4,3]  R1979     -4.0840244293212891e-01
    z[2,4,3]  R1980     -5.4294604063034058e-01
    z[2,4,3]  R1981     7.1361762285232544e-01
    z[2,4,3]  R1982     -2.2852474451065063e-01
    z[2,4,3]  R1983     -3.5795214772224426e-01
    z[2,4,3]  R1984     -2.6905605196952820e-01
    z[2,4,3]  R1985     5.6580636650323868e-02
    z[2,4,3]  R1986     -1.1291564255952835e-01
    z[2,4,3]  R1987     -4.3126974254846573e-02
    z[2,4,3]  R1988     -8.4073126316070557e-02
    z[2,4,3]  R1989     -1.1861911416053772e-01
    z[2,4,3]  R1990     -2.1147488057613373e-01
    z[2,4,3]  R1991     1.1938295327126980e-02
    z[2,4,3]  R1992     -3.3003918826580048e-02
    z[2,4,3]  R1993     -7.1461528539657593e-02
    z[2,4,3]  R1994     -3.5813751816749573e-01
    z[2,4,3]  R1995     3.7784200906753540e-01
    z[2,4,3]  R1996     2.3530612885951996e-01
    z[2,4,3]  R1997     -1.9758237898349762e-01
    z[2,4,3]  R1998     3.5624884068965912e-02
    z[2,4,3]  R1999     -0.330709308385849
    z[2,4,3]  R2000     1.2008894234895706e-01
    z[2,4,3]  R2001     -4.6502269804477692e-02
    z[2,4,3]  R2002     -2.7664867043495178e-01
    z[2,4,3]  R2003     -7.3545746505260468e-02
    z[2,4,3]  R2004     -1.3987350463867188e-01
    z[2,4,3]  R2005     7.3284611105918884e-02
    z[2,4,3]  R2006     -1.9933162629604340e-01
    z[2,4,3]  R2007     -1.5276260673999786e-01
    z[2,4,3]  R2008     5.7509493827819824e-01
    z[2,4,3]  R2009     -4.4765692949295044e-01
    z[2,4,3]  R2010     -7.7382522821426392e-01
    z[2,4,3]  R2011     7.6344740390777588e-01
    z[2,4,3]  R2012     5.8561843633651733e-01
    z[2,4,3]  R2013     4.7341939806938171e-01
    z[2,4,3]  R2014     2.2318008542060852e-01
    z[2,4,3]  R2015     3.6834666132926941e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1921     -1
    z[2,4,4]  R1922     1
    z[2,4,4]  R1927     1.6780348122119904e-01
    z[2,4,4]  R1928     -9.5293030142784119e-02
    z[2,4,4]  R1929     -5.0396603345870972e-01
    z[2,4,4]  R1930     1.4677263796329498e-01
    z[2,4,4]  R1931     -3.6618176102638245e-01
    z[2,4,4]  R1932     -4.2743611335754395e-01
    z[2,4,4]  R1933     -2.1006008982658386e-01
    z[2,4,4]  R1934     -7.2236508131027222e-01
    z[2,4,4]  R1935     -0.205518439412117
    z[2,4,4]  R1936     -5.8308511972427368e-01
    z[2,4,4]  R1937     -5.9225648641586304e-02
    z[2,4,4]  R1938     -1.6364024579524994e-01
    z[2,4,4]  R1939     -2.3171067237854004e-01
    z[2,4,4]  R1940     1.4094124734401703e-01
    z[2,4,4]  R1941     3.2538506388664246e-01
    z[2,4,4]  R1942     0.0657089427113533
    z[2,4,4]  R1943     3.0613413453102112e-01
    z[2,4,4]  R1944     3.8916683197021484e-01
    z[2,4,4]  R1945     2.6407399773597717e-01
    z[2,4,4]  R1946     1.0766576230525970e-01
    z[2,4,4]  R1947     3.0829259753227234e-01
    z[2,4,4]  R1948     0.542674720287323
    z[2,4,4]  R1949     -3.5133257508277893e-01
    z[2,4,4]  R1950     6.7589128017425537e-01
    z[2,4,4]  R1951     9.3958681821823120e-01
    z[2,4,4]  R1952     8.3078670501708984e-01
    z[2,4,4]  R1953     7.6595938205718994e-01
    z[2,4,4]  R1954     -3.4655591845512390e-01
    z[2,4,4]  R1955     8.8376337289810181e-01
    z[2,4,4]  R1956     6.3066780567169189e-01
    z[2,4,4]  R1957     3.0546778440475464e-01
    z[2,4,4]  R1958     0.541685938835144
    z[2,4,4]  R1959     2.6552131772041321e-01
    z[2,4,4]  R1960     5.4971385002136230e-01
    z[2,4,4]  R1961     1.4752371609210968e-01
    z[2,4,4]  R1962     3.7905752658843994e-01
    z[2,4,4]  R1963     1.2931534647941589e-01
    z[2,4,4]  R1964     -2.2250978276133537e-02
    z[2,4,4]  R1965     0.729640543460846
    z[2,4,4]  R1966     -6.8487298488616943e-01
    z[2,4,4]  R1967     -4.5553824305534363e-01
    z[2,4,4]  R1968     -4.0139034390449524e-01
    z[2,4,4]  R1969     3.2666096091270447e-01
    z[2,4,4]  R1970     6.5018379688262939e-01
    z[2,4,4]  R1971     0.615688145160675
    z[2,4,4]  R1972     6.1329811811447144e-01
    z[2,4,4]  R1973     6.6873502731323242e-01
    z[2,4,4]  R1974     6.3954770565032959e-01
    z[2,4,4]  R1975     3.2765284180641174e-01
    z[2,4,4]  R1976     6.7813855409622192e-01
    z[2,4,4]  R1977     -5.0727075338363647e-01
    z[2,4,4]  R1978     -3.3661961555480957e-01
    z[2,4,4]  R1979     9.8570518195629120e-02
    z[2,4,4]  R1980     6.1248999834060669e-01
    z[2,4,4]  R1981     -3.7129085510969162e-02
    z[2,4,4]  R1982     7.7158856391906738e-01
    z[2,4,4]  R1983     7.6849943399429321e-01
    z[2,4,4]  R1984     0.732159435749054
    z[2,4,4]  R1985     5.8081064373254776e-02
    z[2,4,4]  R1986     -1.3108095526695251e-01
    z[2,4,4]  R1987     1.7517803609371185e-01
    z[2,4,4]  R1988     -5.0521481037139893e-01
    z[2,4,4]  R1989     -3.7098596803843975e-03
    z[2,4,4]  R1990     -7.8253731131553650e-02
    z[2,4,4]  R1991     1.8952155485749245e-02
    z[2,4,4]  R1992     1.0351741313934326e-01
    z[2,4,4]  R1993     -3.0360710620880127e-01
    z[2,4,4]  R1994     -2.0744135975837708e-01
    z[2,4,4]  R1995     -2.9577660560607910e-01
    z[2,4,4]  R1996     6.2534660100936890e-02
    z[2,4,4]  R1997     2.8456097841262817e-01
    z[2,4,4]  R1998     4.0337464213371277e-01
    z[2,4,4]  R1999     7.7082134783267975e-02
    z[2,4,4]  R2000     1.1331208795309067e-01
    z[2,4,4]  R2001     -2.6226335763931274e-01
    z[2,4,4]  R2002     -3.4285095334053040e-01
    z[2,4,4]  R2003     8.8250853121280670e-02
    z[2,4,4]  R2004     2.7964314818382263e-01
    z[2,4,4]  R2005     8.8019356131553650e-02
    z[2,4,4]  R2006     3.6297035217285156e-01
    z[2,4,4]  R2007     6.8603962659835815e-02
    z[2,4,4]  R2008     2.4468223750591278e-01
    z[2,4,4]  R2009     -4.6644932031631470e-01
    z[2,4,4]  R2010     -3.0253347754478455e-01
    z[2,4,4]  R2011     3.5661216825246811e-02
    z[2,4,4]  R2012     -2.8646424412727356e-01
    z[2,4,4]  R2013     -1.2093091756105423e-01
    z[2,4,4]  R2014     8.1553466618061066e-02
    z[2,4,4]  R2015     -5.2477353811264038e-01
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1923     -1
    z[2,4,5]  R1924     1
    z[2,4,5]  R1927     -1.5103656053543091e-01
    z[2,4,5]  R1928     -6.2295131385326385e-02
    z[2,4,5]  R1929     -0.0794144868850708
    z[2,4,5]  R1930     -7.3905050754547119e-02
    z[2,4,5]  R1931     -0.553706169128418
    z[2,4,5]  R1932     -0.50154048204422
    z[2,4,5]  R1933     -8.5121077299118042e-01
    z[2,4,5]  R1934     -5.6201732158660889e-01
    z[2,4,5]  R1935     -6.5065312385559082e-01
    z[2,4,5]  R1936     -0.338346391916275
    z[2,4,5]  R1937     -8.2619205117225647e-02
    z[2,4,5]  R1938     -1.1536671966314316e-01
    z[2,4,5]  R1939     -1.1266986839473248e-02
    z[2,4,5]  R1940     -3.0776521563529968e-01
    z[2,4,5]  R1941     2.1929222345352173e-01
    z[2,4,5]  R1942     4.4513073563575745e-01
    z[2,4,5]  R1943     2.4503825604915619e-01
    z[2,4,5]  R1944     2.3875932395458221e-01
    z[2,4,5]  R1945     2.1600700914859772e-01
    z[2,4,5]  R1946     3.1031739711761475e-01
    z[2,4,5]  R1947     -5.0032925605773926e-01
    z[2,4,5]  R1948     -6.4615093171596527e-02
    z[2,4,5]  R1949     -3.0091321095824242e-03
    z[2,4,5]  R1950     -9.5629818737506866e-02
    z[2,4,5]  R1951     0.0893244668841362
    z[2,4,5]  R1952     -2.0185333490371704e-01
    z[2,4,5]  R1953     -5.3852040320634842e-02
    z[2,4,5]  R1954     4.5460018515586853e-01
    z[2,4,5]  R1955     1.1297465115785599e-01
    z[2,4,5]  R1956     -1.1456539481878281e-01
    z[2,4,5]  R1957     5.3864598274230957e-01
    z[2,4,5]  R1958     -1.5818008780479431e-01
    z[2,4,5]  R1959     -2.5313705205917358e-01
    z[2,4,5]  R1960     3.8068592548370361e-01
    z[2,4,5]  R1961     6.9146496057510376e-01
    z[2,4,5]  R1962     1.8906120955944061e-01
    z[2,4,5]  R1963     2.3913174867630005e-01
    z[2,4,5]  R1964     2.2060884535312653e-01
    z[2,4,5]  R1965     -1.7037029564380646e-01
    z[2,4,5]  R1966     1.4622513949871063e-01
    z[2,4,5]  R1967     -1.1423914879560471e-01
    z[2,4,5]  R1968     -1.4322666823863983e-01
    z[2,4,5]  R1969     -1.0807734727859497e-01
    z[2,4,5]  R1970     1.5783878043293953e-02
    z[2,4,5]  R1971     4.9813590943813324e-02
    z[2,4,5]  R1972     -1.0862774401903152e-01
    z[2,4,5]  R1973     5.8036959171295166e-01
    z[2,4,5]  R1974     4.1192063689231873e-01
    z[2,4,5]  R1975     5.0464153289794922e-01
    z[2,4,5]  R1976     4.2999365925788879e-01
    z[2,4,5]  R1977     -5.0462526082992554e-01
    z[2,4,5]  R1978     -1.6671015322208405e-01
    z[2,4,5]  R1979     1.7743869125843048e-01
    z[2,4,5]  R1980     9.9554657936096191e-02
    z[2,4,5]  R1981     2.8193006291985512e-02
    z[2,4,5]  R1982     -2.9880398511886597e-01
    z[2,4,5]  R1983     3.6627429723739624e-01
    z[2,4,5]  R1984     -1.4255641959607601e-02
    z[2,4,5]  R1985     3.4274047613143921e-01
    z[2,4,5]  R1986     -2.7850124239921570e-01
    z[2,4,5]  R1987     1.2280213832855225e-01
    z[2,4,5]  R1988     4.8055514693260193e-02
    z[2,4,5]  R1989     -3.5813519358634949e-01
    z[2,4,5]  R1990     8.1823609769344330e-02
    z[2,4,5]  R1991     -3.6321735382080078e-01
    z[2,4,5]  R1992     -2.6041004061698914e-01
    z[2,4,5]  R1993     -6.7825573682785034e-01
    z[2,4,5]  R1994     -1.2281390838325024e-02
    z[2,4,5]  R1995     3.1469874083995819e-02
    z[2,4,5]  R1996     5.8050606399774551e-02
    z[2,4,5]  R1997     -1.4533384144306183e-01
    z[2,4,5]  R1998     1.5770610189065337e-03
    z[2,4,5]  R1999     1.1847331374883652e-01
    z[2,4,5]  R2000     -4.4052530080080032e-02
    z[2,4,5]  R2001     2.4003873765468597e-01
    z[2,4,5]  R2002     -1.1766491085290909e-01
    z[2,4,5]  R2003     1.6332441568374634e-01
    z[2,4,5]  R2004     -1.0694076865911484e-01
    z[2,4,5]  R2005     1.6248992085456848e-01
    z[2,4,5]  R2006     -2.2576166689395905e-01
    z[2,4,5]  R2007     -8.2591855525970459e-01
    z[2,4,5]  R2008     3.0087551474571228e-01
    z[2,4,5]  R2009     -1.8919488787651062e-01
    z[2,4,5]  R2010     -1.0286095738410950e-01
    z[2,4,5]  R2011     -9.0068064630031586e-02
    z[2,4,5]  R2012     1.7317394912242889e-01
    z[2,4,5]  R2013     2.8762108087539673e-01
    z[2,4,5]  R2014     3.4940522909164429e-01
    z[2,4,5]  R2015     2.5666022300720215e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1925     -1
    z[2,4,6]  R1926     1
    z[2,4,6]  R1927     -2.5069481134414673e-01
    z[2,4,6]  R1928     2.0381264388561249e-01
    z[2,4,6]  R1929     -2.8867053985595703e-01
    z[2,4,6]  R1930     3.7670439481735229e-01
    z[2,4,6]  R1931     3.1335431337356567e-01
    z[2,4,6]  R1932     -1.0851830244064331e-01
    z[2,4,6]  R1933     4.4684566557407379e-02
    z[2,4,6]  R1934     1.6724999248981476e-01
    z[2,4,6]  R1935     4.3016341328620911e-01
    z[2,4,6]  R1936     3.4454837441444397e-01
    z[2,4,6]  R1937     -3.2937828451395035e-02
    z[2,4,6]  R1938     -1.2528675794601440e-01
    z[2,4,6]  R1939     6.4339734613895416e-02
    z[2,4,6]  R1940     -8.2796871662139893e-02
    z[2,4,6]  R1941     -1.4643880724906921e-01
    z[2,4,6]  R1942     3.0713915824890137e-01
    z[2,4,6]  R1943     6.8526528775691986e-02
    z[2,4,6]  R1944     -1.0783251374959946e-01
    z[2,4,6]  R1945     2.5204023718833923e-01
    z[2,4,6]  R1946     -6.3451957702636719e-01
    z[2,4,6]  R1947     3.9810085296630859e-01
    z[2,4,6]  R1948     3.2346194982528687e-01
    z[2,4,6]  R1949     5.4837477207183838e-01
    z[2,4,6]  R1950     3.2659384608268738e-01
    z[2,4,6]  R1951     -9.7096830606460571e-02
    z[2,4,6]  R1952     -1.2588070333003998e-01
    z[2,4,6]  R1953     -3.2313096523284912e-01
    z[2,4,6]  R1954     -4.4252294301986694e-01
    z[2,4,6]  R1955     -1.6365081071853638e-01
    z[2,4,6]  R1956     1.5072350203990936e-01
    z[2,4,6]  R1957     -1.0466154664754868e-01
    z[2,4,6]  R1958     1.0212297551333904e-02
    z[2,4,6]  R1959     2.6807376742362976e-01
    z[2,4,6]  R1960     -1.0517653077840805e-01
    z[2,4,6]  R1961     -9.1191403567790985e-02
    z[2,4,6]  R1962     3.6306518316268921e-01
    z[2,4,6]  R1963     4.8085975646972656e-01
    z[2,4,6]  R1964     -6.9738447666168213e-01
    z[2,4,6]  R1965     1.5220688283443451e-01
    z[2,4,6]  R1966     1.7330373823642731e-01
    z[2,4,6]  R1967     1.7091201245784760e-01
    z[2,4,6]  R1968     3.7513554096221924e-01
    z[2,4,6]  R1969     1.5162459574639797e-02
    z[2,4,6]  R1970     -3.5503348708152771e-01
    z[2,4,6]  R1971     -0.428116112947464
    z[2,4,6]  R1972     -5.8395510911941528e-01
    z[2,4,6]  R1973     -2.4148355424404144e-01
    z[2,4,6]  R1974     1.3274788856506348e-01
    z[2,4,6]  R1975     -1.6567483544349670e-02
    z[2,4,6]  R1976     2.7294814586639404e-01
    z[2,4,6]  R1977     3.3952745795249939e-01
    z[2,4,6]  R1978     6.0924154520034790e-01
    z[2,4,6]  R1979     2.6959735155105591e-01
    z[2,4,6]  R1980     -1.5009182691574097e-01
    z[2,4,6]  R1981     3.1779631972312927e-01
    z[2,4,6]  R1982     -3.9673903584480286e-01
    z[2,4,6]  R1983     5.5634602904319763e-02
    z[2,4,6]  R1984     2.5438934564590454e-01
    z[2,4,6]  R1985     -2.8624063730239868e-01
    z[2,4,6]  R1986     1.3542146980762482e-01
    z[2,4,6]  R1987     -0.00367422285489738
    z[2,4,6]  R1988     -1.0799888521432877e-01
    z[2,4,6]  R1989     -6.1507290601730347e-01
    z[2,4,6]  R1990     1.2677150964736938e-01
    z[2,4,6]  R1991     4.8420354723930359e-01
    z[2,4,6]  R1992     2.0706895738840103e-02
    z[2,4,6]  R1993     3.2840543985366821e-01
    z[2,4,6]  R1994     -2.9542544484138489e-01
    z[2,4,6]  R1995     3.0984729528427124e-01
    z[2,4,6]  R1996     1.5701831877231598e-01
    z[2,4,6]  R1997     -1.4757920987904072e-02
    z[2,4,6]  R1998     -2.2041529417037964e-01
    z[2,4,6]  R1999     -2.5851166248321533e-01
    z[2,4,6]  R2000     -3.4218841791152954e-01
    z[2,4,6]  R2001     -1.1786611378192902e-01
    z[2,4,6]  R2002     1.7341071367263794e-01
    z[2,4,6]  R2003     -7.6179198920726776e-02
    z[2,4,6]  R2004     -5.1968467235565186e-01
    z[2,4,6]  R2005     -3.6494970321655273e-01
    z[2,4,6]  R2006     -1.2957751750946045e-01
    z[2,4,6]  R2007     1.1584952473640442e-01
    z[2,4,6]  R2008     1.1547765135765076e-01
    z[2,4,6]  R2009     -1.2766093015670776e-01
    z[2,4,6]  R2010     1.0075343400239944e-01
    z[2,4,6]  R2011     2.5603345036506653e-01
    z[2,4,6]  R2012     3.4406366944313049e-01
    z[2,4,6]  R2013     -1.7734996974468231e-01
    z[2,4,6]  R2014     -0.0982140377163887
    z[2,4,6]  R2015     -1.2797258794307709e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R2016     -1
    z[4,2,0]  R2017     1
    z[4,2,0]  R2030     -0.626301646232605
    z[4,2,0]  R2031     -8.4204000234603882e-01
    z[4,2,0]  R2032     -5.6200635433197021e-01
    z[4,2,0]  R2033     -5.3218764066696167e-01
    z[4,2,0]  R2034     -0.939971387386322
    z[4,2,0]  R2035     6.5989071130752563e-01
    z[4,2,0]  R2036     -9.3661779165267944e-01
    z[4,2,0]  R2037     5.6124496459960938e-01
    z[4,2,0]  R2038     -8.1057894229888916e-01
    z[4,2,0]  R2039     -8.1453180313110352e-01
    z[4,2,0]  R2040     -1.3804477453231812e-01
    z[4,2,0]  R2041     -1.4331266283988953e-01
    z[4,2,0]  R2042     1.3529990613460541e-01
    z[4,2,0]  R2043     1.8741910159587860e-01
    z[4,2,0]  R2044     1.1734388023614883e-01
    z[4,2,0]  R2045     -1.5084441751241684e-02
    z[4,2,0]  R2046     -4.1426301002502441e-01
    z[4,2,0]  R2047     8.9693886041641235e-01
    z[4,2,0]  R2048     7.0947146415710449e-01
    z[4,2,0]  R2049     0.85356205701828
    z[4,2,0]  R2050     6.7912268638610840e-01
    z[4,2,0]  R2051     4.6549555659294128e-01
    z[4,2,0]  R2052     -7.0993238687515259e-01
    z[4,2,0]  R2053     7.1068447828292847e-01
    z[4,2,0]  R2054     4.5530465245246887e-01
    z[4,2,0]  R2055     0.552579402923584
    z[4,2,0]  R2056     5.8852738142013550e-01
    z[4,2,0]  R2057     -3.5320860147476196e-01
    z[4,2,0]  R2058     -0.319614976644516
    z[4,2,0]  R2059     -2.3107655346393585e-01
    z[4,2,0]  R2060     -7.4349719285964966e-01
    z[4,2,0]  R2061     -9.0440279245376587e-01
    z[4,2,0]  R2062     -6.5755015611648560e-01
    z[4,2,0]  R2063     -3.6882689595222473e-01
    z[4,2,0]  R2064     -1.4272942207753658e-02
    z[4,2,0]  R2065     4.3630054593086243e-01
    z[4,2,0]  R2066     3.0258023738861084e-01
    z[4,2,0]  R2067     1.9868750870227814e-01
    z[4,2,0]  R2068     3.1030893325805664e-01
    z[4,2,0]  R2069     2.8834110498428345e-01
    z[4,2,0]  R2070     2.7444690465927124e-01
    z[4,2,0]  R2071     -0.0762915164232254
    z[4,2,0]  R2072     -2.3704680800437927e-01
    z[4,2,0]  R2073     -0.0945655107498169
    z[4,2,0]  R2074     -6.8223255872726440e-01
    z[4,2,0]  R2075     -6.3873386383056641e-01
    z[4,2,0]  R2076     -6.0326629877090454e-01
    z[4,2,0]  R2077     -6.0984796285629272e-01
    z[4,2,0]  R2078     5.6926918029785156e-01
    z[4,2,0]  R2079     -5.7782799005508423e-02
    z[4,2,0]  R2080     -6.3951557874679565e-01
    z[4,2,0]  R2081     -6.9014227390289307e-01
    z[4,2,0]  R2082     4.5249709486961365e-01
    z[4,2,0]  R2083     -6.7513942718505859e-02
    z[4,2,0]  R2084     -1.5221396088600159e-01
    z[4,2,0]  R2085     -3.7763002514839172e-01
    z[4,2,0]  R2086     -3.0197069048881531e-01
    z[4,2,0]  R2087     5.5052733421325684e-01
    z[4,2,0]  R2088     0.402831107378006
    z[4,2,0]  R2089     0.676831066608429
    z[4,2,0]  R2090     1.1956851184368134e-01
    z[4,2,0]  R2091     -7.8148734569549561e-01
    z[4,2,0]  R2092     6.5265917778015137e-01
    z[4,2,0]  R2093     -7.2481507062911987e-01
    z[4,2,0]  R2094     3.8184890151023865e-01
    z[4,2,0]  R2095     4.3753212690353394e-01
    z[4,2,0]  R2096     -7.1952289342880249e-01
    z[4,2,0]  R2097     4.2336440086364746e-01
    z[4,2,0]  R2098     -1.8188993632793427e-01
    z[4,2,0]  R2099     0.668256938457489
    z[4,2,0]  R2100     4.7530296444892883e-01
    z[4,2,0]  R2101     7.9442560672760010e-01
    z[4,2,0]  R2102     0.531466007232666
    z[4,2,0]  R2103     5.7659108191728592e-02
    z[4,2,0]  R2104     3.7302851676940918e-01
    z[4,2,0]  R2105     1.3967619836330414e-01
    z[4,2,0]  R2106     9.8253987729549408e-02
    z[4,2,0]  R2107     -1.2154962867498398e-02
    z[4,2,0]  R2108     3.6504435539245605e-01
    z[4,2,0]  R2109     2.6145428419113159e-01
    z[4,2,0]  R2110     1.4792186021804810e-01
    z[4,2,0]  R2111     1.0102129727602005e-01
    z[4,2,0]  R2112     -7.0512253046035767e-01
    z[4,2,0]  R2113     3.8878908753395081e-01
    z[4,2,0]  R2114     3.1997001171112061e-01
    z[4,2,0]  R2115     2.2307321429252625e-01
    z[4,2,0]  R2116     2.2730773314833641e-02
    z[4,2,0]  R2117     5.2008849382400513e-01
    z[4,2,0]  R2118     -2.0841567218303680e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R2018     -1
    z[4,2,1]  R2019     1
    z[4,2,1]  R2030     -0.575942873954773
    z[4,2,1]  R2031     -8.1678695976734161e-02
    z[4,2,1]  R2032     -1.9468982517719269e-01
    z[4,2,1]  R2033     -8.7245449423789978e-02
    z[4,2,1]  R2034     -1.4296740293502808e-01
    z[4,2,1]  R2035     1.5793354809284210e-01
    z[4,2,1]  R2036     6.2615498900413513e-02
    z[4,2,1]  R2037     -8.5508622229099274e-02
    z[4,2,1]  R2038     2.1103753149509430e-01
    z[4,2,1]  R2039     0.0857396051287651
    z[4,2,1]  R2040     8.7869238853454590e-01
    z[4,2,1]  R2041     7.4564278125762939e-01
    z[4,2,1]  R2042     0.814132571220398
    z[4,2,1]  R2043     8.3106732368469238e-01
    z[4,2,1]  R2044     0.913650393486023
    z[4,2,1]  R2045     9.2196524143218994e-01
    z[4,2,1]  R2046     6.8651187419891357e-01
    z[4,2,1]  R2047     -3.4975543618202209e-01
    z[4,2,1]  R2048     -2.1639437973499298e-01
    z[4,2,1]  R2049     3.3483337610960007e-02
    z[4,2,1]  R2050     -5.4730284214019775e-01
    z[4,2,1]  R2051     -1.0956397652626038e-01
    z[4,2,1]  R2052     0.00622505834326148
    z[4,2,1]  R2053     5.1804497838020325e-02
    z[4,2,1]  R2054     -2.2204600274562836e-01
    z[4,2,1]  R2055     -2.3661231622099876e-02
    z[4,2,1]  R2056     2.3132576048374176e-01
    z[4,2,1]  R2057     -6.3067066669464111e-01
    z[4,2,1]  R2058     -8.3851498365402222e-01
    z[4,2,1]  R2059     -6.7305499315261841e-01
    z[4,2,1]  R2060     -1.6133917868137360e-01
    z[4,2,1]  R2061     -1.8875263631343842e-01
    z[4,2,1]  R2062     -1.4964066445827484e-01
    z[4,2,1]  R2063     -6.5964251756668091e-01
    z[4,2,1]  R2064     7.8889004886150360e-02
    z[4,2,1]  R2065     1.8604267388582230e-02
    z[4,2,1]  R2066     -1.1806106194853783e-02
    z[4,2,1]  R2067     5.4581854492425919e-02
    z[4,2,1]  R2068     -1.2077865749597549e-01
    z[4,2,1]  R2069     5.2824807353317738e-03
    z[4,2,1]  R2070     8.4847694635391235e-01
    z[4,2,1]  R2071     8.0799955129623413e-01
    z[4,2,1]  R2072     7.9552549123764038e-01
    z[4,2,1]  R2073     8.1549555063247681e-01
    z[4,2,1]  R2074     3.7019926309585571e-01
    z[4,2,1]  R2075     2.2374063730239868e-01
    z[4,2,1]  R2076     8.6924374103546143e-02
    z[4,2,1]  R2077     3.7069177627563477e-01
    z[4,2,1]  R2078     3.9249441027641296e-01
    z[4,2,1]  R2079     6.4467805624008179e-01
    z[4,2,1]  R2080     -1.0548141598701477e-01
    z[4,2,1]  R2081     -1.2155154347419739e-01
    z[4,2,1]  R2082     -5.4345929622650146e-01
    z[4,2,1]  R2083     2.1160256862640381e-01
    z[4,2,1]  R2084     8.4358178079128265e-02
    z[4,2,1]  R2085     -4.2696982622146606e-02
    z[4,2,1]  R2086     -1.6924735158681870e-02
    z[4,2,1]  R2087     3.2430076599121094e-01
    z[4,2,1]  R2088     3.4691080451011658e-02
    z[4,2,1]  R2089     8.5422113537788391e-02
    z[4,2,1]  R2090     5.7380330562591553e-01
    z[4,2,1]  R2091     -1.3982464373111725e-01
    z[4,2,1]  R2092     5.3358948230743408e-01
    z[4,2,1]  R2093     -9.4836302101612091e-02
    z[4,2,1]  R2094     0.49685138463974
    z[4,2,1]  R2095     4.8165795207023621e-01
    z[4,2,1]  R2096     -1.6482116281986237e-01
    z[4,2,1]  R2097     4.7156643867492676e-01
    z[4,2,1]  R2098     2.8162896633148193e-01
    z[4,2,1]  R2099     1.7092798650264740e-01
    z[4,2,1]  R2100     7.1815800666809082e-01
    z[4,2,1]  R2101     -1.8876178562641144e-01
    z[4,2,1]  R2102     1.4198282361030579e-01
    z[4,2,1]  R2103     3.8490608334541321e-01
    z[4,2,1]  R2104     4.1333901882171631e-01
    z[4,2,1]  R2105     3.3508679270744324e-01
    z[4,2,1]  R2106     -1.2112998217344284e-01
    z[4,2,1]  R2107     -1.4878851175308228e-01
    z[4,2,1]  R2108     -4.0528278797864914e-02
    z[4,2,1]  R2109     -2.2516460716724396e-01
    z[4,2,1]  R2110     4.0738192200660706e-01
    z[4,2,1]  R2111     3.3872112631797791e-01
    z[4,2,1]  R2112     2.9937621951103210e-01
    z[4,2,1]  R2113     3.7586104869842529e-01
    z[4,2,1]  R2114     -5.2003145217895508e-01
    z[4,2,1]  R2115     2.3173166811466217e-01
    z[4,2,1]  R2116     -3.7086048722267151e-01
    z[4,2,1]  R2117     -5.2467468194663525e-03
    z[4,2,1]  R2118     -4.5383399724960327e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R2020     -1
    z[4,2,2]  R2021     1
    z[4,2,2]  R2030     3.8755902647972107e-01
    z[4,2,2]  R2031     4.8647314310073853e-01
    z[4,2,2]  R2032     6.0824459791183472e-01
    z[4,2,2]  R2033     4.3417137861251831e-01
    z[4,2,2]  R2034     -1.4967535436153412e-01
    z[4,2,2]  R2035     -4.1559547185897827e-01
    z[4,2,2]  R2036     -1.9692401587963104e-01
    z[4,2,2]  R2037     -1.1192564666271210e-01
    z[4,2,2]  R2038     -1.9925747811794281e-01
    z[4,2,2]  R2039     4.4076152145862579e-02
    z[4,2,2]  R2040     -0.348624587059021
    z[4,2,2]  R2041     -5.3115451335906982e-01
    z[4,2,2]  R2042     -3.2606229186058044e-01
    z[4,2,2]  R2043     -2.7933281660079956e-01
    z[4,2,2]  R2044     -0.0719640925526619
    z[4,2,2]  R2045     -0.0854223445057869
    z[4,2,2]  R2046     -3.4509435296058655e-01
    z[4,2,2]  R2047     1.6582074761390686e-01
    z[4,2,2]  R2048     2.6561295986175537e-01
    z[4,2,2]  R2049     3.1241217255592346e-01
    z[4,2,2]  R2050     3.5691785160452127e-03
    z[4,2,2]  R2051     -2.1841278672218323e-01
    z[4,2,2]  R2052     3.8633834570646286e-02
    z[4,2,2]  R2053     1.4892983436584473e-01
    z[4,2,2]  R2054     -1.7980413138866425e-01
    z[4,2,2]  R2055     0.190543994307518
    z[4,2,2]  R2056     1.6353680193424225e-01
    z[4,2,2]  R2057     -0.352943480014801
    z[4,2,2]  R2058     -8.0922663211822510e-02
    z[4,2,2]  R2059     -1.6812250018119812e-02
    z[4,2,2]  R2060     5.5405408143997192e-01
    z[4,2,2]  R2061     3.0208969116210938e-01
    z[4,2,2]  R2062     4.4547548890113831e-01
    z[4,2,2]  R2063     4.7857272624969482e-01
    z[4,2,2]  R2064     6.4202749729156494e-01
    z[4,2,2]  R2065     8.1291161477565765e-02
    z[4,2,2]  R2066     4.4162884354591370e-02
    z[4,2,2]  R2067     -1.8790006870403886e-03
    z[4,2,2]  R2068     -2.3436856269836426e-01
    z[4,2,2]  R2069     -2.3957021534442902e-01
    z[4,2,2]  R2070     -4.2595416307449341e-01
    z[4,2,2]  R2071     -5.2947640419006348e-01
    z[4,2,2]  R2072     -0.502391517162323
    z[4,2,2]  R2073     -4.5143491029739380e-01
    z[4,2,2]  R2074     -0.36711585521698
    z[4,2,2]  R2075     -4.1537192463874817e-01
    z[4,2,2]  R2076     -4.2701101303100586e-01
    z[4,2,2]  R2077     -1.5642069280147552e-01
    z[4,2,2]  R2078     4.9039289355278015e-01
    z[4,2,2]  R2079     -6.6163659095764160e-02
    z[4,2,2]  R2080     -2.6565429568290710e-01
    z[4,2,2]  R2081     -3.1715756654739380e-01
    z[4,2,2]  R2082     -5.7490535080432892e-02
    z[4,2,2]  R2083     -3.7725567817687988e-01
    z[4,2,2]  R2084     -1.4679531753063202e-01
    z[4,2,2]  R2085     3.9403751492500305e-02
    z[4,2,2]  R2086     2.0407268404960632e-01
    z[4,2,2]  R2087     2.6282489299774170e-01
    z[4,2,2]  R2088     -4.7353811562061310e-02
    z[4,2,2]  R2089     -1.6353714466094971e-01
    z[4,2,2]  R2090     2.9847669601440430e-01
    z[4,2,2]  R2091     -1.3640609383583069e-01
    z[4,2,2]  R2092     2.2130960226058960e-01
    z[4,2,2]  R2093     -8.3762980997562408e-02
    z[4,2,2]  R2094     2.1198947727680206e-01
    z[4,2,2]  R2095     3.2118758559226990e-01
    z[4,2,2]  R2096     -3.8719365000724792e-01
    z[4,2,2]  R2097     2.0314460992813110e-01
    z[4,2,2]  R2098     -3.0454638600349426e-01
    z[4,2,2]  R2099     -4.2584415525197983e-02
    z[4,2,2]  R2100     -9.1633729636669159e-02
    z[4,2,2]  R2101     -3.4959834069013596e-02
    z[4,2,2]  R2102     -3.4006664156913757e-01
    z[4,2,2]  R2103     6.0803387314081192e-02
    z[4,2,2]  R2104     6.2868803739547729e-02
    z[4,2,2]  R2105     2.2307692468166351e-01
    z[4,2,2]  R2106     1.4269936084747314e-01
    z[4,2,2]  R2107     -1.7905475571751595e-02
    z[4,2,2]  R2108     1.4066404104232788e-01
    z[4,2,2]  R2109     -3.2815438508987427e-01
    z[4,2,2]  R2110     -1.9858621060848236e-01
    z[4,2,2]  R2111     -4.4785720109939575e-01
    z[4,2,2]  R2112     -3.6400568485260010e-01
    z[4,2,2]  R2113     -7.2100780904293060e-02
    z[4,2,2]  R2114     -1.2152507901191711e-01
    z[4,2,2]  R2115     4.7754812985658646e-02
    z[4,2,2]  R2116     7.7282279729843140e-02
    z[4,2,2]  R2117     -2.3688524961471558e-01
    z[4,2,2]  R2118     -0.737982451915741
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R2022     -1
    z[4,2,3]  R2023     1
    z[4,2,3]  R2030     -1.1291564255952835e-01
    z[4,2,3]  R2031     -4.3126974254846573e-02
    z[4,2,3]  R2032     -8.4073126316070557e-02
    z[4,2,3]  R2033     -1.1861911416053772e-01
    z[4,2,3]  R2034     -2.1147488057613373e-01
    z[4,2,3]  R2035     1.1938295327126980e-02
    z[4,2,3]  R2036     -3.3003918826580048e-02
    z[4,2,3]  R2037     -7.1461528539657593e-02
    z[4,2,3]  R2038     -3.5813751816749573e-01
    z[4,2,3]  R2039     3.7784200906753540e-01
    z[4,2,3]  R2040     2.3530612885951996e-01
    z[4,2,3]  R2041     -1.9758237898349762e-01
    z[4,2,3]  R2042     3.5624884068965912e-02
    z[4,2,3]  R2043     -0.330709308385849
    z[4,2,3]  R2044     1.2008894234895706e-01
    z[4,2,3]  R2045     -4.6502269804477692e-02
    z[4,2,3]  R2046     -2.7664867043495178e-01
    z[4,2,3]  R2047     -7.3545746505260468e-02
    z[4,2,3]  R2048     -1.3987350463867188e-01
    z[4,2,3]  R2049     7.3284611105918884e-02
    z[4,2,3]  R2050     -1.9933162629604340e-01
    z[4,2,3]  R2051     -1.5276260673999786e-01
    z[4,2,3]  R2052     5.7509493827819824e-01
    z[4,2,3]  R2053     -4.4765692949295044e-01
    z[4,2,3]  R2054     -7.7382522821426392e-01
    z[4,2,3]  R2055     7.6344740390777588e-01
    z[4,2,3]  R2056     5.8561843633651733e-01
    z[4,2,3]  R2057     4.7341939806938171e-01
    z[4,2,3]  R2058     2.2318008542060852e-01
    z[4,2,3]  R2059     3.6834666132926941e-01
    z[4,2,3]  R2060     1.9688328728079796e-02
    z[4,2,3]  R2061     2.5863319635391235e-02
    z[4,2,3]  R2062     -5.6284625083208084e-02
    z[4,2,3]  R2063     -1.7577295005321503e-01
    z[4,2,3]  R2064     -2.0616275072097778e-01
    z[4,2,3]  R2065     5.9721589088439941e-01
    z[4,2,3]  R2066     3.6833903193473816e-01
    z[4,2,3]  R2067     3.0313912034034729e-01
    z[4,2,3]  R2068     4.2844411730766296e-01
    z[4,2,3]  R2069     5.3503030538558960e-01
    z[4,2,3]  R2070     -1.0913491994142532e-01
    z[4,2,3]  R2071     -7.2018451988697052e-02
    z[4,2,3]  R2072     -2.4380747228860855e-02
    z[4,2,3]  R2073     2.8135562315583229e-02
    z[4,2,3]  R2074     2.9551374912261963e-01
    z[4,2,3]  R2075     -2.6950290799140930e-01
    z[4,2,3]  R2076     0.536393404006958
    z[4,2,3]  R2077     -4.9610573053359985e-01
    z[4,2,3]  R2078     3.1855475902557373e-01
    z[4,2,3]  R2079     2.5723496079444885e-01
    z[4,2,3]  R2080     -7.3913954198360443e-02
    z[4,2,3]  R2081     -0.0710030347108841
    z[4,2,3]  R2082     2.6913684606552124e-01
    z[4,2,3]  R2083     -4.8549634218215942e-01
    z[4,2,3]  R2084     -2.1894189715385437e-01
    z[4,2,3]  R2085     -3.2744863629341125e-01
    z[4,2,3]  R2086     -4.1578125953674316e-01
    z[4,2,3]  R2087     -9.1020818799734116e-03
    z[4,2,3]  R2088     -1.1704139411449432e-01
    z[4,2,3]  R2089     -2.7253192663192749e-01
    z[4,2,3]  R2090     -4.1588541865348816e-01
    z[4,2,3]  R2091     1.8047462403774261e-01
    z[4,2,3]  R2092     1.8411104381084442e-01
    z[4,2,3]  R2093     -2.1536672487854958e-02
    z[4,2,3]  R2094     2.3278267681598663e-01
    z[4,2,3]  R2095     -4.0269672870635986e-01
    z[4,2,3]  R2096     8.3176698535680771e-03
    z[4,2,3]  R2097     1.4700825512409210e-01
    z[4,2,3]  R2098     -4.5856767892837524e-01
    z[4,2,3]  R2099     -4.3998207896947861e-02
    z[4,2,3]  R2100     1.2758034281432629e-02
    z[4,2,3]  R2101     0.0983872041106224
    z[4,2,3]  R2102     6.8053025007247925e-01
    z[4,2,3]  R2103     -5.4386472702026367e-01
    z[4,2,3]  R2104     -3.4815445542335510e-01
    z[4,2,3]  R2105     -2.9917529225349426e-01
    z[4,2,3]  R2106     -3.3609643578529358e-01
    z[4,2,3]  R2107     -6.1731004714965820e-01
    z[4,2,3]  R2108     -6.9499629735946655e-01
    z[4,2,3]  R2109     -2.3235796391963959e-01
    z[4,2,3]  R2110     -3.8140979409217834e-01
    z[4,2,3]  R2111     -4.0274840593338013e-01
    z[4,2,3]  R2112     -4.0840244293212891e-01
    z[4,2,3]  R2113     -5.4294604063034058e-01
    z[4,2,3]  R2114     7.1361762285232544e-01
    z[4,2,3]  R2115     -2.2852474451065063e-01
    z[4,2,3]  R2116     -3.5795214772224426e-01
    z[4,2,3]  R2117     -2.6905605196952820e-01
    z[4,2,3]  R2118     5.6580636650323868e-02
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R2024     -1
    z[4,2,4]  R2025     1
    z[4,2,4]  R2030     -1.3108095526695251e-01
    z[4,2,4]  R2031     1.7517803609371185e-01
    z[4,2,4]  R2032     -5.0521481037139893e-01
    z[4,2,4]  R2033     -3.7098596803843975e-03
    z[4,2,4]  R2034     -7.8253731131553650e-02
    z[4,2,4]  R2035     1.8952155485749245e-02
    z[4,2,4]  R2036     1.0351741313934326e-01
    z[4,2,4]  R2037     -3.0360710620880127e-01
    z[4,2,4]  R2038     -2.0744135975837708e-01
    z[4,2,4]  R2039     -2.9577660560607910e-01
    z[4,2,4]  R2040     6.2534660100936890e-02
    z[4,2,4]  R2041     2.8456097841262817e-01
    z[4,2,4]  R2042     4.0337464213371277e-01
    z[4,2,4]  R2043     7.7082134783267975e-02
    z[4,2,4]  R2044     1.1331208795309067e-01
    z[4,2,4]  R2045     -2.6226335763931274e-01
    z[4,2,4]  R2046     -3.4285095334053040e-01
    z[4,2,4]  R2047     8.8250853121280670e-02
    z[4,2,4]  R2048     2.7964314818382263e-01
    z[4,2,4]  R2049     8.8019356131553650e-02
    z[4,2,4]  R2050     3.6297035217285156e-01
    z[4,2,4]  R2051     6.8603962659835815e-02
    z[4,2,4]  R2052     2.4468223750591278e-01
    z[4,2,4]  R2053     -4.6644932031631470e-01
    z[4,2,4]  R2054     -3.0253347754478455e-01
    z[4,2,4]  R2055     3.5661216825246811e-02
    z[4,2,4]  R2056     -2.8646424412727356e-01
    z[4,2,4]  R2057     -1.2093091756105423e-01
    z[4,2,4]  R2058     8.1553466618061066e-02
    z[4,2,4]  R2059     -5.2477353811264038e-01
    z[4,2,4]  R2060     1.6780348122119904e-01
    z[4,2,4]  R2061     -9.5293030142784119e-02
    z[4,2,4]  R2062     -5.0396603345870972e-01
    z[4,2,4]  R2063     1.4677263796329498e-01
    z[4,2,4]  R2064     -3.6618176102638245e-01
    z[4,2,4]  R2065     -4.2743611335754395e-01
    z[4,2,4]  R2066     -2.1006008982658386e-01
    z[4,2,4]  R2067     -7.2236508131027222e-01
    z[4,2,4]  R2068     -0.205518439412117
    z[4,2,4]  R2069     -5.8308511972427368e-01
    z[4,2,4]  R2070     -5.9225648641586304e-02
    z[4,2,4]  R2071     -1.6364024579524994e-01
    z[4,2,4]  R2072     -2.3171067237854004e-01
    z[4,2,4]  R2073     1.4094124734401703e-01
    z[4,2,4]  R2074     3.2538506388664246e-01
    z[4,2,4]  R2075     0.0657089427113533
    z[4,2,4]  R2076     3.0613413453102112e-01
    z[4,2,4]  R2077     3.8916683197021484e-01
    z[4,2,4]  R2078     2.6407399773597717e-01
    z[4,2,4]  R2079     1.0766576230525970e-01
    z[4,2,4]  R2080     3.0829259753227234e-01
    z[4,2,4]  R2081     0.542674720287323
    z[4,2,4]  R2082     -3.5133257508277893e-01
    z[4,2,4]  R2083     6.7589128017425537e-01
    z[4,2,4]  R2084     9.3958681821823120e-01
    z[4,2,4]  R2085     8.3078670501708984e-01
    z[4,2,4]  R2086     7.6595938205718994e-01
    z[4,2,4]  R2087     -3.4655591845512390e-01
    z[4,2,4]  R2088     8.8376337289810181e-01
    z[4,2,4]  R2089     6.3066780567169189e-01
    z[4,2,4]  R2090     3.0546778440475464e-01
    z[4,2,4]  R2091     0.541685938835144
    z[4,2,4]  R2092     2.6552131772041321e-01
    z[4,2,4]  R2093     5.4971385002136230e-01
    z[4,2,4]  R2094     1.4752371609210968e-01
    z[4,2,4]  R2095     3.7905752658843994e-01
    z[4,2,4]  R2096     1.2931534647941589e-01
    z[4,2,4]  R2097     -2.2250978276133537e-02
    z[4,2,4]  R2098     0.729640543460846
    z[4,2,4]  R2099     -6.8487298488616943e-01
    z[4,2,4]  R2100     -4.5553824305534363e-01
    z[4,2,4]  R2101     -4.0139034390449524e-01
    z[4,2,4]  R2102     3.2666096091270447e-01
    z[4,2,4]  R2103     6.5018379688262939e-01
    z[4,2,4]  R2104     0.615688145160675
    z[4,2,4]  R2105     6.1329811811447144e-01
    z[4,2,4]  R2106     6.6873502731323242e-01
    z[4,2,4]  R2107     6.3954770565032959e-01
    z[4,2,4]  R2108     3.2765284180641174e-01
    z[4,2,4]  R2109     6.7813855409622192e-01
    z[4,2,4]  R2110     -5.0727075338363647e-01
    z[4,2,4]  R2111     -3.3661961555480957e-01
    z[4,2,4]  R2112     9.8570518195629120e-02
    z[4,2,4]  R2113     6.1248999834060669e-01
    z[4,2,4]  R2114     -3.7129085510969162e-02
    z[4,2,4]  R2115     7.7158856391906738e-01
    z[4,2,4]  R2116     7.6849943399429321e-01
    z[4,2,4]  R2117     0.732159435749054
    z[4,2,4]  R2118     5.8081064373254776e-02
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R2026     -1
    z[4,2,5]  R2027     1
    z[4,2,5]  R2030     -2.7850124239921570e-01
    z[4,2,5]  R2031     1.2280213832855225e-01
    z[4,2,5]  R2032     4.8055514693260193e-02
    z[4,2,5]  R2033     -3.5813519358634949e-01
    z[4,2,5]  R2034     8.1823609769344330e-02
    z[4,2,5]  R2035     -3.6321735382080078e-01
    z[4,2,5]  R2036     -2.6041004061698914e-01
    z[4,2,5]  R2037     -6.7825573682785034e-01
    z[4,2,5]  R2038     -1.2281390838325024e-02
    z[4,2,5]  R2039     3.1469874083995819e-02
    z[4,2,5]  R2040     5.8050606399774551e-02
    z[4,2,5]  R2041     -1.4533384144306183e-01
    z[4,2,5]  R2042     1.5770610189065337e-03
    z[4,2,5]  R2043     1.1847331374883652e-01
    z[4,2,5]  R2044     -4.4052530080080032e-02
    z[4,2,5]  R2045     2.4003873765468597e-01
    z[4,2,5]  R2046     -1.1766491085290909e-01
    z[4,2,5]  R2047     1.6332441568374634e-01
    z[4,2,5]  R2048     -1.0694076865911484e-01
    z[4,2,5]  R2049     1.6248992085456848e-01
    z[4,2,5]  R2050     -2.2576166689395905e-01
    z[4,2,5]  R2051     -8.2591855525970459e-01
    z[4,2,5]  R2052     3.0087551474571228e-01
    z[4,2,5]  R2053     -1.8919488787651062e-01
    z[4,2,5]  R2054     -1.0286095738410950e-01
    z[4,2,5]  R2055     -9.0068064630031586e-02
    z[4,2,5]  R2056     1.7317394912242889e-01
    z[4,2,5]  R2057     2.8762108087539673e-01
    z[4,2,5]  R2058     3.4940522909164429e-01
    z[4,2,5]  R2059     2.5666022300720215e-01
    z[4,2,5]  R2060     -1.5103656053543091e-01
    z[4,2,5]  R2061     -6.2295131385326385e-02
    z[4,2,5]  R2062     -0.0794144868850708
    z[4,2,5]  R2063     -7.3905050754547119e-02
    z[4,2,5]  R2064     -0.553706169128418
    z[4,2,5]  R2065     -0.50154048204422
    z[4,2,5]  R2066     -8.5121077299118042e-01
    z[4,2,5]  R2067     -5.6201732158660889e-01
    z[4,2,5]  R2068     -6.5065312385559082e-01
    z[4,2,5]  R2069     -0.338346391916275
    z[4,2,5]  R2070     -8.2619205117225647e-02
    z[4,2,5]  R2071     -1.1536671966314316e-01
    z[4,2,5]  R2072     -1.1266986839473248e-02
    z[4,2,5]  R2073     -3.0776521563529968e-01
    z[4,2,5]  R2074     2.1929222345352173e-01
    z[4,2,5]  R2075     4.4513073563575745e-01
    z[4,2,5]  R2076     2.4503825604915619e-01
    z[4,2,5]  R2077     2.3875932395458221e-01
    z[4,2,5]  R2078     2.1600700914859772e-01
    z[4,2,5]  R2079     3.1031739711761475e-01
    z[4,2,5]  R2080     -5.0032925605773926e-01
    z[4,2,5]  R2081     -6.4615093171596527e-02
    z[4,2,5]  R2082     -3.0091321095824242e-03
    z[4,2,5]  R2083     -9.5629818737506866e-02
    z[4,2,5]  R2084     0.0893244668841362
    z[4,2,5]  R2085     -2.0185333490371704e-01
    z[4,2,5]  R2086     -5.3852040320634842e-02
    z[4,2,5]  R2087     4.5460018515586853e-01
    z[4,2,5]  R2088     1.1297465115785599e-01
    z[4,2,5]  R2089     -1.1456539481878281e-01
    z[4,2,5]  R2090     5.3864598274230957e-01
    z[4,2,5]  R2091     -1.5818008780479431e-01
    z[4,2,5]  R2092     -2.5313705205917358e-01
    z[4,2,5]  R2093     3.8068592548370361e-01
    z[4,2,5]  R2094     6.9146496057510376e-01
    z[4,2,5]  R2095     1.8906120955944061e-01
    z[4,2,5]  R2096     2.3913174867630005e-01
    z[4,2,5]  R2097     2.2060884535312653e-01
    z[4,2,5]  R2098     -1.7037029564380646e-01
    z[4,2,5]  R2099     1.4622513949871063e-01
    z[4,2,5]  R2100     -1.1423914879560471e-01
    z[4,2,5]  R2101     -1.4322666823863983e-01
    z[4,2,5]  R2102     -1.0807734727859497e-01
    z[4,2,5]  R2103     1.5783878043293953e-02
    z[4,2,5]  R2104     4.9813590943813324e-02
    z[4,2,5]  R2105     -1.0862774401903152e-01
    z[4,2,5]  R2106     5.8036959171295166e-01
    z[4,2,5]  R2107     4.1192063689231873e-01
    z[4,2,5]  R2108     5.0464153289794922e-01
    z[4,2,5]  R2109     4.2999365925788879e-01
    z[4,2,5]  R2110     -5.0462526082992554e-01
    z[4,2,5]  R2111     -1.6671015322208405e-01
    z[4,2,5]  R2112     1.7743869125843048e-01
    z[4,2,5]  R2113     9.9554657936096191e-02
    z[4,2,5]  R2114     2.8193006291985512e-02
    z[4,2,5]  R2115     -2.9880398511886597e-01
    z[4,2,5]  R2116     3.6627429723739624e-01
    z[4,2,5]  R2117     -1.4255641959607601e-02
    z[4,2,5]  R2118     3.4274047613143921e-01
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R2028     -1
    z[4,2,6]  R2029     1
    z[4,2,6]  R2030     1.3542146980762482e-01
    z[4,2,6]  R2031     -0.00367422285489738
    z[4,2,6]  R2032     -1.0799888521432877e-01
    z[4,2,6]  R2033     -6.1507290601730347e-01
    z[4,2,6]  R2034     1.2677150964736938e-01
    z[4,2,6]  R2035     4.8420354723930359e-01
    z[4,2,6]  R2036     2.0706895738840103e-02
    z[4,2,6]  R2037     3.2840543985366821e-01
    z[4,2,6]  R2038     -2.9542544484138489e-01
    z[4,2,6]  R2039     3.0984729528427124e-01
    z[4,2,6]  R2040     1.5701831877231598e-01
    z[4,2,6]  R2041     -1.4757920987904072e-02
    z[4,2,6]  R2042     -2.2041529417037964e-01
    z[4,2,6]  R2043     -2.5851166248321533e-01
    z[4,2,6]  R2044     -3.4218841791152954e-01
    z[4,2,6]  R2045     -1.1786611378192902e-01
    z[4,2,6]  R2046     1.7341071367263794e-01
    z[4,2,6]  R2047     -7.6179198920726776e-02
    z[4,2,6]  R2048     -5.1968467235565186e-01
    z[4,2,6]  R2049     -3.6494970321655273e-01
    z[4,2,6]  R2050     -1.2957751750946045e-01
    z[4,2,6]  R2051     1.1584952473640442e-01
    z[4,2,6]  R2052     1.1547765135765076e-01
    z[4,2,6]  R2053     -1.2766093015670776e-01
    z[4,2,6]  R2054     1.0075343400239944e-01
    z[4,2,6]  R2055     2.5603345036506653e-01
    z[4,2,6]  R2056     3.4406366944313049e-01
    z[4,2,6]  R2057     -1.7734996974468231e-01
    z[4,2,6]  R2058     -0.0982140377163887
    z[4,2,6]  R2059     -1.2797258794307709e-01
    z[4,2,6]  R2060     -2.5069481134414673e-01
    z[4,2,6]  R2061     2.0381264388561249e-01
    z[4,2,6]  R2062     -2.8867053985595703e-01
    z[4,2,6]  R2063     3.7670439481735229e-01
    z[4,2,6]  R2064     3.1335431337356567e-01
    z[4,2,6]  R2065     -1.0851830244064331e-01
    z[4,2,6]  R2066     4.4684566557407379e-02
    z[4,2,6]  R2067     1.6724999248981476e-01
    z[4,2,6]  R2068     4.3016341328620911e-01
    z[4,2,6]  R2069     3.4454837441444397e-01
    z[4,2,6]  R2070     -3.2937828451395035e-02
    z[4,2,6]  R2071     -1.2528675794601440e-01
    z[4,2,6]  R2072     6.4339734613895416e-02
    z[4,2,6]  R2073     -8.2796871662139893e-02
    z[4,2,6]  R2074     -1.4643880724906921e-01
    z[4,2,6]  R2075     3.0713915824890137e-01
    z[4,2,6]  R2076     6.8526528775691986e-02
    z[4,2,6]  R2077     -1.0783251374959946e-01
    z[4,2,6]  R2078     2.5204023718833923e-01
    z[4,2,6]  R2079     -6.3451957702636719e-01
    z[4,2,6]  R2080     3.9810085296630859e-01
    z[4,2,6]  R2081     3.2346194982528687e-01
    z[4,2,6]  R2082     5.4837477207183838e-01
    z[4,2,6]  R2083     3.2659384608268738e-01
    z[4,2,6]  R2084     -9.7096830606460571e-02
    z[4,2,6]  R2085     -1.2588070333003998e-01
    z[4,2,6]  R2086     -3.2313096523284912e-01
    z[4,2,6]  R2087     -4.4252294301986694e-01
    z[4,2,6]  R2088     -1.6365081071853638e-01
    z[4,2,6]  R2089     1.5072350203990936e-01
    z[4,2,6]  R2090     -1.0466154664754868e-01
    z[4,2,6]  R2091     1.0212297551333904e-02
    z[4,2,6]  R2092     2.6807376742362976e-01
    z[4,2,6]  R2093     -1.0517653077840805e-01
    z[4,2,6]  R2094     -9.1191403567790985e-02
    z[4,2,6]  R2095     3.6306518316268921e-01
    z[4,2,6]  R2096     4.8085975646972656e-01
    z[4,2,6]  R2097     -6.9738447666168213e-01
    z[4,2,6]  R2098     1.5220688283443451e-01
    z[4,2,6]  R2099     1.7330373823642731e-01
    z[4,2,6]  R2100     1.7091201245784760e-01
    z[4,2,6]  R2101     3.7513554096221924e-01
    z[4,2,6]  R2102     1.5162459574639797e-02
    z[4,2,6]  R2103     -3.5503348708152771e-01
    z[4,2,6]  R2104     -0.428116112947464
    z[4,2,6]  R2105     -5.8395510911941528e-01
    z[4,2,6]  R2106     -2.4148355424404144e-01
    z[4,2,6]  R2107     1.3274788856506348e-01
    z[4,2,6]  R2108     -1.6567483544349670e-02
    z[4,2,6]  R2109     2.7294814586639404e-01
    z[4,2,6]  R2110     3.3952745795249939e-01
    z[4,2,6]  R2111     6.0924154520034790e-01
    z[4,2,6]  R2112     2.6959735155105591e-01
    z[4,2,6]  R2113     -1.5009182691574097e-01
    z[4,2,6]  R2114     3.1779631972312927e-01
    z[4,2,6]  R2115     -3.9673903584480286e-01
    z[4,2,6]  R2116     5.5634602904319763e-02
    z[4,2,6]  R2117     2.5438934564590454e-01
    z[4,2,6]  R2118     -2.8624063730239868e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2192     -1
    z[3,4,0]  R2193     1
    z[3,4,0]  R2206     2.5813335180282593e-01
    z[3,4,0]  R2207     -9.3980008363723755e-01
    z[3,4,0]  R2208     -9.2294001579284668e-01
    z[3,4,0]  R2209     5.8017861843109131e-01
    z[3,4,0]  R2210     -8.6002784967422485e-01
    z[3,4,0]  R2211     -0.892230212688446
    z[3,4,0]  R2212     -9.4262242317199707e-01
    z[3,4,0]  R2213     -9.1773474216461182e-01
    z[3,4,0]  R2214     -8.9749175310134888e-01
    z[3,4,0]  R2215     -0.83182692527771
    z[3,4,0]  R2216     5.5075997114181519e-01
    z[3,4,0]  R2217     4.8558406531810760e-02
    z[3,4,0]  R2218     2.1610417962074280e-01
    z[3,4,0]  R2219     5.7938706874847412e-01
    z[3,4,0]  R2220     1.8145748972892761e-01
    z[3,4,0]  R2221     3.6470952630043030e-01
    z[3,4,0]  R2222     3.6930146813392639e-01
    z[3,4,0]  R2223     3.9038211107254028e-01
    z[3,4,0]  R2224     2.6583820581436157e-01
    z[3,4,0]  R2225     2.2130346298217773e-01
    z[3,4,0]  R2226     4.6522235870361328e-01
    z[3,4,0]  R2227     6.5786594152450562e-01
    z[3,4,0]  R2228     4.9325266480445862e-01
    z[3,4,0]  R2229     3.5619714856147766e-01
    z[3,4,0]  R2230     5.5103158950805664e-01
    z[3,4,0]  R2231     2.9873868823051453e-01
    z[3,4,0]  R2232     -3.5717669129371643e-01
    z[3,4,0]  R2233     -2.7027529478073120e-01
    z[3,4,0]  R2234     -0.3973388671875
    z[3,4,0]  R2235     -2.8489735722541809e-01
    z[3,4,0]  R2236     6.8873858451843262e-01
    z[3,4,0]  R2237     0.576435387134552
    z[3,4,0]  R2238     -1.0018469393253326e-01
    z[3,4,0]  R2239     6.7038416862487793e-02
    z[3,4,0]  R2240     3.8674166798591614e-01
    z[3,4,0]  R2241     3.9960426092147827e-01
    z[3,4,0]  R2242     3.9525407552719116e-01
    z[3,4,0]  R2243     3.9926269650459290e-01
    z[3,4,0]  R2244     -3.9417085051536560e-01
    z[3,4,0]  R2245     5.6480592489242554e-01
    z[3,4,0]  R2246     5.3114473819732666e-01
    z[3,4,0]  R2247     -5.3321599960327148e-02
    z[3,4,0]  R2248     3.0768087506294250e-01
    z[3,4,0]  R2249     1.9263944029808044e-01
    z[3,4,0]  R2250     1.9228491187095642e-01
    z[3,4,0]  R2251     -3.8100141286849976e-01
    z[3,4,0]  R2252     5.4885959625244141e-01
    z[3,4,0]  R2253     6.0691988468170166e-01
    z[3,4,0]  R2254     -4.7804492712020874e-01
    z[3,4,0]  R2255     3.6181899905204773e-01
    z[3,4,0]  R2256     5.7915753126144409e-01
    z[3,4,0]  R2257     -1.7139646410942078e-01
    z[3,4,0]  R2258     2.4324850738048553e-01
    z[3,4,0]  R2259     2.1458587050437927e-01
    z[3,4,0]  R2260     3.3688443899154663e-01
    z[3,4,0]  R2261     -1.5396653115749359e-01
    z[3,4,0]  R2262     -3.9778491854667664e-01
    z[3,4,0]  R2263     -5.5805152654647827e-01
    z[3,4,0]  R2264     2.9693955183029175e-01
    z[3,4,0]  R2265     -3.9586779475212097e-01
    z[3,4,0]  R2266     3.9001861214637756e-01
    z[3,4,0]  R2267     -1.1424923688173294e-01
    z[3,4,0]  R2268     1.1477511376142502e-01
    z[3,4,0]  R2269     3.7824258208274841e-01
    z[3,4,0]  R2270     4.2572364211082458e-01
    z[3,4,0]  R2271     -3.0046832561492920e-01
    z[3,4,0]  R2272     -4.1631302237510681e-01
    z[3,4,0]  R2273     -2.2245289757847786e-02
    z[3,4,0]  R2274     -1.5044157207012177e-01
    z[3,4,0]  R2275     -2.3720417916774750e-01
    z[3,4,0]  R2276     -6.7189380526542664e-02
    z[3,4,0]  R2277     3.3011120557785034e-01
    z[3,4,0]  R2278     2.8113198280334473e-01
    z[3,4,0]  R2279     -2.5362789630889893e-01
    z[3,4,0]  R2280     -4.4777533411979675e-01
    z[3,4,0]  R2281     2.2559408843517303e-01
    z[3,4,0]  R2282     1.6263779997825623e-01
    z[3,4,0]  R2283     -3.0208915472030640e-01
    z[3,4,0]  R2284     -2.7314043045043945e-01
    z[3,4,0]  R2285     -3.9606195688247681e-01
    z[3,4,0]  R2286     3.0516144633293152e-01
    z[3,4,0]  R2287     -1.5908235311508179e-01
    z[3,4,0]  R2288     3.5983249545097351e-01
    z[3,4,0]  R2289     4.0131369233131409e-01
    z[3,4,0]  R2290     -3.1321954727172852e-01
    z[3,4,0]  R2291     -2.8356176614761353e-01
    z[3,4,0]  R2292     -3.0964380502700806e-01
    z[3,4,0]  R2293     -3.9614996314048767e-01
    z[3,4,0]  R2294     -1.2843808531761169e-01
    z[3,4,0]  R2295     -2.2057932615280151e-01
    z[3,4,0]  R2296     -0.626301646232605
    z[3,4,0]  R2297     -8.4204000234603882e-01
    z[3,4,0]  R2298     -5.6200635433197021e-01
    z[3,4,0]  R2299     -5.3218764066696167e-01
    z[3,4,0]  R2300     -0.939971387386322
    z[3,4,0]  R2301     6.5989071130752563e-01
    z[3,4,0]  R2302     -9.3661779165267944e-01
    z[3,4,0]  R2303     5.6124496459960938e-01
    z[3,4,0]  R2304     -8.1057894229888916e-01
    z[3,4,0]  R2305     -8.1453180313110352e-01
    z[3,4,0]  R2306     -1.3804477453231812e-01
    z[3,4,0]  R2307     -1.4331266283988953e-01
    z[3,4,0]  R2308     1.3529990613460541e-01
    z[3,4,0]  R2309     1.8741910159587860e-01
    z[3,4,0]  R2310     1.1734388023614883e-01
    z[3,4,0]  R2311     -1.5084441751241684e-02
    z[3,4,0]  R2312     -4.1426301002502441e-01
    z[3,4,0]  R2313     8.9693886041641235e-01
    z[3,4,0]  R2314     7.0947146415710449e-01
    z[3,4,0]  R2315     0.85356205701828
    z[3,4,0]  R2316     6.7912268638610840e-01
    z[3,4,0]  R2317     4.6549555659294128e-01
    z[3,4,0]  R2318     -7.0993238687515259e-01
    z[3,4,0]  R2319     7.1068447828292847e-01
    z[3,4,0]  R2320     4.5530465245246887e-01
    z[3,4,0]  R2321     0.552579402923584
    z[3,4,0]  R2322     5.8852738142013550e-01
    z[3,4,0]  R2323     -3.5320860147476196e-01
    z[3,4,0]  R2324     -0.319614976644516
    z[3,4,0]  R2325     -2.3107655346393585e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2194     -1
    z[3,4,1]  R2195     1
    z[3,4,1]  R2206     4.5794308185577393e-01
    z[3,4,1]  R2207     1.5471121668815613e-01
    z[3,4,1]  R2208     1.6253520548343658e-01
    z[3,4,1]  R2209     5.4190081357955933e-01
    z[3,4,1]  R2210     1.8640153110027313e-01
    z[3,4,1]  R2211     0.0975256860256195
    z[3,4,1]  R2212     -9.9438624456524849e-03
    z[3,4,1]  R2213     2.0124214887619019e-01
    z[3,4,1]  R2214     2.0787183940410614e-01
    z[3,4,1]  R2215     2.8012225031852722e-01
    z[3,4,1]  R2216     4.9174398183822632e-01
    z[3,4,1]  R2217     5.9860908985137939e-01
    z[3,4,1]  R2218     5.6498810648918152e-02
    z[3,4,1]  R2219     1.5831539034843445e-01
    z[3,4,1]  R2220     2.6287177205085754e-01
    z[3,4,1]  R2221     1.3917708396911621e-01
    z[3,4,1]  R2222     -3.7313610315322876e-02
    z[3,4,1]  R2223     -6.4909934997558594e-01
    z[3,4,1]  R2224     -6.3023924827575684e-01
    z[3,4,1]  R2225     -0.601081371307373
    z[3,4,1]  R2226     4.8583567142486572e-01
    z[3,4,1]  R2227     1.6910223662853241e-01
    z[3,4,1]  R2228     3.8512364029884338e-01
    z[3,4,1]  R2229     -2.4250841140747070e-01
    z[3,4,1]  R2230     2.0148472487926483e-01
    z[3,4,1]  R2231     5.6375807523727417e-01
    z[3,4,1]  R2232     -8.8710987567901611e-01
    z[3,4,1]  R2233     -8.7936633825302124e-01
    z[3,4,1]  R2234     -8.4518057107925415e-01
    z[3,4,1]  R2235     -8.9767938852310181e-01
    z[3,4,1]  R2236     3.1527695059776306e-01
    z[3,4,1]  R2237     1.0131421685218811e-01
    z[3,4,1]  R2238     6.2148368358612061e-01
    z[3,4,1]  R2239     6.3854932785034180e-01
    z[3,4,1]  R2240     -7.8269565105438232e-01
    z[3,4,1]  R2241     -7.5086838006973267e-01
    z[3,4,1]  R2242     -7.9141962528228760e-01
    z[3,4,1]  R2243     -8.3746296167373657e-01
    z[3,4,1]  R2244     -5.1557046175003052e-01
    z[3,4,1]  R2245     -6.1647754907608032e-01
    z[3,4,1]  R2246     3.2905480265617371e-01
    z[3,4,1]  R2247     9.5572900772094727e-01
    z[3,4,1]  R2248     3.0548056960105896e-01
    z[3,4,1]  R2249     1.9497880339622498e-01
    z[3,4,1]  R2250     5.1851749420166016e-01
    z[3,4,1]  R2251     6.3300591707229614e-01
    z[3,4,1]  R2252     -0.712550163269043
    z[3,4,1]  R2253     -7.5988835096359253e-01
    z[3,4,1]  R2254     -7.4890685081481934e-01
    z[3,4,1]  R2255     -6.0639894008636475e-01
    z[3,4,1]  R2256     6.6063940525054932e-01
    z[3,4,1]  R2257     7.8202486038208008e-01
    z[3,4,1]  R2258     1.7261256277561188e-01
    z[3,4,1]  R2259     -2.3551419377326965e-01
    z[3,4,1]  R2260     -2.0627915859222412e-01
    z[3,4,1]  R2261     -9.0729838609695435e-01
    z[3,4,1]  R2262     -8.2229351997375488e-01
    z[3,4,1]  R2263     -7.3243695497512817e-01
    z[3,4,1]  R2264     -5.0932437181472778e-01
    z[3,4,1]  R2265     -5.9857684373855591e-01
    z[3,4,1]  R2266     -1.8179433420300484e-02
    z[3,4,1]  R2267     8.6025208234786987e-01
    z[3,4,1]  R2268     4.1180285811424255e-01
    z[3,4,1]  R2269     -6.7911714315414429e-01
    z[3,4,1]  R2270     -6.1638671159744263e-01
    z[3,4,1]  R2271     -8.4821528196334839e-01
    z[3,4,1]  R2272     -6.9856476783752441e-01
    z[3,4,1]  R2273     -8.9396846294403076e-01
    z[3,4,1]  R2274     -8.1388109922409058e-01
    z[3,4,1]  R2275     -8.0397886037826538e-01
    z[3,4,1]  R2276     1.1819742619991302e-02
    z[3,4,1]  R2277     -7.3750841617584229e-01
    z[3,4,1]  R2278     -5.9825807809829712e-01
    z[3,4,1]  R2279     -0.844097912311554
    z[3,4,1]  R2280     -5.0424879789352417e-01
    z[3,4,1]  R2281     -6.4740163087844849e-01
    z[3,4,1]  R2282     -4.7776961326599121e-01
    z[3,4,1]  R2283     -5.2313446998596191e-01
    z[3,4,1]  R2284     -7.1146863698959351e-01
    z[3,4,1]  R2285     -0.487781286239624
    z[3,4,1]  R2286     1.2014646083116531e-02
    z[3,4,1]  R2287     6.5612250566482544e-01
    z[3,4,1]  R2288     -6.7768466472625732e-01
    z[3,4,1]  R2289     -7.2295677661895752e-01
    z[3,4,1]  R2290     -8.6170834302902222e-01
    z[3,4,1]  R2291     -0.867425799369812
    z[3,4,1]  R2292     -4.6951338648796082e-01
    z[3,4,1]  R2293     -4.7382223606109619e-01
    z[3,4,1]  R2294     -9.8977647721767426e-02
    z[3,4,1]  R2295     -2.1678347885608673e-01
    z[3,4,1]  R2296     -0.575942873954773
    z[3,4,1]  R2297     -8.1678695976734161e-02
    z[3,4,1]  R2298     -1.9468982517719269e-01
    z[3,4,1]  R2299     -8.7245449423789978e-02
    z[3,4,1]  R2300     -1.4296740293502808e-01
    z[3,4,1]  R2301     1.5793354809284210e-01
    z[3,4,1]  R2302     6.2615498900413513e-02
    z[3,4,1]  R2303     -8.5508622229099274e-02
    z[3,4,1]  R2304     2.1103753149509430e-01
    z[3,4,1]  R2305     0.0857396051287651
    z[3,4,1]  R2306     8.7869238853454590e-01
    z[3,4,1]  R2307     7.4564278125762939e-01
    z[3,4,1]  R2308     0.814132571220398
    z[3,4,1]  R2309     8.3106732368469238e-01
    z[3,4,1]  R2310     0.913650393486023
    z[3,4,1]  R2311     9.2196524143218994e-01
    z[3,4,1]  R2312     6.8651187419891357e-01
    z[3,4,1]  R2313     -3.4975543618202209e-01
    z[3,4,1]  R2314     -2.1639437973499298e-01
    z[3,4,1]  R2315     3.3483337610960007e-02
    z[3,4,1]  R2316     -5.4730284214019775e-01
    z[3,4,1]  R2317     -1.0956397652626038e-01
    z[3,4,1]  R2318     0.00622505834326148
    z[3,4,1]  R2319     5.1804497838020325e-02
    z[3,4,1]  R2320     -2.2204600274562836e-01
    z[3,4,1]  R2321     -2.3661231622099876e-02
    z[3,4,1]  R2322     2.3132576048374176e-01
    z[3,4,1]  R2323     -6.3067066669464111e-01
    z[3,4,1]  R2324     -8.3851498365402222e-01
    z[3,4,1]  R2325     -6.7305499315261841e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2196     -1
    z[3,4,2]  R2197     1
    z[3,4,2]  R2206     4.7317445278167725e-01
    z[3,4,2]  R2207     -7.1036987006664276e-02
    z[3,4,2]  R2208     3.9349254220724106e-03
    z[3,4,2]  R2209     6.0475575923919678e-01
    z[3,4,2]  R2210     -1.0655601322650909e-01
    z[3,4,2]  R2211     1.0289722681045532e-01
    z[3,4,2]  R2212     -1.4623812399804592e-02
    z[3,4,2]  R2213     -1.1547831445932388e-01
    z[3,4,2]  R2214     2.7077925205230713e-01
    z[3,4,2]  R2215     3.0057525634765625e-01
    z[3,4,2]  R2216     -6.0011076927185059e-01
    z[3,4,2]  R2217     -2.8771796822547913e-01
    z[3,4,2]  R2218     -0.17482890188694
    z[3,4,2]  R2219     5.7021718472242355e-02
    z[3,4,2]  R2220     -2.6236066222190857e-01
    z[3,4,2]  R2221     -2.7732434868812561e-01
    z[3,4,2]  R2222     -5.6132465600967407e-02
    z[3,4,2]  R2223     2.5654694437980652e-01
    z[3,4,2]  R2224     -2.4898232519626617e-01
    z[3,4,2]  R2225     -4.8615369945764542e-02
    z[3,4,2]  R2226     -2.3697596788406372e-01
    z[3,4,2]  R2227     0.478730708360672
    z[3,4,2]  R2228     1.1790613085031509e-01
    z[3,4,2]  R2229     1.5007908223196864e-03
    z[3,4,2]  R2230     -3.0414253473281860e-01
    z[3,4,2]  R2231     -4.6622648835182190e-01
    z[3,4,2]  R2232     1.2217401713132858e-01
    z[3,4,2]  R2233     -7.3766350746154785e-02
    z[3,4,2]  R2234     8.6302056908607483e-02
    z[3,4,2]  R2235     7.0185407996177673e-02
    z[3,4,2]  R2236     -1.1465033888816833e-01
    z[3,4,2]  R2237     -1.8005770444869995e-01
    z[3,4,2]  R2238     2.2961066663265228e-01
    z[3,4,2]  R2239     -5.6701207160949707e-01
    z[3,4,2]  R2240     -7.0753586478531361e-03
    z[3,4,2]  R2241     -4.2569848895072937e-01
    z[3,4,2]  R2242     3.8507454097270966e-02
    z[3,4,2]  R2243     -2.1936345100402832e-01
    z[3,4,2]  R2244     -4.4113822281360626e-02
    z[3,4,2]  R2245     -2.9070353507995605e-01
    z[3,4,2]  R2246     3.1474274396896362e-01
    z[3,4,2]  R2247     -1.3277991116046906e-01
    z[3,4,2]  R2248     -2.0039129257202148e-01
    z[3,4,2]  R2249     3.3667656779289246e-01
    z[3,4,2]  R2250     9.5063023269176483e-02
    z[3,4,2]  R2251     1.8678675591945648e-01
    z[3,4,2]  R2252     -1.5000531077384949e-01
    z[3,4,2]  R2253     1.4589686691761017e-01
    z[3,4,2]  R2254     -1.3811717927455902e-01
    z[3,4,2]  R2255     -3.2649955153465271e-01
    z[3,4,2]  R2256     -7.7538035809993744e-02
    z[3,4,2]  R2257     2.7904254198074341e-01
    z[3,4,2]  R2258     4.6756044030189514e-01
    z[3,4,2]  R2259     5.8996933698654175e-01
    z[3,4,2]  R2260     3.0695015192031860e-01
    z[3,4,2]  R2261     -8.3865828812122345e-02
    z[3,4,2]  R2262     -0.201654851436615
    z[3,4,2]  R2263     2.3760262876749039e-02
    z[3,4,2]  R2264     1.9889634847640991e-01
    z[3,4,2]  R2265     -4.1506299376487732e-01
    z[3,4,2]  R2266     1.5373519062995911e-01
    z[3,4,2]  R2267     6.0239702463150024e-02
    z[3,4,2]  R2268     -2.5170063972473145e-01
    z[3,4,2]  R2269     -3.9540448784828186e-01
    z[3,4,2]  R2270     1.8756791949272156e-01
    z[3,4,2]  R2271     -1.8159843981266022e-01
    z[3,4,2]  R2272     -1.4692538976669312e-01
    z[3,4,2]  R2273     2.8810954093933105e-01
    z[3,4,2]  R2274     0.518994152545929
    z[3,4,2]  R2275     -7.1790322661399841e-02
    z[3,4,2]  R2276     2.0671610534191132e-01
    z[3,4,2]  R2277     -2.9173594713211060e-01
    z[3,4,2]  R2278     -2.5543960928916931e-01
    z[3,4,2]  R2279     -2.7297517657279968e-01
    z[3,4,2]  R2280     -4.6042707562446594e-01
    z[3,4,2]  R2281     1.2205547094345093e-01
    z[3,4,2]  R2282     -1.7233356833457947e-01
    z[3,4,2]  R2283     -0.463856041431427
    z[3,4,2]  R2284     -0.343553364276886
    z[3,4,2]  R2285     -5.5767357349395752e-01
    z[3,4,2]  R2286     2.7804297208786011e-01
    z[3,4,2]  R2287     -6.2095586210489273e-02
    z[3,4,2]  R2288     -2.0334620773792267e-01
    z[3,4,2]  R2289     -4.3719375133514404e-01
    z[3,4,2]  R2290     -3.4538358449935913e-01
    z[3,4,2]  R2291     2.2523038089275360e-01
    z[3,4,2]  R2292     -1.1186144500970840e-01
    z[3,4,2]  R2293     -2.3457500338554382e-01
    z[3,4,2]  R2294     -3.6460712552070618e-01
    z[3,4,2]  R2295     -7.4643462896347046e-01
    z[3,4,2]  R2296     3.8755902647972107e-01
    z[3,4,2]  R2297     4.8647314310073853e-01
    z[3,4,2]  R2298     6.0824459791183472e-01
    z[3,4,2]  R2299     4.3417137861251831e-01
    z[3,4,2]  R2300     -1.4967535436153412e-01
    z[3,4,2]  R2301     -4.1559547185897827e-01
    z[3,4,2]  R2302     -1.9692401587963104e-01
    z[3,4,2]  R2303     -1.1192564666271210e-01
    z[3,4,2]  R2304     -1.9925747811794281e-01
    z[3,4,2]  R2305     4.4076152145862579e-02
    z[3,4,2]  R2306     -0.348624587059021
    z[3,4,2]  R2307     -5.3115451335906982e-01
    z[3,4,2]  R2308     -3.2606229186058044e-01
    z[3,4,2]  R2309     -2.7933281660079956e-01
    z[3,4,2]  R2310     -0.0719640925526619
    z[3,4,2]  R2311     -0.0854223445057869
    z[3,4,2]  R2312     -3.4509435296058655e-01
    z[3,4,2]  R2313     1.6582074761390686e-01
    z[3,4,2]  R2314     2.6561295986175537e-01
    z[3,4,2]  R2315     3.1241217255592346e-01
    z[3,4,2]  R2316     3.5691785160452127e-03
    z[3,4,2]  R2317     -2.1841278672218323e-01
    z[3,4,2]  R2318     3.8633834570646286e-02
    z[3,4,2]  R2319     1.4892983436584473e-01
    z[3,4,2]  R2320     -1.7980413138866425e-01
    z[3,4,2]  R2321     0.190543994307518
    z[3,4,2]  R2322     1.6353680193424225e-01
    z[3,4,2]  R2323     -0.352943480014801
    z[3,4,2]  R2324     -8.0922663211822510e-02
    z[3,4,2]  R2325     -1.6812250018119812e-02
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2198     -1
    z[3,4,3]  R2199     1
    z[3,4,3]  R2206     -3.7363407015800476e-01
    z[3,4,3]  R2207     -2.3972152173519135e-01
    z[3,4,3]  R2208     -1.9779071211814880e-01
    z[3,4,3]  R2209     -7.7056130394339561e-03
    z[3,4,3]  R2210     -2.0588600635528564e-01
    z[3,4,3]  R2211     3.0438458546996117e-02
    z[3,4,3]  R2212     -8.3044849336147308e-02
    z[3,4,3]  R2213     2.4156817793846130e-01
    z[3,4,3]  R2214     9.3204446136951447e-02
    z[3,4,3]  R2215     -1.8220625817775726e-01
    z[3,4,3]  R2216     -2.1709744632244110e-01
    z[3,4,3]  R2217     4.2003658413887024e-01
    z[3,4,3]  R2218     -6.1917316913604736e-01
    z[3,4,3]  R2219     -2.4185305833816528e-01
    z[3,4,3]  R2220     -4.7418147325515747e-01
    z[3,4,3]  R2221     -3.5897254943847656e-01
    z[3,4,3]  R2222     -6.7649924755096436e-01
    z[3,4,3]  R2223     5.8192396163940430e-01
    z[3,4,3]  R2224     5.5674391984939575e-01
    z[3,4,3]  R2225     6.7789024114608765e-01
    z[3,4,3]  R2226     -1.2351523339748383e-01
    z[3,4,3]  R2227     -3.7697765231132507e-01
    z[3,4,3]  R2228     -3.9568236470222473e-01
    z[3,4,3]  R2229     -4.5480468869209290e-01
    z[3,4,3]  R2230     -1.4198586344718933e-01
    z[3,4,3]  R2231     -3.2391302287578583e-02
    z[3,4,3]  R2232     -7.1297824382781982e-02
    z[3,4,3]  R2233     -1.7052255570888519e-01
    z[3,4,3]  R2234     -1.3055598735809326e-01
    z[3,4,3]  R2235     1.0369133204221725e-01
    z[3,4,3]  R2236     -5.6572878360748291e-01
    z[3,4,3]  R2237     -6.1591309309005737e-01
    z[3,4,3]  R2238     6.7653483152389526e-01
    z[3,4,3]  R2239     -1.1923617124557495e-01
    z[3,4,3]  R2240     3.2390314340591431e-01
    z[3,4,3]  R2241     3.9310574531555176e-02
    z[3,4,3]  R2242     1.3593333959579468e-01
    z[3,4,3]  R2243     -1.6196319460868835e-01
    z[3,4,3]  R2244     5.8970528841018677e-01
    z[3,4,3]  R2245     3.8669671863317490e-02
    z[3,4,3]  R2246     -1.9893029239028692e-03
    z[3,4,3]  R2247     1.4506794512271881e-01
    z[3,4,3]  R2248     -2.7058762311935425e-01
    z[3,4,3]  R2249     -5.8655035495758057e-01
    z[3,4,3]  R2250     -4.3224066495895386e-02
    z[3,4,3]  R2251     3.6754816770553589e-01
    z[3,4,3]  R2252     3.5326120257377625e-01
    z[3,4,3]  R2253     2.2708898410201073e-02
    z[3,4,3]  R2254     2.7809518575668335e-01
    z[3,4,3]  R2255     2.4823831021785736e-01
    z[3,4,3]  R2256     -2.7817955613136292e-01
    z[3,4,3]  R2257     -3.7966978549957275e-01
    z[3,4,3]  R2258     -5.1656246185302734e-01
    z[3,4,3]  R2259     -7.2383642196655273e-01
    z[3,4,3]  R2260     -4.3253010511398315e-01
    z[3,4,3]  R2261     -3.0411076545715332e-01
    z[3,4,3]  R2262     -5.1381520926952362e-02
    z[3,4,3]  R2263     2.3650184273719788e-01
    z[3,4,3]  R2264     5.2529340982437134e-01
    z[3,4,3]  R2265     2.6098170876502991e-01
    z[3,4,3]  R2266     -7.0872771739959717e-01
    z[3,4,3]  R2267     2.3492148146033287e-02
    z[3,4,3]  R2268     -5.7568907737731934e-01
    z[3,4,3]  R2269     2.0097626373171806e-02
    z[3,4,3]  R2270     3.1200775504112244e-01
    z[3,4,3]  R2271     -3.1716406345367432e-01
    z[3,4,3]  R2272     0.325791597366333
    z[3,4,3]  R2273     -1.7388641834259033e-01
    z[3,4,3]  R2274     -3.3776730298995972e-02
    z[3,4,3]  R2275     -9.5977261662483215e-02
    z[3,4,3]  R2276     -7.8665858507156372e-01
    z[3,4,3]  R2277     3.5539820790290833e-01
    z[3,4,3]  R2278     5.0124150514602661e-01
    z[3,4,3]  R2279     -1.1464725248515606e-02
    z[3,4,3]  R2280     4.6107214689254761e-01
    z[3,4,3]  R2281     4.3256533145904541e-01
    z[3,4,3]  R2282     6.0782027244567871e-01
    z[3,4,3]  R2283     1.7142720520496368e-01
    z[3,4,3]  R2284     3.2900744676589966e-01
    z[3,4,3]  R2285     -7.7450558543205261e-02
    z[3,4,3]  R2286     -6.4688611030578613e-01
    z[3,4,3]  R2287     3.6693942546844482e-01
    z[3,4,3]  R2288     0.519483745098114
    z[3,4,3]  R2289     5.1869828253984451e-02
    z[3,4,3]  R2290     1.3376979529857635e-01
    z[3,4,3]  R2291     1.4833371341228485e-01
    z[3,4,3]  R2292     4.6653857827186584e-01
    z[3,4,3]  R2293     1.1839896440505981e-01
    z[3,4,3]  R2294     6.3796001672744751e-01
    z[3,4,3]  R2295     2.9312953352928162e-01
    z[3,4,3]  R2296     -1.1291564255952835e-01
    z[3,4,3]  R2297     -4.3126974254846573e-02
    z[3,4,3]  R2298     -8.4073126316070557e-02
    z[3,4,3]  R2299     -1.1861911416053772e-01
    z[3,4,3]  R2300     -2.1147488057613373e-01
    z[3,4,3]  R2301     1.1938295327126980e-02
    z[3,4,3]  R2302     -3.3003918826580048e-02
    z[3,4,3]  R2303     -7.1461528539657593e-02
    z[3,4,3]  R2304     -3.5813751816749573e-01
    z[3,4,3]  R2305     3.7784200906753540e-01
    z[3,4,3]  R2306     2.3530612885951996e-01
    z[3,4,3]  R2307     -1.9758237898349762e-01
    z[3,4,3]  R2308     3.5624884068965912e-02
    z[3,4,3]  R2309     -0.330709308385849
    z[3,4,3]  R2310     1.2008894234895706e-01
    z[3,4,3]  R2311     -4.6502269804477692e-02
    z[3,4,3]  R2312     -2.7664867043495178e-01
    z[3,4,3]  R2313     -7.3545746505260468e-02
    z[3,4,3]  R2314     -1.3987350463867188e-01
    z[3,4,3]  R2315     7.3284611105918884e-02
    z[3,4,3]  R2316     -1.9933162629604340e-01
    z[3,4,3]  R2317     -1.5276260673999786e-01
    z[3,4,3]  R2318     5.7509493827819824e-01
    z[3,4,3]  R2319     -4.4765692949295044e-01
    z[3,4,3]  R2320     -7.7382522821426392e-01
    z[3,4,3]  R2321     7.6344740390777588e-01
    z[3,4,3]  R2322     5.8561843633651733e-01
    z[3,4,3]  R2323     4.7341939806938171e-01
    z[3,4,3]  R2324     2.2318008542060852e-01
    z[3,4,3]  R2325     3.6834666132926941e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2200     -1
    z[3,4,4]  R2201     1
    z[3,4,4]  R2206     3.4899908304214478e-01
    z[3,4,4]  R2207     1.3045790791511536e-01
    z[3,4,4]  R2208     6.4899399876594543e-02
    z[3,4,4]  R2209     5.2281104028224945e-02
    z[3,4,4]  R2210     -2.7794393897056580e-01
    z[3,4,4]  R2211     -4.3862383812665939e-02
    z[3,4,4]  R2212     -3.0529299378395081e-01
    z[3,4,4]  R2213     -0.0504038967192173
    z[3,4,4]  R2214     1.9112777709960938e-01
    z[3,4,4]  R2215     -4.1402861475944519e-02
    z[3,4,4]  R2216     -3.5263508558273315e-02
    z[3,4,4]  R2217     2.8810936212539673e-01
    z[3,4,4]  R2218     -6.4258921146392822e-01
    z[3,4,4]  R2219     -5.0122499465942383e-01
    z[3,4,4]  R2220     -7.5447636842727661e-01
    z[3,4,4]  R2221     -4.3736043572425842e-01
    z[3,4,4]  R2222     -2.8554555773735046e-01
    z[3,4,4]  R2223     -1.3387228548526764e-01
    z[3,4,4]  R2224     3.9674103260040283e-01
    z[3,4,4]  R2225     -1.8834735453128815e-01
    z[3,4,4]  R2226     1.6314629465341568e-02
    z[3,4,4]  R2227     3.4935045987367630e-02
    z[3,4,4]  R2228     -5.6127011775970459e-01
    z[3,4,4]  R2229     6.2418907880783081e-01
    z[3,4,4]  R2230     0.508728563785553
    z[3,4,4]  R2231     5.9628438949584961e-01
    z[3,4,4]  R2232     -9.6647582948207855e-02
    z[3,4,4]  R2233     -2.8975948691368103e-01
    z[3,4,4]  R2234     -1.2747314572334290e-01
    z[3,4,4]  R2235     2.3188865184783936e-01
    z[3,4,4]  R2236     -6.5716892480850220e-02
    z[3,4,4]  R2237     8.0855533480644226e-02
    z[3,4,4]  R2238     -3.2234955579042435e-02
    z[3,4,4]  R2239     -2.5378465652465820e-01
    z[3,4,4]  R2240     2.8136804699897766e-01
    z[3,4,4]  R2241     -1.0198257118463516e-01
    z[3,4,4]  R2242     -1.1463674902915955e-01
    z[3,4,4]  R2243     1.7112898826599121e-01
    z[3,4,4]  R2244     -2.5380682945251465e-01
    z[3,4,4]  R2245     9.4268575310707092e-02
    z[3,4,4]  R2246     6.5625023841857910e-01
    z[3,4,4]  R2247     -1.6640214622020721e-01
    z[3,4,4]  R2248     5.1289498805999756e-01
    z[3,4,4]  R2249     -4.8925641179084778e-01
    z[3,4,4]  R2250     2.7319782972335815e-01
    z[3,4,4]  R2251     2.0046363770961761e-01
    z[3,4,4]  R2252     -1.7939563095569611e-01
    z[3,4,4]  R2253     7.3708340525627136e-02
    z[3,4,4]  R2254     -2.0611342787742615e-01
    z[3,4,4]  R2255     1.1279787868261337e-01
    z[3,4,4]  R2256     2.5928923487663269e-01
    z[3,4,4]  R2257     1.6672702133655548e-01
    z[3,4,4]  R2258     -4.0130406618118286e-01
    z[3,4,4]  R2259     -5.1522977650165558e-02
    z[3,4,4]  R2260     4.1288143396377563e-01
    z[3,4,4]  R2261     -8.2583807408809662e-02
    z[3,4,4]  R2262     8.4618858993053436e-02
    z[3,4,4]  R2263     1.7774626612663269e-01
    z[3,4,4]  R2264     2.6971861720085144e-02
    z[3,4,4]  R2265     3.5232746601104736e-01
    z[3,4,4]  R2266     5.6551039218902588e-01
    z[3,4,4]  R2267     1.7291894555091858e-01
    z[3,4,4]  R2268     -3.7263345718383789e-01
    z[3,4,4]  R2269     -1.6487531363964081e-01
    z[3,4,4]  R2270     -3.3342546224594116e-01
    z[3,4,4]  R2271     2.2124059498310089e-01
    z[3,4,4]  R2272     1.4005471765995026e-01
    z[3,4,4]  R2273     2.7248656749725342e-01
    z[3,4,4]  R2274     -3.3528175204992294e-02
    z[3,4,4]  R2275     1.4610594511032104e-01
    z[3,4,4]  R2276     -1.8471702933311462e-02
    z[3,4,4]  R2277     -7.2325021028518677e-02
    z[3,4,4]  R2278     -2.2511104121804237e-02
    z[3,4,4]  R2279     1.9403712451457977e-01
    z[3,4,4]  R2280     1.2670768797397614e-01
    z[3,4,4]  R2281     -0.0792994499206543
    z[3,4,4]  R2282     -2.1422253549098969e-01
    z[3,4,4]  R2283     2.0323148369789124e-01
    z[3,4,4]  R2284     1.4503178000450134e-01
    z[3,4,4]  R2285     -3.4546792507171631e-01
    z[3,4,4]  R2286     -1.3877657055854797e-01
    z[3,4,4]  R2287     4.0217930078506470e-01
    z[3,4,4]  R2288     -3.1700424849987030e-02
    z[3,4,4]  R2289     2.9526901245117188e-01
    z[3,4,4]  R2290     -5.3333666175603867e-02
    z[3,4,4]  R2291     1.0146160423755646e-01
    z[3,4,4]  R2292     -1.7991612851619720e-01
    z[3,4,4]  R2293     -1.6010677814483643e-01
    z[3,4,4]  R2294     -3.0307593941688538e-01
    z[3,4,4]  R2295     -2.7151322364807129e-01
    z[3,4,4]  R2296     -1.3108095526695251e-01
    z[3,4,4]  R2297     1.7517803609371185e-01
    z[3,4,4]  R2298     -5.0521481037139893e-01
    z[3,4,4]  R2299     -3.7098596803843975e-03
    z[3,4,4]  R2300     -7.8253731131553650e-02
    z[3,4,4]  R2301     1.8952155485749245e-02
    z[3,4,4]  R2302     1.0351741313934326e-01
    z[3,4,4]  R2303     -3.0360710620880127e-01
    z[3,4,4]  R2304     -2.0744135975837708e-01
    z[3,4,4]  R2305     -2.9577660560607910e-01
    z[3,4,4]  R2306     6.2534660100936890e-02
    z[3,4,4]  R2307     2.8456097841262817e-01
    z[3,4,4]  R2308     4.0337464213371277e-01
    z[3,4,4]  R2309     7.7082134783267975e-02
    z[3,4,4]  R2310     1.1331208795309067e-01
    z[3,4,4]  R2311     -2.6226335763931274e-01
    z[3,4,4]  R2312     -3.4285095334053040e-01
    z[3,4,4]  R2313     8.8250853121280670e-02
    z[3,4,4]  R2314     2.7964314818382263e-01
    z[3,4,4]  R2315     8.8019356131553650e-02
    z[3,4,4]  R2316     3.6297035217285156e-01
    z[3,4,4]  R2317     6.8603962659835815e-02
    z[3,4,4]  R2318     2.4468223750591278e-01
    z[3,4,4]  R2319     -4.6644932031631470e-01
    z[3,4,4]  R2320     -3.0253347754478455e-01
    z[3,4,4]  R2321     3.5661216825246811e-02
    z[3,4,4]  R2322     -2.8646424412727356e-01
    z[3,4,4]  R2323     -1.2093091756105423e-01
    z[3,4,4]  R2324     8.1553466618061066e-02
    z[3,4,4]  R2325     -5.2477353811264038e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2202     -1
    z[3,4,5]  R2203     1
    z[3,4,5]  R2206     -4.8548573255538940e-01
    z[3,4,5]  R2207     6.3925251364707947e-02
    z[3,4,5]  R2208     -1.3533490896224976e-01
    z[3,4,5]  R2209     -2.9999520629644394e-02
    z[3,4,5]  R2210     -2.9029190540313721e-01
    z[3,4,5]  R2211     -4.2483350634574890e-01
    z[3,4,5]  R2212     -4.1109815239906311e-02
    z[3,4,5]  R2213     -0.0789119228720665
    z[3,4,5]  R2214     0.00739058293402195
    z[3,4,5]  R2215     -2.2993431985378265e-01
    z[3,4,5]  R2216     2.0528608560562134e-01
    z[3,4,5]  R2217     -2.4083724617958069e-01
    z[3,4,5]  R2218     -1.9655372202396393e-01
    z[3,4,5]  R2219     1.6232709586620331e-01
    z[3,4,5]  R2220     -1.7088063061237335e-01
    z[3,4,5]  R2221     -0.0994378998875618
    z[3,4,5]  R2222     2.9747176170349121e-01
    z[3,4,5]  R2223     -5.1031500101089478e-02
    z[3,4,5]  R2224     -4.4756412506103516e-02
    z[3,4,5]  R2225     2.6538664102554321e-01
    z[3,4,5]  R2226     -2.2161072492599487e-01
    z[3,4,5]  R2227     8.1138901412487030e-02
    z[3,4,5]  R2228     1.0783676803112030e-01
    z[3,4,5]  R2229     1.5114578604698181e-01
    z[3,4,5]  R2230     4.8304149508476257e-01
    z[3,4,5]  R2231     -1.2417440861463547e-01
    z[3,4,5]  R2232     -5.2974302321672440e-02
    z[3,4,5]  R2233     1.1111255735158920e-02
    z[3,4,5]  R2234     -8.2784526050090790e-02
    z[3,4,5]  R2235     1.1146222800016403e-01
    z[3,4,5]  R2236     0.251359224319458
    z[3,4,5]  R2237     4.1499685496091843e-02
    z[3,4,5]  R2238     -2.8766372799873352e-01
    z[3,4,5]  R2239     -4.3079584836959839e-01
    z[3,4,5]  R2240     2.2054976224899292e-01
    z[3,4,5]  R2241     -1.4317522943019867e-01
    z[3,4,5]  R2242     4.1190677881240845e-01
    z[3,4,5]  R2243     1.5191332995891571e-01
    z[3,4,5]  R2244     3.1151914596557617e-01
    z[3,4,5]  R2245     3.9414763450622559e-01
    z[3,4,5]  R2246     2.2859179973602295e-01
    z[3,4,5]  R2247     -1.1515405774116516e-01
    z[3,4,5]  R2248     -3.2339328527450562e-01
    z[3,4,5]  R2249     -1.7447908222675323e-01
    z[3,4,5]  R2250     -2.9478749260306358e-02
    z[3,4,5]  R2251     0.340032160282135
    z[3,4,5]  R2252     1.0683614015579224e-01
    z[3,4,5]  R2253     -1.3590057194232941e-01
    z[3,4,5]  R2254     -2.6704284548759460e-01
    z[3,4,5]  R2255     1.3821706175804138e-01
    z[3,4,5]  R2256     -2.4591540917754173e-02
    z[3,4,5]  R2257     1.7587290704250336e-01
    z[3,4,5]  R2258     -6.7038662731647491e-02
    z[3,4,5]  R2259     -1.2629090249538422e-01
    z[3,4,5]  R2260     -2.9961558058857918e-02
    z[3,4,5]  R2261     1.6140486299991608e-01
    z[3,4,5]  R2262     3.3552536368370056e-01
    z[3,4,5]  R2263     2.3200479149818420e-01
    z[3,4,5]  R2264     1.7891988158226013e-01
    z[3,4,5]  R2265     2.6513275504112244e-01
    z[3,4,5]  R2266     -8.6372224614024162e-03
    z[3,4,5]  R2267     -4.5620220899581909e-01
    z[3,4,5]  R2268     -5.3024077415466309e-01
    z[3,4,5]  R2269     7.6076802797615528e-03
    z[3,4,5]  R2270     -2.6597169041633606e-01
    z[3,4,5]  R2271     -1.9071632996201515e-02
    z[3,4,5]  R2272     2.7643588185310364e-01
    z[3,4,5]  R2273     1.4667242765426636e-02
    z[3,4,5]  R2274     1.9412128627300262e-01
    z[3,4,5]  R2275     -0.51123046875
    z[3,4,5]  R2276     -4.3620994687080383e-01
    z[3,4,5]  R2277     3.6117190122604370e-01
    z[3,4,5]  R2278     -2.8672000765800476e-01
    z[3,4,5]  R2279     -3.2860684394836426e-01
    z[3,4,5]  R2280     2.9860296845436096e-01
    z[3,4,5]  R2281     1.2046633660793304e-01
    z[3,4,5]  R2282     -2.8808993101119995e-01
    z[3,4,5]  R2283     4.9473512172698975e-01
    z[3,4,5]  R2284     -9.4497554004192352e-02
    z[3,4,5]  R2285     2.6760599017143250e-01
    z[3,4,5]  R2286     -3.1865677237510681e-01
    z[3,4,5]  R2287     4.2646953463554382e-01
    z[3,4,5]  R2288     2.1734078228473663e-01
    z[3,4,5]  R2289     -1.1890596896409988e-01
    z[3,4,5]  R2290     1.2651601433753967e-01
    z[3,4,5]  R2291     -2.9000097513198853e-01
    z[3,4,5]  R2292     5.5134242773056030e-01
    z[3,4,5]  R2293     3.9442360401153564e-01
    z[3,4,5]  R2294     5.3061836957931519e-01
    z[3,4,5]  R2295     4.0059766173362732e-01
    z[3,4,5]  R2296     -2.7850124239921570e-01
    z[3,4,5]  R2297     1.2280213832855225e-01
    z[3,4,5]  R2298     4.8055514693260193e-02
    z[3,4,5]  R2299     -3.5813519358634949e-01
    z[3,4,5]  R2300     8.1823609769344330e-02
    z[3,4,5]  R2301     -3.6321735382080078e-01
    z[3,4,5]  R2302     -2.6041004061698914e-01
    z[3,4,5]  R2303     -6.7825573682785034e-01
    z[3,4,5]  R2304     -1.2281390838325024e-02
    z[3,4,5]  R2305     3.1469874083995819e-02
    z[3,4,5]  R2306     5.8050606399774551e-02
    z[3,4,5]  R2307     -1.4533384144306183e-01
    z[3,4,5]  R2308     1.5770610189065337e-03
    z[3,4,5]  R2309     1.1847331374883652e-01
    z[3,4,5]  R2310     -4.4052530080080032e-02
    z[3,4,5]  R2311     2.4003873765468597e-01
    z[3,4,5]  R2312     -1.1766491085290909e-01
    z[3,4,5]  R2313     1.6332441568374634e-01
    z[3,4,5]  R2314     -1.0694076865911484e-01
    z[3,4,5]  R2315     1.6248992085456848e-01
    z[3,4,5]  R2316     -2.2576166689395905e-01
    z[3,4,5]  R2317     -8.2591855525970459e-01
    z[3,4,5]  R2318     3.0087551474571228e-01
    z[3,4,5]  R2319     -1.8919488787651062e-01
    z[3,4,5]  R2320     -1.0286095738410950e-01
    z[3,4,5]  R2321     -9.0068064630031586e-02
    z[3,4,5]  R2322     1.7317394912242889e-01
    z[3,4,5]  R2323     2.8762108087539673e-01
    z[3,4,5]  R2324     3.4940522909164429e-01
    z[3,4,5]  R2325     2.5666022300720215e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2204     -1
    z[3,4,6]  R2205     1
    z[3,4,6]  R2206     -5.1596730947494507e-02
    z[3,4,6]  R2207     -9.6031047403812408e-02
    z[3,4,6]  R2208     2.4515299499034882e-01
    z[3,4,6]  R2209     1.7724240198731422e-02
    z[3,4,6]  R2210     1.0169165581464767e-01
    z[3,4,6]  R2211     -2.2188175469636917e-02
    z[3,4,6]  R2212     9.6747070550918579e-02
    z[3,4,6]  R2213     -1.9185002148151398e-01
    z[3,4,6]  R2214     -1.8084512650966644e-01
    z[3,4,6]  R2215     -2.2686289250850677e-01
    z[3,4,6]  R2216     -6.4817108213901520e-02
    z[3,4,6]  R2217     4.8896557092666626e-01
    z[3,4,6]  R2218     2.9088145494461060e-01
    z[3,4,6]  R2219     5.4765480756759644e-01
    z[3,4,6]  R2220     -0.0765218734741211
    z[3,4,6]  R2221     6.6383326053619385e-01
    z[3,4,6]  R2222     -4.8103660345077515e-01
    z[3,4,6]  R2223     -3.5973396152257919e-02
    z[3,4,6]  R2224     2.7675414457917213e-02
    z[3,4,6]  R2225     1.4806197583675385e-01
    z[3,4,6]  R2226     6.5325385332107544e-01
    z[3,4,6]  R2227     3.9939659833908081e-01
    z[3,4,6]  R2228     -3.3355975151062012e-01
    z[3,4,6]  R2229     4.4159561395645142e-01
    z[3,4,6]  R2230     -2.2576887905597687e-01
    z[3,4,6]  R2231     -5.9509657323360443e-02
    z[3,4,6]  R2232     2.3087641596794128e-01
    z[3,4,6]  R2233     1.8725031614303589e-01
    z[3,4,6]  R2234     -2.8318881988525391e-01
    z[3,4,6]  R2235     1.7644004523754120e-01
    z[3,4,6]  R2236     -1.5983033180236816e-01
    z[3,4,6]  R2237     4.8726612329483032e-01
    z[3,4,6]  R2238     0.0975242406129837
    z[3,4,6]  R2239     -4.5267440378665924e-02
    z[3,4,6]  R2240     -7.1026429533958435e-02
    z[3,4,6]  R2241     -2.5069704651832581e-01
    z[3,4,6]  R2242     -1.2107732892036438e-01
    z[3,4,6]  R2243     -1.1193778365850449e-01
    z[3,4,6]  R2244     2.6010793447494507e-01
    z[3,4,6]  R2245     -2.2518199682235718e-01
    z[3,4,6]  R2246     -1.6620095074176788e-01
    z[3,4,6]  R2247     -6.4135879278182983e-02
    z[3,4,6]  R2248     5.7532179355621338e-01
    z[3,4,6]  R2249     -4.4459655880928040e-01
    z[3,4,6]  R2250     -7.7958631515502930e-01
    z[3,4,6]  R2251     3.5826382040977478e-01
    z[3,4,6]  R2252     1.1560061015188694e-02
    z[3,4,6]  R2253     9.2273719608783722e-02
    z[3,4,6]  R2254     2.0095439627766609e-02
    z[3,4,6]  R2255     5.4892235994338989e-01
    z[3,4,6]  R2256     -2.7730929851531982e-01
    z[3,4,6]  R2257     2.7985206246376038e-01
    z[3,4,6]  R2258     -5.0994741916656494e-01
    z[3,4,6]  R2259     8.8763415813446045e-02
    z[3,4,6]  R2260     0.625530481338501
    z[3,4,6]  R2261     -1.4392854273319244e-01
    z[3,4,6]  R2262     5.0578240305185318e-02
    z[3,4,6]  R2263     -1.0098070651292801e-01
    z[3,4,6]  R2264     5.5152767896652222e-01
    z[3,4,6]  R2265     2.2399918735027313e-01
    z[3,4,6]  R2266     -4.1818860918283463e-02
    z[3,4,6]  R2267     -6.8638898432254791e-02
    z[3,4,6]  R2268     4.9629233777523041e-02
    z[3,4,6]  R2269     4.6015450358390808e-01
    z[3,4,6]  R2270     3.5267940163612366e-01
    z[3,4,6]  R2271     8.5834264755249023e-02
    z[3,4,6]  R2272     3.3901542425155640e-01
    z[3,4,6]  R2273     1.1232954263687134e-01
    z[3,4,6]  R2274     -7.5245961546897888e-02
    z[3,4,6]  R2275     -1.6824442893266678e-02
    z[3,4,6]  R2276     -3.7836784124374390e-01
    z[3,4,6]  R2277     -3.7656403146684170e-03
    z[3,4,6]  R2278     -4.0477716922760010e-01
    z[3,4,6]  R2279     0.0537756085395813
    z[3,4,6]  R2280     1.2422189861536026e-01
    z[3,4,6]  R2281     5.5422705411911011e-01
    z[3,4,6]  R2282     4.6610483527183533e-01
    z[3,4,6]  R2283     -3.2319790124893188e-01
    z[3,4,6]  R2284     -4.0369275212287903e-01
    z[3,4,6]  R2285     -3.1184107065200806e-01
    z[3,4,6]  R2286     5.3866648674011230e-01
    z[3,4,6]  R2287     -2.4914094805717468e-01
    z[3,4,6]  R2288     -2.2761613130569458e-01
    z[3,4,6]  R2289     -1.4536048471927643e-01
    z[3,4,6]  R2290     -5.7595260441303253e-02
    z[3,4,6]  R2291     0.00621609203517437
    z[3,4,6]  R2292     -3.4228414297103882e-01
    z[3,4,6]  R2293     -6.0688531398773193e-01
    z[3,4,6]  R2294     -2.4569284915924072e-01
    z[3,4,6]  R2295     -1.6450603306293488e-01
    z[3,4,6]  R2296     1.3542146980762482e-01
    z[3,4,6]  R2297     -0.00367422285489738
    z[3,4,6]  R2298     -1.0799888521432877e-01
    z[3,4,6]  R2299     -6.1507290601730347e-01
    z[3,4,6]  R2300     1.2677150964736938e-01
    z[3,4,6]  R2301     4.8420354723930359e-01
    z[3,4,6]  R2302     2.0706895738840103e-02
    z[3,4,6]  R2303     3.2840543985366821e-01
    z[3,4,6]  R2304     -2.9542544484138489e-01
    z[3,4,6]  R2305     3.0984729528427124e-01
    z[3,4,6]  R2306     1.5701831877231598e-01
    z[3,4,6]  R2307     -1.4757920987904072e-02
    z[3,4,6]  R2308     -2.2041529417037964e-01
    z[3,4,6]  R2309     -2.5851166248321533e-01
    z[3,4,6]  R2310     -3.4218841791152954e-01
    z[3,4,6]  R2311     -1.1786611378192902e-01
    z[3,4,6]  R2312     1.7341071367263794e-01
    z[3,4,6]  R2313     -7.6179198920726776e-02
    z[3,4,6]  R2314     -5.1968467235565186e-01
    z[3,4,6]  R2315     -3.6494970321655273e-01
    z[3,4,6]  R2316     -1.2957751750946045e-01
    z[3,4,6]  R2317     1.1584952473640442e-01
    z[3,4,6]  R2318     1.1547765135765076e-01
    z[3,4,6]  R2319     -1.2766093015670776e-01
    z[3,4,6]  R2320     1.0075343400239944e-01
    z[3,4,6]  R2321     2.5603345036506653e-01
    z[3,4,6]  R2322     3.4406366944313049e-01
    z[3,4,6]  R2323     -1.7734996974468231e-01
    z[3,4,6]  R2324     -0.0982140377163887
    z[3,4,6]  R2325     -1.2797258794307709e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2326     -1
    z[4,3,0]  R2327     1
    z[4,3,0]  R2340     -0.626301646232605
    z[4,3,0]  R2341     -8.4204000234603882e-01
    z[4,3,0]  R2342     -5.6200635433197021e-01
    z[4,3,0]  R2343     -5.3218764066696167e-01
    z[4,3,0]  R2344     -0.939971387386322
    z[4,3,0]  R2345     6.5989071130752563e-01
    z[4,3,0]  R2346     -9.3661779165267944e-01
    z[4,3,0]  R2347     5.6124496459960938e-01
    z[4,3,0]  R2348     -8.1057894229888916e-01
    z[4,3,0]  R2349     -8.1453180313110352e-01
    z[4,3,0]  R2350     -1.3804477453231812e-01
    z[4,3,0]  R2351     -1.4331266283988953e-01
    z[4,3,0]  R2352     1.3529990613460541e-01
    z[4,3,0]  R2353     1.8741910159587860e-01
    z[4,3,0]  R2354     1.1734388023614883e-01
    z[4,3,0]  R2355     -1.5084441751241684e-02
    z[4,3,0]  R2356     -4.1426301002502441e-01
    z[4,3,0]  R2357     8.9693886041641235e-01
    z[4,3,0]  R2358     7.0947146415710449e-01
    z[4,3,0]  R2359     0.85356205701828
    z[4,3,0]  R2360     6.7912268638610840e-01
    z[4,3,0]  R2361     4.6549555659294128e-01
    z[4,3,0]  R2362     -7.0993238687515259e-01
    z[4,3,0]  R2363     7.1068447828292847e-01
    z[4,3,0]  R2364     4.5530465245246887e-01
    z[4,3,0]  R2365     0.552579402923584
    z[4,3,0]  R2366     5.8852738142013550e-01
    z[4,3,0]  R2367     -3.5320860147476196e-01
    z[4,3,0]  R2368     -0.319614976644516
    z[4,3,0]  R2369     -2.3107655346393585e-01
    z[4,3,0]  R2370     2.5813335180282593e-01
    z[4,3,0]  R2371     -9.3980008363723755e-01
    z[4,3,0]  R2372     -9.2294001579284668e-01
    z[4,3,0]  R2373     5.8017861843109131e-01
    z[4,3,0]  R2374     -8.6002784967422485e-01
    z[4,3,0]  R2375     -0.892230212688446
    z[4,3,0]  R2376     -9.4262242317199707e-01
    z[4,3,0]  R2377     -9.1773474216461182e-01
    z[4,3,0]  R2378     -8.9749175310134888e-01
    z[4,3,0]  R2379     -0.83182692527771
    z[4,3,0]  R2380     5.5075997114181519e-01
    z[4,3,0]  R2381     4.8558406531810760e-02
    z[4,3,0]  R2382     2.1610417962074280e-01
    z[4,3,0]  R2383     5.7938706874847412e-01
    z[4,3,0]  R2384     1.8145748972892761e-01
    z[4,3,0]  R2385     3.6470952630043030e-01
    z[4,3,0]  R2386     3.6930146813392639e-01
    z[4,3,0]  R2387     3.9038211107254028e-01
    z[4,3,0]  R2388     2.6583820581436157e-01
    z[4,3,0]  R2389     2.2130346298217773e-01
    z[4,3,0]  R2390     4.6522235870361328e-01
    z[4,3,0]  R2391     6.5786594152450562e-01
    z[4,3,0]  R2392     4.9325266480445862e-01
    z[4,3,0]  R2393     3.5619714856147766e-01
    z[4,3,0]  R2394     5.5103158950805664e-01
    z[4,3,0]  R2395     2.9873868823051453e-01
    z[4,3,0]  R2396     -3.5717669129371643e-01
    z[4,3,0]  R2397     -2.7027529478073120e-01
    z[4,3,0]  R2398     -0.3973388671875
    z[4,3,0]  R2399     -2.8489735722541809e-01
    z[4,3,0]  R2400     6.8873858451843262e-01
    z[4,3,0]  R2401     0.576435387134552
    z[4,3,0]  R2402     -1.0018469393253326e-01
    z[4,3,0]  R2403     6.7038416862487793e-02
    z[4,3,0]  R2404     3.8674166798591614e-01
    z[4,3,0]  R2405     3.9960426092147827e-01
    z[4,3,0]  R2406     3.9525407552719116e-01
    z[4,3,0]  R2407     3.9926269650459290e-01
    z[4,3,0]  R2408     -3.9417085051536560e-01
    z[4,3,0]  R2409     5.6480592489242554e-01
    z[4,3,0]  R2410     5.3114473819732666e-01
    z[4,3,0]  R2411     -5.3321599960327148e-02
    z[4,3,0]  R2412     3.0768087506294250e-01
    z[4,3,0]  R2413     1.9263944029808044e-01
    z[4,3,0]  R2414     1.9228491187095642e-01
    z[4,3,0]  R2415     -3.8100141286849976e-01
    z[4,3,0]  R2416     5.4885959625244141e-01
    z[4,3,0]  R2417     6.0691988468170166e-01
    z[4,3,0]  R2418     -4.7804492712020874e-01
    z[4,3,0]  R2419     3.6181899905204773e-01
    z[4,3,0]  R2420     5.7915753126144409e-01
    z[4,3,0]  R2421     -1.7139646410942078e-01
    z[4,3,0]  R2422     2.4324850738048553e-01
    z[4,3,0]  R2423     2.1458587050437927e-01
    z[4,3,0]  R2424     3.3688443899154663e-01
    z[4,3,0]  R2425     -1.5396653115749359e-01
    z[4,3,0]  R2426     -3.9778491854667664e-01
    z[4,3,0]  R2427     -5.5805152654647827e-01
    z[4,3,0]  R2428     2.9693955183029175e-01
    z[4,3,0]  R2429     -3.9586779475212097e-01
    z[4,3,0]  R2430     3.9001861214637756e-01
    z[4,3,0]  R2431     -1.1424923688173294e-01
    z[4,3,0]  R2432     1.1477511376142502e-01
    z[4,3,0]  R2433     3.7824258208274841e-01
    z[4,3,0]  R2434     4.2572364211082458e-01
    z[4,3,0]  R2435     -3.0046832561492920e-01
    z[4,3,0]  R2436     -4.1631302237510681e-01
    z[4,3,0]  R2437     -2.2245289757847786e-02
    z[4,3,0]  R2438     -1.5044157207012177e-01
    z[4,3,0]  R2439     -2.3720417916774750e-01
    z[4,3,0]  R2440     -6.7189380526542664e-02
    z[4,3,0]  R2441     3.3011120557785034e-01
    z[4,3,0]  R2442     2.8113198280334473e-01
    z[4,3,0]  R2443     -2.5362789630889893e-01
    z[4,3,0]  R2444     -4.4777533411979675e-01
    z[4,3,0]  R2445     2.2559408843517303e-01
    z[4,3,0]  R2446     1.6263779997825623e-01
    z[4,3,0]  R2447     -3.0208915472030640e-01
    z[4,3,0]  R2448     -2.7314043045043945e-01
    z[4,3,0]  R2449     -3.9606195688247681e-01
    z[4,3,0]  R2450     3.0516144633293152e-01
    z[4,3,0]  R2451     -1.5908235311508179e-01
    z[4,3,0]  R2452     3.5983249545097351e-01
    z[4,3,0]  R2453     4.0131369233131409e-01
    z[4,3,0]  R2454     -3.1321954727172852e-01
    z[4,3,0]  R2455     -2.8356176614761353e-01
    z[4,3,0]  R2456     -3.0964380502700806e-01
    z[4,3,0]  R2457     -3.9614996314048767e-01
    z[4,3,0]  R2458     -1.2843808531761169e-01
    z[4,3,0]  R2459     -2.2057932615280151e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2328     -1
    z[4,3,1]  R2329     1
    z[4,3,1]  R2340     -0.575942873954773
    z[4,3,1]  R2341     -8.1678695976734161e-02
    z[4,3,1]  R2342     -1.9468982517719269e-01
    z[4,3,1]  R2343     -8.7245449423789978e-02
    z[4,3,1]  R2344     -1.4296740293502808e-01
    z[4,3,1]  R2345     1.5793354809284210e-01
    z[4,3,1]  R2346     6.2615498900413513e-02
    z[4,3,1]  R2347     -8.5508622229099274e-02
    z[4,3,1]  R2348     2.1103753149509430e-01
    z[4,3,1]  R2349     0.0857396051287651
    z[4,3,1]  R2350     8.7869238853454590e-01
    z[4,3,1]  R2351     7.4564278125762939e-01
    z[4,3,1]  R2352     0.814132571220398
    z[4,3,1]  R2353     8.3106732368469238e-01
    z[4,3,1]  R2354     0.913650393486023
    z[4,3,1]  R2355     9.2196524143218994e-01
    z[4,3,1]  R2356     6.8651187419891357e-01
    z[4,3,1]  R2357     -3.4975543618202209e-01
    z[4,3,1]  R2358     -2.1639437973499298e-01
    z[4,3,1]  R2359     3.3483337610960007e-02
    z[4,3,1]  R2360     -5.4730284214019775e-01
    z[4,3,1]  R2361     -1.0956397652626038e-01
    z[4,3,1]  R2362     0.00622505834326148
    z[4,3,1]  R2363     5.1804497838020325e-02
    z[4,3,1]  R2364     -2.2204600274562836e-01
    z[4,3,1]  R2365     -2.3661231622099876e-02
    z[4,3,1]  R2366     2.3132576048374176e-01
    z[4,3,1]  R2367     -6.3067066669464111e-01
    z[4,3,1]  R2368     -8.3851498365402222e-01
    z[4,3,1]  R2369     -6.7305499315261841e-01
    z[4,3,1]  R2370     4.5794308185577393e-01
    z[4,3,1]  R2371     1.5471121668815613e-01
    z[4,3,1]  R2372     1.6253520548343658e-01
    z[4,3,1]  R2373     5.4190081357955933e-01
    z[4,3,1]  R2374     1.8640153110027313e-01
    z[4,3,1]  R2375     0.0975256860256195
    z[4,3,1]  R2376     -9.9438624456524849e-03
    z[4,3,1]  R2377     2.0124214887619019e-01
    z[4,3,1]  R2378     2.0787183940410614e-01
    z[4,3,1]  R2379     2.8012225031852722e-01
    z[4,3,1]  R2380     4.9174398183822632e-01
    z[4,3,1]  R2381     5.9860908985137939e-01
    z[4,3,1]  R2382     5.6498810648918152e-02
    z[4,3,1]  R2383     1.5831539034843445e-01
    z[4,3,1]  R2384     2.6287177205085754e-01
    z[4,3,1]  R2385     1.3917708396911621e-01
    z[4,3,1]  R2386     -3.7313610315322876e-02
    z[4,3,1]  R2387     -6.4909934997558594e-01
    z[4,3,1]  R2388     -6.3023924827575684e-01
    z[4,3,1]  R2389     -0.601081371307373
    z[4,3,1]  R2390     4.8583567142486572e-01
    z[4,3,1]  R2391     1.6910223662853241e-01
    z[4,3,1]  R2392     3.8512364029884338e-01
    z[4,3,1]  R2393     -2.4250841140747070e-01
    z[4,3,1]  R2394     2.0148472487926483e-01
    z[4,3,1]  R2395     5.6375807523727417e-01
    z[4,3,1]  R2396     -8.8710987567901611e-01
    z[4,3,1]  R2397     -8.7936633825302124e-01
    z[4,3,1]  R2398     -8.4518057107925415e-01
    z[4,3,1]  R2399     -8.9767938852310181e-01
    z[4,3,1]  R2400     3.1527695059776306e-01
    z[4,3,1]  R2401     1.0131421685218811e-01
    z[4,3,1]  R2402     6.2148368358612061e-01
    z[4,3,1]  R2403     6.3854932785034180e-01
    z[4,3,1]  R2404     -7.8269565105438232e-01
    z[4,3,1]  R2405     -7.5086838006973267e-01
    z[4,3,1]  R2406     -7.9141962528228760e-01
    z[4,3,1]  R2407     -8.3746296167373657e-01
    z[4,3,1]  R2408     -5.1557046175003052e-01
    z[4,3,1]  R2409     -6.1647754907608032e-01
    z[4,3,1]  R2410     3.2905480265617371e-01
    z[4,3,1]  R2411     9.5572900772094727e-01
    z[4,3,1]  R2412     3.0548056960105896e-01
    z[4,3,1]  R2413     1.9497880339622498e-01
    z[4,3,1]  R2414     5.1851749420166016e-01
    z[4,3,1]  R2415     6.3300591707229614e-01
    z[4,3,1]  R2416     -0.712550163269043
    z[4,3,1]  R2417     -7.5988835096359253e-01
    z[4,3,1]  R2418     -7.4890685081481934e-01
    z[4,3,1]  R2419     -6.0639894008636475e-01
    z[4,3,1]  R2420     6.6063940525054932e-01
    z[4,3,1]  R2421     7.8202486038208008e-01
    z[4,3,1]  R2422     1.7261256277561188e-01
    z[4,3,1]  R2423     -2.3551419377326965e-01
    z[4,3,1]  R2424     -2.0627915859222412e-01
    z[4,3,1]  R2425     -9.0729838609695435e-01
    z[4,3,1]  R2426     -8.2229351997375488e-01
    z[4,3,1]  R2427     -7.3243695497512817e-01
    z[4,3,1]  R2428     -5.0932437181472778e-01
    z[4,3,1]  R2429     -5.9857684373855591e-01
    z[4,3,1]  R2430     -1.8179433420300484e-02
    z[4,3,1]  R2431     8.6025208234786987e-01
    z[4,3,1]  R2432     4.1180285811424255e-01
    z[4,3,1]  R2433     -6.7911714315414429e-01
    z[4,3,1]  R2434     -6.1638671159744263e-01
    z[4,3,1]  R2435     -8.4821528196334839e-01
    z[4,3,1]  R2436     -6.9856476783752441e-01
    z[4,3,1]  R2437     -8.9396846294403076e-01
    z[4,3,1]  R2438     -8.1388109922409058e-01
    z[4,3,1]  R2439     -8.0397886037826538e-01
    z[4,3,1]  R2440     1.1819742619991302e-02
    z[4,3,1]  R2441     -7.3750841617584229e-01
    z[4,3,1]  R2442     -5.9825807809829712e-01
    z[4,3,1]  R2443     -0.844097912311554
    z[4,3,1]  R2444     -5.0424879789352417e-01
    z[4,3,1]  R2445     -6.4740163087844849e-01
    z[4,3,1]  R2446     -4.7776961326599121e-01
    z[4,3,1]  R2447     -5.2313446998596191e-01
    z[4,3,1]  R2448     -7.1146863698959351e-01
    z[4,3,1]  R2449     -0.487781286239624
    z[4,3,1]  R2450     1.2014646083116531e-02
    z[4,3,1]  R2451     6.5612250566482544e-01
    z[4,3,1]  R2452     -6.7768466472625732e-01
    z[4,3,1]  R2453     -7.2295677661895752e-01
    z[4,3,1]  R2454     -8.6170834302902222e-01
    z[4,3,1]  R2455     -0.867425799369812
    z[4,3,1]  R2456     -4.6951338648796082e-01
    z[4,3,1]  R2457     -4.7382223606109619e-01
    z[4,3,1]  R2458     -9.8977647721767426e-02
    z[4,3,1]  R2459     -2.1678347885608673e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2330     -1
    z[4,3,2]  R2331     1
    z[4,3,2]  R2340     3.8755902647972107e-01
    z[4,3,2]  R2341     4.8647314310073853e-01
    z[4,3,2]  R2342     6.0824459791183472e-01
    z[4,3,2]  R2343     4.3417137861251831e-01
    z[4,3,2]  R2344     -1.4967535436153412e-01
    z[4,3,2]  R2345     -4.1559547185897827e-01
    z[4,3,2]  R2346     -1.9692401587963104e-01
    z[4,3,2]  R2347     -1.1192564666271210e-01
    z[4,3,2]  R2348     -1.9925747811794281e-01
    z[4,3,2]  R2349     4.4076152145862579e-02
    z[4,3,2]  R2350     -0.348624587059021
    z[4,3,2]  R2351     -5.3115451335906982e-01
    z[4,3,2]  R2352     -3.2606229186058044e-01
    z[4,3,2]  R2353     -2.7933281660079956e-01
    z[4,3,2]  R2354     -0.0719640925526619
    z[4,3,2]  R2355     -0.0854223445057869
    z[4,3,2]  R2356     -3.4509435296058655e-01
    z[4,3,2]  R2357     1.6582074761390686e-01
    z[4,3,2]  R2358     2.6561295986175537e-01
    z[4,3,2]  R2359     3.1241217255592346e-01
    z[4,3,2]  R2360     3.5691785160452127e-03
    z[4,3,2]  R2361     -2.1841278672218323e-01
    z[4,3,2]  R2362     3.8633834570646286e-02
    z[4,3,2]  R2363     1.4892983436584473e-01
    z[4,3,2]  R2364     -1.7980413138866425e-01
    z[4,3,2]  R2365     0.190543994307518
    z[4,3,2]  R2366     1.6353680193424225e-01
    z[4,3,2]  R2367     -0.352943480014801
    z[4,3,2]  R2368     -8.0922663211822510e-02
    z[4,3,2]  R2369     -1.6812250018119812e-02
    z[4,3,2]  R2370     4.7317445278167725e-01
    z[4,3,2]  R2371     -7.1036987006664276e-02
    z[4,3,2]  R2372     3.9349254220724106e-03
    z[4,3,2]  R2373     6.0475575923919678e-01
    z[4,3,2]  R2374     -1.0655601322650909e-01
    z[4,3,2]  R2375     1.0289722681045532e-01
    z[4,3,2]  R2376     -1.4623812399804592e-02
    z[4,3,2]  R2377     -1.1547831445932388e-01
    z[4,3,2]  R2378     2.7077925205230713e-01
    z[4,3,2]  R2379     3.0057525634765625e-01
    z[4,3,2]  R2380     -6.0011076927185059e-01
    z[4,3,2]  R2381     -2.8771796822547913e-01
    z[4,3,2]  R2382     -0.17482890188694
    z[4,3,2]  R2383     5.7021718472242355e-02
    z[4,3,2]  R2384     -2.6236066222190857e-01
    z[4,3,2]  R2385     -2.7732434868812561e-01
    z[4,3,2]  R2386     -5.6132465600967407e-02
    z[4,3,2]  R2387     2.5654694437980652e-01
    z[4,3,2]  R2388     -2.4898232519626617e-01
    z[4,3,2]  R2389     -4.8615369945764542e-02
    z[4,3,2]  R2390     -2.3697596788406372e-01
    z[4,3,2]  R2391     0.478730708360672
    z[4,3,2]  R2392     1.1790613085031509e-01
    z[4,3,2]  R2393     1.5007908223196864e-03
    z[4,3,2]  R2394     -3.0414253473281860e-01
    z[4,3,2]  R2395     -4.6622648835182190e-01
    z[4,3,2]  R2396     1.2217401713132858e-01
    z[4,3,2]  R2397     -7.3766350746154785e-02
    z[4,3,2]  R2398     8.6302056908607483e-02
    z[4,3,2]  R2399     7.0185407996177673e-02
    z[4,3,2]  R2400     -1.1465033888816833e-01
    z[4,3,2]  R2401     -1.8005770444869995e-01
    z[4,3,2]  R2402     2.2961066663265228e-01
    z[4,3,2]  R2403     -5.6701207160949707e-01
    z[4,3,2]  R2404     -7.0753586478531361e-03
    z[4,3,2]  R2405     -4.2569848895072937e-01
    z[4,3,2]  R2406     3.8507454097270966e-02
    z[4,3,2]  R2407     -2.1936345100402832e-01
    z[4,3,2]  R2408     -4.4113822281360626e-02
    z[4,3,2]  R2409     -2.9070353507995605e-01
    z[4,3,2]  R2410     3.1474274396896362e-01
    z[4,3,2]  R2411     -1.3277991116046906e-01
    z[4,3,2]  R2412     -2.0039129257202148e-01
    z[4,3,2]  R2413     3.3667656779289246e-01
    z[4,3,2]  R2414     9.5063023269176483e-02
    z[4,3,2]  R2415     1.8678675591945648e-01
    z[4,3,2]  R2416     -1.5000531077384949e-01
    z[4,3,2]  R2417     1.4589686691761017e-01
    z[4,3,2]  R2418     -1.3811717927455902e-01
    z[4,3,2]  R2419     -3.2649955153465271e-01
    z[4,3,2]  R2420     -7.7538035809993744e-02
    z[4,3,2]  R2421     2.7904254198074341e-01
    z[4,3,2]  R2422     4.6756044030189514e-01
    z[4,3,2]  R2423     5.8996933698654175e-01
    z[4,3,2]  R2424     3.0695015192031860e-01
    z[4,3,2]  R2425     -8.3865828812122345e-02
    z[4,3,2]  R2426     -0.201654851436615
    z[4,3,2]  R2427     2.3760262876749039e-02
    z[4,3,2]  R2428     1.9889634847640991e-01
    z[4,3,2]  R2429     -4.1506299376487732e-01
    z[4,3,2]  R2430     1.5373519062995911e-01
    z[4,3,2]  R2431     6.0239702463150024e-02
    z[4,3,2]  R2432     -2.5170063972473145e-01
    z[4,3,2]  R2433     -3.9540448784828186e-01
    z[4,3,2]  R2434     1.8756791949272156e-01
    z[4,3,2]  R2435     -1.8159843981266022e-01
    z[4,3,2]  R2436     -1.4692538976669312e-01
    z[4,3,2]  R2437     2.8810954093933105e-01
    z[4,3,2]  R2438     0.518994152545929
    z[4,3,2]  R2439     -7.1790322661399841e-02
    z[4,3,2]  R2440     2.0671610534191132e-01
    z[4,3,2]  R2441     -2.9173594713211060e-01
    z[4,3,2]  R2442     -2.5543960928916931e-01
    z[4,3,2]  R2443     -2.7297517657279968e-01
    z[4,3,2]  R2444     -4.6042707562446594e-01
    z[4,3,2]  R2445     1.2205547094345093e-01
    z[4,3,2]  R2446     -1.7233356833457947e-01
    z[4,3,2]  R2447     -0.463856041431427
    z[4,3,2]  R2448     -0.343553364276886
    z[4,3,2]  R2449     -5.5767357349395752e-01
    z[4,3,2]  R2450     2.7804297208786011e-01
    z[4,3,2]  R2451     -6.2095586210489273e-02
    z[4,3,2]  R2452     -2.0334620773792267e-01
    z[4,3,2]  R2453     -4.3719375133514404e-01
    z[4,3,2]  R2454     -3.4538358449935913e-01
    z[4,3,2]  R2455     2.2523038089275360e-01
    z[4,3,2]  R2456     -1.1186144500970840e-01
    z[4,3,2]  R2457     -2.3457500338554382e-01
    z[4,3,2]  R2458     -3.6460712552070618e-01
    z[4,3,2]  R2459     -7.4643462896347046e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2332     -1
    z[4,3,3]  R2333     1
    z[4,3,3]  R2340     -1.1291564255952835e-01
    z[4,3,3]  R2341     -4.3126974254846573e-02
    z[4,3,3]  R2342     -8.4073126316070557e-02
    z[4,3,3]  R2343     -1.1861911416053772e-01
    z[4,3,3]  R2344     -2.1147488057613373e-01
    z[4,3,3]  R2345     1.1938295327126980e-02
    z[4,3,3]  R2346     -3.3003918826580048e-02
    z[4,3,3]  R2347     -7.1461528539657593e-02
    z[4,3,3]  R2348     -3.5813751816749573e-01
    z[4,3,3]  R2349     3.7784200906753540e-01
    z[4,3,3]  R2350     2.3530612885951996e-01
    z[4,3,3]  R2351     -1.9758237898349762e-01
    z[4,3,3]  R2352     3.5624884068965912e-02
    z[4,3,3]  R2353     -0.330709308385849
    z[4,3,3]  R2354     1.2008894234895706e-01
    z[4,3,3]  R2355     -4.6502269804477692e-02
    z[4,3,3]  R2356     -2.7664867043495178e-01
    z[4,3,3]  R2357     -7.3545746505260468e-02
    z[4,3,3]  R2358     -1.3987350463867188e-01
    z[4,3,3]  R2359     7.3284611105918884e-02
    z[4,3,3]  R2360     -1.9933162629604340e-01
    z[4,3,3]  R2361     -1.5276260673999786e-01
    z[4,3,3]  R2362     5.7509493827819824e-01
    z[4,3,3]  R2363     -4.4765692949295044e-01
    z[4,3,3]  R2364     -7.7382522821426392e-01
    z[4,3,3]  R2365     7.6344740390777588e-01
    z[4,3,3]  R2366     5.8561843633651733e-01
    z[4,3,3]  R2367     4.7341939806938171e-01
    z[4,3,3]  R2368     2.2318008542060852e-01
    z[4,3,3]  R2369     3.6834666132926941e-01
    z[4,3,3]  R2370     -3.7363407015800476e-01
    z[4,3,3]  R2371     -2.3972152173519135e-01
    z[4,3,3]  R2372     -1.9779071211814880e-01
    z[4,3,3]  R2373     -7.7056130394339561e-03
    z[4,3,3]  R2374     -2.0588600635528564e-01
    z[4,3,3]  R2375     3.0438458546996117e-02
    z[4,3,3]  R2376     -8.3044849336147308e-02
    z[4,3,3]  R2377     2.4156817793846130e-01
    z[4,3,3]  R2378     9.3204446136951447e-02
    z[4,3,3]  R2379     -1.8220625817775726e-01
    z[4,3,3]  R2380     -2.1709744632244110e-01
    z[4,3,3]  R2381     4.2003658413887024e-01
    z[4,3,3]  R2382     -6.1917316913604736e-01
    z[4,3,3]  R2383     -2.4185305833816528e-01
    z[4,3,3]  R2384     -4.7418147325515747e-01
    z[4,3,3]  R2385     -3.5897254943847656e-01
    z[4,3,3]  R2386     -6.7649924755096436e-01
    z[4,3,3]  R2387     5.8192396163940430e-01
    z[4,3,3]  R2388     5.5674391984939575e-01
    z[4,3,3]  R2389     6.7789024114608765e-01
    z[4,3,3]  R2390     -1.2351523339748383e-01
    z[4,3,3]  R2391     -3.7697765231132507e-01
    z[4,3,3]  R2392     -3.9568236470222473e-01
    z[4,3,3]  R2393     -4.5480468869209290e-01
    z[4,3,3]  R2394     -1.4198586344718933e-01
    z[4,3,3]  R2395     -3.2391302287578583e-02
    z[4,3,3]  R2396     -7.1297824382781982e-02
    z[4,3,3]  R2397     -1.7052255570888519e-01
    z[4,3,3]  R2398     -1.3055598735809326e-01
    z[4,3,3]  R2399     1.0369133204221725e-01
    z[4,3,3]  R2400     -5.6572878360748291e-01
    z[4,3,3]  R2401     -6.1591309309005737e-01
    z[4,3,3]  R2402     6.7653483152389526e-01
    z[4,3,3]  R2403     -1.1923617124557495e-01
    z[4,3,3]  R2404     3.2390314340591431e-01
    z[4,3,3]  R2405     3.9310574531555176e-02
    z[4,3,3]  R2406     1.3593333959579468e-01
    z[4,3,3]  R2407     -1.6196319460868835e-01
    z[4,3,3]  R2408     5.8970528841018677e-01
    z[4,3,3]  R2409     3.8669671863317490e-02
    z[4,3,3]  R2410     -1.9893029239028692e-03
    z[4,3,3]  R2411     1.4506794512271881e-01
    z[4,3,3]  R2412     -2.7058762311935425e-01
    z[4,3,3]  R2413     -5.8655035495758057e-01
    z[4,3,3]  R2414     -4.3224066495895386e-02
    z[4,3,3]  R2415     3.6754816770553589e-01
    z[4,3,3]  R2416     3.5326120257377625e-01
    z[4,3,3]  R2417     2.2708898410201073e-02
    z[4,3,3]  R2418     2.7809518575668335e-01
    z[4,3,3]  R2419     2.4823831021785736e-01
    z[4,3,3]  R2420     -2.7817955613136292e-01
    z[4,3,3]  R2421     -3.7966978549957275e-01
    z[4,3,3]  R2422     -5.1656246185302734e-01
    z[4,3,3]  R2423     -7.2383642196655273e-01
    z[4,3,3]  R2424     -4.3253010511398315e-01
    z[4,3,3]  R2425     -3.0411076545715332e-01
    z[4,3,3]  R2426     -5.1381520926952362e-02
    z[4,3,3]  R2427     2.3650184273719788e-01
    z[4,3,3]  R2428     5.2529340982437134e-01
    z[4,3,3]  R2429     2.6098170876502991e-01
    z[4,3,3]  R2430     -7.0872771739959717e-01
    z[4,3,3]  R2431     2.3492148146033287e-02
    z[4,3,3]  R2432     -5.7568907737731934e-01
    z[4,3,3]  R2433     2.0097626373171806e-02
    z[4,3,3]  R2434     3.1200775504112244e-01
    z[4,3,3]  R2435     -3.1716406345367432e-01
    z[4,3,3]  R2436     0.325791597366333
    z[4,3,3]  R2437     -1.7388641834259033e-01
    z[4,3,3]  R2438     -3.3776730298995972e-02
    z[4,3,3]  R2439     -9.5977261662483215e-02
    z[4,3,3]  R2440     -7.8665858507156372e-01
    z[4,3,3]  R2441     3.5539820790290833e-01
    z[4,3,3]  R2442     5.0124150514602661e-01
    z[4,3,3]  R2443     -1.1464725248515606e-02
    z[4,3,3]  R2444     4.6107214689254761e-01
    z[4,3,3]  R2445     4.3256533145904541e-01
    z[4,3,3]  R2446     6.0782027244567871e-01
    z[4,3,3]  R2447     1.7142720520496368e-01
    z[4,3,3]  R2448     3.2900744676589966e-01
    z[4,3,3]  R2449     -7.7450558543205261e-02
    z[4,3,3]  R2450     -6.4688611030578613e-01
    z[4,3,3]  R2451     3.6693942546844482e-01
    z[4,3,3]  R2452     0.519483745098114
    z[4,3,3]  R2453     5.1869828253984451e-02
    z[4,3,3]  R2454     1.3376979529857635e-01
    z[4,3,3]  R2455     1.4833371341228485e-01
    z[4,3,3]  R2456     4.6653857827186584e-01
    z[4,3,3]  R2457     1.1839896440505981e-01
    z[4,3,3]  R2458     6.3796001672744751e-01
    z[4,3,3]  R2459     2.9312953352928162e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2334     -1
    z[4,3,4]  R2335     1
    z[4,3,4]  R2340     -1.3108095526695251e-01
    z[4,3,4]  R2341     1.7517803609371185e-01
    z[4,3,4]  R2342     -5.0521481037139893e-01
    z[4,3,4]  R2343     -3.7098596803843975e-03
    z[4,3,4]  R2344     -7.8253731131553650e-02
    z[4,3,4]  R2345     1.8952155485749245e-02
    z[4,3,4]  R2346     1.0351741313934326e-01
    z[4,3,4]  R2347     -3.0360710620880127e-01
    z[4,3,4]  R2348     -2.0744135975837708e-01
    z[4,3,4]  R2349     -2.9577660560607910e-01
    z[4,3,4]  R2350     6.2534660100936890e-02
    z[4,3,4]  R2351     2.8456097841262817e-01
    z[4,3,4]  R2352     4.0337464213371277e-01
    z[4,3,4]  R2353     7.7082134783267975e-02
    z[4,3,4]  R2354     1.1331208795309067e-01
    z[4,3,4]  R2355     -2.6226335763931274e-01
    z[4,3,4]  R2356     -3.4285095334053040e-01
    z[4,3,4]  R2357     8.8250853121280670e-02
    z[4,3,4]  R2358     2.7964314818382263e-01
    z[4,3,4]  R2359     8.8019356131553650e-02
    z[4,3,4]  R2360     3.6297035217285156e-01
    z[4,3,4]  R2361     6.8603962659835815e-02
    z[4,3,4]  R2362     2.4468223750591278e-01
    z[4,3,4]  R2363     -4.6644932031631470e-01
    z[4,3,4]  R2364     -3.0253347754478455e-01
    z[4,3,4]  R2365     3.5661216825246811e-02
    z[4,3,4]  R2366     -2.8646424412727356e-01
    z[4,3,4]  R2367     -1.2093091756105423e-01
    z[4,3,4]  R2368     8.1553466618061066e-02
    z[4,3,4]  R2369     -5.2477353811264038e-01
    z[4,3,4]  R2370     3.4899908304214478e-01
    z[4,3,4]  R2371     1.3045790791511536e-01
    z[4,3,4]  R2372     6.4899399876594543e-02
    z[4,3,4]  R2373     5.2281104028224945e-02
    z[4,3,4]  R2374     -2.7794393897056580e-01
    z[4,3,4]  R2375     -4.3862383812665939e-02
    z[4,3,4]  R2376     -3.0529299378395081e-01
    z[4,3,4]  R2377     -0.0504038967192173
    z[4,3,4]  R2378     1.9112777709960938e-01
    z[4,3,4]  R2379     -4.1402861475944519e-02
    z[4,3,4]  R2380     -3.5263508558273315e-02
    z[4,3,4]  R2381     2.8810936212539673e-01
    z[4,3,4]  R2382     -6.4258921146392822e-01
    z[4,3,4]  R2383     -5.0122499465942383e-01
    z[4,3,4]  R2384     -7.5447636842727661e-01
    z[4,3,4]  R2385     -4.3736043572425842e-01
    z[4,3,4]  R2386     -2.8554555773735046e-01
    z[4,3,4]  R2387     -1.3387228548526764e-01
    z[4,3,4]  R2388     3.9674103260040283e-01
    z[4,3,4]  R2389     -1.8834735453128815e-01
    z[4,3,4]  R2390     1.6314629465341568e-02
    z[4,3,4]  R2391     3.4935045987367630e-02
    z[4,3,4]  R2392     -5.6127011775970459e-01
    z[4,3,4]  R2393     6.2418907880783081e-01
    z[4,3,4]  R2394     0.508728563785553
    z[4,3,4]  R2395     5.9628438949584961e-01
    z[4,3,4]  R2396     -9.6647582948207855e-02
    z[4,3,4]  R2397     -2.8975948691368103e-01
    z[4,3,4]  R2398     -1.2747314572334290e-01
    z[4,3,4]  R2399     2.3188865184783936e-01
    z[4,3,4]  R2400     -6.5716892480850220e-02
    z[4,3,4]  R2401     8.0855533480644226e-02
    z[4,3,4]  R2402     -3.2234955579042435e-02
    z[4,3,4]  R2403     -2.5378465652465820e-01
    z[4,3,4]  R2404     2.8136804699897766e-01
    z[4,3,4]  R2405     -1.0198257118463516e-01
    z[4,3,4]  R2406     -1.1463674902915955e-01
    z[4,3,4]  R2407     1.7112898826599121e-01
    z[4,3,4]  R2408     -2.5380682945251465e-01
    z[4,3,4]  R2409     9.4268575310707092e-02
    z[4,3,4]  R2410     6.5625023841857910e-01
    z[4,3,4]  R2411     -1.6640214622020721e-01
    z[4,3,4]  R2412     5.1289498805999756e-01
    z[4,3,4]  R2413     -4.8925641179084778e-01
    z[4,3,4]  R2414     2.7319782972335815e-01
    z[4,3,4]  R2415     2.0046363770961761e-01
    z[4,3,4]  R2416     -1.7939563095569611e-01
    z[4,3,4]  R2417     7.3708340525627136e-02
    z[4,3,4]  R2418     -2.0611342787742615e-01
    z[4,3,4]  R2419     1.1279787868261337e-01
    z[4,3,4]  R2420     2.5928923487663269e-01
    z[4,3,4]  R2421     1.6672702133655548e-01
    z[4,3,4]  R2422     -4.0130406618118286e-01
    z[4,3,4]  R2423     -5.1522977650165558e-02
    z[4,3,4]  R2424     4.1288143396377563e-01
    z[4,3,4]  R2425     -8.2583807408809662e-02
    z[4,3,4]  R2426     8.4618858993053436e-02
    z[4,3,4]  R2427     1.7774626612663269e-01
    z[4,3,4]  R2428     2.6971861720085144e-02
    z[4,3,4]  R2429     3.5232746601104736e-01
    z[4,3,4]  R2430     5.6551039218902588e-01
    z[4,3,4]  R2431     1.7291894555091858e-01
    z[4,3,4]  R2432     -3.7263345718383789e-01
    z[4,3,4]  R2433     -1.6487531363964081e-01
    z[4,3,4]  R2434     -3.3342546224594116e-01
    z[4,3,4]  R2435     2.2124059498310089e-01
    z[4,3,4]  R2436     1.4005471765995026e-01
    z[4,3,4]  R2437     2.7248656749725342e-01
    z[4,3,4]  R2438     -3.3528175204992294e-02
    z[4,3,4]  R2439     1.4610594511032104e-01
    z[4,3,4]  R2440     -1.8471702933311462e-02
    z[4,3,4]  R2441     -7.2325021028518677e-02
    z[4,3,4]  R2442     -2.2511104121804237e-02
    z[4,3,4]  R2443     1.9403712451457977e-01
    z[4,3,4]  R2444     1.2670768797397614e-01
    z[4,3,4]  R2445     -0.0792994499206543
    z[4,3,4]  R2446     -2.1422253549098969e-01
    z[4,3,4]  R2447     2.0323148369789124e-01
    z[4,3,4]  R2448     1.4503178000450134e-01
    z[4,3,4]  R2449     -3.4546792507171631e-01
    z[4,3,4]  R2450     -1.3877657055854797e-01
    z[4,3,4]  R2451     4.0217930078506470e-01
    z[4,3,4]  R2452     -3.1700424849987030e-02
    z[4,3,4]  R2453     2.9526901245117188e-01
    z[4,3,4]  R2454     -5.3333666175603867e-02
    z[4,3,4]  R2455     1.0146160423755646e-01
    z[4,3,4]  R2456     -1.7991612851619720e-01
    z[4,3,4]  R2457     -1.6010677814483643e-01
    z[4,3,4]  R2458     -3.0307593941688538e-01
    z[4,3,4]  R2459     -2.7151322364807129e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2336     -1
    z[4,3,5]  R2337     1
    z[4,3,5]  R2340     -2.7850124239921570e-01
    z[4,3,5]  R2341     1.2280213832855225e-01
    z[4,3,5]  R2342     4.8055514693260193e-02
    z[4,3,5]  R2343     -3.5813519358634949e-01
    z[4,3,5]  R2344     8.1823609769344330e-02
    z[4,3,5]  R2345     -3.6321735382080078e-01
    z[4,3,5]  R2346     -2.6041004061698914e-01
    z[4,3,5]  R2347     -6.7825573682785034e-01
    z[4,3,5]  R2348     -1.2281390838325024e-02
    z[4,3,5]  R2349     3.1469874083995819e-02
    z[4,3,5]  R2350     5.8050606399774551e-02
    z[4,3,5]  R2351     -1.4533384144306183e-01
    z[4,3,5]  R2352     1.5770610189065337e-03
    z[4,3,5]  R2353     1.1847331374883652e-01
    z[4,3,5]  R2354     -4.4052530080080032e-02
    z[4,3,5]  R2355     2.4003873765468597e-01
    z[4,3,5]  R2356     -1.1766491085290909e-01
    z[4,3,5]  R2357     1.6332441568374634e-01
    z[4,3,5]  R2358     -1.0694076865911484e-01
    z[4,3,5]  R2359     1.6248992085456848e-01
    z[4,3,5]  R2360     -2.2576166689395905e-01
    z[4,3,5]  R2361     -8.2591855525970459e-01
    z[4,3,5]  R2362     3.0087551474571228e-01
    z[4,3,5]  R2363     -1.8919488787651062e-01
    z[4,3,5]  R2364     -1.0286095738410950e-01
    z[4,3,5]  R2365     -9.0068064630031586e-02
    z[4,3,5]  R2366     1.7317394912242889e-01
    z[4,3,5]  R2367     2.8762108087539673e-01
    z[4,3,5]  R2368     3.4940522909164429e-01
    z[4,3,5]  R2369     2.5666022300720215e-01
    z[4,3,5]  R2370     -4.8548573255538940e-01
    z[4,3,5]  R2371     6.3925251364707947e-02
    z[4,3,5]  R2372     -1.3533490896224976e-01
    z[4,3,5]  R2373     -2.9999520629644394e-02
    z[4,3,5]  R2374     -2.9029190540313721e-01
    z[4,3,5]  R2375     -4.2483350634574890e-01
    z[4,3,5]  R2376     -4.1109815239906311e-02
    z[4,3,5]  R2377     -0.0789119228720665
    z[4,3,5]  R2378     0.00739058293402195
    z[4,3,5]  R2379     -2.2993431985378265e-01
    z[4,3,5]  R2380     2.0528608560562134e-01
    z[4,3,5]  R2381     -2.4083724617958069e-01
    z[4,3,5]  R2382     -1.9655372202396393e-01
    z[4,3,5]  R2383     1.6232709586620331e-01
    z[4,3,5]  R2384     -1.7088063061237335e-01
    z[4,3,5]  R2385     -0.0994378998875618
    z[4,3,5]  R2386     2.9747176170349121e-01
    z[4,3,5]  R2387     -5.1031500101089478e-02
    z[4,3,5]  R2388     -4.4756412506103516e-02
    z[4,3,5]  R2389     2.6538664102554321e-01
    z[4,3,5]  R2390     -2.2161072492599487e-01
    z[4,3,5]  R2391     8.1138901412487030e-02
    z[4,3,5]  R2392     1.0783676803112030e-01
    z[4,3,5]  R2393     1.5114578604698181e-01
    z[4,3,5]  R2394     4.8304149508476257e-01
    z[4,3,5]  R2395     -1.2417440861463547e-01
    z[4,3,5]  R2396     -5.2974302321672440e-02
    z[4,3,5]  R2397     1.1111255735158920e-02
    z[4,3,5]  R2398     -8.2784526050090790e-02
    z[4,3,5]  R2399     1.1146222800016403e-01
    z[4,3,5]  R2400     0.251359224319458
    z[4,3,5]  R2401     4.1499685496091843e-02
    z[4,3,5]  R2402     -2.8766372799873352e-01
    z[4,3,5]  R2403     -4.3079584836959839e-01
    z[4,3,5]  R2404     2.2054976224899292e-01
    z[4,3,5]  R2405     -1.4317522943019867e-01
    z[4,3,5]  R2406     4.1190677881240845e-01
    z[4,3,5]  R2407     1.5191332995891571e-01
    z[4,3,5]  R2408     3.1151914596557617e-01
    z[4,3,5]  R2409     3.9414763450622559e-01
    z[4,3,5]  R2410     2.2859179973602295e-01
    z[4,3,5]  R2411     -1.1515405774116516e-01
    z[4,3,5]  R2412     -3.2339328527450562e-01
    z[4,3,5]  R2413     -1.7447908222675323e-01
    z[4,3,5]  R2414     -2.9478749260306358e-02
    z[4,3,5]  R2415     0.340032160282135
    z[4,3,5]  R2416     1.0683614015579224e-01
    z[4,3,5]  R2417     -1.3590057194232941e-01
    z[4,3,5]  R2418     -2.6704284548759460e-01
    z[4,3,5]  R2419     1.3821706175804138e-01
    z[4,3,5]  R2420     -2.4591540917754173e-02
    z[4,3,5]  R2421     1.7587290704250336e-01
    z[4,3,5]  R2422     -6.7038662731647491e-02
    z[4,3,5]  R2423     -1.2629090249538422e-01
    z[4,3,5]  R2424     -2.9961558058857918e-02
    z[4,3,5]  R2425     1.6140486299991608e-01
    z[4,3,5]  R2426     3.3552536368370056e-01
    z[4,3,5]  R2427     2.3200479149818420e-01
    z[4,3,5]  R2428     1.7891988158226013e-01
    z[4,3,5]  R2429     2.6513275504112244e-01
    z[4,3,5]  R2430     -8.6372224614024162e-03
    z[4,3,5]  R2431     -4.5620220899581909e-01
    z[4,3,5]  R2432     -5.3024077415466309e-01
    z[4,3,5]  R2433     7.6076802797615528e-03
    z[4,3,5]  R2434     -2.6597169041633606e-01
    z[4,3,5]  R2435     -1.9071632996201515e-02
    z[4,3,5]  R2436     2.7643588185310364e-01
    z[4,3,5]  R2437     1.4667242765426636e-02
    z[4,3,5]  R2438     1.9412128627300262e-01
    z[4,3,5]  R2439     -0.51123046875
    z[4,3,5]  R2440     -4.3620994687080383e-01
    z[4,3,5]  R2441     3.6117190122604370e-01
    z[4,3,5]  R2442     -2.8672000765800476e-01
    z[4,3,5]  R2443     -3.2860684394836426e-01
    z[4,3,5]  R2444     2.9860296845436096e-01
    z[4,3,5]  R2445     1.2046633660793304e-01
    z[4,3,5]  R2446     -2.8808993101119995e-01
    z[4,3,5]  R2447     4.9473512172698975e-01
    z[4,3,5]  R2448     -9.4497554004192352e-02
    z[4,3,5]  R2449     2.6760599017143250e-01
    z[4,3,5]  R2450     -3.1865677237510681e-01
    z[4,3,5]  R2451     4.2646953463554382e-01
    z[4,3,5]  R2452     2.1734078228473663e-01
    z[4,3,5]  R2453     -1.1890596896409988e-01
    z[4,3,5]  R2454     1.2651601433753967e-01
    z[4,3,5]  R2455     -2.9000097513198853e-01
    z[4,3,5]  R2456     5.5134242773056030e-01
    z[4,3,5]  R2457     3.9442360401153564e-01
    z[4,3,5]  R2458     5.3061836957931519e-01
    z[4,3,5]  R2459     4.0059766173362732e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2338     -1
    z[4,3,6]  R2339     1
    z[4,3,6]  R2340     1.3542146980762482e-01
    z[4,3,6]  R2341     -0.00367422285489738
    z[4,3,6]  R2342     -1.0799888521432877e-01
    z[4,3,6]  R2343     -6.1507290601730347e-01
    z[4,3,6]  R2344     1.2677150964736938e-01
    z[4,3,6]  R2345     4.8420354723930359e-01
    z[4,3,6]  R2346     2.0706895738840103e-02
    z[4,3,6]  R2347     3.2840543985366821e-01
    z[4,3,6]  R2348     -2.9542544484138489e-01
    z[4,3,6]  R2349     3.0984729528427124e-01
    z[4,3,6]  R2350     1.5701831877231598e-01
    z[4,3,6]  R2351     -1.4757920987904072e-02
    z[4,3,6]  R2352     -2.2041529417037964e-01
    z[4,3,6]  R2353     -2.5851166248321533e-01
    z[4,3,6]  R2354     -3.4218841791152954e-01
    z[4,3,6]  R2355     -1.1786611378192902e-01
    z[4,3,6]  R2356     1.7341071367263794e-01
    z[4,3,6]  R2357     -7.6179198920726776e-02
    z[4,3,6]  R2358     -5.1968467235565186e-01
    z[4,3,6]  R2359     -3.6494970321655273e-01
    z[4,3,6]  R2360     -1.2957751750946045e-01
    z[4,3,6]  R2361     1.1584952473640442e-01
    z[4,3,6]  R2362     1.1547765135765076e-01
    z[4,3,6]  R2363     -1.2766093015670776e-01
    z[4,3,6]  R2364     1.0075343400239944e-01
    z[4,3,6]  R2365     2.5603345036506653e-01
    z[4,3,6]  R2366     3.4406366944313049e-01
    z[4,3,6]  R2367     -1.7734996974468231e-01
    z[4,3,6]  R2368     -0.0982140377163887
    z[4,3,6]  R2369     -1.2797258794307709e-01
    z[4,3,6]  R2370     -5.1596730947494507e-02
    z[4,3,6]  R2371     -9.6031047403812408e-02
    z[4,3,6]  R2372     2.4515299499034882e-01
    z[4,3,6]  R2373     1.7724240198731422e-02
    z[4,3,6]  R2374     1.0169165581464767e-01
    z[4,3,6]  R2375     -2.2188175469636917e-02
    z[4,3,6]  R2376     9.6747070550918579e-02
    z[4,3,6]  R2377     -1.9185002148151398e-01
    z[4,3,6]  R2378     -1.8084512650966644e-01
    z[4,3,6]  R2379     -2.2686289250850677e-01
    z[4,3,6]  R2380     -6.4817108213901520e-02
    z[4,3,6]  R2381     4.8896557092666626e-01
    z[4,3,6]  R2382     2.9088145494461060e-01
    z[4,3,6]  R2383     5.4765480756759644e-01
    z[4,3,6]  R2384     -0.0765218734741211
    z[4,3,6]  R2385     6.6383326053619385e-01
    z[4,3,6]  R2386     -4.8103660345077515e-01
    z[4,3,6]  R2387     -3.5973396152257919e-02
    z[4,3,6]  R2388     2.7675414457917213e-02
    z[4,3,6]  R2389     1.4806197583675385e-01
    z[4,3,6]  R2390     6.5325385332107544e-01
    z[4,3,6]  R2391     3.9939659833908081e-01
    z[4,3,6]  R2392     -3.3355975151062012e-01
    z[4,3,6]  R2393     4.4159561395645142e-01
    z[4,3,6]  R2394     -2.2576887905597687e-01
    z[4,3,6]  R2395     -5.9509657323360443e-02
    z[4,3,6]  R2396     2.3087641596794128e-01
    z[4,3,6]  R2397     1.8725031614303589e-01
    z[4,3,6]  R2398     -2.8318881988525391e-01
    z[4,3,6]  R2399     1.7644004523754120e-01
    z[4,3,6]  R2400     -1.5983033180236816e-01
    z[4,3,6]  R2401     4.8726612329483032e-01
    z[4,3,6]  R2402     0.0975242406129837
    z[4,3,6]  R2403     -4.5267440378665924e-02
    z[4,3,6]  R2404     -7.1026429533958435e-02
    z[4,3,6]  R2405     -2.5069704651832581e-01
    z[4,3,6]  R2406     -1.2107732892036438e-01
    z[4,3,6]  R2407     -1.1193778365850449e-01
    z[4,3,6]  R2408     2.6010793447494507e-01
    z[4,3,6]  R2409     -2.2518199682235718e-01
    z[4,3,6]  R2410     -1.6620095074176788e-01
    z[4,3,6]  R2411     -6.4135879278182983e-02
    z[4,3,6]  R2412     5.7532179355621338e-01
    z[4,3,6]  R2413     -4.4459655880928040e-01
    z[4,3,6]  R2414     -7.7958631515502930e-01
    z[4,3,6]  R2415     3.5826382040977478e-01
    z[4,3,6]  R2416     1.1560061015188694e-02
    z[4,3,6]  R2417     9.2273719608783722e-02
    z[4,3,6]  R2418     2.0095439627766609e-02
    z[4,3,6]  R2419     5.4892235994338989e-01
    z[4,3,6]  R2420     -2.7730929851531982e-01
    z[4,3,6]  R2421     2.7985206246376038e-01
    z[4,3,6]  R2422     -5.0994741916656494e-01
    z[4,3,6]  R2423     8.8763415813446045e-02
    z[4,3,6]  R2424     0.625530481338501
    z[4,3,6]  R2425     -1.4392854273319244e-01
    z[4,3,6]  R2426     5.0578240305185318e-02
    z[4,3,6]  R2427     -1.0098070651292801e-01
    z[4,3,6]  R2428     5.5152767896652222e-01
    z[4,3,6]  R2429     2.2399918735027313e-01
    z[4,3,6]  R2430     -4.1818860918283463e-02
    z[4,3,6]  R2431     -6.8638898432254791e-02
    z[4,3,6]  R2432     4.9629233777523041e-02
    z[4,3,6]  R2433     4.6015450358390808e-01
    z[4,3,6]  R2434     3.5267940163612366e-01
    z[4,3,6]  R2435     8.5834264755249023e-02
    z[4,3,6]  R2436     3.3901542425155640e-01
    z[4,3,6]  R2437     1.1232954263687134e-01
    z[4,3,6]  R2438     -7.5245961546897888e-02
    z[4,3,6]  R2439     -1.6824442893266678e-02
    z[4,3,6]  R2440     -3.7836784124374390e-01
    z[4,3,6]  R2441     -3.7656403146684170e-03
    z[4,3,6]  R2442     -4.0477716922760010e-01
    z[4,3,6]  R2443     0.0537756085395813
    z[4,3,6]  R2444     1.2422189861536026e-01
    z[4,3,6]  R2445     5.5422705411911011e-01
    z[4,3,6]  R2446     4.6610483527183533e-01
    z[4,3,6]  R2447     -3.2319790124893188e-01
    z[4,3,6]  R2448     -4.0369275212287903e-01
    z[4,3,6]  R2449     -3.1184107065200806e-01
    z[4,3,6]  R2450     5.3866648674011230e-01
    z[4,3,6]  R2451     -2.4914094805717468e-01
    z[4,3,6]  R2452     -2.2761613130569458e-01
    z[4,3,6]  R2453     -1.4536048471927643e-01
    z[4,3,6]  R2454     -5.7595260441303253e-02
    z[4,3,6]  R2455     0.00621609203517437
    z[4,3,6]  R2456     -3.4228414297103882e-01
    z[4,3,6]  R2457     -6.0688531398773193e-01
    z[4,3,6]  R2458     -2.4569284915924072e-01
    z[4,3,6]  R2459     -1.6450603306293488e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R45       1
    RHS1      R46       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,2]
 BV BND1      phi[2,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[5,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,6]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[5,3]
 BV BND1      phi[4,6]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,2,0]
 FR BND1      z[0,2,1]
 FR BND1      z[0,2,2]
 FR BND1      z[0,2,3]
 FR BND1      z[0,2,4]
 FR BND1      z[0,2,5]
 FR BND1      z[0,2,6]
 FR BND1      z[2,0,0]
 FR BND1      z[2,0,1]
 FR BND1      z[2,0,2]
 FR BND1      z[2,0,3]
 FR BND1      z[2,0,4]
 FR BND1      z[2,0,5]
 FR BND1      z[2,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
ENDATA
