NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 E  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -3.0999999046325684e+00
    phi[0,1]  R85       -2.2400000095367432e+00
    phi[0,1]  R86       -2.2400000095367432e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       -3.0999999046325684e+00
    phi[0,1]  R89       -2.5699999332427979e+00
    phi[0,1]  R90       -2.5699999332427979e+00
    phi[0,1]  R91       -3.0999999046325684e+00
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -2.0899999141693115e+00
    phi[0,1]  R94       -2.0899999141693115e+00
    phi[0,1]  R95       -3.0999999046325684e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       1.6176911592483521e+00
    phi[0,1]  R98       1.9264374971389771e+00
    phi[0,1]  R99       -1.7764717340469360e+00
    phi[0,1]  R100      0.19227235019207
    phi[0,1]  R101      8.2300078868865967e-01
    phi[0,1]  R102      1.2250748872756958e+00
    phi[0,1]  R103      1.6920751333236694e-01
    phi[0,1]  R104      1.4693274497985840e+00
    phi[0,1]  R105      1.7805197238922119e+00
    phi[0,1]  R106      8.4915554523468018e-01
    phi[0,1]  R107      -9.6450674533843994e-01
    phi[0,1]  R108      -8.2347267866134644e-01
    phi[0,1]  R109      -1.5428993701934814e+00
    phi[0,1]  R110      -2.1978731155395508e+00
    phi[0,1]  R111      6.2043684720993042e-01
    phi[0,1]  R112      1.5893007516860962e+00
    phi[0,1]  R113      2.3979711532592773e+00
    phi[0,1]  R114      2.2645072937011719e+00
    phi[0,1]  R115      2.9162409305572510e+00
    phi[0,1]  R116      2.6519620418548584e+00
    phi[0,1]  R117      2.6510496139526367e+00
    phi[0,1]  R118      2.9280147552490234e+00
    phi[0,1]  R119      3.1418359279632568e+00
    phi[0,1]  R120      1.1599903553724289e-01
    phi[0,1]  R121      1.1462978124618530e+00
    phi[0,1]  R122      3.2080335617065430e+00
    phi[0,1]  R123      -3.0489850044250488e+00
    phi[0,1]  R124      2.3416626453399658e-01
    phi[0,1]  R125      -2.0564618110656738e+00
    phi[0,1]  R126      -2.9161450862884521e+00
    phi[0,1]  R127      -1.7801364660263062e+00
    phi[0,1]  R128      -1.3315849304199219e+00
    phi[0,1]  R129      -1.6002427339553833e+00
    phi[0,1]  R130      -2.0333988666534424e+00
    phi[0,1]  R131      -1.8048453330993652e+00
    phi[0,1]  R132      6.8536955118179321e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R133      -3.0999999046325684e+00
    phi[1,0]  R134      -3.0999999046325684e+00
    phi[1,0]  R135      -2.2400000095367432e+00
    phi[1,0]  R136      -2.2400000095367432e+00
    phi[1,0]  R137      -3.0999999046325684e+00
    phi[1,0]  R138      -3.0999999046325684e+00
    phi[1,0]  R139      -2.5699999332427979e+00
    phi[1,0]  R140      -2.5699999332427979e+00
    phi[1,0]  R141      -3.0999999046325684e+00
    phi[1,0]  R142      -3.0999999046325684e+00
    phi[1,0]  R143      -2.0899999141693115e+00
    phi[1,0]  R144      -2.0899999141693115e+00
    phi[1,0]  R145      -3.0999999046325684e+00
    phi[1,0]  R146      -3.0999999046325684e+00
    phi[1,0]  R147      2.3979711532592773e+00
    phi[1,0]  R148      2.2645072937011719e+00
    phi[1,0]  R149      2.9162409305572510e+00
    phi[1,0]  R150      2.6519620418548584e+00
    phi[1,0]  R151      2.6510496139526367e+00
    phi[1,0]  R152      2.9280147552490234e+00
    phi[1,0]  R153      3.1418359279632568e+00
    phi[1,0]  R154      1.1599903553724289e-01
    phi[1,0]  R155      1.1462978124618530e+00
    phi[1,0]  R156      3.2080335617065430e+00
    phi[1,0]  R157      -3.0489850044250488e+00
    phi[1,0]  R158      2.3416626453399658e-01
    phi[1,0]  R159      -2.0564618110656738e+00
    phi[1,0]  R160      -2.9161450862884521e+00
    phi[1,0]  R161      -1.7801364660263062e+00
    phi[1,0]  R162      -1.3315849304199219e+00
    phi[1,0]  R163      -1.6002427339553833e+00
    phi[1,0]  R164      -2.0333988666534424e+00
    phi[1,0]  R165      -1.8048453330993652e+00
    phi[1,0]  R166      6.8536955118179321e-01
    phi[1,0]  R167      1.6176911592483521e+00
    phi[1,0]  R168      1.9264374971389771e+00
    phi[1,0]  R169      -1.7764717340469360e+00
    phi[1,0]  R170      0.19227235019207
    phi[1,0]  R171      8.2300078868865967e-01
    phi[1,0]  R172      1.2250748872756958e+00
    phi[1,0]  R173      1.6920751333236694e-01
    phi[1,0]  R174      1.4693274497985840e+00
    phi[1,0]  R175      1.7805197238922119e+00
    phi[1,0]  R176      8.4915554523468018e-01
    phi[1,0]  R177      -9.6450674533843994e-01
    phi[1,0]  R178      -8.2347267866134644e-01
    phi[1,0]  R179      -1.5428993701934814e+00
    phi[1,0]  R180      -2.1978731155395508e+00
    phi[1,0]  R181      6.2043684720993042e-01
    phi[1,0]  R182      1.5893007516860962e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R183      -3.0999999046325684e+00
    phi[0,4]  R184      -3.0999999046325684e+00
    phi[0,4]  R185      -2.2400000095367432e+00
    phi[0,4]  R186      -2.2400000095367432e+00
    phi[0,4]  R187      -3.0999999046325684e+00
    phi[0,4]  R188      -3.0999999046325684e+00
    phi[0,4]  R189      -2.5699999332427979e+00
    phi[0,4]  R190      -2.5699999332427979e+00
    phi[0,4]  R191      -3.0999999046325684e+00
    phi[0,4]  R192      -3.0999999046325684e+00
    phi[0,4]  R193      -2.0899999141693115e+00
    phi[0,4]  R194      -2.0899999141693115e+00
    phi[0,4]  R195      -3.0999999046325684e+00
    phi[0,4]  R196      -3.0999999046325684e+00
    phi[0,4]  R197      1.6176911592483521e+00
    phi[0,4]  R198      1.9264374971389771e+00
    phi[0,4]  R199      -1.7764717340469360e+00
    phi[0,4]  R200      0.19227235019207
    phi[0,4]  R201      8.2300078868865967e-01
    phi[0,4]  R202      1.2250748872756958e+00
    phi[0,4]  R203      1.6920751333236694e-01
    phi[0,4]  R204      1.4693274497985840e+00
    phi[0,4]  R205      1.7805197238922119e+00
    phi[0,4]  R206      8.4915554523468018e-01
    phi[0,4]  R207      -9.6450674533843994e-01
    phi[0,4]  R208      -8.2347267866134644e-01
    phi[0,4]  R209      -1.5428993701934814e+00
    phi[0,4]  R210      -2.1978731155395508e+00
    phi[0,4]  R211      6.2043684720993042e-01
    phi[0,4]  R212      1.5893007516860962e+00
    phi[0,4]  R213      -1.2023929357528687e+00
    phi[0,4]  R214      0.352314829826355
    phi[0,4]  R215      2.4685935974121094e+00
    phi[0,4]  R216      1.8390362262725830e+00
    phi[0,4]  R217      2.1797032356262207e+00
    phi[0,4]  R218      1.9191360473632812e+00
    phi[0,4]  R219      2.0211613178253174e+00
    phi[0,4]  R220      -6.9803541898727417e-01
    phi[0,4]  R221      8.8250523805618286e-01
    phi[0,4]  R222      2.2618391513824463e+00
    phi[0,4]  R223      -1.1823394298553467e+00
    phi[0,4]  R224      -5.3477686643600464e-01
    phi[0,4]  R225      -2.3936569690704346e+00
    phi[0,4]  R226      4.5409354567527771e-01
    phi[0,4]  R227      -6.2627816200256348e-01
    phi[0,4]  R228      -1.2292701005935669e+00
    phi[0,4]  R229      -2.5000665187835693e+00
    phi[0,4]  R230      -1.2740068137645721e-01
    phi[0,4]  R231      3.7044934928417206e-02
    phi[0,4]  R232      -1.0751044750213623e+00
    phi[0,4]  R233      -1.34263014793396
    phi[0,4]  R234      -1.5654886960983276e+00
    phi[0,4]  R235      3.8693344593048096e-01
    phi[0,4]  R236      -1.5006781816482544e+00
    phi[0,4]  R237      -8.9753977954387665e-03
    phi[0,4]  R238      3.1434157863259315e-03
    phi[0,4]  R239      -9.9963355064392090e-01
    phi[0,4]  R240      -5.4390919208526611e-01
    phi[0,4]  R241      -1.1288168430328369e+00
    phi[0,4]  R242      2.5151152163743973e-02
    phi[0,4]  R243      -2.7150812149047852e+00
    phi[0,4]  R244      -1.1818279027938843e+00
    phi[0,4]  R245      4.3212777376174927e-01
    phi[0,4]  R246      -1.7364704608917236e+00
    phi[0,4]  R247      -4.7457376122474670e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R248      -3.0999999046325684e+00
    phi[4,0]  R249      -3.0999999046325684e+00
    phi[4,0]  R250      -2.2400000095367432e+00
    phi[4,0]  R251      -2.2400000095367432e+00
    phi[4,0]  R252      -3.0999999046325684e+00
    phi[4,0]  R253      -3.0999999046325684e+00
    phi[4,0]  R254      -2.5699999332427979e+00
    phi[4,0]  R255      -2.5699999332427979e+00
    phi[4,0]  R256      -3.0999999046325684e+00
    phi[4,0]  R257      -3.0999999046325684e+00
    phi[4,0]  R258      -2.0899999141693115e+00
    phi[4,0]  R259      -2.0899999141693115e+00
    phi[4,0]  R260      -3.0999999046325684e+00
    phi[4,0]  R261      -3.0999999046325684e+00
    phi[4,0]  R262      -1.2023929357528687e+00
    phi[4,0]  R263      0.352314829826355
    phi[4,0]  R264      2.4685935974121094e+00
    phi[4,0]  R265      1.8390362262725830e+00
    phi[4,0]  R266      2.1797032356262207e+00
    phi[4,0]  R267      1.9191360473632812e+00
    phi[4,0]  R268      2.0211613178253174e+00
    phi[4,0]  R269      -6.9803541898727417e-01
    phi[4,0]  R270      8.8250523805618286e-01
    phi[4,0]  R271      2.2618391513824463e+00
    phi[4,0]  R272      -1.1823394298553467e+00
    phi[4,0]  R273      -5.3477686643600464e-01
    phi[4,0]  R274      -2.3936569690704346e+00
    phi[4,0]  R275      4.5409354567527771e-01
    phi[4,0]  R276      -6.2627816200256348e-01
    phi[4,0]  R277      -1.2292701005935669e+00
    phi[4,0]  R278      -2.5000665187835693e+00
    phi[4,0]  R279      -1.2740068137645721e-01
    phi[4,0]  R280      3.7044934928417206e-02
    phi[4,0]  R281      -1.0751044750213623e+00
    phi[4,0]  R282      -1.34263014793396
    phi[4,0]  R283      -1.5654886960983276e+00
    phi[4,0]  R284      3.8693344593048096e-01
    phi[4,0]  R285      -1.5006781816482544e+00
    phi[4,0]  R286      -8.9753977954387665e-03
    phi[4,0]  R287      3.1434157863259315e-03
    phi[4,0]  R288      -9.9963355064392090e-01
    phi[4,0]  R289      -5.4390919208526611e-01
    phi[4,0]  R290      -1.1288168430328369e+00
    phi[4,0]  R291      2.5151152163743973e-02
    phi[4,0]  R292      -2.7150812149047852e+00
    phi[4,0]  R293      -1.1818279027938843e+00
    phi[4,0]  R294      4.3212777376174927e-01
    phi[4,0]  R295      -1.7364704608917236e+00
    phi[4,0]  R296      -4.7457376122474670e-01
    phi[4,0]  R297      1.6176911592483521e+00
    phi[4,0]  R298      1.9264374971389771e+00
    phi[4,0]  R299      -1.7764717340469360e+00
    phi[4,0]  R300      0.19227235019207
    phi[4,0]  R301      8.2300078868865967e-01
    phi[4,0]  R302      1.2250748872756958e+00
    phi[4,0]  R303      1.6920751333236694e-01
    phi[4,0]  R304      1.4693274497985840e+00
    phi[4,0]  R305      1.7805197238922119e+00
    phi[4,0]  R306      8.4915554523468018e-01
    phi[4,0]  R307      -9.6450674533843994e-01
    phi[4,0]  R308      -8.2347267866134644e-01
    phi[4,0]  R309      -1.5428993701934814e+00
    phi[4,0]  R310      -2.1978731155395508e+00
    phi[4,0]  R311      6.2043684720993042e-01
    phi[4,0]  R312      1.5893007516860962e+00
    phi[9,0]  R0        -1
    phi[9,0]  R2        9.4174765696930018e-01
    phi[9,0]  R3        1.8582516049777085e+00
    phi[9,0]  R4        -2.0075832245638567e+00
    phi[9,0]  R5        1.1312221732838843e+00
    phi[9,0]  R6        -6.1007437545507859e-02
    phi[9,0]  R7        -9.0157231981258179e-01
    phi[9,0]  R8        0.0858217947780835
    phi[9,0]  R81       1
    phi[9,0]  R313      -4.0417475616018681e+00
    phi[9,0]  R314      -2.1582522476632682e+00
    phi[9,0]  R315      -4.0982516145144512e+00
    phi[9,0]  R316      -3.8174840455903469e-01
    phi[9,0]  R317      -1.0924166800687116e+00
    phi[9,0]  R318      -5.1075831291964251e+00
    phi[9,0]  R319      -3.7012221065266822e+00
    phi[9,0]  R320      -1.4387777599589135e+00
    phi[9,0]  R321      -3.0389924670870605e+00
    phi[9,0]  R322      -3.1610073421780762e+00
    phi[9,0]  R323      -1.1884275943567297e+00
    phi[9,0]  R324      -2.9915722339818931e+00
    phi[9,0]  R325      -3.1858216994106519e+00
    phi[9,0]  R326      -3.0141781098544849e+00
    phi[9,0]  R327      -1.9851569034557759e-02
    phi[9,0]  R328      -2.5471759907746083e-02
    phi[9,0]  R329      -2.9536663642643513e-02
    phi[9,0]  R330      -4.1442807407454735e-02
    phi[9,0]  R331      -4.3835614215446461e-02
    phi[9,0]  R332      -0.284917317347829
    phi[9,0]  R333      -2.8839187310083814e-01
    phi[9,0]  R334      -3.0323159965211643e-01
    phi[9,0]  R335      -3.1809163213335845e-01
    phi[9,0]  R336      -3.6280290400721249e-01
    phi[9,0]  R337      -3.2669616957983094e-02
    phi[9,0]  R338      -3.3144503441120077e-02
    phi[9,0]  R339      -3.6002859217887595e-02
    phi[9,0]  R340      -2.6896966029044025e+00
    phi[9,0]  R341      -2.9899279014093971e-01
    phi[9,0]  R342      -3.3079224885882574e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R343      -3.0999999046325684e+00
    phi[1,2]  R344      -3.0999999046325684e+00
    phi[1,2]  R345      -2.2400000095367432e+00
    phi[1,2]  R346      -2.2400000095367432e+00
    phi[1,2]  R347      -3.0999999046325684e+00
    phi[1,2]  R348      -3.0999999046325684e+00
    phi[1,2]  R349      -2.5699999332427979e+00
    phi[1,2]  R350      -2.5699999332427979e+00
    phi[1,2]  R351      -3.0999999046325684e+00
    phi[1,2]  R352      -3.0999999046325684e+00
    phi[1,2]  R353      -2.0899999141693115e+00
    phi[1,2]  R354      -2.0899999141693115e+00
    phi[1,2]  R355      -3.0999999046325684e+00
    phi[1,2]  R356      -3.0999999046325684e+00
    phi[1,2]  R357      2.3979711532592773e+00
    phi[1,2]  R358      2.2645072937011719e+00
    phi[1,2]  R359      2.9162409305572510e+00
    phi[1,2]  R360      2.6519620418548584e+00
    phi[1,2]  R361      2.6510496139526367e+00
    phi[1,2]  R362      2.9280147552490234e+00
    phi[1,2]  R363      3.1418359279632568e+00
    phi[1,2]  R364      1.1599903553724289e-01
    phi[1,2]  R365      1.1462978124618530e+00
    phi[1,2]  R366      3.2080335617065430e+00
    phi[1,2]  R367      -3.0489850044250488e+00
    phi[1,2]  R368      2.3416626453399658e-01
    phi[1,2]  R369      -2.0564618110656738e+00
    phi[1,2]  R370      -2.9161450862884521e+00
    phi[1,2]  R371      -1.7801364660263062e+00
    phi[1,2]  R372      -1.3315849304199219e+00
    phi[1,2]  R373      -1.6002427339553833e+00
    phi[1,2]  R374      -2.0333988666534424e+00
    phi[1,2]  R375      -1.8048453330993652e+00
    phi[1,2]  R376      6.8536955118179321e-01
    phi[1,2]  R377      -1.4546804428100586e+00
    phi[1,2]  R378      -5.9212064743041992e-01
    phi[1,2]  R379      -1.0501078367233276e+00
    phi[1,2]  R380      4.3382245302200317e-01
    phi[1,2]  R381      -8.7469273805618286e-01
    phi[1,2]  R382      9.4552046060562134e-01
    phi[1,2]  R383      3.1285580992698669e-01
    phi[1,2]  R384      8.1798344850540161e-02
    phi[1,2]  R385      -1.3129736185073853e+00
    phi[1,2]  R386      1.6811151504516602e+00
    phi[1,2]  R387      -8.4134763479232788e-01
    phi[1,2]  R388      0.771798312664032
    phi[1,2]  R389      1.1031951904296875e+00
    phi[1,2]  R390      1.1481455564498901e+00
    phi[1,2]  R391      4.7361576557159424e-01
    phi[1,2]  R392      -4.1142477989196777e+00
    phi[1,2]  R393      -3.8815793991088867e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R394      -3.0999999046325684e+00
    phi[2,1]  R395      -3.0999999046325684e+00
    phi[2,1]  R396      -2.2400000095367432e+00
    phi[2,1]  R397      -2.2400000095367432e+00
    phi[2,1]  R398      -3.0999999046325684e+00
    phi[2,1]  R399      -3.0999999046325684e+00
    phi[2,1]  R400      -2.5699999332427979e+00
    phi[2,1]  R401      -2.5699999332427979e+00
    phi[2,1]  R402      -3.0999999046325684e+00
    phi[2,1]  R403      -3.0999999046325684e+00
    phi[2,1]  R404      -2.0899999141693115e+00
    phi[2,1]  R405      -2.0899999141693115e+00
    phi[2,1]  R406      -3.0999999046325684e+00
    phi[2,1]  R407      -3.0999999046325684e+00
    phi[2,1]  R408      -1.4546804428100586e+00
    phi[2,1]  R409      -5.9212064743041992e-01
    phi[2,1]  R410      -1.0501078367233276e+00
    phi[2,1]  R411      4.3382245302200317e-01
    phi[2,1]  R412      -8.7469273805618286e-01
    phi[2,1]  R413      9.4552046060562134e-01
    phi[2,1]  R414      3.1285580992698669e-01
    phi[2,1]  R415      8.1798344850540161e-02
    phi[2,1]  R416      -1.3129736185073853e+00
    phi[2,1]  R417      1.6811151504516602e+00
    phi[2,1]  R418      -8.4134763479232788e-01
    phi[2,1]  R419      0.771798312664032
    phi[2,1]  R420      1.1031951904296875e+00
    phi[2,1]  R421      1.1481455564498901e+00
    phi[2,1]  R422      4.7361576557159424e-01
    phi[2,1]  R423      -4.1142477989196777e+00
    phi[2,1]  R424      -3.8815793991088867e+00
    phi[2,1]  R425      2.3979711532592773e+00
    phi[2,1]  R426      2.2645072937011719e+00
    phi[2,1]  R427      2.9162409305572510e+00
    phi[2,1]  R428      2.6519620418548584e+00
    phi[2,1]  R429      2.6510496139526367e+00
    phi[2,1]  R430      2.9280147552490234e+00
    phi[2,1]  R431      3.1418359279632568e+00
    phi[2,1]  R432      1.1599903553724289e-01
    phi[2,1]  R433      1.1462978124618530e+00
    phi[2,1]  R434      3.2080335617065430e+00
    phi[2,1]  R435      -3.0489850044250488e+00
    phi[2,1]  R436      2.3416626453399658e-01
    phi[2,1]  R437      -2.0564618110656738e+00
    phi[2,1]  R438      -2.9161450862884521e+00
    phi[2,1]  R439      -1.7801364660263062e+00
    phi[2,1]  R440      -1.3315849304199219e+00
    phi[2,1]  R441      -1.6002427339553833e+00
    phi[2,1]  R442      -2.0333988666534424e+00
    phi[2,1]  R443      -1.8048453330993652e+00
    phi[2,1]  R444      6.8536955118179321e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R445      -3.0999999046325684e+00
    phi[2,3]  R446      -3.0999999046325684e+00
    phi[2,3]  R447      -2.2400000095367432e+00
    phi[2,3]  R448      -2.2400000095367432e+00
    phi[2,3]  R449      -3.0999999046325684e+00
    phi[2,3]  R450      -3.0999999046325684e+00
    phi[2,3]  R451      -2.5699999332427979e+00
    phi[2,3]  R452      -2.5699999332427979e+00
    phi[2,3]  R453      -3.0999999046325684e+00
    phi[2,3]  R454      -3.0999999046325684e+00
    phi[2,3]  R455      -2.0899999141693115e+00
    phi[2,3]  R456      -2.0899999141693115e+00
    phi[2,3]  R457      -3.0999999046325684e+00
    phi[2,3]  R458      -3.0999999046325684e+00
    phi[2,3]  R459      -1.4546804428100586e+00
    phi[2,3]  R460      -5.9212064743041992e-01
    phi[2,3]  R461      -1.0501078367233276e+00
    phi[2,3]  R462      4.3382245302200317e-01
    phi[2,3]  R463      -8.7469273805618286e-01
    phi[2,3]  R464      9.4552046060562134e-01
    phi[2,3]  R465      3.1285580992698669e-01
    phi[2,3]  R466      8.1798344850540161e-02
    phi[2,3]  R467      -1.3129736185073853e+00
    phi[2,3]  R468      1.6811151504516602e+00
    phi[2,3]  R469      -8.4134763479232788e-01
    phi[2,3]  R470      0.771798312664032
    phi[2,3]  R471      1.1031951904296875e+00
    phi[2,3]  R472      1.1481455564498901e+00
    phi[2,3]  R473      4.7361576557159424e-01
    phi[2,3]  R474      -4.1142477989196777e+00
    phi[2,3]  R475      -3.8815793991088867e+00
    phi[2,3]  R476      5.5691719055175781e-01
    phi[2,3]  R477      1.1676070690155029e+00
    phi[2,3]  R478      1.1257034540176392e+00
    phi[2,3]  R479      1.2889283895492554e+00
    phi[2,3]  R480      -1.0399992763996124e-01
    phi[2,3]  R481      1.4067442417144775e+00
    phi[2,3]  R482      4.2668992280960083e-01
    phi[2,3]  R483      -1.5571099519729614e-01
    phi[2,3]  R484      1.1044305562973022e+00
    phi[2,3]  R485      0.847160816192627
    phi[2,3]  R486      -1.1658567190170288e+00
    phi[2,3]  R487      -2.3524858951568604e+00
    phi[2,3]  R488      -4.8323315382003784e-01
    phi[2,3]  R489      -1.5230820178985596e+00
    phi[2,3]  R490      -1.2052540779113770e+00
    phi[2,3]  R491      -9.3188160657882690e-01
    phi[2,3]  R492      -1.4549326896667480e+00
    phi[2,3]  R493      -1.4218230247497559e+00
    phi[2,3]  R494      -0.72177654504776
    phi[2,3]  R495      -4.9966388940811157e-01
    phi[2,3]  R496      2.2174786031246185e-01
    phi[2,3]  R497      -1.1464895308017731e-01
    phi[2,3]  R498      -8.0772674083709717e-01
    phi[2,3]  R499      -9.9099779129028320e-01
    phi[2,3]  R500      -1.0556774139404297e+00
    phi[2,3]  R501      -0.825905442237854
    phi[2,3]  R502      -4.7574272751808167e-01
    phi[2,3]  R503      -5.4511600732803345e-01
    phi[2,3]  R504      -2.6870751380920410e-01
    phi[2,3]  R505      1.2476793676614761e-01
    phi[2,3]  R506      -2.0335075259208679e-01
    phi[2,3]  R507      -7.1775817871093750e-01
    phi[2,3]  R508      -1.5088090300559998e-01
    phi[2,3]  R509      -2.2003276348114014e+00
    phi[2,3]  R510      -4.5689743757247925e-01
    phi[2,3]  R511      -2.30526065826416
    phi[2,3]  R512      -1.3236665725708008e+00
    phi[2,3]  R513      2.2050376236438751e-01
    phi[2,3]  R514      4.6538457274436951e-01
    phi[2,3]  R515      -6.9870918989181519e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R516      -3.0999999046325684e+00
    phi[3,2]  R517      -3.0999999046325684e+00
    phi[3,2]  R518      -2.2400000095367432e+00
    phi[3,2]  R519      -2.2400000095367432e+00
    phi[3,2]  R520      -3.0999999046325684e+00
    phi[3,2]  R521      -3.0999999046325684e+00
    phi[3,2]  R522      -2.5699999332427979e+00
    phi[3,2]  R523      -2.5699999332427979e+00
    phi[3,2]  R524      -3.0999999046325684e+00
    phi[3,2]  R525      -3.0999999046325684e+00
    phi[3,2]  R526      -2.0899999141693115e+00
    phi[3,2]  R527      -2.0899999141693115e+00
    phi[3,2]  R528      -3.0999999046325684e+00
    phi[3,2]  R529      -3.0999999046325684e+00
    phi[3,2]  R530      5.5691719055175781e-01
    phi[3,2]  R531      1.1676070690155029e+00
    phi[3,2]  R532      1.1257034540176392e+00
    phi[3,2]  R533      1.2889283895492554e+00
    phi[3,2]  R534      -1.0399992763996124e-01
    phi[3,2]  R535      1.4067442417144775e+00
    phi[3,2]  R536      4.2668992280960083e-01
    phi[3,2]  R537      -1.5571099519729614e-01
    phi[3,2]  R538      1.1044305562973022e+00
    phi[3,2]  R539      0.847160816192627
    phi[3,2]  R540      -1.1658567190170288e+00
    phi[3,2]  R541      -2.3524858951568604e+00
    phi[3,2]  R542      -4.8323315382003784e-01
    phi[3,2]  R543      -1.5230820178985596e+00
    phi[3,2]  R544      -1.2052540779113770e+00
    phi[3,2]  R545      -9.3188160657882690e-01
    phi[3,2]  R546      -1.4549326896667480e+00
    phi[3,2]  R547      -1.4218230247497559e+00
    phi[3,2]  R548      -0.72177654504776
    phi[3,2]  R549      -4.9966388940811157e-01
    phi[3,2]  R550      2.2174786031246185e-01
    phi[3,2]  R551      -1.1464895308017731e-01
    phi[3,2]  R552      -8.0772674083709717e-01
    phi[3,2]  R553      -9.9099779129028320e-01
    phi[3,2]  R554      -1.0556774139404297e+00
    phi[3,2]  R555      -0.825905442237854
    phi[3,2]  R556      -4.7574272751808167e-01
    phi[3,2]  R557      -5.4511600732803345e-01
    phi[3,2]  R558      -2.6870751380920410e-01
    phi[3,2]  R559      1.2476793676614761e-01
    phi[3,2]  R560      -2.0335075259208679e-01
    phi[3,2]  R561      -7.1775817871093750e-01
    phi[3,2]  R562      -1.5088090300559998e-01
    phi[3,2]  R563      -2.2003276348114014e+00
    phi[3,2]  R564      -4.5689743757247925e-01
    phi[3,2]  R565      -2.30526065826416
    phi[3,2]  R566      -1.3236665725708008e+00
    phi[3,2]  R567      2.2050376236438751e-01
    phi[3,2]  R568      4.6538457274436951e-01
    phi[3,2]  R569      -6.9870918989181519e-01
    phi[3,2]  R570      -1.4546804428100586e+00
    phi[3,2]  R571      -5.9212064743041992e-01
    phi[3,2]  R572      -1.0501078367233276e+00
    phi[3,2]  R573      4.3382245302200317e-01
    phi[3,2]  R574      -8.7469273805618286e-01
    phi[3,2]  R575      9.4552046060562134e-01
    phi[3,2]  R576      3.1285580992698669e-01
    phi[3,2]  R577      8.1798344850540161e-02
    phi[3,2]  R578      -1.3129736185073853e+00
    phi[3,2]  R579      1.6811151504516602e+00
    phi[3,2]  R580      -8.4134763479232788e-01
    phi[3,2]  R581      0.771798312664032
    phi[3,2]  R582      1.1031951904296875e+00
    phi[3,2]  R583      1.1481455564498901e+00
    phi[3,2]  R584      4.7361576557159424e-01
    phi[3,2]  R585      -4.1142477989196777e+00
    phi[3,2]  R586      -3.8815793991088867e+00
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R72       -1
    phi[2,8]  R587      -3.0999999046325684e+00
    phi[2,8]  R588      -3.0999999046325684e+00
    phi[2,8]  R589      -2.2400000095367432e+00
    phi[2,8]  R590      -2.2400000095367432e+00
    phi[2,8]  R591      -3.0999999046325684e+00
    phi[2,8]  R592      -3.0999999046325684e+00
    phi[2,8]  R593      -2.5699999332427979e+00
    phi[2,8]  R594      -2.5699999332427979e+00
    phi[2,8]  R595      -3.0999999046325684e+00
    phi[2,8]  R596      -3.0999999046325684e+00
    phi[2,8]  R597      -2.0899999141693115e+00
    phi[2,8]  R598      -2.0899999141693115e+00
    phi[2,8]  R599      -3.0999999046325684e+00
    phi[2,8]  R600      -3.0999999046325684e+00
    phi[2,8]  R601      -1.4546804428100586e+00
    phi[2,8]  R602      -5.9212064743041992e-01
    phi[2,8]  R603      -1.0501078367233276e+00
    phi[2,8]  R604      4.3382245302200317e-01
    phi[2,8]  R605      -8.7469273805618286e-01
    phi[2,8]  R606      9.4552046060562134e-01
    phi[2,8]  R607      3.1285580992698669e-01
    phi[2,8]  R608      8.1798344850540161e-02
    phi[2,8]  R609      -1.3129736185073853e+00
    phi[2,8]  R610      1.6811151504516602e+00
    phi[2,8]  R611      -8.4134763479232788e-01
    phi[2,8]  R612      0.771798312664032
    phi[2,8]  R613      1.1031951904296875e+00
    phi[2,8]  R614      1.1481455564498901e+00
    phi[2,8]  R615      4.7361576557159424e-01
    phi[2,8]  R616      -4.1142477989196777e+00
    phi[2,8]  R617      -3.8815793991088867e+00
    phi[2,8]  R618      5.8282083272933960e-01
    phi[2,8]  R619      8.3800524473190308e-01
    phi[2,8]  R620      8.1208860874176025e-01
    phi[2,8]  R621      0.622974157333374
    phi[2,8]  R622      1.4355593919754028e+00
    phi[2,8]  R623      1.0575745105743408e+00
    phi[2,8]  R624      1.3136055469512939e+00
    phi[2,8]  R625      4.7144067287445068e-01
    phi[2,8]  R626      1.6568474769592285e+00
    phi[2,8]  R627      5.2560627460479736e-01
    phi[2,8]  R628      -4.3935582041740417e-01
    phi[2,8]  R629      -1.0026727914810181e+00
    phi[2,8]  R630      -1.4162725210189819e+00
    phi[2,8]  R631      -0.409243643283844
    phi[2,8]  R632      -4.7040209174156189e-01
    phi[2,8]  R633      -1.3549349308013916e+00
    phi[2,8]  R634      -2.0218968391418457e+00
    phi[2,8]  R635      -1.7422090768814087e+00
    phi[2,8]  R636      -2.2356967926025391e+00
    phi[2,8]  R637      -1.7128735780715942e+00
    phi[2,8]  R638      -9.5942610502243042e-01
    phi[2,8]  R639      -2.0333502292633057e+00
    phi[2,8]  R640      -7.8408193588256836e-01
    phi[2,8]  R641      -6.5372139215469360e-01
    phi[2,8]  R642      -6.8306976556777954e-01
    phi[2,8]  R643      -5.8369970321655273e-01
    phi[2,8]  R644      -7.0935618877410889e-01
    phi[2,8]  R645      -6.9286918640136719e-01
    phi[2,8]  R646      -1.1067681312561035e+00
    phi[2,8]  R647      -1.2483698129653931e+00
    phi[2,8]  R648      -1.7692523002624512e+00
    phi[2,8]  R649      -1.4669533967971802e+00
    phi[2,8]  R650      -1.5966976881027222e+00
    phi[2,8]  R651      -1.5375669002532959e+00
    phi[2,8]  R652      -1.2269496917724609e+00
    phi[2,8]  R653      -1.1999402046203613e+00
    phi[2,8]  R654      -1.1097574234008789e+00
    phi[2,8]  R655      -1.2974882125854492e+00
    phi[2,8]  R656      -8.7800550460815430e-01
    phi[2,8]  R657      -1.2297562360763550e+00
    phi[2,8]  R658      -1.9449659585952759e+00
    phi[2,8]  R659      -1.4276326894760132e+00
    phi[2,8]  R660      -7.8295665979385376e-01
    phi[2,8]  R661      -2.5256681442260742e+00
    phi[2,8]  R662      -1.7772398889064789e-01
    phi[2,8]  R663      -2.1754345893859863e+00
    phi[2,8]  R664      -1.0916693210601807e+00
    phi[2,8]  R665      -1.1356456279754639e+00
    phi[2,8]  R666      2.3508442938327789e-01
    phi[2,8]  R667      -2.2958195209503174e+00
    phi[8,2]  R18       -1
    phi[8,2]  R72       1
    phi[8,2]  R73       1
    phi[8,2]  R668      -3.0999999046325684e+00
    phi[8,2]  R669      -3.0999999046325684e+00
    phi[8,2]  R670      -2.2400000095367432e+00
    phi[8,2]  R671      -2.2400000095367432e+00
    phi[8,2]  R672      -3.0999999046325684e+00
    phi[8,2]  R673      -3.0999999046325684e+00
    phi[8,2]  R674      -2.5699999332427979e+00
    phi[8,2]  R675      -2.5699999332427979e+00
    phi[8,2]  R676      -3.0999999046325684e+00
    phi[8,2]  R677      -3.0999999046325684e+00
    phi[8,2]  R678      -2.0899999141693115e+00
    phi[8,2]  R679      -2.0899999141693115e+00
    phi[8,2]  R680      -3.0999999046325684e+00
    phi[8,2]  R681      -3.0999999046325684e+00
    phi[8,2]  R682      5.8282083272933960e-01
    phi[8,2]  R683      8.3800524473190308e-01
    phi[8,2]  R684      8.1208860874176025e-01
    phi[8,2]  R685      0.622974157333374
    phi[8,2]  R686      1.4355593919754028e+00
    phi[8,2]  R687      1.0575745105743408e+00
    phi[8,2]  R688      1.3136055469512939e+00
    phi[8,2]  R689      4.7144067287445068e-01
    phi[8,2]  R690      1.6568474769592285e+00
    phi[8,2]  R691      5.2560627460479736e-01
    phi[8,2]  R692      -4.3935582041740417e-01
    phi[8,2]  R693      -1.0026727914810181e+00
    phi[8,2]  R694      -1.4162725210189819e+00
    phi[8,2]  R695      -0.409243643283844
    phi[8,2]  R696      -4.7040209174156189e-01
    phi[8,2]  R697      -1.3549349308013916e+00
    phi[8,2]  R698      -2.0218968391418457e+00
    phi[8,2]  R699      -1.7422090768814087e+00
    phi[8,2]  R700      -2.2356967926025391e+00
    phi[8,2]  R701      -1.7128735780715942e+00
    phi[8,2]  R702      -9.5942610502243042e-01
    phi[8,2]  R703      -2.0333502292633057e+00
    phi[8,2]  R704      -7.8408193588256836e-01
    phi[8,2]  R705      -6.5372139215469360e-01
    phi[8,2]  R706      -6.8306976556777954e-01
    phi[8,2]  R707      -5.8369970321655273e-01
    phi[8,2]  R708      -7.0935618877410889e-01
    phi[8,2]  R709      -6.9286918640136719e-01
    phi[8,2]  R710      -1.1067681312561035e+00
    phi[8,2]  R711      -1.2483698129653931e+00
    phi[8,2]  R712      -1.7692523002624512e+00
    phi[8,2]  R713      -1.4669533967971802e+00
    phi[8,2]  R714      -1.5966976881027222e+00
    phi[8,2]  R715      -1.5375669002532959e+00
    phi[8,2]  R716      -1.2269496917724609e+00
    phi[8,2]  R717      -1.1999402046203613e+00
    phi[8,2]  R718      -1.1097574234008789e+00
    phi[8,2]  R719      -1.2974882125854492e+00
    phi[8,2]  R720      -8.7800550460815430e-01
    phi[8,2]  R721      -1.2297562360763550e+00
    phi[8,2]  R722      -1.9449659585952759e+00
    phi[8,2]  R723      -1.4276326894760132e+00
    phi[8,2]  R724      -7.8295665979385376e-01
    phi[8,2]  R725      -2.5256681442260742e+00
    phi[8,2]  R726      -1.7772398889064789e-01
    phi[8,2]  R727      -2.1754345893859863e+00
    phi[8,2]  R728      -1.0916693210601807e+00
    phi[8,2]  R729      -1.1356456279754639e+00
    phi[8,2]  R730      2.3508442938327789e-01
    phi[8,2]  R731      -2.2958195209503174e+00
    phi[8,2]  R732      -1.4546804428100586e+00
    phi[8,2]  R733      -5.9212064743041992e-01
    phi[8,2]  R734      -1.0501078367233276e+00
    phi[8,2]  R735      4.3382245302200317e-01
    phi[8,2]  R736      -8.7469273805618286e-01
    phi[8,2]  R737      9.4552046060562134e-01
    phi[8,2]  R738      3.1285580992698669e-01
    phi[8,2]  R739      8.1798344850540161e-02
    phi[8,2]  R740      -1.3129736185073853e+00
    phi[8,2]  R741      1.6811151504516602e+00
    phi[8,2]  R742      -8.4134763479232788e-01
    phi[8,2]  R743      0.771798312664032
    phi[8,2]  R744      1.1031951904296875e+00
    phi[8,2]  R745      1.1481455564498901e+00
    phi[8,2]  R746      4.7361576557159424e-01
    phi[8,2]  R747      -4.1142477989196777e+00
    phi[8,2]  R748      -3.8815793991088867e+00
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R749      -3.0999999046325684e+00
    phi[3,7]  R750      -3.0999999046325684e+00
    phi[3,7]  R751      -2.2400000095367432e+00
    phi[3,7]  R752      -2.2400000095367432e+00
    phi[3,7]  R753      -3.0999999046325684e+00
    phi[3,7]  R754      -3.0999999046325684e+00
    phi[3,7]  R755      -2.5699999332427979e+00
    phi[3,7]  R756      -2.5699999332427979e+00
    phi[3,7]  R757      -3.0999999046325684e+00
    phi[3,7]  R758      -3.0999999046325684e+00
    phi[3,7]  R759      -2.0899999141693115e+00
    phi[3,7]  R760      -2.0899999141693115e+00
    phi[3,7]  R761      -3.0999999046325684e+00
    phi[3,7]  R762      -3.0999999046325684e+00
    phi[3,7]  R763      5.5691719055175781e-01
    phi[3,7]  R764      1.1676070690155029e+00
    phi[3,7]  R765      1.1257034540176392e+00
    phi[3,7]  R766      1.2889283895492554e+00
    phi[3,7]  R767      -1.0399992763996124e-01
    phi[3,7]  R768      1.4067442417144775e+00
    phi[3,7]  R769      4.2668992280960083e-01
    phi[3,7]  R770      -1.5571099519729614e-01
    phi[3,7]  R771      1.1044305562973022e+00
    phi[3,7]  R772      0.847160816192627
    phi[3,7]  R773      -1.1658567190170288e+00
    phi[3,7]  R774      -2.3524858951568604e+00
    phi[3,7]  R775      -4.8323315382003784e-01
    phi[3,7]  R776      -1.5230820178985596e+00
    phi[3,7]  R777      -1.2052540779113770e+00
    phi[3,7]  R778      -9.3188160657882690e-01
    phi[3,7]  R779      -1.4549326896667480e+00
    phi[3,7]  R780      -1.4218230247497559e+00
    phi[3,7]  R781      -0.72177654504776
    phi[3,7]  R782      -4.9966388940811157e-01
    phi[3,7]  R783      2.2174786031246185e-01
    phi[3,7]  R784      -1.1464895308017731e-01
    phi[3,7]  R785      -8.0772674083709717e-01
    phi[3,7]  R786      -9.9099779129028320e-01
    phi[3,7]  R787      -1.0556774139404297e+00
    phi[3,7]  R788      -0.825905442237854
    phi[3,7]  R789      -4.7574272751808167e-01
    phi[3,7]  R790      -5.4511600732803345e-01
    phi[3,7]  R791      -2.6870751380920410e-01
    phi[3,7]  R792      1.2476793676614761e-01
    phi[3,7]  R793      -2.0335075259208679e-01
    phi[3,7]  R794      -7.1775817871093750e-01
    phi[3,7]  R795      -1.5088090300559998e-01
    phi[3,7]  R796      -2.2003276348114014e+00
    phi[3,7]  R797      -4.5689743757247925e-01
    phi[3,7]  R798      -2.30526065826416
    phi[3,7]  R799      -1.3236665725708008e+00
    phi[3,7]  R800      2.2050376236438751e-01
    phi[3,7]  R801      4.6538457274436951e-01
    phi[3,7]  R802      -6.9870918989181519e-01
    phi[3,7]  R803      8.0814909934997559e-01
    phi[3,7]  R804      0.593903660774231
    phi[3,7]  R805      2.8582972288131714e-01
    phi[3,7]  R806      7.7031278610229492e-01
    phi[3,7]  R807      1.3615182638168335e+00
    phi[3,7]  R808      1.3845279216766357e+00
    phi[3,7]  R809      1.5104572772979736e+00
    phi[3,7]  R810      1.2223293781280518e+00
    phi[3,7]  R811      5.7734370231628418e-01
    phi[3,7]  R812      1.2637337446212769e+00
    phi[3,7]  R813      -1.9761165380477905e+00
    phi[3,7]  R814      5.6174176931381226e-01
    phi[3,7]  R815      7.6697868108749390e-01
    phi[3,7]  R816      2.9686507582664490e-01
    phi[3,7]  R817      -3.5951399803161621e-01
    phi[3,7]  R818      -2.3557493090629578e-01
    phi[3,7]  R819      7.5873124599456787e-01
    phi[3,7]  R820      5.4362523555755615e-01
    phi[3,7]  R821      5.9937143325805664e-01
    phi[3,7]  R822      1.5125733613967896e-01
    phi[3,7]  R823      -2.9733273983001709e+00
    phi[3,7]  R824      -2.4763958454132080e+00
    phi[3,7]  R825      -1.7448166608810425e+00
    phi[3,7]  R826      -2.0399453639984131e+00
    phi[3,7]  R827      -2.0464224815368652e+00
    phi[3,7]  R828      -1.9427832365036011e+00
    phi[3,7]  R829      -1.7384226322174072e+00
    phi[3,7]  R830      -2.2709167003631592e+00
    phi[3,7]  R831      -2.5773463249206543e+00
    phi[3,7]  R832      -2.2635715007781982e+00
    phi[3,7]  R833      -2.1381218433380127e+00
    phi[3,7]  R834      -6.0316574573516846e-01
    phi[3,7]  R835      -2.8731775283813477e+00
    phi[3,7]  R836      -1.2101813554763794e+00
    phi[3,7]  R837      -1.6512056589126587e+00
    phi[3,7]  R838      3.4945130348205566e-01
    phi[3,7]  R839      -9.1628044843673706e-01
    phi[3,7]  R840      -7.2233664989471436e-01
    phi[3,7]  R841      -2.0741679668426514e+00
    phi[3,7]  R842      -1.2760337591171265e+00
    phi[3,7]  R843      -4.0075129270553589e-01
    phi[3,7]  R844      -1.5454621315002441e+00
    phi[3,7]  R845      -1.1258156299591064e+00
    phi[3,7]  R846      -0.809455394744873
    phi[3,7]  R847      -2.1934275627136230e+00
    phi[3,7]  R848      -7.0796781778335571e-01
    phi[3,7]  R849      -0.276529461145401
    phi[3,7]  R850      -1.2813086509704590e+00
    phi[3,7]  R851      -4.8335880041122437e-01
    phi[3,7]  R852      -1.5266004800796509e+00
    phi[3,7]  R853      -1.3633702993392944e+00
    phi[3,7]  R854      -1.9923751354217529e+00
    phi[3,7]  R855      6.0494482517242432e-01
    phi[3,7]  R856      4.4653840363025665e-02
    phi[3,7]  R857      -2.9458900913596153e-02
    phi[3,7]  R858      2.2889226675033569e-01
    phi[3,7]  R859      -6.9841831922531128e-01
    phi[3,7]  R860      -1.8795415163040161e+00
    phi[3,7]  R861      -1.1024289131164551e+00
    phi[3,7]  R862      -1.1221097707748413e+00
    phi[3,7]  R863      -1.3016744852066040e+00
    phi[3,7]  R864      -2.2501921653747559e+00
    phi[3,7]  R865      5.9786713123321533e-01
    phi[3,7]  R866      -9.7964859008789062e-01
    phi[3,7]  R867      -1.1365514993667603e+00
    phi[3,7]  R868      -2.3618225753307343e-01
    phi[3,7]  R869      1.1323076486587524e+00
    phi[3,7]  R870      -1.6009088754653931e+00
    phi[3,7]  R871      -1.0700919628143311e+00
    phi[3,7]  R872      -7.5001293420791626e-01
    phi[3,7]  R873      -2.1539564132690430e+00
    phi[3,7]  R874      -1.4369049072265625e+00
    phi[3,7]  R875      -1.3118622303009033e+00
    phi[3,7]  R876      -3.1221383810043335e-01
    phi[3,7]  R877      0.636221706867218
    phi[3,7]  R878      -3.0095168948173523e-01
    phi[3,7]  R879      -2.4399578571319580e+00
    phi[3,7]  R880      -1.2554960325360298e-02
    phi[3,7]  R881      -1.4634590148925781e+00
    phi[3,7]  R882      -8.5986232757568359e-01
    phi[3,7]  R883      -6.7004489898681641e-01
    phi[3,7]  R884      -1.4838951826095581e+00
    phi[3,7]  R885      -9.3338280916213989e-01
    phi[3,7]  R886      -1.8910875320434570e+00
    phi[3,7]  R887      -1.3837145566940308e+00
    phi[3,7]  R888      -1.5548077821731567e+00
    phi[3,7]  R889      -1.0777770280838013e+00
    phi[3,7]  R890      -9.8165266215801239e-02
    phi[3,7]  R891      -1.5265028476715088e+00
    phi[3,7]  R892      -7.0962882041931152e-01
    phi[3,7]  R893      -1.3603292703628540e+00
    phi[3,7]  R894      -1.7556039094924927e+00
    phi[3,7]  R895      -6.7591369152069092e-01
    phi[3,7]  R896      -5.3965717554092407e-01
    phi[3,7]  R897      -1.4771698415279388e-01
    phi[3,7]  R898      -1.6524975001811981e-01
    phi[3,7]  R899      2.6460245251655579e-01
    phi[3,7]  R900      -1.1077358722686768e+00
    phi[3,7]  R901      -5.9347808361053467e-01
    phi[3,7]  R902      -0.257224977016449
    phi[3,7]  R903      -3.1198132038116455e+00
    phi[3,7]  R904      -5.7441276311874390e-01
    phi[3,7]  R905      -7.0118492841720581e-01
    phi[3,7]  R906      -1.2638417482376099e+00
    phi[3,7]  R907      -1.4614349603652954e-01
    phi[3,7]  R908      -1.2780195474624634e+00
    phi[3,7]  R909      -1.8722082376480103e+00
    phi[3,7]  R910      2.4315266311168671e-01
    phi[3,7]  R911      -1.61667001247406
    phi[3,7]  R912      -2.0211164951324463e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R913      -3.0999999046325684e+00
    phi[7,3]  R914      -3.0999999046325684e+00
    phi[7,3]  R915      -2.2400000095367432e+00
    phi[7,3]  R916      -2.2400000095367432e+00
    phi[7,3]  R917      -3.0999999046325684e+00
    phi[7,3]  R918      -3.0999999046325684e+00
    phi[7,3]  R919      -2.5699999332427979e+00
    phi[7,3]  R920      -2.5699999332427979e+00
    phi[7,3]  R921      -3.0999999046325684e+00
    phi[7,3]  R922      -3.0999999046325684e+00
    phi[7,3]  R923      -2.0899999141693115e+00
    phi[7,3]  R924      -2.0899999141693115e+00
    phi[7,3]  R925      -3.0999999046325684e+00
    phi[7,3]  R926      -3.0999999046325684e+00
    phi[7,3]  R927      8.0814909934997559e-01
    phi[7,3]  R928      0.593903660774231
    phi[7,3]  R929      2.8582972288131714e-01
    phi[7,3]  R930      7.7031278610229492e-01
    phi[7,3]  R931      1.3615182638168335e+00
    phi[7,3]  R932      1.3845279216766357e+00
    phi[7,3]  R933      1.5104572772979736e+00
    phi[7,3]  R934      1.2223293781280518e+00
    phi[7,3]  R935      5.7734370231628418e-01
    phi[7,3]  R936      1.2637337446212769e+00
    phi[7,3]  R937      -1.9761165380477905e+00
    phi[7,3]  R938      5.6174176931381226e-01
    phi[7,3]  R939      7.6697868108749390e-01
    phi[7,3]  R940      2.9686507582664490e-01
    phi[7,3]  R941      -3.5951399803161621e-01
    phi[7,3]  R942      -2.3557493090629578e-01
    phi[7,3]  R943      7.5873124599456787e-01
    phi[7,3]  R944      5.4362523555755615e-01
    phi[7,3]  R945      5.9937143325805664e-01
    phi[7,3]  R946      1.5125733613967896e-01
    phi[7,3]  R947      -2.9733273983001709e+00
    phi[7,3]  R948      -2.4763958454132080e+00
    phi[7,3]  R949      -1.7448166608810425e+00
    phi[7,3]  R950      -2.0399453639984131e+00
    phi[7,3]  R951      -2.0464224815368652e+00
    phi[7,3]  R952      -1.9427832365036011e+00
    phi[7,3]  R953      -1.7384226322174072e+00
    phi[7,3]  R954      -2.2709167003631592e+00
    phi[7,3]  R955      -2.5773463249206543e+00
    phi[7,3]  R956      -2.2635715007781982e+00
    phi[7,3]  R957      -2.1381218433380127e+00
    phi[7,3]  R958      -6.0316574573516846e-01
    phi[7,3]  R959      -2.8731775283813477e+00
    phi[7,3]  R960      -1.2101813554763794e+00
    phi[7,3]  R961      -1.6512056589126587e+00
    phi[7,3]  R962      3.4945130348205566e-01
    phi[7,3]  R963      -9.1628044843673706e-01
    phi[7,3]  R964      -7.2233664989471436e-01
    phi[7,3]  R965      -2.0741679668426514e+00
    phi[7,3]  R966      -1.2760337591171265e+00
    phi[7,3]  R967      -4.0075129270553589e-01
    phi[7,3]  R968      -1.5454621315002441e+00
    phi[7,3]  R969      -1.1258156299591064e+00
    phi[7,3]  R970      -0.809455394744873
    phi[7,3]  R971      -2.1934275627136230e+00
    phi[7,3]  R972      -7.0796781778335571e-01
    phi[7,3]  R973      -0.276529461145401
    phi[7,3]  R974      -1.2813086509704590e+00
    phi[7,3]  R975      -4.8335880041122437e-01
    phi[7,3]  R976      -1.5266004800796509e+00
    phi[7,3]  R977      -1.3633702993392944e+00
    phi[7,3]  R978      -1.9923751354217529e+00
    phi[7,3]  R979      6.0494482517242432e-01
    phi[7,3]  R980      4.4653840363025665e-02
    phi[7,3]  R981      -2.9458900913596153e-02
    phi[7,3]  R982      2.2889226675033569e-01
    phi[7,3]  R983      -6.9841831922531128e-01
    phi[7,3]  R984      -1.8795415163040161e+00
    phi[7,3]  R985      -1.1024289131164551e+00
    phi[7,3]  R986      -1.1221097707748413e+00
    phi[7,3]  R987      -1.3016744852066040e+00
    phi[7,3]  R988      -2.2501921653747559e+00
    phi[7,3]  R989      5.9786713123321533e-01
    phi[7,3]  R990      -9.7964859008789062e-01
    phi[7,3]  R991      -1.1365514993667603e+00
    phi[7,3]  R992      -2.3618225753307343e-01
    phi[7,3]  R993      1.1323076486587524e+00
    phi[7,3]  R994      -1.6009088754653931e+00
    phi[7,3]  R995      -1.0700919628143311e+00
    phi[7,3]  R996      -7.5001293420791626e-01
    phi[7,3]  R997      -2.1539564132690430e+00
    phi[7,3]  R998      -1.4369049072265625e+00
    phi[7,3]  R999      -1.3118622303009033e+00
    phi[7,3]  R1000     -3.1221383810043335e-01
    phi[7,3]  R1001     0.636221706867218
    phi[7,3]  R1002     -3.0095168948173523e-01
    phi[7,3]  R1003     -2.4399578571319580e+00
    phi[7,3]  R1004     -1.2554960325360298e-02
    phi[7,3]  R1005     -1.4634590148925781e+00
    phi[7,3]  R1006     -8.5986232757568359e-01
    phi[7,3]  R1007     -6.7004489898681641e-01
    phi[7,3]  R1008     -1.4838951826095581e+00
    phi[7,3]  R1009     -9.3338280916213989e-01
    phi[7,3]  R1010     -1.8910875320434570e+00
    phi[7,3]  R1011     -1.3837145566940308e+00
    phi[7,3]  R1012     -1.5548077821731567e+00
    phi[7,3]  R1013     -1.0777770280838013e+00
    phi[7,3]  R1014     -9.8165266215801239e-02
    phi[7,3]  R1015     -1.5265028476715088e+00
    phi[7,3]  R1016     -7.0962882041931152e-01
    phi[7,3]  R1017     -1.3603292703628540e+00
    phi[7,3]  R1018     -1.7556039094924927e+00
    phi[7,3]  R1019     -6.7591369152069092e-01
    phi[7,3]  R1020     -5.3965717554092407e-01
    phi[7,3]  R1021     -1.4771698415279388e-01
    phi[7,3]  R1022     -1.6524975001811981e-01
    phi[7,3]  R1023     2.6460245251655579e-01
    phi[7,3]  R1024     -1.1077358722686768e+00
    phi[7,3]  R1025     -5.9347808361053467e-01
    phi[7,3]  R1026     -0.257224977016449
    phi[7,3]  R1027     -3.1198132038116455e+00
    phi[7,3]  R1028     -5.7441276311874390e-01
    phi[7,3]  R1029     -7.0118492841720581e-01
    phi[7,3]  R1030     -1.2638417482376099e+00
    phi[7,3]  R1031     -1.4614349603652954e-01
    phi[7,3]  R1032     -1.2780195474624634e+00
    phi[7,3]  R1033     -1.8722082376480103e+00
    phi[7,3]  R1034     2.4315266311168671e-01
    phi[7,3]  R1035     -1.61667001247406
    phi[7,3]  R1036     -2.0211164951324463e+00
    phi[7,3]  R1037     5.5691719055175781e-01
    phi[7,3]  R1038     1.1676070690155029e+00
    phi[7,3]  R1039     1.1257034540176392e+00
    phi[7,3]  R1040     1.2889283895492554e+00
    phi[7,3]  R1041     -1.0399992763996124e-01
    phi[7,3]  R1042     1.4067442417144775e+00
    phi[7,3]  R1043     4.2668992280960083e-01
    phi[7,3]  R1044     -1.5571099519729614e-01
    phi[7,3]  R1045     1.1044305562973022e+00
    phi[7,3]  R1046     0.847160816192627
    phi[7,3]  R1047     -1.1658567190170288e+00
    phi[7,3]  R1048     -2.3524858951568604e+00
    phi[7,3]  R1049     -4.8323315382003784e-01
    phi[7,3]  R1050     -1.5230820178985596e+00
    phi[7,3]  R1051     -1.2052540779113770e+00
    phi[7,3]  R1052     -9.3188160657882690e-01
    phi[7,3]  R1053     -1.4549326896667480e+00
    phi[7,3]  R1054     -1.4218230247497559e+00
    phi[7,3]  R1055     -0.72177654504776
    phi[7,3]  R1056     -4.9966388940811157e-01
    phi[7,3]  R1057     2.2174786031246185e-01
    phi[7,3]  R1058     -1.1464895308017731e-01
    phi[7,3]  R1059     -8.0772674083709717e-01
    phi[7,3]  R1060     -9.9099779129028320e-01
    phi[7,3]  R1061     -1.0556774139404297e+00
    phi[7,3]  R1062     -0.825905442237854
    phi[7,3]  R1063     -4.7574272751808167e-01
    phi[7,3]  R1064     -5.4511600732803345e-01
    phi[7,3]  R1065     -2.6870751380920410e-01
    phi[7,3]  R1066     1.2476793676614761e-01
    phi[7,3]  R1067     -2.0335075259208679e-01
    phi[7,3]  R1068     -7.1775817871093750e-01
    phi[7,3]  R1069     -1.5088090300559998e-01
    phi[7,3]  R1070     -2.2003276348114014e+00
    phi[7,3]  R1071     -4.5689743757247925e-01
    phi[7,3]  R1072     -2.30526065826416
    phi[7,3]  R1073     -1.3236665725708008e+00
    phi[7,3]  R1074     2.2050376236438751e-01
    phi[7,3]  R1075     4.6538457274436951e-01
    phi[7,3]  R1076     -6.9870918989181519e-01
    phi[3,8]  R27       1
    phi[3,8]  R28       1
    phi[3,8]  R72       -1
    phi[3,8]  R1077     -3.0999999046325684e+00
    phi[3,8]  R1078     -3.0999999046325684e+00
    phi[3,8]  R1079     -2.2400000095367432e+00
    phi[3,8]  R1080     -2.2400000095367432e+00
    phi[3,8]  R1081     -3.0999999046325684e+00
    phi[3,8]  R1082     -3.0999999046325684e+00
    phi[3,8]  R1083     -2.5699999332427979e+00
    phi[3,8]  R1084     -2.5699999332427979e+00
    phi[3,8]  R1085     -3.0999999046325684e+00
    phi[3,8]  R1086     -3.0999999046325684e+00
    phi[3,8]  R1087     -2.0899999141693115e+00
    phi[3,8]  R1088     -2.0899999141693115e+00
    phi[3,8]  R1089     -3.0999999046325684e+00
    phi[3,8]  R1090     -3.0999999046325684e+00
    phi[3,8]  R1091     5.5691719055175781e-01
    phi[3,8]  R1092     1.1676070690155029e+00
    phi[3,8]  R1093     1.1257034540176392e+00
    phi[3,8]  R1094     1.2889283895492554e+00
    phi[3,8]  R1095     -1.0399992763996124e-01
    phi[3,8]  R1096     1.4067442417144775e+00
    phi[3,8]  R1097     4.2668992280960083e-01
    phi[3,8]  R1098     -1.5571099519729614e-01
    phi[3,8]  R1099     1.1044305562973022e+00
    phi[3,8]  R1100     0.847160816192627
    phi[3,8]  R1101     -1.1658567190170288e+00
    phi[3,8]  R1102     -2.3524858951568604e+00
    phi[3,8]  R1103     -4.8323315382003784e-01
    phi[3,8]  R1104     -1.5230820178985596e+00
    phi[3,8]  R1105     -1.2052540779113770e+00
    phi[3,8]  R1106     -9.3188160657882690e-01
    phi[3,8]  R1107     -1.4549326896667480e+00
    phi[3,8]  R1108     -1.4218230247497559e+00
    phi[3,8]  R1109     -0.72177654504776
    phi[3,8]  R1110     -4.9966388940811157e-01
    phi[3,8]  R1111     2.2174786031246185e-01
    phi[3,8]  R1112     -1.1464895308017731e-01
    phi[3,8]  R1113     -8.0772674083709717e-01
    phi[3,8]  R1114     -9.9099779129028320e-01
    phi[3,8]  R1115     -1.0556774139404297e+00
    phi[3,8]  R1116     -0.825905442237854
    phi[3,8]  R1117     -4.7574272751808167e-01
    phi[3,8]  R1118     -5.4511600732803345e-01
    phi[3,8]  R1119     -2.6870751380920410e-01
    phi[3,8]  R1120     1.2476793676614761e-01
    phi[3,8]  R1121     -2.0335075259208679e-01
    phi[3,8]  R1122     -7.1775817871093750e-01
    phi[3,8]  R1123     -1.5088090300559998e-01
    phi[3,8]  R1124     -2.2003276348114014e+00
    phi[3,8]  R1125     -4.5689743757247925e-01
    phi[3,8]  R1126     -2.30526065826416
    phi[3,8]  R1127     -1.3236665725708008e+00
    phi[3,8]  R1128     2.2050376236438751e-01
    phi[3,8]  R1129     4.6538457274436951e-01
    phi[3,8]  R1130     -6.9870918989181519e-01
    phi[3,8]  R1131     5.8282083272933960e-01
    phi[3,8]  R1132     8.3800524473190308e-01
    phi[3,8]  R1133     8.1208860874176025e-01
    phi[3,8]  R1134     0.622974157333374
    phi[3,8]  R1135     1.4355593919754028e+00
    phi[3,8]  R1136     1.0575745105743408e+00
    phi[3,8]  R1137     1.3136055469512939e+00
    phi[3,8]  R1138     4.7144067287445068e-01
    phi[3,8]  R1139     1.6568474769592285e+00
    phi[3,8]  R1140     5.2560627460479736e-01
    phi[3,8]  R1141     -4.3935582041740417e-01
    phi[3,8]  R1142     -1.0026727914810181e+00
    phi[3,8]  R1143     -1.4162725210189819e+00
    phi[3,8]  R1144     -0.409243643283844
    phi[3,8]  R1145     -4.7040209174156189e-01
    phi[3,8]  R1146     -1.3549349308013916e+00
    phi[3,8]  R1147     -2.0218968391418457e+00
    phi[3,8]  R1148     -1.7422090768814087e+00
    phi[3,8]  R1149     -2.2356967926025391e+00
    phi[3,8]  R1150     -1.7128735780715942e+00
    phi[3,8]  R1151     -9.5942610502243042e-01
    phi[3,8]  R1152     -2.0333502292633057e+00
    phi[3,8]  R1153     -7.8408193588256836e-01
    phi[3,8]  R1154     -6.5372139215469360e-01
    phi[3,8]  R1155     -6.8306976556777954e-01
    phi[3,8]  R1156     -5.8369970321655273e-01
    phi[3,8]  R1157     -7.0935618877410889e-01
    phi[3,8]  R1158     -6.9286918640136719e-01
    phi[3,8]  R1159     -1.1067681312561035e+00
    phi[3,8]  R1160     -1.2483698129653931e+00
    phi[3,8]  R1161     -1.7692523002624512e+00
    phi[3,8]  R1162     -1.4669533967971802e+00
    phi[3,8]  R1163     -1.5966976881027222e+00
    phi[3,8]  R1164     -1.5375669002532959e+00
    phi[3,8]  R1165     -1.2269496917724609e+00
    phi[3,8]  R1166     -1.1999402046203613e+00
    phi[3,8]  R1167     -1.1097574234008789e+00
    phi[3,8]  R1168     -1.2974882125854492e+00
    phi[3,8]  R1169     -8.7800550460815430e-01
    phi[3,8]  R1170     -1.2297562360763550e+00
    phi[3,8]  R1171     -1.9449659585952759e+00
    phi[3,8]  R1172     -1.4276326894760132e+00
    phi[3,8]  R1173     -7.8295665979385376e-01
    phi[3,8]  R1174     -2.5256681442260742e+00
    phi[3,8]  R1175     -1.7772398889064789e-01
    phi[3,8]  R1176     -2.1754345893859863e+00
    phi[3,8]  R1177     -1.0916693210601807e+00
    phi[3,8]  R1178     -1.1356456279754639e+00
    phi[3,8]  R1179     2.3508442938327789e-01
    phi[3,8]  R1180     -2.2958195209503174e+00
    phi[8,3]  R27       -1
    phi[8,3]  R72       1
    phi[8,3]  R73       1
    phi[8,3]  R1181     -3.0999999046325684e+00
    phi[8,3]  R1182     -3.0999999046325684e+00
    phi[8,3]  R1183     -2.2400000095367432e+00
    phi[8,3]  R1184     -2.2400000095367432e+00
    phi[8,3]  R1185     -3.0999999046325684e+00
    phi[8,3]  R1186     -3.0999999046325684e+00
    phi[8,3]  R1187     -2.5699999332427979e+00
    phi[8,3]  R1188     -2.5699999332427979e+00
    phi[8,3]  R1189     -3.0999999046325684e+00
    phi[8,3]  R1190     -3.0999999046325684e+00
    phi[8,3]  R1191     -2.0899999141693115e+00
    phi[8,3]  R1192     -2.0899999141693115e+00
    phi[8,3]  R1193     -3.0999999046325684e+00
    phi[8,3]  R1194     -3.0999999046325684e+00
    phi[8,3]  R1195     5.8282083272933960e-01
    phi[8,3]  R1196     8.3800524473190308e-01
    phi[8,3]  R1197     8.1208860874176025e-01
    phi[8,3]  R1198     0.622974157333374
    phi[8,3]  R1199     1.4355593919754028e+00
    phi[8,3]  R1200     1.0575745105743408e+00
    phi[8,3]  R1201     1.3136055469512939e+00
    phi[8,3]  R1202     4.7144067287445068e-01
    phi[8,3]  R1203     1.6568474769592285e+00
    phi[8,3]  R1204     5.2560627460479736e-01
    phi[8,3]  R1205     -4.3935582041740417e-01
    phi[8,3]  R1206     -1.0026727914810181e+00
    phi[8,3]  R1207     -1.4162725210189819e+00
    phi[8,3]  R1208     -0.409243643283844
    phi[8,3]  R1209     -4.7040209174156189e-01
    phi[8,3]  R1210     -1.3549349308013916e+00
    phi[8,3]  R1211     -2.0218968391418457e+00
    phi[8,3]  R1212     -1.7422090768814087e+00
    phi[8,3]  R1213     -2.2356967926025391e+00
    phi[8,3]  R1214     -1.7128735780715942e+00
    phi[8,3]  R1215     -9.5942610502243042e-01
    phi[8,3]  R1216     -2.0333502292633057e+00
    phi[8,3]  R1217     -7.8408193588256836e-01
    phi[8,3]  R1218     -6.5372139215469360e-01
    phi[8,3]  R1219     -6.8306976556777954e-01
    phi[8,3]  R1220     -5.8369970321655273e-01
    phi[8,3]  R1221     -7.0935618877410889e-01
    phi[8,3]  R1222     -6.9286918640136719e-01
    phi[8,3]  R1223     -1.1067681312561035e+00
    phi[8,3]  R1224     -1.2483698129653931e+00
    phi[8,3]  R1225     -1.7692523002624512e+00
    phi[8,3]  R1226     -1.4669533967971802e+00
    phi[8,3]  R1227     -1.5966976881027222e+00
    phi[8,3]  R1228     -1.5375669002532959e+00
    phi[8,3]  R1229     -1.2269496917724609e+00
    phi[8,3]  R1230     -1.1999402046203613e+00
    phi[8,3]  R1231     -1.1097574234008789e+00
    phi[8,3]  R1232     -1.2974882125854492e+00
    phi[8,3]  R1233     -8.7800550460815430e-01
    phi[8,3]  R1234     -1.2297562360763550e+00
    phi[8,3]  R1235     -1.9449659585952759e+00
    phi[8,3]  R1236     -1.4276326894760132e+00
    phi[8,3]  R1237     -7.8295665979385376e-01
    phi[8,3]  R1238     -2.5256681442260742e+00
    phi[8,3]  R1239     -1.7772398889064789e-01
    phi[8,3]  R1240     -2.1754345893859863e+00
    phi[8,3]  R1241     -1.0916693210601807e+00
    phi[8,3]  R1242     -1.1356456279754639e+00
    phi[8,3]  R1243     2.3508442938327789e-01
    phi[8,3]  R1244     -2.2958195209503174e+00
    phi[8,3]  R1245     5.5691719055175781e-01
    phi[8,3]  R1246     1.1676070690155029e+00
    phi[8,3]  R1247     1.1257034540176392e+00
    phi[8,3]  R1248     1.2889283895492554e+00
    phi[8,3]  R1249     -1.0399992763996124e-01
    phi[8,3]  R1250     1.4067442417144775e+00
    phi[8,3]  R1251     4.2668992280960083e-01
    phi[8,3]  R1252     -1.5571099519729614e-01
    phi[8,3]  R1253     1.1044305562973022e+00
    phi[8,3]  R1254     0.847160816192627
    phi[8,3]  R1255     -1.1658567190170288e+00
    phi[8,3]  R1256     -2.3524858951568604e+00
    phi[8,3]  R1257     -4.8323315382003784e-01
    phi[8,3]  R1258     -1.5230820178985596e+00
    phi[8,3]  R1259     -1.2052540779113770e+00
    phi[8,3]  R1260     -9.3188160657882690e-01
    phi[8,3]  R1261     -1.4549326896667480e+00
    phi[8,3]  R1262     -1.4218230247497559e+00
    phi[8,3]  R1263     -0.72177654504776
    phi[8,3]  R1264     -4.9966388940811157e-01
    phi[8,3]  R1265     2.2174786031246185e-01
    phi[8,3]  R1266     -1.1464895308017731e-01
    phi[8,3]  R1267     -8.0772674083709717e-01
    phi[8,3]  R1268     -9.9099779129028320e-01
    phi[8,3]  R1269     -1.0556774139404297e+00
    phi[8,3]  R1270     -0.825905442237854
    phi[8,3]  R1271     -4.7574272751808167e-01
    phi[8,3]  R1272     -5.4511600732803345e-01
    phi[8,3]  R1273     -2.6870751380920410e-01
    phi[8,3]  R1274     1.2476793676614761e-01
    phi[8,3]  R1275     -2.0335075259208679e-01
    phi[8,3]  R1276     -7.1775817871093750e-01
    phi[8,3]  R1277     -1.5088090300559998e-01
    phi[8,3]  R1278     -2.2003276348114014e+00
    phi[8,3]  R1279     -4.5689743757247925e-01
    phi[8,3]  R1280     -2.30526065826416
    phi[8,3]  R1281     -1.3236665725708008e+00
    phi[8,3]  R1282     2.2050376236438751e-01
    phi[8,3]  R1283     4.6538457274436951e-01
    phi[8,3]  R1284     -6.9870918989181519e-01
    phi[3,10]  R27       1
    phi[3,10]  R28       1
    phi[3,10]  R29       1.5421065800520726e+00
    phi[3,10]  R30       -8.8776875076217410e-01
    phi[3,10]  R31       -3.8431048377833932e-01
    phi[3,10]  R32       -1.1588861938327546e+00
    phi[3,10]  R33       -1.1986656114441963e+00
    phi[3,10]  R34       -3.4680428057403478e-01
    phi[3,10]  R35       -1.0940946324365357e+00
    phi[3,10]  R82       -1
    phi[3,10]  R1285     -1.5578933245804958e+00
    phi[3,10]  R1286     -4.6421064846846409e+00
    phi[3,10]  R1287     -3.1277687602989173e+00
    phi[3,10]  R1288     -1.3522312587745691e+00
    phi[3,10]  R1289     -3.4843103884109077e+00
    phi[3,10]  R1290     -2.7156894208542290e+00
    phi[3,10]  R1291     -3.7288861270755524e+00
    phi[3,10]  R1292     -1.4111137394100433e+00
    phi[3,10]  R1293     -4.2986655160767651e+00
    phi[3,10]  R1294     -1.9013342931883721e+00
    phi[3,10]  R1295     -2.4368041947433463e+00
    phi[3,10]  R1296     -1.7431956335952767e+00
    phi[3,10]  R1297     -4.1940945370691036e+00
    phi[3,10]  R1298     -2.0059052721960327e+00
    phi[3,10]  R1299     -1.6567536766616553e-01
    phi[3,10]  R1300     -1.7070944436076396e-01
    phi[3,10]  R1301     -1.7513244083025414e-01
    phi[3,10]  R1302     -1.7887432683738824e-01
    phi[3,10]  R1303     -1.8287700534054721e-01
    phi[3,10]  R1304     -1.8338665309178959e-01
    phi[3,10]  R1305     -0.189284834845174
    phi[3,10]  R1306     -1.9886419991322180e-01
    phi[3,10]  R1307     -2.0081608183056465e-01
    phi[3,10]  R1308     -2.1733848698641411e-01
    phi[3,10]  R1309     -2.3950844932759618e-01
    phi[3,10]  R1310     -7.3835388692155113e-01
    phi[3,10]  R1311     -2.8220432090856484e-01
    phi[3,10]  R1312     -6.1750302791419986e-01
    phi[3,10]  R1313     -2.9580802536473882e-01
    phi[3,10]  R1314     -4.4406460414384152e-01
    phi[3,10]  R1315     -3.1747701567647368e-01
    phi[3,10]  R1316     -0.312280083298518
    phi[3,10]  R1317     -0.402718815741479
    phi[3,10]  R1318     -3.1729107351500296e-01
    phi[3,10]  R1319     -7.4319950449743832e-01
    phi[3,10]  R1320     -5.7307225451901478e-01
    phi[3,10]  R1321     -1.1018727016374101e+00
    phi[3,10]  R1322     -1.0375842017769965e+00
    phi[3,10]  R1323     -1.0129824397572516e+00
    phi[3,10]  R1324     -7.8402332759380711e-01
    phi[3,10]  R1325     -1.1882223072838332e+00
    phi[3,10]  R1326     -1.0237400013838875e+00
    phi[3,10]  R1327     -1.0239491841553234e+00
    phi[3,10]  R1328     -1.0775676762605870e+00
    phi[3,10]  R1329     -3.5956184362065763e-01
    phi[3,10]  R1330     -3.6447654920215578e-01
    phi[3,10]  R1331     -3.6790294862668249e-01
    phi[3,10]  R1332     -8.7967421703205417e-01
    phi[3,10]  R1333     -4.3130192344810292e-01
    phi[3,10]  R1334     -1.0548351133418423e+00
    phi[3,10]  R1335     -7.9909490779280934e-01
    phi[3,10]  R1336     -1.4125112814321095e+00
    phi[3,10]  R1337     -1.5372242997149663e+00
    phi[3,10]  R1338     -1.6869449857778314e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1339     -3.0999999046325684e+00
    phi[4,5]  R1340     -3.0999999046325684e+00
    phi[4,5]  R1341     -2.2400000095367432e+00
    phi[4,5]  R1342     -2.2400000095367432e+00
    phi[4,5]  R1343     -3.0999999046325684e+00
    phi[4,5]  R1344     -3.0999999046325684e+00
    phi[4,5]  R1345     -2.5699999332427979e+00
    phi[4,5]  R1346     -2.5699999332427979e+00
    phi[4,5]  R1347     -3.0999999046325684e+00
    phi[4,5]  R1348     -3.0999999046325684e+00
    phi[4,5]  R1349     -2.0899999141693115e+00
    phi[4,5]  R1350     -2.0899999141693115e+00
    phi[4,5]  R1351     -3.0999999046325684e+00
    phi[4,5]  R1352     -3.0999999046325684e+00
    phi[4,5]  R1353     -1.2023929357528687e+00
    phi[4,5]  R1354     0.352314829826355
    phi[4,5]  R1355     2.4685935974121094e+00
    phi[4,5]  R1356     1.8390362262725830e+00
    phi[4,5]  R1357     2.1797032356262207e+00
    phi[4,5]  R1358     1.9191360473632812e+00
    phi[4,5]  R1359     2.0211613178253174e+00
    phi[4,5]  R1360     -6.9803541898727417e-01
    phi[4,5]  R1361     8.8250523805618286e-01
    phi[4,5]  R1362     2.2618391513824463e+00
    phi[4,5]  R1363     -1.1823394298553467e+00
    phi[4,5]  R1364     -5.3477686643600464e-01
    phi[4,5]  R1365     -2.3936569690704346e+00
    phi[4,5]  R1366     4.5409354567527771e-01
    phi[4,5]  R1367     -6.2627816200256348e-01
    phi[4,5]  R1368     -1.2292701005935669e+00
    phi[4,5]  R1369     -2.5000665187835693e+00
    phi[4,5]  R1370     -1.2740068137645721e-01
    phi[4,5]  R1371     3.7044934928417206e-02
    phi[4,5]  R1372     -1.0751044750213623e+00
    phi[4,5]  R1373     -1.34263014793396
    phi[4,5]  R1374     -1.5654886960983276e+00
    phi[4,5]  R1375     3.8693344593048096e-01
    phi[4,5]  R1376     -1.5006781816482544e+00
    phi[4,5]  R1377     -8.9753977954387665e-03
    phi[4,5]  R1378     3.1434157863259315e-03
    phi[4,5]  R1379     -9.9963355064392090e-01
    phi[4,5]  R1380     -5.4390919208526611e-01
    phi[4,5]  R1381     -1.1288168430328369e+00
    phi[4,5]  R1382     2.5151152163743973e-02
    phi[4,5]  R1383     -2.7150812149047852e+00
    phi[4,5]  R1384     -1.1818279027938843e+00
    phi[4,5]  R1385     4.3212777376174927e-01
    phi[4,5]  R1386     -1.7364704608917236e+00
    phi[4,5]  R1387     -4.7457376122474670e-01
    phi[4,5]  R1388     -1.8298130482435226e-02
    phi[4,5]  R1389     -1.3601433038711548e+00
    phi[4,5]  R1390     -6.9190669059753418e-01
    phi[4,5]  R1391     8.8580265641212463e-02
    phi[4,5]  R1392     1.9816690683364868e+00
    phi[4,5]  R1393     2.1114418506622314e+00
    phi[4,5]  R1394     1.9855208396911621e+00
    phi[4,5]  R1395     -9.3719147145748138e-02
    phi[4,5]  R1396     1.8388533592224121e+00
    phi[4,5]  R1397     2.0132796764373779e+00
    phi[4,5]  R1398     -1.5927966833114624e+00
    phi[4,5]  R1399     7.5526319444179535e-02
    phi[4,5]  R1400     -2.6407063007354736e+00
    phi[4,5]  R1401     -2.7896173000335693e+00
    phi[4,5]  R1402     -1.6096544265747070e+00
    phi[4,5]  R1403     -2.2847490310668945e+00
    phi[4,5]  R1404     -2.2032866477966309e+00
    phi[4,5]  R1405     -2.1830172538757324e+00
    phi[4,5]  R1406     -1.5119225978851318e+00
    phi[4,5]  R1407     -2.4671163558959961e+00
    phi[4,5]  R1408     -1.8209593296051025e+00
    phi[4,5]  R1409     -1.4782996177673340e+00
    phi[4,5]  R1410     -1.3411904573440552e+00
    phi[4,5]  R1411     -1.2724453210830688e+00
    phi[4,5]  R1412     -1.4419362545013428e+00
    phi[4,5]  R1413     -1.7212557792663574e+00
    phi[4,5]  R1414     2.1362203359603882e-01
    phi[4,5]  R1415     -2.7031302452087402e+00
    phi[4,5]  R1416     -1.4083731174468994e+00
    phi[4,5]  R1417     -1.6713666915893555e+00
    phi[4,5]  R1418     -7.9356002807617188e-01
    phi[4,5]  R1419     -3.0880379676818848e+00
    phi[4,5]  R1420     -3.8299548625946045e-01
    phi[4,5]  R1421     -5.0625175237655640e-01
    phi[4,5]  R1422     7.1394972503185272e-02
    phi[4,5]  R1423     -4.7384798526763916e-01
    phi[4,5]  R1424     -3.1830927729606628e-01
    phi[4,5]  R1425     -1.2153860330581665e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1426     -3.0999999046325684e+00
    phi[5,4]  R1427     -3.0999999046325684e+00
    phi[5,4]  R1428     -2.2400000095367432e+00
    phi[5,4]  R1429     -2.2400000095367432e+00
    phi[5,4]  R1430     -3.0999999046325684e+00
    phi[5,4]  R1431     -3.0999999046325684e+00
    phi[5,4]  R1432     -2.5699999332427979e+00
    phi[5,4]  R1433     -2.5699999332427979e+00
    phi[5,4]  R1434     -3.0999999046325684e+00
    phi[5,4]  R1435     -3.0999999046325684e+00
    phi[5,4]  R1436     -2.0899999141693115e+00
    phi[5,4]  R1437     -2.0899999141693115e+00
    phi[5,4]  R1438     -3.0999999046325684e+00
    phi[5,4]  R1439     -3.0999999046325684e+00
    phi[5,4]  R1440     -1.8298130482435226e-02
    phi[5,4]  R1441     -1.3601433038711548e+00
    phi[5,4]  R1442     -6.9190669059753418e-01
    phi[5,4]  R1443     8.8580265641212463e-02
    phi[5,4]  R1444     1.9816690683364868e+00
    phi[5,4]  R1445     2.1114418506622314e+00
    phi[5,4]  R1446     1.9855208396911621e+00
    phi[5,4]  R1447     -9.3719147145748138e-02
    phi[5,4]  R1448     1.8388533592224121e+00
    phi[5,4]  R1449     2.0132796764373779e+00
    phi[5,4]  R1450     -1.5927966833114624e+00
    phi[5,4]  R1451     7.5526319444179535e-02
    phi[5,4]  R1452     -2.6407063007354736e+00
    phi[5,4]  R1453     -2.7896173000335693e+00
    phi[5,4]  R1454     -1.6096544265747070e+00
    phi[5,4]  R1455     -2.2847490310668945e+00
    phi[5,4]  R1456     -2.2032866477966309e+00
    phi[5,4]  R1457     -2.1830172538757324e+00
    phi[5,4]  R1458     -1.5119225978851318e+00
    phi[5,4]  R1459     -2.4671163558959961e+00
    phi[5,4]  R1460     -1.8209593296051025e+00
    phi[5,4]  R1461     -1.4782996177673340e+00
    phi[5,4]  R1462     -1.3411904573440552e+00
    phi[5,4]  R1463     -1.2724453210830688e+00
    phi[5,4]  R1464     -1.4419362545013428e+00
    phi[5,4]  R1465     -1.7212557792663574e+00
    phi[5,4]  R1466     2.1362203359603882e-01
    phi[5,4]  R1467     -2.7031302452087402e+00
    phi[5,4]  R1468     -1.4083731174468994e+00
    phi[5,4]  R1469     -1.6713666915893555e+00
    phi[5,4]  R1470     -7.9356002807617188e-01
    phi[5,4]  R1471     -3.0880379676818848e+00
    phi[5,4]  R1472     -3.8299548625946045e-01
    phi[5,4]  R1473     -5.0625175237655640e-01
    phi[5,4]  R1474     7.1394972503185272e-02
    phi[5,4]  R1475     -4.7384798526763916e-01
    phi[5,4]  R1476     -3.1830927729606628e-01
    phi[5,4]  R1477     -1.2153860330581665e+00
    phi[5,4]  R1478     -1.2023929357528687e+00
    phi[5,4]  R1479     0.352314829826355
    phi[5,4]  R1480     2.4685935974121094e+00
    phi[5,4]  R1481     1.8390362262725830e+00
    phi[5,4]  R1482     2.1797032356262207e+00
    phi[5,4]  R1483     1.9191360473632812e+00
    phi[5,4]  R1484     2.0211613178253174e+00
    phi[5,4]  R1485     -6.9803541898727417e-01
    phi[5,4]  R1486     8.8250523805618286e-01
    phi[5,4]  R1487     2.2618391513824463e+00
    phi[5,4]  R1488     -1.1823394298553467e+00
    phi[5,4]  R1489     -5.3477686643600464e-01
    phi[5,4]  R1490     -2.3936569690704346e+00
    phi[5,4]  R1491     4.5409354567527771e-01
    phi[5,4]  R1492     -6.2627816200256348e-01
    phi[5,4]  R1493     -1.2292701005935669e+00
    phi[5,4]  R1494     -2.5000665187835693e+00
    phi[5,4]  R1495     -1.2740068137645721e-01
    phi[5,4]  R1496     3.7044934928417206e-02
    phi[5,4]  R1497     -1.0751044750213623e+00
    phi[5,4]  R1498     -1.34263014793396
    phi[5,4]  R1499     -1.5654886960983276e+00
    phi[5,4]  R1500     3.8693344593048096e-01
    phi[5,4]  R1501     -1.5006781816482544e+00
    phi[5,4]  R1502     -8.9753977954387665e-03
    phi[5,4]  R1503     3.1434157863259315e-03
    phi[5,4]  R1504     -9.9963355064392090e-01
    phi[5,4]  R1505     -5.4390919208526611e-01
    phi[5,4]  R1506     -1.1288168430328369e+00
    phi[5,4]  R1507     2.5151152163743973e-02
    phi[5,4]  R1508     -2.7150812149047852e+00
    phi[5,4]  R1509     -1.1818279027938843e+00
    phi[5,4]  R1510     4.3212777376174927e-01
    phi[5,4]  R1511     -1.7364704608917236e+00
    phi[5,4]  R1512     -4.7457376122474670e-01
    phi[9,4]  R36       -1
    phi[9,4]  R38       9.4174765696930018e-01
    phi[9,4]  R39       1.8582516049777085e+00
    phi[9,4]  R40       -2.0075832245638567e+00
    phi[9,4]  R41       1.1312221732838843e+00
    phi[9,4]  R42       -6.1007437545507859e-02
    phi[9,4]  R43       -9.0157231981258179e-01
    phi[9,4]  R44       0.0858217947780835
    phi[9,4]  R81       1
    phi[9,4]  R1513     -4.0417475616018681e+00
    phi[9,4]  R1514     -2.1582522476632682e+00
    phi[9,4]  R1515     -4.0982516145144512e+00
    phi[9,4]  R1516     -3.8174840455903469e-01
    phi[9,4]  R1517     -1.0924166800687116e+00
    phi[9,4]  R1518     -5.1075831291964251e+00
    phi[9,4]  R1519     -3.7012221065266822e+00
    phi[9,4]  R1520     -1.4387777599589135e+00
    phi[9,4]  R1521     -3.0389924670870605e+00
    phi[9,4]  R1522     -3.1610073421780762e+00
    phi[9,4]  R1523     -1.1884275943567297e+00
    phi[9,4]  R1524     -2.9915722339818931e+00
    phi[9,4]  R1525     -3.1858216994106519e+00
    phi[9,4]  R1526     -3.0141781098544849e+00
    phi[9,4]  R1527     -1.37686078679259
    phi[9,4]  R1528     -1.1847147761053456e-01
    phi[9,4]  R1529     -1.2445789885983016e-01
    phi[9,4]  R1530     -1.2657669615442746e-01
    phi[9,4]  R1531     -1.3018732874036143e-01
    phi[9,4]  R1532     -1.3112955603313559e-01
    phi[9,4]  R1533     -1.3203551317332263e-01
    phi[9,4]  R1534     -0.949158290844675
    phi[9,4]  R1535     -1.3678975899820989e-01
    phi[9,4]  R1536     -1.3780302726227411e-01
    phi[9,4]  R1537     -1.4960424764955027e-01
    phi[9,4]  R1538     -1.6266071337202520e-01
    phi[9,4]  R1539     -1.3032734235710657e+00
    phi[9,4]  R1540     -1.8759247610546037e-01
    phi[9,4]  R1541     -1.9897524119925658e-01
    phi[9,4]  R1542     -2.0802406890599223e-01
    phi[9,4]  R1543     -1.4275613664453022e+00
    phi[9,4]  R1544     -2.0999075827069480e-01
    phi[9,4]  R1545     -2.2028528544668308e-01
    phi[9,4]  R1546     -2.3132916127694547e-01
    phi[9,4]  R1547     -1.0901258392324453e-01
    phi[9,4]  R1548     -1.3582355918837985e-01
    phi[9,4]  R1549     -1.4103230549358559e-01
    phi[9,4]  R1550     -1.5263403452629376e-01
    phi[9,4]  R1551     -1.6235789300723921e-01
    phi[9,4]  R1552     -1.7248736101161077e-01
    phi[9,4]  R1553     -1.7408247704010882e-01
    phi[9,4]  R1554     -1.8368513966994815e-01
    phi[9,4]  R1555     -1.8999663721002380e-01
    phi[9,4]  R1556     -1.9520258148230843e-01
    phi[9,4]  R1557     -1.7708589221646509e-01
    phi[9,4]  R1558     -1.8255789302196590e-01
    phi[9,4]  R1559     -1.9037066279834614e-01
    phi[9,4]  R1560     -2.3783859082486192e-01
    phi[9,4]  R1561     -3.8101784987298593e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1562     -3.0999999046325684e+00
    phi[5,6]  R1563     -3.0999999046325684e+00
    phi[5,6]  R1564     -2.2400000095367432e+00
    phi[5,6]  R1565     -2.2400000095367432e+00
    phi[5,6]  R1566     -3.0999999046325684e+00
    phi[5,6]  R1567     -3.0999999046325684e+00
    phi[5,6]  R1568     -2.5699999332427979e+00
    phi[5,6]  R1569     -2.5699999332427979e+00
    phi[5,6]  R1570     -3.0999999046325684e+00
    phi[5,6]  R1571     -3.0999999046325684e+00
    phi[5,6]  R1572     -2.0899999141693115e+00
    phi[5,6]  R1573     -2.0899999141693115e+00
    phi[5,6]  R1574     -3.0999999046325684e+00
    phi[5,6]  R1575     -3.0999999046325684e+00
    phi[5,6]  R1576     -1.8298130482435226e-02
    phi[5,6]  R1577     -1.3601433038711548e+00
    phi[5,6]  R1578     -6.9190669059753418e-01
    phi[5,6]  R1579     8.8580265641212463e-02
    phi[5,6]  R1580     1.9816690683364868e+00
    phi[5,6]  R1581     2.1114418506622314e+00
    phi[5,6]  R1582     1.9855208396911621e+00
    phi[5,6]  R1583     -9.3719147145748138e-02
    phi[5,6]  R1584     1.8388533592224121e+00
    phi[5,6]  R1585     2.0132796764373779e+00
    phi[5,6]  R1586     -1.5927966833114624e+00
    phi[5,6]  R1587     7.5526319444179535e-02
    phi[5,6]  R1588     -2.6407063007354736e+00
    phi[5,6]  R1589     -2.7896173000335693e+00
    phi[5,6]  R1590     -1.6096544265747070e+00
    phi[5,6]  R1591     -2.2847490310668945e+00
    phi[5,6]  R1592     -2.2032866477966309e+00
    phi[5,6]  R1593     -2.1830172538757324e+00
    phi[5,6]  R1594     -1.5119225978851318e+00
    phi[5,6]  R1595     -2.4671163558959961e+00
    phi[5,6]  R1596     -1.8209593296051025e+00
    phi[5,6]  R1597     -1.4782996177673340e+00
    phi[5,6]  R1598     -1.3411904573440552e+00
    phi[5,6]  R1599     -1.2724453210830688e+00
    phi[5,6]  R1600     -1.4419362545013428e+00
    phi[5,6]  R1601     -1.7212557792663574e+00
    phi[5,6]  R1602     2.1362203359603882e-01
    phi[5,6]  R1603     -2.7031302452087402e+00
    phi[5,6]  R1604     -1.4083731174468994e+00
    phi[5,6]  R1605     -1.6713666915893555e+00
    phi[5,6]  R1606     -7.9356002807617188e-01
    phi[5,6]  R1607     -3.0880379676818848e+00
    phi[5,6]  R1608     -3.8299548625946045e-01
    phi[5,6]  R1609     -5.0625175237655640e-01
    phi[5,6]  R1610     7.1394972503185272e-02
    phi[5,6]  R1611     -4.7384798526763916e-01
    phi[5,6]  R1612     -3.1830927729606628e-01
    phi[5,6]  R1613     -1.2153860330581665e+00
    phi[5,6]  R1614     1.7945587635040283e+00
    phi[5,6]  R1615     -2.5229876860976219e-02
    phi[5,6]  R1616     1.5759075880050659e+00
    phi[5,6]  R1617     -6.9480979442596436e-01
    phi[5,6]  R1618     6.3725960254669189e-01
    phi[5,6]  R1619     -4.9357242882251740e-02
    phi[5,6]  R1620     -1.6643366813659668e+00
    phi[5,6]  R1621     1.1803015470504761e+00
    phi[5,6]  R1622     -6.6094177961349487e-01
    phi[5,6]  R1623     -1.2120583057403564e+00
    phi[5,6]  R1624     -7.4432700872421265e-01
    phi[5,6]  R1625     -8.8830518722534180e-01
    phi[5,6]  R1626     -6.7630618810653687e-01
    phi[5,6]  R1627     -7.4179548025131226e-01
    phi[5,6]  R1628     -5.2418190240859985e-01
    phi[5,6]  R1629     -1.6497973203659058e+00
    phi[5,6]  R1630     -1.5367597341537476e+00
    phi[5,6]  R1631     -1.3893884420394897e+00
    phi[5,6]  R1632     -1.1687244176864624e+00
    phi[5,6]  R1633     4.0042963624000549e-01
    phi[5,6]  R1634     -2.7924988269805908e+00
    phi[5,6]  R1635     -1.2616661787033081e+00
    phi[5,6]  R1636     -0.684218168258667
    phi[5,6]  R1637     -1.5389295816421509e+00
    phi[5,6]  R1638     -9.2119020223617554e-01
    phi[5,6]  R1639     1.1347523927688599e+00
    phi[5,6]  R1640     6.9630306959152222e-01
    phi[5,6]  R1641     -1.2407938241958618e+00
    phi[5,6]  R1642     3.7352092564105988e-02
    phi[5,6]  R1643     -2.9763538837432861e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1644     -3.0999999046325684e+00
    phi[6,5]  R1645     -3.0999999046325684e+00
    phi[6,5]  R1646     -2.2400000095367432e+00
    phi[6,5]  R1647     -2.2400000095367432e+00
    phi[6,5]  R1648     -3.0999999046325684e+00
    phi[6,5]  R1649     -3.0999999046325684e+00
    phi[6,5]  R1650     -2.5699999332427979e+00
    phi[6,5]  R1651     -2.5699999332427979e+00
    phi[6,5]  R1652     -3.0999999046325684e+00
    phi[6,5]  R1653     -3.0999999046325684e+00
    phi[6,5]  R1654     -2.0899999141693115e+00
    phi[6,5]  R1655     -2.0899999141693115e+00
    phi[6,5]  R1656     -3.0999999046325684e+00
    phi[6,5]  R1657     -3.0999999046325684e+00
    phi[6,5]  R1658     1.7945587635040283e+00
    phi[6,5]  R1659     -2.5229876860976219e-02
    phi[6,5]  R1660     1.5759075880050659e+00
    phi[6,5]  R1661     -6.9480979442596436e-01
    phi[6,5]  R1662     6.3725960254669189e-01
    phi[6,5]  R1663     -4.9357242882251740e-02
    phi[6,5]  R1664     -1.6643366813659668e+00
    phi[6,5]  R1665     1.1803015470504761e+00
    phi[6,5]  R1666     -6.6094177961349487e-01
    phi[6,5]  R1667     -1.2120583057403564e+00
    phi[6,5]  R1668     -7.4432700872421265e-01
    phi[6,5]  R1669     -8.8830518722534180e-01
    phi[6,5]  R1670     -6.7630618810653687e-01
    phi[6,5]  R1671     -7.4179548025131226e-01
    phi[6,5]  R1672     -5.2418190240859985e-01
    phi[6,5]  R1673     -1.6497973203659058e+00
    phi[6,5]  R1674     -1.5367597341537476e+00
    phi[6,5]  R1675     -1.3893884420394897e+00
    phi[6,5]  R1676     -1.1687244176864624e+00
    phi[6,5]  R1677     4.0042963624000549e-01
    phi[6,5]  R1678     -2.7924988269805908e+00
    phi[6,5]  R1679     -1.2616661787033081e+00
    phi[6,5]  R1680     -0.684218168258667
    phi[6,5]  R1681     -1.5389295816421509e+00
    phi[6,5]  R1682     -9.2119020223617554e-01
    phi[6,5]  R1683     1.1347523927688599e+00
    phi[6,5]  R1684     6.9630306959152222e-01
    phi[6,5]  R1685     -1.2407938241958618e+00
    phi[6,5]  R1686     3.7352092564105988e-02
    phi[6,5]  R1687     -2.9763538837432861e+00
    phi[6,5]  R1688     -1.8298130482435226e-02
    phi[6,5]  R1689     -1.3601433038711548e+00
    phi[6,5]  R1690     -6.9190669059753418e-01
    phi[6,5]  R1691     8.8580265641212463e-02
    phi[6,5]  R1692     1.9816690683364868e+00
    phi[6,5]  R1693     2.1114418506622314e+00
    phi[6,5]  R1694     1.9855208396911621e+00
    phi[6,5]  R1695     -9.3719147145748138e-02
    phi[6,5]  R1696     1.8388533592224121e+00
    phi[6,5]  R1697     2.0132796764373779e+00
    phi[6,5]  R1698     -1.5927966833114624e+00
    phi[6,5]  R1699     7.5526319444179535e-02
    phi[6,5]  R1700     -2.6407063007354736e+00
    phi[6,5]  R1701     -2.7896173000335693e+00
    phi[6,5]  R1702     -1.6096544265747070e+00
    phi[6,5]  R1703     -2.2847490310668945e+00
    phi[6,5]  R1704     -2.2032866477966309e+00
    phi[6,5]  R1705     -2.1830172538757324e+00
    phi[6,5]  R1706     -1.5119225978851318e+00
    phi[6,5]  R1707     -2.4671163558959961e+00
    phi[6,5]  R1708     -1.8209593296051025e+00
    phi[6,5]  R1709     -1.4782996177673340e+00
    phi[6,5]  R1710     -1.3411904573440552e+00
    phi[6,5]  R1711     -1.2724453210830688e+00
    phi[6,5]  R1712     -1.4419362545013428e+00
    phi[6,5]  R1713     -1.7212557792663574e+00
    phi[6,5]  R1714     2.1362203359603882e-01
    phi[6,5]  R1715     -2.7031302452087402e+00
    phi[6,5]  R1716     -1.4083731174468994e+00
    phi[6,5]  R1717     -1.6713666915893555e+00
    phi[6,5]  R1718     -7.9356002807617188e-01
    phi[6,5]  R1719     -3.0880379676818848e+00
    phi[6,5]  R1720     -3.8299548625946045e-01
    phi[6,5]  R1721     -5.0625175237655640e-01
    phi[6,5]  R1722     7.1394972503185272e-02
    phi[6,5]  R1723     -4.7384798526763916e-01
    phi[6,5]  R1724     -3.1830927729606628e-01
    phi[6,5]  R1725     -1.2153860330581665e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R1726     -3.0999999046325684e+00
    phi[6,7]  R1727     -3.0999999046325684e+00
    phi[6,7]  R1728     -2.2400000095367432e+00
    phi[6,7]  R1729     -2.2400000095367432e+00
    phi[6,7]  R1730     -3.0999999046325684e+00
    phi[6,7]  R1731     -3.0999999046325684e+00
    phi[6,7]  R1732     -2.5699999332427979e+00
    phi[6,7]  R1733     -2.5699999332427979e+00
    phi[6,7]  R1734     -3.0999999046325684e+00
    phi[6,7]  R1735     -3.0999999046325684e+00
    phi[6,7]  R1736     -2.0899999141693115e+00
    phi[6,7]  R1737     -2.0899999141693115e+00
    phi[6,7]  R1738     -3.0999999046325684e+00
    phi[6,7]  R1739     -3.0999999046325684e+00
    phi[6,7]  R1740     1.7945587635040283e+00
    phi[6,7]  R1741     -2.5229876860976219e-02
    phi[6,7]  R1742     1.5759075880050659e+00
    phi[6,7]  R1743     -6.9480979442596436e-01
    phi[6,7]  R1744     6.3725960254669189e-01
    phi[6,7]  R1745     -4.9357242882251740e-02
    phi[6,7]  R1746     -1.6643366813659668e+00
    phi[6,7]  R1747     1.1803015470504761e+00
    phi[6,7]  R1748     -6.6094177961349487e-01
    phi[6,7]  R1749     -1.2120583057403564e+00
    phi[6,7]  R1750     -7.4432700872421265e-01
    phi[6,7]  R1751     -8.8830518722534180e-01
    phi[6,7]  R1752     -6.7630618810653687e-01
    phi[6,7]  R1753     -7.4179548025131226e-01
    phi[6,7]  R1754     -5.2418190240859985e-01
    phi[6,7]  R1755     -1.6497973203659058e+00
    phi[6,7]  R1756     -1.5367597341537476e+00
    phi[6,7]  R1757     -1.3893884420394897e+00
    phi[6,7]  R1758     -1.1687244176864624e+00
    phi[6,7]  R1759     4.0042963624000549e-01
    phi[6,7]  R1760     -2.7924988269805908e+00
    phi[6,7]  R1761     -1.2616661787033081e+00
    phi[6,7]  R1762     -0.684218168258667
    phi[6,7]  R1763     -1.5389295816421509e+00
    phi[6,7]  R1764     -9.2119020223617554e-01
    phi[6,7]  R1765     1.1347523927688599e+00
    phi[6,7]  R1766     6.9630306959152222e-01
    phi[6,7]  R1767     -1.2407938241958618e+00
    phi[6,7]  R1768     3.7352092564105988e-02
    phi[6,7]  R1769     -2.9763538837432861e+00
    phi[6,7]  R1770     8.0814909934997559e-01
    phi[6,7]  R1771     0.593903660774231
    phi[6,7]  R1772     2.8582972288131714e-01
    phi[6,7]  R1773     7.7031278610229492e-01
    phi[6,7]  R1774     1.3615182638168335e+00
    phi[6,7]  R1775     1.3845279216766357e+00
    phi[6,7]  R1776     1.5104572772979736e+00
    phi[6,7]  R1777     1.2223293781280518e+00
    phi[6,7]  R1778     5.7734370231628418e-01
    phi[6,7]  R1779     1.2637337446212769e+00
    phi[6,7]  R1780     -1.9761165380477905e+00
    phi[6,7]  R1781     5.6174176931381226e-01
    phi[6,7]  R1782     7.6697868108749390e-01
    phi[6,7]  R1783     2.9686507582664490e-01
    phi[6,7]  R1784     -3.5951399803161621e-01
    phi[6,7]  R1785     -2.3557493090629578e-01
    phi[6,7]  R1786     7.5873124599456787e-01
    phi[6,7]  R1787     5.4362523555755615e-01
    phi[6,7]  R1788     5.9937143325805664e-01
    phi[6,7]  R1789     1.5125733613967896e-01
    phi[6,7]  R1790     -2.9733273983001709e+00
    phi[6,7]  R1791     -2.4763958454132080e+00
    phi[6,7]  R1792     -1.7448166608810425e+00
    phi[6,7]  R1793     -2.0399453639984131e+00
    phi[6,7]  R1794     -2.0464224815368652e+00
    phi[6,7]  R1795     -1.9427832365036011e+00
    phi[6,7]  R1796     -1.7384226322174072e+00
    phi[6,7]  R1797     -2.2709167003631592e+00
    phi[6,7]  R1798     -2.5773463249206543e+00
    phi[6,7]  R1799     -2.2635715007781982e+00
    phi[6,7]  R1800     -2.1381218433380127e+00
    phi[6,7]  R1801     -6.0316574573516846e-01
    phi[6,7]  R1802     -2.8731775283813477e+00
    phi[6,7]  R1803     -1.2101813554763794e+00
    phi[6,7]  R1804     -1.6512056589126587e+00
    phi[6,7]  R1805     3.4945130348205566e-01
    phi[6,7]  R1806     -9.1628044843673706e-01
    phi[6,7]  R1807     -7.2233664989471436e-01
    phi[6,7]  R1808     -2.0741679668426514e+00
    phi[6,7]  R1809     -1.2760337591171265e+00
    phi[6,7]  R1810     -4.0075129270553589e-01
    phi[6,7]  R1811     -1.5454621315002441e+00
    phi[6,7]  R1812     -1.1258156299591064e+00
    phi[6,7]  R1813     -0.809455394744873
    phi[6,7]  R1814     -2.1934275627136230e+00
    phi[6,7]  R1815     -7.0796781778335571e-01
    phi[6,7]  R1816     -0.276529461145401
    phi[6,7]  R1817     -1.2813086509704590e+00
    phi[6,7]  R1818     -4.8335880041122437e-01
    phi[6,7]  R1819     -1.5266004800796509e+00
    phi[6,7]  R1820     -1.3633702993392944e+00
    phi[6,7]  R1821     -1.9923751354217529e+00
    phi[6,7]  R1822     6.0494482517242432e-01
    phi[6,7]  R1823     4.4653840363025665e-02
    phi[6,7]  R1824     -2.9458900913596153e-02
    phi[6,7]  R1825     2.2889226675033569e-01
    phi[6,7]  R1826     -6.9841831922531128e-01
    phi[6,7]  R1827     -1.8795415163040161e+00
    phi[6,7]  R1828     -1.1024289131164551e+00
    phi[6,7]  R1829     -1.1221097707748413e+00
    phi[6,7]  R1830     -1.3016744852066040e+00
    phi[6,7]  R1831     -2.2501921653747559e+00
    phi[6,7]  R1832     5.9786713123321533e-01
    phi[6,7]  R1833     -9.7964859008789062e-01
    phi[6,7]  R1834     -1.1365514993667603e+00
    phi[6,7]  R1835     -2.3618225753307343e-01
    phi[6,7]  R1836     1.1323076486587524e+00
    phi[6,7]  R1837     -1.6009088754653931e+00
    phi[6,7]  R1838     -1.0700919628143311e+00
    phi[6,7]  R1839     -7.5001293420791626e-01
    phi[6,7]  R1840     -2.1539564132690430e+00
    phi[6,7]  R1841     -1.4369049072265625e+00
    phi[6,7]  R1842     -1.3118622303009033e+00
    phi[6,7]  R1843     -3.1221383810043335e-01
    phi[6,7]  R1844     0.636221706867218
    phi[6,7]  R1845     -3.0095168948173523e-01
    phi[6,7]  R1846     -2.4399578571319580e+00
    phi[6,7]  R1847     -1.2554960325360298e-02
    phi[6,7]  R1848     -1.4634590148925781e+00
    phi[6,7]  R1849     -8.5986232757568359e-01
    phi[6,7]  R1850     -6.7004489898681641e-01
    phi[6,7]  R1851     -1.4838951826095581e+00
    phi[6,7]  R1852     -9.3338280916213989e-01
    phi[6,7]  R1853     -1.8910875320434570e+00
    phi[6,7]  R1854     -1.3837145566940308e+00
    phi[6,7]  R1855     -1.5548077821731567e+00
    phi[6,7]  R1856     -1.0777770280838013e+00
    phi[6,7]  R1857     -9.8165266215801239e-02
    phi[6,7]  R1858     -1.5265028476715088e+00
    phi[6,7]  R1859     -7.0962882041931152e-01
    phi[6,7]  R1860     -1.3603292703628540e+00
    phi[6,7]  R1861     -1.7556039094924927e+00
    phi[6,7]  R1862     -6.7591369152069092e-01
    phi[6,7]  R1863     -5.3965717554092407e-01
    phi[6,7]  R1864     -1.4771698415279388e-01
    phi[6,7]  R1865     -1.6524975001811981e-01
    phi[6,7]  R1866     2.6460245251655579e-01
    phi[6,7]  R1867     -1.1077358722686768e+00
    phi[6,7]  R1868     -5.9347808361053467e-01
    phi[6,7]  R1869     -0.257224977016449
    phi[6,7]  R1870     -3.1198132038116455e+00
    phi[6,7]  R1871     -5.7441276311874390e-01
    phi[6,7]  R1872     -7.0118492841720581e-01
    phi[6,7]  R1873     -1.2638417482376099e+00
    phi[6,7]  R1874     -1.4614349603652954e-01
    phi[6,7]  R1875     -1.2780195474624634e+00
    phi[6,7]  R1876     -1.8722082376480103e+00
    phi[6,7]  R1877     2.4315266311168671e-01
    phi[6,7]  R1878     -1.61667001247406
    phi[6,7]  R1879     -2.0211164951324463e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R1880     -3.0999999046325684e+00
    phi[7,6]  R1881     -3.0999999046325684e+00
    phi[7,6]  R1882     -2.2400000095367432e+00
    phi[7,6]  R1883     -2.2400000095367432e+00
    phi[7,6]  R1884     -3.0999999046325684e+00
    phi[7,6]  R1885     -3.0999999046325684e+00
    phi[7,6]  R1886     -2.5699999332427979e+00
    phi[7,6]  R1887     -2.5699999332427979e+00
    phi[7,6]  R1888     -3.0999999046325684e+00
    phi[7,6]  R1889     -3.0999999046325684e+00
    phi[7,6]  R1890     -2.0899999141693115e+00
    phi[7,6]  R1891     -2.0899999141693115e+00
    phi[7,6]  R1892     -3.0999999046325684e+00
    phi[7,6]  R1893     -3.0999999046325684e+00
    phi[7,6]  R1894     8.0814909934997559e-01
    phi[7,6]  R1895     0.593903660774231
    phi[7,6]  R1896     2.8582972288131714e-01
    phi[7,6]  R1897     7.7031278610229492e-01
    phi[7,6]  R1898     1.3615182638168335e+00
    phi[7,6]  R1899     1.3845279216766357e+00
    phi[7,6]  R1900     1.5104572772979736e+00
    phi[7,6]  R1901     1.2223293781280518e+00
    phi[7,6]  R1902     5.7734370231628418e-01
    phi[7,6]  R1903     1.2637337446212769e+00
    phi[7,6]  R1904     -1.9761165380477905e+00
    phi[7,6]  R1905     5.6174176931381226e-01
    phi[7,6]  R1906     7.6697868108749390e-01
    phi[7,6]  R1907     2.9686507582664490e-01
    phi[7,6]  R1908     -3.5951399803161621e-01
    phi[7,6]  R1909     -2.3557493090629578e-01
    phi[7,6]  R1910     7.5873124599456787e-01
    phi[7,6]  R1911     5.4362523555755615e-01
    phi[7,6]  R1912     5.9937143325805664e-01
    phi[7,6]  R1913     1.5125733613967896e-01
    phi[7,6]  R1914     -2.9733273983001709e+00
    phi[7,6]  R1915     -2.4763958454132080e+00
    phi[7,6]  R1916     -1.7448166608810425e+00
    phi[7,6]  R1917     -2.0399453639984131e+00
    phi[7,6]  R1918     -2.0464224815368652e+00
    phi[7,6]  R1919     -1.9427832365036011e+00
    phi[7,6]  R1920     -1.7384226322174072e+00
    phi[7,6]  R1921     -2.2709167003631592e+00
    phi[7,6]  R1922     -2.5773463249206543e+00
    phi[7,6]  R1923     -2.2635715007781982e+00
    phi[7,6]  R1924     -2.1381218433380127e+00
    phi[7,6]  R1925     -6.0316574573516846e-01
    phi[7,6]  R1926     -2.8731775283813477e+00
    phi[7,6]  R1927     -1.2101813554763794e+00
    phi[7,6]  R1928     -1.6512056589126587e+00
    phi[7,6]  R1929     3.4945130348205566e-01
    phi[7,6]  R1930     -9.1628044843673706e-01
    phi[7,6]  R1931     -7.2233664989471436e-01
    phi[7,6]  R1932     -2.0741679668426514e+00
    phi[7,6]  R1933     -1.2760337591171265e+00
    phi[7,6]  R1934     -4.0075129270553589e-01
    phi[7,6]  R1935     -1.5454621315002441e+00
    phi[7,6]  R1936     -1.1258156299591064e+00
    phi[7,6]  R1937     -0.809455394744873
    phi[7,6]  R1938     -2.1934275627136230e+00
    phi[7,6]  R1939     -7.0796781778335571e-01
    phi[7,6]  R1940     -0.276529461145401
    phi[7,6]  R1941     -1.2813086509704590e+00
    phi[7,6]  R1942     -4.8335880041122437e-01
    phi[7,6]  R1943     -1.5266004800796509e+00
    phi[7,6]  R1944     -1.3633702993392944e+00
    phi[7,6]  R1945     -1.9923751354217529e+00
    phi[7,6]  R1946     6.0494482517242432e-01
    phi[7,6]  R1947     4.4653840363025665e-02
    phi[7,6]  R1948     -2.9458900913596153e-02
    phi[7,6]  R1949     2.2889226675033569e-01
    phi[7,6]  R1950     -6.9841831922531128e-01
    phi[7,6]  R1951     -1.8795415163040161e+00
    phi[7,6]  R1952     -1.1024289131164551e+00
    phi[7,6]  R1953     -1.1221097707748413e+00
    phi[7,6]  R1954     -1.3016744852066040e+00
    phi[7,6]  R1955     -2.2501921653747559e+00
    phi[7,6]  R1956     5.9786713123321533e-01
    phi[7,6]  R1957     -9.7964859008789062e-01
    phi[7,6]  R1958     -1.1365514993667603e+00
    phi[7,6]  R1959     -2.3618225753307343e-01
    phi[7,6]  R1960     1.1323076486587524e+00
    phi[7,6]  R1961     -1.6009088754653931e+00
    phi[7,6]  R1962     -1.0700919628143311e+00
    phi[7,6]  R1963     -7.5001293420791626e-01
    phi[7,6]  R1964     -2.1539564132690430e+00
    phi[7,6]  R1965     -1.4369049072265625e+00
    phi[7,6]  R1966     -1.3118622303009033e+00
    phi[7,6]  R1967     -3.1221383810043335e-01
    phi[7,6]  R1968     0.636221706867218
    phi[7,6]  R1969     -3.0095168948173523e-01
    phi[7,6]  R1970     -2.4399578571319580e+00
    phi[7,6]  R1971     -1.2554960325360298e-02
    phi[7,6]  R1972     -1.4634590148925781e+00
    phi[7,6]  R1973     -8.5986232757568359e-01
    phi[7,6]  R1974     -6.7004489898681641e-01
    phi[7,6]  R1975     -1.4838951826095581e+00
    phi[7,6]  R1976     -9.3338280916213989e-01
    phi[7,6]  R1977     -1.8910875320434570e+00
    phi[7,6]  R1978     -1.3837145566940308e+00
    phi[7,6]  R1979     -1.5548077821731567e+00
    phi[7,6]  R1980     -1.0777770280838013e+00
    phi[7,6]  R1981     -9.8165266215801239e-02
    phi[7,6]  R1982     -1.5265028476715088e+00
    phi[7,6]  R1983     -7.0962882041931152e-01
    phi[7,6]  R1984     -1.3603292703628540e+00
    phi[7,6]  R1985     -1.7556039094924927e+00
    phi[7,6]  R1986     -6.7591369152069092e-01
    phi[7,6]  R1987     -5.3965717554092407e-01
    phi[7,6]  R1988     -1.4771698415279388e-01
    phi[7,6]  R1989     -1.6524975001811981e-01
    phi[7,6]  R1990     2.6460245251655579e-01
    phi[7,6]  R1991     -1.1077358722686768e+00
    phi[7,6]  R1992     -5.9347808361053467e-01
    phi[7,6]  R1993     -0.257224977016449
    phi[7,6]  R1994     -3.1198132038116455e+00
    phi[7,6]  R1995     -5.7441276311874390e-01
    phi[7,6]  R1996     -7.0118492841720581e-01
    phi[7,6]  R1997     -1.2638417482376099e+00
    phi[7,6]  R1998     -1.4614349603652954e-01
    phi[7,6]  R1999     -1.2780195474624634e+00
    phi[7,6]  R2000     -1.8722082376480103e+00
    phi[7,6]  R2001     2.4315266311168671e-01
    phi[7,6]  R2002     -1.61667001247406
    phi[7,6]  R2003     -2.0211164951324463e+00
    phi[7,6]  R2004     1.7945587635040283e+00
    phi[7,6]  R2005     -2.5229876860976219e-02
    phi[7,6]  R2006     1.5759075880050659e+00
    phi[7,6]  R2007     -6.9480979442596436e-01
    phi[7,6]  R2008     6.3725960254669189e-01
    phi[7,6]  R2009     -4.9357242882251740e-02
    phi[7,6]  R2010     -1.6643366813659668e+00
    phi[7,6]  R2011     1.1803015470504761e+00
    phi[7,6]  R2012     -6.6094177961349487e-01
    phi[7,6]  R2013     -1.2120583057403564e+00
    phi[7,6]  R2014     -7.4432700872421265e-01
    phi[7,6]  R2015     -8.8830518722534180e-01
    phi[7,6]  R2016     -6.7630618810653687e-01
    phi[7,6]  R2017     -7.4179548025131226e-01
    phi[7,6]  R2018     -5.2418190240859985e-01
    phi[7,6]  R2019     -1.6497973203659058e+00
    phi[7,6]  R2020     -1.5367597341537476e+00
    phi[7,6]  R2021     -1.3893884420394897e+00
    phi[7,6]  R2022     -1.1687244176864624e+00
    phi[7,6]  R2023     4.0042963624000549e-01
    phi[7,6]  R2024     -2.7924988269805908e+00
    phi[7,6]  R2025     -1.2616661787033081e+00
    phi[7,6]  R2026     -0.684218168258667
    phi[7,6]  R2027     -1.5389295816421509e+00
    phi[7,6]  R2028     -9.2119020223617554e-01
    phi[7,6]  R2029     1.1347523927688599e+00
    phi[7,6]  R2030     6.9630306959152222e-01
    phi[7,6]  R2031     -1.2407938241958618e+00
    phi[7,6]  R2032     3.7352092564105988e-02
    phi[7,6]  R2033     -2.9763538837432861e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2034     -3.0999999046325684e+00
    phi[7,8]  R2035     -3.0999999046325684e+00
    phi[7,8]  R2036     -2.2400000095367432e+00
    phi[7,8]  R2037     -2.2400000095367432e+00
    phi[7,8]  R2038     -3.0999999046325684e+00
    phi[7,8]  R2039     -3.0999999046325684e+00
    phi[7,8]  R2040     -2.5699999332427979e+00
    phi[7,8]  R2041     -2.5699999332427979e+00
    phi[7,8]  R2042     -3.0999999046325684e+00
    phi[7,8]  R2043     -3.0999999046325684e+00
    phi[7,8]  R2044     -2.0899999141693115e+00
    phi[7,8]  R2045     -2.0899999141693115e+00
    phi[7,8]  R2046     -3.0999999046325684e+00
    phi[7,8]  R2047     -3.0999999046325684e+00
    phi[7,8]  R2048     8.0814909934997559e-01
    phi[7,8]  R2049     0.593903660774231
    phi[7,8]  R2050     2.8582972288131714e-01
    phi[7,8]  R2051     7.7031278610229492e-01
    phi[7,8]  R2052     1.3615182638168335e+00
    phi[7,8]  R2053     1.3845279216766357e+00
    phi[7,8]  R2054     1.5104572772979736e+00
    phi[7,8]  R2055     1.2223293781280518e+00
    phi[7,8]  R2056     5.7734370231628418e-01
    phi[7,8]  R2057     1.2637337446212769e+00
    phi[7,8]  R2058     -1.9761165380477905e+00
    phi[7,8]  R2059     5.6174176931381226e-01
    phi[7,8]  R2060     7.6697868108749390e-01
    phi[7,8]  R2061     2.9686507582664490e-01
    phi[7,8]  R2062     -3.5951399803161621e-01
    phi[7,8]  R2063     -2.3557493090629578e-01
    phi[7,8]  R2064     7.5873124599456787e-01
    phi[7,8]  R2065     5.4362523555755615e-01
    phi[7,8]  R2066     5.9937143325805664e-01
    phi[7,8]  R2067     1.5125733613967896e-01
    phi[7,8]  R2068     -2.9733273983001709e+00
    phi[7,8]  R2069     -2.4763958454132080e+00
    phi[7,8]  R2070     -1.7448166608810425e+00
    phi[7,8]  R2071     -2.0399453639984131e+00
    phi[7,8]  R2072     -2.0464224815368652e+00
    phi[7,8]  R2073     -1.9427832365036011e+00
    phi[7,8]  R2074     -1.7384226322174072e+00
    phi[7,8]  R2075     -2.2709167003631592e+00
    phi[7,8]  R2076     -2.5773463249206543e+00
    phi[7,8]  R2077     -2.2635715007781982e+00
    phi[7,8]  R2078     -2.1381218433380127e+00
    phi[7,8]  R2079     -6.0316574573516846e-01
    phi[7,8]  R2080     -2.8731775283813477e+00
    phi[7,8]  R2081     -1.2101813554763794e+00
    phi[7,8]  R2082     -1.6512056589126587e+00
    phi[7,8]  R2083     3.4945130348205566e-01
    phi[7,8]  R2084     -9.1628044843673706e-01
    phi[7,8]  R2085     -7.2233664989471436e-01
    phi[7,8]  R2086     -2.0741679668426514e+00
    phi[7,8]  R2087     -1.2760337591171265e+00
    phi[7,8]  R2088     -4.0075129270553589e-01
    phi[7,8]  R2089     -1.5454621315002441e+00
    phi[7,8]  R2090     -1.1258156299591064e+00
    phi[7,8]  R2091     -0.809455394744873
    phi[7,8]  R2092     -2.1934275627136230e+00
    phi[7,8]  R2093     -7.0796781778335571e-01
    phi[7,8]  R2094     -0.276529461145401
    phi[7,8]  R2095     -1.2813086509704590e+00
    phi[7,8]  R2096     -4.8335880041122437e-01
    phi[7,8]  R2097     -1.5266004800796509e+00
    phi[7,8]  R2098     -1.3633702993392944e+00
    phi[7,8]  R2099     -1.9923751354217529e+00
    phi[7,8]  R2100     6.0494482517242432e-01
    phi[7,8]  R2101     4.4653840363025665e-02
    phi[7,8]  R2102     -2.9458900913596153e-02
    phi[7,8]  R2103     2.2889226675033569e-01
    phi[7,8]  R2104     -6.9841831922531128e-01
    phi[7,8]  R2105     -1.8795415163040161e+00
    phi[7,8]  R2106     -1.1024289131164551e+00
    phi[7,8]  R2107     -1.1221097707748413e+00
    phi[7,8]  R2108     -1.3016744852066040e+00
    phi[7,8]  R2109     -2.2501921653747559e+00
    phi[7,8]  R2110     5.9786713123321533e-01
    phi[7,8]  R2111     -9.7964859008789062e-01
    phi[7,8]  R2112     -1.1365514993667603e+00
    phi[7,8]  R2113     -2.3618225753307343e-01
    phi[7,8]  R2114     1.1323076486587524e+00
    phi[7,8]  R2115     -1.6009088754653931e+00
    phi[7,8]  R2116     -1.0700919628143311e+00
    phi[7,8]  R2117     -7.5001293420791626e-01
    phi[7,8]  R2118     -2.1539564132690430e+00
    phi[7,8]  R2119     -1.4369049072265625e+00
    phi[7,8]  R2120     -1.3118622303009033e+00
    phi[7,8]  R2121     -3.1221383810043335e-01
    phi[7,8]  R2122     0.636221706867218
    phi[7,8]  R2123     -3.0095168948173523e-01
    phi[7,8]  R2124     -2.4399578571319580e+00
    phi[7,8]  R2125     -1.2554960325360298e-02
    phi[7,8]  R2126     -1.4634590148925781e+00
    phi[7,8]  R2127     -8.5986232757568359e-01
    phi[7,8]  R2128     -6.7004489898681641e-01
    phi[7,8]  R2129     -1.4838951826095581e+00
    phi[7,8]  R2130     -9.3338280916213989e-01
    phi[7,8]  R2131     -1.8910875320434570e+00
    phi[7,8]  R2132     -1.3837145566940308e+00
    phi[7,8]  R2133     -1.5548077821731567e+00
    phi[7,8]  R2134     -1.0777770280838013e+00
    phi[7,8]  R2135     -9.8165266215801239e-02
    phi[7,8]  R2136     -1.5265028476715088e+00
    phi[7,8]  R2137     -7.0962882041931152e-01
    phi[7,8]  R2138     -1.3603292703628540e+00
    phi[7,8]  R2139     -1.7556039094924927e+00
    phi[7,8]  R2140     -6.7591369152069092e-01
    phi[7,8]  R2141     -5.3965717554092407e-01
    phi[7,8]  R2142     -1.4771698415279388e-01
    phi[7,8]  R2143     -1.6524975001811981e-01
    phi[7,8]  R2144     2.6460245251655579e-01
    phi[7,8]  R2145     -1.1077358722686768e+00
    phi[7,8]  R2146     -5.9347808361053467e-01
    phi[7,8]  R2147     -0.257224977016449
    phi[7,8]  R2148     -3.1198132038116455e+00
    phi[7,8]  R2149     -5.7441276311874390e-01
    phi[7,8]  R2150     -7.0118492841720581e-01
    phi[7,8]  R2151     -1.2638417482376099e+00
    phi[7,8]  R2152     -1.4614349603652954e-01
    phi[7,8]  R2153     -1.2780195474624634e+00
    phi[7,8]  R2154     -1.8722082376480103e+00
    phi[7,8]  R2155     2.4315266311168671e-01
    phi[7,8]  R2156     -1.61667001247406
    phi[7,8]  R2157     -2.0211164951324463e+00
    phi[7,8]  R2158     5.8282083272933960e-01
    phi[7,8]  R2159     8.3800524473190308e-01
    phi[7,8]  R2160     8.1208860874176025e-01
    phi[7,8]  R2161     0.622974157333374
    phi[7,8]  R2162     1.4355593919754028e+00
    phi[7,8]  R2163     1.0575745105743408e+00
    phi[7,8]  R2164     1.3136055469512939e+00
    phi[7,8]  R2165     4.7144067287445068e-01
    phi[7,8]  R2166     1.6568474769592285e+00
    phi[7,8]  R2167     5.2560627460479736e-01
    phi[7,8]  R2168     -4.3935582041740417e-01
    phi[7,8]  R2169     -1.0026727914810181e+00
    phi[7,8]  R2170     -1.4162725210189819e+00
    phi[7,8]  R2171     -0.409243643283844
    phi[7,8]  R2172     -4.7040209174156189e-01
    phi[7,8]  R2173     -1.3549349308013916e+00
    phi[7,8]  R2174     -2.0218968391418457e+00
    phi[7,8]  R2175     -1.7422090768814087e+00
    phi[7,8]  R2176     -2.2356967926025391e+00
    phi[7,8]  R2177     -1.7128735780715942e+00
    phi[7,8]  R2178     -9.5942610502243042e-01
    phi[7,8]  R2179     -2.0333502292633057e+00
    phi[7,8]  R2180     -7.8408193588256836e-01
    phi[7,8]  R2181     -6.5372139215469360e-01
    phi[7,8]  R2182     -6.8306976556777954e-01
    phi[7,8]  R2183     -5.8369970321655273e-01
    phi[7,8]  R2184     -7.0935618877410889e-01
    phi[7,8]  R2185     -6.9286918640136719e-01
    phi[7,8]  R2186     -1.1067681312561035e+00
    phi[7,8]  R2187     -1.2483698129653931e+00
    phi[7,8]  R2188     -1.7692523002624512e+00
    phi[7,8]  R2189     -1.4669533967971802e+00
    phi[7,8]  R2190     -1.5966976881027222e+00
    phi[7,8]  R2191     -1.5375669002532959e+00
    phi[7,8]  R2192     -1.2269496917724609e+00
    phi[7,8]  R2193     -1.1999402046203613e+00
    phi[7,8]  R2194     -1.1097574234008789e+00
    phi[7,8]  R2195     -1.2974882125854492e+00
    phi[7,8]  R2196     -8.7800550460815430e-01
    phi[7,8]  R2197     -1.2297562360763550e+00
    phi[7,8]  R2198     -1.9449659585952759e+00
    phi[7,8]  R2199     -1.4276326894760132e+00
    phi[7,8]  R2200     -7.8295665979385376e-01
    phi[7,8]  R2201     -2.5256681442260742e+00
    phi[7,8]  R2202     -1.7772398889064789e-01
    phi[7,8]  R2203     -2.1754345893859863e+00
    phi[7,8]  R2204     -1.0916693210601807e+00
    phi[7,8]  R2205     -1.1356456279754639e+00
    phi[7,8]  R2206     2.3508442938327789e-01
    phi[7,8]  R2207     -2.2958195209503174e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2208     -3.0999999046325684e+00
    phi[8,7]  R2209     -3.0999999046325684e+00
    phi[8,7]  R2210     -2.2400000095367432e+00
    phi[8,7]  R2211     -2.2400000095367432e+00
    phi[8,7]  R2212     -3.0999999046325684e+00
    phi[8,7]  R2213     -3.0999999046325684e+00
    phi[8,7]  R2214     -2.5699999332427979e+00
    phi[8,7]  R2215     -2.5699999332427979e+00
    phi[8,7]  R2216     -3.0999999046325684e+00
    phi[8,7]  R2217     -3.0999999046325684e+00
    phi[8,7]  R2218     -2.0899999141693115e+00
    phi[8,7]  R2219     -2.0899999141693115e+00
    phi[8,7]  R2220     -3.0999999046325684e+00
    phi[8,7]  R2221     -3.0999999046325684e+00
    phi[8,7]  R2222     5.8282083272933960e-01
    phi[8,7]  R2223     8.3800524473190308e-01
    phi[8,7]  R2224     8.1208860874176025e-01
    phi[8,7]  R2225     0.622974157333374
    phi[8,7]  R2226     1.4355593919754028e+00
    phi[8,7]  R2227     1.0575745105743408e+00
    phi[8,7]  R2228     1.3136055469512939e+00
    phi[8,7]  R2229     4.7144067287445068e-01
    phi[8,7]  R2230     1.6568474769592285e+00
    phi[8,7]  R2231     5.2560627460479736e-01
    phi[8,7]  R2232     -4.3935582041740417e-01
    phi[8,7]  R2233     -1.0026727914810181e+00
    phi[8,7]  R2234     -1.4162725210189819e+00
    phi[8,7]  R2235     -0.409243643283844
    phi[8,7]  R2236     -4.7040209174156189e-01
    phi[8,7]  R2237     -1.3549349308013916e+00
    phi[8,7]  R2238     -2.0218968391418457e+00
    phi[8,7]  R2239     -1.7422090768814087e+00
    phi[8,7]  R2240     -2.2356967926025391e+00
    phi[8,7]  R2241     -1.7128735780715942e+00
    phi[8,7]  R2242     -9.5942610502243042e-01
    phi[8,7]  R2243     -2.0333502292633057e+00
    phi[8,7]  R2244     -7.8408193588256836e-01
    phi[8,7]  R2245     -6.5372139215469360e-01
    phi[8,7]  R2246     -6.8306976556777954e-01
    phi[8,7]  R2247     -5.8369970321655273e-01
    phi[8,7]  R2248     -7.0935618877410889e-01
    phi[8,7]  R2249     -6.9286918640136719e-01
    phi[8,7]  R2250     -1.1067681312561035e+00
    phi[8,7]  R2251     -1.2483698129653931e+00
    phi[8,7]  R2252     -1.7692523002624512e+00
    phi[8,7]  R2253     -1.4669533967971802e+00
    phi[8,7]  R2254     -1.5966976881027222e+00
    phi[8,7]  R2255     -1.5375669002532959e+00
    phi[8,7]  R2256     -1.2269496917724609e+00
    phi[8,7]  R2257     -1.1999402046203613e+00
    phi[8,7]  R2258     -1.1097574234008789e+00
    phi[8,7]  R2259     -1.2974882125854492e+00
    phi[8,7]  R2260     -8.7800550460815430e-01
    phi[8,7]  R2261     -1.2297562360763550e+00
    phi[8,7]  R2262     -1.9449659585952759e+00
    phi[8,7]  R2263     -1.4276326894760132e+00
    phi[8,7]  R2264     -7.8295665979385376e-01
    phi[8,7]  R2265     -2.5256681442260742e+00
    phi[8,7]  R2266     -1.7772398889064789e-01
    phi[8,7]  R2267     -2.1754345893859863e+00
    phi[8,7]  R2268     -1.0916693210601807e+00
    phi[8,7]  R2269     -1.1356456279754639e+00
    phi[8,7]  R2270     2.3508442938327789e-01
    phi[8,7]  R2271     -2.2958195209503174e+00
    phi[8,7]  R2272     8.0814909934997559e-01
    phi[8,7]  R2273     0.593903660774231
    phi[8,7]  R2274     2.8582972288131714e-01
    phi[8,7]  R2275     7.7031278610229492e-01
    phi[8,7]  R2276     1.3615182638168335e+00
    phi[8,7]  R2277     1.3845279216766357e+00
    phi[8,7]  R2278     1.5104572772979736e+00
    phi[8,7]  R2279     1.2223293781280518e+00
    phi[8,7]  R2280     5.7734370231628418e-01
    phi[8,7]  R2281     1.2637337446212769e+00
    phi[8,7]  R2282     -1.9761165380477905e+00
    phi[8,7]  R2283     5.6174176931381226e-01
    phi[8,7]  R2284     7.6697868108749390e-01
    phi[8,7]  R2285     2.9686507582664490e-01
    phi[8,7]  R2286     -3.5951399803161621e-01
    phi[8,7]  R2287     -2.3557493090629578e-01
    phi[8,7]  R2288     7.5873124599456787e-01
    phi[8,7]  R2289     5.4362523555755615e-01
    phi[8,7]  R2290     5.9937143325805664e-01
    phi[8,7]  R2291     1.5125733613967896e-01
    phi[8,7]  R2292     -2.9733273983001709e+00
    phi[8,7]  R2293     -2.4763958454132080e+00
    phi[8,7]  R2294     -1.7448166608810425e+00
    phi[8,7]  R2295     -2.0399453639984131e+00
    phi[8,7]  R2296     -2.0464224815368652e+00
    phi[8,7]  R2297     -1.9427832365036011e+00
    phi[8,7]  R2298     -1.7384226322174072e+00
    phi[8,7]  R2299     -2.2709167003631592e+00
    phi[8,7]  R2300     -2.5773463249206543e+00
    phi[8,7]  R2301     -2.2635715007781982e+00
    phi[8,7]  R2302     -2.1381218433380127e+00
    phi[8,7]  R2303     -6.0316574573516846e-01
    phi[8,7]  R2304     -2.8731775283813477e+00
    phi[8,7]  R2305     -1.2101813554763794e+00
    phi[8,7]  R2306     -1.6512056589126587e+00
    phi[8,7]  R2307     3.4945130348205566e-01
    phi[8,7]  R2308     -9.1628044843673706e-01
    phi[8,7]  R2309     -7.2233664989471436e-01
    phi[8,7]  R2310     -2.0741679668426514e+00
    phi[8,7]  R2311     -1.2760337591171265e+00
    phi[8,7]  R2312     -4.0075129270553589e-01
    phi[8,7]  R2313     -1.5454621315002441e+00
    phi[8,7]  R2314     -1.1258156299591064e+00
    phi[8,7]  R2315     -0.809455394744873
    phi[8,7]  R2316     -2.1934275627136230e+00
    phi[8,7]  R2317     -7.0796781778335571e-01
    phi[8,7]  R2318     -0.276529461145401
    phi[8,7]  R2319     -1.2813086509704590e+00
    phi[8,7]  R2320     -4.8335880041122437e-01
    phi[8,7]  R2321     -1.5266004800796509e+00
    phi[8,7]  R2322     -1.3633702993392944e+00
    phi[8,7]  R2323     -1.9923751354217529e+00
    phi[8,7]  R2324     6.0494482517242432e-01
    phi[8,7]  R2325     4.4653840363025665e-02
    phi[8,7]  R2326     -2.9458900913596153e-02
    phi[8,7]  R2327     2.2889226675033569e-01
    phi[8,7]  R2328     -6.9841831922531128e-01
    phi[8,7]  R2329     -1.8795415163040161e+00
    phi[8,7]  R2330     -1.1024289131164551e+00
    phi[8,7]  R2331     -1.1221097707748413e+00
    phi[8,7]  R2332     -1.3016744852066040e+00
    phi[8,7]  R2333     -2.2501921653747559e+00
    phi[8,7]  R2334     5.9786713123321533e-01
    phi[8,7]  R2335     -9.7964859008789062e-01
    phi[8,7]  R2336     -1.1365514993667603e+00
    phi[8,7]  R2337     -2.3618225753307343e-01
    phi[8,7]  R2338     1.1323076486587524e+00
    phi[8,7]  R2339     -1.6009088754653931e+00
    phi[8,7]  R2340     -1.0700919628143311e+00
    phi[8,7]  R2341     -7.5001293420791626e-01
    phi[8,7]  R2342     -2.1539564132690430e+00
    phi[8,7]  R2343     -1.4369049072265625e+00
    phi[8,7]  R2344     -1.3118622303009033e+00
    phi[8,7]  R2345     -3.1221383810043335e-01
    phi[8,7]  R2346     0.636221706867218
    phi[8,7]  R2347     -3.0095168948173523e-01
    phi[8,7]  R2348     -2.4399578571319580e+00
    phi[8,7]  R2349     -1.2554960325360298e-02
    phi[8,7]  R2350     -1.4634590148925781e+00
    phi[8,7]  R2351     -8.5986232757568359e-01
    phi[8,7]  R2352     -6.7004489898681641e-01
    phi[8,7]  R2353     -1.4838951826095581e+00
    phi[8,7]  R2354     -9.3338280916213989e-01
    phi[8,7]  R2355     -1.8910875320434570e+00
    phi[8,7]  R2356     -1.3837145566940308e+00
    phi[8,7]  R2357     -1.5548077821731567e+00
    phi[8,7]  R2358     -1.0777770280838013e+00
    phi[8,7]  R2359     -9.8165266215801239e-02
    phi[8,7]  R2360     -1.5265028476715088e+00
    phi[8,7]  R2361     -7.0962882041931152e-01
    phi[8,7]  R2362     -1.3603292703628540e+00
    phi[8,7]  R2363     -1.7556039094924927e+00
    phi[8,7]  R2364     -6.7591369152069092e-01
    phi[8,7]  R2365     -5.3965717554092407e-01
    phi[8,7]  R2366     -1.4771698415279388e-01
    phi[8,7]  R2367     -1.6524975001811981e-01
    phi[8,7]  R2368     2.6460245251655579e-01
    phi[8,7]  R2369     -1.1077358722686768e+00
    phi[8,7]  R2370     -5.9347808361053467e-01
    phi[8,7]  R2371     -0.257224977016449
    phi[8,7]  R2372     -3.1198132038116455e+00
    phi[8,7]  R2373     -5.7441276311874390e-01
    phi[8,7]  R2374     -7.0118492841720581e-01
    phi[8,7]  R2375     -1.2638417482376099e+00
    phi[8,7]  R2376     -1.4614349603652954e-01
    phi[8,7]  R2377     -1.2780195474624634e+00
    phi[8,7]  R2378     -1.8722082376480103e+00
    phi[8,7]  R2379     2.4315266311168671e-01
    phi[8,7]  R2380     -1.61667001247406
    phi[8,7]  R2381     -2.0211164951324463e+00
    phi[8,10]  R72       1
    phi[8,10]  R73       1
    phi[8,10]  R74       1.5421065800520726e+00
    phi[8,10]  R75       -8.8776875076217410e-01
    phi[8,10]  R76       -3.8431048377833932e-01
    phi[8,10]  R77       -1.1588861938327546e+00
    phi[8,10]  R78       -1.1986656114441963e+00
    phi[8,10]  R79       -3.4680428057403478e-01
    phi[8,10]  R80       -1.0940946324365357e+00
    phi[8,10]  R82       -1
    phi[8,10]  R2382     -1.5578933245804958e+00
    phi[8,10]  R2383     -4.6421064846846409e+00
    phi[8,10]  R2384     -3.1277687602989173e+00
    phi[8,10]  R2385     -1.3522312587745691e+00
    phi[8,10]  R2386     -3.4843103884109077e+00
    phi[8,10]  R2387     -2.7156894208542290e+00
    phi[8,10]  R2388     -3.7288861270755524e+00
    phi[8,10]  R2389     -1.4111137394100433e+00
    phi[8,10]  R2390     -4.2986655160767651e+00
    phi[8,10]  R2391     -1.9013342931883721e+00
    phi[8,10]  R2392     -2.4368041947433463e+00
    phi[8,10]  R2393     -1.7431956335952767e+00
    phi[8,10]  R2394     -4.1940945370691036e+00
    phi[8,10]  R2395     -2.0059052721960327e+00
    phi[8,10]  R2396     -1.6617178484928519e-01
    phi[8,10]  R2397     -0.171247278395265
    phi[8,10]  R2398     -1.7172517473537130e-01
    phi[8,10]  R2399     -1.7475987539615512e-01
    phi[8,10]  R2400     -1.7525251953196141e-01
    phi[8,10]  R2401     -1.8469312227626444e-01
    phi[8,10]  R2402     -1.8636520441840077e-01
    phi[8,10]  R2403     -1.9136208913382924e-01
    phi[8,10]  R2404     -0.19259266156749
    phi[8,10]  R2405     -1.9366309797441872e-01
    phi[8,10]  R2406     -2.7238726966484855e-01
    phi[8,10]  R2407     -2.7791254021821210e-01
    phi[8,10]  R2408     -2.9883202052594116e-01
    phi[8,10]  R2409     -3.3217849139445765e-01
    phi[8,10]  R2410     -3.3570332236451655e-01
    phi[8,10]  R2411     -3.6840654817277907e-01
    phi[8,10]  R2412     -0.373706687838089
    phi[8,10]  R2413     -3.7476210251183373e-01
    phi[8,10]  R2414     -3.9793351867645921e-01
    phi[8,10]  R2415     -4.0467668287775105e-01
    phi[8,10]  R2416     -9.9366284388621418e-01
    phi[8,10]  R2417     -1.3577506173586014e+00
    phi[8,10]  R2418     -1.3244798825963948e+00
    phi[8,10]  R2419     -1.1853282111491912e+00
    phi[8,10]  R2420     -9.9741722294249135e-01
    phi[8,10]  R2421     -9.1399650908341834e-01
    phi[8,10]  R2422     -1.1733379469265965e+00
    phi[8,10]  R2423     -1.1140356487200878e+00
    phi[8,10]  R2424     -1.53701928543888
    phi[8,10]  R2425     -1.4686458602693246e+00
    phi[8,10]  R2426     -7.0698883604786866e-01
    phi[8,10]  R2427     -9.7333923043652115e-01
    phi[8,10]  R2428     -0.983380280315311
    phi[8,10]  R2429     -1.0036784869827904e+00
    phi[8,10]  R2430     -1.0170713306753221e+00
    phi[8,10]  R2431     -1.0228854237600988e+00
    phi[8,10]  R2432     -1.0391996303351161e+00
    phi[8,10]  R2433     -1.0461515739239136e+00
    phi[8,10]  R2434     -1.0613830674165086e+00
    phi[8,10]  R2435     -1.0649533462313243e+00
    phi[8,10]  R2436     -5.2406439848051090e-01
    phi[8,10]  R2437     -7.0492118879110033e-01
    phi[8,10]  R2438     -1.2619288615740618e+00
    phi[8,10]  R2439     -8.8951129796767225e-01
    phi[8,10]  R2440     -9.3848199097213580e-01
    phi[8,10]  R2441     -9.7343447720989085e-01
    phi[8,10]  R2442     -9.7558908746832618e-01
    phi[8,10]  R2443     -9.8230560884599982e-01
    phi[8,10]  R2444     -0.998603509480112
    phi[8,10]  R2445     -1.0175910432190380e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R83       -1
    z[0,1,0]  R84       1
    z[0,1,0]  R97       1.8577425181865692e-01
    z[0,1,0]  R98       -4.0250238776206970e-01
    z[0,1,0]  R99       5.9304761886596680e-01
    z[0,1,0]  R100      3.3914414048194885e-01
    z[0,1,0]  R101      4.2059165239334106e-01
    z[0,1,0]  R102      0.372530072927475
    z[0,1,0]  R103      0.504259467124939
    z[0,1,0]  R104      -3.6620065569877625e-01
    z[0,1,0]  R105      -4.2994326353073120e-01
    z[0,1,0]  R106      -9.0523689985275269e-02
    z[0,1,0]  R107      -4.3303436040878296e-01
    z[0,1,0]  R108      -3.4408020973205566e-01
    z[0,1,0]  R109      -6.3562989234924316e-01
    z[0,1,0]  R110      0.0958806499838829
    z[0,1,0]  R111      8.1111185252666473e-02
    z[0,1,0]  R112      -1.2107379734516144e-01
    z[0,1,0]  R113      6.1115242540836334e-02
    z[0,1,0]  R114      3.4678170084953308e-01
    z[0,1,0]  R115      -3.5861795768141747e-03
    z[0,1,0]  R116      4.4398523867130280e-02
    z[0,1,0]  R117      3.5011547803878784e-01
    z[0,1,0]  R118      2.0817881822586060e-01
    z[0,1,0]  R119      2.9778337478637695e-01
    z[0,1,0]  R120      -6.9507293403148651e-02
    z[0,1,0]  R121      0.0963430106639862
    z[0,1,0]  R122      2.5605884194374084e-01
    z[0,1,0]  R123      -4.7528970241546631e-01
    z[0,1,0]  R124      -4.1346180438995361e-01
    z[0,1,0]  R125      -3.2739189267158508e-01
    z[0,1,0]  R126      -2.5131538510322571e-01
    z[0,1,0]  R127      -4.4437846541404724e-01
    z[0,1,0]  R128      1.7433683574199677e-01
    z[0,1,0]  R129      -4.7088381648063660e-01
    z[0,1,0]  R130      -8.0200988054275513e-01
    z[0,1,0]  R131      -1.2751890718936920e-01
    z[0,1,0]  R132      1.9296426326036453e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R85       -1
    z[0,1,1]  R86       1
    z[0,1,1]  R97       6.9019153714179993e-02
    z[0,1,1]  R98       8.7127543985843658e-02
    z[0,1,1]  R99       2.9900375008583069e-01
    z[0,1,1]  R100      9.1754212975502014e-02
    z[0,1,1]  R101      9.7815565764904022e-02
    z[0,1,1]  R102      -8.5498660802841187e-01
    z[0,1,1]  R103      -7.6015001535415649e-01
    z[0,1,1]  R104      -8.4713155031204224e-01
    z[0,1,1]  R105      -7.8432118892669678e-01
    z[0,1,1]  R106      -8.1291466951370239e-01
    z[0,1,1]  R107      0.385277658700943
    z[0,1,1]  R108      5.4460048675537109e-01
    z[0,1,1]  R109      5.1341801881790161e-01
    z[0,1,1]  R110      -1.9678102806210518e-02
    z[0,1,1]  R111      -8.9115822315216064e-01
    z[0,1,1]  R112      -9.1251105070114136e-01
    z[0,1,1]  R113      -0.670496940612793
    z[0,1,1]  R114      1.9411586225032806e-01
    z[0,1,1]  R115      7.3674730956554413e-02
    z[0,1,1]  R116      1.3380122184753418e-01
    z[0,1,1]  R117      1.1019846051931381e-01
    z[0,1,1]  R118      -5.4210770130157471e-01
    z[0,1,1]  R119      0.147373229265213
    z[0,1,1]  R120      -8.3530586957931519e-01
    z[0,1,1]  R121      1.0140072554349899e-01
    z[0,1,1]  R122      -8.3609145879745483e-01
    z[0,1,1]  R123      5.6331526488065720e-02
    z[0,1,1]  R124      -5.4738566279411316e-02
    z[0,1,1]  R125      2.2444877028465271e-01
    z[0,1,1]  R126      0.8356893658638
    z[0,1,1]  R127      3.1258377432823181e-01
    z[0,1,1]  R128      4.5268520712852478e-01
    z[0,1,1]  R129      0.725092887878418
    z[0,1,1]  R130      5.1484996080398560e-01
    z[0,1,1]  R131      7.5360083580017090e-01
    z[0,1,1]  R132      2.6453128457069397e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R87       -1
    z[0,1,2]  R88       1
    z[0,1,2]  R97       8.6046516895294189e-01
    z[0,1,2]  R98       4.7455862164497375e-01
    z[0,1,2]  R99       -2.1670293807983398e-01
    z[0,1,2]  R100      1.3036768138408661e-01
    z[0,1,2]  R101      7.9535908997058868e-02
    z[0,1,2]  R102      9.3808054924011230e-02
    z[0,1,2]  R103      -1.9777974113821983e-02
    z[0,1,2]  R104      1.2077989988029003e-02
    z[0,1,2]  R105      1.1202631890773773e-01
    z[0,1,2]  R106      -2.5457123294472694e-02
    z[0,1,2]  R107      2.3391798138618469e-01
    z[0,1,2]  R108      -5.8963544666767120e-02
    z[0,1,2]  R109      -0.425925612449646
    z[0,1,2]  R110      2.6953849196434021e-01
    z[0,1,2]  R111      -2.3235602676868439e-01
    z[0,1,2]  R112      -1.1962404847145081e-01
    z[0,1,2]  R113      5.2930426597595215e-01
    z[0,1,2]  R114      3.5214978456497192e-01
    z[0,1,2]  R115      4.5405516028404236e-01
    z[0,1,2]  R116      4.7220396995544434e-01
    z[0,1,2]  R117      7.8601932525634766e-01
    z[0,1,2]  R118      -8.1950798630714417e-02
    z[0,1,2]  R119      7.1948093175888062e-01
    z[0,1,2]  R120      -3.2306644320487976e-01
    z[0,1,2]  R121      3.1845986843109131e-02
    z[0,1,2]  R122      3.1323564052581787e-01
    z[0,1,2]  R123      -2.5523701310157776e-01
    z[0,1,2]  R124      -2.8995606303215027e-01
    z[0,1,2]  R125      -1.8330007791519165e-01
    z[0,1,2]  R126      -5.3818099200725555e-02
    z[0,1,2]  R127      -2.5158625841140747e-01
    z[0,1,2]  R128      -2.3679348826408386e-01
    z[0,1,2]  R129      2.6354601606726646e-02
    z[0,1,2]  R130      -1.3988175988197327e-01
    z[0,1,2]  R131      1.6360491514205933e-02
    z[0,1,2]  R132      -2.6247063279151917e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R89       -1
    z[0,1,3]  R90       1
    z[0,1,3]  R97       -2.8663533926010132e-01
    z[0,1,3]  R98       -7.6727020740509033e-01
    z[0,1,3]  R99       -2.9720821976661682e-01
    z[0,1,3]  R100      -4.6246835589408875e-01
    z[0,1,3]  R101      -7.4910408258438110e-01
    z[0,1,3]  R102      1.4437849819660187e-01
    z[0,1,3]  R103      3.9207759499549866e-01
    z[0,1,3]  R104      1.1975728720426559e-01
    z[0,1,3]  R105      2.5175365805625916e-01
    z[0,1,3]  R106      2.1004541218280792e-01
    z[0,1,3]  R107      5.5384886264801025e-01
    z[0,1,3]  R108      2.2122795879840851e-01
    z[0,1,3]  R109      1.2456604093313217e-01
    z[0,1,3]  R110      2.4052891135215759e-01
    z[0,1,3]  R111      2.2559799253940582e-02
    z[0,1,3]  R112      -3.3356092870235443e-02
    z[0,1,3]  R113      4.8845723271369934e-01
    z[0,1,3]  R114      -6.0759127140045166e-01
    z[0,1,3]  R115      -3.8873347640037537e-01
    z[0,1,3]  R116      -1.9432626664638519e-01
    z[0,1,3]  R117      -0.175181582570076
    z[0,1,3]  R118      -2.9513069987297058e-01
    z[0,1,3]  R119      -0.0831599235534668
    z[0,1,3]  R120      -1.7597758769989014e-01
    z[0,1,3]  R121      -5.5355662107467651e-01
    z[0,1,3]  R122      -1.5770237147808075e-01
    z[0,1,3]  R123      3.6064285039901733e-01
    z[0,1,3]  R124      4.2841225862503052e-01
    z[0,1,3]  R125      3.5281065106391907e-01
    z[0,1,3]  R126      -2.0015968382358551e-01
    z[0,1,3]  R127      7.6101320981979370e-01
    z[0,1,3]  R128      -2.2730755805969238e-01
    z[0,1,3]  R129      4.9997620284557343e-02
    z[0,1,3]  R130      -2.5239327549934387e-01
    z[0,1,3]  R131      -2.6964496355503798e-03
    z[0,1,3]  R132      1.1851250380277634e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R91       -1
    z[0,1,4]  R92       1
    z[0,1,4]  R97       -1.2365782260894775e-01
    z[0,1,4]  R98       7.5269125401973724e-02
    z[0,1,4]  R99       1.3593231141567230e-01
    z[0,1,4]  R100      -0.343688428401947
    z[0,1,4]  R101      -0.0699055939912796
    z[0,1,4]  R102      -1.3933452963829041e-01
    z[0,1,4]  R103      -6.0493290424346924e-02
    z[0,1,4]  R104      -5.7243339717388153e-02
    z[0,1,4]  R105      -1.0175827890634537e-01
    z[0,1,4]  R106      2.9869192838668823e-01
    z[0,1,4]  R107      -1.0766943544149399e-01
    z[0,1,4]  R108      1.9593912363052368e-01
    z[0,1,4]  R109      1.2759655714035034e-01
    z[0,1,4]  R110      8.1766790151596069e-01
    z[0,1,4]  R111      2.9254147410392761e-01
    z[0,1,4]  R112      -2.0382346585392952e-02
    z[0,1,4]  R113      -1.7064822837710381e-02
    z[0,1,4]  R114      5.3245973587036133e-01
    z[0,1,4]  R115      7.8416770696640015e-01
    z[0,1,4]  R116      6.6201478242874146e-01
    z[0,1,4]  R117      4.4137087464332581e-01
    z[0,1,4]  R118      5.1038908958435059e-01
    z[0,1,4]  R119      0.350729376077652
    z[0,1,4]  R120      -2.9283556342124939e-01
    z[0,1,4]  R121      6.3868880271911621e-01
    z[0,1,4]  R122      2.5991666316986084e-01
    z[0,1,4]  R123      -2.3611986637115479e-01
    z[0,1,4]  R124      6.2702828645706177e-01
    z[0,1,4]  R125      -2.5449457764625549e-01
    z[0,1,4]  R126      -1.9062182307243347e-01
    z[0,1,4]  R127      -9.2199616134166718e-02
    z[0,1,4]  R128      -4.4130030274391174e-01
    z[0,1,4]  R129      8.2113333046436310e-02
    z[0,1,4]  R130      7.5337424874305725e-02
    z[0,1,4]  R131      2.7578082680702209e-01
    z[0,1,4]  R132      1.5675379335880280e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R93       -1
    z[0,1,5]  R94       1
    z[0,1,5]  R97       -1.4507479965686798e-01
    z[0,1,5]  R98       -9.6735939383506775e-02
    z[0,1,5]  R99       -0.575602114200592
    z[0,1,5]  R100      2.4396726861596107e-02
    z[0,1,5]  R101      4.8044177889823914e-01
    z[0,1,5]  R102      2.7716580033302307e-01
    z[0,1,5]  R103      -1.9671705085784197e-03
    z[0,1,5]  R104      -8.5782044334337115e-04
    z[0,1,5]  R105      3.3683833479881287e-01
    z[0,1,5]  R106      -1.6500061750411987e-01
    z[0,1,5]  R107      -4.8872837424278259e-01
    z[0,1,5]  R108      2.1847733855247498e-01
    z[0,1,5]  R109      -1.5152585506439209e-01
    z[0,1,5]  R110      2.8312146663665771e-01
    z[0,1,5]  R111      -2.1683995425701141e-01
    z[0,1,5]  R112      3.5741943120956421e-01
    z[0,1,5]  R113      -2.3706601932644844e-02
    z[0,1,5]  R114      2.8746696189045906e-02
    z[0,1,5]  R115      1.4385445415973663e-01
    z[0,1,5]  R116      4.0604382753372192e-01
    z[0,1,5]  R117      -9.8630271852016449e-02
    z[0,1,5]  R118      5.5401074886322021e-01
    z[0,1,5]  R119      4.8987871408462524e-01
    z[0,1,5]  R120      1.4435516297817230e-01
    z[0,1,5]  R121      1.3800123333930969e-01
    z[0,1,5]  R122      2.0936714112758636e-01
    z[0,1,5]  R123      -6.4345175027847290e-01
    z[0,1,5]  R124      -3.6098206043243408e-01
    z[0,1,5]  R125      -5.2372545003890991e-01
    z[0,1,5]  R126      -6.7019402980804443e-02
    z[0,1,5]  R127      -1.1411903798580170e-01
    z[0,1,5]  R128      0.676039457321167
    z[0,1,5]  R129      -2.5497004389762878e-01
    z[0,1,5]  R130      4.5900885015726089e-02
    z[0,1,5]  R131      -5.4525250196456909e-01
    z[0,1,5]  R132      5.1757085323333740e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R95       -1
    z[0,1,6]  R96       1
    z[0,1,6]  R97       -3.1910225749015808e-01
    z[0,1,6]  R98       3.8312595337629318e-02
    z[0,1,6]  R99       2.7166712284088135e-01
    z[0,1,6]  R100      7.2592890262603760e-01
    z[0,1,6]  R101      -1.0168961435556412e-01
    z[0,1,6]  R102      -6.5873727202415466e-02
    z[0,1,6]  R103      -1.0057418793439865e-01
    z[0,1,6]  R104      3.6124783754348755e-01
    z[0,1,6]  R105      1.5634240582585335e-02
    z[0,1,6]  R106      -4.1202667355537415e-01
    z[0,1,6]  R107      2.2831596434116364e-01
    z[0,1,6]  R108      -6.6818869113922119e-01
    z[0,1,6]  R109      3.1017127633094788e-01
    z[0,1,6]  R110      0.333430677652359
    z[0,1,6]  R111      -1.1027046293020248e-01
    z[0,1,6]  R112      9.5278814435005188e-02
    z[0,1,6]  R113      1.6459685564041138e-01
    z[0,1,6]  R114      2.5405707955360413e-01
    z[0,1,6]  R115      4.0819738060235977e-02
    z[0,1,6]  R116      -3.4095677733421326e-01
    z[0,1,6]  R117      -1.1056360602378845e-01
    z[0,1,6]  R118      3.9215475320816040e-02
    z[0,1,6]  R119      4.5227214694023132e-02
    z[0,1,6]  R120      2.3558828234672546e-01
    z[0,1,6]  R121      -4.9601322412490845e-01
    z[0,1,6]  R122      3.1735043972730637e-02
    z[0,1,6]  R123      -3.2547584176063538e-01
    z[0,1,6]  R124      1.8699988722801208e-01
    z[0,1,6]  R125      5.8762842416763306e-01
    z[0,1,6]  R126      -3.9328780770301819e-01
    z[0,1,6]  R127      2.0213498175144196e-01
    z[0,1,6]  R128      7.1885332465171814e-02
    z[0,1,6]  R129      4.2138126492500305e-01
    z[0,1,6]  R130      2.5649489834904671e-02
    z[0,1,6]  R131      -2.0541286468505859e-01
    z[0,1,6]  R132      7.4448871612548828e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R133      -1
    z[1,0,0]  R134      1
    z[1,0,0]  R147      6.1115242540836334e-02
    z[1,0,0]  R148      3.4678170084953308e-01
    z[1,0,0]  R149      -3.5861795768141747e-03
    z[1,0,0]  R150      4.4398523867130280e-02
    z[1,0,0]  R151      3.5011547803878784e-01
    z[1,0,0]  R152      2.0817881822586060e-01
    z[1,0,0]  R153      2.9778337478637695e-01
    z[1,0,0]  R154      -6.9507293403148651e-02
    z[1,0,0]  R155      0.0963430106639862
    z[1,0,0]  R156      2.5605884194374084e-01
    z[1,0,0]  R157      -4.7528970241546631e-01
    z[1,0,0]  R158      -4.1346180438995361e-01
    z[1,0,0]  R159      -3.2739189267158508e-01
    z[1,0,0]  R160      -2.5131538510322571e-01
    z[1,0,0]  R161      -4.4437846541404724e-01
    z[1,0,0]  R162      1.7433683574199677e-01
    z[1,0,0]  R163      -4.7088381648063660e-01
    z[1,0,0]  R164      -8.0200988054275513e-01
    z[1,0,0]  R165      -1.2751890718936920e-01
    z[1,0,0]  R166      1.9296426326036453e-02
    z[1,0,0]  R167      1.8577425181865692e-01
    z[1,0,0]  R168      -4.0250238776206970e-01
    z[1,0,0]  R169      5.9304761886596680e-01
    z[1,0,0]  R170      3.3914414048194885e-01
    z[1,0,0]  R171      4.2059165239334106e-01
    z[1,0,0]  R172      0.372530072927475
    z[1,0,0]  R173      0.504259467124939
    z[1,0,0]  R174      -3.6620065569877625e-01
    z[1,0,0]  R175      -4.2994326353073120e-01
    z[1,0,0]  R176      -9.0523689985275269e-02
    z[1,0,0]  R177      -4.3303436040878296e-01
    z[1,0,0]  R178      -3.4408020973205566e-01
    z[1,0,0]  R179      -6.3562989234924316e-01
    z[1,0,0]  R180      0.0958806499838829
    z[1,0,0]  R181      8.1111185252666473e-02
    z[1,0,0]  R182      -1.2107379734516144e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R135      -1
    z[1,0,1]  R136      1
    z[1,0,1]  R147      -0.670496940612793
    z[1,0,1]  R148      1.9411586225032806e-01
    z[1,0,1]  R149      7.3674730956554413e-02
    z[1,0,1]  R150      1.3380122184753418e-01
    z[1,0,1]  R151      1.1019846051931381e-01
    z[1,0,1]  R152      -5.4210770130157471e-01
    z[1,0,1]  R153      0.147373229265213
    z[1,0,1]  R154      -8.3530586957931519e-01
    z[1,0,1]  R155      1.0140072554349899e-01
    z[1,0,1]  R156      -8.3609145879745483e-01
    z[1,0,1]  R157      5.6331526488065720e-02
    z[1,0,1]  R158      -5.4738566279411316e-02
    z[1,0,1]  R159      2.2444877028465271e-01
    z[1,0,1]  R160      0.8356893658638
    z[1,0,1]  R161      3.1258377432823181e-01
    z[1,0,1]  R162      4.5268520712852478e-01
    z[1,0,1]  R163      0.725092887878418
    z[1,0,1]  R164      5.1484996080398560e-01
    z[1,0,1]  R165      7.5360083580017090e-01
    z[1,0,1]  R166      2.6453128457069397e-01
    z[1,0,1]  R167      6.9019153714179993e-02
    z[1,0,1]  R168      8.7127543985843658e-02
    z[1,0,1]  R169      2.9900375008583069e-01
    z[1,0,1]  R170      9.1754212975502014e-02
    z[1,0,1]  R171      9.7815565764904022e-02
    z[1,0,1]  R172      -8.5498660802841187e-01
    z[1,0,1]  R173      -7.6015001535415649e-01
    z[1,0,1]  R174      -8.4713155031204224e-01
    z[1,0,1]  R175      -7.8432118892669678e-01
    z[1,0,1]  R176      -8.1291466951370239e-01
    z[1,0,1]  R177      0.385277658700943
    z[1,0,1]  R178      5.4460048675537109e-01
    z[1,0,1]  R179      5.1341801881790161e-01
    z[1,0,1]  R180      -1.9678102806210518e-02
    z[1,0,1]  R181      -8.9115822315216064e-01
    z[1,0,1]  R182      -9.1251105070114136e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R137      -1
    z[1,0,2]  R138      1
    z[1,0,2]  R147      5.2930426597595215e-01
    z[1,0,2]  R148      3.5214978456497192e-01
    z[1,0,2]  R149      4.5405516028404236e-01
    z[1,0,2]  R150      4.7220396995544434e-01
    z[1,0,2]  R151      7.8601932525634766e-01
    z[1,0,2]  R152      -8.1950798630714417e-02
    z[1,0,2]  R153      7.1948093175888062e-01
    z[1,0,2]  R154      -3.2306644320487976e-01
    z[1,0,2]  R155      3.1845986843109131e-02
    z[1,0,2]  R156      3.1323564052581787e-01
    z[1,0,2]  R157      -2.5523701310157776e-01
    z[1,0,2]  R158      -2.8995606303215027e-01
    z[1,0,2]  R159      -1.8330007791519165e-01
    z[1,0,2]  R160      -5.3818099200725555e-02
    z[1,0,2]  R161      -2.5158625841140747e-01
    z[1,0,2]  R162      -2.3679348826408386e-01
    z[1,0,2]  R163      2.6354601606726646e-02
    z[1,0,2]  R164      -1.3988175988197327e-01
    z[1,0,2]  R165      1.6360491514205933e-02
    z[1,0,2]  R166      -2.6247063279151917e-01
    z[1,0,2]  R167      8.6046516895294189e-01
    z[1,0,2]  R168      4.7455862164497375e-01
    z[1,0,2]  R169      -2.1670293807983398e-01
    z[1,0,2]  R170      1.3036768138408661e-01
    z[1,0,2]  R171      7.9535908997058868e-02
    z[1,0,2]  R172      9.3808054924011230e-02
    z[1,0,2]  R173      -1.9777974113821983e-02
    z[1,0,2]  R174      1.2077989988029003e-02
    z[1,0,2]  R175      1.1202631890773773e-01
    z[1,0,2]  R176      -2.5457123294472694e-02
    z[1,0,2]  R177      2.3391798138618469e-01
    z[1,0,2]  R178      -5.8963544666767120e-02
    z[1,0,2]  R179      -0.425925612449646
    z[1,0,2]  R180      2.6953849196434021e-01
    z[1,0,2]  R181      -2.3235602676868439e-01
    z[1,0,2]  R182      -1.1962404847145081e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R139      -1
    z[1,0,3]  R140      1
    z[1,0,3]  R147      4.8845723271369934e-01
    z[1,0,3]  R148      -6.0759127140045166e-01
    z[1,0,3]  R149      -3.8873347640037537e-01
    z[1,0,3]  R150      -1.9432626664638519e-01
    z[1,0,3]  R151      -0.175181582570076
    z[1,0,3]  R152      -2.9513069987297058e-01
    z[1,0,3]  R153      -0.0831599235534668
    z[1,0,3]  R154      -1.7597758769989014e-01
    z[1,0,3]  R155      -5.5355662107467651e-01
    z[1,0,3]  R156      -1.5770237147808075e-01
    z[1,0,3]  R157      3.6064285039901733e-01
    z[1,0,3]  R158      4.2841225862503052e-01
    z[1,0,3]  R159      3.5281065106391907e-01
    z[1,0,3]  R160      -2.0015968382358551e-01
    z[1,0,3]  R161      7.6101320981979370e-01
    z[1,0,3]  R162      -2.2730755805969238e-01
    z[1,0,3]  R163      4.9997620284557343e-02
    z[1,0,3]  R164      -2.5239327549934387e-01
    z[1,0,3]  R165      -2.6964496355503798e-03
    z[1,0,3]  R166      1.1851250380277634e-01
    z[1,0,3]  R167      -2.8663533926010132e-01
    z[1,0,3]  R168      -7.6727020740509033e-01
    z[1,0,3]  R169      -2.9720821976661682e-01
    z[1,0,3]  R170      -4.6246835589408875e-01
    z[1,0,3]  R171      -7.4910408258438110e-01
    z[1,0,3]  R172      1.4437849819660187e-01
    z[1,0,3]  R173      3.9207759499549866e-01
    z[1,0,3]  R174      1.1975728720426559e-01
    z[1,0,3]  R175      2.5175365805625916e-01
    z[1,0,3]  R176      2.1004541218280792e-01
    z[1,0,3]  R177      5.5384886264801025e-01
    z[1,0,3]  R178      2.2122795879840851e-01
    z[1,0,3]  R179      1.2456604093313217e-01
    z[1,0,3]  R180      2.4052891135215759e-01
    z[1,0,3]  R181      2.2559799253940582e-02
    z[1,0,3]  R182      -3.3356092870235443e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R141      -1
    z[1,0,4]  R142      1
    z[1,0,4]  R147      -1.7064822837710381e-02
    z[1,0,4]  R148      5.3245973587036133e-01
    z[1,0,4]  R149      7.8416770696640015e-01
    z[1,0,4]  R150      6.6201478242874146e-01
    z[1,0,4]  R151      4.4137087464332581e-01
    z[1,0,4]  R152      5.1038908958435059e-01
    z[1,0,4]  R153      0.350729376077652
    z[1,0,4]  R154      -2.9283556342124939e-01
    z[1,0,4]  R155      6.3868880271911621e-01
    z[1,0,4]  R156      2.5991666316986084e-01
    z[1,0,4]  R157      -2.3611986637115479e-01
    z[1,0,4]  R158      6.2702828645706177e-01
    z[1,0,4]  R159      -2.5449457764625549e-01
    z[1,0,4]  R160      -1.9062182307243347e-01
    z[1,0,4]  R161      -9.2199616134166718e-02
    z[1,0,4]  R162      -4.4130030274391174e-01
    z[1,0,4]  R163      8.2113333046436310e-02
    z[1,0,4]  R164      7.5337424874305725e-02
    z[1,0,4]  R165      2.7578082680702209e-01
    z[1,0,4]  R166      1.5675379335880280e-01
    z[1,0,4]  R167      -1.2365782260894775e-01
    z[1,0,4]  R168      7.5269125401973724e-02
    z[1,0,4]  R169      1.3593231141567230e-01
    z[1,0,4]  R170      -0.343688428401947
    z[1,0,4]  R171      -0.0699055939912796
    z[1,0,4]  R172      -1.3933452963829041e-01
    z[1,0,4]  R173      -6.0493290424346924e-02
    z[1,0,4]  R174      -5.7243339717388153e-02
    z[1,0,4]  R175      -1.0175827890634537e-01
    z[1,0,4]  R176      2.9869192838668823e-01
    z[1,0,4]  R177      -1.0766943544149399e-01
    z[1,0,4]  R178      1.9593912363052368e-01
    z[1,0,4]  R179      1.2759655714035034e-01
    z[1,0,4]  R180      8.1766790151596069e-01
    z[1,0,4]  R181      2.9254147410392761e-01
    z[1,0,4]  R182      -2.0382346585392952e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R143      -1
    z[1,0,5]  R144      1
    z[1,0,5]  R147      -2.3706601932644844e-02
    z[1,0,5]  R148      2.8746696189045906e-02
    z[1,0,5]  R149      1.4385445415973663e-01
    z[1,0,5]  R150      4.0604382753372192e-01
    z[1,0,5]  R151      -9.8630271852016449e-02
    z[1,0,5]  R152      5.5401074886322021e-01
    z[1,0,5]  R153      4.8987871408462524e-01
    z[1,0,5]  R154      1.4435516297817230e-01
    z[1,0,5]  R155      1.3800123333930969e-01
    z[1,0,5]  R156      2.0936714112758636e-01
    z[1,0,5]  R157      -6.4345175027847290e-01
    z[1,0,5]  R158      -3.6098206043243408e-01
    z[1,0,5]  R159      -5.2372545003890991e-01
    z[1,0,5]  R160      -6.7019402980804443e-02
    z[1,0,5]  R161      -1.1411903798580170e-01
    z[1,0,5]  R162      0.676039457321167
    z[1,0,5]  R163      -2.5497004389762878e-01
    z[1,0,5]  R164      4.5900885015726089e-02
    z[1,0,5]  R165      -5.4525250196456909e-01
    z[1,0,5]  R166      5.1757085323333740e-01
    z[1,0,5]  R167      -1.4507479965686798e-01
    z[1,0,5]  R168      -9.6735939383506775e-02
    z[1,0,5]  R169      -0.575602114200592
    z[1,0,5]  R170      2.4396726861596107e-02
    z[1,0,5]  R171      4.8044177889823914e-01
    z[1,0,5]  R172      2.7716580033302307e-01
    z[1,0,5]  R173      -1.9671705085784197e-03
    z[1,0,5]  R174      -8.5782044334337115e-04
    z[1,0,5]  R175      3.3683833479881287e-01
    z[1,0,5]  R176      -1.6500061750411987e-01
    z[1,0,5]  R177      -4.8872837424278259e-01
    z[1,0,5]  R178      2.1847733855247498e-01
    z[1,0,5]  R179      -1.5152585506439209e-01
    z[1,0,5]  R180      2.8312146663665771e-01
    z[1,0,5]  R181      -2.1683995425701141e-01
    z[1,0,5]  R182      3.5741943120956421e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R145      -1
    z[1,0,6]  R146      1
    z[1,0,6]  R147      1.6459685564041138e-01
    z[1,0,6]  R148      2.5405707955360413e-01
    z[1,0,6]  R149      4.0819738060235977e-02
    z[1,0,6]  R150      -3.4095677733421326e-01
    z[1,0,6]  R151      -1.1056360602378845e-01
    z[1,0,6]  R152      3.9215475320816040e-02
    z[1,0,6]  R153      4.5227214694023132e-02
    z[1,0,6]  R154      2.3558828234672546e-01
    z[1,0,6]  R155      -4.9601322412490845e-01
    z[1,0,6]  R156      3.1735043972730637e-02
    z[1,0,6]  R157      -3.2547584176063538e-01
    z[1,0,6]  R158      1.8699988722801208e-01
    z[1,0,6]  R159      5.8762842416763306e-01
    z[1,0,6]  R160      -3.9328780770301819e-01
    z[1,0,6]  R161      2.0213498175144196e-01
    z[1,0,6]  R162      7.1885332465171814e-02
    z[1,0,6]  R163      4.2138126492500305e-01
    z[1,0,6]  R164      2.5649489834904671e-02
    z[1,0,6]  R165      -2.0541286468505859e-01
    z[1,0,6]  R166      7.4448871612548828e-01
    z[1,0,6]  R167      -3.1910225749015808e-01
    z[1,0,6]  R168      3.8312595337629318e-02
    z[1,0,6]  R169      2.7166712284088135e-01
    z[1,0,6]  R170      7.2592890262603760e-01
    z[1,0,6]  R171      -1.0168961435556412e-01
    z[1,0,6]  R172      -6.5873727202415466e-02
    z[1,0,6]  R173      -1.0057418793439865e-01
    z[1,0,6]  R174      3.6124783754348755e-01
    z[1,0,6]  R175      1.5634240582585335e-02
    z[1,0,6]  R176      -4.1202667355537415e-01
    z[1,0,6]  R177      2.2831596434116364e-01
    z[1,0,6]  R178      -6.6818869113922119e-01
    z[1,0,6]  R179      3.1017127633094788e-01
    z[1,0,6]  R180      0.333430677652359
    z[1,0,6]  R181      -1.1027046293020248e-01
    z[1,0,6]  R182      9.5278814435005188e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R183      -1
    z[0,4,0]  R184      1
    z[0,4,0]  R197      1.8577425181865692e-01
    z[0,4,0]  R198      -4.0250238776206970e-01
    z[0,4,0]  R199      5.9304761886596680e-01
    z[0,4,0]  R200      3.3914414048194885e-01
    z[0,4,0]  R201      4.2059165239334106e-01
    z[0,4,0]  R202      0.372530072927475
    z[0,4,0]  R203      0.504259467124939
    z[0,4,0]  R204      -3.6620065569877625e-01
    z[0,4,0]  R205      -4.2994326353073120e-01
    z[0,4,0]  R206      -9.0523689985275269e-02
    z[0,4,0]  R207      -4.3303436040878296e-01
    z[0,4,0]  R208      -3.4408020973205566e-01
    z[0,4,0]  R209      -6.3562989234924316e-01
    z[0,4,0]  R210      0.0958806499838829
    z[0,4,0]  R211      8.1111185252666473e-02
    z[0,4,0]  R212      -1.2107379734516144e-01
    z[0,4,0]  R213      2.6317232847213745e-01
    z[0,4,0]  R214      -5.6546837091445923e-01
    z[0,4,0]  R215      -6.6512620449066162e-01
    z[0,4,0]  R216      -5.9499043226242065e-01
    z[0,4,0]  R217      -4.7558397054672241e-01
    z[0,4,0]  R218      -2.8419154882431030e-01
    z[0,4,0]  R219      -5.2697896957397461e-01
    z[0,4,0]  R220      -5.0199301913380623e-03
    z[0,4,0]  R221      -2.8651875257492065e-01
    z[0,4,0]  R222      -7.7887797355651855e-01
    z[0,4,0]  R223      4.0775316953659058e-01
    z[0,4,0]  R224      2.7798458933830261e-01
    z[0,4,0]  R225      9.0594850480556488e-02
    z[0,4,0]  R226      2.7893108129501343e-01
    z[0,4,0]  R227      1.4825348556041718e-01
    z[0,4,0]  R228      5.2443629503250122e-01
    z[0,4,0]  R229      2.9940828680992126e-01
    z[0,4,0]  R230      2.7604022622108459e-01
    z[0,4,0]  R231      8.0869764089584351e-02
    z[0,4,0]  R232      -1.1270183324813843e-01
    z[0,4,0]  R233      -2.1888931095600128e-01
    z[0,4,0]  R234      4.2094182223081589e-02
    z[0,4,0]  R235      -7.5227484107017517e-02
    z[0,4,0]  R236      -2.0039016008377075e-01
    z[0,4,0]  R237      -4.2725026607513428e-01
    z[0,4,0]  R238      -1.2496877461671829e-01
    z[0,4,0]  R239      1.1946169286966324e-01
    z[0,4,0]  R240      1.1976820975542068e-01
    z[0,4,0]  R241      -1.6199196875095367e-01
    z[0,4,0]  R242      -1.8205009400844574e-01
    z[0,4,0]  R243      2.9029405117034912e-01
    z[0,4,0]  R244      2.1191759407520294e-01
    z[0,4,0]  R245      0.0979313850402832
    z[0,4,0]  R246      3.6537414789199829e-01
    z[0,4,0]  R247      5.7950496673583984e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R185      -1
    z[0,4,1]  R186      1
    z[0,4,1]  R197      6.9019153714179993e-02
    z[0,4,1]  R198      8.7127543985843658e-02
    z[0,4,1]  R199      2.9900375008583069e-01
    z[0,4,1]  R200      9.1754212975502014e-02
    z[0,4,1]  R201      9.7815565764904022e-02
    z[0,4,1]  R202      -8.5498660802841187e-01
    z[0,4,1]  R203      -7.6015001535415649e-01
    z[0,4,1]  R204      -8.4713155031204224e-01
    z[0,4,1]  R205      -7.8432118892669678e-01
    z[0,4,1]  R206      -8.1291466951370239e-01
    z[0,4,1]  R207      0.385277658700943
    z[0,4,1]  R208      5.4460048675537109e-01
    z[0,4,1]  R209      5.1341801881790161e-01
    z[0,4,1]  R210      -1.9678102806210518e-02
    z[0,4,1]  R211      -8.9115822315216064e-01
    z[0,4,1]  R212      -9.1251105070114136e-01
    z[0,4,1]  R213      2.1415875852108002e-01
    z[0,4,1]  R214      3.3031871914863586e-01
    z[0,4,1]  R215      -0.579989492893219
    z[0,4,1]  R216      -0.738753080368042
    z[0,4,1]  R217      -7.4549549818038940e-01
    z[0,4,1]  R218      -9.0103352069854736e-01
    z[0,4,1]  R219      -7.6249200105667114e-01
    z[0,4,1]  R220      2.0877319574356079e-01
    z[0,4,1]  R221      -8.0265545845031738e-01
    z[0,4,1]  R222      -4.4744989275932312e-01
    z[0,4,1]  R223      6.5953671932220459e-01
    z[0,4,1]  R224      2.9075467586517334e-01
    z[0,4,1]  R225      5.1141297817230225e-01
    z[0,4,1]  R226      2.3910698294639587e-01
    z[0,4,1]  R227      2.7770560979843140e-01
    z[0,4,1]  R228      5.9006351232528687e-01
    z[0,4,1]  R229      5.5754226446151733e-01
    z[0,4,1]  R230      1.9369617104530334e-01
    z[0,4,1]  R231      1.4462156593799591e-01
    z[0,4,1]  R232      4.5790910720825195e-01
    z[0,4,1]  R233      8.1007617712020874e-01
    z[0,4,1]  R234      5.4744428396224976e-01
    z[0,4,1]  R235      4.1722071170806885e-01
    z[0,4,1]  R236      8.8161730766296387e-01
    z[0,4,1]  R237      6.3271081447601318e-01
    z[0,4,1]  R238      5.9155243635177612e-01
    z[0,4,1]  R239      4.8234167695045471e-01
    z[0,4,1]  R240      6.7794388532638550e-01
    z[0,4,1]  R241      5.4521161317825317e-01
    z[0,4,1]  R242      3.8384035229682922e-01
    z[0,4,1]  R243      0.844523549079895
    z[0,4,1]  R244      7.4751389026641846e-01
    z[0,4,1]  R245      4.5838546752929688e-01
    z[0,4,1]  R246      5.1698708534240723e-01
    z[0,4,1]  R247      -5.3574711084365845e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R187      -1
    z[0,4,2]  R188      1
    z[0,4,2]  R197      8.6046516895294189e-01
    z[0,4,2]  R198      4.7455862164497375e-01
    z[0,4,2]  R199      -2.1670293807983398e-01
    z[0,4,2]  R200      1.3036768138408661e-01
    z[0,4,2]  R201      7.9535908997058868e-02
    z[0,4,2]  R202      9.3808054924011230e-02
    z[0,4,2]  R203      -1.9777974113821983e-02
    z[0,4,2]  R204      1.2077989988029003e-02
    z[0,4,2]  R205      1.1202631890773773e-01
    z[0,4,2]  R206      -2.5457123294472694e-02
    z[0,4,2]  R207      2.3391798138618469e-01
    z[0,4,2]  R208      -5.8963544666767120e-02
    z[0,4,2]  R209      -0.425925612449646
    z[0,4,2]  R210      2.6953849196434021e-01
    z[0,4,2]  R211      -2.3235602676868439e-01
    z[0,4,2]  R212      -1.1962404847145081e-01
    z[0,4,2]  R213      6.6612499952316284e-01
    z[0,4,2]  R214      3.2712161540985107e-01
    z[0,4,2]  R215      0.36520916223526
    z[0,4,2]  R216      6.0635735280811787e-03
    z[0,4,2]  R217      3.8577702641487122e-01
    z[0,4,2]  R218      1.3701667077839375e-02
    z[0,4,2]  R219      -1.9621748477220535e-02
    z[0,4,2]  R220      4.8134312033653259e-01
    z[0,4,2]  R221      -1.3301129639148712e-01
    z[0,4,2]  R222      2.1512357890605927e-01
    z[0,4,2]  R223      -9.3196697533130646e-02
    z[0,4,2]  R224      2.8650718927383423e-01
    z[0,4,2]  R225      -1.9951665401458740e-01
    z[0,4,2]  R226      3.5323369503021240e-01
    z[0,4,2]  R227      -9.4967454671859741e-02
    z[0,4,2]  R228      2.1584048867225647e-01
    z[0,4,2]  R229      1.6235182061791420e-02
    z[0,4,2]  R230      1.6828076541423798e-01
    z[0,4,2]  R231      1.4500774443149567e-01
    z[0,4,2]  R232      -2.5203108787536621e-01
    z[0,4,2]  R233      1.9131980836391449e-01
    z[0,4,2]  R234      -2.5324690341949463e-01
    z[0,4,2]  R235      4.5704704523086548e-01
    z[0,4,2]  R236      3.6697588860988617e-02
    z[0,4,2]  R237      1.5689401328563690e-01
    z[0,4,2]  R238      6.6139960289001465e-01
    z[0,4,2]  R239      5.4390519857406616e-01
    z[0,4,2]  R240      0.560393214225769
    z[0,4,2]  R241      3.9219895005226135e-01
    z[0,4,2]  R242      2.2104445099830627e-01
    z[0,4,2]  R243      -1.7613707482814789e-01
    z[0,4,2]  R244      1.2199211120605469e-01
    z[0,4,2]  R245      3.3063071966171265e-01
    z[0,4,2]  R246      -2.1118113398551941e-01
    z[0,4,2]  R247      -4.3785148859024048e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R189      -1
    z[0,4,3]  R190      1
    z[0,4,3]  R197      -2.8663533926010132e-01
    z[0,4,3]  R198      -7.6727020740509033e-01
    z[0,4,3]  R199      -2.9720821976661682e-01
    z[0,4,3]  R200      -4.6246835589408875e-01
    z[0,4,3]  R201      -7.4910408258438110e-01
    z[0,4,3]  R202      1.4437849819660187e-01
    z[0,4,3]  R203      3.9207759499549866e-01
    z[0,4,3]  R204      1.1975728720426559e-01
    z[0,4,3]  R205      2.5175365805625916e-01
    z[0,4,3]  R206      2.1004541218280792e-01
    z[0,4,3]  R207      5.5384886264801025e-01
    z[0,4,3]  R208      2.2122795879840851e-01
    z[0,4,3]  R209      1.2456604093313217e-01
    z[0,4,3]  R210      2.4052891135215759e-01
    z[0,4,3]  R211      2.2559799253940582e-02
    z[0,4,3]  R212      -3.3356092870235443e-02
    z[0,4,3]  R213      6.1507642269134521e-01
    z[0,4,3]  R214      4.4686588644981384e-01
    z[0,4,3]  R215      2.5985551998019218e-02
    z[0,4,3]  R216      0.0774635300040245
    z[0,4,3]  R217      1.2837946414947510e-01
    z[0,4,3]  R218      1.4763016998767853e-01
    z[0,4,3]  R219      -1.1432129889726639e-01
    z[0,4,3]  R220      4.8429793119430542e-01
    z[0,4,3]  R221      2.5366386771202087e-01
    z[0,4,3]  R222      -3.6661627888679504e-01
    z[0,4,3]  R223      -0.264119416475296
    z[0,4,3]  R224      -2.6760128140449524e-01
    z[0,4,3]  R225      -1.6713038086891174e-01
    z[0,4,3]  R226      -7.0014017820358276e-01
    z[0,4,3]  R227      -7.4978643655776978e-01
    z[0,4,3]  R228      -3.5778027772903442e-01
    z[0,4,3]  R229      -4.2110189795494080e-01
    z[0,4,3]  R230      -6.3382244110107422e-01
    z[0,4,3]  R231      -4.4403409957885742e-01
    z[0,4,3]  R232      -3.7899157404899597e-01
    z[0,4,3]  R233      -1.3485260307788849e-02
    z[0,4,3]  R234      -5.0639325380325317e-01
    z[0,4,3]  R235      -1.9734393060207367e-01
    z[0,4,3]  R236      -2.1550129354000092e-01
    z[0,4,3]  R237      -5.9948104619979858e-01
    z[0,4,3]  R238      -1.1764326132833958e-02
    z[0,4,3]  R239      0.564063310623169
    z[0,4,3]  R240      -1.0873633623123169e-01
    z[0,4,3]  R241      4.2686897516250610e-01
    z[0,4,3]  R242      -6.5339082479476929e-01
    z[0,4,3]  R243      1.5900303423404694e-01
    z[0,4,3]  R244      -2.5881990790367126e-02
    z[0,4,3]  R245      -7.0459538698196411e-01
    z[0,4,3]  R246      -3.7491348385810852e-01
    z[0,4,3]  R247      -2.7145528793334961e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R191      -1
    z[0,4,4]  R192      1
    z[0,4,4]  R197      -1.2365782260894775e-01
    z[0,4,4]  R198      7.5269125401973724e-02
    z[0,4,4]  R199      1.3593231141567230e-01
    z[0,4,4]  R200      -0.343688428401947
    z[0,4,4]  R201      -0.0699055939912796
    z[0,4,4]  R202      -1.3933452963829041e-01
    z[0,4,4]  R203      -6.0493290424346924e-02
    z[0,4,4]  R204      -5.7243339717388153e-02
    z[0,4,4]  R205      -1.0175827890634537e-01
    z[0,4,4]  R206      2.9869192838668823e-01
    z[0,4,4]  R207      -1.0766943544149399e-01
    z[0,4,4]  R208      1.9593912363052368e-01
    z[0,4,4]  R209      1.2759655714035034e-01
    z[0,4,4]  R210      8.1766790151596069e-01
    z[0,4,4]  R211      2.9254147410392761e-01
    z[0,4,4]  R212      -2.0382346585392952e-02
    z[0,4,4]  R213      1.1974767595529556e-01
    z[0,4,4]  R214      9.1862939298152924e-03
    z[0,4,4]  R215      7.3491334915161133e-02
    z[0,4,4]  R216      -5.8846427127718925e-03
    z[0,4,4]  R217      -1.6747325658798218e-01
    z[0,4,4]  R218      -1.3405182398855686e-03
    z[0,4,4]  R219      2.5259381532669067e-01
    z[0,4,4]  R220      -2.1315573155879974e-01
    z[0,4,4]  R221      3.2217299938201904e-01
    z[0,4,4]  R222      5.4563339799642563e-02
    z[0,4,4]  R223      -1.9892422854900360e-01
    z[0,4,4]  R224      -6.7497217655181885e-01
    z[0,4,4]  R225      0.788306474685669
    z[0,4,4]  R226      -4.4945013523101807e-01
    z[0,4,4]  R227      -2.1735686063766479e-01
    z[0,4,4]  R228      -2.3181030154228210e-01
    z[0,4,4]  R229      5.2764439582824707e-01
    z[0,4,4]  R230      -1.1529266089200974e-01
    z[0,4,4]  R231      -4.5612469315528870e-01
    z[0,4,4]  R232      2.4645689129829407e-01
    z[0,4,4]  R233      -3.4443697333335876e-01
    z[0,4,4]  R234      -4.1347879171371460e-01
    z[0,4,4]  R235      -6.9526904821395874e-01
    z[0,4,4]  R236      1.8194644153118134e-01
    z[0,4,4]  R237      8.0386392772197723e-02
    z[0,4,4]  R238      -3.9396342635154724e-01
    z[0,4,4]  R239      -2.4239769577980042e-01
    z[0,4,4]  R240      -1.4636828005313873e-01
    z[0,4,4]  R241      2.6185914874076843e-01
    z[0,4,4]  R242      1.6176441311836243e-01
    z[0,4,4]  R243      1.8638296052813530e-02
    z[0,4,4]  R244      2.1074400842189789e-01
    z[0,4,4]  R245      -1.7241697013378143e-01
    z[0,4,4]  R246      3.6345225572586060e-01
    z[0,4,4]  R247      -2.9684737324714661e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R193      -1
    z[0,4,5]  R194      1
    z[0,4,5]  R197      -1.4507479965686798e-01
    z[0,4,5]  R198      -9.6735939383506775e-02
    z[0,4,5]  R199      -0.575602114200592
    z[0,4,5]  R200      2.4396726861596107e-02
    z[0,4,5]  R201      4.8044177889823914e-01
    z[0,4,5]  R202      2.7716580033302307e-01
    z[0,4,5]  R203      -1.9671705085784197e-03
    z[0,4,5]  R204      -8.5782044334337115e-04
    z[0,4,5]  R205      3.3683833479881287e-01
    z[0,4,5]  R206      -1.6500061750411987e-01
    z[0,4,5]  R207      -4.8872837424278259e-01
    z[0,4,5]  R208      2.1847733855247498e-01
    z[0,4,5]  R209      -1.5152585506439209e-01
    z[0,4,5]  R210      2.8312146663665771e-01
    z[0,4,5]  R211      -2.1683995425701141e-01
    z[0,4,5]  R212      3.5741943120956421e-01
    z[0,4,5]  R213      1.9912265241146088e-01
    z[0,4,5]  R214      4.6489837765693665e-01
    z[0,4,5]  R215      1.7913137376308441e-01
    z[0,4,5]  R216      1.4583170413970947e-01
    z[0,4,5]  R217      -1.5650568902492523e-01
    z[0,4,5]  R218      2.6274496316909790e-01
    z[0,4,5]  R219      1.2872308492660522e-01
    z[0,4,5]  R220      3.1005263328552246e-01
    z[0,4,5]  R221      -2.4613271653652191e-01
    z[0,4,5]  R222      -7.7008586376905441e-03
    z[0,4,5]  R223      5.2982527017593384e-01
    z[0,4,5]  R224      -4.3148615956306458e-01
    z[0,4,5]  R225      1.3492126762866974e-01
    z[0,4,5]  R226      -1.5359036624431610e-01
    z[0,4,5]  R227      -4.3180957436561584e-01
    z[0,4,5]  R228      -3.0500459671020508e-01
    z[0,4,5]  R229      -0.306742787361145
    z[0,4,5]  R230      -4.3126323819160461e-01
    z[0,4,5]  R231      -2.4748770892620087e-01
    z[0,4,5]  R232      -1.0798367857933044e-01
    z[0,4,5]  R233      -3.5758325457572937e-01
    z[0,4,5]  R234      -4.5182332396507263e-01
    z[0,4,5]  R235      1.2278459221124649e-01
    z[0,4,5]  R236      -2.3089537024497986e-01
    z[0,4,5]  R237      -6.4779542386531830e-02
    z[0,4,5]  R238      -1.6605409979820251e-01
    z[0,4,5]  R239      -0.283381849527359
    z[0,4,5]  R240      -2.8153559565544128e-01
    z[0,4,5]  R241      -4.6473595499992371e-01
    z[0,4,5]  R242      -5.0197279453277588e-01
    z[0,4,5]  R243      -1.4717520773410797e-01
    z[0,4,5]  R244      2.8738099336624146e-01
    z[0,4,5]  R245      0.093800388276577
    z[0,4,5]  R246      -2.8256615996360779e-01
    z[0,4,5]  R247      0.0650511384010315
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R195      -1
    z[0,4,6]  R196      1
    z[0,4,6]  R197      -3.1910225749015808e-01
    z[0,4,6]  R198      3.8312595337629318e-02
    z[0,4,6]  R199      2.7166712284088135e-01
    z[0,4,6]  R200      7.2592890262603760e-01
    z[0,4,6]  R201      -1.0168961435556412e-01
    z[0,4,6]  R202      -6.5873727202415466e-02
    z[0,4,6]  R203      -1.0057418793439865e-01
    z[0,4,6]  R204      3.6124783754348755e-01
    z[0,4,6]  R205      1.5634240582585335e-02
    z[0,4,6]  R206      -4.1202667355537415e-01
    z[0,4,6]  R207      2.2831596434116364e-01
    z[0,4,6]  R208      -6.6818869113922119e-01
    z[0,4,6]  R209      3.1017127633094788e-01
    z[0,4,6]  R210      0.333430677652359
    z[0,4,6]  R211      -1.1027046293020248e-01
    z[0,4,6]  R212      9.5278814435005188e-02
    z[0,4,6]  R213      9.4051003456115723e-02
    z[0,4,6]  R214      2.1959602832794189e-01
    z[0,4,6]  R215      -2.2288376092910767e-01
    z[0,4,6]  R216      2.6998394727706909e-01
    z[0,4,6]  R217      1.4485952444374561e-02
    z[0,4,6]  R218      -1.2788560986518860e-01
    z[0,4,6]  R219      -2.1695968508720398e-01
    z[0,4,6]  R220      5.9041076898574829e-01
    z[0,4,6]  R221      -1.6503702104091644e-01
    z[0,4,6]  R222      9.7034208476543427e-02
    z[0,4,6]  R223      4.2760372161865234e-03
    z[0,4,6]  R224      2.0669229328632355e-01
    z[0,4,6]  R225      1.5125776827335358e-01
    z[0,4,6]  R226      -1.5639545023441315e-01
    z[0,4,6]  R227      3.0983600020408630e-01
    z[0,4,6]  R228      -2.3544387519359589e-01
    z[0,4,6]  R229      2.2228620946407318e-01
    z[0,4,6]  R230      -5.0690621137619019e-01
    z[0,4,6]  R231      -6.9645619392395020e-01
    z[0,4,6]  R232      -0.70573490858078
    z[0,4,6]  R233      -1.1214417964220047e-01
    z[0,4,6]  R234      5.3438387811183929e-02
    z[0,4,6]  R235      -2.7194821834564209e-01
    z[0,4,6]  R236      2.1997734904289246e-01
    z[0,4,6]  R237      1.4994235336780548e-01
    z[0,4,6]  R238      1.1865685880184174e-01
    z[0,4,6]  R239      3.6452680360525846e-03
    z[0,4,6]  R240      -3.1543239951133728e-01
    z[0,4,6]  R241      -2.3646588623523712e-01
    z[0,4,6]  R242      -2.5612443685531616e-01
    z[0,4,6]  R243      3.5241311788558960e-01
    z[0,4,6]  R244      -5.0374704599380493e-01
    z[0,4,6]  R245      -3.6877453327178955e-01
    z[0,4,6]  R246      -4.4958570599555969e-01
    z[0,4,6]  R247      1.3927395641803741e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R248      -1
    z[4,0,0]  R249      1
    z[4,0,0]  R262      2.6317232847213745e-01
    z[4,0,0]  R263      -5.6546837091445923e-01
    z[4,0,0]  R264      -6.6512620449066162e-01
    z[4,0,0]  R265      -5.9499043226242065e-01
    z[4,0,0]  R266      -4.7558397054672241e-01
    z[4,0,0]  R267      -2.8419154882431030e-01
    z[4,0,0]  R268      -5.2697896957397461e-01
    z[4,0,0]  R269      -5.0199301913380623e-03
    z[4,0,0]  R270      -2.8651875257492065e-01
    z[4,0,0]  R271      -7.7887797355651855e-01
    z[4,0,0]  R272      4.0775316953659058e-01
    z[4,0,0]  R273      2.7798458933830261e-01
    z[4,0,0]  R274      9.0594850480556488e-02
    z[4,0,0]  R275      2.7893108129501343e-01
    z[4,0,0]  R276      1.4825348556041718e-01
    z[4,0,0]  R277      5.2443629503250122e-01
    z[4,0,0]  R278      2.9940828680992126e-01
    z[4,0,0]  R279      2.7604022622108459e-01
    z[4,0,0]  R280      8.0869764089584351e-02
    z[4,0,0]  R281      -1.1270183324813843e-01
    z[4,0,0]  R282      -2.1888931095600128e-01
    z[4,0,0]  R283      4.2094182223081589e-02
    z[4,0,0]  R284      -7.5227484107017517e-02
    z[4,0,0]  R285      -2.0039016008377075e-01
    z[4,0,0]  R286      -4.2725026607513428e-01
    z[4,0,0]  R287      -1.2496877461671829e-01
    z[4,0,0]  R288      1.1946169286966324e-01
    z[4,0,0]  R289      1.1976820975542068e-01
    z[4,0,0]  R290      -1.6199196875095367e-01
    z[4,0,0]  R291      -1.8205009400844574e-01
    z[4,0,0]  R292      2.9029405117034912e-01
    z[4,0,0]  R293      2.1191759407520294e-01
    z[4,0,0]  R294      0.0979313850402832
    z[4,0,0]  R295      3.6537414789199829e-01
    z[4,0,0]  R296      5.7950496673583984e-01
    z[4,0,0]  R297      1.8577425181865692e-01
    z[4,0,0]  R298      -4.0250238776206970e-01
    z[4,0,0]  R299      5.9304761886596680e-01
    z[4,0,0]  R300      3.3914414048194885e-01
    z[4,0,0]  R301      4.2059165239334106e-01
    z[4,0,0]  R302      0.372530072927475
    z[4,0,0]  R303      0.504259467124939
    z[4,0,0]  R304      -3.6620065569877625e-01
    z[4,0,0]  R305      -4.2994326353073120e-01
    z[4,0,0]  R306      -9.0523689985275269e-02
    z[4,0,0]  R307      -4.3303436040878296e-01
    z[4,0,0]  R308      -3.4408020973205566e-01
    z[4,0,0]  R309      -6.3562989234924316e-01
    z[4,0,0]  R310      0.0958806499838829
    z[4,0,0]  R311      8.1111185252666473e-02
    z[4,0,0]  R312      -1.2107379734516144e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R250      -1
    z[4,0,1]  R251      1
    z[4,0,1]  R262      2.1415875852108002e-01
    z[4,0,1]  R263      3.3031871914863586e-01
    z[4,0,1]  R264      -0.579989492893219
    z[4,0,1]  R265      -0.738753080368042
    z[4,0,1]  R266      -7.4549549818038940e-01
    z[4,0,1]  R267      -9.0103352069854736e-01
    z[4,0,1]  R268      -7.6249200105667114e-01
    z[4,0,1]  R269      2.0877319574356079e-01
    z[4,0,1]  R270      -8.0265545845031738e-01
    z[4,0,1]  R271      -4.4744989275932312e-01
    z[4,0,1]  R272      6.5953671932220459e-01
    z[4,0,1]  R273      2.9075467586517334e-01
    z[4,0,1]  R274      5.1141297817230225e-01
    z[4,0,1]  R275      2.3910698294639587e-01
    z[4,0,1]  R276      2.7770560979843140e-01
    z[4,0,1]  R277      5.9006351232528687e-01
    z[4,0,1]  R278      5.5754226446151733e-01
    z[4,0,1]  R279      1.9369617104530334e-01
    z[4,0,1]  R280      1.4462156593799591e-01
    z[4,0,1]  R281      4.5790910720825195e-01
    z[4,0,1]  R282      8.1007617712020874e-01
    z[4,0,1]  R283      5.4744428396224976e-01
    z[4,0,1]  R284      4.1722071170806885e-01
    z[4,0,1]  R285      8.8161730766296387e-01
    z[4,0,1]  R286      6.3271081447601318e-01
    z[4,0,1]  R287      5.9155243635177612e-01
    z[4,0,1]  R288      4.8234167695045471e-01
    z[4,0,1]  R289      6.7794388532638550e-01
    z[4,0,1]  R290      5.4521161317825317e-01
    z[4,0,1]  R291      3.8384035229682922e-01
    z[4,0,1]  R292      0.844523549079895
    z[4,0,1]  R293      7.4751389026641846e-01
    z[4,0,1]  R294      4.5838546752929688e-01
    z[4,0,1]  R295      5.1698708534240723e-01
    z[4,0,1]  R296      -5.3574711084365845e-01
    z[4,0,1]  R297      6.9019153714179993e-02
    z[4,0,1]  R298      8.7127543985843658e-02
    z[4,0,1]  R299      2.9900375008583069e-01
    z[4,0,1]  R300      9.1754212975502014e-02
    z[4,0,1]  R301      9.7815565764904022e-02
    z[4,0,1]  R302      -8.5498660802841187e-01
    z[4,0,1]  R303      -7.6015001535415649e-01
    z[4,0,1]  R304      -8.4713155031204224e-01
    z[4,0,1]  R305      -7.8432118892669678e-01
    z[4,0,1]  R306      -8.1291466951370239e-01
    z[4,0,1]  R307      0.385277658700943
    z[4,0,1]  R308      5.4460048675537109e-01
    z[4,0,1]  R309      5.1341801881790161e-01
    z[4,0,1]  R310      -1.9678102806210518e-02
    z[4,0,1]  R311      -8.9115822315216064e-01
    z[4,0,1]  R312      -9.1251105070114136e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R252      -1
    z[4,0,2]  R253      1
    z[4,0,2]  R262      6.6612499952316284e-01
    z[4,0,2]  R263      3.2712161540985107e-01
    z[4,0,2]  R264      0.36520916223526
    z[4,0,2]  R265      6.0635735280811787e-03
    z[4,0,2]  R266      3.8577702641487122e-01
    z[4,0,2]  R267      1.3701667077839375e-02
    z[4,0,2]  R268      -1.9621748477220535e-02
    z[4,0,2]  R269      4.8134312033653259e-01
    z[4,0,2]  R270      -1.3301129639148712e-01
    z[4,0,2]  R271      2.1512357890605927e-01
    z[4,0,2]  R272      -9.3196697533130646e-02
    z[4,0,2]  R273      2.8650718927383423e-01
    z[4,0,2]  R274      -1.9951665401458740e-01
    z[4,0,2]  R275      3.5323369503021240e-01
    z[4,0,2]  R276      -9.4967454671859741e-02
    z[4,0,2]  R277      2.1584048867225647e-01
    z[4,0,2]  R278      1.6235182061791420e-02
    z[4,0,2]  R279      1.6828076541423798e-01
    z[4,0,2]  R280      1.4500774443149567e-01
    z[4,0,2]  R281      -2.5203108787536621e-01
    z[4,0,2]  R282      1.9131980836391449e-01
    z[4,0,2]  R283      -2.5324690341949463e-01
    z[4,0,2]  R284      4.5704704523086548e-01
    z[4,0,2]  R285      3.6697588860988617e-02
    z[4,0,2]  R286      1.5689401328563690e-01
    z[4,0,2]  R287      6.6139960289001465e-01
    z[4,0,2]  R288      5.4390519857406616e-01
    z[4,0,2]  R289      0.560393214225769
    z[4,0,2]  R290      3.9219895005226135e-01
    z[4,0,2]  R291      2.2104445099830627e-01
    z[4,0,2]  R292      -1.7613707482814789e-01
    z[4,0,2]  R293      1.2199211120605469e-01
    z[4,0,2]  R294      3.3063071966171265e-01
    z[4,0,2]  R295      -2.1118113398551941e-01
    z[4,0,2]  R296      -4.3785148859024048e-01
    z[4,0,2]  R297      8.6046516895294189e-01
    z[4,0,2]  R298      4.7455862164497375e-01
    z[4,0,2]  R299      -2.1670293807983398e-01
    z[4,0,2]  R300      1.3036768138408661e-01
    z[4,0,2]  R301      7.9535908997058868e-02
    z[4,0,2]  R302      9.3808054924011230e-02
    z[4,0,2]  R303      -1.9777974113821983e-02
    z[4,0,2]  R304      1.2077989988029003e-02
    z[4,0,2]  R305      1.1202631890773773e-01
    z[4,0,2]  R306      -2.5457123294472694e-02
    z[4,0,2]  R307      2.3391798138618469e-01
    z[4,0,2]  R308      -5.8963544666767120e-02
    z[4,0,2]  R309      -0.425925612449646
    z[4,0,2]  R310      2.6953849196434021e-01
    z[4,0,2]  R311      -2.3235602676868439e-01
    z[4,0,2]  R312      -1.1962404847145081e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R254      -1
    z[4,0,3]  R255      1
    z[4,0,3]  R262      6.1507642269134521e-01
    z[4,0,3]  R263      4.4686588644981384e-01
    z[4,0,3]  R264      2.5985551998019218e-02
    z[4,0,3]  R265      0.0774635300040245
    z[4,0,3]  R266      1.2837946414947510e-01
    z[4,0,3]  R267      1.4763016998767853e-01
    z[4,0,3]  R268      -1.1432129889726639e-01
    z[4,0,3]  R269      4.8429793119430542e-01
    z[4,0,3]  R270      2.5366386771202087e-01
    z[4,0,3]  R271      -3.6661627888679504e-01
    z[4,0,3]  R272      -0.264119416475296
    z[4,0,3]  R273      -2.6760128140449524e-01
    z[4,0,3]  R274      -1.6713038086891174e-01
    z[4,0,3]  R275      -7.0014017820358276e-01
    z[4,0,3]  R276      -7.4978643655776978e-01
    z[4,0,3]  R277      -3.5778027772903442e-01
    z[4,0,3]  R278      -4.2110189795494080e-01
    z[4,0,3]  R279      -6.3382244110107422e-01
    z[4,0,3]  R280      -4.4403409957885742e-01
    z[4,0,3]  R281      -3.7899157404899597e-01
    z[4,0,3]  R282      -1.3485260307788849e-02
    z[4,0,3]  R283      -5.0639325380325317e-01
    z[4,0,3]  R284      -1.9734393060207367e-01
    z[4,0,3]  R285      -2.1550129354000092e-01
    z[4,0,3]  R286      -5.9948104619979858e-01
    z[4,0,3]  R287      -1.1764326132833958e-02
    z[4,0,3]  R288      0.564063310623169
    z[4,0,3]  R289      -1.0873633623123169e-01
    z[4,0,3]  R290      4.2686897516250610e-01
    z[4,0,3]  R291      -6.5339082479476929e-01
    z[4,0,3]  R292      1.5900303423404694e-01
    z[4,0,3]  R293      -2.5881990790367126e-02
    z[4,0,3]  R294      -7.0459538698196411e-01
    z[4,0,3]  R295      -3.7491348385810852e-01
    z[4,0,3]  R296      -2.7145528793334961e-01
    z[4,0,3]  R297      -2.8663533926010132e-01
    z[4,0,3]  R298      -7.6727020740509033e-01
    z[4,0,3]  R299      -2.9720821976661682e-01
    z[4,0,3]  R300      -4.6246835589408875e-01
    z[4,0,3]  R301      -7.4910408258438110e-01
    z[4,0,3]  R302      1.4437849819660187e-01
    z[4,0,3]  R303      3.9207759499549866e-01
    z[4,0,3]  R304      1.1975728720426559e-01
    z[4,0,3]  R305      2.5175365805625916e-01
    z[4,0,3]  R306      2.1004541218280792e-01
    z[4,0,3]  R307      5.5384886264801025e-01
    z[4,0,3]  R308      2.2122795879840851e-01
    z[4,0,3]  R309      1.2456604093313217e-01
    z[4,0,3]  R310      2.4052891135215759e-01
    z[4,0,3]  R311      2.2559799253940582e-02
    z[4,0,3]  R312      -3.3356092870235443e-02
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R256      -1
    z[4,0,4]  R257      1
    z[4,0,4]  R262      1.1974767595529556e-01
    z[4,0,4]  R263      9.1862939298152924e-03
    z[4,0,4]  R264      7.3491334915161133e-02
    z[4,0,4]  R265      -5.8846427127718925e-03
    z[4,0,4]  R266      -1.6747325658798218e-01
    z[4,0,4]  R267      -1.3405182398855686e-03
    z[4,0,4]  R268      2.5259381532669067e-01
    z[4,0,4]  R269      -2.1315573155879974e-01
    z[4,0,4]  R270      3.2217299938201904e-01
    z[4,0,4]  R271      5.4563339799642563e-02
    z[4,0,4]  R272      -1.9892422854900360e-01
    z[4,0,4]  R273      -6.7497217655181885e-01
    z[4,0,4]  R274      0.788306474685669
    z[4,0,4]  R275      -4.4945013523101807e-01
    z[4,0,4]  R276      -2.1735686063766479e-01
    z[4,0,4]  R277      -2.3181030154228210e-01
    z[4,0,4]  R278      5.2764439582824707e-01
    z[4,0,4]  R279      -1.1529266089200974e-01
    z[4,0,4]  R280      -4.5612469315528870e-01
    z[4,0,4]  R281      2.4645689129829407e-01
    z[4,0,4]  R282      -3.4443697333335876e-01
    z[4,0,4]  R283      -4.1347879171371460e-01
    z[4,0,4]  R284      -6.9526904821395874e-01
    z[4,0,4]  R285      1.8194644153118134e-01
    z[4,0,4]  R286      8.0386392772197723e-02
    z[4,0,4]  R287      -3.9396342635154724e-01
    z[4,0,4]  R288      -2.4239769577980042e-01
    z[4,0,4]  R289      -1.4636828005313873e-01
    z[4,0,4]  R290      2.6185914874076843e-01
    z[4,0,4]  R291      1.6176441311836243e-01
    z[4,0,4]  R292      1.8638296052813530e-02
    z[4,0,4]  R293      2.1074400842189789e-01
    z[4,0,4]  R294      -1.7241697013378143e-01
    z[4,0,4]  R295      3.6345225572586060e-01
    z[4,0,4]  R296      -2.9684737324714661e-01
    z[4,0,4]  R297      -1.2365782260894775e-01
    z[4,0,4]  R298      7.5269125401973724e-02
    z[4,0,4]  R299      1.3593231141567230e-01
    z[4,0,4]  R300      -0.343688428401947
    z[4,0,4]  R301      -0.0699055939912796
    z[4,0,4]  R302      -1.3933452963829041e-01
    z[4,0,4]  R303      -6.0493290424346924e-02
    z[4,0,4]  R304      -5.7243339717388153e-02
    z[4,0,4]  R305      -1.0175827890634537e-01
    z[4,0,4]  R306      2.9869192838668823e-01
    z[4,0,4]  R307      -1.0766943544149399e-01
    z[4,0,4]  R308      1.9593912363052368e-01
    z[4,0,4]  R309      1.2759655714035034e-01
    z[4,0,4]  R310      8.1766790151596069e-01
    z[4,0,4]  R311      2.9254147410392761e-01
    z[4,0,4]  R312      -2.0382346585392952e-02
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R258      -1
    z[4,0,5]  R259      1
    z[4,0,5]  R262      1.9912265241146088e-01
    z[4,0,5]  R263      4.6489837765693665e-01
    z[4,0,5]  R264      1.7913137376308441e-01
    z[4,0,5]  R265      1.4583170413970947e-01
    z[4,0,5]  R266      -1.5650568902492523e-01
    z[4,0,5]  R267      2.6274496316909790e-01
    z[4,0,5]  R268      1.2872308492660522e-01
    z[4,0,5]  R269      3.1005263328552246e-01
    z[4,0,5]  R270      -2.4613271653652191e-01
    z[4,0,5]  R271      -7.7008586376905441e-03
    z[4,0,5]  R272      5.2982527017593384e-01
    z[4,0,5]  R273      -4.3148615956306458e-01
    z[4,0,5]  R274      1.3492126762866974e-01
    z[4,0,5]  R275      -1.5359036624431610e-01
    z[4,0,5]  R276      -4.3180957436561584e-01
    z[4,0,5]  R277      -3.0500459671020508e-01
    z[4,0,5]  R278      -0.306742787361145
    z[4,0,5]  R279      -4.3126323819160461e-01
    z[4,0,5]  R280      -2.4748770892620087e-01
    z[4,0,5]  R281      -1.0798367857933044e-01
    z[4,0,5]  R282      -3.5758325457572937e-01
    z[4,0,5]  R283      -4.5182332396507263e-01
    z[4,0,5]  R284      1.2278459221124649e-01
    z[4,0,5]  R285      -2.3089537024497986e-01
    z[4,0,5]  R286      -6.4779542386531830e-02
    z[4,0,5]  R287      -1.6605409979820251e-01
    z[4,0,5]  R288      -0.283381849527359
    z[4,0,5]  R289      -2.8153559565544128e-01
    z[4,0,5]  R290      -4.6473595499992371e-01
    z[4,0,5]  R291      -5.0197279453277588e-01
    z[4,0,5]  R292      -1.4717520773410797e-01
    z[4,0,5]  R293      2.8738099336624146e-01
    z[4,0,5]  R294      0.093800388276577
    z[4,0,5]  R295      -2.8256615996360779e-01
    z[4,0,5]  R296      0.0650511384010315
    z[4,0,5]  R297      -1.4507479965686798e-01
    z[4,0,5]  R298      -9.6735939383506775e-02
    z[4,0,5]  R299      -0.575602114200592
    z[4,0,5]  R300      2.4396726861596107e-02
    z[4,0,5]  R301      4.8044177889823914e-01
    z[4,0,5]  R302      2.7716580033302307e-01
    z[4,0,5]  R303      -1.9671705085784197e-03
    z[4,0,5]  R304      -8.5782044334337115e-04
    z[4,0,5]  R305      3.3683833479881287e-01
    z[4,0,5]  R306      -1.6500061750411987e-01
    z[4,0,5]  R307      -4.8872837424278259e-01
    z[4,0,5]  R308      2.1847733855247498e-01
    z[4,0,5]  R309      -1.5152585506439209e-01
    z[4,0,5]  R310      2.8312146663665771e-01
    z[4,0,5]  R311      -2.1683995425701141e-01
    z[4,0,5]  R312      3.5741943120956421e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R260      -1
    z[4,0,6]  R261      1
    z[4,0,6]  R262      9.4051003456115723e-02
    z[4,0,6]  R263      2.1959602832794189e-01
    z[4,0,6]  R264      -2.2288376092910767e-01
    z[4,0,6]  R265      2.6998394727706909e-01
    z[4,0,6]  R266      1.4485952444374561e-02
    z[4,0,6]  R267      -1.2788560986518860e-01
    z[4,0,6]  R268      -2.1695968508720398e-01
    z[4,0,6]  R269      5.9041076898574829e-01
    z[4,0,6]  R270      -1.6503702104091644e-01
    z[4,0,6]  R271      9.7034208476543427e-02
    z[4,0,6]  R272      4.2760372161865234e-03
    z[4,0,6]  R273      2.0669229328632355e-01
    z[4,0,6]  R274      1.5125776827335358e-01
    z[4,0,6]  R275      -1.5639545023441315e-01
    z[4,0,6]  R276      3.0983600020408630e-01
    z[4,0,6]  R277      -2.3544387519359589e-01
    z[4,0,6]  R278      2.2228620946407318e-01
    z[4,0,6]  R279      -5.0690621137619019e-01
    z[4,0,6]  R280      -6.9645619392395020e-01
    z[4,0,6]  R281      -0.70573490858078
    z[4,0,6]  R282      -1.1214417964220047e-01
    z[4,0,6]  R283      5.3438387811183929e-02
    z[4,0,6]  R284      -2.7194821834564209e-01
    z[4,0,6]  R285      2.1997734904289246e-01
    z[4,0,6]  R286      1.4994235336780548e-01
    z[4,0,6]  R287      1.1865685880184174e-01
    z[4,0,6]  R288      3.6452680360525846e-03
    z[4,0,6]  R289      -3.1543239951133728e-01
    z[4,0,6]  R290      -2.3646588623523712e-01
    z[4,0,6]  R291      -2.5612443685531616e-01
    z[4,0,6]  R292      3.5241311788558960e-01
    z[4,0,6]  R293      -5.0374704599380493e-01
    z[4,0,6]  R294      -3.6877453327178955e-01
    z[4,0,6]  R295      -4.4958570599555969e-01
    z[4,0,6]  R296      1.3927395641803741e-01
    z[4,0,6]  R297      -3.1910225749015808e-01
    z[4,0,6]  R298      3.8312595337629318e-02
    z[4,0,6]  R299      2.7166712284088135e-01
    z[4,0,6]  R300      7.2592890262603760e-01
    z[4,0,6]  R301      -1.0168961435556412e-01
    z[4,0,6]  R302      -6.5873727202415466e-02
    z[4,0,6]  R303      -1.0057418793439865e-01
    z[4,0,6]  R304      3.6124783754348755e-01
    z[4,0,6]  R305      1.5634240582585335e-02
    z[4,0,6]  R306      -4.1202667355537415e-01
    z[4,0,6]  R307      2.2831596434116364e-01
    z[4,0,6]  R308      -6.6818869113922119e-01
    z[4,0,6]  R309      3.1017127633094788e-01
    z[4,0,6]  R310      0.333430677652359
    z[4,0,6]  R311      -1.1027046293020248e-01
    z[4,0,6]  R312      9.5278814435005188e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R343      -1
    z[1,2,0]  R344      1
    z[1,2,0]  R357      6.1115242540836334e-02
    z[1,2,0]  R358      3.4678170084953308e-01
    z[1,2,0]  R359      -3.5861795768141747e-03
    z[1,2,0]  R360      4.4398523867130280e-02
    z[1,2,0]  R361      3.5011547803878784e-01
    z[1,2,0]  R362      2.0817881822586060e-01
    z[1,2,0]  R363      2.9778337478637695e-01
    z[1,2,0]  R364      -6.9507293403148651e-02
    z[1,2,0]  R365      0.0963430106639862
    z[1,2,0]  R366      2.5605884194374084e-01
    z[1,2,0]  R367      -4.7528970241546631e-01
    z[1,2,0]  R368      -4.1346180438995361e-01
    z[1,2,0]  R369      -3.2739189267158508e-01
    z[1,2,0]  R370      -2.5131538510322571e-01
    z[1,2,0]  R371      -4.4437846541404724e-01
    z[1,2,0]  R372      1.7433683574199677e-01
    z[1,2,0]  R373      -4.7088381648063660e-01
    z[1,2,0]  R374      -8.0200988054275513e-01
    z[1,2,0]  R375      -1.2751890718936920e-01
    z[1,2,0]  R376      1.9296426326036453e-02
    z[1,2,0]  R377      -4.7791567444801331e-01
    z[1,2,0]  R378      -4.3469026684761047e-01
    z[1,2,0]  R379      -0.340529203414917
    z[1,2,0]  R380      3.1684383749961853e-01
    z[1,2,0]  R381      -2.8930708765983582e-01
    z[1,2,0]  R382      0.569987416267395
    z[1,2,0]  R383      -3.9689540863037109e-02
    z[1,2,0]  R384      3.4201338887214661e-01
    z[1,2,0]  R385      -4.3589100241661072e-01
    z[1,2,0]  R386      8.0050855875015259e-01
    z[1,2,0]  R387      1.6933538019657135e-02
    z[1,2,0]  R388      3.8401553034782410e-01
    z[1,2,0]  R389      6.3226169347763062e-01
    z[1,2,0]  R390      3.9538022875785828e-01
    z[1,2,0]  R391      4.5348340272903442e-01
    z[1,2,0]  R392      1.8556459248065948e-01
    z[1,2,0]  R393      2.8833302855491638e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R345      -1
    z[1,2,1]  R346      1
    z[1,2,1]  R357      -0.670496940612793
    z[1,2,1]  R358      1.9411586225032806e-01
    z[1,2,1]  R359      7.3674730956554413e-02
    z[1,2,1]  R360      1.3380122184753418e-01
    z[1,2,1]  R361      1.1019846051931381e-01
    z[1,2,1]  R362      -5.4210770130157471e-01
    z[1,2,1]  R363      0.147373229265213
    z[1,2,1]  R364      -8.3530586957931519e-01
    z[1,2,1]  R365      1.0140072554349899e-01
    z[1,2,1]  R366      -8.3609145879745483e-01
    z[1,2,1]  R367      5.6331526488065720e-02
    z[1,2,1]  R368      -5.4738566279411316e-02
    z[1,2,1]  R369      2.2444877028465271e-01
    z[1,2,1]  R370      0.8356893658638
    z[1,2,1]  R371      3.1258377432823181e-01
    z[1,2,1]  R372      4.5268520712852478e-01
    z[1,2,1]  R373      0.725092887878418
    z[1,2,1]  R374      5.1484996080398560e-01
    z[1,2,1]  R375      7.5360083580017090e-01
    z[1,2,1]  R376      2.6453128457069397e-01
    z[1,2,1]  R377      0.257255882024765
    z[1,2,1]  R378      2.1956029534339905e-01
    z[1,2,1]  R379      1.6878212988376617e-01
    z[1,2,1]  R380      1.8642768263816833e-01
    z[1,2,1]  R381      3.3697074651718140e-01
    z[1,2,1]  R382      1.5065012872219086e-01
    z[1,2,1]  R383      -1.5303435735404491e-02
    z[1,2,1]  R384      1.9988635182380676e-01
    z[1,2,1]  R385      3.0230081081390381e-01
    z[1,2,1]  R386      1.1791199445724487e-01
    z[1,2,1]  R387      8.6105978488922119e-01
    z[1,2,1]  R388      4.7929906845092773e-01
    z[1,2,1]  R389      -6.1272454261779785e-01
    z[1,2,1]  R390      -8.6557334661483765e-01
    z[1,2,1]  R391      -8.1219369173049927e-01
    z[1,2,1]  R392      2.1737320721149445e-01
    z[1,2,1]  R393      2.6539999246597290e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R347      -1
    z[1,2,2]  R348      1
    z[1,2,2]  R357      5.2930426597595215e-01
    z[1,2,2]  R358      3.5214978456497192e-01
    z[1,2,2]  R359      4.5405516028404236e-01
    z[1,2,2]  R360      4.7220396995544434e-01
    z[1,2,2]  R361      7.8601932525634766e-01
    z[1,2,2]  R362      -8.1950798630714417e-02
    z[1,2,2]  R363      7.1948093175888062e-01
    z[1,2,2]  R364      -3.2306644320487976e-01
    z[1,2,2]  R365      3.1845986843109131e-02
    z[1,2,2]  R366      3.1323564052581787e-01
    z[1,2,2]  R367      -2.5523701310157776e-01
    z[1,2,2]  R368      -2.8995606303215027e-01
    z[1,2,2]  R369      -1.8330007791519165e-01
    z[1,2,2]  R370      -5.3818099200725555e-02
    z[1,2,2]  R371      -2.5158625841140747e-01
    z[1,2,2]  R372      -2.3679348826408386e-01
    z[1,2,2]  R373      2.6354601606726646e-02
    z[1,2,2]  R374      -1.3988175988197327e-01
    z[1,2,2]  R375      1.6360491514205933e-02
    z[1,2,2]  R376      -2.6247063279151917e-01
    z[1,2,2]  R377      -4.0107178688049316e-01
    z[1,2,2]  R378      3.9156821370124817e-01
    z[1,2,2]  R379      1.8699896335601807e-01
    z[1,2,2]  R380      -2.6355883479118347e-01
    z[1,2,2]  R381      -1.6198235750198364e-01
    z[1,2,2]  R382      3.4033775329589844e-01
    z[1,2,2]  R383      2.8280389308929443e-01
    z[1,2,2]  R384      -4.8253139853477478e-01
    z[1,2,2]  R385      1.5344102680683136e-01
    z[1,2,2]  R386      0.482488751411438
    z[1,2,2]  R387      1.1112050712108612e-01
    z[1,2,2]  R388      4.8545765876770020e-01
    z[1,2,2]  R389      -2.5814312696456909e-01
    z[1,2,2]  R390      -1.0168453305959702e-01
    z[1,2,2]  R391      -3.0397295951843262e-01
    z[1,2,2]  R392      -4.5900654792785645e-01
    z[1,2,2]  R393      -4.2968934774398804e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R349      -1
    z[1,2,3]  R350      1
    z[1,2,3]  R357      4.8845723271369934e-01
    z[1,2,3]  R358      -6.0759127140045166e-01
    z[1,2,3]  R359      -3.8873347640037537e-01
    z[1,2,3]  R360      -1.9432626664638519e-01
    z[1,2,3]  R361      -0.175181582570076
    z[1,2,3]  R362      -2.9513069987297058e-01
    z[1,2,3]  R363      -0.0831599235534668
    z[1,2,3]  R364      -1.7597758769989014e-01
    z[1,2,3]  R365      -5.5355662107467651e-01
    z[1,2,3]  R366      -1.5770237147808075e-01
    z[1,2,3]  R367      3.6064285039901733e-01
    z[1,2,3]  R368      4.2841225862503052e-01
    z[1,2,3]  R369      3.5281065106391907e-01
    z[1,2,3]  R370      -2.0015968382358551e-01
    z[1,2,3]  R371      7.6101320981979370e-01
    z[1,2,3]  R372      -2.2730755805969238e-01
    z[1,2,3]  R373      4.9997620284557343e-02
    z[1,2,3]  R374      -2.5239327549934387e-01
    z[1,2,3]  R375      -2.6964496355503798e-03
    z[1,2,3]  R376      1.1851250380277634e-01
    z[1,2,3]  R377      5.6083297729492188e-01
    z[1,2,3]  R378      0.0547274611890316
    z[1,2,3]  R379      0.602268397808075
    z[1,2,3]  R380      -6.5138369798660278e-01
    z[1,2,3]  R381      4.6961027383804321e-01
    z[1,2,3]  R382      -5.6371581554412842e-01
    z[1,2,3]  R383      -0.739917516708374
    z[1,2,3]  R384      -4.2029540985822678e-02
    z[1,2,3]  R385      -2.8136106207966805e-02
    z[1,2,3]  R386      -7.4998661875724792e-02
    z[1,2,3]  R387      -2.0571278035640717e-01
    z[1,2,3]  R388      -3.4350258111953735e-01
    z[1,2,3]  R389      2.0098045468330383e-01
    z[1,2,3]  R390      -1.7220930755138397e-01
    z[1,2,3]  R391      8.4163762629032135e-02
    z[1,2,3]  R392      -1.1817722022533417e-01
    z[1,2,3]  R393      5.4602071642875671e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R351      -1
    z[1,2,4]  R352      1
    z[1,2,4]  R357      -1.7064822837710381e-02
    z[1,2,4]  R358      5.3245973587036133e-01
    z[1,2,4]  R359      7.8416770696640015e-01
    z[1,2,4]  R360      6.6201478242874146e-01
    z[1,2,4]  R361      4.4137087464332581e-01
    z[1,2,4]  R362      5.1038908958435059e-01
    z[1,2,4]  R363      0.350729376077652
    z[1,2,4]  R364      -2.9283556342124939e-01
    z[1,2,4]  R365      6.3868880271911621e-01
    z[1,2,4]  R366      2.5991666316986084e-01
    z[1,2,4]  R367      -2.3611986637115479e-01
    z[1,2,4]  R368      6.2702828645706177e-01
    z[1,2,4]  R369      -2.5449457764625549e-01
    z[1,2,4]  R370      -1.9062182307243347e-01
    z[1,2,4]  R371      -9.2199616134166718e-02
    z[1,2,4]  R372      -4.4130030274391174e-01
    z[1,2,4]  R373      8.2113333046436310e-02
    z[1,2,4]  R374      7.5337424874305725e-02
    z[1,2,4]  R375      2.7578082680702209e-01
    z[1,2,4]  R376      1.5675379335880280e-01
    z[1,2,4]  R377      -1.2686930596828461e-01
    z[1,2,4]  R378      1.0851389169692993e-01
    z[1,2,4]  R379      -1.0209298878908157e-01
    z[1,2,4]  R380      5.3755092620849609e-01
    z[1,2,4]  R381      0.44412961602211
    z[1,2,4]  R382      -7.2428070008754730e-02
    z[1,2,4]  R383      2.4110174179077148e-01
    z[1,2,4]  R384      0.666729748249054
    z[1,2,4]  R385      -5.4639589786529541e-01
    z[1,2,4]  R386      1.5601858496665955e-01
    z[1,2,4]  R387      -2.3172209039330482e-03
    z[1,2,4]  R388      2.2902800142765045e-01
    z[1,2,4]  R389      -1.0874087363481522e-01
    z[1,2,4]  R390      -1.2333360314369202e-01
    z[1,2,4]  R391      -1.7300260066986084e-01
    z[1,2,4]  R392      -0.677017867565155
    z[1,2,4]  R393      -5.5533581972122192e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R353      -1
    z[1,2,5]  R354      1
    z[1,2,5]  R357      -2.3706601932644844e-02
    z[1,2,5]  R358      2.8746696189045906e-02
    z[1,2,5]  R359      1.4385445415973663e-01
    z[1,2,5]  R360      4.0604382753372192e-01
    z[1,2,5]  R361      -9.8630271852016449e-02
    z[1,2,5]  R362      5.5401074886322021e-01
    z[1,2,5]  R363      4.8987871408462524e-01
    z[1,2,5]  R364      1.4435516297817230e-01
    z[1,2,5]  R365      1.3800123333930969e-01
    z[1,2,5]  R366      2.0936714112758636e-01
    z[1,2,5]  R367      -6.4345175027847290e-01
    z[1,2,5]  R368      -3.6098206043243408e-01
    z[1,2,5]  R369      -5.2372545003890991e-01
    z[1,2,5]  R370      -6.7019402980804443e-02
    z[1,2,5]  R371      -1.1411903798580170e-01
    z[1,2,5]  R372      0.676039457321167
    z[1,2,5]  R373      -2.5497004389762878e-01
    z[1,2,5]  R374      4.5900885015726089e-02
    z[1,2,5]  R375      -5.4525250196456909e-01
    z[1,2,5]  R376      5.1757085323333740e-01
    z[1,2,5]  R377      4.6073180437088013e-01
    z[1,2,5]  R378      -4.5443538576364517e-02
    z[1,2,5]  R379      -0.586475133895874
    z[1,2,5]  R380      8.9801521971821785e-03
    z[1,2,5]  R381      -1.6270147264003754e-01
    z[1,2,5]  R382      -1.6778273880481720e-01
    z[1,2,5]  R383      -1.2378364801406860e-01
    z[1,2,5]  R384      -4.0458962321281433e-01
    z[1,2,5]  R385      2.6042655110359192e-01
    z[1,2,5]  R386      -1.1376355588436127e-01
    z[1,2,5]  R387      -6.4084318000823259e-04
    z[1,2,5]  R388      9.5598847838118672e-04
    z[1,2,5]  R389      1.9212763011455536e-01
    z[1,2,5]  R390      1.8085126578807831e-01
    z[1,2,5]  R391      6.4689829945564270e-02
    z[1,2,5]  R392      -3.1809869408607483e-01
    z[1,2,5]  R393      -4.7258087992668152e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R355      -1
    z[1,2,6]  R356      1
    z[1,2,6]  R357      1.6459685564041138e-01
    z[1,2,6]  R358      2.5405707955360413e-01
    z[1,2,6]  R359      4.0819738060235977e-02
    z[1,2,6]  R360      -3.4095677733421326e-01
    z[1,2,6]  R361      -1.1056360602378845e-01
    z[1,2,6]  R362      3.9215475320816040e-02
    z[1,2,6]  R363      4.5227214694023132e-02
    z[1,2,6]  R364      2.3558828234672546e-01
    z[1,2,6]  R365      -4.9601322412490845e-01
    z[1,2,6]  R366      3.1735043972730637e-02
    z[1,2,6]  R367      -3.2547584176063538e-01
    z[1,2,6]  R368      1.8699988722801208e-01
    z[1,2,6]  R369      5.8762842416763306e-01
    z[1,2,6]  R370      -3.9328780770301819e-01
    z[1,2,6]  R371      2.0213498175144196e-01
    z[1,2,6]  R372      7.1885332465171814e-02
    z[1,2,6]  R373      4.2138126492500305e-01
    z[1,2,6]  R374      2.5649489834904671e-02
    z[1,2,6]  R375      -2.0541286468505859e-01
    z[1,2,6]  R376      7.4448871612548828e-01
    z[1,2,6]  R377      4.0673531591892242e-02
    z[1,2,6]  R378      -7.6985484361648560e-01
    z[1,2,6]  R379      3.2168385386466980e-01
    z[1,2,6]  R380      -2.8644195199012756e-01
    z[1,2,6]  R381      -5.7641750574111938e-01
    z[1,2,6]  R382      4.3060046434402466e-01
    z[1,2,6]  R383      -5.4523575305938721e-01
    z[1,2,6]  R384      1.5747912228107452e-02
    z[1,2,6]  R385      5.7263159751892090e-01
    z[1,2,6]  R386      -2.6377776265144348e-01
    z[1,2,6]  R387      4.5124056935310364e-01
    z[1,2,6]  R388      -4.6549594402313232e-01
    z[1,2,6]  R389      2.6276421546936035e-01
    z[1,2,6]  R390      -8.0889321863651276e-02
    z[1,2,6]  R391      -3.3113043755292892e-02
    z[1,2,6]  R392      -0.366226464509964
    z[1,2,6]  R393      -3.5648569464683533e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R394      -1
    z[2,1,0]  R395      1
    z[2,1,0]  R408      -4.7791567444801331e-01
    z[2,1,0]  R409      -4.3469026684761047e-01
    z[2,1,0]  R410      -0.340529203414917
    z[2,1,0]  R411      3.1684383749961853e-01
    z[2,1,0]  R412      -2.8930708765983582e-01
    z[2,1,0]  R413      0.569987416267395
    z[2,1,0]  R414      -3.9689540863037109e-02
    z[2,1,0]  R415      3.4201338887214661e-01
    z[2,1,0]  R416      -4.3589100241661072e-01
    z[2,1,0]  R417      8.0050855875015259e-01
    z[2,1,0]  R418      1.6933538019657135e-02
    z[2,1,0]  R419      3.8401553034782410e-01
    z[2,1,0]  R420      6.3226169347763062e-01
    z[2,1,0]  R421      3.9538022875785828e-01
    z[2,1,0]  R422      4.5348340272903442e-01
    z[2,1,0]  R423      1.8556459248065948e-01
    z[2,1,0]  R424      2.8833302855491638e-01
    z[2,1,0]  R425      6.1115242540836334e-02
    z[2,1,0]  R426      3.4678170084953308e-01
    z[2,1,0]  R427      -3.5861795768141747e-03
    z[2,1,0]  R428      4.4398523867130280e-02
    z[2,1,0]  R429      3.5011547803878784e-01
    z[2,1,0]  R430      2.0817881822586060e-01
    z[2,1,0]  R431      2.9778337478637695e-01
    z[2,1,0]  R432      -6.9507293403148651e-02
    z[2,1,0]  R433      0.0963430106639862
    z[2,1,0]  R434      2.5605884194374084e-01
    z[2,1,0]  R435      -4.7528970241546631e-01
    z[2,1,0]  R436      -4.1346180438995361e-01
    z[2,1,0]  R437      -3.2739189267158508e-01
    z[2,1,0]  R438      -2.5131538510322571e-01
    z[2,1,0]  R439      -4.4437846541404724e-01
    z[2,1,0]  R440      1.7433683574199677e-01
    z[2,1,0]  R441      -4.7088381648063660e-01
    z[2,1,0]  R442      -8.0200988054275513e-01
    z[2,1,0]  R443      -1.2751890718936920e-01
    z[2,1,0]  R444      1.9296426326036453e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R396      -1
    z[2,1,1]  R397      1
    z[2,1,1]  R408      0.257255882024765
    z[2,1,1]  R409      2.1956029534339905e-01
    z[2,1,1]  R410      1.6878212988376617e-01
    z[2,1,1]  R411      1.8642768263816833e-01
    z[2,1,1]  R412      3.3697074651718140e-01
    z[2,1,1]  R413      1.5065012872219086e-01
    z[2,1,1]  R414      -1.5303435735404491e-02
    z[2,1,1]  R415      1.9988635182380676e-01
    z[2,1,1]  R416      3.0230081081390381e-01
    z[2,1,1]  R417      1.1791199445724487e-01
    z[2,1,1]  R418      8.6105978488922119e-01
    z[2,1,1]  R419      4.7929906845092773e-01
    z[2,1,1]  R420      -6.1272454261779785e-01
    z[2,1,1]  R421      -8.6557334661483765e-01
    z[2,1,1]  R422      -8.1219369173049927e-01
    z[2,1,1]  R423      2.1737320721149445e-01
    z[2,1,1]  R424      2.6539999246597290e-01
    z[2,1,1]  R425      -0.670496940612793
    z[2,1,1]  R426      1.9411586225032806e-01
    z[2,1,1]  R427      7.3674730956554413e-02
    z[2,1,1]  R428      1.3380122184753418e-01
    z[2,1,1]  R429      1.1019846051931381e-01
    z[2,1,1]  R430      -5.4210770130157471e-01
    z[2,1,1]  R431      0.147373229265213
    z[2,1,1]  R432      -8.3530586957931519e-01
    z[2,1,1]  R433      1.0140072554349899e-01
    z[2,1,1]  R434      -8.3609145879745483e-01
    z[2,1,1]  R435      5.6331526488065720e-02
    z[2,1,1]  R436      -5.4738566279411316e-02
    z[2,1,1]  R437      2.2444877028465271e-01
    z[2,1,1]  R438      0.8356893658638
    z[2,1,1]  R439      3.1258377432823181e-01
    z[2,1,1]  R440      4.5268520712852478e-01
    z[2,1,1]  R441      0.725092887878418
    z[2,1,1]  R442      5.1484996080398560e-01
    z[2,1,1]  R443      7.5360083580017090e-01
    z[2,1,1]  R444      2.6453128457069397e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R398      -1
    z[2,1,2]  R399      1
    z[2,1,2]  R408      -4.0107178688049316e-01
    z[2,1,2]  R409      3.9156821370124817e-01
    z[2,1,2]  R410      1.8699896335601807e-01
    z[2,1,2]  R411      -2.6355883479118347e-01
    z[2,1,2]  R412      -1.6198235750198364e-01
    z[2,1,2]  R413      3.4033775329589844e-01
    z[2,1,2]  R414      2.8280389308929443e-01
    z[2,1,2]  R415      -4.8253139853477478e-01
    z[2,1,2]  R416      1.5344102680683136e-01
    z[2,1,2]  R417      0.482488751411438
    z[2,1,2]  R418      1.1112050712108612e-01
    z[2,1,2]  R419      4.8545765876770020e-01
    z[2,1,2]  R420      -2.5814312696456909e-01
    z[2,1,2]  R421      -1.0168453305959702e-01
    z[2,1,2]  R422      -3.0397295951843262e-01
    z[2,1,2]  R423      -4.5900654792785645e-01
    z[2,1,2]  R424      -4.2968934774398804e-01
    z[2,1,2]  R425      5.2930426597595215e-01
    z[2,1,2]  R426      3.5214978456497192e-01
    z[2,1,2]  R427      4.5405516028404236e-01
    z[2,1,2]  R428      4.7220396995544434e-01
    z[2,1,2]  R429      7.8601932525634766e-01
    z[2,1,2]  R430      -8.1950798630714417e-02
    z[2,1,2]  R431      7.1948093175888062e-01
    z[2,1,2]  R432      -3.2306644320487976e-01
    z[2,1,2]  R433      3.1845986843109131e-02
    z[2,1,2]  R434      3.1323564052581787e-01
    z[2,1,2]  R435      -2.5523701310157776e-01
    z[2,1,2]  R436      -2.8995606303215027e-01
    z[2,1,2]  R437      -1.8330007791519165e-01
    z[2,1,2]  R438      -5.3818099200725555e-02
    z[2,1,2]  R439      -2.5158625841140747e-01
    z[2,1,2]  R440      -2.3679348826408386e-01
    z[2,1,2]  R441      2.6354601606726646e-02
    z[2,1,2]  R442      -1.3988175988197327e-01
    z[2,1,2]  R443      1.6360491514205933e-02
    z[2,1,2]  R444      -2.6247063279151917e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R400      -1
    z[2,1,3]  R401      1
    z[2,1,3]  R408      5.6083297729492188e-01
    z[2,1,3]  R409      0.0547274611890316
    z[2,1,3]  R410      0.602268397808075
    z[2,1,3]  R411      -6.5138369798660278e-01
    z[2,1,3]  R412      4.6961027383804321e-01
    z[2,1,3]  R413      -5.6371581554412842e-01
    z[2,1,3]  R414      -0.739917516708374
    z[2,1,3]  R415      -4.2029540985822678e-02
    z[2,1,3]  R416      -2.8136106207966805e-02
    z[2,1,3]  R417      -7.4998661875724792e-02
    z[2,1,3]  R418      -2.0571278035640717e-01
    z[2,1,3]  R419      -3.4350258111953735e-01
    z[2,1,3]  R420      2.0098045468330383e-01
    z[2,1,3]  R421      -1.7220930755138397e-01
    z[2,1,3]  R422      8.4163762629032135e-02
    z[2,1,3]  R423      -1.1817722022533417e-01
    z[2,1,3]  R424      5.4602071642875671e-02
    z[2,1,3]  R425      4.8845723271369934e-01
    z[2,1,3]  R426      -6.0759127140045166e-01
    z[2,1,3]  R427      -3.8873347640037537e-01
    z[2,1,3]  R428      -1.9432626664638519e-01
    z[2,1,3]  R429      -0.175181582570076
    z[2,1,3]  R430      -2.9513069987297058e-01
    z[2,1,3]  R431      -0.0831599235534668
    z[2,1,3]  R432      -1.7597758769989014e-01
    z[2,1,3]  R433      -5.5355662107467651e-01
    z[2,1,3]  R434      -1.5770237147808075e-01
    z[2,1,3]  R435      3.6064285039901733e-01
    z[2,1,3]  R436      4.2841225862503052e-01
    z[2,1,3]  R437      3.5281065106391907e-01
    z[2,1,3]  R438      -2.0015968382358551e-01
    z[2,1,3]  R439      7.6101320981979370e-01
    z[2,1,3]  R440      -2.2730755805969238e-01
    z[2,1,3]  R441      4.9997620284557343e-02
    z[2,1,3]  R442      -2.5239327549934387e-01
    z[2,1,3]  R443      -2.6964496355503798e-03
    z[2,1,3]  R444      1.1851250380277634e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R402      -1
    z[2,1,4]  R403      1
    z[2,1,4]  R408      -1.2686930596828461e-01
    z[2,1,4]  R409      1.0851389169692993e-01
    z[2,1,4]  R410      -1.0209298878908157e-01
    z[2,1,4]  R411      5.3755092620849609e-01
    z[2,1,4]  R412      0.44412961602211
    z[2,1,4]  R413      -7.2428070008754730e-02
    z[2,1,4]  R414      2.4110174179077148e-01
    z[2,1,4]  R415      0.666729748249054
    z[2,1,4]  R416      -5.4639589786529541e-01
    z[2,1,4]  R417      1.5601858496665955e-01
    z[2,1,4]  R418      -2.3172209039330482e-03
    z[2,1,4]  R419      2.2902800142765045e-01
    z[2,1,4]  R420      -1.0874087363481522e-01
    z[2,1,4]  R421      -1.2333360314369202e-01
    z[2,1,4]  R422      -1.7300260066986084e-01
    z[2,1,4]  R423      -0.677017867565155
    z[2,1,4]  R424      -5.5533581972122192e-01
    z[2,1,4]  R425      -1.7064822837710381e-02
    z[2,1,4]  R426      5.3245973587036133e-01
    z[2,1,4]  R427      7.8416770696640015e-01
    z[2,1,4]  R428      6.6201478242874146e-01
    z[2,1,4]  R429      4.4137087464332581e-01
    z[2,1,4]  R430      5.1038908958435059e-01
    z[2,1,4]  R431      0.350729376077652
    z[2,1,4]  R432      -2.9283556342124939e-01
    z[2,1,4]  R433      6.3868880271911621e-01
    z[2,1,4]  R434      2.5991666316986084e-01
    z[2,1,4]  R435      -2.3611986637115479e-01
    z[2,1,4]  R436      6.2702828645706177e-01
    z[2,1,4]  R437      -2.5449457764625549e-01
    z[2,1,4]  R438      -1.9062182307243347e-01
    z[2,1,4]  R439      -9.2199616134166718e-02
    z[2,1,4]  R440      -4.4130030274391174e-01
    z[2,1,4]  R441      8.2113333046436310e-02
    z[2,1,4]  R442      7.5337424874305725e-02
    z[2,1,4]  R443      2.7578082680702209e-01
    z[2,1,4]  R444      1.5675379335880280e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R404      -1
    z[2,1,5]  R405      1
    z[2,1,5]  R408      4.6073180437088013e-01
    z[2,1,5]  R409      -4.5443538576364517e-02
    z[2,1,5]  R410      -0.586475133895874
    z[2,1,5]  R411      8.9801521971821785e-03
    z[2,1,5]  R412      -1.6270147264003754e-01
    z[2,1,5]  R413      -1.6778273880481720e-01
    z[2,1,5]  R414      -1.2378364801406860e-01
    z[2,1,5]  R415      -4.0458962321281433e-01
    z[2,1,5]  R416      2.6042655110359192e-01
    z[2,1,5]  R417      -1.1376355588436127e-01
    z[2,1,5]  R418      -6.4084318000823259e-04
    z[2,1,5]  R419      9.5598847838118672e-04
    z[2,1,5]  R420      1.9212763011455536e-01
    z[2,1,5]  R421      1.8085126578807831e-01
    z[2,1,5]  R422      6.4689829945564270e-02
    z[2,1,5]  R423      -3.1809869408607483e-01
    z[2,1,5]  R424      -4.7258087992668152e-01
    z[2,1,5]  R425      -2.3706601932644844e-02
    z[2,1,5]  R426      2.8746696189045906e-02
    z[2,1,5]  R427      1.4385445415973663e-01
    z[2,1,5]  R428      4.0604382753372192e-01
    z[2,1,5]  R429      -9.8630271852016449e-02
    z[2,1,5]  R430      5.5401074886322021e-01
    z[2,1,5]  R431      4.8987871408462524e-01
    z[2,1,5]  R432      1.4435516297817230e-01
    z[2,1,5]  R433      1.3800123333930969e-01
    z[2,1,5]  R434      2.0936714112758636e-01
    z[2,1,5]  R435      -6.4345175027847290e-01
    z[2,1,5]  R436      -3.6098206043243408e-01
    z[2,1,5]  R437      -5.2372545003890991e-01
    z[2,1,5]  R438      -6.7019402980804443e-02
    z[2,1,5]  R439      -1.1411903798580170e-01
    z[2,1,5]  R440      0.676039457321167
    z[2,1,5]  R441      -2.5497004389762878e-01
    z[2,1,5]  R442      4.5900885015726089e-02
    z[2,1,5]  R443      -5.4525250196456909e-01
    z[2,1,5]  R444      5.1757085323333740e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R406      -1
    z[2,1,6]  R407      1
    z[2,1,6]  R408      4.0673531591892242e-02
    z[2,1,6]  R409      -7.6985484361648560e-01
    z[2,1,6]  R410      3.2168385386466980e-01
    z[2,1,6]  R411      -2.8644195199012756e-01
    z[2,1,6]  R412      -5.7641750574111938e-01
    z[2,1,6]  R413      4.3060046434402466e-01
    z[2,1,6]  R414      -5.4523575305938721e-01
    z[2,1,6]  R415      1.5747912228107452e-02
    z[2,1,6]  R416      5.7263159751892090e-01
    z[2,1,6]  R417      -2.6377776265144348e-01
    z[2,1,6]  R418      4.5124056935310364e-01
    z[2,1,6]  R419      -4.6549594402313232e-01
    z[2,1,6]  R420      2.6276421546936035e-01
    z[2,1,6]  R421      -8.0889321863651276e-02
    z[2,1,6]  R422      -3.3113043755292892e-02
    z[2,1,6]  R423      -0.366226464509964
    z[2,1,6]  R424      -3.5648569464683533e-01
    z[2,1,6]  R425      1.6459685564041138e-01
    z[2,1,6]  R426      2.5405707955360413e-01
    z[2,1,6]  R427      4.0819738060235977e-02
    z[2,1,6]  R428      -3.4095677733421326e-01
    z[2,1,6]  R429      -1.1056360602378845e-01
    z[2,1,6]  R430      3.9215475320816040e-02
    z[2,1,6]  R431      4.5227214694023132e-02
    z[2,1,6]  R432      2.3558828234672546e-01
    z[2,1,6]  R433      -4.9601322412490845e-01
    z[2,1,6]  R434      3.1735043972730637e-02
    z[2,1,6]  R435      -3.2547584176063538e-01
    z[2,1,6]  R436      1.8699988722801208e-01
    z[2,1,6]  R437      5.8762842416763306e-01
    z[2,1,6]  R438      -3.9328780770301819e-01
    z[2,1,6]  R439      2.0213498175144196e-01
    z[2,1,6]  R440      7.1885332465171814e-02
    z[2,1,6]  R441      4.2138126492500305e-01
    z[2,1,6]  R442      2.5649489834904671e-02
    z[2,1,6]  R443      -2.0541286468505859e-01
    z[2,1,6]  R444      7.4448871612548828e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R445      -1
    z[2,3,0]  R446      1
    z[2,3,0]  R459      -4.7791567444801331e-01
    z[2,3,0]  R460      -4.3469026684761047e-01
    z[2,3,0]  R461      -0.340529203414917
    z[2,3,0]  R462      3.1684383749961853e-01
    z[2,3,0]  R463      -2.8930708765983582e-01
    z[2,3,0]  R464      0.569987416267395
    z[2,3,0]  R465      -3.9689540863037109e-02
    z[2,3,0]  R466      3.4201338887214661e-01
    z[2,3,0]  R467      -4.3589100241661072e-01
    z[2,3,0]  R468      8.0050855875015259e-01
    z[2,3,0]  R469      1.6933538019657135e-02
    z[2,3,0]  R470      3.8401553034782410e-01
    z[2,3,0]  R471      6.3226169347763062e-01
    z[2,3,0]  R472      3.9538022875785828e-01
    z[2,3,0]  R473      4.5348340272903442e-01
    z[2,3,0]  R474      1.8556459248065948e-01
    z[2,3,0]  R475      2.8833302855491638e-01
    z[2,3,0]  R476      7.1162068843841553e-01
    z[2,3,0]  R477      9.5327025651931763e-01
    z[2,3,0]  R478      7.0742470026016235e-01
    z[2,3,0]  R479      0.798708438873291
    z[2,3,0]  R480      5.8215296268463135e-01
    z[2,3,0]  R481      8.0113774538040161e-01
    z[2,3,0]  R482      8.3893394470214844e-01
    z[2,3,0]  R483      7.2176802158355713e-01
    z[2,3,0]  R484      6.9075030088424683e-01
    z[2,3,0]  R485      6.9604158401489258e-01
    z[2,3,0]  R486      -4.7281497716903687e-01
    z[2,3,0]  R487      -6.8683397769927979e-01
    z[2,3,0]  R488      -6.7731253802776337e-02
    z[2,3,0]  R489      -3.9962872862815857e-01
    z[2,3,0]  R490      -1.8932853639125824e-01
    z[2,3,0]  R491      -4.4252589344978333e-01
    z[2,3,0]  R492      -4.3393689393997192e-01
    z[2,3,0]  R493      -2.8371793031692505e-01
    z[2,3,0]  R494      -3.8343551754951477e-01
    z[2,3,0]  R495      -3.8241106271743774e-01
    z[2,3,0]  R496      1.2241673469543457e-01
    z[2,3,0]  R497      -1.2061749584972858e-02
    z[2,3,0]  R498      -1.4337897300720215e-01
    z[2,3,0]  R499      -2.2681014239788055e-01
    z[2,3,0]  R500      -1.9298419356346130e-01
    z[2,3,0]  R501      -4.9005974084138870e-02
    z[2,3,0]  R502      -1.9798719882965088e-01
    z[2,3,0]  R503      5.4058995097875595e-02
    z[2,3,0]  R504      1.2684838473796844e-01
    z[2,3,0]  R505      -1.7259445041418076e-02
    z[2,3,0]  R506      1.5683120489120483e-01
    z[2,3,0]  R507      -5.1860684156417847e-01
    z[2,3,0]  R508      2.6655766367912292e-01
    z[2,3,0]  R509      -5.6426441669464111e-01
    z[2,3,0]  R510      2.5352329015731812e-02
    z[2,3,0]  R511      -6.1914050579071045e-01
    z[2,3,0]  R512      -3.5635665059089661e-01
    z[2,3,0]  R513      3.6339778453111649e-02
    z[2,3,0]  R514      7.9450950026512146e-02
    z[2,3,0]  R515      2.2689421474933624e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R447      -1
    z[2,3,1]  R448      1
    z[2,3,1]  R459      0.257255882024765
    z[2,3,1]  R460      2.1956029534339905e-01
    z[2,3,1]  R461      1.6878212988376617e-01
    z[2,3,1]  R462      1.8642768263816833e-01
    z[2,3,1]  R463      3.3697074651718140e-01
    z[2,3,1]  R464      1.5065012872219086e-01
    z[2,3,1]  R465      -1.5303435735404491e-02
    z[2,3,1]  R466      1.9988635182380676e-01
    z[2,3,1]  R467      3.0230081081390381e-01
    z[2,3,1]  R468      1.1791199445724487e-01
    z[2,3,1]  R469      8.6105978488922119e-01
    z[2,3,1]  R470      4.7929906845092773e-01
    z[2,3,1]  R471      -6.1272454261779785e-01
    z[2,3,1]  R472      -8.6557334661483765e-01
    z[2,3,1]  R473      -8.1219369173049927e-01
    z[2,3,1]  R474      2.1737320721149445e-01
    z[2,3,1]  R475      2.6539999246597290e-01
    z[2,3,1]  R476      -9.5694243907928467e-02
    z[2,3,1]  R477      -3.7281468510627747e-02
    z[2,3,1]  R478      2.7269739075563848e-04
    z[2,3,1]  R479      1.2312665581703186e-01
    z[2,3,1]  R480      2.2732684016227722e-01
    z[2,3,1]  R481      -2.7584299445152283e-01
    z[2,3,1]  R482      8.5411950945854187e-02
    z[2,3,1]  R483      9.4852922484278679e-03
    z[2,3,1]  R484      -3.8345813751220703e-01
    z[2,3,1]  R485      -1.6182261705398560e-01
    z[2,3,1]  R486      3.8585740327835083e-01
    z[2,3,1]  R487      2.5853881239891052e-01
    z[2,3,1]  R488      5.1659452915191650e-01
    z[2,3,1]  R489      6.1803042888641357e-01
    z[2,3,1]  R490      4.8582258820533752e-01
    z[2,3,1]  R491      2.7209252119064331e-01
    z[2,3,1]  R492      8.4815979003906250e-01
    z[2,3,1]  R493      0.591509997844696
    z[2,3,1]  R494      6.3983148336410522e-01
    z[2,3,1]  R495      4.4348701834678650e-01
    z[2,3,1]  R496      -0.985664963722229
    z[2,3,1]  R497      4.2809438705444336e-01
    z[2,3,1]  R498      -9.2774575948715210e-01
    z[2,3,1]  R499      -9.0466153621673584e-01
    z[2,3,1]  R500      -8.9581912755966187e-01
    z[2,3,1]  R501      -8.7088793516159058e-01
    z[2,3,1]  R502      -9.1231465339660645e-01
    z[2,3,1]  R503      -0.892479658126831
    z[2,3,1]  R504      -8.8815581798553467e-01
    z[2,3,1]  R505      -8.9752441644668579e-01
    z[2,3,1]  R506      0.728148341178894
    z[2,3,1]  R507      3.8828489184379578e-01
    z[2,3,1]  R508      7.8841805458068848e-01
    z[2,3,1]  R509      4.5100745558738708e-01
    z[2,3,1]  R510      0.782682478427887
    z[2,3,1]  R511      7.1726846508681774e-03
    z[2,3,1]  R512      -2.3392945528030396e-01
    z[2,3,1]  R513      -6.7416888475418091e-01
    z[2,3,1]  R514      -6.3650351762771606e-01
    z[2,3,1]  R515      -4.3019664287567139e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R449      -1
    z[2,3,2]  R450      1
    z[2,3,2]  R459      -4.0107178688049316e-01
    z[2,3,2]  R460      3.9156821370124817e-01
    z[2,3,2]  R461      1.8699896335601807e-01
    z[2,3,2]  R462      -2.6355883479118347e-01
    z[2,3,2]  R463      -1.6198235750198364e-01
    z[2,3,2]  R464      3.4033775329589844e-01
    z[2,3,2]  R465      2.8280389308929443e-01
    z[2,3,2]  R466      -4.8253139853477478e-01
    z[2,3,2]  R467      1.5344102680683136e-01
    z[2,3,2]  R468      0.482488751411438
    z[2,3,2]  R469      1.1112050712108612e-01
    z[2,3,2]  R470      4.8545765876770020e-01
    z[2,3,2]  R471      -2.5814312696456909e-01
    z[2,3,2]  R472      -1.0168453305959702e-01
    z[2,3,2]  R473      -3.0397295951843262e-01
    z[2,3,2]  R474      -4.5900654792785645e-01
    z[2,3,2]  R475      -4.2968934774398804e-01
    z[2,3,2]  R476      5.0105190277099609e-01
    z[2,3,2]  R477      1.6583970189094543e-01
    z[2,3,2]  R478      4.9155265092849731e-01
    z[2,3,2]  R479      3.6315330862998962e-01
    z[2,3,2]  R480      5.6071329116821289e-01
    z[2,3,2]  R481      3.0591517686843872e-01
    z[2,3,2]  R482      2.4037525057792664e-01
    z[2,3,2]  R483      0.488815575838089
    z[2,3,2]  R484      4.8330357670783997e-01
    z[2,3,2]  R485      6.2198311090469360e-01
    z[2,3,2]  R486      -6.1789786815643311e-01
    z[2,3,2]  R487      -4.6963772177696228e-01
    z[2,3,2]  R488      -5.0127208232879639e-01
    z[2,3,2]  R489      -5.5330657958984375e-01
    z[2,3,2]  R490      -3.1416711211204529e-01
    z[2,3,2]  R491      -1.7954818904399872e-01
    z[2,3,2]  R492      1.7211334407329559e-01
    z[2,3,2]  R493      -6.4731532335281372e-01
    z[2,3,2]  R494      -2.6995593309402466e-01
    z[2,3,2]  R495      -5.1188085228204727e-02
    z[2,3,2]  R496      0.0458839125931263
    z[2,3,2]  R497      0.326031357049942
    z[2,3,2]  R498      2.6491987705230713e-01
    z[2,3,2]  R499      2.7660864591598511e-01
    z[2,3,2]  R500      1.1854731291532516e-01
    z[2,3,2]  R501      -2.3694671690464020e-02
    z[2,3,2]  R502      1.4027518033981323e-01
    z[2,3,2]  R503      -9.1233126819133759e-02
    z[2,3,2]  R504      4.8379283398389816e-02
    z[2,3,2]  R505      -3.0592581257224083e-02
    z[2,3,2]  R506      -0.0733601376414299
    z[2,3,2]  R507      2.5493115186691284e-01
    z[2,3,2]  R508      -1.6764026880264282e-01
    z[2,3,2]  R509      4.0803188085556030e-01
    z[2,3,2]  R510      -1.4757739007472992e-01
    z[2,3,2]  R511      1.1929593980312347e-01
    z[2,3,2]  R512      -4.9659019708633423e-01
    z[2,3,2]  R513      8.0252867192029953e-03
    z[2,3,2]  R514      5.1690624095499516e-03
    z[2,3,2]  R515      -1.4292004704475403e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R451      -1
    z[2,3,3]  R452      1
    z[2,3,3]  R459      5.6083297729492188e-01
    z[2,3,3]  R460      0.0547274611890316
    z[2,3,3]  R461      0.602268397808075
    z[2,3,3]  R462      -6.5138369798660278e-01
    z[2,3,3]  R463      4.6961027383804321e-01
    z[2,3,3]  R464      -5.6371581554412842e-01
    z[2,3,3]  R465      -0.739917516708374
    z[2,3,3]  R466      -4.2029540985822678e-02
    z[2,3,3]  R467      -2.8136106207966805e-02
    z[2,3,3]  R468      -7.4998661875724792e-02
    z[2,3,3]  R469      -2.0571278035640717e-01
    z[2,3,3]  R470      -3.4350258111953735e-01
    z[2,3,3]  R471      2.0098045468330383e-01
    z[2,3,3]  R472      -1.7220930755138397e-01
    z[2,3,3]  R473      8.4163762629032135e-02
    z[2,3,3]  R474      -1.1817722022533417e-01
    z[2,3,3]  R475      5.4602071642875671e-02
    z[2,3,3]  R476      1.2336388975381851e-01
    z[2,3,3]  R477      1.4014837145805359e-01
    z[2,3,3]  R478      1.9738397002220154e-01
    z[2,3,3]  R479      -4.3479744344949722e-02
    z[2,3,3]  R480      2.2622174024581909e-01
    z[2,3,3]  R481      -2.4902520701289177e-02
    z[2,3,3]  R482      2.5310555100440979e-01
    z[2,3,3]  R483      3.1763198971748352e-01
    z[2,3,3]  R484      1.9800575077533722e-01
    z[2,3,3]  R485      -2.8173295781016350e-02
    z[2,3,3]  R486      2.2794772684574127e-01
    z[2,3,3]  R487      -0.0826336070895195
    z[2,3,3]  R488      4.6799725294113159e-01
    z[2,3,3]  R489      -2.6709496974945068e-01
    z[2,3,3]  R490      0.503420889377594
    z[2,3,3]  R491      -4.7182232141494751e-02
    z[2,3,3]  R492      -3.2185006886720657e-02
    z[2,3,3]  R493      1.1630264669656754e-01
    z[2,3,3]  R494      3.4428283572196960e-02
    z[2,3,3]  R495      -0.00514657236635685
    z[2,3,3]  R496      8.9136496186256409e-02
    z[2,3,3]  R497      -3.6063587665557861e-01
    z[2,3,3]  R498      -0.081561379134655
    z[2,3,3]  R499      8.1481322646141052e-02
    z[2,3,3]  R500      1.2045668065547943e-01
    z[2,3,3]  R501      3.1591024994850159e-01
    z[2,3,3]  R502      -7.1248807013034821e-02
    z[2,3,3]  R503      -1.9285000860691071e-02
    z[2,3,3]  R504      -1.8393030762672424e-01
    z[2,3,3]  R505      -1.1943616718053818e-01
    z[2,3,3]  R506      -3.4615222364664078e-02
    z[2,3,3]  R507      0.208840012550354
    z[2,3,3]  R508      -2.3434206843376160e-01
    z[2,3,3]  R509      -3.7884226441383362e-01
    z[2,3,3]  R510      -4.3607643246650696e-01
    z[2,3,3]  R511      1.5645003318786621e-01
    z[2,3,3]  R512      4.4591864943504333e-01
    z[2,3,3]  R513      -5.6606572866439819e-01
    z[2,3,3]  R514      -6.4688396453857422e-01
    z[2,3,3]  R515      -6.5649574995040894e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R453      -1
    z[2,3,4]  R454      1
    z[2,3,4]  R459      -1.2686930596828461e-01
    z[2,3,4]  R460      1.0851389169692993e-01
    z[2,3,4]  R461      -1.0209298878908157e-01
    z[2,3,4]  R462      5.3755092620849609e-01
    z[2,3,4]  R463      0.44412961602211
    z[2,3,4]  R464      -7.2428070008754730e-02
    z[2,3,4]  R465      2.4110174179077148e-01
    z[2,3,4]  R466      0.666729748249054
    z[2,3,4]  R467      -5.4639589786529541e-01
    z[2,3,4]  R468      1.5601858496665955e-01
    z[2,3,4]  R469      -2.3172209039330482e-03
    z[2,3,4]  R470      2.2902800142765045e-01
    z[2,3,4]  R471      -1.0874087363481522e-01
    z[2,3,4]  R472      -1.2333360314369202e-01
    z[2,3,4]  R473      -1.7300260066986084e-01
    z[2,3,4]  R474      -0.677017867565155
    z[2,3,4]  R475      -5.5533581972122192e-01
    z[2,3,4]  R476      -1.7499543726444244e-01
    z[2,3,4]  R477      -9.3153864145278931e-02
    z[2,3,4]  R478      -4.2097586393356323e-01
    z[2,3,4]  R479      -8.7057955563068390e-02
    z[2,3,4]  R480      1.9317786395549774e-01
    z[2,3,4]  R481      9.1338835656642914e-02
    z[2,3,4]  R482      3.4952649474143982e-01
    z[2,3,4]  R483      1.7258162796497345e-01
    z[2,3,4]  R484      2.2579045966267586e-02
    z[2,3,4]  R485      -4.4032309204339981e-02
    z[2,3,4]  R486      8.7571300566196442e-02
    z[2,3,4]  R487      1.6282857954502106e-01
    z[2,3,4]  R488      -2.4272072315216064e-01
    z[2,3,4]  R489      2.6515156030654907e-01
    z[2,3,4]  R490      -2.6562556624412537e-01
    z[2,3,4]  R491      -5.7785177230834961e-01
    z[2,3,4]  R492      -1.6454145312309265e-01
    z[2,3,4]  R493      -0.111277274787426
    z[2,3,4]  R494      -3.0620154738426208e-01
    z[2,3,4]  R495      -7.2088211774826050e-01
    z[2,3,4]  R496      1.2066298164427280e-02
    z[2,3,4]  R497      2.4230834096670151e-02
    z[2,3,4]  R498      0.0743400976061821
    z[2,3,4]  R499      1.9495931267738342e-01
    z[2,3,4]  R500      -5.6943674571812153e-03
    z[2,3,4]  R501      2.3302891850471497e-01
    z[2,3,4]  R502      -1.9806885719299316e-01
    z[2,3,4]  R503      1.6575929522514343e-01
    z[2,3,4]  R504      -2.6363892480731010e-02
    z[2,3,4]  R505      -3.8546428084373474e-01
    z[2,3,4]  R506      1.8515472114086151e-01
    z[2,3,4]  R507      -4.6308046579360962e-01
    z[2,3,4]  R508      1.9928932189941406e-01
    z[2,3,4]  R509      3.5109764337539673e-01
    z[2,3,4]  R510      -7.7538110315799713e-02
    z[2,3,4]  R511      5.2223944664001465e-01
    z[2,3,4]  R512      -2.9867190122604370e-01
    z[2,3,4]  R513      -2.8627860546112061e-01
    z[2,3,4]  R514      -9.1373048722743988e-02
    z[2,3,4]  R515      5.1102095842361450e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R455      -1
    z[2,3,5]  R456      1
    z[2,3,5]  R459      4.6073180437088013e-01
    z[2,3,5]  R460      -4.5443538576364517e-02
    z[2,3,5]  R461      -0.586475133895874
    z[2,3,5]  R462      8.9801521971821785e-03
    z[2,3,5]  R463      -1.6270147264003754e-01
    z[2,3,5]  R464      -1.6778273880481720e-01
    z[2,3,5]  R465      -1.2378364801406860e-01
    z[2,3,5]  R466      -4.0458962321281433e-01
    z[2,3,5]  R467      2.6042655110359192e-01
    z[2,3,5]  R468      -1.1376355588436127e-01
    z[2,3,5]  R469      -6.4084318000823259e-04
    z[2,3,5]  R470      9.5598847838118672e-04
    z[2,3,5]  R471      1.9212763011455536e-01
    z[2,3,5]  R472      1.8085126578807831e-01
    z[2,3,5]  R473      6.4689829945564270e-02
    z[2,3,5]  R474      -3.1809869408607483e-01
    z[2,3,5]  R475      -4.7258087992668152e-01
    z[2,3,5]  R476      3.9365947246551514e-01
    z[2,3,5]  R477      1.8414977192878723e-01
    z[2,3,5]  R478      1.3328801095485687e-01
    z[2,3,5]  R479      2.4706198275089264e-01
    z[2,3,5]  R480      4.0213245153427124e-01
    z[2,3,5]  R481      2.3150397837162018e-01
    z[2,3,5]  R482      5.8123461902141571e-02
    z[2,3,5]  R483      -1.1589889228343964e-01
    z[2,3,5]  R484      -2.0197346806526184e-01
    z[2,3,5]  R485      -3.0134108662605286e-01
    z[2,3,5]  R486      -4.1382014751434326e-01
    z[2,3,5]  R487      -1.6606800258159637e-01
    z[2,3,5]  R488      0.132082000374794
    z[2,3,5]  R489      -1.0103802382946014e-01
    z[2,3,5]  R490      -5.1464891433715820e-01
    z[2,3,5]  R491      -3.7848666310310364e-01
    z[2,3,5]  R492      1.1804620176553726e-01
    z[2,3,5]  R493      2.5822449475526810e-02
    z[2,3,5]  R494      2.5962832570075989e-01
    z[2,3,5]  R495      -3.1875947117805481e-01
    z[2,3,5]  R496      -5.5032365024089813e-02
    z[2,3,5]  R497      -6.8893593549728394e-01
    z[2,3,5]  R498      1.0112300515174866e-01
    z[2,3,5]  R499      8.0109424889087677e-02
    z[2,3,5]  R500      2.6628252863883972e-01
    z[2,3,5]  R501      2.9066300392150879e-01
    z[2,3,5]  R502      2.5254175066947937e-01
    z[2,3,5]  R503      3.9021271467208862e-01
    z[2,3,5]  R504      1.5079198777675629e-01
    z[2,3,5]  R505      1.1973618716001511e-01
    z[2,3,5]  R506      -3.1197625398635864e-01
    z[2,3,5]  R507      -8.2270748913288116e-02
    z[2,3,5]  R508      -3.3672001957893372e-01
    z[2,3,5]  R509      -2.1148182451725006e-01
    z[2,3,5]  R510      -3.8456863164901733e-01
    z[2,3,5]  R511      0.0923554003238678
    z[2,3,5]  R512      5.3185307979583740e-01
    z[2,3,5]  R513      -3.5393461585044861e-01
    z[2,3,5]  R514      -1.6921687126159668e-01
    z[2,3,5]  R515      -2.2447425127029419e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R457      -1
    z[2,3,6]  R458      1
    z[2,3,6]  R459      4.0673531591892242e-02
    z[2,3,6]  R460      -7.6985484361648560e-01
    z[2,3,6]  R461      3.2168385386466980e-01
    z[2,3,6]  R462      -2.8644195199012756e-01
    z[2,3,6]  R463      -5.7641750574111938e-01
    z[2,3,6]  R464      4.3060046434402466e-01
    z[2,3,6]  R465      -5.4523575305938721e-01
    z[2,3,6]  R466      1.5747912228107452e-02
    z[2,3,6]  R467      5.7263159751892090e-01
    z[2,3,6]  R468      -2.6377776265144348e-01
    z[2,3,6]  R469      4.5124056935310364e-01
    z[2,3,6]  R470      -4.6549594402313232e-01
    z[2,3,6]  R471      2.6276421546936035e-01
    z[2,3,6]  R472      -8.0889321863651276e-02
    z[2,3,6]  R473      -3.3113043755292892e-02
    z[2,3,6]  R474      -0.366226464509964
    z[2,3,6]  R475      -3.5648569464683533e-01
    z[2,3,6]  R476      1.8048782646656036e-01
    z[2,3,6]  R477      -1.2364926747977734e-02
    z[2,3,6]  R478      -1.5485283732414246e-01
    z[2,3,6]  R479      -3.8015130162239075e-01
    z[2,3,6]  R480      -2.1169923245906830e-01
    z[2,3,6]  R481      -3.5489144921302795e-01
    z[2,3,6]  R482      -2.0372769236564636e-01
    z[2,3,6]  R483      3.0969858169555664e-01
    z[2,3,6]  R484      -2.4845942854881287e-01
    z[2,3,6]  R485      9.4537958502769470e-02
    z[2,3,6]  R486      -1.2200947850942612e-01
    z[2,3,6]  R487      4.2418986558914185e-01
    z[2,3,6]  R488      -0.426483690738678
    z[2,3,6]  R489      -1.8254956230521202e-02
    z[2,3,6]  R490      2.0143781602382660e-01
    z[2,3,6]  R491      4.6744823455810547e-01
    z[2,3,6]  R492      -1.4372245967388153e-01
    z[2,3,6]  R493      3.5217520594596863e-01
    z[2,3,6]  R494      -4.5647022128105164e-01
    z[2,3,6]  R495      1.8208703398704529e-01
    z[2,3,6]  R496      -0.01593635417521
    z[2,3,6]  R497      -3.2406035065650940e-01
    z[2,3,6]  R498      1.6168814897537231e-01
    z[2,3,6]  R499      -5.0659310072660446e-02
    z[2,3,6]  R500      2.4650168418884277e-01
    z[2,3,6]  R501      2.1313808392733335e-03
    z[2,3,6]  R502      -2.6850234717130661e-02
    z[2,3,6]  R503      1.1009088903665543e-01
    z[2,3,6]  R504      3.6808228492736816e-01
    z[2,3,6]  R505      1.2661641836166382e-01
    z[2,3,6]  R506      -5.5408710241317749e-01
    z[2,3,6]  R507      -5.0046551227569580e-01
    z[2,3,6]  R508      -2.6688572764396667e-01
    z[2,3,6]  R509      -1.3869464397430420e-02
    z[2,3,6]  R510      1.4463216066360474e-01
    z[2,3,6]  R511      -5.4464846849441528e-01
    z[2,3,6]  R512      2.7732202783226967e-02
    z[2,3,6]  R513      1.2828026711940765e-01
    z[2,3,6]  R514      -3.6480379104614258e-01
    z[2,3,6]  R515      2.2492859512567520e-02
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R516      -1
    z[3,2,0]  R517      1
    z[3,2,0]  R530      7.1162068843841553e-01
    z[3,2,0]  R531      9.5327025651931763e-01
    z[3,2,0]  R532      7.0742470026016235e-01
    z[3,2,0]  R533      0.798708438873291
    z[3,2,0]  R534      5.8215296268463135e-01
    z[3,2,0]  R535      8.0113774538040161e-01
    z[3,2,0]  R536      8.3893394470214844e-01
    z[3,2,0]  R537      7.2176802158355713e-01
    z[3,2,0]  R538      6.9075030088424683e-01
    z[3,2,0]  R539      6.9604158401489258e-01
    z[3,2,0]  R540      -4.7281497716903687e-01
    z[3,2,0]  R541      -6.8683397769927979e-01
    z[3,2,0]  R542      -6.7731253802776337e-02
    z[3,2,0]  R543      -3.9962872862815857e-01
    z[3,2,0]  R544      -1.8932853639125824e-01
    z[3,2,0]  R545      -4.4252589344978333e-01
    z[3,2,0]  R546      -4.3393689393997192e-01
    z[3,2,0]  R547      -2.8371793031692505e-01
    z[3,2,0]  R548      -3.8343551754951477e-01
    z[3,2,0]  R549      -3.8241106271743774e-01
    z[3,2,0]  R550      1.2241673469543457e-01
    z[3,2,0]  R551      -1.2061749584972858e-02
    z[3,2,0]  R552      -1.4337897300720215e-01
    z[3,2,0]  R553      -2.2681014239788055e-01
    z[3,2,0]  R554      -1.9298419356346130e-01
    z[3,2,0]  R555      -4.9005974084138870e-02
    z[3,2,0]  R556      -1.9798719882965088e-01
    z[3,2,0]  R557      5.4058995097875595e-02
    z[3,2,0]  R558      1.2684838473796844e-01
    z[3,2,0]  R559      -1.7259445041418076e-02
    z[3,2,0]  R560      1.5683120489120483e-01
    z[3,2,0]  R561      -5.1860684156417847e-01
    z[3,2,0]  R562      2.6655766367912292e-01
    z[3,2,0]  R563      -5.6426441669464111e-01
    z[3,2,0]  R564      2.5352329015731812e-02
    z[3,2,0]  R565      -6.1914050579071045e-01
    z[3,2,0]  R566      -3.5635665059089661e-01
    z[3,2,0]  R567      3.6339778453111649e-02
    z[3,2,0]  R568      7.9450950026512146e-02
    z[3,2,0]  R569      2.2689421474933624e-01
    z[3,2,0]  R570      -4.7791567444801331e-01
    z[3,2,0]  R571      -4.3469026684761047e-01
    z[3,2,0]  R572      -0.340529203414917
    z[3,2,0]  R573      3.1684383749961853e-01
    z[3,2,0]  R574      -2.8930708765983582e-01
    z[3,2,0]  R575      0.569987416267395
    z[3,2,0]  R576      -3.9689540863037109e-02
    z[3,2,0]  R577      3.4201338887214661e-01
    z[3,2,0]  R578      -4.3589100241661072e-01
    z[3,2,0]  R579      8.0050855875015259e-01
    z[3,2,0]  R580      1.6933538019657135e-02
    z[3,2,0]  R581      3.8401553034782410e-01
    z[3,2,0]  R582      6.3226169347763062e-01
    z[3,2,0]  R583      3.9538022875785828e-01
    z[3,2,0]  R584      4.5348340272903442e-01
    z[3,2,0]  R585      1.8556459248065948e-01
    z[3,2,0]  R586      2.8833302855491638e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R518      -1
    z[3,2,1]  R519      1
    z[3,2,1]  R530      -9.5694243907928467e-02
    z[3,2,1]  R531      -3.7281468510627747e-02
    z[3,2,1]  R532      2.7269739075563848e-04
    z[3,2,1]  R533      1.2312665581703186e-01
    z[3,2,1]  R534      2.2732684016227722e-01
    z[3,2,1]  R535      -2.7584299445152283e-01
    z[3,2,1]  R536      8.5411950945854187e-02
    z[3,2,1]  R537      9.4852922484278679e-03
    z[3,2,1]  R538      -3.8345813751220703e-01
    z[3,2,1]  R539      -1.6182261705398560e-01
    z[3,2,1]  R540      3.8585740327835083e-01
    z[3,2,1]  R541      2.5853881239891052e-01
    z[3,2,1]  R542      5.1659452915191650e-01
    z[3,2,1]  R543      6.1803042888641357e-01
    z[3,2,1]  R544      4.8582258820533752e-01
    z[3,2,1]  R545      2.7209252119064331e-01
    z[3,2,1]  R546      8.4815979003906250e-01
    z[3,2,1]  R547      0.591509997844696
    z[3,2,1]  R548      6.3983148336410522e-01
    z[3,2,1]  R549      4.4348701834678650e-01
    z[3,2,1]  R550      -0.985664963722229
    z[3,2,1]  R551      4.2809438705444336e-01
    z[3,2,1]  R552      -9.2774575948715210e-01
    z[3,2,1]  R553      -9.0466153621673584e-01
    z[3,2,1]  R554      -8.9581912755966187e-01
    z[3,2,1]  R555      -8.7088793516159058e-01
    z[3,2,1]  R556      -9.1231465339660645e-01
    z[3,2,1]  R557      -0.892479658126831
    z[3,2,1]  R558      -8.8815581798553467e-01
    z[3,2,1]  R559      -8.9752441644668579e-01
    z[3,2,1]  R560      0.728148341178894
    z[3,2,1]  R561      3.8828489184379578e-01
    z[3,2,1]  R562      7.8841805458068848e-01
    z[3,2,1]  R563      4.5100745558738708e-01
    z[3,2,1]  R564      0.782682478427887
    z[3,2,1]  R565      7.1726846508681774e-03
    z[3,2,1]  R566      -2.3392945528030396e-01
    z[3,2,1]  R567      -6.7416888475418091e-01
    z[3,2,1]  R568      -6.3650351762771606e-01
    z[3,2,1]  R569      -4.3019664287567139e-01
    z[3,2,1]  R570      0.257255882024765
    z[3,2,1]  R571      2.1956029534339905e-01
    z[3,2,1]  R572      1.6878212988376617e-01
    z[3,2,1]  R573      1.8642768263816833e-01
    z[3,2,1]  R574      3.3697074651718140e-01
    z[3,2,1]  R575      1.5065012872219086e-01
    z[3,2,1]  R576      -1.5303435735404491e-02
    z[3,2,1]  R577      1.9988635182380676e-01
    z[3,2,1]  R578      3.0230081081390381e-01
    z[3,2,1]  R579      1.1791199445724487e-01
    z[3,2,1]  R580      8.6105978488922119e-01
    z[3,2,1]  R581      4.7929906845092773e-01
    z[3,2,1]  R582      -6.1272454261779785e-01
    z[3,2,1]  R583      -8.6557334661483765e-01
    z[3,2,1]  R584      -8.1219369173049927e-01
    z[3,2,1]  R585      2.1737320721149445e-01
    z[3,2,1]  R586      2.6539999246597290e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R520      -1
    z[3,2,2]  R521      1
    z[3,2,2]  R530      5.0105190277099609e-01
    z[3,2,2]  R531      1.6583970189094543e-01
    z[3,2,2]  R532      4.9155265092849731e-01
    z[3,2,2]  R533      3.6315330862998962e-01
    z[3,2,2]  R534      5.6071329116821289e-01
    z[3,2,2]  R535      3.0591517686843872e-01
    z[3,2,2]  R536      2.4037525057792664e-01
    z[3,2,2]  R537      0.488815575838089
    z[3,2,2]  R538      4.8330357670783997e-01
    z[3,2,2]  R539      6.2198311090469360e-01
    z[3,2,2]  R540      -6.1789786815643311e-01
    z[3,2,2]  R541      -4.6963772177696228e-01
    z[3,2,2]  R542      -5.0127208232879639e-01
    z[3,2,2]  R543      -5.5330657958984375e-01
    z[3,2,2]  R544      -3.1416711211204529e-01
    z[3,2,2]  R545      -1.7954818904399872e-01
    z[3,2,2]  R546      1.7211334407329559e-01
    z[3,2,2]  R547      -6.4731532335281372e-01
    z[3,2,2]  R548      -2.6995593309402466e-01
    z[3,2,2]  R549      -5.1188085228204727e-02
    z[3,2,2]  R550      0.0458839125931263
    z[3,2,2]  R551      0.326031357049942
    z[3,2,2]  R552      2.6491987705230713e-01
    z[3,2,2]  R553      2.7660864591598511e-01
    z[3,2,2]  R554      1.1854731291532516e-01
    z[3,2,2]  R555      -2.3694671690464020e-02
    z[3,2,2]  R556      1.4027518033981323e-01
    z[3,2,2]  R557      -9.1233126819133759e-02
    z[3,2,2]  R558      4.8379283398389816e-02
    z[3,2,2]  R559      -3.0592581257224083e-02
    z[3,2,2]  R560      -0.0733601376414299
    z[3,2,2]  R561      2.5493115186691284e-01
    z[3,2,2]  R562      -1.6764026880264282e-01
    z[3,2,2]  R563      4.0803188085556030e-01
    z[3,2,2]  R564      -1.4757739007472992e-01
    z[3,2,2]  R565      1.1929593980312347e-01
    z[3,2,2]  R566      -4.9659019708633423e-01
    z[3,2,2]  R567      8.0252867192029953e-03
    z[3,2,2]  R568      5.1690624095499516e-03
    z[3,2,2]  R569      -1.4292004704475403e-01
    z[3,2,2]  R570      -4.0107178688049316e-01
    z[3,2,2]  R571      3.9156821370124817e-01
    z[3,2,2]  R572      1.8699896335601807e-01
    z[3,2,2]  R573      -2.6355883479118347e-01
    z[3,2,2]  R574      -1.6198235750198364e-01
    z[3,2,2]  R575      3.4033775329589844e-01
    z[3,2,2]  R576      2.8280389308929443e-01
    z[3,2,2]  R577      -4.8253139853477478e-01
    z[3,2,2]  R578      1.5344102680683136e-01
    z[3,2,2]  R579      0.482488751411438
    z[3,2,2]  R580      1.1112050712108612e-01
    z[3,2,2]  R581      4.8545765876770020e-01
    z[3,2,2]  R582      -2.5814312696456909e-01
    z[3,2,2]  R583      -1.0168453305959702e-01
    z[3,2,2]  R584      -3.0397295951843262e-01
    z[3,2,2]  R585      -4.5900654792785645e-01
    z[3,2,2]  R586      -4.2968934774398804e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R522      -1
    z[3,2,3]  R523      1
    z[3,2,3]  R530      1.2336388975381851e-01
    z[3,2,3]  R531      1.4014837145805359e-01
    z[3,2,3]  R532      1.9738397002220154e-01
    z[3,2,3]  R533      -4.3479744344949722e-02
    z[3,2,3]  R534      2.2622174024581909e-01
    z[3,2,3]  R535      -2.4902520701289177e-02
    z[3,2,3]  R536      2.5310555100440979e-01
    z[3,2,3]  R537      3.1763198971748352e-01
    z[3,2,3]  R538      1.9800575077533722e-01
    z[3,2,3]  R539      -2.8173295781016350e-02
    z[3,2,3]  R540      2.2794772684574127e-01
    z[3,2,3]  R541      -0.0826336070895195
    z[3,2,3]  R542      4.6799725294113159e-01
    z[3,2,3]  R543      -2.6709496974945068e-01
    z[3,2,3]  R544      0.503420889377594
    z[3,2,3]  R545      -4.7182232141494751e-02
    z[3,2,3]  R546      -3.2185006886720657e-02
    z[3,2,3]  R547      1.1630264669656754e-01
    z[3,2,3]  R548      3.4428283572196960e-02
    z[3,2,3]  R549      -0.00514657236635685
    z[3,2,3]  R550      8.9136496186256409e-02
    z[3,2,3]  R551      -3.6063587665557861e-01
    z[3,2,3]  R552      -0.081561379134655
    z[3,2,3]  R553      8.1481322646141052e-02
    z[3,2,3]  R554      1.2045668065547943e-01
    z[3,2,3]  R555      3.1591024994850159e-01
    z[3,2,3]  R556      -7.1248807013034821e-02
    z[3,2,3]  R557      -1.9285000860691071e-02
    z[3,2,3]  R558      -1.8393030762672424e-01
    z[3,2,3]  R559      -1.1943616718053818e-01
    z[3,2,3]  R560      -3.4615222364664078e-02
    z[3,2,3]  R561      0.208840012550354
    z[3,2,3]  R562      -2.3434206843376160e-01
    z[3,2,3]  R563      -3.7884226441383362e-01
    z[3,2,3]  R564      -4.3607643246650696e-01
    z[3,2,3]  R565      1.5645003318786621e-01
    z[3,2,3]  R566      4.4591864943504333e-01
    z[3,2,3]  R567      -5.6606572866439819e-01
    z[3,2,3]  R568      -6.4688396453857422e-01
    z[3,2,3]  R569      -6.5649574995040894e-01
    z[3,2,3]  R570      5.6083297729492188e-01
    z[3,2,3]  R571      0.0547274611890316
    z[3,2,3]  R572      0.602268397808075
    z[3,2,3]  R573      -6.5138369798660278e-01
    z[3,2,3]  R574      4.6961027383804321e-01
    z[3,2,3]  R575      -5.6371581554412842e-01
    z[3,2,3]  R576      -0.739917516708374
    z[3,2,3]  R577      -4.2029540985822678e-02
    z[3,2,3]  R578      -2.8136106207966805e-02
    z[3,2,3]  R579      -7.4998661875724792e-02
    z[3,2,3]  R580      -2.0571278035640717e-01
    z[3,2,3]  R581      -3.4350258111953735e-01
    z[3,2,3]  R582      2.0098045468330383e-01
    z[3,2,3]  R583      -1.7220930755138397e-01
    z[3,2,3]  R584      8.4163762629032135e-02
    z[3,2,3]  R585      -1.1817722022533417e-01
    z[3,2,3]  R586      5.4602071642875671e-02
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R524      -1
    z[3,2,4]  R525      1
    z[3,2,4]  R530      -1.7499543726444244e-01
    z[3,2,4]  R531      -9.3153864145278931e-02
    z[3,2,4]  R532      -4.2097586393356323e-01
    z[3,2,4]  R533      -8.7057955563068390e-02
    z[3,2,4]  R534      1.9317786395549774e-01
    z[3,2,4]  R535      9.1338835656642914e-02
    z[3,2,4]  R536      3.4952649474143982e-01
    z[3,2,4]  R537      1.7258162796497345e-01
    z[3,2,4]  R538      2.2579045966267586e-02
    z[3,2,4]  R539      -4.4032309204339981e-02
    z[3,2,4]  R540      8.7571300566196442e-02
    z[3,2,4]  R541      1.6282857954502106e-01
    z[3,2,4]  R542      -2.4272072315216064e-01
    z[3,2,4]  R543      2.6515156030654907e-01
    z[3,2,4]  R544      -2.6562556624412537e-01
    z[3,2,4]  R545      -5.7785177230834961e-01
    z[3,2,4]  R546      -1.6454145312309265e-01
    z[3,2,4]  R547      -0.111277274787426
    z[3,2,4]  R548      -3.0620154738426208e-01
    z[3,2,4]  R549      -7.2088211774826050e-01
    z[3,2,4]  R550      1.2066298164427280e-02
    z[3,2,4]  R551      2.4230834096670151e-02
    z[3,2,4]  R552      0.0743400976061821
    z[3,2,4]  R553      1.9495931267738342e-01
    z[3,2,4]  R554      -5.6943674571812153e-03
    z[3,2,4]  R555      2.3302891850471497e-01
    z[3,2,4]  R556      -1.9806885719299316e-01
    z[3,2,4]  R557      1.6575929522514343e-01
    z[3,2,4]  R558      -2.6363892480731010e-02
    z[3,2,4]  R559      -3.8546428084373474e-01
    z[3,2,4]  R560      1.8515472114086151e-01
    z[3,2,4]  R561      -4.6308046579360962e-01
    z[3,2,4]  R562      1.9928932189941406e-01
    z[3,2,4]  R563      3.5109764337539673e-01
    z[3,2,4]  R564      -7.7538110315799713e-02
    z[3,2,4]  R565      5.2223944664001465e-01
    z[3,2,4]  R566      -2.9867190122604370e-01
    z[3,2,4]  R567      -2.8627860546112061e-01
    z[3,2,4]  R568      -9.1373048722743988e-02
    z[3,2,4]  R569      5.1102095842361450e-01
    z[3,2,4]  R570      -1.2686930596828461e-01
    z[3,2,4]  R571      1.0851389169692993e-01
    z[3,2,4]  R572      -1.0209298878908157e-01
    z[3,2,4]  R573      5.3755092620849609e-01
    z[3,2,4]  R574      0.44412961602211
    z[3,2,4]  R575      -7.2428070008754730e-02
    z[3,2,4]  R576      2.4110174179077148e-01
    z[3,2,4]  R577      0.666729748249054
    z[3,2,4]  R578      -5.4639589786529541e-01
    z[3,2,4]  R579      1.5601858496665955e-01
    z[3,2,4]  R580      -2.3172209039330482e-03
    z[3,2,4]  R581      2.2902800142765045e-01
    z[3,2,4]  R582      -1.0874087363481522e-01
    z[3,2,4]  R583      -1.2333360314369202e-01
    z[3,2,4]  R584      -1.7300260066986084e-01
    z[3,2,4]  R585      -0.677017867565155
    z[3,2,4]  R586      -5.5533581972122192e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R526      -1
    z[3,2,5]  R527      1
    z[3,2,5]  R530      3.9365947246551514e-01
    z[3,2,5]  R531      1.8414977192878723e-01
    z[3,2,5]  R532      1.3328801095485687e-01
    z[3,2,5]  R533      2.4706198275089264e-01
    z[3,2,5]  R534      4.0213245153427124e-01
    z[3,2,5]  R535      2.3150397837162018e-01
    z[3,2,5]  R536      5.8123461902141571e-02
    z[3,2,5]  R537      -1.1589889228343964e-01
    z[3,2,5]  R538      -2.0197346806526184e-01
    z[3,2,5]  R539      -3.0134108662605286e-01
    z[3,2,5]  R540      -4.1382014751434326e-01
    z[3,2,5]  R541      -1.6606800258159637e-01
    z[3,2,5]  R542      0.132082000374794
    z[3,2,5]  R543      -1.0103802382946014e-01
    z[3,2,5]  R544      -5.1464891433715820e-01
    z[3,2,5]  R545      -3.7848666310310364e-01
    z[3,2,5]  R546      1.1804620176553726e-01
    z[3,2,5]  R547      2.5822449475526810e-02
    z[3,2,5]  R548      2.5962832570075989e-01
    z[3,2,5]  R549      -3.1875947117805481e-01
    z[3,2,5]  R550      -5.5032365024089813e-02
    z[3,2,5]  R551      -6.8893593549728394e-01
    z[3,2,5]  R552      1.0112300515174866e-01
    z[3,2,5]  R553      8.0109424889087677e-02
    z[3,2,5]  R554      2.6628252863883972e-01
    z[3,2,5]  R555      2.9066300392150879e-01
    z[3,2,5]  R556      2.5254175066947937e-01
    z[3,2,5]  R557      3.9021271467208862e-01
    z[3,2,5]  R558      1.5079198777675629e-01
    z[3,2,5]  R559      1.1973618716001511e-01
    z[3,2,5]  R560      -3.1197625398635864e-01
    z[3,2,5]  R561      -8.2270748913288116e-02
    z[3,2,5]  R562      -3.3672001957893372e-01
    z[3,2,5]  R563      -2.1148182451725006e-01
    z[3,2,5]  R564      -3.8456863164901733e-01
    z[3,2,5]  R565      0.0923554003238678
    z[3,2,5]  R566      5.3185307979583740e-01
    z[3,2,5]  R567      -3.5393461585044861e-01
    z[3,2,5]  R568      -1.6921687126159668e-01
    z[3,2,5]  R569      -2.2447425127029419e-01
    z[3,2,5]  R570      4.6073180437088013e-01
    z[3,2,5]  R571      -4.5443538576364517e-02
    z[3,2,5]  R572      -0.586475133895874
    z[3,2,5]  R573      8.9801521971821785e-03
    z[3,2,5]  R574      -1.6270147264003754e-01
    z[3,2,5]  R575      -1.6778273880481720e-01
    z[3,2,5]  R576      -1.2378364801406860e-01
    z[3,2,5]  R577      -4.0458962321281433e-01
    z[3,2,5]  R578      2.6042655110359192e-01
    z[3,2,5]  R579      -1.1376355588436127e-01
    z[3,2,5]  R580      -6.4084318000823259e-04
    z[3,2,5]  R581      9.5598847838118672e-04
    z[3,2,5]  R582      1.9212763011455536e-01
    z[3,2,5]  R583      1.8085126578807831e-01
    z[3,2,5]  R584      6.4689829945564270e-02
    z[3,2,5]  R585      -3.1809869408607483e-01
    z[3,2,5]  R586      -4.7258087992668152e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R528      -1
    z[3,2,6]  R529      1
    z[3,2,6]  R530      1.8048782646656036e-01
    z[3,2,6]  R531      -1.2364926747977734e-02
    z[3,2,6]  R532      -1.5485283732414246e-01
    z[3,2,6]  R533      -3.8015130162239075e-01
    z[3,2,6]  R534      -2.1169923245906830e-01
    z[3,2,6]  R535      -3.5489144921302795e-01
    z[3,2,6]  R536      -2.0372769236564636e-01
    z[3,2,6]  R537      3.0969858169555664e-01
    z[3,2,6]  R538      -2.4845942854881287e-01
    z[3,2,6]  R539      9.4537958502769470e-02
    z[3,2,6]  R540      -1.2200947850942612e-01
    z[3,2,6]  R541      4.2418986558914185e-01
    z[3,2,6]  R542      -0.426483690738678
    z[3,2,6]  R543      -1.8254956230521202e-02
    z[3,2,6]  R544      2.0143781602382660e-01
    z[3,2,6]  R545      4.6744823455810547e-01
    z[3,2,6]  R546      -1.4372245967388153e-01
    z[3,2,6]  R547      3.5217520594596863e-01
    z[3,2,6]  R548      -4.5647022128105164e-01
    z[3,2,6]  R549      1.8208703398704529e-01
    z[3,2,6]  R550      -0.01593635417521
    z[3,2,6]  R551      -3.2406035065650940e-01
    z[3,2,6]  R552      1.6168814897537231e-01
    z[3,2,6]  R553      -5.0659310072660446e-02
    z[3,2,6]  R554      2.4650168418884277e-01
    z[3,2,6]  R555      2.1313808392733335e-03
    z[3,2,6]  R556      -2.6850234717130661e-02
    z[3,2,6]  R557      1.1009088903665543e-01
    z[3,2,6]  R558      3.6808228492736816e-01
    z[3,2,6]  R559      1.2661641836166382e-01
    z[3,2,6]  R560      -5.5408710241317749e-01
    z[3,2,6]  R561      -5.0046551227569580e-01
    z[3,2,6]  R562      -2.6688572764396667e-01
    z[3,2,6]  R563      -1.3869464397430420e-02
    z[3,2,6]  R564      1.4463216066360474e-01
    z[3,2,6]  R565      -5.4464846849441528e-01
    z[3,2,6]  R566      2.7732202783226967e-02
    z[3,2,6]  R567      1.2828026711940765e-01
    z[3,2,6]  R568      -3.6480379104614258e-01
    z[3,2,6]  R569      2.2492859512567520e-02
    z[3,2,6]  R570      4.0673531591892242e-02
    z[3,2,6]  R571      -7.6985484361648560e-01
    z[3,2,6]  R572      3.2168385386466980e-01
    z[3,2,6]  R573      -2.8644195199012756e-01
    z[3,2,6]  R574      -5.7641750574111938e-01
    z[3,2,6]  R575      4.3060046434402466e-01
    z[3,2,6]  R576      -5.4523575305938721e-01
    z[3,2,6]  R577      1.5747912228107452e-02
    z[3,2,6]  R578      5.7263159751892090e-01
    z[3,2,6]  R579      -2.6377776265144348e-01
    z[3,2,6]  R580      4.5124056935310364e-01
    z[3,2,6]  R581      -4.6549594402313232e-01
    z[3,2,6]  R582      2.6276421546936035e-01
    z[3,2,6]  R583      -8.0889321863651276e-02
    z[3,2,6]  R584      -3.3113043755292892e-02
    z[3,2,6]  R585      -0.366226464509964
    z[3,2,6]  R586      -3.5648569464683533e-01
    z[2,8,0]  R20       -1
    z[2,8,0]  R74       1
    z[2,8,0]  R587      -1
    z[2,8,0]  R588      1
    z[2,8,0]  R601      -4.7791567444801331e-01
    z[2,8,0]  R602      -4.3469026684761047e-01
    z[2,8,0]  R603      -0.340529203414917
    z[2,8,0]  R604      3.1684383749961853e-01
    z[2,8,0]  R605      -2.8930708765983582e-01
    z[2,8,0]  R606      0.569987416267395
    z[2,8,0]  R607      -3.9689540863037109e-02
    z[2,8,0]  R608      3.4201338887214661e-01
    z[2,8,0]  R609      -4.3589100241661072e-01
    z[2,8,0]  R610      8.0050855875015259e-01
    z[2,8,0]  R611      1.6933538019657135e-02
    z[2,8,0]  R612      3.8401553034782410e-01
    z[2,8,0]  R613      6.3226169347763062e-01
    z[2,8,0]  R614      3.9538022875785828e-01
    z[2,8,0]  R615      4.5348340272903442e-01
    z[2,8,0]  R616      1.8556459248065948e-01
    z[2,8,0]  R617      2.8833302855491638e-01
    z[2,8,0]  R618      7.0530152320861816e-01
    z[2,8,0]  R619      8.8695132732391357e-01
    z[2,8,0]  R620      7.5331693887710571e-01
    z[2,8,0]  R621      9.0934127569198608e-01
    z[2,8,0]  R622      8.2864642143249512e-01
    z[2,8,0]  R623      9.4234520196914673e-01
    z[2,8,0]  R624      9.3040871620178223e-01
    z[2,8,0]  R625      0.736838161945343
    z[2,8,0]  R626      8.6052078008651733e-01
    z[2,8,0]  R627      0.713066577911377
    z[2,8,0]  R628      1.3651348650455475e-01
    z[2,8,0]  R629      -3.2548218965530396e-02
    z[2,8,0]  R630      -4.8324260115623474e-01
    z[2,8,0]  R631      4.2534127831459045e-02
    z[2,8,0]  R632      -2.1742577850818634e-01
    z[2,8,0]  R633      -5.1593035459518433e-01
    z[2,8,0]  R634      -3.0395722389221191e-01
    z[2,8,0]  R635      -7.2562158107757568e-02
    z[2,8,0]  R636      -5.1913022994995117e-01
    z[2,8,0]  R637      -1.5697129070758820e-01
    z[2,8,0]  R638      -3.2283249497413635e-01
    z[2,8,0]  R639      -0.721881091594696
    z[2,8,0]  R640      -2.3561200499534607e-01
    z[2,8,0]  R641      -2.9592856764793396e-01
    z[2,8,0]  R642      -2.5959175825119019e-01
    z[2,8,0]  R643      -2.2420540452003479e-01
    z[2,8,0]  R644      -4.0958243608474731e-01
    z[2,8,0]  R645      -0.331001877784729
    z[2,8,0]  R646      -2.5792077183723450e-01
    z[2,8,0]  R647      -1.9591730833053589e-01
    z[2,8,0]  R648      -2.6988866925239563e-01
    z[2,8,0]  R649      -6.8003219366073608e-01
    z[2,8,0]  R650      -6.5597808361053467e-01
    z[2,8,0]  R651      -8.8376182317733765e-01
    z[2,8,0]  R652      -0.755744218826294
    z[2,8,0]  R653      -8.1956106424331665e-01
    z[2,8,0]  R654      -6.7751920223236084e-01
    z[2,8,0]  R655      -6.9661718606948853e-01
    z[2,8,0]  R656      -5.9385901689529419e-01
    z[2,8,0]  R657      -5.2864837646484375e-01
    z[2,8,0]  R658      7.0176303386688232e-02
    z[2,8,0]  R659      -0.313693106174469
    z[2,8,0]  R660      -4.1877318173646927e-02
    z[2,8,0]  R661      -8.0878752470016479e-01
    z[2,8,0]  R662      -1.6961207985877991e-01
    z[2,8,0]  R663      -8.6870723962783813e-01
    z[2,8,0]  R664      -6.7262911796569824e-01
    z[2,8,0]  R665      -8.4285312891006470e-01
    z[2,8,0]  R666      -2.3766933381557465e-01
    z[2,8,0]  R667      -9.1773825883865356e-01
    z[2,8,1]  R21       -1
    z[2,8,1]  R75       1
    z[2,8,1]  R589      -1
    z[2,8,1]  R590      1
    z[2,8,1]  R601      0.257255882024765
    z[2,8,1]  R602      2.1956029534339905e-01
    z[2,8,1]  R603      1.6878212988376617e-01
    z[2,8,1]  R604      1.8642768263816833e-01
    z[2,8,1]  R605      3.3697074651718140e-01
    z[2,8,1]  R606      1.5065012872219086e-01
    z[2,8,1]  R607      -1.5303435735404491e-02
    z[2,8,1]  R608      1.9988635182380676e-01
    z[2,8,1]  R609      3.0230081081390381e-01
    z[2,8,1]  R610      1.1791199445724487e-01
    z[2,8,1]  R611      8.6105978488922119e-01
    z[2,8,1]  R612      4.7929906845092773e-01
    z[2,8,1]  R613      -6.1272454261779785e-01
    z[2,8,1]  R614      -8.6557334661483765e-01
    z[2,8,1]  R615      -8.1219369173049927e-01
    z[2,8,1]  R616      2.1737320721149445e-01
    z[2,8,1]  R617      2.6539999246597290e-01
    z[2,8,1]  R618      1.9630730152130127e-02
    z[2,8,1]  R619      -7.9196922481060028e-02
    z[2,8,1]  R620      -1.9613333046436310e-02
    z[2,8,1]  R621      1.1365023255348206e-01
    z[2,8,1]  R622      -3.1931233406066895e-01
    z[2,8,1]  R623      -1.1122805625200272e-01
    z[2,8,1]  R624      1.1261923238635063e-02
    z[2,8,1]  R625      -2.4862538278102875e-01
    z[2,8,1]  R626      -5.1845584064722061e-02
    z[2,8,1]  R627      -0.0972457155585289
    z[2,8,1]  R628      8.0286830663681030e-01
    z[2,8,1]  R629      5.8779406547546387e-01
    z[2,8,1]  R630      5.0273990631103516e-01
    z[2,8,1]  R631      4.3708527088165283e-01
    z[2,8,1]  R632      4.7819891571998596e-01
    z[2,8,1]  R633      4.5853444933891296e-01
    z[2,8,1]  R634      4.3781113624572754e-01
    z[2,8,1]  R635      5.7233953475952148e-01
    z[2,8,1]  R636      5.0355130434036255e-01
    z[2,8,1]  R637      3.4641581773757935e-01
    z[2,8,1]  R638      -9.3039542436599731e-01
    z[2,8,1]  R639      2.0746754109859467e-01
    z[2,8,1]  R640      -8.8955307006835938e-01
    z[2,8,1]  R641      -0.88219153881073
    z[2,8,1]  R642      -8.5865569114685059e-01
    z[2,8,1]  R643      -9.2376661300659180e-01
    z[2,8,1]  R644      -8.7629443407058716e-01
    z[2,8,1]  R645      -8.7441927194595337e-01
    z[2,8,1]  R646      -8.8528978824615479e-01
    z[2,8,1]  R647      -8.8353222608566284e-01
    z[2,8,1]  R648      -6.1534738540649414e-01
    z[2,8,1]  R649      1.6282060742378235e-01
    z[2,8,1]  R650      -4.4630587100982666e-01
    z[2,8,1]  R651      -1.6083197295665741e-01
    z[2,8,1]  R652      -6.9364093244075775e-02
    z[2,8,1]  R653      -2.9856148362159729e-01
    z[2,8,1]  R654      -1.5196952223777771e-01
    z[2,8,1]  R655      -1.4520509541034698e-01
    z[2,8,1]  R656      -1.8252392113208771e-01
    z[2,8,1]  R657      3.3651031553745270e-02
    z[2,8,1]  R658      -3.3370348811149597e-01
    z[2,8,1]  R659      -6.3353508710861206e-01
    z[2,8,1]  R660      -9.1670429706573486e-01
    z[2,8,1]  R661      2.0634920895099640e-01
    z[2,8,1]  R662      -0.873768150806427
    z[2,8,1]  R663      2.2565890848636627e-01
    z[2,8,1]  R664      3.6477770656347275e-02
    z[2,8,1]  R665      -1.0097629576921463e-01
    z[2,8,1]  R666      -8.6336147785186768e-01
    z[2,8,1]  R667      1.5227134525775909e-01
    z[2,8,2]  R22       -1
    z[2,8,2]  R76       1
    z[2,8,2]  R591      -1
    z[2,8,2]  R592      1
    z[2,8,2]  R601      -4.0107178688049316e-01
    z[2,8,2]  R602      3.9156821370124817e-01
    z[2,8,2]  R603      1.8699896335601807e-01
    z[2,8,2]  R604      -2.6355883479118347e-01
    z[2,8,2]  R605      -1.6198235750198364e-01
    z[2,8,2]  R606      3.4033775329589844e-01
    z[2,8,2]  R607      2.8280389308929443e-01
    z[2,8,2]  R608      -4.8253139853477478e-01
    z[2,8,2]  R609      1.5344102680683136e-01
    z[2,8,2]  R610      0.482488751411438
    z[2,8,2]  R611      1.1112050712108612e-01
    z[2,8,2]  R612      4.8545765876770020e-01
    z[2,8,2]  R613      -2.5814312696456909e-01
    z[2,8,2]  R614      -1.0168453305959702e-01
    z[2,8,2]  R615      -3.0397295951843262e-01
    z[2,8,2]  R616      -4.5900654792785645e-01
    z[2,8,2]  R617      -4.2968934774398804e-01
    z[2,8,2]  R618      0.508542537689209
    z[2,8,2]  R619      3.8803330063819885e-01
    z[2,8,2]  R620      4.5523053407669067e-01
    z[2,8,2]  R621      1.8744862079620361e-01
    z[2,8,2]  R622      3.4964513778686523e-01
    z[2,8,2]  R623      1.0699527338147163e-02
    z[2,8,2]  R624      2.3295685648918152e-01
    z[2,8,2]  R625      5.0984853506088257e-01
    z[2,8,2]  R626      6.4617067575454712e-02
    z[2,8,2]  R627      4.4522005319595337e-01
    z[2,8,2]  R628      -2.8069171309471130e-01
    z[2,8,2]  R629      -2.6032933592796326e-01
    z[2,8,2]  R630      -4.4359427690505981e-01
    z[2,8,2]  R631      -6.2107211351394653e-01
    z[2,8,2]  R632      -3.7472090125083923e-01
    z[2,8,2]  R633      -0.568618893623352
    z[2,8,2]  R634      -1.7549788951873779e-01
    z[2,8,2]  R635      -3.2367938756942749e-01
    z[2,8,2]  R636      -5.3947108983993530e-01
    z[2,8,2]  R637      -7.0862895250320435e-01
    z[2,8,2]  R638      -0.0657036080956459
    z[2,8,2]  R639      0.23386250436306
    z[2,8,2]  R640      1.0245457291603088e-01
    z[2,8,2]  R641      -2.5030821561813354e-01
    z[2,8,2]  R642      -3.6769038438796997e-01
    z[2,8,2]  R643      -1.3862235844135284e-01
    z[2,8,2]  R644      -7.5600305572152138e-03
    z[2,8,2]  R645      -1.4240401983261108e-01
    z[2,8,2]  R646      -3.8570471107959747e-02
    z[2,8,2]  R647      -3.9163712412118912e-02
    z[2,8,2]  R648      1.0111314058303833e-01
    z[2,8,2]  R649      -2.2710916399955750e-01
    z[2,8,2]  R650      -2.7996638417243958e-01
    z[2,8,2]  R651      5.8180510997772217e-02
    z[2,8,2]  R652      -1.9354438781738281e-01
    z[2,8,2]  R653      0.0391550213098526
    z[2,8,2]  R654      -1.0665337741374969e-01
    z[2,8,2]  R655      9.8015762865543365e-02
    z[2,8,2]  R656      -1.9831072539091110e-02
    z[2,8,2]  R657      -8.0827414989471436e-02
    z[2,8,2]  R658      0.0355074517428875
    z[2,8,2]  R659      3.8741311430931091e-01
    z[2,8,2]  R660      -1.0585274547338486e-01
    z[2,8,2]  R661      -3.9191875606775284e-02
    z[2,8,2]  R662      3.4256509970873594e-03
    z[2,8,2]  R663      2.8114444017410278e-01
    z[2,8,2]  R664      -1.0289106518030167e-01
    z[2,8,2]  R665      -1.0542208328843117e-02
    z[2,8,2]  R666      -2.1782732009887695e-01
    z[2,8,2]  R667      8.0047480762004852e-02
    z[2,8,3]  R23       -1
    z[2,8,3]  R77       1
    z[2,8,3]  R593      -1
    z[2,8,3]  R594      1
    z[2,8,3]  R601      5.6083297729492188e-01
    z[2,8,3]  R602      0.0547274611890316
    z[2,8,3]  R603      0.602268397808075
    z[2,8,3]  R604      -6.5138369798660278e-01
    z[2,8,3]  R605      4.6961027383804321e-01
    z[2,8,3]  R606      -5.6371581554412842e-01
    z[2,8,3]  R607      -0.739917516708374
    z[2,8,3]  R608      -4.2029540985822678e-02
    z[2,8,3]  R609      -2.8136106207966805e-02
    z[2,8,3]  R610      -7.4998661875724792e-02
    z[2,8,3]  R611      -2.0571278035640717e-01
    z[2,8,3]  R612      -3.4350258111953735e-01
    z[2,8,3]  R613      2.0098045468330383e-01
    z[2,8,3]  R614      -1.7220930755138397e-01
    z[2,8,3]  R615      8.4163762629032135e-02
    z[2,8,3]  R616      -1.1817722022533417e-01
    z[2,8,3]  R617      5.4602071642875671e-02
    z[2,8,3]  R618      2.5739121437072754e-01
    z[2,8,3]  R619      1.6530117392539978e-01
    z[2,8,3]  R620      1.7963266372680664e-01
    z[2,8,3]  R621      1.3234589993953705e-01
    z[2,8,3]  R622      -4.1194036602973938e-02
    z[2,8,3]  R623      1.3977135717868805e-01
    z[2,8,3]  R624      -0.0847676619887352
    z[2,8,3]  R625      3.2371747493743896e-01
    z[2,8,3]  R626      1.3982596993446350e-01
    z[2,8,3]  R627      4.7496250271797180e-01
    z[2,8,3]  R628      7.1082182228565216e-02
    z[2,8,3]  R629      5.2524650096893311e-01
    z[2,8,3]  R630      4.5181828737258911e-01
    z[2,8,3]  R631      3.5764062404632568e-01
    z[2,8,3]  R632      2.4676126241683960e-01
    z[2,8,3]  R633      1.6248725354671478e-01
    z[2,8,3]  R634      3.5538071393966675e-01
    z[2,8,3]  R635      4.9725881218910217e-01
    z[2,8,3]  R636      1.0206269472837448e-01
    z[2,8,3]  R637      2.6244139671325684e-01
    z[2,8,3]  R638      7.6342053711414337e-02
    z[2,8,3]  R639      -5.8134537935256958e-01
    z[2,8,3]  R640      -2.5366422533988953e-01
    z[2,8,3]  R641      -1.7145574092864990e-01
    z[2,8,3]  R642      0.0885215699672699
    z[2,8,3]  R643      1.3964995741844177e-01
    z[2,8,3]  R644      -1.9695621728897095e-01
    z[2,8,3]  R645      -6.9412998855113983e-02
    z[2,8,3]  R646      -1.7963644862174988e-01
    z[2,8,3]  R647      -1.2966012954711914e-01
    z[2,8,3]  R648      6.1762750148773193e-01
    z[2,8,3]  R649      -6.0979276895523071e-01
    z[2,8,3]  R650      -7.1638122200965881e-02
    z[2,8,3]  R651      -3.3242511749267578e-01
    z[2,8,3]  R652      -5.5677896738052368e-01
    z[2,8,3]  R653      -3.1964725255966187e-01
    z[2,8,3]  R654      -0.56904536485672
    z[2,8,3]  R655      -4.8577833175659180e-01
    z[2,8,3]  R656      -4.5397144556045532e-01
    z[2,8,3]  R657      -6.0044860839843750e-01
    z[2,8,3]  R658      4.0795540809631348e-01
    z[2,8,3]  R659      1.8678598105907440e-01
    z[2,8,3]  R660      1.8172113597393036e-01
    z[2,8,3]  R661      -0.290932834148407
    z[2,8,3]  R662      6.5892942249774933e-02
    z[2,8,3]  R663      -2.2303043305873871e-01
    z[2,8,3]  R664      -6.0945552587509155e-01
    z[2,8,3]  R665      -2.3416090011596680e-01
    z[2,8,3]  R666      -1.4389619231224060e-01
    z[2,8,3]  R667      -1.4314334094524384e-01
    z[2,8,4]  R24       -1
    z[2,8,4]  R78       1
    z[2,8,4]  R595      -1
    z[2,8,4]  R596      1
    z[2,8,4]  R601      -1.2686930596828461e-01
    z[2,8,4]  R602      1.0851389169692993e-01
    z[2,8,4]  R603      -1.0209298878908157e-01
    z[2,8,4]  R604      5.3755092620849609e-01
    z[2,8,4]  R605      0.44412961602211
    z[2,8,4]  R606      -7.2428070008754730e-02
    z[2,8,4]  R607      2.4110174179077148e-01
    z[2,8,4]  R608      0.666729748249054
    z[2,8,4]  R609      -5.4639589786529541e-01
    z[2,8,4]  R610      1.5601858496665955e-01
    z[2,8,4]  R611      -2.3172209039330482e-03
    z[2,8,4]  R612      2.2902800142765045e-01
    z[2,8,4]  R613      -1.0874087363481522e-01
    z[2,8,4]  R614      -1.2333360314369202e-01
    z[2,8,4]  R615      -1.7300260066986084e-01
    z[2,8,4]  R616      -0.677017867565155
    z[2,8,4]  R617      -5.5533581972122192e-01
    z[2,8,4]  R618      -1.6608202457427979e-01
    z[2,8,4]  R619      1.4930222928524017e-01
    z[2,8,4]  R620      1.0916792601346970e-01
    z[2,8,4]  R621      1.6858358681201935e-01
    z[2,8,4]  R622      1.7198072746396065e-02
    z[2,8,4]  R623      -3.4115172922611237e-02
    z[2,8,4]  R624      -1.9708819687366486e-02
    z[2,8,4]  R625      1.2298287451267242e-01
    z[2,8,4]  R626      -0.27997025847435
    z[2,8,4]  R627      -1.6390171647071838e-01
    z[2,8,4]  R628      -1.8132030963897705e-01
    z[2,8,4]  R629      1.9520732760429382e-01
    z[2,8,4]  R630      -1.9591921567916870e-01
    z[2,8,4]  R631      -3.0801620334386826e-02
    z[2,8,4]  R632      -6.9214117527008057e-01
    z[2,8,4]  R633      -2.2359889745712280e-01
    z[2,8,4]  R634      2.5557526946067810e-01
    z[2,8,4]  R635      -2.2692269086837769e-01
    z[2,8,4]  R636      3.4116649627685547e-01
    z[2,8,4]  R637      2.1558435261249542e-01
    z[2,8,4]  R638      9.2774204909801483e-02
    z[2,8,4]  R639      -8.5824113339185715e-03
    z[2,8,4]  R640      8.9389160275459290e-02
    z[2,8,4]  R641      1.5136560425162315e-02
    z[2,8,4]  R642      7.6929312199354172e-03
    z[2,8,4]  R643      -0.0321052223443985
    z[2,8,4]  R644      -7.9387754201889038e-02
    z[2,8,4]  R645      -1.2461936473846436e-01
    z[2,8,4]  R646      -1.1244063824415207e-01
    z[2,8,4]  R647      7.1235232055187225e-02
    z[2,8,4]  R648      3.2721456140279770e-02
    z[2,8,4]  R649      2.3946096003055573e-01
    z[2,8,4]  R650      3.6254864931106567e-01
    z[2,8,4]  R651      -3.1196763738989830e-02
    z[2,8,4]  R652      4.7189682722091675e-02
    z[2,8,4]  R653      -4.9045007675886154e-02
    z[2,8,4]  R654      2.2894616425037384e-01
    z[2,8,4]  R655      2.1908958256244659e-01
    z[2,8,4]  R656      1.0117696970701218e-01
    z[2,8,4]  R657      3.4478890895843506e-01
    z[2,8,4]  R658      5.3812485933303833e-01
    z[2,8,4]  R659      2.0495966076850891e-01
    z[2,8,4]  R660      -1.7710077762603760e-01
    z[2,8,4]  R661      4.3691709637641907e-01
    z[2,8,4]  R662      -9.8659023642539978e-03
    z[2,8,4]  R663      6.8453907966613770e-02
    z[2,8,4]  R664      1.5254114568233490e-01
    z[2,8,4]  R665      -3.0586105585098267e-01
    z[2,8,4]  R666      -2.0717906951904297e-01
    z[2,8,4]  R667      -8.4953360259532928e-02
    z[2,8,5]  R25       -1
    z[2,8,5]  R79       1
    z[2,8,5]  R597      -1
    z[2,8,5]  R598      1
    z[2,8,5]  R601      4.6073180437088013e-01
    z[2,8,5]  R602      -4.5443538576364517e-02
    z[2,8,5]  R603      -0.586475133895874
    z[2,8,5]  R604      8.9801521971821785e-03
    z[2,8,5]  R605      -1.6270147264003754e-01
    z[2,8,5]  R606      -1.6778273880481720e-01
    z[2,8,5]  R607      -1.2378364801406860e-01
    z[2,8,5]  R608      -4.0458962321281433e-01
    z[2,8,5]  R609      2.6042655110359192e-01
    z[2,8,5]  R610      -1.1376355588436127e-01
    z[2,8,5]  R611      -6.4084318000823259e-04
    z[2,8,5]  R612      9.5598847838118672e-04
    z[2,8,5]  R613      1.9212763011455536e-01
    z[2,8,5]  R614      1.8085126578807831e-01
    z[2,8,5]  R615      6.4689829945564270e-02
    z[2,8,5]  R616      -3.1809869408607483e-01
    z[2,8,5]  R617      -4.7258087992668152e-01
    z[2,8,5]  R618      3.7518101930618286e-01
    z[2,8,5]  R619      -6.0493446653708816e-04
    z[2,8,5]  R620      2.2294235229492188e-01
    z[2,8,5]  R621      2.8060016036033630e-01
    z[2,8,5]  R622      2.0822128653526306e-01
    z[2,8,5]  R623      2.6795136928558350e-01
    z[2,8,5]  R624      2.4268044531345367e-01
    z[2,8,5]  R625      -1.2292737513780594e-01
    z[2,8,5]  R626      0.171631321310997
    z[2,8,5]  R627      -1.7719285190105438e-01
    z[2,8,5]  R628      -4.6486237645149231e-01
    z[2,8,5]  R629      -2.3795351386070251e-01
    z[2,8,5]  R630      1.5455009043216705e-01
    z[2,8,5]  R631      -5.0613671541213989e-01
    z[2,8,5]  R632      2.0881672203540802e-01
    z[2,8,5]  R633      -3.0684599280357361e-01
    z[2,8,5]  R634      -6.2262868881225586e-01
    z[2,8,5]  R635      2.8113192319869995e-01
    z[2,8,5]  R636      1.2872710824012756e-01
    z[2,8,5]  R637      -1.3126474618911743e-01
    z[2,8,5]  R638      5.3936883807182312e-02
    z[2,8,5]  R639      -2.0388758182525635e-01
    z[2,8,5]  R640      -2.4250808358192444e-01
    z[2,8,5]  R641      -1.6675812005996704e-01
    z[2,8,5]  R642      -1.8792568147182465e-01
    z[2,8,5]  R643      2.3786008358001709e-01
    z[2,8,5]  R644      1.3416735827922821e-01
    z[2,8,5]  R645      2.9073727130889893e-01
    z[2,8,5]  R646      -7.5451299548149109e-02
    z[2,8,5]  R647      -1.6008451581001282e-01
    z[2,8,5]  R648      2.8374210000038147e-01
    z[2,8,5]  R649      -9.4341598451137543e-02
    z[2,8,5]  R650      -3.8035833835601807e-01
    z[2,8,5]  R651      4.5989226549863815e-02
    z[2,8,5]  R652      1.1464400589466095e-01
    z[2,8,5]  R653      -1.8688382208347321e-01
    z[2,8,5]  R654      -1.3190971314907074e-01
    z[2,8,5]  R655      -3.4474423527717590e-01
    z[2,8,5]  R656      -5.5179882049560547e-01
    z[2,8,5]  R657      -4.4205829501152039e-01
    z[2,8,5]  R658      4.1795790195465088e-01
    z[2,8,5]  R659      5.2266085147857666e-01
    z[2,8,5]  R660      -3.5278671421110630e-03
    z[2,8,5]  R661      -1.4266875386238098e-01
    z[2,8,5]  R662      -4.2489495873451233e-01
    z[2,8,5]  R663      -1.4343149960041046e-01
    z[2,8,5]  R664      -2.5397273898124695e-01
    z[2,8,5]  R665      -1.2654094398021698e-01
    z[2,8,5]  R666      -1.2960636615753174e-01
    z[2,8,5]  R667      2.9142990708351135e-01
    z[2,8,6]  R26       -1
    z[2,8,6]  R80       1
    z[2,8,6]  R599      -1
    z[2,8,6]  R600      1
    z[2,8,6]  R601      4.0673531591892242e-02
    z[2,8,6]  R602      -7.6985484361648560e-01
    z[2,8,6]  R603      3.2168385386466980e-01
    z[2,8,6]  R604      -2.8644195199012756e-01
    z[2,8,6]  R605      -5.7641750574111938e-01
    z[2,8,6]  R606      4.3060046434402466e-01
    z[2,8,6]  R607      -5.4523575305938721e-01
    z[2,8,6]  R608      1.5747912228107452e-02
    z[2,8,6]  R609      5.7263159751892090e-01
    z[2,8,6]  R610      -2.6377776265144348e-01
    z[2,8,6]  R611      4.5124056935310364e-01
    z[2,8,6]  R612      -4.6549594402313232e-01
    z[2,8,6]  R613      2.6276421546936035e-01
    z[2,8,6]  R614      -8.0889321863651276e-02
    z[2,8,6]  R615      -3.3113043755292892e-02
    z[2,8,6]  R616      -0.366226464509964
    z[2,8,6]  R617      -3.5648569464683533e-01
    z[2,8,6]  R618      -9.4628900289535522e-02
    z[2,8,6]  R619      -8.2821592688560486e-02
    z[2,8,6]  R620      -3.6194634437561035e-01
    z[2,8,6]  R621      -1.9311843439936638e-02
    z[2,8,6]  R622      -2.0924621820449829e-01
    z[2,8,6]  R623      8.3675451576709747e-02
    z[2,8,6]  R624      -1.1608625948429108e-01
    z[2,8,6]  R625      1.6750479117035866e-02
    z[2,8,6]  R626      -3.5390508174896240e-01
    z[2,8,6]  R627      2.8072218410670757e-03
    z[2,8,6]  R628      0.0628654882311821
    z[2,8,6]  R629      -4.6374088525772095e-01
    z[2,8,6]  R630      -2.2481869161128998e-01
    z[2,8,6]  R631      -1.9075348973274231e-01
    z[2,8,6]  R632      -9.0090613812208176e-03
    z[2,8,6]  R633      1.7228309810161591e-01
    z[2,8,6]  R634      3.2534804940223694e-01
    z[2,8,6]  R635      4.2964923381805420e-01
    z[2,8,6]  R636      2.0622503757476807e-01
    z[2,8,6]  R637      4.6970045566558838e-01
    z[2,8,6]  R638      0.0920991376042366
    z[2,8,6]  R639      3.9331771433353424e-02
    z[2,8,6]  R640      1.0742158442735672e-01
    z[2,8,6]  R641      1.1864091455936432e-01
    z[2,8,6]  R642      1.3005739450454712e-01
    z[2,8,6]  R643      -7.7928858809173107e-03
    z[2,8,6]  R644      -3.4613016992807388e-02
    z[2,8,6]  R645      2.5950780138373375e-02
    z[2,8,6]  R646      3.1248387694358826e-01
    z[2,8,6]  R647      3.6323550343513489e-01
    z[2,8,6]  R648      2.7429863810539246e-01
    z[2,8,6]  R649      -1.4621193706989288e-01
    z[2,8,6]  R650      -1.0429130494594574e-01
    z[2,8,6]  R651      -2.7589586377143860e-01
    z[2,8,6]  R652      -2.4740052223205566e-01
    z[2,8,6]  R653      -3.1327673792839050e-01
    z[2,8,6]  R654      -3.3595946431159973e-01
    z[2,8,6]  R655      -2.8496238589286804e-01
    z[2,8,6]  R656      -3.0465468764305115e-01
    z[2,8,6]  R657      -1.9501791894435883e-01
    z[2,8,6]  R658      5.0175851583480835e-01
    z[2,8,6]  R659      8.3230612799525261e-03
    z[2,8,6]  R660      2.8687119483947754e-01
    z[2,8,6]  R661      7.6511144638061523e-02
    z[2,8,6]  R662      -1.5091150999069214e-01
    z[2,8,6]  R663      -2.0095384120941162e-01
    z[2,8,6]  R664      -2.7648857235908508e-01
    z[2,8,6]  R665      -3.3896368741989136e-01
    z[2,8,6]  R666      -2.6503643393516541e-01
    z[2,8,6]  R667      -1.2459450960159302e-01
    z[8,2,0]  R20       1
    z[8,2,0]  R74       -1
    z[8,2,0]  R668      -1
    z[8,2,0]  R669      1
    z[8,2,0]  R682      7.0530152320861816e-01
    z[8,2,0]  R683      8.8695132732391357e-01
    z[8,2,0]  R684      7.5331693887710571e-01
    z[8,2,0]  R685      9.0934127569198608e-01
    z[8,2,0]  R686      8.2864642143249512e-01
    z[8,2,0]  R687      9.4234520196914673e-01
    z[8,2,0]  R688      9.3040871620178223e-01
    z[8,2,0]  R689      0.736838161945343
    z[8,2,0]  R690      8.6052078008651733e-01
    z[8,2,0]  R691      0.713066577911377
    z[8,2,0]  R692      1.3651348650455475e-01
    z[8,2,0]  R693      -3.2548218965530396e-02
    z[8,2,0]  R694      -4.8324260115623474e-01
    z[8,2,0]  R695      4.2534127831459045e-02
    z[8,2,0]  R696      -2.1742577850818634e-01
    z[8,2,0]  R697      -5.1593035459518433e-01
    z[8,2,0]  R698      -3.0395722389221191e-01
    z[8,2,0]  R699      -7.2562158107757568e-02
    z[8,2,0]  R700      -5.1913022994995117e-01
    z[8,2,0]  R701      -1.5697129070758820e-01
    z[8,2,0]  R702      -3.2283249497413635e-01
    z[8,2,0]  R703      -0.721881091594696
    z[8,2,0]  R704      -2.3561200499534607e-01
    z[8,2,0]  R705      -2.9592856764793396e-01
    z[8,2,0]  R706      -2.5959175825119019e-01
    z[8,2,0]  R707      -2.2420540452003479e-01
    z[8,2,0]  R708      -4.0958243608474731e-01
    z[8,2,0]  R709      -0.331001877784729
    z[8,2,0]  R710      -2.5792077183723450e-01
    z[8,2,0]  R711      -1.9591730833053589e-01
    z[8,2,0]  R712      -2.6988866925239563e-01
    z[8,2,0]  R713      -6.8003219366073608e-01
    z[8,2,0]  R714      -6.5597808361053467e-01
    z[8,2,0]  R715      -8.8376182317733765e-01
    z[8,2,0]  R716      -0.755744218826294
    z[8,2,0]  R717      -8.1956106424331665e-01
    z[8,2,0]  R718      -6.7751920223236084e-01
    z[8,2,0]  R719      -6.9661718606948853e-01
    z[8,2,0]  R720      -5.9385901689529419e-01
    z[8,2,0]  R721      -5.2864837646484375e-01
    z[8,2,0]  R722      7.0176303386688232e-02
    z[8,2,0]  R723      -0.313693106174469
    z[8,2,0]  R724      -4.1877318173646927e-02
    z[8,2,0]  R725      -8.0878752470016479e-01
    z[8,2,0]  R726      -1.6961207985877991e-01
    z[8,2,0]  R727      -8.6870723962783813e-01
    z[8,2,0]  R728      -6.7262911796569824e-01
    z[8,2,0]  R729      -8.4285312891006470e-01
    z[8,2,0]  R730      -2.3766933381557465e-01
    z[8,2,0]  R731      -9.1773825883865356e-01
    z[8,2,0]  R732      -4.7791567444801331e-01
    z[8,2,0]  R733      -4.3469026684761047e-01
    z[8,2,0]  R734      -0.340529203414917
    z[8,2,0]  R735      3.1684383749961853e-01
    z[8,2,0]  R736      -2.8930708765983582e-01
    z[8,2,0]  R737      0.569987416267395
    z[8,2,0]  R738      -3.9689540863037109e-02
    z[8,2,0]  R739      3.4201338887214661e-01
    z[8,2,0]  R740      -4.3589100241661072e-01
    z[8,2,0]  R741      8.0050855875015259e-01
    z[8,2,0]  R742      1.6933538019657135e-02
    z[8,2,0]  R743      3.8401553034782410e-01
    z[8,2,0]  R744      6.3226169347763062e-01
    z[8,2,0]  R745      3.9538022875785828e-01
    z[8,2,0]  R746      4.5348340272903442e-01
    z[8,2,0]  R747      1.8556459248065948e-01
    z[8,2,0]  R748      2.8833302855491638e-01
    z[8,2,1]  R21       1
    z[8,2,1]  R75       -1
    z[8,2,1]  R670      -1
    z[8,2,1]  R671      1
    z[8,2,1]  R682      1.9630730152130127e-02
    z[8,2,1]  R683      -7.9196922481060028e-02
    z[8,2,1]  R684      -1.9613333046436310e-02
    z[8,2,1]  R685      1.1365023255348206e-01
    z[8,2,1]  R686      -3.1931233406066895e-01
    z[8,2,1]  R687      -1.1122805625200272e-01
    z[8,2,1]  R688      1.1261923238635063e-02
    z[8,2,1]  R689      -2.4862538278102875e-01
    z[8,2,1]  R690      -5.1845584064722061e-02
    z[8,2,1]  R691      -0.0972457155585289
    z[8,2,1]  R692      8.0286830663681030e-01
    z[8,2,1]  R693      5.8779406547546387e-01
    z[8,2,1]  R694      5.0273990631103516e-01
    z[8,2,1]  R695      4.3708527088165283e-01
    z[8,2,1]  R696      4.7819891571998596e-01
    z[8,2,1]  R697      4.5853444933891296e-01
    z[8,2,1]  R698      4.3781113624572754e-01
    z[8,2,1]  R699      5.7233953475952148e-01
    z[8,2,1]  R700      5.0355130434036255e-01
    z[8,2,1]  R701      3.4641581773757935e-01
    z[8,2,1]  R702      -9.3039542436599731e-01
    z[8,2,1]  R703      2.0746754109859467e-01
    z[8,2,1]  R704      -8.8955307006835938e-01
    z[8,2,1]  R705      -0.88219153881073
    z[8,2,1]  R706      -8.5865569114685059e-01
    z[8,2,1]  R707      -9.2376661300659180e-01
    z[8,2,1]  R708      -8.7629443407058716e-01
    z[8,2,1]  R709      -8.7441927194595337e-01
    z[8,2,1]  R710      -8.8528978824615479e-01
    z[8,2,1]  R711      -8.8353222608566284e-01
    z[8,2,1]  R712      -6.1534738540649414e-01
    z[8,2,1]  R713      1.6282060742378235e-01
    z[8,2,1]  R714      -4.4630587100982666e-01
    z[8,2,1]  R715      -1.6083197295665741e-01
    z[8,2,1]  R716      -6.9364093244075775e-02
    z[8,2,1]  R717      -2.9856148362159729e-01
    z[8,2,1]  R718      -1.5196952223777771e-01
    z[8,2,1]  R719      -1.4520509541034698e-01
    z[8,2,1]  R720      -1.8252392113208771e-01
    z[8,2,1]  R721      3.3651031553745270e-02
    z[8,2,1]  R722      -3.3370348811149597e-01
    z[8,2,1]  R723      -6.3353508710861206e-01
    z[8,2,1]  R724      -9.1670429706573486e-01
    z[8,2,1]  R725      2.0634920895099640e-01
    z[8,2,1]  R726      -0.873768150806427
    z[8,2,1]  R727      2.2565890848636627e-01
    z[8,2,1]  R728      3.6477770656347275e-02
    z[8,2,1]  R729      -1.0097629576921463e-01
    z[8,2,1]  R730      -8.6336147785186768e-01
    z[8,2,1]  R731      1.5227134525775909e-01
    z[8,2,1]  R732      0.257255882024765
    z[8,2,1]  R733      2.1956029534339905e-01
    z[8,2,1]  R734      1.6878212988376617e-01
    z[8,2,1]  R735      1.8642768263816833e-01
    z[8,2,1]  R736      3.3697074651718140e-01
    z[8,2,1]  R737      1.5065012872219086e-01
    z[8,2,1]  R738      -1.5303435735404491e-02
    z[8,2,1]  R739      1.9988635182380676e-01
    z[8,2,1]  R740      3.0230081081390381e-01
    z[8,2,1]  R741      1.1791199445724487e-01
    z[8,2,1]  R742      8.6105978488922119e-01
    z[8,2,1]  R743      4.7929906845092773e-01
    z[8,2,1]  R744      -6.1272454261779785e-01
    z[8,2,1]  R745      -8.6557334661483765e-01
    z[8,2,1]  R746      -8.1219369173049927e-01
    z[8,2,1]  R747      2.1737320721149445e-01
    z[8,2,1]  R748      2.6539999246597290e-01
    z[8,2,2]  R22       1
    z[8,2,2]  R76       -1
    z[8,2,2]  R672      -1
    z[8,2,2]  R673      1
    z[8,2,2]  R682      0.508542537689209
    z[8,2,2]  R683      3.8803330063819885e-01
    z[8,2,2]  R684      4.5523053407669067e-01
    z[8,2,2]  R685      1.8744862079620361e-01
    z[8,2,2]  R686      3.4964513778686523e-01
    z[8,2,2]  R687      1.0699527338147163e-02
    z[8,2,2]  R688      2.3295685648918152e-01
    z[8,2,2]  R689      5.0984853506088257e-01
    z[8,2,2]  R690      6.4617067575454712e-02
    z[8,2,2]  R691      4.4522005319595337e-01
    z[8,2,2]  R692      -2.8069171309471130e-01
    z[8,2,2]  R693      -2.6032933592796326e-01
    z[8,2,2]  R694      -4.4359427690505981e-01
    z[8,2,2]  R695      -6.2107211351394653e-01
    z[8,2,2]  R696      -3.7472090125083923e-01
    z[8,2,2]  R697      -0.568618893623352
    z[8,2,2]  R698      -1.7549788951873779e-01
    z[8,2,2]  R699      -3.2367938756942749e-01
    z[8,2,2]  R700      -5.3947108983993530e-01
    z[8,2,2]  R701      -7.0862895250320435e-01
    z[8,2,2]  R702      -0.0657036080956459
    z[8,2,2]  R703      0.23386250436306
    z[8,2,2]  R704      1.0245457291603088e-01
    z[8,2,2]  R705      -2.5030821561813354e-01
    z[8,2,2]  R706      -3.6769038438796997e-01
    z[8,2,2]  R707      -1.3862235844135284e-01
    z[8,2,2]  R708      -7.5600305572152138e-03
    z[8,2,2]  R709      -1.4240401983261108e-01
    z[8,2,2]  R710      -3.8570471107959747e-02
    z[8,2,2]  R711      -3.9163712412118912e-02
    z[8,2,2]  R712      1.0111314058303833e-01
    z[8,2,2]  R713      -2.2710916399955750e-01
    z[8,2,2]  R714      -2.7996638417243958e-01
    z[8,2,2]  R715      5.8180510997772217e-02
    z[8,2,2]  R716      -1.9354438781738281e-01
    z[8,2,2]  R717      0.0391550213098526
    z[8,2,2]  R718      -1.0665337741374969e-01
    z[8,2,2]  R719      9.8015762865543365e-02
    z[8,2,2]  R720      -1.9831072539091110e-02
    z[8,2,2]  R721      -8.0827414989471436e-02
    z[8,2,2]  R722      0.0355074517428875
    z[8,2,2]  R723      3.8741311430931091e-01
    z[8,2,2]  R724      -1.0585274547338486e-01
    z[8,2,2]  R725      -3.9191875606775284e-02
    z[8,2,2]  R726      3.4256509970873594e-03
    z[8,2,2]  R727      2.8114444017410278e-01
    z[8,2,2]  R728      -1.0289106518030167e-01
    z[8,2,2]  R729      -1.0542208328843117e-02
    z[8,2,2]  R730      -2.1782732009887695e-01
    z[8,2,2]  R731      8.0047480762004852e-02
    z[8,2,2]  R732      -4.0107178688049316e-01
    z[8,2,2]  R733      3.9156821370124817e-01
    z[8,2,2]  R734      1.8699896335601807e-01
    z[8,2,2]  R735      -2.6355883479118347e-01
    z[8,2,2]  R736      -1.6198235750198364e-01
    z[8,2,2]  R737      3.4033775329589844e-01
    z[8,2,2]  R738      2.8280389308929443e-01
    z[8,2,2]  R739      -4.8253139853477478e-01
    z[8,2,2]  R740      1.5344102680683136e-01
    z[8,2,2]  R741      0.482488751411438
    z[8,2,2]  R742      1.1112050712108612e-01
    z[8,2,2]  R743      4.8545765876770020e-01
    z[8,2,2]  R744      -2.5814312696456909e-01
    z[8,2,2]  R745      -1.0168453305959702e-01
    z[8,2,2]  R746      -3.0397295951843262e-01
    z[8,2,2]  R747      -4.5900654792785645e-01
    z[8,2,2]  R748      -4.2968934774398804e-01
    z[8,2,3]  R23       1
    z[8,2,3]  R77       -1
    z[8,2,3]  R674      -1
    z[8,2,3]  R675      1
    z[8,2,3]  R682      2.5739121437072754e-01
    z[8,2,3]  R683      1.6530117392539978e-01
    z[8,2,3]  R684      1.7963266372680664e-01
    z[8,2,3]  R685      1.3234589993953705e-01
    z[8,2,3]  R686      -4.1194036602973938e-02
    z[8,2,3]  R687      1.3977135717868805e-01
    z[8,2,3]  R688      -0.0847676619887352
    z[8,2,3]  R689      3.2371747493743896e-01
    z[8,2,3]  R690      1.3982596993446350e-01
    z[8,2,3]  R691      4.7496250271797180e-01
    z[8,2,3]  R692      7.1082182228565216e-02
    z[8,2,3]  R693      5.2524650096893311e-01
    z[8,2,3]  R694      4.5181828737258911e-01
    z[8,2,3]  R695      3.5764062404632568e-01
    z[8,2,3]  R696      2.4676126241683960e-01
    z[8,2,3]  R697      1.6248725354671478e-01
    z[8,2,3]  R698      3.5538071393966675e-01
    z[8,2,3]  R699      4.9725881218910217e-01
    z[8,2,3]  R700      1.0206269472837448e-01
    z[8,2,3]  R701      2.6244139671325684e-01
    z[8,2,3]  R702      7.6342053711414337e-02
    z[8,2,3]  R703      -5.8134537935256958e-01
    z[8,2,3]  R704      -2.5366422533988953e-01
    z[8,2,3]  R705      -1.7145574092864990e-01
    z[8,2,3]  R706      0.0885215699672699
    z[8,2,3]  R707      1.3964995741844177e-01
    z[8,2,3]  R708      -1.9695621728897095e-01
    z[8,2,3]  R709      -6.9412998855113983e-02
    z[8,2,3]  R710      -1.7963644862174988e-01
    z[8,2,3]  R711      -1.2966012954711914e-01
    z[8,2,3]  R712      6.1762750148773193e-01
    z[8,2,3]  R713      -6.0979276895523071e-01
    z[8,2,3]  R714      -7.1638122200965881e-02
    z[8,2,3]  R715      -3.3242511749267578e-01
    z[8,2,3]  R716      -5.5677896738052368e-01
    z[8,2,3]  R717      -3.1964725255966187e-01
    z[8,2,3]  R718      -0.56904536485672
    z[8,2,3]  R719      -4.8577833175659180e-01
    z[8,2,3]  R720      -4.5397144556045532e-01
    z[8,2,3]  R721      -6.0044860839843750e-01
    z[8,2,3]  R722      4.0795540809631348e-01
    z[8,2,3]  R723      1.8678598105907440e-01
    z[8,2,3]  R724      1.8172113597393036e-01
    z[8,2,3]  R725      -0.290932834148407
    z[8,2,3]  R726      6.5892942249774933e-02
    z[8,2,3]  R727      -2.2303043305873871e-01
    z[8,2,3]  R728      -6.0945552587509155e-01
    z[8,2,3]  R729      -2.3416090011596680e-01
    z[8,2,3]  R730      -1.4389619231224060e-01
    z[8,2,3]  R731      -1.4314334094524384e-01
    z[8,2,3]  R732      5.6083297729492188e-01
    z[8,2,3]  R733      0.0547274611890316
    z[8,2,3]  R734      0.602268397808075
    z[8,2,3]  R735      -6.5138369798660278e-01
    z[8,2,3]  R736      4.6961027383804321e-01
    z[8,2,3]  R737      -5.6371581554412842e-01
    z[8,2,3]  R738      -0.739917516708374
    z[8,2,3]  R739      -4.2029540985822678e-02
    z[8,2,3]  R740      -2.8136106207966805e-02
    z[8,2,3]  R741      -7.4998661875724792e-02
    z[8,2,3]  R742      -2.0571278035640717e-01
    z[8,2,3]  R743      -3.4350258111953735e-01
    z[8,2,3]  R744      2.0098045468330383e-01
    z[8,2,3]  R745      -1.7220930755138397e-01
    z[8,2,3]  R746      8.4163762629032135e-02
    z[8,2,3]  R747      -1.1817722022533417e-01
    z[8,2,3]  R748      5.4602071642875671e-02
    z[8,2,4]  R24       1
    z[8,2,4]  R78       -1
    z[8,2,4]  R676      -1
    z[8,2,4]  R677      1
    z[8,2,4]  R682      -1.6608202457427979e-01
    z[8,2,4]  R683      1.4930222928524017e-01
    z[8,2,4]  R684      1.0916792601346970e-01
    z[8,2,4]  R685      1.6858358681201935e-01
    z[8,2,4]  R686      1.7198072746396065e-02
    z[8,2,4]  R687      -3.4115172922611237e-02
    z[8,2,4]  R688      -1.9708819687366486e-02
    z[8,2,4]  R689      1.2298287451267242e-01
    z[8,2,4]  R690      -0.27997025847435
    z[8,2,4]  R691      -1.6390171647071838e-01
    z[8,2,4]  R692      -1.8132030963897705e-01
    z[8,2,4]  R693      1.9520732760429382e-01
    z[8,2,4]  R694      -1.9591921567916870e-01
    z[8,2,4]  R695      -3.0801620334386826e-02
    z[8,2,4]  R696      -6.9214117527008057e-01
    z[8,2,4]  R697      -2.2359889745712280e-01
    z[8,2,4]  R698      2.5557526946067810e-01
    z[8,2,4]  R699      -2.2692269086837769e-01
    z[8,2,4]  R700      3.4116649627685547e-01
    z[8,2,4]  R701      2.1558435261249542e-01
    z[8,2,4]  R702      9.2774204909801483e-02
    z[8,2,4]  R703      -8.5824113339185715e-03
    z[8,2,4]  R704      8.9389160275459290e-02
    z[8,2,4]  R705      1.5136560425162315e-02
    z[8,2,4]  R706      7.6929312199354172e-03
    z[8,2,4]  R707      -0.0321052223443985
    z[8,2,4]  R708      -7.9387754201889038e-02
    z[8,2,4]  R709      -1.2461936473846436e-01
    z[8,2,4]  R710      -1.1244063824415207e-01
    z[8,2,4]  R711      7.1235232055187225e-02
    z[8,2,4]  R712      3.2721456140279770e-02
    z[8,2,4]  R713      2.3946096003055573e-01
    z[8,2,4]  R714      3.6254864931106567e-01
    z[8,2,4]  R715      -3.1196763738989830e-02
    z[8,2,4]  R716      4.7189682722091675e-02
    z[8,2,4]  R717      -4.9045007675886154e-02
    z[8,2,4]  R718      2.2894616425037384e-01
    z[8,2,4]  R719      2.1908958256244659e-01
    z[8,2,4]  R720      1.0117696970701218e-01
    z[8,2,4]  R721      3.4478890895843506e-01
    z[8,2,4]  R722      5.3812485933303833e-01
    z[8,2,4]  R723      2.0495966076850891e-01
    z[8,2,4]  R724      -1.7710077762603760e-01
    z[8,2,4]  R725      4.3691709637641907e-01
    z[8,2,4]  R726      -9.8659023642539978e-03
    z[8,2,4]  R727      6.8453907966613770e-02
    z[8,2,4]  R728      1.5254114568233490e-01
    z[8,2,4]  R729      -3.0586105585098267e-01
    z[8,2,4]  R730      -2.0717906951904297e-01
    z[8,2,4]  R731      -8.4953360259532928e-02
    z[8,2,4]  R732      -1.2686930596828461e-01
    z[8,2,4]  R733      1.0851389169692993e-01
    z[8,2,4]  R734      -1.0209298878908157e-01
    z[8,2,4]  R735      5.3755092620849609e-01
    z[8,2,4]  R736      0.44412961602211
    z[8,2,4]  R737      -7.2428070008754730e-02
    z[8,2,4]  R738      2.4110174179077148e-01
    z[8,2,4]  R739      0.666729748249054
    z[8,2,4]  R740      -5.4639589786529541e-01
    z[8,2,4]  R741      1.5601858496665955e-01
    z[8,2,4]  R742      -2.3172209039330482e-03
    z[8,2,4]  R743      2.2902800142765045e-01
    z[8,2,4]  R744      -1.0874087363481522e-01
    z[8,2,4]  R745      -1.2333360314369202e-01
    z[8,2,4]  R746      -1.7300260066986084e-01
    z[8,2,4]  R747      -0.677017867565155
    z[8,2,4]  R748      -5.5533581972122192e-01
    z[8,2,5]  R25       1
    z[8,2,5]  R79       -1
    z[8,2,5]  R678      -1
    z[8,2,5]  R679      1
    z[8,2,5]  R682      3.7518101930618286e-01
    z[8,2,5]  R683      -6.0493446653708816e-04
    z[8,2,5]  R684      2.2294235229492188e-01
    z[8,2,5]  R685      2.8060016036033630e-01
    z[8,2,5]  R686      2.0822128653526306e-01
    z[8,2,5]  R687      2.6795136928558350e-01
    z[8,2,5]  R688      2.4268044531345367e-01
    z[8,2,5]  R689      -1.2292737513780594e-01
    z[8,2,5]  R690      0.171631321310997
    z[8,2,5]  R691      -1.7719285190105438e-01
    z[8,2,5]  R692      -4.6486237645149231e-01
    z[8,2,5]  R693      -2.3795351386070251e-01
    z[8,2,5]  R694      1.5455009043216705e-01
    z[8,2,5]  R695      -5.0613671541213989e-01
    z[8,2,5]  R696      2.0881672203540802e-01
    z[8,2,5]  R697      -3.0684599280357361e-01
    z[8,2,5]  R698      -6.2262868881225586e-01
    z[8,2,5]  R699      2.8113192319869995e-01
    z[8,2,5]  R700      1.2872710824012756e-01
    z[8,2,5]  R701      -1.3126474618911743e-01
    z[8,2,5]  R702      5.3936883807182312e-02
    z[8,2,5]  R703      -2.0388758182525635e-01
    z[8,2,5]  R704      -2.4250808358192444e-01
    z[8,2,5]  R705      -1.6675812005996704e-01
    z[8,2,5]  R706      -1.8792568147182465e-01
    z[8,2,5]  R707      2.3786008358001709e-01
    z[8,2,5]  R708      1.3416735827922821e-01
    z[8,2,5]  R709      2.9073727130889893e-01
    z[8,2,5]  R710      -7.5451299548149109e-02
    z[8,2,5]  R711      -1.6008451581001282e-01
    z[8,2,5]  R712      2.8374210000038147e-01
    z[8,2,5]  R713      -9.4341598451137543e-02
    z[8,2,5]  R714      -3.8035833835601807e-01
    z[8,2,5]  R715      4.5989226549863815e-02
    z[8,2,5]  R716      1.1464400589466095e-01
    z[8,2,5]  R717      -1.8688382208347321e-01
    z[8,2,5]  R718      -1.3190971314907074e-01
    z[8,2,5]  R719      -3.4474423527717590e-01
    z[8,2,5]  R720      -5.5179882049560547e-01
    z[8,2,5]  R721      -4.4205829501152039e-01
    z[8,2,5]  R722      4.1795790195465088e-01
    z[8,2,5]  R723      5.2266085147857666e-01
    z[8,2,5]  R724      -3.5278671421110630e-03
    z[8,2,5]  R725      -1.4266875386238098e-01
    z[8,2,5]  R726      -4.2489495873451233e-01
    z[8,2,5]  R727      -1.4343149960041046e-01
    z[8,2,5]  R728      -2.5397273898124695e-01
    z[8,2,5]  R729      -1.2654094398021698e-01
    z[8,2,5]  R730      -1.2960636615753174e-01
    z[8,2,5]  R731      2.9142990708351135e-01
    z[8,2,5]  R732      4.6073180437088013e-01
    z[8,2,5]  R733      -4.5443538576364517e-02
    z[8,2,5]  R734      -0.586475133895874
    z[8,2,5]  R735      8.9801521971821785e-03
    z[8,2,5]  R736      -1.6270147264003754e-01
    z[8,2,5]  R737      -1.6778273880481720e-01
    z[8,2,5]  R738      -1.2378364801406860e-01
    z[8,2,5]  R739      -4.0458962321281433e-01
    z[8,2,5]  R740      2.6042655110359192e-01
    z[8,2,5]  R741      -1.1376355588436127e-01
    z[8,2,5]  R742      -6.4084318000823259e-04
    z[8,2,5]  R743      9.5598847838118672e-04
    z[8,2,5]  R744      1.9212763011455536e-01
    z[8,2,5]  R745      1.8085126578807831e-01
    z[8,2,5]  R746      6.4689829945564270e-02
    z[8,2,5]  R747      -3.1809869408607483e-01
    z[8,2,5]  R748      -4.7258087992668152e-01
    z[8,2,6]  R26       1
    z[8,2,6]  R80       -1
    z[8,2,6]  R680      -1
    z[8,2,6]  R681      1
    z[8,2,6]  R682      -9.4628900289535522e-02
    z[8,2,6]  R683      -8.2821592688560486e-02
    z[8,2,6]  R684      -3.6194634437561035e-01
    z[8,2,6]  R685      -1.9311843439936638e-02
    z[8,2,6]  R686      -2.0924621820449829e-01
    z[8,2,6]  R687      8.3675451576709747e-02
    z[8,2,6]  R688      -1.1608625948429108e-01
    z[8,2,6]  R689      1.6750479117035866e-02
    z[8,2,6]  R690      -3.5390508174896240e-01
    z[8,2,6]  R691      2.8072218410670757e-03
    z[8,2,6]  R692      0.0628654882311821
    z[8,2,6]  R693      -4.6374088525772095e-01
    z[8,2,6]  R694      -2.2481869161128998e-01
    z[8,2,6]  R695      -1.9075348973274231e-01
    z[8,2,6]  R696      -9.0090613812208176e-03
    z[8,2,6]  R697      1.7228309810161591e-01
    z[8,2,6]  R698      3.2534804940223694e-01
    z[8,2,6]  R699      4.2964923381805420e-01
    z[8,2,6]  R700      2.0622503757476807e-01
    z[8,2,6]  R701      4.6970045566558838e-01
    z[8,2,6]  R702      0.0920991376042366
    z[8,2,6]  R703      3.9331771433353424e-02
    z[8,2,6]  R704      1.0742158442735672e-01
    z[8,2,6]  R705      1.1864091455936432e-01
    z[8,2,6]  R706      1.3005739450454712e-01
    z[8,2,6]  R707      -7.7928858809173107e-03
    z[8,2,6]  R708      -3.4613016992807388e-02
    z[8,2,6]  R709      2.5950780138373375e-02
    z[8,2,6]  R710      3.1248387694358826e-01
    z[8,2,6]  R711      3.6323550343513489e-01
    z[8,2,6]  R712      2.7429863810539246e-01
    z[8,2,6]  R713      -1.4621193706989288e-01
    z[8,2,6]  R714      -1.0429130494594574e-01
    z[8,2,6]  R715      -2.7589586377143860e-01
    z[8,2,6]  R716      -2.4740052223205566e-01
    z[8,2,6]  R717      -3.1327673792839050e-01
    z[8,2,6]  R718      -3.3595946431159973e-01
    z[8,2,6]  R719      -2.8496238589286804e-01
    z[8,2,6]  R720      -3.0465468764305115e-01
    z[8,2,6]  R721      -1.9501791894435883e-01
    z[8,2,6]  R722      5.0175851583480835e-01
    z[8,2,6]  R723      8.3230612799525261e-03
    z[8,2,6]  R724      2.8687119483947754e-01
    z[8,2,6]  R725      7.6511144638061523e-02
    z[8,2,6]  R726      -1.5091150999069214e-01
    z[8,2,6]  R727      -2.0095384120941162e-01
    z[8,2,6]  R728      -2.7648857235908508e-01
    z[8,2,6]  R729      -3.3896368741989136e-01
    z[8,2,6]  R730      -2.6503643393516541e-01
    z[8,2,6]  R731      -1.2459450960159302e-01
    z[8,2,6]  R732      4.0673531591892242e-02
    z[8,2,6]  R733      -7.6985484361648560e-01
    z[8,2,6]  R734      3.2168385386466980e-01
    z[8,2,6]  R735      -2.8644195199012756e-01
    z[8,2,6]  R736      -5.7641750574111938e-01
    z[8,2,6]  R737      4.3060046434402466e-01
    z[8,2,6]  R738      -5.4523575305938721e-01
    z[8,2,6]  R739      1.5747912228107452e-02
    z[8,2,6]  R740      5.7263159751892090e-01
    z[8,2,6]  R741      -2.6377776265144348e-01
    z[8,2,6]  R742      4.5124056935310364e-01
    z[8,2,6]  R743      -4.6549594402313232e-01
    z[8,2,6]  R744      2.6276421546936035e-01
    z[8,2,6]  R745      -8.0889321863651276e-02
    z[8,2,6]  R746      -3.3113043755292892e-02
    z[8,2,6]  R747      -0.366226464509964
    z[8,2,6]  R748      -3.5648569464683533e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R749      -1
    z[3,7,0]  R750      1
    z[3,7,0]  R763      7.1162068843841553e-01
    z[3,7,0]  R764      9.5327025651931763e-01
    z[3,7,0]  R765      7.0742470026016235e-01
    z[3,7,0]  R766      0.798708438873291
    z[3,7,0]  R767      5.8215296268463135e-01
    z[3,7,0]  R768      8.0113774538040161e-01
    z[3,7,0]  R769      8.3893394470214844e-01
    z[3,7,0]  R770      7.2176802158355713e-01
    z[3,7,0]  R771      6.9075030088424683e-01
    z[3,7,0]  R772      6.9604158401489258e-01
    z[3,7,0]  R773      -4.7281497716903687e-01
    z[3,7,0]  R774      -6.8683397769927979e-01
    z[3,7,0]  R775      -6.7731253802776337e-02
    z[3,7,0]  R776      -3.9962872862815857e-01
    z[3,7,0]  R777      -1.8932853639125824e-01
    z[3,7,0]  R778      -4.4252589344978333e-01
    z[3,7,0]  R779      -4.3393689393997192e-01
    z[3,7,0]  R780      -2.8371793031692505e-01
    z[3,7,0]  R781      -3.8343551754951477e-01
    z[3,7,0]  R782      -3.8241106271743774e-01
    z[3,7,0]  R783      1.2241673469543457e-01
    z[3,7,0]  R784      -1.2061749584972858e-02
    z[3,7,0]  R785      -1.4337897300720215e-01
    z[3,7,0]  R786      -2.2681014239788055e-01
    z[3,7,0]  R787      -1.9298419356346130e-01
    z[3,7,0]  R788      -4.9005974084138870e-02
    z[3,7,0]  R789      -1.9798719882965088e-01
    z[3,7,0]  R790      5.4058995097875595e-02
    z[3,7,0]  R791      1.2684838473796844e-01
    z[3,7,0]  R792      -1.7259445041418076e-02
    z[3,7,0]  R793      1.5683120489120483e-01
    z[3,7,0]  R794      -5.1860684156417847e-01
    z[3,7,0]  R795      2.6655766367912292e-01
    z[3,7,0]  R796      -5.6426441669464111e-01
    z[3,7,0]  R797      2.5352329015731812e-02
    z[3,7,0]  R798      -6.1914050579071045e-01
    z[3,7,0]  R799      -3.5635665059089661e-01
    z[3,7,0]  R800      3.6339778453111649e-02
    z[3,7,0]  R801      7.9450950026512146e-02
    z[3,7,0]  R802      2.2689421474933624e-01
    z[3,7,0]  R803      0.77576744556427
    z[3,7,0]  R804      8.8025522232055664e-01
    z[3,7,0]  R805      6.4333146810531616e-01
    z[3,7,0]  R806      8.7296146154403687e-01
    z[3,7,0]  R807      6.7654889822006226e-01
    z[3,7,0]  R808      7.7571070194244385e-01
    z[3,7,0]  R809      7.1319955587387085e-01
    z[3,7,0]  R810      7.6416790485382080e-01
    z[3,7,0]  R811      0.66385817527771
    z[3,7,0]  R812      7.3412883281707764e-01
    z[3,7,0]  R813      -0.0723298192024231
    z[3,7,0]  R814      -3.6823704838752747e-01
    z[3,7,0]  R815      -1.8581800162792206e-01
    z[3,7,0]  R816      -2.1017327904701233e-01
    z[3,7,0]  R817      -4.3952235579490662e-01
    z[3,7,0]  R818      -0.404788076877594
    z[3,7,0]  R819      6.5057352185249329e-02
    z[3,7,0]  R820      -3.6465483903884888e-01
    z[3,7,0]  R821      -7.1978025138378143e-02
    z[3,7,0]  R822      -1.6103573143482208e-02
    z[3,7,0]  R823      1.5172088146209717e-01
    z[3,7,0]  R824      8.2185946404933929e-02
    z[3,7,0]  R825      2.3939360678195953e-01
    z[3,7,0]  R826      0.133229598402977
    z[3,7,0]  R827      3.4232255816459656e-01
    z[3,7,0]  R828      2.4072253704071045e-01
    z[3,7,0]  R829      -0.907288670539856
    z[3,7,0]  R830      -9.0061253309249878e-01
    z[3,7,0]  R831      -7.9439109563827515e-01
    z[3,7,0]  R832      -7.9312282800674438e-01
    z[3,7,0]  R833      6.7805558443069458e-02
    z[3,7,0]  R834      3.4394392371177673e-01
    z[3,7,0]  R835      3.5133108496665955e-01
    z[3,7,0]  R836      2.5730523467063904e-01
    z[3,7,0]  R837      -4.4008356332778931e-01
    z[3,7,0]  R838      -8.8031291961669922e-02
    z[3,7,0]  R839      -1.8469962477684021e-01
    z[3,7,0]  R840      1.5967264771461487e-01
    z[3,7,0]  R841      -7.2020488977432251e-01
    z[3,7,0]  R842      -5.1735591888427734e-01
    z[3,7,0]  R843      6.6200077533721924e-01
    z[3,7,0]  R844      6.1138284206390381e-01
    z[3,7,0]  R845      3.5945829749107361e-01
    z[3,7,0]  R846      3.4982198476791382e-01
    z[3,7,0]  R847      4.5862689614295959e-01
    z[3,7,0]  R848      -3.2159939408302307e-02
    z[3,7,0]  R849      -0.553945779800415
    z[3,7,0]  R850      -1.6781832277774811e-01
    z[3,7,0]  R851      2.1491825580596924e-01
    z[3,7,0]  R852      -8.2912176847457886e-01
    z[3,7,0]  R853      3.9126396179199219e-01
    z[3,7,0]  R854      2.4881863594055176e-01
    z[3,7,0]  R855      2.1482163667678833e-01
    z[3,7,0]  R856      1.6018109396100044e-02
    z[3,7,0]  R857      1.4037631452083588e-01
    z[3,7,0]  R858      -1.0633911192417145e-01
    z[3,7,0]  R859      3.5546919703483582e-01
    z[3,7,0]  R860      -7.3311340808868408e-01
    z[3,7,0]  R861      -0.69478839635849
    z[3,7,0]  R862      -6.0788959264755249e-01
    z[3,7,0]  R863      9.3835823237895966e-02
    z[3,7,0]  R864      3.0185481905937195e-01
    z[3,7,0]  R865      6.9934844970703125e-02
    z[3,7,0]  R866      -3.5546261817216873e-02
    z[3,7,0]  R867      -2.1151846647262573e-01
    z[3,7,0]  R868      2.6397460699081421e-01
    z[3,7,0]  R869      1.4714916236698627e-02
    z[3,7,0]  R870      -0.826717734336853
    z[3,7,0]  R871      -5.6553375720977783e-01
    z[3,7,0]  R872      -4.6557343006134033e-01
    z[3,7,0]  R873      2.2465810179710388e-01
    z[3,7,0]  R874      -7.3979392647743225e-02
    z[3,7,0]  R875      -0.567614734172821
    z[3,7,0]  R876      2.2830119729042053e-01
    z[3,7,0]  R877      3.2732114195823669e-01
    z[3,7,0]  R878      -2.1348632872104645e-01
    z[3,7,0]  R879      -5.2942311763763428e-01
    z[3,7,0]  R880      -4.3943038582801819e-01
    z[3,7,0]  R881      -7.5273221731185913e-01
    z[3,7,0]  R882      -2.6824358105659485e-01
    z[3,7,0]  R883      -5.7141637802124023e-01
    z[3,7,0]  R884      -7.9831665754318237e-01
    z[3,7,0]  R885      2.3983244597911835e-01
    z[3,7,0]  R886      -4.5837086439132690e-01
    z[3,7,0]  R887      -2.7903449535369873e-01
    z[3,7,0]  R888      -2.3343828320503235e-01
    z[3,7,0]  R889      -1.9718140363693237e-01
    z[3,7,0]  R890      1.6486378014087677e-01
    z[3,7,0]  R891      -8.1450670957565308e-01
    z[3,7,0]  R892      -2.9810729622840881e-01
    z[3,7,0]  R893      0.346869558095932
    z[3,7,0]  R894      1.3677033782005310e-01
    z[3,7,0]  R895      -2.9752010107040405e-01
    z[3,7,0]  R896      -2.8384643793106079e-01
    z[3,7,0]  R897      1.6154052317142487e-01
    z[3,7,0]  R898      -4.7044627368450165e-02
    z[3,7,0]  R899      2.0723946392536163e-01
    z[3,7,0]  R900      -0.820107102394104
    z[3,7,0]  R901      -5.7578301429748535e-01
    z[3,7,0]  R902      -0.0969822108745575
    z[3,7,0]  R903      6.0532465577125549e-02
    z[3,7,0]  R904      -4.2753165960311890e-01
    z[3,7,0]  R905      -1.7922100424766541e-01
    z[3,7,0]  R906      -5.5445814132690430e-01
    z[3,7,0]  R907      0.257851779460907
    z[3,7,0]  R908      -1.9561986625194550e-01
    z[3,7,0]  R909      -7.6634180545806885e-01
    z[3,7,0]  R910      -2.9960823059082031e-01
    z[3,7,0]  R911      -6.7675042152404785e-01
    z[3,7,0]  R912      -7.6143556833267212e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R751      -1
    z[3,7,1]  R752      1
    z[3,7,1]  R763      -9.5694243907928467e-02
    z[3,7,1]  R764      -3.7281468510627747e-02
    z[3,7,1]  R765      2.7269739075563848e-04
    z[3,7,1]  R766      1.2312665581703186e-01
    z[3,7,1]  R767      2.2732684016227722e-01
    z[3,7,1]  R768      -2.7584299445152283e-01
    z[3,7,1]  R769      8.5411950945854187e-02
    z[3,7,1]  R770      9.4852922484278679e-03
    z[3,7,1]  R771      -3.8345813751220703e-01
    z[3,7,1]  R772      -1.6182261705398560e-01
    z[3,7,1]  R773      3.8585740327835083e-01
    z[3,7,1]  R774      2.5853881239891052e-01
    z[3,7,1]  R775      5.1659452915191650e-01
    z[3,7,1]  R776      6.1803042888641357e-01
    z[3,7,1]  R777      4.8582258820533752e-01
    z[3,7,1]  R778      2.7209252119064331e-01
    z[3,7,1]  R779      8.4815979003906250e-01
    z[3,7,1]  R780      0.591509997844696
    z[3,7,1]  R781      6.3983148336410522e-01
    z[3,7,1]  R782      4.4348701834678650e-01
    z[3,7,1]  R783      -0.985664963722229
    z[3,7,1]  R784      4.2809438705444336e-01
    z[3,7,1]  R785      -9.2774575948715210e-01
    z[3,7,1]  R786      -9.0466153621673584e-01
    z[3,7,1]  R787      -8.9581912755966187e-01
    z[3,7,1]  R788      -8.7088793516159058e-01
    z[3,7,1]  R789      -9.1231465339660645e-01
    z[3,7,1]  R790      -0.892479658126831
    z[3,7,1]  R791      -8.8815581798553467e-01
    z[3,7,1]  R792      -8.9752441644668579e-01
    z[3,7,1]  R793      0.728148341178894
    z[3,7,1]  R794      3.8828489184379578e-01
    z[3,7,1]  R795      7.8841805458068848e-01
    z[3,7,1]  R796      4.5100745558738708e-01
    z[3,7,1]  R797      0.782682478427887
    z[3,7,1]  R798      7.1726846508681774e-03
    z[3,7,1]  R799      -2.3392945528030396e-01
    z[3,7,1]  R800      -6.7416888475418091e-01
    z[3,7,1]  R801      -6.3650351762771606e-01
    z[3,7,1]  R802      -4.3019664287567139e-01
    z[3,7,1]  R803      1.6411490738391876e-02
    z[3,7,1]  R804      1.8768697977066040e-01
    z[3,7,1]  R805      -2.3674362897872925e-01
    z[3,7,1]  R806      2.9516544938087463e-01
    z[3,7,1]  R807      2.3874360322952271e-01
    z[3,7,1]  R808      2.4278904497623444e-01
    z[3,7,1]  R809      3.0271226167678833e-01
    z[3,7,1]  R810      -5.8600634336471558e-02
    z[3,7,1]  R811      2.9660817980766296e-01
    z[3,7,1]  R812      4.3455091118812561e-01
    z[3,7,1]  R813      5.2240979671478271e-01
    z[3,7,1]  R814      -5.1190710067749023e-01
    z[3,7,1]  R815      -4.8452475666999817e-01
    z[3,7,1]  R816      -0.502964437007904
    z[3,7,1]  R817      -4.7964704036712646e-01
    z[3,7,1]  R818      -0.854331910610199
    z[3,7,1]  R819      -5.2673918008804321e-01
    z[3,7,1]  R820      -4.7937366366386414e-01
    z[3,7,1]  R821      -7.8769600391387939e-01
    z[3,7,1]  R822      -5.6490635871887207e-01
    z[3,7,1]  R823      1.2438297271728516e-02
    z[3,7,1]  R824      6.8744570016860962e-01
    z[3,7,1]  R825      4.6005198359489441e-01
    z[3,7,1]  R826      -7.7825301885604858e-01
    z[3,7,1]  R827      -2.2731673717498779e-01
    z[3,7,1]  R828      -6.9942563772201538e-01
    z[3,7,1]  R829      -1.7192485928535461e-01
    z[3,7,1]  R830      -1.9084727764129639e-01
    z[3,7,1]  R831      -3.4105113148689270e-01
    z[3,7,1]  R832      -2.1921217441558838e-01
    z[3,7,1]  R833      6.6876864433288574e-01
    z[3,7,1]  R834      2.2041143476963043e-01
    z[3,7,1]  R835      2.5117090344429016e-01
    z[3,7,1]  R836      1.6876345872879028e-01
    z[3,7,1]  R837      -7.2898006439208984e-01
    z[3,7,1]  R838      -7.4544352293014526e-01
    z[3,7,1]  R839      -5.6649994850158691e-01
    z[3,7,1]  R840      -0.865119218826294
    z[3,7,1]  R841      -0.507922351360321
    z[3,7,1]  R842      -0.618511438369751
    z[3,7,1]  R843      -2.1649330854415894e-01
    z[3,7,1]  R844      3.0930796265602112e-01
    z[3,7,1]  R845      8.4924995899200439e-01
    z[3,7,1]  R846      4.2335382103919983e-01
    z[3,7,1]  R847      4.6006661653518677e-01
    z[3,7,1]  R848      7.8704708814620972e-01
    z[3,7,1]  R849      -7.1661293506622314e-01
    z[3,7,1]  R850      -7.4266058206558228e-01
    z[3,7,1]  R851      -8.4290659427642822e-01
    z[3,7,1]  R852      -4.6834820508956909e-01
    z[3,7,1]  R853      3.1773579120635986e-01
    z[3,7,1]  R854      3.5326966643333435e-01
    z[3,7,1]  R855      -8.7270236015319824e-01
    z[3,7,1]  R856      -8.1956350803375244e-01
    z[3,7,1]  R857      6.7453527450561523e-01
    z[3,7,1]  R858      -5.3128945827484131e-01
    z[3,7,1]  R859      -0.854092001914978
    z[3,7,1]  R860      1.3329645991325378e-01
    z[3,7,1]  R861      1.7880636453628540e-01
    z[3,7,1]  R862      -1.1599297635257244e-02
    z[3,7,1]  R863      7.3112434148788452e-01
    z[3,7,1]  R864      3.0246776342391968e-01
    z[3,7,1]  R865      -6.0424768924713135e-01
    z[3,7,1]  R866      -0.900780975818634
    z[3,7,1]  R867      -7.2514319419860840e-01
    z[3,7,1]  R868      4.5567423105239868e-01
    z[3,7,1]  R869      -6.1548978090286255e-01
    z[3,7,1]  R870      -2.8613340854644775e-01
    z[3,7,1]  R871      2.3322394490242004e-01
    z[3,7,1]  R872      2.5845530629158020e-01
    z[3,7,1]  R873      4.8997023701667786e-01
    z[3,7,1]  R874      4.0439867973327637e-01
    z[3,7,1]  R875      -0.656741201877594
    z[3,7,1]  R876      -8.8230144977569580e-01
    z[3,7,1]  R877      -8.0567622184753418e-01
    z[3,7,1]  R878      -5.0674062967300415e-01
    z[3,7,1]  R879      -5.5835723876953125e-01
    z[3,7,1]  R880      1.6405096650123596e-01
    z[3,7,1]  R881      4.2379528284072876e-02
    z[3,7,1]  R882      -2.6594796776771545e-01
    z[3,7,1]  R883      -5.7925939559936523e-01
    z[3,7,1]  R884      -5.6226819753646851e-01
    z[3,7,1]  R885      -7.9547297954559326e-01
    z[3,7,1]  R886      -6.3943260908126831e-01
    z[3,7,1]  R887      -5.9386724233627319e-01
    z[3,7,1]  R888      -7.3498421907424927e-01
    z[3,7,1]  R889      -3.1208464503288269e-01
    z[3,7,1]  R890      -6.8900579214096069e-01
    z[3,7,1]  R891      -3.7101477384567261e-01
    z[3,7,1]  R892      6.6063500940799713e-02
    z[3,7,1]  R893      5.4832839965820312e-01
    z[3,7,1]  R894      5.9515094757080078e-01
    z[3,7,1]  R895      -7.0391672849655151e-01
    z[3,7,1]  R896      -6.7108732461929321e-01
    z[3,7,1]  R897      -0.752247154712677
    z[3,7,1]  R898      -8.9022374153137207e-01
    z[3,7,1]  R899      -7.2310638427734375e-01
    z[3,7,1]  R900      2.3239577189087868e-02
    z[3,7,1]  R901      -2.1518308669328690e-02
    z[3,7,1]  R902      -4.8537105321884155e-01
    z[3,7,1]  R903      2.7299115061759949e-01
    z[3,7,1]  R904      -6.1635011434555054e-01
    z[3,7,1]  R905      -8.9283865690231323e-01
    z[3,7,1]  R906      -6.3888096809387207e-01
    z[3,7,1]  R907      0.512329638004303
    z[3,7,1]  R908      -2.2371679544448853e-01
    z[3,7,1]  R909      -3.9436888694763184e-01
    z[3,7,1]  R910      -4.8325982689857483e-01
    z[3,7,1]  R911      3.8783061504364014e-01
    z[3,7,1]  R912      2.6828026771545410e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R753      -1
    z[3,7,2]  R754      1
    z[3,7,2]  R763      5.0105190277099609e-01
    z[3,7,2]  R764      1.6583970189094543e-01
    z[3,7,2]  R765      4.9155265092849731e-01
    z[3,7,2]  R766      3.6315330862998962e-01
    z[3,7,2]  R767      5.6071329116821289e-01
    z[3,7,2]  R768      3.0591517686843872e-01
    z[3,7,2]  R769      2.4037525057792664e-01
    z[3,7,2]  R770      0.488815575838089
    z[3,7,2]  R771      4.8330357670783997e-01
    z[3,7,2]  R772      6.2198311090469360e-01
    z[3,7,2]  R773      -6.1789786815643311e-01
    z[3,7,2]  R774      -4.6963772177696228e-01
    z[3,7,2]  R775      -5.0127208232879639e-01
    z[3,7,2]  R776      -5.5330657958984375e-01
    z[3,7,2]  R777      -3.1416711211204529e-01
    z[3,7,2]  R778      -1.7954818904399872e-01
    z[3,7,2]  R779      1.7211334407329559e-01
    z[3,7,2]  R780      -6.4731532335281372e-01
    z[3,7,2]  R781      -2.6995593309402466e-01
    z[3,7,2]  R782      -5.1188085228204727e-02
    z[3,7,2]  R783      0.0458839125931263
    z[3,7,2]  R784      0.326031357049942
    z[3,7,2]  R785      2.6491987705230713e-01
    z[3,7,2]  R786      2.7660864591598511e-01
    z[3,7,2]  R787      1.1854731291532516e-01
    z[3,7,2]  R788      -2.3694671690464020e-02
    z[3,7,2]  R789      1.4027518033981323e-01
    z[3,7,2]  R790      -9.1233126819133759e-02
    z[3,7,2]  R791      4.8379283398389816e-02
    z[3,7,2]  R792      -3.0592581257224083e-02
    z[3,7,2]  R793      -0.0733601376414299
    z[3,7,2]  R794      2.5493115186691284e-01
    z[3,7,2]  R795      -1.6764026880264282e-01
    z[3,7,2]  R796      4.0803188085556030e-01
    z[3,7,2]  R797      -1.4757739007472992e-01
    z[3,7,2]  R798      1.1929593980312347e-01
    z[3,7,2]  R799      -4.9659019708633423e-01
    z[3,7,2]  R800      8.0252867192029953e-03
    z[3,7,2]  R801      5.1690624095499516e-03
    z[3,7,2]  R802      -1.4292004704475403e-01
    z[3,7,2]  R803      2.5777277350425720e-01
    z[3,7,2]  R804      -1.1954865604639053e-01
    z[3,7,2]  R805      1.0909274965524673e-01
    z[3,7,2]  R806      -1.0482856631278992e-01
    z[3,7,2]  R807      -2.9389381408691406e-01
    z[3,7,2]  R808      -0.358809232711792
    z[3,7,2]  R809      -0.108444444835186
    z[3,7,2]  R810      1.3620543479919434e-01
    z[3,7,2]  R811      -9.4696566462516785e-02
    z[3,7,2]  R812      -2.3804001510143280e-01
    z[3,7,2]  R813      4.7510975599288940e-01
    z[3,7,2]  R814      -4.3975785374641418e-01
    z[3,7,2]  R815      -6.3251811265945435e-01
    z[3,7,2]  R816      -6.5593171119689941e-01
    z[3,7,2]  R817      -3.6732786893844604e-01
    z[3,7,2]  R818      5.5395025759935379e-02
    z[3,7,2]  R819      -5.7521623373031616e-01
    z[3,7,2]  R820      -5.3364193439483643e-01
    z[3,7,2]  R821      -4.8240253329277039e-01
    z[3,7,2]  R822      -4.0648695826530457e-01
    z[3,7,2]  R823      7.5240141153335571e-01
    z[3,7,2]  R824      2.6230162382125854e-01
    z[3,7,2]  R825      -1.4601278118789196e-02
    z[3,7,2]  R826      1.1752258241176605e-01
    z[3,7,2]  R827      5.1802337169647217e-01
    z[3,7,2]  R828      -8.5014671087265015e-02
    z[3,7,2]  R829      -4.3336819857358932e-02
    z[3,7,2]  R830      -6.9281840696930885e-03
    z[3,7,2]  R831      2.6703259348869324e-01
    z[3,7,2]  R832      4.8138287663459778e-01
    z[3,7,2]  R833      6.2798202037811279e-01
    z[3,7,2]  R834      5.0892859697341919e-01
    z[3,7,2]  R835      3.6279958486557007e-01
    z[3,7,2]  R836      3.9509826898574829e-01
    z[3,7,2]  R837      -1.8965192139148712e-01
    z[3,7,2]  R838      -4.0701773762702942e-01
    z[3,7,2]  R839      -3.4555483609437943e-02
    z[3,7,2]  R840      -3.2562226057052612e-02
    z[3,7,2]  R841      -1.1808338761329651e-01
    z[3,7,2]  R842      -3.9527878165245056e-01
    z[3,7,2]  R843      2.0764118060469627e-02
    z[3,7,2]  R844      3.7314009666442871e-01
    z[3,7,2]  R845      1.9965112209320068e-01
    z[3,7,2]  R846      5.7231187820434570e-01
    z[3,7,2]  R847      1.8976931273937225e-01
    z[3,7,2]  R848      1.5339636802673340e-01
    z[3,7,2]  R849      -3.3698305487632751e-01
    z[3,7,2]  R850      -6.9558590650558472e-02
    z[3,7,2]  R851      -2.9084178805351257e-01
    z[3,7,2]  R852      1.6147981584072113e-01
    z[3,7,2]  R853      5.5289882421493530e-01
    z[3,7,2]  R854      5.6592386960983276e-01
    z[3,7,2]  R855      -2.6835048198699951e-01
    z[3,7,2]  R856      -4.5116010308265686e-01
    z[3,7,2]  R857      3.9275681972503662e-01
    z[3,7,2]  R858      1.4864921569824219e-01
    z[3,7,2]  R859      1.4777974784374237e-01
    z[3,7,2]  R860      1.4433830045163631e-02
    z[3,7,2]  R861      5.8649875223636627e-02
    z[3,7,2]  R862      9.5928184688091278e-02
    z[3,7,2]  R863      2.0550854504108429e-01
    z[3,7,2]  R864      0.733496904373169
    z[3,7,2]  R865      -3.0421867966651917e-01
    z[3,7,2]  R866      4.0832184255123138e-02
    z[3,7,2]  R867      -2.1121737360954285e-01
    z[3,7,2]  R868      -2.3063591122627258e-01
    z[3,7,2]  R869      -1.8074475228786469e-01
    z[3,7,2]  R870      2.3348145186901093e-01
    z[3,7,2]  R871      -5.4902553558349609e-02
    z[3,7,2]  R872      -1.1982156336307526e-01
    z[3,7,2]  R873      4.7163677215576172e-01
    z[3,7,2]  R874      4.8232552409172058e-01
    z[3,7,2]  R875      9.2045597732067108e-02
    z[3,7,2]  R876      4.4353265315294266e-02
    z[3,7,2]  R877      -0.0972619354724884
    z[3,7,2]  R878      -2.3143781721591949e-01
    z[3,7,2]  R879      3.4219604730606079e-01
    z[3,7,2]  R880      -1.6744692623615265e-01
    z[3,7,2]  R881      -3.4664005041122437e-01
    z[3,7,2]  R882      -7.7150254510343075e-03
    z[3,7,2]  R883      -3.6362352967262268e-01
    z[3,7,2]  R884      1.8867236375808716e-01
    z[3,7,2]  R885      -3.1880292296409607e-01
    z[3,7,2]  R886      2.4227949976921082e-01
    z[3,7,2]  R887      2.2747018933296204e-01
    z[3,7,2]  R888      1.7310473322868347e-01
    z[3,7,2]  R889      2.0147490501403809e-01
    z[3,7,2]  R890      -3.0700030922889709e-01
    z[3,7,2]  R891      1.7181381583213806e-02
    z[3,7,2]  R892      -2.2931785881519318e-01
    z[3,7,2]  R893      6.6481626033782959e-01
    z[3,7,2]  R894      2.7252513170242310e-01
    z[3,7,2]  R895      -2.7540338039398193e-01
    z[3,7,2]  R896      7.6584428548812866e-02
    z[3,7,2]  R897      -5.7331192493438721e-01
    z[3,7,2]  R898      -2.6023969054222107e-01
    z[3,7,2]  R899      -2.5527155399322510e-01
    z[3,7,2]  R900      -1.5020149759948254e-02
    z[3,7,2]  R901      -6.1559706926345825e-02
    z[3,7,2]  R902      7.7393390238285065e-02
    z[3,7,2]  R903      6.6374713182449341e-01
    z[3,7,2]  R904      1.5252985060214996e-01
    z[3,7,2]  R905      -3.3343076705932617e-01
    z[3,7,2]  R906      -3.8093057274818420e-01
    z[3,7,2]  R907      -4.5072987675666809e-01
    z[3,7,2]  R908      3.1683048605918884e-01
    z[3,7,2]  R909      -6.4119093120098114e-02
    z[3,7,2]  R910      1.8009927123785019e-02
    z[3,7,2]  R911      -5.0373566150665283e-01
    z[3,7,2]  R912      -5.5464059114456177e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R755      -1
    z[3,7,3]  R756      1
    z[3,7,3]  R763      1.2336388975381851e-01
    z[3,7,3]  R764      1.4014837145805359e-01
    z[3,7,3]  R765      1.9738397002220154e-01
    z[3,7,3]  R766      -4.3479744344949722e-02
    z[3,7,3]  R767      2.2622174024581909e-01
    z[3,7,3]  R768      -2.4902520701289177e-02
    z[3,7,3]  R769      2.5310555100440979e-01
    z[3,7,3]  R770      3.1763198971748352e-01
    z[3,7,3]  R771      1.9800575077533722e-01
    z[3,7,3]  R772      -2.8173295781016350e-02
    z[3,7,3]  R773      2.2794772684574127e-01
    z[3,7,3]  R774      -0.0826336070895195
    z[3,7,3]  R775      4.6799725294113159e-01
    z[3,7,3]  R776      -2.6709496974945068e-01
    z[3,7,3]  R777      0.503420889377594
    z[3,7,3]  R778      -4.7182232141494751e-02
    z[3,7,3]  R779      -3.2185006886720657e-02
    z[3,7,3]  R780      1.1630264669656754e-01
    z[3,7,3]  R781      3.4428283572196960e-02
    z[3,7,3]  R782      -0.00514657236635685
    z[3,7,3]  R783      8.9136496186256409e-02
    z[3,7,3]  R784      -3.6063587665557861e-01
    z[3,7,3]  R785      -0.081561379134655
    z[3,7,3]  R786      8.1481322646141052e-02
    z[3,7,3]  R787      1.2045668065547943e-01
    z[3,7,3]  R788      3.1591024994850159e-01
    z[3,7,3]  R789      -7.1248807013034821e-02
    z[3,7,3]  R790      -1.9285000860691071e-02
    z[3,7,3]  R791      -1.8393030762672424e-01
    z[3,7,3]  R792      -1.1943616718053818e-01
    z[3,7,3]  R793      -3.4615222364664078e-02
    z[3,7,3]  R794      0.208840012550354
    z[3,7,3]  R795      -2.3434206843376160e-01
    z[3,7,3]  R796      -3.7884226441383362e-01
    z[3,7,3]  R797      -4.3607643246650696e-01
    z[3,7,3]  R798      1.5645003318786621e-01
    z[3,7,3]  R799      4.4591864943504333e-01
    z[3,7,3]  R800      -5.6606572866439819e-01
    z[3,7,3]  R801      -6.4688396453857422e-01
    z[3,7,3]  R802      -6.5649574995040894e-01
    z[3,7,3]  R803      3.6191475391387939e-01
    z[3,7,3]  R804      2.7237620949745178e-01
    z[3,7,3]  R805      6.7980909347534180e-01
    z[3,7,3]  R806      7.3311723768711090e-02
    z[3,7,3]  R807      0.42009437084198
    z[3,7,3]  R808      2.3003891110420227e-01
    z[3,7,3]  R809      3.1932342052459717e-01
    z[3,7,3]  R810      3.5840702056884766e-01
    z[3,7,3]  R811      5.6651169061660767e-01
    z[3,7,3]  R812      2.8356346487998962e-01
    z[3,7,3]  R813      -5.6767380237579346e-01
    z[3,7,3]  R814      -3.6865150928497314e-01
    z[3,7,3]  R815      -3.7740305066108704e-01
    z[3,7,3]  R816      -5.0571990013122559e-01
    z[3,7,3]  R817      -0.410660982131958
    z[3,7,3]  R818      2.1263739466667175e-01
    z[3,7,3]  R819      -5.3038388490676880e-01
    z[3,7,3]  R820      -5.2300339937210083e-01
    z[3,7,3]  R821      -2.2139649093151093e-01
    z[3,7,3]  R822      -4.4104033708572388e-01
    z[3,7,3]  R823      -3.6225321888923645e-01
    z[3,7,3]  R824      1.0925932228565216e-01
    z[3,7,3]  R825      -7.1278387308120728e-01
    z[3,7,3]  R826      2.1688152849674225e-01
    z[3,7,3]  R827      -6.9918829202651978e-01
    z[3,7,3]  R828      2.2615356743335724e-01
    z[3,7,3]  R829      -9.6766859292984009e-02
    z[3,7,3]  R830      -1.0856787860393524e-01
    z[3,7,3]  R831      -7.7130466699600220e-02
    z[3,7,3]  R832      -2.0936983823776245e-01
    z[3,7,3]  R833      5.5666558444499969e-02
    z[3,7,3]  R834      -4.1393363475799561e-01
    z[3,7,3]  R835      -7.4532374739646912e-02
    z[3,7,3]  R836      -3.2952728867530823e-01
    z[3,7,3]  R837      5.7273630052804947e-02
    z[3,7,3]  R838      3.5371991991996765e-01
    z[3,7,3]  R839      6.2036764621734619e-01
    z[3,7,3]  R840      0.174591064453125
    z[3,7,3]  R841      -6.5473616123199463e-02
    z[3,7,3]  R842      9.8076008260250092e-02
    z[3,7,3]  R843      0.54584139585495
    z[3,7,3]  R844      -5.0053983926773071e-01
    z[3,7,3]  R845      -6.7424766719341278e-02
    z[3,7,3]  R846      -4.1990217566490173e-01
    z[3,7,3]  R847      -4.7919595241546631e-01
    z[3,7,3]  R848      -4.7395061701536179e-02
    z[3,7,3]  R849      -7.9899743199348450e-02
    z[3,7,3]  R850      3.8864096999168396e-01
    z[3,7,3]  R851      0.112656369805336
    z[3,7,3]  R852      -1.6416944563388824e-01
    z[3,7,3]  R853      -1.8139523267745972e-01
    z[3,7,3]  R854      -3.0042198300361633e-01
    z[3,7,3]  R855      2.0458501577377319e-01
    z[3,7,3]  R856      0.299461305141449
    z[3,7,3]  R857      -3.0456364154815674e-01
    z[3,7,3]  R858      6.3462370634078979e-01
    z[3,7,3]  R859      -3.1808264553546906e-02
    z[3,7,3]  R860      -6.1111348867416382e-01
    z[3,7,3]  R861      -4.4662916660308838e-01
    z[3,7,3]  R862      -7.2431737184524536e-01
    z[3,7,3]  R863      -9.9267408251762390e-02
    z[3,7,3]  R864      -2.1639212965965271e-01
    z[3,7,3]  R865      4.5839720964431763e-01
    z[3,7,3]  R866      -1.2969951145350933e-02
    z[3,7,3]  R867      1.9489879906177521e-01
    z[3,7,3]  R868      -0.739753782749176
    z[3,7,3]  R869      4.2342305183410645e-01
    z[3,7,3]  R870      -1.6215343773365021e-01
    z[3,7,3]  R871      -6.8730795383453369e-01
    z[3,7,3]  R872      -8.0857044458389282e-01
    z[3,7,3]  R873      -4.8054140806198120e-01
    z[3,7,3]  R874      6.1848795413970947e-01
    z[3,7,3]  R875      -2.5894984602928162e-01
    z[3,7,3]  R876      2.4202822148799896e-01
    z[3,7,3]  R877      2.5243896525353193e-03
    z[3,7,3]  R878      5.7796555757522583e-01
    z[3,7,3]  R879      3.4566736221313477e-01
    z[3,7,3]  R880      -7.0362383127212524e-01
    z[3,7,3]  R881      -3.6247396469116211e-01
    z[3,7,3]  R882      -0.738812267780304
    z[3,7,3]  R883      -4.3917959928512573e-01
    z[3,7,3]  R884      -6.6205725073814392e-02
    z[3,7,3]  R885      2.7190076652914286e-03
    z[3,7,3]  R886      4.7790881991386414e-01
    z[3,7,3]  R887      6.6536128520965576e-01
    z[3,7,3]  R888      2.6913082599639893e-01
    z[3,7,3]  R889      8.1416743993759155e-01
    z[3,7,3]  R890      7.6190240681171417e-02
    z[3,7,3]  R891      7.1276850998401642e-02
    z[3,7,3]  R892      -8.8126683235168457e-01
    z[3,7,3]  R893      -2.3248299956321716e-01
    z[3,7,3]  R894      -1.1482724547386169e-01
    z[3,7,3]  R895      4.6430990099906921e-01
    z[3,7,3]  R896      5.5468821525573730e-01
    z[3,7,3]  R897      1.5193149447441101e-02
    z[3,7,3]  R898      -3.2171458005905151e-02
    z[3,7,3]  R899      5.1962349563837051e-02
    z[3,7,3]  R900      -5.0766462087631226e-01
    z[3,7,3]  R901      -7.0269167423248291e-01
    z[3,7,3]  R902      3.8918992877006531e-01
    z[3,7,3]  R903      -3.2630622386932373e-01
    z[3,7,3]  R904      5.4890251159667969e-01
    z[3,7,3]  R905      3.0041038990020752e-02
    z[3,7,3]  R906      -7.0372693240642548e-02
    z[3,7,3]  R907      -6.6674917936325073e-01
    z[3,7,3]  R908      8.2571476697921753e-01
    z[3,7,3]  R909      1.8634662032127380e-01
    z[3,7,3]  R910      -5.4187369346618652e-01
    z[3,7,3]  R911      -1.8501089513301849e-01
    z[3,7,3]  R912      1.1763103306293488e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R757      -1
    z[3,7,4]  R758      1
    z[3,7,4]  R763      -1.7499543726444244e-01
    z[3,7,4]  R764      -9.3153864145278931e-02
    z[3,7,4]  R765      -4.2097586393356323e-01
    z[3,7,4]  R766      -8.7057955563068390e-02
    z[3,7,4]  R767      1.9317786395549774e-01
    z[3,7,4]  R768      9.1338835656642914e-02
    z[3,7,4]  R769      3.4952649474143982e-01
    z[3,7,4]  R770      1.7258162796497345e-01
    z[3,7,4]  R771      2.2579045966267586e-02
    z[3,7,4]  R772      -4.4032309204339981e-02
    z[3,7,4]  R773      8.7571300566196442e-02
    z[3,7,4]  R774      1.6282857954502106e-01
    z[3,7,4]  R775      -2.4272072315216064e-01
    z[3,7,4]  R776      2.6515156030654907e-01
    z[3,7,4]  R777      -2.6562556624412537e-01
    z[3,7,4]  R778      -5.7785177230834961e-01
    z[3,7,4]  R779      -1.6454145312309265e-01
    z[3,7,4]  R780      -0.111277274787426
    z[3,7,4]  R781      -3.0620154738426208e-01
    z[3,7,4]  R782      -7.2088211774826050e-01
    z[3,7,4]  R783      1.2066298164427280e-02
    z[3,7,4]  R784      2.4230834096670151e-02
    z[3,7,4]  R785      0.0743400976061821
    z[3,7,4]  R786      1.9495931267738342e-01
    z[3,7,4]  R787      -5.6943674571812153e-03
    z[3,7,4]  R788      2.3302891850471497e-01
    z[3,7,4]  R789      -1.9806885719299316e-01
    z[3,7,4]  R790      1.6575929522514343e-01
    z[3,7,4]  R791      -2.6363892480731010e-02
    z[3,7,4]  R792      -3.8546428084373474e-01
    z[3,7,4]  R793      1.8515472114086151e-01
    z[3,7,4]  R794      -4.6308046579360962e-01
    z[3,7,4]  R795      1.9928932189941406e-01
    z[3,7,4]  R796      3.5109764337539673e-01
    z[3,7,4]  R797      -7.7538110315799713e-02
    z[3,7,4]  R798      5.2223944664001465e-01
    z[3,7,4]  R799      -2.9867190122604370e-01
    z[3,7,4]  R800      -2.8627860546112061e-01
    z[3,7,4]  R801      -9.1373048722743988e-02
    z[3,7,4]  R802      5.1102095842361450e-01
    z[3,7,4]  R803      1.6483603417873383e-01
    z[3,7,4]  R804      -2.0548866689205170e-01
    z[3,7,4]  R805      -1.2014985829591751e-01
    z[3,7,4]  R806      2.9497590661048889e-01
    z[3,7,4]  R807      1.4236049354076385e-01
    z[3,7,4]  R808      2.5435414910316467e-01
    z[3,7,4]  R809      1.6347086429595947e-01
    z[3,7,4]  R810      -4.1072311997413635e-01
    z[3,7,4]  R811      -2.4284815788269043e-01
    z[3,7,4]  R812      -1.8633264303207397e-01
    z[3,7,4]  R813      3.5102775692939758e-01
    z[3,7,4]  R814      -4.9579218029975891e-01
    z[3,7,4]  R815      -0.420878142118454
    z[3,7,4]  R816      -1.1079634726047516e-01
    z[3,7,4]  R817      -4.8875716328620911e-01
    z[3,7,4]  R818      -3.1739141792058945e-02
    z[3,7,4]  R819      -1.8995173275470734e-01
    z[3,7,4]  R820      8.6141005158424377e-03
    z[3,7,4]  R821      -2.5475943088531494e-01
    z[3,7,4]  R822      -4.2808291316032410e-01
    z[3,7,4]  R823      -1.7352880537509918e-01
    z[3,7,4]  R824      2.0763443410396576e-01
    z[3,7,4]  R825      -1.5970483422279358e-01
    z[3,7,4]  R826      -0.164675772190094
    z[3,7,4]  R827      6.9020465016365051e-02
    z[3,7,4]  R828      3.3810202032327652e-02
    z[3,7,4]  R829      2.0591814070940018e-02
    z[3,7,4]  R830      1.2437465041875839e-01
    z[3,7,4]  R831      2.7689921855926514e-01
    z[3,7,4]  R832      1.0139914602041245e-01
    z[3,7,4]  R833      -7.4027101509273052e-03
    z[3,7,4]  R834      -9.2984713613986969e-02
    z[3,7,4]  R835      5.7830739021301270e-01
    z[3,7,4]  R836      5.7642382383346558e-01
    z[3,7,4]  R837      9.1092668473720551e-02
    z[3,7,4]  R838      -2.9985904693603516e-01
    z[3,7,4]  R839      -3.4815132617950439e-01
    z[3,7,4]  R840      -5.8498740196228027e-02
    z[3,7,4]  R841      2.5201949477195740e-01
    z[3,7,4]  R842      1.6721126437187195e-01
    z[3,7,4]  R843      1.5844435989856720e-01
    z[3,7,4]  R844      3.3917296677827835e-03
    z[3,7,4]  R845      -1.0530129820108414e-01
    z[3,7,4]  R846      -3.4999931231141090e-03
    z[3,7,4]  R847      1.9685381650924683e-01
    z[3,7,4]  R848      4.1764539480209351e-01
    z[3,7,4]  R849      1.4651700854301453e-01
    z[3,7,4]  R850      4.3963202834129333e-01
    z[3,7,4]  R851      3.0410623550415039e-01
    z[3,7,4]  R852      1.7601549625396729e-01
    z[3,7,4]  R853      -1.3534653186798096e-01
    z[3,7,4]  R854      4.7975964844226837e-02
    z[3,7,4]  R855      1.0215112566947937e-01
    z[3,7,4]  R856      -0.0791703388094902
    z[3,7,4]  R857      -1.5117718279361725e-01
    z[3,7,4]  R858      -0.000655064475722611
    z[3,7,4]  R859      -1.3639484345912933e-01
    z[3,7,4]  R860      -1.7070990800857544e-01
    z[3,7,4]  R861      -4.9967950582504272e-01
    z[3,7,4]  R862      -1.6937865316867828e-01
    z[3,7,4]  R863      5.0345176458358765e-01
    z[3,7,4]  R864      -1.9321238994598389e-01
    z[3,7,4]  R865      -0.510749340057373
    z[3,7,4]  R866      -1.7659065127372742e-01
    z[3,7,4]  R867      -3.2749277353286743e-01
    z[3,7,4]  R868      -1.6959272325038910e-01
    z[3,7,4]  R869      -2.5101867318153381e-01
    z[3,7,4]  R870      -3.8920632004737854e-01
    z[3,7,4]  R871      -3.8718926906585693e-01
    z[3,7,4]  R872      -1.7540577054023743e-01
    z[3,7,4]  R873      2.6764786243438721e-01
    z[3,7,4]  R874      2.7633774280548096e-01
    z[3,7,4]  R875      2.6715666055679321e-01
    z[3,7,4]  R876      1.8802155554294586e-01
    z[3,7,4]  R877      -1.0254956036806107e-01
    z[3,7,4]  R878      2.7900439500808716e-01
    z[3,7,4]  R879      1.4084173738956451e-01
    z[3,7,4]  R880      -3.8704228401184082e-01
    z[3,7,4]  R881      7.1601629257202148e-02
    z[3,7,4]  R882      1.6826494038105011e-01
    z[3,7,4]  R883      6.9450519979000092e-02
    z[3,7,4]  R884      5.5063869804143906e-02
    z[3,7,4]  R885      1.9221821799874306e-02
    z[3,7,4]  R886      0.0171035286039114
    z[3,7,4]  R887      2.2876986861228943e-01
    z[3,7,4]  R888      -2.5459113717079163e-01
    z[3,7,4]  R889      7.4961505830287933e-02
    z[3,7,4]  R890      -1.6473822295665741e-01
    z[3,7,4]  R891      -3.0694943666458130e-01
    z[3,7,4]  R892      -2.2959465160965919e-02
    z[3,7,4]  R893      9.0642586350440979e-02
    z[3,7,4]  R894      4.7416013479232788e-01
    z[3,7,4]  R895      1.4224231243133545e-01
    z[3,7,4]  R896      -3.5413238406181335e-01
    z[3,7,4]  R897      8.0844148993492126e-02
    z[3,7,4]  R898      2.1051813662052155e-01
    z[3,7,4]  R899      -1.5900759398937225e-01
    z[3,7,4]  R900      -2.7241092175245285e-02
    z[3,7,4]  R901      1.8105036020278931e-01
    z[3,7,4]  R902      6.2217503786087036e-01
    z[3,7,4]  R903      3.6257752776145935e-01
    z[3,7,4]  R904      -1.5457384288311005e-01
    z[3,7,4]  R905      1.6399468481540680e-01
    z[3,7,4]  R906      7.4029639363288879e-02
    z[3,7,4]  R907      3.4444069024175406e-03
    z[3,7,4]  R908      2.1715784445405006e-02
    z[3,7,4]  R909      -1.1888762563467026e-01
    z[3,7,4]  R910      -1.4770109951496124e-01
    z[3,7,4]  R911      -2.0655460655689240e-01
    z[3,7,4]  R912      1.4602577686309814e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R759      -1
    z[3,7,5]  R760      1
    z[3,7,5]  R763      3.9365947246551514e-01
    z[3,7,5]  R764      1.8414977192878723e-01
    z[3,7,5]  R765      1.3328801095485687e-01
    z[3,7,5]  R766      2.4706198275089264e-01
    z[3,7,5]  R767      4.0213245153427124e-01
    z[3,7,5]  R768      2.3150397837162018e-01
    z[3,7,5]  R769      5.8123461902141571e-02
    z[3,7,5]  R770      -1.1589889228343964e-01
    z[3,7,5]  R771      -2.0197346806526184e-01
    z[3,7,5]  R772      -3.0134108662605286e-01
    z[3,7,5]  R773      -4.1382014751434326e-01
    z[3,7,5]  R774      -1.6606800258159637e-01
    z[3,7,5]  R775      0.132082000374794
    z[3,7,5]  R776      -1.0103802382946014e-01
    z[3,7,5]  R777      -5.1464891433715820e-01
    z[3,7,5]  R778      -3.7848666310310364e-01
    z[3,7,5]  R779      1.1804620176553726e-01
    z[3,7,5]  R780      2.5822449475526810e-02
    z[3,7,5]  R781      2.5962832570075989e-01
    z[3,7,5]  R782      -3.1875947117805481e-01
    z[3,7,5]  R783      -5.5032365024089813e-02
    z[3,7,5]  R784      -6.8893593549728394e-01
    z[3,7,5]  R785      1.0112300515174866e-01
    z[3,7,5]  R786      8.0109424889087677e-02
    z[3,7,5]  R787      2.6628252863883972e-01
    z[3,7,5]  R788      2.9066300392150879e-01
    z[3,7,5]  R789      2.5254175066947937e-01
    z[3,7,5]  R790      3.9021271467208862e-01
    z[3,7,5]  R791      1.5079198777675629e-01
    z[3,7,5]  R792      1.1973618716001511e-01
    z[3,7,5]  R793      -3.1197625398635864e-01
    z[3,7,5]  R794      -8.2270748913288116e-02
    z[3,7,5]  R795      -3.3672001957893372e-01
    z[3,7,5]  R796      -2.1148182451725006e-01
    z[3,7,5]  R797      -3.8456863164901733e-01
    z[3,7,5]  R798      0.0923554003238678
    z[3,7,5]  R799      5.3185307979583740e-01
    z[3,7,5]  R800      -3.5393461585044861e-01
    z[3,7,5]  R801      -1.6921687126159668e-01
    z[3,7,5]  R802      -2.2447425127029419e-01
    z[3,7,5]  R803      3.6157190799713135e-01
    z[3,7,5]  R804      8.6428232491016388e-02
    z[3,7,5]  R805      1.7475946247577667e-01
    z[3,7,5]  R806      2.1422280371189117e-01
    z[3,7,5]  R807      -2.6312029361724854e-01
    z[3,7,5]  R808      -1.1258765310049057e-01
    z[3,7,5]  R809      -6.9279879331588745e-02
    z[3,7,5]  R810      2.6745384931564331e-01
    z[3,7,5]  R811      -2.8706169128417969e-01
    z[3,7,5]  R812      -2.1840818226337433e-01
    z[3,7,5]  R813      -1.7786248028278351e-01
    z[3,7,5]  R814      -2.1726746112108231e-02
    z[3,7,5]  R815      -6.3736066222190857e-02
    z[3,7,5]  R816      3.1286545097827911e-02
    z[3,7,5]  R817      7.8133922070264816e-03
    z[3,7,5]  R818      1.1068589985370636e-01
    z[3,7,5]  R819      2.6434719562530518e-01
    z[3,7,5]  R820      0.0418284609913826
    z[3,7,5]  R821      1.6630619764328003e-01
    z[3,7,5]  R822      2.8218093514442444e-01
    z[3,7,5]  R823      -0.478199303150177
    z[3,7,5]  R824      -1.9420586526393890e-01
    z[3,7,5]  R825      -7.1430094540119171e-02
    z[3,7,5]  R826      -0.292460560798645
    z[3,7,5]  R827      2.2123925387859344e-01
    z[3,7,5]  R828      -4.1238903999328613e-01
    z[3,7,5]  R829      -3.6590325832366943e-01
    z[3,7,5]  R830      -3.0864715576171875e-01
    z[3,7,5]  R831      -3.1340357661247253e-01
    z[3,7,5]  R832      1.8844987452030182e-01
    z[3,7,5]  R833      -3.8047227263450623e-01
    z[3,7,5]  R834      -2.8123003244400024e-01
    z[3,7,5]  R835      -3.0721798539161682e-01
    z[3,7,5]  R836      -3.0520227551460266e-01
    z[3,7,5]  R837      -2.6596600189805031e-02
    z[3,7,5]  R838      -2.2794160246849060e-01
    z[3,7,5]  R839      -2.9888552427291870e-01
    z[3,7,5]  R840      2.7011623978614807e-01
    z[3,7,5]  R841      -1.4479759335517883e-01
    z[3,7,5]  R842      -3.0097526311874390e-01
    z[3,7,5]  R843      1.1131688207387924e-01
    z[3,7,5]  R844      -3.7510967254638672e-01
    z[3,7,5]  R845      -1.9735524058341980e-01
    z[3,7,5]  R846      -1.3828532397747040e-01
    z[3,7,5]  R847      -3.4852313995361328e-01
    z[3,7,5]  R848      -2.5787869095802307e-01
    z[3,7,5]  R849      -1.0327735543251038e-01
    z[3,7,5]  R850      1.2150023831054568e-03
    z[3,7,5]  R851      -2.3134063184261322e-01
    z[3,7,5]  R852      4.0065199136734009e-02
    z[3,7,5]  R853      -5.5110651254653931e-01
    z[3,7,5]  R854      4.4556212425231934e-01
    z[3,7,5]  R855      2.4070987105369568e-01
    z[3,7,5]  R856      -1.0796731710433960e-01
    z[3,7,5]  R857      2.1233783662319183e-01
    z[3,7,5]  R858      -1.3205768167972565e-01
    z[3,7,5]  R859      -2.4533860385417938e-01
    z[3,7,5]  R860      -3.0848110094666481e-02
    z[3,7,5]  R861      -1.4587184786796570e-01
    z[3,7,5]  R862      0.252546489238739
    z[3,7,5]  R863      -3.6108851432800293e-01
    z[3,7,5]  R864      1.9542382657527924e-01
    z[3,7,5]  R865      -2.3221735656261444e-01
    z[3,7,5]  R866      -3.7104284763336182e-01
    z[3,7,5]  R867      -4.8415485769510269e-02
    z[3,7,5]  R868      2.5979939103126526e-01
    z[3,7,5]  R869      -1.2629453837871552e-01
    z[3,7,5]  R870      -4.3472938239574432e-02
    z[3,7,5]  R871      -3.7419281434267759e-03
    z[3,7,5]  R872      9.2434667050838470e-02
    z[3,7,5]  R873      -4.2871972918510437e-01
    z[3,7,5]  R874      -3.3051091432571411e-01
    z[3,7,5]  R875      3.0744457244873047e-01
    z[3,7,5]  R876      -1.1734230071306229e-01
    z[3,7,5]  R877      -6.0735039412975311e-02
    z[3,7,5]  R878      -4.1593369841575623e-01
    z[3,7,5]  R879      1.5159327536821365e-02
    z[3,7,5]  R880      2.9559774324297905e-02
    z[3,7,5]  R881      -4.1807761788368225e-01
    z[3,7,5]  R882      5.3183263540267944e-01
    z[3,7,5]  R883      5.0590906292200089e-02
    z[3,7,5]  R884      4.6976704150438309e-02
    z[3,7,5]  R885      -4.1004788875579834e-01
    z[3,7,5]  R886      -8.0488964915275574e-02
    z[3,7,5]  R887      -1.3850995898246765e-01
    z[3,7,5]  R888      1.7445281147956848e-01
    z[3,7,5]  R889      -3.7980481982231140e-01
    z[3,7,5]  R890      -0.549176037311554
    z[3,7,5]  R891      -3.1081077456474304e-01
    z[3,7,5]  R892      2.7003228664398193e-01
    z[3,7,5]  R893      -1.6107386350631714e-01
    z[3,7,5]  R894      -5.5078428983688354e-01
    z[3,7,5]  R895      -3.1608107686042786e-01
    z[3,7,5]  R896      -1.7238157987594604e-01
    z[3,7,5]  R897      -1.0442781448364258e-01
    z[3,7,5]  R898      2.9218757152557373e-01
    z[3,7,5]  R899      -4.2967864871025085e-01
    z[3,7,5]  R900      -1.0896987468004227e-01
    z[3,7,5]  R901      1.6916318237781525e-01
    z[3,7,5]  R902      0.0191938616335392
    z[3,7,5]  R903      8.2310363650321960e-02
    z[3,7,5]  R904      -2.0744070410728455e-01
    z[3,7,5]  R905      -1.1092843860387802e-01
    z[3,7,5]  R906      -1.8518300354480743e-01
    z[3,7,5]  R907      2.7184817939996719e-02
    z[3,7,5]  R908      -3.5375106334686279e-01
    z[3,7,5]  R909      -3.9943951368331909e-01
    z[3,7,5]  R910      4.8046806454658508e-01
    z[3,7,5]  R911      -2.3944278061389923e-01
    z[3,7,5]  R912      -7.0862270891666412e-02
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R761      -1
    z[3,7,6]  R762      1
    z[3,7,6]  R763      1.8048782646656036e-01
    z[3,7,6]  R764      -1.2364926747977734e-02
    z[3,7,6]  R765      -1.5485283732414246e-01
    z[3,7,6]  R766      -3.8015130162239075e-01
    z[3,7,6]  R767      -2.1169923245906830e-01
    z[3,7,6]  R768      -3.5489144921302795e-01
    z[3,7,6]  R769      -2.0372769236564636e-01
    z[3,7,6]  R770      3.0969858169555664e-01
    z[3,7,6]  R771      -2.4845942854881287e-01
    z[3,7,6]  R772      9.4537958502769470e-02
    z[3,7,6]  R773      -1.2200947850942612e-01
    z[3,7,6]  R774      4.2418986558914185e-01
    z[3,7,6]  R775      -0.426483690738678
    z[3,7,6]  R776      -1.8254956230521202e-02
    z[3,7,6]  R777      2.0143781602382660e-01
    z[3,7,6]  R778      4.6744823455810547e-01
    z[3,7,6]  R779      -1.4372245967388153e-01
    z[3,7,6]  R780      3.5217520594596863e-01
    z[3,7,6]  R781      -4.5647022128105164e-01
    z[3,7,6]  R782      1.8208703398704529e-01
    z[3,7,6]  R783      -0.01593635417521
    z[3,7,6]  R784      -3.2406035065650940e-01
    z[3,7,6]  R785      1.6168814897537231e-01
    z[3,7,6]  R786      -5.0659310072660446e-02
    z[3,7,6]  R787      2.4650168418884277e-01
    z[3,7,6]  R788      2.1313808392733335e-03
    z[3,7,6]  R789      -2.6850234717130661e-02
    z[3,7,6]  R790      1.1009088903665543e-01
    z[3,7,6]  R791      3.6808228492736816e-01
    z[3,7,6]  R792      1.2661641836166382e-01
    z[3,7,6]  R793      -5.5408710241317749e-01
    z[3,7,6]  R794      -5.0046551227569580e-01
    z[3,7,6]  R795      -2.6688572764396667e-01
    z[3,7,6]  R796      -1.3869464397430420e-02
    z[3,7,6]  R797      1.4463216066360474e-01
    z[3,7,6]  R798      -5.4464846849441528e-01
    z[3,7,6]  R799      2.7732202783226967e-02
    z[3,7,6]  R800      1.2828026711940765e-01
    z[3,7,6]  R801      -3.6480379104614258e-01
    z[3,7,6]  R802      2.2492859512567520e-02
    z[3,7,6]  R803      -2.0635235309600830e-01
    z[3,7,6]  R804      2.2748260200023651e-01
    z[3,7,6]  R805      1.0516013205051422e-01
    z[3,7,6]  R806      -3.9368532598018646e-02
    z[3,7,6]  R807      -3.6459761857986450e-01
    z[3,7,6]  R808      -2.8335893154144287e-01
    z[3,7,6]  R809      -5.0444173812866211e-01
    z[3,7,6]  R810      -1.5931384265422821e-01
    z[3,7,6]  R811      -5.7740285992622375e-03
    z[3,7,6]  R812      -2.2962391376495361e-01
    z[3,7,6]  R813      -1.3790573179721832e-01
    z[3,7,6]  R814      -1.6364523768424988e-01
    z[3,7,6]  R815      -8.3632849156856537e-02
    z[3,7,6]  R816      6.0002632439136505e-02
    z[3,7,6]  R817      1.8504603207111359e-01
    z[3,7,6]  R818      -2.1147492527961731e-01
    z[3,7,6]  R819      1.3096566312015057e-02
    z[3,7,6]  R820      -2.7766495943069458e-01
    z[3,7,6]  R821      -8.0890739336609840e-03
    z[3,7,6]  R822      2.4081563949584961e-01
    z[3,7,6]  R823      1.4388850331306458e-01
    z[3,7,6]  R824      5.9924638271331787e-01
    z[3,7,6]  R825      4.3836173415184021e-01
    z[3,7,6]  R826      4.5063480734825134e-01
    z[3,7,6]  R827      1.4219434559345245e-01
    z[3,7,6]  R828      4.7252067923545837e-01
    z[3,7,6]  R829      -4.1448645293712616e-02
    z[3,7,6]  R830      1.7293691635131836e-01
    z[3,7,6]  R831      2.1829646080732346e-02
    z[3,7,6]  R832      3.9265986531972885e-02
    z[3,7,6]  R833      7.6660722494125366e-02
    z[3,7,6]  R834      -5.6128031015396118e-01
    z[3,7,6]  R835      4.9747237563133240e-01
    z[3,7,6]  R836      -4.6390643715858459e-01
    z[3,7,6]  R837      4.7608932852745056e-01
    z[3,7,6]  R838      -6.2533393502235413e-02
    z[3,7,6]  R839      2.1993571519851685e-01
    z[3,7,6]  R840      3.4372383356094360e-01
    z[3,7,6]  R841      3.4728819131851196e-01
    z[3,7,6]  R842      0.255688339471817
    z[3,7,6]  R843      4.2310228943824768e-01
    z[3,7,6]  R844      6.8588759750127792e-03
    z[3,7,6]  R845      2.3477682471275330e-01
    z[3,7,6]  R846      -4.1881051659584045e-01
    z[3,7,6]  R847      3.9004996418952942e-01
    z[3,7,6]  R848      -0.335882306098938
    z[3,7,6]  R849      -1.6593678295612335e-01
    z[3,7,6]  R850      2.6671022176742554e-01
    z[3,7,6]  R851      6.2468592077493668e-03
    z[3,7,6]  R852      -8.7136939167976379e-02
    z[3,7,6]  R853      -2.9209271073341370e-01
    z[3,7,6]  R854      0.44937664270401
    z[3,7,6]  R855      -9.9995970726013184e-02
    z[3,7,6]  R856      1.3004487752914429e-01
    z[3,7,6]  R857      -4.5862618088722229e-01
    z[3,7,6]  R858      -5.1394551992416382e-01
    z[3,7,6]  R859      -2.0621180534362793e-01
    z[3,7,6]  R860      2.0252232253551483e-01
    z[3,7,6]  R861      -1.0687220841646194e-01
    z[3,7,6]  R862      -6.3475079834461212e-02
    z[3,7,6]  R863      -1.4392933249473572e-01
    z[3,7,6]  R864      3.9627268910408020e-01
    z[3,7,6]  R865      -1.1192449927330017e-01
    z[3,7,6]  R866      -1.2898662686347961e-01
    z[3,7,6]  R867      4.8706603050231934e-01
    z[3,7,6]  R868      1.6122156381607056e-01
    z[3,7,6]  R869      -0.574490487575531
    z[3,7,6]  R870      2.2059172391891479e-02
    z[3,7,6]  R871      2.1027492359280586e-02
    z[3,7,6]  R872      -9.4802536070346832e-02
    z[3,7,6]  R873      -2.5701060891151428e-02
    z[3,7,6]  R874      -1.7384913563728333e-01
    z[3,7,6]  R875      0.0712905079126358
    z[3,7,6]  R876      -2.4445161223411560e-01
    z[3,7,6]  R877      -4.6912181377410889e-01
    z[3,7,6]  R878      -2.4328069388866425e-01
    z[3,7,6]  R879      3.8897043466567993e-01
    z[3,7,6]  R880      -3.2586455345153809e-01
    z[3,7,6]  R881      1.1651214212179184e-02
    z[3,7,6]  R882      1.5964837744832039e-02
    z[3,7,6]  R883      7.3880054056644440e-02
    z[3,7,6]  R884      -3.6409109830856323e-02
    z[3,7,6]  R885      1.9887593388557434e-01
    z[3,7,6]  R886      2.9521992802619934e-01
    z[3,7,6]  R887      5.9096522629261017e-02
    z[3,7,6]  R888      4.5569464564323425e-01
    z[3,7,6]  R889      -1.0193645209074020e-01
    z[3,7,6]  R890      -2.6325622200965881e-01
    z[3,7,6]  R891      5.2250474691390991e-02
    z[3,7,6]  R892      6.4070552587509155e-02
    z[3,7,6]  R893      -2.2096963226795197e-01
    z[3,7,6]  R894      -1.0697133839130402e-01
    z[3,7,6]  R895      6.6424749791622162e-02
    z[3,7,6]  R896      -2.0087711513042450e-02
    z[3,7,6]  R897      2.4833540618419647e-01
    z[3,7,6]  R898      8.2687549293041229e-02
    z[3,7,6]  R899      -3.9547204971313477e-01
    z[3,7,6]  R900      -2.3731590807437897e-01
    z[3,7,6]  R901      -3.3022749423980713e-01
    z[3,7,6]  R902      -0.458345502614975
    z[3,7,6]  R903      4.8635181784629822e-01
    z[3,7,6]  R904      -2.1411462128162384e-01
    z[3,7,6]  R905      1.3943125307559967e-01
    z[3,7,6]  R906      3.0752828717231750e-01
    z[3,7,6]  R907      1.5022693574428558e-01
    z[3,7,6]  R908      -6.2335506081581116e-02
    z[3,7,6]  R909      2.1135514974594116e-01
    z[3,7,6]  R910      -0.360663503408432
    z[3,7,6]  R911      6.0167215764522552e-02
    z[3,7,6]  R912      2.0817078649997711e-02
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R913      -1
    z[7,3,0]  R914      1
    z[7,3,0]  R927      0.77576744556427
    z[7,3,0]  R928      8.8025522232055664e-01
    z[7,3,0]  R929      6.4333146810531616e-01
    z[7,3,0]  R930      8.7296146154403687e-01
    z[7,3,0]  R931      6.7654889822006226e-01
    z[7,3,0]  R932      7.7571070194244385e-01
    z[7,3,0]  R933      7.1319955587387085e-01
    z[7,3,0]  R934      7.6416790485382080e-01
    z[7,3,0]  R935      0.66385817527771
    z[7,3,0]  R936      7.3412883281707764e-01
    z[7,3,0]  R937      -0.0723298192024231
    z[7,3,0]  R938      -3.6823704838752747e-01
    z[7,3,0]  R939      -1.8581800162792206e-01
    z[7,3,0]  R940      -2.1017327904701233e-01
    z[7,3,0]  R941      -4.3952235579490662e-01
    z[7,3,0]  R942      -0.404788076877594
    z[7,3,0]  R943      6.5057352185249329e-02
    z[7,3,0]  R944      -3.6465483903884888e-01
    z[7,3,0]  R945      -7.1978025138378143e-02
    z[7,3,0]  R946      -1.6103573143482208e-02
    z[7,3,0]  R947      1.5172088146209717e-01
    z[7,3,0]  R948      8.2185946404933929e-02
    z[7,3,0]  R949      2.3939360678195953e-01
    z[7,3,0]  R950      0.133229598402977
    z[7,3,0]  R951      3.4232255816459656e-01
    z[7,3,0]  R952      2.4072253704071045e-01
    z[7,3,0]  R953      -0.907288670539856
    z[7,3,0]  R954      -9.0061253309249878e-01
    z[7,3,0]  R955      -7.9439109563827515e-01
    z[7,3,0]  R956      -7.9312282800674438e-01
    z[7,3,0]  R957      6.7805558443069458e-02
    z[7,3,0]  R958      3.4394392371177673e-01
    z[7,3,0]  R959      3.5133108496665955e-01
    z[7,3,0]  R960      2.5730523467063904e-01
    z[7,3,0]  R961      -4.4008356332778931e-01
    z[7,3,0]  R962      -8.8031291961669922e-02
    z[7,3,0]  R963      -1.8469962477684021e-01
    z[7,3,0]  R964      1.5967264771461487e-01
    z[7,3,0]  R965      -7.2020488977432251e-01
    z[7,3,0]  R966      -5.1735591888427734e-01
    z[7,3,0]  R967      6.6200077533721924e-01
    z[7,3,0]  R968      6.1138284206390381e-01
    z[7,3,0]  R969      3.5945829749107361e-01
    z[7,3,0]  R970      3.4982198476791382e-01
    z[7,3,0]  R971      4.5862689614295959e-01
    z[7,3,0]  R972      -3.2159939408302307e-02
    z[7,3,0]  R973      -0.553945779800415
    z[7,3,0]  R974      -1.6781832277774811e-01
    z[7,3,0]  R975      2.1491825580596924e-01
    z[7,3,0]  R976      -8.2912176847457886e-01
    z[7,3,0]  R977      3.9126396179199219e-01
    z[7,3,0]  R978      2.4881863594055176e-01
    z[7,3,0]  R979      2.1482163667678833e-01
    z[7,3,0]  R980      1.6018109396100044e-02
    z[7,3,0]  R981      1.4037631452083588e-01
    z[7,3,0]  R982      -1.0633911192417145e-01
    z[7,3,0]  R983      3.5546919703483582e-01
    z[7,3,0]  R984      -7.3311340808868408e-01
    z[7,3,0]  R985      -0.69478839635849
    z[7,3,0]  R986      -6.0788959264755249e-01
    z[7,3,0]  R987      9.3835823237895966e-02
    z[7,3,0]  R988      3.0185481905937195e-01
    z[7,3,0]  R989      6.9934844970703125e-02
    z[7,3,0]  R990      -3.5546261817216873e-02
    z[7,3,0]  R991      -2.1151846647262573e-01
    z[7,3,0]  R992      2.6397460699081421e-01
    z[7,3,0]  R993      1.4714916236698627e-02
    z[7,3,0]  R994      -0.826717734336853
    z[7,3,0]  R995      -5.6553375720977783e-01
    z[7,3,0]  R996      -4.6557343006134033e-01
    z[7,3,0]  R997      2.2465810179710388e-01
    z[7,3,0]  R998      -7.3979392647743225e-02
    z[7,3,0]  R999      -0.567614734172821
    z[7,3,0]  R1000     2.2830119729042053e-01
    z[7,3,0]  R1001     3.2732114195823669e-01
    z[7,3,0]  R1002     -2.1348632872104645e-01
    z[7,3,0]  R1003     -5.2942311763763428e-01
    z[7,3,0]  R1004     -4.3943038582801819e-01
    z[7,3,0]  R1005     -7.5273221731185913e-01
    z[7,3,0]  R1006     -2.6824358105659485e-01
    z[7,3,0]  R1007     -5.7141637802124023e-01
    z[7,3,0]  R1008     -7.9831665754318237e-01
    z[7,3,0]  R1009     2.3983244597911835e-01
    z[7,3,0]  R1010     -4.5837086439132690e-01
    z[7,3,0]  R1011     -2.7903449535369873e-01
    z[7,3,0]  R1012     -2.3343828320503235e-01
    z[7,3,0]  R1013     -1.9718140363693237e-01
    z[7,3,0]  R1014     1.6486378014087677e-01
    z[7,3,0]  R1015     -8.1450670957565308e-01
    z[7,3,0]  R1016     -2.9810729622840881e-01
    z[7,3,0]  R1017     0.346869558095932
    z[7,3,0]  R1018     1.3677033782005310e-01
    z[7,3,0]  R1019     -2.9752010107040405e-01
    z[7,3,0]  R1020     -2.8384643793106079e-01
    z[7,3,0]  R1021     1.6154052317142487e-01
    z[7,3,0]  R1022     -4.7044627368450165e-02
    z[7,3,0]  R1023     2.0723946392536163e-01
    z[7,3,0]  R1024     -0.820107102394104
    z[7,3,0]  R1025     -5.7578301429748535e-01
    z[7,3,0]  R1026     -0.0969822108745575
    z[7,3,0]  R1027     6.0532465577125549e-02
    z[7,3,0]  R1028     -4.2753165960311890e-01
    z[7,3,0]  R1029     -1.7922100424766541e-01
    z[7,3,0]  R1030     -5.5445814132690430e-01
    z[7,3,0]  R1031     0.257851779460907
    z[7,3,0]  R1032     -1.9561986625194550e-01
    z[7,3,0]  R1033     -7.6634180545806885e-01
    z[7,3,0]  R1034     -2.9960823059082031e-01
    z[7,3,0]  R1035     -6.7675042152404785e-01
    z[7,3,0]  R1036     -7.6143556833267212e-01
    z[7,3,0]  R1037     7.1162068843841553e-01
    z[7,3,0]  R1038     9.5327025651931763e-01
    z[7,3,0]  R1039     7.0742470026016235e-01
    z[7,3,0]  R1040     0.798708438873291
    z[7,3,0]  R1041     5.8215296268463135e-01
    z[7,3,0]  R1042     8.0113774538040161e-01
    z[7,3,0]  R1043     8.3893394470214844e-01
    z[7,3,0]  R1044     7.2176802158355713e-01
    z[7,3,0]  R1045     6.9075030088424683e-01
    z[7,3,0]  R1046     6.9604158401489258e-01
    z[7,3,0]  R1047     -4.7281497716903687e-01
    z[7,3,0]  R1048     -6.8683397769927979e-01
    z[7,3,0]  R1049     -6.7731253802776337e-02
    z[7,3,0]  R1050     -3.9962872862815857e-01
    z[7,3,0]  R1051     -1.8932853639125824e-01
    z[7,3,0]  R1052     -4.4252589344978333e-01
    z[7,3,0]  R1053     -4.3393689393997192e-01
    z[7,3,0]  R1054     -2.8371793031692505e-01
    z[7,3,0]  R1055     -3.8343551754951477e-01
    z[7,3,0]  R1056     -3.8241106271743774e-01
    z[7,3,0]  R1057     1.2241673469543457e-01
    z[7,3,0]  R1058     -1.2061749584972858e-02
    z[7,3,0]  R1059     -1.4337897300720215e-01
    z[7,3,0]  R1060     -2.2681014239788055e-01
    z[7,3,0]  R1061     -1.9298419356346130e-01
    z[7,3,0]  R1062     -4.9005974084138870e-02
    z[7,3,0]  R1063     -1.9798719882965088e-01
    z[7,3,0]  R1064     5.4058995097875595e-02
    z[7,3,0]  R1065     1.2684838473796844e-01
    z[7,3,0]  R1066     -1.7259445041418076e-02
    z[7,3,0]  R1067     1.5683120489120483e-01
    z[7,3,0]  R1068     -5.1860684156417847e-01
    z[7,3,0]  R1069     2.6655766367912292e-01
    z[7,3,0]  R1070     -5.6426441669464111e-01
    z[7,3,0]  R1071     2.5352329015731812e-02
    z[7,3,0]  R1072     -6.1914050579071045e-01
    z[7,3,0]  R1073     -3.5635665059089661e-01
    z[7,3,0]  R1074     3.6339778453111649e-02
    z[7,3,0]  R1075     7.9450950026512146e-02
    z[7,3,0]  R1076     2.2689421474933624e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R915      -1
    z[7,3,1]  R916      1
    z[7,3,1]  R927      1.6411490738391876e-02
    z[7,3,1]  R928      1.8768697977066040e-01
    z[7,3,1]  R929      -2.3674362897872925e-01
    z[7,3,1]  R930      2.9516544938087463e-01
    z[7,3,1]  R931      2.3874360322952271e-01
    z[7,3,1]  R932      2.4278904497623444e-01
    z[7,3,1]  R933      3.0271226167678833e-01
    z[7,3,1]  R934      -5.8600634336471558e-02
    z[7,3,1]  R935      2.9660817980766296e-01
    z[7,3,1]  R936      4.3455091118812561e-01
    z[7,3,1]  R937      5.2240979671478271e-01
    z[7,3,1]  R938      -5.1190710067749023e-01
    z[7,3,1]  R939      -4.8452475666999817e-01
    z[7,3,1]  R940      -0.502964437007904
    z[7,3,1]  R941      -4.7964704036712646e-01
    z[7,3,1]  R942      -0.854331910610199
    z[7,3,1]  R943      -5.2673918008804321e-01
    z[7,3,1]  R944      -4.7937366366386414e-01
    z[7,3,1]  R945      -7.8769600391387939e-01
    z[7,3,1]  R946      -5.6490635871887207e-01
    z[7,3,1]  R947      1.2438297271728516e-02
    z[7,3,1]  R948      6.8744570016860962e-01
    z[7,3,1]  R949      4.6005198359489441e-01
    z[7,3,1]  R950      -7.7825301885604858e-01
    z[7,3,1]  R951      -2.2731673717498779e-01
    z[7,3,1]  R952      -6.9942563772201538e-01
    z[7,3,1]  R953      -1.7192485928535461e-01
    z[7,3,1]  R954      -1.9084727764129639e-01
    z[7,3,1]  R955      -3.4105113148689270e-01
    z[7,3,1]  R956      -2.1921217441558838e-01
    z[7,3,1]  R957      6.6876864433288574e-01
    z[7,3,1]  R958      2.2041143476963043e-01
    z[7,3,1]  R959      2.5117090344429016e-01
    z[7,3,1]  R960      1.6876345872879028e-01
    z[7,3,1]  R961      -7.2898006439208984e-01
    z[7,3,1]  R962      -7.4544352293014526e-01
    z[7,3,1]  R963      -5.6649994850158691e-01
    z[7,3,1]  R964      -0.865119218826294
    z[7,3,1]  R965      -0.507922351360321
    z[7,3,1]  R966      -0.618511438369751
    z[7,3,1]  R967      -2.1649330854415894e-01
    z[7,3,1]  R968      3.0930796265602112e-01
    z[7,3,1]  R969      8.4924995899200439e-01
    z[7,3,1]  R970      4.2335382103919983e-01
    z[7,3,1]  R971      4.6006661653518677e-01
    z[7,3,1]  R972      7.8704708814620972e-01
    z[7,3,1]  R973      -7.1661293506622314e-01
    z[7,3,1]  R974      -7.4266058206558228e-01
    z[7,3,1]  R975      -8.4290659427642822e-01
    z[7,3,1]  R976      -4.6834820508956909e-01
    z[7,3,1]  R977      3.1773579120635986e-01
    z[7,3,1]  R978      3.5326966643333435e-01
    z[7,3,1]  R979      -8.7270236015319824e-01
    z[7,3,1]  R980      -8.1956350803375244e-01
    z[7,3,1]  R981      6.7453527450561523e-01
    z[7,3,1]  R982      -5.3128945827484131e-01
    z[7,3,1]  R983      -0.854092001914978
    z[7,3,1]  R984      1.3329645991325378e-01
    z[7,3,1]  R985      1.7880636453628540e-01
    z[7,3,1]  R986      -1.1599297635257244e-02
    z[7,3,1]  R987      7.3112434148788452e-01
    z[7,3,1]  R988      3.0246776342391968e-01
    z[7,3,1]  R989      -6.0424768924713135e-01
    z[7,3,1]  R990      -0.900780975818634
    z[7,3,1]  R991      -7.2514319419860840e-01
    z[7,3,1]  R992      4.5567423105239868e-01
    z[7,3,1]  R993      -6.1548978090286255e-01
    z[7,3,1]  R994      -2.8613340854644775e-01
    z[7,3,1]  R995      2.3322394490242004e-01
    z[7,3,1]  R996      2.5845530629158020e-01
    z[7,3,1]  R997      4.8997023701667786e-01
    z[7,3,1]  R998      4.0439867973327637e-01
    z[7,3,1]  R999      -0.656741201877594
    z[7,3,1]  R1000     -8.8230144977569580e-01
    z[7,3,1]  R1001     -8.0567622184753418e-01
    z[7,3,1]  R1002     -5.0674062967300415e-01
    z[7,3,1]  R1003     -5.5835723876953125e-01
    z[7,3,1]  R1004     1.6405096650123596e-01
    z[7,3,1]  R1005     4.2379528284072876e-02
    z[7,3,1]  R1006     -2.6594796776771545e-01
    z[7,3,1]  R1007     -5.7925939559936523e-01
    z[7,3,1]  R1008     -5.6226819753646851e-01
    z[7,3,1]  R1009     -7.9547297954559326e-01
    z[7,3,1]  R1010     -6.3943260908126831e-01
    z[7,3,1]  R1011     -5.9386724233627319e-01
    z[7,3,1]  R1012     -7.3498421907424927e-01
    z[7,3,1]  R1013     -3.1208464503288269e-01
    z[7,3,1]  R1014     -6.8900579214096069e-01
    z[7,3,1]  R1015     -3.7101477384567261e-01
    z[7,3,1]  R1016     6.6063500940799713e-02
    z[7,3,1]  R1017     5.4832839965820312e-01
    z[7,3,1]  R1018     5.9515094757080078e-01
    z[7,3,1]  R1019     -7.0391672849655151e-01
    z[7,3,1]  R1020     -6.7108732461929321e-01
    z[7,3,1]  R1021     -0.752247154712677
    z[7,3,1]  R1022     -8.9022374153137207e-01
    z[7,3,1]  R1023     -7.2310638427734375e-01
    z[7,3,1]  R1024     2.3239577189087868e-02
    z[7,3,1]  R1025     -2.1518308669328690e-02
    z[7,3,1]  R1026     -4.8537105321884155e-01
    z[7,3,1]  R1027     2.7299115061759949e-01
    z[7,3,1]  R1028     -6.1635011434555054e-01
    z[7,3,1]  R1029     -8.9283865690231323e-01
    z[7,3,1]  R1030     -6.3888096809387207e-01
    z[7,3,1]  R1031     0.512329638004303
    z[7,3,1]  R1032     -2.2371679544448853e-01
    z[7,3,1]  R1033     -3.9436888694763184e-01
    z[7,3,1]  R1034     -4.8325982689857483e-01
    z[7,3,1]  R1035     3.8783061504364014e-01
    z[7,3,1]  R1036     2.6828026771545410e-01
    z[7,3,1]  R1037     -9.5694243907928467e-02
    z[7,3,1]  R1038     -3.7281468510627747e-02
    z[7,3,1]  R1039     2.7269739075563848e-04
    z[7,3,1]  R1040     1.2312665581703186e-01
    z[7,3,1]  R1041     2.2732684016227722e-01
    z[7,3,1]  R1042     -2.7584299445152283e-01
    z[7,3,1]  R1043     8.5411950945854187e-02
    z[7,3,1]  R1044     9.4852922484278679e-03
    z[7,3,1]  R1045     -3.8345813751220703e-01
    z[7,3,1]  R1046     -1.6182261705398560e-01
    z[7,3,1]  R1047     3.8585740327835083e-01
    z[7,3,1]  R1048     2.5853881239891052e-01
    z[7,3,1]  R1049     5.1659452915191650e-01
    z[7,3,1]  R1050     6.1803042888641357e-01
    z[7,3,1]  R1051     4.8582258820533752e-01
    z[7,3,1]  R1052     2.7209252119064331e-01
    z[7,3,1]  R1053     8.4815979003906250e-01
    z[7,3,1]  R1054     0.591509997844696
    z[7,3,1]  R1055     6.3983148336410522e-01
    z[7,3,1]  R1056     4.4348701834678650e-01
    z[7,3,1]  R1057     -0.985664963722229
    z[7,3,1]  R1058     4.2809438705444336e-01
    z[7,3,1]  R1059     -9.2774575948715210e-01
    z[7,3,1]  R1060     -9.0466153621673584e-01
    z[7,3,1]  R1061     -8.9581912755966187e-01
    z[7,3,1]  R1062     -8.7088793516159058e-01
    z[7,3,1]  R1063     -9.1231465339660645e-01
    z[7,3,1]  R1064     -0.892479658126831
    z[7,3,1]  R1065     -8.8815581798553467e-01
    z[7,3,1]  R1066     -8.9752441644668579e-01
    z[7,3,1]  R1067     0.728148341178894
    z[7,3,1]  R1068     3.8828489184379578e-01
    z[7,3,1]  R1069     7.8841805458068848e-01
    z[7,3,1]  R1070     4.5100745558738708e-01
    z[7,3,1]  R1071     0.782682478427887
    z[7,3,1]  R1072     7.1726846508681774e-03
    z[7,3,1]  R1073     -2.3392945528030396e-01
    z[7,3,1]  R1074     -6.7416888475418091e-01
    z[7,3,1]  R1075     -6.3650351762771606e-01
    z[7,3,1]  R1076     -4.3019664287567139e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R917      -1
    z[7,3,2]  R918      1
    z[7,3,2]  R927      2.5777277350425720e-01
    z[7,3,2]  R928      -1.1954865604639053e-01
    z[7,3,2]  R929      1.0909274965524673e-01
    z[7,3,2]  R930      -1.0482856631278992e-01
    z[7,3,2]  R931      -2.9389381408691406e-01
    z[7,3,2]  R932      -0.358809232711792
    z[7,3,2]  R933      -0.108444444835186
    z[7,3,2]  R934      1.3620543479919434e-01
    z[7,3,2]  R935      -9.4696566462516785e-02
    z[7,3,2]  R936      -2.3804001510143280e-01
    z[7,3,2]  R937      4.7510975599288940e-01
    z[7,3,2]  R938      -4.3975785374641418e-01
    z[7,3,2]  R939      -6.3251811265945435e-01
    z[7,3,2]  R940      -6.5593171119689941e-01
    z[7,3,2]  R941      -3.6732786893844604e-01
    z[7,3,2]  R942      5.5395025759935379e-02
    z[7,3,2]  R943      -5.7521623373031616e-01
    z[7,3,2]  R944      -5.3364193439483643e-01
    z[7,3,2]  R945      -4.8240253329277039e-01
    z[7,3,2]  R946      -4.0648695826530457e-01
    z[7,3,2]  R947      7.5240141153335571e-01
    z[7,3,2]  R948      2.6230162382125854e-01
    z[7,3,2]  R949      -1.4601278118789196e-02
    z[7,3,2]  R950      1.1752258241176605e-01
    z[7,3,2]  R951      5.1802337169647217e-01
    z[7,3,2]  R952      -8.5014671087265015e-02
    z[7,3,2]  R953      -4.3336819857358932e-02
    z[7,3,2]  R954      -6.9281840696930885e-03
    z[7,3,2]  R955      2.6703259348869324e-01
    z[7,3,2]  R956      4.8138287663459778e-01
    z[7,3,2]  R957      6.2798202037811279e-01
    z[7,3,2]  R958      5.0892859697341919e-01
    z[7,3,2]  R959      3.6279958486557007e-01
    z[7,3,2]  R960      3.9509826898574829e-01
    z[7,3,2]  R961      -1.8965192139148712e-01
    z[7,3,2]  R962      -4.0701773762702942e-01
    z[7,3,2]  R963      -3.4555483609437943e-02
    z[7,3,2]  R964      -3.2562226057052612e-02
    z[7,3,2]  R965      -1.1808338761329651e-01
    z[7,3,2]  R966      -3.9527878165245056e-01
    z[7,3,2]  R967      2.0764118060469627e-02
    z[7,3,2]  R968      3.7314009666442871e-01
    z[7,3,2]  R969      1.9965112209320068e-01
    z[7,3,2]  R970      5.7231187820434570e-01
    z[7,3,2]  R971      1.8976931273937225e-01
    z[7,3,2]  R972      1.5339636802673340e-01
    z[7,3,2]  R973      -3.3698305487632751e-01
    z[7,3,2]  R974      -6.9558590650558472e-02
    z[7,3,2]  R975      -2.9084178805351257e-01
    z[7,3,2]  R976      1.6147981584072113e-01
    z[7,3,2]  R977      5.5289882421493530e-01
    z[7,3,2]  R978      5.6592386960983276e-01
    z[7,3,2]  R979      -2.6835048198699951e-01
    z[7,3,2]  R980      -4.5116010308265686e-01
    z[7,3,2]  R981      3.9275681972503662e-01
    z[7,3,2]  R982      1.4864921569824219e-01
    z[7,3,2]  R983      1.4777974784374237e-01
    z[7,3,2]  R984      1.4433830045163631e-02
    z[7,3,2]  R985      5.8649875223636627e-02
    z[7,3,2]  R986      9.5928184688091278e-02
    z[7,3,2]  R987      2.0550854504108429e-01
    z[7,3,2]  R988      0.733496904373169
    z[7,3,2]  R989      -3.0421867966651917e-01
    z[7,3,2]  R990      4.0832184255123138e-02
    z[7,3,2]  R991      -2.1121737360954285e-01
    z[7,3,2]  R992      -2.3063591122627258e-01
    z[7,3,2]  R993      -1.8074475228786469e-01
    z[7,3,2]  R994      2.3348145186901093e-01
    z[7,3,2]  R995      -5.4902553558349609e-02
    z[7,3,2]  R996      -1.1982156336307526e-01
    z[7,3,2]  R997      4.7163677215576172e-01
    z[7,3,2]  R998      4.8232552409172058e-01
    z[7,3,2]  R999      9.2045597732067108e-02
    z[7,3,2]  R1000     4.4353265315294266e-02
    z[7,3,2]  R1001     -0.0972619354724884
    z[7,3,2]  R1002     -2.3143781721591949e-01
    z[7,3,2]  R1003     3.4219604730606079e-01
    z[7,3,2]  R1004     -1.6744692623615265e-01
    z[7,3,2]  R1005     -3.4664005041122437e-01
    z[7,3,2]  R1006     -7.7150254510343075e-03
    z[7,3,2]  R1007     -3.6362352967262268e-01
    z[7,3,2]  R1008     1.8867236375808716e-01
    z[7,3,2]  R1009     -3.1880292296409607e-01
    z[7,3,2]  R1010     2.4227949976921082e-01
    z[7,3,2]  R1011     2.2747018933296204e-01
    z[7,3,2]  R1012     1.7310473322868347e-01
    z[7,3,2]  R1013     2.0147490501403809e-01
    z[7,3,2]  R1014     -3.0700030922889709e-01
    z[7,3,2]  R1015     1.7181381583213806e-02
    z[7,3,2]  R1016     -2.2931785881519318e-01
    z[7,3,2]  R1017     6.6481626033782959e-01
    z[7,3,2]  R1018     2.7252513170242310e-01
    z[7,3,2]  R1019     -2.7540338039398193e-01
    z[7,3,2]  R1020     7.6584428548812866e-02
    z[7,3,2]  R1021     -5.7331192493438721e-01
    z[7,3,2]  R1022     -2.6023969054222107e-01
    z[7,3,2]  R1023     -2.5527155399322510e-01
    z[7,3,2]  R1024     -1.5020149759948254e-02
    z[7,3,2]  R1025     -6.1559706926345825e-02
    z[7,3,2]  R1026     7.7393390238285065e-02
    z[7,3,2]  R1027     6.6374713182449341e-01
    z[7,3,2]  R1028     1.5252985060214996e-01
    z[7,3,2]  R1029     -3.3343076705932617e-01
    z[7,3,2]  R1030     -3.8093057274818420e-01
    z[7,3,2]  R1031     -4.5072987675666809e-01
    z[7,3,2]  R1032     3.1683048605918884e-01
    z[7,3,2]  R1033     -6.4119093120098114e-02
    z[7,3,2]  R1034     1.8009927123785019e-02
    z[7,3,2]  R1035     -5.0373566150665283e-01
    z[7,3,2]  R1036     -5.5464059114456177e-01
    z[7,3,2]  R1037     5.0105190277099609e-01
    z[7,3,2]  R1038     1.6583970189094543e-01
    z[7,3,2]  R1039     4.9155265092849731e-01
    z[7,3,2]  R1040     3.6315330862998962e-01
    z[7,3,2]  R1041     5.6071329116821289e-01
    z[7,3,2]  R1042     3.0591517686843872e-01
    z[7,3,2]  R1043     2.4037525057792664e-01
    z[7,3,2]  R1044     0.488815575838089
    z[7,3,2]  R1045     4.8330357670783997e-01
    z[7,3,2]  R1046     6.2198311090469360e-01
    z[7,3,2]  R1047     -6.1789786815643311e-01
    z[7,3,2]  R1048     -4.6963772177696228e-01
    z[7,3,2]  R1049     -5.0127208232879639e-01
    z[7,3,2]  R1050     -5.5330657958984375e-01
    z[7,3,2]  R1051     -3.1416711211204529e-01
    z[7,3,2]  R1052     -1.7954818904399872e-01
    z[7,3,2]  R1053     1.7211334407329559e-01
    z[7,3,2]  R1054     -6.4731532335281372e-01
    z[7,3,2]  R1055     -2.6995593309402466e-01
    z[7,3,2]  R1056     -5.1188085228204727e-02
    z[7,3,2]  R1057     0.0458839125931263
    z[7,3,2]  R1058     0.326031357049942
    z[7,3,2]  R1059     2.6491987705230713e-01
    z[7,3,2]  R1060     2.7660864591598511e-01
    z[7,3,2]  R1061     1.1854731291532516e-01
    z[7,3,2]  R1062     -2.3694671690464020e-02
    z[7,3,2]  R1063     1.4027518033981323e-01
    z[7,3,2]  R1064     -9.1233126819133759e-02
    z[7,3,2]  R1065     4.8379283398389816e-02
    z[7,3,2]  R1066     -3.0592581257224083e-02
    z[7,3,2]  R1067     -0.0733601376414299
    z[7,3,2]  R1068     2.5493115186691284e-01
    z[7,3,2]  R1069     -1.6764026880264282e-01
    z[7,3,2]  R1070     4.0803188085556030e-01
    z[7,3,2]  R1071     -1.4757739007472992e-01
    z[7,3,2]  R1072     1.1929593980312347e-01
    z[7,3,2]  R1073     -4.9659019708633423e-01
    z[7,3,2]  R1074     8.0252867192029953e-03
    z[7,3,2]  R1075     5.1690624095499516e-03
    z[7,3,2]  R1076     -1.4292004704475403e-01
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R919      -1
    z[7,3,3]  R920      1
    z[7,3,3]  R927      3.6191475391387939e-01
    z[7,3,3]  R928      2.7237620949745178e-01
    z[7,3,3]  R929      6.7980909347534180e-01
    z[7,3,3]  R930      7.3311723768711090e-02
    z[7,3,3]  R931      0.42009437084198
    z[7,3,3]  R932      2.3003891110420227e-01
    z[7,3,3]  R933      3.1932342052459717e-01
    z[7,3,3]  R934      3.5840702056884766e-01
    z[7,3,3]  R935      5.6651169061660767e-01
    z[7,3,3]  R936      2.8356346487998962e-01
    z[7,3,3]  R937      -5.6767380237579346e-01
    z[7,3,3]  R938      -3.6865150928497314e-01
    z[7,3,3]  R939      -3.7740305066108704e-01
    z[7,3,3]  R940      -5.0571990013122559e-01
    z[7,3,3]  R941      -0.410660982131958
    z[7,3,3]  R942      2.1263739466667175e-01
    z[7,3,3]  R943      -5.3038388490676880e-01
    z[7,3,3]  R944      -5.2300339937210083e-01
    z[7,3,3]  R945      -2.2139649093151093e-01
    z[7,3,3]  R946      -4.4104033708572388e-01
    z[7,3,3]  R947      -3.6225321888923645e-01
    z[7,3,3]  R948      1.0925932228565216e-01
    z[7,3,3]  R949      -7.1278387308120728e-01
    z[7,3,3]  R950      2.1688152849674225e-01
    z[7,3,3]  R951      -6.9918829202651978e-01
    z[7,3,3]  R952      2.2615356743335724e-01
    z[7,3,3]  R953      -9.6766859292984009e-02
    z[7,3,3]  R954      -1.0856787860393524e-01
    z[7,3,3]  R955      -7.7130466699600220e-02
    z[7,3,3]  R956      -2.0936983823776245e-01
    z[7,3,3]  R957      5.5666558444499969e-02
    z[7,3,3]  R958      -4.1393363475799561e-01
    z[7,3,3]  R959      -7.4532374739646912e-02
    z[7,3,3]  R960      -3.2952728867530823e-01
    z[7,3,3]  R961      5.7273630052804947e-02
    z[7,3,3]  R962      3.5371991991996765e-01
    z[7,3,3]  R963      6.2036764621734619e-01
    z[7,3,3]  R964      0.174591064453125
    z[7,3,3]  R965      -6.5473616123199463e-02
    z[7,3,3]  R966      9.8076008260250092e-02
    z[7,3,3]  R967      0.54584139585495
    z[7,3,3]  R968      -5.0053983926773071e-01
    z[7,3,3]  R969      -6.7424766719341278e-02
    z[7,3,3]  R970      -4.1990217566490173e-01
    z[7,3,3]  R971      -4.7919595241546631e-01
    z[7,3,3]  R972      -4.7395061701536179e-02
    z[7,3,3]  R973      -7.9899743199348450e-02
    z[7,3,3]  R974      3.8864096999168396e-01
    z[7,3,3]  R975      0.112656369805336
    z[7,3,3]  R976      -1.6416944563388824e-01
    z[7,3,3]  R977      -1.8139523267745972e-01
    z[7,3,3]  R978      -3.0042198300361633e-01
    z[7,3,3]  R979      2.0458501577377319e-01
    z[7,3,3]  R980      0.299461305141449
    z[7,3,3]  R981      -3.0456364154815674e-01
    z[7,3,3]  R982      6.3462370634078979e-01
    z[7,3,3]  R983      -3.1808264553546906e-02
    z[7,3,3]  R984      -6.1111348867416382e-01
    z[7,3,3]  R985      -4.4662916660308838e-01
    z[7,3,3]  R986      -7.2431737184524536e-01
    z[7,3,3]  R987      -9.9267408251762390e-02
    z[7,3,3]  R988      -2.1639212965965271e-01
    z[7,3,3]  R989      4.5839720964431763e-01
    z[7,3,3]  R990      -1.2969951145350933e-02
    z[7,3,3]  R991      1.9489879906177521e-01
    z[7,3,3]  R992      -0.739753782749176
    z[7,3,3]  R993      4.2342305183410645e-01
    z[7,3,3]  R994      -1.6215343773365021e-01
    z[7,3,3]  R995      -6.8730795383453369e-01
    z[7,3,3]  R996      -8.0857044458389282e-01
    z[7,3,3]  R997      -4.8054140806198120e-01
    z[7,3,3]  R998      6.1848795413970947e-01
    z[7,3,3]  R999      -2.5894984602928162e-01
    z[7,3,3]  R1000     2.4202822148799896e-01
    z[7,3,3]  R1001     2.5243896525353193e-03
    z[7,3,3]  R1002     5.7796555757522583e-01
    z[7,3,3]  R1003     3.4566736221313477e-01
    z[7,3,3]  R1004     -7.0362383127212524e-01
    z[7,3,3]  R1005     -3.6247396469116211e-01
    z[7,3,3]  R1006     -0.738812267780304
    z[7,3,3]  R1007     -4.3917959928512573e-01
    z[7,3,3]  R1008     -6.6205725073814392e-02
    z[7,3,3]  R1009     2.7190076652914286e-03
    z[7,3,3]  R1010     4.7790881991386414e-01
    z[7,3,3]  R1011     6.6536128520965576e-01
    z[7,3,3]  R1012     2.6913082599639893e-01
    z[7,3,3]  R1013     8.1416743993759155e-01
    z[7,3,3]  R1014     7.6190240681171417e-02
    z[7,3,3]  R1015     7.1276850998401642e-02
    z[7,3,3]  R1016     -8.8126683235168457e-01
    z[7,3,3]  R1017     -2.3248299956321716e-01
    z[7,3,3]  R1018     -1.1482724547386169e-01
    z[7,3,3]  R1019     4.6430990099906921e-01
    z[7,3,3]  R1020     5.5468821525573730e-01
    z[7,3,3]  R1021     1.5193149447441101e-02
    z[7,3,3]  R1022     -3.2171458005905151e-02
    z[7,3,3]  R1023     5.1962349563837051e-02
    z[7,3,3]  R1024     -5.0766462087631226e-01
    z[7,3,3]  R1025     -7.0269167423248291e-01
    z[7,3,3]  R1026     3.8918992877006531e-01
    z[7,3,3]  R1027     -3.2630622386932373e-01
    z[7,3,3]  R1028     5.4890251159667969e-01
    z[7,3,3]  R1029     3.0041038990020752e-02
    z[7,3,3]  R1030     -7.0372693240642548e-02
    z[7,3,3]  R1031     -6.6674917936325073e-01
    z[7,3,3]  R1032     8.2571476697921753e-01
    z[7,3,3]  R1033     1.8634662032127380e-01
    z[7,3,3]  R1034     -5.4187369346618652e-01
    z[7,3,3]  R1035     -1.8501089513301849e-01
    z[7,3,3]  R1036     1.1763103306293488e-01
    z[7,3,3]  R1037     1.2336388975381851e-01
    z[7,3,3]  R1038     1.4014837145805359e-01
    z[7,3,3]  R1039     1.9738397002220154e-01
    z[7,3,3]  R1040     -4.3479744344949722e-02
    z[7,3,3]  R1041     2.2622174024581909e-01
    z[7,3,3]  R1042     -2.4902520701289177e-02
    z[7,3,3]  R1043     2.5310555100440979e-01
    z[7,3,3]  R1044     3.1763198971748352e-01
    z[7,3,3]  R1045     1.9800575077533722e-01
    z[7,3,3]  R1046     -2.8173295781016350e-02
    z[7,3,3]  R1047     2.2794772684574127e-01
    z[7,3,3]  R1048     -0.0826336070895195
    z[7,3,3]  R1049     4.6799725294113159e-01
    z[7,3,3]  R1050     -2.6709496974945068e-01
    z[7,3,3]  R1051     0.503420889377594
    z[7,3,3]  R1052     -4.7182232141494751e-02
    z[7,3,3]  R1053     -3.2185006886720657e-02
    z[7,3,3]  R1054     1.1630264669656754e-01
    z[7,3,3]  R1055     3.4428283572196960e-02
    z[7,3,3]  R1056     -0.00514657236635685
    z[7,3,3]  R1057     8.9136496186256409e-02
    z[7,3,3]  R1058     -3.6063587665557861e-01
    z[7,3,3]  R1059     -0.081561379134655
    z[7,3,3]  R1060     8.1481322646141052e-02
    z[7,3,3]  R1061     1.2045668065547943e-01
    z[7,3,3]  R1062     3.1591024994850159e-01
    z[7,3,3]  R1063     -7.1248807013034821e-02
    z[7,3,3]  R1064     -1.9285000860691071e-02
    z[7,3,3]  R1065     -1.8393030762672424e-01
    z[7,3,3]  R1066     -1.1943616718053818e-01
    z[7,3,3]  R1067     -3.4615222364664078e-02
    z[7,3,3]  R1068     0.208840012550354
    z[7,3,3]  R1069     -2.3434206843376160e-01
    z[7,3,3]  R1070     -3.7884226441383362e-01
    z[7,3,3]  R1071     -4.3607643246650696e-01
    z[7,3,3]  R1072     1.5645003318786621e-01
    z[7,3,3]  R1073     4.4591864943504333e-01
    z[7,3,3]  R1074     -5.6606572866439819e-01
    z[7,3,3]  R1075     -6.4688396453857422e-01
    z[7,3,3]  R1076     -6.5649574995040894e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R921      -1
    z[7,3,4]  R922      1
    z[7,3,4]  R927      1.6483603417873383e-01
    z[7,3,4]  R928      -2.0548866689205170e-01
    z[7,3,4]  R929      -1.2014985829591751e-01
    z[7,3,4]  R930      2.9497590661048889e-01
    z[7,3,4]  R931      1.4236049354076385e-01
    z[7,3,4]  R932      2.5435414910316467e-01
    z[7,3,4]  R933      1.6347086429595947e-01
    z[7,3,4]  R934      -4.1072311997413635e-01
    z[7,3,4]  R935      -2.4284815788269043e-01
    z[7,3,4]  R936      -1.8633264303207397e-01
    z[7,3,4]  R937      3.5102775692939758e-01
    z[7,3,4]  R938      -4.9579218029975891e-01
    z[7,3,4]  R939      -0.420878142118454
    z[7,3,4]  R940      -1.1079634726047516e-01
    z[7,3,4]  R941      -4.8875716328620911e-01
    z[7,3,4]  R942      -3.1739141792058945e-02
    z[7,3,4]  R943      -1.8995173275470734e-01
    z[7,3,4]  R944      8.6141005158424377e-03
    z[7,3,4]  R945      -2.5475943088531494e-01
    z[7,3,4]  R946      -4.2808291316032410e-01
    z[7,3,4]  R947      -1.7352880537509918e-01
    z[7,3,4]  R948      2.0763443410396576e-01
    z[7,3,4]  R949      -1.5970483422279358e-01
    z[7,3,4]  R950      -0.164675772190094
    z[7,3,4]  R951      6.9020465016365051e-02
    z[7,3,4]  R952      3.3810202032327652e-02
    z[7,3,4]  R953      2.0591814070940018e-02
    z[7,3,4]  R954      1.2437465041875839e-01
    z[7,3,4]  R955      2.7689921855926514e-01
    z[7,3,4]  R956      1.0139914602041245e-01
    z[7,3,4]  R957      -7.4027101509273052e-03
    z[7,3,4]  R958      -9.2984713613986969e-02
    z[7,3,4]  R959      5.7830739021301270e-01
    z[7,3,4]  R960      5.7642382383346558e-01
    z[7,3,4]  R961      9.1092668473720551e-02
    z[7,3,4]  R962      -2.9985904693603516e-01
    z[7,3,4]  R963      -3.4815132617950439e-01
    z[7,3,4]  R964      -5.8498740196228027e-02
    z[7,3,4]  R965      2.5201949477195740e-01
    z[7,3,4]  R966      1.6721126437187195e-01
    z[7,3,4]  R967      1.5844435989856720e-01
    z[7,3,4]  R968      3.3917296677827835e-03
    z[7,3,4]  R969      -1.0530129820108414e-01
    z[7,3,4]  R970      -3.4999931231141090e-03
    z[7,3,4]  R971      1.9685381650924683e-01
    z[7,3,4]  R972      4.1764539480209351e-01
    z[7,3,4]  R973      1.4651700854301453e-01
    z[7,3,4]  R974      4.3963202834129333e-01
    z[7,3,4]  R975      3.0410623550415039e-01
    z[7,3,4]  R976      1.7601549625396729e-01
    z[7,3,4]  R977      -1.3534653186798096e-01
    z[7,3,4]  R978      4.7975964844226837e-02
    z[7,3,4]  R979      1.0215112566947937e-01
    z[7,3,4]  R980      -0.0791703388094902
    z[7,3,4]  R981      -1.5117718279361725e-01
    z[7,3,4]  R982      -0.000655064475722611
    z[7,3,4]  R983      -1.3639484345912933e-01
    z[7,3,4]  R984      -1.7070990800857544e-01
    z[7,3,4]  R985      -4.9967950582504272e-01
    z[7,3,4]  R986      -1.6937865316867828e-01
    z[7,3,4]  R987      5.0345176458358765e-01
    z[7,3,4]  R988      -1.9321238994598389e-01
    z[7,3,4]  R989      -0.510749340057373
    z[7,3,4]  R990      -1.7659065127372742e-01
    z[7,3,4]  R991      -3.2749277353286743e-01
    z[7,3,4]  R992      -1.6959272325038910e-01
    z[7,3,4]  R993      -2.5101867318153381e-01
    z[7,3,4]  R994      -3.8920632004737854e-01
    z[7,3,4]  R995      -3.8718926906585693e-01
    z[7,3,4]  R996      -1.7540577054023743e-01
    z[7,3,4]  R997      2.6764786243438721e-01
    z[7,3,4]  R998      2.7633774280548096e-01
    z[7,3,4]  R999      2.6715666055679321e-01
    z[7,3,4]  R1000     1.8802155554294586e-01
    z[7,3,4]  R1001     -1.0254956036806107e-01
    z[7,3,4]  R1002     2.7900439500808716e-01
    z[7,3,4]  R1003     1.4084173738956451e-01
    z[7,3,4]  R1004     -3.8704228401184082e-01
    z[7,3,4]  R1005     7.1601629257202148e-02
    z[7,3,4]  R1006     1.6826494038105011e-01
    z[7,3,4]  R1007     6.9450519979000092e-02
    z[7,3,4]  R1008     5.5063869804143906e-02
    z[7,3,4]  R1009     1.9221821799874306e-02
    z[7,3,4]  R1010     0.0171035286039114
    z[7,3,4]  R1011     2.2876986861228943e-01
    z[7,3,4]  R1012     -2.5459113717079163e-01
    z[7,3,4]  R1013     7.4961505830287933e-02
    z[7,3,4]  R1014     -1.6473822295665741e-01
    z[7,3,4]  R1015     -3.0694943666458130e-01
    z[7,3,4]  R1016     -2.2959465160965919e-02
    z[7,3,4]  R1017     9.0642586350440979e-02
    z[7,3,4]  R1018     4.7416013479232788e-01
    z[7,3,4]  R1019     1.4224231243133545e-01
    z[7,3,4]  R1020     -3.5413238406181335e-01
    z[7,3,4]  R1021     8.0844148993492126e-02
    z[7,3,4]  R1022     2.1051813662052155e-01
    z[7,3,4]  R1023     -1.5900759398937225e-01
    z[7,3,4]  R1024     -2.7241092175245285e-02
    z[7,3,4]  R1025     1.8105036020278931e-01
    z[7,3,4]  R1026     6.2217503786087036e-01
    z[7,3,4]  R1027     3.6257752776145935e-01
    z[7,3,4]  R1028     -1.5457384288311005e-01
    z[7,3,4]  R1029     1.6399468481540680e-01
    z[7,3,4]  R1030     7.4029639363288879e-02
    z[7,3,4]  R1031     3.4444069024175406e-03
    z[7,3,4]  R1032     2.1715784445405006e-02
    z[7,3,4]  R1033     -1.1888762563467026e-01
    z[7,3,4]  R1034     -1.4770109951496124e-01
    z[7,3,4]  R1035     -2.0655460655689240e-01
    z[7,3,4]  R1036     1.4602577686309814e-01
    z[7,3,4]  R1037     -1.7499543726444244e-01
    z[7,3,4]  R1038     -9.3153864145278931e-02
    z[7,3,4]  R1039     -4.2097586393356323e-01
    z[7,3,4]  R1040     -8.7057955563068390e-02
    z[7,3,4]  R1041     1.9317786395549774e-01
    z[7,3,4]  R1042     9.1338835656642914e-02
    z[7,3,4]  R1043     3.4952649474143982e-01
    z[7,3,4]  R1044     1.7258162796497345e-01
    z[7,3,4]  R1045     2.2579045966267586e-02
    z[7,3,4]  R1046     -4.4032309204339981e-02
    z[7,3,4]  R1047     8.7571300566196442e-02
    z[7,3,4]  R1048     1.6282857954502106e-01
    z[7,3,4]  R1049     -2.4272072315216064e-01
    z[7,3,4]  R1050     2.6515156030654907e-01
    z[7,3,4]  R1051     -2.6562556624412537e-01
    z[7,3,4]  R1052     -5.7785177230834961e-01
    z[7,3,4]  R1053     -1.6454145312309265e-01
    z[7,3,4]  R1054     -0.111277274787426
    z[7,3,4]  R1055     -3.0620154738426208e-01
    z[7,3,4]  R1056     -7.2088211774826050e-01
    z[7,3,4]  R1057     1.2066298164427280e-02
    z[7,3,4]  R1058     2.4230834096670151e-02
    z[7,3,4]  R1059     0.0743400976061821
    z[7,3,4]  R1060     1.9495931267738342e-01
    z[7,3,4]  R1061     -5.6943674571812153e-03
    z[7,3,4]  R1062     2.3302891850471497e-01
    z[7,3,4]  R1063     -1.9806885719299316e-01
    z[7,3,4]  R1064     1.6575929522514343e-01
    z[7,3,4]  R1065     -2.6363892480731010e-02
    z[7,3,4]  R1066     -3.8546428084373474e-01
    z[7,3,4]  R1067     1.8515472114086151e-01
    z[7,3,4]  R1068     -4.6308046579360962e-01
    z[7,3,4]  R1069     1.9928932189941406e-01
    z[7,3,4]  R1070     3.5109764337539673e-01
    z[7,3,4]  R1071     -7.7538110315799713e-02
    z[7,3,4]  R1072     5.2223944664001465e-01
    z[7,3,4]  R1073     -2.9867190122604370e-01
    z[7,3,4]  R1074     -2.8627860546112061e-01
    z[7,3,4]  R1075     -9.1373048722743988e-02
    z[7,3,4]  R1076     5.1102095842361450e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R923      -1
    z[7,3,5]  R924      1
    z[7,3,5]  R927      3.6157190799713135e-01
    z[7,3,5]  R928      8.6428232491016388e-02
    z[7,3,5]  R929      1.7475946247577667e-01
    z[7,3,5]  R930      2.1422280371189117e-01
    z[7,3,5]  R931      -2.6312029361724854e-01
    z[7,3,5]  R932      -1.1258765310049057e-01
    z[7,3,5]  R933      -6.9279879331588745e-02
    z[7,3,5]  R934      2.6745384931564331e-01
    z[7,3,5]  R935      -2.8706169128417969e-01
    z[7,3,5]  R936      -2.1840818226337433e-01
    z[7,3,5]  R937      -1.7786248028278351e-01
    z[7,3,5]  R938      -2.1726746112108231e-02
    z[7,3,5]  R939      -6.3736066222190857e-02
    z[7,3,5]  R940      3.1286545097827911e-02
    z[7,3,5]  R941      7.8133922070264816e-03
    z[7,3,5]  R942      1.1068589985370636e-01
    z[7,3,5]  R943      2.6434719562530518e-01
    z[7,3,5]  R944      0.0418284609913826
    z[7,3,5]  R945      1.6630619764328003e-01
    z[7,3,5]  R946      2.8218093514442444e-01
    z[7,3,5]  R947      -0.478199303150177
    z[7,3,5]  R948      -1.9420586526393890e-01
    z[7,3,5]  R949      -7.1430094540119171e-02
    z[7,3,5]  R950      -0.292460560798645
    z[7,3,5]  R951      2.2123925387859344e-01
    z[7,3,5]  R952      -4.1238903999328613e-01
    z[7,3,5]  R953      -3.6590325832366943e-01
    z[7,3,5]  R954      -3.0864715576171875e-01
    z[7,3,5]  R955      -3.1340357661247253e-01
    z[7,3,5]  R956      1.8844987452030182e-01
    z[7,3,5]  R957      -3.8047227263450623e-01
    z[7,3,5]  R958      -2.8123003244400024e-01
    z[7,3,5]  R959      -3.0721798539161682e-01
    z[7,3,5]  R960      -3.0520227551460266e-01
    z[7,3,5]  R961      -2.6596600189805031e-02
    z[7,3,5]  R962      -2.2794160246849060e-01
    z[7,3,5]  R963      -2.9888552427291870e-01
    z[7,3,5]  R964      2.7011623978614807e-01
    z[7,3,5]  R965      -1.4479759335517883e-01
    z[7,3,5]  R966      -3.0097526311874390e-01
    z[7,3,5]  R967      1.1131688207387924e-01
    z[7,3,5]  R968      -3.7510967254638672e-01
    z[7,3,5]  R969      -1.9735524058341980e-01
    z[7,3,5]  R970      -1.3828532397747040e-01
    z[7,3,5]  R971      -3.4852313995361328e-01
    z[7,3,5]  R972      -2.5787869095802307e-01
    z[7,3,5]  R973      -1.0327735543251038e-01
    z[7,3,5]  R974      1.2150023831054568e-03
    z[7,3,5]  R975      -2.3134063184261322e-01
    z[7,3,5]  R976      4.0065199136734009e-02
    z[7,3,5]  R977      -5.5110651254653931e-01
    z[7,3,5]  R978      4.4556212425231934e-01
    z[7,3,5]  R979      2.4070987105369568e-01
    z[7,3,5]  R980      -1.0796731710433960e-01
    z[7,3,5]  R981      2.1233783662319183e-01
    z[7,3,5]  R982      -1.3205768167972565e-01
    z[7,3,5]  R983      -2.4533860385417938e-01
    z[7,3,5]  R984      -3.0848110094666481e-02
    z[7,3,5]  R985      -1.4587184786796570e-01
    z[7,3,5]  R986      0.252546489238739
    z[7,3,5]  R987      -3.6108851432800293e-01
    z[7,3,5]  R988      1.9542382657527924e-01
    z[7,3,5]  R989      -2.3221735656261444e-01
    z[7,3,5]  R990      -3.7104284763336182e-01
    z[7,3,5]  R991      -4.8415485769510269e-02
    z[7,3,5]  R992      2.5979939103126526e-01
    z[7,3,5]  R993      -1.2629453837871552e-01
    z[7,3,5]  R994      -4.3472938239574432e-02
    z[7,3,5]  R995      -3.7419281434267759e-03
    z[7,3,5]  R996      9.2434667050838470e-02
    z[7,3,5]  R997      -4.2871972918510437e-01
    z[7,3,5]  R998      -3.3051091432571411e-01
    z[7,3,5]  R999      3.0744457244873047e-01
    z[7,3,5]  R1000     -1.1734230071306229e-01
    z[7,3,5]  R1001     -6.0735039412975311e-02
    z[7,3,5]  R1002     -4.1593369841575623e-01
    z[7,3,5]  R1003     1.5159327536821365e-02
    z[7,3,5]  R1004     2.9559774324297905e-02
    z[7,3,5]  R1005     -4.1807761788368225e-01
    z[7,3,5]  R1006     5.3183263540267944e-01
    z[7,3,5]  R1007     5.0590906292200089e-02
    z[7,3,5]  R1008     4.6976704150438309e-02
    z[7,3,5]  R1009     -4.1004788875579834e-01
    z[7,3,5]  R1010     -8.0488964915275574e-02
    z[7,3,5]  R1011     -1.3850995898246765e-01
    z[7,3,5]  R1012     1.7445281147956848e-01
    z[7,3,5]  R1013     -3.7980481982231140e-01
    z[7,3,5]  R1014     -0.549176037311554
    z[7,3,5]  R1015     -3.1081077456474304e-01
    z[7,3,5]  R1016     2.7003228664398193e-01
    z[7,3,5]  R1017     -1.6107386350631714e-01
    z[7,3,5]  R1018     -5.5078428983688354e-01
    z[7,3,5]  R1019     -3.1608107686042786e-01
    z[7,3,5]  R1020     -1.7238157987594604e-01
    z[7,3,5]  R1021     -1.0442781448364258e-01
    z[7,3,5]  R1022     2.9218757152557373e-01
    z[7,3,5]  R1023     -4.2967864871025085e-01
    z[7,3,5]  R1024     -1.0896987468004227e-01
    z[7,3,5]  R1025     1.6916318237781525e-01
    z[7,3,5]  R1026     0.0191938616335392
    z[7,3,5]  R1027     8.2310363650321960e-02
    z[7,3,5]  R1028     -2.0744070410728455e-01
    z[7,3,5]  R1029     -1.1092843860387802e-01
    z[7,3,5]  R1030     -1.8518300354480743e-01
    z[7,3,5]  R1031     2.7184817939996719e-02
    z[7,3,5]  R1032     -3.5375106334686279e-01
    z[7,3,5]  R1033     -3.9943951368331909e-01
    z[7,3,5]  R1034     4.8046806454658508e-01
    z[7,3,5]  R1035     -2.3944278061389923e-01
    z[7,3,5]  R1036     -7.0862270891666412e-02
    z[7,3,5]  R1037     3.9365947246551514e-01
    z[7,3,5]  R1038     1.8414977192878723e-01
    z[7,3,5]  R1039     1.3328801095485687e-01
    z[7,3,5]  R1040     2.4706198275089264e-01
    z[7,3,5]  R1041     4.0213245153427124e-01
    z[7,3,5]  R1042     2.3150397837162018e-01
    z[7,3,5]  R1043     5.8123461902141571e-02
    z[7,3,5]  R1044     -1.1589889228343964e-01
    z[7,3,5]  R1045     -2.0197346806526184e-01
    z[7,3,5]  R1046     -3.0134108662605286e-01
    z[7,3,5]  R1047     -4.1382014751434326e-01
    z[7,3,5]  R1048     -1.6606800258159637e-01
    z[7,3,5]  R1049     0.132082000374794
    z[7,3,5]  R1050     -1.0103802382946014e-01
    z[7,3,5]  R1051     -5.1464891433715820e-01
    z[7,3,5]  R1052     -3.7848666310310364e-01
    z[7,3,5]  R1053     1.1804620176553726e-01
    z[7,3,5]  R1054     2.5822449475526810e-02
    z[7,3,5]  R1055     2.5962832570075989e-01
    z[7,3,5]  R1056     -3.1875947117805481e-01
    z[7,3,5]  R1057     -5.5032365024089813e-02
    z[7,3,5]  R1058     -6.8893593549728394e-01
    z[7,3,5]  R1059     1.0112300515174866e-01
    z[7,3,5]  R1060     8.0109424889087677e-02
    z[7,3,5]  R1061     2.6628252863883972e-01
    z[7,3,5]  R1062     2.9066300392150879e-01
    z[7,3,5]  R1063     2.5254175066947937e-01
    z[7,3,5]  R1064     3.9021271467208862e-01
    z[7,3,5]  R1065     1.5079198777675629e-01
    z[7,3,5]  R1066     1.1973618716001511e-01
    z[7,3,5]  R1067     -3.1197625398635864e-01
    z[7,3,5]  R1068     -8.2270748913288116e-02
    z[7,3,5]  R1069     -3.3672001957893372e-01
    z[7,3,5]  R1070     -2.1148182451725006e-01
    z[7,3,5]  R1071     -3.8456863164901733e-01
    z[7,3,5]  R1072     0.0923554003238678
    z[7,3,5]  R1073     5.3185307979583740e-01
    z[7,3,5]  R1074     -3.5393461585044861e-01
    z[7,3,5]  R1075     -1.6921687126159668e-01
    z[7,3,5]  R1076     -2.2447425127029419e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R925      -1
    z[7,3,6]  R926      1
    z[7,3,6]  R927      -2.0635235309600830e-01
    z[7,3,6]  R928      2.2748260200023651e-01
    z[7,3,6]  R929      1.0516013205051422e-01
    z[7,3,6]  R930      -3.9368532598018646e-02
    z[7,3,6]  R931      -3.6459761857986450e-01
    z[7,3,6]  R932      -2.8335893154144287e-01
    z[7,3,6]  R933      -5.0444173812866211e-01
    z[7,3,6]  R934      -1.5931384265422821e-01
    z[7,3,6]  R935      -5.7740285992622375e-03
    z[7,3,6]  R936      -2.2962391376495361e-01
    z[7,3,6]  R937      -1.3790573179721832e-01
    z[7,3,6]  R938      -1.6364523768424988e-01
    z[7,3,6]  R939      -8.3632849156856537e-02
    z[7,3,6]  R940      6.0002632439136505e-02
    z[7,3,6]  R941      1.8504603207111359e-01
    z[7,3,6]  R942      -2.1147492527961731e-01
    z[7,3,6]  R943      1.3096566312015057e-02
    z[7,3,6]  R944      -2.7766495943069458e-01
    z[7,3,6]  R945      -8.0890739336609840e-03
    z[7,3,6]  R946      2.4081563949584961e-01
    z[7,3,6]  R947      1.4388850331306458e-01
    z[7,3,6]  R948      5.9924638271331787e-01
    z[7,3,6]  R949      4.3836173415184021e-01
    z[7,3,6]  R950      4.5063480734825134e-01
    z[7,3,6]  R951      1.4219434559345245e-01
    z[7,3,6]  R952      4.7252067923545837e-01
    z[7,3,6]  R953      -4.1448645293712616e-02
    z[7,3,6]  R954      1.7293691635131836e-01
    z[7,3,6]  R955      2.1829646080732346e-02
    z[7,3,6]  R956      3.9265986531972885e-02
    z[7,3,6]  R957      7.6660722494125366e-02
    z[7,3,6]  R958      -5.6128031015396118e-01
    z[7,3,6]  R959      4.9747237563133240e-01
    z[7,3,6]  R960      -4.6390643715858459e-01
    z[7,3,6]  R961      4.7608932852745056e-01
    z[7,3,6]  R962      -6.2533393502235413e-02
    z[7,3,6]  R963      2.1993571519851685e-01
    z[7,3,6]  R964      3.4372383356094360e-01
    z[7,3,6]  R965      3.4728819131851196e-01
    z[7,3,6]  R966      0.255688339471817
    z[7,3,6]  R967      4.2310228943824768e-01
    z[7,3,6]  R968      6.8588759750127792e-03
    z[7,3,6]  R969      2.3477682471275330e-01
    z[7,3,6]  R970      -4.1881051659584045e-01
    z[7,3,6]  R971      3.9004996418952942e-01
    z[7,3,6]  R972      -0.335882306098938
    z[7,3,6]  R973      -1.6593678295612335e-01
    z[7,3,6]  R974      2.6671022176742554e-01
    z[7,3,6]  R975      6.2468592077493668e-03
    z[7,3,6]  R976      -8.7136939167976379e-02
    z[7,3,6]  R977      -2.9209271073341370e-01
    z[7,3,6]  R978      0.44937664270401
    z[7,3,6]  R979      -9.9995970726013184e-02
    z[7,3,6]  R980      1.3004487752914429e-01
    z[7,3,6]  R981      -4.5862618088722229e-01
    z[7,3,6]  R982      -5.1394551992416382e-01
    z[7,3,6]  R983      -2.0621180534362793e-01
    z[7,3,6]  R984      2.0252232253551483e-01
    z[7,3,6]  R985      -1.0687220841646194e-01
    z[7,3,6]  R986      -6.3475079834461212e-02
    z[7,3,6]  R987      -1.4392933249473572e-01
    z[7,3,6]  R988      3.9627268910408020e-01
    z[7,3,6]  R989      -1.1192449927330017e-01
    z[7,3,6]  R990      -1.2898662686347961e-01
    z[7,3,6]  R991      4.8706603050231934e-01
    z[7,3,6]  R992      1.6122156381607056e-01
    z[7,3,6]  R993      -0.574490487575531
    z[7,3,6]  R994      2.2059172391891479e-02
    z[7,3,6]  R995      2.1027492359280586e-02
    z[7,3,6]  R996      -9.4802536070346832e-02
    z[7,3,6]  R997      -2.5701060891151428e-02
    z[7,3,6]  R998      -1.7384913563728333e-01
    z[7,3,6]  R999      0.0712905079126358
    z[7,3,6]  R1000     -2.4445161223411560e-01
    z[7,3,6]  R1001     -4.6912181377410889e-01
    z[7,3,6]  R1002     -2.4328069388866425e-01
    z[7,3,6]  R1003     3.8897043466567993e-01
    z[7,3,6]  R1004     -3.2586455345153809e-01
    z[7,3,6]  R1005     1.1651214212179184e-02
    z[7,3,6]  R1006     1.5964837744832039e-02
    z[7,3,6]  R1007     7.3880054056644440e-02
    z[7,3,6]  R1008     -3.6409109830856323e-02
    z[7,3,6]  R1009     1.9887593388557434e-01
    z[7,3,6]  R1010     2.9521992802619934e-01
    z[7,3,6]  R1011     5.9096522629261017e-02
    z[7,3,6]  R1012     4.5569464564323425e-01
    z[7,3,6]  R1013     -1.0193645209074020e-01
    z[7,3,6]  R1014     -2.6325622200965881e-01
    z[7,3,6]  R1015     5.2250474691390991e-02
    z[7,3,6]  R1016     6.4070552587509155e-02
    z[7,3,6]  R1017     -2.2096963226795197e-01
    z[7,3,6]  R1018     -1.0697133839130402e-01
    z[7,3,6]  R1019     6.6424749791622162e-02
    z[7,3,6]  R1020     -2.0087711513042450e-02
    z[7,3,6]  R1021     2.4833540618419647e-01
    z[7,3,6]  R1022     8.2687549293041229e-02
    z[7,3,6]  R1023     -3.9547204971313477e-01
    z[7,3,6]  R1024     -2.3731590807437897e-01
    z[7,3,6]  R1025     -3.3022749423980713e-01
    z[7,3,6]  R1026     -0.458345502614975
    z[7,3,6]  R1027     4.8635181784629822e-01
    z[7,3,6]  R1028     -2.1411462128162384e-01
    z[7,3,6]  R1029     1.3943125307559967e-01
    z[7,3,6]  R1030     3.0752828717231750e-01
    z[7,3,6]  R1031     1.5022693574428558e-01
    z[7,3,6]  R1032     -6.2335506081581116e-02
    z[7,3,6]  R1033     2.1135514974594116e-01
    z[7,3,6]  R1034     -0.360663503408432
    z[7,3,6]  R1035     6.0167215764522552e-02
    z[7,3,6]  R1036     2.0817078649997711e-02
    z[7,3,6]  R1037     1.8048782646656036e-01
    z[7,3,6]  R1038     -1.2364926747977734e-02
    z[7,3,6]  R1039     -1.5485283732414246e-01
    z[7,3,6]  R1040     -3.8015130162239075e-01
    z[7,3,6]  R1041     -2.1169923245906830e-01
    z[7,3,6]  R1042     -3.5489144921302795e-01
    z[7,3,6]  R1043     -2.0372769236564636e-01
    z[7,3,6]  R1044     3.0969858169555664e-01
    z[7,3,6]  R1045     -2.4845942854881287e-01
    z[7,3,6]  R1046     9.4537958502769470e-02
    z[7,3,6]  R1047     -1.2200947850942612e-01
    z[7,3,6]  R1048     4.2418986558914185e-01
    z[7,3,6]  R1049     -0.426483690738678
    z[7,3,6]  R1050     -1.8254956230521202e-02
    z[7,3,6]  R1051     2.0143781602382660e-01
    z[7,3,6]  R1052     4.6744823455810547e-01
    z[7,3,6]  R1053     -1.4372245967388153e-01
    z[7,3,6]  R1054     3.5217520594596863e-01
    z[7,3,6]  R1055     -4.5647022128105164e-01
    z[7,3,6]  R1056     1.8208703398704529e-01
    z[7,3,6]  R1057     -0.01593635417521
    z[7,3,6]  R1058     -3.2406035065650940e-01
    z[7,3,6]  R1059     1.6168814897537231e-01
    z[7,3,6]  R1060     -5.0659310072660446e-02
    z[7,3,6]  R1061     2.4650168418884277e-01
    z[7,3,6]  R1062     2.1313808392733335e-03
    z[7,3,6]  R1063     -2.6850234717130661e-02
    z[7,3,6]  R1064     1.1009088903665543e-01
    z[7,3,6]  R1065     3.6808228492736816e-01
    z[7,3,6]  R1066     1.2661641836166382e-01
    z[7,3,6]  R1067     -5.5408710241317749e-01
    z[7,3,6]  R1068     -5.0046551227569580e-01
    z[7,3,6]  R1069     -2.6688572764396667e-01
    z[7,3,6]  R1070     -1.3869464397430420e-02
    z[7,3,6]  R1071     1.4463216066360474e-01
    z[7,3,6]  R1072     -5.4464846849441528e-01
    z[7,3,6]  R1073     2.7732202783226967e-02
    z[7,3,6]  R1074     1.2828026711940765e-01
    z[7,3,6]  R1075     -3.6480379104614258e-01
    z[7,3,6]  R1076     2.2492859512567520e-02
    z[3,8,0]  R29       -1
    z[3,8,0]  R74       1
    z[3,8,0]  R1077     -1
    z[3,8,0]  R1078     1
    z[3,8,0]  R1091     7.1162068843841553e-01
    z[3,8,0]  R1092     9.5327025651931763e-01
    z[3,8,0]  R1093     7.0742470026016235e-01
    z[3,8,0]  R1094     0.798708438873291
    z[3,8,0]  R1095     5.8215296268463135e-01
    z[3,8,0]  R1096     8.0113774538040161e-01
    z[3,8,0]  R1097     8.3893394470214844e-01
    z[3,8,0]  R1098     7.2176802158355713e-01
    z[3,8,0]  R1099     6.9075030088424683e-01
    z[3,8,0]  R1100     6.9604158401489258e-01
    z[3,8,0]  R1101     -4.7281497716903687e-01
    z[3,8,0]  R1102     -6.8683397769927979e-01
    z[3,8,0]  R1103     -6.7731253802776337e-02
    z[3,8,0]  R1104     -3.9962872862815857e-01
    z[3,8,0]  R1105     -1.8932853639125824e-01
    z[3,8,0]  R1106     -4.4252589344978333e-01
    z[3,8,0]  R1107     -4.3393689393997192e-01
    z[3,8,0]  R1108     -2.8371793031692505e-01
    z[3,8,0]  R1109     -3.8343551754951477e-01
    z[3,8,0]  R1110     -3.8241106271743774e-01
    z[3,8,0]  R1111     1.2241673469543457e-01
    z[3,8,0]  R1112     -1.2061749584972858e-02
    z[3,8,0]  R1113     -1.4337897300720215e-01
    z[3,8,0]  R1114     -2.2681014239788055e-01
    z[3,8,0]  R1115     -1.9298419356346130e-01
    z[3,8,0]  R1116     -4.9005974084138870e-02
    z[3,8,0]  R1117     -1.9798719882965088e-01
    z[3,8,0]  R1118     5.4058995097875595e-02
    z[3,8,0]  R1119     1.2684838473796844e-01
    z[3,8,0]  R1120     -1.7259445041418076e-02
    z[3,8,0]  R1121     1.5683120489120483e-01
    z[3,8,0]  R1122     -5.1860684156417847e-01
    z[3,8,0]  R1123     2.6655766367912292e-01
    z[3,8,0]  R1124     -5.6426441669464111e-01
    z[3,8,0]  R1125     2.5352329015731812e-02
    z[3,8,0]  R1126     -6.1914050579071045e-01
    z[3,8,0]  R1127     -3.5635665059089661e-01
    z[3,8,0]  R1128     3.6339778453111649e-02
    z[3,8,0]  R1129     7.9450950026512146e-02
    z[3,8,0]  R1130     2.2689421474933624e-01
    z[3,8,0]  R1131     7.0530152320861816e-01
    z[3,8,0]  R1132     8.8695132732391357e-01
    z[3,8,0]  R1133     7.5331693887710571e-01
    z[3,8,0]  R1134     9.0934127569198608e-01
    z[3,8,0]  R1135     8.2864642143249512e-01
    z[3,8,0]  R1136     9.4234520196914673e-01
    z[3,8,0]  R1137     9.3040871620178223e-01
    z[3,8,0]  R1138     0.736838161945343
    z[3,8,0]  R1139     8.6052078008651733e-01
    z[3,8,0]  R1140     0.713066577911377
    z[3,8,0]  R1141     1.3651348650455475e-01
    z[3,8,0]  R1142     -3.2548218965530396e-02
    z[3,8,0]  R1143     -4.8324260115623474e-01
    z[3,8,0]  R1144     4.2534127831459045e-02
    z[3,8,0]  R1145     -2.1742577850818634e-01
    z[3,8,0]  R1146     -5.1593035459518433e-01
    z[3,8,0]  R1147     -3.0395722389221191e-01
    z[3,8,0]  R1148     -7.2562158107757568e-02
    z[3,8,0]  R1149     -5.1913022994995117e-01
    z[3,8,0]  R1150     -1.5697129070758820e-01
    z[3,8,0]  R1151     -3.2283249497413635e-01
    z[3,8,0]  R1152     -0.721881091594696
    z[3,8,0]  R1153     -2.3561200499534607e-01
    z[3,8,0]  R1154     -2.9592856764793396e-01
    z[3,8,0]  R1155     -2.5959175825119019e-01
    z[3,8,0]  R1156     -2.2420540452003479e-01
    z[3,8,0]  R1157     -4.0958243608474731e-01
    z[3,8,0]  R1158     -0.331001877784729
    z[3,8,0]  R1159     -2.5792077183723450e-01
    z[3,8,0]  R1160     -1.9591730833053589e-01
    z[3,8,0]  R1161     -2.6988866925239563e-01
    z[3,8,0]  R1162     -6.8003219366073608e-01
    z[3,8,0]  R1163     -6.5597808361053467e-01
    z[3,8,0]  R1164     -8.8376182317733765e-01
    z[3,8,0]  R1165     -0.755744218826294
    z[3,8,0]  R1166     -8.1956106424331665e-01
    z[3,8,0]  R1167     -6.7751920223236084e-01
    z[3,8,0]  R1168     -6.9661718606948853e-01
    z[3,8,0]  R1169     -5.9385901689529419e-01
    z[3,8,0]  R1170     -5.2864837646484375e-01
    z[3,8,0]  R1171     7.0176303386688232e-02
    z[3,8,0]  R1172     -0.313693106174469
    z[3,8,0]  R1173     -4.1877318173646927e-02
    z[3,8,0]  R1174     -8.0878752470016479e-01
    z[3,8,0]  R1175     -1.6961207985877991e-01
    z[3,8,0]  R1176     -8.6870723962783813e-01
    z[3,8,0]  R1177     -6.7262911796569824e-01
    z[3,8,0]  R1178     -8.4285312891006470e-01
    z[3,8,0]  R1179     -2.3766933381557465e-01
    z[3,8,0]  R1180     -9.1773825883865356e-01
    z[3,8,1]  R30       -1
    z[3,8,1]  R75       1
    z[3,8,1]  R1079     -1
    z[3,8,1]  R1080     1
    z[3,8,1]  R1091     -9.5694243907928467e-02
    z[3,8,1]  R1092     -3.7281468510627747e-02
    z[3,8,1]  R1093     2.7269739075563848e-04
    z[3,8,1]  R1094     1.2312665581703186e-01
    z[3,8,1]  R1095     2.2732684016227722e-01
    z[3,8,1]  R1096     -2.7584299445152283e-01
    z[3,8,1]  R1097     8.5411950945854187e-02
    z[3,8,1]  R1098     9.4852922484278679e-03
    z[3,8,1]  R1099     -3.8345813751220703e-01
    z[3,8,1]  R1100     -1.6182261705398560e-01
    z[3,8,1]  R1101     3.8585740327835083e-01
    z[3,8,1]  R1102     2.5853881239891052e-01
    z[3,8,1]  R1103     5.1659452915191650e-01
    z[3,8,1]  R1104     6.1803042888641357e-01
    z[3,8,1]  R1105     4.8582258820533752e-01
    z[3,8,1]  R1106     2.7209252119064331e-01
    z[3,8,1]  R1107     8.4815979003906250e-01
    z[3,8,1]  R1108     0.591509997844696
    z[3,8,1]  R1109     6.3983148336410522e-01
    z[3,8,1]  R1110     4.4348701834678650e-01
    z[3,8,1]  R1111     -0.985664963722229
    z[3,8,1]  R1112     4.2809438705444336e-01
    z[3,8,1]  R1113     -9.2774575948715210e-01
    z[3,8,1]  R1114     -9.0466153621673584e-01
    z[3,8,1]  R1115     -8.9581912755966187e-01
    z[3,8,1]  R1116     -8.7088793516159058e-01
    z[3,8,1]  R1117     -9.1231465339660645e-01
    z[3,8,1]  R1118     -0.892479658126831
    z[3,8,1]  R1119     -8.8815581798553467e-01
    z[3,8,1]  R1120     -8.9752441644668579e-01
    z[3,8,1]  R1121     0.728148341178894
    z[3,8,1]  R1122     3.8828489184379578e-01
    z[3,8,1]  R1123     7.8841805458068848e-01
    z[3,8,1]  R1124     4.5100745558738708e-01
    z[3,8,1]  R1125     0.782682478427887
    z[3,8,1]  R1126     7.1726846508681774e-03
    z[3,8,1]  R1127     -2.3392945528030396e-01
    z[3,8,1]  R1128     -6.7416888475418091e-01
    z[3,8,1]  R1129     -6.3650351762771606e-01
    z[3,8,1]  R1130     -4.3019664287567139e-01
    z[3,8,1]  R1131     1.9630730152130127e-02
    z[3,8,1]  R1132     -7.9196922481060028e-02
    z[3,8,1]  R1133     -1.9613333046436310e-02
    z[3,8,1]  R1134     1.1365023255348206e-01
    z[3,8,1]  R1135     -3.1931233406066895e-01
    z[3,8,1]  R1136     -1.1122805625200272e-01
    z[3,8,1]  R1137     1.1261923238635063e-02
    z[3,8,1]  R1138     -2.4862538278102875e-01
    z[3,8,1]  R1139     -5.1845584064722061e-02
    z[3,8,1]  R1140     -0.0972457155585289
    z[3,8,1]  R1141     8.0286830663681030e-01
    z[3,8,1]  R1142     5.8779406547546387e-01
    z[3,8,1]  R1143     5.0273990631103516e-01
    z[3,8,1]  R1144     4.3708527088165283e-01
    z[3,8,1]  R1145     4.7819891571998596e-01
    z[3,8,1]  R1146     4.5853444933891296e-01
    z[3,8,1]  R1147     4.3781113624572754e-01
    z[3,8,1]  R1148     5.7233953475952148e-01
    z[3,8,1]  R1149     5.0355130434036255e-01
    z[3,8,1]  R1150     3.4641581773757935e-01
    z[3,8,1]  R1151     -9.3039542436599731e-01
    z[3,8,1]  R1152     2.0746754109859467e-01
    z[3,8,1]  R1153     -8.8955307006835938e-01
    z[3,8,1]  R1154     -0.88219153881073
    z[3,8,1]  R1155     -8.5865569114685059e-01
    z[3,8,1]  R1156     -9.2376661300659180e-01
    z[3,8,1]  R1157     -8.7629443407058716e-01
    z[3,8,1]  R1158     -8.7441927194595337e-01
    z[3,8,1]  R1159     -8.8528978824615479e-01
    z[3,8,1]  R1160     -8.8353222608566284e-01
    z[3,8,1]  R1161     -6.1534738540649414e-01
    z[3,8,1]  R1162     1.6282060742378235e-01
    z[3,8,1]  R1163     -4.4630587100982666e-01
    z[3,8,1]  R1164     -1.6083197295665741e-01
    z[3,8,1]  R1165     -6.9364093244075775e-02
    z[3,8,1]  R1166     -2.9856148362159729e-01
    z[3,8,1]  R1167     -1.5196952223777771e-01
    z[3,8,1]  R1168     -1.4520509541034698e-01
    z[3,8,1]  R1169     -1.8252392113208771e-01
    z[3,8,1]  R1170     3.3651031553745270e-02
    z[3,8,1]  R1171     -3.3370348811149597e-01
    z[3,8,1]  R1172     -6.3353508710861206e-01
    z[3,8,1]  R1173     -9.1670429706573486e-01
    z[3,8,1]  R1174     2.0634920895099640e-01
    z[3,8,1]  R1175     -0.873768150806427
    z[3,8,1]  R1176     2.2565890848636627e-01
    z[3,8,1]  R1177     3.6477770656347275e-02
    z[3,8,1]  R1178     -1.0097629576921463e-01
    z[3,8,1]  R1179     -8.6336147785186768e-01
    z[3,8,1]  R1180     1.5227134525775909e-01
    z[3,8,2]  R31       -1
    z[3,8,2]  R76       1
    z[3,8,2]  R1081     -1
    z[3,8,2]  R1082     1
    z[3,8,2]  R1091     5.0105190277099609e-01
    z[3,8,2]  R1092     1.6583970189094543e-01
    z[3,8,2]  R1093     4.9155265092849731e-01
    z[3,8,2]  R1094     3.6315330862998962e-01
    z[3,8,2]  R1095     5.6071329116821289e-01
    z[3,8,2]  R1096     3.0591517686843872e-01
    z[3,8,2]  R1097     2.4037525057792664e-01
    z[3,8,2]  R1098     0.488815575838089
    z[3,8,2]  R1099     4.8330357670783997e-01
    z[3,8,2]  R1100     6.2198311090469360e-01
    z[3,8,2]  R1101     -6.1789786815643311e-01
    z[3,8,2]  R1102     -4.6963772177696228e-01
    z[3,8,2]  R1103     -5.0127208232879639e-01
    z[3,8,2]  R1104     -5.5330657958984375e-01
    z[3,8,2]  R1105     -3.1416711211204529e-01
    z[3,8,2]  R1106     -1.7954818904399872e-01
    z[3,8,2]  R1107     1.7211334407329559e-01
    z[3,8,2]  R1108     -6.4731532335281372e-01
    z[3,8,2]  R1109     -2.6995593309402466e-01
    z[3,8,2]  R1110     -5.1188085228204727e-02
    z[3,8,2]  R1111     0.0458839125931263
    z[3,8,2]  R1112     0.326031357049942
    z[3,8,2]  R1113     2.6491987705230713e-01
    z[3,8,2]  R1114     2.7660864591598511e-01
    z[3,8,2]  R1115     1.1854731291532516e-01
    z[3,8,2]  R1116     -2.3694671690464020e-02
    z[3,8,2]  R1117     1.4027518033981323e-01
    z[3,8,2]  R1118     -9.1233126819133759e-02
    z[3,8,2]  R1119     4.8379283398389816e-02
    z[3,8,2]  R1120     -3.0592581257224083e-02
    z[3,8,2]  R1121     -0.0733601376414299
    z[3,8,2]  R1122     2.5493115186691284e-01
    z[3,8,2]  R1123     -1.6764026880264282e-01
    z[3,8,2]  R1124     4.0803188085556030e-01
    z[3,8,2]  R1125     -1.4757739007472992e-01
    z[3,8,2]  R1126     1.1929593980312347e-01
    z[3,8,2]  R1127     -4.9659019708633423e-01
    z[3,8,2]  R1128     8.0252867192029953e-03
    z[3,8,2]  R1129     5.1690624095499516e-03
    z[3,8,2]  R1130     -1.4292004704475403e-01
    z[3,8,2]  R1131     0.508542537689209
    z[3,8,2]  R1132     3.8803330063819885e-01
    z[3,8,2]  R1133     4.5523053407669067e-01
    z[3,8,2]  R1134     1.8744862079620361e-01
    z[3,8,2]  R1135     3.4964513778686523e-01
    z[3,8,2]  R1136     1.0699527338147163e-02
    z[3,8,2]  R1137     2.3295685648918152e-01
    z[3,8,2]  R1138     5.0984853506088257e-01
    z[3,8,2]  R1139     6.4617067575454712e-02
    z[3,8,2]  R1140     4.4522005319595337e-01
    z[3,8,2]  R1141     -2.8069171309471130e-01
    z[3,8,2]  R1142     -2.6032933592796326e-01
    z[3,8,2]  R1143     -4.4359427690505981e-01
    z[3,8,2]  R1144     -6.2107211351394653e-01
    z[3,8,2]  R1145     -3.7472090125083923e-01
    z[3,8,2]  R1146     -0.568618893623352
    z[3,8,2]  R1147     -1.7549788951873779e-01
    z[3,8,2]  R1148     -3.2367938756942749e-01
    z[3,8,2]  R1149     -5.3947108983993530e-01
    z[3,8,2]  R1150     -7.0862895250320435e-01
    z[3,8,2]  R1151     -0.0657036080956459
    z[3,8,2]  R1152     0.23386250436306
    z[3,8,2]  R1153     1.0245457291603088e-01
    z[3,8,2]  R1154     -2.5030821561813354e-01
    z[3,8,2]  R1155     -3.6769038438796997e-01
    z[3,8,2]  R1156     -1.3862235844135284e-01
    z[3,8,2]  R1157     -7.5600305572152138e-03
    z[3,8,2]  R1158     -1.4240401983261108e-01
    z[3,8,2]  R1159     -3.8570471107959747e-02
    z[3,8,2]  R1160     -3.9163712412118912e-02
    z[3,8,2]  R1161     1.0111314058303833e-01
    z[3,8,2]  R1162     -2.2710916399955750e-01
    z[3,8,2]  R1163     -2.7996638417243958e-01
    z[3,8,2]  R1164     5.8180510997772217e-02
    z[3,8,2]  R1165     -1.9354438781738281e-01
    z[3,8,2]  R1166     0.0391550213098526
    z[3,8,2]  R1167     -1.0665337741374969e-01
    z[3,8,2]  R1168     9.8015762865543365e-02
    z[3,8,2]  R1169     -1.9831072539091110e-02
    z[3,8,2]  R1170     -8.0827414989471436e-02
    z[3,8,2]  R1171     0.0355074517428875
    z[3,8,2]  R1172     3.8741311430931091e-01
    z[3,8,2]  R1173     -1.0585274547338486e-01
    z[3,8,2]  R1174     -3.9191875606775284e-02
    z[3,8,2]  R1175     3.4256509970873594e-03
    z[3,8,2]  R1176     2.8114444017410278e-01
    z[3,8,2]  R1177     -1.0289106518030167e-01
    z[3,8,2]  R1178     -1.0542208328843117e-02
    z[3,8,2]  R1179     -2.1782732009887695e-01
    z[3,8,2]  R1180     8.0047480762004852e-02
    z[3,8,3]  R32       -1
    z[3,8,3]  R77       1
    z[3,8,3]  R1083     -1
    z[3,8,3]  R1084     1
    z[3,8,3]  R1091     1.2336388975381851e-01
    z[3,8,3]  R1092     1.4014837145805359e-01
    z[3,8,3]  R1093     1.9738397002220154e-01
    z[3,8,3]  R1094     -4.3479744344949722e-02
    z[3,8,3]  R1095     2.2622174024581909e-01
    z[3,8,3]  R1096     -2.4902520701289177e-02
    z[3,8,3]  R1097     2.5310555100440979e-01
    z[3,8,3]  R1098     3.1763198971748352e-01
    z[3,8,3]  R1099     1.9800575077533722e-01
    z[3,8,3]  R1100     -2.8173295781016350e-02
    z[3,8,3]  R1101     2.2794772684574127e-01
    z[3,8,3]  R1102     -0.0826336070895195
    z[3,8,3]  R1103     4.6799725294113159e-01
    z[3,8,3]  R1104     -2.6709496974945068e-01
    z[3,8,3]  R1105     0.503420889377594
    z[3,8,3]  R1106     -4.7182232141494751e-02
    z[3,8,3]  R1107     -3.2185006886720657e-02
    z[3,8,3]  R1108     1.1630264669656754e-01
    z[3,8,3]  R1109     3.4428283572196960e-02
    z[3,8,3]  R1110     -0.00514657236635685
    z[3,8,3]  R1111     8.9136496186256409e-02
    z[3,8,3]  R1112     -3.6063587665557861e-01
    z[3,8,3]  R1113     -0.081561379134655
    z[3,8,3]  R1114     8.1481322646141052e-02
    z[3,8,3]  R1115     1.2045668065547943e-01
    z[3,8,3]  R1116     3.1591024994850159e-01
    z[3,8,3]  R1117     -7.1248807013034821e-02
    z[3,8,3]  R1118     -1.9285000860691071e-02
    z[3,8,3]  R1119     -1.8393030762672424e-01
    z[3,8,3]  R1120     -1.1943616718053818e-01
    z[3,8,3]  R1121     -3.4615222364664078e-02
    z[3,8,3]  R1122     0.208840012550354
    z[3,8,3]  R1123     -2.3434206843376160e-01
    z[3,8,3]  R1124     -3.7884226441383362e-01
    z[3,8,3]  R1125     -4.3607643246650696e-01
    z[3,8,3]  R1126     1.5645003318786621e-01
    z[3,8,3]  R1127     4.4591864943504333e-01
    z[3,8,3]  R1128     -5.6606572866439819e-01
    z[3,8,3]  R1129     -6.4688396453857422e-01
    z[3,8,3]  R1130     -6.5649574995040894e-01
    z[3,8,3]  R1131     2.5739121437072754e-01
    z[3,8,3]  R1132     1.6530117392539978e-01
    z[3,8,3]  R1133     1.7963266372680664e-01
    z[3,8,3]  R1134     1.3234589993953705e-01
    z[3,8,3]  R1135     -4.1194036602973938e-02
    z[3,8,3]  R1136     1.3977135717868805e-01
    z[3,8,3]  R1137     -0.0847676619887352
    z[3,8,3]  R1138     3.2371747493743896e-01
    z[3,8,3]  R1139     1.3982596993446350e-01
    z[3,8,3]  R1140     4.7496250271797180e-01
    z[3,8,3]  R1141     7.1082182228565216e-02
    z[3,8,3]  R1142     5.2524650096893311e-01
    z[3,8,3]  R1143     4.5181828737258911e-01
    z[3,8,3]  R1144     3.5764062404632568e-01
    z[3,8,3]  R1145     2.4676126241683960e-01
    z[3,8,3]  R1146     1.6248725354671478e-01
    z[3,8,3]  R1147     3.5538071393966675e-01
    z[3,8,3]  R1148     4.9725881218910217e-01
    z[3,8,3]  R1149     1.0206269472837448e-01
    z[3,8,3]  R1150     2.6244139671325684e-01
    z[3,8,3]  R1151     7.6342053711414337e-02
    z[3,8,3]  R1152     -5.8134537935256958e-01
    z[3,8,3]  R1153     -2.5366422533988953e-01
    z[3,8,3]  R1154     -1.7145574092864990e-01
    z[3,8,3]  R1155     0.0885215699672699
    z[3,8,3]  R1156     1.3964995741844177e-01
    z[3,8,3]  R1157     -1.9695621728897095e-01
    z[3,8,3]  R1158     -6.9412998855113983e-02
    z[3,8,3]  R1159     -1.7963644862174988e-01
    z[3,8,3]  R1160     -1.2966012954711914e-01
    z[3,8,3]  R1161     6.1762750148773193e-01
    z[3,8,3]  R1162     -6.0979276895523071e-01
    z[3,8,3]  R1163     -7.1638122200965881e-02
    z[3,8,3]  R1164     -3.3242511749267578e-01
    z[3,8,3]  R1165     -5.5677896738052368e-01
    z[3,8,3]  R1166     -3.1964725255966187e-01
    z[3,8,3]  R1167     -0.56904536485672
    z[3,8,3]  R1168     -4.8577833175659180e-01
    z[3,8,3]  R1169     -4.5397144556045532e-01
    z[3,8,3]  R1170     -6.0044860839843750e-01
    z[3,8,3]  R1171     4.0795540809631348e-01
    z[3,8,3]  R1172     1.8678598105907440e-01
    z[3,8,3]  R1173     1.8172113597393036e-01
    z[3,8,3]  R1174     -0.290932834148407
    z[3,8,3]  R1175     6.5892942249774933e-02
    z[3,8,3]  R1176     -2.2303043305873871e-01
    z[3,8,3]  R1177     -6.0945552587509155e-01
    z[3,8,3]  R1178     -2.3416090011596680e-01
    z[3,8,3]  R1179     -1.4389619231224060e-01
    z[3,8,3]  R1180     -1.4314334094524384e-01
    z[3,8,4]  R33       -1
    z[3,8,4]  R78       1
    z[3,8,4]  R1085     -1
    z[3,8,4]  R1086     1
    z[3,8,4]  R1091     -1.7499543726444244e-01
    z[3,8,4]  R1092     -9.3153864145278931e-02
    z[3,8,4]  R1093     -4.2097586393356323e-01
    z[3,8,4]  R1094     -8.7057955563068390e-02
    z[3,8,4]  R1095     1.9317786395549774e-01
    z[3,8,4]  R1096     9.1338835656642914e-02
    z[3,8,4]  R1097     3.4952649474143982e-01
    z[3,8,4]  R1098     1.7258162796497345e-01
    z[3,8,4]  R1099     2.2579045966267586e-02
    z[3,8,4]  R1100     -4.4032309204339981e-02
    z[3,8,4]  R1101     8.7571300566196442e-02
    z[3,8,4]  R1102     1.6282857954502106e-01
    z[3,8,4]  R1103     -2.4272072315216064e-01
    z[3,8,4]  R1104     2.6515156030654907e-01
    z[3,8,4]  R1105     -2.6562556624412537e-01
    z[3,8,4]  R1106     -5.7785177230834961e-01
    z[3,8,4]  R1107     -1.6454145312309265e-01
    z[3,8,4]  R1108     -0.111277274787426
    z[3,8,4]  R1109     -3.0620154738426208e-01
    z[3,8,4]  R1110     -7.2088211774826050e-01
    z[3,8,4]  R1111     1.2066298164427280e-02
    z[3,8,4]  R1112     2.4230834096670151e-02
    z[3,8,4]  R1113     0.0743400976061821
    z[3,8,4]  R1114     1.9495931267738342e-01
    z[3,8,4]  R1115     -5.6943674571812153e-03
    z[3,8,4]  R1116     2.3302891850471497e-01
    z[3,8,4]  R1117     -1.9806885719299316e-01
    z[3,8,4]  R1118     1.6575929522514343e-01
    z[3,8,4]  R1119     -2.6363892480731010e-02
    z[3,8,4]  R1120     -3.8546428084373474e-01
    z[3,8,4]  R1121     1.8515472114086151e-01
    z[3,8,4]  R1122     -4.6308046579360962e-01
    z[3,8,4]  R1123     1.9928932189941406e-01
    z[3,8,4]  R1124     3.5109764337539673e-01
    z[3,8,4]  R1125     -7.7538110315799713e-02
    z[3,8,4]  R1126     5.2223944664001465e-01
    z[3,8,4]  R1127     -2.9867190122604370e-01
    z[3,8,4]  R1128     -2.8627860546112061e-01
    z[3,8,4]  R1129     -9.1373048722743988e-02
    z[3,8,4]  R1130     5.1102095842361450e-01
    z[3,8,4]  R1131     -1.6608202457427979e-01
    z[3,8,4]  R1132     1.4930222928524017e-01
    z[3,8,4]  R1133     1.0916792601346970e-01
    z[3,8,4]  R1134     1.6858358681201935e-01
    z[3,8,4]  R1135     1.7198072746396065e-02
    z[3,8,4]  R1136     -3.4115172922611237e-02
    z[3,8,4]  R1137     -1.9708819687366486e-02
    z[3,8,4]  R1138     1.2298287451267242e-01
    z[3,8,4]  R1139     -0.27997025847435
    z[3,8,4]  R1140     -1.6390171647071838e-01
    z[3,8,4]  R1141     -1.8132030963897705e-01
    z[3,8,4]  R1142     1.9520732760429382e-01
    z[3,8,4]  R1143     -1.9591921567916870e-01
    z[3,8,4]  R1144     -3.0801620334386826e-02
    z[3,8,4]  R1145     -6.9214117527008057e-01
    z[3,8,4]  R1146     -2.2359889745712280e-01
    z[3,8,4]  R1147     2.5557526946067810e-01
    z[3,8,4]  R1148     -2.2692269086837769e-01
    z[3,8,4]  R1149     3.4116649627685547e-01
    z[3,8,4]  R1150     2.1558435261249542e-01
    z[3,8,4]  R1151     9.2774204909801483e-02
    z[3,8,4]  R1152     -8.5824113339185715e-03
    z[3,8,4]  R1153     8.9389160275459290e-02
    z[3,8,4]  R1154     1.5136560425162315e-02
    z[3,8,4]  R1155     7.6929312199354172e-03
    z[3,8,4]  R1156     -0.0321052223443985
    z[3,8,4]  R1157     -7.9387754201889038e-02
    z[3,8,4]  R1158     -1.2461936473846436e-01
    z[3,8,4]  R1159     -1.1244063824415207e-01
    z[3,8,4]  R1160     7.1235232055187225e-02
    z[3,8,4]  R1161     3.2721456140279770e-02
    z[3,8,4]  R1162     2.3946096003055573e-01
    z[3,8,4]  R1163     3.6254864931106567e-01
    z[3,8,4]  R1164     -3.1196763738989830e-02
    z[3,8,4]  R1165     4.7189682722091675e-02
    z[3,8,4]  R1166     -4.9045007675886154e-02
    z[3,8,4]  R1167     2.2894616425037384e-01
    z[3,8,4]  R1168     2.1908958256244659e-01
    z[3,8,4]  R1169     1.0117696970701218e-01
    z[3,8,4]  R1170     3.4478890895843506e-01
    z[3,8,4]  R1171     5.3812485933303833e-01
    z[3,8,4]  R1172     2.0495966076850891e-01
    z[3,8,4]  R1173     -1.7710077762603760e-01
    z[3,8,4]  R1174     4.3691709637641907e-01
    z[3,8,4]  R1175     -9.8659023642539978e-03
    z[3,8,4]  R1176     6.8453907966613770e-02
    z[3,8,4]  R1177     1.5254114568233490e-01
    z[3,8,4]  R1178     -3.0586105585098267e-01
    z[3,8,4]  R1179     -2.0717906951904297e-01
    z[3,8,4]  R1180     -8.4953360259532928e-02
    z[3,8,5]  R34       -1
    z[3,8,5]  R79       1
    z[3,8,5]  R1087     -1
    z[3,8,5]  R1088     1
    z[3,8,5]  R1091     3.9365947246551514e-01
    z[3,8,5]  R1092     1.8414977192878723e-01
    z[3,8,5]  R1093     1.3328801095485687e-01
    z[3,8,5]  R1094     2.4706198275089264e-01
    z[3,8,5]  R1095     4.0213245153427124e-01
    z[3,8,5]  R1096     2.3150397837162018e-01
    z[3,8,5]  R1097     5.8123461902141571e-02
    z[3,8,5]  R1098     -1.1589889228343964e-01
    z[3,8,5]  R1099     -2.0197346806526184e-01
    z[3,8,5]  R1100     -3.0134108662605286e-01
    z[3,8,5]  R1101     -4.1382014751434326e-01
    z[3,8,5]  R1102     -1.6606800258159637e-01
    z[3,8,5]  R1103     0.132082000374794
    z[3,8,5]  R1104     -1.0103802382946014e-01
    z[3,8,5]  R1105     -5.1464891433715820e-01
    z[3,8,5]  R1106     -3.7848666310310364e-01
    z[3,8,5]  R1107     1.1804620176553726e-01
    z[3,8,5]  R1108     2.5822449475526810e-02
    z[3,8,5]  R1109     2.5962832570075989e-01
    z[3,8,5]  R1110     -3.1875947117805481e-01
    z[3,8,5]  R1111     -5.5032365024089813e-02
    z[3,8,5]  R1112     -6.8893593549728394e-01
    z[3,8,5]  R1113     1.0112300515174866e-01
    z[3,8,5]  R1114     8.0109424889087677e-02
    z[3,8,5]  R1115     2.6628252863883972e-01
    z[3,8,5]  R1116     2.9066300392150879e-01
    z[3,8,5]  R1117     2.5254175066947937e-01
    z[3,8,5]  R1118     3.9021271467208862e-01
    z[3,8,5]  R1119     1.5079198777675629e-01
    z[3,8,5]  R1120     1.1973618716001511e-01
    z[3,8,5]  R1121     -3.1197625398635864e-01
    z[3,8,5]  R1122     -8.2270748913288116e-02
    z[3,8,5]  R1123     -3.3672001957893372e-01
    z[3,8,5]  R1124     -2.1148182451725006e-01
    z[3,8,5]  R1125     -3.8456863164901733e-01
    z[3,8,5]  R1126     0.0923554003238678
    z[3,8,5]  R1127     5.3185307979583740e-01
    z[3,8,5]  R1128     -3.5393461585044861e-01
    z[3,8,5]  R1129     -1.6921687126159668e-01
    z[3,8,5]  R1130     -2.2447425127029419e-01
    z[3,8,5]  R1131     3.7518101930618286e-01
    z[3,8,5]  R1132     -6.0493446653708816e-04
    z[3,8,5]  R1133     2.2294235229492188e-01
    z[3,8,5]  R1134     2.8060016036033630e-01
    z[3,8,5]  R1135     2.0822128653526306e-01
    z[3,8,5]  R1136     2.6795136928558350e-01
    z[3,8,5]  R1137     2.4268044531345367e-01
    z[3,8,5]  R1138     -1.2292737513780594e-01
    z[3,8,5]  R1139     0.171631321310997
    z[3,8,5]  R1140     -1.7719285190105438e-01
    z[3,8,5]  R1141     -4.6486237645149231e-01
    z[3,8,5]  R1142     -2.3795351386070251e-01
    z[3,8,5]  R1143     1.5455009043216705e-01
    z[3,8,5]  R1144     -5.0613671541213989e-01
    z[3,8,5]  R1145     2.0881672203540802e-01
    z[3,8,5]  R1146     -3.0684599280357361e-01
    z[3,8,5]  R1147     -6.2262868881225586e-01
    z[3,8,5]  R1148     2.8113192319869995e-01
    z[3,8,5]  R1149     1.2872710824012756e-01
    z[3,8,5]  R1150     -1.3126474618911743e-01
    z[3,8,5]  R1151     5.3936883807182312e-02
    z[3,8,5]  R1152     -2.0388758182525635e-01
    z[3,8,5]  R1153     -2.4250808358192444e-01
    z[3,8,5]  R1154     -1.6675812005996704e-01
    z[3,8,5]  R1155     -1.8792568147182465e-01
    z[3,8,5]  R1156     2.3786008358001709e-01
    z[3,8,5]  R1157     1.3416735827922821e-01
    z[3,8,5]  R1158     2.9073727130889893e-01
    z[3,8,5]  R1159     -7.5451299548149109e-02
    z[3,8,5]  R1160     -1.6008451581001282e-01
    z[3,8,5]  R1161     2.8374210000038147e-01
    z[3,8,5]  R1162     -9.4341598451137543e-02
    z[3,8,5]  R1163     -3.8035833835601807e-01
    z[3,8,5]  R1164     4.5989226549863815e-02
    z[3,8,5]  R1165     1.1464400589466095e-01
    z[3,8,5]  R1166     -1.8688382208347321e-01
    z[3,8,5]  R1167     -1.3190971314907074e-01
    z[3,8,5]  R1168     -3.4474423527717590e-01
    z[3,8,5]  R1169     -5.5179882049560547e-01
    z[3,8,5]  R1170     -4.4205829501152039e-01
    z[3,8,5]  R1171     4.1795790195465088e-01
    z[3,8,5]  R1172     5.2266085147857666e-01
    z[3,8,5]  R1173     -3.5278671421110630e-03
    z[3,8,5]  R1174     -1.4266875386238098e-01
    z[3,8,5]  R1175     -4.2489495873451233e-01
    z[3,8,5]  R1176     -1.4343149960041046e-01
    z[3,8,5]  R1177     -2.5397273898124695e-01
    z[3,8,5]  R1178     -1.2654094398021698e-01
    z[3,8,5]  R1179     -1.2960636615753174e-01
    z[3,8,5]  R1180     2.9142990708351135e-01
    z[3,8,6]  R35       -1
    z[3,8,6]  R80       1
    z[3,8,6]  R1089     -1
    z[3,8,6]  R1090     1
    z[3,8,6]  R1091     1.8048782646656036e-01
    z[3,8,6]  R1092     -1.2364926747977734e-02
    z[3,8,6]  R1093     -1.5485283732414246e-01
    z[3,8,6]  R1094     -3.8015130162239075e-01
    z[3,8,6]  R1095     -2.1169923245906830e-01
    z[3,8,6]  R1096     -3.5489144921302795e-01
    z[3,8,6]  R1097     -2.0372769236564636e-01
    z[3,8,6]  R1098     3.0969858169555664e-01
    z[3,8,6]  R1099     -2.4845942854881287e-01
    z[3,8,6]  R1100     9.4537958502769470e-02
    z[3,8,6]  R1101     -1.2200947850942612e-01
    z[3,8,6]  R1102     4.2418986558914185e-01
    z[3,8,6]  R1103     -0.426483690738678
    z[3,8,6]  R1104     -1.8254956230521202e-02
    z[3,8,6]  R1105     2.0143781602382660e-01
    z[3,8,6]  R1106     4.6744823455810547e-01
    z[3,8,6]  R1107     -1.4372245967388153e-01
    z[3,8,6]  R1108     3.5217520594596863e-01
    z[3,8,6]  R1109     -4.5647022128105164e-01
    z[3,8,6]  R1110     1.8208703398704529e-01
    z[3,8,6]  R1111     -0.01593635417521
    z[3,8,6]  R1112     -3.2406035065650940e-01
    z[3,8,6]  R1113     1.6168814897537231e-01
    z[3,8,6]  R1114     -5.0659310072660446e-02
    z[3,8,6]  R1115     2.4650168418884277e-01
    z[3,8,6]  R1116     2.1313808392733335e-03
    z[3,8,6]  R1117     -2.6850234717130661e-02
    z[3,8,6]  R1118     1.1009088903665543e-01
    z[3,8,6]  R1119     3.6808228492736816e-01
    z[3,8,6]  R1120     1.2661641836166382e-01
    z[3,8,6]  R1121     -5.5408710241317749e-01
    z[3,8,6]  R1122     -5.0046551227569580e-01
    z[3,8,6]  R1123     -2.6688572764396667e-01
    z[3,8,6]  R1124     -1.3869464397430420e-02
    z[3,8,6]  R1125     1.4463216066360474e-01
    z[3,8,6]  R1126     -5.4464846849441528e-01
    z[3,8,6]  R1127     2.7732202783226967e-02
    z[3,8,6]  R1128     1.2828026711940765e-01
    z[3,8,6]  R1129     -3.6480379104614258e-01
    z[3,8,6]  R1130     2.2492859512567520e-02
    z[3,8,6]  R1131     -9.4628900289535522e-02
    z[3,8,6]  R1132     -8.2821592688560486e-02
    z[3,8,6]  R1133     -3.6194634437561035e-01
    z[3,8,6]  R1134     -1.9311843439936638e-02
    z[3,8,6]  R1135     -2.0924621820449829e-01
    z[3,8,6]  R1136     8.3675451576709747e-02
    z[3,8,6]  R1137     -1.1608625948429108e-01
    z[3,8,6]  R1138     1.6750479117035866e-02
    z[3,8,6]  R1139     -3.5390508174896240e-01
    z[3,8,6]  R1140     2.8072218410670757e-03
    z[3,8,6]  R1141     0.0628654882311821
    z[3,8,6]  R1142     -4.6374088525772095e-01
    z[3,8,6]  R1143     -2.2481869161128998e-01
    z[3,8,6]  R1144     -1.9075348973274231e-01
    z[3,8,6]  R1145     -9.0090613812208176e-03
    z[3,8,6]  R1146     1.7228309810161591e-01
    z[3,8,6]  R1147     3.2534804940223694e-01
    z[3,8,6]  R1148     4.2964923381805420e-01
    z[3,8,6]  R1149     2.0622503757476807e-01
    z[3,8,6]  R1150     4.6970045566558838e-01
    z[3,8,6]  R1151     0.0920991376042366
    z[3,8,6]  R1152     3.9331771433353424e-02
    z[3,8,6]  R1153     1.0742158442735672e-01
    z[3,8,6]  R1154     1.1864091455936432e-01
    z[3,8,6]  R1155     1.3005739450454712e-01
    z[3,8,6]  R1156     -7.7928858809173107e-03
    z[3,8,6]  R1157     -3.4613016992807388e-02
    z[3,8,6]  R1158     2.5950780138373375e-02
    z[3,8,6]  R1159     3.1248387694358826e-01
    z[3,8,6]  R1160     3.6323550343513489e-01
    z[3,8,6]  R1161     2.7429863810539246e-01
    z[3,8,6]  R1162     -1.4621193706989288e-01
    z[3,8,6]  R1163     -1.0429130494594574e-01
    z[3,8,6]  R1164     -2.7589586377143860e-01
    z[3,8,6]  R1165     -2.4740052223205566e-01
    z[3,8,6]  R1166     -3.1327673792839050e-01
    z[3,8,6]  R1167     -3.3595946431159973e-01
    z[3,8,6]  R1168     -2.8496238589286804e-01
    z[3,8,6]  R1169     -3.0465468764305115e-01
    z[3,8,6]  R1170     -1.9501791894435883e-01
    z[3,8,6]  R1171     5.0175851583480835e-01
    z[3,8,6]  R1172     8.3230612799525261e-03
    z[3,8,6]  R1173     2.8687119483947754e-01
    z[3,8,6]  R1174     7.6511144638061523e-02
    z[3,8,6]  R1175     -1.5091150999069214e-01
    z[3,8,6]  R1176     -2.0095384120941162e-01
    z[3,8,6]  R1177     -2.7648857235908508e-01
    z[3,8,6]  R1178     -3.3896368741989136e-01
    z[3,8,6]  R1179     -2.6503643393516541e-01
    z[3,8,6]  R1180     -1.2459450960159302e-01
    z[8,3,0]  R29       1
    z[8,3,0]  R74       -1
    z[8,3,0]  R1181     -1
    z[8,3,0]  R1182     1
    z[8,3,0]  R1195     7.0530152320861816e-01
    z[8,3,0]  R1196     8.8695132732391357e-01
    z[8,3,0]  R1197     7.5331693887710571e-01
    z[8,3,0]  R1198     9.0934127569198608e-01
    z[8,3,0]  R1199     8.2864642143249512e-01
    z[8,3,0]  R1200     9.4234520196914673e-01
    z[8,3,0]  R1201     9.3040871620178223e-01
    z[8,3,0]  R1202     0.736838161945343
    z[8,3,0]  R1203     8.6052078008651733e-01
    z[8,3,0]  R1204     0.713066577911377
    z[8,3,0]  R1205     1.3651348650455475e-01
    z[8,3,0]  R1206     -3.2548218965530396e-02
    z[8,3,0]  R1207     -4.8324260115623474e-01
    z[8,3,0]  R1208     4.2534127831459045e-02
    z[8,3,0]  R1209     -2.1742577850818634e-01
    z[8,3,0]  R1210     -5.1593035459518433e-01
    z[8,3,0]  R1211     -3.0395722389221191e-01
    z[8,3,0]  R1212     -7.2562158107757568e-02
    z[8,3,0]  R1213     -5.1913022994995117e-01
    z[8,3,0]  R1214     -1.5697129070758820e-01
    z[8,3,0]  R1215     -3.2283249497413635e-01
    z[8,3,0]  R1216     -0.721881091594696
    z[8,3,0]  R1217     -2.3561200499534607e-01
    z[8,3,0]  R1218     -2.9592856764793396e-01
    z[8,3,0]  R1219     -2.5959175825119019e-01
    z[8,3,0]  R1220     -2.2420540452003479e-01
    z[8,3,0]  R1221     -4.0958243608474731e-01
    z[8,3,0]  R1222     -0.331001877784729
    z[8,3,0]  R1223     -2.5792077183723450e-01
    z[8,3,0]  R1224     -1.9591730833053589e-01
    z[8,3,0]  R1225     -2.6988866925239563e-01
    z[8,3,0]  R1226     -6.8003219366073608e-01
    z[8,3,0]  R1227     -6.5597808361053467e-01
    z[8,3,0]  R1228     -8.8376182317733765e-01
    z[8,3,0]  R1229     -0.755744218826294
    z[8,3,0]  R1230     -8.1956106424331665e-01
    z[8,3,0]  R1231     -6.7751920223236084e-01
    z[8,3,0]  R1232     -6.9661718606948853e-01
    z[8,3,0]  R1233     -5.9385901689529419e-01
    z[8,3,0]  R1234     -5.2864837646484375e-01
    z[8,3,0]  R1235     7.0176303386688232e-02
    z[8,3,0]  R1236     -0.313693106174469
    z[8,3,0]  R1237     -4.1877318173646927e-02
    z[8,3,0]  R1238     -8.0878752470016479e-01
    z[8,3,0]  R1239     -1.6961207985877991e-01
    z[8,3,0]  R1240     -8.6870723962783813e-01
    z[8,3,0]  R1241     -6.7262911796569824e-01
    z[8,3,0]  R1242     -8.4285312891006470e-01
    z[8,3,0]  R1243     -2.3766933381557465e-01
    z[8,3,0]  R1244     -9.1773825883865356e-01
    z[8,3,0]  R1245     7.1162068843841553e-01
    z[8,3,0]  R1246     9.5327025651931763e-01
    z[8,3,0]  R1247     7.0742470026016235e-01
    z[8,3,0]  R1248     0.798708438873291
    z[8,3,0]  R1249     5.8215296268463135e-01
    z[8,3,0]  R1250     8.0113774538040161e-01
    z[8,3,0]  R1251     8.3893394470214844e-01
    z[8,3,0]  R1252     7.2176802158355713e-01
    z[8,3,0]  R1253     6.9075030088424683e-01
    z[8,3,0]  R1254     6.9604158401489258e-01
    z[8,3,0]  R1255     -4.7281497716903687e-01
    z[8,3,0]  R1256     -6.8683397769927979e-01
    z[8,3,0]  R1257     -6.7731253802776337e-02
    z[8,3,0]  R1258     -3.9962872862815857e-01
    z[8,3,0]  R1259     -1.8932853639125824e-01
    z[8,3,0]  R1260     -4.4252589344978333e-01
    z[8,3,0]  R1261     -4.3393689393997192e-01
    z[8,3,0]  R1262     -2.8371793031692505e-01
    z[8,3,0]  R1263     -3.8343551754951477e-01
    z[8,3,0]  R1264     -3.8241106271743774e-01
    z[8,3,0]  R1265     1.2241673469543457e-01
    z[8,3,0]  R1266     -1.2061749584972858e-02
    z[8,3,0]  R1267     -1.4337897300720215e-01
    z[8,3,0]  R1268     -2.2681014239788055e-01
    z[8,3,0]  R1269     -1.9298419356346130e-01
    z[8,3,0]  R1270     -4.9005974084138870e-02
    z[8,3,0]  R1271     -1.9798719882965088e-01
    z[8,3,0]  R1272     5.4058995097875595e-02
    z[8,3,0]  R1273     1.2684838473796844e-01
    z[8,3,0]  R1274     -1.7259445041418076e-02
    z[8,3,0]  R1275     1.5683120489120483e-01
    z[8,3,0]  R1276     -5.1860684156417847e-01
    z[8,3,0]  R1277     2.6655766367912292e-01
    z[8,3,0]  R1278     -5.6426441669464111e-01
    z[8,3,0]  R1279     2.5352329015731812e-02
    z[8,3,0]  R1280     -6.1914050579071045e-01
    z[8,3,0]  R1281     -3.5635665059089661e-01
    z[8,3,0]  R1282     3.6339778453111649e-02
    z[8,3,0]  R1283     7.9450950026512146e-02
    z[8,3,0]  R1284     2.2689421474933624e-01
    z[8,3,1]  R30       1
    z[8,3,1]  R75       -1
    z[8,3,1]  R1183     -1
    z[8,3,1]  R1184     1
    z[8,3,1]  R1195     1.9630730152130127e-02
    z[8,3,1]  R1196     -7.9196922481060028e-02
    z[8,3,1]  R1197     -1.9613333046436310e-02
    z[8,3,1]  R1198     1.1365023255348206e-01
    z[8,3,1]  R1199     -3.1931233406066895e-01
    z[8,3,1]  R1200     -1.1122805625200272e-01
    z[8,3,1]  R1201     1.1261923238635063e-02
    z[8,3,1]  R1202     -2.4862538278102875e-01
    z[8,3,1]  R1203     -5.1845584064722061e-02
    z[8,3,1]  R1204     -0.0972457155585289
    z[8,3,1]  R1205     8.0286830663681030e-01
    z[8,3,1]  R1206     5.8779406547546387e-01
    z[8,3,1]  R1207     5.0273990631103516e-01
    z[8,3,1]  R1208     4.3708527088165283e-01
    z[8,3,1]  R1209     4.7819891571998596e-01
    z[8,3,1]  R1210     4.5853444933891296e-01
    z[8,3,1]  R1211     4.3781113624572754e-01
    z[8,3,1]  R1212     5.7233953475952148e-01
    z[8,3,1]  R1213     5.0355130434036255e-01
    z[8,3,1]  R1214     3.4641581773757935e-01
    z[8,3,1]  R1215     -9.3039542436599731e-01
    z[8,3,1]  R1216     2.0746754109859467e-01
    z[8,3,1]  R1217     -8.8955307006835938e-01
    z[8,3,1]  R1218     -0.88219153881073
    z[8,3,1]  R1219     -8.5865569114685059e-01
    z[8,3,1]  R1220     -9.2376661300659180e-01
    z[8,3,1]  R1221     -8.7629443407058716e-01
    z[8,3,1]  R1222     -8.7441927194595337e-01
    z[8,3,1]  R1223     -8.8528978824615479e-01
    z[8,3,1]  R1224     -8.8353222608566284e-01
    z[8,3,1]  R1225     -6.1534738540649414e-01
    z[8,3,1]  R1226     1.6282060742378235e-01
    z[8,3,1]  R1227     -4.4630587100982666e-01
    z[8,3,1]  R1228     -1.6083197295665741e-01
    z[8,3,1]  R1229     -6.9364093244075775e-02
    z[8,3,1]  R1230     -2.9856148362159729e-01
    z[8,3,1]  R1231     -1.5196952223777771e-01
    z[8,3,1]  R1232     -1.4520509541034698e-01
    z[8,3,1]  R1233     -1.8252392113208771e-01
    z[8,3,1]  R1234     3.3651031553745270e-02
    z[8,3,1]  R1235     -3.3370348811149597e-01
    z[8,3,1]  R1236     -6.3353508710861206e-01
    z[8,3,1]  R1237     -9.1670429706573486e-01
    z[8,3,1]  R1238     2.0634920895099640e-01
    z[8,3,1]  R1239     -0.873768150806427
    z[8,3,1]  R1240     2.2565890848636627e-01
    z[8,3,1]  R1241     3.6477770656347275e-02
    z[8,3,1]  R1242     -1.0097629576921463e-01
    z[8,3,1]  R1243     -8.6336147785186768e-01
    z[8,3,1]  R1244     1.5227134525775909e-01
    z[8,3,1]  R1245     -9.5694243907928467e-02
    z[8,3,1]  R1246     -3.7281468510627747e-02
    z[8,3,1]  R1247     2.7269739075563848e-04
    z[8,3,1]  R1248     1.2312665581703186e-01
    z[8,3,1]  R1249     2.2732684016227722e-01
    z[8,3,1]  R1250     -2.7584299445152283e-01
    z[8,3,1]  R1251     8.5411950945854187e-02
    z[8,3,1]  R1252     9.4852922484278679e-03
    z[8,3,1]  R1253     -3.8345813751220703e-01
    z[8,3,1]  R1254     -1.6182261705398560e-01
    z[8,3,1]  R1255     3.8585740327835083e-01
    z[8,3,1]  R1256     2.5853881239891052e-01
    z[8,3,1]  R1257     5.1659452915191650e-01
    z[8,3,1]  R1258     6.1803042888641357e-01
    z[8,3,1]  R1259     4.8582258820533752e-01
    z[8,3,1]  R1260     2.7209252119064331e-01
    z[8,3,1]  R1261     8.4815979003906250e-01
    z[8,3,1]  R1262     0.591509997844696
    z[8,3,1]  R1263     6.3983148336410522e-01
    z[8,3,1]  R1264     4.4348701834678650e-01
    z[8,3,1]  R1265     -0.985664963722229
    z[8,3,1]  R1266     4.2809438705444336e-01
    z[8,3,1]  R1267     -9.2774575948715210e-01
    z[8,3,1]  R1268     -9.0466153621673584e-01
    z[8,3,1]  R1269     -8.9581912755966187e-01
    z[8,3,1]  R1270     -8.7088793516159058e-01
    z[8,3,1]  R1271     -9.1231465339660645e-01
    z[8,3,1]  R1272     -0.892479658126831
    z[8,3,1]  R1273     -8.8815581798553467e-01
    z[8,3,1]  R1274     -8.9752441644668579e-01
    z[8,3,1]  R1275     0.728148341178894
    z[8,3,1]  R1276     3.8828489184379578e-01
    z[8,3,1]  R1277     7.8841805458068848e-01
    z[8,3,1]  R1278     4.5100745558738708e-01
    z[8,3,1]  R1279     0.782682478427887
    z[8,3,1]  R1280     7.1726846508681774e-03
    z[8,3,1]  R1281     -2.3392945528030396e-01
    z[8,3,1]  R1282     -6.7416888475418091e-01
    z[8,3,1]  R1283     -6.3650351762771606e-01
    z[8,3,1]  R1284     -4.3019664287567139e-01
    z[8,3,2]  R31       1
    z[8,3,2]  R76       -1
    z[8,3,2]  R1185     -1
    z[8,3,2]  R1186     1
    z[8,3,2]  R1195     0.508542537689209
    z[8,3,2]  R1196     3.8803330063819885e-01
    z[8,3,2]  R1197     4.5523053407669067e-01
    z[8,3,2]  R1198     1.8744862079620361e-01
    z[8,3,2]  R1199     3.4964513778686523e-01
    z[8,3,2]  R1200     1.0699527338147163e-02
    z[8,3,2]  R1201     2.3295685648918152e-01
    z[8,3,2]  R1202     5.0984853506088257e-01
    z[8,3,2]  R1203     6.4617067575454712e-02
    z[8,3,2]  R1204     4.4522005319595337e-01
    z[8,3,2]  R1205     -2.8069171309471130e-01
    z[8,3,2]  R1206     -2.6032933592796326e-01
    z[8,3,2]  R1207     -4.4359427690505981e-01
    z[8,3,2]  R1208     -6.2107211351394653e-01
    z[8,3,2]  R1209     -3.7472090125083923e-01
    z[8,3,2]  R1210     -0.568618893623352
    z[8,3,2]  R1211     -1.7549788951873779e-01
    z[8,3,2]  R1212     -3.2367938756942749e-01
    z[8,3,2]  R1213     -5.3947108983993530e-01
    z[8,3,2]  R1214     -7.0862895250320435e-01
    z[8,3,2]  R1215     -0.0657036080956459
    z[8,3,2]  R1216     0.23386250436306
    z[8,3,2]  R1217     1.0245457291603088e-01
    z[8,3,2]  R1218     -2.5030821561813354e-01
    z[8,3,2]  R1219     -3.6769038438796997e-01
    z[8,3,2]  R1220     -1.3862235844135284e-01
    z[8,3,2]  R1221     -7.5600305572152138e-03
    z[8,3,2]  R1222     -1.4240401983261108e-01
    z[8,3,2]  R1223     -3.8570471107959747e-02
    z[8,3,2]  R1224     -3.9163712412118912e-02
    z[8,3,2]  R1225     1.0111314058303833e-01
    z[8,3,2]  R1226     -2.2710916399955750e-01
    z[8,3,2]  R1227     -2.7996638417243958e-01
    z[8,3,2]  R1228     5.8180510997772217e-02
    z[8,3,2]  R1229     -1.9354438781738281e-01
    z[8,3,2]  R1230     0.0391550213098526
    z[8,3,2]  R1231     -1.0665337741374969e-01
    z[8,3,2]  R1232     9.8015762865543365e-02
    z[8,3,2]  R1233     -1.9831072539091110e-02
    z[8,3,2]  R1234     -8.0827414989471436e-02
    z[8,3,2]  R1235     0.0355074517428875
    z[8,3,2]  R1236     3.8741311430931091e-01
    z[8,3,2]  R1237     -1.0585274547338486e-01
    z[8,3,2]  R1238     -3.9191875606775284e-02
    z[8,3,2]  R1239     3.4256509970873594e-03
    z[8,3,2]  R1240     2.8114444017410278e-01
    z[8,3,2]  R1241     -1.0289106518030167e-01
    z[8,3,2]  R1242     -1.0542208328843117e-02
    z[8,3,2]  R1243     -2.1782732009887695e-01
    z[8,3,2]  R1244     8.0047480762004852e-02
    z[8,3,2]  R1245     5.0105190277099609e-01
    z[8,3,2]  R1246     1.6583970189094543e-01
    z[8,3,2]  R1247     4.9155265092849731e-01
    z[8,3,2]  R1248     3.6315330862998962e-01
    z[8,3,2]  R1249     5.6071329116821289e-01
    z[8,3,2]  R1250     3.0591517686843872e-01
    z[8,3,2]  R1251     2.4037525057792664e-01
    z[8,3,2]  R1252     0.488815575838089
    z[8,3,2]  R1253     4.8330357670783997e-01
    z[8,3,2]  R1254     6.2198311090469360e-01
    z[8,3,2]  R1255     -6.1789786815643311e-01
    z[8,3,2]  R1256     -4.6963772177696228e-01
    z[8,3,2]  R1257     -5.0127208232879639e-01
    z[8,3,2]  R1258     -5.5330657958984375e-01
    z[8,3,2]  R1259     -3.1416711211204529e-01
    z[8,3,2]  R1260     -1.7954818904399872e-01
    z[8,3,2]  R1261     1.7211334407329559e-01
    z[8,3,2]  R1262     -6.4731532335281372e-01
    z[8,3,2]  R1263     -2.6995593309402466e-01
    z[8,3,2]  R1264     -5.1188085228204727e-02
    z[8,3,2]  R1265     0.0458839125931263
    z[8,3,2]  R1266     0.326031357049942
    z[8,3,2]  R1267     2.6491987705230713e-01
    z[8,3,2]  R1268     2.7660864591598511e-01
    z[8,3,2]  R1269     1.1854731291532516e-01
    z[8,3,2]  R1270     -2.3694671690464020e-02
    z[8,3,2]  R1271     1.4027518033981323e-01
    z[8,3,2]  R1272     -9.1233126819133759e-02
    z[8,3,2]  R1273     4.8379283398389816e-02
    z[8,3,2]  R1274     -3.0592581257224083e-02
    z[8,3,2]  R1275     -0.0733601376414299
    z[8,3,2]  R1276     2.5493115186691284e-01
    z[8,3,2]  R1277     -1.6764026880264282e-01
    z[8,3,2]  R1278     4.0803188085556030e-01
    z[8,3,2]  R1279     -1.4757739007472992e-01
    z[8,3,2]  R1280     1.1929593980312347e-01
    z[8,3,2]  R1281     -4.9659019708633423e-01
    z[8,3,2]  R1282     8.0252867192029953e-03
    z[8,3,2]  R1283     5.1690624095499516e-03
    z[8,3,2]  R1284     -1.4292004704475403e-01
    z[8,3,3]  R32       1
    z[8,3,3]  R77       -1
    z[8,3,3]  R1187     -1
    z[8,3,3]  R1188     1
    z[8,3,3]  R1195     2.5739121437072754e-01
    z[8,3,3]  R1196     1.6530117392539978e-01
    z[8,3,3]  R1197     1.7963266372680664e-01
    z[8,3,3]  R1198     1.3234589993953705e-01
    z[8,3,3]  R1199     -4.1194036602973938e-02
    z[8,3,3]  R1200     1.3977135717868805e-01
    z[8,3,3]  R1201     -0.0847676619887352
    z[8,3,3]  R1202     3.2371747493743896e-01
    z[8,3,3]  R1203     1.3982596993446350e-01
    z[8,3,3]  R1204     4.7496250271797180e-01
    z[8,3,3]  R1205     7.1082182228565216e-02
    z[8,3,3]  R1206     5.2524650096893311e-01
    z[8,3,3]  R1207     4.5181828737258911e-01
    z[8,3,3]  R1208     3.5764062404632568e-01
    z[8,3,3]  R1209     2.4676126241683960e-01
    z[8,3,3]  R1210     1.6248725354671478e-01
    z[8,3,3]  R1211     3.5538071393966675e-01
    z[8,3,3]  R1212     4.9725881218910217e-01
    z[8,3,3]  R1213     1.0206269472837448e-01
    z[8,3,3]  R1214     2.6244139671325684e-01
    z[8,3,3]  R1215     7.6342053711414337e-02
    z[8,3,3]  R1216     -5.8134537935256958e-01
    z[8,3,3]  R1217     -2.5366422533988953e-01
    z[8,3,3]  R1218     -1.7145574092864990e-01
    z[8,3,3]  R1219     0.0885215699672699
    z[8,3,3]  R1220     1.3964995741844177e-01
    z[8,3,3]  R1221     -1.9695621728897095e-01
    z[8,3,3]  R1222     -6.9412998855113983e-02
    z[8,3,3]  R1223     -1.7963644862174988e-01
    z[8,3,3]  R1224     -1.2966012954711914e-01
    z[8,3,3]  R1225     6.1762750148773193e-01
    z[8,3,3]  R1226     -6.0979276895523071e-01
    z[8,3,3]  R1227     -7.1638122200965881e-02
    z[8,3,3]  R1228     -3.3242511749267578e-01
    z[8,3,3]  R1229     -5.5677896738052368e-01
    z[8,3,3]  R1230     -3.1964725255966187e-01
    z[8,3,3]  R1231     -0.56904536485672
    z[8,3,3]  R1232     -4.8577833175659180e-01
    z[8,3,3]  R1233     -4.5397144556045532e-01
    z[8,3,3]  R1234     -6.0044860839843750e-01
    z[8,3,3]  R1235     4.0795540809631348e-01
    z[8,3,3]  R1236     1.8678598105907440e-01
    z[8,3,3]  R1237     1.8172113597393036e-01
    z[8,3,3]  R1238     -0.290932834148407
    z[8,3,3]  R1239     6.5892942249774933e-02
    z[8,3,3]  R1240     -2.2303043305873871e-01
    z[8,3,3]  R1241     -6.0945552587509155e-01
    z[8,3,3]  R1242     -2.3416090011596680e-01
    z[8,3,3]  R1243     -1.4389619231224060e-01
    z[8,3,3]  R1244     -1.4314334094524384e-01
    z[8,3,3]  R1245     1.2336388975381851e-01
    z[8,3,3]  R1246     1.4014837145805359e-01
    z[8,3,3]  R1247     1.9738397002220154e-01
    z[8,3,3]  R1248     -4.3479744344949722e-02
    z[8,3,3]  R1249     2.2622174024581909e-01
    z[8,3,3]  R1250     -2.4902520701289177e-02
    z[8,3,3]  R1251     2.5310555100440979e-01
    z[8,3,3]  R1252     3.1763198971748352e-01
    z[8,3,3]  R1253     1.9800575077533722e-01
    z[8,3,3]  R1254     -2.8173295781016350e-02
    z[8,3,3]  R1255     2.2794772684574127e-01
    z[8,3,3]  R1256     -0.0826336070895195
    z[8,3,3]  R1257     4.6799725294113159e-01
    z[8,3,3]  R1258     -2.6709496974945068e-01
    z[8,3,3]  R1259     0.503420889377594
    z[8,3,3]  R1260     -4.7182232141494751e-02
    z[8,3,3]  R1261     -3.2185006886720657e-02
    z[8,3,3]  R1262     1.1630264669656754e-01
    z[8,3,3]  R1263     3.4428283572196960e-02
    z[8,3,3]  R1264     -0.00514657236635685
    z[8,3,3]  R1265     8.9136496186256409e-02
    z[8,3,3]  R1266     -3.6063587665557861e-01
    z[8,3,3]  R1267     -0.081561379134655
    z[8,3,3]  R1268     8.1481322646141052e-02
    z[8,3,3]  R1269     1.2045668065547943e-01
    z[8,3,3]  R1270     3.1591024994850159e-01
    z[8,3,3]  R1271     -7.1248807013034821e-02
    z[8,3,3]  R1272     -1.9285000860691071e-02
    z[8,3,3]  R1273     -1.8393030762672424e-01
    z[8,3,3]  R1274     -1.1943616718053818e-01
    z[8,3,3]  R1275     -3.4615222364664078e-02
    z[8,3,3]  R1276     0.208840012550354
    z[8,3,3]  R1277     -2.3434206843376160e-01
    z[8,3,3]  R1278     -3.7884226441383362e-01
    z[8,3,3]  R1279     -4.3607643246650696e-01
    z[8,3,3]  R1280     1.5645003318786621e-01
    z[8,3,3]  R1281     4.4591864943504333e-01
    z[8,3,3]  R1282     -5.6606572866439819e-01
    z[8,3,3]  R1283     -6.4688396453857422e-01
    z[8,3,3]  R1284     -6.5649574995040894e-01
    z[8,3,4]  R33       1
    z[8,3,4]  R78       -1
    z[8,3,4]  R1189     -1
    z[8,3,4]  R1190     1
    z[8,3,4]  R1195     -1.6608202457427979e-01
    z[8,3,4]  R1196     1.4930222928524017e-01
    z[8,3,4]  R1197     1.0916792601346970e-01
    z[8,3,4]  R1198     1.6858358681201935e-01
    z[8,3,4]  R1199     1.7198072746396065e-02
    z[8,3,4]  R1200     -3.4115172922611237e-02
    z[8,3,4]  R1201     -1.9708819687366486e-02
    z[8,3,4]  R1202     1.2298287451267242e-01
    z[8,3,4]  R1203     -0.27997025847435
    z[8,3,4]  R1204     -1.6390171647071838e-01
    z[8,3,4]  R1205     -1.8132030963897705e-01
    z[8,3,4]  R1206     1.9520732760429382e-01
    z[8,3,4]  R1207     -1.9591921567916870e-01
    z[8,3,4]  R1208     -3.0801620334386826e-02
    z[8,3,4]  R1209     -6.9214117527008057e-01
    z[8,3,4]  R1210     -2.2359889745712280e-01
    z[8,3,4]  R1211     2.5557526946067810e-01
    z[8,3,4]  R1212     -2.2692269086837769e-01
    z[8,3,4]  R1213     3.4116649627685547e-01
    z[8,3,4]  R1214     2.1558435261249542e-01
    z[8,3,4]  R1215     9.2774204909801483e-02
    z[8,3,4]  R1216     -8.5824113339185715e-03
    z[8,3,4]  R1217     8.9389160275459290e-02
    z[8,3,4]  R1218     1.5136560425162315e-02
    z[8,3,4]  R1219     7.6929312199354172e-03
    z[8,3,4]  R1220     -0.0321052223443985
    z[8,3,4]  R1221     -7.9387754201889038e-02
    z[8,3,4]  R1222     -1.2461936473846436e-01
    z[8,3,4]  R1223     -1.1244063824415207e-01
    z[8,3,4]  R1224     7.1235232055187225e-02
    z[8,3,4]  R1225     3.2721456140279770e-02
    z[8,3,4]  R1226     2.3946096003055573e-01
    z[8,3,4]  R1227     3.6254864931106567e-01
    z[8,3,4]  R1228     -3.1196763738989830e-02
    z[8,3,4]  R1229     4.7189682722091675e-02
    z[8,3,4]  R1230     -4.9045007675886154e-02
    z[8,3,4]  R1231     2.2894616425037384e-01
    z[8,3,4]  R1232     2.1908958256244659e-01
    z[8,3,4]  R1233     1.0117696970701218e-01
    z[8,3,4]  R1234     3.4478890895843506e-01
    z[8,3,4]  R1235     5.3812485933303833e-01
    z[8,3,4]  R1236     2.0495966076850891e-01
    z[8,3,4]  R1237     -1.7710077762603760e-01
    z[8,3,4]  R1238     4.3691709637641907e-01
    z[8,3,4]  R1239     -9.8659023642539978e-03
    z[8,3,4]  R1240     6.8453907966613770e-02
    z[8,3,4]  R1241     1.5254114568233490e-01
    z[8,3,4]  R1242     -3.0586105585098267e-01
    z[8,3,4]  R1243     -2.0717906951904297e-01
    z[8,3,4]  R1244     -8.4953360259532928e-02
    z[8,3,4]  R1245     -1.7499543726444244e-01
    z[8,3,4]  R1246     -9.3153864145278931e-02
    z[8,3,4]  R1247     -4.2097586393356323e-01
    z[8,3,4]  R1248     -8.7057955563068390e-02
    z[8,3,4]  R1249     1.9317786395549774e-01
    z[8,3,4]  R1250     9.1338835656642914e-02
    z[8,3,4]  R1251     3.4952649474143982e-01
    z[8,3,4]  R1252     1.7258162796497345e-01
    z[8,3,4]  R1253     2.2579045966267586e-02
    z[8,3,4]  R1254     -4.4032309204339981e-02
    z[8,3,4]  R1255     8.7571300566196442e-02
    z[8,3,4]  R1256     1.6282857954502106e-01
    z[8,3,4]  R1257     -2.4272072315216064e-01
    z[8,3,4]  R1258     2.6515156030654907e-01
    z[8,3,4]  R1259     -2.6562556624412537e-01
    z[8,3,4]  R1260     -5.7785177230834961e-01
    z[8,3,4]  R1261     -1.6454145312309265e-01
    z[8,3,4]  R1262     -0.111277274787426
    z[8,3,4]  R1263     -3.0620154738426208e-01
    z[8,3,4]  R1264     -7.2088211774826050e-01
    z[8,3,4]  R1265     1.2066298164427280e-02
    z[8,3,4]  R1266     2.4230834096670151e-02
    z[8,3,4]  R1267     0.0743400976061821
    z[8,3,4]  R1268     1.9495931267738342e-01
    z[8,3,4]  R1269     -5.6943674571812153e-03
    z[8,3,4]  R1270     2.3302891850471497e-01
    z[8,3,4]  R1271     -1.9806885719299316e-01
    z[8,3,4]  R1272     1.6575929522514343e-01
    z[8,3,4]  R1273     -2.6363892480731010e-02
    z[8,3,4]  R1274     -3.8546428084373474e-01
    z[8,3,4]  R1275     1.8515472114086151e-01
    z[8,3,4]  R1276     -4.6308046579360962e-01
    z[8,3,4]  R1277     1.9928932189941406e-01
    z[8,3,4]  R1278     3.5109764337539673e-01
    z[8,3,4]  R1279     -7.7538110315799713e-02
    z[8,3,4]  R1280     5.2223944664001465e-01
    z[8,3,4]  R1281     -2.9867190122604370e-01
    z[8,3,4]  R1282     -2.8627860546112061e-01
    z[8,3,4]  R1283     -9.1373048722743988e-02
    z[8,3,4]  R1284     5.1102095842361450e-01
    z[8,3,5]  R34       1
    z[8,3,5]  R79       -1
    z[8,3,5]  R1191     -1
    z[8,3,5]  R1192     1
    z[8,3,5]  R1195     3.7518101930618286e-01
    z[8,3,5]  R1196     -6.0493446653708816e-04
    z[8,3,5]  R1197     2.2294235229492188e-01
    z[8,3,5]  R1198     2.8060016036033630e-01
    z[8,3,5]  R1199     2.0822128653526306e-01
    z[8,3,5]  R1200     2.6795136928558350e-01
    z[8,3,5]  R1201     2.4268044531345367e-01
    z[8,3,5]  R1202     -1.2292737513780594e-01
    z[8,3,5]  R1203     0.171631321310997
    z[8,3,5]  R1204     -1.7719285190105438e-01
    z[8,3,5]  R1205     -4.6486237645149231e-01
    z[8,3,5]  R1206     -2.3795351386070251e-01
    z[8,3,5]  R1207     1.5455009043216705e-01
    z[8,3,5]  R1208     -5.0613671541213989e-01
    z[8,3,5]  R1209     2.0881672203540802e-01
    z[8,3,5]  R1210     -3.0684599280357361e-01
    z[8,3,5]  R1211     -6.2262868881225586e-01
    z[8,3,5]  R1212     2.8113192319869995e-01
    z[8,3,5]  R1213     1.2872710824012756e-01
    z[8,3,5]  R1214     -1.3126474618911743e-01
    z[8,3,5]  R1215     5.3936883807182312e-02
    z[8,3,5]  R1216     -2.0388758182525635e-01
    z[8,3,5]  R1217     -2.4250808358192444e-01
    z[8,3,5]  R1218     -1.6675812005996704e-01
    z[8,3,5]  R1219     -1.8792568147182465e-01
    z[8,3,5]  R1220     2.3786008358001709e-01
    z[8,3,5]  R1221     1.3416735827922821e-01
    z[8,3,5]  R1222     2.9073727130889893e-01
    z[8,3,5]  R1223     -7.5451299548149109e-02
    z[8,3,5]  R1224     -1.6008451581001282e-01
    z[8,3,5]  R1225     2.8374210000038147e-01
    z[8,3,5]  R1226     -9.4341598451137543e-02
    z[8,3,5]  R1227     -3.8035833835601807e-01
    z[8,3,5]  R1228     4.5989226549863815e-02
    z[8,3,5]  R1229     1.1464400589466095e-01
    z[8,3,5]  R1230     -1.8688382208347321e-01
    z[8,3,5]  R1231     -1.3190971314907074e-01
    z[8,3,5]  R1232     -3.4474423527717590e-01
    z[8,3,5]  R1233     -5.5179882049560547e-01
    z[8,3,5]  R1234     -4.4205829501152039e-01
    z[8,3,5]  R1235     4.1795790195465088e-01
    z[8,3,5]  R1236     5.2266085147857666e-01
    z[8,3,5]  R1237     -3.5278671421110630e-03
    z[8,3,5]  R1238     -1.4266875386238098e-01
    z[8,3,5]  R1239     -4.2489495873451233e-01
    z[8,3,5]  R1240     -1.4343149960041046e-01
    z[8,3,5]  R1241     -2.5397273898124695e-01
    z[8,3,5]  R1242     -1.2654094398021698e-01
    z[8,3,5]  R1243     -1.2960636615753174e-01
    z[8,3,5]  R1244     2.9142990708351135e-01
    z[8,3,5]  R1245     3.9365947246551514e-01
    z[8,3,5]  R1246     1.8414977192878723e-01
    z[8,3,5]  R1247     1.3328801095485687e-01
    z[8,3,5]  R1248     2.4706198275089264e-01
    z[8,3,5]  R1249     4.0213245153427124e-01
    z[8,3,5]  R1250     2.3150397837162018e-01
    z[8,3,5]  R1251     5.8123461902141571e-02
    z[8,3,5]  R1252     -1.1589889228343964e-01
    z[8,3,5]  R1253     -2.0197346806526184e-01
    z[8,3,5]  R1254     -3.0134108662605286e-01
    z[8,3,5]  R1255     -4.1382014751434326e-01
    z[8,3,5]  R1256     -1.6606800258159637e-01
    z[8,3,5]  R1257     0.132082000374794
    z[8,3,5]  R1258     -1.0103802382946014e-01
    z[8,3,5]  R1259     -5.1464891433715820e-01
    z[8,3,5]  R1260     -3.7848666310310364e-01
    z[8,3,5]  R1261     1.1804620176553726e-01
    z[8,3,5]  R1262     2.5822449475526810e-02
    z[8,3,5]  R1263     2.5962832570075989e-01
    z[8,3,5]  R1264     -3.1875947117805481e-01
    z[8,3,5]  R1265     -5.5032365024089813e-02
    z[8,3,5]  R1266     -6.8893593549728394e-01
    z[8,3,5]  R1267     1.0112300515174866e-01
    z[8,3,5]  R1268     8.0109424889087677e-02
    z[8,3,5]  R1269     2.6628252863883972e-01
    z[8,3,5]  R1270     2.9066300392150879e-01
    z[8,3,5]  R1271     2.5254175066947937e-01
    z[8,3,5]  R1272     3.9021271467208862e-01
    z[8,3,5]  R1273     1.5079198777675629e-01
    z[8,3,5]  R1274     1.1973618716001511e-01
    z[8,3,5]  R1275     -3.1197625398635864e-01
    z[8,3,5]  R1276     -8.2270748913288116e-02
    z[8,3,5]  R1277     -3.3672001957893372e-01
    z[8,3,5]  R1278     -2.1148182451725006e-01
    z[8,3,5]  R1279     -3.8456863164901733e-01
    z[8,3,5]  R1280     0.0923554003238678
    z[8,3,5]  R1281     5.3185307979583740e-01
    z[8,3,5]  R1282     -3.5393461585044861e-01
    z[8,3,5]  R1283     -1.6921687126159668e-01
    z[8,3,5]  R1284     -2.2447425127029419e-01
    z[8,3,6]  R35       1
    z[8,3,6]  R80       -1
    z[8,3,6]  R1193     -1
    z[8,3,6]  R1194     1
    z[8,3,6]  R1195     -9.4628900289535522e-02
    z[8,3,6]  R1196     -8.2821592688560486e-02
    z[8,3,6]  R1197     -3.6194634437561035e-01
    z[8,3,6]  R1198     -1.9311843439936638e-02
    z[8,3,6]  R1199     -2.0924621820449829e-01
    z[8,3,6]  R1200     8.3675451576709747e-02
    z[8,3,6]  R1201     -1.1608625948429108e-01
    z[8,3,6]  R1202     1.6750479117035866e-02
    z[8,3,6]  R1203     -3.5390508174896240e-01
    z[8,3,6]  R1204     2.8072218410670757e-03
    z[8,3,6]  R1205     0.0628654882311821
    z[8,3,6]  R1206     -4.6374088525772095e-01
    z[8,3,6]  R1207     -2.2481869161128998e-01
    z[8,3,6]  R1208     -1.9075348973274231e-01
    z[8,3,6]  R1209     -9.0090613812208176e-03
    z[8,3,6]  R1210     1.7228309810161591e-01
    z[8,3,6]  R1211     3.2534804940223694e-01
    z[8,3,6]  R1212     4.2964923381805420e-01
    z[8,3,6]  R1213     2.0622503757476807e-01
    z[8,3,6]  R1214     4.6970045566558838e-01
    z[8,3,6]  R1215     0.0920991376042366
    z[8,3,6]  R1216     3.9331771433353424e-02
    z[8,3,6]  R1217     1.0742158442735672e-01
    z[8,3,6]  R1218     1.1864091455936432e-01
    z[8,3,6]  R1219     1.3005739450454712e-01
    z[8,3,6]  R1220     -7.7928858809173107e-03
    z[8,3,6]  R1221     -3.4613016992807388e-02
    z[8,3,6]  R1222     2.5950780138373375e-02
    z[8,3,6]  R1223     3.1248387694358826e-01
    z[8,3,6]  R1224     3.6323550343513489e-01
    z[8,3,6]  R1225     2.7429863810539246e-01
    z[8,3,6]  R1226     -1.4621193706989288e-01
    z[8,3,6]  R1227     -1.0429130494594574e-01
    z[8,3,6]  R1228     -2.7589586377143860e-01
    z[8,3,6]  R1229     -2.4740052223205566e-01
    z[8,3,6]  R1230     -3.1327673792839050e-01
    z[8,3,6]  R1231     -3.3595946431159973e-01
    z[8,3,6]  R1232     -2.8496238589286804e-01
    z[8,3,6]  R1233     -3.0465468764305115e-01
    z[8,3,6]  R1234     -1.9501791894435883e-01
    z[8,3,6]  R1235     5.0175851583480835e-01
    z[8,3,6]  R1236     8.3230612799525261e-03
    z[8,3,6]  R1237     2.8687119483947754e-01
    z[8,3,6]  R1238     7.6511144638061523e-02
    z[8,3,6]  R1239     -1.5091150999069214e-01
    z[8,3,6]  R1240     -2.0095384120941162e-01
    z[8,3,6]  R1241     -2.7648857235908508e-01
    z[8,3,6]  R1242     -3.3896368741989136e-01
    z[8,3,6]  R1243     -2.6503643393516541e-01
    z[8,3,6]  R1244     -1.2459450960159302e-01
    z[8,3,6]  R1245     1.8048782646656036e-01
    z[8,3,6]  R1246     -1.2364926747977734e-02
    z[8,3,6]  R1247     -1.5485283732414246e-01
    z[8,3,6]  R1248     -3.8015130162239075e-01
    z[8,3,6]  R1249     -2.1169923245906830e-01
    z[8,3,6]  R1250     -3.5489144921302795e-01
    z[8,3,6]  R1251     -2.0372769236564636e-01
    z[8,3,6]  R1252     3.0969858169555664e-01
    z[8,3,6]  R1253     -2.4845942854881287e-01
    z[8,3,6]  R1254     9.4537958502769470e-02
    z[8,3,6]  R1255     -1.2200947850942612e-01
    z[8,3,6]  R1256     4.2418986558914185e-01
    z[8,3,6]  R1257     -0.426483690738678
    z[8,3,6]  R1258     -1.8254956230521202e-02
    z[8,3,6]  R1259     2.0143781602382660e-01
    z[8,3,6]  R1260     4.6744823455810547e-01
    z[8,3,6]  R1261     -1.4372245967388153e-01
    z[8,3,6]  R1262     3.5217520594596863e-01
    z[8,3,6]  R1263     -4.5647022128105164e-01
    z[8,3,6]  R1264     1.8208703398704529e-01
    z[8,3,6]  R1265     -0.01593635417521
    z[8,3,6]  R1266     -3.2406035065650940e-01
    z[8,3,6]  R1267     1.6168814897537231e-01
    z[8,3,6]  R1268     -5.0659310072660446e-02
    z[8,3,6]  R1269     2.4650168418884277e-01
    z[8,3,6]  R1270     2.1313808392733335e-03
    z[8,3,6]  R1271     -2.6850234717130661e-02
    z[8,3,6]  R1272     1.1009088903665543e-01
    z[8,3,6]  R1273     3.6808228492736816e-01
    z[8,3,6]  R1274     1.2661641836166382e-01
    z[8,3,6]  R1275     -5.5408710241317749e-01
    z[8,3,6]  R1276     -5.0046551227569580e-01
    z[8,3,6]  R1277     -2.6688572764396667e-01
    z[8,3,6]  R1278     -1.3869464397430420e-02
    z[8,3,6]  R1279     1.4463216066360474e-01
    z[8,3,6]  R1280     -5.4464846849441528e-01
    z[8,3,6]  R1281     2.7732202783226967e-02
    z[8,3,6]  R1282     1.2828026711940765e-01
    z[8,3,6]  R1283     -3.6480379104614258e-01
    z[8,3,6]  R1284     2.2492859512567520e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1339     -1
    z[4,5,0]  R1340     1
    z[4,5,0]  R1353     2.6317232847213745e-01
    z[4,5,0]  R1354     -5.6546837091445923e-01
    z[4,5,0]  R1355     -6.6512620449066162e-01
    z[4,5,0]  R1356     -5.9499043226242065e-01
    z[4,5,0]  R1357     -4.7558397054672241e-01
    z[4,5,0]  R1358     -2.8419154882431030e-01
    z[4,5,0]  R1359     -5.2697896957397461e-01
    z[4,5,0]  R1360     -5.0199301913380623e-03
    z[4,5,0]  R1361     -2.8651875257492065e-01
    z[4,5,0]  R1362     -7.7887797355651855e-01
    z[4,5,0]  R1363     4.0775316953659058e-01
    z[4,5,0]  R1364     2.7798458933830261e-01
    z[4,5,0]  R1365     9.0594850480556488e-02
    z[4,5,0]  R1366     2.7893108129501343e-01
    z[4,5,0]  R1367     1.4825348556041718e-01
    z[4,5,0]  R1368     5.2443629503250122e-01
    z[4,5,0]  R1369     2.9940828680992126e-01
    z[4,5,0]  R1370     2.7604022622108459e-01
    z[4,5,0]  R1371     8.0869764089584351e-02
    z[4,5,0]  R1372     -1.1270183324813843e-01
    z[4,5,0]  R1373     -2.1888931095600128e-01
    z[4,5,0]  R1374     4.2094182223081589e-02
    z[4,5,0]  R1375     -7.5227484107017517e-02
    z[4,5,0]  R1376     -2.0039016008377075e-01
    z[4,5,0]  R1377     -4.2725026607513428e-01
    z[4,5,0]  R1378     -1.2496877461671829e-01
    z[4,5,0]  R1379     1.1946169286966324e-01
    z[4,5,0]  R1380     1.1976820975542068e-01
    z[4,5,0]  R1381     -1.6199196875095367e-01
    z[4,5,0]  R1382     -1.8205009400844574e-01
    z[4,5,0]  R1383     2.9029405117034912e-01
    z[4,5,0]  R1384     2.1191759407520294e-01
    z[4,5,0]  R1385     0.0979313850402832
    z[4,5,0]  R1386     3.6537414789199829e-01
    z[4,5,0]  R1387     5.7950496673583984e-01
    z[4,5,0]  R1388     -3.7165734171867371e-01
    z[4,5,0]  R1389     2.5423645973205566e-01
    z[4,5,0]  R1390     2.4872298538684845e-01
    z[4,5,0]  R1391     2.9558088630437851e-02
    z[4,5,0]  R1392     -9.4943279027938843e-01
    z[4,5,0]  R1393     -8.3394092321395874e-01
    z[4,5,0]  R1394     -7.5397741794586182e-01
    z[4,5,0]  R1395     -2.8083962202072144e-01
    z[4,5,0]  R1396     -7.7542614936828613e-01
    z[4,5,0]  R1397     -0.810214638710022
    z[4,5,0]  R1398     7.4249900877475739e-02
    z[4,5,0]  R1399     1.3378772139549255e-01
    z[4,5,0]  R1400     1.3947302103042603e-01
    z[4,5,0]  R1401     9.5370262861251831e-01
    z[4,5,0]  R1402     8.9479452371597290e-01
    z[4,5,0]  R1403     7.4716895818710327e-01
    z[4,5,0]  R1404     5.6038695573806763e-01
    z[4,5,0]  R1405     4.7246214747428894e-01
    z[4,5,0]  R1406     6.9520950317382812e-01
    z[4,5,0]  R1407     5.6997841596603394e-01
    z[4,5,0]  R1408     -3.0660793185234070e-01
    z[4,5,0]  R1409     6.0899662971496582e-01
    z[4,5,0]  R1410     0.0663609504699707
    z[4,5,0]  R1411     1.5556894242763519e-01
    z[4,5,0]  R1412     9.8015494644641876e-02
    z[4,5,0]  R1413     1.5616254508495331e-01
    z[4,5,0]  R1414     -6.1184495687484741e-01
    z[4,5,0]  R1415     5.0071090459823608e-01
    z[4,5,0]  R1416     -5.1849460601806641e-01
    z[4,5,0]  R1417     5.0254905223846436e-01
    z[4,5,0]  R1418     4.1909966617822647e-02
    z[4,5,0]  R1419     6.1971396207809448e-01
    z[4,5,0]  R1420     -4.9056360125541687e-01
    z[4,5,0]  R1421     -5.9301030635833740e-01
    z[4,5,0]  R1422     5.9655243158340454e-01
    z[4,5,0]  R1423     5.4794758558273315e-01
    z[4,5,0]  R1424     4.0061506628990173e-01
    z[4,5,0]  R1425     0.0852038785815239
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1341     -1
    z[4,5,1]  R1342     1
    z[4,5,1]  R1353     2.1415875852108002e-01
    z[4,5,1]  R1354     3.3031871914863586e-01
    z[4,5,1]  R1355     -0.579989492893219
    z[4,5,1]  R1356     -0.738753080368042
    z[4,5,1]  R1357     -7.4549549818038940e-01
    z[4,5,1]  R1358     -9.0103352069854736e-01
    z[4,5,1]  R1359     -7.6249200105667114e-01
    z[4,5,1]  R1360     2.0877319574356079e-01
    z[4,5,1]  R1361     -8.0265545845031738e-01
    z[4,5,1]  R1362     -4.4744989275932312e-01
    z[4,5,1]  R1363     6.5953671932220459e-01
    z[4,5,1]  R1364     2.9075467586517334e-01
    z[4,5,1]  R1365     5.1141297817230225e-01
    z[4,5,1]  R1366     2.3910698294639587e-01
    z[4,5,1]  R1367     2.7770560979843140e-01
    z[4,5,1]  R1368     5.9006351232528687e-01
    z[4,5,1]  R1369     5.5754226446151733e-01
    z[4,5,1]  R1370     1.9369617104530334e-01
    z[4,5,1]  R1371     1.4462156593799591e-01
    z[4,5,1]  R1372     4.5790910720825195e-01
    z[4,5,1]  R1373     8.1007617712020874e-01
    z[4,5,1]  R1374     5.4744428396224976e-01
    z[4,5,1]  R1375     4.1722071170806885e-01
    z[4,5,1]  R1376     8.8161730766296387e-01
    z[4,5,1]  R1377     6.3271081447601318e-01
    z[4,5,1]  R1378     5.9155243635177612e-01
    z[4,5,1]  R1379     4.8234167695045471e-01
    z[4,5,1]  R1380     6.7794388532638550e-01
    z[4,5,1]  R1381     5.4521161317825317e-01
    z[4,5,1]  R1382     3.8384035229682922e-01
    z[4,5,1]  R1383     0.844523549079895
    z[4,5,1]  R1384     7.4751389026641846e-01
    z[4,5,1]  R1385     4.5838546752929688e-01
    z[4,5,1]  R1386     5.1698708534240723e-01
    z[4,5,1]  R1387     -5.3574711084365845e-01
    z[4,5,1]  R1388     3.5621708631515503e-01
    z[4,5,1]  R1389     3.3393144607543945e-01
    z[4,5,1]  R1390     1.3601289689540863e-01
    z[4,5,1]  R1391     1.5801647305488586e-01
    z[4,5,1]  R1392     -2.1558862924575806e-01
    z[4,5,1]  R1393     -4.0382570028305054e-01
    z[4,5,1]  R1394     -5.0637245178222656e-01
    z[4,5,1]  R1395     2.1526904404163361e-01
    z[4,5,1]  R1396     -3.1657409667968750e-01
    z[4,5,1]  R1397     -1.1454027891159058e-01
    z[4,5,1]  R1398     5.0060570240020752e-01
    z[4,5,1]  R1399     6.2163311243057251e-01
    z[4,5,1]  R1400     6.6500949859619141e-01
    z[4,5,1]  R1401     1.9339509308338165e-01
    z[4,5,1]  R1402     2.2413589060306549e-01
    z[4,5,1]  R1403     3.4828302264213562e-01
    z[4,5,1]  R1404     6.7968463897705078e-01
    z[4,5,1]  R1405     4.7478905320167542e-01
    z[4,5,1]  R1406     2.8254491090774536e-01
    z[4,5,1]  R1407     7.2019243240356445e-01
    z[4,5,1]  R1408     6.7777782678604126e-01
    z[4,5,1]  R1409     5.9171909093856812e-01
    z[4,5,1]  R1410     7.7749079465866089e-01
    z[4,5,1]  R1411     7.2966808080673218e-01
    z[4,5,1]  R1412     3.6581516265869141e-01
    z[4,5,1]  R1413     8.4231942892074585e-01
    z[4,5,1]  R1414     5.1810473203659058e-01
    z[4,5,1]  R1415     1.9991654157638550e-01
    z[4,5,1]  R1416     2.7876409888267517e-01
    z[4,5,1]  R1417     1.5909207984805107e-02
    z[4,5,1]  R1418     4.9808838963508606e-01
    z[4,5,1]  R1419     3.9224720001220703e-01
    z[4,5,1]  R1420     4.9291603267192841e-02
    z[4,5,1]  R1421     3.7664610147476196e-01
    z[4,5,1]  R1422     -3.5159853100776672e-01
    z[4,5,1]  R1423     -3.2897260785102844e-01
    z[4,5,1]  R1424     -2.3197236657142639e-01
    z[4,5,1]  R1425     -2.7160695195198059e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1343     -1
    z[4,5,2]  R1344     1
    z[4,5,2]  R1353     6.6612499952316284e-01
    z[4,5,2]  R1354     3.2712161540985107e-01
    z[4,5,2]  R1355     0.36520916223526
    z[4,5,2]  R1356     6.0635735280811787e-03
    z[4,5,2]  R1357     3.8577702641487122e-01
    z[4,5,2]  R1358     1.3701667077839375e-02
    z[4,5,2]  R1359     -1.9621748477220535e-02
    z[4,5,2]  R1360     4.8134312033653259e-01
    z[4,5,2]  R1361     -1.3301129639148712e-01
    z[4,5,2]  R1362     2.1512357890605927e-01
    z[4,5,2]  R1363     -9.3196697533130646e-02
    z[4,5,2]  R1364     2.8650718927383423e-01
    z[4,5,2]  R1365     -1.9951665401458740e-01
    z[4,5,2]  R1366     3.5323369503021240e-01
    z[4,5,2]  R1367     -9.4967454671859741e-02
    z[4,5,2]  R1368     2.1584048867225647e-01
    z[4,5,2]  R1369     1.6235182061791420e-02
    z[4,5,2]  R1370     1.6828076541423798e-01
    z[4,5,2]  R1371     1.4500774443149567e-01
    z[4,5,2]  R1372     -2.5203108787536621e-01
    z[4,5,2]  R1373     1.9131980836391449e-01
    z[4,5,2]  R1374     -2.5324690341949463e-01
    z[4,5,2]  R1375     4.5704704523086548e-01
    z[4,5,2]  R1376     3.6697588860988617e-02
    z[4,5,2]  R1377     1.5689401328563690e-01
    z[4,5,2]  R1378     6.6139960289001465e-01
    z[4,5,2]  R1379     5.4390519857406616e-01
    z[4,5,2]  R1380     0.560393214225769
    z[4,5,2]  R1381     3.9219895005226135e-01
    z[4,5,2]  R1382     2.2104445099830627e-01
    z[4,5,2]  R1383     -1.7613707482814789e-01
    z[4,5,2]  R1384     1.2199211120605469e-01
    z[4,5,2]  R1385     3.3063071966171265e-01
    z[4,5,2]  R1386     -2.1118113398551941e-01
    z[4,5,2]  R1387     -4.3785148859024048e-01
    z[4,5,2]  R1388     0.543677568435669
    z[4,5,2]  R1389     0.0949089303612709
    z[4,5,2]  R1390     5.5399411916732788e-01
    z[4,5,2]  R1391     4.0176367759704590e-01
    z[4,5,2]  R1392     2.9772909358143806e-02
    z[4,5,2]  R1393     9.1124951839447021e-02
    z[4,5,2]  R1394     -0.378989040851593
    z[4,5,2]  R1395     -6.6550811752676964e-03
    z[4,5,2]  R1396     -4.5272448658943176e-01
    z[4,5,2]  R1397     -2.4107094109058380e-01
    z[4,5,2]  R1398     1.3548418879508972e-01
    z[4,5,2]  R1399     1.2397056818008423e-01
    z[4,5,2]  R1400     -5.4570674896240234e-01
    z[4,5,2]  R1401     -3.6240026354789734e-02
    z[4,5,2]  R1402     2.3004771769046783e-01
    z[4,5,2]  R1403     -1.5100175142288208e-01
    z[4,5,2]  R1404     3.0566141009330750e-01
    z[4,5,2]  R1405     -3.8016438484191895e-01
    z[4,5,2]  R1406     1.8540556728839874e-01
    z[4,5,2]  R1407     5.8623835444450378e-02
    z[4,5,2]  R1408     -2.0094287395477295e-01
    z[4,5,2]  R1409     3.6440202593803406e-01
    z[4,5,2]  R1410     -5.0664746761322021e-01
    z[4,5,2]  R1411     3.4543567895889282e-01
    z[4,5,2]  R1412     1.1916842311620712e-02
    z[4,5,2]  R1413     -3.1948363780975342e-01
    z[4,5,2]  R1414     -8.5224412381649017e-02
    z[4,5,2]  R1415     1.0992618650197983e-01
    z[4,5,2]  R1416     -3.2113745808601379e-01
    z[4,5,2]  R1417     5.8931398391723633e-01
    z[4,5,2]  R1418     1.3008764386177063e-01
    z[4,5,2]  R1419     2.3867875337600708e-01
    z[4,5,2]  R1420     -3.0248191952705383e-01
    z[4,5,2]  R1421     -2.2429986298084259e-01
    z[4,5,2]  R1422     1.7193353176116943e-01
    z[4,5,2]  R1423     2.6403996348381042e-01
    z[4,5,2]  R1424     -4.3028593063354492e-01
    z[4,5,2]  R1425     -1.4504867792129517e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1345     -1
    z[4,5,3]  R1346     1
    z[4,5,3]  R1353     6.1507642269134521e-01
    z[4,5,3]  R1354     4.4686588644981384e-01
    z[4,5,3]  R1355     2.5985551998019218e-02
    z[4,5,3]  R1356     0.0774635300040245
    z[4,5,3]  R1357     1.2837946414947510e-01
    z[4,5,3]  R1358     1.4763016998767853e-01
    z[4,5,3]  R1359     -1.1432129889726639e-01
    z[4,5,3]  R1360     4.8429793119430542e-01
    z[4,5,3]  R1361     2.5366386771202087e-01
    z[4,5,3]  R1362     -3.6661627888679504e-01
    z[4,5,3]  R1363     -0.264119416475296
    z[4,5,3]  R1364     -2.6760128140449524e-01
    z[4,5,3]  R1365     -1.6713038086891174e-01
    z[4,5,3]  R1366     -7.0014017820358276e-01
    z[4,5,3]  R1367     -7.4978643655776978e-01
    z[4,5,3]  R1368     -3.5778027772903442e-01
    z[4,5,3]  R1369     -4.2110189795494080e-01
    z[4,5,3]  R1370     -6.3382244110107422e-01
    z[4,5,3]  R1371     -4.4403409957885742e-01
    z[4,5,3]  R1372     -3.7899157404899597e-01
    z[4,5,3]  R1373     -1.3485260307788849e-02
    z[4,5,3]  R1374     -5.0639325380325317e-01
    z[4,5,3]  R1375     -1.9734393060207367e-01
    z[4,5,3]  R1376     -2.1550129354000092e-01
    z[4,5,3]  R1377     -5.9948104619979858e-01
    z[4,5,3]  R1378     -1.1764326132833958e-02
    z[4,5,3]  R1379     0.564063310623169
    z[4,5,3]  R1380     -1.0873633623123169e-01
    z[4,5,3]  R1381     4.2686897516250610e-01
    z[4,5,3]  R1382     -6.5339082479476929e-01
    z[4,5,3]  R1383     1.5900303423404694e-01
    z[4,5,3]  R1384     -2.5881990790367126e-02
    z[4,5,3]  R1385     -7.0459538698196411e-01
    z[4,5,3]  R1386     -3.7491348385810852e-01
    z[4,5,3]  R1387     -2.7145528793334961e-01
    z[4,5,3]  R1388     4.2069047689437866e-01
    z[4,5,3]  R1389     5.8827346563339233e-01
    z[4,5,3]  R1390     4.2392176389694214e-01
    z[4,5,3]  R1391     4.8124855756759644e-01
    z[4,5,3]  R1392     1.8951384723186493e-01
    z[4,5,3]  R1393     6.4295828342437744e-02
    z[4,5,3]  R1394     -1.0613235644996166e-02
    z[4,5,3]  R1395     3.8200652599334717e-01
    z[4,5,3]  R1396     -2.9858285188674927e-01
    z[4,5,3]  R1397     -4.1682040691375732e-01
    z[4,5,3]  R1398     2.9735782742500305e-01
    z[4,5,3]  R1399     -2.5405082106590271e-01
    z[4,5,3]  R1400     -8.2731194794178009e-02
    z[4,5,3]  R1401     4.1493650525808334e-02
    z[4,5,3]  R1402     -3.2313905656337738e-02
    z[4,5,3]  R1403     -2.1091900765895844e-01
    z[4,5,3]  R1404     2.1014882251620293e-02
    z[4,5,3]  R1405     -2.4078558385372162e-01
    z[4,5,3]  R1406     -9.9243007600307465e-02
    z[4,5,3]  R1407     -3.0275449156761169e-01
    z[4,5,3]  R1408     4.0310040116310120e-01
    z[4,5,3]  R1409     -6.5796904265880585e-02
    z[4,5,3]  R1410     1.7600330710411072e-01
    z[4,5,3]  R1411     -4.5627933740615845e-01
    z[4,5,3]  R1412     5.0871866941452026e-01
    z[4,5,3]  R1413     -1.9985513389110565e-01
    z[4,5,3]  R1414     2.2603482007980347e-01
    z[4,5,3]  R1415     1.3266973197460175e-01
    z[4,5,3]  R1416     1.1315760016441345e-01
    z[4,5,3]  R1417     5.2334928512573242e-01
    z[4,5,3]  R1418     3.9895462989807129e-01
    z[4,5,3]  R1419     3.6140042543411255e-01
    z[4,5,3]  R1420     -9.4725519418716431e-02
    z[4,5,3]  R1421     -2.4097454547882080e-01
    z[4,5,3]  R1422     -2.5678718090057373e-01
    z[4,5,3]  R1423     -2.3178162053227425e-02
    z[4,5,3]  R1424     -6.2350267171859741e-01
    z[4,5,3]  R1425     6.9501721858978271e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1347     -1
    z[4,5,4]  R1348     1
    z[4,5,4]  R1353     1.1974767595529556e-01
    z[4,5,4]  R1354     9.1862939298152924e-03
    z[4,5,4]  R1355     7.3491334915161133e-02
    z[4,5,4]  R1356     -5.8846427127718925e-03
    z[4,5,4]  R1357     -1.6747325658798218e-01
    z[4,5,4]  R1358     -1.3405182398855686e-03
    z[4,5,4]  R1359     2.5259381532669067e-01
    z[4,5,4]  R1360     -2.1315573155879974e-01
    z[4,5,4]  R1361     3.2217299938201904e-01
    z[4,5,4]  R1362     5.4563339799642563e-02
    z[4,5,4]  R1363     -1.9892422854900360e-01
    z[4,5,4]  R1364     -6.7497217655181885e-01
    z[4,5,4]  R1365     0.788306474685669
    z[4,5,4]  R1366     -4.4945013523101807e-01
    z[4,5,4]  R1367     -2.1735686063766479e-01
    z[4,5,4]  R1368     -2.3181030154228210e-01
    z[4,5,4]  R1369     5.2764439582824707e-01
    z[4,5,4]  R1370     -1.1529266089200974e-01
    z[4,5,4]  R1371     -4.5612469315528870e-01
    z[4,5,4]  R1372     2.4645689129829407e-01
    z[4,5,4]  R1373     -3.4443697333335876e-01
    z[4,5,4]  R1374     -4.1347879171371460e-01
    z[4,5,4]  R1375     -6.9526904821395874e-01
    z[4,5,4]  R1376     1.8194644153118134e-01
    z[4,5,4]  R1377     8.0386392772197723e-02
    z[4,5,4]  R1378     -3.9396342635154724e-01
    z[4,5,4]  R1379     -2.4239769577980042e-01
    z[4,5,4]  R1380     -1.4636828005313873e-01
    z[4,5,4]  R1381     2.6185914874076843e-01
    z[4,5,4]  R1382     1.6176441311836243e-01
    z[4,5,4]  R1383     1.8638296052813530e-02
    z[4,5,4]  R1384     2.1074400842189789e-01
    z[4,5,4]  R1385     -1.7241697013378143e-01
    z[4,5,4]  R1386     3.6345225572586060e-01
    z[4,5,4]  R1387     -2.9684737324714661e-01
    z[4,5,4]  R1388     -0.131282776594162
    z[4,5,4]  R1389     -2.0270679891109467e-01
    z[4,5,4]  R1390     5.0708428025245667e-02
    z[4,5,4]  R1391     4.0424704551696777e-02
    z[4,5,4]  R1392     -2.3826232179999352e-02
    z[4,5,4]  R1393     7.8646644949913025e-02
    z[4,5,4]  R1394     -1.5068666636943817e-01
    z[4,5,4]  R1395     8.6473770439624786e-02
    z[4,5,4]  R1396     1.8061840906739235e-02
    z[4,5,4]  R1397     -2.3037877678871155e-01
    z[4,5,4]  R1398     3.6236989498138428e-01
    z[4,5,4]  R1399     -3.5175427794456482e-01
    z[4,5,4]  R1400     3.7179195880889893e-01
    z[4,5,4]  R1401     9.9859438836574554e-02
    z[4,5,4]  R1402     -0.219310000538826
    z[4,5,4]  R1403     2.7160480618476868e-01
    z[4,5,4]  R1404     -0.0803123265504837
    z[4,5,4]  R1405     4.6058705449104309e-01
    z[4,5,4]  R1406     -4.9506008625030518e-01
    z[4,5,4]  R1407     7.1128294803202152e-03
    z[4,5,4]  R1408     2.3088155686855316e-01
    z[4,5,4]  R1409     -3.5117557644844055e-01
    z[4,5,4]  R1410     -6.1572656035423279e-02
    z[4,5,4]  R1411     1.6156718134880066e-01
    z[4,5,4]  R1412     0.528188169002533
    z[4,5,4]  R1413     -1.3759201765060425e-01
    z[4,5,4]  R1414     2.6156926155090332e-01
    z[4,5,4]  R1415     7.8093636035919189e-01
    z[4,5,4]  R1416     5.7497990131378174e-01
    z[4,5,4]  R1417     2.3538200557231903e-01
    z[4,5,4]  R1418     0.0971253365278244
    z[4,5,4]  R1419     4.8219704627990723e-01
    z[4,5,4]  R1420     7.6357948780059814e-01
    z[4,5,4]  R1421     0.605150580406189
    z[4,5,4]  R1422     -5.2266061305999756e-02
    z[4,5,4]  R1423     -1.5737497806549072e-01
    z[4,5,4]  R1424     -2.6336705684661865e-01
    z[4,5,4]  R1425     -2.9991421103477478e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1349     -1
    z[4,5,5]  R1350     1
    z[4,5,5]  R1353     1.9912265241146088e-01
    z[4,5,5]  R1354     4.6489837765693665e-01
    z[4,5,5]  R1355     1.7913137376308441e-01
    z[4,5,5]  R1356     1.4583170413970947e-01
    z[4,5,5]  R1357     -1.5650568902492523e-01
    z[4,5,5]  R1358     2.6274496316909790e-01
    z[4,5,5]  R1359     1.2872308492660522e-01
    z[4,5,5]  R1360     3.1005263328552246e-01
    z[4,5,5]  R1361     -2.4613271653652191e-01
    z[4,5,5]  R1362     -7.7008586376905441e-03
    z[4,5,5]  R1363     5.2982527017593384e-01
    z[4,5,5]  R1364     -4.3148615956306458e-01
    z[4,5,5]  R1365     1.3492126762866974e-01
    z[4,5,5]  R1366     -1.5359036624431610e-01
    z[4,5,5]  R1367     -4.3180957436561584e-01
    z[4,5,5]  R1368     -3.0500459671020508e-01
    z[4,5,5]  R1369     -0.306742787361145
    z[4,5,5]  R1370     -4.3126323819160461e-01
    z[4,5,5]  R1371     -2.4748770892620087e-01
    z[4,5,5]  R1372     -1.0798367857933044e-01
    z[4,5,5]  R1373     -3.5758325457572937e-01
    z[4,5,5]  R1374     -4.5182332396507263e-01
    z[4,5,5]  R1375     1.2278459221124649e-01
    z[4,5,5]  R1376     -2.3089537024497986e-01
    z[4,5,5]  R1377     -6.4779542386531830e-02
    z[4,5,5]  R1378     -1.6605409979820251e-01
    z[4,5,5]  R1379     -0.283381849527359
    z[4,5,5]  R1380     -2.8153559565544128e-01
    z[4,5,5]  R1381     -4.6473595499992371e-01
    z[4,5,5]  R1382     -5.0197279453277588e-01
    z[4,5,5]  R1383     -1.4717520773410797e-01
    z[4,5,5]  R1384     2.8738099336624146e-01
    z[4,5,5]  R1385     0.093800388276577
    z[4,5,5]  R1386     -2.8256615996360779e-01
    z[4,5,5]  R1387     0.0650511384010315
    z[4,5,5]  R1388     2.7271553874015808e-01
    z[4,5,5]  R1389     5.2691268920898438e-01
    z[4,5,5]  R1390     6.4450263977050781e-01
    z[4,5,5]  R1391     7.0472925901412964e-01
    z[4,5,5]  R1392     -9.9377147853374481e-02
    z[4,5,5]  R1393     3.4897324442863464e-01
    z[4,5,5]  R1394     2.3402487859129906e-02
    z[4,5,5]  R1395     8.3330857753753662e-01
    z[4,5,5]  R1396     3.7897545844316483e-02
    z[4,5,5]  R1397     1.3680934906005859e-01
    z[4,5,5]  R1398     -0.595125675201416
    z[4,5,5]  R1399     -1.5955404937267303e-01
    z[4,5,5]  R1400     -2.2005158662796021e-01
    z[4,5,5]  R1401     2.0205345004796982e-02
    z[4,5,5]  R1402     -8.1733748316764832e-02
    z[4,5,5]  R1403     -2.3836898803710938e-01
    z[4,5,5]  R1404     -3.5071724653244019e-01
    z[4,5,5]  R1405     2.5413361191749573e-01
    z[4,5,5]  R1406     4.1997302323579788e-02
    z[4,5,5]  R1407     -1.7531554400920868e-01
    z[4,5,5]  R1408     -2.3685748875141144e-01
    z[4,5,5]  R1409     0.0639994740486145
    z[4,5,5]  R1410     1.9936181604862213e-01
    z[4,5,5]  R1411     2.3382996022701263e-01
    z[4,5,5]  R1412     -5.0613805651664734e-02
    z[4,5,5]  R1413     -3.2176694273948669e-01
    z[4,5,5]  R1414     -3.8128022104501724e-02
    z[4,5,5]  R1415     0.258573055267334
    z[4,5,5]  R1416     -1.9886805117130280e-01
    z[4,5,5]  R1417     2.5721633434295654e-01
    z[4,5,5]  R1418     -3.9157253503799438e-01
    z[4,5,5]  R1419     -0.0499303825199604
    z[4,5,5]  R1420     -6.2995433807373047e-02
    z[4,5,5]  R1421     -1.5592688322067261e-01
    z[4,5,5]  R1422     5.3906667232513428e-01
    z[4,5,5]  R1423     6.6354691982269287e-01
    z[4,5,5]  R1424     3.5606831312179565e-01
    z[4,5,5]  R1425     -3.9531141519546509e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1351     -1
    z[4,5,6]  R1352     1
    z[4,5,6]  R1353     9.4051003456115723e-02
    z[4,5,6]  R1354     2.1959602832794189e-01
    z[4,5,6]  R1355     -2.2288376092910767e-01
    z[4,5,6]  R1356     2.6998394727706909e-01
    z[4,5,6]  R1357     1.4485952444374561e-02
    z[4,5,6]  R1358     -1.2788560986518860e-01
    z[4,5,6]  R1359     -2.1695968508720398e-01
    z[4,5,6]  R1360     5.9041076898574829e-01
    z[4,5,6]  R1361     -1.6503702104091644e-01
    z[4,5,6]  R1362     9.7034208476543427e-02
    z[4,5,6]  R1363     4.2760372161865234e-03
    z[4,5,6]  R1364     2.0669229328632355e-01
    z[4,5,6]  R1365     1.5125776827335358e-01
    z[4,5,6]  R1366     -1.5639545023441315e-01
    z[4,5,6]  R1367     3.0983600020408630e-01
    z[4,5,6]  R1368     -2.3544387519359589e-01
    z[4,5,6]  R1369     2.2228620946407318e-01
    z[4,5,6]  R1370     -5.0690621137619019e-01
    z[4,5,6]  R1371     -6.9645619392395020e-01
    z[4,5,6]  R1372     -0.70573490858078
    z[4,5,6]  R1373     -1.1214417964220047e-01
    z[4,5,6]  R1374     5.3438387811183929e-02
    z[4,5,6]  R1375     -2.7194821834564209e-01
    z[4,5,6]  R1376     2.1997734904289246e-01
    z[4,5,6]  R1377     1.4994235336780548e-01
    z[4,5,6]  R1378     1.1865685880184174e-01
    z[4,5,6]  R1379     3.6452680360525846e-03
    z[4,5,6]  R1380     -3.1543239951133728e-01
    z[4,5,6]  R1381     -2.3646588623523712e-01
    z[4,5,6]  R1382     -2.5612443685531616e-01
    z[4,5,6]  R1383     3.5241311788558960e-01
    z[4,5,6]  R1384     -5.0374704599380493e-01
    z[4,5,6]  R1385     -3.6877453327178955e-01
    z[4,5,6]  R1386     -4.4958570599555969e-01
    z[4,5,6]  R1387     1.3927395641803741e-01
    z[4,5,6]  R1388     4.1328620910644531e-01
    z[4,5,6]  R1389     3.8736695051193237e-01
    z[4,5,6]  R1390     1.2273205816745758e-01
    z[4,5,6]  R1391     -2.8786346316337585e-01
    z[4,5,6]  R1392     -6.9666884839534760e-02
    z[4,5,6]  R1393     0.0325879268348217
    z[4,5,6]  R1394     9.0030990540981293e-02
    z[4,5,6]  R1395     1.6411638259887695e-01
    z[4,5,6]  R1396     -5.1199745386838913e-02
    z[4,5,6]  R1397     1.6366812586784363e-01
    z[4,5,6]  R1398     -3.8937997817993164e-01
    z[4,5,6]  R1399     -6.0545355081558228e-01
    z[4,5,6]  R1400     2.1683479845523834e-01
    z[4,5,6]  R1401     1.9908371567726135e-01
    z[4,5,6]  R1402     -2.0090420544147491e-01
    z[4,5,6]  R1403     -3.5008609294891357e-01
    z[4,5,6]  R1404     -2.5925608351826668e-02
    z[4,5,6]  R1405     -2.6856634020805359e-01
    z[4,5,6]  R1406     3.8181087374687195e-01
    z[4,5,6]  R1407     1.7482678592205048e-01
    z[4,5,6]  R1408     3.6651477217674255e-01
    z[4,5,6]  R1409     1.2022166699171066e-01
    z[4,5,6]  R1410     -2.4474318325519562e-01
    z[4,5,6]  R1411     1.8731169402599335e-01
    z[4,5,6]  R1412     -5.6221973896026611e-01
    z[4,5,6]  R1413     4.0419686585664749e-02
    z[4,5,6]  R1414     -4.7852483391761780e-01
    z[4,5,6]  R1415     5.3995925933122635e-02
    z[4,5,6]  R1416     4.0910828113555908e-01
    z[4,5,6]  R1417     6.6640153527259827e-02
    z[4,5,6]  R1418     -6.4132785797119141e-01
    z[4,5,6]  R1419     1.9877620041370392e-01
    z[4,5,6]  R1420     -2.6349094510078430e-01
    z[4,5,6]  R1421     -0.0870453417301178
    z[4,5,6]  R1422     -3.6287501454353333e-01
    z[4,5,6]  R1423     2.3709645867347717e-01
    z[4,5,6]  R1424     1.2509196996688843e-01
    z[4,5,6]  R1425     4.1068512201309204e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1426     -1
    z[5,4,0]  R1427     1
    z[5,4,0]  R1440     -3.7165734171867371e-01
    z[5,4,0]  R1441     2.5423645973205566e-01
    z[5,4,0]  R1442     2.4872298538684845e-01
    z[5,4,0]  R1443     2.9558088630437851e-02
    z[5,4,0]  R1444     -9.4943279027938843e-01
    z[5,4,0]  R1445     -8.3394092321395874e-01
    z[5,4,0]  R1446     -7.5397741794586182e-01
    z[5,4,0]  R1447     -2.8083962202072144e-01
    z[5,4,0]  R1448     -7.7542614936828613e-01
    z[5,4,0]  R1449     -0.810214638710022
    z[5,4,0]  R1450     7.4249900877475739e-02
    z[5,4,0]  R1451     1.3378772139549255e-01
    z[5,4,0]  R1452     1.3947302103042603e-01
    z[5,4,0]  R1453     9.5370262861251831e-01
    z[5,4,0]  R1454     8.9479452371597290e-01
    z[5,4,0]  R1455     7.4716895818710327e-01
    z[5,4,0]  R1456     5.6038695573806763e-01
    z[5,4,0]  R1457     4.7246214747428894e-01
    z[5,4,0]  R1458     6.9520950317382812e-01
    z[5,4,0]  R1459     5.6997841596603394e-01
    z[5,4,0]  R1460     -3.0660793185234070e-01
    z[5,4,0]  R1461     6.0899662971496582e-01
    z[5,4,0]  R1462     0.0663609504699707
    z[5,4,0]  R1463     1.5556894242763519e-01
    z[5,4,0]  R1464     9.8015494644641876e-02
    z[5,4,0]  R1465     1.5616254508495331e-01
    z[5,4,0]  R1466     -6.1184495687484741e-01
    z[5,4,0]  R1467     5.0071090459823608e-01
    z[5,4,0]  R1468     -5.1849460601806641e-01
    z[5,4,0]  R1469     5.0254905223846436e-01
    z[5,4,0]  R1470     4.1909966617822647e-02
    z[5,4,0]  R1471     6.1971396207809448e-01
    z[5,4,0]  R1472     -4.9056360125541687e-01
    z[5,4,0]  R1473     -5.9301030635833740e-01
    z[5,4,0]  R1474     5.9655243158340454e-01
    z[5,4,0]  R1475     5.4794758558273315e-01
    z[5,4,0]  R1476     4.0061506628990173e-01
    z[5,4,0]  R1477     0.0852038785815239
    z[5,4,0]  R1478     2.6317232847213745e-01
    z[5,4,0]  R1479     -5.6546837091445923e-01
    z[5,4,0]  R1480     -6.6512620449066162e-01
    z[5,4,0]  R1481     -5.9499043226242065e-01
    z[5,4,0]  R1482     -4.7558397054672241e-01
    z[5,4,0]  R1483     -2.8419154882431030e-01
    z[5,4,0]  R1484     -5.2697896957397461e-01
    z[5,4,0]  R1485     -5.0199301913380623e-03
    z[5,4,0]  R1486     -2.8651875257492065e-01
    z[5,4,0]  R1487     -7.7887797355651855e-01
    z[5,4,0]  R1488     4.0775316953659058e-01
    z[5,4,0]  R1489     2.7798458933830261e-01
    z[5,4,0]  R1490     9.0594850480556488e-02
    z[5,4,0]  R1491     2.7893108129501343e-01
    z[5,4,0]  R1492     1.4825348556041718e-01
    z[5,4,0]  R1493     5.2443629503250122e-01
    z[5,4,0]  R1494     2.9940828680992126e-01
    z[5,4,0]  R1495     2.7604022622108459e-01
    z[5,4,0]  R1496     8.0869764089584351e-02
    z[5,4,0]  R1497     -1.1270183324813843e-01
    z[5,4,0]  R1498     -2.1888931095600128e-01
    z[5,4,0]  R1499     4.2094182223081589e-02
    z[5,4,0]  R1500     -7.5227484107017517e-02
    z[5,4,0]  R1501     -2.0039016008377075e-01
    z[5,4,0]  R1502     -4.2725026607513428e-01
    z[5,4,0]  R1503     -1.2496877461671829e-01
    z[5,4,0]  R1504     1.1946169286966324e-01
    z[5,4,0]  R1505     1.1976820975542068e-01
    z[5,4,0]  R1506     -1.6199196875095367e-01
    z[5,4,0]  R1507     -1.8205009400844574e-01
    z[5,4,0]  R1508     2.9029405117034912e-01
    z[5,4,0]  R1509     2.1191759407520294e-01
    z[5,4,0]  R1510     0.0979313850402832
    z[5,4,0]  R1511     3.6537414789199829e-01
    z[5,4,0]  R1512     5.7950496673583984e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1428     -1
    z[5,4,1]  R1429     1
    z[5,4,1]  R1440     3.5621708631515503e-01
    z[5,4,1]  R1441     3.3393144607543945e-01
    z[5,4,1]  R1442     1.3601289689540863e-01
    z[5,4,1]  R1443     1.5801647305488586e-01
    z[5,4,1]  R1444     -2.1558862924575806e-01
    z[5,4,1]  R1445     -4.0382570028305054e-01
    z[5,4,1]  R1446     -5.0637245178222656e-01
    z[5,4,1]  R1447     2.1526904404163361e-01
    z[5,4,1]  R1448     -3.1657409667968750e-01
    z[5,4,1]  R1449     -1.1454027891159058e-01
    z[5,4,1]  R1450     5.0060570240020752e-01
    z[5,4,1]  R1451     6.2163311243057251e-01
    z[5,4,1]  R1452     6.6500949859619141e-01
    z[5,4,1]  R1453     1.9339509308338165e-01
    z[5,4,1]  R1454     2.2413589060306549e-01
    z[5,4,1]  R1455     3.4828302264213562e-01
    z[5,4,1]  R1456     6.7968463897705078e-01
    z[5,4,1]  R1457     4.7478905320167542e-01
    z[5,4,1]  R1458     2.8254491090774536e-01
    z[5,4,1]  R1459     7.2019243240356445e-01
    z[5,4,1]  R1460     6.7777782678604126e-01
    z[5,4,1]  R1461     5.9171909093856812e-01
    z[5,4,1]  R1462     7.7749079465866089e-01
    z[5,4,1]  R1463     7.2966808080673218e-01
    z[5,4,1]  R1464     3.6581516265869141e-01
    z[5,4,1]  R1465     8.4231942892074585e-01
    z[5,4,1]  R1466     5.1810473203659058e-01
    z[5,4,1]  R1467     1.9991654157638550e-01
    z[5,4,1]  R1468     2.7876409888267517e-01
    z[5,4,1]  R1469     1.5909207984805107e-02
    z[5,4,1]  R1470     4.9808838963508606e-01
    z[5,4,1]  R1471     3.9224720001220703e-01
    z[5,4,1]  R1472     4.9291603267192841e-02
    z[5,4,1]  R1473     3.7664610147476196e-01
    z[5,4,1]  R1474     -3.5159853100776672e-01
    z[5,4,1]  R1475     -3.2897260785102844e-01
    z[5,4,1]  R1476     -2.3197236657142639e-01
    z[5,4,1]  R1477     -2.7160695195198059e-01
    z[5,4,1]  R1478     2.1415875852108002e-01
    z[5,4,1]  R1479     3.3031871914863586e-01
    z[5,4,1]  R1480     -0.579989492893219
    z[5,4,1]  R1481     -0.738753080368042
    z[5,4,1]  R1482     -7.4549549818038940e-01
    z[5,4,1]  R1483     -9.0103352069854736e-01
    z[5,4,1]  R1484     -7.6249200105667114e-01
    z[5,4,1]  R1485     2.0877319574356079e-01
    z[5,4,1]  R1486     -8.0265545845031738e-01
    z[5,4,1]  R1487     -4.4744989275932312e-01
    z[5,4,1]  R1488     6.5953671932220459e-01
    z[5,4,1]  R1489     2.9075467586517334e-01
    z[5,4,1]  R1490     5.1141297817230225e-01
    z[5,4,1]  R1491     2.3910698294639587e-01
    z[5,4,1]  R1492     2.7770560979843140e-01
    z[5,4,1]  R1493     5.9006351232528687e-01
    z[5,4,1]  R1494     5.5754226446151733e-01
    z[5,4,1]  R1495     1.9369617104530334e-01
    z[5,4,1]  R1496     1.4462156593799591e-01
    z[5,4,1]  R1497     4.5790910720825195e-01
    z[5,4,1]  R1498     8.1007617712020874e-01
    z[5,4,1]  R1499     5.4744428396224976e-01
    z[5,4,1]  R1500     4.1722071170806885e-01
    z[5,4,1]  R1501     8.8161730766296387e-01
    z[5,4,1]  R1502     6.3271081447601318e-01
    z[5,4,1]  R1503     5.9155243635177612e-01
    z[5,4,1]  R1504     4.8234167695045471e-01
    z[5,4,1]  R1505     6.7794388532638550e-01
    z[5,4,1]  R1506     5.4521161317825317e-01
    z[5,4,1]  R1507     3.8384035229682922e-01
    z[5,4,1]  R1508     0.844523549079895
    z[5,4,1]  R1509     7.4751389026641846e-01
    z[5,4,1]  R1510     4.5838546752929688e-01
    z[5,4,1]  R1511     5.1698708534240723e-01
    z[5,4,1]  R1512     -5.3574711084365845e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1430     -1
    z[5,4,2]  R1431     1
    z[5,4,2]  R1440     0.543677568435669
    z[5,4,2]  R1441     0.0949089303612709
    z[5,4,2]  R1442     5.5399411916732788e-01
    z[5,4,2]  R1443     4.0176367759704590e-01
    z[5,4,2]  R1444     2.9772909358143806e-02
    z[5,4,2]  R1445     9.1124951839447021e-02
    z[5,4,2]  R1446     -0.378989040851593
    z[5,4,2]  R1447     -6.6550811752676964e-03
    z[5,4,2]  R1448     -4.5272448658943176e-01
    z[5,4,2]  R1449     -2.4107094109058380e-01
    z[5,4,2]  R1450     1.3548418879508972e-01
    z[5,4,2]  R1451     1.2397056818008423e-01
    z[5,4,2]  R1452     -5.4570674896240234e-01
    z[5,4,2]  R1453     -3.6240026354789734e-02
    z[5,4,2]  R1454     2.3004771769046783e-01
    z[5,4,2]  R1455     -1.5100175142288208e-01
    z[5,4,2]  R1456     3.0566141009330750e-01
    z[5,4,2]  R1457     -3.8016438484191895e-01
    z[5,4,2]  R1458     1.8540556728839874e-01
    z[5,4,2]  R1459     5.8623835444450378e-02
    z[5,4,2]  R1460     -2.0094287395477295e-01
    z[5,4,2]  R1461     3.6440202593803406e-01
    z[5,4,2]  R1462     -5.0664746761322021e-01
    z[5,4,2]  R1463     3.4543567895889282e-01
    z[5,4,2]  R1464     1.1916842311620712e-02
    z[5,4,2]  R1465     -3.1948363780975342e-01
    z[5,4,2]  R1466     -8.5224412381649017e-02
    z[5,4,2]  R1467     1.0992618650197983e-01
    z[5,4,2]  R1468     -3.2113745808601379e-01
    z[5,4,2]  R1469     5.8931398391723633e-01
    z[5,4,2]  R1470     1.3008764386177063e-01
    z[5,4,2]  R1471     2.3867875337600708e-01
    z[5,4,2]  R1472     -3.0248191952705383e-01
    z[5,4,2]  R1473     -2.2429986298084259e-01
    z[5,4,2]  R1474     1.7193353176116943e-01
    z[5,4,2]  R1475     2.6403996348381042e-01
    z[5,4,2]  R1476     -4.3028593063354492e-01
    z[5,4,2]  R1477     -1.4504867792129517e-01
    z[5,4,2]  R1478     6.6612499952316284e-01
    z[5,4,2]  R1479     3.2712161540985107e-01
    z[5,4,2]  R1480     0.36520916223526
    z[5,4,2]  R1481     6.0635735280811787e-03
    z[5,4,2]  R1482     3.8577702641487122e-01
    z[5,4,2]  R1483     1.3701667077839375e-02
    z[5,4,2]  R1484     -1.9621748477220535e-02
    z[5,4,2]  R1485     4.8134312033653259e-01
    z[5,4,2]  R1486     -1.3301129639148712e-01
    z[5,4,2]  R1487     2.1512357890605927e-01
    z[5,4,2]  R1488     -9.3196697533130646e-02
    z[5,4,2]  R1489     2.8650718927383423e-01
    z[5,4,2]  R1490     -1.9951665401458740e-01
    z[5,4,2]  R1491     3.5323369503021240e-01
    z[5,4,2]  R1492     -9.4967454671859741e-02
    z[5,4,2]  R1493     2.1584048867225647e-01
    z[5,4,2]  R1494     1.6235182061791420e-02
    z[5,4,2]  R1495     1.6828076541423798e-01
    z[5,4,2]  R1496     1.4500774443149567e-01
    z[5,4,2]  R1497     -2.5203108787536621e-01
    z[5,4,2]  R1498     1.9131980836391449e-01
    z[5,4,2]  R1499     -2.5324690341949463e-01
    z[5,4,2]  R1500     4.5704704523086548e-01
    z[5,4,2]  R1501     3.6697588860988617e-02
    z[5,4,2]  R1502     1.5689401328563690e-01
    z[5,4,2]  R1503     6.6139960289001465e-01
    z[5,4,2]  R1504     5.4390519857406616e-01
    z[5,4,2]  R1505     0.560393214225769
    z[5,4,2]  R1506     3.9219895005226135e-01
    z[5,4,2]  R1507     2.2104445099830627e-01
    z[5,4,2]  R1508     -1.7613707482814789e-01
    z[5,4,2]  R1509     1.2199211120605469e-01
    z[5,4,2]  R1510     3.3063071966171265e-01
    z[5,4,2]  R1511     -2.1118113398551941e-01
    z[5,4,2]  R1512     -4.3785148859024048e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1432     -1
    z[5,4,3]  R1433     1
    z[5,4,3]  R1440     4.2069047689437866e-01
    z[5,4,3]  R1441     5.8827346563339233e-01
    z[5,4,3]  R1442     4.2392176389694214e-01
    z[5,4,3]  R1443     4.8124855756759644e-01
    z[5,4,3]  R1444     1.8951384723186493e-01
    z[5,4,3]  R1445     6.4295828342437744e-02
    z[5,4,3]  R1446     -1.0613235644996166e-02
    z[5,4,3]  R1447     3.8200652599334717e-01
    z[5,4,3]  R1448     -2.9858285188674927e-01
    z[5,4,3]  R1449     -4.1682040691375732e-01
    z[5,4,3]  R1450     2.9735782742500305e-01
    z[5,4,3]  R1451     -2.5405082106590271e-01
    z[5,4,3]  R1452     -8.2731194794178009e-02
    z[5,4,3]  R1453     4.1493650525808334e-02
    z[5,4,3]  R1454     -3.2313905656337738e-02
    z[5,4,3]  R1455     -2.1091900765895844e-01
    z[5,4,3]  R1456     2.1014882251620293e-02
    z[5,4,3]  R1457     -2.4078558385372162e-01
    z[5,4,3]  R1458     -9.9243007600307465e-02
    z[5,4,3]  R1459     -3.0275449156761169e-01
    z[5,4,3]  R1460     4.0310040116310120e-01
    z[5,4,3]  R1461     -6.5796904265880585e-02
    z[5,4,3]  R1462     1.7600330710411072e-01
    z[5,4,3]  R1463     -4.5627933740615845e-01
    z[5,4,3]  R1464     5.0871866941452026e-01
    z[5,4,3]  R1465     -1.9985513389110565e-01
    z[5,4,3]  R1466     2.2603482007980347e-01
    z[5,4,3]  R1467     1.3266973197460175e-01
    z[5,4,3]  R1468     1.1315760016441345e-01
    z[5,4,3]  R1469     5.2334928512573242e-01
    z[5,4,3]  R1470     3.9895462989807129e-01
    z[5,4,3]  R1471     3.6140042543411255e-01
    z[5,4,3]  R1472     -9.4725519418716431e-02
    z[5,4,3]  R1473     -2.4097454547882080e-01
    z[5,4,3]  R1474     -2.5678718090057373e-01
    z[5,4,3]  R1475     -2.3178162053227425e-02
    z[5,4,3]  R1476     -6.2350267171859741e-01
    z[5,4,3]  R1477     6.9501721858978271e-01
    z[5,4,3]  R1478     6.1507642269134521e-01
    z[5,4,3]  R1479     4.4686588644981384e-01
    z[5,4,3]  R1480     2.5985551998019218e-02
    z[5,4,3]  R1481     0.0774635300040245
    z[5,4,3]  R1482     1.2837946414947510e-01
    z[5,4,3]  R1483     1.4763016998767853e-01
    z[5,4,3]  R1484     -1.1432129889726639e-01
    z[5,4,3]  R1485     4.8429793119430542e-01
    z[5,4,3]  R1486     2.5366386771202087e-01
    z[5,4,3]  R1487     -3.6661627888679504e-01
    z[5,4,3]  R1488     -0.264119416475296
    z[5,4,3]  R1489     -2.6760128140449524e-01
    z[5,4,3]  R1490     -1.6713038086891174e-01
    z[5,4,3]  R1491     -7.0014017820358276e-01
    z[5,4,3]  R1492     -7.4978643655776978e-01
    z[5,4,3]  R1493     -3.5778027772903442e-01
    z[5,4,3]  R1494     -4.2110189795494080e-01
    z[5,4,3]  R1495     -6.3382244110107422e-01
    z[5,4,3]  R1496     -4.4403409957885742e-01
    z[5,4,3]  R1497     -3.7899157404899597e-01
    z[5,4,3]  R1498     -1.3485260307788849e-02
    z[5,4,3]  R1499     -5.0639325380325317e-01
    z[5,4,3]  R1500     -1.9734393060207367e-01
    z[5,4,3]  R1501     -2.1550129354000092e-01
    z[5,4,3]  R1502     -5.9948104619979858e-01
    z[5,4,3]  R1503     -1.1764326132833958e-02
    z[5,4,3]  R1504     0.564063310623169
    z[5,4,3]  R1505     -1.0873633623123169e-01
    z[5,4,3]  R1506     4.2686897516250610e-01
    z[5,4,3]  R1507     -6.5339082479476929e-01
    z[5,4,3]  R1508     1.5900303423404694e-01
    z[5,4,3]  R1509     -2.5881990790367126e-02
    z[5,4,3]  R1510     -7.0459538698196411e-01
    z[5,4,3]  R1511     -3.7491348385810852e-01
    z[5,4,3]  R1512     -2.7145528793334961e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1434     -1
    z[5,4,4]  R1435     1
    z[5,4,4]  R1440     -0.131282776594162
    z[5,4,4]  R1441     -2.0270679891109467e-01
    z[5,4,4]  R1442     5.0708428025245667e-02
    z[5,4,4]  R1443     4.0424704551696777e-02
    z[5,4,4]  R1444     -2.3826232179999352e-02
    z[5,4,4]  R1445     7.8646644949913025e-02
    z[5,4,4]  R1446     -1.5068666636943817e-01
    z[5,4,4]  R1447     8.6473770439624786e-02
    z[5,4,4]  R1448     1.8061840906739235e-02
    z[5,4,4]  R1449     -2.3037877678871155e-01
    z[5,4,4]  R1450     3.6236989498138428e-01
    z[5,4,4]  R1451     -3.5175427794456482e-01
    z[5,4,4]  R1452     3.7179195880889893e-01
    z[5,4,4]  R1453     9.9859438836574554e-02
    z[5,4,4]  R1454     -0.219310000538826
    z[5,4,4]  R1455     2.7160480618476868e-01
    z[5,4,4]  R1456     -0.0803123265504837
    z[5,4,4]  R1457     4.6058705449104309e-01
    z[5,4,4]  R1458     -4.9506008625030518e-01
    z[5,4,4]  R1459     7.1128294803202152e-03
    z[5,4,4]  R1460     2.3088155686855316e-01
    z[5,4,4]  R1461     -3.5117557644844055e-01
    z[5,4,4]  R1462     -6.1572656035423279e-02
    z[5,4,4]  R1463     1.6156718134880066e-01
    z[5,4,4]  R1464     0.528188169002533
    z[5,4,4]  R1465     -1.3759201765060425e-01
    z[5,4,4]  R1466     2.6156926155090332e-01
    z[5,4,4]  R1467     7.8093636035919189e-01
    z[5,4,4]  R1468     5.7497990131378174e-01
    z[5,4,4]  R1469     2.3538200557231903e-01
    z[5,4,4]  R1470     0.0971253365278244
    z[5,4,4]  R1471     4.8219704627990723e-01
    z[5,4,4]  R1472     7.6357948780059814e-01
    z[5,4,4]  R1473     0.605150580406189
    z[5,4,4]  R1474     -5.2266061305999756e-02
    z[5,4,4]  R1475     -1.5737497806549072e-01
    z[5,4,4]  R1476     -2.6336705684661865e-01
    z[5,4,4]  R1477     -2.9991421103477478e-01
    z[5,4,4]  R1478     1.1974767595529556e-01
    z[5,4,4]  R1479     9.1862939298152924e-03
    z[5,4,4]  R1480     7.3491334915161133e-02
    z[5,4,4]  R1481     -5.8846427127718925e-03
    z[5,4,4]  R1482     -1.6747325658798218e-01
    z[5,4,4]  R1483     -1.3405182398855686e-03
    z[5,4,4]  R1484     2.5259381532669067e-01
    z[5,4,4]  R1485     -2.1315573155879974e-01
    z[5,4,4]  R1486     3.2217299938201904e-01
    z[5,4,4]  R1487     5.4563339799642563e-02
    z[5,4,4]  R1488     -1.9892422854900360e-01
    z[5,4,4]  R1489     -6.7497217655181885e-01
    z[5,4,4]  R1490     0.788306474685669
    z[5,4,4]  R1491     -4.4945013523101807e-01
    z[5,4,4]  R1492     -2.1735686063766479e-01
    z[5,4,4]  R1493     -2.3181030154228210e-01
    z[5,4,4]  R1494     5.2764439582824707e-01
    z[5,4,4]  R1495     -1.1529266089200974e-01
    z[5,4,4]  R1496     -4.5612469315528870e-01
    z[5,4,4]  R1497     2.4645689129829407e-01
    z[5,4,4]  R1498     -3.4443697333335876e-01
    z[5,4,4]  R1499     -4.1347879171371460e-01
    z[5,4,4]  R1500     -6.9526904821395874e-01
    z[5,4,4]  R1501     1.8194644153118134e-01
    z[5,4,4]  R1502     8.0386392772197723e-02
    z[5,4,4]  R1503     -3.9396342635154724e-01
    z[5,4,4]  R1504     -2.4239769577980042e-01
    z[5,4,4]  R1505     -1.4636828005313873e-01
    z[5,4,4]  R1506     2.6185914874076843e-01
    z[5,4,4]  R1507     1.6176441311836243e-01
    z[5,4,4]  R1508     1.8638296052813530e-02
    z[5,4,4]  R1509     2.1074400842189789e-01
    z[5,4,4]  R1510     -1.7241697013378143e-01
    z[5,4,4]  R1511     3.6345225572586060e-01
    z[5,4,4]  R1512     -2.9684737324714661e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1436     -1
    z[5,4,5]  R1437     1
    z[5,4,5]  R1440     2.7271553874015808e-01
    z[5,4,5]  R1441     5.2691268920898438e-01
    z[5,4,5]  R1442     6.4450263977050781e-01
    z[5,4,5]  R1443     7.0472925901412964e-01
    z[5,4,5]  R1444     -9.9377147853374481e-02
    z[5,4,5]  R1445     3.4897324442863464e-01
    z[5,4,5]  R1446     2.3402487859129906e-02
    z[5,4,5]  R1447     8.3330857753753662e-01
    z[5,4,5]  R1448     3.7897545844316483e-02
    z[5,4,5]  R1449     1.3680934906005859e-01
    z[5,4,5]  R1450     -0.595125675201416
    z[5,4,5]  R1451     -1.5955404937267303e-01
    z[5,4,5]  R1452     -2.2005158662796021e-01
    z[5,4,5]  R1453     2.0205345004796982e-02
    z[5,4,5]  R1454     -8.1733748316764832e-02
    z[5,4,5]  R1455     -2.3836898803710938e-01
    z[5,4,5]  R1456     -3.5071724653244019e-01
    z[5,4,5]  R1457     2.5413361191749573e-01
    z[5,4,5]  R1458     4.1997302323579788e-02
    z[5,4,5]  R1459     -1.7531554400920868e-01
    z[5,4,5]  R1460     -2.3685748875141144e-01
    z[5,4,5]  R1461     0.0639994740486145
    z[5,4,5]  R1462     1.9936181604862213e-01
    z[5,4,5]  R1463     2.3382996022701263e-01
    z[5,4,5]  R1464     -5.0613805651664734e-02
    z[5,4,5]  R1465     -3.2176694273948669e-01
    z[5,4,5]  R1466     -3.8128022104501724e-02
    z[5,4,5]  R1467     0.258573055267334
    z[5,4,5]  R1468     -1.9886805117130280e-01
    z[5,4,5]  R1469     2.5721633434295654e-01
    z[5,4,5]  R1470     -3.9157253503799438e-01
    z[5,4,5]  R1471     -0.0499303825199604
    z[5,4,5]  R1472     -6.2995433807373047e-02
    z[5,4,5]  R1473     -1.5592688322067261e-01
    z[5,4,5]  R1474     5.3906667232513428e-01
    z[5,4,5]  R1475     6.6354691982269287e-01
    z[5,4,5]  R1476     3.5606831312179565e-01
    z[5,4,5]  R1477     -3.9531141519546509e-01
    z[5,4,5]  R1478     1.9912265241146088e-01
    z[5,4,5]  R1479     4.6489837765693665e-01
    z[5,4,5]  R1480     1.7913137376308441e-01
    z[5,4,5]  R1481     1.4583170413970947e-01
    z[5,4,5]  R1482     -1.5650568902492523e-01
    z[5,4,5]  R1483     2.6274496316909790e-01
    z[5,4,5]  R1484     1.2872308492660522e-01
    z[5,4,5]  R1485     3.1005263328552246e-01
    z[5,4,5]  R1486     -2.4613271653652191e-01
    z[5,4,5]  R1487     -7.7008586376905441e-03
    z[5,4,5]  R1488     5.2982527017593384e-01
    z[5,4,5]  R1489     -4.3148615956306458e-01
    z[5,4,5]  R1490     1.3492126762866974e-01
    z[5,4,5]  R1491     -1.5359036624431610e-01
    z[5,4,5]  R1492     -4.3180957436561584e-01
    z[5,4,5]  R1493     -3.0500459671020508e-01
    z[5,4,5]  R1494     -0.306742787361145
    z[5,4,5]  R1495     -4.3126323819160461e-01
    z[5,4,5]  R1496     -2.4748770892620087e-01
    z[5,4,5]  R1497     -1.0798367857933044e-01
    z[5,4,5]  R1498     -3.5758325457572937e-01
    z[5,4,5]  R1499     -4.5182332396507263e-01
    z[5,4,5]  R1500     1.2278459221124649e-01
    z[5,4,5]  R1501     -2.3089537024497986e-01
    z[5,4,5]  R1502     -6.4779542386531830e-02
    z[5,4,5]  R1503     -1.6605409979820251e-01
    z[5,4,5]  R1504     -0.283381849527359
    z[5,4,5]  R1505     -2.8153559565544128e-01
    z[5,4,5]  R1506     -4.6473595499992371e-01
    z[5,4,5]  R1507     -5.0197279453277588e-01
    z[5,4,5]  R1508     -1.4717520773410797e-01
    z[5,4,5]  R1509     2.8738099336624146e-01
    z[5,4,5]  R1510     0.093800388276577
    z[5,4,5]  R1511     -2.8256615996360779e-01
    z[5,4,5]  R1512     0.0650511384010315
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1438     -1
    z[5,4,6]  R1439     1
    z[5,4,6]  R1440     4.1328620910644531e-01
    z[5,4,6]  R1441     3.8736695051193237e-01
    z[5,4,6]  R1442     1.2273205816745758e-01
    z[5,4,6]  R1443     -2.8786346316337585e-01
    z[5,4,6]  R1444     -6.9666884839534760e-02
    z[5,4,6]  R1445     0.0325879268348217
    z[5,4,6]  R1446     9.0030990540981293e-02
    z[5,4,6]  R1447     1.6411638259887695e-01
    z[5,4,6]  R1448     -5.1199745386838913e-02
    z[5,4,6]  R1449     1.6366812586784363e-01
    z[5,4,6]  R1450     -3.8937997817993164e-01
    z[5,4,6]  R1451     -6.0545355081558228e-01
    z[5,4,6]  R1452     2.1683479845523834e-01
    z[5,4,6]  R1453     1.9908371567726135e-01
    z[5,4,6]  R1454     -2.0090420544147491e-01
    z[5,4,6]  R1455     -3.5008609294891357e-01
    z[5,4,6]  R1456     -2.5925608351826668e-02
    z[5,4,6]  R1457     -2.6856634020805359e-01
    z[5,4,6]  R1458     3.8181087374687195e-01
    z[5,4,6]  R1459     1.7482678592205048e-01
    z[5,4,6]  R1460     3.6651477217674255e-01
    z[5,4,6]  R1461     1.2022166699171066e-01
    z[5,4,6]  R1462     -2.4474318325519562e-01
    z[5,4,6]  R1463     1.8731169402599335e-01
    z[5,4,6]  R1464     -5.6221973896026611e-01
    z[5,4,6]  R1465     4.0419686585664749e-02
    z[5,4,6]  R1466     -4.7852483391761780e-01
    z[5,4,6]  R1467     5.3995925933122635e-02
    z[5,4,6]  R1468     4.0910828113555908e-01
    z[5,4,6]  R1469     6.6640153527259827e-02
    z[5,4,6]  R1470     -6.4132785797119141e-01
    z[5,4,6]  R1471     1.9877620041370392e-01
    z[5,4,6]  R1472     -2.6349094510078430e-01
    z[5,4,6]  R1473     -0.0870453417301178
    z[5,4,6]  R1474     -3.6287501454353333e-01
    z[5,4,6]  R1475     2.3709645867347717e-01
    z[5,4,6]  R1476     1.2509196996688843e-01
    z[5,4,6]  R1477     4.1068512201309204e-01
    z[5,4,6]  R1478     9.4051003456115723e-02
    z[5,4,6]  R1479     2.1959602832794189e-01
    z[5,4,6]  R1480     -2.2288376092910767e-01
    z[5,4,6]  R1481     2.6998394727706909e-01
    z[5,4,6]  R1482     1.4485952444374561e-02
    z[5,4,6]  R1483     -1.2788560986518860e-01
    z[5,4,6]  R1484     -2.1695968508720398e-01
    z[5,4,6]  R1485     5.9041076898574829e-01
    z[5,4,6]  R1486     -1.6503702104091644e-01
    z[5,4,6]  R1487     9.7034208476543427e-02
    z[5,4,6]  R1488     4.2760372161865234e-03
    z[5,4,6]  R1489     2.0669229328632355e-01
    z[5,4,6]  R1490     1.5125776827335358e-01
    z[5,4,6]  R1491     -1.5639545023441315e-01
    z[5,4,6]  R1492     3.0983600020408630e-01
    z[5,4,6]  R1493     -2.3544387519359589e-01
    z[5,4,6]  R1494     2.2228620946407318e-01
    z[5,4,6]  R1495     -5.0690621137619019e-01
    z[5,4,6]  R1496     -6.9645619392395020e-01
    z[5,4,6]  R1497     -0.70573490858078
    z[5,4,6]  R1498     -1.1214417964220047e-01
    z[5,4,6]  R1499     5.3438387811183929e-02
    z[5,4,6]  R1500     -2.7194821834564209e-01
    z[5,4,6]  R1501     2.1997734904289246e-01
    z[5,4,6]  R1502     1.4994235336780548e-01
    z[5,4,6]  R1503     1.1865685880184174e-01
    z[5,4,6]  R1504     3.6452680360525846e-03
    z[5,4,6]  R1505     -3.1543239951133728e-01
    z[5,4,6]  R1506     -2.3646588623523712e-01
    z[5,4,6]  R1507     -2.5612443685531616e-01
    z[5,4,6]  R1508     3.5241311788558960e-01
    z[5,4,6]  R1509     -5.0374704599380493e-01
    z[5,4,6]  R1510     -3.6877453327178955e-01
    z[5,4,6]  R1511     -4.4958570599555969e-01
    z[5,4,6]  R1512     1.3927395641803741e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1562     -1
    z[5,6,0]  R1563     1
    z[5,6,0]  R1576     -3.7165734171867371e-01
    z[5,6,0]  R1577     2.5423645973205566e-01
    z[5,6,0]  R1578     2.4872298538684845e-01
    z[5,6,0]  R1579     2.9558088630437851e-02
    z[5,6,0]  R1580     -9.4943279027938843e-01
    z[5,6,0]  R1581     -8.3394092321395874e-01
    z[5,6,0]  R1582     -7.5397741794586182e-01
    z[5,6,0]  R1583     -2.8083962202072144e-01
    z[5,6,0]  R1584     -7.7542614936828613e-01
    z[5,6,0]  R1585     -0.810214638710022
    z[5,6,0]  R1586     7.4249900877475739e-02
    z[5,6,0]  R1587     1.3378772139549255e-01
    z[5,6,0]  R1588     1.3947302103042603e-01
    z[5,6,0]  R1589     9.5370262861251831e-01
    z[5,6,0]  R1590     8.9479452371597290e-01
    z[5,6,0]  R1591     7.4716895818710327e-01
    z[5,6,0]  R1592     5.6038695573806763e-01
    z[5,6,0]  R1593     4.7246214747428894e-01
    z[5,6,0]  R1594     6.9520950317382812e-01
    z[5,6,0]  R1595     5.6997841596603394e-01
    z[5,6,0]  R1596     -3.0660793185234070e-01
    z[5,6,0]  R1597     6.0899662971496582e-01
    z[5,6,0]  R1598     0.0663609504699707
    z[5,6,0]  R1599     1.5556894242763519e-01
    z[5,6,0]  R1600     9.8015494644641876e-02
    z[5,6,0]  R1601     1.5616254508495331e-01
    z[5,6,0]  R1602     -6.1184495687484741e-01
    z[5,6,0]  R1603     5.0071090459823608e-01
    z[5,6,0]  R1604     -5.1849460601806641e-01
    z[5,6,0]  R1605     5.0254905223846436e-01
    z[5,6,0]  R1606     4.1909966617822647e-02
    z[5,6,0]  R1607     6.1971396207809448e-01
    z[5,6,0]  R1608     -4.9056360125541687e-01
    z[5,6,0]  R1609     -5.9301030635833740e-01
    z[5,6,0]  R1610     5.9655243158340454e-01
    z[5,6,0]  R1611     5.4794758558273315e-01
    z[5,6,0]  R1612     4.0061506628990173e-01
    z[5,6,0]  R1613     0.0852038785815239
    z[5,6,0]  R1614     6.0078807175159454e-02
    z[5,6,0]  R1615     4.2724207043647766e-01
    z[5,6,0]  R1616     -1.3868042826652527e-01
    z[5,6,0]  R1617     2.4168582260608673e-01
    z[5,6,0]  R1618     1.7367795109748840e-01
    z[5,6,0]  R1619     5.2177809178829193e-02
    z[5,6,0]  R1620     -1.2040754407644272e-01
    z[5,6,0]  R1621     -8.5096374154090881e-02
    z[5,6,0]  R1622     1.5058766305446625e-01
    z[5,6,0]  R1623     -1.9815723598003387e-01
    z[5,6,0]  R1624     2.7436295151710510e-01
    z[5,6,0]  R1625     9.1647975146770477e-02
    z[5,6,0]  R1626     2.1745577454566956e-02
    z[5,6,0]  R1627     1.4354908466339111e-01
    z[5,6,0]  R1628     1.1310781538486481e-01
    z[5,6,0]  R1629     2.0845864713191986e-01
    z[5,6,0]  R1630     2.1086524426937103e-01
    z[5,6,0]  R1631     2.7131393551826477e-01
    z[5,6,0]  R1632     3.1033164262771606e-01
    z[5,6,0]  R1633     4.3398644775152206e-02
    z[5,6,0]  R1634     -1.3096639513969421e-01
    z[5,6,0]  R1635     -1.4340618252754211e-01
    z[5,6,0]  R1636     -5.6878834962844849e-01
    z[5,6,0]  R1637     2.8041192889213562e-01
    z[5,6,0]  R1638     -8.6313909292221069e-01
    z[5,6,0]  R1639     1.3524170219898224e-01
    z[5,6,0]  R1640     -3.0409637093544006e-01
    z[5,6,0]  R1641     7.7812612056732178e-02
    z[5,6,0]  R1642     -1.8799254670739174e-02
    z[5,6,0]  R1643     8.7074846029281616e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1564     -1
    z[5,6,1]  R1565     1
    z[5,6,1]  R1576     3.5621708631515503e-01
    z[5,6,1]  R1577     3.3393144607543945e-01
    z[5,6,1]  R1578     1.3601289689540863e-01
    z[5,6,1]  R1579     1.5801647305488586e-01
    z[5,6,1]  R1580     -2.1558862924575806e-01
    z[5,6,1]  R1581     -4.0382570028305054e-01
    z[5,6,1]  R1582     -5.0637245178222656e-01
    z[5,6,1]  R1583     2.1526904404163361e-01
    z[5,6,1]  R1584     -3.1657409667968750e-01
    z[5,6,1]  R1585     -1.1454027891159058e-01
    z[5,6,1]  R1586     5.0060570240020752e-01
    z[5,6,1]  R1587     6.2163311243057251e-01
    z[5,6,1]  R1588     6.6500949859619141e-01
    z[5,6,1]  R1589     1.9339509308338165e-01
    z[5,6,1]  R1590     2.2413589060306549e-01
    z[5,6,1]  R1591     3.4828302264213562e-01
    z[5,6,1]  R1592     6.7968463897705078e-01
    z[5,6,1]  R1593     4.7478905320167542e-01
    z[5,6,1]  R1594     2.8254491090774536e-01
    z[5,6,1]  R1595     7.2019243240356445e-01
    z[5,6,1]  R1596     6.7777782678604126e-01
    z[5,6,1]  R1597     5.9171909093856812e-01
    z[5,6,1]  R1598     7.7749079465866089e-01
    z[5,6,1]  R1599     7.2966808080673218e-01
    z[5,6,1]  R1600     3.6581516265869141e-01
    z[5,6,1]  R1601     8.4231942892074585e-01
    z[5,6,1]  R1602     5.1810473203659058e-01
    z[5,6,1]  R1603     1.9991654157638550e-01
    z[5,6,1]  R1604     2.7876409888267517e-01
    z[5,6,1]  R1605     1.5909207984805107e-02
    z[5,6,1]  R1606     4.9808838963508606e-01
    z[5,6,1]  R1607     3.9224720001220703e-01
    z[5,6,1]  R1608     4.9291603267192841e-02
    z[5,6,1]  R1609     3.7664610147476196e-01
    z[5,6,1]  R1610     -3.5159853100776672e-01
    z[5,6,1]  R1611     -3.2897260785102844e-01
    z[5,6,1]  R1612     -2.3197236657142639e-01
    z[5,6,1]  R1613     -2.7160695195198059e-01
    z[5,6,1]  R1614     4.0564718842506409e-01
    z[5,6,1]  R1615     2.2150342166423798e-01
    z[5,6,1]  R1616     7.5999921560287476e-01
    z[5,6,1]  R1617     8.0857682228088379e-01
    z[5,6,1]  R1618     6.7764484882354736e-01
    z[5,6,1]  R1619     6.8996334075927734e-01
    z[5,6,1]  R1620     6.9491308927536011e-01
    z[5,6,1]  R1621     7.1934080123901367e-01
    z[5,6,1]  R1622     5.3852117061614990e-01
    z[5,6,1]  R1623     4.8250377178192139e-01
    z[5,6,1]  R1624     -0.8618124127388
    z[5,6,1]  R1625     -8.8795089721679688e-01
    z[5,6,1]  R1626     -9.1304314136505127e-01
    z[5,6,1]  R1627     -7.7425575256347656e-01
    z[5,6,1]  R1628     -7.6965504884719849e-01
    z[5,6,1]  R1629     -7.8923708200454712e-01
    z[5,6,1]  R1630     -8.4171468019485474e-01
    z[5,6,1]  R1631     -8.9356827735900879e-01
    z[5,6,1]  R1632     -8.8723313808441162e-01
    z[5,6,1]  R1633     -0.852087140083313
    z[5,6,1]  R1634     1.7683847248554230e-01
    z[5,6,1]  R1635     -7.9349607229232788e-02
    z[5,6,1]  R1636     2.7236542105674744e-01
    z[5,6,1]  R1637     -1.4644323289394379e-01
    z[5,6,1]  R1638     -2.8788959980010986e-01
    z[5,6,1]  R1639     -6.1036145687103271e-01
    z[5,6,1]  R1640     -5.1336658000946045e-01
    z[5,6,1]  R1641     -6.2286847829818726e-01
    z[5,6,1]  R1642     -6.2361860275268555e-01
    z[5,6,1]  R1643     -0.288864403963089
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1566     -1
    z[5,6,2]  R1567     1
    z[5,6,2]  R1576     0.543677568435669
    z[5,6,2]  R1577     0.0949089303612709
    z[5,6,2]  R1578     5.5399411916732788e-01
    z[5,6,2]  R1579     4.0176367759704590e-01
    z[5,6,2]  R1580     2.9772909358143806e-02
    z[5,6,2]  R1581     9.1124951839447021e-02
    z[5,6,2]  R1582     -0.378989040851593
    z[5,6,2]  R1583     -6.6550811752676964e-03
    z[5,6,2]  R1584     -4.5272448658943176e-01
    z[5,6,2]  R1585     -2.4107094109058380e-01
    z[5,6,2]  R1586     1.3548418879508972e-01
    z[5,6,2]  R1587     1.2397056818008423e-01
    z[5,6,2]  R1588     -5.4570674896240234e-01
    z[5,6,2]  R1589     -3.6240026354789734e-02
    z[5,6,2]  R1590     2.3004771769046783e-01
    z[5,6,2]  R1591     -1.5100175142288208e-01
    z[5,6,2]  R1592     3.0566141009330750e-01
    z[5,6,2]  R1593     -3.8016438484191895e-01
    z[5,6,2]  R1594     1.8540556728839874e-01
    z[5,6,2]  R1595     5.8623835444450378e-02
    z[5,6,2]  R1596     -2.0094287395477295e-01
    z[5,6,2]  R1597     3.6440202593803406e-01
    z[5,6,2]  R1598     -5.0664746761322021e-01
    z[5,6,2]  R1599     3.4543567895889282e-01
    z[5,6,2]  R1600     1.1916842311620712e-02
    z[5,6,2]  R1601     -3.1948363780975342e-01
    z[5,6,2]  R1602     -8.5224412381649017e-02
    z[5,6,2]  R1603     1.0992618650197983e-01
    z[5,6,2]  R1604     -3.2113745808601379e-01
    z[5,6,2]  R1605     5.8931398391723633e-01
    z[5,6,2]  R1606     1.3008764386177063e-01
    z[5,6,2]  R1607     2.3867875337600708e-01
    z[5,6,2]  R1608     -3.0248191952705383e-01
    z[5,6,2]  R1609     -2.2429986298084259e-01
    z[5,6,2]  R1610     1.7193353176116943e-01
    z[5,6,2]  R1611     2.6403996348381042e-01
    z[5,6,2]  R1612     -4.3028593063354492e-01
    z[5,6,2]  R1613     -1.4504867792129517e-01
    z[5,6,2]  R1614     -3.4663298726081848e-01
    z[5,6,2]  R1615     9.0632744133472443e-02
    z[5,6,2]  R1616     -2.2049550712108612e-01
    z[5,6,2]  R1617     2.9269057512283325e-01
    z[5,6,2]  R1618     4.2941588163375854e-01
    z[5,6,2]  R1619     1.9265830516815186e-01
    z[5,6,2]  R1620     4.5219299197196960e-01
    z[5,6,2]  R1621     -0.402471125125885
    z[5,6,2]  R1622     4.4798237085342407e-01
    z[5,6,2]  R1623     -3.9822395890951157e-02
    z[5,6,2]  R1624     1.3586680591106415e-01
    z[5,6,2]  R1625     7.3633953928947449e-02
    z[5,6,2]  R1626     -2.1363621950149536e-01
    z[5,6,2]  R1627     -2.0699515938758850e-01
    z[5,6,2]  R1628     4.3758027255535126e-02
    z[5,6,2]  R1629     -1.8099133670330048e-01
    z[5,6,2]  R1630     2.9156863689422607e-02
    z[5,6,2]  R1631     1.8243777751922607e-01
    z[5,6,2]  R1632     -0.0689927414059639
    z[5,6,2]  R1633     -3.3757713437080383e-01
    z[5,6,2]  R1634     -9.5141483470797539e-03
    z[5,6,2]  R1635     3.0076336860656738e-01
    z[5,6,2]  R1636     -3.8881582021713257e-01
    z[5,6,2]  R1637     4.2071306705474854e-01
    z[5,6,2]  R1638     2.2023412585258484e-01
    z[5,6,2]  R1639     -2.4554346501827240e-01
    z[5,6,2]  R1640     -4.2343845963478088e-01
    z[5,6,2]  R1641     4.6115991473197937e-01
    z[5,6,2]  R1642     1.1870677024126053e-01
    z[5,6,2]  R1643     -8.8434182107448578e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1568     -1
    z[5,6,3]  R1569     1
    z[5,6,3]  R1576     4.2069047689437866e-01
    z[5,6,3]  R1577     5.8827346563339233e-01
    z[5,6,3]  R1578     4.2392176389694214e-01
    z[5,6,3]  R1579     4.8124855756759644e-01
    z[5,6,3]  R1580     1.8951384723186493e-01
    z[5,6,3]  R1581     6.4295828342437744e-02
    z[5,6,3]  R1582     -1.0613235644996166e-02
    z[5,6,3]  R1583     3.8200652599334717e-01
    z[5,6,3]  R1584     -2.9858285188674927e-01
    z[5,6,3]  R1585     -4.1682040691375732e-01
    z[5,6,3]  R1586     2.9735782742500305e-01
    z[5,6,3]  R1587     -2.5405082106590271e-01
    z[5,6,3]  R1588     -8.2731194794178009e-02
    z[5,6,3]  R1589     4.1493650525808334e-02
    z[5,6,3]  R1590     -3.2313905656337738e-02
    z[5,6,3]  R1591     -2.1091900765895844e-01
    z[5,6,3]  R1592     2.1014882251620293e-02
    z[5,6,3]  R1593     -2.4078558385372162e-01
    z[5,6,3]  R1594     -9.9243007600307465e-02
    z[5,6,3]  R1595     -3.0275449156761169e-01
    z[5,6,3]  R1596     4.0310040116310120e-01
    z[5,6,3]  R1597     -6.5796904265880585e-02
    z[5,6,3]  R1598     1.7600330710411072e-01
    z[5,6,3]  R1599     -4.5627933740615845e-01
    z[5,6,3]  R1600     5.0871866941452026e-01
    z[5,6,3]  R1601     -1.9985513389110565e-01
    z[5,6,3]  R1602     2.2603482007980347e-01
    z[5,6,3]  R1603     1.3266973197460175e-01
    z[5,6,3]  R1604     1.1315760016441345e-01
    z[5,6,3]  R1605     5.2334928512573242e-01
    z[5,6,3]  R1606     3.9895462989807129e-01
    z[5,6,3]  R1607     3.6140042543411255e-01
    z[5,6,3]  R1608     -9.4725519418716431e-02
    z[5,6,3]  R1609     -2.4097454547882080e-01
    z[5,6,3]  R1610     -2.5678718090057373e-01
    z[5,6,3]  R1611     -2.3178162053227425e-02
    z[5,6,3]  R1612     -6.2350267171859741e-01
    z[5,6,3]  R1613     6.9501721858978271e-01
    z[5,6,3]  R1614     -4.8990166187286377e-01
    z[5,6,3]  R1615     -3.9430651068687439e-01
    z[5,6,3]  R1616     0.46151003241539
    z[5,6,3]  R1617     -2.4853320419788361e-01
    z[5,6,3]  R1618     -0.0752018466591835
    z[5,6,3]  R1619     4.7317335009574890e-01
    z[5,6,3]  R1620     1.9617833197116852e-01
    z[5,6,3]  R1621     2.4148421362042427e-02
    z[5,6,3]  R1622     -1.8303368985652924e-01
    z[5,6,3]  R1623     -6.1512148380279541e-01
    z[5,6,3]  R1624     -3.2610893249511719e-01
    z[5,6,3]  R1625     -4.0407484769821167e-01
    z[5,6,3]  R1626     2.0927238464355469e-01
    z[5,6,3]  R1627     -5.3526580333709717e-01
    z[5,6,3]  R1628     -5.4303711652755737e-01
    z[5,6,3]  R1629     -4.6658292412757874e-01
    z[5,6,3]  R1630     -3.6240440607070923e-01
    z[5,6,3]  R1631     -2.0387594401836395e-01
    z[5,6,3]  R1632     -1.6399122774600983e-01
    z[5,6,3]  R1633     2.0753040909767151e-01
    z[5,6,3]  R1634     -3.4860542416572571e-01
    z[5,6,3]  R1635     -0.545215904712677
    z[5,6,3]  R1636     0.0992526262998581
    z[5,6,3]  R1637     6.3176751136779785e-01
    z[5,6,3]  R1638     1.9093842804431915e-01
    z[5,6,3]  R1639     3.1614455580711365e-01
    z[5,6,3]  R1640     2.0861414074897766e-01
    z[5,6,3]  R1641     4.4924274086952209e-01
    z[5,6,3]  R1642     4.8011621832847595e-01
    z[5,6,3]  R1643     1.5854936838150024e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1570     -1
    z[5,6,4]  R1571     1
    z[5,6,4]  R1576     -0.131282776594162
    z[5,6,4]  R1577     -2.0270679891109467e-01
    z[5,6,4]  R1578     5.0708428025245667e-02
    z[5,6,4]  R1579     4.0424704551696777e-02
    z[5,6,4]  R1580     -2.3826232179999352e-02
    z[5,6,4]  R1581     7.8646644949913025e-02
    z[5,6,4]  R1582     -1.5068666636943817e-01
    z[5,6,4]  R1583     8.6473770439624786e-02
    z[5,6,4]  R1584     1.8061840906739235e-02
    z[5,6,4]  R1585     -2.3037877678871155e-01
    z[5,6,4]  R1586     3.6236989498138428e-01
    z[5,6,4]  R1587     -3.5175427794456482e-01
    z[5,6,4]  R1588     3.7179195880889893e-01
    z[5,6,4]  R1589     9.9859438836574554e-02
    z[5,6,4]  R1590     -0.219310000538826
    z[5,6,4]  R1591     2.7160480618476868e-01
    z[5,6,4]  R1592     -0.0803123265504837
    z[5,6,4]  R1593     4.6058705449104309e-01
    z[5,6,4]  R1594     -4.9506008625030518e-01
    z[5,6,4]  R1595     7.1128294803202152e-03
    z[5,6,4]  R1596     2.3088155686855316e-01
    z[5,6,4]  R1597     -3.5117557644844055e-01
    z[5,6,4]  R1598     -6.1572656035423279e-02
    z[5,6,4]  R1599     1.6156718134880066e-01
    z[5,6,4]  R1600     0.528188169002533
    z[5,6,4]  R1601     -1.3759201765060425e-01
    z[5,6,4]  R1602     2.6156926155090332e-01
    z[5,6,4]  R1603     7.8093636035919189e-01
    z[5,6,4]  R1604     5.7497990131378174e-01
    z[5,6,4]  R1605     2.3538200557231903e-01
    z[5,6,4]  R1606     0.0971253365278244
    z[5,6,4]  R1607     4.8219704627990723e-01
    z[5,6,4]  R1608     7.6357948780059814e-01
    z[5,6,4]  R1609     0.605150580406189
    z[5,6,4]  R1610     -5.2266061305999756e-02
    z[5,6,4]  R1611     -1.5737497806549072e-01
    z[5,6,4]  R1612     -2.6336705684661865e-01
    z[5,6,4]  R1613     -2.9991421103477478e-01
    z[5,6,4]  R1614     -5.2042442560195923e-01
    z[5,6,4]  R1615     -7.6170068979263306e-01
    z[5,6,4]  R1616     -1.9811517000198364e-01
    z[5,6,4]  R1617     -3.4133148193359375e-01
    z[5,6,4]  R1618     -3.3587660640478134e-02
    z[5,6,4]  R1619     4.7299563884735107e-02
    z[5,6,4]  R1620     4.8518773913383484e-01
    z[5,6,4]  R1621     -1.8480852246284485e-01
    z[5,6,4]  R1622     2.7453845739364624e-01
    z[5,6,4]  R1623     4.5313492417335510e-01
    z[5,6,4]  R1624     3.7386257201433182e-02
    z[5,6,4]  R1625     1.2197016924619675e-01
    z[5,6,4]  R1626     -5.4741352796554565e-02
    z[5,6,4]  R1627     7.8208781778812408e-02
    z[5,6,4]  R1628     1.5961837768554688e-01
    z[5,6,4]  R1629     2.8302788734436035e-01
    z[5,6,4]  R1630     3.1871438026428223e-01
    z[5,6,4]  R1631     1.2767308950424194e-01
    z[5,6,4]  R1632     -2.8134299442172050e-02
    z[5,6,4]  R1633     -3.0184331536293030e-01
    z[5,6,4]  R1634     0.159694641828537
    z[5,6,4]  R1635     4.5935627818107605e-01
    z[5,6,4]  R1636     4.9985128641128540e-01
    z[5,6,4]  R1637     -3.1561404466629028e-01
    z[5,6,4]  R1638     6.6229745745658875e-02
    z[5,6,4]  R1639     -1.8067894876003265e-01
    z[5,6,4]  R1640     4.0252575278282166e-01
    z[5,6,4]  R1641     3.4419393539428711e-01
    z[5,6,4]  R1642     3.2462656497955322e-01
    z[5,6,4]  R1643     2.9222598671913147e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1572     -1
    z[5,6,5]  R1573     1
    z[5,6,5]  R1576     2.7271553874015808e-01
    z[5,6,5]  R1577     5.2691268920898438e-01
    z[5,6,5]  R1578     6.4450263977050781e-01
    z[5,6,5]  R1579     7.0472925901412964e-01
    z[5,6,5]  R1580     -9.9377147853374481e-02
    z[5,6,5]  R1581     3.4897324442863464e-01
    z[5,6,5]  R1582     2.3402487859129906e-02
    z[5,6,5]  R1583     8.3330857753753662e-01
    z[5,6,5]  R1584     3.7897545844316483e-02
    z[5,6,5]  R1585     1.3680934906005859e-01
    z[5,6,5]  R1586     -0.595125675201416
    z[5,6,5]  R1587     -1.5955404937267303e-01
    z[5,6,5]  R1588     -2.2005158662796021e-01
    z[5,6,5]  R1589     2.0205345004796982e-02
    z[5,6,5]  R1590     -8.1733748316764832e-02
    z[5,6,5]  R1591     -2.3836898803710938e-01
    z[5,6,5]  R1592     -3.5071724653244019e-01
    z[5,6,5]  R1593     2.5413361191749573e-01
    z[5,6,5]  R1594     4.1997302323579788e-02
    z[5,6,5]  R1595     -1.7531554400920868e-01
    z[5,6,5]  R1596     -2.3685748875141144e-01
    z[5,6,5]  R1597     0.0639994740486145
    z[5,6,5]  R1598     1.9936181604862213e-01
    z[5,6,5]  R1599     2.3382996022701263e-01
    z[5,6,5]  R1600     -5.0613805651664734e-02
    z[5,6,5]  R1601     -3.2176694273948669e-01
    z[5,6,5]  R1602     -3.8128022104501724e-02
    z[5,6,5]  R1603     0.258573055267334
    z[5,6,5]  R1604     -1.9886805117130280e-01
    z[5,6,5]  R1605     2.5721633434295654e-01
    z[5,6,5]  R1606     -3.9157253503799438e-01
    z[5,6,5]  R1607     -0.0499303825199604
    z[5,6,5]  R1608     -6.2995433807373047e-02
    z[5,6,5]  R1609     -1.5592688322067261e-01
    z[5,6,5]  R1610     5.3906667232513428e-01
    z[5,6,5]  R1611     6.6354691982269287e-01
    z[5,6,5]  R1612     3.5606831312179565e-01
    z[5,6,5]  R1613     -3.9531141519546509e-01
    z[5,6,5]  R1614     3.5878576338291168e-02
    z[5,6,5]  R1615     -8.7139256298542023e-02
    z[5,6,5]  R1616     7.0316776633262634e-02
    z[5,6,5]  R1617     -4.3579056859016418e-02
    z[5,6,5]  R1618     2.8673139214515686e-01
    z[5,6,5]  R1619     4.2939415574073792e-01
    z[5,6,5]  R1620     -0.0457756407558918
    z[5,6,5]  R1621     4.9169689416885376e-01
    z[5,6,5]  R1622     0.598415195941925
    z[5,6,5]  R1623     2.3235686123371124e-01
    z[5,6,5]  R1624     4.0108706802129745e-02
    z[5,6,5]  R1625     -4.2695008218288422e-02
    z[5,6,5]  R1626     -6.1412472277879715e-02
    z[5,6,5]  R1627     1.9556295871734619e-01
    z[5,6,5]  R1628     1.6959644854068756e-01
    z[5,6,5]  R1629     2.7440250851213932e-03
    z[5,6,5]  R1630     1.1292400211095810e-01
    z[5,6,5]  R1631     1.4733427762985229e-01
    z[5,6,5]  R1632     1.5611982345581055e-01
    z[5,6,5]  R1633     -1.3234174251556396e-01
    z[5,6,5]  R1634     -5.2889758348464966e-01
    z[5,6,5]  R1635     -4.0778699517250061e-01
    z[5,6,5]  R1636     -4.3332013487815857e-01
    z[5,6,5]  R1637     -3.9692139625549316e-01
    z[5,6,5]  R1638     1.8549689650535583e-01
    z[5,6,5]  R1639     6.4147424697875977e-01
    z[5,6,5]  R1640     4.3304291367530823e-01
    z[5,6,5]  R1641     2.6354651898145676e-02
    z[5,6,5]  R1642     3.8828876614570618e-01
    z[5,6,5]  R1643     1.9409877061843872e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1574     -1
    z[5,6,6]  R1575     1
    z[5,6,6]  R1576     4.1328620910644531e-01
    z[5,6,6]  R1577     3.8736695051193237e-01
    z[5,6,6]  R1578     1.2273205816745758e-01
    z[5,6,6]  R1579     -2.8786346316337585e-01
    z[5,6,6]  R1580     -6.9666884839534760e-02
    z[5,6,6]  R1581     0.0325879268348217
    z[5,6,6]  R1582     9.0030990540981293e-02
    z[5,6,6]  R1583     1.6411638259887695e-01
    z[5,6,6]  R1584     -5.1199745386838913e-02
    z[5,6,6]  R1585     1.6366812586784363e-01
    z[5,6,6]  R1586     -3.8937997817993164e-01
    z[5,6,6]  R1587     -6.0545355081558228e-01
    z[5,6,6]  R1588     2.1683479845523834e-01
    z[5,6,6]  R1589     1.9908371567726135e-01
    z[5,6,6]  R1590     -2.0090420544147491e-01
    z[5,6,6]  R1591     -3.5008609294891357e-01
    z[5,6,6]  R1592     -2.5925608351826668e-02
    z[5,6,6]  R1593     -2.6856634020805359e-01
    z[5,6,6]  R1594     3.8181087374687195e-01
    z[5,6,6]  R1595     1.7482678592205048e-01
    z[5,6,6]  R1596     3.6651477217674255e-01
    z[5,6,6]  R1597     1.2022166699171066e-01
    z[5,6,6]  R1598     -2.4474318325519562e-01
    z[5,6,6]  R1599     1.8731169402599335e-01
    z[5,6,6]  R1600     -5.6221973896026611e-01
    z[5,6,6]  R1601     4.0419686585664749e-02
    z[5,6,6]  R1602     -4.7852483391761780e-01
    z[5,6,6]  R1603     5.3995925933122635e-02
    z[5,6,6]  R1604     4.0910828113555908e-01
    z[5,6,6]  R1605     6.6640153527259827e-02
    z[5,6,6]  R1606     -6.4132785797119141e-01
    z[5,6,6]  R1607     1.9877620041370392e-01
    z[5,6,6]  R1608     -2.6349094510078430e-01
    z[5,6,6]  R1609     -0.0870453417301178
    z[5,6,6]  R1610     -3.6287501454353333e-01
    z[5,6,6]  R1611     2.3709645867347717e-01
    z[5,6,6]  R1612     1.2509196996688843e-01
    z[5,6,6]  R1613     4.1068512201309204e-01
    z[5,6,6]  R1614     -4.4671460986137390e-01
    z[5,6,6]  R1615     1.3010539114475250e-01
    z[5,6,6]  R1616     -3.1203389167785645e-01
    z[5,6,6]  R1617     1.4815047383308411e-01
    z[5,6,6]  R1618     -4.8706978559494019e-01
    z[5,6,6]  R1619     2.7129575610160828e-01
    z[5,6,6]  R1620     1.4876447618007660e-01
    z[5,6,6]  R1621     1.9188860058784485e-01
    z[5,6,6]  R1622     1.4020219445228577e-01
    z[5,6,6]  R1623     2.9772892594337463e-01
    z[5,6,6]  R1624     -2.3278956115245819e-01
    z[5,6,6]  R1625     -1.3321335613727570e-01
    z[5,6,6]  R1626     2.6396209001541138e-01
    z[5,6,6]  R1627     7.8763835132122040e-02
    z[5,6,6]  R1628     -2.0926684141159058e-01
    z[5,6,6]  R1629     5.5498555302619934e-02
    z[5,6,6]  R1630     2.3121263831853867e-02
    z[5,6,6]  R1631     1.2275070697069168e-01
    z[5,6,6]  R1632     2.4432279169559479e-01
    z[5,6,6]  R1633     -8.0082036554813385e-02
    z[5,6,6]  R1634     7.2437882423400879e-01
    z[5,6,6]  R1635     -4.5620280504226685e-01
    z[5,6,6]  R1636     -6.0417965054512024e-02
    z[5,6,6]  R1637     2.5813746452331543e-01
    z[5,6,6]  R1638     -2.1989642083644867e-01
    z[5,6,6]  R1639     -6.9250069558620453e-02
    z[5,6,6]  R1640     -2.6759475469589233e-01
    z[5,6,6]  R1641     -2.6893958449363708e-01
    z[5,6,6]  R1642     -3.3165183663368225e-01
    z[5,6,6]  R1643     4.8224378377199173e-02
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1644     -1
    z[6,5,0]  R1645     1
    z[6,5,0]  R1658     6.0078807175159454e-02
    z[6,5,0]  R1659     4.2724207043647766e-01
    z[6,5,0]  R1660     -1.3868042826652527e-01
    z[6,5,0]  R1661     2.4168582260608673e-01
    z[6,5,0]  R1662     1.7367795109748840e-01
    z[6,5,0]  R1663     5.2177809178829193e-02
    z[6,5,0]  R1664     -1.2040754407644272e-01
    z[6,5,0]  R1665     -8.5096374154090881e-02
    z[6,5,0]  R1666     1.5058766305446625e-01
    z[6,5,0]  R1667     -1.9815723598003387e-01
    z[6,5,0]  R1668     2.7436295151710510e-01
    z[6,5,0]  R1669     9.1647975146770477e-02
    z[6,5,0]  R1670     2.1745577454566956e-02
    z[6,5,0]  R1671     1.4354908466339111e-01
    z[6,5,0]  R1672     1.1310781538486481e-01
    z[6,5,0]  R1673     2.0845864713191986e-01
    z[6,5,0]  R1674     2.1086524426937103e-01
    z[6,5,0]  R1675     2.7131393551826477e-01
    z[6,5,0]  R1676     3.1033164262771606e-01
    z[6,5,0]  R1677     4.3398644775152206e-02
    z[6,5,0]  R1678     -1.3096639513969421e-01
    z[6,5,0]  R1679     -1.4340618252754211e-01
    z[6,5,0]  R1680     -5.6878834962844849e-01
    z[6,5,0]  R1681     2.8041192889213562e-01
    z[6,5,0]  R1682     -8.6313909292221069e-01
    z[6,5,0]  R1683     1.3524170219898224e-01
    z[6,5,0]  R1684     -3.0409637093544006e-01
    z[6,5,0]  R1685     7.7812612056732178e-02
    z[6,5,0]  R1686     -1.8799254670739174e-02
    z[6,5,0]  R1687     8.7074846029281616e-01
    z[6,5,0]  R1688     -3.7165734171867371e-01
    z[6,5,0]  R1689     2.5423645973205566e-01
    z[6,5,0]  R1690     2.4872298538684845e-01
    z[6,5,0]  R1691     2.9558088630437851e-02
    z[6,5,0]  R1692     -9.4943279027938843e-01
    z[6,5,0]  R1693     -8.3394092321395874e-01
    z[6,5,0]  R1694     -7.5397741794586182e-01
    z[6,5,0]  R1695     -2.8083962202072144e-01
    z[6,5,0]  R1696     -7.7542614936828613e-01
    z[6,5,0]  R1697     -0.810214638710022
    z[6,5,0]  R1698     7.4249900877475739e-02
    z[6,5,0]  R1699     1.3378772139549255e-01
    z[6,5,0]  R1700     1.3947302103042603e-01
    z[6,5,0]  R1701     9.5370262861251831e-01
    z[6,5,0]  R1702     8.9479452371597290e-01
    z[6,5,0]  R1703     7.4716895818710327e-01
    z[6,5,0]  R1704     5.6038695573806763e-01
    z[6,5,0]  R1705     4.7246214747428894e-01
    z[6,5,0]  R1706     6.9520950317382812e-01
    z[6,5,0]  R1707     5.6997841596603394e-01
    z[6,5,0]  R1708     -3.0660793185234070e-01
    z[6,5,0]  R1709     6.0899662971496582e-01
    z[6,5,0]  R1710     0.0663609504699707
    z[6,5,0]  R1711     1.5556894242763519e-01
    z[6,5,0]  R1712     9.8015494644641876e-02
    z[6,5,0]  R1713     1.5616254508495331e-01
    z[6,5,0]  R1714     -6.1184495687484741e-01
    z[6,5,0]  R1715     5.0071090459823608e-01
    z[6,5,0]  R1716     -5.1849460601806641e-01
    z[6,5,0]  R1717     5.0254905223846436e-01
    z[6,5,0]  R1718     4.1909966617822647e-02
    z[6,5,0]  R1719     6.1971396207809448e-01
    z[6,5,0]  R1720     -4.9056360125541687e-01
    z[6,5,0]  R1721     -5.9301030635833740e-01
    z[6,5,0]  R1722     5.9655243158340454e-01
    z[6,5,0]  R1723     5.4794758558273315e-01
    z[6,5,0]  R1724     4.0061506628990173e-01
    z[6,5,0]  R1725     0.0852038785815239
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1646     -1
    z[6,5,1]  R1647     1
    z[6,5,1]  R1658     4.0564718842506409e-01
    z[6,5,1]  R1659     2.2150342166423798e-01
    z[6,5,1]  R1660     7.5999921560287476e-01
    z[6,5,1]  R1661     8.0857682228088379e-01
    z[6,5,1]  R1662     6.7764484882354736e-01
    z[6,5,1]  R1663     6.8996334075927734e-01
    z[6,5,1]  R1664     6.9491308927536011e-01
    z[6,5,1]  R1665     7.1934080123901367e-01
    z[6,5,1]  R1666     5.3852117061614990e-01
    z[6,5,1]  R1667     4.8250377178192139e-01
    z[6,5,1]  R1668     -0.8618124127388
    z[6,5,1]  R1669     -8.8795089721679688e-01
    z[6,5,1]  R1670     -9.1304314136505127e-01
    z[6,5,1]  R1671     -7.7425575256347656e-01
    z[6,5,1]  R1672     -7.6965504884719849e-01
    z[6,5,1]  R1673     -7.8923708200454712e-01
    z[6,5,1]  R1674     -8.4171468019485474e-01
    z[6,5,1]  R1675     -8.9356827735900879e-01
    z[6,5,1]  R1676     -8.8723313808441162e-01
    z[6,5,1]  R1677     -0.852087140083313
    z[6,5,1]  R1678     1.7683847248554230e-01
    z[6,5,1]  R1679     -7.9349607229232788e-02
    z[6,5,1]  R1680     2.7236542105674744e-01
    z[6,5,1]  R1681     -1.4644323289394379e-01
    z[6,5,1]  R1682     -2.8788959980010986e-01
    z[6,5,1]  R1683     -6.1036145687103271e-01
    z[6,5,1]  R1684     -5.1336658000946045e-01
    z[6,5,1]  R1685     -6.2286847829818726e-01
    z[6,5,1]  R1686     -6.2361860275268555e-01
    z[6,5,1]  R1687     -0.288864403963089
    z[6,5,1]  R1688     3.5621708631515503e-01
    z[6,5,1]  R1689     3.3393144607543945e-01
    z[6,5,1]  R1690     1.3601289689540863e-01
    z[6,5,1]  R1691     1.5801647305488586e-01
    z[6,5,1]  R1692     -2.1558862924575806e-01
    z[6,5,1]  R1693     -4.0382570028305054e-01
    z[6,5,1]  R1694     -5.0637245178222656e-01
    z[6,5,1]  R1695     2.1526904404163361e-01
    z[6,5,1]  R1696     -3.1657409667968750e-01
    z[6,5,1]  R1697     -1.1454027891159058e-01
    z[6,5,1]  R1698     5.0060570240020752e-01
    z[6,5,1]  R1699     6.2163311243057251e-01
    z[6,5,1]  R1700     6.6500949859619141e-01
    z[6,5,1]  R1701     1.9339509308338165e-01
    z[6,5,1]  R1702     2.2413589060306549e-01
    z[6,5,1]  R1703     3.4828302264213562e-01
    z[6,5,1]  R1704     6.7968463897705078e-01
    z[6,5,1]  R1705     4.7478905320167542e-01
    z[6,5,1]  R1706     2.8254491090774536e-01
    z[6,5,1]  R1707     7.2019243240356445e-01
    z[6,5,1]  R1708     6.7777782678604126e-01
    z[6,5,1]  R1709     5.9171909093856812e-01
    z[6,5,1]  R1710     7.7749079465866089e-01
    z[6,5,1]  R1711     7.2966808080673218e-01
    z[6,5,1]  R1712     3.6581516265869141e-01
    z[6,5,1]  R1713     8.4231942892074585e-01
    z[6,5,1]  R1714     5.1810473203659058e-01
    z[6,5,1]  R1715     1.9991654157638550e-01
    z[6,5,1]  R1716     2.7876409888267517e-01
    z[6,5,1]  R1717     1.5909207984805107e-02
    z[6,5,1]  R1718     4.9808838963508606e-01
    z[6,5,1]  R1719     3.9224720001220703e-01
    z[6,5,1]  R1720     4.9291603267192841e-02
    z[6,5,1]  R1721     3.7664610147476196e-01
    z[6,5,1]  R1722     -3.5159853100776672e-01
    z[6,5,1]  R1723     -3.2897260785102844e-01
    z[6,5,1]  R1724     -2.3197236657142639e-01
    z[6,5,1]  R1725     -2.7160695195198059e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1648     -1
    z[6,5,2]  R1649     1
    z[6,5,2]  R1658     -3.4663298726081848e-01
    z[6,5,2]  R1659     9.0632744133472443e-02
    z[6,5,2]  R1660     -2.2049550712108612e-01
    z[6,5,2]  R1661     2.9269057512283325e-01
    z[6,5,2]  R1662     4.2941588163375854e-01
    z[6,5,2]  R1663     1.9265830516815186e-01
    z[6,5,2]  R1664     4.5219299197196960e-01
    z[6,5,2]  R1665     -0.402471125125885
    z[6,5,2]  R1666     4.4798237085342407e-01
    z[6,5,2]  R1667     -3.9822395890951157e-02
    z[6,5,2]  R1668     1.3586680591106415e-01
    z[6,5,2]  R1669     7.3633953928947449e-02
    z[6,5,2]  R1670     -2.1363621950149536e-01
    z[6,5,2]  R1671     -2.0699515938758850e-01
    z[6,5,2]  R1672     4.3758027255535126e-02
    z[6,5,2]  R1673     -1.8099133670330048e-01
    z[6,5,2]  R1674     2.9156863689422607e-02
    z[6,5,2]  R1675     1.8243777751922607e-01
    z[6,5,2]  R1676     -0.0689927414059639
    z[6,5,2]  R1677     -3.3757713437080383e-01
    z[6,5,2]  R1678     -9.5141483470797539e-03
    z[6,5,2]  R1679     3.0076336860656738e-01
    z[6,5,2]  R1680     -3.8881582021713257e-01
    z[6,5,2]  R1681     4.2071306705474854e-01
    z[6,5,2]  R1682     2.2023412585258484e-01
    z[6,5,2]  R1683     -2.4554346501827240e-01
    z[6,5,2]  R1684     -4.2343845963478088e-01
    z[6,5,2]  R1685     4.6115991473197937e-01
    z[6,5,2]  R1686     1.1870677024126053e-01
    z[6,5,2]  R1687     -8.8434182107448578e-02
    z[6,5,2]  R1688     0.543677568435669
    z[6,5,2]  R1689     0.0949089303612709
    z[6,5,2]  R1690     5.5399411916732788e-01
    z[6,5,2]  R1691     4.0176367759704590e-01
    z[6,5,2]  R1692     2.9772909358143806e-02
    z[6,5,2]  R1693     9.1124951839447021e-02
    z[6,5,2]  R1694     -0.378989040851593
    z[6,5,2]  R1695     -6.6550811752676964e-03
    z[6,5,2]  R1696     -4.5272448658943176e-01
    z[6,5,2]  R1697     -2.4107094109058380e-01
    z[6,5,2]  R1698     1.3548418879508972e-01
    z[6,5,2]  R1699     1.2397056818008423e-01
    z[6,5,2]  R1700     -5.4570674896240234e-01
    z[6,5,2]  R1701     -3.6240026354789734e-02
    z[6,5,2]  R1702     2.3004771769046783e-01
    z[6,5,2]  R1703     -1.5100175142288208e-01
    z[6,5,2]  R1704     3.0566141009330750e-01
    z[6,5,2]  R1705     -3.8016438484191895e-01
    z[6,5,2]  R1706     1.8540556728839874e-01
    z[6,5,2]  R1707     5.8623835444450378e-02
    z[6,5,2]  R1708     -2.0094287395477295e-01
    z[6,5,2]  R1709     3.6440202593803406e-01
    z[6,5,2]  R1710     -5.0664746761322021e-01
    z[6,5,2]  R1711     3.4543567895889282e-01
    z[6,5,2]  R1712     1.1916842311620712e-02
    z[6,5,2]  R1713     -3.1948363780975342e-01
    z[6,5,2]  R1714     -8.5224412381649017e-02
    z[6,5,2]  R1715     1.0992618650197983e-01
    z[6,5,2]  R1716     -3.2113745808601379e-01
    z[6,5,2]  R1717     5.8931398391723633e-01
    z[6,5,2]  R1718     1.3008764386177063e-01
    z[6,5,2]  R1719     2.3867875337600708e-01
    z[6,5,2]  R1720     -3.0248191952705383e-01
    z[6,5,2]  R1721     -2.2429986298084259e-01
    z[6,5,2]  R1722     1.7193353176116943e-01
    z[6,5,2]  R1723     2.6403996348381042e-01
    z[6,5,2]  R1724     -4.3028593063354492e-01
    z[6,5,2]  R1725     -1.4504867792129517e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1650     -1
    z[6,5,3]  R1651     1
    z[6,5,3]  R1658     -4.8990166187286377e-01
    z[6,5,3]  R1659     -3.9430651068687439e-01
    z[6,5,3]  R1660     0.46151003241539
    z[6,5,3]  R1661     -2.4853320419788361e-01
    z[6,5,3]  R1662     -0.0752018466591835
    z[6,5,3]  R1663     4.7317335009574890e-01
    z[6,5,3]  R1664     1.9617833197116852e-01
    z[6,5,3]  R1665     2.4148421362042427e-02
    z[6,5,3]  R1666     -1.8303368985652924e-01
    z[6,5,3]  R1667     -6.1512148380279541e-01
    z[6,5,3]  R1668     -3.2610893249511719e-01
    z[6,5,3]  R1669     -4.0407484769821167e-01
    z[6,5,3]  R1670     2.0927238464355469e-01
    z[6,5,3]  R1671     -5.3526580333709717e-01
    z[6,5,3]  R1672     -5.4303711652755737e-01
    z[6,5,3]  R1673     -4.6658292412757874e-01
    z[6,5,3]  R1674     -3.6240440607070923e-01
    z[6,5,3]  R1675     -2.0387594401836395e-01
    z[6,5,3]  R1676     -1.6399122774600983e-01
    z[6,5,3]  R1677     2.0753040909767151e-01
    z[6,5,3]  R1678     -3.4860542416572571e-01
    z[6,5,3]  R1679     -0.545215904712677
    z[6,5,3]  R1680     0.0992526262998581
    z[6,5,3]  R1681     6.3176751136779785e-01
    z[6,5,3]  R1682     1.9093842804431915e-01
    z[6,5,3]  R1683     3.1614455580711365e-01
    z[6,5,3]  R1684     2.0861414074897766e-01
    z[6,5,3]  R1685     4.4924274086952209e-01
    z[6,5,3]  R1686     4.8011621832847595e-01
    z[6,5,3]  R1687     1.5854936838150024e-01
    z[6,5,3]  R1688     4.2069047689437866e-01
    z[6,5,3]  R1689     5.8827346563339233e-01
    z[6,5,3]  R1690     4.2392176389694214e-01
    z[6,5,3]  R1691     4.8124855756759644e-01
    z[6,5,3]  R1692     1.8951384723186493e-01
    z[6,5,3]  R1693     6.4295828342437744e-02
    z[6,5,3]  R1694     -1.0613235644996166e-02
    z[6,5,3]  R1695     3.8200652599334717e-01
    z[6,5,3]  R1696     -2.9858285188674927e-01
    z[6,5,3]  R1697     -4.1682040691375732e-01
    z[6,5,3]  R1698     2.9735782742500305e-01
    z[6,5,3]  R1699     -2.5405082106590271e-01
    z[6,5,3]  R1700     -8.2731194794178009e-02
    z[6,5,3]  R1701     4.1493650525808334e-02
    z[6,5,3]  R1702     -3.2313905656337738e-02
    z[6,5,3]  R1703     -2.1091900765895844e-01
    z[6,5,3]  R1704     2.1014882251620293e-02
    z[6,5,3]  R1705     -2.4078558385372162e-01
    z[6,5,3]  R1706     -9.9243007600307465e-02
    z[6,5,3]  R1707     -3.0275449156761169e-01
    z[6,5,3]  R1708     4.0310040116310120e-01
    z[6,5,3]  R1709     -6.5796904265880585e-02
    z[6,5,3]  R1710     1.7600330710411072e-01
    z[6,5,3]  R1711     -4.5627933740615845e-01
    z[6,5,3]  R1712     5.0871866941452026e-01
    z[6,5,3]  R1713     -1.9985513389110565e-01
    z[6,5,3]  R1714     2.2603482007980347e-01
    z[6,5,3]  R1715     1.3266973197460175e-01
    z[6,5,3]  R1716     1.1315760016441345e-01
    z[6,5,3]  R1717     5.2334928512573242e-01
    z[6,5,3]  R1718     3.9895462989807129e-01
    z[6,5,3]  R1719     3.6140042543411255e-01
    z[6,5,3]  R1720     -9.4725519418716431e-02
    z[6,5,3]  R1721     -2.4097454547882080e-01
    z[6,5,3]  R1722     -2.5678718090057373e-01
    z[6,5,3]  R1723     -2.3178162053227425e-02
    z[6,5,3]  R1724     -6.2350267171859741e-01
    z[6,5,3]  R1725     6.9501721858978271e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1652     -1
    z[6,5,4]  R1653     1
    z[6,5,4]  R1658     -5.2042442560195923e-01
    z[6,5,4]  R1659     -7.6170068979263306e-01
    z[6,5,4]  R1660     -1.9811517000198364e-01
    z[6,5,4]  R1661     -3.4133148193359375e-01
    z[6,5,4]  R1662     -3.3587660640478134e-02
    z[6,5,4]  R1663     4.7299563884735107e-02
    z[6,5,4]  R1664     4.8518773913383484e-01
    z[6,5,4]  R1665     -1.8480852246284485e-01
    z[6,5,4]  R1666     2.7453845739364624e-01
    z[6,5,4]  R1667     4.5313492417335510e-01
    z[6,5,4]  R1668     3.7386257201433182e-02
    z[6,5,4]  R1669     1.2197016924619675e-01
    z[6,5,4]  R1670     -5.4741352796554565e-02
    z[6,5,4]  R1671     7.8208781778812408e-02
    z[6,5,4]  R1672     1.5961837768554688e-01
    z[6,5,4]  R1673     2.8302788734436035e-01
    z[6,5,4]  R1674     3.1871438026428223e-01
    z[6,5,4]  R1675     1.2767308950424194e-01
    z[6,5,4]  R1676     -2.8134299442172050e-02
    z[6,5,4]  R1677     -3.0184331536293030e-01
    z[6,5,4]  R1678     0.159694641828537
    z[6,5,4]  R1679     4.5935627818107605e-01
    z[6,5,4]  R1680     4.9985128641128540e-01
    z[6,5,4]  R1681     -3.1561404466629028e-01
    z[6,5,4]  R1682     6.6229745745658875e-02
    z[6,5,4]  R1683     -1.8067894876003265e-01
    z[6,5,4]  R1684     4.0252575278282166e-01
    z[6,5,4]  R1685     3.4419393539428711e-01
    z[6,5,4]  R1686     3.2462656497955322e-01
    z[6,5,4]  R1687     2.9222598671913147e-01
    z[6,5,4]  R1688     -0.131282776594162
    z[6,5,4]  R1689     -2.0270679891109467e-01
    z[6,5,4]  R1690     5.0708428025245667e-02
    z[6,5,4]  R1691     4.0424704551696777e-02
    z[6,5,4]  R1692     -2.3826232179999352e-02
    z[6,5,4]  R1693     7.8646644949913025e-02
    z[6,5,4]  R1694     -1.5068666636943817e-01
    z[6,5,4]  R1695     8.6473770439624786e-02
    z[6,5,4]  R1696     1.8061840906739235e-02
    z[6,5,4]  R1697     -2.3037877678871155e-01
    z[6,5,4]  R1698     3.6236989498138428e-01
    z[6,5,4]  R1699     -3.5175427794456482e-01
    z[6,5,4]  R1700     3.7179195880889893e-01
    z[6,5,4]  R1701     9.9859438836574554e-02
    z[6,5,4]  R1702     -0.219310000538826
    z[6,5,4]  R1703     2.7160480618476868e-01
    z[6,5,4]  R1704     -0.0803123265504837
    z[6,5,4]  R1705     4.6058705449104309e-01
    z[6,5,4]  R1706     -4.9506008625030518e-01
    z[6,5,4]  R1707     7.1128294803202152e-03
    z[6,5,4]  R1708     2.3088155686855316e-01
    z[6,5,4]  R1709     -3.5117557644844055e-01
    z[6,5,4]  R1710     -6.1572656035423279e-02
    z[6,5,4]  R1711     1.6156718134880066e-01
    z[6,5,4]  R1712     0.528188169002533
    z[6,5,4]  R1713     -1.3759201765060425e-01
    z[6,5,4]  R1714     2.6156926155090332e-01
    z[6,5,4]  R1715     7.8093636035919189e-01
    z[6,5,4]  R1716     5.7497990131378174e-01
    z[6,5,4]  R1717     2.3538200557231903e-01
    z[6,5,4]  R1718     0.0971253365278244
    z[6,5,4]  R1719     4.8219704627990723e-01
    z[6,5,4]  R1720     7.6357948780059814e-01
    z[6,5,4]  R1721     0.605150580406189
    z[6,5,4]  R1722     -5.2266061305999756e-02
    z[6,5,4]  R1723     -1.5737497806549072e-01
    z[6,5,4]  R1724     -2.6336705684661865e-01
    z[6,5,4]  R1725     -2.9991421103477478e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1654     -1
    z[6,5,5]  R1655     1
    z[6,5,5]  R1658     3.5878576338291168e-02
    z[6,5,5]  R1659     -8.7139256298542023e-02
    z[6,5,5]  R1660     7.0316776633262634e-02
    z[6,5,5]  R1661     -4.3579056859016418e-02
    z[6,5,5]  R1662     2.8673139214515686e-01
    z[6,5,5]  R1663     4.2939415574073792e-01
    z[6,5,5]  R1664     -0.0457756407558918
    z[6,5,5]  R1665     4.9169689416885376e-01
    z[6,5,5]  R1666     0.598415195941925
    z[6,5,5]  R1667     2.3235686123371124e-01
    z[6,5,5]  R1668     4.0108706802129745e-02
    z[6,5,5]  R1669     -4.2695008218288422e-02
    z[6,5,5]  R1670     -6.1412472277879715e-02
    z[6,5,5]  R1671     1.9556295871734619e-01
    z[6,5,5]  R1672     1.6959644854068756e-01
    z[6,5,5]  R1673     2.7440250851213932e-03
    z[6,5,5]  R1674     1.1292400211095810e-01
    z[6,5,5]  R1675     1.4733427762985229e-01
    z[6,5,5]  R1676     1.5611982345581055e-01
    z[6,5,5]  R1677     -1.3234174251556396e-01
    z[6,5,5]  R1678     -5.2889758348464966e-01
    z[6,5,5]  R1679     -4.0778699517250061e-01
    z[6,5,5]  R1680     -4.3332013487815857e-01
    z[6,5,5]  R1681     -3.9692139625549316e-01
    z[6,5,5]  R1682     1.8549689650535583e-01
    z[6,5,5]  R1683     6.4147424697875977e-01
    z[6,5,5]  R1684     4.3304291367530823e-01
    z[6,5,5]  R1685     2.6354651898145676e-02
    z[6,5,5]  R1686     3.8828876614570618e-01
    z[6,5,5]  R1687     1.9409877061843872e-01
    z[6,5,5]  R1688     2.7271553874015808e-01
    z[6,5,5]  R1689     5.2691268920898438e-01
    z[6,5,5]  R1690     6.4450263977050781e-01
    z[6,5,5]  R1691     7.0472925901412964e-01
    z[6,5,5]  R1692     -9.9377147853374481e-02
    z[6,5,5]  R1693     3.4897324442863464e-01
    z[6,5,5]  R1694     2.3402487859129906e-02
    z[6,5,5]  R1695     8.3330857753753662e-01
    z[6,5,5]  R1696     3.7897545844316483e-02
    z[6,5,5]  R1697     1.3680934906005859e-01
    z[6,5,5]  R1698     -0.595125675201416
    z[6,5,5]  R1699     -1.5955404937267303e-01
    z[6,5,5]  R1700     -2.2005158662796021e-01
    z[6,5,5]  R1701     2.0205345004796982e-02
    z[6,5,5]  R1702     -8.1733748316764832e-02
    z[6,5,5]  R1703     -2.3836898803710938e-01
    z[6,5,5]  R1704     -3.5071724653244019e-01
    z[6,5,5]  R1705     2.5413361191749573e-01
    z[6,5,5]  R1706     4.1997302323579788e-02
    z[6,5,5]  R1707     -1.7531554400920868e-01
    z[6,5,5]  R1708     -2.3685748875141144e-01
    z[6,5,5]  R1709     0.0639994740486145
    z[6,5,5]  R1710     1.9936181604862213e-01
    z[6,5,5]  R1711     2.3382996022701263e-01
    z[6,5,5]  R1712     -5.0613805651664734e-02
    z[6,5,5]  R1713     -3.2176694273948669e-01
    z[6,5,5]  R1714     -3.8128022104501724e-02
    z[6,5,5]  R1715     0.258573055267334
    z[6,5,5]  R1716     -1.9886805117130280e-01
    z[6,5,5]  R1717     2.5721633434295654e-01
    z[6,5,5]  R1718     -3.9157253503799438e-01
    z[6,5,5]  R1719     -0.0499303825199604
    z[6,5,5]  R1720     -6.2995433807373047e-02
    z[6,5,5]  R1721     -1.5592688322067261e-01
    z[6,5,5]  R1722     5.3906667232513428e-01
    z[6,5,5]  R1723     6.6354691982269287e-01
    z[6,5,5]  R1724     3.5606831312179565e-01
    z[6,5,5]  R1725     -3.9531141519546509e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1656     -1
    z[6,5,6]  R1657     1
    z[6,5,6]  R1658     -4.4671460986137390e-01
    z[6,5,6]  R1659     1.3010539114475250e-01
    z[6,5,6]  R1660     -3.1203389167785645e-01
    z[6,5,6]  R1661     1.4815047383308411e-01
    z[6,5,6]  R1662     -4.8706978559494019e-01
    z[6,5,6]  R1663     2.7129575610160828e-01
    z[6,5,6]  R1664     1.4876447618007660e-01
    z[6,5,6]  R1665     1.9188860058784485e-01
    z[6,5,6]  R1666     1.4020219445228577e-01
    z[6,5,6]  R1667     2.9772892594337463e-01
    z[6,5,6]  R1668     -2.3278956115245819e-01
    z[6,5,6]  R1669     -1.3321335613727570e-01
    z[6,5,6]  R1670     2.6396209001541138e-01
    z[6,5,6]  R1671     7.8763835132122040e-02
    z[6,5,6]  R1672     -2.0926684141159058e-01
    z[6,5,6]  R1673     5.5498555302619934e-02
    z[6,5,6]  R1674     2.3121263831853867e-02
    z[6,5,6]  R1675     1.2275070697069168e-01
    z[6,5,6]  R1676     2.4432279169559479e-01
    z[6,5,6]  R1677     -8.0082036554813385e-02
    z[6,5,6]  R1678     7.2437882423400879e-01
    z[6,5,6]  R1679     -4.5620280504226685e-01
    z[6,5,6]  R1680     -6.0417965054512024e-02
    z[6,5,6]  R1681     2.5813746452331543e-01
    z[6,5,6]  R1682     -2.1989642083644867e-01
    z[6,5,6]  R1683     -6.9250069558620453e-02
    z[6,5,6]  R1684     -2.6759475469589233e-01
    z[6,5,6]  R1685     -2.6893958449363708e-01
    z[6,5,6]  R1686     -3.3165183663368225e-01
    z[6,5,6]  R1687     4.8224378377199173e-02
    z[6,5,6]  R1688     4.1328620910644531e-01
    z[6,5,6]  R1689     3.8736695051193237e-01
    z[6,5,6]  R1690     1.2273205816745758e-01
    z[6,5,6]  R1691     -2.8786346316337585e-01
    z[6,5,6]  R1692     -6.9666884839534760e-02
    z[6,5,6]  R1693     0.0325879268348217
    z[6,5,6]  R1694     9.0030990540981293e-02
    z[6,5,6]  R1695     1.6411638259887695e-01
    z[6,5,6]  R1696     -5.1199745386838913e-02
    z[6,5,6]  R1697     1.6366812586784363e-01
    z[6,5,6]  R1698     -3.8937997817993164e-01
    z[6,5,6]  R1699     -6.0545355081558228e-01
    z[6,5,6]  R1700     2.1683479845523834e-01
    z[6,5,6]  R1701     1.9908371567726135e-01
    z[6,5,6]  R1702     -2.0090420544147491e-01
    z[6,5,6]  R1703     -3.5008609294891357e-01
    z[6,5,6]  R1704     -2.5925608351826668e-02
    z[6,5,6]  R1705     -2.6856634020805359e-01
    z[6,5,6]  R1706     3.8181087374687195e-01
    z[6,5,6]  R1707     1.7482678592205048e-01
    z[6,5,6]  R1708     3.6651477217674255e-01
    z[6,5,6]  R1709     1.2022166699171066e-01
    z[6,5,6]  R1710     -2.4474318325519562e-01
    z[6,5,6]  R1711     1.8731169402599335e-01
    z[6,5,6]  R1712     -5.6221973896026611e-01
    z[6,5,6]  R1713     4.0419686585664749e-02
    z[6,5,6]  R1714     -4.7852483391761780e-01
    z[6,5,6]  R1715     5.3995925933122635e-02
    z[6,5,6]  R1716     4.0910828113555908e-01
    z[6,5,6]  R1717     6.6640153527259827e-02
    z[6,5,6]  R1718     -6.4132785797119141e-01
    z[6,5,6]  R1719     1.9877620041370392e-01
    z[6,5,6]  R1720     -2.6349094510078430e-01
    z[6,5,6]  R1721     -0.0870453417301178
    z[6,5,6]  R1722     -3.6287501454353333e-01
    z[6,5,6]  R1723     2.3709645867347717e-01
    z[6,5,6]  R1724     1.2509196996688843e-01
    z[6,5,6]  R1725     4.1068512201309204e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R1726     -1
    z[6,7,0]  R1727     1
    z[6,7,0]  R1740     6.0078807175159454e-02
    z[6,7,0]  R1741     4.2724207043647766e-01
    z[6,7,0]  R1742     -1.3868042826652527e-01
    z[6,7,0]  R1743     2.4168582260608673e-01
    z[6,7,0]  R1744     1.7367795109748840e-01
    z[6,7,0]  R1745     5.2177809178829193e-02
    z[6,7,0]  R1746     -1.2040754407644272e-01
    z[6,7,0]  R1747     -8.5096374154090881e-02
    z[6,7,0]  R1748     1.5058766305446625e-01
    z[6,7,0]  R1749     -1.9815723598003387e-01
    z[6,7,0]  R1750     2.7436295151710510e-01
    z[6,7,0]  R1751     9.1647975146770477e-02
    z[6,7,0]  R1752     2.1745577454566956e-02
    z[6,7,0]  R1753     1.4354908466339111e-01
    z[6,7,0]  R1754     1.1310781538486481e-01
    z[6,7,0]  R1755     2.0845864713191986e-01
    z[6,7,0]  R1756     2.1086524426937103e-01
    z[6,7,0]  R1757     2.7131393551826477e-01
    z[6,7,0]  R1758     3.1033164262771606e-01
    z[6,7,0]  R1759     4.3398644775152206e-02
    z[6,7,0]  R1760     -1.3096639513969421e-01
    z[6,7,0]  R1761     -1.4340618252754211e-01
    z[6,7,0]  R1762     -5.6878834962844849e-01
    z[6,7,0]  R1763     2.8041192889213562e-01
    z[6,7,0]  R1764     -8.6313909292221069e-01
    z[6,7,0]  R1765     1.3524170219898224e-01
    z[6,7,0]  R1766     -3.0409637093544006e-01
    z[6,7,0]  R1767     7.7812612056732178e-02
    z[6,7,0]  R1768     -1.8799254670739174e-02
    z[6,7,0]  R1769     8.7074846029281616e-01
    z[6,7,0]  R1770     0.77576744556427
    z[6,7,0]  R1771     8.8025522232055664e-01
    z[6,7,0]  R1772     6.4333146810531616e-01
    z[6,7,0]  R1773     8.7296146154403687e-01
    z[6,7,0]  R1774     6.7654889822006226e-01
    z[6,7,0]  R1775     7.7571070194244385e-01
    z[6,7,0]  R1776     7.1319955587387085e-01
    z[6,7,0]  R1777     7.6416790485382080e-01
    z[6,7,0]  R1778     0.66385817527771
    z[6,7,0]  R1779     7.3412883281707764e-01
    z[6,7,0]  R1780     -0.0723298192024231
    z[6,7,0]  R1781     -3.6823704838752747e-01
    z[6,7,0]  R1782     -1.8581800162792206e-01
    z[6,7,0]  R1783     -2.1017327904701233e-01
    z[6,7,0]  R1784     -4.3952235579490662e-01
    z[6,7,0]  R1785     -0.404788076877594
    z[6,7,0]  R1786     6.5057352185249329e-02
    z[6,7,0]  R1787     -3.6465483903884888e-01
    z[6,7,0]  R1788     -7.1978025138378143e-02
    z[6,7,0]  R1789     -1.6103573143482208e-02
    z[6,7,0]  R1790     1.5172088146209717e-01
    z[6,7,0]  R1791     8.2185946404933929e-02
    z[6,7,0]  R1792     2.3939360678195953e-01
    z[6,7,0]  R1793     0.133229598402977
    z[6,7,0]  R1794     3.4232255816459656e-01
    z[6,7,0]  R1795     2.4072253704071045e-01
    z[6,7,0]  R1796     -0.907288670539856
    z[6,7,0]  R1797     -9.0061253309249878e-01
    z[6,7,0]  R1798     -7.9439109563827515e-01
    z[6,7,0]  R1799     -7.9312282800674438e-01
    z[6,7,0]  R1800     6.7805558443069458e-02
    z[6,7,0]  R1801     3.4394392371177673e-01
    z[6,7,0]  R1802     3.5133108496665955e-01
    z[6,7,0]  R1803     2.5730523467063904e-01
    z[6,7,0]  R1804     -4.4008356332778931e-01
    z[6,7,0]  R1805     -8.8031291961669922e-02
    z[6,7,0]  R1806     -1.8469962477684021e-01
    z[6,7,0]  R1807     1.5967264771461487e-01
    z[6,7,0]  R1808     -7.2020488977432251e-01
    z[6,7,0]  R1809     -5.1735591888427734e-01
    z[6,7,0]  R1810     6.6200077533721924e-01
    z[6,7,0]  R1811     6.1138284206390381e-01
    z[6,7,0]  R1812     3.5945829749107361e-01
    z[6,7,0]  R1813     3.4982198476791382e-01
    z[6,7,0]  R1814     4.5862689614295959e-01
    z[6,7,0]  R1815     -3.2159939408302307e-02
    z[6,7,0]  R1816     -0.553945779800415
    z[6,7,0]  R1817     -1.6781832277774811e-01
    z[6,7,0]  R1818     2.1491825580596924e-01
    z[6,7,0]  R1819     -8.2912176847457886e-01
    z[6,7,0]  R1820     3.9126396179199219e-01
    z[6,7,0]  R1821     2.4881863594055176e-01
    z[6,7,0]  R1822     2.1482163667678833e-01
    z[6,7,0]  R1823     1.6018109396100044e-02
    z[6,7,0]  R1824     1.4037631452083588e-01
    z[6,7,0]  R1825     -1.0633911192417145e-01
    z[6,7,0]  R1826     3.5546919703483582e-01
    z[6,7,0]  R1827     -7.3311340808868408e-01
    z[6,7,0]  R1828     -0.69478839635849
    z[6,7,0]  R1829     -6.0788959264755249e-01
    z[6,7,0]  R1830     9.3835823237895966e-02
    z[6,7,0]  R1831     3.0185481905937195e-01
    z[6,7,0]  R1832     6.9934844970703125e-02
    z[6,7,0]  R1833     -3.5546261817216873e-02
    z[6,7,0]  R1834     -2.1151846647262573e-01
    z[6,7,0]  R1835     2.6397460699081421e-01
    z[6,7,0]  R1836     1.4714916236698627e-02
    z[6,7,0]  R1837     -0.826717734336853
    z[6,7,0]  R1838     -5.6553375720977783e-01
    z[6,7,0]  R1839     -4.6557343006134033e-01
    z[6,7,0]  R1840     2.2465810179710388e-01
    z[6,7,0]  R1841     -7.3979392647743225e-02
    z[6,7,0]  R1842     -0.567614734172821
    z[6,7,0]  R1843     2.2830119729042053e-01
    z[6,7,0]  R1844     3.2732114195823669e-01
    z[6,7,0]  R1845     -2.1348632872104645e-01
    z[6,7,0]  R1846     -5.2942311763763428e-01
    z[6,7,0]  R1847     -4.3943038582801819e-01
    z[6,7,0]  R1848     -7.5273221731185913e-01
    z[6,7,0]  R1849     -2.6824358105659485e-01
    z[6,7,0]  R1850     -5.7141637802124023e-01
    z[6,7,0]  R1851     -7.9831665754318237e-01
    z[6,7,0]  R1852     2.3983244597911835e-01
    z[6,7,0]  R1853     -4.5837086439132690e-01
    z[6,7,0]  R1854     -2.7903449535369873e-01
    z[6,7,0]  R1855     -2.3343828320503235e-01
    z[6,7,0]  R1856     -1.9718140363693237e-01
    z[6,7,0]  R1857     1.6486378014087677e-01
    z[6,7,0]  R1858     -8.1450670957565308e-01
    z[6,7,0]  R1859     -2.9810729622840881e-01
    z[6,7,0]  R1860     0.346869558095932
    z[6,7,0]  R1861     1.3677033782005310e-01
    z[6,7,0]  R1862     -2.9752010107040405e-01
    z[6,7,0]  R1863     -2.8384643793106079e-01
    z[6,7,0]  R1864     1.6154052317142487e-01
    z[6,7,0]  R1865     -4.7044627368450165e-02
    z[6,7,0]  R1866     2.0723946392536163e-01
    z[6,7,0]  R1867     -0.820107102394104
    z[6,7,0]  R1868     -5.7578301429748535e-01
    z[6,7,0]  R1869     -0.0969822108745575
    z[6,7,0]  R1870     6.0532465577125549e-02
    z[6,7,0]  R1871     -4.2753165960311890e-01
    z[6,7,0]  R1872     -1.7922100424766541e-01
    z[6,7,0]  R1873     -5.5445814132690430e-01
    z[6,7,0]  R1874     0.257851779460907
    z[6,7,0]  R1875     -1.9561986625194550e-01
    z[6,7,0]  R1876     -7.6634180545806885e-01
    z[6,7,0]  R1877     -2.9960823059082031e-01
    z[6,7,0]  R1878     -6.7675042152404785e-01
    z[6,7,0]  R1879     -7.6143556833267212e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R1728     -1
    z[6,7,1]  R1729     1
    z[6,7,1]  R1740     4.0564718842506409e-01
    z[6,7,1]  R1741     2.2150342166423798e-01
    z[6,7,1]  R1742     7.5999921560287476e-01
    z[6,7,1]  R1743     8.0857682228088379e-01
    z[6,7,1]  R1744     6.7764484882354736e-01
    z[6,7,1]  R1745     6.8996334075927734e-01
    z[6,7,1]  R1746     6.9491308927536011e-01
    z[6,7,1]  R1747     7.1934080123901367e-01
    z[6,7,1]  R1748     5.3852117061614990e-01
    z[6,7,1]  R1749     4.8250377178192139e-01
    z[6,7,1]  R1750     -0.8618124127388
    z[6,7,1]  R1751     -8.8795089721679688e-01
    z[6,7,1]  R1752     -9.1304314136505127e-01
    z[6,7,1]  R1753     -7.7425575256347656e-01
    z[6,7,1]  R1754     -7.6965504884719849e-01
    z[6,7,1]  R1755     -7.8923708200454712e-01
    z[6,7,1]  R1756     -8.4171468019485474e-01
    z[6,7,1]  R1757     -8.9356827735900879e-01
    z[6,7,1]  R1758     -8.8723313808441162e-01
    z[6,7,1]  R1759     -0.852087140083313
    z[6,7,1]  R1760     1.7683847248554230e-01
    z[6,7,1]  R1761     -7.9349607229232788e-02
    z[6,7,1]  R1762     2.7236542105674744e-01
    z[6,7,1]  R1763     -1.4644323289394379e-01
    z[6,7,1]  R1764     -2.8788959980010986e-01
    z[6,7,1]  R1765     -6.1036145687103271e-01
    z[6,7,1]  R1766     -5.1336658000946045e-01
    z[6,7,1]  R1767     -6.2286847829818726e-01
    z[6,7,1]  R1768     -6.2361860275268555e-01
    z[6,7,1]  R1769     -0.288864403963089
    z[6,7,1]  R1770     1.6411490738391876e-02
    z[6,7,1]  R1771     1.8768697977066040e-01
    z[6,7,1]  R1772     -2.3674362897872925e-01
    z[6,7,1]  R1773     2.9516544938087463e-01
    z[6,7,1]  R1774     2.3874360322952271e-01
    z[6,7,1]  R1775     2.4278904497623444e-01
    z[6,7,1]  R1776     3.0271226167678833e-01
    z[6,7,1]  R1777     -5.8600634336471558e-02
    z[6,7,1]  R1778     2.9660817980766296e-01
    z[6,7,1]  R1779     4.3455091118812561e-01
    z[6,7,1]  R1780     5.2240979671478271e-01
    z[6,7,1]  R1781     -5.1190710067749023e-01
    z[6,7,1]  R1782     -4.8452475666999817e-01
    z[6,7,1]  R1783     -0.502964437007904
    z[6,7,1]  R1784     -4.7964704036712646e-01
    z[6,7,1]  R1785     -0.854331910610199
    z[6,7,1]  R1786     -5.2673918008804321e-01
    z[6,7,1]  R1787     -4.7937366366386414e-01
    z[6,7,1]  R1788     -7.8769600391387939e-01
    z[6,7,1]  R1789     -5.6490635871887207e-01
    z[6,7,1]  R1790     1.2438297271728516e-02
    z[6,7,1]  R1791     6.8744570016860962e-01
    z[6,7,1]  R1792     4.6005198359489441e-01
    z[6,7,1]  R1793     -7.7825301885604858e-01
    z[6,7,1]  R1794     -2.2731673717498779e-01
    z[6,7,1]  R1795     -6.9942563772201538e-01
    z[6,7,1]  R1796     -1.7192485928535461e-01
    z[6,7,1]  R1797     -1.9084727764129639e-01
    z[6,7,1]  R1798     -3.4105113148689270e-01
    z[6,7,1]  R1799     -2.1921217441558838e-01
    z[6,7,1]  R1800     6.6876864433288574e-01
    z[6,7,1]  R1801     2.2041143476963043e-01
    z[6,7,1]  R1802     2.5117090344429016e-01
    z[6,7,1]  R1803     1.6876345872879028e-01
    z[6,7,1]  R1804     -7.2898006439208984e-01
    z[6,7,1]  R1805     -7.4544352293014526e-01
    z[6,7,1]  R1806     -5.6649994850158691e-01
    z[6,7,1]  R1807     -0.865119218826294
    z[6,7,1]  R1808     -0.507922351360321
    z[6,7,1]  R1809     -0.618511438369751
    z[6,7,1]  R1810     -2.1649330854415894e-01
    z[6,7,1]  R1811     3.0930796265602112e-01
    z[6,7,1]  R1812     8.4924995899200439e-01
    z[6,7,1]  R1813     4.2335382103919983e-01
    z[6,7,1]  R1814     4.6006661653518677e-01
    z[6,7,1]  R1815     7.8704708814620972e-01
    z[6,7,1]  R1816     -7.1661293506622314e-01
    z[6,7,1]  R1817     -7.4266058206558228e-01
    z[6,7,1]  R1818     -8.4290659427642822e-01
    z[6,7,1]  R1819     -4.6834820508956909e-01
    z[6,7,1]  R1820     3.1773579120635986e-01
    z[6,7,1]  R1821     3.5326966643333435e-01
    z[6,7,1]  R1822     -8.7270236015319824e-01
    z[6,7,1]  R1823     -8.1956350803375244e-01
    z[6,7,1]  R1824     6.7453527450561523e-01
    z[6,7,1]  R1825     -5.3128945827484131e-01
    z[6,7,1]  R1826     -0.854092001914978
    z[6,7,1]  R1827     1.3329645991325378e-01
    z[6,7,1]  R1828     1.7880636453628540e-01
    z[6,7,1]  R1829     -1.1599297635257244e-02
    z[6,7,1]  R1830     7.3112434148788452e-01
    z[6,7,1]  R1831     3.0246776342391968e-01
    z[6,7,1]  R1832     -6.0424768924713135e-01
    z[6,7,1]  R1833     -0.900780975818634
    z[6,7,1]  R1834     -7.2514319419860840e-01
    z[6,7,1]  R1835     4.5567423105239868e-01
    z[6,7,1]  R1836     -6.1548978090286255e-01
    z[6,7,1]  R1837     -2.8613340854644775e-01
    z[6,7,1]  R1838     2.3322394490242004e-01
    z[6,7,1]  R1839     2.5845530629158020e-01
    z[6,7,1]  R1840     4.8997023701667786e-01
    z[6,7,1]  R1841     4.0439867973327637e-01
    z[6,7,1]  R1842     -0.656741201877594
    z[6,7,1]  R1843     -8.8230144977569580e-01
    z[6,7,1]  R1844     -8.0567622184753418e-01
    z[6,7,1]  R1845     -5.0674062967300415e-01
    z[6,7,1]  R1846     -5.5835723876953125e-01
    z[6,7,1]  R1847     1.6405096650123596e-01
    z[6,7,1]  R1848     4.2379528284072876e-02
    z[6,7,1]  R1849     -2.6594796776771545e-01
    z[6,7,1]  R1850     -5.7925939559936523e-01
    z[6,7,1]  R1851     -5.6226819753646851e-01
    z[6,7,1]  R1852     -7.9547297954559326e-01
    z[6,7,1]  R1853     -6.3943260908126831e-01
    z[6,7,1]  R1854     -5.9386724233627319e-01
    z[6,7,1]  R1855     -7.3498421907424927e-01
    z[6,7,1]  R1856     -3.1208464503288269e-01
    z[6,7,1]  R1857     -6.8900579214096069e-01
    z[6,7,1]  R1858     -3.7101477384567261e-01
    z[6,7,1]  R1859     6.6063500940799713e-02
    z[6,7,1]  R1860     5.4832839965820312e-01
    z[6,7,1]  R1861     5.9515094757080078e-01
    z[6,7,1]  R1862     -7.0391672849655151e-01
    z[6,7,1]  R1863     -6.7108732461929321e-01
    z[6,7,1]  R1864     -0.752247154712677
    z[6,7,1]  R1865     -8.9022374153137207e-01
    z[6,7,1]  R1866     -7.2310638427734375e-01
    z[6,7,1]  R1867     2.3239577189087868e-02
    z[6,7,1]  R1868     -2.1518308669328690e-02
    z[6,7,1]  R1869     -4.8537105321884155e-01
    z[6,7,1]  R1870     2.7299115061759949e-01
    z[6,7,1]  R1871     -6.1635011434555054e-01
    z[6,7,1]  R1872     -8.9283865690231323e-01
    z[6,7,1]  R1873     -6.3888096809387207e-01
    z[6,7,1]  R1874     0.512329638004303
    z[6,7,1]  R1875     -2.2371679544448853e-01
    z[6,7,1]  R1876     -3.9436888694763184e-01
    z[6,7,1]  R1877     -4.8325982689857483e-01
    z[6,7,1]  R1878     3.8783061504364014e-01
    z[6,7,1]  R1879     2.6828026771545410e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R1730     -1
    z[6,7,2]  R1731     1
    z[6,7,2]  R1740     -3.4663298726081848e-01
    z[6,7,2]  R1741     9.0632744133472443e-02
    z[6,7,2]  R1742     -2.2049550712108612e-01
    z[6,7,2]  R1743     2.9269057512283325e-01
    z[6,7,2]  R1744     4.2941588163375854e-01
    z[6,7,2]  R1745     1.9265830516815186e-01
    z[6,7,2]  R1746     4.5219299197196960e-01
    z[6,7,2]  R1747     -0.402471125125885
    z[6,7,2]  R1748     4.4798237085342407e-01
    z[6,7,2]  R1749     -3.9822395890951157e-02
    z[6,7,2]  R1750     1.3586680591106415e-01
    z[6,7,2]  R1751     7.3633953928947449e-02
    z[6,7,2]  R1752     -2.1363621950149536e-01
    z[6,7,2]  R1753     -2.0699515938758850e-01
    z[6,7,2]  R1754     4.3758027255535126e-02
    z[6,7,2]  R1755     -1.8099133670330048e-01
    z[6,7,2]  R1756     2.9156863689422607e-02
    z[6,7,2]  R1757     1.8243777751922607e-01
    z[6,7,2]  R1758     -0.0689927414059639
    z[6,7,2]  R1759     -3.3757713437080383e-01
    z[6,7,2]  R1760     -9.5141483470797539e-03
    z[6,7,2]  R1761     3.0076336860656738e-01
    z[6,7,2]  R1762     -3.8881582021713257e-01
    z[6,7,2]  R1763     4.2071306705474854e-01
    z[6,7,2]  R1764     2.2023412585258484e-01
    z[6,7,2]  R1765     -2.4554346501827240e-01
    z[6,7,2]  R1766     -4.2343845963478088e-01
    z[6,7,2]  R1767     4.6115991473197937e-01
    z[6,7,2]  R1768     1.1870677024126053e-01
    z[6,7,2]  R1769     -8.8434182107448578e-02
    z[6,7,2]  R1770     2.5777277350425720e-01
    z[6,7,2]  R1771     -1.1954865604639053e-01
    z[6,7,2]  R1772     1.0909274965524673e-01
    z[6,7,2]  R1773     -1.0482856631278992e-01
    z[6,7,2]  R1774     -2.9389381408691406e-01
    z[6,7,2]  R1775     -0.358809232711792
    z[6,7,2]  R1776     -0.108444444835186
    z[6,7,2]  R1777     1.3620543479919434e-01
    z[6,7,2]  R1778     -9.4696566462516785e-02
    z[6,7,2]  R1779     -2.3804001510143280e-01
    z[6,7,2]  R1780     4.7510975599288940e-01
    z[6,7,2]  R1781     -4.3975785374641418e-01
    z[6,7,2]  R1782     -6.3251811265945435e-01
    z[6,7,2]  R1783     -6.5593171119689941e-01
    z[6,7,2]  R1784     -3.6732786893844604e-01
    z[6,7,2]  R1785     5.5395025759935379e-02
    z[6,7,2]  R1786     -5.7521623373031616e-01
    z[6,7,2]  R1787     -5.3364193439483643e-01
    z[6,7,2]  R1788     -4.8240253329277039e-01
    z[6,7,2]  R1789     -4.0648695826530457e-01
    z[6,7,2]  R1790     7.5240141153335571e-01
    z[6,7,2]  R1791     2.6230162382125854e-01
    z[6,7,2]  R1792     -1.4601278118789196e-02
    z[6,7,2]  R1793     1.1752258241176605e-01
    z[6,7,2]  R1794     5.1802337169647217e-01
    z[6,7,2]  R1795     -8.5014671087265015e-02
    z[6,7,2]  R1796     -4.3336819857358932e-02
    z[6,7,2]  R1797     -6.9281840696930885e-03
    z[6,7,2]  R1798     2.6703259348869324e-01
    z[6,7,2]  R1799     4.8138287663459778e-01
    z[6,7,2]  R1800     6.2798202037811279e-01
    z[6,7,2]  R1801     5.0892859697341919e-01
    z[6,7,2]  R1802     3.6279958486557007e-01
    z[6,7,2]  R1803     3.9509826898574829e-01
    z[6,7,2]  R1804     -1.8965192139148712e-01
    z[6,7,2]  R1805     -4.0701773762702942e-01
    z[6,7,2]  R1806     -3.4555483609437943e-02
    z[6,7,2]  R1807     -3.2562226057052612e-02
    z[6,7,2]  R1808     -1.1808338761329651e-01
    z[6,7,2]  R1809     -3.9527878165245056e-01
    z[6,7,2]  R1810     2.0764118060469627e-02
    z[6,7,2]  R1811     3.7314009666442871e-01
    z[6,7,2]  R1812     1.9965112209320068e-01
    z[6,7,2]  R1813     5.7231187820434570e-01
    z[6,7,2]  R1814     1.8976931273937225e-01
    z[6,7,2]  R1815     1.5339636802673340e-01
    z[6,7,2]  R1816     -3.3698305487632751e-01
    z[6,7,2]  R1817     -6.9558590650558472e-02
    z[6,7,2]  R1818     -2.9084178805351257e-01
    z[6,7,2]  R1819     1.6147981584072113e-01
    z[6,7,2]  R1820     5.5289882421493530e-01
    z[6,7,2]  R1821     5.6592386960983276e-01
    z[6,7,2]  R1822     -2.6835048198699951e-01
    z[6,7,2]  R1823     -4.5116010308265686e-01
    z[6,7,2]  R1824     3.9275681972503662e-01
    z[6,7,2]  R1825     1.4864921569824219e-01
    z[6,7,2]  R1826     1.4777974784374237e-01
    z[6,7,2]  R1827     1.4433830045163631e-02
    z[6,7,2]  R1828     5.8649875223636627e-02
    z[6,7,2]  R1829     9.5928184688091278e-02
    z[6,7,2]  R1830     2.0550854504108429e-01
    z[6,7,2]  R1831     0.733496904373169
    z[6,7,2]  R1832     -3.0421867966651917e-01
    z[6,7,2]  R1833     4.0832184255123138e-02
    z[6,7,2]  R1834     -2.1121737360954285e-01
    z[6,7,2]  R1835     -2.3063591122627258e-01
    z[6,7,2]  R1836     -1.8074475228786469e-01
    z[6,7,2]  R1837     2.3348145186901093e-01
    z[6,7,2]  R1838     -5.4902553558349609e-02
    z[6,7,2]  R1839     -1.1982156336307526e-01
    z[6,7,2]  R1840     4.7163677215576172e-01
    z[6,7,2]  R1841     4.8232552409172058e-01
    z[6,7,2]  R1842     9.2045597732067108e-02
    z[6,7,2]  R1843     4.4353265315294266e-02
    z[6,7,2]  R1844     -0.0972619354724884
    z[6,7,2]  R1845     -2.3143781721591949e-01
    z[6,7,2]  R1846     3.4219604730606079e-01
    z[6,7,2]  R1847     -1.6744692623615265e-01
    z[6,7,2]  R1848     -3.4664005041122437e-01
    z[6,7,2]  R1849     -7.7150254510343075e-03
    z[6,7,2]  R1850     -3.6362352967262268e-01
    z[6,7,2]  R1851     1.8867236375808716e-01
    z[6,7,2]  R1852     -3.1880292296409607e-01
    z[6,7,2]  R1853     2.4227949976921082e-01
    z[6,7,2]  R1854     2.2747018933296204e-01
    z[6,7,2]  R1855     1.7310473322868347e-01
    z[6,7,2]  R1856     2.0147490501403809e-01
    z[6,7,2]  R1857     -3.0700030922889709e-01
    z[6,7,2]  R1858     1.7181381583213806e-02
    z[6,7,2]  R1859     -2.2931785881519318e-01
    z[6,7,2]  R1860     6.6481626033782959e-01
    z[6,7,2]  R1861     2.7252513170242310e-01
    z[6,7,2]  R1862     -2.7540338039398193e-01
    z[6,7,2]  R1863     7.6584428548812866e-02
    z[6,7,2]  R1864     -5.7331192493438721e-01
    z[6,7,2]  R1865     -2.6023969054222107e-01
    z[6,7,2]  R1866     -2.5527155399322510e-01
    z[6,7,2]  R1867     -1.5020149759948254e-02
    z[6,7,2]  R1868     -6.1559706926345825e-02
    z[6,7,2]  R1869     7.7393390238285065e-02
    z[6,7,2]  R1870     6.6374713182449341e-01
    z[6,7,2]  R1871     1.5252985060214996e-01
    z[6,7,2]  R1872     -3.3343076705932617e-01
    z[6,7,2]  R1873     -3.8093057274818420e-01
    z[6,7,2]  R1874     -4.5072987675666809e-01
    z[6,7,2]  R1875     3.1683048605918884e-01
    z[6,7,2]  R1876     -6.4119093120098114e-02
    z[6,7,2]  R1877     1.8009927123785019e-02
    z[6,7,2]  R1878     -5.0373566150665283e-01
    z[6,7,2]  R1879     -5.5464059114456177e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R1732     -1
    z[6,7,3]  R1733     1
    z[6,7,3]  R1740     -4.8990166187286377e-01
    z[6,7,3]  R1741     -3.9430651068687439e-01
    z[6,7,3]  R1742     0.46151003241539
    z[6,7,3]  R1743     -2.4853320419788361e-01
    z[6,7,3]  R1744     -0.0752018466591835
    z[6,7,3]  R1745     4.7317335009574890e-01
    z[6,7,3]  R1746     1.9617833197116852e-01
    z[6,7,3]  R1747     2.4148421362042427e-02
    z[6,7,3]  R1748     -1.8303368985652924e-01
    z[6,7,3]  R1749     -6.1512148380279541e-01
    z[6,7,3]  R1750     -3.2610893249511719e-01
    z[6,7,3]  R1751     -4.0407484769821167e-01
    z[6,7,3]  R1752     2.0927238464355469e-01
    z[6,7,3]  R1753     -5.3526580333709717e-01
    z[6,7,3]  R1754     -5.4303711652755737e-01
    z[6,7,3]  R1755     -4.6658292412757874e-01
    z[6,7,3]  R1756     -3.6240440607070923e-01
    z[6,7,3]  R1757     -2.0387594401836395e-01
    z[6,7,3]  R1758     -1.6399122774600983e-01
    z[6,7,3]  R1759     2.0753040909767151e-01
    z[6,7,3]  R1760     -3.4860542416572571e-01
    z[6,7,3]  R1761     -0.545215904712677
    z[6,7,3]  R1762     0.0992526262998581
    z[6,7,3]  R1763     6.3176751136779785e-01
    z[6,7,3]  R1764     1.9093842804431915e-01
    z[6,7,3]  R1765     3.1614455580711365e-01
    z[6,7,3]  R1766     2.0861414074897766e-01
    z[6,7,3]  R1767     4.4924274086952209e-01
    z[6,7,3]  R1768     4.8011621832847595e-01
    z[6,7,3]  R1769     1.5854936838150024e-01
    z[6,7,3]  R1770     3.6191475391387939e-01
    z[6,7,3]  R1771     2.7237620949745178e-01
    z[6,7,3]  R1772     6.7980909347534180e-01
    z[6,7,3]  R1773     7.3311723768711090e-02
    z[6,7,3]  R1774     0.42009437084198
    z[6,7,3]  R1775     2.3003891110420227e-01
    z[6,7,3]  R1776     3.1932342052459717e-01
    z[6,7,3]  R1777     3.5840702056884766e-01
    z[6,7,3]  R1778     5.6651169061660767e-01
    z[6,7,3]  R1779     2.8356346487998962e-01
    z[6,7,3]  R1780     -5.6767380237579346e-01
    z[6,7,3]  R1781     -3.6865150928497314e-01
    z[6,7,3]  R1782     -3.7740305066108704e-01
    z[6,7,3]  R1783     -5.0571990013122559e-01
    z[6,7,3]  R1784     -0.410660982131958
    z[6,7,3]  R1785     2.1263739466667175e-01
    z[6,7,3]  R1786     -5.3038388490676880e-01
    z[6,7,3]  R1787     -5.2300339937210083e-01
    z[6,7,3]  R1788     -2.2139649093151093e-01
    z[6,7,3]  R1789     -4.4104033708572388e-01
    z[6,7,3]  R1790     -3.6225321888923645e-01
    z[6,7,3]  R1791     1.0925932228565216e-01
    z[6,7,3]  R1792     -7.1278387308120728e-01
    z[6,7,3]  R1793     2.1688152849674225e-01
    z[6,7,3]  R1794     -6.9918829202651978e-01
    z[6,7,3]  R1795     2.2615356743335724e-01
    z[6,7,3]  R1796     -9.6766859292984009e-02
    z[6,7,3]  R1797     -1.0856787860393524e-01
    z[6,7,3]  R1798     -7.7130466699600220e-02
    z[6,7,3]  R1799     -2.0936983823776245e-01
    z[6,7,3]  R1800     5.5666558444499969e-02
    z[6,7,3]  R1801     -4.1393363475799561e-01
    z[6,7,3]  R1802     -7.4532374739646912e-02
    z[6,7,3]  R1803     -3.2952728867530823e-01
    z[6,7,3]  R1804     5.7273630052804947e-02
    z[6,7,3]  R1805     3.5371991991996765e-01
    z[6,7,3]  R1806     6.2036764621734619e-01
    z[6,7,3]  R1807     0.174591064453125
    z[6,7,3]  R1808     -6.5473616123199463e-02
    z[6,7,3]  R1809     9.8076008260250092e-02
    z[6,7,3]  R1810     0.54584139585495
    z[6,7,3]  R1811     -5.0053983926773071e-01
    z[6,7,3]  R1812     -6.7424766719341278e-02
    z[6,7,3]  R1813     -4.1990217566490173e-01
    z[6,7,3]  R1814     -4.7919595241546631e-01
    z[6,7,3]  R1815     -4.7395061701536179e-02
    z[6,7,3]  R1816     -7.9899743199348450e-02
    z[6,7,3]  R1817     3.8864096999168396e-01
    z[6,7,3]  R1818     0.112656369805336
    z[6,7,3]  R1819     -1.6416944563388824e-01
    z[6,7,3]  R1820     -1.8139523267745972e-01
    z[6,7,3]  R1821     -3.0042198300361633e-01
    z[6,7,3]  R1822     2.0458501577377319e-01
    z[6,7,3]  R1823     0.299461305141449
    z[6,7,3]  R1824     -3.0456364154815674e-01
    z[6,7,3]  R1825     6.3462370634078979e-01
    z[6,7,3]  R1826     -3.1808264553546906e-02
    z[6,7,3]  R1827     -6.1111348867416382e-01
    z[6,7,3]  R1828     -4.4662916660308838e-01
    z[6,7,3]  R1829     -7.2431737184524536e-01
    z[6,7,3]  R1830     -9.9267408251762390e-02
    z[6,7,3]  R1831     -2.1639212965965271e-01
    z[6,7,3]  R1832     4.5839720964431763e-01
    z[6,7,3]  R1833     -1.2969951145350933e-02
    z[6,7,3]  R1834     1.9489879906177521e-01
    z[6,7,3]  R1835     -0.739753782749176
    z[6,7,3]  R1836     4.2342305183410645e-01
    z[6,7,3]  R1837     -1.6215343773365021e-01
    z[6,7,3]  R1838     -6.8730795383453369e-01
    z[6,7,3]  R1839     -8.0857044458389282e-01
    z[6,7,3]  R1840     -4.8054140806198120e-01
    z[6,7,3]  R1841     6.1848795413970947e-01
    z[6,7,3]  R1842     -2.5894984602928162e-01
    z[6,7,3]  R1843     2.4202822148799896e-01
    z[6,7,3]  R1844     2.5243896525353193e-03
    z[6,7,3]  R1845     5.7796555757522583e-01
    z[6,7,3]  R1846     3.4566736221313477e-01
    z[6,7,3]  R1847     -7.0362383127212524e-01
    z[6,7,3]  R1848     -3.6247396469116211e-01
    z[6,7,3]  R1849     -0.738812267780304
    z[6,7,3]  R1850     -4.3917959928512573e-01
    z[6,7,3]  R1851     -6.6205725073814392e-02
    z[6,7,3]  R1852     2.7190076652914286e-03
    z[6,7,3]  R1853     4.7790881991386414e-01
    z[6,7,3]  R1854     6.6536128520965576e-01
    z[6,7,3]  R1855     2.6913082599639893e-01
    z[6,7,3]  R1856     8.1416743993759155e-01
    z[6,7,3]  R1857     7.6190240681171417e-02
    z[6,7,3]  R1858     7.1276850998401642e-02
    z[6,7,3]  R1859     -8.8126683235168457e-01
    z[6,7,3]  R1860     -2.3248299956321716e-01
    z[6,7,3]  R1861     -1.1482724547386169e-01
    z[6,7,3]  R1862     4.6430990099906921e-01
    z[6,7,3]  R1863     5.5468821525573730e-01
    z[6,7,3]  R1864     1.5193149447441101e-02
    z[6,7,3]  R1865     -3.2171458005905151e-02
    z[6,7,3]  R1866     5.1962349563837051e-02
    z[6,7,3]  R1867     -5.0766462087631226e-01
    z[6,7,3]  R1868     -7.0269167423248291e-01
    z[6,7,3]  R1869     3.8918992877006531e-01
    z[6,7,3]  R1870     -3.2630622386932373e-01
    z[6,7,3]  R1871     5.4890251159667969e-01
    z[6,7,3]  R1872     3.0041038990020752e-02
    z[6,7,3]  R1873     -7.0372693240642548e-02
    z[6,7,3]  R1874     -6.6674917936325073e-01
    z[6,7,3]  R1875     8.2571476697921753e-01
    z[6,7,3]  R1876     1.8634662032127380e-01
    z[6,7,3]  R1877     -5.4187369346618652e-01
    z[6,7,3]  R1878     -1.8501089513301849e-01
    z[6,7,3]  R1879     1.1763103306293488e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R1734     -1
    z[6,7,4]  R1735     1
    z[6,7,4]  R1740     -5.2042442560195923e-01
    z[6,7,4]  R1741     -7.6170068979263306e-01
    z[6,7,4]  R1742     -1.9811517000198364e-01
    z[6,7,4]  R1743     -3.4133148193359375e-01
    z[6,7,4]  R1744     -3.3587660640478134e-02
    z[6,7,4]  R1745     4.7299563884735107e-02
    z[6,7,4]  R1746     4.8518773913383484e-01
    z[6,7,4]  R1747     -1.8480852246284485e-01
    z[6,7,4]  R1748     2.7453845739364624e-01
    z[6,7,4]  R1749     4.5313492417335510e-01
    z[6,7,4]  R1750     3.7386257201433182e-02
    z[6,7,4]  R1751     1.2197016924619675e-01
    z[6,7,4]  R1752     -5.4741352796554565e-02
    z[6,7,4]  R1753     7.8208781778812408e-02
    z[6,7,4]  R1754     1.5961837768554688e-01
    z[6,7,4]  R1755     2.8302788734436035e-01
    z[6,7,4]  R1756     3.1871438026428223e-01
    z[6,7,4]  R1757     1.2767308950424194e-01
    z[6,7,4]  R1758     -2.8134299442172050e-02
    z[6,7,4]  R1759     -3.0184331536293030e-01
    z[6,7,4]  R1760     0.159694641828537
    z[6,7,4]  R1761     4.5935627818107605e-01
    z[6,7,4]  R1762     4.9985128641128540e-01
    z[6,7,4]  R1763     -3.1561404466629028e-01
    z[6,7,4]  R1764     6.6229745745658875e-02
    z[6,7,4]  R1765     -1.8067894876003265e-01
    z[6,7,4]  R1766     4.0252575278282166e-01
    z[6,7,4]  R1767     3.4419393539428711e-01
    z[6,7,4]  R1768     3.2462656497955322e-01
    z[6,7,4]  R1769     2.9222598671913147e-01
    z[6,7,4]  R1770     1.6483603417873383e-01
    z[6,7,4]  R1771     -2.0548866689205170e-01
    z[6,7,4]  R1772     -1.2014985829591751e-01
    z[6,7,4]  R1773     2.9497590661048889e-01
    z[6,7,4]  R1774     1.4236049354076385e-01
    z[6,7,4]  R1775     2.5435414910316467e-01
    z[6,7,4]  R1776     1.6347086429595947e-01
    z[6,7,4]  R1777     -4.1072311997413635e-01
    z[6,7,4]  R1778     -2.4284815788269043e-01
    z[6,7,4]  R1779     -1.8633264303207397e-01
    z[6,7,4]  R1780     3.5102775692939758e-01
    z[6,7,4]  R1781     -4.9579218029975891e-01
    z[6,7,4]  R1782     -0.420878142118454
    z[6,7,4]  R1783     -1.1079634726047516e-01
    z[6,7,4]  R1784     -4.8875716328620911e-01
    z[6,7,4]  R1785     -3.1739141792058945e-02
    z[6,7,4]  R1786     -1.8995173275470734e-01
    z[6,7,4]  R1787     8.6141005158424377e-03
    z[6,7,4]  R1788     -2.5475943088531494e-01
    z[6,7,4]  R1789     -4.2808291316032410e-01
    z[6,7,4]  R1790     -1.7352880537509918e-01
    z[6,7,4]  R1791     2.0763443410396576e-01
    z[6,7,4]  R1792     -1.5970483422279358e-01
    z[6,7,4]  R1793     -0.164675772190094
    z[6,7,4]  R1794     6.9020465016365051e-02
    z[6,7,4]  R1795     3.3810202032327652e-02
    z[6,7,4]  R1796     2.0591814070940018e-02
    z[6,7,4]  R1797     1.2437465041875839e-01
    z[6,7,4]  R1798     2.7689921855926514e-01
    z[6,7,4]  R1799     1.0139914602041245e-01
    z[6,7,4]  R1800     -7.4027101509273052e-03
    z[6,7,4]  R1801     -9.2984713613986969e-02
    z[6,7,4]  R1802     5.7830739021301270e-01
    z[6,7,4]  R1803     5.7642382383346558e-01
    z[6,7,4]  R1804     9.1092668473720551e-02
    z[6,7,4]  R1805     -2.9985904693603516e-01
    z[6,7,4]  R1806     -3.4815132617950439e-01
    z[6,7,4]  R1807     -5.8498740196228027e-02
    z[6,7,4]  R1808     2.5201949477195740e-01
    z[6,7,4]  R1809     1.6721126437187195e-01
    z[6,7,4]  R1810     1.5844435989856720e-01
    z[6,7,4]  R1811     3.3917296677827835e-03
    z[6,7,4]  R1812     -1.0530129820108414e-01
    z[6,7,4]  R1813     -3.4999931231141090e-03
    z[6,7,4]  R1814     1.9685381650924683e-01
    z[6,7,4]  R1815     4.1764539480209351e-01
    z[6,7,4]  R1816     1.4651700854301453e-01
    z[6,7,4]  R1817     4.3963202834129333e-01
    z[6,7,4]  R1818     3.0410623550415039e-01
    z[6,7,4]  R1819     1.7601549625396729e-01
    z[6,7,4]  R1820     -1.3534653186798096e-01
    z[6,7,4]  R1821     4.7975964844226837e-02
    z[6,7,4]  R1822     1.0215112566947937e-01
    z[6,7,4]  R1823     -0.0791703388094902
    z[6,7,4]  R1824     -1.5117718279361725e-01
    z[6,7,4]  R1825     -0.000655064475722611
    z[6,7,4]  R1826     -1.3639484345912933e-01
    z[6,7,4]  R1827     -1.7070990800857544e-01
    z[6,7,4]  R1828     -4.9967950582504272e-01
    z[6,7,4]  R1829     -1.6937865316867828e-01
    z[6,7,4]  R1830     5.0345176458358765e-01
    z[6,7,4]  R1831     -1.9321238994598389e-01
    z[6,7,4]  R1832     -0.510749340057373
    z[6,7,4]  R1833     -1.7659065127372742e-01
    z[6,7,4]  R1834     -3.2749277353286743e-01
    z[6,7,4]  R1835     -1.6959272325038910e-01
    z[6,7,4]  R1836     -2.5101867318153381e-01
    z[6,7,4]  R1837     -3.8920632004737854e-01
    z[6,7,4]  R1838     -3.8718926906585693e-01
    z[6,7,4]  R1839     -1.7540577054023743e-01
    z[6,7,4]  R1840     2.6764786243438721e-01
    z[6,7,4]  R1841     2.7633774280548096e-01
    z[6,7,4]  R1842     2.6715666055679321e-01
    z[6,7,4]  R1843     1.8802155554294586e-01
    z[6,7,4]  R1844     -1.0254956036806107e-01
    z[6,7,4]  R1845     2.7900439500808716e-01
    z[6,7,4]  R1846     1.4084173738956451e-01
    z[6,7,4]  R1847     -3.8704228401184082e-01
    z[6,7,4]  R1848     7.1601629257202148e-02
    z[6,7,4]  R1849     1.6826494038105011e-01
    z[6,7,4]  R1850     6.9450519979000092e-02
    z[6,7,4]  R1851     5.5063869804143906e-02
    z[6,7,4]  R1852     1.9221821799874306e-02
    z[6,7,4]  R1853     0.0171035286039114
    z[6,7,4]  R1854     2.2876986861228943e-01
    z[6,7,4]  R1855     -2.5459113717079163e-01
    z[6,7,4]  R1856     7.4961505830287933e-02
    z[6,7,4]  R1857     -1.6473822295665741e-01
    z[6,7,4]  R1858     -3.0694943666458130e-01
    z[6,7,4]  R1859     -2.2959465160965919e-02
    z[6,7,4]  R1860     9.0642586350440979e-02
    z[6,7,4]  R1861     4.7416013479232788e-01
    z[6,7,4]  R1862     1.4224231243133545e-01
    z[6,7,4]  R1863     -3.5413238406181335e-01
    z[6,7,4]  R1864     8.0844148993492126e-02
    z[6,7,4]  R1865     2.1051813662052155e-01
    z[6,7,4]  R1866     -1.5900759398937225e-01
    z[6,7,4]  R1867     -2.7241092175245285e-02
    z[6,7,4]  R1868     1.8105036020278931e-01
    z[6,7,4]  R1869     6.2217503786087036e-01
    z[6,7,4]  R1870     3.6257752776145935e-01
    z[6,7,4]  R1871     -1.5457384288311005e-01
    z[6,7,4]  R1872     1.6399468481540680e-01
    z[6,7,4]  R1873     7.4029639363288879e-02
    z[6,7,4]  R1874     3.4444069024175406e-03
    z[6,7,4]  R1875     2.1715784445405006e-02
    z[6,7,4]  R1876     -1.1888762563467026e-01
    z[6,7,4]  R1877     -1.4770109951496124e-01
    z[6,7,4]  R1878     -2.0655460655689240e-01
    z[6,7,4]  R1879     1.4602577686309814e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R1736     -1
    z[6,7,5]  R1737     1
    z[6,7,5]  R1740     3.5878576338291168e-02
    z[6,7,5]  R1741     -8.7139256298542023e-02
    z[6,7,5]  R1742     7.0316776633262634e-02
    z[6,7,5]  R1743     -4.3579056859016418e-02
    z[6,7,5]  R1744     2.8673139214515686e-01
    z[6,7,5]  R1745     4.2939415574073792e-01
    z[6,7,5]  R1746     -0.0457756407558918
    z[6,7,5]  R1747     4.9169689416885376e-01
    z[6,7,5]  R1748     0.598415195941925
    z[6,7,5]  R1749     2.3235686123371124e-01
    z[6,7,5]  R1750     4.0108706802129745e-02
    z[6,7,5]  R1751     -4.2695008218288422e-02
    z[6,7,5]  R1752     -6.1412472277879715e-02
    z[6,7,5]  R1753     1.9556295871734619e-01
    z[6,7,5]  R1754     1.6959644854068756e-01
    z[6,7,5]  R1755     2.7440250851213932e-03
    z[6,7,5]  R1756     1.1292400211095810e-01
    z[6,7,5]  R1757     1.4733427762985229e-01
    z[6,7,5]  R1758     1.5611982345581055e-01
    z[6,7,5]  R1759     -1.3234174251556396e-01
    z[6,7,5]  R1760     -5.2889758348464966e-01
    z[6,7,5]  R1761     -4.0778699517250061e-01
    z[6,7,5]  R1762     -4.3332013487815857e-01
    z[6,7,5]  R1763     -3.9692139625549316e-01
    z[6,7,5]  R1764     1.8549689650535583e-01
    z[6,7,5]  R1765     6.4147424697875977e-01
    z[6,7,5]  R1766     4.3304291367530823e-01
    z[6,7,5]  R1767     2.6354651898145676e-02
    z[6,7,5]  R1768     3.8828876614570618e-01
    z[6,7,5]  R1769     1.9409877061843872e-01
    z[6,7,5]  R1770     3.6157190799713135e-01
    z[6,7,5]  R1771     8.6428232491016388e-02
    z[6,7,5]  R1772     1.7475946247577667e-01
    z[6,7,5]  R1773     2.1422280371189117e-01
    z[6,7,5]  R1774     -2.6312029361724854e-01
    z[6,7,5]  R1775     -1.1258765310049057e-01
    z[6,7,5]  R1776     -6.9279879331588745e-02
    z[6,7,5]  R1777     2.6745384931564331e-01
    z[6,7,5]  R1778     -2.8706169128417969e-01
    z[6,7,5]  R1779     -2.1840818226337433e-01
    z[6,7,5]  R1780     -1.7786248028278351e-01
    z[6,7,5]  R1781     -2.1726746112108231e-02
    z[6,7,5]  R1782     -6.3736066222190857e-02
    z[6,7,5]  R1783     3.1286545097827911e-02
    z[6,7,5]  R1784     7.8133922070264816e-03
    z[6,7,5]  R1785     1.1068589985370636e-01
    z[6,7,5]  R1786     2.6434719562530518e-01
    z[6,7,5]  R1787     0.0418284609913826
    z[6,7,5]  R1788     1.6630619764328003e-01
    z[6,7,5]  R1789     2.8218093514442444e-01
    z[6,7,5]  R1790     -0.478199303150177
    z[6,7,5]  R1791     -1.9420586526393890e-01
    z[6,7,5]  R1792     -7.1430094540119171e-02
    z[6,7,5]  R1793     -0.292460560798645
    z[6,7,5]  R1794     2.2123925387859344e-01
    z[6,7,5]  R1795     -4.1238903999328613e-01
    z[6,7,5]  R1796     -3.6590325832366943e-01
    z[6,7,5]  R1797     -3.0864715576171875e-01
    z[6,7,5]  R1798     -3.1340357661247253e-01
    z[6,7,5]  R1799     1.8844987452030182e-01
    z[6,7,5]  R1800     -3.8047227263450623e-01
    z[6,7,5]  R1801     -2.8123003244400024e-01
    z[6,7,5]  R1802     -3.0721798539161682e-01
    z[6,7,5]  R1803     -3.0520227551460266e-01
    z[6,7,5]  R1804     -2.6596600189805031e-02
    z[6,7,5]  R1805     -2.2794160246849060e-01
    z[6,7,5]  R1806     -2.9888552427291870e-01
    z[6,7,5]  R1807     2.7011623978614807e-01
    z[6,7,5]  R1808     -1.4479759335517883e-01
    z[6,7,5]  R1809     -3.0097526311874390e-01
    z[6,7,5]  R1810     1.1131688207387924e-01
    z[6,7,5]  R1811     -3.7510967254638672e-01
    z[6,7,5]  R1812     -1.9735524058341980e-01
    z[6,7,5]  R1813     -1.3828532397747040e-01
    z[6,7,5]  R1814     -3.4852313995361328e-01
    z[6,7,5]  R1815     -2.5787869095802307e-01
    z[6,7,5]  R1816     -1.0327735543251038e-01
    z[6,7,5]  R1817     1.2150023831054568e-03
    z[6,7,5]  R1818     -2.3134063184261322e-01
    z[6,7,5]  R1819     4.0065199136734009e-02
    z[6,7,5]  R1820     -5.5110651254653931e-01
    z[6,7,5]  R1821     4.4556212425231934e-01
    z[6,7,5]  R1822     2.4070987105369568e-01
    z[6,7,5]  R1823     -1.0796731710433960e-01
    z[6,7,5]  R1824     2.1233783662319183e-01
    z[6,7,5]  R1825     -1.3205768167972565e-01
    z[6,7,5]  R1826     -2.4533860385417938e-01
    z[6,7,5]  R1827     -3.0848110094666481e-02
    z[6,7,5]  R1828     -1.4587184786796570e-01
    z[6,7,5]  R1829     0.252546489238739
    z[6,7,5]  R1830     -3.6108851432800293e-01
    z[6,7,5]  R1831     1.9542382657527924e-01
    z[6,7,5]  R1832     -2.3221735656261444e-01
    z[6,7,5]  R1833     -3.7104284763336182e-01
    z[6,7,5]  R1834     -4.8415485769510269e-02
    z[6,7,5]  R1835     2.5979939103126526e-01
    z[6,7,5]  R1836     -1.2629453837871552e-01
    z[6,7,5]  R1837     -4.3472938239574432e-02
    z[6,7,5]  R1838     -3.7419281434267759e-03
    z[6,7,5]  R1839     9.2434667050838470e-02
    z[6,7,5]  R1840     -4.2871972918510437e-01
    z[6,7,5]  R1841     -3.3051091432571411e-01
    z[6,7,5]  R1842     3.0744457244873047e-01
    z[6,7,5]  R1843     -1.1734230071306229e-01
    z[6,7,5]  R1844     -6.0735039412975311e-02
    z[6,7,5]  R1845     -4.1593369841575623e-01
    z[6,7,5]  R1846     1.5159327536821365e-02
    z[6,7,5]  R1847     2.9559774324297905e-02
    z[6,7,5]  R1848     -4.1807761788368225e-01
    z[6,7,5]  R1849     5.3183263540267944e-01
    z[6,7,5]  R1850     5.0590906292200089e-02
    z[6,7,5]  R1851     4.6976704150438309e-02
    z[6,7,5]  R1852     -4.1004788875579834e-01
    z[6,7,5]  R1853     -8.0488964915275574e-02
    z[6,7,5]  R1854     -1.3850995898246765e-01
    z[6,7,5]  R1855     1.7445281147956848e-01
    z[6,7,5]  R1856     -3.7980481982231140e-01
    z[6,7,5]  R1857     -0.549176037311554
    z[6,7,5]  R1858     -3.1081077456474304e-01
    z[6,7,5]  R1859     2.7003228664398193e-01
    z[6,7,5]  R1860     -1.6107386350631714e-01
    z[6,7,5]  R1861     -5.5078428983688354e-01
    z[6,7,5]  R1862     -3.1608107686042786e-01
    z[6,7,5]  R1863     -1.7238157987594604e-01
    z[6,7,5]  R1864     -1.0442781448364258e-01
    z[6,7,5]  R1865     2.9218757152557373e-01
    z[6,7,5]  R1866     -4.2967864871025085e-01
    z[6,7,5]  R1867     -1.0896987468004227e-01
    z[6,7,5]  R1868     1.6916318237781525e-01
    z[6,7,5]  R1869     0.0191938616335392
    z[6,7,5]  R1870     8.2310363650321960e-02
    z[6,7,5]  R1871     -2.0744070410728455e-01
    z[6,7,5]  R1872     -1.1092843860387802e-01
    z[6,7,5]  R1873     -1.8518300354480743e-01
    z[6,7,5]  R1874     2.7184817939996719e-02
    z[6,7,5]  R1875     -3.5375106334686279e-01
    z[6,7,5]  R1876     -3.9943951368331909e-01
    z[6,7,5]  R1877     4.8046806454658508e-01
    z[6,7,5]  R1878     -2.3944278061389923e-01
    z[6,7,5]  R1879     -7.0862270891666412e-02
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R1738     -1
    z[6,7,6]  R1739     1
    z[6,7,6]  R1740     -4.4671460986137390e-01
    z[6,7,6]  R1741     1.3010539114475250e-01
    z[6,7,6]  R1742     -3.1203389167785645e-01
    z[6,7,6]  R1743     1.4815047383308411e-01
    z[6,7,6]  R1744     -4.8706978559494019e-01
    z[6,7,6]  R1745     2.7129575610160828e-01
    z[6,7,6]  R1746     1.4876447618007660e-01
    z[6,7,6]  R1747     1.9188860058784485e-01
    z[6,7,6]  R1748     1.4020219445228577e-01
    z[6,7,6]  R1749     2.9772892594337463e-01
    z[6,7,6]  R1750     -2.3278956115245819e-01
    z[6,7,6]  R1751     -1.3321335613727570e-01
    z[6,7,6]  R1752     2.6396209001541138e-01
    z[6,7,6]  R1753     7.8763835132122040e-02
    z[6,7,6]  R1754     -2.0926684141159058e-01
    z[6,7,6]  R1755     5.5498555302619934e-02
    z[6,7,6]  R1756     2.3121263831853867e-02
    z[6,7,6]  R1757     1.2275070697069168e-01
    z[6,7,6]  R1758     2.4432279169559479e-01
    z[6,7,6]  R1759     -8.0082036554813385e-02
    z[6,7,6]  R1760     7.2437882423400879e-01
    z[6,7,6]  R1761     -4.5620280504226685e-01
    z[6,7,6]  R1762     -6.0417965054512024e-02
    z[6,7,6]  R1763     2.5813746452331543e-01
    z[6,7,6]  R1764     -2.1989642083644867e-01
    z[6,7,6]  R1765     -6.9250069558620453e-02
    z[6,7,6]  R1766     -2.6759475469589233e-01
    z[6,7,6]  R1767     -2.6893958449363708e-01
    z[6,7,6]  R1768     -3.3165183663368225e-01
    z[6,7,6]  R1769     4.8224378377199173e-02
    z[6,7,6]  R1770     -2.0635235309600830e-01
    z[6,7,6]  R1771     2.2748260200023651e-01
    z[6,7,6]  R1772     1.0516013205051422e-01
    z[6,7,6]  R1773     -3.9368532598018646e-02
    z[6,7,6]  R1774     -3.6459761857986450e-01
    z[6,7,6]  R1775     -2.8335893154144287e-01
    z[6,7,6]  R1776     -5.0444173812866211e-01
    z[6,7,6]  R1777     -1.5931384265422821e-01
    z[6,7,6]  R1778     -5.7740285992622375e-03
    z[6,7,6]  R1779     -2.2962391376495361e-01
    z[6,7,6]  R1780     -1.3790573179721832e-01
    z[6,7,6]  R1781     -1.6364523768424988e-01
    z[6,7,6]  R1782     -8.3632849156856537e-02
    z[6,7,6]  R1783     6.0002632439136505e-02
    z[6,7,6]  R1784     1.8504603207111359e-01
    z[6,7,6]  R1785     -2.1147492527961731e-01
    z[6,7,6]  R1786     1.3096566312015057e-02
    z[6,7,6]  R1787     -2.7766495943069458e-01
    z[6,7,6]  R1788     -8.0890739336609840e-03
    z[6,7,6]  R1789     2.4081563949584961e-01
    z[6,7,6]  R1790     1.4388850331306458e-01
    z[6,7,6]  R1791     5.9924638271331787e-01
    z[6,7,6]  R1792     4.3836173415184021e-01
    z[6,7,6]  R1793     4.5063480734825134e-01
    z[6,7,6]  R1794     1.4219434559345245e-01
    z[6,7,6]  R1795     4.7252067923545837e-01
    z[6,7,6]  R1796     -4.1448645293712616e-02
    z[6,7,6]  R1797     1.7293691635131836e-01
    z[6,7,6]  R1798     2.1829646080732346e-02
    z[6,7,6]  R1799     3.9265986531972885e-02
    z[6,7,6]  R1800     7.6660722494125366e-02
    z[6,7,6]  R1801     -5.6128031015396118e-01
    z[6,7,6]  R1802     4.9747237563133240e-01
    z[6,7,6]  R1803     -4.6390643715858459e-01
    z[6,7,6]  R1804     4.7608932852745056e-01
    z[6,7,6]  R1805     -6.2533393502235413e-02
    z[6,7,6]  R1806     2.1993571519851685e-01
    z[6,7,6]  R1807     3.4372383356094360e-01
    z[6,7,6]  R1808     3.4728819131851196e-01
    z[6,7,6]  R1809     0.255688339471817
    z[6,7,6]  R1810     4.2310228943824768e-01
    z[6,7,6]  R1811     6.8588759750127792e-03
    z[6,7,6]  R1812     2.3477682471275330e-01
    z[6,7,6]  R1813     -4.1881051659584045e-01
    z[6,7,6]  R1814     3.9004996418952942e-01
    z[6,7,6]  R1815     -0.335882306098938
    z[6,7,6]  R1816     -1.6593678295612335e-01
    z[6,7,6]  R1817     2.6671022176742554e-01
    z[6,7,6]  R1818     6.2468592077493668e-03
    z[6,7,6]  R1819     -8.7136939167976379e-02
    z[6,7,6]  R1820     -2.9209271073341370e-01
    z[6,7,6]  R1821     0.44937664270401
    z[6,7,6]  R1822     -9.9995970726013184e-02
    z[6,7,6]  R1823     1.3004487752914429e-01
    z[6,7,6]  R1824     -4.5862618088722229e-01
    z[6,7,6]  R1825     -5.1394551992416382e-01
    z[6,7,6]  R1826     -2.0621180534362793e-01
    z[6,7,6]  R1827     2.0252232253551483e-01
    z[6,7,6]  R1828     -1.0687220841646194e-01
    z[6,7,6]  R1829     -6.3475079834461212e-02
    z[6,7,6]  R1830     -1.4392933249473572e-01
    z[6,7,6]  R1831     3.9627268910408020e-01
    z[6,7,6]  R1832     -1.1192449927330017e-01
    z[6,7,6]  R1833     -1.2898662686347961e-01
    z[6,7,6]  R1834     4.8706603050231934e-01
    z[6,7,6]  R1835     1.6122156381607056e-01
    z[6,7,6]  R1836     -0.574490487575531
    z[6,7,6]  R1837     2.2059172391891479e-02
    z[6,7,6]  R1838     2.1027492359280586e-02
    z[6,7,6]  R1839     -9.4802536070346832e-02
    z[6,7,6]  R1840     -2.5701060891151428e-02
    z[6,7,6]  R1841     -1.7384913563728333e-01
    z[6,7,6]  R1842     0.0712905079126358
    z[6,7,6]  R1843     -2.4445161223411560e-01
    z[6,7,6]  R1844     -4.6912181377410889e-01
    z[6,7,6]  R1845     -2.4328069388866425e-01
    z[6,7,6]  R1846     3.8897043466567993e-01
    z[6,7,6]  R1847     -3.2586455345153809e-01
    z[6,7,6]  R1848     1.1651214212179184e-02
    z[6,7,6]  R1849     1.5964837744832039e-02
    z[6,7,6]  R1850     7.3880054056644440e-02
    z[6,7,6]  R1851     -3.6409109830856323e-02
    z[6,7,6]  R1852     1.9887593388557434e-01
    z[6,7,6]  R1853     2.9521992802619934e-01
    z[6,7,6]  R1854     5.9096522629261017e-02
    z[6,7,6]  R1855     4.5569464564323425e-01
    z[6,7,6]  R1856     -1.0193645209074020e-01
    z[6,7,6]  R1857     -2.6325622200965881e-01
    z[6,7,6]  R1858     5.2250474691390991e-02
    z[6,7,6]  R1859     6.4070552587509155e-02
    z[6,7,6]  R1860     -2.2096963226795197e-01
    z[6,7,6]  R1861     -1.0697133839130402e-01
    z[6,7,6]  R1862     6.6424749791622162e-02
    z[6,7,6]  R1863     -2.0087711513042450e-02
    z[6,7,6]  R1864     2.4833540618419647e-01
    z[6,7,6]  R1865     8.2687549293041229e-02
    z[6,7,6]  R1866     -3.9547204971313477e-01
    z[6,7,6]  R1867     -2.3731590807437897e-01
    z[6,7,6]  R1868     -3.3022749423980713e-01
    z[6,7,6]  R1869     -0.458345502614975
    z[6,7,6]  R1870     4.8635181784629822e-01
    z[6,7,6]  R1871     -2.1411462128162384e-01
    z[6,7,6]  R1872     1.3943125307559967e-01
    z[6,7,6]  R1873     3.0752828717231750e-01
    z[6,7,6]  R1874     1.5022693574428558e-01
    z[6,7,6]  R1875     -6.2335506081581116e-02
    z[6,7,6]  R1876     2.1135514974594116e-01
    z[6,7,6]  R1877     -0.360663503408432
    z[6,7,6]  R1878     6.0167215764522552e-02
    z[6,7,6]  R1879     2.0817078649997711e-02
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R1880     -1
    z[7,6,0]  R1881     1
    z[7,6,0]  R1894     0.77576744556427
    z[7,6,0]  R1895     8.8025522232055664e-01
    z[7,6,0]  R1896     6.4333146810531616e-01
    z[7,6,0]  R1897     8.7296146154403687e-01
    z[7,6,0]  R1898     6.7654889822006226e-01
    z[7,6,0]  R1899     7.7571070194244385e-01
    z[7,6,0]  R1900     7.1319955587387085e-01
    z[7,6,0]  R1901     7.6416790485382080e-01
    z[7,6,0]  R1902     0.66385817527771
    z[7,6,0]  R1903     7.3412883281707764e-01
    z[7,6,0]  R1904     -0.0723298192024231
    z[7,6,0]  R1905     -3.6823704838752747e-01
    z[7,6,0]  R1906     -1.8581800162792206e-01
    z[7,6,0]  R1907     -2.1017327904701233e-01
    z[7,6,0]  R1908     -4.3952235579490662e-01
    z[7,6,0]  R1909     -0.404788076877594
    z[7,6,0]  R1910     6.5057352185249329e-02
    z[7,6,0]  R1911     -3.6465483903884888e-01
    z[7,6,0]  R1912     -7.1978025138378143e-02
    z[7,6,0]  R1913     -1.6103573143482208e-02
    z[7,6,0]  R1914     1.5172088146209717e-01
    z[7,6,0]  R1915     8.2185946404933929e-02
    z[7,6,0]  R1916     2.3939360678195953e-01
    z[7,6,0]  R1917     0.133229598402977
    z[7,6,0]  R1918     3.4232255816459656e-01
    z[7,6,0]  R1919     2.4072253704071045e-01
    z[7,6,0]  R1920     -0.907288670539856
    z[7,6,0]  R1921     -9.0061253309249878e-01
    z[7,6,0]  R1922     -7.9439109563827515e-01
    z[7,6,0]  R1923     -7.9312282800674438e-01
    z[7,6,0]  R1924     6.7805558443069458e-02
    z[7,6,0]  R1925     3.4394392371177673e-01
    z[7,6,0]  R1926     3.5133108496665955e-01
    z[7,6,0]  R1927     2.5730523467063904e-01
    z[7,6,0]  R1928     -4.4008356332778931e-01
    z[7,6,0]  R1929     -8.8031291961669922e-02
    z[7,6,0]  R1930     -1.8469962477684021e-01
    z[7,6,0]  R1931     1.5967264771461487e-01
    z[7,6,0]  R1932     -7.2020488977432251e-01
    z[7,6,0]  R1933     -5.1735591888427734e-01
    z[7,6,0]  R1934     6.6200077533721924e-01
    z[7,6,0]  R1935     6.1138284206390381e-01
    z[7,6,0]  R1936     3.5945829749107361e-01
    z[7,6,0]  R1937     3.4982198476791382e-01
    z[7,6,0]  R1938     4.5862689614295959e-01
    z[7,6,0]  R1939     -3.2159939408302307e-02
    z[7,6,0]  R1940     -0.553945779800415
    z[7,6,0]  R1941     -1.6781832277774811e-01
    z[7,6,0]  R1942     2.1491825580596924e-01
    z[7,6,0]  R1943     -8.2912176847457886e-01
    z[7,6,0]  R1944     3.9126396179199219e-01
    z[7,6,0]  R1945     2.4881863594055176e-01
    z[7,6,0]  R1946     2.1482163667678833e-01
    z[7,6,0]  R1947     1.6018109396100044e-02
    z[7,6,0]  R1948     1.4037631452083588e-01
    z[7,6,0]  R1949     -1.0633911192417145e-01
    z[7,6,0]  R1950     3.5546919703483582e-01
    z[7,6,0]  R1951     -7.3311340808868408e-01
    z[7,6,0]  R1952     -0.69478839635849
    z[7,6,0]  R1953     -6.0788959264755249e-01
    z[7,6,0]  R1954     9.3835823237895966e-02
    z[7,6,0]  R1955     3.0185481905937195e-01
    z[7,6,0]  R1956     6.9934844970703125e-02
    z[7,6,0]  R1957     -3.5546261817216873e-02
    z[7,6,0]  R1958     -2.1151846647262573e-01
    z[7,6,0]  R1959     2.6397460699081421e-01
    z[7,6,0]  R1960     1.4714916236698627e-02
    z[7,6,0]  R1961     -0.826717734336853
    z[7,6,0]  R1962     -5.6553375720977783e-01
    z[7,6,0]  R1963     -4.6557343006134033e-01
    z[7,6,0]  R1964     2.2465810179710388e-01
    z[7,6,0]  R1965     -7.3979392647743225e-02
    z[7,6,0]  R1966     -0.567614734172821
    z[7,6,0]  R1967     2.2830119729042053e-01
    z[7,6,0]  R1968     3.2732114195823669e-01
    z[7,6,0]  R1969     -2.1348632872104645e-01
    z[7,6,0]  R1970     -5.2942311763763428e-01
    z[7,6,0]  R1971     -4.3943038582801819e-01
    z[7,6,0]  R1972     -7.5273221731185913e-01
    z[7,6,0]  R1973     -2.6824358105659485e-01
    z[7,6,0]  R1974     -5.7141637802124023e-01
    z[7,6,0]  R1975     -7.9831665754318237e-01
    z[7,6,0]  R1976     2.3983244597911835e-01
    z[7,6,0]  R1977     -4.5837086439132690e-01
    z[7,6,0]  R1978     -2.7903449535369873e-01
    z[7,6,0]  R1979     -2.3343828320503235e-01
    z[7,6,0]  R1980     -1.9718140363693237e-01
    z[7,6,0]  R1981     1.6486378014087677e-01
    z[7,6,0]  R1982     -8.1450670957565308e-01
    z[7,6,0]  R1983     -2.9810729622840881e-01
    z[7,6,0]  R1984     0.346869558095932
    z[7,6,0]  R1985     1.3677033782005310e-01
    z[7,6,0]  R1986     -2.9752010107040405e-01
    z[7,6,0]  R1987     -2.8384643793106079e-01
    z[7,6,0]  R1988     1.6154052317142487e-01
    z[7,6,0]  R1989     -4.7044627368450165e-02
    z[7,6,0]  R1990     2.0723946392536163e-01
    z[7,6,0]  R1991     -0.820107102394104
    z[7,6,0]  R1992     -5.7578301429748535e-01
    z[7,6,0]  R1993     -0.0969822108745575
    z[7,6,0]  R1994     6.0532465577125549e-02
    z[7,6,0]  R1995     -4.2753165960311890e-01
    z[7,6,0]  R1996     -1.7922100424766541e-01
    z[7,6,0]  R1997     -5.5445814132690430e-01
    z[7,6,0]  R1998     0.257851779460907
    z[7,6,0]  R1999     -1.9561986625194550e-01
    z[7,6,0]  R2000     -7.6634180545806885e-01
    z[7,6,0]  R2001     -2.9960823059082031e-01
    z[7,6,0]  R2002     -6.7675042152404785e-01
    z[7,6,0]  R2003     -7.6143556833267212e-01
    z[7,6,0]  R2004     6.0078807175159454e-02
    z[7,6,0]  R2005     4.2724207043647766e-01
    z[7,6,0]  R2006     -1.3868042826652527e-01
    z[7,6,0]  R2007     2.4168582260608673e-01
    z[7,6,0]  R2008     1.7367795109748840e-01
    z[7,6,0]  R2009     5.2177809178829193e-02
    z[7,6,0]  R2010     -1.2040754407644272e-01
    z[7,6,0]  R2011     -8.5096374154090881e-02
    z[7,6,0]  R2012     1.5058766305446625e-01
    z[7,6,0]  R2013     -1.9815723598003387e-01
    z[7,6,0]  R2014     2.7436295151710510e-01
    z[7,6,0]  R2015     9.1647975146770477e-02
    z[7,6,0]  R2016     2.1745577454566956e-02
    z[7,6,0]  R2017     1.4354908466339111e-01
    z[7,6,0]  R2018     1.1310781538486481e-01
    z[7,6,0]  R2019     2.0845864713191986e-01
    z[7,6,0]  R2020     2.1086524426937103e-01
    z[7,6,0]  R2021     2.7131393551826477e-01
    z[7,6,0]  R2022     3.1033164262771606e-01
    z[7,6,0]  R2023     4.3398644775152206e-02
    z[7,6,0]  R2024     -1.3096639513969421e-01
    z[7,6,0]  R2025     -1.4340618252754211e-01
    z[7,6,0]  R2026     -5.6878834962844849e-01
    z[7,6,0]  R2027     2.8041192889213562e-01
    z[7,6,0]  R2028     -8.6313909292221069e-01
    z[7,6,0]  R2029     1.3524170219898224e-01
    z[7,6,0]  R2030     -3.0409637093544006e-01
    z[7,6,0]  R2031     7.7812612056732178e-02
    z[7,6,0]  R2032     -1.8799254670739174e-02
    z[7,6,0]  R2033     8.7074846029281616e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R1882     -1
    z[7,6,1]  R1883     1
    z[7,6,1]  R1894     1.6411490738391876e-02
    z[7,6,1]  R1895     1.8768697977066040e-01
    z[7,6,1]  R1896     -2.3674362897872925e-01
    z[7,6,1]  R1897     2.9516544938087463e-01
    z[7,6,1]  R1898     2.3874360322952271e-01
    z[7,6,1]  R1899     2.4278904497623444e-01
    z[7,6,1]  R1900     3.0271226167678833e-01
    z[7,6,1]  R1901     -5.8600634336471558e-02
    z[7,6,1]  R1902     2.9660817980766296e-01
    z[7,6,1]  R1903     4.3455091118812561e-01
    z[7,6,1]  R1904     5.2240979671478271e-01
    z[7,6,1]  R1905     -5.1190710067749023e-01
    z[7,6,1]  R1906     -4.8452475666999817e-01
    z[7,6,1]  R1907     -0.502964437007904
    z[7,6,1]  R1908     -4.7964704036712646e-01
    z[7,6,1]  R1909     -0.854331910610199
    z[7,6,1]  R1910     -5.2673918008804321e-01
    z[7,6,1]  R1911     -4.7937366366386414e-01
    z[7,6,1]  R1912     -7.8769600391387939e-01
    z[7,6,1]  R1913     -5.6490635871887207e-01
    z[7,6,1]  R1914     1.2438297271728516e-02
    z[7,6,1]  R1915     6.8744570016860962e-01
    z[7,6,1]  R1916     4.6005198359489441e-01
    z[7,6,1]  R1917     -7.7825301885604858e-01
    z[7,6,1]  R1918     -2.2731673717498779e-01
    z[7,6,1]  R1919     -6.9942563772201538e-01
    z[7,6,1]  R1920     -1.7192485928535461e-01
    z[7,6,1]  R1921     -1.9084727764129639e-01
    z[7,6,1]  R1922     -3.4105113148689270e-01
    z[7,6,1]  R1923     -2.1921217441558838e-01
    z[7,6,1]  R1924     6.6876864433288574e-01
    z[7,6,1]  R1925     2.2041143476963043e-01
    z[7,6,1]  R1926     2.5117090344429016e-01
    z[7,6,1]  R1927     1.6876345872879028e-01
    z[7,6,1]  R1928     -7.2898006439208984e-01
    z[7,6,1]  R1929     -7.4544352293014526e-01
    z[7,6,1]  R1930     -5.6649994850158691e-01
    z[7,6,1]  R1931     -0.865119218826294
    z[7,6,1]  R1932     -0.507922351360321
    z[7,6,1]  R1933     -0.618511438369751
    z[7,6,1]  R1934     -2.1649330854415894e-01
    z[7,6,1]  R1935     3.0930796265602112e-01
    z[7,6,1]  R1936     8.4924995899200439e-01
    z[7,6,1]  R1937     4.2335382103919983e-01
    z[7,6,1]  R1938     4.6006661653518677e-01
    z[7,6,1]  R1939     7.8704708814620972e-01
    z[7,6,1]  R1940     -7.1661293506622314e-01
    z[7,6,1]  R1941     -7.4266058206558228e-01
    z[7,6,1]  R1942     -8.4290659427642822e-01
    z[7,6,1]  R1943     -4.6834820508956909e-01
    z[7,6,1]  R1944     3.1773579120635986e-01
    z[7,6,1]  R1945     3.5326966643333435e-01
    z[7,6,1]  R1946     -8.7270236015319824e-01
    z[7,6,1]  R1947     -8.1956350803375244e-01
    z[7,6,1]  R1948     6.7453527450561523e-01
    z[7,6,1]  R1949     -5.3128945827484131e-01
    z[7,6,1]  R1950     -0.854092001914978
    z[7,6,1]  R1951     1.3329645991325378e-01
    z[7,6,1]  R1952     1.7880636453628540e-01
    z[7,6,1]  R1953     -1.1599297635257244e-02
    z[7,6,1]  R1954     7.3112434148788452e-01
    z[7,6,1]  R1955     3.0246776342391968e-01
    z[7,6,1]  R1956     -6.0424768924713135e-01
    z[7,6,1]  R1957     -0.900780975818634
    z[7,6,1]  R1958     -7.2514319419860840e-01
    z[7,6,1]  R1959     4.5567423105239868e-01
    z[7,6,1]  R1960     -6.1548978090286255e-01
    z[7,6,1]  R1961     -2.8613340854644775e-01
    z[7,6,1]  R1962     2.3322394490242004e-01
    z[7,6,1]  R1963     2.5845530629158020e-01
    z[7,6,1]  R1964     4.8997023701667786e-01
    z[7,6,1]  R1965     4.0439867973327637e-01
    z[7,6,1]  R1966     -0.656741201877594
    z[7,6,1]  R1967     -8.8230144977569580e-01
    z[7,6,1]  R1968     -8.0567622184753418e-01
    z[7,6,1]  R1969     -5.0674062967300415e-01
    z[7,6,1]  R1970     -5.5835723876953125e-01
    z[7,6,1]  R1971     1.6405096650123596e-01
    z[7,6,1]  R1972     4.2379528284072876e-02
    z[7,6,1]  R1973     -2.6594796776771545e-01
    z[7,6,1]  R1974     -5.7925939559936523e-01
    z[7,6,1]  R1975     -5.6226819753646851e-01
    z[7,6,1]  R1976     -7.9547297954559326e-01
    z[7,6,1]  R1977     -6.3943260908126831e-01
    z[7,6,1]  R1978     -5.9386724233627319e-01
    z[7,6,1]  R1979     -7.3498421907424927e-01
    z[7,6,1]  R1980     -3.1208464503288269e-01
    z[7,6,1]  R1981     -6.8900579214096069e-01
    z[7,6,1]  R1982     -3.7101477384567261e-01
    z[7,6,1]  R1983     6.6063500940799713e-02
    z[7,6,1]  R1984     5.4832839965820312e-01
    z[7,6,1]  R1985     5.9515094757080078e-01
    z[7,6,1]  R1986     -7.0391672849655151e-01
    z[7,6,1]  R1987     -6.7108732461929321e-01
    z[7,6,1]  R1988     -0.752247154712677
    z[7,6,1]  R1989     -8.9022374153137207e-01
    z[7,6,1]  R1990     -7.2310638427734375e-01
    z[7,6,1]  R1991     2.3239577189087868e-02
    z[7,6,1]  R1992     -2.1518308669328690e-02
    z[7,6,1]  R1993     -4.8537105321884155e-01
    z[7,6,1]  R1994     2.7299115061759949e-01
    z[7,6,1]  R1995     -6.1635011434555054e-01
    z[7,6,1]  R1996     -8.9283865690231323e-01
    z[7,6,1]  R1997     -6.3888096809387207e-01
    z[7,6,1]  R1998     0.512329638004303
    z[7,6,1]  R1999     -2.2371679544448853e-01
    z[7,6,1]  R2000     -3.9436888694763184e-01
    z[7,6,1]  R2001     -4.8325982689857483e-01
    z[7,6,1]  R2002     3.8783061504364014e-01
    z[7,6,1]  R2003     2.6828026771545410e-01
    z[7,6,1]  R2004     4.0564718842506409e-01
    z[7,6,1]  R2005     2.2150342166423798e-01
    z[7,6,1]  R2006     7.5999921560287476e-01
    z[7,6,1]  R2007     8.0857682228088379e-01
    z[7,6,1]  R2008     6.7764484882354736e-01
    z[7,6,1]  R2009     6.8996334075927734e-01
    z[7,6,1]  R2010     6.9491308927536011e-01
    z[7,6,1]  R2011     7.1934080123901367e-01
    z[7,6,1]  R2012     5.3852117061614990e-01
    z[7,6,1]  R2013     4.8250377178192139e-01
    z[7,6,1]  R2014     -0.8618124127388
    z[7,6,1]  R2015     -8.8795089721679688e-01
    z[7,6,1]  R2016     -9.1304314136505127e-01
    z[7,6,1]  R2017     -7.7425575256347656e-01
    z[7,6,1]  R2018     -7.6965504884719849e-01
    z[7,6,1]  R2019     -7.8923708200454712e-01
    z[7,6,1]  R2020     -8.4171468019485474e-01
    z[7,6,1]  R2021     -8.9356827735900879e-01
    z[7,6,1]  R2022     -8.8723313808441162e-01
    z[7,6,1]  R2023     -0.852087140083313
    z[7,6,1]  R2024     1.7683847248554230e-01
    z[7,6,1]  R2025     -7.9349607229232788e-02
    z[7,6,1]  R2026     2.7236542105674744e-01
    z[7,6,1]  R2027     -1.4644323289394379e-01
    z[7,6,1]  R2028     -2.8788959980010986e-01
    z[7,6,1]  R2029     -6.1036145687103271e-01
    z[7,6,1]  R2030     -5.1336658000946045e-01
    z[7,6,1]  R2031     -6.2286847829818726e-01
    z[7,6,1]  R2032     -6.2361860275268555e-01
    z[7,6,1]  R2033     -0.288864403963089
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R1884     -1
    z[7,6,2]  R1885     1
    z[7,6,2]  R1894     2.5777277350425720e-01
    z[7,6,2]  R1895     -1.1954865604639053e-01
    z[7,6,2]  R1896     1.0909274965524673e-01
    z[7,6,2]  R1897     -1.0482856631278992e-01
    z[7,6,2]  R1898     -2.9389381408691406e-01
    z[7,6,2]  R1899     -0.358809232711792
    z[7,6,2]  R1900     -0.108444444835186
    z[7,6,2]  R1901     1.3620543479919434e-01
    z[7,6,2]  R1902     -9.4696566462516785e-02
    z[7,6,2]  R1903     -2.3804001510143280e-01
    z[7,6,2]  R1904     4.7510975599288940e-01
    z[7,6,2]  R1905     -4.3975785374641418e-01
    z[7,6,2]  R1906     -6.3251811265945435e-01
    z[7,6,2]  R1907     -6.5593171119689941e-01
    z[7,6,2]  R1908     -3.6732786893844604e-01
    z[7,6,2]  R1909     5.5395025759935379e-02
    z[7,6,2]  R1910     -5.7521623373031616e-01
    z[7,6,2]  R1911     -5.3364193439483643e-01
    z[7,6,2]  R1912     -4.8240253329277039e-01
    z[7,6,2]  R1913     -4.0648695826530457e-01
    z[7,6,2]  R1914     7.5240141153335571e-01
    z[7,6,2]  R1915     2.6230162382125854e-01
    z[7,6,2]  R1916     -1.4601278118789196e-02
    z[7,6,2]  R1917     1.1752258241176605e-01
    z[7,6,2]  R1918     5.1802337169647217e-01
    z[7,6,2]  R1919     -8.5014671087265015e-02
    z[7,6,2]  R1920     -4.3336819857358932e-02
    z[7,6,2]  R1921     -6.9281840696930885e-03
    z[7,6,2]  R1922     2.6703259348869324e-01
    z[7,6,2]  R1923     4.8138287663459778e-01
    z[7,6,2]  R1924     6.2798202037811279e-01
    z[7,6,2]  R1925     5.0892859697341919e-01
    z[7,6,2]  R1926     3.6279958486557007e-01
    z[7,6,2]  R1927     3.9509826898574829e-01
    z[7,6,2]  R1928     -1.8965192139148712e-01
    z[7,6,2]  R1929     -4.0701773762702942e-01
    z[7,6,2]  R1930     -3.4555483609437943e-02
    z[7,6,2]  R1931     -3.2562226057052612e-02
    z[7,6,2]  R1932     -1.1808338761329651e-01
    z[7,6,2]  R1933     -3.9527878165245056e-01
    z[7,6,2]  R1934     2.0764118060469627e-02
    z[7,6,2]  R1935     3.7314009666442871e-01
    z[7,6,2]  R1936     1.9965112209320068e-01
    z[7,6,2]  R1937     5.7231187820434570e-01
    z[7,6,2]  R1938     1.8976931273937225e-01
    z[7,6,2]  R1939     1.5339636802673340e-01
    z[7,6,2]  R1940     -3.3698305487632751e-01
    z[7,6,2]  R1941     -6.9558590650558472e-02
    z[7,6,2]  R1942     -2.9084178805351257e-01
    z[7,6,2]  R1943     1.6147981584072113e-01
    z[7,6,2]  R1944     5.5289882421493530e-01
    z[7,6,2]  R1945     5.6592386960983276e-01
    z[7,6,2]  R1946     -2.6835048198699951e-01
    z[7,6,2]  R1947     -4.5116010308265686e-01
    z[7,6,2]  R1948     3.9275681972503662e-01
    z[7,6,2]  R1949     1.4864921569824219e-01
    z[7,6,2]  R1950     1.4777974784374237e-01
    z[7,6,2]  R1951     1.4433830045163631e-02
    z[7,6,2]  R1952     5.8649875223636627e-02
    z[7,6,2]  R1953     9.5928184688091278e-02
    z[7,6,2]  R1954     2.0550854504108429e-01
    z[7,6,2]  R1955     0.733496904373169
    z[7,6,2]  R1956     -3.0421867966651917e-01
    z[7,6,2]  R1957     4.0832184255123138e-02
    z[7,6,2]  R1958     -2.1121737360954285e-01
    z[7,6,2]  R1959     -2.3063591122627258e-01
    z[7,6,2]  R1960     -1.8074475228786469e-01
    z[7,6,2]  R1961     2.3348145186901093e-01
    z[7,6,2]  R1962     -5.4902553558349609e-02
    z[7,6,2]  R1963     -1.1982156336307526e-01
    z[7,6,2]  R1964     4.7163677215576172e-01
    z[7,6,2]  R1965     4.8232552409172058e-01
    z[7,6,2]  R1966     9.2045597732067108e-02
    z[7,6,2]  R1967     4.4353265315294266e-02
    z[7,6,2]  R1968     -0.0972619354724884
    z[7,6,2]  R1969     -2.3143781721591949e-01
    z[7,6,2]  R1970     3.4219604730606079e-01
    z[7,6,2]  R1971     -1.6744692623615265e-01
    z[7,6,2]  R1972     -3.4664005041122437e-01
    z[7,6,2]  R1973     -7.7150254510343075e-03
    z[7,6,2]  R1974     -3.6362352967262268e-01
    z[7,6,2]  R1975     1.8867236375808716e-01
    z[7,6,2]  R1976     -3.1880292296409607e-01
    z[7,6,2]  R1977     2.4227949976921082e-01
    z[7,6,2]  R1978     2.2747018933296204e-01
    z[7,6,2]  R1979     1.7310473322868347e-01
    z[7,6,2]  R1980     2.0147490501403809e-01
    z[7,6,2]  R1981     -3.0700030922889709e-01
    z[7,6,2]  R1982     1.7181381583213806e-02
    z[7,6,2]  R1983     -2.2931785881519318e-01
    z[7,6,2]  R1984     6.6481626033782959e-01
    z[7,6,2]  R1985     2.7252513170242310e-01
    z[7,6,2]  R1986     -2.7540338039398193e-01
    z[7,6,2]  R1987     7.6584428548812866e-02
    z[7,6,2]  R1988     -5.7331192493438721e-01
    z[7,6,2]  R1989     -2.6023969054222107e-01
    z[7,6,2]  R1990     -2.5527155399322510e-01
    z[7,6,2]  R1991     -1.5020149759948254e-02
    z[7,6,2]  R1992     -6.1559706926345825e-02
    z[7,6,2]  R1993     7.7393390238285065e-02
    z[7,6,2]  R1994     6.6374713182449341e-01
    z[7,6,2]  R1995     1.5252985060214996e-01
    z[7,6,2]  R1996     -3.3343076705932617e-01
    z[7,6,2]  R1997     -3.8093057274818420e-01
    z[7,6,2]  R1998     -4.5072987675666809e-01
    z[7,6,2]  R1999     3.1683048605918884e-01
    z[7,6,2]  R2000     -6.4119093120098114e-02
    z[7,6,2]  R2001     1.8009927123785019e-02
    z[7,6,2]  R2002     -5.0373566150665283e-01
    z[7,6,2]  R2003     -5.5464059114456177e-01
    z[7,6,2]  R2004     -3.4663298726081848e-01
    z[7,6,2]  R2005     9.0632744133472443e-02
    z[7,6,2]  R2006     -2.2049550712108612e-01
    z[7,6,2]  R2007     2.9269057512283325e-01
    z[7,6,2]  R2008     4.2941588163375854e-01
    z[7,6,2]  R2009     1.9265830516815186e-01
    z[7,6,2]  R2010     4.5219299197196960e-01
    z[7,6,2]  R2011     -0.402471125125885
    z[7,6,2]  R2012     4.4798237085342407e-01
    z[7,6,2]  R2013     -3.9822395890951157e-02
    z[7,6,2]  R2014     1.3586680591106415e-01
    z[7,6,2]  R2015     7.3633953928947449e-02
    z[7,6,2]  R2016     -2.1363621950149536e-01
    z[7,6,2]  R2017     -2.0699515938758850e-01
    z[7,6,2]  R2018     4.3758027255535126e-02
    z[7,6,2]  R2019     -1.8099133670330048e-01
    z[7,6,2]  R2020     2.9156863689422607e-02
    z[7,6,2]  R2021     1.8243777751922607e-01
    z[7,6,2]  R2022     -0.0689927414059639
    z[7,6,2]  R2023     -3.3757713437080383e-01
    z[7,6,2]  R2024     -9.5141483470797539e-03
    z[7,6,2]  R2025     3.0076336860656738e-01
    z[7,6,2]  R2026     -3.8881582021713257e-01
    z[7,6,2]  R2027     4.2071306705474854e-01
    z[7,6,2]  R2028     2.2023412585258484e-01
    z[7,6,2]  R2029     -2.4554346501827240e-01
    z[7,6,2]  R2030     -4.2343845963478088e-01
    z[7,6,2]  R2031     4.6115991473197937e-01
    z[7,6,2]  R2032     1.1870677024126053e-01
    z[7,6,2]  R2033     -8.8434182107448578e-02
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R1886     -1
    z[7,6,3]  R1887     1
    z[7,6,3]  R1894     3.6191475391387939e-01
    z[7,6,3]  R1895     2.7237620949745178e-01
    z[7,6,3]  R1896     6.7980909347534180e-01
    z[7,6,3]  R1897     7.3311723768711090e-02
    z[7,6,3]  R1898     0.42009437084198
    z[7,6,3]  R1899     2.3003891110420227e-01
    z[7,6,3]  R1900     3.1932342052459717e-01
    z[7,6,3]  R1901     3.5840702056884766e-01
    z[7,6,3]  R1902     5.6651169061660767e-01
    z[7,6,3]  R1903     2.8356346487998962e-01
    z[7,6,3]  R1904     -5.6767380237579346e-01
    z[7,6,3]  R1905     -3.6865150928497314e-01
    z[7,6,3]  R1906     -3.7740305066108704e-01
    z[7,6,3]  R1907     -5.0571990013122559e-01
    z[7,6,3]  R1908     -0.410660982131958
    z[7,6,3]  R1909     2.1263739466667175e-01
    z[7,6,3]  R1910     -5.3038388490676880e-01
    z[7,6,3]  R1911     -5.2300339937210083e-01
    z[7,6,3]  R1912     -2.2139649093151093e-01
    z[7,6,3]  R1913     -4.4104033708572388e-01
    z[7,6,3]  R1914     -3.6225321888923645e-01
    z[7,6,3]  R1915     1.0925932228565216e-01
    z[7,6,3]  R1916     -7.1278387308120728e-01
    z[7,6,3]  R1917     2.1688152849674225e-01
    z[7,6,3]  R1918     -6.9918829202651978e-01
    z[7,6,3]  R1919     2.2615356743335724e-01
    z[7,6,3]  R1920     -9.6766859292984009e-02
    z[7,6,3]  R1921     -1.0856787860393524e-01
    z[7,6,3]  R1922     -7.7130466699600220e-02
    z[7,6,3]  R1923     -2.0936983823776245e-01
    z[7,6,3]  R1924     5.5666558444499969e-02
    z[7,6,3]  R1925     -4.1393363475799561e-01
    z[7,6,3]  R1926     -7.4532374739646912e-02
    z[7,6,3]  R1927     -3.2952728867530823e-01
    z[7,6,3]  R1928     5.7273630052804947e-02
    z[7,6,3]  R1929     3.5371991991996765e-01
    z[7,6,3]  R1930     6.2036764621734619e-01
    z[7,6,3]  R1931     0.174591064453125
    z[7,6,3]  R1932     -6.5473616123199463e-02
    z[7,6,3]  R1933     9.8076008260250092e-02
    z[7,6,3]  R1934     0.54584139585495
    z[7,6,3]  R1935     -5.0053983926773071e-01
    z[7,6,3]  R1936     -6.7424766719341278e-02
    z[7,6,3]  R1937     -4.1990217566490173e-01
    z[7,6,3]  R1938     -4.7919595241546631e-01
    z[7,6,3]  R1939     -4.7395061701536179e-02
    z[7,6,3]  R1940     -7.9899743199348450e-02
    z[7,6,3]  R1941     3.8864096999168396e-01
    z[7,6,3]  R1942     0.112656369805336
    z[7,6,3]  R1943     -1.6416944563388824e-01
    z[7,6,3]  R1944     -1.8139523267745972e-01
    z[7,6,3]  R1945     -3.0042198300361633e-01
    z[7,6,3]  R1946     2.0458501577377319e-01
    z[7,6,3]  R1947     0.299461305141449
    z[7,6,3]  R1948     -3.0456364154815674e-01
    z[7,6,3]  R1949     6.3462370634078979e-01
    z[7,6,3]  R1950     -3.1808264553546906e-02
    z[7,6,3]  R1951     -6.1111348867416382e-01
    z[7,6,3]  R1952     -4.4662916660308838e-01
    z[7,6,3]  R1953     -7.2431737184524536e-01
    z[7,6,3]  R1954     -9.9267408251762390e-02
    z[7,6,3]  R1955     -2.1639212965965271e-01
    z[7,6,3]  R1956     4.5839720964431763e-01
    z[7,6,3]  R1957     -1.2969951145350933e-02
    z[7,6,3]  R1958     1.9489879906177521e-01
    z[7,6,3]  R1959     -0.739753782749176
    z[7,6,3]  R1960     4.2342305183410645e-01
    z[7,6,3]  R1961     -1.6215343773365021e-01
    z[7,6,3]  R1962     -6.8730795383453369e-01
    z[7,6,3]  R1963     -8.0857044458389282e-01
    z[7,6,3]  R1964     -4.8054140806198120e-01
    z[7,6,3]  R1965     6.1848795413970947e-01
    z[7,6,3]  R1966     -2.5894984602928162e-01
    z[7,6,3]  R1967     2.4202822148799896e-01
    z[7,6,3]  R1968     2.5243896525353193e-03
    z[7,6,3]  R1969     5.7796555757522583e-01
    z[7,6,3]  R1970     3.4566736221313477e-01
    z[7,6,3]  R1971     -7.0362383127212524e-01
    z[7,6,3]  R1972     -3.6247396469116211e-01
    z[7,6,3]  R1973     -0.738812267780304
    z[7,6,3]  R1974     -4.3917959928512573e-01
    z[7,6,3]  R1975     -6.6205725073814392e-02
    z[7,6,3]  R1976     2.7190076652914286e-03
    z[7,6,3]  R1977     4.7790881991386414e-01
    z[7,6,3]  R1978     6.6536128520965576e-01
    z[7,6,3]  R1979     2.6913082599639893e-01
    z[7,6,3]  R1980     8.1416743993759155e-01
    z[7,6,3]  R1981     7.6190240681171417e-02
    z[7,6,3]  R1982     7.1276850998401642e-02
    z[7,6,3]  R1983     -8.8126683235168457e-01
    z[7,6,3]  R1984     -2.3248299956321716e-01
    z[7,6,3]  R1985     -1.1482724547386169e-01
    z[7,6,3]  R1986     4.6430990099906921e-01
    z[7,6,3]  R1987     5.5468821525573730e-01
    z[7,6,3]  R1988     1.5193149447441101e-02
    z[7,6,3]  R1989     -3.2171458005905151e-02
    z[7,6,3]  R1990     5.1962349563837051e-02
    z[7,6,3]  R1991     -5.0766462087631226e-01
    z[7,6,3]  R1992     -7.0269167423248291e-01
    z[7,6,3]  R1993     3.8918992877006531e-01
    z[7,6,3]  R1994     -3.2630622386932373e-01
    z[7,6,3]  R1995     5.4890251159667969e-01
    z[7,6,3]  R1996     3.0041038990020752e-02
    z[7,6,3]  R1997     -7.0372693240642548e-02
    z[7,6,3]  R1998     -6.6674917936325073e-01
    z[7,6,3]  R1999     8.2571476697921753e-01
    z[7,6,3]  R2000     1.8634662032127380e-01
    z[7,6,3]  R2001     -5.4187369346618652e-01
    z[7,6,3]  R2002     -1.8501089513301849e-01
    z[7,6,3]  R2003     1.1763103306293488e-01
    z[7,6,3]  R2004     -4.8990166187286377e-01
    z[7,6,3]  R2005     -3.9430651068687439e-01
    z[7,6,3]  R2006     0.46151003241539
    z[7,6,3]  R2007     -2.4853320419788361e-01
    z[7,6,3]  R2008     -0.0752018466591835
    z[7,6,3]  R2009     4.7317335009574890e-01
    z[7,6,3]  R2010     1.9617833197116852e-01
    z[7,6,3]  R2011     2.4148421362042427e-02
    z[7,6,3]  R2012     -1.8303368985652924e-01
    z[7,6,3]  R2013     -6.1512148380279541e-01
    z[7,6,3]  R2014     -3.2610893249511719e-01
    z[7,6,3]  R2015     -4.0407484769821167e-01
    z[7,6,3]  R2016     2.0927238464355469e-01
    z[7,6,3]  R2017     -5.3526580333709717e-01
    z[7,6,3]  R2018     -5.4303711652755737e-01
    z[7,6,3]  R2019     -4.6658292412757874e-01
    z[7,6,3]  R2020     -3.6240440607070923e-01
    z[7,6,3]  R2021     -2.0387594401836395e-01
    z[7,6,3]  R2022     -1.6399122774600983e-01
    z[7,6,3]  R2023     2.0753040909767151e-01
    z[7,6,3]  R2024     -3.4860542416572571e-01
    z[7,6,3]  R2025     -0.545215904712677
    z[7,6,3]  R2026     0.0992526262998581
    z[7,6,3]  R2027     6.3176751136779785e-01
    z[7,6,3]  R2028     1.9093842804431915e-01
    z[7,6,3]  R2029     3.1614455580711365e-01
    z[7,6,3]  R2030     2.0861414074897766e-01
    z[7,6,3]  R2031     4.4924274086952209e-01
    z[7,6,3]  R2032     4.8011621832847595e-01
    z[7,6,3]  R2033     1.5854936838150024e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R1888     -1
    z[7,6,4]  R1889     1
    z[7,6,4]  R1894     1.6483603417873383e-01
    z[7,6,4]  R1895     -2.0548866689205170e-01
    z[7,6,4]  R1896     -1.2014985829591751e-01
    z[7,6,4]  R1897     2.9497590661048889e-01
    z[7,6,4]  R1898     1.4236049354076385e-01
    z[7,6,4]  R1899     2.5435414910316467e-01
    z[7,6,4]  R1900     1.6347086429595947e-01
    z[7,6,4]  R1901     -4.1072311997413635e-01
    z[7,6,4]  R1902     -2.4284815788269043e-01
    z[7,6,4]  R1903     -1.8633264303207397e-01
    z[7,6,4]  R1904     3.5102775692939758e-01
    z[7,6,4]  R1905     -4.9579218029975891e-01
    z[7,6,4]  R1906     -0.420878142118454
    z[7,6,4]  R1907     -1.1079634726047516e-01
    z[7,6,4]  R1908     -4.8875716328620911e-01
    z[7,6,4]  R1909     -3.1739141792058945e-02
    z[7,6,4]  R1910     -1.8995173275470734e-01
    z[7,6,4]  R1911     8.6141005158424377e-03
    z[7,6,4]  R1912     -2.5475943088531494e-01
    z[7,6,4]  R1913     -4.2808291316032410e-01
    z[7,6,4]  R1914     -1.7352880537509918e-01
    z[7,6,4]  R1915     2.0763443410396576e-01
    z[7,6,4]  R1916     -1.5970483422279358e-01
    z[7,6,4]  R1917     -0.164675772190094
    z[7,6,4]  R1918     6.9020465016365051e-02
    z[7,6,4]  R1919     3.3810202032327652e-02
    z[7,6,4]  R1920     2.0591814070940018e-02
    z[7,6,4]  R1921     1.2437465041875839e-01
    z[7,6,4]  R1922     2.7689921855926514e-01
    z[7,6,4]  R1923     1.0139914602041245e-01
    z[7,6,4]  R1924     -7.4027101509273052e-03
    z[7,6,4]  R1925     -9.2984713613986969e-02
    z[7,6,4]  R1926     5.7830739021301270e-01
    z[7,6,4]  R1927     5.7642382383346558e-01
    z[7,6,4]  R1928     9.1092668473720551e-02
    z[7,6,4]  R1929     -2.9985904693603516e-01
    z[7,6,4]  R1930     -3.4815132617950439e-01
    z[7,6,4]  R1931     -5.8498740196228027e-02
    z[7,6,4]  R1932     2.5201949477195740e-01
    z[7,6,4]  R1933     1.6721126437187195e-01
    z[7,6,4]  R1934     1.5844435989856720e-01
    z[7,6,4]  R1935     3.3917296677827835e-03
    z[7,6,4]  R1936     -1.0530129820108414e-01
    z[7,6,4]  R1937     -3.4999931231141090e-03
    z[7,6,4]  R1938     1.9685381650924683e-01
    z[7,6,4]  R1939     4.1764539480209351e-01
    z[7,6,4]  R1940     1.4651700854301453e-01
    z[7,6,4]  R1941     4.3963202834129333e-01
    z[7,6,4]  R1942     3.0410623550415039e-01
    z[7,6,4]  R1943     1.7601549625396729e-01
    z[7,6,4]  R1944     -1.3534653186798096e-01
    z[7,6,4]  R1945     4.7975964844226837e-02
    z[7,6,4]  R1946     1.0215112566947937e-01
    z[7,6,4]  R1947     -0.0791703388094902
    z[7,6,4]  R1948     -1.5117718279361725e-01
    z[7,6,4]  R1949     -0.000655064475722611
    z[7,6,4]  R1950     -1.3639484345912933e-01
    z[7,6,4]  R1951     -1.7070990800857544e-01
    z[7,6,4]  R1952     -4.9967950582504272e-01
    z[7,6,4]  R1953     -1.6937865316867828e-01
    z[7,6,4]  R1954     5.0345176458358765e-01
    z[7,6,4]  R1955     -1.9321238994598389e-01
    z[7,6,4]  R1956     -0.510749340057373
    z[7,6,4]  R1957     -1.7659065127372742e-01
    z[7,6,4]  R1958     -3.2749277353286743e-01
    z[7,6,4]  R1959     -1.6959272325038910e-01
    z[7,6,4]  R1960     -2.5101867318153381e-01
    z[7,6,4]  R1961     -3.8920632004737854e-01
    z[7,6,4]  R1962     -3.8718926906585693e-01
    z[7,6,4]  R1963     -1.7540577054023743e-01
    z[7,6,4]  R1964     2.6764786243438721e-01
    z[7,6,4]  R1965     2.7633774280548096e-01
    z[7,6,4]  R1966     2.6715666055679321e-01
    z[7,6,4]  R1967     1.8802155554294586e-01
    z[7,6,4]  R1968     -1.0254956036806107e-01
    z[7,6,4]  R1969     2.7900439500808716e-01
    z[7,6,4]  R1970     1.4084173738956451e-01
    z[7,6,4]  R1971     -3.8704228401184082e-01
    z[7,6,4]  R1972     7.1601629257202148e-02
    z[7,6,4]  R1973     1.6826494038105011e-01
    z[7,6,4]  R1974     6.9450519979000092e-02
    z[7,6,4]  R1975     5.5063869804143906e-02
    z[7,6,4]  R1976     1.9221821799874306e-02
    z[7,6,4]  R1977     0.0171035286039114
    z[7,6,4]  R1978     2.2876986861228943e-01
    z[7,6,4]  R1979     -2.5459113717079163e-01
    z[7,6,4]  R1980     7.4961505830287933e-02
    z[7,6,4]  R1981     -1.6473822295665741e-01
    z[7,6,4]  R1982     -3.0694943666458130e-01
    z[7,6,4]  R1983     -2.2959465160965919e-02
    z[7,6,4]  R1984     9.0642586350440979e-02
    z[7,6,4]  R1985     4.7416013479232788e-01
    z[7,6,4]  R1986     1.4224231243133545e-01
    z[7,6,4]  R1987     -3.5413238406181335e-01
    z[7,6,4]  R1988     8.0844148993492126e-02
    z[7,6,4]  R1989     2.1051813662052155e-01
    z[7,6,4]  R1990     -1.5900759398937225e-01
    z[7,6,4]  R1991     -2.7241092175245285e-02
    z[7,6,4]  R1992     1.8105036020278931e-01
    z[7,6,4]  R1993     6.2217503786087036e-01
    z[7,6,4]  R1994     3.6257752776145935e-01
    z[7,6,4]  R1995     -1.5457384288311005e-01
    z[7,6,4]  R1996     1.6399468481540680e-01
    z[7,6,4]  R1997     7.4029639363288879e-02
    z[7,6,4]  R1998     3.4444069024175406e-03
    z[7,6,4]  R1999     2.1715784445405006e-02
    z[7,6,4]  R2000     -1.1888762563467026e-01
    z[7,6,4]  R2001     -1.4770109951496124e-01
    z[7,6,4]  R2002     -2.0655460655689240e-01
    z[7,6,4]  R2003     1.4602577686309814e-01
    z[7,6,4]  R2004     -5.2042442560195923e-01
    z[7,6,4]  R2005     -7.6170068979263306e-01
    z[7,6,4]  R2006     -1.9811517000198364e-01
    z[7,6,4]  R2007     -3.4133148193359375e-01
    z[7,6,4]  R2008     -3.3587660640478134e-02
    z[7,6,4]  R2009     4.7299563884735107e-02
    z[7,6,4]  R2010     4.8518773913383484e-01
    z[7,6,4]  R2011     -1.8480852246284485e-01
    z[7,6,4]  R2012     2.7453845739364624e-01
    z[7,6,4]  R2013     4.5313492417335510e-01
    z[7,6,4]  R2014     3.7386257201433182e-02
    z[7,6,4]  R2015     1.2197016924619675e-01
    z[7,6,4]  R2016     -5.4741352796554565e-02
    z[7,6,4]  R2017     7.8208781778812408e-02
    z[7,6,4]  R2018     1.5961837768554688e-01
    z[7,6,4]  R2019     2.8302788734436035e-01
    z[7,6,4]  R2020     3.1871438026428223e-01
    z[7,6,4]  R2021     1.2767308950424194e-01
    z[7,6,4]  R2022     -2.8134299442172050e-02
    z[7,6,4]  R2023     -3.0184331536293030e-01
    z[7,6,4]  R2024     0.159694641828537
    z[7,6,4]  R2025     4.5935627818107605e-01
    z[7,6,4]  R2026     4.9985128641128540e-01
    z[7,6,4]  R2027     -3.1561404466629028e-01
    z[7,6,4]  R2028     6.6229745745658875e-02
    z[7,6,4]  R2029     -1.8067894876003265e-01
    z[7,6,4]  R2030     4.0252575278282166e-01
    z[7,6,4]  R2031     3.4419393539428711e-01
    z[7,6,4]  R2032     3.2462656497955322e-01
    z[7,6,4]  R2033     2.9222598671913147e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R1890     -1
    z[7,6,5]  R1891     1
    z[7,6,5]  R1894     3.6157190799713135e-01
    z[7,6,5]  R1895     8.6428232491016388e-02
    z[7,6,5]  R1896     1.7475946247577667e-01
    z[7,6,5]  R1897     2.1422280371189117e-01
    z[7,6,5]  R1898     -2.6312029361724854e-01
    z[7,6,5]  R1899     -1.1258765310049057e-01
    z[7,6,5]  R1900     -6.9279879331588745e-02
    z[7,6,5]  R1901     2.6745384931564331e-01
    z[7,6,5]  R1902     -2.8706169128417969e-01
    z[7,6,5]  R1903     -2.1840818226337433e-01
    z[7,6,5]  R1904     -1.7786248028278351e-01
    z[7,6,5]  R1905     -2.1726746112108231e-02
    z[7,6,5]  R1906     -6.3736066222190857e-02
    z[7,6,5]  R1907     3.1286545097827911e-02
    z[7,6,5]  R1908     7.8133922070264816e-03
    z[7,6,5]  R1909     1.1068589985370636e-01
    z[7,6,5]  R1910     2.6434719562530518e-01
    z[7,6,5]  R1911     0.0418284609913826
    z[7,6,5]  R1912     1.6630619764328003e-01
    z[7,6,5]  R1913     2.8218093514442444e-01
    z[7,6,5]  R1914     -0.478199303150177
    z[7,6,5]  R1915     -1.9420586526393890e-01
    z[7,6,5]  R1916     -7.1430094540119171e-02
    z[7,6,5]  R1917     -0.292460560798645
    z[7,6,5]  R1918     2.2123925387859344e-01
    z[7,6,5]  R1919     -4.1238903999328613e-01
    z[7,6,5]  R1920     -3.6590325832366943e-01
    z[7,6,5]  R1921     -3.0864715576171875e-01
    z[7,6,5]  R1922     -3.1340357661247253e-01
    z[7,6,5]  R1923     1.8844987452030182e-01
    z[7,6,5]  R1924     -3.8047227263450623e-01
    z[7,6,5]  R1925     -2.8123003244400024e-01
    z[7,6,5]  R1926     -3.0721798539161682e-01
    z[7,6,5]  R1927     -3.0520227551460266e-01
    z[7,6,5]  R1928     -2.6596600189805031e-02
    z[7,6,5]  R1929     -2.2794160246849060e-01
    z[7,6,5]  R1930     -2.9888552427291870e-01
    z[7,6,5]  R1931     2.7011623978614807e-01
    z[7,6,5]  R1932     -1.4479759335517883e-01
    z[7,6,5]  R1933     -3.0097526311874390e-01
    z[7,6,5]  R1934     1.1131688207387924e-01
    z[7,6,5]  R1935     -3.7510967254638672e-01
    z[7,6,5]  R1936     -1.9735524058341980e-01
    z[7,6,5]  R1937     -1.3828532397747040e-01
    z[7,6,5]  R1938     -3.4852313995361328e-01
    z[7,6,5]  R1939     -2.5787869095802307e-01
    z[7,6,5]  R1940     -1.0327735543251038e-01
    z[7,6,5]  R1941     1.2150023831054568e-03
    z[7,6,5]  R1942     -2.3134063184261322e-01
    z[7,6,5]  R1943     4.0065199136734009e-02
    z[7,6,5]  R1944     -5.5110651254653931e-01
    z[7,6,5]  R1945     4.4556212425231934e-01
    z[7,6,5]  R1946     2.4070987105369568e-01
    z[7,6,5]  R1947     -1.0796731710433960e-01
    z[7,6,5]  R1948     2.1233783662319183e-01
    z[7,6,5]  R1949     -1.3205768167972565e-01
    z[7,6,5]  R1950     -2.4533860385417938e-01
    z[7,6,5]  R1951     -3.0848110094666481e-02
    z[7,6,5]  R1952     -1.4587184786796570e-01
    z[7,6,5]  R1953     0.252546489238739
    z[7,6,5]  R1954     -3.6108851432800293e-01
    z[7,6,5]  R1955     1.9542382657527924e-01
    z[7,6,5]  R1956     -2.3221735656261444e-01
    z[7,6,5]  R1957     -3.7104284763336182e-01
    z[7,6,5]  R1958     -4.8415485769510269e-02
    z[7,6,5]  R1959     2.5979939103126526e-01
    z[7,6,5]  R1960     -1.2629453837871552e-01
    z[7,6,5]  R1961     -4.3472938239574432e-02
    z[7,6,5]  R1962     -3.7419281434267759e-03
    z[7,6,5]  R1963     9.2434667050838470e-02
    z[7,6,5]  R1964     -4.2871972918510437e-01
    z[7,6,5]  R1965     -3.3051091432571411e-01
    z[7,6,5]  R1966     3.0744457244873047e-01
    z[7,6,5]  R1967     -1.1734230071306229e-01
    z[7,6,5]  R1968     -6.0735039412975311e-02
    z[7,6,5]  R1969     -4.1593369841575623e-01
    z[7,6,5]  R1970     1.5159327536821365e-02
    z[7,6,5]  R1971     2.9559774324297905e-02
    z[7,6,5]  R1972     -4.1807761788368225e-01
    z[7,6,5]  R1973     5.3183263540267944e-01
    z[7,6,5]  R1974     5.0590906292200089e-02
    z[7,6,5]  R1975     4.6976704150438309e-02
    z[7,6,5]  R1976     -4.1004788875579834e-01
    z[7,6,5]  R1977     -8.0488964915275574e-02
    z[7,6,5]  R1978     -1.3850995898246765e-01
    z[7,6,5]  R1979     1.7445281147956848e-01
    z[7,6,5]  R1980     -3.7980481982231140e-01
    z[7,6,5]  R1981     -0.549176037311554
    z[7,6,5]  R1982     -3.1081077456474304e-01
    z[7,6,5]  R1983     2.7003228664398193e-01
    z[7,6,5]  R1984     -1.6107386350631714e-01
    z[7,6,5]  R1985     -5.5078428983688354e-01
    z[7,6,5]  R1986     -3.1608107686042786e-01
    z[7,6,5]  R1987     -1.7238157987594604e-01
    z[7,6,5]  R1988     -1.0442781448364258e-01
    z[7,6,5]  R1989     2.9218757152557373e-01
    z[7,6,5]  R1990     -4.2967864871025085e-01
    z[7,6,5]  R1991     -1.0896987468004227e-01
    z[7,6,5]  R1992     1.6916318237781525e-01
    z[7,6,5]  R1993     0.0191938616335392
    z[7,6,5]  R1994     8.2310363650321960e-02
    z[7,6,5]  R1995     -2.0744070410728455e-01
    z[7,6,5]  R1996     -1.1092843860387802e-01
    z[7,6,5]  R1997     -1.8518300354480743e-01
    z[7,6,5]  R1998     2.7184817939996719e-02
    z[7,6,5]  R1999     -3.5375106334686279e-01
    z[7,6,5]  R2000     -3.9943951368331909e-01
    z[7,6,5]  R2001     4.8046806454658508e-01
    z[7,6,5]  R2002     -2.3944278061389923e-01
    z[7,6,5]  R2003     -7.0862270891666412e-02
    z[7,6,5]  R2004     3.5878576338291168e-02
    z[7,6,5]  R2005     -8.7139256298542023e-02
    z[7,6,5]  R2006     7.0316776633262634e-02
    z[7,6,5]  R2007     -4.3579056859016418e-02
    z[7,6,5]  R2008     2.8673139214515686e-01
    z[7,6,5]  R2009     4.2939415574073792e-01
    z[7,6,5]  R2010     -0.0457756407558918
    z[7,6,5]  R2011     4.9169689416885376e-01
    z[7,6,5]  R2012     0.598415195941925
    z[7,6,5]  R2013     2.3235686123371124e-01
    z[7,6,5]  R2014     4.0108706802129745e-02
    z[7,6,5]  R2015     -4.2695008218288422e-02
    z[7,6,5]  R2016     -6.1412472277879715e-02
    z[7,6,5]  R2017     1.9556295871734619e-01
    z[7,6,5]  R2018     1.6959644854068756e-01
    z[7,6,5]  R2019     2.7440250851213932e-03
    z[7,6,5]  R2020     1.1292400211095810e-01
    z[7,6,5]  R2021     1.4733427762985229e-01
    z[7,6,5]  R2022     1.5611982345581055e-01
    z[7,6,5]  R2023     -1.3234174251556396e-01
    z[7,6,5]  R2024     -5.2889758348464966e-01
    z[7,6,5]  R2025     -4.0778699517250061e-01
    z[7,6,5]  R2026     -4.3332013487815857e-01
    z[7,6,5]  R2027     -3.9692139625549316e-01
    z[7,6,5]  R2028     1.8549689650535583e-01
    z[7,6,5]  R2029     6.4147424697875977e-01
    z[7,6,5]  R2030     4.3304291367530823e-01
    z[7,6,5]  R2031     2.6354651898145676e-02
    z[7,6,5]  R2032     3.8828876614570618e-01
    z[7,6,5]  R2033     1.9409877061843872e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R1892     -1
    z[7,6,6]  R1893     1
    z[7,6,6]  R1894     -2.0635235309600830e-01
    z[7,6,6]  R1895     2.2748260200023651e-01
    z[7,6,6]  R1896     1.0516013205051422e-01
    z[7,6,6]  R1897     -3.9368532598018646e-02
    z[7,6,6]  R1898     -3.6459761857986450e-01
    z[7,6,6]  R1899     -2.8335893154144287e-01
    z[7,6,6]  R1900     -5.0444173812866211e-01
    z[7,6,6]  R1901     -1.5931384265422821e-01
    z[7,6,6]  R1902     -5.7740285992622375e-03
    z[7,6,6]  R1903     -2.2962391376495361e-01
    z[7,6,6]  R1904     -1.3790573179721832e-01
    z[7,6,6]  R1905     -1.6364523768424988e-01
    z[7,6,6]  R1906     -8.3632849156856537e-02
    z[7,6,6]  R1907     6.0002632439136505e-02
    z[7,6,6]  R1908     1.8504603207111359e-01
    z[7,6,6]  R1909     -2.1147492527961731e-01
    z[7,6,6]  R1910     1.3096566312015057e-02
    z[7,6,6]  R1911     -2.7766495943069458e-01
    z[7,6,6]  R1912     -8.0890739336609840e-03
    z[7,6,6]  R1913     2.4081563949584961e-01
    z[7,6,6]  R1914     1.4388850331306458e-01
    z[7,6,6]  R1915     5.9924638271331787e-01
    z[7,6,6]  R1916     4.3836173415184021e-01
    z[7,6,6]  R1917     4.5063480734825134e-01
    z[7,6,6]  R1918     1.4219434559345245e-01
    z[7,6,6]  R1919     4.7252067923545837e-01
    z[7,6,6]  R1920     -4.1448645293712616e-02
    z[7,6,6]  R1921     1.7293691635131836e-01
    z[7,6,6]  R1922     2.1829646080732346e-02
    z[7,6,6]  R1923     3.9265986531972885e-02
    z[7,6,6]  R1924     7.6660722494125366e-02
    z[7,6,6]  R1925     -5.6128031015396118e-01
    z[7,6,6]  R1926     4.9747237563133240e-01
    z[7,6,6]  R1927     -4.6390643715858459e-01
    z[7,6,6]  R1928     4.7608932852745056e-01
    z[7,6,6]  R1929     -6.2533393502235413e-02
    z[7,6,6]  R1930     2.1993571519851685e-01
    z[7,6,6]  R1931     3.4372383356094360e-01
    z[7,6,6]  R1932     3.4728819131851196e-01
    z[7,6,6]  R1933     0.255688339471817
    z[7,6,6]  R1934     4.2310228943824768e-01
    z[7,6,6]  R1935     6.8588759750127792e-03
    z[7,6,6]  R1936     2.3477682471275330e-01
    z[7,6,6]  R1937     -4.1881051659584045e-01
    z[7,6,6]  R1938     3.9004996418952942e-01
    z[7,6,6]  R1939     -0.335882306098938
    z[7,6,6]  R1940     -1.6593678295612335e-01
    z[7,6,6]  R1941     2.6671022176742554e-01
    z[7,6,6]  R1942     6.2468592077493668e-03
    z[7,6,6]  R1943     -8.7136939167976379e-02
    z[7,6,6]  R1944     -2.9209271073341370e-01
    z[7,6,6]  R1945     0.44937664270401
    z[7,6,6]  R1946     -9.9995970726013184e-02
    z[7,6,6]  R1947     1.3004487752914429e-01
    z[7,6,6]  R1948     -4.5862618088722229e-01
    z[7,6,6]  R1949     -5.1394551992416382e-01
    z[7,6,6]  R1950     -2.0621180534362793e-01
    z[7,6,6]  R1951     2.0252232253551483e-01
    z[7,6,6]  R1952     -1.0687220841646194e-01
    z[7,6,6]  R1953     -6.3475079834461212e-02
    z[7,6,6]  R1954     -1.4392933249473572e-01
    z[7,6,6]  R1955     3.9627268910408020e-01
    z[7,6,6]  R1956     -1.1192449927330017e-01
    z[7,6,6]  R1957     -1.2898662686347961e-01
    z[7,6,6]  R1958     4.8706603050231934e-01
    z[7,6,6]  R1959     1.6122156381607056e-01
    z[7,6,6]  R1960     -0.574490487575531
    z[7,6,6]  R1961     2.2059172391891479e-02
    z[7,6,6]  R1962     2.1027492359280586e-02
    z[7,6,6]  R1963     -9.4802536070346832e-02
    z[7,6,6]  R1964     -2.5701060891151428e-02
    z[7,6,6]  R1965     -1.7384913563728333e-01
    z[7,6,6]  R1966     0.0712905079126358
    z[7,6,6]  R1967     -2.4445161223411560e-01
    z[7,6,6]  R1968     -4.6912181377410889e-01
    z[7,6,6]  R1969     -2.4328069388866425e-01
    z[7,6,6]  R1970     3.8897043466567993e-01
    z[7,6,6]  R1971     -3.2586455345153809e-01
    z[7,6,6]  R1972     1.1651214212179184e-02
    z[7,6,6]  R1973     1.5964837744832039e-02
    z[7,6,6]  R1974     7.3880054056644440e-02
    z[7,6,6]  R1975     -3.6409109830856323e-02
    z[7,6,6]  R1976     1.9887593388557434e-01
    z[7,6,6]  R1977     2.9521992802619934e-01
    z[7,6,6]  R1978     5.9096522629261017e-02
    z[7,6,6]  R1979     4.5569464564323425e-01
    z[7,6,6]  R1980     -1.0193645209074020e-01
    z[7,6,6]  R1981     -2.6325622200965881e-01
    z[7,6,6]  R1982     5.2250474691390991e-02
    z[7,6,6]  R1983     6.4070552587509155e-02
    z[7,6,6]  R1984     -2.2096963226795197e-01
    z[7,6,6]  R1985     -1.0697133839130402e-01
    z[7,6,6]  R1986     6.6424749791622162e-02
    z[7,6,6]  R1987     -2.0087711513042450e-02
    z[7,6,6]  R1988     2.4833540618419647e-01
    z[7,6,6]  R1989     8.2687549293041229e-02
    z[7,6,6]  R1990     -3.9547204971313477e-01
    z[7,6,6]  R1991     -2.3731590807437897e-01
    z[7,6,6]  R1992     -3.3022749423980713e-01
    z[7,6,6]  R1993     -0.458345502614975
    z[7,6,6]  R1994     4.8635181784629822e-01
    z[7,6,6]  R1995     -2.1411462128162384e-01
    z[7,6,6]  R1996     1.3943125307559967e-01
    z[7,6,6]  R1997     3.0752828717231750e-01
    z[7,6,6]  R1998     1.5022693574428558e-01
    z[7,6,6]  R1999     -6.2335506081581116e-02
    z[7,6,6]  R2000     2.1135514974594116e-01
    z[7,6,6]  R2001     -0.360663503408432
    z[7,6,6]  R2002     6.0167215764522552e-02
    z[7,6,6]  R2003     2.0817078649997711e-02
    z[7,6,6]  R2004     -4.4671460986137390e-01
    z[7,6,6]  R2005     1.3010539114475250e-01
    z[7,6,6]  R2006     -3.1203389167785645e-01
    z[7,6,6]  R2007     1.4815047383308411e-01
    z[7,6,6]  R2008     -4.8706978559494019e-01
    z[7,6,6]  R2009     2.7129575610160828e-01
    z[7,6,6]  R2010     1.4876447618007660e-01
    z[7,6,6]  R2011     1.9188860058784485e-01
    z[7,6,6]  R2012     1.4020219445228577e-01
    z[7,6,6]  R2013     2.9772892594337463e-01
    z[7,6,6]  R2014     -2.3278956115245819e-01
    z[7,6,6]  R2015     -1.3321335613727570e-01
    z[7,6,6]  R2016     2.6396209001541138e-01
    z[7,6,6]  R2017     7.8763835132122040e-02
    z[7,6,6]  R2018     -2.0926684141159058e-01
    z[7,6,6]  R2019     5.5498555302619934e-02
    z[7,6,6]  R2020     2.3121263831853867e-02
    z[7,6,6]  R2021     1.2275070697069168e-01
    z[7,6,6]  R2022     2.4432279169559479e-01
    z[7,6,6]  R2023     -8.0082036554813385e-02
    z[7,6,6]  R2024     7.2437882423400879e-01
    z[7,6,6]  R2025     -4.5620280504226685e-01
    z[7,6,6]  R2026     -6.0417965054512024e-02
    z[7,6,6]  R2027     2.5813746452331543e-01
    z[7,6,6]  R2028     -2.1989642083644867e-01
    z[7,6,6]  R2029     -6.9250069558620453e-02
    z[7,6,6]  R2030     -2.6759475469589233e-01
    z[7,6,6]  R2031     -2.6893958449363708e-01
    z[7,6,6]  R2032     -3.3165183663368225e-01
    z[7,6,6]  R2033     4.8224378377199173e-02
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2034     -1
    z[7,8,0]  R2035     1
    z[7,8,0]  R2048     0.77576744556427
    z[7,8,0]  R2049     8.8025522232055664e-01
    z[7,8,0]  R2050     6.4333146810531616e-01
    z[7,8,0]  R2051     8.7296146154403687e-01
    z[7,8,0]  R2052     6.7654889822006226e-01
    z[7,8,0]  R2053     7.7571070194244385e-01
    z[7,8,0]  R2054     7.1319955587387085e-01
    z[7,8,0]  R2055     7.6416790485382080e-01
    z[7,8,0]  R2056     0.66385817527771
    z[7,8,0]  R2057     7.3412883281707764e-01
    z[7,8,0]  R2058     -0.0723298192024231
    z[7,8,0]  R2059     -3.6823704838752747e-01
    z[7,8,0]  R2060     -1.8581800162792206e-01
    z[7,8,0]  R2061     -2.1017327904701233e-01
    z[7,8,0]  R2062     -4.3952235579490662e-01
    z[7,8,0]  R2063     -0.404788076877594
    z[7,8,0]  R2064     6.5057352185249329e-02
    z[7,8,0]  R2065     -3.6465483903884888e-01
    z[7,8,0]  R2066     -7.1978025138378143e-02
    z[7,8,0]  R2067     -1.6103573143482208e-02
    z[7,8,0]  R2068     1.5172088146209717e-01
    z[7,8,0]  R2069     8.2185946404933929e-02
    z[7,8,0]  R2070     2.3939360678195953e-01
    z[7,8,0]  R2071     0.133229598402977
    z[7,8,0]  R2072     3.4232255816459656e-01
    z[7,8,0]  R2073     2.4072253704071045e-01
    z[7,8,0]  R2074     -0.907288670539856
    z[7,8,0]  R2075     -9.0061253309249878e-01
    z[7,8,0]  R2076     -7.9439109563827515e-01
    z[7,8,0]  R2077     -7.9312282800674438e-01
    z[7,8,0]  R2078     6.7805558443069458e-02
    z[7,8,0]  R2079     3.4394392371177673e-01
    z[7,8,0]  R2080     3.5133108496665955e-01
    z[7,8,0]  R2081     2.5730523467063904e-01
    z[7,8,0]  R2082     -4.4008356332778931e-01
    z[7,8,0]  R2083     -8.8031291961669922e-02
    z[7,8,0]  R2084     -1.8469962477684021e-01
    z[7,8,0]  R2085     1.5967264771461487e-01
    z[7,8,0]  R2086     -7.2020488977432251e-01
    z[7,8,0]  R2087     -5.1735591888427734e-01
    z[7,8,0]  R2088     6.6200077533721924e-01
    z[7,8,0]  R2089     6.1138284206390381e-01
    z[7,8,0]  R2090     3.5945829749107361e-01
    z[7,8,0]  R2091     3.4982198476791382e-01
    z[7,8,0]  R2092     4.5862689614295959e-01
    z[7,8,0]  R2093     -3.2159939408302307e-02
    z[7,8,0]  R2094     -0.553945779800415
    z[7,8,0]  R2095     -1.6781832277774811e-01
    z[7,8,0]  R2096     2.1491825580596924e-01
    z[7,8,0]  R2097     -8.2912176847457886e-01
    z[7,8,0]  R2098     3.9126396179199219e-01
    z[7,8,0]  R2099     2.4881863594055176e-01
    z[7,8,0]  R2100     2.1482163667678833e-01
    z[7,8,0]  R2101     1.6018109396100044e-02
    z[7,8,0]  R2102     1.4037631452083588e-01
    z[7,8,0]  R2103     -1.0633911192417145e-01
    z[7,8,0]  R2104     3.5546919703483582e-01
    z[7,8,0]  R2105     -7.3311340808868408e-01
    z[7,8,0]  R2106     -0.69478839635849
    z[7,8,0]  R2107     -6.0788959264755249e-01
    z[7,8,0]  R2108     9.3835823237895966e-02
    z[7,8,0]  R2109     3.0185481905937195e-01
    z[7,8,0]  R2110     6.9934844970703125e-02
    z[7,8,0]  R2111     -3.5546261817216873e-02
    z[7,8,0]  R2112     -2.1151846647262573e-01
    z[7,8,0]  R2113     2.6397460699081421e-01
    z[7,8,0]  R2114     1.4714916236698627e-02
    z[7,8,0]  R2115     -0.826717734336853
    z[7,8,0]  R2116     -5.6553375720977783e-01
    z[7,8,0]  R2117     -4.6557343006134033e-01
    z[7,8,0]  R2118     2.2465810179710388e-01
    z[7,8,0]  R2119     -7.3979392647743225e-02
    z[7,8,0]  R2120     -0.567614734172821
    z[7,8,0]  R2121     2.2830119729042053e-01
    z[7,8,0]  R2122     3.2732114195823669e-01
    z[7,8,0]  R2123     -2.1348632872104645e-01
    z[7,8,0]  R2124     -5.2942311763763428e-01
    z[7,8,0]  R2125     -4.3943038582801819e-01
    z[7,8,0]  R2126     -7.5273221731185913e-01
    z[7,8,0]  R2127     -2.6824358105659485e-01
    z[7,8,0]  R2128     -5.7141637802124023e-01
    z[7,8,0]  R2129     -7.9831665754318237e-01
    z[7,8,0]  R2130     2.3983244597911835e-01
    z[7,8,0]  R2131     -4.5837086439132690e-01
    z[7,8,0]  R2132     -2.7903449535369873e-01
    z[7,8,0]  R2133     -2.3343828320503235e-01
    z[7,8,0]  R2134     -1.9718140363693237e-01
    z[7,8,0]  R2135     1.6486378014087677e-01
    z[7,8,0]  R2136     -8.1450670957565308e-01
    z[7,8,0]  R2137     -2.9810729622840881e-01
    z[7,8,0]  R2138     0.346869558095932
    z[7,8,0]  R2139     1.3677033782005310e-01
    z[7,8,0]  R2140     -2.9752010107040405e-01
    z[7,8,0]  R2141     -2.8384643793106079e-01
    z[7,8,0]  R2142     1.6154052317142487e-01
    z[7,8,0]  R2143     -4.7044627368450165e-02
    z[7,8,0]  R2144     2.0723946392536163e-01
    z[7,8,0]  R2145     -0.820107102394104
    z[7,8,0]  R2146     -5.7578301429748535e-01
    z[7,8,0]  R2147     -0.0969822108745575
    z[7,8,0]  R2148     6.0532465577125549e-02
    z[7,8,0]  R2149     -4.2753165960311890e-01
    z[7,8,0]  R2150     -1.7922100424766541e-01
    z[7,8,0]  R2151     -5.5445814132690430e-01
    z[7,8,0]  R2152     0.257851779460907
    z[7,8,0]  R2153     -1.9561986625194550e-01
    z[7,8,0]  R2154     -7.6634180545806885e-01
    z[7,8,0]  R2155     -2.9960823059082031e-01
    z[7,8,0]  R2156     -6.7675042152404785e-01
    z[7,8,0]  R2157     -7.6143556833267212e-01
    z[7,8,0]  R2158     7.0530152320861816e-01
    z[7,8,0]  R2159     8.8695132732391357e-01
    z[7,8,0]  R2160     7.5331693887710571e-01
    z[7,8,0]  R2161     9.0934127569198608e-01
    z[7,8,0]  R2162     8.2864642143249512e-01
    z[7,8,0]  R2163     9.4234520196914673e-01
    z[7,8,0]  R2164     9.3040871620178223e-01
    z[7,8,0]  R2165     0.736838161945343
    z[7,8,0]  R2166     8.6052078008651733e-01
    z[7,8,0]  R2167     0.713066577911377
    z[7,8,0]  R2168     1.3651348650455475e-01
    z[7,8,0]  R2169     -3.2548218965530396e-02
    z[7,8,0]  R2170     -4.8324260115623474e-01
    z[7,8,0]  R2171     4.2534127831459045e-02
    z[7,8,0]  R2172     -2.1742577850818634e-01
    z[7,8,0]  R2173     -5.1593035459518433e-01
    z[7,8,0]  R2174     -3.0395722389221191e-01
    z[7,8,0]  R2175     -7.2562158107757568e-02
    z[7,8,0]  R2176     -5.1913022994995117e-01
    z[7,8,0]  R2177     -1.5697129070758820e-01
    z[7,8,0]  R2178     -3.2283249497413635e-01
    z[7,8,0]  R2179     -0.721881091594696
    z[7,8,0]  R2180     -2.3561200499534607e-01
    z[7,8,0]  R2181     -2.9592856764793396e-01
    z[7,8,0]  R2182     -2.5959175825119019e-01
    z[7,8,0]  R2183     -2.2420540452003479e-01
    z[7,8,0]  R2184     -4.0958243608474731e-01
    z[7,8,0]  R2185     -0.331001877784729
    z[7,8,0]  R2186     -2.5792077183723450e-01
    z[7,8,0]  R2187     -1.9591730833053589e-01
    z[7,8,0]  R2188     -2.6988866925239563e-01
    z[7,8,0]  R2189     -6.8003219366073608e-01
    z[7,8,0]  R2190     -6.5597808361053467e-01
    z[7,8,0]  R2191     -8.8376182317733765e-01
    z[7,8,0]  R2192     -0.755744218826294
    z[7,8,0]  R2193     -8.1956106424331665e-01
    z[7,8,0]  R2194     -6.7751920223236084e-01
    z[7,8,0]  R2195     -6.9661718606948853e-01
    z[7,8,0]  R2196     -5.9385901689529419e-01
    z[7,8,0]  R2197     -5.2864837646484375e-01
    z[7,8,0]  R2198     7.0176303386688232e-02
    z[7,8,0]  R2199     -0.313693106174469
    z[7,8,0]  R2200     -4.1877318173646927e-02
    z[7,8,0]  R2201     -8.0878752470016479e-01
    z[7,8,0]  R2202     -1.6961207985877991e-01
    z[7,8,0]  R2203     -8.6870723962783813e-01
    z[7,8,0]  R2204     -6.7262911796569824e-01
    z[7,8,0]  R2205     -8.4285312891006470e-01
    z[7,8,0]  R2206     -2.3766933381557465e-01
    z[7,8,0]  R2207     -9.1773825883865356e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2036     -1
    z[7,8,1]  R2037     1
    z[7,8,1]  R2048     1.6411490738391876e-02
    z[7,8,1]  R2049     1.8768697977066040e-01
    z[7,8,1]  R2050     -2.3674362897872925e-01
    z[7,8,1]  R2051     2.9516544938087463e-01
    z[7,8,1]  R2052     2.3874360322952271e-01
    z[7,8,1]  R2053     2.4278904497623444e-01
    z[7,8,1]  R2054     3.0271226167678833e-01
    z[7,8,1]  R2055     -5.8600634336471558e-02
    z[7,8,1]  R2056     2.9660817980766296e-01
    z[7,8,1]  R2057     4.3455091118812561e-01
    z[7,8,1]  R2058     5.2240979671478271e-01
    z[7,8,1]  R2059     -5.1190710067749023e-01
    z[7,8,1]  R2060     -4.8452475666999817e-01
    z[7,8,1]  R2061     -0.502964437007904
    z[7,8,1]  R2062     -4.7964704036712646e-01
    z[7,8,1]  R2063     -0.854331910610199
    z[7,8,1]  R2064     -5.2673918008804321e-01
    z[7,8,1]  R2065     -4.7937366366386414e-01
    z[7,8,1]  R2066     -7.8769600391387939e-01
    z[7,8,1]  R2067     -5.6490635871887207e-01
    z[7,8,1]  R2068     1.2438297271728516e-02
    z[7,8,1]  R2069     6.8744570016860962e-01
    z[7,8,1]  R2070     4.6005198359489441e-01
    z[7,8,1]  R2071     -7.7825301885604858e-01
    z[7,8,1]  R2072     -2.2731673717498779e-01
    z[7,8,1]  R2073     -6.9942563772201538e-01
    z[7,8,1]  R2074     -1.7192485928535461e-01
    z[7,8,1]  R2075     -1.9084727764129639e-01
    z[7,8,1]  R2076     -3.4105113148689270e-01
    z[7,8,1]  R2077     -2.1921217441558838e-01
    z[7,8,1]  R2078     6.6876864433288574e-01
    z[7,8,1]  R2079     2.2041143476963043e-01
    z[7,8,1]  R2080     2.5117090344429016e-01
    z[7,8,1]  R2081     1.6876345872879028e-01
    z[7,8,1]  R2082     -7.2898006439208984e-01
    z[7,8,1]  R2083     -7.4544352293014526e-01
    z[7,8,1]  R2084     -5.6649994850158691e-01
    z[7,8,1]  R2085     -0.865119218826294
    z[7,8,1]  R2086     -0.507922351360321
    z[7,8,1]  R2087     -0.618511438369751
    z[7,8,1]  R2088     -2.1649330854415894e-01
    z[7,8,1]  R2089     3.0930796265602112e-01
    z[7,8,1]  R2090     8.4924995899200439e-01
    z[7,8,1]  R2091     4.2335382103919983e-01
    z[7,8,1]  R2092     4.6006661653518677e-01
    z[7,8,1]  R2093     7.8704708814620972e-01
    z[7,8,1]  R2094     -7.1661293506622314e-01
    z[7,8,1]  R2095     -7.4266058206558228e-01
    z[7,8,1]  R2096     -8.4290659427642822e-01
    z[7,8,1]  R2097     -4.6834820508956909e-01
    z[7,8,1]  R2098     3.1773579120635986e-01
    z[7,8,1]  R2099     3.5326966643333435e-01
    z[7,8,1]  R2100     -8.7270236015319824e-01
    z[7,8,1]  R2101     -8.1956350803375244e-01
    z[7,8,1]  R2102     6.7453527450561523e-01
    z[7,8,1]  R2103     -5.3128945827484131e-01
    z[7,8,1]  R2104     -0.854092001914978
    z[7,8,1]  R2105     1.3329645991325378e-01
    z[7,8,1]  R2106     1.7880636453628540e-01
    z[7,8,1]  R2107     -1.1599297635257244e-02
    z[7,8,1]  R2108     7.3112434148788452e-01
    z[7,8,1]  R2109     3.0246776342391968e-01
    z[7,8,1]  R2110     -6.0424768924713135e-01
    z[7,8,1]  R2111     -0.900780975818634
    z[7,8,1]  R2112     -7.2514319419860840e-01
    z[7,8,1]  R2113     4.5567423105239868e-01
    z[7,8,1]  R2114     -6.1548978090286255e-01
    z[7,8,1]  R2115     -2.8613340854644775e-01
    z[7,8,1]  R2116     2.3322394490242004e-01
    z[7,8,1]  R2117     2.5845530629158020e-01
    z[7,8,1]  R2118     4.8997023701667786e-01
    z[7,8,1]  R2119     4.0439867973327637e-01
    z[7,8,1]  R2120     -0.656741201877594
    z[7,8,1]  R2121     -8.8230144977569580e-01
    z[7,8,1]  R2122     -8.0567622184753418e-01
    z[7,8,1]  R2123     -5.0674062967300415e-01
    z[7,8,1]  R2124     -5.5835723876953125e-01
    z[7,8,1]  R2125     1.6405096650123596e-01
    z[7,8,1]  R2126     4.2379528284072876e-02
    z[7,8,1]  R2127     -2.6594796776771545e-01
    z[7,8,1]  R2128     -5.7925939559936523e-01
    z[7,8,1]  R2129     -5.6226819753646851e-01
    z[7,8,1]  R2130     -7.9547297954559326e-01
    z[7,8,1]  R2131     -6.3943260908126831e-01
    z[7,8,1]  R2132     -5.9386724233627319e-01
    z[7,8,1]  R2133     -7.3498421907424927e-01
    z[7,8,1]  R2134     -3.1208464503288269e-01
    z[7,8,1]  R2135     -6.8900579214096069e-01
    z[7,8,1]  R2136     -3.7101477384567261e-01
    z[7,8,1]  R2137     6.6063500940799713e-02
    z[7,8,1]  R2138     5.4832839965820312e-01
    z[7,8,1]  R2139     5.9515094757080078e-01
    z[7,8,1]  R2140     -7.0391672849655151e-01
    z[7,8,1]  R2141     -6.7108732461929321e-01
    z[7,8,1]  R2142     -0.752247154712677
    z[7,8,1]  R2143     -8.9022374153137207e-01
    z[7,8,1]  R2144     -7.2310638427734375e-01
    z[7,8,1]  R2145     2.3239577189087868e-02
    z[7,8,1]  R2146     -2.1518308669328690e-02
    z[7,8,1]  R2147     -4.8537105321884155e-01
    z[7,8,1]  R2148     2.7299115061759949e-01
    z[7,8,1]  R2149     -6.1635011434555054e-01
    z[7,8,1]  R2150     -8.9283865690231323e-01
    z[7,8,1]  R2151     -6.3888096809387207e-01
    z[7,8,1]  R2152     0.512329638004303
    z[7,8,1]  R2153     -2.2371679544448853e-01
    z[7,8,1]  R2154     -3.9436888694763184e-01
    z[7,8,1]  R2155     -4.8325982689857483e-01
    z[7,8,1]  R2156     3.8783061504364014e-01
    z[7,8,1]  R2157     2.6828026771545410e-01
    z[7,8,1]  R2158     1.9630730152130127e-02
    z[7,8,1]  R2159     -7.9196922481060028e-02
    z[7,8,1]  R2160     -1.9613333046436310e-02
    z[7,8,1]  R2161     1.1365023255348206e-01
    z[7,8,1]  R2162     -3.1931233406066895e-01
    z[7,8,1]  R2163     -1.1122805625200272e-01
    z[7,8,1]  R2164     1.1261923238635063e-02
    z[7,8,1]  R2165     -2.4862538278102875e-01
    z[7,8,1]  R2166     -5.1845584064722061e-02
    z[7,8,1]  R2167     -0.0972457155585289
    z[7,8,1]  R2168     8.0286830663681030e-01
    z[7,8,1]  R2169     5.8779406547546387e-01
    z[7,8,1]  R2170     5.0273990631103516e-01
    z[7,8,1]  R2171     4.3708527088165283e-01
    z[7,8,1]  R2172     4.7819891571998596e-01
    z[7,8,1]  R2173     4.5853444933891296e-01
    z[7,8,1]  R2174     4.3781113624572754e-01
    z[7,8,1]  R2175     5.7233953475952148e-01
    z[7,8,1]  R2176     5.0355130434036255e-01
    z[7,8,1]  R2177     3.4641581773757935e-01
    z[7,8,1]  R2178     -9.3039542436599731e-01
    z[7,8,1]  R2179     2.0746754109859467e-01
    z[7,8,1]  R2180     -8.8955307006835938e-01
    z[7,8,1]  R2181     -0.88219153881073
    z[7,8,1]  R2182     -8.5865569114685059e-01
    z[7,8,1]  R2183     -9.2376661300659180e-01
    z[7,8,1]  R2184     -8.7629443407058716e-01
    z[7,8,1]  R2185     -8.7441927194595337e-01
    z[7,8,1]  R2186     -8.8528978824615479e-01
    z[7,8,1]  R2187     -8.8353222608566284e-01
    z[7,8,1]  R2188     -6.1534738540649414e-01
    z[7,8,1]  R2189     1.6282060742378235e-01
    z[7,8,1]  R2190     -4.4630587100982666e-01
    z[7,8,1]  R2191     -1.6083197295665741e-01
    z[7,8,1]  R2192     -6.9364093244075775e-02
    z[7,8,1]  R2193     -2.9856148362159729e-01
    z[7,8,1]  R2194     -1.5196952223777771e-01
    z[7,8,1]  R2195     -1.4520509541034698e-01
    z[7,8,1]  R2196     -1.8252392113208771e-01
    z[7,8,1]  R2197     3.3651031553745270e-02
    z[7,8,1]  R2198     -3.3370348811149597e-01
    z[7,8,1]  R2199     -6.3353508710861206e-01
    z[7,8,1]  R2200     -9.1670429706573486e-01
    z[7,8,1]  R2201     2.0634920895099640e-01
    z[7,8,1]  R2202     -0.873768150806427
    z[7,8,1]  R2203     2.2565890848636627e-01
    z[7,8,1]  R2204     3.6477770656347275e-02
    z[7,8,1]  R2205     -1.0097629576921463e-01
    z[7,8,1]  R2206     -8.6336147785186768e-01
    z[7,8,1]  R2207     1.5227134525775909e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2038     -1
    z[7,8,2]  R2039     1
    z[7,8,2]  R2048     2.5777277350425720e-01
    z[7,8,2]  R2049     -1.1954865604639053e-01
    z[7,8,2]  R2050     1.0909274965524673e-01
    z[7,8,2]  R2051     -1.0482856631278992e-01
    z[7,8,2]  R2052     -2.9389381408691406e-01
    z[7,8,2]  R2053     -0.358809232711792
    z[7,8,2]  R2054     -0.108444444835186
    z[7,8,2]  R2055     1.3620543479919434e-01
    z[7,8,2]  R2056     -9.4696566462516785e-02
    z[7,8,2]  R2057     -2.3804001510143280e-01
    z[7,8,2]  R2058     4.7510975599288940e-01
    z[7,8,2]  R2059     -4.3975785374641418e-01
    z[7,8,2]  R2060     -6.3251811265945435e-01
    z[7,8,2]  R2061     -6.5593171119689941e-01
    z[7,8,2]  R2062     -3.6732786893844604e-01
    z[7,8,2]  R2063     5.5395025759935379e-02
    z[7,8,2]  R2064     -5.7521623373031616e-01
    z[7,8,2]  R2065     -5.3364193439483643e-01
    z[7,8,2]  R2066     -4.8240253329277039e-01
    z[7,8,2]  R2067     -4.0648695826530457e-01
    z[7,8,2]  R2068     7.5240141153335571e-01
    z[7,8,2]  R2069     2.6230162382125854e-01
    z[7,8,2]  R2070     -1.4601278118789196e-02
    z[7,8,2]  R2071     1.1752258241176605e-01
    z[7,8,2]  R2072     5.1802337169647217e-01
    z[7,8,2]  R2073     -8.5014671087265015e-02
    z[7,8,2]  R2074     -4.3336819857358932e-02
    z[7,8,2]  R2075     -6.9281840696930885e-03
    z[7,8,2]  R2076     2.6703259348869324e-01
    z[7,8,2]  R2077     4.8138287663459778e-01
    z[7,8,2]  R2078     6.2798202037811279e-01
    z[7,8,2]  R2079     5.0892859697341919e-01
    z[7,8,2]  R2080     3.6279958486557007e-01
    z[7,8,2]  R2081     3.9509826898574829e-01
    z[7,8,2]  R2082     -1.8965192139148712e-01
    z[7,8,2]  R2083     -4.0701773762702942e-01
    z[7,8,2]  R2084     -3.4555483609437943e-02
    z[7,8,2]  R2085     -3.2562226057052612e-02
    z[7,8,2]  R2086     -1.1808338761329651e-01
    z[7,8,2]  R2087     -3.9527878165245056e-01
    z[7,8,2]  R2088     2.0764118060469627e-02
    z[7,8,2]  R2089     3.7314009666442871e-01
    z[7,8,2]  R2090     1.9965112209320068e-01
    z[7,8,2]  R2091     5.7231187820434570e-01
    z[7,8,2]  R2092     1.8976931273937225e-01
    z[7,8,2]  R2093     1.5339636802673340e-01
    z[7,8,2]  R2094     -3.3698305487632751e-01
    z[7,8,2]  R2095     -6.9558590650558472e-02
    z[7,8,2]  R2096     -2.9084178805351257e-01
    z[7,8,2]  R2097     1.6147981584072113e-01
    z[7,8,2]  R2098     5.5289882421493530e-01
    z[7,8,2]  R2099     5.6592386960983276e-01
    z[7,8,2]  R2100     -2.6835048198699951e-01
    z[7,8,2]  R2101     -4.5116010308265686e-01
    z[7,8,2]  R2102     3.9275681972503662e-01
    z[7,8,2]  R2103     1.4864921569824219e-01
    z[7,8,2]  R2104     1.4777974784374237e-01
    z[7,8,2]  R2105     1.4433830045163631e-02
    z[7,8,2]  R2106     5.8649875223636627e-02
    z[7,8,2]  R2107     9.5928184688091278e-02
    z[7,8,2]  R2108     2.0550854504108429e-01
    z[7,8,2]  R2109     0.733496904373169
    z[7,8,2]  R2110     -3.0421867966651917e-01
    z[7,8,2]  R2111     4.0832184255123138e-02
    z[7,8,2]  R2112     -2.1121737360954285e-01
    z[7,8,2]  R2113     -2.3063591122627258e-01
    z[7,8,2]  R2114     -1.8074475228786469e-01
    z[7,8,2]  R2115     2.3348145186901093e-01
    z[7,8,2]  R2116     -5.4902553558349609e-02
    z[7,8,2]  R2117     -1.1982156336307526e-01
    z[7,8,2]  R2118     4.7163677215576172e-01
    z[7,8,2]  R2119     4.8232552409172058e-01
    z[7,8,2]  R2120     9.2045597732067108e-02
    z[7,8,2]  R2121     4.4353265315294266e-02
    z[7,8,2]  R2122     -0.0972619354724884
    z[7,8,2]  R2123     -2.3143781721591949e-01
    z[7,8,2]  R2124     3.4219604730606079e-01
    z[7,8,2]  R2125     -1.6744692623615265e-01
    z[7,8,2]  R2126     -3.4664005041122437e-01
    z[7,8,2]  R2127     -7.7150254510343075e-03
    z[7,8,2]  R2128     -3.6362352967262268e-01
    z[7,8,2]  R2129     1.8867236375808716e-01
    z[7,8,2]  R2130     -3.1880292296409607e-01
    z[7,8,2]  R2131     2.4227949976921082e-01
    z[7,8,2]  R2132     2.2747018933296204e-01
    z[7,8,2]  R2133     1.7310473322868347e-01
    z[7,8,2]  R2134     2.0147490501403809e-01
    z[7,8,2]  R2135     -3.0700030922889709e-01
    z[7,8,2]  R2136     1.7181381583213806e-02
    z[7,8,2]  R2137     -2.2931785881519318e-01
    z[7,8,2]  R2138     6.6481626033782959e-01
    z[7,8,2]  R2139     2.7252513170242310e-01
    z[7,8,2]  R2140     -2.7540338039398193e-01
    z[7,8,2]  R2141     7.6584428548812866e-02
    z[7,8,2]  R2142     -5.7331192493438721e-01
    z[7,8,2]  R2143     -2.6023969054222107e-01
    z[7,8,2]  R2144     -2.5527155399322510e-01
    z[7,8,2]  R2145     -1.5020149759948254e-02
    z[7,8,2]  R2146     -6.1559706926345825e-02
    z[7,8,2]  R2147     7.7393390238285065e-02
    z[7,8,2]  R2148     6.6374713182449341e-01
    z[7,8,2]  R2149     1.5252985060214996e-01
    z[7,8,2]  R2150     -3.3343076705932617e-01
    z[7,8,2]  R2151     -3.8093057274818420e-01
    z[7,8,2]  R2152     -4.5072987675666809e-01
    z[7,8,2]  R2153     3.1683048605918884e-01
    z[7,8,2]  R2154     -6.4119093120098114e-02
    z[7,8,2]  R2155     1.8009927123785019e-02
    z[7,8,2]  R2156     -5.0373566150665283e-01
    z[7,8,2]  R2157     -5.5464059114456177e-01
    z[7,8,2]  R2158     0.508542537689209
    z[7,8,2]  R2159     3.8803330063819885e-01
    z[7,8,2]  R2160     4.5523053407669067e-01
    z[7,8,2]  R2161     1.8744862079620361e-01
    z[7,8,2]  R2162     3.4964513778686523e-01
    z[7,8,2]  R2163     1.0699527338147163e-02
    z[7,8,2]  R2164     2.3295685648918152e-01
    z[7,8,2]  R2165     5.0984853506088257e-01
    z[7,8,2]  R2166     6.4617067575454712e-02
    z[7,8,2]  R2167     4.4522005319595337e-01
    z[7,8,2]  R2168     -2.8069171309471130e-01
    z[7,8,2]  R2169     -2.6032933592796326e-01
    z[7,8,2]  R2170     -4.4359427690505981e-01
    z[7,8,2]  R2171     -6.2107211351394653e-01
    z[7,8,2]  R2172     -3.7472090125083923e-01
    z[7,8,2]  R2173     -0.568618893623352
    z[7,8,2]  R2174     -1.7549788951873779e-01
    z[7,8,2]  R2175     -3.2367938756942749e-01
    z[7,8,2]  R2176     -5.3947108983993530e-01
    z[7,8,2]  R2177     -7.0862895250320435e-01
    z[7,8,2]  R2178     -0.0657036080956459
    z[7,8,2]  R2179     0.23386250436306
    z[7,8,2]  R2180     1.0245457291603088e-01
    z[7,8,2]  R2181     -2.5030821561813354e-01
    z[7,8,2]  R2182     -3.6769038438796997e-01
    z[7,8,2]  R2183     -1.3862235844135284e-01
    z[7,8,2]  R2184     -7.5600305572152138e-03
    z[7,8,2]  R2185     -1.4240401983261108e-01
    z[7,8,2]  R2186     -3.8570471107959747e-02
    z[7,8,2]  R2187     -3.9163712412118912e-02
    z[7,8,2]  R2188     1.0111314058303833e-01
    z[7,8,2]  R2189     -2.2710916399955750e-01
    z[7,8,2]  R2190     -2.7996638417243958e-01
    z[7,8,2]  R2191     5.8180510997772217e-02
    z[7,8,2]  R2192     -1.9354438781738281e-01
    z[7,8,2]  R2193     0.0391550213098526
    z[7,8,2]  R2194     -1.0665337741374969e-01
    z[7,8,2]  R2195     9.8015762865543365e-02
    z[7,8,2]  R2196     -1.9831072539091110e-02
    z[7,8,2]  R2197     -8.0827414989471436e-02
    z[7,8,2]  R2198     0.0355074517428875
    z[7,8,2]  R2199     3.8741311430931091e-01
    z[7,8,2]  R2200     -1.0585274547338486e-01
    z[7,8,2]  R2201     -3.9191875606775284e-02
    z[7,8,2]  R2202     3.4256509970873594e-03
    z[7,8,2]  R2203     2.8114444017410278e-01
    z[7,8,2]  R2204     -1.0289106518030167e-01
    z[7,8,2]  R2205     -1.0542208328843117e-02
    z[7,8,2]  R2206     -2.1782732009887695e-01
    z[7,8,2]  R2207     8.0047480762004852e-02
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2040     -1
    z[7,8,3]  R2041     1
    z[7,8,3]  R2048     3.6191475391387939e-01
    z[7,8,3]  R2049     2.7237620949745178e-01
    z[7,8,3]  R2050     6.7980909347534180e-01
    z[7,8,3]  R2051     7.3311723768711090e-02
    z[7,8,3]  R2052     0.42009437084198
    z[7,8,3]  R2053     2.3003891110420227e-01
    z[7,8,3]  R2054     3.1932342052459717e-01
    z[7,8,3]  R2055     3.5840702056884766e-01
    z[7,8,3]  R2056     5.6651169061660767e-01
    z[7,8,3]  R2057     2.8356346487998962e-01
    z[7,8,3]  R2058     -5.6767380237579346e-01
    z[7,8,3]  R2059     -3.6865150928497314e-01
    z[7,8,3]  R2060     -3.7740305066108704e-01
    z[7,8,3]  R2061     -5.0571990013122559e-01
    z[7,8,3]  R2062     -0.410660982131958
    z[7,8,3]  R2063     2.1263739466667175e-01
    z[7,8,3]  R2064     -5.3038388490676880e-01
    z[7,8,3]  R2065     -5.2300339937210083e-01
    z[7,8,3]  R2066     -2.2139649093151093e-01
    z[7,8,3]  R2067     -4.4104033708572388e-01
    z[7,8,3]  R2068     -3.6225321888923645e-01
    z[7,8,3]  R2069     1.0925932228565216e-01
    z[7,8,3]  R2070     -7.1278387308120728e-01
    z[7,8,3]  R2071     2.1688152849674225e-01
    z[7,8,3]  R2072     -6.9918829202651978e-01
    z[7,8,3]  R2073     2.2615356743335724e-01
    z[7,8,3]  R2074     -9.6766859292984009e-02
    z[7,8,3]  R2075     -1.0856787860393524e-01
    z[7,8,3]  R2076     -7.7130466699600220e-02
    z[7,8,3]  R2077     -2.0936983823776245e-01
    z[7,8,3]  R2078     5.5666558444499969e-02
    z[7,8,3]  R2079     -4.1393363475799561e-01
    z[7,8,3]  R2080     -7.4532374739646912e-02
    z[7,8,3]  R2081     -3.2952728867530823e-01
    z[7,8,3]  R2082     5.7273630052804947e-02
    z[7,8,3]  R2083     3.5371991991996765e-01
    z[7,8,3]  R2084     6.2036764621734619e-01
    z[7,8,3]  R2085     0.174591064453125
    z[7,8,3]  R2086     -6.5473616123199463e-02
    z[7,8,3]  R2087     9.8076008260250092e-02
    z[7,8,3]  R2088     0.54584139585495
    z[7,8,3]  R2089     -5.0053983926773071e-01
    z[7,8,3]  R2090     -6.7424766719341278e-02
    z[7,8,3]  R2091     -4.1990217566490173e-01
    z[7,8,3]  R2092     -4.7919595241546631e-01
    z[7,8,3]  R2093     -4.7395061701536179e-02
    z[7,8,3]  R2094     -7.9899743199348450e-02
    z[7,8,3]  R2095     3.8864096999168396e-01
    z[7,8,3]  R2096     0.112656369805336
    z[7,8,3]  R2097     -1.6416944563388824e-01
    z[7,8,3]  R2098     -1.8139523267745972e-01
    z[7,8,3]  R2099     -3.0042198300361633e-01
    z[7,8,3]  R2100     2.0458501577377319e-01
    z[7,8,3]  R2101     0.299461305141449
    z[7,8,3]  R2102     -3.0456364154815674e-01
    z[7,8,3]  R2103     6.3462370634078979e-01
    z[7,8,3]  R2104     -3.1808264553546906e-02
    z[7,8,3]  R2105     -6.1111348867416382e-01
    z[7,8,3]  R2106     -4.4662916660308838e-01
    z[7,8,3]  R2107     -7.2431737184524536e-01
    z[7,8,3]  R2108     -9.9267408251762390e-02
    z[7,8,3]  R2109     -2.1639212965965271e-01
    z[7,8,3]  R2110     4.5839720964431763e-01
    z[7,8,3]  R2111     -1.2969951145350933e-02
    z[7,8,3]  R2112     1.9489879906177521e-01
    z[7,8,3]  R2113     -0.739753782749176
    z[7,8,3]  R2114     4.2342305183410645e-01
    z[7,8,3]  R2115     -1.6215343773365021e-01
    z[7,8,3]  R2116     -6.8730795383453369e-01
    z[7,8,3]  R2117     -8.0857044458389282e-01
    z[7,8,3]  R2118     -4.8054140806198120e-01
    z[7,8,3]  R2119     6.1848795413970947e-01
    z[7,8,3]  R2120     -2.5894984602928162e-01
    z[7,8,3]  R2121     2.4202822148799896e-01
    z[7,8,3]  R2122     2.5243896525353193e-03
    z[7,8,3]  R2123     5.7796555757522583e-01
    z[7,8,3]  R2124     3.4566736221313477e-01
    z[7,8,3]  R2125     -7.0362383127212524e-01
    z[7,8,3]  R2126     -3.6247396469116211e-01
    z[7,8,3]  R2127     -0.738812267780304
    z[7,8,3]  R2128     -4.3917959928512573e-01
    z[7,8,3]  R2129     -6.6205725073814392e-02
    z[7,8,3]  R2130     2.7190076652914286e-03
    z[7,8,3]  R2131     4.7790881991386414e-01
    z[7,8,3]  R2132     6.6536128520965576e-01
    z[7,8,3]  R2133     2.6913082599639893e-01
    z[7,8,3]  R2134     8.1416743993759155e-01
    z[7,8,3]  R2135     7.6190240681171417e-02
    z[7,8,3]  R2136     7.1276850998401642e-02
    z[7,8,3]  R2137     -8.8126683235168457e-01
    z[7,8,3]  R2138     -2.3248299956321716e-01
    z[7,8,3]  R2139     -1.1482724547386169e-01
    z[7,8,3]  R2140     4.6430990099906921e-01
    z[7,8,3]  R2141     5.5468821525573730e-01
    z[7,8,3]  R2142     1.5193149447441101e-02
    z[7,8,3]  R2143     -3.2171458005905151e-02
    z[7,8,3]  R2144     5.1962349563837051e-02
    z[7,8,3]  R2145     -5.0766462087631226e-01
    z[7,8,3]  R2146     -7.0269167423248291e-01
    z[7,8,3]  R2147     3.8918992877006531e-01
    z[7,8,3]  R2148     -3.2630622386932373e-01
    z[7,8,3]  R2149     5.4890251159667969e-01
    z[7,8,3]  R2150     3.0041038990020752e-02
    z[7,8,3]  R2151     -7.0372693240642548e-02
    z[7,8,3]  R2152     -6.6674917936325073e-01
    z[7,8,3]  R2153     8.2571476697921753e-01
    z[7,8,3]  R2154     1.8634662032127380e-01
    z[7,8,3]  R2155     -5.4187369346618652e-01
    z[7,8,3]  R2156     -1.8501089513301849e-01
    z[7,8,3]  R2157     1.1763103306293488e-01
    z[7,8,3]  R2158     2.5739121437072754e-01
    z[7,8,3]  R2159     1.6530117392539978e-01
    z[7,8,3]  R2160     1.7963266372680664e-01
    z[7,8,3]  R2161     1.3234589993953705e-01
    z[7,8,3]  R2162     -4.1194036602973938e-02
    z[7,8,3]  R2163     1.3977135717868805e-01
    z[7,8,3]  R2164     -0.0847676619887352
    z[7,8,3]  R2165     3.2371747493743896e-01
    z[7,8,3]  R2166     1.3982596993446350e-01
    z[7,8,3]  R2167     4.7496250271797180e-01
    z[7,8,3]  R2168     7.1082182228565216e-02
    z[7,8,3]  R2169     5.2524650096893311e-01
    z[7,8,3]  R2170     4.5181828737258911e-01
    z[7,8,3]  R2171     3.5764062404632568e-01
    z[7,8,3]  R2172     2.4676126241683960e-01
    z[7,8,3]  R2173     1.6248725354671478e-01
    z[7,8,3]  R2174     3.5538071393966675e-01
    z[7,8,3]  R2175     4.9725881218910217e-01
    z[7,8,3]  R2176     1.0206269472837448e-01
    z[7,8,3]  R2177     2.6244139671325684e-01
    z[7,8,3]  R2178     7.6342053711414337e-02
    z[7,8,3]  R2179     -5.8134537935256958e-01
    z[7,8,3]  R2180     -2.5366422533988953e-01
    z[7,8,3]  R2181     -1.7145574092864990e-01
    z[7,8,3]  R2182     0.0885215699672699
    z[7,8,3]  R2183     1.3964995741844177e-01
    z[7,8,3]  R2184     -1.9695621728897095e-01
    z[7,8,3]  R2185     -6.9412998855113983e-02
    z[7,8,3]  R2186     -1.7963644862174988e-01
    z[7,8,3]  R2187     -1.2966012954711914e-01
    z[7,8,3]  R2188     6.1762750148773193e-01
    z[7,8,3]  R2189     -6.0979276895523071e-01
    z[7,8,3]  R2190     -7.1638122200965881e-02
    z[7,8,3]  R2191     -3.3242511749267578e-01
    z[7,8,3]  R2192     -5.5677896738052368e-01
    z[7,8,3]  R2193     -3.1964725255966187e-01
    z[7,8,3]  R2194     -0.56904536485672
    z[7,8,3]  R2195     -4.8577833175659180e-01
    z[7,8,3]  R2196     -4.5397144556045532e-01
    z[7,8,3]  R2197     -6.0044860839843750e-01
    z[7,8,3]  R2198     4.0795540809631348e-01
    z[7,8,3]  R2199     1.8678598105907440e-01
    z[7,8,3]  R2200     1.8172113597393036e-01
    z[7,8,3]  R2201     -0.290932834148407
    z[7,8,3]  R2202     6.5892942249774933e-02
    z[7,8,3]  R2203     -2.2303043305873871e-01
    z[7,8,3]  R2204     -6.0945552587509155e-01
    z[7,8,3]  R2205     -2.3416090011596680e-01
    z[7,8,3]  R2206     -1.4389619231224060e-01
    z[7,8,3]  R2207     -1.4314334094524384e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2042     -1
    z[7,8,4]  R2043     1
    z[7,8,4]  R2048     1.6483603417873383e-01
    z[7,8,4]  R2049     -2.0548866689205170e-01
    z[7,8,4]  R2050     -1.2014985829591751e-01
    z[7,8,4]  R2051     2.9497590661048889e-01
    z[7,8,4]  R2052     1.4236049354076385e-01
    z[7,8,4]  R2053     2.5435414910316467e-01
    z[7,8,4]  R2054     1.6347086429595947e-01
    z[7,8,4]  R2055     -4.1072311997413635e-01
    z[7,8,4]  R2056     -2.4284815788269043e-01
    z[7,8,4]  R2057     -1.8633264303207397e-01
    z[7,8,4]  R2058     3.5102775692939758e-01
    z[7,8,4]  R2059     -4.9579218029975891e-01
    z[7,8,4]  R2060     -0.420878142118454
    z[7,8,4]  R2061     -1.1079634726047516e-01
    z[7,8,4]  R2062     -4.8875716328620911e-01
    z[7,8,4]  R2063     -3.1739141792058945e-02
    z[7,8,4]  R2064     -1.8995173275470734e-01
    z[7,8,4]  R2065     8.6141005158424377e-03
    z[7,8,4]  R2066     -2.5475943088531494e-01
    z[7,8,4]  R2067     -4.2808291316032410e-01
    z[7,8,4]  R2068     -1.7352880537509918e-01
    z[7,8,4]  R2069     2.0763443410396576e-01
    z[7,8,4]  R2070     -1.5970483422279358e-01
    z[7,8,4]  R2071     -0.164675772190094
    z[7,8,4]  R2072     6.9020465016365051e-02
    z[7,8,4]  R2073     3.3810202032327652e-02
    z[7,8,4]  R2074     2.0591814070940018e-02
    z[7,8,4]  R2075     1.2437465041875839e-01
    z[7,8,4]  R2076     2.7689921855926514e-01
    z[7,8,4]  R2077     1.0139914602041245e-01
    z[7,8,4]  R2078     -7.4027101509273052e-03
    z[7,8,4]  R2079     -9.2984713613986969e-02
    z[7,8,4]  R2080     5.7830739021301270e-01
    z[7,8,4]  R2081     5.7642382383346558e-01
    z[7,8,4]  R2082     9.1092668473720551e-02
    z[7,8,4]  R2083     -2.9985904693603516e-01
    z[7,8,4]  R2084     -3.4815132617950439e-01
    z[7,8,4]  R2085     -5.8498740196228027e-02
    z[7,8,4]  R2086     2.5201949477195740e-01
    z[7,8,4]  R2087     1.6721126437187195e-01
    z[7,8,4]  R2088     1.5844435989856720e-01
    z[7,8,4]  R2089     3.3917296677827835e-03
    z[7,8,4]  R2090     -1.0530129820108414e-01
    z[7,8,4]  R2091     -3.4999931231141090e-03
    z[7,8,4]  R2092     1.9685381650924683e-01
    z[7,8,4]  R2093     4.1764539480209351e-01
    z[7,8,4]  R2094     1.4651700854301453e-01
    z[7,8,4]  R2095     4.3963202834129333e-01
    z[7,8,4]  R2096     3.0410623550415039e-01
    z[7,8,4]  R2097     1.7601549625396729e-01
    z[7,8,4]  R2098     -1.3534653186798096e-01
    z[7,8,4]  R2099     4.7975964844226837e-02
    z[7,8,4]  R2100     1.0215112566947937e-01
    z[7,8,4]  R2101     -0.0791703388094902
    z[7,8,4]  R2102     -1.5117718279361725e-01
    z[7,8,4]  R2103     -0.000655064475722611
    z[7,8,4]  R2104     -1.3639484345912933e-01
    z[7,8,4]  R2105     -1.7070990800857544e-01
    z[7,8,4]  R2106     -4.9967950582504272e-01
    z[7,8,4]  R2107     -1.6937865316867828e-01
    z[7,8,4]  R2108     5.0345176458358765e-01
    z[7,8,4]  R2109     -1.9321238994598389e-01
    z[7,8,4]  R2110     -0.510749340057373
    z[7,8,4]  R2111     -1.7659065127372742e-01
    z[7,8,4]  R2112     -3.2749277353286743e-01
    z[7,8,4]  R2113     -1.6959272325038910e-01
    z[7,8,4]  R2114     -2.5101867318153381e-01
    z[7,8,4]  R2115     -3.8920632004737854e-01
    z[7,8,4]  R2116     -3.8718926906585693e-01
    z[7,8,4]  R2117     -1.7540577054023743e-01
    z[7,8,4]  R2118     2.6764786243438721e-01
    z[7,8,4]  R2119     2.7633774280548096e-01
    z[7,8,4]  R2120     2.6715666055679321e-01
    z[7,8,4]  R2121     1.8802155554294586e-01
    z[7,8,4]  R2122     -1.0254956036806107e-01
    z[7,8,4]  R2123     2.7900439500808716e-01
    z[7,8,4]  R2124     1.4084173738956451e-01
    z[7,8,4]  R2125     -3.8704228401184082e-01
    z[7,8,4]  R2126     7.1601629257202148e-02
    z[7,8,4]  R2127     1.6826494038105011e-01
    z[7,8,4]  R2128     6.9450519979000092e-02
    z[7,8,4]  R2129     5.5063869804143906e-02
    z[7,8,4]  R2130     1.9221821799874306e-02
    z[7,8,4]  R2131     0.0171035286039114
    z[7,8,4]  R2132     2.2876986861228943e-01
    z[7,8,4]  R2133     -2.5459113717079163e-01
    z[7,8,4]  R2134     7.4961505830287933e-02
    z[7,8,4]  R2135     -1.6473822295665741e-01
    z[7,8,4]  R2136     -3.0694943666458130e-01
    z[7,8,4]  R2137     -2.2959465160965919e-02
    z[7,8,4]  R2138     9.0642586350440979e-02
    z[7,8,4]  R2139     4.7416013479232788e-01
    z[7,8,4]  R2140     1.4224231243133545e-01
    z[7,8,4]  R2141     -3.5413238406181335e-01
    z[7,8,4]  R2142     8.0844148993492126e-02
    z[7,8,4]  R2143     2.1051813662052155e-01
    z[7,8,4]  R2144     -1.5900759398937225e-01
    z[7,8,4]  R2145     -2.7241092175245285e-02
    z[7,8,4]  R2146     1.8105036020278931e-01
    z[7,8,4]  R2147     6.2217503786087036e-01
    z[7,8,4]  R2148     3.6257752776145935e-01
    z[7,8,4]  R2149     -1.5457384288311005e-01
    z[7,8,4]  R2150     1.6399468481540680e-01
    z[7,8,4]  R2151     7.4029639363288879e-02
    z[7,8,4]  R2152     3.4444069024175406e-03
    z[7,8,4]  R2153     2.1715784445405006e-02
    z[7,8,4]  R2154     -1.1888762563467026e-01
    z[7,8,4]  R2155     -1.4770109951496124e-01
    z[7,8,4]  R2156     -2.0655460655689240e-01
    z[7,8,4]  R2157     1.4602577686309814e-01
    z[7,8,4]  R2158     -1.6608202457427979e-01
    z[7,8,4]  R2159     1.4930222928524017e-01
    z[7,8,4]  R2160     1.0916792601346970e-01
    z[7,8,4]  R2161     1.6858358681201935e-01
    z[7,8,4]  R2162     1.7198072746396065e-02
    z[7,8,4]  R2163     -3.4115172922611237e-02
    z[7,8,4]  R2164     -1.9708819687366486e-02
    z[7,8,4]  R2165     1.2298287451267242e-01
    z[7,8,4]  R2166     -0.27997025847435
    z[7,8,4]  R2167     -1.6390171647071838e-01
    z[7,8,4]  R2168     -1.8132030963897705e-01
    z[7,8,4]  R2169     1.9520732760429382e-01
    z[7,8,4]  R2170     -1.9591921567916870e-01
    z[7,8,4]  R2171     -3.0801620334386826e-02
    z[7,8,4]  R2172     -6.9214117527008057e-01
    z[7,8,4]  R2173     -2.2359889745712280e-01
    z[7,8,4]  R2174     2.5557526946067810e-01
    z[7,8,4]  R2175     -2.2692269086837769e-01
    z[7,8,4]  R2176     3.4116649627685547e-01
    z[7,8,4]  R2177     2.1558435261249542e-01
    z[7,8,4]  R2178     9.2774204909801483e-02
    z[7,8,4]  R2179     -8.5824113339185715e-03
    z[7,8,4]  R2180     8.9389160275459290e-02
    z[7,8,4]  R2181     1.5136560425162315e-02
    z[7,8,4]  R2182     7.6929312199354172e-03
    z[7,8,4]  R2183     -0.0321052223443985
    z[7,8,4]  R2184     -7.9387754201889038e-02
    z[7,8,4]  R2185     -1.2461936473846436e-01
    z[7,8,4]  R2186     -1.1244063824415207e-01
    z[7,8,4]  R2187     7.1235232055187225e-02
    z[7,8,4]  R2188     3.2721456140279770e-02
    z[7,8,4]  R2189     2.3946096003055573e-01
    z[7,8,4]  R2190     3.6254864931106567e-01
    z[7,8,4]  R2191     -3.1196763738989830e-02
    z[7,8,4]  R2192     4.7189682722091675e-02
    z[7,8,4]  R2193     -4.9045007675886154e-02
    z[7,8,4]  R2194     2.2894616425037384e-01
    z[7,8,4]  R2195     2.1908958256244659e-01
    z[7,8,4]  R2196     1.0117696970701218e-01
    z[7,8,4]  R2197     3.4478890895843506e-01
    z[7,8,4]  R2198     5.3812485933303833e-01
    z[7,8,4]  R2199     2.0495966076850891e-01
    z[7,8,4]  R2200     -1.7710077762603760e-01
    z[7,8,4]  R2201     4.3691709637641907e-01
    z[7,8,4]  R2202     -9.8659023642539978e-03
    z[7,8,4]  R2203     6.8453907966613770e-02
    z[7,8,4]  R2204     1.5254114568233490e-01
    z[7,8,4]  R2205     -3.0586105585098267e-01
    z[7,8,4]  R2206     -2.0717906951904297e-01
    z[7,8,4]  R2207     -8.4953360259532928e-02
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2044     -1
    z[7,8,5]  R2045     1
    z[7,8,5]  R2048     3.6157190799713135e-01
    z[7,8,5]  R2049     8.6428232491016388e-02
    z[7,8,5]  R2050     1.7475946247577667e-01
    z[7,8,5]  R2051     2.1422280371189117e-01
    z[7,8,5]  R2052     -2.6312029361724854e-01
    z[7,8,5]  R2053     -1.1258765310049057e-01
    z[7,8,5]  R2054     -6.9279879331588745e-02
    z[7,8,5]  R2055     2.6745384931564331e-01
    z[7,8,5]  R2056     -2.8706169128417969e-01
    z[7,8,5]  R2057     -2.1840818226337433e-01
    z[7,8,5]  R2058     -1.7786248028278351e-01
    z[7,8,5]  R2059     -2.1726746112108231e-02
    z[7,8,5]  R2060     -6.3736066222190857e-02
    z[7,8,5]  R2061     3.1286545097827911e-02
    z[7,8,5]  R2062     7.8133922070264816e-03
    z[7,8,5]  R2063     1.1068589985370636e-01
    z[7,8,5]  R2064     2.6434719562530518e-01
    z[7,8,5]  R2065     0.0418284609913826
    z[7,8,5]  R2066     1.6630619764328003e-01
    z[7,8,5]  R2067     2.8218093514442444e-01
    z[7,8,5]  R2068     -0.478199303150177
    z[7,8,5]  R2069     -1.9420586526393890e-01
    z[7,8,5]  R2070     -7.1430094540119171e-02
    z[7,8,5]  R2071     -0.292460560798645
    z[7,8,5]  R2072     2.2123925387859344e-01
    z[7,8,5]  R2073     -4.1238903999328613e-01
    z[7,8,5]  R2074     -3.6590325832366943e-01
    z[7,8,5]  R2075     -3.0864715576171875e-01
    z[7,8,5]  R2076     -3.1340357661247253e-01
    z[7,8,5]  R2077     1.8844987452030182e-01
    z[7,8,5]  R2078     -3.8047227263450623e-01
    z[7,8,5]  R2079     -2.8123003244400024e-01
    z[7,8,5]  R2080     -3.0721798539161682e-01
    z[7,8,5]  R2081     -3.0520227551460266e-01
    z[7,8,5]  R2082     -2.6596600189805031e-02
    z[7,8,5]  R2083     -2.2794160246849060e-01
    z[7,8,5]  R2084     -2.9888552427291870e-01
    z[7,8,5]  R2085     2.7011623978614807e-01
    z[7,8,5]  R2086     -1.4479759335517883e-01
    z[7,8,5]  R2087     -3.0097526311874390e-01
    z[7,8,5]  R2088     1.1131688207387924e-01
    z[7,8,5]  R2089     -3.7510967254638672e-01
    z[7,8,5]  R2090     -1.9735524058341980e-01
    z[7,8,5]  R2091     -1.3828532397747040e-01
    z[7,8,5]  R2092     -3.4852313995361328e-01
    z[7,8,5]  R2093     -2.5787869095802307e-01
    z[7,8,5]  R2094     -1.0327735543251038e-01
    z[7,8,5]  R2095     1.2150023831054568e-03
    z[7,8,5]  R2096     -2.3134063184261322e-01
    z[7,8,5]  R2097     4.0065199136734009e-02
    z[7,8,5]  R2098     -5.5110651254653931e-01
    z[7,8,5]  R2099     4.4556212425231934e-01
    z[7,8,5]  R2100     2.4070987105369568e-01
    z[7,8,5]  R2101     -1.0796731710433960e-01
    z[7,8,5]  R2102     2.1233783662319183e-01
    z[7,8,5]  R2103     -1.3205768167972565e-01
    z[7,8,5]  R2104     -2.4533860385417938e-01
    z[7,8,5]  R2105     -3.0848110094666481e-02
    z[7,8,5]  R2106     -1.4587184786796570e-01
    z[7,8,5]  R2107     0.252546489238739
    z[7,8,5]  R2108     -3.6108851432800293e-01
    z[7,8,5]  R2109     1.9542382657527924e-01
    z[7,8,5]  R2110     -2.3221735656261444e-01
    z[7,8,5]  R2111     -3.7104284763336182e-01
    z[7,8,5]  R2112     -4.8415485769510269e-02
    z[7,8,5]  R2113     2.5979939103126526e-01
    z[7,8,5]  R2114     -1.2629453837871552e-01
    z[7,8,5]  R2115     -4.3472938239574432e-02
    z[7,8,5]  R2116     -3.7419281434267759e-03
    z[7,8,5]  R2117     9.2434667050838470e-02
    z[7,8,5]  R2118     -4.2871972918510437e-01
    z[7,8,5]  R2119     -3.3051091432571411e-01
    z[7,8,5]  R2120     3.0744457244873047e-01
    z[7,8,5]  R2121     -1.1734230071306229e-01
    z[7,8,5]  R2122     -6.0735039412975311e-02
    z[7,8,5]  R2123     -4.1593369841575623e-01
    z[7,8,5]  R2124     1.5159327536821365e-02
    z[7,8,5]  R2125     2.9559774324297905e-02
    z[7,8,5]  R2126     -4.1807761788368225e-01
    z[7,8,5]  R2127     5.3183263540267944e-01
    z[7,8,5]  R2128     5.0590906292200089e-02
    z[7,8,5]  R2129     4.6976704150438309e-02
    z[7,8,5]  R2130     -4.1004788875579834e-01
    z[7,8,5]  R2131     -8.0488964915275574e-02
    z[7,8,5]  R2132     -1.3850995898246765e-01
    z[7,8,5]  R2133     1.7445281147956848e-01
    z[7,8,5]  R2134     -3.7980481982231140e-01
    z[7,8,5]  R2135     -0.549176037311554
    z[7,8,5]  R2136     -3.1081077456474304e-01
    z[7,8,5]  R2137     2.7003228664398193e-01
    z[7,8,5]  R2138     -1.6107386350631714e-01
    z[7,8,5]  R2139     -5.5078428983688354e-01
    z[7,8,5]  R2140     -3.1608107686042786e-01
    z[7,8,5]  R2141     -1.7238157987594604e-01
    z[7,8,5]  R2142     -1.0442781448364258e-01
    z[7,8,5]  R2143     2.9218757152557373e-01
    z[7,8,5]  R2144     -4.2967864871025085e-01
    z[7,8,5]  R2145     -1.0896987468004227e-01
    z[7,8,5]  R2146     1.6916318237781525e-01
    z[7,8,5]  R2147     0.0191938616335392
    z[7,8,5]  R2148     8.2310363650321960e-02
    z[7,8,5]  R2149     -2.0744070410728455e-01
    z[7,8,5]  R2150     -1.1092843860387802e-01
    z[7,8,5]  R2151     -1.8518300354480743e-01
    z[7,8,5]  R2152     2.7184817939996719e-02
    z[7,8,5]  R2153     -3.5375106334686279e-01
    z[7,8,5]  R2154     -3.9943951368331909e-01
    z[7,8,5]  R2155     4.8046806454658508e-01
    z[7,8,5]  R2156     -2.3944278061389923e-01
    z[7,8,5]  R2157     -7.0862270891666412e-02
    z[7,8,5]  R2158     3.7518101930618286e-01
    z[7,8,5]  R2159     -6.0493446653708816e-04
    z[7,8,5]  R2160     2.2294235229492188e-01
    z[7,8,5]  R2161     2.8060016036033630e-01
    z[7,8,5]  R2162     2.0822128653526306e-01
    z[7,8,5]  R2163     2.6795136928558350e-01
    z[7,8,5]  R2164     2.4268044531345367e-01
    z[7,8,5]  R2165     -1.2292737513780594e-01
    z[7,8,5]  R2166     0.171631321310997
    z[7,8,5]  R2167     -1.7719285190105438e-01
    z[7,8,5]  R2168     -4.6486237645149231e-01
    z[7,8,5]  R2169     -2.3795351386070251e-01
    z[7,8,5]  R2170     1.5455009043216705e-01
    z[7,8,5]  R2171     -5.0613671541213989e-01
    z[7,8,5]  R2172     2.0881672203540802e-01
    z[7,8,5]  R2173     -3.0684599280357361e-01
    z[7,8,5]  R2174     -6.2262868881225586e-01
    z[7,8,5]  R2175     2.8113192319869995e-01
    z[7,8,5]  R2176     1.2872710824012756e-01
    z[7,8,5]  R2177     -1.3126474618911743e-01
    z[7,8,5]  R2178     5.3936883807182312e-02
    z[7,8,5]  R2179     -2.0388758182525635e-01
    z[7,8,5]  R2180     -2.4250808358192444e-01
    z[7,8,5]  R2181     -1.6675812005996704e-01
    z[7,8,5]  R2182     -1.8792568147182465e-01
    z[7,8,5]  R2183     2.3786008358001709e-01
    z[7,8,5]  R2184     1.3416735827922821e-01
    z[7,8,5]  R2185     2.9073727130889893e-01
    z[7,8,5]  R2186     -7.5451299548149109e-02
    z[7,8,5]  R2187     -1.6008451581001282e-01
    z[7,8,5]  R2188     2.8374210000038147e-01
    z[7,8,5]  R2189     -9.4341598451137543e-02
    z[7,8,5]  R2190     -3.8035833835601807e-01
    z[7,8,5]  R2191     4.5989226549863815e-02
    z[7,8,5]  R2192     1.1464400589466095e-01
    z[7,8,5]  R2193     -1.8688382208347321e-01
    z[7,8,5]  R2194     -1.3190971314907074e-01
    z[7,8,5]  R2195     -3.4474423527717590e-01
    z[7,8,5]  R2196     -5.5179882049560547e-01
    z[7,8,5]  R2197     -4.4205829501152039e-01
    z[7,8,5]  R2198     4.1795790195465088e-01
    z[7,8,5]  R2199     5.2266085147857666e-01
    z[7,8,5]  R2200     -3.5278671421110630e-03
    z[7,8,5]  R2201     -1.4266875386238098e-01
    z[7,8,5]  R2202     -4.2489495873451233e-01
    z[7,8,5]  R2203     -1.4343149960041046e-01
    z[7,8,5]  R2204     -2.5397273898124695e-01
    z[7,8,5]  R2205     -1.2654094398021698e-01
    z[7,8,5]  R2206     -1.2960636615753174e-01
    z[7,8,5]  R2207     2.9142990708351135e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2046     -1
    z[7,8,6]  R2047     1
    z[7,8,6]  R2048     -2.0635235309600830e-01
    z[7,8,6]  R2049     2.2748260200023651e-01
    z[7,8,6]  R2050     1.0516013205051422e-01
    z[7,8,6]  R2051     -3.9368532598018646e-02
    z[7,8,6]  R2052     -3.6459761857986450e-01
    z[7,8,6]  R2053     -2.8335893154144287e-01
    z[7,8,6]  R2054     -5.0444173812866211e-01
    z[7,8,6]  R2055     -1.5931384265422821e-01
    z[7,8,6]  R2056     -5.7740285992622375e-03
    z[7,8,6]  R2057     -2.2962391376495361e-01
    z[7,8,6]  R2058     -1.3790573179721832e-01
    z[7,8,6]  R2059     -1.6364523768424988e-01
    z[7,8,6]  R2060     -8.3632849156856537e-02
    z[7,8,6]  R2061     6.0002632439136505e-02
    z[7,8,6]  R2062     1.8504603207111359e-01
    z[7,8,6]  R2063     -2.1147492527961731e-01
    z[7,8,6]  R2064     1.3096566312015057e-02
    z[7,8,6]  R2065     -2.7766495943069458e-01
    z[7,8,6]  R2066     -8.0890739336609840e-03
    z[7,8,6]  R2067     2.4081563949584961e-01
    z[7,8,6]  R2068     1.4388850331306458e-01
    z[7,8,6]  R2069     5.9924638271331787e-01
    z[7,8,6]  R2070     4.3836173415184021e-01
    z[7,8,6]  R2071     4.5063480734825134e-01
    z[7,8,6]  R2072     1.4219434559345245e-01
    z[7,8,6]  R2073     4.7252067923545837e-01
    z[7,8,6]  R2074     -4.1448645293712616e-02
    z[7,8,6]  R2075     1.7293691635131836e-01
    z[7,8,6]  R2076     2.1829646080732346e-02
    z[7,8,6]  R2077     3.9265986531972885e-02
    z[7,8,6]  R2078     7.6660722494125366e-02
    z[7,8,6]  R2079     -5.6128031015396118e-01
    z[7,8,6]  R2080     4.9747237563133240e-01
    z[7,8,6]  R2081     -4.6390643715858459e-01
    z[7,8,6]  R2082     4.7608932852745056e-01
    z[7,8,6]  R2083     -6.2533393502235413e-02
    z[7,8,6]  R2084     2.1993571519851685e-01
    z[7,8,6]  R2085     3.4372383356094360e-01
    z[7,8,6]  R2086     3.4728819131851196e-01
    z[7,8,6]  R2087     0.255688339471817
    z[7,8,6]  R2088     4.2310228943824768e-01
    z[7,8,6]  R2089     6.8588759750127792e-03
    z[7,8,6]  R2090     2.3477682471275330e-01
    z[7,8,6]  R2091     -4.1881051659584045e-01
    z[7,8,6]  R2092     3.9004996418952942e-01
    z[7,8,6]  R2093     -0.335882306098938
    z[7,8,6]  R2094     -1.6593678295612335e-01
    z[7,8,6]  R2095     2.6671022176742554e-01
    z[7,8,6]  R2096     6.2468592077493668e-03
    z[7,8,6]  R2097     -8.7136939167976379e-02
    z[7,8,6]  R2098     -2.9209271073341370e-01
    z[7,8,6]  R2099     0.44937664270401
    z[7,8,6]  R2100     -9.9995970726013184e-02
    z[7,8,6]  R2101     1.3004487752914429e-01
    z[7,8,6]  R2102     -4.5862618088722229e-01
    z[7,8,6]  R2103     -5.1394551992416382e-01
    z[7,8,6]  R2104     -2.0621180534362793e-01
    z[7,8,6]  R2105     2.0252232253551483e-01
    z[7,8,6]  R2106     -1.0687220841646194e-01
    z[7,8,6]  R2107     -6.3475079834461212e-02
    z[7,8,6]  R2108     -1.4392933249473572e-01
    z[7,8,6]  R2109     3.9627268910408020e-01
    z[7,8,6]  R2110     -1.1192449927330017e-01
    z[7,8,6]  R2111     -1.2898662686347961e-01
    z[7,8,6]  R2112     4.8706603050231934e-01
    z[7,8,6]  R2113     1.6122156381607056e-01
    z[7,8,6]  R2114     -0.574490487575531
    z[7,8,6]  R2115     2.2059172391891479e-02
    z[7,8,6]  R2116     2.1027492359280586e-02
    z[7,8,6]  R2117     -9.4802536070346832e-02
    z[7,8,6]  R2118     -2.5701060891151428e-02
    z[7,8,6]  R2119     -1.7384913563728333e-01
    z[7,8,6]  R2120     0.0712905079126358
    z[7,8,6]  R2121     -2.4445161223411560e-01
    z[7,8,6]  R2122     -4.6912181377410889e-01
    z[7,8,6]  R2123     -2.4328069388866425e-01
    z[7,8,6]  R2124     3.8897043466567993e-01
    z[7,8,6]  R2125     -3.2586455345153809e-01
    z[7,8,6]  R2126     1.1651214212179184e-02
    z[7,8,6]  R2127     1.5964837744832039e-02
    z[7,8,6]  R2128     7.3880054056644440e-02
    z[7,8,6]  R2129     -3.6409109830856323e-02
    z[7,8,6]  R2130     1.9887593388557434e-01
    z[7,8,6]  R2131     2.9521992802619934e-01
    z[7,8,6]  R2132     5.9096522629261017e-02
    z[7,8,6]  R2133     4.5569464564323425e-01
    z[7,8,6]  R2134     -1.0193645209074020e-01
    z[7,8,6]  R2135     -2.6325622200965881e-01
    z[7,8,6]  R2136     5.2250474691390991e-02
    z[7,8,6]  R2137     6.4070552587509155e-02
    z[7,8,6]  R2138     -2.2096963226795197e-01
    z[7,8,6]  R2139     -1.0697133839130402e-01
    z[7,8,6]  R2140     6.6424749791622162e-02
    z[7,8,6]  R2141     -2.0087711513042450e-02
    z[7,8,6]  R2142     2.4833540618419647e-01
    z[7,8,6]  R2143     8.2687549293041229e-02
    z[7,8,6]  R2144     -3.9547204971313477e-01
    z[7,8,6]  R2145     -2.3731590807437897e-01
    z[7,8,6]  R2146     -3.3022749423980713e-01
    z[7,8,6]  R2147     -0.458345502614975
    z[7,8,6]  R2148     4.8635181784629822e-01
    z[7,8,6]  R2149     -2.1411462128162384e-01
    z[7,8,6]  R2150     1.3943125307559967e-01
    z[7,8,6]  R2151     3.0752828717231750e-01
    z[7,8,6]  R2152     1.5022693574428558e-01
    z[7,8,6]  R2153     -6.2335506081581116e-02
    z[7,8,6]  R2154     2.1135514974594116e-01
    z[7,8,6]  R2155     -0.360663503408432
    z[7,8,6]  R2156     6.0167215764522552e-02
    z[7,8,6]  R2157     2.0817078649997711e-02
    z[7,8,6]  R2158     -9.4628900289535522e-02
    z[7,8,6]  R2159     -8.2821592688560486e-02
    z[7,8,6]  R2160     -3.6194634437561035e-01
    z[7,8,6]  R2161     -1.9311843439936638e-02
    z[7,8,6]  R2162     -2.0924621820449829e-01
    z[7,8,6]  R2163     8.3675451576709747e-02
    z[7,8,6]  R2164     -1.1608625948429108e-01
    z[7,8,6]  R2165     1.6750479117035866e-02
    z[7,8,6]  R2166     -3.5390508174896240e-01
    z[7,8,6]  R2167     2.8072218410670757e-03
    z[7,8,6]  R2168     0.0628654882311821
    z[7,8,6]  R2169     -4.6374088525772095e-01
    z[7,8,6]  R2170     -2.2481869161128998e-01
    z[7,8,6]  R2171     -1.9075348973274231e-01
    z[7,8,6]  R2172     -9.0090613812208176e-03
    z[7,8,6]  R2173     1.7228309810161591e-01
    z[7,8,6]  R2174     3.2534804940223694e-01
    z[7,8,6]  R2175     4.2964923381805420e-01
    z[7,8,6]  R2176     2.0622503757476807e-01
    z[7,8,6]  R2177     4.6970045566558838e-01
    z[7,8,6]  R2178     0.0920991376042366
    z[7,8,6]  R2179     3.9331771433353424e-02
    z[7,8,6]  R2180     1.0742158442735672e-01
    z[7,8,6]  R2181     1.1864091455936432e-01
    z[7,8,6]  R2182     1.3005739450454712e-01
    z[7,8,6]  R2183     -7.7928858809173107e-03
    z[7,8,6]  R2184     -3.4613016992807388e-02
    z[7,8,6]  R2185     2.5950780138373375e-02
    z[7,8,6]  R2186     3.1248387694358826e-01
    z[7,8,6]  R2187     3.6323550343513489e-01
    z[7,8,6]  R2188     2.7429863810539246e-01
    z[7,8,6]  R2189     -1.4621193706989288e-01
    z[7,8,6]  R2190     -1.0429130494594574e-01
    z[7,8,6]  R2191     -2.7589586377143860e-01
    z[7,8,6]  R2192     -2.4740052223205566e-01
    z[7,8,6]  R2193     -3.1327673792839050e-01
    z[7,8,6]  R2194     -3.3595946431159973e-01
    z[7,8,6]  R2195     -2.8496238589286804e-01
    z[7,8,6]  R2196     -3.0465468764305115e-01
    z[7,8,6]  R2197     -1.9501791894435883e-01
    z[7,8,6]  R2198     5.0175851583480835e-01
    z[7,8,6]  R2199     8.3230612799525261e-03
    z[7,8,6]  R2200     2.8687119483947754e-01
    z[7,8,6]  R2201     7.6511144638061523e-02
    z[7,8,6]  R2202     -1.5091150999069214e-01
    z[7,8,6]  R2203     -2.0095384120941162e-01
    z[7,8,6]  R2204     -2.7648857235908508e-01
    z[7,8,6]  R2205     -3.3896368741989136e-01
    z[7,8,6]  R2206     -2.6503643393516541e-01
    z[7,8,6]  R2207     -1.2459450960159302e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2208     -1
    z[8,7,0]  R2209     1
    z[8,7,0]  R2222     7.0530152320861816e-01
    z[8,7,0]  R2223     8.8695132732391357e-01
    z[8,7,0]  R2224     7.5331693887710571e-01
    z[8,7,0]  R2225     9.0934127569198608e-01
    z[8,7,0]  R2226     8.2864642143249512e-01
    z[8,7,0]  R2227     9.4234520196914673e-01
    z[8,7,0]  R2228     9.3040871620178223e-01
    z[8,7,0]  R2229     0.736838161945343
    z[8,7,0]  R2230     8.6052078008651733e-01
    z[8,7,0]  R2231     0.713066577911377
    z[8,7,0]  R2232     1.3651348650455475e-01
    z[8,7,0]  R2233     -3.2548218965530396e-02
    z[8,7,0]  R2234     -4.8324260115623474e-01
    z[8,7,0]  R2235     4.2534127831459045e-02
    z[8,7,0]  R2236     -2.1742577850818634e-01
    z[8,7,0]  R2237     -5.1593035459518433e-01
    z[8,7,0]  R2238     -3.0395722389221191e-01
    z[8,7,0]  R2239     -7.2562158107757568e-02
    z[8,7,0]  R2240     -5.1913022994995117e-01
    z[8,7,0]  R2241     -1.5697129070758820e-01
    z[8,7,0]  R2242     -3.2283249497413635e-01
    z[8,7,0]  R2243     -0.721881091594696
    z[8,7,0]  R2244     -2.3561200499534607e-01
    z[8,7,0]  R2245     -2.9592856764793396e-01
    z[8,7,0]  R2246     -2.5959175825119019e-01
    z[8,7,0]  R2247     -2.2420540452003479e-01
    z[8,7,0]  R2248     -4.0958243608474731e-01
    z[8,7,0]  R2249     -0.331001877784729
    z[8,7,0]  R2250     -2.5792077183723450e-01
    z[8,7,0]  R2251     -1.9591730833053589e-01
    z[8,7,0]  R2252     -2.6988866925239563e-01
    z[8,7,0]  R2253     -6.8003219366073608e-01
    z[8,7,0]  R2254     -6.5597808361053467e-01
    z[8,7,0]  R2255     -8.8376182317733765e-01
    z[8,7,0]  R2256     -0.755744218826294
    z[8,7,0]  R2257     -8.1956106424331665e-01
    z[8,7,0]  R2258     -6.7751920223236084e-01
    z[8,7,0]  R2259     -6.9661718606948853e-01
    z[8,7,0]  R2260     -5.9385901689529419e-01
    z[8,7,0]  R2261     -5.2864837646484375e-01
    z[8,7,0]  R2262     7.0176303386688232e-02
    z[8,7,0]  R2263     -0.313693106174469
    z[8,7,0]  R2264     -4.1877318173646927e-02
    z[8,7,0]  R2265     -8.0878752470016479e-01
    z[8,7,0]  R2266     -1.6961207985877991e-01
    z[8,7,0]  R2267     -8.6870723962783813e-01
    z[8,7,0]  R2268     -6.7262911796569824e-01
    z[8,7,0]  R2269     -8.4285312891006470e-01
    z[8,7,0]  R2270     -2.3766933381557465e-01
    z[8,7,0]  R2271     -9.1773825883865356e-01
    z[8,7,0]  R2272     0.77576744556427
    z[8,7,0]  R2273     8.8025522232055664e-01
    z[8,7,0]  R2274     6.4333146810531616e-01
    z[8,7,0]  R2275     8.7296146154403687e-01
    z[8,7,0]  R2276     6.7654889822006226e-01
    z[8,7,0]  R2277     7.7571070194244385e-01
    z[8,7,0]  R2278     7.1319955587387085e-01
    z[8,7,0]  R2279     7.6416790485382080e-01
    z[8,7,0]  R2280     0.66385817527771
    z[8,7,0]  R2281     7.3412883281707764e-01
    z[8,7,0]  R2282     -0.0723298192024231
    z[8,7,0]  R2283     -3.6823704838752747e-01
    z[8,7,0]  R2284     -1.8581800162792206e-01
    z[8,7,0]  R2285     -2.1017327904701233e-01
    z[8,7,0]  R2286     -4.3952235579490662e-01
    z[8,7,0]  R2287     -0.404788076877594
    z[8,7,0]  R2288     6.5057352185249329e-02
    z[8,7,0]  R2289     -3.6465483903884888e-01
    z[8,7,0]  R2290     -7.1978025138378143e-02
    z[8,7,0]  R2291     -1.6103573143482208e-02
    z[8,7,0]  R2292     1.5172088146209717e-01
    z[8,7,0]  R2293     8.2185946404933929e-02
    z[8,7,0]  R2294     2.3939360678195953e-01
    z[8,7,0]  R2295     0.133229598402977
    z[8,7,0]  R2296     3.4232255816459656e-01
    z[8,7,0]  R2297     2.4072253704071045e-01
    z[8,7,0]  R2298     -0.907288670539856
    z[8,7,0]  R2299     -9.0061253309249878e-01
    z[8,7,0]  R2300     -7.9439109563827515e-01
    z[8,7,0]  R2301     -7.9312282800674438e-01
    z[8,7,0]  R2302     6.7805558443069458e-02
    z[8,7,0]  R2303     3.4394392371177673e-01
    z[8,7,0]  R2304     3.5133108496665955e-01
    z[8,7,0]  R2305     2.5730523467063904e-01
    z[8,7,0]  R2306     -4.4008356332778931e-01
    z[8,7,0]  R2307     -8.8031291961669922e-02
    z[8,7,0]  R2308     -1.8469962477684021e-01
    z[8,7,0]  R2309     1.5967264771461487e-01
    z[8,7,0]  R2310     -7.2020488977432251e-01
    z[8,7,0]  R2311     -5.1735591888427734e-01
    z[8,7,0]  R2312     6.6200077533721924e-01
    z[8,7,0]  R2313     6.1138284206390381e-01
    z[8,7,0]  R2314     3.5945829749107361e-01
    z[8,7,0]  R2315     3.4982198476791382e-01
    z[8,7,0]  R2316     4.5862689614295959e-01
    z[8,7,0]  R2317     -3.2159939408302307e-02
    z[8,7,0]  R2318     -0.553945779800415
    z[8,7,0]  R2319     -1.6781832277774811e-01
    z[8,7,0]  R2320     2.1491825580596924e-01
    z[8,7,0]  R2321     -8.2912176847457886e-01
    z[8,7,0]  R2322     3.9126396179199219e-01
    z[8,7,0]  R2323     2.4881863594055176e-01
    z[8,7,0]  R2324     2.1482163667678833e-01
    z[8,7,0]  R2325     1.6018109396100044e-02
    z[8,7,0]  R2326     1.4037631452083588e-01
    z[8,7,0]  R2327     -1.0633911192417145e-01
    z[8,7,0]  R2328     3.5546919703483582e-01
    z[8,7,0]  R2329     -7.3311340808868408e-01
    z[8,7,0]  R2330     -0.69478839635849
    z[8,7,0]  R2331     -6.0788959264755249e-01
    z[8,7,0]  R2332     9.3835823237895966e-02
    z[8,7,0]  R2333     3.0185481905937195e-01
    z[8,7,0]  R2334     6.9934844970703125e-02
    z[8,7,0]  R2335     -3.5546261817216873e-02
    z[8,7,0]  R2336     -2.1151846647262573e-01
    z[8,7,0]  R2337     2.6397460699081421e-01
    z[8,7,0]  R2338     1.4714916236698627e-02
    z[8,7,0]  R2339     -0.826717734336853
    z[8,7,0]  R2340     -5.6553375720977783e-01
    z[8,7,0]  R2341     -4.6557343006134033e-01
    z[8,7,0]  R2342     2.2465810179710388e-01
    z[8,7,0]  R2343     -7.3979392647743225e-02
    z[8,7,0]  R2344     -0.567614734172821
    z[8,7,0]  R2345     2.2830119729042053e-01
    z[8,7,0]  R2346     3.2732114195823669e-01
    z[8,7,0]  R2347     -2.1348632872104645e-01
    z[8,7,0]  R2348     -5.2942311763763428e-01
    z[8,7,0]  R2349     -4.3943038582801819e-01
    z[8,7,0]  R2350     -7.5273221731185913e-01
    z[8,7,0]  R2351     -2.6824358105659485e-01
    z[8,7,0]  R2352     -5.7141637802124023e-01
    z[8,7,0]  R2353     -7.9831665754318237e-01
    z[8,7,0]  R2354     2.3983244597911835e-01
    z[8,7,0]  R2355     -4.5837086439132690e-01
    z[8,7,0]  R2356     -2.7903449535369873e-01
    z[8,7,0]  R2357     -2.3343828320503235e-01
    z[8,7,0]  R2358     -1.9718140363693237e-01
    z[8,7,0]  R2359     1.6486378014087677e-01
    z[8,7,0]  R2360     -8.1450670957565308e-01
    z[8,7,0]  R2361     -2.9810729622840881e-01
    z[8,7,0]  R2362     0.346869558095932
    z[8,7,0]  R2363     1.3677033782005310e-01
    z[8,7,0]  R2364     -2.9752010107040405e-01
    z[8,7,0]  R2365     -2.8384643793106079e-01
    z[8,7,0]  R2366     1.6154052317142487e-01
    z[8,7,0]  R2367     -4.7044627368450165e-02
    z[8,7,0]  R2368     2.0723946392536163e-01
    z[8,7,0]  R2369     -0.820107102394104
    z[8,7,0]  R2370     -5.7578301429748535e-01
    z[8,7,0]  R2371     -0.0969822108745575
    z[8,7,0]  R2372     6.0532465577125549e-02
    z[8,7,0]  R2373     -4.2753165960311890e-01
    z[8,7,0]  R2374     -1.7922100424766541e-01
    z[8,7,0]  R2375     -5.5445814132690430e-01
    z[8,7,0]  R2376     0.257851779460907
    z[8,7,0]  R2377     -1.9561986625194550e-01
    z[8,7,0]  R2378     -7.6634180545806885e-01
    z[8,7,0]  R2379     -2.9960823059082031e-01
    z[8,7,0]  R2380     -6.7675042152404785e-01
    z[8,7,0]  R2381     -7.6143556833267212e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2210     -1
    z[8,7,1]  R2211     1
    z[8,7,1]  R2222     1.9630730152130127e-02
    z[8,7,1]  R2223     -7.9196922481060028e-02
    z[8,7,1]  R2224     -1.9613333046436310e-02
    z[8,7,1]  R2225     1.1365023255348206e-01
    z[8,7,1]  R2226     -3.1931233406066895e-01
    z[8,7,1]  R2227     -1.1122805625200272e-01
    z[8,7,1]  R2228     1.1261923238635063e-02
    z[8,7,1]  R2229     -2.4862538278102875e-01
    z[8,7,1]  R2230     -5.1845584064722061e-02
    z[8,7,1]  R2231     -0.0972457155585289
    z[8,7,1]  R2232     8.0286830663681030e-01
    z[8,7,1]  R2233     5.8779406547546387e-01
    z[8,7,1]  R2234     5.0273990631103516e-01
    z[8,7,1]  R2235     4.3708527088165283e-01
    z[8,7,1]  R2236     4.7819891571998596e-01
    z[8,7,1]  R2237     4.5853444933891296e-01
    z[8,7,1]  R2238     4.3781113624572754e-01
    z[8,7,1]  R2239     5.7233953475952148e-01
    z[8,7,1]  R2240     5.0355130434036255e-01
    z[8,7,1]  R2241     3.4641581773757935e-01
    z[8,7,1]  R2242     -9.3039542436599731e-01
    z[8,7,1]  R2243     2.0746754109859467e-01
    z[8,7,1]  R2244     -8.8955307006835938e-01
    z[8,7,1]  R2245     -0.88219153881073
    z[8,7,1]  R2246     -8.5865569114685059e-01
    z[8,7,1]  R2247     -9.2376661300659180e-01
    z[8,7,1]  R2248     -8.7629443407058716e-01
    z[8,7,1]  R2249     -8.7441927194595337e-01
    z[8,7,1]  R2250     -8.8528978824615479e-01
    z[8,7,1]  R2251     -8.8353222608566284e-01
    z[8,7,1]  R2252     -6.1534738540649414e-01
    z[8,7,1]  R2253     1.6282060742378235e-01
    z[8,7,1]  R2254     -4.4630587100982666e-01
    z[8,7,1]  R2255     -1.6083197295665741e-01
    z[8,7,1]  R2256     -6.9364093244075775e-02
    z[8,7,1]  R2257     -2.9856148362159729e-01
    z[8,7,1]  R2258     -1.5196952223777771e-01
    z[8,7,1]  R2259     -1.4520509541034698e-01
    z[8,7,1]  R2260     -1.8252392113208771e-01
    z[8,7,1]  R2261     3.3651031553745270e-02
    z[8,7,1]  R2262     -3.3370348811149597e-01
    z[8,7,1]  R2263     -6.3353508710861206e-01
    z[8,7,1]  R2264     -9.1670429706573486e-01
    z[8,7,1]  R2265     2.0634920895099640e-01
    z[8,7,1]  R2266     -0.873768150806427
    z[8,7,1]  R2267     2.2565890848636627e-01
    z[8,7,1]  R2268     3.6477770656347275e-02
    z[8,7,1]  R2269     -1.0097629576921463e-01
    z[8,7,1]  R2270     -8.6336147785186768e-01
    z[8,7,1]  R2271     1.5227134525775909e-01
    z[8,7,1]  R2272     1.6411490738391876e-02
    z[8,7,1]  R2273     1.8768697977066040e-01
    z[8,7,1]  R2274     -2.3674362897872925e-01
    z[8,7,1]  R2275     2.9516544938087463e-01
    z[8,7,1]  R2276     2.3874360322952271e-01
    z[8,7,1]  R2277     2.4278904497623444e-01
    z[8,7,1]  R2278     3.0271226167678833e-01
    z[8,7,1]  R2279     -5.8600634336471558e-02
    z[8,7,1]  R2280     2.9660817980766296e-01
    z[8,7,1]  R2281     4.3455091118812561e-01
    z[8,7,1]  R2282     5.2240979671478271e-01
    z[8,7,1]  R2283     -5.1190710067749023e-01
    z[8,7,1]  R2284     -4.8452475666999817e-01
    z[8,7,1]  R2285     -0.502964437007904
    z[8,7,1]  R2286     -4.7964704036712646e-01
    z[8,7,1]  R2287     -0.854331910610199
    z[8,7,1]  R2288     -5.2673918008804321e-01
    z[8,7,1]  R2289     -4.7937366366386414e-01
    z[8,7,1]  R2290     -7.8769600391387939e-01
    z[8,7,1]  R2291     -5.6490635871887207e-01
    z[8,7,1]  R2292     1.2438297271728516e-02
    z[8,7,1]  R2293     6.8744570016860962e-01
    z[8,7,1]  R2294     4.6005198359489441e-01
    z[8,7,1]  R2295     -7.7825301885604858e-01
    z[8,7,1]  R2296     -2.2731673717498779e-01
    z[8,7,1]  R2297     -6.9942563772201538e-01
    z[8,7,1]  R2298     -1.7192485928535461e-01
    z[8,7,1]  R2299     -1.9084727764129639e-01
    z[8,7,1]  R2300     -3.4105113148689270e-01
    z[8,7,1]  R2301     -2.1921217441558838e-01
    z[8,7,1]  R2302     6.6876864433288574e-01
    z[8,7,1]  R2303     2.2041143476963043e-01
    z[8,7,1]  R2304     2.5117090344429016e-01
    z[8,7,1]  R2305     1.6876345872879028e-01
    z[8,7,1]  R2306     -7.2898006439208984e-01
    z[8,7,1]  R2307     -7.4544352293014526e-01
    z[8,7,1]  R2308     -5.6649994850158691e-01
    z[8,7,1]  R2309     -0.865119218826294
    z[8,7,1]  R2310     -0.507922351360321
    z[8,7,1]  R2311     -0.618511438369751
    z[8,7,1]  R2312     -2.1649330854415894e-01
    z[8,7,1]  R2313     3.0930796265602112e-01
    z[8,7,1]  R2314     8.4924995899200439e-01
    z[8,7,1]  R2315     4.2335382103919983e-01
    z[8,7,1]  R2316     4.6006661653518677e-01
    z[8,7,1]  R2317     7.8704708814620972e-01
    z[8,7,1]  R2318     -7.1661293506622314e-01
    z[8,7,1]  R2319     -7.4266058206558228e-01
    z[8,7,1]  R2320     -8.4290659427642822e-01
    z[8,7,1]  R2321     -4.6834820508956909e-01
    z[8,7,1]  R2322     3.1773579120635986e-01
    z[8,7,1]  R2323     3.5326966643333435e-01
    z[8,7,1]  R2324     -8.7270236015319824e-01
    z[8,7,1]  R2325     -8.1956350803375244e-01
    z[8,7,1]  R2326     6.7453527450561523e-01
    z[8,7,1]  R2327     -5.3128945827484131e-01
    z[8,7,1]  R2328     -0.854092001914978
    z[8,7,1]  R2329     1.3329645991325378e-01
    z[8,7,1]  R2330     1.7880636453628540e-01
    z[8,7,1]  R2331     -1.1599297635257244e-02
    z[8,7,1]  R2332     7.3112434148788452e-01
    z[8,7,1]  R2333     3.0246776342391968e-01
    z[8,7,1]  R2334     -6.0424768924713135e-01
    z[8,7,1]  R2335     -0.900780975818634
    z[8,7,1]  R2336     -7.2514319419860840e-01
    z[8,7,1]  R2337     4.5567423105239868e-01
    z[8,7,1]  R2338     -6.1548978090286255e-01
    z[8,7,1]  R2339     -2.8613340854644775e-01
    z[8,7,1]  R2340     2.3322394490242004e-01
    z[8,7,1]  R2341     2.5845530629158020e-01
    z[8,7,1]  R2342     4.8997023701667786e-01
    z[8,7,1]  R2343     4.0439867973327637e-01
    z[8,7,1]  R2344     -0.656741201877594
    z[8,7,1]  R2345     -8.8230144977569580e-01
    z[8,7,1]  R2346     -8.0567622184753418e-01
    z[8,7,1]  R2347     -5.0674062967300415e-01
    z[8,7,1]  R2348     -5.5835723876953125e-01
    z[8,7,1]  R2349     1.6405096650123596e-01
    z[8,7,1]  R2350     4.2379528284072876e-02
    z[8,7,1]  R2351     -2.6594796776771545e-01
    z[8,7,1]  R2352     -5.7925939559936523e-01
    z[8,7,1]  R2353     -5.6226819753646851e-01
    z[8,7,1]  R2354     -7.9547297954559326e-01
    z[8,7,1]  R2355     -6.3943260908126831e-01
    z[8,7,1]  R2356     -5.9386724233627319e-01
    z[8,7,1]  R2357     -7.3498421907424927e-01
    z[8,7,1]  R2358     -3.1208464503288269e-01
    z[8,7,1]  R2359     -6.8900579214096069e-01
    z[8,7,1]  R2360     -3.7101477384567261e-01
    z[8,7,1]  R2361     6.6063500940799713e-02
    z[8,7,1]  R2362     5.4832839965820312e-01
    z[8,7,1]  R2363     5.9515094757080078e-01
    z[8,7,1]  R2364     -7.0391672849655151e-01
    z[8,7,1]  R2365     -6.7108732461929321e-01
    z[8,7,1]  R2366     -0.752247154712677
    z[8,7,1]  R2367     -8.9022374153137207e-01
    z[8,7,1]  R2368     -7.2310638427734375e-01
    z[8,7,1]  R2369     2.3239577189087868e-02
    z[8,7,1]  R2370     -2.1518308669328690e-02
    z[8,7,1]  R2371     -4.8537105321884155e-01
    z[8,7,1]  R2372     2.7299115061759949e-01
    z[8,7,1]  R2373     -6.1635011434555054e-01
    z[8,7,1]  R2374     -8.9283865690231323e-01
    z[8,7,1]  R2375     -6.3888096809387207e-01
    z[8,7,1]  R2376     0.512329638004303
    z[8,7,1]  R2377     -2.2371679544448853e-01
    z[8,7,1]  R2378     -3.9436888694763184e-01
    z[8,7,1]  R2379     -4.8325982689857483e-01
    z[8,7,1]  R2380     3.8783061504364014e-01
    z[8,7,1]  R2381     2.6828026771545410e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2212     -1
    z[8,7,2]  R2213     1
    z[8,7,2]  R2222     0.508542537689209
    z[8,7,2]  R2223     3.8803330063819885e-01
    z[8,7,2]  R2224     4.5523053407669067e-01
    z[8,7,2]  R2225     1.8744862079620361e-01
    z[8,7,2]  R2226     3.4964513778686523e-01
    z[8,7,2]  R2227     1.0699527338147163e-02
    z[8,7,2]  R2228     2.3295685648918152e-01
    z[8,7,2]  R2229     5.0984853506088257e-01
    z[8,7,2]  R2230     6.4617067575454712e-02
    z[8,7,2]  R2231     4.4522005319595337e-01
    z[8,7,2]  R2232     -2.8069171309471130e-01
    z[8,7,2]  R2233     -2.6032933592796326e-01
    z[8,7,2]  R2234     -4.4359427690505981e-01
    z[8,7,2]  R2235     -6.2107211351394653e-01
    z[8,7,2]  R2236     -3.7472090125083923e-01
    z[8,7,2]  R2237     -0.568618893623352
    z[8,7,2]  R2238     -1.7549788951873779e-01
    z[8,7,2]  R2239     -3.2367938756942749e-01
    z[8,7,2]  R2240     -5.3947108983993530e-01
    z[8,7,2]  R2241     -7.0862895250320435e-01
    z[8,7,2]  R2242     -0.0657036080956459
    z[8,7,2]  R2243     0.23386250436306
    z[8,7,2]  R2244     1.0245457291603088e-01
    z[8,7,2]  R2245     -2.5030821561813354e-01
    z[8,7,2]  R2246     -3.6769038438796997e-01
    z[8,7,2]  R2247     -1.3862235844135284e-01
    z[8,7,2]  R2248     -7.5600305572152138e-03
    z[8,7,2]  R2249     -1.4240401983261108e-01
    z[8,7,2]  R2250     -3.8570471107959747e-02
    z[8,7,2]  R2251     -3.9163712412118912e-02
    z[8,7,2]  R2252     1.0111314058303833e-01
    z[8,7,2]  R2253     -2.2710916399955750e-01
    z[8,7,2]  R2254     -2.7996638417243958e-01
    z[8,7,2]  R2255     5.8180510997772217e-02
    z[8,7,2]  R2256     -1.9354438781738281e-01
    z[8,7,2]  R2257     0.0391550213098526
    z[8,7,2]  R2258     -1.0665337741374969e-01
    z[8,7,2]  R2259     9.8015762865543365e-02
    z[8,7,2]  R2260     -1.9831072539091110e-02
    z[8,7,2]  R2261     -8.0827414989471436e-02
    z[8,7,2]  R2262     0.0355074517428875
    z[8,7,2]  R2263     3.8741311430931091e-01
    z[8,7,2]  R2264     -1.0585274547338486e-01
    z[8,7,2]  R2265     -3.9191875606775284e-02
    z[8,7,2]  R2266     3.4256509970873594e-03
    z[8,7,2]  R2267     2.8114444017410278e-01
    z[8,7,2]  R2268     -1.0289106518030167e-01
    z[8,7,2]  R2269     -1.0542208328843117e-02
    z[8,7,2]  R2270     -2.1782732009887695e-01
    z[8,7,2]  R2271     8.0047480762004852e-02
    z[8,7,2]  R2272     2.5777277350425720e-01
    z[8,7,2]  R2273     -1.1954865604639053e-01
    z[8,7,2]  R2274     1.0909274965524673e-01
    z[8,7,2]  R2275     -1.0482856631278992e-01
    z[8,7,2]  R2276     -2.9389381408691406e-01
    z[8,7,2]  R2277     -0.358809232711792
    z[8,7,2]  R2278     -0.108444444835186
    z[8,7,2]  R2279     1.3620543479919434e-01
    z[8,7,2]  R2280     -9.4696566462516785e-02
    z[8,7,2]  R2281     -2.3804001510143280e-01
    z[8,7,2]  R2282     4.7510975599288940e-01
    z[8,7,2]  R2283     -4.3975785374641418e-01
    z[8,7,2]  R2284     -6.3251811265945435e-01
    z[8,7,2]  R2285     -6.5593171119689941e-01
    z[8,7,2]  R2286     -3.6732786893844604e-01
    z[8,7,2]  R2287     5.5395025759935379e-02
    z[8,7,2]  R2288     -5.7521623373031616e-01
    z[8,7,2]  R2289     -5.3364193439483643e-01
    z[8,7,2]  R2290     -4.8240253329277039e-01
    z[8,7,2]  R2291     -4.0648695826530457e-01
    z[8,7,2]  R2292     7.5240141153335571e-01
    z[8,7,2]  R2293     2.6230162382125854e-01
    z[8,7,2]  R2294     -1.4601278118789196e-02
    z[8,7,2]  R2295     1.1752258241176605e-01
    z[8,7,2]  R2296     5.1802337169647217e-01
    z[8,7,2]  R2297     -8.5014671087265015e-02
    z[8,7,2]  R2298     -4.3336819857358932e-02
    z[8,7,2]  R2299     -6.9281840696930885e-03
    z[8,7,2]  R2300     2.6703259348869324e-01
    z[8,7,2]  R2301     4.8138287663459778e-01
    z[8,7,2]  R2302     6.2798202037811279e-01
    z[8,7,2]  R2303     5.0892859697341919e-01
    z[8,7,2]  R2304     3.6279958486557007e-01
    z[8,7,2]  R2305     3.9509826898574829e-01
    z[8,7,2]  R2306     -1.8965192139148712e-01
    z[8,7,2]  R2307     -4.0701773762702942e-01
    z[8,7,2]  R2308     -3.4555483609437943e-02
    z[8,7,2]  R2309     -3.2562226057052612e-02
    z[8,7,2]  R2310     -1.1808338761329651e-01
    z[8,7,2]  R2311     -3.9527878165245056e-01
    z[8,7,2]  R2312     2.0764118060469627e-02
    z[8,7,2]  R2313     3.7314009666442871e-01
    z[8,7,2]  R2314     1.9965112209320068e-01
    z[8,7,2]  R2315     5.7231187820434570e-01
    z[8,7,2]  R2316     1.8976931273937225e-01
    z[8,7,2]  R2317     1.5339636802673340e-01
    z[8,7,2]  R2318     -3.3698305487632751e-01
    z[8,7,2]  R2319     -6.9558590650558472e-02
    z[8,7,2]  R2320     -2.9084178805351257e-01
    z[8,7,2]  R2321     1.6147981584072113e-01
    z[8,7,2]  R2322     5.5289882421493530e-01
    z[8,7,2]  R2323     5.6592386960983276e-01
    z[8,7,2]  R2324     -2.6835048198699951e-01
    z[8,7,2]  R2325     -4.5116010308265686e-01
    z[8,7,2]  R2326     3.9275681972503662e-01
    z[8,7,2]  R2327     1.4864921569824219e-01
    z[8,7,2]  R2328     1.4777974784374237e-01
    z[8,7,2]  R2329     1.4433830045163631e-02
    z[8,7,2]  R2330     5.8649875223636627e-02
    z[8,7,2]  R2331     9.5928184688091278e-02
    z[8,7,2]  R2332     2.0550854504108429e-01
    z[8,7,2]  R2333     0.733496904373169
    z[8,7,2]  R2334     -3.0421867966651917e-01
    z[8,7,2]  R2335     4.0832184255123138e-02
    z[8,7,2]  R2336     -2.1121737360954285e-01
    z[8,7,2]  R2337     -2.3063591122627258e-01
    z[8,7,2]  R2338     -1.8074475228786469e-01
    z[8,7,2]  R2339     2.3348145186901093e-01
    z[8,7,2]  R2340     -5.4902553558349609e-02
    z[8,7,2]  R2341     -1.1982156336307526e-01
    z[8,7,2]  R2342     4.7163677215576172e-01
    z[8,7,2]  R2343     4.8232552409172058e-01
    z[8,7,2]  R2344     9.2045597732067108e-02
    z[8,7,2]  R2345     4.4353265315294266e-02
    z[8,7,2]  R2346     -0.0972619354724884
    z[8,7,2]  R2347     -2.3143781721591949e-01
    z[8,7,2]  R2348     3.4219604730606079e-01
    z[8,7,2]  R2349     -1.6744692623615265e-01
    z[8,7,2]  R2350     -3.4664005041122437e-01
    z[8,7,2]  R2351     -7.7150254510343075e-03
    z[8,7,2]  R2352     -3.6362352967262268e-01
    z[8,7,2]  R2353     1.8867236375808716e-01
    z[8,7,2]  R2354     -3.1880292296409607e-01
    z[8,7,2]  R2355     2.4227949976921082e-01
    z[8,7,2]  R2356     2.2747018933296204e-01
    z[8,7,2]  R2357     1.7310473322868347e-01
    z[8,7,2]  R2358     2.0147490501403809e-01
    z[8,7,2]  R2359     -3.0700030922889709e-01
    z[8,7,2]  R2360     1.7181381583213806e-02
    z[8,7,2]  R2361     -2.2931785881519318e-01
    z[8,7,2]  R2362     6.6481626033782959e-01
    z[8,7,2]  R2363     2.7252513170242310e-01
    z[8,7,2]  R2364     -2.7540338039398193e-01
    z[8,7,2]  R2365     7.6584428548812866e-02
    z[8,7,2]  R2366     -5.7331192493438721e-01
    z[8,7,2]  R2367     -2.6023969054222107e-01
    z[8,7,2]  R2368     -2.5527155399322510e-01
    z[8,7,2]  R2369     -1.5020149759948254e-02
    z[8,7,2]  R2370     -6.1559706926345825e-02
    z[8,7,2]  R2371     7.7393390238285065e-02
    z[8,7,2]  R2372     6.6374713182449341e-01
    z[8,7,2]  R2373     1.5252985060214996e-01
    z[8,7,2]  R2374     -3.3343076705932617e-01
    z[8,7,2]  R2375     -3.8093057274818420e-01
    z[8,7,2]  R2376     -4.5072987675666809e-01
    z[8,7,2]  R2377     3.1683048605918884e-01
    z[8,7,2]  R2378     -6.4119093120098114e-02
    z[8,7,2]  R2379     1.8009927123785019e-02
    z[8,7,2]  R2380     -5.0373566150665283e-01
    z[8,7,2]  R2381     -5.5464059114456177e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2214     -1
    z[8,7,3]  R2215     1
    z[8,7,3]  R2222     2.5739121437072754e-01
    z[8,7,3]  R2223     1.6530117392539978e-01
    z[8,7,3]  R2224     1.7963266372680664e-01
    z[8,7,3]  R2225     1.3234589993953705e-01
    z[8,7,3]  R2226     -4.1194036602973938e-02
    z[8,7,3]  R2227     1.3977135717868805e-01
    z[8,7,3]  R2228     -0.0847676619887352
    z[8,7,3]  R2229     3.2371747493743896e-01
    z[8,7,3]  R2230     1.3982596993446350e-01
    z[8,7,3]  R2231     4.7496250271797180e-01
    z[8,7,3]  R2232     7.1082182228565216e-02
    z[8,7,3]  R2233     5.2524650096893311e-01
    z[8,7,3]  R2234     4.5181828737258911e-01
    z[8,7,3]  R2235     3.5764062404632568e-01
    z[8,7,3]  R2236     2.4676126241683960e-01
    z[8,7,3]  R2237     1.6248725354671478e-01
    z[8,7,3]  R2238     3.5538071393966675e-01
    z[8,7,3]  R2239     4.9725881218910217e-01
    z[8,7,3]  R2240     1.0206269472837448e-01
    z[8,7,3]  R2241     2.6244139671325684e-01
    z[8,7,3]  R2242     7.6342053711414337e-02
    z[8,7,3]  R2243     -5.8134537935256958e-01
    z[8,7,3]  R2244     -2.5366422533988953e-01
    z[8,7,3]  R2245     -1.7145574092864990e-01
    z[8,7,3]  R2246     0.0885215699672699
    z[8,7,3]  R2247     1.3964995741844177e-01
    z[8,7,3]  R2248     -1.9695621728897095e-01
    z[8,7,3]  R2249     -6.9412998855113983e-02
    z[8,7,3]  R2250     -1.7963644862174988e-01
    z[8,7,3]  R2251     -1.2966012954711914e-01
    z[8,7,3]  R2252     6.1762750148773193e-01
    z[8,7,3]  R2253     -6.0979276895523071e-01
    z[8,7,3]  R2254     -7.1638122200965881e-02
    z[8,7,3]  R2255     -3.3242511749267578e-01
    z[8,7,3]  R2256     -5.5677896738052368e-01
    z[8,7,3]  R2257     -3.1964725255966187e-01
    z[8,7,3]  R2258     -0.56904536485672
    z[8,7,3]  R2259     -4.8577833175659180e-01
    z[8,7,3]  R2260     -4.5397144556045532e-01
    z[8,7,3]  R2261     -6.0044860839843750e-01
    z[8,7,3]  R2262     4.0795540809631348e-01
    z[8,7,3]  R2263     1.8678598105907440e-01
    z[8,7,3]  R2264     1.8172113597393036e-01
    z[8,7,3]  R2265     -0.290932834148407
    z[8,7,3]  R2266     6.5892942249774933e-02
    z[8,7,3]  R2267     -2.2303043305873871e-01
    z[8,7,3]  R2268     -6.0945552587509155e-01
    z[8,7,3]  R2269     -2.3416090011596680e-01
    z[8,7,3]  R2270     -1.4389619231224060e-01
    z[8,7,3]  R2271     -1.4314334094524384e-01
    z[8,7,3]  R2272     3.6191475391387939e-01
    z[8,7,3]  R2273     2.7237620949745178e-01
    z[8,7,3]  R2274     6.7980909347534180e-01
    z[8,7,3]  R2275     7.3311723768711090e-02
    z[8,7,3]  R2276     0.42009437084198
    z[8,7,3]  R2277     2.3003891110420227e-01
    z[8,7,3]  R2278     3.1932342052459717e-01
    z[8,7,3]  R2279     3.5840702056884766e-01
    z[8,7,3]  R2280     5.6651169061660767e-01
    z[8,7,3]  R2281     2.8356346487998962e-01
    z[8,7,3]  R2282     -5.6767380237579346e-01
    z[8,7,3]  R2283     -3.6865150928497314e-01
    z[8,7,3]  R2284     -3.7740305066108704e-01
    z[8,7,3]  R2285     -5.0571990013122559e-01
    z[8,7,3]  R2286     -0.410660982131958
    z[8,7,3]  R2287     2.1263739466667175e-01
    z[8,7,3]  R2288     -5.3038388490676880e-01
    z[8,7,3]  R2289     -5.2300339937210083e-01
    z[8,7,3]  R2290     -2.2139649093151093e-01
    z[8,7,3]  R2291     -4.4104033708572388e-01
    z[8,7,3]  R2292     -3.6225321888923645e-01
    z[8,7,3]  R2293     1.0925932228565216e-01
    z[8,7,3]  R2294     -7.1278387308120728e-01
    z[8,7,3]  R2295     2.1688152849674225e-01
    z[8,7,3]  R2296     -6.9918829202651978e-01
    z[8,7,3]  R2297     2.2615356743335724e-01
    z[8,7,3]  R2298     -9.6766859292984009e-02
    z[8,7,3]  R2299     -1.0856787860393524e-01
    z[8,7,3]  R2300     -7.7130466699600220e-02
    z[8,7,3]  R2301     -2.0936983823776245e-01
    z[8,7,3]  R2302     5.5666558444499969e-02
    z[8,7,3]  R2303     -4.1393363475799561e-01
    z[8,7,3]  R2304     -7.4532374739646912e-02
    z[8,7,3]  R2305     -3.2952728867530823e-01
    z[8,7,3]  R2306     5.7273630052804947e-02
    z[8,7,3]  R2307     3.5371991991996765e-01
    z[8,7,3]  R2308     6.2036764621734619e-01
    z[8,7,3]  R2309     0.174591064453125
    z[8,7,3]  R2310     -6.5473616123199463e-02
    z[8,7,3]  R2311     9.8076008260250092e-02
    z[8,7,3]  R2312     0.54584139585495
    z[8,7,3]  R2313     -5.0053983926773071e-01
    z[8,7,3]  R2314     -6.7424766719341278e-02
    z[8,7,3]  R2315     -4.1990217566490173e-01
    z[8,7,3]  R2316     -4.7919595241546631e-01
    z[8,7,3]  R2317     -4.7395061701536179e-02
    z[8,7,3]  R2318     -7.9899743199348450e-02
    z[8,7,3]  R2319     3.8864096999168396e-01
    z[8,7,3]  R2320     0.112656369805336
    z[8,7,3]  R2321     -1.6416944563388824e-01
    z[8,7,3]  R2322     -1.8139523267745972e-01
    z[8,7,3]  R2323     -3.0042198300361633e-01
    z[8,7,3]  R2324     2.0458501577377319e-01
    z[8,7,3]  R2325     0.299461305141449
    z[8,7,3]  R2326     -3.0456364154815674e-01
    z[8,7,3]  R2327     6.3462370634078979e-01
    z[8,7,3]  R2328     -3.1808264553546906e-02
    z[8,7,3]  R2329     -6.1111348867416382e-01
    z[8,7,3]  R2330     -4.4662916660308838e-01
    z[8,7,3]  R2331     -7.2431737184524536e-01
    z[8,7,3]  R2332     -9.9267408251762390e-02
    z[8,7,3]  R2333     -2.1639212965965271e-01
    z[8,7,3]  R2334     4.5839720964431763e-01
    z[8,7,3]  R2335     -1.2969951145350933e-02
    z[8,7,3]  R2336     1.9489879906177521e-01
    z[8,7,3]  R2337     -0.739753782749176
    z[8,7,3]  R2338     4.2342305183410645e-01
    z[8,7,3]  R2339     -1.6215343773365021e-01
    z[8,7,3]  R2340     -6.8730795383453369e-01
    z[8,7,3]  R2341     -8.0857044458389282e-01
    z[8,7,3]  R2342     -4.8054140806198120e-01
    z[8,7,3]  R2343     6.1848795413970947e-01
    z[8,7,3]  R2344     -2.5894984602928162e-01
    z[8,7,3]  R2345     2.4202822148799896e-01
    z[8,7,3]  R2346     2.5243896525353193e-03
    z[8,7,3]  R2347     5.7796555757522583e-01
    z[8,7,3]  R2348     3.4566736221313477e-01
    z[8,7,3]  R2349     -7.0362383127212524e-01
    z[8,7,3]  R2350     -3.6247396469116211e-01
    z[8,7,3]  R2351     -0.738812267780304
    z[8,7,3]  R2352     -4.3917959928512573e-01
    z[8,7,3]  R2353     -6.6205725073814392e-02
    z[8,7,3]  R2354     2.7190076652914286e-03
    z[8,7,3]  R2355     4.7790881991386414e-01
    z[8,7,3]  R2356     6.6536128520965576e-01
    z[8,7,3]  R2357     2.6913082599639893e-01
    z[8,7,3]  R2358     8.1416743993759155e-01
    z[8,7,3]  R2359     7.6190240681171417e-02
    z[8,7,3]  R2360     7.1276850998401642e-02
    z[8,7,3]  R2361     -8.8126683235168457e-01
    z[8,7,3]  R2362     -2.3248299956321716e-01
    z[8,7,3]  R2363     -1.1482724547386169e-01
    z[8,7,3]  R2364     4.6430990099906921e-01
    z[8,7,3]  R2365     5.5468821525573730e-01
    z[8,7,3]  R2366     1.5193149447441101e-02
    z[8,7,3]  R2367     -3.2171458005905151e-02
    z[8,7,3]  R2368     5.1962349563837051e-02
    z[8,7,3]  R2369     -5.0766462087631226e-01
    z[8,7,3]  R2370     -7.0269167423248291e-01
    z[8,7,3]  R2371     3.8918992877006531e-01
    z[8,7,3]  R2372     -3.2630622386932373e-01
    z[8,7,3]  R2373     5.4890251159667969e-01
    z[8,7,3]  R2374     3.0041038990020752e-02
    z[8,7,3]  R2375     -7.0372693240642548e-02
    z[8,7,3]  R2376     -6.6674917936325073e-01
    z[8,7,3]  R2377     8.2571476697921753e-01
    z[8,7,3]  R2378     1.8634662032127380e-01
    z[8,7,3]  R2379     -5.4187369346618652e-01
    z[8,7,3]  R2380     -1.8501089513301849e-01
    z[8,7,3]  R2381     1.1763103306293488e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2216     -1
    z[8,7,4]  R2217     1
    z[8,7,4]  R2222     -1.6608202457427979e-01
    z[8,7,4]  R2223     1.4930222928524017e-01
    z[8,7,4]  R2224     1.0916792601346970e-01
    z[8,7,4]  R2225     1.6858358681201935e-01
    z[8,7,4]  R2226     1.7198072746396065e-02
    z[8,7,4]  R2227     -3.4115172922611237e-02
    z[8,7,4]  R2228     -1.9708819687366486e-02
    z[8,7,4]  R2229     1.2298287451267242e-01
    z[8,7,4]  R2230     -0.27997025847435
    z[8,7,4]  R2231     -1.6390171647071838e-01
    z[8,7,4]  R2232     -1.8132030963897705e-01
    z[8,7,4]  R2233     1.9520732760429382e-01
    z[8,7,4]  R2234     -1.9591921567916870e-01
    z[8,7,4]  R2235     -3.0801620334386826e-02
    z[8,7,4]  R2236     -6.9214117527008057e-01
    z[8,7,4]  R2237     -2.2359889745712280e-01
    z[8,7,4]  R2238     2.5557526946067810e-01
    z[8,7,4]  R2239     -2.2692269086837769e-01
    z[8,7,4]  R2240     3.4116649627685547e-01
    z[8,7,4]  R2241     2.1558435261249542e-01
    z[8,7,4]  R2242     9.2774204909801483e-02
    z[8,7,4]  R2243     -8.5824113339185715e-03
    z[8,7,4]  R2244     8.9389160275459290e-02
    z[8,7,4]  R2245     1.5136560425162315e-02
    z[8,7,4]  R2246     7.6929312199354172e-03
    z[8,7,4]  R2247     -0.0321052223443985
    z[8,7,4]  R2248     -7.9387754201889038e-02
    z[8,7,4]  R2249     -1.2461936473846436e-01
    z[8,7,4]  R2250     -1.1244063824415207e-01
    z[8,7,4]  R2251     7.1235232055187225e-02
    z[8,7,4]  R2252     3.2721456140279770e-02
    z[8,7,4]  R2253     2.3946096003055573e-01
    z[8,7,4]  R2254     3.6254864931106567e-01
    z[8,7,4]  R2255     -3.1196763738989830e-02
    z[8,7,4]  R2256     4.7189682722091675e-02
    z[8,7,4]  R2257     -4.9045007675886154e-02
    z[8,7,4]  R2258     2.2894616425037384e-01
    z[8,7,4]  R2259     2.1908958256244659e-01
    z[8,7,4]  R2260     1.0117696970701218e-01
    z[8,7,4]  R2261     3.4478890895843506e-01
    z[8,7,4]  R2262     5.3812485933303833e-01
    z[8,7,4]  R2263     2.0495966076850891e-01
    z[8,7,4]  R2264     -1.7710077762603760e-01
    z[8,7,4]  R2265     4.3691709637641907e-01
    z[8,7,4]  R2266     -9.8659023642539978e-03
    z[8,7,4]  R2267     6.8453907966613770e-02
    z[8,7,4]  R2268     1.5254114568233490e-01
    z[8,7,4]  R2269     -3.0586105585098267e-01
    z[8,7,4]  R2270     -2.0717906951904297e-01
    z[8,7,4]  R2271     -8.4953360259532928e-02
    z[8,7,4]  R2272     1.6483603417873383e-01
    z[8,7,4]  R2273     -2.0548866689205170e-01
    z[8,7,4]  R2274     -1.2014985829591751e-01
    z[8,7,4]  R2275     2.9497590661048889e-01
    z[8,7,4]  R2276     1.4236049354076385e-01
    z[8,7,4]  R2277     2.5435414910316467e-01
    z[8,7,4]  R2278     1.6347086429595947e-01
    z[8,7,4]  R2279     -4.1072311997413635e-01
    z[8,7,4]  R2280     -2.4284815788269043e-01
    z[8,7,4]  R2281     -1.8633264303207397e-01
    z[8,7,4]  R2282     3.5102775692939758e-01
    z[8,7,4]  R2283     -4.9579218029975891e-01
    z[8,7,4]  R2284     -0.420878142118454
    z[8,7,4]  R2285     -1.1079634726047516e-01
    z[8,7,4]  R2286     -4.8875716328620911e-01
    z[8,7,4]  R2287     -3.1739141792058945e-02
    z[8,7,4]  R2288     -1.8995173275470734e-01
    z[8,7,4]  R2289     8.6141005158424377e-03
    z[8,7,4]  R2290     -2.5475943088531494e-01
    z[8,7,4]  R2291     -4.2808291316032410e-01
    z[8,7,4]  R2292     -1.7352880537509918e-01
    z[8,7,4]  R2293     2.0763443410396576e-01
    z[8,7,4]  R2294     -1.5970483422279358e-01
    z[8,7,4]  R2295     -0.164675772190094
    z[8,7,4]  R2296     6.9020465016365051e-02
    z[8,7,4]  R2297     3.3810202032327652e-02
    z[8,7,4]  R2298     2.0591814070940018e-02
    z[8,7,4]  R2299     1.2437465041875839e-01
    z[8,7,4]  R2300     2.7689921855926514e-01
    z[8,7,4]  R2301     1.0139914602041245e-01
    z[8,7,4]  R2302     -7.4027101509273052e-03
    z[8,7,4]  R2303     -9.2984713613986969e-02
    z[8,7,4]  R2304     5.7830739021301270e-01
    z[8,7,4]  R2305     5.7642382383346558e-01
    z[8,7,4]  R2306     9.1092668473720551e-02
    z[8,7,4]  R2307     -2.9985904693603516e-01
    z[8,7,4]  R2308     -3.4815132617950439e-01
    z[8,7,4]  R2309     -5.8498740196228027e-02
    z[8,7,4]  R2310     2.5201949477195740e-01
    z[8,7,4]  R2311     1.6721126437187195e-01
    z[8,7,4]  R2312     1.5844435989856720e-01
    z[8,7,4]  R2313     3.3917296677827835e-03
    z[8,7,4]  R2314     -1.0530129820108414e-01
    z[8,7,4]  R2315     -3.4999931231141090e-03
    z[8,7,4]  R2316     1.9685381650924683e-01
    z[8,7,4]  R2317     4.1764539480209351e-01
    z[8,7,4]  R2318     1.4651700854301453e-01
    z[8,7,4]  R2319     4.3963202834129333e-01
    z[8,7,4]  R2320     3.0410623550415039e-01
    z[8,7,4]  R2321     1.7601549625396729e-01
    z[8,7,4]  R2322     -1.3534653186798096e-01
    z[8,7,4]  R2323     4.7975964844226837e-02
    z[8,7,4]  R2324     1.0215112566947937e-01
    z[8,7,4]  R2325     -0.0791703388094902
    z[8,7,4]  R2326     -1.5117718279361725e-01
    z[8,7,4]  R2327     -0.000655064475722611
    z[8,7,4]  R2328     -1.3639484345912933e-01
    z[8,7,4]  R2329     -1.7070990800857544e-01
    z[8,7,4]  R2330     -4.9967950582504272e-01
    z[8,7,4]  R2331     -1.6937865316867828e-01
    z[8,7,4]  R2332     5.0345176458358765e-01
    z[8,7,4]  R2333     -1.9321238994598389e-01
    z[8,7,4]  R2334     -0.510749340057373
    z[8,7,4]  R2335     -1.7659065127372742e-01
    z[8,7,4]  R2336     -3.2749277353286743e-01
    z[8,7,4]  R2337     -1.6959272325038910e-01
    z[8,7,4]  R2338     -2.5101867318153381e-01
    z[8,7,4]  R2339     -3.8920632004737854e-01
    z[8,7,4]  R2340     -3.8718926906585693e-01
    z[8,7,4]  R2341     -1.7540577054023743e-01
    z[8,7,4]  R2342     2.6764786243438721e-01
    z[8,7,4]  R2343     2.7633774280548096e-01
    z[8,7,4]  R2344     2.6715666055679321e-01
    z[8,7,4]  R2345     1.8802155554294586e-01
    z[8,7,4]  R2346     -1.0254956036806107e-01
    z[8,7,4]  R2347     2.7900439500808716e-01
    z[8,7,4]  R2348     1.4084173738956451e-01
    z[8,7,4]  R2349     -3.8704228401184082e-01
    z[8,7,4]  R2350     7.1601629257202148e-02
    z[8,7,4]  R2351     1.6826494038105011e-01
    z[8,7,4]  R2352     6.9450519979000092e-02
    z[8,7,4]  R2353     5.5063869804143906e-02
    z[8,7,4]  R2354     1.9221821799874306e-02
    z[8,7,4]  R2355     0.0171035286039114
    z[8,7,4]  R2356     2.2876986861228943e-01
    z[8,7,4]  R2357     -2.5459113717079163e-01
    z[8,7,4]  R2358     7.4961505830287933e-02
    z[8,7,4]  R2359     -1.6473822295665741e-01
    z[8,7,4]  R2360     -3.0694943666458130e-01
    z[8,7,4]  R2361     -2.2959465160965919e-02
    z[8,7,4]  R2362     9.0642586350440979e-02
    z[8,7,4]  R2363     4.7416013479232788e-01
    z[8,7,4]  R2364     1.4224231243133545e-01
    z[8,7,4]  R2365     -3.5413238406181335e-01
    z[8,7,4]  R2366     8.0844148993492126e-02
    z[8,7,4]  R2367     2.1051813662052155e-01
    z[8,7,4]  R2368     -1.5900759398937225e-01
    z[8,7,4]  R2369     -2.7241092175245285e-02
    z[8,7,4]  R2370     1.8105036020278931e-01
    z[8,7,4]  R2371     6.2217503786087036e-01
    z[8,7,4]  R2372     3.6257752776145935e-01
    z[8,7,4]  R2373     -1.5457384288311005e-01
    z[8,7,4]  R2374     1.6399468481540680e-01
    z[8,7,4]  R2375     7.4029639363288879e-02
    z[8,7,4]  R2376     3.4444069024175406e-03
    z[8,7,4]  R2377     2.1715784445405006e-02
    z[8,7,4]  R2378     -1.1888762563467026e-01
    z[8,7,4]  R2379     -1.4770109951496124e-01
    z[8,7,4]  R2380     -2.0655460655689240e-01
    z[8,7,4]  R2381     1.4602577686309814e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2218     -1
    z[8,7,5]  R2219     1
    z[8,7,5]  R2222     3.7518101930618286e-01
    z[8,7,5]  R2223     -6.0493446653708816e-04
    z[8,7,5]  R2224     2.2294235229492188e-01
    z[8,7,5]  R2225     2.8060016036033630e-01
    z[8,7,5]  R2226     2.0822128653526306e-01
    z[8,7,5]  R2227     2.6795136928558350e-01
    z[8,7,5]  R2228     2.4268044531345367e-01
    z[8,7,5]  R2229     -1.2292737513780594e-01
    z[8,7,5]  R2230     0.171631321310997
    z[8,7,5]  R2231     -1.7719285190105438e-01
    z[8,7,5]  R2232     -4.6486237645149231e-01
    z[8,7,5]  R2233     -2.3795351386070251e-01
    z[8,7,5]  R2234     1.5455009043216705e-01
    z[8,7,5]  R2235     -5.0613671541213989e-01
    z[8,7,5]  R2236     2.0881672203540802e-01
    z[8,7,5]  R2237     -3.0684599280357361e-01
    z[8,7,5]  R2238     -6.2262868881225586e-01
    z[8,7,5]  R2239     2.8113192319869995e-01
    z[8,7,5]  R2240     1.2872710824012756e-01
    z[8,7,5]  R2241     -1.3126474618911743e-01
    z[8,7,5]  R2242     5.3936883807182312e-02
    z[8,7,5]  R2243     -2.0388758182525635e-01
    z[8,7,5]  R2244     -2.4250808358192444e-01
    z[8,7,5]  R2245     -1.6675812005996704e-01
    z[8,7,5]  R2246     -1.8792568147182465e-01
    z[8,7,5]  R2247     2.3786008358001709e-01
    z[8,7,5]  R2248     1.3416735827922821e-01
    z[8,7,5]  R2249     2.9073727130889893e-01
    z[8,7,5]  R2250     -7.5451299548149109e-02
    z[8,7,5]  R2251     -1.6008451581001282e-01
    z[8,7,5]  R2252     2.8374210000038147e-01
    z[8,7,5]  R2253     -9.4341598451137543e-02
    z[8,7,5]  R2254     -3.8035833835601807e-01
    z[8,7,5]  R2255     4.5989226549863815e-02
    z[8,7,5]  R2256     1.1464400589466095e-01
    z[8,7,5]  R2257     -1.8688382208347321e-01
    z[8,7,5]  R2258     -1.3190971314907074e-01
    z[8,7,5]  R2259     -3.4474423527717590e-01
    z[8,7,5]  R2260     -5.5179882049560547e-01
    z[8,7,5]  R2261     -4.4205829501152039e-01
    z[8,7,5]  R2262     4.1795790195465088e-01
    z[8,7,5]  R2263     5.2266085147857666e-01
    z[8,7,5]  R2264     -3.5278671421110630e-03
    z[8,7,5]  R2265     -1.4266875386238098e-01
    z[8,7,5]  R2266     -4.2489495873451233e-01
    z[8,7,5]  R2267     -1.4343149960041046e-01
    z[8,7,5]  R2268     -2.5397273898124695e-01
    z[8,7,5]  R2269     -1.2654094398021698e-01
    z[8,7,5]  R2270     -1.2960636615753174e-01
    z[8,7,5]  R2271     2.9142990708351135e-01
    z[8,7,5]  R2272     3.6157190799713135e-01
    z[8,7,5]  R2273     8.6428232491016388e-02
    z[8,7,5]  R2274     1.7475946247577667e-01
    z[8,7,5]  R2275     2.1422280371189117e-01
    z[8,7,5]  R2276     -2.6312029361724854e-01
    z[8,7,5]  R2277     -1.1258765310049057e-01
    z[8,7,5]  R2278     -6.9279879331588745e-02
    z[8,7,5]  R2279     2.6745384931564331e-01
    z[8,7,5]  R2280     -2.8706169128417969e-01
    z[8,7,5]  R2281     -2.1840818226337433e-01
    z[8,7,5]  R2282     -1.7786248028278351e-01
    z[8,7,5]  R2283     -2.1726746112108231e-02
    z[8,7,5]  R2284     -6.3736066222190857e-02
    z[8,7,5]  R2285     3.1286545097827911e-02
    z[8,7,5]  R2286     7.8133922070264816e-03
    z[8,7,5]  R2287     1.1068589985370636e-01
    z[8,7,5]  R2288     2.6434719562530518e-01
    z[8,7,5]  R2289     0.0418284609913826
    z[8,7,5]  R2290     1.6630619764328003e-01
    z[8,7,5]  R2291     2.8218093514442444e-01
    z[8,7,5]  R2292     -0.478199303150177
    z[8,7,5]  R2293     -1.9420586526393890e-01
    z[8,7,5]  R2294     -7.1430094540119171e-02
    z[8,7,5]  R2295     -0.292460560798645
    z[8,7,5]  R2296     2.2123925387859344e-01
    z[8,7,5]  R2297     -4.1238903999328613e-01
    z[8,7,5]  R2298     -3.6590325832366943e-01
    z[8,7,5]  R2299     -3.0864715576171875e-01
    z[8,7,5]  R2300     -3.1340357661247253e-01
    z[8,7,5]  R2301     1.8844987452030182e-01
    z[8,7,5]  R2302     -3.8047227263450623e-01
    z[8,7,5]  R2303     -2.8123003244400024e-01
    z[8,7,5]  R2304     -3.0721798539161682e-01
    z[8,7,5]  R2305     -3.0520227551460266e-01
    z[8,7,5]  R2306     -2.6596600189805031e-02
    z[8,7,5]  R2307     -2.2794160246849060e-01
    z[8,7,5]  R2308     -2.9888552427291870e-01
    z[8,7,5]  R2309     2.7011623978614807e-01
    z[8,7,5]  R2310     -1.4479759335517883e-01
    z[8,7,5]  R2311     -3.0097526311874390e-01
    z[8,7,5]  R2312     1.1131688207387924e-01
    z[8,7,5]  R2313     -3.7510967254638672e-01
    z[8,7,5]  R2314     -1.9735524058341980e-01
    z[8,7,5]  R2315     -1.3828532397747040e-01
    z[8,7,5]  R2316     -3.4852313995361328e-01
    z[8,7,5]  R2317     -2.5787869095802307e-01
    z[8,7,5]  R2318     -1.0327735543251038e-01
    z[8,7,5]  R2319     1.2150023831054568e-03
    z[8,7,5]  R2320     -2.3134063184261322e-01
    z[8,7,5]  R2321     4.0065199136734009e-02
    z[8,7,5]  R2322     -5.5110651254653931e-01
    z[8,7,5]  R2323     4.4556212425231934e-01
    z[8,7,5]  R2324     2.4070987105369568e-01
    z[8,7,5]  R2325     -1.0796731710433960e-01
    z[8,7,5]  R2326     2.1233783662319183e-01
    z[8,7,5]  R2327     -1.3205768167972565e-01
    z[8,7,5]  R2328     -2.4533860385417938e-01
    z[8,7,5]  R2329     -3.0848110094666481e-02
    z[8,7,5]  R2330     -1.4587184786796570e-01
    z[8,7,5]  R2331     0.252546489238739
    z[8,7,5]  R2332     -3.6108851432800293e-01
    z[8,7,5]  R2333     1.9542382657527924e-01
    z[8,7,5]  R2334     -2.3221735656261444e-01
    z[8,7,5]  R2335     -3.7104284763336182e-01
    z[8,7,5]  R2336     -4.8415485769510269e-02
    z[8,7,5]  R2337     2.5979939103126526e-01
    z[8,7,5]  R2338     -1.2629453837871552e-01
    z[8,7,5]  R2339     -4.3472938239574432e-02
    z[8,7,5]  R2340     -3.7419281434267759e-03
    z[8,7,5]  R2341     9.2434667050838470e-02
    z[8,7,5]  R2342     -4.2871972918510437e-01
    z[8,7,5]  R2343     -3.3051091432571411e-01
    z[8,7,5]  R2344     3.0744457244873047e-01
    z[8,7,5]  R2345     -1.1734230071306229e-01
    z[8,7,5]  R2346     -6.0735039412975311e-02
    z[8,7,5]  R2347     -4.1593369841575623e-01
    z[8,7,5]  R2348     1.5159327536821365e-02
    z[8,7,5]  R2349     2.9559774324297905e-02
    z[8,7,5]  R2350     -4.1807761788368225e-01
    z[8,7,5]  R2351     5.3183263540267944e-01
    z[8,7,5]  R2352     5.0590906292200089e-02
    z[8,7,5]  R2353     4.6976704150438309e-02
    z[8,7,5]  R2354     -4.1004788875579834e-01
    z[8,7,5]  R2355     -8.0488964915275574e-02
    z[8,7,5]  R2356     -1.3850995898246765e-01
    z[8,7,5]  R2357     1.7445281147956848e-01
    z[8,7,5]  R2358     -3.7980481982231140e-01
    z[8,7,5]  R2359     -0.549176037311554
    z[8,7,5]  R2360     -3.1081077456474304e-01
    z[8,7,5]  R2361     2.7003228664398193e-01
    z[8,7,5]  R2362     -1.6107386350631714e-01
    z[8,7,5]  R2363     -5.5078428983688354e-01
    z[8,7,5]  R2364     -3.1608107686042786e-01
    z[8,7,5]  R2365     -1.7238157987594604e-01
    z[8,7,5]  R2366     -1.0442781448364258e-01
    z[8,7,5]  R2367     2.9218757152557373e-01
    z[8,7,5]  R2368     -4.2967864871025085e-01
    z[8,7,5]  R2369     -1.0896987468004227e-01
    z[8,7,5]  R2370     1.6916318237781525e-01
    z[8,7,5]  R2371     0.0191938616335392
    z[8,7,5]  R2372     8.2310363650321960e-02
    z[8,7,5]  R2373     -2.0744070410728455e-01
    z[8,7,5]  R2374     -1.1092843860387802e-01
    z[8,7,5]  R2375     -1.8518300354480743e-01
    z[8,7,5]  R2376     2.7184817939996719e-02
    z[8,7,5]  R2377     -3.5375106334686279e-01
    z[8,7,5]  R2378     -3.9943951368331909e-01
    z[8,7,5]  R2379     4.8046806454658508e-01
    z[8,7,5]  R2380     -2.3944278061389923e-01
    z[8,7,5]  R2381     -7.0862270891666412e-02
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2220     -1
    z[8,7,6]  R2221     1
    z[8,7,6]  R2222     -9.4628900289535522e-02
    z[8,7,6]  R2223     -8.2821592688560486e-02
    z[8,7,6]  R2224     -3.6194634437561035e-01
    z[8,7,6]  R2225     -1.9311843439936638e-02
    z[8,7,6]  R2226     -2.0924621820449829e-01
    z[8,7,6]  R2227     8.3675451576709747e-02
    z[8,7,6]  R2228     -1.1608625948429108e-01
    z[8,7,6]  R2229     1.6750479117035866e-02
    z[8,7,6]  R2230     -3.5390508174896240e-01
    z[8,7,6]  R2231     2.8072218410670757e-03
    z[8,7,6]  R2232     0.0628654882311821
    z[8,7,6]  R2233     -4.6374088525772095e-01
    z[8,7,6]  R2234     -2.2481869161128998e-01
    z[8,7,6]  R2235     -1.9075348973274231e-01
    z[8,7,6]  R2236     -9.0090613812208176e-03
    z[8,7,6]  R2237     1.7228309810161591e-01
    z[8,7,6]  R2238     3.2534804940223694e-01
    z[8,7,6]  R2239     4.2964923381805420e-01
    z[8,7,6]  R2240     2.0622503757476807e-01
    z[8,7,6]  R2241     4.6970045566558838e-01
    z[8,7,6]  R2242     0.0920991376042366
    z[8,7,6]  R2243     3.9331771433353424e-02
    z[8,7,6]  R2244     1.0742158442735672e-01
    z[8,7,6]  R2245     1.1864091455936432e-01
    z[8,7,6]  R2246     1.3005739450454712e-01
    z[8,7,6]  R2247     -7.7928858809173107e-03
    z[8,7,6]  R2248     -3.4613016992807388e-02
    z[8,7,6]  R2249     2.5950780138373375e-02
    z[8,7,6]  R2250     3.1248387694358826e-01
    z[8,7,6]  R2251     3.6323550343513489e-01
    z[8,7,6]  R2252     2.7429863810539246e-01
    z[8,7,6]  R2253     -1.4621193706989288e-01
    z[8,7,6]  R2254     -1.0429130494594574e-01
    z[8,7,6]  R2255     -2.7589586377143860e-01
    z[8,7,6]  R2256     -2.4740052223205566e-01
    z[8,7,6]  R2257     -3.1327673792839050e-01
    z[8,7,6]  R2258     -3.3595946431159973e-01
    z[8,7,6]  R2259     -2.8496238589286804e-01
    z[8,7,6]  R2260     -3.0465468764305115e-01
    z[8,7,6]  R2261     -1.9501791894435883e-01
    z[8,7,6]  R2262     5.0175851583480835e-01
    z[8,7,6]  R2263     8.3230612799525261e-03
    z[8,7,6]  R2264     2.8687119483947754e-01
    z[8,7,6]  R2265     7.6511144638061523e-02
    z[8,7,6]  R2266     -1.5091150999069214e-01
    z[8,7,6]  R2267     -2.0095384120941162e-01
    z[8,7,6]  R2268     -2.7648857235908508e-01
    z[8,7,6]  R2269     -3.3896368741989136e-01
    z[8,7,6]  R2270     -2.6503643393516541e-01
    z[8,7,6]  R2271     -1.2459450960159302e-01
    z[8,7,6]  R2272     -2.0635235309600830e-01
    z[8,7,6]  R2273     2.2748260200023651e-01
    z[8,7,6]  R2274     1.0516013205051422e-01
    z[8,7,6]  R2275     -3.9368532598018646e-02
    z[8,7,6]  R2276     -3.6459761857986450e-01
    z[8,7,6]  R2277     -2.8335893154144287e-01
    z[8,7,6]  R2278     -5.0444173812866211e-01
    z[8,7,6]  R2279     -1.5931384265422821e-01
    z[8,7,6]  R2280     -5.7740285992622375e-03
    z[8,7,6]  R2281     -2.2962391376495361e-01
    z[8,7,6]  R2282     -1.3790573179721832e-01
    z[8,7,6]  R2283     -1.6364523768424988e-01
    z[8,7,6]  R2284     -8.3632849156856537e-02
    z[8,7,6]  R2285     6.0002632439136505e-02
    z[8,7,6]  R2286     1.8504603207111359e-01
    z[8,7,6]  R2287     -2.1147492527961731e-01
    z[8,7,6]  R2288     1.3096566312015057e-02
    z[8,7,6]  R2289     -2.7766495943069458e-01
    z[8,7,6]  R2290     -8.0890739336609840e-03
    z[8,7,6]  R2291     2.4081563949584961e-01
    z[8,7,6]  R2292     1.4388850331306458e-01
    z[8,7,6]  R2293     5.9924638271331787e-01
    z[8,7,6]  R2294     4.3836173415184021e-01
    z[8,7,6]  R2295     4.5063480734825134e-01
    z[8,7,6]  R2296     1.4219434559345245e-01
    z[8,7,6]  R2297     4.7252067923545837e-01
    z[8,7,6]  R2298     -4.1448645293712616e-02
    z[8,7,6]  R2299     1.7293691635131836e-01
    z[8,7,6]  R2300     2.1829646080732346e-02
    z[8,7,6]  R2301     3.9265986531972885e-02
    z[8,7,6]  R2302     7.6660722494125366e-02
    z[8,7,6]  R2303     -5.6128031015396118e-01
    z[8,7,6]  R2304     4.9747237563133240e-01
    z[8,7,6]  R2305     -4.6390643715858459e-01
    z[8,7,6]  R2306     4.7608932852745056e-01
    z[8,7,6]  R2307     -6.2533393502235413e-02
    z[8,7,6]  R2308     2.1993571519851685e-01
    z[8,7,6]  R2309     3.4372383356094360e-01
    z[8,7,6]  R2310     3.4728819131851196e-01
    z[8,7,6]  R2311     0.255688339471817
    z[8,7,6]  R2312     4.2310228943824768e-01
    z[8,7,6]  R2313     6.8588759750127792e-03
    z[8,7,6]  R2314     2.3477682471275330e-01
    z[8,7,6]  R2315     -4.1881051659584045e-01
    z[8,7,6]  R2316     3.9004996418952942e-01
    z[8,7,6]  R2317     -0.335882306098938
    z[8,7,6]  R2318     -1.6593678295612335e-01
    z[8,7,6]  R2319     2.6671022176742554e-01
    z[8,7,6]  R2320     6.2468592077493668e-03
    z[8,7,6]  R2321     -8.7136939167976379e-02
    z[8,7,6]  R2322     -2.9209271073341370e-01
    z[8,7,6]  R2323     0.44937664270401
    z[8,7,6]  R2324     -9.9995970726013184e-02
    z[8,7,6]  R2325     1.3004487752914429e-01
    z[8,7,6]  R2326     -4.5862618088722229e-01
    z[8,7,6]  R2327     -5.1394551992416382e-01
    z[8,7,6]  R2328     -2.0621180534362793e-01
    z[8,7,6]  R2329     2.0252232253551483e-01
    z[8,7,6]  R2330     -1.0687220841646194e-01
    z[8,7,6]  R2331     -6.3475079834461212e-02
    z[8,7,6]  R2332     -1.4392933249473572e-01
    z[8,7,6]  R2333     3.9627268910408020e-01
    z[8,7,6]  R2334     -1.1192449927330017e-01
    z[8,7,6]  R2335     -1.2898662686347961e-01
    z[8,7,6]  R2336     4.8706603050231934e-01
    z[8,7,6]  R2337     1.6122156381607056e-01
    z[8,7,6]  R2338     -0.574490487575531
    z[8,7,6]  R2339     2.2059172391891479e-02
    z[8,7,6]  R2340     2.1027492359280586e-02
    z[8,7,6]  R2341     -9.4802536070346832e-02
    z[8,7,6]  R2342     -2.5701060891151428e-02
    z[8,7,6]  R2343     -1.7384913563728333e-01
    z[8,7,6]  R2344     0.0712905079126358
    z[8,7,6]  R2345     -2.4445161223411560e-01
    z[8,7,6]  R2346     -4.6912181377410889e-01
    z[8,7,6]  R2347     -2.4328069388866425e-01
    z[8,7,6]  R2348     3.8897043466567993e-01
    z[8,7,6]  R2349     -3.2586455345153809e-01
    z[8,7,6]  R2350     1.1651214212179184e-02
    z[8,7,6]  R2351     1.5964837744832039e-02
    z[8,7,6]  R2352     7.3880054056644440e-02
    z[8,7,6]  R2353     -3.6409109830856323e-02
    z[8,7,6]  R2354     1.9887593388557434e-01
    z[8,7,6]  R2355     2.9521992802619934e-01
    z[8,7,6]  R2356     5.9096522629261017e-02
    z[8,7,6]  R2357     4.5569464564323425e-01
    z[8,7,6]  R2358     -1.0193645209074020e-01
    z[8,7,6]  R2359     -2.6325622200965881e-01
    z[8,7,6]  R2360     5.2250474691390991e-02
    z[8,7,6]  R2361     6.4070552587509155e-02
    z[8,7,6]  R2362     -2.2096963226795197e-01
    z[8,7,6]  R2363     -1.0697133839130402e-01
    z[8,7,6]  R2364     6.6424749791622162e-02
    z[8,7,6]  R2365     -2.0087711513042450e-02
    z[8,7,6]  R2366     2.4833540618419647e-01
    z[8,7,6]  R2367     8.2687549293041229e-02
    z[8,7,6]  R2368     -3.9547204971313477e-01
    z[8,7,6]  R2369     -2.3731590807437897e-01
    z[8,7,6]  R2370     -3.3022749423980713e-01
    z[8,7,6]  R2371     -0.458345502614975
    z[8,7,6]  R2372     4.8635181784629822e-01
    z[8,7,6]  R2373     -2.1411462128162384e-01
    z[8,7,6]  R2374     1.3943125307559967e-01
    z[8,7,6]  R2375     3.0752828717231750e-01
    z[8,7,6]  R2376     1.5022693574428558e-01
    z[8,7,6]  R2377     -6.2335506081581116e-02
    z[8,7,6]  R2378     2.1135514974594116e-01
    z[8,7,6]  R2379     -0.360663503408432
    z[8,7,6]  R2380     6.0167215764522552e-02
    z[8,7,6]  R2381     2.0817078649997711e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R81       1
    RHS1      R82       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[9,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,8]
 BV BND1      phi[8,2]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,8]
 BV BND1      phi[8,3]
 BV BND1      phi[3,10]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[9,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,10]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,8,0]
 FR BND1      z[2,8,1]
 FR BND1      z[2,8,2]
 FR BND1      z[2,8,3]
 FR BND1      z[2,8,4]
 FR BND1      z[2,8,5]
 FR BND1      z[2,8,6]
 FR BND1      z[8,2,0]
 FR BND1      z[8,2,1]
 FR BND1      z[8,2,2]
 FR BND1      z[8,2,3]
 FR BND1      z[8,2,4]
 FR BND1      z[8,2,5]
 FR BND1      z[8,2,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[3,8,0]
 FR BND1      z[3,8,1]
 FR BND1      z[3,8,2]
 FR BND1      z[3,8,3]
 FR BND1      z[3,8,4]
 FR BND1      z[3,8,5]
 FR BND1      z[3,8,6]
 FR BND1      z[8,3,0]
 FR BND1      z[8,3,1]
 FR BND1      z[8,3,2]
 FR BND1      z[8,3,3]
 FR BND1      z[8,3,4]
 FR BND1      z[8,3,5]
 FR BND1      z[8,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
ENDATA
