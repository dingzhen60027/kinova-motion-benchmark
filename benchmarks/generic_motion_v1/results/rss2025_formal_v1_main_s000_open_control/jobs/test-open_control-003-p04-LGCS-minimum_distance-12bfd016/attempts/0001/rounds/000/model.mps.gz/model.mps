NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 E  R46     
 L  R47     
 L  R48     
 L  R49     
 L  R50     
 L  R51     
 L  R52     
 L  R53     
 L  R54     
 L  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 L  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R47       -3.0999999046325684e+00
    phi[0,1]  R48       -3.0999999046325684e+00
    phi[0,1]  R49       -2.2400000095367432e+00
    phi[0,1]  R50       -2.2400000095367432e+00
    phi[0,1]  R51       -3.0999999046325684e+00
    phi[0,1]  R52       -3.0999999046325684e+00
    phi[0,1]  R53       -2.5699999332427979e+00
    phi[0,1]  R54       -2.5699999332427979e+00
    phi[0,1]  R55       -3.0999999046325684e+00
    phi[0,1]  R56       -3.0999999046325684e+00
    phi[0,1]  R57       -2.0899999141693115e+00
    phi[0,1]  R58       -2.0899999141693115e+00
    phi[0,1]  R59       -3.0999999046325684e+00
    phi[0,1]  R60       -3.0999999046325684e+00
    phi[0,1]  R61       2.5974566936492920e+00
    phi[0,1]  R62       2.8682487010955811e+00
    phi[0,1]  R63       1.5820950269699097e+00
    phi[0,1]  R64       2.4137458801269531e+00
    phi[0,1]  R65       2.5813100337982178e+00
    phi[0,1]  R66       3.75659441947937
    phi[0,1]  R67       3.2473025321960449e+00
    phi[0,1]  R68       2.0300309658050537e+00
    phi[0,1]  R69       2.1767852306365967e+00
    phi[0,1]  R70       6.5940797328948975e-01
    phi[0,1]  R71       -2.8619039058685303e+00
    phi[0,1]  R72       -1.8851974010467529e+00
    phi[0,1]  R73       -2.1537461280822754e+00
    phi[0,1]  R74       -2.7427833080291748e+00
    phi[0,1]  R75       -2.2430942058563232e+00
    phi[0,1]  R76       -8.3679038286209106e-01
    phi[0,1]  R77       -2.8003227710723877e+00
    phi[0,1]  R78       -3.1872713565826416e+00
    phi[0,1]  R79       -1.6857606172561646e+00
    phi[0,1]  R80       -3.4221098423004150e+00
    phi[0,1]  R81       2.2263925075531006e+00
    phi[0,1]  R82       1.2524091005325317e+00
    phi[0,1]  R83       -2.5469126701354980e+00
    phi[0,1]  R84       1.2003079801797867e-01
    phi[0,1]  R85       -2.6102342605590820e+00
    phi[0,1]  R86       -2.3584907054901123e+00
    phi[0,1]  R87       -2.1882026195526123e+00
    phi[0,1]  R88       -1.5680531263351440e+00
    phi[0,1]  R89       -3.33258056640625
    phi[0,1]  R90       -1.3866410255432129e+00
    phi[0,1]  R91       -1.5727608203887939e+00
    phi[0,1]  R92       -1.0093477964401245e+00
    phi[0,1]  R93       -1.1689211130142212e+00
    phi[0,1]  R94       -3.2290643453598022e-01
    phi[0,1]  R95       -2.4277734756469727e+00
    phi[0,1]  R96       -1.7736625671386719e+00
    phi[0,1]  R97       -2.0152981281280518e+00
    phi[0,1]  R98       -2.0943448543548584e+00
    phi[0,1]  R99       -1.5062483549118042e+00
    phi[0,1]  R100      -2.6943478584289551e+00
    phi[0,1]  R101      6.0946738719940186e-01
    phi[0,1]  R102      -1.3057361841201782e+00
    phi[0,1]  R103      -1.5625617504119873e+00
    phi[0,1]  R104      -5.9059686958789825e-02
    phi[0,1]  R105      -2.9015748500823975e+00
    phi[0,1]  R106      -2.8699882030487061e+00
    phi[0,1]  R107      -2.1830904483795166e+00
    phi[0,1]  R108      -3.3515632152557373e+00
    phi[0,1]  R109      -2.9988026618957520e+00
    phi[0,1]  R110      -2.9708533287048340e+00
    phi[0,1]  R111      -2.5789287090301514e+00
    phi[0,1]  R112      1.3626056909561157e-01
    phi[0,1]  R113      -6.1639338731765747e-01
    phi[0,1]  R114      -8.9828038215637207e-01
    phi[0,1]  R115      -2.2858147621154785e+00
    phi[0,1]  R116      -1.7517405748367310e+00
    phi[0,1]  R117      -2.6733341217041016e+00
    phi[0,1]  R118      -2.7340774536132812e+00
    phi[0,1]  R119      -1.3700952529907227e+00
    phi[0,1]  R120      -1.6660593748092651e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R121      -3.0999999046325684e+00
    phi[1,0]  R122      -3.0999999046325684e+00
    phi[1,0]  R123      -2.2400000095367432e+00
    phi[1,0]  R124      -2.2400000095367432e+00
    phi[1,0]  R125      -3.0999999046325684e+00
    phi[1,0]  R126      -3.0999999046325684e+00
    phi[1,0]  R127      -2.5699999332427979e+00
    phi[1,0]  R128      -2.5699999332427979e+00
    phi[1,0]  R129      -3.0999999046325684e+00
    phi[1,0]  R130      -3.0999999046325684e+00
    phi[1,0]  R131      -2.0899999141693115e+00
    phi[1,0]  R132      -2.0899999141693115e+00
    phi[1,0]  R133      -3.0999999046325684e+00
    phi[1,0]  R134      -3.0999999046325684e+00
    phi[1,0]  R135      2.2263925075531006e+00
    phi[1,0]  R136      1.2524091005325317e+00
    phi[1,0]  R137      -2.5469126701354980e+00
    phi[1,0]  R138      1.2003079801797867e-01
    phi[1,0]  R139      -2.6102342605590820e+00
    phi[1,0]  R140      -2.3584907054901123e+00
    phi[1,0]  R141      -2.1882026195526123e+00
    phi[1,0]  R142      -1.5680531263351440e+00
    phi[1,0]  R143      -3.33258056640625
    phi[1,0]  R144      -1.3866410255432129e+00
    phi[1,0]  R145      -1.5727608203887939e+00
    phi[1,0]  R146      -1.0093477964401245e+00
    phi[1,0]  R147      -1.1689211130142212e+00
    phi[1,0]  R148      -3.2290643453598022e-01
    phi[1,0]  R149      -2.4277734756469727e+00
    phi[1,0]  R150      -1.7736625671386719e+00
    phi[1,0]  R151      -2.0152981281280518e+00
    phi[1,0]  R152      -2.0943448543548584e+00
    phi[1,0]  R153      -1.5062483549118042e+00
    phi[1,0]  R154      -2.6943478584289551e+00
    phi[1,0]  R155      6.0946738719940186e-01
    phi[1,0]  R156      -1.3057361841201782e+00
    phi[1,0]  R157      -1.5625617504119873e+00
    phi[1,0]  R158      -5.9059686958789825e-02
    phi[1,0]  R159      -2.9015748500823975e+00
    phi[1,0]  R160      -2.8699882030487061e+00
    phi[1,0]  R161      -2.1830904483795166e+00
    phi[1,0]  R162      -3.3515632152557373e+00
    phi[1,0]  R163      -2.9988026618957520e+00
    phi[1,0]  R164      -2.9708533287048340e+00
    phi[1,0]  R165      -2.5789287090301514e+00
    phi[1,0]  R166      1.3626056909561157e-01
    phi[1,0]  R167      -6.1639338731765747e-01
    phi[1,0]  R168      -8.9828038215637207e-01
    phi[1,0]  R169      -2.2858147621154785e+00
    phi[1,0]  R170      -1.7517405748367310e+00
    phi[1,0]  R171      -2.6733341217041016e+00
    phi[1,0]  R172      -2.7340774536132812e+00
    phi[1,0]  R173      -1.3700952529907227e+00
    phi[1,0]  R174      -1.6660593748092651e+00
    phi[1,0]  R175      2.5974566936492920e+00
    phi[1,0]  R176      2.8682487010955811e+00
    phi[1,0]  R177      1.5820950269699097e+00
    phi[1,0]  R178      2.4137458801269531e+00
    phi[1,0]  R179      2.5813100337982178e+00
    phi[1,0]  R180      3.75659441947937
    phi[1,0]  R181      3.2473025321960449e+00
    phi[1,0]  R182      2.0300309658050537e+00
    phi[1,0]  R183      2.1767852306365967e+00
    phi[1,0]  R184      6.5940797328948975e-01
    phi[1,0]  R185      -2.8619039058685303e+00
    phi[1,0]  R186      -1.8851974010467529e+00
    phi[1,0]  R187      -2.1537461280822754e+00
    phi[1,0]  R188      -2.7427833080291748e+00
    phi[1,0]  R189      -2.2430942058563232e+00
    phi[1,0]  R190      -8.3679038286209106e-01
    phi[1,0]  R191      -2.8003227710723877e+00
    phi[1,0]  R192      -3.1872713565826416e+00
    phi[1,0]  R193      -1.6857606172561646e+00
    phi[1,0]  R194      -3.4221098423004150e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R195      -3.0999999046325684e+00
    phi[0,3]  R196      -3.0999999046325684e+00
    phi[0,3]  R197      -2.2400000095367432e+00
    phi[0,3]  R198      -2.2400000095367432e+00
    phi[0,3]  R199      -3.0999999046325684e+00
    phi[0,3]  R200      -3.0999999046325684e+00
    phi[0,3]  R201      -2.5699999332427979e+00
    phi[0,3]  R202      -2.5699999332427979e+00
    phi[0,3]  R203      -3.0999999046325684e+00
    phi[0,3]  R204      -3.0999999046325684e+00
    phi[0,3]  R205      -2.0899999141693115e+00
    phi[0,3]  R206      -2.0899999141693115e+00
    phi[0,3]  R207      -3.0999999046325684e+00
    phi[0,3]  R208      -3.0999999046325684e+00
    phi[0,3]  R209      2.5974566936492920e+00
    phi[0,3]  R210      2.8682487010955811e+00
    phi[0,3]  R211      1.5820950269699097e+00
    phi[0,3]  R212      2.4137458801269531e+00
    phi[0,3]  R213      2.5813100337982178e+00
    phi[0,3]  R214      3.75659441947937
    phi[0,3]  R215      3.2473025321960449e+00
    phi[0,3]  R216      2.0300309658050537e+00
    phi[0,3]  R217      2.1767852306365967e+00
    phi[0,3]  R218      6.5940797328948975e-01
    phi[0,3]  R219      -2.8619039058685303e+00
    phi[0,3]  R220      -1.8851974010467529e+00
    phi[0,3]  R221      -2.1537461280822754e+00
    phi[0,3]  R222      -2.7427833080291748e+00
    phi[0,3]  R223      -2.2430942058563232e+00
    phi[0,3]  R224      -8.3679038286209106e-01
    phi[0,3]  R225      -2.8003227710723877e+00
    phi[0,3]  R226      -3.1872713565826416e+00
    phi[0,3]  R227      -1.6857606172561646e+00
    phi[0,3]  R228      -3.4221098423004150e+00
    phi[0,3]  R229      1.6069425344467163e+00
    phi[0,3]  R230      9.2706519365310669e-01
    phi[0,3]  R231      1.54611074924469
    phi[0,3]  R232      1.3110734224319458e+00
    phi[0,3]  R233      1.1438255310058594e+00
    phi[0,3]  R234      1.9603191614151
    phi[0,3]  R235      1.7324629426002502e-01
    phi[0,3]  R236      9.1675353050231934e-01
    phi[0,3]  R237      -4.1927906870841980e-01
    phi[0,3]  R238      -1.1207662820816040e+00
    phi[0,3]  R239      -6.6371726989746094e-01
    phi[0,3]  R240      -1.1094723939895630e+00
    phi[0,3]  R241      -4.8450121283531189e-01
    phi[0,3]  R242      -9.7202211618423462e-01
    phi[0,3]  R243      -2.5104942321777344e+00
    phi[0,3]  R244      -3.2774178981781006e+00
    phi[0,3]  R245      -2.08794903755188
    phi[0,3]  R246      -1.9125593900680542e+00
    phi[0,3]  R247      -1.8138868808746338e+00
    phi[0,3]  R248      -3.0459187030792236e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R249      -3.0999999046325684e+00
    phi[3,0]  R250      -3.0999999046325684e+00
    phi[3,0]  R251      -2.2400000095367432e+00
    phi[3,0]  R252      -2.2400000095367432e+00
    phi[3,0]  R253      -3.0999999046325684e+00
    phi[3,0]  R254      -3.0999999046325684e+00
    phi[3,0]  R255      -2.5699999332427979e+00
    phi[3,0]  R256      -2.5699999332427979e+00
    phi[3,0]  R257      -3.0999999046325684e+00
    phi[3,0]  R258      -3.0999999046325684e+00
    phi[3,0]  R259      -2.0899999141693115e+00
    phi[3,0]  R260      -2.0899999141693115e+00
    phi[3,0]  R261      -3.0999999046325684e+00
    phi[3,0]  R262      -3.0999999046325684e+00
    phi[3,0]  R263      1.6069425344467163e+00
    phi[3,0]  R264      9.2706519365310669e-01
    phi[3,0]  R265      1.54611074924469
    phi[3,0]  R266      1.3110734224319458e+00
    phi[3,0]  R267      1.1438255310058594e+00
    phi[3,0]  R268      1.9603191614151
    phi[3,0]  R269      1.7324629426002502e-01
    phi[3,0]  R270      9.1675353050231934e-01
    phi[3,0]  R271      -4.1927906870841980e-01
    phi[3,0]  R272      -1.1207662820816040e+00
    phi[3,0]  R273      -6.6371726989746094e-01
    phi[3,0]  R274      -1.1094723939895630e+00
    phi[3,0]  R275      -4.8450121283531189e-01
    phi[3,0]  R276      -9.7202211618423462e-01
    phi[3,0]  R277      -2.5104942321777344e+00
    phi[3,0]  R278      -3.2774178981781006e+00
    phi[3,0]  R279      -2.08794903755188
    phi[3,0]  R280      -1.9125593900680542e+00
    phi[3,0]  R281      -1.8138868808746338e+00
    phi[3,0]  R282      -3.0459187030792236e+00
    phi[3,0]  R283      2.5974566936492920e+00
    phi[3,0]  R284      2.8682487010955811e+00
    phi[3,0]  R285      1.5820950269699097e+00
    phi[3,0]  R286      2.4137458801269531e+00
    phi[3,0]  R287      2.5813100337982178e+00
    phi[3,0]  R288      3.75659441947937
    phi[3,0]  R289      3.2473025321960449e+00
    phi[3,0]  R290      2.0300309658050537e+00
    phi[3,0]  R291      2.1767852306365967e+00
    phi[3,0]  R292      6.5940797328948975e-01
    phi[3,0]  R293      -2.8619039058685303e+00
    phi[3,0]  R294      -1.8851974010467529e+00
    phi[3,0]  R295      -2.1537461280822754e+00
    phi[3,0]  R296      -2.7427833080291748e+00
    phi[3,0]  R297      -2.2430942058563232e+00
    phi[3,0]  R298      -8.3679038286209106e-01
    phi[3,0]  R299      -2.8003227710723877e+00
    phi[3,0]  R300      -3.1872713565826416e+00
    phi[3,0]  R301      -1.6857606172561646e+00
    phi[3,0]  R302      -3.4221098423004150e+00
    phi[5,0]  R0        -1
    phi[5,0]  R2        -2.1742985995609581e+00
    phi[5,0]  R3        -5.7278550663629968e-01
    phi[5,0]  R4        2.0765553714287610e+00
    phi[5,0]  R5        -2.2315018509826006e+00
    phi[5,0]  R6        5.3603954029638556e-01
    phi[5,0]  R7        1.3841513652476629e+00
    phi[5,0]  R8        2.63457743450762
    phi[5,0]  R45       1
    phi[5,0]  R303      -9.2570130507161030e-01
    phi[5,0]  R304      -5.2742985041935260e+00
    phi[5,0]  R305      -1.6672145029004435e+00
    phi[5,0]  R306      -2.8127855161730428e+00
    phi[5,0]  R307      -5.1765552760613289e+00
    phi[5,0]  R308      -1.0234445332038073e+00
    phi[5,0]  R309      -3.3849808226019729e-01
    phi[5,0]  R310      -4.8015017842253984e+00
    phi[5,0]  R311      -3.6360394449289539e+00
    phi[5,0]  R312      -2.5639603643361828e+00
    phi[5,0]  R313      -3.4741512794169744e+00
    phi[5,0]  R314      -7.0584854892164861e-01
    phi[5,0]  R315      -5.7345773391401877e+00
    phi[5,0]  R316      -4.6542247012494853e-01
    phi[5,0]  R317      -3.6014949772978477e-01
    phi[5,0]  R318      -5.3845500155049919e-01
    phi[5,0]  R319      -7.4161647194134206e-01
    phi[5,0]  R320      -1.4694913743102065e+00
    phi[5,0]  R321      -1.7617505935691558e-01
    phi[5,0]  R322      -1.9051604868504235e-01
    phi[5,0]  R323      -1.9878040200726854e-01
    phi[5,0]  R324      -2.4167756406361818e-01
    phi[5,0]  R325      -2.5521850537608781e-01
    phi[5,0]  R326      -2.8092010051200489e-01
    phi[5,0]  R327      -3.7514567755550665e-01
    phi[5,0]  R328      -6.5670142690861422e-01
    phi[5,0]  R329      -1.4359237123471098e+00
    phi[5,0]  R330      -9.8155349226618593e-01
    phi[5,0]  R331      -1.0039008127498361e+00
    phi[5,0]  R332      -1.0875290421009220e+00
    phi[5,0]  R333      -1.7412854815286314e+00
    phi[5,0]  R334      -2.3249454219835122e+00
    phi[5,0]  R335      -1.0868239453215027e+00
    phi[5,0]  R336      -1.1575667450976348e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R337      -3.0999999046325684e+00
    phi[1,2]  R338      -3.0999999046325684e+00
    phi[1,2]  R339      -2.2400000095367432e+00
    phi[1,2]  R340      -2.2400000095367432e+00
    phi[1,2]  R341      -3.0999999046325684e+00
    phi[1,2]  R342      -3.0999999046325684e+00
    phi[1,2]  R343      -2.5699999332427979e+00
    phi[1,2]  R344      -2.5699999332427979e+00
    phi[1,2]  R345      -3.0999999046325684e+00
    phi[1,2]  R346      -3.0999999046325684e+00
    phi[1,2]  R347      -2.0899999141693115e+00
    phi[1,2]  R348      -2.0899999141693115e+00
    phi[1,2]  R349      -3.0999999046325684e+00
    phi[1,2]  R350      -3.0999999046325684e+00
    phi[1,2]  R351      2.2263925075531006e+00
    phi[1,2]  R352      1.2524091005325317e+00
    phi[1,2]  R353      -2.5469126701354980e+00
    phi[1,2]  R354      1.2003079801797867e-01
    phi[1,2]  R355      -2.6102342605590820e+00
    phi[1,2]  R356      -2.3584907054901123e+00
    phi[1,2]  R357      -2.1882026195526123e+00
    phi[1,2]  R358      -1.5680531263351440e+00
    phi[1,2]  R359      -3.33258056640625
    phi[1,2]  R360      -1.3866410255432129e+00
    phi[1,2]  R361      -1.5727608203887939e+00
    phi[1,2]  R362      -1.0093477964401245e+00
    phi[1,2]  R363      -1.1689211130142212e+00
    phi[1,2]  R364      -3.2290643453598022e-01
    phi[1,2]  R365      -2.4277734756469727e+00
    phi[1,2]  R366      -1.7736625671386719e+00
    phi[1,2]  R367      -2.0152981281280518e+00
    phi[1,2]  R368      -2.0943448543548584e+00
    phi[1,2]  R369      -1.5062483549118042e+00
    phi[1,2]  R370      -2.6943478584289551e+00
    phi[1,2]  R371      6.0946738719940186e-01
    phi[1,2]  R372      -1.3057361841201782e+00
    phi[1,2]  R373      -1.5625617504119873e+00
    phi[1,2]  R374      -5.9059686958789825e-02
    phi[1,2]  R375      -2.9015748500823975e+00
    phi[1,2]  R376      -2.8699882030487061e+00
    phi[1,2]  R377      -2.1830904483795166e+00
    phi[1,2]  R378      -3.3515632152557373e+00
    phi[1,2]  R379      -2.9988026618957520e+00
    phi[1,2]  R380      -2.9708533287048340e+00
    phi[1,2]  R381      -2.5789287090301514e+00
    phi[1,2]  R382      1.3626056909561157e-01
    phi[1,2]  R383      -6.1639338731765747e-01
    phi[1,2]  R384      -8.9828038215637207e-01
    phi[1,2]  R385      -2.2858147621154785e+00
    phi[1,2]  R386      -1.7517405748367310e+00
    phi[1,2]  R387      -2.6733341217041016e+00
    phi[1,2]  R388      -2.7340774536132812e+00
    phi[1,2]  R389      -1.3700952529907227e+00
    phi[1,2]  R390      -1.6660593748092651e+00
    phi[1,2]  R391      6.4559715986251831e-01
    phi[1,2]  R392      4.5916372537612915e-01
    phi[1,2]  R393      4.8055320978164673e-01
    phi[1,2]  R394      3.7455520033836365e-01
    phi[1,2]  R395      -8.3785879611968994e-01
    phi[1,2]  R396      -5.9451079368591309e-01
    phi[1,2]  R397      -4.7600808739662170e-01
    phi[1,2]  R398      2.7148500084877014e-01
    phi[1,2]  R399      0.1130366101861
    phi[1,2]  R400      -6.6303676366806030e-01
    phi[1,2]  R401      -8.0951493978500366e-01
    phi[1,2]  R402      -2.5891476869583130e-01
    phi[1,2]  R403      -8.0352711677551270e-01
    phi[1,2]  R404      -1.8874228000640869e+00
    phi[1,2]  R405      -2.5974180698394775e+00
    phi[1,2]  R406      -2.6128213405609131e+00
    phi[1,2]  R407      -2.2439148426055908e+00
    phi[1,2]  R408      -2.1159431934356689e+00
    phi[1,2]  R409      -1.8922260999679565e+00
    phi[1,2]  R410      -3.0244784355163574e+00
    phi[1,2]  R411      -2.2940292358398438e+00
    phi[1,2]  R412      -2.0555188655853271e+00
    phi[1,2]  R413      -2.8691885471343994e+00
    phi[1,2]  R414      -2.3858044147491455e+00
    phi[1,2]  R415      -1.83588445186615
    phi[1,2]  R416      -2.6945152282714844e+00
    phi[1,2]  R417      -1.7065685987472534e+00
    phi[1,2]  R418      -1.6010600328445435e+00
    phi[1,2]  R419      -3.0781605243682861e+00
    phi[1,2]  R420      -1.8596018552780151e+00
    phi[1,2]  R421      -2.9251022338867188e+00
    phi[1,2]  R422      -1.5946084260940552e+00
    phi[1,2]  R423      -1.9536197185516357e+00
    phi[1,2]  R424      -1.9141073226928711e+00
    phi[1,2]  R425      -1.9262479543685913e+00
    phi[1,2]  R426      -4.0857315063476562e+00
    phi[1,2]  R427      -1.6861816644668579e+00
    phi[1,2]  R428      -2.1007082462310791e+00
    phi[1,2]  R429      -2.0144200325012207e+00
    phi[1,2]  R430      -2.2645723819732666e+00
    phi[1,2]  R431      -2.7373936772346497e-01
    phi[1,2]  R432      -1.9503599405288696e+00
    phi[1,2]  R433      -2.9933021068573
    phi[1,2]  R434      -3.1349010467529297e+00
    phi[1,2]  R435      -3.3092114925384521e+00
    phi[1,2]  R436      -1.6174052953720093e+00
    phi[1,2]  R437      -2.9014217853546143e+00
    phi[1,2]  R438      -1.8061344623565674e+00
    phi[1,2]  R439      -1.6370401382446289e+00
    phi[1,2]  R440      -1.9503235816955566e+00
    phi[1,2]  R441      -5.5120462179183960e-01
    phi[1,2]  R442      -3.0070440769195557e+00
    phi[1,2]  R443      -2.7877635955810547e+00
    phi[1,2]  R444      -1.4084955453872681e+00
    phi[1,2]  R445      -1.5117737054824829e+00
    phi[1,2]  R446      -2.2070262432098389e+00
    phi[1,2]  R447      -3.2820637226104736e+00
    phi[1,2]  R448      -2.2329647541046143e+00
    phi[1,2]  R449      -3.5413296222686768e+00
    phi[1,2]  R450      -2.0176897048950195e+00
    phi[1,2]  R451      -1.2447081804275513e+00
    phi[1,2]  R452      -2.1725103855133057e+00
    phi[1,2]  R453      -2.3181962966918945e+00
    phi[1,2]  R454      -2.5905840396881104e+00
    phi[1,2]  R455      -7.7069085836410522e-01
    phi[1,2]  R456      -2.6716580390930176e+00
    phi[1,2]  R457      -1.9927949905395508e+00
    phi[1,2]  R458      -2.7345507144927979e+00
    phi[1,2]  R459      -2.5340874195098877e+00
    phi[1,2]  R460      -2.4101488590240479e+00
    phi[1,2]  R461      -6.7530745267868042e-01
    phi[1,2]  R462      -0.331532746553421
    phi[1,2]  R463      -7.1518331766128540e-01
    phi[1,2]  R464      -2.2097387313842773e+00
    phi[1,2]  R465      -0.188564270734787
    phi[1,2]  R466      -2.9340455532073975e+00
    phi[1,2]  R467      -1.7658981084823608e+00
    phi[1,2]  R468      -2.3129115104675293e+00
    phi[1,2]  R469      -2.0004968643188477e+00
    phi[1,2]  R470      -1.6520259380340576e+00
    phi[1,2]  R471      -7.0179396867752075e-01
    phi[1,2]  R472      -1.9338485598564148e-01
    phi[1,2]  R473      -2.3957686424255371e+00
    phi[1,2]  R474      -2.3699812889099121e+00
    phi[1,2]  R475      -1.0914878845214844e+00
    phi[1,2]  R476      -1.7712409496307373e+00
    phi[1,2]  R477      -1.6024928092956543e+00
    phi[1,2]  R478      -2.2782316207885742e+00
    phi[1,2]  R479      -2.4188754558563232e+00
    phi[1,2]  R480      -3.0373599529266357e+00
    phi[1,2]  R481      -3.9094531536102295e-01
    phi[1,2]  R482      -7.3785686492919922e-01
    phi[1,2]  R483      -1.5853306055068970e+00
    phi[1,2]  R484      -2.5782127380371094e+00
    phi[1,2]  R485      -2.3790390491485596e+00
    phi[1,2]  R486      -2.4555022716522217e+00
    phi[1,2]  R487      -2.4904663562774658e+00
    phi[1,2]  R488      -1.7184319496154785e+00
    phi[1,2]  R489      -1.9494717121124268e+00
    phi[1,2]  R490      -2.0469899177551270e+00
    phi[1,2]  R491      -3.7546166777610779e-01
    phi[1,2]  R492      -2.7554972171783447e+00
    phi[1,2]  R493      -2.0122954845428467e+00
    phi[1,2]  R494      -2.4201695919036865e+00
    phi[1,2]  R495      -1.6185218095779419e+00
    phi[1,2]  R496      -1.2893269062042236e+00
    phi[1,2]  R497      -1.2469331026077271e+00
    phi[1,2]  R498      -1.6163178682327271e+00
    phi[1,2]  R499      -2.6959180831909180e+00
    phi[1,2]  R500      -1.1794676780700684e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R501      -3.0999999046325684e+00
    phi[2,1]  R502      -3.0999999046325684e+00
    phi[2,1]  R503      -2.2400000095367432e+00
    phi[2,1]  R504      -2.2400000095367432e+00
    phi[2,1]  R505      -3.0999999046325684e+00
    phi[2,1]  R506      -3.0999999046325684e+00
    phi[2,1]  R507      -2.5699999332427979e+00
    phi[2,1]  R508      -2.5699999332427979e+00
    phi[2,1]  R509      -3.0999999046325684e+00
    phi[2,1]  R510      -3.0999999046325684e+00
    phi[2,1]  R511      -2.0899999141693115e+00
    phi[2,1]  R512      -2.0899999141693115e+00
    phi[2,1]  R513      -3.0999999046325684e+00
    phi[2,1]  R514      -3.0999999046325684e+00
    phi[2,1]  R515      6.4559715986251831e-01
    phi[2,1]  R516      4.5916372537612915e-01
    phi[2,1]  R517      4.8055320978164673e-01
    phi[2,1]  R518      3.7455520033836365e-01
    phi[2,1]  R519      -8.3785879611968994e-01
    phi[2,1]  R520      -5.9451079368591309e-01
    phi[2,1]  R521      -4.7600808739662170e-01
    phi[2,1]  R522      2.7148500084877014e-01
    phi[2,1]  R523      0.1130366101861
    phi[2,1]  R524      -6.6303676366806030e-01
    phi[2,1]  R525      -8.0951493978500366e-01
    phi[2,1]  R526      -2.5891476869583130e-01
    phi[2,1]  R527      -8.0352711677551270e-01
    phi[2,1]  R528      -1.8874228000640869e+00
    phi[2,1]  R529      -2.5974180698394775e+00
    phi[2,1]  R530      -2.6128213405609131e+00
    phi[2,1]  R531      -2.2439148426055908e+00
    phi[2,1]  R532      -2.1159431934356689e+00
    phi[2,1]  R533      -1.8922260999679565e+00
    phi[2,1]  R534      -3.0244784355163574e+00
    phi[2,1]  R535      -2.2940292358398438e+00
    phi[2,1]  R536      -2.0555188655853271e+00
    phi[2,1]  R537      -2.8691885471343994e+00
    phi[2,1]  R538      -2.3858044147491455e+00
    phi[2,1]  R539      -1.83588445186615
    phi[2,1]  R540      -2.6945152282714844e+00
    phi[2,1]  R541      -1.7065685987472534e+00
    phi[2,1]  R542      -1.6010600328445435e+00
    phi[2,1]  R543      -3.0781605243682861e+00
    phi[2,1]  R544      -1.8596018552780151e+00
    phi[2,1]  R545      -2.9251022338867188e+00
    phi[2,1]  R546      -1.5946084260940552e+00
    phi[2,1]  R547      -1.9536197185516357e+00
    phi[2,1]  R548      -1.9141073226928711e+00
    phi[2,1]  R549      -1.9262479543685913e+00
    phi[2,1]  R550      -4.0857315063476562e+00
    phi[2,1]  R551      -1.6861816644668579e+00
    phi[2,1]  R552      -2.1007082462310791e+00
    phi[2,1]  R553      -2.0144200325012207e+00
    phi[2,1]  R554      -2.2645723819732666e+00
    phi[2,1]  R555      -2.7373936772346497e-01
    phi[2,1]  R556      -1.9503599405288696e+00
    phi[2,1]  R557      -2.9933021068573
    phi[2,1]  R558      -3.1349010467529297e+00
    phi[2,1]  R559      -3.3092114925384521e+00
    phi[2,1]  R560      -1.6174052953720093e+00
    phi[2,1]  R561      -2.9014217853546143e+00
    phi[2,1]  R562      -1.8061344623565674e+00
    phi[2,1]  R563      -1.6370401382446289e+00
    phi[2,1]  R564      -1.9503235816955566e+00
    phi[2,1]  R565      -5.5120462179183960e-01
    phi[2,1]  R566      -3.0070440769195557e+00
    phi[2,1]  R567      -2.7877635955810547e+00
    phi[2,1]  R568      -1.4084955453872681e+00
    phi[2,1]  R569      -1.5117737054824829e+00
    phi[2,1]  R570      -2.2070262432098389e+00
    phi[2,1]  R571      -3.2820637226104736e+00
    phi[2,1]  R572      -2.2329647541046143e+00
    phi[2,1]  R573      -3.5413296222686768e+00
    phi[2,1]  R574      -2.0176897048950195e+00
    phi[2,1]  R575      -1.2447081804275513e+00
    phi[2,1]  R576      -2.1725103855133057e+00
    phi[2,1]  R577      -2.3181962966918945e+00
    phi[2,1]  R578      -2.5905840396881104e+00
    phi[2,1]  R579      -7.7069085836410522e-01
    phi[2,1]  R580      -2.6716580390930176e+00
    phi[2,1]  R581      -1.9927949905395508e+00
    phi[2,1]  R582      -2.7345507144927979e+00
    phi[2,1]  R583      -2.5340874195098877e+00
    phi[2,1]  R584      -2.4101488590240479e+00
    phi[2,1]  R585      -6.7530745267868042e-01
    phi[2,1]  R586      -0.331532746553421
    phi[2,1]  R587      -7.1518331766128540e-01
    phi[2,1]  R588      -2.2097387313842773e+00
    phi[2,1]  R589      -0.188564270734787
    phi[2,1]  R590      -2.9340455532073975e+00
    phi[2,1]  R591      -1.7658981084823608e+00
    phi[2,1]  R592      -2.3129115104675293e+00
    phi[2,1]  R593      -2.0004968643188477e+00
    phi[2,1]  R594      -1.6520259380340576e+00
    phi[2,1]  R595      -7.0179396867752075e-01
    phi[2,1]  R596      -1.9338485598564148e-01
    phi[2,1]  R597      -2.3957686424255371e+00
    phi[2,1]  R598      -2.3699812889099121e+00
    phi[2,1]  R599      -1.0914878845214844e+00
    phi[2,1]  R600      -1.7712409496307373e+00
    phi[2,1]  R601      -1.6024928092956543e+00
    phi[2,1]  R602      -2.2782316207885742e+00
    phi[2,1]  R603      -2.4188754558563232e+00
    phi[2,1]  R604      -3.0373599529266357e+00
    phi[2,1]  R605      -3.9094531536102295e-01
    phi[2,1]  R606      -7.3785686492919922e-01
    phi[2,1]  R607      -1.5853306055068970e+00
    phi[2,1]  R608      -2.5782127380371094e+00
    phi[2,1]  R609      -2.3790390491485596e+00
    phi[2,1]  R610      -2.4555022716522217e+00
    phi[2,1]  R611      -2.4904663562774658e+00
    phi[2,1]  R612      -1.7184319496154785e+00
    phi[2,1]  R613      -1.9494717121124268e+00
    phi[2,1]  R614      -2.0469899177551270e+00
    phi[2,1]  R615      -3.7546166777610779e-01
    phi[2,1]  R616      -2.7554972171783447e+00
    phi[2,1]  R617      -2.0122954845428467e+00
    phi[2,1]  R618      -2.4201695919036865e+00
    phi[2,1]  R619      -1.6185218095779419e+00
    phi[2,1]  R620      -1.2893269062042236e+00
    phi[2,1]  R621      -1.2469331026077271e+00
    phi[2,1]  R622      -1.6163178682327271e+00
    phi[2,1]  R623      -2.6959180831909180e+00
    phi[2,1]  R624      -1.1794676780700684e+00
    phi[2,1]  R625      2.2263925075531006e+00
    phi[2,1]  R626      1.2524091005325317e+00
    phi[2,1]  R627      -2.5469126701354980e+00
    phi[2,1]  R628      1.2003079801797867e-01
    phi[2,1]  R629      -2.6102342605590820e+00
    phi[2,1]  R630      -2.3584907054901123e+00
    phi[2,1]  R631      -2.1882026195526123e+00
    phi[2,1]  R632      -1.5680531263351440e+00
    phi[2,1]  R633      -3.33258056640625
    phi[2,1]  R634      -1.3866410255432129e+00
    phi[2,1]  R635      -1.5727608203887939e+00
    phi[2,1]  R636      -1.0093477964401245e+00
    phi[2,1]  R637      -1.1689211130142212e+00
    phi[2,1]  R638      -3.2290643453598022e-01
    phi[2,1]  R639      -2.4277734756469727e+00
    phi[2,1]  R640      -1.7736625671386719e+00
    phi[2,1]  R641      -2.0152981281280518e+00
    phi[2,1]  R642      -2.0943448543548584e+00
    phi[2,1]  R643      -1.5062483549118042e+00
    phi[2,1]  R644      -2.6943478584289551e+00
    phi[2,1]  R645      6.0946738719940186e-01
    phi[2,1]  R646      -1.3057361841201782e+00
    phi[2,1]  R647      -1.5625617504119873e+00
    phi[2,1]  R648      -5.9059686958789825e-02
    phi[2,1]  R649      -2.9015748500823975e+00
    phi[2,1]  R650      -2.8699882030487061e+00
    phi[2,1]  R651      -2.1830904483795166e+00
    phi[2,1]  R652      -3.3515632152557373e+00
    phi[2,1]  R653      -2.9988026618957520e+00
    phi[2,1]  R654      -2.9708533287048340e+00
    phi[2,1]  R655      -2.5789287090301514e+00
    phi[2,1]  R656      1.3626056909561157e-01
    phi[2,1]  R657      -6.1639338731765747e-01
    phi[2,1]  R658      -8.9828038215637207e-01
    phi[2,1]  R659      -2.2858147621154785e+00
    phi[2,1]  R660      -1.7517405748367310e+00
    phi[2,1]  R661      -2.6733341217041016e+00
    phi[2,1]  R662      -2.7340774536132812e+00
    phi[2,1]  R663      -1.3700952529907227e+00
    phi[2,1]  R664      -1.6660593748092651e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R665      -3.0999999046325684e+00
    phi[1,3]  R666      -3.0999999046325684e+00
    phi[1,3]  R667      -2.2400000095367432e+00
    phi[1,3]  R668      -2.2400000095367432e+00
    phi[1,3]  R669      -3.0999999046325684e+00
    phi[1,3]  R670      -3.0999999046325684e+00
    phi[1,3]  R671      -2.5699999332427979e+00
    phi[1,3]  R672      -2.5699999332427979e+00
    phi[1,3]  R673      -3.0999999046325684e+00
    phi[1,3]  R674      -3.0999999046325684e+00
    phi[1,3]  R675      -2.0899999141693115e+00
    phi[1,3]  R676      -2.0899999141693115e+00
    phi[1,3]  R677      -3.0999999046325684e+00
    phi[1,3]  R678      -3.0999999046325684e+00
    phi[1,3]  R679      2.2263925075531006e+00
    phi[1,3]  R680      1.2524091005325317e+00
    phi[1,3]  R681      -2.5469126701354980e+00
    phi[1,3]  R682      1.2003079801797867e-01
    phi[1,3]  R683      -2.6102342605590820e+00
    phi[1,3]  R684      -2.3584907054901123e+00
    phi[1,3]  R685      -2.1882026195526123e+00
    phi[1,3]  R686      -1.5680531263351440e+00
    phi[1,3]  R687      -3.33258056640625
    phi[1,3]  R688      -1.3866410255432129e+00
    phi[1,3]  R689      -1.5727608203887939e+00
    phi[1,3]  R690      -1.0093477964401245e+00
    phi[1,3]  R691      -1.1689211130142212e+00
    phi[1,3]  R692      -3.2290643453598022e-01
    phi[1,3]  R693      -2.4277734756469727e+00
    phi[1,3]  R694      -1.7736625671386719e+00
    phi[1,3]  R695      -2.0152981281280518e+00
    phi[1,3]  R696      -2.0943448543548584e+00
    phi[1,3]  R697      -1.5062483549118042e+00
    phi[1,3]  R698      -2.6943478584289551e+00
    phi[1,3]  R699      6.0946738719940186e-01
    phi[1,3]  R700      -1.3057361841201782e+00
    phi[1,3]  R701      -1.5625617504119873e+00
    phi[1,3]  R702      -5.9059686958789825e-02
    phi[1,3]  R703      -2.9015748500823975e+00
    phi[1,3]  R704      -2.8699882030487061e+00
    phi[1,3]  R705      -2.1830904483795166e+00
    phi[1,3]  R706      -3.3515632152557373e+00
    phi[1,3]  R707      -2.9988026618957520e+00
    phi[1,3]  R708      -2.9708533287048340e+00
    phi[1,3]  R709      -2.5789287090301514e+00
    phi[1,3]  R710      1.3626056909561157e-01
    phi[1,3]  R711      -6.1639338731765747e-01
    phi[1,3]  R712      -8.9828038215637207e-01
    phi[1,3]  R713      -2.2858147621154785e+00
    phi[1,3]  R714      -1.7517405748367310e+00
    phi[1,3]  R715      -2.6733341217041016e+00
    phi[1,3]  R716      -2.7340774536132812e+00
    phi[1,3]  R717      -1.3700952529907227e+00
    phi[1,3]  R718      -1.6660593748092651e+00
    phi[1,3]  R719      1.6069425344467163e+00
    phi[1,3]  R720      9.2706519365310669e-01
    phi[1,3]  R721      1.54611074924469
    phi[1,3]  R722      1.3110734224319458e+00
    phi[1,3]  R723      1.1438255310058594e+00
    phi[1,3]  R724      1.9603191614151
    phi[1,3]  R725      1.7324629426002502e-01
    phi[1,3]  R726      9.1675353050231934e-01
    phi[1,3]  R727      -4.1927906870841980e-01
    phi[1,3]  R728      -1.1207662820816040e+00
    phi[1,3]  R729      -6.6371726989746094e-01
    phi[1,3]  R730      -1.1094723939895630e+00
    phi[1,3]  R731      -4.8450121283531189e-01
    phi[1,3]  R732      -9.7202211618423462e-01
    phi[1,3]  R733      -2.5104942321777344e+00
    phi[1,3]  R734      -3.2774178981781006e+00
    phi[1,3]  R735      -2.08794903755188
    phi[1,3]  R736      -1.9125593900680542e+00
    phi[1,3]  R737      -1.8138868808746338e+00
    phi[1,3]  R738      -3.0459187030792236e+00
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R739      -3.0999999046325684e+00
    phi[3,1]  R740      -3.0999999046325684e+00
    phi[3,1]  R741      -2.2400000095367432e+00
    phi[3,1]  R742      -2.2400000095367432e+00
    phi[3,1]  R743      -3.0999999046325684e+00
    phi[3,1]  R744      -3.0999999046325684e+00
    phi[3,1]  R745      -2.5699999332427979e+00
    phi[3,1]  R746      -2.5699999332427979e+00
    phi[3,1]  R747      -3.0999999046325684e+00
    phi[3,1]  R748      -3.0999999046325684e+00
    phi[3,1]  R749      -2.0899999141693115e+00
    phi[3,1]  R750      -2.0899999141693115e+00
    phi[3,1]  R751      -3.0999999046325684e+00
    phi[3,1]  R752      -3.0999999046325684e+00
    phi[3,1]  R753      1.6069425344467163e+00
    phi[3,1]  R754      9.2706519365310669e-01
    phi[3,1]  R755      1.54611074924469
    phi[3,1]  R756      1.3110734224319458e+00
    phi[3,1]  R757      1.1438255310058594e+00
    phi[3,1]  R758      1.9603191614151
    phi[3,1]  R759      1.7324629426002502e-01
    phi[3,1]  R760      9.1675353050231934e-01
    phi[3,1]  R761      -4.1927906870841980e-01
    phi[3,1]  R762      -1.1207662820816040e+00
    phi[3,1]  R763      -6.6371726989746094e-01
    phi[3,1]  R764      -1.1094723939895630e+00
    phi[3,1]  R765      -4.8450121283531189e-01
    phi[3,1]  R766      -9.7202211618423462e-01
    phi[3,1]  R767      -2.5104942321777344e+00
    phi[3,1]  R768      -3.2774178981781006e+00
    phi[3,1]  R769      -2.08794903755188
    phi[3,1]  R770      -1.9125593900680542e+00
    phi[3,1]  R771      -1.8138868808746338e+00
    phi[3,1]  R772      -3.0459187030792236e+00
    phi[3,1]  R773      2.2263925075531006e+00
    phi[3,1]  R774      1.2524091005325317e+00
    phi[3,1]  R775      -2.5469126701354980e+00
    phi[3,1]  R776      1.2003079801797867e-01
    phi[3,1]  R777      -2.6102342605590820e+00
    phi[3,1]  R778      -2.3584907054901123e+00
    phi[3,1]  R779      -2.1882026195526123e+00
    phi[3,1]  R780      -1.5680531263351440e+00
    phi[3,1]  R781      -3.33258056640625
    phi[3,1]  R782      -1.3866410255432129e+00
    phi[3,1]  R783      -1.5727608203887939e+00
    phi[3,1]  R784      -1.0093477964401245e+00
    phi[3,1]  R785      -1.1689211130142212e+00
    phi[3,1]  R786      -3.2290643453598022e-01
    phi[3,1]  R787      -2.4277734756469727e+00
    phi[3,1]  R788      -1.7736625671386719e+00
    phi[3,1]  R789      -2.0152981281280518e+00
    phi[3,1]  R790      -2.0943448543548584e+00
    phi[3,1]  R791      -1.5062483549118042e+00
    phi[3,1]  R792      -2.6943478584289551e+00
    phi[3,1]  R793      6.0946738719940186e-01
    phi[3,1]  R794      -1.3057361841201782e+00
    phi[3,1]  R795      -1.5625617504119873e+00
    phi[3,1]  R796      -5.9059686958789825e-02
    phi[3,1]  R797      -2.9015748500823975e+00
    phi[3,1]  R798      -2.8699882030487061e+00
    phi[3,1]  R799      -2.1830904483795166e+00
    phi[3,1]  R800      -3.3515632152557373e+00
    phi[3,1]  R801      -2.9988026618957520e+00
    phi[3,1]  R802      -2.9708533287048340e+00
    phi[3,1]  R803      -2.5789287090301514e+00
    phi[3,1]  R804      1.3626056909561157e-01
    phi[3,1]  R805      -6.1639338731765747e-01
    phi[3,1]  R806      -8.9828038215637207e-01
    phi[3,1]  R807      -2.2858147621154785e+00
    phi[3,1]  R808      -1.7517405748367310e+00
    phi[3,1]  R809      -2.6733341217041016e+00
    phi[3,1]  R810      -2.7340774536132812e+00
    phi[3,1]  R811      -1.3700952529907227e+00
    phi[3,1]  R812      -1.6660593748092651e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R813      -3.0999999046325684e+00
    phi[1,4]  R814      -3.0999999046325684e+00
    phi[1,4]  R815      -2.2400000095367432e+00
    phi[1,4]  R816      -2.2400000095367432e+00
    phi[1,4]  R817      -3.0999999046325684e+00
    phi[1,4]  R818      -3.0999999046325684e+00
    phi[1,4]  R819      -2.5699999332427979e+00
    phi[1,4]  R820      -2.5699999332427979e+00
    phi[1,4]  R821      -3.0999999046325684e+00
    phi[1,4]  R822      -3.0999999046325684e+00
    phi[1,4]  R823      -2.0899999141693115e+00
    phi[1,4]  R824      -2.0899999141693115e+00
    phi[1,4]  R825      -3.0999999046325684e+00
    phi[1,4]  R826      -3.0999999046325684e+00
    phi[1,4]  R827      2.2263925075531006e+00
    phi[1,4]  R828      1.2524091005325317e+00
    phi[1,4]  R829      -2.5469126701354980e+00
    phi[1,4]  R830      1.2003079801797867e-01
    phi[1,4]  R831      -2.6102342605590820e+00
    phi[1,4]  R832      -2.3584907054901123e+00
    phi[1,4]  R833      -2.1882026195526123e+00
    phi[1,4]  R834      -1.5680531263351440e+00
    phi[1,4]  R835      -3.33258056640625
    phi[1,4]  R836      -1.3866410255432129e+00
    phi[1,4]  R837      -1.5727608203887939e+00
    phi[1,4]  R838      -1.0093477964401245e+00
    phi[1,4]  R839      -1.1689211130142212e+00
    phi[1,4]  R840      -3.2290643453598022e-01
    phi[1,4]  R841      -2.4277734756469727e+00
    phi[1,4]  R842      -1.7736625671386719e+00
    phi[1,4]  R843      -2.0152981281280518e+00
    phi[1,4]  R844      -2.0943448543548584e+00
    phi[1,4]  R845      -1.5062483549118042e+00
    phi[1,4]  R846      -2.6943478584289551e+00
    phi[1,4]  R847      6.0946738719940186e-01
    phi[1,4]  R848      -1.3057361841201782e+00
    phi[1,4]  R849      -1.5625617504119873e+00
    phi[1,4]  R850      -5.9059686958789825e-02
    phi[1,4]  R851      -2.9015748500823975e+00
    phi[1,4]  R852      -2.8699882030487061e+00
    phi[1,4]  R853      -2.1830904483795166e+00
    phi[1,4]  R854      -3.3515632152557373e+00
    phi[1,4]  R855      -2.9988026618957520e+00
    phi[1,4]  R856      -2.9708533287048340e+00
    phi[1,4]  R857      -2.5789287090301514e+00
    phi[1,4]  R858      1.3626056909561157e-01
    phi[1,4]  R859      -6.1639338731765747e-01
    phi[1,4]  R860      -8.9828038215637207e-01
    phi[1,4]  R861      -2.2858147621154785e+00
    phi[1,4]  R862      -1.7517405748367310e+00
    phi[1,4]  R863      -2.6733341217041016e+00
    phi[1,4]  R864      -2.7340774536132812e+00
    phi[1,4]  R865      -1.3700952529907227e+00
    phi[1,4]  R866      -1.6660593748092651e+00
    phi[1,4]  R867      2.2276818752288818e-01
    phi[1,4]  R868      3.7029001861810684e-02
    phi[1,4]  R869      -2.7402403950691223e-01
    phi[1,4]  R870      3.3768272399902344e-01
    phi[1,4]  R871      -0.558380126953125
    phi[1,4]  R872      3.6144825816154480e-01
    phi[1,4]  R873      4.7950321435928345e-01
    phi[1,4]  R874      5.3239285945892334e-01
    phi[1,4]  R875      5.2750366926193237e-01
    phi[1,4]  R876      9.3263971805572510e-01
    phi[1,4]  R877      -2.5645124912261963e+00
    phi[1,4]  R878      -2.4623322486877441e+00
    phi[1,4]  R879      -3.0082054138183594e+00
    phi[1,4]  R880      -1.0090082883834839e+00
    phi[1,4]  R881      -8.9040565490722656e-01
    phi[1,4]  R882      -2.1642878055572510e+00
    phi[1,4]  R883      -1.7568511962890625e+00
    phi[1,4]  R884      -1.8405609130859375e+00
    phi[1,4]  R885      -1.9483366012573242e+00
    phi[1,4]  R886      -2.1683411598205566e+00
    phi[1,4]  R887      -4.9423295259475708e-01
    phi[1,4]  R888      -2.1395049095153809e+00
    phi[1,4]  R889      -2.1951858997344971e+00
    phi[1,4]  R890      -2.07004714012146
    phi[1,4]  R891      -1.8361315727233887e+00
    phi[1,4]  R892      -7.6896792650222778e-01
    phi[1,4]  R893      -2.8638944625854492e+00
    phi[1,4]  R894      -2.5256137847900391e+00
    phi[1,4]  R895      -9.4713938236236572e-01
    phi[1,4]  R896      -2.1351103782653809e+00
    phi[1,4]  R897      -1.8661818504333496e+00
    phi[1,4]  R898      -1.5981520414352417e+00
    phi[1,4]  R899      -2.0402641296386719e+00
    phi[1,4]  R900      -1.1748509407043457e+00
    phi[1,4]  R901      -2.0496413707733154e+00
    phi[1,4]  R902      -2.5082964897155762e+00
    phi[1,4]  R903      -2.4169750213623047e+00
    phi[1,4]  R904      -2.3393447399139404e+00
    phi[1,4]  R905      -1.4505541324615479e+00
    phi[1,4]  R906      -6.0002660751342773e-01
    phi[1,4]  R907      -2.3696417808532715e+00
    phi[1,4]  R908      -1.6089435815811157e+00
    phi[1,4]  R909      -2.1147453784942627e+00
    phi[1,4]  R910      -2.2627146244049072e+00
    phi[1,4]  R911      -2.0504148006439209e+00
    phi[1,4]  R912      -2.1237349510192871e+00
    phi[1,4]  R913      -2.5769648551940918e+00
    phi[1,4]  R914      -4.5210966467857361e-01
    phi[1,4]  R915      -1.1546884775161743e+00
    phi[1,4]  R916      -1.7320551872253418e+00
    phi[1,4]  R917      -1.6880097389221191e+00
    phi[1,4]  R918      -1.6912654638290405e+00
    phi[1,4]  R919      -7.6995092630386353e-01
    phi[1,4]  R920      -1.3253802061080933e+00
    phi[1,4]  R921      -2.3307590484619141e+00
    phi[1,4]  R922      -2.0371737480163574e+00
    phi[1,4]  R923      -1.4692775011062622e+00
    phi[1,4]  R924      -2.5349173545837402e+00
    phi[1,4]  R925      -1.4125108718872070e+00
    phi[1,4]  R926      -1.3752728700637817e+00
    phi[1,4]  R927      -2.6204290390014648e+00
    phi[1,4]  R928      -1.8475852012634277e+00
    phi[1,4]  R929      -3.1098883152008057e+00
    phi[1,4]  R930      -1.3431684970855713e+00
    phi[1,4]  R931      -8.9489841461181641e-01
    phi[1,4]  R932      -8.0913382768630981e-01
    phi[1,4]  R933      -1.4148331880569458e+00
    phi[1,4]  R934      -7.3911887407302856e-01
    phi[1,4]  R935      -1.9565033912658691e+00
    phi[1,4]  R936      -1.6502164304256439e-01
    phi[1,4]  R937      -1.1682033538818359e+00
    phi[1,4]  R938      -2.5605266094207764e+00
    phi[1,4]  R939      -1.9631146192550659e+00
    phi[1,4]  R940      -2.1662850379943848e+00
    phi[1,4]  R941      -2.7507803440093994e+00
    phi[1,4]  R942      -2.1397206783294678e+00
    phi[1,4]  R943      -7.1277356147766113e-01
    phi[1,4]  R944      -1.7018672227859497e+00
    phi[1,4]  R945      -1.8090885877609253e+00
    phi[1,4]  R946      -2.2797913551330566e+00
    phi[1,4]  R947      -8.4748250246047974e-01
    phi[1,4]  R948      5.4007512331008911e-01
    phi[1,4]  R949      -2.1078512668609619e+00
    phi[1,4]  R950      -2.0483455657958984e+00
    phi[1,4]  R951      -7.0774477720260620e-01
    phi[1,4]  R952      -9.2972618341445923e-01
    phi[1,4]  R953      -3.2528080940246582e+00
    phi[1,4]  R954      -7.0197623968124390e-01
    phi[1,4]  R955      -1.1618494987487793e+00
    phi[1,4]  R956      -1.6450424194335938e+00
    phi[1,4]  R957      -2.1258029937744141e+00
    phi[1,4]  R958      -3.0885741710662842e+00
    phi[1,4]  R959      -2.94913649559021
    phi[1,4]  R960      -1.9539268016815186e+00
    phi[1,4]  R961      -1.3973873853683472e+00
    phi[1,4]  R962      -1.5839911699295044e+00
    phi[1,4]  R963      -2.2295196056365967e+00
    phi[1,4]  R964      -4.3555787205696106e-01
    phi[1,4]  R965      -1.7578189373016357e+00
    phi[1,4]  R966      -2.3268735408782959e+00
    phi[1,4]  R967      -1.4632124900817871e+00
    phi[1,4]  R968      -7.7642679214477539e-01
    phi[1,4]  R969      -1.7279206514358521e+00
    phi[1,4]  R970      -1.0904998779296875e+00
    phi[1,4]  R971      -2.9578297138214111e+00
    phi[1,4]  R972      -2.0215868949890137e+00
    phi[1,4]  R973      -2.1015448570251465e+00
    phi[1,4]  R974      -1.7755625247955322e+00
    phi[1,4]  R975      -2.3339097499847412e+00
    phi[1,4]  R976      -2.3203690052032471e+00
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R977      -3.0999999046325684e+00
    phi[4,1]  R978      -3.0999999046325684e+00
    phi[4,1]  R979      -2.2400000095367432e+00
    phi[4,1]  R980      -2.2400000095367432e+00
    phi[4,1]  R981      -3.0999999046325684e+00
    phi[4,1]  R982      -3.0999999046325684e+00
    phi[4,1]  R983      -2.5699999332427979e+00
    phi[4,1]  R984      -2.5699999332427979e+00
    phi[4,1]  R985      -3.0999999046325684e+00
    phi[4,1]  R986      -3.0999999046325684e+00
    phi[4,1]  R987      -2.0899999141693115e+00
    phi[4,1]  R988      -2.0899999141693115e+00
    phi[4,1]  R989      -3.0999999046325684e+00
    phi[4,1]  R990      -3.0999999046325684e+00
    phi[4,1]  R991      2.2276818752288818e-01
    phi[4,1]  R992      3.7029001861810684e-02
    phi[4,1]  R993      -2.7402403950691223e-01
    phi[4,1]  R994      3.3768272399902344e-01
    phi[4,1]  R995      -0.558380126953125
    phi[4,1]  R996      3.6144825816154480e-01
    phi[4,1]  R997      4.7950321435928345e-01
    phi[4,1]  R998      5.3239285945892334e-01
    phi[4,1]  R999      5.2750366926193237e-01
    phi[4,1]  R1000     9.3263971805572510e-01
    phi[4,1]  R1001     -2.5645124912261963e+00
    phi[4,1]  R1002     -2.4623322486877441e+00
    phi[4,1]  R1003     -3.0082054138183594e+00
    phi[4,1]  R1004     -1.0090082883834839e+00
    phi[4,1]  R1005     -8.9040565490722656e-01
    phi[4,1]  R1006     -2.1642878055572510e+00
    phi[4,1]  R1007     -1.7568511962890625e+00
    phi[4,1]  R1008     -1.8405609130859375e+00
    phi[4,1]  R1009     -1.9483366012573242e+00
    phi[4,1]  R1010     -2.1683411598205566e+00
    phi[4,1]  R1011     -4.9423295259475708e-01
    phi[4,1]  R1012     -2.1395049095153809e+00
    phi[4,1]  R1013     -2.1951858997344971e+00
    phi[4,1]  R1014     -2.07004714012146
    phi[4,1]  R1015     -1.8361315727233887e+00
    phi[4,1]  R1016     -7.6896792650222778e-01
    phi[4,1]  R1017     -2.8638944625854492e+00
    phi[4,1]  R1018     -2.5256137847900391e+00
    phi[4,1]  R1019     -9.4713938236236572e-01
    phi[4,1]  R1020     -2.1351103782653809e+00
    phi[4,1]  R1021     -1.8661818504333496e+00
    phi[4,1]  R1022     -1.5981520414352417e+00
    phi[4,1]  R1023     -2.0402641296386719e+00
    phi[4,1]  R1024     -1.1748509407043457e+00
    phi[4,1]  R1025     -2.0496413707733154e+00
    phi[4,1]  R1026     -2.5082964897155762e+00
    phi[4,1]  R1027     -2.4169750213623047e+00
    phi[4,1]  R1028     -2.3393447399139404e+00
    phi[4,1]  R1029     -1.4505541324615479e+00
    phi[4,1]  R1030     -6.0002660751342773e-01
    phi[4,1]  R1031     -2.3696417808532715e+00
    phi[4,1]  R1032     -1.6089435815811157e+00
    phi[4,1]  R1033     -2.1147453784942627e+00
    phi[4,1]  R1034     -2.2627146244049072e+00
    phi[4,1]  R1035     -2.0504148006439209e+00
    phi[4,1]  R1036     -2.1237349510192871e+00
    phi[4,1]  R1037     -2.5769648551940918e+00
    phi[4,1]  R1038     -4.5210966467857361e-01
    phi[4,1]  R1039     -1.1546884775161743e+00
    phi[4,1]  R1040     -1.7320551872253418e+00
    phi[4,1]  R1041     -1.6880097389221191e+00
    phi[4,1]  R1042     -1.6912654638290405e+00
    phi[4,1]  R1043     -7.6995092630386353e-01
    phi[4,1]  R1044     -1.3253802061080933e+00
    phi[4,1]  R1045     -2.3307590484619141e+00
    phi[4,1]  R1046     -2.0371737480163574e+00
    phi[4,1]  R1047     -1.4692775011062622e+00
    phi[4,1]  R1048     -2.5349173545837402e+00
    phi[4,1]  R1049     -1.4125108718872070e+00
    phi[4,1]  R1050     -1.3752728700637817e+00
    phi[4,1]  R1051     -2.6204290390014648e+00
    phi[4,1]  R1052     -1.8475852012634277e+00
    phi[4,1]  R1053     -3.1098883152008057e+00
    phi[4,1]  R1054     -1.3431684970855713e+00
    phi[4,1]  R1055     -8.9489841461181641e-01
    phi[4,1]  R1056     -8.0913382768630981e-01
    phi[4,1]  R1057     -1.4148331880569458e+00
    phi[4,1]  R1058     -7.3911887407302856e-01
    phi[4,1]  R1059     -1.9565033912658691e+00
    phi[4,1]  R1060     -1.6502164304256439e-01
    phi[4,1]  R1061     -1.1682033538818359e+00
    phi[4,1]  R1062     -2.5605266094207764e+00
    phi[4,1]  R1063     -1.9631146192550659e+00
    phi[4,1]  R1064     -2.1662850379943848e+00
    phi[4,1]  R1065     -2.7507803440093994e+00
    phi[4,1]  R1066     -2.1397206783294678e+00
    phi[4,1]  R1067     -7.1277356147766113e-01
    phi[4,1]  R1068     -1.7018672227859497e+00
    phi[4,1]  R1069     -1.8090885877609253e+00
    phi[4,1]  R1070     -2.2797913551330566e+00
    phi[4,1]  R1071     -8.4748250246047974e-01
    phi[4,1]  R1072     5.4007512331008911e-01
    phi[4,1]  R1073     -2.1078512668609619e+00
    phi[4,1]  R1074     -2.0483455657958984e+00
    phi[4,1]  R1075     -7.0774477720260620e-01
    phi[4,1]  R1076     -9.2972618341445923e-01
    phi[4,1]  R1077     -3.2528080940246582e+00
    phi[4,1]  R1078     -7.0197623968124390e-01
    phi[4,1]  R1079     -1.1618494987487793e+00
    phi[4,1]  R1080     -1.6450424194335938e+00
    phi[4,1]  R1081     -2.1258029937744141e+00
    phi[4,1]  R1082     -3.0885741710662842e+00
    phi[4,1]  R1083     -2.94913649559021
    phi[4,1]  R1084     -1.9539268016815186e+00
    phi[4,1]  R1085     -1.3973873853683472e+00
    phi[4,1]  R1086     -1.5839911699295044e+00
    phi[4,1]  R1087     -2.2295196056365967e+00
    phi[4,1]  R1088     -4.3555787205696106e-01
    phi[4,1]  R1089     -1.7578189373016357e+00
    phi[4,1]  R1090     -2.3268735408782959e+00
    phi[4,1]  R1091     -1.4632124900817871e+00
    phi[4,1]  R1092     -7.7642679214477539e-01
    phi[4,1]  R1093     -1.7279206514358521e+00
    phi[4,1]  R1094     -1.0904998779296875e+00
    phi[4,1]  R1095     -2.9578297138214111e+00
    phi[4,1]  R1096     -2.0215868949890137e+00
    phi[4,1]  R1097     -2.1015448570251465e+00
    phi[4,1]  R1098     -1.7755625247955322e+00
    phi[4,1]  R1099     -2.3339097499847412e+00
    phi[4,1]  R1100     -2.3203690052032471e+00
    phi[4,1]  R1101     2.2263925075531006e+00
    phi[4,1]  R1102     1.2524091005325317e+00
    phi[4,1]  R1103     -2.5469126701354980e+00
    phi[4,1]  R1104     1.2003079801797867e-01
    phi[4,1]  R1105     -2.6102342605590820e+00
    phi[4,1]  R1106     -2.3584907054901123e+00
    phi[4,1]  R1107     -2.1882026195526123e+00
    phi[4,1]  R1108     -1.5680531263351440e+00
    phi[4,1]  R1109     -3.33258056640625
    phi[4,1]  R1110     -1.3866410255432129e+00
    phi[4,1]  R1111     -1.5727608203887939e+00
    phi[4,1]  R1112     -1.0093477964401245e+00
    phi[4,1]  R1113     -1.1689211130142212e+00
    phi[4,1]  R1114     -3.2290643453598022e-01
    phi[4,1]  R1115     -2.4277734756469727e+00
    phi[4,1]  R1116     -1.7736625671386719e+00
    phi[4,1]  R1117     -2.0152981281280518e+00
    phi[4,1]  R1118     -2.0943448543548584e+00
    phi[4,1]  R1119     -1.5062483549118042e+00
    phi[4,1]  R1120     -2.6943478584289551e+00
    phi[4,1]  R1121     6.0946738719940186e-01
    phi[4,1]  R1122     -1.3057361841201782e+00
    phi[4,1]  R1123     -1.5625617504119873e+00
    phi[4,1]  R1124     -5.9059686958789825e-02
    phi[4,1]  R1125     -2.9015748500823975e+00
    phi[4,1]  R1126     -2.8699882030487061e+00
    phi[4,1]  R1127     -2.1830904483795166e+00
    phi[4,1]  R1128     -3.3515632152557373e+00
    phi[4,1]  R1129     -2.9988026618957520e+00
    phi[4,1]  R1130     -2.9708533287048340e+00
    phi[4,1]  R1131     -2.5789287090301514e+00
    phi[4,1]  R1132     1.3626056909561157e-01
    phi[4,1]  R1133     -6.1639338731765747e-01
    phi[4,1]  R1134     -8.9828038215637207e-01
    phi[4,1]  R1135     -2.2858147621154785e+00
    phi[4,1]  R1136     -1.7517405748367310e+00
    phi[4,1]  R1137     -2.6733341217041016e+00
    phi[4,1]  R1138     -2.7340774536132812e+00
    phi[4,1]  R1139     -1.3700952529907227e+00
    phi[4,1]  R1140     -1.6660593748092651e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1141     -3.0999999046325684e+00
    phi[2,3]  R1142     -3.0999999046325684e+00
    phi[2,3]  R1143     -2.2400000095367432e+00
    phi[2,3]  R1144     -2.2400000095367432e+00
    phi[2,3]  R1145     -3.0999999046325684e+00
    phi[2,3]  R1146     -3.0999999046325684e+00
    phi[2,3]  R1147     -2.5699999332427979e+00
    phi[2,3]  R1148     -2.5699999332427979e+00
    phi[2,3]  R1149     -3.0999999046325684e+00
    phi[2,3]  R1150     -3.0999999046325684e+00
    phi[2,3]  R1151     -2.0899999141693115e+00
    phi[2,3]  R1152     -2.0899999141693115e+00
    phi[2,3]  R1153     -3.0999999046325684e+00
    phi[2,3]  R1154     -3.0999999046325684e+00
    phi[2,3]  R1155     6.4559715986251831e-01
    phi[2,3]  R1156     4.5916372537612915e-01
    phi[2,3]  R1157     4.8055320978164673e-01
    phi[2,3]  R1158     3.7455520033836365e-01
    phi[2,3]  R1159     -8.3785879611968994e-01
    phi[2,3]  R1160     -5.9451079368591309e-01
    phi[2,3]  R1161     -4.7600808739662170e-01
    phi[2,3]  R1162     2.7148500084877014e-01
    phi[2,3]  R1163     0.1130366101861
    phi[2,3]  R1164     -6.6303676366806030e-01
    phi[2,3]  R1165     -8.0951493978500366e-01
    phi[2,3]  R1166     -2.5891476869583130e-01
    phi[2,3]  R1167     -8.0352711677551270e-01
    phi[2,3]  R1168     -1.8874228000640869e+00
    phi[2,3]  R1169     -2.5974180698394775e+00
    phi[2,3]  R1170     -2.6128213405609131e+00
    phi[2,3]  R1171     -2.2439148426055908e+00
    phi[2,3]  R1172     -2.1159431934356689e+00
    phi[2,3]  R1173     -1.8922260999679565e+00
    phi[2,3]  R1174     -3.0244784355163574e+00
    phi[2,3]  R1175     -2.2940292358398438e+00
    phi[2,3]  R1176     -2.0555188655853271e+00
    phi[2,3]  R1177     -2.8691885471343994e+00
    phi[2,3]  R1178     -2.3858044147491455e+00
    phi[2,3]  R1179     -1.83588445186615
    phi[2,3]  R1180     -2.6945152282714844e+00
    phi[2,3]  R1181     -1.7065685987472534e+00
    phi[2,3]  R1182     -1.6010600328445435e+00
    phi[2,3]  R1183     -3.0781605243682861e+00
    phi[2,3]  R1184     -1.8596018552780151e+00
    phi[2,3]  R1185     -2.9251022338867188e+00
    phi[2,3]  R1186     -1.5946084260940552e+00
    phi[2,3]  R1187     -1.9536197185516357e+00
    phi[2,3]  R1188     -1.9141073226928711e+00
    phi[2,3]  R1189     -1.9262479543685913e+00
    phi[2,3]  R1190     -4.0857315063476562e+00
    phi[2,3]  R1191     -1.6861816644668579e+00
    phi[2,3]  R1192     -2.1007082462310791e+00
    phi[2,3]  R1193     -2.0144200325012207e+00
    phi[2,3]  R1194     -2.2645723819732666e+00
    phi[2,3]  R1195     -2.7373936772346497e-01
    phi[2,3]  R1196     -1.9503599405288696e+00
    phi[2,3]  R1197     -2.9933021068573
    phi[2,3]  R1198     -3.1349010467529297e+00
    phi[2,3]  R1199     -3.3092114925384521e+00
    phi[2,3]  R1200     -1.6174052953720093e+00
    phi[2,3]  R1201     -2.9014217853546143e+00
    phi[2,3]  R1202     -1.8061344623565674e+00
    phi[2,3]  R1203     -1.6370401382446289e+00
    phi[2,3]  R1204     -1.9503235816955566e+00
    phi[2,3]  R1205     -5.5120462179183960e-01
    phi[2,3]  R1206     -3.0070440769195557e+00
    phi[2,3]  R1207     -2.7877635955810547e+00
    phi[2,3]  R1208     -1.4084955453872681e+00
    phi[2,3]  R1209     -1.5117737054824829e+00
    phi[2,3]  R1210     -2.2070262432098389e+00
    phi[2,3]  R1211     -3.2820637226104736e+00
    phi[2,3]  R1212     -2.2329647541046143e+00
    phi[2,3]  R1213     -3.5413296222686768e+00
    phi[2,3]  R1214     -2.0176897048950195e+00
    phi[2,3]  R1215     -1.2447081804275513e+00
    phi[2,3]  R1216     -2.1725103855133057e+00
    phi[2,3]  R1217     -2.3181962966918945e+00
    phi[2,3]  R1218     -2.5905840396881104e+00
    phi[2,3]  R1219     -7.7069085836410522e-01
    phi[2,3]  R1220     -2.6716580390930176e+00
    phi[2,3]  R1221     -1.9927949905395508e+00
    phi[2,3]  R1222     -2.7345507144927979e+00
    phi[2,3]  R1223     -2.5340874195098877e+00
    phi[2,3]  R1224     -2.4101488590240479e+00
    phi[2,3]  R1225     -6.7530745267868042e-01
    phi[2,3]  R1226     -0.331532746553421
    phi[2,3]  R1227     -7.1518331766128540e-01
    phi[2,3]  R1228     -2.2097387313842773e+00
    phi[2,3]  R1229     -0.188564270734787
    phi[2,3]  R1230     -2.9340455532073975e+00
    phi[2,3]  R1231     -1.7658981084823608e+00
    phi[2,3]  R1232     -2.3129115104675293e+00
    phi[2,3]  R1233     -2.0004968643188477e+00
    phi[2,3]  R1234     -1.6520259380340576e+00
    phi[2,3]  R1235     -7.0179396867752075e-01
    phi[2,3]  R1236     -1.9338485598564148e-01
    phi[2,3]  R1237     -2.3957686424255371e+00
    phi[2,3]  R1238     -2.3699812889099121e+00
    phi[2,3]  R1239     -1.0914878845214844e+00
    phi[2,3]  R1240     -1.7712409496307373e+00
    phi[2,3]  R1241     -1.6024928092956543e+00
    phi[2,3]  R1242     -2.2782316207885742e+00
    phi[2,3]  R1243     -2.4188754558563232e+00
    phi[2,3]  R1244     -3.0373599529266357e+00
    phi[2,3]  R1245     -3.9094531536102295e-01
    phi[2,3]  R1246     -7.3785686492919922e-01
    phi[2,3]  R1247     -1.5853306055068970e+00
    phi[2,3]  R1248     -2.5782127380371094e+00
    phi[2,3]  R1249     -2.3790390491485596e+00
    phi[2,3]  R1250     -2.4555022716522217e+00
    phi[2,3]  R1251     -2.4904663562774658e+00
    phi[2,3]  R1252     -1.7184319496154785e+00
    phi[2,3]  R1253     -1.9494717121124268e+00
    phi[2,3]  R1254     -2.0469899177551270e+00
    phi[2,3]  R1255     -3.7546166777610779e-01
    phi[2,3]  R1256     -2.7554972171783447e+00
    phi[2,3]  R1257     -2.0122954845428467e+00
    phi[2,3]  R1258     -2.4201695919036865e+00
    phi[2,3]  R1259     -1.6185218095779419e+00
    phi[2,3]  R1260     -1.2893269062042236e+00
    phi[2,3]  R1261     -1.2469331026077271e+00
    phi[2,3]  R1262     -1.6163178682327271e+00
    phi[2,3]  R1263     -2.6959180831909180e+00
    phi[2,3]  R1264     -1.1794676780700684e+00
    phi[2,3]  R1265     1.6069425344467163e+00
    phi[2,3]  R1266     9.2706519365310669e-01
    phi[2,3]  R1267     1.54611074924469
    phi[2,3]  R1268     1.3110734224319458e+00
    phi[2,3]  R1269     1.1438255310058594e+00
    phi[2,3]  R1270     1.9603191614151
    phi[2,3]  R1271     1.7324629426002502e-01
    phi[2,3]  R1272     9.1675353050231934e-01
    phi[2,3]  R1273     -4.1927906870841980e-01
    phi[2,3]  R1274     -1.1207662820816040e+00
    phi[2,3]  R1275     -6.6371726989746094e-01
    phi[2,3]  R1276     -1.1094723939895630e+00
    phi[2,3]  R1277     -4.8450121283531189e-01
    phi[2,3]  R1278     -9.7202211618423462e-01
    phi[2,3]  R1279     -2.5104942321777344e+00
    phi[2,3]  R1280     -3.2774178981781006e+00
    phi[2,3]  R1281     -2.08794903755188
    phi[2,3]  R1282     -1.9125593900680542e+00
    phi[2,3]  R1283     -1.8138868808746338e+00
    phi[2,3]  R1284     -3.0459187030792236e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1285     -3.0999999046325684e+00
    phi[3,2]  R1286     -3.0999999046325684e+00
    phi[3,2]  R1287     -2.2400000095367432e+00
    phi[3,2]  R1288     -2.2400000095367432e+00
    phi[3,2]  R1289     -3.0999999046325684e+00
    phi[3,2]  R1290     -3.0999999046325684e+00
    phi[3,2]  R1291     -2.5699999332427979e+00
    phi[3,2]  R1292     -2.5699999332427979e+00
    phi[3,2]  R1293     -3.0999999046325684e+00
    phi[3,2]  R1294     -3.0999999046325684e+00
    phi[3,2]  R1295     -2.0899999141693115e+00
    phi[3,2]  R1296     -2.0899999141693115e+00
    phi[3,2]  R1297     -3.0999999046325684e+00
    phi[3,2]  R1298     -3.0999999046325684e+00
    phi[3,2]  R1299     1.6069425344467163e+00
    phi[3,2]  R1300     9.2706519365310669e-01
    phi[3,2]  R1301     1.54611074924469
    phi[3,2]  R1302     1.3110734224319458e+00
    phi[3,2]  R1303     1.1438255310058594e+00
    phi[3,2]  R1304     1.9603191614151
    phi[3,2]  R1305     1.7324629426002502e-01
    phi[3,2]  R1306     9.1675353050231934e-01
    phi[3,2]  R1307     -4.1927906870841980e-01
    phi[3,2]  R1308     -1.1207662820816040e+00
    phi[3,2]  R1309     -6.6371726989746094e-01
    phi[3,2]  R1310     -1.1094723939895630e+00
    phi[3,2]  R1311     -4.8450121283531189e-01
    phi[3,2]  R1312     -9.7202211618423462e-01
    phi[3,2]  R1313     -2.5104942321777344e+00
    phi[3,2]  R1314     -3.2774178981781006e+00
    phi[3,2]  R1315     -2.08794903755188
    phi[3,2]  R1316     -1.9125593900680542e+00
    phi[3,2]  R1317     -1.8138868808746338e+00
    phi[3,2]  R1318     -3.0459187030792236e+00
    phi[3,2]  R1319     6.4559715986251831e-01
    phi[3,2]  R1320     4.5916372537612915e-01
    phi[3,2]  R1321     4.8055320978164673e-01
    phi[3,2]  R1322     3.7455520033836365e-01
    phi[3,2]  R1323     -8.3785879611968994e-01
    phi[3,2]  R1324     -5.9451079368591309e-01
    phi[3,2]  R1325     -4.7600808739662170e-01
    phi[3,2]  R1326     2.7148500084877014e-01
    phi[3,2]  R1327     0.1130366101861
    phi[3,2]  R1328     -6.6303676366806030e-01
    phi[3,2]  R1329     -8.0951493978500366e-01
    phi[3,2]  R1330     -2.5891476869583130e-01
    phi[3,2]  R1331     -8.0352711677551270e-01
    phi[3,2]  R1332     -1.8874228000640869e+00
    phi[3,2]  R1333     -2.5974180698394775e+00
    phi[3,2]  R1334     -2.6128213405609131e+00
    phi[3,2]  R1335     -2.2439148426055908e+00
    phi[3,2]  R1336     -2.1159431934356689e+00
    phi[3,2]  R1337     -1.8922260999679565e+00
    phi[3,2]  R1338     -3.0244784355163574e+00
    phi[3,2]  R1339     -2.2940292358398438e+00
    phi[3,2]  R1340     -2.0555188655853271e+00
    phi[3,2]  R1341     -2.8691885471343994e+00
    phi[3,2]  R1342     -2.3858044147491455e+00
    phi[3,2]  R1343     -1.83588445186615
    phi[3,2]  R1344     -2.6945152282714844e+00
    phi[3,2]  R1345     -1.7065685987472534e+00
    phi[3,2]  R1346     -1.6010600328445435e+00
    phi[3,2]  R1347     -3.0781605243682861e+00
    phi[3,2]  R1348     -1.8596018552780151e+00
    phi[3,2]  R1349     -2.9251022338867188e+00
    phi[3,2]  R1350     -1.5946084260940552e+00
    phi[3,2]  R1351     -1.9536197185516357e+00
    phi[3,2]  R1352     -1.9141073226928711e+00
    phi[3,2]  R1353     -1.9262479543685913e+00
    phi[3,2]  R1354     -4.0857315063476562e+00
    phi[3,2]  R1355     -1.6861816644668579e+00
    phi[3,2]  R1356     -2.1007082462310791e+00
    phi[3,2]  R1357     -2.0144200325012207e+00
    phi[3,2]  R1358     -2.2645723819732666e+00
    phi[3,2]  R1359     -2.7373936772346497e-01
    phi[3,2]  R1360     -1.9503599405288696e+00
    phi[3,2]  R1361     -2.9933021068573
    phi[3,2]  R1362     -3.1349010467529297e+00
    phi[3,2]  R1363     -3.3092114925384521e+00
    phi[3,2]  R1364     -1.6174052953720093e+00
    phi[3,2]  R1365     -2.9014217853546143e+00
    phi[3,2]  R1366     -1.8061344623565674e+00
    phi[3,2]  R1367     -1.6370401382446289e+00
    phi[3,2]  R1368     -1.9503235816955566e+00
    phi[3,2]  R1369     -5.5120462179183960e-01
    phi[3,2]  R1370     -3.0070440769195557e+00
    phi[3,2]  R1371     -2.7877635955810547e+00
    phi[3,2]  R1372     -1.4084955453872681e+00
    phi[3,2]  R1373     -1.5117737054824829e+00
    phi[3,2]  R1374     -2.2070262432098389e+00
    phi[3,2]  R1375     -3.2820637226104736e+00
    phi[3,2]  R1376     -2.2329647541046143e+00
    phi[3,2]  R1377     -3.5413296222686768e+00
    phi[3,2]  R1378     -2.0176897048950195e+00
    phi[3,2]  R1379     -1.2447081804275513e+00
    phi[3,2]  R1380     -2.1725103855133057e+00
    phi[3,2]  R1381     -2.3181962966918945e+00
    phi[3,2]  R1382     -2.5905840396881104e+00
    phi[3,2]  R1383     -7.7069085836410522e-01
    phi[3,2]  R1384     -2.6716580390930176e+00
    phi[3,2]  R1385     -1.9927949905395508e+00
    phi[3,2]  R1386     -2.7345507144927979e+00
    phi[3,2]  R1387     -2.5340874195098877e+00
    phi[3,2]  R1388     -2.4101488590240479e+00
    phi[3,2]  R1389     -6.7530745267868042e-01
    phi[3,2]  R1390     -0.331532746553421
    phi[3,2]  R1391     -7.1518331766128540e-01
    phi[3,2]  R1392     -2.2097387313842773e+00
    phi[3,2]  R1393     -0.188564270734787
    phi[3,2]  R1394     -2.9340455532073975e+00
    phi[3,2]  R1395     -1.7658981084823608e+00
    phi[3,2]  R1396     -2.3129115104675293e+00
    phi[3,2]  R1397     -2.0004968643188477e+00
    phi[3,2]  R1398     -1.6520259380340576e+00
    phi[3,2]  R1399     -7.0179396867752075e-01
    phi[3,2]  R1400     -1.9338485598564148e-01
    phi[3,2]  R1401     -2.3957686424255371e+00
    phi[3,2]  R1402     -2.3699812889099121e+00
    phi[3,2]  R1403     -1.0914878845214844e+00
    phi[3,2]  R1404     -1.7712409496307373e+00
    phi[3,2]  R1405     -1.6024928092956543e+00
    phi[3,2]  R1406     -2.2782316207885742e+00
    phi[3,2]  R1407     -2.4188754558563232e+00
    phi[3,2]  R1408     -3.0373599529266357e+00
    phi[3,2]  R1409     -3.9094531536102295e-01
    phi[3,2]  R1410     -7.3785686492919922e-01
    phi[3,2]  R1411     -1.5853306055068970e+00
    phi[3,2]  R1412     -2.5782127380371094e+00
    phi[3,2]  R1413     -2.3790390491485596e+00
    phi[3,2]  R1414     -2.4555022716522217e+00
    phi[3,2]  R1415     -2.4904663562774658e+00
    phi[3,2]  R1416     -1.7184319496154785e+00
    phi[3,2]  R1417     -1.9494717121124268e+00
    phi[3,2]  R1418     -2.0469899177551270e+00
    phi[3,2]  R1419     -3.7546166777610779e-01
    phi[3,2]  R1420     -2.7554972171783447e+00
    phi[3,2]  R1421     -2.0122954845428467e+00
    phi[3,2]  R1422     -2.4201695919036865e+00
    phi[3,2]  R1423     -1.6185218095779419e+00
    phi[3,2]  R1424     -1.2893269062042236e+00
    phi[3,2]  R1425     -1.2469331026077271e+00
    phi[3,2]  R1426     -1.6163178682327271e+00
    phi[3,2]  R1427     -2.6959180831909180e+00
    phi[3,2]  R1428     -1.1794676780700684e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1429     -3.0999999046325684e+00
    phi[2,4]  R1430     -3.0999999046325684e+00
    phi[2,4]  R1431     -2.2400000095367432e+00
    phi[2,4]  R1432     -2.2400000095367432e+00
    phi[2,4]  R1433     -3.0999999046325684e+00
    phi[2,4]  R1434     -3.0999999046325684e+00
    phi[2,4]  R1435     -2.5699999332427979e+00
    phi[2,4]  R1436     -2.5699999332427979e+00
    phi[2,4]  R1437     -3.0999999046325684e+00
    phi[2,4]  R1438     -3.0999999046325684e+00
    phi[2,4]  R1439     -2.0899999141693115e+00
    phi[2,4]  R1440     -2.0899999141693115e+00
    phi[2,4]  R1441     -3.0999999046325684e+00
    phi[2,4]  R1442     -3.0999999046325684e+00
    phi[2,4]  R1443     6.4559715986251831e-01
    phi[2,4]  R1444     4.5916372537612915e-01
    phi[2,4]  R1445     4.8055320978164673e-01
    phi[2,4]  R1446     3.7455520033836365e-01
    phi[2,4]  R1447     -8.3785879611968994e-01
    phi[2,4]  R1448     -5.9451079368591309e-01
    phi[2,4]  R1449     -4.7600808739662170e-01
    phi[2,4]  R1450     2.7148500084877014e-01
    phi[2,4]  R1451     0.1130366101861
    phi[2,4]  R1452     -6.6303676366806030e-01
    phi[2,4]  R1453     -8.0951493978500366e-01
    phi[2,4]  R1454     -2.5891476869583130e-01
    phi[2,4]  R1455     -8.0352711677551270e-01
    phi[2,4]  R1456     -1.8874228000640869e+00
    phi[2,4]  R1457     -2.5974180698394775e+00
    phi[2,4]  R1458     -2.6128213405609131e+00
    phi[2,4]  R1459     -2.2439148426055908e+00
    phi[2,4]  R1460     -2.1159431934356689e+00
    phi[2,4]  R1461     -1.8922260999679565e+00
    phi[2,4]  R1462     -3.0244784355163574e+00
    phi[2,4]  R1463     -2.2940292358398438e+00
    phi[2,4]  R1464     -2.0555188655853271e+00
    phi[2,4]  R1465     -2.8691885471343994e+00
    phi[2,4]  R1466     -2.3858044147491455e+00
    phi[2,4]  R1467     -1.83588445186615
    phi[2,4]  R1468     -2.6945152282714844e+00
    phi[2,4]  R1469     -1.7065685987472534e+00
    phi[2,4]  R1470     -1.6010600328445435e+00
    phi[2,4]  R1471     -3.0781605243682861e+00
    phi[2,4]  R1472     -1.8596018552780151e+00
    phi[2,4]  R1473     -2.9251022338867188e+00
    phi[2,4]  R1474     -1.5946084260940552e+00
    phi[2,4]  R1475     -1.9536197185516357e+00
    phi[2,4]  R1476     -1.9141073226928711e+00
    phi[2,4]  R1477     -1.9262479543685913e+00
    phi[2,4]  R1478     -4.0857315063476562e+00
    phi[2,4]  R1479     -1.6861816644668579e+00
    phi[2,4]  R1480     -2.1007082462310791e+00
    phi[2,4]  R1481     -2.0144200325012207e+00
    phi[2,4]  R1482     -2.2645723819732666e+00
    phi[2,4]  R1483     -2.7373936772346497e-01
    phi[2,4]  R1484     -1.9503599405288696e+00
    phi[2,4]  R1485     -2.9933021068573
    phi[2,4]  R1486     -3.1349010467529297e+00
    phi[2,4]  R1487     -3.3092114925384521e+00
    phi[2,4]  R1488     -1.6174052953720093e+00
    phi[2,4]  R1489     -2.9014217853546143e+00
    phi[2,4]  R1490     -1.8061344623565674e+00
    phi[2,4]  R1491     -1.6370401382446289e+00
    phi[2,4]  R1492     -1.9503235816955566e+00
    phi[2,4]  R1493     -5.5120462179183960e-01
    phi[2,4]  R1494     -3.0070440769195557e+00
    phi[2,4]  R1495     -2.7877635955810547e+00
    phi[2,4]  R1496     -1.4084955453872681e+00
    phi[2,4]  R1497     -1.5117737054824829e+00
    phi[2,4]  R1498     -2.2070262432098389e+00
    phi[2,4]  R1499     -3.2820637226104736e+00
    phi[2,4]  R1500     -2.2329647541046143e+00
    phi[2,4]  R1501     -3.5413296222686768e+00
    phi[2,4]  R1502     -2.0176897048950195e+00
    phi[2,4]  R1503     -1.2447081804275513e+00
    phi[2,4]  R1504     -2.1725103855133057e+00
    phi[2,4]  R1505     -2.3181962966918945e+00
    phi[2,4]  R1506     -2.5905840396881104e+00
    phi[2,4]  R1507     -7.7069085836410522e-01
    phi[2,4]  R1508     -2.6716580390930176e+00
    phi[2,4]  R1509     -1.9927949905395508e+00
    phi[2,4]  R1510     -2.7345507144927979e+00
    phi[2,4]  R1511     -2.5340874195098877e+00
    phi[2,4]  R1512     -2.4101488590240479e+00
    phi[2,4]  R1513     -6.7530745267868042e-01
    phi[2,4]  R1514     -0.331532746553421
    phi[2,4]  R1515     -7.1518331766128540e-01
    phi[2,4]  R1516     -2.2097387313842773e+00
    phi[2,4]  R1517     -0.188564270734787
    phi[2,4]  R1518     -2.9340455532073975e+00
    phi[2,4]  R1519     -1.7658981084823608e+00
    phi[2,4]  R1520     -2.3129115104675293e+00
    phi[2,4]  R1521     -2.0004968643188477e+00
    phi[2,4]  R1522     -1.6520259380340576e+00
    phi[2,4]  R1523     -7.0179396867752075e-01
    phi[2,4]  R1524     -1.9338485598564148e-01
    phi[2,4]  R1525     -2.3957686424255371e+00
    phi[2,4]  R1526     -2.3699812889099121e+00
    phi[2,4]  R1527     -1.0914878845214844e+00
    phi[2,4]  R1528     -1.7712409496307373e+00
    phi[2,4]  R1529     -1.6024928092956543e+00
    phi[2,4]  R1530     -2.2782316207885742e+00
    phi[2,4]  R1531     -2.4188754558563232e+00
    phi[2,4]  R1532     -3.0373599529266357e+00
    phi[2,4]  R1533     -3.9094531536102295e-01
    phi[2,4]  R1534     -7.3785686492919922e-01
    phi[2,4]  R1535     -1.5853306055068970e+00
    phi[2,4]  R1536     -2.5782127380371094e+00
    phi[2,4]  R1537     -2.3790390491485596e+00
    phi[2,4]  R1538     -2.4555022716522217e+00
    phi[2,4]  R1539     -2.4904663562774658e+00
    phi[2,4]  R1540     -1.7184319496154785e+00
    phi[2,4]  R1541     -1.9494717121124268e+00
    phi[2,4]  R1542     -2.0469899177551270e+00
    phi[2,4]  R1543     -3.7546166777610779e-01
    phi[2,4]  R1544     -2.7554972171783447e+00
    phi[2,4]  R1545     -2.0122954845428467e+00
    phi[2,4]  R1546     -2.4201695919036865e+00
    phi[2,4]  R1547     -1.6185218095779419e+00
    phi[2,4]  R1548     -1.2893269062042236e+00
    phi[2,4]  R1549     -1.2469331026077271e+00
    phi[2,4]  R1550     -1.6163178682327271e+00
    phi[2,4]  R1551     -2.6959180831909180e+00
    phi[2,4]  R1552     -1.1794676780700684e+00
    phi[2,4]  R1553     2.2276818752288818e-01
    phi[2,4]  R1554     3.7029001861810684e-02
    phi[2,4]  R1555     -2.7402403950691223e-01
    phi[2,4]  R1556     3.3768272399902344e-01
    phi[2,4]  R1557     -0.558380126953125
    phi[2,4]  R1558     3.6144825816154480e-01
    phi[2,4]  R1559     4.7950321435928345e-01
    phi[2,4]  R1560     5.3239285945892334e-01
    phi[2,4]  R1561     5.2750366926193237e-01
    phi[2,4]  R1562     9.3263971805572510e-01
    phi[2,4]  R1563     -2.5645124912261963e+00
    phi[2,4]  R1564     -2.4623322486877441e+00
    phi[2,4]  R1565     -3.0082054138183594e+00
    phi[2,4]  R1566     -1.0090082883834839e+00
    phi[2,4]  R1567     -8.9040565490722656e-01
    phi[2,4]  R1568     -2.1642878055572510e+00
    phi[2,4]  R1569     -1.7568511962890625e+00
    phi[2,4]  R1570     -1.8405609130859375e+00
    phi[2,4]  R1571     -1.9483366012573242e+00
    phi[2,4]  R1572     -2.1683411598205566e+00
    phi[2,4]  R1573     -4.9423295259475708e-01
    phi[2,4]  R1574     -2.1395049095153809e+00
    phi[2,4]  R1575     -2.1951858997344971e+00
    phi[2,4]  R1576     -2.07004714012146
    phi[2,4]  R1577     -1.8361315727233887e+00
    phi[2,4]  R1578     -7.6896792650222778e-01
    phi[2,4]  R1579     -2.8638944625854492e+00
    phi[2,4]  R1580     -2.5256137847900391e+00
    phi[2,4]  R1581     -9.4713938236236572e-01
    phi[2,4]  R1582     -2.1351103782653809e+00
    phi[2,4]  R1583     -1.8661818504333496e+00
    phi[2,4]  R1584     -1.5981520414352417e+00
    phi[2,4]  R1585     -2.0402641296386719e+00
    phi[2,4]  R1586     -1.1748509407043457e+00
    phi[2,4]  R1587     -2.0496413707733154e+00
    phi[2,4]  R1588     -2.5082964897155762e+00
    phi[2,4]  R1589     -2.4169750213623047e+00
    phi[2,4]  R1590     -2.3393447399139404e+00
    phi[2,4]  R1591     -1.4505541324615479e+00
    phi[2,4]  R1592     -6.0002660751342773e-01
    phi[2,4]  R1593     -2.3696417808532715e+00
    phi[2,4]  R1594     -1.6089435815811157e+00
    phi[2,4]  R1595     -2.1147453784942627e+00
    phi[2,4]  R1596     -2.2627146244049072e+00
    phi[2,4]  R1597     -2.0504148006439209e+00
    phi[2,4]  R1598     -2.1237349510192871e+00
    phi[2,4]  R1599     -2.5769648551940918e+00
    phi[2,4]  R1600     -4.5210966467857361e-01
    phi[2,4]  R1601     -1.1546884775161743e+00
    phi[2,4]  R1602     -1.7320551872253418e+00
    phi[2,4]  R1603     -1.6880097389221191e+00
    phi[2,4]  R1604     -1.6912654638290405e+00
    phi[2,4]  R1605     -7.6995092630386353e-01
    phi[2,4]  R1606     -1.3253802061080933e+00
    phi[2,4]  R1607     -2.3307590484619141e+00
    phi[2,4]  R1608     -2.0371737480163574e+00
    phi[2,4]  R1609     -1.4692775011062622e+00
    phi[2,4]  R1610     -2.5349173545837402e+00
    phi[2,4]  R1611     -1.4125108718872070e+00
    phi[2,4]  R1612     -1.3752728700637817e+00
    phi[2,4]  R1613     -2.6204290390014648e+00
    phi[2,4]  R1614     -1.8475852012634277e+00
    phi[2,4]  R1615     -3.1098883152008057e+00
    phi[2,4]  R1616     -1.3431684970855713e+00
    phi[2,4]  R1617     -8.9489841461181641e-01
    phi[2,4]  R1618     -8.0913382768630981e-01
    phi[2,4]  R1619     -1.4148331880569458e+00
    phi[2,4]  R1620     -7.3911887407302856e-01
    phi[2,4]  R1621     -1.9565033912658691e+00
    phi[2,4]  R1622     -1.6502164304256439e-01
    phi[2,4]  R1623     -1.1682033538818359e+00
    phi[2,4]  R1624     -2.5605266094207764e+00
    phi[2,4]  R1625     -1.9631146192550659e+00
    phi[2,4]  R1626     -2.1662850379943848e+00
    phi[2,4]  R1627     -2.7507803440093994e+00
    phi[2,4]  R1628     -2.1397206783294678e+00
    phi[2,4]  R1629     -7.1277356147766113e-01
    phi[2,4]  R1630     -1.7018672227859497e+00
    phi[2,4]  R1631     -1.8090885877609253e+00
    phi[2,4]  R1632     -2.2797913551330566e+00
    phi[2,4]  R1633     -8.4748250246047974e-01
    phi[2,4]  R1634     5.4007512331008911e-01
    phi[2,4]  R1635     -2.1078512668609619e+00
    phi[2,4]  R1636     -2.0483455657958984e+00
    phi[2,4]  R1637     -7.0774477720260620e-01
    phi[2,4]  R1638     -9.2972618341445923e-01
    phi[2,4]  R1639     -3.2528080940246582e+00
    phi[2,4]  R1640     -7.0197623968124390e-01
    phi[2,4]  R1641     -1.1618494987487793e+00
    phi[2,4]  R1642     -1.6450424194335938e+00
    phi[2,4]  R1643     -2.1258029937744141e+00
    phi[2,4]  R1644     -3.0885741710662842e+00
    phi[2,4]  R1645     -2.94913649559021
    phi[2,4]  R1646     -1.9539268016815186e+00
    phi[2,4]  R1647     -1.3973873853683472e+00
    phi[2,4]  R1648     -1.5839911699295044e+00
    phi[2,4]  R1649     -2.2295196056365967e+00
    phi[2,4]  R1650     -4.3555787205696106e-01
    phi[2,4]  R1651     -1.7578189373016357e+00
    phi[2,4]  R1652     -2.3268735408782959e+00
    phi[2,4]  R1653     -1.4632124900817871e+00
    phi[2,4]  R1654     -7.7642679214477539e-01
    phi[2,4]  R1655     -1.7279206514358521e+00
    phi[2,4]  R1656     -1.0904998779296875e+00
    phi[2,4]  R1657     -2.9578297138214111e+00
    phi[2,4]  R1658     -2.0215868949890137e+00
    phi[2,4]  R1659     -2.1015448570251465e+00
    phi[2,4]  R1660     -1.7755625247955322e+00
    phi[2,4]  R1661     -2.3339097499847412e+00
    phi[2,4]  R1662     -2.3203690052032471e+00
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1663     -3.0999999046325684e+00
    phi[4,2]  R1664     -3.0999999046325684e+00
    phi[4,2]  R1665     -2.2400000095367432e+00
    phi[4,2]  R1666     -2.2400000095367432e+00
    phi[4,2]  R1667     -3.0999999046325684e+00
    phi[4,2]  R1668     -3.0999999046325684e+00
    phi[4,2]  R1669     -2.5699999332427979e+00
    phi[4,2]  R1670     -2.5699999332427979e+00
    phi[4,2]  R1671     -3.0999999046325684e+00
    phi[4,2]  R1672     -3.0999999046325684e+00
    phi[4,2]  R1673     -2.0899999141693115e+00
    phi[4,2]  R1674     -2.0899999141693115e+00
    phi[4,2]  R1675     -3.0999999046325684e+00
    phi[4,2]  R1676     -3.0999999046325684e+00
    phi[4,2]  R1677     2.2276818752288818e-01
    phi[4,2]  R1678     3.7029001861810684e-02
    phi[4,2]  R1679     -2.7402403950691223e-01
    phi[4,2]  R1680     3.3768272399902344e-01
    phi[4,2]  R1681     -0.558380126953125
    phi[4,2]  R1682     3.6144825816154480e-01
    phi[4,2]  R1683     4.7950321435928345e-01
    phi[4,2]  R1684     5.3239285945892334e-01
    phi[4,2]  R1685     5.2750366926193237e-01
    phi[4,2]  R1686     9.3263971805572510e-01
    phi[4,2]  R1687     -2.5645124912261963e+00
    phi[4,2]  R1688     -2.4623322486877441e+00
    phi[4,2]  R1689     -3.0082054138183594e+00
    phi[4,2]  R1690     -1.0090082883834839e+00
    phi[4,2]  R1691     -8.9040565490722656e-01
    phi[4,2]  R1692     -2.1642878055572510e+00
    phi[4,2]  R1693     -1.7568511962890625e+00
    phi[4,2]  R1694     -1.8405609130859375e+00
    phi[4,2]  R1695     -1.9483366012573242e+00
    phi[4,2]  R1696     -2.1683411598205566e+00
    phi[4,2]  R1697     -4.9423295259475708e-01
    phi[4,2]  R1698     -2.1395049095153809e+00
    phi[4,2]  R1699     -2.1951858997344971e+00
    phi[4,2]  R1700     -2.07004714012146
    phi[4,2]  R1701     -1.8361315727233887e+00
    phi[4,2]  R1702     -7.6896792650222778e-01
    phi[4,2]  R1703     -2.8638944625854492e+00
    phi[4,2]  R1704     -2.5256137847900391e+00
    phi[4,2]  R1705     -9.4713938236236572e-01
    phi[4,2]  R1706     -2.1351103782653809e+00
    phi[4,2]  R1707     -1.8661818504333496e+00
    phi[4,2]  R1708     -1.5981520414352417e+00
    phi[4,2]  R1709     -2.0402641296386719e+00
    phi[4,2]  R1710     -1.1748509407043457e+00
    phi[4,2]  R1711     -2.0496413707733154e+00
    phi[4,2]  R1712     -2.5082964897155762e+00
    phi[4,2]  R1713     -2.4169750213623047e+00
    phi[4,2]  R1714     -2.3393447399139404e+00
    phi[4,2]  R1715     -1.4505541324615479e+00
    phi[4,2]  R1716     -6.0002660751342773e-01
    phi[4,2]  R1717     -2.3696417808532715e+00
    phi[4,2]  R1718     -1.6089435815811157e+00
    phi[4,2]  R1719     -2.1147453784942627e+00
    phi[4,2]  R1720     -2.2627146244049072e+00
    phi[4,2]  R1721     -2.0504148006439209e+00
    phi[4,2]  R1722     -2.1237349510192871e+00
    phi[4,2]  R1723     -2.5769648551940918e+00
    phi[4,2]  R1724     -4.5210966467857361e-01
    phi[4,2]  R1725     -1.1546884775161743e+00
    phi[4,2]  R1726     -1.7320551872253418e+00
    phi[4,2]  R1727     -1.6880097389221191e+00
    phi[4,2]  R1728     -1.6912654638290405e+00
    phi[4,2]  R1729     -7.6995092630386353e-01
    phi[4,2]  R1730     -1.3253802061080933e+00
    phi[4,2]  R1731     -2.3307590484619141e+00
    phi[4,2]  R1732     -2.0371737480163574e+00
    phi[4,2]  R1733     -1.4692775011062622e+00
    phi[4,2]  R1734     -2.5349173545837402e+00
    phi[4,2]  R1735     -1.4125108718872070e+00
    phi[4,2]  R1736     -1.3752728700637817e+00
    phi[4,2]  R1737     -2.6204290390014648e+00
    phi[4,2]  R1738     -1.8475852012634277e+00
    phi[4,2]  R1739     -3.1098883152008057e+00
    phi[4,2]  R1740     -1.3431684970855713e+00
    phi[4,2]  R1741     -8.9489841461181641e-01
    phi[4,2]  R1742     -8.0913382768630981e-01
    phi[4,2]  R1743     -1.4148331880569458e+00
    phi[4,2]  R1744     -7.3911887407302856e-01
    phi[4,2]  R1745     -1.9565033912658691e+00
    phi[4,2]  R1746     -1.6502164304256439e-01
    phi[4,2]  R1747     -1.1682033538818359e+00
    phi[4,2]  R1748     -2.5605266094207764e+00
    phi[4,2]  R1749     -1.9631146192550659e+00
    phi[4,2]  R1750     -2.1662850379943848e+00
    phi[4,2]  R1751     -2.7507803440093994e+00
    phi[4,2]  R1752     -2.1397206783294678e+00
    phi[4,2]  R1753     -7.1277356147766113e-01
    phi[4,2]  R1754     -1.7018672227859497e+00
    phi[4,2]  R1755     -1.8090885877609253e+00
    phi[4,2]  R1756     -2.2797913551330566e+00
    phi[4,2]  R1757     -8.4748250246047974e-01
    phi[4,2]  R1758     5.4007512331008911e-01
    phi[4,2]  R1759     -2.1078512668609619e+00
    phi[4,2]  R1760     -2.0483455657958984e+00
    phi[4,2]  R1761     -7.0774477720260620e-01
    phi[4,2]  R1762     -9.2972618341445923e-01
    phi[4,2]  R1763     -3.2528080940246582e+00
    phi[4,2]  R1764     -7.0197623968124390e-01
    phi[4,2]  R1765     -1.1618494987487793e+00
    phi[4,2]  R1766     -1.6450424194335938e+00
    phi[4,2]  R1767     -2.1258029937744141e+00
    phi[4,2]  R1768     -3.0885741710662842e+00
    phi[4,2]  R1769     -2.94913649559021
    phi[4,2]  R1770     -1.9539268016815186e+00
    phi[4,2]  R1771     -1.3973873853683472e+00
    phi[4,2]  R1772     -1.5839911699295044e+00
    phi[4,2]  R1773     -2.2295196056365967e+00
    phi[4,2]  R1774     -4.3555787205696106e-01
    phi[4,2]  R1775     -1.7578189373016357e+00
    phi[4,2]  R1776     -2.3268735408782959e+00
    phi[4,2]  R1777     -1.4632124900817871e+00
    phi[4,2]  R1778     -7.7642679214477539e-01
    phi[4,2]  R1779     -1.7279206514358521e+00
    phi[4,2]  R1780     -1.0904998779296875e+00
    phi[4,2]  R1781     -2.9578297138214111e+00
    phi[4,2]  R1782     -2.0215868949890137e+00
    phi[4,2]  R1783     -2.1015448570251465e+00
    phi[4,2]  R1784     -1.7755625247955322e+00
    phi[4,2]  R1785     -2.3339097499847412e+00
    phi[4,2]  R1786     -2.3203690052032471e+00
    phi[4,2]  R1787     6.4559715986251831e-01
    phi[4,2]  R1788     4.5916372537612915e-01
    phi[4,2]  R1789     4.8055320978164673e-01
    phi[4,2]  R1790     3.7455520033836365e-01
    phi[4,2]  R1791     -8.3785879611968994e-01
    phi[4,2]  R1792     -5.9451079368591309e-01
    phi[4,2]  R1793     -4.7600808739662170e-01
    phi[4,2]  R1794     2.7148500084877014e-01
    phi[4,2]  R1795     0.1130366101861
    phi[4,2]  R1796     -6.6303676366806030e-01
    phi[4,2]  R1797     -8.0951493978500366e-01
    phi[4,2]  R1798     -2.5891476869583130e-01
    phi[4,2]  R1799     -8.0352711677551270e-01
    phi[4,2]  R1800     -1.8874228000640869e+00
    phi[4,2]  R1801     -2.5974180698394775e+00
    phi[4,2]  R1802     -2.6128213405609131e+00
    phi[4,2]  R1803     -2.2439148426055908e+00
    phi[4,2]  R1804     -2.1159431934356689e+00
    phi[4,2]  R1805     -1.8922260999679565e+00
    phi[4,2]  R1806     -3.0244784355163574e+00
    phi[4,2]  R1807     -2.2940292358398438e+00
    phi[4,2]  R1808     -2.0555188655853271e+00
    phi[4,2]  R1809     -2.8691885471343994e+00
    phi[4,2]  R1810     -2.3858044147491455e+00
    phi[4,2]  R1811     -1.83588445186615
    phi[4,2]  R1812     -2.6945152282714844e+00
    phi[4,2]  R1813     -1.7065685987472534e+00
    phi[4,2]  R1814     -1.6010600328445435e+00
    phi[4,2]  R1815     -3.0781605243682861e+00
    phi[4,2]  R1816     -1.8596018552780151e+00
    phi[4,2]  R1817     -2.9251022338867188e+00
    phi[4,2]  R1818     -1.5946084260940552e+00
    phi[4,2]  R1819     -1.9536197185516357e+00
    phi[4,2]  R1820     -1.9141073226928711e+00
    phi[4,2]  R1821     -1.9262479543685913e+00
    phi[4,2]  R1822     -4.0857315063476562e+00
    phi[4,2]  R1823     -1.6861816644668579e+00
    phi[4,2]  R1824     -2.1007082462310791e+00
    phi[4,2]  R1825     -2.0144200325012207e+00
    phi[4,2]  R1826     -2.2645723819732666e+00
    phi[4,2]  R1827     -2.7373936772346497e-01
    phi[4,2]  R1828     -1.9503599405288696e+00
    phi[4,2]  R1829     -2.9933021068573
    phi[4,2]  R1830     -3.1349010467529297e+00
    phi[4,2]  R1831     -3.3092114925384521e+00
    phi[4,2]  R1832     -1.6174052953720093e+00
    phi[4,2]  R1833     -2.9014217853546143e+00
    phi[4,2]  R1834     -1.8061344623565674e+00
    phi[4,2]  R1835     -1.6370401382446289e+00
    phi[4,2]  R1836     -1.9503235816955566e+00
    phi[4,2]  R1837     -5.5120462179183960e-01
    phi[4,2]  R1838     -3.0070440769195557e+00
    phi[4,2]  R1839     -2.7877635955810547e+00
    phi[4,2]  R1840     -1.4084955453872681e+00
    phi[4,2]  R1841     -1.5117737054824829e+00
    phi[4,2]  R1842     -2.2070262432098389e+00
    phi[4,2]  R1843     -3.2820637226104736e+00
    phi[4,2]  R1844     -2.2329647541046143e+00
    phi[4,2]  R1845     -3.5413296222686768e+00
    phi[4,2]  R1846     -2.0176897048950195e+00
    phi[4,2]  R1847     -1.2447081804275513e+00
    phi[4,2]  R1848     -2.1725103855133057e+00
    phi[4,2]  R1849     -2.3181962966918945e+00
    phi[4,2]  R1850     -2.5905840396881104e+00
    phi[4,2]  R1851     -7.7069085836410522e-01
    phi[4,2]  R1852     -2.6716580390930176e+00
    phi[4,2]  R1853     -1.9927949905395508e+00
    phi[4,2]  R1854     -2.7345507144927979e+00
    phi[4,2]  R1855     -2.5340874195098877e+00
    phi[4,2]  R1856     -2.4101488590240479e+00
    phi[4,2]  R1857     -6.7530745267868042e-01
    phi[4,2]  R1858     -0.331532746553421
    phi[4,2]  R1859     -7.1518331766128540e-01
    phi[4,2]  R1860     -2.2097387313842773e+00
    phi[4,2]  R1861     -0.188564270734787
    phi[4,2]  R1862     -2.9340455532073975e+00
    phi[4,2]  R1863     -1.7658981084823608e+00
    phi[4,2]  R1864     -2.3129115104675293e+00
    phi[4,2]  R1865     -2.0004968643188477e+00
    phi[4,2]  R1866     -1.6520259380340576e+00
    phi[4,2]  R1867     -7.0179396867752075e-01
    phi[4,2]  R1868     -1.9338485598564148e-01
    phi[4,2]  R1869     -2.3957686424255371e+00
    phi[4,2]  R1870     -2.3699812889099121e+00
    phi[4,2]  R1871     -1.0914878845214844e+00
    phi[4,2]  R1872     -1.7712409496307373e+00
    phi[4,2]  R1873     -1.6024928092956543e+00
    phi[4,2]  R1874     -2.2782316207885742e+00
    phi[4,2]  R1875     -2.4188754558563232e+00
    phi[4,2]  R1876     -3.0373599529266357e+00
    phi[4,2]  R1877     -3.9094531536102295e-01
    phi[4,2]  R1878     -7.3785686492919922e-01
    phi[4,2]  R1879     -1.5853306055068970e+00
    phi[4,2]  R1880     -2.5782127380371094e+00
    phi[4,2]  R1881     -2.3790390491485596e+00
    phi[4,2]  R1882     -2.4555022716522217e+00
    phi[4,2]  R1883     -2.4904663562774658e+00
    phi[4,2]  R1884     -1.7184319496154785e+00
    phi[4,2]  R1885     -1.9494717121124268e+00
    phi[4,2]  R1886     -2.0469899177551270e+00
    phi[4,2]  R1887     -3.7546166777610779e-01
    phi[4,2]  R1888     -2.7554972171783447e+00
    phi[4,2]  R1889     -2.0122954845428467e+00
    phi[4,2]  R1890     -2.4201695919036865e+00
    phi[4,2]  R1891     -1.6185218095779419e+00
    phi[4,2]  R1892     -1.2893269062042236e+00
    phi[4,2]  R1893     -1.2469331026077271e+00
    phi[4,2]  R1894     -1.6163178682327271e+00
    phi[4,2]  R1895     -2.6959180831909180e+00
    phi[4,2]  R1896     -1.1794676780700684e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R20       -1.1920343856687263e+00
    phi[2,6]  R21       5.9631075070557560e-01
    phi[2,6]  R22       5.1574715658696668e-01
    phi[2,6]  R23       -2.9959401998392643e-02
    phi[2,6]  R24       1.3724988566432581e+00
    phi[2,6]  R25       -6.2704922472421742e-01
    phi[2,6]  R26       -7.1869616556818894e-01
    phi[2,6]  R46       -1
    phi[2,6]  R1897     -4.2920342903012951e+00
    phi[2,6]  R1898     -1.9079655189638420e+00
    phi[2,6]  R1899     -1.6436892588311676e+00
    phi[2,6]  R1900     -2.8363107602423190e+00
    phi[2,6]  R1901     -2.5842527480456017e+00
    phi[2,6]  R1902     -3.6157470612195350e+00
    phi[2,6]  R1903     -2.5999593352411905e+00
    phi[2,6]  R1904     -2.5400405312444052e+00
    phi[2,6]  R1905     -1.7275010479893103e+00
    phi[2,6]  R1906     -4.4724987612758262e+00
    phi[2,6]  R1907     -2.7170491388935289e+00
    phi[2,6]  R1908     -1.4629506894450941e+00
    phi[2,6]  R1909     -3.8186960702007573e+00
    phi[2,6]  R1910     -2.3813037390643794e+00
    phi[2,6]  R1911     -3.6863109840010755e-01
    phi[2,6]  R1912     -3.9188081526276231e-01
    phi[2,6]  R1913     -3.9691714915893983e-01
    phi[2,6]  R1914     -4.0421087024436964e-01
    phi[2,6]  R1915     -0.40676507541078
    phi[2,6]  R1916     -4.0803411180013116e-01
    phi[2,6]  R1917     -4.1229789862007810e-01
    phi[2,6]  R1918     -4.2137527654828322e-01
    phi[2,6]  R1919     -4.2547734545493954e-01
    phi[2,6]  R1920     -4.3711599374820787e-01
    phi[2,6]  R1921     -7.8999819956861250e-01
    phi[2,6]  R1922     -9.0737308980833642e-01
    phi[2,6]  R1923     -1.0238477575687139e+00
    phi[2,6]  R1924     -1.0279108684649532e+00
    phi[2,6]  R1925     -1.0855715501007717e+00
    phi[2,6]  R1926     -1.1272350866347225e+00
    phi[2,6]  R1927     -1.1395726696247837e+00
    phi[2,6]  R1928     -1.1500633756558516e+00
    phi[2,6]  R1929     -1.2517004316342040e+00
    phi[2,6]  R1930     -1.3086976316702101e+00
    phi[2,6]  R1931     -2.7005186816861517e+00
    phi[2,6]  R1932     -2.6595443831972831e+00
    phi[2,6]  R1933     -2.1485250583812037e+00
    phi[2,6]  R1934     -2.9620769452352396e+00
    phi[2,6]  R1935     -2.4587900322140448e+00
    phi[2,6]  R1936     -1.9306002842214784e+00
    phi[2,6]  R1937     -2.4208128182165343e+00
    phi[2,6]  R1938     -1.5803476437610635e+00
    phi[2,6]  R1939     -2.0331309518642389e+00
    phi[2,6]  R1940     -1.5906883420130906e+00
    phi[2,6]  R1941     -1.3544365013079613e+00
    phi[2,6]  R1942     -1.3983520148991866e+00
    phi[2,6]  R1943     -1.5546032325920223e+00
    phi[2,6]  R1944     -1.6147554578419077e+00
    phi[2,6]  R1945     -1.6551378186714214e+00
    phi[2,6]  R1946     -2.9359494733076312e+00
    phi[2,6]  R1947     -1.7116522624242017e+00
    phi[2,6]  R1948     -1.7649572148961388e+00
    phi[2,6]  R1949     -1.7838473955913683e+00
    phi[2,6]  R1950     -1.7909694803443028e+00
    phi[2,6]  R1951     -1.1521704067642493e+00
    phi[2,6]  R1952     -1.1531854051074553e+00
    phi[2,6]  R1953     -1.3582550844587273e+00
    phi[2,6]  R1954     -1.4239522391286479e+00
    phi[2,6]  R1955     -1.4267925919186422e+00
    phi[2,6]  R1956     -1.7448741054344334e+00
    phi[2,6]  R1957     -1.8989818107150771e+00
    phi[2,6]  R1958     -1.9042666821729082e+00
    phi[2,6]  R1959     -1.9884016731202465e+00
    phi[2,6]  R1960     -1.9901419337145059e+00
    phi[2,6]  R1961     -1.0135130836492245e+00
    phi[2,6]  R1962     -1.2625999859922303e+00
    phi[2,6]  R1963     -1.3430180546506882e+00
    phi[2,6]  R1964     -1.4890904420819731e+00
    phi[2,6]  R1965     -1.6519668832054955e+00
    phi[2,6]  R1966     -1.7361600777955464e+00
    phi[2,6]  R1967     -2.7173819795329339e+00
    phi[2,6]  R1968     -1.79904300790233
    phi[2,6]  R1969     -3.1098777057580458e+00
    phi[2,6]  R1970     -1.8546547878933852e+00
    phi[2,6]  R1971     -7.7146820546806860e-01
    phi[2,6]  R1972     -9.0076552234968865e-01
    phi[2,6]  R1973     -1.24487245247486
    phi[2,6]  R1974     -1.3496676389006468e+00
    phi[2,6]  R1975     -1.6132433983899959e+00
    phi[2,6]  R1976     -3.0765273767342602e+00
    phi[2,6]  R1977     -1.8757020971832863e+00
    phi[2,6]  R1978     -1.9929382938224209e+00
    phi[2,6]  R1979     -1.9932170267501554e+00
    phi[2,6]  R1980     -2.0107055945675194e+00
    phi[2,6]  R1981     -7.4965719139935283e-01
    phi[2,6]  R1982     -0.872734919735347
    phi[2,6]  R1983     -9.3282638863623968e-01
    phi[2,6]  R1984     -9.9878197950031034e-01
    phi[2,6]  R1985     -1.0962169980011280e+00
    phi[2,6]  R1986     -1.1646281522320596e+00
    phi[2,6]  R1987     -1.1742159893162643e+00
    phi[2,6]  R1988     -1.2969640021289648e+00
    phi[2,6]  R1989     -1.7917028802713155e+00
    phi[2,6]  R1990     -1.8162720940071257e+00
    phi[2,6]  R1991     -7.5539762358353690e-01
    phi[2,6]  R1992     -8.4426602663527262e-01
    phi[2,6]  R1993     -8.6547091725622116e-01
    phi[2,6]  R1994     -1.2908244592603406e+00
    phi[2,6]  R1995     -1.3046041897954761e+00
    phi[2,6]  R1996     -1.5498227212311859e+00
    phi[2,6]  R1997     -1.8731706743393222e+00
    phi[2,6]  R1998     -1.9134155356901625e+00
    phi[2,6]  R1999     -2.0719168803894683e+00
    phi[2,6]  R2000     -2.0817937848890922e+00
    phi[2,6]  R2001     -7.8023008089311774e-01
    phi[2,6]  R2002     -9.9130626086790641e-01
    phi[2,6]  R2003     -1.5169567934591226e+00
    phi[2,6]  R2004     -2.6708333917309566e+00
    phi[2,6]  R2005     -2.3728440292713335e+00
    phi[2,6]  R2006     -1.9970208128458142e+00
    phi[2,6]  R2007     -2.1315338572597886e+00
    phi[2,6]  R2008     -2.14968289231089
    phi[2,6]  R2009     -2.1798420364909505e+00
    phi[2,6]  R2010     -2.19545650178162
    phi[2,6]  R2011     -7.9432119680930813e-01
    phi[2,6]  R2012     -2.62380212172062
    phi[2,6]  R2013     -1.9735459246325413e+00
    phi[2,6]  R2014     -2.1477085675909540e+00
    phi[2,6]  R2015     -2.1874846663880954e+00
    phi[2,6]  R2016     -2.1886553048063542e+00
    phi[2,6]  R2017     -2.3477408950675729e+00
    phi[2,6]  R2018     -2.3663657572460912e+00
    phi[2,6]  R2019     -2.3866966779723620e+00
    phi[2,6]  R2020     -2.3906256840225621e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2021     -3.0999999046325684e+00
    phi[3,4]  R2022     -3.0999999046325684e+00
    phi[3,4]  R2023     -2.2400000095367432e+00
    phi[3,4]  R2024     -2.2400000095367432e+00
    phi[3,4]  R2025     -3.0999999046325684e+00
    phi[3,4]  R2026     -3.0999999046325684e+00
    phi[3,4]  R2027     -2.5699999332427979e+00
    phi[3,4]  R2028     -2.5699999332427979e+00
    phi[3,4]  R2029     -3.0999999046325684e+00
    phi[3,4]  R2030     -3.0999999046325684e+00
    phi[3,4]  R2031     -2.0899999141693115e+00
    phi[3,4]  R2032     -2.0899999141693115e+00
    phi[3,4]  R2033     -3.0999999046325684e+00
    phi[3,4]  R2034     -3.0999999046325684e+00
    phi[3,4]  R2035     1.6069425344467163e+00
    phi[3,4]  R2036     9.2706519365310669e-01
    phi[3,4]  R2037     1.54611074924469
    phi[3,4]  R2038     1.3110734224319458e+00
    phi[3,4]  R2039     1.1438255310058594e+00
    phi[3,4]  R2040     1.9603191614151
    phi[3,4]  R2041     1.7324629426002502e-01
    phi[3,4]  R2042     9.1675353050231934e-01
    phi[3,4]  R2043     -4.1927906870841980e-01
    phi[3,4]  R2044     -1.1207662820816040e+00
    phi[3,4]  R2045     -6.6371726989746094e-01
    phi[3,4]  R2046     -1.1094723939895630e+00
    phi[3,4]  R2047     -4.8450121283531189e-01
    phi[3,4]  R2048     -9.7202211618423462e-01
    phi[3,4]  R2049     -2.5104942321777344e+00
    phi[3,4]  R2050     -3.2774178981781006e+00
    phi[3,4]  R2051     -2.08794903755188
    phi[3,4]  R2052     -1.9125593900680542e+00
    phi[3,4]  R2053     -1.8138868808746338e+00
    phi[3,4]  R2054     -3.0459187030792236e+00
    phi[3,4]  R2055     2.2276818752288818e-01
    phi[3,4]  R2056     3.7029001861810684e-02
    phi[3,4]  R2057     -2.7402403950691223e-01
    phi[3,4]  R2058     3.3768272399902344e-01
    phi[3,4]  R2059     -0.558380126953125
    phi[3,4]  R2060     3.6144825816154480e-01
    phi[3,4]  R2061     4.7950321435928345e-01
    phi[3,4]  R2062     5.3239285945892334e-01
    phi[3,4]  R2063     5.2750366926193237e-01
    phi[3,4]  R2064     9.3263971805572510e-01
    phi[3,4]  R2065     -2.5645124912261963e+00
    phi[3,4]  R2066     -2.4623322486877441e+00
    phi[3,4]  R2067     -3.0082054138183594e+00
    phi[3,4]  R2068     -1.0090082883834839e+00
    phi[3,4]  R2069     -8.9040565490722656e-01
    phi[3,4]  R2070     -2.1642878055572510e+00
    phi[3,4]  R2071     -1.7568511962890625e+00
    phi[3,4]  R2072     -1.8405609130859375e+00
    phi[3,4]  R2073     -1.9483366012573242e+00
    phi[3,4]  R2074     -2.1683411598205566e+00
    phi[3,4]  R2075     -4.9423295259475708e-01
    phi[3,4]  R2076     -2.1395049095153809e+00
    phi[3,4]  R2077     -2.1951858997344971e+00
    phi[3,4]  R2078     -2.07004714012146
    phi[3,4]  R2079     -1.8361315727233887e+00
    phi[3,4]  R2080     -7.6896792650222778e-01
    phi[3,4]  R2081     -2.8638944625854492e+00
    phi[3,4]  R2082     -2.5256137847900391e+00
    phi[3,4]  R2083     -9.4713938236236572e-01
    phi[3,4]  R2084     -2.1351103782653809e+00
    phi[3,4]  R2085     -1.8661818504333496e+00
    phi[3,4]  R2086     -1.5981520414352417e+00
    phi[3,4]  R2087     -2.0402641296386719e+00
    phi[3,4]  R2088     -1.1748509407043457e+00
    phi[3,4]  R2089     -2.0496413707733154e+00
    phi[3,4]  R2090     -2.5082964897155762e+00
    phi[3,4]  R2091     -2.4169750213623047e+00
    phi[3,4]  R2092     -2.3393447399139404e+00
    phi[3,4]  R2093     -1.4505541324615479e+00
    phi[3,4]  R2094     -6.0002660751342773e-01
    phi[3,4]  R2095     -2.3696417808532715e+00
    phi[3,4]  R2096     -1.6089435815811157e+00
    phi[3,4]  R2097     -2.1147453784942627e+00
    phi[3,4]  R2098     -2.2627146244049072e+00
    phi[3,4]  R2099     -2.0504148006439209e+00
    phi[3,4]  R2100     -2.1237349510192871e+00
    phi[3,4]  R2101     -2.5769648551940918e+00
    phi[3,4]  R2102     -4.5210966467857361e-01
    phi[3,4]  R2103     -1.1546884775161743e+00
    phi[3,4]  R2104     -1.7320551872253418e+00
    phi[3,4]  R2105     -1.6880097389221191e+00
    phi[3,4]  R2106     -1.6912654638290405e+00
    phi[3,4]  R2107     -7.6995092630386353e-01
    phi[3,4]  R2108     -1.3253802061080933e+00
    phi[3,4]  R2109     -2.3307590484619141e+00
    phi[3,4]  R2110     -2.0371737480163574e+00
    phi[3,4]  R2111     -1.4692775011062622e+00
    phi[3,4]  R2112     -2.5349173545837402e+00
    phi[3,4]  R2113     -1.4125108718872070e+00
    phi[3,4]  R2114     -1.3752728700637817e+00
    phi[3,4]  R2115     -2.6204290390014648e+00
    phi[3,4]  R2116     -1.8475852012634277e+00
    phi[3,4]  R2117     -3.1098883152008057e+00
    phi[3,4]  R2118     -1.3431684970855713e+00
    phi[3,4]  R2119     -8.9489841461181641e-01
    phi[3,4]  R2120     -8.0913382768630981e-01
    phi[3,4]  R2121     -1.4148331880569458e+00
    phi[3,4]  R2122     -7.3911887407302856e-01
    phi[3,4]  R2123     -1.9565033912658691e+00
    phi[3,4]  R2124     -1.6502164304256439e-01
    phi[3,4]  R2125     -1.1682033538818359e+00
    phi[3,4]  R2126     -2.5605266094207764e+00
    phi[3,4]  R2127     -1.9631146192550659e+00
    phi[3,4]  R2128     -2.1662850379943848e+00
    phi[3,4]  R2129     -2.7507803440093994e+00
    phi[3,4]  R2130     -2.1397206783294678e+00
    phi[3,4]  R2131     -7.1277356147766113e-01
    phi[3,4]  R2132     -1.7018672227859497e+00
    phi[3,4]  R2133     -1.8090885877609253e+00
    phi[3,4]  R2134     -2.2797913551330566e+00
    phi[3,4]  R2135     -8.4748250246047974e-01
    phi[3,4]  R2136     5.4007512331008911e-01
    phi[3,4]  R2137     -2.1078512668609619e+00
    phi[3,4]  R2138     -2.0483455657958984e+00
    phi[3,4]  R2139     -7.0774477720260620e-01
    phi[3,4]  R2140     -9.2972618341445923e-01
    phi[3,4]  R2141     -3.2528080940246582e+00
    phi[3,4]  R2142     -7.0197623968124390e-01
    phi[3,4]  R2143     -1.1618494987487793e+00
    phi[3,4]  R2144     -1.6450424194335938e+00
    phi[3,4]  R2145     -2.1258029937744141e+00
    phi[3,4]  R2146     -3.0885741710662842e+00
    phi[3,4]  R2147     -2.94913649559021
    phi[3,4]  R2148     -1.9539268016815186e+00
    phi[3,4]  R2149     -1.3973873853683472e+00
    phi[3,4]  R2150     -1.5839911699295044e+00
    phi[3,4]  R2151     -2.2295196056365967e+00
    phi[3,4]  R2152     -4.3555787205696106e-01
    phi[3,4]  R2153     -1.7578189373016357e+00
    phi[3,4]  R2154     -2.3268735408782959e+00
    phi[3,4]  R2155     -1.4632124900817871e+00
    phi[3,4]  R2156     -7.7642679214477539e-01
    phi[3,4]  R2157     -1.7279206514358521e+00
    phi[3,4]  R2158     -1.0904998779296875e+00
    phi[3,4]  R2159     -2.9578297138214111e+00
    phi[3,4]  R2160     -2.0215868949890137e+00
    phi[3,4]  R2161     -2.1015448570251465e+00
    phi[3,4]  R2162     -1.7755625247955322e+00
    phi[3,4]  R2163     -2.3339097499847412e+00
    phi[3,4]  R2164     -2.3203690052032471e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2165     -3.0999999046325684e+00
    phi[4,3]  R2166     -3.0999999046325684e+00
    phi[4,3]  R2167     -2.2400000095367432e+00
    phi[4,3]  R2168     -2.2400000095367432e+00
    phi[4,3]  R2169     -3.0999999046325684e+00
    phi[4,3]  R2170     -3.0999999046325684e+00
    phi[4,3]  R2171     -2.5699999332427979e+00
    phi[4,3]  R2172     -2.5699999332427979e+00
    phi[4,3]  R2173     -3.0999999046325684e+00
    phi[4,3]  R2174     -3.0999999046325684e+00
    phi[4,3]  R2175     -2.0899999141693115e+00
    phi[4,3]  R2176     -2.0899999141693115e+00
    phi[4,3]  R2177     -3.0999999046325684e+00
    phi[4,3]  R2178     -3.0999999046325684e+00
    phi[4,3]  R2179     2.2276818752288818e-01
    phi[4,3]  R2180     3.7029001861810684e-02
    phi[4,3]  R2181     -2.7402403950691223e-01
    phi[4,3]  R2182     3.3768272399902344e-01
    phi[4,3]  R2183     -0.558380126953125
    phi[4,3]  R2184     3.6144825816154480e-01
    phi[4,3]  R2185     4.7950321435928345e-01
    phi[4,3]  R2186     5.3239285945892334e-01
    phi[4,3]  R2187     5.2750366926193237e-01
    phi[4,3]  R2188     9.3263971805572510e-01
    phi[4,3]  R2189     -2.5645124912261963e+00
    phi[4,3]  R2190     -2.4623322486877441e+00
    phi[4,3]  R2191     -3.0082054138183594e+00
    phi[4,3]  R2192     -1.0090082883834839e+00
    phi[4,3]  R2193     -8.9040565490722656e-01
    phi[4,3]  R2194     -2.1642878055572510e+00
    phi[4,3]  R2195     -1.7568511962890625e+00
    phi[4,3]  R2196     -1.8405609130859375e+00
    phi[4,3]  R2197     -1.9483366012573242e+00
    phi[4,3]  R2198     -2.1683411598205566e+00
    phi[4,3]  R2199     -4.9423295259475708e-01
    phi[4,3]  R2200     -2.1395049095153809e+00
    phi[4,3]  R2201     -2.1951858997344971e+00
    phi[4,3]  R2202     -2.07004714012146
    phi[4,3]  R2203     -1.8361315727233887e+00
    phi[4,3]  R2204     -7.6896792650222778e-01
    phi[4,3]  R2205     -2.8638944625854492e+00
    phi[4,3]  R2206     -2.5256137847900391e+00
    phi[4,3]  R2207     -9.4713938236236572e-01
    phi[4,3]  R2208     -2.1351103782653809e+00
    phi[4,3]  R2209     -1.8661818504333496e+00
    phi[4,3]  R2210     -1.5981520414352417e+00
    phi[4,3]  R2211     -2.0402641296386719e+00
    phi[4,3]  R2212     -1.1748509407043457e+00
    phi[4,3]  R2213     -2.0496413707733154e+00
    phi[4,3]  R2214     -2.5082964897155762e+00
    phi[4,3]  R2215     -2.4169750213623047e+00
    phi[4,3]  R2216     -2.3393447399139404e+00
    phi[4,3]  R2217     -1.4505541324615479e+00
    phi[4,3]  R2218     -6.0002660751342773e-01
    phi[4,3]  R2219     -2.3696417808532715e+00
    phi[4,3]  R2220     -1.6089435815811157e+00
    phi[4,3]  R2221     -2.1147453784942627e+00
    phi[4,3]  R2222     -2.2627146244049072e+00
    phi[4,3]  R2223     -2.0504148006439209e+00
    phi[4,3]  R2224     -2.1237349510192871e+00
    phi[4,3]  R2225     -2.5769648551940918e+00
    phi[4,3]  R2226     -4.5210966467857361e-01
    phi[4,3]  R2227     -1.1546884775161743e+00
    phi[4,3]  R2228     -1.7320551872253418e+00
    phi[4,3]  R2229     -1.6880097389221191e+00
    phi[4,3]  R2230     -1.6912654638290405e+00
    phi[4,3]  R2231     -7.6995092630386353e-01
    phi[4,3]  R2232     -1.3253802061080933e+00
    phi[4,3]  R2233     -2.3307590484619141e+00
    phi[4,3]  R2234     -2.0371737480163574e+00
    phi[4,3]  R2235     -1.4692775011062622e+00
    phi[4,3]  R2236     -2.5349173545837402e+00
    phi[4,3]  R2237     -1.4125108718872070e+00
    phi[4,3]  R2238     -1.3752728700637817e+00
    phi[4,3]  R2239     -2.6204290390014648e+00
    phi[4,3]  R2240     -1.8475852012634277e+00
    phi[4,3]  R2241     -3.1098883152008057e+00
    phi[4,3]  R2242     -1.3431684970855713e+00
    phi[4,3]  R2243     -8.9489841461181641e-01
    phi[4,3]  R2244     -8.0913382768630981e-01
    phi[4,3]  R2245     -1.4148331880569458e+00
    phi[4,3]  R2246     -7.3911887407302856e-01
    phi[4,3]  R2247     -1.9565033912658691e+00
    phi[4,3]  R2248     -1.6502164304256439e-01
    phi[4,3]  R2249     -1.1682033538818359e+00
    phi[4,3]  R2250     -2.5605266094207764e+00
    phi[4,3]  R2251     -1.9631146192550659e+00
    phi[4,3]  R2252     -2.1662850379943848e+00
    phi[4,3]  R2253     -2.7507803440093994e+00
    phi[4,3]  R2254     -2.1397206783294678e+00
    phi[4,3]  R2255     -7.1277356147766113e-01
    phi[4,3]  R2256     -1.7018672227859497e+00
    phi[4,3]  R2257     -1.8090885877609253e+00
    phi[4,3]  R2258     -2.2797913551330566e+00
    phi[4,3]  R2259     -8.4748250246047974e-01
    phi[4,3]  R2260     5.4007512331008911e-01
    phi[4,3]  R2261     -2.1078512668609619e+00
    phi[4,3]  R2262     -2.0483455657958984e+00
    phi[4,3]  R2263     -7.0774477720260620e-01
    phi[4,3]  R2264     -9.2972618341445923e-01
    phi[4,3]  R2265     -3.2528080940246582e+00
    phi[4,3]  R2266     -7.0197623968124390e-01
    phi[4,3]  R2267     -1.1618494987487793e+00
    phi[4,3]  R2268     -1.6450424194335938e+00
    phi[4,3]  R2269     -2.1258029937744141e+00
    phi[4,3]  R2270     -3.0885741710662842e+00
    phi[4,3]  R2271     -2.94913649559021
    phi[4,3]  R2272     -1.9539268016815186e+00
    phi[4,3]  R2273     -1.3973873853683472e+00
    phi[4,3]  R2274     -1.5839911699295044e+00
    phi[4,3]  R2275     -2.2295196056365967e+00
    phi[4,3]  R2276     -4.3555787205696106e-01
    phi[4,3]  R2277     -1.7578189373016357e+00
    phi[4,3]  R2278     -2.3268735408782959e+00
    phi[4,3]  R2279     -1.4632124900817871e+00
    phi[4,3]  R2280     -7.7642679214477539e-01
    phi[4,3]  R2281     -1.7279206514358521e+00
    phi[4,3]  R2282     -1.0904998779296875e+00
    phi[4,3]  R2283     -2.9578297138214111e+00
    phi[4,3]  R2284     -2.0215868949890137e+00
    phi[4,3]  R2285     -2.1015448570251465e+00
    phi[4,3]  R2286     -1.7755625247955322e+00
    phi[4,3]  R2287     -2.3339097499847412e+00
    phi[4,3]  R2288     -2.3203690052032471e+00
    phi[4,3]  R2289     1.6069425344467163e+00
    phi[4,3]  R2290     9.2706519365310669e-01
    phi[4,3]  R2291     1.54611074924469
    phi[4,3]  R2292     1.3110734224319458e+00
    phi[4,3]  R2293     1.1438255310058594e+00
    phi[4,3]  R2294     1.9603191614151
    phi[4,3]  R2295     1.7324629426002502e-01
    phi[4,3]  R2296     9.1675353050231934e-01
    phi[4,3]  R2297     -4.1927906870841980e-01
    phi[4,3]  R2298     -1.1207662820816040e+00
    phi[4,3]  R2299     -6.6371726989746094e-01
    phi[4,3]  R2300     -1.1094723939895630e+00
    phi[4,3]  R2301     -4.8450121283531189e-01
    phi[4,3]  R2302     -9.7202211618423462e-01
    phi[4,3]  R2303     -2.5104942321777344e+00
    phi[4,3]  R2304     -3.2774178981781006e+00
    phi[4,3]  R2305     -2.08794903755188
    phi[4,3]  R2306     -1.9125593900680542e+00
    phi[4,3]  R2307     -1.8138868808746338e+00
    phi[4,3]  R2308     -3.0459187030792236e+00
    phi[5,3]  R27       -1
    phi[5,3]  R29       -2.1742985995609581e+00
    phi[5,3]  R30       -5.7278550663629968e-01
    phi[5,3]  R31       2.0765553714287610e+00
    phi[5,3]  R32       -2.2315018509826006e+00
    phi[5,3]  R33       5.3603954029638556e-01
    phi[5,3]  R34       1.3841513652476629e+00
    phi[5,3]  R35       2.63457743450762
    phi[5,3]  R45       1
    phi[5,3]  R2309     -9.2570130507161030e-01
    phi[5,3]  R2310     -5.2742985041935260e+00
    phi[5,3]  R2311     -1.6672145029004435e+00
    phi[5,3]  R2312     -2.8127855161730428e+00
    phi[5,3]  R2313     -5.1765552760613289e+00
    phi[5,3]  R2314     -1.0234445332038073e+00
    phi[5,3]  R2315     -3.3849808226019729e-01
    phi[5,3]  R2316     -4.8015017842253984e+00
    phi[5,3]  R2317     -3.6360394449289539e+00
    phi[5,3]  R2318     -2.5639603643361828e+00
    phi[5,3]  R2319     -3.4741512794169744e+00
    phi[5,3]  R2320     -7.0584854892164861e-01
    phi[5,3]  R2321     -5.7345773391401877e+00
    phi[5,3]  R2322     -4.6542247012494853e-01
    phi[5,3]  R2323     -1.9598790074378125e-01
    phi[5,3]  R2324     -2.3062491751835923e-01
    phi[5,3]  R2325     -2.3608359901593090e-01
    phi[5,3]  R2326     -2.5400023495787338e-01
    phi[5,3]  R2327     -0.255031214809041
    phi[5,3]  R2328     -2.5734624593620081e-01
    phi[5,3]  R2329     -2.7231615675142828e-01
    phi[5,3]  R2330     -3.1238976514477246e-01
    phi[5,3]  R2331     -3.5306288877687264e-01
    phi[5,3]  R2332     -4.2886163970474578e-01
    phi[5,3]  R2333     -2.8826631817384696e-01
    phi[5,3]  R2334     -3.4242469065799219e-01
    phi[5,3]  R2335     -5.2028302825110839e-01
    phi[5,3]  R2336     -7.7314367322672528e-01
    phi[5,3]  R2337     -8.4787713765449579e-01
    phi[5,3]  R2338     -1.4937415466824135e+00
    phi[5,3]  R2339     -1.5020255441271522e+00
    phi[5,3]  R2340     -1.9140932868146090e+00
    phi[5,3]  R2341     -1.9165881714121866e+00
    phi[5,3]  R2342     -2.0158761394403824e+00
    phi[4,6]  R36       1
    phi[4,6]  R37       1
    phi[4,6]  R38       -1.1920343856687263e+00
    phi[4,6]  R39       5.9631075070557560e-01
    phi[4,6]  R40       5.1574715658696668e-01
    phi[4,6]  R41       -2.9959401998392643e-02
    phi[4,6]  R42       1.3724988566432581e+00
    phi[4,6]  R43       -6.2704922472421742e-01
    phi[4,6]  R44       -7.1869616556818894e-01
    phi[4,6]  R46       -1
    phi[4,6]  R2343     -4.2920342903012951e+00
    phi[4,6]  R2344     -1.9079655189638420e+00
    phi[4,6]  R2345     -1.6436892588311676e+00
    phi[4,6]  R2346     -2.8363107602423190e+00
    phi[4,6]  R2347     -2.5842527480456017e+00
    phi[4,6]  R2348     -3.6157470612195350e+00
    phi[4,6]  R2349     -2.5999593352411905e+00
    phi[4,6]  R2350     -2.5400405312444052e+00
    phi[4,6]  R2351     -1.7275010479893103e+00
    phi[4,6]  R2352     -4.4724987612758262e+00
    phi[4,6]  R2353     -2.7170491388935289e+00
    phi[4,6]  R2354     -1.4629506894450941e+00
    phi[4,6]  R2355     -3.8186960702007573e+00
    phi[4,6]  R2356     -2.3813037390643794e+00
    phi[4,6]  R2357     -3.8769677266776259e-01
    phi[4,6]  R2358     -3.9022448951418776e-01
    phi[4,6]  R2359     -3.9666044527811251e-01
    phi[4,6]  R2360     -3.9799795960986528e-01
    phi[4,6]  R2361     -4.0045624749529957e-01
    phi[4,6]  R2362     -4.0236212604035526e-01
    phi[4,6]  R2363     -4.0503473040745042e-01
    phi[4,6]  R2364     -4.1221153135787458e-01
    phi[4,6]  R2365     -4.1709022654580563e-01
    phi[4,6]  R2366     -4.2675703675755572e-01
    phi[4,6]  R2367     -1.0548200859093009e+00
    phi[4,6]  R2368     -1.1135905596912468e+00
    phi[4,6]  R2369     -1.1188452940530242e+00
    phi[4,6]  R2370     -1.8349414319200750e+00
    phi[4,6]  R2371     -1.2157378610547860e+00
    phi[4,6]  R2372     -1.2239568141048804e+00
    phi[4,6]  R2373     -1.2357276963825177e+00
    phi[4,6]  R2374     -1.2516315251537464e+00
    phi[4,6]  R2375     -1.2622472913271932e+00
    phi[4,6]  R2376     -1.2762671130272336e+00
    phi[4,6]  R2377     -0.865677957828232
    phi[4,6]  R2378     -9.9422892699113019e-01
    phi[4,6]  R2379     -1.1382789419539483e+00
    phi[4,6]  R2380     -1.2629207600450745e+00
    phi[4,6]  R2381     -1.3237496085112348e+00
    phi[4,6]  R2382     -2.0199052749116948e+00
    phi[4,6]  R2383     -2.8347723433890080e+00
    phi[4,6]  R2384     -1.5771216712720517e+00
    phi[4,6]  R2385     -1.6456767568611035e+00
    phi[4,6]  R2386     -1.6514401984951614e+00
    phi[4,6]  R2387     -7.9035516226630742e-01
    phi[4,6]  R2388     -9.6512676622212679e-01
    phi[4,6]  R2389     -1.0085977296815152e+00
    phi[4,6]  R2390     -1.0806777564600840e+00
    phi[4,6]  R2391     -1.1136898745857868e+00
    phi[4,6]  R2392     -1.1673031661859472e+00
    phi[4,6]  R2393     -1.3130961241075938e+00
    phi[4,6]  R2394     -1.3675878821802367e+00
    phi[4,6]  R2395     -1.8358826577732474e+00
    phi[4,6]  R2396     -1.6202112910875683e+00
    phi[4,6]  R2397     -8.0030312349899524e-01
    phi[4,6]  R2398     -9.2634882492879944e-01
    phi[4,6]  R2399     -9.3918479192322257e-01
    phi[4,6]  R2400     -1.1262970683881421e+00
    phi[4,6]  R2401     -1.17049333043578
    phi[4,6]  R2402     -1.4096277614751997e+00
    phi[4,6]  R2403     -1.4440667376636536e+00
    phi[4,6]  R2404     -1.5270886693605183e+00
    phi[4,6]  R2405     -1.9158196395294689e+00
    phi[4,6]  R2406     -2.6309391718826589e+00
    phi[4,6]  R2407     -0.663639991168631
    phi[4,6]  R2408     -0.721121448312372
    phi[4,6]  R2409     -0.772097474394425
    phi[4,6]  R2410     -9.7214376517986123e-01
    phi[4,6]  R2411     -1.0503213281598127e+00
    phi[4,6]  R2412     -1.3010574225712981e+00
    phi[4,6]  R2413     -1.3120836269049492e+00
    phi[4,6]  R2414     -1.3503371971903342e+00
    phi[4,6]  R2415     -1.8472478541024795e+00
    phi[4,6]  R2416     -1.9749977989116418e+00
    phi[4,6]  R2417     -1.1407017603237157e+00
    phi[4,6]  R2418     -1.2092618426586048e+00
    phi[4,6]  R2419     -1.2189158477204316e+00
    phi[4,6]  R2420     -1.4670970490606610e+00
    phi[4,6]  R2421     -1.6627625659675762e+00
    phi[4,6]  R2422     -2.1467319167234522e+00
    phi[4,6]  R2423     -2.4789030001659675e+00
    phi[4,6]  R2424     -1.7336490924091215e+00
    phi[4,6]  R2425     -1.7551447208670983e+00
    phi[4,6]  R2426     -1.7858611007912761e+00
    phi[4,6]  R2427     -7.3813094869247009e-01
    phi[4,6]  R2428     -1.0190836973545003e+00
    phi[4,6]  R2429     -1.0737621353652940e+00
    phi[4,6]  R2430     -1.1417814463234537e+00
    phi[4,6]  R2431     -1.2034539664701711e+00
    phi[4,6]  R2432     -1.3175127859461577e+00
    phi[4,6]  R2433     -1.6792705650593545e+00
    phi[4,6]  R2434     -2.5012111945188420e+00
    phi[4,6]  R2435     -2.4294137291658888e+00
    phi[4,6]  R2436     -2.5765538152634537e+00
    phi[4,6]  R2437     -7.4218811370203830e-01
    phi[4,6]  R2438     -1.1960272397253018e+00
    phi[4,6]  R2439     -2.9855771058194254e+00
    phi[4,6]  R2440     -1.5731764110228301e+00
    phi[4,6]  R2441     -1.5992992097713974e+00
    phi[4,6]  R2442     -2.1415836541509563e+00
    phi[4,6]  R2443     -2.7782870049526149e+00
    phi[4,6]  R2444     -2.0868357628954275e+00
    phi[4,6]  R2445     -2.3550153687222282e+00
    phi[4,6]  R2446     -1.8209886287862738e+00
    phi[4,6]  R2447     -9.3626104877306138e-01
    phi[4,6]  R2448     -1.1411556748931968e+00
    phi[4,6]  R2449     -1.2184070609831190e+00
    phi[4,6]  R2450     -1.4165705288036556e+00
    phi[4,6]  R2451     -2.4487589031462962e+00
    phi[4,6]  R2452     -2.4000428789163379e+00
    phi[4,6]  R2453     -2.1724373862937978e+00
    phi[4,6]  R2454     -1.6899311299922986e+00
    phi[4,6]  R2455     -1.8412817160226176e+00
    phi[4,6]  R2456     -1.8475159457108159e+00
    phi[4,6]  R2457     -1.35668734239611
    phi[4,6]  R2458     -1.8850071308233578e+00
    phi[4,6]  R2459     -1.9777062419050087e+00
    phi[4,6]  R2460     -2.0055260420970571e+00
    phi[4,6]  R2461     -2.5350153054919908e+00
    phi[4,6]  R2462     -2.2031995938557296e+00
    phi[4,6]  R2463     -1.8569969292488404e+00
    phi[4,6]  R2464     -1.8596038167818283e+00
    phi[4,6]  R2465     -1.8803549489750344e+00
    phi[4,6]  R2466     -1.8948392003060071e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R47       -1
    z[0,1,0]  R48       1
    z[0,1,0]  R61       6.1997342109680176e-01
    z[0,1,0]  R62       6.1377388238906860e-01
    z[0,1,0]  R63       8.1624311208724976e-01
    z[0,1,0]  R64       6.6854131221771240e-01
    z[0,1,0]  R65       5.7189089059829712e-01
    z[0,1,0]  R66       6.0928791761398315e-01
    z[0,1,0]  R67       5.4106467962265015e-01
    z[0,1,0]  R68       1.5430673956871033e-01
    z[0,1,0]  R69       3.4609189629554749e-01
    z[0,1,0]  R70       5.4998338222503662e-01
    z[0,1,0]  R71       2.5184392929077148e-01
    z[0,1,0]  R72       -3.5679784417152405e-01
    z[0,1,0]  R73       -3.7212127447128296e-01
    z[0,1,0]  R74       -3.9635765552520752e-01
    z[0,1,0]  R75       -3.9194595813751221e-01
    z[0,1,0]  R76       -4.8806375265121460e-01
    z[0,1,0]  R77       -7.5151152908802032e-02
    z[0,1,0]  R78       5.0344437360763550e-02
    z[0,1,0]  R79       -4.3500930070877075e-01
    z[0,1,0]  R80       -1.4791879057884216e-01
    z[0,1,0]  R81       1.0895483195781708e-01
    z[0,1,0]  R82       0.0934840589761734
    z[0,1,0]  R83       3.0696392059326172e-01
    z[0,1,0]  R84       -2.8118395805358887e-01
    z[0,1,0]  R85       -2.0352919399738312e-01
    z[0,1,0]  R86       2.3840183019638062e-01
    z[0,1,0]  R87       6.5376496315002441e-01
    z[0,1,0]  R88       7.3611110448837280e-02
    z[0,1,0]  R89       6.6353899240493774e-01
    z[0,1,0]  R90       -2.6388000696897507e-03
    z[0,1,0]  R91       -1.3830715417861938e-01
    z[0,1,0]  R92       1.3887564837932587e-01
    z[0,1,0]  R93       -3.9402008056640625e-02
    z[0,1,0]  R94       -5.8835762739181519e-01
    z[0,1,0]  R95       1.6388840973377228e-02
    z[0,1,0]  R96       -4.1222300380468369e-02
    z[0,1,0]  R97       2.8189649805426598e-02
    z[0,1,0]  R98       -1.3297820091247559e-01
    z[0,1,0]  R99       -0.200653538107872
    z[0,1,0]  R100      -1.1196637898683548e-01
    z[0,1,0]  R101      7.7385380864143372e-02
    z[0,1,0]  R102      -9.9324166774749756e-02
    z[0,1,0]  R103      -3.5108867287635803e-01
    z[0,1,0]  R104      -6.3792335987091064e-01
    z[0,1,0]  R105      7.3212879896163940e-01
    z[0,1,0]  R106      4.4521890580654144e-02
    z[0,1,0]  R107      1.0701041668653488e-01
    z[0,1,0]  R108      8.5760957002639771e-01
    z[0,1,0]  R109      6.5180635452270508e-01
    z[0,1,0]  R110      7.6279711723327637e-01
    z[0,1,0]  R111      2.7415168285369873e-01
    z[0,1,0]  R112      -0.303154855966568
    z[0,1,0]  R113      -0.588360071182251
    z[0,1,0]  R114      -3.6815574765205383e-01
    z[0,1,0]  R115      1.2681372463703156e-01
    z[0,1,0]  R116      -9.6772246062755585e-02
    z[0,1,0]  R117      -1.7005759477615356e-01
    z[0,1,0]  R118      -1.2802829733118415e-03
    z[0,1,0]  R119      -5.3634065389633179e-01
    z[0,1,0]  R120      -5.5998134613037109e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R49       -1
    z[0,1,1]  R50       1
    z[0,1,1]  R61       -1.6295786201953888e-01
    z[0,1,1]  R62       -1.2111399322748184e-01
    z[0,1,1]  R63       -2.0713490247726440e-01
    z[0,1,1]  R64       -1.6520245373249054e-01
    z[0,1,1]  R65       -1.8242236971855164e-01
    z[0,1,1]  R66       2.5737902522087097e-01
    z[0,1,1]  R67       2.1483238041400909e-01
    z[0,1,1]  R68       7.1263438463211060e-01
    z[0,1,1]  R69       5.1909154653549194e-01
    z[0,1,1]  R70       -2.3365914821624756e-01
    z[0,1,1]  R71       1.7744581401348114e-01
    z[0,1,1]  R72       5.0638526678085327e-01
    z[0,1,1]  R73       -7.5885814428329468e-01
    z[0,1,1]  R74       -0.867509126663208
    z[0,1,1]  R75       -7.6405006647109985e-01
    z[0,1,1]  R76       -7.5097453594207764e-01
    z[0,1,1]  R77       -7.3848491907119751e-01
    z[0,1,1]  R78       -7.3716473579406738e-01
    z[0,1,1]  R79       -0.848032534122467
    z[0,1,1]  R80       -7.0639103651046753e-01
    z[0,1,1]  R81       -4.6671545505523682e-01
    z[0,1,1]  R82       -1.3359937071800232e-01
    z[0,1,1]  R83       -5.4755187034606934e-01
    z[0,1,1]  R84       -4.5454701781272888e-01
    z[0,1,1]  R85       8.2258599996566772e-01
    z[0,1,1]  R86       8.3536797761917114e-01
    z[0,1,1]  R87       6.0298210382461548e-01
    z[0,1,1]  R88       6.8687140941619873e-01
    z[0,1,1]  R89       2.5713574886322021e-01
    z[0,1,1]  R90       8.2437044382095337e-01
    z[0,1,1]  R91       -6.3565254211425781e-01
    z[0,1,1]  R92       -2.6428091526031494e-01
    z[0,1,1]  R93       -3.4266650676727295e-01
    z[0,1,1]  R94       1.7891493439674377e-01
    z[0,1,1]  R95       -8.8861101539805532e-04
    z[0,1,1]  R96       7.3406648635864258e-01
    z[0,1,1]  R97       7.5357919931411743e-01
    z[0,1,1]  R98       0.777441143989563
    z[0,1,1]  R99       8.4087914228439331e-01
    z[0,1,1]  R100      6.7594271898269653e-01
    z[0,1,1]  R101      -3.0124077200889587e-01
    z[0,1,1]  R102      -3.4512379765510559e-01
    z[0,1,1]  R103      -7.5806662440299988e-02
    z[0,1,1]  R104      1.4388592541217804e-01
    z[0,1,1]  R105      5.3881222009658813e-01
    z[0,1,1]  R106      8.3683592081069946e-01
    z[0,1,1]  R107      8.5966998338699341e-01
    z[0,1,1]  R108      3.2006371021270752e-01
    z[0,1,1]  R109      5.7017904520034790e-01
    z[0,1,1]  R110      5.0148993730545044e-01
    z[0,1,1]  R111      -3.6733394861221313e-01
    z[0,1,1]  R112      3.8637730479240417e-01
    z[0,1,1]  R113      5.2368111908435822e-02
    z[0,1,1]  R114      1.3667643070220947e-01
    z[0,1,1]  R115      7.8310316801071167e-01
    z[0,1,1]  R116      9.3387198448181152e-01
    z[0,1,1]  R117      7.3081928491592407e-01
    z[0,1,1]  R118      6.8152934312820435e-01
    z[0,1,1]  R119      7.1633970737457275e-01
    z[0,1,1]  R120      6.6614228487014771e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R51       -1
    z[0,1,2]  R52       1
    z[0,1,2]  R61       -4.6617171168327332e-01
    z[0,1,2]  R62       -4.1499951481819153e-01
    z[0,1,2]  R63       -1.5257543325424194e-01
    z[0,1,2]  R64       -2.0673599094152451e-02
    z[0,1,2]  R65       -4.3370109796524048e-01
    z[0,1,2]  R66       -0.568998396396637
    z[0,1,2]  R67       -6.6024476289749146e-01
    z[0,1,2]  R68       2.5652045011520386e-01
    z[0,1,2]  R69       2.7954699471592903e-02
    z[0,1,2]  R70       -2.3353826999664307e-01
    z[0,1,2]  R71       0.646335244178772
    z[0,1,2]  R72       1.0253693908452988e-01
    z[0,1,2]  R73       1.6495698690414429e-01
    z[0,1,2]  R74       0.0147220054641366
    z[0,1,2]  R75       -2.7216812968254089e-01
    z[0,1,2]  R76       -1.0292558372020721e-01
    z[0,1,2]  R77       -1.1488610878586769e-02
    z[0,1,2]  R78       1.6968281567096710e-01
    z[0,1,2]  R79       -1.8358199298381805e-01
    z[0,1,2]  R80       -3.1358856707811356e-02
    z[0,1,2]  R81       -4.8679551482200623e-01
    z[0,1,2]  R82       3.6904752254486084e-02
    z[0,1,2]  R83       7.8874669969081879e-02
    z[0,1,2]  R84       -2.1364346146583557e-01
    z[0,1,2]  R85       1.3000316917896271e-01
    z[0,1,2]  R86       -1.4253102242946625e-01
    z[0,1,2]  R87       -8.2498893141746521e-02
    z[0,1,2]  R88       3.2142437994480133e-02
    z[0,1,2]  R89       2.2951868176460266e-01
    z[0,1,2]  R90       -1.9364626705646515e-01
    z[0,1,2]  R91       4.1217097640037537e-01
    z[0,1,2]  R92       1.3405339419841766e-01
    z[0,1,2]  R93       -2.9808761551976204e-02
    z[0,1,2]  R94       -4.6589165925979614e-01
    z[0,1,2]  R95       9.4442255795001984e-02
    z[0,1,2]  R96       1.6268730163574219e-01
    z[0,1,2]  R97       4.9862369894981384e-02
    z[0,1,2]  R98       2.4379999935626984e-01
    z[0,1,2]  R99       1.8106689676642418e-02
    z[0,1,2]  R100      2.1392691135406494e-01
    z[0,1,2]  R101      -6.2701150774955750e-02
    z[0,1,2]  R102      -2.3533287644386292e-01
    z[0,1,2]  R103      -2.0075348019599915e-01
    z[0,1,2]  R104      -4.6012011170387268e-01
    z[0,1,2]  R105      2.8811085224151611e-01
    z[0,1,2]  R106      2.3537848889827728e-01
    z[0,1,2]  R107      3.6041319370269775e-01
    z[0,1,2]  R108      3.1767565011978149e-01
    z[0,1,2]  R109      4.6150788664817810e-01
    z[0,1,2]  R110      3.1205204129219055e-01
    z[0,1,2]  R111      3.9079514145851135e-01
    z[0,1,2]  R112      -4.7543495893478394e-01
    z[0,1,2]  R113      -3.3568689227104187e-01
    z[0,1,2]  R114      -0.611609697341919
    z[0,1,2]  R115      3.3169406652450562e-01
    z[0,1,2]  R116      1.8586735427379608e-01
    z[0,1,2]  R117      1.6468927264213562e-01
    z[0,1,2]  R118      4.8190999031066895e-01
    z[0,1,2]  R119      1.5249325335025787e-01
    z[0,1,2]  R120      1.0341267101466656e-02
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R53       -1
    z[0,1,3]  R54       1
    z[0,1,3]  R61       4.5237401127815247e-01
    z[0,1,3]  R62       2.1295714378356934e-01
    z[0,1,3]  R63       1.4857533574104309e-01
    z[0,1,3]  R64       5.3420770168304443e-01
    z[0,1,3]  R65       4.1671367362141609e-03
    z[0,1,3]  R66       2.2930823266506195e-01
    z[0,1,3]  R67       5.3406044840812683e-02
    z[0,1,3]  R68       1.7053808271884918e-01
    z[0,1,3]  R69       1.3522480428218842e-01
    z[0,1,3]  R70       -3.8373000919818878e-02
    z[0,1,3]  R71       -1.8585045635700226e-01
    z[0,1,3]  R72       -6.4700454473495483e-02
    z[0,1,3]  R73       4.8501765727996826e-01
    z[0,1,3]  R74       -1.9663412868976593e-01
    z[0,1,3]  R75       -3.1709563732147217e-01
    z[0,1,3]  R76       3.2315406203269958e-01
    z[0,1,3]  R77       2.3060378432273865e-01
    z[0,1,3]  R78       -2.5532633066177368e-01
    z[0,1,3]  R79       2.3047365248203278e-01
    z[0,1,3]  R80       -1.3711015693843365e-02
    z[0,1,3]  R81       1.4971904456615448e-01
    z[0,1,3]  R82       5.6009536981582642e-01
    z[0,1,3]  R83       1.2469938024878502e-02
    z[0,1,3]  R84       6.5791660547256470e-01
    z[0,1,3]  R85       -3.6636710166931152e-01
    z[0,1,3]  R86       -2.0004889369010925e-01
    z[0,1,3]  R87       3.1147342920303345e-01
    z[0,1,3]  R88       -4.0973043441772461e-01
    z[0,1,3]  R89       -5.1095658540725708e-01
    z[0,1,3]  R90       -3.7618669867515564e-01
    z[0,1,3]  R91       0.0747021734714508
    z[0,1,3]  R92       -4.3851667642593384e-01
    z[0,1,3]  R93       -5.4049533605575562e-01
    z[0,1,3]  R94       -1.6657525300979614e-01
    z[0,1,3]  R95       -8.6760473251342773e-01
    z[0,1,3]  R96       -0.604107141494751
    z[0,1,3]  R97       -6.4292007684707642e-01
    z[0,1,3]  R98       -3.9882490038871765e-01
    z[0,1,3]  R99       -3.9741331338882446e-01
    z[0,1,3]  R100      -5.5144232511520386e-01
    z[0,1,3]  R101      3.6425283551216125e-01
    z[0,1,3]  R102      -6.6679733991622925e-01
    z[0,1,3]  R103      -6.8822938203811646e-01
    z[0,1,3]  R104      -5.6779447942972183e-02
    z[0,1,3]  R105      7.2429150342941284e-02
    z[0,1,3]  R106      -3.6378815770149231e-01
    z[0,1,3]  R107      -3.0981072783470154e-01
    z[0,1,3]  R108      -2.4286228418350220e-01
    z[0,1,3]  R109      -4.7408733516931534e-02
    z[0,1,3]  R110      1.5245880186557770e-01
    z[0,1,3]  R111      -6.2550747394561768e-01
    z[0,1,3]  R112      -5.9744048118591309e-01
    z[0,1,3]  R113      -3.2809905707836151e-02
    z[0,1,3]  R114      -1.4084091782569885e-01
    z[0,1,3]  R115      -4.1828554868698120e-01
    z[0,1,3]  R116      -2.3344330489635468e-01
    z[0,1,3]  R117      -5.5787372589111328e-01
    z[0,1,3]  R118      -5.1932847499847412e-01
    z[0,1,3]  R119      8.5775060579180717e-03
    z[0,1,3]  R120      -9.6009470522403717e-02
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R55       -1
    z[0,1,4]  R56       1
    z[0,1,4]  R61       3.6352694034576416e-01
    z[0,1,4]  R62       5.0400757789611816e-01
    z[0,1,4]  R63       2.2750173509120941e-01
    z[0,1,4]  R64       1.5809445083141327e-01
    z[0,1,4]  R65       1.7233940958976746e-01
    z[0,1,4]  R66       1.5214808285236359e-01
    z[0,1,4]  R67       -1.9563388824462891e-01
    z[0,1,4]  R68       5.0626449286937714e-02
    z[0,1,4]  R69       1.7327135801315308e-01
    z[0,1,4]  R70       7.5925004482269287e-01
    z[0,1,4]  R71       1.9488541781902313e-01
    z[0,1,4]  R72       -6.4328193664550781e-01
    z[0,1,4]  R73       2.4784643203020096e-02
    z[0,1,4]  R74       1.8433399498462677e-01
    z[0,1,4]  R75       -2.9631075263023376e-01
    z[0,1,4]  R76       5.3221464157104492e-02
    z[0,1,4]  R77       -4.5590990781784058e-01
    z[0,1,4]  R78       -5.9960043430328369e-01
    z[0,1,4]  R79       -4.0511634200811386e-02
    z[0,1,4]  R80       -2.6555356383323669e-01
    z[0,1,4]  R81       6.4057117700576782e-01
    z[0,1,4]  R82       8.0915719270706177e-01
    z[0,1,4]  R83       -5.6615126132965088e-01
    z[0,1,4]  R84       -4.7507378458976746e-01
    z[0,1,4]  R85       -0.077522411942482
    z[0,1,4]  R86       -2.0425860583782196e-01
    z[0,1,4]  R87       -2.8395134210586548e-01
    z[0,1,4]  R88       -2.5203731656074524e-01
    z[0,1,4]  R89       1.7024983465671539e-01
    z[0,1,4]  R90       -2.1192273497581482e-01
    z[0,1,4]  R91       -2.3790630698204041e-01
    z[0,1,4]  R92       -3.1093001365661621e-01
    z[0,1,4]  R93       -4.6103402972221375e-01
    z[0,1,4]  R94       -1.1760532110929489e-01
    z[0,1,4]  R95       -1.2174691259860992e-01
    z[0,1,4]  R96       2.1174573898315430e-01
    z[0,1,4]  R97       3.1613189727067947e-02
    z[0,1,4]  R98       -3.2433861494064331e-01
    z[0,1,4]  R99       -1.9215957820415497e-01
    z[0,1,4]  R100      -4.2228358983993530e-01
    z[0,1,4]  R101      -4.4058007001876831e-01
    z[0,1,4]  R102      -4.0291124582290649e-01
    z[0,1,4]  R103      -5.0877290964126587e-01
    z[0,1,4]  R104      -1.5007355809211731e-01
    z[0,1,4]  R105      -2.6901068165898323e-02
    z[0,1,4]  R106      -1.9950826466083527e-01
    z[0,1,4]  R107      2.1566031500697136e-02
    z[0,1,4]  R108      -1.1014854535460472e-02
    z[0,1,4]  R109      -1.1080067604780197e-01
    z[0,1,4]  R110      -0.186312735080719
    z[0,1,4]  R111      0.0716809555888176
    z[0,1,4]  R112      -1.8982166051864624e-01
    z[0,1,4]  R113      -9.6350491046905518e-02
    z[0,1,4]  R114      -1.2929193675518036e-01
    z[0,1,4]  R115      1.0879338532686234e-01
    z[0,1,4]  R116      1.5406674146652222e-01
    z[0,1,4]  R117      -2.7404522895812988e-01
    z[0,1,4]  R118      -1.9865857902914286e-03
    z[0,1,4]  R119      1.0958957672119141e-01
    z[0,1,4]  R120      -1.0130358487367630e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R57       -1
    z[0,1,5]  R58       1
    z[0,1,5]  R61       -1.5137806534767151e-01
    z[0,1,5]  R62       -9.6033453941345215e-02
    z[0,1,5]  R63       -4.0943923592567444e-01
    z[0,1,5]  R64       -1.7703601717948914e-01
    z[0,1,5]  R65       -6.4846295118331909e-01
    z[0,1,5]  R66       -3.8356935977935791e-01
    z[0,1,5]  R67       -4.2871350049972534e-01
    z[0,1,5]  R68       -4.4779151678085327e-01
    z[0,1,5]  R69       -7.4562197923660278e-01
    z[0,1,5]  R70       1.0171062499284744e-01
    z[0,1,5]  R71       -2.2662536799907684e-01
    z[0,1,5]  R72       -2.0202580094337463e-01
    z[0,1,5]  R73       1.5028274059295654e-01
    z[0,1,5]  R74       8.0235011875629425e-02
    z[0,1,5]  R75       8.0260721733793616e-04
    z[0,1,5]  R76       -1.0110196471214294e-01
    z[0,1,5]  R77       1.0829304903745651e-01
    z[0,1,5]  R78       6.1059617437422276e-03
    z[0,1,5]  R79       -2.9586691409349442e-02
    z[0,1,5]  R80       0.0251467227935791
    z[0,1,5]  R81       -2.0066772401332855e-01
    z[0,1,5]  R82       -5.9441626071929932e-02
    z[0,1,5]  R83       2.7653029561042786e-01
    z[0,1,5]  R84       5.4726753383874893e-02
    z[0,1,5]  R85       3.3891800791025162e-02
    z[0,1,5]  R86       3.3521682024002075e-01
    z[0,1,5]  R87       -1.5599071979522705e-01
    z[0,1,5]  R88       2.5600078515708447e-03
    z[0,1,5]  R89       3.7962925434112549e-01
    z[0,1,5]  R90       1.4176584780216217e-01
    z[0,1,5]  R91       -5.8701831102371216e-01
    z[0,1,5]  R92       -1.1679384857416153e-01
    z[0,1,5]  R93       -3.2678428292274475e-01
    z[0,1,5]  R94       -5.0479900836944580e-01
    z[0,1,5]  R95       -4.6577075123786926e-01
    z[0,1,5]  R96       -1.2833803892135620e-01
    z[0,1,5]  R97       -1.1914358288049698e-01
    z[0,1,5]  R98       -7.5452238321304321e-02
    z[0,1,5]  R99       1.5624926984310150e-01
    z[0,1,5]  R100      -2.7592654805630445e-03
    z[0,1,5]  R101      3.9353662729263306e-01
    z[0,1,5]  R102      -4.4771060347557068e-01
    z[0,1,5]  R103      -2.4050267040729523e-01
    z[0,1,5]  R104      -5.0918138027191162e-01
    z[0,1,5]  R105      2.8002321720123291e-01
    z[0,1,5]  R106      -0.0396539680659771
    z[0,1,5]  R107      -3.9080310612916946e-02
    z[0,1,5]  R108      -1.9320229068398476e-02
    z[0,1,5]  R109      -1.4455287717282772e-02
    z[0,1,5]  R110      -1.0613378137350082e-01
    z[0,1,5]  R111      -4.5793151855468750e-01
    z[0,1,5]  R112      -1.9242644309997559e-01
    z[0,1,5]  R113      -5.7479149103164673e-01
    z[0,1,5]  R114      -1.8723320960998535e-01
    z[0,1,5]  R115      -2.7032741904258728e-01
    z[0,1,5]  R116      4.8314131796360016e-02
    z[0,1,5]  R117      -2.3204919416457415e-03
    z[0,1,5]  R118      -1.4920058846473694e-01
    z[0,1,5]  R119      -3.3517464995384216e-01
    z[0,1,5]  R120      -3.0391353368759155e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R59       -1
    z[0,1,6]  R60       1
    z[0,1,6]  R61       1.0978284478187561e-01
    z[0,1,6]  R62       -3.5747963190078735e-01
    z[0,1,6]  R63       1.6152659058570862e-01
    z[0,1,6]  R64       -4.2850866913795471e-01
    z[0,1,6]  R65       3.6659024655818939e-02
    z[0,1,6]  R66       -1.2612821161746979e-01
    z[0,1,6]  R67       1.5899509191513062e-02
    z[0,1,6]  R68       -4.1276538372039795e-01
    z[0,1,6]  R69       -7.5644083321094513e-02
    z[0,1,6]  R70       -1.0165489278733730e-02
    z[0,1,6]  R71       6.0287523269653320e-01
    z[0,1,6]  R72       3.8333171606063843e-01
    z[0,1,6]  R73       -2.8343913145363331e-03
    z[0,1,6]  R74       -1.0502440482378006e-01
    z[0,1,6]  R75       -1.3419578783214092e-02
    z[0,1,6]  R76       -2.6411110162734985e-01
    z[0,1,6]  R77       4.1964378952980042e-01
    z[0,1,6]  R78       -2.2624682635068893e-02
    z[0,1,6]  R79       4.7652676701545715e-02
    z[0,1,6]  R80       6.3781595230102539e-01
    z[0,1,6]  R81       -2.4560314416885376e-01
    z[0,1,6]  R82       -8.6249615997076035e-03
    z[0,1,6]  R83       4.5009684562683105e-01
    z[0,1,6]  R84       8.4467105567455292e-02
    z[0,1,6]  R85       3.5163056850433350e-01
    z[0,1,6]  R86       1.7577911913394928e-01
    z[0,1,6]  R87       1.4857438392937183e-02
    z[0,1,6]  R88       -5.3883910179138184e-01
    z[0,1,6]  R89       -0.0820883959531784
    z[0,1,6]  R90       -2.7637362480163574e-01
    z[0,1,6]  R91       -1.2720239348709583e-02
    z[0,1,6]  R92       -7.6829922199249268e-01
    z[0,1,6]  R93       -5.1832711696624756e-01
    z[0,1,6]  R94       3.2919490337371826e-01
    z[0,1,6]  R95       -7.9426631331443787e-02
    z[0,1,6]  R96       -8.2022309303283691e-02
    z[0,1,6]  R97       1.7222639173269272e-02
    z[0,1,6]  R98       -2.2025832533836365e-01
    z[0,1,6]  R99       -1.8181389570236206e-01
    z[0,1,6]  R100      -0.0487905852496624
    z[0,1,6]  R101      -6.4627546072006226e-01
    z[0,1,6]  R102      -9.0783812105655670e-02
    z[0,1,6]  R103      -2.0084077119827271e-01
    z[0,1,6]  R104      2.7500659227371216e-01
    z[0,1,6]  R105      0.0792355015873909
    z[0,1,6]  R106      2.6192107796669006e-01
    z[0,1,6]  R107      -1.4711722731590271e-01
    z[0,1,6]  R108      0.0408710315823555
    z[0,1,6]  R109      -1.4940334856510162e-01
    z[0,1,6]  R110      7.1755279786884785e-03
    z[0,1,6]  R111      1.7631410062313080e-01
    z[0,1,6]  R112      -3.2058694958686829e-01
    z[0,1,6]  R113      4.4458872079849243e-01
    z[0,1,6]  R114      6.3253903388977051e-01
    z[0,1,6]  R115      -2.7765689417719841e-02
    z[0,1,6]  R116      5.8352392166852951e-02
    z[0,1,6]  R117      1.5340046584606171e-01
    z[0,1,6]  R118      -1.0635794699192047e-01
    z[0,1,6]  R119      2.2697240114212036e-01
    z[0,1,6]  R120      3.6155867576599121e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R121      -1
    z[1,0,0]  R122      1
    z[1,0,0]  R135      1.0895483195781708e-01
    z[1,0,0]  R136      0.0934840589761734
    z[1,0,0]  R137      3.0696392059326172e-01
    z[1,0,0]  R138      -2.8118395805358887e-01
    z[1,0,0]  R139      -2.0352919399738312e-01
    z[1,0,0]  R140      2.3840183019638062e-01
    z[1,0,0]  R141      6.5376496315002441e-01
    z[1,0,0]  R142      7.3611110448837280e-02
    z[1,0,0]  R143      6.6353899240493774e-01
    z[1,0,0]  R144      -2.6388000696897507e-03
    z[1,0,0]  R145      -1.3830715417861938e-01
    z[1,0,0]  R146      1.3887564837932587e-01
    z[1,0,0]  R147      -3.9402008056640625e-02
    z[1,0,0]  R148      -5.8835762739181519e-01
    z[1,0,0]  R149      1.6388840973377228e-02
    z[1,0,0]  R150      -4.1222300380468369e-02
    z[1,0,0]  R151      2.8189649805426598e-02
    z[1,0,0]  R152      -1.3297820091247559e-01
    z[1,0,0]  R153      -0.200653538107872
    z[1,0,0]  R154      -1.1196637898683548e-01
    z[1,0,0]  R155      7.7385380864143372e-02
    z[1,0,0]  R156      -9.9324166774749756e-02
    z[1,0,0]  R157      -3.5108867287635803e-01
    z[1,0,0]  R158      -6.3792335987091064e-01
    z[1,0,0]  R159      7.3212879896163940e-01
    z[1,0,0]  R160      4.4521890580654144e-02
    z[1,0,0]  R161      1.0701041668653488e-01
    z[1,0,0]  R162      8.5760957002639771e-01
    z[1,0,0]  R163      6.5180635452270508e-01
    z[1,0,0]  R164      7.6279711723327637e-01
    z[1,0,0]  R165      2.7415168285369873e-01
    z[1,0,0]  R166      -0.303154855966568
    z[1,0,0]  R167      -0.588360071182251
    z[1,0,0]  R168      -3.6815574765205383e-01
    z[1,0,0]  R169      1.2681372463703156e-01
    z[1,0,0]  R170      -9.6772246062755585e-02
    z[1,0,0]  R171      -1.7005759477615356e-01
    z[1,0,0]  R172      -1.2802829733118415e-03
    z[1,0,0]  R173      -5.3634065389633179e-01
    z[1,0,0]  R174      -5.5998134613037109e-01
    z[1,0,0]  R175      6.1997342109680176e-01
    z[1,0,0]  R176      6.1377388238906860e-01
    z[1,0,0]  R177      8.1624311208724976e-01
    z[1,0,0]  R178      6.6854131221771240e-01
    z[1,0,0]  R179      5.7189089059829712e-01
    z[1,0,0]  R180      6.0928791761398315e-01
    z[1,0,0]  R181      5.4106467962265015e-01
    z[1,0,0]  R182      1.5430673956871033e-01
    z[1,0,0]  R183      3.4609189629554749e-01
    z[1,0,0]  R184      5.4998338222503662e-01
    z[1,0,0]  R185      2.5184392929077148e-01
    z[1,0,0]  R186      -3.5679784417152405e-01
    z[1,0,0]  R187      -3.7212127447128296e-01
    z[1,0,0]  R188      -3.9635765552520752e-01
    z[1,0,0]  R189      -3.9194595813751221e-01
    z[1,0,0]  R190      -4.8806375265121460e-01
    z[1,0,0]  R191      -7.5151152908802032e-02
    z[1,0,0]  R192      5.0344437360763550e-02
    z[1,0,0]  R193      -4.3500930070877075e-01
    z[1,0,0]  R194      -1.4791879057884216e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R123      -1
    z[1,0,1]  R124      1
    z[1,0,1]  R135      -4.6671545505523682e-01
    z[1,0,1]  R136      -1.3359937071800232e-01
    z[1,0,1]  R137      -5.4755187034606934e-01
    z[1,0,1]  R138      -4.5454701781272888e-01
    z[1,0,1]  R139      8.2258599996566772e-01
    z[1,0,1]  R140      8.3536797761917114e-01
    z[1,0,1]  R141      6.0298210382461548e-01
    z[1,0,1]  R142      6.8687140941619873e-01
    z[1,0,1]  R143      2.5713574886322021e-01
    z[1,0,1]  R144      8.2437044382095337e-01
    z[1,0,1]  R145      -6.3565254211425781e-01
    z[1,0,1]  R146      -2.6428091526031494e-01
    z[1,0,1]  R147      -3.4266650676727295e-01
    z[1,0,1]  R148      1.7891493439674377e-01
    z[1,0,1]  R149      -8.8861101539805532e-04
    z[1,0,1]  R150      7.3406648635864258e-01
    z[1,0,1]  R151      7.5357919931411743e-01
    z[1,0,1]  R152      0.777441143989563
    z[1,0,1]  R153      8.4087914228439331e-01
    z[1,0,1]  R154      6.7594271898269653e-01
    z[1,0,1]  R155      -3.0124077200889587e-01
    z[1,0,1]  R156      -3.4512379765510559e-01
    z[1,0,1]  R157      -7.5806662440299988e-02
    z[1,0,1]  R158      1.4388592541217804e-01
    z[1,0,1]  R159      5.3881222009658813e-01
    z[1,0,1]  R160      8.3683592081069946e-01
    z[1,0,1]  R161      8.5966998338699341e-01
    z[1,0,1]  R162      3.2006371021270752e-01
    z[1,0,1]  R163      5.7017904520034790e-01
    z[1,0,1]  R164      5.0148993730545044e-01
    z[1,0,1]  R165      -3.6733394861221313e-01
    z[1,0,1]  R166      3.8637730479240417e-01
    z[1,0,1]  R167      5.2368111908435822e-02
    z[1,0,1]  R168      1.3667643070220947e-01
    z[1,0,1]  R169      7.8310316801071167e-01
    z[1,0,1]  R170      9.3387198448181152e-01
    z[1,0,1]  R171      7.3081928491592407e-01
    z[1,0,1]  R172      6.8152934312820435e-01
    z[1,0,1]  R173      7.1633970737457275e-01
    z[1,0,1]  R174      6.6614228487014771e-01
    z[1,0,1]  R175      -1.6295786201953888e-01
    z[1,0,1]  R176      -1.2111399322748184e-01
    z[1,0,1]  R177      -2.0713490247726440e-01
    z[1,0,1]  R178      -1.6520245373249054e-01
    z[1,0,1]  R179      -1.8242236971855164e-01
    z[1,0,1]  R180      2.5737902522087097e-01
    z[1,0,1]  R181      2.1483238041400909e-01
    z[1,0,1]  R182      7.1263438463211060e-01
    z[1,0,1]  R183      5.1909154653549194e-01
    z[1,0,1]  R184      -2.3365914821624756e-01
    z[1,0,1]  R185      1.7744581401348114e-01
    z[1,0,1]  R186      5.0638526678085327e-01
    z[1,0,1]  R187      -7.5885814428329468e-01
    z[1,0,1]  R188      -0.867509126663208
    z[1,0,1]  R189      -7.6405006647109985e-01
    z[1,0,1]  R190      -7.5097453594207764e-01
    z[1,0,1]  R191      -7.3848491907119751e-01
    z[1,0,1]  R192      -7.3716473579406738e-01
    z[1,0,1]  R193      -0.848032534122467
    z[1,0,1]  R194      -7.0639103651046753e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R125      -1
    z[1,0,2]  R126      1
    z[1,0,2]  R135      -4.8679551482200623e-01
    z[1,0,2]  R136      3.6904752254486084e-02
    z[1,0,2]  R137      7.8874669969081879e-02
    z[1,0,2]  R138      -2.1364346146583557e-01
    z[1,0,2]  R139      1.3000316917896271e-01
    z[1,0,2]  R140      -1.4253102242946625e-01
    z[1,0,2]  R141      -8.2498893141746521e-02
    z[1,0,2]  R142      3.2142437994480133e-02
    z[1,0,2]  R143      2.2951868176460266e-01
    z[1,0,2]  R144      -1.9364626705646515e-01
    z[1,0,2]  R145      4.1217097640037537e-01
    z[1,0,2]  R146      1.3405339419841766e-01
    z[1,0,2]  R147      -2.9808761551976204e-02
    z[1,0,2]  R148      -4.6589165925979614e-01
    z[1,0,2]  R149      9.4442255795001984e-02
    z[1,0,2]  R150      1.6268730163574219e-01
    z[1,0,2]  R151      4.9862369894981384e-02
    z[1,0,2]  R152      2.4379999935626984e-01
    z[1,0,2]  R153      1.8106689676642418e-02
    z[1,0,2]  R154      2.1392691135406494e-01
    z[1,0,2]  R155      -6.2701150774955750e-02
    z[1,0,2]  R156      -2.3533287644386292e-01
    z[1,0,2]  R157      -2.0075348019599915e-01
    z[1,0,2]  R158      -4.6012011170387268e-01
    z[1,0,2]  R159      2.8811085224151611e-01
    z[1,0,2]  R160      2.3537848889827728e-01
    z[1,0,2]  R161      3.6041319370269775e-01
    z[1,0,2]  R162      3.1767565011978149e-01
    z[1,0,2]  R163      4.6150788664817810e-01
    z[1,0,2]  R164      3.1205204129219055e-01
    z[1,0,2]  R165      3.9079514145851135e-01
    z[1,0,2]  R166      -4.7543495893478394e-01
    z[1,0,2]  R167      -3.3568689227104187e-01
    z[1,0,2]  R168      -0.611609697341919
    z[1,0,2]  R169      3.3169406652450562e-01
    z[1,0,2]  R170      1.8586735427379608e-01
    z[1,0,2]  R171      1.6468927264213562e-01
    z[1,0,2]  R172      4.8190999031066895e-01
    z[1,0,2]  R173      1.5249325335025787e-01
    z[1,0,2]  R174      1.0341267101466656e-02
    z[1,0,2]  R175      -4.6617171168327332e-01
    z[1,0,2]  R176      -4.1499951481819153e-01
    z[1,0,2]  R177      -1.5257543325424194e-01
    z[1,0,2]  R178      -2.0673599094152451e-02
    z[1,0,2]  R179      -4.3370109796524048e-01
    z[1,0,2]  R180      -0.568998396396637
    z[1,0,2]  R181      -6.6024476289749146e-01
    z[1,0,2]  R182      2.5652045011520386e-01
    z[1,0,2]  R183      2.7954699471592903e-02
    z[1,0,2]  R184      -2.3353826999664307e-01
    z[1,0,2]  R185      0.646335244178772
    z[1,0,2]  R186      1.0253693908452988e-01
    z[1,0,2]  R187      1.6495698690414429e-01
    z[1,0,2]  R188      0.0147220054641366
    z[1,0,2]  R189      -2.7216812968254089e-01
    z[1,0,2]  R190      -1.0292558372020721e-01
    z[1,0,2]  R191      -1.1488610878586769e-02
    z[1,0,2]  R192      1.6968281567096710e-01
    z[1,0,2]  R193      -1.8358199298381805e-01
    z[1,0,2]  R194      -3.1358856707811356e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R127      -1
    z[1,0,3]  R128      1
    z[1,0,3]  R135      1.4971904456615448e-01
    z[1,0,3]  R136      5.6009536981582642e-01
    z[1,0,3]  R137      1.2469938024878502e-02
    z[1,0,3]  R138      6.5791660547256470e-01
    z[1,0,3]  R139      -3.6636710166931152e-01
    z[1,0,3]  R140      -2.0004889369010925e-01
    z[1,0,3]  R141      3.1147342920303345e-01
    z[1,0,3]  R142      -4.0973043441772461e-01
    z[1,0,3]  R143      -5.1095658540725708e-01
    z[1,0,3]  R144      -3.7618669867515564e-01
    z[1,0,3]  R145      0.0747021734714508
    z[1,0,3]  R146      -4.3851667642593384e-01
    z[1,0,3]  R147      -5.4049533605575562e-01
    z[1,0,3]  R148      -1.6657525300979614e-01
    z[1,0,3]  R149      -8.6760473251342773e-01
    z[1,0,3]  R150      -0.604107141494751
    z[1,0,3]  R151      -6.4292007684707642e-01
    z[1,0,3]  R152      -3.9882490038871765e-01
    z[1,0,3]  R153      -3.9741331338882446e-01
    z[1,0,3]  R154      -5.5144232511520386e-01
    z[1,0,3]  R155      3.6425283551216125e-01
    z[1,0,3]  R156      -6.6679733991622925e-01
    z[1,0,3]  R157      -6.8822938203811646e-01
    z[1,0,3]  R158      -5.6779447942972183e-02
    z[1,0,3]  R159      7.2429150342941284e-02
    z[1,0,3]  R160      -3.6378815770149231e-01
    z[1,0,3]  R161      -3.0981072783470154e-01
    z[1,0,3]  R162      -2.4286228418350220e-01
    z[1,0,3]  R163      -4.7408733516931534e-02
    z[1,0,3]  R164      1.5245880186557770e-01
    z[1,0,3]  R165      -6.2550747394561768e-01
    z[1,0,3]  R166      -5.9744048118591309e-01
    z[1,0,3]  R167      -3.2809905707836151e-02
    z[1,0,3]  R168      -1.4084091782569885e-01
    z[1,0,3]  R169      -4.1828554868698120e-01
    z[1,0,3]  R170      -2.3344330489635468e-01
    z[1,0,3]  R171      -5.5787372589111328e-01
    z[1,0,3]  R172      -5.1932847499847412e-01
    z[1,0,3]  R173      8.5775060579180717e-03
    z[1,0,3]  R174      -9.6009470522403717e-02
    z[1,0,3]  R175      4.5237401127815247e-01
    z[1,0,3]  R176      2.1295714378356934e-01
    z[1,0,3]  R177      1.4857533574104309e-01
    z[1,0,3]  R178      5.3420770168304443e-01
    z[1,0,3]  R179      4.1671367362141609e-03
    z[1,0,3]  R180      2.2930823266506195e-01
    z[1,0,3]  R181      5.3406044840812683e-02
    z[1,0,3]  R182      1.7053808271884918e-01
    z[1,0,3]  R183      1.3522480428218842e-01
    z[1,0,3]  R184      -3.8373000919818878e-02
    z[1,0,3]  R185      -1.8585045635700226e-01
    z[1,0,3]  R186      -6.4700454473495483e-02
    z[1,0,3]  R187      4.8501765727996826e-01
    z[1,0,3]  R188      -1.9663412868976593e-01
    z[1,0,3]  R189      -3.1709563732147217e-01
    z[1,0,3]  R190      3.2315406203269958e-01
    z[1,0,3]  R191      2.3060378432273865e-01
    z[1,0,3]  R192      -2.5532633066177368e-01
    z[1,0,3]  R193      2.3047365248203278e-01
    z[1,0,3]  R194      -1.3711015693843365e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R129      -1
    z[1,0,4]  R130      1
    z[1,0,4]  R135      6.4057117700576782e-01
    z[1,0,4]  R136      8.0915719270706177e-01
    z[1,0,4]  R137      -5.6615126132965088e-01
    z[1,0,4]  R138      -4.7507378458976746e-01
    z[1,0,4]  R139      -0.077522411942482
    z[1,0,4]  R140      -2.0425860583782196e-01
    z[1,0,4]  R141      -2.8395134210586548e-01
    z[1,0,4]  R142      -2.5203731656074524e-01
    z[1,0,4]  R143      1.7024983465671539e-01
    z[1,0,4]  R144      -2.1192273497581482e-01
    z[1,0,4]  R145      -2.3790630698204041e-01
    z[1,0,4]  R146      -3.1093001365661621e-01
    z[1,0,4]  R147      -4.6103402972221375e-01
    z[1,0,4]  R148      -1.1760532110929489e-01
    z[1,0,4]  R149      -1.2174691259860992e-01
    z[1,0,4]  R150      2.1174573898315430e-01
    z[1,0,4]  R151      3.1613189727067947e-02
    z[1,0,4]  R152      -3.2433861494064331e-01
    z[1,0,4]  R153      -1.9215957820415497e-01
    z[1,0,4]  R154      -4.2228358983993530e-01
    z[1,0,4]  R155      -4.4058007001876831e-01
    z[1,0,4]  R156      -4.0291124582290649e-01
    z[1,0,4]  R157      -5.0877290964126587e-01
    z[1,0,4]  R158      -1.5007355809211731e-01
    z[1,0,4]  R159      -2.6901068165898323e-02
    z[1,0,4]  R160      -1.9950826466083527e-01
    z[1,0,4]  R161      2.1566031500697136e-02
    z[1,0,4]  R162      -1.1014854535460472e-02
    z[1,0,4]  R163      -1.1080067604780197e-01
    z[1,0,4]  R164      -0.186312735080719
    z[1,0,4]  R165      0.0716809555888176
    z[1,0,4]  R166      -1.8982166051864624e-01
    z[1,0,4]  R167      -9.6350491046905518e-02
    z[1,0,4]  R168      -1.2929193675518036e-01
    z[1,0,4]  R169      1.0879338532686234e-01
    z[1,0,4]  R170      1.5406674146652222e-01
    z[1,0,4]  R171      -2.7404522895812988e-01
    z[1,0,4]  R172      -1.9865857902914286e-03
    z[1,0,4]  R173      1.0958957672119141e-01
    z[1,0,4]  R174      -1.0130358487367630e-01
    z[1,0,4]  R175      3.6352694034576416e-01
    z[1,0,4]  R176      5.0400757789611816e-01
    z[1,0,4]  R177      2.2750173509120941e-01
    z[1,0,4]  R178      1.5809445083141327e-01
    z[1,0,4]  R179      1.7233940958976746e-01
    z[1,0,4]  R180      1.5214808285236359e-01
    z[1,0,4]  R181      -1.9563388824462891e-01
    z[1,0,4]  R182      5.0626449286937714e-02
    z[1,0,4]  R183      1.7327135801315308e-01
    z[1,0,4]  R184      7.5925004482269287e-01
    z[1,0,4]  R185      1.9488541781902313e-01
    z[1,0,4]  R186      -6.4328193664550781e-01
    z[1,0,4]  R187      2.4784643203020096e-02
    z[1,0,4]  R188      1.8433399498462677e-01
    z[1,0,4]  R189      -2.9631075263023376e-01
    z[1,0,4]  R190      5.3221464157104492e-02
    z[1,0,4]  R191      -4.5590990781784058e-01
    z[1,0,4]  R192      -5.9960043430328369e-01
    z[1,0,4]  R193      -4.0511634200811386e-02
    z[1,0,4]  R194      -2.6555356383323669e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R131      -1
    z[1,0,5]  R132      1
    z[1,0,5]  R135      -2.0066772401332855e-01
    z[1,0,5]  R136      -5.9441626071929932e-02
    z[1,0,5]  R137      2.7653029561042786e-01
    z[1,0,5]  R138      5.4726753383874893e-02
    z[1,0,5]  R139      3.3891800791025162e-02
    z[1,0,5]  R140      3.3521682024002075e-01
    z[1,0,5]  R141      -1.5599071979522705e-01
    z[1,0,5]  R142      2.5600078515708447e-03
    z[1,0,5]  R143      3.7962925434112549e-01
    z[1,0,5]  R144      1.4176584780216217e-01
    z[1,0,5]  R145      -5.8701831102371216e-01
    z[1,0,5]  R146      -1.1679384857416153e-01
    z[1,0,5]  R147      -3.2678428292274475e-01
    z[1,0,5]  R148      -5.0479900836944580e-01
    z[1,0,5]  R149      -4.6577075123786926e-01
    z[1,0,5]  R150      -1.2833803892135620e-01
    z[1,0,5]  R151      -1.1914358288049698e-01
    z[1,0,5]  R152      -7.5452238321304321e-02
    z[1,0,5]  R153      1.5624926984310150e-01
    z[1,0,5]  R154      -2.7592654805630445e-03
    z[1,0,5]  R155      3.9353662729263306e-01
    z[1,0,5]  R156      -4.4771060347557068e-01
    z[1,0,5]  R157      -2.4050267040729523e-01
    z[1,0,5]  R158      -5.0918138027191162e-01
    z[1,0,5]  R159      2.8002321720123291e-01
    z[1,0,5]  R160      -0.0396539680659771
    z[1,0,5]  R161      -3.9080310612916946e-02
    z[1,0,5]  R162      -1.9320229068398476e-02
    z[1,0,5]  R163      -1.4455287717282772e-02
    z[1,0,5]  R164      -1.0613378137350082e-01
    z[1,0,5]  R165      -4.5793151855468750e-01
    z[1,0,5]  R166      -1.9242644309997559e-01
    z[1,0,5]  R167      -5.7479149103164673e-01
    z[1,0,5]  R168      -1.8723320960998535e-01
    z[1,0,5]  R169      -2.7032741904258728e-01
    z[1,0,5]  R170      4.8314131796360016e-02
    z[1,0,5]  R171      -2.3204919416457415e-03
    z[1,0,5]  R172      -1.4920058846473694e-01
    z[1,0,5]  R173      -3.3517464995384216e-01
    z[1,0,5]  R174      -3.0391353368759155e-01
    z[1,0,5]  R175      -1.5137806534767151e-01
    z[1,0,5]  R176      -9.6033453941345215e-02
    z[1,0,5]  R177      -4.0943923592567444e-01
    z[1,0,5]  R178      -1.7703601717948914e-01
    z[1,0,5]  R179      -6.4846295118331909e-01
    z[1,0,5]  R180      -3.8356935977935791e-01
    z[1,0,5]  R181      -4.2871350049972534e-01
    z[1,0,5]  R182      -4.4779151678085327e-01
    z[1,0,5]  R183      -7.4562197923660278e-01
    z[1,0,5]  R184      1.0171062499284744e-01
    z[1,0,5]  R185      -2.2662536799907684e-01
    z[1,0,5]  R186      -2.0202580094337463e-01
    z[1,0,5]  R187      1.5028274059295654e-01
    z[1,0,5]  R188      8.0235011875629425e-02
    z[1,0,5]  R189      8.0260721733793616e-04
    z[1,0,5]  R190      -1.0110196471214294e-01
    z[1,0,5]  R191      1.0829304903745651e-01
    z[1,0,5]  R192      6.1059617437422276e-03
    z[1,0,5]  R193      -2.9586691409349442e-02
    z[1,0,5]  R194      0.0251467227935791
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R133      -1
    z[1,0,6]  R134      1
    z[1,0,6]  R135      -2.4560314416885376e-01
    z[1,0,6]  R136      -8.6249615997076035e-03
    z[1,0,6]  R137      4.5009684562683105e-01
    z[1,0,6]  R138      8.4467105567455292e-02
    z[1,0,6]  R139      3.5163056850433350e-01
    z[1,0,6]  R140      1.7577911913394928e-01
    z[1,0,6]  R141      1.4857438392937183e-02
    z[1,0,6]  R142      -5.3883910179138184e-01
    z[1,0,6]  R143      -0.0820883959531784
    z[1,0,6]  R144      -2.7637362480163574e-01
    z[1,0,6]  R145      -1.2720239348709583e-02
    z[1,0,6]  R146      -7.6829922199249268e-01
    z[1,0,6]  R147      -5.1832711696624756e-01
    z[1,0,6]  R148      3.2919490337371826e-01
    z[1,0,6]  R149      -7.9426631331443787e-02
    z[1,0,6]  R150      -8.2022309303283691e-02
    z[1,0,6]  R151      1.7222639173269272e-02
    z[1,0,6]  R152      -2.2025832533836365e-01
    z[1,0,6]  R153      -1.8181389570236206e-01
    z[1,0,6]  R154      -0.0487905852496624
    z[1,0,6]  R155      -6.4627546072006226e-01
    z[1,0,6]  R156      -9.0783812105655670e-02
    z[1,0,6]  R157      -2.0084077119827271e-01
    z[1,0,6]  R158      2.7500659227371216e-01
    z[1,0,6]  R159      0.0792355015873909
    z[1,0,6]  R160      2.6192107796669006e-01
    z[1,0,6]  R161      -1.4711722731590271e-01
    z[1,0,6]  R162      0.0408710315823555
    z[1,0,6]  R163      -1.4940334856510162e-01
    z[1,0,6]  R164      7.1755279786884785e-03
    z[1,0,6]  R165      1.7631410062313080e-01
    z[1,0,6]  R166      -3.2058694958686829e-01
    z[1,0,6]  R167      4.4458872079849243e-01
    z[1,0,6]  R168      6.3253903388977051e-01
    z[1,0,6]  R169      -2.7765689417719841e-02
    z[1,0,6]  R170      5.8352392166852951e-02
    z[1,0,6]  R171      1.5340046584606171e-01
    z[1,0,6]  R172      -1.0635794699192047e-01
    z[1,0,6]  R173      2.2697240114212036e-01
    z[1,0,6]  R174      3.6155867576599121e-01
    z[1,0,6]  R175      1.0978284478187561e-01
    z[1,0,6]  R176      -3.5747963190078735e-01
    z[1,0,6]  R177      1.6152659058570862e-01
    z[1,0,6]  R178      -4.2850866913795471e-01
    z[1,0,6]  R179      3.6659024655818939e-02
    z[1,0,6]  R180      -1.2612821161746979e-01
    z[1,0,6]  R181      1.5899509191513062e-02
    z[1,0,6]  R182      -4.1276538372039795e-01
    z[1,0,6]  R183      -7.5644083321094513e-02
    z[1,0,6]  R184      -1.0165489278733730e-02
    z[1,0,6]  R185      6.0287523269653320e-01
    z[1,0,6]  R186      3.8333171606063843e-01
    z[1,0,6]  R187      -2.8343913145363331e-03
    z[1,0,6]  R188      -1.0502440482378006e-01
    z[1,0,6]  R189      -1.3419578783214092e-02
    z[1,0,6]  R190      -2.6411110162734985e-01
    z[1,0,6]  R191      4.1964378952980042e-01
    z[1,0,6]  R192      -2.2624682635068893e-02
    z[1,0,6]  R193      4.7652676701545715e-02
    z[1,0,6]  R194      6.3781595230102539e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R195      -1
    z[0,3,0]  R196      1
    z[0,3,0]  R209      6.1997342109680176e-01
    z[0,3,0]  R210      6.1377388238906860e-01
    z[0,3,0]  R211      8.1624311208724976e-01
    z[0,3,0]  R212      6.6854131221771240e-01
    z[0,3,0]  R213      5.7189089059829712e-01
    z[0,3,0]  R214      6.0928791761398315e-01
    z[0,3,0]  R215      5.4106467962265015e-01
    z[0,3,0]  R216      1.5430673956871033e-01
    z[0,3,0]  R217      3.4609189629554749e-01
    z[0,3,0]  R218      5.4998338222503662e-01
    z[0,3,0]  R219      2.5184392929077148e-01
    z[0,3,0]  R220      -3.5679784417152405e-01
    z[0,3,0]  R221      -3.7212127447128296e-01
    z[0,3,0]  R222      -3.9635765552520752e-01
    z[0,3,0]  R223      -3.9194595813751221e-01
    z[0,3,0]  R224      -4.8806375265121460e-01
    z[0,3,0]  R225      -7.5151152908802032e-02
    z[0,3,0]  R226      5.0344437360763550e-02
    z[0,3,0]  R227      -4.3500930070877075e-01
    z[0,3,0]  R228      -1.4791879057884216e-01
    z[0,3,0]  R229      2.7983114123344421e-01
    z[0,3,0]  R230      4.5460104942321777e-01
    z[0,3,0]  R231      5.2850371599197388e-01
    z[0,3,0]  R232      7.4628823995590210e-01
    z[0,3,0]  R233      6.7978280782699585e-01
    z[0,3,0]  R234      5.0720679759979248e-01
    z[0,3,0]  R235      -1.7386375367641449e-01
    z[0,3,0]  R236      6.3635128736495972e-01
    z[0,3,0]  R237      1.9838495645672083e-03
    z[0,3,0]  R238      4.3724125623703003e-01
    z[0,3,0]  R239      1.0943809896707535e-01
    z[0,3,0]  R240      7.2360396385192871e-01
    z[0,3,0]  R241      -0.41497603058815
    z[0,3,0]  R242      -0.360065221786499
    z[0,3,0]  R243      -4.2180991172790527e-01
    z[0,3,0]  R244      -4.8004138469696045e-01
    z[0,3,0]  R245      -4.3477049469947815e-01
    z[0,3,0]  R246      -0.6156005859375
    z[0,3,0]  R247      -3.2301768660545349e-01
    z[0,3,0]  R248      -3.7379533052444458e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R197      -1
    z[0,3,1]  R198      1
    z[0,3,1]  R209      -1.6295786201953888e-01
    z[0,3,1]  R210      -1.2111399322748184e-01
    z[0,3,1]  R211      -2.0713490247726440e-01
    z[0,3,1]  R212      -1.6520245373249054e-01
    z[0,3,1]  R213      -1.8242236971855164e-01
    z[0,3,1]  R214      2.5737902522087097e-01
    z[0,3,1]  R215      2.1483238041400909e-01
    z[0,3,1]  R216      7.1263438463211060e-01
    z[0,3,1]  R217      5.1909154653549194e-01
    z[0,3,1]  R218      -2.3365914821624756e-01
    z[0,3,1]  R219      1.7744581401348114e-01
    z[0,3,1]  R220      5.0638526678085327e-01
    z[0,3,1]  R221      -7.5885814428329468e-01
    z[0,3,1]  R222      -0.867509126663208
    z[0,3,1]  R223      -7.6405006647109985e-01
    z[0,3,1]  R224      -7.5097453594207764e-01
    z[0,3,1]  R225      -7.3848491907119751e-01
    z[0,3,1]  R226      -7.3716473579406738e-01
    z[0,3,1]  R227      -0.848032534122467
    z[0,3,1]  R228      -7.0639103651046753e-01
    z[0,3,1]  R229      0.505213737487793
    z[0,3,1]  R230      -2.9188922047615051e-01
    z[0,3,1]  R231      -2.7200677990913391e-01
    z[0,3,1]  R232      -3.0819791555404663e-01
    z[0,3,1]  R233      -4.9865084886550903e-01
    z[0,3,1]  R234      -2.9265290498733521e-01
    z[0,3,1]  R235      0.80692058801651
    z[0,3,1]  R236      -5.2047246694564819e-01
    z[0,3,1]  R237      1.3496515154838562e-01
    z[0,3,1]  R238      -6.9121068716049194e-01
    z[0,3,1]  R239      0.0921378806233406
    z[0,3,1]  R240      2.1200199425220490e-01
    z[0,3,1]  R241      -5.6763851642608643e-01
    z[0,3,1]  R242      -8.2999789714813232e-01
    z[0,3,1]  R243      -7.0515358448028564e-01
    z[0,3,1]  R244      -4.0988948941230774e-01
    z[0,3,1]  R245      -4.6646991372108459e-01
    z[0,3,1]  R246      1.9349502027034760e-01
    z[0,3,1]  R247      4.7425529360771179e-01
    z[0,3,1]  R248      2.0977059006690979e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R199      -1
    z[0,3,2]  R200      1
    z[0,3,2]  R209      -4.6617171168327332e-01
    z[0,3,2]  R210      -4.1499951481819153e-01
    z[0,3,2]  R211      -1.5257543325424194e-01
    z[0,3,2]  R212      -2.0673599094152451e-02
    z[0,3,2]  R213      -4.3370109796524048e-01
    z[0,3,2]  R214      -0.568998396396637
    z[0,3,2]  R215      -6.6024476289749146e-01
    z[0,3,2]  R216      2.5652045011520386e-01
    z[0,3,2]  R217      2.7954699471592903e-02
    z[0,3,2]  R218      -2.3353826999664307e-01
    z[0,3,2]  R219      0.646335244178772
    z[0,3,2]  R220      1.0253693908452988e-01
    z[0,3,2]  R221      1.6495698690414429e-01
    z[0,3,2]  R222      0.0147220054641366
    z[0,3,2]  R223      -2.7216812968254089e-01
    z[0,3,2]  R224      -1.0292558372020721e-01
    z[0,3,2]  R225      -1.1488610878586769e-02
    z[0,3,2]  R226      1.6968281567096710e-01
    z[0,3,2]  R227      -1.8358199298381805e-01
    z[0,3,2]  R228      -3.1358856707811356e-02
    z[0,3,2]  R229      9.6491836011409760e-02
    z[0,3,2]  R230      1.0408055037260056e-01
    z[0,3,2]  R231      -2.7911257743835449e-01
    z[0,3,2]  R232      -1.6206982731819153e-01
    z[0,3,2]  R233      2.9160779714584351e-01
    z[0,3,2]  R234      1.2674829363822937e-01
    z[0,3,2]  R235      9.7393020987510681e-02
    z[0,3,2]  R236      -9.0242482721805573e-02
    z[0,3,2]  R237      2.9007151722908020e-01
    z[0,3,2]  R238      -1.8557514250278473e-01
    z[0,3,2]  R239      -2.3937630653381348e-01
    z[0,3,2]  R240      4.1321533918380737e-01
    z[0,3,2]  R241      -4.4200602173805237e-01
    z[0,3,2]  R242      5.5509600788354874e-02
    z[0,3,2]  R243      1.0695017874240875e-01
    z[0,3,2]  R244      -3.8250240683555603e-01
    z[0,3,2]  R245      -4.8148775100708008e-01
    z[0,3,2]  R246      -5.3229510784149170e-01
    z[0,3,2]  R247      1.8213652074337006e-01
    z[0,3,2]  R248      -0.0711749866604805
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R201      -1
    z[0,3,3]  R202      1
    z[0,3,3]  R209      4.5237401127815247e-01
    z[0,3,3]  R210      2.1295714378356934e-01
    z[0,3,3]  R211      1.4857533574104309e-01
    z[0,3,3]  R212      5.3420770168304443e-01
    z[0,3,3]  R213      4.1671367362141609e-03
    z[0,3,3]  R214      2.2930823266506195e-01
    z[0,3,3]  R215      5.3406044840812683e-02
    z[0,3,3]  R216      1.7053808271884918e-01
    z[0,3,3]  R217      1.3522480428218842e-01
    z[0,3,3]  R218      -3.8373000919818878e-02
    z[0,3,3]  R219      -1.8585045635700226e-01
    z[0,3,3]  R220      -6.4700454473495483e-02
    z[0,3,3]  R221      4.8501765727996826e-01
    z[0,3,3]  R222      -1.9663412868976593e-01
    z[0,3,3]  R223      -3.1709563732147217e-01
    z[0,3,3]  R224      3.2315406203269958e-01
    z[0,3,3]  R225      2.3060378432273865e-01
    z[0,3,3]  R226      -2.5532633066177368e-01
    z[0,3,3]  R227      2.3047365248203278e-01
    z[0,3,3]  R228      -1.3711015693843365e-02
    z[0,3,3]  R229      3.8233183324337006e-02
    z[0,3,3]  R230      -5.6281287223100662e-02
    z[0,3,3]  R231      -1.6667445003986359e-01
    z[0,3,3]  R232      -1.1466748267412186e-01
    z[0,3,3]  R233      2.0051820203661919e-02
    z[0,3,3]  R234      1.4815273880958557e-01
    z[0,3,3]  R235      -1.3428920507431030e-01
    z[0,3,3]  R236      -4.4378823041915894e-01
    z[0,3,3]  R237      -2.1803137660026550e-01
    z[0,3,3]  R238      -3.4357210993766785e-01
    z[0,3,3]  R239      -7.1974718570709229e-01
    z[0,3,3]  R240      -3.4759324789047241e-01
    z[0,3,3]  R241      -1.9642159342765808e-01
    z[0,3,3]  R242      1.9086253643035889e-01
    z[0,3,3]  R243      2.0496025681495667e-01
    z[0,3,3]  R244      -7.6402656733989716e-02
    z[0,3,3]  R245      1.2922681868076324e-01
    z[0,3,3]  R246      3.9129105210304260e-01
    z[0,3,3]  R247      5.7691287994384766e-01
    z[0,3,3]  R248      -1.4007851481437683e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R203      -1
    z[0,3,4]  R204      1
    z[0,3,4]  R209      3.6352694034576416e-01
    z[0,3,4]  R210      5.0400757789611816e-01
    z[0,3,4]  R211      2.2750173509120941e-01
    z[0,3,4]  R212      1.5809445083141327e-01
    z[0,3,4]  R213      1.7233940958976746e-01
    z[0,3,4]  R214      1.5214808285236359e-01
    z[0,3,4]  R215      -1.9563388824462891e-01
    z[0,3,4]  R216      5.0626449286937714e-02
    z[0,3,4]  R217      1.7327135801315308e-01
    z[0,3,4]  R218      7.5925004482269287e-01
    z[0,3,4]  R219      1.9488541781902313e-01
    z[0,3,4]  R220      -6.4328193664550781e-01
    z[0,3,4]  R221      2.4784643203020096e-02
    z[0,3,4]  R222      1.8433399498462677e-01
    z[0,3,4]  R223      -2.9631075263023376e-01
    z[0,3,4]  R224      5.3221464157104492e-02
    z[0,3,4]  R225      -4.5590990781784058e-01
    z[0,3,4]  R226      -5.9960043430328369e-01
    z[0,3,4]  R227      -4.0511634200811386e-02
    z[0,3,4]  R228      -2.6555356383323669e-01
    z[0,3,4]  R229      2.6292881369590759e-01
    z[0,3,4]  R230      1.1427477002143860e-03
    z[0,3,4]  R231      2.9889410734176636e-01
    z[0,3,4]  R232      5.2212929725646973e-01
    z[0,3,4]  R233      2.8739643096923828e-01
    z[0,3,4]  R234      4.6194615960121155e-01
    z[0,3,4]  R235      -2.1076743304729462e-01
    z[0,3,4]  R236      8.2869090139865875e-02
    z[0,3,4]  R237      -5.6725829839706421e-01
    z[0,3,4]  R238      -2.1376505494117737e-01
    z[0,3,4]  R239      -5.7799136638641357e-01
    z[0,3,4]  R240      -1.2210885435342789e-01
    z[0,3,4]  R241      -3.7678331136703491e-01
    z[0,3,4]  R242      -1.7832627892494202e-01
    z[0,3,4]  R243      -4.3485438823699951e-01
    z[0,3,4]  R244      0.597722053527832
    z[0,3,4]  R245      4.6631014347076416e-01
    z[0,3,4]  R246      2.9649755358695984e-01
    z[0,3,4]  R247      4.4300094246864319e-01
    z[0,3,4]  R248      7.8966683149337769e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R205      -1
    z[0,3,5]  R206      1
    z[0,3,5]  R209      -1.5137806534767151e-01
    z[0,3,5]  R210      -9.6033453941345215e-02
    z[0,3,5]  R211      -4.0943923592567444e-01
    z[0,3,5]  R212      -1.7703601717948914e-01
    z[0,3,5]  R213      -6.4846295118331909e-01
    z[0,3,5]  R214      -3.8356935977935791e-01
    z[0,3,5]  R215      -4.2871350049972534e-01
    z[0,3,5]  R216      -4.4779151678085327e-01
    z[0,3,5]  R217      -7.4562197923660278e-01
    z[0,3,5]  R218      1.0171062499284744e-01
    z[0,3,5]  R219      -2.2662536799907684e-01
    z[0,3,5]  R220      -2.0202580094337463e-01
    z[0,3,5]  R221      1.5028274059295654e-01
    z[0,3,5]  R222      8.0235011875629425e-02
    z[0,3,5]  R223      8.0260721733793616e-04
    z[0,3,5]  R224      -1.0110196471214294e-01
    z[0,3,5]  R225      1.0829304903745651e-01
    z[0,3,5]  R226      6.1059617437422276e-03
    z[0,3,5]  R227      -2.9586691409349442e-02
    z[0,3,5]  R228      0.0251467227935791
    z[0,3,5]  R229      -7.6487839221954346e-01
    z[0,3,5]  R230      -8.1545692682266235e-01
    z[0,3,5]  R231      -6.6843688488006592e-01
    z[0,3,5]  R232      -1.8858213722705841e-01
    z[0,3,5]  R233      -2.8500708937644958e-01
    z[0,3,5]  R234      -5.8723074197769165e-01
    z[0,3,5]  R235      -4.9610987305641174e-01
    z[0,3,5]  R236      -1.2263411283493042e-01
    z[0,3,5]  R237      -7.1447348594665527e-01
    z[0,3,5]  R238      1.4723853208124638e-02
    z[0,3,5]  R239      -2.5184974074363708e-01
    z[0,3,5]  R240      3.0484935641288757e-01
    z[0,3,5]  R241      -3.5863202810287476e-01
    z[0,3,5]  R242      1.1830098181962967e-01
    z[0,3,5]  R243      2.0683903992176056e-01
    z[0,3,5]  R244      2.4618925154209137e-01
    z[0,3,5]  R245      3.5562586784362793e-01
    z[0,3,5]  R246      -3.2573845237493515e-02
    z[0,3,5]  R247      3.1028228998184204e-01
    z[0,3,5]  R248      3.1595242023468018e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R207      -1
    z[0,3,6]  R208      1
    z[0,3,6]  R209      1.0978284478187561e-01
    z[0,3,6]  R210      -3.5747963190078735e-01
    z[0,3,6]  R211      1.6152659058570862e-01
    z[0,3,6]  R212      -4.2850866913795471e-01
    z[0,3,6]  R213      3.6659024655818939e-02
    z[0,3,6]  R214      -1.2612821161746979e-01
    z[0,3,6]  R215      1.5899509191513062e-02
    z[0,3,6]  R216      -4.1276538372039795e-01
    z[0,3,6]  R217      -7.5644083321094513e-02
    z[0,3,6]  R218      -1.0165489278733730e-02
    z[0,3,6]  R219      6.0287523269653320e-01
    z[0,3,6]  R220      3.8333171606063843e-01
    z[0,3,6]  R221      -2.8343913145363331e-03
    z[0,3,6]  R222      -1.0502440482378006e-01
    z[0,3,6]  R223      -1.3419578783214092e-02
    z[0,3,6]  R224      -2.6411110162734985e-01
    z[0,3,6]  R225      4.1964378952980042e-01
    z[0,3,6]  R226      -2.2624682635068893e-02
    z[0,3,6]  R227      4.7652676701545715e-02
    z[0,3,6]  R228      6.3781595230102539e-01
    z[0,3,6]  R229      -3.8868039846420288e-02
    z[0,3,6]  R230      1.7078292369842529e-01
    z[0,3,6]  R231      6.9759249687194824e-02
    z[0,3,6]  R232      -2.1688843145966530e-02
    z[0,3,6]  R233      -1.9994966685771942e-01
    z[0,3,6]  R234      -2.4667167663574219e-01
    z[0,3,6]  R235      -2.4155495688319206e-02
    z[0,3,6]  R236      -3.1171691417694092e-01
    z[0,3,6]  R237      1.3359299302101135e-01
    z[0,3,6]  R238      3.6421930789947510e-01
    z[0,3,6]  R239      8.1820584833621979e-02
    z[0,3,6]  R240      0.178999662399292
    z[0,3,6]  R241      -3.2374124974012375e-02
    z[0,3,6]  R242      -3.1008267402648926e-01
    z[0,3,6]  R243      1.9876374304294586e-01
    z[0,3,6]  R244      1.7755150794982910e-01
    z[0,3,6]  R245      -3.0585335567593575e-02
    z[0,3,6]  R246      2.4119900166988373e-01
    z[0,3,6]  R247      -1.1051856726408005e-01
    z[0,3,6]  R248      -2.6112416386604309e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R249      -1
    z[3,0,0]  R250      1
    z[3,0,0]  R263      2.7983114123344421e-01
    z[3,0,0]  R264      4.5460104942321777e-01
    z[3,0,0]  R265      5.2850371599197388e-01
    z[3,0,0]  R266      7.4628823995590210e-01
    z[3,0,0]  R267      6.7978280782699585e-01
    z[3,0,0]  R268      5.0720679759979248e-01
    z[3,0,0]  R269      -1.7386375367641449e-01
    z[3,0,0]  R270      6.3635128736495972e-01
    z[3,0,0]  R271      1.9838495645672083e-03
    z[3,0,0]  R272      4.3724125623703003e-01
    z[3,0,0]  R273      1.0943809896707535e-01
    z[3,0,0]  R274      7.2360396385192871e-01
    z[3,0,0]  R275      -0.41497603058815
    z[3,0,0]  R276      -0.360065221786499
    z[3,0,0]  R277      -4.2180991172790527e-01
    z[3,0,0]  R278      -4.8004138469696045e-01
    z[3,0,0]  R279      -4.3477049469947815e-01
    z[3,0,0]  R280      -0.6156005859375
    z[3,0,0]  R281      -3.2301768660545349e-01
    z[3,0,0]  R282      -3.7379533052444458e-01
    z[3,0,0]  R283      6.1997342109680176e-01
    z[3,0,0]  R284      6.1377388238906860e-01
    z[3,0,0]  R285      8.1624311208724976e-01
    z[3,0,0]  R286      6.6854131221771240e-01
    z[3,0,0]  R287      5.7189089059829712e-01
    z[3,0,0]  R288      6.0928791761398315e-01
    z[3,0,0]  R289      5.4106467962265015e-01
    z[3,0,0]  R290      1.5430673956871033e-01
    z[3,0,0]  R291      3.4609189629554749e-01
    z[3,0,0]  R292      5.4998338222503662e-01
    z[3,0,0]  R293      2.5184392929077148e-01
    z[3,0,0]  R294      -3.5679784417152405e-01
    z[3,0,0]  R295      -3.7212127447128296e-01
    z[3,0,0]  R296      -3.9635765552520752e-01
    z[3,0,0]  R297      -3.9194595813751221e-01
    z[3,0,0]  R298      -4.8806375265121460e-01
    z[3,0,0]  R299      -7.5151152908802032e-02
    z[3,0,0]  R300      5.0344437360763550e-02
    z[3,0,0]  R301      -4.3500930070877075e-01
    z[3,0,0]  R302      -1.4791879057884216e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R251      -1
    z[3,0,1]  R252      1
    z[3,0,1]  R263      0.505213737487793
    z[3,0,1]  R264      -2.9188922047615051e-01
    z[3,0,1]  R265      -2.7200677990913391e-01
    z[3,0,1]  R266      -3.0819791555404663e-01
    z[3,0,1]  R267      -4.9865084886550903e-01
    z[3,0,1]  R268      -2.9265290498733521e-01
    z[3,0,1]  R269      0.80692058801651
    z[3,0,1]  R270      -5.2047246694564819e-01
    z[3,0,1]  R271      1.3496515154838562e-01
    z[3,0,1]  R272      -6.9121068716049194e-01
    z[3,0,1]  R273      0.0921378806233406
    z[3,0,1]  R274      2.1200199425220490e-01
    z[3,0,1]  R275      -5.6763851642608643e-01
    z[3,0,1]  R276      -8.2999789714813232e-01
    z[3,0,1]  R277      -7.0515358448028564e-01
    z[3,0,1]  R278      -4.0988948941230774e-01
    z[3,0,1]  R279      -4.6646991372108459e-01
    z[3,0,1]  R280      1.9349502027034760e-01
    z[3,0,1]  R281      4.7425529360771179e-01
    z[3,0,1]  R282      2.0977059006690979e-01
    z[3,0,1]  R283      -1.6295786201953888e-01
    z[3,0,1]  R284      -1.2111399322748184e-01
    z[3,0,1]  R285      -2.0713490247726440e-01
    z[3,0,1]  R286      -1.6520245373249054e-01
    z[3,0,1]  R287      -1.8242236971855164e-01
    z[3,0,1]  R288      2.5737902522087097e-01
    z[3,0,1]  R289      2.1483238041400909e-01
    z[3,0,1]  R290      7.1263438463211060e-01
    z[3,0,1]  R291      5.1909154653549194e-01
    z[3,0,1]  R292      -2.3365914821624756e-01
    z[3,0,1]  R293      1.7744581401348114e-01
    z[3,0,1]  R294      5.0638526678085327e-01
    z[3,0,1]  R295      -7.5885814428329468e-01
    z[3,0,1]  R296      -0.867509126663208
    z[3,0,1]  R297      -7.6405006647109985e-01
    z[3,0,1]  R298      -7.5097453594207764e-01
    z[3,0,1]  R299      -7.3848491907119751e-01
    z[3,0,1]  R300      -7.3716473579406738e-01
    z[3,0,1]  R301      -0.848032534122467
    z[3,0,1]  R302      -7.0639103651046753e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R253      -1
    z[3,0,2]  R254      1
    z[3,0,2]  R263      9.6491836011409760e-02
    z[3,0,2]  R264      1.0408055037260056e-01
    z[3,0,2]  R265      -2.7911257743835449e-01
    z[3,0,2]  R266      -1.6206982731819153e-01
    z[3,0,2]  R267      2.9160779714584351e-01
    z[3,0,2]  R268      1.2674829363822937e-01
    z[3,0,2]  R269      9.7393020987510681e-02
    z[3,0,2]  R270      -9.0242482721805573e-02
    z[3,0,2]  R271      2.9007151722908020e-01
    z[3,0,2]  R272      -1.8557514250278473e-01
    z[3,0,2]  R273      -2.3937630653381348e-01
    z[3,0,2]  R274      4.1321533918380737e-01
    z[3,0,2]  R275      -4.4200602173805237e-01
    z[3,0,2]  R276      5.5509600788354874e-02
    z[3,0,2]  R277      1.0695017874240875e-01
    z[3,0,2]  R278      -3.8250240683555603e-01
    z[3,0,2]  R279      -4.8148775100708008e-01
    z[3,0,2]  R280      -5.3229510784149170e-01
    z[3,0,2]  R281      1.8213652074337006e-01
    z[3,0,2]  R282      -0.0711749866604805
    z[3,0,2]  R283      -4.6617171168327332e-01
    z[3,0,2]  R284      -4.1499951481819153e-01
    z[3,0,2]  R285      -1.5257543325424194e-01
    z[3,0,2]  R286      -2.0673599094152451e-02
    z[3,0,2]  R287      -4.3370109796524048e-01
    z[3,0,2]  R288      -0.568998396396637
    z[3,0,2]  R289      -6.6024476289749146e-01
    z[3,0,2]  R290      2.5652045011520386e-01
    z[3,0,2]  R291      2.7954699471592903e-02
    z[3,0,2]  R292      -2.3353826999664307e-01
    z[3,0,2]  R293      0.646335244178772
    z[3,0,2]  R294      1.0253693908452988e-01
    z[3,0,2]  R295      1.6495698690414429e-01
    z[3,0,2]  R296      0.0147220054641366
    z[3,0,2]  R297      -2.7216812968254089e-01
    z[3,0,2]  R298      -1.0292558372020721e-01
    z[3,0,2]  R299      -1.1488610878586769e-02
    z[3,0,2]  R300      1.6968281567096710e-01
    z[3,0,2]  R301      -1.8358199298381805e-01
    z[3,0,2]  R302      -3.1358856707811356e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R255      -1
    z[3,0,3]  R256      1
    z[3,0,3]  R263      3.8233183324337006e-02
    z[3,0,3]  R264      -5.6281287223100662e-02
    z[3,0,3]  R265      -1.6667445003986359e-01
    z[3,0,3]  R266      -1.1466748267412186e-01
    z[3,0,3]  R267      2.0051820203661919e-02
    z[3,0,3]  R268      1.4815273880958557e-01
    z[3,0,3]  R269      -1.3428920507431030e-01
    z[3,0,3]  R270      -4.4378823041915894e-01
    z[3,0,3]  R271      -2.1803137660026550e-01
    z[3,0,3]  R272      -3.4357210993766785e-01
    z[3,0,3]  R273      -7.1974718570709229e-01
    z[3,0,3]  R274      -3.4759324789047241e-01
    z[3,0,3]  R275      -1.9642159342765808e-01
    z[3,0,3]  R276      1.9086253643035889e-01
    z[3,0,3]  R277      2.0496025681495667e-01
    z[3,0,3]  R278      -7.6402656733989716e-02
    z[3,0,3]  R279      1.2922681868076324e-01
    z[3,0,3]  R280      3.9129105210304260e-01
    z[3,0,3]  R281      5.7691287994384766e-01
    z[3,0,3]  R282      -1.4007851481437683e-01
    z[3,0,3]  R283      4.5237401127815247e-01
    z[3,0,3]  R284      2.1295714378356934e-01
    z[3,0,3]  R285      1.4857533574104309e-01
    z[3,0,3]  R286      5.3420770168304443e-01
    z[3,0,3]  R287      4.1671367362141609e-03
    z[3,0,3]  R288      2.2930823266506195e-01
    z[3,0,3]  R289      5.3406044840812683e-02
    z[3,0,3]  R290      1.7053808271884918e-01
    z[3,0,3]  R291      1.3522480428218842e-01
    z[3,0,3]  R292      -3.8373000919818878e-02
    z[3,0,3]  R293      -1.8585045635700226e-01
    z[3,0,3]  R294      -6.4700454473495483e-02
    z[3,0,3]  R295      4.8501765727996826e-01
    z[3,0,3]  R296      -1.9663412868976593e-01
    z[3,0,3]  R297      -3.1709563732147217e-01
    z[3,0,3]  R298      3.2315406203269958e-01
    z[3,0,3]  R299      2.3060378432273865e-01
    z[3,0,3]  R300      -2.5532633066177368e-01
    z[3,0,3]  R301      2.3047365248203278e-01
    z[3,0,3]  R302      -1.3711015693843365e-02
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R257      -1
    z[3,0,4]  R258      1
    z[3,0,4]  R263      2.6292881369590759e-01
    z[3,0,4]  R264      1.1427477002143860e-03
    z[3,0,4]  R265      2.9889410734176636e-01
    z[3,0,4]  R266      5.2212929725646973e-01
    z[3,0,4]  R267      2.8739643096923828e-01
    z[3,0,4]  R268      4.6194615960121155e-01
    z[3,0,4]  R269      -2.1076743304729462e-01
    z[3,0,4]  R270      8.2869090139865875e-02
    z[3,0,4]  R271      -5.6725829839706421e-01
    z[3,0,4]  R272      -2.1376505494117737e-01
    z[3,0,4]  R273      -5.7799136638641357e-01
    z[3,0,4]  R274      -1.2210885435342789e-01
    z[3,0,4]  R275      -3.7678331136703491e-01
    z[3,0,4]  R276      -1.7832627892494202e-01
    z[3,0,4]  R277      -4.3485438823699951e-01
    z[3,0,4]  R278      0.597722053527832
    z[3,0,4]  R279      4.6631014347076416e-01
    z[3,0,4]  R280      2.9649755358695984e-01
    z[3,0,4]  R281      4.4300094246864319e-01
    z[3,0,4]  R282      7.8966683149337769e-01
    z[3,0,4]  R283      3.6352694034576416e-01
    z[3,0,4]  R284      5.0400757789611816e-01
    z[3,0,4]  R285      2.2750173509120941e-01
    z[3,0,4]  R286      1.5809445083141327e-01
    z[3,0,4]  R287      1.7233940958976746e-01
    z[3,0,4]  R288      1.5214808285236359e-01
    z[3,0,4]  R289      -1.9563388824462891e-01
    z[3,0,4]  R290      5.0626449286937714e-02
    z[3,0,4]  R291      1.7327135801315308e-01
    z[3,0,4]  R292      7.5925004482269287e-01
    z[3,0,4]  R293      1.9488541781902313e-01
    z[3,0,4]  R294      -6.4328193664550781e-01
    z[3,0,4]  R295      2.4784643203020096e-02
    z[3,0,4]  R296      1.8433399498462677e-01
    z[3,0,4]  R297      -2.9631075263023376e-01
    z[3,0,4]  R298      5.3221464157104492e-02
    z[3,0,4]  R299      -4.5590990781784058e-01
    z[3,0,4]  R300      -5.9960043430328369e-01
    z[3,0,4]  R301      -4.0511634200811386e-02
    z[3,0,4]  R302      -2.6555356383323669e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R259      -1
    z[3,0,5]  R260      1
    z[3,0,5]  R263      -7.6487839221954346e-01
    z[3,0,5]  R264      -8.1545692682266235e-01
    z[3,0,5]  R265      -6.6843688488006592e-01
    z[3,0,5]  R266      -1.8858213722705841e-01
    z[3,0,5]  R267      -2.8500708937644958e-01
    z[3,0,5]  R268      -5.8723074197769165e-01
    z[3,0,5]  R269      -4.9610987305641174e-01
    z[3,0,5]  R270      -1.2263411283493042e-01
    z[3,0,5]  R271      -7.1447348594665527e-01
    z[3,0,5]  R272      1.4723853208124638e-02
    z[3,0,5]  R273      -2.5184974074363708e-01
    z[3,0,5]  R274      3.0484935641288757e-01
    z[3,0,5]  R275      -3.5863202810287476e-01
    z[3,0,5]  R276      1.1830098181962967e-01
    z[3,0,5]  R277      2.0683903992176056e-01
    z[3,0,5]  R278      2.4618925154209137e-01
    z[3,0,5]  R279      3.5562586784362793e-01
    z[3,0,5]  R280      -3.2573845237493515e-02
    z[3,0,5]  R281      3.1028228998184204e-01
    z[3,0,5]  R282      3.1595242023468018e-01
    z[3,0,5]  R283      -1.5137806534767151e-01
    z[3,0,5]  R284      -9.6033453941345215e-02
    z[3,0,5]  R285      -4.0943923592567444e-01
    z[3,0,5]  R286      -1.7703601717948914e-01
    z[3,0,5]  R287      -6.4846295118331909e-01
    z[3,0,5]  R288      -3.8356935977935791e-01
    z[3,0,5]  R289      -4.2871350049972534e-01
    z[3,0,5]  R290      -4.4779151678085327e-01
    z[3,0,5]  R291      -7.4562197923660278e-01
    z[3,0,5]  R292      1.0171062499284744e-01
    z[3,0,5]  R293      -2.2662536799907684e-01
    z[3,0,5]  R294      -2.0202580094337463e-01
    z[3,0,5]  R295      1.5028274059295654e-01
    z[3,0,5]  R296      8.0235011875629425e-02
    z[3,0,5]  R297      8.0260721733793616e-04
    z[3,0,5]  R298      -1.0110196471214294e-01
    z[3,0,5]  R299      1.0829304903745651e-01
    z[3,0,5]  R300      6.1059617437422276e-03
    z[3,0,5]  R301      -2.9586691409349442e-02
    z[3,0,5]  R302      0.0251467227935791
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R261      -1
    z[3,0,6]  R262      1
    z[3,0,6]  R263      -3.8868039846420288e-02
    z[3,0,6]  R264      1.7078292369842529e-01
    z[3,0,6]  R265      6.9759249687194824e-02
    z[3,0,6]  R266      -2.1688843145966530e-02
    z[3,0,6]  R267      -1.9994966685771942e-01
    z[3,0,6]  R268      -2.4667167663574219e-01
    z[3,0,6]  R269      -2.4155495688319206e-02
    z[3,0,6]  R270      -3.1171691417694092e-01
    z[3,0,6]  R271      1.3359299302101135e-01
    z[3,0,6]  R272      3.6421930789947510e-01
    z[3,0,6]  R273      8.1820584833621979e-02
    z[3,0,6]  R274      0.178999662399292
    z[3,0,6]  R275      -3.2374124974012375e-02
    z[3,0,6]  R276      -3.1008267402648926e-01
    z[3,0,6]  R277      1.9876374304294586e-01
    z[3,0,6]  R278      1.7755150794982910e-01
    z[3,0,6]  R279      -3.0585335567593575e-02
    z[3,0,6]  R280      2.4119900166988373e-01
    z[3,0,6]  R281      -1.1051856726408005e-01
    z[3,0,6]  R282      -2.6112416386604309e-01
    z[3,0,6]  R283      1.0978284478187561e-01
    z[3,0,6]  R284      -3.5747963190078735e-01
    z[3,0,6]  R285      1.6152659058570862e-01
    z[3,0,6]  R286      -4.2850866913795471e-01
    z[3,0,6]  R287      3.6659024655818939e-02
    z[3,0,6]  R288      -1.2612821161746979e-01
    z[3,0,6]  R289      1.5899509191513062e-02
    z[3,0,6]  R290      -4.1276538372039795e-01
    z[3,0,6]  R291      -7.5644083321094513e-02
    z[3,0,6]  R292      -1.0165489278733730e-02
    z[3,0,6]  R293      6.0287523269653320e-01
    z[3,0,6]  R294      3.8333171606063843e-01
    z[3,0,6]  R295      -2.8343913145363331e-03
    z[3,0,6]  R296      -1.0502440482378006e-01
    z[3,0,6]  R297      -1.3419578783214092e-02
    z[3,0,6]  R298      -2.6411110162734985e-01
    z[3,0,6]  R299      4.1964378952980042e-01
    z[3,0,6]  R300      -2.2624682635068893e-02
    z[3,0,6]  R301      4.7652676701545715e-02
    z[3,0,6]  R302      6.3781595230102539e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R337      -1
    z[1,2,0]  R338      1
    z[1,2,0]  R351      1.0895483195781708e-01
    z[1,2,0]  R352      0.0934840589761734
    z[1,2,0]  R353      3.0696392059326172e-01
    z[1,2,0]  R354      -2.8118395805358887e-01
    z[1,2,0]  R355      -2.0352919399738312e-01
    z[1,2,0]  R356      2.3840183019638062e-01
    z[1,2,0]  R357      6.5376496315002441e-01
    z[1,2,0]  R358      7.3611110448837280e-02
    z[1,2,0]  R359      6.6353899240493774e-01
    z[1,2,0]  R360      -2.6388000696897507e-03
    z[1,2,0]  R361      -1.3830715417861938e-01
    z[1,2,0]  R362      1.3887564837932587e-01
    z[1,2,0]  R363      -3.9402008056640625e-02
    z[1,2,0]  R364      -5.8835762739181519e-01
    z[1,2,0]  R365      1.6388840973377228e-02
    z[1,2,0]  R366      -4.1222300380468369e-02
    z[1,2,0]  R367      2.8189649805426598e-02
    z[1,2,0]  R368      -1.3297820091247559e-01
    z[1,2,0]  R369      -0.200653538107872
    z[1,2,0]  R370      -1.1196637898683548e-01
    z[1,2,0]  R371      7.7385380864143372e-02
    z[1,2,0]  R372      -9.9324166774749756e-02
    z[1,2,0]  R373      -3.5108867287635803e-01
    z[1,2,0]  R374      -6.3792335987091064e-01
    z[1,2,0]  R375      7.3212879896163940e-01
    z[1,2,0]  R376      4.4521890580654144e-02
    z[1,2,0]  R377      1.0701041668653488e-01
    z[1,2,0]  R378      8.5760957002639771e-01
    z[1,2,0]  R379      6.5180635452270508e-01
    z[1,2,0]  R380      7.6279711723327637e-01
    z[1,2,0]  R381      2.7415168285369873e-01
    z[1,2,0]  R382      -0.303154855966568
    z[1,2,0]  R383      -0.588360071182251
    z[1,2,0]  R384      -3.6815574765205383e-01
    z[1,2,0]  R385      1.2681372463703156e-01
    z[1,2,0]  R386      -9.6772246062755585e-02
    z[1,2,0]  R387      -1.7005759477615356e-01
    z[1,2,0]  R388      -1.2802829733118415e-03
    z[1,2,0]  R389      -5.3634065389633179e-01
    z[1,2,0]  R390      -5.5998134613037109e-01
    z[1,2,0]  R391      -7.0111936330795288e-01
    z[1,2,0]  R392      -0.89290452003479
    z[1,2,0]  R393      -5.5982106924057007e-01
    z[1,2,0]  R394      -7.7223902940750122e-01
    z[1,2,0]  R395      -5.1400977373123169e-01
    z[1,2,0]  R396      -5.8208656311035156e-01
    z[1,2,0]  R397      -7.0283114910125732e-01
    z[1,2,0]  R398      -7.5358664989471436e-01
    z[1,2,0]  R399      -8.4476613998413086e-01
    z[1,2,0]  R400      -4.5482754707336426e-01
    z[1,2,0]  R401      -1.1568231880664825e-01
    z[1,2,0]  R402      -1.5688852965831757e-01
    z[1,2,0]  R403      -1.5708351135253906e-01
    z[1,2,0]  R404      0.698796272277832
    z[1,2,0]  R405      7.0299059152603149e-01
    z[1,2,0]  R406      6.8405562639236450e-01
    z[1,2,0]  R407      5.8949434757232666e-01
    z[1,2,0]  R408      7.7339643239974976e-01
    z[1,2,0]  R409      5.5310606956481934e-01
    z[1,2,0]  R410      6.3671547174453735e-01
    z[1,2,0]  R411      -4.5417621731758118e-02
    z[1,2,0]  R412      -1.3537852466106415e-01
    z[1,2,0]  R413      7.9827654361724854e-01
    z[1,2,0]  R414      7.7390931546688080e-02
    z[1,2,0]  R415      1.1108760535717010e-01
    z[1,2,0]  R416      6.6704463958740234e-01
    z[1,2,0]  R417      -6.2267392873764038e-02
    z[1,2,0]  R418      5.9514009952545166e-01
    z[1,2,0]  R419      7.2336536645889282e-01
    z[1,2,0]  R420      0.519419252872467
    z[1,2,0]  R421      3.3257889747619629e-01
    z[1,2,0]  R422      4.8302039504051208e-01
    z[1,2,0]  R423      3.9415013790130615e-01
    z[1,2,0]  R424      3.6163190007209778e-01
    z[1,2,0]  R425      7.2397685050964355e-01
    z[1,2,0]  R426      2.5747874751687050e-02
    z[1,2,0]  R427      4.6654164791107178e-01
    z[1,2,0]  R428      2.6764750480651855e-01
    z[1,2,0]  R429      6.7203575372695923e-01
    z[1,2,0]  R430      3.1270250678062439e-01
    z[1,2,0]  R431      8.6481748148798943e-03
    z[1,2,0]  R432      5.0570660829544067e-01
    z[1,2,0]  R433      5.1533085107803345e-01
    z[1,2,0]  R434      6.8787300586700439e-01
    z[1,2,0]  R435      5.1636826992034912e-01
    z[1,2,0]  R436      3.9412611722946167e-01
    z[1,2,0]  R437      2.9528799653053284e-01
    z[1,2,0]  R438      3.8233464956283569e-01
    z[1,2,0]  R439      4.4280681014060974e-01
    z[1,2,0]  R440      2.8501817584037781e-01
    z[1,2,0]  R441      -6.6540159285068512e-02
    z[1,2,0]  R442      7.2577208280563354e-01
    z[1,2,0]  R443      6.4080274105072021e-01
    z[1,2,0]  R444      4.1627743840217590e-01
    z[1,2,0]  R445      5.0062882900238037e-01
    z[1,2,0]  R446      4.2449519038200378e-01
    z[1,2,0]  R447      0.635075032711029
    z[1,2,0]  R448      3.4158974885940552e-01
    z[1,2,0]  R449      1.6505779325962067e-01
    z[1,2,0]  R450      2.9975670576095581e-01
    z[1,2,0]  R451      -1.8692952394485474e-01
    z[1,2,0]  R452      8.1349158287048340e-01
    z[1,2,0]  R453      6.2359130382537842e-01
    z[1,2,0]  R454      4.8640325665473938e-01
    z[1,2,0]  R455      4.1923937201499939e-01
    z[1,2,0]  R456      0.6805379986763
    z[1,2,0]  R457      3.6483851075172424e-01
    z[1,2,0]  R458      5.0083762407302856e-01
    z[1,2,0]  R459      4.9331733584403992e-01
    z[1,2,0]  R460      3.9891350269317627e-01
    z[1,2,0]  R461      -1.6254135966300964e-01
    z[1,2,0]  R462      -3.8926255702972412e-01
    z[1,2,0]  R463      -1.3564291875809431e-03
    z[1,2,0]  R464      6.3775193691253662e-01
    z[1,2,0]  R465      -7.1092344820499420e-02
    z[1,2,0]  R466      5.1004421710968018e-01
    z[1,2,0]  R467      5.7516175508499146e-01
    z[1,2,0]  R468      5.8088397979736328e-01
    z[1,2,0]  R469      0.561552882194519
    z[1,2,0]  R470      5.3413277864456177e-01
    z[1,2,0]  R471      -3.9800170063972473e-01
    z[1,2,0]  R472      -4.5562595129013062e-01
    z[1,2,0]  R473      8.4574174880981445e-01
    z[1,2,0]  R474      4.4838038086891174e-01
    z[1,2,0]  R475      5.0031250715255737e-01
    z[1,2,0]  R476      0.2799052298069
    z[1,2,0]  R477      5.0745552778244019e-01
    z[1,2,0]  R478      4.3456608057022095e-01
    z[1,2,0]  R479      4.6067798137664795e-01
    z[1,2,0]  R480      5.6948703527450562e-01
    z[1,2,0]  R481      -3.5241582989692688e-01
    z[1,2,0]  R482      -4.7572940587997437e-02
    z[1,2,0]  R483      3.5930645465850830e-01
    z[1,2,0]  R484      7.1881860494613647e-01
    z[1,2,0]  R485      2.6641449332237244e-01
    z[1,2,0]  R486      5.2527123689651489e-01
    z[1,2,0]  R487      2.4020172655582428e-02
    z[1,2,0]  R488      -2.5739121437072754e-01
    z[1,2,0]  R489      -1.3720057904720306e-01
    z[1,2,0]  R490      -0.0615449957549572
    z[1,2,0]  R491      -7.6408244669437408e-02
    z[1,2,0]  R492      6.9351524114608765e-01
    z[1,2,0]  R493      4.3329709768295288e-01
    z[1,2,0]  R494      -4.7730613499879837e-02
    z[1,2,0]  R495      -2.0059393346309662e-01
    z[1,2,0]  R496      -2.2417631745338440e-01
    z[1,2,0]  R497      -2.9909706115722656e-01
    z[1,2,0]  R498      -2.5791233777999878e-01
    z[1,2,0]  R499      3.9937341213226318e-01
    z[1,2,0]  R500      -3.0486646294593811e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R339      -1
    z[1,2,1]  R340      1
    z[1,2,1]  R351      -4.6671545505523682e-01
    z[1,2,1]  R352      -1.3359937071800232e-01
    z[1,2,1]  R353      -5.4755187034606934e-01
    z[1,2,1]  R354      -4.5454701781272888e-01
    z[1,2,1]  R355      8.2258599996566772e-01
    z[1,2,1]  R356      8.3536797761917114e-01
    z[1,2,1]  R357      6.0298210382461548e-01
    z[1,2,1]  R358      6.8687140941619873e-01
    z[1,2,1]  R359      2.5713574886322021e-01
    z[1,2,1]  R360      8.2437044382095337e-01
    z[1,2,1]  R361      -6.3565254211425781e-01
    z[1,2,1]  R362      -2.6428091526031494e-01
    z[1,2,1]  R363      -3.4266650676727295e-01
    z[1,2,1]  R364      1.7891493439674377e-01
    z[1,2,1]  R365      -8.8861101539805532e-04
    z[1,2,1]  R366      7.3406648635864258e-01
    z[1,2,1]  R367      7.5357919931411743e-01
    z[1,2,1]  R368      0.777441143989563
    z[1,2,1]  R369      8.4087914228439331e-01
    z[1,2,1]  R370      6.7594271898269653e-01
    z[1,2,1]  R371      -3.0124077200889587e-01
    z[1,2,1]  R372      -3.4512379765510559e-01
    z[1,2,1]  R373      -7.5806662440299988e-02
    z[1,2,1]  R374      1.4388592541217804e-01
    z[1,2,1]  R375      5.3881222009658813e-01
    z[1,2,1]  R376      8.3683592081069946e-01
    z[1,2,1]  R377      8.5966998338699341e-01
    z[1,2,1]  R378      3.2006371021270752e-01
    z[1,2,1]  R379      5.7017904520034790e-01
    z[1,2,1]  R380      5.0148993730545044e-01
    z[1,2,1]  R381      -3.6733394861221313e-01
    z[1,2,1]  R382      3.8637730479240417e-01
    z[1,2,1]  R383      5.2368111908435822e-02
    z[1,2,1]  R384      1.3667643070220947e-01
    z[1,2,1]  R385      7.8310316801071167e-01
    z[1,2,1]  R386      9.3387198448181152e-01
    z[1,2,1]  R387      7.3081928491592407e-01
    z[1,2,1]  R388      6.8152934312820435e-01
    z[1,2,1]  R389      7.1633970737457275e-01
    z[1,2,1]  R390      6.6614228487014771e-01
    z[1,2,1]  R391      -4.4949498772621155e-01
    z[1,2,1]  R392      -3.3479818701744080e-01
    z[1,2,1]  R393      -4.0453898906707764e-01
    z[1,2,1]  R394      -2.1958525478839874e-01
    z[1,2,1]  R395      -4.5704743266105652e-01
    z[1,2,1]  R396      -3.9728373289108276e-01
    z[1,2,1]  R397      -4.2038300633430481e-01
    z[1,2,1]  R398      -3.3675962686538696e-01
    z[1,2,1]  R399      -3.1949669122695923e-01
    z[1,2,1]  R400      -5.7820230722427368e-01
    z[1,2,1]  R401      -4.9175927042961121e-01
    z[1,2,1]  R402      -4.1158196330070496e-01
    z[1,2,1]  R403      -2.6734501123428345e-01
    z[1,2,1]  R404      -0.53836989402771
    z[1,2,1]  R405      -0.342671275138855
    z[1,2,1]  R406      -0.541056752204895
    z[1,2,1]  R407      -5.0658035278320312e-01
    z[1,2,1]  R408      -4.2686796188354492e-01
    z[1,2,1]  R409      -4.5486468076705933e-01
    z[1,2,1]  R410      -4.7082564234733582e-01
    z[1,2,1]  R411      8.3409690856933594e-01
    z[1,2,1]  R412      8.9928787946701050e-01
    z[1,2,1]  R413      5.4799276590347290e-01
    z[1,2,1]  R414      8.9229595661163330e-01
    z[1,2,1]  R415      8.1544631719589233e-01
    z[1,2,1]  R416      4.9941697716712952e-01
    z[1,2,1]  R417      8.3573579788208008e-01
    z[1,2,1]  R418      6.6910892724990845e-01
    z[1,2,1]  R419      0.512220561504364
    z[1,2,1]  R420      0.647648811340332
    z[1,2,1]  R421      -0.624687135219574
    z[1,2,1]  R422      -1.5297412872314453e-01
    z[1,2,1]  R423      -3.5245409607887268e-01
    z[1,2,1]  R424      3.9174661040306091e-01
    z[1,2,1]  R425      5.8493453264236450e-01
    z[1,2,1]  R426      -4.7863489389419556e-01
    z[1,2,1]  R427      3.3903810381889343e-01
    z[1,2,1]  R428      5.1297110319137573e-01
    z[1,2,1]  R429      2.3550365865230560e-01
    z[1,2,1]  R430      5.3314840793609619e-01
    z[1,2,1]  R431      -2.4784113466739655e-01
    z[1,2,1]  R432      -5.9990996122360229e-01
    z[1,2,1]  R433      -4.7414350509643555e-01
    z[1,2,1]  R434      -3.4876686334609985e-01
    z[1,2,1]  R435      -3.4695991873741150e-01
    z[1,2,1]  R436      4.0909501910209656e-01
    z[1,2,1]  R437      -4.9234721809625626e-02
    z[1,2,1]  R438      5.2433037757873535e-01
    z[1,2,1]  R439      7.4485820531845093e-01
    z[1,2,1]  R440      3.7005302309989929e-01
    z[1,2,1]  R441      -5.4520559310913086e-01
    z[1,2,1]  R442      -3.6321339011192322e-01
    z[1,2,1]  R443      -3.1689906120300293e-01
    z[1,2,1]  R444      4.6174535155296326e-01
    z[1,2,1]  R445      3.0371323227882385e-01
    z[1,2,1]  R446      4.5032000541687012e-01
    z[1,2,1]  R447      3.2231101393699646e-01
    z[1,2,1]  R448      3.0020135641098022e-01
    z[1,2,1]  R449      7.2646868228912354e-01
    z[1,2,1]  R450      2.7069088816642761e-01
    z[1,2,1]  R451      -0.708975076675415
    z[1,2,1]  R452      -3.2215201854705811e-01
    z[1,2,1]  R453      -5.3843152523040771e-01
    z[1,2,1]  R454      -6.7342722415924072e-01
    z[1,2,1]  R455      -1.2217929214239120e-01
    z[1,2,1]  R456      2.8495249152183533e-01
    z[1,2,1]  R457      4.0100643038749695e-01
    z[1,2,1]  R458      6.8663710355758667e-01
    z[1,2,1]  R459      7.4688619375228882e-01
    z[1,2,1]  R460      0.786733090877533
    z[1,2,1]  R461      -5.9715646505355835e-01
    z[1,2,1]  R462      -3.9939552545547485e-01
    z[1,2,1]  R463      -0.359060674905777
    z[1,2,1]  R464      -5.4217046499252319e-01
    z[1,2,1]  R465      -3.9332851767539978e-01
    z[1,2,1]  R466      -6.6162484884262085e-01
    z[1,2,1]  R467      -6.2013298273086548e-01
    z[1,2,1]  R468      -1.5233758091926575e-01
    z[1,2,1]  R469      6.9876176118850708e-01
    z[1,2,1]  R470      4.9144935607910156e-01
    z[1,2,1]  R471      -6.2753462791442871e-01
    z[1,2,1]  R472      -5.0875192880630493e-01
    z[1,2,1]  R473      -3.8915121555328369e-01
    z[1,2,1]  R474      -6.5223330259323120e-01
    z[1,2,1]  R475      -2.3108184337615967e-01
    z[1,2,1]  R476      4.8056399822235107e-01
    z[1,2,1]  R477      6.7994487285614014e-01
    z[1,2,1]  R478      7.9221922159194946e-01
    z[1,2,1]  R479      6.3531875610351562e-01
    z[1,2,1]  R480      0.653005838394165
    z[1,2,1]  R481      -6.4434444904327393e-01
    z[1,2,1]  R482      -0.489510715007782
    z[1,2,1]  R483      -1.9995056092739105e-01
    z[1,2,1]  R484      3.3218595385551453e-01
    z[1,2,1]  R485      8.8451522588729858e-01
    z[1,2,1]  R486      6.7061942815780640e-01
    z[1,2,1]  R487      8.2782679796218872e-01
    z[1,2,1]  R488      8.5486674308776855e-01
    z[1,2,1]  R489      8.5490471124649048e-01
    z[1,2,1]  R490      9.0760940313339233e-01
    z[1,2,1]  R491      -6.9260370731353760e-01
    z[1,2,1]  R492      3.5019379854202271e-01
    z[1,2,1]  R493      7.1538847684860229e-01
    z[1,2,1]  R494      8.1186813116073608e-01
    z[1,2,1]  R495      9.3135637044906616e-01
    z[1,2,1]  R496      9.2622154951095581e-01
    z[1,2,1]  R497      7.4198907613754272e-01
    z[1,2,1]  R498      7.0418852567672729e-01
    z[1,2,1]  R499      6.0367500782012939e-01
    z[1,2,1]  R500      8.0924779176712036e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R341      -1
    z[1,2,2]  R342      1
    z[1,2,2]  R351      -4.8679551482200623e-01
    z[1,2,2]  R352      3.6904752254486084e-02
    z[1,2,2]  R353      7.8874669969081879e-02
    z[1,2,2]  R354      -2.1364346146583557e-01
    z[1,2,2]  R355      1.3000316917896271e-01
    z[1,2,2]  R356      -1.4253102242946625e-01
    z[1,2,2]  R357      -8.2498893141746521e-02
    z[1,2,2]  R358      3.2142437994480133e-02
    z[1,2,2]  R359      2.2951868176460266e-01
    z[1,2,2]  R360      -1.9364626705646515e-01
    z[1,2,2]  R361      4.1217097640037537e-01
    z[1,2,2]  R362      1.3405339419841766e-01
    z[1,2,2]  R363      -2.9808761551976204e-02
    z[1,2,2]  R364      -4.6589165925979614e-01
    z[1,2,2]  R365      9.4442255795001984e-02
    z[1,2,2]  R366      1.6268730163574219e-01
    z[1,2,2]  R367      4.9862369894981384e-02
    z[1,2,2]  R368      2.4379999935626984e-01
    z[1,2,2]  R369      1.8106689676642418e-02
    z[1,2,2]  R370      2.1392691135406494e-01
    z[1,2,2]  R371      -6.2701150774955750e-02
    z[1,2,2]  R372      -2.3533287644386292e-01
    z[1,2,2]  R373      -2.0075348019599915e-01
    z[1,2,2]  R374      -4.6012011170387268e-01
    z[1,2,2]  R375      2.8811085224151611e-01
    z[1,2,2]  R376      2.3537848889827728e-01
    z[1,2,2]  R377      3.6041319370269775e-01
    z[1,2,2]  R378      3.1767565011978149e-01
    z[1,2,2]  R379      4.6150788664817810e-01
    z[1,2,2]  R380      3.1205204129219055e-01
    z[1,2,2]  R381      3.9079514145851135e-01
    z[1,2,2]  R382      -4.7543495893478394e-01
    z[1,2,2]  R383      -3.3568689227104187e-01
    z[1,2,2]  R384      -0.611609697341919
    z[1,2,2]  R385      3.3169406652450562e-01
    z[1,2,2]  R386      1.8586735427379608e-01
    z[1,2,2]  R387      1.6468927264213562e-01
    z[1,2,2]  R388      4.8190999031066895e-01
    z[1,2,2]  R389      1.5249325335025787e-01
    z[1,2,2]  R390      1.0341267101466656e-02
    z[1,2,2]  R391      -8.3873413503170013e-02
    z[1,2,2]  R392      -4.6433258801698685e-02
    z[1,2,2]  R393      -2.2240121662616730e-01
    z[1,2,2]  R394      -2.7171779423952103e-02
    z[1,2,2]  R395      -3.3987402915954590e-01
    z[1,2,2]  R396      -5.5712664127349854e-01
    z[1,2,2]  R397      -1.9285935163497925e-01
    z[1,2,2]  R398      -7.8938134014606476e-02
    z[1,2,2]  R399      -2.2901487350463867e-01
    z[1,2,2]  R400      -7.9810842871665955e-02
    z[1,2,2]  R401      2.6303282380104065e-01
    z[1,2,2]  R402      2.6568922400474548e-01
    z[1,2,2]  R403      4.1921749711036682e-01
    z[1,2,2]  R404      -9.8678901791572571e-02
    z[1,2,2]  R405      -2.0471695065498352e-01
    z[1,2,2]  R406      1.9106050953269005e-02
    z[1,2,2]  R407      -3.7495499849319458e-01
    z[1,2,2]  R408      0.246204674243927
    z[1,2,2]  R409      -7.9527176916599274e-02
    z[1,2,2]  R410      -4.0902385115623474e-01
    z[1,2,2]  R411      2.3406212031841278e-01
    z[1,2,2]  R412      2.1850508451461792e-01
    z[1,2,2]  R413      2.0507957041263580e-01
    z[1,2,2]  R414      2.8700596094131470e-01
    z[1,2,2]  R415      1.1165440827608109e-01
    z[1,2,2]  R416      2.7908065915107727e-01
    z[1,2,2]  R417      1.8962990492582321e-02
    z[1,2,2]  R418      4.4834561645984650e-02
    z[1,2,2]  R419      2.2323322296142578e-01
    z[1,2,2]  R420      1.2390603870153427e-01
    z[1,2,2]  R421      0.0780886635184288
    z[1,2,2]  R422      1.9408886134624481e-01
    z[1,2,2]  R423      -4.8023164272308350e-01
    z[1,2,2]  R424      2.6034104824066162e-01
    z[1,2,2]  R425      1.3381375372409821e-01
    z[1,2,2]  R426      4.1495844721794128e-01
    z[1,2,2]  R427      1.1374760419130325e-01
    z[1,2,2]  R428      -2.3696143925189972e-01
    z[1,2,2]  R429      2.4504022300243378e-01
    z[1,2,2]  R430      -5.6998956203460693e-01
    z[1,2,2]  R431      2.1002964675426483e-01
    z[1,2,2]  R432      1.1083374917507172e-01
    z[1,2,2]  R433      -2.1317757666110992e-01
    z[1,2,2]  R434      2.2484730929136276e-02
    z[1,2,2]  R435      1.1564595997333527e-01
    z[1,2,2]  R436      -3.6476936936378479e-01
    z[1,2,2]  R437      -7.3987501859664917e-01
    z[1,2,2]  R438      -2.7295741438865662e-01
    z[1,2,2]  R439      -1.7261974513530731e-01
    z[1,2,2]  R440      -3.0395638942718506e-01
    z[1,2,2]  R441      -2.3103702813386917e-02
    z[1,2,2]  R442      3.4460190683603287e-02
    z[1,2,2]  R443      0.0395638681948185
    z[1,2,2]  R444      2.0583797991275787e-01
    z[1,2,2]  R445      2.0590786635875702e-01
    z[1,2,2]  R446      2.1422188729047775e-02
    z[1,2,2]  R447      3.2103773951530457e-01
    z[1,2,2]  R448      1.3293132185935974e-01
    z[1,2,2]  R449      1.5961390733718872e-01
    z[1,2,2]  R450      -2.8850415349006653e-01
    z[1,2,2]  R451      3.6791037768125534e-02
    z[1,2,2]  R452      1.2451093643903732e-02
    z[1,2,2]  R453      1.8904432363342494e-04
    z[1,2,2]  R454      -3.2507389783859253e-01
    z[1,2,2]  R455      0.0774095356464386
    z[1,2,2]  R456      3.6462989449501038e-01
    z[1,2,2]  R457      -4.1372212767601013e-01
    z[1,2,2]  R458      -1.2415719032287598e-01
    z[1,2,2]  R459      -0.0970790833234787
    z[1,2,2]  R460      -2.9878395795822144e-01
    z[1,2,2]  R461      1.2553636729717255e-01
    z[1,2,2]  R462      3.5829934477806091e-01
    z[1,2,2]  R463      2.2452621161937714e-01
    z[1,2,2]  R464      -1.6520200669765472e-01
    z[1,2,2]  R465      3.6298206448554993e-01
    z[1,2,2]  R466      6.0138802975416183e-02
    z[1,2,2]  R467      6.9822356104850769e-02
    z[1,2,2]  R468      -3.4507915377616882e-02
    z[1,2,2]  R469      2.3588884621858597e-02
    z[1,2,2]  R470      1.5894058346748352e-01
    z[1,2,2]  R471      2.1491686347872019e-03
    z[1,2,2]  R472      1.8455219268798828e-01
    z[1,2,2]  R473      -5.6969024240970612e-02
    z[1,2,2]  R474      -2.6415362954139709e-01
    z[1,2,2]  R475      1.1966821737587452e-02
    z[1,2,2]  R476      -4.4037967920303345e-01
    z[1,2,2]  R477      -2.6911085471510887e-02
    z[1,2,2]  R478      -1.9403958320617676e-01
    z[1,2,2]  R479      -2.5870782136917114e-01
    z[1,2,2]  R480      -2.3429703712463379e-01
    z[1,2,2]  R481      2.5956448912620544e-01
    z[1,2,2]  R482      3.8324168324470520e-01
    z[1,2,2]  R483      -0.618421196937561
    z[1,2,2]  R484      4.4852638244628906e-01
    z[1,2,2]  R485      1.7736503481864929e-01
    z[1,2,2]  R486      -2.2517210245132446e-01
    z[1,2,2]  R487      -8.2901574671268463e-02
    z[1,2,2]  R488      2.7789219748228788e-03
    z[1,2,2]  R489      -4.8508081585168839e-02
    z[1,2,2]  R490      -5.1402464509010315e-02
    z[1,2,2]  R491      2.8791493177413940e-01
    z[1,2,2]  R492      4.8713916540145874e-01
    z[1,2,2]  R493      -2.3065733909606934e-01
    z[1,2,2]  R494      -7.4305996298789978e-02
    z[1,2,2]  R495      -7.2838112711906433e-02
    z[1,2,2]  R496      -1.8119428306818008e-02
    z[1,2,2]  R497      -3.2035443931818008e-02
    z[1,2,2]  R498      -0.0669550821185112
    z[1,2,2]  R499      -4.0896505117416382e-01
    z[1,2,2]  R500      0.145684614777565
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R343      -1
    z[1,2,3]  R344      1
    z[1,2,3]  R351      1.4971904456615448e-01
    z[1,2,3]  R352      5.6009536981582642e-01
    z[1,2,3]  R353      1.2469938024878502e-02
    z[1,2,3]  R354      6.5791660547256470e-01
    z[1,2,3]  R355      -3.6636710166931152e-01
    z[1,2,3]  R356      -2.0004889369010925e-01
    z[1,2,3]  R357      3.1147342920303345e-01
    z[1,2,3]  R358      -4.0973043441772461e-01
    z[1,2,3]  R359      -5.1095658540725708e-01
    z[1,2,3]  R360      -3.7618669867515564e-01
    z[1,2,3]  R361      0.0747021734714508
    z[1,2,3]  R362      -4.3851667642593384e-01
    z[1,2,3]  R363      -5.4049533605575562e-01
    z[1,2,3]  R364      -1.6657525300979614e-01
    z[1,2,3]  R365      -8.6760473251342773e-01
    z[1,2,3]  R366      -0.604107141494751
    z[1,2,3]  R367      -6.4292007684707642e-01
    z[1,2,3]  R368      -3.9882490038871765e-01
    z[1,2,3]  R369      -3.9741331338882446e-01
    z[1,2,3]  R370      -5.5144232511520386e-01
    z[1,2,3]  R371      3.6425283551216125e-01
    z[1,2,3]  R372      -6.6679733991622925e-01
    z[1,2,3]  R373      -6.8822938203811646e-01
    z[1,2,3]  R374      -5.6779447942972183e-02
    z[1,2,3]  R375      7.2429150342941284e-02
    z[1,2,3]  R376      -3.6378815770149231e-01
    z[1,2,3]  R377      -3.0981072783470154e-01
    z[1,2,3]  R378      -2.4286228418350220e-01
    z[1,2,3]  R379      -4.7408733516931534e-02
    z[1,2,3]  R380      1.5245880186557770e-01
    z[1,2,3]  R381      -6.2550747394561768e-01
    z[1,2,3]  R382      -5.9744048118591309e-01
    z[1,2,3]  R383      -3.2809905707836151e-02
    z[1,2,3]  R384      -1.4084091782569885e-01
    z[1,2,3]  R385      -4.1828554868698120e-01
    z[1,2,3]  R386      -2.3344330489635468e-01
    z[1,2,3]  R387      -5.5787372589111328e-01
    z[1,2,3]  R388      -5.1932847499847412e-01
    z[1,2,3]  R389      8.5775060579180717e-03
    z[1,2,3]  R390      -9.6009470522403717e-02
    z[1,2,3]  R391      -3.1444865465164185e-01
    z[1,2,3]  R392      -1.4626236259937286e-01
    z[1,2,3]  R393      -5.8290481567382812e-01
    z[1,2,3]  R394      -0.359375923871994
    z[1,2,3]  R395      -4.0348294377326965e-01
    z[1,2,3]  R396      -0.338177889585495
    z[1,2,3]  R397      -1.1701557785272598e-01
    z[1,2,3]  R398      -4.8129951953887939e-01
    z[1,2,3]  R399      -0.119330033659935
    z[1,2,3]  R400      -1.2594413757324219e-01
    z[1,2,3]  R401      0.777704656124115
    z[1,2,3]  R402      5.0404578447341919e-01
    z[1,2,3]  R403      7.4074435234069824e-01
    z[1,2,3]  R404      -3.2771375775337219e-01
    z[1,2,3]  R405      -4.4695916771888733e-01
    z[1,2,3]  R406      -1.6949616372585297e-02
    z[1,2,3]  R407      8.2354426383972168e-02
    z[1,2,3]  R408      9.8446160554885864e-02
    z[1,2,3]  R409      1.3948664069175720e-01
    z[1,2,3]  R410      7.8831324353814125e-03
    z[1,2,3]  R411      -4.2408472299575806e-01
    z[1,2,3]  R412      -3.1299224495887756e-01
    z[1,2,3]  R413      3.4943778067827225e-02
    z[1,2,3]  R414      -2.7338418364524841e-01
    z[1,2,3]  R415      -5.3486210107803345e-01
    z[1,2,3]  R416      1.8606856465339661e-01
    z[1,2,3]  R417      -0.537039577960968
    z[1,2,3]  R418      3.3837845921516418e-01
    z[1,2,3]  R419      1.2361179292201996e-01
    z[1,2,3]  R420      5.2461528778076172e-01
    z[1,2,3]  R421      -2.7048733830451965e-01
    z[1,2,3]  R422      -3.6922267079353333e-01
    z[1,2,3]  R423      4.0404331684112549e-01
    z[1,2,3]  R424      6.9523942470550537e-01
    z[1,2,3]  R425      2.1272036433219910e-01
    z[1,2,3]  R426      -5.4666560143232346e-02
    z[1,2,3]  R427      0.553445041179657
    z[1,2,3]  R428      -6.5014642477035522e-01
    z[1,2,3]  R429      5.9282785654067993e-01
    z[1,2,3]  R430      -4.9514451622962952e-01
    z[1,2,3]  R431      5.3969818353652954e-01
    z[1,2,3]  R432      -4.2107868194580078e-01
    z[1,2,3]  R433      4.0940076112747192e-01
    z[1,2,3]  R434      3.0737709999084473e-01
    z[1,2,3]  R435      -9.6147827804088593e-02
    z[1,2,3]  R436      -6.3931626081466675e-01
    z[1,2,3]  R437      5.4876238107681274e-01
    z[1,2,3]  R438      -3.9552164077758789e-01
    z[1,2,3]  R439      -2.9253163933753967e-01
    z[1,2,3]  R440      -3.9204615354537964e-01
    z[1,2,3]  R441      2.5662720203399658e-01
    z[1,2,3]  R442      2.6621833443641663e-01
    z[1,2,3]  R443      -3.8232272863388062e-01
    z[1,2,3]  R444      6.3889360427856445e-01
    z[1,2,3]  R445      7.0790648460388184e-01
    z[1,2,3]  R446      6.2034225463867188e-01
    z[1,2,3]  R447      -4.5698079466819763e-01
    z[1,2,3]  R448      6.6236847639083862e-01
    z[1,2,3]  R449      -3.5968446731567383e-01
    z[1,2,3]  R450      -5.0943839550018311e-01
    z[1,2,3]  R451      0.479433536529541
    z[1,2,3]  R452      -1.0581338405609131e-01
    z[1,2,3]  R453      2.8363707661628723e-01
    z[1,2,3]  R454      3.5104501247406006e-01
    z[1,2,3]  R455      -2.9018688201904297e-01
    z[1,2,3]  R456      -1.8076236546039581e-01
    z[1,2,3]  R457      -4.5794364809989929e-01
    z[1,2,3]  R458      -8.6128480732440948e-02
    z[1,2,3]  R459      -1.3811598718166351e-01
    z[1,2,3]  R460      -5.3824737668037415e-02
    z[1,2,3]  R461      6.4488071203231812e-01
    z[1,2,3]  R462      6.2346053123474121e-01
    z[1,2,3]  R463      0.664882481098175
    z[1,2,3]  R464      -3.2524743676185608e-01
    z[1,2,3]  R465      5.5865764617919922e-01
    z[1,2,3]  R466      -1.5654183924198151e-01
    z[1,2,3]  R467      -2.9144337773323059e-01
    z[1,2,3]  R468      -6.5572023391723633e-01
    z[1,2,3]  R469      1.2729948759078979e-01
    z[1,2,3]  R470      4.0542042255401611e-01
    z[1,2,3]  R471      3.1787082552909851e-01
    z[1,2,3]  R472      4.4996318221092224e-01
    z[1,2,3]  R473      -3.1418710947036743e-01
    z[1,2,3]  R474      3.8389632105827332e-01
    z[1,2,3]  R475      -5.3141820430755615e-01
    z[1,2,3]  R476      -0.643108606338501
    z[1,2,3]  R477      -2.4881545454263687e-02
    z[1,2,3]  R478      -2.0807598531246185e-01
    z[1,2,3]  R479      -1.1604075133800507e-01
    z[1,2,3]  R480      -0.272417277097702
    z[1,2,3]  R481      4.8620399832725525e-01
    z[1,2,3]  R482      5.2253186702728271e-01
    z[1,2,3]  R483      0.405316561460495
    z[1,2,3]  R484      -1.4786474406719208e-01
    z[1,2,3]  R485      -1.6723164916038513e-01
    z[1,2,3]  R486      -1.1875883489847183e-01
    z[1,2,3]  R487      2.3033621907234192e-01
    z[1,2,3]  R488      2.2643083333969116e-01
    z[1,2,3]  R489      1.6457028687000275e-01
    z[1,2,3]  R490      1.6401518881320953e-01
    z[1,2,3]  R491      5.4490929841995239e-01
    z[1,2,3]  R492      -8.8538669049739838e-02
    z[1,2,3]  R493      -1.3700371980667114e-01
    z[1,2,3]  R494      1.9309966266155243e-01
    z[1,2,3]  R495      2.3324583470821381e-01
    z[1,2,3]  R496      2.7790060639381409e-01
    z[1,2,3]  R497      0.458374559879303
    z[1,2,3]  R498      4.9108245968818665e-01
    z[1,2,3]  R499      -2.0483481884002686e-01
    z[1,2,3]  R500      3.1911596655845642e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R345      -1
    z[1,2,4]  R346      1
    z[1,2,4]  R351      6.4057117700576782e-01
    z[1,2,4]  R352      8.0915719270706177e-01
    z[1,2,4]  R353      -5.6615126132965088e-01
    z[1,2,4]  R354      -4.7507378458976746e-01
    z[1,2,4]  R355      -0.077522411942482
    z[1,2,4]  R356      -2.0425860583782196e-01
    z[1,2,4]  R357      -2.8395134210586548e-01
    z[1,2,4]  R358      -2.5203731656074524e-01
    z[1,2,4]  R359      1.7024983465671539e-01
    z[1,2,4]  R360      -2.1192273497581482e-01
    z[1,2,4]  R361      -2.3790630698204041e-01
    z[1,2,4]  R362      -3.1093001365661621e-01
    z[1,2,4]  R363      -4.6103402972221375e-01
    z[1,2,4]  R364      -1.1760532110929489e-01
    z[1,2,4]  R365      -1.2174691259860992e-01
    z[1,2,4]  R366      2.1174573898315430e-01
    z[1,2,4]  R367      3.1613189727067947e-02
    z[1,2,4]  R368      -3.2433861494064331e-01
    z[1,2,4]  R369      -1.9215957820415497e-01
    z[1,2,4]  R370      -4.2228358983993530e-01
    z[1,2,4]  R371      -4.4058007001876831e-01
    z[1,2,4]  R372      -4.0291124582290649e-01
    z[1,2,4]  R373      -5.0877290964126587e-01
    z[1,2,4]  R374      -1.5007355809211731e-01
    z[1,2,4]  R375      -2.6901068165898323e-02
    z[1,2,4]  R376      -1.9950826466083527e-01
    z[1,2,4]  R377      2.1566031500697136e-02
    z[1,2,4]  R378      -1.1014854535460472e-02
    z[1,2,4]  R379      -1.1080067604780197e-01
    z[1,2,4]  R380      -0.186312735080719
    z[1,2,4]  R381      0.0716809555888176
    z[1,2,4]  R382      -1.8982166051864624e-01
    z[1,2,4]  R383      -9.6350491046905518e-02
    z[1,2,4]  R384      -1.2929193675518036e-01
    z[1,2,4]  R385      1.0879338532686234e-01
    z[1,2,4]  R386      1.5406674146652222e-01
    z[1,2,4]  R387      -2.7404522895812988e-01
    z[1,2,4]  R388      -1.9865857902914286e-03
    z[1,2,4]  R389      1.0958957672119141e-01
    z[1,2,4]  R390      -1.0130358487367630e-01
    z[1,2,4]  R391      7.6696373522281647e-02
    z[1,2,4]  R392      -1.3601037859916687e-01
    z[1,2,4]  R393      2.6907208561897278e-01
    z[1,2,4]  R394      -2.7263644337654114e-01
    z[1,2,4]  R395      -3.4290242195129395e-01
    z[1,2,4]  R396      -2.7971944212913513e-01
    z[1,2,4]  R397      -0.45118448138237
    z[1,2,4]  R398      -3.6923289299011230e-02
    z[1,2,4]  R399      -1.7339762300252914e-02
    z[1,2,4]  R400      -4.2922419309616089e-01
    z[1,2,4]  R401      1.5936696529388428e-01
    z[1,2,4]  R402      5.2261584997177124e-01
    z[1,2,4]  R403      -1.9508515298366547e-01
    z[1,2,4]  R404      2.5149953365325928e-01
    z[1,2,4]  R405      -3.6170445382595062e-02
    z[1,2,4]  R406      6.0345385223627090e-02
    z[1,2,4]  R407      3.2775735855102539e-01
    z[1,2,4]  R408      -1.6123975813388824e-01
    z[1,2,4]  R409      -1.1112906038761139e-02
    z[1,2,4]  R410      -1.7066720128059387e-01
    z[1,2,4]  R411      -2.5070169568061829e-01
    z[1,2,4]  R412      -1.6315679252147675e-01
    z[1,2,4]  R413      -0.0604669563472271
    z[1,2,4]  R414      -3.4378089010715485e-02
    z[1,2,4]  R415      3.7657979875802994e-02
    z[1,2,4]  R416      -1.8559253215789795e-01
    z[1,2,4]  R417      7.3197752237319946e-02
    z[1,2,4]  R418      2.6784452795982361e-01
    z[1,2,4]  R419      -3.4259593486785889e-01
    z[1,2,4]  R420      -7.1928925812244415e-02
    z[1,2,4]  R421      -4.5762622356414795e-01
    z[1,2,4]  R422      -1.5903252363204956e-01
    z[1,2,4]  R423      2.1625605225563049e-01
    z[1,2,4]  R424      1.7825832590460777e-02
    z[1,2,4]  R425      1.1625821888446808e-01
    z[1,2,4]  R426      -3.0601578950881958e-01
    z[1,2,4]  R427      4.7598907351493835e-01
    z[1,2,4]  R428      -3.3756002783775330e-01
    z[1,2,4]  R429      2.4750913679599762e-01
    z[1,2,4]  R430      -8.3448909223079681e-02
    z[1,2,4]  R431      0.265316367149353
    z[1,2,4]  R432      -9.8314777016639709e-02
    z[1,2,4]  R433      -4.5501780509948730e-01
    z[1,2,4]  R434      -3.0927973985671997e-01
    z[1,2,4]  R435      -6.9239658117294312e-01
    z[1,2,4]  R436      1.4795464277267456e-01
    z[1,2,4]  R437      -2.1814560890197754e-01
    z[1,2,4]  R438      -3.9844788610935211e-02
    z[1,2,4]  R439      2.5043150782585144e-01
    z[1,2,4]  R440      5.3612012416124344e-02
    z[1,2,4]  R441      7.2713029384613037e-01
    z[1,2,4]  R442      -0.322696328163147
    z[1,2,4]  R443      -2.0935116708278656e-01
    z[1,2,4]  R444      2.8589293360710144e-01
    z[1,2,4]  R445      2.4938410520553589e-01
    z[1,2,4]  R446      1.0532125830650330e-01
    z[1,2,4]  R447      -1.1799144744873047e-01
    z[1,2,4]  R448      -2.9631054401397705e-01
    z[1,2,4]  R449      -2.1745118498802185e-01
    z[1,2,4]  R450      -1.9360281527042389e-01
    z[1,2,4]  R451      5.6955549865961075e-02
    z[1,2,4]  R452      -2.4683679640293121e-01
    z[1,2,4]  R453      1.5325234830379486e-01
    z[1,2,4]  R454      -1.2517413496971130e-01
    z[1,2,4]  R455      6.5691810846328735e-01
    z[1,2,4]  R456      4.9956849217414856e-01
    z[1,2,4]  R457      1.3732229173183441e-01
    z[1,2,4]  R458      -3.8667482137680054e-01
    z[1,2,4]  R459      -3.3884474635124207e-01
    z[1,2,4]  R460      -1.7403274774551392e-01
    z[1,2,4]  R461      0.289171040058136
    z[1,2,4]  R462      0.0606367364525795
    z[1,2,4]  R463      -4.7994937747716904e-02
    z[1,2,4]  R464      2.9373185709118843e-02
    z[1,2,4]  R465      2.4802295863628387e-01
    z[1,2,4]  R466      -3.9063632488250732e-01
    z[1,2,4]  R467      3.0453100800514221e-01
    z[1,2,4]  R468      -3.2805752754211426e-01
    z[1,2,4]  R469      -2.0189037919044495e-01
    z[1,2,4]  R470      -5.9273969382047653e-03
    z[1,2,4]  R471      3.1691977381706238e-01
    z[1,2,4]  R472      3.9639544486999512e-01
    z[1,2,4]  R473      -9.6043810248374939e-02
    z[1,2,4]  R474      -5.7641044259071350e-02
    z[1,2,4]  R475      4.5994570851325989e-01
    z[1,2,4]  R476      -4.5340526849031448e-02
    z[1,2,4]  R477      4.6919766813516617e-02
    z[1,2,4]  R478      -0.274619460105896
    z[1,2,4]  R479      4.3874431401491165e-02
    z[1,2,4]  R480      -0.214004248380661
    z[1,2,4]  R481      2.3286873102188110e-01
    z[1,2,4]  R482      -1.6028711199760437e-01
    z[1,2,4]  R483      3.3477634191513062e-01
    z[1,2,4]  R484      1.7664463818073273e-01
    z[1,2,4]  R485      -1.3306210935115814e-01
    z[1,2,4]  R486      -1.6326928511261940e-02
    z[1,2,4]  R487      -2.6743057370185852e-01
    z[1,2,4]  R488      -8.3587124943733215e-02
    z[1,2,4]  R489      -2.1492704749107361e-02
    z[1,2,4]  R490      -8.7991170585155487e-02
    z[1,2,4]  R491      2.9614555835723877e-01
    z[1,2,4]  R492      1.3326078653335571e-01
    z[1,2,4]  R493      1.1991009861230850e-01
    z[1,2,4]  R494      -2.1958047151565552e-01
    z[1,2,4]  R495      -1.2943805195391178e-02
    z[1,2,4]  R496      2.4993417784571648e-02
    z[1,2,4]  R497      3.1518232822418213e-01
    z[1,2,4]  R498      2.3044927418231964e-01
    z[1,2,4]  R499      1.8626351654529572e-01
    z[1,2,4]  R500      7.2187192738056183e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R347      -1
    z[1,2,5]  R348      1
    z[1,2,5]  R351      -2.0066772401332855e-01
    z[1,2,5]  R352      -5.9441626071929932e-02
    z[1,2,5]  R353      2.7653029561042786e-01
    z[1,2,5]  R354      5.4726753383874893e-02
    z[1,2,5]  R355      3.3891800791025162e-02
    z[1,2,5]  R356      3.3521682024002075e-01
    z[1,2,5]  R357      -1.5599071979522705e-01
    z[1,2,5]  R358      2.5600078515708447e-03
    z[1,2,5]  R359      3.7962925434112549e-01
    z[1,2,5]  R360      1.4176584780216217e-01
    z[1,2,5]  R361      -5.8701831102371216e-01
    z[1,2,5]  R362      -1.1679384857416153e-01
    z[1,2,5]  R363      -3.2678428292274475e-01
    z[1,2,5]  R364      -5.0479900836944580e-01
    z[1,2,5]  R365      -4.6577075123786926e-01
    z[1,2,5]  R366      -1.2833803892135620e-01
    z[1,2,5]  R367      -1.1914358288049698e-01
    z[1,2,5]  R368      -7.5452238321304321e-02
    z[1,2,5]  R369      1.5624926984310150e-01
    z[1,2,5]  R370      -2.7592654805630445e-03
    z[1,2,5]  R371      3.9353662729263306e-01
    z[1,2,5]  R372      -4.4771060347557068e-01
    z[1,2,5]  R373      -2.4050267040729523e-01
    z[1,2,5]  R374      -5.0918138027191162e-01
    z[1,2,5]  R375      2.8002321720123291e-01
    z[1,2,5]  R376      -0.0396539680659771
    z[1,2,5]  R377      -3.9080310612916946e-02
    z[1,2,5]  R378      -1.9320229068398476e-02
    z[1,2,5]  R379      -1.4455287717282772e-02
    z[1,2,5]  R380      -1.0613378137350082e-01
    z[1,2,5]  R381      -4.5793151855468750e-01
    z[1,2,5]  R382      -1.9242644309997559e-01
    z[1,2,5]  R383      -5.7479149103164673e-01
    z[1,2,5]  R384      -1.8723320960998535e-01
    z[1,2,5]  R385      -2.7032741904258728e-01
    z[1,2,5]  R386      4.8314131796360016e-02
    z[1,2,5]  R387      -2.3204919416457415e-03
    z[1,2,5]  R388      -1.4920058846473694e-01
    z[1,2,5]  R389      -3.3517464995384216e-01
    z[1,2,5]  R390      -3.0391353368759155e-01
    z[1,2,5]  R391      -4.0913251042366028e-01
    z[1,2,5]  R392      -1.9938772916793823e-01
    z[1,2,5]  R393      -2.4501414597034454e-01
    z[1,2,5]  R394      -2.0833808183670044e-01
    z[1,2,5]  R395      -1.5545871853828430e-01
    z[1,2,5]  R396      -1.2104744091629982e-02
    z[1,2,5]  R397      -2.4415870010852814e-01
    z[1,2,5]  R398      1.5470339357852936e-01
    z[1,2,5]  R399      -1.3708001375198364e-01
    z[1,2,5]  R400      -4.8285737633705139e-01
    z[1,2,5]  R401      1.7897954583168030e-01
    z[1,2,5]  R402      4.1876620054244995e-01
    z[1,2,5]  R403      6.2775970436632633e-03
    z[1,2,5]  R404      -1.4662048220634460e-01
    z[1,2,5]  R405      1.0123351216316223e-01
    z[1,2,5]  R406      4.1432702541351318e-01
    z[1,2,5]  R407      2.8929945826530457e-01
    z[1,2,5]  R408      -1.0790634900331497e-01
    z[1,2,5]  R409      1.8880537152290344e-01
    z[1,2,5]  R410      4.1776046156883240e-01
    z[1,2,5]  R411      -4.5226030051708221e-02
    z[1,2,5]  R412      -2.3367213085293770e-02
    z[1,2,5]  R413      6.7532330751419067e-02
    z[1,2,5]  R414      -1.6712664067745209e-01
    z[1,2,5]  R415      -9.5498561859130859e-02
    z[1,2,5]  R416      3.7924793362617493e-01
    z[1,2,5]  R417      -5.3726937621831894e-02
    z[1,2,5]  R418      4.1719831526279449e-02
    z[1,2,5]  R419      1.7668071389198303e-01
    z[1,2,5]  R420      -1.0164061188697815e-01
    z[1,2,5]  R421      4.5092034339904785e-01
    z[1,2,5]  R422      -8.1328481435775757e-02
    z[1,2,5]  R423      -5.1702845096588135e-01
    z[1,2,5]  R424      4.0486997365951538e-01
    z[1,2,5]  R425      1.6480258107185364e-01
    z[1,2,5]  R426      0.627466082572937
    z[1,2,5]  R427      0.29982790350914
    z[1,2,5]  R428      -2.3215073347091675e-01
    z[1,2,5]  R429      1.1857450753450394e-01
    z[1,2,5]  R430      -1.3388405740261078e-01
    z[1,2,5]  R431      -7.0382517576217651e-01
    z[1,2,5]  R432      1.1174259334802628e-01
    z[1,2,5]  R433      2.1935574710369110e-01
    z[1,2,5]  R434      -1.0182154178619385e-01
    z[1,2,5]  R435      3.2961988449096680e-01
    z[1,2,5]  R436      -2.5022733211517334e-01
    z[1,2,5]  R437      1.4056839980185032e-02
    z[1,2,5]  R438      -5.8268398046493530e-01
    z[1,2,5]  R439      -2.6642149686813354e-01
    z[1,2,5]  R440      -6.7784243822097778e-01
    z[1,2,5]  R441      7.2239354252815247e-02
    z[1,2,5]  R442      -8.8432334363460541e-02
    z[1,2,5]  R443      5.2897727489471436e-01
    z[1,2,5]  R444      2.8498110175132751e-01
    z[1,2,5]  R445      -2.2599442303180695e-01
    z[1,2,5]  R446      5.6194867938756943e-02
    z[1,2,5]  R447      3.1944376230239868e-01
    z[1,2,5]  R448      -4.6117216348648071e-01
    z[1,2,5]  R449      2.5276523828506470e-01
    z[1,2,5]  R450      -6.7564010620117188e-01
    z[1,2,5]  R451      2.1172720938920975e-02
    z[1,2,5]  R452      -4.0027502179145813e-01
    z[1,2,5]  R453      -1.6390261054039001e-01
    z[1,2,5]  R454      1.1652058362960815e-01
    z[1,2,5]  R455      -1.5202715992927551e-01
    z[1,2,5]  R456      -1.8972858786582947e-01
    z[1,2,5]  R457      -4.7291836142539978e-01
    z[1,2,5]  R458      -2.6897612214088440e-01
    z[1,2,5]  R459      -2.3124687373638153e-01
    z[1,2,5]  R460      -2.3645384609699249e-01
    z[1,2,5]  R461      -3.5391256213188171e-02
    z[1,2,5]  R462      2.5909817218780518e-01
    z[1,2,5]  R463      -0.613033652305603
    z[1,2,5]  R464      -2.3402197659015656e-01
    z[1,2,5]  R465      -0.316095769405365
    z[1,2,5]  R466      3.4054023027420044e-01
    z[1,2,5]  R467      2.4003812670707703e-01
    z[1,2,5]  R468      1.8813515082001686e-02
    z[1,2,5]  R469      -3.4905764460563660e-01
    z[1,2,5]  R470      -4.9916657805442810e-01
    z[1,2,5]  R471      3.1575998663902283e-01
    z[1,2,5]  R472      3.7309196591377258e-01
    z[1,2,5]  R473      7.0639267563819885e-02
    z[1,2,5]  R474      2.4038922786712646e-01
    z[1,2,5]  R475      4.4128566980361938e-02
    z[1,2,5]  R476      -2.6686057448387146e-01
    z[1,2,5]  R477      -5.0679403543472290e-01
    z[1,2,5]  R478      -1.3757790625095367e-01
    z[1,2,5]  R479      -3.3155736327171326e-01
    z[1,2,5]  R480      1.9013158977031708e-01
    z[1,2,5]  R481      2.9067987203598022e-01
    z[1,2,5]  R482      -2.9712867736816406e-01
    z[1,2,5]  R483      -9.7113199532032013e-02
    z[1,2,5]  R484      -4.4012613594532013e-02
    z[1,2,5]  R485      2.5967252254486084e-01
    z[1,2,5]  R486      -2.6901009678840637e-01
    z[1,2,5]  R487      2.6603478193283081e-01
    z[1,2,5]  R488      3.7837705016136169e-01
    z[1,2,5]  R489      4.4696322083473206e-01
    z[1,2,5]  R490      3.3983856439590454e-01
    z[1,2,5]  R491      -1.0552906990051270e-01
    z[1,2,5]  R492      2.3850056529045105e-01
    z[1,2,5]  R493      -0.34966841340065
    z[1,2,5]  R494      3.8474443554878235e-01
    z[1,2,5]  R495      7.0009604096412659e-02
    z[1,2,5]  R496      -1.1616861820220947e-01
    z[1,2,5]  R497      -7.8402034938335419e-02
    z[1,2,5]  R498      -3.5456646233797073e-02
    z[1,2,5]  R499      4.7586232423782349e-01
    z[1,2,5]  R500      0.0745057761669159
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R349      -1
    z[1,2,6]  R350      1
    z[1,2,6]  R351      -2.4560314416885376e-01
    z[1,2,6]  R352      -8.6249615997076035e-03
    z[1,2,6]  R353      4.5009684562683105e-01
    z[1,2,6]  R354      8.4467105567455292e-02
    z[1,2,6]  R355      3.5163056850433350e-01
    z[1,2,6]  R356      1.7577911913394928e-01
    z[1,2,6]  R357      1.4857438392937183e-02
    z[1,2,6]  R358      -5.3883910179138184e-01
    z[1,2,6]  R359      -0.0820883959531784
    z[1,2,6]  R360      -2.7637362480163574e-01
    z[1,2,6]  R361      -1.2720239348709583e-02
    z[1,2,6]  R362      -7.6829922199249268e-01
    z[1,2,6]  R363      -5.1832711696624756e-01
    z[1,2,6]  R364      3.2919490337371826e-01
    z[1,2,6]  R365      -7.9426631331443787e-02
    z[1,2,6]  R366      -8.2022309303283691e-02
    z[1,2,6]  R367      1.7222639173269272e-02
    z[1,2,6]  R368      -2.2025832533836365e-01
    z[1,2,6]  R369      -1.8181389570236206e-01
    z[1,2,6]  R370      -0.0487905852496624
    z[1,2,6]  R371      -6.4627546072006226e-01
    z[1,2,6]  R372      -9.0783812105655670e-02
    z[1,2,6]  R373      -2.0084077119827271e-01
    z[1,2,6]  R374      2.7500659227371216e-01
    z[1,2,6]  R375      0.0792355015873909
    z[1,2,6]  R376      2.6192107796669006e-01
    z[1,2,6]  R377      -1.4711722731590271e-01
    z[1,2,6]  R378      0.0408710315823555
    z[1,2,6]  R379      -1.4940334856510162e-01
    z[1,2,6]  R380      7.1755279786884785e-03
    z[1,2,6]  R381      1.7631410062313080e-01
    z[1,2,6]  R382      -3.2058694958686829e-01
    z[1,2,6]  R383      4.4458872079849243e-01
    z[1,2,6]  R384      6.3253903388977051e-01
    z[1,2,6]  R385      -2.7765689417719841e-02
    z[1,2,6]  R386      5.8352392166852951e-02
    z[1,2,6]  R387      1.5340046584606171e-01
    z[1,2,6]  R388      -1.0635794699192047e-01
    z[1,2,6]  R389      2.2697240114212036e-01
    z[1,2,6]  R390      3.6155867576599121e-01
    z[1,2,6]  R391      -1.6492843627929688e-01
    z[1,2,6]  R392      -9.3961074948310852e-02
    z[1,2,6]  R393      -3.5728029906749725e-02
    z[1,2,6]  R394      -3.2833582162857056e-01
    z[1,2,6]  R395      3.2686257362365723e-01
    z[1,2,6]  R396      -1.4039170928299427e-02
    z[1,2,6]  R397      1.2344378232955933e-01
    z[1,2,6]  R398      -2.3563358187675476e-01
    z[1,2,6]  R399      3.1386756896972656e-01
    z[1,2,6]  R400      1.3855537772178650e-01
    z[1,2,6]  R401      1.1553360521793365e-01
    z[1,2,6]  R402      -1.8122033774852753e-01
    z[1,2,6]  R403      -3.7590980529785156e-01
    z[1,2,6]  R404      0.141273632645607
    z[1,2,6]  R405      3.6761730909347534e-01
    z[1,2,6]  R406      2.5172346830368042e-01
    z[1,2,6]  R407      2.3954164981842041e-01
    z[1,2,6]  R408      -3.3420255780220032e-01
    z[1,2,6]  R409      -6.5239536762237549e-01
    z[1,2,6]  R410      -4.3621074408292770e-02
    z[1,2,6]  R411      -0.0518658272922039
    z[1,2,6]  R412      8.8990144431591034e-03
    z[1,2,6]  R413      1.0470316559076309e-01
    z[1,2,6]  R414      1.0767577588558197e-01
    z[1,2,6]  R415      -1.1672386527061462e-01
    z[1,2,6]  R416      -1.2187291681766510e-01
    z[1,2,6]  R417      2.5548562407493591e-02
    z[1,2,6]  R418      0.0900566577911377
    z[1,2,6]  R419      2.5914067402482033e-02
    z[1,2,6]  R420      6.8382412195205688e-02
    z[1,2,6]  R421      -8.4528736770153046e-02
    z[1,2,6]  R422      -7.3306798934936523e-01
    z[1,2,6]  R423      1.1163865774869919e-01
    z[1,2,6]  R424      -1.9604042172431946e-02
    z[1,2,6]  R425      -1.7284965515136719e-01
    z[1,2,6]  R426      3.2818809151649475e-01
    z[1,2,6]  R427      1.7801612615585327e-01
    z[1,2,6]  R428      -1.3617551326751709e-01
    z[1,2,6]  R429      -7.8074358403682709e-02
    z[1,2,6]  R430      1.5174004435539246e-01
    z[1,2,6]  R431      -0.193263441324234
    z[1,2,6]  R432      -4.1548219323158264e-01
    z[1,2,6]  R433      -2.0349536836147308e-01
    z[1,2,6]  R434      4.5186790823936462e-01
    z[1,2,6]  R435      -4.7979336231946945e-02
    z[1,2,6]  R436      -2.2587533295154572e-01
    z[1,2,6]  R437      -1.1849322170019150e-01
    z[1,2,6]  R438      -8.2743220031261444e-02
    z[1,2,6]  R439      -6.2936772592365742e-03
    z[1,2,6]  R440      2.7090808749198914e-01
    z[1,2,6]  R441      3.1304123997688293e-01
    z[1,2,6]  R442      3.9663332700729370e-01
    z[1,2,6]  R443      -1.3253666460514069e-01
    z[1,2,6]  R444      -1.0549268918111920e-03
    z[1,2,6]  R445      1.8261510878801346e-02
    z[1,2,6]  R446      4.6634960174560547e-01
    z[1,2,6]  R447      -2.5481829047203064e-01
    z[1,2,6]  R448      1.9056017696857452e-01
    z[1,2,6]  R449      4.2305365204811096e-01
    z[1,2,6]  R450      -1.1774463579058647e-02
    z[1,2,6]  R451      0.476979523897171
    z[1,2,6]  R452      0.0441533662378788
    z[1,2,6]  R453      4.3637722730636597e-01
    z[1,2,6]  R454      -2.2750008106231689e-01
    z[1,2,6]  R455      -5.1425302028656006e-01
    z[1,2,6]  R456      -6.6892087459564209e-02
    z[1,2,6]  R457      2.8757461905479431e-01
    z[1,2,6]  R458      1.8163864314556122e-01
    z[1,2,6]  R459      4.4809184968471527e-02
    z[1,2,6]  R460      2.0869192481040955e-01
    z[1,2,6]  R461      3.1698805093765259e-01
    z[1,2,6]  R462      -3.1791147589683533e-01
    z[1,2,6]  R463      -0.0218859501183033
    z[1,2,6]  R464      3.3259138464927673e-01
    z[1,2,6]  R465      -4.8471871018409729e-01
    z[1,2,6]  R466      7.3627866804599762e-02
    z[1,2,6]  R467      -0.210836723446846
    z[1,2,6]  R468      -3.1659367680549622e-01
    z[1,2,6]  R469      -1.3049063086509705e-01
    z[1,2,6]  R470      -1.8533644080162048e-01
    z[1,2,6]  R471      3.8289141654968262e-01
    z[1,2,6]  R472      -2.6891345158219337e-02
    z[1,2,6]  R473      1.3080124557018280e-01
    z[1,2,6]  R474      -3.0868074297904968e-01
    z[1,2,6]  R475      -4.4748479127883911e-01
    z[1,2,6]  R476      9.9589407444000244e-02
    z[1,2,6]  R477      -1.4063747227191925e-01
    z[1,2,6]  R478      -0.0908326730132103
    z[1,2,6]  R479      4.3805864453315735e-01
    z[1,2,6]  R480      1.9548374414443970e-01
    z[1,2,6]  R481      -1.3465739786624908e-01
    z[1,2,6]  R482      -4.7352391481399536e-01
    z[1,2,6]  R483      -4.0334376692771912e-01
    z[1,2,6]  R484      -3.4171923995018005e-01
    z[1,2,6]  R485      -0.0457824245095253
    z[1,2,6]  R486      3.7002786993980408e-01
    z[1,2,6]  R487      3.3452188968658447e-01
    z[1,2,6]  R488      3.8959000259637833e-02
    z[1,2,6]  R489      1.4366483688354492e-01
    z[1,2,6]  R490      1.4029106497764587e-01
    z[1,2,6]  R491      -1.8921458721160889e-01
    z[1,2,6]  R492      -2.7679666876792908e-01
    z[1,2,6]  R493      3.0307358503341675e-01
    z[1,2,6]  R494      3.1549820303916931e-01
    z[1,2,6]  R495      1.6601040959358215e-01
    z[1,2,6]  R496      1.3481980189681053e-02
    z[1,2,6]  R497      2.0826151967048645e-01
    z[1,2,6]  R498      3.7093237042427063e-01
    z[1,2,6]  R499      -7.5687073171138763e-02
    z[1,2,6]  R500      -0.344025194644928
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R501      -1
    z[2,1,0]  R502      1
    z[2,1,0]  R515      -7.0111936330795288e-01
    z[2,1,0]  R516      -0.89290452003479
    z[2,1,0]  R517      -5.5982106924057007e-01
    z[2,1,0]  R518      -7.7223902940750122e-01
    z[2,1,0]  R519      -5.1400977373123169e-01
    z[2,1,0]  R520      -5.8208656311035156e-01
    z[2,1,0]  R521      -7.0283114910125732e-01
    z[2,1,0]  R522      -7.5358664989471436e-01
    z[2,1,0]  R523      -8.4476613998413086e-01
    z[2,1,0]  R524      -4.5482754707336426e-01
    z[2,1,0]  R525      -1.1568231880664825e-01
    z[2,1,0]  R526      -1.5688852965831757e-01
    z[2,1,0]  R527      -1.5708351135253906e-01
    z[2,1,0]  R528      0.698796272277832
    z[2,1,0]  R529      7.0299059152603149e-01
    z[2,1,0]  R530      6.8405562639236450e-01
    z[2,1,0]  R531      5.8949434757232666e-01
    z[2,1,0]  R532      7.7339643239974976e-01
    z[2,1,0]  R533      5.5310606956481934e-01
    z[2,1,0]  R534      6.3671547174453735e-01
    z[2,1,0]  R535      -4.5417621731758118e-02
    z[2,1,0]  R536      -1.3537852466106415e-01
    z[2,1,0]  R537      7.9827654361724854e-01
    z[2,1,0]  R538      7.7390931546688080e-02
    z[2,1,0]  R539      1.1108760535717010e-01
    z[2,1,0]  R540      6.6704463958740234e-01
    z[2,1,0]  R541      -6.2267392873764038e-02
    z[2,1,0]  R542      5.9514009952545166e-01
    z[2,1,0]  R543      7.2336536645889282e-01
    z[2,1,0]  R544      0.519419252872467
    z[2,1,0]  R545      3.3257889747619629e-01
    z[2,1,0]  R546      4.8302039504051208e-01
    z[2,1,0]  R547      3.9415013790130615e-01
    z[2,1,0]  R548      3.6163190007209778e-01
    z[2,1,0]  R549      7.2397685050964355e-01
    z[2,1,0]  R550      2.5747874751687050e-02
    z[2,1,0]  R551      4.6654164791107178e-01
    z[2,1,0]  R552      2.6764750480651855e-01
    z[2,1,0]  R553      6.7203575372695923e-01
    z[2,1,0]  R554      3.1270250678062439e-01
    z[2,1,0]  R555      8.6481748148798943e-03
    z[2,1,0]  R556      5.0570660829544067e-01
    z[2,1,0]  R557      5.1533085107803345e-01
    z[2,1,0]  R558      6.8787300586700439e-01
    z[2,1,0]  R559      5.1636826992034912e-01
    z[2,1,0]  R560      3.9412611722946167e-01
    z[2,1,0]  R561      2.9528799653053284e-01
    z[2,1,0]  R562      3.8233464956283569e-01
    z[2,1,0]  R563      4.4280681014060974e-01
    z[2,1,0]  R564      2.8501817584037781e-01
    z[2,1,0]  R565      -6.6540159285068512e-02
    z[2,1,0]  R566      7.2577208280563354e-01
    z[2,1,0]  R567      6.4080274105072021e-01
    z[2,1,0]  R568      4.1627743840217590e-01
    z[2,1,0]  R569      5.0062882900238037e-01
    z[2,1,0]  R570      4.2449519038200378e-01
    z[2,1,0]  R571      0.635075032711029
    z[2,1,0]  R572      3.4158974885940552e-01
    z[2,1,0]  R573      1.6505779325962067e-01
    z[2,1,0]  R574      2.9975670576095581e-01
    z[2,1,0]  R575      -1.8692952394485474e-01
    z[2,1,0]  R576      8.1349158287048340e-01
    z[2,1,0]  R577      6.2359130382537842e-01
    z[2,1,0]  R578      4.8640325665473938e-01
    z[2,1,0]  R579      4.1923937201499939e-01
    z[2,1,0]  R580      0.6805379986763
    z[2,1,0]  R581      3.6483851075172424e-01
    z[2,1,0]  R582      5.0083762407302856e-01
    z[2,1,0]  R583      4.9331733584403992e-01
    z[2,1,0]  R584      3.9891350269317627e-01
    z[2,1,0]  R585      -1.6254135966300964e-01
    z[2,1,0]  R586      -3.8926255702972412e-01
    z[2,1,0]  R587      -1.3564291875809431e-03
    z[2,1,0]  R588      6.3775193691253662e-01
    z[2,1,0]  R589      -7.1092344820499420e-02
    z[2,1,0]  R590      5.1004421710968018e-01
    z[2,1,0]  R591      5.7516175508499146e-01
    z[2,1,0]  R592      5.8088397979736328e-01
    z[2,1,0]  R593      0.561552882194519
    z[2,1,0]  R594      5.3413277864456177e-01
    z[2,1,0]  R595      -3.9800170063972473e-01
    z[2,1,0]  R596      -4.5562595129013062e-01
    z[2,1,0]  R597      8.4574174880981445e-01
    z[2,1,0]  R598      4.4838038086891174e-01
    z[2,1,0]  R599      5.0031250715255737e-01
    z[2,1,0]  R600      0.2799052298069
    z[2,1,0]  R601      5.0745552778244019e-01
    z[2,1,0]  R602      4.3456608057022095e-01
    z[2,1,0]  R603      4.6067798137664795e-01
    z[2,1,0]  R604      5.6948703527450562e-01
    z[2,1,0]  R605      -3.5241582989692688e-01
    z[2,1,0]  R606      -4.7572940587997437e-02
    z[2,1,0]  R607      3.5930645465850830e-01
    z[2,1,0]  R608      7.1881860494613647e-01
    z[2,1,0]  R609      2.6641449332237244e-01
    z[2,1,0]  R610      5.2527123689651489e-01
    z[2,1,0]  R611      2.4020172655582428e-02
    z[2,1,0]  R612      -2.5739121437072754e-01
    z[2,1,0]  R613      -1.3720057904720306e-01
    z[2,1,0]  R614      -0.0615449957549572
    z[2,1,0]  R615      -7.6408244669437408e-02
    z[2,1,0]  R616      6.9351524114608765e-01
    z[2,1,0]  R617      4.3329709768295288e-01
    z[2,1,0]  R618      -4.7730613499879837e-02
    z[2,1,0]  R619      -2.0059393346309662e-01
    z[2,1,0]  R620      -2.2417631745338440e-01
    z[2,1,0]  R621      -2.9909706115722656e-01
    z[2,1,0]  R622      -2.5791233777999878e-01
    z[2,1,0]  R623      3.9937341213226318e-01
    z[2,1,0]  R624      -3.0486646294593811e-01
    z[2,1,0]  R625      1.0895483195781708e-01
    z[2,1,0]  R626      0.0934840589761734
    z[2,1,0]  R627      3.0696392059326172e-01
    z[2,1,0]  R628      -2.8118395805358887e-01
    z[2,1,0]  R629      -2.0352919399738312e-01
    z[2,1,0]  R630      2.3840183019638062e-01
    z[2,1,0]  R631      6.5376496315002441e-01
    z[2,1,0]  R632      7.3611110448837280e-02
    z[2,1,0]  R633      6.6353899240493774e-01
    z[2,1,0]  R634      -2.6388000696897507e-03
    z[2,1,0]  R635      -1.3830715417861938e-01
    z[2,1,0]  R636      1.3887564837932587e-01
    z[2,1,0]  R637      -3.9402008056640625e-02
    z[2,1,0]  R638      -5.8835762739181519e-01
    z[2,1,0]  R639      1.6388840973377228e-02
    z[2,1,0]  R640      -4.1222300380468369e-02
    z[2,1,0]  R641      2.8189649805426598e-02
    z[2,1,0]  R642      -1.3297820091247559e-01
    z[2,1,0]  R643      -0.200653538107872
    z[2,1,0]  R644      -1.1196637898683548e-01
    z[2,1,0]  R645      7.7385380864143372e-02
    z[2,1,0]  R646      -9.9324166774749756e-02
    z[2,1,0]  R647      -3.5108867287635803e-01
    z[2,1,0]  R648      -6.3792335987091064e-01
    z[2,1,0]  R649      7.3212879896163940e-01
    z[2,1,0]  R650      4.4521890580654144e-02
    z[2,1,0]  R651      1.0701041668653488e-01
    z[2,1,0]  R652      8.5760957002639771e-01
    z[2,1,0]  R653      6.5180635452270508e-01
    z[2,1,0]  R654      7.6279711723327637e-01
    z[2,1,0]  R655      2.7415168285369873e-01
    z[2,1,0]  R656      -0.303154855966568
    z[2,1,0]  R657      -0.588360071182251
    z[2,1,0]  R658      -3.6815574765205383e-01
    z[2,1,0]  R659      1.2681372463703156e-01
    z[2,1,0]  R660      -9.6772246062755585e-02
    z[2,1,0]  R661      -1.7005759477615356e-01
    z[2,1,0]  R662      -1.2802829733118415e-03
    z[2,1,0]  R663      -5.3634065389633179e-01
    z[2,1,0]  R664      -5.5998134613037109e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R503      -1
    z[2,1,1]  R504      1
    z[2,1,1]  R515      -4.4949498772621155e-01
    z[2,1,1]  R516      -3.3479818701744080e-01
    z[2,1,1]  R517      -4.0453898906707764e-01
    z[2,1,1]  R518      -2.1958525478839874e-01
    z[2,1,1]  R519      -4.5704743266105652e-01
    z[2,1,1]  R520      -3.9728373289108276e-01
    z[2,1,1]  R521      -4.2038300633430481e-01
    z[2,1,1]  R522      -3.3675962686538696e-01
    z[2,1,1]  R523      -3.1949669122695923e-01
    z[2,1,1]  R524      -5.7820230722427368e-01
    z[2,1,1]  R525      -4.9175927042961121e-01
    z[2,1,1]  R526      -4.1158196330070496e-01
    z[2,1,1]  R527      -2.6734501123428345e-01
    z[2,1,1]  R528      -0.53836989402771
    z[2,1,1]  R529      -0.342671275138855
    z[2,1,1]  R530      -0.541056752204895
    z[2,1,1]  R531      -5.0658035278320312e-01
    z[2,1,1]  R532      -4.2686796188354492e-01
    z[2,1,1]  R533      -4.5486468076705933e-01
    z[2,1,1]  R534      -4.7082564234733582e-01
    z[2,1,1]  R535      8.3409690856933594e-01
    z[2,1,1]  R536      8.9928787946701050e-01
    z[2,1,1]  R537      5.4799276590347290e-01
    z[2,1,1]  R538      8.9229595661163330e-01
    z[2,1,1]  R539      8.1544631719589233e-01
    z[2,1,1]  R540      4.9941697716712952e-01
    z[2,1,1]  R541      8.3573579788208008e-01
    z[2,1,1]  R542      6.6910892724990845e-01
    z[2,1,1]  R543      0.512220561504364
    z[2,1,1]  R544      0.647648811340332
    z[2,1,1]  R545      -0.624687135219574
    z[2,1,1]  R546      -1.5297412872314453e-01
    z[2,1,1]  R547      -3.5245409607887268e-01
    z[2,1,1]  R548      3.9174661040306091e-01
    z[2,1,1]  R549      5.8493453264236450e-01
    z[2,1,1]  R550      -4.7863489389419556e-01
    z[2,1,1]  R551      3.3903810381889343e-01
    z[2,1,1]  R552      5.1297110319137573e-01
    z[2,1,1]  R553      2.3550365865230560e-01
    z[2,1,1]  R554      5.3314840793609619e-01
    z[2,1,1]  R555      -2.4784113466739655e-01
    z[2,1,1]  R556      -5.9990996122360229e-01
    z[2,1,1]  R557      -4.7414350509643555e-01
    z[2,1,1]  R558      -3.4876686334609985e-01
    z[2,1,1]  R559      -3.4695991873741150e-01
    z[2,1,1]  R560      4.0909501910209656e-01
    z[2,1,1]  R561      -4.9234721809625626e-02
    z[2,1,1]  R562      5.2433037757873535e-01
    z[2,1,1]  R563      7.4485820531845093e-01
    z[2,1,1]  R564      3.7005302309989929e-01
    z[2,1,1]  R565      -5.4520559310913086e-01
    z[2,1,1]  R566      -3.6321339011192322e-01
    z[2,1,1]  R567      -3.1689906120300293e-01
    z[2,1,1]  R568      4.6174535155296326e-01
    z[2,1,1]  R569      3.0371323227882385e-01
    z[2,1,1]  R570      4.5032000541687012e-01
    z[2,1,1]  R571      3.2231101393699646e-01
    z[2,1,1]  R572      3.0020135641098022e-01
    z[2,1,1]  R573      7.2646868228912354e-01
    z[2,1,1]  R574      2.7069088816642761e-01
    z[2,1,1]  R575      -0.708975076675415
    z[2,1,1]  R576      -3.2215201854705811e-01
    z[2,1,1]  R577      -5.3843152523040771e-01
    z[2,1,1]  R578      -6.7342722415924072e-01
    z[2,1,1]  R579      -1.2217929214239120e-01
    z[2,1,1]  R580      2.8495249152183533e-01
    z[2,1,1]  R581      4.0100643038749695e-01
    z[2,1,1]  R582      6.8663710355758667e-01
    z[2,1,1]  R583      7.4688619375228882e-01
    z[2,1,1]  R584      0.786733090877533
    z[2,1,1]  R585      -5.9715646505355835e-01
    z[2,1,1]  R586      -3.9939552545547485e-01
    z[2,1,1]  R587      -0.359060674905777
    z[2,1,1]  R588      -5.4217046499252319e-01
    z[2,1,1]  R589      -3.9332851767539978e-01
    z[2,1,1]  R590      -6.6162484884262085e-01
    z[2,1,1]  R591      -6.2013298273086548e-01
    z[2,1,1]  R592      -1.5233758091926575e-01
    z[2,1,1]  R593      6.9876176118850708e-01
    z[2,1,1]  R594      4.9144935607910156e-01
    z[2,1,1]  R595      -6.2753462791442871e-01
    z[2,1,1]  R596      -5.0875192880630493e-01
    z[2,1,1]  R597      -3.8915121555328369e-01
    z[2,1,1]  R598      -6.5223330259323120e-01
    z[2,1,1]  R599      -2.3108184337615967e-01
    z[2,1,1]  R600      4.8056399822235107e-01
    z[2,1,1]  R601      6.7994487285614014e-01
    z[2,1,1]  R602      7.9221922159194946e-01
    z[2,1,1]  R603      6.3531875610351562e-01
    z[2,1,1]  R604      0.653005838394165
    z[2,1,1]  R605      -6.4434444904327393e-01
    z[2,1,1]  R606      -0.489510715007782
    z[2,1,1]  R607      -1.9995056092739105e-01
    z[2,1,1]  R608      3.3218595385551453e-01
    z[2,1,1]  R609      8.8451522588729858e-01
    z[2,1,1]  R610      6.7061942815780640e-01
    z[2,1,1]  R611      8.2782679796218872e-01
    z[2,1,1]  R612      8.5486674308776855e-01
    z[2,1,1]  R613      8.5490471124649048e-01
    z[2,1,1]  R614      9.0760940313339233e-01
    z[2,1,1]  R615      -6.9260370731353760e-01
    z[2,1,1]  R616      3.5019379854202271e-01
    z[2,1,1]  R617      7.1538847684860229e-01
    z[2,1,1]  R618      8.1186813116073608e-01
    z[2,1,1]  R619      9.3135637044906616e-01
    z[2,1,1]  R620      9.2622154951095581e-01
    z[2,1,1]  R621      7.4198907613754272e-01
    z[2,1,1]  R622      7.0418852567672729e-01
    z[2,1,1]  R623      6.0367500782012939e-01
    z[2,1,1]  R624      8.0924779176712036e-01
    z[2,1,1]  R625      -4.6671545505523682e-01
    z[2,1,1]  R626      -1.3359937071800232e-01
    z[2,1,1]  R627      -5.4755187034606934e-01
    z[2,1,1]  R628      -4.5454701781272888e-01
    z[2,1,1]  R629      8.2258599996566772e-01
    z[2,1,1]  R630      8.3536797761917114e-01
    z[2,1,1]  R631      6.0298210382461548e-01
    z[2,1,1]  R632      6.8687140941619873e-01
    z[2,1,1]  R633      2.5713574886322021e-01
    z[2,1,1]  R634      8.2437044382095337e-01
    z[2,1,1]  R635      -6.3565254211425781e-01
    z[2,1,1]  R636      -2.6428091526031494e-01
    z[2,1,1]  R637      -3.4266650676727295e-01
    z[2,1,1]  R638      1.7891493439674377e-01
    z[2,1,1]  R639      -8.8861101539805532e-04
    z[2,1,1]  R640      7.3406648635864258e-01
    z[2,1,1]  R641      7.5357919931411743e-01
    z[2,1,1]  R642      0.777441143989563
    z[2,1,1]  R643      8.4087914228439331e-01
    z[2,1,1]  R644      6.7594271898269653e-01
    z[2,1,1]  R645      -3.0124077200889587e-01
    z[2,1,1]  R646      -3.4512379765510559e-01
    z[2,1,1]  R647      -7.5806662440299988e-02
    z[2,1,1]  R648      1.4388592541217804e-01
    z[2,1,1]  R649      5.3881222009658813e-01
    z[2,1,1]  R650      8.3683592081069946e-01
    z[2,1,1]  R651      8.5966998338699341e-01
    z[2,1,1]  R652      3.2006371021270752e-01
    z[2,1,1]  R653      5.7017904520034790e-01
    z[2,1,1]  R654      5.0148993730545044e-01
    z[2,1,1]  R655      -3.6733394861221313e-01
    z[2,1,1]  R656      3.8637730479240417e-01
    z[2,1,1]  R657      5.2368111908435822e-02
    z[2,1,1]  R658      1.3667643070220947e-01
    z[2,1,1]  R659      7.8310316801071167e-01
    z[2,1,1]  R660      9.3387198448181152e-01
    z[2,1,1]  R661      7.3081928491592407e-01
    z[2,1,1]  R662      6.8152934312820435e-01
    z[2,1,1]  R663      7.1633970737457275e-01
    z[2,1,1]  R664      6.6614228487014771e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R505      -1
    z[2,1,2]  R506      1
    z[2,1,2]  R515      -8.3873413503170013e-02
    z[2,1,2]  R516      -4.6433258801698685e-02
    z[2,1,2]  R517      -2.2240121662616730e-01
    z[2,1,2]  R518      -2.7171779423952103e-02
    z[2,1,2]  R519      -3.3987402915954590e-01
    z[2,1,2]  R520      -5.5712664127349854e-01
    z[2,1,2]  R521      -1.9285935163497925e-01
    z[2,1,2]  R522      -7.8938134014606476e-02
    z[2,1,2]  R523      -2.2901487350463867e-01
    z[2,1,2]  R524      -7.9810842871665955e-02
    z[2,1,2]  R525      2.6303282380104065e-01
    z[2,1,2]  R526      2.6568922400474548e-01
    z[2,1,2]  R527      4.1921749711036682e-01
    z[2,1,2]  R528      -9.8678901791572571e-02
    z[2,1,2]  R529      -2.0471695065498352e-01
    z[2,1,2]  R530      1.9106050953269005e-02
    z[2,1,2]  R531      -3.7495499849319458e-01
    z[2,1,2]  R532      0.246204674243927
    z[2,1,2]  R533      -7.9527176916599274e-02
    z[2,1,2]  R534      -4.0902385115623474e-01
    z[2,1,2]  R535      2.3406212031841278e-01
    z[2,1,2]  R536      2.1850508451461792e-01
    z[2,1,2]  R537      2.0507957041263580e-01
    z[2,1,2]  R538      2.8700596094131470e-01
    z[2,1,2]  R539      1.1165440827608109e-01
    z[2,1,2]  R540      2.7908065915107727e-01
    z[2,1,2]  R541      1.8962990492582321e-02
    z[2,1,2]  R542      4.4834561645984650e-02
    z[2,1,2]  R543      2.2323322296142578e-01
    z[2,1,2]  R544      1.2390603870153427e-01
    z[2,1,2]  R545      0.0780886635184288
    z[2,1,2]  R546      1.9408886134624481e-01
    z[2,1,2]  R547      -4.8023164272308350e-01
    z[2,1,2]  R548      2.6034104824066162e-01
    z[2,1,2]  R549      1.3381375372409821e-01
    z[2,1,2]  R550      4.1495844721794128e-01
    z[2,1,2]  R551      1.1374760419130325e-01
    z[2,1,2]  R552      -2.3696143925189972e-01
    z[2,1,2]  R553      2.4504022300243378e-01
    z[2,1,2]  R554      -5.6998956203460693e-01
    z[2,1,2]  R555      2.1002964675426483e-01
    z[2,1,2]  R556      1.1083374917507172e-01
    z[2,1,2]  R557      -2.1317757666110992e-01
    z[2,1,2]  R558      2.2484730929136276e-02
    z[2,1,2]  R559      1.1564595997333527e-01
    z[2,1,2]  R560      -3.6476936936378479e-01
    z[2,1,2]  R561      -7.3987501859664917e-01
    z[2,1,2]  R562      -2.7295741438865662e-01
    z[2,1,2]  R563      -1.7261974513530731e-01
    z[2,1,2]  R564      -3.0395638942718506e-01
    z[2,1,2]  R565      -2.3103702813386917e-02
    z[2,1,2]  R566      3.4460190683603287e-02
    z[2,1,2]  R567      0.0395638681948185
    z[2,1,2]  R568      2.0583797991275787e-01
    z[2,1,2]  R569      2.0590786635875702e-01
    z[2,1,2]  R570      2.1422188729047775e-02
    z[2,1,2]  R571      3.2103773951530457e-01
    z[2,1,2]  R572      1.3293132185935974e-01
    z[2,1,2]  R573      1.5961390733718872e-01
    z[2,1,2]  R574      -2.8850415349006653e-01
    z[2,1,2]  R575      3.6791037768125534e-02
    z[2,1,2]  R576      1.2451093643903732e-02
    z[2,1,2]  R577      1.8904432363342494e-04
    z[2,1,2]  R578      -3.2507389783859253e-01
    z[2,1,2]  R579      0.0774095356464386
    z[2,1,2]  R580      3.6462989449501038e-01
    z[2,1,2]  R581      -4.1372212767601013e-01
    z[2,1,2]  R582      -1.2415719032287598e-01
    z[2,1,2]  R583      -0.0970790833234787
    z[2,1,2]  R584      -2.9878395795822144e-01
    z[2,1,2]  R585      1.2553636729717255e-01
    z[2,1,2]  R586      3.5829934477806091e-01
    z[2,1,2]  R587      2.2452621161937714e-01
    z[2,1,2]  R588      -1.6520200669765472e-01
    z[2,1,2]  R589      3.6298206448554993e-01
    z[2,1,2]  R590      6.0138802975416183e-02
    z[2,1,2]  R591      6.9822356104850769e-02
    z[2,1,2]  R592      -3.4507915377616882e-02
    z[2,1,2]  R593      2.3588884621858597e-02
    z[2,1,2]  R594      1.5894058346748352e-01
    z[2,1,2]  R595      2.1491686347872019e-03
    z[2,1,2]  R596      1.8455219268798828e-01
    z[2,1,2]  R597      -5.6969024240970612e-02
    z[2,1,2]  R598      -2.6415362954139709e-01
    z[2,1,2]  R599      1.1966821737587452e-02
    z[2,1,2]  R600      -4.4037967920303345e-01
    z[2,1,2]  R601      -2.6911085471510887e-02
    z[2,1,2]  R602      -1.9403958320617676e-01
    z[2,1,2]  R603      -2.5870782136917114e-01
    z[2,1,2]  R604      -2.3429703712463379e-01
    z[2,1,2]  R605      2.5956448912620544e-01
    z[2,1,2]  R606      3.8324168324470520e-01
    z[2,1,2]  R607      -0.618421196937561
    z[2,1,2]  R608      4.4852638244628906e-01
    z[2,1,2]  R609      1.7736503481864929e-01
    z[2,1,2]  R610      -2.2517210245132446e-01
    z[2,1,2]  R611      -8.2901574671268463e-02
    z[2,1,2]  R612      2.7789219748228788e-03
    z[2,1,2]  R613      -4.8508081585168839e-02
    z[2,1,2]  R614      -5.1402464509010315e-02
    z[2,1,2]  R615      2.8791493177413940e-01
    z[2,1,2]  R616      4.8713916540145874e-01
    z[2,1,2]  R617      -2.3065733909606934e-01
    z[2,1,2]  R618      -7.4305996298789978e-02
    z[2,1,2]  R619      -7.2838112711906433e-02
    z[2,1,2]  R620      -1.8119428306818008e-02
    z[2,1,2]  R621      -3.2035443931818008e-02
    z[2,1,2]  R622      -0.0669550821185112
    z[2,1,2]  R623      -4.0896505117416382e-01
    z[2,1,2]  R624      0.145684614777565
    z[2,1,2]  R625      -4.8679551482200623e-01
    z[2,1,2]  R626      3.6904752254486084e-02
    z[2,1,2]  R627      7.8874669969081879e-02
    z[2,1,2]  R628      -2.1364346146583557e-01
    z[2,1,2]  R629      1.3000316917896271e-01
    z[2,1,2]  R630      -1.4253102242946625e-01
    z[2,1,2]  R631      -8.2498893141746521e-02
    z[2,1,2]  R632      3.2142437994480133e-02
    z[2,1,2]  R633      2.2951868176460266e-01
    z[2,1,2]  R634      -1.9364626705646515e-01
    z[2,1,2]  R635      4.1217097640037537e-01
    z[2,1,2]  R636      1.3405339419841766e-01
    z[2,1,2]  R637      -2.9808761551976204e-02
    z[2,1,2]  R638      -4.6589165925979614e-01
    z[2,1,2]  R639      9.4442255795001984e-02
    z[2,1,2]  R640      1.6268730163574219e-01
    z[2,1,2]  R641      4.9862369894981384e-02
    z[2,1,2]  R642      2.4379999935626984e-01
    z[2,1,2]  R643      1.8106689676642418e-02
    z[2,1,2]  R644      2.1392691135406494e-01
    z[2,1,2]  R645      -6.2701150774955750e-02
    z[2,1,2]  R646      -2.3533287644386292e-01
    z[2,1,2]  R647      -2.0075348019599915e-01
    z[2,1,2]  R648      -4.6012011170387268e-01
    z[2,1,2]  R649      2.8811085224151611e-01
    z[2,1,2]  R650      2.3537848889827728e-01
    z[2,1,2]  R651      3.6041319370269775e-01
    z[2,1,2]  R652      3.1767565011978149e-01
    z[2,1,2]  R653      4.6150788664817810e-01
    z[2,1,2]  R654      3.1205204129219055e-01
    z[2,1,2]  R655      3.9079514145851135e-01
    z[2,1,2]  R656      -4.7543495893478394e-01
    z[2,1,2]  R657      -3.3568689227104187e-01
    z[2,1,2]  R658      -0.611609697341919
    z[2,1,2]  R659      3.3169406652450562e-01
    z[2,1,2]  R660      1.8586735427379608e-01
    z[2,1,2]  R661      1.6468927264213562e-01
    z[2,1,2]  R662      4.8190999031066895e-01
    z[2,1,2]  R663      1.5249325335025787e-01
    z[2,1,2]  R664      1.0341267101466656e-02
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R507      -1
    z[2,1,3]  R508      1
    z[2,1,3]  R515      -3.1444865465164185e-01
    z[2,1,3]  R516      -1.4626236259937286e-01
    z[2,1,3]  R517      -5.8290481567382812e-01
    z[2,1,3]  R518      -0.359375923871994
    z[2,1,3]  R519      -4.0348294377326965e-01
    z[2,1,3]  R520      -0.338177889585495
    z[2,1,3]  R521      -1.1701557785272598e-01
    z[2,1,3]  R522      -4.8129951953887939e-01
    z[2,1,3]  R523      -0.119330033659935
    z[2,1,3]  R524      -1.2594413757324219e-01
    z[2,1,3]  R525      0.777704656124115
    z[2,1,3]  R526      5.0404578447341919e-01
    z[2,1,3]  R527      7.4074435234069824e-01
    z[2,1,3]  R528      -3.2771375775337219e-01
    z[2,1,3]  R529      -4.4695916771888733e-01
    z[2,1,3]  R530      -1.6949616372585297e-02
    z[2,1,3]  R531      8.2354426383972168e-02
    z[2,1,3]  R532      9.8446160554885864e-02
    z[2,1,3]  R533      1.3948664069175720e-01
    z[2,1,3]  R534      7.8831324353814125e-03
    z[2,1,3]  R535      -4.2408472299575806e-01
    z[2,1,3]  R536      -3.1299224495887756e-01
    z[2,1,3]  R537      3.4943778067827225e-02
    z[2,1,3]  R538      -2.7338418364524841e-01
    z[2,1,3]  R539      -5.3486210107803345e-01
    z[2,1,3]  R540      1.8606856465339661e-01
    z[2,1,3]  R541      -0.537039577960968
    z[2,1,3]  R542      3.3837845921516418e-01
    z[2,1,3]  R543      1.2361179292201996e-01
    z[2,1,3]  R544      5.2461528778076172e-01
    z[2,1,3]  R545      -2.7048733830451965e-01
    z[2,1,3]  R546      -3.6922267079353333e-01
    z[2,1,3]  R547      4.0404331684112549e-01
    z[2,1,3]  R548      6.9523942470550537e-01
    z[2,1,3]  R549      2.1272036433219910e-01
    z[2,1,3]  R550      -5.4666560143232346e-02
    z[2,1,3]  R551      0.553445041179657
    z[2,1,3]  R552      -6.5014642477035522e-01
    z[2,1,3]  R553      5.9282785654067993e-01
    z[2,1,3]  R554      -4.9514451622962952e-01
    z[2,1,3]  R555      5.3969818353652954e-01
    z[2,1,3]  R556      -4.2107868194580078e-01
    z[2,1,3]  R557      4.0940076112747192e-01
    z[2,1,3]  R558      3.0737709999084473e-01
    z[2,1,3]  R559      -9.6147827804088593e-02
    z[2,1,3]  R560      -6.3931626081466675e-01
    z[2,1,3]  R561      5.4876238107681274e-01
    z[2,1,3]  R562      -3.9552164077758789e-01
    z[2,1,3]  R563      -2.9253163933753967e-01
    z[2,1,3]  R564      -3.9204615354537964e-01
    z[2,1,3]  R565      2.5662720203399658e-01
    z[2,1,3]  R566      2.6621833443641663e-01
    z[2,1,3]  R567      -3.8232272863388062e-01
    z[2,1,3]  R568      6.3889360427856445e-01
    z[2,1,3]  R569      7.0790648460388184e-01
    z[2,1,3]  R570      6.2034225463867188e-01
    z[2,1,3]  R571      -4.5698079466819763e-01
    z[2,1,3]  R572      6.6236847639083862e-01
    z[2,1,3]  R573      -3.5968446731567383e-01
    z[2,1,3]  R574      -5.0943839550018311e-01
    z[2,1,3]  R575      0.479433536529541
    z[2,1,3]  R576      -1.0581338405609131e-01
    z[2,1,3]  R577      2.8363707661628723e-01
    z[2,1,3]  R578      3.5104501247406006e-01
    z[2,1,3]  R579      -2.9018688201904297e-01
    z[2,1,3]  R580      -1.8076236546039581e-01
    z[2,1,3]  R581      -4.5794364809989929e-01
    z[2,1,3]  R582      -8.6128480732440948e-02
    z[2,1,3]  R583      -1.3811598718166351e-01
    z[2,1,3]  R584      -5.3824737668037415e-02
    z[2,1,3]  R585      6.4488071203231812e-01
    z[2,1,3]  R586      6.2346053123474121e-01
    z[2,1,3]  R587      0.664882481098175
    z[2,1,3]  R588      -3.2524743676185608e-01
    z[2,1,3]  R589      5.5865764617919922e-01
    z[2,1,3]  R590      -1.5654183924198151e-01
    z[2,1,3]  R591      -2.9144337773323059e-01
    z[2,1,3]  R592      -6.5572023391723633e-01
    z[2,1,3]  R593      1.2729948759078979e-01
    z[2,1,3]  R594      4.0542042255401611e-01
    z[2,1,3]  R595      3.1787082552909851e-01
    z[2,1,3]  R596      4.4996318221092224e-01
    z[2,1,3]  R597      -3.1418710947036743e-01
    z[2,1,3]  R598      3.8389632105827332e-01
    z[2,1,3]  R599      -5.3141820430755615e-01
    z[2,1,3]  R600      -0.643108606338501
    z[2,1,3]  R601      -2.4881545454263687e-02
    z[2,1,3]  R602      -2.0807598531246185e-01
    z[2,1,3]  R603      -1.1604075133800507e-01
    z[2,1,3]  R604      -0.272417277097702
    z[2,1,3]  R605      4.8620399832725525e-01
    z[2,1,3]  R606      5.2253186702728271e-01
    z[2,1,3]  R607      0.405316561460495
    z[2,1,3]  R608      -1.4786474406719208e-01
    z[2,1,3]  R609      -1.6723164916038513e-01
    z[2,1,3]  R610      -1.1875883489847183e-01
    z[2,1,3]  R611      2.3033621907234192e-01
    z[2,1,3]  R612      2.2643083333969116e-01
    z[2,1,3]  R613      1.6457028687000275e-01
    z[2,1,3]  R614      1.6401518881320953e-01
    z[2,1,3]  R615      5.4490929841995239e-01
    z[2,1,3]  R616      -8.8538669049739838e-02
    z[2,1,3]  R617      -1.3700371980667114e-01
    z[2,1,3]  R618      1.9309966266155243e-01
    z[2,1,3]  R619      2.3324583470821381e-01
    z[2,1,3]  R620      2.7790060639381409e-01
    z[2,1,3]  R621      0.458374559879303
    z[2,1,3]  R622      4.9108245968818665e-01
    z[2,1,3]  R623      -2.0483481884002686e-01
    z[2,1,3]  R624      3.1911596655845642e-01
    z[2,1,3]  R625      1.4971904456615448e-01
    z[2,1,3]  R626      5.6009536981582642e-01
    z[2,1,3]  R627      1.2469938024878502e-02
    z[2,1,3]  R628      6.5791660547256470e-01
    z[2,1,3]  R629      -3.6636710166931152e-01
    z[2,1,3]  R630      -2.0004889369010925e-01
    z[2,1,3]  R631      3.1147342920303345e-01
    z[2,1,3]  R632      -4.0973043441772461e-01
    z[2,1,3]  R633      -5.1095658540725708e-01
    z[2,1,3]  R634      -3.7618669867515564e-01
    z[2,1,3]  R635      0.0747021734714508
    z[2,1,3]  R636      -4.3851667642593384e-01
    z[2,1,3]  R637      -5.4049533605575562e-01
    z[2,1,3]  R638      -1.6657525300979614e-01
    z[2,1,3]  R639      -8.6760473251342773e-01
    z[2,1,3]  R640      -0.604107141494751
    z[2,1,3]  R641      -6.4292007684707642e-01
    z[2,1,3]  R642      -3.9882490038871765e-01
    z[2,1,3]  R643      -3.9741331338882446e-01
    z[2,1,3]  R644      -5.5144232511520386e-01
    z[2,1,3]  R645      3.6425283551216125e-01
    z[2,1,3]  R646      -6.6679733991622925e-01
    z[2,1,3]  R647      -6.8822938203811646e-01
    z[2,1,3]  R648      -5.6779447942972183e-02
    z[2,1,3]  R649      7.2429150342941284e-02
    z[2,1,3]  R650      -3.6378815770149231e-01
    z[2,1,3]  R651      -3.0981072783470154e-01
    z[2,1,3]  R652      -2.4286228418350220e-01
    z[2,1,3]  R653      -4.7408733516931534e-02
    z[2,1,3]  R654      1.5245880186557770e-01
    z[2,1,3]  R655      -6.2550747394561768e-01
    z[2,1,3]  R656      -5.9744048118591309e-01
    z[2,1,3]  R657      -3.2809905707836151e-02
    z[2,1,3]  R658      -1.4084091782569885e-01
    z[2,1,3]  R659      -4.1828554868698120e-01
    z[2,1,3]  R660      -2.3344330489635468e-01
    z[2,1,3]  R661      -5.5787372589111328e-01
    z[2,1,3]  R662      -5.1932847499847412e-01
    z[2,1,3]  R663      8.5775060579180717e-03
    z[2,1,3]  R664      -9.6009470522403717e-02
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R509      -1
    z[2,1,4]  R510      1
    z[2,1,4]  R515      7.6696373522281647e-02
    z[2,1,4]  R516      -1.3601037859916687e-01
    z[2,1,4]  R517      2.6907208561897278e-01
    z[2,1,4]  R518      -2.7263644337654114e-01
    z[2,1,4]  R519      -3.4290242195129395e-01
    z[2,1,4]  R520      -2.7971944212913513e-01
    z[2,1,4]  R521      -0.45118448138237
    z[2,1,4]  R522      -3.6923289299011230e-02
    z[2,1,4]  R523      -1.7339762300252914e-02
    z[2,1,4]  R524      -4.2922419309616089e-01
    z[2,1,4]  R525      1.5936696529388428e-01
    z[2,1,4]  R526      5.2261584997177124e-01
    z[2,1,4]  R527      -1.9508515298366547e-01
    z[2,1,4]  R528      2.5149953365325928e-01
    z[2,1,4]  R529      -3.6170445382595062e-02
    z[2,1,4]  R530      6.0345385223627090e-02
    z[2,1,4]  R531      3.2775735855102539e-01
    z[2,1,4]  R532      -1.6123975813388824e-01
    z[2,1,4]  R533      -1.1112906038761139e-02
    z[2,1,4]  R534      -1.7066720128059387e-01
    z[2,1,4]  R535      -2.5070169568061829e-01
    z[2,1,4]  R536      -1.6315679252147675e-01
    z[2,1,4]  R537      -0.0604669563472271
    z[2,1,4]  R538      -3.4378089010715485e-02
    z[2,1,4]  R539      3.7657979875802994e-02
    z[2,1,4]  R540      -1.8559253215789795e-01
    z[2,1,4]  R541      7.3197752237319946e-02
    z[2,1,4]  R542      2.6784452795982361e-01
    z[2,1,4]  R543      -3.4259593486785889e-01
    z[2,1,4]  R544      -7.1928925812244415e-02
    z[2,1,4]  R545      -4.5762622356414795e-01
    z[2,1,4]  R546      -1.5903252363204956e-01
    z[2,1,4]  R547      2.1625605225563049e-01
    z[2,1,4]  R548      1.7825832590460777e-02
    z[2,1,4]  R549      1.1625821888446808e-01
    z[2,1,4]  R550      -3.0601578950881958e-01
    z[2,1,4]  R551      4.7598907351493835e-01
    z[2,1,4]  R552      -3.3756002783775330e-01
    z[2,1,4]  R553      2.4750913679599762e-01
    z[2,1,4]  R554      -8.3448909223079681e-02
    z[2,1,4]  R555      0.265316367149353
    z[2,1,4]  R556      -9.8314777016639709e-02
    z[2,1,4]  R557      -4.5501780509948730e-01
    z[2,1,4]  R558      -3.0927973985671997e-01
    z[2,1,4]  R559      -6.9239658117294312e-01
    z[2,1,4]  R560      1.4795464277267456e-01
    z[2,1,4]  R561      -2.1814560890197754e-01
    z[2,1,4]  R562      -3.9844788610935211e-02
    z[2,1,4]  R563      2.5043150782585144e-01
    z[2,1,4]  R564      5.3612012416124344e-02
    z[2,1,4]  R565      7.2713029384613037e-01
    z[2,1,4]  R566      -0.322696328163147
    z[2,1,4]  R567      -2.0935116708278656e-01
    z[2,1,4]  R568      2.8589293360710144e-01
    z[2,1,4]  R569      2.4938410520553589e-01
    z[2,1,4]  R570      1.0532125830650330e-01
    z[2,1,4]  R571      -1.1799144744873047e-01
    z[2,1,4]  R572      -2.9631054401397705e-01
    z[2,1,4]  R573      -2.1745118498802185e-01
    z[2,1,4]  R574      -1.9360281527042389e-01
    z[2,1,4]  R575      5.6955549865961075e-02
    z[2,1,4]  R576      -2.4683679640293121e-01
    z[2,1,4]  R577      1.5325234830379486e-01
    z[2,1,4]  R578      -1.2517413496971130e-01
    z[2,1,4]  R579      6.5691810846328735e-01
    z[2,1,4]  R580      4.9956849217414856e-01
    z[2,1,4]  R581      1.3732229173183441e-01
    z[2,1,4]  R582      -3.8667482137680054e-01
    z[2,1,4]  R583      -3.3884474635124207e-01
    z[2,1,4]  R584      -1.7403274774551392e-01
    z[2,1,4]  R585      0.289171040058136
    z[2,1,4]  R586      0.0606367364525795
    z[2,1,4]  R587      -4.7994937747716904e-02
    z[2,1,4]  R588      2.9373185709118843e-02
    z[2,1,4]  R589      2.4802295863628387e-01
    z[2,1,4]  R590      -3.9063632488250732e-01
    z[2,1,4]  R591      3.0453100800514221e-01
    z[2,1,4]  R592      -3.2805752754211426e-01
    z[2,1,4]  R593      -2.0189037919044495e-01
    z[2,1,4]  R594      -5.9273969382047653e-03
    z[2,1,4]  R595      3.1691977381706238e-01
    z[2,1,4]  R596      3.9639544486999512e-01
    z[2,1,4]  R597      -9.6043810248374939e-02
    z[2,1,4]  R598      -5.7641044259071350e-02
    z[2,1,4]  R599      4.5994570851325989e-01
    z[2,1,4]  R600      -4.5340526849031448e-02
    z[2,1,4]  R601      4.6919766813516617e-02
    z[2,1,4]  R602      -0.274619460105896
    z[2,1,4]  R603      4.3874431401491165e-02
    z[2,1,4]  R604      -0.214004248380661
    z[2,1,4]  R605      2.3286873102188110e-01
    z[2,1,4]  R606      -1.6028711199760437e-01
    z[2,1,4]  R607      3.3477634191513062e-01
    z[2,1,4]  R608      1.7664463818073273e-01
    z[2,1,4]  R609      -1.3306210935115814e-01
    z[2,1,4]  R610      -1.6326928511261940e-02
    z[2,1,4]  R611      -2.6743057370185852e-01
    z[2,1,4]  R612      -8.3587124943733215e-02
    z[2,1,4]  R613      -2.1492704749107361e-02
    z[2,1,4]  R614      -8.7991170585155487e-02
    z[2,1,4]  R615      2.9614555835723877e-01
    z[2,1,4]  R616      1.3326078653335571e-01
    z[2,1,4]  R617      1.1991009861230850e-01
    z[2,1,4]  R618      -2.1958047151565552e-01
    z[2,1,4]  R619      -1.2943805195391178e-02
    z[2,1,4]  R620      2.4993417784571648e-02
    z[2,1,4]  R621      3.1518232822418213e-01
    z[2,1,4]  R622      2.3044927418231964e-01
    z[2,1,4]  R623      1.8626351654529572e-01
    z[2,1,4]  R624      7.2187192738056183e-02
    z[2,1,4]  R625      6.4057117700576782e-01
    z[2,1,4]  R626      8.0915719270706177e-01
    z[2,1,4]  R627      -5.6615126132965088e-01
    z[2,1,4]  R628      -4.7507378458976746e-01
    z[2,1,4]  R629      -0.077522411942482
    z[2,1,4]  R630      -2.0425860583782196e-01
    z[2,1,4]  R631      -2.8395134210586548e-01
    z[2,1,4]  R632      -2.5203731656074524e-01
    z[2,1,4]  R633      1.7024983465671539e-01
    z[2,1,4]  R634      -2.1192273497581482e-01
    z[2,1,4]  R635      -2.3790630698204041e-01
    z[2,1,4]  R636      -3.1093001365661621e-01
    z[2,1,4]  R637      -4.6103402972221375e-01
    z[2,1,4]  R638      -1.1760532110929489e-01
    z[2,1,4]  R639      -1.2174691259860992e-01
    z[2,1,4]  R640      2.1174573898315430e-01
    z[2,1,4]  R641      3.1613189727067947e-02
    z[2,1,4]  R642      -3.2433861494064331e-01
    z[2,1,4]  R643      -1.9215957820415497e-01
    z[2,1,4]  R644      -4.2228358983993530e-01
    z[2,1,4]  R645      -4.4058007001876831e-01
    z[2,1,4]  R646      -4.0291124582290649e-01
    z[2,1,4]  R647      -5.0877290964126587e-01
    z[2,1,4]  R648      -1.5007355809211731e-01
    z[2,1,4]  R649      -2.6901068165898323e-02
    z[2,1,4]  R650      -1.9950826466083527e-01
    z[2,1,4]  R651      2.1566031500697136e-02
    z[2,1,4]  R652      -1.1014854535460472e-02
    z[2,1,4]  R653      -1.1080067604780197e-01
    z[2,1,4]  R654      -0.186312735080719
    z[2,1,4]  R655      0.0716809555888176
    z[2,1,4]  R656      -1.8982166051864624e-01
    z[2,1,4]  R657      -9.6350491046905518e-02
    z[2,1,4]  R658      -1.2929193675518036e-01
    z[2,1,4]  R659      1.0879338532686234e-01
    z[2,1,4]  R660      1.5406674146652222e-01
    z[2,1,4]  R661      -2.7404522895812988e-01
    z[2,1,4]  R662      -1.9865857902914286e-03
    z[2,1,4]  R663      1.0958957672119141e-01
    z[2,1,4]  R664      -1.0130358487367630e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R511      -1
    z[2,1,5]  R512      1
    z[2,1,5]  R515      -4.0913251042366028e-01
    z[2,1,5]  R516      -1.9938772916793823e-01
    z[2,1,5]  R517      -2.4501414597034454e-01
    z[2,1,5]  R518      -2.0833808183670044e-01
    z[2,1,5]  R519      -1.5545871853828430e-01
    z[2,1,5]  R520      -1.2104744091629982e-02
    z[2,1,5]  R521      -2.4415870010852814e-01
    z[2,1,5]  R522      1.5470339357852936e-01
    z[2,1,5]  R523      -1.3708001375198364e-01
    z[2,1,5]  R524      -4.8285737633705139e-01
    z[2,1,5]  R525      1.7897954583168030e-01
    z[2,1,5]  R526      4.1876620054244995e-01
    z[2,1,5]  R527      6.2775970436632633e-03
    z[2,1,5]  R528      -1.4662048220634460e-01
    z[2,1,5]  R529      1.0123351216316223e-01
    z[2,1,5]  R530      4.1432702541351318e-01
    z[2,1,5]  R531      2.8929945826530457e-01
    z[2,1,5]  R532      -1.0790634900331497e-01
    z[2,1,5]  R533      1.8880537152290344e-01
    z[2,1,5]  R534      4.1776046156883240e-01
    z[2,1,5]  R535      -4.5226030051708221e-02
    z[2,1,5]  R536      -2.3367213085293770e-02
    z[2,1,5]  R537      6.7532330751419067e-02
    z[2,1,5]  R538      -1.6712664067745209e-01
    z[2,1,5]  R539      -9.5498561859130859e-02
    z[2,1,5]  R540      3.7924793362617493e-01
    z[2,1,5]  R541      -5.3726937621831894e-02
    z[2,1,5]  R542      4.1719831526279449e-02
    z[2,1,5]  R543      1.7668071389198303e-01
    z[2,1,5]  R544      -1.0164061188697815e-01
    z[2,1,5]  R545      4.5092034339904785e-01
    z[2,1,5]  R546      -8.1328481435775757e-02
    z[2,1,5]  R547      -5.1702845096588135e-01
    z[2,1,5]  R548      4.0486997365951538e-01
    z[2,1,5]  R549      1.6480258107185364e-01
    z[2,1,5]  R550      0.627466082572937
    z[2,1,5]  R551      0.29982790350914
    z[2,1,5]  R552      -2.3215073347091675e-01
    z[2,1,5]  R553      1.1857450753450394e-01
    z[2,1,5]  R554      -1.3388405740261078e-01
    z[2,1,5]  R555      -7.0382517576217651e-01
    z[2,1,5]  R556      1.1174259334802628e-01
    z[2,1,5]  R557      2.1935574710369110e-01
    z[2,1,5]  R558      -1.0182154178619385e-01
    z[2,1,5]  R559      3.2961988449096680e-01
    z[2,1,5]  R560      -2.5022733211517334e-01
    z[2,1,5]  R561      1.4056839980185032e-02
    z[2,1,5]  R562      -5.8268398046493530e-01
    z[2,1,5]  R563      -2.6642149686813354e-01
    z[2,1,5]  R564      -6.7784243822097778e-01
    z[2,1,5]  R565      7.2239354252815247e-02
    z[2,1,5]  R566      -8.8432334363460541e-02
    z[2,1,5]  R567      5.2897727489471436e-01
    z[2,1,5]  R568      2.8498110175132751e-01
    z[2,1,5]  R569      -2.2599442303180695e-01
    z[2,1,5]  R570      5.6194867938756943e-02
    z[2,1,5]  R571      3.1944376230239868e-01
    z[2,1,5]  R572      -4.6117216348648071e-01
    z[2,1,5]  R573      2.5276523828506470e-01
    z[2,1,5]  R574      -6.7564010620117188e-01
    z[2,1,5]  R575      2.1172720938920975e-02
    z[2,1,5]  R576      -4.0027502179145813e-01
    z[2,1,5]  R577      -1.6390261054039001e-01
    z[2,1,5]  R578      1.1652058362960815e-01
    z[2,1,5]  R579      -1.5202715992927551e-01
    z[2,1,5]  R580      -1.8972858786582947e-01
    z[2,1,5]  R581      -4.7291836142539978e-01
    z[2,1,5]  R582      -2.6897612214088440e-01
    z[2,1,5]  R583      -2.3124687373638153e-01
    z[2,1,5]  R584      -2.3645384609699249e-01
    z[2,1,5]  R585      -3.5391256213188171e-02
    z[2,1,5]  R586      2.5909817218780518e-01
    z[2,1,5]  R587      -0.613033652305603
    z[2,1,5]  R588      -2.3402197659015656e-01
    z[2,1,5]  R589      -0.316095769405365
    z[2,1,5]  R590      3.4054023027420044e-01
    z[2,1,5]  R591      2.4003812670707703e-01
    z[2,1,5]  R592      1.8813515082001686e-02
    z[2,1,5]  R593      -3.4905764460563660e-01
    z[2,1,5]  R594      -4.9916657805442810e-01
    z[2,1,5]  R595      3.1575998663902283e-01
    z[2,1,5]  R596      3.7309196591377258e-01
    z[2,1,5]  R597      7.0639267563819885e-02
    z[2,1,5]  R598      2.4038922786712646e-01
    z[2,1,5]  R599      4.4128566980361938e-02
    z[2,1,5]  R600      -2.6686057448387146e-01
    z[2,1,5]  R601      -5.0679403543472290e-01
    z[2,1,5]  R602      -1.3757790625095367e-01
    z[2,1,5]  R603      -3.3155736327171326e-01
    z[2,1,5]  R604      1.9013158977031708e-01
    z[2,1,5]  R605      2.9067987203598022e-01
    z[2,1,5]  R606      -2.9712867736816406e-01
    z[2,1,5]  R607      -9.7113199532032013e-02
    z[2,1,5]  R608      -4.4012613594532013e-02
    z[2,1,5]  R609      2.5967252254486084e-01
    z[2,1,5]  R610      -2.6901009678840637e-01
    z[2,1,5]  R611      2.6603478193283081e-01
    z[2,1,5]  R612      3.7837705016136169e-01
    z[2,1,5]  R613      4.4696322083473206e-01
    z[2,1,5]  R614      3.3983856439590454e-01
    z[2,1,5]  R615      -1.0552906990051270e-01
    z[2,1,5]  R616      2.3850056529045105e-01
    z[2,1,5]  R617      -0.34966841340065
    z[2,1,5]  R618      3.8474443554878235e-01
    z[2,1,5]  R619      7.0009604096412659e-02
    z[2,1,5]  R620      -1.1616861820220947e-01
    z[2,1,5]  R621      -7.8402034938335419e-02
    z[2,1,5]  R622      -3.5456646233797073e-02
    z[2,1,5]  R623      4.7586232423782349e-01
    z[2,1,5]  R624      0.0745057761669159
    z[2,1,5]  R625      -2.0066772401332855e-01
    z[2,1,5]  R626      -5.9441626071929932e-02
    z[2,1,5]  R627      2.7653029561042786e-01
    z[2,1,5]  R628      5.4726753383874893e-02
    z[2,1,5]  R629      3.3891800791025162e-02
    z[2,1,5]  R630      3.3521682024002075e-01
    z[2,1,5]  R631      -1.5599071979522705e-01
    z[2,1,5]  R632      2.5600078515708447e-03
    z[2,1,5]  R633      3.7962925434112549e-01
    z[2,1,5]  R634      1.4176584780216217e-01
    z[2,1,5]  R635      -5.8701831102371216e-01
    z[2,1,5]  R636      -1.1679384857416153e-01
    z[2,1,5]  R637      -3.2678428292274475e-01
    z[2,1,5]  R638      -5.0479900836944580e-01
    z[2,1,5]  R639      -4.6577075123786926e-01
    z[2,1,5]  R640      -1.2833803892135620e-01
    z[2,1,5]  R641      -1.1914358288049698e-01
    z[2,1,5]  R642      -7.5452238321304321e-02
    z[2,1,5]  R643      1.5624926984310150e-01
    z[2,1,5]  R644      -2.7592654805630445e-03
    z[2,1,5]  R645      3.9353662729263306e-01
    z[2,1,5]  R646      -4.4771060347557068e-01
    z[2,1,5]  R647      -2.4050267040729523e-01
    z[2,1,5]  R648      -5.0918138027191162e-01
    z[2,1,5]  R649      2.8002321720123291e-01
    z[2,1,5]  R650      -0.0396539680659771
    z[2,1,5]  R651      -3.9080310612916946e-02
    z[2,1,5]  R652      -1.9320229068398476e-02
    z[2,1,5]  R653      -1.4455287717282772e-02
    z[2,1,5]  R654      -1.0613378137350082e-01
    z[2,1,5]  R655      -4.5793151855468750e-01
    z[2,1,5]  R656      -1.9242644309997559e-01
    z[2,1,5]  R657      -5.7479149103164673e-01
    z[2,1,5]  R658      -1.8723320960998535e-01
    z[2,1,5]  R659      -2.7032741904258728e-01
    z[2,1,5]  R660      4.8314131796360016e-02
    z[2,1,5]  R661      -2.3204919416457415e-03
    z[2,1,5]  R662      -1.4920058846473694e-01
    z[2,1,5]  R663      -3.3517464995384216e-01
    z[2,1,5]  R664      -3.0391353368759155e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R513      -1
    z[2,1,6]  R514      1
    z[2,1,6]  R515      -1.6492843627929688e-01
    z[2,1,6]  R516      -9.3961074948310852e-02
    z[2,1,6]  R517      -3.5728029906749725e-02
    z[2,1,6]  R518      -3.2833582162857056e-01
    z[2,1,6]  R519      3.2686257362365723e-01
    z[2,1,6]  R520      -1.4039170928299427e-02
    z[2,1,6]  R521      1.2344378232955933e-01
    z[2,1,6]  R522      -2.3563358187675476e-01
    z[2,1,6]  R523      3.1386756896972656e-01
    z[2,1,6]  R524      1.3855537772178650e-01
    z[2,1,6]  R525      1.1553360521793365e-01
    z[2,1,6]  R526      -1.8122033774852753e-01
    z[2,1,6]  R527      -3.7590980529785156e-01
    z[2,1,6]  R528      0.141273632645607
    z[2,1,6]  R529      3.6761730909347534e-01
    z[2,1,6]  R530      2.5172346830368042e-01
    z[2,1,6]  R531      2.3954164981842041e-01
    z[2,1,6]  R532      -3.3420255780220032e-01
    z[2,1,6]  R533      -6.5239536762237549e-01
    z[2,1,6]  R534      -4.3621074408292770e-02
    z[2,1,6]  R535      -0.0518658272922039
    z[2,1,6]  R536      8.8990144431591034e-03
    z[2,1,6]  R537      1.0470316559076309e-01
    z[2,1,6]  R538      1.0767577588558197e-01
    z[2,1,6]  R539      -1.1672386527061462e-01
    z[2,1,6]  R540      -1.2187291681766510e-01
    z[2,1,6]  R541      2.5548562407493591e-02
    z[2,1,6]  R542      0.0900566577911377
    z[2,1,6]  R543      2.5914067402482033e-02
    z[2,1,6]  R544      6.8382412195205688e-02
    z[2,1,6]  R545      -8.4528736770153046e-02
    z[2,1,6]  R546      -7.3306798934936523e-01
    z[2,1,6]  R547      1.1163865774869919e-01
    z[2,1,6]  R548      -1.9604042172431946e-02
    z[2,1,6]  R549      -1.7284965515136719e-01
    z[2,1,6]  R550      3.2818809151649475e-01
    z[2,1,6]  R551      1.7801612615585327e-01
    z[2,1,6]  R552      -1.3617551326751709e-01
    z[2,1,6]  R553      -7.8074358403682709e-02
    z[2,1,6]  R554      1.5174004435539246e-01
    z[2,1,6]  R555      -0.193263441324234
    z[2,1,6]  R556      -4.1548219323158264e-01
    z[2,1,6]  R557      -2.0349536836147308e-01
    z[2,1,6]  R558      4.5186790823936462e-01
    z[2,1,6]  R559      -4.7979336231946945e-02
    z[2,1,6]  R560      -2.2587533295154572e-01
    z[2,1,6]  R561      -1.1849322170019150e-01
    z[2,1,6]  R562      -8.2743220031261444e-02
    z[2,1,6]  R563      -6.2936772592365742e-03
    z[2,1,6]  R564      2.7090808749198914e-01
    z[2,1,6]  R565      3.1304123997688293e-01
    z[2,1,6]  R566      3.9663332700729370e-01
    z[2,1,6]  R567      -1.3253666460514069e-01
    z[2,1,6]  R568      -1.0549268918111920e-03
    z[2,1,6]  R569      1.8261510878801346e-02
    z[2,1,6]  R570      4.6634960174560547e-01
    z[2,1,6]  R571      -2.5481829047203064e-01
    z[2,1,6]  R572      1.9056017696857452e-01
    z[2,1,6]  R573      4.2305365204811096e-01
    z[2,1,6]  R574      -1.1774463579058647e-02
    z[2,1,6]  R575      0.476979523897171
    z[2,1,6]  R576      0.0441533662378788
    z[2,1,6]  R577      4.3637722730636597e-01
    z[2,1,6]  R578      -2.2750008106231689e-01
    z[2,1,6]  R579      -5.1425302028656006e-01
    z[2,1,6]  R580      -6.6892087459564209e-02
    z[2,1,6]  R581      2.8757461905479431e-01
    z[2,1,6]  R582      1.8163864314556122e-01
    z[2,1,6]  R583      4.4809184968471527e-02
    z[2,1,6]  R584      2.0869192481040955e-01
    z[2,1,6]  R585      3.1698805093765259e-01
    z[2,1,6]  R586      -3.1791147589683533e-01
    z[2,1,6]  R587      -0.0218859501183033
    z[2,1,6]  R588      3.3259138464927673e-01
    z[2,1,6]  R589      -4.8471871018409729e-01
    z[2,1,6]  R590      7.3627866804599762e-02
    z[2,1,6]  R591      -0.210836723446846
    z[2,1,6]  R592      -3.1659367680549622e-01
    z[2,1,6]  R593      -1.3049063086509705e-01
    z[2,1,6]  R594      -1.8533644080162048e-01
    z[2,1,6]  R595      3.8289141654968262e-01
    z[2,1,6]  R596      -2.6891345158219337e-02
    z[2,1,6]  R597      1.3080124557018280e-01
    z[2,1,6]  R598      -3.0868074297904968e-01
    z[2,1,6]  R599      -4.4748479127883911e-01
    z[2,1,6]  R600      9.9589407444000244e-02
    z[2,1,6]  R601      -1.4063747227191925e-01
    z[2,1,6]  R602      -0.0908326730132103
    z[2,1,6]  R603      4.3805864453315735e-01
    z[2,1,6]  R604      1.9548374414443970e-01
    z[2,1,6]  R605      -1.3465739786624908e-01
    z[2,1,6]  R606      -4.7352391481399536e-01
    z[2,1,6]  R607      -4.0334376692771912e-01
    z[2,1,6]  R608      -3.4171923995018005e-01
    z[2,1,6]  R609      -0.0457824245095253
    z[2,1,6]  R610      3.7002786993980408e-01
    z[2,1,6]  R611      3.3452188968658447e-01
    z[2,1,6]  R612      3.8959000259637833e-02
    z[2,1,6]  R613      1.4366483688354492e-01
    z[2,1,6]  R614      1.4029106497764587e-01
    z[2,1,6]  R615      -1.8921458721160889e-01
    z[2,1,6]  R616      -2.7679666876792908e-01
    z[2,1,6]  R617      3.0307358503341675e-01
    z[2,1,6]  R618      3.1549820303916931e-01
    z[2,1,6]  R619      1.6601040959358215e-01
    z[2,1,6]  R620      1.3481980189681053e-02
    z[2,1,6]  R621      2.0826151967048645e-01
    z[2,1,6]  R622      3.7093237042427063e-01
    z[2,1,6]  R623      -7.5687073171138763e-02
    z[2,1,6]  R624      -0.344025194644928
    z[2,1,6]  R625      -2.4560314416885376e-01
    z[2,1,6]  R626      -8.6249615997076035e-03
    z[2,1,6]  R627      4.5009684562683105e-01
    z[2,1,6]  R628      8.4467105567455292e-02
    z[2,1,6]  R629      3.5163056850433350e-01
    z[2,1,6]  R630      1.7577911913394928e-01
    z[2,1,6]  R631      1.4857438392937183e-02
    z[2,1,6]  R632      -5.3883910179138184e-01
    z[2,1,6]  R633      -0.0820883959531784
    z[2,1,6]  R634      -2.7637362480163574e-01
    z[2,1,6]  R635      -1.2720239348709583e-02
    z[2,1,6]  R636      -7.6829922199249268e-01
    z[2,1,6]  R637      -5.1832711696624756e-01
    z[2,1,6]  R638      3.2919490337371826e-01
    z[2,1,6]  R639      -7.9426631331443787e-02
    z[2,1,6]  R640      -8.2022309303283691e-02
    z[2,1,6]  R641      1.7222639173269272e-02
    z[2,1,6]  R642      -2.2025832533836365e-01
    z[2,1,6]  R643      -1.8181389570236206e-01
    z[2,1,6]  R644      -0.0487905852496624
    z[2,1,6]  R645      -6.4627546072006226e-01
    z[2,1,6]  R646      -9.0783812105655670e-02
    z[2,1,6]  R647      -2.0084077119827271e-01
    z[2,1,6]  R648      2.7500659227371216e-01
    z[2,1,6]  R649      0.0792355015873909
    z[2,1,6]  R650      2.6192107796669006e-01
    z[2,1,6]  R651      -1.4711722731590271e-01
    z[2,1,6]  R652      0.0408710315823555
    z[2,1,6]  R653      -1.4940334856510162e-01
    z[2,1,6]  R654      7.1755279786884785e-03
    z[2,1,6]  R655      1.7631410062313080e-01
    z[2,1,6]  R656      -3.2058694958686829e-01
    z[2,1,6]  R657      4.4458872079849243e-01
    z[2,1,6]  R658      6.3253903388977051e-01
    z[2,1,6]  R659      -2.7765689417719841e-02
    z[2,1,6]  R660      5.8352392166852951e-02
    z[2,1,6]  R661      1.5340046584606171e-01
    z[2,1,6]  R662      -1.0635794699192047e-01
    z[2,1,6]  R663      2.2697240114212036e-01
    z[2,1,6]  R664      3.6155867576599121e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R665      -1
    z[1,3,0]  R666      1
    z[1,3,0]  R679      1.0895483195781708e-01
    z[1,3,0]  R680      0.0934840589761734
    z[1,3,0]  R681      3.0696392059326172e-01
    z[1,3,0]  R682      -2.8118395805358887e-01
    z[1,3,0]  R683      -2.0352919399738312e-01
    z[1,3,0]  R684      2.3840183019638062e-01
    z[1,3,0]  R685      6.5376496315002441e-01
    z[1,3,0]  R686      7.3611110448837280e-02
    z[1,3,0]  R687      6.6353899240493774e-01
    z[1,3,0]  R688      -2.6388000696897507e-03
    z[1,3,0]  R689      -1.3830715417861938e-01
    z[1,3,0]  R690      1.3887564837932587e-01
    z[1,3,0]  R691      -3.9402008056640625e-02
    z[1,3,0]  R692      -5.8835762739181519e-01
    z[1,3,0]  R693      1.6388840973377228e-02
    z[1,3,0]  R694      -4.1222300380468369e-02
    z[1,3,0]  R695      2.8189649805426598e-02
    z[1,3,0]  R696      -1.3297820091247559e-01
    z[1,3,0]  R697      -0.200653538107872
    z[1,3,0]  R698      -1.1196637898683548e-01
    z[1,3,0]  R699      7.7385380864143372e-02
    z[1,3,0]  R700      -9.9324166774749756e-02
    z[1,3,0]  R701      -3.5108867287635803e-01
    z[1,3,0]  R702      -6.3792335987091064e-01
    z[1,3,0]  R703      7.3212879896163940e-01
    z[1,3,0]  R704      4.4521890580654144e-02
    z[1,3,0]  R705      1.0701041668653488e-01
    z[1,3,0]  R706      8.5760957002639771e-01
    z[1,3,0]  R707      6.5180635452270508e-01
    z[1,3,0]  R708      7.6279711723327637e-01
    z[1,3,0]  R709      2.7415168285369873e-01
    z[1,3,0]  R710      -0.303154855966568
    z[1,3,0]  R711      -0.588360071182251
    z[1,3,0]  R712      -3.6815574765205383e-01
    z[1,3,0]  R713      1.2681372463703156e-01
    z[1,3,0]  R714      -9.6772246062755585e-02
    z[1,3,0]  R715      -1.7005759477615356e-01
    z[1,3,0]  R716      -1.2802829733118415e-03
    z[1,3,0]  R717      -5.3634065389633179e-01
    z[1,3,0]  R718      -5.5998134613037109e-01
    z[1,3,0]  R719      2.7983114123344421e-01
    z[1,3,0]  R720      4.5460104942321777e-01
    z[1,3,0]  R721      5.2850371599197388e-01
    z[1,3,0]  R722      7.4628823995590210e-01
    z[1,3,0]  R723      6.7978280782699585e-01
    z[1,3,0]  R724      5.0720679759979248e-01
    z[1,3,0]  R725      -1.7386375367641449e-01
    z[1,3,0]  R726      6.3635128736495972e-01
    z[1,3,0]  R727      1.9838495645672083e-03
    z[1,3,0]  R728      4.3724125623703003e-01
    z[1,3,0]  R729      1.0943809896707535e-01
    z[1,3,0]  R730      7.2360396385192871e-01
    z[1,3,0]  R731      -0.41497603058815
    z[1,3,0]  R732      -0.360065221786499
    z[1,3,0]  R733      -4.2180991172790527e-01
    z[1,3,0]  R734      -4.8004138469696045e-01
    z[1,3,0]  R735      -4.3477049469947815e-01
    z[1,3,0]  R736      -0.6156005859375
    z[1,3,0]  R737      -3.2301768660545349e-01
    z[1,3,0]  R738      -3.7379533052444458e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R667      -1
    z[1,3,1]  R668      1
    z[1,3,1]  R679      -4.6671545505523682e-01
    z[1,3,1]  R680      -1.3359937071800232e-01
    z[1,3,1]  R681      -5.4755187034606934e-01
    z[1,3,1]  R682      -4.5454701781272888e-01
    z[1,3,1]  R683      8.2258599996566772e-01
    z[1,3,1]  R684      8.3536797761917114e-01
    z[1,3,1]  R685      6.0298210382461548e-01
    z[1,3,1]  R686      6.8687140941619873e-01
    z[1,3,1]  R687      2.5713574886322021e-01
    z[1,3,1]  R688      8.2437044382095337e-01
    z[1,3,1]  R689      -6.3565254211425781e-01
    z[1,3,1]  R690      -2.6428091526031494e-01
    z[1,3,1]  R691      -3.4266650676727295e-01
    z[1,3,1]  R692      1.7891493439674377e-01
    z[1,3,1]  R693      -8.8861101539805532e-04
    z[1,3,1]  R694      7.3406648635864258e-01
    z[1,3,1]  R695      7.5357919931411743e-01
    z[1,3,1]  R696      0.777441143989563
    z[1,3,1]  R697      8.4087914228439331e-01
    z[1,3,1]  R698      6.7594271898269653e-01
    z[1,3,1]  R699      -3.0124077200889587e-01
    z[1,3,1]  R700      -3.4512379765510559e-01
    z[1,3,1]  R701      -7.5806662440299988e-02
    z[1,3,1]  R702      1.4388592541217804e-01
    z[1,3,1]  R703      5.3881222009658813e-01
    z[1,3,1]  R704      8.3683592081069946e-01
    z[1,3,1]  R705      8.5966998338699341e-01
    z[1,3,1]  R706      3.2006371021270752e-01
    z[1,3,1]  R707      5.7017904520034790e-01
    z[1,3,1]  R708      5.0148993730545044e-01
    z[1,3,1]  R709      -3.6733394861221313e-01
    z[1,3,1]  R710      3.8637730479240417e-01
    z[1,3,1]  R711      5.2368111908435822e-02
    z[1,3,1]  R712      1.3667643070220947e-01
    z[1,3,1]  R713      7.8310316801071167e-01
    z[1,3,1]  R714      9.3387198448181152e-01
    z[1,3,1]  R715      7.3081928491592407e-01
    z[1,3,1]  R716      6.8152934312820435e-01
    z[1,3,1]  R717      7.1633970737457275e-01
    z[1,3,1]  R718      6.6614228487014771e-01
    z[1,3,1]  R719      0.505213737487793
    z[1,3,1]  R720      -2.9188922047615051e-01
    z[1,3,1]  R721      -2.7200677990913391e-01
    z[1,3,1]  R722      -3.0819791555404663e-01
    z[1,3,1]  R723      -4.9865084886550903e-01
    z[1,3,1]  R724      -2.9265290498733521e-01
    z[1,3,1]  R725      0.80692058801651
    z[1,3,1]  R726      -5.2047246694564819e-01
    z[1,3,1]  R727      1.3496515154838562e-01
    z[1,3,1]  R728      -6.9121068716049194e-01
    z[1,3,1]  R729      0.0921378806233406
    z[1,3,1]  R730      2.1200199425220490e-01
    z[1,3,1]  R731      -5.6763851642608643e-01
    z[1,3,1]  R732      -8.2999789714813232e-01
    z[1,3,1]  R733      -7.0515358448028564e-01
    z[1,3,1]  R734      -4.0988948941230774e-01
    z[1,3,1]  R735      -4.6646991372108459e-01
    z[1,3,1]  R736      1.9349502027034760e-01
    z[1,3,1]  R737      4.7425529360771179e-01
    z[1,3,1]  R738      2.0977059006690979e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R669      -1
    z[1,3,2]  R670      1
    z[1,3,2]  R679      -4.8679551482200623e-01
    z[1,3,2]  R680      3.6904752254486084e-02
    z[1,3,2]  R681      7.8874669969081879e-02
    z[1,3,2]  R682      -2.1364346146583557e-01
    z[1,3,2]  R683      1.3000316917896271e-01
    z[1,3,2]  R684      -1.4253102242946625e-01
    z[1,3,2]  R685      -8.2498893141746521e-02
    z[1,3,2]  R686      3.2142437994480133e-02
    z[1,3,2]  R687      2.2951868176460266e-01
    z[1,3,2]  R688      -1.9364626705646515e-01
    z[1,3,2]  R689      4.1217097640037537e-01
    z[1,3,2]  R690      1.3405339419841766e-01
    z[1,3,2]  R691      -2.9808761551976204e-02
    z[1,3,2]  R692      -4.6589165925979614e-01
    z[1,3,2]  R693      9.4442255795001984e-02
    z[1,3,2]  R694      1.6268730163574219e-01
    z[1,3,2]  R695      4.9862369894981384e-02
    z[1,3,2]  R696      2.4379999935626984e-01
    z[1,3,2]  R697      1.8106689676642418e-02
    z[1,3,2]  R698      2.1392691135406494e-01
    z[1,3,2]  R699      -6.2701150774955750e-02
    z[1,3,2]  R700      -2.3533287644386292e-01
    z[1,3,2]  R701      -2.0075348019599915e-01
    z[1,3,2]  R702      -4.6012011170387268e-01
    z[1,3,2]  R703      2.8811085224151611e-01
    z[1,3,2]  R704      2.3537848889827728e-01
    z[1,3,2]  R705      3.6041319370269775e-01
    z[1,3,2]  R706      3.1767565011978149e-01
    z[1,3,2]  R707      4.6150788664817810e-01
    z[1,3,2]  R708      3.1205204129219055e-01
    z[1,3,2]  R709      3.9079514145851135e-01
    z[1,3,2]  R710      -4.7543495893478394e-01
    z[1,3,2]  R711      -3.3568689227104187e-01
    z[1,3,2]  R712      -0.611609697341919
    z[1,3,2]  R713      3.3169406652450562e-01
    z[1,3,2]  R714      1.8586735427379608e-01
    z[1,3,2]  R715      1.6468927264213562e-01
    z[1,3,2]  R716      4.8190999031066895e-01
    z[1,3,2]  R717      1.5249325335025787e-01
    z[1,3,2]  R718      1.0341267101466656e-02
    z[1,3,2]  R719      9.6491836011409760e-02
    z[1,3,2]  R720      1.0408055037260056e-01
    z[1,3,2]  R721      -2.7911257743835449e-01
    z[1,3,2]  R722      -1.6206982731819153e-01
    z[1,3,2]  R723      2.9160779714584351e-01
    z[1,3,2]  R724      1.2674829363822937e-01
    z[1,3,2]  R725      9.7393020987510681e-02
    z[1,3,2]  R726      -9.0242482721805573e-02
    z[1,3,2]  R727      2.9007151722908020e-01
    z[1,3,2]  R728      -1.8557514250278473e-01
    z[1,3,2]  R729      -2.3937630653381348e-01
    z[1,3,2]  R730      4.1321533918380737e-01
    z[1,3,2]  R731      -4.4200602173805237e-01
    z[1,3,2]  R732      5.5509600788354874e-02
    z[1,3,2]  R733      1.0695017874240875e-01
    z[1,3,2]  R734      -3.8250240683555603e-01
    z[1,3,2]  R735      -4.8148775100708008e-01
    z[1,3,2]  R736      -5.3229510784149170e-01
    z[1,3,2]  R737      1.8213652074337006e-01
    z[1,3,2]  R738      -0.0711749866604805
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R671      -1
    z[1,3,3]  R672      1
    z[1,3,3]  R679      1.4971904456615448e-01
    z[1,3,3]  R680      5.6009536981582642e-01
    z[1,3,3]  R681      1.2469938024878502e-02
    z[1,3,3]  R682      6.5791660547256470e-01
    z[1,3,3]  R683      -3.6636710166931152e-01
    z[1,3,3]  R684      -2.0004889369010925e-01
    z[1,3,3]  R685      3.1147342920303345e-01
    z[1,3,3]  R686      -4.0973043441772461e-01
    z[1,3,3]  R687      -5.1095658540725708e-01
    z[1,3,3]  R688      -3.7618669867515564e-01
    z[1,3,3]  R689      0.0747021734714508
    z[1,3,3]  R690      -4.3851667642593384e-01
    z[1,3,3]  R691      -5.4049533605575562e-01
    z[1,3,3]  R692      -1.6657525300979614e-01
    z[1,3,3]  R693      -8.6760473251342773e-01
    z[1,3,3]  R694      -0.604107141494751
    z[1,3,3]  R695      -6.4292007684707642e-01
    z[1,3,3]  R696      -3.9882490038871765e-01
    z[1,3,3]  R697      -3.9741331338882446e-01
    z[1,3,3]  R698      -5.5144232511520386e-01
    z[1,3,3]  R699      3.6425283551216125e-01
    z[1,3,3]  R700      -6.6679733991622925e-01
    z[1,3,3]  R701      -6.8822938203811646e-01
    z[1,3,3]  R702      -5.6779447942972183e-02
    z[1,3,3]  R703      7.2429150342941284e-02
    z[1,3,3]  R704      -3.6378815770149231e-01
    z[1,3,3]  R705      -3.0981072783470154e-01
    z[1,3,3]  R706      -2.4286228418350220e-01
    z[1,3,3]  R707      -4.7408733516931534e-02
    z[1,3,3]  R708      1.5245880186557770e-01
    z[1,3,3]  R709      -6.2550747394561768e-01
    z[1,3,3]  R710      -5.9744048118591309e-01
    z[1,3,3]  R711      -3.2809905707836151e-02
    z[1,3,3]  R712      -1.4084091782569885e-01
    z[1,3,3]  R713      -4.1828554868698120e-01
    z[1,3,3]  R714      -2.3344330489635468e-01
    z[1,3,3]  R715      -5.5787372589111328e-01
    z[1,3,3]  R716      -5.1932847499847412e-01
    z[1,3,3]  R717      8.5775060579180717e-03
    z[1,3,3]  R718      -9.6009470522403717e-02
    z[1,3,3]  R719      3.8233183324337006e-02
    z[1,3,3]  R720      -5.6281287223100662e-02
    z[1,3,3]  R721      -1.6667445003986359e-01
    z[1,3,3]  R722      -1.1466748267412186e-01
    z[1,3,3]  R723      2.0051820203661919e-02
    z[1,3,3]  R724      1.4815273880958557e-01
    z[1,3,3]  R725      -1.3428920507431030e-01
    z[1,3,3]  R726      -4.4378823041915894e-01
    z[1,3,3]  R727      -2.1803137660026550e-01
    z[1,3,3]  R728      -3.4357210993766785e-01
    z[1,3,3]  R729      -7.1974718570709229e-01
    z[1,3,3]  R730      -3.4759324789047241e-01
    z[1,3,3]  R731      -1.9642159342765808e-01
    z[1,3,3]  R732      1.9086253643035889e-01
    z[1,3,3]  R733      2.0496025681495667e-01
    z[1,3,3]  R734      -7.6402656733989716e-02
    z[1,3,3]  R735      1.2922681868076324e-01
    z[1,3,3]  R736      3.9129105210304260e-01
    z[1,3,3]  R737      5.7691287994384766e-01
    z[1,3,3]  R738      -1.4007851481437683e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R673      -1
    z[1,3,4]  R674      1
    z[1,3,4]  R679      6.4057117700576782e-01
    z[1,3,4]  R680      8.0915719270706177e-01
    z[1,3,4]  R681      -5.6615126132965088e-01
    z[1,3,4]  R682      -4.7507378458976746e-01
    z[1,3,4]  R683      -0.077522411942482
    z[1,3,4]  R684      -2.0425860583782196e-01
    z[1,3,4]  R685      -2.8395134210586548e-01
    z[1,3,4]  R686      -2.5203731656074524e-01
    z[1,3,4]  R687      1.7024983465671539e-01
    z[1,3,4]  R688      -2.1192273497581482e-01
    z[1,3,4]  R689      -2.3790630698204041e-01
    z[1,3,4]  R690      -3.1093001365661621e-01
    z[1,3,4]  R691      -4.6103402972221375e-01
    z[1,3,4]  R692      -1.1760532110929489e-01
    z[1,3,4]  R693      -1.2174691259860992e-01
    z[1,3,4]  R694      2.1174573898315430e-01
    z[1,3,4]  R695      3.1613189727067947e-02
    z[1,3,4]  R696      -3.2433861494064331e-01
    z[1,3,4]  R697      -1.9215957820415497e-01
    z[1,3,4]  R698      -4.2228358983993530e-01
    z[1,3,4]  R699      -4.4058007001876831e-01
    z[1,3,4]  R700      -4.0291124582290649e-01
    z[1,3,4]  R701      -5.0877290964126587e-01
    z[1,3,4]  R702      -1.5007355809211731e-01
    z[1,3,4]  R703      -2.6901068165898323e-02
    z[1,3,4]  R704      -1.9950826466083527e-01
    z[1,3,4]  R705      2.1566031500697136e-02
    z[1,3,4]  R706      -1.1014854535460472e-02
    z[1,3,4]  R707      -1.1080067604780197e-01
    z[1,3,4]  R708      -0.186312735080719
    z[1,3,4]  R709      0.0716809555888176
    z[1,3,4]  R710      -1.8982166051864624e-01
    z[1,3,4]  R711      -9.6350491046905518e-02
    z[1,3,4]  R712      -1.2929193675518036e-01
    z[1,3,4]  R713      1.0879338532686234e-01
    z[1,3,4]  R714      1.5406674146652222e-01
    z[1,3,4]  R715      -2.7404522895812988e-01
    z[1,3,4]  R716      -1.9865857902914286e-03
    z[1,3,4]  R717      1.0958957672119141e-01
    z[1,3,4]  R718      -1.0130358487367630e-01
    z[1,3,4]  R719      2.6292881369590759e-01
    z[1,3,4]  R720      1.1427477002143860e-03
    z[1,3,4]  R721      2.9889410734176636e-01
    z[1,3,4]  R722      5.2212929725646973e-01
    z[1,3,4]  R723      2.8739643096923828e-01
    z[1,3,4]  R724      4.6194615960121155e-01
    z[1,3,4]  R725      -2.1076743304729462e-01
    z[1,3,4]  R726      8.2869090139865875e-02
    z[1,3,4]  R727      -5.6725829839706421e-01
    z[1,3,4]  R728      -2.1376505494117737e-01
    z[1,3,4]  R729      -5.7799136638641357e-01
    z[1,3,4]  R730      -1.2210885435342789e-01
    z[1,3,4]  R731      -3.7678331136703491e-01
    z[1,3,4]  R732      -1.7832627892494202e-01
    z[1,3,4]  R733      -4.3485438823699951e-01
    z[1,3,4]  R734      0.597722053527832
    z[1,3,4]  R735      4.6631014347076416e-01
    z[1,3,4]  R736      2.9649755358695984e-01
    z[1,3,4]  R737      4.4300094246864319e-01
    z[1,3,4]  R738      7.8966683149337769e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R675      -1
    z[1,3,5]  R676      1
    z[1,3,5]  R679      -2.0066772401332855e-01
    z[1,3,5]  R680      -5.9441626071929932e-02
    z[1,3,5]  R681      2.7653029561042786e-01
    z[1,3,5]  R682      5.4726753383874893e-02
    z[1,3,5]  R683      3.3891800791025162e-02
    z[1,3,5]  R684      3.3521682024002075e-01
    z[1,3,5]  R685      -1.5599071979522705e-01
    z[1,3,5]  R686      2.5600078515708447e-03
    z[1,3,5]  R687      3.7962925434112549e-01
    z[1,3,5]  R688      1.4176584780216217e-01
    z[1,3,5]  R689      -5.8701831102371216e-01
    z[1,3,5]  R690      -1.1679384857416153e-01
    z[1,3,5]  R691      -3.2678428292274475e-01
    z[1,3,5]  R692      -5.0479900836944580e-01
    z[1,3,5]  R693      -4.6577075123786926e-01
    z[1,3,5]  R694      -1.2833803892135620e-01
    z[1,3,5]  R695      -1.1914358288049698e-01
    z[1,3,5]  R696      -7.5452238321304321e-02
    z[1,3,5]  R697      1.5624926984310150e-01
    z[1,3,5]  R698      -2.7592654805630445e-03
    z[1,3,5]  R699      3.9353662729263306e-01
    z[1,3,5]  R700      -4.4771060347557068e-01
    z[1,3,5]  R701      -2.4050267040729523e-01
    z[1,3,5]  R702      -5.0918138027191162e-01
    z[1,3,5]  R703      2.8002321720123291e-01
    z[1,3,5]  R704      -0.0396539680659771
    z[1,3,5]  R705      -3.9080310612916946e-02
    z[1,3,5]  R706      -1.9320229068398476e-02
    z[1,3,5]  R707      -1.4455287717282772e-02
    z[1,3,5]  R708      -1.0613378137350082e-01
    z[1,3,5]  R709      -4.5793151855468750e-01
    z[1,3,5]  R710      -1.9242644309997559e-01
    z[1,3,5]  R711      -5.7479149103164673e-01
    z[1,3,5]  R712      -1.8723320960998535e-01
    z[1,3,5]  R713      -2.7032741904258728e-01
    z[1,3,5]  R714      4.8314131796360016e-02
    z[1,3,5]  R715      -2.3204919416457415e-03
    z[1,3,5]  R716      -1.4920058846473694e-01
    z[1,3,5]  R717      -3.3517464995384216e-01
    z[1,3,5]  R718      -3.0391353368759155e-01
    z[1,3,5]  R719      -7.6487839221954346e-01
    z[1,3,5]  R720      -8.1545692682266235e-01
    z[1,3,5]  R721      -6.6843688488006592e-01
    z[1,3,5]  R722      -1.8858213722705841e-01
    z[1,3,5]  R723      -2.8500708937644958e-01
    z[1,3,5]  R724      -5.8723074197769165e-01
    z[1,3,5]  R725      -4.9610987305641174e-01
    z[1,3,5]  R726      -1.2263411283493042e-01
    z[1,3,5]  R727      -7.1447348594665527e-01
    z[1,3,5]  R728      1.4723853208124638e-02
    z[1,3,5]  R729      -2.5184974074363708e-01
    z[1,3,5]  R730      3.0484935641288757e-01
    z[1,3,5]  R731      -3.5863202810287476e-01
    z[1,3,5]  R732      1.1830098181962967e-01
    z[1,3,5]  R733      2.0683903992176056e-01
    z[1,3,5]  R734      2.4618925154209137e-01
    z[1,3,5]  R735      3.5562586784362793e-01
    z[1,3,5]  R736      -3.2573845237493515e-02
    z[1,3,5]  R737      3.1028228998184204e-01
    z[1,3,5]  R738      3.1595242023468018e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R677      -1
    z[1,3,6]  R678      1
    z[1,3,6]  R679      -2.4560314416885376e-01
    z[1,3,6]  R680      -8.6249615997076035e-03
    z[1,3,6]  R681      4.5009684562683105e-01
    z[1,3,6]  R682      8.4467105567455292e-02
    z[1,3,6]  R683      3.5163056850433350e-01
    z[1,3,6]  R684      1.7577911913394928e-01
    z[1,3,6]  R685      1.4857438392937183e-02
    z[1,3,6]  R686      -5.3883910179138184e-01
    z[1,3,6]  R687      -0.0820883959531784
    z[1,3,6]  R688      -2.7637362480163574e-01
    z[1,3,6]  R689      -1.2720239348709583e-02
    z[1,3,6]  R690      -7.6829922199249268e-01
    z[1,3,6]  R691      -5.1832711696624756e-01
    z[1,3,6]  R692      3.2919490337371826e-01
    z[1,3,6]  R693      -7.9426631331443787e-02
    z[1,3,6]  R694      -8.2022309303283691e-02
    z[1,3,6]  R695      1.7222639173269272e-02
    z[1,3,6]  R696      -2.2025832533836365e-01
    z[1,3,6]  R697      -1.8181389570236206e-01
    z[1,3,6]  R698      -0.0487905852496624
    z[1,3,6]  R699      -6.4627546072006226e-01
    z[1,3,6]  R700      -9.0783812105655670e-02
    z[1,3,6]  R701      -2.0084077119827271e-01
    z[1,3,6]  R702      2.7500659227371216e-01
    z[1,3,6]  R703      0.0792355015873909
    z[1,3,6]  R704      2.6192107796669006e-01
    z[1,3,6]  R705      -1.4711722731590271e-01
    z[1,3,6]  R706      0.0408710315823555
    z[1,3,6]  R707      -1.4940334856510162e-01
    z[1,3,6]  R708      7.1755279786884785e-03
    z[1,3,6]  R709      1.7631410062313080e-01
    z[1,3,6]  R710      -3.2058694958686829e-01
    z[1,3,6]  R711      4.4458872079849243e-01
    z[1,3,6]  R712      6.3253903388977051e-01
    z[1,3,6]  R713      -2.7765689417719841e-02
    z[1,3,6]  R714      5.8352392166852951e-02
    z[1,3,6]  R715      1.5340046584606171e-01
    z[1,3,6]  R716      -1.0635794699192047e-01
    z[1,3,6]  R717      2.2697240114212036e-01
    z[1,3,6]  R718      3.6155867576599121e-01
    z[1,3,6]  R719      -3.8868039846420288e-02
    z[1,3,6]  R720      1.7078292369842529e-01
    z[1,3,6]  R721      6.9759249687194824e-02
    z[1,3,6]  R722      -2.1688843145966530e-02
    z[1,3,6]  R723      -1.9994966685771942e-01
    z[1,3,6]  R724      -2.4667167663574219e-01
    z[1,3,6]  R725      -2.4155495688319206e-02
    z[1,3,6]  R726      -3.1171691417694092e-01
    z[1,3,6]  R727      1.3359299302101135e-01
    z[1,3,6]  R728      3.6421930789947510e-01
    z[1,3,6]  R729      8.1820584833621979e-02
    z[1,3,6]  R730      0.178999662399292
    z[1,3,6]  R731      -3.2374124974012375e-02
    z[1,3,6]  R732      -3.1008267402648926e-01
    z[1,3,6]  R733      1.9876374304294586e-01
    z[1,3,6]  R734      1.7755150794982910e-01
    z[1,3,6]  R735      -3.0585335567593575e-02
    z[1,3,6]  R736      2.4119900166988373e-01
    z[1,3,6]  R737      -1.1051856726408005e-01
    z[1,3,6]  R738      -2.6112416386604309e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R739      -1
    z[3,1,0]  R740      1
    z[3,1,0]  R753      2.7983114123344421e-01
    z[3,1,0]  R754      4.5460104942321777e-01
    z[3,1,0]  R755      5.2850371599197388e-01
    z[3,1,0]  R756      7.4628823995590210e-01
    z[3,1,0]  R757      6.7978280782699585e-01
    z[3,1,0]  R758      5.0720679759979248e-01
    z[3,1,0]  R759      -1.7386375367641449e-01
    z[3,1,0]  R760      6.3635128736495972e-01
    z[3,1,0]  R761      1.9838495645672083e-03
    z[3,1,0]  R762      4.3724125623703003e-01
    z[3,1,0]  R763      1.0943809896707535e-01
    z[3,1,0]  R764      7.2360396385192871e-01
    z[3,1,0]  R765      -0.41497603058815
    z[3,1,0]  R766      -0.360065221786499
    z[3,1,0]  R767      -4.2180991172790527e-01
    z[3,1,0]  R768      -4.8004138469696045e-01
    z[3,1,0]  R769      -4.3477049469947815e-01
    z[3,1,0]  R770      -0.6156005859375
    z[3,1,0]  R771      -3.2301768660545349e-01
    z[3,1,0]  R772      -3.7379533052444458e-01
    z[3,1,0]  R773      1.0895483195781708e-01
    z[3,1,0]  R774      0.0934840589761734
    z[3,1,0]  R775      3.0696392059326172e-01
    z[3,1,0]  R776      -2.8118395805358887e-01
    z[3,1,0]  R777      -2.0352919399738312e-01
    z[3,1,0]  R778      2.3840183019638062e-01
    z[3,1,0]  R779      6.5376496315002441e-01
    z[3,1,0]  R780      7.3611110448837280e-02
    z[3,1,0]  R781      6.6353899240493774e-01
    z[3,1,0]  R782      -2.6388000696897507e-03
    z[3,1,0]  R783      -1.3830715417861938e-01
    z[3,1,0]  R784      1.3887564837932587e-01
    z[3,1,0]  R785      -3.9402008056640625e-02
    z[3,1,0]  R786      -5.8835762739181519e-01
    z[3,1,0]  R787      1.6388840973377228e-02
    z[3,1,0]  R788      -4.1222300380468369e-02
    z[3,1,0]  R789      2.8189649805426598e-02
    z[3,1,0]  R790      -1.3297820091247559e-01
    z[3,1,0]  R791      -0.200653538107872
    z[3,1,0]  R792      -1.1196637898683548e-01
    z[3,1,0]  R793      7.7385380864143372e-02
    z[3,1,0]  R794      -9.9324166774749756e-02
    z[3,1,0]  R795      -3.5108867287635803e-01
    z[3,1,0]  R796      -6.3792335987091064e-01
    z[3,1,0]  R797      7.3212879896163940e-01
    z[3,1,0]  R798      4.4521890580654144e-02
    z[3,1,0]  R799      1.0701041668653488e-01
    z[3,1,0]  R800      8.5760957002639771e-01
    z[3,1,0]  R801      6.5180635452270508e-01
    z[3,1,0]  R802      7.6279711723327637e-01
    z[3,1,0]  R803      2.7415168285369873e-01
    z[3,1,0]  R804      -0.303154855966568
    z[3,1,0]  R805      -0.588360071182251
    z[3,1,0]  R806      -3.6815574765205383e-01
    z[3,1,0]  R807      1.2681372463703156e-01
    z[3,1,0]  R808      -9.6772246062755585e-02
    z[3,1,0]  R809      -1.7005759477615356e-01
    z[3,1,0]  R810      -1.2802829733118415e-03
    z[3,1,0]  R811      -5.3634065389633179e-01
    z[3,1,0]  R812      -5.5998134613037109e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R741      -1
    z[3,1,1]  R742      1
    z[3,1,1]  R753      0.505213737487793
    z[3,1,1]  R754      -2.9188922047615051e-01
    z[3,1,1]  R755      -2.7200677990913391e-01
    z[3,1,1]  R756      -3.0819791555404663e-01
    z[3,1,1]  R757      -4.9865084886550903e-01
    z[3,1,1]  R758      -2.9265290498733521e-01
    z[3,1,1]  R759      0.80692058801651
    z[3,1,1]  R760      -5.2047246694564819e-01
    z[3,1,1]  R761      1.3496515154838562e-01
    z[3,1,1]  R762      -6.9121068716049194e-01
    z[3,1,1]  R763      0.0921378806233406
    z[3,1,1]  R764      2.1200199425220490e-01
    z[3,1,1]  R765      -5.6763851642608643e-01
    z[3,1,1]  R766      -8.2999789714813232e-01
    z[3,1,1]  R767      -7.0515358448028564e-01
    z[3,1,1]  R768      -4.0988948941230774e-01
    z[3,1,1]  R769      -4.6646991372108459e-01
    z[3,1,1]  R770      1.9349502027034760e-01
    z[3,1,1]  R771      4.7425529360771179e-01
    z[3,1,1]  R772      2.0977059006690979e-01
    z[3,1,1]  R773      -4.6671545505523682e-01
    z[3,1,1]  R774      -1.3359937071800232e-01
    z[3,1,1]  R775      -5.4755187034606934e-01
    z[3,1,1]  R776      -4.5454701781272888e-01
    z[3,1,1]  R777      8.2258599996566772e-01
    z[3,1,1]  R778      8.3536797761917114e-01
    z[3,1,1]  R779      6.0298210382461548e-01
    z[3,1,1]  R780      6.8687140941619873e-01
    z[3,1,1]  R781      2.5713574886322021e-01
    z[3,1,1]  R782      8.2437044382095337e-01
    z[3,1,1]  R783      -6.3565254211425781e-01
    z[3,1,1]  R784      -2.6428091526031494e-01
    z[3,1,1]  R785      -3.4266650676727295e-01
    z[3,1,1]  R786      1.7891493439674377e-01
    z[3,1,1]  R787      -8.8861101539805532e-04
    z[3,1,1]  R788      7.3406648635864258e-01
    z[3,1,1]  R789      7.5357919931411743e-01
    z[3,1,1]  R790      0.777441143989563
    z[3,1,1]  R791      8.4087914228439331e-01
    z[3,1,1]  R792      6.7594271898269653e-01
    z[3,1,1]  R793      -3.0124077200889587e-01
    z[3,1,1]  R794      -3.4512379765510559e-01
    z[3,1,1]  R795      -7.5806662440299988e-02
    z[3,1,1]  R796      1.4388592541217804e-01
    z[3,1,1]  R797      5.3881222009658813e-01
    z[3,1,1]  R798      8.3683592081069946e-01
    z[3,1,1]  R799      8.5966998338699341e-01
    z[3,1,1]  R800      3.2006371021270752e-01
    z[3,1,1]  R801      5.7017904520034790e-01
    z[3,1,1]  R802      5.0148993730545044e-01
    z[3,1,1]  R803      -3.6733394861221313e-01
    z[3,1,1]  R804      3.8637730479240417e-01
    z[3,1,1]  R805      5.2368111908435822e-02
    z[3,1,1]  R806      1.3667643070220947e-01
    z[3,1,1]  R807      7.8310316801071167e-01
    z[3,1,1]  R808      9.3387198448181152e-01
    z[3,1,1]  R809      7.3081928491592407e-01
    z[3,1,1]  R810      6.8152934312820435e-01
    z[3,1,1]  R811      7.1633970737457275e-01
    z[3,1,1]  R812      6.6614228487014771e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R743      -1
    z[3,1,2]  R744      1
    z[3,1,2]  R753      9.6491836011409760e-02
    z[3,1,2]  R754      1.0408055037260056e-01
    z[3,1,2]  R755      -2.7911257743835449e-01
    z[3,1,2]  R756      -1.6206982731819153e-01
    z[3,1,2]  R757      2.9160779714584351e-01
    z[3,1,2]  R758      1.2674829363822937e-01
    z[3,1,2]  R759      9.7393020987510681e-02
    z[3,1,2]  R760      -9.0242482721805573e-02
    z[3,1,2]  R761      2.9007151722908020e-01
    z[3,1,2]  R762      -1.8557514250278473e-01
    z[3,1,2]  R763      -2.3937630653381348e-01
    z[3,1,2]  R764      4.1321533918380737e-01
    z[3,1,2]  R765      -4.4200602173805237e-01
    z[3,1,2]  R766      5.5509600788354874e-02
    z[3,1,2]  R767      1.0695017874240875e-01
    z[3,1,2]  R768      -3.8250240683555603e-01
    z[3,1,2]  R769      -4.8148775100708008e-01
    z[3,1,2]  R770      -5.3229510784149170e-01
    z[3,1,2]  R771      1.8213652074337006e-01
    z[3,1,2]  R772      -0.0711749866604805
    z[3,1,2]  R773      -4.8679551482200623e-01
    z[3,1,2]  R774      3.6904752254486084e-02
    z[3,1,2]  R775      7.8874669969081879e-02
    z[3,1,2]  R776      -2.1364346146583557e-01
    z[3,1,2]  R777      1.3000316917896271e-01
    z[3,1,2]  R778      -1.4253102242946625e-01
    z[3,1,2]  R779      -8.2498893141746521e-02
    z[3,1,2]  R780      3.2142437994480133e-02
    z[3,1,2]  R781      2.2951868176460266e-01
    z[3,1,2]  R782      -1.9364626705646515e-01
    z[3,1,2]  R783      4.1217097640037537e-01
    z[3,1,2]  R784      1.3405339419841766e-01
    z[3,1,2]  R785      -2.9808761551976204e-02
    z[3,1,2]  R786      -4.6589165925979614e-01
    z[3,1,2]  R787      9.4442255795001984e-02
    z[3,1,2]  R788      1.6268730163574219e-01
    z[3,1,2]  R789      4.9862369894981384e-02
    z[3,1,2]  R790      2.4379999935626984e-01
    z[3,1,2]  R791      1.8106689676642418e-02
    z[3,1,2]  R792      2.1392691135406494e-01
    z[3,1,2]  R793      -6.2701150774955750e-02
    z[3,1,2]  R794      -2.3533287644386292e-01
    z[3,1,2]  R795      -2.0075348019599915e-01
    z[3,1,2]  R796      -4.6012011170387268e-01
    z[3,1,2]  R797      2.8811085224151611e-01
    z[3,1,2]  R798      2.3537848889827728e-01
    z[3,1,2]  R799      3.6041319370269775e-01
    z[3,1,2]  R800      3.1767565011978149e-01
    z[3,1,2]  R801      4.6150788664817810e-01
    z[3,1,2]  R802      3.1205204129219055e-01
    z[3,1,2]  R803      3.9079514145851135e-01
    z[3,1,2]  R804      -4.7543495893478394e-01
    z[3,1,2]  R805      -3.3568689227104187e-01
    z[3,1,2]  R806      -0.611609697341919
    z[3,1,2]  R807      3.3169406652450562e-01
    z[3,1,2]  R808      1.8586735427379608e-01
    z[3,1,2]  R809      1.6468927264213562e-01
    z[3,1,2]  R810      4.8190999031066895e-01
    z[3,1,2]  R811      1.5249325335025787e-01
    z[3,1,2]  R812      1.0341267101466656e-02
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R745      -1
    z[3,1,3]  R746      1
    z[3,1,3]  R753      3.8233183324337006e-02
    z[3,1,3]  R754      -5.6281287223100662e-02
    z[3,1,3]  R755      -1.6667445003986359e-01
    z[3,1,3]  R756      -1.1466748267412186e-01
    z[3,1,3]  R757      2.0051820203661919e-02
    z[3,1,3]  R758      1.4815273880958557e-01
    z[3,1,3]  R759      -1.3428920507431030e-01
    z[3,1,3]  R760      -4.4378823041915894e-01
    z[3,1,3]  R761      -2.1803137660026550e-01
    z[3,1,3]  R762      -3.4357210993766785e-01
    z[3,1,3]  R763      -7.1974718570709229e-01
    z[3,1,3]  R764      -3.4759324789047241e-01
    z[3,1,3]  R765      -1.9642159342765808e-01
    z[3,1,3]  R766      1.9086253643035889e-01
    z[3,1,3]  R767      2.0496025681495667e-01
    z[3,1,3]  R768      -7.6402656733989716e-02
    z[3,1,3]  R769      1.2922681868076324e-01
    z[3,1,3]  R770      3.9129105210304260e-01
    z[3,1,3]  R771      5.7691287994384766e-01
    z[3,1,3]  R772      -1.4007851481437683e-01
    z[3,1,3]  R773      1.4971904456615448e-01
    z[3,1,3]  R774      5.6009536981582642e-01
    z[3,1,3]  R775      1.2469938024878502e-02
    z[3,1,3]  R776      6.5791660547256470e-01
    z[3,1,3]  R777      -3.6636710166931152e-01
    z[3,1,3]  R778      -2.0004889369010925e-01
    z[3,1,3]  R779      3.1147342920303345e-01
    z[3,1,3]  R780      -4.0973043441772461e-01
    z[3,1,3]  R781      -5.1095658540725708e-01
    z[3,1,3]  R782      -3.7618669867515564e-01
    z[3,1,3]  R783      0.0747021734714508
    z[3,1,3]  R784      -4.3851667642593384e-01
    z[3,1,3]  R785      -5.4049533605575562e-01
    z[3,1,3]  R786      -1.6657525300979614e-01
    z[3,1,3]  R787      -8.6760473251342773e-01
    z[3,1,3]  R788      -0.604107141494751
    z[3,1,3]  R789      -6.4292007684707642e-01
    z[3,1,3]  R790      -3.9882490038871765e-01
    z[3,1,3]  R791      -3.9741331338882446e-01
    z[3,1,3]  R792      -5.5144232511520386e-01
    z[3,1,3]  R793      3.6425283551216125e-01
    z[3,1,3]  R794      -6.6679733991622925e-01
    z[3,1,3]  R795      -6.8822938203811646e-01
    z[3,1,3]  R796      -5.6779447942972183e-02
    z[3,1,3]  R797      7.2429150342941284e-02
    z[3,1,3]  R798      -3.6378815770149231e-01
    z[3,1,3]  R799      -3.0981072783470154e-01
    z[3,1,3]  R800      -2.4286228418350220e-01
    z[3,1,3]  R801      -4.7408733516931534e-02
    z[3,1,3]  R802      1.5245880186557770e-01
    z[3,1,3]  R803      -6.2550747394561768e-01
    z[3,1,3]  R804      -5.9744048118591309e-01
    z[3,1,3]  R805      -3.2809905707836151e-02
    z[3,1,3]  R806      -1.4084091782569885e-01
    z[3,1,3]  R807      -4.1828554868698120e-01
    z[3,1,3]  R808      -2.3344330489635468e-01
    z[3,1,3]  R809      -5.5787372589111328e-01
    z[3,1,3]  R810      -5.1932847499847412e-01
    z[3,1,3]  R811      8.5775060579180717e-03
    z[3,1,3]  R812      -9.6009470522403717e-02
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R747      -1
    z[3,1,4]  R748      1
    z[3,1,4]  R753      2.6292881369590759e-01
    z[3,1,4]  R754      1.1427477002143860e-03
    z[3,1,4]  R755      2.9889410734176636e-01
    z[3,1,4]  R756      5.2212929725646973e-01
    z[3,1,4]  R757      2.8739643096923828e-01
    z[3,1,4]  R758      4.6194615960121155e-01
    z[3,1,4]  R759      -2.1076743304729462e-01
    z[3,1,4]  R760      8.2869090139865875e-02
    z[3,1,4]  R761      -5.6725829839706421e-01
    z[3,1,4]  R762      -2.1376505494117737e-01
    z[3,1,4]  R763      -5.7799136638641357e-01
    z[3,1,4]  R764      -1.2210885435342789e-01
    z[3,1,4]  R765      -3.7678331136703491e-01
    z[3,1,4]  R766      -1.7832627892494202e-01
    z[3,1,4]  R767      -4.3485438823699951e-01
    z[3,1,4]  R768      0.597722053527832
    z[3,1,4]  R769      4.6631014347076416e-01
    z[3,1,4]  R770      2.9649755358695984e-01
    z[3,1,4]  R771      4.4300094246864319e-01
    z[3,1,4]  R772      7.8966683149337769e-01
    z[3,1,4]  R773      6.4057117700576782e-01
    z[3,1,4]  R774      8.0915719270706177e-01
    z[3,1,4]  R775      -5.6615126132965088e-01
    z[3,1,4]  R776      -4.7507378458976746e-01
    z[3,1,4]  R777      -0.077522411942482
    z[3,1,4]  R778      -2.0425860583782196e-01
    z[3,1,4]  R779      -2.8395134210586548e-01
    z[3,1,4]  R780      -2.5203731656074524e-01
    z[3,1,4]  R781      1.7024983465671539e-01
    z[3,1,4]  R782      -2.1192273497581482e-01
    z[3,1,4]  R783      -2.3790630698204041e-01
    z[3,1,4]  R784      -3.1093001365661621e-01
    z[3,1,4]  R785      -4.6103402972221375e-01
    z[3,1,4]  R786      -1.1760532110929489e-01
    z[3,1,4]  R787      -1.2174691259860992e-01
    z[3,1,4]  R788      2.1174573898315430e-01
    z[3,1,4]  R789      3.1613189727067947e-02
    z[3,1,4]  R790      -3.2433861494064331e-01
    z[3,1,4]  R791      -1.9215957820415497e-01
    z[3,1,4]  R792      -4.2228358983993530e-01
    z[3,1,4]  R793      -4.4058007001876831e-01
    z[3,1,4]  R794      -4.0291124582290649e-01
    z[3,1,4]  R795      -5.0877290964126587e-01
    z[3,1,4]  R796      -1.5007355809211731e-01
    z[3,1,4]  R797      -2.6901068165898323e-02
    z[3,1,4]  R798      -1.9950826466083527e-01
    z[3,1,4]  R799      2.1566031500697136e-02
    z[3,1,4]  R800      -1.1014854535460472e-02
    z[3,1,4]  R801      -1.1080067604780197e-01
    z[3,1,4]  R802      -0.186312735080719
    z[3,1,4]  R803      0.0716809555888176
    z[3,1,4]  R804      -1.8982166051864624e-01
    z[3,1,4]  R805      -9.6350491046905518e-02
    z[3,1,4]  R806      -1.2929193675518036e-01
    z[3,1,4]  R807      1.0879338532686234e-01
    z[3,1,4]  R808      1.5406674146652222e-01
    z[3,1,4]  R809      -2.7404522895812988e-01
    z[3,1,4]  R810      -1.9865857902914286e-03
    z[3,1,4]  R811      1.0958957672119141e-01
    z[3,1,4]  R812      -1.0130358487367630e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R749      -1
    z[3,1,5]  R750      1
    z[3,1,5]  R753      -7.6487839221954346e-01
    z[3,1,5]  R754      -8.1545692682266235e-01
    z[3,1,5]  R755      -6.6843688488006592e-01
    z[3,1,5]  R756      -1.8858213722705841e-01
    z[3,1,5]  R757      -2.8500708937644958e-01
    z[3,1,5]  R758      -5.8723074197769165e-01
    z[3,1,5]  R759      -4.9610987305641174e-01
    z[3,1,5]  R760      -1.2263411283493042e-01
    z[3,1,5]  R761      -7.1447348594665527e-01
    z[3,1,5]  R762      1.4723853208124638e-02
    z[3,1,5]  R763      -2.5184974074363708e-01
    z[3,1,5]  R764      3.0484935641288757e-01
    z[3,1,5]  R765      -3.5863202810287476e-01
    z[3,1,5]  R766      1.1830098181962967e-01
    z[3,1,5]  R767      2.0683903992176056e-01
    z[3,1,5]  R768      2.4618925154209137e-01
    z[3,1,5]  R769      3.5562586784362793e-01
    z[3,1,5]  R770      -3.2573845237493515e-02
    z[3,1,5]  R771      3.1028228998184204e-01
    z[3,1,5]  R772      3.1595242023468018e-01
    z[3,1,5]  R773      -2.0066772401332855e-01
    z[3,1,5]  R774      -5.9441626071929932e-02
    z[3,1,5]  R775      2.7653029561042786e-01
    z[3,1,5]  R776      5.4726753383874893e-02
    z[3,1,5]  R777      3.3891800791025162e-02
    z[3,1,5]  R778      3.3521682024002075e-01
    z[3,1,5]  R779      -1.5599071979522705e-01
    z[3,1,5]  R780      2.5600078515708447e-03
    z[3,1,5]  R781      3.7962925434112549e-01
    z[3,1,5]  R782      1.4176584780216217e-01
    z[3,1,5]  R783      -5.8701831102371216e-01
    z[3,1,5]  R784      -1.1679384857416153e-01
    z[3,1,5]  R785      -3.2678428292274475e-01
    z[3,1,5]  R786      -5.0479900836944580e-01
    z[3,1,5]  R787      -4.6577075123786926e-01
    z[3,1,5]  R788      -1.2833803892135620e-01
    z[3,1,5]  R789      -1.1914358288049698e-01
    z[3,1,5]  R790      -7.5452238321304321e-02
    z[3,1,5]  R791      1.5624926984310150e-01
    z[3,1,5]  R792      -2.7592654805630445e-03
    z[3,1,5]  R793      3.9353662729263306e-01
    z[3,1,5]  R794      -4.4771060347557068e-01
    z[3,1,5]  R795      -2.4050267040729523e-01
    z[3,1,5]  R796      -5.0918138027191162e-01
    z[3,1,5]  R797      2.8002321720123291e-01
    z[3,1,5]  R798      -0.0396539680659771
    z[3,1,5]  R799      -3.9080310612916946e-02
    z[3,1,5]  R800      -1.9320229068398476e-02
    z[3,1,5]  R801      -1.4455287717282772e-02
    z[3,1,5]  R802      -1.0613378137350082e-01
    z[3,1,5]  R803      -4.5793151855468750e-01
    z[3,1,5]  R804      -1.9242644309997559e-01
    z[3,1,5]  R805      -5.7479149103164673e-01
    z[3,1,5]  R806      -1.8723320960998535e-01
    z[3,1,5]  R807      -2.7032741904258728e-01
    z[3,1,5]  R808      4.8314131796360016e-02
    z[3,1,5]  R809      -2.3204919416457415e-03
    z[3,1,5]  R810      -1.4920058846473694e-01
    z[3,1,5]  R811      -3.3517464995384216e-01
    z[3,1,5]  R812      -3.0391353368759155e-01
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R751      -1
    z[3,1,6]  R752      1
    z[3,1,6]  R753      -3.8868039846420288e-02
    z[3,1,6]  R754      1.7078292369842529e-01
    z[3,1,6]  R755      6.9759249687194824e-02
    z[3,1,6]  R756      -2.1688843145966530e-02
    z[3,1,6]  R757      -1.9994966685771942e-01
    z[3,1,6]  R758      -2.4667167663574219e-01
    z[3,1,6]  R759      -2.4155495688319206e-02
    z[3,1,6]  R760      -3.1171691417694092e-01
    z[3,1,6]  R761      1.3359299302101135e-01
    z[3,1,6]  R762      3.6421930789947510e-01
    z[3,1,6]  R763      8.1820584833621979e-02
    z[3,1,6]  R764      0.178999662399292
    z[3,1,6]  R765      -3.2374124974012375e-02
    z[3,1,6]  R766      -3.1008267402648926e-01
    z[3,1,6]  R767      1.9876374304294586e-01
    z[3,1,6]  R768      1.7755150794982910e-01
    z[3,1,6]  R769      -3.0585335567593575e-02
    z[3,1,6]  R770      2.4119900166988373e-01
    z[3,1,6]  R771      -1.1051856726408005e-01
    z[3,1,6]  R772      -2.6112416386604309e-01
    z[3,1,6]  R773      -2.4560314416885376e-01
    z[3,1,6]  R774      -8.6249615997076035e-03
    z[3,1,6]  R775      4.5009684562683105e-01
    z[3,1,6]  R776      8.4467105567455292e-02
    z[3,1,6]  R777      3.5163056850433350e-01
    z[3,1,6]  R778      1.7577911913394928e-01
    z[3,1,6]  R779      1.4857438392937183e-02
    z[3,1,6]  R780      -5.3883910179138184e-01
    z[3,1,6]  R781      -0.0820883959531784
    z[3,1,6]  R782      -2.7637362480163574e-01
    z[3,1,6]  R783      -1.2720239348709583e-02
    z[3,1,6]  R784      -7.6829922199249268e-01
    z[3,1,6]  R785      -5.1832711696624756e-01
    z[3,1,6]  R786      3.2919490337371826e-01
    z[3,1,6]  R787      -7.9426631331443787e-02
    z[3,1,6]  R788      -8.2022309303283691e-02
    z[3,1,6]  R789      1.7222639173269272e-02
    z[3,1,6]  R790      -2.2025832533836365e-01
    z[3,1,6]  R791      -1.8181389570236206e-01
    z[3,1,6]  R792      -0.0487905852496624
    z[3,1,6]  R793      -6.4627546072006226e-01
    z[3,1,6]  R794      -9.0783812105655670e-02
    z[3,1,6]  R795      -2.0084077119827271e-01
    z[3,1,6]  R796      2.7500659227371216e-01
    z[3,1,6]  R797      0.0792355015873909
    z[3,1,6]  R798      2.6192107796669006e-01
    z[3,1,6]  R799      -1.4711722731590271e-01
    z[3,1,6]  R800      0.0408710315823555
    z[3,1,6]  R801      -1.4940334856510162e-01
    z[3,1,6]  R802      7.1755279786884785e-03
    z[3,1,6]  R803      1.7631410062313080e-01
    z[3,1,6]  R804      -3.2058694958686829e-01
    z[3,1,6]  R805      4.4458872079849243e-01
    z[3,1,6]  R806      6.3253903388977051e-01
    z[3,1,6]  R807      -2.7765689417719841e-02
    z[3,1,6]  R808      5.8352392166852951e-02
    z[3,1,6]  R809      1.5340046584606171e-01
    z[3,1,6]  R810      -1.0635794699192047e-01
    z[3,1,6]  R811      2.2697240114212036e-01
    z[3,1,6]  R812      3.6155867576599121e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R813      -1
    z[1,4,0]  R814      1
    z[1,4,0]  R827      1.0895483195781708e-01
    z[1,4,0]  R828      0.0934840589761734
    z[1,4,0]  R829      3.0696392059326172e-01
    z[1,4,0]  R830      -2.8118395805358887e-01
    z[1,4,0]  R831      -2.0352919399738312e-01
    z[1,4,0]  R832      2.3840183019638062e-01
    z[1,4,0]  R833      6.5376496315002441e-01
    z[1,4,0]  R834      7.3611110448837280e-02
    z[1,4,0]  R835      6.6353899240493774e-01
    z[1,4,0]  R836      -2.6388000696897507e-03
    z[1,4,0]  R837      -1.3830715417861938e-01
    z[1,4,0]  R838      1.3887564837932587e-01
    z[1,4,0]  R839      -3.9402008056640625e-02
    z[1,4,0]  R840      -5.8835762739181519e-01
    z[1,4,0]  R841      1.6388840973377228e-02
    z[1,4,0]  R842      -4.1222300380468369e-02
    z[1,4,0]  R843      2.8189649805426598e-02
    z[1,4,0]  R844      -1.3297820091247559e-01
    z[1,4,0]  R845      -0.200653538107872
    z[1,4,0]  R846      -1.1196637898683548e-01
    z[1,4,0]  R847      7.7385380864143372e-02
    z[1,4,0]  R848      -9.9324166774749756e-02
    z[1,4,0]  R849      -3.5108867287635803e-01
    z[1,4,0]  R850      -6.3792335987091064e-01
    z[1,4,0]  R851      7.3212879896163940e-01
    z[1,4,0]  R852      4.4521890580654144e-02
    z[1,4,0]  R853      1.0701041668653488e-01
    z[1,4,0]  R854      8.5760957002639771e-01
    z[1,4,0]  R855      6.5180635452270508e-01
    z[1,4,0]  R856      7.6279711723327637e-01
    z[1,4,0]  R857      2.7415168285369873e-01
    z[1,4,0]  R858      -0.303154855966568
    z[1,4,0]  R859      -0.588360071182251
    z[1,4,0]  R860      -3.6815574765205383e-01
    z[1,4,0]  R861      1.2681372463703156e-01
    z[1,4,0]  R862      -9.6772246062755585e-02
    z[1,4,0]  R863      -1.7005759477615356e-01
    z[1,4,0]  R864      -1.2802829733118415e-03
    z[1,4,0]  R865      -5.3634065389633179e-01
    z[1,4,0]  R866      -5.5998134613037109e-01
    z[1,4,0]  R867      -5.8755654096603394e-01
    z[1,4,0]  R868      -0.550112783908844
    z[1,4,0]  R869      -5.7592475414276123e-01
    z[1,4,0]  R870      -6.1626744270324707e-01
    z[1,4,0]  R871      -5.3182321786880493e-01
    z[1,4,0]  R872      -6.7129796743392944e-01
    z[1,4,0]  R873      -6.7024582624435425e-01
    z[1,4,0]  R874      -5.8671534061431885e-01
    z[1,4,0]  R875      -6.3573414087295532e-01
    z[1,4,0]  R876      -7.6984459161758423e-01
    z[1,4,0]  R877      2.2927865386009216e-01
    z[1,4,0]  R878      6.8313342332839966e-01
    z[1,4,0]  R879      7.1734535694122314e-01
    z[1,4,0]  R880      -3.7486594915390015e-01
    z[1,4,0]  R881      4.1173495352268219e-02
    z[1,4,0]  R882      2.9657664895057678e-01
    z[1,4,0]  R883      1.4933685958385468e-01
    z[1,4,0]  R884      4.7259172797203064e-01
    z[1,4,0]  R885      5.5157589912414551e-01
    z[1,4,0]  R886      4.6082824468612671e-01
    z[1,4,0]  R887      -1.1115819215774536e-01
    z[1,4,0]  R888      -1.2880751863121986e-02
    z[1,4,0]  R889      5.5273931473493576e-02
    z[1,4,0]  R890      1.4118523895740509e-01
    z[1,4,0]  R891      6.4345401525497437e-01
    z[1,4,0]  R892      0.0411706306040287
    z[1,4,0]  R893      2.1051850169897079e-02
    z[1,4,0]  R894      3.9216777682304382e-01
    z[1,4,0]  R895      3.2847228646278381e-01
    z[1,4,0]  R896      -0.0661325603723526
    z[1,4,0]  R897      1.6047385288402438e-03
    z[1,4,0]  R898      1.1611460894346237e-01
    z[1,4,0]  R899      2.0121926069259644e-01
    z[1,4,0]  R900      -2.7605935931205750e-01
    z[1,4,0]  R901      5.7087254524230957e-01
    z[1,4,0]  R902      0.534482479095459
    z[1,4,0]  R903      5.3874176740646362e-01
    z[1,4,0]  R904      6.4456933736801147e-01
    z[1,4,0]  R905      -2.6294299960136414e-01
    z[1,4,0]  R906      1.6433918476104736e-01
    z[1,4,0]  R907      9.2788405716419220e-02
    z[1,4,0]  R908      8.6532514542341232e-03
    z[1,4,0]  R909      -5.0115205347537994e-02
    z[1,4,0]  R910      8.6147910356521606e-01
    z[1,4,0]  R911      4.8253032565116882e-01
    z[1,4,0]  R912      7.4361699819564819e-01
    z[1,4,0]  R913      7.0720338821411133e-01
    z[1,4,0]  R914      1.0208169370889664e-01
    z[1,4,0]  R915      1.2148441374301910e-01
    z[1,4,0]  R916      -1.1865770816802979e-01
    z[1,4,0]  R917      -1.4550159871578217e-01
    z[1,4,0]  R918      -3.6517471075057983e-02
    z[1,4,0]  R919      -2.0804883539676666e-01
    z[1,4,0]  R920      3.9359282702207565e-02
    z[1,4,0]  R921      6.9649285078048706e-01
    z[1,4,0]  R922      7.3793154954910278e-01
    z[1,4,0]  R923      6.9981509447097778e-01
    z[1,4,0]  R924      8.4909921884536743e-01
    z[1,4,0]  R925      2.7244171500205994e-01
    z[1,4,0]  R926      0.168548122048378
    z[1,4,0]  R927      6.9429796934127808e-01
    z[1,4,0]  R928      6.7381465435028076e-01
    z[1,4,0]  R929      7.3634153604507446e-01
    z[1,4,0]  R930      6.1560302972793579e-01
    z[1,4,0]  R931      2.6052442193031311e-01
    z[1,4,0]  R932      -1.2880542874336243e-01
    z[1,4,0]  R933      -1.2372874468564987e-01
    z[1,4,0]  R934      2.1286159753799438e-01
    z[1,4,0]  R935      5.8649146556854248e-01
    z[1,4,0]  R936      -1.5846298635005951e-01
    z[1,4,0]  R937      -8.1728391349315643e-02
    z[1,4,0]  R938      6.9623565673828125e-01
    z[1,4,0]  R939      7.5372809171676636e-01
    z[1,4,0]  R940      6.9946563243865967e-01
    z[1,4,0]  R941      6.5266388654708862e-01
    z[1,4,0]  R942      8.8066416978836060e-01
    z[1,4,0]  R943      0.0986173152923584
    z[1,4,0]  R944      -0.0824391320347786
    z[1,4,0]  R945      1.0335975885391235e-01
    z[1,4,0]  R946      -1.2979520484805107e-02
    z[1,4,0]  R947      -0.0978812426328659
    z[1,4,0]  R948      -4.1288039088249207e-01
    z[1,4,0]  R949      -4.5653238892555237e-01
    z[1,4,0]  R950      6.8289393186569214e-01
    z[1,4,0]  R951      2.8496208786964417e-01
    z[1,4,0]  R952      -1.0464946739375591e-02
    z[1,4,0]  R953      1.7132751643657684e-01
    z[1,4,0]  R954      -2.8915578126907349e-01
    z[1,4,0]  R955      -2.0504486560821533e-01
    z[1,4,0]  R956      3.2287436723709106e-01
    z[1,4,0]  R957      0.789137065410614
    z[1,4,0]  R958      7.2498601675033569e-01
    z[1,4,0]  R959      7.4532598257064819e-01
    z[1,4,0]  R960      7.3198574781417847e-01
    z[1,4,0]  R961      -9.2089831829071045e-02
    z[1,4,0]  R962      -7.7427178621292114e-02
    z[1,4,0]  R963      1.8897749483585358e-01
    z[1,4,0]  R964      4.4966783374547958e-02
    z[1,4,0]  R965      4.8142012953758240e-01
    z[1,4,0]  R966      6.7377209663391113e-01
    z[1,4,0]  R967      7.4083232879638672e-01
    z[1,4,0]  R968      5.7815268635749817e-02
    z[1,4,0]  R969      2.0731888711452484e-01
    z[1,4,0]  R970      1.8512832000851631e-02
    z[1,4,0]  R971      3.2425409555435181e-01
    z[1,4,0]  R972      2.0348079502582550e-01
    z[1,4,0]  R973      5.5700516700744629e-01
    z[1,4,0]  R974      4.3710514903068542e-01
    z[1,4,0]  R975      5.9524399042129517e-01
    z[1,4,0]  R976      4.2955505847930908e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R815      -1
    z[1,4,1]  R816      1
    z[1,4,1]  R827      -4.6671545505523682e-01
    z[1,4,1]  R828      -1.3359937071800232e-01
    z[1,4,1]  R829      -5.4755187034606934e-01
    z[1,4,1]  R830      -4.5454701781272888e-01
    z[1,4,1]  R831      8.2258599996566772e-01
    z[1,4,1]  R832      8.3536797761917114e-01
    z[1,4,1]  R833      6.0298210382461548e-01
    z[1,4,1]  R834      6.8687140941619873e-01
    z[1,4,1]  R835      2.5713574886322021e-01
    z[1,4,1]  R836      8.2437044382095337e-01
    z[1,4,1]  R837      -6.3565254211425781e-01
    z[1,4,1]  R838      -2.6428091526031494e-01
    z[1,4,1]  R839      -3.4266650676727295e-01
    z[1,4,1]  R840      1.7891493439674377e-01
    z[1,4,1]  R841      -8.8861101539805532e-04
    z[1,4,1]  R842      7.3406648635864258e-01
    z[1,4,1]  R843      7.5357919931411743e-01
    z[1,4,1]  R844      0.777441143989563
    z[1,4,1]  R845      8.4087914228439331e-01
    z[1,4,1]  R846      6.7594271898269653e-01
    z[1,4,1]  R847      -3.0124077200889587e-01
    z[1,4,1]  R848      -3.4512379765510559e-01
    z[1,4,1]  R849      -7.5806662440299988e-02
    z[1,4,1]  R850      1.4388592541217804e-01
    z[1,4,1]  R851      5.3881222009658813e-01
    z[1,4,1]  R852      8.3683592081069946e-01
    z[1,4,1]  R853      8.5966998338699341e-01
    z[1,4,1]  R854      3.2006371021270752e-01
    z[1,4,1]  R855      5.7017904520034790e-01
    z[1,4,1]  R856      5.0148993730545044e-01
    z[1,4,1]  R857      -3.6733394861221313e-01
    z[1,4,1]  R858      3.8637730479240417e-01
    z[1,4,1]  R859      5.2368111908435822e-02
    z[1,4,1]  R860      1.3667643070220947e-01
    z[1,4,1]  R861      7.8310316801071167e-01
    z[1,4,1]  R862      9.3387198448181152e-01
    z[1,4,1]  R863      7.3081928491592407e-01
    z[1,4,1]  R864      6.8152934312820435e-01
    z[1,4,1]  R865      7.1633970737457275e-01
    z[1,4,1]  R866      6.6614228487014771e-01
    z[1,4,1]  R867      -3.5023787617683411e-01
    z[1,4,1]  R868      -2.5114196538925171e-01
    z[1,4,1]  R869      -3.5928779840469360e-01
    z[1,4,1]  R870      -2.9726028442382812e-01
    z[1,4,1]  R871      -5.5615627765655518e-01
    z[1,4,1]  R872      -5.1980084180831909e-01
    z[1,4,1]  R873      -4.0141481161117554e-01
    z[1,4,1]  R874      -2.5546005368232727e-01
    z[1,4,1]  R875      -0.32403364777565
    z[1,4,1]  R876      -2.9785001277923584e-01
    z[1,4,1]  R877      -7.1147876977920532e-01
    z[1,4,1]  R878      -4.6179959177970886e-01
    z[1,4,1]  R879      -3.7745356559753418e-01
    z[1,4,1]  R880      7.5218003988265991e-01
    z[1,4,1]  R881      -5.3693801164627075e-01
    z[1,4,1]  R882      -6.2811189889907837e-01
    z[1,4,1]  R883      -7.1127003431320190e-01
    z[1,4,1]  R884      -4.3059056997299194e-01
    z[1,4,1]  R885      -4.5296445488929749e-01
    z[1,4,1]  R886      -4.9211472272872925e-01
    z[1,4,1]  R887      -6.8705797195434570e-01
    z[1,4,1]  R888      -3.8977241516113281e-01
    z[1,4,1]  R889      7.1482799947261810e-02
    z[1,4,1]  R890      -5.5262351036071777e-01
    z[1,4,1]  R891      -5.0978618860244751e-01
    z[1,4,1]  R892      7.4618428945541382e-01
    z[1,4,1]  R893      8.8835489749908447e-01
    z[1,4,1]  R894      -1.7341756820678711e-01
    z[1,4,1]  R895      8.2127535343170166e-01
    z[1,4,1]  R896      -0.522761881351471
    z[1,4,1]  R897      -2.8531920909881592e-01
    z[1,4,1]  R898      -5.0097370147705078e-01
    z[1,4,1]  R899      -5.6872421503067017e-01
    z[1,4,1]  R900      -4.4913262128829956e-01
    z[1,4,1]  R901      -5.8296936750411987e-01
    z[1,4,1]  R902      -5.0831443071365356e-01
    z[1,4,1]  R903      -4.9253699183464050e-01
    z[1,4,1]  R904      -1.8199425935745239e-01
    z[1,4,1]  R905      5.9212136268615723e-01
    z[1,4,1]  R906      8.6953115463256836e-01
    z[1,4,1]  R907      -2.9620343446731567e-01
    z[1,4,1]  R908      -8.4968489408493042e-01
    z[1,4,1]  R909      -5.1040691137313843e-01
    z[1,4,1]  R910      -2.2170072793960571e-01
    z[1,4,1]  R911      -5.4525840282440186e-01
    z[1,4,1]  R912      -1.0907662659883499e-01
    z[1,4,1]  R913      -2.1314503252506256e-01
    z[1,4,1]  R914      8.4723156690597534e-01
    z[1,4,1]  R915      0.880919337272644
    z[1,4,1]  R916      7.2155517339706421e-01
    z[1,4,1]  R917      -0.628449022769928
    z[1,4,1]  R918      -7.0719486474990845e-01
    z[1,4,1]  R919      -8.2792568206787109e-01
    z[1,4,1]  R920      -7.3079919815063477e-01
    z[1,4,1]  R921      -6.0353887081146240e-01
    z[1,4,1]  R922      -1.8426091969013214e-01
    z[1,4,1]  R923      -4.6042034029960632e-01
    z[1,4,1]  R924      -8.7848186492919922e-02
    z[1,4,1]  R925      0.886595606803894
    z[1,4,1]  R926      9.6384423971176147e-01
    z[1,4,1]  R927      -4.5259761810302734e-01
    z[1,4,1]  R928      -2.2987347841262817e-01
    z[1,4,1]  R929      -0.301234632730484
    z[1,4,1]  R930      -1.4728754758834839e-01
    z[1,4,1]  R931      8.4514260292053223e-01
    z[1,4,1]  R932      8.3458983898162842e-01
    z[1,4,1]  R933      9.0441882610321045e-01
    z[1,4,1]  R934      5.4224532842636108e-01
    z[1,4,1]  R935      4.8052567243576050e-01
    z[1,4,1]  R936      4.5277449488639832e-01
    z[1,4,1]  R937      -0.736034631729126
    z[1,4,1]  R938      -0.50221848487854
    z[1,4,1]  R939      -2.9484912753105164e-01
    z[1,4,1]  R940      -3.2997876405715942e-01
    z[1,4,1]  R941      -3.0022957921028137e-01
    z[1,4,1]  R942      -0.0613643079996109
    z[1,4,1]  R943      8.3372437953948975e-01
    z[1,4,1]  R944      0.959001362323761
    z[1,4,1]  R945      8.2865160703659058e-01
    z[1,4,1]  R946      8.6359906196594238e-01
    z[1,4,1]  R947      -7.7929478883743286e-01
    z[1,4,1]  R948      5.7339859008789062e-01
    z[1,4,1]  R949      7.7785891294479370e-01
    z[1,4,1]  R950      -0.228417307138443
    z[1,4,1]  R951      6.4570468664169312e-01
    z[1,4,1]  R952      0.749077558517456
    z[1,4,1]  R953      7.8521335124969482e-01
    z[1,4,1]  R954      6.2177753448486328e-01
    z[1,4,1]  R955      5.0166165828704834e-01
    z[1,4,1]  R956      6.4847087860107422e-01
    z[1,4,1]  R957      -5.2170819044113159e-01
    z[1,4,1]  R958      -2.6020979881286621e-01
    z[1,4,1]  R959      -1.6403673589229584e-01
    z[1,4,1]  R960      -2.5790682435035706e-01
    z[1,4,1]  R961      7.9363530874252319e-01
    z[1,4,1]  R962      9.5412641763687134e-01
    z[1,4,1]  R963      9.1491103172302246e-01
    z[1,4,1]  R964      0.478773295879364
    z[1,4,1]  R965      0.548701286315918
    z[1,4,1]  R966      6.0121679306030273e-01
    z[1,4,1]  R967      -1.6934056580066681e-01
    z[1,4,1]  R968      8.2446902990341187e-01
    z[1,4,1]  R969      9.6358984708786011e-01
    z[1,4,1]  R970      6.5812236070632935e-01
    z[1,4,1]  R971      7.1535408496856689e-01
    z[1,4,1]  R972      5.4849225282669067e-01
    z[1,4,1]  R973      7.1080332994461060e-01
    z[1,4,1]  R974      7.2019606828689575e-01
    z[1,4,1]  R975      0.670100748538971
    z[1,4,1]  R976      0.737332820892334
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R817      -1
    z[1,4,2]  R818      1
    z[1,4,2]  R827      -4.8679551482200623e-01
    z[1,4,2]  R828      3.6904752254486084e-02
    z[1,4,2]  R829      7.8874669969081879e-02
    z[1,4,2]  R830      -2.1364346146583557e-01
    z[1,4,2]  R831      1.3000316917896271e-01
    z[1,4,2]  R832      -1.4253102242946625e-01
    z[1,4,2]  R833      -8.2498893141746521e-02
    z[1,4,2]  R834      3.2142437994480133e-02
    z[1,4,2]  R835      2.2951868176460266e-01
    z[1,4,2]  R836      -1.9364626705646515e-01
    z[1,4,2]  R837      4.1217097640037537e-01
    z[1,4,2]  R838      1.3405339419841766e-01
    z[1,4,2]  R839      -2.9808761551976204e-02
    z[1,4,2]  R840      -4.6589165925979614e-01
    z[1,4,2]  R841      9.4442255795001984e-02
    z[1,4,2]  R842      1.6268730163574219e-01
    z[1,4,2]  R843      4.9862369894981384e-02
    z[1,4,2]  R844      2.4379999935626984e-01
    z[1,4,2]  R845      1.8106689676642418e-02
    z[1,4,2]  R846      2.1392691135406494e-01
    z[1,4,2]  R847      -6.2701150774955750e-02
    z[1,4,2]  R848      -2.3533287644386292e-01
    z[1,4,2]  R849      -2.0075348019599915e-01
    z[1,4,2]  R850      -4.6012011170387268e-01
    z[1,4,2]  R851      2.8811085224151611e-01
    z[1,4,2]  R852      2.3537848889827728e-01
    z[1,4,2]  R853      3.6041319370269775e-01
    z[1,4,2]  R854      3.1767565011978149e-01
    z[1,4,2]  R855      4.6150788664817810e-01
    z[1,4,2]  R856      3.1205204129219055e-01
    z[1,4,2]  R857      3.9079514145851135e-01
    z[1,4,2]  R858      -4.7543495893478394e-01
    z[1,4,2]  R859      -3.3568689227104187e-01
    z[1,4,2]  R860      -0.611609697341919
    z[1,4,2]  R861      3.3169406652450562e-01
    z[1,4,2]  R862      1.8586735427379608e-01
    z[1,4,2]  R863      1.6468927264213562e-01
    z[1,4,2]  R864      4.8190999031066895e-01
    z[1,4,2]  R865      1.5249325335025787e-01
    z[1,4,2]  R866      1.0341267101466656e-02
    z[1,4,2]  R867      -1.9520850479602814e-01
    z[1,4,2]  R868      9.2998119071125984e-03
    z[1,4,2]  R869      -5.1382946968078613e-01
    z[1,4,2]  R870      1.9087596237659454e-01
    z[1,4,2]  R871      -1.3207024335861206e-01
    z[1,4,2]  R872      -1.5683691203594208e-01
    z[1,4,2]  R873      -3.3692610263824463e-01
    z[1,4,2]  R874      -2.0341442525386810e-01
    z[1,4,2]  R875      9.9804960191249847e-02
    z[1,4,2]  R876      6.1308752745389938e-02
    z[1,4,2]  R877      -2.7224181219935417e-02
    z[1,4,2]  R878      1.4349375665187836e-01
    z[1,4,2]  R879      -1.2734179198741913e-01
    z[1,4,2]  R880      -2.1428765356540680e-01
    z[1,4,2]  R881      7.2389543056488037e-01
    z[1,4,2]  R882      5.6075859069824219e-01
    z[1,4,2]  R883      4.6849995851516724e-01
    z[1,4,2]  R884      -3.2706481218338013e-01
    z[1,4,2]  R885      9.1979922726750374e-03
    z[1,4,2]  R886      -5.4430490732192993e-01
    z[1,4,2]  R887      5.6827646493911743e-01
    z[1,4,2]  R888      -5.1286339759826660e-01
    z[1,4,2]  R889      -0.46903195977211
    z[1,4,2]  R890      1.9012993574142456e-01
    z[1,4,2]  R891      -2.2154814004898071e-01
    z[1,4,2]  R892      5.2097213268280029e-01
    z[1,4,2]  R893      -1.8444817513227463e-02
    z[1,4,2]  R894      6.6841256618499756e-01
    z[1,4,2]  R895      3.9735755324363708e-01
    z[1,4,2]  R896      -5.5841112136840820e-01
    z[1,4,2]  R897      -1.5113285183906555e-01
    z[1,4,2]  R898      1.7867620289325714e-01
    z[1,4,2]  R899      5.4607796669006348e-01
    z[1,4,2]  R900      -5.6303566694259644e-01
    z[1,4,2]  R901      -3.3601748943328857e-01
    z[1,4,2]  R902      -1.7890906333923340e-01
    z[1,4,2]  R903      -1.4444294571876526e-01
    z[1,4,2]  R904      -0.652751088142395
    z[1,4,2]  R905      -3.9298117160797119e-01
    z[1,4,2]  R906      9.1285429894924164e-02
    z[1,4,2]  R907      -0.668785572052002
    z[1,4,2]  R908      1.9610232114791870e-01
    z[1,4,2]  R909      -7.2156423330307007e-01
    z[1,4,2]  R910      1.7301666736602783e-01
    z[1,4,2]  R911      -3.2959020137786865e-01
    z[1,4,2]  R912      1.7456393688917160e-02
    z[1,4,2]  R913      2.7208173274993896e-01
    z[1,4,2]  R914      1.0649657994508743e-01
    z[1,4,2]  R915      -0.0938347652554512
    z[1,4,2]  R916      4.1236659884452820e-01
    z[1,4,2]  R917      -0.494943231344223
    z[1,4,2]  R918      -1.2691226601600647e-01
    z[1,4,2]  R919      5.0492975860834122e-02
    z[1,4,2]  R920      4.7204467654228210e-01
    z[1,4,2]  R921      -8.4907226264476776e-02
    z[1,4,2]  R922      -1.3565035164356232e-01
    z[1,4,2]  R923      1.6225245594978333e-01
    z[1,4,2]  R924      -1.5981492400169373e-01
    z[1,4,2]  R925      0.0615328773856163
    z[1,4,2]  R926      1.6760799288749695e-01
    z[1,4,2]  R927      -1.1647468805313110e-01
    z[1,4,2]  R928      2.5308451056480408e-01
    z[1,4,2]  R929      -2.0218318328261375e-02
    z[1,4,2]  R930      0.582478940486908
    z[1,4,2]  R931      2.9166597127914429e-01
    z[1,4,2]  R932      4.5439252257347107e-01
    z[1,4,2]  R933      2.3995140194892883e-01
    z[1,4,2]  R934      1.7692428827285767e-01
    z[1,4,2]  R935      3.7672752141952515e-01
    z[1,4,2]  R936      1.2909972667694092e-01
    z[1,4,2]  R937      6.1129800975322723e-02
    z[1,4,2]  R938      4.1504953987896442e-03
    z[1,4,2]  R939      3.5807663202285767e-01
    z[1,4,2]  R940      1.4697174727916718e-01
    z[1,4,2]  R941      -2.2409553825855255e-01
    z[1,4,2]  R942      -1.0674206167459488e-01
    z[1,4,2]  R943      2.6567617058753967e-01
    z[1,4,2]  R944      1.8880042433738708e-01
    z[1,4,2]  R945      3.4775212407112122e-01
    z[1,4,2]  R946      -0.073155976831913
    z[1,4,2]  R947      5.9725141525268555e-01
    z[1,4,2]  R948      -9.0044438838958740e-02
    z[1,4,2]  R949      3.5335725545883179e-01
    z[1,4,2]  R950      -4.3700179457664490e-01
    z[1,4,2]  R951      2.0539747178554535e-01
    z[1,4,2]  R952      2.1612955629825592e-01
    z[1,4,2]  R953      3.0064875259995461e-02
    z[1,4,2]  R954      2.0245923101902008e-01
    z[1,4,2]  R955      2.1178799867630005e-01
    z[1,4,2]  R956      -3.9450940489768982e-01
    z[1,4,2]  R957      4.3772339820861816e-02
    z[1,4,2]  R958      -4.0393903851509094e-02
    z[1,4,2]  R959      9.4932131469249725e-02
    z[1,4,2]  R960      -3.7179183959960938e-01
    z[1,4,2]  R961      2.8107839822769165e-01
    z[1,4,2]  R962      1.8511307239532471e-01
    z[1,4,2]  R963      -1.2274567782878876e-01
    z[1,4,2]  R964      1.3293507695198059e-01
    z[1,4,2]  R965      2.1158735454082489e-01
    z[1,4,2]  R966      -5.7536359876394272e-02
    z[1,4,2]  R967      3.7202858924865723e-01
    z[1,4,2]  R968      2.4892997741699219e-01
    z[1,4,2]  R969      6.7938235588371754e-03
    z[1,4,2]  R970      2.5844931602478027e-01
    z[1,4,2]  R971      1.1316926218569279e-02
    z[1,4,2]  R972      6.3249832019209862e-03
    z[1,4,2]  R973      -2.2752940654754639e-01
    z[1,4,2]  R974      -3.5796791315078735e-01
    z[1,4,2]  R975      -2.9539284110069275e-01
    z[1,4,2]  R976      -1.9871445000171661e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R819      -1
    z[1,4,3]  R820      1
    z[1,4,3]  R827      1.4971904456615448e-01
    z[1,4,3]  R828      5.6009536981582642e-01
    z[1,4,3]  R829      1.2469938024878502e-02
    z[1,4,3]  R830      6.5791660547256470e-01
    z[1,4,3]  R831      -3.6636710166931152e-01
    z[1,4,3]  R832      -2.0004889369010925e-01
    z[1,4,3]  R833      3.1147342920303345e-01
    z[1,4,3]  R834      -4.0973043441772461e-01
    z[1,4,3]  R835      -5.1095658540725708e-01
    z[1,4,3]  R836      -3.7618669867515564e-01
    z[1,4,3]  R837      0.0747021734714508
    z[1,4,3]  R838      -4.3851667642593384e-01
    z[1,4,3]  R839      -5.4049533605575562e-01
    z[1,4,3]  R840      -1.6657525300979614e-01
    z[1,4,3]  R841      -8.6760473251342773e-01
    z[1,4,3]  R842      -0.604107141494751
    z[1,4,3]  R843      -6.4292007684707642e-01
    z[1,4,3]  R844      -3.9882490038871765e-01
    z[1,4,3]  R845      -3.9741331338882446e-01
    z[1,4,3]  R846      -5.5144232511520386e-01
    z[1,4,3]  R847      3.6425283551216125e-01
    z[1,4,3]  R848      -6.6679733991622925e-01
    z[1,4,3]  R849      -6.8822938203811646e-01
    z[1,4,3]  R850      -5.6779447942972183e-02
    z[1,4,3]  R851      7.2429150342941284e-02
    z[1,4,3]  R852      -3.6378815770149231e-01
    z[1,4,3]  R853      -3.0981072783470154e-01
    z[1,4,3]  R854      -2.4286228418350220e-01
    z[1,4,3]  R855      -4.7408733516931534e-02
    z[1,4,3]  R856      1.5245880186557770e-01
    z[1,4,3]  R857      -6.2550747394561768e-01
    z[1,4,3]  R858      -5.9744048118591309e-01
    z[1,4,3]  R859      -3.2809905707836151e-02
    z[1,4,3]  R860      -1.4084091782569885e-01
    z[1,4,3]  R861      -4.1828554868698120e-01
    z[1,4,3]  R862      -2.3344330489635468e-01
    z[1,4,3]  R863      -5.5787372589111328e-01
    z[1,4,3]  R864      -5.1932847499847412e-01
    z[1,4,3]  R865      8.5775060579180717e-03
    z[1,4,3]  R866      -9.6009470522403717e-02
    z[1,4,3]  R867      -3.6240240931510925e-01
    z[1,4,3]  R868      -5.8406364917755127e-01
    z[1,4,3]  R869      -3.9486807584762573e-01
    z[1,4,3]  R870      -4.8408702015876770e-01
    z[1,4,3]  R871      -2.6580053567886353e-01
    z[1,4,3]  R872      -1.0204381495714188e-01
    z[1,4,3]  R873      -2.9818978905677795e-01
    z[1,4,3]  R874      -4.7207662463188171e-01
    z[1,4,3]  R875      -4.9308976531028748e-01
    z[1,4,3]  R876      -4.1535407304763794e-01
    z[1,4,3]  R877      -1.7730298638343811e-01
    z[1,4,3]  R878      9.8836747929453850e-03
    z[1,4,3]  R879      6.6793225705623627e-02
    z[1,4,3]  R880      2.3008877038955688e-01
    z[1,4,3]  R881      3.6241963505744934e-01
    z[1,4,3]  R882      1.1827819049358368e-01
    z[1,4,3]  R883      4.2783892154693604e-01
    z[1,4,3]  R884      0.361988365650177
    z[1,4,3]  R885      1.6963206231594086e-01
    z[1,4,3]  R886      3.9747819304466248e-01
    z[1,4,3]  R887      2.1296314895153046e-01
    z[1,4,3]  R888      1.4430669136345387e-02
    z[1,4,3]  R889      -3.5894379019737244e-01
    z[1,4,3]  R890      -5.8972876518964767e-02
    z[1,4,3]  R891      -1.3377124071121216e-01
    z[1,4,3]  R892      2.0331309735774994e-01
    z[1,4,3]  R893      1.6727812588214874e-01
    z[1,4,3]  R894      -4.0399852395057678e-01
    z[1,4,3]  R895      -2.3591844365000725e-02
    z[1,4,3]  R896      4.4183173775672913e-01
    z[1,4,3]  R897      -3.2720467448234558e-01
    z[1,4,3]  R898      -4.3055215477943420e-01
    z[1,4,3]  R899      -3.1249335408210754e-01
    z[1,4,3]  R900      0.405229389667511
    z[1,4,3]  R901      1.7126889526844025e-01
    z[1,4,3]  R902      5.4399931430816650e-01
    z[1,4,3]  R903      3.7154817581176758e-01
    z[1,4,3]  R904      -7.8700542449951172e-02
    z[1,4,3]  R905      -6.3104387372732162e-03
    z[1,4,3]  R906      2.0656596124172211e-01
    z[1,4,3]  R907      -2.2475211322307587e-01
    z[1,4,3]  R908      -5.3780917078256607e-02
    z[1,4,3]  R909      2.1162706613540649e-01
    z[1,4,3]  R910      -6.0689233243465424e-02
    z[1,4,3]  R911      4.1020902991294861e-01
    z[1,4,3]  R912      -6.2734061479568481e-01
    z[1,4,3]  R913      -1.5283970534801483e-01
    z[1,4,3]  R914      9.8189562559127808e-02
    z[1,4,3]  R915      3.2321885228157043e-01
    z[1,4,3]  R916      0.495151162147522
    z[1,4,3]  R917      -1.1997682973742485e-02
    z[1,4,3]  R918      -3.3768004179000854e-01
    z[1,4,3]  R919      2.6501366496086121e-01
    z[1,4,3]  R920      2.4692660570144653e-01
    z[1,4,3]  R921      1.5630787611007690e-01
    z[1,4,3]  R922      -3.9980259537696838e-01
    z[1,4,3]  R923      2.1275892853736877e-02
    z[1,4,3]  R924      -2.5178197026252747e-01
    z[1,4,3]  R925      3.1184336543083191e-01
    z[1,4,3]  R926      2.5135293602943420e-02
    z[1,4,3]  R927      4.3311214447021484e-01
    z[1,4,3]  R928      -4.6883741021156311e-01
    z[1,4,3]  R929      1.8819957971572876e-02
    z[1,4,3]  R930      -3.3058160543441772e-01
    z[1,4,3]  R931      4.9212433397769928e-02
    z[1,4,3]  R932      5.8376058936119080e-02
    z[1,4,3]  R933      2.5313809514045715e-01
    z[1,4,3]  R934      3.5397332906723022e-01
    z[1,4,3]  R935      4.8243951797485352e-01
    z[1,4,3]  R936      0.520687997341156
    z[1,4,3]  R937      -5.3401719778776169e-02
    z[1,4,3]  R938      3.7972751259803772e-01
    z[1,4,3]  R939      -1.1306407302618027e-01
    z[1,4,3]  R940      -3.3169585466384888e-01
    z[1,4,3]  R941      2.3402684926986694e-01
    z[1,4,3]  R942      -3.3222606778144836e-01
    z[1,4,3]  R943      2.2909869253635406e-01
    z[1,4,3]  R944      1.4218333363533020e-01
    z[1,4,3]  R945      2.0553000271320343e-01
    z[1,4,3]  R946      2.3103292286396027e-01
    z[1,4,3]  R947      -5.7719651609659195e-02
    z[1,4,3]  R948      1.9641692936420441e-01
    z[1,4,3]  R949      1.0498762130737305e-01
    z[1,4,3]  R950      8.7422579526901245e-02
    z[1,4,3]  R951      0.33449786901474
    z[1,4,3]  R952      2.0736102759838104e-01
    z[1,4,3]  R953      3.3902138471603394e-01
    z[1,4,3]  R954      -2.3966248333454132e-01
    z[1,4,3]  R955      3.6694878339767456e-01
    z[1,4,3]  R956      -5.0786721706390381e-01
    z[1,4,3]  R957      -2.3085476830601692e-02
    z[1,4,3]  R958      1.0495626181364059e-01
    z[1,4,3]  R959      -3.4113073348999023e-01
    z[1,4,3]  R960      8.6206562817096710e-02
    z[1,4,3]  R961      2.9715862870216370e-01
    z[1,4,3]  R962      1.2247022241353989e-01
    z[1,4,3]  R963      -2.4262189865112305e-02
    z[1,4,3]  R964      6.0212099552154541e-01
    z[1,4,3]  R965      2.7250188589096069e-01
    z[1,4,3]  R966      2.7629515528678894e-01
    z[1,4,3]  R967      -2.8098204731941223e-01
    z[1,4,3]  R968      8.2127936184406281e-02
    z[1,4,3]  R969      9.0992741286754608e-02
    z[1,4,3]  R970      5.9459584951400757e-01
    z[1,4,3]  R971      4.8615738749504089e-01
    z[1,4,3]  R972      4.2329812049865723e-01
    z[1,4,3]  R973      1.4226980507373810e-02
    z[1,4,3]  R974      -1.6567033529281616e-01
    z[1,4,3]  R975      -1.9238793849945068e-01
    z[1,4,3]  R976      -1.8471808731555939e-01
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R821      -1
    z[1,4,4]  R822      1
    z[1,4,4]  R827      6.4057117700576782e-01
    z[1,4,4]  R828      8.0915719270706177e-01
    z[1,4,4]  R829      -5.6615126132965088e-01
    z[1,4,4]  R830      -4.7507378458976746e-01
    z[1,4,4]  R831      -0.077522411942482
    z[1,4,4]  R832      -2.0425860583782196e-01
    z[1,4,4]  R833      -2.8395134210586548e-01
    z[1,4,4]  R834      -2.5203731656074524e-01
    z[1,4,4]  R835      1.7024983465671539e-01
    z[1,4,4]  R836      -2.1192273497581482e-01
    z[1,4,4]  R837      -2.3790630698204041e-01
    z[1,4,4]  R838      -3.1093001365661621e-01
    z[1,4,4]  R839      -4.6103402972221375e-01
    z[1,4,4]  R840      -1.1760532110929489e-01
    z[1,4,4]  R841      -1.2174691259860992e-01
    z[1,4,4]  R842      2.1174573898315430e-01
    z[1,4,4]  R843      3.1613189727067947e-02
    z[1,4,4]  R844      -3.2433861494064331e-01
    z[1,4,4]  R845      -1.9215957820415497e-01
    z[1,4,4]  R846      -4.2228358983993530e-01
    z[1,4,4]  R847      -4.4058007001876831e-01
    z[1,4,4]  R848      -4.0291124582290649e-01
    z[1,4,4]  R849      -5.0877290964126587e-01
    z[1,4,4]  R850      -1.5007355809211731e-01
    z[1,4,4]  R851      -2.6901068165898323e-02
    z[1,4,4]  R852      -1.9950826466083527e-01
    z[1,4,4]  R853      2.1566031500697136e-02
    z[1,4,4]  R854      -1.1014854535460472e-02
    z[1,4,4]  R855      -1.1080067604780197e-01
    z[1,4,4]  R856      -0.186312735080719
    z[1,4,4]  R857      0.0716809555888176
    z[1,4,4]  R858      -1.8982166051864624e-01
    z[1,4,4]  R859      -9.6350491046905518e-02
    z[1,4,4]  R860      -1.2929193675518036e-01
    z[1,4,4]  R861      1.0879338532686234e-01
    z[1,4,4]  R862      1.5406674146652222e-01
    z[1,4,4]  R863      -2.7404522895812988e-01
    z[1,4,4]  R864      -1.9865857902914286e-03
    z[1,4,4]  R865      1.0958957672119141e-01
    z[1,4,4]  R866      -1.0130358487367630e-01
    z[1,4,4]  R867      -1.6682930290699005e-01
    z[1,4,4]  R868      -1.9122330844402313e-01
    z[1,4,4]  R869      -1.1914963275194168e-01
    z[1,4,4]  R870      -2.1009781956672668e-01
    z[1,4,4]  R871      -4.1547951102256775e-01
    z[1,4,4]  R872      3.2895419280976057e-03
    z[1,4,4]  R873      6.3411749899387360e-02
    z[1,4,4]  R874      2.6501941680908203e-01
    z[1,4,4]  R875      -9.0105690062046051e-02
    z[1,4,4]  R876      2.3578166961669922e-01
    z[1,4,4]  R877      -2.0581318438053131e-01
    z[1,4,4]  R878      -1.5405574440956116e-01
    z[1,4,4]  R879      -4.6345052123069763e-01
    z[1,4,4]  R880      -1.7371930181980133e-01
    z[1,4,4]  R881      1.5203894674777985e-01
    z[1,4,4]  R882      -1.7029793560504913e-01
    z[1,4,4]  R883      -1.4309158921241760e-01
    z[1,4,4]  R884      6.5895318984985352e-02
    z[1,4,4]  R885      -8.9322596788406372e-02
    z[1,4,4]  R886      6.9609411060810089e-02
    z[1,4,4]  R887      3.4623327851295471e-01
    z[1,4,4]  R888      -4.7948709130287170e-01
    z[1,4,4]  R889      -6.1006331443786621e-01
    z[1,4,4]  R890      8.7079212069511414e-02
    z[1,4,4]  R891      4.4583201408386230e-01
    z[1,4,4]  R892      3.1959778070449829e-01
    z[1,4,4]  R893      -0.0889601856470108
    z[1,4,4]  R894      -4.1677546501159668e-01
    z[1,4,4]  R895      1.6093716025352478e-01
    z[1,4,4]  R896      2.8899261355400085e-01
    z[1,4,4]  R897      -6.7880898714065552e-01
    z[1,4,4]  R898      2.3162260651588440e-01
    z[1,4,4]  R899      -4.2658692598342896e-01
    z[1,4,4]  R900      3.7110611796379089e-02
    z[1,4,4]  R901      0.253608763217926
    z[1,4,4]  R902      -3.0783239006996155e-01
    z[1,4,4]  R903      8.0141127109527588e-02
    z[1,4,4]  R904      2.8608945012092590e-01
    z[1,4,4]  R905      -3.0059763230383396e-03
    z[1,4,4]  R906      3.0319327116012573e-01
    z[1,4,4]  R907      -4.4815093278884888e-01
    z[1,4,4]  R908      1.0846333205699921e-01
    z[1,4,4]  R909      -2.5771671533584595e-01
    z[1,4,4]  R910      7.1807242929935455e-02
    z[1,4,4]  R911      3.1035497784614563e-01
    z[1,4,4]  R912      3.9208721369504929e-02
    z[1,4,4]  R913      -4.1954988241195679e-01
    z[1,4,4]  R914      3.2510882616043091e-01
    z[1,4,4]  R915      3.0939370393753052e-01
    z[1,4,4]  R916      1.0399816930294037e-01
    z[1,4,4]  R917      -3.2380643486976624e-01
    z[1,4,4]  R918      -4.3692804872989655e-02
    z[1,4,4]  R919      3.5460570454597473e-01
    z[1,4,4]  R920      -1.2773409485816956e-01
    z[1,4,4]  R921      -9.9731072783470154e-02
    z[1,4,4]  R922      2.4622483551502228e-01
    z[1,4,4]  R923      4.0934920310974121e-01
    z[1,4,4]  R924      -2.5437366962432861e-01
    z[1,4,4]  R925      3.4494414925575256e-02
    z[1,4,4]  R926      3.8776747882366180e-02
    z[1,4,4]  R927      -2.2928847372531891e-01
    z[1,4,4]  R928      7.2756119072437286e-02
    z[1,4,4]  R929      -5.0857514142990112e-01
    z[1,4,4]  R930      2.7385911345481873e-01
    z[1,4,4]  R931      3.0575612187385559e-01
    z[1,4,4]  R932      2.1467334032058716e-01
    z[1,4,4]  R933      1.6659593582153320e-01
    z[1,4,4]  R934      6.6348105669021606e-01
    z[1,4,4]  R935      -7.7274434268474579e-02
    z[1,4,4]  R936      5.2379506826400757e-01
    z[1,4,4]  R937      2.8799173235893250e-01
    z[1,4,4]  R938      -1.4048458635807037e-01
    z[1,4,4]  R939      -1.8486697971820831e-01
    z[1,4,4]  R940      2.1070814132690430e-01
    z[1,4,4]  R941      -2.4036785587668419e-02
    z[1,4,4]  R942      3.0900094658136368e-02
    z[1,4,4]  R943      1.7191524803638458e-01
    z[1,4,4]  R944      0.0910961776971817
    z[1,4,4]  R945      2.3283807933330536e-01
    z[1,4,4]  R946      0.0839817002415657
    z[1,4,4]  R947      4.7030895948410034e-02
    z[1,4,4]  R948      2.6917797327041626e-01
    z[1,4,4]  R949      -2.2383768856525421e-01
    z[1,4,4]  R950      2.5361141562461853e-01
    z[1,4,4]  R951      5.5442094802856445e-01
    z[1,4,4]  R952      5.7248443365097046e-01
    z[1,4,4]  R953      -0.470795214176178
    z[1,4,4]  R954      4.7683233022689819e-01
    z[1,4,4]  R955      4.5888155698776245e-01
    z[1,4,4]  R956      1.3239391148090363e-01
    z[1,4,4]  R957      2.6018369942903519e-02
    z[1,4,4]  R958      -2.6247984170913696e-01
    z[1,4,4]  R959      -2.6960924267768860e-01
    z[1,4,4]  R960      2.5080201029777527e-01
    z[1,4,4]  R961      3.7362700700759888e-01
    z[1,4,4]  R962      -1.7409019637852907e-03
    z[1,4,4]  R963      -2.4190691113471985e-01
    z[1,4,4]  R964      5.1489669084548950e-01
    z[1,4,4]  R965      -1.8420583009719849e-01
    z[1,4,4]  R966      -1.3304264843463898e-01
    z[1,4,4]  R967      3.0345159769058228e-01
    z[1,4,4]  R968      4.6785643696784973e-01
    z[1,4,4]  R969      -9.7694151103496552e-02
    z[1,4,4]  R970      6.8273797631263733e-02
    z[1,4,4]  R971      -2.1637508273124695e-01
    z[1,4,4]  R972      2.2672414779663086e-01
    z[1,4,4]  R973      -1.3508158922195435e-01
    z[1,4,4]  R974      1.2351201474666595e-01
    z[1,4,4]  R975      -1.2425804138183594e-01
    z[1,4,4]  R976      -2.5327226519584656e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R823      -1
    z[1,4,5]  R824      1
    z[1,4,5]  R827      -2.0066772401332855e-01
    z[1,4,5]  R828      -5.9441626071929932e-02
    z[1,4,5]  R829      2.7653029561042786e-01
    z[1,4,5]  R830      5.4726753383874893e-02
    z[1,4,5]  R831      3.3891800791025162e-02
    z[1,4,5]  R832      3.3521682024002075e-01
    z[1,4,5]  R833      -1.5599071979522705e-01
    z[1,4,5]  R834      2.5600078515708447e-03
    z[1,4,5]  R835      3.7962925434112549e-01
    z[1,4,5]  R836      1.4176584780216217e-01
    z[1,4,5]  R837      -5.8701831102371216e-01
    z[1,4,5]  R838      -1.1679384857416153e-01
    z[1,4,5]  R839      -3.2678428292274475e-01
    z[1,4,5]  R840      -5.0479900836944580e-01
    z[1,4,5]  R841      -4.6577075123786926e-01
    z[1,4,5]  R842      -1.2833803892135620e-01
    z[1,4,5]  R843      -1.1914358288049698e-01
    z[1,4,5]  R844      -7.5452238321304321e-02
    z[1,4,5]  R845      1.5624926984310150e-01
    z[1,4,5]  R846      -2.7592654805630445e-03
    z[1,4,5]  R847      3.9353662729263306e-01
    z[1,4,5]  R848      -4.4771060347557068e-01
    z[1,4,5]  R849      -2.4050267040729523e-01
    z[1,4,5]  R850      -5.0918138027191162e-01
    z[1,4,5]  R851      2.8002321720123291e-01
    z[1,4,5]  R852      -0.0396539680659771
    z[1,4,5]  R853      -3.9080310612916946e-02
    z[1,4,5]  R854      -1.9320229068398476e-02
    z[1,4,5]  R855      -1.4455287717282772e-02
    z[1,4,5]  R856      -1.0613378137350082e-01
    z[1,4,5]  R857      -4.5793151855468750e-01
    z[1,4,5]  R858      -1.9242644309997559e-01
    z[1,4,5]  R859      -5.7479149103164673e-01
    z[1,4,5]  R860      -1.8723320960998535e-01
    z[1,4,5]  R861      -2.7032741904258728e-01
    z[1,4,5]  R862      4.8314131796360016e-02
    z[1,4,5]  R863      -2.3204919416457415e-03
    z[1,4,5]  R864      -1.4920058846473694e-01
    z[1,4,5]  R865      -3.3517464995384216e-01
    z[1,4,5]  R866      -3.0391353368759155e-01
    z[1,4,5]  R867      -0.567290186882019
    z[1,4,5]  R868      -4.7096580266952515e-01
    z[1,4,5]  R869      -2.8467962145805359e-01
    z[1,4,5]  R870      -4.5613187551498413e-01
    z[1,4,5]  R871      -3.7316355109214783e-01
    z[1,4,5]  R872      -4.9113425612449646e-01
    z[1,4,5]  R873      -2.2501760721206665e-01
    z[1,4,5]  R874      -4.5422890782356262e-01
    z[1,4,5]  R875      -1.9683602452278137e-01
    z[1,4,5]  R876      -7.4810914695262909e-02
    z[1,4,5]  R877      5.5614137649536133e-01
    z[1,4,5]  R878      4.6744874119758606e-01
    z[1,4,5]  R879      3.0523526668548584e-01
    z[1,4,5]  R880      -4.0307754278182983e-01
    z[1,4,5]  R881      6.4861392602324486e-03
    z[1,4,5]  R882      -3.5454906523227692e-02
    z[1,4,5]  R883      1.2842306494712830e-01
    z[1,4,5]  R884      1.4541678130626678e-01
    z[1,4,5]  R885      1.6680285334587097e-01
    z[1,4,5]  R886      8.6275503039360046e-02
    z[1,4,5]  R887      -8.8976975530385971e-03
    z[1,4,5]  R888      4.5235604047775269e-01
    z[1,4,5]  R889      3.6717417836189270e-01
    z[1,4,5]  R890      -6.2057387083768845e-02
    z[1,4,5]  R891      1.4026379585266113e-01
    z[1,4,5]  R892      -8.7293386459350586e-02
    z[1,4,5]  R893      2.5280052423477173e-01
    z[1,4,5]  R894      1.5615834295749664e-01
    z[1,4,5]  R895      -1.2509214878082275e-01
    z[1,4,5]  R896      2.4431882798671722e-01
    z[1,4,5]  R897      3.5856953263282776e-01
    z[1,4,5]  R898      5.8395403623580933e-01
    z[1,4,5]  R899      2.4112163484096527e-01
    z[1,4,5]  R900      2.9454326629638672e-01
    z[1,4,5]  R901      3.1561228632926941e-01
    z[1,4,5]  R902      -1.8078792095184326e-01
    z[1,4,5]  R903      -2.5250095129013062e-01
    z[1,4,5]  R904      1.8632566928863525e-01
    z[1,4,5]  R905      -4.3672680854797363e-01
    z[1,4,5]  R906      -8.9058600366115570e-02
    z[1,4,5]  R907      4.4784566760063171e-01
    z[1,4,5]  R908      0.425496906042099
    z[1,4,5]  R909      3.2415258884429932e-01
    z[1,4,5]  R910      -1.6619232296943665e-01
    z[1,4,5]  R911      -2.3024032998364419e-04
    z[1,4,5]  R912      -2.1188246086239815e-02
    z[1,4,5]  R913      -4.2546260356903076e-01
    z[1,4,5]  R914      -3.7626194953918457e-01
    z[1,4,5]  R915      -1.1377550661563873e-02
    z[1,4,5]  R916      -1.3964809477329254e-01
    z[1,4,5]  R917      4.3637013435363770e-01
    z[1,4,5]  R918      5.8601337671279907e-01
    z[1,4,5]  R919      1.8636810779571533e-01
    z[1,4,5]  R920      2.5316748023033142e-01
    z[1,4,5]  R921      1.7170919477939606e-01
    z[1,4,5]  R922      3.3964416384696960e-01
    z[1,4,5]  R923      -2.2880868613719940e-01
    z[1,4,5]  R924      -3.0514645576477051e-01
    z[1,4,5]  R925      -3.9614114910364151e-02
    z[1,4,5]  R926      -1.1986841447651386e-02
    z[1,4,5]  R927      -1.8737922608852386e-01
    z[1,4,5]  R928      2.9761362075805664e-01
    z[1,4,5]  R929      -1.4091113209724426e-01
    z[1,4,5]  R930      -2.1088285744190216e-01
    z[1,4,5]  R931      -1.4867080748081207e-01
    z[1,4,5]  R932      -1.5140730142593384e-01
    z[1,4,5]  R933      7.3399171233177185e-02
    z[1,4,5]  R934      -1.3731801509857178e-01
    z[1,4,5]  R935      -2.1077500283718109e-01
    z[1,4,5]  R936      -4.1861617565155029e-01
    z[1,4,5]  R937      1.5950110554695129e-01
    z[1,4,5]  R938      3.1426626443862915e-01
    z[1,4,5]  R939      6.6431082785129547e-02
    z[1,4,5]  R940      4.6235236525535583e-01
    z[1,4,5]  R941      -1.1576903052628040e-02
    z[1,4,5]  R942      -7.8274980187416077e-02
    z[1,4,5]  R943      -3.7693977355957031e-01
    z[1,4,5]  R944      4.1850835084915161e-02
    z[1,4,5]  R945      6.0755524784326553e-02
    z[1,4,5]  R946      -1.1820632964372635e-02
    z[1,4,5]  R947      5.8419197797775269e-02
    z[1,4,5]  R948      -4.5930200815200806e-01
    z[1,4,5]  R949      1.8721137195825577e-02
    z[1,4,5]  R950      -4.5784667134284973e-01
    z[1,4,5]  R951      -1.4388071000576019e-01
    z[1,4,5]  R952      0.082222118973732
    z[1,4,5]  R953      1.2622365355491638e-01
    z[1,4,5]  R954      -2.6503092050552368e-01
    z[1,4,5]  R955      -3.6509260535240173e-01
    z[1,4,5]  R956      -1.9301755726337433e-01
    z[1,4,5]  R957      2.3834304511547089e-01
    z[1,4,5]  R958      3.6902558803558350e-01
    z[1,4,5]  R959      3.8425880670547485e-01
    z[1,4,5]  R960      -4.2244362831115723e-01
    z[1,4,5]  R961      2.0742814987897873e-02
    z[1,4,5]  R962      0.0847427025437355
    z[1,4,5]  R963      1.6116046905517578e-01
    z[1,4,5]  R964      -3.4456923604011536e-01
    z[1,4,5]  R965      -5.1498931646347046e-01
    z[1,4,5]  R966      -2.9532846808433533e-01
    z[1,4,5]  R967      -3.2721281051635742e-01
    z[1,4,5]  R968      -5.4802145808935165e-02
    z[1,4,5]  R969      2.5784159079194069e-02
    z[1,4,5]  R970      -3.3183619379997253e-01
    z[1,4,5]  R971      -9.4814337790012360e-02
    z[1,4,5]  R972      -3.2409057021141052e-01
    z[1,4,5]  R973      -3.0177587270736694e-01
    z[1,4,5]  R974      -3.4313338994979858e-01
    z[1,4,5]  R975      -2.3594951629638672e-01
    z[1,4,5]  R976      -3.2928720116615295e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R825      -1
    z[1,4,6]  R826      1
    z[1,4,6]  R827      -2.4560314416885376e-01
    z[1,4,6]  R828      -8.6249615997076035e-03
    z[1,4,6]  R829      4.5009684562683105e-01
    z[1,4,6]  R830      8.4467105567455292e-02
    z[1,4,6]  R831      3.5163056850433350e-01
    z[1,4,6]  R832      1.7577911913394928e-01
    z[1,4,6]  R833      1.4857438392937183e-02
    z[1,4,6]  R834      -5.3883910179138184e-01
    z[1,4,6]  R835      -0.0820883959531784
    z[1,4,6]  R836      -2.7637362480163574e-01
    z[1,4,6]  R837      -1.2720239348709583e-02
    z[1,4,6]  R838      -7.6829922199249268e-01
    z[1,4,6]  R839      -5.1832711696624756e-01
    z[1,4,6]  R840      3.2919490337371826e-01
    z[1,4,6]  R841      -7.9426631331443787e-02
    z[1,4,6]  R842      -8.2022309303283691e-02
    z[1,4,6]  R843      1.7222639173269272e-02
    z[1,4,6]  R844      -2.2025832533836365e-01
    z[1,4,6]  R845      -1.8181389570236206e-01
    z[1,4,6]  R846      -0.0487905852496624
    z[1,4,6]  R847      -6.4627546072006226e-01
    z[1,4,6]  R848      -9.0783812105655670e-02
    z[1,4,6]  R849      -2.0084077119827271e-01
    z[1,4,6]  R850      2.7500659227371216e-01
    z[1,4,6]  R851      0.0792355015873909
    z[1,4,6]  R852      2.6192107796669006e-01
    z[1,4,6]  R853      -1.4711722731590271e-01
    z[1,4,6]  R854      0.0408710315823555
    z[1,4,6]  R855      -1.4940334856510162e-01
    z[1,4,6]  R856      7.1755279786884785e-03
    z[1,4,6]  R857      1.7631410062313080e-01
    z[1,4,6]  R858      -3.2058694958686829e-01
    z[1,4,6]  R859      4.4458872079849243e-01
    z[1,4,6]  R860      6.3253903388977051e-01
    z[1,4,6]  R861      -2.7765689417719841e-02
    z[1,4,6]  R862      5.8352392166852951e-02
    z[1,4,6]  R863      1.5340046584606171e-01
    z[1,4,6]  R864      -1.0635794699192047e-01
    z[1,4,6]  R865      2.2697240114212036e-01
    z[1,4,6]  R866      3.6155867576599121e-01
    z[1,4,6]  R867      -1.1409967392683029e-01
    z[1,4,6]  R868      1.8631061911582947e-01
    z[1,4,6]  R869      1.5505558252334595e-01
    z[1,4,6]  R870      -9.4230905175209045e-02
    z[1,4,6]  R871      8.8811673223972321e-02
    z[1,4,6]  R872      -5.4144892841577530e-02
    z[1,4,6]  R873      -3.6406937241554260e-01
    z[1,4,6]  R874      2.2296257317066193e-01
    z[1,4,6]  R875      -4.3690085411071777e-01
    z[1,4,6]  R876      -0.284881055355072
    z[1,4,6]  R877      2.3958197236061096e-01
    z[1,4,6]  R878      -2.3904012143611908e-01
    z[1,4,6]  R879      -1.1963321268558502e-01
    z[1,4,6]  R880      -4.6805106103420258e-02
    z[1,4,6]  R881      -1.7740327119827271e-01
    z[1,4,6]  R882      3.9852154254913330e-01
    z[1,4,6]  R883      -1.7968656122684479e-01
    z[1,4,6]  R884      -5.7249772548675537e-01
    z[1,4,6]  R885      -6.5263003110885620e-01
    z[1,4,6]  R886      -2.8091764450073242e-01
    z[1,4,6]  R887      1.6536907851696014e-01
    z[1,4,6]  R888      -3.8747996091842651e-01
    z[1,4,6]  R889      -3.6879444122314453e-01
    z[1,4,6]  R890      7.8969156742095947e-01
    z[1,4,6]  R891      -2.0165938138961792e-01
    z[1,4,6]  R892      -1.3785080611705780e-01
    z[1,4,6]  R893      0.332021564245224
    z[1,4,6]  R894      8.9740976691246033e-02
    z[1,4,6]  R895      -1.3271878659725189e-01
    z[1,4,6]  R896      2.6851412653923035e-01
    z[1,4,6]  R897      -4.4646671414375305e-01
    z[1,4,6]  R898      3.5155513882637024e-01
    z[1,4,6]  R899      9.7187506034970284e-03
    z[1,4,6]  R900      -3.9079171419143677e-01
    z[1,4,6]  R901      -1.6757705807685852e-01
    z[1,4,6]  R902      -2.3581512272357941e-02
    z[1,4,6]  R903      4.8792776465415955e-01
    z[1,4,6]  R904      5.0658807158470154e-02
    z[1,4,6]  R905      4.8480924963951111e-01
    z[1,4,6]  R906      -2.5699833035469055e-01
    z[1,4,6]  R907      6.6792696714401245e-02
    z[1,4,6]  R908      2.0928496122360229e-01
    z[1,4,6]  R909      -6.2918695621192455e-03
    z[1,4,6]  R910      0.377238005399704
    z[1,4,6]  R911      3.1086388230323792e-01
    z[1,4,6]  R912      -1.9821390509605408e-01
    z[1,4,6]  R913      -1.8849206389859319e-03
    z[1,4,6]  R914      5.9384290128946304e-02
    z[1,4,6]  R915      -9.6629941835999489e-03
    z[1,4,6]  R916      1.4050062000751495e-01
    z[1,4,6]  R917      -2.0856364071369171e-01
    z[1,4,6]  R918      1.5194277465343475e-01
    z[1,4,6]  R919      1.9492205977439880e-01
    z[1,4,6]  R920      -3.1650376319885254e-01
    z[1,4,6]  R921      -2.8207591176033020e-01
    z[1,4,6]  R922      -2.5937798619270325e-01
    z[1,4,6]  R923      -2.2709725797176361e-01
    z[1,4,6]  R924      -1.5670976042747498e-01
    z[1,4,6]  R925      -1.8955725431442261e-01
    z[1,4,6]  R926      -1.1056371033191681e-01
    z[1,4,6]  R927      1.5578483045101166e-01
    z[1,4,6]  R928      -3.3971226215362549e-01
    z[1,4,6]  R929      2.9629576206207275e-01
    z[1,4,6]  R930      -1.7692670226097107e-01
    z[1,4,6]  R931      1.2157399207353592e-01
    z[1,4,6]  R932      -8.9330114424228668e-02
    z[1,4,6]  R933      -1.0918104648590088e-01
    z[1,4,6]  R934      2.1212534606456757e-01
    z[1,4,6]  R935      -0.00732843903824687
    z[1,4,6]  R936      -1.8028123676776886e-01
    z[1,4,6]  R937      5.8017671108245850e-01
    z[1,4,6]  R938      1.7972312867641449e-02
    z[1,4,6]  R939      -4.0665301680564880e-01
    z[1,4,6]  R940      1.0987018793821335e-01
    z[1,4,6]  R941      6.1497384309768677e-01
    z[1,4,6]  R942      -3.0301022529602051e-01
    z[1,4,6]  R943      2.1675251424312592e-02
    z[1,4,6]  R944      8.7226778268814087e-02
    z[1,4,6]  R945      2.8561198711395264e-01
    z[1,4,6]  R946      4.3371358513832092e-01
    z[1,4,6]  R947      1.3211207091808319e-01
    z[1,4,6]  R948      -4.1308730840682983e-01
    z[1,4,6]  R949      -1.3268908485770226e-02
    z[1,4,6]  R950      -9.4475768506526947e-02
    z[1,4,6]  R951      1.4035947620868683e-01
    z[1,4,6]  R952      1.2068077921867371e-01
    z[1,4,6]  R953      2.5822622701525688e-02
    z[1,4,6]  R954      3.6570936441421509e-01
    z[1,4,6]  R955      4.2769372463226318e-01
    z[1,4,6]  R956      -8.2987926900386810e-02
    z[1,4,6]  R957      -2.1248523890972137e-01
    z[1,4,6]  R958      4.3469882011413574e-01
    z[1,4,6]  R959      2.6805743575096130e-01
    z[1,4,6]  R960      -1.0324721783399582e-01
    z[1,4,6]  R961      2.3308119177818298e-01
    z[1,4,6]  R962      -1.6491647064685822e-01
    z[1,4,6]  R963      -1.6455566883087158e-01
    z[1,4,6]  R964      -6.8455703556537628e-02
    z[1,4,6]  R965      -2.2133512794971466e-01
    z[1,4,6]  R966      -9.1432582121342421e-04
    z[1,4,6]  R967      -0.0773564875125885
    z[1,4,6]  R968      1.6218551993370056e-01
    z[1,4,6]  R969      -9.9893517792224884e-02
    z[1,4,6]  R970      -1.7724396288394928e-01
    z[1,4,6]  R971      3.0140149593353271e-01
    z[1,4,6]  R972      5.6753152608871460e-01
    z[1,4,6]  R973      -1.5236841142177582e-01
    z[1,4,6]  R974      4.0906123816967010e-02
    z[1,4,6]  R975      -3.5598453134298325e-02
    z[1,4,6]  R976      1.6011761128902435e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R977      -1
    z[4,1,0]  R978      1
    z[4,1,0]  R991      -5.8755654096603394e-01
    z[4,1,0]  R992      -0.550112783908844
    z[4,1,0]  R993      -5.7592475414276123e-01
    z[4,1,0]  R994      -6.1626744270324707e-01
    z[4,1,0]  R995      -5.3182321786880493e-01
    z[4,1,0]  R996      -6.7129796743392944e-01
    z[4,1,0]  R997      -6.7024582624435425e-01
    z[4,1,0]  R998      -5.8671534061431885e-01
    z[4,1,0]  R999      -6.3573414087295532e-01
    z[4,1,0]  R1000     -7.6984459161758423e-01
    z[4,1,0]  R1001     2.2927865386009216e-01
    z[4,1,0]  R1002     6.8313342332839966e-01
    z[4,1,0]  R1003     7.1734535694122314e-01
    z[4,1,0]  R1004     -3.7486594915390015e-01
    z[4,1,0]  R1005     4.1173495352268219e-02
    z[4,1,0]  R1006     2.9657664895057678e-01
    z[4,1,0]  R1007     1.4933685958385468e-01
    z[4,1,0]  R1008     4.7259172797203064e-01
    z[4,1,0]  R1009     5.5157589912414551e-01
    z[4,1,0]  R1010     4.6082824468612671e-01
    z[4,1,0]  R1011     -1.1115819215774536e-01
    z[4,1,0]  R1012     -1.2880751863121986e-02
    z[4,1,0]  R1013     5.5273931473493576e-02
    z[4,1,0]  R1014     1.4118523895740509e-01
    z[4,1,0]  R1015     6.4345401525497437e-01
    z[4,1,0]  R1016     0.0411706306040287
    z[4,1,0]  R1017     2.1051850169897079e-02
    z[4,1,0]  R1018     3.9216777682304382e-01
    z[4,1,0]  R1019     3.2847228646278381e-01
    z[4,1,0]  R1020     -0.0661325603723526
    z[4,1,0]  R1021     1.6047385288402438e-03
    z[4,1,0]  R1022     1.1611460894346237e-01
    z[4,1,0]  R1023     2.0121926069259644e-01
    z[4,1,0]  R1024     -2.7605935931205750e-01
    z[4,1,0]  R1025     5.7087254524230957e-01
    z[4,1,0]  R1026     0.534482479095459
    z[4,1,0]  R1027     5.3874176740646362e-01
    z[4,1,0]  R1028     6.4456933736801147e-01
    z[4,1,0]  R1029     -2.6294299960136414e-01
    z[4,1,0]  R1030     1.6433918476104736e-01
    z[4,1,0]  R1031     9.2788405716419220e-02
    z[4,1,0]  R1032     8.6532514542341232e-03
    z[4,1,0]  R1033     -5.0115205347537994e-02
    z[4,1,0]  R1034     8.6147910356521606e-01
    z[4,1,0]  R1035     4.8253032565116882e-01
    z[4,1,0]  R1036     7.4361699819564819e-01
    z[4,1,0]  R1037     7.0720338821411133e-01
    z[4,1,0]  R1038     1.0208169370889664e-01
    z[4,1,0]  R1039     1.2148441374301910e-01
    z[4,1,0]  R1040     -1.1865770816802979e-01
    z[4,1,0]  R1041     -1.4550159871578217e-01
    z[4,1,0]  R1042     -3.6517471075057983e-02
    z[4,1,0]  R1043     -2.0804883539676666e-01
    z[4,1,0]  R1044     3.9359282702207565e-02
    z[4,1,0]  R1045     6.9649285078048706e-01
    z[4,1,0]  R1046     7.3793154954910278e-01
    z[4,1,0]  R1047     6.9981509447097778e-01
    z[4,1,0]  R1048     8.4909921884536743e-01
    z[4,1,0]  R1049     2.7244171500205994e-01
    z[4,1,0]  R1050     0.168548122048378
    z[4,1,0]  R1051     6.9429796934127808e-01
    z[4,1,0]  R1052     6.7381465435028076e-01
    z[4,1,0]  R1053     7.3634153604507446e-01
    z[4,1,0]  R1054     6.1560302972793579e-01
    z[4,1,0]  R1055     2.6052442193031311e-01
    z[4,1,0]  R1056     -1.2880542874336243e-01
    z[4,1,0]  R1057     -1.2372874468564987e-01
    z[4,1,0]  R1058     2.1286159753799438e-01
    z[4,1,0]  R1059     5.8649146556854248e-01
    z[4,1,0]  R1060     -1.5846298635005951e-01
    z[4,1,0]  R1061     -8.1728391349315643e-02
    z[4,1,0]  R1062     6.9623565673828125e-01
    z[4,1,0]  R1063     7.5372809171676636e-01
    z[4,1,0]  R1064     6.9946563243865967e-01
    z[4,1,0]  R1065     6.5266388654708862e-01
    z[4,1,0]  R1066     8.8066416978836060e-01
    z[4,1,0]  R1067     0.0986173152923584
    z[4,1,0]  R1068     -0.0824391320347786
    z[4,1,0]  R1069     1.0335975885391235e-01
    z[4,1,0]  R1070     -1.2979520484805107e-02
    z[4,1,0]  R1071     -0.0978812426328659
    z[4,1,0]  R1072     -4.1288039088249207e-01
    z[4,1,0]  R1073     -4.5653238892555237e-01
    z[4,1,0]  R1074     6.8289393186569214e-01
    z[4,1,0]  R1075     2.8496208786964417e-01
    z[4,1,0]  R1076     -1.0464946739375591e-02
    z[4,1,0]  R1077     1.7132751643657684e-01
    z[4,1,0]  R1078     -2.8915578126907349e-01
    z[4,1,0]  R1079     -2.0504486560821533e-01
    z[4,1,0]  R1080     3.2287436723709106e-01
    z[4,1,0]  R1081     0.789137065410614
    z[4,1,0]  R1082     7.2498601675033569e-01
    z[4,1,0]  R1083     7.4532598257064819e-01
    z[4,1,0]  R1084     7.3198574781417847e-01
    z[4,1,0]  R1085     -9.2089831829071045e-02
    z[4,1,0]  R1086     -7.7427178621292114e-02
    z[4,1,0]  R1087     1.8897749483585358e-01
    z[4,1,0]  R1088     4.4966783374547958e-02
    z[4,1,0]  R1089     4.8142012953758240e-01
    z[4,1,0]  R1090     6.7377209663391113e-01
    z[4,1,0]  R1091     7.4083232879638672e-01
    z[4,1,0]  R1092     5.7815268635749817e-02
    z[4,1,0]  R1093     2.0731888711452484e-01
    z[4,1,0]  R1094     1.8512832000851631e-02
    z[4,1,0]  R1095     3.2425409555435181e-01
    z[4,1,0]  R1096     2.0348079502582550e-01
    z[4,1,0]  R1097     5.5700516700744629e-01
    z[4,1,0]  R1098     4.3710514903068542e-01
    z[4,1,0]  R1099     5.9524399042129517e-01
    z[4,1,0]  R1100     4.2955505847930908e-01
    z[4,1,0]  R1101     1.0895483195781708e-01
    z[4,1,0]  R1102     0.0934840589761734
    z[4,1,0]  R1103     3.0696392059326172e-01
    z[4,1,0]  R1104     -2.8118395805358887e-01
    z[4,1,0]  R1105     -2.0352919399738312e-01
    z[4,1,0]  R1106     2.3840183019638062e-01
    z[4,1,0]  R1107     6.5376496315002441e-01
    z[4,1,0]  R1108     7.3611110448837280e-02
    z[4,1,0]  R1109     6.6353899240493774e-01
    z[4,1,0]  R1110     -2.6388000696897507e-03
    z[4,1,0]  R1111     -1.3830715417861938e-01
    z[4,1,0]  R1112     1.3887564837932587e-01
    z[4,1,0]  R1113     -3.9402008056640625e-02
    z[4,1,0]  R1114     -5.8835762739181519e-01
    z[4,1,0]  R1115     1.6388840973377228e-02
    z[4,1,0]  R1116     -4.1222300380468369e-02
    z[4,1,0]  R1117     2.8189649805426598e-02
    z[4,1,0]  R1118     -1.3297820091247559e-01
    z[4,1,0]  R1119     -0.200653538107872
    z[4,1,0]  R1120     -1.1196637898683548e-01
    z[4,1,0]  R1121     7.7385380864143372e-02
    z[4,1,0]  R1122     -9.9324166774749756e-02
    z[4,1,0]  R1123     -3.5108867287635803e-01
    z[4,1,0]  R1124     -6.3792335987091064e-01
    z[4,1,0]  R1125     7.3212879896163940e-01
    z[4,1,0]  R1126     4.4521890580654144e-02
    z[4,1,0]  R1127     1.0701041668653488e-01
    z[4,1,0]  R1128     8.5760957002639771e-01
    z[4,1,0]  R1129     6.5180635452270508e-01
    z[4,1,0]  R1130     7.6279711723327637e-01
    z[4,1,0]  R1131     2.7415168285369873e-01
    z[4,1,0]  R1132     -0.303154855966568
    z[4,1,0]  R1133     -0.588360071182251
    z[4,1,0]  R1134     -3.6815574765205383e-01
    z[4,1,0]  R1135     1.2681372463703156e-01
    z[4,1,0]  R1136     -9.6772246062755585e-02
    z[4,1,0]  R1137     -1.7005759477615356e-01
    z[4,1,0]  R1138     -1.2802829733118415e-03
    z[4,1,0]  R1139     -5.3634065389633179e-01
    z[4,1,0]  R1140     -5.5998134613037109e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R979      -1
    z[4,1,1]  R980      1
    z[4,1,1]  R991      -3.5023787617683411e-01
    z[4,1,1]  R992      -2.5114196538925171e-01
    z[4,1,1]  R993      -3.5928779840469360e-01
    z[4,1,1]  R994      -2.9726028442382812e-01
    z[4,1,1]  R995      -5.5615627765655518e-01
    z[4,1,1]  R996      -5.1980084180831909e-01
    z[4,1,1]  R997      -4.0141481161117554e-01
    z[4,1,1]  R998      -2.5546005368232727e-01
    z[4,1,1]  R999      -0.32403364777565
    z[4,1,1]  R1000     -2.9785001277923584e-01
    z[4,1,1]  R1001     -7.1147876977920532e-01
    z[4,1,1]  R1002     -4.6179959177970886e-01
    z[4,1,1]  R1003     -3.7745356559753418e-01
    z[4,1,1]  R1004     7.5218003988265991e-01
    z[4,1,1]  R1005     -5.3693801164627075e-01
    z[4,1,1]  R1006     -6.2811189889907837e-01
    z[4,1,1]  R1007     -7.1127003431320190e-01
    z[4,1,1]  R1008     -4.3059056997299194e-01
    z[4,1,1]  R1009     -4.5296445488929749e-01
    z[4,1,1]  R1010     -4.9211472272872925e-01
    z[4,1,1]  R1011     -6.8705797195434570e-01
    z[4,1,1]  R1012     -3.8977241516113281e-01
    z[4,1,1]  R1013     7.1482799947261810e-02
    z[4,1,1]  R1014     -5.5262351036071777e-01
    z[4,1,1]  R1015     -5.0978618860244751e-01
    z[4,1,1]  R1016     7.4618428945541382e-01
    z[4,1,1]  R1017     8.8835489749908447e-01
    z[4,1,1]  R1018     -1.7341756820678711e-01
    z[4,1,1]  R1019     8.2127535343170166e-01
    z[4,1,1]  R1020     -0.522761881351471
    z[4,1,1]  R1021     -2.8531920909881592e-01
    z[4,1,1]  R1022     -5.0097370147705078e-01
    z[4,1,1]  R1023     -5.6872421503067017e-01
    z[4,1,1]  R1024     -4.4913262128829956e-01
    z[4,1,1]  R1025     -5.8296936750411987e-01
    z[4,1,1]  R1026     -5.0831443071365356e-01
    z[4,1,1]  R1027     -4.9253699183464050e-01
    z[4,1,1]  R1028     -1.8199425935745239e-01
    z[4,1,1]  R1029     5.9212136268615723e-01
    z[4,1,1]  R1030     8.6953115463256836e-01
    z[4,1,1]  R1031     -2.9620343446731567e-01
    z[4,1,1]  R1032     -8.4968489408493042e-01
    z[4,1,1]  R1033     -5.1040691137313843e-01
    z[4,1,1]  R1034     -2.2170072793960571e-01
    z[4,1,1]  R1035     -5.4525840282440186e-01
    z[4,1,1]  R1036     -1.0907662659883499e-01
    z[4,1,1]  R1037     -2.1314503252506256e-01
    z[4,1,1]  R1038     8.4723156690597534e-01
    z[4,1,1]  R1039     0.880919337272644
    z[4,1,1]  R1040     7.2155517339706421e-01
    z[4,1,1]  R1041     -0.628449022769928
    z[4,1,1]  R1042     -7.0719486474990845e-01
    z[4,1,1]  R1043     -8.2792568206787109e-01
    z[4,1,1]  R1044     -7.3079919815063477e-01
    z[4,1,1]  R1045     -6.0353887081146240e-01
    z[4,1,1]  R1046     -1.8426091969013214e-01
    z[4,1,1]  R1047     -4.6042034029960632e-01
    z[4,1,1]  R1048     -8.7848186492919922e-02
    z[4,1,1]  R1049     0.886595606803894
    z[4,1,1]  R1050     9.6384423971176147e-01
    z[4,1,1]  R1051     -4.5259761810302734e-01
    z[4,1,1]  R1052     -2.2987347841262817e-01
    z[4,1,1]  R1053     -0.301234632730484
    z[4,1,1]  R1054     -1.4728754758834839e-01
    z[4,1,1]  R1055     8.4514260292053223e-01
    z[4,1,1]  R1056     8.3458983898162842e-01
    z[4,1,1]  R1057     9.0441882610321045e-01
    z[4,1,1]  R1058     5.4224532842636108e-01
    z[4,1,1]  R1059     4.8052567243576050e-01
    z[4,1,1]  R1060     4.5277449488639832e-01
    z[4,1,1]  R1061     -0.736034631729126
    z[4,1,1]  R1062     -0.50221848487854
    z[4,1,1]  R1063     -2.9484912753105164e-01
    z[4,1,1]  R1064     -3.2997876405715942e-01
    z[4,1,1]  R1065     -3.0022957921028137e-01
    z[4,1,1]  R1066     -0.0613643079996109
    z[4,1,1]  R1067     8.3372437953948975e-01
    z[4,1,1]  R1068     0.959001362323761
    z[4,1,1]  R1069     8.2865160703659058e-01
    z[4,1,1]  R1070     8.6359906196594238e-01
    z[4,1,1]  R1071     -7.7929478883743286e-01
    z[4,1,1]  R1072     5.7339859008789062e-01
    z[4,1,1]  R1073     7.7785891294479370e-01
    z[4,1,1]  R1074     -0.228417307138443
    z[4,1,1]  R1075     6.4570468664169312e-01
    z[4,1,1]  R1076     0.749077558517456
    z[4,1,1]  R1077     7.8521335124969482e-01
    z[4,1,1]  R1078     6.2177753448486328e-01
    z[4,1,1]  R1079     5.0166165828704834e-01
    z[4,1,1]  R1080     6.4847087860107422e-01
    z[4,1,1]  R1081     -5.2170819044113159e-01
    z[4,1,1]  R1082     -2.6020979881286621e-01
    z[4,1,1]  R1083     -1.6403673589229584e-01
    z[4,1,1]  R1084     -2.5790682435035706e-01
    z[4,1,1]  R1085     7.9363530874252319e-01
    z[4,1,1]  R1086     9.5412641763687134e-01
    z[4,1,1]  R1087     9.1491103172302246e-01
    z[4,1,1]  R1088     0.478773295879364
    z[4,1,1]  R1089     0.548701286315918
    z[4,1,1]  R1090     6.0121679306030273e-01
    z[4,1,1]  R1091     -1.6934056580066681e-01
    z[4,1,1]  R1092     8.2446902990341187e-01
    z[4,1,1]  R1093     9.6358984708786011e-01
    z[4,1,1]  R1094     6.5812236070632935e-01
    z[4,1,1]  R1095     7.1535408496856689e-01
    z[4,1,1]  R1096     5.4849225282669067e-01
    z[4,1,1]  R1097     7.1080332994461060e-01
    z[4,1,1]  R1098     7.2019606828689575e-01
    z[4,1,1]  R1099     0.670100748538971
    z[4,1,1]  R1100     0.737332820892334
    z[4,1,1]  R1101     -4.6671545505523682e-01
    z[4,1,1]  R1102     -1.3359937071800232e-01
    z[4,1,1]  R1103     -5.4755187034606934e-01
    z[4,1,1]  R1104     -4.5454701781272888e-01
    z[4,1,1]  R1105     8.2258599996566772e-01
    z[4,1,1]  R1106     8.3536797761917114e-01
    z[4,1,1]  R1107     6.0298210382461548e-01
    z[4,1,1]  R1108     6.8687140941619873e-01
    z[4,1,1]  R1109     2.5713574886322021e-01
    z[4,1,1]  R1110     8.2437044382095337e-01
    z[4,1,1]  R1111     -6.3565254211425781e-01
    z[4,1,1]  R1112     -2.6428091526031494e-01
    z[4,1,1]  R1113     -3.4266650676727295e-01
    z[4,1,1]  R1114     1.7891493439674377e-01
    z[4,1,1]  R1115     -8.8861101539805532e-04
    z[4,1,1]  R1116     7.3406648635864258e-01
    z[4,1,1]  R1117     7.5357919931411743e-01
    z[4,1,1]  R1118     0.777441143989563
    z[4,1,1]  R1119     8.4087914228439331e-01
    z[4,1,1]  R1120     6.7594271898269653e-01
    z[4,1,1]  R1121     -3.0124077200889587e-01
    z[4,1,1]  R1122     -3.4512379765510559e-01
    z[4,1,1]  R1123     -7.5806662440299988e-02
    z[4,1,1]  R1124     1.4388592541217804e-01
    z[4,1,1]  R1125     5.3881222009658813e-01
    z[4,1,1]  R1126     8.3683592081069946e-01
    z[4,1,1]  R1127     8.5966998338699341e-01
    z[4,1,1]  R1128     3.2006371021270752e-01
    z[4,1,1]  R1129     5.7017904520034790e-01
    z[4,1,1]  R1130     5.0148993730545044e-01
    z[4,1,1]  R1131     -3.6733394861221313e-01
    z[4,1,1]  R1132     3.8637730479240417e-01
    z[4,1,1]  R1133     5.2368111908435822e-02
    z[4,1,1]  R1134     1.3667643070220947e-01
    z[4,1,1]  R1135     7.8310316801071167e-01
    z[4,1,1]  R1136     9.3387198448181152e-01
    z[4,1,1]  R1137     7.3081928491592407e-01
    z[4,1,1]  R1138     6.8152934312820435e-01
    z[4,1,1]  R1139     7.1633970737457275e-01
    z[4,1,1]  R1140     6.6614228487014771e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R981      -1
    z[4,1,2]  R982      1
    z[4,1,2]  R991      -1.9520850479602814e-01
    z[4,1,2]  R992      9.2998119071125984e-03
    z[4,1,2]  R993      -5.1382946968078613e-01
    z[4,1,2]  R994      1.9087596237659454e-01
    z[4,1,2]  R995      -1.3207024335861206e-01
    z[4,1,2]  R996      -1.5683691203594208e-01
    z[4,1,2]  R997      -3.3692610263824463e-01
    z[4,1,2]  R998      -2.0341442525386810e-01
    z[4,1,2]  R999      9.9804960191249847e-02
    z[4,1,2]  R1000     6.1308752745389938e-02
    z[4,1,2]  R1001     -2.7224181219935417e-02
    z[4,1,2]  R1002     1.4349375665187836e-01
    z[4,1,2]  R1003     -1.2734179198741913e-01
    z[4,1,2]  R1004     -2.1428765356540680e-01
    z[4,1,2]  R1005     7.2389543056488037e-01
    z[4,1,2]  R1006     5.6075859069824219e-01
    z[4,1,2]  R1007     4.6849995851516724e-01
    z[4,1,2]  R1008     -3.2706481218338013e-01
    z[4,1,2]  R1009     9.1979922726750374e-03
    z[4,1,2]  R1010     -5.4430490732192993e-01
    z[4,1,2]  R1011     5.6827646493911743e-01
    z[4,1,2]  R1012     -5.1286339759826660e-01
    z[4,1,2]  R1013     -0.46903195977211
    z[4,1,2]  R1014     1.9012993574142456e-01
    z[4,1,2]  R1015     -2.2154814004898071e-01
    z[4,1,2]  R1016     5.2097213268280029e-01
    z[4,1,2]  R1017     -1.8444817513227463e-02
    z[4,1,2]  R1018     6.6841256618499756e-01
    z[4,1,2]  R1019     3.9735755324363708e-01
    z[4,1,2]  R1020     -5.5841112136840820e-01
    z[4,1,2]  R1021     -1.5113285183906555e-01
    z[4,1,2]  R1022     1.7867620289325714e-01
    z[4,1,2]  R1023     5.4607796669006348e-01
    z[4,1,2]  R1024     -5.6303566694259644e-01
    z[4,1,2]  R1025     -3.3601748943328857e-01
    z[4,1,2]  R1026     -1.7890906333923340e-01
    z[4,1,2]  R1027     -1.4444294571876526e-01
    z[4,1,2]  R1028     -0.652751088142395
    z[4,1,2]  R1029     -3.9298117160797119e-01
    z[4,1,2]  R1030     9.1285429894924164e-02
    z[4,1,2]  R1031     -0.668785572052002
    z[4,1,2]  R1032     1.9610232114791870e-01
    z[4,1,2]  R1033     -7.2156423330307007e-01
    z[4,1,2]  R1034     1.7301666736602783e-01
    z[4,1,2]  R1035     -3.2959020137786865e-01
    z[4,1,2]  R1036     1.7456393688917160e-02
    z[4,1,2]  R1037     2.7208173274993896e-01
    z[4,1,2]  R1038     1.0649657994508743e-01
    z[4,1,2]  R1039     -0.0938347652554512
    z[4,1,2]  R1040     4.1236659884452820e-01
    z[4,1,2]  R1041     -0.494943231344223
    z[4,1,2]  R1042     -1.2691226601600647e-01
    z[4,1,2]  R1043     5.0492975860834122e-02
    z[4,1,2]  R1044     4.7204467654228210e-01
    z[4,1,2]  R1045     -8.4907226264476776e-02
    z[4,1,2]  R1046     -1.3565035164356232e-01
    z[4,1,2]  R1047     1.6225245594978333e-01
    z[4,1,2]  R1048     -1.5981492400169373e-01
    z[4,1,2]  R1049     0.0615328773856163
    z[4,1,2]  R1050     1.6760799288749695e-01
    z[4,1,2]  R1051     -1.1647468805313110e-01
    z[4,1,2]  R1052     2.5308451056480408e-01
    z[4,1,2]  R1053     -2.0218318328261375e-02
    z[4,1,2]  R1054     0.582478940486908
    z[4,1,2]  R1055     2.9166597127914429e-01
    z[4,1,2]  R1056     4.5439252257347107e-01
    z[4,1,2]  R1057     2.3995140194892883e-01
    z[4,1,2]  R1058     1.7692428827285767e-01
    z[4,1,2]  R1059     3.7672752141952515e-01
    z[4,1,2]  R1060     1.2909972667694092e-01
    z[4,1,2]  R1061     6.1129800975322723e-02
    z[4,1,2]  R1062     4.1504953987896442e-03
    z[4,1,2]  R1063     3.5807663202285767e-01
    z[4,1,2]  R1064     1.4697174727916718e-01
    z[4,1,2]  R1065     -2.2409553825855255e-01
    z[4,1,2]  R1066     -1.0674206167459488e-01
    z[4,1,2]  R1067     2.6567617058753967e-01
    z[4,1,2]  R1068     1.8880042433738708e-01
    z[4,1,2]  R1069     3.4775212407112122e-01
    z[4,1,2]  R1070     -0.073155976831913
    z[4,1,2]  R1071     5.9725141525268555e-01
    z[4,1,2]  R1072     -9.0044438838958740e-02
    z[4,1,2]  R1073     3.5335725545883179e-01
    z[4,1,2]  R1074     -4.3700179457664490e-01
    z[4,1,2]  R1075     2.0539747178554535e-01
    z[4,1,2]  R1076     2.1612955629825592e-01
    z[4,1,2]  R1077     3.0064875259995461e-02
    z[4,1,2]  R1078     2.0245923101902008e-01
    z[4,1,2]  R1079     2.1178799867630005e-01
    z[4,1,2]  R1080     -3.9450940489768982e-01
    z[4,1,2]  R1081     4.3772339820861816e-02
    z[4,1,2]  R1082     -4.0393903851509094e-02
    z[4,1,2]  R1083     9.4932131469249725e-02
    z[4,1,2]  R1084     -3.7179183959960938e-01
    z[4,1,2]  R1085     2.8107839822769165e-01
    z[4,1,2]  R1086     1.8511307239532471e-01
    z[4,1,2]  R1087     -1.2274567782878876e-01
    z[4,1,2]  R1088     1.3293507695198059e-01
    z[4,1,2]  R1089     2.1158735454082489e-01
    z[4,1,2]  R1090     -5.7536359876394272e-02
    z[4,1,2]  R1091     3.7202858924865723e-01
    z[4,1,2]  R1092     2.4892997741699219e-01
    z[4,1,2]  R1093     6.7938235588371754e-03
    z[4,1,2]  R1094     2.5844931602478027e-01
    z[4,1,2]  R1095     1.1316926218569279e-02
    z[4,1,2]  R1096     6.3249832019209862e-03
    z[4,1,2]  R1097     -2.2752940654754639e-01
    z[4,1,2]  R1098     -3.5796791315078735e-01
    z[4,1,2]  R1099     -2.9539284110069275e-01
    z[4,1,2]  R1100     -1.9871445000171661e-01
    z[4,1,2]  R1101     -4.8679551482200623e-01
    z[4,1,2]  R1102     3.6904752254486084e-02
    z[4,1,2]  R1103     7.8874669969081879e-02
    z[4,1,2]  R1104     -2.1364346146583557e-01
    z[4,1,2]  R1105     1.3000316917896271e-01
    z[4,1,2]  R1106     -1.4253102242946625e-01
    z[4,1,2]  R1107     -8.2498893141746521e-02
    z[4,1,2]  R1108     3.2142437994480133e-02
    z[4,1,2]  R1109     2.2951868176460266e-01
    z[4,1,2]  R1110     -1.9364626705646515e-01
    z[4,1,2]  R1111     4.1217097640037537e-01
    z[4,1,2]  R1112     1.3405339419841766e-01
    z[4,1,2]  R1113     -2.9808761551976204e-02
    z[4,1,2]  R1114     -4.6589165925979614e-01
    z[4,1,2]  R1115     9.4442255795001984e-02
    z[4,1,2]  R1116     1.6268730163574219e-01
    z[4,1,2]  R1117     4.9862369894981384e-02
    z[4,1,2]  R1118     2.4379999935626984e-01
    z[4,1,2]  R1119     1.8106689676642418e-02
    z[4,1,2]  R1120     2.1392691135406494e-01
    z[4,1,2]  R1121     -6.2701150774955750e-02
    z[4,1,2]  R1122     -2.3533287644386292e-01
    z[4,1,2]  R1123     -2.0075348019599915e-01
    z[4,1,2]  R1124     -4.6012011170387268e-01
    z[4,1,2]  R1125     2.8811085224151611e-01
    z[4,1,2]  R1126     2.3537848889827728e-01
    z[4,1,2]  R1127     3.6041319370269775e-01
    z[4,1,2]  R1128     3.1767565011978149e-01
    z[4,1,2]  R1129     4.6150788664817810e-01
    z[4,1,2]  R1130     3.1205204129219055e-01
    z[4,1,2]  R1131     3.9079514145851135e-01
    z[4,1,2]  R1132     -4.7543495893478394e-01
    z[4,1,2]  R1133     -3.3568689227104187e-01
    z[4,1,2]  R1134     -0.611609697341919
    z[4,1,2]  R1135     3.3169406652450562e-01
    z[4,1,2]  R1136     1.8586735427379608e-01
    z[4,1,2]  R1137     1.6468927264213562e-01
    z[4,1,2]  R1138     4.8190999031066895e-01
    z[4,1,2]  R1139     1.5249325335025787e-01
    z[4,1,2]  R1140     1.0341267101466656e-02
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R983      -1
    z[4,1,3]  R984      1
    z[4,1,3]  R991      -3.6240240931510925e-01
    z[4,1,3]  R992      -5.8406364917755127e-01
    z[4,1,3]  R993      -3.9486807584762573e-01
    z[4,1,3]  R994      -4.8408702015876770e-01
    z[4,1,3]  R995      -2.6580053567886353e-01
    z[4,1,3]  R996      -1.0204381495714188e-01
    z[4,1,3]  R997      -2.9818978905677795e-01
    z[4,1,3]  R998      -4.7207662463188171e-01
    z[4,1,3]  R999      -4.9308976531028748e-01
    z[4,1,3]  R1000     -4.1535407304763794e-01
    z[4,1,3]  R1001     -1.7730298638343811e-01
    z[4,1,3]  R1002     9.8836747929453850e-03
    z[4,1,3]  R1003     6.6793225705623627e-02
    z[4,1,3]  R1004     2.3008877038955688e-01
    z[4,1,3]  R1005     3.6241963505744934e-01
    z[4,1,3]  R1006     1.1827819049358368e-01
    z[4,1,3]  R1007     4.2783892154693604e-01
    z[4,1,3]  R1008     0.361988365650177
    z[4,1,3]  R1009     1.6963206231594086e-01
    z[4,1,3]  R1010     3.9747819304466248e-01
    z[4,1,3]  R1011     2.1296314895153046e-01
    z[4,1,3]  R1012     1.4430669136345387e-02
    z[4,1,3]  R1013     -3.5894379019737244e-01
    z[4,1,3]  R1014     -5.8972876518964767e-02
    z[4,1,3]  R1015     -1.3377124071121216e-01
    z[4,1,3]  R1016     2.0331309735774994e-01
    z[4,1,3]  R1017     1.6727812588214874e-01
    z[4,1,3]  R1018     -4.0399852395057678e-01
    z[4,1,3]  R1019     -2.3591844365000725e-02
    z[4,1,3]  R1020     4.4183173775672913e-01
    z[4,1,3]  R1021     -3.2720467448234558e-01
    z[4,1,3]  R1022     -4.3055215477943420e-01
    z[4,1,3]  R1023     -3.1249335408210754e-01
    z[4,1,3]  R1024     0.405229389667511
    z[4,1,3]  R1025     1.7126889526844025e-01
    z[4,1,3]  R1026     5.4399931430816650e-01
    z[4,1,3]  R1027     3.7154817581176758e-01
    z[4,1,3]  R1028     -7.8700542449951172e-02
    z[4,1,3]  R1029     -6.3104387372732162e-03
    z[4,1,3]  R1030     2.0656596124172211e-01
    z[4,1,3]  R1031     -2.2475211322307587e-01
    z[4,1,3]  R1032     -5.3780917078256607e-02
    z[4,1,3]  R1033     2.1162706613540649e-01
    z[4,1,3]  R1034     -6.0689233243465424e-02
    z[4,1,3]  R1035     4.1020902991294861e-01
    z[4,1,3]  R1036     -6.2734061479568481e-01
    z[4,1,3]  R1037     -1.5283970534801483e-01
    z[4,1,3]  R1038     9.8189562559127808e-02
    z[4,1,3]  R1039     3.2321885228157043e-01
    z[4,1,3]  R1040     0.495151162147522
    z[4,1,3]  R1041     -1.1997682973742485e-02
    z[4,1,3]  R1042     -3.3768004179000854e-01
    z[4,1,3]  R1043     2.6501366496086121e-01
    z[4,1,3]  R1044     2.4692660570144653e-01
    z[4,1,3]  R1045     1.5630787611007690e-01
    z[4,1,3]  R1046     -3.9980259537696838e-01
    z[4,1,3]  R1047     2.1275892853736877e-02
    z[4,1,3]  R1048     -2.5178197026252747e-01
    z[4,1,3]  R1049     3.1184336543083191e-01
    z[4,1,3]  R1050     2.5135293602943420e-02
    z[4,1,3]  R1051     4.3311214447021484e-01
    z[4,1,3]  R1052     -4.6883741021156311e-01
    z[4,1,3]  R1053     1.8819957971572876e-02
    z[4,1,3]  R1054     -3.3058160543441772e-01
    z[4,1,3]  R1055     4.9212433397769928e-02
    z[4,1,3]  R1056     5.8376058936119080e-02
    z[4,1,3]  R1057     2.5313809514045715e-01
    z[4,1,3]  R1058     3.5397332906723022e-01
    z[4,1,3]  R1059     4.8243951797485352e-01
    z[4,1,3]  R1060     0.520687997341156
    z[4,1,3]  R1061     -5.3401719778776169e-02
    z[4,1,3]  R1062     3.7972751259803772e-01
    z[4,1,3]  R1063     -1.1306407302618027e-01
    z[4,1,3]  R1064     -3.3169585466384888e-01
    z[4,1,3]  R1065     2.3402684926986694e-01
    z[4,1,3]  R1066     -3.3222606778144836e-01
    z[4,1,3]  R1067     2.2909869253635406e-01
    z[4,1,3]  R1068     1.4218333363533020e-01
    z[4,1,3]  R1069     2.0553000271320343e-01
    z[4,1,3]  R1070     2.3103292286396027e-01
    z[4,1,3]  R1071     -5.7719651609659195e-02
    z[4,1,3]  R1072     1.9641692936420441e-01
    z[4,1,3]  R1073     1.0498762130737305e-01
    z[4,1,3]  R1074     8.7422579526901245e-02
    z[4,1,3]  R1075     0.33449786901474
    z[4,1,3]  R1076     2.0736102759838104e-01
    z[4,1,3]  R1077     3.3902138471603394e-01
    z[4,1,3]  R1078     -2.3966248333454132e-01
    z[4,1,3]  R1079     3.6694878339767456e-01
    z[4,1,3]  R1080     -5.0786721706390381e-01
    z[4,1,3]  R1081     -2.3085476830601692e-02
    z[4,1,3]  R1082     1.0495626181364059e-01
    z[4,1,3]  R1083     -3.4113073348999023e-01
    z[4,1,3]  R1084     8.6206562817096710e-02
    z[4,1,3]  R1085     2.9715862870216370e-01
    z[4,1,3]  R1086     1.2247022241353989e-01
    z[4,1,3]  R1087     -2.4262189865112305e-02
    z[4,1,3]  R1088     6.0212099552154541e-01
    z[4,1,3]  R1089     2.7250188589096069e-01
    z[4,1,3]  R1090     2.7629515528678894e-01
    z[4,1,3]  R1091     -2.8098204731941223e-01
    z[4,1,3]  R1092     8.2127936184406281e-02
    z[4,1,3]  R1093     9.0992741286754608e-02
    z[4,1,3]  R1094     5.9459584951400757e-01
    z[4,1,3]  R1095     4.8615738749504089e-01
    z[4,1,3]  R1096     4.2329812049865723e-01
    z[4,1,3]  R1097     1.4226980507373810e-02
    z[4,1,3]  R1098     -1.6567033529281616e-01
    z[4,1,3]  R1099     -1.9238793849945068e-01
    z[4,1,3]  R1100     -1.8471808731555939e-01
    z[4,1,3]  R1101     1.4971904456615448e-01
    z[4,1,3]  R1102     5.6009536981582642e-01
    z[4,1,3]  R1103     1.2469938024878502e-02
    z[4,1,3]  R1104     6.5791660547256470e-01
    z[4,1,3]  R1105     -3.6636710166931152e-01
    z[4,1,3]  R1106     -2.0004889369010925e-01
    z[4,1,3]  R1107     3.1147342920303345e-01
    z[4,1,3]  R1108     -4.0973043441772461e-01
    z[4,1,3]  R1109     -5.1095658540725708e-01
    z[4,1,3]  R1110     -3.7618669867515564e-01
    z[4,1,3]  R1111     0.0747021734714508
    z[4,1,3]  R1112     -4.3851667642593384e-01
    z[4,1,3]  R1113     -5.4049533605575562e-01
    z[4,1,3]  R1114     -1.6657525300979614e-01
    z[4,1,3]  R1115     -8.6760473251342773e-01
    z[4,1,3]  R1116     -0.604107141494751
    z[4,1,3]  R1117     -6.4292007684707642e-01
    z[4,1,3]  R1118     -3.9882490038871765e-01
    z[4,1,3]  R1119     -3.9741331338882446e-01
    z[4,1,3]  R1120     -5.5144232511520386e-01
    z[4,1,3]  R1121     3.6425283551216125e-01
    z[4,1,3]  R1122     -6.6679733991622925e-01
    z[4,1,3]  R1123     -6.8822938203811646e-01
    z[4,1,3]  R1124     -5.6779447942972183e-02
    z[4,1,3]  R1125     7.2429150342941284e-02
    z[4,1,3]  R1126     -3.6378815770149231e-01
    z[4,1,3]  R1127     -3.0981072783470154e-01
    z[4,1,3]  R1128     -2.4286228418350220e-01
    z[4,1,3]  R1129     -4.7408733516931534e-02
    z[4,1,3]  R1130     1.5245880186557770e-01
    z[4,1,3]  R1131     -6.2550747394561768e-01
    z[4,1,3]  R1132     -5.9744048118591309e-01
    z[4,1,3]  R1133     -3.2809905707836151e-02
    z[4,1,3]  R1134     -1.4084091782569885e-01
    z[4,1,3]  R1135     -4.1828554868698120e-01
    z[4,1,3]  R1136     -2.3344330489635468e-01
    z[4,1,3]  R1137     -5.5787372589111328e-01
    z[4,1,3]  R1138     -5.1932847499847412e-01
    z[4,1,3]  R1139     8.5775060579180717e-03
    z[4,1,3]  R1140     -9.6009470522403717e-02
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R985      -1
    z[4,1,4]  R986      1
    z[4,1,4]  R991      -1.6682930290699005e-01
    z[4,1,4]  R992      -1.9122330844402313e-01
    z[4,1,4]  R993      -1.1914963275194168e-01
    z[4,1,4]  R994      -2.1009781956672668e-01
    z[4,1,4]  R995      -4.1547951102256775e-01
    z[4,1,4]  R996      3.2895419280976057e-03
    z[4,1,4]  R997      6.3411749899387360e-02
    z[4,1,4]  R998      2.6501941680908203e-01
    z[4,1,4]  R999      -9.0105690062046051e-02
    z[4,1,4]  R1000     2.3578166961669922e-01
    z[4,1,4]  R1001     -2.0581318438053131e-01
    z[4,1,4]  R1002     -1.5405574440956116e-01
    z[4,1,4]  R1003     -4.6345052123069763e-01
    z[4,1,4]  R1004     -1.7371930181980133e-01
    z[4,1,4]  R1005     1.5203894674777985e-01
    z[4,1,4]  R1006     -1.7029793560504913e-01
    z[4,1,4]  R1007     -1.4309158921241760e-01
    z[4,1,4]  R1008     6.5895318984985352e-02
    z[4,1,4]  R1009     -8.9322596788406372e-02
    z[4,1,4]  R1010     6.9609411060810089e-02
    z[4,1,4]  R1011     3.4623327851295471e-01
    z[4,1,4]  R1012     -4.7948709130287170e-01
    z[4,1,4]  R1013     -6.1006331443786621e-01
    z[4,1,4]  R1014     8.7079212069511414e-02
    z[4,1,4]  R1015     4.4583201408386230e-01
    z[4,1,4]  R1016     3.1959778070449829e-01
    z[4,1,4]  R1017     -0.0889601856470108
    z[4,1,4]  R1018     -4.1677546501159668e-01
    z[4,1,4]  R1019     1.6093716025352478e-01
    z[4,1,4]  R1020     2.8899261355400085e-01
    z[4,1,4]  R1021     -6.7880898714065552e-01
    z[4,1,4]  R1022     2.3162260651588440e-01
    z[4,1,4]  R1023     -4.2658692598342896e-01
    z[4,1,4]  R1024     3.7110611796379089e-02
    z[4,1,4]  R1025     0.253608763217926
    z[4,1,4]  R1026     -3.0783239006996155e-01
    z[4,1,4]  R1027     8.0141127109527588e-02
    z[4,1,4]  R1028     2.8608945012092590e-01
    z[4,1,4]  R1029     -3.0059763230383396e-03
    z[4,1,4]  R1030     3.0319327116012573e-01
    z[4,1,4]  R1031     -4.4815093278884888e-01
    z[4,1,4]  R1032     1.0846333205699921e-01
    z[4,1,4]  R1033     -2.5771671533584595e-01
    z[4,1,4]  R1034     7.1807242929935455e-02
    z[4,1,4]  R1035     3.1035497784614563e-01
    z[4,1,4]  R1036     3.9208721369504929e-02
    z[4,1,4]  R1037     -4.1954988241195679e-01
    z[4,1,4]  R1038     3.2510882616043091e-01
    z[4,1,4]  R1039     3.0939370393753052e-01
    z[4,1,4]  R1040     1.0399816930294037e-01
    z[4,1,4]  R1041     -3.2380643486976624e-01
    z[4,1,4]  R1042     -4.3692804872989655e-02
    z[4,1,4]  R1043     3.5460570454597473e-01
    z[4,1,4]  R1044     -1.2773409485816956e-01
    z[4,1,4]  R1045     -9.9731072783470154e-02
    z[4,1,4]  R1046     2.4622483551502228e-01
    z[4,1,4]  R1047     4.0934920310974121e-01
    z[4,1,4]  R1048     -2.5437366962432861e-01
    z[4,1,4]  R1049     3.4494414925575256e-02
    z[4,1,4]  R1050     3.8776747882366180e-02
    z[4,1,4]  R1051     -2.2928847372531891e-01
    z[4,1,4]  R1052     7.2756119072437286e-02
    z[4,1,4]  R1053     -5.0857514142990112e-01
    z[4,1,4]  R1054     2.7385911345481873e-01
    z[4,1,4]  R1055     3.0575612187385559e-01
    z[4,1,4]  R1056     2.1467334032058716e-01
    z[4,1,4]  R1057     1.6659593582153320e-01
    z[4,1,4]  R1058     6.6348105669021606e-01
    z[4,1,4]  R1059     -7.7274434268474579e-02
    z[4,1,4]  R1060     5.2379506826400757e-01
    z[4,1,4]  R1061     2.8799173235893250e-01
    z[4,1,4]  R1062     -1.4048458635807037e-01
    z[4,1,4]  R1063     -1.8486697971820831e-01
    z[4,1,4]  R1064     2.1070814132690430e-01
    z[4,1,4]  R1065     -2.4036785587668419e-02
    z[4,1,4]  R1066     3.0900094658136368e-02
    z[4,1,4]  R1067     1.7191524803638458e-01
    z[4,1,4]  R1068     0.0910961776971817
    z[4,1,4]  R1069     2.3283807933330536e-01
    z[4,1,4]  R1070     0.0839817002415657
    z[4,1,4]  R1071     4.7030895948410034e-02
    z[4,1,4]  R1072     2.6917797327041626e-01
    z[4,1,4]  R1073     -2.2383768856525421e-01
    z[4,1,4]  R1074     2.5361141562461853e-01
    z[4,1,4]  R1075     5.5442094802856445e-01
    z[4,1,4]  R1076     5.7248443365097046e-01
    z[4,1,4]  R1077     -0.470795214176178
    z[4,1,4]  R1078     4.7683233022689819e-01
    z[4,1,4]  R1079     4.5888155698776245e-01
    z[4,1,4]  R1080     1.3239391148090363e-01
    z[4,1,4]  R1081     2.6018369942903519e-02
    z[4,1,4]  R1082     -2.6247984170913696e-01
    z[4,1,4]  R1083     -2.6960924267768860e-01
    z[4,1,4]  R1084     2.5080201029777527e-01
    z[4,1,4]  R1085     3.7362700700759888e-01
    z[4,1,4]  R1086     -1.7409019637852907e-03
    z[4,1,4]  R1087     -2.4190691113471985e-01
    z[4,1,4]  R1088     5.1489669084548950e-01
    z[4,1,4]  R1089     -1.8420583009719849e-01
    z[4,1,4]  R1090     -1.3304264843463898e-01
    z[4,1,4]  R1091     3.0345159769058228e-01
    z[4,1,4]  R1092     4.6785643696784973e-01
    z[4,1,4]  R1093     -9.7694151103496552e-02
    z[4,1,4]  R1094     6.8273797631263733e-02
    z[4,1,4]  R1095     -2.1637508273124695e-01
    z[4,1,4]  R1096     2.2672414779663086e-01
    z[4,1,4]  R1097     -1.3508158922195435e-01
    z[4,1,4]  R1098     1.2351201474666595e-01
    z[4,1,4]  R1099     -1.2425804138183594e-01
    z[4,1,4]  R1100     -2.5327226519584656e-01
    z[4,1,4]  R1101     6.4057117700576782e-01
    z[4,1,4]  R1102     8.0915719270706177e-01
    z[4,1,4]  R1103     -5.6615126132965088e-01
    z[4,1,4]  R1104     -4.7507378458976746e-01
    z[4,1,4]  R1105     -0.077522411942482
    z[4,1,4]  R1106     -2.0425860583782196e-01
    z[4,1,4]  R1107     -2.8395134210586548e-01
    z[4,1,4]  R1108     -2.5203731656074524e-01
    z[4,1,4]  R1109     1.7024983465671539e-01
    z[4,1,4]  R1110     -2.1192273497581482e-01
    z[4,1,4]  R1111     -2.3790630698204041e-01
    z[4,1,4]  R1112     -3.1093001365661621e-01
    z[4,1,4]  R1113     -4.6103402972221375e-01
    z[4,1,4]  R1114     -1.1760532110929489e-01
    z[4,1,4]  R1115     -1.2174691259860992e-01
    z[4,1,4]  R1116     2.1174573898315430e-01
    z[4,1,4]  R1117     3.1613189727067947e-02
    z[4,1,4]  R1118     -3.2433861494064331e-01
    z[4,1,4]  R1119     -1.9215957820415497e-01
    z[4,1,4]  R1120     -4.2228358983993530e-01
    z[4,1,4]  R1121     -4.4058007001876831e-01
    z[4,1,4]  R1122     -4.0291124582290649e-01
    z[4,1,4]  R1123     -5.0877290964126587e-01
    z[4,1,4]  R1124     -1.5007355809211731e-01
    z[4,1,4]  R1125     -2.6901068165898323e-02
    z[4,1,4]  R1126     -1.9950826466083527e-01
    z[4,1,4]  R1127     2.1566031500697136e-02
    z[4,1,4]  R1128     -1.1014854535460472e-02
    z[4,1,4]  R1129     -1.1080067604780197e-01
    z[4,1,4]  R1130     -0.186312735080719
    z[4,1,4]  R1131     0.0716809555888176
    z[4,1,4]  R1132     -1.8982166051864624e-01
    z[4,1,4]  R1133     -9.6350491046905518e-02
    z[4,1,4]  R1134     -1.2929193675518036e-01
    z[4,1,4]  R1135     1.0879338532686234e-01
    z[4,1,4]  R1136     1.5406674146652222e-01
    z[4,1,4]  R1137     -2.7404522895812988e-01
    z[4,1,4]  R1138     -1.9865857902914286e-03
    z[4,1,4]  R1139     1.0958957672119141e-01
    z[4,1,4]  R1140     -1.0130358487367630e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R987      -1
    z[4,1,5]  R988      1
    z[4,1,5]  R991      -0.567290186882019
    z[4,1,5]  R992      -4.7096580266952515e-01
    z[4,1,5]  R993      -2.8467962145805359e-01
    z[4,1,5]  R994      -4.5613187551498413e-01
    z[4,1,5]  R995      -3.7316355109214783e-01
    z[4,1,5]  R996      -4.9113425612449646e-01
    z[4,1,5]  R997      -2.2501760721206665e-01
    z[4,1,5]  R998      -4.5422890782356262e-01
    z[4,1,5]  R999      -1.9683602452278137e-01
    z[4,1,5]  R1000     -7.4810914695262909e-02
    z[4,1,5]  R1001     5.5614137649536133e-01
    z[4,1,5]  R1002     4.6744874119758606e-01
    z[4,1,5]  R1003     3.0523526668548584e-01
    z[4,1,5]  R1004     -4.0307754278182983e-01
    z[4,1,5]  R1005     6.4861392602324486e-03
    z[4,1,5]  R1006     -3.5454906523227692e-02
    z[4,1,5]  R1007     1.2842306494712830e-01
    z[4,1,5]  R1008     1.4541678130626678e-01
    z[4,1,5]  R1009     1.6680285334587097e-01
    z[4,1,5]  R1010     8.6275503039360046e-02
    z[4,1,5]  R1011     -8.8976975530385971e-03
    z[4,1,5]  R1012     4.5235604047775269e-01
    z[4,1,5]  R1013     3.6717417836189270e-01
    z[4,1,5]  R1014     -6.2057387083768845e-02
    z[4,1,5]  R1015     1.4026379585266113e-01
    z[4,1,5]  R1016     -8.7293386459350586e-02
    z[4,1,5]  R1017     2.5280052423477173e-01
    z[4,1,5]  R1018     1.5615834295749664e-01
    z[4,1,5]  R1019     -1.2509214878082275e-01
    z[4,1,5]  R1020     2.4431882798671722e-01
    z[4,1,5]  R1021     3.5856953263282776e-01
    z[4,1,5]  R1022     5.8395403623580933e-01
    z[4,1,5]  R1023     2.4112163484096527e-01
    z[4,1,5]  R1024     2.9454326629638672e-01
    z[4,1,5]  R1025     3.1561228632926941e-01
    z[4,1,5]  R1026     -1.8078792095184326e-01
    z[4,1,5]  R1027     -2.5250095129013062e-01
    z[4,1,5]  R1028     1.8632566928863525e-01
    z[4,1,5]  R1029     -4.3672680854797363e-01
    z[4,1,5]  R1030     -8.9058600366115570e-02
    z[4,1,5]  R1031     4.4784566760063171e-01
    z[4,1,5]  R1032     0.425496906042099
    z[4,1,5]  R1033     3.2415258884429932e-01
    z[4,1,5]  R1034     -1.6619232296943665e-01
    z[4,1,5]  R1035     -2.3024032998364419e-04
    z[4,1,5]  R1036     -2.1188246086239815e-02
    z[4,1,5]  R1037     -4.2546260356903076e-01
    z[4,1,5]  R1038     -3.7626194953918457e-01
    z[4,1,5]  R1039     -1.1377550661563873e-02
    z[4,1,5]  R1040     -1.3964809477329254e-01
    z[4,1,5]  R1041     4.3637013435363770e-01
    z[4,1,5]  R1042     5.8601337671279907e-01
    z[4,1,5]  R1043     1.8636810779571533e-01
    z[4,1,5]  R1044     2.5316748023033142e-01
    z[4,1,5]  R1045     1.7170919477939606e-01
    z[4,1,5]  R1046     3.3964416384696960e-01
    z[4,1,5]  R1047     -2.2880868613719940e-01
    z[4,1,5]  R1048     -3.0514645576477051e-01
    z[4,1,5]  R1049     -3.9614114910364151e-02
    z[4,1,5]  R1050     -1.1986841447651386e-02
    z[4,1,5]  R1051     -1.8737922608852386e-01
    z[4,1,5]  R1052     2.9761362075805664e-01
    z[4,1,5]  R1053     -1.4091113209724426e-01
    z[4,1,5]  R1054     -2.1088285744190216e-01
    z[4,1,5]  R1055     -1.4867080748081207e-01
    z[4,1,5]  R1056     -1.5140730142593384e-01
    z[4,1,5]  R1057     7.3399171233177185e-02
    z[4,1,5]  R1058     -1.3731801509857178e-01
    z[4,1,5]  R1059     -2.1077500283718109e-01
    z[4,1,5]  R1060     -4.1861617565155029e-01
    z[4,1,5]  R1061     1.5950110554695129e-01
    z[4,1,5]  R1062     3.1426626443862915e-01
    z[4,1,5]  R1063     6.6431082785129547e-02
    z[4,1,5]  R1064     4.6235236525535583e-01
    z[4,1,5]  R1065     -1.1576903052628040e-02
    z[4,1,5]  R1066     -7.8274980187416077e-02
    z[4,1,5]  R1067     -3.7693977355957031e-01
    z[4,1,5]  R1068     4.1850835084915161e-02
    z[4,1,5]  R1069     6.0755524784326553e-02
    z[4,1,5]  R1070     -1.1820632964372635e-02
    z[4,1,5]  R1071     5.8419197797775269e-02
    z[4,1,5]  R1072     -4.5930200815200806e-01
    z[4,1,5]  R1073     1.8721137195825577e-02
    z[4,1,5]  R1074     -4.5784667134284973e-01
    z[4,1,5]  R1075     -1.4388071000576019e-01
    z[4,1,5]  R1076     0.082222118973732
    z[4,1,5]  R1077     1.2622365355491638e-01
    z[4,1,5]  R1078     -2.6503092050552368e-01
    z[4,1,5]  R1079     -3.6509260535240173e-01
    z[4,1,5]  R1080     -1.9301755726337433e-01
    z[4,1,5]  R1081     2.3834304511547089e-01
    z[4,1,5]  R1082     3.6902558803558350e-01
    z[4,1,5]  R1083     3.8425880670547485e-01
    z[4,1,5]  R1084     -4.2244362831115723e-01
    z[4,1,5]  R1085     2.0742814987897873e-02
    z[4,1,5]  R1086     0.0847427025437355
    z[4,1,5]  R1087     1.6116046905517578e-01
    z[4,1,5]  R1088     -3.4456923604011536e-01
    z[4,1,5]  R1089     -5.1498931646347046e-01
    z[4,1,5]  R1090     -2.9532846808433533e-01
    z[4,1,5]  R1091     -3.2721281051635742e-01
    z[4,1,5]  R1092     -5.4802145808935165e-02
    z[4,1,5]  R1093     2.5784159079194069e-02
    z[4,1,5]  R1094     -3.3183619379997253e-01
    z[4,1,5]  R1095     -9.4814337790012360e-02
    z[4,1,5]  R1096     -3.2409057021141052e-01
    z[4,1,5]  R1097     -3.0177587270736694e-01
    z[4,1,5]  R1098     -3.4313338994979858e-01
    z[4,1,5]  R1099     -2.3594951629638672e-01
    z[4,1,5]  R1100     -3.2928720116615295e-01
    z[4,1,5]  R1101     -2.0066772401332855e-01
    z[4,1,5]  R1102     -5.9441626071929932e-02
    z[4,1,5]  R1103     2.7653029561042786e-01
    z[4,1,5]  R1104     5.4726753383874893e-02
    z[4,1,5]  R1105     3.3891800791025162e-02
    z[4,1,5]  R1106     3.3521682024002075e-01
    z[4,1,5]  R1107     -1.5599071979522705e-01
    z[4,1,5]  R1108     2.5600078515708447e-03
    z[4,1,5]  R1109     3.7962925434112549e-01
    z[4,1,5]  R1110     1.4176584780216217e-01
    z[4,1,5]  R1111     -5.8701831102371216e-01
    z[4,1,5]  R1112     -1.1679384857416153e-01
    z[4,1,5]  R1113     -3.2678428292274475e-01
    z[4,1,5]  R1114     -5.0479900836944580e-01
    z[4,1,5]  R1115     -4.6577075123786926e-01
    z[4,1,5]  R1116     -1.2833803892135620e-01
    z[4,1,5]  R1117     -1.1914358288049698e-01
    z[4,1,5]  R1118     -7.5452238321304321e-02
    z[4,1,5]  R1119     1.5624926984310150e-01
    z[4,1,5]  R1120     -2.7592654805630445e-03
    z[4,1,5]  R1121     3.9353662729263306e-01
    z[4,1,5]  R1122     -4.4771060347557068e-01
    z[4,1,5]  R1123     -2.4050267040729523e-01
    z[4,1,5]  R1124     -5.0918138027191162e-01
    z[4,1,5]  R1125     2.8002321720123291e-01
    z[4,1,5]  R1126     -0.0396539680659771
    z[4,1,5]  R1127     -3.9080310612916946e-02
    z[4,1,5]  R1128     -1.9320229068398476e-02
    z[4,1,5]  R1129     -1.4455287717282772e-02
    z[4,1,5]  R1130     -1.0613378137350082e-01
    z[4,1,5]  R1131     -4.5793151855468750e-01
    z[4,1,5]  R1132     -1.9242644309997559e-01
    z[4,1,5]  R1133     -5.7479149103164673e-01
    z[4,1,5]  R1134     -1.8723320960998535e-01
    z[4,1,5]  R1135     -2.7032741904258728e-01
    z[4,1,5]  R1136     4.8314131796360016e-02
    z[4,1,5]  R1137     -2.3204919416457415e-03
    z[4,1,5]  R1138     -1.4920058846473694e-01
    z[4,1,5]  R1139     -3.3517464995384216e-01
    z[4,1,5]  R1140     -3.0391353368759155e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R989      -1
    z[4,1,6]  R990      1
    z[4,1,6]  R991      -1.1409967392683029e-01
    z[4,1,6]  R992      1.8631061911582947e-01
    z[4,1,6]  R993      1.5505558252334595e-01
    z[4,1,6]  R994      -9.4230905175209045e-02
    z[4,1,6]  R995      8.8811673223972321e-02
    z[4,1,6]  R996      -5.4144892841577530e-02
    z[4,1,6]  R997      -3.6406937241554260e-01
    z[4,1,6]  R998      2.2296257317066193e-01
    z[4,1,6]  R999      -4.3690085411071777e-01
    z[4,1,6]  R1000     -0.284881055355072
    z[4,1,6]  R1001     2.3958197236061096e-01
    z[4,1,6]  R1002     -2.3904012143611908e-01
    z[4,1,6]  R1003     -1.1963321268558502e-01
    z[4,1,6]  R1004     -4.6805106103420258e-02
    z[4,1,6]  R1005     -1.7740327119827271e-01
    z[4,1,6]  R1006     3.9852154254913330e-01
    z[4,1,6]  R1007     -1.7968656122684479e-01
    z[4,1,6]  R1008     -5.7249772548675537e-01
    z[4,1,6]  R1009     -6.5263003110885620e-01
    z[4,1,6]  R1010     -2.8091764450073242e-01
    z[4,1,6]  R1011     1.6536907851696014e-01
    z[4,1,6]  R1012     -3.8747996091842651e-01
    z[4,1,6]  R1013     -3.6879444122314453e-01
    z[4,1,6]  R1014     7.8969156742095947e-01
    z[4,1,6]  R1015     -2.0165938138961792e-01
    z[4,1,6]  R1016     -1.3785080611705780e-01
    z[4,1,6]  R1017     0.332021564245224
    z[4,1,6]  R1018     8.9740976691246033e-02
    z[4,1,6]  R1019     -1.3271878659725189e-01
    z[4,1,6]  R1020     2.6851412653923035e-01
    z[4,1,6]  R1021     -4.4646671414375305e-01
    z[4,1,6]  R1022     3.5155513882637024e-01
    z[4,1,6]  R1023     9.7187506034970284e-03
    z[4,1,6]  R1024     -3.9079171419143677e-01
    z[4,1,6]  R1025     -1.6757705807685852e-01
    z[4,1,6]  R1026     -2.3581512272357941e-02
    z[4,1,6]  R1027     4.8792776465415955e-01
    z[4,1,6]  R1028     5.0658807158470154e-02
    z[4,1,6]  R1029     4.8480924963951111e-01
    z[4,1,6]  R1030     -2.5699833035469055e-01
    z[4,1,6]  R1031     6.6792696714401245e-02
    z[4,1,6]  R1032     2.0928496122360229e-01
    z[4,1,6]  R1033     -6.2918695621192455e-03
    z[4,1,6]  R1034     0.377238005399704
    z[4,1,6]  R1035     3.1086388230323792e-01
    z[4,1,6]  R1036     -1.9821390509605408e-01
    z[4,1,6]  R1037     -1.8849206389859319e-03
    z[4,1,6]  R1038     5.9384290128946304e-02
    z[4,1,6]  R1039     -9.6629941835999489e-03
    z[4,1,6]  R1040     1.4050062000751495e-01
    z[4,1,6]  R1041     -2.0856364071369171e-01
    z[4,1,6]  R1042     1.5194277465343475e-01
    z[4,1,6]  R1043     1.9492205977439880e-01
    z[4,1,6]  R1044     -3.1650376319885254e-01
    z[4,1,6]  R1045     -2.8207591176033020e-01
    z[4,1,6]  R1046     -2.5937798619270325e-01
    z[4,1,6]  R1047     -2.2709725797176361e-01
    z[4,1,6]  R1048     -1.5670976042747498e-01
    z[4,1,6]  R1049     -1.8955725431442261e-01
    z[4,1,6]  R1050     -1.1056371033191681e-01
    z[4,1,6]  R1051     1.5578483045101166e-01
    z[4,1,6]  R1052     -3.3971226215362549e-01
    z[4,1,6]  R1053     2.9629576206207275e-01
    z[4,1,6]  R1054     -1.7692670226097107e-01
    z[4,1,6]  R1055     1.2157399207353592e-01
    z[4,1,6]  R1056     -8.9330114424228668e-02
    z[4,1,6]  R1057     -1.0918104648590088e-01
    z[4,1,6]  R1058     2.1212534606456757e-01
    z[4,1,6]  R1059     -0.00732843903824687
    z[4,1,6]  R1060     -1.8028123676776886e-01
    z[4,1,6]  R1061     5.8017671108245850e-01
    z[4,1,6]  R1062     1.7972312867641449e-02
    z[4,1,6]  R1063     -4.0665301680564880e-01
    z[4,1,6]  R1064     1.0987018793821335e-01
    z[4,1,6]  R1065     6.1497384309768677e-01
    z[4,1,6]  R1066     -3.0301022529602051e-01
    z[4,1,6]  R1067     2.1675251424312592e-02
    z[4,1,6]  R1068     8.7226778268814087e-02
    z[4,1,6]  R1069     2.8561198711395264e-01
    z[4,1,6]  R1070     4.3371358513832092e-01
    z[4,1,6]  R1071     1.3211207091808319e-01
    z[4,1,6]  R1072     -4.1308730840682983e-01
    z[4,1,6]  R1073     -1.3268908485770226e-02
    z[4,1,6]  R1074     -9.4475768506526947e-02
    z[4,1,6]  R1075     1.4035947620868683e-01
    z[4,1,6]  R1076     1.2068077921867371e-01
    z[4,1,6]  R1077     2.5822622701525688e-02
    z[4,1,6]  R1078     3.6570936441421509e-01
    z[4,1,6]  R1079     4.2769372463226318e-01
    z[4,1,6]  R1080     -8.2987926900386810e-02
    z[4,1,6]  R1081     -2.1248523890972137e-01
    z[4,1,6]  R1082     4.3469882011413574e-01
    z[4,1,6]  R1083     2.6805743575096130e-01
    z[4,1,6]  R1084     -1.0324721783399582e-01
    z[4,1,6]  R1085     2.3308119177818298e-01
    z[4,1,6]  R1086     -1.6491647064685822e-01
    z[4,1,6]  R1087     -1.6455566883087158e-01
    z[4,1,6]  R1088     -6.8455703556537628e-02
    z[4,1,6]  R1089     -2.2133512794971466e-01
    z[4,1,6]  R1090     -9.1432582121342421e-04
    z[4,1,6]  R1091     -0.0773564875125885
    z[4,1,6]  R1092     1.6218551993370056e-01
    z[4,1,6]  R1093     -9.9893517792224884e-02
    z[4,1,6]  R1094     -1.7724396288394928e-01
    z[4,1,6]  R1095     3.0140149593353271e-01
    z[4,1,6]  R1096     5.6753152608871460e-01
    z[4,1,6]  R1097     -1.5236841142177582e-01
    z[4,1,6]  R1098     4.0906123816967010e-02
    z[4,1,6]  R1099     -3.5598453134298325e-02
    z[4,1,6]  R1100     1.6011761128902435e-01
    z[4,1,6]  R1101     -2.4560314416885376e-01
    z[4,1,6]  R1102     -8.6249615997076035e-03
    z[4,1,6]  R1103     4.5009684562683105e-01
    z[4,1,6]  R1104     8.4467105567455292e-02
    z[4,1,6]  R1105     3.5163056850433350e-01
    z[4,1,6]  R1106     1.7577911913394928e-01
    z[4,1,6]  R1107     1.4857438392937183e-02
    z[4,1,6]  R1108     -5.3883910179138184e-01
    z[4,1,6]  R1109     -0.0820883959531784
    z[4,1,6]  R1110     -2.7637362480163574e-01
    z[4,1,6]  R1111     -1.2720239348709583e-02
    z[4,1,6]  R1112     -7.6829922199249268e-01
    z[4,1,6]  R1113     -5.1832711696624756e-01
    z[4,1,6]  R1114     3.2919490337371826e-01
    z[4,1,6]  R1115     -7.9426631331443787e-02
    z[4,1,6]  R1116     -8.2022309303283691e-02
    z[4,1,6]  R1117     1.7222639173269272e-02
    z[4,1,6]  R1118     -2.2025832533836365e-01
    z[4,1,6]  R1119     -1.8181389570236206e-01
    z[4,1,6]  R1120     -0.0487905852496624
    z[4,1,6]  R1121     -6.4627546072006226e-01
    z[4,1,6]  R1122     -9.0783812105655670e-02
    z[4,1,6]  R1123     -2.0084077119827271e-01
    z[4,1,6]  R1124     2.7500659227371216e-01
    z[4,1,6]  R1125     0.0792355015873909
    z[4,1,6]  R1126     2.6192107796669006e-01
    z[4,1,6]  R1127     -1.4711722731590271e-01
    z[4,1,6]  R1128     0.0408710315823555
    z[4,1,6]  R1129     -1.4940334856510162e-01
    z[4,1,6]  R1130     7.1755279786884785e-03
    z[4,1,6]  R1131     1.7631410062313080e-01
    z[4,1,6]  R1132     -3.2058694958686829e-01
    z[4,1,6]  R1133     4.4458872079849243e-01
    z[4,1,6]  R1134     6.3253903388977051e-01
    z[4,1,6]  R1135     -2.7765689417719841e-02
    z[4,1,6]  R1136     5.8352392166852951e-02
    z[4,1,6]  R1137     1.5340046584606171e-01
    z[4,1,6]  R1138     -1.0635794699192047e-01
    z[4,1,6]  R1139     2.2697240114212036e-01
    z[4,1,6]  R1140     3.6155867576599121e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1141     -1
    z[2,3,0]  R1142     1
    z[2,3,0]  R1155     -7.0111936330795288e-01
    z[2,3,0]  R1156     -0.89290452003479
    z[2,3,0]  R1157     -5.5982106924057007e-01
    z[2,3,0]  R1158     -7.7223902940750122e-01
    z[2,3,0]  R1159     -5.1400977373123169e-01
    z[2,3,0]  R1160     -5.8208656311035156e-01
    z[2,3,0]  R1161     -7.0283114910125732e-01
    z[2,3,0]  R1162     -7.5358664989471436e-01
    z[2,3,0]  R1163     -8.4476613998413086e-01
    z[2,3,0]  R1164     -4.5482754707336426e-01
    z[2,3,0]  R1165     -1.1568231880664825e-01
    z[2,3,0]  R1166     -1.5688852965831757e-01
    z[2,3,0]  R1167     -1.5708351135253906e-01
    z[2,3,0]  R1168     0.698796272277832
    z[2,3,0]  R1169     7.0299059152603149e-01
    z[2,3,0]  R1170     6.8405562639236450e-01
    z[2,3,0]  R1171     5.8949434757232666e-01
    z[2,3,0]  R1172     7.7339643239974976e-01
    z[2,3,0]  R1173     5.5310606956481934e-01
    z[2,3,0]  R1174     6.3671547174453735e-01
    z[2,3,0]  R1175     -4.5417621731758118e-02
    z[2,3,0]  R1176     -1.3537852466106415e-01
    z[2,3,0]  R1177     7.9827654361724854e-01
    z[2,3,0]  R1178     7.7390931546688080e-02
    z[2,3,0]  R1179     1.1108760535717010e-01
    z[2,3,0]  R1180     6.6704463958740234e-01
    z[2,3,0]  R1181     -6.2267392873764038e-02
    z[2,3,0]  R1182     5.9514009952545166e-01
    z[2,3,0]  R1183     7.2336536645889282e-01
    z[2,3,0]  R1184     0.519419252872467
    z[2,3,0]  R1185     3.3257889747619629e-01
    z[2,3,0]  R1186     4.8302039504051208e-01
    z[2,3,0]  R1187     3.9415013790130615e-01
    z[2,3,0]  R1188     3.6163190007209778e-01
    z[2,3,0]  R1189     7.2397685050964355e-01
    z[2,3,0]  R1190     2.5747874751687050e-02
    z[2,3,0]  R1191     4.6654164791107178e-01
    z[2,3,0]  R1192     2.6764750480651855e-01
    z[2,3,0]  R1193     6.7203575372695923e-01
    z[2,3,0]  R1194     3.1270250678062439e-01
    z[2,3,0]  R1195     8.6481748148798943e-03
    z[2,3,0]  R1196     5.0570660829544067e-01
    z[2,3,0]  R1197     5.1533085107803345e-01
    z[2,3,0]  R1198     6.8787300586700439e-01
    z[2,3,0]  R1199     5.1636826992034912e-01
    z[2,3,0]  R1200     3.9412611722946167e-01
    z[2,3,0]  R1201     2.9528799653053284e-01
    z[2,3,0]  R1202     3.8233464956283569e-01
    z[2,3,0]  R1203     4.4280681014060974e-01
    z[2,3,0]  R1204     2.8501817584037781e-01
    z[2,3,0]  R1205     -6.6540159285068512e-02
    z[2,3,0]  R1206     7.2577208280563354e-01
    z[2,3,0]  R1207     6.4080274105072021e-01
    z[2,3,0]  R1208     4.1627743840217590e-01
    z[2,3,0]  R1209     5.0062882900238037e-01
    z[2,3,0]  R1210     4.2449519038200378e-01
    z[2,3,0]  R1211     0.635075032711029
    z[2,3,0]  R1212     3.4158974885940552e-01
    z[2,3,0]  R1213     1.6505779325962067e-01
    z[2,3,0]  R1214     2.9975670576095581e-01
    z[2,3,0]  R1215     -1.8692952394485474e-01
    z[2,3,0]  R1216     8.1349158287048340e-01
    z[2,3,0]  R1217     6.2359130382537842e-01
    z[2,3,0]  R1218     4.8640325665473938e-01
    z[2,3,0]  R1219     4.1923937201499939e-01
    z[2,3,0]  R1220     0.6805379986763
    z[2,3,0]  R1221     3.6483851075172424e-01
    z[2,3,0]  R1222     5.0083762407302856e-01
    z[2,3,0]  R1223     4.9331733584403992e-01
    z[2,3,0]  R1224     3.9891350269317627e-01
    z[2,3,0]  R1225     -1.6254135966300964e-01
    z[2,3,0]  R1226     -3.8926255702972412e-01
    z[2,3,0]  R1227     -1.3564291875809431e-03
    z[2,3,0]  R1228     6.3775193691253662e-01
    z[2,3,0]  R1229     -7.1092344820499420e-02
    z[2,3,0]  R1230     5.1004421710968018e-01
    z[2,3,0]  R1231     5.7516175508499146e-01
    z[2,3,0]  R1232     5.8088397979736328e-01
    z[2,3,0]  R1233     0.561552882194519
    z[2,3,0]  R1234     5.3413277864456177e-01
    z[2,3,0]  R1235     -3.9800170063972473e-01
    z[2,3,0]  R1236     -4.5562595129013062e-01
    z[2,3,0]  R1237     8.4574174880981445e-01
    z[2,3,0]  R1238     4.4838038086891174e-01
    z[2,3,0]  R1239     5.0031250715255737e-01
    z[2,3,0]  R1240     0.2799052298069
    z[2,3,0]  R1241     5.0745552778244019e-01
    z[2,3,0]  R1242     4.3456608057022095e-01
    z[2,3,0]  R1243     4.6067798137664795e-01
    z[2,3,0]  R1244     5.6948703527450562e-01
    z[2,3,0]  R1245     -3.5241582989692688e-01
    z[2,3,0]  R1246     -4.7572940587997437e-02
    z[2,3,0]  R1247     3.5930645465850830e-01
    z[2,3,0]  R1248     7.1881860494613647e-01
    z[2,3,0]  R1249     2.6641449332237244e-01
    z[2,3,0]  R1250     5.2527123689651489e-01
    z[2,3,0]  R1251     2.4020172655582428e-02
    z[2,3,0]  R1252     -2.5739121437072754e-01
    z[2,3,0]  R1253     -1.3720057904720306e-01
    z[2,3,0]  R1254     -0.0615449957549572
    z[2,3,0]  R1255     -7.6408244669437408e-02
    z[2,3,0]  R1256     6.9351524114608765e-01
    z[2,3,0]  R1257     4.3329709768295288e-01
    z[2,3,0]  R1258     -4.7730613499879837e-02
    z[2,3,0]  R1259     -2.0059393346309662e-01
    z[2,3,0]  R1260     -2.2417631745338440e-01
    z[2,3,0]  R1261     -2.9909706115722656e-01
    z[2,3,0]  R1262     -2.5791233777999878e-01
    z[2,3,0]  R1263     3.9937341213226318e-01
    z[2,3,0]  R1264     -3.0486646294593811e-01
    z[2,3,0]  R1265     2.7983114123344421e-01
    z[2,3,0]  R1266     4.5460104942321777e-01
    z[2,3,0]  R1267     5.2850371599197388e-01
    z[2,3,0]  R1268     7.4628823995590210e-01
    z[2,3,0]  R1269     6.7978280782699585e-01
    z[2,3,0]  R1270     5.0720679759979248e-01
    z[2,3,0]  R1271     -1.7386375367641449e-01
    z[2,3,0]  R1272     6.3635128736495972e-01
    z[2,3,0]  R1273     1.9838495645672083e-03
    z[2,3,0]  R1274     4.3724125623703003e-01
    z[2,3,0]  R1275     1.0943809896707535e-01
    z[2,3,0]  R1276     7.2360396385192871e-01
    z[2,3,0]  R1277     -0.41497603058815
    z[2,3,0]  R1278     -0.360065221786499
    z[2,3,0]  R1279     -4.2180991172790527e-01
    z[2,3,0]  R1280     -4.8004138469696045e-01
    z[2,3,0]  R1281     -4.3477049469947815e-01
    z[2,3,0]  R1282     -0.6156005859375
    z[2,3,0]  R1283     -3.2301768660545349e-01
    z[2,3,0]  R1284     -3.7379533052444458e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1143     -1
    z[2,3,1]  R1144     1
    z[2,3,1]  R1155     -4.4949498772621155e-01
    z[2,3,1]  R1156     -3.3479818701744080e-01
    z[2,3,1]  R1157     -4.0453898906707764e-01
    z[2,3,1]  R1158     -2.1958525478839874e-01
    z[2,3,1]  R1159     -4.5704743266105652e-01
    z[2,3,1]  R1160     -3.9728373289108276e-01
    z[2,3,1]  R1161     -4.2038300633430481e-01
    z[2,3,1]  R1162     -3.3675962686538696e-01
    z[2,3,1]  R1163     -3.1949669122695923e-01
    z[2,3,1]  R1164     -5.7820230722427368e-01
    z[2,3,1]  R1165     -4.9175927042961121e-01
    z[2,3,1]  R1166     -4.1158196330070496e-01
    z[2,3,1]  R1167     -2.6734501123428345e-01
    z[2,3,1]  R1168     -0.53836989402771
    z[2,3,1]  R1169     -0.342671275138855
    z[2,3,1]  R1170     -0.541056752204895
    z[2,3,1]  R1171     -5.0658035278320312e-01
    z[2,3,1]  R1172     -4.2686796188354492e-01
    z[2,3,1]  R1173     -4.5486468076705933e-01
    z[2,3,1]  R1174     -4.7082564234733582e-01
    z[2,3,1]  R1175     8.3409690856933594e-01
    z[2,3,1]  R1176     8.9928787946701050e-01
    z[2,3,1]  R1177     5.4799276590347290e-01
    z[2,3,1]  R1178     8.9229595661163330e-01
    z[2,3,1]  R1179     8.1544631719589233e-01
    z[2,3,1]  R1180     4.9941697716712952e-01
    z[2,3,1]  R1181     8.3573579788208008e-01
    z[2,3,1]  R1182     6.6910892724990845e-01
    z[2,3,1]  R1183     0.512220561504364
    z[2,3,1]  R1184     0.647648811340332
    z[2,3,1]  R1185     -0.624687135219574
    z[2,3,1]  R1186     -1.5297412872314453e-01
    z[2,3,1]  R1187     -3.5245409607887268e-01
    z[2,3,1]  R1188     3.9174661040306091e-01
    z[2,3,1]  R1189     5.8493453264236450e-01
    z[2,3,1]  R1190     -4.7863489389419556e-01
    z[2,3,1]  R1191     3.3903810381889343e-01
    z[2,3,1]  R1192     5.1297110319137573e-01
    z[2,3,1]  R1193     2.3550365865230560e-01
    z[2,3,1]  R1194     5.3314840793609619e-01
    z[2,3,1]  R1195     -2.4784113466739655e-01
    z[2,3,1]  R1196     -5.9990996122360229e-01
    z[2,3,1]  R1197     -4.7414350509643555e-01
    z[2,3,1]  R1198     -3.4876686334609985e-01
    z[2,3,1]  R1199     -3.4695991873741150e-01
    z[2,3,1]  R1200     4.0909501910209656e-01
    z[2,3,1]  R1201     -4.9234721809625626e-02
    z[2,3,1]  R1202     5.2433037757873535e-01
    z[2,3,1]  R1203     7.4485820531845093e-01
    z[2,3,1]  R1204     3.7005302309989929e-01
    z[2,3,1]  R1205     -5.4520559310913086e-01
    z[2,3,1]  R1206     -3.6321339011192322e-01
    z[2,3,1]  R1207     -3.1689906120300293e-01
    z[2,3,1]  R1208     4.6174535155296326e-01
    z[2,3,1]  R1209     3.0371323227882385e-01
    z[2,3,1]  R1210     4.5032000541687012e-01
    z[2,3,1]  R1211     3.2231101393699646e-01
    z[2,3,1]  R1212     3.0020135641098022e-01
    z[2,3,1]  R1213     7.2646868228912354e-01
    z[2,3,1]  R1214     2.7069088816642761e-01
    z[2,3,1]  R1215     -0.708975076675415
    z[2,3,1]  R1216     -3.2215201854705811e-01
    z[2,3,1]  R1217     -5.3843152523040771e-01
    z[2,3,1]  R1218     -6.7342722415924072e-01
    z[2,3,1]  R1219     -1.2217929214239120e-01
    z[2,3,1]  R1220     2.8495249152183533e-01
    z[2,3,1]  R1221     4.0100643038749695e-01
    z[2,3,1]  R1222     6.8663710355758667e-01
    z[2,3,1]  R1223     7.4688619375228882e-01
    z[2,3,1]  R1224     0.786733090877533
    z[2,3,1]  R1225     -5.9715646505355835e-01
    z[2,3,1]  R1226     -3.9939552545547485e-01
    z[2,3,1]  R1227     -0.359060674905777
    z[2,3,1]  R1228     -5.4217046499252319e-01
    z[2,3,1]  R1229     -3.9332851767539978e-01
    z[2,3,1]  R1230     -6.6162484884262085e-01
    z[2,3,1]  R1231     -6.2013298273086548e-01
    z[2,3,1]  R1232     -1.5233758091926575e-01
    z[2,3,1]  R1233     6.9876176118850708e-01
    z[2,3,1]  R1234     4.9144935607910156e-01
    z[2,3,1]  R1235     -6.2753462791442871e-01
    z[2,3,1]  R1236     -5.0875192880630493e-01
    z[2,3,1]  R1237     -3.8915121555328369e-01
    z[2,3,1]  R1238     -6.5223330259323120e-01
    z[2,3,1]  R1239     -2.3108184337615967e-01
    z[2,3,1]  R1240     4.8056399822235107e-01
    z[2,3,1]  R1241     6.7994487285614014e-01
    z[2,3,1]  R1242     7.9221922159194946e-01
    z[2,3,1]  R1243     6.3531875610351562e-01
    z[2,3,1]  R1244     0.653005838394165
    z[2,3,1]  R1245     -6.4434444904327393e-01
    z[2,3,1]  R1246     -0.489510715007782
    z[2,3,1]  R1247     -1.9995056092739105e-01
    z[2,3,1]  R1248     3.3218595385551453e-01
    z[2,3,1]  R1249     8.8451522588729858e-01
    z[2,3,1]  R1250     6.7061942815780640e-01
    z[2,3,1]  R1251     8.2782679796218872e-01
    z[2,3,1]  R1252     8.5486674308776855e-01
    z[2,3,1]  R1253     8.5490471124649048e-01
    z[2,3,1]  R1254     9.0760940313339233e-01
    z[2,3,1]  R1255     -6.9260370731353760e-01
    z[2,3,1]  R1256     3.5019379854202271e-01
    z[2,3,1]  R1257     7.1538847684860229e-01
    z[2,3,1]  R1258     8.1186813116073608e-01
    z[2,3,1]  R1259     9.3135637044906616e-01
    z[2,3,1]  R1260     9.2622154951095581e-01
    z[2,3,1]  R1261     7.4198907613754272e-01
    z[2,3,1]  R1262     7.0418852567672729e-01
    z[2,3,1]  R1263     6.0367500782012939e-01
    z[2,3,1]  R1264     8.0924779176712036e-01
    z[2,3,1]  R1265     0.505213737487793
    z[2,3,1]  R1266     -2.9188922047615051e-01
    z[2,3,1]  R1267     -2.7200677990913391e-01
    z[2,3,1]  R1268     -3.0819791555404663e-01
    z[2,3,1]  R1269     -4.9865084886550903e-01
    z[2,3,1]  R1270     -2.9265290498733521e-01
    z[2,3,1]  R1271     0.80692058801651
    z[2,3,1]  R1272     -5.2047246694564819e-01
    z[2,3,1]  R1273     1.3496515154838562e-01
    z[2,3,1]  R1274     -6.9121068716049194e-01
    z[2,3,1]  R1275     0.0921378806233406
    z[2,3,1]  R1276     2.1200199425220490e-01
    z[2,3,1]  R1277     -5.6763851642608643e-01
    z[2,3,1]  R1278     -8.2999789714813232e-01
    z[2,3,1]  R1279     -7.0515358448028564e-01
    z[2,3,1]  R1280     -4.0988948941230774e-01
    z[2,3,1]  R1281     -4.6646991372108459e-01
    z[2,3,1]  R1282     1.9349502027034760e-01
    z[2,3,1]  R1283     4.7425529360771179e-01
    z[2,3,1]  R1284     2.0977059006690979e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1145     -1
    z[2,3,2]  R1146     1
    z[2,3,2]  R1155     -8.3873413503170013e-02
    z[2,3,2]  R1156     -4.6433258801698685e-02
    z[2,3,2]  R1157     -2.2240121662616730e-01
    z[2,3,2]  R1158     -2.7171779423952103e-02
    z[2,3,2]  R1159     -3.3987402915954590e-01
    z[2,3,2]  R1160     -5.5712664127349854e-01
    z[2,3,2]  R1161     -1.9285935163497925e-01
    z[2,3,2]  R1162     -7.8938134014606476e-02
    z[2,3,2]  R1163     -2.2901487350463867e-01
    z[2,3,2]  R1164     -7.9810842871665955e-02
    z[2,3,2]  R1165     2.6303282380104065e-01
    z[2,3,2]  R1166     2.6568922400474548e-01
    z[2,3,2]  R1167     4.1921749711036682e-01
    z[2,3,2]  R1168     -9.8678901791572571e-02
    z[2,3,2]  R1169     -2.0471695065498352e-01
    z[2,3,2]  R1170     1.9106050953269005e-02
    z[2,3,2]  R1171     -3.7495499849319458e-01
    z[2,3,2]  R1172     0.246204674243927
    z[2,3,2]  R1173     -7.9527176916599274e-02
    z[2,3,2]  R1174     -4.0902385115623474e-01
    z[2,3,2]  R1175     2.3406212031841278e-01
    z[2,3,2]  R1176     2.1850508451461792e-01
    z[2,3,2]  R1177     2.0507957041263580e-01
    z[2,3,2]  R1178     2.8700596094131470e-01
    z[2,3,2]  R1179     1.1165440827608109e-01
    z[2,3,2]  R1180     2.7908065915107727e-01
    z[2,3,2]  R1181     1.8962990492582321e-02
    z[2,3,2]  R1182     4.4834561645984650e-02
    z[2,3,2]  R1183     2.2323322296142578e-01
    z[2,3,2]  R1184     1.2390603870153427e-01
    z[2,3,2]  R1185     0.0780886635184288
    z[2,3,2]  R1186     1.9408886134624481e-01
    z[2,3,2]  R1187     -4.8023164272308350e-01
    z[2,3,2]  R1188     2.6034104824066162e-01
    z[2,3,2]  R1189     1.3381375372409821e-01
    z[2,3,2]  R1190     4.1495844721794128e-01
    z[2,3,2]  R1191     1.1374760419130325e-01
    z[2,3,2]  R1192     -2.3696143925189972e-01
    z[2,3,2]  R1193     2.4504022300243378e-01
    z[2,3,2]  R1194     -5.6998956203460693e-01
    z[2,3,2]  R1195     2.1002964675426483e-01
    z[2,3,2]  R1196     1.1083374917507172e-01
    z[2,3,2]  R1197     -2.1317757666110992e-01
    z[2,3,2]  R1198     2.2484730929136276e-02
    z[2,3,2]  R1199     1.1564595997333527e-01
    z[2,3,2]  R1200     -3.6476936936378479e-01
    z[2,3,2]  R1201     -7.3987501859664917e-01
    z[2,3,2]  R1202     -2.7295741438865662e-01
    z[2,3,2]  R1203     -1.7261974513530731e-01
    z[2,3,2]  R1204     -3.0395638942718506e-01
    z[2,3,2]  R1205     -2.3103702813386917e-02
    z[2,3,2]  R1206     3.4460190683603287e-02
    z[2,3,2]  R1207     0.0395638681948185
    z[2,3,2]  R1208     2.0583797991275787e-01
    z[2,3,2]  R1209     2.0590786635875702e-01
    z[2,3,2]  R1210     2.1422188729047775e-02
    z[2,3,2]  R1211     3.2103773951530457e-01
    z[2,3,2]  R1212     1.3293132185935974e-01
    z[2,3,2]  R1213     1.5961390733718872e-01
    z[2,3,2]  R1214     -2.8850415349006653e-01
    z[2,3,2]  R1215     3.6791037768125534e-02
    z[2,3,2]  R1216     1.2451093643903732e-02
    z[2,3,2]  R1217     1.8904432363342494e-04
    z[2,3,2]  R1218     -3.2507389783859253e-01
    z[2,3,2]  R1219     0.0774095356464386
    z[2,3,2]  R1220     3.6462989449501038e-01
    z[2,3,2]  R1221     -4.1372212767601013e-01
    z[2,3,2]  R1222     -1.2415719032287598e-01
    z[2,3,2]  R1223     -0.0970790833234787
    z[2,3,2]  R1224     -2.9878395795822144e-01
    z[2,3,2]  R1225     1.2553636729717255e-01
    z[2,3,2]  R1226     3.5829934477806091e-01
    z[2,3,2]  R1227     2.2452621161937714e-01
    z[2,3,2]  R1228     -1.6520200669765472e-01
    z[2,3,2]  R1229     3.6298206448554993e-01
    z[2,3,2]  R1230     6.0138802975416183e-02
    z[2,3,2]  R1231     6.9822356104850769e-02
    z[2,3,2]  R1232     -3.4507915377616882e-02
    z[2,3,2]  R1233     2.3588884621858597e-02
    z[2,3,2]  R1234     1.5894058346748352e-01
    z[2,3,2]  R1235     2.1491686347872019e-03
    z[2,3,2]  R1236     1.8455219268798828e-01
    z[2,3,2]  R1237     -5.6969024240970612e-02
    z[2,3,2]  R1238     -2.6415362954139709e-01
    z[2,3,2]  R1239     1.1966821737587452e-02
    z[2,3,2]  R1240     -4.4037967920303345e-01
    z[2,3,2]  R1241     -2.6911085471510887e-02
    z[2,3,2]  R1242     -1.9403958320617676e-01
    z[2,3,2]  R1243     -2.5870782136917114e-01
    z[2,3,2]  R1244     -2.3429703712463379e-01
    z[2,3,2]  R1245     2.5956448912620544e-01
    z[2,3,2]  R1246     3.8324168324470520e-01
    z[2,3,2]  R1247     -0.618421196937561
    z[2,3,2]  R1248     4.4852638244628906e-01
    z[2,3,2]  R1249     1.7736503481864929e-01
    z[2,3,2]  R1250     -2.2517210245132446e-01
    z[2,3,2]  R1251     -8.2901574671268463e-02
    z[2,3,2]  R1252     2.7789219748228788e-03
    z[2,3,2]  R1253     -4.8508081585168839e-02
    z[2,3,2]  R1254     -5.1402464509010315e-02
    z[2,3,2]  R1255     2.8791493177413940e-01
    z[2,3,2]  R1256     4.8713916540145874e-01
    z[2,3,2]  R1257     -2.3065733909606934e-01
    z[2,3,2]  R1258     -7.4305996298789978e-02
    z[2,3,2]  R1259     -7.2838112711906433e-02
    z[2,3,2]  R1260     -1.8119428306818008e-02
    z[2,3,2]  R1261     -3.2035443931818008e-02
    z[2,3,2]  R1262     -0.0669550821185112
    z[2,3,2]  R1263     -4.0896505117416382e-01
    z[2,3,2]  R1264     0.145684614777565
    z[2,3,2]  R1265     9.6491836011409760e-02
    z[2,3,2]  R1266     1.0408055037260056e-01
    z[2,3,2]  R1267     -2.7911257743835449e-01
    z[2,3,2]  R1268     -1.6206982731819153e-01
    z[2,3,2]  R1269     2.9160779714584351e-01
    z[2,3,2]  R1270     1.2674829363822937e-01
    z[2,3,2]  R1271     9.7393020987510681e-02
    z[2,3,2]  R1272     -9.0242482721805573e-02
    z[2,3,2]  R1273     2.9007151722908020e-01
    z[2,3,2]  R1274     -1.8557514250278473e-01
    z[2,3,2]  R1275     -2.3937630653381348e-01
    z[2,3,2]  R1276     4.1321533918380737e-01
    z[2,3,2]  R1277     -4.4200602173805237e-01
    z[2,3,2]  R1278     5.5509600788354874e-02
    z[2,3,2]  R1279     1.0695017874240875e-01
    z[2,3,2]  R1280     -3.8250240683555603e-01
    z[2,3,2]  R1281     -4.8148775100708008e-01
    z[2,3,2]  R1282     -5.3229510784149170e-01
    z[2,3,2]  R1283     1.8213652074337006e-01
    z[2,3,2]  R1284     -0.0711749866604805
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1147     -1
    z[2,3,3]  R1148     1
    z[2,3,3]  R1155     -3.1444865465164185e-01
    z[2,3,3]  R1156     -1.4626236259937286e-01
    z[2,3,3]  R1157     -5.8290481567382812e-01
    z[2,3,3]  R1158     -0.359375923871994
    z[2,3,3]  R1159     -4.0348294377326965e-01
    z[2,3,3]  R1160     -0.338177889585495
    z[2,3,3]  R1161     -1.1701557785272598e-01
    z[2,3,3]  R1162     -4.8129951953887939e-01
    z[2,3,3]  R1163     -0.119330033659935
    z[2,3,3]  R1164     -1.2594413757324219e-01
    z[2,3,3]  R1165     0.777704656124115
    z[2,3,3]  R1166     5.0404578447341919e-01
    z[2,3,3]  R1167     7.4074435234069824e-01
    z[2,3,3]  R1168     -3.2771375775337219e-01
    z[2,3,3]  R1169     -4.4695916771888733e-01
    z[2,3,3]  R1170     -1.6949616372585297e-02
    z[2,3,3]  R1171     8.2354426383972168e-02
    z[2,3,3]  R1172     9.8446160554885864e-02
    z[2,3,3]  R1173     1.3948664069175720e-01
    z[2,3,3]  R1174     7.8831324353814125e-03
    z[2,3,3]  R1175     -4.2408472299575806e-01
    z[2,3,3]  R1176     -3.1299224495887756e-01
    z[2,3,3]  R1177     3.4943778067827225e-02
    z[2,3,3]  R1178     -2.7338418364524841e-01
    z[2,3,3]  R1179     -5.3486210107803345e-01
    z[2,3,3]  R1180     1.8606856465339661e-01
    z[2,3,3]  R1181     -0.537039577960968
    z[2,3,3]  R1182     3.3837845921516418e-01
    z[2,3,3]  R1183     1.2361179292201996e-01
    z[2,3,3]  R1184     5.2461528778076172e-01
    z[2,3,3]  R1185     -2.7048733830451965e-01
    z[2,3,3]  R1186     -3.6922267079353333e-01
    z[2,3,3]  R1187     4.0404331684112549e-01
    z[2,3,3]  R1188     6.9523942470550537e-01
    z[2,3,3]  R1189     2.1272036433219910e-01
    z[2,3,3]  R1190     -5.4666560143232346e-02
    z[2,3,3]  R1191     0.553445041179657
    z[2,3,3]  R1192     -6.5014642477035522e-01
    z[2,3,3]  R1193     5.9282785654067993e-01
    z[2,3,3]  R1194     -4.9514451622962952e-01
    z[2,3,3]  R1195     5.3969818353652954e-01
    z[2,3,3]  R1196     -4.2107868194580078e-01
    z[2,3,3]  R1197     4.0940076112747192e-01
    z[2,3,3]  R1198     3.0737709999084473e-01
    z[2,3,3]  R1199     -9.6147827804088593e-02
    z[2,3,3]  R1200     -6.3931626081466675e-01
    z[2,3,3]  R1201     5.4876238107681274e-01
    z[2,3,3]  R1202     -3.9552164077758789e-01
    z[2,3,3]  R1203     -2.9253163933753967e-01
    z[2,3,3]  R1204     -3.9204615354537964e-01
    z[2,3,3]  R1205     2.5662720203399658e-01
    z[2,3,3]  R1206     2.6621833443641663e-01
    z[2,3,3]  R1207     -3.8232272863388062e-01
    z[2,3,3]  R1208     6.3889360427856445e-01
    z[2,3,3]  R1209     7.0790648460388184e-01
    z[2,3,3]  R1210     6.2034225463867188e-01
    z[2,3,3]  R1211     -4.5698079466819763e-01
    z[2,3,3]  R1212     6.6236847639083862e-01
    z[2,3,3]  R1213     -3.5968446731567383e-01
    z[2,3,3]  R1214     -5.0943839550018311e-01
    z[2,3,3]  R1215     0.479433536529541
    z[2,3,3]  R1216     -1.0581338405609131e-01
    z[2,3,3]  R1217     2.8363707661628723e-01
    z[2,3,3]  R1218     3.5104501247406006e-01
    z[2,3,3]  R1219     -2.9018688201904297e-01
    z[2,3,3]  R1220     -1.8076236546039581e-01
    z[2,3,3]  R1221     -4.5794364809989929e-01
    z[2,3,3]  R1222     -8.6128480732440948e-02
    z[2,3,3]  R1223     -1.3811598718166351e-01
    z[2,3,3]  R1224     -5.3824737668037415e-02
    z[2,3,3]  R1225     6.4488071203231812e-01
    z[2,3,3]  R1226     6.2346053123474121e-01
    z[2,3,3]  R1227     0.664882481098175
    z[2,3,3]  R1228     -3.2524743676185608e-01
    z[2,3,3]  R1229     5.5865764617919922e-01
    z[2,3,3]  R1230     -1.5654183924198151e-01
    z[2,3,3]  R1231     -2.9144337773323059e-01
    z[2,3,3]  R1232     -6.5572023391723633e-01
    z[2,3,3]  R1233     1.2729948759078979e-01
    z[2,3,3]  R1234     4.0542042255401611e-01
    z[2,3,3]  R1235     3.1787082552909851e-01
    z[2,3,3]  R1236     4.4996318221092224e-01
    z[2,3,3]  R1237     -3.1418710947036743e-01
    z[2,3,3]  R1238     3.8389632105827332e-01
    z[2,3,3]  R1239     -5.3141820430755615e-01
    z[2,3,3]  R1240     -0.643108606338501
    z[2,3,3]  R1241     -2.4881545454263687e-02
    z[2,3,3]  R1242     -2.0807598531246185e-01
    z[2,3,3]  R1243     -1.1604075133800507e-01
    z[2,3,3]  R1244     -0.272417277097702
    z[2,3,3]  R1245     4.8620399832725525e-01
    z[2,3,3]  R1246     5.2253186702728271e-01
    z[2,3,3]  R1247     0.405316561460495
    z[2,3,3]  R1248     -1.4786474406719208e-01
    z[2,3,3]  R1249     -1.6723164916038513e-01
    z[2,3,3]  R1250     -1.1875883489847183e-01
    z[2,3,3]  R1251     2.3033621907234192e-01
    z[2,3,3]  R1252     2.2643083333969116e-01
    z[2,3,3]  R1253     1.6457028687000275e-01
    z[2,3,3]  R1254     1.6401518881320953e-01
    z[2,3,3]  R1255     5.4490929841995239e-01
    z[2,3,3]  R1256     -8.8538669049739838e-02
    z[2,3,3]  R1257     -1.3700371980667114e-01
    z[2,3,3]  R1258     1.9309966266155243e-01
    z[2,3,3]  R1259     2.3324583470821381e-01
    z[2,3,3]  R1260     2.7790060639381409e-01
    z[2,3,3]  R1261     0.458374559879303
    z[2,3,3]  R1262     4.9108245968818665e-01
    z[2,3,3]  R1263     -2.0483481884002686e-01
    z[2,3,3]  R1264     3.1911596655845642e-01
    z[2,3,3]  R1265     3.8233183324337006e-02
    z[2,3,3]  R1266     -5.6281287223100662e-02
    z[2,3,3]  R1267     -1.6667445003986359e-01
    z[2,3,3]  R1268     -1.1466748267412186e-01
    z[2,3,3]  R1269     2.0051820203661919e-02
    z[2,3,3]  R1270     1.4815273880958557e-01
    z[2,3,3]  R1271     -1.3428920507431030e-01
    z[2,3,3]  R1272     -4.4378823041915894e-01
    z[2,3,3]  R1273     -2.1803137660026550e-01
    z[2,3,3]  R1274     -3.4357210993766785e-01
    z[2,3,3]  R1275     -7.1974718570709229e-01
    z[2,3,3]  R1276     -3.4759324789047241e-01
    z[2,3,3]  R1277     -1.9642159342765808e-01
    z[2,3,3]  R1278     1.9086253643035889e-01
    z[2,3,3]  R1279     2.0496025681495667e-01
    z[2,3,3]  R1280     -7.6402656733989716e-02
    z[2,3,3]  R1281     1.2922681868076324e-01
    z[2,3,3]  R1282     3.9129105210304260e-01
    z[2,3,3]  R1283     5.7691287994384766e-01
    z[2,3,3]  R1284     -1.4007851481437683e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1149     -1
    z[2,3,4]  R1150     1
    z[2,3,4]  R1155     7.6696373522281647e-02
    z[2,3,4]  R1156     -1.3601037859916687e-01
    z[2,3,4]  R1157     2.6907208561897278e-01
    z[2,3,4]  R1158     -2.7263644337654114e-01
    z[2,3,4]  R1159     -3.4290242195129395e-01
    z[2,3,4]  R1160     -2.7971944212913513e-01
    z[2,3,4]  R1161     -0.45118448138237
    z[2,3,4]  R1162     -3.6923289299011230e-02
    z[2,3,4]  R1163     -1.7339762300252914e-02
    z[2,3,4]  R1164     -4.2922419309616089e-01
    z[2,3,4]  R1165     1.5936696529388428e-01
    z[2,3,4]  R1166     5.2261584997177124e-01
    z[2,3,4]  R1167     -1.9508515298366547e-01
    z[2,3,4]  R1168     2.5149953365325928e-01
    z[2,3,4]  R1169     -3.6170445382595062e-02
    z[2,3,4]  R1170     6.0345385223627090e-02
    z[2,3,4]  R1171     3.2775735855102539e-01
    z[2,3,4]  R1172     -1.6123975813388824e-01
    z[2,3,4]  R1173     -1.1112906038761139e-02
    z[2,3,4]  R1174     -1.7066720128059387e-01
    z[2,3,4]  R1175     -2.5070169568061829e-01
    z[2,3,4]  R1176     -1.6315679252147675e-01
    z[2,3,4]  R1177     -0.0604669563472271
    z[2,3,4]  R1178     -3.4378089010715485e-02
    z[2,3,4]  R1179     3.7657979875802994e-02
    z[2,3,4]  R1180     -1.8559253215789795e-01
    z[2,3,4]  R1181     7.3197752237319946e-02
    z[2,3,4]  R1182     2.6784452795982361e-01
    z[2,3,4]  R1183     -3.4259593486785889e-01
    z[2,3,4]  R1184     -7.1928925812244415e-02
    z[2,3,4]  R1185     -4.5762622356414795e-01
    z[2,3,4]  R1186     -1.5903252363204956e-01
    z[2,3,4]  R1187     2.1625605225563049e-01
    z[2,3,4]  R1188     1.7825832590460777e-02
    z[2,3,4]  R1189     1.1625821888446808e-01
    z[2,3,4]  R1190     -3.0601578950881958e-01
    z[2,3,4]  R1191     4.7598907351493835e-01
    z[2,3,4]  R1192     -3.3756002783775330e-01
    z[2,3,4]  R1193     2.4750913679599762e-01
    z[2,3,4]  R1194     -8.3448909223079681e-02
    z[2,3,4]  R1195     0.265316367149353
    z[2,3,4]  R1196     -9.8314777016639709e-02
    z[2,3,4]  R1197     -4.5501780509948730e-01
    z[2,3,4]  R1198     -3.0927973985671997e-01
    z[2,3,4]  R1199     -6.9239658117294312e-01
    z[2,3,4]  R1200     1.4795464277267456e-01
    z[2,3,4]  R1201     -2.1814560890197754e-01
    z[2,3,4]  R1202     -3.9844788610935211e-02
    z[2,3,4]  R1203     2.5043150782585144e-01
    z[2,3,4]  R1204     5.3612012416124344e-02
    z[2,3,4]  R1205     7.2713029384613037e-01
    z[2,3,4]  R1206     -0.322696328163147
    z[2,3,4]  R1207     -2.0935116708278656e-01
    z[2,3,4]  R1208     2.8589293360710144e-01
    z[2,3,4]  R1209     2.4938410520553589e-01
    z[2,3,4]  R1210     1.0532125830650330e-01
    z[2,3,4]  R1211     -1.1799144744873047e-01
    z[2,3,4]  R1212     -2.9631054401397705e-01
    z[2,3,4]  R1213     -2.1745118498802185e-01
    z[2,3,4]  R1214     -1.9360281527042389e-01
    z[2,3,4]  R1215     5.6955549865961075e-02
    z[2,3,4]  R1216     -2.4683679640293121e-01
    z[2,3,4]  R1217     1.5325234830379486e-01
    z[2,3,4]  R1218     -1.2517413496971130e-01
    z[2,3,4]  R1219     6.5691810846328735e-01
    z[2,3,4]  R1220     4.9956849217414856e-01
    z[2,3,4]  R1221     1.3732229173183441e-01
    z[2,3,4]  R1222     -3.8667482137680054e-01
    z[2,3,4]  R1223     -3.3884474635124207e-01
    z[2,3,4]  R1224     -1.7403274774551392e-01
    z[2,3,4]  R1225     0.289171040058136
    z[2,3,4]  R1226     0.0606367364525795
    z[2,3,4]  R1227     -4.7994937747716904e-02
    z[2,3,4]  R1228     2.9373185709118843e-02
    z[2,3,4]  R1229     2.4802295863628387e-01
    z[2,3,4]  R1230     -3.9063632488250732e-01
    z[2,3,4]  R1231     3.0453100800514221e-01
    z[2,3,4]  R1232     -3.2805752754211426e-01
    z[2,3,4]  R1233     -2.0189037919044495e-01
    z[2,3,4]  R1234     -5.9273969382047653e-03
    z[2,3,4]  R1235     3.1691977381706238e-01
    z[2,3,4]  R1236     3.9639544486999512e-01
    z[2,3,4]  R1237     -9.6043810248374939e-02
    z[2,3,4]  R1238     -5.7641044259071350e-02
    z[2,3,4]  R1239     4.5994570851325989e-01
    z[2,3,4]  R1240     -4.5340526849031448e-02
    z[2,3,4]  R1241     4.6919766813516617e-02
    z[2,3,4]  R1242     -0.274619460105896
    z[2,3,4]  R1243     4.3874431401491165e-02
    z[2,3,4]  R1244     -0.214004248380661
    z[2,3,4]  R1245     2.3286873102188110e-01
    z[2,3,4]  R1246     -1.6028711199760437e-01
    z[2,3,4]  R1247     3.3477634191513062e-01
    z[2,3,4]  R1248     1.7664463818073273e-01
    z[2,3,4]  R1249     -1.3306210935115814e-01
    z[2,3,4]  R1250     -1.6326928511261940e-02
    z[2,3,4]  R1251     -2.6743057370185852e-01
    z[2,3,4]  R1252     -8.3587124943733215e-02
    z[2,3,4]  R1253     -2.1492704749107361e-02
    z[2,3,4]  R1254     -8.7991170585155487e-02
    z[2,3,4]  R1255     2.9614555835723877e-01
    z[2,3,4]  R1256     1.3326078653335571e-01
    z[2,3,4]  R1257     1.1991009861230850e-01
    z[2,3,4]  R1258     -2.1958047151565552e-01
    z[2,3,4]  R1259     -1.2943805195391178e-02
    z[2,3,4]  R1260     2.4993417784571648e-02
    z[2,3,4]  R1261     3.1518232822418213e-01
    z[2,3,4]  R1262     2.3044927418231964e-01
    z[2,3,4]  R1263     1.8626351654529572e-01
    z[2,3,4]  R1264     7.2187192738056183e-02
    z[2,3,4]  R1265     2.6292881369590759e-01
    z[2,3,4]  R1266     1.1427477002143860e-03
    z[2,3,4]  R1267     2.9889410734176636e-01
    z[2,3,4]  R1268     5.2212929725646973e-01
    z[2,3,4]  R1269     2.8739643096923828e-01
    z[2,3,4]  R1270     4.6194615960121155e-01
    z[2,3,4]  R1271     -2.1076743304729462e-01
    z[2,3,4]  R1272     8.2869090139865875e-02
    z[2,3,4]  R1273     -5.6725829839706421e-01
    z[2,3,4]  R1274     -2.1376505494117737e-01
    z[2,3,4]  R1275     -5.7799136638641357e-01
    z[2,3,4]  R1276     -1.2210885435342789e-01
    z[2,3,4]  R1277     -3.7678331136703491e-01
    z[2,3,4]  R1278     -1.7832627892494202e-01
    z[2,3,4]  R1279     -4.3485438823699951e-01
    z[2,3,4]  R1280     0.597722053527832
    z[2,3,4]  R1281     4.6631014347076416e-01
    z[2,3,4]  R1282     2.9649755358695984e-01
    z[2,3,4]  R1283     4.4300094246864319e-01
    z[2,3,4]  R1284     7.8966683149337769e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1151     -1
    z[2,3,5]  R1152     1
    z[2,3,5]  R1155     -4.0913251042366028e-01
    z[2,3,5]  R1156     -1.9938772916793823e-01
    z[2,3,5]  R1157     -2.4501414597034454e-01
    z[2,3,5]  R1158     -2.0833808183670044e-01
    z[2,3,5]  R1159     -1.5545871853828430e-01
    z[2,3,5]  R1160     -1.2104744091629982e-02
    z[2,3,5]  R1161     -2.4415870010852814e-01
    z[2,3,5]  R1162     1.5470339357852936e-01
    z[2,3,5]  R1163     -1.3708001375198364e-01
    z[2,3,5]  R1164     -4.8285737633705139e-01
    z[2,3,5]  R1165     1.7897954583168030e-01
    z[2,3,5]  R1166     4.1876620054244995e-01
    z[2,3,5]  R1167     6.2775970436632633e-03
    z[2,3,5]  R1168     -1.4662048220634460e-01
    z[2,3,5]  R1169     1.0123351216316223e-01
    z[2,3,5]  R1170     4.1432702541351318e-01
    z[2,3,5]  R1171     2.8929945826530457e-01
    z[2,3,5]  R1172     -1.0790634900331497e-01
    z[2,3,5]  R1173     1.8880537152290344e-01
    z[2,3,5]  R1174     4.1776046156883240e-01
    z[2,3,5]  R1175     -4.5226030051708221e-02
    z[2,3,5]  R1176     -2.3367213085293770e-02
    z[2,3,5]  R1177     6.7532330751419067e-02
    z[2,3,5]  R1178     -1.6712664067745209e-01
    z[2,3,5]  R1179     -9.5498561859130859e-02
    z[2,3,5]  R1180     3.7924793362617493e-01
    z[2,3,5]  R1181     -5.3726937621831894e-02
    z[2,3,5]  R1182     4.1719831526279449e-02
    z[2,3,5]  R1183     1.7668071389198303e-01
    z[2,3,5]  R1184     -1.0164061188697815e-01
    z[2,3,5]  R1185     4.5092034339904785e-01
    z[2,3,5]  R1186     -8.1328481435775757e-02
    z[2,3,5]  R1187     -5.1702845096588135e-01
    z[2,3,5]  R1188     4.0486997365951538e-01
    z[2,3,5]  R1189     1.6480258107185364e-01
    z[2,3,5]  R1190     0.627466082572937
    z[2,3,5]  R1191     0.29982790350914
    z[2,3,5]  R1192     -2.3215073347091675e-01
    z[2,3,5]  R1193     1.1857450753450394e-01
    z[2,3,5]  R1194     -1.3388405740261078e-01
    z[2,3,5]  R1195     -7.0382517576217651e-01
    z[2,3,5]  R1196     1.1174259334802628e-01
    z[2,3,5]  R1197     2.1935574710369110e-01
    z[2,3,5]  R1198     -1.0182154178619385e-01
    z[2,3,5]  R1199     3.2961988449096680e-01
    z[2,3,5]  R1200     -2.5022733211517334e-01
    z[2,3,5]  R1201     1.4056839980185032e-02
    z[2,3,5]  R1202     -5.8268398046493530e-01
    z[2,3,5]  R1203     -2.6642149686813354e-01
    z[2,3,5]  R1204     -6.7784243822097778e-01
    z[2,3,5]  R1205     7.2239354252815247e-02
    z[2,3,5]  R1206     -8.8432334363460541e-02
    z[2,3,5]  R1207     5.2897727489471436e-01
    z[2,3,5]  R1208     2.8498110175132751e-01
    z[2,3,5]  R1209     -2.2599442303180695e-01
    z[2,3,5]  R1210     5.6194867938756943e-02
    z[2,3,5]  R1211     3.1944376230239868e-01
    z[2,3,5]  R1212     -4.6117216348648071e-01
    z[2,3,5]  R1213     2.5276523828506470e-01
    z[2,3,5]  R1214     -6.7564010620117188e-01
    z[2,3,5]  R1215     2.1172720938920975e-02
    z[2,3,5]  R1216     -4.0027502179145813e-01
    z[2,3,5]  R1217     -1.6390261054039001e-01
    z[2,3,5]  R1218     1.1652058362960815e-01
    z[2,3,5]  R1219     -1.5202715992927551e-01
    z[2,3,5]  R1220     -1.8972858786582947e-01
    z[2,3,5]  R1221     -4.7291836142539978e-01
    z[2,3,5]  R1222     -2.6897612214088440e-01
    z[2,3,5]  R1223     -2.3124687373638153e-01
    z[2,3,5]  R1224     -2.3645384609699249e-01
    z[2,3,5]  R1225     -3.5391256213188171e-02
    z[2,3,5]  R1226     2.5909817218780518e-01
    z[2,3,5]  R1227     -0.613033652305603
    z[2,3,5]  R1228     -2.3402197659015656e-01
    z[2,3,5]  R1229     -0.316095769405365
    z[2,3,5]  R1230     3.4054023027420044e-01
    z[2,3,5]  R1231     2.4003812670707703e-01
    z[2,3,5]  R1232     1.8813515082001686e-02
    z[2,3,5]  R1233     -3.4905764460563660e-01
    z[2,3,5]  R1234     -4.9916657805442810e-01
    z[2,3,5]  R1235     3.1575998663902283e-01
    z[2,3,5]  R1236     3.7309196591377258e-01
    z[2,3,5]  R1237     7.0639267563819885e-02
    z[2,3,5]  R1238     2.4038922786712646e-01
    z[2,3,5]  R1239     4.4128566980361938e-02
    z[2,3,5]  R1240     -2.6686057448387146e-01
    z[2,3,5]  R1241     -5.0679403543472290e-01
    z[2,3,5]  R1242     -1.3757790625095367e-01
    z[2,3,5]  R1243     -3.3155736327171326e-01
    z[2,3,5]  R1244     1.9013158977031708e-01
    z[2,3,5]  R1245     2.9067987203598022e-01
    z[2,3,5]  R1246     -2.9712867736816406e-01
    z[2,3,5]  R1247     -9.7113199532032013e-02
    z[2,3,5]  R1248     -4.4012613594532013e-02
    z[2,3,5]  R1249     2.5967252254486084e-01
    z[2,3,5]  R1250     -2.6901009678840637e-01
    z[2,3,5]  R1251     2.6603478193283081e-01
    z[2,3,5]  R1252     3.7837705016136169e-01
    z[2,3,5]  R1253     4.4696322083473206e-01
    z[2,3,5]  R1254     3.3983856439590454e-01
    z[2,3,5]  R1255     -1.0552906990051270e-01
    z[2,3,5]  R1256     2.3850056529045105e-01
    z[2,3,5]  R1257     -0.34966841340065
    z[2,3,5]  R1258     3.8474443554878235e-01
    z[2,3,5]  R1259     7.0009604096412659e-02
    z[2,3,5]  R1260     -1.1616861820220947e-01
    z[2,3,5]  R1261     -7.8402034938335419e-02
    z[2,3,5]  R1262     -3.5456646233797073e-02
    z[2,3,5]  R1263     4.7586232423782349e-01
    z[2,3,5]  R1264     0.0745057761669159
    z[2,3,5]  R1265     -7.6487839221954346e-01
    z[2,3,5]  R1266     -8.1545692682266235e-01
    z[2,3,5]  R1267     -6.6843688488006592e-01
    z[2,3,5]  R1268     -1.8858213722705841e-01
    z[2,3,5]  R1269     -2.8500708937644958e-01
    z[2,3,5]  R1270     -5.8723074197769165e-01
    z[2,3,5]  R1271     -4.9610987305641174e-01
    z[2,3,5]  R1272     -1.2263411283493042e-01
    z[2,3,5]  R1273     -7.1447348594665527e-01
    z[2,3,5]  R1274     1.4723853208124638e-02
    z[2,3,5]  R1275     -2.5184974074363708e-01
    z[2,3,5]  R1276     3.0484935641288757e-01
    z[2,3,5]  R1277     -3.5863202810287476e-01
    z[2,3,5]  R1278     1.1830098181962967e-01
    z[2,3,5]  R1279     2.0683903992176056e-01
    z[2,3,5]  R1280     2.4618925154209137e-01
    z[2,3,5]  R1281     3.5562586784362793e-01
    z[2,3,5]  R1282     -3.2573845237493515e-02
    z[2,3,5]  R1283     3.1028228998184204e-01
    z[2,3,5]  R1284     3.1595242023468018e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1153     -1
    z[2,3,6]  R1154     1
    z[2,3,6]  R1155     -1.6492843627929688e-01
    z[2,3,6]  R1156     -9.3961074948310852e-02
    z[2,3,6]  R1157     -3.5728029906749725e-02
    z[2,3,6]  R1158     -3.2833582162857056e-01
    z[2,3,6]  R1159     3.2686257362365723e-01
    z[2,3,6]  R1160     -1.4039170928299427e-02
    z[2,3,6]  R1161     1.2344378232955933e-01
    z[2,3,6]  R1162     -2.3563358187675476e-01
    z[2,3,6]  R1163     3.1386756896972656e-01
    z[2,3,6]  R1164     1.3855537772178650e-01
    z[2,3,6]  R1165     1.1553360521793365e-01
    z[2,3,6]  R1166     -1.8122033774852753e-01
    z[2,3,6]  R1167     -3.7590980529785156e-01
    z[2,3,6]  R1168     0.141273632645607
    z[2,3,6]  R1169     3.6761730909347534e-01
    z[2,3,6]  R1170     2.5172346830368042e-01
    z[2,3,6]  R1171     2.3954164981842041e-01
    z[2,3,6]  R1172     -3.3420255780220032e-01
    z[2,3,6]  R1173     -6.5239536762237549e-01
    z[2,3,6]  R1174     -4.3621074408292770e-02
    z[2,3,6]  R1175     -0.0518658272922039
    z[2,3,6]  R1176     8.8990144431591034e-03
    z[2,3,6]  R1177     1.0470316559076309e-01
    z[2,3,6]  R1178     1.0767577588558197e-01
    z[2,3,6]  R1179     -1.1672386527061462e-01
    z[2,3,6]  R1180     -1.2187291681766510e-01
    z[2,3,6]  R1181     2.5548562407493591e-02
    z[2,3,6]  R1182     0.0900566577911377
    z[2,3,6]  R1183     2.5914067402482033e-02
    z[2,3,6]  R1184     6.8382412195205688e-02
    z[2,3,6]  R1185     -8.4528736770153046e-02
    z[2,3,6]  R1186     -7.3306798934936523e-01
    z[2,3,6]  R1187     1.1163865774869919e-01
    z[2,3,6]  R1188     -1.9604042172431946e-02
    z[2,3,6]  R1189     -1.7284965515136719e-01
    z[2,3,6]  R1190     3.2818809151649475e-01
    z[2,3,6]  R1191     1.7801612615585327e-01
    z[2,3,6]  R1192     -1.3617551326751709e-01
    z[2,3,6]  R1193     -7.8074358403682709e-02
    z[2,3,6]  R1194     1.5174004435539246e-01
    z[2,3,6]  R1195     -0.193263441324234
    z[2,3,6]  R1196     -4.1548219323158264e-01
    z[2,3,6]  R1197     -2.0349536836147308e-01
    z[2,3,6]  R1198     4.5186790823936462e-01
    z[2,3,6]  R1199     -4.7979336231946945e-02
    z[2,3,6]  R1200     -2.2587533295154572e-01
    z[2,3,6]  R1201     -1.1849322170019150e-01
    z[2,3,6]  R1202     -8.2743220031261444e-02
    z[2,3,6]  R1203     -6.2936772592365742e-03
    z[2,3,6]  R1204     2.7090808749198914e-01
    z[2,3,6]  R1205     3.1304123997688293e-01
    z[2,3,6]  R1206     3.9663332700729370e-01
    z[2,3,6]  R1207     -1.3253666460514069e-01
    z[2,3,6]  R1208     -1.0549268918111920e-03
    z[2,3,6]  R1209     1.8261510878801346e-02
    z[2,3,6]  R1210     4.6634960174560547e-01
    z[2,3,6]  R1211     -2.5481829047203064e-01
    z[2,3,6]  R1212     1.9056017696857452e-01
    z[2,3,6]  R1213     4.2305365204811096e-01
    z[2,3,6]  R1214     -1.1774463579058647e-02
    z[2,3,6]  R1215     0.476979523897171
    z[2,3,6]  R1216     0.0441533662378788
    z[2,3,6]  R1217     4.3637722730636597e-01
    z[2,3,6]  R1218     -2.2750008106231689e-01
    z[2,3,6]  R1219     -5.1425302028656006e-01
    z[2,3,6]  R1220     -6.6892087459564209e-02
    z[2,3,6]  R1221     2.8757461905479431e-01
    z[2,3,6]  R1222     1.8163864314556122e-01
    z[2,3,6]  R1223     4.4809184968471527e-02
    z[2,3,6]  R1224     2.0869192481040955e-01
    z[2,3,6]  R1225     3.1698805093765259e-01
    z[2,3,6]  R1226     -3.1791147589683533e-01
    z[2,3,6]  R1227     -0.0218859501183033
    z[2,3,6]  R1228     3.3259138464927673e-01
    z[2,3,6]  R1229     -4.8471871018409729e-01
    z[2,3,6]  R1230     7.3627866804599762e-02
    z[2,3,6]  R1231     -0.210836723446846
    z[2,3,6]  R1232     -3.1659367680549622e-01
    z[2,3,6]  R1233     -1.3049063086509705e-01
    z[2,3,6]  R1234     -1.8533644080162048e-01
    z[2,3,6]  R1235     3.8289141654968262e-01
    z[2,3,6]  R1236     -2.6891345158219337e-02
    z[2,3,6]  R1237     1.3080124557018280e-01
    z[2,3,6]  R1238     -3.0868074297904968e-01
    z[2,3,6]  R1239     -4.4748479127883911e-01
    z[2,3,6]  R1240     9.9589407444000244e-02
    z[2,3,6]  R1241     -1.4063747227191925e-01
    z[2,3,6]  R1242     -0.0908326730132103
    z[2,3,6]  R1243     4.3805864453315735e-01
    z[2,3,6]  R1244     1.9548374414443970e-01
    z[2,3,6]  R1245     -1.3465739786624908e-01
    z[2,3,6]  R1246     -4.7352391481399536e-01
    z[2,3,6]  R1247     -4.0334376692771912e-01
    z[2,3,6]  R1248     -3.4171923995018005e-01
    z[2,3,6]  R1249     -0.0457824245095253
    z[2,3,6]  R1250     3.7002786993980408e-01
    z[2,3,6]  R1251     3.3452188968658447e-01
    z[2,3,6]  R1252     3.8959000259637833e-02
    z[2,3,6]  R1253     1.4366483688354492e-01
    z[2,3,6]  R1254     1.4029106497764587e-01
    z[2,3,6]  R1255     -1.8921458721160889e-01
    z[2,3,6]  R1256     -2.7679666876792908e-01
    z[2,3,6]  R1257     3.0307358503341675e-01
    z[2,3,6]  R1258     3.1549820303916931e-01
    z[2,3,6]  R1259     1.6601040959358215e-01
    z[2,3,6]  R1260     1.3481980189681053e-02
    z[2,3,6]  R1261     2.0826151967048645e-01
    z[2,3,6]  R1262     3.7093237042427063e-01
    z[2,3,6]  R1263     -7.5687073171138763e-02
    z[2,3,6]  R1264     -0.344025194644928
    z[2,3,6]  R1265     -3.8868039846420288e-02
    z[2,3,6]  R1266     1.7078292369842529e-01
    z[2,3,6]  R1267     6.9759249687194824e-02
    z[2,3,6]  R1268     -2.1688843145966530e-02
    z[2,3,6]  R1269     -1.9994966685771942e-01
    z[2,3,6]  R1270     -2.4667167663574219e-01
    z[2,3,6]  R1271     -2.4155495688319206e-02
    z[2,3,6]  R1272     -3.1171691417694092e-01
    z[2,3,6]  R1273     1.3359299302101135e-01
    z[2,3,6]  R1274     3.6421930789947510e-01
    z[2,3,6]  R1275     8.1820584833621979e-02
    z[2,3,6]  R1276     0.178999662399292
    z[2,3,6]  R1277     -3.2374124974012375e-02
    z[2,3,6]  R1278     -3.1008267402648926e-01
    z[2,3,6]  R1279     1.9876374304294586e-01
    z[2,3,6]  R1280     1.7755150794982910e-01
    z[2,3,6]  R1281     -3.0585335567593575e-02
    z[2,3,6]  R1282     2.4119900166988373e-01
    z[2,3,6]  R1283     -1.1051856726408005e-01
    z[2,3,6]  R1284     -2.6112416386604309e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1285     -1
    z[3,2,0]  R1286     1
    z[3,2,0]  R1299     2.7983114123344421e-01
    z[3,2,0]  R1300     4.5460104942321777e-01
    z[3,2,0]  R1301     5.2850371599197388e-01
    z[3,2,0]  R1302     7.4628823995590210e-01
    z[3,2,0]  R1303     6.7978280782699585e-01
    z[3,2,0]  R1304     5.0720679759979248e-01
    z[3,2,0]  R1305     -1.7386375367641449e-01
    z[3,2,0]  R1306     6.3635128736495972e-01
    z[3,2,0]  R1307     1.9838495645672083e-03
    z[3,2,0]  R1308     4.3724125623703003e-01
    z[3,2,0]  R1309     1.0943809896707535e-01
    z[3,2,0]  R1310     7.2360396385192871e-01
    z[3,2,0]  R1311     -0.41497603058815
    z[3,2,0]  R1312     -0.360065221786499
    z[3,2,0]  R1313     -4.2180991172790527e-01
    z[3,2,0]  R1314     -4.8004138469696045e-01
    z[3,2,0]  R1315     -4.3477049469947815e-01
    z[3,2,0]  R1316     -0.6156005859375
    z[3,2,0]  R1317     -3.2301768660545349e-01
    z[3,2,0]  R1318     -3.7379533052444458e-01
    z[3,2,0]  R1319     -7.0111936330795288e-01
    z[3,2,0]  R1320     -0.89290452003479
    z[3,2,0]  R1321     -5.5982106924057007e-01
    z[3,2,0]  R1322     -7.7223902940750122e-01
    z[3,2,0]  R1323     -5.1400977373123169e-01
    z[3,2,0]  R1324     -5.8208656311035156e-01
    z[3,2,0]  R1325     -7.0283114910125732e-01
    z[3,2,0]  R1326     -7.5358664989471436e-01
    z[3,2,0]  R1327     -8.4476613998413086e-01
    z[3,2,0]  R1328     -4.5482754707336426e-01
    z[3,2,0]  R1329     -1.1568231880664825e-01
    z[3,2,0]  R1330     -1.5688852965831757e-01
    z[3,2,0]  R1331     -1.5708351135253906e-01
    z[3,2,0]  R1332     0.698796272277832
    z[3,2,0]  R1333     7.0299059152603149e-01
    z[3,2,0]  R1334     6.8405562639236450e-01
    z[3,2,0]  R1335     5.8949434757232666e-01
    z[3,2,0]  R1336     7.7339643239974976e-01
    z[3,2,0]  R1337     5.5310606956481934e-01
    z[3,2,0]  R1338     6.3671547174453735e-01
    z[3,2,0]  R1339     -4.5417621731758118e-02
    z[3,2,0]  R1340     -1.3537852466106415e-01
    z[3,2,0]  R1341     7.9827654361724854e-01
    z[3,2,0]  R1342     7.7390931546688080e-02
    z[3,2,0]  R1343     1.1108760535717010e-01
    z[3,2,0]  R1344     6.6704463958740234e-01
    z[3,2,0]  R1345     -6.2267392873764038e-02
    z[3,2,0]  R1346     5.9514009952545166e-01
    z[3,2,0]  R1347     7.2336536645889282e-01
    z[3,2,0]  R1348     0.519419252872467
    z[3,2,0]  R1349     3.3257889747619629e-01
    z[3,2,0]  R1350     4.8302039504051208e-01
    z[3,2,0]  R1351     3.9415013790130615e-01
    z[3,2,0]  R1352     3.6163190007209778e-01
    z[3,2,0]  R1353     7.2397685050964355e-01
    z[3,2,0]  R1354     2.5747874751687050e-02
    z[3,2,0]  R1355     4.6654164791107178e-01
    z[3,2,0]  R1356     2.6764750480651855e-01
    z[3,2,0]  R1357     6.7203575372695923e-01
    z[3,2,0]  R1358     3.1270250678062439e-01
    z[3,2,0]  R1359     8.6481748148798943e-03
    z[3,2,0]  R1360     5.0570660829544067e-01
    z[3,2,0]  R1361     5.1533085107803345e-01
    z[3,2,0]  R1362     6.8787300586700439e-01
    z[3,2,0]  R1363     5.1636826992034912e-01
    z[3,2,0]  R1364     3.9412611722946167e-01
    z[3,2,0]  R1365     2.9528799653053284e-01
    z[3,2,0]  R1366     3.8233464956283569e-01
    z[3,2,0]  R1367     4.4280681014060974e-01
    z[3,2,0]  R1368     2.8501817584037781e-01
    z[3,2,0]  R1369     -6.6540159285068512e-02
    z[3,2,0]  R1370     7.2577208280563354e-01
    z[3,2,0]  R1371     6.4080274105072021e-01
    z[3,2,0]  R1372     4.1627743840217590e-01
    z[3,2,0]  R1373     5.0062882900238037e-01
    z[3,2,0]  R1374     4.2449519038200378e-01
    z[3,2,0]  R1375     0.635075032711029
    z[3,2,0]  R1376     3.4158974885940552e-01
    z[3,2,0]  R1377     1.6505779325962067e-01
    z[3,2,0]  R1378     2.9975670576095581e-01
    z[3,2,0]  R1379     -1.8692952394485474e-01
    z[3,2,0]  R1380     8.1349158287048340e-01
    z[3,2,0]  R1381     6.2359130382537842e-01
    z[3,2,0]  R1382     4.8640325665473938e-01
    z[3,2,0]  R1383     4.1923937201499939e-01
    z[3,2,0]  R1384     0.6805379986763
    z[3,2,0]  R1385     3.6483851075172424e-01
    z[3,2,0]  R1386     5.0083762407302856e-01
    z[3,2,0]  R1387     4.9331733584403992e-01
    z[3,2,0]  R1388     3.9891350269317627e-01
    z[3,2,0]  R1389     -1.6254135966300964e-01
    z[3,2,0]  R1390     -3.8926255702972412e-01
    z[3,2,0]  R1391     -1.3564291875809431e-03
    z[3,2,0]  R1392     6.3775193691253662e-01
    z[3,2,0]  R1393     -7.1092344820499420e-02
    z[3,2,0]  R1394     5.1004421710968018e-01
    z[3,2,0]  R1395     5.7516175508499146e-01
    z[3,2,0]  R1396     5.8088397979736328e-01
    z[3,2,0]  R1397     0.561552882194519
    z[3,2,0]  R1398     5.3413277864456177e-01
    z[3,2,0]  R1399     -3.9800170063972473e-01
    z[3,2,0]  R1400     -4.5562595129013062e-01
    z[3,2,0]  R1401     8.4574174880981445e-01
    z[3,2,0]  R1402     4.4838038086891174e-01
    z[3,2,0]  R1403     5.0031250715255737e-01
    z[3,2,0]  R1404     0.2799052298069
    z[3,2,0]  R1405     5.0745552778244019e-01
    z[3,2,0]  R1406     4.3456608057022095e-01
    z[3,2,0]  R1407     4.6067798137664795e-01
    z[3,2,0]  R1408     5.6948703527450562e-01
    z[3,2,0]  R1409     -3.5241582989692688e-01
    z[3,2,0]  R1410     -4.7572940587997437e-02
    z[3,2,0]  R1411     3.5930645465850830e-01
    z[3,2,0]  R1412     7.1881860494613647e-01
    z[3,2,0]  R1413     2.6641449332237244e-01
    z[3,2,0]  R1414     5.2527123689651489e-01
    z[3,2,0]  R1415     2.4020172655582428e-02
    z[3,2,0]  R1416     -2.5739121437072754e-01
    z[3,2,0]  R1417     -1.3720057904720306e-01
    z[3,2,0]  R1418     -0.0615449957549572
    z[3,2,0]  R1419     -7.6408244669437408e-02
    z[3,2,0]  R1420     6.9351524114608765e-01
    z[3,2,0]  R1421     4.3329709768295288e-01
    z[3,2,0]  R1422     -4.7730613499879837e-02
    z[3,2,0]  R1423     -2.0059393346309662e-01
    z[3,2,0]  R1424     -2.2417631745338440e-01
    z[3,2,0]  R1425     -2.9909706115722656e-01
    z[3,2,0]  R1426     -2.5791233777999878e-01
    z[3,2,0]  R1427     3.9937341213226318e-01
    z[3,2,0]  R1428     -3.0486646294593811e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1287     -1
    z[3,2,1]  R1288     1
    z[3,2,1]  R1299     0.505213737487793
    z[3,2,1]  R1300     -2.9188922047615051e-01
    z[3,2,1]  R1301     -2.7200677990913391e-01
    z[3,2,1]  R1302     -3.0819791555404663e-01
    z[3,2,1]  R1303     -4.9865084886550903e-01
    z[3,2,1]  R1304     -2.9265290498733521e-01
    z[3,2,1]  R1305     0.80692058801651
    z[3,2,1]  R1306     -5.2047246694564819e-01
    z[3,2,1]  R1307     1.3496515154838562e-01
    z[3,2,1]  R1308     -6.9121068716049194e-01
    z[3,2,1]  R1309     0.0921378806233406
    z[3,2,1]  R1310     2.1200199425220490e-01
    z[3,2,1]  R1311     -5.6763851642608643e-01
    z[3,2,1]  R1312     -8.2999789714813232e-01
    z[3,2,1]  R1313     -7.0515358448028564e-01
    z[3,2,1]  R1314     -4.0988948941230774e-01
    z[3,2,1]  R1315     -4.6646991372108459e-01
    z[3,2,1]  R1316     1.9349502027034760e-01
    z[3,2,1]  R1317     4.7425529360771179e-01
    z[3,2,1]  R1318     2.0977059006690979e-01
    z[3,2,1]  R1319     -4.4949498772621155e-01
    z[3,2,1]  R1320     -3.3479818701744080e-01
    z[3,2,1]  R1321     -4.0453898906707764e-01
    z[3,2,1]  R1322     -2.1958525478839874e-01
    z[3,2,1]  R1323     -4.5704743266105652e-01
    z[3,2,1]  R1324     -3.9728373289108276e-01
    z[3,2,1]  R1325     -4.2038300633430481e-01
    z[3,2,1]  R1326     -3.3675962686538696e-01
    z[3,2,1]  R1327     -3.1949669122695923e-01
    z[3,2,1]  R1328     -5.7820230722427368e-01
    z[3,2,1]  R1329     -4.9175927042961121e-01
    z[3,2,1]  R1330     -4.1158196330070496e-01
    z[3,2,1]  R1331     -2.6734501123428345e-01
    z[3,2,1]  R1332     -0.53836989402771
    z[3,2,1]  R1333     -0.342671275138855
    z[3,2,1]  R1334     -0.541056752204895
    z[3,2,1]  R1335     -5.0658035278320312e-01
    z[3,2,1]  R1336     -4.2686796188354492e-01
    z[3,2,1]  R1337     -4.5486468076705933e-01
    z[3,2,1]  R1338     -4.7082564234733582e-01
    z[3,2,1]  R1339     8.3409690856933594e-01
    z[3,2,1]  R1340     8.9928787946701050e-01
    z[3,2,1]  R1341     5.4799276590347290e-01
    z[3,2,1]  R1342     8.9229595661163330e-01
    z[3,2,1]  R1343     8.1544631719589233e-01
    z[3,2,1]  R1344     4.9941697716712952e-01
    z[3,2,1]  R1345     8.3573579788208008e-01
    z[3,2,1]  R1346     6.6910892724990845e-01
    z[3,2,1]  R1347     0.512220561504364
    z[3,2,1]  R1348     0.647648811340332
    z[3,2,1]  R1349     -0.624687135219574
    z[3,2,1]  R1350     -1.5297412872314453e-01
    z[3,2,1]  R1351     -3.5245409607887268e-01
    z[3,2,1]  R1352     3.9174661040306091e-01
    z[3,2,1]  R1353     5.8493453264236450e-01
    z[3,2,1]  R1354     -4.7863489389419556e-01
    z[3,2,1]  R1355     3.3903810381889343e-01
    z[3,2,1]  R1356     5.1297110319137573e-01
    z[3,2,1]  R1357     2.3550365865230560e-01
    z[3,2,1]  R1358     5.3314840793609619e-01
    z[3,2,1]  R1359     -2.4784113466739655e-01
    z[3,2,1]  R1360     -5.9990996122360229e-01
    z[3,2,1]  R1361     -4.7414350509643555e-01
    z[3,2,1]  R1362     -3.4876686334609985e-01
    z[3,2,1]  R1363     -3.4695991873741150e-01
    z[3,2,1]  R1364     4.0909501910209656e-01
    z[3,2,1]  R1365     -4.9234721809625626e-02
    z[3,2,1]  R1366     5.2433037757873535e-01
    z[3,2,1]  R1367     7.4485820531845093e-01
    z[3,2,1]  R1368     3.7005302309989929e-01
    z[3,2,1]  R1369     -5.4520559310913086e-01
    z[3,2,1]  R1370     -3.6321339011192322e-01
    z[3,2,1]  R1371     -3.1689906120300293e-01
    z[3,2,1]  R1372     4.6174535155296326e-01
    z[3,2,1]  R1373     3.0371323227882385e-01
    z[3,2,1]  R1374     4.5032000541687012e-01
    z[3,2,1]  R1375     3.2231101393699646e-01
    z[3,2,1]  R1376     3.0020135641098022e-01
    z[3,2,1]  R1377     7.2646868228912354e-01
    z[3,2,1]  R1378     2.7069088816642761e-01
    z[3,2,1]  R1379     -0.708975076675415
    z[3,2,1]  R1380     -3.2215201854705811e-01
    z[3,2,1]  R1381     -5.3843152523040771e-01
    z[3,2,1]  R1382     -6.7342722415924072e-01
    z[3,2,1]  R1383     -1.2217929214239120e-01
    z[3,2,1]  R1384     2.8495249152183533e-01
    z[3,2,1]  R1385     4.0100643038749695e-01
    z[3,2,1]  R1386     6.8663710355758667e-01
    z[3,2,1]  R1387     7.4688619375228882e-01
    z[3,2,1]  R1388     0.786733090877533
    z[3,2,1]  R1389     -5.9715646505355835e-01
    z[3,2,1]  R1390     -3.9939552545547485e-01
    z[3,2,1]  R1391     -0.359060674905777
    z[3,2,1]  R1392     -5.4217046499252319e-01
    z[3,2,1]  R1393     -3.9332851767539978e-01
    z[3,2,1]  R1394     -6.6162484884262085e-01
    z[3,2,1]  R1395     -6.2013298273086548e-01
    z[3,2,1]  R1396     -1.5233758091926575e-01
    z[3,2,1]  R1397     6.9876176118850708e-01
    z[3,2,1]  R1398     4.9144935607910156e-01
    z[3,2,1]  R1399     -6.2753462791442871e-01
    z[3,2,1]  R1400     -5.0875192880630493e-01
    z[3,2,1]  R1401     -3.8915121555328369e-01
    z[3,2,1]  R1402     -6.5223330259323120e-01
    z[3,2,1]  R1403     -2.3108184337615967e-01
    z[3,2,1]  R1404     4.8056399822235107e-01
    z[3,2,1]  R1405     6.7994487285614014e-01
    z[3,2,1]  R1406     7.9221922159194946e-01
    z[3,2,1]  R1407     6.3531875610351562e-01
    z[3,2,1]  R1408     0.653005838394165
    z[3,2,1]  R1409     -6.4434444904327393e-01
    z[3,2,1]  R1410     -0.489510715007782
    z[3,2,1]  R1411     -1.9995056092739105e-01
    z[3,2,1]  R1412     3.3218595385551453e-01
    z[3,2,1]  R1413     8.8451522588729858e-01
    z[3,2,1]  R1414     6.7061942815780640e-01
    z[3,2,1]  R1415     8.2782679796218872e-01
    z[3,2,1]  R1416     8.5486674308776855e-01
    z[3,2,1]  R1417     8.5490471124649048e-01
    z[3,2,1]  R1418     9.0760940313339233e-01
    z[3,2,1]  R1419     -6.9260370731353760e-01
    z[3,2,1]  R1420     3.5019379854202271e-01
    z[3,2,1]  R1421     7.1538847684860229e-01
    z[3,2,1]  R1422     8.1186813116073608e-01
    z[3,2,1]  R1423     9.3135637044906616e-01
    z[3,2,1]  R1424     9.2622154951095581e-01
    z[3,2,1]  R1425     7.4198907613754272e-01
    z[3,2,1]  R1426     7.0418852567672729e-01
    z[3,2,1]  R1427     6.0367500782012939e-01
    z[3,2,1]  R1428     8.0924779176712036e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1289     -1
    z[3,2,2]  R1290     1
    z[3,2,2]  R1299     9.6491836011409760e-02
    z[3,2,2]  R1300     1.0408055037260056e-01
    z[3,2,2]  R1301     -2.7911257743835449e-01
    z[3,2,2]  R1302     -1.6206982731819153e-01
    z[3,2,2]  R1303     2.9160779714584351e-01
    z[3,2,2]  R1304     1.2674829363822937e-01
    z[3,2,2]  R1305     9.7393020987510681e-02
    z[3,2,2]  R1306     -9.0242482721805573e-02
    z[3,2,2]  R1307     2.9007151722908020e-01
    z[3,2,2]  R1308     -1.8557514250278473e-01
    z[3,2,2]  R1309     -2.3937630653381348e-01
    z[3,2,2]  R1310     4.1321533918380737e-01
    z[3,2,2]  R1311     -4.4200602173805237e-01
    z[3,2,2]  R1312     5.5509600788354874e-02
    z[3,2,2]  R1313     1.0695017874240875e-01
    z[3,2,2]  R1314     -3.8250240683555603e-01
    z[3,2,2]  R1315     -4.8148775100708008e-01
    z[3,2,2]  R1316     -5.3229510784149170e-01
    z[3,2,2]  R1317     1.8213652074337006e-01
    z[3,2,2]  R1318     -0.0711749866604805
    z[3,2,2]  R1319     -8.3873413503170013e-02
    z[3,2,2]  R1320     -4.6433258801698685e-02
    z[3,2,2]  R1321     -2.2240121662616730e-01
    z[3,2,2]  R1322     -2.7171779423952103e-02
    z[3,2,2]  R1323     -3.3987402915954590e-01
    z[3,2,2]  R1324     -5.5712664127349854e-01
    z[3,2,2]  R1325     -1.9285935163497925e-01
    z[3,2,2]  R1326     -7.8938134014606476e-02
    z[3,2,2]  R1327     -2.2901487350463867e-01
    z[3,2,2]  R1328     -7.9810842871665955e-02
    z[3,2,2]  R1329     2.6303282380104065e-01
    z[3,2,2]  R1330     2.6568922400474548e-01
    z[3,2,2]  R1331     4.1921749711036682e-01
    z[3,2,2]  R1332     -9.8678901791572571e-02
    z[3,2,2]  R1333     -2.0471695065498352e-01
    z[3,2,2]  R1334     1.9106050953269005e-02
    z[3,2,2]  R1335     -3.7495499849319458e-01
    z[3,2,2]  R1336     0.246204674243927
    z[3,2,2]  R1337     -7.9527176916599274e-02
    z[3,2,2]  R1338     -4.0902385115623474e-01
    z[3,2,2]  R1339     2.3406212031841278e-01
    z[3,2,2]  R1340     2.1850508451461792e-01
    z[3,2,2]  R1341     2.0507957041263580e-01
    z[3,2,2]  R1342     2.8700596094131470e-01
    z[3,2,2]  R1343     1.1165440827608109e-01
    z[3,2,2]  R1344     2.7908065915107727e-01
    z[3,2,2]  R1345     1.8962990492582321e-02
    z[3,2,2]  R1346     4.4834561645984650e-02
    z[3,2,2]  R1347     2.2323322296142578e-01
    z[3,2,2]  R1348     1.2390603870153427e-01
    z[3,2,2]  R1349     0.0780886635184288
    z[3,2,2]  R1350     1.9408886134624481e-01
    z[3,2,2]  R1351     -4.8023164272308350e-01
    z[3,2,2]  R1352     2.6034104824066162e-01
    z[3,2,2]  R1353     1.3381375372409821e-01
    z[3,2,2]  R1354     4.1495844721794128e-01
    z[3,2,2]  R1355     1.1374760419130325e-01
    z[3,2,2]  R1356     -2.3696143925189972e-01
    z[3,2,2]  R1357     2.4504022300243378e-01
    z[3,2,2]  R1358     -5.6998956203460693e-01
    z[3,2,2]  R1359     2.1002964675426483e-01
    z[3,2,2]  R1360     1.1083374917507172e-01
    z[3,2,2]  R1361     -2.1317757666110992e-01
    z[3,2,2]  R1362     2.2484730929136276e-02
    z[3,2,2]  R1363     1.1564595997333527e-01
    z[3,2,2]  R1364     -3.6476936936378479e-01
    z[3,2,2]  R1365     -7.3987501859664917e-01
    z[3,2,2]  R1366     -2.7295741438865662e-01
    z[3,2,2]  R1367     -1.7261974513530731e-01
    z[3,2,2]  R1368     -3.0395638942718506e-01
    z[3,2,2]  R1369     -2.3103702813386917e-02
    z[3,2,2]  R1370     3.4460190683603287e-02
    z[3,2,2]  R1371     0.0395638681948185
    z[3,2,2]  R1372     2.0583797991275787e-01
    z[3,2,2]  R1373     2.0590786635875702e-01
    z[3,2,2]  R1374     2.1422188729047775e-02
    z[3,2,2]  R1375     3.2103773951530457e-01
    z[3,2,2]  R1376     1.3293132185935974e-01
    z[3,2,2]  R1377     1.5961390733718872e-01
    z[3,2,2]  R1378     -2.8850415349006653e-01
    z[3,2,2]  R1379     3.6791037768125534e-02
    z[3,2,2]  R1380     1.2451093643903732e-02
    z[3,2,2]  R1381     1.8904432363342494e-04
    z[3,2,2]  R1382     -3.2507389783859253e-01
    z[3,2,2]  R1383     0.0774095356464386
    z[3,2,2]  R1384     3.6462989449501038e-01
    z[3,2,2]  R1385     -4.1372212767601013e-01
    z[3,2,2]  R1386     -1.2415719032287598e-01
    z[3,2,2]  R1387     -0.0970790833234787
    z[3,2,2]  R1388     -2.9878395795822144e-01
    z[3,2,2]  R1389     1.2553636729717255e-01
    z[3,2,2]  R1390     3.5829934477806091e-01
    z[3,2,2]  R1391     2.2452621161937714e-01
    z[3,2,2]  R1392     -1.6520200669765472e-01
    z[3,2,2]  R1393     3.6298206448554993e-01
    z[3,2,2]  R1394     6.0138802975416183e-02
    z[3,2,2]  R1395     6.9822356104850769e-02
    z[3,2,2]  R1396     -3.4507915377616882e-02
    z[3,2,2]  R1397     2.3588884621858597e-02
    z[3,2,2]  R1398     1.5894058346748352e-01
    z[3,2,2]  R1399     2.1491686347872019e-03
    z[3,2,2]  R1400     1.8455219268798828e-01
    z[3,2,2]  R1401     -5.6969024240970612e-02
    z[3,2,2]  R1402     -2.6415362954139709e-01
    z[3,2,2]  R1403     1.1966821737587452e-02
    z[3,2,2]  R1404     -4.4037967920303345e-01
    z[3,2,2]  R1405     -2.6911085471510887e-02
    z[3,2,2]  R1406     -1.9403958320617676e-01
    z[3,2,2]  R1407     -2.5870782136917114e-01
    z[3,2,2]  R1408     -2.3429703712463379e-01
    z[3,2,2]  R1409     2.5956448912620544e-01
    z[3,2,2]  R1410     3.8324168324470520e-01
    z[3,2,2]  R1411     -0.618421196937561
    z[3,2,2]  R1412     4.4852638244628906e-01
    z[3,2,2]  R1413     1.7736503481864929e-01
    z[3,2,2]  R1414     -2.2517210245132446e-01
    z[3,2,2]  R1415     -8.2901574671268463e-02
    z[3,2,2]  R1416     2.7789219748228788e-03
    z[3,2,2]  R1417     -4.8508081585168839e-02
    z[3,2,2]  R1418     -5.1402464509010315e-02
    z[3,2,2]  R1419     2.8791493177413940e-01
    z[3,2,2]  R1420     4.8713916540145874e-01
    z[3,2,2]  R1421     -2.3065733909606934e-01
    z[3,2,2]  R1422     -7.4305996298789978e-02
    z[3,2,2]  R1423     -7.2838112711906433e-02
    z[3,2,2]  R1424     -1.8119428306818008e-02
    z[3,2,2]  R1425     -3.2035443931818008e-02
    z[3,2,2]  R1426     -0.0669550821185112
    z[3,2,2]  R1427     -4.0896505117416382e-01
    z[3,2,2]  R1428     0.145684614777565
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1291     -1
    z[3,2,3]  R1292     1
    z[3,2,3]  R1299     3.8233183324337006e-02
    z[3,2,3]  R1300     -5.6281287223100662e-02
    z[3,2,3]  R1301     -1.6667445003986359e-01
    z[3,2,3]  R1302     -1.1466748267412186e-01
    z[3,2,3]  R1303     2.0051820203661919e-02
    z[3,2,3]  R1304     1.4815273880958557e-01
    z[3,2,3]  R1305     -1.3428920507431030e-01
    z[3,2,3]  R1306     -4.4378823041915894e-01
    z[3,2,3]  R1307     -2.1803137660026550e-01
    z[3,2,3]  R1308     -3.4357210993766785e-01
    z[3,2,3]  R1309     -7.1974718570709229e-01
    z[3,2,3]  R1310     -3.4759324789047241e-01
    z[3,2,3]  R1311     -1.9642159342765808e-01
    z[3,2,3]  R1312     1.9086253643035889e-01
    z[3,2,3]  R1313     2.0496025681495667e-01
    z[3,2,3]  R1314     -7.6402656733989716e-02
    z[3,2,3]  R1315     1.2922681868076324e-01
    z[3,2,3]  R1316     3.9129105210304260e-01
    z[3,2,3]  R1317     5.7691287994384766e-01
    z[3,2,3]  R1318     -1.4007851481437683e-01
    z[3,2,3]  R1319     -3.1444865465164185e-01
    z[3,2,3]  R1320     -1.4626236259937286e-01
    z[3,2,3]  R1321     -5.8290481567382812e-01
    z[3,2,3]  R1322     -0.359375923871994
    z[3,2,3]  R1323     -4.0348294377326965e-01
    z[3,2,3]  R1324     -0.338177889585495
    z[3,2,3]  R1325     -1.1701557785272598e-01
    z[3,2,3]  R1326     -4.8129951953887939e-01
    z[3,2,3]  R1327     -0.119330033659935
    z[3,2,3]  R1328     -1.2594413757324219e-01
    z[3,2,3]  R1329     0.777704656124115
    z[3,2,3]  R1330     5.0404578447341919e-01
    z[3,2,3]  R1331     7.4074435234069824e-01
    z[3,2,3]  R1332     -3.2771375775337219e-01
    z[3,2,3]  R1333     -4.4695916771888733e-01
    z[3,2,3]  R1334     -1.6949616372585297e-02
    z[3,2,3]  R1335     8.2354426383972168e-02
    z[3,2,3]  R1336     9.8446160554885864e-02
    z[3,2,3]  R1337     1.3948664069175720e-01
    z[3,2,3]  R1338     7.8831324353814125e-03
    z[3,2,3]  R1339     -4.2408472299575806e-01
    z[3,2,3]  R1340     -3.1299224495887756e-01
    z[3,2,3]  R1341     3.4943778067827225e-02
    z[3,2,3]  R1342     -2.7338418364524841e-01
    z[3,2,3]  R1343     -5.3486210107803345e-01
    z[3,2,3]  R1344     1.8606856465339661e-01
    z[3,2,3]  R1345     -0.537039577960968
    z[3,2,3]  R1346     3.3837845921516418e-01
    z[3,2,3]  R1347     1.2361179292201996e-01
    z[3,2,3]  R1348     5.2461528778076172e-01
    z[3,2,3]  R1349     -2.7048733830451965e-01
    z[3,2,3]  R1350     -3.6922267079353333e-01
    z[3,2,3]  R1351     4.0404331684112549e-01
    z[3,2,3]  R1352     6.9523942470550537e-01
    z[3,2,3]  R1353     2.1272036433219910e-01
    z[3,2,3]  R1354     -5.4666560143232346e-02
    z[3,2,3]  R1355     0.553445041179657
    z[3,2,3]  R1356     -6.5014642477035522e-01
    z[3,2,3]  R1357     5.9282785654067993e-01
    z[3,2,3]  R1358     -4.9514451622962952e-01
    z[3,2,3]  R1359     5.3969818353652954e-01
    z[3,2,3]  R1360     -4.2107868194580078e-01
    z[3,2,3]  R1361     4.0940076112747192e-01
    z[3,2,3]  R1362     3.0737709999084473e-01
    z[3,2,3]  R1363     -9.6147827804088593e-02
    z[3,2,3]  R1364     -6.3931626081466675e-01
    z[3,2,3]  R1365     5.4876238107681274e-01
    z[3,2,3]  R1366     -3.9552164077758789e-01
    z[3,2,3]  R1367     -2.9253163933753967e-01
    z[3,2,3]  R1368     -3.9204615354537964e-01
    z[3,2,3]  R1369     2.5662720203399658e-01
    z[3,2,3]  R1370     2.6621833443641663e-01
    z[3,2,3]  R1371     -3.8232272863388062e-01
    z[3,2,3]  R1372     6.3889360427856445e-01
    z[3,2,3]  R1373     7.0790648460388184e-01
    z[3,2,3]  R1374     6.2034225463867188e-01
    z[3,2,3]  R1375     -4.5698079466819763e-01
    z[3,2,3]  R1376     6.6236847639083862e-01
    z[3,2,3]  R1377     -3.5968446731567383e-01
    z[3,2,3]  R1378     -5.0943839550018311e-01
    z[3,2,3]  R1379     0.479433536529541
    z[3,2,3]  R1380     -1.0581338405609131e-01
    z[3,2,3]  R1381     2.8363707661628723e-01
    z[3,2,3]  R1382     3.5104501247406006e-01
    z[3,2,3]  R1383     -2.9018688201904297e-01
    z[3,2,3]  R1384     -1.8076236546039581e-01
    z[3,2,3]  R1385     -4.5794364809989929e-01
    z[3,2,3]  R1386     -8.6128480732440948e-02
    z[3,2,3]  R1387     -1.3811598718166351e-01
    z[3,2,3]  R1388     -5.3824737668037415e-02
    z[3,2,3]  R1389     6.4488071203231812e-01
    z[3,2,3]  R1390     6.2346053123474121e-01
    z[3,2,3]  R1391     0.664882481098175
    z[3,2,3]  R1392     -3.2524743676185608e-01
    z[3,2,3]  R1393     5.5865764617919922e-01
    z[3,2,3]  R1394     -1.5654183924198151e-01
    z[3,2,3]  R1395     -2.9144337773323059e-01
    z[3,2,3]  R1396     -6.5572023391723633e-01
    z[3,2,3]  R1397     1.2729948759078979e-01
    z[3,2,3]  R1398     4.0542042255401611e-01
    z[3,2,3]  R1399     3.1787082552909851e-01
    z[3,2,3]  R1400     4.4996318221092224e-01
    z[3,2,3]  R1401     -3.1418710947036743e-01
    z[3,2,3]  R1402     3.8389632105827332e-01
    z[3,2,3]  R1403     -5.3141820430755615e-01
    z[3,2,3]  R1404     -0.643108606338501
    z[3,2,3]  R1405     -2.4881545454263687e-02
    z[3,2,3]  R1406     -2.0807598531246185e-01
    z[3,2,3]  R1407     -1.1604075133800507e-01
    z[3,2,3]  R1408     -0.272417277097702
    z[3,2,3]  R1409     4.8620399832725525e-01
    z[3,2,3]  R1410     5.2253186702728271e-01
    z[3,2,3]  R1411     0.405316561460495
    z[3,2,3]  R1412     -1.4786474406719208e-01
    z[3,2,3]  R1413     -1.6723164916038513e-01
    z[3,2,3]  R1414     -1.1875883489847183e-01
    z[3,2,3]  R1415     2.3033621907234192e-01
    z[3,2,3]  R1416     2.2643083333969116e-01
    z[3,2,3]  R1417     1.6457028687000275e-01
    z[3,2,3]  R1418     1.6401518881320953e-01
    z[3,2,3]  R1419     5.4490929841995239e-01
    z[3,2,3]  R1420     -8.8538669049739838e-02
    z[3,2,3]  R1421     -1.3700371980667114e-01
    z[3,2,3]  R1422     1.9309966266155243e-01
    z[3,2,3]  R1423     2.3324583470821381e-01
    z[3,2,3]  R1424     2.7790060639381409e-01
    z[3,2,3]  R1425     0.458374559879303
    z[3,2,3]  R1426     4.9108245968818665e-01
    z[3,2,3]  R1427     -2.0483481884002686e-01
    z[3,2,3]  R1428     3.1911596655845642e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1293     -1
    z[3,2,4]  R1294     1
    z[3,2,4]  R1299     2.6292881369590759e-01
    z[3,2,4]  R1300     1.1427477002143860e-03
    z[3,2,4]  R1301     2.9889410734176636e-01
    z[3,2,4]  R1302     5.2212929725646973e-01
    z[3,2,4]  R1303     2.8739643096923828e-01
    z[3,2,4]  R1304     4.6194615960121155e-01
    z[3,2,4]  R1305     -2.1076743304729462e-01
    z[3,2,4]  R1306     8.2869090139865875e-02
    z[3,2,4]  R1307     -5.6725829839706421e-01
    z[3,2,4]  R1308     -2.1376505494117737e-01
    z[3,2,4]  R1309     -5.7799136638641357e-01
    z[3,2,4]  R1310     -1.2210885435342789e-01
    z[3,2,4]  R1311     -3.7678331136703491e-01
    z[3,2,4]  R1312     -1.7832627892494202e-01
    z[3,2,4]  R1313     -4.3485438823699951e-01
    z[3,2,4]  R1314     0.597722053527832
    z[3,2,4]  R1315     4.6631014347076416e-01
    z[3,2,4]  R1316     2.9649755358695984e-01
    z[3,2,4]  R1317     4.4300094246864319e-01
    z[3,2,4]  R1318     7.8966683149337769e-01
    z[3,2,4]  R1319     7.6696373522281647e-02
    z[3,2,4]  R1320     -1.3601037859916687e-01
    z[3,2,4]  R1321     2.6907208561897278e-01
    z[3,2,4]  R1322     -2.7263644337654114e-01
    z[3,2,4]  R1323     -3.4290242195129395e-01
    z[3,2,4]  R1324     -2.7971944212913513e-01
    z[3,2,4]  R1325     -0.45118448138237
    z[3,2,4]  R1326     -3.6923289299011230e-02
    z[3,2,4]  R1327     -1.7339762300252914e-02
    z[3,2,4]  R1328     -4.2922419309616089e-01
    z[3,2,4]  R1329     1.5936696529388428e-01
    z[3,2,4]  R1330     5.2261584997177124e-01
    z[3,2,4]  R1331     -1.9508515298366547e-01
    z[3,2,4]  R1332     2.5149953365325928e-01
    z[3,2,4]  R1333     -3.6170445382595062e-02
    z[3,2,4]  R1334     6.0345385223627090e-02
    z[3,2,4]  R1335     3.2775735855102539e-01
    z[3,2,4]  R1336     -1.6123975813388824e-01
    z[3,2,4]  R1337     -1.1112906038761139e-02
    z[3,2,4]  R1338     -1.7066720128059387e-01
    z[3,2,4]  R1339     -2.5070169568061829e-01
    z[3,2,4]  R1340     -1.6315679252147675e-01
    z[3,2,4]  R1341     -0.0604669563472271
    z[3,2,4]  R1342     -3.4378089010715485e-02
    z[3,2,4]  R1343     3.7657979875802994e-02
    z[3,2,4]  R1344     -1.8559253215789795e-01
    z[3,2,4]  R1345     7.3197752237319946e-02
    z[3,2,4]  R1346     2.6784452795982361e-01
    z[3,2,4]  R1347     -3.4259593486785889e-01
    z[3,2,4]  R1348     -7.1928925812244415e-02
    z[3,2,4]  R1349     -4.5762622356414795e-01
    z[3,2,4]  R1350     -1.5903252363204956e-01
    z[3,2,4]  R1351     2.1625605225563049e-01
    z[3,2,4]  R1352     1.7825832590460777e-02
    z[3,2,4]  R1353     1.1625821888446808e-01
    z[3,2,4]  R1354     -3.0601578950881958e-01
    z[3,2,4]  R1355     4.7598907351493835e-01
    z[3,2,4]  R1356     -3.3756002783775330e-01
    z[3,2,4]  R1357     2.4750913679599762e-01
    z[3,2,4]  R1358     -8.3448909223079681e-02
    z[3,2,4]  R1359     0.265316367149353
    z[3,2,4]  R1360     -9.8314777016639709e-02
    z[3,2,4]  R1361     -4.5501780509948730e-01
    z[3,2,4]  R1362     -3.0927973985671997e-01
    z[3,2,4]  R1363     -6.9239658117294312e-01
    z[3,2,4]  R1364     1.4795464277267456e-01
    z[3,2,4]  R1365     -2.1814560890197754e-01
    z[3,2,4]  R1366     -3.9844788610935211e-02
    z[3,2,4]  R1367     2.5043150782585144e-01
    z[3,2,4]  R1368     5.3612012416124344e-02
    z[3,2,4]  R1369     7.2713029384613037e-01
    z[3,2,4]  R1370     -0.322696328163147
    z[3,2,4]  R1371     -2.0935116708278656e-01
    z[3,2,4]  R1372     2.8589293360710144e-01
    z[3,2,4]  R1373     2.4938410520553589e-01
    z[3,2,4]  R1374     1.0532125830650330e-01
    z[3,2,4]  R1375     -1.1799144744873047e-01
    z[3,2,4]  R1376     -2.9631054401397705e-01
    z[3,2,4]  R1377     -2.1745118498802185e-01
    z[3,2,4]  R1378     -1.9360281527042389e-01
    z[3,2,4]  R1379     5.6955549865961075e-02
    z[3,2,4]  R1380     -2.4683679640293121e-01
    z[3,2,4]  R1381     1.5325234830379486e-01
    z[3,2,4]  R1382     -1.2517413496971130e-01
    z[3,2,4]  R1383     6.5691810846328735e-01
    z[3,2,4]  R1384     4.9956849217414856e-01
    z[3,2,4]  R1385     1.3732229173183441e-01
    z[3,2,4]  R1386     -3.8667482137680054e-01
    z[3,2,4]  R1387     -3.3884474635124207e-01
    z[3,2,4]  R1388     -1.7403274774551392e-01
    z[3,2,4]  R1389     0.289171040058136
    z[3,2,4]  R1390     0.0606367364525795
    z[3,2,4]  R1391     -4.7994937747716904e-02
    z[3,2,4]  R1392     2.9373185709118843e-02
    z[3,2,4]  R1393     2.4802295863628387e-01
    z[3,2,4]  R1394     -3.9063632488250732e-01
    z[3,2,4]  R1395     3.0453100800514221e-01
    z[3,2,4]  R1396     -3.2805752754211426e-01
    z[3,2,4]  R1397     -2.0189037919044495e-01
    z[3,2,4]  R1398     -5.9273969382047653e-03
    z[3,2,4]  R1399     3.1691977381706238e-01
    z[3,2,4]  R1400     3.9639544486999512e-01
    z[3,2,4]  R1401     -9.6043810248374939e-02
    z[3,2,4]  R1402     -5.7641044259071350e-02
    z[3,2,4]  R1403     4.5994570851325989e-01
    z[3,2,4]  R1404     -4.5340526849031448e-02
    z[3,2,4]  R1405     4.6919766813516617e-02
    z[3,2,4]  R1406     -0.274619460105896
    z[3,2,4]  R1407     4.3874431401491165e-02
    z[3,2,4]  R1408     -0.214004248380661
    z[3,2,4]  R1409     2.3286873102188110e-01
    z[3,2,4]  R1410     -1.6028711199760437e-01
    z[3,2,4]  R1411     3.3477634191513062e-01
    z[3,2,4]  R1412     1.7664463818073273e-01
    z[3,2,4]  R1413     -1.3306210935115814e-01
    z[3,2,4]  R1414     -1.6326928511261940e-02
    z[3,2,4]  R1415     -2.6743057370185852e-01
    z[3,2,4]  R1416     -8.3587124943733215e-02
    z[3,2,4]  R1417     -2.1492704749107361e-02
    z[3,2,4]  R1418     -8.7991170585155487e-02
    z[3,2,4]  R1419     2.9614555835723877e-01
    z[3,2,4]  R1420     1.3326078653335571e-01
    z[3,2,4]  R1421     1.1991009861230850e-01
    z[3,2,4]  R1422     -2.1958047151565552e-01
    z[3,2,4]  R1423     -1.2943805195391178e-02
    z[3,2,4]  R1424     2.4993417784571648e-02
    z[3,2,4]  R1425     3.1518232822418213e-01
    z[3,2,4]  R1426     2.3044927418231964e-01
    z[3,2,4]  R1427     1.8626351654529572e-01
    z[3,2,4]  R1428     7.2187192738056183e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1295     -1
    z[3,2,5]  R1296     1
    z[3,2,5]  R1299     -7.6487839221954346e-01
    z[3,2,5]  R1300     -8.1545692682266235e-01
    z[3,2,5]  R1301     -6.6843688488006592e-01
    z[3,2,5]  R1302     -1.8858213722705841e-01
    z[3,2,5]  R1303     -2.8500708937644958e-01
    z[3,2,5]  R1304     -5.8723074197769165e-01
    z[3,2,5]  R1305     -4.9610987305641174e-01
    z[3,2,5]  R1306     -1.2263411283493042e-01
    z[3,2,5]  R1307     -7.1447348594665527e-01
    z[3,2,5]  R1308     1.4723853208124638e-02
    z[3,2,5]  R1309     -2.5184974074363708e-01
    z[3,2,5]  R1310     3.0484935641288757e-01
    z[3,2,5]  R1311     -3.5863202810287476e-01
    z[3,2,5]  R1312     1.1830098181962967e-01
    z[3,2,5]  R1313     2.0683903992176056e-01
    z[3,2,5]  R1314     2.4618925154209137e-01
    z[3,2,5]  R1315     3.5562586784362793e-01
    z[3,2,5]  R1316     -3.2573845237493515e-02
    z[3,2,5]  R1317     3.1028228998184204e-01
    z[3,2,5]  R1318     3.1595242023468018e-01
    z[3,2,5]  R1319     -4.0913251042366028e-01
    z[3,2,5]  R1320     -1.9938772916793823e-01
    z[3,2,5]  R1321     -2.4501414597034454e-01
    z[3,2,5]  R1322     -2.0833808183670044e-01
    z[3,2,5]  R1323     -1.5545871853828430e-01
    z[3,2,5]  R1324     -1.2104744091629982e-02
    z[3,2,5]  R1325     -2.4415870010852814e-01
    z[3,2,5]  R1326     1.5470339357852936e-01
    z[3,2,5]  R1327     -1.3708001375198364e-01
    z[3,2,5]  R1328     -4.8285737633705139e-01
    z[3,2,5]  R1329     1.7897954583168030e-01
    z[3,2,5]  R1330     4.1876620054244995e-01
    z[3,2,5]  R1331     6.2775970436632633e-03
    z[3,2,5]  R1332     -1.4662048220634460e-01
    z[3,2,5]  R1333     1.0123351216316223e-01
    z[3,2,5]  R1334     4.1432702541351318e-01
    z[3,2,5]  R1335     2.8929945826530457e-01
    z[3,2,5]  R1336     -1.0790634900331497e-01
    z[3,2,5]  R1337     1.8880537152290344e-01
    z[3,2,5]  R1338     4.1776046156883240e-01
    z[3,2,5]  R1339     -4.5226030051708221e-02
    z[3,2,5]  R1340     -2.3367213085293770e-02
    z[3,2,5]  R1341     6.7532330751419067e-02
    z[3,2,5]  R1342     -1.6712664067745209e-01
    z[3,2,5]  R1343     -9.5498561859130859e-02
    z[3,2,5]  R1344     3.7924793362617493e-01
    z[3,2,5]  R1345     -5.3726937621831894e-02
    z[3,2,5]  R1346     4.1719831526279449e-02
    z[3,2,5]  R1347     1.7668071389198303e-01
    z[3,2,5]  R1348     -1.0164061188697815e-01
    z[3,2,5]  R1349     4.5092034339904785e-01
    z[3,2,5]  R1350     -8.1328481435775757e-02
    z[3,2,5]  R1351     -5.1702845096588135e-01
    z[3,2,5]  R1352     4.0486997365951538e-01
    z[3,2,5]  R1353     1.6480258107185364e-01
    z[3,2,5]  R1354     0.627466082572937
    z[3,2,5]  R1355     0.29982790350914
    z[3,2,5]  R1356     -2.3215073347091675e-01
    z[3,2,5]  R1357     1.1857450753450394e-01
    z[3,2,5]  R1358     -1.3388405740261078e-01
    z[3,2,5]  R1359     -7.0382517576217651e-01
    z[3,2,5]  R1360     1.1174259334802628e-01
    z[3,2,5]  R1361     2.1935574710369110e-01
    z[3,2,5]  R1362     -1.0182154178619385e-01
    z[3,2,5]  R1363     3.2961988449096680e-01
    z[3,2,5]  R1364     -2.5022733211517334e-01
    z[3,2,5]  R1365     1.4056839980185032e-02
    z[3,2,5]  R1366     -5.8268398046493530e-01
    z[3,2,5]  R1367     -2.6642149686813354e-01
    z[3,2,5]  R1368     -6.7784243822097778e-01
    z[3,2,5]  R1369     7.2239354252815247e-02
    z[3,2,5]  R1370     -8.8432334363460541e-02
    z[3,2,5]  R1371     5.2897727489471436e-01
    z[3,2,5]  R1372     2.8498110175132751e-01
    z[3,2,5]  R1373     -2.2599442303180695e-01
    z[3,2,5]  R1374     5.6194867938756943e-02
    z[3,2,5]  R1375     3.1944376230239868e-01
    z[3,2,5]  R1376     -4.6117216348648071e-01
    z[3,2,5]  R1377     2.5276523828506470e-01
    z[3,2,5]  R1378     -6.7564010620117188e-01
    z[3,2,5]  R1379     2.1172720938920975e-02
    z[3,2,5]  R1380     -4.0027502179145813e-01
    z[3,2,5]  R1381     -1.6390261054039001e-01
    z[3,2,5]  R1382     1.1652058362960815e-01
    z[3,2,5]  R1383     -1.5202715992927551e-01
    z[3,2,5]  R1384     -1.8972858786582947e-01
    z[3,2,5]  R1385     -4.7291836142539978e-01
    z[3,2,5]  R1386     -2.6897612214088440e-01
    z[3,2,5]  R1387     -2.3124687373638153e-01
    z[3,2,5]  R1388     -2.3645384609699249e-01
    z[3,2,5]  R1389     -3.5391256213188171e-02
    z[3,2,5]  R1390     2.5909817218780518e-01
    z[3,2,5]  R1391     -0.613033652305603
    z[3,2,5]  R1392     -2.3402197659015656e-01
    z[3,2,5]  R1393     -0.316095769405365
    z[3,2,5]  R1394     3.4054023027420044e-01
    z[3,2,5]  R1395     2.4003812670707703e-01
    z[3,2,5]  R1396     1.8813515082001686e-02
    z[3,2,5]  R1397     -3.4905764460563660e-01
    z[3,2,5]  R1398     -4.9916657805442810e-01
    z[3,2,5]  R1399     3.1575998663902283e-01
    z[3,2,5]  R1400     3.7309196591377258e-01
    z[3,2,5]  R1401     7.0639267563819885e-02
    z[3,2,5]  R1402     2.4038922786712646e-01
    z[3,2,5]  R1403     4.4128566980361938e-02
    z[3,2,5]  R1404     -2.6686057448387146e-01
    z[3,2,5]  R1405     -5.0679403543472290e-01
    z[3,2,5]  R1406     -1.3757790625095367e-01
    z[3,2,5]  R1407     -3.3155736327171326e-01
    z[3,2,5]  R1408     1.9013158977031708e-01
    z[3,2,5]  R1409     2.9067987203598022e-01
    z[3,2,5]  R1410     -2.9712867736816406e-01
    z[3,2,5]  R1411     -9.7113199532032013e-02
    z[3,2,5]  R1412     -4.4012613594532013e-02
    z[3,2,5]  R1413     2.5967252254486084e-01
    z[3,2,5]  R1414     -2.6901009678840637e-01
    z[3,2,5]  R1415     2.6603478193283081e-01
    z[3,2,5]  R1416     3.7837705016136169e-01
    z[3,2,5]  R1417     4.4696322083473206e-01
    z[3,2,5]  R1418     3.3983856439590454e-01
    z[3,2,5]  R1419     -1.0552906990051270e-01
    z[3,2,5]  R1420     2.3850056529045105e-01
    z[3,2,5]  R1421     -0.34966841340065
    z[3,2,5]  R1422     3.8474443554878235e-01
    z[3,2,5]  R1423     7.0009604096412659e-02
    z[3,2,5]  R1424     -1.1616861820220947e-01
    z[3,2,5]  R1425     -7.8402034938335419e-02
    z[3,2,5]  R1426     -3.5456646233797073e-02
    z[3,2,5]  R1427     4.7586232423782349e-01
    z[3,2,5]  R1428     0.0745057761669159
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1297     -1
    z[3,2,6]  R1298     1
    z[3,2,6]  R1299     -3.8868039846420288e-02
    z[3,2,6]  R1300     1.7078292369842529e-01
    z[3,2,6]  R1301     6.9759249687194824e-02
    z[3,2,6]  R1302     -2.1688843145966530e-02
    z[3,2,6]  R1303     -1.9994966685771942e-01
    z[3,2,6]  R1304     -2.4667167663574219e-01
    z[3,2,6]  R1305     -2.4155495688319206e-02
    z[3,2,6]  R1306     -3.1171691417694092e-01
    z[3,2,6]  R1307     1.3359299302101135e-01
    z[3,2,6]  R1308     3.6421930789947510e-01
    z[3,2,6]  R1309     8.1820584833621979e-02
    z[3,2,6]  R1310     0.178999662399292
    z[3,2,6]  R1311     -3.2374124974012375e-02
    z[3,2,6]  R1312     -3.1008267402648926e-01
    z[3,2,6]  R1313     1.9876374304294586e-01
    z[3,2,6]  R1314     1.7755150794982910e-01
    z[3,2,6]  R1315     -3.0585335567593575e-02
    z[3,2,6]  R1316     2.4119900166988373e-01
    z[3,2,6]  R1317     -1.1051856726408005e-01
    z[3,2,6]  R1318     -2.6112416386604309e-01
    z[3,2,6]  R1319     -1.6492843627929688e-01
    z[3,2,6]  R1320     -9.3961074948310852e-02
    z[3,2,6]  R1321     -3.5728029906749725e-02
    z[3,2,6]  R1322     -3.2833582162857056e-01
    z[3,2,6]  R1323     3.2686257362365723e-01
    z[3,2,6]  R1324     -1.4039170928299427e-02
    z[3,2,6]  R1325     1.2344378232955933e-01
    z[3,2,6]  R1326     -2.3563358187675476e-01
    z[3,2,6]  R1327     3.1386756896972656e-01
    z[3,2,6]  R1328     1.3855537772178650e-01
    z[3,2,6]  R1329     1.1553360521793365e-01
    z[3,2,6]  R1330     -1.8122033774852753e-01
    z[3,2,6]  R1331     -3.7590980529785156e-01
    z[3,2,6]  R1332     0.141273632645607
    z[3,2,6]  R1333     3.6761730909347534e-01
    z[3,2,6]  R1334     2.5172346830368042e-01
    z[3,2,6]  R1335     2.3954164981842041e-01
    z[3,2,6]  R1336     -3.3420255780220032e-01
    z[3,2,6]  R1337     -6.5239536762237549e-01
    z[3,2,6]  R1338     -4.3621074408292770e-02
    z[3,2,6]  R1339     -0.0518658272922039
    z[3,2,6]  R1340     8.8990144431591034e-03
    z[3,2,6]  R1341     1.0470316559076309e-01
    z[3,2,6]  R1342     1.0767577588558197e-01
    z[3,2,6]  R1343     -1.1672386527061462e-01
    z[3,2,6]  R1344     -1.2187291681766510e-01
    z[3,2,6]  R1345     2.5548562407493591e-02
    z[3,2,6]  R1346     0.0900566577911377
    z[3,2,6]  R1347     2.5914067402482033e-02
    z[3,2,6]  R1348     6.8382412195205688e-02
    z[3,2,6]  R1349     -8.4528736770153046e-02
    z[3,2,6]  R1350     -7.3306798934936523e-01
    z[3,2,6]  R1351     1.1163865774869919e-01
    z[3,2,6]  R1352     -1.9604042172431946e-02
    z[3,2,6]  R1353     -1.7284965515136719e-01
    z[3,2,6]  R1354     3.2818809151649475e-01
    z[3,2,6]  R1355     1.7801612615585327e-01
    z[3,2,6]  R1356     -1.3617551326751709e-01
    z[3,2,6]  R1357     -7.8074358403682709e-02
    z[3,2,6]  R1358     1.5174004435539246e-01
    z[3,2,6]  R1359     -0.193263441324234
    z[3,2,6]  R1360     -4.1548219323158264e-01
    z[3,2,6]  R1361     -2.0349536836147308e-01
    z[3,2,6]  R1362     4.5186790823936462e-01
    z[3,2,6]  R1363     -4.7979336231946945e-02
    z[3,2,6]  R1364     -2.2587533295154572e-01
    z[3,2,6]  R1365     -1.1849322170019150e-01
    z[3,2,6]  R1366     -8.2743220031261444e-02
    z[3,2,6]  R1367     -6.2936772592365742e-03
    z[3,2,6]  R1368     2.7090808749198914e-01
    z[3,2,6]  R1369     3.1304123997688293e-01
    z[3,2,6]  R1370     3.9663332700729370e-01
    z[3,2,6]  R1371     -1.3253666460514069e-01
    z[3,2,6]  R1372     -1.0549268918111920e-03
    z[3,2,6]  R1373     1.8261510878801346e-02
    z[3,2,6]  R1374     4.6634960174560547e-01
    z[3,2,6]  R1375     -2.5481829047203064e-01
    z[3,2,6]  R1376     1.9056017696857452e-01
    z[3,2,6]  R1377     4.2305365204811096e-01
    z[3,2,6]  R1378     -1.1774463579058647e-02
    z[3,2,6]  R1379     0.476979523897171
    z[3,2,6]  R1380     0.0441533662378788
    z[3,2,6]  R1381     4.3637722730636597e-01
    z[3,2,6]  R1382     -2.2750008106231689e-01
    z[3,2,6]  R1383     -5.1425302028656006e-01
    z[3,2,6]  R1384     -6.6892087459564209e-02
    z[3,2,6]  R1385     2.8757461905479431e-01
    z[3,2,6]  R1386     1.8163864314556122e-01
    z[3,2,6]  R1387     4.4809184968471527e-02
    z[3,2,6]  R1388     2.0869192481040955e-01
    z[3,2,6]  R1389     3.1698805093765259e-01
    z[3,2,6]  R1390     -3.1791147589683533e-01
    z[3,2,6]  R1391     -0.0218859501183033
    z[3,2,6]  R1392     3.3259138464927673e-01
    z[3,2,6]  R1393     -4.8471871018409729e-01
    z[3,2,6]  R1394     7.3627866804599762e-02
    z[3,2,6]  R1395     -0.210836723446846
    z[3,2,6]  R1396     -3.1659367680549622e-01
    z[3,2,6]  R1397     -1.3049063086509705e-01
    z[3,2,6]  R1398     -1.8533644080162048e-01
    z[3,2,6]  R1399     3.8289141654968262e-01
    z[3,2,6]  R1400     -2.6891345158219337e-02
    z[3,2,6]  R1401     1.3080124557018280e-01
    z[3,2,6]  R1402     -3.0868074297904968e-01
    z[3,2,6]  R1403     -4.4748479127883911e-01
    z[3,2,6]  R1404     9.9589407444000244e-02
    z[3,2,6]  R1405     -1.4063747227191925e-01
    z[3,2,6]  R1406     -0.0908326730132103
    z[3,2,6]  R1407     4.3805864453315735e-01
    z[3,2,6]  R1408     1.9548374414443970e-01
    z[3,2,6]  R1409     -1.3465739786624908e-01
    z[3,2,6]  R1410     -4.7352391481399536e-01
    z[3,2,6]  R1411     -4.0334376692771912e-01
    z[3,2,6]  R1412     -3.4171923995018005e-01
    z[3,2,6]  R1413     -0.0457824245095253
    z[3,2,6]  R1414     3.7002786993980408e-01
    z[3,2,6]  R1415     3.3452188968658447e-01
    z[3,2,6]  R1416     3.8959000259637833e-02
    z[3,2,6]  R1417     1.4366483688354492e-01
    z[3,2,6]  R1418     1.4029106497764587e-01
    z[3,2,6]  R1419     -1.8921458721160889e-01
    z[3,2,6]  R1420     -2.7679666876792908e-01
    z[3,2,6]  R1421     3.0307358503341675e-01
    z[3,2,6]  R1422     3.1549820303916931e-01
    z[3,2,6]  R1423     1.6601040959358215e-01
    z[3,2,6]  R1424     1.3481980189681053e-02
    z[3,2,6]  R1425     2.0826151967048645e-01
    z[3,2,6]  R1426     3.7093237042427063e-01
    z[3,2,6]  R1427     -7.5687073171138763e-02
    z[3,2,6]  R1428     -0.344025194644928
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1429     -1
    z[2,4,0]  R1430     1
    z[2,4,0]  R1443     -7.0111936330795288e-01
    z[2,4,0]  R1444     -0.89290452003479
    z[2,4,0]  R1445     -5.5982106924057007e-01
    z[2,4,0]  R1446     -7.7223902940750122e-01
    z[2,4,0]  R1447     -5.1400977373123169e-01
    z[2,4,0]  R1448     -5.8208656311035156e-01
    z[2,4,0]  R1449     -7.0283114910125732e-01
    z[2,4,0]  R1450     -7.5358664989471436e-01
    z[2,4,0]  R1451     -8.4476613998413086e-01
    z[2,4,0]  R1452     -4.5482754707336426e-01
    z[2,4,0]  R1453     -1.1568231880664825e-01
    z[2,4,0]  R1454     -1.5688852965831757e-01
    z[2,4,0]  R1455     -1.5708351135253906e-01
    z[2,4,0]  R1456     0.698796272277832
    z[2,4,0]  R1457     7.0299059152603149e-01
    z[2,4,0]  R1458     6.8405562639236450e-01
    z[2,4,0]  R1459     5.8949434757232666e-01
    z[2,4,0]  R1460     7.7339643239974976e-01
    z[2,4,0]  R1461     5.5310606956481934e-01
    z[2,4,0]  R1462     6.3671547174453735e-01
    z[2,4,0]  R1463     -4.5417621731758118e-02
    z[2,4,0]  R1464     -1.3537852466106415e-01
    z[2,4,0]  R1465     7.9827654361724854e-01
    z[2,4,0]  R1466     7.7390931546688080e-02
    z[2,4,0]  R1467     1.1108760535717010e-01
    z[2,4,0]  R1468     6.6704463958740234e-01
    z[2,4,0]  R1469     -6.2267392873764038e-02
    z[2,4,0]  R1470     5.9514009952545166e-01
    z[2,4,0]  R1471     7.2336536645889282e-01
    z[2,4,0]  R1472     0.519419252872467
    z[2,4,0]  R1473     3.3257889747619629e-01
    z[2,4,0]  R1474     4.8302039504051208e-01
    z[2,4,0]  R1475     3.9415013790130615e-01
    z[2,4,0]  R1476     3.6163190007209778e-01
    z[2,4,0]  R1477     7.2397685050964355e-01
    z[2,4,0]  R1478     2.5747874751687050e-02
    z[2,4,0]  R1479     4.6654164791107178e-01
    z[2,4,0]  R1480     2.6764750480651855e-01
    z[2,4,0]  R1481     6.7203575372695923e-01
    z[2,4,0]  R1482     3.1270250678062439e-01
    z[2,4,0]  R1483     8.6481748148798943e-03
    z[2,4,0]  R1484     5.0570660829544067e-01
    z[2,4,0]  R1485     5.1533085107803345e-01
    z[2,4,0]  R1486     6.8787300586700439e-01
    z[2,4,0]  R1487     5.1636826992034912e-01
    z[2,4,0]  R1488     3.9412611722946167e-01
    z[2,4,0]  R1489     2.9528799653053284e-01
    z[2,4,0]  R1490     3.8233464956283569e-01
    z[2,4,0]  R1491     4.4280681014060974e-01
    z[2,4,0]  R1492     2.8501817584037781e-01
    z[2,4,0]  R1493     -6.6540159285068512e-02
    z[2,4,0]  R1494     7.2577208280563354e-01
    z[2,4,0]  R1495     6.4080274105072021e-01
    z[2,4,0]  R1496     4.1627743840217590e-01
    z[2,4,0]  R1497     5.0062882900238037e-01
    z[2,4,0]  R1498     4.2449519038200378e-01
    z[2,4,0]  R1499     0.635075032711029
    z[2,4,0]  R1500     3.4158974885940552e-01
    z[2,4,0]  R1501     1.6505779325962067e-01
    z[2,4,0]  R1502     2.9975670576095581e-01
    z[2,4,0]  R1503     -1.8692952394485474e-01
    z[2,4,0]  R1504     8.1349158287048340e-01
    z[2,4,0]  R1505     6.2359130382537842e-01
    z[2,4,0]  R1506     4.8640325665473938e-01
    z[2,4,0]  R1507     4.1923937201499939e-01
    z[2,4,0]  R1508     0.6805379986763
    z[2,4,0]  R1509     3.6483851075172424e-01
    z[2,4,0]  R1510     5.0083762407302856e-01
    z[2,4,0]  R1511     4.9331733584403992e-01
    z[2,4,0]  R1512     3.9891350269317627e-01
    z[2,4,0]  R1513     -1.6254135966300964e-01
    z[2,4,0]  R1514     -3.8926255702972412e-01
    z[2,4,0]  R1515     -1.3564291875809431e-03
    z[2,4,0]  R1516     6.3775193691253662e-01
    z[2,4,0]  R1517     -7.1092344820499420e-02
    z[2,4,0]  R1518     5.1004421710968018e-01
    z[2,4,0]  R1519     5.7516175508499146e-01
    z[2,4,0]  R1520     5.8088397979736328e-01
    z[2,4,0]  R1521     0.561552882194519
    z[2,4,0]  R1522     5.3413277864456177e-01
    z[2,4,0]  R1523     -3.9800170063972473e-01
    z[2,4,0]  R1524     -4.5562595129013062e-01
    z[2,4,0]  R1525     8.4574174880981445e-01
    z[2,4,0]  R1526     4.4838038086891174e-01
    z[2,4,0]  R1527     5.0031250715255737e-01
    z[2,4,0]  R1528     0.2799052298069
    z[2,4,0]  R1529     5.0745552778244019e-01
    z[2,4,0]  R1530     4.3456608057022095e-01
    z[2,4,0]  R1531     4.6067798137664795e-01
    z[2,4,0]  R1532     5.6948703527450562e-01
    z[2,4,0]  R1533     -3.5241582989692688e-01
    z[2,4,0]  R1534     -4.7572940587997437e-02
    z[2,4,0]  R1535     3.5930645465850830e-01
    z[2,4,0]  R1536     7.1881860494613647e-01
    z[2,4,0]  R1537     2.6641449332237244e-01
    z[2,4,0]  R1538     5.2527123689651489e-01
    z[2,4,0]  R1539     2.4020172655582428e-02
    z[2,4,0]  R1540     -2.5739121437072754e-01
    z[2,4,0]  R1541     -1.3720057904720306e-01
    z[2,4,0]  R1542     -0.0615449957549572
    z[2,4,0]  R1543     -7.6408244669437408e-02
    z[2,4,0]  R1544     6.9351524114608765e-01
    z[2,4,0]  R1545     4.3329709768295288e-01
    z[2,4,0]  R1546     -4.7730613499879837e-02
    z[2,4,0]  R1547     -2.0059393346309662e-01
    z[2,4,0]  R1548     -2.2417631745338440e-01
    z[2,4,0]  R1549     -2.9909706115722656e-01
    z[2,4,0]  R1550     -2.5791233777999878e-01
    z[2,4,0]  R1551     3.9937341213226318e-01
    z[2,4,0]  R1552     -3.0486646294593811e-01
    z[2,4,0]  R1553     -5.8755654096603394e-01
    z[2,4,0]  R1554     -0.550112783908844
    z[2,4,0]  R1555     -5.7592475414276123e-01
    z[2,4,0]  R1556     -6.1626744270324707e-01
    z[2,4,0]  R1557     -5.3182321786880493e-01
    z[2,4,0]  R1558     -6.7129796743392944e-01
    z[2,4,0]  R1559     -6.7024582624435425e-01
    z[2,4,0]  R1560     -5.8671534061431885e-01
    z[2,4,0]  R1561     -6.3573414087295532e-01
    z[2,4,0]  R1562     -7.6984459161758423e-01
    z[2,4,0]  R1563     2.2927865386009216e-01
    z[2,4,0]  R1564     6.8313342332839966e-01
    z[2,4,0]  R1565     7.1734535694122314e-01
    z[2,4,0]  R1566     -3.7486594915390015e-01
    z[2,4,0]  R1567     4.1173495352268219e-02
    z[2,4,0]  R1568     2.9657664895057678e-01
    z[2,4,0]  R1569     1.4933685958385468e-01
    z[2,4,0]  R1570     4.7259172797203064e-01
    z[2,4,0]  R1571     5.5157589912414551e-01
    z[2,4,0]  R1572     4.6082824468612671e-01
    z[2,4,0]  R1573     -1.1115819215774536e-01
    z[2,4,0]  R1574     -1.2880751863121986e-02
    z[2,4,0]  R1575     5.5273931473493576e-02
    z[2,4,0]  R1576     1.4118523895740509e-01
    z[2,4,0]  R1577     6.4345401525497437e-01
    z[2,4,0]  R1578     0.0411706306040287
    z[2,4,0]  R1579     2.1051850169897079e-02
    z[2,4,0]  R1580     3.9216777682304382e-01
    z[2,4,0]  R1581     3.2847228646278381e-01
    z[2,4,0]  R1582     -0.0661325603723526
    z[2,4,0]  R1583     1.6047385288402438e-03
    z[2,4,0]  R1584     1.1611460894346237e-01
    z[2,4,0]  R1585     2.0121926069259644e-01
    z[2,4,0]  R1586     -2.7605935931205750e-01
    z[2,4,0]  R1587     5.7087254524230957e-01
    z[2,4,0]  R1588     0.534482479095459
    z[2,4,0]  R1589     5.3874176740646362e-01
    z[2,4,0]  R1590     6.4456933736801147e-01
    z[2,4,0]  R1591     -2.6294299960136414e-01
    z[2,4,0]  R1592     1.6433918476104736e-01
    z[2,4,0]  R1593     9.2788405716419220e-02
    z[2,4,0]  R1594     8.6532514542341232e-03
    z[2,4,0]  R1595     -5.0115205347537994e-02
    z[2,4,0]  R1596     8.6147910356521606e-01
    z[2,4,0]  R1597     4.8253032565116882e-01
    z[2,4,0]  R1598     7.4361699819564819e-01
    z[2,4,0]  R1599     7.0720338821411133e-01
    z[2,4,0]  R1600     1.0208169370889664e-01
    z[2,4,0]  R1601     1.2148441374301910e-01
    z[2,4,0]  R1602     -1.1865770816802979e-01
    z[2,4,0]  R1603     -1.4550159871578217e-01
    z[2,4,0]  R1604     -3.6517471075057983e-02
    z[2,4,0]  R1605     -2.0804883539676666e-01
    z[2,4,0]  R1606     3.9359282702207565e-02
    z[2,4,0]  R1607     6.9649285078048706e-01
    z[2,4,0]  R1608     7.3793154954910278e-01
    z[2,4,0]  R1609     6.9981509447097778e-01
    z[2,4,0]  R1610     8.4909921884536743e-01
    z[2,4,0]  R1611     2.7244171500205994e-01
    z[2,4,0]  R1612     0.168548122048378
    z[2,4,0]  R1613     6.9429796934127808e-01
    z[2,4,0]  R1614     6.7381465435028076e-01
    z[2,4,0]  R1615     7.3634153604507446e-01
    z[2,4,0]  R1616     6.1560302972793579e-01
    z[2,4,0]  R1617     2.6052442193031311e-01
    z[2,4,0]  R1618     -1.2880542874336243e-01
    z[2,4,0]  R1619     -1.2372874468564987e-01
    z[2,4,0]  R1620     2.1286159753799438e-01
    z[2,4,0]  R1621     5.8649146556854248e-01
    z[2,4,0]  R1622     -1.5846298635005951e-01
    z[2,4,0]  R1623     -8.1728391349315643e-02
    z[2,4,0]  R1624     6.9623565673828125e-01
    z[2,4,0]  R1625     7.5372809171676636e-01
    z[2,4,0]  R1626     6.9946563243865967e-01
    z[2,4,0]  R1627     6.5266388654708862e-01
    z[2,4,0]  R1628     8.8066416978836060e-01
    z[2,4,0]  R1629     0.0986173152923584
    z[2,4,0]  R1630     -0.0824391320347786
    z[2,4,0]  R1631     1.0335975885391235e-01
    z[2,4,0]  R1632     -1.2979520484805107e-02
    z[2,4,0]  R1633     -0.0978812426328659
    z[2,4,0]  R1634     -4.1288039088249207e-01
    z[2,4,0]  R1635     -4.5653238892555237e-01
    z[2,4,0]  R1636     6.8289393186569214e-01
    z[2,4,0]  R1637     2.8496208786964417e-01
    z[2,4,0]  R1638     -1.0464946739375591e-02
    z[2,4,0]  R1639     1.7132751643657684e-01
    z[2,4,0]  R1640     -2.8915578126907349e-01
    z[2,4,0]  R1641     -2.0504486560821533e-01
    z[2,4,0]  R1642     3.2287436723709106e-01
    z[2,4,0]  R1643     0.789137065410614
    z[2,4,0]  R1644     7.2498601675033569e-01
    z[2,4,0]  R1645     7.4532598257064819e-01
    z[2,4,0]  R1646     7.3198574781417847e-01
    z[2,4,0]  R1647     -9.2089831829071045e-02
    z[2,4,0]  R1648     -7.7427178621292114e-02
    z[2,4,0]  R1649     1.8897749483585358e-01
    z[2,4,0]  R1650     4.4966783374547958e-02
    z[2,4,0]  R1651     4.8142012953758240e-01
    z[2,4,0]  R1652     6.7377209663391113e-01
    z[2,4,0]  R1653     7.4083232879638672e-01
    z[2,4,0]  R1654     5.7815268635749817e-02
    z[2,4,0]  R1655     2.0731888711452484e-01
    z[2,4,0]  R1656     1.8512832000851631e-02
    z[2,4,0]  R1657     3.2425409555435181e-01
    z[2,4,0]  R1658     2.0348079502582550e-01
    z[2,4,0]  R1659     5.5700516700744629e-01
    z[2,4,0]  R1660     4.3710514903068542e-01
    z[2,4,0]  R1661     5.9524399042129517e-01
    z[2,4,0]  R1662     4.2955505847930908e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1431     -1
    z[2,4,1]  R1432     1
    z[2,4,1]  R1443     -4.4949498772621155e-01
    z[2,4,1]  R1444     -3.3479818701744080e-01
    z[2,4,1]  R1445     -4.0453898906707764e-01
    z[2,4,1]  R1446     -2.1958525478839874e-01
    z[2,4,1]  R1447     -4.5704743266105652e-01
    z[2,4,1]  R1448     -3.9728373289108276e-01
    z[2,4,1]  R1449     -4.2038300633430481e-01
    z[2,4,1]  R1450     -3.3675962686538696e-01
    z[2,4,1]  R1451     -3.1949669122695923e-01
    z[2,4,1]  R1452     -5.7820230722427368e-01
    z[2,4,1]  R1453     -4.9175927042961121e-01
    z[2,4,1]  R1454     -4.1158196330070496e-01
    z[2,4,1]  R1455     -2.6734501123428345e-01
    z[2,4,1]  R1456     -0.53836989402771
    z[2,4,1]  R1457     -0.342671275138855
    z[2,4,1]  R1458     -0.541056752204895
    z[2,4,1]  R1459     -5.0658035278320312e-01
    z[2,4,1]  R1460     -4.2686796188354492e-01
    z[2,4,1]  R1461     -4.5486468076705933e-01
    z[2,4,1]  R1462     -4.7082564234733582e-01
    z[2,4,1]  R1463     8.3409690856933594e-01
    z[2,4,1]  R1464     8.9928787946701050e-01
    z[2,4,1]  R1465     5.4799276590347290e-01
    z[2,4,1]  R1466     8.9229595661163330e-01
    z[2,4,1]  R1467     8.1544631719589233e-01
    z[2,4,1]  R1468     4.9941697716712952e-01
    z[2,4,1]  R1469     8.3573579788208008e-01
    z[2,4,1]  R1470     6.6910892724990845e-01
    z[2,4,1]  R1471     0.512220561504364
    z[2,4,1]  R1472     0.647648811340332
    z[2,4,1]  R1473     -0.624687135219574
    z[2,4,1]  R1474     -1.5297412872314453e-01
    z[2,4,1]  R1475     -3.5245409607887268e-01
    z[2,4,1]  R1476     3.9174661040306091e-01
    z[2,4,1]  R1477     5.8493453264236450e-01
    z[2,4,1]  R1478     -4.7863489389419556e-01
    z[2,4,1]  R1479     3.3903810381889343e-01
    z[2,4,1]  R1480     5.1297110319137573e-01
    z[2,4,1]  R1481     2.3550365865230560e-01
    z[2,4,1]  R1482     5.3314840793609619e-01
    z[2,4,1]  R1483     -2.4784113466739655e-01
    z[2,4,1]  R1484     -5.9990996122360229e-01
    z[2,4,1]  R1485     -4.7414350509643555e-01
    z[2,4,1]  R1486     -3.4876686334609985e-01
    z[2,4,1]  R1487     -3.4695991873741150e-01
    z[2,4,1]  R1488     4.0909501910209656e-01
    z[2,4,1]  R1489     -4.9234721809625626e-02
    z[2,4,1]  R1490     5.2433037757873535e-01
    z[2,4,1]  R1491     7.4485820531845093e-01
    z[2,4,1]  R1492     3.7005302309989929e-01
    z[2,4,1]  R1493     -5.4520559310913086e-01
    z[2,4,1]  R1494     -3.6321339011192322e-01
    z[2,4,1]  R1495     -3.1689906120300293e-01
    z[2,4,1]  R1496     4.6174535155296326e-01
    z[2,4,1]  R1497     3.0371323227882385e-01
    z[2,4,1]  R1498     4.5032000541687012e-01
    z[2,4,1]  R1499     3.2231101393699646e-01
    z[2,4,1]  R1500     3.0020135641098022e-01
    z[2,4,1]  R1501     7.2646868228912354e-01
    z[2,4,1]  R1502     2.7069088816642761e-01
    z[2,4,1]  R1503     -0.708975076675415
    z[2,4,1]  R1504     -3.2215201854705811e-01
    z[2,4,1]  R1505     -5.3843152523040771e-01
    z[2,4,1]  R1506     -6.7342722415924072e-01
    z[2,4,1]  R1507     -1.2217929214239120e-01
    z[2,4,1]  R1508     2.8495249152183533e-01
    z[2,4,1]  R1509     4.0100643038749695e-01
    z[2,4,1]  R1510     6.8663710355758667e-01
    z[2,4,1]  R1511     7.4688619375228882e-01
    z[2,4,1]  R1512     0.786733090877533
    z[2,4,1]  R1513     -5.9715646505355835e-01
    z[2,4,1]  R1514     -3.9939552545547485e-01
    z[2,4,1]  R1515     -0.359060674905777
    z[2,4,1]  R1516     -5.4217046499252319e-01
    z[2,4,1]  R1517     -3.9332851767539978e-01
    z[2,4,1]  R1518     -6.6162484884262085e-01
    z[2,4,1]  R1519     -6.2013298273086548e-01
    z[2,4,1]  R1520     -1.5233758091926575e-01
    z[2,4,1]  R1521     6.9876176118850708e-01
    z[2,4,1]  R1522     4.9144935607910156e-01
    z[2,4,1]  R1523     -6.2753462791442871e-01
    z[2,4,1]  R1524     -5.0875192880630493e-01
    z[2,4,1]  R1525     -3.8915121555328369e-01
    z[2,4,1]  R1526     -6.5223330259323120e-01
    z[2,4,1]  R1527     -2.3108184337615967e-01
    z[2,4,1]  R1528     4.8056399822235107e-01
    z[2,4,1]  R1529     6.7994487285614014e-01
    z[2,4,1]  R1530     7.9221922159194946e-01
    z[2,4,1]  R1531     6.3531875610351562e-01
    z[2,4,1]  R1532     0.653005838394165
    z[2,4,1]  R1533     -6.4434444904327393e-01
    z[2,4,1]  R1534     -0.489510715007782
    z[2,4,1]  R1535     -1.9995056092739105e-01
    z[2,4,1]  R1536     3.3218595385551453e-01
    z[2,4,1]  R1537     8.8451522588729858e-01
    z[2,4,1]  R1538     6.7061942815780640e-01
    z[2,4,1]  R1539     8.2782679796218872e-01
    z[2,4,1]  R1540     8.5486674308776855e-01
    z[2,4,1]  R1541     8.5490471124649048e-01
    z[2,4,1]  R1542     9.0760940313339233e-01
    z[2,4,1]  R1543     -6.9260370731353760e-01
    z[2,4,1]  R1544     3.5019379854202271e-01
    z[2,4,1]  R1545     7.1538847684860229e-01
    z[2,4,1]  R1546     8.1186813116073608e-01
    z[2,4,1]  R1547     9.3135637044906616e-01
    z[2,4,1]  R1548     9.2622154951095581e-01
    z[2,4,1]  R1549     7.4198907613754272e-01
    z[2,4,1]  R1550     7.0418852567672729e-01
    z[2,4,1]  R1551     6.0367500782012939e-01
    z[2,4,1]  R1552     8.0924779176712036e-01
    z[2,4,1]  R1553     -3.5023787617683411e-01
    z[2,4,1]  R1554     -2.5114196538925171e-01
    z[2,4,1]  R1555     -3.5928779840469360e-01
    z[2,4,1]  R1556     -2.9726028442382812e-01
    z[2,4,1]  R1557     -5.5615627765655518e-01
    z[2,4,1]  R1558     -5.1980084180831909e-01
    z[2,4,1]  R1559     -4.0141481161117554e-01
    z[2,4,1]  R1560     -2.5546005368232727e-01
    z[2,4,1]  R1561     -0.32403364777565
    z[2,4,1]  R1562     -2.9785001277923584e-01
    z[2,4,1]  R1563     -7.1147876977920532e-01
    z[2,4,1]  R1564     -4.6179959177970886e-01
    z[2,4,1]  R1565     -3.7745356559753418e-01
    z[2,4,1]  R1566     7.5218003988265991e-01
    z[2,4,1]  R1567     -5.3693801164627075e-01
    z[2,4,1]  R1568     -6.2811189889907837e-01
    z[2,4,1]  R1569     -7.1127003431320190e-01
    z[2,4,1]  R1570     -4.3059056997299194e-01
    z[2,4,1]  R1571     -4.5296445488929749e-01
    z[2,4,1]  R1572     -4.9211472272872925e-01
    z[2,4,1]  R1573     -6.8705797195434570e-01
    z[2,4,1]  R1574     -3.8977241516113281e-01
    z[2,4,1]  R1575     7.1482799947261810e-02
    z[2,4,1]  R1576     -5.5262351036071777e-01
    z[2,4,1]  R1577     -5.0978618860244751e-01
    z[2,4,1]  R1578     7.4618428945541382e-01
    z[2,4,1]  R1579     8.8835489749908447e-01
    z[2,4,1]  R1580     -1.7341756820678711e-01
    z[2,4,1]  R1581     8.2127535343170166e-01
    z[2,4,1]  R1582     -0.522761881351471
    z[2,4,1]  R1583     -2.8531920909881592e-01
    z[2,4,1]  R1584     -5.0097370147705078e-01
    z[2,4,1]  R1585     -5.6872421503067017e-01
    z[2,4,1]  R1586     -4.4913262128829956e-01
    z[2,4,1]  R1587     -5.8296936750411987e-01
    z[2,4,1]  R1588     -5.0831443071365356e-01
    z[2,4,1]  R1589     -4.9253699183464050e-01
    z[2,4,1]  R1590     -1.8199425935745239e-01
    z[2,4,1]  R1591     5.9212136268615723e-01
    z[2,4,1]  R1592     8.6953115463256836e-01
    z[2,4,1]  R1593     -2.9620343446731567e-01
    z[2,4,1]  R1594     -8.4968489408493042e-01
    z[2,4,1]  R1595     -5.1040691137313843e-01
    z[2,4,1]  R1596     -2.2170072793960571e-01
    z[2,4,1]  R1597     -5.4525840282440186e-01
    z[2,4,1]  R1598     -1.0907662659883499e-01
    z[2,4,1]  R1599     -2.1314503252506256e-01
    z[2,4,1]  R1600     8.4723156690597534e-01
    z[2,4,1]  R1601     0.880919337272644
    z[2,4,1]  R1602     7.2155517339706421e-01
    z[2,4,1]  R1603     -0.628449022769928
    z[2,4,1]  R1604     -7.0719486474990845e-01
    z[2,4,1]  R1605     -8.2792568206787109e-01
    z[2,4,1]  R1606     -7.3079919815063477e-01
    z[2,4,1]  R1607     -6.0353887081146240e-01
    z[2,4,1]  R1608     -1.8426091969013214e-01
    z[2,4,1]  R1609     -4.6042034029960632e-01
    z[2,4,1]  R1610     -8.7848186492919922e-02
    z[2,4,1]  R1611     0.886595606803894
    z[2,4,1]  R1612     9.6384423971176147e-01
    z[2,4,1]  R1613     -4.5259761810302734e-01
    z[2,4,1]  R1614     -2.2987347841262817e-01
    z[2,4,1]  R1615     -0.301234632730484
    z[2,4,1]  R1616     -1.4728754758834839e-01
    z[2,4,1]  R1617     8.4514260292053223e-01
    z[2,4,1]  R1618     8.3458983898162842e-01
    z[2,4,1]  R1619     9.0441882610321045e-01
    z[2,4,1]  R1620     5.4224532842636108e-01
    z[2,4,1]  R1621     4.8052567243576050e-01
    z[2,4,1]  R1622     4.5277449488639832e-01
    z[2,4,1]  R1623     -0.736034631729126
    z[2,4,1]  R1624     -0.50221848487854
    z[2,4,1]  R1625     -2.9484912753105164e-01
    z[2,4,1]  R1626     -3.2997876405715942e-01
    z[2,4,1]  R1627     -3.0022957921028137e-01
    z[2,4,1]  R1628     -0.0613643079996109
    z[2,4,1]  R1629     8.3372437953948975e-01
    z[2,4,1]  R1630     0.959001362323761
    z[2,4,1]  R1631     8.2865160703659058e-01
    z[2,4,1]  R1632     8.6359906196594238e-01
    z[2,4,1]  R1633     -7.7929478883743286e-01
    z[2,4,1]  R1634     5.7339859008789062e-01
    z[2,4,1]  R1635     7.7785891294479370e-01
    z[2,4,1]  R1636     -0.228417307138443
    z[2,4,1]  R1637     6.4570468664169312e-01
    z[2,4,1]  R1638     0.749077558517456
    z[2,4,1]  R1639     7.8521335124969482e-01
    z[2,4,1]  R1640     6.2177753448486328e-01
    z[2,4,1]  R1641     5.0166165828704834e-01
    z[2,4,1]  R1642     6.4847087860107422e-01
    z[2,4,1]  R1643     -5.2170819044113159e-01
    z[2,4,1]  R1644     -2.6020979881286621e-01
    z[2,4,1]  R1645     -1.6403673589229584e-01
    z[2,4,1]  R1646     -2.5790682435035706e-01
    z[2,4,1]  R1647     7.9363530874252319e-01
    z[2,4,1]  R1648     9.5412641763687134e-01
    z[2,4,1]  R1649     9.1491103172302246e-01
    z[2,4,1]  R1650     0.478773295879364
    z[2,4,1]  R1651     0.548701286315918
    z[2,4,1]  R1652     6.0121679306030273e-01
    z[2,4,1]  R1653     -1.6934056580066681e-01
    z[2,4,1]  R1654     8.2446902990341187e-01
    z[2,4,1]  R1655     9.6358984708786011e-01
    z[2,4,1]  R1656     6.5812236070632935e-01
    z[2,4,1]  R1657     7.1535408496856689e-01
    z[2,4,1]  R1658     5.4849225282669067e-01
    z[2,4,1]  R1659     7.1080332994461060e-01
    z[2,4,1]  R1660     7.2019606828689575e-01
    z[2,4,1]  R1661     0.670100748538971
    z[2,4,1]  R1662     0.737332820892334
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1433     -1
    z[2,4,2]  R1434     1
    z[2,4,2]  R1443     -8.3873413503170013e-02
    z[2,4,2]  R1444     -4.6433258801698685e-02
    z[2,4,2]  R1445     -2.2240121662616730e-01
    z[2,4,2]  R1446     -2.7171779423952103e-02
    z[2,4,2]  R1447     -3.3987402915954590e-01
    z[2,4,2]  R1448     -5.5712664127349854e-01
    z[2,4,2]  R1449     -1.9285935163497925e-01
    z[2,4,2]  R1450     -7.8938134014606476e-02
    z[2,4,2]  R1451     -2.2901487350463867e-01
    z[2,4,2]  R1452     -7.9810842871665955e-02
    z[2,4,2]  R1453     2.6303282380104065e-01
    z[2,4,2]  R1454     2.6568922400474548e-01
    z[2,4,2]  R1455     4.1921749711036682e-01
    z[2,4,2]  R1456     -9.8678901791572571e-02
    z[2,4,2]  R1457     -2.0471695065498352e-01
    z[2,4,2]  R1458     1.9106050953269005e-02
    z[2,4,2]  R1459     -3.7495499849319458e-01
    z[2,4,2]  R1460     0.246204674243927
    z[2,4,2]  R1461     -7.9527176916599274e-02
    z[2,4,2]  R1462     -4.0902385115623474e-01
    z[2,4,2]  R1463     2.3406212031841278e-01
    z[2,4,2]  R1464     2.1850508451461792e-01
    z[2,4,2]  R1465     2.0507957041263580e-01
    z[2,4,2]  R1466     2.8700596094131470e-01
    z[2,4,2]  R1467     1.1165440827608109e-01
    z[2,4,2]  R1468     2.7908065915107727e-01
    z[2,4,2]  R1469     1.8962990492582321e-02
    z[2,4,2]  R1470     4.4834561645984650e-02
    z[2,4,2]  R1471     2.2323322296142578e-01
    z[2,4,2]  R1472     1.2390603870153427e-01
    z[2,4,2]  R1473     0.0780886635184288
    z[2,4,2]  R1474     1.9408886134624481e-01
    z[2,4,2]  R1475     -4.8023164272308350e-01
    z[2,4,2]  R1476     2.6034104824066162e-01
    z[2,4,2]  R1477     1.3381375372409821e-01
    z[2,4,2]  R1478     4.1495844721794128e-01
    z[2,4,2]  R1479     1.1374760419130325e-01
    z[2,4,2]  R1480     -2.3696143925189972e-01
    z[2,4,2]  R1481     2.4504022300243378e-01
    z[2,4,2]  R1482     -5.6998956203460693e-01
    z[2,4,2]  R1483     2.1002964675426483e-01
    z[2,4,2]  R1484     1.1083374917507172e-01
    z[2,4,2]  R1485     -2.1317757666110992e-01
    z[2,4,2]  R1486     2.2484730929136276e-02
    z[2,4,2]  R1487     1.1564595997333527e-01
    z[2,4,2]  R1488     -3.6476936936378479e-01
    z[2,4,2]  R1489     -7.3987501859664917e-01
    z[2,4,2]  R1490     -2.7295741438865662e-01
    z[2,4,2]  R1491     -1.7261974513530731e-01
    z[2,4,2]  R1492     -3.0395638942718506e-01
    z[2,4,2]  R1493     -2.3103702813386917e-02
    z[2,4,2]  R1494     3.4460190683603287e-02
    z[2,4,2]  R1495     0.0395638681948185
    z[2,4,2]  R1496     2.0583797991275787e-01
    z[2,4,2]  R1497     2.0590786635875702e-01
    z[2,4,2]  R1498     2.1422188729047775e-02
    z[2,4,2]  R1499     3.2103773951530457e-01
    z[2,4,2]  R1500     1.3293132185935974e-01
    z[2,4,2]  R1501     1.5961390733718872e-01
    z[2,4,2]  R1502     -2.8850415349006653e-01
    z[2,4,2]  R1503     3.6791037768125534e-02
    z[2,4,2]  R1504     1.2451093643903732e-02
    z[2,4,2]  R1505     1.8904432363342494e-04
    z[2,4,2]  R1506     -3.2507389783859253e-01
    z[2,4,2]  R1507     0.0774095356464386
    z[2,4,2]  R1508     3.6462989449501038e-01
    z[2,4,2]  R1509     -4.1372212767601013e-01
    z[2,4,2]  R1510     -1.2415719032287598e-01
    z[2,4,2]  R1511     -0.0970790833234787
    z[2,4,2]  R1512     -2.9878395795822144e-01
    z[2,4,2]  R1513     1.2553636729717255e-01
    z[2,4,2]  R1514     3.5829934477806091e-01
    z[2,4,2]  R1515     2.2452621161937714e-01
    z[2,4,2]  R1516     -1.6520200669765472e-01
    z[2,4,2]  R1517     3.6298206448554993e-01
    z[2,4,2]  R1518     6.0138802975416183e-02
    z[2,4,2]  R1519     6.9822356104850769e-02
    z[2,4,2]  R1520     -3.4507915377616882e-02
    z[2,4,2]  R1521     2.3588884621858597e-02
    z[2,4,2]  R1522     1.5894058346748352e-01
    z[2,4,2]  R1523     2.1491686347872019e-03
    z[2,4,2]  R1524     1.8455219268798828e-01
    z[2,4,2]  R1525     -5.6969024240970612e-02
    z[2,4,2]  R1526     -2.6415362954139709e-01
    z[2,4,2]  R1527     1.1966821737587452e-02
    z[2,4,2]  R1528     -4.4037967920303345e-01
    z[2,4,2]  R1529     -2.6911085471510887e-02
    z[2,4,2]  R1530     -1.9403958320617676e-01
    z[2,4,2]  R1531     -2.5870782136917114e-01
    z[2,4,2]  R1532     -2.3429703712463379e-01
    z[2,4,2]  R1533     2.5956448912620544e-01
    z[2,4,2]  R1534     3.8324168324470520e-01
    z[2,4,2]  R1535     -0.618421196937561
    z[2,4,2]  R1536     4.4852638244628906e-01
    z[2,4,2]  R1537     1.7736503481864929e-01
    z[2,4,2]  R1538     -2.2517210245132446e-01
    z[2,4,2]  R1539     -8.2901574671268463e-02
    z[2,4,2]  R1540     2.7789219748228788e-03
    z[2,4,2]  R1541     -4.8508081585168839e-02
    z[2,4,2]  R1542     -5.1402464509010315e-02
    z[2,4,2]  R1543     2.8791493177413940e-01
    z[2,4,2]  R1544     4.8713916540145874e-01
    z[2,4,2]  R1545     -2.3065733909606934e-01
    z[2,4,2]  R1546     -7.4305996298789978e-02
    z[2,4,2]  R1547     -7.2838112711906433e-02
    z[2,4,2]  R1548     -1.8119428306818008e-02
    z[2,4,2]  R1549     -3.2035443931818008e-02
    z[2,4,2]  R1550     -0.0669550821185112
    z[2,4,2]  R1551     -4.0896505117416382e-01
    z[2,4,2]  R1552     0.145684614777565
    z[2,4,2]  R1553     -1.9520850479602814e-01
    z[2,4,2]  R1554     9.2998119071125984e-03
    z[2,4,2]  R1555     -5.1382946968078613e-01
    z[2,4,2]  R1556     1.9087596237659454e-01
    z[2,4,2]  R1557     -1.3207024335861206e-01
    z[2,4,2]  R1558     -1.5683691203594208e-01
    z[2,4,2]  R1559     -3.3692610263824463e-01
    z[2,4,2]  R1560     -2.0341442525386810e-01
    z[2,4,2]  R1561     9.9804960191249847e-02
    z[2,4,2]  R1562     6.1308752745389938e-02
    z[2,4,2]  R1563     -2.7224181219935417e-02
    z[2,4,2]  R1564     1.4349375665187836e-01
    z[2,4,2]  R1565     -1.2734179198741913e-01
    z[2,4,2]  R1566     -2.1428765356540680e-01
    z[2,4,2]  R1567     7.2389543056488037e-01
    z[2,4,2]  R1568     5.6075859069824219e-01
    z[2,4,2]  R1569     4.6849995851516724e-01
    z[2,4,2]  R1570     -3.2706481218338013e-01
    z[2,4,2]  R1571     9.1979922726750374e-03
    z[2,4,2]  R1572     -5.4430490732192993e-01
    z[2,4,2]  R1573     5.6827646493911743e-01
    z[2,4,2]  R1574     -5.1286339759826660e-01
    z[2,4,2]  R1575     -0.46903195977211
    z[2,4,2]  R1576     1.9012993574142456e-01
    z[2,4,2]  R1577     -2.2154814004898071e-01
    z[2,4,2]  R1578     5.2097213268280029e-01
    z[2,4,2]  R1579     -1.8444817513227463e-02
    z[2,4,2]  R1580     6.6841256618499756e-01
    z[2,4,2]  R1581     3.9735755324363708e-01
    z[2,4,2]  R1582     -5.5841112136840820e-01
    z[2,4,2]  R1583     -1.5113285183906555e-01
    z[2,4,2]  R1584     1.7867620289325714e-01
    z[2,4,2]  R1585     5.4607796669006348e-01
    z[2,4,2]  R1586     -5.6303566694259644e-01
    z[2,4,2]  R1587     -3.3601748943328857e-01
    z[2,4,2]  R1588     -1.7890906333923340e-01
    z[2,4,2]  R1589     -1.4444294571876526e-01
    z[2,4,2]  R1590     -0.652751088142395
    z[2,4,2]  R1591     -3.9298117160797119e-01
    z[2,4,2]  R1592     9.1285429894924164e-02
    z[2,4,2]  R1593     -0.668785572052002
    z[2,4,2]  R1594     1.9610232114791870e-01
    z[2,4,2]  R1595     -7.2156423330307007e-01
    z[2,4,2]  R1596     1.7301666736602783e-01
    z[2,4,2]  R1597     -3.2959020137786865e-01
    z[2,4,2]  R1598     1.7456393688917160e-02
    z[2,4,2]  R1599     2.7208173274993896e-01
    z[2,4,2]  R1600     1.0649657994508743e-01
    z[2,4,2]  R1601     -0.0938347652554512
    z[2,4,2]  R1602     4.1236659884452820e-01
    z[2,4,2]  R1603     -0.494943231344223
    z[2,4,2]  R1604     -1.2691226601600647e-01
    z[2,4,2]  R1605     5.0492975860834122e-02
    z[2,4,2]  R1606     4.7204467654228210e-01
    z[2,4,2]  R1607     -8.4907226264476776e-02
    z[2,4,2]  R1608     -1.3565035164356232e-01
    z[2,4,2]  R1609     1.6225245594978333e-01
    z[2,4,2]  R1610     -1.5981492400169373e-01
    z[2,4,2]  R1611     0.0615328773856163
    z[2,4,2]  R1612     1.6760799288749695e-01
    z[2,4,2]  R1613     -1.1647468805313110e-01
    z[2,4,2]  R1614     2.5308451056480408e-01
    z[2,4,2]  R1615     -2.0218318328261375e-02
    z[2,4,2]  R1616     0.582478940486908
    z[2,4,2]  R1617     2.9166597127914429e-01
    z[2,4,2]  R1618     4.5439252257347107e-01
    z[2,4,2]  R1619     2.3995140194892883e-01
    z[2,4,2]  R1620     1.7692428827285767e-01
    z[2,4,2]  R1621     3.7672752141952515e-01
    z[2,4,2]  R1622     1.2909972667694092e-01
    z[2,4,2]  R1623     6.1129800975322723e-02
    z[2,4,2]  R1624     4.1504953987896442e-03
    z[2,4,2]  R1625     3.5807663202285767e-01
    z[2,4,2]  R1626     1.4697174727916718e-01
    z[2,4,2]  R1627     -2.2409553825855255e-01
    z[2,4,2]  R1628     -1.0674206167459488e-01
    z[2,4,2]  R1629     2.6567617058753967e-01
    z[2,4,2]  R1630     1.8880042433738708e-01
    z[2,4,2]  R1631     3.4775212407112122e-01
    z[2,4,2]  R1632     -0.073155976831913
    z[2,4,2]  R1633     5.9725141525268555e-01
    z[2,4,2]  R1634     -9.0044438838958740e-02
    z[2,4,2]  R1635     3.5335725545883179e-01
    z[2,4,2]  R1636     -4.3700179457664490e-01
    z[2,4,2]  R1637     2.0539747178554535e-01
    z[2,4,2]  R1638     2.1612955629825592e-01
    z[2,4,2]  R1639     3.0064875259995461e-02
    z[2,4,2]  R1640     2.0245923101902008e-01
    z[2,4,2]  R1641     2.1178799867630005e-01
    z[2,4,2]  R1642     -3.9450940489768982e-01
    z[2,4,2]  R1643     4.3772339820861816e-02
    z[2,4,2]  R1644     -4.0393903851509094e-02
    z[2,4,2]  R1645     9.4932131469249725e-02
    z[2,4,2]  R1646     -3.7179183959960938e-01
    z[2,4,2]  R1647     2.8107839822769165e-01
    z[2,4,2]  R1648     1.8511307239532471e-01
    z[2,4,2]  R1649     -1.2274567782878876e-01
    z[2,4,2]  R1650     1.3293507695198059e-01
    z[2,4,2]  R1651     2.1158735454082489e-01
    z[2,4,2]  R1652     -5.7536359876394272e-02
    z[2,4,2]  R1653     3.7202858924865723e-01
    z[2,4,2]  R1654     2.4892997741699219e-01
    z[2,4,2]  R1655     6.7938235588371754e-03
    z[2,4,2]  R1656     2.5844931602478027e-01
    z[2,4,2]  R1657     1.1316926218569279e-02
    z[2,4,2]  R1658     6.3249832019209862e-03
    z[2,4,2]  R1659     -2.2752940654754639e-01
    z[2,4,2]  R1660     -3.5796791315078735e-01
    z[2,4,2]  R1661     -2.9539284110069275e-01
    z[2,4,2]  R1662     -1.9871445000171661e-01
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1435     -1
    z[2,4,3]  R1436     1
    z[2,4,3]  R1443     -3.1444865465164185e-01
    z[2,4,3]  R1444     -1.4626236259937286e-01
    z[2,4,3]  R1445     -5.8290481567382812e-01
    z[2,4,3]  R1446     -0.359375923871994
    z[2,4,3]  R1447     -4.0348294377326965e-01
    z[2,4,3]  R1448     -0.338177889585495
    z[2,4,3]  R1449     -1.1701557785272598e-01
    z[2,4,3]  R1450     -4.8129951953887939e-01
    z[2,4,3]  R1451     -0.119330033659935
    z[2,4,3]  R1452     -1.2594413757324219e-01
    z[2,4,3]  R1453     0.777704656124115
    z[2,4,3]  R1454     5.0404578447341919e-01
    z[2,4,3]  R1455     7.4074435234069824e-01
    z[2,4,3]  R1456     -3.2771375775337219e-01
    z[2,4,3]  R1457     -4.4695916771888733e-01
    z[2,4,3]  R1458     -1.6949616372585297e-02
    z[2,4,3]  R1459     8.2354426383972168e-02
    z[2,4,3]  R1460     9.8446160554885864e-02
    z[2,4,3]  R1461     1.3948664069175720e-01
    z[2,4,3]  R1462     7.8831324353814125e-03
    z[2,4,3]  R1463     -4.2408472299575806e-01
    z[2,4,3]  R1464     -3.1299224495887756e-01
    z[2,4,3]  R1465     3.4943778067827225e-02
    z[2,4,3]  R1466     -2.7338418364524841e-01
    z[2,4,3]  R1467     -5.3486210107803345e-01
    z[2,4,3]  R1468     1.8606856465339661e-01
    z[2,4,3]  R1469     -0.537039577960968
    z[2,4,3]  R1470     3.3837845921516418e-01
    z[2,4,3]  R1471     1.2361179292201996e-01
    z[2,4,3]  R1472     5.2461528778076172e-01
    z[2,4,3]  R1473     -2.7048733830451965e-01
    z[2,4,3]  R1474     -3.6922267079353333e-01
    z[2,4,3]  R1475     4.0404331684112549e-01
    z[2,4,3]  R1476     6.9523942470550537e-01
    z[2,4,3]  R1477     2.1272036433219910e-01
    z[2,4,3]  R1478     -5.4666560143232346e-02
    z[2,4,3]  R1479     0.553445041179657
    z[2,4,3]  R1480     -6.5014642477035522e-01
    z[2,4,3]  R1481     5.9282785654067993e-01
    z[2,4,3]  R1482     -4.9514451622962952e-01
    z[2,4,3]  R1483     5.3969818353652954e-01
    z[2,4,3]  R1484     -4.2107868194580078e-01
    z[2,4,3]  R1485     4.0940076112747192e-01
    z[2,4,3]  R1486     3.0737709999084473e-01
    z[2,4,3]  R1487     -9.6147827804088593e-02
    z[2,4,3]  R1488     -6.3931626081466675e-01
    z[2,4,3]  R1489     5.4876238107681274e-01
    z[2,4,3]  R1490     -3.9552164077758789e-01
    z[2,4,3]  R1491     -2.9253163933753967e-01
    z[2,4,3]  R1492     -3.9204615354537964e-01
    z[2,4,3]  R1493     2.5662720203399658e-01
    z[2,4,3]  R1494     2.6621833443641663e-01
    z[2,4,3]  R1495     -3.8232272863388062e-01
    z[2,4,3]  R1496     6.3889360427856445e-01
    z[2,4,3]  R1497     7.0790648460388184e-01
    z[2,4,3]  R1498     6.2034225463867188e-01
    z[2,4,3]  R1499     -4.5698079466819763e-01
    z[2,4,3]  R1500     6.6236847639083862e-01
    z[2,4,3]  R1501     -3.5968446731567383e-01
    z[2,4,3]  R1502     -5.0943839550018311e-01
    z[2,4,3]  R1503     0.479433536529541
    z[2,4,3]  R1504     -1.0581338405609131e-01
    z[2,4,3]  R1505     2.8363707661628723e-01
    z[2,4,3]  R1506     3.5104501247406006e-01
    z[2,4,3]  R1507     -2.9018688201904297e-01
    z[2,4,3]  R1508     -1.8076236546039581e-01
    z[2,4,3]  R1509     -4.5794364809989929e-01
    z[2,4,3]  R1510     -8.6128480732440948e-02
    z[2,4,3]  R1511     -1.3811598718166351e-01
    z[2,4,3]  R1512     -5.3824737668037415e-02
    z[2,4,3]  R1513     6.4488071203231812e-01
    z[2,4,3]  R1514     6.2346053123474121e-01
    z[2,4,3]  R1515     0.664882481098175
    z[2,4,3]  R1516     -3.2524743676185608e-01
    z[2,4,3]  R1517     5.5865764617919922e-01
    z[2,4,3]  R1518     -1.5654183924198151e-01
    z[2,4,3]  R1519     -2.9144337773323059e-01
    z[2,4,3]  R1520     -6.5572023391723633e-01
    z[2,4,3]  R1521     1.2729948759078979e-01
    z[2,4,3]  R1522     4.0542042255401611e-01
    z[2,4,3]  R1523     3.1787082552909851e-01
    z[2,4,3]  R1524     4.4996318221092224e-01
    z[2,4,3]  R1525     -3.1418710947036743e-01
    z[2,4,3]  R1526     3.8389632105827332e-01
    z[2,4,3]  R1527     -5.3141820430755615e-01
    z[2,4,3]  R1528     -0.643108606338501
    z[2,4,3]  R1529     -2.4881545454263687e-02
    z[2,4,3]  R1530     -2.0807598531246185e-01
    z[2,4,3]  R1531     -1.1604075133800507e-01
    z[2,4,3]  R1532     -0.272417277097702
    z[2,4,3]  R1533     4.8620399832725525e-01
    z[2,4,3]  R1534     5.2253186702728271e-01
    z[2,4,3]  R1535     0.405316561460495
    z[2,4,3]  R1536     -1.4786474406719208e-01
    z[2,4,3]  R1537     -1.6723164916038513e-01
    z[2,4,3]  R1538     -1.1875883489847183e-01
    z[2,4,3]  R1539     2.3033621907234192e-01
    z[2,4,3]  R1540     2.2643083333969116e-01
    z[2,4,3]  R1541     1.6457028687000275e-01
    z[2,4,3]  R1542     1.6401518881320953e-01
    z[2,4,3]  R1543     5.4490929841995239e-01
    z[2,4,3]  R1544     -8.8538669049739838e-02
    z[2,4,3]  R1545     -1.3700371980667114e-01
    z[2,4,3]  R1546     1.9309966266155243e-01
    z[2,4,3]  R1547     2.3324583470821381e-01
    z[2,4,3]  R1548     2.7790060639381409e-01
    z[2,4,3]  R1549     0.458374559879303
    z[2,4,3]  R1550     4.9108245968818665e-01
    z[2,4,3]  R1551     -2.0483481884002686e-01
    z[2,4,3]  R1552     3.1911596655845642e-01
    z[2,4,3]  R1553     -3.6240240931510925e-01
    z[2,4,3]  R1554     -5.8406364917755127e-01
    z[2,4,3]  R1555     -3.9486807584762573e-01
    z[2,4,3]  R1556     -4.8408702015876770e-01
    z[2,4,3]  R1557     -2.6580053567886353e-01
    z[2,4,3]  R1558     -1.0204381495714188e-01
    z[2,4,3]  R1559     -2.9818978905677795e-01
    z[2,4,3]  R1560     -4.7207662463188171e-01
    z[2,4,3]  R1561     -4.9308976531028748e-01
    z[2,4,3]  R1562     -4.1535407304763794e-01
    z[2,4,3]  R1563     -1.7730298638343811e-01
    z[2,4,3]  R1564     9.8836747929453850e-03
    z[2,4,3]  R1565     6.6793225705623627e-02
    z[2,4,3]  R1566     2.3008877038955688e-01
    z[2,4,3]  R1567     3.6241963505744934e-01
    z[2,4,3]  R1568     1.1827819049358368e-01
    z[2,4,3]  R1569     4.2783892154693604e-01
    z[2,4,3]  R1570     0.361988365650177
    z[2,4,3]  R1571     1.6963206231594086e-01
    z[2,4,3]  R1572     3.9747819304466248e-01
    z[2,4,3]  R1573     2.1296314895153046e-01
    z[2,4,3]  R1574     1.4430669136345387e-02
    z[2,4,3]  R1575     -3.5894379019737244e-01
    z[2,4,3]  R1576     -5.8972876518964767e-02
    z[2,4,3]  R1577     -1.3377124071121216e-01
    z[2,4,3]  R1578     2.0331309735774994e-01
    z[2,4,3]  R1579     1.6727812588214874e-01
    z[2,4,3]  R1580     -4.0399852395057678e-01
    z[2,4,3]  R1581     -2.3591844365000725e-02
    z[2,4,3]  R1582     4.4183173775672913e-01
    z[2,4,3]  R1583     -3.2720467448234558e-01
    z[2,4,3]  R1584     -4.3055215477943420e-01
    z[2,4,3]  R1585     -3.1249335408210754e-01
    z[2,4,3]  R1586     0.405229389667511
    z[2,4,3]  R1587     1.7126889526844025e-01
    z[2,4,3]  R1588     5.4399931430816650e-01
    z[2,4,3]  R1589     3.7154817581176758e-01
    z[2,4,3]  R1590     -7.8700542449951172e-02
    z[2,4,3]  R1591     -6.3104387372732162e-03
    z[2,4,3]  R1592     2.0656596124172211e-01
    z[2,4,3]  R1593     -2.2475211322307587e-01
    z[2,4,3]  R1594     -5.3780917078256607e-02
    z[2,4,3]  R1595     2.1162706613540649e-01
    z[2,4,3]  R1596     -6.0689233243465424e-02
    z[2,4,3]  R1597     4.1020902991294861e-01
    z[2,4,3]  R1598     -6.2734061479568481e-01
    z[2,4,3]  R1599     -1.5283970534801483e-01
    z[2,4,3]  R1600     9.8189562559127808e-02
    z[2,4,3]  R1601     3.2321885228157043e-01
    z[2,4,3]  R1602     0.495151162147522
    z[2,4,3]  R1603     -1.1997682973742485e-02
    z[2,4,3]  R1604     -3.3768004179000854e-01
    z[2,4,3]  R1605     2.6501366496086121e-01
    z[2,4,3]  R1606     2.4692660570144653e-01
    z[2,4,3]  R1607     1.5630787611007690e-01
    z[2,4,3]  R1608     -3.9980259537696838e-01
    z[2,4,3]  R1609     2.1275892853736877e-02
    z[2,4,3]  R1610     -2.5178197026252747e-01
    z[2,4,3]  R1611     3.1184336543083191e-01
    z[2,4,3]  R1612     2.5135293602943420e-02
    z[2,4,3]  R1613     4.3311214447021484e-01
    z[2,4,3]  R1614     -4.6883741021156311e-01
    z[2,4,3]  R1615     1.8819957971572876e-02
    z[2,4,3]  R1616     -3.3058160543441772e-01
    z[2,4,3]  R1617     4.9212433397769928e-02
    z[2,4,3]  R1618     5.8376058936119080e-02
    z[2,4,3]  R1619     2.5313809514045715e-01
    z[2,4,3]  R1620     3.5397332906723022e-01
    z[2,4,3]  R1621     4.8243951797485352e-01
    z[2,4,3]  R1622     0.520687997341156
    z[2,4,3]  R1623     -5.3401719778776169e-02
    z[2,4,3]  R1624     3.7972751259803772e-01
    z[2,4,3]  R1625     -1.1306407302618027e-01
    z[2,4,3]  R1626     -3.3169585466384888e-01
    z[2,4,3]  R1627     2.3402684926986694e-01
    z[2,4,3]  R1628     -3.3222606778144836e-01
    z[2,4,3]  R1629     2.2909869253635406e-01
    z[2,4,3]  R1630     1.4218333363533020e-01
    z[2,4,3]  R1631     2.0553000271320343e-01
    z[2,4,3]  R1632     2.3103292286396027e-01
    z[2,4,3]  R1633     -5.7719651609659195e-02
    z[2,4,3]  R1634     1.9641692936420441e-01
    z[2,4,3]  R1635     1.0498762130737305e-01
    z[2,4,3]  R1636     8.7422579526901245e-02
    z[2,4,3]  R1637     0.33449786901474
    z[2,4,3]  R1638     2.0736102759838104e-01
    z[2,4,3]  R1639     3.3902138471603394e-01
    z[2,4,3]  R1640     -2.3966248333454132e-01
    z[2,4,3]  R1641     3.6694878339767456e-01
    z[2,4,3]  R1642     -5.0786721706390381e-01
    z[2,4,3]  R1643     -2.3085476830601692e-02
    z[2,4,3]  R1644     1.0495626181364059e-01
    z[2,4,3]  R1645     -3.4113073348999023e-01
    z[2,4,3]  R1646     8.6206562817096710e-02
    z[2,4,3]  R1647     2.9715862870216370e-01
    z[2,4,3]  R1648     1.2247022241353989e-01
    z[2,4,3]  R1649     -2.4262189865112305e-02
    z[2,4,3]  R1650     6.0212099552154541e-01
    z[2,4,3]  R1651     2.7250188589096069e-01
    z[2,4,3]  R1652     2.7629515528678894e-01
    z[2,4,3]  R1653     -2.8098204731941223e-01
    z[2,4,3]  R1654     8.2127936184406281e-02
    z[2,4,3]  R1655     9.0992741286754608e-02
    z[2,4,3]  R1656     5.9459584951400757e-01
    z[2,4,3]  R1657     4.8615738749504089e-01
    z[2,4,3]  R1658     4.2329812049865723e-01
    z[2,4,3]  R1659     1.4226980507373810e-02
    z[2,4,3]  R1660     -1.6567033529281616e-01
    z[2,4,3]  R1661     -1.9238793849945068e-01
    z[2,4,3]  R1662     -1.8471808731555939e-01
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1437     -1
    z[2,4,4]  R1438     1
    z[2,4,4]  R1443     7.6696373522281647e-02
    z[2,4,4]  R1444     -1.3601037859916687e-01
    z[2,4,4]  R1445     2.6907208561897278e-01
    z[2,4,4]  R1446     -2.7263644337654114e-01
    z[2,4,4]  R1447     -3.4290242195129395e-01
    z[2,4,4]  R1448     -2.7971944212913513e-01
    z[2,4,4]  R1449     -0.45118448138237
    z[2,4,4]  R1450     -3.6923289299011230e-02
    z[2,4,4]  R1451     -1.7339762300252914e-02
    z[2,4,4]  R1452     -4.2922419309616089e-01
    z[2,4,4]  R1453     1.5936696529388428e-01
    z[2,4,4]  R1454     5.2261584997177124e-01
    z[2,4,4]  R1455     -1.9508515298366547e-01
    z[2,4,4]  R1456     2.5149953365325928e-01
    z[2,4,4]  R1457     -3.6170445382595062e-02
    z[2,4,4]  R1458     6.0345385223627090e-02
    z[2,4,4]  R1459     3.2775735855102539e-01
    z[2,4,4]  R1460     -1.6123975813388824e-01
    z[2,4,4]  R1461     -1.1112906038761139e-02
    z[2,4,4]  R1462     -1.7066720128059387e-01
    z[2,4,4]  R1463     -2.5070169568061829e-01
    z[2,4,4]  R1464     -1.6315679252147675e-01
    z[2,4,4]  R1465     -0.0604669563472271
    z[2,4,4]  R1466     -3.4378089010715485e-02
    z[2,4,4]  R1467     3.7657979875802994e-02
    z[2,4,4]  R1468     -1.8559253215789795e-01
    z[2,4,4]  R1469     7.3197752237319946e-02
    z[2,4,4]  R1470     2.6784452795982361e-01
    z[2,4,4]  R1471     -3.4259593486785889e-01
    z[2,4,4]  R1472     -7.1928925812244415e-02
    z[2,4,4]  R1473     -4.5762622356414795e-01
    z[2,4,4]  R1474     -1.5903252363204956e-01
    z[2,4,4]  R1475     2.1625605225563049e-01
    z[2,4,4]  R1476     1.7825832590460777e-02
    z[2,4,4]  R1477     1.1625821888446808e-01
    z[2,4,4]  R1478     -3.0601578950881958e-01
    z[2,4,4]  R1479     4.7598907351493835e-01
    z[2,4,4]  R1480     -3.3756002783775330e-01
    z[2,4,4]  R1481     2.4750913679599762e-01
    z[2,4,4]  R1482     -8.3448909223079681e-02
    z[2,4,4]  R1483     0.265316367149353
    z[2,4,4]  R1484     -9.8314777016639709e-02
    z[2,4,4]  R1485     -4.5501780509948730e-01
    z[2,4,4]  R1486     -3.0927973985671997e-01
    z[2,4,4]  R1487     -6.9239658117294312e-01
    z[2,4,4]  R1488     1.4795464277267456e-01
    z[2,4,4]  R1489     -2.1814560890197754e-01
    z[2,4,4]  R1490     -3.9844788610935211e-02
    z[2,4,4]  R1491     2.5043150782585144e-01
    z[2,4,4]  R1492     5.3612012416124344e-02
    z[2,4,4]  R1493     7.2713029384613037e-01
    z[2,4,4]  R1494     -0.322696328163147
    z[2,4,4]  R1495     -2.0935116708278656e-01
    z[2,4,4]  R1496     2.8589293360710144e-01
    z[2,4,4]  R1497     2.4938410520553589e-01
    z[2,4,4]  R1498     1.0532125830650330e-01
    z[2,4,4]  R1499     -1.1799144744873047e-01
    z[2,4,4]  R1500     -2.9631054401397705e-01
    z[2,4,4]  R1501     -2.1745118498802185e-01
    z[2,4,4]  R1502     -1.9360281527042389e-01
    z[2,4,4]  R1503     5.6955549865961075e-02
    z[2,4,4]  R1504     -2.4683679640293121e-01
    z[2,4,4]  R1505     1.5325234830379486e-01
    z[2,4,4]  R1506     -1.2517413496971130e-01
    z[2,4,4]  R1507     6.5691810846328735e-01
    z[2,4,4]  R1508     4.9956849217414856e-01
    z[2,4,4]  R1509     1.3732229173183441e-01
    z[2,4,4]  R1510     -3.8667482137680054e-01
    z[2,4,4]  R1511     -3.3884474635124207e-01
    z[2,4,4]  R1512     -1.7403274774551392e-01
    z[2,4,4]  R1513     0.289171040058136
    z[2,4,4]  R1514     0.0606367364525795
    z[2,4,4]  R1515     -4.7994937747716904e-02
    z[2,4,4]  R1516     2.9373185709118843e-02
    z[2,4,4]  R1517     2.4802295863628387e-01
    z[2,4,4]  R1518     -3.9063632488250732e-01
    z[2,4,4]  R1519     3.0453100800514221e-01
    z[2,4,4]  R1520     -3.2805752754211426e-01
    z[2,4,4]  R1521     -2.0189037919044495e-01
    z[2,4,4]  R1522     -5.9273969382047653e-03
    z[2,4,4]  R1523     3.1691977381706238e-01
    z[2,4,4]  R1524     3.9639544486999512e-01
    z[2,4,4]  R1525     -9.6043810248374939e-02
    z[2,4,4]  R1526     -5.7641044259071350e-02
    z[2,4,4]  R1527     4.5994570851325989e-01
    z[2,4,4]  R1528     -4.5340526849031448e-02
    z[2,4,4]  R1529     4.6919766813516617e-02
    z[2,4,4]  R1530     -0.274619460105896
    z[2,4,4]  R1531     4.3874431401491165e-02
    z[2,4,4]  R1532     -0.214004248380661
    z[2,4,4]  R1533     2.3286873102188110e-01
    z[2,4,4]  R1534     -1.6028711199760437e-01
    z[2,4,4]  R1535     3.3477634191513062e-01
    z[2,4,4]  R1536     1.7664463818073273e-01
    z[2,4,4]  R1537     -1.3306210935115814e-01
    z[2,4,4]  R1538     -1.6326928511261940e-02
    z[2,4,4]  R1539     -2.6743057370185852e-01
    z[2,4,4]  R1540     -8.3587124943733215e-02
    z[2,4,4]  R1541     -2.1492704749107361e-02
    z[2,4,4]  R1542     -8.7991170585155487e-02
    z[2,4,4]  R1543     2.9614555835723877e-01
    z[2,4,4]  R1544     1.3326078653335571e-01
    z[2,4,4]  R1545     1.1991009861230850e-01
    z[2,4,4]  R1546     -2.1958047151565552e-01
    z[2,4,4]  R1547     -1.2943805195391178e-02
    z[2,4,4]  R1548     2.4993417784571648e-02
    z[2,4,4]  R1549     3.1518232822418213e-01
    z[2,4,4]  R1550     2.3044927418231964e-01
    z[2,4,4]  R1551     1.8626351654529572e-01
    z[2,4,4]  R1552     7.2187192738056183e-02
    z[2,4,4]  R1553     -1.6682930290699005e-01
    z[2,4,4]  R1554     -1.9122330844402313e-01
    z[2,4,4]  R1555     -1.1914963275194168e-01
    z[2,4,4]  R1556     -2.1009781956672668e-01
    z[2,4,4]  R1557     -4.1547951102256775e-01
    z[2,4,4]  R1558     3.2895419280976057e-03
    z[2,4,4]  R1559     6.3411749899387360e-02
    z[2,4,4]  R1560     2.6501941680908203e-01
    z[2,4,4]  R1561     -9.0105690062046051e-02
    z[2,4,4]  R1562     2.3578166961669922e-01
    z[2,4,4]  R1563     -2.0581318438053131e-01
    z[2,4,4]  R1564     -1.5405574440956116e-01
    z[2,4,4]  R1565     -4.6345052123069763e-01
    z[2,4,4]  R1566     -1.7371930181980133e-01
    z[2,4,4]  R1567     1.5203894674777985e-01
    z[2,4,4]  R1568     -1.7029793560504913e-01
    z[2,4,4]  R1569     -1.4309158921241760e-01
    z[2,4,4]  R1570     6.5895318984985352e-02
    z[2,4,4]  R1571     -8.9322596788406372e-02
    z[2,4,4]  R1572     6.9609411060810089e-02
    z[2,4,4]  R1573     3.4623327851295471e-01
    z[2,4,4]  R1574     -4.7948709130287170e-01
    z[2,4,4]  R1575     -6.1006331443786621e-01
    z[2,4,4]  R1576     8.7079212069511414e-02
    z[2,4,4]  R1577     4.4583201408386230e-01
    z[2,4,4]  R1578     3.1959778070449829e-01
    z[2,4,4]  R1579     -0.0889601856470108
    z[2,4,4]  R1580     -4.1677546501159668e-01
    z[2,4,4]  R1581     1.6093716025352478e-01
    z[2,4,4]  R1582     2.8899261355400085e-01
    z[2,4,4]  R1583     -6.7880898714065552e-01
    z[2,4,4]  R1584     2.3162260651588440e-01
    z[2,4,4]  R1585     -4.2658692598342896e-01
    z[2,4,4]  R1586     3.7110611796379089e-02
    z[2,4,4]  R1587     0.253608763217926
    z[2,4,4]  R1588     -3.0783239006996155e-01
    z[2,4,4]  R1589     8.0141127109527588e-02
    z[2,4,4]  R1590     2.8608945012092590e-01
    z[2,4,4]  R1591     -3.0059763230383396e-03
    z[2,4,4]  R1592     3.0319327116012573e-01
    z[2,4,4]  R1593     -4.4815093278884888e-01
    z[2,4,4]  R1594     1.0846333205699921e-01
    z[2,4,4]  R1595     -2.5771671533584595e-01
    z[2,4,4]  R1596     7.1807242929935455e-02
    z[2,4,4]  R1597     3.1035497784614563e-01
    z[2,4,4]  R1598     3.9208721369504929e-02
    z[2,4,4]  R1599     -4.1954988241195679e-01
    z[2,4,4]  R1600     3.2510882616043091e-01
    z[2,4,4]  R1601     3.0939370393753052e-01
    z[2,4,4]  R1602     1.0399816930294037e-01
    z[2,4,4]  R1603     -3.2380643486976624e-01
    z[2,4,4]  R1604     -4.3692804872989655e-02
    z[2,4,4]  R1605     3.5460570454597473e-01
    z[2,4,4]  R1606     -1.2773409485816956e-01
    z[2,4,4]  R1607     -9.9731072783470154e-02
    z[2,4,4]  R1608     2.4622483551502228e-01
    z[2,4,4]  R1609     4.0934920310974121e-01
    z[2,4,4]  R1610     -2.5437366962432861e-01
    z[2,4,4]  R1611     3.4494414925575256e-02
    z[2,4,4]  R1612     3.8776747882366180e-02
    z[2,4,4]  R1613     -2.2928847372531891e-01
    z[2,4,4]  R1614     7.2756119072437286e-02
    z[2,4,4]  R1615     -5.0857514142990112e-01
    z[2,4,4]  R1616     2.7385911345481873e-01
    z[2,4,4]  R1617     3.0575612187385559e-01
    z[2,4,4]  R1618     2.1467334032058716e-01
    z[2,4,4]  R1619     1.6659593582153320e-01
    z[2,4,4]  R1620     6.6348105669021606e-01
    z[2,4,4]  R1621     -7.7274434268474579e-02
    z[2,4,4]  R1622     5.2379506826400757e-01
    z[2,4,4]  R1623     2.8799173235893250e-01
    z[2,4,4]  R1624     -1.4048458635807037e-01
    z[2,4,4]  R1625     -1.8486697971820831e-01
    z[2,4,4]  R1626     2.1070814132690430e-01
    z[2,4,4]  R1627     -2.4036785587668419e-02
    z[2,4,4]  R1628     3.0900094658136368e-02
    z[2,4,4]  R1629     1.7191524803638458e-01
    z[2,4,4]  R1630     0.0910961776971817
    z[2,4,4]  R1631     2.3283807933330536e-01
    z[2,4,4]  R1632     0.0839817002415657
    z[2,4,4]  R1633     4.7030895948410034e-02
    z[2,4,4]  R1634     2.6917797327041626e-01
    z[2,4,4]  R1635     -2.2383768856525421e-01
    z[2,4,4]  R1636     2.5361141562461853e-01
    z[2,4,4]  R1637     5.5442094802856445e-01
    z[2,4,4]  R1638     5.7248443365097046e-01
    z[2,4,4]  R1639     -0.470795214176178
    z[2,4,4]  R1640     4.7683233022689819e-01
    z[2,4,4]  R1641     4.5888155698776245e-01
    z[2,4,4]  R1642     1.3239391148090363e-01
    z[2,4,4]  R1643     2.6018369942903519e-02
    z[2,4,4]  R1644     -2.6247984170913696e-01
    z[2,4,4]  R1645     -2.6960924267768860e-01
    z[2,4,4]  R1646     2.5080201029777527e-01
    z[2,4,4]  R1647     3.7362700700759888e-01
    z[2,4,4]  R1648     -1.7409019637852907e-03
    z[2,4,4]  R1649     -2.4190691113471985e-01
    z[2,4,4]  R1650     5.1489669084548950e-01
    z[2,4,4]  R1651     -1.8420583009719849e-01
    z[2,4,4]  R1652     -1.3304264843463898e-01
    z[2,4,4]  R1653     3.0345159769058228e-01
    z[2,4,4]  R1654     4.6785643696784973e-01
    z[2,4,4]  R1655     -9.7694151103496552e-02
    z[2,4,4]  R1656     6.8273797631263733e-02
    z[2,4,4]  R1657     -2.1637508273124695e-01
    z[2,4,4]  R1658     2.2672414779663086e-01
    z[2,4,4]  R1659     -1.3508158922195435e-01
    z[2,4,4]  R1660     1.2351201474666595e-01
    z[2,4,4]  R1661     -1.2425804138183594e-01
    z[2,4,4]  R1662     -2.5327226519584656e-01
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1439     -1
    z[2,4,5]  R1440     1
    z[2,4,5]  R1443     -4.0913251042366028e-01
    z[2,4,5]  R1444     -1.9938772916793823e-01
    z[2,4,5]  R1445     -2.4501414597034454e-01
    z[2,4,5]  R1446     -2.0833808183670044e-01
    z[2,4,5]  R1447     -1.5545871853828430e-01
    z[2,4,5]  R1448     -1.2104744091629982e-02
    z[2,4,5]  R1449     -2.4415870010852814e-01
    z[2,4,5]  R1450     1.5470339357852936e-01
    z[2,4,5]  R1451     -1.3708001375198364e-01
    z[2,4,5]  R1452     -4.8285737633705139e-01
    z[2,4,5]  R1453     1.7897954583168030e-01
    z[2,4,5]  R1454     4.1876620054244995e-01
    z[2,4,5]  R1455     6.2775970436632633e-03
    z[2,4,5]  R1456     -1.4662048220634460e-01
    z[2,4,5]  R1457     1.0123351216316223e-01
    z[2,4,5]  R1458     4.1432702541351318e-01
    z[2,4,5]  R1459     2.8929945826530457e-01
    z[2,4,5]  R1460     -1.0790634900331497e-01
    z[2,4,5]  R1461     1.8880537152290344e-01
    z[2,4,5]  R1462     4.1776046156883240e-01
    z[2,4,5]  R1463     -4.5226030051708221e-02
    z[2,4,5]  R1464     -2.3367213085293770e-02
    z[2,4,5]  R1465     6.7532330751419067e-02
    z[2,4,5]  R1466     -1.6712664067745209e-01
    z[2,4,5]  R1467     -9.5498561859130859e-02
    z[2,4,5]  R1468     3.7924793362617493e-01
    z[2,4,5]  R1469     -5.3726937621831894e-02
    z[2,4,5]  R1470     4.1719831526279449e-02
    z[2,4,5]  R1471     1.7668071389198303e-01
    z[2,4,5]  R1472     -1.0164061188697815e-01
    z[2,4,5]  R1473     4.5092034339904785e-01
    z[2,4,5]  R1474     -8.1328481435775757e-02
    z[2,4,5]  R1475     -5.1702845096588135e-01
    z[2,4,5]  R1476     4.0486997365951538e-01
    z[2,4,5]  R1477     1.6480258107185364e-01
    z[2,4,5]  R1478     0.627466082572937
    z[2,4,5]  R1479     0.29982790350914
    z[2,4,5]  R1480     -2.3215073347091675e-01
    z[2,4,5]  R1481     1.1857450753450394e-01
    z[2,4,5]  R1482     -1.3388405740261078e-01
    z[2,4,5]  R1483     -7.0382517576217651e-01
    z[2,4,5]  R1484     1.1174259334802628e-01
    z[2,4,5]  R1485     2.1935574710369110e-01
    z[2,4,5]  R1486     -1.0182154178619385e-01
    z[2,4,5]  R1487     3.2961988449096680e-01
    z[2,4,5]  R1488     -2.5022733211517334e-01
    z[2,4,5]  R1489     1.4056839980185032e-02
    z[2,4,5]  R1490     -5.8268398046493530e-01
    z[2,4,5]  R1491     -2.6642149686813354e-01
    z[2,4,5]  R1492     -6.7784243822097778e-01
    z[2,4,5]  R1493     7.2239354252815247e-02
    z[2,4,5]  R1494     -8.8432334363460541e-02
    z[2,4,5]  R1495     5.2897727489471436e-01
    z[2,4,5]  R1496     2.8498110175132751e-01
    z[2,4,5]  R1497     -2.2599442303180695e-01
    z[2,4,5]  R1498     5.6194867938756943e-02
    z[2,4,5]  R1499     3.1944376230239868e-01
    z[2,4,5]  R1500     -4.6117216348648071e-01
    z[2,4,5]  R1501     2.5276523828506470e-01
    z[2,4,5]  R1502     -6.7564010620117188e-01
    z[2,4,5]  R1503     2.1172720938920975e-02
    z[2,4,5]  R1504     -4.0027502179145813e-01
    z[2,4,5]  R1505     -1.6390261054039001e-01
    z[2,4,5]  R1506     1.1652058362960815e-01
    z[2,4,5]  R1507     -1.5202715992927551e-01
    z[2,4,5]  R1508     -1.8972858786582947e-01
    z[2,4,5]  R1509     -4.7291836142539978e-01
    z[2,4,5]  R1510     -2.6897612214088440e-01
    z[2,4,5]  R1511     -2.3124687373638153e-01
    z[2,4,5]  R1512     -2.3645384609699249e-01
    z[2,4,5]  R1513     -3.5391256213188171e-02
    z[2,4,5]  R1514     2.5909817218780518e-01
    z[2,4,5]  R1515     -0.613033652305603
    z[2,4,5]  R1516     -2.3402197659015656e-01
    z[2,4,5]  R1517     -0.316095769405365
    z[2,4,5]  R1518     3.4054023027420044e-01
    z[2,4,5]  R1519     2.4003812670707703e-01
    z[2,4,5]  R1520     1.8813515082001686e-02
    z[2,4,5]  R1521     -3.4905764460563660e-01
    z[2,4,5]  R1522     -4.9916657805442810e-01
    z[2,4,5]  R1523     3.1575998663902283e-01
    z[2,4,5]  R1524     3.7309196591377258e-01
    z[2,4,5]  R1525     7.0639267563819885e-02
    z[2,4,5]  R1526     2.4038922786712646e-01
    z[2,4,5]  R1527     4.4128566980361938e-02
    z[2,4,5]  R1528     -2.6686057448387146e-01
    z[2,4,5]  R1529     -5.0679403543472290e-01
    z[2,4,5]  R1530     -1.3757790625095367e-01
    z[2,4,5]  R1531     -3.3155736327171326e-01
    z[2,4,5]  R1532     1.9013158977031708e-01
    z[2,4,5]  R1533     2.9067987203598022e-01
    z[2,4,5]  R1534     -2.9712867736816406e-01
    z[2,4,5]  R1535     -9.7113199532032013e-02
    z[2,4,5]  R1536     -4.4012613594532013e-02
    z[2,4,5]  R1537     2.5967252254486084e-01
    z[2,4,5]  R1538     -2.6901009678840637e-01
    z[2,4,5]  R1539     2.6603478193283081e-01
    z[2,4,5]  R1540     3.7837705016136169e-01
    z[2,4,5]  R1541     4.4696322083473206e-01
    z[2,4,5]  R1542     3.3983856439590454e-01
    z[2,4,5]  R1543     -1.0552906990051270e-01
    z[2,4,5]  R1544     2.3850056529045105e-01
    z[2,4,5]  R1545     -0.34966841340065
    z[2,4,5]  R1546     3.8474443554878235e-01
    z[2,4,5]  R1547     7.0009604096412659e-02
    z[2,4,5]  R1548     -1.1616861820220947e-01
    z[2,4,5]  R1549     -7.8402034938335419e-02
    z[2,4,5]  R1550     -3.5456646233797073e-02
    z[2,4,5]  R1551     4.7586232423782349e-01
    z[2,4,5]  R1552     0.0745057761669159
    z[2,4,5]  R1553     -0.567290186882019
    z[2,4,5]  R1554     -4.7096580266952515e-01
    z[2,4,5]  R1555     -2.8467962145805359e-01
    z[2,4,5]  R1556     -4.5613187551498413e-01
    z[2,4,5]  R1557     -3.7316355109214783e-01
    z[2,4,5]  R1558     -4.9113425612449646e-01
    z[2,4,5]  R1559     -2.2501760721206665e-01
    z[2,4,5]  R1560     -4.5422890782356262e-01
    z[2,4,5]  R1561     -1.9683602452278137e-01
    z[2,4,5]  R1562     -7.4810914695262909e-02
    z[2,4,5]  R1563     5.5614137649536133e-01
    z[2,4,5]  R1564     4.6744874119758606e-01
    z[2,4,5]  R1565     3.0523526668548584e-01
    z[2,4,5]  R1566     -4.0307754278182983e-01
    z[2,4,5]  R1567     6.4861392602324486e-03
    z[2,4,5]  R1568     -3.5454906523227692e-02
    z[2,4,5]  R1569     1.2842306494712830e-01
    z[2,4,5]  R1570     1.4541678130626678e-01
    z[2,4,5]  R1571     1.6680285334587097e-01
    z[2,4,5]  R1572     8.6275503039360046e-02
    z[2,4,5]  R1573     -8.8976975530385971e-03
    z[2,4,5]  R1574     4.5235604047775269e-01
    z[2,4,5]  R1575     3.6717417836189270e-01
    z[2,4,5]  R1576     -6.2057387083768845e-02
    z[2,4,5]  R1577     1.4026379585266113e-01
    z[2,4,5]  R1578     -8.7293386459350586e-02
    z[2,4,5]  R1579     2.5280052423477173e-01
    z[2,4,5]  R1580     1.5615834295749664e-01
    z[2,4,5]  R1581     -1.2509214878082275e-01
    z[2,4,5]  R1582     2.4431882798671722e-01
    z[2,4,5]  R1583     3.5856953263282776e-01
    z[2,4,5]  R1584     5.8395403623580933e-01
    z[2,4,5]  R1585     2.4112163484096527e-01
    z[2,4,5]  R1586     2.9454326629638672e-01
    z[2,4,5]  R1587     3.1561228632926941e-01
    z[2,4,5]  R1588     -1.8078792095184326e-01
    z[2,4,5]  R1589     -2.5250095129013062e-01
    z[2,4,5]  R1590     1.8632566928863525e-01
    z[2,4,5]  R1591     -4.3672680854797363e-01
    z[2,4,5]  R1592     -8.9058600366115570e-02
    z[2,4,5]  R1593     4.4784566760063171e-01
    z[2,4,5]  R1594     0.425496906042099
    z[2,4,5]  R1595     3.2415258884429932e-01
    z[2,4,5]  R1596     -1.6619232296943665e-01
    z[2,4,5]  R1597     -2.3024032998364419e-04
    z[2,4,5]  R1598     -2.1188246086239815e-02
    z[2,4,5]  R1599     -4.2546260356903076e-01
    z[2,4,5]  R1600     -3.7626194953918457e-01
    z[2,4,5]  R1601     -1.1377550661563873e-02
    z[2,4,5]  R1602     -1.3964809477329254e-01
    z[2,4,5]  R1603     4.3637013435363770e-01
    z[2,4,5]  R1604     5.8601337671279907e-01
    z[2,4,5]  R1605     1.8636810779571533e-01
    z[2,4,5]  R1606     2.5316748023033142e-01
    z[2,4,5]  R1607     1.7170919477939606e-01
    z[2,4,5]  R1608     3.3964416384696960e-01
    z[2,4,5]  R1609     -2.2880868613719940e-01
    z[2,4,5]  R1610     -3.0514645576477051e-01
    z[2,4,5]  R1611     -3.9614114910364151e-02
    z[2,4,5]  R1612     -1.1986841447651386e-02
    z[2,4,5]  R1613     -1.8737922608852386e-01
    z[2,4,5]  R1614     2.9761362075805664e-01
    z[2,4,5]  R1615     -1.4091113209724426e-01
    z[2,4,5]  R1616     -2.1088285744190216e-01
    z[2,4,5]  R1617     -1.4867080748081207e-01
    z[2,4,5]  R1618     -1.5140730142593384e-01
    z[2,4,5]  R1619     7.3399171233177185e-02
    z[2,4,5]  R1620     -1.3731801509857178e-01
    z[2,4,5]  R1621     -2.1077500283718109e-01
    z[2,4,5]  R1622     -4.1861617565155029e-01
    z[2,4,5]  R1623     1.5950110554695129e-01
    z[2,4,5]  R1624     3.1426626443862915e-01
    z[2,4,5]  R1625     6.6431082785129547e-02
    z[2,4,5]  R1626     4.6235236525535583e-01
    z[2,4,5]  R1627     -1.1576903052628040e-02
    z[2,4,5]  R1628     -7.8274980187416077e-02
    z[2,4,5]  R1629     -3.7693977355957031e-01
    z[2,4,5]  R1630     4.1850835084915161e-02
    z[2,4,5]  R1631     6.0755524784326553e-02
    z[2,4,5]  R1632     -1.1820632964372635e-02
    z[2,4,5]  R1633     5.8419197797775269e-02
    z[2,4,5]  R1634     -4.5930200815200806e-01
    z[2,4,5]  R1635     1.8721137195825577e-02
    z[2,4,5]  R1636     -4.5784667134284973e-01
    z[2,4,5]  R1637     -1.4388071000576019e-01
    z[2,4,5]  R1638     0.082222118973732
    z[2,4,5]  R1639     1.2622365355491638e-01
    z[2,4,5]  R1640     -2.6503092050552368e-01
    z[2,4,5]  R1641     -3.6509260535240173e-01
    z[2,4,5]  R1642     -1.9301755726337433e-01
    z[2,4,5]  R1643     2.3834304511547089e-01
    z[2,4,5]  R1644     3.6902558803558350e-01
    z[2,4,5]  R1645     3.8425880670547485e-01
    z[2,4,5]  R1646     -4.2244362831115723e-01
    z[2,4,5]  R1647     2.0742814987897873e-02
    z[2,4,5]  R1648     0.0847427025437355
    z[2,4,5]  R1649     1.6116046905517578e-01
    z[2,4,5]  R1650     -3.4456923604011536e-01
    z[2,4,5]  R1651     -5.1498931646347046e-01
    z[2,4,5]  R1652     -2.9532846808433533e-01
    z[2,4,5]  R1653     -3.2721281051635742e-01
    z[2,4,5]  R1654     -5.4802145808935165e-02
    z[2,4,5]  R1655     2.5784159079194069e-02
    z[2,4,5]  R1656     -3.3183619379997253e-01
    z[2,4,5]  R1657     -9.4814337790012360e-02
    z[2,4,5]  R1658     -3.2409057021141052e-01
    z[2,4,5]  R1659     -3.0177587270736694e-01
    z[2,4,5]  R1660     -3.4313338994979858e-01
    z[2,4,5]  R1661     -2.3594951629638672e-01
    z[2,4,5]  R1662     -3.2928720116615295e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1441     -1
    z[2,4,6]  R1442     1
    z[2,4,6]  R1443     -1.6492843627929688e-01
    z[2,4,6]  R1444     -9.3961074948310852e-02
    z[2,4,6]  R1445     -3.5728029906749725e-02
    z[2,4,6]  R1446     -3.2833582162857056e-01
    z[2,4,6]  R1447     3.2686257362365723e-01
    z[2,4,6]  R1448     -1.4039170928299427e-02
    z[2,4,6]  R1449     1.2344378232955933e-01
    z[2,4,6]  R1450     -2.3563358187675476e-01
    z[2,4,6]  R1451     3.1386756896972656e-01
    z[2,4,6]  R1452     1.3855537772178650e-01
    z[2,4,6]  R1453     1.1553360521793365e-01
    z[2,4,6]  R1454     -1.8122033774852753e-01
    z[2,4,6]  R1455     -3.7590980529785156e-01
    z[2,4,6]  R1456     0.141273632645607
    z[2,4,6]  R1457     3.6761730909347534e-01
    z[2,4,6]  R1458     2.5172346830368042e-01
    z[2,4,6]  R1459     2.3954164981842041e-01
    z[2,4,6]  R1460     -3.3420255780220032e-01
    z[2,4,6]  R1461     -6.5239536762237549e-01
    z[2,4,6]  R1462     -4.3621074408292770e-02
    z[2,4,6]  R1463     -0.0518658272922039
    z[2,4,6]  R1464     8.8990144431591034e-03
    z[2,4,6]  R1465     1.0470316559076309e-01
    z[2,4,6]  R1466     1.0767577588558197e-01
    z[2,4,6]  R1467     -1.1672386527061462e-01
    z[2,4,6]  R1468     -1.2187291681766510e-01
    z[2,4,6]  R1469     2.5548562407493591e-02
    z[2,4,6]  R1470     0.0900566577911377
    z[2,4,6]  R1471     2.5914067402482033e-02
    z[2,4,6]  R1472     6.8382412195205688e-02
    z[2,4,6]  R1473     -8.4528736770153046e-02
    z[2,4,6]  R1474     -7.3306798934936523e-01
    z[2,4,6]  R1475     1.1163865774869919e-01
    z[2,4,6]  R1476     -1.9604042172431946e-02
    z[2,4,6]  R1477     -1.7284965515136719e-01
    z[2,4,6]  R1478     3.2818809151649475e-01
    z[2,4,6]  R1479     1.7801612615585327e-01
    z[2,4,6]  R1480     -1.3617551326751709e-01
    z[2,4,6]  R1481     -7.8074358403682709e-02
    z[2,4,6]  R1482     1.5174004435539246e-01
    z[2,4,6]  R1483     -0.193263441324234
    z[2,4,6]  R1484     -4.1548219323158264e-01
    z[2,4,6]  R1485     -2.0349536836147308e-01
    z[2,4,6]  R1486     4.5186790823936462e-01
    z[2,4,6]  R1487     -4.7979336231946945e-02
    z[2,4,6]  R1488     -2.2587533295154572e-01
    z[2,4,6]  R1489     -1.1849322170019150e-01
    z[2,4,6]  R1490     -8.2743220031261444e-02
    z[2,4,6]  R1491     -6.2936772592365742e-03
    z[2,4,6]  R1492     2.7090808749198914e-01
    z[2,4,6]  R1493     3.1304123997688293e-01
    z[2,4,6]  R1494     3.9663332700729370e-01
    z[2,4,6]  R1495     -1.3253666460514069e-01
    z[2,4,6]  R1496     -1.0549268918111920e-03
    z[2,4,6]  R1497     1.8261510878801346e-02
    z[2,4,6]  R1498     4.6634960174560547e-01
    z[2,4,6]  R1499     -2.5481829047203064e-01
    z[2,4,6]  R1500     1.9056017696857452e-01
    z[2,4,6]  R1501     4.2305365204811096e-01
    z[2,4,6]  R1502     -1.1774463579058647e-02
    z[2,4,6]  R1503     0.476979523897171
    z[2,4,6]  R1504     0.0441533662378788
    z[2,4,6]  R1505     4.3637722730636597e-01
    z[2,4,6]  R1506     -2.2750008106231689e-01
    z[2,4,6]  R1507     -5.1425302028656006e-01
    z[2,4,6]  R1508     -6.6892087459564209e-02
    z[2,4,6]  R1509     2.8757461905479431e-01
    z[2,4,6]  R1510     1.8163864314556122e-01
    z[2,4,6]  R1511     4.4809184968471527e-02
    z[2,4,6]  R1512     2.0869192481040955e-01
    z[2,4,6]  R1513     3.1698805093765259e-01
    z[2,4,6]  R1514     -3.1791147589683533e-01
    z[2,4,6]  R1515     -0.0218859501183033
    z[2,4,6]  R1516     3.3259138464927673e-01
    z[2,4,6]  R1517     -4.8471871018409729e-01
    z[2,4,6]  R1518     7.3627866804599762e-02
    z[2,4,6]  R1519     -0.210836723446846
    z[2,4,6]  R1520     -3.1659367680549622e-01
    z[2,4,6]  R1521     -1.3049063086509705e-01
    z[2,4,6]  R1522     -1.8533644080162048e-01
    z[2,4,6]  R1523     3.8289141654968262e-01
    z[2,4,6]  R1524     -2.6891345158219337e-02
    z[2,4,6]  R1525     1.3080124557018280e-01
    z[2,4,6]  R1526     -3.0868074297904968e-01
    z[2,4,6]  R1527     -4.4748479127883911e-01
    z[2,4,6]  R1528     9.9589407444000244e-02
    z[2,4,6]  R1529     -1.4063747227191925e-01
    z[2,4,6]  R1530     -0.0908326730132103
    z[2,4,6]  R1531     4.3805864453315735e-01
    z[2,4,6]  R1532     1.9548374414443970e-01
    z[2,4,6]  R1533     -1.3465739786624908e-01
    z[2,4,6]  R1534     -4.7352391481399536e-01
    z[2,4,6]  R1535     -4.0334376692771912e-01
    z[2,4,6]  R1536     -3.4171923995018005e-01
    z[2,4,6]  R1537     -0.0457824245095253
    z[2,4,6]  R1538     3.7002786993980408e-01
    z[2,4,6]  R1539     3.3452188968658447e-01
    z[2,4,6]  R1540     3.8959000259637833e-02
    z[2,4,6]  R1541     1.4366483688354492e-01
    z[2,4,6]  R1542     1.4029106497764587e-01
    z[2,4,6]  R1543     -1.8921458721160889e-01
    z[2,4,6]  R1544     -2.7679666876792908e-01
    z[2,4,6]  R1545     3.0307358503341675e-01
    z[2,4,6]  R1546     3.1549820303916931e-01
    z[2,4,6]  R1547     1.6601040959358215e-01
    z[2,4,6]  R1548     1.3481980189681053e-02
    z[2,4,6]  R1549     2.0826151967048645e-01
    z[2,4,6]  R1550     3.7093237042427063e-01
    z[2,4,6]  R1551     -7.5687073171138763e-02
    z[2,4,6]  R1552     -0.344025194644928
    z[2,4,6]  R1553     -1.1409967392683029e-01
    z[2,4,6]  R1554     1.8631061911582947e-01
    z[2,4,6]  R1555     1.5505558252334595e-01
    z[2,4,6]  R1556     -9.4230905175209045e-02
    z[2,4,6]  R1557     8.8811673223972321e-02
    z[2,4,6]  R1558     -5.4144892841577530e-02
    z[2,4,6]  R1559     -3.6406937241554260e-01
    z[2,4,6]  R1560     2.2296257317066193e-01
    z[2,4,6]  R1561     -4.3690085411071777e-01
    z[2,4,6]  R1562     -0.284881055355072
    z[2,4,6]  R1563     2.3958197236061096e-01
    z[2,4,6]  R1564     -2.3904012143611908e-01
    z[2,4,6]  R1565     -1.1963321268558502e-01
    z[2,4,6]  R1566     -4.6805106103420258e-02
    z[2,4,6]  R1567     -1.7740327119827271e-01
    z[2,4,6]  R1568     3.9852154254913330e-01
    z[2,4,6]  R1569     -1.7968656122684479e-01
    z[2,4,6]  R1570     -5.7249772548675537e-01
    z[2,4,6]  R1571     -6.5263003110885620e-01
    z[2,4,6]  R1572     -2.8091764450073242e-01
    z[2,4,6]  R1573     1.6536907851696014e-01
    z[2,4,6]  R1574     -3.8747996091842651e-01
    z[2,4,6]  R1575     -3.6879444122314453e-01
    z[2,4,6]  R1576     7.8969156742095947e-01
    z[2,4,6]  R1577     -2.0165938138961792e-01
    z[2,4,6]  R1578     -1.3785080611705780e-01
    z[2,4,6]  R1579     0.332021564245224
    z[2,4,6]  R1580     8.9740976691246033e-02
    z[2,4,6]  R1581     -1.3271878659725189e-01
    z[2,4,6]  R1582     2.6851412653923035e-01
    z[2,4,6]  R1583     -4.4646671414375305e-01
    z[2,4,6]  R1584     3.5155513882637024e-01
    z[2,4,6]  R1585     9.7187506034970284e-03
    z[2,4,6]  R1586     -3.9079171419143677e-01
    z[2,4,6]  R1587     -1.6757705807685852e-01
    z[2,4,6]  R1588     -2.3581512272357941e-02
    z[2,4,6]  R1589     4.8792776465415955e-01
    z[2,4,6]  R1590     5.0658807158470154e-02
    z[2,4,6]  R1591     4.8480924963951111e-01
    z[2,4,6]  R1592     -2.5699833035469055e-01
    z[2,4,6]  R1593     6.6792696714401245e-02
    z[2,4,6]  R1594     2.0928496122360229e-01
    z[2,4,6]  R1595     -6.2918695621192455e-03
    z[2,4,6]  R1596     0.377238005399704
    z[2,4,6]  R1597     3.1086388230323792e-01
    z[2,4,6]  R1598     -1.9821390509605408e-01
    z[2,4,6]  R1599     -1.8849206389859319e-03
    z[2,4,6]  R1600     5.9384290128946304e-02
    z[2,4,6]  R1601     -9.6629941835999489e-03
    z[2,4,6]  R1602     1.4050062000751495e-01
    z[2,4,6]  R1603     -2.0856364071369171e-01
    z[2,4,6]  R1604     1.5194277465343475e-01
    z[2,4,6]  R1605     1.9492205977439880e-01
    z[2,4,6]  R1606     -3.1650376319885254e-01
    z[2,4,6]  R1607     -2.8207591176033020e-01
    z[2,4,6]  R1608     -2.5937798619270325e-01
    z[2,4,6]  R1609     -2.2709725797176361e-01
    z[2,4,6]  R1610     -1.5670976042747498e-01
    z[2,4,6]  R1611     -1.8955725431442261e-01
    z[2,4,6]  R1612     -1.1056371033191681e-01
    z[2,4,6]  R1613     1.5578483045101166e-01
    z[2,4,6]  R1614     -3.3971226215362549e-01
    z[2,4,6]  R1615     2.9629576206207275e-01
    z[2,4,6]  R1616     -1.7692670226097107e-01
    z[2,4,6]  R1617     1.2157399207353592e-01
    z[2,4,6]  R1618     -8.9330114424228668e-02
    z[2,4,6]  R1619     -1.0918104648590088e-01
    z[2,4,6]  R1620     2.1212534606456757e-01
    z[2,4,6]  R1621     -0.00732843903824687
    z[2,4,6]  R1622     -1.8028123676776886e-01
    z[2,4,6]  R1623     5.8017671108245850e-01
    z[2,4,6]  R1624     1.7972312867641449e-02
    z[2,4,6]  R1625     -4.0665301680564880e-01
    z[2,4,6]  R1626     1.0987018793821335e-01
    z[2,4,6]  R1627     6.1497384309768677e-01
    z[2,4,6]  R1628     -3.0301022529602051e-01
    z[2,4,6]  R1629     2.1675251424312592e-02
    z[2,4,6]  R1630     8.7226778268814087e-02
    z[2,4,6]  R1631     2.8561198711395264e-01
    z[2,4,6]  R1632     4.3371358513832092e-01
    z[2,4,6]  R1633     1.3211207091808319e-01
    z[2,4,6]  R1634     -4.1308730840682983e-01
    z[2,4,6]  R1635     -1.3268908485770226e-02
    z[2,4,6]  R1636     -9.4475768506526947e-02
    z[2,4,6]  R1637     1.4035947620868683e-01
    z[2,4,6]  R1638     1.2068077921867371e-01
    z[2,4,6]  R1639     2.5822622701525688e-02
    z[2,4,6]  R1640     3.6570936441421509e-01
    z[2,4,6]  R1641     4.2769372463226318e-01
    z[2,4,6]  R1642     -8.2987926900386810e-02
    z[2,4,6]  R1643     -2.1248523890972137e-01
    z[2,4,6]  R1644     4.3469882011413574e-01
    z[2,4,6]  R1645     2.6805743575096130e-01
    z[2,4,6]  R1646     -1.0324721783399582e-01
    z[2,4,6]  R1647     2.3308119177818298e-01
    z[2,4,6]  R1648     -1.6491647064685822e-01
    z[2,4,6]  R1649     -1.6455566883087158e-01
    z[2,4,6]  R1650     -6.8455703556537628e-02
    z[2,4,6]  R1651     -2.2133512794971466e-01
    z[2,4,6]  R1652     -9.1432582121342421e-04
    z[2,4,6]  R1653     -0.0773564875125885
    z[2,4,6]  R1654     1.6218551993370056e-01
    z[2,4,6]  R1655     -9.9893517792224884e-02
    z[2,4,6]  R1656     -1.7724396288394928e-01
    z[2,4,6]  R1657     3.0140149593353271e-01
    z[2,4,6]  R1658     5.6753152608871460e-01
    z[2,4,6]  R1659     -1.5236841142177582e-01
    z[2,4,6]  R1660     4.0906123816967010e-02
    z[2,4,6]  R1661     -3.5598453134298325e-02
    z[2,4,6]  R1662     1.6011761128902435e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1663     -1
    z[4,2,0]  R1664     1
    z[4,2,0]  R1677     -5.8755654096603394e-01
    z[4,2,0]  R1678     -0.550112783908844
    z[4,2,0]  R1679     -5.7592475414276123e-01
    z[4,2,0]  R1680     -6.1626744270324707e-01
    z[4,2,0]  R1681     -5.3182321786880493e-01
    z[4,2,0]  R1682     -6.7129796743392944e-01
    z[4,2,0]  R1683     -6.7024582624435425e-01
    z[4,2,0]  R1684     -5.8671534061431885e-01
    z[4,2,0]  R1685     -6.3573414087295532e-01
    z[4,2,0]  R1686     -7.6984459161758423e-01
    z[4,2,0]  R1687     2.2927865386009216e-01
    z[4,2,0]  R1688     6.8313342332839966e-01
    z[4,2,0]  R1689     7.1734535694122314e-01
    z[4,2,0]  R1690     -3.7486594915390015e-01
    z[4,2,0]  R1691     4.1173495352268219e-02
    z[4,2,0]  R1692     2.9657664895057678e-01
    z[4,2,0]  R1693     1.4933685958385468e-01
    z[4,2,0]  R1694     4.7259172797203064e-01
    z[4,2,0]  R1695     5.5157589912414551e-01
    z[4,2,0]  R1696     4.6082824468612671e-01
    z[4,2,0]  R1697     -1.1115819215774536e-01
    z[4,2,0]  R1698     -1.2880751863121986e-02
    z[4,2,0]  R1699     5.5273931473493576e-02
    z[4,2,0]  R1700     1.4118523895740509e-01
    z[4,2,0]  R1701     6.4345401525497437e-01
    z[4,2,0]  R1702     0.0411706306040287
    z[4,2,0]  R1703     2.1051850169897079e-02
    z[4,2,0]  R1704     3.9216777682304382e-01
    z[4,2,0]  R1705     3.2847228646278381e-01
    z[4,2,0]  R1706     -0.0661325603723526
    z[4,2,0]  R1707     1.6047385288402438e-03
    z[4,2,0]  R1708     1.1611460894346237e-01
    z[4,2,0]  R1709     2.0121926069259644e-01
    z[4,2,0]  R1710     -2.7605935931205750e-01
    z[4,2,0]  R1711     5.7087254524230957e-01
    z[4,2,0]  R1712     0.534482479095459
    z[4,2,0]  R1713     5.3874176740646362e-01
    z[4,2,0]  R1714     6.4456933736801147e-01
    z[4,2,0]  R1715     -2.6294299960136414e-01
    z[4,2,0]  R1716     1.6433918476104736e-01
    z[4,2,0]  R1717     9.2788405716419220e-02
    z[4,2,0]  R1718     8.6532514542341232e-03
    z[4,2,0]  R1719     -5.0115205347537994e-02
    z[4,2,0]  R1720     8.6147910356521606e-01
    z[4,2,0]  R1721     4.8253032565116882e-01
    z[4,2,0]  R1722     7.4361699819564819e-01
    z[4,2,0]  R1723     7.0720338821411133e-01
    z[4,2,0]  R1724     1.0208169370889664e-01
    z[4,2,0]  R1725     1.2148441374301910e-01
    z[4,2,0]  R1726     -1.1865770816802979e-01
    z[4,2,0]  R1727     -1.4550159871578217e-01
    z[4,2,0]  R1728     -3.6517471075057983e-02
    z[4,2,0]  R1729     -2.0804883539676666e-01
    z[4,2,0]  R1730     3.9359282702207565e-02
    z[4,2,0]  R1731     6.9649285078048706e-01
    z[4,2,0]  R1732     7.3793154954910278e-01
    z[4,2,0]  R1733     6.9981509447097778e-01
    z[4,2,0]  R1734     8.4909921884536743e-01
    z[4,2,0]  R1735     2.7244171500205994e-01
    z[4,2,0]  R1736     0.168548122048378
    z[4,2,0]  R1737     6.9429796934127808e-01
    z[4,2,0]  R1738     6.7381465435028076e-01
    z[4,2,0]  R1739     7.3634153604507446e-01
    z[4,2,0]  R1740     6.1560302972793579e-01
    z[4,2,0]  R1741     2.6052442193031311e-01
    z[4,2,0]  R1742     -1.2880542874336243e-01
    z[4,2,0]  R1743     -1.2372874468564987e-01
    z[4,2,0]  R1744     2.1286159753799438e-01
    z[4,2,0]  R1745     5.8649146556854248e-01
    z[4,2,0]  R1746     -1.5846298635005951e-01
    z[4,2,0]  R1747     -8.1728391349315643e-02
    z[4,2,0]  R1748     6.9623565673828125e-01
    z[4,2,0]  R1749     7.5372809171676636e-01
    z[4,2,0]  R1750     6.9946563243865967e-01
    z[4,2,0]  R1751     6.5266388654708862e-01
    z[4,2,0]  R1752     8.8066416978836060e-01
    z[4,2,0]  R1753     0.0986173152923584
    z[4,2,0]  R1754     -0.0824391320347786
    z[4,2,0]  R1755     1.0335975885391235e-01
    z[4,2,0]  R1756     -1.2979520484805107e-02
    z[4,2,0]  R1757     -0.0978812426328659
    z[4,2,0]  R1758     -4.1288039088249207e-01
    z[4,2,0]  R1759     -4.5653238892555237e-01
    z[4,2,0]  R1760     6.8289393186569214e-01
    z[4,2,0]  R1761     2.8496208786964417e-01
    z[4,2,0]  R1762     -1.0464946739375591e-02
    z[4,2,0]  R1763     1.7132751643657684e-01
    z[4,2,0]  R1764     -2.8915578126907349e-01
    z[4,2,0]  R1765     -2.0504486560821533e-01
    z[4,2,0]  R1766     3.2287436723709106e-01
    z[4,2,0]  R1767     0.789137065410614
    z[4,2,0]  R1768     7.2498601675033569e-01
    z[4,2,0]  R1769     7.4532598257064819e-01
    z[4,2,0]  R1770     7.3198574781417847e-01
    z[4,2,0]  R1771     -9.2089831829071045e-02
    z[4,2,0]  R1772     -7.7427178621292114e-02
    z[4,2,0]  R1773     1.8897749483585358e-01
    z[4,2,0]  R1774     4.4966783374547958e-02
    z[4,2,0]  R1775     4.8142012953758240e-01
    z[4,2,0]  R1776     6.7377209663391113e-01
    z[4,2,0]  R1777     7.4083232879638672e-01
    z[4,2,0]  R1778     5.7815268635749817e-02
    z[4,2,0]  R1779     2.0731888711452484e-01
    z[4,2,0]  R1780     1.8512832000851631e-02
    z[4,2,0]  R1781     3.2425409555435181e-01
    z[4,2,0]  R1782     2.0348079502582550e-01
    z[4,2,0]  R1783     5.5700516700744629e-01
    z[4,2,0]  R1784     4.3710514903068542e-01
    z[4,2,0]  R1785     5.9524399042129517e-01
    z[4,2,0]  R1786     4.2955505847930908e-01
    z[4,2,0]  R1787     -7.0111936330795288e-01
    z[4,2,0]  R1788     -0.89290452003479
    z[4,2,0]  R1789     -5.5982106924057007e-01
    z[4,2,0]  R1790     -7.7223902940750122e-01
    z[4,2,0]  R1791     -5.1400977373123169e-01
    z[4,2,0]  R1792     -5.8208656311035156e-01
    z[4,2,0]  R1793     -7.0283114910125732e-01
    z[4,2,0]  R1794     -7.5358664989471436e-01
    z[4,2,0]  R1795     -8.4476613998413086e-01
    z[4,2,0]  R1796     -4.5482754707336426e-01
    z[4,2,0]  R1797     -1.1568231880664825e-01
    z[4,2,0]  R1798     -1.5688852965831757e-01
    z[4,2,0]  R1799     -1.5708351135253906e-01
    z[4,2,0]  R1800     0.698796272277832
    z[4,2,0]  R1801     7.0299059152603149e-01
    z[4,2,0]  R1802     6.8405562639236450e-01
    z[4,2,0]  R1803     5.8949434757232666e-01
    z[4,2,0]  R1804     7.7339643239974976e-01
    z[4,2,0]  R1805     5.5310606956481934e-01
    z[4,2,0]  R1806     6.3671547174453735e-01
    z[4,2,0]  R1807     -4.5417621731758118e-02
    z[4,2,0]  R1808     -1.3537852466106415e-01
    z[4,2,0]  R1809     7.9827654361724854e-01
    z[4,2,0]  R1810     7.7390931546688080e-02
    z[4,2,0]  R1811     1.1108760535717010e-01
    z[4,2,0]  R1812     6.6704463958740234e-01
    z[4,2,0]  R1813     -6.2267392873764038e-02
    z[4,2,0]  R1814     5.9514009952545166e-01
    z[4,2,0]  R1815     7.2336536645889282e-01
    z[4,2,0]  R1816     0.519419252872467
    z[4,2,0]  R1817     3.3257889747619629e-01
    z[4,2,0]  R1818     4.8302039504051208e-01
    z[4,2,0]  R1819     3.9415013790130615e-01
    z[4,2,0]  R1820     3.6163190007209778e-01
    z[4,2,0]  R1821     7.2397685050964355e-01
    z[4,2,0]  R1822     2.5747874751687050e-02
    z[4,2,0]  R1823     4.6654164791107178e-01
    z[4,2,0]  R1824     2.6764750480651855e-01
    z[4,2,0]  R1825     6.7203575372695923e-01
    z[4,2,0]  R1826     3.1270250678062439e-01
    z[4,2,0]  R1827     8.6481748148798943e-03
    z[4,2,0]  R1828     5.0570660829544067e-01
    z[4,2,0]  R1829     5.1533085107803345e-01
    z[4,2,0]  R1830     6.8787300586700439e-01
    z[4,2,0]  R1831     5.1636826992034912e-01
    z[4,2,0]  R1832     3.9412611722946167e-01
    z[4,2,0]  R1833     2.9528799653053284e-01
    z[4,2,0]  R1834     3.8233464956283569e-01
    z[4,2,0]  R1835     4.4280681014060974e-01
    z[4,2,0]  R1836     2.8501817584037781e-01
    z[4,2,0]  R1837     -6.6540159285068512e-02
    z[4,2,0]  R1838     7.2577208280563354e-01
    z[4,2,0]  R1839     6.4080274105072021e-01
    z[4,2,0]  R1840     4.1627743840217590e-01
    z[4,2,0]  R1841     5.0062882900238037e-01
    z[4,2,0]  R1842     4.2449519038200378e-01
    z[4,2,0]  R1843     0.635075032711029
    z[4,2,0]  R1844     3.4158974885940552e-01
    z[4,2,0]  R1845     1.6505779325962067e-01
    z[4,2,0]  R1846     2.9975670576095581e-01
    z[4,2,0]  R1847     -1.8692952394485474e-01
    z[4,2,0]  R1848     8.1349158287048340e-01
    z[4,2,0]  R1849     6.2359130382537842e-01
    z[4,2,0]  R1850     4.8640325665473938e-01
    z[4,2,0]  R1851     4.1923937201499939e-01
    z[4,2,0]  R1852     0.6805379986763
    z[4,2,0]  R1853     3.6483851075172424e-01
    z[4,2,0]  R1854     5.0083762407302856e-01
    z[4,2,0]  R1855     4.9331733584403992e-01
    z[4,2,0]  R1856     3.9891350269317627e-01
    z[4,2,0]  R1857     -1.6254135966300964e-01
    z[4,2,0]  R1858     -3.8926255702972412e-01
    z[4,2,0]  R1859     -1.3564291875809431e-03
    z[4,2,0]  R1860     6.3775193691253662e-01
    z[4,2,0]  R1861     -7.1092344820499420e-02
    z[4,2,0]  R1862     5.1004421710968018e-01
    z[4,2,0]  R1863     5.7516175508499146e-01
    z[4,2,0]  R1864     5.8088397979736328e-01
    z[4,2,0]  R1865     0.561552882194519
    z[4,2,0]  R1866     5.3413277864456177e-01
    z[4,2,0]  R1867     -3.9800170063972473e-01
    z[4,2,0]  R1868     -4.5562595129013062e-01
    z[4,2,0]  R1869     8.4574174880981445e-01
    z[4,2,0]  R1870     4.4838038086891174e-01
    z[4,2,0]  R1871     5.0031250715255737e-01
    z[4,2,0]  R1872     0.2799052298069
    z[4,2,0]  R1873     5.0745552778244019e-01
    z[4,2,0]  R1874     4.3456608057022095e-01
    z[4,2,0]  R1875     4.6067798137664795e-01
    z[4,2,0]  R1876     5.6948703527450562e-01
    z[4,2,0]  R1877     -3.5241582989692688e-01
    z[4,2,0]  R1878     -4.7572940587997437e-02
    z[4,2,0]  R1879     3.5930645465850830e-01
    z[4,2,0]  R1880     7.1881860494613647e-01
    z[4,2,0]  R1881     2.6641449332237244e-01
    z[4,2,0]  R1882     5.2527123689651489e-01
    z[4,2,0]  R1883     2.4020172655582428e-02
    z[4,2,0]  R1884     -2.5739121437072754e-01
    z[4,2,0]  R1885     -1.3720057904720306e-01
    z[4,2,0]  R1886     -0.0615449957549572
    z[4,2,0]  R1887     -7.6408244669437408e-02
    z[4,2,0]  R1888     6.9351524114608765e-01
    z[4,2,0]  R1889     4.3329709768295288e-01
    z[4,2,0]  R1890     -4.7730613499879837e-02
    z[4,2,0]  R1891     -2.0059393346309662e-01
    z[4,2,0]  R1892     -2.2417631745338440e-01
    z[4,2,0]  R1893     -2.9909706115722656e-01
    z[4,2,0]  R1894     -2.5791233777999878e-01
    z[4,2,0]  R1895     3.9937341213226318e-01
    z[4,2,0]  R1896     -3.0486646294593811e-01
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1665     -1
    z[4,2,1]  R1666     1
    z[4,2,1]  R1677     -3.5023787617683411e-01
    z[4,2,1]  R1678     -2.5114196538925171e-01
    z[4,2,1]  R1679     -3.5928779840469360e-01
    z[4,2,1]  R1680     -2.9726028442382812e-01
    z[4,2,1]  R1681     -5.5615627765655518e-01
    z[4,2,1]  R1682     -5.1980084180831909e-01
    z[4,2,1]  R1683     -4.0141481161117554e-01
    z[4,2,1]  R1684     -2.5546005368232727e-01
    z[4,2,1]  R1685     -0.32403364777565
    z[4,2,1]  R1686     -2.9785001277923584e-01
    z[4,2,1]  R1687     -7.1147876977920532e-01
    z[4,2,1]  R1688     -4.6179959177970886e-01
    z[4,2,1]  R1689     -3.7745356559753418e-01
    z[4,2,1]  R1690     7.5218003988265991e-01
    z[4,2,1]  R1691     -5.3693801164627075e-01
    z[4,2,1]  R1692     -6.2811189889907837e-01
    z[4,2,1]  R1693     -7.1127003431320190e-01
    z[4,2,1]  R1694     -4.3059056997299194e-01
    z[4,2,1]  R1695     -4.5296445488929749e-01
    z[4,2,1]  R1696     -4.9211472272872925e-01
    z[4,2,1]  R1697     -6.8705797195434570e-01
    z[4,2,1]  R1698     -3.8977241516113281e-01
    z[4,2,1]  R1699     7.1482799947261810e-02
    z[4,2,1]  R1700     -5.5262351036071777e-01
    z[4,2,1]  R1701     -5.0978618860244751e-01
    z[4,2,1]  R1702     7.4618428945541382e-01
    z[4,2,1]  R1703     8.8835489749908447e-01
    z[4,2,1]  R1704     -1.7341756820678711e-01
    z[4,2,1]  R1705     8.2127535343170166e-01
    z[4,2,1]  R1706     -0.522761881351471
    z[4,2,1]  R1707     -2.8531920909881592e-01
    z[4,2,1]  R1708     -5.0097370147705078e-01
    z[4,2,1]  R1709     -5.6872421503067017e-01
    z[4,2,1]  R1710     -4.4913262128829956e-01
    z[4,2,1]  R1711     -5.8296936750411987e-01
    z[4,2,1]  R1712     -5.0831443071365356e-01
    z[4,2,1]  R1713     -4.9253699183464050e-01
    z[4,2,1]  R1714     -1.8199425935745239e-01
    z[4,2,1]  R1715     5.9212136268615723e-01
    z[4,2,1]  R1716     8.6953115463256836e-01
    z[4,2,1]  R1717     -2.9620343446731567e-01
    z[4,2,1]  R1718     -8.4968489408493042e-01
    z[4,2,1]  R1719     -5.1040691137313843e-01
    z[4,2,1]  R1720     -2.2170072793960571e-01
    z[4,2,1]  R1721     -5.4525840282440186e-01
    z[4,2,1]  R1722     -1.0907662659883499e-01
    z[4,2,1]  R1723     -2.1314503252506256e-01
    z[4,2,1]  R1724     8.4723156690597534e-01
    z[4,2,1]  R1725     0.880919337272644
    z[4,2,1]  R1726     7.2155517339706421e-01
    z[4,2,1]  R1727     -0.628449022769928
    z[4,2,1]  R1728     -7.0719486474990845e-01
    z[4,2,1]  R1729     -8.2792568206787109e-01
    z[4,2,1]  R1730     -7.3079919815063477e-01
    z[4,2,1]  R1731     -6.0353887081146240e-01
    z[4,2,1]  R1732     -1.8426091969013214e-01
    z[4,2,1]  R1733     -4.6042034029960632e-01
    z[4,2,1]  R1734     -8.7848186492919922e-02
    z[4,2,1]  R1735     0.886595606803894
    z[4,2,1]  R1736     9.6384423971176147e-01
    z[4,2,1]  R1737     -4.5259761810302734e-01
    z[4,2,1]  R1738     -2.2987347841262817e-01
    z[4,2,1]  R1739     -0.301234632730484
    z[4,2,1]  R1740     -1.4728754758834839e-01
    z[4,2,1]  R1741     8.4514260292053223e-01
    z[4,2,1]  R1742     8.3458983898162842e-01
    z[4,2,1]  R1743     9.0441882610321045e-01
    z[4,2,1]  R1744     5.4224532842636108e-01
    z[4,2,1]  R1745     4.8052567243576050e-01
    z[4,2,1]  R1746     4.5277449488639832e-01
    z[4,2,1]  R1747     -0.736034631729126
    z[4,2,1]  R1748     -0.50221848487854
    z[4,2,1]  R1749     -2.9484912753105164e-01
    z[4,2,1]  R1750     -3.2997876405715942e-01
    z[4,2,1]  R1751     -3.0022957921028137e-01
    z[4,2,1]  R1752     -0.0613643079996109
    z[4,2,1]  R1753     8.3372437953948975e-01
    z[4,2,1]  R1754     0.959001362323761
    z[4,2,1]  R1755     8.2865160703659058e-01
    z[4,2,1]  R1756     8.6359906196594238e-01
    z[4,2,1]  R1757     -7.7929478883743286e-01
    z[4,2,1]  R1758     5.7339859008789062e-01
    z[4,2,1]  R1759     7.7785891294479370e-01
    z[4,2,1]  R1760     -0.228417307138443
    z[4,2,1]  R1761     6.4570468664169312e-01
    z[4,2,1]  R1762     0.749077558517456
    z[4,2,1]  R1763     7.8521335124969482e-01
    z[4,2,1]  R1764     6.2177753448486328e-01
    z[4,2,1]  R1765     5.0166165828704834e-01
    z[4,2,1]  R1766     6.4847087860107422e-01
    z[4,2,1]  R1767     -5.2170819044113159e-01
    z[4,2,1]  R1768     -2.6020979881286621e-01
    z[4,2,1]  R1769     -1.6403673589229584e-01
    z[4,2,1]  R1770     -2.5790682435035706e-01
    z[4,2,1]  R1771     7.9363530874252319e-01
    z[4,2,1]  R1772     9.5412641763687134e-01
    z[4,2,1]  R1773     9.1491103172302246e-01
    z[4,2,1]  R1774     0.478773295879364
    z[4,2,1]  R1775     0.548701286315918
    z[4,2,1]  R1776     6.0121679306030273e-01
    z[4,2,1]  R1777     -1.6934056580066681e-01
    z[4,2,1]  R1778     8.2446902990341187e-01
    z[4,2,1]  R1779     9.6358984708786011e-01
    z[4,2,1]  R1780     6.5812236070632935e-01
    z[4,2,1]  R1781     7.1535408496856689e-01
    z[4,2,1]  R1782     5.4849225282669067e-01
    z[4,2,1]  R1783     7.1080332994461060e-01
    z[4,2,1]  R1784     7.2019606828689575e-01
    z[4,2,1]  R1785     0.670100748538971
    z[4,2,1]  R1786     0.737332820892334
    z[4,2,1]  R1787     -4.4949498772621155e-01
    z[4,2,1]  R1788     -3.3479818701744080e-01
    z[4,2,1]  R1789     -4.0453898906707764e-01
    z[4,2,1]  R1790     -2.1958525478839874e-01
    z[4,2,1]  R1791     -4.5704743266105652e-01
    z[4,2,1]  R1792     -3.9728373289108276e-01
    z[4,2,1]  R1793     -4.2038300633430481e-01
    z[4,2,1]  R1794     -3.3675962686538696e-01
    z[4,2,1]  R1795     -3.1949669122695923e-01
    z[4,2,1]  R1796     -5.7820230722427368e-01
    z[4,2,1]  R1797     -4.9175927042961121e-01
    z[4,2,1]  R1798     -4.1158196330070496e-01
    z[4,2,1]  R1799     -2.6734501123428345e-01
    z[4,2,1]  R1800     -0.53836989402771
    z[4,2,1]  R1801     -0.342671275138855
    z[4,2,1]  R1802     -0.541056752204895
    z[4,2,1]  R1803     -5.0658035278320312e-01
    z[4,2,1]  R1804     -4.2686796188354492e-01
    z[4,2,1]  R1805     -4.5486468076705933e-01
    z[4,2,1]  R1806     -4.7082564234733582e-01
    z[4,2,1]  R1807     8.3409690856933594e-01
    z[4,2,1]  R1808     8.9928787946701050e-01
    z[4,2,1]  R1809     5.4799276590347290e-01
    z[4,2,1]  R1810     8.9229595661163330e-01
    z[4,2,1]  R1811     8.1544631719589233e-01
    z[4,2,1]  R1812     4.9941697716712952e-01
    z[4,2,1]  R1813     8.3573579788208008e-01
    z[4,2,1]  R1814     6.6910892724990845e-01
    z[4,2,1]  R1815     0.512220561504364
    z[4,2,1]  R1816     0.647648811340332
    z[4,2,1]  R1817     -0.624687135219574
    z[4,2,1]  R1818     -1.5297412872314453e-01
    z[4,2,1]  R1819     -3.5245409607887268e-01
    z[4,2,1]  R1820     3.9174661040306091e-01
    z[4,2,1]  R1821     5.8493453264236450e-01
    z[4,2,1]  R1822     -4.7863489389419556e-01
    z[4,2,1]  R1823     3.3903810381889343e-01
    z[4,2,1]  R1824     5.1297110319137573e-01
    z[4,2,1]  R1825     2.3550365865230560e-01
    z[4,2,1]  R1826     5.3314840793609619e-01
    z[4,2,1]  R1827     -2.4784113466739655e-01
    z[4,2,1]  R1828     -5.9990996122360229e-01
    z[4,2,1]  R1829     -4.7414350509643555e-01
    z[4,2,1]  R1830     -3.4876686334609985e-01
    z[4,2,1]  R1831     -3.4695991873741150e-01
    z[4,2,1]  R1832     4.0909501910209656e-01
    z[4,2,1]  R1833     -4.9234721809625626e-02
    z[4,2,1]  R1834     5.2433037757873535e-01
    z[4,2,1]  R1835     7.4485820531845093e-01
    z[4,2,1]  R1836     3.7005302309989929e-01
    z[4,2,1]  R1837     -5.4520559310913086e-01
    z[4,2,1]  R1838     -3.6321339011192322e-01
    z[4,2,1]  R1839     -3.1689906120300293e-01
    z[4,2,1]  R1840     4.6174535155296326e-01
    z[4,2,1]  R1841     3.0371323227882385e-01
    z[4,2,1]  R1842     4.5032000541687012e-01
    z[4,2,1]  R1843     3.2231101393699646e-01
    z[4,2,1]  R1844     3.0020135641098022e-01
    z[4,2,1]  R1845     7.2646868228912354e-01
    z[4,2,1]  R1846     2.7069088816642761e-01
    z[4,2,1]  R1847     -0.708975076675415
    z[4,2,1]  R1848     -3.2215201854705811e-01
    z[4,2,1]  R1849     -5.3843152523040771e-01
    z[4,2,1]  R1850     -6.7342722415924072e-01
    z[4,2,1]  R1851     -1.2217929214239120e-01
    z[4,2,1]  R1852     2.8495249152183533e-01
    z[4,2,1]  R1853     4.0100643038749695e-01
    z[4,2,1]  R1854     6.8663710355758667e-01
    z[4,2,1]  R1855     7.4688619375228882e-01
    z[4,2,1]  R1856     0.786733090877533
    z[4,2,1]  R1857     -5.9715646505355835e-01
    z[4,2,1]  R1858     -3.9939552545547485e-01
    z[4,2,1]  R1859     -0.359060674905777
    z[4,2,1]  R1860     -5.4217046499252319e-01
    z[4,2,1]  R1861     -3.9332851767539978e-01
    z[4,2,1]  R1862     -6.6162484884262085e-01
    z[4,2,1]  R1863     -6.2013298273086548e-01
    z[4,2,1]  R1864     -1.5233758091926575e-01
    z[4,2,1]  R1865     6.9876176118850708e-01
    z[4,2,1]  R1866     4.9144935607910156e-01
    z[4,2,1]  R1867     -6.2753462791442871e-01
    z[4,2,1]  R1868     -5.0875192880630493e-01
    z[4,2,1]  R1869     -3.8915121555328369e-01
    z[4,2,1]  R1870     -6.5223330259323120e-01
    z[4,2,1]  R1871     -2.3108184337615967e-01
    z[4,2,1]  R1872     4.8056399822235107e-01
    z[4,2,1]  R1873     6.7994487285614014e-01
    z[4,2,1]  R1874     7.9221922159194946e-01
    z[4,2,1]  R1875     6.3531875610351562e-01
    z[4,2,1]  R1876     0.653005838394165
    z[4,2,1]  R1877     -6.4434444904327393e-01
    z[4,2,1]  R1878     -0.489510715007782
    z[4,2,1]  R1879     -1.9995056092739105e-01
    z[4,2,1]  R1880     3.3218595385551453e-01
    z[4,2,1]  R1881     8.8451522588729858e-01
    z[4,2,1]  R1882     6.7061942815780640e-01
    z[4,2,1]  R1883     8.2782679796218872e-01
    z[4,2,1]  R1884     8.5486674308776855e-01
    z[4,2,1]  R1885     8.5490471124649048e-01
    z[4,2,1]  R1886     9.0760940313339233e-01
    z[4,2,1]  R1887     -6.9260370731353760e-01
    z[4,2,1]  R1888     3.5019379854202271e-01
    z[4,2,1]  R1889     7.1538847684860229e-01
    z[4,2,1]  R1890     8.1186813116073608e-01
    z[4,2,1]  R1891     9.3135637044906616e-01
    z[4,2,1]  R1892     9.2622154951095581e-01
    z[4,2,1]  R1893     7.4198907613754272e-01
    z[4,2,1]  R1894     7.0418852567672729e-01
    z[4,2,1]  R1895     6.0367500782012939e-01
    z[4,2,1]  R1896     8.0924779176712036e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1667     -1
    z[4,2,2]  R1668     1
    z[4,2,2]  R1677     -1.9520850479602814e-01
    z[4,2,2]  R1678     9.2998119071125984e-03
    z[4,2,2]  R1679     -5.1382946968078613e-01
    z[4,2,2]  R1680     1.9087596237659454e-01
    z[4,2,2]  R1681     -1.3207024335861206e-01
    z[4,2,2]  R1682     -1.5683691203594208e-01
    z[4,2,2]  R1683     -3.3692610263824463e-01
    z[4,2,2]  R1684     -2.0341442525386810e-01
    z[4,2,2]  R1685     9.9804960191249847e-02
    z[4,2,2]  R1686     6.1308752745389938e-02
    z[4,2,2]  R1687     -2.7224181219935417e-02
    z[4,2,2]  R1688     1.4349375665187836e-01
    z[4,2,2]  R1689     -1.2734179198741913e-01
    z[4,2,2]  R1690     -2.1428765356540680e-01
    z[4,2,2]  R1691     7.2389543056488037e-01
    z[4,2,2]  R1692     5.6075859069824219e-01
    z[4,2,2]  R1693     4.6849995851516724e-01
    z[4,2,2]  R1694     -3.2706481218338013e-01
    z[4,2,2]  R1695     9.1979922726750374e-03
    z[4,2,2]  R1696     -5.4430490732192993e-01
    z[4,2,2]  R1697     5.6827646493911743e-01
    z[4,2,2]  R1698     -5.1286339759826660e-01
    z[4,2,2]  R1699     -0.46903195977211
    z[4,2,2]  R1700     1.9012993574142456e-01
    z[4,2,2]  R1701     -2.2154814004898071e-01
    z[4,2,2]  R1702     5.2097213268280029e-01
    z[4,2,2]  R1703     -1.8444817513227463e-02
    z[4,2,2]  R1704     6.6841256618499756e-01
    z[4,2,2]  R1705     3.9735755324363708e-01
    z[4,2,2]  R1706     -5.5841112136840820e-01
    z[4,2,2]  R1707     -1.5113285183906555e-01
    z[4,2,2]  R1708     1.7867620289325714e-01
    z[4,2,2]  R1709     5.4607796669006348e-01
    z[4,2,2]  R1710     -5.6303566694259644e-01
    z[4,2,2]  R1711     -3.3601748943328857e-01
    z[4,2,2]  R1712     -1.7890906333923340e-01
    z[4,2,2]  R1713     -1.4444294571876526e-01
    z[4,2,2]  R1714     -0.652751088142395
    z[4,2,2]  R1715     -3.9298117160797119e-01
    z[4,2,2]  R1716     9.1285429894924164e-02
    z[4,2,2]  R1717     -0.668785572052002
    z[4,2,2]  R1718     1.9610232114791870e-01
    z[4,2,2]  R1719     -7.2156423330307007e-01
    z[4,2,2]  R1720     1.7301666736602783e-01
    z[4,2,2]  R1721     -3.2959020137786865e-01
    z[4,2,2]  R1722     1.7456393688917160e-02
    z[4,2,2]  R1723     2.7208173274993896e-01
    z[4,2,2]  R1724     1.0649657994508743e-01
    z[4,2,2]  R1725     -0.0938347652554512
    z[4,2,2]  R1726     4.1236659884452820e-01
    z[4,2,2]  R1727     -0.494943231344223
    z[4,2,2]  R1728     -1.2691226601600647e-01
    z[4,2,2]  R1729     5.0492975860834122e-02
    z[4,2,2]  R1730     4.7204467654228210e-01
    z[4,2,2]  R1731     -8.4907226264476776e-02
    z[4,2,2]  R1732     -1.3565035164356232e-01
    z[4,2,2]  R1733     1.6225245594978333e-01
    z[4,2,2]  R1734     -1.5981492400169373e-01
    z[4,2,2]  R1735     0.0615328773856163
    z[4,2,2]  R1736     1.6760799288749695e-01
    z[4,2,2]  R1737     -1.1647468805313110e-01
    z[4,2,2]  R1738     2.5308451056480408e-01
    z[4,2,2]  R1739     -2.0218318328261375e-02
    z[4,2,2]  R1740     0.582478940486908
    z[4,2,2]  R1741     2.9166597127914429e-01
    z[4,2,2]  R1742     4.5439252257347107e-01
    z[4,2,2]  R1743     2.3995140194892883e-01
    z[4,2,2]  R1744     1.7692428827285767e-01
    z[4,2,2]  R1745     3.7672752141952515e-01
    z[4,2,2]  R1746     1.2909972667694092e-01
    z[4,2,2]  R1747     6.1129800975322723e-02
    z[4,2,2]  R1748     4.1504953987896442e-03
    z[4,2,2]  R1749     3.5807663202285767e-01
    z[4,2,2]  R1750     1.4697174727916718e-01
    z[4,2,2]  R1751     -2.2409553825855255e-01
    z[4,2,2]  R1752     -1.0674206167459488e-01
    z[4,2,2]  R1753     2.6567617058753967e-01
    z[4,2,2]  R1754     1.8880042433738708e-01
    z[4,2,2]  R1755     3.4775212407112122e-01
    z[4,2,2]  R1756     -0.073155976831913
    z[4,2,2]  R1757     5.9725141525268555e-01
    z[4,2,2]  R1758     -9.0044438838958740e-02
    z[4,2,2]  R1759     3.5335725545883179e-01
    z[4,2,2]  R1760     -4.3700179457664490e-01
    z[4,2,2]  R1761     2.0539747178554535e-01
    z[4,2,2]  R1762     2.1612955629825592e-01
    z[4,2,2]  R1763     3.0064875259995461e-02
    z[4,2,2]  R1764     2.0245923101902008e-01
    z[4,2,2]  R1765     2.1178799867630005e-01
    z[4,2,2]  R1766     -3.9450940489768982e-01
    z[4,2,2]  R1767     4.3772339820861816e-02
    z[4,2,2]  R1768     -4.0393903851509094e-02
    z[4,2,2]  R1769     9.4932131469249725e-02
    z[4,2,2]  R1770     -3.7179183959960938e-01
    z[4,2,2]  R1771     2.8107839822769165e-01
    z[4,2,2]  R1772     1.8511307239532471e-01
    z[4,2,2]  R1773     -1.2274567782878876e-01
    z[4,2,2]  R1774     1.3293507695198059e-01
    z[4,2,2]  R1775     2.1158735454082489e-01
    z[4,2,2]  R1776     -5.7536359876394272e-02
    z[4,2,2]  R1777     3.7202858924865723e-01
    z[4,2,2]  R1778     2.4892997741699219e-01
    z[4,2,2]  R1779     6.7938235588371754e-03
    z[4,2,2]  R1780     2.5844931602478027e-01
    z[4,2,2]  R1781     1.1316926218569279e-02
    z[4,2,2]  R1782     6.3249832019209862e-03
    z[4,2,2]  R1783     -2.2752940654754639e-01
    z[4,2,2]  R1784     -3.5796791315078735e-01
    z[4,2,2]  R1785     -2.9539284110069275e-01
    z[4,2,2]  R1786     -1.9871445000171661e-01
    z[4,2,2]  R1787     -8.3873413503170013e-02
    z[4,2,2]  R1788     -4.6433258801698685e-02
    z[4,2,2]  R1789     -2.2240121662616730e-01
    z[4,2,2]  R1790     -2.7171779423952103e-02
    z[4,2,2]  R1791     -3.3987402915954590e-01
    z[4,2,2]  R1792     -5.5712664127349854e-01
    z[4,2,2]  R1793     -1.9285935163497925e-01
    z[4,2,2]  R1794     -7.8938134014606476e-02
    z[4,2,2]  R1795     -2.2901487350463867e-01
    z[4,2,2]  R1796     -7.9810842871665955e-02
    z[4,2,2]  R1797     2.6303282380104065e-01
    z[4,2,2]  R1798     2.6568922400474548e-01
    z[4,2,2]  R1799     4.1921749711036682e-01
    z[4,2,2]  R1800     -9.8678901791572571e-02
    z[4,2,2]  R1801     -2.0471695065498352e-01
    z[4,2,2]  R1802     1.9106050953269005e-02
    z[4,2,2]  R1803     -3.7495499849319458e-01
    z[4,2,2]  R1804     0.246204674243927
    z[4,2,2]  R1805     -7.9527176916599274e-02
    z[4,2,2]  R1806     -4.0902385115623474e-01
    z[4,2,2]  R1807     2.3406212031841278e-01
    z[4,2,2]  R1808     2.1850508451461792e-01
    z[4,2,2]  R1809     2.0507957041263580e-01
    z[4,2,2]  R1810     2.8700596094131470e-01
    z[4,2,2]  R1811     1.1165440827608109e-01
    z[4,2,2]  R1812     2.7908065915107727e-01
    z[4,2,2]  R1813     1.8962990492582321e-02
    z[4,2,2]  R1814     4.4834561645984650e-02
    z[4,2,2]  R1815     2.2323322296142578e-01
    z[4,2,2]  R1816     1.2390603870153427e-01
    z[4,2,2]  R1817     0.0780886635184288
    z[4,2,2]  R1818     1.9408886134624481e-01
    z[4,2,2]  R1819     -4.8023164272308350e-01
    z[4,2,2]  R1820     2.6034104824066162e-01
    z[4,2,2]  R1821     1.3381375372409821e-01
    z[4,2,2]  R1822     4.1495844721794128e-01
    z[4,2,2]  R1823     1.1374760419130325e-01
    z[4,2,2]  R1824     -2.3696143925189972e-01
    z[4,2,2]  R1825     2.4504022300243378e-01
    z[4,2,2]  R1826     -5.6998956203460693e-01
    z[4,2,2]  R1827     2.1002964675426483e-01
    z[4,2,2]  R1828     1.1083374917507172e-01
    z[4,2,2]  R1829     -2.1317757666110992e-01
    z[4,2,2]  R1830     2.2484730929136276e-02
    z[4,2,2]  R1831     1.1564595997333527e-01
    z[4,2,2]  R1832     -3.6476936936378479e-01
    z[4,2,2]  R1833     -7.3987501859664917e-01
    z[4,2,2]  R1834     -2.7295741438865662e-01
    z[4,2,2]  R1835     -1.7261974513530731e-01
    z[4,2,2]  R1836     -3.0395638942718506e-01
    z[4,2,2]  R1837     -2.3103702813386917e-02
    z[4,2,2]  R1838     3.4460190683603287e-02
    z[4,2,2]  R1839     0.0395638681948185
    z[4,2,2]  R1840     2.0583797991275787e-01
    z[4,2,2]  R1841     2.0590786635875702e-01
    z[4,2,2]  R1842     2.1422188729047775e-02
    z[4,2,2]  R1843     3.2103773951530457e-01
    z[4,2,2]  R1844     1.3293132185935974e-01
    z[4,2,2]  R1845     1.5961390733718872e-01
    z[4,2,2]  R1846     -2.8850415349006653e-01
    z[4,2,2]  R1847     3.6791037768125534e-02
    z[4,2,2]  R1848     1.2451093643903732e-02
    z[4,2,2]  R1849     1.8904432363342494e-04
    z[4,2,2]  R1850     -3.2507389783859253e-01
    z[4,2,2]  R1851     0.0774095356464386
    z[4,2,2]  R1852     3.6462989449501038e-01
    z[4,2,2]  R1853     -4.1372212767601013e-01
    z[4,2,2]  R1854     -1.2415719032287598e-01
    z[4,2,2]  R1855     -0.0970790833234787
    z[4,2,2]  R1856     -2.9878395795822144e-01
    z[4,2,2]  R1857     1.2553636729717255e-01
    z[4,2,2]  R1858     3.5829934477806091e-01
    z[4,2,2]  R1859     2.2452621161937714e-01
    z[4,2,2]  R1860     -1.6520200669765472e-01
    z[4,2,2]  R1861     3.6298206448554993e-01
    z[4,2,2]  R1862     6.0138802975416183e-02
    z[4,2,2]  R1863     6.9822356104850769e-02
    z[4,2,2]  R1864     -3.4507915377616882e-02
    z[4,2,2]  R1865     2.3588884621858597e-02
    z[4,2,2]  R1866     1.5894058346748352e-01
    z[4,2,2]  R1867     2.1491686347872019e-03
    z[4,2,2]  R1868     1.8455219268798828e-01
    z[4,2,2]  R1869     -5.6969024240970612e-02
    z[4,2,2]  R1870     -2.6415362954139709e-01
    z[4,2,2]  R1871     1.1966821737587452e-02
    z[4,2,2]  R1872     -4.4037967920303345e-01
    z[4,2,2]  R1873     -2.6911085471510887e-02
    z[4,2,2]  R1874     -1.9403958320617676e-01
    z[4,2,2]  R1875     -2.5870782136917114e-01
    z[4,2,2]  R1876     -2.3429703712463379e-01
    z[4,2,2]  R1877     2.5956448912620544e-01
    z[4,2,2]  R1878     3.8324168324470520e-01
    z[4,2,2]  R1879     -0.618421196937561
    z[4,2,2]  R1880     4.4852638244628906e-01
    z[4,2,2]  R1881     1.7736503481864929e-01
    z[4,2,2]  R1882     -2.2517210245132446e-01
    z[4,2,2]  R1883     -8.2901574671268463e-02
    z[4,2,2]  R1884     2.7789219748228788e-03
    z[4,2,2]  R1885     -4.8508081585168839e-02
    z[4,2,2]  R1886     -5.1402464509010315e-02
    z[4,2,2]  R1887     2.8791493177413940e-01
    z[4,2,2]  R1888     4.8713916540145874e-01
    z[4,2,2]  R1889     -2.3065733909606934e-01
    z[4,2,2]  R1890     -7.4305996298789978e-02
    z[4,2,2]  R1891     -7.2838112711906433e-02
    z[4,2,2]  R1892     -1.8119428306818008e-02
    z[4,2,2]  R1893     -3.2035443931818008e-02
    z[4,2,2]  R1894     -0.0669550821185112
    z[4,2,2]  R1895     -4.0896505117416382e-01
    z[4,2,2]  R1896     0.145684614777565
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1669     -1
    z[4,2,3]  R1670     1
    z[4,2,3]  R1677     -3.6240240931510925e-01
    z[4,2,3]  R1678     -5.8406364917755127e-01
    z[4,2,3]  R1679     -3.9486807584762573e-01
    z[4,2,3]  R1680     -4.8408702015876770e-01
    z[4,2,3]  R1681     -2.6580053567886353e-01
    z[4,2,3]  R1682     -1.0204381495714188e-01
    z[4,2,3]  R1683     -2.9818978905677795e-01
    z[4,2,3]  R1684     -4.7207662463188171e-01
    z[4,2,3]  R1685     -4.9308976531028748e-01
    z[4,2,3]  R1686     -4.1535407304763794e-01
    z[4,2,3]  R1687     -1.7730298638343811e-01
    z[4,2,3]  R1688     9.8836747929453850e-03
    z[4,2,3]  R1689     6.6793225705623627e-02
    z[4,2,3]  R1690     2.3008877038955688e-01
    z[4,2,3]  R1691     3.6241963505744934e-01
    z[4,2,3]  R1692     1.1827819049358368e-01
    z[4,2,3]  R1693     4.2783892154693604e-01
    z[4,2,3]  R1694     0.361988365650177
    z[4,2,3]  R1695     1.6963206231594086e-01
    z[4,2,3]  R1696     3.9747819304466248e-01
    z[4,2,3]  R1697     2.1296314895153046e-01
    z[4,2,3]  R1698     1.4430669136345387e-02
    z[4,2,3]  R1699     -3.5894379019737244e-01
    z[4,2,3]  R1700     -5.8972876518964767e-02
    z[4,2,3]  R1701     -1.3377124071121216e-01
    z[4,2,3]  R1702     2.0331309735774994e-01
    z[4,2,3]  R1703     1.6727812588214874e-01
    z[4,2,3]  R1704     -4.0399852395057678e-01
    z[4,2,3]  R1705     -2.3591844365000725e-02
    z[4,2,3]  R1706     4.4183173775672913e-01
    z[4,2,3]  R1707     -3.2720467448234558e-01
    z[4,2,3]  R1708     -4.3055215477943420e-01
    z[4,2,3]  R1709     -3.1249335408210754e-01
    z[4,2,3]  R1710     0.405229389667511
    z[4,2,3]  R1711     1.7126889526844025e-01
    z[4,2,3]  R1712     5.4399931430816650e-01
    z[4,2,3]  R1713     3.7154817581176758e-01
    z[4,2,3]  R1714     -7.8700542449951172e-02
    z[4,2,3]  R1715     -6.3104387372732162e-03
    z[4,2,3]  R1716     2.0656596124172211e-01
    z[4,2,3]  R1717     -2.2475211322307587e-01
    z[4,2,3]  R1718     -5.3780917078256607e-02
    z[4,2,3]  R1719     2.1162706613540649e-01
    z[4,2,3]  R1720     -6.0689233243465424e-02
    z[4,2,3]  R1721     4.1020902991294861e-01
    z[4,2,3]  R1722     -6.2734061479568481e-01
    z[4,2,3]  R1723     -1.5283970534801483e-01
    z[4,2,3]  R1724     9.8189562559127808e-02
    z[4,2,3]  R1725     3.2321885228157043e-01
    z[4,2,3]  R1726     0.495151162147522
    z[4,2,3]  R1727     -1.1997682973742485e-02
    z[4,2,3]  R1728     -3.3768004179000854e-01
    z[4,2,3]  R1729     2.6501366496086121e-01
    z[4,2,3]  R1730     2.4692660570144653e-01
    z[4,2,3]  R1731     1.5630787611007690e-01
    z[4,2,3]  R1732     -3.9980259537696838e-01
    z[4,2,3]  R1733     2.1275892853736877e-02
    z[4,2,3]  R1734     -2.5178197026252747e-01
    z[4,2,3]  R1735     3.1184336543083191e-01
    z[4,2,3]  R1736     2.5135293602943420e-02
    z[4,2,3]  R1737     4.3311214447021484e-01
    z[4,2,3]  R1738     -4.6883741021156311e-01
    z[4,2,3]  R1739     1.8819957971572876e-02
    z[4,2,3]  R1740     -3.3058160543441772e-01
    z[4,2,3]  R1741     4.9212433397769928e-02
    z[4,2,3]  R1742     5.8376058936119080e-02
    z[4,2,3]  R1743     2.5313809514045715e-01
    z[4,2,3]  R1744     3.5397332906723022e-01
    z[4,2,3]  R1745     4.8243951797485352e-01
    z[4,2,3]  R1746     0.520687997341156
    z[4,2,3]  R1747     -5.3401719778776169e-02
    z[4,2,3]  R1748     3.7972751259803772e-01
    z[4,2,3]  R1749     -1.1306407302618027e-01
    z[4,2,3]  R1750     -3.3169585466384888e-01
    z[4,2,3]  R1751     2.3402684926986694e-01
    z[4,2,3]  R1752     -3.3222606778144836e-01
    z[4,2,3]  R1753     2.2909869253635406e-01
    z[4,2,3]  R1754     1.4218333363533020e-01
    z[4,2,3]  R1755     2.0553000271320343e-01
    z[4,2,3]  R1756     2.3103292286396027e-01
    z[4,2,3]  R1757     -5.7719651609659195e-02
    z[4,2,3]  R1758     1.9641692936420441e-01
    z[4,2,3]  R1759     1.0498762130737305e-01
    z[4,2,3]  R1760     8.7422579526901245e-02
    z[4,2,3]  R1761     0.33449786901474
    z[4,2,3]  R1762     2.0736102759838104e-01
    z[4,2,3]  R1763     3.3902138471603394e-01
    z[4,2,3]  R1764     -2.3966248333454132e-01
    z[4,2,3]  R1765     3.6694878339767456e-01
    z[4,2,3]  R1766     -5.0786721706390381e-01
    z[4,2,3]  R1767     -2.3085476830601692e-02
    z[4,2,3]  R1768     1.0495626181364059e-01
    z[4,2,3]  R1769     -3.4113073348999023e-01
    z[4,2,3]  R1770     8.6206562817096710e-02
    z[4,2,3]  R1771     2.9715862870216370e-01
    z[4,2,3]  R1772     1.2247022241353989e-01
    z[4,2,3]  R1773     -2.4262189865112305e-02
    z[4,2,3]  R1774     6.0212099552154541e-01
    z[4,2,3]  R1775     2.7250188589096069e-01
    z[4,2,3]  R1776     2.7629515528678894e-01
    z[4,2,3]  R1777     -2.8098204731941223e-01
    z[4,2,3]  R1778     8.2127936184406281e-02
    z[4,2,3]  R1779     9.0992741286754608e-02
    z[4,2,3]  R1780     5.9459584951400757e-01
    z[4,2,3]  R1781     4.8615738749504089e-01
    z[4,2,3]  R1782     4.2329812049865723e-01
    z[4,2,3]  R1783     1.4226980507373810e-02
    z[4,2,3]  R1784     -1.6567033529281616e-01
    z[4,2,3]  R1785     -1.9238793849945068e-01
    z[4,2,3]  R1786     -1.8471808731555939e-01
    z[4,2,3]  R1787     -3.1444865465164185e-01
    z[4,2,3]  R1788     -1.4626236259937286e-01
    z[4,2,3]  R1789     -5.8290481567382812e-01
    z[4,2,3]  R1790     -0.359375923871994
    z[4,2,3]  R1791     -4.0348294377326965e-01
    z[4,2,3]  R1792     -0.338177889585495
    z[4,2,3]  R1793     -1.1701557785272598e-01
    z[4,2,3]  R1794     -4.8129951953887939e-01
    z[4,2,3]  R1795     -0.119330033659935
    z[4,2,3]  R1796     -1.2594413757324219e-01
    z[4,2,3]  R1797     0.777704656124115
    z[4,2,3]  R1798     5.0404578447341919e-01
    z[4,2,3]  R1799     7.4074435234069824e-01
    z[4,2,3]  R1800     -3.2771375775337219e-01
    z[4,2,3]  R1801     -4.4695916771888733e-01
    z[4,2,3]  R1802     -1.6949616372585297e-02
    z[4,2,3]  R1803     8.2354426383972168e-02
    z[4,2,3]  R1804     9.8446160554885864e-02
    z[4,2,3]  R1805     1.3948664069175720e-01
    z[4,2,3]  R1806     7.8831324353814125e-03
    z[4,2,3]  R1807     -4.2408472299575806e-01
    z[4,2,3]  R1808     -3.1299224495887756e-01
    z[4,2,3]  R1809     3.4943778067827225e-02
    z[4,2,3]  R1810     -2.7338418364524841e-01
    z[4,2,3]  R1811     -5.3486210107803345e-01
    z[4,2,3]  R1812     1.8606856465339661e-01
    z[4,2,3]  R1813     -0.537039577960968
    z[4,2,3]  R1814     3.3837845921516418e-01
    z[4,2,3]  R1815     1.2361179292201996e-01
    z[4,2,3]  R1816     5.2461528778076172e-01
    z[4,2,3]  R1817     -2.7048733830451965e-01
    z[4,2,3]  R1818     -3.6922267079353333e-01
    z[4,2,3]  R1819     4.0404331684112549e-01
    z[4,2,3]  R1820     6.9523942470550537e-01
    z[4,2,3]  R1821     2.1272036433219910e-01
    z[4,2,3]  R1822     -5.4666560143232346e-02
    z[4,2,3]  R1823     0.553445041179657
    z[4,2,3]  R1824     -6.5014642477035522e-01
    z[4,2,3]  R1825     5.9282785654067993e-01
    z[4,2,3]  R1826     -4.9514451622962952e-01
    z[4,2,3]  R1827     5.3969818353652954e-01
    z[4,2,3]  R1828     -4.2107868194580078e-01
    z[4,2,3]  R1829     4.0940076112747192e-01
    z[4,2,3]  R1830     3.0737709999084473e-01
    z[4,2,3]  R1831     -9.6147827804088593e-02
    z[4,2,3]  R1832     -6.3931626081466675e-01
    z[4,2,3]  R1833     5.4876238107681274e-01
    z[4,2,3]  R1834     -3.9552164077758789e-01
    z[4,2,3]  R1835     -2.9253163933753967e-01
    z[4,2,3]  R1836     -3.9204615354537964e-01
    z[4,2,3]  R1837     2.5662720203399658e-01
    z[4,2,3]  R1838     2.6621833443641663e-01
    z[4,2,3]  R1839     -3.8232272863388062e-01
    z[4,2,3]  R1840     6.3889360427856445e-01
    z[4,2,3]  R1841     7.0790648460388184e-01
    z[4,2,3]  R1842     6.2034225463867188e-01
    z[4,2,3]  R1843     -4.5698079466819763e-01
    z[4,2,3]  R1844     6.6236847639083862e-01
    z[4,2,3]  R1845     -3.5968446731567383e-01
    z[4,2,3]  R1846     -5.0943839550018311e-01
    z[4,2,3]  R1847     0.479433536529541
    z[4,2,3]  R1848     -1.0581338405609131e-01
    z[4,2,3]  R1849     2.8363707661628723e-01
    z[4,2,3]  R1850     3.5104501247406006e-01
    z[4,2,3]  R1851     -2.9018688201904297e-01
    z[4,2,3]  R1852     -1.8076236546039581e-01
    z[4,2,3]  R1853     -4.5794364809989929e-01
    z[4,2,3]  R1854     -8.6128480732440948e-02
    z[4,2,3]  R1855     -1.3811598718166351e-01
    z[4,2,3]  R1856     -5.3824737668037415e-02
    z[4,2,3]  R1857     6.4488071203231812e-01
    z[4,2,3]  R1858     6.2346053123474121e-01
    z[4,2,3]  R1859     0.664882481098175
    z[4,2,3]  R1860     -3.2524743676185608e-01
    z[4,2,3]  R1861     5.5865764617919922e-01
    z[4,2,3]  R1862     -1.5654183924198151e-01
    z[4,2,3]  R1863     -2.9144337773323059e-01
    z[4,2,3]  R1864     -6.5572023391723633e-01
    z[4,2,3]  R1865     1.2729948759078979e-01
    z[4,2,3]  R1866     4.0542042255401611e-01
    z[4,2,3]  R1867     3.1787082552909851e-01
    z[4,2,3]  R1868     4.4996318221092224e-01
    z[4,2,3]  R1869     -3.1418710947036743e-01
    z[4,2,3]  R1870     3.8389632105827332e-01
    z[4,2,3]  R1871     -5.3141820430755615e-01
    z[4,2,3]  R1872     -0.643108606338501
    z[4,2,3]  R1873     -2.4881545454263687e-02
    z[4,2,3]  R1874     -2.0807598531246185e-01
    z[4,2,3]  R1875     -1.1604075133800507e-01
    z[4,2,3]  R1876     -0.272417277097702
    z[4,2,3]  R1877     4.8620399832725525e-01
    z[4,2,3]  R1878     5.2253186702728271e-01
    z[4,2,3]  R1879     0.405316561460495
    z[4,2,3]  R1880     -1.4786474406719208e-01
    z[4,2,3]  R1881     -1.6723164916038513e-01
    z[4,2,3]  R1882     -1.1875883489847183e-01
    z[4,2,3]  R1883     2.3033621907234192e-01
    z[4,2,3]  R1884     2.2643083333969116e-01
    z[4,2,3]  R1885     1.6457028687000275e-01
    z[4,2,3]  R1886     1.6401518881320953e-01
    z[4,2,3]  R1887     5.4490929841995239e-01
    z[4,2,3]  R1888     -8.8538669049739838e-02
    z[4,2,3]  R1889     -1.3700371980667114e-01
    z[4,2,3]  R1890     1.9309966266155243e-01
    z[4,2,3]  R1891     2.3324583470821381e-01
    z[4,2,3]  R1892     2.7790060639381409e-01
    z[4,2,3]  R1893     0.458374559879303
    z[4,2,3]  R1894     4.9108245968818665e-01
    z[4,2,3]  R1895     -2.0483481884002686e-01
    z[4,2,3]  R1896     3.1911596655845642e-01
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1671     -1
    z[4,2,4]  R1672     1
    z[4,2,4]  R1677     -1.6682930290699005e-01
    z[4,2,4]  R1678     -1.9122330844402313e-01
    z[4,2,4]  R1679     -1.1914963275194168e-01
    z[4,2,4]  R1680     -2.1009781956672668e-01
    z[4,2,4]  R1681     -4.1547951102256775e-01
    z[4,2,4]  R1682     3.2895419280976057e-03
    z[4,2,4]  R1683     6.3411749899387360e-02
    z[4,2,4]  R1684     2.6501941680908203e-01
    z[4,2,4]  R1685     -9.0105690062046051e-02
    z[4,2,4]  R1686     2.3578166961669922e-01
    z[4,2,4]  R1687     -2.0581318438053131e-01
    z[4,2,4]  R1688     -1.5405574440956116e-01
    z[4,2,4]  R1689     -4.6345052123069763e-01
    z[4,2,4]  R1690     -1.7371930181980133e-01
    z[4,2,4]  R1691     1.5203894674777985e-01
    z[4,2,4]  R1692     -1.7029793560504913e-01
    z[4,2,4]  R1693     -1.4309158921241760e-01
    z[4,2,4]  R1694     6.5895318984985352e-02
    z[4,2,4]  R1695     -8.9322596788406372e-02
    z[4,2,4]  R1696     6.9609411060810089e-02
    z[4,2,4]  R1697     3.4623327851295471e-01
    z[4,2,4]  R1698     -4.7948709130287170e-01
    z[4,2,4]  R1699     -6.1006331443786621e-01
    z[4,2,4]  R1700     8.7079212069511414e-02
    z[4,2,4]  R1701     4.4583201408386230e-01
    z[4,2,4]  R1702     3.1959778070449829e-01
    z[4,2,4]  R1703     -0.0889601856470108
    z[4,2,4]  R1704     -4.1677546501159668e-01
    z[4,2,4]  R1705     1.6093716025352478e-01
    z[4,2,4]  R1706     2.8899261355400085e-01
    z[4,2,4]  R1707     -6.7880898714065552e-01
    z[4,2,4]  R1708     2.3162260651588440e-01
    z[4,2,4]  R1709     -4.2658692598342896e-01
    z[4,2,4]  R1710     3.7110611796379089e-02
    z[4,2,4]  R1711     0.253608763217926
    z[4,2,4]  R1712     -3.0783239006996155e-01
    z[4,2,4]  R1713     8.0141127109527588e-02
    z[4,2,4]  R1714     2.8608945012092590e-01
    z[4,2,4]  R1715     -3.0059763230383396e-03
    z[4,2,4]  R1716     3.0319327116012573e-01
    z[4,2,4]  R1717     -4.4815093278884888e-01
    z[4,2,4]  R1718     1.0846333205699921e-01
    z[4,2,4]  R1719     -2.5771671533584595e-01
    z[4,2,4]  R1720     7.1807242929935455e-02
    z[4,2,4]  R1721     3.1035497784614563e-01
    z[4,2,4]  R1722     3.9208721369504929e-02
    z[4,2,4]  R1723     -4.1954988241195679e-01
    z[4,2,4]  R1724     3.2510882616043091e-01
    z[4,2,4]  R1725     3.0939370393753052e-01
    z[4,2,4]  R1726     1.0399816930294037e-01
    z[4,2,4]  R1727     -3.2380643486976624e-01
    z[4,2,4]  R1728     -4.3692804872989655e-02
    z[4,2,4]  R1729     3.5460570454597473e-01
    z[4,2,4]  R1730     -1.2773409485816956e-01
    z[4,2,4]  R1731     -9.9731072783470154e-02
    z[4,2,4]  R1732     2.4622483551502228e-01
    z[4,2,4]  R1733     4.0934920310974121e-01
    z[4,2,4]  R1734     -2.5437366962432861e-01
    z[4,2,4]  R1735     3.4494414925575256e-02
    z[4,2,4]  R1736     3.8776747882366180e-02
    z[4,2,4]  R1737     -2.2928847372531891e-01
    z[4,2,4]  R1738     7.2756119072437286e-02
    z[4,2,4]  R1739     -5.0857514142990112e-01
    z[4,2,4]  R1740     2.7385911345481873e-01
    z[4,2,4]  R1741     3.0575612187385559e-01
    z[4,2,4]  R1742     2.1467334032058716e-01
    z[4,2,4]  R1743     1.6659593582153320e-01
    z[4,2,4]  R1744     6.6348105669021606e-01
    z[4,2,4]  R1745     -7.7274434268474579e-02
    z[4,2,4]  R1746     5.2379506826400757e-01
    z[4,2,4]  R1747     2.8799173235893250e-01
    z[4,2,4]  R1748     -1.4048458635807037e-01
    z[4,2,4]  R1749     -1.8486697971820831e-01
    z[4,2,4]  R1750     2.1070814132690430e-01
    z[4,2,4]  R1751     -2.4036785587668419e-02
    z[4,2,4]  R1752     3.0900094658136368e-02
    z[4,2,4]  R1753     1.7191524803638458e-01
    z[4,2,4]  R1754     0.0910961776971817
    z[4,2,4]  R1755     2.3283807933330536e-01
    z[4,2,4]  R1756     0.0839817002415657
    z[4,2,4]  R1757     4.7030895948410034e-02
    z[4,2,4]  R1758     2.6917797327041626e-01
    z[4,2,4]  R1759     -2.2383768856525421e-01
    z[4,2,4]  R1760     2.5361141562461853e-01
    z[4,2,4]  R1761     5.5442094802856445e-01
    z[4,2,4]  R1762     5.7248443365097046e-01
    z[4,2,4]  R1763     -0.470795214176178
    z[4,2,4]  R1764     4.7683233022689819e-01
    z[4,2,4]  R1765     4.5888155698776245e-01
    z[4,2,4]  R1766     1.3239391148090363e-01
    z[4,2,4]  R1767     2.6018369942903519e-02
    z[4,2,4]  R1768     -2.6247984170913696e-01
    z[4,2,4]  R1769     -2.6960924267768860e-01
    z[4,2,4]  R1770     2.5080201029777527e-01
    z[4,2,4]  R1771     3.7362700700759888e-01
    z[4,2,4]  R1772     -1.7409019637852907e-03
    z[4,2,4]  R1773     -2.4190691113471985e-01
    z[4,2,4]  R1774     5.1489669084548950e-01
    z[4,2,4]  R1775     -1.8420583009719849e-01
    z[4,2,4]  R1776     -1.3304264843463898e-01
    z[4,2,4]  R1777     3.0345159769058228e-01
    z[4,2,4]  R1778     4.6785643696784973e-01
    z[4,2,4]  R1779     -9.7694151103496552e-02
    z[4,2,4]  R1780     6.8273797631263733e-02
    z[4,2,4]  R1781     -2.1637508273124695e-01
    z[4,2,4]  R1782     2.2672414779663086e-01
    z[4,2,4]  R1783     -1.3508158922195435e-01
    z[4,2,4]  R1784     1.2351201474666595e-01
    z[4,2,4]  R1785     -1.2425804138183594e-01
    z[4,2,4]  R1786     -2.5327226519584656e-01
    z[4,2,4]  R1787     7.6696373522281647e-02
    z[4,2,4]  R1788     -1.3601037859916687e-01
    z[4,2,4]  R1789     2.6907208561897278e-01
    z[4,2,4]  R1790     -2.7263644337654114e-01
    z[4,2,4]  R1791     -3.4290242195129395e-01
    z[4,2,4]  R1792     -2.7971944212913513e-01
    z[4,2,4]  R1793     -0.45118448138237
    z[4,2,4]  R1794     -3.6923289299011230e-02
    z[4,2,4]  R1795     -1.7339762300252914e-02
    z[4,2,4]  R1796     -4.2922419309616089e-01
    z[4,2,4]  R1797     1.5936696529388428e-01
    z[4,2,4]  R1798     5.2261584997177124e-01
    z[4,2,4]  R1799     -1.9508515298366547e-01
    z[4,2,4]  R1800     2.5149953365325928e-01
    z[4,2,4]  R1801     -3.6170445382595062e-02
    z[4,2,4]  R1802     6.0345385223627090e-02
    z[4,2,4]  R1803     3.2775735855102539e-01
    z[4,2,4]  R1804     -1.6123975813388824e-01
    z[4,2,4]  R1805     -1.1112906038761139e-02
    z[4,2,4]  R1806     -1.7066720128059387e-01
    z[4,2,4]  R1807     -2.5070169568061829e-01
    z[4,2,4]  R1808     -1.6315679252147675e-01
    z[4,2,4]  R1809     -0.0604669563472271
    z[4,2,4]  R1810     -3.4378089010715485e-02
    z[4,2,4]  R1811     3.7657979875802994e-02
    z[4,2,4]  R1812     -1.8559253215789795e-01
    z[4,2,4]  R1813     7.3197752237319946e-02
    z[4,2,4]  R1814     2.6784452795982361e-01
    z[4,2,4]  R1815     -3.4259593486785889e-01
    z[4,2,4]  R1816     -7.1928925812244415e-02
    z[4,2,4]  R1817     -4.5762622356414795e-01
    z[4,2,4]  R1818     -1.5903252363204956e-01
    z[4,2,4]  R1819     2.1625605225563049e-01
    z[4,2,4]  R1820     1.7825832590460777e-02
    z[4,2,4]  R1821     1.1625821888446808e-01
    z[4,2,4]  R1822     -3.0601578950881958e-01
    z[4,2,4]  R1823     4.7598907351493835e-01
    z[4,2,4]  R1824     -3.3756002783775330e-01
    z[4,2,4]  R1825     2.4750913679599762e-01
    z[4,2,4]  R1826     -8.3448909223079681e-02
    z[4,2,4]  R1827     0.265316367149353
    z[4,2,4]  R1828     -9.8314777016639709e-02
    z[4,2,4]  R1829     -4.5501780509948730e-01
    z[4,2,4]  R1830     -3.0927973985671997e-01
    z[4,2,4]  R1831     -6.9239658117294312e-01
    z[4,2,4]  R1832     1.4795464277267456e-01
    z[4,2,4]  R1833     -2.1814560890197754e-01
    z[4,2,4]  R1834     -3.9844788610935211e-02
    z[4,2,4]  R1835     2.5043150782585144e-01
    z[4,2,4]  R1836     5.3612012416124344e-02
    z[4,2,4]  R1837     7.2713029384613037e-01
    z[4,2,4]  R1838     -0.322696328163147
    z[4,2,4]  R1839     -2.0935116708278656e-01
    z[4,2,4]  R1840     2.8589293360710144e-01
    z[4,2,4]  R1841     2.4938410520553589e-01
    z[4,2,4]  R1842     1.0532125830650330e-01
    z[4,2,4]  R1843     -1.1799144744873047e-01
    z[4,2,4]  R1844     -2.9631054401397705e-01
    z[4,2,4]  R1845     -2.1745118498802185e-01
    z[4,2,4]  R1846     -1.9360281527042389e-01
    z[4,2,4]  R1847     5.6955549865961075e-02
    z[4,2,4]  R1848     -2.4683679640293121e-01
    z[4,2,4]  R1849     1.5325234830379486e-01
    z[4,2,4]  R1850     -1.2517413496971130e-01
    z[4,2,4]  R1851     6.5691810846328735e-01
    z[4,2,4]  R1852     4.9956849217414856e-01
    z[4,2,4]  R1853     1.3732229173183441e-01
    z[4,2,4]  R1854     -3.8667482137680054e-01
    z[4,2,4]  R1855     -3.3884474635124207e-01
    z[4,2,4]  R1856     -1.7403274774551392e-01
    z[4,2,4]  R1857     0.289171040058136
    z[4,2,4]  R1858     0.0606367364525795
    z[4,2,4]  R1859     -4.7994937747716904e-02
    z[4,2,4]  R1860     2.9373185709118843e-02
    z[4,2,4]  R1861     2.4802295863628387e-01
    z[4,2,4]  R1862     -3.9063632488250732e-01
    z[4,2,4]  R1863     3.0453100800514221e-01
    z[4,2,4]  R1864     -3.2805752754211426e-01
    z[4,2,4]  R1865     -2.0189037919044495e-01
    z[4,2,4]  R1866     -5.9273969382047653e-03
    z[4,2,4]  R1867     3.1691977381706238e-01
    z[4,2,4]  R1868     3.9639544486999512e-01
    z[4,2,4]  R1869     -9.6043810248374939e-02
    z[4,2,4]  R1870     -5.7641044259071350e-02
    z[4,2,4]  R1871     4.5994570851325989e-01
    z[4,2,4]  R1872     -4.5340526849031448e-02
    z[4,2,4]  R1873     4.6919766813516617e-02
    z[4,2,4]  R1874     -0.274619460105896
    z[4,2,4]  R1875     4.3874431401491165e-02
    z[4,2,4]  R1876     -0.214004248380661
    z[4,2,4]  R1877     2.3286873102188110e-01
    z[4,2,4]  R1878     -1.6028711199760437e-01
    z[4,2,4]  R1879     3.3477634191513062e-01
    z[4,2,4]  R1880     1.7664463818073273e-01
    z[4,2,4]  R1881     -1.3306210935115814e-01
    z[4,2,4]  R1882     -1.6326928511261940e-02
    z[4,2,4]  R1883     -2.6743057370185852e-01
    z[4,2,4]  R1884     -8.3587124943733215e-02
    z[4,2,4]  R1885     -2.1492704749107361e-02
    z[4,2,4]  R1886     -8.7991170585155487e-02
    z[4,2,4]  R1887     2.9614555835723877e-01
    z[4,2,4]  R1888     1.3326078653335571e-01
    z[4,2,4]  R1889     1.1991009861230850e-01
    z[4,2,4]  R1890     -2.1958047151565552e-01
    z[4,2,4]  R1891     -1.2943805195391178e-02
    z[4,2,4]  R1892     2.4993417784571648e-02
    z[4,2,4]  R1893     3.1518232822418213e-01
    z[4,2,4]  R1894     2.3044927418231964e-01
    z[4,2,4]  R1895     1.8626351654529572e-01
    z[4,2,4]  R1896     7.2187192738056183e-02
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1673     -1
    z[4,2,5]  R1674     1
    z[4,2,5]  R1677     -0.567290186882019
    z[4,2,5]  R1678     -4.7096580266952515e-01
    z[4,2,5]  R1679     -2.8467962145805359e-01
    z[4,2,5]  R1680     -4.5613187551498413e-01
    z[4,2,5]  R1681     -3.7316355109214783e-01
    z[4,2,5]  R1682     -4.9113425612449646e-01
    z[4,2,5]  R1683     -2.2501760721206665e-01
    z[4,2,5]  R1684     -4.5422890782356262e-01
    z[4,2,5]  R1685     -1.9683602452278137e-01
    z[4,2,5]  R1686     -7.4810914695262909e-02
    z[4,2,5]  R1687     5.5614137649536133e-01
    z[4,2,5]  R1688     4.6744874119758606e-01
    z[4,2,5]  R1689     3.0523526668548584e-01
    z[4,2,5]  R1690     -4.0307754278182983e-01
    z[4,2,5]  R1691     6.4861392602324486e-03
    z[4,2,5]  R1692     -3.5454906523227692e-02
    z[4,2,5]  R1693     1.2842306494712830e-01
    z[4,2,5]  R1694     1.4541678130626678e-01
    z[4,2,5]  R1695     1.6680285334587097e-01
    z[4,2,5]  R1696     8.6275503039360046e-02
    z[4,2,5]  R1697     -8.8976975530385971e-03
    z[4,2,5]  R1698     4.5235604047775269e-01
    z[4,2,5]  R1699     3.6717417836189270e-01
    z[4,2,5]  R1700     -6.2057387083768845e-02
    z[4,2,5]  R1701     1.4026379585266113e-01
    z[4,2,5]  R1702     -8.7293386459350586e-02
    z[4,2,5]  R1703     2.5280052423477173e-01
    z[4,2,5]  R1704     1.5615834295749664e-01
    z[4,2,5]  R1705     -1.2509214878082275e-01
    z[4,2,5]  R1706     2.4431882798671722e-01
    z[4,2,5]  R1707     3.5856953263282776e-01
    z[4,2,5]  R1708     5.8395403623580933e-01
    z[4,2,5]  R1709     2.4112163484096527e-01
    z[4,2,5]  R1710     2.9454326629638672e-01
    z[4,2,5]  R1711     3.1561228632926941e-01
    z[4,2,5]  R1712     -1.8078792095184326e-01
    z[4,2,5]  R1713     -2.5250095129013062e-01
    z[4,2,5]  R1714     1.8632566928863525e-01
    z[4,2,5]  R1715     -4.3672680854797363e-01
    z[4,2,5]  R1716     -8.9058600366115570e-02
    z[4,2,5]  R1717     4.4784566760063171e-01
    z[4,2,5]  R1718     0.425496906042099
    z[4,2,5]  R1719     3.2415258884429932e-01
    z[4,2,5]  R1720     -1.6619232296943665e-01
    z[4,2,5]  R1721     -2.3024032998364419e-04
    z[4,2,5]  R1722     -2.1188246086239815e-02
    z[4,2,5]  R1723     -4.2546260356903076e-01
    z[4,2,5]  R1724     -3.7626194953918457e-01
    z[4,2,5]  R1725     -1.1377550661563873e-02
    z[4,2,5]  R1726     -1.3964809477329254e-01
    z[4,2,5]  R1727     4.3637013435363770e-01
    z[4,2,5]  R1728     5.8601337671279907e-01
    z[4,2,5]  R1729     1.8636810779571533e-01
    z[4,2,5]  R1730     2.5316748023033142e-01
    z[4,2,5]  R1731     1.7170919477939606e-01
    z[4,2,5]  R1732     3.3964416384696960e-01
    z[4,2,5]  R1733     -2.2880868613719940e-01
    z[4,2,5]  R1734     -3.0514645576477051e-01
    z[4,2,5]  R1735     -3.9614114910364151e-02
    z[4,2,5]  R1736     -1.1986841447651386e-02
    z[4,2,5]  R1737     -1.8737922608852386e-01
    z[4,2,5]  R1738     2.9761362075805664e-01
    z[4,2,5]  R1739     -1.4091113209724426e-01
    z[4,2,5]  R1740     -2.1088285744190216e-01
    z[4,2,5]  R1741     -1.4867080748081207e-01
    z[4,2,5]  R1742     -1.5140730142593384e-01
    z[4,2,5]  R1743     7.3399171233177185e-02
    z[4,2,5]  R1744     -1.3731801509857178e-01
    z[4,2,5]  R1745     -2.1077500283718109e-01
    z[4,2,5]  R1746     -4.1861617565155029e-01
    z[4,2,5]  R1747     1.5950110554695129e-01
    z[4,2,5]  R1748     3.1426626443862915e-01
    z[4,2,5]  R1749     6.6431082785129547e-02
    z[4,2,5]  R1750     4.6235236525535583e-01
    z[4,2,5]  R1751     -1.1576903052628040e-02
    z[4,2,5]  R1752     -7.8274980187416077e-02
    z[4,2,5]  R1753     -3.7693977355957031e-01
    z[4,2,5]  R1754     4.1850835084915161e-02
    z[4,2,5]  R1755     6.0755524784326553e-02
    z[4,2,5]  R1756     -1.1820632964372635e-02
    z[4,2,5]  R1757     5.8419197797775269e-02
    z[4,2,5]  R1758     -4.5930200815200806e-01
    z[4,2,5]  R1759     1.8721137195825577e-02
    z[4,2,5]  R1760     -4.5784667134284973e-01
    z[4,2,5]  R1761     -1.4388071000576019e-01
    z[4,2,5]  R1762     0.082222118973732
    z[4,2,5]  R1763     1.2622365355491638e-01
    z[4,2,5]  R1764     -2.6503092050552368e-01
    z[4,2,5]  R1765     -3.6509260535240173e-01
    z[4,2,5]  R1766     -1.9301755726337433e-01
    z[4,2,5]  R1767     2.3834304511547089e-01
    z[4,2,5]  R1768     3.6902558803558350e-01
    z[4,2,5]  R1769     3.8425880670547485e-01
    z[4,2,5]  R1770     -4.2244362831115723e-01
    z[4,2,5]  R1771     2.0742814987897873e-02
    z[4,2,5]  R1772     0.0847427025437355
    z[4,2,5]  R1773     1.6116046905517578e-01
    z[4,2,5]  R1774     -3.4456923604011536e-01
    z[4,2,5]  R1775     -5.1498931646347046e-01
    z[4,2,5]  R1776     -2.9532846808433533e-01
    z[4,2,5]  R1777     -3.2721281051635742e-01
    z[4,2,5]  R1778     -5.4802145808935165e-02
    z[4,2,5]  R1779     2.5784159079194069e-02
    z[4,2,5]  R1780     -3.3183619379997253e-01
    z[4,2,5]  R1781     -9.4814337790012360e-02
    z[4,2,5]  R1782     -3.2409057021141052e-01
    z[4,2,5]  R1783     -3.0177587270736694e-01
    z[4,2,5]  R1784     -3.4313338994979858e-01
    z[4,2,5]  R1785     -2.3594951629638672e-01
    z[4,2,5]  R1786     -3.2928720116615295e-01
    z[4,2,5]  R1787     -4.0913251042366028e-01
    z[4,2,5]  R1788     -1.9938772916793823e-01
    z[4,2,5]  R1789     -2.4501414597034454e-01
    z[4,2,5]  R1790     -2.0833808183670044e-01
    z[4,2,5]  R1791     -1.5545871853828430e-01
    z[4,2,5]  R1792     -1.2104744091629982e-02
    z[4,2,5]  R1793     -2.4415870010852814e-01
    z[4,2,5]  R1794     1.5470339357852936e-01
    z[4,2,5]  R1795     -1.3708001375198364e-01
    z[4,2,5]  R1796     -4.8285737633705139e-01
    z[4,2,5]  R1797     1.7897954583168030e-01
    z[4,2,5]  R1798     4.1876620054244995e-01
    z[4,2,5]  R1799     6.2775970436632633e-03
    z[4,2,5]  R1800     -1.4662048220634460e-01
    z[4,2,5]  R1801     1.0123351216316223e-01
    z[4,2,5]  R1802     4.1432702541351318e-01
    z[4,2,5]  R1803     2.8929945826530457e-01
    z[4,2,5]  R1804     -1.0790634900331497e-01
    z[4,2,5]  R1805     1.8880537152290344e-01
    z[4,2,5]  R1806     4.1776046156883240e-01
    z[4,2,5]  R1807     -4.5226030051708221e-02
    z[4,2,5]  R1808     -2.3367213085293770e-02
    z[4,2,5]  R1809     6.7532330751419067e-02
    z[4,2,5]  R1810     -1.6712664067745209e-01
    z[4,2,5]  R1811     -9.5498561859130859e-02
    z[4,2,5]  R1812     3.7924793362617493e-01
    z[4,2,5]  R1813     -5.3726937621831894e-02
    z[4,2,5]  R1814     4.1719831526279449e-02
    z[4,2,5]  R1815     1.7668071389198303e-01
    z[4,2,5]  R1816     -1.0164061188697815e-01
    z[4,2,5]  R1817     4.5092034339904785e-01
    z[4,2,5]  R1818     -8.1328481435775757e-02
    z[4,2,5]  R1819     -5.1702845096588135e-01
    z[4,2,5]  R1820     4.0486997365951538e-01
    z[4,2,5]  R1821     1.6480258107185364e-01
    z[4,2,5]  R1822     0.627466082572937
    z[4,2,5]  R1823     0.29982790350914
    z[4,2,5]  R1824     -2.3215073347091675e-01
    z[4,2,5]  R1825     1.1857450753450394e-01
    z[4,2,5]  R1826     -1.3388405740261078e-01
    z[4,2,5]  R1827     -7.0382517576217651e-01
    z[4,2,5]  R1828     1.1174259334802628e-01
    z[4,2,5]  R1829     2.1935574710369110e-01
    z[4,2,5]  R1830     -1.0182154178619385e-01
    z[4,2,5]  R1831     3.2961988449096680e-01
    z[4,2,5]  R1832     -2.5022733211517334e-01
    z[4,2,5]  R1833     1.4056839980185032e-02
    z[4,2,5]  R1834     -5.8268398046493530e-01
    z[4,2,5]  R1835     -2.6642149686813354e-01
    z[4,2,5]  R1836     -6.7784243822097778e-01
    z[4,2,5]  R1837     7.2239354252815247e-02
    z[4,2,5]  R1838     -8.8432334363460541e-02
    z[4,2,5]  R1839     5.2897727489471436e-01
    z[4,2,5]  R1840     2.8498110175132751e-01
    z[4,2,5]  R1841     -2.2599442303180695e-01
    z[4,2,5]  R1842     5.6194867938756943e-02
    z[4,2,5]  R1843     3.1944376230239868e-01
    z[4,2,5]  R1844     -4.6117216348648071e-01
    z[4,2,5]  R1845     2.5276523828506470e-01
    z[4,2,5]  R1846     -6.7564010620117188e-01
    z[4,2,5]  R1847     2.1172720938920975e-02
    z[4,2,5]  R1848     -4.0027502179145813e-01
    z[4,2,5]  R1849     -1.6390261054039001e-01
    z[4,2,5]  R1850     1.1652058362960815e-01
    z[4,2,5]  R1851     -1.5202715992927551e-01
    z[4,2,5]  R1852     -1.8972858786582947e-01
    z[4,2,5]  R1853     -4.7291836142539978e-01
    z[4,2,5]  R1854     -2.6897612214088440e-01
    z[4,2,5]  R1855     -2.3124687373638153e-01
    z[4,2,5]  R1856     -2.3645384609699249e-01
    z[4,2,5]  R1857     -3.5391256213188171e-02
    z[4,2,5]  R1858     2.5909817218780518e-01
    z[4,2,5]  R1859     -0.613033652305603
    z[4,2,5]  R1860     -2.3402197659015656e-01
    z[4,2,5]  R1861     -0.316095769405365
    z[4,2,5]  R1862     3.4054023027420044e-01
    z[4,2,5]  R1863     2.4003812670707703e-01
    z[4,2,5]  R1864     1.8813515082001686e-02
    z[4,2,5]  R1865     -3.4905764460563660e-01
    z[4,2,5]  R1866     -4.9916657805442810e-01
    z[4,2,5]  R1867     3.1575998663902283e-01
    z[4,2,5]  R1868     3.7309196591377258e-01
    z[4,2,5]  R1869     7.0639267563819885e-02
    z[4,2,5]  R1870     2.4038922786712646e-01
    z[4,2,5]  R1871     4.4128566980361938e-02
    z[4,2,5]  R1872     -2.6686057448387146e-01
    z[4,2,5]  R1873     -5.0679403543472290e-01
    z[4,2,5]  R1874     -1.3757790625095367e-01
    z[4,2,5]  R1875     -3.3155736327171326e-01
    z[4,2,5]  R1876     1.9013158977031708e-01
    z[4,2,5]  R1877     2.9067987203598022e-01
    z[4,2,5]  R1878     -2.9712867736816406e-01
    z[4,2,5]  R1879     -9.7113199532032013e-02
    z[4,2,5]  R1880     -4.4012613594532013e-02
    z[4,2,5]  R1881     2.5967252254486084e-01
    z[4,2,5]  R1882     -2.6901009678840637e-01
    z[4,2,5]  R1883     2.6603478193283081e-01
    z[4,2,5]  R1884     3.7837705016136169e-01
    z[4,2,5]  R1885     4.4696322083473206e-01
    z[4,2,5]  R1886     3.3983856439590454e-01
    z[4,2,5]  R1887     -1.0552906990051270e-01
    z[4,2,5]  R1888     2.3850056529045105e-01
    z[4,2,5]  R1889     -0.34966841340065
    z[4,2,5]  R1890     3.8474443554878235e-01
    z[4,2,5]  R1891     7.0009604096412659e-02
    z[4,2,5]  R1892     -1.1616861820220947e-01
    z[4,2,5]  R1893     -7.8402034938335419e-02
    z[4,2,5]  R1894     -3.5456646233797073e-02
    z[4,2,5]  R1895     4.7586232423782349e-01
    z[4,2,5]  R1896     0.0745057761669159
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1675     -1
    z[4,2,6]  R1676     1
    z[4,2,6]  R1677     -1.1409967392683029e-01
    z[4,2,6]  R1678     1.8631061911582947e-01
    z[4,2,6]  R1679     1.5505558252334595e-01
    z[4,2,6]  R1680     -9.4230905175209045e-02
    z[4,2,6]  R1681     8.8811673223972321e-02
    z[4,2,6]  R1682     -5.4144892841577530e-02
    z[4,2,6]  R1683     -3.6406937241554260e-01
    z[4,2,6]  R1684     2.2296257317066193e-01
    z[4,2,6]  R1685     -4.3690085411071777e-01
    z[4,2,6]  R1686     -0.284881055355072
    z[4,2,6]  R1687     2.3958197236061096e-01
    z[4,2,6]  R1688     -2.3904012143611908e-01
    z[4,2,6]  R1689     -1.1963321268558502e-01
    z[4,2,6]  R1690     -4.6805106103420258e-02
    z[4,2,6]  R1691     -1.7740327119827271e-01
    z[4,2,6]  R1692     3.9852154254913330e-01
    z[4,2,6]  R1693     -1.7968656122684479e-01
    z[4,2,6]  R1694     -5.7249772548675537e-01
    z[4,2,6]  R1695     -6.5263003110885620e-01
    z[4,2,6]  R1696     -2.8091764450073242e-01
    z[4,2,6]  R1697     1.6536907851696014e-01
    z[4,2,6]  R1698     -3.8747996091842651e-01
    z[4,2,6]  R1699     -3.6879444122314453e-01
    z[4,2,6]  R1700     7.8969156742095947e-01
    z[4,2,6]  R1701     -2.0165938138961792e-01
    z[4,2,6]  R1702     -1.3785080611705780e-01
    z[4,2,6]  R1703     0.332021564245224
    z[4,2,6]  R1704     8.9740976691246033e-02
    z[4,2,6]  R1705     -1.3271878659725189e-01
    z[4,2,6]  R1706     2.6851412653923035e-01
    z[4,2,6]  R1707     -4.4646671414375305e-01
    z[4,2,6]  R1708     3.5155513882637024e-01
    z[4,2,6]  R1709     9.7187506034970284e-03
    z[4,2,6]  R1710     -3.9079171419143677e-01
    z[4,2,6]  R1711     -1.6757705807685852e-01
    z[4,2,6]  R1712     -2.3581512272357941e-02
    z[4,2,6]  R1713     4.8792776465415955e-01
    z[4,2,6]  R1714     5.0658807158470154e-02
    z[4,2,6]  R1715     4.8480924963951111e-01
    z[4,2,6]  R1716     -2.5699833035469055e-01
    z[4,2,6]  R1717     6.6792696714401245e-02
    z[4,2,6]  R1718     2.0928496122360229e-01
    z[4,2,6]  R1719     -6.2918695621192455e-03
    z[4,2,6]  R1720     0.377238005399704
    z[4,2,6]  R1721     3.1086388230323792e-01
    z[4,2,6]  R1722     -1.9821390509605408e-01
    z[4,2,6]  R1723     -1.8849206389859319e-03
    z[4,2,6]  R1724     5.9384290128946304e-02
    z[4,2,6]  R1725     -9.6629941835999489e-03
    z[4,2,6]  R1726     1.4050062000751495e-01
    z[4,2,6]  R1727     -2.0856364071369171e-01
    z[4,2,6]  R1728     1.5194277465343475e-01
    z[4,2,6]  R1729     1.9492205977439880e-01
    z[4,2,6]  R1730     -3.1650376319885254e-01
    z[4,2,6]  R1731     -2.8207591176033020e-01
    z[4,2,6]  R1732     -2.5937798619270325e-01
    z[4,2,6]  R1733     -2.2709725797176361e-01
    z[4,2,6]  R1734     -1.5670976042747498e-01
    z[4,2,6]  R1735     -1.8955725431442261e-01
    z[4,2,6]  R1736     -1.1056371033191681e-01
    z[4,2,6]  R1737     1.5578483045101166e-01
    z[4,2,6]  R1738     -3.3971226215362549e-01
    z[4,2,6]  R1739     2.9629576206207275e-01
    z[4,2,6]  R1740     -1.7692670226097107e-01
    z[4,2,6]  R1741     1.2157399207353592e-01
    z[4,2,6]  R1742     -8.9330114424228668e-02
    z[4,2,6]  R1743     -1.0918104648590088e-01
    z[4,2,6]  R1744     2.1212534606456757e-01
    z[4,2,6]  R1745     -0.00732843903824687
    z[4,2,6]  R1746     -1.8028123676776886e-01
    z[4,2,6]  R1747     5.8017671108245850e-01
    z[4,2,6]  R1748     1.7972312867641449e-02
    z[4,2,6]  R1749     -4.0665301680564880e-01
    z[4,2,6]  R1750     1.0987018793821335e-01
    z[4,2,6]  R1751     6.1497384309768677e-01
    z[4,2,6]  R1752     -3.0301022529602051e-01
    z[4,2,6]  R1753     2.1675251424312592e-02
    z[4,2,6]  R1754     8.7226778268814087e-02
    z[4,2,6]  R1755     2.8561198711395264e-01
    z[4,2,6]  R1756     4.3371358513832092e-01
    z[4,2,6]  R1757     1.3211207091808319e-01
    z[4,2,6]  R1758     -4.1308730840682983e-01
    z[4,2,6]  R1759     -1.3268908485770226e-02
    z[4,2,6]  R1760     -9.4475768506526947e-02
    z[4,2,6]  R1761     1.4035947620868683e-01
    z[4,2,6]  R1762     1.2068077921867371e-01
    z[4,2,6]  R1763     2.5822622701525688e-02
    z[4,2,6]  R1764     3.6570936441421509e-01
    z[4,2,6]  R1765     4.2769372463226318e-01
    z[4,2,6]  R1766     -8.2987926900386810e-02
    z[4,2,6]  R1767     -2.1248523890972137e-01
    z[4,2,6]  R1768     4.3469882011413574e-01
    z[4,2,6]  R1769     2.6805743575096130e-01
    z[4,2,6]  R1770     -1.0324721783399582e-01
    z[4,2,6]  R1771     2.3308119177818298e-01
    z[4,2,6]  R1772     -1.6491647064685822e-01
    z[4,2,6]  R1773     -1.6455566883087158e-01
    z[4,2,6]  R1774     -6.8455703556537628e-02
    z[4,2,6]  R1775     -2.2133512794971466e-01
    z[4,2,6]  R1776     -9.1432582121342421e-04
    z[4,2,6]  R1777     -0.0773564875125885
    z[4,2,6]  R1778     1.6218551993370056e-01
    z[4,2,6]  R1779     -9.9893517792224884e-02
    z[4,2,6]  R1780     -1.7724396288394928e-01
    z[4,2,6]  R1781     3.0140149593353271e-01
    z[4,2,6]  R1782     5.6753152608871460e-01
    z[4,2,6]  R1783     -1.5236841142177582e-01
    z[4,2,6]  R1784     4.0906123816967010e-02
    z[4,2,6]  R1785     -3.5598453134298325e-02
    z[4,2,6]  R1786     1.6011761128902435e-01
    z[4,2,6]  R1787     -1.6492843627929688e-01
    z[4,2,6]  R1788     -9.3961074948310852e-02
    z[4,2,6]  R1789     -3.5728029906749725e-02
    z[4,2,6]  R1790     -3.2833582162857056e-01
    z[4,2,6]  R1791     3.2686257362365723e-01
    z[4,2,6]  R1792     -1.4039170928299427e-02
    z[4,2,6]  R1793     1.2344378232955933e-01
    z[4,2,6]  R1794     -2.3563358187675476e-01
    z[4,2,6]  R1795     3.1386756896972656e-01
    z[4,2,6]  R1796     1.3855537772178650e-01
    z[4,2,6]  R1797     1.1553360521793365e-01
    z[4,2,6]  R1798     -1.8122033774852753e-01
    z[4,2,6]  R1799     -3.7590980529785156e-01
    z[4,2,6]  R1800     0.141273632645607
    z[4,2,6]  R1801     3.6761730909347534e-01
    z[4,2,6]  R1802     2.5172346830368042e-01
    z[4,2,6]  R1803     2.3954164981842041e-01
    z[4,2,6]  R1804     -3.3420255780220032e-01
    z[4,2,6]  R1805     -6.5239536762237549e-01
    z[4,2,6]  R1806     -4.3621074408292770e-02
    z[4,2,6]  R1807     -0.0518658272922039
    z[4,2,6]  R1808     8.8990144431591034e-03
    z[4,2,6]  R1809     1.0470316559076309e-01
    z[4,2,6]  R1810     1.0767577588558197e-01
    z[4,2,6]  R1811     -1.1672386527061462e-01
    z[4,2,6]  R1812     -1.2187291681766510e-01
    z[4,2,6]  R1813     2.5548562407493591e-02
    z[4,2,6]  R1814     0.0900566577911377
    z[4,2,6]  R1815     2.5914067402482033e-02
    z[4,2,6]  R1816     6.8382412195205688e-02
    z[4,2,6]  R1817     -8.4528736770153046e-02
    z[4,2,6]  R1818     -7.3306798934936523e-01
    z[4,2,6]  R1819     1.1163865774869919e-01
    z[4,2,6]  R1820     -1.9604042172431946e-02
    z[4,2,6]  R1821     -1.7284965515136719e-01
    z[4,2,6]  R1822     3.2818809151649475e-01
    z[4,2,6]  R1823     1.7801612615585327e-01
    z[4,2,6]  R1824     -1.3617551326751709e-01
    z[4,2,6]  R1825     -7.8074358403682709e-02
    z[4,2,6]  R1826     1.5174004435539246e-01
    z[4,2,6]  R1827     -0.193263441324234
    z[4,2,6]  R1828     -4.1548219323158264e-01
    z[4,2,6]  R1829     -2.0349536836147308e-01
    z[4,2,6]  R1830     4.5186790823936462e-01
    z[4,2,6]  R1831     -4.7979336231946945e-02
    z[4,2,6]  R1832     -2.2587533295154572e-01
    z[4,2,6]  R1833     -1.1849322170019150e-01
    z[4,2,6]  R1834     -8.2743220031261444e-02
    z[4,2,6]  R1835     -6.2936772592365742e-03
    z[4,2,6]  R1836     2.7090808749198914e-01
    z[4,2,6]  R1837     3.1304123997688293e-01
    z[4,2,6]  R1838     3.9663332700729370e-01
    z[4,2,6]  R1839     -1.3253666460514069e-01
    z[4,2,6]  R1840     -1.0549268918111920e-03
    z[4,2,6]  R1841     1.8261510878801346e-02
    z[4,2,6]  R1842     4.6634960174560547e-01
    z[4,2,6]  R1843     -2.5481829047203064e-01
    z[4,2,6]  R1844     1.9056017696857452e-01
    z[4,2,6]  R1845     4.2305365204811096e-01
    z[4,2,6]  R1846     -1.1774463579058647e-02
    z[4,2,6]  R1847     0.476979523897171
    z[4,2,6]  R1848     0.0441533662378788
    z[4,2,6]  R1849     4.3637722730636597e-01
    z[4,2,6]  R1850     -2.2750008106231689e-01
    z[4,2,6]  R1851     -5.1425302028656006e-01
    z[4,2,6]  R1852     -6.6892087459564209e-02
    z[4,2,6]  R1853     2.8757461905479431e-01
    z[4,2,6]  R1854     1.8163864314556122e-01
    z[4,2,6]  R1855     4.4809184968471527e-02
    z[4,2,6]  R1856     2.0869192481040955e-01
    z[4,2,6]  R1857     3.1698805093765259e-01
    z[4,2,6]  R1858     -3.1791147589683533e-01
    z[4,2,6]  R1859     -0.0218859501183033
    z[4,2,6]  R1860     3.3259138464927673e-01
    z[4,2,6]  R1861     -4.8471871018409729e-01
    z[4,2,6]  R1862     7.3627866804599762e-02
    z[4,2,6]  R1863     -0.210836723446846
    z[4,2,6]  R1864     -3.1659367680549622e-01
    z[4,2,6]  R1865     -1.3049063086509705e-01
    z[4,2,6]  R1866     -1.8533644080162048e-01
    z[4,2,6]  R1867     3.8289141654968262e-01
    z[4,2,6]  R1868     -2.6891345158219337e-02
    z[4,2,6]  R1869     1.3080124557018280e-01
    z[4,2,6]  R1870     -3.0868074297904968e-01
    z[4,2,6]  R1871     -4.4748479127883911e-01
    z[4,2,6]  R1872     9.9589407444000244e-02
    z[4,2,6]  R1873     -1.4063747227191925e-01
    z[4,2,6]  R1874     -0.0908326730132103
    z[4,2,6]  R1875     4.3805864453315735e-01
    z[4,2,6]  R1876     1.9548374414443970e-01
    z[4,2,6]  R1877     -1.3465739786624908e-01
    z[4,2,6]  R1878     -4.7352391481399536e-01
    z[4,2,6]  R1879     -4.0334376692771912e-01
    z[4,2,6]  R1880     -3.4171923995018005e-01
    z[4,2,6]  R1881     -0.0457824245095253
    z[4,2,6]  R1882     3.7002786993980408e-01
    z[4,2,6]  R1883     3.3452188968658447e-01
    z[4,2,6]  R1884     3.8959000259637833e-02
    z[4,2,6]  R1885     1.4366483688354492e-01
    z[4,2,6]  R1886     1.4029106497764587e-01
    z[4,2,6]  R1887     -1.8921458721160889e-01
    z[4,2,6]  R1888     -2.7679666876792908e-01
    z[4,2,6]  R1889     3.0307358503341675e-01
    z[4,2,6]  R1890     3.1549820303916931e-01
    z[4,2,6]  R1891     1.6601040959358215e-01
    z[4,2,6]  R1892     1.3481980189681053e-02
    z[4,2,6]  R1893     2.0826151967048645e-01
    z[4,2,6]  R1894     3.7093237042427063e-01
    z[4,2,6]  R1895     -7.5687073171138763e-02
    z[4,2,6]  R1896     -0.344025194644928
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2021     -1
    z[3,4,0]  R2022     1
    z[3,4,0]  R2035     2.7983114123344421e-01
    z[3,4,0]  R2036     4.5460104942321777e-01
    z[3,4,0]  R2037     5.2850371599197388e-01
    z[3,4,0]  R2038     7.4628823995590210e-01
    z[3,4,0]  R2039     6.7978280782699585e-01
    z[3,4,0]  R2040     5.0720679759979248e-01
    z[3,4,0]  R2041     -1.7386375367641449e-01
    z[3,4,0]  R2042     6.3635128736495972e-01
    z[3,4,0]  R2043     1.9838495645672083e-03
    z[3,4,0]  R2044     4.3724125623703003e-01
    z[3,4,0]  R2045     1.0943809896707535e-01
    z[3,4,0]  R2046     7.2360396385192871e-01
    z[3,4,0]  R2047     -0.41497603058815
    z[3,4,0]  R2048     -0.360065221786499
    z[3,4,0]  R2049     -4.2180991172790527e-01
    z[3,4,0]  R2050     -4.8004138469696045e-01
    z[3,4,0]  R2051     -4.3477049469947815e-01
    z[3,4,0]  R2052     -0.6156005859375
    z[3,4,0]  R2053     -3.2301768660545349e-01
    z[3,4,0]  R2054     -3.7379533052444458e-01
    z[3,4,0]  R2055     -5.8755654096603394e-01
    z[3,4,0]  R2056     -0.550112783908844
    z[3,4,0]  R2057     -5.7592475414276123e-01
    z[3,4,0]  R2058     -6.1626744270324707e-01
    z[3,4,0]  R2059     -5.3182321786880493e-01
    z[3,4,0]  R2060     -6.7129796743392944e-01
    z[3,4,0]  R2061     -6.7024582624435425e-01
    z[3,4,0]  R2062     -5.8671534061431885e-01
    z[3,4,0]  R2063     -6.3573414087295532e-01
    z[3,4,0]  R2064     -7.6984459161758423e-01
    z[3,4,0]  R2065     2.2927865386009216e-01
    z[3,4,0]  R2066     6.8313342332839966e-01
    z[3,4,0]  R2067     7.1734535694122314e-01
    z[3,4,0]  R2068     -3.7486594915390015e-01
    z[3,4,0]  R2069     4.1173495352268219e-02
    z[3,4,0]  R2070     2.9657664895057678e-01
    z[3,4,0]  R2071     1.4933685958385468e-01
    z[3,4,0]  R2072     4.7259172797203064e-01
    z[3,4,0]  R2073     5.5157589912414551e-01
    z[3,4,0]  R2074     4.6082824468612671e-01
    z[3,4,0]  R2075     -1.1115819215774536e-01
    z[3,4,0]  R2076     -1.2880751863121986e-02
    z[3,4,0]  R2077     5.5273931473493576e-02
    z[3,4,0]  R2078     1.4118523895740509e-01
    z[3,4,0]  R2079     6.4345401525497437e-01
    z[3,4,0]  R2080     0.0411706306040287
    z[3,4,0]  R2081     2.1051850169897079e-02
    z[3,4,0]  R2082     3.9216777682304382e-01
    z[3,4,0]  R2083     3.2847228646278381e-01
    z[3,4,0]  R2084     -0.0661325603723526
    z[3,4,0]  R2085     1.6047385288402438e-03
    z[3,4,0]  R2086     1.1611460894346237e-01
    z[3,4,0]  R2087     2.0121926069259644e-01
    z[3,4,0]  R2088     -2.7605935931205750e-01
    z[3,4,0]  R2089     5.7087254524230957e-01
    z[3,4,0]  R2090     0.534482479095459
    z[3,4,0]  R2091     5.3874176740646362e-01
    z[3,4,0]  R2092     6.4456933736801147e-01
    z[3,4,0]  R2093     -2.6294299960136414e-01
    z[3,4,0]  R2094     1.6433918476104736e-01
    z[3,4,0]  R2095     9.2788405716419220e-02
    z[3,4,0]  R2096     8.6532514542341232e-03
    z[3,4,0]  R2097     -5.0115205347537994e-02
    z[3,4,0]  R2098     8.6147910356521606e-01
    z[3,4,0]  R2099     4.8253032565116882e-01
    z[3,4,0]  R2100     7.4361699819564819e-01
    z[3,4,0]  R2101     7.0720338821411133e-01
    z[3,4,0]  R2102     1.0208169370889664e-01
    z[3,4,0]  R2103     1.2148441374301910e-01
    z[3,4,0]  R2104     -1.1865770816802979e-01
    z[3,4,0]  R2105     -1.4550159871578217e-01
    z[3,4,0]  R2106     -3.6517471075057983e-02
    z[3,4,0]  R2107     -2.0804883539676666e-01
    z[3,4,0]  R2108     3.9359282702207565e-02
    z[3,4,0]  R2109     6.9649285078048706e-01
    z[3,4,0]  R2110     7.3793154954910278e-01
    z[3,4,0]  R2111     6.9981509447097778e-01
    z[3,4,0]  R2112     8.4909921884536743e-01
    z[3,4,0]  R2113     2.7244171500205994e-01
    z[3,4,0]  R2114     0.168548122048378
    z[3,4,0]  R2115     6.9429796934127808e-01
    z[3,4,0]  R2116     6.7381465435028076e-01
    z[3,4,0]  R2117     7.3634153604507446e-01
    z[3,4,0]  R2118     6.1560302972793579e-01
    z[3,4,0]  R2119     2.6052442193031311e-01
    z[3,4,0]  R2120     -1.2880542874336243e-01
    z[3,4,0]  R2121     -1.2372874468564987e-01
    z[3,4,0]  R2122     2.1286159753799438e-01
    z[3,4,0]  R2123     5.8649146556854248e-01
    z[3,4,0]  R2124     -1.5846298635005951e-01
    z[3,4,0]  R2125     -8.1728391349315643e-02
    z[3,4,0]  R2126     6.9623565673828125e-01
    z[3,4,0]  R2127     7.5372809171676636e-01
    z[3,4,0]  R2128     6.9946563243865967e-01
    z[3,4,0]  R2129     6.5266388654708862e-01
    z[3,4,0]  R2130     8.8066416978836060e-01
    z[3,4,0]  R2131     0.0986173152923584
    z[3,4,0]  R2132     -0.0824391320347786
    z[3,4,0]  R2133     1.0335975885391235e-01
    z[3,4,0]  R2134     -1.2979520484805107e-02
    z[3,4,0]  R2135     -0.0978812426328659
    z[3,4,0]  R2136     -4.1288039088249207e-01
    z[3,4,0]  R2137     -4.5653238892555237e-01
    z[3,4,0]  R2138     6.8289393186569214e-01
    z[3,4,0]  R2139     2.8496208786964417e-01
    z[3,4,0]  R2140     -1.0464946739375591e-02
    z[3,4,0]  R2141     1.7132751643657684e-01
    z[3,4,0]  R2142     -2.8915578126907349e-01
    z[3,4,0]  R2143     -2.0504486560821533e-01
    z[3,4,0]  R2144     3.2287436723709106e-01
    z[3,4,0]  R2145     0.789137065410614
    z[3,4,0]  R2146     7.2498601675033569e-01
    z[3,4,0]  R2147     7.4532598257064819e-01
    z[3,4,0]  R2148     7.3198574781417847e-01
    z[3,4,0]  R2149     -9.2089831829071045e-02
    z[3,4,0]  R2150     -7.7427178621292114e-02
    z[3,4,0]  R2151     1.8897749483585358e-01
    z[3,4,0]  R2152     4.4966783374547958e-02
    z[3,4,0]  R2153     4.8142012953758240e-01
    z[3,4,0]  R2154     6.7377209663391113e-01
    z[3,4,0]  R2155     7.4083232879638672e-01
    z[3,4,0]  R2156     5.7815268635749817e-02
    z[3,4,0]  R2157     2.0731888711452484e-01
    z[3,4,0]  R2158     1.8512832000851631e-02
    z[3,4,0]  R2159     3.2425409555435181e-01
    z[3,4,0]  R2160     2.0348079502582550e-01
    z[3,4,0]  R2161     5.5700516700744629e-01
    z[3,4,0]  R2162     4.3710514903068542e-01
    z[3,4,0]  R2163     5.9524399042129517e-01
    z[3,4,0]  R2164     4.2955505847930908e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2023     -1
    z[3,4,1]  R2024     1
    z[3,4,1]  R2035     0.505213737487793
    z[3,4,1]  R2036     -2.9188922047615051e-01
    z[3,4,1]  R2037     -2.7200677990913391e-01
    z[3,4,1]  R2038     -3.0819791555404663e-01
    z[3,4,1]  R2039     -4.9865084886550903e-01
    z[3,4,1]  R2040     -2.9265290498733521e-01
    z[3,4,1]  R2041     0.80692058801651
    z[3,4,1]  R2042     -5.2047246694564819e-01
    z[3,4,1]  R2043     1.3496515154838562e-01
    z[3,4,1]  R2044     -6.9121068716049194e-01
    z[3,4,1]  R2045     0.0921378806233406
    z[3,4,1]  R2046     2.1200199425220490e-01
    z[3,4,1]  R2047     -5.6763851642608643e-01
    z[3,4,1]  R2048     -8.2999789714813232e-01
    z[3,4,1]  R2049     -7.0515358448028564e-01
    z[3,4,1]  R2050     -4.0988948941230774e-01
    z[3,4,1]  R2051     -4.6646991372108459e-01
    z[3,4,1]  R2052     1.9349502027034760e-01
    z[3,4,1]  R2053     4.7425529360771179e-01
    z[3,4,1]  R2054     2.0977059006690979e-01
    z[3,4,1]  R2055     -3.5023787617683411e-01
    z[3,4,1]  R2056     -2.5114196538925171e-01
    z[3,4,1]  R2057     -3.5928779840469360e-01
    z[3,4,1]  R2058     -2.9726028442382812e-01
    z[3,4,1]  R2059     -5.5615627765655518e-01
    z[3,4,1]  R2060     -5.1980084180831909e-01
    z[3,4,1]  R2061     -4.0141481161117554e-01
    z[3,4,1]  R2062     -2.5546005368232727e-01
    z[3,4,1]  R2063     -0.32403364777565
    z[3,4,1]  R2064     -2.9785001277923584e-01
    z[3,4,1]  R2065     -7.1147876977920532e-01
    z[3,4,1]  R2066     -4.6179959177970886e-01
    z[3,4,1]  R2067     -3.7745356559753418e-01
    z[3,4,1]  R2068     7.5218003988265991e-01
    z[3,4,1]  R2069     -5.3693801164627075e-01
    z[3,4,1]  R2070     -6.2811189889907837e-01
    z[3,4,1]  R2071     -7.1127003431320190e-01
    z[3,4,1]  R2072     -4.3059056997299194e-01
    z[3,4,1]  R2073     -4.5296445488929749e-01
    z[3,4,1]  R2074     -4.9211472272872925e-01
    z[3,4,1]  R2075     -6.8705797195434570e-01
    z[3,4,1]  R2076     -3.8977241516113281e-01
    z[3,4,1]  R2077     7.1482799947261810e-02
    z[3,4,1]  R2078     -5.5262351036071777e-01
    z[3,4,1]  R2079     -5.0978618860244751e-01
    z[3,4,1]  R2080     7.4618428945541382e-01
    z[3,4,1]  R2081     8.8835489749908447e-01
    z[3,4,1]  R2082     -1.7341756820678711e-01
    z[3,4,1]  R2083     8.2127535343170166e-01
    z[3,4,1]  R2084     -0.522761881351471
    z[3,4,1]  R2085     -2.8531920909881592e-01
    z[3,4,1]  R2086     -5.0097370147705078e-01
    z[3,4,1]  R2087     -5.6872421503067017e-01
    z[3,4,1]  R2088     -4.4913262128829956e-01
    z[3,4,1]  R2089     -5.8296936750411987e-01
    z[3,4,1]  R2090     -5.0831443071365356e-01
    z[3,4,1]  R2091     -4.9253699183464050e-01
    z[3,4,1]  R2092     -1.8199425935745239e-01
    z[3,4,1]  R2093     5.9212136268615723e-01
    z[3,4,1]  R2094     8.6953115463256836e-01
    z[3,4,1]  R2095     -2.9620343446731567e-01
    z[3,4,1]  R2096     -8.4968489408493042e-01
    z[3,4,1]  R2097     -5.1040691137313843e-01
    z[3,4,1]  R2098     -2.2170072793960571e-01
    z[3,4,1]  R2099     -5.4525840282440186e-01
    z[3,4,1]  R2100     -1.0907662659883499e-01
    z[3,4,1]  R2101     -2.1314503252506256e-01
    z[3,4,1]  R2102     8.4723156690597534e-01
    z[3,4,1]  R2103     0.880919337272644
    z[3,4,1]  R2104     7.2155517339706421e-01
    z[3,4,1]  R2105     -0.628449022769928
    z[3,4,1]  R2106     -7.0719486474990845e-01
    z[3,4,1]  R2107     -8.2792568206787109e-01
    z[3,4,1]  R2108     -7.3079919815063477e-01
    z[3,4,1]  R2109     -6.0353887081146240e-01
    z[3,4,1]  R2110     -1.8426091969013214e-01
    z[3,4,1]  R2111     -4.6042034029960632e-01
    z[3,4,1]  R2112     -8.7848186492919922e-02
    z[3,4,1]  R2113     0.886595606803894
    z[3,4,1]  R2114     9.6384423971176147e-01
    z[3,4,1]  R2115     -4.5259761810302734e-01
    z[3,4,1]  R2116     -2.2987347841262817e-01
    z[3,4,1]  R2117     -0.301234632730484
    z[3,4,1]  R2118     -1.4728754758834839e-01
    z[3,4,1]  R2119     8.4514260292053223e-01
    z[3,4,1]  R2120     8.3458983898162842e-01
    z[3,4,1]  R2121     9.0441882610321045e-01
    z[3,4,1]  R2122     5.4224532842636108e-01
    z[3,4,1]  R2123     4.8052567243576050e-01
    z[3,4,1]  R2124     4.5277449488639832e-01
    z[3,4,1]  R2125     -0.736034631729126
    z[3,4,1]  R2126     -0.50221848487854
    z[3,4,1]  R2127     -2.9484912753105164e-01
    z[3,4,1]  R2128     -3.2997876405715942e-01
    z[3,4,1]  R2129     -3.0022957921028137e-01
    z[3,4,1]  R2130     -0.0613643079996109
    z[3,4,1]  R2131     8.3372437953948975e-01
    z[3,4,1]  R2132     0.959001362323761
    z[3,4,1]  R2133     8.2865160703659058e-01
    z[3,4,1]  R2134     8.6359906196594238e-01
    z[3,4,1]  R2135     -7.7929478883743286e-01
    z[3,4,1]  R2136     5.7339859008789062e-01
    z[3,4,1]  R2137     7.7785891294479370e-01
    z[3,4,1]  R2138     -0.228417307138443
    z[3,4,1]  R2139     6.4570468664169312e-01
    z[3,4,1]  R2140     0.749077558517456
    z[3,4,1]  R2141     7.8521335124969482e-01
    z[3,4,1]  R2142     6.2177753448486328e-01
    z[3,4,1]  R2143     5.0166165828704834e-01
    z[3,4,1]  R2144     6.4847087860107422e-01
    z[3,4,1]  R2145     -5.2170819044113159e-01
    z[3,4,1]  R2146     -2.6020979881286621e-01
    z[3,4,1]  R2147     -1.6403673589229584e-01
    z[3,4,1]  R2148     -2.5790682435035706e-01
    z[3,4,1]  R2149     7.9363530874252319e-01
    z[3,4,1]  R2150     9.5412641763687134e-01
    z[3,4,1]  R2151     9.1491103172302246e-01
    z[3,4,1]  R2152     0.478773295879364
    z[3,4,1]  R2153     0.548701286315918
    z[3,4,1]  R2154     6.0121679306030273e-01
    z[3,4,1]  R2155     -1.6934056580066681e-01
    z[3,4,1]  R2156     8.2446902990341187e-01
    z[3,4,1]  R2157     9.6358984708786011e-01
    z[3,4,1]  R2158     6.5812236070632935e-01
    z[3,4,1]  R2159     7.1535408496856689e-01
    z[3,4,1]  R2160     5.4849225282669067e-01
    z[3,4,1]  R2161     7.1080332994461060e-01
    z[3,4,1]  R2162     7.2019606828689575e-01
    z[3,4,1]  R2163     0.670100748538971
    z[3,4,1]  R2164     0.737332820892334
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2025     -1
    z[3,4,2]  R2026     1
    z[3,4,2]  R2035     9.6491836011409760e-02
    z[3,4,2]  R2036     1.0408055037260056e-01
    z[3,4,2]  R2037     -2.7911257743835449e-01
    z[3,4,2]  R2038     -1.6206982731819153e-01
    z[3,4,2]  R2039     2.9160779714584351e-01
    z[3,4,2]  R2040     1.2674829363822937e-01
    z[3,4,2]  R2041     9.7393020987510681e-02
    z[3,4,2]  R2042     -9.0242482721805573e-02
    z[3,4,2]  R2043     2.9007151722908020e-01
    z[3,4,2]  R2044     -1.8557514250278473e-01
    z[3,4,2]  R2045     -2.3937630653381348e-01
    z[3,4,2]  R2046     4.1321533918380737e-01
    z[3,4,2]  R2047     -4.4200602173805237e-01
    z[3,4,2]  R2048     5.5509600788354874e-02
    z[3,4,2]  R2049     1.0695017874240875e-01
    z[3,4,2]  R2050     -3.8250240683555603e-01
    z[3,4,2]  R2051     -4.8148775100708008e-01
    z[3,4,2]  R2052     -5.3229510784149170e-01
    z[3,4,2]  R2053     1.8213652074337006e-01
    z[3,4,2]  R2054     -0.0711749866604805
    z[3,4,2]  R2055     -1.9520850479602814e-01
    z[3,4,2]  R2056     9.2998119071125984e-03
    z[3,4,2]  R2057     -5.1382946968078613e-01
    z[3,4,2]  R2058     1.9087596237659454e-01
    z[3,4,2]  R2059     -1.3207024335861206e-01
    z[3,4,2]  R2060     -1.5683691203594208e-01
    z[3,4,2]  R2061     -3.3692610263824463e-01
    z[3,4,2]  R2062     -2.0341442525386810e-01
    z[3,4,2]  R2063     9.9804960191249847e-02
    z[3,4,2]  R2064     6.1308752745389938e-02
    z[3,4,2]  R2065     -2.7224181219935417e-02
    z[3,4,2]  R2066     1.4349375665187836e-01
    z[3,4,2]  R2067     -1.2734179198741913e-01
    z[3,4,2]  R2068     -2.1428765356540680e-01
    z[3,4,2]  R2069     7.2389543056488037e-01
    z[3,4,2]  R2070     5.6075859069824219e-01
    z[3,4,2]  R2071     4.6849995851516724e-01
    z[3,4,2]  R2072     -3.2706481218338013e-01
    z[3,4,2]  R2073     9.1979922726750374e-03
    z[3,4,2]  R2074     -5.4430490732192993e-01
    z[3,4,2]  R2075     5.6827646493911743e-01
    z[3,4,2]  R2076     -5.1286339759826660e-01
    z[3,4,2]  R2077     -0.46903195977211
    z[3,4,2]  R2078     1.9012993574142456e-01
    z[3,4,2]  R2079     -2.2154814004898071e-01
    z[3,4,2]  R2080     5.2097213268280029e-01
    z[3,4,2]  R2081     -1.8444817513227463e-02
    z[3,4,2]  R2082     6.6841256618499756e-01
    z[3,4,2]  R2083     3.9735755324363708e-01
    z[3,4,2]  R2084     -5.5841112136840820e-01
    z[3,4,2]  R2085     -1.5113285183906555e-01
    z[3,4,2]  R2086     1.7867620289325714e-01
    z[3,4,2]  R2087     5.4607796669006348e-01
    z[3,4,2]  R2088     -5.6303566694259644e-01
    z[3,4,2]  R2089     -3.3601748943328857e-01
    z[3,4,2]  R2090     -1.7890906333923340e-01
    z[3,4,2]  R2091     -1.4444294571876526e-01
    z[3,4,2]  R2092     -0.652751088142395
    z[3,4,2]  R2093     -3.9298117160797119e-01
    z[3,4,2]  R2094     9.1285429894924164e-02
    z[3,4,2]  R2095     -0.668785572052002
    z[3,4,2]  R2096     1.9610232114791870e-01
    z[3,4,2]  R2097     -7.2156423330307007e-01
    z[3,4,2]  R2098     1.7301666736602783e-01
    z[3,4,2]  R2099     -3.2959020137786865e-01
    z[3,4,2]  R2100     1.7456393688917160e-02
    z[3,4,2]  R2101     2.7208173274993896e-01
    z[3,4,2]  R2102     1.0649657994508743e-01
    z[3,4,2]  R2103     -0.0938347652554512
    z[3,4,2]  R2104     4.1236659884452820e-01
    z[3,4,2]  R2105     -0.494943231344223
    z[3,4,2]  R2106     -1.2691226601600647e-01
    z[3,4,2]  R2107     5.0492975860834122e-02
    z[3,4,2]  R2108     4.7204467654228210e-01
    z[3,4,2]  R2109     -8.4907226264476776e-02
    z[3,4,2]  R2110     -1.3565035164356232e-01
    z[3,4,2]  R2111     1.6225245594978333e-01
    z[3,4,2]  R2112     -1.5981492400169373e-01
    z[3,4,2]  R2113     0.0615328773856163
    z[3,4,2]  R2114     1.6760799288749695e-01
    z[3,4,2]  R2115     -1.1647468805313110e-01
    z[3,4,2]  R2116     2.5308451056480408e-01
    z[3,4,2]  R2117     -2.0218318328261375e-02
    z[3,4,2]  R2118     0.582478940486908
    z[3,4,2]  R2119     2.9166597127914429e-01
    z[3,4,2]  R2120     4.5439252257347107e-01
    z[3,4,2]  R2121     2.3995140194892883e-01
    z[3,4,2]  R2122     1.7692428827285767e-01
    z[3,4,2]  R2123     3.7672752141952515e-01
    z[3,4,2]  R2124     1.2909972667694092e-01
    z[3,4,2]  R2125     6.1129800975322723e-02
    z[3,4,2]  R2126     4.1504953987896442e-03
    z[3,4,2]  R2127     3.5807663202285767e-01
    z[3,4,2]  R2128     1.4697174727916718e-01
    z[3,4,2]  R2129     -2.2409553825855255e-01
    z[3,4,2]  R2130     -1.0674206167459488e-01
    z[3,4,2]  R2131     2.6567617058753967e-01
    z[3,4,2]  R2132     1.8880042433738708e-01
    z[3,4,2]  R2133     3.4775212407112122e-01
    z[3,4,2]  R2134     -0.073155976831913
    z[3,4,2]  R2135     5.9725141525268555e-01
    z[3,4,2]  R2136     -9.0044438838958740e-02
    z[3,4,2]  R2137     3.5335725545883179e-01
    z[3,4,2]  R2138     -4.3700179457664490e-01
    z[3,4,2]  R2139     2.0539747178554535e-01
    z[3,4,2]  R2140     2.1612955629825592e-01
    z[3,4,2]  R2141     3.0064875259995461e-02
    z[3,4,2]  R2142     2.0245923101902008e-01
    z[3,4,2]  R2143     2.1178799867630005e-01
    z[3,4,2]  R2144     -3.9450940489768982e-01
    z[3,4,2]  R2145     4.3772339820861816e-02
    z[3,4,2]  R2146     -4.0393903851509094e-02
    z[3,4,2]  R2147     9.4932131469249725e-02
    z[3,4,2]  R2148     -3.7179183959960938e-01
    z[3,4,2]  R2149     2.8107839822769165e-01
    z[3,4,2]  R2150     1.8511307239532471e-01
    z[3,4,2]  R2151     -1.2274567782878876e-01
    z[3,4,2]  R2152     1.3293507695198059e-01
    z[3,4,2]  R2153     2.1158735454082489e-01
    z[3,4,2]  R2154     -5.7536359876394272e-02
    z[3,4,2]  R2155     3.7202858924865723e-01
    z[3,4,2]  R2156     2.4892997741699219e-01
    z[3,4,2]  R2157     6.7938235588371754e-03
    z[3,4,2]  R2158     2.5844931602478027e-01
    z[3,4,2]  R2159     1.1316926218569279e-02
    z[3,4,2]  R2160     6.3249832019209862e-03
    z[3,4,2]  R2161     -2.2752940654754639e-01
    z[3,4,2]  R2162     -3.5796791315078735e-01
    z[3,4,2]  R2163     -2.9539284110069275e-01
    z[3,4,2]  R2164     -1.9871445000171661e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2027     -1
    z[3,4,3]  R2028     1
    z[3,4,3]  R2035     3.8233183324337006e-02
    z[3,4,3]  R2036     -5.6281287223100662e-02
    z[3,4,3]  R2037     -1.6667445003986359e-01
    z[3,4,3]  R2038     -1.1466748267412186e-01
    z[3,4,3]  R2039     2.0051820203661919e-02
    z[3,4,3]  R2040     1.4815273880958557e-01
    z[3,4,3]  R2041     -1.3428920507431030e-01
    z[3,4,3]  R2042     -4.4378823041915894e-01
    z[3,4,3]  R2043     -2.1803137660026550e-01
    z[3,4,3]  R2044     -3.4357210993766785e-01
    z[3,4,3]  R2045     -7.1974718570709229e-01
    z[3,4,3]  R2046     -3.4759324789047241e-01
    z[3,4,3]  R2047     -1.9642159342765808e-01
    z[3,4,3]  R2048     1.9086253643035889e-01
    z[3,4,3]  R2049     2.0496025681495667e-01
    z[3,4,3]  R2050     -7.6402656733989716e-02
    z[3,4,3]  R2051     1.2922681868076324e-01
    z[3,4,3]  R2052     3.9129105210304260e-01
    z[3,4,3]  R2053     5.7691287994384766e-01
    z[3,4,3]  R2054     -1.4007851481437683e-01
    z[3,4,3]  R2055     -3.6240240931510925e-01
    z[3,4,3]  R2056     -5.8406364917755127e-01
    z[3,4,3]  R2057     -3.9486807584762573e-01
    z[3,4,3]  R2058     -4.8408702015876770e-01
    z[3,4,3]  R2059     -2.6580053567886353e-01
    z[3,4,3]  R2060     -1.0204381495714188e-01
    z[3,4,3]  R2061     -2.9818978905677795e-01
    z[3,4,3]  R2062     -4.7207662463188171e-01
    z[3,4,3]  R2063     -4.9308976531028748e-01
    z[3,4,3]  R2064     -4.1535407304763794e-01
    z[3,4,3]  R2065     -1.7730298638343811e-01
    z[3,4,3]  R2066     9.8836747929453850e-03
    z[3,4,3]  R2067     6.6793225705623627e-02
    z[3,4,3]  R2068     2.3008877038955688e-01
    z[3,4,3]  R2069     3.6241963505744934e-01
    z[3,4,3]  R2070     1.1827819049358368e-01
    z[3,4,3]  R2071     4.2783892154693604e-01
    z[3,4,3]  R2072     0.361988365650177
    z[3,4,3]  R2073     1.6963206231594086e-01
    z[3,4,3]  R2074     3.9747819304466248e-01
    z[3,4,3]  R2075     2.1296314895153046e-01
    z[3,4,3]  R2076     1.4430669136345387e-02
    z[3,4,3]  R2077     -3.5894379019737244e-01
    z[3,4,3]  R2078     -5.8972876518964767e-02
    z[3,4,3]  R2079     -1.3377124071121216e-01
    z[3,4,3]  R2080     2.0331309735774994e-01
    z[3,4,3]  R2081     1.6727812588214874e-01
    z[3,4,3]  R2082     -4.0399852395057678e-01
    z[3,4,3]  R2083     -2.3591844365000725e-02
    z[3,4,3]  R2084     4.4183173775672913e-01
    z[3,4,3]  R2085     -3.2720467448234558e-01
    z[3,4,3]  R2086     -4.3055215477943420e-01
    z[3,4,3]  R2087     -3.1249335408210754e-01
    z[3,4,3]  R2088     0.405229389667511
    z[3,4,3]  R2089     1.7126889526844025e-01
    z[3,4,3]  R2090     5.4399931430816650e-01
    z[3,4,3]  R2091     3.7154817581176758e-01
    z[3,4,3]  R2092     -7.8700542449951172e-02
    z[3,4,3]  R2093     -6.3104387372732162e-03
    z[3,4,3]  R2094     2.0656596124172211e-01
    z[3,4,3]  R2095     -2.2475211322307587e-01
    z[3,4,3]  R2096     -5.3780917078256607e-02
    z[3,4,3]  R2097     2.1162706613540649e-01
    z[3,4,3]  R2098     -6.0689233243465424e-02
    z[3,4,3]  R2099     4.1020902991294861e-01
    z[3,4,3]  R2100     -6.2734061479568481e-01
    z[3,4,3]  R2101     -1.5283970534801483e-01
    z[3,4,3]  R2102     9.8189562559127808e-02
    z[3,4,3]  R2103     3.2321885228157043e-01
    z[3,4,3]  R2104     0.495151162147522
    z[3,4,3]  R2105     -1.1997682973742485e-02
    z[3,4,3]  R2106     -3.3768004179000854e-01
    z[3,4,3]  R2107     2.6501366496086121e-01
    z[3,4,3]  R2108     2.4692660570144653e-01
    z[3,4,3]  R2109     1.5630787611007690e-01
    z[3,4,3]  R2110     -3.9980259537696838e-01
    z[3,4,3]  R2111     2.1275892853736877e-02
    z[3,4,3]  R2112     -2.5178197026252747e-01
    z[3,4,3]  R2113     3.1184336543083191e-01
    z[3,4,3]  R2114     2.5135293602943420e-02
    z[3,4,3]  R2115     4.3311214447021484e-01
    z[3,4,3]  R2116     -4.6883741021156311e-01
    z[3,4,3]  R2117     1.8819957971572876e-02
    z[3,4,3]  R2118     -3.3058160543441772e-01
    z[3,4,3]  R2119     4.9212433397769928e-02
    z[3,4,3]  R2120     5.8376058936119080e-02
    z[3,4,3]  R2121     2.5313809514045715e-01
    z[3,4,3]  R2122     3.5397332906723022e-01
    z[3,4,3]  R2123     4.8243951797485352e-01
    z[3,4,3]  R2124     0.520687997341156
    z[3,4,3]  R2125     -5.3401719778776169e-02
    z[3,4,3]  R2126     3.7972751259803772e-01
    z[3,4,3]  R2127     -1.1306407302618027e-01
    z[3,4,3]  R2128     -3.3169585466384888e-01
    z[3,4,3]  R2129     2.3402684926986694e-01
    z[3,4,3]  R2130     -3.3222606778144836e-01
    z[3,4,3]  R2131     2.2909869253635406e-01
    z[3,4,3]  R2132     1.4218333363533020e-01
    z[3,4,3]  R2133     2.0553000271320343e-01
    z[3,4,3]  R2134     2.3103292286396027e-01
    z[3,4,3]  R2135     -5.7719651609659195e-02
    z[3,4,3]  R2136     1.9641692936420441e-01
    z[3,4,3]  R2137     1.0498762130737305e-01
    z[3,4,3]  R2138     8.7422579526901245e-02
    z[3,4,3]  R2139     0.33449786901474
    z[3,4,3]  R2140     2.0736102759838104e-01
    z[3,4,3]  R2141     3.3902138471603394e-01
    z[3,4,3]  R2142     -2.3966248333454132e-01
    z[3,4,3]  R2143     3.6694878339767456e-01
    z[3,4,3]  R2144     -5.0786721706390381e-01
    z[3,4,3]  R2145     -2.3085476830601692e-02
    z[3,4,3]  R2146     1.0495626181364059e-01
    z[3,4,3]  R2147     -3.4113073348999023e-01
    z[3,4,3]  R2148     8.6206562817096710e-02
    z[3,4,3]  R2149     2.9715862870216370e-01
    z[3,4,3]  R2150     1.2247022241353989e-01
    z[3,4,3]  R2151     -2.4262189865112305e-02
    z[3,4,3]  R2152     6.0212099552154541e-01
    z[3,4,3]  R2153     2.7250188589096069e-01
    z[3,4,3]  R2154     2.7629515528678894e-01
    z[3,4,3]  R2155     -2.8098204731941223e-01
    z[3,4,3]  R2156     8.2127936184406281e-02
    z[3,4,3]  R2157     9.0992741286754608e-02
    z[3,4,3]  R2158     5.9459584951400757e-01
    z[3,4,3]  R2159     4.8615738749504089e-01
    z[3,4,3]  R2160     4.2329812049865723e-01
    z[3,4,3]  R2161     1.4226980507373810e-02
    z[3,4,3]  R2162     -1.6567033529281616e-01
    z[3,4,3]  R2163     -1.9238793849945068e-01
    z[3,4,3]  R2164     -1.8471808731555939e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2029     -1
    z[3,4,4]  R2030     1
    z[3,4,4]  R2035     2.6292881369590759e-01
    z[3,4,4]  R2036     1.1427477002143860e-03
    z[3,4,4]  R2037     2.9889410734176636e-01
    z[3,4,4]  R2038     5.2212929725646973e-01
    z[3,4,4]  R2039     2.8739643096923828e-01
    z[3,4,4]  R2040     4.6194615960121155e-01
    z[3,4,4]  R2041     -2.1076743304729462e-01
    z[3,4,4]  R2042     8.2869090139865875e-02
    z[3,4,4]  R2043     -5.6725829839706421e-01
    z[3,4,4]  R2044     -2.1376505494117737e-01
    z[3,4,4]  R2045     -5.7799136638641357e-01
    z[3,4,4]  R2046     -1.2210885435342789e-01
    z[3,4,4]  R2047     -3.7678331136703491e-01
    z[3,4,4]  R2048     -1.7832627892494202e-01
    z[3,4,4]  R2049     -4.3485438823699951e-01
    z[3,4,4]  R2050     0.597722053527832
    z[3,4,4]  R2051     4.6631014347076416e-01
    z[3,4,4]  R2052     2.9649755358695984e-01
    z[3,4,4]  R2053     4.4300094246864319e-01
    z[3,4,4]  R2054     7.8966683149337769e-01
    z[3,4,4]  R2055     -1.6682930290699005e-01
    z[3,4,4]  R2056     -1.9122330844402313e-01
    z[3,4,4]  R2057     -1.1914963275194168e-01
    z[3,4,4]  R2058     -2.1009781956672668e-01
    z[3,4,4]  R2059     -4.1547951102256775e-01
    z[3,4,4]  R2060     3.2895419280976057e-03
    z[3,4,4]  R2061     6.3411749899387360e-02
    z[3,4,4]  R2062     2.6501941680908203e-01
    z[3,4,4]  R2063     -9.0105690062046051e-02
    z[3,4,4]  R2064     2.3578166961669922e-01
    z[3,4,4]  R2065     -2.0581318438053131e-01
    z[3,4,4]  R2066     -1.5405574440956116e-01
    z[3,4,4]  R2067     -4.6345052123069763e-01
    z[3,4,4]  R2068     -1.7371930181980133e-01
    z[3,4,4]  R2069     1.5203894674777985e-01
    z[3,4,4]  R2070     -1.7029793560504913e-01
    z[3,4,4]  R2071     -1.4309158921241760e-01
    z[3,4,4]  R2072     6.5895318984985352e-02
    z[3,4,4]  R2073     -8.9322596788406372e-02
    z[3,4,4]  R2074     6.9609411060810089e-02
    z[3,4,4]  R2075     3.4623327851295471e-01
    z[3,4,4]  R2076     -4.7948709130287170e-01
    z[3,4,4]  R2077     -6.1006331443786621e-01
    z[3,4,4]  R2078     8.7079212069511414e-02
    z[3,4,4]  R2079     4.4583201408386230e-01
    z[3,4,4]  R2080     3.1959778070449829e-01
    z[3,4,4]  R2081     -0.0889601856470108
    z[3,4,4]  R2082     -4.1677546501159668e-01
    z[3,4,4]  R2083     1.6093716025352478e-01
    z[3,4,4]  R2084     2.8899261355400085e-01
    z[3,4,4]  R2085     -6.7880898714065552e-01
    z[3,4,4]  R2086     2.3162260651588440e-01
    z[3,4,4]  R2087     -4.2658692598342896e-01
    z[3,4,4]  R2088     3.7110611796379089e-02
    z[3,4,4]  R2089     0.253608763217926
    z[3,4,4]  R2090     -3.0783239006996155e-01
    z[3,4,4]  R2091     8.0141127109527588e-02
    z[3,4,4]  R2092     2.8608945012092590e-01
    z[3,4,4]  R2093     -3.0059763230383396e-03
    z[3,4,4]  R2094     3.0319327116012573e-01
    z[3,4,4]  R2095     -4.4815093278884888e-01
    z[3,4,4]  R2096     1.0846333205699921e-01
    z[3,4,4]  R2097     -2.5771671533584595e-01
    z[3,4,4]  R2098     7.1807242929935455e-02
    z[3,4,4]  R2099     3.1035497784614563e-01
    z[3,4,4]  R2100     3.9208721369504929e-02
    z[3,4,4]  R2101     -4.1954988241195679e-01
    z[3,4,4]  R2102     3.2510882616043091e-01
    z[3,4,4]  R2103     3.0939370393753052e-01
    z[3,4,4]  R2104     1.0399816930294037e-01
    z[3,4,4]  R2105     -3.2380643486976624e-01
    z[3,4,4]  R2106     -4.3692804872989655e-02
    z[3,4,4]  R2107     3.5460570454597473e-01
    z[3,4,4]  R2108     -1.2773409485816956e-01
    z[3,4,4]  R2109     -9.9731072783470154e-02
    z[3,4,4]  R2110     2.4622483551502228e-01
    z[3,4,4]  R2111     4.0934920310974121e-01
    z[3,4,4]  R2112     -2.5437366962432861e-01
    z[3,4,4]  R2113     3.4494414925575256e-02
    z[3,4,4]  R2114     3.8776747882366180e-02
    z[3,4,4]  R2115     -2.2928847372531891e-01
    z[3,4,4]  R2116     7.2756119072437286e-02
    z[3,4,4]  R2117     -5.0857514142990112e-01
    z[3,4,4]  R2118     2.7385911345481873e-01
    z[3,4,4]  R2119     3.0575612187385559e-01
    z[3,4,4]  R2120     2.1467334032058716e-01
    z[3,4,4]  R2121     1.6659593582153320e-01
    z[3,4,4]  R2122     6.6348105669021606e-01
    z[3,4,4]  R2123     -7.7274434268474579e-02
    z[3,4,4]  R2124     5.2379506826400757e-01
    z[3,4,4]  R2125     2.8799173235893250e-01
    z[3,4,4]  R2126     -1.4048458635807037e-01
    z[3,4,4]  R2127     -1.8486697971820831e-01
    z[3,4,4]  R2128     2.1070814132690430e-01
    z[3,4,4]  R2129     -2.4036785587668419e-02
    z[3,4,4]  R2130     3.0900094658136368e-02
    z[3,4,4]  R2131     1.7191524803638458e-01
    z[3,4,4]  R2132     0.0910961776971817
    z[3,4,4]  R2133     2.3283807933330536e-01
    z[3,4,4]  R2134     0.0839817002415657
    z[3,4,4]  R2135     4.7030895948410034e-02
    z[3,4,4]  R2136     2.6917797327041626e-01
    z[3,4,4]  R2137     -2.2383768856525421e-01
    z[3,4,4]  R2138     2.5361141562461853e-01
    z[3,4,4]  R2139     5.5442094802856445e-01
    z[3,4,4]  R2140     5.7248443365097046e-01
    z[3,4,4]  R2141     -0.470795214176178
    z[3,4,4]  R2142     4.7683233022689819e-01
    z[3,4,4]  R2143     4.5888155698776245e-01
    z[3,4,4]  R2144     1.3239391148090363e-01
    z[3,4,4]  R2145     2.6018369942903519e-02
    z[3,4,4]  R2146     -2.6247984170913696e-01
    z[3,4,4]  R2147     -2.6960924267768860e-01
    z[3,4,4]  R2148     2.5080201029777527e-01
    z[3,4,4]  R2149     3.7362700700759888e-01
    z[3,4,4]  R2150     -1.7409019637852907e-03
    z[3,4,4]  R2151     -2.4190691113471985e-01
    z[3,4,4]  R2152     5.1489669084548950e-01
    z[3,4,4]  R2153     -1.8420583009719849e-01
    z[3,4,4]  R2154     -1.3304264843463898e-01
    z[3,4,4]  R2155     3.0345159769058228e-01
    z[3,4,4]  R2156     4.6785643696784973e-01
    z[3,4,4]  R2157     -9.7694151103496552e-02
    z[3,4,4]  R2158     6.8273797631263733e-02
    z[3,4,4]  R2159     -2.1637508273124695e-01
    z[3,4,4]  R2160     2.2672414779663086e-01
    z[3,4,4]  R2161     -1.3508158922195435e-01
    z[3,4,4]  R2162     1.2351201474666595e-01
    z[3,4,4]  R2163     -1.2425804138183594e-01
    z[3,4,4]  R2164     -2.5327226519584656e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2031     -1
    z[3,4,5]  R2032     1
    z[3,4,5]  R2035     -7.6487839221954346e-01
    z[3,4,5]  R2036     -8.1545692682266235e-01
    z[3,4,5]  R2037     -6.6843688488006592e-01
    z[3,4,5]  R2038     -1.8858213722705841e-01
    z[3,4,5]  R2039     -2.8500708937644958e-01
    z[3,4,5]  R2040     -5.8723074197769165e-01
    z[3,4,5]  R2041     -4.9610987305641174e-01
    z[3,4,5]  R2042     -1.2263411283493042e-01
    z[3,4,5]  R2043     -7.1447348594665527e-01
    z[3,4,5]  R2044     1.4723853208124638e-02
    z[3,4,5]  R2045     -2.5184974074363708e-01
    z[3,4,5]  R2046     3.0484935641288757e-01
    z[3,4,5]  R2047     -3.5863202810287476e-01
    z[3,4,5]  R2048     1.1830098181962967e-01
    z[3,4,5]  R2049     2.0683903992176056e-01
    z[3,4,5]  R2050     2.4618925154209137e-01
    z[3,4,5]  R2051     3.5562586784362793e-01
    z[3,4,5]  R2052     -3.2573845237493515e-02
    z[3,4,5]  R2053     3.1028228998184204e-01
    z[3,4,5]  R2054     3.1595242023468018e-01
    z[3,4,5]  R2055     -0.567290186882019
    z[3,4,5]  R2056     -4.7096580266952515e-01
    z[3,4,5]  R2057     -2.8467962145805359e-01
    z[3,4,5]  R2058     -4.5613187551498413e-01
    z[3,4,5]  R2059     -3.7316355109214783e-01
    z[3,4,5]  R2060     -4.9113425612449646e-01
    z[3,4,5]  R2061     -2.2501760721206665e-01
    z[3,4,5]  R2062     -4.5422890782356262e-01
    z[3,4,5]  R2063     -1.9683602452278137e-01
    z[3,4,5]  R2064     -7.4810914695262909e-02
    z[3,4,5]  R2065     5.5614137649536133e-01
    z[3,4,5]  R2066     4.6744874119758606e-01
    z[3,4,5]  R2067     3.0523526668548584e-01
    z[3,4,5]  R2068     -4.0307754278182983e-01
    z[3,4,5]  R2069     6.4861392602324486e-03
    z[3,4,5]  R2070     -3.5454906523227692e-02
    z[3,4,5]  R2071     1.2842306494712830e-01
    z[3,4,5]  R2072     1.4541678130626678e-01
    z[3,4,5]  R2073     1.6680285334587097e-01
    z[3,4,5]  R2074     8.6275503039360046e-02
    z[3,4,5]  R2075     -8.8976975530385971e-03
    z[3,4,5]  R2076     4.5235604047775269e-01
    z[3,4,5]  R2077     3.6717417836189270e-01
    z[3,4,5]  R2078     -6.2057387083768845e-02
    z[3,4,5]  R2079     1.4026379585266113e-01
    z[3,4,5]  R2080     -8.7293386459350586e-02
    z[3,4,5]  R2081     2.5280052423477173e-01
    z[3,4,5]  R2082     1.5615834295749664e-01
    z[3,4,5]  R2083     -1.2509214878082275e-01
    z[3,4,5]  R2084     2.4431882798671722e-01
    z[3,4,5]  R2085     3.5856953263282776e-01
    z[3,4,5]  R2086     5.8395403623580933e-01
    z[3,4,5]  R2087     2.4112163484096527e-01
    z[3,4,5]  R2088     2.9454326629638672e-01
    z[3,4,5]  R2089     3.1561228632926941e-01
    z[3,4,5]  R2090     -1.8078792095184326e-01
    z[3,4,5]  R2091     -2.5250095129013062e-01
    z[3,4,5]  R2092     1.8632566928863525e-01
    z[3,4,5]  R2093     -4.3672680854797363e-01
    z[3,4,5]  R2094     -8.9058600366115570e-02
    z[3,4,5]  R2095     4.4784566760063171e-01
    z[3,4,5]  R2096     0.425496906042099
    z[3,4,5]  R2097     3.2415258884429932e-01
    z[3,4,5]  R2098     -1.6619232296943665e-01
    z[3,4,5]  R2099     -2.3024032998364419e-04
    z[3,4,5]  R2100     -2.1188246086239815e-02
    z[3,4,5]  R2101     -4.2546260356903076e-01
    z[3,4,5]  R2102     -3.7626194953918457e-01
    z[3,4,5]  R2103     -1.1377550661563873e-02
    z[3,4,5]  R2104     -1.3964809477329254e-01
    z[3,4,5]  R2105     4.3637013435363770e-01
    z[3,4,5]  R2106     5.8601337671279907e-01
    z[3,4,5]  R2107     1.8636810779571533e-01
    z[3,4,5]  R2108     2.5316748023033142e-01
    z[3,4,5]  R2109     1.7170919477939606e-01
    z[3,4,5]  R2110     3.3964416384696960e-01
    z[3,4,5]  R2111     -2.2880868613719940e-01
    z[3,4,5]  R2112     -3.0514645576477051e-01
    z[3,4,5]  R2113     -3.9614114910364151e-02
    z[3,4,5]  R2114     -1.1986841447651386e-02
    z[3,4,5]  R2115     -1.8737922608852386e-01
    z[3,4,5]  R2116     2.9761362075805664e-01
    z[3,4,5]  R2117     -1.4091113209724426e-01
    z[3,4,5]  R2118     -2.1088285744190216e-01
    z[3,4,5]  R2119     -1.4867080748081207e-01
    z[3,4,5]  R2120     -1.5140730142593384e-01
    z[3,4,5]  R2121     7.3399171233177185e-02
    z[3,4,5]  R2122     -1.3731801509857178e-01
    z[3,4,5]  R2123     -2.1077500283718109e-01
    z[3,4,5]  R2124     -4.1861617565155029e-01
    z[3,4,5]  R2125     1.5950110554695129e-01
    z[3,4,5]  R2126     3.1426626443862915e-01
    z[3,4,5]  R2127     6.6431082785129547e-02
    z[3,4,5]  R2128     4.6235236525535583e-01
    z[3,4,5]  R2129     -1.1576903052628040e-02
    z[3,4,5]  R2130     -7.8274980187416077e-02
    z[3,4,5]  R2131     -3.7693977355957031e-01
    z[3,4,5]  R2132     4.1850835084915161e-02
    z[3,4,5]  R2133     6.0755524784326553e-02
    z[3,4,5]  R2134     -1.1820632964372635e-02
    z[3,4,5]  R2135     5.8419197797775269e-02
    z[3,4,5]  R2136     -4.5930200815200806e-01
    z[3,4,5]  R2137     1.8721137195825577e-02
    z[3,4,5]  R2138     -4.5784667134284973e-01
    z[3,4,5]  R2139     -1.4388071000576019e-01
    z[3,4,5]  R2140     0.082222118973732
    z[3,4,5]  R2141     1.2622365355491638e-01
    z[3,4,5]  R2142     -2.6503092050552368e-01
    z[3,4,5]  R2143     -3.6509260535240173e-01
    z[3,4,5]  R2144     -1.9301755726337433e-01
    z[3,4,5]  R2145     2.3834304511547089e-01
    z[3,4,5]  R2146     3.6902558803558350e-01
    z[3,4,5]  R2147     3.8425880670547485e-01
    z[3,4,5]  R2148     -4.2244362831115723e-01
    z[3,4,5]  R2149     2.0742814987897873e-02
    z[3,4,5]  R2150     0.0847427025437355
    z[3,4,5]  R2151     1.6116046905517578e-01
    z[3,4,5]  R2152     -3.4456923604011536e-01
    z[3,4,5]  R2153     -5.1498931646347046e-01
    z[3,4,5]  R2154     -2.9532846808433533e-01
    z[3,4,5]  R2155     -3.2721281051635742e-01
    z[3,4,5]  R2156     -5.4802145808935165e-02
    z[3,4,5]  R2157     2.5784159079194069e-02
    z[3,4,5]  R2158     -3.3183619379997253e-01
    z[3,4,5]  R2159     -9.4814337790012360e-02
    z[3,4,5]  R2160     -3.2409057021141052e-01
    z[3,4,5]  R2161     -3.0177587270736694e-01
    z[3,4,5]  R2162     -3.4313338994979858e-01
    z[3,4,5]  R2163     -2.3594951629638672e-01
    z[3,4,5]  R2164     -3.2928720116615295e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2033     -1
    z[3,4,6]  R2034     1
    z[3,4,6]  R2035     -3.8868039846420288e-02
    z[3,4,6]  R2036     1.7078292369842529e-01
    z[3,4,6]  R2037     6.9759249687194824e-02
    z[3,4,6]  R2038     -2.1688843145966530e-02
    z[3,4,6]  R2039     -1.9994966685771942e-01
    z[3,4,6]  R2040     -2.4667167663574219e-01
    z[3,4,6]  R2041     -2.4155495688319206e-02
    z[3,4,6]  R2042     -3.1171691417694092e-01
    z[3,4,6]  R2043     1.3359299302101135e-01
    z[3,4,6]  R2044     3.6421930789947510e-01
    z[3,4,6]  R2045     8.1820584833621979e-02
    z[3,4,6]  R2046     0.178999662399292
    z[3,4,6]  R2047     -3.2374124974012375e-02
    z[3,4,6]  R2048     -3.1008267402648926e-01
    z[3,4,6]  R2049     1.9876374304294586e-01
    z[3,4,6]  R2050     1.7755150794982910e-01
    z[3,4,6]  R2051     -3.0585335567593575e-02
    z[3,4,6]  R2052     2.4119900166988373e-01
    z[3,4,6]  R2053     -1.1051856726408005e-01
    z[3,4,6]  R2054     -2.6112416386604309e-01
    z[3,4,6]  R2055     -1.1409967392683029e-01
    z[3,4,6]  R2056     1.8631061911582947e-01
    z[3,4,6]  R2057     1.5505558252334595e-01
    z[3,4,6]  R2058     -9.4230905175209045e-02
    z[3,4,6]  R2059     8.8811673223972321e-02
    z[3,4,6]  R2060     -5.4144892841577530e-02
    z[3,4,6]  R2061     -3.6406937241554260e-01
    z[3,4,6]  R2062     2.2296257317066193e-01
    z[3,4,6]  R2063     -4.3690085411071777e-01
    z[3,4,6]  R2064     -0.284881055355072
    z[3,4,6]  R2065     2.3958197236061096e-01
    z[3,4,6]  R2066     -2.3904012143611908e-01
    z[3,4,6]  R2067     -1.1963321268558502e-01
    z[3,4,6]  R2068     -4.6805106103420258e-02
    z[3,4,6]  R2069     -1.7740327119827271e-01
    z[3,4,6]  R2070     3.9852154254913330e-01
    z[3,4,6]  R2071     -1.7968656122684479e-01
    z[3,4,6]  R2072     -5.7249772548675537e-01
    z[3,4,6]  R2073     -6.5263003110885620e-01
    z[3,4,6]  R2074     -2.8091764450073242e-01
    z[3,4,6]  R2075     1.6536907851696014e-01
    z[3,4,6]  R2076     -3.8747996091842651e-01
    z[3,4,6]  R2077     -3.6879444122314453e-01
    z[3,4,6]  R2078     7.8969156742095947e-01
    z[3,4,6]  R2079     -2.0165938138961792e-01
    z[3,4,6]  R2080     -1.3785080611705780e-01
    z[3,4,6]  R2081     0.332021564245224
    z[3,4,6]  R2082     8.9740976691246033e-02
    z[3,4,6]  R2083     -1.3271878659725189e-01
    z[3,4,6]  R2084     2.6851412653923035e-01
    z[3,4,6]  R2085     -4.4646671414375305e-01
    z[3,4,6]  R2086     3.5155513882637024e-01
    z[3,4,6]  R2087     9.7187506034970284e-03
    z[3,4,6]  R2088     -3.9079171419143677e-01
    z[3,4,6]  R2089     -1.6757705807685852e-01
    z[3,4,6]  R2090     -2.3581512272357941e-02
    z[3,4,6]  R2091     4.8792776465415955e-01
    z[3,4,6]  R2092     5.0658807158470154e-02
    z[3,4,6]  R2093     4.8480924963951111e-01
    z[3,4,6]  R2094     -2.5699833035469055e-01
    z[3,4,6]  R2095     6.6792696714401245e-02
    z[3,4,6]  R2096     2.0928496122360229e-01
    z[3,4,6]  R2097     -6.2918695621192455e-03
    z[3,4,6]  R2098     0.377238005399704
    z[3,4,6]  R2099     3.1086388230323792e-01
    z[3,4,6]  R2100     -1.9821390509605408e-01
    z[3,4,6]  R2101     -1.8849206389859319e-03
    z[3,4,6]  R2102     5.9384290128946304e-02
    z[3,4,6]  R2103     -9.6629941835999489e-03
    z[3,4,6]  R2104     1.4050062000751495e-01
    z[3,4,6]  R2105     -2.0856364071369171e-01
    z[3,4,6]  R2106     1.5194277465343475e-01
    z[3,4,6]  R2107     1.9492205977439880e-01
    z[3,4,6]  R2108     -3.1650376319885254e-01
    z[3,4,6]  R2109     -2.8207591176033020e-01
    z[3,4,6]  R2110     -2.5937798619270325e-01
    z[3,4,6]  R2111     -2.2709725797176361e-01
    z[3,4,6]  R2112     -1.5670976042747498e-01
    z[3,4,6]  R2113     -1.8955725431442261e-01
    z[3,4,6]  R2114     -1.1056371033191681e-01
    z[3,4,6]  R2115     1.5578483045101166e-01
    z[3,4,6]  R2116     -3.3971226215362549e-01
    z[3,4,6]  R2117     2.9629576206207275e-01
    z[3,4,6]  R2118     -1.7692670226097107e-01
    z[3,4,6]  R2119     1.2157399207353592e-01
    z[3,4,6]  R2120     -8.9330114424228668e-02
    z[3,4,6]  R2121     -1.0918104648590088e-01
    z[3,4,6]  R2122     2.1212534606456757e-01
    z[3,4,6]  R2123     -0.00732843903824687
    z[3,4,6]  R2124     -1.8028123676776886e-01
    z[3,4,6]  R2125     5.8017671108245850e-01
    z[3,4,6]  R2126     1.7972312867641449e-02
    z[3,4,6]  R2127     -4.0665301680564880e-01
    z[3,4,6]  R2128     1.0987018793821335e-01
    z[3,4,6]  R2129     6.1497384309768677e-01
    z[3,4,6]  R2130     -3.0301022529602051e-01
    z[3,4,6]  R2131     2.1675251424312592e-02
    z[3,4,6]  R2132     8.7226778268814087e-02
    z[3,4,6]  R2133     2.8561198711395264e-01
    z[3,4,6]  R2134     4.3371358513832092e-01
    z[3,4,6]  R2135     1.3211207091808319e-01
    z[3,4,6]  R2136     -4.1308730840682983e-01
    z[3,4,6]  R2137     -1.3268908485770226e-02
    z[3,4,6]  R2138     -9.4475768506526947e-02
    z[3,4,6]  R2139     1.4035947620868683e-01
    z[3,4,6]  R2140     1.2068077921867371e-01
    z[3,4,6]  R2141     2.5822622701525688e-02
    z[3,4,6]  R2142     3.6570936441421509e-01
    z[3,4,6]  R2143     4.2769372463226318e-01
    z[3,4,6]  R2144     -8.2987926900386810e-02
    z[3,4,6]  R2145     -2.1248523890972137e-01
    z[3,4,6]  R2146     4.3469882011413574e-01
    z[3,4,6]  R2147     2.6805743575096130e-01
    z[3,4,6]  R2148     -1.0324721783399582e-01
    z[3,4,6]  R2149     2.3308119177818298e-01
    z[3,4,6]  R2150     -1.6491647064685822e-01
    z[3,4,6]  R2151     -1.6455566883087158e-01
    z[3,4,6]  R2152     -6.8455703556537628e-02
    z[3,4,6]  R2153     -2.2133512794971466e-01
    z[3,4,6]  R2154     -9.1432582121342421e-04
    z[3,4,6]  R2155     -0.0773564875125885
    z[3,4,6]  R2156     1.6218551993370056e-01
    z[3,4,6]  R2157     -9.9893517792224884e-02
    z[3,4,6]  R2158     -1.7724396288394928e-01
    z[3,4,6]  R2159     3.0140149593353271e-01
    z[3,4,6]  R2160     5.6753152608871460e-01
    z[3,4,6]  R2161     -1.5236841142177582e-01
    z[3,4,6]  R2162     4.0906123816967010e-02
    z[3,4,6]  R2163     -3.5598453134298325e-02
    z[3,4,6]  R2164     1.6011761128902435e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2165     -1
    z[4,3,0]  R2166     1
    z[4,3,0]  R2179     -5.8755654096603394e-01
    z[4,3,0]  R2180     -0.550112783908844
    z[4,3,0]  R2181     -5.7592475414276123e-01
    z[4,3,0]  R2182     -6.1626744270324707e-01
    z[4,3,0]  R2183     -5.3182321786880493e-01
    z[4,3,0]  R2184     -6.7129796743392944e-01
    z[4,3,0]  R2185     -6.7024582624435425e-01
    z[4,3,0]  R2186     -5.8671534061431885e-01
    z[4,3,0]  R2187     -6.3573414087295532e-01
    z[4,3,0]  R2188     -7.6984459161758423e-01
    z[4,3,0]  R2189     2.2927865386009216e-01
    z[4,3,0]  R2190     6.8313342332839966e-01
    z[4,3,0]  R2191     7.1734535694122314e-01
    z[4,3,0]  R2192     -3.7486594915390015e-01
    z[4,3,0]  R2193     4.1173495352268219e-02
    z[4,3,0]  R2194     2.9657664895057678e-01
    z[4,3,0]  R2195     1.4933685958385468e-01
    z[4,3,0]  R2196     4.7259172797203064e-01
    z[4,3,0]  R2197     5.5157589912414551e-01
    z[4,3,0]  R2198     4.6082824468612671e-01
    z[4,3,0]  R2199     -1.1115819215774536e-01
    z[4,3,0]  R2200     -1.2880751863121986e-02
    z[4,3,0]  R2201     5.5273931473493576e-02
    z[4,3,0]  R2202     1.4118523895740509e-01
    z[4,3,0]  R2203     6.4345401525497437e-01
    z[4,3,0]  R2204     0.0411706306040287
    z[4,3,0]  R2205     2.1051850169897079e-02
    z[4,3,0]  R2206     3.9216777682304382e-01
    z[4,3,0]  R2207     3.2847228646278381e-01
    z[4,3,0]  R2208     -0.0661325603723526
    z[4,3,0]  R2209     1.6047385288402438e-03
    z[4,3,0]  R2210     1.1611460894346237e-01
    z[4,3,0]  R2211     2.0121926069259644e-01
    z[4,3,0]  R2212     -2.7605935931205750e-01
    z[4,3,0]  R2213     5.7087254524230957e-01
    z[4,3,0]  R2214     0.534482479095459
    z[4,3,0]  R2215     5.3874176740646362e-01
    z[4,3,0]  R2216     6.4456933736801147e-01
    z[4,3,0]  R2217     -2.6294299960136414e-01
    z[4,3,0]  R2218     1.6433918476104736e-01
    z[4,3,0]  R2219     9.2788405716419220e-02
    z[4,3,0]  R2220     8.6532514542341232e-03
    z[4,3,0]  R2221     -5.0115205347537994e-02
    z[4,3,0]  R2222     8.6147910356521606e-01
    z[4,3,0]  R2223     4.8253032565116882e-01
    z[4,3,0]  R2224     7.4361699819564819e-01
    z[4,3,0]  R2225     7.0720338821411133e-01
    z[4,3,0]  R2226     1.0208169370889664e-01
    z[4,3,0]  R2227     1.2148441374301910e-01
    z[4,3,0]  R2228     -1.1865770816802979e-01
    z[4,3,0]  R2229     -1.4550159871578217e-01
    z[4,3,0]  R2230     -3.6517471075057983e-02
    z[4,3,0]  R2231     -2.0804883539676666e-01
    z[4,3,0]  R2232     3.9359282702207565e-02
    z[4,3,0]  R2233     6.9649285078048706e-01
    z[4,3,0]  R2234     7.3793154954910278e-01
    z[4,3,0]  R2235     6.9981509447097778e-01
    z[4,3,0]  R2236     8.4909921884536743e-01
    z[4,3,0]  R2237     2.7244171500205994e-01
    z[4,3,0]  R2238     0.168548122048378
    z[4,3,0]  R2239     6.9429796934127808e-01
    z[4,3,0]  R2240     6.7381465435028076e-01
    z[4,3,0]  R2241     7.3634153604507446e-01
    z[4,3,0]  R2242     6.1560302972793579e-01
    z[4,3,0]  R2243     2.6052442193031311e-01
    z[4,3,0]  R2244     -1.2880542874336243e-01
    z[4,3,0]  R2245     -1.2372874468564987e-01
    z[4,3,0]  R2246     2.1286159753799438e-01
    z[4,3,0]  R2247     5.8649146556854248e-01
    z[4,3,0]  R2248     -1.5846298635005951e-01
    z[4,3,0]  R2249     -8.1728391349315643e-02
    z[4,3,0]  R2250     6.9623565673828125e-01
    z[4,3,0]  R2251     7.5372809171676636e-01
    z[4,3,0]  R2252     6.9946563243865967e-01
    z[4,3,0]  R2253     6.5266388654708862e-01
    z[4,3,0]  R2254     8.8066416978836060e-01
    z[4,3,0]  R2255     0.0986173152923584
    z[4,3,0]  R2256     -0.0824391320347786
    z[4,3,0]  R2257     1.0335975885391235e-01
    z[4,3,0]  R2258     -1.2979520484805107e-02
    z[4,3,0]  R2259     -0.0978812426328659
    z[4,3,0]  R2260     -4.1288039088249207e-01
    z[4,3,0]  R2261     -4.5653238892555237e-01
    z[4,3,0]  R2262     6.8289393186569214e-01
    z[4,3,0]  R2263     2.8496208786964417e-01
    z[4,3,0]  R2264     -1.0464946739375591e-02
    z[4,3,0]  R2265     1.7132751643657684e-01
    z[4,3,0]  R2266     -2.8915578126907349e-01
    z[4,3,0]  R2267     -2.0504486560821533e-01
    z[4,3,0]  R2268     3.2287436723709106e-01
    z[4,3,0]  R2269     0.789137065410614
    z[4,3,0]  R2270     7.2498601675033569e-01
    z[4,3,0]  R2271     7.4532598257064819e-01
    z[4,3,0]  R2272     7.3198574781417847e-01
    z[4,3,0]  R2273     -9.2089831829071045e-02
    z[4,3,0]  R2274     -7.7427178621292114e-02
    z[4,3,0]  R2275     1.8897749483585358e-01
    z[4,3,0]  R2276     4.4966783374547958e-02
    z[4,3,0]  R2277     4.8142012953758240e-01
    z[4,3,0]  R2278     6.7377209663391113e-01
    z[4,3,0]  R2279     7.4083232879638672e-01
    z[4,3,0]  R2280     5.7815268635749817e-02
    z[4,3,0]  R2281     2.0731888711452484e-01
    z[4,3,0]  R2282     1.8512832000851631e-02
    z[4,3,0]  R2283     3.2425409555435181e-01
    z[4,3,0]  R2284     2.0348079502582550e-01
    z[4,3,0]  R2285     5.5700516700744629e-01
    z[4,3,0]  R2286     4.3710514903068542e-01
    z[4,3,0]  R2287     5.9524399042129517e-01
    z[4,3,0]  R2288     4.2955505847930908e-01
    z[4,3,0]  R2289     2.7983114123344421e-01
    z[4,3,0]  R2290     4.5460104942321777e-01
    z[4,3,0]  R2291     5.2850371599197388e-01
    z[4,3,0]  R2292     7.4628823995590210e-01
    z[4,3,0]  R2293     6.7978280782699585e-01
    z[4,3,0]  R2294     5.0720679759979248e-01
    z[4,3,0]  R2295     -1.7386375367641449e-01
    z[4,3,0]  R2296     6.3635128736495972e-01
    z[4,3,0]  R2297     1.9838495645672083e-03
    z[4,3,0]  R2298     4.3724125623703003e-01
    z[4,3,0]  R2299     1.0943809896707535e-01
    z[4,3,0]  R2300     7.2360396385192871e-01
    z[4,3,0]  R2301     -0.41497603058815
    z[4,3,0]  R2302     -0.360065221786499
    z[4,3,0]  R2303     -4.2180991172790527e-01
    z[4,3,0]  R2304     -4.8004138469696045e-01
    z[4,3,0]  R2305     -4.3477049469947815e-01
    z[4,3,0]  R2306     -0.6156005859375
    z[4,3,0]  R2307     -3.2301768660545349e-01
    z[4,3,0]  R2308     -3.7379533052444458e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2167     -1
    z[4,3,1]  R2168     1
    z[4,3,1]  R2179     -3.5023787617683411e-01
    z[4,3,1]  R2180     -2.5114196538925171e-01
    z[4,3,1]  R2181     -3.5928779840469360e-01
    z[4,3,1]  R2182     -2.9726028442382812e-01
    z[4,3,1]  R2183     -5.5615627765655518e-01
    z[4,3,1]  R2184     -5.1980084180831909e-01
    z[4,3,1]  R2185     -4.0141481161117554e-01
    z[4,3,1]  R2186     -2.5546005368232727e-01
    z[4,3,1]  R2187     -0.32403364777565
    z[4,3,1]  R2188     -2.9785001277923584e-01
    z[4,3,1]  R2189     -7.1147876977920532e-01
    z[4,3,1]  R2190     -4.6179959177970886e-01
    z[4,3,1]  R2191     -3.7745356559753418e-01
    z[4,3,1]  R2192     7.5218003988265991e-01
    z[4,3,1]  R2193     -5.3693801164627075e-01
    z[4,3,1]  R2194     -6.2811189889907837e-01
    z[4,3,1]  R2195     -7.1127003431320190e-01
    z[4,3,1]  R2196     -4.3059056997299194e-01
    z[4,3,1]  R2197     -4.5296445488929749e-01
    z[4,3,1]  R2198     -4.9211472272872925e-01
    z[4,3,1]  R2199     -6.8705797195434570e-01
    z[4,3,1]  R2200     -3.8977241516113281e-01
    z[4,3,1]  R2201     7.1482799947261810e-02
    z[4,3,1]  R2202     -5.5262351036071777e-01
    z[4,3,1]  R2203     -5.0978618860244751e-01
    z[4,3,1]  R2204     7.4618428945541382e-01
    z[4,3,1]  R2205     8.8835489749908447e-01
    z[4,3,1]  R2206     -1.7341756820678711e-01
    z[4,3,1]  R2207     8.2127535343170166e-01
    z[4,3,1]  R2208     -0.522761881351471
    z[4,3,1]  R2209     -2.8531920909881592e-01
    z[4,3,1]  R2210     -5.0097370147705078e-01
    z[4,3,1]  R2211     -5.6872421503067017e-01
    z[4,3,1]  R2212     -4.4913262128829956e-01
    z[4,3,1]  R2213     -5.8296936750411987e-01
    z[4,3,1]  R2214     -5.0831443071365356e-01
    z[4,3,1]  R2215     -4.9253699183464050e-01
    z[4,3,1]  R2216     -1.8199425935745239e-01
    z[4,3,1]  R2217     5.9212136268615723e-01
    z[4,3,1]  R2218     8.6953115463256836e-01
    z[4,3,1]  R2219     -2.9620343446731567e-01
    z[4,3,1]  R2220     -8.4968489408493042e-01
    z[4,3,1]  R2221     -5.1040691137313843e-01
    z[4,3,1]  R2222     -2.2170072793960571e-01
    z[4,3,1]  R2223     -5.4525840282440186e-01
    z[4,3,1]  R2224     -1.0907662659883499e-01
    z[4,3,1]  R2225     -2.1314503252506256e-01
    z[4,3,1]  R2226     8.4723156690597534e-01
    z[4,3,1]  R2227     0.880919337272644
    z[4,3,1]  R2228     7.2155517339706421e-01
    z[4,3,1]  R2229     -0.628449022769928
    z[4,3,1]  R2230     -7.0719486474990845e-01
    z[4,3,1]  R2231     -8.2792568206787109e-01
    z[4,3,1]  R2232     -7.3079919815063477e-01
    z[4,3,1]  R2233     -6.0353887081146240e-01
    z[4,3,1]  R2234     -1.8426091969013214e-01
    z[4,3,1]  R2235     -4.6042034029960632e-01
    z[4,3,1]  R2236     -8.7848186492919922e-02
    z[4,3,1]  R2237     0.886595606803894
    z[4,3,1]  R2238     9.6384423971176147e-01
    z[4,3,1]  R2239     -4.5259761810302734e-01
    z[4,3,1]  R2240     -2.2987347841262817e-01
    z[4,3,1]  R2241     -0.301234632730484
    z[4,3,1]  R2242     -1.4728754758834839e-01
    z[4,3,1]  R2243     8.4514260292053223e-01
    z[4,3,1]  R2244     8.3458983898162842e-01
    z[4,3,1]  R2245     9.0441882610321045e-01
    z[4,3,1]  R2246     5.4224532842636108e-01
    z[4,3,1]  R2247     4.8052567243576050e-01
    z[4,3,1]  R2248     4.5277449488639832e-01
    z[4,3,1]  R2249     -0.736034631729126
    z[4,3,1]  R2250     -0.50221848487854
    z[4,3,1]  R2251     -2.9484912753105164e-01
    z[4,3,1]  R2252     -3.2997876405715942e-01
    z[4,3,1]  R2253     -3.0022957921028137e-01
    z[4,3,1]  R2254     -0.0613643079996109
    z[4,3,1]  R2255     8.3372437953948975e-01
    z[4,3,1]  R2256     0.959001362323761
    z[4,3,1]  R2257     8.2865160703659058e-01
    z[4,3,1]  R2258     8.6359906196594238e-01
    z[4,3,1]  R2259     -7.7929478883743286e-01
    z[4,3,1]  R2260     5.7339859008789062e-01
    z[4,3,1]  R2261     7.7785891294479370e-01
    z[4,3,1]  R2262     -0.228417307138443
    z[4,3,1]  R2263     6.4570468664169312e-01
    z[4,3,1]  R2264     0.749077558517456
    z[4,3,1]  R2265     7.8521335124969482e-01
    z[4,3,1]  R2266     6.2177753448486328e-01
    z[4,3,1]  R2267     5.0166165828704834e-01
    z[4,3,1]  R2268     6.4847087860107422e-01
    z[4,3,1]  R2269     -5.2170819044113159e-01
    z[4,3,1]  R2270     -2.6020979881286621e-01
    z[4,3,1]  R2271     -1.6403673589229584e-01
    z[4,3,1]  R2272     -2.5790682435035706e-01
    z[4,3,1]  R2273     7.9363530874252319e-01
    z[4,3,1]  R2274     9.5412641763687134e-01
    z[4,3,1]  R2275     9.1491103172302246e-01
    z[4,3,1]  R2276     0.478773295879364
    z[4,3,1]  R2277     0.548701286315918
    z[4,3,1]  R2278     6.0121679306030273e-01
    z[4,3,1]  R2279     -1.6934056580066681e-01
    z[4,3,1]  R2280     8.2446902990341187e-01
    z[4,3,1]  R2281     9.6358984708786011e-01
    z[4,3,1]  R2282     6.5812236070632935e-01
    z[4,3,1]  R2283     7.1535408496856689e-01
    z[4,3,1]  R2284     5.4849225282669067e-01
    z[4,3,1]  R2285     7.1080332994461060e-01
    z[4,3,1]  R2286     7.2019606828689575e-01
    z[4,3,1]  R2287     0.670100748538971
    z[4,3,1]  R2288     0.737332820892334
    z[4,3,1]  R2289     0.505213737487793
    z[4,3,1]  R2290     -2.9188922047615051e-01
    z[4,3,1]  R2291     -2.7200677990913391e-01
    z[4,3,1]  R2292     -3.0819791555404663e-01
    z[4,3,1]  R2293     -4.9865084886550903e-01
    z[4,3,1]  R2294     -2.9265290498733521e-01
    z[4,3,1]  R2295     0.80692058801651
    z[4,3,1]  R2296     -5.2047246694564819e-01
    z[4,3,1]  R2297     1.3496515154838562e-01
    z[4,3,1]  R2298     -6.9121068716049194e-01
    z[4,3,1]  R2299     0.0921378806233406
    z[4,3,1]  R2300     2.1200199425220490e-01
    z[4,3,1]  R2301     -5.6763851642608643e-01
    z[4,3,1]  R2302     -8.2999789714813232e-01
    z[4,3,1]  R2303     -7.0515358448028564e-01
    z[4,3,1]  R2304     -4.0988948941230774e-01
    z[4,3,1]  R2305     -4.6646991372108459e-01
    z[4,3,1]  R2306     1.9349502027034760e-01
    z[4,3,1]  R2307     4.7425529360771179e-01
    z[4,3,1]  R2308     2.0977059006690979e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2169     -1
    z[4,3,2]  R2170     1
    z[4,3,2]  R2179     -1.9520850479602814e-01
    z[4,3,2]  R2180     9.2998119071125984e-03
    z[4,3,2]  R2181     -5.1382946968078613e-01
    z[4,3,2]  R2182     1.9087596237659454e-01
    z[4,3,2]  R2183     -1.3207024335861206e-01
    z[4,3,2]  R2184     -1.5683691203594208e-01
    z[4,3,2]  R2185     -3.3692610263824463e-01
    z[4,3,2]  R2186     -2.0341442525386810e-01
    z[4,3,2]  R2187     9.9804960191249847e-02
    z[4,3,2]  R2188     6.1308752745389938e-02
    z[4,3,2]  R2189     -2.7224181219935417e-02
    z[4,3,2]  R2190     1.4349375665187836e-01
    z[4,3,2]  R2191     -1.2734179198741913e-01
    z[4,3,2]  R2192     -2.1428765356540680e-01
    z[4,3,2]  R2193     7.2389543056488037e-01
    z[4,3,2]  R2194     5.6075859069824219e-01
    z[4,3,2]  R2195     4.6849995851516724e-01
    z[4,3,2]  R2196     -3.2706481218338013e-01
    z[4,3,2]  R2197     9.1979922726750374e-03
    z[4,3,2]  R2198     -5.4430490732192993e-01
    z[4,3,2]  R2199     5.6827646493911743e-01
    z[4,3,2]  R2200     -5.1286339759826660e-01
    z[4,3,2]  R2201     -0.46903195977211
    z[4,3,2]  R2202     1.9012993574142456e-01
    z[4,3,2]  R2203     -2.2154814004898071e-01
    z[4,3,2]  R2204     5.2097213268280029e-01
    z[4,3,2]  R2205     -1.8444817513227463e-02
    z[4,3,2]  R2206     6.6841256618499756e-01
    z[4,3,2]  R2207     3.9735755324363708e-01
    z[4,3,2]  R2208     -5.5841112136840820e-01
    z[4,3,2]  R2209     -1.5113285183906555e-01
    z[4,3,2]  R2210     1.7867620289325714e-01
    z[4,3,2]  R2211     5.4607796669006348e-01
    z[4,3,2]  R2212     -5.6303566694259644e-01
    z[4,3,2]  R2213     -3.3601748943328857e-01
    z[4,3,2]  R2214     -1.7890906333923340e-01
    z[4,3,2]  R2215     -1.4444294571876526e-01
    z[4,3,2]  R2216     -0.652751088142395
    z[4,3,2]  R2217     -3.9298117160797119e-01
    z[4,3,2]  R2218     9.1285429894924164e-02
    z[4,3,2]  R2219     -0.668785572052002
    z[4,3,2]  R2220     1.9610232114791870e-01
    z[4,3,2]  R2221     -7.2156423330307007e-01
    z[4,3,2]  R2222     1.7301666736602783e-01
    z[4,3,2]  R2223     -3.2959020137786865e-01
    z[4,3,2]  R2224     1.7456393688917160e-02
    z[4,3,2]  R2225     2.7208173274993896e-01
    z[4,3,2]  R2226     1.0649657994508743e-01
    z[4,3,2]  R2227     -0.0938347652554512
    z[4,3,2]  R2228     4.1236659884452820e-01
    z[4,3,2]  R2229     -0.494943231344223
    z[4,3,2]  R2230     -1.2691226601600647e-01
    z[4,3,2]  R2231     5.0492975860834122e-02
    z[4,3,2]  R2232     4.7204467654228210e-01
    z[4,3,2]  R2233     -8.4907226264476776e-02
    z[4,3,2]  R2234     -1.3565035164356232e-01
    z[4,3,2]  R2235     1.6225245594978333e-01
    z[4,3,2]  R2236     -1.5981492400169373e-01
    z[4,3,2]  R2237     0.0615328773856163
    z[4,3,2]  R2238     1.6760799288749695e-01
    z[4,3,2]  R2239     -1.1647468805313110e-01
    z[4,3,2]  R2240     2.5308451056480408e-01
    z[4,3,2]  R2241     -2.0218318328261375e-02
    z[4,3,2]  R2242     0.582478940486908
    z[4,3,2]  R2243     2.9166597127914429e-01
    z[4,3,2]  R2244     4.5439252257347107e-01
    z[4,3,2]  R2245     2.3995140194892883e-01
    z[4,3,2]  R2246     1.7692428827285767e-01
    z[4,3,2]  R2247     3.7672752141952515e-01
    z[4,3,2]  R2248     1.2909972667694092e-01
    z[4,3,2]  R2249     6.1129800975322723e-02
    z[4,3,2]  R2250     4.1504953987896442e-03
    z[4,3,2]  R2251     3.5807663202285767e-01
    z[4,3,2]  R2252     1.4697174727916718e-01
    z[4,3,2]  R2253     -2.2409553825855255e-01
    z[4,3,2]  R2254     -1.0674206167459488e-01
    z[4,3,2]  R2255     2.6567617058753967e-01
    z[4,3,2]  R2256     1.8880042433738708e-01
    z[4,3,2]  R2257     3.4775212407112122e-01
    z[4,3,2]  R2258     -0.073155976831913
    z[4,3,2]  R2259     5.9725141525268555e-01
    z[4,3,2]  R2260     -9.0044438838958740e-02
    z[4,3,2]  R2261     3.5335725545883179e-01
    z[4,3,2]  R2262     -4.3700179457664490e-01
    z[4,3,2]  R2263     2.0539747178554535e-01
    z[4,3,2]  R2264     2.1612955629825592e-01
    z[4,3,2]  R2265     3.0064875259995461e-02
    z[4,3,2]  R2266     2.0245923101902008e-01
    z[4,3,2]  R2267     2.1178799867630005e-01
    z[4,3,2]  R2268     -3.9450940489768982e-01
    z[4,3,2]  R2269     4.3772339820861816e-02
    z[4,3,2]  R2270     -4.0393903851509094e-02
    z[4,3,2]  R2271     9.4932131469249725e-02
    z[4,3,2]  R2272     -3.7179183959960938e-01
    z[4,3,2]  R2273     2.8107839822769165e-01
    z[4,3,2]  R2274     1.8511307239532471e-01
    z[4,3,2]  R2275     -1.2274567782878876e-01
    z[4,3,2]  R2276     1.3293507695198059e-01
    z[4,3,2]  R2277     2.1158735454082489e-01
    z[4,3,2]  R2278     -5.7536359876394272e-02
    z[4,3,2]  R2279     3.7202858924865723e-01
    z[4,3,2]  R2280     2.4892997741699219e-01
    z[4,3,2]  R2281     6.7938235588371754e-03
    z[4,3,2]  R2282     2.5844931602478027e-01
    z[4,3,2]  R2283     1.1316926218569279e-02
    z[4,3,2]  R2284     6.3249832019209862e-03
    z[4,3,2]  R2285     -2.2752940654754639e-01
    z[4,3,2]  R2286     -3.5796791315078735e-01
    z[4,3,2]  R2287     -2.9539284110069275e-01
    z[4,3,2]  R2288     -1.9871445000171661e-01
    z[4,3,2]  R2289     9.6491836011409760e-02
    z[4,3,2]  R2290     1.0408055037260056e-01
    z[4,3,2]  R2291     -2.7911257743835449e-01
    z[4,3,2]  R2292     -1.6206982731819153e-01
    z[4,3,2]  R2293     2.9160779714584351e-01
    z[4,3,2]  R2294     1.2674829363822937e-01
    z[4,3,2]  R2295     9.7393020987510681e-02
    z[4,3,2]  R2296     -9.0242482721805573e-02
    z[4,3,2]  R2297     2.9007151722908020e-01
    z[4,3,2]  R2298     -1.8557514250278473e-01
    z[4,3,2]  R2299     -2.3937630653381348e-01
    z[4,3,2]  R2300     4.1321533918380737e-01
    z[4,3,2]  R2301     -4.4200602173805237e-01
    z[4,3,2]  R2302     5.5509600788354874e-02
    z[4,3,2]  R2303     1.0695017874240875e-01
    z[4,3,2]  R2304     -3.8250240683555603e-01
    z[4,3,2]  R2305     -4.8148775100708008e-01
    z[4,3,2]  R2306     -5.3229510784149170e-01
    z[4,3,2]  R2307     1.8213652074337006e-01
    z[4,3,2]  R2308     -0.0711749866604805
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2171     -1
    z[4,3,3]  R2172     1
    z[4,3,3]  R2179     -3.6240240931510925e-01
    z[4,3,3]  R2180     -5.8406364917755127e-01
    z[4,3,3]  R2181     -3.9486807584762573e-01
    z[4,3,3]  R2182     -4.8408702015876770e-01
    z[4,3,3]  R2183     -2.6580053567886353e-01
    z[4,3,3]  R2184     -1.0204381495714188e-01
    z[4,3,3]  R2185     -2.9818978905677795e-01
    z[4,3,3]  R2186     -4.7207662463188171e-01
    z[4,3,3]  R2187     -4.9308976531028748e-01
    z[4,3,3]  R2188     -4.1535407304763794e-01
    z[4,3,3]  R2189     -1.7730298638343811e-01
    z[4,3,3]  R2190     9.8836747929453850e-03
    z[4,3,3]  R2191     6.6793225705623627e-02
    z[4,3,3]  R2192     2.3008877038955688e-01
    z[4,3,3]  R2193     3.6241963505744934e-01
    z[4,3,3]  R2194     1.1827819049358368e-01
    z[4,3,3]  R2195     4.2783892154693604e-01
    z[4,3,3]  R2196     0.361988365650177
    z[4,3,3]  R2197     1.6963206231594086e-01
    z[4,3,3]  R2198     3.9747819304466248e-01
    z[4,3,3]  R2199     2.1296314895153046e-01
    z[4,3,3]  R2200     1.4430669136345387e-02
    z[4,3,3]  R2201     -3.5894379019737244e-01
    z[4,3,3]  R2202     -5.8972876518964767e-02
    z[4,3,3]  R2203     -1.3377124071121216e-01
    z[4,3,3]  R2204     2.0331309735774994e-01
    z[4,3,3]  R2205     1.6727812588214874e-01
    z[4,3,3]  R2206     -4.0399852395057678e-01
    z[4,3,3]  R2207     -2.3591844365000725e-02
    z[4,3,3]  R2208     4.4183173775672913e-01
    z[4,3,3]  R2209     -3.2720467448234558e-01
    z[4,3,3]  R2210     -4.3055215477943420e-01
    z[4,3,3]  R2211     -3.1249335408210754e-01
    z[4,3,3]  R2212     0.405229389667511
    z[4,3,3]  R2213     1.7126889526844025e-01
    z[4,3,3]  R2214     5.4399931430816650e-01
    z[4,3,3]  R2215     3.7154817581176758e-01
    z[4,3,3]  R2216     -7.8700542449951172e-02
    z[4,3,3]  R2217     -6.3104387372732162e-03
    z[4,3,3]  R2218     2.0656596124172211e-01
    z[4,3,3]  R2219     -2.2475211322307587e-01
    z[4,3,3]  R2220     -5.3780917078256607e-02
    z[4,3,3]  R2221     2.1162706613540649e-01
    z[4,3,3]  R2222     -6.0689233243465424e-02
    z[4,3,3]  R2223     4.1020902991294861e-01
    z[4,3,3]  R2224     -6.2734061479568481e-01
    z[4,3,3]  R2225     -1.5283970534801483e-01
    z[4,3,3]  R2226     9.8189562559127808e-02
    z[4,3,3]  R2227     3.2321885228157043e-01
    z[4,3,3]  R2228     0.495151162147522
    z[4,3,3]  R2229     -1.1997682973742485e-02
    z[4,3,3]  R2230     -3.3768004179000854e-01
    z[4,3,3]  R2231     2.6501366496086121e-01
    z[4,3,3]  R2232     2.4692660570144653e-01
    z[4,3,3]  R2233     1.5630787611007690e-01
    z[4,3,3]  R2234     -3.9980259537696838e-01
    z[4,3,3]  R2235     2.1275892853736877e-02
    z[4,3,3]  R2236     -2.5178197026252747e-01
    z[4,3,3]  R2237     3.1184336543083191e-01
    z[4,3,3]  R2238     2.5135293602943420e-02
    z[4,3,3]  R2239     4.3311214447021484e-01
    z[4,3,3]  R2240     -4.6883741021156311e-01
    z[4,3,3]  R2241     1.8819957971572876e-02
    z[4,3,3]  R2242     -3.3058160543441772e-01
    z[4,3,3]  R2243     4.9212433397769928e-02
    z[4,3,3]  R2244     5.8376058936119080e-02
    z[4,3,3]  R2245     2.5313809514045715e-01
    z[4,3,3]  R2246     3.5397332906723022e-01
    z[4,3,3]  R2247     4.8243951797485352e-01
    z[4,3,3]  R2248     0.520687997341156
    z[4,3,3]  R2249     -5.3401719778776169e-02
    z[4,3,3]  R2250     3.7972751259803772e-01
    z[4,3,3]  R2251     -1.1306407302618027e-01
    z[4,3,3]  R2252     -3.3169585466384888e-01
    z[4,3,3]  R2253     2.3402684926986694e-01
    z[4,3,3]  R2254     -3.3222606778144836e-01
    z[4,3,3]  R2255     2.2909869253635406e-01
    z[4,3,3]  R2256     1.4218333363533020e-01
    z[4,3,3]  R2257     2.0553000271320343e-01
    z[4,3,3]  R2258     2.3103292286396027e-01
    z[4,3,3]  R2259     -5.7719651609659195e-02
    z[4,3,3]  R2260     1.9641692936420441e-01
    z[4,3,3]  R2261     1.0498762130737305e-01
    z[4,3,3]  R2262     8.7422579526901245e-02
    z[4,3,3]  R2263     0.33449786901474
    z[4,3,3]  R2264     2.0736102759838104e-01
    z[4,3,3]  R2265     3.3902138471603394e-01
    z[4,3,3]  R2266     -2.3966248333454132e-01
    z[4,3,3]  R2267     3.6694878339767456e-01
    z[4,3,3]  R2268     -5.0786721706390381e-01
    z[4,3,3]  R2269     -2.3085476830601692e-02
    z[4,3,3]  R2270     1.0495626181364059e-01
    z[4,3,3]  R2271     -3.4113073348999023e-01
    z[4,3,3]  R2272     8.6206562817096710e-02
    z[4,3,3]  R2273     2.9715862870216370e-01
    z[4,3,3]  R2274     1.2247022241353989e-01
    z[4,3,3]  R2275     -2.4262189865112305e-02
    z[4,3,3]  R2276     6.0212099552154541e-01
    z[4,3,3]  R2277     2.7250188589096069e-01
    z[4,3,3]  R2278     2.7629515528678894e-01
    z[4,3,3]  R2279     -2.8098204731941223e-01
    z[4,3,3]  R2280     8.2127936184406281e-02
    z[4,3,3]  R2281     9.0992741286754608e-02
    z[4,3,3]  R2282     5.9459584951400757e-01
    z[4,3,3]  R2283     4.8615738749504089e-01
    z[4,3,3]  R2284     4.2329812049865723e-01
    z[4,3,3]  R2285     1.4226980507373810e-02
    z[4,3,3]  R2286     -1.6567033529281616e-01
    z[4,3,3]  R2287     -1.9238793849945068e-01
    z[4,3,3]  R2288     -1.8471808731555939e-01
    z[4,3,3]  R2289     3.8233183324337006e-02
    z[4,3,3]  R2290     -5.6281287223100662e-02
    z[4,3,3]  R2291     -1.6667445003986359e-01
    z[4,3,3]  R2292     -1.1466748267412186e-01
    z[4,3,3]  R2293     2.0051820203661919e-02
    z[4,3,3]  R2294     1.4815273880958557e-01
    z[4,3,3]  R2295     -1.3428920507431030e-01
    z[4,3,3]  R2296     -4.4378823041915894e-01
    z[4,3,3]  R2297     -2.1803137660026550e-01
    z[4,3,3]  R2298     -3.4357210993766785e-01
    z[4,3,3]  R2299     -7.1974718570709229e-01
    z[4,3,3]  R2300     -3.4759324789047241e-01
    z[4,3,3]  R2301     -1.9642159342765808e-01
    z[4,3,3]  R2302     1.9086253643035889e-01
    z[4,3,3]  R2303     2.0496025681495667e-01
    z[4,3,3]  R2304     -7.6402656733989716e-02
    z[4,3,3]  R2305     1.2922681868076324e-01
    z[4,3,3]  R2306     3.9129105210304260e-01
    z[4,3,3]  R2307     5.7691287994384766e-01
    z[4,3,3]  R2308     -1.4007851481437683e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2173     -1
    z[4,3,4]  R2174     1
    z[4,3,4]  R2179     -1.6682930290699005e-01
    z[4,3,4]  R2180     -1.9122330844402313e-01
    z[4,3,4]  R2181     -1.1914963275194168e-01
    z[4,3,4]  R2182     -2.1009781956672668e-01
    z[4,3,4]  R2183     -4.1547951102256775e-01
    z[4,3,4]  R2184     3.2895419280976057e-03
    z[4,3,4]  R2185     6.3411749899387360e-02
    z[4,3,4]  R2186     2.6501941680908203e-01
    z[4,3,4]  R2187     -9.0105690062046051e-02
    z[4,3,4]  R2188     2.3578166961669922e-01
    z[4,3,4]  R2189     -2.0581318438053131e-01
    z[4,3,4]  R2190     -1.5405574440956116e-01
    z[4,3,4]  R2191     -4.6345052123069763e-01
    z[4,3,4]  R2192     -1.7371930181980133e-01
    z[4,3,4]  R2193     1.5203894674777985e-01
    z[4,3,4]  R2194     -1.7029793560504913e-01
    z[4,3,4]  R2195     -1.4309158921241760e-01
    z[4,3,4]  R2196     6.5895318984985352e-02
    z[4,3,4]  R2197     -8.9322596788406372e-02
    z[4,3,4]  R2198     6.9609411060810089e-02
    z[4,3,4]  R2199     3.4623327851295471e-01
    z[4,3,4]  R2200     -4.7948709130287170e-01
    z[4,3,4]  R2201     -6.1006331443786621e-01
    z[4,3,4]  R2202     8.7079212069511414e-02
    z[4,3,4]  R2203     4.4583201408386230e-01
    z[4,3,4]  R2204     3.1959778070449829e-01
    z[4,3,4]  R2205     -0.0889601856470108
    z[4,3,4]  R2206     -4.1677546501159668e-01
    z[4,3,4]  R2207     1.6093716025352478e-01
    z[4,3,4]  R2208     2.8899261355400085e-01
    z[4,3,4]  R2209     -6.7880898714065552e-01
    z[4,3,4]  R2210     2.3162260651588440e-01
    z[4,3,4]  R2211     -4.2658692598342896e-01
    z[4,3,4]  R2212     3.7110611796379089e-02
    z[4,3,4]  R2213     0.253608763217926
    z[4,3,4]  R2214     -3.0783239006996155e-01
    z[4,3,4]  R2215     8.0141127109527588e-02
    z[4,3,4]  R2216     2.8608945012092590e-01
    z[4,3,4]  R2217     -3.0059763230383396e-03
    z[4,3,4]  R2218     3.0319327116012573e-01
    z[4,3,4]  R2219     -4.4815093278884888e-01
    z[4,3,4]  R2220     1.0846333205699921e-01
    z[4,3,4]  R2221     -2.5771671533584595e-01
    z[4,3,4]  R2222     7.1807242929935455e-02
    z[4,3,4]  R2223     3.1035497784614563e-01
    z[4,3,4]  R2224     3.9208721369504929e-02
    z[4,3,4]  R2225     -4.1954988241195679e-01
    z[4,3,4]  R2226     3.2510882616043091e-01
    z[4,3,4]  R2227     3.0939370393753052e-01
    z[4,3,4]  R2228     1.0399816930294037e-01
    z[4,3,4]  R2229     -3.2380643486976624e-01
    z[4,3,4]  R2230     -4.3692804872989655e-02
    z[4,3,4]  R2231     3.5460570454597473e-01
    z[4,3,4]  R2232     -1.2773409485816956e-01
    z[4,3,4]  R2233     -9.9731072783470154e-02
    z[4,3,4]  R2234     2.4622483551502228e-01
    z[4,3,4]  R2235     4.0934920310974121e-01
    z[4,3,4]  R2236     -2.5437366962432861e-01
    z[4,3,4]  R2237     3.4494414925575256e-02
    z[4,3,4]  R2238     3.8776747882366180e-02
    z[4,3,4]  R2239     -2.2928847372531891e-01
    z[4,3,4]  R2240     7.2756119072437286e-02
    z[4,3,4]  R2241     -5.0857514142990112e-01
    z[4,3,4]  R2242     2.7385911345481873e-01
    z[4,3,4]  R2243     3.0575612187385559e-01
    z[4,3,4]  R2244     2.1467334032058716e-01
    z[4,3,4]  R2245     1.6659593582153320e-01
    z[4,3,4]  R2246     6.6348105669021606e-01
    z[4,3,4]  R2247     -7.7274434268474579e-02
    z[4,3,4]  R2248     5.2379506826400757e-01
    z[4,3,4]  R2249     2.8799173235893250e-01
    z[4,3,4]  R2250     -1.4048458635807037e-01
    z[4,3,4]  R2251     -1.8486697971820831e-01
    z[4,3,4]  R2252     2.1070814132690430e-01
    z[4,3,4]  R2253     -2.4036785587668419e-02
    z[4,3,4]  R2254     3.0900094658136368e-02
    z[4,3,4]  R2255     1.7191524803638458e-01
    z[4,3,4]  R2256     0.0910961776971817
    z[4,3,4]  R2257     2.3283807933330536e-01
    z[4,3,4]  R2258     0.0839817002415657
    z[4,3,4]  R2259     4.7030895948410034e-02
    z[4,3,4]  R2260     2.6917797327041626e-01
    z[4,3,4]  R2261     -2.2383768856525421e-01
    z[4,3,4]  R2262     2.5361141562461853e-01
    z[4,3,4]  R2263     5.5442094802856445e-01
    z[4,3,4]  R2264     5.7248443365097046e-01
    z[4,3,4]  R2265     -0.470795214176178
    z[4,3,4]  R2266     4.7683233022689819e-01
    z[4,3,4]  R2267     4.5888155698776245e-01
    z[4,3,4]  R2268     1.3239391148090363e-01
    z[4,3,4]  R2269     2.6018369942903519e-02
    z[4,3,4]  R2270     -2.6247984170913696e-01
    z[4,3,4]  R2271     -2.6960924267768860e-01
    z[4,3,4]  R2272     2.5080201029777527e-01
    z[4,3,4]  R2273     3.7362700700759888e-01
    z[4,3,4]  R2274     -1.7409019637852907e-03
    z[4,3,4]  R2275     -2.4190691113471985e-01
    z[4,3,4]  R2276     5.1489669084548950e-01
    z[4,3,4]  R2277     -1.8420583009719849e-01
    z[4,3,4]  R2278     -1.3304264843463898e-01
    z[4,3,4]  R2279     3.0345159769058228e-01
    z[4,3,4]  R2280     4.6785643696784973e-01
    z[4,3,4]  R2281     -9.7694151103496552e-02
    z[4,3,4]  R2282     6.8273797631263733e-02
    z[4,3,4]  R2283     -2.1637508273124695e-01
    z[4,3,4]  R2284     2.2672414779663086e-01
    z[4,3,4]  R2285     -1.3508158922195435e-01
    z[4,3,4]  R2286     1.2351201474666595e-01
    z[4,3,4]  R2287     -1.2425804138183594e-01
    z[4,3,4]  R2288     -2.5327226519584656e-01
    z[4,3,4]  R2289     2.6292881369590759e-01
    z[4,3,4]  R2290     1.1427477002143860e-03
    z[4,3,4]  R2291     2.9889410734176636e-01
    z[4,3,4]  R2292     5.2212929725646973e-01
    z[4,3,4]  R2293     2.8739643096923828e-01
    z[4,3,4]  R2294     4.6194615960121155e-01
    z[4,3,4]  R2295     -2.1076743304729462e-01
    z[4,3,4]  R2296     8.2869090139865875e-02
    z[4,3,4]  R2297     -5.6725829839706421e-01
    z[4,3,4]  R2298     -2.1376505494117737e-01
    z[4,3,4]  R2299     -5.7799136638641357e-01
    z[4,3,4]  R2300     -1.2210885435342789e-01
    z[4,3,4]  R2301     -3.7678331136703491e-01
    z[4,3,4]  R2302     -1.7832627892494202e-01
    z[4,3,4]  R2303     -4.3485438823699951e-01
    z[4,3,4]  R2304     0.597722053527832
    z[4,3,4]  R2305     4.6631014347076416e-01
    z[4,3,4]  R2306     2.9649755358695984e-01
    z[4,3,4]  R2307     4.4300094246864319e-01
    z[4,3,4]  R2308     7.8966683149337769e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2175     -1
    z[4,3,5]  R2176     1
    z[4,3,5]  R2179     -0.567290186882019
    z[4,3,5]  R2180     -4.7096580266952515e-01
    z[4,3,5]  R2181     -2.8467962145805359e-01
    z[4,3,5]  R2182     -4.5613187551498413e-01
    z[4,3,5]  R2183     -3.7316355109214783e-01
    z[4,3,5]  R2184     -4.9113425612449646e-01
    z[4,3,5]  R2185     -2.2501760721206665e-01
    z[4,3,5]  R2186     -4.5422890782356262e-01
    z[4,3,5]  R2187     -1.9683602452278137e-01
    z[4,3,5]  R2188     -7.4810914695262909e-02
    z[4,3,5]  R2189     5.5614137649536133e-01
    z[4,3,5]  R2190     4.6744874119758606e-01
    z[4,3,5]  R2191     3.0523526668548584e-01
    z[4,3,5]  R2192     -4.0307754278182983e-01
    z[4,3,5]  R2193     6.4861392602324486e-03
    z[4,3,5]  R2194     -3.5454906523227692e-02
    z[4,3,5]  R2195     1.2842306494712830e-01
    z[4,3,5]  R2196     1.4541678130626678e-01
    z[4,3,5]  R2197     1.6680285334587097e-01
    z[4,3,5]  R2198     8.6275503039360046e-02
    z[4,3,5]  R2199     -8.8976975530385971e-03
    z[4,3,5]  R2200     4.5235604047775269e-01
    z[4,3,5]  R2201     3.6717417836189270e-01
    z[4,3,5]  R2202     -6.2057387083768845e-02
    z[4,3,5]  R2203     1.4026379585266113e-01
    z[4,3,5]  R2204     -8.7293386459350586e-02
    z[4,3,5]  R2205     2.5280052423477173e-01
    z[4,3,5]  R2206     1.5615834295749664e-01
    z[4,3,5]  R2207     -1.2509214878082275e-01
    z[4,3,5]  R2208     2.4431882798671722e-01
    z[4,3,5]  R2209     3.5856953263282776e-01
    z[4,3,5]  R2210     5.8395403623580933e-01
    z[4,3,5]  R2211     2.4112163484096527e-01
    z[4,3,5]  R2212     2.9454326629638672e-01
    z[4,3,5]  R2213     3.1561228632926941e-01
    z[4,3,5]  R2214     -1.8078792095184326e-01
    z[4,3,5]  R2215     -2.5250095129013062e-01
    z[4,3,5]  R2216     1.8632566928863525e-01
    z[4,3,5]  R2217     -4.3672680854797363e-01
    z[4,3,5]  R2218     -8.9058600366115570e-02
    z[4,3,5]  R2219     4.4784566760063171e-01
    z[4,3,5]  R2220     0.425496906042099
    z[4,3,5]  R2221     3.2415258884429932e-01
    z[4,3,5]  R2222     -1.6619232296943665e-01
    z[4,3,5]  R2223     -2.3024032998364419e-04
    z[4,3,5]  R2224     -2.1188246086239815e-02
    z[4,3,5]  R2225     -4.2546260356903076e-01
    z[4,3,5]  R2226     -3.7626194953918457e-01
    z[4,3,5]  R2227     -1.1377550661563873e-02
    z[4,3,5]  R2228     -1.3964809477329254e-01
    z[4,3,5]  R2229     4.3637013435363770e-01
    z[4,3,5]  R2230     5.8601337671279907e-01
    z[4,3,5]  R2231     1.8636810779571533e-01
    z[4,3,5]  R2232     2.5316748023033142e-01
    z[4,3,5]  R2233     1.7170919477939606e-01
    z[4,3,5]  R2234     3.3964416384696960e-01
    z[4,3,5]  R2235     -2.2880868613719940e-01
    z[4,3,5]  R2236     -3.0514645576477051e-01
    z[4,3,5]  R2237     -3.9614114910364151e-02
    z[4,3,5]  R2238     -1.1986841447651386e-02
    z[4,3,5]  R2239     -1.8737922608852386e-01
    z[4,3,5]  R2240     2.9761362075805664e-01
    z[4,3,5]  R2241     -1.4091113209724426e-01
    z[4,3,5]  R2242     -2.1088285744190216e-01
    z[4,3,5]  R2243     -1.4867080748081207e-01
    z[4,3,5]  R2244     -1.5140730142593384e-01
    z[4,3,5]  R2245     7.3399171233177185e-02
    z[4,3,5]  R2246     -1.3731801509857178e-01
    z[4,3,5]  R2247     -2.1077500283718109e-01
    z[4,3,5]  R2248     -4.1861617565155029e-01
    z[4,3,5]  R2249     1.5950110554695129e-01
    z[4,3,5]  R2250     3.1426626443862915e-01
    z[4,3,5]  R2251     6.6431082785129547e-02
    z[4,3,5]  R2252     4.6235236525535583e-01
    z[4,3,5]  R2253     -1.1576903052628040e-02
    z[4,3,5]  R2254     -7.8274980187416077e-02
    z[4,3,5]  R2255     -3.7693977355957031e-01
    z[4,3,5]  R2256     4.1850835084915161e-02
    z[4,3,5]  R2257     6.0755524784326553e-02
    z[4,3,5]  R2258     -1.1820632964372635e-02
    z[4,3,5]  R2259     5.8419197797775269e-02
    z[4,3,5]  R2260     -4.5930200815200806e-01
    z[4,3,5]  R2261     1.8721137195825577e-02
    z[4,3,5]  R2262     -4.5784667134284973e-01
    z[4,3,5]  R2263     -1.4388071000576019e-01
    z[4,3,5]  R2264     0.082222118973732
    z[4,3,5]  R2265     1.2622365355491638e-01
    z[4,3,5]  R2266     -2.6503092050552368e-01
    z[4,3,5]  R2267     -3.6509260535240173e-01
    z[4,3,5]  R2268     -1.9301755726337433e-01
    z[4,3,5]  R2269     2.3834304511547089e-01
    z[4,3,5]  R2270     3.6902558803558350e-01
    z[4,3,5]  R2271     3.8425880670547485e-01
    z[4,3,5]  R2272     -4.2244362831115723e-01
    z[4,3,5]  R2273     2.0742814987897873e-02
    z[4,3,5]  R2274     0.0847427025437355
    z[4,3,5]  R2275     1.6116046905517578e-01
    z[4,3,5]  R2276     -3.4456923604011536e-01
    z[4,3,5]  R2277     -5.1498931646347046e-01
    z[4,3,5]  R2278     -2.9532846808433533e-01
    z[4,3,5]  R2279     -3.2721281051635742e-01
    z[4,3,5]  R2280     -5.4802145808935165e-02
    z[4,3,5]  R2281     2.5784159079194069e-02
    z[4,3,5]  R2282     -3.3183619379997253e-01
    z[4,3,5]  R2283     -9.4814337790012360e-02
    z[4,3,5]  R2284     -3.2409057021141052e-01
    z[4,3,5]  R2285     -3.0177587270736694e-01
    z[4,3,5]  R2286     -3.4313338994979858e-01
    z[4,3,5]  R2287     -2.3594951629638672e-01
    z[4,3,5]  R2288     -3.2928720116615295e-01
    z[4,3,5]  R2289     -7.6487839221954346e-01
    z[4,3,5]  R2290     -8.1545692682266235e-01
    z[4,3,5]  R2291     -6.6843688488006592e-01
    z[4,3,5]  R2292     -1.8858213722705841e-01
    z[4,3,5]  R2293     -2.8500708937644958e-01
    z[4,3,5]  R2294     -5.8723074197769165e-01
    z[4,3,5]  R2295     -4.9610987305641174e-01
    z[4,3,5]  R2296     -1.2263411283493042e-01
    z[4,3,5]  R2297     -7.1447348594665527e-01
    z[4,3,5]  R2298     1.4723853208124638e-02
    z[4,3,5]  R2299     -2.5184974074363708e-01
    z[4,3,5]  R2300     3.0484935641288757e-01
    z[4,3,5]  R2301     -3.5863202810287476e-01
    z[4,3,5]  R2302     1.1830098181962967e-01
    z[4,3,5]  R2303     2.0683903992176056e-01
    z[4,3,5]  R2304     2.4618925154209137e-01
    z[4,3,5]  R2305     3.5562586784362793e-01
    z[4,3,5]  R2306     -3.2573845237493515e-02
    z[4,3,5]  R2307     3.1028228998184204e-01
    z[4,3,5]  R2308     3.1595242023468018e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2177     -1
    z[4,3,6]  R2178     1
    z[4,3,6]  R2179     -1.1409967392683029e-01
    z[4,3,6]  R2180     1.8631061911582947e-01
    z[4,3,6]  R2181     1.5505558252334595e-01
    z[4,3,6]  R2182     -9.4230905175209045e-02
    z[4,3,6]  R2183     8.8811673223972321e-02
    z[4,3,6]  R2184     -5.4144892841577530e-02
    z[4,3,6]  R2185     -3.6406937241554260e-01
    z[4,3,6]  R2186     2.2296257317066193e-01
    z[4,3,6]  R2187     -4.3690085411071777e-01
    z[4,3,6]  R2188     -0.284881055355072
    z[4,3,6]  R2189     2.3958197236061096e-01
    z[4,3,6]  R2190     -2.3904012143611908e-01
    z[4,3,6]  R2191     -1.1963321268558502e-01
    z[4,3,6]  R2192     -4.6805106103420258e-02
    z[4,3,6]  R2193     -1.7740327119827271e-01
    z[4,3,6]  R2194     3.9852154254913330e-01
    z[4,3,6]  R2195     -1.7968656122684479e-01
    z[4,3,6]  R2196     -5.7249772548675537e-01
    z[4,3,6]  R2197     -6.5263003110885620e-01
    z[4,3,6]  R2198     -2.8091764450073242e-01
    z[4,3,6]  R2199     1.6536907851696014e-01
    z[4,3,6]  R2200     -3.8747996091842651e-01
    z[4,3,6]  R2201     -3.6879444122314453e-01
    z[4,3,6]  R2202     7.8969156742095947e-01
    z[4,3,6]  R2203     -2.0165938138961792e-01
    z[4,3,6]  R2204     -1.3785080611705780e-01
    z[4,3,6]  R2205     0.332021564245224
    z[4,3,6]  R2206     8.9740976691246033e-02
    z[4,3,6]  R2207     -1.3271878659725189e-01
    z[4,3,6]  R2208     2.6851412653923035e-01
    z[4,3,6]  R2209     -4.4646671414375305e-01
    z[4,3,6]  R2210     3.5155513882637024e-01
    z[4,3,6]  R2211     9.7187506034970284e-03
    z[4,3,6]  R2212     -3.9079171419143677e-01
    z[4,3,6]  R2213     -1.6757705807685852e-01
    z[4,3,6]  R2214     -2.3581512272357941e-02
    z[4,3,6]  R2215     4.8792776465415955e-01
    z[4,3,6]  R2216     5.0658807158470154e-02
    z[4,3,6]  R2217     4.8480924963951111e-01
    z[4,3,6]  R2218     -2.5699833035469055e-01
    z[4,3,6]  R2219     6.6792696714401245e-02
    z[4,3,6]  R2220     2.0928496122360229e-01
    z[4,3,6]  R2221     -6.2918695621192455e-03
    z[4,3,6]  R2222     0.377238005399704
    z[4,3,6]  R2223     3.1086388230323792e-01
    z[4,3,6]  R2224     -1.9821390509605408e-01
    z[4,3,6]  R2225     -1.8849206389859319e-03
    z[4,3,6]  R2226     5.9384290128946304e-02
    z[4,3,6]  R2227     -9.6629941835999489e-03
    z[4,3,6]  R2228     1.4050062000751495e-01
    z[4,3,6]  R2229     -2.0856364071369171e-01
    z[4,3,6]  R2230     1.5194277465343475e-01
    z[4,3,6]  R2231     1.9492205977439880e-01
    z[4,3,6]  R2232     -3.1650376319885254e-01
    z[4,3,6]  R2233     -2.8207591176033020e-01
    z[4,3,6]  R2234     -2.5937798619270325e-01
    z[4,3,6]  R2235     -2.2709725797176361e-01
    z[4,3,6]  R2236     -1.5670976042747498e-01
    z[4,3,6]  R2237     -1.8955725431442261e-01
    z[4,3,6]  R2238     -1.1056371033191681e-01
    z[4,3,6]  R2239     1.5578483045101166e-01
    z[4,3,6]  R2240     -3.3971226215362549e-01
    z[4,3,6]  R2241     2.9629576206207275e-01
    z[4,3,6]  R2242     -1.7692670226097107e-01
    z[4,3,6]  R2243     1.2157399207353592e-01
    z[4,3,6]  R2244     -8.9330114424228668e-02
    z[4,3,6]  R2245     -1.0918104648590088e-01
    z[4,3,6]  R2246     2.1212534606456757e-01
    z[4,3,6]  R2247     -0.00732843903824687
    z[4,3,6]  R2248     -1.8028123676776886e-01
    z[4,3,6]  R2249     5.8017671108245850e-01
    z[4,3,6]  R2250     1.7972312867641449e-02
    z[4,3,6]  R2251     -4.0665301680564880e-01
    z[4,3,6]  R2252     1.0987018793821335e-01
    z[4,3,6]  R2253     6.1497384309768677e-01
    z[4,3,6]  R2254     -3.0301022529602051e-01
    z[4,3,6]  R2255     2.1675251424312592e-02
    z[4,3,6]  R2256     8.7226778268814087e-02
    z[4,3,6]  R2257     2.8561198711395264e-01
    z[4,3,6]  R2258     4.3371358513832092e-01
    z[4,3,6]  R2259     1.3211207091808319e-01
    z[4,3,6]  R2260     -4.1308730840682983e-01
    z[4,3,6]  R2261     -1.3268908485770226e-02
    z[4,3,6]  R2262     -9.4475768506526947e-02
    z[4,3,6]  R2263     1.4035947620868683e-01
    z[4,3,6]  R2264     1.2068077921867371e-01
    z[4,3,6]  R2265     2.5822622701525688e-02
    z[4,3,6]  R2266     3.6570936441421509e-01
    z[4,3,6]  R2267     4.2769372463226318e-01
    z[4,3,6]  R2268     -8.2987926900386810e-02
    z[4,3,6]  R2269     -2.1248523890972137e-01
    z[4,3,6]  R2270     4.3469882011413574e-01
    z[4,3,6]  R2271     2.6805743575096130e-01
    z[4,3,6]  R2272     -1.0324721783399582e-01
    z[4,3,6]  R2273     2.3308119177818298e-01
    z[4,3,6]  R2274     -1.6491647064685822e-01
    z[4,3,6]  R2275     -1.6455566883087158e-01
    z[4,3,6]  R2276     -6.8455703556537628e-02
    z[4,3,6]  R2277     -2.2133512794971466e-01
    z[4,3,6]  R2278     -9.1432582121342421e-04
    z[4,3,6]  R2279     -0.0773564875125885
    z[4,3,6]  R2280     1.6218551993370056e-01
    z[4,3,6]  R2281     -9.9893517792224884e-02
    z[4,3,6]  R2282     -1.7724396288394928e-01
    z[4,3,6]  R2283     3.0140149593353271e-01
    z[4,3,6]  R2284     5.6753152608871460e-01
    z[4,3,6]  R2285     -1.5236841142177582e-01
    z[4,3,6]  R2286     4.0906123816967010e-02
    z[4,3,6]  R2287     -3.5598453134298325e-02
    z[4,3,6]  R2288     1.6011761128902435e-01
    z[4,3,6]  R2289     -3.8868039846420288e-02
    z[4,3,6]  R2290     1.7078292369842529e-01
    z[4,3,6]  R2291     6.9759249687194824e-02
    z[4,3,6]  R2292     -2.1688843145966530e-02
    z[4,3,6]  R2293     -1.9994966685771942e-01
    z[4,3,6]  R2294     -2.4667167663574219e-01
    z[4,3,6]  R2295     -2.4155495688319206e-02
    z[4,3,6]  R2296     -3.1171691417694092e-01
    z[4,3,6]  R2297     1.3359299302101135e-01
    z[4,3,6]  R2298     3.6421930789947510e-01
    z[4,3,6]  R2299     8.1820584833621979e-02
    z[4,3,6]  R2300     0.178999662399292
    z[4,3,6]  R2301     -3.2374124974012375e-02
    z[4,3,6]  R2302     -3.1008267402648926e-01
    z[4,3,6]  R2303     1.9876374304294586e-01
    z[4,3,6]  R2304     1.7755150794982910e-01
    z[4,3,6]  R2305     -3.0585335567593575e-02
    z[4,3,6]  R2306     2.4119900166988373e-01
    z[4,3,6]  R2307     -1.1051856726408005e-01
    z[4,3,6]  R2308     -2.6112416386604309e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R45       1
    RHS1      R46       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[5,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,6]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[5,3]
 BV BND1      phi[4,6]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
ENDATA
